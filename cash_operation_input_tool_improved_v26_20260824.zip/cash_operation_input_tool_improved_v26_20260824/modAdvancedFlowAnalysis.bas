Attribute VB_Name = "modAdvancedFlowAnalysis"
Option Explicit

'��������̑g�����͖������ɂ���Ǝw���I�ɑ����邽�߁A������̒T���͈͂𖾎����Đ��䂷��B
'������B���͖ق��Č��������������A�������ʂ������O�ɃG���[�Œ�~����B
Private Const FLOW_BUFFER_ROWS As Long = 1000
Private Const FLOW_MAX_SIDE_TRANSACTIONS As Long = 5
Private Const FLOW_MAX_AGGREGATE_TRANSACTIONS As Long = 12
Private Const FLOW_CONTEXT_NEIGHBORS As Long = 8
Private Const FLOW_MAX_MULTI_BUNDLES_PER_SIDE As Long = 100000
Private Const FLOW_MAX_BUNDLES_PER_SIDE As Long = 300000
Private Const FLOW_MAX_LINKS As Long = 200000
Private Const FLOW_MAX_CHAIN_LEGS As Long = 6
Private Const FLOW_MAX_COMBINATION_OPERATIONS As Long = 5000000
Private Const FLOW_MAX_TARGET_PAIR_OPERATIONS As Long = 5000000
Private Const FLOW_MAX_MATCH_OPERATIONS As Long = 5000000
Private Const FLOW_MAX_ADJACENCY_OPERATIONS As Long = 5000000
Private Const FLOW_MAX_TERMINAL_OPERATIONS As Long = 3000000
Private Const FLOW_MAX_ORIGIN_OPERATIONS As Long = 3000000
Private Const FLOW_MAX_LONG_AGGREGATE_OPERATIONS As Long = 2000000
Private Const FLOW_DETAIL_MAX_CHARS As Long = 30000

Private Type FlowBundle
    RowList As String
    IdList As String
    AccountList As String
    TotalAmount As Double
    ItemCount As Long
    MinDate As Long
    MaxDate As Long
    MinStamp As Double
    MaxStamp As Double
    HasAnyTime As Boolean
    HasAllTimes As Boolean
End Type

Private Type FlowLink
    WithdrawalBundle As Long
    DepositBundle As Long
    DifferenceAmount As Double
    Score As Long
    Rating As String
    Chronology As String
    TimePrecision As String
    PeriodText As String
    KeyText As String
End Type

Private Type FlowRecord
    KindCode As Long       '1=�����ƍ��A2=�A���A3=�I�[�o���A4=����A5�`7=�����N�_�̊e�A��
    LinkList As String
    ExtraWithdrawalRows As String
    OriginDepositBundle As Long
    Score As Long
    Rating As String
    KeyText As String
End Type

Public Function AdvancedFlowAnalysisHeaders() As Variant
    AdvancedFlowAnalysisHeaders = Array( _
        "�]��", "�X�R�A", "���͎��", "��������", "�������x", "����", "�i�K��", "�����", _
        "�N�_�z", "�ǐՏI�[�z", "�N�I�_��", "���莑���o�H", "��������", "�o������", _
        "��������", "���藝�R", "�m�F��", "�m�F����", "�m�F�L�[", "�\�����ID", _
        "�N�_����ID", "�I�_����ID")
End Function

Public Sub BuildAdvancedFlowAnalysisSheetCore( _
        ByRef sourceData As Variant, ByVal sourceRowCount As Long, _
        ByRef withdrawalRows() As Long, ByVal withdrawalCount As Long, _
        ByRef depositRows() As Long, ByVal depositCount As Long, _
        ByRef componentWithdrawalRows() As Long, ByVal componentWithdrawalCount As Long, _
        ByRef componentDepositRows() As Long, ByVal componentDepositCount As Long, _
        ByVal dayWindow As Long, ByVal absoluteTolerance As Double, _
        ByVal rateTolerance As Double, ByVal settingsSignature As String, _
        ByVal wsOut As Worksheet, ByVal reviews As Object, _
        ByVal candidateCountByTx As Object, ByVal bestScoreByTx As Object, _
        ByVal bestRatingByTx As Object, ByRef writtenCount As Long)
    Dim withdrawalBundles() As FlowBundle, depositBundles() As FlowBundle
    Dim links() As FlowLink, records() As FlowRecord
    Dim withdrawalBundleCount As Long, depositBundleCount As Long
    Dim linkCount As Long, recordCount As Long
    Dim seenRecords As Object

    If wsOut Is Nothing Then _
        Err.Raise vbObjectError + 4700, "BuildAdvancedFlowAnalysisSheetCore", _
                  "�����t���[�ǐՂ̏o�͐悪����܂���B"
    Set seenRecords = CreateObject("Scripting.Dictionary")
    seenRecords.CompareMode = vbTextCompare

    If sourceRowCount > 0 Then
        If withdrawalCount > 0 Or (componentWithdrawalCount >= 2 And depositCount > 0) Then _
            BuildFlowBundles sourceData, withdrawalRows, withdrawalCount, False, dayWindow, _
                             componentWithdrawalRows, componentWithdrawalCount, depositRows, _
                             depositCount, absoluteTolerance, rateTolerance, withdrawalBundles, _
                             withdrawalBundleCount
        If depositCount > 0 Or (componentDepositCount >= 2 And withdrawalCount > 0) Then _
            BuildFlowBundles sourceData, depositRows, depositCount, True, dayWindow, _
                             componentDepositRows, componentDepositCount, withdrawalRows, _
                             withdrawalCount, absoluteTolerance, rateTolerance, depositBundles, _
                             depositBundleCount
        If withdrawalBundleCount > 0 And depositBundleCount > 0 Then
            BuildFlowLinks sourceData, withdrawalBundles, withdrawalBundleCount, _
                           depositBundles, depositBundleCount, dayWindow, absoluteTolerance, _
                           rateTolerance, links, linkCount, records, recordCount, seenRecords
        End If
        If linkCount > 0 Then
            BuildFlowChains sourceData, withdrawalBundles, withdrawalBundleCount, _
                            depositBundles, links, linkCount, dayWindow, absoluteTolerance, _
                            rateTolerance, records, recordCount, seenRecords
            BuildDepositOriginFlowRecords sourceData, withdrawalBundles, depositBundles, _
                                          depositBundleCount, links, linkCount, dayWindow, _
                                          absoluteTolerance, rateTolerance, records, recordCount, _
                                          seenRecords
        End If
    End If

    If recordCount > MAX_ANALYSIS_OUTPUT_ROWS Then _
        Err.Raise vbObjectError + 4701, "BuildAdvancedFlowAnalysisSheetCore", _
                  "�����t���[�ǐՌ�₪���p����i" & _
                  Format$(MAX_ANALYSIS_OUTPUT_ROWS, "#,##0") & "���j�𒴂��܂��B" & _
                  "�Œ���z���グ�邩�A�������E���z�����e�����߂Ă��������B"

    UpdateFlowCandidateStats sourceData, withdrawalBundles, depositBundles, links, _
                             records, recordCount, candidateCountByTx, bestScoreByTx, bestRatingByTx
    PrepareAdvancedFlowAnalysisSheet wsOut
    If recordCount > 0 Then
        WriteAdvancedFlowAnalysis sourceData, withdrawalBundles, depositBundles, links, _
                                  records, recordCount, reviews, settingsSignature, _
                                  candidateCountByTx, wsOut, writtenCount
    End If
    If writtenCount <> recordCount Then _
        Err.Raise vbObjectError + 4702, "BuildAdvancedFlowAnalysisSheetCore", _
                  "�����t���[�ǐՂ̎��O�����Əo�͌�������v���܂���B"
    FinalizeAdvancedFlowAnalysisSheet wsOut, recordCount
End Sub

Public Sub PrepareAdvancedFlowAnalysisSheet(ByVal ws As Worksheet)
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    If ws Is Nothing Then Exit Sub
    On Error GoTo EH
    ws.Unprotect Password:=TOOL_PASSWORD
    If ws.AutoFilterMode Then ws.AutoFilterMode = False
    ResetWorksheet ws
    SetRowValues ws.Range("A1"), AdvancedFlowAnalysisHeaders()
    FormatOutputHeader ws.Range(ws.Cells(1, 1), ws.Cells(1, FLOW_ANALYSIS_LAST_COL))
    ws.Columns("A:V").NumberFormatLocal = "@"
    ws.Columns("B:B").NumberFormatLocal = "0"
    ws.Columns("G:H").NumberFormatLocal = "0"
    ws.Columns("I:K").NumberFormatLocal = "#,##0.########"
    ApplyAdvancedFlowColumnWidths ws
    ws.Columns("S:V").Hidden = True
    ProtectSingleAnalysisSheet ws
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    On Error Resume Next
    EmergencyProtectToolSheet ws
    On Error GoTo 0
    Err.Raise errorNumber, "PrepareAdvancedFlowAnalysisSheet", errorSource & " / " & errorDescription
End Sub

Public Sub FinalizeAdvancedFlowAnalysisSheet(ByVal ws As Worksheet, ByVal dataCount As Long)
    Dim lastR As Long
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    If ws Is Nothing Then Exit Sub
    On Error GoTo EH
    ws.Unprotect Password:=TOOL_PASSWORD
    lastR = dataCount + 1
    FormatOutputHeader ws.Range(ws.Cells(1, 1), ws.Cells(1, FLOW_ANALYSIS_LAST_COL))
    If dataCount > 1 Then SortAdvancedFlowAnalysis ws, lastR
    ApplyAdvancedFlowColumnWidths ws
    ws.Columns("S:V").Hidden = True
    If dataCount > 0 Then
        With ws.Range(ws.Cells(2, 1), ws.Cells(lastR, FLOW_ANALYSIS_LAST_COL))
            .VerticalAlignment = xlTop
            .WrapText = False
        End With
        If dataCount <= 10000 Then
            With ws.Range(ws.Cells(2, 1), ws.Cells(lastR, FLOW_ANALYSIS_LAST_COL)).Borders
                .Color = RGB(226, 232, 240)
                .LineStyle = xlContinuous
            End With
        End If
        ws.Range(ws.Cells(2, 12), ws.Cells(lastR, 18)).WrapText = True
        ws.Range(ws.Cells(2, FLOW_ANALYSIS_STATUS_COL), _
                 ws.Cells(lastR, FLOW_ANALYSIS_MEMO_COL)).Interior.Color = RGB(254, 249, 195)
        ws.Rows("2:" & CStr(lastR)).RowHeight = 54
    End If
    If ws.AutoFilterMode Then ws.AutoFilterMode = False
    ws.Range(ws.Cells(1, 1), ws.Cells(lastR, FLOW_ANALYSIS_LAST_COL)).AutoFilter
    ApplyAnalysisReviewValidation ws, FLOW_ANALYSIS_STATUS_COL, FLOW_ANALYSIS_MEMO_COL, lastR
    SafeFreezeOutputHeader ws
    ProtectSingleAnalysisSheet ws
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    On Error Resume Next
    EmergencyProtectToolSheet ws
    On Error GoTo 0
    Err.Raise errorNumber, "FinalizeAdvancedFlowAnalysisSheet", errorSource & " / " & errorDescription
End Sub

Private Sub ApplyAdvancedFlowColumnWidths(ByVal ws As Worksheet)
    ws.Columns("A:B").ColumnWidth = 8
    ws.Columns("C:C").ColumnWidth = 24
    ws.Columns("D:F").ColumnWidth = 22
    ws.Columns("G:H").ColumnWidth = 10
    ws.Columns("I:K").ColumnWidth = 16
    ws.Columns("L:L").ColumnWidth = 46
    ws.Columns("M:O").ColumnWidth = 58
    ws.Columns("P:P").ColumnWidth = 60
    ws.Columns("Q:Q").ColumnWidth = 16
    ws.Columns("R:R").ColumnWidth = 38
End Sub

Private Sub SortAdvancedFlowAnalysis(ByVal ws As Worksheet, ByVal lastR As Long)
    With ws.Sort
        .SortFields.Clear
        .SortFields.Add Key:=ws.Range(ws.Cells(2, 2), ws.Cells(lastR, 2)), _
                        SortOn:=xlSortOnValues, Order:=xlDescending, DataOption:=xlSortNormal
        .SortFields.Add Key:=ws.Range(ws.Cells(2, 3), ws.Cells(lastR, 3)), _
                        SortOn:=xlSortOnValues, Order:=xlAscending, DataOption:=xlSortNormal
        .SetRange ws.Range(ws.Cells(1, 1), ws.Cells(lastR, FLOW_ANALYSIS_LAST_COL))
        .Header = xlYes
        .Apply
    End With
End Sub

Private Sub BuildFlowBundles(ByRef sourceData As Variant, ByRef sourceRows() As Long, _
                             ByVal sourceCount As Long, ByVal isDeposit As Boolean, _
                             ByVal dayWindow As Long, ByRef componentRows() As Long, _
                             ByVal componentCount As Long, ByRef targetRows() As Long, _
                             ByVal targetCount As Long, ByVal absoluteTolerance As Double, _
                             ByVal rateTolerance As Double, ByRef bundles() As FlowBundle, _
                             ByRef bundleCount As Long)
    Dim seen As Object
    Dim i As Long, multiCount As Long, operationCount As Long, longOperationCount As Long
    Dim selectedRows(1 To FLOW_MAX_SIDE_TRANSACTIONS) As Long
    Set seen = CreateObject("Scripting.Dictionary")
    seen.CompareMode = vbTextCompare

    For i = 1 To sourceCount
        selectedRows(1) = sourceRows(i)
        AddSelectedFlowBundle sourceData, selectedRows, 1, isDeposit, dayWindow, _
                              bundles, bundleCount, multiCount, seen
    Next i
    If sourceCount >= 2 Then
        '���P�ʁA�����P�ʁA�l���P�ʂɉ����A���������z���ɂ����ׂċߐڑg���������B
        '����̑�������ł����͏������Ɉˑ������A�����\����ID�ŏ��d������B
        GenerateFlowBundlesByContext sourceData, sourceRows, sourceCount, isDeposit, dayWindow, 1, _
                                     bundles, bundleCount, multiCount, seen, operationCount
        GenerateFlowBundlesByContext sourceData, sourceRows, sourceCount, isDeposit, dayWindow, 2, _
                                     bundles, bundleCount, multiCount, seen, operationCount
        GenerateFlowBundlesByContext sourceData, sourceRows, sourceCount, isDeposit, dayWindow, 3, _
                                     bundles, bundleCount, multiCount, seen, operationCount
        GenerateFlowBundlesByContext sourceData, sourceRows, sourceCount, isDeposit, dayWindow, 4, _
                                     bundles, bundleCount, multiCount, seen, operationCount
        '6���ȏ�̕����E���Z�͑S�g�����ɂ����A��������E����l���̎��n����
        '�A���������������ő�12���܂ő��˂�B�w���I����������A�����������E���B
        GenerateLongSequentialBundlesByContext sourceData, sourceRows, sourceCount, isDeposit, _
                                               dayWindow, 2, bundles, bundleCount, multiCount, _
                                               seen, longOperationCount
        GenerateLongSequentialBundlesByContext sourceData, sourceRows, sourceCount, isDeposit, _
                                               dayWindow, 3, bundles, bundleCount, multiCount, _
                                               seen, longOperationCount
    End If
    If componentCount >= 2 And targetCount > 0 Then _
        GenerateTargetAwarePairBundles sourceData, componentRows, componentCount, targetRows, _
                                       targetCount, isDeposit, dayWindow, absoluteTolerance, _
                                       rateTolerance, bundles, bundleCount, multiCount, seen
End Sub

Private Sub GenerateLongSequentialBundlesByContext( _
        ByRef sourceData As Variant, ByRef sourceRows() As Long, ByVal sourceCount As Long, _
        ByVal isDeposit As Boolean, ByVal dayWindow As Long, ByVal contextMode As Long, _
        ByRef bundles() As FlowBundle, ByRef bundleCount As Long, ByRef multiCount As Long, _
        ByVal seen As Object, ByRef operationCount As Long)
    Dim contextRows() As Long, contextKeys() As String, contextStamps() As Double
    Dim selectedRows(1 To FLOW_MAX_AGGREGATE_TRANSACTIONS) As Long
    Dim i As Long, groupStart As Long, groupEnd As Long
    Dim firstPos As Long, lastPos As Long, selectedCount As Long
    ReDim contextRows(1 To sourceCount)
    ReDim contextKeys(1 To sourceCount)
    ReDim contextStamps(1 To sourceCount)
    For i = 1 To sourceCount
        contextRows(i) = sourceRows(i)
        contextKeys(i) = FlowContextKey(sourceData, sourceRows(i), contextMode)
        contextStamps(i) = FlowSortStamp(sourceData, sourceRows(i))
    Next i
    If sourceCount > 1 Then _
        QuickSortFlowContext contextKeys, contextStamps, contextRows, 1, sourceCount
    groupStart = 1
    Do While groupStart <= sourceCount
        groupEnd = groupStart
        Do While groupEnd < sourceCount
            If StrComp(contextKeys(groupEnd + 1), contextKeys(groupStart), vbBinaryCompare) <> 0 Then Exit Do
            groupEnd = groupEnd + 1
        Loop
        If groupEnd - groupStart + 1 > FLOW_MAX_SIDE_TRANSACTIONS And _
           Left$(contextKeys(groupStart), 2) <> "U|" Then
            For firstPos = groupStart To groupEnd - FLOW_MAX_SIDE_TRANSACTIONS
                selectedCount = 0
                For lastPos = firstPos To groupEnd
                    selectedCount = selectedCount + 1
                    If selectedCount > FLOW_MAX_AGGREGATE_TRANSACTIONS Then Exit For
                    selectedRows(selectedCount) = contextRows(lastPos)
                    If selectedCount > FLOW_MAX_SIDE_TRANSACTIONS Then
                        operationCount = operationCount + 1
                        If operationCount Mod 8192 = 0 Then _
                            AppProgress "���������E���Z�̘A�������T�����Ă��܂�...", operationCount, _
                                        FLOW_MAX_LONG_AGGREGATE_OPERATIONS
                        If operationCount > FLOW_MAX_LONG_AGGREGATE_OPERATIONS Then _
                            Err.Raise vbObjectError + 4713, "GenerateLongSequentialBundlesByContext", _
                                      "���������E���Z�̘A������T�������p����𒴂��܂����B" & _
                                      "�Œ���z���グ�邩�A���͑Ώۂ𕪂��Ă��������B"
                        AddSelectedFlowBundle sourceData, selectedRows, selectedCount, isDeposit, _
                                              dayWindow, bundles, bundleCount, multiCount, seen
                    End If
                Next lastPos
            Next firstPos
        End If
        groupStart = groupEnd + 1
    Loop
End Sub

Private Sub GenerateTargetAwarePairBundles( _
        ByRef sourceData As Variant, ByRef componentRows() As Long, ByVal componentCount As Long, _
        ByRef targetRows() As Long, ByVal targetCount As Long, ByVal isDeposit As Boolean, _
        ByVal dayWindow As Long, ByVal absoluteTolerance As Double, ByVal rateTolerance As Double, _
        ByRef bundles() As FlowBundle, ByRef bundleCount As Long, ByRef multiCount As Long, _
        ByVal seen As Object)
    Dim dateBuckets As Object, bucket As Collection
    Dim candidateAmounts() As Double, candidateRows() As Long
    Dim targetDates() As Double, targetOrder() As Long
    Dim selectedRows(1 To FLOW_MAX_SIDE_TRANSACTIONS) As Long
    Dim i As Long, j As Long, targetIndex As Long, candidateCount As Long
    Dim firstMatch As Long, lastMatch As Long, componentRow As Long, targetRow As Long
    Dim targetDate As Long, cachedTargetDate As Long, dateCursor As Long, operationCount As Long
    Dim hasCandidateCache As Boolean
    Dim targetAmount As Double, totalAmount As Double, lowerAmount As Double, upperAmount As Double
    Dim complementLower As Double, complementUpper As Double, differenceAmount As Double
    Dim dateKey As String, rowItem As Variant
    Set dateBuckets = CreateObject("Scripting.Dictionary")
    dateBuckets.CompareMode = vbBinaryCompare
    ReDim candidateAmounts(1 To componentCount)
    ReDim candidateRows(1 To componentCount)
    ReDim targetDates(1 To targetCount)
    ReDim targetOrder(1 To targetCount)

    For i = 1 To componentCount
        componentRow = componentRows(i)
        dateKey = CStr(CLng(VBA.DateValue(CDate(sourceData(componentRow, OUT_COL_DATE)))))
        If dateBuckets.Exists(dateKey) Then
            Set bucket = dateBuckets(dateKey)
        Else
            Set bucket = New Collection
            dateBuckets.Add dateKey, bucket
        End If
        bucket.Add componentRow
    Next i

    '�������̖ڕW����͌����t��������ɂȂ邽�߁A���t���ɂ܂Ƃ߂Č��z��ƕ��בւ����ė��p����B
    For i = 1 To targetCount
        targetOrder(i) = targetRows(i)
        targetDates(i) = CDbl(CLng(VBA.DateValue(CDate(sourceData(targetRows(i), OUT_COL_DATE)))))
    Next i
    If targetCount > 1 Then QuickSortFlowAmounts targetDates, targetOrder, 1, targetCount

    For targetIndex = 1 To targetCount
        targetRow = targetOrder(targetIndex)
        targetDate = CLng(targetDates(targetIndex))
        If isDeposit Then
            targetAmount = CDbl(sourceData(targetRow, OUT_COL_WITHDRAW))
        Else
            targetAmount = CDbl(sourceData(targetRow, OUT_COL_DEPOSIT))
        End If
        FlowAmountSearchBounds targetAmount, absoluteTolerance, rateTolerance, lowerAmount, upperAmount
        If Not hasCandidateCache Or targetDate <> cachedTargetDate Then
            candidateCount = 0
            For dateCursor = targetDate - dayWindow To targetDate + dayWindow
                dateKey = CStr(dateCursor)
                If dateBuckets.Exists(dateKey) Then
                    Set bucket = dateBuckets(dateKey)
                    For Each rowItem In bucket
                        operationCount = operationCount + 1
                        If operationCount Mod 8192 = 0 Then _
                            AppProgress "�ڕW�z���畡�������T�����Ă��܂�...", operationCount, _
                                        FLOW_MAX_TARGET_PAIR_OPERATIONS
                        If operationCount > FLOW_MAX_TARGET_PAIR_OPERATIONS Then _
                            Err.Raise vbObjectError + 4712, "GenerateTargetAwarePairBundles", _
                                      "�ڕW�z����̕�������T�������p����𒴂��܂����B" & _
                                      "�Œ���z���グ�邩�A�������E���z�����e�����߂Ă��������B"
                        candidateCount = candidateCount + 1
                        componentRow = CLng(rowItem)
                        candidateRows(candidateCount) = componentRow
                        If isDeposit Then
                            candidateAmounts(candidateCount) = CDbl(sourceData(componentRow, OUT_COL_DEPOSIT))
                        Else
                            candidateAmounts(candidateCount) = CDbl(sourceData(componentRow, OUT_COL_WITHDRAW))
                        End If
                    Next rowItem
                End If
            Next dateCursor
            If candidateCount >= 2 Then _
                QuickSortFlowAmounts candidateAmounts, candidateRows, 1, candidateCount
            cachedTargetDate = targetDate
            hasCandidateCache = True
        End If
        If candidateCount >= 2 Then
            For i = 1 To candidateCount - 1
                If candidateAmounts(i) > upperAmount Then Exit For
                complementLower = lowerAmount - candidateAmounts(i)
                complementUpper = upperAmount - candidateAmounts(i)
                firstMatch = LowerBoundFlowAmount(candidateAmounts, candidateCount, complementLower)
                If firstMatch <= i Then firstMatch = i + 1
                lastMatch = UpperBoundFlowAmount(candidateAmounts, candidateCount, complementUpper)
                If firstMatch <= lastMatch Then
                    For j = firstMatch To lastMatch
                        operationCount = operationCount + 1
                        If operationCount Mod 8192 = 0 Then _
                            AppProgress "�ڕW�z�̑g�������ƍ����Ă��܂�...", operationCount, _
                                        FLOW_MAX_TARGET_PAIR_OPERATIONS
                        If operationCount > FLOW_MAX_TARGET_PAIR_OPERATIONS Then _
                            Err.Raise vbObjectError + 4712, "GenerateTargetAwarePairBundles", _
                                      "�ڕW�z����̕�������T�������p����𒴂��܂����B" & _
                                      "�Œ���z���グ�邩�A�������E���z�����e�����߂Ă��������B"
                        totalAmount = candidateAmounts(i) + candidateAmounts(j)
                        differenceAmount = Abs(targetAmount - totalAmount)
                        If differenceAmount <= FlowAllowedDifference(targetAmount, totalAmount, _
                                absoluteTolerance, rateTolerance) + 0.0000001 Then
                            selectedRows(1) = candidateRows(i)
                            selectedRows(2) = candidateRows(j)
                            AddSelectedFlowBundle sourceData, selectedRows, 2, isDeposit, dayWindow, _
                                                  bundles, bundleCount, multiCount, seen
                        End If
                    Next j
                End If
            Next i
        End If
    Next targetIndex
End Sub

Private Sub GenerateFlowBundlesByContext( _
        ByRef sourceData As Variant, ByRef sourceRows() As Long, ByVal sourceCount As Long, _
        ByVal isDeposit As Boolean, ByVal dayWindow As Long, ByVal contextMode As Long, _
        ByRef bundles() As FlowBundle, ByRef bundleCount As Long, ByRef multiCount As Long, _
        ByVal seen As Object, ByRef operationCount As Long)
    Dim contextRows() As Long, contextKeys() As String, contextStamps() As Double
    Dim i As Long, groupStart As Long, groupEnd As Long
    ReDim contextRows(1 To sourceCount)
    ReDim contextKeys(1 To sourceCount)
    ReDim contextStamps(1 To sourceCount)
    For i = 1 To sourceCount
        contextRows(i) = sourceRows(i)
        contextKeys(i) = FlowContextKey(sourceData, sourceRows(i), contextMode)
        contextStamps(i) = FlowContextSortValue(sourceData, sourceRows(i), contextMode, isDeposit)
    Next i
    If sourceCount > 1 Then _
        QuickSortFlowContext contextKeys, contextStamps, contextRows, 1, sourceCount

    groupStart = 1
    Do While groupStart <= sourceCount
        groupEnd = groupStart
        Do While groupEnd < sourceCount
            If StrComp(contextKeys(groupEnd + 1), contextKeys(groupStart), vbBinaryCompare) <> 0 Then Exit Do
            groupEnd = groupEnd + 1
        Loop
        If groupEnd > groupStart And Left$(contextKeys(groupStart), 2) <> "U|" Then
            GenerateContextCombinations sourceData, contextRows, groupStart, groupEnd, isDeposit, _
                                        dayWindow, bundles, bundleCount, multiCount, seen, operationCount
        End If
        groupStart = groupEnd + 1
    Loop
End Sub

Private Function FlowContextKey(ByRef sourceData As Variant, ByVal sourceRow As Long, _
                                ByVal contextMode As Long) As String
    Dim dateKey As String, identityKey As String
    dateKey = CStr(CLng(VBA.DateValue(CDate(sourceData(sourceRow, OUT_COL_DATE)))))
    Select Case contextMode
        Case 1
            FlowContextKey = "D|" & dateKey
        Case 2
            FlowContextKey = "A|" & UCase$(CellText(sourceData(sourceRow, WORK_TX_COL_ACCOUNT_ID)))
        Case 3
            identityKey = CellText(sourceData(sourceRow, WORK_TX_COL_PERSON_ID))
            If Len(identityKey) = 0 Then _
                identityKey = NormalizePersonNameKey(CellText(sourceData(sourceRow, OUT_COL_PERSON)))
            If Len(identityKey) = 0 Then
                FlowContextKey = "U|" & CStr(sourceRow)
            Else
                FlowContextKey = "P|" & UCase$(identityKey)
            End If
        Case Else
            FlowContextKey = "M|" & dateKey
    End Select
End Function

Private Function FlowContextSortValue(ByRef sourceData As Variant, ByVal sourceRow As Long, _
                                      ByVal contextMode As Long, ByVal isDeposit As Boolean) As Double
    If contextMode = 4 Then
        If isDeposit Then
            FlowContextSortValue = CDbl(sourceData(sourceRow, OUT_COL_DEPOSIT))
        Else
            FlowContextSortValue = CDbl(sourceData(sourceRow, OUT_COL_WITHDRAW))
        End If
    Else
        FlowContextSortValue = FlowSortStamp(sourceData, sourceRow)
    End If
End Function

Private Function FlowSortStamp(ByRef sourceData As Variant, ByVal sourceRow As Long) As Double
    Dim timeFraction As Double
    FlowSortStamp = CDbl(VBA.DateValue(CDate(sourceData(sourceRow, OUT_COL_DATE))))
    If TryGetFlowTime(sourceData(sourceRow, OUT_COL_TIME), timeFraction) Then
        FlowSortStamp = FlowSortStamp + timeFraction
    Else
        '�����Ȃ��͓����̒����֒u���B�����̒f��ɂ͎g�킸�A�ߐڒT�������������肳����B
        FlowSortStamp = FlowSortStamp + 0.5
    End If
End Function

Private Sub GenerateContextCombinations( _
        ByRef sourceData As Variant, ByRef contextRows() As Long, _
        ByVal groupStart As Long, ByVal groupEnd As Long, ByVal isDeposit As Boolean, _
        ByVal dayWindow As Long, ByRef bundles() As FlowBundle, ByRef bundleCount As Long, _
        ByRef multiCount As Long, ByVal seen As Object, ByRef operationCount As Long)
    Dim firstPos As Long, maxPos As Long
    Dim selectedRows(1 To FLOW_MAX_SIDE_TRANSACTIONS) As Long
    For firstPos = groupStart To groupEnd - 1
        selectedRows(1) = contextRows(firstPos)
        maxPos = firstPos + FLOW_CONTEXT_NEIGHBORS - 1
        If maxPos > groupEnd Then maxPos = groupEnd
        ExtendContextCombination sourceData, contextRows, firstPos + 1, maxPos, selectedRows, 1, _
                                 isDeposit, dayWindow, bundles, bundleCount, multiCount, seen, operationCount
    Next firstPos
End Sub

Private Sub ExtendContextCombination( _
        ByRef sourceData As Variant, ByRef contextRows() As Long, ByVal nextPos As Long, _
        ByVal maxPos As Long, ByRef selectedRows() As Long, ByVal selectedCount As Long, _
        ByVal isDeposit As Boolean, ByVal dayWindow As Long, ByRef bundles() As FlowBundle, _
        ByRef bundleCount As Long, ByRef multiCount As Long, ByVal seen As Object, _
        ByRef operationCount As Long)
    Dim pos As Long, newCount As Long
    For pos = nextPos To maxPos
        operationCount = operationCount + 1
        If operationCount Mod 8192 = 0 Then _
            AppProgress "�ߐڎ���̑g������T�����Ă��܂�...", operationCount, _
                        FLOW_MAX_COMBINATION_OPERATIONS
        If operationCount > FLOW_MAX_COMBINATION_OPERATIONS Then _
            Err.Raise vbObjectError + 4703, "ExtendContextCombination", _
                      "��������̑g�����T�������p����𒴂��܂����B" & _
                      "���͑Ώۂ̍Œ���z���グ�邩�A�Ώێ���𕪂��Ă��������B"
        newCount = selectedCount + 1
        selectedRows(newCount) = contextRows(pos)
        AddSelectedFlowBundle sourceData, selectedRows, newCount, isDeposit, dayWindow, _
                              bundles, bundleCount, multiCount, seen
        If newCount < FLOW_MAX_SIDE_TRANSACTIONS And pos < maxPos Then
            ExtendContextCombination sourceData, contextRows, pos + 1, maxPos, selectedRows, newCount, _
                                     isDeposit, dayWindow, bundles, bundleCount, multiCount, seen, operationCount
        End If
    Next pos
End Sub

Private Sub AddSelectedFlowBundle( _
        ByRef sourceData As Variant, ByRef selectedRows() As Long, ByVal selectedCount As Long, _
        ByVal isDeposit As Boolean, ByVal dayWindow As Long, ByRef bundles() As FlowBundle, _
        ByRef bundleCount As Long, ByRef multiCount As Long, ByVal seen As Object)
    Dim rowValues(1 To FLOW_MAX_AGGREGATE_TRANSACTIONS) As Long
    Dim idValues(1 To FLOW_MAX_AGGREGATE_TRANSACTIONS) As String
    Dim accountValues(1 To FLOW_MAX_AGGREGATE_TRANSACTIONS) As String
    Dim uniqueAccounts As Object
    Dim i As Long, sourceRow As Long, accountCount As Long
    Dim rowList As String, idList As String, accountList As String, keyText As String
    Dim totalAmount As Double, minDate As Long, maxDate As Long, transactionDateSerial As Long
    Dim timeFraction As Double, hasTime As Boolean
    Dim anyTime As Boolean, allTimes As Boolean
    Set uniqueAccounts = CreateObject("Scripting.Dictionary")
    uniqueAccounts.CompareMode = vbTextCompare
    allTimes = True

    For i = 1 To selectedCount
        sourceRow = selectedRows(i)
        rowValues(i) = sourceRow
        idValues(i) = CellText(sourceData(sourceRow, WORK_TX_COL_TRANSACTION_ID))
        If Len(idValues(i)) = 0 Then Exit Sub
        If isDeposit Then
            totalAmount = totalAmount + CDbl(sourceData(sourceRow, OUT_COL_DEPOSIT))
        Else
            totalAmount = totalAmount + CDbl(sourceData(sourceRow, OUT_COL_WITHDRAW))
        End If
        transactionDateSerial = CLng(VBA.DateValue(CDate(sourceData(sourceRow, OUT_COL_DATE))))
        If i = 1 Or transactionDateSerial < minDate Then minDate = transactionDateSerial
        If i = 1 Or transactionDateSerial > maxDate Then maxDate = transactionDateSerial
        hasTime = TryGetFlowTime(sourceData(sourceRow, OUT_COL_TIME), timeFraction)
        If hasTime Then
            anyTime = True
        Else
            allTimes = False
        End If
        accountValues(i) = CellText(sourceData(sourceRow, WORK_TX_COL_ACCOUNT_ID))
        If Len(accountValues(i)) = 0 Then Exit Sub
        If Not uniqueAccounts.Exists(accountValues(i)) Then uniqueAccounts.Add accountValues(i), True
    Next i
    If selectedCount > 1 And maxDate - minDate > dayWindow Then Exit Sub
    If totalAmount <= 0 Then Exit Sub

    SortLongValues rowValues, selectedCount
    SortTextValues idValues, selectedCount
    rowList = JoinLongValues(rowValues, selectedCount)
    idList = JoinTextValues(idValues, selectedCount)
    accountCount = DictionaryKeysToSortedArray(uniqueAccounts, accountValues)
    accountList = JoinTextValues(accountValues, accountCount)
    keyText = CStr(selectedCount) & ":" & idList
    If seen.Exists(keyText) Then Exit Sub

    If selectedCount > 1 Then
        multiCount = multiCount + 1
        If multiCount > FLOW_MAX_MULTI_BUNDLES_PER_SIDE Then _
            Err.Raise vbObjectError + 4704, "AddSelectedFlowBundle", _
                      "��������̑����Б�" & Format$(FLOW_MAX_MULTI_BUNDLES_PER_SIDE, "#,##0") & _
                      "���𒴂��܂����B�Œ���z���グ�邩�A�Ώێ���𕪂��Ă��������B"
    End If
    EnsureFlowBundleCapacity bundles, bundleCount + 1
    bundleCount = bundleCount + 1
    With bundles(bundleCount)
        .RowList = rowList
        .IdList = idList
        .AccountList = accountList
        .TotalAmount = totalAmount
        .ItemCount = selectedCount
        .MinDate = minDate
        .MaxDate = maxDate
        .HasAnyTime = anyTime
        .HasAllTimes = allTimes
    End With
    SetFlowBundleStampBounds sourceData, bundles(bundleCount)
    seen.Add keyText, bundleCount
End Sub

Private Sub SetFlowBundleStampBounds(ByRef sourceData As Variant, ByRef bundle As FlowBundle)
    Dim rowParts As Variant, item As Variant
    Dim sourceRow As Long, timeFraction As Double, stampValue As Double
    Dim firstValue As Boolean
    firstValue = True
    rowParts = Split(bundle.RowList, ";")
    For Each item In rowParts
        sourceRow = CLng(item)
        stampValue = CDbl(VBA.DateValue(CDate(sourceData(sourceRow, OUT_COL_DATE))))
        If TryGetFlowTime(sourceData(sourceRow, OUT_COL_TIME), timeFraction) Then _
            stampValue = stampValue + timeFraction
        If firstValue Or stampValue < bundle.MinStamp Then bundle.MinStamp = stampValue
        If firstValue Or stampValue > bundle.MaxStamp Then bundle.MaxStamp = stampValue
        firstValue = False
    Next item
End Sub

Private Sub EnsureFlowBundleCapacity(ByRef bundles() As FlowBundle, ByVal requiredCount As Long)
    Dim newCapacity As Long
    If requiredCount > FLOW_MAX_BUNDLES_PER_SIDE Then _
        Err.Raise vbObjectError + 4710, "EnsureFlowBundleCapacity", _
                  "�����t���[�̎�������Б�" & _
                  Format$(FLOW_MAX_BUNDLES_PER_SIDE, "#,##0") & _
                  "���𒴂��܂����B�Œ���z���グ�邩�A���͑Ώۂ𕪂��Ă��������B"
    If requiredCount <= 1 Then
        ReDim bundles(1 To 1024)
    ElseIf requiredCount > UBound(bundles) Then
        newCapacity = UBound(bundles) * 2
        If newCapacity < requiredCount Then newCapacity = requiredCount
        If newCapacity > FLOW_MAX_BUNDLES_PER_SIDE Then newCapacity = FLOW_MAX_BUNDLES_PER_SIDE
        ReDim Preserve bundles(1 To newCapacity)
    End If
End Sub

Private Sub QuickSortFlowContext(ByRef keys() As String, ByRef stamps() As Double, _
                                 ByRef rows() As Long, ByVal firstIndex As Long, _
                                 ByVal lastIndex As Long)
    Dim low As Long, high As Long, pivotIndex As Long
    Dim pivotKey As String, pivotStamp As Double, pivotRow As Long
    Dim tempKey As String, tempStamp As Double, tempRow As Long
    low = firstIndex
    high = lastIndex
    pivotIndex = (firstIndex + lastIndex) \ 2
    pivotKey = keys(pivotIndex)
    pivotStamp = stamps(pivotIndex)
    pivotRow = rows(pivotIndex)
    Do While low <= high
        Do While CompareFlowContext(keys(low), stamps(low), rows(low), _
                                    pivotKey, pivotStamp, pivotRow) < 0
            low = low + 1
        Loop
        Do While CompareFlowContext(keys(high), stamps(high), rows(high), _
                                    pivotKey, pivotStamp, pivotRow) > 0
            high = high - 1
        Loop
        If low <= high Then
            tempKey = keys(low): keys(low) = keys(high): keys(high) = tempKey
            tempStamp = stamps(low): stamps(low) = stamps(high): stamps(high) = tempStamp
            tempRow = rows(low): rows(low) = rows(high): rows(high) = tempRow
            low = low + 1
            high = high - 1
        End If
    Loop
    If firstIndex < high Then QuickSortFlowContext keys, stamps, rows, firstIndex, high
    If low < lastIndex Then QuickSortFlowContext keys, stamps, rows, low, lastIndex
End Sub

Private Function CompareFlowContext(ByVal firstKey As String, ByVal firstStamp As Double, _
                                    ByVal firstRow As Long, ByVal secondKey As String, _
                                    ByVal secondStamp As Double, ByVal secondRow As Long) As Long
    CompareFlowContext = StrComp(firstKey, secondKey, vbBinaryCompare)
    If CompareFlowContext <> 0 Then Exit Function
    If firstStamp < secondStamp Then
        CompareFlowContext = -1
    ElseIf firstStamp > secondStamp Then
        CompareFlowContext = 1
    ElseIf firstRow < secondRow Then
        CompareFlowContext = -1
    ElseIf firstRow > secondRow Then
        CompareFlowContext = 1
    End If
End Function

Private Sub SortLongValues(ByRef values() As Long, ByVal itemCount As Long)
    Dim i As Long, j As Long, valueToInsert As Long
    For i = 2 To itemCount
        valueToInsert = values(i)
        j = i - 1
        Do While j >= 1
            If values(j) <= valueToInsert Then Exit Do
            values(j + 1) = values(j)
            j = j - 1
        Loop
        values(j + 1) = valueToInsert
    Next i
End Sub

Private Sub SortTextValues(ByRef values() As String, ByVal itemCount As Long)
    Dim i As Long, j As Long, valueToInsert As String
    For i = 2 To itemCount
        valueToInsert = values(i)
        j = i - 1
        Do While j >= 1
            If StrComp(values(j), valueToInsert, vbTextCompare) <= 0 Then Exit Do
            values(j + 1) = values(j)
            j = j - 1
        Loop
        values(j + 1) = valueToInsert
    Next i
End Sub

Private Function JoinLongValues(ByRef values() As Long, ByVal itemCount As Long) As String
    Dim i As Long
    For i = 1 To itemCount
        If i > 1 Then JoinLongValues = JoinLongValues & ";"
        JoinLongValues = JoinLongValues & CStr(values(i))
    Next i
End Function

Private Function JoinTextValues(ByRef values() As String, ByVal itemCount As Long) As String
    Dim i As Long
    For i = 1 To itemCount
        If i > 1 Then JoinTextValues = JoinTextValues & ";"
        JoinTextValues = JoinTextValues & values(i)
    Next i
End Function

Private Function DictionaryKeysToSortedArray(ByVal values As Object, _
                                             ByRef targetValues() As String) As Long
    Dim item As Variant, itemCount As Long
    If values Is Nothing Then Exit Function
    For Each item In values.Keys
        itemCount = itemCount + 1
        targetValues(itemCount) = CStr(item)
    Next item
    If itemCount > 1 Then SortTextValues targetValues, itemCount
    DictionaryKeysToSortedArray = itemCount
End Function

Private Sub BuildFlowLinks( _
        ByRef sourceData As Variant, ByRef withdrawalBundles() As FlowBundle, _
        ByVal withdrawalBundleCount As Long, ByRef depositBundles() As FlowBundle, _
        ByVal depositBundleCount As Long, ByVal dayWindow As Long, _
        ByVal absoluteTolerance As Double, ByVal rateTolerance As Double, _
        ByRef links() As FlowLink, ByRef linkCount As Long, _
        ByRef records() As FlowRecord, ByRef recordCount As Long, ByVal seenRecords As Object)
    Dim depositAmounts() As Double, depositIndexes() As Long
    Dim i As Long, j As Long, firstMatch As Long, lastMatch As Long
    Dim lowerAmount As Double, upperAmount As Double, differenceAmount As Double
    Dim matchOperations As Long
    ReDim depositAmounts(1 To depositBundleCount)
    ReDim depositIndexes(1 To depositBundleCount)
    For i = 1 To depositBundleCount
        depositAmounts(i) = depositBundles(i).TotalAmount
        depositIndexes(i) = i
    Next i
    If depositBundleCount > 1 Then _
        QuickSortFlowAmounts depositAmounts, depositIndexes, 1, depositBundleCount

    For i = 1 To withdrawalBundleCount
        If i Mod 256 = 0 Then _
            AppProgress "��������̋��z���ƍ����Ă��܂�...", i, withdrawalBundleCount
        FlowAmountSearchBounds withdrawalBundles(i).TotalAmount, absoluteTolerance, _
                               rateTolerance, lowerAmount, upperAmount
        firstMatch = LowerBoundFlowAmount(depositAmounts, depositBundleCount, lowerAmount)
        lastMatch = UpperBoundFlowAmount(depositAmounts, depositBundleCount, upperAmount)
        If firstMatch <= lastMatch Then
            For j = firstMatch To lastMatch
                matchOperations = matchOperations + 1
                If matchOperations Mod 8192 = 0 Then _
                    AppProgress "��������̋��z���ƍ����Ă��܂�...", matchOperations, _
                                FLOW_MAX_MATCH_OPERATIONS
                If matchOperations > FLOW_MAX_MATCH_OPERATIONS Then _
                    Err.Raise vbObjectError + 4705, "BuildFlowLinks", _
                              "��������̋��z�ƍ������p����𒴂��܂����B" & _
                              "�Œ���z���グ�邩�A�������E���z�����e�����߂Ă��������B"
                differenceAmount = Abs(withdrawalBundles(i).TotalAmount - _
                                       depositBundles(depositIndexes(j)).TotalAmount)
                If differenceAmount <= FlowAllowedDifference( _
                        withdrawalBundles(i).TotalAmount, depositBundles(depositIndexes(j)).TotalAmount, _
                        absoluteTolerance, rateTolerance) + 0.0000001 Then
                    If FlowBundlesEligible(withdrawalBundles(i), depositBundles(depositIndexes(j)), _
                                           dayWindow) Then
                        AddFlowLink sourceData, withdrawalBundles, depositBundles, i, depositIndexes(j), _
                                    differenceAmount, absoluteTolerance, links, linkCount, _
                                    records, recordCount, seenRecords
                    End If
                End If
            Next j
        End If
    Next i
End Sub

Private Function FlowBundlesEligible(ByRef withdrawalBundle As FlowBundle, _
                                     ByRef depositBundle As FlowBundle, _
                                     ByVal dayWindow As Long) As Boolean
    Dim intervalGap As Long
    '�P��̓�������������Ŋ�������o�����͏��O����B���Ε��œ��������W�����܂ޏꍇ�́A
    '�W�����̕ʌ����Ԉړ������蓾�邽�ߌ��Ƃ��Ďc���B
    If InStr(1, withdrawalBundle.AccountList, ";", vbBinaryCompare) = 0 And _
       StrComp(withdrawalBundle.AccountList, depositBundle.AccountList, vbTextCompare) = 0 Then Exit Function
    '��������̊e���͍쐬���_�œ��������Ɍ���ς݁B���ǂ����͍ł��߂����t�̊Ԋu�Ŕ��肵�A
    '���Ԃ��ꕔ�d�Ȃ镪���E���Z���A�S�̊��Ԃ����𗝗R�ɗ��Ƃ��Ȃ��B
    If withdrawalBundle.MaxDate < depositBundle.MinDate Then
        intervalGap = depositBundle.MinDate - withdrawalBundle.MaxDate
    ElseIf depositBundle.MaxDate < withdrawalBundle.MinDate Then
        intervalGap = withdrawalBundle.MinDate - depositBundle.MaxDate
    End If
    If intervalGap > dayWindow Then Exit Function
    FlowBundlesEligible = True
End Function

Private Sub AddFlowLink( _
        ByRef sourceData As Variant, ByRef withdrawalBundles() As FlowBundle, _
        ByRef depositBundles() As FlowBundle, ByVal withdrawalIndex As Long, _
        ByVal depositIndex As Long, ByVal differenceAmount As Double, _
        ByVal absoluteTolerance As Double, ByRef links() As FlowLink, _
        ByRef linkCount As Long, ByRef records() As FlowRecord, _
        ByRef recordCount As Long, ByVal seenRecords As Object)
    Dim score As Long, ratingText As String, chronology As String
    Dim precisionText As String, periodText As String, linkKey As String
    If linkCount >= FLOW_MAX_LINKS Then _
        Err.Raise vbObjectError + 4706, "AddFlowLink", _
                  "�����t���[�̓����ƍ���" & Format$(FLOW_MAX_LINKS, "#,##0") & _
                  "���𒴂��܂����B�Œ���z���グ�邩�A���͏��������߂Ă��������B"
    EnsureFlowLinkCapacity links, linkCount + 1
    EvaluateFlowLink sourceData, withdrawalBundles(withdrawalIndex), depositBundles(depositIndex), _
                     differenceAmount, absoluteTolerance, score, ratingText, chronology, _
                     precisionText, periodText
    linkCount = linkCount + 1
    linkKey = withdrawalBundles(withdrawalIndex).IdList & ">" & depositBundles(depositIndex).IdList
    With links(linkCount)
        .WithdrawalBundle = withdrawalIndex
        .DepositBundle = depositIndex
        .DifferenceAmount = differenceAmount
        .Score = score
        .Rating = ratingText
        .Chronology = chronology
        .TimePrecision = precisionText
        .PeriodText = periodText
        .KeyText = linkKey
    End With
    If withdrawalBundles(withdrawalIndex).ItemCount > 1 Or _
       depositBundles(depositIndex).ItemCount > 1 Then
        AddFlowRecord records, recordCount, 1, CStr(linkCount), vbNullString, score, ratingText, _
                      "GROUP:" & linkKey, seenRecords
    End If
End Sub

Private Sub EvaluateFlowLink( _
        ByRef sourceData As Variant, ByRef withdrawalBundle As FlowBundle, _
        ByRef depositBundle As FlowBundle, ByVal differenceAmount As Double, _
        ByVal absoluteTolerance As Double, ByRef score As Long, ByRef ratingText As String, _
        ByRef chronology As String, ByRef precisionText As String, ByRef periodText As String)
    Dim minDate As Long, maxDate As Long, dayDifference As Long
    Dim complexityPenalty As Long
    If differenceAmount < 0.0000001 Then
        score = 45
    ElseIf differenceAmount <= absoluteTolerance + 0.0000001 Then
        score = 35
    Else
        score = 25
    End If

    If withdrawalBundle.HasAllTimes And depositBundle.HasAllTimes Then
        precisionText = "�S����������"
    ElseIf withdrawalBundle.HasAnyTime Or depositBundle.HasAnyTime Then
        precisionText = "�ꕔ��������"
    Else
        precisionText = "�����Ȃ�"
    End If
    DetermineFlowChronology withdrawalBundle, depositBundle, chronology

    minDate = withdrawalBundle.MinDate
    If depositBundle.MinDate < minDate Then minDate = depositBundle.MinDate
    maxDate = withdrawalBundle.MaxDate
    If depositBundle.MaxDate > maxDate Then maxDate = depositBundle.MaxDate
    dayDifference = maxDate - minDate
    If dayDifference = 0 Then
        periodText = "����"
        If withdrawalBundle.HasAllTimes And depositBundle.HasAllTimes Then
            score = score + 24
        Else
            score = score + 16
        End If
    ElseIf dayDifference = 1 Then
        periodText = "1��"
        score = score + 13
    ElseIf dayDifference <= 3 Then
        periodText = CStr(dayDifference) & "��"
        score = score + 10
    ElseIf dayDifference <= 7 Then
        periodText = CStr(dayDifference) & "��"
        score = score + 6
    Else
        periodText = CStr(dayDifference) & "��"
        score = score + 3
    End If

    If BundlesSharePerson(sourceData, withdrawalBundle, depositBundle) Then
        score = score + 12
    Else
        score = score + 5
    End If
    score = score + 8
    complexityPenalty = withdrawalBundle.ItemCount + depositBundle.ItemCount - 2
    If complexityPenalty > 0 Then score = score - complexityPenalty * 2
    If InStr(1, chronology, "����", vbTextCompare) > 0 Then score = score - 2
    If score < 1 Then score = 1
    If score > 100 Then score = 100
    ratingText = FlowRatingForScore(score)
End Sub

Private Sub DetermineFlowChronology(ByRef withdrawalBundle As FlowBundle, _
                                    ByRef depositBundle As FlowBundle, _
                                    ByRef chronology As String)
    If withdrawalBundle.MaxDate < depositBundle.MinDate Then
        chronology = "�o��������"
    ElseIf depositBundle.MaxDate < withdrawalBundle.MinDate Then
        chronology = "�������o��"
    ElseIf withdrawalBundle.HasAllTimes And depositBundle.HasAllTimes Then
        If withdrawalBundle.MaxStamp < depositBundle.MinStamp - 0.000000001 Then
            chronology = "�o��������"
        ElseIf depositBundle.MaxStamp < withdrawalBundle.MinStamp - 0.000000001 Then
            chronology = "�������o��"
        ElseIf Abs(withdrawalBundle.MaxStamp - withdrawalBundle.MinStamp) <= 0.000000001 And _
               Abs(depositBundle.MaxStamp - depositBundle.MinStamp) <= 0.000000001 And _
               Abs(withdrawalBundle.MinStamp - depositBundle.MinStamp) <= 0.000000001 Then
            chronology = "������"
        Else
            chronology = "���n�񍬍�"
        End If
    Else
        chronology = "�������m��i���������E�V�t�g����j"
    End If
End Sub

Private Function BundlesSharePerson(ByRef sourceData As Variant, _
                                    ByRef firstBundle As FlowBundle, _
                                    ByRef secondBundle As FlowBundle) As Boolean
    Dim firstRows As Variant, secondRows As Variant
    Dim firstItem As Variant, secondItem As Variant
    Dim firstIdentity As String, secondIdentity As String
    firstRows = Split(firstBundle.RowList, ";")
    secondRows = Split(secondBundle.RowList, ";")
    For Each firstItem In firstRows
        firstIdentity = FlowPersonIdentity(sourceData, CLng(firstItem))
        If Len(firstIdentity) > 0 Then
            For Each secondItem In secondRows
                secondIdentity = FlowPersonIdentity(sourceData, CLng(secondItem))
                If StrComp(firstIdentity, secondIdentity, vbTextCompare) = 0 Then
                    BundlesSharePerson = True
                    Exit Function
                End If
            Next secondItem
        End If
    Next firstItem
End Function

Private Function FlowPersonIdentity(ByRef sourceData As Variant, ByVal sourceRow As Long) As String
    FlowPersonIdentity = CellText(sourceData(sourceRow, WORK_TX_COL_PERSON_ID))
    If Len(FlowPersonIdentity) = 0 Then _
        FlowPersonIdentity = NormalizePersonNameKey(CellText(sourceData(sourceRow, OUT_COL_PERSON)))
End Function

Private Sub EnsureFlowLinkCapacity(ByRef links() As FlowLink, ByVal requiredCount As Long)
    Dim newCapacity As Long
    If requiredCount <= 1 Then
        ReDim links(1 To 1024)
    ElseIf requiredCount > UBound(links) Then
        newCapacity = UBound(links) * 2
        If newCapacity < requiredCount Then newCapacity = requiredCount
        If newCapacity > FLOW_MAX_LINKS Then newCapacity = FLOW_MAX_LINKS
        ReDim Preserve links(1 To newCapacity)
    End If
End Sub

Private Sub AddFlowRecord(ByRef records() As FlowRecord, ByRef recordCount As Long, _
                          ByVal kindCode As Long, ByVal linkList As String, _
                          ByVal extraWithdrawalRows As String, ByVal score As Long, _
                          ByVal ratingText As String, ByVal keyText As String, _
                          ByVal seenRecords As Object)
    If seenRecords.Exists(keyText) Then Exit Sub
    If recordCount >= MAX_ANALYSIS_OUTPUT_ROWS Then _
        Err.Raise vbObjectError + 4707, "AddFlowRecord", _
                  "�����t���[�ǐՌ�₪���p����i" & _
                  Format$(MAX_ANALYSIS_OUTPUT_ROWS, "#,##0") & "���j�𒴂��܂����B"
    EnsureFlowRecordCapacity records, recordCount + 1
    recordCount = recordCount + 1
    With records(recordCount)
        .KindCode = kindCode
        .LinkList = linkList
        .ExtraWithdrawalRows = extraWithdrawalRows
        .Score = score
        .Rating = ratingText
        .KeyText = keyText
    End With
    seenRecords.Add keyText, recordCount
End Sub

Private Sub EnsureFlowRecordCapacity(ByRef records() As FlowRecord, ByVal requiredCount As Long)
    Dim newCapacity As Long
    If requiredCount <= 1 Then
        ReDim records(1 To 1024)
    ElseIf requiredCount > UBound(records) Then
        newCapacity = UBound(records) * 2
        If newCapacity < requiredCount Then newCapacity = requiredCount
        If newCapacity > MAX_ANALYSIS_OUTPUT_ROWS Then newCapacity = MAX_ANALYSIS_OUTPUT_ROWS
        ReDim Preserve records(1 To newCapacity)
    End If
End Sub

Private Function FlowRatingForScore(ByVal score As Long) As String
    If score >= 80 Then
        FlowRatingForScore = "��"
    ElseIf score >= 60 Then
        FlowRatingForScore = "��"
    Else
        FlowRatingForScore = "��"
    End If
End Function

Private Sub FlowAmountSearchBounds(ByVal amountValue As Double, _
                                   ByVal absoluteTolerance As Double, _
                                   ByVal rateTolerance As Double, _
                                   ByRef lowerAmount As Double, ByRef upperAmount As Double)
    Dim rateValue As Double
    rateValue = rateTolerance / 100#
    lowerAmount = amountValue - absoluteTolerance
    If lowerAmount > amountValue * (1# - rateValue) Then _
        lowerAmount = amountValue * (1# - rateValue)
    If lowerAmount < 0 Then lowerAmount = 0
    upperAmount = amountValue + absoluteTolerance
    If rateValue >= 1# Then
        upperAmount = 1E+307
    ElseIf upperAmount < amountValue / (1# - rateValue) Then
        upperAmount = amountValue / (1# - rateValue)
    End If
End Sub

Private Function FlowAllowedDifference(ByVal firstAmount As Double, _
                                       ByVal secondAmount As Double, _
                                       ByVal absoluteTolerance As Double, _
                                       ByVal rateTolerance As Double) As Double
    Dim rateDifference As Double
    If firstAmount > secondAmount Then
        rateDifference = firstAmount * rateTolerance / 100#
    Else
        rateDifference = secondAmount * rateTolerance / 100#
    End If
    If absoluteTolerance > rateDifference Then
        FlowAllowedDifference = absoluteTolerance
    Else
        FlowAllowedDifference = rateDifference
    End If
End Function

Private Function LowerBoundFlowAmount(ByRef amounts() As Double, ByVal itemCount As Long, _
                                      ByVal targetValue As Double) As Long
    Dim low As Long, high As Long, mid As Long
    low = 1: high = itemCount + 1
    Do While low < high
        mid = low + (high - low) \ 2
        If mid <= itemCount And amounts(mid) < targetValue Then low = mid + 1 Else high = mid
    Loop
    LowerBoundFlowAmount = low
End Function

Private Function UpperBoundFlowAmount(ByRef amounts() As Double, ByVal itemCount As Long, _
                                      ByVal targetValue As Double) As Long
    Dim low As Long, high As Long, mid As Long
    low = 1: high = itemCount + 1
    Do While low < high
        mid = low + (high - low) \ 2
        If mid <= itemCount And amounts(mid) <= targetValue Then low = mid + 1 Else high = mid
    Loop
    UpperBoundFlowAmount = low - 1
End Function

Private Sub QuickSortFlowAmounts(ByRef amounts() As Double, ByRef indexes() As Long, _
                                 ByVal firstIndex As Long, ByVal lastIndex As Long)
    Dim low As Long, high As Long, pivot As Double
    Dim tempAmount As Double, tempIndex As Long
    low = firstIndex: high = lastIndex
    pivot = amounts((firstIndex + lastIndex) \ 2)
    Do While low <= high
        Do While amounts(low) < pivot
            low = low + 1
        Loop
        Do While amounts(high) > pivot
            high = high - 1
        Loop
        If low <= high Then
            tempAmount = amounts(low): amounts(low) = amounts(high): amounts(high) = tempAmount
            tempIndex = indexes(low): indexes(low) = indexes(high): indexes(high) = tempIndex
            low = low + 1: high = high - 1
        End If
    Loop
    If firstIndex < high Then QuickSortFlowAmounts amounts, indexes, firstIndex, high
    If low < lastIndex Then QuickSortFlowAmounts amounts, indexes, low, lastIndex
End Sub

Private Sub BuildFlowChains( _
        ByRef sourceData As Variant, ByRef withdrawalBundles() As FlowBundle, _
        ByVal withdrawalBundleCount As Long, _
        ByRef depositBundles() As FlowBundle, ByRef links() As FlowLink, _
        ByVal linkCount As Long, ByVal dayWindow As Long, _
        ByVal absoluteTolerance As Double, ByVal rateTolerance As Double, _
        ByRef records() As FlowRecord, ByRef recordCount As Long, ByVal seenRecords As Object)
    Dim adjacency As Object, withdrawalByAccount As Object, terminalCandidateSeen As Object
    Dim predecessor() As Long, covered() As Boolean
    Dim path(1 To FLOW_MAX_CHAIN_LEGS) As Long
    Dim usedRows As Object
    Dim i As Long, terminalOperationCount As Long
    Set adjacency = CreateObject("Scripting.Dictionary")
    adjacency.CompareMode = vbTextCompare
    Set terminalCandidateSeen = CreateObject("Scripting.Dictionary")
    terminalCandidateSeen.CompareMode = vbTextCompare
    ReDim predecessor(1 To linkCount)
    ReDim covered(1 To linkCount)
    BuildFlowAdjacency sourceData, withdrawalBundles, depositBundles, links, linkCount, _
                       dayWindow, absoluteTolerance, rateTolerance, adjacency, predecessor
    Set withdrawalByAccount = BuildWithdrawalBundleAccountIndex(withdrawalBundles, withdrawalBundleCount)

    For i = 1 To linkCount
        If i Mod 512 = 0 Then AppProgress "���i�����t���[��ڑ����Ă��܂�...", i, linkCount
        If FlowLinkCanCarryForward(links(i)) And predecessor(i) = 0 Then
            Set usedRows = CreateObject("Scripting.Dictionary")
            usedRows.CompareMode = vbTextCompare
            path(1) = i
            AddLinkRowsToDictionary withdrawalBundles, depositBundles, links(i), usedRows
            ExploreFlowPath sourceData, withdrawalBundles, depositBundles, links, adjacency, _
                            withdrawalByAccount, dayWindow, absoluteTolerance, rateTolerance, _
                            path, 1, usedRows, covered, terminalCandidateSeen, terminalOperationCount, _
                            records, recordCount, seenRecords
        End If
    Next i
    '�z�o�H�ȂǊJ�n�_����ӂɌ��߂��Ȃ������N���A��x�͒T������B
    For i = 1 To linkCount
        If FlowLinkCanCarryForward(links(i)) And Not covered(i) Then
            Set usedRows = CreateObject("Scripting.Dictionary")
            usedRows.CompareMode = vbTextCompare
            path(1) = i
            AddLinkRowsToDictionary withdrawalBundles, depositBundles, links(i), usedRows
            ExploreFlowPath sourceData, withdrawalBundles, depositBundles, links, adjacency, _
                            withdrawalByAccount, dayWindow, absoluteTolerance, rateTolerance, _
                            path, 1, usedRows, covered, terminalCandidateSeen, terminalOperationCount, _
                            records, recordCount, seenRecords
        End If
    Next i
End Sub

'�ʏ탊���N�́u�o�����Ɠ������v�̏ƍ��Ƃ��ĕێ����邽�߁A�P���̓�����s����
'���̂܂ܑ��i�֐ڑ�����Ɠ����o�����x�g���Ă��܂��B�����ł́A�O�i��������
'�Ɨ��̋N�_�Ƃ��Ċ����̏o���N�_�o�H�֕t�����A�������o���������ȍ~�𖾎��I�ɍ��B
Private Sub BuildDepositOriginFlowRecords( _
        ByRef sourceData As Variant, ByRef withdrawalBundles() As FlowBundle, _
        ByRef depositBundles() As FlowBundle, ByVal depositBundleCount As Long, _
        ByRef links() As FlowLink, ByVal linkCount As Long, ByVal dayWindow As Long, _
        ByVal absoluteTolerance As Double, ByVal rateTolerance As Double, _
        ByRef records() As FlowRecord, ByRef recordCount As Long, ByVal seenRecords As Object)
    Dim depositsByAccount As Object, candidateSeen As Object, usedRows As Object
    Dim baseRecordCount As Long, operationCount As Long
    Dim i As Long, firstLinkIndex As Long, originKind As Long
    If depositBundleCount <= 0 Or linkCount <= 0 Then Exit Sub
    Set depositsByAccount = BuildDepositBundleAccountIndex(depositBundles, depositBundleCount)
    Set candidateSeen = CreateObject("Scripting.Dictionary")
    candidateSeen.CompareMode = vbTextCompare
    Set usedRows = CreateObject("Scripting.Dictionary")
    usedRows.CompareMode = vbTextCompare
    baseRecordCount = recordCount

    '1��1�̏o�������������N�ɂ��O�i������t����B����ɂ��A�S�ĒP������ł�
    '�������o������������≻�ł���B
    For i = 1 To linkCount
        If i Mod 512 = 0 Then AppProgress "�����N�_�̘A����T�����Ă��܂�...", i, linkCount
        If FlowLinkCanCarryForward(links(i)) Then
            usedRows.RemoveAll
            AddFlowRowsToDictionary withdrawalBundles(links(i).WithdrawalBundle).RowList, usedRows
            AddFlowRowsToDictionary depositBundles(links(i).DepositBundle).RowList, usedRows
            AddOriginCandidatesForPath sourceData, withdrawalBundles, depositBundles, links, _
                CStr(i), vbNullString, 5, links(i).Score - 2, "LINK:" & links(i).KeyText, _
                depositsByAccount, candidateSeen, usedRows, dayWindow, absoluteTolerance, _
                rateTolerance, operationCount, records, recordCount, seenRecords
        End If
    Next i

    '���ɍ쐬�ς݂̒����A���E�I�[�o���ւ��������@�ŋN�_������t������B
    '��̃��[�v�Œǉ��������R�[�h���ċA�I�ɑ��B�����Ȃ��悤�A�J�n����������������B
    For i = 1 To baseRecordCount
        firstLinkIndex = FirstFlowLinkIndex(records(i).LinkList)
        If firstLinkIndex > 0 And FlowLinkCanCarryForward(links(firstLinkIndex)) Then
            If FlowListItemCount(records(i).LinkList) > 1 Or _
               Len(records(i).ExtraWithdrawalRows) > 0 Then
                usedRows.RemoveAll
                CollectFlowRecordRows withdrawalBundles, depositBundles, links, records(i), usedRows
                Select Case records(i).KindCode
                    Case 3: originKind = 6
                    Case 4: originKind = 7
                    Case Else: originKind = 5
                End Select
                AddOriginCandidatesForPath sourceData, withdrawalBundles, depositBundles, links, _
                    records(i).LinkList, records(i).ExtraWithdrawalRows, originKind, _
                    records(i).Score - 2, records(i).KeyText, depositsByAccount, candidateSeen, _
                    usedRows, dayWindow, absoluteTolerance, rateTolerance, operationCount, _
                    records, recordCount, seenRecords
            End If
        End If
    Next i
End Sub

Private Sub AddOriginCandidatesForPath( _
        ByRef sourceData As Variant, ByRef withdrawalBundles() As FlowBundle, _
        ByRef depositBundles() As FlowBundle, ByRef links() As FlowLink, _
        ByVal linkList As String, ByVal extraWithdrawalRows As String, ByVal originKind As Long, _
        ByVal baseScore As Long, ByVal baseKey As String, ByVal depositsByAccount As Object, _
        ByVal candidateSeen As Object, ByVal usedRows As Object, ByVal dayWindow As Long, _
        ByVal absoluteTolerance As Double, ByVal rateTolerance As Double, _
        ByRef operationCount As Long, ByRef records() As FlowRecord, ByRef recordCount As Long, _
        ByVal seenRecords As Object)
    Dim firstLinkIndex As Long, firstWithdrawalIndex As Long
    Dim accountParts As Variant, accountItem As Variant
    Dim bundleItems As Collection, bundleItem As Variant, originIndex As Long
    Dim keyText As String, score As Long
    firstLinkIndex = FirstFlowLinkIndex(linkList)
    If firstLinkIndex <= 0 Then Exit Sub
    firstWithdrawalIndex = links(firstLinkIndex).WithdrawalBundle
    candidateSeen.RemoveAll
    accountParts = Split(withdrawalBundles(firstWithdrawalIndex).AccountList, ";")
    For Each accountItem In accountParts
        If depositsByAccount.Exists(CStr(accountItem)) Then
            Set bundleItems = depositsByAccount(CStr(accountItem))
            For Each bundleItem In bundleItems
                originIndex = CLng(bundleItem)
                If Not candidateSeen.Exists(CStr(originIndex)) Then
                    candidateSeen.Add CStr(originIndex), True
                    operationCount = operationCount + 1
                    If operationCount Mod 8192 = 0 Then _
                        AppProgress "�����N�_�̘A�������ƍ����Ă��܂�...", operationCount, _
                                    FLOW_MAX_ORIGIN_OPERATIONS
                    If operationCount > FLOW_MAX_ORIGIN_OPERATIONS Then _
                        Err.Raise vbObjectError + 4710, "AddOriginCandidatesForPath", _
                                  "�����N�_�̘A���T�������p����𒴂��܂����B" & _
                                  "�Œ���z���グ�邩�A���͑Ώۂ𕪂��Ă��������B"
                    If Not AnyFlowRowsInDictionary(depositBundles(originIndex).RowList, usedRows) Then
                        If OriginBundlesCompatible(depositBundles(originIndex), _
                                                   withdrawalBundles(firstWithdrawalIndex), dayWindow, _
                                                   absoluteTolerance, rateTolerance) Then
                            score = baseScore
                            If score < 1 Then score = 1
                            If score > 100 Then score = 100
                            keyText = "ORIGIN:" & depositBundles(originIndex).IdList & "|" & baseKey
                            AddOriginFlowRecord records, recordCount, originKind, linkList, _
                                                extraWithdrawalRows, originIndex, score, _
                                                FlowRatingForScore(score), keyText, seenRecords
                        End If
                    End If
                End If
            Next bundleItem
        End If
    Next accountItem
End Sub

Private Sub AddOriginFlowRecord(ByRef records() As FlowRecord, ByRef recordCount As Long, _
                                ByVal kindCode As Long, ByVal linkList As String, _
                                ByVal extraWithdrawalRows As String, ByVal originDepositBundle As Long, _
                                ByVal score As Long, ByVal ratingText As String, ByVal keyText As String, _
                                ByVal seenRecords As Object)
    Dim previousCount As Long
    previousCount = recordCount
    AddFlowRecord records, recordCount, kindCode, linkList, extraWithdrawalRows, score, _
                  ratingText, keyText, seenRecords
    If recordCount > previousCount Then records(recordCount).OriginDepositBundle = originDepositBundle
End Sub

Private Function FirstFlowLinkIndex(ByVal linkList As String) As Long
    Dim parts As Variant
    If Len(linkList) = 0 Then Exit Function
    parts = Split(linkList, ";")
    If IsNumeric(parts(LBound(parts))) Then FirstFlowLinkIndex = CLng(parts(LBound(parts)))
End Function

Private Function OriginBundlesCompatible(ByRef depositBundle As FlowBundle, _
                                         ByRef withdrawalBundle As FlowBundle, _
                                         ByVal dayWindow As Long, _
                                         ByVal absoluteTolerance As Double, _
                                         ByVal rateTolerance As Double) As Boolean
    Dim firstToWithdrawalDays As Long
    '�N�_�z�͍ŏ��̏o���i�K�Ɠ��������W�������ō\������B�����������܂ޑ���
    '�ꕔ��������v����ꍇ�́A���֌W�ȓ����܂ŋN�_�z�֊܂߂邽�ߍ̗p���Ȃ��B
    If StrComp(depositBundle.AccountList, withdrawalBundle.AccountList, vbTextCompare) <> 0 Then _
        Exit Function
    If Abs(depositBundle.TotalAmount - withdrawalBundle.TotalAmount) > _
       FlowAllowedDifference(depositBundle.TotalAmount, withdrawalBundle.TotalAmount, _
                             absoluteTolerance, rateTolerance) + 0.0000001 Then Exit Function

    '���̈ꕔ�������o���O�Ȃ�悢�A�Ƃ͂��Ȃ��B���ׂĂ̋N�_�������ŏ���
    '�o���i�K���O�i�����Ŏ��������Ȃ珇������j�ŁA�S�̂����������ɂ��邱�ƁB
    firstToWithdrawalDays = withdrawalBundle.MinDate - depositBundle.MinDate
    If firstToWithdrawalDays < 0 Or firstToWithdrawalDays > dayWindow Then Exit Function
    If depositBundle.MaxDate > withdrawalBundle.MinDate Then Exit Function
    If depositBundle.MaxDate = withdrawalBundle.MinDate And _
       depositBundle.HasAllTimes And withdrawalBundle.HasAllTimes Then
        If depositBundle.MaxStamp > withdrawalBundle.MinStamp + 0.000000001 Then Exit Function
    End If
    OriginBundlesCompatible = True
End Function

Private Sub BuildFlowAdjacency( _
        ByRef sourceData As Variant, ByRef withdrawalBundles() As FlowBundle, _
        ByRef depositBundles() As FlowBundle, ByRef links() As FlowLink, _
        ByVal linkCount As Long, ByVal dayWindow As Long, _
        ByVal absoluteTolerance As Double, ByVal rateTolerance As Double, _
        ByVal adjacency As Object, ByRef predecessor() As Long)
    Dim sourceLinksByAccount As Object, candidateSeen As Object
    Dim accountParts As Variant, accountItem As Variant
    Dim linkList As Collection, nextList As Collection
    Dim candidateItem As Variant
    Dim i As Long, nextIndex As Long, operationCount As Long
    Set sourceLinksByAccount = CreateObject("Scripting.Dictionary")
    sourceLinksByAccount.CompareMode = vbTextCompare
    Set candidateSeen = CreateObject("Scripting.Dictionary")
    candidateSeen.CompareMode = vbTextCompare

    For i = 1 To linkCount
        If FlowLinkCanCarryForward(links(i)) Then
            accountParts = Split(withdrawalBundles(links(i).WithdrawalBundle).AccountList, ";")
            For Each accountItem In accountParts
                If Not sourceLinksByAccount.Exists(CStr(accountItem)) Then
                    Set linkList = New Collection
                    sourceLinksByAccount.Add CStr(accountItem), linkList
                Else
                    Set linkList = sourceLinksByAccount(CStr(accountItem))
                End If
                linkList.Add i
            Next accountItem
        End If
    Next i

    For i = 1 To linkCount
        If FlowLinkCanCarryForward(links(i)) Then
            candidateSeen.RemoveAll
            accountParts = Split(depositBundles(links(i).DepositBundle).AccountList, ";")
            For Each accountItem In accountParts
                If sourceLinksByAccount.Exists(CStr(accountItem)) Then
                    Set linkList = sourceLinksByAccount(CStr(accountItem))
                    For Each candidateItem In linkList
                        nextIndex = CLng(candidateItem)
                        If nextIndex <> i And Not candidateSeen.Exists(CStr(nextIndex)) Then
                            candidateSeen.Add CStr(nextIndex), True
                            operationCount = operationCount + 1
                            If operationCount Mod 8192 = 0 Then _
                                AppProgress "���i�����t���[�̐ڑ����ƍ����Ă��܂�...", operationCount, _
                                            FLOW_MAX_ADJACENCY_OPERATIONS
                            If operationCount > FLOW_MAX_ADJACENCY_OPERATIONS Then _
                                Err.Raise vbObjectError + 4708, "BuildFlowAdjacency", _
                                          "���i�����t���[�̐ڑ��T�������p����𒴂��܂����B" & _
                                          "�Œ���z���グ�邩�A���͑Ώۂ𕪂��Ă��������B"
                            If CanFollowFlowLink(sourceData, withdrawalBundles, depositBundles, _
                                                 links(i), links(nextIndex), dayWindow, _
                                                 absoluteTolerance, rateTolerance) Then
                                If Not adjacency.Exists(CStr(i)) Then
                                    Set nextList = New Collection
                                    adjacency.Add CStr(i), nextList
                                Else
                                    Set nextList = adjacency(CStr(i))
                                End If
                                nextList.Add nextIndex
                                predecessor(nextIndex) = predecessor(nextIndex) + 1
                            End If
                        End If
                    Next candidateItem
                End If
            Next accountItem
        End If
    Next i
End Sub

Private Function CanFollowFlowLink( _
        ByRef sourceData As Variant, ByRef withdrawalBundles() As FlowBundle, _
        ByRef depositBundles() As FlowBundle, ByRef firstLink As FlowLink, _
        ByRef secondLink As FlowLink, ByVal dayWindow As Long, _
        ByVal absoluteTolerance As Double, ByVal rateTolerance As Double) As Boolean
    If Not FlowLinkCanCarryForward(firstLink) Or _
       Not FlowLinkCanCarryForward(secondLink) Then Exit Function
    If FlowListsOverlap(withdrawalBundles(firstLink.WithdrawalBundle).RowList, _
                        withdrawalBundles(secondLink.WithdrawalBundle).RowList) Then Exit Function
    If FlowListsOverlap(withdrawalBundles(firstLink.WithdrawalBundle).RowList, _
                        depositBundles(secondLink.DepositBundle).RowList) Then Exit Function
    If FlowListsOverlap(depositBundles(firstLink.DepositBundle).RowList, _
                        withdrawalBundles(secondLink.WithdrawalBundle).RowList) Then Exit Function
    If FlowListsOverlap(depositBundles(firstLink.DepositBundle).RowList, _
                        depositBundles(secondLink.DepositBundle).RowList) Then Exit Function
    CanFollowFlowLink = RelayBundlesCompatible( _
        sourceData, depositBundles(firstLink.DepositBundle), _
        withdrawalBundles(secondLink.WithdrawalBundle), dayWindow, _
        absoluteTolerance, rateTolerance)
End Function

Private Function RelayBundlesCompatible( _
        ByRef sourceData As Variant, ByRef depositBundle As FlowBundle, _
        ByRef withdrawalBundle As FlowBundle, ByVal dayWindow As Long, _
        ByVal absoluteTolerance As Double, ByVal rateTolerance As Double) As Boolean
    Dim commonAccounts As String
    Dim depositAmount As Double, withdrawalAmount As Double
    commonAccounts = FlowListIntersection(depositBundle.AccountList, withdrawalBundle.AccountList)
    If Len(commonAccounts) = 0 Then Exit Function
    depositAmount = SumFlowBundleForAccounts(sourceData, depositBundle.RowList, commonAccounts, True)
    withdrawalAmount = SumFlowBundleForAccounts(sourceData, withdrawalBundle.RowList, commonAccounts, False)
    If depositAmount <= 0 Or withdrawalAmount <= 0 Then Exit Function
    If Abs(depositAmount - withdrawalAmount) > _
       FlowAllowedDifference(depositAmount, withdrawalAmount, absoluteTolerance, rateTolerance) + 0.0000001 Then _
        Exit Function
    If Not HasPlausibleRelayOrder(sourceData, depositBundle.RowList, withdrawalBundle.RowList, _
                                  commonAccounts, dayWindow) Then Exit Function
    RelayBundlesCompatible = True
End Function

Private Function HasPlausibleRelayOrder( _
        ByRef sourceData As Variant, ByVal depositRowsText As String, _
        ByVal withdrawalRowsText As String, ByVal commonAccounts As String, _
        ByVal dayWindow As Long) As Boolean
    Dim depositRows As Variant, withdrawalRows As Variant
    Dim depositItem As Variant, withdrawalItem As Variant
    Dim depositRow As Long, withdrawalRow As Long, accountID As String
    depositRows = Split(depositRowsText, ";")
    withdrawalRows = Split(withdrawalRowsText, ";")
    For Each depositItem In depositRows
        depositRow = CLng(depositItem)
        accountID = CellText(sourceData(depositRow, WORK_TX_COL_ACCOUNT_ID))
        If FlowListContains(commonAccounts, accountID) Then
            For Each withdrawalItem In withdrawalRows
                withdrawalRow = CLng(withdrawalItem)
                If StrComp(accountID, CellText(sourceData(withdrawalRow, WORK_TX_COL_ACCOUNT_ID)), _
                           vbTextCompare) = 0 Then
                    If IsPlausibleFollowingTransaction(sourceData, depositRow, withdrawalRow, dayWindow) Then
                        HasPlausibleRelayOrder = True
                        Exit Function
                    End If
                End If
            Next withdrawalItem
        End If
    Next depositItem
End Function

Private Function IsPlausibleFollowingTransaction(ByRef sourceData As Variant, _
                                                 ByVal firstRow As Long, _
                                                 ByVal secondRow As Long, _
                                                 ByVal dayWindow As Long) As Boolean
    Dim firstDate As Long, secondDate As Long, dayDifference As Long
    Dim firstTime As Double, secondTime As Double
    Dim firstHasTime As Boolean, secondHasTime As Boolean
    firstDate = CLng(VBA.DateValue(CDate(sourceData(firstRow, OUT_COL_DATE))))
    secondDate = CLng(VBA.DateValue(CDate(sourceData(secondRow, OUT_COL_DATE))))
    dayDifference = secondDate - firstDate
    If dayDifference < 0 Or dayDifference > dayWindow Then Exit Function
    If dayDifference > 0 Then
        IsPlausibleFollowingTransaction = True
        Exit Function
    End If
    firstHasTime = TryGetFlowTime(sourceData(firstRow, OUT_COL_TIME), firstTime)
    secondHasTime = TryGetFlowTime(sourceData(secondRow, OUT_COL_TIME), secondTime)
    If firstHasTime And secondHasTime Then
        IsPlausibleFollowingTransaction = (secondTime >= firstTime - 0.000000001)
    Else
        '�����ŕЕ��܂��͗����̎������Ȃ���΁A���t�E���z�E���ꒆ�p�������珇���𐄒肷��B
        IsPlausibleFollowingTransaction = True
    End If
End Function

Private Function SumFlowBundleForAccounts(ByRef sourceData As Variant, _
                                          ByVal rowList As String, _
                                          ByVal accountList As String, _
                                          ByVal isDeposit As Boolean) As Double
    Dim rowParts As Variant, rowItem As Variant, sourceRow As Long
    Dim accountID As String
    rowParts = Split(rowList, ";")
    For Each rowItem In rowParts
        sourceRow = CLng(rowItem)
        accountID = CellText(sourceData(sourceRow, WORK_TX_COL_ACCOUNT_ID))
        If FlowListContains(accountList, accountID) Then
            If isDeposit Then
                SumFlowBundleForAccounts = SumFlowBundleForAccounts + _
                                           CDbl(sourceData(sourceRow, OUT_COL_DEPOSIT))
            Else
                SumFlowBundleForAccounts = SumFlowBundleForAccounts + _
                                           CDbl(sourceData(sourceRow, OUT_COL_WITHDRAW))
            End If
        End If
    Next rowItem
End Function

Private Function FlowListIntersection(ByVal firstList As String, _
                                      ByVal secondList As String) As String
    Dim items As Variant, item As Variant
    items = Split(firstList, ";")
    For Each item In items
        If FlowListContains(secondList, CStr(item)) Then
            If Len(FlowListIntersection) > 0 Then FlowListIntersection = FlowListIntersection & ";"
            FlowListIntersection = FlowListIntersection & CStr(item)
        End If
    Next item
End Function

Private Function FlowListContains(ByVal listText As String, ByVal itemText As String) As Boolean
    If Len(listText) = 0 Or Len(itemText) = 0 Then Exit Function
    FlowListContains = (InStr(1, ";" & listText & ";", ";" & itemText & ";", vbTextCompare) > 0)
End Function

Private Function FlowListsOverlap(ByVal firstList As String, ByVal secondList As String) As Boolean
    Dim items As Variant, item As Variant
    If Len(firstList) = 0 Or Len(secondList) = 0 Then Exit Function
    items = Split(firstList, ";")
    For Each item In items
        If FlowListContains(secondList, CStr(item)) Then
            FlowListsOverlap = True
            Exit Function
        End If
    Next item
End Function

Private Function BuildWithdrawalBundleAccountIndex( _
        ByRef withdrawalBundles() As FlowBundle, _
        ByVal withdrawalBundleCount As Long) As Object
    Dim result As Object, bundlesForAccount As Collection
    Dim accountParts As Variant, accountItem As Variant
    Dim i As Long, accountID As String
    Set result = CreateObject("Scripting.Dictionary")
    result.CompareMode = vbTextCompare
    For i = 1 To withdrawalBundleCount
        accountParts = Split(withdrawalBundles(i).AccountList, ";")
        For Each accountItem In accountParts
            accountID = CStr(accountItem)
            If Not result.Exists(accountID) Then
                Set bundlesForAccount = New Collection
                result.Add accountID, bundlesForAccount
            Else
                Set bundlesForAccount = result(accountID)
            End If
            bundlesForAccount.Add i
        Next accountItem
    Next i
    Set BuildWithdrawalBundleAccountIndex = result
End Function

Private Function BuildDepositBundleAccountIndex( _
        ByRef depositBundles() As FlowBundle, ByVal depositBundleCount As Long) As Object
    Dim result As Object, bundlesForAccount As Collection
    Dim accountParts As Variant, accountItem As Variant
    Dim i As Long, accountID As String
    Set result = CreateObject("Scripting.Dictionary")
    result.CompareMode = vbTextCompare
    For i = 1 To depositBundleCount
        accountParts = Split(depositBundles(i).AccountList, ";")
        For Each accountItem In accountParts
            accountID = CStr(accountItem)
            If Not result.Exists(accountID) Then
                Set bundlesForAccount = New Collection
                result.Add accountID, bundlesForAccount
            Else
                Set bundlesForAccount = result(accountID)
            End If
            bundlesForAccount.Add i
        Next accountItem
    Next i
    Set BuildDepositBundleAccountIndex = result
End Function

Private Function FlowLinkCanCarryForward(ByRef link As FlowLink) As Boolean
    '�P���̏ƍ����ł͊��m�̓�����s���c�����A���̑g���o���N�_�̎����o�H��
    '�g�ݍ��ނƎ��n��ɔ����邽�߁A���i�E���p��o���̒T���ɂ͎g�p���Ȃ��B
    FlowLinkCanCarryForward = _
        (StrComp(link.Chronology, "�������o��", vbTextCompare) <> 0)
End Function

Private Sub ExploreFlowPath( _
        ByRef sourceData As Variant, ByRef withdrawalBundles() As FlowBundle, _
        ByRef depositBundles() As FlowBundle, ByRef links() As FlowLink, _
        ByVal adjacency As Object, ByVal withdrawalByAccount As Object, _
        ByVal dayWindow As Long, ByVal absoluteTolerance As Double, _
        ByVal rateTolerance As Double, ByRef path() As Long, ByVal depth As Long, _
        ByVal usedRows As Object, ByRef covered() As Boolean, _
        ByVal terminalCandidateSeen As Object, _
        ByRef terminalOperationCount As Long, _
        ByRef records() As FlowRecord, ByRef recordCount As Long, ByVal seenRecords As Object)
    Dim nextLinks As Collection
    Dim nextItem As Variant, nextIndex As Long
    Dim extended As Boolean
    covered(path(depth)) = True

    AddTerminalFlowRecordsForPath sourceData, withdrawalBundles, depositBundles, links, _
                                  adjacency, withdrawalByAccount, dayWindow, absoluteTolerance, _
                                  rateTolerance, path, depth, usedRows, terminalCandidateSeen, _
                                  terminalOperationCount, _
                                  records, recordCount, seenRecords
    If depth >= FLOW_MAX_CHAIN_LEGS Then
        If depth >= 2 Then
            If FlowPathHasUnusedExtension(withdrawalBundles, depositBundles, links, adjacency, _
                                          path, depth, usedRows) Then
                AddChainFlowRecord links, path, depth, 4, records, recordCount, seenRecords
            Else
                AddChainFlowRecord links, path, depth, 2, records, recordCount, seenRecords
            End If
        End If
        Exit Sub
    End If
    If adjacency.Exists(CStr(path(depth))) Then
        Set nextLinks = adjacency(CStr(path(depth)))
        For Each nextItem In nextLinks
            nextIndex = CLng(nextItem)
            If Not PathContainsFlowLink(path, depth, nextIndex) Then
                If LinkRowsAreUnused(withdrawalBundles, depositBundles, links(nextIndex), usedRows) Then
                    extended = True
                    path(depth + 1) = nextIndex
                    AddLinkRowsToDictionary withdrawalBundles, depositBundles, links(nextIndex), usedRows
                    ExploreFlowPath sourceData, withdrawalBundles, depositBundles, links, adjacency, _
                                    withdrawalByAccount, dayWindow, absoluteTolerance, rateTolerance, _
                                    path, depth + 1, usedRows, covered, terminalCandidateSeen, _
                                    terminalOperationCount, _
                                    records, recordCount, seenRecords
                    RemoveLinkRowsFromDictionary withdrawalBundles, depositBundles, links(nextIndex), usedRows
                End If
            End If
        Next nextItem
    End If
    If Not extended And depth >= 2 Then _
        AddChainFlowRecord links, path, depth, 2, records, recordCount, seenRecords
End Sub

Private Function FlowPathHasUnusedExtension( _
        ByRef withdrawalBundles() As FlowBundle, ByRef depositBundles() As FlowBundle, _
        ByRef links() As FlowLink, ByVal adjacency As Object, ByRef path() As Long, _
        ByVal depth As Long, ByVal usedRows As Object) As Boolean
    Dim nextLinks As Collection, item As Variant, nextIndex As Long
    If Not adjacency.Exists(CStr(path(depth))) Then Exit Function
    Set nextLinks = adjacency(CStr(path(depth)))
    For Each item In nextLinks
        nextIndex = CLng(item)
        If Not PathContainsFlowLink(path, depth, nextIndex) Then
            If LinkRowsAreUnused(withdrawalBundles, depositBundles, links(nextIndex), usedRows) Then
                FlowPathHasUnusedExtension = True
                Exit Function
            End If
        End If
    Next item
End Function

Private Sub AddChainFlowRecord(ByRef links() As FlowLink, ByRef path() As Long, _
                               ByVal depth As Long, ByVal kindCode As Long, _
                               ByRef records() As FlowRecord, ByRef recordCount As Long, _
                               ByVal seenRecords As Object)
    Dim i As Long, linkList As String, keyText As String
    Dim scoreTotal As Long, score As Long
    For i = 1 To depth
        If i > 1 Then
            linkList = linkList & ";"
            keyText = keyText & "|"
        End If
        linkList = linkList & CStr(path(i))
        keyText = keyText & links(path(i)).KeyText
        scoreTotal = scoreTotal + links(path(i)).Score
    Next i
    score = CLng(scoreTotal / depth) + (depth - 1) * 3
    If kindCode = 4 Then score = score - 3
    If score > 100 Then score = 100
    If score < 1 Then score = 1
    If kindCode = 4 Then
        keyText = "CHAIN-LIMIT:" & keyText
    Else
        keyText = "CHAIN:" & keyText
    End If
    AddFlowRecord records, recordCount, kindCode, linkList, vbNullString, score, _
                  FlowRatingForScore(score), keyText, seenRecords
End Sub

Private Sub AddTerminalFlowRecordsForPath( _
        ByRef sourceData As Variant, ByRef withdrawalBundles() As FlowBundle, _
        ByRef depositBundles() As FlowBundle, ByRef links() As FlowLink, _
        ByVal adjacency As Object, ByVal withdrawalByAccount As Object, _
        ByVal dayWindow As Long, ByVal absoluteTolerance As Double, _
        ByVal rateTolerance As Double, ByRef path() As Long, ByVal depth As Long, _
        ByVal usedRows As Object, ByVal candidateSeen As Object, _
        ByRef terminalOperationCount As Long, _
        ByRef records() As FlowRecord, ByRef recordCount As Long, _
        ByVal seenRecords As Object)
    Dim lastLinkIndex As Long, depositBundleIndex As Long
    Dim accountParts As Variant, accountItem As Variant
    Dim accountBundles As Collection, bundleItem As Variant
    Dim candidateBundleIndex As Long
    Dim linkList As String, pathKey As String, keyText As String
    Dim score As Long
    lastLinkIndex = path(depth)
    depositBundleIndex = links(lastLinkIndex).DepositBundle
    candidateSeen.RemoveAll
    accountParts = Split(depositBundles(depositBundleIndex).AccountList, ";")
    For Each accountItem In accountParts
        If withdrawalByAccount.Exists(CStr(accountItem)) Then
            Set accountBundles = withdrawalByAccount(CStr(accountItem))
            For Each bundleItem In accountBundles
                candidateBundleIndex = CLng(bundleItem)
                If Not candidateSeen.Exists(CStr(candidateBundleIndex)) Then
                    candidateSeen.Add CStr(candidateBundleIndex), True
                    terminalOperationCount = terminalOperationCount + 1
                    If terminalOperationCount Mod 8192 = 0 Then _
                        AppProgress "���p��o���̑g�������ƍ����Ă��܂�...", terminalOperationCount, _
                                    FLOW_MAX_TERMINAL_OPERATIONS
                    If terminalOperationCount > FLOW_MAX_TERMINAL_OPERATIONS Then _
                        Err.Raise vbObjectError + 4709, "AddTerminalFlowRecordsForPath", _
                                  "���p��o���̑g�����T�������p����𒴂��܂����B" & _
                                  "�Œ���z���グ�邩�A���͑Ώۂ𕪂��Ă��������B"
                    If Not AnyFlowRowsInDictionary( _
                            withdrawalBundles(candidateBundleIndex).RowList, usedRows) Then
                        If Not WithdrawalBundleCoveredByAdjacentLink( _
                                lastLinkIndex, candidateBundleIndex, adjacency, withdrawalBundles, links) Then
                            If RelayBundlesCompatible( _
                                    sourceData, depositBundles(depositBundleIndex), _
                                    withdrawalBundles(candidateBundleIndex), dayWindow, _
                                    absoluteTolerance, rateTolerance) Then
                                linkList = vbNullString
                                pathKey = vbNullString
                                BuildPathIdentity links, path, depth, linkList, pathKey
                                keyText = "TAIL:" & pathKey & ">" & _
                                          withdrawalBundles(candidateBundleIndex).IdList
                                score = AveragePathScore(links, path, depth) - 2
                                If score < 1 Then score = 1
                                AddFlowRecord records, recordCount, 3, linkList, _
                                              withdrawalBundles(candidateBundleIndex).RowList, score, _
                                              FlowRatingForScore(score), keyText, seenRecords
                            End If
                        End If
                    End If
                End If
            Next bundleItem
        End If
    Next accountItem
End Sub

Private Function WithdrawalBundleCoveredByAdjacentLink( _
        ByVal currentLink As Long, ByVal withdrawalBundleIndex As Long, ByVal adjacency As Object, _
        ByRef withdrawalBundles() As FlowBundle, ByRef links() As FlowLink) As Boolean
    Dim nextLinks As Collection, item As Variant, nextIndex As Long
    If Not adjacency.Exists(CStr(currentLink)) Then Exit Function
    Set nextLinks = adjacency(CStr(currentLink))
    For Each item In nextLinks
        nextIndex = CLng(item)
        If StrComp(withdrawalBundles(links(nextIndex).WithdrawalBundle).IdList, _
                   withdrawalBundles(withdrawalBundleIndex).IdList, vbTextCompare) = 0 Then
            WithdrawalBundleCoveredByAdjacentLink = True
            Exit Function
        End If
    Next item
End Function

Private Sub BuildPathIdentity(ByRef links() As FlowLink, ByRef path() As Long, _
                              ByVal depth As Long, ByRef linkList As String, _
                              ByRef pathKey As String)
    Dim i As Long
    For i = 1 To depth
        If i > 1 Then
            linkList = linkList & ";"
            pathKey = pathKey & "|"
        End If
        linkList = linkList & CStr(path(i))
        pathKey = pathKey & links(path(i)).KeyText
    Next i
End Sub

Private Function AveragePathScore(ByRef links() As FlowLink, ByRef path() As Long, _
                                  ByVal depth As Long) As Long
    Dim i As Long, scoreTotal As Long
    For i = 1 To depth
        scoreTotal = scoreTotal + links(path(i)).Score
    Next i
    AveragePathScore = CLng(scoreTotal / depth) + (depth - 1) * 3
    If AveragePathScore > 100 Then AveragePathScore = 100
End Function

Private Function PathContainsFlowLink(ByRef path() As Long, ByVal depth As Long, _
                                      ByVal linkIndex As Long) As Boolean
    Dim i As Long
    For i = 1 To depth
        If path(i) = linkIndex Then
            PathContainsFlowLink = True
            Exit Function
        End If
    Next i
End Function

Private Function LinkRowsAreUnused(ByRef withdrawalBundles() As FlowBundle, _
                                   ByRef depositBundles() As FlowBundle, _
                                   ByRef link As FlowLink, ByVal usedRows As Object) As Boolean
    If AnyFlowRowsInDictionary(withdrawalBundles(link.WithdrawalBundle).RowList, usedRows) Then Exit Function
    If AnyFlowRowsInDictionary(depositBundles(link.DepositBundle).RowList, usedRows) Then Exit Function
    LinkRowsAreUnused = True
End Function

Private Function AnyFlowRowsInDictionary(ByVal rowList As String, ByVal values As Object) As Boolean
    Dim rows As Variant, item As Variant
    rows = Split(rowList, ";")
    For Each item In rows
        If values.Exists(CStr(item)) Then
            AnyFlowRowsInDictionary = True
            Exit Function
        End If
    Next item
End Function

Private Sub AddLinkRowsToDictionary(ByRef withdrawalBundles() As FlowBundle, _
                                    ByRef depositBundles() As FlowBundle, _
                                    ByRef link As FlowLink, ByVal values As Object)
    AddFlowRowsToDictionary withdrawalBundles(link.WithdrawalBundle).RowList, values
    AddFlowRowsToDictionary depositBundles(link.DepositBundle).RowList, values
End Sub

Private Sub RemoveLinkRowsFromDictionary(ByRef withdrawalBundles() As FlowBundle, _
                                         ByRef depositBundles() As FlowBundle, _
                                         ByRef link As FlowLink, ByVal values As Object)
    RemoveFlowRowsFromDictionary withdrawalBundles(link.WithdrawalBundle).RowList, values
    RemoveFlowRowsFromDictionary depositBundles(link.DepositBundle).RowList, values
End Sub

Private Sub AddFlowRowsToDictionary(ByVal rowList As String, ByVal values As Object)
    Dim rows As Variant, item As Variant
    rows = Split(rowList, ";")
    For Each item In rows
        If Not values.Exists(CStr(item)) Then values.Add CStr(item), True
    Next item
End Sub

Private Sub RemoveFlowRowsFromDictionary(ByVal rowList As String, ByVal values As Object)
    Dim rows As Variant, item As Variant
    rows = Split(rowList, ";")
    For Each item In rows
        If values.Exists(CStr(item)) Then values.Remove CStr(item)
    Next item
End Sub

Private Sub UpdateFlowCandidateStats( _
        ByRef sourceData As Variant, ByRef withdrawalBundles() As FlowBundle, _
        ByRef depositBundles() As FlowBundle, ByRef links() As FlowLink, _
        ByRef records() As FlowRecord, ByVal recordCount As Long, _
        ByVal candidateCountByTx As Object, ByVal bestScoreByTx As Object, _
        ByVal bestRatingByTx As Object)
    Dim recordRows As Object
    Dim rowItem As Variant, sourceRow As Long, transactionID As String
    Dim i As Long
    Set recordRows = CreateObject("Scripting.Dictionary")
    recordRows.CompareMode = vbTextCompare
    For i = 1 To recordCount
        recordRows.RemoveAll
        CollectFlowRecordRows withdrawalBundles, depositBundles, links, records(i), recordRows
        For Each rowItem In recordRows.Keys
            sourceRow = CLng(rowItem)
            transactionID = CellText(sourceData(sourceRow, WORK_TX_COL_TRANSACTION_ID))
            UpdateShiftCandidateStats candidateCountByTx, bestScoreByTx, bestRatingByTx, _
                                      transactionID, records(i).Score, records(i).Rating
        Next rowItem
    Next i
End Sub

Private Sub CollectFlowRecordRows( _
        ByRef withdrawalBundles() As FlowBundle, ByRef depositBundles() As FlowBundle, _
        ByRef links() As FlowLink, ByRef record As FlowRecord, ByVal targetRows As Object)
    Dim linkParts As Variant, linkItem As Variant, linkIndex As Long
    linkParts = Split(record.LinkList, ";")
    For Each linkItem In linkParts
        linkIndex = CLng(linkItem)
        AddFlowRowsToDictionary withdrawalBundles(links(linkIndex).WithdrawalBundle).RowList, targetRows
        AddFlowRowsToDictionary depositBundles(links(linkIndex).DepositBundle).RowList, targetRows
    Next linkItem
    If Len(record.ExtraWithdrawalRows) > 0 Then _
        AddFlowRowsToDictionary record.ExtraWithdrawalRows, targetRows
    If record.OriginDepositBundle > 0 Then _
        AddFlowRowsToDictionary depositBundles(record.OriginDepositBundle).RowList, targetRows
End Sub

Private Sub WriteAdvancedFlowAnalysis( _
        ByRef sourceData As Variant, ByRef withdrawalBundles() As FlowBundle, _
        ByRef depositBundles() As FlowBundle, ByRef links() As FlowLink, _
        ByRef records() As FlowRecord, ByVal recordCount As Long, ByVal reviews As Object, _
        ByVal settingsSignature As String, ByVal candidateCountByTx As Object, _
        ByVal wsOut As Worksheet, ByRef writtenCount As Long)
    Dim buffer() As Variant
    Dim bufferCount As Long, nextOutputRow As Long, i As Long
    Dim withdrawalSet As Object, depositSet As Object, allRows As Object, accountLabels As Object
    ReDim buffer(1 To FLOW_BUFFER_ROWS, 1 To FLOW_ANALYSIS_LAST_COL)
    Set withdrawalSet = CreateObject("Scripting.Dictionary")
    Set depositSet = CreateObject("Scripting.Dictionary")
    Set allRows = CreateObject("Scripting.Dictionary")
    Set accountLabels = CreateObject("Scripting.Dictionary")
    withdrawalSet.CompareMode = vbTextCompare
    depositSet.CompareMode = vbTextCompare
    allRows.CompareMode = vbTextCompare
    accountLabels.CompareMode = vbTextCompare
    BuildFlowAccountLabelIndex sourceData, accountLabels
    nextOutputRow = 2
    For i = 1 To recordCount
        bufferCount = bufferCount + 1
        FillAdvancedFlowAnalysisRow buffer, bufferCount, sourceData, withdrawalBundles, _
                                    depositBundles, links, records(i), reviews, withdrawalSet, _
                                    depositSet, allRows, accountLabels, settingsSignature, _
                                    candidateCountByTx
        writtenCount = writtenCount + 1
        If bufferCount = FLOW_BUFFER_ROWS Then
            FlushAnalysisBuffer wsOut, buffer, bufferCount, nextOutputRow, FLOW_ANALYSIS_LAST_COL
            ReDim buffer(1 To FLOW_BUFFER_ROWS, 1 To FLOW_ANALYSIS_LAST_COL)
            bufferCount = 0
        End If
    Next i
    If bufferCount > 0 Then _
        FlushAnalysisBuffer wsOut, buffer, bufferCount, nextOutputRow, FLOW_ANALYSIS_LAST_COL
End Sub

Private Sub FillAdvancedFlowAnalysisRow( _
        ByRef buffer As Variant, ByVal bufferRow As Long, ByRef sourceData As Variant, _
        ByRef withdrawalBundles() As FlowBundle, ByRef depositBundles() As FlowBundle, _
        ByRef links() As FlowLink, ByRef record As FlowRecord, ByVal reviews As Object, _
        ByVal withdrawalSet As Object, ByVal depositSet As Object, ByVal allRows As Object, _
        ByVal accountLabels As Object, ByVal settingsSignature As String, _
        ByVal candidateCountByTx As Object)
    Dim linkParts As Variant, linkItem As Variant
    Dim firstLink As Long, lastLink As Long, linkIndex As Long, linkCount As Long
    Dim routeText As String, orderText As String, withdrawalText As String, depositText As String
    Dim reasonText As String, analysisType As String, orderDecision As String
    Dim precisionText As String, periodText As String, transactionIDs As String
    Dim evidenceRowList As String, evidenceDigest As String
    Dim originAccounts As String, endpointAccounts As String
    Dim startAmount As Double, endpointAmount As Double, differenceAmount As Double
    Dim transactionCount As Long, stageCount As Long, ambiguityCount As Long
    Dim reviewValues As Variant
    withdrawalSet.RemoveAll
    depositSet.RemoveAll
    allRows.RemoveAll

    linkParts = Split(record.LinkList, ";")
    linkCount = UBound(linkParts) - LBound(linkParts) + 1
    firstLink = CLng(linkParts(LBound(linkParts)))
    lastLink = CLng(linkParts(UBound(linkParts)))
    If record.OriginDepositBundle > 0 Then
        AddFlowRowsToDictionary depositBundles(record.OriginDepositBundle).RowList, depositSet
        AddFlowRowsToDictionary depositBundles(record.OriginDepositBundle).RowList, allRows
        routeText = FriendlyFlowBundleAccounts(depositBundles(record.OriginDepositBundle), _
                    accountLabels) & "�i�����j �� " & _
                    FriendlyFlowBundleAccounts(withdrawalBundles(links(firstLink).WithdrawalBundle), _
                    accountLabels) & "�i�o���j"
        orderText = "����[" & BuildFlowBundleDetails(sourceData, _
                    depositBundles(record.OriginDepositBundle), True) & "] �� �o��[" & _
                    BuildFlowBundleDetails(sourceData, _
                    withdrawalBundles(links(firstLink).WithdrawalBundle), False) & "]"
    End If
    For Each linkItem In linkParts
        linkIndex = CLng(linkItem)
        AddFlowRowsToDictionary withdrawalBundles(links(linkIndex).WithdrawalBundle).RowList, withdrawalSet
        AddFlowRowsToDictionary depositBundles(links(linkIndex).DepositBundle).RowList, depositSet
        AppendFlowRoute routeText, FriendlyFlowBundleAccounts( _
                        withdrawalBundles(links(linkIndex).WithdrawalBundle), accountLabels), _
                        FriendlyFlowBundleAccounts( _
                        depositBundles(links(linkIndex).DepositBundle), accountLabels)
        If record.OriginDepositBundle > 0 And linkIndex = firstLink Then
            FlowAppendText orderText, "����[" & BuildFlowBundleDetails(sourceData, _
                           depositBundles(links(linkIndex).DepositBundle), True) & "]", " �� "
        Else
            FlowAppendText orderText, BuildFlowLinkOrder(sourceData, _
                           withdrawalBundles(links(linkIndex).WithdrawalBundle), _
                           depositBundles(links(linkIndex).DepositBundle), _
                           links(linkIndex).Chronology), " / "
        End If
    Next linkItem
    CopyFlowDictionaryKeys withdrawalSet, allRows
    CopyFlowDictionaryKeys depositSet, allRows
    If Len(record.ExtraWithdrawalRows) > 0 Then
        AddFlowRowsToDictionary record.ExtraWithdrawalRows, withdrawalSet
        AddFlowRowsToDictionary record.ExtraWithdrawalRows, allRows
        FlowAppendText routeText, " �� �i���̓���������j", vbNullString
        FlowAppendText orderText, " �� �o��[" & _
                       BuildFlowRowListDetails(sourceData, record.ExtraWithdrawalRows, False) & _
                       "] �� ���̓���������", vbNullString
    End If

    If record.OriginDepositBundle > 0 Then
        startAmount = depositBundles(record.OriginDepositBundle).TotalAmount
    Else
        startAmount = withdrawalBundles(links(firstLink).WithdrawalBundle).TotalAmount
    End If
    If Len(record.ExtraWithdrawalRows) > 0 Then
        endpointAmount = SumFlowRowListAmount(sourceData, record.ExtraWithdrawalRows, False)
        endpointAccounts = "������"
    Else
        endpointAmount = depositBundles(links(lastLink).DepositBundle).TotalAmount
        endpointAccounts = depositBundles(links(lastLink).DepositBundle).AccountList
    End If
    differenceAmount = Abs(startAmount - endpointAmount)
    If record.OriginDepositBundle > 0 Then
        originAccounts = depositBundles(record.OriginDepositBundle).AccountList
    Else
        originAccounts = withdrawalBundles(links(firstLink).WithdrawalBundle).AccountList
    End If
    transactionCount = allRows.Count
    stageCount = linkCount
    If Len(record.ExtraWithdrawalRows) > 0 Then stageCount = stageCount + 1
    If record.OriginDepositBundle > 0 Then stageCount = stageCount + 1
    DetermineFlowRecordTimeAndPeriod sourceData, allRows, precisionText, periodText
    DetermineFlowRecordLabels record, linkCount, withdrawalBundles, depositBundles, links, _
                              firstLink, precisionText, analysisType, orderDecision, reasonText
    withdrawalText = BuildFlowSetDetails(sourceData, withdrawalSet, False)
    depositText = BuildFlowSetDetails(sourceData, depositSet, True)
    transactionIDs = BuildFlowTransactionIDList(sourceData, allRows)
    ambiguityCount = AnalysisMaximumCandidateCount(candidateCountByTx, transactionIDs)
    If ambiguityCount > 1 Then
        reasonText = AppendAnalysisReason(reasonText, "���������܂ތ�₪�ő�" & _
                     CStr(ambiguityCount) & "������A�m��O�ɏd�����p���m�F���Ă��������B")
    End If
    reasonText = AppendAnalysisReason(reasonText, _
                 "���͓��͍ςݎ���͈͓̔��ł̐���ł��B�����ڎ���̕s���݂��Ӗ����܂���B")
    evidenceRowList = BuildFlowEvidenceRowList(allRows)
    evidenceDigest = AnalysisEvidenceDigest(sourceData, evidenceRowList, _
                     "FLOW|" & settingsSignature & "|" & record.KeyText & _
                     "|AMB=" & CStr(ambiguityCount))
    reviewValues = AnalysisReviewValues(reviews, record.KeyText, evidenceDigest)
    If CBool(reviewValues(2)) Then
        reasonText = AppendAnalysisReason(reasonText, _
                     "�O��m�F��ɍ�������܂��͕��͏������ς�������߁A�Ċm�F�֖߂��܂����B")
        reviewValues(1) = AppendAnalysisMemo(CStr(reviewValues(1)), _
                          "[����] ��������܂��͕��͏����̕ύX�����m���A�Ċm�F�֖߂��܂����B")
    End If

    buffer(bufferRow, 1) = record.Rating
    buffer(bufferRow, 2) = record.Score
    buffer(bufferRow, 3) = analysisType
    buffer(bufferRow, 4) = orderDecision
    buffer(bufferRow, 5) = precisionText
    buffer(bufferRow, 6) = periodText
    buffer(bufferRow, 7) = stageCount
    buffer(bufferRow, 8) = transactionCount
    buffer(bufferRow, 9) = startAmount
    buffer(bufferRow, 10) = endpointAmount
    buffer(bufferRow, 11) = differenceAmount
    buffer(bufferRow, 12) = routeText
    buffer(bufferRow, 13) = orderText
    buffer(bufferRow, 14) = withdrawalText
    buffer(bufferRow, 15) = depositText
    buffer(bufferRow, 16) = reasonText
    buffer(bufferRow, 17) = reviewValues(0)
    buffer(bufferRow, 18) = reviewValues(1)
    buffer(bufferRow, 19) = AnalysisStoredKey(record.KeyText, evidenceDigest)
    buffer(bufferRow, 20) = transactionIDs
    buffer(bufferRow, 21) = originAccounts
    buffer(bufferRow, 22) = endpointAccounts
End Sub

Private Sub DetermineFlowRecordLabels( _
        ByRef record As FlowRecord, ByVal linkCount As Long, _
        ByRef withdrawalBundles() As FlowBundle, ByRef depositBundles() As FlowBundle, _
        ByRef links() As FlowLink, ByVal firstLink As Long, ByVal precisionText As String, _
        ByRef analysisType As String, ByRef orderDecision As String, ByRef reasonText As String)
    Dim withdrawalCount As Long, depositCount As Long
    Dim terminalWithdrawalCount As Long, terminalAggregateText As String
    withdrawalCount = withdrawalBundles(links(firstLink).WithdrawalBundle).ItemCount
    depositCount = depositBundles(links(firstLink).DepositBundle).ItemCount
    Select Case record.KindCode
        Case 1
            If withdrawalCount = 1 And depositCount > 1 Then
                analysisType = "1�Ε��i���������j"
            ElseIf withdrawalCount > 1 And depositCount = 1 Then
                analysisType = "����1�i���Z�����j"
            Else
                analysisType = "���Ε��i�����E���Z�j"
            End If
            orderDecision = links(firstLink).Chronology
            reasonText = CStr(withdrawalCount) & "���̏o�����v��" & CStr(depositCount) & _
                         "���̓������v�����z���e���ŏƍ��B���t�E�����E�l���̋ߐڏ�������" & _
                         "�\�������쐬���Ă��܂��B"
        Case 2
            analysisType = "�A���ړ��i" & CStr(linkCount) & "�i�j"
            orderDecision = FlowChainOrderDecision(precisionText, False, links, record.LinkList)
            reasonText = "�قȂ�����Ԃ̋��z�ߎ���" & CStr(linkCount) & _
                         "�i�ڑ����A���p�����̓�����ɍs��ꂽ�o����ǐՂ��Ă��܂��B"
        Case 3
            terminalWithdrawalCount = FlowListItemCount(record.ExtraWithdrawalRows)
            If linkCount = 1 And terminalWithdrawalCount = 1 Then
                analysisType = "���p��o���i������������j"
            ElseIf linkCount = 1 Then
                analysisType = "���p�㕡���o���i������������j"
            ElseIf terminalWithdrawalCount = 1 Then
                analysisType = "�A���{���p��o���i������������j"
            Else
                analysisType = "�A���{���p�㕡���o���i������������j"
            End If
            orderDecision = FlowChainOrderDecision(precisionText, False, links, record.LinkList)
            If terminalWithdrawalCount > 1 Then terminalAggregateText = "���v"
            reasonText = "���p�����ւ̓�����A���z�܂��͋߂����z�̏o��" & _
                         terminalAggregateText & _
                         "�܂Ŋm�F�ł��܂������A" & _
                         "���̐�̓������͓��肵�Ă��܂���B"
        Case 5
            analysisType = "�����N�_�A���i�������o���������E" & CStr(linkCount + 1) & "�i�j"
            orderDecision = FlowChainOrderDecision(precisionText, False, links, record.LinkList)
            reasonText = "��������ւ̑O�i�����ƁA���̌�̋ߎ��z�o�����N�_�Ƃ��āA" & _
                         "�����̏o���������o�H�֐ڑ����Ă��܂��B����������g�r���܂ł�" & _
                         "��̉����Ƃ��ĒǐՂ��܂��B"
        Case 6
            terminalWithdrawalCount = FlowListItemCount(record.ExtraWithdrawalRows)
            analysisType = "�����N�_�A���{�I�[�o���i������������j"
            orderDecision = FlowChainOrderDecision(precisionText, False, links, record.LinkList)
            reasonText = "�O�i�������瓯������̏o���A�ʌ����ւ̓����A����ɏI�[�o���܂�" & _
                         "�ǐՂ��܂����B���̐�̓�����͓��肵�Ă��܂���B"
        Case 7
            analysisType = "�����N�_�A���i�T�����" & CStr(FLOW_MAX_CHAIN_LEGS + 1) & "�i�j"
            orderDecision = FlowChainOrderDecision(precisionText, True, links, record.LinkList)
            reasonText = "�O�i�������܂ގ����o�H���T������ɒB�������߁A���̍s�ŋ�؂��Ă��܂��B" & _
                         "�����̌����ʂɊm�F���Ă��������B"
        Case Else
            analysisType = "�A���ړ��i�T�����" & CStr(FLOW_MAX_CHAIN_LEGS) & "�i�j"
            orderDecision = FlowChainOrderDecision(precisionText, True, links, record.LinkList)
            reasonText = "�����o�H��" & CStr(FLOW_MAX_CHAIN_LEGS) & _
                         "�i�ɒB�������߁A���̍s�ŒT������؂��Ă��܂��B�����̌����ʂɊm�F���Ă��������B"
    End Select
    If InStr(1, precisionText, "��������", vbTextCompare) = 0 Or _
       StrComp(precisionText, "�S����������", vbTextCompare) <> 0 Then
        reasonText = reasonText & " �������������͓����E�ߐړ��A���z�A���ꒆ�p�������琄�肵�Ă��܂��B"
    End If
    reasonText = reasonText & " �E�v�̗L���͌�⏜�O�����Ɏg�p���Ă��܂���B"
End Sub

Private Function FlowListItemCount(ByVal listText As String) As Long
    Dim values As Variant
    If Len(listText) = 0 Then Exit Function
    values = Split(listText, ";")
    FlowListItemCount = UBound(values) - LBound(values) + 1
End Function

Private Function FlowChainOrderDecision(ByVal precisionText As String, _
                                        ByVal reachedLimit As Boolean, _
                                        ByRef links() As FlowLink, ByVal linkList As String) As String
    Dim linkParts As Variant, item As Variant, linkIndex As Long
    Dim hasPostingOrderDifference As Boolean
    linkParts = Split(linkList, ";")
    For Each item In linkParts
        linkIndex = CLng(item)
        If StrComp(links(linkIndex).Chronology, "�o��������", vbTextCompare) <> 0 And _
           StrComp(links(linkIndex).Chronology, "������", vbTextCompare) <> 0 Then
            hasPostingOrderDifference = True
            Exit For
        End If
    Next item
    If StrComp(precisionText, "�S����������", vbTextCompare) = 0 And _
       Not hasPostingOrderDifference Then
        FlowChainOrderDecision = "�����o�H���i�S�����m�F�j"
    ElseIf StrComp(precisionText, "�S����������", vbTextCompare) = 0 Then
        FlowChainOrderDecision = "�����o�H���i�L�������ق���j"
    Else
        FlowChainOrderDecision = "�����o�H���i�����������܂ސ���j"
    End If
    If reachedLimit Then FlowChainOrderDecision = FlowChainOrderDecision & "�E�T��������B"
End Function

Private Sub DetermineFlowRecordTimeAndPeriod(ByRef sourceData As Variant, ByVal rows As Object, _
                                             ByRef precisionText As String, ByRef periodText As String)
    Dim item As Variant, sourceRow As Long, transactionDateSerial As Long
    Dim minDate As Long, maxDate As Long, anyTime As Boolean, allTimes As Boolean
    Dim timeFraction As Double, firstValue As Boolean
    allTimes = True
    firstValue = True
    For Each item In rows.Keys
        sourceRow = CLng(item)
        transactionDateSerial = CLng(VBA.DateValue(CDate(sourceData(sourceRow, OUT_COL_DATE))))
        If firstValue Or transactionDateSerial < minDate Then minDate = transactionDateSerial
        If firstValue Or transactionDateSerial > maxDate Then maxDate = transactionDateSerial
        If TryGetFlowTime(sourceData(sourceRow, OUT_COL_TIME), timeFraction) Then
            anyTime = True
        Else
            allTimes = False
        End If
        firstValue = False
    Next item
    If allTimes And rows.Count > 0 Then
        precisionText = "�S����������"
    ElseIf anyTime Then
        precisionText = "�ꕔ��������"
    Else
        precisionText = "�����Ȃ�"
    End If
    If minDate = maxDate Then
        periodText = Format$(CDate(minDate), "yyyy/m/d") & "�i�����j"
    Else
        periodText = Format$(CDate(minDate), "yyyy/m/d") & "�`" & _
                     Format$(CDate(maxDate), "yyyy/m/d") & "�i" & _
                     CStr(maxDate - minDate) & "���j"
    End If
End Sub

Private Sub AppendFlowRoute(ByRef routeText As String, ByVal sourceAccounts As String, _
                            ByVal destinationAccounts As String)
    Dim segmentText As String
    segmentText = sourceAccounts & " �� " & destinationAccounts
    FlowAppendText routeText, segmentText, " / "
End Sub

Private Function BuildFlowLinkOrder( _
        ByRef sourceData As Variant, ByRef withdrawalBundle As FlowBundle, _
        ByRef depositBundle As FlowBundle, ByVal chronology As String) As String
    Dim withdrawalDetails As String, depositDetails As String
    withdrawalDetails = BuildFlowBundleDetails(sourceData, withdrawalBundle, False)
    depositDetails = BuildFlowBundleDetails(sourceData, depositBundle, True)
    If StrComp(chronology, "�������o��", vbTextCompare) = 0 Then
        BuildFlowLinkOrder = "����[" & depositDetails & "] �� �o��[" & _
                             withdrawalDetails & "]"
    ElseIf StrComp(chronology, "���n�񍬍�", vbTextCompare) = 0 Then
        BuildFlowLinkOrder = "���n�񍬍�[" & _
                             BuildFlowMergedTimeline(sourceData, withdrawalBundle, _
                                                     depositBundle) & "]"
    ElseIf InStr(1, chronology, "�������m��", vbTextCompare) > 0 Then
        BuildFlowLinkOrder = "�������m��{�o��[" & withdrawalDetails & "] / ����[" & _
                             depositDetails & "]}�i�����o�H���j"
    Else
        BuildFlowLinkOrder = "�o��[" & withdrawalDetails & "] �� ����[" & _
                             depositDetails & "]"
        If InStr(1, chronology, "����", vbTextCompare) > 0 Then _
            BuildFlowLinkOrder = BuildFlowLinkOrder & "�i����j"
        If StrComp(chronology, "������", vbTextCompare) = 0 Then _
            BuildFlowLinkOrder = BuildFlowLinkOrder & "�i�������j"
    End If
End Function

Private Function FriendlyFlowBundleAccounts(ByRef bundle As FlowBundle, _
                                            ByVal accountLabels As Object) As String
    Dim accounts As Variant, item As Variant, accountID As String
    Dim resultText As String
    accounts = Split(bundle.AccountList, ";")
    For Each item In accounts
        accountID = CStr(item)
        If accountLabels.Exists(accountID) Then
            FlowAppendText resultText, CStr(accountLabels(accountID)), "�E"
        Else
            FlowAppendText resultText, accountID, "�E"
        End If
    Next item
    FriendlyFlowBundleAccounts = resultText
End Function

Private Sub BuildFlowAccountLabelIndex(ByRef sourceData As Variant, ByVal accountLabels As Object)
    Dim r As Long, accountID As String, labelText As String
    For r = 1 To UBound(sourceData, 1)
        accountID = CellText(sourceData(r, WORK_TX_COL_ACCOUNT_ID))
        If Len(accountID) > 0 And Not accountLabels.Exists(accountID) Then
            labelText = CellText(sourceData(r, OUT_COL_BANK))
            If HasText(sourceData(r, OUT_COL_BRANCH)) Then _
                labelText = labelText & " " & CellText(sourceData(r, OUT_COL_BRANCH))
            If HasText(sourceData(r, OUT_COL_ACCOUNT_TYPE)) Then _
                labelText = labelText & " " & CellText(sourceData(r, OUT_COL_ACCOUNT_TYPE))
            If HasText(sourceData(r, OUT_COL_ACCOUNT_NO)) Then _
                labelText = labelText & " " & CellText(sourceData(r, OUT_COL_ACCOUNT_NO))
            If Len(Trim$(labelText)) = 0 Then labelText = accountID
            accountLabels.Add accountID, Trim$(labelText)
        End If
    Next r
End Sub

Private Function BuildFlowBundleDetails(ByRef sourceData As Variant, _
                                        ByRef bundle As FlowBundle, _
                                        ByVal isDeposit As Boolean) As String
    Dim rows As Variant, rowValues() As Long
    Dim i As Long, itemCount As Long
    Dim resultText As String
    rows = Split(bundle.RowList, ";")
    itemCount = UBound(rows) - LBound(rows) + 1
    ReDim rowValues(1 To itemCount)
    For i = 1 To itemCount
        rowValues(i) = CLng(rows(LBound(rows) + i - 1))
    Next i
    If itemCount > 1 Then SortFlowDetailRows sourceData, rowValues, itemCount
    For i = 1 To itemCount
        FlowAppendText resultText, _
                       FormatFlowTransaction(sourceData, rowValues(i), isDeposit), " / "
    Next i
    BuildFlowBundleDetails = resultText
End Function

Private Function BuildFlowMergedTimeline( _
        ByRef sourceData As Variant, ByRef withdrawalBundle As FlowBundle, _
        ByRef depositBundle As FlowBundle) As String
    Dim withdrawalRows As Variant, depositRows As Variant
    Dim rowValues() As Long
    Dim item As Variant, itemCount As Long, i As Long, isDeposit As Boolean
    Dim resultText As String
    withdrawalRows = Split(withdrawalBundle.RowList, ";")
    depositRows = Split(depositBundle.RowList, ";")
    ReDim rowValues(1 To withdrawalBundle.ItemCount + depositBundle.ItemCount)
    For Each item In withdrawalRows
        itemCount = itemCount + 1
        rowValues(itemCount) = CLng(item)
    Next item
    For Each item In depositRows
        itemCount = itemCount + 1
        rowValues(itemCount) = CLng(item)
    Next item
    If itemCount > 1 Then SortFlowDetailRows sourceData, rowValues, itemCount
    For i = 1 To itemCount
        isDeposit = HasText(sourceData(rowValues(i), OUT_COL_DEPOSIT))
        FlowAppendText resultText, _
                       FormatFlowTransaction(sourceData, rowValues(i), isDeposit), " �� "
    Next i
    BuildFlowMergedTimeline = resultText
End Function

Private Sub SortFlowDetailRows(ByRef sourceData As Variant, ByRef rows() As Long, _
                               ByVal itemCount As Long)
    Dim i As Long, j As Long, valueToInsert As Long
    For i = 2 To itemCount
        valueToInsert = rows(i)
        j = i - 1
        Do While j >= 1
            If CompareFlowDetailRows(sourceData, rows(j), valueToInsert) <= 0 Then Exit Do
            rows(j + 1) = rows(j)
            j = j - 1
        Loop
        rows(j + 1) = valueToInsert
    Next i
End Sub

Private Function CompareFlowDetailRows(ByRef sourceData As Variant, _
                                       ByVal firstRow As Long, _
                                       ByVal secondRow As Long) As Long
    Dim firstDate As Long, secondDate As Long
    Dim firstTime As Double, secondTime As Double
    Dim firstHasTime As Boolean, secondHasTime As Boolean
    firstDate = CLng(VBA.DateValue(CDate(sourceData(firstRow, OUT_COL_DATE))))
    secondDate = CLng(VBA.DateValue(CDate(sourceData(secondRow, OUT_COL_DATE))))
    If firstDate < secondDate Then
        CompareFlowDetailRows = -1
        Exit Function
    ElseIf firstDate > secondDate Then
        CompareFlowDetailRows = 1
        Exit Function
    End If
    firstHasTime = TryGetFlowTime(sourceData(firstRow, OUT_COL_TIME), firstTime)
    secondHasTime = TryGetFlowTime(sourceData(secondRow, OUT_COL_TIME), secondTime)
    If firstHasTime And secondHasTime Then
        If firstTime < secondTime Then
            CompareFlowDetailRows = -1
            Exit Function
        ElseIf firstTime > secondTime Then
            CompareFlowDetailRows = 1
            Exit Function
        End If
    End If
    '�Е��ł��������Ȃ���Ήˋ󎞍��ŕ��ׂ��A������s�������肵���⏕���ɂ���B
    If firstRow < secondRow Then
        CompareFlowDetailRows = -1
    ElseIf firstRow > secondRow Then
        CompareFlowDetailRows = 1
    End If
End Function

Private Function BuildFlowRowListDetails(ByRef sourceData As Variant, _
                                         ByVal rowList As String, _
                                         ByVal isDeposit As Boolean) As String
    Dim rows As Variant, rowValues() As Long
    Dim i As Long, itemCount As Long
    Dim resultText As String
    If Len(rowList) = 0 Then Exit Function
    rows = Split(rowList, ";")
    itemCount = UBound(rows) - LBound(rows) + 1
    ReDim rowValues(1 To itemCount)
    For i = 1 To itemCount
        rowValues(i) = CLng(rows(LBound(rows) + i - 1))
    Next i
    If itemCount > 1 Then SortFlowDetailRows sourceData, rowValues, itemCount
    For i = 1 To itemCount
        FlowAppendText resultText, _
                       FormatFlowTransaction(sourceData, rowValues(i), isDeposit), " / "
    Next i
    BuildFlowRowListDetails = resultText
End Function

Private Function SumFlowRowListAmount(ByRef sourceData As Variant, ByVal rowList As String, _
                                      ByVal isDeposit As Boolean) As Double
    Dim rows As Variant, item As Variant, sourceRow As Long
    If Len(rowList) = 0 Then Exit Function
    rows = Split(rowList, ";")
    For Each item In rows
        sourceRow = CLng(item)
        If isDeposit Then
            SumFlowRowListAmount = SumFlowRowListAmount + CDbl(sourceData(sourceRow, OUT_COL_DEPOSIT))
        Else
            SumFlowRowListAmount = SumFlowRowListAmount + CDbl(sourceData(sourceRow, OUT_COL_WITHDRAW))
        End If
    Next item
End Function

Private Function BuildFlowSetDetails(ByRef sourceData As Variant, ByVal rows As Object, _
                                     ByVal isDeposit As Boolean) As String
    Dim item As Variant, rowValues() As Long
    Dim itemCount As Long, i As Long
    Dim resultText As String
    If rows Is Nothing Then Exit Function
    If rows.Count = 0 Then Exit Function
    ReDim rowValues(1 To rows.Count)
    For Each item In rows.Keys
        itemCount = itemCount + 1
        rowValues(itemCount) = CLng(item)
    Next item
    If itemCount > 1 Then SortFlowDetailRows sourceData, rowValues, itemCount
    For i = 1 To itemCount
        FlowAppendText resultText, _
                       FormatFlowTransaction(sourceData, rowValues(i), isDeposit), " / "
    Next i
    BuildFlowSetDetails = resultText
End Function

Private Function FormatFlowTransaction(ByRef sourceData As Variant, ByVal sourceRow As Long, _
                                       ByVal isDeposit As Boolean) As String
    Dim timeText As String, accountText As String, amountValue As Double
    Dim timeFraction As Double, kindText As String
    If TryGetFlowTime(sourceData(sourceRow, OUT_COL_TIME), timeFraction) Then
        timeText = Format$(timeFraction, "hh:mm")
    Else
        timeText = "--:--"
    End If
    accountText = CellText(sourceData(sourceRow, OUT_COL_BANK))
    If HasText(sourceData(sourceRow, OUT_COL_BRANCH)) Then _
        accountText = accountText & " " & CellText(sourceData(sourceRow, OUT_COL_BRANCH))
    If HasText(sourceData(sourceRow, OUT_COL_ACCOUNT_TYPE)) Then _
        accountText = accountText & " " & CellText(sourceData(sourceRow, OUT_COL_ACCOUNT_TYPE))
    If HasText(sourceData(sourceRow, OUT_COL_ACCOUNT_NO)) Then _
        accountText = accountText & " " & CellText(sourceData(sourceRow, OUT_COL_ACCOUNT_NO))
    If isDeposit Then
        amountValue = CDbl(sourceData(sourceRow, OUT_COL_DEPOSIT))
        kindText = "����"
    Else
        amountValue = CDbl(sourceData(sourceRow, OUT_COL_WITHDRAW))
        kindText = "�o��"
    End If
    FormatFlowTransaction = Format$(CDate(sourceData(sourceRow, OUT_COL_DATE)), "yyyy/m/d") & _
                            " " & timeText & " " & Trim$(accountText) & " " & kindText & _
                            " " & Format$(amountValue, "#,##0.########")
End Function

Private Function BuildFlowTransactionIDList(ByRef sourceData As Variant, _
                                            ByVal rows As Object) As String
    Dim values() As String, item As Variant, itemCount As Long
    If rows.Count = 0 Then Exit Function
    ReDim values(1 To rows.Count)
    For Each item In rows.Keys
        itemCount = itemCount + 1
        values(itemCount) = CellText(sourceData(CLng(item), WORK_TX_COL_TRANSACTION_ID))
    Next item
    If itemCount > 1 Then SortTextValues values, itemCount
    BuildFlowTransactionIDList = JoinTextValues(values, itemCount)
End Function

Private Function BuildFlowEvidenceRowList(ByVal rows As Object) As String
    Dim values() As Long, item As Variant, itemCount As Long
    If rows.Count = 0 Then Exit Function
    ReDim values(1 To rows.Count)
    For Each item In rows.Keys
        itemCount = itemCount + 1
        values(itemCount) = CLng(item)
    Next item
    If itemCount > 1 Then SortLongValues values, itemCount
    BuildFlowEvidenceRowList = JoinLongValues(values, itemCount)
End Function

Private Sub CopyFlowDictionaryKeys(ByVal sourceValues As Object, ByVal targetValues As Object)
    Dim item As Variant
    For Each item In sourceValues.Keys
        If Not targetValues.Exists(CStr(item)) Then targetValues.Add CStr(item), True
    Next item
End Sub

Private Sub FlowAppendText(ByRef targetText As String, ByVal newText As String, _
                           ByVal separatorText As String)
    Dim availableChars As Long
    If Len(newText) = 0 Or Len(targetText) >= FLOW_DETAIL_MAX_CHARS Then Exit Sub
    availableChars = FLOW_DETAIL_MAX_CHARS - Len(targetText)
    If Len(targetText) > 0 And Len(separatorText) > 0 Then
        If availableChars <= Len(separatorText) Then Exit Sub
        targetText = targetText & separatorText
        availableChars = FLOW_DETAIL_MAX_CHARS - Len(targetText)
    End If
    If Len(newText) <= availableChars Then
        targetText = targetText & newText
    ElseIf availableChars > 1 Then
        targetText = targetText & Left$(newText, availableChars - 1) & "�c"
    End If
End Sub

Private Function TryGetFlowTime(ByVal valueIn As Variant, ByRef timeFraction As Double) As Boolean
    Dim ok As Boolean, normalizedTime As Variant
    If Not HasText(valueIn) Then Exit Function
    normalizedTime = NormalizeTimeInput(valueIn, ok)
    If Not ok Then Exit Function
    timeFraction = CDbl(CDate(normalizedTime)) - Fix(CDbl(CDate(normalizedTime)))
    TryGetFlowTime = True
End Function

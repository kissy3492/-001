Attribute VB_Name = "modBalanceReconciliation"
Option Explicit

'�ʒ��ɋL�ڂ��ꂽ�����c�����A���O�̊��m�c���Ƃ��̊Ԃ̓��o������Čv�Z����B
'�����������铯������͓��͏����g���A����������s����������ł��邱�Ƃ�\������B

Private Const RECON_BUFFER_ROWS As Long = 1000
Private Const RECON_EPSILON As Double = 0.00000001

Public Function BalanceReconciliationHeaders() As Variant
    BalanceReconciliationHeaders = Array( _
        "����", "�O����m�c������", "����c������", "�Ώێ����", _
        "�O��c��", "���o�����z", "�v�Z�c��", "�L�ڎc��", "���z�E�������x")
End Function

Public Sub SetupBalanceReconciliationSheet(Optional ByVal resetContents As Boolean = False)
    Dim ws As Worksheet
    Set ws = GetOrCreateSheet(SH_BALANCE_RECONCILIATION, False)
    ws.Unprotect Password:=TOOL_PASSWORD
    If resetContents Then ResetWorksheet ws
    If Len(CellText(ws.Cells(1, 1).Value)) = 0 Then _
        SetRowValues ws.Range("A1"), BalanceReconciliationHeaders()
    FormatOutputHeader ws.Range(ws.Cells(1, 1), _
                                ws.Cells(1, BALANCE_RECONCILIATION_LAST_COL))
    ws.Columns("A:A").ColumnWidth = 42
    ws.Columns("B:C").ColumnWidth = 24
    ws.Columns("D:D").ColumnWidth = 12
    ws.Columns("E:H").ColumnWidth = 17
    ws.Columns("I:I").ColumnWidth = 40
    ws.Columns("B:C").NumberFormatLocal = "@"
    ws.Columns("D:D").NumberFormatLocal = "0"
    ws.Columns("E:H").NumberFormatLocal = "#,##0.########"
    ProtectSingleAnalysisSheet ws
    If LastUsedRowInSheet(ws) < 2 Then SetSheetVeryHiddenSafe ws
End Sub

Public Sub BuildBalanceReconciliationCore(Optional ByVal activateAfter As Boolean = False)
    Dim wsTx As Worksheet, wsOut As Worksheet
    Dim data As Variant, lastR As Long, sourceCount As Long
    Dim rows() As Long, rowCount As Long, r As Long, sourceRow As Long
    Dim dayHasMissing As Object, dayKey As String
    Dim currentAccount As String, previousAccount As String
    Dim baselineSet As Boolean, baselineBalance As Double, runningDelta As Double
    Dim runningCompensation As Double, stableDelta As Double
    Dim actualBalance As Double, expectedBalance As Double, difference As Double
    Dim tolerance As Double
    Dim intervalCount As Long, intervalMissingTime As Boolean
    Dim previousStamp As String, currentStamp As String, orderText As String
    Dim buffer() As Variant, bufferCount As Long, nextOutputRow As Long, outputCount As Long
    Set wsTx = GetSheet(SH_WORK_TX)
    SetupBalanceReconciliationSheet True
    Set wsOut = GetSheet(SH_BALANCE_RECONCILIATION)
    lastR = LastUsedRowInSheet(wsTx)
    If lastR < 2 Then Exit Sub
    data = wsTx.Range(wsTx.Cells(2, 1), wsTx.Cells(lastR, WORK_TX_COL_PERSON_ID)).Value2
    sourceCount = UBound(data, 1)
    ReDim rows(1 To sourceCount)
    Set dayHasMissing = CreateObject("Scripting.Dictionary")
    dayHasMissing.CompareMode = vbTextCompare
    For r = 1 To sourceCount
        If CellText(data(r, WORK_TX_COL_RECORD_TYPE)) = RECORD_TRANSACTION Then
            If Not IsDate(data(r, OUT_COL_DATE)) Then _
                Err.Raise vbObjectError + 4970, "BuildBalanceReconciliationCore", _
                          "W_��� " & CStr(r + 1) & "�s�ڂ̓��t���s���ł��B"
            currentAccount = CellText(data(r, WORK_TX_COL_ACCOUNT_ID))
            If Len(currentAccount) = 0 Then _
                Err.Raise vbObjectError + 4971, "BuildBalanceReconciliationCore", _
                          "W_��� " & CStr(r + 1) & "�s�ڂ̌���ID������܂���B"
            rowCount = rowCount + 1
            rows(rowCount) = r
            dayKey = ReconciliationDayKey(data, r)
            If Not HasText(data(r, OUT_COL_TIME)) Then dayHasMissing(dayKey) = True
        End If
    Next r
    If rowCount = 0 Then Exit Sub
    ReDim Preserve rows(1 To rowCount)
    If rowCount > 1 Then QuickSortReconciliationRows data, rows, 1, rowCount, dayHasMissing
    ReDim buffer(1 To RECON_BUFFER_ROWS, 1 To BALANCE_RECONCILIATION_LAST_COL)
    nextOutputRow = 2
    For r = 1 To rowCount
        sourceRow = rows(r)
        currentAccount = CellText(data(sourceRow, WORK_TX_COL_ACCOUNT_ID))
        If StrComp(currentAccount, previousAccount, vbBinaryCompare) <> 0 Then
            previousAccount = currentAccount
            baselineSet = False: runningDelta = 0: runningCompensation = 0
            intervalCount = 0
            intervalMissingTime = False: previousStamp = vbNullString
        End If
        If baselineSet Then
            AddReconciliationDelta runningDelta, runningCompensation, _
                                   ReconciliationDelta(data, sourceRow)
            intervalCount = intervalCount + 1
            If Not HasText(data(sourceRow, OUT_COL_TIME)) Then intervalMissingTime = True
        End If
        If HasText(data(sourceRow, OUT_COL_OTHER)) Then
            If Not IsNumeric(data(sourceRow, OUT_COL_OTHER)) Then _
                Err.Raise vbObjectError + 4972, "BuildBalanceReconciliationCore", _
                          "W_��� " & CStr(sourceRow + 1) & "�s�ڂ̎����c�����s���ł��B"
            actualBalance = CDbl(data(sourceRow, OUT_COL_OTHER))
            currentStamp = ReconciliationDateTimeText(data, sourceRow)
            If baselineSet Then
                stableDelta = runningDelta + runningCompensation
                expectedBalance = baselineBalance + stableDelta
                difference = actualBalance - expectedBalance
                tolerance = ReconciliationTolerance(baselineBalance, stableDelta, actualBalance)
                If Abs(difference) > tolerance Then
                    outputCount = outputCount + 1
                    If outputCount > MAX_ANALYSIS_OUTPUT_ROWS Then _
                        Err.Raise vbObjectError + 4973, "BuildBalanceReconciliationCore", _
                                  "�c�����Z�̕s��v���������p����𒴂��܂����B"
                    bufferCount = bufferCount + 1
                    If intervalMissingTime Then
                        orderText = "�����s�����܂ށE���͏�����"
                    Else
                        orderText = "���t�E��������"
                    End If
                    FillReconciliationBuffer buffer, bufferCount, data, sourceRow, _
                                             previousStamp, currentStamp, intervalCount, _
                                             baselineBalance, stableDelta, expectedBalance, _
                                             actualBalance, difference, orderText
                    If bufferCount = RECON_BUFFER_ROWS Then
                        FlushReconciliationBuffer wsOut, buffer, bufferCount, nextOutputRow
                        ReDim buffer(1 To RECON_BUFFER_ROWS, 1 To BALANCE_RECONCILIATION_LAST_COL)
                        bufferCount = 0
                    End If
                End If
            End If
            baselineSet = True
            baselineBalance = actualBalance
            previousStamp = currentStamp
            runningDelta = 0: runningCompensation = 0: intervalCount = 0
            intervalMissingTime = Not HasText(data(sourceRow, OUT_COL_TIME))
        End If
    Next r
    If bufferCount > 0 Then FlushReconciliationBuffer wsOut, buffer, bufferCount, nextOutputRow
    FinalizeBalanceReconciliation wsOut, outputCount
    If outputCount > 0 Then
        wsOut.Visible = xlSheetVisible
        If activateAfter Then wsOut.Activate
    Else
        SetSheetVeryHiddenSafe wsOut
    End If
End Sub

Private Sub FillReconciliationBuffer(ByRef buffer As Variant, ByVal bufferRow As Long, _
                                     ByRef data As Variant, ByVal sourceRow As Long, _
                                     ByVal previousStamp As String, ByVal currentStamp As String, _
                                     ByVal intervalCount As Long, ByVal baseline As Double, _
                                     ByVal netAmount As Double, ByVal expected As Double, _
                                     ByVal actual As Double, ByVal difference As Double, _
                                     ByVal orderText As String)
    buffer(bufferRow, 1) = ReconciliationAccountText(data, sourceRow)
    buffer(bufferRow, 2) = previousStamp
    buffer(bufferRow, 3) = currentStamp
    buffer(bufferRow, 4) = intervalCount
    buffer(bufferRow, 5) = baseline
    buffer(bufferRow, 6) = netAmount
    buffer(bufferRow, 7) = expected
    buffer(bufferRow, 8) = actual
    buffer(bufferRow, 9) = "���z " & Format$(difference, "#,##0.########") & " / " & orderText
End Sub

Private Sub FlushReconciliationBuffer(ByVal ws As Worksheet, ByRef buffer As Variant, _
                                      ByVal itemCount As Long, ByRef nextOutputRow As Long)
    Dim outputData() As Variant, r As Long, c As Long
    ReDim outputData(1 To itemCount, 1 To BALANCE_RECONCILIATION_LAST_COL)
    For r = 1 To itemCount
        For c = 1 To BALANCE_RECONCILIATION_LAST_COL
            outputData(r, c) = buffer(r, c)
        Next c
    Next r
    ws.Range(ws.Cells(nextOutputRow, 1), _
             ws.Cells(nextOutputRow + itemCount - 1, BALANCE_RECONCILIATION_LAST_COL)).Value = outputData
    nextOutputRow = nextOutputRow + itemCount
End Sub

Private Sub FinalizeBalanceReconciliation(ByVal ws As Worksheet, ByVal dataCount As Long)
    Dim lastR As Long
    lastR = dataCount + 1
    ws.Unprotect Password:=TOOL_PASSWORD
    FormatOutputHeader ws.Range(ws.Cells(1, 1), ws.Cells(1, BALANCE_RECONCILIATION_LAST_COL))
    If dataCount > 0 Then
        With ws.Range(ws.Cells(2, 1), ws.Cells(lastR, BALANCE_RECONCILIATION_LAST_COL))
            .Borders.LineStyle = xlContinuous
            .Borders.Color = RGB(226, 232, 240)
            .VerticalAlignment = xlTop
            .WrapText = True
        End With
        ws.Range(ws.Cells(2, 9), ws.Cells(lastR, 9)).Interior.Color = RGB(254, 226, 226)
        ws.Rows("2:" & CStr(lastR)).RowHeight = 40
    End If
    If ws.AutoFilterMode Then ws.AutoFilterMode = False
    ws.Range(ws.Cells(1, 1), ws.Cells(lastR, BALANCE_RECONCILIATION_LAST_COL)).AutoFilter
    SafeFreezeOutputHeader ws
    ProtectSingleAnalysisSheet ws
End Sub

Private Sub QuickSortReconciliationRows(ByRef data As Variant, ByRef rows() As Long, _
                                        ByVal firstIndex As Long, ByVal lastIndex As Long, _
                                        ByVal dayHasMissing As Object)
    Dim low As Long, high As Long, pivotRow As Long, tempRow As Long
    low = firstIndex: high = lastIndex: pivotRow = rows((firstIndex + lastIndex) \ 2)
    Do While low <= high
        Do While CompareReconciliationRows(data, rows(low), pivotRow, dayHasMissing) < 0
            low = low + 1
        Loop
        Do While CompareReconciliationRows(data, rows(high), pivotRow, dayHasMissing) > 0
            high = high - 1
        Loop
        If low <= high Then
            tempRow = rows(low): rows(low) = rows(high): rows(high) = tempRow
            low = low + 1: high = high - 1
        End If
    Loop
    If firstIndex < high Then QuickSortReconciliationRows data, rows, firstIndex, high, dayHasMissing
    If low < lastIndex Then QuickSortReconciliationRows data, rows, low, lastIndex, dayHasMissing
End Sub

Private Function CompareReconciliationRows(ByRef data As Variant, ByVal firstRow As Long, _
                                           ByVal secondRow As Long, _
                                           ByVal dayHasMissing As Object) As Long
    Dim compareValue As Long, firstDate As Long, secondDate As Long
    Dim firstOrder As Double, secondOrder As Double, firstTime As Double, secondTime As Double
    Dim dayKey As String
    compareValue = StrComp(CellText(data(firstRow, WORK_TX_COL_ACCOUNT_ID)), _
                           CellText(data(secondRow, WORK_TX_COL_ACCOUNT_ID)), vbBinaryCompare)
    If compareValue <> 0 Then CompareReconciliationRows = compareValue: Exit Function
    firstDate = CLng(VBA.DateValue(CDate(data(firstRow, OUT_COL_DATE))))
    secondDate = CLng(VBA.DateValue(CDate(data(secondRow, OUT_COL_DATE))))
    If firstDate < secondDate Then CompareReconciliationRows = -1: Exit Function
    If firstDate > secondDate Then CompareReconciliationRows = 1: Exit Function
    dayKey = ReconciliationDayKey(data, firstRow)
    firstOrder = ReconciliationNumber(data(firstRow, WORK_TX_COL_INPUT_ORDER))
    secondOrder = ReconciliationNumber(data(secondRow, WORK_TX_COL_INPUT_ORDER))
    If Not dayHasMissing.Exists(dayKey) Then
        firstTime = ReconciliationTimeNumber(data(firstRow, OUT_COL_TIME))
        secondTime = ReconciliationTimeNumber(data(secondRow, OUT_COL_TIME))
        If firstTime < secondTime Then CompareReconciliationRows = -1: Exit Function
        If firstTime > secondTime Then CompareReconciliationRows = 1: Exit Function
    End If
    If firstOrder < secondOrder Then CompareReconciliationRows = -1 ElseIf firstOrder > secondOrder Then CompareReconciliationRows = 1 ElseIf firstRow < secondRow Then CompareReconciliationRows = -1 ElseIf firstRow > secondRow Then CompareReconciliationRows = 1
End Function

Private Function ReconciliationDayKey(ByRef data As Variant, ByVal rowNo As Long) As String
    ReconciliationDayKey = CellText(data(rowNo, WORK_TX_COL_ACCOUNT_ID)) & "|" & _
                           Format$(CDate(data(rowNo, OUT_COL_DATE)), "yyyymmdd")
End Function

Private Function ReconciliationDelta(ByRef data As Variant, ByVal rowNo As Long) As Double
    ReconciliationDelta = ReconciliationNumber(data(rowNo, OUT_COL_DEPOSIT)) - _
                          ReconciliationNumber(data(rowNo, OUT_COL_WITHDRAW))
End Function

'Neumaier�⏞�a�ŁA�����̏��z�����傫�Ȋ�c���ɑ΂���ۂߌ덷�̒~�ς�}����B
Private Sub AddReconciliationDelta(ByRef runningTotal As Double, _
                                   ByRef compensation As Double, _
                                   ByVal valueToAdd As Double)
    Dim newTotal As Double
    newTotal = runningTotal + valueToAdd
    If Abs(runningTotal) >= Abs(valueToAdd) Then
        compensation = compensation + ((runningTotal - newTotal) + valueToAdd)
    Else
        compensation = compensation + ((valueToAdd - newTotal) + runningTotal)
    End If
    runningTotal = newTotal
End Sub

'�Œ苖�e���ɉ����AExcel�̔{���x���ŕ\���\�Ȗ�4 ULP������ړx�ɉ����ċ��e����B
'����ɂ��v�Z�@�ۂ߂����̋U�s��v�������A�\���\�Ȏ��z���͎c���B
Private Function ReconciliationTolerance(ByVal baseline As Double, _
                                         ByVal netAmount As Double, _
                                         ByVal actual As Double) As Double
    Const DOUBLE_EPSILON As Double = 2.22044604925031E-16
    Dim scaleValue As Double, floatingAllowance As Double
    scaleValue = Abs(baseline)
    If Abs(netAmount) > scaleValue Then scaleValue = Abs(netAmount)
    If Abs(actual) > scaleValue Then scaleValue = Abs(actual)
    floatingAllowance = scaleValue * DOUBLE_EPSILON * 4#
    If floatingAllowance > RECON_EPSILON Then
        ReconciliationTolerance = floatingAllowance
    Else
        ReconciliationTolerance = RECON_EPSILON
    End If
End Function

Private Function ReconciliationNumber(ByVal valueIn As Variant) As Double
    If IsError(valueIn) Or IsNull(valueIn) Or IsEmpty(valueIn) Then Exit Function
    If IsNumeric(valueIn) Then ReconciliationNumber = CDbl(valueIn)
End Function

Private Function ReconciliationTimeNumber(ByVal valueIn As Variant) As Double
    If HasText(valueIn) Then ReconciliationTimeNumber = CDbl(VBA.TimeValue(CDate(valueIn)))
End Function

Private Function ReconciliationDateTimeText(ByRef data As Variant, ByVal rowNo As Long) As String
    ReconciliationDateTimeText = Format$(CDate(data(rowNo, OUT_COL_DATE)), "yyyy/m/d") & " "
    If HasText(data(rowNo, OUT_COL_TIME)) Then
        ReconciliationDateTimeText = ReconciliationDateTimeText & _
                                     Format$(VBA.TimeValue(CDate(data(rowNo, OUT_COL_TIME))), "hh:mm")
    Else
        ReconciliationDateTimeText = ReconciliationDateTimeText & "--:--"
    End If
End Function

Private Function ReconciliationAccountText(ByRef data As Variant, ByVal rowNo As Long) As String
    ReconciliationAccountText = CellText(data(rowNo, OUT_COL_PERSON)) & " / " & _
        CellText(data(rowNo, OUT_COL_BANK)) & " " & CellText(data(rowNo, OUT_COL_BRANCH)) & _
        " " & CellText(data(rowNo, OUT_COL_ACCOUNT_TYPE)) & " " & _
        CellText(data(rowNo, OUT_COL_ACCOUNT_NO))
End Function

Public Sub CheckBalanceReconciliation(ByRef problems As String)
    Dim ws As Worksheet, lastR As Long, data As Variant, r As Long
    Dim tolerance As Double
    If Not SheetExists(SH_BALANCE_RECONCILIATION) Then
        problems = problems & "�E�c�����Z�V�[�g������܂���" & vbCrLf
        Exit Sub
    End If
    Set ws = GetSheet(SH_BALANCE_RECONCILIATION)
    lastR = LastUsedRowInSheet(ws)
    If lastR >= 2 Then
        data = ws.Range(ws.Cells(2, 1), _
                        ws.Cells(lastR, BALANCE_RECONCILIATION_LAST_COL)).Value2
        For r = 1 To UBound(data, 1)
            If Len(CellText(data(r, 1))) = 0 Or Not IsNumeric(data(r, 4)) Or _
               Not IsNumeric(data(r, 5)) Or Not IsNumeric(data(r, 6)) Or _
               Not IsNumeric(data(r, 7)) Or Not IsNumeric(data(r, 8)) Then
                problems = problems & "�E�c�����Z " & CStr(r + 1) & "�s: �l���s���ł�" & vbCrLf
            Else
                tolerance = ReconciliationTolerance(CDbl(data(r, 5)), _
                                                    CDbl(data(r, 6)), _
                                                    CDbl(data(r, 8)))
                If Abs(CDbl(data(r, 8)) - CDbl(data(r, 7))) <= tolerance Then
                    problems = problems & "�E�c�����Z " & CStr(r + 1) & _
                               "�s: �v�Z�덷�͈͂̍s���c���Ă��܂�" & vbCrLf
                ElseIf Abs((CDbl(data(r, 5)) + CDbl(data(r, 6))) - _
                           CDbl(data(r, 7))) > tolerance Then
                    problems = problems & "�E�c�����Z " & CStr(r + 1) & _
                               "�s: �v�Z�c��������ƈ�v���܂���" & vbCrLf
                End If
            End If
            If Len(problems) > 700000 Then Exit For
        Next r
    End If
    If Not ws.ProtectContents Then problems = problems & "�E�c�����Z�V�[�g���ی삳��Ă��܂���" & vbCrLf
End Sub

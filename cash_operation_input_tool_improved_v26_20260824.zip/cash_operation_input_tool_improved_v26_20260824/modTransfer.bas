Attribute VB_Name = "modTransfer"
Option Explicit

Private Const MAX_ACCOUNT_REBUILD_RECORDS As Long = 100000

'���Ń}�N�����͎c���A�����{�^���◘�p�҂̃V���[�g�J�b�g���󂳂Ȃ��B
Public Sub TransferCurrentAccount()
    SaveCurrentAccount
End Sub

Public Sub TransferCurrentAccountKeepBankBranch()
    SaveCurrentAccountCore KEEP_BANK_BRANCH, False
End Sub

Public Sub TransferCurrentAccountNextBranch()
    SaveCurrentAccountNextBranch
End Sub

Public Sub SaveCurrentAccount()
    SaveCurrentAccountCore "", False
End Sub

Public Sub SaveCurrentAccountNextBranch()
    If IsEditMode() Then
        SetInputStatus "�������́A��Ɂu�����𔽉f�v�����s���Ă��������B"
        Exit Sub
    End If
    SaveCurrentAccountCore KEEP_BANK_BRANCH_PERSON_TYPE, True
End Sub

Private Sub SaveCurrentAccountCore(Optional ByVal keepOverride As String = "", _
                                   Optional ByVal nextBranchAfter As Boolean = False)
    Dim wsIn As Worksheet, wsTx As Worksheet, wsBal As Worksheet, wsAcc As Worksheet
    Dim bankName As String, branchName As String, personName As String
    Dim relationshipText As String, accountType As String, accountNo As String
    Dim rawOpen As Variant, rawClose As Variant, openDate As Variant, closeDate As Variant
    Dim dateOK As Boolean, timeOK As Boolean, amountOK As Boolean
    Dim currentYear As Long, currentMonth As Long, currentDay As Long, yearAdd As Long
    Dim txDate As Variant, txTime As Variant, amountValue As Variant
    Dim withdrawValue As Variant, depositValue As Variant, balanceValue As Variant
    Dim tekiyoText As String, previousTekiyo As String
    Dim validationCount As Long, firstMessage As String, firstAddress As String
    Dim r As Long, c As Long, memoCol As Long, lastInputRow As Long
    Dim txCount As Long, balCount As Long, userTxCount As Long
    Dim txCapacity As Long, balCapacity As Long, storedBalanceCount As Long
    Dim preservedHiddenBalanceCount As Long
    Dim txData() As Variant, balData() As Variant
    Dim accountID As String, editAccountID As String, duplicateID As String
    Dim transferID As String, personID As String, nextAccountNo As String
    Dim focusPolicy As String
    Dim oldTx As Variant, oldBal As Variant, oldMaster As Variant
    Dim idCounterSnapshot As Variant
    Dim oldTxCount As Long, oldBalCount As Long, oldMasterRow As Long
    Dim writeStarted As Boolean, committed As Boolean, idCountersCaptured As Boolean
    Dim rollbackVerified As Boolean
    Dim newTxFirst As Long, newBalFirst As Long
    Dim errorNumber As Long, errorDescription As String
    Dim rollbackDetail As String, rollbackVerifyDetail As String
    Dim balanceStructureDetail As String
    Dim postProcessDetail As String, postProcessSuffix As String, retentionWarning As String

    If Not RequireToolReady() Then Exit Sub
    If Not RequireInternalStoresSafeForWrite() Then Exit Sub
    On Error GoTo EH
    AppBegin "���͓��e�����؂��Ă��܂�..."
    Set wsIn = GetSheet(SH_INPUT)
    Set wsTx = GetSheet(SH_WORK_TX)
    Set wsBal = GetSheet(SH_WORK_BAL)
    Set wsAcc = GetSheet(SH_WORK_ACCOUNT)
    CheckUnsupportedInputCells wsIn, validationCount, firstMessage, firstAddress
    If Not ValidateBalanceInputStructure(wsIn, balanceStructureDetail) Then
        AddValidationError "�c���������݂̐ݒ�ƈ�v���܂���B�ݒ��ʂŁu" & _
                           "�c�������Đ����v�����s���Ă��������B", CELL_OPEN_DATE, _
                           validationCount, firstMessage, firstAddress
    End If

    bankName = CellText(wsIn.Range(CELL_BANK).Value)
    branchName = CellText(wsIn.Range(CELL_BRANCH).Value)
    personName = CellText(wsIn.Range(CELL_PERSON).Value)
    relationshipText = CellText(wsIn.Range(CELL_RELATIONSHIP).Value)
    If Len(relationshipText) = 0 Then relationshipText = RelationshipForName(personName)
    accountType = CellText(wsIn.Range(CELL_ACCOUNT_TYPE).Value)
    accountNo = NormalizeAccountHyphen(CellText(wsIn.Range(CELL_ACCOUNT_NO).Value))
    rawOpen = wsIn.Range(CELL_OPEN_DATE).Value
    rawClose = wsIn.Range(CELL_CLOSE_DATE).Value

    AddRequiredError bankName, "��s������͂��Ă��������B", CELL_BANK, validationCount, firstMessage, firstAddress
    AddRequiredError personName, "��������͂��Ă��������B", CELL_PERSON, validationCount, firstMessage, firstAddress
    AddRequiredError accountType, "�Ȗڂ���͂��Ă��������B���ɂȂ��Ȗڂ����ړ��͂ł��܂��B", CELL_ACCOUNT_TYPE, validationCount, firstMessage, firstAddress
    AddRequiredError accountNo, "�����ԍ�����͂��Ă��������B", CELL_ACCOUNT_NO, validationCount, firstMessage, firstAddress
    AddMaxLengthError bankName, 100, "��s��", CELL_BANK, validationCount, firstMessage, firstAddress
    AddMaxLengthError branchName, 100, "�x�X��", CELL_BRANCH, validationCount, firstMessage, firstAddress
    AddMaxLengthError personName, 100, "����", CELL_PERSON, validationCount, firstMessage, firstAddress
    AddMaxLengthError relationshipText, 50, "����", CELL_RELATIONSHIP, validationCount, firstMessage, firstAddress
    AddMaxLengthError accountType, 100, "�Ȗ�", CELL_ACCOUNT_TYPE, validationCount, firstMessage, firstAddress
    AddMaxLengthError accountNo, 100, "�����ԍ�", CELL_ACCOUNT_NO, validationCount, firstMessage, firstAddress

    If HasText(rawOpen) Then
        openDate = ResolveAccountDateInput(rawOpen, dateOK)
        If Not dateOK Then AddValidationError "�����J�ݓ�����t�Ƃ��ĉ��߂ł��܂���B", CELL_OPEN_DATE, validationCount, firstMessage, firstAddress
    Else
        openDate = ""
    End If
    If HasText(rawClose) Then
        closeDate = ResolveAccountDateInput(rawClose, dateOK)
        If Not dateOK Then AddValidationError "������������t�Ƃ��ĉ��߂ł��܂���B", CELL_CLOSE_DATE, validationCount, firstMessage, firstAddress
    Else
        closeDate = ""
    End If
    If IsDate(openDate) And IsDate(closeDate) Then
        If CDate(openDate) > CDate(closeDate) Then
            AddValidationError "���������������J�ݓ����O�ł��B", CELL_CLOSE_DATE, validationCount, firstMessage, firstAddress
        End If
    End If

    editAccountID = CurrentEditAccountID()
    If Len(editAccountID) > 0 And FindAccountRowByID(editAccountID) = 0 Then
        AddValidationError "�����Ώۂ̌�����������܂���B�o�^�ς݌�������I�ђ����Ă��������B", CELL_BANK, validationCount, firstMessage, firstAddress
    End If
    If Len(bankName) > 0 And Len(accountType) > 0 And Len(accountNo) > 0 Then
        duplicateID = FindAccountIDByLocator(bankName, branchName, accountType, accountNo, editAccountID)
        If Len(duplicateID) > 0 Then
            AddValidationError "������s�E�x�X�E�ȖځE�����ԍ��̌����͊��ɓo�^�ς݂ł��B���`�������o�^�ς݌�������s���Ă��������B", _
                               CELL_ACCOUNT_NO, validationCount, firstMessage, firstAddress
        End If
    End If

    If Len(editAccountID) > 0 Then
        storedBalanceCount = CountAccountRecords(wsBal, WORK_BAL_COL_ACCOUNT_ID, editAccountID)
        If storedBalanceCount > MAX_ACCOUNT_REBUILD_RECORDS Then
            AppEnd
            SetInputStatus "�����Ώۂ̎c���s�����p����𒴂��Ă��܂��B�Č��𕪊����Ă��������B"
            AddCheck "�G���[", "��������", "�c���s��" & Format$(storedBalanceCount, "#,##0") & _
                     "������A�����p�č\�z����𒴂��Ă��܂�: " & editAccountID
            Exit Sub
        End If
    End If

    txCapacity = (TX_LAST_ROW - TX_FIRST_ROW + 1) + BAL_MAX_LABELS + storedBalanceCount + 2
    balCapacity = BAL_MAX_LABELS + storedBalanceCount
    If balCapacity < 1 Then balCapacity = 1
    ReDim txData(1 To txCapacity, 1 To WORK_TX_COL_PERSON_ID)
    ReDim balData(1 To balCapacity, 1 To WORK_BAL_COL_PERSON_ID)

    If IsDate(openDate) Then
        txCount = txCount + 1
        FillPreparedTx txData, txCount, bankName, branchName, personName, relationshipText, accountType, accountNo, _
                       CDate(openDate), "", "", "", "", "", "�����J�ݓ�", "", RECORD_OPEN, 0
    End If
    If IsDate(closeDate) Then
        txCount = txCount + 1
        FillPreparedTx txData, txCount, bankName, branchName, personName, relationshipText, accountType, accountNo, _
                       CDate(closeDate), "", "", "", "", "", "��������", "", RECORD_CLOSE, 999999
    End If

    yearAdd = GetCfgLong(ROW_CFG_YEAR_ADD, 2000)
    lastInputRow = LastInputTransactionRow(wsIn)
    For r = TX_FIRST_ROW To lastInputRow
        If Not IsTransactionRowBlank(wsIn, r) Then
            txDate = ResolveInputDate(wsIn.Cells(r, COL_TX_YEAR).Value, wsIn.Cells(r, COL_TX_MONTH).Value, _
                                      wsIn.Cells(r, COL_TX_DAY).Value, currentYear, currentMonth, currentDay, yearAdd, dateOK)
            If Not dateOK Then
                AddValidationError CStr(r) & "�s�ڂ̓��t��⊮�ł��܂���B�N�E���E�����m�F���Ă��������B", _
                                   wsIn.Cells(r, COL_TX_DAY).Address(False, False), validationCount, firstMessage, firstAddress
            Else
                If IsDate(openDate) Then
                    If CDate(txDate) < CDate(openDate) Then
                        AddValidationError CStr(r) & "�s�ڂ̎�����͌����J�ݓ����O�ł��B", _
                                           wsIn.Cells(r, COL_TX_DAY).Address(False, False), validationCount, firstMessage, firstAddress
                    End If
                End If
                If IsDate(closeDate) Then
                    If CDate(txDate) > CDate(closeDate) Then
                        AddValidationError CStr(r) & "�s�ڂ̎�����͌�����������ł��B", _
                                           wsIn.Cells(r, COL_TX_DAY).Address(False, False), validationCount, firstMessage, firstAddress
                    End If
                End If
            End If

            txTime = NormalizeTimeInput(wsIn.Cells(r, COL_TX_TIME).Value, timeOK)
            If Not timeOK Then
                AddValidationError CStr(r) & "�s�ڂ̎������s���ł��B1�`4����HHMM�܂���HH:MM�œ��͂��Ă��������B", _
                                   wsIn.Cells(r, COL_TX_TIME).Address(False, False), validationCount, firstMessage, firstAddress
            End If

            withdrawValue = ParseAmountOrError(wsIn.Cells(r, COL_TX_WITHDRAW).Value, amountOK)
            If Not amountOK Then
                AddValidationError CStr(r) & "�s�ڂ̏o���z���s���ł��i�L������15���E����8���ȓ��j�B", _
                                   wsIn.Cells(r, COL_TX_WITHDRAW).Address(False, False), validationCount, firstMessage, firstAddress
            ElseIf HasText(withdrawValue) Then
                If CDbl(withdrawValue) < 0 Then
                    AddValidationError CStr(r) & "�s�ڂ̏o���z��0�ȏ�œ��͂��Ă��������B", _
                                       wsIn.Cells(r, COL_TX_WITHDRAW).Address(False, False), validationCount, firstMessage, firstAddress
                End If
            End If
            depositValue = ParseAmountOrError(wsIn.Cells(r, COL_TX_DEPOSIT).Value, amountOK)
            If Not amountOK Then
                AddValidationError CStr(r) & "�s�ڂ̓����z���s���ł��i�L������15���E����8���ȓ��j�B", _
                                   wsIn.Cells(r, COL_TX_DEPOSIT).Address(False, False), validationCount, firstMessage, firstAddress
            ElseIf HasText(depositValue) Then
                If CDbl(depositValue) < 0 Then
                    AddValidationError CStr(r) & "�s�ڂ̓����z��0�ȏ�œ��͂��Ă��������B", _
                                       wsIn.Cells(r, COL_TX_DEPOSIT).Address(False, False), validationCount, firstMessage, firstAddress
                End If
            End If
            If HasText(withdrawValue) And HasText(depositValue) Then
                AddValidationError CStr(r) & "�s�ڂ͏o���Ɠ����̗����ɋ��z������܂��B�ǂ��炩����ɂ��Ă��������B", _
                                   wsIn.Cells(r, COL_TX_WITHDRAW).Address(False, False), validationCount, firstMessage, firstAddress
            End If
            balanceValue = ParseAmountOrError(wsIn.Cells(r, COL_TX_BALANCE).Value, amountOK)
            If Not amountOK Then
                AddValidationError CStr(r) & "�s�ڂ̎����c�����s���ł��i�L������15���E����8���ȓ��j�B", _
                                   wsIn.Cells(r, COL_TX_BALANCE).Address(False, False), validationCount, firstMessage, firstAddress
            End If

            tekiyoText = CellText(wsIn.Cells(r, COL_TX_TEKIYO).Value)
            AddMaxLengthError CellText(wsIn.Cells(r, COL_TX_SHOP).Value), 100, CStr(r) & "�s�ڂ̎戵�X", _
                              wsIn.Cells(r, COL_TX_SHOP).Address(False, False), validationCount, firstMessage, firstAddress
            AddMaxLengthError CellText(wsIn.Cells(r, COL_TX_MACHINE).Value), 100, CStr(r) & "�s�ڂ̋@��", _
                              wsIn.Cells(r, COL_TX_MACHINE).Address(False, False), validationCount, firstMessage, firstAddress
            AddMaxLengthError tekiyoText, 500, CStr(r) & "�s�ڂ̓E�v", _
                              wsIn.Cells(r, COL_TX_TEKIYO).Address(False, False), validationCount, firstMessage, firstAddress
            If tekiyoText = "����" Then
                If Len(previousTekiyo) = 0 Then
                    AddValidationError CStr(r) & "�s�ڂ́u����v���O�ɓE�v������܂���B", _
                                       wsIn.Cells(r, COL_TX_TEKIYO).Address(False, False), validationCount, firstMessage, firstAddress
                Else
                    tekiyoText = previousTekiyo
                End If
            End If
            If Len(tekiyoText) > 0 Then previousTekiyo = tekiyoText

            If Not HasText(withdrawValue) And Not HasText(depositValue) And Not HasText(balanceValue) And _
               Len(CellText(wsIn.Cells(r, COL_TX_SHOP).Value)) = 0 And _
               Len(CellText(wsIn.Cells(r, COL_TX_MACHINE).Value)) = 0 And Len(tekiyoText) = 0 Then
                AddValidationError CStr(r) & "�s�ڂ͓��t�ȊO�̎�����e������܂���B�s�v�ȍs�͓��t�������Ă��������B", _
                                   wsIn.Cells(r, COL_TX_DAY).Address(False, False), validationCount, firstMessage, firstAddress
            End If

            If dateOK And timeOK Then
                txCount = txCount + 1
                userTxCount = userTxCount + 1
                FillPreparedTx txData, txCount, bankName, branchName, personName, relationshipText, accountType, accountNo, _
                               txDate, txTime, withdrawValue, depositValue, _
                               CellText(wsIn.Cells(r, COL_TX_SHOP).Value), CellText(wsIn.Cells(r, COL_TX_MACHINE).Value), _
                               tekiyoText, balanceValue, RECORD_TRANSACTION, r - TX_FIRST_ROW + 1
            End If
        End If
    Next r

    memoCol = BalanceMemoCol(wsIn)
    AddMaxLengthError CellText(wsIn.Cells(BAL_VALUE_ROW, memoCol).Value), 1000, "�c�����̂��̑�", _
                      wsIn.Cells(BAL_VALUE_ROW, memoCol).Address(False, False), validationCount, firstMessage, firstAddress
    For c = BAL_FIRST_COL To memoCol - 1
        If Not AccountExistsAtDate(wsIn.Cells(BAL_DATE_ROW, c).Value, openDate, closeDate) Then
            If HasText(wsIn.Cells(BAL_VALUE_ROW, c).Value) And Not IsBalancePlaceholder(wsIn.Cells(BAL_VALUE_ROW, c).Value) Then
                AddValidationError "�J�ݑO�܂��͉���̎c���͓o�^�ł��܂���B���t��߂����A�c�����폜���Ă���ύX���Ă��������B", _
                                   wsIn.Cells(BAL_VALUE_ROW, c).Address(False, False), validationCount, firstMessage, firstAddress
            End If
        ElseIf HasText(wsIn.Cells(BAL_VALUE_ROW, c).Value) And Not IsBalancePlaceholder(wsIn.Cells(BAL_VALUE_ROW, c).Value) Then
            amountValue = ParseAmountOrError(wsIn.Cells(BAL_VALUE_ROW, c).Value, amountOK)
            If Not amountOK Then
                AddValidationError "�c�����u" & CellText(wsIn.Cells(BAL_LABEL_ROW, c).Value) & _
                                   "�v���s���ł��i�L������15���E����8���ȓ��j�B", _
                                   wsIn.Cells(BAL_VALUE_ROW, c).Address(False, False), validationCount, firstMessage, firstAddress
            Else
                balCount = balCount + 1
                FillPreparedBalance balData, balCount, personName, bankName, branchName, accountType, accountNo, _
                                    openDate, closeDate, wsIn.Cells(BAL_DATE_ROW, c).Value, _
                                    BalanceTekiyoLabel(wsIn.Cells(BAL_LABEL_ROW, c).Value), amountValue, _
                                    CellText(wsIn.Cells(BAL_VALUE_ROW, memoCol).Value), relationshipText
                txCount = txCount + 1
                FillPreparedTx txData, txCount, bankName, branchName, personName, relationshipText, accountType, accountNo, _
                               wsIn.Cells(BAL_DATE_ROW, c).Value, "", "", "", "", "", _
                               BalanceTekiyoLabel(wsIn.Cells(BAL_LABEL_ROW, c).Value), amountValue, RECORD_BALANCE, 500000 + c
            End If
        End If
    Next c

    If Len(editAccountID) > 0 Then
        PreserveHiddenBalancesForEdit wsIn, wsBal, editAccountID, bankName, branchName, personName, _
                                      relationshipText, accountType, accountNo, openDate, closeDate, _
                                      txData, txCount, balData, balCount, preservedHiddenBalanceCount, _
                                      validationCount, firstMessage, firstAddress
    End If

    If validationCount > 0 Then
        AppEnd
        SetInputStatus "�o�^�ł��܂���i" & validationCount & "���j�@" & firstMessage
        If Len(firstAddress) > 0 Then SafeSelectCell wsIn, firstAddress
        Exit Sub
    End If

    EnsureInternalAppendCapacity wsTx, txCount, "W_���"
    EnsureInternalAppendCapacity wsBal, balCount, "W_�c��"
    If Len(editAccountID) = 0 Then EnsureInternalAppendCapacity wsAcc, 1, "W_����"

    idCounterSnapshot = CaptureInternalIdCounters()
    idCountersCaptured = True
    If Len(editAccountID) > 0 Then
        accountID = editAccountID
        '�VID��U��O�ɋ��s��ޔ�����B���e���ς��Ȃ�����E�c����ID���ێ����A
        '�������`�������̒����ŕ��͊m�F������s�K�v�Ɏ���Ȃ��B
        SnapshotAccountRows wsTx, WORK_TX_COL_ACCOUNT_ID, accountID, WORK_TX_COL_PERSON_ID, oldTx, oldTxCount
        SnapshotAccountRows wsBal, WORK_BAL_COL_ACCOUNT_ID, accountID, WORK_BAL_COL_PERSON_ID, oldBal, oldBalCount
        oldMasterRow = FindAccountRowByID(accountID)
        If oldMasterRow > 0 Then _
            oldMaster = wsAcc.Range(wsAcc.Cells(oldMasterRow, 1), _
                                    wsAcc.Cells(oldMasterRow, ACC_COL_TRANSFER_ID)).Value
    Else
        accountID = NextInternalId(STATE_NEXT_ACCOUNT, "A")
    End If
    '�����͌����̓��ꐫ���ێ�����B���������E�����Ől��ID�𕪒f���Ȃ��B
    If Len(editAccountID) > 0 Then
        oldMasterRow = FindAccountRowByID(editAccountID)
        If oldMasterRow > 0 Then personID = CellText(wsAcc.Cells(oldMasterRow, ACC_COL_PERSON_ID).Value)
    End If
    If Len(personID) = 0 Then personID = PersonIDForName(personName, relationshipText)
    If Len(personID) = 0 Then personID = NextInternalId(STATE_NEXT_PERSON, "P")
    transferID = NextInternalId(STATE_NEXT_TRANSFER, "R")
    nextAccountNo = NextBranchAccountNo(accountNo)

    AssignPreparedTransactionIDs txData, txCount, oldTx, oldTxCount
    AssignPreparedBalanceIDs balData, balCount, oldBal, oldBalCount

    For r = 1 To txCount
        txData(r, WORK_TX_COL_ACCOUNT_ID) = accountID
        txData(r, WORK_TX_COL_TRANSFER_ID) = transferID
        txData(r, WORK_TX_COL_SOURCE) = SOURCE_MANUAL
        txData(r, WORK_TX_COL_PERSON_ID) = personID
    Next r
    For r = 1 To balCount
        balData(r, WORK_BAL_COL_ACCOUNT_ID) = accountID
        balData(r, WORK_BAL_COL_TRANSFER_ID) = transferID
        balData(r, WORK_BAL_COL_SOURCE) = SOURCE_MANUAL
        balData(r, WORK_BAL_COL_PERSON_ID) = personID
    Next r

    Application.StatusBar = "���؍ς݃f�[�^���ꊇ�o�^���Ă��܂�..."
    writeStarted = True
    newTxFirst = AppendPreparedTxRows(wsTx, txData, txCount)
    newBalFirst = AppendPreparedBalanceRows(wsBal, balData, balCount)
    If Len(editAccountID) > 0 Then
        DeleteOldRowsExceptTransfer wsTx, WORK_TX_COL_ACCOUNT_ID, WORK_TX_COL_TRANSFER_ID, accountID, transferID
        DeleteOldRowsExceptTransfer wsBal, WORK_BAL_COL_ACCOUNT_ID, WORK_BAL_COL_TRANSFER_ID, accountID, transferID
    End If
    UpsertAccountMaster accountID, transferID, bankName, branchName, personName, relationshipText, _
                        accountType, accountNo, openDate, closeDate, personID, SOURCE_MANUAL
    If Len(editAccountID) > 0 Then SynchronizePersonRelationship personID, relationshipText
    '�����܂łňČ��f�[�^�{�̂͐������Ă���B�ȍ~�̏o�͏�ԁE���E��ʐ����͌㏈���Ƃ��Ĉ����B
    committed = True
    MarkOutputsDirty
    InvalidateDuplicateAccountWarningCache

    On Error Resume Next
    Err.Clear
    UpdateAccountCandidates bankName, branchName, personName
    If Err.Number <> 0 Then AppendTransferDetail postProcessDetail, "�������: Err " & Err.Number & " " & Err.Description
    Err.Clear
    AddAccountTypeCandidate accountType
    If Err.Number <> 0 Then AppendTransferDetail postProcessDetail, "�Ȗڌ��: Err " & Err.Number & " " & Err.Description
    Err.Clear
    AddPersonCandidateWithID personName, personID, relationshipText
    If Err.Number <> 0 Then AppendTransferDetail postProcessDetail, "�l�����: Err " & Err.Number & " " & Err.Description
    Err.Clear
    If IsDate(openDate) Then
        wsIn.Range(CELL_OPEN_DATE).Value = CDate(openDate)
        If Err.Number <> 0 Then AppendTransferDetail postProcessDetail, "�J�ݓ��̕\���X�V: Err " & Err.Number & " " & Err.Description
        Err.Clear
    End If
    If IsDate(closeDate) Then
        wsIn.Range(CELL_CLOSE_DATE).Value = CDate(closeDate)
        If Err.Number <> 0 Then AppendTransferDetail postProcessDetail, "�����̕\���X�V: Err " & Err.Number & " " & Err.Description
        Err.Clear
    End If
    BuildRegisteredAccountsSheet False
    If Err.Number <> 0 Then AppendTransferDetail postProcessDetail, "�o�^�ς݌����ꗗ: Err " & Err.Number & " " & Err.Description
    Err.Clear
    focusPolicy = keepOverride
    If Len(focusPolicy) = 0 Then focusPolicy = GetPostTransferKeepPolicy()
    If Err.Number <> 0 Then AppendTransferDetail postProcessDetail, "�]�L��ݒ�̎擾: Err " & Err.Number & " " & Err.Description
    Err.Clear
    If nextBranchAfter Then
        ApplyPostTransferCleanup KEEP_BANK_BRANCH_PERSON_TYPE
        If Err.Number <> 0 Then AppendTransferDetail postProcessDetail, "���͗��̐���: Err " & Err.Number & " " & Err.Description
        Err.Clear
        SetNextBranchAccountNumber nextAccountNo
        If Err.Number <> 0 Then AppendTransferDetail postProcessDetail, "���}�Ԃ̐ݒ�: Err " & Err.Number & " " & Err.Description
        Err.Clear
        focusPolicy = KEEP_BANK_BRANCH_PERSON_TYPE
    Else
        ApplyPostTransferCleanup keepOverride
        If Err.Number <> 0 Then AppendTransferDetail postProcessDetail, "���͗��̐���: Err " & Err.Number & " " & Err.Description
        Err.Clear
    End If
    FocusAfterPostTransferCleanup focusPolicy
    If Err.Number <> 0 Then
        AppendTransferDetail postProcessDetail, "���͈ʒu�̈ړ�: Err " & Err.Number & " " & Err.Description
    End If
    Err.Clear
    On Error GoTo 0

    AppEnd
    If Len(postProcessDetail) > 0 Then
        AddCheck "�x��", "�����o�^�㏈��", postProcessDetail
        postProcessSuffix = "�i�o�^�ς݁E��ʐ����͗v�m�F�j"
    End If
    If Not GetPostTransferClearTransaction() Or Not GetPostTransferClearBalance() Then _
        retentionWarning = "�i�O�����̖��ׂ܂��͎c����ێ����B�������֗��p���Ȃ��ꍇ�̓N���A�j"
    If Len(editAccountID) > 0 Then
        SetInputStatus "�����𔽉f���܂����B��� " & userTxCount & "���A�c�� " & balCount & "��" & _
                       IIf(preservedHiddenBalanceCount > 0, "�i�\�����ԊO " & preservedHiddenBalanceCount & "����ێ��j", "") & _
                       postProcessSuffix & retentionWarning & "�B"
    Else
        SetInputStatus "�o�^���܂����B��� " & userTxCount & "���A�c�� " & balCount & "��" & _
                       postProcessSuffix & retentionWarning & "�B"
    End If
    Exit Sub

EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    If committed Then
        AppForceRestore
        EnableInputKeys
        SetInputStatus "�o�^�f�[�^�͕ۑ��ς݂ł����A��ʂ̌㏈���ŃG���[���������܂����BC_�`�F�b�N���m�F���Ă��������B"
        AddCheck "�x��", "�����o�^�㏈��", "Err " & errorNumber & ": " & errorDescription
        MsgBox "�����f�[�^�̕ۑ��͊������Ă��܂����A���X�V���ʐ����̌㏈���ŃG���[���������܂����B" & vbCrLf & _
               "�ēo�^�����A�o�^�ς݌�����C_�`�F�b�N���m�F���Ă��������B" & vbCrLf & _
               "Err " & errorNumber & ": " & errorDescription, vbExclamation
        Exit Sub
    End If
    If writeStarted And Not committed Then
        On Error Resume Next
        Err.Clear
        RollbackAccountWrite accountID, transferID, editAccountID, oldTx, oldTxCount, oldBal, oldBalCount, oldMaster, oldMasterRow
        If Err.Number <> 0 Then AppendTransferDetail rollbackDetail, "���������G���[: " & Err.Description
        Err.Clear
        rollbackVerifyDetail = VerifyAccountRollback(accountID, editAccountID, oldTx, oldTxCount, oldBal, oldBalCount, oldMaster)
        If Err.Number <> 0 Then
            AppendTransferDetail rollbackDetail, "�����m�F�G���[: " & Err.Description
        ElseIf Len(rollbackVerifyDetail) > 0 Then
            AppendTransferDetail rollbackDetail, rollbackVerifyDetail
        Else
            rollbackVerified = True
        End If
        Err.Clear
        On Error GoTo 0
    End If
    If idCountersCaptured And (Not writeStarted Or rollbackVerified) Then
        On Error Resume Next
        Err.Clear
        RestoreInternalIdCounters idCounterSnapshot
        If Err.Number <> 0 Then
            AppendTransferDetail rollbackDetail, "ID�̔ԏ�Ԃ̕����G���[: " & Err.Description
        End If
        Err.Clear
        On Error GoTo 0
    End If
    AppForceRestore
    EnableInputKeys
    If Not writeStarted Or rollbackVerified Then
        SetInputStatus "�o�^�Ɏ��s�������߁A�f�[�^�͔��f���Ă��܂���B"
        If Len(rollbackDetail) > 0 Then AddCheck "�x��", "�����o�^���[���o�b�N", rollbackDetail
    Else
        SetInputStatus "�o�^�Ɏ��s���A�������ʂ��v�m�F�ł��BC_�`�F�b�N���m�F���Ă��������B"
        AddCheck "�G���[", "�����o�^���[���o�b�N", rollbackDetail
    End If
    MsgBox "�����o�^���ɃG���[���������܂����B" & vbCrLf & _
           "Err " & errorNumber & ": " & errorDescription & _
           IIf(Len(rollbackDetail) > 0, vbCrLf & "�����m�F: " & rollbackDetail, ""), vbCritical
End Sub

Private Sub CheckUnsupportedInputCells(ByVal ws As Worksheet, ByRef errorCount As Long, _
                                       ByRef firstMessage As String, ByRef firstAddress As String)
    '�\��t���œ��͋K�����I�񂳂�Ă��A�����E�G���[�l��l�Ȃ��Ƃ��Ėق��ė��Ƃ��Ȃ��B
    '���͒l�͓o�^���ɒ萔�֌Œ肷��݌v�Ȃ̂ŁA�����͌v�Z���ʂ������Ă��Ă������I�ɋ��ۂ���B
    Dim accountRange As Range
    If ws Is Nothing Then Exit Sub
    Set accountRange = Union(ws.Range(CELL_BANK), ws.Range(CELL_BRANCH), ws.Range(CELL_PERSON), _
                             ws.Range(CELL_RELATIONSHIP), ws.Range(CELL_ACCOUNT_TYPE), _
                             ws.Range(CELL_ACCOUNT_NO), ws.Range(CELL_OPEN_DATE), ws.Range(CELL_CLOSE_DATE))
    CheckUnsupportedInputRange accountRange, "�������", errorCount, firstMessage, firstAddress
    CheckUnsupportedInputRange ws.Range(ws.Cells(BAL_VALUE_ROW, BAL_FIRST_COL), _
                                         ws.Cells(BAL_VALUE_ROW, BAL_MAX_COL)), _
                               "�c�����͗�", errorCount, firstMessage, firstAddress
    CheckUnsupportedInputRange ws.Range(ws.Cells(TX_FIRST_ROW, COL_TX_YEAR), _
                                         ws.Cells(TX_LAST_ROW, COL_TX_BALANCE)), _
                               "������͗�", errorCount, firstMessage, firstAddress
End Sub

Private Sub CheckUnsupportedInputRange(ByVal target As Range, ByVal labelText As String, _
                                       ByRef errorCount As Long, ByRef firstMessage As String, _
                                       ByRef firstAddress As String)
    Dim badCells As Range
    If target Is Nothing Then Exit Sub
    On Error Resume Next
    Err.Clear
    Set badCells = target.SpecialCells(xlCellTypeFormulas)
    Err.Clear
    On Error GoTo EH
    If Not badCells Is Nothing Then
        AddValidationError labelText & "�ɐ���������܂��B�l�Ƃ��ē\��t�������Ă��������B", _
                           badCells.Cells(1, 1).Address(False, False), errorCount, firstMessage, firstAddress
    End If

    Set badCells = Nothing
    On Error Resume Next
    Err.Clear
    Set badCells = target.SpecialCells(xlCellTypeConstants, xlErrors)
    Err.Clear
    On Error GoTo EH
    If Not badCells Is Nothing Then
        AddValidationError labelText & "�ɃG���[�l������܂��B���e���C�����Ă��������B", _
                           badCells.Cells(1, 1).Address(False, False), errorCount, firstMessage, firstAddress
    End If
    Exit Sub
EH:
    Err.Raise Err.Number, "CheckUnsupportedInputRange(" & labelText & ")", Err.Description
End Sub

Private Sub AddMaxLengthError(ByVal valueText As String, ByVal maxLength As Long, ByVal labelText As String, _
                              ByVal addressText As String, ByRef errorCount As Long, _
                              ByRef firstMessage As String, ByRef firstAddress As String)
    If Len(valueText) > maxLength Then
        AddValidationError labelText & "��" & CStr(maxLength) & "�����ȓ��ɂ��Ă��������B", _
                           addressText, errorCount, firstMessage, firstAddress
    End If
End Sub

Private Function LastInputTransactionRow(ByVal ws As Worksheet) As Long
    Dim foundCell As Range
    LastInputTransactionRow = TX_FIRST_ROW - 1
    If ws Is Nothing Then Exit Function
    On Error Resume Next
    Set foundCell = ws.Range(ws.Cells(TX_FIRST_ROW, COL_TX_YEAR), ws.Cells(TX_LAST_ROW, COL_TX_BALANCE)).Find( _
                    What:="*", After:=ws.Cells(TX_FIRST_ROW, COL_TX_YEAR), LookIn:=xlValues, _
                    LookAt:=xlPart, SearchOrder:=xlByRows, SearchDirection:=xlPrevious, _
                    MatchCase:=False, MatchByte:=False, SearchFormat:=False)
    On Error GoTo 0
    If Not foundCell Is Nothing Then LastInputTransactionRow = foundCell.Row
End Function

Private Sub AddRequiredError(ByVal valueText As String, ByVal messageText As String, ByVal addressText As String, _
                             ByRef errorCount As Long, ByRef firstMessage As String, ByRef firstAddress As String)
    If Len(CellText(valueText)) = 0 Then AddValidationError messageText, addressText, errorCount, firstMessage, firstAddress
End Sub

Private Sub AddValidationError(ByVal messageText As String, ByVal addressText As String, _
                               ByRef errorCount As Long, ByRef firstMessage As String, ByRef firstAddress As String)
    errorCount = errorCount + 1
    If Len(firstMessage) = 0 Then
        firstMessage = messageText
        firstAddress = addressText
    End If
End Sub

Private Function ParseAmountOrError(ByVal valueIn As Variant, ByRef ok As Boolean) As Variant
    ParseAmountOrError = TryParseAmount(valueIn, ok)
End Function

Private Sub PreserveHiddenBalancesForEdit(ByVal wsIn As Worksheet, ByVal wsBal As Worksheet, ByVal accountID As String, _
                                          ByVal bankName As String, ByVal branchName As String, ByVal personName As String, _
                                          ByVal relationshipText As String, ByVal accountType As String, ByVal accountNo As String, _
                                          ByVal openDate As Variant, ByVal closeDate As Variant, _
                                          ByRef txData() As Variant, ByRef txCount As Long, _
                                          ByRef balData() As Variant, ByRef balCount As Long, _
                                          ByRef preservedCount As Long, ByRef validationCount As Long, _
                                          ByRef firstMessage As String, ByRef firstAddress As String)
    Dim lastR As Long, r As Long, gridCol As Long, memoCol As Long
    Dim sourceRow As Long
    Dim balanceDate As Variant, amountValue As Variant
    Dim labelText As String, memoText As String
    Dim amountOK As Boolean
    Dim seenHiddenDates As Object
    Dim balanceData As Variant

    Set seenHiddenDates = CreateObject("Scripting.Dictionary")
    seenHiddenDates.CompareMode = vbTextCompare
    memoCol = BalanceMemoCol(wsIn)
    lastR = LastUsedRowInSheet(wsBal)
    If lastR < 2 Then Exit Sub
    '�����Ώۂ���K�͕ۊǂ̖����ɂ����Ă��A�s���Ƃ�Excel�ǎ���s��Ȃ��B
    balanceData = wsBal.Range(wsBal.Cells(2, 1), wsBal.Cells(lastR, WORK_BAL_COL_PERSON_ID)).Value2
    For r = 1 To UBound(balanceData, 1)
        sourceRow = r + 1
        If CellText(balanceData(r, WORK_BAL_COL_ACCOUNT_ID)) = accountID Then
            balanceDate = balanceData(r, 8)
            gridCol = FindBalanceGridColumn(wsIn, balanceDate)
            If gridCol = 0 Then
                If Not IsDate(balanceDate) Then
                    AddValidationError "�\�����ԊO�̊����c���ɕs���Ȋ��������܂��B", CELL_OPEN_DATE, validationCount, firstMessage, firstAddress
                ElseIf seenHiddenDates.Exists(Format$(CDate(balanceDate), "yyyymmdd")) Then
                    AddValidationError "�\�����ԊO�̊����c�����������t�ŏd�����Ă��܂��B�Z���t�`�F�b�N�����s���Ă��������B", CELL_OPEN_DATE, validationCount, firstMessage, firstAddress
                ElseIf Not AccountExistsAtDate(balanceDate, openDate, closeDate) Then
                    AddValidationError "�\�����ԊO�̊����c���i" & Format$(CDate(balanceDate), "yyyy/m/d") & "�j���A�V�����J�ݓ��E�����͈̔͊O�ɂȂ�܂��B", _
                                       CELL_OPEN_DATE, validationCount, firstMessage, firstAddress
                Else
                    seenHiddenDates.Add Format$(CDate(balanceDate), "yyyymmdd"), True
                    amountValue = ParseAmountOrError(balanceData(r, 10), amountOK)
                    If Not amountOK Or Not HasText(amountValue) Then
                        AddValidationError "�\�����ԊO�̊����c���i" & Format$(CDate(balanceDate), "yyyy/m/d") & "�j�̋��z���s���ł��B", _
                                           CELL_OPEN_DATE, validationCount, firstMessage, firstAddress
                    Else
                        labelText = CellText(balanceData(r, 9))
                        If Len(labelText) = 0 Then labelText = Format$(CDate(balanceDate), "yyyy/m/d") & "���_�c��"
                        memoText = CellText(wsIn.Cells(BAL_VALUE_ROW, memoCol).Value)
                        If Len(memoText) = 0 Then memoText = CellText(balanceData(r, 11))
                        balCount = balCount + 1
                        FillPreparedBalance balData, balCount, personName, bankName, branchName, accountType, accountNo, _
                                            openDate, closeDate, CDate(balanceDate), labelText, amountValue, memoText, relationshipText
                        txCount = txCount + 1
                        FillPreparedTx txData, txCount, bankName, branchName, personName, relationshipText, accountType, accountNo, _
                                       CDate(balanceDate), "", "", "", "", "", BalanceTekiyoLabel(labelText), amountValue, _
                                       RECORD_BALANCE, 600000 + sourceRow
                        preservedCount = preservedCount + 1
                    End If
                End If
            End If
        End If
    Next r
End Sub

Private Function FindBalanceGridColumn(ByVal ws As Worksheet, ByVal targetDate As Variant) As Long
    Dim c As Long, memoCol As Long
    If ws Is Nothing Or Not IsDate(targetDate) Then Exit Function
    memoCol = BalanceMemoCol(ws)
    For c = BAL_FIRST_COL To memoCol - 1
        If IsDate(ws.Cells(BAL_DATE_ROW, c).Value) Then
            If CLng(CDate(ws.Cells(BAL_DATE_ROW, c).Value)) = CLng(CDate(targetDate)) Then
                FindBalanceGridColumn = c
                Exit Function
            End If
        End If
    Next c
End Function

Private Sub AssignPreparedTransactionIDs(ByRef txData() As Variant, ByVal txCount As Long, _
                                         ByRef oldTx As Variant, ByVal oldTxCount As Long)
    Dim oldBySignature As Object, idQueue As Collection
    Dim newPositions() As Long, newIDs As Variant
    Dim signatureText As String, transactionID As String
    Dim r As Long, newCount As Long
    If txCount <= 0 Then Exit Sub
    Set oldBySignature = CreateObject("Scripting.Dictionary")
    oldBySignature.CompareMode = vbBinaryCompare
    If oldTxCount > 0 Then
        For r = 1 To oldTxCount
            signatureText = StoredTransactionIdentitySignature(oldTx, r)
            transactionID = CellText(oldTx(r, WORK_TX_COL_TRANSACTION_ID))
            If Len(transactionID) = 0 Then _
                Err.Raise vbObjectError + 2061, "AssignPreparedTransactionIDs", _
                          "�����Ώۂ̊�������Ɏ��ID������܂���B�Z���t�`�F�b�N�����s���Ă��������B"
            If Not oldBySignature.Exists(signatureText) Then
                Set idQueue = New Collection
                oldBySignature.Add signatureText, idQueue
            Else
                Set idQueue = oldBySignature(signatureText)
            End If
            idQueue.Add transactionID
        Next r
    End If
    ReDim newPositions(1 To txCount)
    For r = 1 To txCount
        signatureText = PreparedTransactionIdentitySignature(txData, r)
        If oldBySignature.Exists(signatureText) Then
            Set idQueue = oldBySignature(signatureText)
            If idQueue.Count > 0 Then
                txData(r, WORK_TX_COL_TRANSACTION_ID) = CStr(idQueue(1))
                idQueue.Remove 1
            Else
                newCount = newCount + 1: newPositions(newCount) = r
            End If
        Else
            newCount = newCount + 1: newPositions(newCount) = r
        End If
    Next r
    If newCount > 0 Then
        newIDs = ReserveInternalIds(STATE_NEXT_TRANSACTION, "T", newCount)
        For r = 1 To newCount
            txData(newPositions(r), WORK_TX_COL_TRANSACTION_ID) = CStr(newIDs(r))
        Next r
    End If
End Sub

Private Sub AssignPreparedBalanceIDs(ByRef balData() As Variant, ByVal balCount As Long, _
                                     ByRef oldBal As Variant, ByVal oldBalCount As Long)
    Dim oldBySignature As Object, idQueue As Collection
    Dim newPositions() As Long, newIDs As Variant
    Dim signatureText As String, balanceID As String
    Dim r As Long, newCount As Long
    If balCount <= 0 Then Exit Sub
    Set oldBySignature = CreateObject("Scripting.Dictionary")
    oldBySignature.CompareMode = vbBinaryCompare
    If oldBalCount > 0 Then
        For r = 1 To oldBalCount
            signatureText = StoredBalanceIdentitySignature(oldBal, r)
            balanceID = CellText(oldBal(r, WORK_BAL_COL_BALANCE_ID))
            If Len(balanceID) = 0 Then _
                Err.Raise vbObjectError + 2062, "AssignPreparedBalanceIDs", _
                          "�����Ώۂ̊����c���Ɏc��ID������܂���B�Z���t�`�F�b�N�����s���Ă��������B"
            If Not oldBySignature.Exists(signatureText) Then
                Set idQueue = New Collection
                oldBySignature.Add signatureText, idQueue
            Else
                Set idQueue = oldBySignature(signatureText)
            End If
            idQueue.Add balanceID
        Next r
    End If
    ReDim newPositions(1 To balCount)
    For r = 1 To balCount
        signatureText = PreparedBalanceIdentitySignature(balData, r)
        If oldBySignature.Exists(signatureText) Then
            Set idQueue = oldBySignature(signatureText)
            If idQueue.Count > 0 Then
                balData(r, WORK_BAL_COL_BALANCE_ID) = CStr(idQueue(1))
                idQueue.Remove 1
            Else
                newCount = newCount + 1: newPositions(newCount) = r
            End If
        Else
            newCount = newCount + 1: newPositions(newCount) = r
        End If
    Next r
    If newCount > 0 Then
        newIDs = ReserveInternalIds(STATE_NEXT_BALANCE, "B", newCount)
        For r = 1 To newCount
            balData(newPositions(r), WORK_BAL_COL_BALANCE_ID) = CStr(newIDs(r))
        Next r
    End If
End Sub

Private Function PreparedTransactionIdentitySignature(ByRef data() As Variant, ByVal rowNo As Long) As String
    PreparedTransactionIdentitySignature = TransactionIdentitySignatureFromValues( _
        data(rowNo, OUT_COL_DATE), data(rowNo, OUT_COL_TIME), data(rowNo, OUT_COL_WITHDRAW), _
        data(rowNo, OUT_COL_DEPOSIT), data(rowNo, OUT_COL_SHOP), data(rowNo, OUT_COL_MACHINE), _
        data(rowNo, OUT_COL_TEKIYO), data(rowNo, OUT_COL_OTHER), _
        data(rowNo, WORK_TX_COL_RECORD_TYPE))
End Function

Private Function StoredTransactionIdentitySignature(ByRef data As Variant, ByVal rowNo As Long) As String
    StoredTransactionIdentitySignature = TransactionIdentitySignatureFromValues( _
        data(rowNo, OUT_COL_DATE), data(rowNo, OUT_COL_TIME), data(rowNo, OUT_COL_WITHDRAW), _
        data(rowNo, OUT_COL_DEPOSIT), data(rowNo, OUT_COL_SHOP), data(rowNo, OUT_COL_MACHINE), _
        data(rowNo, OUT_COL_TEKIYO), data(rowNo, OUT_COL_OTHER), _
        data(rowNo, WORK_TX_COL_RECORD_TYPE))
End Function

Private Function TransactionIdentitySignatureFromValues( _
        ByVal dateInputValue As Variant, ByVal timeInputValue As Variant, ByVal withdrawalValue As Variant, _
        ByVal depositValue As Variant, ByVal shopValue As Variant, ByVal machineValue As Variant, _
        ByVal tekiyoValue As Variant, ByVal balanceValue As Variant, ByVal recordTypeValue As Variant) As String
    TransactionIdentitySignatureFromValues = _
        TransferSignaturePart(TransferDateSignature(dateInputValue)) & _
        TransferSignaturePart(TransferTimeSignature(timeInputValue)) & _
        TransferSignaturePart(TransferAmountSignature(withdrawalValue)) & _
        TransferSignaturePart(TransferAmountSignature(depositValue)) & _
        TransferSignaturePart(CellText(shopValue)) & TransferSignaturePart(CellText(machineValue)) & _
        TransferSignaturePart(CellText(tekiyoValue)) & _
        TransferSignaturePart(TransferAmountSignature(balanceValue)) & _
        TransferSignaturePart(CellText(recordTypeValue))
End Function

Private Function PreparedBalanceIdentitySignature(ByRef data() As Variant, ByVal rowNo As Long) As String
    PreparedBalanceIdentitySignature = BalanceIdentitySignatureFromValues( _
        data(rowNo, 8), data(rowNo, 9), data(rowNo, 10), data(rowNo, 11))
End Function

Private Function StoredBalanceIdentitySignature(ByRef data As Variant, ByVal rowNo As Long) As String
    StoredBalanceIdentitySignature = BalanceIdentitySignatureFromValues( _
        data(rowNo, 8), data(rowNo, 9), data(rowNo, 10), data(rowNo, 11))
End Function

Private Function BalanceIdentitySignatureFromValues(ByVal dateInputValue As Variant, _
                                                    ByVal labelValue As Variant, _
                                                    ByVal amountValue As Variant, _
                                                    ByVal memoValue As Variant) As String
    BalanceIdentitySignatureFromValues = TransferSignaturePart(TransferDateSignature(dateInputValue)) & _
                                         TransferSignaturePart(CellText(labelValue)) & _
                                         TransferSignaturePart(TransferAmountSignature(amountValue)) & _
                                         TransferSignaturePart(CellText(memoValue))
End Function

Private Function TransferDateSignature(ByVal valueIn As Variant) As String
    If IsDate(valueIn) Then
        TransferDateSignature = Format$(CLng(VBA.DateValue(CDate(valueIn))), "0")
    Else
        TransferDateSignature = CellText(valueIn)
    End If
End Function

Private Function TransferTimeSignature(ByVal valueIn As Variant) As String
    If IsError(valueIn) Or IsNull(valueIn) Or IsEmpty(valueIn) Then Exit Function
    If VarType(valueIn) = vbString And Len(Trim$(CStr(valueIn))) = 0 Then Exit Function
    If IsDate(valueIn) Or IsNumeric(valueIn) Then
        On Error GoTo RawValue
        TransferTimeSignature = Format$(CDbl(VBA.TimeValue(CDate(valueIn))), "0.0000000000")
        Exit Function
    End If
RawValue:
    TransferTimeSignature = CellText(valueIn)
End Function

Private Function TransferAmountSignature(ByVal valueIn As Variant) As String
    If IsError(valueIn) Or IsNull(valueIn) Or IsEmpty(valueIn) Then Exit Function
    If VarType(valueIn) = vbString And Len(Trim$(CStr(valueIn))) = 0 Then Exit Function
    If IsNumeric(valueIn) Then
        TransferAmountSignature = Format$(CDbl(valueIn), "0.00000000")
    Else
        TransferAmountSignature = CellText(valueIn)
    End If
End Function

Private Function TransferSignaturePart(ByVal valueText As String) As String
    TransferSignaturePart = CStr(Len(valueText)) & ":" & valueText & "|"
End Function

Private Sub FillPreparedTx(ByRef data() As Variant, ByVal rowNo As Long, _
                           ByVal bankName As String, ByVal branchName As String, ByVal personName As String, _
                           ByVal relationshipText As String, ByVal accountType As String, ByVal accountNo As String, _
                           ByVal txDate As Variant, ByVal txTime As Variant, ByVal withdrawValue As Variant, _
                           ByVal depositValue As Variant, ByVal shopText As String, ByVal machineText As String, _
                           ByVal tekiyoText As String, ByVal afterBalance As Variant, _
                           ByVal recordType As String, ByVal inputOrder As Long)
    data(rowNo, OUT_COL_BANK) = bankName
    data(rowNo, OUT_COL_BRANCH) = branchName
    data(rowNo, OUT_COL_PERSON) = personName
    data(rowNo, OUT_COL_ACCOUNT_TYPE) = accountType
    data(rowNo, OUT_COL_ACCOUNT_NO) = accountNo
    data(rowNo, OUT_COL_DATE) = txDate
    data(rowNo, OUT_COL_TIME) = txTime
    data(rowNo, OUT_COL_WITHDRAW) = withdrawValue
    data(rowNo, OUT_COL_DEPOSIT) = depositValue
    data(rowNo, OUT_COL_SHOP) = shopText
    data(rowNo, OUT_COL_MACHINE) = machineText
    data(rowNo, OUT_COL_TEKIYO) = tekiyoText
    data(rowNo, OUT_COL_OTHER) = afterBalance
    data(rowNo, WORK_TX_COL_RELATIONSHIP) = relationshipText
    data(rowNo, WORK_TX_COL_RECORD_TYPE) = recordType
    data(rowNo, WORK_TX_COL_INPUT_ORDER) = inputOrder
End Sub

Private Sub FillPreparedBalance(ByRef data() As Variant, ByVal rowNo As Long, _
                                ByVal personName As String, ByVal bankName As String, ByVal branchName As String, _
                                ByVal accountType As String, ByVal accountNo As String, _
                                ByVal openDate As Variant, ByVal closeDate As Variant, ByVal balanceDate As Variant, _
                                ByVal labelText As String, ByVal amountValue As Variant, ByVal memoText As String, _
                                ByVal relationshipText As String)
    data(rowNo, 1) = personName
    data(rowNo, 2) = bankName
    data(rowNo, 3) = branchName
    data(rowNo, 4) = accountType
    data(rowNo, 5) = accountNo
    data(rowNo, 6) = openDate
    data(rowNo, 7) = closeDate
    data(rowNo, 8) = balanceDate
    data(rowNo, 9) = labelText
    data(rowNo, 10) = amountValue
    data(rowNo, 11) = memoText
    data(rowNo, WORK_BAL_COL_RELATIONSHIP) = relationshipText
End Sub

Private Function AppendPreparedTxRows(ByVal ws As Worksheet, ByRef data() As Variant, ByVal rowCount As Long) As Long
    Dim firstR As Long, r As Long, c As Long
    Dim writeData() As Variant
    If rowCount = 0 Then Exit Function
    firstR = LastUsedRowInSheet(ws) + 1
    If firstR < 2 Then firstR = 2
    If rowCount > ws.Rows.Count - firstR + 1 Then _
        Err.Raise vbObjectError + 3501, "AppendPreparedTxRows", "����ۊǂ�Excel�̍s����𒴂��܂��B�Č��𕪊����Ă��������B"
    ReDim writeData(1 To rowCount, 1 To WORK_TX_COL_PERSON_ID)
    For r = 1 To rowCount
        For c = 1 To WORK_TX_COL_PERSON_ID
            writeData(r, c) = data(r, c)
        Next c
    Next r
    ws.Range(ws.Cells(firstR, 1), ws.Cells(firstR + rowCount - 1, OUT_COL_ACCOUNT_NO)).NumberFormatLocal = "@"
    ws.Range(ws.Cells(firstR, OUT_COL_SHOP), ws.Cells(firstR + rowCount - 1, OUT_COL_TEKIYO)).NumberFormatLocal = "@"
    ws.Range(ws.Cells(firstR, WORK_TX_COL_RELATIONSHIP), ws.Cells(firstR + rowCount - 1, WORK_TX_COL_PERSON_ID)).NumberFormatLocal = "@"
    ws.Range(ws.Cells(firstR, 1), ws.Cells(firstR + rowCount - 1, WORK_TX_COL_PERSON_ID)).Value = writeData
    FormatNewWorkTxRows ws, firstR, firstR + rowCount - 1
    AppendPreparedTxRows = firstR
End Function

Private Function AppendPreparedBalanceRows(ByVal ws As Worksheet, ByRef data() As Variant, ByVal rowCount As Long) As Long
    Dim firstR As Long, r As Long, c As Long
    Dim writeData() As Variant
    If rowCount = 0 Then Exit Function
    firstR = LastUsedRowInSheet(ws) + 1
    If firstR < 2 Then firstR = 2
    If rowCount > ws.Rows.Count - firstR + 1 Then _
        Err.Raise vbObjectError + 3502, "AppendPreparedBalanceRows", "�c���ۊǂ�Excel�̍s����𒴂��܂��B�Č��𕪊����Ă��������B"
    ReDim writeData(1 To rowCount, 1 To WORK_BAL_COL_PERSON_ID)
    For r = 1 To rowCount
        For c = 1 To WORK_BAL_COL_PERSON_ID
            writeData(r, c) = data(r, c)
        Next c
    Next r
    ws.Range(ws.Cells(firstR, 1), ws.Cells(firstR + rowCount - 1, 5)).NumberFormatLocal = "@"
    ws.Range(ws.Cells(firstR, 9), ws.Cells(firstR + rowCount - 1, 9)).NumberFormatLocal = "@"
    ws.Range(ws.Cells(firstR, 11), ws.Cells(firstR + rowCount - 1, WORK_BAL_COL_PERSON_ID)).NumberFormatLocal = "@"
    ws.Range(ws.Cells(firstR, 1), ws.Cells(firstR + rowCount - 1, WORK_BAL_COL_PERSON_ID)).Value = writeData
    FormatNewWorkBalanceRows ws, firstR, firstR + rowCount - 1
    AppendPreparedBalanceRows = firstR
End Function

Private Sub FormatNewWorkTxRows(ByVal ws As Worksheet, ByVal firstR As Long, ByVal lastR As Long)
    If firstR = 0 Or lastR < firstR Then Exit Sub
    ws.Range(ws.Cells(firstR, 1), ws.Cells(lastR, OUT_COL_ACCOUNT_NO)).NumberFormatLocal = "@"
    ws.Range(ws.Cells(firstR, OUT_COL_SHOP), ws.Cells(lastR, OUT_COL_TEKIYO)).NumberFormatLocal = "@"
    ws.Range(ws.Cells(firstR, WORK_TX_COL_RELATIONSHIP), ws.Cells(lastR, WORK_TX_COL_PERSON_ID)).NumberFormatLocal = "@"
    ws.Range(ws.Cells(firstR, OUT_COL_DATE), ws.Cells(lastR, OUT_COL_DATE)).NumberFormatLocal = "yyyy/m/d"
    ws.Range(ws.Cells(firstR, OUT_COL_TIME), ws.Cells(lastR, OUT_COL_TIME)).NumberFormatLocal = "hh:mm"
    ws.Range(ws.Cells(firstR, OUT_COL_WITHDRAW), ws.Cells(lastR, OUT_COL_DEPOSIT)).NumberFormatLocal = "#,##0.########"
    ws.Range(ws.Cells(firstR, OUT_COL_OTHER), ws.Cells(lastR, OUT_COL_OTHER)).NumberFormatLocal = "#,##0.########"
End Sub

Private Sub FormatNewWorkBalanceRows(ByVal ws As Worksheet, ByVal firstR As Long, ByVal lastR As Long)
    If firstR = 0 Or lastR < firstR Then Exit Sub
    ws.Range(ws.Cells(firstR, 1), ws.Cells(lastR, 5)).NumberFormatLocal = "@"
    ws.Range(ws.Cells(firstR, 9), ws.Cells(lastR, 9)).NumberFormatLocal = "@"
    ws.Range(ws.Cells(firstR, 11), ws.Cells(lastR, WORK_BAL_COL_PERSON_ID)).NumberFormatLocal = "@"
    ws.Range(ws.Cells(firstR, 6), ws.Cells(lastR, 8)).NumberFormatLocal = "yyyy/m/d"
    ws.Range(ws.Cells(firstR, 10), ws.Cells(lastR, 10)).NumberFormatLocal = "#,##0.########"
End Sub

Private Sub SnapshotAccountRows(ByVal ws As Worksheet, ByVal accountIDCol As Long, ByVal accountID As String, _
                                ByVal lastCol As Long, ByRef snapshot As Variant, ByRef snapshotCount As Long)
    Dim lastR As Long, r As Long, c As Long, outR As Long
    Dim sourceData As Variant
    snapshotCount = 0
    lastR = LastUsedRowInSheet(ws)
    If lastR < 2 Then Exit Sub
    sourceData = ws.Range(ws.Cells(2, 1), ws.Cells(lastR, lastCol)).Value
    For r = 1 To UBound(sourceData, 1)
        If CellText(sourceData(r, accountIDCol)) = accountID Then snapshotCount = snapshotCount + 1
    Next r
    If snapshotCount = 0 Then Exit Sub
    ReDim snapshot(1 To snapshotCount, 1 To lastCol)
    For r = 1 To UBound(sourceData, 1)
        If CellText(sourceData(r, accountIDCol)) = accountID Then
            outR = outR + 1
            For c = 1 To lastCol
                snapshot(outR, c) = sourceData(r, c)
            Next c
        End If
    Next r
End Sub

Private Sub DeleteOldRowsExceptTransfer(ByVal ws As Worksheet, ByVal accountIDCol As Long, _
                                        ByVal transferIDCol As Long, ByVal accountID As String, ByVal keepTransferID As String)
    Dim lastCol As Long
    If ws Is Nothing Then Exit Sub
    If ws.Name = SH_WORK_TX Then
        lastCol = WORK_TX_COL_PERSON_ID
    ElseIf ws.Name = SH_WORK_BAL Then
        lastCol = WORK_BAL_COL_PERSON_ID
    Else
        Err.Raise vbObjectError + 4114, "DeleteOldRowsExceptTransfer", "�ΏۊO�̓����V�[�g�ł�: " & ws.Name
    End If
    CompactDeleteDataRows ws, lastCol, accountIDCol, accountID, transferIDCol, keepTransferID, False
End Sub

Private Sub DeleteRowsByTransfer(ByVal ws As Worksheet, ByVal transferIDCol As Long, ByVal transferID As String)
    Dim lastCol As Long
    If Len(transferID) = 0 Then Exit Sub
    If ws Is Nothing Then Exit Sub
    If ws.Name = SH_WORK_TX Then
        lastCol = WORK_TX_COL_PERSON_ID
    ElseIf ws.Name = SH_WORK_BAL Then
        lastCol = WORK_BAL_COL_PERSON_ID
    Else
        Err.Raise vbObjectError + 4115, "DeleteRowsByTransfer", "�ΏۊO�̓����V�[�g�ł�: " & ws.Name
    End If
    CompactDeleteDataRows ws, lastCol, transferIDCol, transferID
End Sub

Private Sub RestoreSnapshotRows(ByVal ws As Worksheet, ByVal snapshot As Variant, ByVal rowCount As Long, ByVal lastCol As Long)
    Dim firstR As Long
    If rowCount = 0 Then Exit Sub
    firstR = LastUsedRowInSheet(ws) + 1
    If firstR < 2 Then firstR = 2
    ws.Range(ws.Cells(firstR, 1), ws.Cells(firstR + rowCount - 1, lastCol)).Value = snapshot
End Sub

Private Sub RollbackAccountWrite(ByVal accountID As String, ByVal transferID As String, ByVal editAccountID As String, _
                                 ByVal oldTx As Variant, ByVal oldTxCount As Long, ByVal oldBal As Variant, ByVal oldBalCount As Long, _
                                 ByVal oldMaster As Variant, ByVal oldMasterRow As Long)
    Dim wsTx As Worksheet, wsBal As Worksheet, wsAcc As Worksheet
    Dim r As Long
    Dim rollbackProblems As String
    Dim txCleared As Boolean, balCleared As Boolean
    Set wsTx = GetSheet(SH_WORK_TX)
    Set wsBal = GetSheet(SH_WORK_BAL)
    Set wsAcc = GetSheet(SH_WORK_ACCOUNT)

    On Error Resume Next
    If Len(editAccountID) > 0 Then
        Err.Clear
        CompactDeleteDataRows wsTx, WORK_TX_COL_PERSON_ID, WORK_TX_COL_ACCOUNT_ID, accountID
        If Err.Number <> 0 Then
            AppendTransferDetail rollbackProblems, "���������̏���: " & Err.Description
        Else
            txCleared = True
        End If
        Err.Clear
        CompactDeleteDataRows wsBal, WORK_BAL_COL_PERSON_ID, WORK_BAL_COL_ACCOUNT_ID, accountID
        If Err.Number <> 0 Then
            AppendTransferDetail rollbackProblems, "������c���̏���: " & Err.Description
        Else
            balCleared = True
        End If
        If txCleared Then
            Err.Clear
            RestoreSnapshotRows wsTx, oldTx, oldTxCount, WORK_TX_COL_PERSON_ID
            If Err.Number <> 0 Then AppendTransferDetail rollbackProblems, "������̏��߂�: " & Err.Description
        End If
        If balCleared Then
            Err.Clear
            RestoreSnapshotRows wsBal, oldBal, oldBalCount, WORK_BAL_COL_PERSON_ID
            If Err.Number <> 0 Then AppendTransferDetail rollbackProblems, "���c���̏��߂�: " & Err.Description
        End If
        Err.Clear
        FormatWorkTx
        If Err.Number <> 0 Then AppendTransferDetail rollbackProblems, "��������̕���: " & Err.Description
        Err.Clear
        FormatWorkBal
        If Err.Number <> 0 Then AppendTransferDetail rollbackProblems, "�c�������̕���: " & Err.Description
        Err.Clear
        r = FindAccountRowByID(accountID)
        If Err.Number <> 0 Then
            AppendTransferDetail rollbackProblems, "�����}�X�^�̌���: " & Err.Description
        ElseIf oldMasterRow > 0 Then
            If r = 0 Then r = oldMasterRow
            If r < 2 Then r = LastUsedRowInSheet(wsAcc) + 1
            If r >= 2 And r <= wsAcc.Rows.Count Then
                If Len(CellText(wsAcc.Cells(r, ACC_COL_ID).Value)) = 0 Or _
                   StrComp(CellText(wsAcc.Cells(r, ACC_COL_ID).Value), accountID, vbTextCompare) = 0 Then
                    Err.Clear
                    wsAcc.Range(wsAcc.Cells(r, 1), wsAcc.Cells(r, ACC_COL_TRANSFER_ID)).Value = oldMaster
                    If Err.Number <> 0 Then AppendTransferDetail rollbackProblems, "�������}�X�^�̏��߂�: " & Err.Description
                Else
                    AppendTransferDetail rollbackProblems, "�������}�X�^�̏����ʒu�ɕʌ���������܂��B"
                End If
            Else
                AppendTransferDetail rollbackProblems, "�������}�X�^�̏����ʒu���s���ł��B"
            End If
        End If
    Else
        Err.Clear
        DeleteRowsByTransfer wsTx, WORK_TX_COL_TRANSFER_ID, transferID
        If Err.Number <> 0 Then AppendTransferDetail rollbackProblems, "�V�K����̏���: " & Err.Description
        Err.Clear
        DeleteRowsByTransfer wsBal, WORK_BAL_COL_TRANSFER_ID, transferID
        If Err.Number <> 0 Then AppendTransferDetail rollbackProblems, "�V�K�c���̏���: " & Err.Description
        Err.Clear
        r = FindAccountRowByID(accountID)
        If Err.Number <> 0 Then
            AppendTransferDetail rollbackProblems, "�V�K�����}�X�^�̌���: " & Err.Description
        ElseIf r > 0 Then
            wsAcc.Rows(r).Delete
            If Err.Number <> 0 Then AppendTransferDetail rollbackProblems, "�V�K�����}�X�^�̏���: " & Err.Description
        End If
    End If
    On Error GoTo 0
    If Len(rollbackProblems) > 0 Then _
        Err.Raise vbObjectError + 4116, "RollbackAccountWrite", rollbackProblems
End Sub

Private Sub AppendTransferDetail(ByRef detailText As String, ByVal newDetail As String)
    newDetail = Trim$(newDetail)
    If Len(newDetail) = 0 Then Exit Sub
    If Len(detailText) > 0 Then detailText = detailText & " / "
    detailText = detailText & newDetail
End Sub

Private Function VerifyAccountRollback(ByVal accountID As String, ByVal editAccountID As String, _
                                       ByRef oldTx As Variant, ByVal expectedTxCount As Long, _
                                       ByRef oldBal As Variant, ByVal expectedBalCount As Long, _
                                       ByRef oldMaster As Variant) As String
    Dim problems As String
    If Len(editAccountID) > 0 Then
        If CountAccountRecords(GetSheet(SH_WORK_TX), WORK_TX_COL_ACCOUNT_ID, accountID) <> expectedTxCount Then problems = problems & "��������������O�ƈ�v���܂���B "
        If CountAccountRecords(GetSheet(SH_WORK_BAL), WORK_BAL_COL_ACCOUNT_ID, accountID) <> expectedBalCount Then problems = problems & "�c�������������O�ƈ�v���܂���B "
        If Not AccountRowsMatchSnapshot(GetSheet(SH_WORK_TX), WORK_TX_COL_ACCOUNT_ID, accountID, oldTx, expectedTxCount, WORK_TX_COL_PERSON_ID) Then problems = problems & "������e�������O�ƈ�v���܂���B "
        If Not AccountRowsMatchSnapshot(GetSheet(SH_WORK_BAL), WORK_BAL_COL_ACCOUNT_ID, accountID, oldBal, expectedBalCount, WORK_BAL_COL_PERSON_ID) Then problems = problems & "�c�����e�������O�ƈ�v���܂���B "
        If Not AccountMasterMatchesSnapshot(accountID, oldMaster) Then problems = problems & "�����}�X�^�������O�ƈ�v���܂���B "
    Else
        If CountAccountRecords(GetSheet(SH_WORK_TX), WORK_TX_COL_ACCOUNT_ID, accountID) > 0 Then problems = problems & "�ǉ�������c���Ă��܂��B "
        If CountAccountRecords(GetSheet(SH_WORK_BAL), WORK_BAL_COL_ACCOUNT_ID, accountID) > 0 Then problems = problems & "�ǉ��c�����c���Ă��܂��B "
        If FindAccountRowByID(accountID) > 0 Then problems = problems & "�ǉ��������c���Ă��܂��B "
    End If
    VerifyAccountRollback = Trim$(problems)
End Function

Private Function AccountRowsMatchSnapshot(ByVal ws As Worksheet, ByVal accountIDCol As Long, _
                                          ByVal accountID As String, ByRef snapshot As Variant, _
                                          ByVal expectedCount As Long, ByVal lastCol As Long) As Boolean
    Dim r As Long, c As Long, snapshotRow As Long
    Dim lastR As Long, sourceData As Variant
    If ws Is Nothing Then Exit Function
    If CountAccountRecords(ws, accountIDCol, accountID) <> expectedCount Then Exit Function
    If expectedCount = 0 Then
        AccountRowsMatchSnapshot = True
        Exit Function
    End If
    If Not IsArray(snapshot) Then Exit Function
    lastR = LastUsedRowInSheet(ws)
    If lastR < 2 Then Exit Function
    sourceData = ws.Range(ws.Cells(2, 1), ws.Cells(lastR, lastCol)).Value
    For r = 1 To UBound(sourceData, 1)
        If CellText(sourceData(r, accountIDCol)) = accountID Then
            snapshotRow = snapshotRow + 1
            If snapshotRow > expectedCount Then Exit Function
            For c = 1 To lastCol
                If CellText(sourceData(r, c)) <> CellText(snapshot(snapshotRow, c)) Then Exit Function
            Next c
        End If
    Next r
    AccountRowsMatchSnapshot = (snapshotRow = expectedCount)
End Function

Private Function AccountMasterMatchesSnapshot(ByVal accountID As String, ByRef snapshot As Variant) As Boolean
    Dim ws As Worksheet, r As Long, c As Long
    If Not IsArray(snapshot) Then Exit Function
    Set ws = GetSheet(SH_WORK_ACCOUNT)
    r = FindAccountRowByID(accountID)
    If r = 0 Then Exit Function
    For c = 1 To ACC_COL_TRANSFER_ID
        If CellText(ws.Cells(r, c).Value) <> CellText(snapshot(1, c)) Then Exit Function
    Next c
    AccountMasterMatchesSnapshot = True
End Function

'���łő����W���[������Ă΂��\�������邽�߁A�݊��p�Ɏc���B
Public Sub FormatWorkTx()
    Dim ws As Worksheet
    Set ws = GetSheet(SH_WORK_TX)
    FormatNewWorkTxRows ws, 2, LastUsedRowInSheet(ws)
End Sub

Public Sub FormatWorkBal()
    Dim ws As Worksheet
    Set ws = GetSheet(SH_WORK_BAL)
    FormatNewWorkBalanceRows ws, 2, LastUsedRowInSheet(ws)
End Sub

@echo off
setlocal
pushd "%~dp0"
"%SystemRoot%\System32\cscript.exe" //nologo "%~dp0CREATE_TOOL.vbs"
set "tool_exit_code=%errorlevel%"
popd
if not "%tool_exit_code%"=="0" pause
exit /b %tool_exit_code%

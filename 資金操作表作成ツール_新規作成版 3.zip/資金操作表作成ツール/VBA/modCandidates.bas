Attribute VB_Name = "modCandidates"
Option Explicit
Private mCandidateIndexes As Object

Public Sub BuildCandidateSheets(Optional ByVal resetContents As Boolean = False)
    If resetContents Then InvalidateCandidateCache
    SetupCandidateSheet SH_BANK_CAND, "��s�����", NM_LST_BANK_CAND, resetContents
    SetupCandidateSheet SH_BRANCH_CAND, "�x�X�����", NM_LST_BRANCH_CAND, resetContents
    SetupCandidateSheet SH_PERSON_CAND, "�l�����", NM_LST_PERSON_CAND, resetContents
End Sub

Private Sub SetupCandidateSheet(ByVal sheetName As String, ByVal titleText As String, ByVal listName As String, ByVal resetContents As Boolean)
    Dim ws As Worksheet
    On Error Resume Next
    Set ws = GetOrCreateSheet(sheetName, False)
    If ws Is Nothing Then Exit Sub
    ws.Visible = xlSheetVisible
    ws.Cells.Font.Name = "Yu Gothic UI"
    ws.Cells.Font.Size = 10
    If resetContents Or Len(CellText(ws.Range("A1").Value)) = 0 Then
        ws.Cells.Clear
        ws.Range("A1").Value = titleText
        ws.Range("A1").Font.Bold = True
        ws.Range("A2").Value = ""
    End If
    ws.Columns("A:A").ColumnWidth = 28
    RefreshSingleCandidateName sheetName, listName
    On Error GoTo 0
End Sub

Public Sub RefreshAccountCandidateNames()
    RefreshSingleCandidateName SH_BANK_CAND, NM_LST_BANK_CAND
    RefreshSingleCandidateName SH_BRANCH_CAND, NM_LST_BRANCH_CAND
    RefreshSingleCandidateName SH_PERSON_CAND, NM_LST_PERSON_CAND
    RefreshSingleCandidateName SH_ACCOUNT_TYPE, NM_LST_ACCOUNT_TYPE
    RefreshSingleCandidateName SH_TEKIYO, NM_LST_TEKIYO
End Sub

Private Sub RefreshSingleCandidateName(ByVal sheetName As String, ByVal listName As String)
    Dim ws As Worksheet
    Dim lastR As Long
    On Error Resume Next
    If Not SheetExists(sheetName) Then Exit Sub
    Set ws = GetSheet(sheetName)
    lastR = LastRow(ws, 1)
    If lastR < 2 Then
        ws.Range("A2").Value = ""
        lastR = 2
    End If
    ResetName listName, ws.Range("A2:A" & CStr(lastR))
    On Error GoTo 0
End Sub

Public Sub UpdateAccountCandidates(ByVal bankName As String, ByVal branchName As String, ByVal personName As String)
    AddCandidateValue SH_BANK_CAND, NM_LST_BANK_CAND, bankName
    AddCandidateValue SH_BRANCH_CAND, NM_LST_BRANCH_CAND, branchName
    AddCandidateValue SH_PERSON_CAND, NM_LST_PERSON_CAND, personName
End Sub

Public Sub UpdateCandidateFromTarget(ByVal Target As Range)
    If Target Is Nothing Then Exit Sub
    On Error Resume Next
    If Target.Worksheet.Name <> SH_INPUT Then Exit Sub
    Select Case Target.Address(False, False)
        Case CELL_BANK
            AddCandidateValue SH_BANK_CAND, NM_LST_BANK_CAND, CellText(Target.Value)
        Case CELL_BRANCH
            AddCandidateValue SH_BRANCH_CAND, NM_LST_BRANCH_CAND, CellText(Target.Value)
        Case CELL_PERSON
            AddCandidateValue SH_PERSON_CAND, NM_LST_PERSON_CAND, CellText(Target.Value)
    End Select
    On Error GoTo 0
End Sub

Private Sub AddCandidateValue(ByVal sheetName As String, ByVal listName As String, ByVal valueText As String)
    Dim ws As Worksheet, index As Object, raw As Variant, r As Long, lastR As Long, s As String
    s = Trim$(valueText)
    If Len(s) = 0 Then Exit Sub
    If Not SheetExists(sheetName) Then BuildCandidateSheets False
    If Not SheetExists(sheetName) Then Exit Sub
    Set ws = GetSheet(sheetName)
    If mCandidateIndexes Is Nothing Then Set mCandidateIndexes = CreateObject("Scripting.Dictionary")
    If mCandidateIndexes.Exists(sheetName) Then
        Set index = mCandidateIndexes(sheetName)
    Else
        Set index = CreateObject("Scripting.Dictionary"): index.CompareMode = vbTextCompare
        raw = ws.Range("A1:A" & Application.Max(2, LastRow(ws))).Value2
        For r = 2 To UBound(raw, 1)
            If HasText(raw(r, 1)) Then index(CellText(raw(r, 1))) = True
        Next r
        mCandidateIndexes.Add sheetName, index
    End If
    If index.Exists(s) Then Exit Sub
    lastR = Application.Max(1, LastRow(ws))
    ws.Cells(lastR + 1, 1).NumberFormat = "@"
    ws.Cells(lastR + 1, 1).Value2 = s
    index.Add s, True
    RefreshSingleCandidateName sheetName, listName
End Sub

Public Sub RememberAccountType(ByVal subject As String)
    AddCandidateValue SH_ACCOUNT_TYPE, NM_LST_ACCOUNT_TYPE, subject
End Sub

Public Sub EnsureDefaultAccountTypes()
    Dim subjects As Variant, i As Long
    subjects = Array( _
        "���ʗa��", "�����a��", "����a��", "�ʏ풙��", "��z����", _
        "���~�a��", "�ʏ풙�~����", "�ʒm�a��", "�[�ŏ����a��", "�ϗ�����a��", _
        "�������a��", "�����w����", "�ϓ��������", "����ϋ�", "��������", _
        "�U�֌���", "�S�ے�z����", "�S�ے������", "�����ϗ���z", "�����ϗ����", _
        "���`���~", "���Y�`����z", "���Y�`���N��", "���Y�`���Z��", "�O�ݕ��ʗa��", _
        "�O�ݒ���a��", "�O�ݗa��", "��", "���̑�")
    For i = LBound(subjects) To UBound(subjects): RememberAccountType CStr(subjects(i)): Next i
End Sub

Public Sub InvalidateCandidateCache(Optional ByVal sheetName As String = "")
    If mCandidateIndexes Is Nothing Then Exit Sub
    If Len(sheetName) = 0 Then
        Set mCandidateIndexes = Nothing
    ElseIf mCandidateIndexes.Exists(sheetName) Then
        mCandidateIndexes.Remove sheetName
    End If
End Sub

Attribute VB_Name = "modWorkflow"
Option Explicit

Public Sub InvalidateOutputViews()
    GetSheet(SH_INPUT).Range("X7").Value2 = "1"
    InvalidateShiftSession
End Sub

Public Sub ApplySettingsAndReturn()
    If ApplyPendingSettings() Then ShowInputSheet
End Sub

Public Sub OpenShopNames()
    If Not RequireToolReady() Then Exit Sub
    If Not ApplyPendingSettings() Then Exit Sub
    On Error GoTo EH
    AppBegin "�戵�X��\�����Ă��܂�..."
    EnsureCurrentOutputs
    GetSheet(SH_SHOP_TARGET).Activate
    AppEnd
    Exit Sub
EH:
    Dim originalErrorText As String
    originalErrorText = Err.Description
    AppEnd
    MsgBox originalErrorText, vbExclamation
End Sub

Public Sub ApplyShopNamesToOutput(Optional ByVal destination As Worksheet = Nothing, Optional ByVal mappingSheet As Worksheet = Nothing)
    Dim ws As Worksheet, target As Worksheet, map As Object, r As Long, key As String, s As String
    If destination Is Nothing Then Set ws = GetSheet(SH_OUTPUT_TX) Else Set ws = destination
    If mappingSheet Is Nothing Then Set target = GetSheet(SH_SHOP_TARGET) Else Set target = mappingSheet
    Set map = CreateObject("Scripting.Dictionary")
    For r = 2 To LastRow(target)
        s = CellText(target.Cells(r, SHOP_TGT_COL_RESULT).Value2)
        If Len(s) > 0 And CellText(target.Cells(r, SHOP_TGT_COL_STATUS).Value2) <> "�ۗ�" Then
            key = CellText(target.Cells(r, SHOP_TGT_COL_BANK).Value2) & Chr$(30) & NormalizeShopCodeText(CellText(target.Cells(r, SHOP_TGT_COL_CODE).Value2))
            map(key) = s
        End If
    Next r
    For r = 2 To LastUsedRowInSheet(ws)
        s = CellText(ws.Cells(r, OUT_COL_SHOP).Value2)
        If IsCodeLikeShop(s) Then
            key = CellText(ws.Cells(r, OUT_COL_BANK).Value2) & Chr$(30) & NormalizeShopCodeText(s)
            If map.Exists(key) Then ws.Cells(r, OUT_COL_SHOP).Value2 = map(key)
        End If
    Next r
End Sub

Public Function RequirePostedInput() As Boolean
    If InputIsDirty Then
        ShowInputSheet
        UpdateInputStateLabel
        MsgBox "���͒��̓��e�������f�ł��B�u�]�L���Ď��ցv�܂��́u�����𔽉f�v�������Ă���J���Ă��������B���͂��������ꍇ�́u���͑���v�̏������g���܂��B", vbExclamation
        Exit Function
    End If
    RequirePostedInput = True
End Function

Public Sub EnsureCurrentOutputs()
    If CellText(GetSheet(SH_INPUT).Range("X7").Value2) <> "0" Then RefreshAllOutputs
    If GetSheet(SH_OUTPUT_TX).Visible <> xlSheetVisible Then GetSheet(SH_OUTPUT_TX).Visible = xlSheetVisible
    If GetSheet(SH_OUTPUT_BAL).Visible <> xlSheetVisible Then GetSheet(SH_OUTPUT_BAL).Visible = xlSheetVisible
    If GetSheet(SH_SHOP_TARGET).Visible <> xlSheetVisible Then GetSheet(SH_SHOP_TARGET).Visible = xlSheetVisible
End Sub

Public Sub ProtectGeneratedOutput(ByVal ws As Worksheet)
    ws.Protect Password:=TOOL_PASSWORD, UserInterfaceOnly:=True, DrawingObjects:=True, AllowFiltering:=True
    ws.EnableSelection = xlNoRestrictions
End Sub

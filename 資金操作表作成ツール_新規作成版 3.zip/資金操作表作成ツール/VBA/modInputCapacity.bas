Attribute VB_Name = "modInputCapacity"
Option Explicit

Private Const CELL_INPUT_LAST_ROW As String = "X15"
Private Const INPUT_ROW_STEP As Long = 500
Private mInputLastRow As Long

Public Function InputLastTransactionRow() As Long
    Dim v As Variant
    If mInputLastRow = 0 Then
        v = GetSheet(SH_INPUT).Range(CELL_INPUT_LAST_ROW).Value2
        mInputLastRow = TX_LAST_ROW
        If IsNumeric(v) Then
            If CDbl(v) >= TX_LAST_ROW And CDbl(v) <= GetSheet(SH_INPUT).Rows.Count Then mInputLastRow = CLng(v)
        End If
    End If
    InputLastTransactionRow = mInputLastRow
End Function

Public Sub ResetInputCapacityCache()
    mInputLastRow = 0
End Sub

Public Function InputTransactionRange() As Range
    Set InputTransactionRange = GetSheet(SH_INPUT).Range("B" & TX_FIRST_ROW & ":K" & InputLastTransactionRow())
End Function

Public Function LastInputDataRow() As Long
    Dim hit As Range
    Set hit = InputTransactionRange().Find(What:="*", After:=GetSheet(SH_INPUT).Cells(TX_FIRST_ROW, COL_TX_YEAR), _
        LookIn:=xlFormulas, LookAt:=xlPart, SearchOrder:=xlByRows, SearchDirection:=xlPrevious, MatchCase:=False, MatchByte:=False, SearchFormat:=False)
    LastInputDataRow = TX_FIRST_ROW - 1
    If Not hit Is Nothing Then LastInputDataRow = hit.Row
End Function

Public Sub EnsureTransactionCapacity(ByVal requiredCount As Long)
    Dim ws As Worksheet, oldLast As Long, newLast As Long, maxCount As Long
    Dim message As String, started As Boolean
    Set ws = GetSheet(SH_INPUT)
    oldLast = InputLastTransactionRow()
    If requiredCount <= oldLast - TX_FIRST_ROW + 1 Then Exit Sub
    maxCount = ws.Rows.Count - TX_FIRST_ROW + 1
    If requiredCount > maxCount Then Err.Raise vbObjectError + 2901, , "Excel�̍s���𒴂��邽�߁A����ȏ㖾�ׂ�ǉ��ł��܂���B"
    newLast = TX_FIRST_ROW - 1 + Application.Min(maxCount, ((requiredCount + INPUT_ROW_STEP - 1) \ INPUT_ROW_STEP) * INPUT_ROW_STEP)
    On Error GoTo EH
    AppBegin "���ח����L���Ă��܂�..."
    started = True
    ws.Unprotect Password:=TOOL_PASSWORD
    FormatAdditionalInputRows ws, oldLast + 1, newLast
    ws.ScrollArea = "A1:K" & newLast
    ws.Range(CELL_INPUT_LAST_ROW).Value2 = newLast
    mInputLastRow = newLast
    ProtectInputSheet
    AppEnd
    Exit Sub
EH:
    message = Err.Description
    ProtectInputSheet
    If started Then AppEnd
    Err.Raise vbObjectError + 2902, "EnsureTransactionCapacity", "���ח���ǉ��ł��܂���ł����B���͍ς݂̓��e�͎c���Ă��܂��B" & vbCrLf & message
End Sub

Private Sub FormatAdditionalInputRows(ByVal ws As Worksheet, ByVal firstRow As Long, ByVal lastRow As Long)
    Dim body As Range
    Set body = ws.Range("B" & firstRow & ":K" & lastRow)
    With body
        .Font.Name = "Yu Gothic UI": .Font.Size = 10: .Font.Color = RGB(15, 23, 42)
        .Interior.Color = vbWhite: .WrapText = False: .Locked = False
        .Borders.LineStyle = xlContinuous: .Borders.Color = RGB(226, 232, 240)
        .NumberFormat = "General"
    End With
    ws.Rows(firstRow & ":" & lastRow).RowHeight = 23
    ws.Range("B" & firstRow & ":D" & lastRow).NumberFormat = "0"
    ws.Range("E" & firstRow & ":E" & lastRow).NumberFormat = "@"
    ws.Range("F" & firstRow & ":G" & lastRow).NumberFormat = "@"
    ws.Range("F" & firstRow & ":G" & lastRow).HorizontalAlignment = xlRight
    ws.Range("H" & firstRow & ":K" & lastRow).NumberFormat = "@"
    ApplyValidationInputOnly ws.Range("B" & firstRow & ":G" & lastRow), xlIMEModeOff
    ApplyValidationInputOnly ws.Range("H" & firstRow & ":I" & lastRow), xlIMEModeOff
    ApplyValidationList ws.Range("J" & firstRow & ":J" & lastRow), NM_LST_TEKIYO, xlIMEModeHiragana, True
    ApplyValidationInputOnly ws.Range("K" & firstRow & ":K" & lastRow), xlIMEModeHiragana
End Sub

Public Sub AddTransactionInputRows()
    Dim message As String
    On Error GoTo EH
    EnsureTransactionCapacity InputLastTransactionRow() - TX_FIRST_ROW + 1 + INPUT_ROW_STEP
    Exit Sub
EH:
    message = Err.Description
    MsgBox message, vbExclamation
End Sub

Public Sub GoToTransactionEnd()
    Dim r As Long, ws As Worksheet, message As String
    On Error GoTo EH
    Set ws = GetSheet(SH_INPUT)
    r = LastInputDataRow() + 1
    EnsureTransactionCapacity r - TX_FIRST_ROW + 1
    SafeSelectCell ws, ws.Cells(r, IIf(r = TX_FIRST_ROW, COL_TX_YEAR, COL_TX_DAY)).Address
    Exit Sub
EH:
    message = Err.Description
    MsgBox message, vbExclamation
End Sub

Public Sub CopyPreviousDescription()
    Dim ws As Worksheet, values As Variant, r As Long, s As String, message As String
    On Error GoTo EH
    If Not ActiveWorkbook Is ThisWorkbook Then Exit Sub
    Set ws = GetSheet(SH_INPUT)
    If Not ActiveSheet Is ws Then Exit Sub
    If ActiveCell.Row <= TX_FIRST_ROW Or ActiveCell.Row > InputLastTransactionRow() Then Exit Sub
    values = ws.Range("J" & TX_FIRST_ROW & ":J" & ActiveCell.Row - 1).Value2
    If Not IsArray(values) Then
        s = CellText(values)
    Else
        For r = UBound(values, 1) To 1 Step -1
            s = CellText(values(r, 1))
            If Len(s) > 0 And s <> "����" Then Exit For
        Next r
    End If
    If Len(s) = 0 Or s = "����" Then Exit Sub
    ws.Cells(ActiveCell.Row, COL_TX_TEKIYO).Value2 = s
    SafeSelectCell ws, ws.Cells(ActiveCell.Row, COL_TX_TEKIYO).Address
    Exit Sub
EH:
    message = Err.Description
    MsgBox message, vbExclamation
End Sub

Public Sub FitEmptyTransactionCapacity(ByVal requiredCount As Long)
    Dim ws As Worksheet, desired As Long, oldLast As Long
    Set ws = GetSheet(SH_INPUT)
    oldLast = InputLastTransactionRow()
    desired = Application.Max(TX_LAST_ROW, TX_FIRST_ROW - 1 + ((requiredCount + INPUT_ROW_STEP - 1) \ INPUT_ROW_STEP) * INPUT_ROW_STEP)
    If desired >= oldLast Then Exit Sub
    '�����ؑցE���׏����ŋ�ɂȂ������͗��������k�߂�B
    ws.Range("B" & desired + 1 & ":K" & oldLast).Locked = True
    ws.Range(CELL_INPUT_LAST_ROW).Value2 = desired
    mInputLastRow = desired
    ws.ScrollArea = "A1:K" & desired
End Sub

Attribute VB_Name = "modAmountInput"
Option Explicit

Private mEntryRange As Range

Public Function TransactionAmountInputRange() As Range
    Set TransactionAmountInputRange = GetSheet(SH_INPUT).Range( _
        "F" & TX_FIRST_ROW & ":G" & InputLastTransactionRow())
End Function

Public Function ParseTransactionMoney(ByVal value As Variant, ByRef ok As Boolean) As Variant
    Dim s As String, p As Long, dotCount As Long, baseValue As Variant, digits As String
    ok = False
    If IsError(value) Then Exit Function
    s = CellText(value)
    On Error Resume Next
    s = StrConv(s, vbNarrow)
    On Error GoTo Invalid
    p = Len(s)
    Do While p > 0
        If Mid$(s, p, 1) <> "." Then Exit Do
        p = p - 1
    Loop
    dotCount = Len(s) - p
    If dotCount = 0 Then
        ParseTransactionMoney = ParseMoney(value, False, ok)
        Exit Function
    End If
    baseValue = ParseMoney(Left$(s, p), False, ok)
    If Not ok Then Exit Function
    ok = False
    If Not HasText(baseValue) Then Exit Function
    If CDbl(baseValue) = 0 Then ParseTransactionMoney = 0#: ok = True: Exit Function
    digits = Format$(CDbl(baseValue), "0")
    '�����̋��z���15�����A���l������O�Ɋm�F����B�ۂ߂ēo�^���Ȃ��B
    If Len(digits) + dotCount * 3 > 15 Then Exit Function
    ParseTransactionMoney = CDbl(digits & String$(dotCount * 3, "0"))
    ok = True
    Exit Function
Invalid:
    ok = False
End Function

Private Function AmountIntersection(ByVal Target As Range) As Range
    If Target Is Nothing Then Exit Function
    If Not Target.Worksheet Is GetSheet(SH_INPUT) Then Exit Function
    Set AmountIntersection = Intersect(Target, TransactionAmountInputRange())
End Function

Private Sub FormatAmountCells(ByVal Target As Range)
    Dim blanks As Range, area As Range, hit As Range
    Set hit = AmountIntersection(Target)
    If hit Is Nothing Then Exit Sub
    hit.NumberFormat = "#,##0"
    hit.HorizontalAlignment = xlRight
    '�V�������͐�����O�ɕ����񏑎��ɂ��A50. �̖�����Excel�ɏ������Ȃ��B
    For Each area In hit.Areas
        If area.Cells.CountLarge = 1 Then
            If IsEmpty(area.Value2) And Not area.HasFormula Then area.NumberFormat = "@"
        Else
            Set blanks = Nothing
            On Error Resume Next
            Set blanks = area.SpecialCells(xlCellTypeBlanks)
            On Error GoTo 0
            If Not blanks Is Nothing Then
                Set blanks = Intersect(area, blanks)
                If Not blanks Is Nothing Then blanks.NumberFormat = "@"
            End If
        End If
    Next area
End Sub

Public Sub ResetTransactionAmountFormatting()
    Set mEntryRange = Nothing
    FormatAmountCells TransactionAmountInputRange()
End Sub

Public Sub ReleaseTransactionAmountEntry()
    If mEntryRange Is Nothing Then Exit Sub
    FormatAmountCells mEntryRange
    Set mEntryRange = Nothing
End Sub

Public Sub PrepareTransactionAmountEntry()
    Dim nextRange As Range, currentFormat As Variant
    If Not ActiveWorkbook Is ThisWorkbook Then Exit Sub
    If ActiveSheet.Name <> SH_INPUT Then Exit Sub
    If TypeName(Selection) <> "Range" Then Exit Sub
    Set nextRange = AmountIntersection(Selection)
    If Not mEntryRange Is Nothing Then
        If Not nextRange Is Nothing Then
            If mEntryRange.Address = nextRange.Address Then
                currentFormat = nextRange.NumberFormat
                If Not IsNull(currentFormat) Then
                    If CStr(currentFormat) = "@" Then Exit Sub
                End If
            Else
                ReleaseTransactionAmountEntry
            End If
        Else
            ReleaseTransactionAmountEntry
        End If
    End If
    If nextRange Is Nothing Then Exit Sub
    nextRange.NumberFormat = "@"
    nextRange.HorizontalAlignment = xlRight
    Set mEntryRange = nextRange
End Sub

Public Sub NormalizeTransactionAmountChange(ByVal Target As Range)
    Dim hit As Range, cell As Range, amount As Variant, value As Variant, ok As Boolean
    Dim savedEvents As Boolean, errorNumber As Long, errorText As String
    Set hit = AmountIntersection(Target)
    If hit Is Nothing Then Exit Sub
    savedEvents = Application.EnableEvents
    On Error GoTo EH
    Application.EnableEvents = False
    For Each cell In hit.Cells
        If Not cell.HasFormula Then
            value = cell.Value2
            If HasText(value) And Not IsError(value) Then
                '�����񏑎��Ŏ󂯎�����ʏ��Excel�������A�]���ǂ��舵���B
                If Left$(CellText(value), 1) = "=" Then
                    cell.NumberFormat = "General"
                    On Error Resume Next
                    cell.FormulaLocal = CStr(value)
                    If Err.Number <> 0 Then
                        Err.Clear
                        cell.NumberFormat = "@"
                        cell.Value2 = CStr(value)
                    End If
                    On Error GoTo EH
                Else
                    amount = ParseTransactionMoney(value, ok)
                    If ok Then
                        '���l�Ŋm�肵�ASUM��]�L�E���[�̌v�Z�ɂ��̂܂܎g����悤�ɂ���B
                        cell.NumberFormat = "General"
                        cell.Value2 = CDbl(amount)
                    ElseIf VarType(value) <> vbString Then
                        '�����ȏ������𐮐��\���ŉB�����A���̓��͂�������܂܎c���B
                        cell.NumberFormat = "@"
                        cell.Value2 = CStr(value)
                    End If
                End If
            End If
        End If
    Next cell
    FormatAmountCells hit
    'Ctrl+Enter���œ����Z���ɗ��܂��Ă��A���̒������͂��󂯎����Ԃɖ߂��B
    PrepareTransactionAmountEntry
    Application.EnableEvents = savedEvents
    Exit Sub
EH:
    errorNumber = Err.Number: errorText = Err.Description
    Application.EnableEvents = savedEvents
    Err.Raise errorNumber, "NormalizeTransactionAmountChange", errorText
End Sub

Public Function TransactionAmountStatus(ByVal Target As Range) As String
    Dim hit As Range, amount As Variant, ok As Boolean, label As String
    If Target Is Nothing Then Exit Function
    If Target.Cells.CountLarge <> 1 Then Exit Function
    Set hit = AmountIntersection(Target)
    If hit Is Nothing Then Exit Function
    label = IIf(hit.Column = COL_TX_WITHDRAW, "�o��", "����")
    amount = ParseTransactionMoney(hit.Value2, ok)
    If ok And HasText(amount) Then
        TransactionAmountStatus = label & "�@" & Format$(CDbl(amount), "#,##0") & "�~�@�^�@������ . ��000�ǉ�"
    ElseIf IsError(hit.Value2) Or HasText(hit.Value2) Then
        TransactionAmountStatus = label & "�@���͂��m�F���Ă��������B��F50. �� 50,000�A50.. �� 50,000,000"
    Else
        TransactionAmountStatus = label & "�@������ . ��000�ǉ��@��F50. �� 50,000�A50.. �� 50,000,000"
    End If
End Function

Attribute VB_Name = "modUI"
Option Explicit

Private mButtonSeq As Long

Public Sub BuildOperationPanel(ByVal ws As Worksheet, Optional ByVal arrangeLayout As Boolean = False)
    Dim shp As Shape
    If ws Is Nothing Then Exit Sub
    ws.Unprotect Password:=TOOL_PASSWORD
    On Error Resume Next
    Set shp = ws.Shapes(UI_PREFIX & "main_0")
    On Error GoTo 0
    If shp Is Nothing Or arrangeLayout Then PolishInputLayout ws
    If Not ws.Range("B7").MergeCells Then MergeAndFormat ws.Range("B7:K7"), ""
    UpdateInputActionButtons ws
    RefreshInputHeadings ws
    ProtectInputSheet
End Sub

Public Sub UpdateInputActionButtons(ByVal ws As Worksheet)
    Dim x As Double, y As Double, w As Double, bw As Double, i As Long
    Dim weights As Variant, captions As Variant, actions As Variant, editing As Boolean, dirty As Boolean
    Dim wasProtected As Boolean, errorNumber As Long, errorText As String
    If ws Is Nothing Then Exit Sub
    On Error GoTo EH
    wasProtected = ws.ProtectContents Or ws.ProtectDrawingObjects
    If wasProtected Then ws.Unprotect Password:=TOOL_PASSWORD
    editing = (Len(CurrentEditAccountID()) > 0): dirty = InputIsDirty()
    captions = Array("�]�L���Ď���", "���͂���蒼��", "�o�^����", "���[��\��", "Excel�o��", "�ۑ�", "�ݒ�")
    actions = Array("TransferCurrentAccount", "DiscardInput", "ShowRegisteredAccounts", "BuildAllOutputSheets", "ExportFinalWorkbooks", "SaveToolWorkbook", "ShowConfigSheet")
    If editing Then
        captions(0) = "�����𔽉f"
        captions(1) = IIf(dirty, "���f���ĐV�K����", "�V����������")
        captions(2) = IIf(dirty, "���f���Č����I��", "�o�^����")
        actions(1) = "ReflectAndStartNewAccount": actions(2) = "ReflectAndSelectAccount"
    End If
    weights = Array(1.15, 1.45, 1.45, 1.1, 1#, 0.65, 0.65)
    x = ws.Range("B3").Left: y = ws.Range("B3").Top + 3
    w = ws.Range("B3:K3").Width - 56
    For i = 0 To 6
        bw = w * CDbl(weights(i)) / 7.45
        PutToolButton ws, "main_" & i, x, y, bw, 30, CStr(captions(i)), CStr(actions(i)), IIf(i = 0, "primary", "tool")
        x = x + bw
        If i = 2 Or i = 4 Then x = x + 16 Else x = x + 6
    Next i
    If wasProtected Then ProtectInputSheet
    Exit Sub
EH:
    errorNumber = Err.Number: errorText = Err.Description
    If wasProtected Then ProtectInputSheet
    Err.Raise errorNumber, "UpdateInputActionButtons", errorText
End Sub

Public Sub AddPanelBack(ByVal ws As Worksheet, ByVal x As Double, ByVal y As Double, ByVal w As Double, ByVal h As Double)
    Dim shp As Shape
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    Set shp = ws.Shapes.AddShape(msoShapeRoundedRectangle, x, y, w, h)
    If Not shp Is Nothing Then
        With shp
            .Name = UI_PREFIX & "panel_back"
            .Fill.ForeColor.RGB = RGB(255, 255, 255)
            .Line.ForeColor.RGB = RGB(203, 213, 225)
            .Line.Weight = 1
            '�p�l���w�i�͌�h���b�O�œ����Ȃ��悤���b�N����B
            'xlMove�ɂ��āA�񕝒������ɃJ�[�h���s�p�ӂɐL�k���Ȃ��悤�ɂ���B
            .Placement = xlMove
            .Locked = True
            .ZOrder msoSendToBack
            .Shadow.Visible = msoTrue
            .Shadow.Transparency = 0.88
            .Shadow.Blur = 7
            .Shadow.OffsetX = 0
            .Shadow.OffsetY = 2
        End With
    End If
    On Error GoTo 0
End Sub

Public Sub AddUIButton(ByVal ws As Worksheet, ByVal x As Double, ByVal y As Double, ByVal w As Double, ByVal h As Double, ByVal caption As String, ByVal macroName As String, ByVal styleName As String)
    mButtonSeq = mButtonSeq + 1
    PutToolButton ws, "btn_" & CStr(mButtonSeq), x, y, w, h, caption, macroName, styleName
End Sub

Public Sub PutToolButton(ByVal ws As Worksheet, ByVal key As String, ByVal x As Double, ByVal y As Double, ByVal w As Double, ByVal h As Double, ByVal caption As String, ByVal macroName As String, ByVal styleName As String)
    Dim shp As Shape
    Dim fillColor As Long, lineColor As Long, fontColor As Long, created As Boolean, desired As String
    If ws Is Nothing Then Exit Sub
    GetButtonColors styleName, fillColor, lineColor, fontColor
    If IsLightExcelColor(fillColor) And IsLightExcelColor(fontColor) Then fontColor = RGB(15, 23, 42)
    On Error Resume Next
    Set shp = ws.Shapes(UI_PREFIX & key)
    On Error GoTo 0
    If shp Is Nothing Then
        Set shp = ws.Shapes.AddShape(msoShapeRoundedRectangle, x, y, w, h)
        shp.Name = UI_PREFIX & key
        created = True
    End If
    desired = MacroRef(macroName)
    With shp
        If Abs(.Left - x) > 0.1 Then .Left = x
        If Abs(.Top - y) > 0.1 Then .Top = y
        If Abs(.Width - w) > 0.1 Then .Width = w
        If Abs(.Height - h) > 0.1 Then .Height = h
        If .TextFrame.Characters.Text <> caption Then .TextFrame.Characters.Text = caption
        If .OnAction <> desired Then .OnAction = desired
        If .AlternativeText <> macroName Then .AlternativeText = macroName
        If .Visible <> msoTrue Then .Visible = msoTrue
    End With
    If created Then
        With shp
            .TextFrame.HorizontalAlignment = IIf(styleName = "soft", xlHAlignLeft, xlHAlignCenter)
            .TextFrame.VerticalAlignment = xlVAlignCenter
            .TextFrame.MarginLeft = 2
            .TextFrame.MarginRight = 2
            .TextFrame.MarginTop = 0
            .TextFrame.MarginBottom = 0
            .TextFrame.Characters.Font.Name = "Yu Gothic UI"
            .TextFrame.Characters.Font.Size = IIf(h >= 30, 10, 9.5)
            .TextFrame.Characters.Font.Bold = True
            .TextFrame.Characters.Font.Color = fontColor
            .Fill.ForeColor.RGB = fillColor
            .Line.ForeColor.RGB = lineColor
            .Line.Weight = 0.8
            '�p�l���w�i�͌�h���b�O�œ����Ȃ��悤���b�N����B
            'xlMove�ɂ��āA�񕝒������ɃJ�[�h���s�p�ӂɐL�k���Ȃ��悤�ɂ���B
            .Placement = xlMove
            .Locked = True
            .DrawingObject.PrintObject = False
            .Shadow.Visible = msoFalse
        End With
    End If
End Sub

Private Sub GetButtonColors(ByVal styleName As String, ByRef fillColor As Long, ByRef lineColor As Long, ByRef fontColor As Long)
    fontColor = RGB(15, 23, 42)
    Select Case LCase$(styleName)
        Case "hero"
            fillColor = RGB(20, 184, 166)
            lineColor = RGB(13, 148, 136)
            fontColor = RGB(255, 255, 255)
        Case "primary"
            fillColor = RGB(37, 99, 235)
            lineColor = RGB(29, 78, 216)
            fontColor = RGB(255, 255, 255)
        Case "accent"
            fillColor = RGB(14, 165, 233)
            lineColor = RGB(2, 132, 199)
            fontColor = RGB(255, 255, 255)
        Case "export"
            fillColor = RGB(124, 58, 237)
            lineColor = RGB(109, 40, 217)
            fontColor = RGB(255, 255, 255)
        Case "danger"
            fillColor = RGB(239, 68, 68)
            lineColor = RGB(220, 38, 38)
            fontColor = RGB(255, 255, 255)
        Case "neutral"
            fillColor = RGB(241, 245, 249)
            lineColor = RGB(203, 213, 225)
            fontColor = RGB(15, 23, 42)
        Case "tool"
            fillColor = RGB(255, 255, 255)
            lineColor = RGB(203, 213, 225)
            fontColor = RGB(30, 64, 175)
        Case "soft"
            fillColor = RGB(248, 250, 252)
            lineColor = RGB(226, 232, 240)
            fontColor = RGB(51, 65, 85)
        Case Else
            fillColor = RGB(248, 250, 252)
            lineColor = RGB(203, 213, 225)
            fontColor = RGB(15, 23, 42)
    End Select
End Sub

Public Sub AddConfigButton(ByVal ws As Worksheet, ByVal cellAddress As String, ByVal caption As String, ByVal macroName As String)
    Dim a As Range
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    Set a = ws.Range(cellAddress)
    On Error GoTo 0
    If a Is Nothing Then Exit Sub
    AddUIButton ws, a.Left, a.Top, 150, 28, caption, macroName, "tool"
End Sub

Public Sub BuildInputHelpCards(ByVal ws As Worksheet)
    If ws Is Nothing Then Exit Sub
    ws.Range("M2:T14").ClearContents
End Sub

Public Sub RefreshButtonActions(Optional ByVal targetBookName As String = "")
    Dim ws As Worksheet, shp As Shape, macroName As String, desired As String
    Dim wasContents As Boolean, wasDrawing As Boolean, wasScenarios As Boolean
    Dim unlocked As Boolean, errorText As String
    On Error GoTo EH
    For Each ws In ThisWorkbook.Worksheets
        unlocked = False
        wasContents = ws.ProtectContents: wasDrawing = ws.ProtectDrawingObjects: wasScenarios = ws.ProtectScenarios
        For Each shp In ws.Shapes
            If Left$(shp.Name, Len(UI_PREFIX)) = UI_PREFIX Then
                macroName = shp.AlternativeText
                If Len(macroName) > 0 Then
                    desired = MacroRef(macroName, targetBookName)
                    If shp.OnAction <> desired Then
                        If Not unlocked And (wasContents Or wasDrawing Or wasScenarios) Then
                            ws.Unprotect Password:=TOOL_PASSWORD
                            unlocked = True
                        End If
                        shp.OnAction = desired
                    End If
                End If
            End If
        Next shp
        If unlocked Then ws.Protect Password:=TOOL_PASSWORD, DrawingObjects:=wasDrawing, Contents:=wasContents, Scenarios:=wasScenarios, UserInterfaceOnly:=True, AllowFiltering:=True
    Next ws
    Exit Sub
EH:
    errorText = Err.Description
    On Error Resume Next
    If unlocked Then ws.Protect Password:=TOOL_PASSWORD, DrawingObjects:=wasDrawing, Contents:=wasContents, Scenarios:=wasScenarios, UserInterfaceOnly:=True, AllowFiltering:=True
    On Error GoTo 0
    Err.Raise vbObjectError + 2802, "RefreshButtonActions", "�{�^���̎Q�Ɛ���X�V�ł��܂���ł����B" & errorText
End Sub

Public Sub FormatHeader(ByVal rng As Range, Optional ByVal fillColor As Long = 0)
    If rng Is Nothing Then Exit Sub
    If fillColor = 0 Then fillColor = RGB(226, 232, 240)
    With rng
        .Font.Bold = True
        .Font.Color = RGB(15, 23, 42)
        .Interior.Color = fillColor
        .Borders.LineStyle = xlContinuous
        .Borders.Color = RGB(203, 213, 225)
        .VerticalAlignment = xlCenter
    End With
End Sub

Public Sub FormatOutputHeader(ByVal rng As Range)
    If rng Is Nothing Then Exit Sub
    With rng
        .Font.Bold = True
        .Font.Size = 14
        .Font.Color = RGB(255, 255, 255)
        .Interior.Color = RGB(30, 64, 175)
        .HorizontalAlignment = xlCenter
        .VerticalAlignment = xlCenter
        .Borders.LineStyle = xlContinuous
        .Borders.Color = RGB(147, 197, 253)
    End With
End Sub

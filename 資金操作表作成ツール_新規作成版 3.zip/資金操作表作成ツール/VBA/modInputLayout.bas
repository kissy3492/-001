Attribute VB_Name = "modInputLayout"
Option Explicit

Private Const CELL_ACCOUNT_FOLDED As String = "X12"
Private Const CELL_BALANCE_FOLDED As String = "X13"

Public Sub SetInputSections(ByVal showAccount As Boolean, ByVal showBalances As Boolean)
    Dim ws As Worksheet, changed As Boolean
    On Error GoTo EH
    Set ws = GetSheet(SH_INPUT)
    changed = (ws.Rows(5).Hidden = showAccount Or ws.Rows(9).Hidden = showBalances)
    If Not changed Then Exit Sub
    AppBegin
    ws.Unprotect Password:=TOOL_PASSWORD
    ws.Range(CELL_ACCOUNT_FOLDED).Value2 = IIf(showAccount, "0", "1")
    ws.Range(CELL_BALANCE_FOLDED).Value2 = IIf(showBalances, "0", "1")
    ApplyInputSections ws
    AppEnd
    Exit Sub
EH:
    Dim message As String
    message = Err.Description
    AppEnd
    Err.Raise vbObjectError + 2701, "SetInputSections", message
End Sub

Public Sub ApplyInputSections(ByVal ws As Worksheet)
    ws.Unprotect Password:=TOOL_PASSWORD
    If ws.Rows(5).Hidden <> (CellText(ws.Range(CELL_ACCOUNT_FOLDED).Value2) = "1") Then ws.Rows("5:6").Hidden = (CellText(ws.Range(CELL_ACCOUNT_FOLDED).Value2) = "1")
    If ws.Rows(9).Hidden <> (CellText(ws.Range(CELL_BALANCE_FOLDED).Value2) = "1") Then ws.Rows("9:11").Hidden = (CellText(ws.Range(CELL_BALANCE_FOLDED).Value2) = "1")
    RefreshInputHeadings ws
    ProtectInputSheet
    SafeFreezeInput
End Sub

Public Sub ToggleAccountDetails()
    On Error GoTo EH
    AppBegin
    SetInputSections GetSheet(SH_INPUT).Rows(5).Hidden, Not GetSheet(SH_INPUT).Rows(9).Hidden
    AppEnd
    Exit Sub
EH:
    Dim originalErrorText As String
    originalErrorText = Err.Description
    AppEnd
    MsgBox originalErrorText, vbExclamation
End Sub

Public Sub ToggleBalanceDetails()
    On Error GoTo EH
    AppBegin
    SetInputSections Not GetSheet(SH_INPUT).Rows(5).Hidden, GetSheet(SH_INPUT).Rows(9).Hidden
    AppEnd
    Exit Sub
EH:
    Dim originalErrorText As String
    originalErrorText = Err.Description
    AppEnd
    MsgBox originalErrorText, vbExclamation
End Sub

Public Sub PrepareInputSelection(ByVal targetCell As Range)
    Dim r As Long, ws As Worksheet
    Set ws = targetCell.Worksheet
    If ws.Name <> SH_INPUT Then Exit Sub
    r = targetCell.Row
    If r >= TX_FIRST_ROW And r <= InputLastTransactionRow() Then
        SetInputSections False, False
    ElseIf r = 5 Or r = 6 Then
        SetInputSections True, Not ws.Rows(9).Hidden
    ElseIf r >= BAL_LABEL_ROW And r <= BAL_DATE_ROW Then
        SetInputSections Not ws.Rows(5).Hidden, True
    End If
End Sub

Public Sub RefreshInputHeadings(ByVal ws As Worksheet)
    Dim caption As String, detail As String
    caption = "�������"
    If ws.Rows(5).Hidden Then
        detail = CellText(ws.Range(CELL_PERSON).Value2) & "�@" & CellText(ws.Range(CELL_BANK).Value2) & "�@" & CellText(ws.Range(CELL_ACCOUNT_NO).Value2)
        caption = caption & "�@" & Left$(Trim$(detail), 38) & "�@�{"
    Else
        caption = caption & "�@�|"
    End If
    SetInputHeading ws, "account_toggle", "B4:H4", caption, "ToggleAccountDetails"
    SetInputHeading ws, "branch_plus", "I4:J4", "�}�ԁ{1", "IncrementAccountBranchNo"
    SetInputHeading ws, "input_actions", "K4", "���͑��� ��", "ShowInputActions"
    caption = "�c������" & IIf(ws.Rows(9).Hidden, "�@�{", "�@�|")
    SetInputHeading ws, "balance_toggle", "B8:H8", caption, "ToggleBalanceDetails"
    UpdateInputStateLabel
End Sub

Private Sub SetInputHeading(ByVal ws As Worksheet, ByVal key As String, ByVal addressText As String, ByVal caption As String, ByVal action As String)
    Dim box As Range
    Set box = ws.Range(addressText)
    PutToolButton ws, key, box.Left, box.Top, box.Width, box.Height, caption, action, "soft"
End Sub

Public Sub UpdateInputStateLabel()
    Dim ws As Worksheet, caption As String, button As Shape
    Set ws = GetSheet(SH_INPUT)
    caption = IIf(Len(CurrentEditAccountID()) > 0, "������", "�V��������")
    If InputIsDirty Then
        caption = caption & "�@�E�@�����f"
    ElseIf Len(CurrentEditAccountID()) > 0 Then
        caption = caption & "�@�E�@���f�ς�"
    End If
    If CellText(ws.Range("B7").Value2) = caption Then Exit Sub
    ws.Range("B7").Value2 = caption
    With ws.Range("B7:K7")
        .Interior.Color = IIf(InputIsDirty, RGB(255, 247, 224), RGB(248, 250, 252))
        .Font.Color = IIf(InputIsDirty, RGB(120, 73, 0), RGB(51, 65, 85))
        .Font.Size = 10: .Font.Bold = True
    End With
    On Error Resume Next
    Set button = ws.Shapes(UI_PREFIX & "main_0")
    On Error GoTo 0
    If Not button Is Nothing Then UpdateInputActionButtons ws
End Sub

Attribute VB_Name = "modSettings"
Option Explicit

Private mApplying As Boolean
Private Const CELL_SETTINGS_PENDING As String = "X1"
Private Const CELL_SETTINGS_READY As String = "X2"

Public Function ConfigValueCell(ByVal key As Long) As Range
    Dim address As String
    Select Case key
        Case ROW_CFG_INHERITANCE_DATE: address = "C6"
        Case ROW_CFG_BAL_START_YEAR: address = "C7"
        Case ROW_CFG_BAL_END_YEAR: address = "C8"
        Case ROW_CFG_YEAR_ADD: address = "C10"
        Case ROW_CFG_INPUT_MODE: address = "C11"
        Case ROW_CFG_POST_KEEP: address = "C15"
        Case ROW_CFG_POST_TX: address = "C16"
        Case ROW_CFG_POST_BAL: address = "C17"
        Case ROW_CFG_YEAR_MODE: address = "C9"
        Case ROW_CFG_RELATIONSHIP: address = "C12"
        Case ROW_CFG_SHOW_INHERITANCE_ROW: address = "C20"
        Case ROW_CFG_SHOW_OPEN_DATE_ROW: address = "C21"
        Case ROW_CFG_SHOW_CLOSE_DATE_ROW: address = "C22"
        Case ROW_CFG_SHOW_BALANCE_ROWS: address = "C23"
        Case Else: Err.Raise vbObjectError + 3001, "ConfigValueCell", "�ݒ荀�ڂ�������܂���B"
    End Select
    Set ConfigValueCell = GetSheet(SH_CONFIG).Range(address)
End Function

Public Function ReadConfigValues() As Variant
    Dim values(1 To 14, 1 To 1) As Variant, key As Long
    For key = 4 To 17: values(key - 3, 1) = ConfigValueCell(key).Value2: Next key
    ReadConfigValues = values
End Function

Public Sub WriteConfigValues(ByVal values As Variant)
    Dim key As Long
    For key = 4 To 17: ConfigValueCell(key).Value2 = values(key - 3, 1): Next key
End Sub

Public Function ReadEffectiveConfigValue(ByVal key As Long) As Variant
    Dim ws As Worksheet
    Set ws = GetSheet(SH_CONFIG)
    If mApplying Or CellText(ws.Range(CELL_SETTINGS_READY).Value2) <> "1" Then
        ReadEffectiveConfigValue = ConfigValueCell(key).Value
    Else
        ReadEffectiveConfigValue = ws.Cells(key, 24).Value
    End If
End Function

Public Function EffectiveEraCell(ByVal rowNo As Long, ByVal colNo As Long) As Range
    Dim ws As Worksheet
    Set ws = GetSheet(SH_CONFIG)
    If mApplying Or CellText(ws.Range(CELL_SETTINGS_READY).Value2) <> "1" Then
        Set EffectiveEraCell = ws.Cells(rowNo, colNo)
    Else
        Set EffectiveEraCell = ws.Cells(rowNo, colNo + 22)
    End If
End Function

Public Sub CommitSettingsSnapshot()
    Dim ws As Worksheet
    Set ws = GetSheet(SH_CONFIG)
    ws.Range("X4:X17").Value2 = ReadConfigValues()
    ws.Range("X4").NumberFormat = "yyyy/m/d"
    ws.Range("X27:AC36").Value2 = ws.Range("B27:G36").Value2
    ws.Range("AA27:AB36").NumberFormat = "yyyy/m/d"
    ws.Range(CELL_SETTINGS_READY).Value2 = "1"
    ws.Range(CELL_SETTINGS_PENDING).Value2 = "0"
End Sub

Public Sub EnsureSettingsState()
    If CellText(GetSheet(SH_CONFIG).Range(CELL_SETTINGS_READY).Value2) <> "1" Then CommitSettingsSnapshot
End Sub

Public Sub OnConfigInputChange(ByVal Target As Range)
    Dim key As Long, relevant As Boolean, ws As Worksheet
    Set ws = GetSheet(SH_CONFIG)
    For key = 4 To 17
        If Not Intersect(Target, ConfigValueCell(key)) Is Nothing Then relevant = True: Exit For
    Next key
    If Not Intersect(Target, ws.Range("B27:G36")) Is Nothing Then relevant = True
    If Not relevant Then Exit Sub
    ws.Range(CELL_SETTINGS_PENDING).Value2 = "1"
    If Not Intersect(Target, ConfigValueCell(ROW_CFG_YEAR_MODE)) Is Nothing Then LayoutConfigSections
End Sub

Public Function ApplyPendingSettings() As Boolean
    Dim ws As Worksheet, oldValues As Variant, newValues As Variant, oldEra As Variant, newEra As Variant
    Dim changed As Boolean, balanceChanged As Boolean, relationshipChanged As Boolean, outputChanged As Boolean
    Dim key As Long, r As Long, c As Long, labels As Collection, dates As Collection
    Dim state As Collection, began As Boolean, message As String, restoreMessage As String
    If mApplying Then ApplyPendingSettings = True: Exit Function
    If Not SheetExists(SH_CONFIG) Then ApplyPendingSettings = True: Exit Function
    On Error GoTo EH
    Set ws = GetSheet(SH_CONFIG)
    EnsureSettingsState
    If CellText(ws.Range(CELL_SETTINGS_PENDING).Value2) <> "1" Then ApplyPendingSettings = True: Exit Function
    On Error GoTo EH
    oldValues = ws.Range("X4:X17").Value2: newValues = ReadConfigValues()
    oldEra = ws.Range("X27:AC36").Value2: newEra = ws.Range("B27:G36").Value2
    For key = 4 To 17
        If CellText(oldValues(key - 3, 1)) <> CellText(newValues(key - 3, 1)) Then
            changed = True
            If key >= 4 And key <= 6 Then balanceChanged = True
            If key = ROW_CFG_RELATIONSHIP Then relationshipChanged = True
            If (key >= 4 And key <= 6) Or key >= ROW_CFG_RELATIONSHIP Then outputChanged = True
        End If
    Next key
    For r = 1 To 10
        For c = 1 To 6
            If CellText(oldEra(r, c)) <> CellText(newEra(r, c)) Then changed = True
        Next c
    Next r
    If Not changed Then
        ws.Range(CELL_SETTINGS_PENDING).Value2 = "0"
        ApplyPendingSettings = True
        Exit Function
    End If
    mApplying = True
    '���̐ݒ�����؂��Ă���\����ς���B���i�̓ǎ��͓K�p�ςݒl���g���B
    If balanceChanged Then BuildBalanceCollections labels, dates
    AppBegin "�ݒ�𔽉f���Ă��܂�...": began = True
    If balanceChanged Or relationshipChanged Then Set state = CaptureInputState()
    If balanceChanged Then RebuildBalanceDraft
    If relationshipChanged Then
        GetSheet(SH_INPUT).Unprotect Password:=TOOL_PASSWORD
        ApplyRelationshipInput GetSheet(SH_INPUT)
        ProtectInputSheet
    End If
    ResetInputNavigation
    If outputChanged Then InvalidateOutputViews
    UpdateInputActionButtons GetSheet(SH_INPUT)
    CommitSettingsSnapshot
    mApplying = False
    AppEnd
    ApplyPendingSettings = True
    Exit Function
EH:
    message = Err.Description
    mApplying = False
    On Error Resume Next
    If IsArray(oldValues) Then ws.Range("X4:X17").Value2 = oldValues
    If IsArray(oldEra) Then ws.Range("X27:AC36").Value2 = oldEra
    ws.Range(CELL_SETTINGS_PENDING).Value2 = "1"
    If Not state Is Nothing Then
        Err.Clear
        RestoreInputState state
        If Err.Number <> 0 Then restoreMessage = vbCrLf & "���͉�ʂ�߂��܂���ł����B���͓��e��ۑ����Ă���A�J�������Ă��������B"
    End If
    If began Then AppEnd
    On Error GoTo 0
    MsgBox "�ݒ�𔽉f�ł��܂���ł����B�ݒ�l���m�F���Ă��������B" & vbCrLf & message & restoreMessage, vbExclamation
End Function

Public Sub CreateConfigSheet()
    Dim ws As Worksheet, key As Long
    Set ws = GetSheet(SH_CONFIG)
    ws.Unprotect Password:=TOOL_PASSWORD
    ConfigValueCell(ROW_CFG_INHERITANCE_DATE).ClearContents
    ConfigValueCell(ROW_CFG_BAL_START_YEAR).Value2 = Year(Date) - 4
    ConfigValueCell(ROW_CFG_BAL_END_YEAR).Value2 = Year(Date)
    ConfigValueCell(ROW_CFG_YEAR_ADD).Value2 = 2000
    ConfigValueCell(ROW_CFG_INPUT_MODE).Value2 = MODE_NORMAL
    ConfigValueCell(ROW_CFG_POST_KEEP).Value2 = KEEP_BANK_BRANCH_PERSON_TYPE
    ConfigValueCell(ROW_CFG_POST_TX).Value2 = POST_CLEAR
    ConfigValueCell(ROW_CFG_POST_BAL).Value2 = POST_CLEAR
    ConfigValueCell(ROW_CFG_YEAR_MODE).Value2 = YEAR_MODE_WAREKI
    For key = ROW_CFG_RELATIONSHIP To ROW_CFG_SHOW_BALANCE_ROWS: ConfigValueCell(key).Value2 = DISPLAY_ON: Next key
    SetRowValues ws.Range("B27"), Array(1, "���a", "S", DateSerial(1926, 12, 25), DateSerial(1989, 1, 7), "TRUE")
    SetRowValues ws.Range("B28"), Array(2, "����", "H", DateSerial(1989, 1, 8), DateSerial(2019, 4, 30), "TRUE")
    SetRowValues ws.Range("B29"), Array(3, "�ߘa", "R", DateSerial(2019, 5, 1), "", "TRUE")
    ws.Range("J2").Value2 = "1"
    ws.Range("J3:J5").Value2 = "0"
    FormatConfigSheet False
    CommitSettingsSnapshot
End Sub

Public Sub FormatConfigSheet(Optional ByVal protectAfter As Boolean = True)
    Dim ws As Worksheet, key As Long, labels As Variant, notes As Variant, cell As Range, r As Long
    Set ws = GetSheet(SH_CONFIG)
    ws.Unprotect Password:=TOOL_PASSWORD
    ws.Range("A1:G44").Font.Name = "Yu Gothic UI"
    ws.Range("A1:G44").Font.Size = 10
    ws.Range("A1:G44").Font.Color = RGB(30, 41, 59)
    ws.Range("A1:G44").Interior.Color = vbWhite
    ws.Range("A1:G44").VerticalAlignment = xlCenter
    ws.Columns("A:A").ColumnWidth = 2
    ws.Columns("B:B").ColumnWidth = 24
    ws.Columns("C:C").ColumnWidth = 36
    ws.Columns("D:D").ColumnWidth = 12
    ws.Columns("E:F").ColumnWidth = 14
    ws.Columns("G:G").ColumnWidth = 10
    ws.Columns("H:H").ColumnWidth = 2
    ws.Columns("I:AC").Hidden = True
    ws.Rows("1:44").RowHeight = 24
    For Each cell In ws.Range("A1,A4,A13,A18,A24,A38,A40,A42,A44"): cell.EntireRow.RowHeight = 4: Next cell
    ws.Rows(2).RowHeight = 28: ws.Rows(3).RowHeight = 34
    ws.Rows("15:17").RowHeight = 28
    ws.Rows(37).RowHeight = 24
    ws.Rows(41).RowHeight = 32: ws.Rows(43).RowHeight = 32
    MergeAndFormat ws.Range("B2:G2"), "�ݒ�"
    ws.Range("B2").Font.Size = 16: ws.Range("B2").Font.Bold = True
    ws.Range("B2").HorizontalAlignment = xlLeft
    labels = Array("�����J�n��", "�c���\���J�n�N", "�c���\���I���N", "����2���̉��Z�l", "���̓��[�h", _
        "�����p���������", "���̌����̖���", "���̌����̎c��", "�N�̓��͕���", "�����̓��́E�\��", _
        "�����J�n���s", "�����J�ݓ��s", "���������s", "�c���s")
    notes = Array("�󗓂ł��g���܂��B", "�N���c���̕\�����Ԃł��B", "�N���c���̕\�����Ԃł��B", "��F26��2026�N�Ƃ���ꍇ��2000�B", _
        "Tab�Œʂ閾�ׂ̍��ڂ�I�т܂��B", "�V�K�����̓]�L��Ɉ����p���܂��B", "�ʏ�̓N���A�B�c���ꍇ�͉������ɂȂ�܂��B", _
        "�S�y�[�W�ƃ������Ώۂł��B", "���͍ς݂̔N���͕ێ����A�V������������K�p���܂��B", "���͗��ƒ��[�ɔ��f���܂��B", _
        "��������\�֕\�����܂��B", "��������\�֕\�����܂��B", "��������\�֕\�����܂��B", "��������\�֕\�����܂��B")
    For key = 4 To 17
        r = ConfigValueCell(key).Row
        ws.Cells(r, 2).Value2 = labels(key - 4)
        ws.Cells(r, 2).Font.Bold = True
        MergeAndFormat ws.Range(ws.Cells(r, 4), ws.Cells(r, 7)), CStr(notes(key - 4))
        ws.Cells(r, 4).Font.Size = 9: ws.Cells(r, 4).Font.Color = RGB(71, 85, 105)
        ws.Cells(r, 4).HorizontalAlignment = xlLeft: ws.Cells(r, 4).WrapText = True
        With ConfigValueCell(key)
            .Interior.Color = RGB(248, 250, 252)
            .Borders.LineStyle = xlContinuous: .Borders.Color = RGB(203, 213, 225)
            .HorizontalAlignment = xlLeft
            .WrapText = True
            .NumberFormat = "@"
        End With
    Next key
    ConfigValueCell(ROW_CFG_INHERITANCE_DATE).NumberFormat = "yyyy/m/d"
    For key = ROW_CFG_BAL_START_YEAR To ROW_CFG_YEAR_ADD: ConfigValueCell(key).NumberFormat = "0": Next key
    MergeAndFormat ws.Range("B5:G5"), "��{�ݒ�"
    ws.Range("B5:G5").Interior.Color = RGB(239, 246, 255): ws.Range("B5").Font.Bold = True
    SetRowValues ws.Range("B26"), Array("�����R�[�h", "������", "����", "�J�n��", "�I����", "�L��")
    FormatOutputHeader ws.Range("B26:G26")
    ws.Range("B27:G36").Borders.LineStyle = xlContinuous
    ws.Range("B27:G36").Borders.Color = RGB(226, 232, 240)
    ws.Range("E27:F36").NumberFormat = "yyyy/m/d"
    MergeAndFormat ws.Range("B37:G37"), "�J�ݓ��E�����F1.53.5.6�����a53�N5��6���A3.1.5.1���ߘa���N5��1���B"
    ws.Range("B37").HorizontalAlignment = xlLeft: ws.Range("B37").Font.Size = 9
    LayoutConfigSections False
    ws.ScrollArea = "A1:G44"
    If protectAfter Then ProtectConfigSheet
End Sub

Public Sub LayoutConfigSections(Optional ByVal protectAfter As Boolean = True)
    Dim ws As Worksheet, x As Double, y As Double, w As Double
    Dim carry As Boolean, showOutputs As Boolean, era As Boolean, other As Boolean
    Set ws = GetSheet(SH_CONFIG)
    ws.Unprotect Password:=TOOL_PASSWORD
    carry = (CellText(ws.Range("J2").Value2) = "1")
    showOutputs = (CellText(ws.Range("J3").Value2) = "1")
    era = (CellText(ws.Range("J4").Value2) = "1")
    other = (CellText(ws.Range("J5").Value2) = "1")
    ws.Rows(10).Hidden = (CellText(ConfigValueCell(ROW_CFG_YEAR_MODE).Value2) <> YEAR_MODE_WESTERN2)
    ws.Rows("15:17").Hidden = Not carry
    ws.Rows("20:23").Hidden = Not showOutputs
    ws.Rows("26:37").Hidden = Not era
    ws.Rows("40:44").Hidden = Not other
    x = ws.Range("B3").Left: y = ws.Range("B3").Top + 2: w = ws.Range("B3:G3").Width
    PutToolButton ws, "cfg_apply", x, y, 160, 29, "�ݒ�𔽉f���Ė߂�", "ApplySettingsAndReturn", "primary"
    PutToolButton ws, "cfg_candidates", x + 172, y, 128, 29, "����ҏW ��", "ShowCandidateMenu", "tool"
    PutToolButton ws, "cfg_shop", x + w - 140, y, 140, 29, "�戵�X�������", "OpenShopNames", "tool"
    PutConfigHeading ws, 14, "�]�L��̈��p��", carry, "ToggleConfigCarry"
    PutConfigHeading ws, 19, "���[�̕\������", showOutputs, "ToggleConfigOutput"
    PutConfigHeading ws, 25, "�����̐ݒ�", era, "ToggleConfigEra"
    PutConfigHeading ws, 39, "���̑��̑���", other, "ToggleConfigOther"
    If other Then
        y = ws.Range("B41").Top
        PutToolButton ws, "cfg_import", x, y, 160, 29, "���`���f�[�^�̎捞", "ImportExistingToolData", "tool"
        PutToolButton ws, "cfg_restore", x + 172, y, 160, 29, "���͉�ʁETab����", "RestoreToolFormatting", "tool"
        PutToolButton ws, "cfg_clear", x, ws.Range("B43").Top, 160, 29, "�Č��f�[�^������", "InitializeToolData", "danger"
    End If
    SetConfigButtonVisible ws, "cfg_import", other
    SetConfigButtonVisible ws, "cfg_restore", other
    SetConfigButtonVisible ws, "cfg_clear", other
    If protectAfter Then ProtectConfigSheet
End Sub

Private Sub PutConfigHeading(ByVal ws As Worksheet, ByVal rowNo As Long, ByVal caption As String, ByVal expanded As Boolean, ByVal action As String)
    Dim box As Range
    Set box = ws.Range(ws.Cells(rowNo, 2), ws.Cells(rowNo, 7))
    PutToolButton ws, "cfg_heading_" & rowNo, box.Left, box.Top, box.Width, box.Height, _
        caption & IIf(expanded, "�@�|", "�@�{"), action, "soft"
End Sub

Private Sub SetConfigButtonVisible(ByVal ws As Worksheet, ByVal key As String, ByVal visible As Boolean)
    Dim shp As Shape
    On Error Resume Next
    Set shp = ws.Shapes(UI_PREFIX & key)
    On Error GoTo 0
    If Not shp Is Nothing Then shp.Visible = visible
End Sub

Private Sub ToggleConfigSection(ByVal address As String)
    Dim ws As Worksheet, message As String
    On Error GoTo EH
    Set ws = GetSheet(SH_CONFIG)
    AppBegin
    ws.Range(address).Value2 = IIf(CellText(ws.Range(address).Value2) = "1", "0", "1")
    LayoutConfigSections
    AppEnd
    Exit Sub
EH:
    message = Err.Description
    AppEnd
    MsgBox "�ݒ藓��؂�ւ����܂���ł����B" & vbCrLf & message, vbExclamation
End Sub

Public Sub ToggleConfigCarry()
    ToggleConfigSection "J2"
End Sub
Public Sub ToggleConfigOutput()
    ToggleConfigSection "J3"
End Sub
Public Sub ToggleConfigEra()
    ToggleConfigSection "J4"
End Sub
Public Sub ToggleConfigOther()
    ToggleConfigSection "J5"
End Sub

Public Sub ProtectConfigSheet()
    Dim ws As Worksheet, key As Long
    Set ws = GetSheet(SH_CONFIG)
    ws.Unprotect Password:=TOOL_PASSWORD
    ws.Range("A1:AC53").Locked = True
    For key = 4 To 17: ConfigValueCell(key).Locked = False: Next key
    ws.Range("B27:G36").Locked = False
    ws.Protect Password:=TOOL_PASSWORD, UserInterfaceOnly:=True, DrawingObjects:=True
    ws.EnableSelection = xlUnlockedCells
End Sub

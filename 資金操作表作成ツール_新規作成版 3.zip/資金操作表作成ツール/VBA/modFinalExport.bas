Attribute VB_Name = "modFinalExport"
Option Explicit

Public Sub ExportFinalWorkbooks()
    Dim folder As String, stage As String, names As Variant, paths(0 To 1) As String, backups(0 To 1) As String
    Dim installed(0 To 1) As Boolean, moved(0 To 1) As Boolean, i As Long
    Dim fd As FileDialog, fs As Object, message As String, restoreMessage As String
    If Not RequireToolReady() Then Exit Sub
    If Not RequirePostedInput() Then Exit Sub
    On Error GoTo EH
    EnsureAccountStore
    If LastRow(GetSheet(SH_ACCOUNTS)) < 2 Then MsgBox "�o�͂���������o�^����Ă��܂���B", vbInformation: Exit Sub
    Set fd = Application.FileDialog(msoFileDialogFolderPicker)
    fd.Title = "Excel�t�@�C���̕ۑ���"
    If fd.Show <> -1 Then Exit Sub
    folder = fd.SelectedItems(1)
    Set fs = CreateObject("Scripting.FileSystemObject")
    names = Array("01_��������\.xlsx", "02_�c�����ڕ\.xlsx")
    For i = 0 To 1
        paths(i) = fs.BuildPath(folder, CStr(names(i)))
        If fs.FileExists(paths(i)) Then message = message & CStr(names(i)) & vbCrLf
    Next i
    If Len(message) > 0 Then
        If MsgBox("�����̃t�@�C�����㏑�����܂����H" & vbCrLf & message, vbYesNo + vbQuestion + vbDefaultButton2) <> vbYes Then Exit Sub
    End If
    AppBegin "Excel�t�@�C�����쐬���Ă��܂�..."
    EnsureCurrentOutputs
    stage = fs.BuildPath(folder, fs.GetTempName)
    fs.CreateFolder stage
    ExportOneSheetAsXlsx GetSheet(SH_OUTPUT_TX), "��������\", fs.BuildPath(stage, CStr(names(0)))
    ExportOneSheetAsXlsx GetSheet(SH_OUTPUT_BAL), "�c�����ڕ\", fs.BuildPath(stage, CStr(names(1)))
    '2�t�@�C���Ƃ��ۑ����I���Ă�������t�@�C�������ւ���B
    For i = 0 To 1
        backups(i) = fs.BuildPath(stage, CStr(i) & ".bak")
        If fs.FileExists(paths(i)) Then
            fs.MoveFile paths(i), backups(i): moved(i) = True
        End If
        fs.MoveFile fs.BuildPath(stage, CStr(names(i))), paths(i): installed(i) = True
    Next i
    On Error Resume Next
    fs.DeleteFolder stage, True
    On Error GoTo 0
    AppEnd
    ShowInputSheet
    SetInputStatus "Excel�o�͂��������܂����B�@" & folder
    Exit Sub
EH:
    message = Err.Description
    On Error Resume Next
    If Not fs Is Nothing Then
        For i = 1 To 0 Step -1
            Err.Clear
            If installed(i) Then fs.DeleteFile paths(i), True
            If Err.Number <> 0 Then restoreMessage = restoreMessage & CStr(names(i)) & "�i�V�K�t�@�C���̏����j "
            Err.Clear
            If moved(i) Then fs.MoveFile backups(i), paths(i)
            If Err.Number <> 0 Then restoreMessage = restoreMessage & CStr(names(i)) & "�i���t�@�C���̕����j "
        Next i
        If Len(stage) > 0 And Len(restoreMessage) = 0 Then fs.DeleteFolder stage, True
    End If
    AppEnd
    On Error GoTo 0
    If Len(restoreMessage) > 0 Then
        message = message & vbCrLf & "�����ł��Ȃ������t�@�C���F" & restoreMessage & vbCrLf & "���t�@�C���̑ޔ��F" & stage
    End If
    MsgBox "Excel�o�͂������ł��܂���ł����B" & vbCrLf & message, vbExclamation
End Sub

Private Sub ExportOneSheetAsXlsx(ByVal src As Worksheet, ByVal sheetName As String, ByVal savePath As String)
    Dim wb As Workbook, ws As Worksheet, e As Long, message As String
    On Error GoTo EH
    src.Copy
    Set wb = ActiveWorkbook: Set ws = wb.Worksheets(1)
    ws.Name = sheetName
    ws.Unprotect Password:=TOOL_PASSWORD
    DeleteToolShapes ws, True
    If src.Name = SH_OUTPUT_TX Then
        If ShiftReportHeader(ws) = 4 Then ws.Rows("1:3").Delete
        ws.Columns("R:R").ClearContents
        ws.PageSetup.PrintTitleRows = "$1:$1"
        ws.PageSetup.PrintArea = ws.Range("A1:M" & Application.Max(1, LastUsedRowInSheet(ws))).Address
        ActiveWindow.FreezePanes = False
        ActiveWindow.SplitColumn = 0: ActiveWindow.SplitRow = 1
        ActiveWindow.FreezePanes = True
    End If
    ws.Calculate
    ws.Range("A1").Select
    wb.SaveAs Filename:=savePath, FileFormat:=xlOpenXMLWorkbook, CreateBackup:=False
    wb.Close SaveChanges:=False
    Exit Sub
EH:
    e = Err.Number: message = Err.Description
    On Error Resume Next
    If Not wb Is Nothing Then wb.Close SaveChanges:=False
    On Error GoTo 0
    Err.Raise e, "ExportOneSheetAsXlsx", message
End Sub

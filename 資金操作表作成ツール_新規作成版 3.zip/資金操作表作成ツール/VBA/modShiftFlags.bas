Attribute VB_Name = "modShiftFlags"
Option Explicit

Private mReady As Boolean, mBusy As Boolean
Private mData As Variant, mBuckets As Object, mFlags As Object, mOutputRows As Object
Private mOrder() As Long, mCount As Long, mOrigin As Long, mPosition As Long
Private mAmountOrder() As Long, mGroupKeys() As String
Private mMatches As Collection

Public Sub InvalidateShiftSession()
    mReady = False
End Sub

Public Function ShiftReportHeader(ByVal ws As Worksheet) As Long
    ShiftReportHeader = 1
    If CellText(ws.Range("R1").Value2) = "SHIFT_PANEL" Then ShiftReportHeader = 4
End Function

Public Sub AttachShiftToolbar(ByVal ws As Worksheet)
    Dim captions As Variant, actions As Variant, widths As Variant, i As Long, x As Double, last As Long, scale As Double
    '���[�̖{�������I���Ă���ĂԁB�W�v�p�̒l��13��̕��т͕ύX���Ȃ��B
    ws.Rows("1:3").Insert Shift:=xlDown
    ws.Range("R1").Value2 = "SHIFT_PANEL"
    ws.Range("A1:M3").Clear
    ws.Range("A1:M3").Interior.Color = vbWhite
    ws.Range("A1:M3").Font.Name = "Yu Gothic UI": ws.Range("A1:M3").Font.Size = 11
    ws.Range("A1:M3").Font.Color = RGB(30, 41, 59)
    ws.Range("A2:M2").Merge: ws.Range("A3:M3").Merge
    ws.Range("A2:M3").HorizontalAlignment = xlLeft: ws.Range("A2:M3").VerticalAlignment = xlCenter
    ws.Range("A2:M3").WrapText = True
    ws.Rows(1).RowHeight = 34: ws.Rows(2).RowHeight = 22: ws.Rows(3).RowHeight = 38
    ws.Range("A2").Value2 = "�����V�t�g���F��������ƁA�Ή�����o���E�����Ɂ���\�����܂��B"
    ws.Range("A3").Value2 = "���z���_�u���N���b�N����ƁA����̊m�F�ƌ��̃I���E�I�t���ł��܂��B"
    captions = Array("��������", "�O�̌��", "���̌��", "��₩��O��", "�o����", "������", "�덷5%�ȓ�", "���t�� 3��", "���͂�")
    actions = Array("SearchShiftFlags", "PreviousShiftCandidate", "NextShiftCandidate", "ToggleShiftExclusion", "GoShiftWithdrawal", "GoShiftDeposit", "ToggleShiftTolerance", "ChooseShiftDays", "GoInputSheet")
    widths = Array(78, 65, 65, 105, 58, 58, 102, 84, 62)
    captions(6) = IIf(ShiftAllowDifference(), "�덷5%�ȓ�", "���S��v")
    captions(7) = "���t�� " & ShiftDays() & "��"
    scale = (ws.Range("A1:M1").Width - 48) / 677
    x = ws.Range("A1").Left
    For i = 0 To 8
        PutToolButton ws, "shift_" & i, x, ws.Range("A1").Top + 3, CDbl(widths(i)) * scale, 28, CStr(captions(i)), CStr(actions(i)), "tool"
        x = x + CDbl(widths(i)) * scale + 6
    Next i
    ws.Columns("R:R").Hidden = True
    last = Application.Max(4, LastUsedRowInSheet(ws))
    ws.PageSetup.PrintArea = ws.Range("A4:M" & last).Address
    ws.PageSetup.PrintTitleRows = "$4:$4"
    ws.PageSetup.RightFooter = "�� �����V�t�g���"
End Sub

Public Function ShiftTimeKnown(ByVal value As Variant) As Boolean
    If IsError(value) Or IsNull(value) Or IsEmpty(value) Then Exit Function
    If Not HasText(value) Or Not IsNumeric(value) Then Exit Function
    ShiftTimeKnown = CDbl(value) >= 0 And CDbl(value) < 1
End Function

Public Function ShiftChronology(ByVal outDay As Double, ByVal outTime As Variant, ByVal inDay As Double, ByVal inTime As Variant, ByVal days As Long) As Long
    Dim difference As Double, outMinute As Long, inMinute As Long
    ShiftChronology = -1
    difference = Int(inDay) - Int(outDay)
    If difference < 0 Or difference > days Then Exit Function
    If difference > 0 Then ShiftChronology = 1: Exit Function
    ShiftChronology = 0
    If Not ShiftTimeKnown(outTime) Or Not ShiftTimeKnown(inTime) Then Exit Function
    outMinute = Fix(CDbl(outTime) * 1440# + 0.0000001)
    inMinute = Fix(CDbl(inTime) * 1440# + 0.0000001)
    If outMinute > inMinute Then ShiftChronology = -1
    If outMinute < inMinute Then ShiftChronology = 1
End Function

Private Function RowSide(ByVal row As Long) As String
    Dim w As Double, d As Double
    If IsNumeric(mData(row, 8)) Then w = CDbl(mData(row, 8))
    If IsNumeric(mData(row, 9)) Then d = CDbl(mData(row, 9))
    If w > 0 And d = 0 Then RowSide = "W"
    If d > 0 And w = 0 Then RowSide = "D"
End Function

Private Function RowAmount(ByVal row As Long) As Double
    If RowSide(row) = "W" Then RowAmount = CDbl(mData(row, 8)) Else RowAmount = CDbl(mData(row, 9))
End Function

Private Function BucketKey(ByVal side As String, ByVal day As Long) As String
    BucketKey = side & "|" & CStr(day)
End Function

Public Function ShiftAmountBand(ByVal originAmount As Double, ByVal partnerAmount As Double, ByVal originSide As String, ByVal allowDifference As Boolean) As Long
    '����̋��z���͈͖����Ȃ�-1�A�͈͓��Ȃ�0�A�͈͒��߂Ȃ�1�B
    '��������T���ꍇ���A����͕K���o���z�B���Z�Ƌ��E�̊ۂ߂������B
    If Not allowDifference Then
        If partnerAmount < originAmount Then ShiftAmountBand = -1
        If partnerAmount > originAmount Then ShiftAmountBand = 1
    ElseIf originSide = "W" Then
        If CDec(partnerAmount) * 100 < CDec(originAmount) * 95 Then ShiftAmountBand = -1
        If CDec(partnerAmount) * 100 > CDec(originAmount) * 105 Then ShiftAmountBand = 1
    Else
        If CDec(partnerAmount) * 105 < CDec(originAmount) * 100 Then ShiftAmountBand = -1
        If CDec(partnerAmount) * 95 > CDec(originAmount) * 100 Then ShiftAmountBand = 1
    End If
End Function

Private Function AmountRowComesBefore(ByVal leftRow As Long, ByVal rightRow As Long) As Boolean
    If mGroupKeys(leftRow) <> mGroupKeys(rightRow) Then
        AmountRowComesBefore = mGroupKeys(leftRow) < mGroupKeys(rightRow)
    ElseIf RowAmount(leftRow) <> RowAmount(rightRow) Then
        AmountRowComesBefore = RowAmount(leftRow) < RowAmount(rightRow)
    Else
        AmountRowComesBefore = RowComesBefore(leftRow, rightRow)
    End If
End Function

Private Sub SortShiftAmountRows(ByVal lo As Long, ByVal hi As Long)
    Dim i As Long, j As Long, pivot As Long, swap As Long
    i = lo: j = hi: pivot = mAmountOrder((lo + hi) \ 2)
    Do While i <= j
        Do While AmountRowComesBefore(mAmountOrder(i), pivot): i = i + 1: Loop
        Do While AmountRowComesBefore(pivot, mAmountOrder(j)): j = j - 1: Loop
        If i <= j Then
            swap = mAmountOrder(i): mAmountOrder(i) = mAmountOrder(j): mAmountOrder(j) = swap
            i = i + 1: j = j - 1
        End If
    Loop
    If lo < j Then SortShiftAmountRows lo, j
    If i < hi Then SortShiftAmountRows i, hi
End Sub

Private Function FirstShiftAmountIndex(ByVal origin As Long, ByVal first As Long, ByVal last As Long, ByVal allowDifference As Boolean) As Long
    Dim lo As Long, hi As Long, middle As Long
    lo = first: hi = last + 1
    Do While lo < hi
        middle = (lo + hi) \ 2
        If ShiftAmountBand(RowAmount(origin), RowAmount(mAmountOrder(middle)), RowSide(origin), allowDifference) < 0 Then
            lo = middle + 1
        Else
            hi = middle
        End If
    Loop
    FirstShiftAmountIndex = lo
End Function

Private Function RowComesBefore(ByVal leftRow As Long, ByVal rightRow As Long) As Boolean
    Dim leftTime As Double, rightTime As Double
    If CDbl(mData(leftRow, 6)) <> CDbl(mData(rightRow, 6)) Then
        RowComesBefore = CDbl(mData(leftRow, 6)) < CDbl(mData(rightRow, 6)): Exit Function
    End If
    leftTime = 2: rightTime = 2
    If ShiftTimeKnown(mData(leftRow, 7)) Then leftTime = CDbl(mData(leftRow, 7))
    If ShiftTimeKnown(mData(rightRow, 7)) Then rightTime = CDbl(mData(rightRow, 7))
    If leftTime <> rightTime Then RowComesBefore = leftTime < rightTime Else RowComesBefore = leftRow < rightRow
End Function

Private Sub SortShiftRows(ByRef order() As Long, ByVal lo As Long, ByVal hi As Long)
    Dim i As Long, j As Long, pivot As Long, swap As Long
    i = lo: j = hi: pivot = order((lo + hi) \ 2)
    Do While i <= j
        Do While RowComesBefore(order(i), pivot): i = i + 1: Loop
        Do While RowComesBefore(pivot, order(j)): j = j - 1: Loop
        If i <= j Then
            swap = order(i): order(i) = order(j): order(j) = swap
            i = i + 1: j = j - 1
        End If
    Loop
    If lo < j Then SortShiftRows order, lo, j
    If i < hi Then SortShiftRows order, i, hi
End Sub

Private Sub BuildShiftIndex()
    Dim r As Long, i As Long, side As String, key As String, bounds As Variant, accounts As Object, account As String
    Set mBuckets = CreateObject("Scripting.Dictionary")
    mData = ShiftRows(): mCount = 0
    ReDim mOrder(1 To Application.Max(1, UBound(mData, 1) - 1))
    ReDim mAmountOrder(1 To UBound(mOrder)): ReDim mGroupKeys(1 To UBound(mData, 1))
    For r = 2 To UBound(mData, 1)
        If CellText(mData(r, 16)) = "���" And Len(ShiftRowID(r)) > 0 Then
            If IsNumeric(mData(r, 6)) And HasText(mData(r, 6)) Then
                If CDbl(mData(r, 6)) > 0 And CDbl(mData(r, 6)) < 2958466# Then
                    If Len(RowSide(r)) > 0 Then mCount = mCount + 1: mOrder(mCount) = r
                End If
            End If
        End If
    Next r
    If mCount > 1 Then SortShiftRows mOrder, 1, mCount
    For i = 1 To mCount
        r = mOrder(i): side = RowSide(r)
        mAmountOrder(i) = r
        mGroupKeys(r) = BucketKey(side, CLng(Int(CDbl(mData(r, 6))))) & "|" & CellText(mData(r, 15))
    Next i
    If mCount > 1 Then SortShiftAmountRows 1, mCount
    For i = 1 To mCount
        r = mAmountOrder(i): side = RowSide(r)
        key = BucketKey(side, CLng(Int(CDbl(mData(r, 6)))))
        If Not mBuckets.Exists(key) Then
            Set accounts = CreateObject("Scripting.Dictionary"): mBuckets.Add key, accounts
        End If
        Set accounts = mBuckets(key): account = CellText(mData(r, 15))
        If Not accounts.Exists(account) Then
            accounts.Add account, Array(i, i)
        Else
            bounds = accounts(account): bounds(1) = i: accounts(account) = bounds
        End If
    Next i
End Sub

Private Function FindShiftPartners(ByVal origin As Long, Optional ByVal firstOnly As Boolean = False, Optional ByVal includeExcluded As Boolean = False) As Collection
    Dim result As New Collection, side As String, opposite As String, fromDay As Long, toDay As Long, day As Long
    Dim key As String, bounds As Variant, row As Long, w As Long, d As Long, chronology As Long, index As Long, allowDifference As Boolean
    Dim accounts As Object, account As Variant, ordered() As Long, i As Long, sorted As New Collection
    Set FindShiftPartners = result
    side = RowSide(origin)
    If Len(side) = 0 Or Not HasText(mData(origin, 6)) Or Not IsNumeric(mData(origin, 6)) Then Exit Function
    opposite = IIf(side = "W", "D", "W")
    allowDifference = ShiftAllowDifference()
    fromDay = CLng(Int(CDbl(mData(origin, 6)))): toDay = fromDay
    If side = "W" Then toDay = toDay + ShiftDays() Else fromDay = fromDay - ShiftDays()
    For day = fromDay To toDay
        key = BucketKey(opposite, day)
        If mBuckets.Exists(key) Then
            Set accounts = mBuckets(key)
            For Each account In accounts.Keys
                If CellText(mData(origin, 15)) <> CStr(account) Then
                    bounds = accounts(account)
                    index = FirstShiftAmountIndex(origin, CLng(bounds(0)), CLng(bounds(1)), allowDifference)
                    Do While index <= CLng(bounds(1))
                    row = mAmountOrder(index)
                    If ShiftAmountBand(RowAmount(origin), RowAmount(row), side, allowDifference) > 0 Then Exit Do
                    If side = "W" Then w = origin: d = row Else w = row: d = origin
                    If includeExcluded Or Not ShiftPairExcluded(w, d) Then
                        chronology = ShiftChronology(CDbl(mData(w, 6)), mData(w, 7), CDbl(mData(d, 6)), mData(d, 7), ShiftDays())
                        If chronology >= 0 Then
                            result.Add CLng(row)
                            If firstOnly Then Set FindShiftPartners = result: Exit Function
                        End If
                    End If
                    index = index + 1
                    Loop
                End If
            Next account
        End If
    Next day
    If result.Count < 2 Then Set FindShiftPartners = result: Exit Function
    ReDim ordered(1 To result.Count)
    For i = 1 To result.Count: ordered(i) = CLng(result(i)): Next i
    SortShiftRows ordered, 1, result.Count
    For i = 1 To result.Count: sorted.Add ordered(i): Next i
    Set FindShiftPartners = sorted
End Function

Public Sub SearchShiftFlags()
    Dim started As Boolean, previousCancel As Long, cancelChanged As Boolean, ws As Worksheet
    Dim i As Long, row As Long, matches As Collection, message As String, pointers As Variant
    Dim originID As String, partnerID As String, selected As Long, partner As Long
    If mBusy Then Exit Sub
    If Not RequireToolReady() Then Exit Sub
    On Error GoTo EH
    If mReady And mOrigin > 0 Then
        originID = ShiftRowID(mOrigin)
        If mPosition >= 1 And mPosition <= mMatches.Count Then partnerID = ShiftRowID(CLng(mMatches(mPosition)))
    End If
    mBusy = True: mReady = False
    AppBegin "�����V�t�g�̌���T���Ă��܂�...": started = True
    EnsureCurrentOutputs
    Set ws = GetSheet(SH_OUTPUT_TX): ws.Activate
    previousCancel = Application.EnableCancelKey: cancelChanged = True
    Application.EnableCancelKey = xlErrorHandler
    LoadShiftData
    BuildShiftIndex
    Set mOutputRows = CreateObject("Scripting.Dictionary")
    pointers = ws.Range("R5:R" & Application.Max(6, LastUsedRowInSheet(ws))).Value2
    For i = 1 To UBound(pointers, 1)
        If IsNumeric(pointers(i, 1)) And HasText(pointers(i, 1)) Then
            row = CLng(pointers(i, 1))
            If row >= 2 And row <= UBound(mData, 1) Then
                If CellText(mData(row, 16)) = "���" Then mOutputRows(CStr(row)) = i + 4
            End If
        End If
    Next i
    Set mFlags = CreateObject("Scripting.Dictionary")
    mOrigin = 0: mPosition = 0: Set mMatches = New Collection
    For i = 1 To mCount
        row = mOrder(i): Set matches = FindShiftPartners(row, True)
        If matches.Count > 0 Then
            mFlags(CStr(row)) = True
            If mOrigin = 0 And RowSide(row) = "W" Then mOrigin = row
        End If
    Next i
    PaintShiftFlags ws
    selected = ShiftRowFromID(originID): partner = ShiftRowFromID(partnerID)
    If selected > 0 Then
        Set matches = FindShiftPartners(selected, False, True)
        If matches.Count > 0 Then mOrigin = selected
    End If
    If mOrigin > 0 Then
        Set mMatches = FindShiftPartners(mOrigin, False, True): mPosition = 1
        For i = 1 To mMatches.Count
            If CLng(mMatches(i)) = partner Then mPosition = i: Exit For
        Next i
    Else
        AdvanceShiftOrigin 1
    End If
    RenderShiftChoice
    mReady = True
    Application.EnableCancelKey = previousCancel: cancelChanged = False
    AppEnd: started = False
    mBusy = False
    FreezeShiftReport ws
    Exit Sub
EH:
    message = Err.Description
    If Err.Number = 18 Then message = "���̌����𒆒f���܂����B"
    mReady = False
    On Error Resume Next
    If cancelChanged Then Application.EnableCancelKey = previousCancel
    If Not ws Is Nothing Then
        ws.Unprotect Password:=TOOL_PASSWORD
        ClearShiftFlags ws
        ws.Range("A2").Value2 = "�����������B������x�u���������v�Œ��ׂ��܂��B"
        ws.Range("A3").Value2 = message
        ProtectGeneratedOutput ws
    End If
    If started Then AppEnd
    mBusy = False
    Application.StatusBar = message
    On Error GoTo 0
End Sub

Private Function EnsureShiftSession() As Boolean
    If mBusy Then Exit Function
    If Not mReady Then SearchShiftFlags
    EnsureShiftSession = mReady
End Function

Public Sub ClearShiftFlags(ByVal ws As Worksheet)
    Dim last As Long
    last = LastUsedRowInSheet(ws)
    If last < 5 Then Exit Sub
    '�c���E�������̋��z��M��BH/I�̕\���������܂Ƃ߂Ė߂��B
    With ws.Range("H5:I" & last)
        .NumberFormat = "#,##0"
        .Font.Color = RGB(30, 41, 59): .Font.Bold = False
    End With
End Sub

Private Sub PaintShiftRow(ByVal ws As Worksheet, ByVal row As Long)
    Dim outputRow As Long, col As Long
    If Not mOutputRows.Exists(CStr(row)) Then Exit Sub
    outputRow = CLng(mOutputRows(CStr(row))): col = IIf(RowSide(row) = "W", 8, 9)
    With ws.Cells(outputRow, col)
        If mFlags.Exists(CStr(row)) Then
            .NumberFormat = """�� ""#,##0": .Font.Color = RGB(29, 78, 216): .Font.Bold = True
        Else
            .NumberFormat = "#,##0": .Font.Color = RGB(30, 41, 59): .Font.Bold = False
        End If
    End With
End Sub

Private Sub PaintShiftFlags(ByVal ws As Worksheet)
    Dim row As Variant, address As String, part As String
    ws.Unprotect Password:=TOOL_PASSWORD
    ClearShiftFlags ws
    For Each row In mFlags.Keys
        If mOutputRows.Exists(CStr(row)) Then
            part = IIf(RowSide(CLng(row)) = "W", "H", "I") & CStr(mOutputRows(CStr(row)))
            If Len(address) + Len(part) > 200 Then PaintShiftRange ws.Range(address): address = ""
            If Len(address) > 0 Then address = address & ","
            address = address & part
        End If
    Next row
    If Len(address) > 0 Then PaintShiftRange ws.Range(address)
    ProtectGeneratedOutput ws
End Sub

Private Sub PaintShiftRange(ByVal target As Range)
    target.NumberFormat = """�� ""#,##0"
    target.Font.Color = RGB(29, 78, 216): target.Font.Bold = True
End Sub

Private Sub CurrentShiftPair(ByRef withdrawal As Long, ByRef deposit As Long)
    withdrawal = 0: deposit = 0
    If mMatches Is Nothing Then Exit Sub
    If mPosition < 1 Or mPosition > mMatches.Count Then Exit Sub
    If RowSide(mOrigin) = "W" Then
        withdrawal = mOrigin: deposit = CLng(mMatches(mPosition))
    Else
        withdrawal = CLng(mMatches(mPosition)): deposit = mOrigin
    End If
End Sub

Private Function ShiftRowCaption(ByVal row As Long) As String
    Dim timeText As String
    timeText = "�����s��"
    If ShiftTimeKnown(mData(row, 7)) Then timeText = Format$(CDbl(mData(row, 7)), "hh:mm")
    ShiftRowCaption = Format$(CDate(mData(row, 6)), "yyyy/m/d") & " " & timeText & " " & CellText(mData(row, 3)) & " " & CellText(mData(row, 1)) & " " & CellText(mData(row, 5))
End Function

Private Sub RenderShiftChoice()
    Dim ws As Worksheet, w As Long, d As Long, label As String, order As Long, caption As String, excluded As Boolean
    Dim difference As Double, rate As Double
    Set ws = GetSheet(SH_OUTPUT_TX)
    ws.Unprotect Password:=TOOL_PASSWORD
    CurrentShiftPair w, d
    If w > 0 Then excluded = ShiftPairExcluded(w, d)
    caption = IIf(excluded, "���ɖ߂�", "��₩��O��")
    ws.Shapes(UI_PREFIX & "shift_3").TextFrame.Characters.Text = caption
    ws.Shapes(UI_PREFIX & "shift_6").TextFrame.Characters.Text = IIf(ShiftAllowDifference(), "�덷5%�ȓ�", "���S��v")
    ws.Shapes(UI_PREFIX & "shift_7").TextFrame.Characters.Text = "���t�� " & ShiftDays() & "��"
    ws.Range("A2").Value2 = "�S�o�^���ׁ^��▾�� " & mFlags.Count & "���^���O " & ShiftExcludedCount() & "�g"
    If w > 0 Then
        order = ShiftChronology(CDbl(mData(w, 6)), mData(w, 7), CDbl(mData(d, 6)), mData(d, 7), ShiftDays())
        label = "���t�Ŕ�r"
        If ShiftTimeKnown(mData(w, 7)) And ShiftTimeKnown(mData(d, 7)) Then label = "���n��"
        If order = 0 Then label = label & "�E�����̏������m��"
        difference = RowAmount(d) - RowAmount(w): rate = difference / RowAmount(w)
        ws.Range("A2").Value2 = ws.Range("A2").Value2 & "�^���� " & mPosition & "/" & mMatches.Count & "�^���̑g���� " & IIf(excluded, "OFF", "ON") & "�^" & label
        ws.Range("A2").Value2 = ws.Range("A2").Value2 & "�^���z " & Format$(difference, "+#,##0;-#,##0;0") & "�~�i" & Format$(rate, "+0.00%;-0.00%;0.00%") & "�j"
        ws.Range("A3").Value2 = "�o�� " & ShiftRowCaption(w) & "�@" & Format$(RowAmount(w), "#,##0") & "�~" & vbLf & "���� " & ShiftRowCaption(d) & "�@" & Format$(RowAmount(d), "#,##0") & "�~"
    Else
        ws.Range("A3").Value2 = "���̏����ɍ����g�����͂���܂���B�ʂ̋��z���_�u���N���b�N����ƁA���̖��ׂ̑�����m�F�ł��܂��B"
    End If
    ProtectGeneratedOutput ws
End Sub

Public Sub SelectShiftTransaction(ByVal target As Range)
    Dim pointer As Variant, row As Long, started As Boolean
    If CellText(GetSheet(SH_INPUT).Range("X7").Value2) <> "0" Then SearchShiftFlags: Exit Sub
    If Not EnsureShiftSession() Then Exit Sub
    If target.Worksheet.Name <> SH_OUTPUT_TX Or target.Row < 5 Then Exit Sub
    pointer = target.Worksheet.Cells(target.Row, 18).Value2
    If Not IsNumeric(pointer) Or Not HasText(pointer) Then Exit Sub
    row = CLng(pointer)
    If Not mOutputRows.Exists(CStr(row)) Then Exit Sub
    On Error GoTo EH
    AppBegin: started = True
    mOrigin = row: mPosition = 1
    Set mMatches = FindShiftPartners(row, False, True)
    RenderShiftChoice
    AppEnd
    Exit Sub
EH:
    If started Then AppEnd
    Application.StatusBar = "����\���ł��܂���ł����B" & Err.Description
End Sub

Public Sub NextShiftCandidate()
    StepShiftCandidate 1
End Sub

Public Sub PreviousShiftCandidate()
    StepShiftCandidate -1
End Sub

Private Sub StepShiftCandidate(ByVal direction As Long)
    Dim started As Boolean, message As String
    If Not EnsureShiftSession() Then Exit Sub
    On Error GoTo EH
    AppBegin: started = True
    If mPosition + direction >= 1 And mPosition + direction <= mMatches.Count Then
        mPosition = mPosition + direction
    Else
        AdvanceShiftOrigin direction
    End If
    RenderShiftChoice
    AppEnd
    Exit Sub
EH:
    message = Err.Description
    If started Then AppEnd
    Application.StatusBar = message
End Sub

Private Sub AdvanceShiftOrigin(ByVal direction As Long)
    Dim start As Long, i As Long, index As Long, row As Long, matches As Collection
    start = IIf(direction > 0, mCount - 1, 0)
    For i = 1 To mCount
        If mOrder(i) = mOrigin Then start = i - 1: Exit For
    Next i
    For i = 1 To mCount
        index = ((start + direction * i + mCount) Mod mCount) + 1
        row = mOrder(index)
        If RowSide(row) = "W" Then
            Set matches = FindShiftPartners(row, True, True)
            If matches.Count > 0 Then
                mOrigin = row: Set mMatches = FindShiftPartners(row, False, True)
                mPosition = IIf(direction > 0, 1, mMatches.Count)
                Exit Sub
            End If
        End If
    Next i
    mOrigin = 0: mPosition = 0: Set mMatches = New Collection
End Sub

Public Sub ToggleShiftExclusion()
    Dim w As Long, d As Long, row As Variant, partners As Collection, ws As Worksheet, started As Boolean, message As String
    Dim previousCancel As Long, cancelChanged As Boolean
    If mBusy Then Exit Sub
    '�ēǍ��Ŋm�F�Ώۂ��ς��ꍇ�A���̂܂ܕʂ̑g���������O���Ȃ��B
    If Not mReady Then SearchShiftFlags: Exit Sub
    CurrentShiftPair w, d
    If w = 0 Then Exit Sub
    On Error GoTo EH
    mBusy = True
    previousCancel = Application.EnableCancelKey: cancelChanged = True
    Application.EnableCancelKey = xlErrorHandler
    mReady = False
    Set ws = GetSheet(SH_OUTPUT_TX)
    AppBegin: started = True
    ws.Unprotect Password:=TOOL_PASSWORD
    '���O�L�^��ς���O�ɁA�e������o���̌Â���������B
    '�r���Ŏ��s���Ă��A��₪�Ȃ��Ȃ������ׂ֌Â�����c���Ȃ��B
    For Each row In Array(w, d)
        If mFlags.Exists(CStr(row)) Then mFlags.Remove CStr(row)
        PaintShiftRow ws, CLng(row)
    Next row
    SetShiftPairExcluded w, d, Not ShiftPairExcluded(w, d)
    For Each row In Array(w, d)
        Set partners = FindShiftPartners(CLng(row), True)
        If partners.Count > 0 Then
            mFlags(CStr(row)) = True
        ElseIf mFlags.Exists(CStr(row)) Then
            mFlags.Remove CStr(row)
        End If
        PaintShiftRow ws, CLng(row)
    Next row
    '����ꗗ�ƑI���ʒu�͕ێ��B�����{�^���ł�����x�����Γ����g������߂���B
    RenderShiftChoice
    Application.EnableCancelKey = previousCancel: cancelChanged = False
    mReady = True
    AppEnd: started = False: mBusy = False
    Exit Sub
EH:
    message = Err.Description
    If Err.Number = 18 Then message = "���̍X�V�𒆒f���܂����B"
    On Error Resume Next
    mReady = False: mOrigin = 0: mPosition = 0
    Set mFlags = CreateObject("Scripting.Dictionary"): Set mMatches = New Collection
    If Not ws Is Nothing Then
        ws.Unprotect Password:=TOOL_PASSWORD
        ClearShiftFlags ws
        ws.Range("A2").Value2 = "���̍X�V���������ł��B�u���������v�ōĊm�F���Ă��������B"
        ws.Range("A3").Value2 = message
        ws.Shapes(UI_PREFIX & "shift_3").TextFrame.Characters.Text = "��₩��O��"
        ProtectGeneratedOutput ws
    End If
    If cancelChanged Then Application.EnableCancelKey = previousCancel
    If started Then AppEnd
    mBusy = False
    Application.StatusBar = "���̍X�V�������ł��܂���ł����B" & message
    On Error GoTo 0
End Sub

Public Sub GoShiftWithdrawal()
    GoShiftMember True
End Sub

Public Sub GoShiftDeposit()
    GoShiftMember False
End Sub

Private Sub GoShiftMember(ByVal withdrawal As Boolean)
    Dim w As Long, d As Long, row As Long, ws As Worksheet
    If Not EnsureShiftSession() Then Exit Sub
    CurrentShiftPair w, d
    If w = 0 Then Exit Sub
    row = IIf(withdrawal, w, d)
    If Not mOutputRows.Exists(CStr(row)) Then Exit Sub
    Set ws = GetSheet(SH_OUTPUT_TX)
    On Error GoTo EH
    If ws.Rows(CLng(mOutputRows(CStr(row)))).Hidden Then
        If ws.FilterMode Then ws.ShowAllData
    End If
    Application.Goto ws.Cells(CLng(mOutputRows(CStr(row))), IIf(withdrawal, 8, 9)), True
    Exit Sub
EH:
    Application.StatusBar = "���薾�ׂֈړ��ł��܂���ł����B" & Err.Description
End Sub

Public Sub ToggleShiftTolerance()
    Dim started As Boolean, message As String, ws As Worksheet
    Dim previousCancel As Long, cancelChanged As Boolean
    If Not EnsureShiftSession() Then Exit Sub
    On Error GoTo EH
    previousCancel = Application.EnableCancelKey: cancelChanged = True
    Application.EnableCancelKey = xlErrorHandler
    AppBegin: started = True
    ChangeShiftTolerance Not ShiftAllowDifference()
    SearchShiftFlags
    Application.EnableCancelKey = previousCancel: cancelChanged = False
    AppEnd: started = False
    Exit Sub
EH:
    message = Err.Description
    mReady = False
    On Error Resume Next
    Set ws = GetSheet(SH_OUTPUT_TX): ws.Unprotect Password:=TOOL_PASSWORD
    ClearShiftFlags ws
    ws.Range("A2").Value2 = "�����̐ؑւ��������ł��B�u���������v�ōĊm�F���Ă��������B"
    ws.Range("A3").Value2 = message
    ProtectGeneratedOutput ws
    If cancelChanged Then Application.EnableCancelKey = previousCancel
    If started Then AppEnd
    Application.StatusBar = message
    On Error GoTo 0
End Sub

Public Sub ChooseShiftDays()
    Dim value As Variant, started As Boolean, message As String, ws As Worksheet
    Dim previousCancel As Long, cancelChanged As Boolean
    If Not EnsureShiftSession() Then Exit Sub
    value = Application.InputBox("�o���̓����牽����܂ł̓�����T���܂����H ���������Ȃ�0�B", "���t�̌�����", ShiftDays(), Type:=1)
    If VarType(value) = vbBoolean Then Exit Sub
    If value < 0 Or value > 3650 Or value <> Fix(value) Then
        MsgBox "0����3650�܂ł̐����œ��͂��Ă��������B", vbInformation: Exit Sub
    End If
    On Error GoTo EH
    previousCancel = Application.EnableCancelKey: cancelChanged = True
    Application.EnableCancelKey = xlErrorHandler
    AppBegin: started = True
    ChangeShiftDays CLng(value)
    SearchShiftFlags
    Application.EnableCancelKey = previousCancel: cancelChanged = False
    AppEnd: started = False
    Exit Sub
EH:
    message = Err.Description
    mReady = False
    On Error Resume Next
    Set ws = GetSheet(SH_OUTPUT_TX): ws.Unprotect Password:=TOOL_PASSWORD
    ClearShiftFlags ws
    ws.Range("A2").Value2 = "�����̐ؑւ��������ł��B�u���������v�ōĊm�F���Ă��������B"
    ws.Range("A3").Value2 = message
    ProtectGeneratedOutput ws
    If cancelChanged Then Application.EnableCancelKey = previousCancel
    If started Then AppEnd
    Application.StatusBar = message
    On Error GoTo 0
End Sub

Public Sub FreezeShiftReport(ByVal ws As Worksheet)
    On Error Resume Next
    If ActiveSheet Is ws Then
        If ActiveWindow.SplitRow <> 4 Or Not ActiveWindow.FreezePanes Then
            ActiveWindow.FreezePanes = False
            ActiveWindow.SplitColumn = 0: ActiveWindow.SplitRow = 4
            ActiveWindow.FreezePanes = True
        End If
    End If
    On Error GoTo 0
End Sub

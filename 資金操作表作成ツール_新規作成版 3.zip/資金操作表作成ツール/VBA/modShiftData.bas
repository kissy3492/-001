Attribute VB_Name = "modShiftData"
Option Explicit

Private Const SHIFT_STORE As String = "W_�V�t�g���f"
Private mRows As Variant, mIDs As Object, mByID As Object, mExcluded As Object
Private mExcludedRows As Object
Private mNextID As Long, mDays As Long
Private mAllowDifference As Boolean, mPreferencesLoaded As Boolean

Public Function CaptureShiftData() As Variant
    If SheetExists(SHIFT_STORE) Then CaptureShiftData = ReadStore(GetSheet(SHIFT_STORE), 19)
End Function

Public Sub RestoreShiftData(ByVal saved As Variant)
    If IsArray(saved) Then
        WriteStore GetSheet(SHIFT_STORE), saved
    ElseIf SheetExists(SHIFT_STORE) Then
        ClearStoreBody GetSheet(SHIFT_STORE), 19
    End If
    mPreferencesLoaded = False
    InvalidateShiftSession
End Sub

Public Sub ClearShiftData()
    Dim saved As Variant, cleared(1 To 2, 1 To 19) As Variant, r As Long, c As Long, days As Long, allowDifference As Boolean
    If SheetExists(SHIFT_STORE) Then
        saved = CaptureShiftData(): days = 3: allowDifference = True
        For c = 1 To 19: cleared(1, c) = saved(1, c): Next c
        For r = 2 To UBound(saved, 1)
            If CellText(saved(r, 1)) = "M" Then
                If IsNumeric(saved(r, 2)) Then days = CLng(saved(r, 2))
                allowDifference = CellText(saved(r, 4)) <> "0"
            End If
        Next r
        cleared(2, 1) = "M": cleared(2, 2) = days: cleared(2, 3) = 0
        cleared(2, 4) = IIf(allowDifference, 1, 0)
        WriteStore GetSheet(SHIFT_STORE), cleared
    End If
    mPreferencesLoaded = False
    InvalidateShiftSession
End Sub

Private Function RowSignature(ByRef rows As Variant, ByVal row As Long, ByVal offset As Long) As String
    Dim c As Long, value As String, marker As String
    For c = 1 To 16
        value = CStr(rows(row, c + offset))
        If offset = 3 Then
            If Len(CStr(rows(row, 3))) = 16 Then
                marker = Mid$(CStr(rows(row, 3)), c, 1)
                If marker <> "." Then value = marker & Mid$(value, 2)
            End If
        End If
        RowSignature = RowSignature & CStr(Len(value)) & ":" & value
    Next c
End Function

Public Sub LoadShiftData()
    Dim saved As Variant, oldGroups As Object, newGroups As Object, oldIDs As Collection, newRows As Collection
    Dim key As Variant, group As Collection, r As Long, i As Long, uid As String, oldID As String, pair As String
    mRows = ReadStore(GetSheet(SH_WORK_TX), 16)
    saved = CaptureShiftData()
    Set oldGroups = CreateObject("Scripting.Dictionary"): Set newGroups = CreateObject("Scripting.Dictionary")
    Set mIDs = CreateObject("Scripting.Dictionary"): Set mByID = CreateObject("Scripting.Dictionary")
    Set mExcluded = CreateObject("Scripting.Dictionary")
    mNextID = 0: mDays = 3: mAllowDifference = True
    If IsArray(saved) Then
        For r = 2 To UBound(saved, 1)
            Select Case CellText(saved(r, 1))
                Case "M"
                    If IsNumeric(saved(r, 2)) Then mDays = CLng(saved(r, 2))
                    If IsNumeric(saved(r, 3)) Then mNextID = CLng(saved(r, 3))
                    mAllowDifference = CellText(saved(r, 4)) <> "0"
                Case "R"
                    key = RowSignature(saved, r, 3)
                    If Not oldGroups.Exists(key) Then
                        Set group = New Collection: oldGroups.Add key, group
                    End If
                    Set group = oldGroups(key): group.Add CellText(saved(r, 2))
            End Select
        Next r
    End If
    If mDays < 0 Or mDays > 3650 Then mDays = 3
    mPreferencesLoaded = True
    For r = 2 To UBound(mRows, 1)
        If CellText(mRows(r, 16)) = "���" Then
            key = RowSignature(mRows, r, 0)
            If Not newGroups.Exists(key) Then
                Set group = New Collection: newGroups.Add key, group
            End If
            Set group = newGroups(key): group.Add r
        End If
    Next r
    For Each key In newGroups.Keys
        Set newRows = newGroups(key): Set oldIDs = Nothing
        If oldGroups.Exists(key) Then
            Set group = oldGroups(key)
            '������e�̌������ς�����ꍇ�A�폜���ꂽ���ׂ̔��f��ʖ��ׂֈڂ��Ȃ��B
            If group.Count = newRows.Count Then Set oldIDs = group
        End If
        For i = 1 To newRows.Count
            uid = ""
            If Not oldIDs Is Nothing Then uid = CStr(oldIDs(i))
            If Len(uid) = 0 Then mNextID = mNextID + 1: uid = "S" & CStr(mNextID)
            If mByID.Exists(uid) Then Err.Raise vbObjectError + 3500, , "���̑Ή�����ǂݏo���܂���ł����B"
            mIDs(CStr(newRows(i))) = uid: mByID(uid) = CLng(newRows(i))
        Next i
    Next key
    If IsArray(saved) Then
        For r = 2 To UBound(saved, 1)
            If CellText(saved(r, 1)) = "E" Then
                uid = CellText(saved(r, 2)): oldID = CellText(saved(r, 3))
                If mByID.Exists(uid) And mByID.Exists(oldID) Then
                    pair = uid & "|" & oldID: mExcluded(pair) = True
                End If
            End If
        Next r
    End If
    SaveShiftData
End Sub

Public Function ShiftRows() As Variant
    ShiftRows = mRows
End Function

Public Function ShiftRowID(ByVal row As Long) As String
    If mIDs.Exists(CStr(row)) Then ShiftRowID = CStr(mIDs(CStr(row)))
End Function

Public Function ShiftRowFromID(ByVal uid As String) As Long
    If mByID.Exists(uid) Then ShiftRowFromID = CLng(mByID(uid))
End Function

Private Sub LoadShiftPreferences()
    Dim ws As Worksheet
    If mPreferencesLoaded Then Exit Sub
    mDays = 3: mAllowDifference = True
    If SheetExists(SHIFT_STORE) Then
        Set ws = GetSheet(SHIFT_STORE)
        If CellText(ws.Cells(2, 1).Value2) = "M" Then
            If IsNumeric(ws.Cells(2, 2).Value2) Then mDays = CLng(ws.Cells(2, 2).Value2)
            mAllowDifference = CellText(ws.Cells(2, 4).Value2) <> "0"
        End If
    End If
    If mDays < 0 Or mDays > 3650 Then mDays = 3
    mPreferencesLoaded = True
End Sub

Public Function ShiftDays() As Long
    LoadShiftPreferences
    ShiftDays = mDays
End Function

Public Function ShiftAllowDifference() As Boolean
    LoadShiftPreferences
    ShiftAllowDifference = mAllowDifference
End Function

Public Sub ChangeShiftDays(ByVal days As Long)
    SaveShiftPreference 2, days
    mDays = days
End Sub

Public Sub ChangeShiftTolerance(ByVal allowDifference As Boolean)
    SaveShiftPreference 4, IIf(allowDifference, 1, 0)
    mAllowDifference = allowDifference
End Sub

Private Sub SaveShiftPreference(ByVal column As Long, ByVal value As Long)
    Dim ws As Worksheet, previous As Variant, writing As Boolean, message As String
    On Error GoTo EH
    Set ws = GetSheet(SHIFT_STORE)
    previous = ws.Cells(2, column).Value2
    writing = True
    ws.Cells(2, column).Value2 = value
    Exit Sub
EH:
    message = Err.Description
    On Error Resume Next
    If writing Then ws.Cells(2, column).Value2 = previous
    mPreferencesLoaded = False
    On Error GoTo 0
    Err.Raise vbObjectError + 3501, "SaveShiftPreference", message
End Sub

Public Function ShiftPairExcluded(ByVal withdrawal As Long, ByVal deposit As Long) As Boolean
    ShiftPairExcluded = mExcluded.Exists(ShiftRowID(withdrawal) & "|" & ShiftRowID(deposit))
End Function

Public Function ShiftExcludedCount() As Long
    ShiftExcludedCount = mExcluded.Count
End Function

Public Sub SetShiftPairExcluded(ByVal withdrawal As Long, ByVal deposit As Long, ByVal excluded As Boolean)
    Dim key As String, existed As Boolean, message As String, ws As Worksheet, row As Long
    Dim previous As Variant, nextRow(1 To 1, 1 To 3) As Variant, writing As Boolean, restoreIssue As String
    key = ShiftRowID(withdrawal) & "|" & ShiftRowID(deposit): existed = mExcluded.Exists(key)
    If excluded = existed Then Exit Sub
    On Error GoTo EH
    Set ws = GetSheet(SHIFT_STORE)
    If existed Then row = CLng(mExcludedRows(key)) Else row = LastRow(ws, 1) + 1
    previous = ws.Cells(row, 1).Resize(1, 3).Value2
    writing = True
    If excluded Then
        nextRow(1, 1) = "E": nextRow(1, 2) = ShiftRowID(withdrawal): nextRow(1, 3) = ShiftRowID(deposit)
        ws.Cells(row, 1).Resize(1, 3).Value2 = nextRow
        mExcluded(key) = True: mExcludedRows(key) = row
    Else
        ws.Cells(row, 1).Resize(1, 3).ClearContents
        mExcluded.Remove key: mExcludedRows.Remove key
    End If
    Exit Sub
EH:
    message = Err.Description
    On Error Resume Next
    If writing Then
        Err.Clear
        ws.Cells(row, 1).Resize(1, 3).Value2 = previous
        If Err.Number <> 0 Then restoreIssue = " ���O�L�^�̕������������ł��B"
    End If
    If existed Then
        mExcluded(key) = True: mExcludedRows(key) = row
    ElseIf mExcluded.Exists(key) Then
        mExcluded.Remove key: mExcludedRows.Remove key
    End If
    On Error GoTo 0
    Err.Raise vbObjectError + 3502, "SetShiftPairExcluded", message & restoreIssue
End Sub

Private Sub SaveShiftData()
    Dim ws As Worksheet, saved As Variant, nextData As Variant, key As Variant, parts As Variant
    Dim row As Long, r As Long, c As Long, same As Boolean, writing As Boolean, message As String, restoreIssue As String
    Dim markers As String, text As String, marker As String
    On Error GoTo EH
    saved = CaptureShiftData()
    Set mExcludedRows = CreateObject("Scripting.Dictionary")
    ReDim nextData(1 To 2 + mIDs.Count + mExcluded.Count, 1 To 19)
    nextData(1, 1) = "�敪": nextData(1, 2) = "�Ώ�": nextData(1, 3) = "����"
    For c = 1 To 16: nextData(1, c + 3) = "���l" & CStr(c): Next c
    nextData(2, 1) = "M": nextData(2, 2) = mDays: nextData(2, 3) = mNextID
    nextData(2, 4) = IIf(mAllowDifference, 1, 0)
    row = 2
    For r = 2 To UBound(mRows, 1)
        If mIDs.Exists(CStr(r)) Then
            row = row + 1: nextData(row, 1) = "R": nextData(row, 2) = mIDs(CStr(r))
            markers = ""
            For c = 1 To 16
                nextData(row, c + 3) = mRows(r, c): marker = "."
                If VarType(mRows(r, c)) = vbString Then
                    text = CStr(mRows(r, c))
                    If Len(text) > 0 Then
                        If InStr(1, "=+-@", Left$(text, 1), vbBinaryCompare) > 0 Then
                            marker = Left$(text, 1): nextData(row, c + 3) = "!" & Mid$(text, 2)
                        End If
                    End If
                End If
                markers = markers & marker
            Next c
            nextData(row, 3) = markers
        End If
    Next r
    For Each key In mExcluded.Keys
        parts = Split(CStr(key), "|"): row = row + 1
        nextData(row, 1) = "E": nextData(row, 2) = parts(0): nextData(row, 3) = parts(1)
        mExcludedRows(key) = row
    Next key
    If IsArray(saved) Then
        same = (UBound(saved, 1) = UBound(nextData, 1))
        If same Then
            For r = 1 To UBound(nextData, 1)
                For c = 1 To 19
                    If CStr(saved(r, c)) <> CStr(nextData(r, c)) Then same = False: Exit For
                Next c
                If Not same Then Exit For
            Next r
        End If
        If same Then Exit Sub
    End If
    Set ws = GetOrCreateSheet(SHIFT_STORE, False)
    ws.Visible = xlSheetVeryHidden
    '�����𐔎��Ƃ��čĎ��s���Ȃ��B�o�^���ׂ̒l������ۑ�����B
    ws.Cells(1, 1).Resize(UBound(nextData, 1), 19).NumberFormat = "@"
    writing = True
    WriteStore ws, nextData
    Exit Sub
EH:
    message = Err.Description
    On Error Resume Next
    If writing Then
        Err.Clear
        If IsArray(saved) Then WriteStore ws, saved Else ClearStoreBody ws, 19
        If Err.Number <> 0 Then restoreIssue = " ���O�L�^�̕������������ł��B"
    End If
    On Error GoTo 0
    Err.Raise vbObjectError + 3503, "SaveShiftData", "���̔��f��ۑ��ł��܂���ł����B" & message & restoreIssue
End Sub

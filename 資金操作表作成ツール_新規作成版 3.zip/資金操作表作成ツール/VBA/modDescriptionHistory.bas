Attribute VB_Name = "modDescriptionHistory"
Option Explicit

Private Const CELL_DESCRIPTION_HISTORY As String = "X16"
Private mDescriptions As Variant
Private mDescriptionCount As Long
Private mDescriptionsReady As Boolean

Public Sub ResetDescriptionCache()
    mDescriptionsReady = False
    mDescriptions = Empty
    mDescriptionCount = 0
End Sub

Public Sub EnsureDescriptionHistory()
    Dim values As Collection, seen As Object, tx As Variant, raw As Variant, ws As Worksheet
    Dim r As Long, lastR As Long, initialized As Boolean
    If mDescriptionsReady Then Exit Sub
    Set values = New Collection: Set seen = CreateObject("Scripting.Dictionary")
    seen.CompareMode = vbTextCompare
    Set ws = GetSheet(SH_TEKIYO)
    initialized = (CellText(GetSheet(SH_INPUT).Range(CELL_DESCRIPTION_HISTORY).Value2) = "1")
    If initialized Then
        lastR = LastRow(ws)
        If lastR >= 2 Then
            raw = ws.Range("A1:A" & lastR).Value2
            For r = 2 To UBound(raw, 1): CollectDescription values, seen, raw(r, 1): Next r
        End If
    Else
        '����͌Œ���������p�����A���͒��E�o�^�ς݂̎��ۂ̓E�v������B
        lastR = LastInputDataRow()
        If lastR >= TX_FIRST_ROW Then
            raw = GetSheet(SH_INPUT).Range("J" & TX_FIRST_ROW - 1 & ":J" & lastR).Value2
            For r = UBound(raw, 1) To 2 Step -1: CollectDescription values, seen, raw(r, 1): Next r
        End If
        tx = ReadStore(GetSheet(SH_WORK_TX), 16)
        For r = UBound(tx, 1) To 2 Step -1
            If CellText(tx(r, TX_KIND_COL)) = "���" Then CollectDescription values, seen, tx(r, 12)
        Next r
    End If
    If initialized Then
        CacheDescriptionHistory values
    Else
        StoreDescriptionHistory values, True
        GetSheet(SH_INPUT).Range(CELL_DESCRIPTION_HISTORY).Value2 = "1"
    End If
End Sub

Private Sub CollectDescription(ByVal values As Collection, ByVal seen As Object, ByVal value As Variant)
    Dim s As String
    If IsError(value) Then Exit Sub
    s = CellText(value)
    If Len(s) = 0 Or s = "����" Then Exit Sub
    If seen.Exists(s) Then Exit Sub
    seen.Add s, True: values.Add s
End Sub

Public Sub RememberDescriptionRange(ByVal source As Range)
    Dim area As Range, batch As Collection, raw As Variant, r As Long
    If source Is Nothing Then Exit Sub
    Set batch = New Collection
    For Each area In source.Areas
        raw = area.Value2
        If IsArray(raw) Then
            For r = 1 To UBound(raw, 1): batch.Add raw(r, 1): Next r
        Else
            batch.Add raw
        End If
    Next area
    RememberDescriptionBatch batch
End Sub

Public Sub RememberStoredDescriptions(ByVal tx As Variant)
    Dim batch As New Collection, r As Long
    For r = 2 To UBound(tx, 1)
        If CellText(tx(r, TX_KIND_COL)) = "���" Then batch.Add tx(r, 12)
    Next r
    RememberDescriptionBatch batch
End Sub

Private Sub RememberDescriptionBatch(ByVal batch As Collection)
    Dim values As New Collection, seen As Object, r As Long, s As String
    If batch.Count = 0 Then Exit Sub
    EnsureDescriptionHistory
    Set seen = CreateObject("Scripting.Dictionary"): seen.CompareMode = vbTextCompare
    '�ꊇ�\��t���͌�̍s��擪�ɂ��A������������x����������B
    For r = batch.Count To 1 Step -1: CollectDescription values, seen, batch(r): Next r
    If values.Count = 0 Then Exit Sub
    If values.Count = 1 And mDescriptionCount > 0 Then
        s = CStr(values(1))
        If StrComp(CStr(mDescriptions(1, 1)), s, vbBinaryCompare) = 0 Then Exit Sub
    End If
    For r = 1 To mDescriptionCount: CollectDescription values, seen, mDescriptions(r, 1): Next r
    StoreDescriptionHistory values, False
End Sub

Private Sub StoreDescriptionHistory(ByVal values As Collection, ByVal resetList As Boolean)
    Dim ws As Worksheet, data As Variant, changed As Variant
    Dim n As Long, r As Long, oldLast As Long, firstChange As Long, lastChange As Long
    Set ws = GetSheet(SH_TEKIYO)
    n = values.Count: oldLast = LastRow(ws)
    ReDim data(1 To Application.Max(1, n), 1 To 1)
    For r = 1 To n
        data(r, 1) = CStr(values(r))
    Next r
    firstChange = 1: lastChange = Application.Max(1, n)
    If mDescriptionsReady And n = mDescriptionCount And Not resetList Then
        firstChange = 0: lastChange = 0
        For r = 1 To n
            If CStr(data(r, 1)) <> CStr(mDescriptions(r, 1)) Then
                If firstChange = 0 Then firstChange = r
                lastChange = r
            End If
        Next r
    End If
    If firstChange > 0 Then
        ReDim changed(1 To lastChange - firstChange + 1, 1 To 1)
        For r = firstChange To lastChange: changed(r - firstChange + 1, 1) = data(r, 1): Next r
        With ws.Cells(firstChange + 1, 1).Resize(UBound(changed, 1), 1)
            .NumberFormat = "@": .Value2 = changed
        End With
    End If
    If oldLast > n + 1 Then ws.Range("A" & n + 2 & ":A" & oldLast).ClearContents
    If resetList Or n <> mDescriptionCount Then ResetName NM_LST_TEKIYO, ws.Range("A2:A" & Application.Max(2, n + 1))
    mDescriptions = data
    mDescriptionCount = n: mDescriptionsReady = True
End Sub

Public Sub RefreshDescriptionHistoryFromSheet()
    Dim values As New Collection, seen As Object, raw As Variant, r As Long
    Set seen = CreateObject("Scripting.Dictionary"): seen.CompareMode = vbTextCompare
    raw = GetSheet(SH_TEKIYO).Range("A1:A" & Application.Max(2, LastRow(GetSheet(SH_TEKIYO)))).Value2
    For r = 2 To UBound(raw, 1): CollectDescription values, seen, raw(r, 1): Next r
    StoreDescriptionHistory values, True
End Sub

Private Sub CacheDescriptionHistory(ByVal values As Collection)
    Dim data As Variant, r As Long
    ReDim data(1 To Application.Max(1, values.Count), 1 To 1)
    For r = 1 To values.Count: data(r, 1) = CStr(values(r)): Next r
    mDescriptions = data: mDescriptionCount = values.Count: mDescriptionsReady = True
End Sub

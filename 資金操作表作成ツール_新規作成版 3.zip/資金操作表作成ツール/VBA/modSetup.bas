Attribute VB_Name = "modSetup"
Option Explicit

Public Sub SetupWorkbook()
    On Error GoTo EH
    If SheetExists(SH_CONFIG) Or SheetExists(SH_WORK_TX) Then
        MsgBox "�쐬�ς݂̃u�b�N�ł��B�ݒ�́u�ݒ�v����ύX�ł��܂��B", vbInformation
        Exit Sub
    End If
    AppBegin "���͉�ʂ��쐬���Ă��܂�..."
    ResetInputCapacityCache
    ResetDescriptionCache
    InvalidateCandidateCache
    ThisWorkbook.Date1904 = False
    DisableInputKeys
    PrepareSheets
    BuildConfigSheet
    BuildMasterSheets
    EnsureContinuationSettings
    BuildCandidateSheets False
    BuildInputSheet
    BuildWorkSheets
    FormatWorkTx: FormatWorkBal
    EnsureAccountStore
    EnsureDescriptionHistory
    BuildOutputSheets
    BuildBalanceInputFields False
    ApplyInputSettings False
    BuildOperationPanel GetSheet(SH_INPUT)
    GetSheet(SH_INPUT).Activate
    SafeFreezeInput
    SafeSelectCell GetSheet(SH_INPUT), CELL_BANK
    HideDailySheets True
    ProtectConfigSheet
    RefreshButtonActions
    AppEnd
    EnableInputKeys
    Exit Sub
EH:
    Dim e As Long, message As String
    e = Err.Number: message = Err.Description
    AppEnd
    Err.Raise e, "SetupWorkbook", message
End Sub

Public Sub PrepareSheets()
    GetOrCreateSheet SH_CONFIG, True
    GetOrCreateSheet SH_INPUT, True
    GetOrCreateSheet SH_TEKIYO, True
    GetOrCreateSheet SH_ACCOUNT_TYPE, True
    GetOrCreateSheet SH_INPUT_MODE, True
    GetOrCreateSheet SH_YEAR_MODE, True
    GetOrCreateSheet SH_DISPLAY_OPTION, True
    GetOrCreateSheet SH_BANK_CAND, True
    GetOrCreateSheet SH_BRANCH_CAND, True
    GetOrCreateSheet SH_PERSON_CAND, True
    GetOrCreateSheet SH_WORK_TX, True
    GetOrCreateSheet SH_WORK_BAL, True
    GetOrCreateSheet SH_OUTPUT_TX, True
    GetOrCreateSheet SH_OUTPUT_BAL, True
    GetOrCreateSheet SH_SHOP_TARGET, True
End Sub

Public Sub BuildConfigSheet()
    CreateConfigSheet
End Sub

Public Sub BuildMasterSheets()
    Dim ws As Worksheet
    On Error GoTo EH
    Set ws = GetSheet(SH_TEKIYO)
    ws.Cells.Clear
    ws.Range("A1").Value = "�E�v���": ws.Range("A1").Font.Bold = True
    ws.Columns("A:A").NumberFormat = "@"
    ws.Columns("A:A").ColumnWidth = 36
    ResetName NM_LST_TEKIYO, ws.Range("A2")
    Set ws = GetSheet(SH_ACCOUNT_TYPE)
    ws.Cells.Clear
    ws.Range("A1").Value = "�Ȗڌ��": ws.Range("A1").Font.Bold = True
    EnsureDefaultAccountTypes
    ws.Columns("A:A").ColumnWidth = 22
    Set ws = GetSheet(SH_INPUT_MODE)
    ws.Cells.Clear
    ws.Range("A1").Value = "���̓��[�h": ws.Range("A1").Font.Bold = True
    ws.Range("A2:A7").Value = Application.Transpose(Array(MODE_NORMAL, MODE_NO_TIME, MODE_NO_MACHINE, MODE_NO_TEKIYO, MODE_WITH_OTHER, MODE_SIMPLE))
    ws.Columns("A:A").ColumnWidth = 18
    ResetName NM_LST_INPUT_MODE, ws.Range("A2:A7")

    Set ws = GetSheet(SH_YEAR_MODE)
    ws.Cells.Clear
    ws.Range("A1").Value = "�N���͕���": ws.Range("A1").Font.Bold = True
    ws.Range("A2:A3").Value = Application.Transpose(Array(YEAR_MODE_WAREKI, YEAR_MODE_WESTERN2))
    ws.Columns("A:A").ColumnWidth = 18
    ResetName NM_LST_YEAR_MODE, ws.Range("A2:A3")

    Set ws = GetSheet(SH_DISPLAY_OPTION)
    ws.Cells.Clear
    ws.Range("A1").Value = "�\���ؑ�": ws.Range("A1").Font.Bold = True
    ws.Range("A2:A3").Value = Application.Transpose(Array(DISPLAY_ON, DISPLAY_OFF))
    ws.Columns("A:A").ColumnWidth = 16
    ResetName NM_LST_DISPLAY_OPTION, ws.Range("A2:A3")

    ApplyValidationList GetCfgCell(ROW_CFG_INPUT_MODE), NM_LST_INPUT_MODE, xlIMEModeOff, False
    ApplyValidationList GetCfgCell(ROW_CFG_YEAR_MODE), NM_LST_YEAR_MODE, xlIMEModeOff, False
    ApplyValidationList GetCfgCell(ROW_CFG_RELATIONSHIP), NM_LST_DISPLAY_OPTION, xlIMEModeOff, False
    ApplyValidationList GetCfgCell(ROW_CFG_SHOW_INHERITANCE_ROW), NM_LST_DISPLAY_OPTION, xlIMEModeOff, False
    ApplyValidationList GetCfgCell(ROW_CFG_SHOW_OPEN_DATE_ROW), NM_LST_DISPLAY_OPTION, xlIMEModeOff, False
    ApplyValidationList GetCfgCell(ROW_CFG_SHOW_CLOSE_DATE_ROW), NM_LST_DISPLAY_OPTION, xlIMEModeOff, False
    ApplyValidationList GetCfgCell(ROW_CFG_SHOW_BALANCE_ROWS), NM_LST_DISPLAY_OPTION, xlIMEModeOff, False
    Exit Sub
EH:
    Err.Raise Err.Number, "BuildMasterSheets", Err.Description
End Sub
Public Sub BuildInputSheet()
    Dim ws As Worksheet
    Dim r As Long
    On Error GoTo EH
    Set ws = GetSheet(SH_INPUT)
    If ws Is Nothing Then Err.Raise vbObjectError + 1201, "BuildInputSheet", "���̓V�[�g���擾�ł��܂���B"
    With ws
        .Unprotect Password:=TOOL_PASSWORD
        .Cells.Clear
        .Cells.Font.Name = "Yu Gothic UI"
        .Cells.Font.Size = 10
        .Cells.Font.Color = RGB(15, 23, 42)
        .Cells.Interior.Color = RGB(255, 255, 255)
        .Rows.RowHeight = 20
        .Columns("A:A").ColumnWidth = 2
        .Columns("B:I").ColumnWidth = 14.5
        .Columns("J:J").ColumnWidth = 18
        .Columns("K:K").ColumnWidth = 24
        .Columns("L:L").ColumnWidth = 2
        .Columns("M:T").ColumnWidth = 12.8
        .Columns("U:U").ColumnWidth = 2

        MergeAndFormat .Range("B2:K2"), "��������\�E�c�����ڕ\"
        With .Range("B2:K2")
            .Interior.Color = RGB(239, 246, 255)
            .Font.Color = RGB(30, 64, 175)
            .Font.Bold = True
            .Font.Size = 16
            .HorizontalAlignment = xlCenter
            .VerticalAlignment = xlCenter
            .Borders.LineStyle = xlContinuous
            .Borders.Color = RGB(147, 197, 253)
        End With
        .Rows(2).RowHeight = 30

        MergeAndFormat .Range("B4:K4"), "�������"
        FormatHeader .Range("B4:K4")
        .Range("B5").Value = "��s��": MergeAndFormat .Range("C5:D5"), ""
        .Range("E5").Value = "�x�X��": MergeAndFormat .Range("F5:G5"), ""
        .Range("H5").Value = "����": .Range("I5").Value = ""
        .Range("J5").Value = "����": .Range("K5").Value = ""
        .Range("B6").Value = "�Ȗ�": MergeAndFormat .Range("C6:D6"), ""
        .Range("E6").Value = "�����ԍ�": MergeAndFormat .Range("F6:G6"), ""
        .Range("H6").Value = "�J�ݓ�": .Range("I6").Value = ""
        .Range("J6").Value = "����": .Range("K6").Value = ""
        .Range("B5:K6").Borders.LineStyle = xlContinuous
        .Range("B5:K6").Borders.Color = RGB(203, 213, 225)
        .Range("B5,E5,H5,J5,B6,E6,H6,J6").Font.Bold = True
        .Range("B5,E5,H5,J5,B6,E6,H6,J6").Interior.Color = RGB(241, 245, 249)
        .Range("B5,E5,H5,J5,B6,E6,H6,J6").Font.Color = RGB(30, 64, 175)
        .Range("C5:D5,F5:G5,I5,K5,C6:D6,F6:G6,I6,K6").Interior.Color = RGB(248, 250, 252)
        .Range("C5:D5,F5:G5,I5,K5,C6:D6,F6:G6,I6,K6").Font.Color = RGB(15, 23, 42)

        MergeAndFormat .Range("B8:K8"), "�c������"
        FormatHeader .Range("B8:K8")

        MergeAndFormat .Range(CELL_STATUS & ":K12"), "�⊮�l�@-�N�@-���@-���@--:--"
        With .Range(CELL_STATUS & ":K12")
            .Interior.Color = RGB(236, 253, 245)
            .Font.Color = RGB(15, 118, 110)
            .Borders.LineStyle = xlContinuous
            .Borders.Color = RGB(94, 234, 212)
            .HorizontalAlignment = xlCenter
            .VerticalAlignment = xlCenter
            .Font.Bold = True
        End With
        .Rows(12).RowHeight = 25

        SetRowValues .Range("B14"), Array("�N", "��", "��", "����", "�o��", "����", "�戵�X", "�@��", "�E�v", "���̑�")
        FormatOutputHeader .Range("B14:K14")
        With .Range("B14:K14")
            .Interior.Color = RGB(37, 99, 235)
            .Font.Color = RGB(255, 255, 255)
            .Borders.Color = RGB(29, 78, 216)
        End With

        With .Range(.Cells(TX_FIRST_ROW, COL_TX_YEAR), .Cells(InputLastTransactionRow(), COL_TX_OTHER))
            .Borders.LineStyle = xlContinuous: .Borders.Color = RGB(226, 232, 240)
            .Interior.Color = vbWhite: .Font.Color = RGB(15, 23, 42)
        End With
        .Rows(TX_FIRST_ROW & ":" & InputLastTransactionRow()).RowHeight = 21
        .Range(.Cells(TX_FIRST_ROW, COL_TX_OTHER), .Cells(InputLastTransactionRow(), COL_TX_OTHER)).WrapText = False
        .Range(.Cells(TX_FIRST_ROW, COL_TX_TIME), .Cells(InputLastTransactionRow(), COL_TX_TIME)).NumberFormatLocal = "@"
        .Range(.Cells(TX_FIRST_ROW, COL_TX_SHOP), .Cells(InputLastTransactionRow(), COL_TX_MACHINE)).NumberFormatLocal = "@"
        .Range(.Cells(TX_FIRST_ROW, COL_TX_WITHDRAW), .Cells(InputLastTransactionRow(), COL_TX_DEPOSIT)).NumberFormat = "@"
        .Range(.Cells(TX_FIRST_ROW, COL_TX_YEAR), .Cells(InputLastTransactionRow(), COL_TX_DAY)).NumberFormatLocal = "0"
        BuildOperationPanel ws
        BuildInputHelpCards ws
    End With
    PolishInputLayout ws
    Exit Sub
EH:
    Err.Raise Err.Number, "BuildInputSheet", Err.Description
End Sub
Public Sub BuildWorkSheets()
    Dim ws As Worksheet
    On Error GoTo EH
    Set ws = GetSheet(SH_WORK_TX)
    ws.Cells.Clear
    SetRowValues ws.Range("A1"), Array("��s��", "�x�X��", "����", "�Ȗ�", "�����ԍ�", "���t", "����", "�o��", "����", "�戵�X", "�@��", "�E�v��", "���̑�", "����")
    FormatOutputHeader ws.Range("A1:N1")
    ws.Columns("A:N").ColumnWidth = 14
    ws.Columns("F:F").NumberFormatLocal = "yyyy/m/d"
    ws.Columns("G:G").NumberFormatLocal = "hh:mm"
    ws.Columns("H:I").NumberFormatLocal = "#,##0"
    ws.Columns("E:E").NumberFormatLocal = "@"
    ws.Columns("J:K").NumberFormatLocal = "@"
    ws.Columns("M:M").NumberFormatLocal = "#,##0"
    Set ws = GetSheet(SH_WORK_BAL)
    ws.Cells.Clear
    SetRowValues ws.Range("A1"), Array("����", "��s��", "�x�X��", "�Ȗ�", "�����ԍ�", "�����J�ݓ�", "��������", "�c�����", "�c�����o��", "�c��", "���̑�", "����")
    FormatOutputHeader ws.Range("A1:L1")
    ws.Columns("A:L").ColumnWidth = 14
    ws.Columns("F:H").NumberFormatLocal = "yyyy/m/d"
    ws.Columns("J:J").NumberFormatLocal = "#,##0"
    FormatWorkTx: FormatWorkBal
    Exit Sub
EH:
    Err.Raise Err.Number, "BuildWorkSheets", Err.Description
End Sub

Public Sub BuildOutputSheets()
    Dim ws As Worksheet
    On Error GoTo EH
    Set ws = GetSheet(SH_OUTPUT_TX)
    ws.Unprotect Password:=TOOL_PASSWORD
    ws.Cells.Clear
    SetRowValues ws.Range("A1"), Array("��s��", "�x�X��", "����", "�Ȗ�", "�����ԍ�", "���t", "����", "�o��", "����", "�戵�X", "�@��", "�E�v��", "���̑�")
    FormatOutputHeader ws.Range("A1:M1")
    ws.Columns("A:M").ColumnWidth = 14
    ws.Columns("F:F").NumberFormatLocal = "yyyy/m/d"
    ws.Columns("G:G").NumberFormatLocal = "hh:mm"
    ws.Columns("H:I").NumberFormatLocal = "#,##0"
    ws.Columns("E:E").NumberFormatLocal = "@"
    ws.Columns("J:K").NumberFormatLocal = "@"
    ws.Columns("M:M").NumberFormatLocal = "#,##0"
    AutoFitSheetSmart ws, "A:M", 8, 34
    Set ws = GetSheet(SH_OUTPUT_BAL)
    ws.Unprotect Password:=TOOL_PASSWORD
    ws.Cells.Clear
    ws.Range("A1").Value = "�c�����ڕ\"
    ws.Range("A1").Font.Bold = True
    ws.Range("A1").Font.Size = 14
    ws.Columns("A:Z").ColumnWidth = 14
    AutoFitSheetSmart ws, "A:Z", 8, 34

    Set ws = GetSheet(SH_SHOP_TARGET)
    ws.Unprotect Password:=TOOL_PASSWORD
    SetupShopConversionTargetSheet ws
    FormatShopConversionTargetSheet ws

    Exit Sub
EH:
    Err.Raise Err.Number, "BuildOutputSheets", Err.Description
End Sub

Public Sub BuildBalanceInputFields(Optional ByVal showDoneMessage As Boolean = True)
    Dim e As Long, message As String
    On Error GoTo EH
    AppBegin "�c�������X�V���Ă��܂�..."
    RebuildBalanceDraft
    AppEnd
    Exit Sub
EH:
    e = Err.Number: message = Err.Description
    AppEnd
    Err.Raise e, "BuildBalanceInputFields", message
End Sub

Public Sub ResetBalanceInputArea(ByVal ws As Worksheet)
    Dim rng As Range
    If ws Is Nothing Then Exit Sub
    ws.Unprotect Password:=TOOL_PASSWORD
    Set rng = ws.Range(ws.Cells(BAL_LABEL_ROW, BAL_FIRST_COL), ws.Cells(BAL_DATE_ROW, BAL_MAX_COL))
    rng.UnMerge
    rng.Validation.Delete
    rng.ClearContents
    rng.ClearFormats
End Sub

Public Sub FormatBalanceInputArea(ByVal ws As Worksheet, ByVal memoCol As Long)
    Dim labelRange As Range
    Dim valueRange As Range
    Dim dateRange As Range
    If ws Is Nothing Then Exit Sub

    Set labelRange = ws.Range(ws.Cells(BAL_LABEL_ROW, BAL_FIRST_COL), ws.Cells(BAL_LABEL_ROW, BAL_MAX_COL))
    Set valueRange = ws.Range(ws.Cells(BAL_VALUE_ROW, BAL_FIRST_COL), ws.Cells(BAL_VALUE_ROW, BAL_MAX_COL))
    Set dateRange = ws.Range(ws.Cells(BAL_DATE_ROW, BAL_FIRST_COL), ws.Cells(BAL_DATE_ROW, BAL_MAX_COL))

    With labelRange
        .Font.Bold = True
        .Font.Size = 10
        .Font.Color = RGB(30, 64, 175)
        .Interior.Color = RGB(219, 234, 254)
        .HorizontalAlignment = xlCenter
        .VerticalAlignment = xlCenter
        .Borders.LineStyle = xlContinuous
        .Borders.Color = RGB(147, 197, 253)
        .WrapText = True
        .ShrinkToFit = False
    End With

    With valueRange
        .Interior.Color = RGB(248, 250, 252)
        .Font.Color = RGB(15, 23, 42)
        .Borders.LineStyle = xlContinuous
        .VerticalAlignment = xlCenter
    End With

    With dateRange
        .Interior.Color = RGB(241, 245, 249)
        .Borders.LineStyle = xlContinuous
        .Font.Size = 8
        .Font.Color = RGB(71, 85, 105)
        .HorizontalAlignment = xlCenter
        .NumberFormatLocal = "yyyy/m/d"
    End With

    If memoCol > BAL_FIRST_COL Then ws.Range(ws.Cells(BAL_VALUE_ROW, BAL_FIRST_COL), ws.Cells(BAL_VALUE_ROW, memoCol - 1)).NumberFormatLocal = "#,##0"

    On Error Resume Next
    If ws.Cells(BAL_VALUE_ROW, memoCol).MergeCells Then
        ws.Cells(BAL_VALUE_ROW, memoCol).MergeArea.NumberFormatLocal = "@"
        ws.Cells(BAL_VALUE_ROW, memoCol).MergeArea.HorizontalAlignment = xlLeft
    Else
        ws.Cells(BAL_VALUE_ROW, memoCol).NumberFormatLocal = "@"
        ws.Cells(BAL_VALUE_ROW, memoCol).HorizontalAlignment = xlLeft
    End If
    On Error GoTo 0

    ws.Rows(BAL_LABEL_ROW).RowHeight = 30
    ws.Rows(BAL_VALUE_ROW).RowHeight = 25
    ws.Rows(BAL_DATE_ROW).RowHeight = 17
End Sub

Public Sub ApplyInputSettings(Optional ByVal showDoneMessage As Boolean = True)
    Dim ws As Worksheet
    Dim memoCol As Long
    On Error GoTo EH
    If Not SheetExists(SH_INPUT) Then Exit Sub
    Set ws = GetSheet(SH_INPUT)
    ws.Unprotect Password:=TOOL_PASSWORD
    RefreshAccountCandidateNames
    ApplyValidationList ws.Range(CELL_BANK), NM_LST_BANK_CAND, xlIMEModeHiragana, True
    ApplyValidationList ws.Range(CELL_BRANCH), NM_LST_BRANCH_CAND, xlIMEModeHiragana, True
    ApplyValidationList ws.Range(CELL_PERSON), NM_LST_PERSON_CAND, xlIMEModeHiragana, True
    ApplyValidationInputOnly ws.Range(CELL_RELATIONSHIP), xlIMEModeHiragana
    ApplyValidationList ws.Range(CELL_ACCOUNT_TYPE), NM_LST_ACCOUNT_TYPE, xlIMEModeHiragana, True
    ApplyValidationInputOnly ws.Range(CELL_ACCOUNT_NO), xlIMEModeOff
    ApplyValidationInputOnly ws.Range(CELL_OPEN_DATE), xlIMEModeOff
    ApplyValidationInputOnly ws.Range(CELL_CLOSE_DATE), xlIMEModeOff
    memoCol = BalanceMemoCol(ws)
    If memoCol > BAL_FIRST_COL Then ApplyValidationInputOnly ws.Range(ws.Cells(BAL_VALUE_ROW, BAL_FIRST_COL), ws.Cells(BAL_VALUE_ROW, memoCol - 1)), xlIMEModeOff
    ApplyValidationInputOnly ws.Cells(BAL_VALUE_ROW, memoCol), xlIMEModeHiragana
    ApplyValidationInputOnly ws.Range(ws.Cells(TX_FIRST_ROW, COL_TX_YEAR), ws.Cells(InputLastTransactionRow(), COL_TX_DEPOSIT)), xlIMEModeOff
    ApplyValidationInputOnly ws.Range(ws.Cells(TX_FIRST_ROW, COL_TX_SHOP), ws.Cells(InputLastTransactionRow(), COL_TX_MACHINE)), xlIMEModeOff
    ApplyValidationList ws.Range(ws.Cells(TX_FIRST_ROW, COL_TX_TEKIYO), ws.Cells(InputLastTransactionRow(), COL_TX_TEKIYO)), NM_LST_TEKIYO, xlIMEModeHiragana, True
    ApplyValidationInputOnly ws.Range(ws.Cells(TX_FIRST_ROW, COL_TX_OTHER), ws.Cells(InputLastTransactionRow(), COL_TX_OTHER)), xlIMEModeHiragana
    ApplyValidationList GetCfgCell(ROW_CFG_INPUT_MODE), NM_LST_INPUT_MODE, xlIMEModeOff, False
    ApplyValidationList GetCfgCell(ROW_CFG_YEAR_MODE), NM_LST_YEAR_MODE, xlIMEModeOff, False
    ApplyValidationList GetCfgCell(ROW_CFG_RELATIONSHIP), NM_LST_DISPLAY_OPTION, xlIMEModeOff, False
    ApplyValidationList GetCfgCell(ROW_CFG_SHOW_INHERITANCE_ROW), NM_LST_DISPLAY_OPTION, xlIMEModeOff, False
    ApplyValidationList GetCfgCell(ROW_CFG_SHOW_OPEN_DATE_ROW), NM_LST_DISPLAY_OPTION, xlIMEModeOff, False
    ApplyValidationList GetCfgCell(ROW_CFG_SHOW_CLOSE_DATE_ROW), NM_LST_DISPLAY_OPTION, xlIMEModeOff, False
    ApplyValidationList GetCfgCell(ROW_CFG_SHOW_BALANCE_ROWS), NM_LST_DISPLAY_OPTION, xlIMEModeOff, False
    ws.Range(CELL_ACCOUNT_NO).NumberFormatLocal = "@"
    '�J�ݓ��E�����͓��͕⏕�Ŏ����t�ɐ��K�����邽�߁A�\���͓��t�`���ɌŒ肷��B
    '�����񏑎��ɖ߂��ƁA����������ɓ��t�V���A���l�������鋰�ꂪ����B
    ws.Range(CELL_OPEN_DATE).NumberFormatLocal = "yyyy/m/d"
    ws.Range(CELL_CLOSE_DATE).NumberFormatLocal = "yyyy/m/d"
    ws.Range(ws.Cells(TX_FIRST_ROW, COL_TX_TIME), ws.Cells(InputLastTransactionRow(), COL_TX_TIME)).NumberFormatLocal = "@"
    ws.Range(ws.Cells(TX_FIRST_ROW, COL_TX_SHOP), ws.Cells(InputLastTransactionRow(), COL_TX_OTHER)).NumberFormatLocal = "@"
    ResetTransactionAmountFormatting
    ws.Cells.Locked = True
    UnlockRange ws.Range(CELL_BANK)
    UnlockRange ws.Range(CELL_BRANCH)
    UnlockRange ws.Range(CELL_PERSON)
    ApplyRelationshipInput ws
    UnlockRange ws.Range(CELL_ACCOUNT_TYPE)
    UnlockRange ws.Range(CELL_ACCOUNT_NO)
    UnlockRange ws.Range(CELL_OPEN_DATE)
    UnlockRange ws.Range(CELL_CLOSE_DATE)
    If memoCol > BAL_FIRST_COL Then UnlockRange ws.Range(ws.Cells(BAL_VALUE_ROW, BAL_FIRST_COL), ws.Cells(BAL_VALUE_ROW, memoCol - 1))
    UnlockRange ws.Cells(BAL_VALUE_ROW, memoCol)
    ApplyBalanceAvailability ws
    UnlockTransactionInputCells ws
    ProtectInputSheet
    EnableInputKeys

    Exit Sub
EH:
    ProtectInputSheet
    EnableInputKeys
    Err.Raise vbObjectError + 1501, "ApplyInputSettings", "���͗��̐ݒ�Ɏ��s���܂����B" & Err.Description
End Sub

Public Sub ApplyRelationshipInput(ByVal ws As Worksheet)
    If UseRelationshipDisplay() Then
        UnlockRange ws.Range(CELL_RELATIONSHIP)
        ws.Range(CELL_RELATIONSHIP).Interior.Color = RGB(248, 250, 252)
        ws.Range(CELL_RELATIONSHIP).Font.Color = RGB(15, 23, 42)
    Else
        ws.Range(CELL_RELATIONSHIP).Locked = True
        ws.Range(CELL_RELATIONSHIP).Interior.Color = RGB(226, 232, 240)
        ws.Range(CELL_RELATIONSHIP).Font.Color = RGB(148, 163, 184)
    End If
End Sub

Private Sub UnlockTransactionInputCells(ByVal ws As Worksheet)
    Dim modeText As String
    If ws Is Nothing Then Exit Sub
    modeText = GetInputMode()

    '�N�E����2�s�ڈȍ~�������ł���悤�Ƀ��b�N��������B
    '�������ʏ��Tab���[�g�ɂ͓��ꂸ�A���i�̘A�����͂́u���v����n�܂�B
    UnlockRange ws.Range(ws.Cells(TX_FIRST_ROW, COL_TX_YEAR), ws.Cells(InputLastTransactionRow(), COL_TX_MONTH))

    '�ʏ���͂Œʂ������ח��B
    UnlockRange ws.Range(ws.Cells(TX_FIRST_ROW, COL_TX_DAY), ws.Cells(InputLastTransactionRow(), COL_TX_DEPOSIT))
    UnlockRange ws.Range(ws.Cells(TX_FIRST_ROW, COL_TX_SHOP), ws.Cells(InputLastTransactionRow(), COL_TX_TEKIYO))

    '���̑���́A�ʏ�Tab���[�g�ł͔�΂����A�N���b�N�E���L�[�ł͓��͂ł���悤��Ƀ��b�N��������B
    '�C�ɂȂ���������������͒��ɒ��ڏ�����悤�ɂ��邽�߁B
    UnlockRange ws.Range(ws.Cells(TX_FIRST_ROW, COL_TX_OTHER), ws.Cells(InputLastTransactionRow(), COL_TX_OTHER))
End Sub

Public Sub ProtectInputSheet()
    On Error Resume Next
    If Not SheetExists(SH_INPUT) Then Exit Sub
    With ThisWorkbook.Worksheets(SH_INPUT)
        .Unprotect Password:=TOOL_PASSWORD
        '���̓Z���͕ҏW�\�A�}�`�{�^���̓N���b�N���s�̂݉\�ɂ��A��h���b�O��E�N���b�N�ҏW��h���B
        LockToolShapes ThisWorkbook.Worksheets(SH_INPUT)
        .Protect Password:=TOOL_PASSWORD, DrawingObjects:=True, Contents:=True, Scenarios:=False, _
                 UserInterfaceOnly:=True, AllowFiltering:=True, AllowFormattingCells:=False, _
                 AllowFormattingColumns:=False, AllowFormattingRows:=False
        .EnableSelection = xlUnlockedCells
    End With
    On Error GoTo 0
End Sub



Public Sub GoInputSheet()
    If Not SheetExists(SH_INPUT) Then Exit Sub
    ThisWorkbook.Worksheets(SH_INPUT).Visible = xlSheetVisible
    SafeSelectCell GetSheet(SH_INPUT), CELL_BANK
    HideDailySheets False
End Sub

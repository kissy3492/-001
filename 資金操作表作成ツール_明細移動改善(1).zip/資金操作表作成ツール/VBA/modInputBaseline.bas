Attribute VB_Name = "modInputBaseline"
Option Explicit

Public Function EmptyAccountBaseline() As Variant
    Dim data(1 To 1, 1 To 10) As Variant
    EmptyAccountBaseline = data
End Function

Public Function EmptyBalanceBaseline() As Variant
    Dim data(1 To 1, 1 To 3) As Variant
    data(1, 1) = "���": data(1, 2) = "���o��": data(1, 3) = "�J�n�l"
    EmptyBalanceBaseline = data
End Function

Public Function StateAccountBaseline(ByVal state As Collection) As Variant
    StateAccountBaseline = EmptyAccountBaseline()
    On Error Resume Next
    StateAccountBaseline = state("accountBase")
    On Error GoTo 0
End Function

Public Function StateBalanceBaseline(ByVal state As Collection) As Variant
    StateBalanceBaseline = EmptyBalanceBaseline()
    On Error Resume Next
    StateBalanceBaseline = state("balanceBase")
    On Error GoTo 0
End Function

Public Function CurrentBalanceBaseline() As Variant
    Dim ws As Worksheet, count As Long
    Set ws = GetSheet(SH_INPUT)
    count = CLng(Val(CellText(ws.Range("AA2").Value2)))
    If count < 1 Then CurrentBalanceBaseline = EmptyBalanceBaseline(): Exit Function
    CurrentBalanceBaseline = ws.Range("AA4").Resize(count, 3).Value2
End Function

Public Sub WriteInputBaseline(ByVal account As Variant, ByVal balances As Variant)
    Dim ws As Worksheet, oldCount As Long, count As Long
    Set ws = GetSheet(SH_INPUT)
    oldCount = CLng(Val(CellText(ws.Range("AA2").Value2)))
    count = UBound(balances, 1)
    ws.Range("AA1:AJ1").NumberFormat = "@": ws.Range("AA1:AJ1").Value2 = account
    ws.Range("AA4").Resize(count, 3).NumberFormat = "@"
    ws.Range("AA4").Resize(count, 3).Value2 = balances
    If oldCount > count Then ws.Range("AA4").Offset(count).Resize(oldCount - count, 3).ClearContents
    ws.Range("AA2").Value2 = count
    ws.Columns("AA:AJ").Hidden = True
End Sub

Public Function AccountDataRow(ByVal data As Variant, ByVal id As String) As Variant
    Dim row As Variant, r As Long, c As Long
    row = EmptyAccountBaseline()
    For r = 2 To UBound(data, 1)
        If CellText(data(r, 1)) = id Then
            For c = 1 To 10: row(1, c) = data(r, c): Next c
            Exit For
        End If
    Next r
    AccountDataRow = row
End Function

Public Function AccountBalanceBaseline(ByVal data As Variant, ByVal id As String) As Variant
    Dim result As Variant, r As Long, n As Long, emptyData As Variant, c As Long
    emptyData = EmptyBalanceBaseline()
    ReDim result(1 To UBound(data, 1), 1 To 3)
    For c = 1 To 3: result(1, c) = emptyData(1, c): Next c
    n = 1
    For r = 2 To UBound(data, 1)
        If CellText(data(r, 13)) = id Then
            n = n + 1: result(n, 1) = data(r, 8): result(n, 2) = data(r, 9): result(n, 3) = data(r, 10)
        End If
    Next r
    AccountBalanceBaseline = FitStoreRows(result, n)
End Function

Public Function AccountDateEditValue(ByVal cell As Range) As Variant
    Dim raw As Variant, typed As Variant
    raw = cell.Value2
    If cell.HasFormula Then
        If TryStoredDate(raw, typed) Then
            AccountDateEditValue = Format$(CDate(typed), "yyyy/m/d")
            Exit Function
        End If
    End If
    '�������� .Value �����t�֕ϊ��ł��Ȃ��Ă��A���͌��l������Ȃ��B
    On Error Resume Next
    typed = cell.Value
    On Error GoTo 0
    If VarType(typed) = vbDate Then
        AccountDateEditValue = Format$(CDate(typed), "yyyy/m/d")
    Else
        AccountDateEditValue = raw
        If Not IsError(raw) And Not IsNull(raw) Then
            If IsNumeric(raw) Then AccountDateEditValue = CStr(raw)
        End If
    End If
End Function

Public Function StateAccountValues(ByVal state As Collection) As Variant
    Dim result As Variant, fields As Variant, meta As Variant, c As Long
    result = EmptyAccountBaseline(): fields = state("fields"): meta = state("metadata")
    result(1, 1) = meta(1, 1)
    For c = 2 To 9: result(1, c) = fields(c - 2): Next c
    result(1, 10) = meta(4, 1)
    StateAccountValues = result
End Function

Public Function AccountFieldEqual(ByVal a As Variant, ByVal b As Variant, ByVal field As Long) As Boolean
    Dim leftDate As Variant, rightDate As Variant, leftOK As Boolean, rightOK As Boolean
    If SameEditValue(a, b) Then AccountFieldEqual = True: Exit Function
    If field = 7 Then
        AccountFieldEqual = (NormalizeAccountHyphen(CellText(a)) = NormalizeAccountHyphen(CellText(b)))
    ElseIf field = 8 Or field = 9 Then
        If AccountDateValue(a, leftDate) And AccountDateValue(b, rightDate) Then
            AccountFieldEqual = (CDbl(CDate(leftDate)) = CDbl(CDate(rightDate)))
        End If
    End If
End Function

Public Function SameAccountIdentity(ByVal a As Variant, ByVal b As Variant) As Boolean
    Dim field As Variant
    For Each field In Array(2, 3, 6, 7)
        If Not AccountFieldEqual(a(1, CLng(field)), b(1, CLng(field)), CLng(field)) Then Exit Function
    Next field
    SameAccountIdentity = True
End Function

Public Function BalancePointRows(ByVal data As Variant) As Object
    Dim result As Object, r As Long, day As Variant
    Set result = CreateObject("Scripting.Dictionary")
    For r = 2 To UBound(data, 1)
        If TryStoredDate(data(r, 1), day) Then result(CStr(CLng(CDate(day)))) = r
    Next r
    Set BalancePointRows = result
End Function

Public Function BalancePointValue(ByVal data As Variant, ByVal rows As Object, ByVal key As String) As Variant
    If rows.Exists(key) Then BalancePointValue = data(CLng(rows(key)), 3)
End Function

Public Function DraftEditMap(ByVal parked As Variant, ByVal currentAcc As Variant, ByVal currentBal As Variant, Optional ByVal selected As Object = Nothing) As Object
    Dim result As Object, headers As Object, id As Variant, state As Collection, baseline As Variant, edited As Variant
    Dim baseBal As Variant, editBal As Variant, baseRows As Object, r As Long, c As Long, day As Variant, key As String
    Set result = CreateObject("Scripting.Dictionary"): Set headers = DraftHeaderRows(parked)
    For Each id In headers.Keys
        If Not selected Is Nothing Then
            If Not selected.Exists(id) Then GoTo NextDraftAccount
        End If
        Set state = DecodeParkedState(parked, CStr(id), GetSheet(SH_INPUT).Range("X1:X20").Value2)
        baseline = StateAccountBaseline(state): edited = StateAccountValues(state)
        If Not HasText(baseline(1, 1)) Then baseline = AccountDataRow(currentAcc, CStr(id))
        If HasText(baseline(1, 1)) Then
            For c = 2 To 10
                If Not AccountFieldEqual(edited(1, c), baseline(1, c), c) Then result(CStr(id) & "|A|" & c) = edited(1, c)
            Next c
            If Not SameAccountIdentity(edited, baseline) Then result(CStr(id) & "|I") = edited
            baseBal = StateBalanceBaseline(state)
            If Not HasText(StateAccountID(state)) Then baseBal = AccountBalanceBaseline(currentBal, CStr(id))
            editBal = state("balances"): Set baseRows = BalancePointRows(baseBal)
            For r = 2 To UBound(editBal, 1)
                If TryStoredDate(editBal(r, 1), day) Then
                    key = CStr(CLng(CDate(day)))
                    If Not BatchValueEqual(editBal(r, 3), BalancePointValue(baseBal, baseRows, key), True) Then result(CStr(id) & "|B|" & key) = editBal(r, 3)
                End If
            Next r
        End If
NextDraftAccount:
    Next id
    Set DraftEditMap = result
End Function

Private Function StateAccountID(ByVal state As Collection) As String
    Dim baseline As Variant
    baseline = StateAccountBaseline(state): StateAccountID = CellText(baseline(1, 1))
End Function

Public Function DraftFieldConflict(ByVal drafts As Object, ByVal id As String, ByVal field As Long, ByVal dateKey As String, ByVal value As Variant, ByVal money As Boolean) As Boolean
    Dim key As String
    If money Then key = id & "|B|" & dateKey Else key = id & "|A|" & field
    If drafts.Exists(key) Then
        If money Then
            DraftFieldConflict = Not BatchValueEqual(drafts(key), value, True)
        Else
            DraftFieldConflict = Not AccountFieldEqual(drafts(key), value, field)
        End If
    End If
End Function

Public Function RebaseAccountState(ByVal state As Collection, ByVal oldAcc As Variant, ByVal nextAcc As Variant, ByVal oldBal As Variant, ByVal nextBal As Variant) As Collection
    Dim result As New Collection, baseline As Variant, edited As Variant, current As Variant, fields As Variant, meta As Variant
    Dim baseBal As Variant, editBal As Variant, currentBal As Variant, baseRows As Object, editRows As Object, currentRows As Object, keys As Object
    Dim b As Variant, e As Variant, v As Variant, key As Variant, field As Variant, c As Long, n As Long, outBal As Variant, outBase As Variant, id As String
    baseline = StateAccountBaseline(state): edited = StateAccountValues(state): id = CellText(edited(1, 1))
    If Not HasText(baseline(1, 1)) Then baseline = AccountDataRow(oldAcc, id): baseBal = AccountBalanceBaseline(oldBal, id) Else baseBal = StateBalanceBaseline(state)
    current = AccountDataRow(nextAcc, id)
    If Not HasText(current(1, 1)) Then Set RebaseAccountState = state: Exit Function
    For c = 2 To 10
        If c <> 2 And c <> 3 And c <> 6 And c <> 7 Then
            If AccountFieldEqual(edited(1, c), baseline(1, c), c) Or AccountFieldEqual(edited(1, c), current(1, c), c) Then
                edited(1, c) = current(1, c): baseline(1, c) = current(1, c)
            End If
        End If
    Next c
    If SameAccountIdentity(edited, baseline) Or SameAccountIdentity(edited, current) Then
        For Each field In Array(2, 3, 6, 7)
            c = CLng(field): edited(1, c) = current(1, c): baseline(1, c) = current(1, c)
        Next field
    End If
    edited(1, 1) = id: baseline(1, 1) = id
    editBal = state("balances"): currentBal = AccountBalanceBaseline(nextBal, id)
    Set baseRows = BalancePointRows(baseBal): Set editRows = BalancePointRows(editBal): Set currentRows = BalancePointRows(currentBal)
    Set keys = CreateObject("Scripting.Dictionary")
    For Each key In editRows.Keys: keys(key) = True: Next key
    For Each key In currentRows.Keys: keys(key) = True: Next key
    ReDim outBal(1 To keys.Count + 1, 1 To 3): ReDim outBase(1 To keys.Count + 1, 1 To 3)
    For c = 1 To 3: outBal(1, c) = editBal(1, c): outBase(1, c) = baseBal(1, c): Next c
    n = 1
    For Each key In keys.Keys
        b = BalancePointValue(baseBal, baseRows, CStr(key)): e = BalancePointValue(editBal, editRows, CStr(key))
        v = BalancePointValue(currentBal, currentRows, CStr(key))
        If BatchValueEqual(e, b, True) Or BatchValueEqual(e, v, True) Then e = v: b = v
        n = n + 1: outBal(n, 1) = CLng(key): outBase(n, 1) = CLng(key)
        If editRows.Exists(key) Then outBal(n, 2) = editBal(CLng(editRows(key)), 2) Else outBal(n, 2) = currentBal(CLng(currentRows(key)), 2)
        outBase(n, 2) = outBal(n, 2): outBal(n, 3) = e: outBase(n, 3) = b
    Next key
    fields = state("fields"): meta = state("metadata")
    For c = 2 To 9: fields(c - 2) = edited(1, c): Next c
    meta(4, 1) = edited(1, 10)
    result.Add fields, "fields": result.Add meta, "metadata": result.Add state("transactions"), "transactions"
    result.Add outBal, "balances": result.Add StateBookmark(state), "bookmark"
    result.Add baseline, "accountBase": result.Add outBase, "balanceBase"
    CopyStateInputFormulas state, result
    RebaseStateAccountFormulas state, result
    Set RebaseAccountState = result
End Function

Public Function InputAccountFieldAddress(ByVal field As Long) As String
    Dim addresses As Variant
    addresses = Array(CELL_BANK, CELL_BRANCH, CELL_PERSON, CELL_RELATIONSHIP, CELL_ACCOUNT_TYPE, CELL_ACCOUNT_NO, CELL_OPEN_DATE, CELL_CLOSE_DATE)
    If field >= 2 And field <= 9 Then InputAccountFieldAddress = CStr(addresses(field - 2))
End Function

Public Sub RebaseStateAccountFormulas(ByVal before As Collection, ByVal after As Collection)
    Dim previous As Variant, current As Variant, formulas As Object, field As Long, address As String
    previous = StateAccountValues(before): current = StateAccountValues(after)
    Set formulas = StateInputFormulas(after)
    For field = 2 To 9
        address = InputAccountFieldAddress(field)
        If formulas.Exists(address) Then
            If Not AccountFieldEqual(previous(1, field), current(1, field), field) Then formulas.Remove address
        End If
    Next field
End Sub

Public Function RebaseParkedAccounts(ByVal parked As Variant, ByVal ids As Object, ByVal oldAcc As Variant, ByVal nextAcc As Variant, ByVal oldBal As Variant, ByVal nextBal As Variant) As Variant
    Dim result As Variant, headers As Object, id As Variant, state As Collection, block As Variant
    result = parked: Set headers = DraftHeaderRows(parked)
    For Each id In ids.Keys
        If headers.Exists(id) Then
            Set state = DecodeParkedState(parked, CStr(id), GetSheet(SH_INPUT).Range("X1:X20").Value2)
            Set state = RebaseAccountState(state, oldAcc, nextAcc, oldBal, nextBal)
            block = EncodeParkedState(CStr(id), state)
            result = ReplaceAccountRows(result, block, UBound(block, 1), 1, CStr(id))
        End If
    Next id
    RebaseParkedAccounts = result
End Function

Public Sub WriteInputAccountState(ByVal state As Collection)
    Dim ws As Worksheet, addresses As Variant, values As Variant, meta As Variant, c As Long, day As Variant, formulas As Object, address As String
    Set ws = GetSheet(SH_INPUT)
    ws.Unprotect Password:=TOOL_PASSWORD
    addresses = Array(CELL_BANK, CELL_BRANCH, CELL_PERSON, CELL_RELATIONSHIP, CELL_ACCOUNT_TYPE, CELL_ACCOUNT_NO, CELL_OPEN_DATE, CELL_CLOSE_DATE)
    values = state("fields"): meta = state("metadata"): Set formulas = StateInputFormulas(state)
    For c = 0 To 7
        address = ws.Range(addresses(c)).Cells(1, 1).Address(False, False)
        If formulas.Exists(address) Then
            WriteInputCellToken ws.Range(address), formulas(address)
        ElseIf c = 6 Or c = 7 Then
            WriteAccountDateInput ws.Range(addresses(c)), values(c)
        Else
            WriteInputCellToken ws.Range(addresses(c)), Array(values(c), "")
        End If
    Next c
    ws.Range(CELL_BAL_MEMO).Value2 = meta(4, 1)
    WriteStore GetSheet(SH_BAL_DRAFT), state("balances")
    WriteInputBaseline StateAccountBaseline(state), StateBalanceBaseline(state)
    '��ʂ̎c�����͎��̕`��܂œǂݖ߂��Ȃ��B
    ws.Range(CELL_BAL_RENDER).Value2 = "1"
    ResetInputFormulaTracking
End Sub


Public Function MergeInputAccountInfo(ByVal state As Collection, ByVal id As String, ByVal accounts As Variant) As Collection
    Dim result As New Collection, baseline As Variant, edited As Variant, current As Variant, accepted As Variant, display As Variant, nextBase As Variant
    Dim pending As Object, c As Long, field As Variant, value As Variant, normalized As Variant, ok As Boolean, issue As String, identityIssue As String
    Dim opened As Variant, closed As Variant, isNew As Boolean, sameBase As Boolean
    Set pending = CreateObject("Scripting.Dictionary")
    baseline = StateAccountBaseline(state): edited = StateAccountValues(state): current = AccountDataRow(accounts, id)
    isNew = Not HasText(current(1, 1))
    If Not HasText(baseline(1, 1)) And Not isNew Then baseline = current
    edited(1, 1) = id: current(1, 1) = id: baseline(1, 1) = id
    accepted = current: display = edited: nextBase = baseline
    If IsError(edited(1, 7)) Then identityIssue = "�����ԍ��̓��͂�ێ����Ă��܂�"
    If Len(identityIssue) = 0 Then edited(1, 7) = NormalizeAccountHyphen(CellText(edited(1, 7)))
    For c = 2 To 10
        value = edited(1, c): issue = ""
        If AccountFieldEqual(value, baseline(1, c), c) And Not isNew Then
            value = current(1, c)
        ElseIf Not isNew And Not AccountFieldEqual(current(1, c), baseline(1, c), c) And Not AccountFieldEqual(current(1, c), value, c) Then
            issue = "�����������ڂ�ʑ���ł��ύX�������߁A���̓��͂�ێ����Ă��܂�"
        ElseIf IsError(value) Then
            issue = "�Z���̃G���[������������ڂ�ێ����Ă��܂�"
        ElseIf (c = 2 Or c = 4 Or c = 6 Or c = 7) And Not HasText(value) Then
            issue = "��s���E�����E�ȖځE�����ԍ��̕s���������͂�ێ����Ă��܂�"
        ElseIf c = 8 Or c = 9 Then
            If AccountFieldEqual(value, current(1, c), c) Then
                value = current(1, c)
            Else
                normalized = ParseOptionalAccountDate(value, ok)
                If ok Then value = normalized Else issue = IIf(c = 8, "�J�ݓ�", "����") & "�͖����f�ł��B���͂͂��̂܂ܕێ����Ă��܂�"
            End If
        End If
        If Len(issue) > 0 Then
            pending(CStr(c)) = issue
            If c = 2 Or c = 3 Or c = 6 Or c = 7 Then identityIssue = issue
        Else
            accepted(1, c) = value: display(1, c) = value: nextBase(1, c) = value
        End If
    Next c
    If Not SameAccountIdentity(edited, baseline) And Not isNew Then
        If Not SameAccountIdentity(current, baseline) And Not SameAccountIdentity(edited, current) Then identityIssue = "��s�E�x�X�E�ȖځE�ԍ���ʑ���ł��ύX�������߁A����̑g������ێ����Ă��܂�"
    End If
    If Len(identityIssue) = 0 And Not SameAccountIdentity(accepted, current) Then
        If Len(DuplicateAccountID(CellText(accepted(1, 2)), CellText(accepted(1, 3)), CellText(accepted(1, 6)), CellText(accepted(1, 7)), id)) > 0 Then identityIssue = "������s�E�x�X�E�ȖځE�ԍ��̌��������邽�߁A����̑g������ێ����Ă��܂�"
    End If
    If Len(identityIssue) > 0 Then
        For Each field In Array(2, 3, 6, 7)
            c = CLng(field): accepted(1, c) = current(1, c): display(1, c) = edited(1, c): nextBase(1, c) = baseline(1, c)
            pending(CStr(c)) = identityIssue
        Next field
    End If
    If isNew Then
        If Len(identityIssue) > 0 Or pending.Exists("4") Then Err.Raise vbObjectError + 2320, , "�V���������͋�s���E�����E�ȖځE�����ԍ����w�肵�Ă��������B�d�������͓o�^��������J���܂��B���͓r���̂܂ܕۑ��ł��܂��B"
    End If
    If AccountDateValue(accepted(1, 8), opened) And AccountDateValue(accepted(1, 9), closed) Then
        If CDate(opened) > CDate(closed) Then
            For c = 8 To 9
                If Not AccountFieldEqual(accepted(1, c), current(1, c), c) Then
                    accepted(1, c) = current(1, c): display(1, c) = edited(1, c): nextBase(1, c) = baseline(1, c)
                    pending(CStr(c)) = "�J�ݓ��E�����̑O��֌W���������Ȃ����߁A���̕ύX��ێ����Ă��܂�"
                End If
            Next c
        End If
    End If
    result.Add accepted, "values": result.Add display, "display": result.Add nextBase, "baseline": result.Add pending, "pending"
    Set MergeInputAccountInfo = result
End Function

Private Function ParseOptionalAccountDate(ByVal value As Variant, ByRef ok As Boolean) As Variant
    On Error GoTo Invalid
    ParseOptionalAccountDate = ResolveAccountDateInput(value, ok)
    Exit Function
Invalid:
    ok = False
End Function

Public Function MergeInputBalanceInfo(ByVal state As Collection, ByVal id As String, ByVal balances As Variant) As Collection
    Dim result As New Collection, baseline As Variant, edited As Variant, current As Variant, accepted As Variant, display As Variant, nextBase As Variant
    Dim bRows As Object, eRows As Object, cRows As Object, keys As Object, pending As Object, key As Variant, row As Long, n As Long, c As Long
    Dim b As Variant, e As Variant, v As Variant, value As Variant, parsed As Variant, ok As Boolean, conflict As Boolean
    baseline = StateBalanceBaseline(state): edited = state("balances"): current = AccountBalanceBaseline(balances, id)
    If Len(StateAccountID(state)) = 0 Then baseline = current
    Set bRows = BalancePointRows(baseline): Set eRows = BalancePointRows(edited): Set cRows = BalancePointRows(current)
    Set keys = CreateObject("Scripting.Dictionary"): Set pending = CreateObject("Scripting.Dictionary")
    For Each key In eRows.Keys: keys(key) = True: Next key
    For Each key In cRows.Keys: keys(key) = True: Next key
    ReDim accepted(1 To keys.Count + 1, 1 To 3): ReDim display(1 To keys.Count + 1, 1 To 3): ReDim nextBase(1 To keys.Count + 1, 1 To 3)
    For c = 1 To 3: accepted(1, c) = edited(1, c): display(1, c) = edited(1, c): nextBase(1, c) = edited(1, c): Next c
    n = 1
    For Each key In keys.Keys
        b = BalancePointValue(baseline, bRows, CStr(key)): e = BalancePointValue(edited, eRows, CStr(key)): v = BalancePointValue(current, cRows, CStr(key))
        '���̑���ő��������\���̓��t�͍폜���Ȃ��B
        If Not eRows.Exists(key) Then e = b
        value = MergeBatchValue(b, v, e, True, conflict)
        parsed = ParseMoney(value, True, ok)
        If Not ok Then conflict = True
        If conflict Then
            value = v: pending(CStr(key)) = "�c���̓��͖͂����f�ł�"
        Else
            value = parsed: e = value: b = value
        End If
        n = n + 1
        accepted(n, 1) = CLng(key): display(n, 1) = CLng(key): nextBase(n, 1) = CLng(key)
        If eRows.Exists(key) Then accepted(n, 2) = edited(CLng(eRows(key)), 2) Else accepted(n, 2) = current(CLng(cRows(key)), 2)
        display(n, 2) = accepted(n, 2): nextBase(n, 2) = accepted(n, 2)
        accepted(n, 3) = value: display(n, 3) = e: nextBase(n, 3) = b
    Next key
    result.Add accepted, "values": result.Add display, "display": result.Add nextBase, "baseline": result.Add pending, "pending"
    Set MergeInputBalanceInfo = result
End Function

Public Function TransferInputState(ByVal before As Collection, ByVal id As String, ByVal accountResult As Collection, ByVal balanceResult As Collection, ByVal transactions As Variant, ByVal hasPending As Boolean) As Collection
    Dim state As New Collection, fields As Variant, meta As Variant, info As Variant, c As Long
    info = accountResult("display"): fields = before("fields"): meta = before("metadata")
    For c = 2 To 9: fields(c - 2) = info(1, c): Next c
    meta(1, 1) = id: meta(2, 1) = IIf(hasPending, "1", "0"): meta(4, 1) = info(1, 10)
    state.Add fields, "fields": state.Add meta, "metadata": state.Add transactions, "transactions"
    state.Add balanceResult("display"), "balances": state.Add StateBookmark(before), "bookmark"
    state.Add accountResult("baseline"), "accountBase": state.Add balanceResult("baseline"), "balanceBase"
    CopyStateInputFormulas before, state
    Set TransferInputState = state
End Function


Public Function AccountDateValue(ByVal value As Variant, ByRef result As Variant) As Boolean
    Dim ok As Boolean
    On Error GoTo Invalid
    result = Empty
    If IsError(value) Or Not HasText(value) Then Exit Function
    If VarType(value) = vbDate Then
        result = CDate(value): AccountDateValue = True
    ElseIf VarType(value) = vbString Then
        result = ResolveAccountDateInput(value, ok)
        If ok And HasText(result) Then AccountDateValue = True
    ElseIf TryStoredDate(value, result) Then
        AccountDateValue = True
    End If
    Exit Function
Invalid:
    result = Empty
End Function


Public Sub AddInputConflictActions(ByVal menu As Object)
    Dim field As Long, dateKey As String
    If Not SelectedInputConflict(field, dateKey) Then Exit Sub
    AddInputMenuItem menu, "���̍��ڂ͍���̓��͂��g��", "UseSelectedInputEdit", True
    AddInputMenuItem menu, "���̍��ڂ����݂̓o�^�l�ɖ߂�", "UseSelectedRegisteredValue"
End Sub
Private Function SelectedInputConflict(ByRef field As Long, ByRef dateKey As String) As Boolean
    Dim baseline As Variant, current As Variant, edited As Variant, id As String, addresses As Variant, c As Long, ws As Worksheet
    Dim bRows As Object, cRows As Object, eRows As Object, b As Variant, e As Variant, v As Variant, value As Variant, conflict As Boolean
    If ActiveSheet.Name <> SH_INPUT Or Len(CurrentEditAccountID()) = 0 Then Exit Function
    Set ws = GetSheet(SH_INPUT)
    addresses = Array(CELL_BANK, CELL_BRANCH, CELL_PERSON, CELL_RELATIONSHIP, CELL_ACCOUNT_TYPE, CELL_ACCOUNT_NO, CELL_OPEN_DATE, CELL_CLOSE_DATE)
    For c = 0 To 7
        If Not Intersect(ActiveCell, ws.Range(addresses(c)).MergeArea) Is Nothing Then field = c + 2: Exit For
    Next c
    If ActiveCell.Row = BAL_VALUE_ROW Then
        If ActiveCell.Column = BalanceMemoCol(ws) Then
            field = 10
        ElseIf ActiveCell.Column >= BAL_FIRST_COL And ActiveCell.Column < BalanceMemoCol(ws) Then
            dateKey = CStr(CLng(ws.Cells(BAL_DATE_ROW, ActiveCell.Column).Value2))
        End If
    End If
    If field = 0 And Len(dateKey) = 0 Then Exit Function
    id = CurrentEditAccountID(): baseline = ws.Range("AA1:AJ1").Value2
    If Not HasText(baseline(1, 1)) Then Exit Function
    current = AccountDataRow(ReadStore(GetSheet(SH_ACCOUNTS), 10), id)
    If Not HasText(current(1, 1)) Then Exit Function
    If field > 0 Then
        edited = EmptyAccountBaseline()
        For c = 0 To 7: edited(1, c + 2) = ws.Range(addresses(c)).Value2: Next c
        edited(1, 8) = AccountDateEditValue(ws.Range(CELL_OPEN_DATE)): edited(1, 9) = AccountDateEditValue(ws.Range(CELL_CLOSE_DATE))
        edited(1, 10) = ws.Cells(BAL_VALUE_ROW, BalanceMemoCol(ws)).Value2
        If field = 2 Or field = 3 Or field = 6 Or field = 7 Then
            SelectedInputConflict = Not SameAccountIdentity(edited, baseline) And Not SameAccountIdentity(current, baseline) And Not SameAccountIdentity(edited, current)
        Else
            SelectedInputConflict = Not AccountFieldEqual(edited(1, field), baseline(1, field), field) And Not AccountFieldEqual(current(1, field), baseline(1, field), field) And Not AccountFieldEqual(edited(1, field), current(1, field), field)
        End If
    Else
        FlushBalancePage
        baseline = CurrentBalanceBaseline(): edited = ReadStore(GetSheet(SH_BAL_DRAFT), 3)
        current = AccountBalanceBaseline(ReadStore(GetSheet(SH_WORK_BAL), 13), id)
        Set bRows = BalancePointRows(baseline): Set eRows = BalancePointRows(edited): Set cRows = BalancePointRows(current)
        b = BalancePointValue(baseline, bRows, dateKey): e = BalancePointValue(edited, eRows, dateKey): v = BalancePointValue(current, cRows, dateKey)
        value = MergeBatchValue(b, v, e, True, conflict): SelectedInputConflict = conflict
    End If
End Function
Public Sub UseSelectedInputEdit()
    ResolveSelectedInputConflict True
End Sub

Public Sub UseSelectedRegisteredValue()
    ResolveSelectedInputConflict False
End Sub

Private Sub ResolveSelectedInputConflict(ByVal useEdited As Boolean)
    Dim field As Long, dateKey As String, id As String, before As Collection, state As New Collection, baseline As Variant, balBase As Variant
    Dim edited As Variant, balances As Variant, current As Variant, currentBal As Variant, bRows As Object, eRows As Object, cRows As Object
    Dim formulas As Object, addresses As Variant, address As String
    Dim fields As Variant, meta As Variant, c As Variant, value As Variant, block As Variant, data As Variant, r As Long, started As Boolean, writing As Boolean, message As String
    On Error GoTo EH
    If Not SelectedInputConflict(field, dateKey) Then Exit Sub
    Set before = CaptureInputState(): id = CurrentEditAccountID(): baseline = StateAccountBaseline(before): edited = StateAccountValues(before)
    balBase = StateBalanceBaseline(before): balances = before("balances")
    current = AccountDataRow(ReadStore(GetSheet(SH_ACCOUNTS), 10), id)
    If field > 0 Then
        If field = 2 Or field = 3 Or field = 6 Or field = 7 Then
            For Each c In Array(2, 3, 6, 7)
                baseline(1, CLng(c)) = current(1, CLng(c))
                If Not useEdited Then edited(1, CLng(c)) = current(1, CLng(c))
            Next c
        Else
            baseline(1, field) = current(1, field)
            If Not useEdited Then edited(1, field) = current(1, field)
        End If
    Else
        currentBal = AccountBalanceBaseline(ReadStore(GetSheet(SH_WORK_BAL), 13), id)
        Set bRows = BalancePointRows(balBase): Set eRows = BalancePointRows(balances): Set cRows = BalancePointRows(currentBal)
        value = BalancePointValue(currentBal, cRows, dateKey)
        If bRows.Exists(dateKey) Then
            balBase(CLng(bRows(dateKey)), 3) = value
        Else
            ReDim data(1 To UBound(balBase, 1) + 1, 1 To 3)
            For r = 1 To UBound(balBase, 1): For Each c In Array(1, 2, 3): data(r, CLng(c)) = balBase(r, CLng(c)): Next c: Next r
            r = UBound(data, 1): data(r, 1) = CLng(dateKey): data(r, 3) = value: balBase = data
        End If
        If Not useEdited And eRows.Exists(dateKey) Then balances(CLng(eRows(dateKey)), 3) = value
    End If
    fields = before("fields"): meta = before("metadata")
    For Each c In Array(2, 3, 4, 5, 6, 7, 8, 9): fields(CLng(c) - 2) = edited(1, CLng(c)): Next c
    meta(4, 1) = edited(1, 10)
    state.Add fields, "fields": state.Add meta, "metadata": state.Add before("transactions"), "transactions"
    CopyStateInputFormulas before, state
    If Not useEdited And field > 0 Then
        Set formulas = StateInputFormulas(state)
        addresses = Array(CELL_BANK, CELL_BRANCH, CELL_PERSON, CELL_RELATIONSHIP, CELL_ACCOUNT_TYPE, CELL_ACCOUNT_NO, CELL_OPEN_DATE, CELL_CLOSE_DATE)
        For Each c In Array(2, 3, 4, 5, 6, 7, 8, 9)
            If CLng(c) = field Or ((field = 2 Or field = 3 Or field = 6 Or field = 7) And (CLng(c) = 2 Or CLng(c) = 3 Or CLng(c) = 6 Or CLng(c) = 7)) Then
                address = GetSheet(SH_INPUT).Range(addresses(CLng(c) - 2)).Cells(1, 1).Address(False, False)
                If formulas.Exists(address) Then formulas.Remove address
            End If
        Next c
    End If
    state.Add balances, "balances": state.Add StateBookmark(before), "bookmark": state.Add baseline, "accountBase": state.Add balBase, "balanceBase"
    AppBegin: started = True: writing = True
    WriteInputAccountState state
    MarkInputDirty GetSheet(SH_INPUT).Range(CELL_ACCOUNT_NO)
    writing = False
    ClearInputUndo
    RenderBalancePage: ProtectInputSheet
    SetInputStatus "�I�񂾒l����͗��ɕێ����܂����B�u�����𔽉f�v�œo�^�ł��܂��B"
    EndAppScope started
    Exit Sub
EH:
    message = Err.Description
    On Error Resume Next
    If writing Then RestoreInputState before
    ProtectInputSheet: EndAppScope started
    On Error GoTo 0
    MsgBox "���͒l��I�ׂ܂���ł����B" & message, vbExclamation
End Sub

Attribute VB_Name = "modBuildOutputs"
Option Explicit

Public Sub BuildAllOutputSheets()
    Dim appStarted As Boolean
    If Not RequireToolReady() Then Exit Sub

    On Error GoTo EH
    AppBegin "���[���쐬���Ă��܂�..."
    appStarted = True
    EnsureCurrentOutputs
    GetSheet(SH_OUTPUT_TX).Activate
    FreezeCashReport GetSheet(SH_OUTPUT_TX)
    EndAppScope appStarted
    Exit Sub
EH:
    Dim originalErrorText As String
    originalErrorText = Err.Description
    EndAppScope appStarted
    MsgBox "���[���쐬�ł��܂���ł����B" & vbCrLf & originalErrorText, vbExclamation
End Sub

Public Sub RefreshAllOutputs(Optional ByVal cashOnly As Boolean = False)
    Dim originals As New Collection, snapshots As New Collection, ws As Worksheet, snapshot As Collection
    Dim names As Variant, name As Variant, i As Long, filters As Collection
    Dim started As Boolean, writing As Boolean, message As String, restoring As String, committed As Boolean
    On Error GoTo EH
    AppBegin "���[���X�V���Ă��܂�...": started = True
    EnsureAccountStore
    CaptureAnalysisPanelInputs
    Set filters = CaptureCashFilters(GetSheet(SH_OUTPUT_TX))
    If cashOnly Then names = Array(SH_OUTPUT_TX, SH_SHOP_TARGET) Else names = Array(SH_OUTPUT_TX, SH_SHOP_TARGET, SH_OUTPUT_BAL)
    For Each name In names
        Set ws = GetSheet(CStr(name)): originals.Add ws
        snapshots.Add CaptureOutputSnapshot(ws)
    Next name
    '�V�[�g�̓��ꐫ��ۂB�g�̍s�����Ɋm�ۂ��A�Đ����ōs��}�����Ȃ��B
    writing = True
    BuildCashOperationSheetCore False, originals(1), False, ANALYSIS_PANEL_ROWS + 1
    AttachAnalysisPanel originals(1)
    RestoreCashFilters originals(1), filters
    BuildShopConversionTargetSheetCore False, originals(1), originals(2)
    ApplyShopNamesToOutput originals(1), originals(2)
    If Not cashOnly Then BuildBalanceTransitionSheetCore False, originals(3)
    GetSheet(SH_INPUT).Range("X7").Value2 = "0"
    writing = False: committed = True
    DeleteOutputSnapshots snapshots
    HideDailySheets False
    EndAppScope started
    Exit Sub
EH:
    message = Err.Description
    On Error Resume Next
    If writing Then
        For i = snapshots.Count To 1 Step -1
            Err.Clear
            Set ws = originals(i): Set snapshot = snapshots(i)
            RestoreOutputSnapshot ws, snapshot
            If Err.Number <> 0 Then restoring = restoring & " " & ws.Name
        Next i
    End If
    If Len(restoring) = 0 Then DeleteOutputSnapshots snapshots
    HideDailySheets True
    InvalidateOutputViews cashOnly
    ResetAnalysisSelectionCache
    EndAppScope started
    On Error GoTo 0
    If committed Then
        message = message & vbCrLf & "���[�̍X�V�͊������܂����B��ʂ̍X�V�������ł��܂���ł����B"
    ElseIf Len(restoring) > 0 Then
        message = message & vbCrLf & "���[�\���̕����������F" & restoring & "�B�ޔ��V�[�g��ێ����Ă��܂��B�㏑�������ۑ��ς݃u�b�N����m�F���Ă��������B"
    Else
        message = message & vbCrLf & "�o�^�f�[�^�ƍX�V�O�̒��[��ێ����Ă��܂��B�����𒼂��čč쐬�ł��܂��B"
    End If
    Err.Raise vbObjectError + 2402, "RefreshAllOutputs", message
End Sub

Public Function CaptureOutputSnapshot(ByVal ws As Worksheet) As Collection
    Dim result As New Collection, backup As Worksheet, formulas As Object, cells As Range, cell As Range
    Dim message As String, number As Long
    Set formulas = CreateObject("Scripting.Dictionary")
    On Error Resume Next
    Set cells = ws.Cells.SpecialCells(xlCellTypeFormulas)
    On Error GoTo EH
    If Not cells Is Nothing Then
        For Each cell In cells.Cells: formulas(cell.Address(False, False)) = InputCellToken(cell): Next cell
    End If
    result.Add formulas, "formulas"
    result.Add CaptureCashFilters(ws), "filters"
    If ws.AutoFilterMode Then result.Add ws.AutoFilter.Range.Address, "filterRange" Else result.Add "", "filterRange"
    result.Add ws.Visible, "visibility": result.Add ws.ScrollArea, "scrollArea"
    ws.Copy After:=ThisWorkbook.Sheets(ThisWorkbook.Sheets.Count)
    Set backup = ThisWorkbook.Worksheets(ThisWorkbook.Worksheets.Count)
    result.Add backup, "sheet"
    GetSheet(SH_INPUT).Activate: backup.Visible = xlSheetVeryHidden
    Set CaptureOutputSnapshot = result
    Exit Function
EH:
    number = Err.Number: message = Err.Description
    On Error Resume Next
    If Not backup Is Nothing Then backup.Delete
    On Error GoTo 0
    Err.Raise number, "CaptureOutputSnapshot", message
End Function

Public Sub DeleteOutputSnapshots(ByVal snapshots As Collection)
    Dim snapshot As Collection, backup As Worksheet
    On Error Resume Next
    GetSheet(SH_INPUT).Activate
    For Each snapshot In snapshots
        Set backup = snapshot("sheet"): backup.Visible = xlSheetVeryHidden: backup.Delete
    Next snapshot
    Application.CutCopyMode = False
    On Error GoTo 0
End Sub

Public Sub RestoreOutputSnapshot(ByVal ws As Worksheet, ByVal snapshot As Collection)
    Dim backup As Worksheet, formulas As Object, key As Variant, last As Long, previousLast As Long, c As Long
    Dim shape As Shape, added As Shape, filters As Collection, item As Object, target As Range
    Set backup = snapshot("sheet"): Set formulas = snapshot("formulas")
    last = Application.Max(1, LastUsedRowInSheet(backup))
    '�戵�X�̓��͋K���̓f�[�^�s����ɂ��p�ӂ��Ă���B
    If ws.Name = SH_SHOP_TARGET Then last = Application.Max(last, 1000)
    previousLast = Application.Max(last, LastUsedRowInSheet(ws))
    ws.Unprotect Password:=TOOL_PASSWORD: backup.Unprotect Password:=TOOL_PASSWORD
    ws.ScrollArea = ""
    If ws.AutoFilterMode Then ws.AutoFilterMode = False
    DeleteToolShapes ws, True
    ws.Cells.UnMerge: ws.Cells.Clear
    ws.Rows("1:" & previousLast).Hidden = False
    backup.Range("A1:T" & last).Copy
    ws.Range("A1").PasteSpecial Paste:=xlPasteAll
    '�V�[�g�R�s�[�����ȎQ�Ǝ������������Ă��A���̎������̂܂ܖ߂��B
    For Each key In formulas.Keys: WriteInputCellToken ws.Range(CStr(key)), formulas(key): Next key
    For c = 1 To 20
        ws.Columns(c).ColumnWidth = backup.Columns(c).ColumnWidth
        ws.Columns(c).Hidden = backup.Columns(c).Hidden
    Next c
    If Len(CStr(snapshot("filterRange"))) > 0 Then
        Set target = ws.Range(CStr(snapshot("filterRange")))
        target.AutoFilter
        Set filters = snapshot("filters")
        For Each item In filters: ApplyOutputFilter target, item: Next item
    End If
    '�t�B���^�[�̍ēK�p��ɁA�蓮�ŉB�����s���܂߂Č��̕\����Ԃ֖߂��B
    CopyOutputRowLayout backup, ws, 1, last
    ws.Visible = xlSheetVisible: backup.Visible = xlSheetVisible
    For Each shape In backup.Shapes
        backup.Activate: shape.Copy
        ws.Activate: ws.Paste
        Set added = ws.Shapes(ws.Shapes.Count)
        added.Name = shape.Name: added.Top = shape.Top: added.Left = shape.Left
        added.Width = shape.Width: added.Height = shape.Height
    Next shape
    backup.Visible = xlSheetVeryHidden
    ws.ScrollArea = CStr(snapshot("scrollArea"))
    If ws.Name = SH_SHOP_TARGET Then ProtectShopConversionTargetSheet Else ProtectGeneratedOutput ws
    GetSheet(SH_INPUT).Activate
    ws.Visible = snapshot("visibility")
    Application.CutCopyMode = False
    RestoreOutputPrintSettings backup, ws
End Sub

Private Sub CopyOutputRowLayout(ByVal source As Worksheet, ByVal target As Worksheet, ByVal first As Long, ByVal last As Long)
    Dim r As Long, start As Long, height As Double, previousHeight As Double, hidden As Boolean, previousHidden As Boolean
    start = first
    '�����s��RowHeight�́A�قȂ鍂���ł��擪�s�̒l��Ԃ��ꍇ������B
    '�����������e�s��ǂ݁A���������E�\����Ԃ̘A����Ԃ��܂Ƃ߂Ė߂��B
    For r = first To last
        hidden = source.Rows(r).Hidden
        If hidden Then source.Rows(r).Hidden = False
        height = source.Rows(r).RowHeight
        If hidden Then source.Rows(r).Hidden = True
        If r > first Then
            If height <> previousHeight Or hidden <> previousHidden Then
                target.Rows(start & ":" & r - 1).RowHeight = previousHeight
                target.Rows(start & ":" & r - 1).Hidden = previousHidden
                start = r
            End If
        End If
        previousHeight = height: previousHidden = hidden
    Next r
    target.Rows(start & ":" & last).RowHeight = previousHeight
    target.Rows(start & ":" & last).Hidden = previousHidden
End Sub

Public Sub ApplyOutputFilter(ByVal target As Range, ByVal item As Object)
    If item.Exists("first") And item.Exists("second") Then
        target.AutoFilter Field:=CLng(item("field")), Criteria1:=item("first"), Operator:=CLng(item("operator")), Criteria2:=item("second")
    ElseIf item.Exists("first") Then
        target.AutoFilter Field:=CLng(item("field")), Criteria1:=item("first"), Operator:=CLng(item("operator"))
    ElseIf item.Exists("second") Then
        target.AutoFilter Field:=CLng(item("field")), Operator:=CLng(item("operator")), Criteria2:=item("second")
    End If
End Sub

Private Sub RestoreOutputPrintSettings(ByVal source As Worksheet, ByVal target As Worksheet)
    Dim propertyName As Variant, value As Variant, ignored As Variant, pageBreak As Object, verticalBreak As Object
    Dim issue As String
    On Error Resume Next
    For Each propertyName In Array("PaperSize", "Orientation", "Zoom", "FitToPagesWide", "FitToPagesTall", "PrintArea", "PrintTitleRows", "PrintTitleColumns", "CenterHorizontally", "CenterVertically", "LeftMargin", "RightMargin", "TopMargin", "BottomMargin", "HeaderMargin", "FooterMargin", "LeftHeader", "CenterHeader", "RightHeader", "LeftFooter", "CenterFooter", "RightFooter")
        Err.Clear
        value = CallByName(source.PageSetup, CStr(propertyName), VbGet)
        If Err.Number = 0 Then ignored = CallByName(target.PageSetup, CStr(propertyName), VbLet, value)
        If Err.Number <> 0 Then issue = "����ݒ�"
    Next propertyName
    Err.Clear
    target.ResetAllPageBreaks
    For Each pageBreak In source.HPageBreaks
        If pageBreak.Type = xlPageBreakManual Then target.HPageBreaks.Add Before:=target.Cells(pageBreak.Location.Row, 1)
    Next pageBreak
    For Each verticalBreak In source.VPageBreaks
        If verticalBreak.Type = xlPageBreakManual Then target.VPageBreaks.Add Before:=target.Cells(1, verticalBreak.Location.Column)
    Next verticalBreak
    If Err.Number <> 0 Then issue = issue & " ���y�[�W"
    On Error GoTo 0
    If Len(issue) > 0 Then Err.Raise vbObjectError + 2403, "RestoreOutputPrintSettings", "���e�͕������܂������A" & issue & "�𕜌��ł��܂���ł����B"
End Sub

Public Sub BuildCashOperationSheet()
    BuildAllOutputSheets
End Sub

Public Sub BuildBalanceTransitionSheet()
    BuildAllOutputSheets
    If SheetExists(SH_OUTPUT_BAL) Then GetSheet(SH_OUTPUT_BAL).Activate
End Sub

Public Sub BuildCashOperationSheetCore(ByVal activateAfter As Boolean, Optional ByVal destination As Worksheet = Nothing, Optional ByVal includeAnalysis As Boolean = True, Optional ByVal bodyHeader As Long = 1)
    Dim src As Variant, data As Variant, ws As Worksheet, r As Long, c As Long, n As Long
    Dim kind As String, included As Boolean, inheritanceDate As Variant, kinds As Variant
    Dim id As String, filters As Collection, times As Variant, ids As Variant, grains As Object
    If destination Is Nothing And includeAnalysis Then bodyHeader = ANALYSIS_PANEL_ROWS + 1
    src = ReportSourceData(SH_WORK_TX, TX_STORE_COLS, TX_ID_COL, 6)
    If destination Is Nothing Then Set ws = GetSheet(SH_OUTPUT_TX) Else Set ws = destination
    Set filters = CaptureCashFilters(ws)
    Set grains = AnalysisTimeGrains()
    If destination Is Nothing Then CaptureAnalysisPanelInputs
    ws.Unprotect Password:=TOOL_PASSWORD
    If ws.AutoFilterMode Then ws.AutoFilterMode = False
    ws.Rows("1:" & Application.Max(ANALYSIS_PANEL_ROWS + 1, LastUsedRowInSheet(ws))).Hidden = False
    DeleteToolShapes ws, True
    ws.Cells.UnMerge: ws.Cells.Clear
    ws.Visible = xlSheetVisible
    ws.Columns("A:E").NumberFormat = "@": ws.Columns("J:M").NumberFormat = "@"
    If bodyHeader > 1 Then ws.Range("A1").Value2 = "�W�v�E�֘A���@�{"
    SetRowValues ws.Cells(bodyHeader, 1), Array("��s��", "�x�X��", "����", "�Ȗ�", "�����ԍ�", "���t", "����", "�o��", "����", "�戵�X", "�@��", "�E�v", "���̑�")
    ReDim data(1 To UBound(src, 1) + 1, 1 To 20)
    inheritanceDate = GetCfgDateValue(ROW_CFG_INHERITANCE_DATE)
    If ShowInheritanceStartRow() And IsDate(inheritanceDate) Then
        If Not ReportDateIncluded(inheritanceDate) Then inheritanceDate = Empty
    End If
    If ShowInheritanceStartRow() And IsDate(inheritanceDate) Then
        n = 1: data(n, 6) = CDbl(CDate(inheritanceDate)): data(n, 12) = "�����J�n��": data(n, 17) = "����"
    End If
    For r = 2 To UBound(src, 1)
        id = CStr(src(r, TX_ID_COL))
        kind = CStr(src(r, TX_KIND_COL)): included = True
        Select Case kind
            Case "�J��": included = ShowOpenDateRow()
            Case "���": included = ShowCloseDateRow()
            Case "�c��": included = ShowBalanceRowsInCashOperation()
        End Select
        If included Then
            n = n + 1
            For c = 1 To 13: data(n, c) = src(r, c): Next c
            data(n, 3) = DisplayPersonWithRelationship(CStr(src(r, 3)), CStr(src(r, 14)))
            data(n, 17) = kind: data(n, 18) = id
            If kind = "���" Then data(n, REPORT_UID_COL) = src(r, TX_UID_COL)
            If kind = "���" Then
                If Not HasText(data(n, 7)) Then data(n, 7) = "--:--"
            End If
        End If
    Next r
    If n > 0 Then
        Dim fitted As Variant
        ReDim fitted(1 To n, 1 To 20)
        For r = 1 To n
            For c = 1 To 20: fitted(r, c) = data(r, c): Next c
        Next r
        ws.Cells(bodyHeader + 1, 1).Resize(n, 20).Value2 = fitted
    End If
    SortCashOperation ws, bodyHeader
    FormatCashOperationOutputLayout ws, bodyHeader
    kinds = ws.Range("Q1:Q" & Application.Max(2, n + bodyHeader)).Value2
    times = ws.Range("G1:G" & Application.Max(2, n + bodyHeader)).Value2
    ids = ws.Cells(1, REPORT_UID_COL).Resize(Application.Max(2, n + bodyHeader), 1).Value2
    For r = bodyHeader + 1 To n + bodyHeader
        If IsNumeric(times(r, 1)) And HasText(times(r, 1)) Then
            ws.Cells(r, 7).NumberFormat = StoredTimeFormat(times(r, 1), RecordedTimeGrain(CellText(ids(r, 1)), times(r, 1), grains))
            If ws.Cells(r, 7).NumberFormat = "hh:mm:ss" Then ws.Columns(7).ColumnWidth = 11
        End If
        kind = CellText(kinds(r, 1))
        Select Case kind
            Case "�c��"
                ws.Range("A" & r & ":M" & r).Interior.Color = RGB(236, 247, 241)
                ws.Cells(r, 13).NumberFormat = "#,##0"
            Case "����"
                ws.Range("A" & r & ":M" & r).Interior.Color = RGB(255, 246, 219)
                ws.Range("A" & r & ":M" & r).Font.Bold = True
            Case "�J��", "���"
                ws.Range("A" & r & ":M" & r).Interior.Color = RGB(239, 246, 255)
        End Select
    Next r
    ws.Columns("N:P").ClearContents
    SetRowValues ws.Cells(bodyHeader, 17), Array("�s�敪", "������ID", "", "����ID")
    ws.Columns("N:T").Hidden = True
    ws.PageSetup.PrintArea = ws.Range("A" & bodyHeader & ":M" & n + bodyHeader).Address
    If ws.AutoFilterMode Then ws.AutoFilterMode = False
    ws.Range("A" & bodyHeader & ":M" & n + bodyHeader).AutoFilter
    ProtectGeneratedOutput ws
    If includeAnalysis And destination Is Nothing Then
        AttachAnalysisPanel ws
        RestoreCashFilters ws, filters
        RefreshShopRowReferences
    End If
    If activateAfter Then ws.Activate
End Sub

Public Sub SortCashOperation(ByVal ws As Worksheet, Optional ByVal header As Long = 1)
    Dim lastR As Long, r As Long, v As Variant, times As Variant, keys As Variant
    lastR = LastUsedRowInSheet(ws)
    If lastR < header + 2 Then Exit Sub
    SetRowValues ws.Cells(header, 14), Array("���͏�", "�����L��", "�����L�[")
    times = ws.Range("G" & header + 1 & ":G" & lastR).Value2
    ReDim keys(1 To lastR - header, 1 To 3)
    For r = 1 To UBound(times, 1)
        keys(r, 1) = r + header
        v = times(r, 1)
        If IsNumeric(v) And HasText(v) Then
            keys(r, 2) = 0: keys(r, 3) = CDbl(v)
        Else
            keys(r, 2) = 1: keys(r, 3) = 0
        End If
    Next r
    ws.Cells(header + 1, 14).Resize(UBound(keys, 1), 3).Value2 = keys
    With ws.Sort
        .SortFields.Clear
        .SortFields.Add Key:=ws.Range("F" & header + 1 & ":F" & lastR), Order:=xlAscending
        .SortFields.Add Key:=ws.Range("O" & header + 1 & ":O" & lastR), Order:=xlAscending
        .SortFields.Add Key:=ws.Range("P" & header + 1 & ":P" & lastR), Order:=xlAscending
        .SortFields.Add Key:=ws.Range("N" & header + 1 & ":N" & lastR), Order:=xlAscending
        .SetRange ws.Range("A" & header & ":T" & lastR): .Header = xlYes: .Apply
    End With
    ws.Range("N" & header & ":P" & lastR).ClearContents
End Sub

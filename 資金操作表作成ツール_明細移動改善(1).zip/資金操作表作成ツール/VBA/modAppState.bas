Attribute VB_Name = "modAppState"
Option Explicit
Private mDepth As Long
Private mEvents As Boolean, mScreen As Boolean, mAlerts As Boolean
Private mCalc As XlCalculation, mStatus As Variant
Private mRestorePending As Boolean, mRestoreCalc As Boolean
Private mRestoreMessage As String, mLastWarning As String

Public Sub AppBegin(Optional ByVal statusText As String = "������...", Optional ByVal manualCalculation As Boolean = True)
    Dim entered As Boolean, originalNumber As Long, originalText As String
    On Error GoTo EH
    If mDepth = 0 Then
        If mRestorePending Then
            RestoreApplicationSnapshot False

        End If
        If Not mRestorePending Then
        mEvents = Application.EnableEvents: mScreen = Application.ScreenUpdating
        mAlerts = Application.DisplayAlerts: mCalc = Application.Calculation
        mStatus = Application.StatusBar
        If VarType(mStatus) = vbString Then
            If Left$(CStr(mStatus), 7) = "�ۑ����܂����F" Or Left$(CStr(mStatus), 6) = "�o�b�N�A�b�v" Then mStatus = False
        End If
        mRestorePending = True: mRestoreCalc = False
        End If
    End If
    mDepth = mDepth + 1: entered = True
    Application.EnableEvents = False
    Application.DisplayAlerts = False
    On Error Resume Next
    Application.ScreenUpdating = False
    On Error GoTo EH
    '�蓮�v�Z�ɐ؂�ւ����Ȃ����ł́A���݂̌v�Z�����ŏ�������B
    On Error Resume Next
    If manualCalculation And mDepth = 1 And mCalc <> xlCalculationManual Then
        Err.Clear
        Application.Calculation = xlCalculationManual
        If Err.Number = 0 Then mRestoreCalc = True
    End If
    Application.StatusBar = statusText
    On Error GoTo 0
    Exit Sub
EH:
    originalNumber = Err.Number: originalText = Err.Description
    If entered Then mDepth = mDepth - 1
    If mDepth = 0 And entered Then RestoreApplicationSnapshot False
    Err.Raise originalNumber, "AppBegin", originalText
End Sub

Public Sub EndAppScope(ByRef started As Boolean)
    If Not started Then Exit Sub
    started = False
    AppEnd
End Sub

Public Function ToolAppScopeActive() As Boolean
    ToolAppScopeActive = (mDepth > 0)
End Function

Public Sub AppEnd()
    If mDepth > 0 Then mDepth = mDepth - 1
    If mDepth > 0 Then Exit Sub
    RestoreApplicationSnapshot True
    RefreshInputHistoryCommands
End Sub

Public Sub AppForceRestore()
    mDepth = 0
    RestoreApplicationSnapshot True
End Sub

Private Sub RestoreApplicationSnapshot(ByVal notifyFailure As Boolean)
    Dim attempt As Long, failed As String
    If Not mRestorePending Then Exit Sub
    '�ꎞ�I��COM�G���[�͂��̏�ōĎ��s���A���s�����ꍇ�͌��̏�Ԃ�ێ�����B
    For attempt = 1 To 2
        failed = ""
        On Error Resume Next
        Err.Clear
        If mRestoreCalc Then Application.Calculation = mCalc
        If Err.Number <> 0 Then failed = "�v�Z�����F" & Err.Description: Err.Clear
        Application.ScreenUpdating = mScreen
        If Err.Number <> 0 Then failed = failed & vbCrLf & "��ʍX�V�F" & Err.Description: Err.Clear
        Application.DisplayAlerts = mAlerts
        If Err.Number <> 0 Then failed = failed & vbCrLf & "Excel�̒ʒm�F" & Err.Description: Err.Clear
        Application.StatusBar = mStatus
        If Err.Number <> 0 Then failed = failed & vbCrLf & "��ԕ\���F" & Err.Description: Err.Clear
        Application.EnableEvents = mEvents
        If Err.Number <> 0 Then failed = failed & vbCrLf & "���̓C�x���g�F" & Err.Description: Err.Clear
        On Error GoTo 0
        If Len(failed) = 0 Then
            mRestorePending = False: mRestoreCalc = False
            mRestoreMessage = "": mLastWarning = ""
            Exit Sub
        End If
    Next attempt
    mRestoreMessage = failed
    If notifyFailure And failed <> mLastWarning Then
        mLastWarning = failed
        MsgBox "������Excel�ݒ���ꕔ�߂��܂���ł����B���̑���ōĎ��s���܂��B" & vbCrLf & failed, vbExclamation
    End If
End Sub

Attribute VB_Name = "modDataValues"
Option Explicit

Public Function TryStoredDate(ByVal value As Variant, ByRef result As Variant, Optional ByVal allowBlank As Boolean = False) As Boolean
    Dim serial As Double
    result = Empty
    If IsError(value) Or IsNull(value) Then Exit Function
    If Not HasText(value) Then TryStoredDate = allowBlank: Exit Function
    On Error GoTo InvalidDate
    If Not IsNumeric(value) Then Exit Function
    serial = CDbl(value)
    If serial < CDbl(DateSerial(1900, 1, 1)) Or serial > CDbl(DateSerial(9999, 12, 31)) Then Exit Function
    If serial <> Fix(serial) Then Exit Function
    result = CDate(serial)
    TryStoredDate = True
InvalidDate:
End Function

Public Function ImportedDate(ByVal value As Variant, ByVal location As String, Optional ByVal allowBlank As Boolean = False, Optional ByVal dayOffset As Long = 0) As Variant
    Dim shifted As Variant, parsed As Variant
    shifted = value
    If Not IsError(value) And Not IsNull(value) Then
        If HasText(value) And IsNumeric(value) Then shifted = CDbl(value) + dayOffset
    End If
    If Not TryStoredDate(shifted, parsed, allowBlank) Then
        Err.Raise vbObjectError + 2512, "ImportedDate", location & "�̓��t���m�F���Ă��������B�l�F" & ImportValueText(value)
    End If
    If HasText(parsed) Then ImportedDate = CDbl(CDate(parsed))
End Function

Private Function ImportValueText(ByVal value As Variant) As String
    If IsError(value) Then
        ImportValueText = "�Z���̃G���["
    ElseIf IsNull(value) Or IsEmpty(value) Then
        ImportValueText = "��"
    Else
        ImportValueText = Left$(CStr(value), 80)
    End If
End Function

Public Sub NormalizeImportedValues(ByRef tx As Variant, ByRef bal As Variant, ByRef cfg As Variant, ByVal dayOffset As Long)
    Dim r As Long, c As Long, ok As Boolean, parsed As Variant, location As String
    For r = 2 To UBound(tx, 1)
        location = SH_WORK_TX & " " & r & "�s��"
        For c = 1 To 14
            If IsError(tx(r, c)) Then Err.Raise vbObjectError + 2513, , location & "��" & c & "��ڂɃZ���̃G���[������܂��B"
        Next c
        tx(r, 6) = ImportedDate(tx(r, 6), location & " F��", False, dayOffset)
        parsed = NormalizeTimeInput(tx(r, 7), ok)
        If Not ok Then Err.Raise vbObjectError + 2514, , location & "�̎������m�F���Ă��������B�l�F" & ImportValueText(tx(r, 7))
        If HasText(parsed) Then tx(r, 7) = CDbl(CDate(parsed)) Else tx(r, 7) = Empty
        For c = 8 To 9
            parsed = ParseMoney(tx(r, c), False, ok)
            If Not ok Then Err.Raise vbObjectError + 2515, , location & "��" & IIf(c = 8, "�o��", "����") & "�𐮐��œ��͂��Ă��������B�l�F" & ImportValueText(tx(r, c))
            tx(r, c) = parsed
        Next c
        NormalizeTransactionAmounts tx(r, 8), tx(r, 9)
        If HasText(tx(r, 8)) And HasText(tx(r, 9)) Then Err.Raise vbObjectError + 2516, , location & "�͏o���Ɠ�����ʂ̍s�ɂ��Ă��������B"
    Next r
    For r = 2 To UBound(bal, 1)
        location = SH_WORK_BAL & " " & r & "�s��"
        For c = 1 To 12
            If IsError(bal(r, c)) Then Err.Raise vbObjectError + 2513, , location & "��" & c & "��ڂɃZ���̃G���[������܂��B"
        Next c
        bal(r, 6) = ImportedDate(bal(r, 6), location & " F��", True, dayOffset)
        bal(r, 7) = ImportedDate(bal(r, 7), location & " G��", True, dayOffset)
        bal(r, 8) = ImportedDate(bal(r, 8), location & " H��", False, dayOffset)
        parsed = ParseMoney(bal(r, 10), True, ok)
        If Not ok Or Not HasText(parsed) Then Err.Raise vbObjectError + 2517, , location & "�̎c���𐮐��œ��͂��Ă��������B�l�F" & ImportValueText(bal(r, 10))
        bal(r, 10) = parsed
    Next r
    cfg(1, 1) = ImportedDate(cfg(1, 1), SH_CONFIG & " C4", True, dayOffset)
End Sub

Public Sub SortNumericKeys(ByRef values As Variant)
    If Not IsArray(values) Then Exit Sub
    If UBound(values) <= LBound(values) Then Exit Sub
    SortNumericKeyRange values, LBound(values), UBound(values)
End Sub

Private Sub SortNumericKeyRange(ByRef values As Variant, ByVal first As Long, ByVal last As Long)
    Dim leftIndex As Long, rightIndex As Long, pivot As Double, temporary As Variant
    leftIndex = first: rightIndex = last
    pivot = CDbl(values(first + (last - first) \ 2))
    Do While leftIndex <= rightIndex
        Do While CDbl(values(leftIndex)) < pivot: leftIndex = leftIndex + 1: Loop
        Do While CDbl(values(rightIndex)) > pivot: rightIndex = rightIndex - 1: Loop
        If leftIndex <= rightIndex Then
            temporary = values(leftIndex): values(leftIndex) = values(rightIndex): values(rightIndex) = temporary
            leftIndex = leftIndex + 1: rightIndex = rightIndex - 1
        End If
    Loop
    If first < rightIndex Then SortNumericKeyRange values, first, rightIndex
    If leftIndex < last Then SortNumericKeyRange values, leftIndex, last
End Sub

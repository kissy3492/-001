Attribute VB_Name = "modTransactionIdentity"
Option Explicit

Public Const TX_UID_COL As Long = 17
Public Const TX_STORE_COLS As Long = 17
Public Const INPUT_UID_COL As Long = 12
Public Const REPORT_UID_COL As Long = 20
Private mIdentityNext As Double
Private mIdentityEnd As Double
Private mIdentitySeeded As Boolean

Public Function NewInternalID(ByVal prefix As String) As String
    Dim ws As Worksheet, reserved As Double
    If Not mIdentitySeeded Then
        ReserveExistingIdentities
        mIdentitySeeded = True
    End If
    If mIdentityNext >= mIdentityEnd Then
        Set ws = GetSheet(SH_CONFIG)
        reserved = Val(CellText(ws.Range("XFD22").Value2))
        If reserved < mIdentityEnd Then reserved = mIdentityEnd
        mIdentityNext = reserved: mIdentityEnd = reserved + 10000
        ws.Range("XFD22").Value2 = mIdentityEnd
        ws.Columns(16384).Hidden = True
    End If
    mIdentityNext = mIdentityNext + 1
    NewInternalID = prefix & Format$(mIdentityNext, "000000000000")
End Function

Public Sub EnsureTransactionIdentity()
    Dim ws As Worksheet, data As Variant, ids As Variant, r As Long, reserved As Double
    If Not SheetExists(SH_WORK_TX) Then Exit Sub
    Set ws = GetSheet(SH_WORK_TX)
    If CellText(ws.Cells(1, TX_UID_COL).Value2) = "����ID" Then Exit Sub
    data = ReadStore(ws, TX_STORE_COLS)
    reserved = Val(CellText(GetSheet(SH_CONFIG).Range("XFD22").Value2))
    For r = 2 To UBound(data, 1)
        If Left$(CellText(data(r, TX_UID_COL)), 1) = "T" Then reserved = Application.Max(reserved, Val(Mid$(CellText(data(r, TX_UID_COL)), 2)))
    Next r
    GetSheet(SH_CONFIG).Range("XFD22").Value2 = reserved
    ReDim ids(1 To UBound(data, 1), 1 To 1)
    ids(1, 1) = "����ID"
    For r = 2 To UBound(data, 1)
        ids(r, 1) = data(r, TX_UID_COL)
        If CellText(data(r, TX_KIND_COL)) = "���" And Not HasText(ids(r, 1)) Then ids(r, 1) = NewInternalID("T")
    Next r
    ws.Columns(TX_UID_COL).NumberFormat = "@"
    ws.Cells(1, TX_UID_COL).Resize(UBound(ids, 1), 1).Value2 = ids
    GetSheet(SH_INPUT).Columns(INPUT_UID_COL).Hidden = True
    GetSheet(SH_INPUT).Range("X7").Value2 = "1"
End Sub

Public Sub ClearInputTransactionIDs()
    Dim ws As Worksheet, lastID As Long
    Set ws = GetSheet(SH_INPUT)
    lastID = Application.Max(TX_FIRST_ROW, LastRow(ws, INPUT_UID_COL))
    ws.Cells(TX_FIRST_ROW, INPUT_UID_COL).Resize(lastID - TX_FIRST_ROW + 1, 1).ClearContents
    ws.Columns(INPUT_UID_COL).Hidden = True
End Sub

Public Function FindInputTransaction(ByVal uid As String) As Long
    Dim hit As Variant
    If Len(uid) = 0 Then Exit Function
    hit = Application.Match(uid, GetSheet(SH_INPUT).Columns(INPUT_UID_COL), 0)
    If Not IsError(hit) Then FindInputTransaction = CLng(hit)
End Function

Public Function FindReportTransaction(ByVal uid As String) As Long
    Dim hit As Variant
    If Len(uid) = 0 Then Exit Function
    hit = Application.Match(uid, GetSheet(SH_OUTPUT_TX).Columns(REPORT_UID_COL), 0)
    If Not IsError(hit) Then FindReportTransaction = CLng(hit)
End Function

Private Sub ReserveExistingIdentities()
    Dim reserved As Double, specification As Variant, part As Variant, data As Variant
    Dim ws As Worksheet, r As Long, c As Long, value As String, fields As Variant, field As Variant
    reserved = Val(CellText(GetSheet(SH_CONFIG).Range("XFD22").Value2))
    '�폜�ς݂̌������Q�Ƃ���r�����͂��܂߁A�����̔ԍ������\�񂷂�B
    For Each specification In Array(SH_ACCOUNTS & ":1", SH_WORK_TX & ":15,17", SH_WORK_BAL & ":13", "W_������:1,14", _
        "W_�܂Ƃߌ�����:1", "W_�܂Ƃߌ��c��:13", "W_�֘A:1,4,8,11,12", "�܂Ƃߓ���:1", "W_�l������:1,2", "W_���͉�����:1,2", "W_�o�T:1,2", SH_INPUT & ":12")
        part = Split(CStr(specification), ":")
        If SheetExists(CStr(part(0))) Then
            Set ws = GetSheet(CStr(part(0))): fields = Split(CStr(part(1)), ",")
            For Each field In fields
                c = CLng(field)
                data = ws.Cells(1, c).Resize(Application.Max(2, LastRow(ws, c)), 1).Value2
                For r = 2 To UBound(data, 1)
                    value = CellText(data(r, 1))
                    If Len(value) > 1 And InStr(1, "ANTRPUI", Left$(value, 1), vbBinaryCompare) > 0 Then
                        If IsNumeric(Mid$(value, 2)) Then reserved = Application.Max(reserved, Val(Mid$(value, 2)))
                    End If
                Next r
            Next field
        End If
    Next specification
    For Each specification In Array(CELL_EDIT_ID, CELL_DRAFT_KEY)
        value = CellText(GetSheet(SH_INPUT).Range(CStr(specification)).Value2)
        If Len(value) > 1 Then reserved = Application.Max(reserved, Val(Mid$(value, 2)))
    Next specification
    If SheetExists(SH_BATCH) Then
        value = CellText(GetSheet(SH_BATCH).Range("XFD5").Value2)
        If Len(value) > 1 Then reserved = Application.Max(reserved, Val(Mid$(value, 2)))
    End If
    GetSheet(SH_CONFIG).Range("XFD22").Value2 = reserved
End Sub

Attribute VB_Name = "modPortraitOutput"
Option Explicit

Public Sub ExportCashPortrait()
    Dim source As Worksheet, book As Workbook, ws As Worksheet, path As Variant, values As Variant
    Dim r As Long, row As Long, lastR As Long, started As Boolean, message As String, detail As String
    Dim blocks As New Collection
    Dim timeGrains As Object, ids As Variant
    On Error GoTo EH
    PauseAnalysisSearch
    EnsureCurrentOutputs
    Set source = GetSheet(SH_OUTPUT_TX)
    path = Application.GetSaveAsFilename(InitialFileName:="��������\_A4�c.xlsx", FileFilter:="Excel �u�b�N (*.xlsx), *.xlsx", Title:="���ݕ\�����̖��ׂ�A4�c�ŏo��")
    If VarType(path) = vbBoolean Then Exit Sub
    If LCase$(Right$(CStr(path), 5)) <> ".xlsx" Then path = CStr(path) & ".xlsx"
    If Len(Dir$(CStr(path))) > 0 Then
        If MsgBox("�����̃t�@�C�����㏑�����܂����H", vbYesNo + vbQuestion + vbDefaultButton2) <> vbYes Then Exit Sub
    End If
    AppBegin "A4�c�̎�������\���o�͂��Ă��܂�...": started = True
    Set book = Workbooks.Add(xlWBATWorksheet): Set ws = book.Worksheets(1): ws.Name = "��������\_A4�c"
    PreparePortraitSheet ws, "��������\", "�o�^�ς݁E���݂̕\���͈� / " & Format$(Now, "yyyy/m/d hh:mm")
    SetRowValues ws.Range("A4"), Array("���t", "����", "�E�v", "�o��", "����")
    row = 4: lastR = LastRow(source, 6)
    values = source.Range("A1:M" & Application.Max(1, lastR)).Value2
    ids = source.Cells(1, REPORT_UID_COL).Resize(Application.Max(2, lastR), 1).Value2
    Set timeGrains = AnalysisTimeGrains()
    For r = CashReportHeader(source) + 1 To lastR
        If Not source.Rows(r).Hidden Then
            blocks.Add row + 1
            row = row + 1
            ws.Cells(row, 1).Value2 = PortraitDate(values(r, 6))
            ws.Cells(row, 2).Value2 = PortraitTime(values(r, 7), RecordedTimeGrain(CellText(ids(r, 1)), values(r, 7), timeGrains))
            ws.Cells(row, 3).Value2 = Left$(CellText(values(r, 12)), 24)
            ws.Cells(row, 4).Value2 = values(r, 8): ws.Cells(row, 5).Value2 = values(r, 9)
            ws.Range("D" & row & ":E" & row).NumberFormat = "#,##0"
            ws.Rows(row).RowHeight = 33
            ws.Range("A" & row & ":E" & row).Borders(xlEdgeTop).Color = RGB(170, 184, 195)
            detail = CellText(values(r, 3)) & " / " & CellText(values(r, 1)) & " " & CellText(values(r, 2)) & " / " & CellText(values(r, 4)) & " " & CellText(values(r, 5))
            AppendPortraitText ws, row, detail
            detail = "�戵�X�F" & CellText(values(r, 10)) & " / �@�ԁF" & CellText(values(r, 11))
            If HasText(values(r, 13)) Then detail = detail & " / ���̑��F" & CellText(values(r, 13))
            AppendPortraitText ws, row, detail
            If Len(CellText(values(r, 12))) > 24 Then AppendPortraitText ws, row, "�E�v�S���F" & CellText(values(r, 12))
        End If
    Next r
    FinishPortraitSheet ws, row, blocks
    SavePortraitBook book, CStr(path): Set book = Nothing
    EndAppScope started
    AnalysisPanelMessage "A4�c�̎�������\���o�͂��܂����B"
    Exit Sub
EH:
    message = Err.Description
    On Error Resume Next
    If Not book Is Nothing Then book.Close SaveChanges:=False
    EndAppScope started
    On Error GoTo 0
    AnalysisPanelMessage "A4�c�̏o�͂������ł��܂���ł����B" & message
End Sub

Public Sub AddAnalysisPortrait(ByVal source As Worksheet)
    Dim ws As Worksheet, values As Variant, r As Long, row As Long, c As Long, detail As String, title As String
    Dim blocks As New Collection
    values = source.Range("A1:M" & LastRow(source, 2)).Value2
    Set ws = source.Parent.Worksheets.Add(After:=source): ws.Name = "A4�c"
    PreparePortraitSheet ws, "�W�v�E�֘A���", CellText(values(2, 1))
    SetRowValues ws.Range("A4"), Array("���t", "����", "�g����", CellText(values(4, 5)), CellText(values(4, 6)))
    row = 4
    For r = 5 To UBound(values, 1)
        blocks.Add row + 1
        row = row + 1
        ws.Cells(row, 1).Value2 = values(r, 3): ws.Cells(row, 2).Value2 = values(r, 4): ws.Cells(row, 3).Value2 = values(r, 1)
        ws.Cells(row, 4).Value2 = values(r, 5): ws.Cells(row, 5).Value2 = values(r, 6)
        ws.Range("D" & row & ":E" & row).NumberFormat = "#,##0": ws.Rows(row).RowHeight = 33
        ws.Range("A" & row & ":E" & row).Borders(xlEdgeTop).Color = RGB(170, 184, 195)
        AppendPortraitText ws, row, CellText(values(r, 2))
        For c = 7 To 13
            If HasText(values(r, c)) Then AppendPortraitText ws, row, CellText(values(4, c)) & "�F" & CellText(values(r, c))
        Next c
    Next r
    FinishPortraitSheet ws, row, blocks
    ws.Activate: ws.Range("A1").Select
End Sub

Private Sub PreparePortraitSheet(ByVal ws As Worksheet, ByVal title As String, ByVal subtitle As String)
    Dim widths As Variant, c As Long, ratio As Double
    widths = Array(14, 9, 25, 22, 22)
    For c = 1 To 5: ws.Columns(c).ColumnWidth = widths(c - 1): Next c
    ratio = 532 / ws.Range("A1:E1").Width
    For c = 1 To 5: ws.Columns(c).ColumnWidth = ws.Columns(c).ColumnWidth * ratio: Next c
    ws.Columns("A:E").NumberFormat = "@"
    ws.Columns("A:E").Font.Name = "Yu Gothic UI": ws.Columns("A:E").Font.Size = 11
    ws.Columns("A:E").WrapText = True: ws.Columns("A:E").VerticalAlignment = xlCenter
    ws.Range("A1:E1").Merge: ws.Range("A1").Value2 = title
    ws.Range("A1").Font.Size = 15: ws.Range("A1").Font.Bold = True: ws.Rows(1).RowHeight = 28
    ws.Range("A2:E2").Merge: ws.Range("A2").Value2 = subtitle: ws.Rows(2).RowHeight = PortraitTextHeight(subtitle)
    ws.Rows(3).RowHeight = 8
    ws.Range("A4:E4").Interior.Color = RGB(235, 241, 245): ws.Range("A4:E4").Font.Bold = True: ws.Rows(4).RowHeight = 25
    ws.Columns("D:E").HorizontalAlignment = xlRight
End Sub

Private Sub AppendPortraitText(ByVal ws As Worksheet, ByRef row As Long, ByVal text As String)
    Dim offset As Long, part As String
    If Len(text) = 0 Then Exit Sub
    offset = 1
    Do While offset <= Len(text)
        part = TakePortraitText(text, offset)
        row = row + 1
        ws.Range("A" & row & ":E" & row).Merge: ws.Cells(row, 1).Value2 = part
        ws.Rows(row).RowHeight = PortraitTextHeight(part)
        ws.Cells(row, 1).HorizontalAlignment = xlLeft
    Loop
End Sub

Private Function TakePortraitText(ByVal text As String, ByRef offset As Long) As String
    Dim first As Long, units As Long, lines As Long, nextUnits As Long, nextLines As Long, code As Long
    first = offset: lines = 1
    '�����������ŋ�؂�ƁA�����̉��s��Excel�̍s������𒴂���B
    Do While offset <= Len(text) And offset - first < 200
        code = AscW(Mid$(text, offset, 1))
        nextUnits = units: nextLines = lines
        If code = 10 Then
            nextLines = nextLines + 1: nextUnits = 0
        Else
            If code < 0 Or code > 255 Then nextUnits = nextUnits + 2 Else nextUnits = nextUnits + 1
            If nextUnits > 84 Then nextLines = nextLines + 1: nextUnits = 2
        End If
        If nextLines > 12 And offset > first Then Exit Do
        units = nextUnits: lines = nextLines: offset = offset + 1
    Loop
    TakePortraitText = Mid$(text, first, offset - first)
End Function

Private Sub FinishPortraitSheet(ByVal ws As Worksheet, ByVal last As Long, ByVal blocks As Collection)
    ws.Range("A1:E" & last).Font.Color = RGB(30, 41, 59)
    With ws.PageSetup
        .PaperSize = xlPaperA4: .Orientation = xlPortrait
        .Zoom = 100
        .LeftMargin = Application.InchesToPoints(0.36): .RightMargin = Application.InchesToPoints(0.36)
        .TopMargin = Application.InchesToPoints(0.4): .BottomMargin = Application.InchesToPoints(0.4)
        .PrintArea = ws.Range("A1:E" & last).Address: .PrintTitleRows = "$1:$4"
        .CenterFooter = "&P / &N"
    End With
    KeepPortraitBlocks ws, last, blocks
End Sub

Private Sub KeepPortraitBlocks(ByVal ws As Worksheet, ByVal last As Long, ByVal blocks As Collection)
    Dim starts() As Long, entry As Variant, i As Long, first As Long, finish As Long, row As Long
    Dim available As Double, used As Double, height As Double, rowHeight As Double, breaks As Long, text As String
    '���y�[�W�̒������g���Ȃ�Excel�ł��A�o�̓f�[�^�̕ۑ��͌p������B
    On Error GoTo AutomaticPages
    If blocks.Count = 0 Then Exit Sub
    available = Application.CentimetersToPoints(29.7) - ws.PageSetup.TopMargin - ws.PageSetup.BottomMargin - ws.Rows("1:4").Height - 12
    If available < 100 Then Exit Sub
    ReDim starts(1 To blocks.Count + 1)
    For Each entry In blocks: i = i + 1: starts(i) = CLng(entry): Next entry
    starts(blocks.Count + 1) = last + 1
    ws.ResetAllPageBreaks
    For i = 1 To blocks.Count
        first = starts(i): finish = starts(i + 1) - 1
        height = ws.Rows(first & ":" & finish).Height
        If used > 0 And used + height > available Then
            If breaks >= 1000 Then Exit Sub
            ws.HPageBreaks.Add Before:=ws.Cells(first, 1)
            breaks = breaks + 1: used = 0
        End If
        If height <= available Then
            used = used + height
        Else
            '��������y�[�W�𒴂���ꍇ�͐����s�̊Ԃŋ�؂�A�����̑Ώۂ������B
            For row = first To finish
                rowHeight = ws.Rows(row).RowHeight
                If used > 0 And used + rowHeight > available Then
                    If breaks >= 1000 Then Exit Sub
                    ws.HPageBreaks.Add Before:=ws.Cells(row, 1)
                    breaks = breaks + 1: used = 0
                    text = "�k�O�ł���̑����l" & CellText(ws.Cells(first, 1).Value2) & " / " & Left$(CellText(ws.Cells(first + 1, 1).Value2), 35)
                    text = text & vbLf & CellText(ws.Cells(row, 1).Value2)
                    ws.Cells(row, 1).Value2 = text
                    rowHeight = Application.Max(rowHeight, PortraitTextHeight(text))
                    ws.Rows(row).RowHeight = rowHeight
                End If
                used = used + rowHeight
            Next row
        End If
    Next i
AutomaticPages:
End Sub

Private Function PortraitDate(ByVal value As Variant) As String
    If IsNumeric(value) And HasText(value) Then PortraitDate = Format$(CDbl(value), "yyyy/m/d") Else PortraitDate = CellText(value)
End Function

Private Function PortraitTime(ByVal value As Variant, Optional ByVal grain As Long = 0) As String
    If Not HasText(value) Then PortraitTime = "--:--": Exit Function
    If IsNumeric(value) Then PortraitTime = PreciseInputTimeText(value, grain) Else PortraitTime = CellText(value)
End Function

Private Sub SavePortraitBook(ByVal book As Workbook, ByVal path As String)
    Dim fs As Object, stage As String, backup As String, moved As Boolean, installed As Boolean, message As String, restored As Boolean
    On Error GoTo EH
    Set fs = CreateObject("Scripting.FileSystemObject")
    stage = fs.BuildPath(fs.GetParentFolderName(path), fs.GetTempName): fs.CreateFolder stage
    backup = fs.BuildPath(stage, "previous.xlsx")
    book.SaveAs Filename:=fs.BuildPath(stage, "new.xlsx"), FileFormat:=xlOpenXMLWorkbook, CreateBackup:=False
    book.Close SaveChanges:=False
    If fs.FileExists(path) Then fs.MoveFile path, backup: moved = True
    fs.MoveFile fs.BuildPath(stage, "new.xlsx"), path: installed = True
    On Error Resume Next
    fs.DeleteFolder stage, True
    On Error GoTo 0
    Exit Sub
EH:
    message = Err.Description
    On Error Resume Next
    If moved And Not installed Then
        Err.Clear: fs.MoveFile backup, path: restored = (Err.Number = 0)
        If Not restored Then message = message & " / ���t�@�C���̑ޔ��F" & backup
    Else
        restored = True
    End If
    If Len(stage) > 0 And restored Then fs.DeleteFolder stage, True
    On Error GoTo 0
    Err.Raise vbObjectError + 3510, "SavePortraitBook", message
End Sub

Public Sub ExportNetworkConnections(ByVal book As Workbook, ByVal pathID As String, ByVal data As Variant)
    Dim ws As Worksheet, edges As Collection, edge As Object, row As Long
    Dim blocks As New Collection
    Set ws = book.Worksheets.Add(After:=book.Worksheets(book.Worksheets.Count)): ws.Name = "�o�H�̐ڑ�"
    PreparePortraitSheet ws, "�o�H�̐ڑ�", AnalysisNetworkSummary(pathID, data)
    SetRowValues ws.Range("A4"), Array("������", "�o����", "�ڑ��������", "�������z", "��o���z")
    Set edges = AnalysisPathEdges(pathID, data): row = 4
    For Each edge In edges
        blocks.Add row + 1
        row = row + 1
        ws.Cells(row, 1).Value2 = AnalysisDateText(CStr(edge("from")))
        ws.Cells(row, 2).Value2 = AnalysisDateText(CStr(edge("to")))
        ws.Cells(row, 3).Value2 = CellText(AnalysisValue(CStr(edge("from")), 3))
        ws.Cells(row, 4).Value2 = AnalysisAmount(CStr(edge("from")))
        ws.Cells(row, 5).Value2 = AnalysisAmount(CStr(edge("to")))
        ws.Range("D" & row & ":E" & row).NumberFormat = "#,##0": ws.Rows(row).RowHeight = 32
        AppendPortraitText ws, row, AnalysisAccountText(CStr(edge("from")))
        AppendPortraitText ws, row, "���� " & AnalysisTimeText(CStr(edge("from"))) & " �� �o�� " & AnalysisTimeText(CStr(edge("to"))) & " / �ڑ��z�͖��w��"
    Next edge
    FinishPortraitSheet ws, row, blocks
End Sub

Private Function PortraitTextHeight(ByVal text As String) As Double
    Dim i As Long, units As Long, lines As Long, code As Long
    lines = 1
    For i = 1 To Len(text)
        code = AscW(Mid$(text, i, 1))
        If code = 10 Then
            lines = lines + 1: units = 0
        Else
            If code < 0 Or code > 255 Then units = units + 2 Else units = units + 1
            If units > 84 Then lines = lines + 1: units = 2
        End If
    Next i
    PortraitTextHeight = Application.Min(300, Application.Max(25, lines * 16 + 5))
End Function

Public Sub ExportPairAllocations(ByVal book As Workbook, ByVal groups As Object, ByVal context As Object)
    Dim group As Variant, pairs As Collection, pair As Object, ws As Worksheet, row As Long, details As Object, count As Long
    Dim blocks As New Collection
    For Each group In groups.Keys
        Set pairs = RelationPairRows(CStr(group), False, context)
        If pairs.Count > 0 Then
            If ws Is Nothing Then
                Set ws = book.Worksheets.Add(After:=book.Worksheets(book.Worksheets.Count)): ws.Name = "�ʔz��"
                PreparePortraitSheet ws, "���p�҂��L�^�����ʔz��", "�ۑ������z���ƕҏW���̒l�B�����ׂ̕ύX���Ōv�Z�ΏۊO�ƂȂ����֘A�́A���̏�Ԃ𕹋L���Ă��܂��B"
                SetRowValues ws.Range("A4"), Array("�o����", "������", "�g����", "�ۑ������z", "���z������")
                row = 4
            End If
            Set details = RelationDetails(CStr(group), context)
            For Each pair In pairs
                If HasText(pair("amount")) Or HasText(AnalysisEditExportValue(pair)) Then
                    blocks.Add row + 1
                    count = count + 1: row = row + 1
                    ws.Cells(row, 1).Value2 = AnalysisDateText(CStr(pair("from")))
                    ws.Cells(row, 2).Value2 = AnalysisDateText(CStr(pair("to")))
                    ws.Cells(row, 3).Value2 = "�ʔz�� " & count
                    ws.Cells(row, 4).Value2 = pair("amount"): ws.Cells(row, 5).Value2 = AnalysisEditExportValue(pair)
                    ws.Range("D" & row & ":E" & row).NumberFormat = "#,##0": ws.Rows(row).RowHeight = 32
                    AppendPortraitText ws, row, "�o���F" & AnalysisAccountText(CStr(pair("from"))) & " / " & AnalysisTimeText(CStr(pair("from")))
                    AppendPortraitText ws, row, "�����F" & AnalysisAccountText(CStr(pair("to"))) & " / " & AnalysisTimeText(CStr(pair("to")))
                    AppendPortraitText ws, row, CStr(details("status")) & " / " & CStr(details("memo"))
                End If
            Next pair
        End If
    Next group
    If Not ws Is Nothing Then FinishPortraitSheet ws, row, blocks
End Sub

Attribute VB_Name = "modInputCells"
Option Explicit

'���͌����̋��ʕ\���B����������2�v�f�g�[�N�������̂܂ܓǂ߂�B
Public Function InputCellToken(ByVal cell As Range) As Variant
    Dim expression As String, relative As String, dialect As Long, probe As Variant, relativeProbe As Variant, kind As String, group As String
    If cell.HasFormula Then
        expression = CStr(cell.Formula): relative = CStr(cell.FormulaR1C1)
        On Error Resume Next
        Err.Clear
        probe = CallByName(cell, "Formula2", VbGet)
        If Err.Number = 0 Then
            relativeProbe = CallByName(cell, "Formula2R1C1", VbGet)
            If Err.Number = 0 Then
                expression = CStr(probe): relative = CStr(relativeProbe): dialect = 2
            End If
        End If
        On Error GoTo 0
    End If
    If cell.HasArray Then
        kind = "array": group = cell.CurrentArray.Address(False, False)
        expression = CStr(cell.CurrentArray.FormulaArray)
    ElseIf InputCellHasSpill(cell) Then
        kind = "spill"
    End If
    InputCellToken = Array(cell.Value2, expression, dialect, relative, kind, group)
End Function

Public Function InputTokenDialect(ByVal token As Variant) As Long
    If UBound(token) >= 2 Then InputTokenDialect = CLng(token(2))
End Function

Public Function InputValuesEqual(ByVal a As Variant, ByVal b As Variant) As Boolean
    Dim i As Long
    If IsArray(a) Or IsArray(b) Then
        If Not IsArray(a) Or Not IsArray(b) Then Exit Function
        If LBound(a) <> LBound(b) Or UBound(a) <> UBound(b) Then Exit Function
        For i = LBound(a) To UBound(a)
            If Not InputValuesEqual(a(i), b(i)) Then Exit Function
        Next i
        InputValuesEqual = True
    ElseIf IsError(a) Or IsError(b) Then
        If IsError(a) And IsError(b) Then InputValuesEqual = (CStr(a) = CStr(b))
    ElseIf IsNull(a) Or IsNull(b) Then
        InputValuesEqual = (IsNull(a) And IsNull(b))
    ElseIf IsEmpty(a) Or IsEmpty(b) Then
        InputValuesEqual = (IsEmpty(a) And IsEmpty(b))
    ElseIf VarType(a) = VarType(b) Then
        InputValuesEqual = (a = b)
    ElseIf VarType(a) <> vbString And VarType(b) <> vbString Then
        If IsNumeric(a) And IsNumeric(b) Then InputValuesEqual = (CDbl(a) = CDbl(b))
    End If
End Function

Public Function InputTokenEqual(ByVal a As Variant, ByVal b As Variant) As Boolean
    If InputTokenKind(a) <> InputTokenKind(b) Then Exit Function
    If CStr(a(1)) <> CStr(b(1)) Then Exit Function
    If Len(CStr(a(1))) > 0 Then
        InputTokenEqual = (InputTokenDialect(a) = InputTokenDialect(b))
    Else
        InputTokenEqual = InputValuesEqual(a(0), b(0))
    End If
End Function

Public Function InputValueLength(ByVal value As Variant) As Double
    Dim part As Variant
    If IsArray(value) Then
        For Each part In value: InputValueLength = InputValueLength + InputValueLength(part) + 16: Next part
    ElseIf Not IsNull(value) And Not IsEmpty(value) Then
        InputValueLength = Len(CStr(value))
    End If
End Function

Public Sub WriteInputCellToken(ByVal cell As Range, ByVal token As Variant, Optional ByVal relative As Boolean = False)
    Dim expression As String, propertyName As String, ignored As Variant, previousFormat As String
    Dim failureNumber As Long, failureSource As String, failureMessage As String
    On Error GoTo EH
    expression = CStr(token(1))
    If InputTokenKind(token) = "array" Then
        If Len(expression) > 255 Then Err.Raise vbObjectError + 3413, , "�����z�񐔎��͂��̕�������ł͈����܂���B"
        cell.Worksheet.Range(CStr(token(5))).FormulaArray = expression
        Exit Sub
    End If
    If Len(expression) > 0 Then
        previousFormat = CStr(cell.NumberFormat)
        If previousFormat = "@" Then cell.NumberFormat = "General"
        propertyName = "Formula"
        If InputTokenDialect(token) = 2 Then propertyName = "Formula2"
        If relative And UBound(token) >= 3 Then
            If Len(CStr(token(3))) > 0 Then expression = CStr(token(3)): propertyName = propertyName & "R1C1"
        End If
        If propertyName = "Formula" Then
            cell.Formula = expression
        ElseIf propertyName = "FormulaR1C1" Then
            cell.FormulaR1C1 = expression
        Else
            ignored = CallByName(cell, propertyName, VbLet, expression)
        End If
        If previousFormat = "@" Then cell.NumberFormat = previousFormat
    ElseIf IsEmpty(token(0)) Or IsNull(token(0)) Then
        If cell.MergeCells Then cell.MergeArea.ClearContents Else cell.ClearContents
    ElseIf VarType(token(0)) = vbString Then
        cell.Formula = "'" & CStr(token(0))
    Else
        cell.Value2 = token(0)
    End If
    Exit Sub
EH:
    failureNumber = Err.Number: failureSource = Err.Source: failureMessage = Err.Description
    On Error Resume Next
    If previousFormat = "@" Then cell.NumberFormat = previousFormat
    On Error GoTo 0
    Err.Raise failureNumber, failureSource, failureMessage
End Sub

Public Sub WriteInputValueBlock(ByVal target As Range, ByVal values As Variant)
    Dim safe As Variant, r As Long, c As Long
    safe = values
    For r = 1 To UBound(safe, 1)
        For c = 1 To UBound(safe, 2)
            If VarType(safe(r, c)) = vbString Then safe(r, c) = "'" & CStr(safe(r, c))
        Next c
    Next r
    target.Formula = safe
End Sub

Public Function ReadInputFormulaCells() As Object
    Dim result As Object, ws As Worksheet, body As Range, part As Range, cell As Range
    Set result = CreateObject("Scripting.Dictionary"): Set ws = GetSheet(SH_INPUT)
    Set body = Union(ws.Range("B5:K6"), ws.Range("B" & TX_FIRST_ROW & ":K" & Application.Max(TX_FIRST_ROW, LastInputDataRow())))
    On Error Resume Next
    Set part = body.SpecialCells(xlCellTypeFormulas)
    On Error GoTo 0
    If Not part Is Nothing Then
        Set part = Intersect(part, body)
        If Not part Is Nothing Then
            For Each cell In part.Cells: result(cell.Address(False, False)) = InputCellToken(cell): Next cell
        End If
    End If
    Set ReadInputFormulaCells = result
End Function

Public Function StateInputFormulas(ByVal state As Collection) As Object
    Dim result As Object
    On Error Resume Next
    Set result = state("formulas")
    On Error GoTo 0
    If result Is Nothing Then Set result = CreateObject("Scripting.Dictionary")
    Set StateInputFormulas = result
End Function

Public Sub CopyStateInputFormulas(ByVal source As Collection, ByVal target As Collection)
    Dim formulas As Object, result As Object, key As Variant
    Set formulas = StateInputFormulas(source): Set result = CreateObject("Scripting.Dictionary")
    For Each key In formulas.Keys: result(key) = formulas(key): Next key
    target.Add result, "formulas"
End Sub

Public Sub RestoreStateInputFormulas(ByVal state As Collection)
    Dim formulas As Object, key As Variant, ws As Worksheet
    Set ws = GetSheet(SH_INPUT): Set formulas = StateInputFormulas(state)
    For Each key In formulas.Keys
        If Not InputTokenEqual(InputCellToken(ws.Range(CStr(key))), formulas(key)) Then WriteInputCellToken ws.Range(CStr(key)), formulas(key)
    Next key
    ResetInputFormulaTracking
End Sub

'�z��̈ꕔ����ҏW���鑀�삾�����~�߂�B�N���E�ۑ��̓_���ɂ͎g��Ȃ��B
Public Sub RequireIndependentInputCells(ByVal target As Range)
    Dim cell As Range, part As Range, spill As Variant
    On Error Resume Next
    Set part = target.SpecialCells(xlCellTypeFormulas)
    On Error GoTo 0
    If Not part Is Nothing Then
        Set part = Intersect(target, part)
        If Not part Is Nothing Then
            For Each cell In part.Cells
                If cell.HasArray Then Err.Raise vbObjectError + 3410, , "�z�񐔎����܂ޔ͈͂ł��B���̖��ב���́A�z�񐔎����܂܂Ȃ��͈͂ōs���Ă��������B"
            Next cell
        End If
    End If
    On Error Resume Next
    Err.Clear: spill = CallByName(target, "HasSpill", VbGet)
    If Err.Number <> 0 Then spill = False
    On Error GoTo 0
    If IsNull(spill) Then Err.Raise vbObjectError + 3411, , "�z�񐔎��̓W�J����܂ނ��߁A���͈̖̔͂��ב���͍s���Ă��܂���B"
    If spill = True Then Err.Raise vbObjectError + 3411, , "�z�񐔎��̓W�J����܂ނ��߁A���͈̖̔͂��ב���͍s���Ă��܂���B"
End Sub

Public Function ReadWorkbookFormulaReferences() As Object
    Dim result As Object, ws As Worksheet, part As Range, cell As Range, item As Name
    Set result = CreateObject("Scripting.Dictionary")
    For Each ws In ThisWorkbook.Worksheets
        Set part = Nothing
        On Error Resume Next
        Set part = ws.UsedRange.SpecialCells(xlCellTypeFormulas)
        On Error GoTo 0
        If Not part Is Nothing Then
            For Each cell In part.Cells
                If ws.Name <> SH_INPUT Or Intersect(cell, ws.Range("B" & TX_FIRST_ROW & ":L" & ws.Rows.Count)) Is Nothing Then
                    If cell.HasArray Then
                        If cell.Address <> cell.CurrentArray.Cells(1, 1).Address Then GoTo NextReferenceCell
                        If Len(CStr(cell.CurrentArray.FormulaArray)) > 255 Then Err.Raise vbObjectError + 3414, , "�Q�Ɛ�ɒ����z�񐔎������邽�߁A���̈ړ��E�}���̎�������ێ��ł��܂���B"
                    End If
                    result("E|" & ws.CodeName & "|" & cell.Address(False, False)) = InputCellToken(cell)
                End If
NextReferenceCell:
            Next cell
        End If
    Next ws
    For Each item In ThisWorkbook.Names
        If InStr(1, item.Name, "_ToolInputMoveAnchor", vbTextCompare) = 0 And InStr(1, item.RefersTo, SH_INPUT, vbTextCompare) > 0 Then result("D|" & item.Name) = Array(item.RefersTo, "")
    Next item
    Set ReadWorkbookFormulaReferences = result
End Function

Public Function ReferenceHistoryCell(ByVal key As String) As Range
    Dim pieces As Variant, ws As Worksheet
    pieces = Split(key, "|")
    For Each ws In ThisWorkbook.Worksheets
        If ws.CodeName = CStr(pieces(1)) Then Set ReferenceHistoryCell = ws.Range(CStr(pieces(2))): Exit Function
    Next ws
    Err.Raise vbObjectError + 3412, , "�����̎Q�Ɛ�V�[�g��������܂���B"
End Function

Public Sub RestoreFormulaReferences(ByVal references As Object)
    Dim key As Variant, token As Variant
    For Each key In references.Keys
        token = references(key)
        If Left$(CStr(key), 2) = "E|" Then
            WriteInputCellToken ReferenceHistoryCell(CStr(key)), token
        ElseIf Left$(CStr(key), 2) = "D|" Then
            ThisWorkbook.Names(Mid$(CStr(key), 3)).RefersTo = CStr(token(0))
        End If
    Next key
End Sub


Public Function InputTokenKind(ByVal token As Variant) As String
    If UBound(token) >= 4 Then InputTokenKind = CStr(token(4))
End Function

Public Function InputCellHasSpill(ByVal cell As Range) As Boolean
    Dim value As Variant
    On Error Resume Next
    value = CallByName(cell, "HasSpill", VbGet)
    If Err.Number = 0 Then
        If Not IsNull(value) Then InputCellHasSpill = CBool(value)
    End If
    On Error GoTo 0
End Function

Public Sub RestoreInputTransactionState(ByVal state As Collection)
    Dim ws As Worksheet, desired As Variant, actual As Variant, expressions As Variant, formulas As Object
    Dim r As Long, c As Long, last As Long, cell As Range, token As Variant, address As String
    Dim changes As New Collection, previous As Variant
    Set ws = GetSheet(SH_INPUT): desired = state("transactions"): Set formulas = StateInputFormulas(state)
    last = Application.Max(UBound(desired, 1), LastInputDataRow() - TX_FIRST_ROW + 1, LastRow(ws, INPUT_UID_COL) - TX_FIRST_ROW + 1)
    actual = ws.Cells(TX_FIRST_ROW, COL_TX_YEAR).Resize(last, 11).Value2
    expressions = ws.Cells(TX_FIRST_ROW, COL_TX_YEAR).Resize(last, 11).Formula
    For r = 1 To last
        For c = 1 To 11
            address = Chr$(64 + COL_TX_YEAR + c - 1) & CStr(TX_FIRST_ROW + r - 1)
            token = Array(Empty, "")
            If r <= UBound(desired, 1) Then token = Array(desired(r, c), "")
            If formulas.Exists(address) Then token = formulas(address)
            If Not InputValuesEqual(actual(r, c), token(0)) Or Not InputValuesEqual(expressions(r, c), actual(r, c)) Or Len(CStr(token(1))) > 0 Then
                Set cell = ws.Range(address): previous = InputCellToken(cell)
                If Not InputTokenEqual(previous, token) Then
                    '�z����܂܂Ȃ��͈͂̑��삪���s�����ꍇ�A���֌W�Ȕz��̍Čv�Z�l�͖߂��Ȃ��B
                    If Not cell.HasArray And Not InputCellHasSpill(cell) Then changes.Add Array("C|" & address, previous, token)
                End If
            End If
        Next c
    Next r
    RestoreInputCellChanges changes
End Sub


Public Function InputHasGroupedFormulas() As Boolean
    On Error GoTo Grouped
    RequireIndependentInputCells Union(GetSheet(SH_INPUT).Range("B5:K6"), InputTransactionRange())
    Exit Function
Grouped:
    InputHasGroupedFormulas = True
End Function


Public Function InputBlankCanFill(ByVal token As Variant) As Boolean
    If Len(InputTokenKind(token)) > 0 Then Exit Function
    If Len(CStr(token(1))) > 0 Then Exit Function
    If IsError(token(0)) Then Exit Function
    If IsEmpty(token(0)) Or IsNull(token(0)) Then
        InputBlankCanFill = True
    ElseIf VarType(token(0)) = vbString Then
        InputBlankCanFill = (Len(CStr(token(0))) = 0)
    End If
End Function

Attribute VB_Name = "modAnalysisSearch"
Option Explicit

Private Const SEARCH_SLICE_SECONDS As Double = 0.18
Private Const SEARCH_ITEM_LIMIT As Long = 12000
Private mSearchBusy As Boolean
Private mSearchComplete As Boolean
Private mSearchPaused As Boolean
Private mSearchCapacity As Boolean
Private mSearchGeneration As Long
Private mSortedItems As Collection
Private mSortedCount As Long
Private mSearchItems As Collection
Private mSearchSeen As Object
Private mSearchUsage As Object
Private mSearchAnchors As Variant
Private mAnchorCount As Long
Private mAnchorIndex As Long
Private mSearchShapes As Collection
Private mShapeIndex As Long
Private mBundleShape As String
Private mSearchDeep As Boolean
Private mSearchWide As Boolean
Private mSearchDays As Long
Private mSearchAbsolute As Double
Private mSearchRate As Double
Private mSearchPartner As String
Private mSearchBridge As String
Private mSearchPathLinks As String
Private mSearchPathID As String
Private mSearchExcluded As Object
Private mSearchContext As String
Private mSearchIssue As String
Private mCurrentAnchor As String
Private mPoolW As Collection
Private mPoolD As Collection
Private mPoolDay As Long
Private mPoolSide As Long
Private mPoolIndex As Long
Private mPoolReady As Boolean
Private mBucket As Collection
Private mMaxW As Double
Private mMaxD As Double
Private mNeededW As Long
Private mNeededD As Long
Private mDepth As Long
Private mTotalDepth As Long
Private mPosition(1 To 12) As Long
Private mChosen(1 To 12) As String
Private mCombinationsReady As Boolean
Private mCompleteShapes As Long
Private mResumeAt As Date
Private mResumeProcedure As String
Private mPauseSerial As Long
Private mSearchFrames As Collection
Private mFrameComplete As Boolean
Private mAnchorSet As Object
Private mPoolCache As Object
Private mPoolCacheOrder As Collection
Private mHeap(1 To SEARCH_ITEM_LIMIT) As Object
Private mHeapCounts(1 To 36) As Long
Private mHeapLimit As Long
Private mRetainedDirty As Boolean

Public Function AnalysisSearchRunning() As Boolean
    AnalysisSearchRunning = mSearchBusy
End Function

Public Sub SetAnalysisBundleShape(ByVal shape As String)
    mBundleShape = shape
End Sub

Public Sub SetAnalysisDeepSearch(ByVal enabled As Boolean)
    mSearchDeep = enabled
End Sub

Public Sub SetAnalysisWideSearch(ByVal enabled As Boolean)
    mSearchWide = enabled
End Sub

Public Function AnalysisSearchCanContinue() As Boolean
    If mSearchItems Is Nothing Then Exit Function
    AnalysisSearchCanContinue = Not mSearchComplete And mSearchGeneration = AnalysisDataGeneration()
End Function

Public Function AnalysisSearchIsCurrent() As Boolean
    If mSearchItems Is Nothing Then Exit Function
    AnalysisSearchIsCurrent = (mSearchGeneration = AnalysisDataGeneration())
End Function

Public Sub PauseAnalysisSearch()
    mPauseSerial = mPauseSerial + 1
    mSearchPaused = True
    CancelAnalysisSearchSchedule
End Sub

Public Function SuspendAnalysisSearch() As Collection
    Dim state As New Collection
    state.Add (Not mSearchPaused And mResumeAt <> 0 And AnalysisSearchCanContinue()), "resume"
    state.Add mSearchGeneration, "generation"
    state.Add mPauseSerial, "pause"
    CancelAnalysisSearchSchedule
    Set SuspendAnalysisSearch = state
End Function

Public Sub ResumeSuspendedAnalysisSearch(ByVal state As Collection)
    If state Is Nothing Then Exit Sub
    If Not CBool(state("resume")) Then Exit Sub
    If CLng(state("pause")) <> mPauseSerial Or mSearchPaused Then Exit Sub
    If CLng(state("generation")) <> AnalysisDataGeneration() Then Exit Sub
    If Not ActiveWorkbook Is ThisWorkbook Then Exit Sub
    If ActiveSheet.Name <> SH_OUTPUT_TX Then Exit Sub
    ScheduleAnalysisSearch
End Sub

Public Sub CancelAnalysisSearchSchedule()
    On Error Resume Next
    If mResumeAt <> 0 Then Application.OnTime EarliestTime:=mResumeAt, Procedure:=mResumeProcedure, Schedule:=False
    mResumeAt = 0: mResumeProcedure = ""
    On Error GoTo 0
End Sub

Public Sub ScheduleAnalysisSearch()
    If mSearchPaused Or Not AnalysisSearchCanContinue() Or mResumeAt <> 0 Then Exit Sub
    On Error GoTo Done
    mResumeAt = Now + TimeSerial(0, 0, 1)
    mResumeProcedure = MacroRef("ResumeAnalysisSearchTick")
    Application.OnTime EarliestTime:=mResumeAt, Procedure:=mResumeProcedure, Schedule:=True
    Exit Sub
Done:
    mResumeAt = 0
End Sub

Public Sub ResumeAnalysisSearchTick()
    mResumeAt = 0
    If Not ActiveWorkbook Is ThisWorkbook Then Exit Sub
    If ActiveSheet.Name <> SH_OUTPUT_TX Or mSearchPaused Then Exit Sub
    If Not Application.Ready Or ToolSaveInProgress Or mSearchBusy Or ToolAppScopeActive() Then ScheduleAnalysisSearch: Exit Sub
    If Not AnalysisSearchCanContinue() Then Exit Sub
    ContinuePanelSearch True
End Sub

Public Function SearchAnalysis(ByVal anchors As Object, Optional ByVal bundles As Boolean = False, Optional ByVal pathFrom As String = "", Optional ByVal excluded As Object = Nothing, Optional ByVal pathLinks As String = "", Optional ByVal pathID As String = "") As Object
    Dim selected As Object, uid As Variant, bucket As Collection, w As Long, d As Long, total As Long, limit As Long, key As String
    On Error GoTo EH
    CancelAnalysisSearchSchedule
    LoadAnalysisData
    Set mSortedItems = Nothing: mSortedCount = -1
    Set mSearchItems = New Collection: Set mSearchSeen = CreateObject("Scripting.Dictionary")
    Set mSearchUsage = CreateObject("Scripting.Dictionary"): Set mSearchShapes = New Collection
    Set selected = CreateObject("Scripting.Dictionary")
    mSearchDays = CLng(Application.Max(0, Application.Min(36500, AnalysisSetting(30, 3))))
    mSearchAbsolute = Application.Max(0, AnalysisSetting(31, 10000)): mSearchRate = Application.Max(0, Application.Min(100, AnalysisSetting(32, 10))) / 100
    mSearchPartner = AnalysisPartnerFilter(): mSearchBridge = pathFrom
    mSearchPathLinks = "": mSearchPathID = ""
    If Len(pathFrom) > 0 Then mSearchPathLinks = pathLinks: mSearchPathID = pathID
    Set mSearchExcluded = excluded
    If Len(pathFrom) > 0 Then
        Set bucket = AnalysisAccountBucket(CellText(AnalysisValue(pathFrom, TX_ID_COL)), "W")
        For Each uid In bucket
            If AnalysisChronology(pathFrom, CStr(uid)) >= 0 Then
                If CDbl(AnalysisValue(CStr(uid), 6)) - CDbl(AnalysisValue(pathFrom, 6)) <= mSearchDays Then
                    selected(CStr(uid)) = True
                End If
            End If
        Next uid
    Else
        For Each uid In anchors.Keys
            If Len(AnalysisSide(CStr(uid))) > 0 Then selected(CStr(uid)) = True
        Next uid
    End If
    Set mAnchorSet = selected
    mAnchorCount = selected.Count
    If mAnchorCount > 0 Then mSearchAnchors = Split(AnalysisIDKey(selected), "|")
    mSearchShapes.Add "1:1"
    If bundles Or Len(pathFrom) > 0 Then
        limit = 3: If mSearchDeep Then limit = 6
        For total = 3 To limit * 2
            For w = 1 To limit
                d = total - w
                If d >= 1 And d <= limit Then
                    key = CStr(w) & ":" & CStr(d)
                    If Len(mBundleShape) = 0 Or key = mBundleShape Then mSearchShapes.Add key
                End If
            Next w
        Next total
    End If
    InitializeSearchFrames
    mShapeIndex = 1: mAnchorIndex = 0: mCompleteShapes = 0
    mSearchComplete = (mAnchorCount = 0): mSearchPaused = False: mSearchCapacity = False
    mPoolReady = False: mCombinationsReady = False: mCurrentAnchor = "": mSearchIssue = ""
    mSearchGeneration = AnalysisDataGeneration()
    mSearchContext = Format$(Now, "m/d hh:mm:ss") & "���� / �N�_" & anchors.Count & "���E����F" & IIf(Len(mSearchPartner) = 0, "�S����", mSearchPartner)
    mSearchContext = mSearchContext & " / �O��" & mSearchDays & "����E���Z��" & mSearchDays & "��"
    mSearchContext = mSearchContext & " / �ʏ퍷�z�F�傫������1%�i�Œ�1,000�~�j�ƒǉ����" & Format$(mSearchAbsolute, "#,##0") & "�~�̏��������A����" & Format$(mSearchRate * 100, "0.##") & "%�ȓ�"
    mSearchContext = mSearchContext & IIf(mSearchWide, " / �Q�l�F10���~����5%�ȓ�", " / ��v�E�����z")
    Set SearchAnalysis = ContinueSearchAnalysis()
    Exit Function
EH:
    mSearchIssue = Err.Description: mSearchPaused = True
    Set SearchAnalysis = CurrentSearchResult()
End Function

Public Function ContinueSearchAnalysis() As Object
    Dim started As Double, steps As Long, previousCancel As Long
    If mSearchItems Is Nothing Then
        Set mSearchItems = New Collection: mSearchComplete = True
    End If
    If mSearchGeneration <> AnalysisDataGeneration() Then
        mSearchIssue = "�o�^���e���ς��܂����B���݂̏����Ō����������Ă��������B"
        Set ContinueSearchAnalysis = CurrentSearchResult(): Exit Function
    End If
    If mSearchBusy Then Set ContinueSearchAnalysis = CurrentSearchResult(): Exit Function
    On Error GoTo EH
    mSearchBusy = True: mSearchPaused = False: mSearchIssue = ""
    previousCancel = Application.EnableCancelKey: Application.EnableCancelKey = xlErrorHandler
    started = Timer
    Do While Not mSearchComplete
        SearchStep
        steps = steps + 1
        If mFrameComplete Or steps Mod 32 = 0 Then AdvanceSearchFrame
        If steps Mod 8 = 0 Then
            If SearchElapsed(started) >= SEARCH_SLICE_SECONDS Then Exit Do
        End If
    Loop
Done:
    Application.EnableCancelKey = previousCancel
    mSearchBusy = False
    Set ContinueSearchAnalysis = CurrentSearchResult()
    Exit Function
EH:
    If Err.Number = 18 Then mSearchIssue = "�����𒆒f���܂����B" Else mSearchIssue = "�����̑��s�𒆒f���܂����F" & Err.Description
    mSearchPaused = True
    Resume Done
End Function

Private Function SearchElapsed(ByVal started As Double) As Double
    SearchElapsed = Timer - started
    If SearchElapsed < 0 Then SearchElapsed = SearchElapsed + 86400
End Function

Private Sub SearchStep()
    Dim shape As Variant, count As Long, uid As String, pool As Collection, startAt As Long, j As Long
    Dim choices As Collection, value As Variant
    If mAnchorIndex >= mAnchorCount Then mFrameComplete = True: Exit Sub
    If Len(mCurrentAnchor) = 0 Then
        mCurrentAnchor = CStr(mSearchAnchors(mAnchorIndex))
        If Not mSearchExcluded Is Nothing Then
            If mSearchExcluded.Exists(mCurrentAnchor) Then NextSearchAnchor: Exit Sub
        End If
        Set mPoolW = New Collection: Set mPoolD = New Collection
        mMaxW = 0: mMaxD = 0: mPoolDay = -mSearchDays: mPoolSide = 0: mPoolIndex = 1
        Set mBucket = Nothing
        RestoreCachedSearchPool
    End If
    If Not mPoolReady Then
        BuildSearchPoolStep
        Exit Sub
    End If
    If Not mCombinationsReady Then
        shape = Split(CStr(mSearchShapes(mShapeIndex)), ":")
        mNeededW = CLng(shape(0)): mNeededD = CLng(shape(1))
        If AnalysisSide(mCurrentAnchor) = "W" Then mNeededW = mNeededW - 1 Else mNeededD = mNeededD - 1
        If mNeededW > mPoolW.Count Or mNeededD > mPoolD.Count Then NextSearchAnchor: Exit Sub
        mTotalDepth = mNeededW + mNeededD: mDepth = 1
        For j = 1 To 12: mPosition(j) = 0: mChosen(j) = "": Next j
        mCombinationsReady = True
    End If
    If mDepth < 1 Then NextSearchAnchor: Exit Sub
    If mDepth > mTotalDepth Then
        Set choices = New Collection: choices.Add mCurrentAnchor
        For j = 1 To mTotalDepth: choices.Add mChosen(j): Next j
        AddSearchCandidate choices
        mDepth = mDepth - 1
        Exit Sub
    End If
    If mDepth <= mNeededW Then Set pool = mPoolW Else Set pool = mPoolD
    mPosition(mDepth) = mPosition(mDepth) + 1
    count = mNeededW - mDepth
    If mDepth > mNeededW Then count = mTotalDepth - mDepth
    If mPosition(mDepth) > pool.Count - count Then
        mDepth = mDepth - 1: Exit Sub
    End If
    uid = CStr(pool(mPosition(mDepth)))
    mChosen(mDepth) = uid
    If Not SearchPartialFits() Then Exit Sub
    mDepth = mDepth + 1
    If mDepth <= mTotalDepth Then
        startAt = 0
        If mDepth <> mNeededW + 1 Then startAt = mPosition(mDepth - 1)
        mPosition(mDepth) = startAt
    End If
End Sub

Private Sub NextSearchAnchor()
    mAnchorIndex = mAnchorIndex + 1
    mCurrentAnchor = "": mPoolReady = False: mCombinationsReady = False
End Sub

Private Sub BuildSearchPoolStep()
    Dim day As Long, uid As String
    If mPoolDay > mSearchDays Then mPoolReady = True: CacheSearchPool: Exit Sub
    If mBucket Is Nothing Then
        day = CLng(Int(CDbl(AnalysisValue(mCurrentAnchor, 6)))) + mPoolDay
        Set mBucket = AnalysisDayBucket(day, IIf(mPoolSide = 0, "W", "D"))
        mPoolIndex = 1
        If CStr(mSearchShapes(mShapeIndex)) = "1:1" Then
            If IIf(mPoolSide = 0, "W", "D") = AnalysisSide(mCurrentAnchor) Then
                mPoolIndex = mBucket.Count + 1
            Else
                mPoolIndex = AnalysisLowerBound(mBucket, Application.Max(0, AnalysisAmount(mCurrentAnchor) - SearchMoneyBound()))
            End If
        End If
    End If
    If mPoolIndex > mBucket.Count Then
        Set mBucket = Nothing
        mPoolSide = mPoolSide + 1
        If mPoolSide > 1 Then mPoolSide = 0: mPoolDay = mPoolDay + 1
        Exit Sub
    End If
    uid = CStr(mBucket(mPoolIndex)): mPoolIndex = mPoolIndex + 1
    If CStr(mSearchShapes(mShapeIndex)) = "1:1" Then
        If AnalysisAmount(uid) > AnalysisAmount(mCurrentAnchor) + SearchMoneyBound() Then mPoolIndex = mBucket.Count + 1: Exit Sub
    End If
    If uid = mCurrentAnchor Then Exit Sub
    If Not mSearchExcluded Is Nothing Then
        If mSearchExcluded.Exists(uid) Then Exit Sub
    End If
    If AnalysisSide(uid) <> AnalysisSide(mCurrentAnchor) Then
        If Not SearchPartnerMatches(uid) Then Exit Sub
        If CellText(AnalysisValue(uid, TX_ID_COL)) = CellText(AnalysisValue(mCurrentAnchor, TX_ID_COL)) Then Exit Sub
    End If
    If AnalysisSide(uid) = "W" Then
        mPoolW.Add uid: If AnalysisAmount(uid) > mMaxW Then mMaxW = AnalysisAmount(uid)
    Else
        mPoolD.Add uid: If AnalysisAmount(uid) > mMaxD Then mMaxD = AnalysisAmount(uid)
    End If
End Sub

Private Function SearchPartialFits() As Boolean
    Dim ids As Collection, i As Long, j As Long, uid As String, other As String
    Dim firstDay As Double, lastDay As Double, day As Double, w As Variant, d As Variant
    Dim remainingW As Long, remainingD As Long, bound As Double
    Set ids = New Collection: ids.Add mCurrentAnchor
    For i = 1 To mDepth: ids.Add mChosen(i): Next i
    firstDay = 1E+20
    For i = 1 To ids.Count
        uid = CStr(ids(i)): day = CDbl(AnalysisValue(uid, 6))
        firstDay = Application.Min(firstDay, day): lastDay = Application.Max(lastDay, day)
        If lastDay - firstDay > mSearchDays Then Exit Function
        If AnalysisSide(uid) = "W" Then w = CDec(w) + CDec(AnalysisAmount(uid)) Else d = CDec(d) + CDec(AnalysisAmount(uid))
        For j = 1 To i - 1
            other = CStr(ids(j))
            If AnalysisSide(other) <> AnalysisSide(uid) Then
                If CellText(AnalysisValue(other, TX_ID_COL)) = CellText(AnalysisValue(uid, TX_ID_COL)) Then Exit Function
            End If
        Next j
    Next i
    remainingW = Application.Max(0, mNeededW - mDepth)
    remainingD = mNeededD - Application.Max(0, mDepth - mNeededW)
    bound = SearchMoneyBound()
    If CDbl(w) > CDbl(d) + CDbl(mMaxD) * remainingD + bound Then Exit Function
    If CDbl(d) > CDbl(w) + CDbl(mMaxW) * remainingW + bound Then Exit Function
    SearchPartialFits = True
End Function

Public Function AnalysisMoneyFits(ByVal withdrawal As Double, ByVal deposit As Double, ByVal absoluteLimit As Double, ByVal rateLimit As Double) As Boolean
    Dim largest As Double, difference As Double
    If withdrawal <= 0 Or deposit <= 0 Then Exit Function
    largest = Application.Max(withdrawal, deposit): difference = Abs(withdrawal - deposit)
    AnalysisMoneyFits = difference <= absoluteLimit And difference / largest <= rateLimit
End Function

Private Function CandidateMoneyTier(ByVal w As Variant, ByVal d As Variant) As Long
    CandidateMoneyTier = CandidateMoneyRule(CDbl(w), CDbl(d), mSearchAbsolute, mSearchRate, mSearchWide)
End Function

Public Function CandidateMoneyRule(ByVal withdrawal As Double, ByVal deposit As Double, ByVal extraLimit As Double, ByVal rate As Double, ByVal includeReference As Boolean) As Long
    Dim largest As Double, small As Double
    CandidateMoneyRule = -1
    If withdrawal <= 0 Or deposit <= 0 Then Exit Function
    If withdrawal = deposit Then CandidateMoneyRule = 0: Exit Function
    largest = Application.Max(withdrawal, deposit)
    small = Application.Min(extraLimit, Application.Max(1000, largest * 0.01))
    If AnalysisMoneyFits(withdrawal, deposit, small, rate) Then CandidateMoneyRule = 1: Exit Function
    If includeReference And AnalysisMoneyFits(withdrawal, deposit, 100000, 0.05) Then CandidateMoneyRule = 2
End Function

Private Function SearchMoneyBound() As Double
    SearchMoneyBound = mSearchAbsolute
    If mSearchWide Then SearchMoneyBound = Application.Max(SearchMoneyBound, 100000)
End Function

Private Sub AddSearchCandidate(ByVal choices As Collection)
    Dim ids As Object, item As Object, uid As Variant, other As Variant, key As String
    Dim w As Variant, d As Variant, countW As Long, countD As Long, tier As Long, sequence As Long, matches As Object
    Dim firstDay As Double, lastDay As Double, day As Double, possibleAmount As Double, uncovered As Double
    Set ids = CreateObject("Scripting.Dictionary"): sequence = 1: firstDay = 1E+20
    For Each uid In choices
        If ids.Exists(CStr(uid)) Then Exit Sub
        ids(CStr(uid)) = True
        day = CDbl(AnalysisValue(CStr(uid), 6)): firstDay = Application.Min(firstDay, day): lastDay = Application.Max(lastDay, day)
        If AnalysisSide(CStr(uid)) = "W" Then w = CDec(w) + CDec(AnalysisAmount(CStr(uid))): countW = countW + 1 Else d = CDec(d) + CDec(AnalysisAmount(CStr(uid))): countD = countD + 1
    Next uid
    tier = CandidateMoneyTier(w, d): If tier < 0 Then Exit Sub
    If Not CandidateOwnedByCurrentAnchor(ids) Then Exit Sub
    sequence = AnalysisCandidateOrder(ids, possibleAmount, uncovered)
    If Len(mSearchBridge) > 0 And sequence < 0 Then Exit Sub
    key = AnalysisIDKey(ids)
    If Len(mSearchBridge) > 0 Then key = mSearchBridge & ">" & key
    If mSearchSeen.Exists(key) Then Exit Sub
    Set item = CreateObject("Scripting.Dictionary")
    item("key") = key: item("ids") = AnalysisIDKey(ids): item("out") = w: item("in") = d
    item("difference") = d - w: item("span") = lastDay - firstDay: item("order") = sequence
    item("timeCapacity") = possibleAmount: item("timeUncovered") = uncovered
    item("firstDay") = firstDay: item("lastDay") = lastDay: item("tier") = tier
    item("shape") = CStr(countW) & "��" & CStr(countD): item("bridge") = mSearchBridge: item("anchor") = mCurrentAnchor
    item("pathLinks") = mSearchPathLinks: item("pathID") = mSearchPathID
    item("generation") = mSearchGeneration
    item("evidence") = IIf(tier = 0, "���v��v", "���z " & Format$(Abs(CDbl(d) - CDbl(w)), "#,##0") & "�~")
    If countW > 1 And countD > 1 Then item("evidence") = CStr(item("evidence")) & " / �ʔz���͖��w��"
    If tier = 2 Then item("evidence") = "�Q�l / " & CStr(item("evidence"))
    If sequence = 0 Then item("evidence") = CStr(item("evidence")) & " / �������m��"
    If sequence < 0 Then item("evidence") = CStr(item("evidence")) & " / �L�^�����ł͑Ή��s�� " & Format$(uncovered, "#,##0") & "�~"
    Set matches = CreateObject("Scripting.Dictionary")
    item("evidence") = CStr(item("evidence")) & CandidateSourceEvidence(ids, matches)
    item.Add "evidencePairs", matches
    If Len(mSearchBridge) > 0 Then
        item("evidence") = CStr(item("evidence")) & " / �ڑ������� " & Format$(AnalysisAmount(mSearchBridge), "#,##0") & "�~�E�ڑ��z�͖��w��"
    End If
    item("competing") = False
    For Each uid In ids.Keys
        If mSearchUsage.Exists(CStr(uid)) Then mSearchUsage(CStr(uid)) = 2 Else mSearchUsage(CStr(uid)) = 1
    Next uid
    RetainSearchCandidate item
End Sub

Private Function SearchPartnerMatches(ByVal uid As String) As Boolean
    If Len(mSearchPartner) = 0 Then SearchPartnerMatches = True: Exit Function
    SearchPartnerMatches = InStr(1, AnalysisAccountText(uid), mSearchPartner, vbTextCompare) > 0
End Function

Public Function CurrentSearchResult() As Object
    Dim result As Object, item As Object, uid As Variant, ids As Object, message As String, shape As String
    Set result = CreateObject("Scripting.Dictionary")
    If mSearchItems Is Nothing Then Set mSearchItems = New Collection
    If mSearchShapes Is Nothing Then Set mSearchShapes = New Collection
    If mSearchUsage Is Nothing Then Set mSearchUsage = CreateObject("Scripting.Dictionary")
    If mRetainedDirty Or mSortedItems Is Nothing Then
        Set mSearchItems = RetainedSearchItems()
        Set mSortedItems = SortedSearchItems(mSearchItems, Nothing, 0)
        mSortedCount = mSearchItems.Count: mRetainedDirty = False
    End If
    result.Add "items", mSortedItems
    result("pathFrom") = mSearchBridge: result("pathLinks") = mSearchPathLinks: result("pathID") = mSearchPathID
    result("complete") = mSearchComplete And Len(mSearchIssue) = 0
    If mShapeIndex > 0 And mShapeIndex <= mSearchShapes.Count Then shape = Replace(CStr(mSearchShapes(mShapeIndex)), ":", "��")
    If Len(mSearchIssue) > 0 Then
        message = mSearchIssue
    ElseIf mSearchComplete Then
        message = mSearchItems.Count & "�g / �w�肵���g�����͈͂̒T�����I��"
    ElseIf mSearchPaused Then
        message = mSearchItems.Count & "�g / �����͒��f���B�O������ő����ĒT���܂��B"
    Else
        message = mSearchItems.Count & "�g / " & shape & "��T�����B�����ĒT���E���f�ł��܂��B"
    End If
    If mSearchCapacity Then message = message & "�^��ނ��Ƃ̕\�����ɏ������"
    result("limited") = mSearchCapacity
    result("message") = message
    result("context") = mSearchContext & " / �I�������g���� " & mCompleteShapes & "/" & mSearchShapes.Count & IIf(result("complete"), "", "�E�r��")
    Set CurrentSearchResult = result
End Function

Private Function CandidateComesBefore(ByVal leftItem As Object, ByVal rightItem As Object) As Boolean
    If CLng(leftItem("tier")) <> CLng(rightItem("tier")) Then
        CandidateComesBefore = CLng(leftItem("tier")) < CLng(rightItem("tier"))
    ElseIf CLng(leftItem("order")) <> CLng(rightItem("order")) Then
        CandidateComesBefore = CLng(leftItem("order")) > CLng(rightItem("order"))
    ElseIf Abs(CDbl(leftItem("difference"))) <> Abs(CDbl(rightItem("difference"))) Then
        CandidateComesBefore = Abs(CDbl(leftItem("difference"))) < Abs(CDbl(rightItem("difference")))
    ElseIf CDbl(leftItem("span")) <> CDbl(rightItem("span")) Then
        CandidateComesBefore = CDbl(leftItem("span")) < CDbl(rightItem("span"))
    Else
        CandidateComesBefore = StrComp(CStr(leftItem("key")), CStr(rightItem("key")), vbBinaryCompare) < 0
    End If
End Function

Public Function AnalysisIDKey(ByVal ids As Object) As String
    Dim values As Variant
    If ids.Count = 0 Then Exit Function
    values = ids.Keys
    If UBound(values) > 0 Then SortAnalysisKeys values, 0, UBound(values)
    AnalysisIDKey = Join(values, "|")
End Function

Private Sub SortAnalysisKeys(ByRef values As Variant, ByVal lo As Long, ByVal hi As Long)
    Dim i As Long, j As Long, pivot As String, swapValue As String
    i = lo: j = hi: pivot = CStr(values((lo + hi) \ 2))
    Do While i <= j
        Do While StrComp(CStr(values(i)), pivot, vbBinaryCompare) < 0: i = i + 1: Loop
        Do While StrComp(CStr(values(j)), pivot, vbBinaryCompare) > 0: j = j - 1: Loop
        If i <= j Then
            swapValue = CStr(values(i)): values(i) = values(j): values(j) = swapValue
            i = i + 1: j = j - 1
        End If
    Loop
    If lo < j Then SortAnalysisKeys values, lo, j
    If i < hi Then SortAnalysisKeys values, i, hi
End Sub

Public Function AnalysisIDSet(ByVal keys As String) As Object
    Dim result As Object, item As Variant
    Set result = CreateObject("Scripting.Dictionary")
    For Each item In Split(keys, "|")
        If Len(CStr(item)) > 0 Then result(CStr(item)) = True
    Next item
    Set AnalysisIDSet = result
End Function

Private Function SortedSearchItems(ByVal items As Collection, ByVal sorted As Collection, ByVal sortedCount As Long) As Collection
    Dim result As New Collection, added() As Object, previous() As Object, order() As Long
    Dim item As Object, i As Long, a As Long, b As Long, addedCount As Long
    If sorted Is Nothing Then sortedCount = 0
    If sortedCount < 0 Or sortedCount > items.Count Then sortedCount = 0
    addedCount = items.Count - sortedCount
    ReDim added(1 To Application.Max(1, addedCount))
    ReDim previous(1 To Application.Max(1, sortedCount))
    ReDim order(1 To Application.Max(1, addedCount))
    'Collection�ւ̔����C���f�b�N�X�Q�Ƃ�����A��������₾������בւ���B
    For Each item In items
        i = i + 1
        If i > sortedCount Then Set added(i - sortedCount) = item: order(i - sortedCount) = i - sortedCount
    Next item
    If sortedCount > 0 Then
        i = 0
        For Each item In sorted
            i = i + 1: Set previous(i) = item
        Next item
    End If
    If addedCount > 1 Then SortCandidateIndices added, order, 1, addedCount
    a = 1: b = 1
    Do While a <= sortedCount And b <= addedCount
        If CandidateComesBefore(added(order(b)), previous(a)) Then
            result.Add added(order(b)): b = b + 1
        Else
            result.Add previous(a): a = a + 1
        End If
    Loop
    Do While a <= sortedCount: result.Add previous(a): a = a + 1: Loop
    Do While b <= addedCount: result.Add added(order(b)): b = b + 1: Loop
    Set SortedSearchItems = result
End Function

Private Sub SortCandidateIndices(ByRef items() As Object, ByRef order() As Long, ByVal lo As Long, ByVal hi As Long)
    Dim i As Long, j As Long, pivot As Object, swapIndex As Long
    i = lo: j = hi: Set pivot = items(order((lo + hi) \ 2))
    Do While i <= j
        Do While CandidateComesBefore(items(order(i)), pivot): i = i + 1: Loop
        Do While CandidateComesBefore(pivot, items(order(j))): j = j - 1: Loop
        If i <= j Then
            swapIndex = order(i): order(i) = order(j): order(j) = swapIndex
            i = i + 1: j = j - 1
        End If
    Loop
    If lo < j Then SortCandidateIndices items, order, lo, j
    If i < hi Then SortCandidateIndices items, order, i, hi
End Sub

Public Function AnalysisPartnerFilter() As String
    AnalysisPartnerFilter = Trim$(CellText(GetSheet(SH_CONFIG).Cells(33, 16384).Value2))
End Function

Public Function AnalysisSetting(ByVal row As Long, ByVal fallback As Double) As Double
    Dim v As Variant
    v = GetSheet(SH_CONFIG).Cells(row, 16384).Value2
    AnalysisSetting = fallback
    If HasText(v) And IsNumeric(v) Then AnalysisSetting = CDbl(v)
End Function

Public Function CandidateHasCompetition(ByVal item As Object) As Boolean
    Dim uid As Variant, ids As Object
    If mSearchUsage Is Nothing Then Exit Function
    Set ids = AnalysisIDSet(CStr(item("ids")))
    For Each uid In ids.Keys
        If mSearchUsage.Exists(CStr(uid)) Then
            If CLng(mSearchUsage(CStr(uid))) > 1 Then CandidateHasCompetition = True: Exit Function
        End If
    Next uid
End Function

Public Function SearchUnmatchedIDs() As Object
    Dim result As Object, i As Long, uid As String
    Set result = CreateObject("Scripting.Dictionary")
    If Not mSearchUsage Is Nothing Then
        For i = 0 To mAnchorCount - 1
            uid = CStr(mSearchAnchors(i))
            If Not mSearchUsage.Exists(uid) Then result(uid) = True
        Next i
    End If
    Set SearchUnmatchedIDs = result
End Function

Private Function CandidateSourceEvidence(ByVal ids As Object, ByVal matches As Object) As String
    Dim uid As Variant, other As Variant, evidence As String, shops As Long, machines As Long, names As Long
    For Each uid In ids.Keys
        If AnalysisSide(CStr(uid)) = "W" Then
            For Each other In ids.Keys
                If AnalysisSide(CStr(other)) = "D" Then
                    evidence = AnalysisPairEvidence(CStr(uid), CStr(other))
                    If Len(evidence) > 0 Then matches(CStr(uid) & "~" & CStr(other)) = evidence
                    If InStr(evidence, "�戵�X") > 0 Then shops = shops + 1
                    If InStr(evidence, "�@��") > 0 Then machines = machines + 1
                    If InStr(evidence, "����") > 0 Then names = names + 1
                End If
            Next other
        End If
    Next uid
    If shops > 0 Then CandidateSourceEvidence = " / �戵�X��v" & shops & "�g"
    If machines > 0 Then CandidateSourceEvidence = CandidateSourceEvidence & " / �@�Ԉ�v" & machines & "�g"
    If names > 0 Then CandidateSourceEvidence = CandidateSourceEvidence & " / �E�v�ɑ��莁��" & names & "�g"
End Function

Public Function AnalysisPairEvidence(ByVal withdrawal As String, ByVal deposit As String) As String
    Dim bank As String, shop As String, machine As String, person As String, text As String
    bank = CellText(AnalysisValue(withdrawal, 1)): shop = CellText(AnalysisValue(withdrawal, 10)): machine = CellText(AnalysisValue(withdrawal, 11))
    If bank = CellText(AnalysisValue(deposit, 1)) And Len(shop) > 0 Then
        If shop = CellText(AnalysisValue(deposit, 10)) Then
            text = "�����s�E�戵�X"
            If Len(machine) > 0 And machine = CellText(AnalysisValue(deposit, 11)) Then text = text & "�E�@��"
        End If
    End If
    person = CellText(AnalysisValue(deposit, 3))
    If Len(person) > 1 Then
        If InStr(1, CellText(AnalysisValue(withdrawal, 12)), person, vbTextCompare) > 0 Then text = text & " �E�v�ɓ���������"
    End If
    person = CellText(AnalysisValue(withdrawal, 3))
    If Len(person) > 1 Then
        If InStr(1, CellText(AnalysisValue(deposit, 12)), person, vbTextCompare) > 0 Then text = text & " �E�v�ɏo��������"
    End If
    AnalysisPairEvidence = Trim$(text)
End Function

Public Function CandidateMemberEvidence(ByVal candidate As Object, ByVal uid As String) As String
    Dim matches As Object, key As Variant, pair As Variant, other As String
    If candidate Is Nothing Then Exit Function
    If Not candidate.Exists("evidencePairs") Then Exit Function
    Set matches = candidate("evidencePairs")
    For Each key In matches.Keys
        pair = Split(CStr(key), "~"): other = ""
        If CStr(pair(0)) = uid Then other = CStr(pair(1))
        If CStr(pair(1)) = uid Then other = CStr(pair(0))
        If Len(other) > 0 Then
            If Len(CandidateMemberEvidence) > 0 Then CandidateMemberEvidence = CandidateMemberEvidence & " / "
            CandidateMemberEvidence = CandidateMemberEvidence & CellText(AnalysisValue(other, 3)) & " " & AnalysisDateText(other) & "�F" & CStr(matches(key))
        End If
    Next key
End Function


Private Sub InitializeSearchFrames()
    Dim frame As Object, i As Long
    Set mSearchFrames = New Collection: Set mPoolCache = CreateObject("Scripting.Dictionary"): Set mPoolCacheOrder = New Collection
    For i = 1 To mSearchShapes.Count
        Set frame = CreateObject("Scripting.Dictionary"): frame("done") = False
        mSearchFrames.Add frame
    Next i
    For i = 1 To SEARCH_ITEM_LIMIT: Set mHeap(i) = Nothing: Next i
    For i = 1 To 36: mHeapCounts(i) = 0: Next i
    mHeapLimit = SEARCH_ITEM_LIMIT \ mSearchShapes.Count
    mFrameComplete = False: mRetainedDirty = True
End Sub

Private Sub AdvanceSearchFrame()
    Dim frame As Object, nextFrame As Object, i As Long, position As Variant, chosen As Variant
    Set frame = mSearchFrames(mShapeIndex)
    frame("done") = mFrameComplete
    If mFrameComplete Then
        mCompleteShapes = mCompleteShapes + 1
        frame.RemoveAll: frame("done") = True
    Else
        frame("index") = mAnchorIndex: frame("anchor") = mCurrentAnchor
        Set frame("poolW") = mPoolW: Set frame("poolD") = mPoolD: Set frame("bucket") = mBucket
        frame("day") = mPoolDay: frame("side") = mPoolSide: frame("poolIndex") = mPoolIndex: frame("poolReady") = mPoolReady
        frame("maxW") = mMaxW: frame("maxD") = mMaxD: frame("needW") = mNeededW: frame("needD") = mNeededD
        frame("depth") = mDepth: frame("total") = mTotalDepth: frame("ready") = mCombinationsReady
        ReDim position(1 To 12): ReDim chosen(1 To 12)
        For i = 1 To 12: position(i) = mPosition(i): chosen(i) = mChosen(i): Next i
        frame("position") = position: frame("chosen") = chosen
    End If
    If mCompleteShapes >= mSearchShapes.Count Then mSearchComplete = True: Exit Sub
    Do
        mShapeIndex = mShapeIndex Mod mSearchShapes.Count + 1
        Set nextFrame = mSearchFrames(mShapeIndex)
        If Not CBool(nextFrame("done")) Then Exit Do
    Loop
    mFrameComplete = False
    If nextFrame.Exists("index") Then
        mAnchorIndex = CLng(nextFrame("index")): mCurrentAnchor = CStr(nextFrame("anchor"))
        Set mPoolW = nextFrame("poolW"): Set mPoolD = nextFrame("poolD"): Set mBucket = nextFrame("bucket")
        mPoolDay = CLng(nextFrame("day")): mPoolSide = CLng(nextFrame("side")): mPoolIndex = CLng(nextFrame("poolIndex")): mPoolReady = CBool(nextFrame("poolReady"))
        mMaxW = CDbl(nextFrame("maxW")): mMaxD = CDbl(nextFrame("maxD")): mNeededW = CLng(nextFrame("needW")): mNeededD = CLng(nextFrame("needD"))
        mDepth = CLng(nextFrame("depth")): mTotalDepth = CLng(nextFrame("total")): mCombinationsReady = CBool(nextFrame("ready"))
        position = nextFrame("position"): chosen = nextFrame("chosen")
        For i = 1 To 12: mPosition(i) = CLng(position(i)): mChosen(i) = CStr(chosen(i)): Next i
    Else
        mAnchorIndex = 0: mCurrentAnchor = "": mPoolReady = False: mCombinationsReady = False
        Set mPoolW = Nothing: Set mPoolD = Nothing: Set mBucket = Nothing
    End If
End Sub

Private Function SearchPoolKey() As String
    SearchPoolKey = mCurrentAnchor & IIf(CStr(mSearchShapes(mShapeIndex)) = "1:1", ":single", ":bundle")
End Function

Private Sub RestoreCachedSearchPool()
    Dim cached As Collection, key As String
    key = SearchPoolKey()
    If Not mPoolCache.Exists(key) Then Exit Sub
    Set cached = mPoolCache(key)
    Set mPoolW = cached("w"): Set mPoolD = cached("d")
    mMaxW = CDbl(cached("maxW")): mMaxD = CDbl(cached("maxD")): mPoolReady = True
End Sub

Private Sub CacheSearchPool()
    Dim cached As New Collection, key As String, old As String
    key = SearchPoolKey()
    If mPoolCache.Exists(key) Then Exit Sub
    cached.Add mPoolW, "w": cached.Add mPoolD, "d": cached.Add mMaxW, "maxW": cached.Add mMaxD, "maxD"
    mPoolCache.Add key, cached: mPoolCacheOrder.Add key
    Do While mPoolCacheOrder.Count > 8
        old = CStr(mPoolCacheOrder(1)): mPoolCacheOrder.Remove 1: mPoolCache.Remove old
    Loop
End Sub

Private Function CandidateOwnedByCurrentAnchor(ByVal ids As Object) As Boolean
    Dim uid As Variant, other As Variant, eligible As Boolean
    For Each uid In ids.Keys
        If StrComp(CStr(uid), mCurrentAnchor, vbBinaryCompare) < 0 And mAnchorSet.Exists(CStr(uid)) Then
            eligible = True
            For Each other In ids.Keys
                If AnalysisSide(CStr(other)) <> AnalysisSide(CStr(uid)) Then
                    If Not SearchPartnerMatches(CStr(other)) Then eligible = False: Exit For
                End If
            Next other
            If eligible Then Exit Function
        End If
    Next uid
    CandidateOwnedByCurrentAnchor = True
End Function

Private Sub RetainSearchCandidate(ByVal item As Object)
    Dim start As Long, count As Long, position As Long, parent As Long, child As Long, swap As Object
    start = (mShapeIndex - 1) * mHeapLimit: count = mHeapCounts(mShapeIndex)
    If count < mHeapLimit Then
        count = count + 1: mHeapCounts(mShapeIndex) = count: position = count
        Set mHeap(start + position) = item: mSearchSeen(CStr(item("key"))) = True
        Do While position > 1
            parent = position \ 2
            If Not CandidateComesBefore(mHeap(start + parent), mHeap(start + position)) Then Exit Do
            Set swap = mHeap(start + parent): Set mHeap(start + parent) = mHeap(start + position): Set mHeap(start + position) = swap
            position = parent
        Loop
    Else
        mSearchCapacity = True
        If Not CandidateComesBefore(item, mHeap(start + 1)) Then Exit Sub
        mSearchSeen.Remove CStr(mHeap(start + 1).Item("key"))
        Set mHeap(start + 1) = item: mSearchSeen(CStr(item("key"))) = True: position = 1
        Do While position * 2 <= count
            child = position * 2
            If child < count Then
                If CandidateComesBefore(mHeap(start + child), mHeap(start + child + 1)) Then child = child + 1
            End If
            If Not CandidateComesBefore(mHeap(start + position), mHeap(start + child)) Then Exit Do
            Set swap = mHeap(start + position): Set mHeap(start + position) = mHeap(start + child): Set mHeap(start + child) = swap
            position = child
        Loop
    End If
    mRetainedDirty = True
End Sub

Private Function RetainedSearchItems() As Collection
    Dim result As New Collection, shape As Long, i As Long, start As Long
    If Not mSearchShapes Is Nothing Then
        For shape = 1 To mSearchShapes.Count
            start = (shape - 1) * mHeapLimit
            For i = 1 To mHeapCounts(shape): result.Add mHeap(start + i): Next i
        Next shape
    End If
    Set RetainedSearchItems = result
End Function


Public Function AnalysisCandidateIsCurrent(ByVal item As Object) As Boolean
    If item Is Nothing Then Exit Function
    If Not item.Exists("generation") Then Exit Function
    AnalysisCandidateIsCurrent = (CLng(item("generation")) = AnalysisDataGeneration())
End Function

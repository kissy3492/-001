Attribute VB_Name = "modAnalysisRelations"
Option Explicit

Public Const SH_ANALYSIS_RELATIONS As String = "W_�֘A"
Private mRemovedRelation As Variant
Private mRemovedDrafts As Variant

Public Function ReadStoredAnalysisRelations() As Variant
    Dim data As Variant, c As Long, headers As Variant
    If SheetExists(SH_ANALYSIS_RELATIONS) Then
        ReadStoredAnalysisRelations = ReadStore(GetSheet(SH_ANALYSIS_RELATIONS), 12)
    Else
        headers = Array("�֘AID", "���e", "���", "�Q��ID", "�w��z", "���z������", "����", "�o�^������", "���o��", "�\����", "�ڑ�������ID", "�ڑ���o��ID")
        ReDim data(1 To 1, 1 To 12)
        For c = 1 To 12: data(1, c) = headers(c - 1): Next c
        ReadStoredAnalysisRelations = data
    End If
End Function

Public Function ReadAnalysisRelations() As Variant
    ReadAnalysisRelations = ProjectAnalysisDrafts(ReadStoredAnalysisRelations())
End Function

Public Function AnalysisRelationStore() As Worksheet
    Dim ws As Worksheet
    If SheetExists(SH_ANALYSIS_RELATIONS) Then
        Set ws = GetSheet(SH_ANALYSIS_RELATIONS)
    Else
        Set ws = GetOrCreateSheet(SH_ANALYSIS_RELATIONS, False)
        WriteStore ws, ReadStoredAnalysisRelations()
    End If
    If Not HasText(ws.Cells(1, 1).Value2) Then
        SetRowValues ws.Cells(1, 1), Array("�֘AID", "���e", "���", "�Q��ID", "�w��z", "���z������", "����", "�o�^������", "���o��", "�\����", "�ڑ�������ID", "�ڑ���o��ID")
        ws.Columns("A:L").NumberFormat = "@"
        ws.Columns(5).NumberFormat = "#,##0"
    End If
    ws.Visible = xlSheetVeryHidden
    Set AnalysisRelationStore = ws
End Function

Public Function RelationHeaders(ByVal data As Variant) As Object
    Dim result As Object, r As Long
    Set result = CreateObject("Scripting.Dictionary")
    For r = 2 To UBound(data, 1)
        If CellText(data(r, 2)) = "H" Then result(CellText(data(r, 1))) = r
    Next r
    Set RelationHeaders = result
End Function

Public Function RelationMemberKeys(ByVal relationID As String, ByVal data As Variant) As String
    Dim r As Long, keys As String
    For r = 2 To UBound(data, 1)
        If CellText(data(r, 1)) = relationID And (CellText(data(r, 2)) = "T" Or CellText(data(r, 2)) = "L") Then
            If Len(keys) > 0 Then keys = keys & "|"
            keys = keys & CellText(data(r, 4))
        End If
    Next r
    RelationMemberKeys = keys
End Function

Public Function RegisterAnalysisRelation(ByVal members As Object, Optional ByVal searchContext As String = "", Optional ByVal evidence As String = "") As String
    Dim data As Variant, headers As Object, compositions As Object, relationID As Variant, key As String, uid As Variant, block As Variant, r As Long
    If members.Count < 2 Then Err.Raise vbObjectError + 3401, , "�֘A�t���閾�ׂ�2���ȏ�I�����Ă��������B"
    LoadAnalysisData
    For Each uid In members.Keys
        If Not AnalysisIDs().Exists(CStr(uid)) Then Err.Raise vbObjectError + 3402, , "�폜���ꂽ���ׂ��܂܂�Ă��܂��B���݂̖��ׂ�I�ђ����Ă��������B"
    Next uid
    data = ReadAnalysisRelations(): Set headers = RelationHeaders(data): key = AnalysisIDKey(members)
    Set compositions = RelationCompositions(data)
    For Each relationID In headers.Keys
        If CellText(data(CLng(headers(relationID)), 3)) = "G" Then
            If AnalysisIDKey(AnalysisIDSet(CStr(compositions(relationID)))) = key Then RegisterAnalysisRelation = CStr(relationID): Exit Function
        End If
    Next relationID
    RegisterAnalysisRelation = NewInternalID("R")
    ReDim block(1 To members.Count + 1, 1 To 12)
    block(1, 1) = RegisterAnalysisRelation: block(1, 2) = "H": block(1, 3) = "G"
    block(1, 9) = Format$(Now, "yyyy/m/d hh:mm:ss"): block(1, 10) = searchContext
    If Len(evidence) > 0 Then block(1, 10) = searchContext & " / " & evidence
    r = 1
    For Each uid In members.Keys
        r = r + 1
        block(r, 1) = RegisterAnalysisRelation: block(r, 2) = "T": block(r, 4) = CStr(uid)
        block(r, 8) = AnalysisValue(CStr(uid), TX_ID_COL): block(r, 9) = AnalysisSide(CStr(uid))
        block(r, 10) = AnalysisAccountText(CStr(uid))
    Next uid
    AppendRelationRows block
End Function

Public Function RegisterCandidateRelation(ByVal members As Object, ByVal searchContext As String, ByVal evidence As String, ByVal pathFrom As String, ByVal pathLinks As String, ByVal existingPath As String, ByVal toWithdrawal As String, ByRef savedPath As String) As String
    Dim original As Variant, relationID As String, nextPath As String, started As Boolean, writing As Boolean
    Dim message As String, restoring As String
    On Error GoTo EH
    FlushPendingAnalysisEdits
    EnsureAnalysisDraftStored
    original = ReadStoredAnalysisRelations()
    AppBegin "�֘A�t����ۑ����Ă��܂�...": started = True
    writing = True
    relationID = RegisterAnalysisRelation(members, searchContext, evidence)
    If Len(pathFrom) > 0 Then
        nextPath = RegisterAnalysisPath(pathLinks & "|" & relationID, existingPath, pathFrom, toWithdrawal)
    End If
    writing = False
    savedPath = nextPath
    RegisterCandidateRelation = relationID
    EndAppScope started
    Exit Function
EH:
    message = Err.Description
    On Error Resume Next
    If writing Then
        Err.Clear
        WriteStore AnalysisRelationStore(), original
        If Err.Number <> 0 Then restoring = vbCrLf & "�֘A�̕����������ł��܂���ł����F" & Err.Description
    End If
    EndAppScope started
    On Error GoTo 0
    savedPath = ""
    If Len(restoring) = 0 Then message = "�֘A�t����ۑ��ł��܂���ł����B�o�^�O�̏�Ԃ�ێ����Ă��܂��B" & vbCrLf & message
    Err.Raise vbObjectError + 3430, "RegisterCandidateRelation", message & restoring
End Function

Public Function RegisterAnalysisPath(ByVal links As String, Optional ByVal existingPath As String = "", Optional ByVal fromDeposit As String = "", Optional ByVal toWithdrawal As String = "") As String
    Dim data As Variant, headers As Object, nodes As Object, used As Object, owner As Object
    Dim link As Variant, uid As Variant, members As Object, edges As Collection, edge As Object
    Dim block As Variant, nextData As Variant, r As Long, c As Long, rowByNode As Object, row As Long
    Dim fromNode As String, toNode As String, entry As Variant, found As Boolean
    data = ReadAnalysisRelations(): Set headers = RelationHeaders(data)
    Set nodes = AnalysisIDSet(links): Set used = CreateObject("Scripting.Dictionary")
    Set owner = CreateObject("Scripting.Dictionary"): Set rowByNode = CreateObject("Scripting.Dictionary")
    If nodes.Count < 2 Then Err.Raise vbObjectError + 3403, , "�o�H�ɂ�2��Ԉȏ�̊֘A�t�����K�v�ł��B"
    If Len(existingPath) > 0 Then
        If Not headers.Exists(existingPath) Then Err.Raise vbObjectError + 3404, , "��������o�H���폜����Ă��܂��B"
        If CellText(data(CLng(headers(existingPath)), 3)) <> "P" Then Err.Raise vbObjectError + 3405, , "�����悪�o�H�ł͂���܂���B"
        '�����J�n��ɒǉ�����������A�ĊJ�������̓o�^�Ŏ�菜���Ȃ��B
        For Each link In Split(RelationMemberKeys(existingPath, data), "|")
            If Len(CStr(link)) > 0 Then nodes(CStr(link)) = True
        Next link
    End If
    For Each link In nodes.Keys
        If Not headers.Exists(CStr(link)) Then Err.Raise vbObjectError + 3404, , "�Q�Ɛ�̊֘A�t��������܂���B"
        If CellText(data(CLng(headers(CStr(link))), 3)) <> "G" Then Err.Raise vbObjectError + 3405, , "�o�H�ɂ͋�Ԃ̊֘A�t�����w�肵�Ă��������B"
        Set members = AnalysisIDSet(RelationMemberKeys(CStr(link), data))
        For Each uid In members.Keys
            If used.Exists(CStr(uid)) Then Err.Raise vbObjectError + 3406, , "�������ׂ͌o�H����1��ԂŎg�p���܂��B�����͊�����Ԃւ̐ڑ��ŋL�^�ł��܂��B"
            used(CStr(uid)) = True: owner(CStr(uid)) = CStr(link)
        Next uid
    Next link
    Set edges = AnalysisPathEdges(existingPath, data)
    If Len(fromDeposit) > 0 Or Len(toWithdrawal) > 0 Then
        If Not owner.Exists(fromDeposit) Or Not owner.Exists(toWithdrawal) Then Err.Raise vbObjectError + 3406, , "�ڑ����閾�ׂ��o�H���ɂ���܂���B"
        fromNode = CStr(owner(fromDeposit)): toNode = CStr(owner(toWithdrawal))
        If fromNode = toNode Then Err.Raise vbObjectError + 3406, , "�ʋ�Ԃ̖��ׂ�ڑ����Ă��������B"
        If AnalysisSide(fromDeposit) <> "D" Or AnalysisSide(toWithdrawal) <> "W" Then Err.Raise vbObjectError + 3406, , "�ڑ��_�̓��o������������Ă��܂��B"
        If CellText(AnalysisValue(fromDeposit, TX_ID_COL)) <> CellText(AnalysisValue(toWithdrawal, TX_ID_COL)) Then Err.Raise vbObjectError + 3406, , "�ڑ��_�̌�������v���Ă��܂���B"
        If AnalysisChronology(fromDeposit, toWithdrawal) < 0 Then Err.Raise vbObjectError + 3406, , "�������O�̏o���ւ͐ڑ��ł��܂���B"
        If PathNodeReachable(edges, toNode, fromNode) Then Err.Raise vbObjectError + 3406, , "�ߋ��̓�����Ԃւ̏z�Q�Ƃ͍��܂���B����̖߂����͕ʖ��ׂ̋�ԂŋL�^�ł��܂��B"
        For Each edge In edges
            If edge("from") = fromDeposit And edge("to") = toWithdrawal Then found = True: Exit For
        Next edge
        If Not found Then
            Set edge = CreateObject("Scripting.Dictionary")
            edge("fromNode") = fromNode: edge("toNode") = toNode: edge("from") = fromDeposit: edge("to") = toWithdrawal
            edges.Add edge
        End If
    End If
    If Len(existingPath) > 0 Then RegisterAnalysisPath = existingPath Else RegisterAnalysisPath = NewInternalID("P")
    ReDim block(1 To 1 + nodes.Count + edges.Count, 1 To 12)
    block(1, 1) = RegisterAnalysisPath: block(1, 2) = "H": block(1, 3) = "P"
    If Len(existingPath) > 0 Then block(1, 7) = data(CLng(headers(existingPath)), 7)
    row = 1
    For Each link In nodes.Keys
        row = row + 1: rowByNode(CStr(link)) = row
        block(row, 1) = RegisterAnalysisPath: block(row, 2) = "L": block(row, 4) = CStr(link)
    Next link
    For Each edge In edges
        row = row + 1
        block(row, 1) = RegisterAnalysisPath: block(row, 2) = "C": block(row, 4) = edge("toNode")
        block(row, 8) = edge("fromNode"): block(row, 11) = edge("from"): block(row, 12) = edge("to")
        If rowByNode.Exists(CStr(edge("toNode"))) Then
            r = CLng(rowByNode(CStr(edge("toNode"))))
            If Not HasText(block(r, 11)) Then block(r, 11) = edge("from"): block(r, 12) = edge("to")
        End If
    Next edge
    If Len(existingPath) > 0 Then
        nextData = ReplaceAccountRows(data, block, UBound(block, 1), 1, existingPath)
        WriteRelationChanges nextData, data
    Else
        AppendRelationRows block
    End If
End Function

Private Sub AppendRelationRows(ByVal block As Variant)
    Dim ws As Worksheet, first As Long, original As String, started As Boolean
    On Error GoTo EH
    AppBegin: started = True
    Set ws = AnalysisRelationStore(): first = LastRow(ws) + 1
    ws.Cells(first, 1).Resize(UBound(block, 1), 12).Value2 = block
    MarkFileNeedsSave
    EndAppScope started
    Exit Sub
EH:
    original = Err.Description
    On Error Resume Next
    If first > 0 Then ws.Cells(first, 1).Resize(UBound(block, 1), 12).ClearContents
    EndAppScope started
    On Error GoTo 0
    Err.Raise vbObjectError + 3407, "AppendRelationRows", "�֘A�t����o�^�ł��܂���ł����B" & original
End Sub

Public Function RelationAllocationState(Optional ByVal excludeID As String = "", Optional ByVal sourceData As Variant) As Object
    Dim data As Variant, invalid As Object, totals As Object, groupW As Object, groupD As Object, result As Object
    Dim r As Long, uid As String, rid As String, amount As Variant, key As Variant, ok As Boolean
    Dim pairTotals As Object, paired As Object, other As String, members As Object
    Dim parsedDay As Variant, uncertain As Object
    If IsMissing(sourceData) Then data = ReadAnalysisRelations() Else data = sourceData
    Set invalid = CreateObject("Scripting.Dictionary"): Set totals = CreateObject("Scripting.Dictionary")
    Set groupW = CreateObject("Scripting.Dictionary"): Set groupD = CreateObject("Scripting.Dictionary")
    Set paired = CreateObject("Scripting.Dictionary"): Set pairTotals = CreateObject("Scripting.Dictionary")
    Set members = CreateObject("Scripting.Dictionary")
    For r = 2 To UBound(data, 1)
        If CellText(data(r, 2)) = "T" Then members(CellText(data(r, 1)) & "|" & CellText(data(r, 4))) = True
    Next r
    For r = 2 To UBound(data, 1)
        rid = CellText(data(r, 1)): uid = CellText(data(r, 4))
        If rid <> excludeID And CellText(data(r, 2)) = "T" Then
            amount = ParseMoney(data(r, 5), False, ok)
            If Not ok Then
                invalid(rid) = "�w��z��ǂݎ��܂���"
            ElseIf HasText(amount) Then
                If amount > 0 Then
                    If Not AnalysisIDs().Exists(uid) Then
                        invalid(rid) = "�����ׂ��폜����Ă��܂�"
                    ElseIf CellText(data(r, 9)) <> AnalysisSide(uid) Then
                        invalid(rid) = "�o���E��������������Ă��܂�"
                    ElseIf amount > CDec(AnalysisAmount(uid)) Then
                        invalid(rid) = "�����z�𒴂��Ă��܂�"
                    ElseIf Not TryStoredDate(AnalysisValue(uid, 6), parsedDay) Then
                        invalid(rid) = "�����ׂ̓��t���m�F�ł��܂���"
                    End If
                    If CellText(data(r, 9)) = "W" Then groupW(rid) = CDec(groupW(rid)) + amount Else groupD(rid) = CDec(groupD(rid)) + amount
                End If
            End If
        ElseIf rid <> excludeID And CellText(data(r, 2)) = "F" Then
            amount = ParseMoney(data(r, 5), False, ok)
            If Not ok Then
                invalid(rid) = "�ʔz����ǂݎ��܂���"
            ElseIf HasText(amount) Then
                If amount > 0 Then
                    other = CellText(data(r, 11)): paired(rid) = True
                    If Not members.Exists(rid & "|" & uid) Or Not members.Exists(rid & "|" & other) Then invalid(rid) = "�֘A�Ɋ܂܂�Ȃ��ʔz��������܂�"
                    If AnalysisSide(uid) <> "W" Or AnalysisSide(other) <> "D" Then invalid(rid) = "�ʔz���̌����ׂ��ύX�E�폜����Ă��܂�"
                    pairTotals(rid & "|" & uid) = CDec(pairTotals(rid & "|" & uid)) + amount
                    pairTotals(rid & "|" & other) = CDec(pairTotals(rid & "|" & other)) + amount
                End If
            End If
        End If
    Next r
    For Each key In RelationHeaders(data).Keys
        If CDec(groupW(key)) <> CDec(groupD(key)) Then invalid(CStr(key)) = "�w�肵���o���Ɠ����̍��v����v���Ă��܂���"
    Next key
    For r = 2 To UBound(data, 1)
        rid = CellText(data(r, 1)): uid = CellText(data(r, 4))
        If rid <> excludeID And CellText(data(r, 2)) = "T" Then
            amount = ParseMoney(data(r, 5), False, ok)
            If Not HasText(amount) Then amount = CDec(0)
            If paired.Exists(rid) And ok Then
                If CDec(pairTotals(rid & "|" & uid)) <> amount Then invalid(rid) = "�̗p�z�ƌʔz������v���Ă��܂���"
            End If
        End If
    Next r
    For r = 2 To UBound(data, 1)
        rid = CellText(data(r, 1)): uid = CellText(data(r, 4))
        If rid <> excludeID And CellText(data(r, 2)) = "T" And Not invalid.Exists(rid) Then
            amount = ParseMoney(data(r, 5), False, ok)
            If HasText(amount) Then totals(uid) = CDec(totals(uid)) + amount
        End If
    Next r
    '�S�Ώۂ𓯂����v�ŕ]�����Ă��珜�O���A�s���ŗD�悳���Ȃ��B
    For r = 2 To UBound(data, 1)
        rid = CellText(data(r, 1)): uid = CellText(data(r, 4))
        If rid <> excludeID And CellText(data(r, 2)) = "T" Then
            amount = ParseMoney(data(r, 5), False, ok)
            If ok And HasText(amount) Then
                If amount > 0 Then
                    If CDec(totals(uid)) > CDec(AnalysisAmount(uid)) Then invalid(rid) = "���̊֘A�Ƃ̎w�荇�v�������z�𒴂��Ă��܂�"
                End If
            End If
        End If
    Next r
    totals.RemoveAll
    For r = 2 To UBound(data, 1)
        rid = CellText(data(r, 1)): uid = CellText(data(r, 4))
        If rid <> excludeID And CellText(data(r, 2)) = "T" And Not invalid.Exists(rid) Then
            amount = ParseMoney(data(r, 5), False, ok)
            If HasText(amount) Then totals(uid) = CDec(totals(uid)) + amount
        End If
    Next r
    Set result = CreateObject("Scripting.Dictionary")
    '�w��ς݂̋��z�͗\��Ƃ��Ďc���B���ԏ����̖����ő��̊֘A�֓�d�g�p�����Ȃ��B
    Set uncertain = CreateObject("Scripting.Dictionary")
    AddRelationTimeStates data, excludeID, invalid, uncertain
    result.Add "invalid", invalid: result.Add "used", totals: result.Add "uncertain", uncertain
    Set RelationAllocationState = result
End Function

Private Sub AddRelationTimeStates(ByVal data As Variant, ByVal excludeID As String, ByVal invalid As Object, ByVal uncertain As Object)
    Dim groups As Object, paired As Object, group As Object, amounts As Object, r As Long, rid As String
    Dim uid As String, other As String, side As String, amount As Variant, ok As Boolean, order As Long, key As Variant
    Set groups = CreateObject("Scripting.Dictionary"): Set paired = CreateObject("Scripting.Dictionary")
    For r = 2 To UBound(data, 1)
        rid = CellText(data(r, 1))
        If rid <> excludeID And Not invalid.Exists(rid) And CellText(data(r, 2)) = "T" Then
            amount = ParseMoney(data(r, 5), False, ok)
            If ok And HasText(amount) Then
                If amount > 0 Then
                    If Not groups.Exists(rid) Then
                        Set group = CreateObject("Scripting.Dictionary")
                        group.Add "W", CreateObject("Scripting.Dictionary"): group.Add "D", CreateObject("Scripting.Dictionary")
                        groups.Add rid, group
                    End If
                    uid = CellText(data(r, 4)): side = AnalysisSide(uid)
                    Set group = groups(rid): Set amounts = group(side)
                    amounts(uid) = CDec(amounts(uid)) + amount
                End If
            End If
        End If
    Next r
    For r = 2 To UBound(data, 1)
        rid = CellText(data(r, 1))
        If rid <> excludeID And Not invalid.Exists(rid) And CellText(data(r, 2)) = "F" Then
            amount = ParseMoney(data(r, 5), False, ok)
            If ok And HasText(amount) Then
                If amount > 0 Then
                    paired(rid) = True: uid = CellText(data(r, 4)): other = CellText(data(r, 11))
                    order = AnalysisChronology(uid, other)
                    If order < 0 Then invalid(rid) = "�ʔz���̓������o�����O�ł�"
                    If order = 0 Then uncertain(rid) = True
                End If
            End If
        End If
    Next r
    For Each key In groups.Keys
        If Not invalid.Exists(key) And Not paired.Exists(key) Then
            Set group = groups(key)
            order = AdoptedTemporalOrder(group("W"), group("D"))
            If order < 0 Then invalid(key) = "�����܂łɑΉ��ł���̗p�o���z���s�����Ă��܂�"
            If order = 0 Then uncertain(key) = True
        End If
    Next key
End Sub
Public Function RelationDetails(ByVal relationID As String, Optional ByVal context As Object = Nothing) As Object
    Dim data As Variant, headers As Object, result As Object, rows As New Collection, item As Object, state As Object, invalid As Object, used As Object
    Dim r As Long, uid As String, totalW As Double, totalD As Double, anyAmount As Boolean
    If context Is Nothing Then Set context = NewRelationContext()
    If context.Exists("detail:" & relationID) Then Set RelationDetails = context("detail:" & relationID): Exit Function
    data = context("data"): Set headers = context("headers")
    Set result = CreateObject("Scripting.Dictionary"): result.Add "rows", rows: result("id") = relationID
    result("sourceContext") = "": result("recordedAt") = ""
    result("kind") = "": result("memo") = "": result("status") = "�֘A�t������������Ă��܂�": result("out") = 0#: result("in") = 0#
    If Not headers.Exists(relationID) Then Set RelationDetails = result: Exit Function
    r = CLng(headers(relationID)): result("kind") = CellText(data(r, 3)): result("memo") = CellText(data(r, 7))
    result("sourceContext") = CellText(data(r, 10)): result("recordedAt") = CellText(data(r, 9))
    Set state = context("allocation"): Set invalid = state("invalid")
    Set state = RelationAllocationState(relationID, data): Set used = state("used")
    For r = 2 To UBound(data, 1)
        If CellText(data(r, 1)) = relationID And (CellText(data(r, 2)) = "T" Or CellText(data(r, 2)) = "L") Then
            Set item = CreateObject("Scripting.Dictionary"): uid = CellText(data(r, 4))
            item("id") = uid: item("row") = r: item("type") = CellText(data(r, 2))
            item("editState") = CellText(data(r, 7))
            item("amount") = data(r, 5): item("draft") = data(r, 6): item("side") = CellText(data(r, 9))
            item("label") = CellText(data(r, 10)): item("available") = 0#: item("status") = ""
            item("from") = CellText(data(r, 11)): item("to") = CellText(data(r, 12))
            If CellText(data(r, 2)) = "T" Then
                If AnalysisIDs().Exists(uid) Then
                    item("label") = AnalysisAccountText(uid): item("available") = CDec(AnalysisAmount(uid)) - CDec(used(uid))
                    If item("available") < 0 Then item("available") = CDec(0)
                    totalW = totalW + Val(CellText(AnalysisValue(uid, 8))): totalD = totalD + Val(CellText(AnalysisValue(uid, 9)))
                    If CellText(data(r, 8)) <> CellText(AnalysisValue(uid, TX_ID_COL)) Then item("status") = "�������ύX����Ă��܂�"
                    If CellText(data(r, 9)) <> AnalysisSide(uid) Then item("status") = "�o���E�������ύX����Ă��܂�"
                    If context("draftAccounts").Exists(CellText(AnalysisValue(uid, TX_ID_COL))) Then item("status") = CStr(item("status")) & " ���̌����͒����r���i�o�^�ς݂�\���j"
                Else
                    item("status") = "�����ׂ͍폜�ς�"
                End If
                If HasText(data(r, 5)) Then
                    If IsNumeric(data(r, 5)) Then
                        If CDec(data(r, 5)) > 0 Then anyAmount = True
                    End If
                End If
            Else
                If Not headers.Exists(uid) Then item("status") = "��Ԃ̊֘A�t���͉����ς�"
            End If
            rows.Add item
        End If
    Next r
    result("out") = totalW: result("in") = totalD
    If invalid.Exists(relationID) Then
        If anyAmount Then result("status") = "�w��z�͌v�Z�ΏۊO�F" & CStr(invalid(relationID)) Else result("status") = "�����ׂ͍폜�ς�"
    ElseIf result("kind") = "P" Then
        result("status") = AnalysisNetworkSummary(relationID, data)
    ElseIf anyAmount Then
        result("status") = "���z�w�肠��"
        If context("allocation")("uncertain").Exists(relationID) Then result("status") = result("status") & "�E�������m��"
    Else
        result("status") = "�֘A�t���̂�"
    End If
    context.Add "detail:" & relationID, result
    Set RelationDetails = result
End Function

Public Sub SetRelationMemo(ByVal relationID As String, ByVal memo As String)
    PersistAnalysisEdit relationID, "", memo
End Sub
Public Sub SetRelationDraftAmount(ByVal relationID As String, ByVal uid As String, ByVal value As Variant)
    PersistAnalysisEdit relationID, uid, value
End Sub
Public Sub InitializeRelationAmounts(ByVal relationID As String, Optional ByVal context As Object = Nothing)
    '�̗p�l�̏����\���͋��ʓǂݏo�����s���B��ʂ��J���������ł͕ύX���Ȃ��B
End Sub
Public Function CommitRelationAmounts(ByVal relationID As String) As String
    CommitRelationAmounts = CommitRelationAllocation(relationID, "T")
End Function
Public Sub RemoveAnalysisRelation(ByVal relationID As String)
    Dim data As Variant, nextData As Variant, noRows As Variant, removed As Variant, drafts As Variant, r As Long, c As Long, n As Long
    Dim writing As Boolean, message As String, restoreIssue As String, started As Boolean
    On Error GoTo EH
    CaptureAnalysisPanelInputs
    drafts = AnalysisDraftData(): data = ReadStoredAnalysisRelations()
    nextData = ReplaceAccountRows(data, noRows, 0, 1, relationID)
    ReDim removed(1 To UBound(data, 1), 1 To 12)
    For r = 2 To UBound(data, 1)
        If CellText(data(r, 1)) = relationID Then
            n = n + 1
            For c = 1 To 12: removed(n, c) = data(r, c): Next c
        End If
    Next r
    If n = 0 Then Exit Sub
    AppBegin: started = True: writing = True
    WriteStore AnalysisRelationStore(), nextData
    RemoveAnalysisDrafts relationID
    ClearAnalysisBindings GetSheet(SH_OUTPUT_TX)
    MarkFileNeedsSave
    mRemovedRelation = FitStoreRows(removed, n): mRemovedDrafts = drafts
    writing = False
    EndAppScope started
    Exit Sub
EH:
    message = Err.Description
    On Error Resume Next
    If writing Then
        Err.Clear: WriteStore AnalysisRelationStore(), data
        If Err.Number <> 0 Then restoreIssue = " �o�^�l": Err.Clear
        RestoreAnalysisDraftData drafts
        If Err.Number <> 0 Then restoreIssue = restoreIssue & " ������"
    End If
    EndAppScope started
    On Error GoTo 0
    If Len(restoreIssue) > 0 Then message = "�����������F" & restoreIssue & "�B�㏑�������ۑ��ς݃u�b�N�֖߂��Ă��������B" & message
    Err.Raise vbObjectError + 3425, , message
End Sub
Public Function CanUndoRelationRemoval() As Boolean
    CanUndoRelationRemoval = IsArray(mRemovedRelation)
End Function

Public Sub UndoAnalysisRelationRemoval()
    Dim data As Variant, drafts As Variant, rid As String, writing As Boolean, message As String, started As Boolean, restoring As String
    On Error GoTo EH
    If Not IsArray(mRemovedRelation) Then Exit Sub
    data = ReadStoredAnalysisRelations(): drafts = AnalysisDraftData(): rid = CellText(mRemovedRelation(1, 1))
    AppBegin: started = True: writing = True
    AppendRelationRows mRemovedRelation
    RestoreRemovedAnalysisDrafts rid, mRemovedDrafts
    writing = False: mRemovedRelation = Empty: mRemovedDrafts = Empty
    EndAppScope started
    ShowAnalysisRecords
    Exit Sub
EH:
    message = Err.Description
    On Error Resume Next
    If writing Then
        Err.Clear: WriteStore AnalysisRelationStore(), data
        If Err.Number <> 0 Then restoring = " �o�^�l": Err.Clear
        RestoreAnalysisDraftData drafts
        If Err.Number <> 0 Then restoring = restoring & " ������"
        If Len(restoring) > 0 Then message = "�������������ł��i" & restoring & "�j�B�㏑�������ۑ��ς݃u�b�N�֖߂��Ă��������B" & message
    End If
    EndAppScope started
    On Error GoTo 0
    AnalysisPanelMessage "�֘A�t����߂��܂���ł����B" & message
End Sub
Public Sub ClearAnalysisUndo()
    mRemovedDrafts = Empty
    mRemovedRelation = Empty
End Sub

Public Function AnalysisRelationsList() As Collection
    Dim result As New Collection, data As Variant, headers As Object, compositions As Object, key As Variant, item As Object
    data = ReadAnalysisRelations(): Set headers = RelationHeaders(data): Set compositions = RelationCompositions(data)
    For Each key In headers.Keys
        Set item = CreateObject("Scripting.Dictionary")
        item("id") = CStr(key): item("kind") = CellText(data(CLng(headers(key)), 3)): item("memo") = CellText(data(CLng(headers(key)), 7))
        item("ids") = CStr(compositions(key)): result.Add item
    Next key
    Set AnalysisRelationsList = result
End Function

Public Sub WriteRelationChanges(ByVal nextData As Variant, ByVal oldData As Variant)
    Dim ws As Worksheet, started As Boolean, message As String, original As Variant, writing As Boolean
    On Error GoTo EH
    EnsureAnalysisDraftStored
    original = ReadStoredAnalysisRelations()
    AppBegin: started = True
    Set ws = AnalysisRelationStore(): writing = True
    WriteStore ws, UnprojectAnalysisDrafts(nextData)
    MarkFileNeedsSave
    writing = False
    EndAppScope started
    Exit Sub
EH:
    message = Err.Description
    On Error Resume Next
    If writing Then
        Err.Clear: WriteStore ws, original
        If Err.Number <> 0 Then message = message & " �o�^�l�̕������������ł��B�㏑�������ۑ��ς݃u�b�N�ɖ߂��Ă��������B"
    End If
    EndAppScope started
    On Error GoTo 0
    Err.Raise vbObjectError + 3408, "WriteRelationChanges", message
End Sub
Private Function RelationCompositions(ByVal data As Variant) As Object
    Dim result As Object, r As Long, key As String, members As String
    Set result = CreateObject("Scripting.Dictionary")
    For r = 2 To UBound(data, 1)
        key = CellText(data(r, 1))
        If (CellText(data(r, 2)) = "T" Or CellText(data(r, 2)) = "L") Then
            members = CStr(result(key))
            If Len(members) > 0 Then members = members & "|"
            result(key) = members & CellText(data(r, 4))
        End If
    Next r
    Set RelationCompositions = result
End Function

Public Function NewRelationContext() As Object
    Dim result As Object, data As Variant
    Set result = CreateObject("Scripting.Dictionary")
    data = ReadAnalysisRelations()
    result.Add "data", data: result.Add "headers", RelationHeaders(data)
    result.Add "allocation", RelationAllocationState("", data)
    result.Add "draftAccounts", AnalysisDraftAccounts()
    Set NewRelationContext = result
End Function

Private Function RelationHeaderRow(ByVal relationID As String, ByVal data As Variant) As Long
    Dim headers As Object
    Set headers = RelationHeaders(data)
    If headers.Exists(relationID) Then RelationHeaderRow = CLng(headers(relationID))
End Function

Private Function PathConnectionMatches(ByVal id As String, ByVal data As Variant, ByVal fromID As String, ByVal toID As String) As Boolean
    Dim r As Long, last As Long
    For r = 2 To UBound(data, 1)
        If CellText(data(r, 1)) = id And CellText(data(r, 2)) = "L" Then last = r
    Next r
    If last > 0 Then PathConnectionMatches = (CellText(data(last, 11)) = fromID And CellText(data(last, 12)) = toID)
End Function

Private Function AnalysisDraftAccounts() As Object
    Dim result As Object, data As Variant, r As Long, id As String
    Set result = CreateObject("Scripting.Dictionary")
    On Error GoTo Done
    If SheetExists(SH_PARKED_DRAFTS) Then
        data = ReadStore(GetSheet(SH_PARKED_DRAFTS), 14)
        Set result = DraftHeaderRows(data)
    End If
    If InputIsDirty Then
        id = CurrentEditAccountID()
        If Len(id) > 0 Then result(id) = True
    End If
Done:
    Set AnalysisDraftAccounts = result
End Function

Public Function AnalysisPathEdges(ByVal pathID As String, ByVal data As Variant) As Collection
    Dim edges As New Collection, seen As Object, owners As Object, nodes As Object, node As Variant, uid As Variant
    Dim r As Long, fromID As String, toID As String, key As String, edge As Object
    Set seen = CreateObject("Scripting.Dictionary"): Set owners = CreateObject("Scripting.Dictionary")
    Set nodes = AnalysisIDSet(RelationMemberKeys(pathID, data))
    For Each node In nodes.Keys
        For Each uid In Split(RelationMemberKeys(CStr(node), data), "|")
            If Len(CStr(uid)) > 0 Then owners(CStr(uid)) = CStr(node)
        Next uid
    Next node
    For r = 2 To UBound(data, 1)
        If CellText(data(r, 1)) = pathID Then
            If CellText(data(r, 2)) = "L" Or CellText(data(r, 2)) = "C" Then
                fromID = CellText(data(r, 11)): toID = CellText(data(r, 12))
                key = fromID & "|" & toID
                If Len(fromID) > 0 And Len(toID) > 0 And Not seen.Exists(key) Then
                    Set edge = CreateObject("Scripting.Dictionary")
                    edge("from") = fromID: edge("to") = toID
                    edge("fromNode") = CellText(owners(fromID)): edge("toNode") = CellText(owners(toID))
                    edges.Add edge: seen(key) = True
                End If
            End If
        End If
    Next r
    Set AnalysisPathEdges = edges
End Function

Private Function PathNodeReachable(ByVal edges As Collection, ByVal startNode As String, ByVal finishNode As String) As Boolean
    Dim seen As Object, queue As New Collection, node As String, edge As Object, i As Long
    Set seen = CreateObject("Scripting.Dictionary"): seen(startNode) = True: queue.Add startNode
    i = 1
    Do While i <= queue.Count
        node = CStr(queue(i)): i = i + 1
        If node = finishNode Then PathNodeReachable = True: Exit Function
        For Each edge In edges
            If CStr(edge("fromNode")) = node Then
                If Not seen.Exists(CStr(edge("toNode"))) Then seen(CStr(edge("toNode"))) = True: queue.Add CStr(edge("toNode"))
            End If
        Next edge
    Loop
End Function

Public Function AnalysisNetworkSummary(ByVal pathID As String, ByVal data As Variant) As String
    Dim edges As Collection, edge As Object, nodes As Object, node As Variant, members As Object, uid As Variant
    Dim incoming As Object, outgoing As Object, roots As Object, rootAmount As Variant, leafAmount As Variant
    Dim distinctEdges As Object, edgeKey As String
    Dim branches As Object, merges As Object, branchCount As Long, mergeCount As Long, returnSeen As Boolean, incomplete As Boolean
    Set edges = AnalysisPathEdges(pathID, data): Set nodes = AnalysisIDSet(RelationMemberKeys(pathID, data))
    Set incoming = CreateObject("Scripting.Dictionary"): Set outgoing = CreateObject("Scripting.Dictionary")
    Set roots = CreateObject("Scripting.Dictionary"): Set branches = CreateObject("Scripting.Dictionary"): Set merges = CreateObject("Scripting.Dictionary")
    Set distinctEdges = CreateObject("Scripting.Dictionary")
    rootAmount = CDec(0): leafAmount = CDec(0)
    For Each edge In edges
        incoming(CStr(edge("to"))) = True: outgoing(CStr(edge("from"))) = True
        edgeKey = CStr(edge("fromNode")) & "|" & CStr(edge("toNode"))
        If Not distinctEdges.Exists(edgeKey) Then
            branches(CStr(edge("fromNode"))) = CLng(branches(CStr(edge("fromNode")))) + 1
            merges(CStr(edge("toNode"))) = CLng(merges(CStr(edge("toNode")))) + 1
            distinctEdges(edgeKey) = True
        End If
        If AnalysisSide(CStr(edge("from"))) <> "D" Or AnalysisSide(CStr(edge("to"))) <> "W" Then
            incomplete = True
        Else
            If CellText(AnalysisValue(CStr(edge("from")), TX_ID_COL)) <> CellText(AnalysisValue(CStr(edge("to")), TX_ID_COL)) Then incomplete = True
            If AnalysisChronology(CStr(edge("from")), CStr(edge("to"))) < 0 Then incomplete = True
        End If
    Next edge
    For Each node In nodes.Keys
        Set members = AnalysisIDSet(RelationMemberKeys(CStr(node), data))
        If members.Count = 0 Then incomplete = True
        For Each uid In members.Keys
            If Not AnalysisIDs().Exists(CStr(uid)) Then incomplete = True
            If AnalysisSide(CStr(uid)) = "W" And Not incoming.Exists(CStr(uid)) Then
                rootAmount = rootAmount + CDec(AnalysisAmount(CStr(uid)))
                roots(CellText(AnalysisValue(CStr(uid), TX_ID_COL))) = True
            End If
        Next uid
    Next node
    For Each node In nodes.Keys
        Set members = AnalysisIDSet(RelationMemberKeys(CStr(node), data))
        If members.Count = 0 Then incomplete = True
        For Each uid In members.Keys
            If Not AnalysisIDs().Exists(CStr(uid)) Then incomplete = True
            If AnalysisSide(CStr(uid)) = "D" And Not outgoing.Exists(CStr(uid)) Then
                leafAmount = leafAmount + CDec(AnalysisAmount(CStr(uid)))
                If roots.Exists(CellText(AnalysisValue(CStr(uid), TX_ID_COL))) Then returnSeen = True
            End If
        Next uid
    Next node
    For Each node In branches.Keys: If CLng(branches(node)) > 1 Then branchCount = branchCount + 1
    Next node
    For Each node In merges.Keys: If CLng(merges(node)) > 1 Then mergeCount = mergeCount + 1
    Next node
    AnalysisNetworkSummary = nodes.Count & "��ԁE" & edges.Count & "�ڑ� / ����" & branchCount & "�E����" & mergeCount
    If incomplete Then
        AnalysisNetworkSummary = AnalysisNetworkSummary & " / ��ԁE�����ׂ̕ύX�܂��͍폜����B�N�_�E�I�[�z�͖��Z�o"
        Exit Function
    End If
    AnalysisNetworkSummary = AnalysisNetworkSummary & " / �N�_�o�� " & Format$(rootAmount, "#,##0") & "�~�E�I�[���� " & Format$(leafAmount, "#,##0") & "�~�i�����׊z�j"
    If returnSeen Then AnalysisNetworkSummary = AnalysisNetworkSummary & " / �N�_�Ɠ��������ւ̖߂肠��"
    If incomplete Then AnalysisNetworkSummary = AnalysisNetworkSummary & " / �ڑ������ׂ̕ύX�E�폜����"
    AnalysisNetworkSummary = AnalysisNetworkSummary & " / �ڑ��Ԃ̔z���͖��w��E��Ԋz�͉��Z���܂���"
End Function

Public Function AdoptedAnalysisAggregates(ByVal scope As Object, ByVal flows As Boolean) As Collection
    Dim data As Variant, state As Object, invalid As Object, groups As Object, item As Object, result As New Collection
    Dim r As Long, relationID As String, uid As String, key As String, amount As Variant, label As String
    Dim groupIDs As Object, member As Variant, outgoing As Object, incoming As Object, selectedRelations As Object, paired As Object, otherID As String
    data = ReadAnalysisRelations(): Set state = RelationAllocationState("", data): Set invalid = state("invalid")
    Set groups = CreateObject("Scripting.Dictionary"): Set selectedRelations = CreateObject("Scripting.Dictionary")
    Set paired = CreateObject("Scripting.Dictionary")
    If flows Then
        For r = 2 To UBound(data, 1)
            If CellText(data(r, 2)) = "T" And scope.Exists(CellText(data(r, 4))) Then selectedRelations(CellText(data(r, 1))) = True
        Next r
        For r = 2 To UBound(data, 1)
            relationID = CellText(data(r, 1))
            If CellText(data(r, 2)) = "F" And HasText(data(r, 5)) And Not invalid.Exists(relationID) And selectedRelations.Exists(relationID) Then
                amount = CDec(data(r, 5))
                If amount > 0 Then
                    uid = CellText(data(r, 4)): otherID = CellText(data(r, 11)): paired(relationID) = True
                    key = relationID & ">" & AnalysisPersonID(uid) & ">" & AnalysisPersonID(otherID)
                    If Not groups.Exists(key) Then
                        Set item = CreateObject("Scripting.Dictionary")
                        item("key") = key: item("count") = 0: item("out") = CDec(0): item("in") = CDec(0): item("ids") = ""
                        groups.Add key, item: result.Add item
                    End If
                    Set item = groups(key)
                    item("out") = CDec(item("out")) + amount: item("in") = CDec(item("in")) + amount
                    item("ids") = CStr(item("ids")) & uid & "|" & otherID & "|"
                    item("count") = AnalysisIDSet(CStr(item("ids"))).Count
                End If
            End If
        Next r
    End If
    For r = 2 To UBound(data, 1)
        relationID = CellText(data(r, 1)): uid = CellText(data(r, 4))
        If CellText(data(r, 2)) = "T" And HasText(data(r, 5)) And Not invalid.Exists(relationID) Then
            If (Not flows And scope.Exists(uid)) Or (flows And selectedRelations.Exists(relationID) And Not paired.Exists(relationID)) Then
                amount = CDec(data(r, 5))
                If amount > 0 Then
                    If flows Then key = relationID Else key = AnalysisPersonID(uid)
                    If Not groups.Exists(key) Then
                        Set item = CreateObject("Scripting.Dictionary")
                        item("key") = key: item("count") = 0: item("out") = CDec(0): item("in") = CDec(0): item("ids") = ""
                        item("label") = DisplayPersonWithRelationship(CellText(AnalysisValue(uid, 3)), CellText(AnalysisValue(uid, 14)))
                        groups.Add key, item: result.Add item
                    End If
                    Set item = groups(key): item("count") = CLng(item("count")) + 1
                    If AnalysisSide(uid) = "W" Then item("out") = CDec(item("out")) + amount Else item("in") = CDec(item("in")) + amount
                    item("ids") = CStr(item("ids")) & uid & "|"
                End If
            End If
        End If
    Next r
    If flows Then
        For Each item In result
            Set groupIDs = AnalysisIDSet(CStr(item("ids")))
            Set outgoing = CreateObject("Scripting.Dictionary"): Set incoming = CreateObject("Scripting.Dictionary")
            For Each member In groupIDs.Keys
                uid = CStr(member)
                label = DisplayPersonWithRelationship(CellText(AnalysisValue(uid, 3)), CellText(AnalysisValue(uid, 14)))
                If AnalysisSide(uid) = "W" Then outgoing(label) = True Else incoming(label) = True
            Next member
            item("label") = Join(outgoing.Keys, "�E") & " �� " & Join(incoming.Keys, "�E")
        Next item
    End If
    Set AdoptedAnalysisAggregates = result
End Function

Public Function RelationPairRows(ByVal relationID As String, Optional ByVal initialize As Boolean = False, Optional ByVal context As Object = Nothing) As Collection
    Dim data As Variant, result As New Collection, r As Long, uid As Variant, other As Variant, members As Object
    Dim item As Object, known As Object, possible As Long, wCount As Long, dCount As Long
    If context Is Nothing Then data = ReadAnalysisRelations() Else data = context("data")
    Set known = CreateObject("Scripting.Dictionary")
    For r = 2 To UBound(data, 1)
        If CellText(data(r, 1)) = relationID And CellText(data(r, 2)) = "F" Then
            Set item = CreateObject("Scripting.Dictionary")
            item("type") = "T": item("from") = CellText(data(r, 4)): item("to") = CellText(data(r, 11))
            item("editState") = CellText(data(r, 7))
            item("amount") = data(r, 5): item("draft") = data(r, 6)
            item("ids") = CStr(item("from")) & "|" & CStr(item("to"))
            known(CStr(item("from")) & "~" & CStr(item("to"))) = True: result.Add item
        End If
    Next r
    If initialize Then
        Set members = AnalysisIDSet(RelationMemberKeys(relationID, data))
        For Each uid In members.Keys
            If AnalysisSide(CStr(uid)) = "W" Then
                wCount = wCount + 1
            ElseIf AnalysisSide(CStr(uid)) = "D" Then
                dCount = dCount + 1
            End If
        Next uid
        If CDbl(wCount) * dCount > 10000 Then Err.Raise vbObjectError + 3410, , "�ʔz���̑g�������������߁A�֘A�������Ȃ܂Ƃ܂�ɕ����ē��͂��Ă��������B�֘A���̂��͕̂ێ����Ă��܂��B"
        possible = wCount * dCount
        If possible > 0 Then
            For Each uid In members.Keys
                If AnalysisSide(CStr(uid)) = "W" Then
                    For Each other In members.Keys
                        If AnalysisSide(CStr(other)) = "D" Then
                            If Not known.Exists(CStr(uid) & "~" & CStr(other)) Then
                                Set item = CreateObject("Scripting.Dictionary")
                                item("type") = "T": item("from") = CStr(uid): item("to") = CStr(other)
                                item("amount") = Empty: item("draft") = Empty: item("editState") = ""
                                item("ids") = CStr(uid) & "|" & CStr(other)
                                result.Add item
                            End If
                        End If
                    Next other
                End If
            Next uid

        End If
        Set RelationPairRows = result
    Else
        Set RelationPairRows = result
    End If
End Function

Public Sub SetRelationPairDraft(ByVal relationID As String, ByVal fromID As String, ByVal toID As String, ByVal value As Variant)
    PersistAnalysisEdit relationID, fromID & "~" & toID, value
End Sub
Public Function CommitRelationPairs(ByVal relationID As String) As String
    CommitRelationPairs = CommitRelationAllocation(relationID, "F")
End Function

Private Function CommitRelationAllocation(ByVal rid As String, ByVal mode As String) As String
    Dim data As Variant, original As Variant, block As Variant, nextData As Variant, oldDraft As Variant
    Dim headers As Object, members As Object, state As Object, used As Object, totals As Object, pairs As Collection, item As Object
    Dim r As Long, c As Long, n As Long, uid As String, other As String, value As Variant, amount As Variant
    Dim ok As Boolean, sumW As Variant, sumD As Variant, started As Boolean, writing As Boolean, message As String, restoring As String
    On Error GoTo EH
    If Not HasAnalysisAmountEdits(rid, mode) Then Exit Function
    If AnalysisAmountDraftIsStale(rid, mode) Then
        CommitRelationAllocation = "�ȑO�̗̍p�z����ɂ������͂ł��B�ǉ�����́u�ȑO�̋��z���͂�����g���v�őI��ł��甽�f�ł��܂��B": Exit Function
    End If
    original = ReadStoredAnalysisRelations(): data = ReadAnalysisRelations(): Set headers = RelationHeaders(data)
    If Not headers.Exists(rid) Then CommitRelationAllocation = "���̊֘A�͉����ς݂ł��B���͕͂ێ����Ă��܂��B": Exit Function
    If CellText(data(CLng(headers(rid)), 3)) <> "G" Then Exit Function
    Set members = AnalysisIDSet(RelationMemberKeys(rid, data))
    Set state = RelationAllocationState(rid, data): Set used = state("used")
    Set totals = CreateObject("Scripting.Dictionary")
    ReDim block(1 To UBound(data, 1) + members.Count * 2, 1 To 12)
    n = 0
    For r = 2 To UBound(data, 1)
        If CellText(data(r, 1)) = rid And CellText(data(r, 2)) <> "F" Then
            n = n + 1
            For c = 1 To 12: block(n, c) = data(r, c): Next c
        End If
    Next r
    If mode = "F" Then
        Set pairs = RelationPairRows(rid, False)
        '�ʔz���͓��͍ς݁E�̗p�ς݂̑g�����������A�S�g�����̋�s��ۑ����Ȃ��B
        For Each item In pairs
            uid = CStr(item("from")): other = CStr(item("to"))
            amount = ParseMoney(item("draft"), False, ok)
            If Not ok Then CommitRelationAllocation = "�ʔz����0�ȏ�̐����œ��͂��Ă��������B���͓r���͕ۑ��ł��܂��B": Exit Function
            If HasText(amount) Then
                If amount > 0 Then
                    If Not members.Exists(uid) Or Not members.Exists(other) Then CommitRelationAllocation = "�֘A�Ɋ܂܂�Ȃ��z���ł��B���͕͂ێ����܂��B": Exit Function
                    If AnalysisSide(uid) <> "W" Or AnalysisSide(other) <> "D" Then CommitRelationAllocation = "���̔z�����w�肵�������ׂ��ύX�E�폜����Ă��܂��B": Exit Function
                End If
                totals(uid) = CDec(totals(uid)) + amount: totals(other) = CDec(totals(other)) + amount
                n = n + 1
                block(n, 1) = rid: block(n, 2) = "F": block(n, 4) = uid: block(n, 11) = other: block(n, 5) = amount
            End If
        Next item
    End If
    sumW = CDec(0): sumD = CDec(0)
    For r = 1 To n
        If CellText(block(r, 2)) = "T" Then
            uid = CellText(block(r, 4))
            If mode = "F" Then
                amount = CDec(totals(uid)): ok = True
            Else
                amount = ParseMoney(block(r, 6), False, ok)
            End If
            If Not ok Then CommitRelationAllocation = "�w��z��0�ȏ�̐����œ��͂��Ă��������B���͓r���͕ۑ��ł��܂��B": Exit Function
            If HasText(amount) Then
                If amount > 0 Then
                    If Not AnalysisIDs().Exists(uid) Then CommitRelationAllocation = "���̎w��z�̌����ׂ��폜����Ă��܂��B0�E�󗓂ɂ��ĉ����ł��܂��B": Exit Function
                    If Len(AnalysisSide(uid)) = 0 Then CommitRelationAllocation = "�o���E�����𔻕ʂł��Ȃ����ׂł��B": Exit Function
                    If amount + CDec(used(uid)) > CDec(AnalysisAmount(uid)) Then CommitRelationAllocation = "���̊֘A�Ƃ̗̍p�z���v�������׊z�𒴂��܂��B���̊֘A�̓��͕͂ێ����܂��B": Exit Function
                    If AnalysisSide(uid) = "W" Then sumW = sumW + amount Else sumD = sumD + amount
                End If
            End If
            block(r, 5) = amount
            If AnalysisIDs().Exists(uid) Then block(r, 8) = AnalysisValue(uid, TX_ID_COL): block(r, 9) = AnalysisSide(uid)
        End If
        If CellText(block(r, 2)) = "H" Then block(r, 12) = CStr(CDec(RelationAmountStamp(rid, original)) + CDec(1))
    Next r
    If sumW <> sumD Then CommitRelationAllocation = "�w�肷��o���Ɠ����̍��v�����낦�Ă��������B���͂ƃ����͕ێ����܂��B": Exit Function
    nextData = ReplaceAccountRows(original, UnprojectAnalysisDrafts(FitStoreRows(block, n)), n, 1, rid)
    oldDraft = AnalysisDraftData()
    AppBegin "�w��z�𔽉f���Ă��܂�...": started = True: writing = True
    If mode = "T" Then PreservePreviousPairAmounts rid, original
    WriteStore AnalysisRelationStore(), nextData
    RemoveAnalysisDrafts rid, mode
    MarkFileNeedsSave
    writing = False
    EndAppScope started
    Exit Function
EH:
    message = Err.Description
    If writing Then
        On Error Resume Next
        Err.Clear
        WriteStore AnalysisRelationStore(), original
        If Err.Number <> 0 Then restoring = "�o�^�l": Err.Clear
        RestoreAnalysisDraftData oldDraft
        If Err.Number <> 0 Then restoring = restoring & " ������"
        On Error GoTo 0
    End If
    EndAppScope started
    CommitRelationAllocation = "�w��z�𔽉f�ł��܂���ł����B" & message
    If Len(restoring) > 0 Then CommitRelationAllocation = "�������������ł��i" & restoring & "�j�B�㏑�������ۑ��ς݃u�b�N�֖߂��Ă��������B" & message
End Function

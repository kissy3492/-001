Attribute VB_Name = "modInputPending"
Option Explicit

Private mParkedAccounts As Object

Public Sub ResetPendingAccountCache()
    Set mParkedAccounts = Nothing
End Sub

Public Function PendingInputAccountCount() As Long
    Dim data As Variant, r As Long, key As String
    If mParkedAccounts Is Nothing Then
        Set mParkedAccounts = CreateObject("Scripting.Dictionary")
        If SheetExists(SH_PARKED_DRAFTS) Then
            data = ReadStore(GetSheet(SH_PARKED_DRAFTS), 14)
            For r = 2 To UBound(data, 1)
                If CellText(data(r, 2)) = "����" Then mParkedAccounts(CellText(data(r, 1))) = True
            Next r
        End If
    End If
    PendingInputAccountCount = mParkedAccounts.Count
    key = CurrentDraftKey()
    If InputIsDirty Then
        If Not mParkedAccounts.Exists(key) Then PendingInputAccountCount = PendingInputAccountCount + 1
    ElseIf Len(key) > 0 Then
        If mParkedAccounts.Exists(key) Then PendingInputAccountCount = PendingInputAccountCount - 1
    End If
End Function

Public Function PendingInputSummary() As String
    Dim count As Long
    count = PendingInputAccountCount()
    If count > 0 Then PendingInputSummary = "���[�֖����f�F" & count & "����"
End Function

Public Sub FocusNextUnfinishedInput()
    Dim ws As Worksheet, raw As Variant, r As Long, c As Long, cy As Long, cm As Long, cd As Long, previous As String
    Dim parsed As Variant, issue As String, first As Long, firstColumn As Long, start As Long, hasValues As Boolean
    Set ws = GetSheet(SH_INPUT)
    If Not ActiveSheet Is ws Then ShowInputSheet
    start = ActiveCell.Row
    raw = ws.Cells(TX_FIRST_ROW, COL_TX_YEAR).Resize(Application.Max(1, LastInputDataRow() - TX_FIRST_ROW + 1), 10).Value2
    For r = 1 To UBound(raw, 1)
        hasValues = False
        For c = 1 To 10
            If IsError(raw(r, c)) Or HasText(raw(r, c)) Then hasValues = True: Exit For
        Next c
        If hasValues Then
            If Not TryReadInputTransaction(raw, r, cy, cm, cd, previous, parsed, issue, c) Then
                If first = 0 Then first = TX_FIRST_ROW + r - 1: firstColumn = c
                If TX_FIRST_ROW + r - 1 > start Then
                    SafeSelectCell ws, ws.Cells(TX_FIRST_ROW + r - 1, c).Address
                    SetInputStatus issue
                    Exit Sub
                End If
            End If
        End If
    Next r
    If first > 0 Then
        SafeSelectCell ws, ws.Cells(first, firstColumn).Address
    Else
        SetInputStatus "���ׂۗ̕��ӏ��͂���܂���B�������E�c���̖����f���o�^��������m�F�ł��܂��B"
    End If
End Sub

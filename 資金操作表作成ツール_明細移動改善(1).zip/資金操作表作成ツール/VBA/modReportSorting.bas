Attribute VB_Name = "modReportSorting"
Option Explicit

Private mSortSheet As String

Public Function ShowReportColumnSort(ByVal target As Range) As Boolean
    Dim menu As Object, ws As Worksheet, header As Long, columns As Long
    On Error GoTo Done
    Set ws = target.Worksheet
    If Not ReportSortRange(ws, header, columns) Then Exit Function
    If target.Row <> header Or target.Column > columns Then Exit Function
    mSortSheet = ws.Name
    Set menu = Application.CommandBars.Add(Position:=5, Temporary:=True)
    AddReportSortItems menu, target.Column
    ShowReportColumnSort = True
    menu.ShowPopup
Done:
    On Error Resume Next
    If Not menu Is Nothing Then menu.Delete
    On Error GoTo 0
End Function

Public Sub ShowCurrentReportSortMenu()
    Dim ws As Worksheet, menu As Object, fieldMenu As Object, header As Long, columns As Long, c As Long
    On Error GoTo Done
    If Not ActiveWorkbook Is ThisWorkbook Then Exit Sub
    Set ws = ActiveSheet
    If Not ReportSortRange(ws, header, columns) Then Exit Sub
    mSortSheet = ws.Name
    Set menu = Application.CommandBars.Add(Position:=5, Temporary:=True)
    For c = 1 To columns
        Set fieldMenu = AddInputSubMenu(menu, CellText(ws.Cells(header, c).Value2))
        AddReportSortItems fieldMenu, c
    Next c
    menu.ShowPopup
Done:
    On Error Resume Next
    If Not menu Is Nothing Then menu.Delete
    On Error GoTo 0
End Sub

Private Function ReportSortRange(ByVal ws As Worksheet, ByRef header As Long, ByRef columns As Long) As Boolean
    Select Case ws.Name
        Case SH_OUTPUT_TX: header = CashReportHeader(ws): columns = 13
        Case SH_SHOP_TARGET: header = 1: columns = 8
        Case Else: Exit Function
    End Select
    ReportSortRange = True
End Function

Private Sub AddReportSortItems(ByVal menu As Object, ByVal column As Long)
    Dim button As Object
    Set button = menu.Controls.Add(Type:=1)
    button.Caption = "����": button.Tag = CStr(column) & "|1": button.OnAction = MacroRef("ApplyReportSortChoice")
    Set button = menu.Controls.Add(Type:=1)
    button.Caption = "�~��": button.Tag = CStr(column) & "|2": button.OnAction = MacroRef("ApplyReportSortChoice")
End Sub

Public Sub ApplyReportSortChoice()
    Dim choice As Variant, ws As Worksheet, target As Range, filters As Collection
    Dim header As Long, columns As Long, lastR As Long, sortColumn As Long, lastColumn As Long, r As Long
    Dim order As XlSortOrder, before As Variant, keys As Variant, started As Boolean, writing As Boolean, sorted As Boolean
    Dim message As String, restoring As String, selectedID As String, selectedRow As Long, keyValue As Variant
    On Error GoTo EH
    If Not ActiveWorkbook Is ThisWorkbook Then Exit Sub
    If ActiveSheet.Name <> mSortSheet Then Exit Sub
    Set ws = GetSheet(mSortSheet)
    If Not ReportSortRange(ws, header, columns) Then Exit Sub
    choice = Split(CStr(Application.CommandBars.ActionControl.Tag), "|")
    sortColumn = CLng(choice(0)): order = CLng(choice(1))
    If sortColumn < 1 Or sortColumn > columns Then Exit Sub
    If ws.Name = SH_OUTPUT_TX Then
        PauseAnalysisSearch: FlushPendingAnalysisEdits
        lastR = LastRow(ws, 6): lastColumn = REPORT_UID_COL
        If ActiveCell.Row > header Then selectedID = CellText(ws.Cells(ActiveCell.Row, REPORT_UID_COL).Value2)
    Else
        lastR = LastRow(ws): lastColumn = 8
        If Not IsNumeric(ws.Cells(2, 1).Value2) Then Exit Sub
    End If
    If lastR <= header + 1 Then Exit Sub
    Set filters = CaptureCashFilters(ws)
    Set target = ws.Cells(header, 1).Resize(lastR - header + 1, lastColumn)
    before = target.Value2
    AppBegin "���בւ��Ă��܂�...": started = True
    ws.Unprotect Password:=TOOL_PASSWORD
    If ws.FilterMode Then ws.ShowAllData
    If ws.AutoFilterMode Then ws.AutoFilterMode = False
    writing = True
    With ws.Sort
        .SortFields.Clear
        If ws.Name = SH_OUTPUT_TX Then
            'N:P�͒��[�{���̍�Ɨ�B�㕔�̕��͓��͂Ƃ̑Ή����ɂ͐G��Ȃ��B
            ReDim keys(1 To lastR - header, 1 To 3)
            For r = 1 To UBound(keys, 1)
                keys(r, 1) = r: keyValue = before(r + 1, 7)
                If HasText(keyValue) And IsNumeric(keyValue) Then
                    keys(r, 2) = 0: keys(r, 3) = CDbl(keyValue)
                Else
                    keys(r, 2) = 1: keys(r, 3) = 0
                End If
            Next r
            ws.Cells(header + 1, 14).Resize(UBound(keys, 1), 3).Value2 = keys
            If sortColumn <> 7 Then .SortFields.Add Key:=ws.Cells(header + 1, sortColumn).Resize(lastR - header), Order:=order
            If sortColumn <> 6 And sortColumn <> 7 Then .SortFields.Add Key:=ws.Cells(header + 1, 6).Resize(lastR - header), Order:=xlAscending
            .SortFields.Add Key:=ws.Cells(header + 1, 15).Resize(lastR - header), Order:=xlAscending
            If sortColumn = 7 Then
                .SortFields.Add Key:=ws.Cells(header + 1, 16).Resize(lastR - header), Order:=order
            Else
                .SortFields.Add Key:=ws.Cells(header + 1, 16).Resize(lastR - header), Order:=xlAscending
            End If
            .SortFields.Add Key:=ws.Cells(header + 1, 14).Resize(lastR - header), Order:=xlAscending
        Else
            .SortFields.Add Key:=ws.Cells(header + 1, sortColumn).Resize(lastR - header), Order:=order
            If sortColumn <> 1 Then .SortFields.Add Key:=ws.Cells(header + 1, 1).Resize(lastR - header), Order:=xlAscending
        End If
        .SetRange target: .Header = xlYes: .Orientation = xlTopToBottom: .MatchCase = False
        .Apply
    End With
    sorted = True
    If ws.Name = SH_OUTPUT_TX Then ws.Cells(header + 1, 14).Resize(lastR - header, 3).ClearContents
    ws.Cells(header + 1, 1).Resize(lastR - header, columns).Rows.AutoFit
    For r = header + 1 To lastR
        If ws.Rows(r).RowHeight < 25 Then ws.Rows(r).RowHeight = 25
    Next r
    RestoreReportSortFilters ws, header, columns, lastR, filters
    ws.Calculate
    writing = False
    If ws.Name = SH_OUTPUT_TX Then
        RefreshShopRowReferences
        If Len(selectedID) > 0 Then selectedRow = FindReportTransaction(selectedID)
        If selectedRow > header Then
            If Not ws.Rows(selectedRow).Hidden Then ws.Cells(selectedRow, sortColumn).Select
        End If
    End If
    ProtectSortedReport ws
    MarkFileNeedsSave
    EndAppScope started
    Exit Sub
EH:
    message = Err.Description
    On Error Resume Next
    If writing And Not sorted Then
        Err.Clear: target.Value2 = before
        If Err.Number <> 0 Then restoring = "���я��̕����������ł��܂���ł����B���[���č쐬���Ă��������B " & Err.Description
    End If
    If Not ws Is Nothing Then
        If ws.Name = SH_OUTPUT_TX And lastR > header Then ws.Cells(header + 1, 14).Resize(lastR - header, 3).ClearContents
        If Not filters Is Nothing Then RestoreReportSortFilters ws, header, columns, lastR, filters
        If sorted And ws.Name = SH_OUTPUT_TX Then RefreshShopRowReferences
        ProtectSortedReport ws
    End If
    If sorted Then MarkFileNeedsSave
    EndAppScope started
    On Error GoTo 0
    If sorted Then message = "���בւ��͊������܂����B�\���̌㏈���������ł��܂���ł����B" & vbCrLf & message
    MsgBox message & vbCrLf & restoring, vbExclamation
End Sub

Private Sub RestoreReportSortFilters(ByVal ws As Worksheet, ByVal header As Long, ByVal columns As Long, ByVal lastR As Long, ByVal filters As Collection)
    Dim item As Object, target As Range
    Set target = ws.Cells(header, 1).Resize(lastR - header + 1, columns)
    If Not ws.AutoFilterMode Then target.AutoFilter
    For Each item In filters
        If item.Exists("first") And item.Exists("second") Then
            target.AutoFilter Field:=CLng(item("field")), Criteria1:=item("first"), Operator:=CLng(item("operator")), Criteria2:=item("second")
        ElseIf item.Exists("first") Then
            target.AutoFilter Field:=CLng(item("field")), Criteria1:=item("first"), Operator:=CLng(item("operator"))
        ElseIf item.Exists("second") Then
            target.AutoFilter Field:=CLng(item("field")), Operator:=CLng(item("operator")), Criteria2:=item("second")
        End If
    Next item
End Sub

Private Sub ProtectSortedReport(ByVal ws As Worksheet)
    If ws.Name = SH_OUTPUT_TX Then
        ProtectGeneratedOutput ws
        ProtectShopConversionTargetSheet
    Else
        ProtectShopConversionTargetSheet ws
    End If
End Sub

Attribute VB_Name = "modTransfer"
Option Explicit

Public Sub TransferCurrentAccount()
    TransferAccountCore "", False
End Sub

Public Sub TransferCurrentAccountKeepBankBranch()
    TransferAccountCore KEEP_BANK_BRANCH, False
End Sub

Public Sub TransferCurrentAccountNextBranch()
    TransferAccountCore KEEP_BANK_BRANCH_PERSON_TYPE, True
End Sub

Private Sub TransferAccountCore(ByVal keepOverride As String, ByVal nextBranch As Boolean)
    Dim appStarted As Boolean
    Dim ws As Worksheet, wsTx As Worksheet, wsBal As Worksheet, wsAcc As Worksheet
    Dim accountID As String, oldID As String, bank As String, branch As String, person As String
    Dim relation As String, subject As String, number As String, memo As String
    Dim opened As Variant, closed As Variant, parsedDate As Variant, parsedTime As Variant
    Dim outAmount As Variant, inAmount As Variant, amount As Variant, info As Variant, draft As Variant
    Dim raw As Variant, tx As Variant, bal As Variant, oldTx As Variant, oldBal As Variant, oldAcc As Variant
    Dim nextTx As Variant, nextBal As Variant, nextAcc As Variant
    Dim r As Long, c As Long, nTx As Long, nBal As Long, userRows As Long, focusRow As Long
    Dim focusCol As Long, balanceErrorDate As Variant
    Dim beforeInput As Collection, oldDrafts As Variant, existingNext As String
    Dim cy As Long, cm As Long, cd As Long, ok As Boolean, previousMemo As String, description As String
    Dim writing As Boolean, committed As Boolean, eText As String, restoreText As String
    Dim inputIDs As Variant, usedIDs As Object, txUID As String
    Dim nextNumber As String, policy As String, goNext As Boolean
    Dim parsedRow As Variant, rowIssue As String, invalidRows As Long, invalidBalances As Long, oldRows As Object
    Dim firstIssue As String, firstIssueRow As Long, firstIssueCol As Long, storedRow As Long
    Dim clearTx As Boolean, clearBal As Boolean, oldBookmarks As Variant, nextBookmarks As Variant
    Dim accountResult As Collection, balanceResult As Collection, inputAfter As Collection, pending As Object, invalidFields As Long
    Dim normalizedInput As Variant, nextDrafts As Variant, block As Variant, originalDraftKey As String, noRows As Variant, key As Variant
    Dim oldRaw As Variant, nextRaw As Variant, oldOrigins As Variant, nextOrigins As Variant
    If Not RequireToolReady() Then Exit Sub
    On Error GoTo EH
    EnsureAccountStore
    Set ws = GetSheet(SH_INPUT): Set wsTx = GetSheet(SH_WORK_TX)
    Set wsBal = GetSheet(SH_WORK_BAL): Set wsAcc = GetSheet(SH_ACCOUNTS)
    GetSheet(SH_INPUT).Calculate
    Set beforeInput = CaptureInputState()
    oldID = CurrentEditAccountID(): accountID = oldID: originalDraftKey = CurrentDraftKey()
    If Len(oldID) > 0 And AccountRow(oldID) = 0 Then Err.Raise vbObjectError + 2305, , "�������̌����͍폜����Ă��܂��B���͓��e�͕ێ����Ă��܂��B"
    If Len(accountID) = 0 Then accountID = NextAccountID()
    oldTx = ReadStore(wsTx, TX_STORE_COLS): oldBal = ReadStore(wsBal, 13): oldAcc = ReadStore(wsAcc, 10)
    Set accountResult = MergeInputAccountInfo(beforeInput, accountID, oldAcc)
    info = accountResult("values"): Set pending = accountResult("pending"): invalidFields = pending.Count
    For Each key In pending.Keys: firstIssue = CStr(pending(key)): Exit For: Next key
    bank = CellText(info(1, 2)): branch = CellText(info(1, 3)): person = CellText(info(1, 4)): relation = CellText(info(1, 5))
    subject = CellText(info(1, 6)): number = CellText(info(1, 7)): memo = CellText(info(1, 10))
    opened = info(1, 8): closed = info(1, 9)
    If TryStoredDate(opened, parsedDate) Then opened = CDate(parsedDate)
    If TryStoredDate(closed, parsedDate) Then closed = CDate(parsedDate)
    Set balanceResult = MergeInputBalanceInfo(beforeInput, accountID, oldBal)
    draft = balanceResult("values"): Set pending = balanceResult("pending"): invalidBalances = pending.Count
    If invalidBalances > 0 And Len(firstIssue) = 0 Then firstIssue = "�c���̕s���l�E�������_�̕ʕύX�͓��͗��ɕێ����Ă��܂��B"
    raw = beforeInput("transactions"): normalizedInput = raw
    ReDim tx(1 To UBound(raw, 1) + UBound(draft, 1) + 2, 1 To TX_STORE_COLS)
    ReDim bal(1 To Application.Max(1, UBound(draft, 1) - 1), 1 To 13)
    policy = keepOverride: If Len(policy) = 0 Then policy = GetPostTransferKeepPolicy()
    clearTx = GetPostTransferClearTransaction(): clearBal = GetPostTransferClearBalance()
    goNext = (Len(oldID) = 0 Or nextBranch Or Len(keepOverride) > 0)
    If nextBranch Then
        nextNumber = NextBranchAccountNo(number)
        existingNext = DuplicateAccountID(bank, branch, subject, nextNumber, "")
    End If
    Set oldRows = BatchRowsByID(oldTx, TX_UID_COL)
    ReDim inputIDs(1 To UBound(raw, 1), 1 To 1)
    Set usedIDs = CreateObject("Scripting.Dictionary")
    For r = 1 To UBound(raw, 1)
        If InputArrayRowHasData(raw, r) Then
            focusRow = TX_FIRST_ROW + r - 1
            If Not TryReadInputTransaction(raw, r, cy, cm, cd, previousMemo, parsedRow, rowIssue, focusCol) Then
                invalidRows = invalidRows + 1
                If Len(firstIssue) = 0 Then firstIssue = rowIssue: firstIssueRow = focusRow: firstIssueCol = focusCol
                txUID = CellText(raw(r, 11))
                If oldRows.Exists(txUID) Then
                    If CellText(oldTx(CLng(oldRows(txUID)), TX_ID_COL)) <> accountID Then txUID = ""
                End If
                If Len(txUID) = 0 Then txUID = NewInternalID("T")
                inputIDs(r, 1) = txUID
                If usedIDs.Exists(txUID) Then txUID = NewInternalID("T"): inputIDs(r, 1) = txUID
                If Len(txUID) > 0 And oldRows.Exists(txUID) Then
                    storedRow = CLng(oldRows(txUID))
                    If CellText(oldTx(storedRow, TX_ID_COL)) = accountID Then
                        nTx = nTx + 1
                        For c = 1 To TX_STORE_COLS: tx(nTx, c) = oldTx(storedRow, c): Next c
                        SetTxIdentity tx, nTx, bank, branch, person, relation, subject, number, accountID, "���"
                        usedIDs(txUID) = True
                    End If
                End If
                usedIDs(txUID) = True
                GoTo NextInputRow
            End If
            parsedDate = parsedRow(0): parsedTime = parsedRow(1): outAmount = parsedRow(2): inAmount = parsedRow(3): description = parsedRow(4)
            nTx = nTx + 1: userRows = userRows + 1
            SetTxIdentity tx, nTx, bank, branch, person, relation, subject, number, accountID, "���"
            txUID = CellText(raw(r, 11))
            If oldRows.Exists(txUID) Then
                If CellText(oldTx(CLng(oldRows(txUID)), TX_ID_COL)) <> accountID Then txUID = ""
            End If
            If Len(txUID) = 0 Or usedIDs.Exists(txUID) Then txUID = NewInternalID("T")
            usedIDs(txUID) = True: tx(nTx, TX_UID_COL) = txUID: inputIDs(r, 1) = txUID
            '�ĕ\������������ύX���Ă��Ȃ��ꍇ�́A���̐��l���x�����̂܂܎c���B
            If VarType(raw(r, 4)) = vbString And oldRows.Exists(txUID) Then
                storedRow = CLng(oldRows(txUID))
                If CellText(raw(r, 4)) = InputTimeText(oldTx(storedRow, 7)) Then parsedTime = oldTx(storedRow, 7)
            End If
            tx(nTx, 6) = CDbl(CDate(parsedDate))
            If HasText(parsedTime) Then tx(nTx, 7) = CDbl(CDate(parsedTime))
            tx(nTx, 8) = outAmount: tx(nTx, 9) = inAmount
            tx(nTx, 10) = CellText(raw(r, 7)): tx(nTx, 11) = CellText(raw(r, 8))
            tx(nTx, 12) = description: tx(nTx, 13) = CellText(raw(r, 10))
            '��x�o�^�������t�ƓE�v�́A�㗬�s�̌�̒����ŕω������Ȃ��B
            normalizedInput(r, 1) = Year(CDate(parsedDate)): normalizedInput(r, 2) = Month(CDate(parsedDate)): normalizedInput(r, 3) = Day(CDate(parsedDate))
            normalizedInput(r, 9) = description
        End If
NextInputRow:
        normalizedInput(r, 11) = inputIDs(r, 1)
    Next r
    focusRow = 0
    For r = 2 To UBound(draft, 1)
        balanceErrorDate = draft(r, 1)
        amount = draft(r, 3)
        If HasText(amount) Then

            nBal = nBal + 1
            bal(nBal, 1) = person: bal(nBal, 2) = bank: bal(nBal, 3) = branch
            bal(nBal, 4) = subject: bal(nBal, 5) = number
            bal(nBal, 6) = opened: bal(nBal, 7) = closed: bal(nBal, 8) = draft(r, 1)
            bal(nBal, 9) = draft(r, 2): bal(nBal, 10) = amount: bal(nBal, 11) = memo
            bal(nBal, 12) = relation: bal(nBal, 13) = accountID
            nTx = nTx + 1
            SetTxIdentity tx, nTx, bank, branch, person, relation, subject, number, accountID, "�c��"
            tx(nTx, 6) = draft(r, 1): tx(nTx, 12) = BalanceTekiyoLabel(draft(r, 2)): tx(nTx, 13) = amount
        End If
    Next r
    balanceErrorDate = Empty
    If IsDate(opened) Then
        nTx = nTx + 1
        SetTxIdentity tx, nTx, bank, branch, person, relation, subject, number, accountID, "�J��"
        tx(nTx, 6) = CDbl(CDate(opened)): tx(nTx, 12) = "�����J�ݓ�"
    End If
    If IsDate(closed) Then
        nTx = nTx + 1
        SetTxIdentity tx, nTx, bank, branch, person, relation, subject, number, accountID, "���"
        tx(nTx, 6) = CDbl(CDate(closed)): tx(nTx, 12) = "��������"
    End If
    nextTx = ReplaceAccountRows(oldTx, tx, nTx, TX_ID_COL, accountID)
    nextBal = ReplaceAccountRows(oldBal, bal, nBal, BAL_ID_COL, accountID)
    nextAcc = ReplaceAccountRows(oldAcc, info, 1, 1, accountID)
    oldBookmarks = ReadStore(BookmarkStore(), 2)
    nextBookmarks = WithBookmark(oldBookmarks, accountID, CellText(ws.Range("X22").Value2))
    oldDrafts = ParkedDraftData()
    Set inputAfter = TransferInputState(beforeInput, accountID, accountResult, balanceResult, normalizedInput, (invalidRows + invalidBalances + invalidFields > 0))
    nextDrafts = ReplaceAccountRows(oldDrafts, noRows, 0, 1, originalDraftKey)
    If invalidRows + invalidBalances + invalidFields > 0 Then
        block = EncodeParkedState(accountID, inputAfter)
        nextDrafts = ReplaceAccountRows(nextDrafts, block, UBound(block, 1), 1, accountID)
        goNext = False: existingNext = ""
    End If
    oldRaw = ReadStore(InputRawStore(), INPUT_RAW_COLS)
    nextRaw = BuildAccountInputRaw(oldRaw, accountID, inputAfter, nextTx)
    If SheetExists("W_�o�T") Then
        oldOrigins = ReadStore(ImportOriginStore(), IMPORT_ORIGIN_COLS): nextOrigins = oldOrigins
        For r = 2 To UBound(nextOrigins, 1)
            If Len(originalDraftKey) > 0 And CellText(nextOrigins(r, 30)) = originalDraftKey Then nextOrigins(r, 30) = accountID
            If usedIDs.Exists(CellText(nextOrigins(r, 1))) Then nextOrigins(r, 30) = accountID
        Next r
    End If
    AppBegin "�����𔽉f���Ă��܂�..."
    appStarted = True
    FormatWorkTx: FormatWorkBal
    writing = True
    WriteStore wsTx, nextTx: WriteStore wsBal, nextBal: WriteStore wsAcc, nextAcc
    WriteStore BookmarkStore(), nextBookmarks
    WriteStore GetSheet(SH_PARKED_DRAFTS), nextDrafts
    WriteInputAccountState inputAfter
    WriteInputValueBlock ws.Cells(TX_FIRST_ROW, COL_TX_YEAR).Resize(UBound(normalizedInput, 1), 11), normalizedInput
    RestoreStateInputFormulas inputAfter
    WriteStore InputRawStore(), nextRaw
    If IsArray(nextOrigins) Then WriteStore ImportOriginStore(), nextOrigins
    ws.Range(CELL_EDIT_ID).Value2 = accountID: ws.Range(CELL_DIRTY).Value2 = IIf(invalidRows + invalidBalances + invalidFields > 0, "1", "0")
    InvalidateDateCacheFrom TX_FIRST_ROW
    InvalidateOutputViews
    committed = True
    ClearInputUndo
    InvalidateDuplicateAccountWarningCache
    UpdateAccountCandidates bank, branch, person: RememberAccountType subject
    RenderBalancePage
    ProtectInputSheet
    If goNext Then
        If nextBranch And Len(existingNext) > 0 Then
            OpenAccountOrDraft existingNext, True
            If CurrentEditAccountID() <> existingNext Then Err.Raise vbObjectError + 2318, , "���݂̌����͔��f�ς݂ł��B���}�Ԃ��J���Ȃ��������߁A�o�^��������J���Ă��������B"
        Else
            ClearInputForNextAccount policy, clearTx, clearBal
            If nextBranch Then SetNextBranchAccountNumber nextNumber
        End If
    Else
        BuildOperationPanel ws
    End If
    EndAppScope appStarted
    If goNext And Len(existingNext) = 0 Then FocusAfterPostTransferCleanup policy
    SetInputStatus IIf(Len(oldID) = 0, "�]�L���܂����B", "�����𔽉f���܂����B") & "�@���� " & userRows & "���E�c�� " & nBal & "���_�@�^�@�u�b�N�ւ̕ۑ��́u�ۑ��v"
    If Len(existingNext) > 0 Then SetInputStatus "���f���A�o�^�ς݂̎��}�� " & nextNumber & " ���J���܂����B�ۑ��́u�ۑ��v�ł��B"
    If invalidRows + invalidBalances + invalidFields > 0 Then
        SetInputStatus "���� " & userRows & "���𔽉f�B�����f�F���� " & invalidRows & "�s�E�c�� " & invalidBalances & "���ځE������� " & invalidFields & "���ځB" & firstIssue
        If firstIssueRow >= TX_FIRST_ROW Then SafeSelectCell ws, ws.Cells(firstIssueRow, firstIssueCol).Address
    ElseIf Not goNext Then
        ReturnAfterReportCorrection accountID
    End If
    Exit Sub
EH:
    eText = Err.Description
    If writing And Not committed Then
        On Error Resume Next
        RestoreInputState beforeInput
        If Err.Number <> 0 Then restoreText = "���͉��": Err.Clear
        If IsArray(oldOrigins) Then WriteStore ImportOriginStore(), oldOrigins
        If Err.Number <> 0 Then restoreText = restoreText & " �o�T": Err.Clear
        WriteStore InputRawStore(), oldRaw
        If Err.Number <> 0 Then restoreText = restoreText & " ������": Err.Clear
        WriteStore GetSheet(SH_PARKED_DRAFTS), oldDrafts
        If Err.Number <> 0 Then restoreText = restoreText & " ������": Err.Clear
        WriteStore BookmarkStore(), oldBookmarks
        If Err.Number <> 0 Then restoreText = restoreText & " ������": Err.Clear
        WriteStore wsTx, oldTx
        If Err.Number <> 0 Then restoreText = restoreText & " ���": Err.Clear
        WriteStore wsBal, oldBal
        If Err.Number <> 0 Then restoreText = restoreText & " �c��": Err.Clear
        WriteStore wsAcc, oldAcc
        If Err.Number <> 0 Then restoreText = restoreText & " �����䒠": Err.Clear
        InvalidateOutputViews
        On Error GoTo 0
    End If
    On Error Resume Next
    If HasText(balanceErrorDate) Then
        FocusBalanceDate balanceErrorDate
    ElseIf focusRow >= TX_FIRST_ROW Then
        SafeSelectCell ws, ws.Cells(focusRow, focusCol).Address
    End If
    EndAppScope appStarted
    On Error GoTo 0
    If committed Then
        MsgBox "�����f�[�^�̔��f�͊������܂����B���͉�ʂ̌㏈���Ŗ�肪�������܂����B�ē]�L�����A�o�^��������m�F���Ă��������B" & vbCrLf & eText, vbExclamation
    ElseIf Len(restoreText) > 0 Then
        MsgBox "�������݂ƕ����Ɏ��s���܂����B�u�b�N���㏑���ۑ��������A�ۑ��ς݂̃u�b�N���J�������Ă��������B" & vbCrLf & restoreText & vbCrLf & eText, vbCritical
    Else
        MsgBox "�]�L�͍s���Ă��܂���B���͓��e���m�F���Ă��������B" & vbCrLf & eText, vbExclamation
    End If
End Sub

Private Function InputArrayRowHasData(ByVal data As Variant, ByVal r As Long) As Boolean
    Dim c As Long
    For c = 1 To 10
        If IsError(data(r, c)) Or HasText(data(r, c)) Then InputArrayRowHasData = True: Exit Function
    Next c
End Function

Public Function ParseMoney(ByVal value As Variant, ByVal allowNegative As Boolean, ByRef ok As Boolean) As Variant
    Dim s As String, n As Double, i As Long, ch As String
    ok = False
    If IsError(value) Then Exit Function
    s = Replace(Replace(CellText(value), ",", ""), "�C", "")
    On Error Resume Next
    s = StrConv(s, vbNarrow)
    On Error GoTo Invalid
    If Len(s) = 0 Then ok = True: Exit Function
    For i = 1 To Len(s)
        ch = Mid$(s, i, 1)
        If ch < "0" Or ch > "9" Then
            If Not (ch = "-" And i = 1 And allowNegative) Then Exit Function
        End If
    Next i
    If Not IsNumeric(s) Then Exit Function
    n = CDbl(s)
    If Abs(n) > 999999999999999# Then Exit Function
    If n < 0 And Not allowNegative Then Exit Function
    ParseMoney = CDec(s): ok = True
Invalid:
End Function

Private Sub SetTxIdentity(ByRef data As Variant, ByVal r As Long, ByVal bank As String, ByVal branch As String, ByVal person As String, ByVal relation As String, ByVal subject As String, ByVal number As String, ByVal accountID As String, ByVal kind As String)
    data(r, 1) = bank: data(r, 2) = branch: data(r, 3) = person: data(r, 4) = subject
    data(r, 5) = number: data(r, 14) = relation: data(r, 15) = accountID: data(r, 16) = kind
End Sub

Public Sub FormatWorkTx()
    With GetSheet(SH_WORK_TX)
        .Columns("A:E").NumberFormat = "@"
        .Columns("F:F").NumberFormat = "yyyy/m/d": .Columns("G:G").NumberFormat = "hh:mm"
        .Columns("H:I").NumberFormat = "#,##0": .Columns("J:L").NumberFormat = "@"
        .Columns("M:M").NumberFormat = "@": .Columns("N:P").NumberFormat = "@"
        .Cells(1, TX_ID_COL).Value2 = "����ID": .Cells(1, TX_KIND_COL).Value2 = "�s�敪"
    End With
End Sub

Public Sub FormatWorkBal()
    With GetSheet(SH_WORK_BAL)
        .Columns("A:E").NumberFormat = "@": .Columns("F:H").NumberFormat = "yyyy/m/d"
        .Columns("I:I").NumberFormat = "@": .Columns("J:J").NumberFormat = "#,##0"
        .Columns("K:M").NumberFormat = "@": .Cells(1, BAL_ID_COL).Value2 = "����ID"
    End With
End Sub

Public Sub NormalizeTransactionAmounts(ByRef withdrawal As Variant, ByRef deposit As Variant)
    If HasText(withdrawal) And HasText(deposit) Then
        If CDbl(withdrawal) = 0 And CDbl(deposit) <> 0 Then withdrawal = Empty
        If CDbl(deposit) = 0 And HasText(withdrawal) Then deposit = Empty
    End If
End Sub

Public Function NonZeroAmount(ByVal value As Variant) As Boolean
    Dim parsed As Variant, ok As Boolean
    parsed = ParseMoney(value, True, ok)
    If ok And HasText(parsed) Then NonZeroAmount = (CDbl(parsed) <> 0)
End Function

Public Function TryReadInputTransaction(ByVal raw As Variant, ByVal row As Long, ByRef year As Long, ByRef month As Long, ByRef day As Long, ByRef previousMemo As String, ByRef parsed As Variant, ByRef issue As String, ByRef column As Long) As Boolean
    Dim c As Long, ok As Boolean, dateInput As Variant, timeInput As Variant, withdrawal As Variant, deposit As Variant, description As String
    On Error GoTo InvalidValue
    issue = "": column = COL_TX_YEAR
    If IsError(raw(row, 9)) Then
        previousMemo = "": description = ""
    Else
        description = CellText(raw(row, 9))
        If description <> "����" And Len(description) > 0 Then previousMemo = description
    End If
    dateInput = ResolveInputDate(raw(row, 1), raw(row, 2), raw(row, 3), year, month, day, InputYearAdd(), ok)
    If Not ok Then
        issue = "�N���������m��ł��B���͂����l�͕ێ����܂��B": Exit Function
    End If
    For c = 4 To 10
        If IsError(raw(row, c)) Then column = COL_TX_YEAR + c - 1: issue = "�Z���̃G���[��������Ă��������B": Exit Function
    Next c
    column = COL_TX_TIME
    timeInput = NormalizeTimeInput(raw(row, 4), ok)
    If Not ok Then issue = "������������邩�󗓂ɂ��Ă��������B": Exit Function
    column = COL_TX_WITHDRAW
    withdrawal = ParseMoney(raw(row, 5), False, ok)
    If Not ok Then issue = "�o���z�𐮐��œ��͂��Ă��������B": Exit Function
    column = COL_TX_DEPOSIT
    deposit = ParseMoney(raw(row, 6), False, ok)
    If Not ok Then issue = "�����z�𐮐��œ��͂��Ă��������B": Exit Function
    NormalizeTransactionAmounts withdrawal, deposit
    If HasText(withdrawal) And HasText(deposit) Then issue = "�o���Ɠ������������z�̂��߁A���̍s�͖����f�ł��B": Exit Function
    If Not HasText(withdrawal) And Not HasText(deposit) Then issue = "�o���܂��͓�������͂��Ă��������B": Exit Function
    column = COL_TX_TEKIYO
    If description = "����" Then
        If Len(previousMemo) = 0 Then issue = "�u����v�̌��ɂȂ�E�v������܂���B": Exit Function
        description = previousMemo
    End If
    parsed = Array(dateInput, timeInput, withdrawal, deposit, description)
    TryReadInputTransaction = True
    Exit Function
InvalidValue:
    issue = "���̍s�͖����f�ł��F" & Err.Description
End Function

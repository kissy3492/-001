Attribute VB_Name = "modAnalysisPanel"
Option Explicit

Public Const ANALYSIS_PANEL_ROWS As Long = 16
Private mPanelExpanded As Boolean
Private mPanelOpen As Boolean
Private mPanelReady As Boolean
Private mPanelMode As String
Private mPanelPage As Long
Private mPanelItems As Collection
Private mPanelScope As Object
Private mPanelSelected As Object
Private mPanelChoice As Long
Private mPanelRowIDs As Object
Private mPanelNotice As String
Private mPanelLastSelection As String
Private mPanelRelation As String
Private mPanelDetailIDs As String
Private mPanelDetailCandidate As Object
Private mPanelAggregate As String
Private mPanelAmounts As Boolean
Private mPanelPathLinks As String
Private mPanelPathID As String
Private mPanelPathFrom As String
Private mPanelResultComplete As Boolean
Private mPanelAnchor As Object
Private mPanelResultNote As String
Private mPanelRenderedMode As String
Private mPanelRenderedAmounts As Boolean
Private mPanelTotalW As Double
Private mPanelTotalD As Double
Private mPanelScopeKey As String
Private mRefreshingScope As Boolean
Private mScopeGeneration As Long
Private mReadingSearch As Boolean

Public Function CashReportHeader(ByVal ws As Worksheet) As Long
    Dim values As Variant, r As Long
    CashReportHeader = 1
    If Not CellText(ws.Range("A1").Value2) Like "�W�v�E�֘A���*" Then Exit Function
    values = ws.Range("A1:F40").Value2
    For r = 2 To 40
        If CellText(values(r, 1)) = "��s��" Then
            CashReportHeader = r: Exit Function
        End If
    Next r
    CashReportHeader = ANALYSIS_PANEL_ROWS + 1
End Function

Public Sub ResetAnalysisSelectionCache()
    mPanelLastSelection = "": mPanelScopeKey = "!": mPanelRenderedMode = ""
    mPanelReady = False
End Sub

Public Sub AttachAnalysisPanel(ByVal ws As Worksheet, Optional ByRef insertedRows As Long = 0)
    Dim lastR As Long, oldHeader As Long
    If ws.Name = SH_OUTPUT_TX Then CaptureAnalysisPanelInputs
    ws.Unprotect Password:=TOOL_PASSWORD
    oldHeader = CashReportHeader(ws)
    If oldHeader = 1 Then
        ws.Rows("1:" & ANALYSIS_PANEL_ROWS).Insert Shift:=xlDown
        insertedRows = ANALYSIS_PANEL_ROWS
    ElseIf oldHeader < ANALYSIS_PANEL_ROWS + 1 Then
        ws.Rows(oldHeader & ":" & ANALYSIS_PANEL_ROWS).Insert Shift:=xlDown
        insertedRows = ANALYSIS_PANEL_ROWS + 1 - oldHeader
    End If
    lastR = Application.Max(ANALYSIS_PANEL_ROWS + 1, LastRow(ws, 6))
    ws.Rows("1:" & ANALYSIS_PANEL_ROWS).RowHeight = 19
    ClearAnalysisBindings ws
    ws.Range("A1:M" & ANALYSIS_PANEL_ROWS).UnMerge
    ws.Range("A1:M" & ANALYSIS_PANEL_ROWS).Clear
    PanelLabel ws, "A1:E1", "�W�v�E�֘A���@�{"
    PanelLabel ws, "F1:G1", "�W�v"
    PanelLabel ws, "H1:I1", "���"
    PanelLabel ws, "J1:K1", "�L�^"
    PanelLabel ws, "L1:M1", "����"
    ws.Rows(1).RowHeight = 26
    ws.Range("A1:M1").Font.Bold = True
    ws.Rows("2:" & ANALYSIS_PANEL_ROWS).Hidden = True
    ws.Columns("N:T").Hidden = True
    ws.PageSetup.PrintArea = ws.Range("A" & ANALYSIS_PANEL_ROWS + 1 & ":M" & lastR).Address
    ws.PageSetup.PrintTitleRows = "$" & ANALYSIS_PANEL_ROWS + 1 & ":$" & ANALYSIS_PANEL_ROWS + 1
    mPanelOpen = False: mPanelReady = False
    ProtectGeneratedOutput ws
End Sub

Public Sub PrepareAnalysisPanelOnOpen()
    Dim ws As Worksheet
    If Not SheetExists(SH_OUTPUT_TX) Then Exit Sub
    Set ws = GetSheet(SH_OUTPUT_TX)
    CaptureAnalysisPanelInputs
    ws.Unprotect Password:=TOOL_PASSWORD
    ClearAnalysisBindings ws
    If CashReportHeader(ws) > 1 Then
        If CashReportHeader(ws) <> ANALYSIS_PANEL_ROWS + 1 Then AttachAnalysisPanel ws: RefreshShopRowReferences
        ws.Unprotect Password:=TOOL_PASSWORD
        ws.Rows("2:" & ANALYSIS_PANEL_ROWS).Hidden = True
        ws.Range("A1").Value2 = "�W�v�E�֘A���@�{"
        ws.Range("A2:M" & ANALYSIS_PANEL_ROWS).Locked = True
        ProtectGeneratedOutput ws
    End If
    mPanelOpen = False: mPanelReady = False
End Sub

Private Sub InitializePanelState()
    FlushPendingAnalysisEdits
    If mPanelReady Then Exit Sub
    LoadAnalysisData
    Set mPanelScope = AnalysisVisibleIDs(): mPanelScopeKey = "!"
    Set mPanelSelected = CreateObject("Scripting.Dictionary")
    Set mPanelAnchor = CreateObject("Scripting.Dictionary")
    Set mPanelItems = New Collection
    Set mPanelRowIDs = CreateObject("Scripting.Dictionary")
    mPanelPage = 0: mPanelChoice = 0: mPanelAmounts = False: mPanelMode = "aggregate": mPanelAggregate = "����"
    mPanelRelation = "": mPanelDetailIDs = "": mPanelAmounts = False
    Set mPanelDetailCandidate = Nothing
    mPanelPathID = "": mPanelPathLinks = "": mPanelPathFrom = ""
    mPanelLastSelection = "": mPanelResultNote = "": mPanelScopeKey = "!": mPanelRenderedMode = ""
    mPanelReady = True
End Sub

Public Sub ToggleAnalysisPanel()
    Dim started As Boolean, ws As Worksheet, message As String
    On Error GoTo EH
    AppBegin: started = True
    Set ws = GetSheet(SH_OUTPUT_TX)
    If CashReportHeader(ws) = 1 Then
        TryInstallAnalysisPanel CaptureCashFilters(ws)
        Set ws = GetSheet(SH_OUTPUT_TX)
        If CashReportHeader(ws) = 1 Then EndAppScope started: Exit Sub
    End If
    mPanelOpen = Not mPanelOpen
    If mPanelOpen Then
        InitializePanelState
        Set mPanelScope = AnalysisVisibleIDs(): mPanelScopeKey = "!"
        ShowAnalysisAccounts
    Else
        PauseAnalysisSearch
        ws.Unprotect Password:=TOOL_PASSWORD
        ws.Rows("2:" & ANALYSIS_PANEL_ROWS).Hidden = True
        ws.Range("A1").Value2 = "�W�v�E�֘A���@�{"
        ProtectGeneratedOutput ws
    End If
    FreezeCashReport ws
    EndAppScope started
    Exit Sub
EH:
    message = Err.Description
    EndAppScope started
    AnalysisPanelMessage "�\�����X�V�ł��܂���ł����B" & message
End Sub

Public Sub FreezeCashReport(ByVal ws As Worksheet)
    Dim scroll As Long, header As Long
    If Not ActiveSheet Is ws Then Exit Sub
    header = CashReportHeader(ws)
    If ActiveWindow.FreezePanes And ActiveWindow.SplitRow = header And ActiveWindow.SplitColumn = 0 Then Exit Sub
    scroll = ActiveWindow.ScrollRow
    ActiveWindow.FreezePanes = False
    ActiveWindow.ScrollRow = 1
    ActiveWindow.SplitColumn = 0
    ActiveWindow.SplitRow = header
    ActiveWindow.FreezePanes = True
    ActiveWindow.ScrollRow = Application.Max(header + 1, scroll)
End Sub

Public Sub AnalysisPanelSelection(ByVal target As Range)
    Dim ids As Object, key As String, started As Boolean, row As Long, column As Long, item As Object, message As String
    If AnalysisSearchRunning() Then Exit Sub
    If CashReportHeader(target.Worksheet) = 1 Then Exit Sub
    On Error GoTo EH
    FlushPendingAnalysisEdits
    RefreshCurrentAnalysisScope
    row = target.Row: column = target.Column
    If row <= ANALYSIS_PANEL_ROWS Then
        If row = 1 Then
            Select Case column
                Case 1 To 5: ToggleAnalysisPanel
                Case 6 To 7: ShowAnalysisAggregateMenu
                Case 8 To 9: ShowAnalysisCandidateEntry
                Case 10 To 11: ShowAnalysisRecords
                Case 12 To 13: ShowAnalysisActions
            End Select
        ElseIf mPanelOpen Then
            If row = 4 Then
                Select Case column
                    Case 1 To 6
                        If PendingInputAccountCount() > 0 Then ShowRegisteredAccounts
                        Exit Sub
                    Case 7 To 9: ShowAnalysisSearchMenu
                    Case 10 To 13: RegisterPanelRelation
                End Select
            ElseIf row >= 7 And row <= 6 + PanelPageSize() Then
                If mPanelMode = "settings" Then Exit Sub
                If mPanelMode <> "candidates" And Not mReadingSearch Then PauseAnalysisSearch
                mPanelChoice = mPanelPage * PanelPageSize() + row - 6
                If mPanelChoice <= mPanelItems.Count Then
                    Set item = mPanelItems(mPanelChoice)
                    If mPanelMode = "detail" And mPanelRowIDs.Exists(CStr(row)) Then
                        Set mPanelSelected = AnalysisIDSet(CStr(mPanelRowIDs(CStr(row))))
                    End If
                End If
                HighlightPanelChoice
                Exit Sub
            ElseIf row = 15 Then
                If mPanelMode <> "candidates" And Not mReadingSearch Then PauseAnalysisSearch
                Select Case column
                    Case 1 To 3: If mPanelPage > 0 Then mPanelPage = mPanelPage - 1: ClearPanelChoice: RenderAnalysisPanel
                    Case 7 To 9: If (mPanelPage + 1) * PanelPageSize() < mPanelItems.Count Then mPanelPage = mPanelPage + 1: ClearPanelChoice: RenderAnalysisPanel
                    Case 10 To 13: OpenPanelChoice
                End Select
            ElseIf row = 16 Then
                Exit Sub
            End If
        End If
        AppBegin: started = True
        If ActiveSheet Is target.Worksheet Then target.Worksheet.Cells(CashReportHeader(target.Worksheet), 1).Select
        EndAppScope started
        Exit Sub
    End If
    If Not mPanelOpen Then Exit Sub
    InitializePanelState
    Set ids = AnalysisSelectedIDs(target)
    If ids.Count = 0 Then Exit Sub
    key = AnalysisIDKey(ids)
    If key = mPanelLastSelection And mPanelMode = "candidates" Then
        If AnalysisIDKey(AnalysisVisibleIDs()) = AnalysisIDKey(mPanelScope) Then Exit Sub
    End If
    Set mPanelSelected = ids: Set mPanelAnchor = ids: mPanelLastSelection = key: mPanelChoice = 0
    mPanelPathFrom = "": mPanelPathLinks = "": mPanelPathID = ""
    Set mPanelScope = AnalysisVisibleIDs(): mPanelScopeKey = "!"
    PauseAnalysisSearch
    mPanelRelation = "": mPanelDetailIDs = "": mPanelResultNote = ""
    mPanelAmounts = False: mPanelMode = "selection": Set mPanelItems = New Collection: mPanelPage = 0
    mPanelNotice = CStr(ids.Count) & "����I���B�u���v�Ō����A�������ׂ́u�֘A�t����v�ŋL�^�ł��܂��B"
    RenderAnalysisPanel
    Exit Sub
EH:
    message = Err.Description
    EndAppScope started
    AnalysisPanelMessage "���̕\�����X�V�ł��܂���ł����B" & message
End Sub

Public Function AnalysisPanelDoubleClick(ByVal target As Range) As Boolean
    If CashReportHeader(target.Worksheet) = 1 Or target.Row > ANALYSIS_PANEL_ROWS Then Exit Function
    AnalysisPanelDoubleClick = True
    If Not mPanelOpen Then Exit Function
    If target.Row = 16 And target.Column >= 2 And Len(mPanelRelation) > 0 Then AnalysisPanelDoubleClick = False: Exit Function
    If target.Row >= 7 And target.Row <= 6 + PanelPageSize() Then
        If mPanelMode = "settings" Or mPanelAmounts Or mPanelMode = "pairs" Then AnalysisPanelDoubleClick = False: Exit Function
        mPanelChoice = mPanelPage * PanelPageSize() + target.Row - 6
        OpenPanelChoice
    End If
End Function

Public Sub AnalysisPanelChange(ByVal target As Range)
    Dim hit As Range, cell As Range, value As Variant, ok As Boolean, row As Long
    If Not mPanelReady Or Not mPanelOpen Then Exit Sub
    If mPanelMode = "settings" Then
        If Not Intersect(target, target.Worksheet.Range("H10:M10")) Is Nothing Then
            GetSheet(SH_CONFIG).Cells(33, 16384).Value2 = CellText(target.Worksheet.Range("H10").Value2)
            MarkFileNeedsSave
            AnalysisPanelMessage "��������̏�����ύX���܂����B�󗓂Ȃ�i��܂���B�����Č����ł��܂��B"
        End If
        Set hit = Intersect(target, target.Worksheet.Range("H7:M9"))
        If Not hit Is Nothing Then
            For row = 7 To 9
                If Not Intersect(hit, target.Worksheet.Rows(row)) Is Nothing Then
                    value = target.Worksheet.Cells(row, 8).Value2
                    ok = False
                    If IsNumeric(value) And HasText(value) Then
                        If CDbl(value) >= 0 Then
                            Select Case row
                                Case 7: ok = (CDbl(value) <= 36500 And CDbl(value) = Fix(CDbl(value)))
                                Case 8: ok = (CDbl(value) <= 922337203685477# And CDbl(value) = Fix(CDbl(value)))
                                Case 9: ok = (CDbl(value) <= 100)
                            End Select
                        End If
                    End If
                    If ok Then
                        GetSheet(SH_CONFIG).Cells(row + 23, 16384).Value2 = CDbl(value)
                        MarkFileNeedsSave
                        AnalysisPanelMessage "����������ύX���܂����B�S�̂܂��͑I�𖾍ׂ̌��������ł��܂��B"
                    Else
                        AnalysisPanelMessage "������0�`36,500�̐����A���z��0�ȏ�̐����A������0�`100���œ��͂��Ă��������B�����ɂ͕ύX�O�̏������g���܂��B"
                    End If
                End If
            Next row
        End If
        Exit Sub
    End If
    CaptureAnalysisPanelInputs

End Sub

Private Sub PanelLabel(ByVal ws As Worksheet, ByVal address As String, ByVal value As String)
    With ws.Range(address)
        If .Cells(1, 1).MergeArea.Address <> .Address Then .UnMerge: .Merge
        .NumberFormat = "@": .Cells(1, 1).Value2 = value
        .Font.Name = "Yu Gothic UI": .Font.Size = 11: .Font.Color = RGB(30, 41, 59)
        .Interior.Color = vbWhite: .VerticalAlignment = xlCenter: .HorizontalAlignment = xlLeft
        .WrapText = False: .ShrinkToFit = False
    End With
End Sub

Private Sub RenderAnalysisPanel(Optional ByVal context As Object = Nothing)
    Dim ws As Worksheet, started As Boolean, totalW As Double, totalD As Double, uid As Variant, r As Long, i As Long
    Dim item As Object, details As Object, rows As Collection, ids As Object, label As String, accountText As String
    Dim message As String, firstID As String, lastID As String, key As Variant, firstR As Long, lastR As Long, searchState As Object
    On Error GoTo EH
    FlushPendingAnalysisEdits
    AppBegin: started = True
    Set ws = GetSheet(SH_OUTPUT_TX)
    If CashReportHeader(ws) = 1 Then TryInstallAnalysisPanel CaptureCashFilters(ws)
    Set ws = GetSheet(SH_OUTPUT_TX)
    If CashReportHeader(ws) = 1 Then Err.Raise vbObjectError + 3450, , "���͕\�����J���܂���ł����B�ʏ�̒��[�͗��p�ł��܂��B"
    ws.Unprotect Password:=TOOL_PASSWORD
    ClearAnalysisBindings ws
    ws.Rows("2:" & ANALYSIS_PANEL_ROWS).Hidden = False
    If mPanelRenderedMode <> mPanelMode Or mPanelRenderedAmounts <> mPanelAmounts Then
        ws.Range("A2:M16").UnMerge: ws.Range("A2:M16").Clear
    Else
        ws.Range("A2:M16").ClearContents
    End If
    ws.Range("A2:M16").Locked = True
    ws.Range("A2:M16").NumberFormat = "General"
    ws.Range("A1").Value2 = "�W�v�E�֘A���@�|"
    ws.Range("A2:M16").Font.Name = "Yu Gothic UI": ws.Range("A2:M16").Font.Size = 11
    ws.Range("A2:M16").Font.Color = RGB(30, 41, 59): ws.Range("A2:M16").Interior.Color = vbWhite
    ws.Rows("2:16").RowHeight = 19: ws.Rows("7:14").RowHeight = 28
    ws.Rows("11:14").Hidden = (PanelPageSize() = 4)
    ws.Rows("2:3").Hidden = False
    If mPanelMode = "settings" Then ws.Rows("11:14").Hidden = True
    Set mPanelRowIDs = CreateObject("Scripting.Dictionary")
    If mPanelScopeKey = "!" Then
        mPanelTotalW = 0: mPanelTotalD = 0
        For Each uid In mPanelScope.Keys
            mPanelTotalW = mPanelTotalW + Val(CellText(AnalysisValue(CStr(uid), 8)))
            mPanelTotalD = mPanelTotalD + Val(CellText(AnalysisValue(CStr(uid), 9)))
        Next uid
        mPanelScopeKey = "current"
    End If
    totalW = mPanelTotalW: totalD = mPanelTotalD
    PanelLabel ws, "A2:M2", "�W�v�Ώۂ̓o�^�ςݖ��� " & mPanelScope.Count & "���@�o�� " & Format$(totalW, "#,##0") & "�~�@���� " & Format$(totalD, "#,##0") & "�~�@���� " & Format$(totalD - totalW, "#,##0") & "�~"
    firstR = CashReportHeader(ws) + 1: lastR = Application.Max(firstR, LastRow(ws, 6))
    ws.Range("A2").NumberFormat = "General"
    ws.Range("A2").Formula = "=""�\�����̖��� ""&SUBTOTAL(103,T" & firstR & ":T" & lastR & ")&""���@�o�� ""&TEXT(SUBTOTAL(109,H" & firstR & ":H" & lastR & "),""#,##0"")&""�~�@���� ""&TEXT(SUBTOTAL(109,I" & firstR & ":I" & lastR & "),""#,##0"")&""�~"""
    PanelLabel ws, "A3:M3", CurrentPanelContext()
    PanelLabel ws, "A4:F4", IIf(PendingInputAccountCount() > 0, PendingInputSummary() & "�@�J��", "�o�^�ς݂�\��")
    PanelLabel ws, "G4:I4", IIf(Len(mPanelRelation) > 0, "�ǉ������E���z�w��", "�ǉ������E����")
    PanelLabel ws, "J4:M4", ""
    If CanRegisterPanelSelection() Then ws.Range("J4").Value2 = "�֘A�t����"
    ws.Range("A4:M4").Font.Color = RGB(30, 64, 175): ws.Range("A4:M4").Interior.Color = RGB(239, 246, 255)
    If mPanelMode = "candidates" And AnalysisSearchCanContinue() Then
        Set searchState = CurrentSearchResult(): mPanelNotice = CStr(searchState("message"))
    End If
    If PanelCandidateIsStale() Then mPanelNotice = "�o�^�ςݖ��ׂ��ς��܂����B���������������Ɠo�^�E�o�͂ł��܂��B"
    PanelLabel ws, "A5:M5", mPanelNotice
    ws.Range("A5:M5").Font.Size = 11
    PanelLabel ws, "A6:E6", "�����E�g����"
    PanelLabel ws, "F6:F6", "���t"
    PanelLabel ws, "G6:G6", "�����E����"
    PanelLabel ws, "H6:H6", "�o��"
    PanelLabel ws, "I6:I6", "����"
    PanelLabel ws, "J6:J6", "���z"
    PanelLabel ws, "K6:K6", "������"
    PanelLabel ws, "L6:M6", "�E�v�E����"
    If (mPanelMode = "detail" Or mPanelMode = "pairs") And Len(mPanelRelation) > 0 Then
        If context Is Nothing Then Set context = NewRelationContext()
    End If
    If mPanelMode = "aggregate" Then
        ws.Range("A6").Value2 = mPanelAggregate & "�ʏW�v": ws.Range("F6").Value2 = "����": ws.Range("G6").ClearContents
        ws.Range("J6").Value2 = "����": ws.Range("K6").ClearContents
    ElseIf mPanelMode = "balance" Then
        ws.Range("F6").Value2 = "�O����t": ws.Range("G6").Value2 = "������t"
        ws.Range("H6").Value2 = "�O��c��": ws.Range("I6").Value2 = "����c��": ws.Range("J6").Value2 = "����": ws.Range("K6").ClearContents
    ElseIf mPanelMode = "pairs" Then
        Set mPanelItems = RelationPairRows(mPanelRelation, True, context)
        ws.Range("A6").Value2 = "�o���� �� ������": ws.Range("F6").Value2 = "�o����": ws.Range("G6").Value2 = "������"
        ws.Range("J6:K6").Merge: ws.Range("J6").Value2 = "�ۑ������z": ws.Range("L6").Value2 = "����̔z��"
    ElseIf mPanelMode = "connections" Then
        ws.Range("F6").Value2 = "��������": ws.Range("G6").Value2 = "��o����"
        ws.Range("H6").Value2 = "��̏o��": ws.Range("I6").Value2 = "���̓���": ws.Range("J6").ClearContents
    ElseIf mPanelMode = "detail" And mPanelAmounts Then
        ws.Range("J6:K6").Merge: ws.Range("J6").Value2 = "�g����z": ws.Range("L6").Value2 = "����̎w��z"
        Set details = RelationDetails(mPanelRelation, context): Set mPanelItems = details("rows")
    End If
    ws.Range("A6:M6").Interior.Color = RGB(241, 245, 249): ws.Range("A6:M6").Font.Bold = True
    ws.Range("H6").Font.Color = RGB(146, 64, 14): ws.Range("I6").Font.Color = RGB(15, 99, 88)
    For r = 7 To 6 + PanelPageSize()
        i = mPanelPage * PanelPageSize() + r - 6
        If i > mPanelItems.Count Then Exit For
        Set item = mPanelItems(i)
        PanelLabel ws, "A" & r & ":E" & r, ""
        PanelLabel ws, "L" & r & ":M" & r, ""
        ws.Range("A" & r & ":M" & r).Borders(xlEdgeBottom).Color = RGB(226, 232, 240)
        ws.Range("H" & r & ":K" & r).NumberFormat = "#,##0"
        Select Case mPanelMode
            Case "aggregate"
                ws.Cells(r, 1).Value2 = item("label"): ws.Cells(r, 6).Value2 = item("count")
                ws.Cells(r, 8).Value2 = item("out"): ws.Cells(r, 9).Value2 = item("in"): ws.Cells(r, 10).Value2 = CDbl(item("in")) - CDbl(item("out"))
            Case "balance"
                ws.Cells(r, 1).Value2 = item("label"): ws.Cells(r, 6).Value2 = item("from"): ws.Cells(r, 7).Value2 = item("to")
                ws.Range("F" & r & ":G" & r).NumberFormat = "yyyy/m/d"
                ws.Cells(r, 8).Value2 = item("before"): ws.Cells(r, 9).Value2 = item("after")
                If HasText(item("before")) Then ws.Cells(r, 10).Value2 = CDbl(item("after")) - CDbl(item("before")) Else ws.Cells(r, 12).Value2 = "�o�^�c����1���_"
            Case "candidates"
                Set ids = AnalysisIDSet(CStr(item("ids"))): accountText = "": label = "": firstID = "": lastID = ""
                For Each uid In ids.Keys
                    If AnalysisSide(CStr(uid)) = "W" And Len(firstID) = 0 Then firstID = CStr(uid)
                    If AnalysisSide(CStr(uid)) = "D" And Len(lastID) = 0 Then lastID = CStr(uid)
                    If Len(label) > 0 Then label = label & " / "
                    label = label & CellText(AnalysisValue(CStr(uid), 12))
                Next uid
                accountText = CStr(item("shape")) & "�@" & CandidateSideCaption(ids, "W") & " �^ " & CandidateSideCaption(ids, "D")
                ws.Cells(r, 1).Value2 = accountText
                ws.Cells(r, 6).NumberFormat = "@": ws.Cells(r, 6).Value2 = Format$(CDbl(item("firstDay")), "m/d") & "�`" & Format$(CDbl(item("lastDay")), "m/d")
                Select Case CLng(item("order"))
                    Case -1: ws.Cells(r, 7).Value2 = "�S�z�Ή��s��"
                    Case 0: ws.Cells(r, 7).Value2 = "�������m��"
                    Case Else: ws.Cells(r, 7).Value2 = "���������Ȃ�"
                End Select
                ws.Cells(r, 8).Value2 = item("out"): ws.Cells(r, 9).Value2 = item("in"): ws.Cells(r, 10).Value2 = item("difference"): ws.Cells(r, 11).Value2 = item("span")
                If HasOutsideScope(ids) Then label = "�\���͈͊O�̑��肠�� / " & label
                label = CStr(item("evidence")) & " / " & label
                If CandidateHasCompetition(item) Then label = "�������� / " & label
                ws.Cells(r, 12).Value2 = label
            Case "pairs"
                firstID = CStr(item("from")): lastID = CStr(item("to"))
                mPanelRowIDs(CStr(r)) = firstID & "~" & lastID
                ws.Cells(r, 1).Value2 = CompactAnalysisAccount(firstID) & " �� " & CompactAnalysisAccount(lastID)
                ws.Cells(r, 6).NumberFormat = "@": ws.Cells(r, 7).NumberFormat = "@"
                ws.Cells(r, 6).Value2 = AnalysisDateText(firstID): ws.Cells(r, 7).Value2 = AnalysisDateText(lastID)
                ws.Cells(r, 8).Value2 = AnalysisAmount(firstID): ws.Cells(r, 9).Value2 = AnalysisAmount(lastID)
                ws.Range("J" & r & ":K" & r).Merge: ws.Cells(r, 10).Value2 = item("amount")
                ws.Range("L" & r & ":M" & r).Locked = False: ws.Range("L" & r & ":M" & r).NumberFormat = "#,##0"
                ws.Cells(r, 12).Value2 = PendingAnalysisValue(mPanelRelation, firstID & "~" & lastID, item("draft"))
                ws.Range("L" & r & ":M" & r).Interior.Color = RGB(239, 246, 255)
            Case "connections"
                firstID = CStr(item("from")): lastID = CStr(item("to"))
                ws.Cells(r, 1).Value2 = AnalysisAccountText(firstID)
                ws.Cells(r, 6).NumberFormat = "@": ws.Cells(r, 7).NumberFormat = "@"
                ws.Cells(r, 6).Value2 = AnalysisDateText(firstID): ws.Cells(r, 7).Value2 = AnalysisDateText(lastID)
                ws.Cells(r, 8).Value2 = AnalysisAmount(lastID): ws.Cells(r, 9).Value2 = AnalysisAmount(firstID)
                ws.Cells(r, 12).Value2 = AnalysisTimeText(firstID) & " �� " & AnalysisTimeText(lastID) & " / �ڑ��z�͖��w��"
            Case "records"
                ws.Cells(r, 1).Value2 = IIf(item("kind") = "P", "�o�H", "�֘A�t��") & "�@" & CStr(item("memo"))
                ws.Cells(r, 12).Value2 = "�_�u���N���b�N�ŏڍ�"
                If item("kind") = "G" Then RenderRelationTotals ws, r, CStr(item("ids"))
            Case "detail"
                If item("type") = "L" Then
                    Set details = RelationDetails(CStr(item("id")), context)
                    ws.Cells(r, 1).Value2 = "��� " & i & "�@" & CStr(details("memo"))
                    ws.Cells(r, 8).Value2 = details("out"): ws.Cells(r, 9).Value2 = details("in")
                    ws.Cells(r, 12).Value2 = details("status")
                    If i > 1 Then ws.Cells(r, 12).Value2 = CStr(details("status")) & " / " & AnalysisPathConnectionText(item)
                Else
                    uid = CStr(item("id")): mPanelRowIDs(CStr(r)) = CStr(uid)
                    ws.Cells(r, 1).Value2 = item("label")
                    ws.Cells(r, 6).NumberFormat = "@": ws.Cells(r, 6).Value2 = AnalysisDateText(CStr(uid))
                    ws.Cells(r, 7).NumberFormat = "@": ws.Cells(r, 7).Value2 = AnalysisTimeText(CStr(uid))
                    ws.Cells(r, 8).Value2 = AnalysisValue(CStr(uid), 8): ws.Cells(r, 9).Value2 = AnalysisValue(CStr(uid), 9)
                    If mPanelAmounts Then
                        ws.Range("J" & r & ":K" & r).Merge: ws.Cells(r, 10).Value2 = item("available")
                        ws.Range("L" & r & ":M" & r).Locked = False: ws.Range("L" & r & ":M" & r).NumberFormat = "#,##0"
                        ws.Cells(r, 12).Value2 = PendingAnalysisValue(mPanelRelation, CStr(uid), item("draft")): ws.Range("L" & r & ":M" & r).Interior.Color = RGB(239, 246, 255)
                    Else
                        ws.Cells(r, 12).Value2 = CellText(AnalysisValue(CStr(uid), 12)) & " " & CStr(item("status"))
                        If Not mPanelScope.Exists(CStr(uid)) Then ws.Cells(r, 12).Value2 = "�\�������O / " & CStr(ws.Cells(r, 12).Value2)
                    End If
                End If
        End Select
        ws.Range("A" & r & ":G" & r).WrapText = True: ws.Range("L" & r & ":M" & r).WrapText = True
    Next r
    PanelLabel ws, "A15:C15", "�O�̈ꗗ"
    PanelLabel ws, "D15:F15", CStr(mPanelPage + 1) & " / " & CStr(Application.Max(1, (mPanelItems.Count + PanelPageSize() - 1) \ PanelPageSize()))
    PanelLabel ws, "G15:I15", "���̈ꗗ"
    PanelLabel ws, "J15:M15", "�I�������s�̏ڍ�"
    If mPanelAmounts Then ws.Range("J15").Value2 = "�w��z�𔽉f"
    If mPanelMode = "pairs" Then ws.Range("J15").Value2 = "�ʔz���𔽉f"
    If (mPanelMode = "detail" Or mPanelMode = "pairs") And Len(mPanelRelation) > 0 Then
        Set details = RelationDetails(mPanelRelation, context)
        PanelLabel ws, "A16:A16", "����"
        PanelLabel ws, "B16:M16", CellText(PendingAnalysisValue(mPanelRelation, "", details("memo")))
        ws.Range("B16:M16").Locked = False: ws.Range("B16:M16").Interior.Color = RGB(239, 246, 255)
    Else
        PanelLabel ws, "A16:M16", "���͔�r�̂��߂̑g�����ł��B�����ׂ̋��z�͕ύX���܂���B"
        ws.Range("A16:M16").Font.Size = 11
    End If
    ws.Range("A5:M5").WrapText = True: ws.Rows(5).RowHeight = 30
    ws.Range("B16:M16").WrapText = True: ws.Rows(16).RowHeight = 30
    If mPanelMode = "pairs" Or mPanelAmounts Then
        If AnalysisAmountDraftIsStale(mPanelRelation, IIf(mPanelMode = "pairs", "F", "T")) Then ws.Range("A5").Value2 = "�ȑO�̗̍p�z����ɂ������͂ł��B�ǉ����삩��A���̓��͂�����g�����Ƃ��ł��܂��B"
    End If
    If mPanelMode = "settings" Then RenderAnalysisSettings ws
    ws.Range("H7:M14").HorizontalAlignment = xlRight
    If mPanelMode <> "settings" Then ws.Range("H7:K14").ShrinkToFit = False
    ws.Range("A2:M16").VerticalAlignment = xlCenter
    BindAnalysisPanel ws, mPanelRelation, (mPanelAmounts Or mPanelMode = "pairs"), mPanelRowIDs
    ProtectGeneratedOutput ws
    mPanelOpen = True: mPanelReady = True
    mPanelRenderedMode = mPanelMode: mPanelRenderedAmounts = mPanelAmounts
    HighlightPanelChoice
    FreezeCashReport ws
    EndAppScope started
    Exit Sub
EH:
    message = Err.Description
    On Error Resume Next
    If CellText(ws.Range("N1").Value2) <> "�ҏW�Ή�" Then ws.Range("A2:M16").Locked = True
    ProtectGeneratedOutput ws
    EndAppScope started
    On Error GoTo 0
    AnalysisPanelMessage "�\�����X�V�ł��܂���ł����B" & message
End Sub

Private Function HasOutsideScope(ByVal ids As Object) As Boolean
    Dim uid As Variant
    For Each uid In ids.Keys
        If Not mPanelScope.Exists(uid) Then HasOutsideScope = True: Exit Function
    Next uid
End Function

Private Sub RenderRelationTotals(ByVal ws As Worksheet, ByVal row As Long, ByVal keys As String)
    Dim uid As Variant, ids As Object, totalW As Double, totalD As Double, label As String
    Set ids = AnalysisIDSet(keys)
    For Each uid In ids.Keys
        totalW = totalW + Val(CellText(AnalysisValue(CStr(uid), 8))): totalD = totalD + Val(CellText(AnalysisValue(CStr(uid), 9)))
        If Len(label) = 0 Then label = AnalysisAccountText(CStr(uid))
    Next uid
    ws.Cells(row, 8).Value2 = totalW: ws.Cells(row, 9).Value2 = totalD: ws.Cells(row, 10).Value2 = totalD - totalW
    ws.Cells(row, 1).Value2 = CStr(ws.Cells(row, 1).Value2) & " / " & label
End Sub

Public Sub AnalysisPanelMessage(ByVal message As String)
    Dim previousEvents As Boolean
    previousEvents = Application.EnableEvents
    On Error Resume Next
    Application.EnableEvents = False
    If CashReportHeader(GetSheet(SH_OUTPUT_TX)) > 1 Then GetSheet(SH_OUTPUT_TX).Range("A5").Value2 = message
    Application.StatusBar = message
    Application.EnableEvents = previousEvents
    On Error GoTo 0
End Sub

Private Sub RunPanelSearch(ByVal anchors As Object, ByVal bundles As Boolean, Optional ByVal pathFrom As String = "", Optional ByVal excluded As Object = Nothing)
    Dim result As Object
    PauseAnalysisSearch
    mPanelLastSelection = ""
    If anchors.Count = 1 And Not bundles And Len(pathFrom) = 0 Then mPanelLastSelection = AnalysisIDKey(anchors)
    Set mPanelScope = AnalysisVisibleIDs(): mPanelScopeKey = "!"
    Set result = SearchAnalysis(anchors, bundles, pathFrom, excluded, mPanelPathLinks, mPanelPathID)
    RestorePanelSearchPath result
    Set mPanelItems = result("items"): mPanelResultComplete = CBool(result("complete"))
    mPanelResultNote = CStr(result("context"))
    mPanelMode = "candidates": mPanelPage = 0: mPanelChoice = 0: mPanelAmounts = False
    mPanelRelation = "": mPanelDetailIDs = ""
    mPanelNotice = CStr(result("message"))
    If anchors.Count = 1 And Len(pathFrom) = 0 Then mPanelNotice = "�I�𖾍ׂ̌�� / " & mPanelNotice
    If Len(pathFrom) > 0 Then mPanelNotice = "�o�H�̑��� / " & mPanelNotice
    RenderAnalysisPanel
    ScheduleAnalysisSearch
End Sub

Private Sub RestorePanelSearchPath(ByVal result As Object)
    mPanelPathFrom = CStr(result("pathFrom"))
    mPanelPathLinks = CStr(result("pathLinks")): mPanelPathID = CStr(result("pathID"))
    Set mPanelDetailCandidate = Nothing
End Sub

Public Sub ShowAllAnalysisCandidates()
    InitializePanelState
    Set mPanelScope = AnalysisVisibleIDs(): mPanelScopeKey = "!": mPanelPathFrom = "": mPanelPathLinks = "": mPanelPathID = ""
    SetAnalysisBundleShape ""
    SetAnalysisDeepSearch False
    SetAnalysisWideSearch False
    RunPanelSearch mPanelScope, True
End Sub

Public Sub ShowAnalysisAccounts()
    ShowPanelAggregate "����"
End Sub

Public Sub ShowAnalysisMonths()
    ShowPanelAggregate "��"
End Sub

Public Sub ShowAnalysisDescriptions()
    ShowPanelAggregate "�E�v"
End Sub

Private Sub ShowPanelAggregate(ByVal mode As String)
    PauseAnalysisSearch
    InitializePanelState
    Set mPanelScope = AnalysisVisibleIDs(): mPanelScopeKey = "!"
    Set mPanelItems = AnalysisAggregates(mode, mPanelScope)
    mPanelRelation = "": mPanelDetailIDs = "": mPanelLastSelection = "": mPanelResultNote = ""
    Set mPanelSelected = CreateObject("Scripting.Dictionary"): Set mPanelAnchor = CreateObject("Scripting.Dictionary")
    mPanelPathFrom = "": mPanelPathID = "": mPanelPathLinks = ""
    mPanelAmounts = False: mPanelMode = "aggregate": mPanelAggregate = mode: mPanelPage = 0: mPanelChoice = 0
    mPanelNotice = mode & "�ʏW�v�B�s���_�u���N���b�N����Ɠ����\�����܂��B"
    If mode = "�l��" Then mPanelNotice = "���������E�֌W�������O���[�v�Ƃ��Ă��܂��B�ʐl��\�L�Ⴂ�́A���ׂ�I�����đ��상�j���[���番���E�����ł��܂��B"
    RenderAnalysisPanel
End Sub

Public Sub ShowAnalysisRecords()
    PauseAnalysisSearch
    InitializePanelState
    Set mPanelItems = AnalysisRelationsList()
    mPanelRelation = "": mPanelDetailIDs = ""
    mPanelLastSelection = "": mPanelResultNote = ""
    Set mPanelSelected = CreateObject("Scripting.Dictionary"): Set mPanelAnchor = CreateObject("Scripting.Dictionary")
    mPanelPathFrom = "": mPanelPathID = "": mPanelPathLinks = ""
    mPanelMode = "records": mPanelPage = 0: mPanelChoice = 0: mPanelAmounts = False
    mPanelNotice = "�L�^�����֘A�t���ƌo�H�B�����Ǝw��z�͏ڍׂŕҏW�ł��܂��B"
    RenderAnalysisPanel
End Sub

Public Sub ShowAnalysisAggregateMenu()
    Dim menu As Object
    On Error GoTo Done
    Set menu = Application.CommandBars.Add(Position:=5, Temporary:=True)
    AddInputMenuItem menu, "�l����", "ShowAnalysisPeople"
    AddInputMenuItem menu, "�l���ʂ̗̍p�z", "ShowAdoptedPeople"
    AddInputMenuItem menu, "�̗p�����֘A�̐l���ԁE�l�����̈ړ�", "ShowAdoptedFlows"
    AddInputMenuItem menu, "������", "ShowAnalysisAccounts"
    AddInputMenuItem menu, "����", "ShowAnalysisMonths"
    AddInputMenuItem menu, "�E�v��", "ShowAnalysisDescriptions"
    AddInputMenuItem menu, "�o�^�����c���̑���", "ShowAnalysisBalances"
    menu.ShowPopup
Done:
    On Error Resume Next
    If Not menu Is Nothing Then menu.Delete
    On Error GoTo 0
End Sub

Public Sub ShowAnalysisSearchMenu()
    Dim menu As Object, shapes As Object, keys As Variant, firstItem As Object
    On Error GoTo Done
    InitializePanelState
    Set menu = Application.CommandBars.Add(Position:=5, Temporary:=True)
    If mPanelAnchor.Count = 1 Or mPanelSelected.Count = 1 Then
        AddInputMenuItem menu, "1��1�̌��", "ShowSelectedAnalysisCandidates"
        Set shapes = AddInputSubMenu(menu, "�`��I��ŒT��")
        AddInputMenuItem shapes, "1��2", "ShowBundle12"
        AddInputMenuItem shapes, "2��1", "ShowBundle21"
        AddInputMenuItem shapes, "1��3", "ShowBundle13"
        AddInputMenuItem shapes, "3��1", "ShowBundle31"
        AddInputMenuItem shapes, "2��2", "ShowBundle22"
    End If
    AddInputMenuItem menu, "�ő�3��3�܂ŒT��", "ShowAnalysisBundles"
    AddInputMenuItem menu, "�ő�6��6�܂ŏڂ����T��", "ShowDeepAnalysisCandidates"
    AddInputMenuItem menu, "���z�̑傫���Q�l�����T��", "ShowWideAnalysisCandidates"
    If AnalysisSearchCanContinue() Then
        AddInputMenuItem menu, "�O������ő����ĒT��", "ContinuePanelSearch"
        AddInputMenuItem menu, "�����𒆒f", "PausePanelSearch"
    End If
    AddInputMenuItem menu, "�����ςݔ͈͂Ō��̂Ȃ�����", "ShowUnmatchedAnalysis"
    AddInputMenuItem menu, "���������E�������", "ShowAnalysisSettings"
    If Len(mPanelPathID) > 0 Then AddInputMenuItem menu, "�o�H�̐ڑ��ꗗ", "ShowPanelPathConnections"
    If (mPanelMode = "detail" Or mPanelMode = "pairs") And Len(mPanelRelation) > 0 Then
        If mPanelItems.Count > 0 Then
            Set firstItem = mPanelItems(1)
            If firstItem("type") = "T" Then
                If mPanelSelected.Count = 1 Then
                    keys = mPanelSelected.Keys
                    If AnalysisSide(CStr(keys(0))) = "D" Then
                        AddInputMenuItem menu, "���̓�������o�H�̑�����T��", "ContinueAnalysisPath", True
                        If Len(mPanelPathID) > 0 Then AddInputMenuItem menu, "�o�H���̊�����Ԃ֐ڑ��i�����j", "ShowExistingPathConnections"
                    End If
                End If
                AddInputMenuItem menu, "�֘A�t���̋��z���w��", "ShowRelationAmountEditor", True
                AddInputMenuItem menu, "�o����������ւ̌ʔz��", "ShowRelationPairEditor"
            End If
        End If
        If AnalysisAmountDraftIsStale(mPanelRelation, IIf(mPanelMode = "pairs", "F", "T")) Then AddInputMenuItem menu, "�ȑO�̋��z���͂�����g��", "UsePreviousPanelAmounts"
        AddInputMenuItem menu, "���̊֘A�t��������", "DeletePanelRelation"
    End If
    menu.ShowPopup
Done:
    On Error Resume Next
    If Not menu Is Nothing Then menu.Delete
    On Error GoTo 0
End Sub

Public Sub ShowAnalysisActions()
    Dim menu As Object
    On Error GoTo Done
    Set menu = Application.CommandBars.Add(Position:=5, Temporary:=True)
    AddInputMenuItem menu, IIf(mPanelExpanded, "���ׂ��L���i4���\���j", "�ꗗ���L���i8���\���j"), "ToggleAnalysisListSize"
    AddInputMenuItem menu, "���֖͂߂�", "ShowInputSheet"
    AddInputMenuItem menu, "�ۑ�", "SaveToolWorkbook"
    AddInputMenuItem menu, "Excel�o��", "ShowExportOptions"
    AddInputMenuItem menu, "���ׂ���בւ�", "ShowCurrentReportSortMenu"
    AddInputMenuItem menu, "A4�c�̎�������\���o��", "ExportCashPortrait"
    AddInputMenuItem menu, "�I�������̐l�����܂Ƃ߂�", "GroupSelectedPeople"
    AddInputMenuItem menu, "�I�������̐l���𕪂���", "SeparateSelectedPeople"
    If Not mPanelSelected Is Nothing Then
        If mPanelSelected.Count = 1 Then
            AddInputMenuItem menu, "�����ׂ����", "EditPanelSourceTransaction", True
            AddInputMenuItem menu, "��荞�݌���\��", "ShowPanelSource"
        End If
    End If
    If CanUndoRelationRemoval() Then AddInputMenuItem menu, "�֘A�t���̉��������ɖ߂�", "UndoAnalysisRelationRemoval"
    AddInputMenuItem menu, "���݂̏W�v�E��r��Excel�o��", "ExportCurrentAnalysis"
    menu.ShowPopup
Done:
    On Error Resume Next
    If Not menu Is Nothing Then menu.Delete
    On Error GoTo 0
End Sub

Public Sub ShowSelectedAnalysisCandidates()
    InitializePanelState
    If mPanelSelected.Count = 1 Then Set mPanelAnchor = mPanelSelected
    If mPanelAnchor.Count <> 1 Then AnalysisPanelMessage "����T�����ׂ�1���I�����Ă��������B": Exit Sub
    mPanelPathFrom = ""
    SetAnalysisBundleShape ""
    SetAnalysisDeepSearch False
    SetAnalysisWideSearch False
    RunPanelSearch mPanelAnchor, False
End Sub

Public Sub ShowAnalysisBundles()
    ShowBundleShape ""
End Sub

Public Sub RegisterPanelRelation()
    Dim ids As Object, item As Object, relationID As String, toID As String, evidence As String
    Dim pathFrom As String, pathLinks As String, pathID As String, savedPath As String
    On Error GoTo EH
    InitializePanelState
    If PanelCandidateIsStale() Then AnalysisPanelMessage "�o�^�ςݖ��ׂ��ς��܂����B���������������Ă���֘A�t���Ă��������B": Exit Sub
    If Not CanRegisterPanelSelection() Then AnalysisPanelMessage "�֘A�t������܂��͖��ׂ�I�����Ă��������B": Exit Sub
    If mPanelMode = "candidates" Then
        Set item = mPanelItems(mPanelChoice): Set ids = AnalysisIDSet(CStr(item("ids")))
    ElseIf mPanelMode = "detail" Then
        Set ids = AnalysisIDSet(mPanelDetailIDs)
        Set item = mPanelDetailCandidate
    Else
        Set ids = mPanelSelected
    End If
    If Not item Is Nothing Then
        evidence = CStr(item("evidence")): toID = CStr(item("anchor"))
        pathFrom = CStr(item("bridge")): pathLinks = CStr(item("pathLinks")): pathID = CStr(item("pathID"))
    End If
    relationID = RegisterCandidateRelation(ids, mPanelResultNote, evidence, pathFrom, pathLinks, pathID, toID, savedPath)
    If Len(savedPath) > 0 Then
        mPanelPathID = savedPath: mPanelPathLinks = RelationMemberKeys(savedPath, ReadAnalysisRelations())
        mPanelPathFrom = ""
    Else
        mPanelPathID = "": mPanelPathLinks = "": mPanelPathFrom = ""
    End If
    OpenPanelRelation relationID
    Exit Sub
EH:
    If Len(relationID) > 0 Then
        AnalysisPanelMessage "�֘A�t���̕ۑ��͊������܂����B�\�����J���܂���ł����B" & Err.Description
    Else
        AnalysisPanelMessage Err.Description
    End If
End Sub

Private Sub OpenPanelChoice()
    Dim item As Object, issue As String
    FlushPendingAnalysisEdits
    If mPanelMode = "pairs" Then
        issue = CommitRelationPairs(mPanelRelation)
        If Len(issue) > 0 Then AnalysisPanelMessage issue: Exit Sub
        OpenPanelRelation mPanelRelation: Exit Sub
    End If
    If mPanelAmounts Then
        issue = CommitRelationAmounts(mPanelRelation)
        If Len(issue) > 0 Then AnalysisPanelMessage issue: Exit Sub
        mPanelAmounts = False: OpenPanelRelation mPanelRelation: Exit Sub
    End If
    If Not PanelChoiceAvailable() Then Exit Sub
    Set item = mPanelItems(mPanelChoice)
    Select Case mPanelMode
        Case "candidates": ShowPanelDetail CStr(item("ids")), item
        Case "aggregate", "connections": ShowPanelDetail CStr(item("ids"))
        Case "records": OpenPanelRelation CStr(item("id"))
        Case "detail"
            If item("type") = "L" Then
                OpenPanelRelation CStr(item("id"))
            Else
                Set mPanelSelected = AnalysisIDSet(CStr(item("id")))
                EditPanelSourceTransaction
            End If
    End Select
End Sub

Private Sub ShowPanelDetail(ByVal ids As String, Optional ByVal candidate As Object = Nothing)
    Dim uid As Variant, members As Object, item As Object
    mReadingSearch = Not candidate Is Nothing
    If Not mReadingSearch Then PauseAnalysisSearch
    FlushPendingAnalysisEdits
    mPanelLastSelection = ""
    mPanelDetailIDs = ids: mPanelRelation = "": mPanelAmounts = False
    Set mPanelDetailCandidate = candidate
    Set mPanelSelected = CreateObject("Scripting.Dictionary")
    Set members = AnalysisIDSet(ids): Set mPanelItems = New Collection
    For Each uid In members.Keys
        Set item = CreateObject("Scripting.Dictionary")
        item("id") = CStr(uid): item("type") = "T": item("label") = AnalysisAccountText(CStr(uid)): item("status") = CandidateMemberEvidence(candidate, CStr(uid))
        If Not AnalysisIDs().Exists(CStr(uid)) Then item("label") = "�폜��������": item("status") = "�����ׂ͍폜�ς�"
        mPanelItems.Add item
    Next uid
    mPanelMode = "detail": mPanelPage = 0: mPanelChoice = 0
    mPanelNotice = "��r���̖��ׁB�����ׂ��������ꍇ�͍s���_�u���N���b�N���܂��B"
    If mReadingSearch Then mPanelNotice = "�I�����������Œ肵�ĕ\�����Ă��܂��B�����̑����͌��ꗗ�֔��f�ł��܂��B"
    RenderAnalysisPanel
End Sub

Private Sub OpenPanelRelation(ByVal relationID As String)
    Dim details As Object, context As Object
    PauseAnalysisSearch
    FlushPendingAnalysisEdits
    Set context = NewRelationContext(): Set details = RelationDetails(relationID, context)
    Set mPanelSelected = CreateObject("Scripting.Dictionary")
    mPanelLastSelection = "": mPanelResultNote = "": mPanelPathFrom = ""
    mPanelRelation = relationID: mPanelDetailIDs = "": mPanelMode = "detail": mPanelAmounts = False
    Set mPanelDetailCandidate = Nothing
    Set mPanelItems = details("rows"): mPanelPage = 0: mPanelChoice = 0: mPanelNotice = CStr(details("status"))
    mPanelResultNote = CStr(details("sourceContext"))
    If details("kind") = "P" Then
        mPanelPathID = relationID: mPanelPathLinks = RelationMemberKeys(relationID, context("data"))
    End If
    RenderAnalysisPanel context
End Sub

Public Sub ShowRelationAmountEditor()
    Dim details As Object, context As Object
    If Len(mPanelRelation) = 0 Then Exit Sub
    On Error GoTo EH
    FlushPendingAnalysisEdits
    Set context = NewRelationContext(): Set details = RelationDetails(mPanelRelation, context)
    If details("kind") <> "G" Then AnalysisPanelMessage "���z�͊e��Ԃ̊֘A�t���Ŏw�肵�܂��B": Exit Sub
    InitializeRelationAmounts mPanelRelation, context
    mPanelMode = "detail": mPanelAmounts = True: mPanelPage = 0: mPanelChoice = 0: mPanelNotice = "�����������Ɖ����\��ɂȂ�܂��B���f����܂ō̗p�z�͑O��̂܂܂ł��B"
    RenderAnalysisPanel context
    Exit Sub
EH:
    AnalysisPanelMessage Err.Description
End Sub

Public Sub DeletePanelRelation()
    If Len(mPanelRelation) = 0 Then Exit Sub
    On Error GoTo EH
    FlushPendingAnalysisEdits
    RemoveAnalysisRelation mPanelRelation
    mPanelRelation = "": ShowAnalysisRecords
    Exit Sub
EH:
    AnalysisPanelMessage Err.Description
End Sub

Public Sub EditPanelSourceTransaction()
    Dim keys As Variant, row As Long
    If mPanelSelected Is Nothing Then Exit Sub
    If mPanelSelected.Count <> 1 Then AnalysisPanelMessage "�������錳���ׂ�1���I�����Ă��������B": Exit Sub
    keys = mPanelSelected.Keys
    row = FindReportTransaction(CStr(keys(0)))
    If row > 0 Then EditReportTransaction GetSheet(SH_OUTPUT_TX).Cells(row, 12) Else EditTransactionByID CStr(keys(0))
End Sub

Public Sub ShowCorrectedAnalysisTransaction(ByVal uid As String)
    InitializePanelState
    Set mPanelScope = AnalysisVisibleIDs(): mPanelScopeKey = "!"
    ShowPanelDetail uid
End Sub

Public Sub ContinueAnalysisPath()
    Dim keys As Variant, uid As String, data As Variant, headers As Object, excluded As Object, link As Variant, member As Variant
    Dim links As Object, details As Object, orderedLinks As Variant, members As Object, context As Object
    On Error GoTo EH
    If mPanelSelected Is Nothing Then Exit Sub
    If mPanelSelected.Count <> 1 Or Len(mPanelRelation) = 0 Then AnalysisPanelMessage "�֘A�t���̏ڍׂŁA�����̋N�_�ƂȂ������1���I�����Ă��������B": Exit Sub
    keys = mPanelSelected.Keys: uid = CStr(keys(0))
    If AnalysisSide(uid) <> "D" Then AnalysisPanelMessage "�o�H�̑����͓������N�_�ɂ��܂��B": Exit Sub
    Set context = NewRelationContext()
    Set details = RelationDetails(mPanelRelation, context)
    If details("kind") <> "G" Then AnalysisPanelMessage "��Ԃ̏ڍׂ��J���A�N�_�̓�����I�����Ă��������B": Exit Sub
    data = context("data")
    Set members = AnalysisIDSet(RelationMemberKeys(mPanelRelation, data))
    If Not members.Exists(uid) Then AnalysisPanelMessage "�\�����̊֘A�t���Ɋ܂܂�������I�����Ă��������B": Exit Sub
    If Len(mPanelPathID) = 0 Then mPanelPathLinks = mPanelRelation
    orderedLinks = Split(mPanelPathLinks, "|")
    If Not AnalysisIDSet(mPanelPathLinks).Exists(mPanelRelation) Then mPanelPathLinks = mPanelRelation: mPanelPathID = ""
    Set excluded = CreateObject("Scripting.Dictionary")
    For Each link In Split(mPanelPathLinks, "|")
        For Each member In Split(RelationMemberKeys(CStr(link), data), "|")
            excluded(CStr(member)) = True
        Next member
    Next link
    mPanelPathFrom = uid
    SetAnalysisBundleShape ""
    RunPanelSearch mPanelSelected, True, uid, excluded
    Exit Sub
EH:
    AnalysisPanelMessage Err.Description
End Sub

Public Sub ShowAnalysisSettings()
    PauseAnalysisSearch
    InitializePanelState
    If mPanelSelected.Count = 1 Then Set mPanelAnchor = mPanelSelected
    Set mPanelSelected = CreateObject("Scripting.Dictionary")
    mPanelPathFrom = ""
    mPanelAmounts = False: mPanelMode = "settings": mPanelNotice = "�ʏ�̍��z�͑傫������1%�i�Œ�1,000�~�j�ƒǉ�����̏��������B�����������K�p���܂��B"

    Set mPanelItems = New Collection: mPanelPage = 0
    RenderAnalysisPanel
End Sub

Private Sub RenderAnalysisSettings(ByVal ws As Worksheet)
    Dim r As Long, labels As Variant, defaults As Variant
    ws.Range("A6:M10").UnMerge: ws.Range("A6:M10").Clear
    labels = Array("�O��̓����i����j", "�ʏ���̒ǉ�����i�~�j", "�ʏ���̍��z��������i���j")
    defaults = Array(3, 10000, 10)
    For r = 7 To 9
        PanelLabel ws, "A" & r & ":G" & r, CStr(labels(r - 7))
        PanelLabel ws, "H" & r & ":M" & r, CStr(AnalysisSetting(r + 23, CDbl(defaults(r - 7))))
        ws.Range("H" & r & ":M" & r).Locked = False: ws.Range("H" & r & ":M" & r).Interior.Color = RGB(239, 246, 255)
    Next r
    PanelLabel ws, "A10:G10", "����̋�s�E�����E�����ԍ��i������v�^�󗓂Ȃ�S���j"
    PanelLabel ws, "H10:M10", AnalysisPartnerFilter()
    ws.Range("H10:M10").Locked = False: ws.Range("H10:M10").Interior.Color = RGB(239, 246, 255)
End Sub

Public Function CurrentAnalysisExportItems(Optional ByVal context As Object = Nothing) As Collection
    Dim details As Object, selected As New Collection
    InitializePanelState
    RefreshCurrentAnalysisScope True
    If PanelCandidateIsStale() Then Err.Raise vbObjectError + 3461, "CurrentAnalysisExportItems", "�o�^�ςݖ��ׂ��ς��܂����B���������������Ă���o�͂��Ă��������B"
    If mPanelMode = "records" Then
        If PanelChoiceAvailable() Then selected.Add mPanelItems(mPanelChoice)
        Set CurrentAnalysisExportItems = selected
    ElseIf mPanelMode = "pairs" And Len(mPanelRelation) > 0 Then
        Set CurrentAnalysisExportItems = RelationPairRows(mPanelRelation, False, context)
    ElseIf mPanelMode = "detail" And Len(mPanelRelation) > 0 Then
        Set details = RelationDetails(mPanelRelation, context)
        Set CurrentAnalysisExportItems = details("rows")
    Else
        Set CurrentAnalysisExportItems = mPanelItems
    End If
End Function

Public Function AnalysisPanelIsOpen() As Boolean
    AnalysisPanelIsOpen = mPanelOpen
End Function

Public Function AnalysisPanelRelationID() As String
    AnalysisPanelRelationID = mPanelRelation
End Function

Public Sub RestoreAnalysisAfterCorrection(ByVal uid As String, ByVal relationID As String)
    InitializePanelState
    Set mPanelScope = AnalysisVisibleIDs(): mPanelScopeKey = "!"
    If Len(relationID) > 0 Then OpenPanelRelation relationID Else ShowPanelDetail uid
End Sub

Public Function CurrentAnalysisExportMode() As String
    CurrentAnalysisExportMode = mPanelMode
End Function

Public Function CurrentAnalysisExportNote() As String
    CurrentAnalysisExportNote = CurrentPanelContext() & " / " & mPanelNotice
    If PendingInputAccountCount() > 0 Then CurrentAnalysisExportNote = CurrentAnalysisExportNote & " / " & PendingInputSummary()
End Function

Public Sub ShowAnalysisBalances()
    PauseAnalysisSearch
    InitializePanelState
    Set mPanelScope = AnalysisVisibleIDs(): mPanelScopeKey = "!"
    Set mPanelItems = AnalysisBalanceChanges(mPanelScope)
    mPanelLastSelection = "": mPanelResultNote = "": mPanelRelation = "": mPanelDetailIDs = ""
    Set mPanelSelected = CreateObject("Scripting.Dictionary"): Set mPanelAnchor = CreateObject("Scripting.Dictionary")
    mPanelPathFrom = "": mPanelPathID = "": mPanelPathLinks = ""
    mPanelAmounts = False: mPanelMode = "balance": mPanelPage = 0: mPanelChoice = 0
    mPanelNotice = "�����̕��������̂ݔ��f�E�c���͑S���ԁB��������E�F�̍i���݂͓K�p���܂���B"
    RenderAnalysisPanel
End Sub

Private Function CompactAnalysisAccount(ByVal uid As String) As String
    CompactAnalysisAccount = CellText(AnalysisValue(uid, 3)) & " " & CellText(AnalysisValue(uid, 1)) & " " & Right$(CellText(AnalysisValue(uid, 5)), 4)
End Function

Private Function CurrentPanelContext() As String
    If Len(mPanelResultNote) > 0 Then
        CurrentPanelContext = mPanelResultNote
    ElseIf mPanelMode = "balance" Then
        CurrentPanelContext = "�����̕��������̂ݔ��f�E�c���͑S����"
    ElseIf Len(mPanelRelation) > 0 Or mPanelMode = "records" Then
        CurrentPanelContext = "���p�҂��L�^�����֘A�t���E����"
    Else
        CurrentPanelContext = "�Ώۂ̓o�^�ςݖ��� " & mPanelScope.Count & "��"
        If mPanelMode = "aggregate" Then CurrentPanelContext = CurrentPanelContext & "�^���݂̕\�������ɘA��"
        If mPanelAggregate = "�֘A���Ƃ̗̍p�z" And mPanelMode = "aggregate" Then CurrentPanelContext = CurrentPanelContext & "�^�֘A�͕\���͈͊O�̍\�����ׂ��܂�"
    End If
End Function

Private Function PanelChoiceAvailable() As Boolean
    If mPanelItems Is Nothing Then Exit Function
    PanelChoiceAvailable = (mPanelChoice > mPanelPage * PanelPageSize() And mPanelChoice <= (mPanelPage + 1) * PanelPageSize() And mPanelChoice <= mPanelItems.Count)
End Function

Private Function CanRegisterPanelSelection() As Boolean
    If PanelCandidateIsStale() Then Exit Function
    Select Case mPanelMode
        Case "candidates": CanRegisterPanelSelection = PanelChoiceAvailable()
        Case "detail": CanRegisterPanelSelection = (Len(mPanelDetailIDs) > 0 And mPanelItems.Count >= 2)
        Case "selection": CanRegisterPanelSelection = (mPanelSelected.Count >= 2)
    End Select
End Function

Private Sub ClearPanelChoice()
    mPanelChoice = 0
    Set mPanelSelected = CreateObject("Scripting.Dictionary")
End Sub

Private Sub HighlightPanelChoice()
    Dim ws As Worksheet, row As Long, started As Boolean
    If mPanelMode = "settings" Then Exit Sub
    On Error GoTo Done
    AppBegin: started = True
    Set ws = GetSheet(SH_OUTPUT_TX)
    ws.Range("A7:K14").Interior.Color = vbWhite
    If PanelChoiceAvailable() Then
        row = 6 + mPanelChoice - mPanelPage * PanelPageSize()
        ws.Range("A" & row & ":K" & row).Interior.Color = RGB(224, 239, 247)
    End If
    ws.Range("J4").Value2 = ""
    If CanRegisterPanelSelection() Then ws.Range("J4").Value2 = "�֘A�t����"
Done:
    EndAppScope started
End Sub


Public Sub FlushPendingAnalysisEdits()
    ReplayAnalysisEdits
End Sub

Public Sub ShowBundle12()
    ShowBundleShape "1:2"
End Sub
Public Sub ShowBundle21()
    ShowBundleShape "2:1"
End Sub
Public Sub ShowBundle13()
    ShowBundleShape "1:3"
End Sub
Public Sub ShowBundle31()
    ShowBundleShape "3:1"
End Sub
Public Sub ShowBundle22()
    ShowBundleShape "2:2"
End Sub
Private Sub ShowBundleShape(ByVal shape As String)
    InitializePanelState
    If mPanelSelected.Count = 1 Then Set mPanelAnchor = mPanelSelected
    If mPanelAnchor.Count <> 1 Then AnalysisPanelMessage "�����E���Z��T�����ׂ�1���I�����Ă��������B": Exit Sub
    mPanelPathFrom = ""
    SetAnalysisDeepSearch False
    SetAnalysisWideSearch False
    SetAnalysisBundleShape shape
    RunPanelSearch mPanelAnchor, True
End Sub

Public Sub OpenCashAnalysis()
    Dim started As Boolean, message As String
    On Error GoTo EH
    AppBegin: started = True
    EnsureCurrentOutputs
    GetSheet(SH_OUTPUT_TX).Activate
    ShowAnalysisAccounts
    FreezeCashReport GetSheet(SH_OUTPUT_TX)
    EndAppScope started
    Exit Sub
EH:
    message = Err.Description
    EndAppScope started
    AnalysisPanelMessage "�W�v��\���ł��܂���ł����B�o�^�ς݂̒��[�͂��̂܂ܗ��p�ł��܂��B" & message
End Sub

Private Function PanelPageSize() As Long
    Dim available As Double
    PanelPageSize = 4
    If Not mPanelExpanded Then Exit Function
    On Error GoTo Done
    available = ActiveWindow.UsableHeight * 100 / ActiveWindow.Zoom
    If available >= 500 Then PanelPageSize = 8
Done:
End Function

Public Sub ToggleAnalysisListSize()
    InitializePanelState
    PauseAnalysisSearch
    mPanelExpanded = Not mPanelExpanded
    mPanelPage = 0: mPanelChoice = 0
    If mPanelExpanded And PanelPageSize() = 4 Then mPanelNotice = "���̉�ʂ̍����ł�4���\���ł��BExcel�̕\���{����E�B���h�E�̍����Œ����ł��܂��B"
    RenderAnalysisPanel
End Sub

Public Sub ShowAnalysisCandidateEntry()
    InitializePanelState
    If mPanelAnchor.Count = 1 Then
        ShowBundleShape ""
    Else
        ShowAllAnalysisCandidates
    End If
End Sub

Public Sub ContinuePanelSearch(Optional ByVal automatic As Boolean = False)
    Dim result As Object, selectedKey As String, i As Long, item As Object
    On Error GoTo EH
    If automatic And mPanelMode <> "candidates" And Not (mPanelMode = "detail" And mReadingSearch) Then PauseAnalysisSearch: Exit Sub
    If Not AnalysisSearchCanContinue() Then
        If automatic Or Not AnalysisSearchIsCurrent() Then
            If Not automatic Then AnalysisPanelMessage "�o�^���e���ς��܂����B���݂̏����Ō����������Ă��������B"
            Exit Sub
        End If
    End If
    If mPanelMode = "candidates" And PanelChoiceAvailable() Then
        Set item = mPanelItems(mPanelChoice): selectedKey = CStr(item("key"))
    ElseIf mPanelMode = "detail" And mReadingSearch Then
        If Not mPanelDetailCandidate Is Nothing Then selectedKey = CStr(mPanelDetailCandidate("key"))
    End If
    Set result = ContinueSearchAnalysis()
    If automatic Then
        If Len(selectedKey) > 0 Or (mPanelMode = "detail" And mReadingSearch) Or (mPanelMode = "candidates" And mPanelPage > 0) Then
            mPanelNotice = CStr(result("message")) & "�^�\�����̌��͌Œ�B�����ĒT���ňꗗ���X�V"
            AnalysisPanelMessage mPanelNotice
            ScheduleAnalysisSearch
            Exit Sub
        End If
    End If
    mReadingSearch = False
    RestorePanelSearchPath result
    Set mPanelItems = result("items")
    mPanelMode = "candidates": mPanelAmounts = False: mPanelRelation = "": mPanelDetailIDs = ""
    mPanelResultComplete = CBool(result("complete")): mPanelResultNote = CStr(result("context"))
    mPanelNotice = CStr(result("message")): mPanelChoice = 0
    If Len(selectedKey) > 0 Then
        i = 0
        For Each item In mPanelItems
            i = i + 1
            If CStr(item("key")) = selectedKey Then mPanelChoice = i: mPanelPage = (i - 1) \ PanelPageSize(): Exit For
        Next item
    End If
    RenderAnalysisPanel
    ScheduleAnalysisSearch
    Exit Sub
EH:
    PauseAnalysisSearch
    AnalysisPanelMessage "���͕ێ����Ă��܂��B" & Err.Description
End Sub

Public Sub PausePanelSearch()
    PauseAnalysisSearch
    AnalysisPanelMessage "�����𒆒f���܂����B�����ĒT���Ɠ����ʒu����ĊJ���܂��B"
End Sub

Public Sub ShowDeepAnalysisCandidates()
    InitializePanelState
    If mPanelSelected.Count = 1 Then Set mPanelAnchor = mPanelSelected
    If mPanelAnchor.Count <> 1 Then AnalysisPanelMessage "�ڂ����T���N�_���ׂ�1���I�����Ă��������B": Exit Sub
    mPanelPathFrom = "": SetAnalysisBundleShape ""
    SetAnalysisDeepSearch True: SetAnalysisWideSearch False
    RunPanelSearch mPanelAnchor, True
End Sub

Public Sub ShowWideAnalysisCandidates()
    InitializePanelState
    If mPanelSelected.Count = 1 Then Set mPanelAnchor = mPanelSelected
    If mPanelAnchor.Count <> 1 Then AnalysisPanelMessage "�Q�l����T���N�_���ׂ�1���I�����Ă��������B": Exit Sub
    mPanelPathFrom = "": SetAnalysisBundleShape ""
    SetAnalysisDeepSearch False: SetAnalysisWideSearch True
    RunPanelSearch mPanelAnchor, True
End Sub

Public Sub ShowUnmatchedAnalysis()
    Dim ids As Object, result As Object
    InitializePanelState: PauseAnalysisSearch
    If Not AnalysisSearchIsCurrent() Then AnalysisPanelMessage "�o�^���e���ς��܂����B���������������Ă��������B": Exit Sub
    Set ids = SearchUnmatchedIDs()
    If ids.Count = 0 Then AnalysisPanelMessage "�����N�_�̒��ɁA�����_�Ō��̂Ȃ����ׂ͂���܂���B": Exit Sub
    Set result = CurrentSearchResult()
    ShowPanelDetail AnalysisIDKey(ids)
    mPanelResultNote = CStr(result("context"))
    mPanelNotice = IIf(CBool(result("complete")), "�w�肵���T���͈͂Ō��Ȃ�", "�T���r���ŁA�����_�ł͌��Ȃ�") & "�B����̗L���⎑���̐������m�肷��\���ł͂���܂���B"
    RenderAnalysisPanel
End Sub

Public Sub ShowAnalysisPeople()
    ShowPanelAggregate "�l��"
End Sub

Public Function PanelSelectedAccountIDs() As Object
    Dim result As Object, uid As Variant, key As String
    Set result = CreateObject("Scripting.Dictionary")
    If Not mPanelSelected Is Nothing Then
        For Each uid In mPanelSelected.Keys
            key = CellText(AnalysisValue(CStr(uid), TX_ID_COL))
            If Len(key) > 0 Then result(key) = True
        Next uid
    End If
    Set PanelSelectedAccountIDs = result
End Function

Public Sub ShowExistingPathConnections()
    Dim menu As Object, button As Object, keys As Variant, fromID As String, data As Variant
    Dim link As Variant, uid As Variant, count As Long
    On Error GoTo Done
    If Len(mPanelPathID) = 0 Or mPanelSelected.Count <> 1 Then Exit Sub
    keys = mPanelSelected.Keys: fromID = CStr(keys(0))
    If AnalysisSide(fromID) <> "D" Then Exit Sub
    data = ReadAnalysisRelations()
    Set menu = Application.CommandBars.Add(Position:=5, Temporary:=True)
    For Each link In Split(mPanelPathLinks, "|")
        If CStr(link) <> mPanelRelation Then
            For Each uid In Split(RelationMemberKeys(CStr(link), data), "|")
                If AnalysisSide(CStr(uid)) = "W" Then
                    If CellText(AnalysisValue(fromID, TX_ID_COL)) = CellText(AnalysisValue(CStr(uid), TX_ID_COL)) Then
                        If AnalysisChronology(fromID, CStr(uid)) >= 0 Then
                            Set button = menu.Controls.Add(Type:=1)
                            button.Caption = AnalysisDateText(CStr(uid)) & " " & AnalysisTimeText(CStr(uid)) & " / �o�� " & Format$(AnalysisAmount(CStr(uid)), "#,##0") & "�~ / " & CellText(AnalysisValue(CStr(uid), 12))
                            button.Tag = CStr(uid): button.OnAction = MacroRef("ConnectExistingPathWithdrawal")
                            count = count + 1
                        End If
                    End If
                End If
            Next uid
        End If
    Next link
    If count = 0 Then AnalysisPanelMessage "���������̌㑱�o�����A�o�H���̑���Ԃɂ���܂���B" Else menu.ShowPopup
Done:
    On Error Resume Next
    If Not menu Is Nothing Then menu.Delete
    On Error GoTo 0
End Sub

Public Sub ConnectExistingPathWithdrawal()
    Dim keys As Variant, uid As String
    On Error GoTo EH
    uid = CStr(Application.CommandBars.ActionControl.Tag)
    keys = mPanelSelected.Keys
    mPanelPathID = RegisterAnalysisPath(mPanelPathLinks, mPanelPathID, CStr(keys(0)), uid)
    OpenPanelRelation mPanelPathID
    Exit Sub
EH:
    AnalysisPanelMessage Err.Description
End Sub

Public Sub ShowPanelSource()
    Dim keys As Variant, text As String
    If mPanelSelected Is Nothing Then Exit Sub
    If mPanelSelected.Count <> 1 Then Exit Sub
    keys = mPanelSelected.Keys: text = AnalysisSourceText(CStr(keys(0)))
    If Len(text) = 0 Then text = "����͂܂��͋��ł���̖��ׂł��B��荞�݌��̋L�^�͂���܂���B"
    MsgBox text, vbInformation, "��荞�݌�"
End Sub

Public Sub ShowAdoptedPeople()
    ShowAdoptedAggregate False
End Sub

Public Sub ShowAdoptedFlows()
    ShowAdoptedAggregate True
End Sub

Private Sub ShowAdoptedAggregate(ByVal flows As Boolean)
    PauseAnalysisSearch: InitializePanelState
    Set mPanelScope = AnalysisVisibleIDs(): mPanelScopeKey = "!"
    Set mPanelItems = AdoptedAnalysisAggregates(mPanelScope, flows)
    mPanelMode = "aggregate": mPanelAggregate = IIf(flows, "�֘A���Ƃ̗̍p�z", "�l���̗̍p�z")
    mPanelPage = 0: mPanelChoice = 0: mPanelAmounts = False: mPanelRelation = "": mPanelDetailIDs = "": mPanelResultNote = ""
    mPanelPathFrom = "": mPanelPathID = "": mPanelPathLinks = ""
    mPanelNotice = "���z�E���ԏ����ɖ�������֘A�͏W�v�ΏۊO�B�����s���͊܂݂܂��B�w��z�͉����܂ŗ\�񂵁A�L�^�E������ێ����܂��B����͌����׊z�ł��B"
    RenderAnalysisPanel
End Sub

Public Sub ShowPanelPathConnections()
    Dim data As Variant, edge As Object
    If Len(mPanelPathID) = 0 Then Exit Sub
    On Error GoTo EH
    PauseAnalysisSearch: FlushPendingAnalysisEdits
    data = ReadAnalysisRelations()
    Set mPanelItems = AnalysisPathEdges(mPanelPathID, data)
    For Each edge In mPanelItems: edge("ids") = CStr(edge("from")) & "|" & CStr(edge("to")): Next edge
    mPanelMode = "connections": mPanelPage = 0: mPanelChoice = 0: mPanelAmounts = False
    mPanelRelation = "": mPanelDetailIDs = "": mPanelResultNote = ""
    mPanelNotice = AnalysisNetworkSummary(mPanelPathID, data)
    RenderAnalysisPanel
    Exit Sub
EH:
    AnalysisPanelMessage Err.Description
End Sub

Public Sub ShowRelationPairEditor()
    Dim details As Object
    On Error GoTo EH
    If Len(mPanelRelation) = 0 Then Exit Sub
    PauseAnalysisSearch: FlushPendingAnalysisEdits
    Set details = RelationDetails(mPanelRelation)
    If details("kind") <> "G" Then Exit Sub
    Set mPanelItems = RelationPairRows(mPanelRelation, True)
    Set mPanelSelected = CreateObject("Scripting.Dictionary")
    mPanelMode = "pairs": mPanelAmounts = False: mPanelPage = 0: mPanelChoice = 0
    mPanelNotice = "�ʔz���̍��v���̗p���܂��B�����������Ɖ����\��B���f�O�͓��͓r���ł��B" & CStr(details("status"))
    RenderAnalysisPanel
    Exit Sub
EH:
    AnalysisPanelMessage Err.Description
End Sub

Public Sub UsePreviousPanelAmounts()
    Dim mode As String
    On Error GoTo EH
    FlushPendingAnalysisEdits
    mode = "T": If mPanelMode = "pairs" Then mode = "F"
    RebaseAnalysisAmountDraft mPanelRelation, mode
    RenderAnalysisPanel
    Exit Sub
EH:
    AnalysisPanelMessage Err.Description
End Sub


Public Sub RefreshCurrentAnalysisScope(Optional ByVal force As Boolean = False)
    Dim current As Object, uid As Variant, changed As Boolean, started As Boolean, nextItems As Collection, message As String
    If mRefreshingScope Or Not mPanelOpen Or mPanelMode <> "aggregate" Then Exit Sub
    If ToolAppScopeActive() And Not force Then Exit Sub
    If Not ActiveWorkbook Is ThisWorkbook And Not force Then Exit Sub
    On Error GoTo EH
    mRefreshingScope = True
    Set current = AnalysisVisibleIDs()
    changed = (mScopeGeneration <> AnalysisDataGeneration())
    If mPanelScope Is Nothing Then
        changed = True
    ElseIf current.Count <> mPanelScope.Count Then
        changed = True
    Else
        For Each uid In current.Keys
            If Not mPanelScope.Exists(CStr(uid)) Then changed = True: Exit For
        Next uid
    End If
    If Not changed Then GoTo Done
    AppBegin "", False: started = True
    If mPanelAggregate = "�֘A���Ƃ̗̍p�z" Then
        Set nextItems = AdoptedAnalysisAggregates(current, True)
    ElseIf mPanelAggregate = "�l���̗̍p�z" Then
        Set nextItems = AdoptedAnalysisAggregates(current, False)
    Else
        Set nextItems = AnalysisAggregates(mPanelAggregate, current)
    End If
    Set mPanelScope = current: Set mPanelItems = nextItems: mPanelScopeKey = "!": mScopeGeneration = AnalysisDataGeneration()
    mPanelChoice = 0: mPanelPage = Application.Min(mPanelPage, Application.Max(0, (mPanelItems.Count - 1) \ PanelPageSize()))
    RenderAnalysisPanel
Done:
    EndAppScope started: mRefreshingScope = False
    Exit Sub
EH:
    message = Err.Description
    EndAppScope started: mRefreshingScope = False: mScopeGeneration = -1
    If force Then Err.Raise vbObjectError + 3460, "RefreshCurrentAnalysisScope", "���ݔ͈͂̏W�v���X�V�ł��܂���ł����B" & message
    AnalysisPanelMessage "�W�v�̍X�V���������ł��B�W�v���J�������Ă��������B" & message
End Sub

Private Function CandidateSideCaption(ByVal ids As Object, ByVal side As String) As String
    Dim uid As Variant, count As Long, first As String, people As Object
    Set people = CreateObject("Scripting.Dictionary")
    For Each uid In ids.Keys
        If AnalysisSide(CStr(uid)) = side Then
            count = count + 1
            If Len(first) = 0 Then first = CStr(uid)
            people(CellText(AnalysisValue(CStr(uid), 3))) = True
        End If
    Next uid
    If Len(first) = 0 Then Exit Function
    CandidateSideCaption = CompactAnalysisAccount(first)
    If count > 1 Then CandidateSideCaption = CandidateSideCaption & " �ق�" & count - 1 & "��"
End Function


Private Function PanelCandidateIsStale() As Boolean
    Dim candidate As Object
    If mPanelMode = "candidates" Then
        If mPanelItems Is Nothing Then Exit Function
        If mPanelItems.Count = 0 Then Exit Function
        '���ꗗ�͈�̌������ʂ��ꊇ�œ���ւ��邽�߁A������������B
        Set candidate = mPanelItems(1)
    ElseIf mPanelMode = "detail" Then
        Set candidate = mPanelDetailCandidate
    End If
    If Not candidate Is Nothing Then PanelCandidateIsStale = Not AnalysisCandidateIsCurrent(candidate)
End Function

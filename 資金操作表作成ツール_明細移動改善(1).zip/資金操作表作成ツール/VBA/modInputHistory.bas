Attribute VB_Name = "modInputHistory"
Option Explicit

'�����͓��͓��e�����B�ۑ������E�\���E�o�^�l�E���͂̋L�^�͊����߂��Ȃ��B
Private Const HISTORY_STEPS As Long = 100
Private Const HISTORY_BUDGET As Double = 33554432#
Private Const HISTORY_BLOCK_ROWS As Long = 256
Private mPast As Collection
Private mFuture As Collection
Private mShadow As Object
Private mReferenceShadow As Object
Private mContext As String
Private mApplying As Boolean
Private mObserving As Boolean
Private mOwnCommands As Boolean
Private mUnavailable As Boolean
Private mCost As Double

Public Sub ResetInputHistory()
    ResetInputMoveAnchor
    Set mPast = New Collection: Set mFuture = New Collection
    Set mShadow = Nothing: Set mReferenceShadow = Nothing
    mContext = "": mCost = 0: mObserving = False
End Sub

Private Function HistoryContext() As String
    HistoryContext = CurrentEditAccountID() & "|" & CurrentDraftKey()
End Function

Public Sub AdoptInputHistoryDraftKey()
    '�V�K���͂��ꗗ�֑ޔ�����ID���t���Ă��A���������̓��͗�����ۂB
    If mShadow Is Nothing Then Exit Sub
    If Len(CurrentEditAccountID()) = 0 And mContext = "|" Then mContext = HistoryContext()
    AdoptInputMoveDraftKey
End Sub

Private Function HistoryOnInput() As Boolean
    If Not ActiveWorkbook Is ThisWorkbook Then Exit Function
    If Not TypeOf ActiveSheet Is Worksheet Then Exit Function
    HistoryOnInput = (ActiveSheet.Name = SH_INPUT)
End Function

Public Sub EnsureInputHistory()
    If mApplying Or mObserving Or ToolAppScopeActive() Then Exit Sub
    If Not HistoryOnInput() Then Exit Sub
    If Not mShadow Is Nothing Then
        If mContext = HistoryContext() Then
            If mReferenceShadow Is Nothing Then RefreshInputReferenceHistory
            Exit Sub
        End If
    End If
    On Error GoTo EH
    ResetInputHistory
    Set mShadow = ReadInputHistorySnapshot()
    mContext = HistoryContext()
    RefreshInputReferenceHistory
    Exit Sub
EH:
    HistoryUnavailable
End Sub

Public Function InputHistoryUndoText() As String
    Dim entry As Collection
    If mPast Is Nothing Then Exit Function
    If mPast.Count = 0 Then Exit Function
    Set entry = mPast(mPast.Count)
    InputHistoryUndoText = CStr(entry("caption")) & "�����ɖ߂�"
End Function

Public Function InputHistoryRedoText() As String
    Dim entry As Collection
    If mFuture Is Nothing Then Exit Function
    If mFuture.Count = 0 Then Exit Function
    Set entry = mFuture(mFuture.Count)
    InputHistoryRedoText = CStr(entry("caption")) & "����蒼��"
End Function

Public Sub ReleaseInputHistoryCommands()
    On Error Resume Next
    If mOwnCommands Then
        Application.OnRepeat "", ""
        Application.OnUndo "", ""
    End If
    mOwnCommands = False
    On Error GoTo 0
End Sub

Public Sub RefreshInputHistoryCommands()
    Dim undoText As String, redoText As String
    If mApplying Or mObserving Or ToolAppScopeActive() Then Exit Sub
    If Not HistoryOnInput() Then Exit Sub
    EnsureInputHistory
    If mShadow Is Nothing Then Exit Sub
    On Error Resume Next
    TrackInputMoveSelection Selection
    If Err.Number <> 0 Then Application.StatusBar = Err.Description
    On Error GoTo 0
    undoText = InputHistoryUndoText(): redoText = InputHistoryRedoText()
    On Error Resume Next
    mOwnCommands = True
    If Len(redoText) > 0 Then
        Application.OnRepeat redoText, MacroRef("RedoInputOperation")
    Else
        Application.OnRepeat "", ""
    End If
    If Len(undoText) > 0 Then
        Application.OnUndo undoText, MacroRef("UndoInputOperation")
    Else
        Application.OnUndo "", ""
    End If
    On Error GoTo 0
End Sub

Public Sub BeginInputHistoryChange()
    If mApplying Then Exit Sub
    'Change�͕ҏW��ɔ��΂���B�����ŕҏW�O�̏�Ԃ�ǂݒ����Ă͂����Ȃ��B
    mObserving = True
End Sub

Public Function IsInputHistoryTarget(ByVal target As Range) As Boolean
    Dim ws As Worksheet
    If target Is Nothing Then Exit Function
    Set ws = target.Worksheet
    IsInputHistoryTarget = Not Intersect(target, Union(ws.Range("B5:K6,B10:K10"), InputEntryRange())) Is Nothing
End Function

Public Sub EndInputHistoryChange(ByVal target As Range, Optional ByVal movedInput As Boolean = False, Optional ByVal undoAddress As String = "", Optional ByVal redoAddress As String = "")
    Dim after As Object, before As Object, key As Variant, caption As String, entry As Collection
    If mApplying Or Not mObserving Then Exit Sub
    On Error GoTo EH
    mObserving = False
    If mShadow Is Nothing Then GoTo MissingBefore
    If mContext <> HistoryContext() Then GoTo MissingBefore
    If movedInput Then
        Set after = ReadInputHistorySnapshot()
        '�ړ����������ŋ�ɂȂ��Ă��A���̃Z����ID�𗚗����痎�Ƃ��Ȃ��B
        For Each key In mShadow.Keys
            If Not after.Exists(CStr(key)) Then after(CStr(key)) = Array(Empty, "")
        Next key
    Else
        Set after = ReadChangedHistoryCells(target)
    End If
    Set before = CreateObject("Scripting.Dictionary")
    For Each key In after.Keys: before(CStr(key)) = HistoryToken(mShadow, CStr(key)): Next key
    If movedInput Then MergeNativeReferenceHistory before, after
    caption = "���͂̕ύX"
    If target.Cells.CountLarge > 1 Then caption = "�͈͂̓���"
    If movedInput Then caption = "���ׂ̈ړ�"
    Set entry = HistoryEntry(before, after, caption, target.Cells(1, 1).Address(False, False), undoAddress, redoAddress)
    For Each key In after.Keys
        If Left$(CStr(key), 2) = "E|" Or Left$(CStr(key), 2) = "D|" Then
            If Not mReferenceShadow Is Nothing Then mReferenceShadow(CStr(key)) = after(key)
        Else
            mShadow(CStr(key)) = after(key)
        End If
    Next key
    AddHistoryEntry entry
    Exit Sub
MissingBefore:
    HistoryUnavailable
    Exit Sub
EH:
    HistoryUnavailable
End Sub

Public Sub KeepInputHistory(ByVal state As Collection, ByVal caption As String, ByVal addressText As String)
    Dim before As Object, after As Object, entry As Collection
    On Error GoTo EH
    Set before = state("history")
    Set after = ReadInputHistorySnapshot()
    If mPast Is Nothing Then ResetInputHistory
    If Not mShadow Is Nothing Then
        If mContext <> HistoryContext() Then ResetInputHistory
    End If
    AddOperationHistoryState state, before, after
    Set entry = HistoryEntry(before, after, caption, addressText)
    Set mShadow = ReadInputHistorySnapshot(): mContext = HistoryContext()
    RefreshInputReferenceHistory
    AddHistoryEntry entry
    Exit Sub
EH:
    HistoryUnavailable
End Sub

Private Sub AddHistoryEntry(ByVal entry As Collection)
    Dim old As Collection
    If entry Is Nothing Then Exit Sub
    If mPast Is Nothing Then Set mPast = New Collection
    If Not mFuture Is Nothing Then
        For Each old In mFuture: mCost = mCost - CDbl(old("cost")): Next old
    End If
    Set mFuture = New Collection
    mPast.Add entry: mCost = mCost + CDbl(entry("cost"))
    '�傫�Ȉꊇ�\�t���ł����O�̑���͎c���B�Â���������������B
    Do While mPast.Count > 1
        If mPast.Count <= HISTORY_STEPS And mCost <= HISTORY_BUDGET Then Exit Do
        Set old = mPast(1): mCost = mCost - CDbl(old("cost"))
        mPast.Remove 1
    Loop
End Sub

Private Function HistoryEntry(ByVal before As Object, ByVal after As Object, ByVal caption As String, ByVal addressText As String, Optional ByVal undoAddress As String = "", Optional ByVal redoAddress As String = "") As Collection
    Dim keys As Object, key As Variant, a As Variant, b As Variant, changes As New Collection, entry As New Collection
    Dim cost As Double
    Set keys = CreateObject("Scripting.Dictionary")
    For Each key In before.Keys: keys(CStr(key)) = True: Next key
    For Each key In after.Keys: keys(CStr(key)) = True: Next key
    For Each key In keys.Keys
        a = HistoryToken(before, CStr(key)): b = HistoryToken(after, CStr(key))
        If Not HistoryTokensEqual(a, b) Then
            If Left$(CStr(key), 2) = "C|" Then
                If Len(InputTokenKind(a)) > 0 Or Len(InputTokenKind(b)) > 0 Then Err.Raise vbObjectError + 3415, , "�z�񐔎���ύX��������̎������͕ێ��ł��܂���B"
            End If
            changes.Add Array(CStr(key), a, b)
            cost = cost + 512 + 2# * (Len(CStr(key)) + HistoryTokenLength(a) + HistoryTokenLength(b))
        End If
    Next key
    If changes.Count = 0 Then Exit Function
    entry.Add changes, "changes": entry.Add caption, "caption": entry.Add addressText, "address"
    entry.Add HistoryFocusKey(changes, addressText), "focus"
    If Len(undoAddress) = 0 Then undoAddress = addressText
    If Len(redoAddress) = 0 Then redoAddress = addressText
    entry.Add undoAddress, "undoAddress": entry.Add redoAddress, "redoAddress"
    entry.Add cost, "cost"
    Set HistoryEntry = entry
End Function

Private Function HistoryFocusKey(ByVal changes As Collection, ByVal addressText As String) As String
    Dim ws As Worksheet, cell As Range, change As Variant, key As String, balanceKey As String, memoChanged As Boolean
    Dim day As Variant, normalInput As Boolean
    Set ws = GetSheet(SH_INPUT): Set cell = ws.Range(addressText).Cells(1, 1)
    If cell.Row = BAL_VALUE_ROW Then
        If cell.Column >= BalanceMemoCol(ws) Then
            HistoryFocusKey = "M": Exit Function
        End If
        If TryStoredDate(ws.Cells(BAL_DATE_ROW, cell.Column).Value2, day) Then
            HistoryFocusKey = "B|" & CStr(CLng(CDate(day))): Exit Function
        End If
    End If
    For Each change In changes
        key = CStr(change(0))
        If Left$(key, 2) = "B|" And Len(balanceKey) = 0 Then balanceKey = key
        If key = "M" Then memoChanged = True
        If Left$(key, 2) = "C|" And Left$(key, 3) <> "C|X" Then normalInput = True
    Next change
    If Not normalInput And Len(balanceKey) > 0 Then
        HistoryFocusKey = balanceKey
    ElseIf Not normalInput And memoChanged Then
        HistoryFocusKey = "M"
    Else
        HistoryFocusKey = "C|" & addressText
    End If
End Function

Private Function HistoryTokenLength(ByVal token As Variant) As Double
    HistoryTokenLength = InputValueLength(token(0)) + Len(CStr(token(1)))
End Function

Private Function HistoryToken(ByVal data As Object, ByVal key As String) As Variant
    If data.Exists(key) Then HistoryToken = data(key) Else HistoryToken = Array(Empty, "")
End Function

Private Function HistoryTokensEqual(ByVal a As Variant, ByVal b As Variant) As Boolean
    HistoryTokensEqual = InputTokenEqual(a, b)
End Function

Private Function InputHistoryDerivedKey(ByVal key As String) As Boolean
    Select Case key
        Case "C|X2", "C|X5", "C|X6", "C|X8", "C|X9", "C|X10": InputHistoryDerivedKey = True
    End Select
End Function

Public Sub SyncInputHistoryDerivedState()
    Dim address As Variant, ws As Worksheet
    If mShadow Is Nothing Then Exit Sub
    If mContext <> HistoryContext() Then Exit Sub
    Set ws = GetSheet(SH_INPUT)
    For Each address In Array("X2", "X5", "X6", "X8", "X9", "X10")
        mShadow("C|" & CStr(address)) = InputCellToken(ws.Range(CStr(address)))
    Next address
End Sub

Private Function HistoryRollbackChanges(ByVal changes As Collection, ByVal current As Object) As Collection
    Dim result As New Collection, seen As Object, change As Variant, key As String, address As Variant, token As Variant
    Set seen = CreateObject("Scripting.Dictionary")
    For Each change In changes
        key = CStr(change(0)): token = HistoryToken(current, key)
        result.Add Array(key, token, token): seen(key) = True
    Next change
    For Each address In Array("X2", "X5", "X6", "X8", "X9", "X10")
        key = "C|" & CStr(address)
        If Not seen.Exists(key) Then
            token = InputCellToken(GetSheet(SH_INPUT).Range(CStr(address)))
            result.Add Array(key, token, token)
        End If
    Next address
    Set HistoryRollbackChanges = result
End Function

Public Function ReadInputHistorySnapshot() As Object
    Dim result As Object, ws As Worksheet, last As Long
    Set result = CreateObject("Scripting.Dictionary"): Set ws = GetSheet(SH_INPUT)
    ReadHistorySmallFields result, ws
    last = Application.Max(TX_FIRST_ROW, LastInputDataRow(), LastRow(ws, INPUT_UID_COL))
    ReadHistoryRange result, ws.Range(ws.Cells(TX_FIRST_ROW, COL_TX_YEAR), ws.Cells(last, INPUT_UID_COL))
    Set ReadInputHistorySnapshot = result
End Function

Private Function ReadChangedHistoryCells(ByVal target As Range) As Object
    Dim result As Object, part As Range, area As Range, ws As Worksheet, last As Long
    Set result = CreateObject("Scripting.Dictionary"): Set ws = GetSheet(SH_INPUT)
    '���t�̐��`�ɔ����c�����ύX�Ɖ��ߏ���������1����Ɋ܂߂�B
    ReadHistorySmallFields result, ws
    last = InputLastTransactionRow()
    For Each area In target.Areas
        If area.Row + area.Rows.Count - 1 > last Then last = Application.Max(last, LastInputDataRow())
    Next area
    Set part = Intersect(target, ws.Range("B" & TX_FIRST_ROW & ":L" & last))
    If Not part Is Nothing Then
        For Each area In part.Areas: ReadHistoryRange result, area, True: Next area
    End If
    Set ReadChangedHistoryCells = result
End Function

Private Sub ReadHistorySmallFields(ByVal result As Object, ByVal ws As Worksheet)
    Dim field As Variant, cell As Range, data As Variant, r As Long, c As Long, day As Variant, key As String
    For Each field In Array(CELL_BANK, CELL_BRANCH, CELL_PERSON, CELL_RELATIONSHIP, CELL_ACCOUNT_TYPE, CELL_ACCOUNT_NO, CELL_OPEN_DATE, CELL_CLOSE_DATE, "X2", "X5", "X6", "X8", "X9", "X10", "X22")
        Set cell = ws.Range(CStr(field)).Cells(1, 1)
        result("C|" & cell.Address(False, False)) = HistoryCellToken(cell)
    Next field
    data = ReadStore(GetSheet(SH_BAL_DRAFT), 3)
    For r = 2 To UBound(data, 1)
        If TryStoredDate(data(r, 1), day) Then result("B|" & CStr(CLng(CDate(day)))) = Array(data(r, 3), "")
    Next r
    result("M") = Array(ws.Range(CELL_BAL_MEMO).Value2, "")
    If CellText(ws.Range(CELL_BAL_RENDER).Value2) = "1" Then Exit Sub
    For c = BAL_FIRST_COL To BalanceMemoCol(ws) - 1
        If TryStoredDate(ws.Cells(BAL_DATE_ROW, c).Value2, day) Then
            key = "B|" & CStr(CLng(CDate(day)))
            result(key) = Array(ws.Cells(BAL_VALUE_ROW, c).Value2, "")
        End If
    Next c
    '�c���ƃ����͊����̃y�[�W�ۑ��Ɠ������l���L�^����B
    result("M") = Array(ws.Cells(BAL_VALUE_ROW, BalanceMemoCol(ws)).Value2, "")
End Sub

Private Function HistoryCellToken(ByVal cell As Range) As Variant
    HistoryCellToken = InputCellToken(cell)
End Function

Private Sub ReadHistoryRange(ByVal result As Object, ByVal source As Range, Optional ByVal includeEmpty As Boolean = False)
    Dim values As Variant, formulas As Variant, r As Long, c As Long, v As Variant, f As String
    Dim firstRow As Long, firstCol As Long, key As String
    If source.Cells.CountLarge = 1 Then
        result("C|" & source.Address(False, False)) = HistoryCellToken(source)
        Exit Sub
    End If
    values = source.Value2: formulas = source.Formula
    firstRow = source.Row: firstCol = source.Column
    For r = 1 To UBound(values, 1)
        For c = 1 To UBound(values, 2)
            v = values(r, c): f = ""
            If VarType(formulas(r, c)) = vbString Then
                If Left$(CStr(formulas(r, c)), 1) = "=" Then
                    If source.Cells(r, c).HasFormula Then f = CStr(formulas(r, c))
                End If
            End If
            key = "C|" & Chr$(64 + firstCol + c - 1) & CStr(firstRow + r - 1)
            If Len(f) > 0 Then
                result(key) = InputCellToken(source.Cells(r, c))
            ElseIf includeEmpty Or Not IsEmpty(v) Then
                result(key) = Array(v, "")
            End If
        Next c
    Next r
End Sub

Public Sub UndoInputHistory()
    MoveInputHistory False
End Sub

Public Sub RedoInputHistory()
    MoveInputHistory True
End Sub

Private Sub MoveInputHistory(ByVal forward As Boolean)
    Dim entry As Collection, changes As Collection, change As Variant, current As Object, expected As Variant
    Dim source As Collection, destination As Collection, side As Long, targetSide As Long
    Dim started As Boolean, writing As Boolean, moved As Boolean, message As String, restoreIssue As String
    Dim parkedBefore As Variant, parkedWriting As Boolean, destinationAdded As Boolean
    Dim rollback As Collection
    If Not HistoryOnInput() Or mApplying Or mObserving Then Exit Sub
    EnsureInputHistory
    If mShadow Is Nothing Then Exit Sub
    If forward Then Set source = mFuture: Set destination = mPast Else Set source = mPast: Set destination = mFuture
    If source Is Nothing Then Exit Sub
    If source.Count = 0 Then Exit Sub
    On Error GoTo EH
    Set entry = source(source.Count): Set changes = entry("changes")
    side = 2: targetSide = 1
    If forward Then side = 1: targetSide = 2
    Set current = ReadHistoryEntryCells(changes)
    For Each change In changes
        expected = change(side)
        If Not InputHistoryDerivedKey(CStr(change(0))) And Not HistoryTokensEqual(HistoryToken(current, CStr(change(0))), expected) Then
            ResetInputHistory
            SetInputStatus "�ʂ̑���œ��͂��ς�������߁A�ȑO�̎�������������؂�܂����B���݂̓��͕͂ێ����Ă��܂��B"
            RefreshInputHistoryCommands
            Exit Sub
        End If
    Next change
    Set rollback = HistoryRollbackChanges(changes, current)
    ResetInputMoveAnchor
    mApplying = True
    AppBegin IIf(forward, "���͂���蒼���Ă��܂�...", "���͂����ɖ߂��Ă��܂�..."), False: started = True
    writing = True
    ApplyHistoryChanges changes, targetSide
    GetSheet(SH_INPUT).Calculate
    ReconcileInputFormulaState
    If Not InputIsDirty And Len(CurrentDraftKey()) > 0 Then
        '�S�ҏW���������������ɁA�ޔ��ς݂̌Â��������c���Ȃ��B
        parkedBefore = ParkedDraftData(): parkedWriting = True
        RemoveParkedDraft CurrentDraftKey()
    End If
    UpdateInputHistoryShadow changes, targetSide
    SyncInputHistoryDerivedState
    destination.Add entry: destinationAdded = True
    source.Remove source.Count: moved = True
    writing = False
    RefreshAfterHistory entry, forward
    EndAppScope started
    mApplying = False
    RefreshInputHistoryCommands
    Exit Sub
EH:
    message = Err.Description
    On Error Resume Next
    If writing And Not moved Then
        Err.Clear
        ApplyHistoryChanges rollback, 1
        If Err.Number <> 0 Then restoreIssue = Err.Description: Err.Clear
        RefreshHistoryState
        If Err.Number <> 0 Then restoreIssue = restoreIssue & " " & Err.Description
        If parkedWriting Then
            Err.Clear
            WriteStore GetSheet(SH_PARKED_DRAFTS), parkedBefore
            If Err.Number <> 0 Then restoreIssue = restoreIssue & " " & Err.Description
        End If
        Err.Clear
        UpdateInputHistoryShadow rollback, 1
        SyncInputHistoryDerivedState
        If destinationAdded Then destination.Remove destination.Count
        If Err.Number <> 0 Then restoreIssue = restoreIssue & " " & Err.Description
    End If
    ProtectInputSheet
    EndAppScope started: mApplying = False
    If Len(restoreIssue) > 0 Then ResetInputHistory
    On Error GoTo 0
    If Len(restoreIssue) > 0 Then
        MsgBox "���͂̕����������ł��܂���ł����B�㏑���ۑ������A�ۑ��ς݂̃u�b�N����ĊJ���Ă��������B" & vbCrLf & message & vbCrLf & restoreIssue, vbExclamation
    ElseIf moved Then
        MsgBox "���͕͂ύX�ς݂ł����A�����̕\���X�V�������ł��܂���ł����B" & vbCrLf & message, vbExclamation
    Else
        MsgBox "�������E��蒼���������ł��܂���ł����B����O�̓��͕͂ێ����Ă��܂��B" & vbCrLf & message, vbExclamation
    End If
    RefreshInputHistoryCommands
End Sub

Private Function ReadHistoryEntryCells(ByVal changes As Collection) As Object
    Dim result As Object, small As Object, change As Variant, key As String, ws As Worksheet
    Dim blocks As Object, block As Variant, first As Long, last As Long, origins As Object
    Set result = CreateObject("Scripting.Dictionary"): Set small = CreateObject("Scripting.Dictionary")
    Set ws = GetSheet(SH_INPUT): ReadHistorySmallFields small, ws
    If changes.Count >= 128 Then
        Set blocks = HistoryTransactionBlocks(changes)
        For Each block In blocks.Keys
            first = CLng(block): last = Application.Min(ws.Rows.Count, first + HISTORY_BLOCK_ROWS - 1)
            ReadHistoryRange result, ws.Range(ws.Cells(first, COL_TX_YEAR), ws.Cells(last, INPUT_UID_COL)), True
        Next block
    End If
    For Each change In changes
        key = CStr(change(0))
        If Left$(key, 2) = "C|" Then
            If Not result.Exists(key) Then result(key) = HistoryCellToken(ws.Range(Mid$(key, 3)))
        ElseIf Left$(key, 2) = "E|" Then
            result(key) = InputCellToken(ReferenceHistoryCell(key))
        ElseIf Left$(key, 2) = "D|" Then
            result(key) = Array(ThisWorkbook.Names(Mid$(key, 3)).RefersTo, "")
        ElseIf Left$(key, 2) = "O|" Then
            If origins Is Nothing Then Set origins = ReadImportHistoryTokens()
            result(key) = HistoryToken(origins, key)
        Else
            result(key) = HistoryToken(small, key)
        End If
    Next change
    Set ReadHistoryEntryCells = result
End Function

Private Function HistoryTransactionRow(ByVal key As String) As Long
    Dim col As String, r As Long
    If Left$(key, 2) <> "C|" Then Exit Function
    col = Mid$(key, 3, 1)
    If col < "B" Or col > "L" Then Exit Function
    If Not IsNumeric(Mid$(key, 4)) Then Exit Function
    r = CLng(Mid$(key, 4))
    If r >= TX_FIRST_ROW Then HistoryTransactionRow = r
End Function

Private Function HistoryTransactionBlocks(ByVal changes As Collection) As Object
    Dim result As Object, change As Variant, r As Long, first As Long
    Set result = CreateObject("Scripting.Dictionary")
    For Each change In changes
        r = HistoryTransactionRow(CStr(change(0)))
        If r > 0 Then
            first = TX_FIRST_ROW + ((r - TX_FIRST_ROW) \ HISTORY_BLOCK_ROWS) * HISTORY_BLOCK_ROWS
            result(CStr(first)) = True
        End If
    Next change
    Set HistoryTransactionBlocks = result
End Function

Private Sub WriteHistoryTransactionBlocks(ByVal ws As Worksheet, ByVal changes As Collection, ByVal side As Long)
    Dim edits As Object, change As Variant, keys As Variant, i As Long, j As Long, row As Long, col As Long
    Dim first As Long, last As Long, values As Variant, key As String, token As Variant
    Set edits = CreateObject("Scripting.Dictionary")
    For Each change In changes
        If HistoryTransactionRow(CStr(change(0))) > 0 Then edits(CStr(change(0))) = change(side)
    Next change
    '�P��Z�����͌ʂɕ������A�萔�͘A�����铯���񂾂����܂Ƃ߂�B
    For Each change In changes
        key = CStr(change(0))
        If edits.Exists(key) Then
            row = HistoryTransactionRow(key): col = Asc(Mid$(key, 3, 1)) - 64
            token = edits(key)
            If Len(CStr(token(1))) > 0 Then
                WriteInputCellToken ws.Cells(row, col), token: edits.Remove key
            Else
                first = row: last = row
                Do While edits.Exists("C|" & Chr$(64 + col) & CStr(last + 1))
                    token = edits("C|" & Chr$(64 + col) & CStr(last + 1))
                    If Len(CStr(token(1))) > 0 Then Exit Do
                    last = last + 1
                Loop
                ReDim values(1 To last - first + 1, 1 To 1)
                For i = first To last
                    key = "C|" & Chr$(64 + col) & CStr(i): token = edits(key)
                    values(i - first + 1, 1) = token(0): edits.Remove key
                Next i
                WriteInputValueBlock ws.Cells(first, col).Resize(last - first + 1, 1), values
            End If
        End If
    Next change
End Sub

Private Function HistoryFormulaValue(ByVal token As Variant) As Variant
    If Len(CStr(token(1))) > 0 Then
        HistoryFormulaValue = CStr(token(1))
    ElseIf IsNull(token(0)) Or IsEmpty(token(0)) Then
        HistoryFormulaValue = Empty
    ElseIf VarType(token(0)) = vbString Then
        HistoryFormulaValue = "'" & CStr(token(0))
    Else
        HistoryFormulaValue = token(0)
    End If
End Function

Private Sub ApplyHistoryChanges(ByVal changes As Collection, ByVal side As Long)
    Dim ws As Worksheet, draft As Worksheet, change As Variant, key As String, token As Variant
    Dim hit As Variant, c As Long, day As Long, row As Long, needed As Long, bulk As Boolean
    Set ws = GetSheet(SH_INPUT): Set draft = GetSheet(SH_BAL_DRAFT)
    If InputHasGroupedFormulas() Then
        For Each change In changes
            key = CStr(change(0))
            If Left$(key, 2) = "C|" Then RequireIndependentInputCells ws.Range(Mid$(key, 3))
        Next change
    End If
    needed = InputLastTransactionRow()
    For Each change In changes
        key = CStr(change(0))
        needed = Application.Max(needed, HistoryTransactionRow(key))
    Next change
    EnsureTransactionCapacity needed - TX_FIRST_ROW + 1
    ws.Unprotect Password:=TOOL_PASSWORD
    bulk = (changes.Count >= 128)
    If bulk Then WriteHistoryTransactionBlocks ws, changes, side
    For Each change In changes
        key = CStr(change(0)): token = change(side)
        If Left$(key, 2) = "C|" Then
            If Not bulk Or HistoryTransactionRow(key) = 0 Then WriteHistoryCell ws.Range(Mid$(key, 3)), token
        ElseIf Left$(key, 2) = "E|" Then
            WriteInputCellToken ReferenceHistoryCell(key), token
        ElseIf Left$(key, 2) = "D|" Then
            ThisWorkbook.Names(Mid$(key, 3)).RefersTo = CStr(token(0))
        ElseIf key = "M" Then
            ws.Range(CELL_BAL_MEMO).Value2 = token(0)
            If CellText(ws.Range(CELL_BAL_RENDER).Value2) <> "1" Then WriteHistoryCell ws.Cells(BAL_VALUE_ROW, BalanceMemoCol(ws)), token
        ElseIf Left$(key, 2) = "B|" Then
            day = CLng(Mid$(key, 3))
            hit = Application.Match(CDbl(day), draft.Columns(1), 0)
            If IsError(hit) Then
                row = Application.Max(2, LastRow(draft) + 1)
                draft.Cells(row, 1).Value2 = day
                draft.Cells(row, 2).Value2 = Format$(CDate(day), "yyyy/m/d") & "���_�c��"
            Else
                row = CLng(hit)
            End If
            draft.Cells(row, 3).Value2 = token(0)
            If CellText(ws.Range(CELL_BAL_RENDER).Value2) <> "1" Then
                For c = BAL_FIRST_COL To BalanceMemoCol(ws) - 1
                    If IsNumeric(ws.Cells(BAL_DATE_ROW, c).Value2) Then
                        If CDbl(ws.Cells(BAL_DATE_ROW, c).Value2) = CDbl(day) Then WriteHistoryCell ws.Cells(BAL_VALUE_ROW, c), token
                    End If
                Next c
            End If
        End If
    Next change
    ApplyImportHistoryChanges changes, side
End Sub

Private Sub WriteHistoryCell(ByVal cell As Range, ByVal token As Variant)
    WriteInputCellToken cell, token
End Sub

Public Sub AddOperationHistoryState(ByVal state As Collection, ByVal before As Object, ByVal after As Object)
    Dim extra As Object, current As Object, key As Variant, origins As Variant
    On Error Resume Next
    Set extra = state("references")
    On Error GoTo 0
    If Not extra Is Nothing Then
        Set current = ReadWorkbookFormulaReferences()
        For Each key In extra.Keys
            before(key) = extra(key)
            If current.Exists(key) Then after(key) = current(key) Else after(key) = Array(Empty, "")
        Next key
    End If
    AddImportOperationHistory state, before, after
End Sub

Private Sub RefreshAfterHistory(ByVal entry As Collection, ByVal forward As Boolean)
    Dim ws As Worksheet, focus As String
    Set ws = GetSheet(SH_INPUT)
    RefreshHistoryState
    focus = CStr(entry("focus"))
    If Left$(focus, 2) = "B|" Then
        FocusBalanceDate CDate(CLng(Mid$(focus, 3)))
    ElseIf focus = "M" Then
        SafeSelectCell ws, ws.Cells(BAL_VALUE_ROW, BalanceMemoCol(ws)).Address
    Else
        If forward Then SafeSelectCell ws, CStr(entry("redoAddress")) Else SafeSelectCell ws, CStr(entry("undoAddress"))
    End If
    RememberInputPosition ActiveCell
    SetInputStatus CStr(entry("caption")) & IIf(forward, "�F��蒼���܂����B", "�F���ɖ߂��܂����B") & "�ۑ��́u�ۑ��v�ł��B"
End Sub

Private Sub RefreshHistoryState()
    Dim ws As Worksheet
    Set ws = GetSheet(SH_INPUT)
    ResetInputNavigation
    ResetInputFormulaTracking
    ApplyBalanceAvailability ws, True
    ProtectInputSheet
    UpdateInputStateLabel
    MarkFileNeedsSave
End Sub

Private Sub HistoryUnavailable()
    Dim previousEvents As Boolean
    If mUnavailable Then Exit Sub
    mUnavailable = True
    On Error Resume Next
    previousEvents = Application.EnableEvents
    Application.EnableEvents = False
    ResetInputHistory
    If HistoryOnInput() Then
        Set mShadow = ReadInputHistorySnapshot(): mContext = HistoryContext()
        SetInputStatus "���̑���̎��������L�^�ł��܂���ł����B���͓��e�͎c���Ă��܂��B"
    End If
    Application.EnableEvents = previousEvents
    mUnavailable = False
    On Error GoTo 0
End Sub

Public Function InputHistoryBeforeMove() As Object
    If mShadow Is Nothing Then Exit Function
    If mContext <> HistoryContext() Then Exit Function
    Set InputHistoryBeforeMove = mShadow
End Function

Public Function InputHistoryMoveToken(ByVal data As Object, ByVal key As String) As Variant
    InputHistoryMoveToken = HistoryToken(data, key)
End Function

Public Function InputHistoryMoveTokensEqual(ByVal a As Variant, ByVal b As Variant) As Boolean
    InputHistoryMoveTokensEqual = HistoryTokensEqual(a, b)
End Function

Public Function InputHistoryMoveRows(ByVal before As Object) As Variant
    Dim data() As Variant, key As Variant, last As Long, row As Long, c As Long, token As Variant
    last = TX_FIRST_ROW
    For Each key In before.Keys: last = Application.Max(last, HistoryTransactionRow(CStr(key))): Next key
    ReDim data(1 To last - TX_FIRST_ROW + 1, 1 To 11)
    For row = TX_FIRST_ROW To last
        For c = COL_TX_YEAR To INPUT_UID_COL
            token = HistoryToken(before, "C|" & Chr$(64 + c) & CStr(row))
            data(row - TX_FIRST_ROW + 1, c - COL_TX_YEAR + 1) = token(0)
        Next c
    Next row
    InputHistoryMoveRows = data
End Function

Public Sub ApplyInputMovePlan(ByVal plan As Object)
    Dim changes As New Collection, key As Variant, ws As Worksheet
    If plan.Count = 0 Then Exit Sub
    Set ws = GetSheet(SH_INPUT)
    For Each key In plan.Keys
        changes.Add Array(CStr(key), HistoryCellToken(ws.Range(Mid$(CStr(key), 3))), plan(key))
    Next key
    ApplyHistoryChanges changes, 2
    ProtectInputSheet
End Sub

Public Sub RestoreInputBeforeNativeMove()
    Dim after As Object, before As Object, entry As Collection, changes As Collection, key As Variant
    If mShadow Is Nothing Then Err.Raise vbObjectError + 2965, , "�ړ��O�̓��͂�����܂���B"
    If mContext <> HistoryContext() Then Err.Raise vbObjectError + 2966, , "�ړ��O�̌����ƌ��݂̌�������v���܂���B"
    Set after = ReadInputHistorySnapshot()
    Set before = CreateObject("Scripting.Dictionary")
    For Each key In mShadow.Keys: before(key) = mShadow(key): Next key
    MergeNativeReferenceHistory before, after
    Set entry = HistoryEntry(before, after, "���ׂ̈ړ�", "B15")
    If Not entry Is Nothing Then
        Set changes = entry("changes")
        ApplyHistoryChanges changes, 1
    End If
    RefreshHistoryState
End Sub



Public Sub RestoreInputCellChanges(ByVal changes As Collection)
    WriteHistoryTransactionBlocks GetSheet(SH_INPUT), changes, 2
End Sub


Public Sub InvalidateInputReferenceHistory()
    Set mReferenceShadow = Nothing
End Sub

Private Sub RefreshInputReferenceHistory()
    On Error GoTo Unavailable
    Set mReferenceShadow = ReadWorkbookFormulaReferences()
    Exit Sub
Unavailable:
    Set mReferenceShadow = Nothing
End Sub

Private Sub MergeNativeReferenceHistory(ByVal before As Object, ByVal after As Object)
    Dim current As Object, key As Variant
    If mReferenceShadow Is Nothing Then Err.Raise vbObjectError + 3416, , "�ړ��O�̎Q�Ɛ�����ێ��ł��܂���ł����B"
    Set current = ReadWorkbookFormulaReferences()
    For Each key In mReferenceShadow.Keys
        before(key) = mReferenceShadow(key)
        If current.Exists(key) Then after(key) = current(key) Else after(key) = Array(Empty, "")
    Next key
End Sub

Private Sub UpdateInputHistoryShadow(ByVal changes As Collection, ByVal side As Long)
    Dim change As Variant, key As String
    For Each change In changes
        key = CStr(change(0))
        If Left$(key, 2) = "E|" Or Left$(key, 2) = "D|" Then
            If Not mReferenceShadow Is Nothing Then mReferenceShadow(key) = change(side)
        ElseIf Left$(key, 2) <> "O|" Then
            mShadow(key) = change(side)
        End If
    Next change
End Sub

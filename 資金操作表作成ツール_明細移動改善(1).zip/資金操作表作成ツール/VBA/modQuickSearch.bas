Attribute VB_Name = "modQuickSearch"
Option Explicit

Private mDescriptionTarget As String
Private mDescriptionChoices As Collection
Private mDescriptionChoice As Long
Private mDescriptionRetry As Boolean

Public Function MatchesSearchText(ByVal text As String, ByVal query As String) As Boolean
    Dim terms As Variant, part As Variant
    query = Trim$(Replace(query, "�@", " "))
    terms = Split(query, " ")
    For Each part In terms
        If Len(CStr(part)) > 0 Then
            If InStr(1, text, CStr(part), vbTextCompare) = 0 Then Exit Function
        End If
    Next part
    MatchesSearchText = True
End Function

Public Sub FilterRegisteredAccounts()
    Dim ws As Worksheet, data As Variant, flags As Variant, query As String, text As String
    Dim r As Long, c As Long, n As Long, matches As Long, appStarted As Boolean, message As String
    On Error GoTo EH
    Set ws = GetSheet(SH_ACCOUNT_LIST)
    query = CellText(ws.Range("B3").Value2)
    n = LastRow(ws, 10)
    AppBegin
    appStarted = True
    ws.Unprotect Password:=TOOL_PASSWORD
    If ws.AutoFilterMode Then ws.AutoFilterMode = False
    If n >= 5 Then
        data = ws.Range("A5:K" & n).Value2
        ReDim flags(1 To UBound(data, 1), 1 To 1)
        For r = 1 To UBound(data, 1)
            text = ""
            For c = 1 To 9: text = text & " " & CellText(data(r, c)): Next c
            text = text & " " & CellText(data(r, 11))
            If MatchesSearchText(text, query) Then flags(r, 1) = "�\��": matches = matches + 1
        Next r
        ws.Range("L5").Resize(UBound(flags, 1), 1).Value2 = flags
        ws.Range("A4:L" & n).AutoFilter Field:=12, Criteria1:="�\��"
    End If
    ws.Range("E3").Value2 = matches & " / " & Application.Max(0, n - 4) & " ����"
    ws.Protect Password:=TOOL_PASSWORD, DrawingObjects:=True, UserInterfaceOnly:=True, AllowFiltering:=True
    ws.EnableSelection = xlNoRestrictions
    EndAppScope appStarted
    Exit Sub
EH:
    message = Err.Description
    On Error Resume Next
    ws.Protect Password:=TOOL_PASSWORD, DrawingObjects:=True, UserInterfaceOnly:=True, AllowFiltering:=True
    EndAppScope appStarted
    On Error GoTo 0
    MsgBox "�������i�荞�߂܂���ł����B" & vbCrLf & message, vbExclamation
End Sub

Public Sub SearchDescriptionHistory()
    Dim query As Variant, prior As String, data As Variant, menu As Object, item As Object
    Dim r As Long, total As Long, appStarted As Boolean, state As Collection, chosen As String
    Dim source As Worksheet, message As String, writing As Boolean
    On Error GoTo EH
    If Not ActiveWorkbook Is ThisWorkbook Then Exit Sub
    If ActiveSheet.Name <> SH_INPUT Then Exit Sub
    If ActiveCell.Row < TX_FIRST_ROW Or ActiveCell.Row > InputLastTransactionRow() Then
        MsgBox "�E�v�����閾�׍s��I��ł��������B", vbInformation
        Exit Sub
    End If
    Set source = GetSheet(SH_INPUT)
    mDescriptionTarget = source.Cells(ActiveCell.Row, COL_TX_TEKIYO).Address
    EnsureDescriptionHistory
    data = RankedDescriptionValues()
    Do
        query = Application.InputBox(Prompt:="�E�v�Ɋ܂܂�镶������͂��Ă��������B�󗓂Ȃ獡�̌����Ŏg�������A���̌�ɑS�̗̂�����\�����܂��B", _
                                     Title:="�E�v������", Default:=prior, Type:=2)
        If VarType(query) = vbBoolean Then Exit Sub
        prior = CStr(query)
        Set mDescriptionChoices = New Collection
        total = 0: mDescriptionChoice = 0: mDescriptionRetry = False
        Set menu = Application.CommandBars.Add(Position:=5, Temporary:=True)
        For r = 1 To UBound(data, 1)
            chosen = CellText(data(r, 1))
            If Len(chosen) > 0 Then
                If MatchesSearchText(chosen, prior) Then
                    total = total + 1
                    If mDescriptionChoices.Count < 20 Then
                        mDescriptionChoices.Add chosen
                        Set item = menu.Controls.Add(Type:=1, Temporary:=True)
                        item.Caption = Replace(Left$(Replace(Replace(chosen, vbCr, " "), vbLf, " "), 48), "&", "&&")
                        If Len(chosen) > 48 Then item.Caption = item.Caption & "..."
                        item.TooltipText = chosen
                        item.Tag = CStr(mDescriptionChoices.Count)
                        item.OnAction = MacroRef("ChooseDescriptionResult")
                    End If
                End If
            End If
        Next r
        Set item = menu.Controls.Add(Type:=1, Temporary:=True)
        item.Caption = IIf(total = 0, "�Y�������₪����܂���", CStr(total) & " ���� " & mDescriptionChoices.Count & " ����\��")
        item.Enabled = False: item.BeginGroup = True
        Set item = menu.Controls.Add(Type:=1, Temporary:=True)
        item.Caption = "�������镶����ς���...": item.Tag = "0": item.OnAction = MacroRef("ChooseDescriptionResult")
        menu.ShowPopup
        menu.Delete: Set menu = Nothing
        If mDescriptionChoice > 0 Then Exit Do
        If Not mDescriptionRetry Then Exit Sub
    Loop
    chosen = CStr(mDescriptionChoices(mDescriptionChoice))
    AppBegin
    appStarted = True
    Set state = CaptureInputState()
    writing = True
    source.Range(mDescriptionTarget).Value2 = chosen
    OnInputChange source.Range(mDescriptionTarget)
    SafeSelectCell source, mDescriptionTarget
    KeepInputUndo state, "�E�v�̑I��", mDescriptionTarget
    writing = False
    EndAppScope appStarted
    RefreshInputHistoryCommands
    Exit Sub
EH:
    message = Err.Description
    On Error Resume Next
    If Not menu Is Nothing Then menu.Delete
    If writing Then
        Err.Clear
        RestoreInputState state
        If Err.Number <> 0 Then message = message & vbCrLf & "���͉�ʂ̕������������ł��B�o�^�ς݃f�[�^�͕ύX���Ă��܂���B"
    End If
    EndAppScope appStarted
    On Error GoTo 0
    MsgBox "�E�v�������E���͂ł��܂���ł����B" & vbCrLf & message, vbExclamation
End Sub

Public Sub ChooseDescriptionResult()
    Dim control As Object, index As Long
    Set control = Application.CommandBars.ActionControl
    If control Is Nothing Then Exit Sub
    index = CLng(Val(control.Tag))
    If index = 0 Then
        mDescriptionRetry = True
    ElseIf Not mDescriptionChoices Is Nothing Then
        If index <= mDescriptionChoices.Count Then mDescriptionChoice = index
    End If
End Sub

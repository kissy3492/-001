Attribute VB_Name = "modRecoveryCopies"
Option Explicit

Private mRecoveryNeeded As Boolean
Private mRecoveryAt As Date
Private mRecoveryProcedure As String
Private mLastChange As Date
Private mRecovering As Boolean

Public Sub RecoveryChanged()
    If mRecovering Then Exit Sub
    mRecoveryNeeded = True: mLastChange = Now
    ResumeRecoverySchedule
End Sub

Public Sub ResumeRecoverySchedule()
    On Error GoTo Done
    If mRecovering Or Not mRecoveryNeeded Or mRecoveryAt <> 0 Then Exit Sub
    If ThisWorkbook.FileFormat <> 52 Or Len(ThisWorkbook.Path) = 0 Then Exit Sub
    mRecoveryAt = Now + TimeSerial(0, 5, 0)
    mRecoveryProcedure = MacroRef("SaveRecoveryCopy")
    Application.OnTime EarliestTime:=mRecoveryAt, Procedure:=mRecoveryProcedure, Schedule:=True
    Exit Sub
Done:
    mRecoveryAt = 0
End Sub

Public Sub StopRecoverySchedule()
    On Error Resume Next
    If mRecoveryAt <> 0 Then Application.OnTime EarliestTime:=mRecoveryAt, Procedure:=mRecoveryProcedure, Schedule:=False
    mRecoveryAt = 0: mRecoveryProcedure = ""
    On Error GoTo 0
End Sub

Public Sub NormalSaveCompleted()
    StopRecoverySchedule
    mRecoveryNeeded = False
End Sub

Public Sub SaveRecoveryCopy()
    Dim appStarted As Boolean, fs As Object, fileName As String, path As String, folder As String, message As String
    Dim buttonsChanged As Boolean, completed As Boolean, stage As String, buttonIssue As String
    Dim searchState As Collection
    mRecoveryAt = 0
    On Error GoTo EH
    If Not mRecoveryNeeded Or mRecovering Then Exit Sub
    If ToolSaveInProgress Or Not Application.Ready Or Application.CutCopyMode <> False Then GoTo Later
    If Not ActiveWorkbook Is ThisWorkbook Then GoTo Later
    If DateDiff("s", mLastChange, Now) < 3 Then GoTo Later
    If ThisWorkbook.FileFormat <> 52 Or Len(ThisWorkbook.Path) = 0 Then Exit Sub
    mRecovering = True
    Set fs = CreateObject("Scripting.FileSystemObject")
    folder = RecoveryFolderPath()
    fileName = "��_" & Format$(Now, "yyyymmdd_hhnnss") & ".xlsm"
    path = fs.BuildPath(folder, fileName)
    If fs.FileExists(path) Then GoTo Later
    AppBegin "�񕜗p�̍T����ۑ����Ă��܂�...", False
    appStarted = True
    Set searchState = SuspendAnalysisSearch()
    PrepareToolSave True, False
    buttonsChanged = True
    buttonIssue = RefreshSaveButtons(fileName)
    stage = fs.BuildPath(folder, "�쐬��_" & fileName)
    ThisWorkbook.SaveCopyAs Filename:=stage
    fs.MoveFile stage, path
    stage = ""
    completed = True
    buttonIssue = buttonIssue & RefreshSaveButtons()
    buttonsChanged = False
    mRecoveryNeeded = False
    EndAppScope appStarted
    mRecovering = False
    ResumeSuspendedAnalysisSearch searchState
    Application.StatusBar = "�񕜗p�̍T����ۑ����܂��� " & Format$(Now, "hh:mm") & "�@�^�@�ʏ�̕ۑ��́u�ۑ��v"
    If Len(buttonIssue) > 0 Then Application.StatusBar = "�񕜗p�̍T���͕ۑ��ς݂ł��B�{�^���X�V���������̂��߁A�ۑ�����J�������Ă��������B " & buttonIssue
    TrimRecoveryCopies folder, fileName
    RefreshInputHistoryCommands
    Exit Sub
Later:
    mRecovering = False
    ResumeRecoverySchedule
    Exit Sub
EH:
    message = Err.Description
    On Error Resume Next
    If Len(stage) > 0 And Not fs Is Nothing Then
        If fs.FileExists(stage) Then fs.DeleteFile stage, True
    End If
    If buttonsChanged Then RefreshButtonActions
    EndAppScope appStarted
    mRecovering = False
    If Not completed Then
        Application.StatusBar = "�񕜗p�̍T����ۑ��ł��܂���ł����B�u�ۑ��v�ŕۑ����Ă��������B " & message
    End If
    ResumeRecoverySchedule
    ResumeSuspendedAnalysisSearch searchState
    RefreshInputHistoryCommands
    On Error GoTo 0
End Sub

Public Function RecoveryFolderPath() As String
    Dim fs As Object, root As String, folder As String, identity As String, i As Long, code As Long, hash As Double
    Dim baseFolder As String, marker As String, stream As Object, owner As String, attempt As Long
    Set fs = CreateObject("Scripting.FileSystemObject")
    identity = LCase$(ThisWorkbook.FullName)
    For i = 1 To Len(identity)
        code = AscW(Mid$(identity, i, 1)): If code < 0 Then code = code + 65536
        hash = hash * 31 + code
        hash = hash - Fix(hash / 2147483647#) * 2147483647#
    Next i
    root = Environ$("LOCALAPPDATA")
    If Len(root) = 0 Then Err.Raise vbObjectError + 3360, , "�񕜗p�̕ۑ�����擾�ł��܂���B"
    root = fs.BuildPath(root, "��������\�쐬�c�[��")
    If Not fs.FolderExists(root) Then fs.CreateFolder root
    baseFolder = fs.BuildPath(root, "��_" & Hex$(CLng(hash)))
    folder = baseFolder
    Do
        If Not fs.FolderExists(folder) Then fs.CreateFolder folder
        marker = fs.BuildPath(folder, "���t�@�C��.txt")
        If Not fs.FileExists(marker) Then
            Set stream = fs.CreateTextFile(marker, False, True)
            stream.Write identity: stream.Close
            Exit Do
        End If
        Set stream = fs.OpenTextFile(marker, 1, False, -1)
        owner = stream.ReadAll: stream.Close
        If StrComp(owner, identity, vbTextCompare) = 0 Then Exit Do
        attempt = attempt + 1: folder = baseFolder & "_" & attempt
    Loop
    RecoveryFolderPath = folder
End Function

Private Sub TrimRecoveryCopies(ByVal folder As String, ByVal currentName As String)
    Dim fs As Object, files As Object, item As Object, names As New Collection, values As Variant
    Dim r As Long, c As Long, temp As String
    '�����쐬�����񕜃t�@�C��������3����c���B���s���Ă��ۑ��ς݂̍T�������s�����ɂ��Ȃ��B
    On Error GoTo Done
    Set fs = CreateObject("Scripting.FileSystemObject")
    Set files = fs.GetFolder(folder).Files
    For Each item In files
        If item.Name Like "��_########_######.xlsm" Then names.Add item.Name
    Next item
    If names.Count <= 3 Then Exit Sub
    ReDim values(1 To names.Count)
    For r = 1 To names.Count: values(r) = CStr(names(r)): Next r
    For r = 1 To UBound(values) - 1
        For c = r + 1 To UBound(values)
            If CStr(values(r)) < CStr(values(c)) Then temp = CStr(values(r)): values(r) = values(c): values(c) = temp
        Next c
    Next r
    For r = 4 To UBound(values)
        If CStr(values(r)) <> currentName Then fs.DeleteFile fs.BuildPath(folder, CStr(values(r))), True
    Next r
Done:
End Sub

Public Sub ShowRecoveryFolder()
    Dim folder As String
    On Error GoTo EH
    folder = RecoveryFolderPath()
    ThisWorkbook.FollowHyperlink Address:=folder
    Exit Sub
EH:
    MsgBox "�񕜗p�̕ۑ�����J���܂���ł����B" & vbCrLf & Err.Description, vbExclamation
End Sub

Attribute VB_Name = "modReportEditing"
Option Explicit

Private mReportUID As String
Private mReportKind As String
Private mReportDate As Variant
Private mReportAccount As String
Private mReportReturnPending As Boolean
Private mReportHadAnalysis As Boolean
Private mReportRelation As String

Public Function HasReportReturn() As Boolean
    HasReportReturn = mReportReturnPending
End Function

Public Sub EditReportTransaction(ByVal target As Range)
    Dim ws As Worksheet, ordinal As Long
    Set ws = target.Worksheet
    If ws.Name <> SH_OUTPUT_TX Or target.Row <= CashReportHeader(ws) Then Exit Sub
    mReportAccount = CellText(ws.Cells(target.Row, 18).Value2)
    If Len(mReportAccount) = 0 Then Exit Sub
    mReportUID = CellText(ws.Cells(target.Row, REPORT_UID_COL).Value2)
    mReportKind = CellText(ws.Cells(target.Row, 17).Value2)
    mReportDate = ws.Cells(target.Row, 6).Value2
    OpenReportCorrection
End Sub

Public Sub EditTransactionByID(ByVal uid As String)
    mReportAccount = CellText(AnalysisValue(uid, TX_ID_COL))
    If Len(mReportAccount) = 0 Then Exit Sub
    mReportUID = uid: mReportKind = "���": mReportDate = AnalysisValue(uid, 6)
    OpenReportCorrection
End Sub

Private Sub OpenReportCorrection()
    Dim started As Boolean, row As Long, message As String
    On Error GoTo EH
    mReportHadAnalysis = AnalysisPanelIsOpen(): mReportRelation = AnalysisPanelRelationID()
    mReportReturnPending = False
    AppBegin "���̖��ׂ��J���Ă��܂�...": started = True
    OpenAccountOrDraft mReportAccount
    If CurrentEditAccountID() <> mReportAccount Then GoTo Done
    mReportReturnPending = True
    If mReportKind = "���" Then
        row = FindInputTransaction(mReportUID)
        If row > 0 Then
            SetInputSections False, False
            SafeSelectCell GetSheet(SH_INPUT), "J" & row
        Else
            mReportReturnPending = False
            SetInputStatus "�����̉��������J���܂����B���̖��ׂ͉������ɂ���܂���B"
            GoTo Done
        End If
    ElseIf mReportKind = "�c��" Then
        FocusBalanceDate mReportDate
    Else
        SetInputSections True, False
        SafeSelectCell GetSheet(SH_INPUT), IIf(mReportKind = "���", CELL_CLOSE_DATE, CELL_OPEN_DATE)
    End If
    SetInputStatus "���[����������ł��B�u�����𔽉f�v�œ������ׂ֖߂�܂��B"
Done:
    EndAppScope started
    Exit Sub
EH:
    message = Err.Description
    mReportReturnPending = False
    EndAppScope started
    MsgBox "���̖��ׂ��J���܂���ł����B" & vbCrLf & message, vbExclamation
End Sub

Public Sub ReturnToSourceReport()
    Dim started As Boolean, ws As Worksheet, message As String, row As Long, r As Long, found As Boolean
    On Error GoTo EH
    If Not mReportReturnPending Then Exit Sub

    AppBegin "���[�֖߂��Ă��܂�...": started = True
    EnsureCurrentOutputs
    Set ws = GetSheet(SH_OUTPUT_TX): ws.Activate
    If Len(mReportUID) > 0 Then
        row = FindReportTransaction(mReportUID)
    Else
        For r = CashReportHeader(ws) + 1 To LastRow(ws, 6)
            If CellText(ws.Cells(r, 18).Value2) = mReportAccount And CellText(ws.Cells(r, 17).Value2) = mReportKind Then
                If mReportKind <> "�c��" Or CellText(ws.Cells(r, 6).Value2) = CellText(mReportDate) Then row = r: Exit For
            End If
        Next r
    End If
    If row > 0 Then found = Not ws.Rows(row).Hidden
    If found Then
        If mReportHadAnalysis Then RestoreAnalysisAfterCorrection mReportUID, mReportRelation
        ws.Cells(row, 12).Select
        ActiveWindow.ScrollRow = Application.Max(CashReportHeader(ws) + 1, row - 2)
    Else
        ws.Cells(CashReportHeader(ws), 1).Select
        If Len(mReportUID) > 0 Then ShowCorrectedAnalysisTransaction mReportUID
    End If
    FreezeCashReport ws
    mReportReturnPending = False: mReportUID = "": mReportAccount = "": mReportRelation = ""
    EndAppScope started
    Exit Sub
EH:
    message = Err.Description
    EndAppScope started
    MsgBox "���[�֖߂�܂���ł����B�����f�[�^�͕ێ����Ă��܂��B" & vbCrLf & message, vbExclamation
End Sub

Public Sub ReturnAfterReportCorrection(ByVal id As String)
    If id = mReportAccount And mReportReturnPending Then ReturnToSourceReport
End Sub

Attribute VB_Name = "modInputConvenience"
Option Explicit

Public Function RankedDescriptionValues() As Variant
    Dim recent As Variant, raw As Variant, output As Variant, seen As Object, r As Long, n As Long, phrase As String
    recent = DescriptionHistoryValues()
    raw = GetSheet(SH_INPUT).Range("J" & TX_FIRST_ROW & ":J" & Application.Max(TX_FIRST_ROW + 1, LastInputDataRow())).Value2
    ReDim output(1 To UBound(recent, 1) + UBound(raw, 1), 1 To 1)
    Set seen = CreateObject("Scripting.Dictionary"): seen.CompareMode = vbTextCompare
    '���̌����œ��͂�����𖖔������ɏo���A���̌�ɑS�����̗����𑱂���B
    For r = UBound(raw, 1) To 1 Step -1
        phrase = CellText(raw(r, 1))
        If Len(phrase) > 0 And phrase <> "����" Then
            If Not seen.Exists(phrase) Then n = n + 1: output(n, 1) = phrase: seen.Add phrase, True
        End If
    Next r
    For r = 1 To UBound(recent, 1)
        phrase = CellText(recent(r, 1))
        If Len(phrase) > 0 And phrase <> "����" Then
            If Not seen.Exists(phrase) Then n = n + 1: output(n, 1) = phrase: seen.Add phrase, True
        End If
    Next r
    RankedDescriptionValues = output
End Function

Public Sub ShowSelectedAmounts(ByVal target As Range)
    Dim area As Range, part As Range, rows As Range, raw As Variant, r As Long, count As Long, selectedCount As Long
    Dim outSum As Variant, inSum As Variant, value As Variant, ok As Boolean, invalid As Boolean, text As String
    Set rows = Intersect(target.EntireRow, InputTransactionRange())
    If rows Is Nothing Then Exit Sub
    outSum = CDec(0): inSum = CDec(0)
    For Each area In rows.Areas
        selectedCount = selectedCount + area.Rows.Count
        Set part = Intersect(area, GetSheet(SH_INPUT).Range("B15:K" & Application.Max(TX_FIRST_ROW, LastInputDataRow())))
        If Not part Is Nothing Then
            raw = part.Value2
            For r = 1 To UBound(raw, 1)
                If InputRowHasValues(raw, r) Then
                    count = count + 1
                    value = ParseMoney(raw(r, 5), False, ok)
                    If ok Then
                        If HasText(value) Then outSum = outSum + CDec(value)
                    Else
                        invalid = True
                    End If
                    value = ParseMoney(raw(r, 6), False, ok)
                    If ok Then
                        If HasText(value) Then inSum = inSum + CDec(value)
                    Else
                        invalid = True
                    End If
                End If
            Next r
        End If
    Next area
    text = "�I�� " & selectedCount & " �s�i���� " & count & " ���j�@�o�� " & Format$(outSum, "#,##0") & " �~�@�^�@���� " & Format$(inSum, "#,##0") & " �~"
    If invalid Then text = text & "�@�����l�łȂ����z�͏W�v�O"
    SetInputStatus text
End Sub

Public Function InputRowHasValues(ByVal data As Variant, ByVal rowNo As Long) As Boolean
    Dim c As Long
    For c = 1 To UBound(data, 2)
        If IsError(data(rowNo, c)) Or HasText(data(rowNo, c)) Then InputRowHasValues = True: Exit Function
    Next c
End Function

Public Function FillEmptyValues(ByVal data As Variant, ByVal value As String) As Variant
    Dim result As Variant, r As Long, c As Long
    result = data
    For r = 1 To UBound(result, 1)
        For c = 1 To UBound(result, 2)
            If Not IsError(result(r, c)) Then
                If Not HasText(result(r, c)) Then result(r, c) = value
            End If
        Next c
    Next r
    FillEmptyValues = result
End Function

Public Sub FillSelectedBlanks()
    Dim selected As Range, answer As Variant, state As Collection, cell As Range, edits As Object
    Dim appStarted As Boolean, writing As Boolean, message As String, restoreIssue As String
    On Error GoTo EH
    Set selected = TransactionSelection()
    If selected Is Nothing Then Exit Sub
    If selected.Columns.Count <> 1 Or selected.Column < COL_TX_SHOP Then
        MsgBox "�戵�X�E�@�ԁE�E�v�E���̑��̂����ꂩ1��ŁA���͂���s��I��ł��������B", vbInformation
        Exit Sub
    End If
    answer = Application.InputBox(Prompt:="�I�������͈͂̋󗓂����ɓ���镶������͂��Ă��������B���͍ς݂̒l�Ɛ����͕ێ����܂��B", Title:="�󗓂����ɓ���", Type:=2)
    If VarType(answer) = vbBoolean Then Exit Sub
    If Len(CStr(answer)) = 0 Then Exit Sub
    Set edits = CreateObject("Scripting.Dictionary")
    For Each cell In selected.Cells
        If InputBlankCanFill(InputCellToken(cell)) Then
            RequireIndependentInputCells cell
            edits("C|" & cell.Address(False, False)) = Array(CStr(answer), "")
        End If
    Next cell
    If edits.Count = 0 Then Exit Sub
    AppBegin
    appStarted = True
    Set state = CaptureInputState(False): writing = True
    '�󗓂̃Z�����������ʂ̗��������֓n���B�I��S�̂�l�ŏ����߂��Ȃ��B
    ApplyInputMovePlan edits
    OnInputChange selected
    KeepInputUndo state, "�󗓂ւ̓���", selected.Cells(1, 1).Address
    writing = False
    EndAppScope appStarted
    RefreshInputHistoryCommands
    Exit Sub
EH:
    message = Err.Description
    On Error Resume Next
    If writing Then
        Err.Clear
        RestoreInputState state
        If Err.Number <> 0 Then restoreIssue = vbCrLf & "���͗��̕������������ł��F" & Err.Description
    End If
    EndAppScope appStarted
    On Error GoTo 0
    MsgBox "�󗓂֓��͂ł��܂���ł����B" & vbCrLf & message & restoreIssue, vbExclamation
End Sub

Public Sub EditSourceBookmark()
    Dim answer As Variant, ws As Worksheet, appStarted As Boolean, before As Collection, writing As Boolean
    On Error GoTo EH
    Set ws = GetSheet(SH_INPUT)
    answer = Application.InputBox(Prompt:="�ǂ��܂œ��͂��������L�^���܂��B��F�ʒ�2���ځE12�y�[�W�܂ŁB���[�ɂ͏o�܂���B", _
                                  Title:="�����̂�����", Default:=CellText(ws.Range("X22").Value2), Type:=2)
    If VarType(answer) = vbBoolean Then Exit Sub
    AppBegin
    appStarted = True
    Set before = CaptureInputState()
    writing = True
    ws.Range("X22").Value2 = CStr(answer)
    MarkInputDirty ws.Range(CELL_BANK)
    SetInputStatus "�����̂�����F" & CStr(answer)
    KeepInputUndo before, "������̕ύX", CELL_BANK
    writing = False
    EndAppScope appStarted
    Exit Sub
EH:
    Dim message As String
    message = Err.Description
    On Error Resume Next
    If writing Then KeepInputUndo before, "������̕ύX", CELL_BANK
    EndAppScope appStarted
    On Error GoTo 0
    MsgBox "��������X�V�ł��܂���ł����B" & vbCrLf & message, vbExclamation
End Sub

Public Function StateBookmark(ByVal state As Collection) As String
    On Error Resume Next
    StateBookmark = CStr(state("bookmark"))
    On Error GoTo 0
End Function

Public Function BookmarkStore() As Worksheet
    Set BookmarkStore = EnsureHiddenStore("W_������", Array("����ID", "�����̂�����"))
End Function

Public Function EnsureHiddenStore(ByVal name As String, ByVal headers As Variant) As Worksheet
    Dim ws As Worksheet, prior As Object, appStarted As Boolean, message As String
    If SheetExists(name) Then Set EnsureHiddenStore = GetSheet(name): Exit Function
    On Error GoTo EH
    Set prior = ActiveSheet
    AppBegin
    appStarted = True
    Set ws = GetOrCreateSheet(name, False)
    SetRowValues ws.Range("A1"), headers
    ws.Range(ws.Columns(1), ws.Columns(UBound(headers) - LBound(headers) + 1)).NumberFormat = "@"
    prior.Activate
    ws.Visible = xlSheetVeryHidden
    Set EnsureHiddenStore = ws
    EndAppScope appStarted
    Exit Function
EH:
    message = Err.Description
    On Error Resume Next
    If Not prior Is Nothing Then prior.Activate
    EndAppScope appStarted
    On Error GoTo 0
    Err.Raise vbObjectError + 3340, "EnsureHiddenStore", message
End Function

Public Function RegisteredBookmark(ByVal id As String) As String
    Dim data As Variant, r As Long
    data = ReadStore(BookmarkStore(), 2)
    For r = 2 To UBound(data, 1)
        If CellText(data(r, 1)) = id Then RegisteredBookmark = CellText(data(r, 2)): Exit Function
    Next r
End Function

Public Function WithBookmark(ByVal oldData As Variant, ByVal id As String, ByVal bookmark As String) As Variant
    Dim row(1 To 1, 1 To 2) As Variant, n As Long
    If Len(bookmark) > 0 Then row(1, 1) = id: row(1, 2) = bookmark: n = 1
    WithBookmark = ReplaceAccountRows(oldData, row, n, 1, id)
End Function

Attribute VB_Name = "modAnalysisDrafts"
Option Explicit
Private Const SH_PENDING_ANALYSIS As String = "W_���͉�����"
Private mPending As Object
Private mDraftLoaded As Boolean
Private mCaptureBusy As Boolean
Private mDraftDirty As Boolean

Public Sub ResetAnalysisDraftCache()
    Set mPending = Nothing
    mDraftLoaded = False: mDraftDirty = False: mCaptureBusy = False
End Sub

Public Function SameEditValue(ByVal a As Variant, ByVal b As Variant) As Boolean
    If IsError(a) Or IsError(b) Then
        If IsError(a) And IsError(b) Then SameEditValue = (CStr(a) = CStr(b))
    Else
        SameEditValue = (CellText(a) = CellText(b))
    End If
End Function

Private Function AmountDraftMode(ByVal uid As String) As String
    If Len(uid) = 0 Then
        AmountDraftMode = "M"
    ElseIf InStr(uid, "~") > 0 Then
        AmountDraftMode = "F"
    Else
        AmountDraftMode = "T"
    End If
End Function

Public Function RelationAmountStamp(ByVal rid As String, ByVal data As Variant) As String
    Dim r As Long
    RelationAmountStamp = "0"
    For r = 2 To UBound(data, 1)
        If CellText(data(r, 1)) = rid And CellText(data(r, 2)) = "H" Then
            If HasText(data(r, 12)) Then RelationAmountStamp = CellText(data(r, 12))
            Exit Function
        End If
    Next r
End Function
Private Sub LoadPendingAnalysis()
    Dim data As Variant, raw As Variant, headers As Object, r As Long, rid As String, uid As String, mode As String, entry As Variant, key As String
    Dim migrate As Boolean, edited As Boolean
    If mDraftLoaded Then Exit Sub
    Set mPending = CreateObject("Scripting.Dictionary")
    raw = ReadStoredAnalysisRelations(): Set headers = RelationHeaders(raw)
    If SheetExists(SH_PENDING_ANALYSIS) Then
        data = ReadStore(GetSheet(SH_PENDING_ANALYSIS), 6)
        For r = 2 To UBound(data, 1)
            rid = CellText(data(r, 1)): uid = CellText(data(r, 2))
            If Len(rid) > 0 Then
                mode = CellText(data(r, 5))
                If Len(mode) = 0 Then mode = AmountDraftMode(uid): migrate = True
                key = rid & "|" & uid
                entry = Array(rid, uid, data(r, 3), CellText(data(r, 4)), mode, CellText(data(r, 6)))
                If mode <> "M" And Len(CStr(entry(3))) = 0 Then entry(3) = RelationAmountStamp(rid, raw)
                mPending(key) = entry
            End If
        Next r
    End If
    For r = 2 To UBound(raw, 1)
        rid = CellText(raw(r, 1)): uid = CellText(raw(r, 4)): mode = CellText(raw(r, 2))
        edited = False
        If mode = "T" Or mode = "F" Then
            edited = HasText(raw(r, 6)) Or IsError(raw(r, 6))
            If mode = "T" And headers.Exists(rid) Then
                If HasText(raw(CLng(headers(rid)), 6)) Then edited = True
            End If
            If mode = "F" Then uid = uid & "~" & CellText(raw(r, 11))
            key = rid & "|" & uid
            If edited And Not mPending.Exists(key) Then
                entry = Array(rid, uid, raw(r, 6), RelationAmountStamp(rid, raw), mode, "")
                If mode = "F" And Not HasAdoptedPairs(rid, raw) Then entry(5) = "�ȑO�̓���"
                mPending(key) = entry: migrate = True
            End If
        End If
    Next r
    mDraftLoaded = True
    If migrate Then StorePendingAnalysis
End Sub

Private Function HasAdoptedPairs(ByVal rid As String, ByVal data As Variant) As Boolean
    Dim r As Long
    For r = 2 To UBound(data, 1)
        If CellText(data(r, 1)) = rid And CellText(data(r, 2)) = "F" Then
            If HasText(data(r, 5)) Then HasAdoptedPairs = True: Exit Function
        End If
    Next r
End Function

Public Function AnalysisDraftData() As Variant
    Dim data As Variant, key As Variant, entry As Variant, r As Long, c As Long
    LoadPendingAnalysis
    ReDim data(1 To mPending.Count + 1, 1 To 6)
    data(1, 1) = "�֘AID": data(1, 2) = "�Ώ�": data(1, 3) = "�ҏW���̒l"
    data(1, 4) = "�J�n���̔z����": data(1, 5) = "����": data(1, 6) = "����"
    r = 1
    For Each key In mPending.Keys
        entry = mPending(key): r = r + 1
        For c = 0 To 5: data(r, c + 1) = entry(c): Next c
    Next key
    AnalysisDraftData = data
End Function

Private Sub StorePendingAnalysis()
    Dim ws As Worksheet, data As Variant, previous As Variant, message As String
    Dim started As Boolean
    On Error GoTo EH
    mDraftDirty = True
    data = AnalysisDraftData()
    AppBegin "", False: started = True
    Set ws = GetOrCreateSheet(SH_PENDING_ANALYSIS, False)
    previous = ReadStore(ws, 6)
    ws.Columns("A:F").NumberFormat = "@"
    WriteStore ws, data: ws.Visible = xlSheetVeryHidden
    mDraftDirty = False
    EndAppScope started
    Exit Sub
EH:
    message = Err.Description
    On Error Resume Next
    If IsArray(previous) Then
        Err.Clear: WriteStore ws, previous
        If Err.Number <> 0 Then message = message & vbCrLf & "���͉������̕������������ł��F" & Err.Description
    End If
    EndAppScope started
    On Error GoTo 0
    Err.Raise vbObjectError + 3420, "StorePendingAnalysis", message
End Sub

Public Sub RestoreAnalysisDraftData(ByVal data As Variant)
    Dim r As Long
    Set mPending = CreateObject("Scripting.Dictionary"): mDraftLoaded = True
    For r = 2 To UBound(data, 1)
        mPending(CellText(data(r, 1)) & "|" & CellText(data(r, 2))) = Array(data(r, 1), data(r, 2), data(r, 3), data(r, 4), data(r, 5), data(r, 6))
    Next r
    StorePendingAnalysis
End Sub

Public Sub PersistAnalysisEdit(ByVal relationID As String, ByVal uid As String, ByVal value As Variant)
    Dim key As String, entry As Variant, before As Variant, data As Variant
    LoadPendingAnalysis
    before = AnalysisDraftData(): key = relationID & "|" & uid
    If mPending.Exists(key) Then
        entry = mPending(key)
        If SameEditValue(entry(2), value) Then EnsureAnalysisDraftStored: Exit Sub
        entry(2) = value
    Else
        data = ReadStoredAnalysisRelations()
        entry = Array(relationID, uid, value, RelationAmountStamp(relationID, data), AmountDraftMode(uid), "")
    End If
    On Error GoTo EH
    mPending(key) = entry
    StorePendingAnalysis
    MarkFileNeedsSave
    Exit Sub
EH:
    Dim message As String
    message = Err.Description
    On Error Resume Next
    RestoreAnalysisDraftData before
    On Error GoTo 0
    Err.Raise vbObjectError + 3421, "PersistAnalysisEdit", "���͗��ɓ��e��ێ����Ă��܂��B" & message
End Sub

Public Function PendingAnalysisValue(ByVal relationID As String, ByVal uid As String, ByVal fallback As Variant) As Variant
    Dim entry As Variant
    LoadPendingAnalysis
    PendingAnalysisValue = fallback
    If mPending.Exists(relationID & "|" & uid) Then
        entry = mPending(relationID & "|" & uid): PendingAnalysisValue = entry(2)
    End If
End Function

Public Function HasAnalysisAmountEdits(ByVal rid As String, ByVal mode As String) As Boolean
    Dim key As Variant, entry As Variant
    LoadPendingAnalysis
    For Each key In mPending.Keys
        entry = mPending(key)
        If CStr(entry(0)) = rid And CStr(entry(4)) = mode Then HasAnalysisAmountEdits = True: Exit Function
    Next key
End Function

Public Function AnalysisAmountDraftIsStale(ByVal rid As String, ByVal mode As String) As Boolean
    Dim key As Variant, entry As Variant, stamp As String
    LoadPendingAnalysis: stamp = RelationAmountStamp(rid, ReadStoredAnalysisRelations())
    For Each key In mPending.Keys
        entry = mPending(key)
        If CStr(entry(0)) = rid And CStr(entry(4)) = mode Then
            If CStr(entry(3)) <> stamp Or Len(CStr(entry(5))) > 0 Then AnalysisAmountDraftIsStale = True: Exit Function
        End If
    Next key
End Function

Public Sub RebaseAnalysisAmountDraft(ByVal rid As String, ByVal mode As String)
    Dim key As Variant, entry As Variant, before As Variant, stamp As String, message As String
    LoadPendingAnalysis: before = AnalysisDraftData(): stamp = RelationAmountStamp(rid, ReadStoredAnalysisRelations())
    On Error GoTo EH
    For Each key In mPending.Keys
        entry = mPending(key)
        If CStr(entry(0)) = rid And CStr(entry(4)) = mode Then
            entry(3) = stamp: entry(5) = "": mPending(key) = entry
        End If
    Next key
    StorePendingAnalysis: MarkFileNeedsSave
    Exit Sub
EH:
    message = Err.Description
    On Error Resume Next
    RestoreAnalysisDraftData before
    On Error GoTo 0
    Err.Raise vbObjectError + 3422, , message
End Sub

Public Sub RemoveAnalysisDrafts(ByVal rid As String, Optional ByVal mode As String = "*")
    Dim keys As Variant, key As Variant, entry As Variant
    LoadPendingAnalysis: keys = mPending.Keys
    For Each key In keys
        entry = mPending(key)
        If CStr(entry(0)) = rid Then
            If mode = "*" Or CStr(entry(4)) = mode Then mPending.Remove CStr(key)
        End If
    Next key
    StorePendingAnalysis
End Sub

Public Sub RestoreRemovedAnalysisDrafts(ByVal rid As String, ByVal saved As Variant)
    Dim r As Long
    LoadPendingAnalysis
    For r = 2 To UBound(saved, 1)
        If CellText(saved(r, 1)) = rid Then
            mPending(rid & "|" & CellText(saved(r, 2))) = Array(saved(r, 1), saved(r, 2), saved(r, 3), saved(r, 4), saved(r, 5), saved(r, 6))
        End If
    Next r
    StorePendingAnalysis
End Sub

Public Function ProjectAnalysisDrafts(ByVal raw As Variant) As Variant
    Dim data As Variant, pending As Variant, headers As Object, index As Object, r As Long, c As Long, n As Long, rid As String, uid As String, key As String, mode As String
    Dim entry As Variant, pair As Variant, row As Long, stamp As String
    LoadPendingAnalysis: pending = AnalysisDraftData()
    ReDim data(1 To UBound(raw, 1) + UBound(pending, 1), 1 To 12)
    n = UBound(raw, 1): Set index = CreateObject("Scripting.Dictionary"): Set headers = RelationHeaders(raw)
    For r = 1 To n
        For c = 1 To 12: data(r, c) = raw(r, c): Next c
        mode = CellText(data(r, 2)): rid = CellText(data(r, 1))
        If mode = "T" Or mode = "F" Then
            uid = CellText(data(r, 4)): If mode = "F" Then uid = uid & "~" & CellText(data(r, 11))
            index(rid & "|" & uid) = r
            data(r, 6) = data(r, 5): data(r, 7) = Empty
        ElseIf mode = "H" Then
            data(r, 6) = Empty
        End If
    Next r
    For r = 2 To UBound(pending, 1)
        rid = CellText(pending(r, 1)): uid = CellText(pending(r, 2)): mode = CellText(pending(r, 5))
        If headers.Exists(rid) Then
            stamp = CellText(raw(CLng(headers(rid)), 12)): If Len(stamp) = 0 Then stamp = "0"
            If mode = "M" Then
                data(CLng(headers(rid)), 7) = pending(r, 3)
            Else
                key = rid & "|" & uid
                If mode = "F" And Not index.Exists(key) Then
                    pair = Split(uid, "~")
                    If UBound(pair) = 1 Then
                        n = n + 1: data(n, 1) = rid: data(n, 2) = "F": data(n, 4) = pair(0): data(n, 11) = pair(1): index(key) = n
                    End If
                End If
                If index.Exists(key) Then
                    row = CLng(index(key)): data(row, 6) = pending(r, 3)
                    data(row, 7) = "�ҏW��"
                    If Not HasText(pending(r, 3)) And Not IsError(pending(r, 3)) Then data(row, 7) = "�����\��"
                    If CellText(pending(r, 4)) <> stamp Or HasText(pending(r, 6)) Then data(row, 7) = "�ȑO�̓���"
                End If
            End If
        End If
    Next r
    ProjectAnalysisDrafts = FitStoreRows(data, n)
End Function

Public Function UnprojectAnalysisDrafts(ByVal data As Variant) As Variant
    Dim r As Long, c As Long, n As Long, result As Variant, mode As String, keep As Boolean
    ReDim result(1 To UBound(data, 1), 1 To UBound(data, 2))
    For r = 1 To UBound(data, 1)
        mode = CellText(data(r, 2)): keep = True
        If mode = "F" Then keep = HasText(data(r, 5)) Or IsError(data(r, 5))
        If keep Then
            n = n + 1
            For c = 1 To UBound(data, 2): result(n, c) = data(r, c): Next c
            Select Case mode
                Case "H": result(n, 6) = Empty
                Case "T", "F": result(n, 6) = Empty: result(n, 7) = Empty
            End Select
        End If
    Next r
    UnprojectAnalysisDrafts = FitStoreRows(result, n)
End Function
Public Sub ClearAnalysisBindings(ByVal ws As Worksheet)
    Dim protected As Boolean, message As String
    On Error GoTo EH
    protected = ws.ProtectContents
    If protected Then ws.Unprotect Password:=TOOL_PASSWORD
    ws.Range("N1:Q16").ClearContents
    If protected Then ProtectGeneratedOutput ws
    Exit Sub
EH:
    message = Err.Description
    On Error Resume Next
    If protected Then ProtectGeneratedOutput ws
    On Error GoTo 0
    Err.Raise vbObjectError + 3426, , message
End Sub
Public Sub BindAnalysisPanel(ByVal ws As Worksheet, ByVal rid As String, ByVal amounts As Boolean, ByVal rows As Object)
    Dim key As Variant, row As Long
    ClearAnalysisBindings ws
    If Len(rid) = 0 Then Exit Sub
    ws.Range("N1").Value2 = "�ҏW�Ή�"
    ws.Range("N16").Value2 = rid: ws.Range("O16").Value2 = "": ws.Range("P16").Value2 = ws.Range("B16").Value2
    If amounts Then
        For Each key In rows.Keys
            row = CLng(key)
            ws.Cells(row, 14).Value2 = rid: ws.Cells(row, 15).Value2 = rows(key): ws.Cells(row, 16).Value2 = ws.Cells(row, 12).Value2
        Next key
    End If
    ws.Columns("N:T").Hidden = True
End Sub

Public Sub CaptureAnalysisPanelInputs()
    Dim ws As Worksheet, row As Long, rid As String, uid As String, value As Variant, message As String, started As Boolean, protected As Boolean
    Dim data As Variant, changed As Object, key As Variant, entry As Variant, pendingKey As String
    If mCaptureBusy Then Exit Sub
    If Not SheetExists(SH_OUTPUT_TX) Then Exit Sub
    Set ws = GetSheet(SH_OUTPUT_TX)
    If CellText(ws.Range("N1").Value2) <> "�ҏW�Ή�" Then Exit Sub
    On Error GoTo EH
    mCaptureBusy = True
    LoadPendingAnalysis
    Set changed = CreateObject("Scripting.Dictionary")
    For row = 7 To 16
        rid = CellText(ws.Cells(row, 14).Value2)
        If Len(rid) > 0 Then
            If row = 16 Then value = ws.Range("B16").Value2 Else value = ws.Cells(row, 12).Value2
            If Not SameEditValue(value, ws.Cells(row, 16).Value2) Then changed(CStr(row)) = value
        End If
    Next row
    If changed.Count = 0 Then
        EnsureAnalysisDraftStored
        mCaptureBusy = False
        Exit Sub
    End If
    data = ReadStoredAnalysisRelations()
    AppBegin "", False: started = True
    protected = ws.ProtectContents
    If protected Then ws.Unprotect Password:=TOOL_PASSWORD
    For Each key In changed.Keys
        row = CLng(key): rid = CellText(ws.Cells(row, 14).Value2): uid = CellText(ws.Cells(row, 15).Value2)
        pendingKey = rid & "|" & uid
        If mPending.Exists(pendingKey) Then
            entry = mPending(pendingKey): entry(2) = changed(key)
        Else
            entry = Array(rid, uid, changed(key), RelationAmountStamp(rid, data), AmountDraftMode(uid), "")
        End If
        mPending(pendingKey) = entry
        mDraftDirty = True
    Next key
    '�S�y�[�W���̕ύX����x�ŕۑ��B�ۑ��ł���܂ŉ�ʑ��̓ǎ�ςݒl��i�߂Ȃ��B
    StorePendingAnalysis
    For Each key In changed.Keys: ws.Cells(CLng(key), 16).Value2 = changed(key): Next key
    MarkFileNeedsSave
    If protected Then ProtectGeneratedOutput ws
    EndAppScope started: mCaptureBusy = False
    Exit Sub
EH:
    message = Err.Description
    On Error Resume Next
    If protected Then ProtectGeneratedOutput ws
    EndAppScope started: mCaptureBusy = False
    On Error GoTo 0
    Err.Raise vbObjectError + 3423, , "�ҏW���e�͌��݂̓��͗��Ɏc���Ă��܂��B�ۑ����Ă���ēx���삵�Ă��������B" & message
End Sub

Public Sub PreserveAnalysisForSave()
    On Error GoTo Held
    CaptureAnalysisPanelInputs
    EnsureAnalysisDraftStored
    Exit Sub
Held:
    Application.StatusBar = "���͂̓��͗��ƑΏۂ��܂߂ĕۑ����܂��B�̗p�z�̔��f�͍s���܂���B"
End Sub

Public Sub ReplayAnalysisEdits()
    '�݊������B�\���E�ۑ����ɉ��������̗p�l�֍Ĕ��f���Ȃ��B
    CaptureAnalysisPanelInputs
End Sub


Public Sub EnsureAnalysisDraftStored()
    LoadPendingAnalysis
    If mDraftDirty Then StorePendingAnalysis
End Sub

Public Sub PreservePreviousPairAmounts(ByVal rid As String, ByVal data As Variant)
    Dim r As Long, uid As String, key As String
    LoadPendingAnalysis
    For r = 2 To UBound(data, 1)
        If CellText(data(r, 1)) = rid And CellText(data(r, 2)) = "F" Then
            If HasText(data(r, 5)) Then
                uid = CellText(data(r, 4)) & "~" & CellText(data(r, 11)): key = rid & "|" & uid
                If Not mPending.Exists(key) Then
                    mPending(key) = Array(rid, uid, data(r, 5), RelationAmountStamp(rid, data), "F", "�ȑO�̓���")
                End If
            End If
        End If
    Next r
    StorePendingAnalysis
End Sub

Public Sub ClearAllAnalysisDrafts()
    LoadPendingAnalysis
    mPending.RemoveAll
    StorePendingAnalysis
End Sub

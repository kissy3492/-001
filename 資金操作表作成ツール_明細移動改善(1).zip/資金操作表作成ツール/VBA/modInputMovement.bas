Attribute VB_Name = "modInputMovement"
Option Explicit

'���O��`��1�������BExcel���g���؂���E�h���b�O�ōX�V����Q�Ƃ��g���B
'�Z���̓��e�̈�v����ړ����𐄑����Ȃ��B���͒l�EID�̕ۑ���͏]���ǂ���B
Private Const MOVE_ANCHOR_NAME As String = "_ToolInputMoveAnchor"
Private mOriginAddress As String
Private mOriginContext As String
Private mAnchor As Name

Private Function MoveContext() As String
    MoveContext = CurrentEditAccountID() & "|" & CurrentDraftKey()
End Function

Public Sub ResetInputMoveAnchor()
    mOriginAddress = "": mOriginContext = ""
    Set mAnchor = Nothing
End Sub

Public Sub AdoptInputMoveDraftKey()
    If Len(CurrentEditAccountID()) = 0 And mOriginContext = "|" Then mOriginContext = MoveContext()
End Sub

Public Function InputMovePending() As Boolean
    Dim destination As Range
    If Len(mOriginAddress) = 0 Or mAnchor Is Nothing Then Exit Function
    If mOriginContext <> MoveContext() Then Exit Function
    On Error GoTo Done
    Set destination = mAnchor.RefersToRange
    If Not destination.Worksheet Is GetSheet(SH_INPUT) Then
        InputMovePending = True
    Else
        InputMovePending = (destination.Address(False, False) <> mOriginAddress)
    End If
Done:
End Function

Public Sub TrackInputMoveSelection(ByVal selected As Object)
    Dim target As Range, body As Range, addressText As String, reference As String, wasSaved As Boolean, issue As String
    If Not ActiveWorkbook Is ThisWorkbook Then Exit Sub
    If Not TypeOf selected Is Range Then Exit Sub
    If Application.CutCopyMode <> False Or InputMovePending() Then Exit Sub
    Set target = selected
    If Not target.Worksheet Is GetSheet(SH_INPUT) Then Exit Sub
    If target.Areas.Count <> 1 Then ResetInputMoveAnchor: Exit Sub
    Set body = Intersect(target, InputEntryRange())
    If body Is Nothing Then ResetInputMoveAnchor: Exit Sub
    If body.Cells.CountLarge <> target.Cells.CountLarge Then ResetInputMoveAnchor: Exit Sub
    addressText = target.Address(False, False)
    If addressText = mOriginAddress And mOriginContext = MoveContext() And Not mAnchor Is Nothing Then Exit Sub
    reference = "='" & Replace(target.Worksheet.Name, "'", "''") & "'!" & target.Address
    wasSaved = ThisWorkbook.Saved
    On Error GoTo EH
    Set mAnchor = ThisWorkbook.Names.Add(Name:=MOVE_ANCHOR_NAME, RefersTo:=reference, Visible:=False)
    mOriginAddress = addressText: mOriginContext = MoveContext()
    '�I���̒ǐՂ����ł́A�ۑ��ς݂̓��͂𖢕ۑ������ɂ��Ȃ��B
    If wasSaved Then ThisWorkbook.Saved = True
    Exit Sub
EH:
    issue = Err.Description
    ResetInputMoveAnchor
    Err.Raise vbObjectError + 2960, "TrackInputMoveSelection", "�ړ����̋L�����X�V�ł��܂���ł����B" & issue
End Sub

Public Function ReconcileNativeInputMove(ByVal target As Range, ByRef affected As Range, ByRef undoAddress As String, ByRef redoAddress As String) As Boolean
    Dim ws As Worksheet, source As Range, destination As Range, before As Object, plan As Object
    Dim previous As Variant, normalized As Variant, wholeRows As Boolean, internalMove As Boolean
    Dim last As Long, oldLast As Long, r As Long, fromRow As Long, toRow As Long
    Dim key As String, token As Variant, message As String, restored As String
    Set affected = target
    If Not InputMovePending() Then Exit Function
    On Error GoTo EH
    Set ws = GetSheet(SH_INPUT): Set source = ws.Range(mOriginAddress)
    Set destination = mAnchor.RefersToRange
    Set before = InputHistoryBeforeMove()
    If before Is Nothing Then Err.Raise vbObjectError + 2961, , "�ړ��O�̓��͂�ǂݏo���܂���ł����B"
    undoAddress = source.Cells(1, 1).Address(False, False): redoAddress = undoAddress
    internalMove = (destination.Worksheet Is ws)
    Set plan = CreateObject("Scripting.Dictionary")
    Set affected = Union(target, source)
    If internalMove Then
        redoAddress = destination.Cells(1, 1).Address(False, False)
        Set affected = Union(affected, destination)
        If source.Rows.Count <> destination.Rows.Count Or source.Columns.Count <> destination.Columns.Count Then
            Err.Raise vbObjectError + 2962, , "�ړ����ƈړ���͈̔͂�ǂݎ��܂���ł����B"
        End If
        last = source.Row + source.Rows.Count - 1
        previous = InputHistoryMoveRows(before)
        oldLast = TX_FIRST_ROW + UBound(previous, 1) - 1
        wholeRows = CompleteMovedRecords(source, destination, before, oldLast)
        If wholeRows And source.Row <> destination.Row Then
            '�d�Ȃ�ړ��ɂ��Ή��B��Ɉړ���ID����ɂ��A�ޔ�����ID���ړ���֊��蓖�Ă�B
            For r = source.Row To Application.Min(last, oldLast)
                key = "C|L" & CStr(r): token = InputHistoryMoveToken(before, key)
                If HasText(token(0)) Then plan(key) = Array(Empty, "")
            Next r
            For r = destination.Row To Application.Min(destination.Row + destination.Rows.Count - 1, oldLast)
                key = "C|L" & CStr(r): token = InputHistoryMoveToken(before, key)
                If HasText(token(0)) Then plan(key) = Array(Empty, "")
            Next r
            For r = source.Row To Application.Min(last, oldLast)
                token = InputHistoryMoveToken(before, "C|L" & CStr(r))
                If HasText(token(0)) Then plan("C|L" & CStr(destination.Row + r - source.Row)) = token
            Next r
            '�ړ������擪�ƁA���ʒu�E�㏑����̌㑱�s���ʂ̔N���E�E�v���p�����Ȃ��悤�ɂ���B
            normalized = previous
            PreserveFollowingContext normalized, source.Row - TX_FIRST_ROW + 1
            For r = source.Row To last
                fromRow = r - TX_FIRST_ROW + 1
                If fromRow > UBound(previous, 1) Then Exit For
                toRow = destination.Row + r - source.Row
                AddMovedContext plan, before, normalized, r, toRow
            Next r
            AddFollowingMoveContext plan, before, previous, source, destination, last + 1
            AddFollowingMoveContext plan, before, previous, source, destination, destination.Row + destination.Rows.Count
        End If
    End If
    '�ꕔ�̍��ڂ����̈ړ��ł͖���ID�͉^�΂Ȃ��B��ɂȂ����s�̌Â�ID�����������B
    AddEmptyRowIdentities plan, affected, wholeRows
    For Each token In plan.Keys
        Set affected = Union(affected, ws.Range(Mid$(CStr(token), 3)))
    Next token
    ApplyInputMovePlan plan
    ResetInputMoveAnchor
    ReconcileNativeInputMove = True
    Exit Function
EH:
    message = Err.Description
    On Error Resume Next
    Err.Clear
    RestoreInputBeforeNativeMove
    If Err.Number <> 0 Then restored = Err.Description
    ResetInputMoveAnchor
    On Error GoTo 0
    If Len(restored) = 0 Then
        Err.Raise vbObjectError + 2963, "ReconcileNativeInputMove", "���ׂ̈ړ��������ł��Ȃ��������߁A�ړ��O�̓��֖͂߂��܂����B" & vbCrLf & message
    Else
        Err.Raise vbObjectError + 2964, "ReconcileNativeInputMove", "���ׂ̈ړ��ƕ����������ł��܂���ł����B�ۑ��ς݂̃u�b�N�͕ێ����Ă��������B" & vbCrLf & message & vbCrLf & restored
    End If
End Function

Private Function CompleteMovedRecords(ByVal source As Range, ByVal destination As Range, ByVal before As Object, ByVal oldLast As Long) As Boolean
    Dim row As Long, lastColumn As Long, token As Variant
    If source.Column <> COL_TX_YEAR Or destination.Column <> COL_TX_YEAR Then Exit Function
    lastColumn = source.Column + source.Columns.Count - 1
    If lastColumn < COL_TX_TEKIYO Or lastColumn > COL_TX_OTHER Then Exit Function
    '���̑����I�΂Ȃ������ꍇ���A�����̂��̑�������Ȃ疾�בS�̂Ƃ��Ĉ����B
    If lastColumn < COL_TX_OTHER Then
        For row = source.Row To Application.Min(source.Row + source.Rows.Count - 1, oldLast)
            token = InputHistoryMoveToken(before, "C|K" & CStr(row))
            If Len(CStr(token(1))) > 0 Or IsError(token(0)) Or HasText(token(0)) Then Exit Function
        Next row
        For row = destination.Row To Application.Min(destination.Row + destination.Rows.Count - 1, oldLast)
            token = InputHistoryMoveToken(before, "C|K" & CStr(row))
            If Len(CStr(token(1))) > 0 Or IsError(token(0)) Or HasText(token(0)) Then Exit Function
        Next row
    End If
    CompleteMovedRecords = True
End Function

Private Sub AddMovedContext(ByVal plan As Object, ByVal before As Object, ByVal normalized As Variant, ByVal fromRow As Long, ByVal toRow As Long)
    Dim c As Variant, index As Long, oldToken As Variant, newToken As Variant
    index = fromRow - TX_FIRST_ROW + 1
    For Each c In Array(COL_TX_YEAR, COL_TX_MONTH, COL_TX_DAY, COL_TX_TEKIYO)
        oldToken = InputHistoryMoveToken(before, "C|" & Chr$(64 + CLng(c)) & CStr(fromRow))
        '������Excel���ړ���������ێ��B�ȗ����ꂽ���t�E���ゾ���𖾎�����B
        If Len(CStr(oldToken(1))) = 0 Then
            newToken = Array(normalized(index, CLng(c) - 1), "")
            If Not InputHistoryMoveTokensEqual(oldToken, newToken) Then
                plan("C|" & Chr$(64 + CLng(c)) & CStr(toRow)) = newToken
            End If
        End If
    Next c
End Sub

Private Sub AddFollowingMoveContext(ByVal plan As Object, ByVal before As Object, ByVal previous As Variant, ByVal source As Range, ByVal destination As Range, ByVal boundary As Long)
    Dim normalized As Variant, row As Long
    If boundary > TX_FIRST_ROW + UBound(previous, 1) - 1 Then Exit Sub
    normalized = previous
    PreserveFollowingContext normalized, boundary - TX_FIRST_ROW + 1
    For row = boundary To TX_FIRST_ROW + UBound(previous, 1) - 1
        If Not (row >= source.Row And row < source.Row + source.Rows.Count) And _
           Not (row >= destination.Row And row < destination.Row + destination.Rows.Count) Then
            AddMovedContext plan, before, normalized, row, row
        End If
    Next row
End Sub

Private Sub AddEmptyRowIdentities(ByVal plan As Object, ByVal affected As Range, ByVal preservePlanned As Boolean)
    Dim body As Range, area As Range, data As Variant, r As Long, c As Long, populated As Boolean
    Dim ws As Worksheet, first As Long, last As Long, lastID As Long, key As String
    Set ws = GetSheet(SH_INPUT): lastID = LastRow(ws, INPUT_UID_COL)
    If lastID < TX_FIRST_ROW Then Exit Sub
    Set body = Intersect(affected, ws.Range("B" & TX_FIRST_ROW & ":K" & lastID))
    If body Is Nothing Then Exit Sub
    For Each area In body.Areas
        first = area.Row: last = area.Row + area.Rows.Count - 1
        data = ws.Cells(first, COL_TX_YEAR).Resize(last - first + 1, 11).Formula
        For r = 1 To UBound(data, 1)
            key = "C|L" & CStr(first + r - 1)
            If Not (preservePlanned And plan.Exists(key)) Then
                If HasText(data(r, 11)) Then
                    populated = False
                    For c = 1 To 10
                        If IsError(data(r, c)) Or HasText(data(r, c)) Then populated = True: Exit For
                    Next c
                    If Not populated Then plan(key) = Array(Empty, "")
                End If
            End If
        Next r
    Next area
End Sub

Public Sub ReconcileNativeInputIdentities(ByVal target As Range, ByRef affected As Range)
    Dim plan As Object, key As Variant, message As String, restored As String
    On Error GoTo EH
    Set plan = CreateObject("Scripting.Dictionary")
    '�ʏ���́E�\��t���͊����s�̒����B�R�s�[����ID�𕡐����Ȃ��B
    '��ɂȂ����s�͈ȑO�̖��ׂƂ̑Ή����O���A���̌�̓��͂ɌÂ�ID�𗬗p���Ȃ��B
    AddEmptyRowIdentities plan, target, True
    If plan.Count = 0 Then Exit Sub
    For Each key In plan.Keys: Set affected = Union(affected, target.Worksheet.Range(Mid$(CStr(key), 3))): Next key
    ApplyInputMovePlan plan
    Exit Sub
EH:
    message = Err.Description
    On Error Resume Next
    Err.Clear
    RestoreInputBeforeNativeMove
    If Err.Number <> 0 Then restored = Err.Description
    ResetInputMoveAnchor
    On Error GoTo 0
    Err.Raise vbObjectError + 2967, "ReconcileNativeInputIdentities", "���͂Ɩ��ׂ̑Ή����X�V�ł��܂���ł����B" & vbCrLf & message & vbCrLf & restored
End Sub

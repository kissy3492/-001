Attribute VB_Name = "modInputRaw"
Option Explicit

Public Const SH_INPUT_RAW As String = "W_������"
Public Const INPUT_RAW_COLS As Long = 9
Private mFormulaSeen As Object
Private mFormulaContext As String
Private mCheckingFormula As Boolean

Public Function InputRawStore() As Worksheet
    Set InputRawStore = EnsureHiddenStore(SH_INPUT_RAW, Array("����ID", "����ID", "����", "���", "���l", "��", "���`��", "���Ύ�", "���f���̒l"))
End Function

Public Function ReadInputRawData() As Variant
    Dim data(1 To 1, 1 To INPUT_RAW_COLS) As Variant
    If SheetExists(SH_INPUT_RAW) Then
        ReadInputRawData = ReadStore(GetSheet(SH_INPUT_RAW), INPUT_RAW_COLS)
    Else
        ReadInputRawData = data
    End If
End Function

Public Function BuildAccountInputRaw(ByVal original As Variant, ByVal owner As String, ByVal state As Collection, ByVal registered As Variant) As Variant
    Dim formulas As Object, key As Variant, token As Variant, tx As Variant, block As Variant, registeredRows As Object
    Dim storedRow As Long, storedDate As Variant
    Dim ws As Worksheet, cell As Range, r As Long, n As Long, field As Long, uid As String, baseline As Variant, accountFields As Variant, addresses As Variant, i As Long, capacity As Long
    Set ws = GetSheet(SH_INPUT): Set formulas = StateInputFormulas(state): tx = state("transactions")
    Set registeredRows = BatchRowsByID(registered, TX_UID_COL)
    accountFields = state("fields")
    addresses = Array(CELL_BANK, CELL_BRANCH, CELL_PERSON, CELL_RELATIONSHIP, CELL_ACCOUNT_TYPE, CELL_ACCOUNT_NO, CELL_OPEN_DATE, CELL_CLOSE_DATE)
    capacity = formulas.Count + UBound(tx, 1)
    If formulas.Count > 0 Then capacity = capacity + UBound(tx, 1) + 1
    ReDim block(1 To Application.Max(1, capacity), 1 To INPUT_RAW_COLS)
    If formulas.Count > 0 Then
        n = 1: block(n, 1) = owner: block(n, 2) = "@": block(n, 3) = 1: block(n, 4) = "�z�u"
        block(n, 5) = UBound(tx, 1)
    End If
    For Each key In formulas.Keys
        Set cell = ws.Range(CStr(key)): uid = "@": field = cell.Column
        baseline = cell.Value2
        If cell.Row >= TX_FIRST_ROW Then
            r = cell.Row - TX_FIRST_ROW + 1
            If r > UBound(tx, 1) Then GoTo NextFormula
            uid = CellText(tx(r, 11)): field = cell.Column - COL_TX_YEAR + 1
            '���ʂ��󕶎��̎������̍s�ɂ��A���ʒu�Ŗ߂���L�^���c���B
            If Len(uid) = 0 Then uid = "@" & CStr(key)
            baseline = tx(r, field)
            If registeredRows.Exists(uid) Then
                storedRow = CLng(registeredRows(uid))
                If field >= 4 Then
                    baseline = registered(storedRow, field + 3)
                ElseIf TryStoredDate(registered(storedRow, OUT_COL_DATE), storedDate) Then
                    If field = 1 Then baseline = Year(CDate(storedDate))
                    If field = 2 Then baseline = Month(CDate(storedDate))
                    If field = 3 Then baseline = Day(CDate(storedDate))
                End If
            End If
        Else
            uid = "@" & CStr(key)
            For i = 0 To 7
                If ws.Range(CStr(addresses(i))).Cells(1, 1).Address(False, False) = CStr(key) Then
                    baseline = accountFields(i)
                    If VarType(baseline) = vbDate Then baseline = Format$(CDate(baseline), "yyyy/m/d")
                    Exit For
                End If
            Next i
        End If
        token = formulas(key): n = n + 1
        block(n, 1) = owner: block(n, 2) = uid: block(n, 3) = field: block(n, 4) = "��"
        block(n, 5) = token(0): block(n, 6) = token(1): block(n, 7) = InputTokenDialect(token)
        If UBound(token) >= 3 Then block(n, 8) = token(3)
        block(n, 9) = baseline
NextFormula:
    Next key
    For r = 1 To UBound(tx, 1)
        uid = CellText(tx(r, 11))
        If formulas.Count > 0 And Len(uid) > 0 Then
            n = n + 1: block(n, 1) = owner: block(n, 2) = uid: block(n, 4) = "�s�ʒu"
            block(n, 5) = TX_FIRST_ROW + r - 1
        End If
        If Len(uid) > 0 And HasText(tx(r, 4)) Then
            n = n + 1: block(n, 1) = owner: block(n, 2) = uid: block(n, 3) = 4: block(n, 4) = "����"
            block(n, 5) = InputTimeGrain(tx(r, 4)): block(n, 9) = tx(r, 4)
        End If
    Next r
    BuildAccountInputRaw = ReplaceAccountRows(original, block, n, 1, owner)
End Function

Public Function RestoreRegisteredInputRaw(ByVal owner As String, ByVal layoutTrusted As Boolean) As String
    Dim data As Variant, ids As Object, raw As Variant, ws As Worksheet, r As Long, field As Long
    Dim uid As String, cell As Range, token As Variant, changed As Boolean, beforeValue As Variant, expected As Object, key As Variant
    Dim kind As String, legacyLayout As Boolean, sameValue As Boolean
    If Not SheetExists(SH_INPUT_RAW) Then ResetInputFormulaTracking: Exit Function
    data = ReadInputRawData(): Set ws = GetSheet(SH_INPUT): Set ids = CreateObject("Scripting.Dictionary")
    Set expected = CreateObject("Scripting.Dictionary")
    raw = ws.Range("L" & TX_FIRST_ROW & ":L" & Application.Max(TX_FIRST_ROW + 1, LastInputDataRow())).Value2
    For r = 1 To UBound(raw, 1)
        If HasText(raw(r, 1)) Then ids(CellText(raw(r, 1))) = TX_FIRST_ROW + r - 1
    Next r
    For r = 2 To UBound(data, 1)
        If CellText(data(r, 1)) = owner Then
            kind = CellText(data(r, 4))
            If kind <> "��" And kind <> "����" Then GoTo NextRaw
            uid = CellText(data(r, 2)): field = CLng(Val(CellText(data(r, 3)))): Set cell = Nothing
            If Left$(uid, 1) = "@" And Len(uid) > 1 Then
                Set cell = ws.Range(Mid$(uid, 2))
                If cell.Row >= TX_FIRST_ROW And Not layoutTrusted Then Err.Raise vbObjectError + 3415, , "�����̌��̍s�z�u���m�F�ł��܂���B�ۑ��ς݂̉������A�܂��͍X�V�O�̃u�b�N����m�F���Ă��������B"
            ElseIf ids.Exists(uid) And field >= 1 And field <= 10 Then
                Set cell = ws.Cells(CLng(ids(uid)), COL_TX_YEAR + field - 1)
            End If
            If Not cell Is Nothing Then
                If kind = "��" Then
                    beforeValue = cell.Value2
                    token = Array(data(r, 5), CellText(data(r, 6)), CLng(Val(CellText(data(r, 7)))), CellText(data(r, 8)))
                    If InputBlankCanFill(Array(beforeValue, "")) And InputBlankCanFill(Array(data(r, 9), "")) Then
                        sameValue = True
                    ElseIf cell.Row >= TX_FIRST_ROW Then
                        sameValue = ImportFieldEqual(beforeValue, data(r, 9), field)
                    ElseIf cell.Address(False, False) = ws.Range(CELL_OPEN_DATE).Address(False, False) Or cell.Address(False, False) = ws.Range(CELL_CLOSE_DATE).Address(False, False) Then
                        sameValue = AccountFieldEqual(beforeValue, data(r, 9), 8)
                    ElseIf cell.Address(False, False) = ws.Range(CELL_ACCOUNT_NO).Address(False, False) Then
                        sameValue = AccountFieldEqual(beforeValue, data(r, 9), 7)
                    Else
                        sameValue = (CellText(beforeValue) = CellText(data(r, 9)))
                    End If
                    If Not sameValue Then changed = True
                    WriteInputCellToken cell, token, (Left$(uid, 1) <> "@")
                    expected(cell.Address(False, False)) = data(r, 5)
                    If Not layoutTrusted Then legacyLayout = True
                ElseIf kind = "����" Then
                    If Not cell.HasFormula Then
                        If CLng(Val(CellText(data(r, 5)))) = 1 Then
                            If ImportFieldEqual(cell.Value2, data(r, 9), 4) Then cell.Value2 = PreciseInputTimeText(cell.Value2, 1)
                        End If
                    End If
                End If
            End If
        End If
NextRaw:
    Next r
    If expected.Count > 0 Then ws.Calculate
    For Each key In expected.Keys
        If Not InputValuesEqual(ws.Range(CStr(key)).Value2, expected(key)) Then changed = True
    Next key
    ResetInputFormulaTracking
    If changed Or legacyLayout Then MarkInputDirty ws.Range(CELL_ACCOUNT_NO)
    If legacyLayout Then
        RestoreRegisteredInputRaw = "���̍s�z�u�����L�^�܂��͕s�����ł��B�����̎Q�Ɛ�ƌv�Z���ʂ��m�F���Ă��甽�f���Ă��������B"
    ElseIf changed Then
        RestoreRegisteredInputRaw = "���̐����ƌ��݂̒l�ɕύX������܂��B���͓��e���m�F���Ĕ��f�ł��܂��B"
    End If
End Function

Public Function InputTimeGrain(ByVal value As Variant) As Long
    Dim text As String, parsed As Variant, ok As Boolean
    InputTimeGrain = 86400
    parsed = NormalizeTimeInput(value, ok)
    If Not ok Or Not HasText(parsed) Then Exit Function
    InputTimeGrain = 60
    text = Replace(CellText(value), "�F", ":")
    If UBound(Split(text, ":")) >= 2 Or Len(Replace(text, " ", "")) = 6 And InStr(text, ":") = 0 Then InputTimeGrain = 1
    If Second(CDate(parsed)) <> 0 Then InputTimeGrain = 1
End Function

Public Function PreciseInputTimeText(ByVal value As Variant, Optional ByVal grain As Long = 0) As String
    Dim parsed As Variant, ok As Boolean
    parsed = NormalizeTimeInput(value, ok)
    If Not ok Then PreciseInputTimeText = CellText(value): Exit Function
    If Not HasText(parsed) Then Exit Function
    If grain = 0 Then grain = InputTimeGrain(value)
    PreciseInputTimeText = Format$(CDate(parsed), IIf(grain = 1, "hh:mm:ss", "hh:mm"))
End Function

Public Function AnalysisTimeGrains() As Object
    Dim data As Variant, result As Object, r As Long
    Set result = CreateObject("Scripting.Dictionary")
    data = ReadInputRawData()
    For r = 2 To UBound(data, 1)
        If CellText(data(r, 4)) = "����" Then result(CellText(data(r, 2))) = Array(CLng(Val(CellText(data(r, 5)))), data(r, 9))
    Next r
    Set AnalysisTimeGrains = result
End Function

Public Function RecordedTimeGrain(ByVal uid As String, ByVal value As Variant, ByVal grains As Object) As Long
    Dim saved As Variant, parsed As Variant, ok As Boolean
    RecordedTimeGrain = InputTimeGrain(value)
    If Not grains.Exists(uid) Then Exit Function
    saved = grains(uid): parsed = NormalizeTimeInput(saved(1), ok)
    If ok And HasText(parsed) And HasText(value) And IsNumeric(value) Then
        If Abs(CDbl(parsed) - CDbl(value)) < 0.00000001 Then
            If CLng(saved(0)) = 1 Or CLng(saved(0)) = 60 Then RecordedTimeGrain = CLng(saved(0))
        End If
    End If
End Function

Public Sub ResetInputFormulaTracking()
    Set mFormulaSeen = Nothing: mFormulaContext = ""
End Sub

Public Sub EnsureInputFormulaTracking()
    If Not SheetExists(SH_INPUT) Then Exit Sub
    If mFormulaSeen Is Nothing Or mFormulaContext <> CurrentDraftKey() Then
        Set mFormulaSeen = ReadInputFormulaCells(): mFormulaContext = CurrentDraftKey()
        ReconcileInputFormulaState mFormulaSeen
    End If
End Sub

Public Sub CheckInputFormulaResults()
    Dim key As Variant, token As Variant, current As Variant, ws As Worksheet, changed As Boolean, previousEvents As Boolean
    If mCheckingFormula Or ToolAppScopeActive() Then Exit Sub
    If Not SheetExists(SH_INPUT) Then Exit Sub
    On Error GoTo Done
    mCheckingFormula = True: previousEvents = Application.EnableEvents
    EnsureInputFormulaTracking
    Set ws = GetSheet(SH_INPUT)
    For Each key In mFormulaSeen.Keys
        token = mFormulaSeen(key): current = InputCellToken(ws.Range(CStr(key)))
        If Not InputValuesEqual(token(0), current(0)) Or Not InputTokenEqual(token, current) Then changed = True
        mFormulaSeen(key) = current
    Next key
    If changed Then
        Application.EnableEvents = False
        MarkInputDirty ws.Range(CELL_ACCOUNT_NO)
        InvalidateDateCacheFrom TX_FIRST_ROW
    End If
    SyncInputHistoryDerivedState
Done:
    Application.EnableEvents = previousEvents
    mCheckingFormula = False
End Sub

Public Sub ReconcileInputFormulaState(Optional ByVal formulas As Object = Nothing)
    Dim ws As Worksheet, expected As Object, data As Variant, key As Variant
    Dim owner As String, cell As Range, uid As String, field As Long, r As Long, token As Variant
    Dim previousEvents As Boolean, changed As Boolean, message As String, number As Long
    If Not SheetExists(SH_INPUT) Then Exit Sub
    If InputIsDirty Then Exit Sub
    owner = CurrentEditAccountID(): If Len(owner) = 0 Then Exit Sub
    If formulas Is Nothing Then Set formulas = ReadInputFormulaCells()
    If formulas.Count = 0 Then Exit Sub
    Set ws = GetSheet(SH_INPUT): Set expected = CreateObject("Scripting.Dictionary")
    data = ReadInputRawData()
    For r = 2 To UBound(data, 1)
        If CellText(data(r, 1)) = owner And CellText(data(r, 4)) = "��" Then
            key = CellText(data(r, 2)) & "|" & CellText(data(r, 3))
            expected(key) = Array(data(r, 5), CellText(data(r, 6)), CLng(Val(CellText(data(r, 7)))))
        End If
    Next r
    For Each key In formulas.Keys
        Set cell = ws.Range(CStr(key)): field = cell.Column
        uid = "@" & CStr(key)
        If cell.Row >= TX_FIRST_ROW Then
            field = cell.Column - COL_TX_YEAR + 1
            If HasText(ws.Cells(cell.Row, INPUT_UID_COL).Value2) Then uid = CellText(ws.Cells(cell.Row, INPUT_UID_COL).Value2)
        End If
        token = formulas(key)
        If expected.Exists(uid & "|" & field) Then
            changed = Not ReflectedFormulaTokenEqual(token, expected(uid & "|" & field))
        Else
            changed = True
        End If
        If changed Then Exit For
    Next key
    If Not changed Then Exit Sub
    previousEvents = Application.EnableEvents
    On Error GoTo EH
    Application.EnableEvents = False
    MarkInputDirty ws.Range(CELL_ACCOUNT_NO)
    InvalidateDateCacheFrom TX_FIRST_ROW
    SyncInputHistoryDerivedState
    Application.EnableEvents = previousEvents
    Exit Sub
EH:
    number = Err.Number: message = Err.Description
    Application.EnableEvents = previousEvents
    Err.Raise number, "ReconcileInputFormulaState", message
End Sub

Public Function ReflectedFormulaTokenEqual(ByVal current As Variant, ByVal reflected As Variant) As Boolean
    ReflectedFormulaTokenEqual = InputTokenEqual(current, reflected) And InputValuesEqual(current(0), reflected(0))
End Function

Public Function RebaseAccountRawFormulas(ByVal raw As Variant, ByVal oldAcc As Variant, ByVal nextAcc As Variant, ByVal selected As Object) As Variant
    Dim result As Variant, changed As Object, oldRows As Object, nextRows As Object, id As Variant
    Dim r As Long, c As Long, n As Long, key As String, field As Long, oldRow As Long, nextRow As Long
    Set changed = CreateObject("Scripting.Dictionary")
    Set oldRows = BatchRowsByID(oldAcc, 1): Set nextRows = BatchRowsByID(nextAcc, 1)
    For Each id In selected.Keys
        If oldRows.Exists(id) And nextRows.Exists(id) Then
            oldRow = CLng(oldRows(id)): nextRow = CLng(nextRows(id))
            For field = 2 To 9
                If Not AccountFieldEqual(oldAcc(oldRow, field), nextAcc(nextRow, field), field) Then
                    changed(CStr(id) & "|@" & InputAccountFieldAddress(field)) = True
                End If
            Next field
        End If
    Next id
    ReDim result(1 To UBound(raw, 1), 1 To INPUT_RAW_COLS)
    For r = 1 To UBound(raw, 1)
        key = CellText(raw(r, 1)) & "|" & CellText(raw(r, 2))
        If CellText(raw(r, 4)) <> "��" Or Not changed.Exists(key) Then
            n = n + 1
            For c = 1 To INPUT_RAW_COLS: result(n, c) = raw(r, c): Next c
        End If
    Next r
    RebaseAccountRawFormulas = FitStoreRows(result, n)
End Function


Public Function PositionAccountInputData(ByVal compact As Variant, ByVal owner As String, ByRef layoutTrusted As Boolean) As Variant
    Dim raw As Variant, r As Long, kind As String
    raw = ReadInputRawData()
    PositionAccountInputData = PlaceRegisteredInputRows(compact, raw, owner, layoutTrusted)
    If layoutTrusted Then Exit Function
    For r = 2 To UBound(raw, 1)
        If CellText(raw(r, 1)) = owner Then
            kind = CellText(raw(r, 4))
            If kind = "�z�u" Or kind = "�s�ʒu" Then Err.Raise vbObjectError + 3414, , "�ۑ����ꂽ�����̍s�z�u���s�����ł��B���݂̓��͕͂ύX���Ă��܂���B�ۑ��ς݂̉������A�܂��͍X�V�O�̃u�b�N����m�F���Ă��������B"
        End If
    Next r
End Function

Public Function PlaceRegisteredInputRows(ByVal compact As Variant, ByVal raw As Variant, ByVal owner As String, ByRef layoutTrusted As Boolean) As Variant
    Dim positions As Object, occupied As Object, seen As Object, r As Long, c As Long, slot As Long
    Dim height As Long, markerCount As Long, uid As String, kind As String, value As Variant, result As Variant
    layoutTrusted = False: PlaceRegisteredInputRows = compact
    Set positions = CreateObject("Scripting.Dictionary"): Set occupied = CreateObject("Scripting.Dictionary")
    Set seen = CreateObject("Scripting.Dictionary")
    '�z�u���͑S�̂����؂��Ă���g���B�����E�d���Ŗ��ׂ��㏑�����Ȃ��B
    For r = 2 To UBound(raw, 1)
        If CellText(raw(r, 1)) = owner Then
            kind = CellText(raw(r, 4)): value = raw(r, 5)
            If kind = "�z�u" Or kind = "�s�ʒu" Then
                If IsError(value) Or IsNull(value) Or IsEmpty(value) Then Exit Function
                If Not IsNumeric(value) Then Exit Function
                If CDbl(value) <> Fix(CDbl(value)) Then Exit Function
                If CDbl(value) < 1 Or CDbl(value) > 1048576 Then Exit Function
                If kind = "�z�u" Then
                    markerCount = markerCount + 1
                    If markerCount > 1 Or CellText(raw(r, 3)) <> "1" Then Exit Function
                    height = CLng(value)
                    If height > 1048576 - TX_FIRST_ROW + 1 Then Exit Function
                Else
                    slot = CLng(value) - TX_FIRST_ROW + 1: uid = CellText(raw(r, 2))
                    If slot < 1 Or Len(uid) = 0 Then Exit Function
                    If positions.Exists(uid) Or occupied.Exists(CStr(slot)) Then Exit Function
                    positions(uid) = slot: occupied(CStr(slot)) = True
                End If
            End If
        End If
    Next r
    If markerCount <> 1 Then Exit Function
    For r = 1 To UBound(compact, 1)
        uid = CellText(compact(r, 11))
        If Len(uid) > 0 Then
            If Not positions.Exists(uid) Then Exit Function
            slot = CLng(positions(uid))
            If slot > height Or seen.Exists(uid) Then Exit Function
            seen(uid) = True
        ElseIf InputRowHasValues(compact, r) Then
            Exit Function
        End If
    Next r
    ReDim result(1 To height, 1 To 11)
    For r = 1 To UBound(compact, 1)
        uid = CellText(compact(r, 11))
        If Len(uid) > 0 Then
            slot = CLng(positions(uid))
            For c = 1 To 11: result(slot, c) = compact(r, c): Next c
        End If
    Next r
    layoutTrusted = True: PlaceRegisteredInputRows = result
End Function

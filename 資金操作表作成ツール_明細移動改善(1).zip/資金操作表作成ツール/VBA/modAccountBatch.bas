Attribute VB_Name = "modAccountBatch"
Option Explicit

Public Sub ApplyAccountBatch()
    Dim ws As Worksheet, mode As String, raw As Variant, dates As Variant, ids As Object
    Dim oldAcc As Variant, oldTx As Variant, oldBal As Variant, acc As Variant, tx As Variant, bal As Variant
    Dim r As Long, n As Long, columns As Long, id As String
    Dim labelsData As Variant, dateLabels As Object, result As Collection, merged As Collection, drafts As Object
    Dim baseAcc As Variant, baseBal As Variant, oldConflicts As Variant, conflicts As Variant, display As Variant, conflictStore As Worksheet
    Dim appStarted As Boolean, writing As Boolean, committed As Boolean, message As String, restoring As String
    Dim oldDrafts As Variant, nextDrafts As Variant, inputBefore As Collection, inputAfter As Collection, selected As Object
    Dim oldRaw As Variant, nextRaw As Variant
    On Error GoTo EH
    mode = BatchMode(): If mode <> "�c��" And mode <> "�������" Then Exit Sub
    ParkCurrentInput
    Set ws = GetSheet(SH_BATCH)
    n = CLng(ws.Range("XFD2").Value2): columns = CLng(ws.Range("XFD3").Value2)
    raw = ws.Range("A6").Resize(n, columns).Value2
    oldAcc = ReadStore(GetSheet(SH_ACCOUNTS), 10): oldTx = ReadStore(GetSheet(SH_WORK_TX), TX_STORE_COLS): oldBal = ReadStore(GetSheet(SH_WORK_BAL), 13)
    If mode = "�c��" Then
        labelsData = GetSheet(SH_BATCH_BAL).Range("P2").Resize(columns - 6, 2).Value2
        Set dateLabels = CreateObject("Scripting.Dictionary")
        For r = 1 To UBound(labelsData, 1): dateLabels(CStr(CLng(labelsData(r, 1)))) = CellText(labelsData(r, 2)): Next r
        dates = ws.Range("G5").Resize(1, columns - 6).Value2
        '���t1��ł��z��Ƃ��Ĉ����B
        If columns = 7 Then
            ReDim dates(1 To 1, 1 To 1): dates(1, 1) = ws.Range("G5").Value2
        End If
    End If
    baseAcc = ReadStore(GetSheet(SH_BATCH_ACC), 10): baseBal = ReadStore(GetSheet(SH_BATCH_BAL), 13)
    oldConflicts = ReadBatchConflicts(): oldDrafts = ParkedDraftData()
    oldRaw = ReadInputRawData()
    Set selected = CreateObject("Scripting.Dictionary")
    For r = 1 To UBound(raw, 1): selected(CellText(raw(r, 1))) = True: Next r
    Set drafts = DraftEditMap(oldDrafts, oldAcc, oldBal, selected)
    Set inputBefore = CaptureInputState()
    Set merged = MergeAccountBatch(raw, mode, baseAcc, baseBal, oldAcc, oldBal, dates, oldConflicts, drafts)
    conflicts = merged("conflicts"): display = merged("display"): Set ids = merged("ids")
    If CLng(merged("count")) > 0 And ids.Count > 0 Then
        Set result = BuildBatchStoreData(ChangedBatchRows(merged("raw"), ids), mode, oldAcc, oldTx, oldBal, dates, dateLabels)
        acc = result("accounts"): tx = result("transactions"): bal = result("balances")
    Else
        acc = oldAcc: tx = oldTx: bal = oldBal
    End If
    nextDrafts = RebaseParkedAccounts(oldDrafts, ids, oldAcc, acc, oldBal, bal)
    nextRaw = RebaseAccountRawFormulas(oldRaw, oldAcc, acc, ids)
    If ids.Exists(CurrentEditAccountID()) Then Set inputAfter = RebaseAccountState(inputBefore, oldAcc, acc, oldBal, bal)
    AppBegin "�܂Ƃߓ��͂𔽉f���Ă��܂�..."
    appStarted = True
    writing = True
    If ids.Count > 0 Then
        WriteStore GetSheet(SH_ACCOUNTS), acc
        WriteStore GetSheet(SH_WORK_BAL), bal
        WriteStore GetSheet(SH_WORK_TX), tx
        WriteStore InputRawStore(), nextRaw
    End If
    WriteStore GetSheet(SH_BATCH_ACC), NextBatchAccountBaseline(acc, conflicts, mode)
    WriteStore GetSheet(SH_BATCH_BAL), NextBatchBalanceBaseline(bal, baseBal, conflicts, mode, dates)
    WriteStore GetSheet(SH_PARKED_DRAFTS), nextDrafts
    If Not inputAfter Is Nothing Then
        WriteInputAccountState inputAfter
        GetSheet(SH_INPUT).Calculate
        ReconcileInputFormulaState
    End If
    Set conflictStore = GetOrCreateSheet(SH_BATCH_CONFLICT, False)
    conflictStore.Columns("A:G").NumberFormat = "@": WriteStore conflictStore, conflicts: conflictStore.Visible = xlSheetVeryHidden
    ws.Range("A6").Resize(n, columns).Value2 = display
    If ids.Count > 0 Then InvalidateOutputViews Else MarkFileNeedsSave
    committed = True
    If Not inputAfter Is Nothing Then
        ClearInputUndo
        RenderBalancePage
        ProtectInputSheet
    End If
    For r = 2 To UBound(acc, 1)
        If ids.Exists(CStr(acc(r, 1))) Then
            UpdateAccountCandidates CStr(acc(r, 2)), CStr(acc(r, 3)), CStr(acc(r, 4))
            RememberAccountType CStr(acc(r, 6))
        End If
    Next r
    If UBound(conflicts, 1) > 1 Then
        ShowBatchConflicts conflicts, oldConflicts
        ResumeBatchInput
    Else
        CloseBatchInput
    End If
    If ids.Count = 0 And UBound(conflicts, 1) = 1 Then
        SetInputStatus "�ύX�͂���܂���B�o�^���e�͂��̂܂܂ł��B"
    Else
        SetInputStatus ids.Count & " ������" & mode & "�𔽉f���܂����B" & (UBound(conflicts, 1) - 1) & "���ڂ͂܂Ƃߓ��͂ɕێ��B�ۑ��́u�ۑ��v�ł��B"
    End If
    EndAppScope appStarted
    Exit Sub
EH:
    message = Err.Description
    On Error Resume Next
    If writing And Not committed Then
        Err.Clear
        If ids.Count > 0 Then
            WriteStore GetSheet(SH_ACCOUNTS), oldAcc
            If Err.Number <> 0 Then restoring = " ����": Err.Clear
            WriteStore GetSheet(SH_WORK_BAL), oldBal
            If Err.Number <> 0 Then restoring = restoring & " �c��": Err.Clear
            WriteStore GetSheet(SH_WORK_TX), oldTx
            If Err.Number <> 0 Then restoring = restoring & " ���"
            Err.Clear
            WriteStore InputRawStore(), oldRaw
            If Err.Number <> 0 Then restoring = restoring & " ������"
        End If
        Err.Clear
        WriteStore GetSheet(SH_PARKED_DRAFTS), oldDrafts
        If Err.Number <> 0 Then restoring = restoring & " �������F" & Err.Description: Err.Clear
        If Not inputBefore Is Nothing Then RestoreInputState inputBefore
        If Err.Number <> 0 Then restoring = restoring & " ���͉�ʁF" & Err.Description: Err.Clear
        WriteStore GetSheet(SH_BATCH_ACC), baseAcc
        If Err.Number <> 0 Then restoring = restoring & " �����̊J�n�l�F" & Err.Description: Err.Clear
        WriteStore GetSheet(SH_BATCH_BAL), baseBal
        If Err.Number <> 0 Then restoring = restoring & " �c���̊J�n�l�F" & Err.Description: Err.Clear
        If Not conflictStore Is Nothing Then WriteStore conflictStore, oldConflicts
        If Err.Number <> 0 Then restoring = restoring & " �����̋L�^�F" & Err.Description: Err.Clear
        ws.Range("A6").Resize(n, columns).Value2 = raw
        If Err.Number <> 0 Then restoring = restoring & " �܂Ƃߓ���"
        InvalidateOutputViews
    End If
    ProtectInputSheet
    EndAppScope appStarted
    On Error GoTo 0
    If Len(restoring) > 0 Then
        message = "�����������F" & restoring & "�B�㏑���ۑ������A�ۑ��ς݃u�b�N���J�������Ă��������B" & vbCrLf & message
    ElseIf committed Then
        message = "�o�^�f�[�^�ւ̔��f�͊������܂����B�Ĕ��f�����A�o�^��������J�������Ă��������B" & vbCrLf & message
    Else
        message = "�o�^�f�[�^�͕ύX���Ă��܂���B�܂Ƃߓ��͂̓��e�͎c���Ă��܂��B" & vbCrLf & message
    End If
    MsgBox message, vbExclamation
End Sub

Public Function FitStoreRows(ByVal data As Variant, ByVal count As Long) As Variant
    Dim result As Variant, r As Long, c As Long
    ReDim result(1 To count, 1 To UBound(data, 2))
    For r = 1 To count
        For c = 1 To UBound(data, 2): result(r, c) = data(r, c): Next c
    Next r
    FitStoreRows = result
End Function

Public Function BalanceDataForAccounts(ByVal data As Variant, ByVal ids As Object) As Variant
    Dim result As Variant, r As Long, c As Long, count As Long
    ReDim result(1 To UBound(data, 1), 1 To UBound(data, 2))
    count = 1
    For c = 1 To UBound(data, 2): result(1, c) = data(1, c): Next c
    For r = 2 To UBound(data, 1)
        If ids.Exists(CellText(data(r, 13))) Then
            count = count + 1
            For c = 1 To UBound(data, 2): result(count, c) = data(r, c): Next c
        End If
    Next r
    BalanceDataForAccounts = FitStoreRows(result, count)
End Function


Private Sub SetTransactionIdentity(ByRef data As Variant, ByVal row As Long, ByVal acc As Variant, ByVal ar As Long)
    data(row, 1) = acc(ar, 2): data(row, 2) = acc(ar, 3): data(row, 3) = acc(ar, 4)
    data(row, 4) = acc(ar, 6): data(row, 5) = acc(ar, 7): data(row, 14) = acc(ar, 5): data(row, 15) = acc(ar, 1)
End Sub

Private Sub SetBalanceIdentity(ByRef data As Variant, ByVal row As Long, ByVal acc As Variant, ByVal ar As Long)
    data(row, 1) = acc(ar, 4): data(row, 2) = acc(ar, 2): data(row, 3) = acc(ar, 3)
    data(row, 4) = acc(ar, 6): data(row, 5) = acc(ar, 7): data(row, 6) = acc(ar, 8): data(row, 7) = acc(ar, 9)
    data(row, 11) = acc(ar, 10): data(row, 12) = acc(ar, 5): data(row, 13) = acc(ar, 1)
End Sub

Public Function BuildBatchStoreData(ByVal raw As Variant, ByVal mode As String, ByVal oldAcc As Variant, ByVal oldTx As Variant, ByVal oldBal As Variant, ByVal dates As Variant, ByVal dateLabels As Object) As Collection
    Dim acc As Variant, tx As Variant, bal As Variant, ids As Object, accountRows As Object
    Dim r As Long, c As Long, ar As Long, n As Long, nBal As Long, nTx As Long, columns As Long, id As String, key As String
    Dim value As Variant, ok As Boolean, result As New Collection, gridDates As Object, keepRow As Boolean
    n = UBound(raw, 1): columns = UBound(raw, 2)
    acc = oldAcc
    Set ids = CreateObject("Scripting.Dictionary"): Set accountRows = CreateObject("Scripting.Dictionary")
    For r = 2 To UBound(acc, 1): accountRows(CStr(acc(r, 1))) = r: Next r
    For r = 1 To n
        id = CellText(raw(r, 1))
        If Not accountRows.Exists(id) Or ids.Exists(id) Then Err.Raise vbObjectError + 3310, , "�Ώۂ̌������ς���Ă��܂��B�܂Ƃߓ��͂��J�������Ă��������B"
        ids.Add id, True: ar = CLng(accountRows(id))
        If mode = "�������" Then
            For c = 2 To 10
                If c <> 8 And c <> 9 Then
                    acc(ar, c) = raw(r, c)
                End If
            Next c
            acc(ar, 7) = NormalizeAccountHyphen(CStr(acc(ar, 7)))
        End If
    Next r
    If mode = "�c��" Then
        Set gridDates = CreateObject("Scripting.Dictionary")
        For c = 1 To UBound(dates, 2): gridDates(CStr(CLng(dates(1, c)))) = True: Next c
        ReDim bal(1 To UBound(oldBal, 1) + n * (columns - 6), 1 To 13)
        nBal = 1
        For c = 1 To 13: bal(1, c) = oldBal(1, c): Next c
        For r = 2 To UBound(oldBal, 1)
            keepRow = True
            If ids.Exists(CStr(oldBal(r, 13))) Then keepRow = Not gridDates.Exists(CStr(CLng(oldBal(r, 8))))
            If keepRow Then
                nBal = nBal + 1
                For c = 1 To 13: bal(nBal, c) = oldBal(r, c): Next c
            End If
        Next r
        For r = 1 To n
            ar = CLng(accountRows(CStr(raw(r, 1))))
            For c = 7 To columns
                If CellText(raw(r, c)) <> "-" Then
                    value = ParseMoney(raw(r, c), True, ok)
                    If Not ok Then
                        Err.Raise vbObjectError + 3314, , (r + 5) & "�s�ځE" & Format$(CDate(dates(1, c - 6)), "yyyy/m/d") & "�̎c���𐮐��œ��͂��Ă��������B�󗓂��g�p�ł��܂��B"
                    End If
                    If HasText(value) Then
                        nBal = nBal + 1
                        SetBalanceIdentity bal, nBal, acc, ar
                        bal(nBal, 8) = dates(1, c - 6): bal(nBal, 9) = dateLabels(CStr(CLng(dates(1, c - 6))))
                        bal(nBal, 10) = value
                    End If

                End If
            Next c
        Next r
        bal = FitStoreRows(bal, nBal)
    Else
        bal = oldBal
        For r = 2 To UBound(bal, 1)
            id = CStr(bal(r, 13))
            If ids.Exists(id) Then SetBalanceIdentity bal, r, acc, CLng(accountRows(id))
        Next r
    End If
    ReDim tx(1 To UBound(oldTx, 1) + UBound(bal, 1), 1 To TX_STORE_COLS)
    nTx = 1
    For c = 1 To TX_STORE_COLS: tx(1, c) = oldTx(1, c): Next c
    For r = 2 To UBound(oldTx, 1)
        id = CStr(oldTx(r, 15))
        If Not (mode = "�c��" And ids.Exists(id) And CStr(oldTx(r, 16)) = "�c��") Then
            nTx = nTx + 1
            For c = 1 To TX_STORE_COLS: tx(nTx, c) = oldTx(r, c): Next c
            If ids.Exists(id) Then SetTransactionIdentity tx, nTx, acc, CLng(accountRows(id))
        End If
    Next r
    If mode = "�c��" Then
        For r = 2 To UBound(bal, 1)
            id = CStr(bal(r, 13))
            If ids.Exists(id) Then
                nTx = nTx + 1
                SetTransactionIdentity tx, nTx, acc, CLng(accountRows(id))
                tx(nTx, 6) = bal(r, 8): tx(nTx, 12) = BalanceTekiyoLabel(bal(r, 9))
                tx(nTx, 13) = bal(r, 10): tx(nTx, 16) = "�c��"
            End If
        Next r
    End If
    tx = FitStoreRows(tx, nTx)
    result.Add acc, "accounts": result.Add tx, "transactions": result.Add bal, "balances"
    result.Add ids, "ids"
    Set BuildBatchStoreData = result
End Function

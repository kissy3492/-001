Attribute VB_Name = "modAnalysisTime"
Option Explicit

'�L�^�̕���\����ԂƂ��Ĕ�r����B�������E�����b�̑O��͒f�肵�Ȃ��B
Public Function CompareRecordedTimes(ByVal firstDay As Double, ByVal firstTime As Variant, ByVal firstGrain As Long, ByVal secondDay As Double, ByVal secondTime As Variant, ByVal secondGrain As Long) As Long
    Dim firstStart As Double, firstEnd As Double, secondStart As Double, secondEnd As Double
    If Int(firstDay) < Int(secondDay) Then CompareRecordedTimes = 1: Exit Function
    If Int(firstDay) > Int(secondDay) Then CompareRecordedTimes = -1: Exit Function
    If Not HasText(firstTime) Or Not HasText(secondTime) Then Exit Function
    If Not IsNumeric(firstTime) Or Not IsNumeric(secondTime) Then Exit Function
    If firstGrain <> 1 And firstGrain <> 60 Then Exit Function
    If secondGrain <> 1 And secondGrain <> 60 Then Exit Function
    firstStart = Fix((CDbl(firstTime) - Int(CDbl(firstTime))) * 86400# + 0.0001)
    secondStart = Fix((CDbl(secondTime) - Int(CDbl(secondTime))) * 86400# + 0.0001)
    firstStart = Int(firstStart / firstGrain) * firstGrain: firstEnd = firstStart + firstGrain
    secondStart = Int(secondStart / secondGrain) * secondGrain: secondEnd = secondStart + secondGrain
    If firstEnd <= secondStart Then CompareRecordedTimes = 1
    If firstStart >= secondEnd Then CompareRecordedTimes = -1
End Function

Public Function RecordedTimeBoundary(ByVal day As Double, ByVal time As Variant, ByVal grain As Long, ByVal upper As Boolean) As Double
    Dim seconds As Double, width As Long
    RecordedTimeBoundary = Int(day) * 86400#
    width = 86400
    If HasText(time) And IsNumeric(time) Then
        If grain = 1 Or grain = 60 Then
            seconds = Fix((CDbl(time) - Int(CDbl(time))) * 86400# + 0.0001)
            RecordedTimeBoundary = RecordedTimeBoundary + Int(seconds / grain) * grain
            width = grain
        End If
    End If
    If upper Then RecordedTimeBoundary = RecordedTimeBoundary + width
End Function

Public Function TimedAmountsCovered(ByVal withdrawals As Object, ByVal deposits As Object, ByVal allowEqual As Boolean) As Boolean
    Dim wKeys As Variant, dKeys As Variant, i As Long, j As Long, available As Variant, before As Boolean
    If deposits.Count = 0 Then TimedAmountsCovered = True: Exit Function
    If withdrawals.Count = 0 Then Exit Function
    wKeys = withdrawals.Keys: dKeys = deposits.Keys
    SortNumericKeys wKeys: SortNumericKeys dKeys
    i = LBound(wKeys): available = CDec(0)
    '�����̊������ɁA�����܂łɎg����o����������x���[������B
    For j = LBound(dKeys) To UBound(dKeys)
        Do While i <= UBound(wKeys)
            before = (CDbl(wKeys(i)) < CDbl(dKeys(j)))
            If allowEqual And CDbl(wKeys(i)) = CDbl(dKeys(j)) Then before = True
            If Not before Then Exit Do
            available = available + CDec(withdrawals(wKeys(i))): i = i + 1
        Loop
        If available < CDec(deposits(dKeys(j))) Then Exit Function
        available = available - CDec(deposits(dKeys(j)))
    Next j
    TimedAmountsCovered = True
End Function

Public Function AdoptedTemporalOrder(ByVal withdrawals As Object, ByVal deposits As Object) As Long
    Dim wEarly As Object, wLate As Object, dEarly As Object, dLate As Object, uid As Variant
    Dim day As Double, time As Variant, grain As Long, first As String, last As String
    Set wEarly = CreateObject("Scripting.Dictionary"): Set wLate = CreateObject("Scripting.Dictionary")
    Set dEarly = CreateObject("Scripting.Dictionary"): Set dLate = CreateObject("Scripting.Dictionary")
    For Each uid In withdrawals.Keys
        day = CDbl(AnalysisValue(CStr(uid), 6)): time = AnalysisValue(CStr(uid), 7): grain = AnalysisTimeGrain(CStr(uid))
        first = CStr(RecordedTimeBoundary(day, time, grain, False)): last = CStr(RecordedTimeBoundary(day, time, grain, True))
        wEarly(first) = CDec(wEarly(first)) + CDec(withdrawals(uid))
        wLate(last) = CDec(wLate(last)) + CDec(withdrawals(uid))
    Next uid
    For Each uid In deposits.Keys
        day = CDbl(AnalysisValue(CStr(uid), 6)): time = AnalysisValue(CStr(uid), 7): grain = AnalysisTimeGrain(CStr(uid))
        first = CStr(RecordedTimeBoundary(day, time, grain, False)): last = CStr(RecordedTimeBoundary(day, time, grain, True))
        dEarly(first) = CDec(dEarly(first)) + CDec(deposits(uid))
        dLate(last) = CDec(dLate(last)) + CDec(deposits(uid))
    Next uid
    AdoptedTemporalOrder = -1
    If Not TimedAmountsCovered(wEarly, dLate, False) Then Exit Function
    AdoptedTemporalOrder = 0
    If TimedAmountsCovered(wLate, dEarly, True) Then AdoptedTemporalOrder = 1
End Function

'�����~�B�ʏ�3��3�E�ڍ�6��6�͈̔͂�Double�������𐳊m�ɕێ��ł��������B
Public Function TemporalMatchCapacity(ByVal withdrawals As Variant, ByVal deposits As Variant, ByVal allowed As Variant) As Double
    Dim capacity() As Double, parent() As Long, queue() As Long
    Dim nw As Long, nd As Long, sink As Long, i As Long, j As Long, head As Long, tail As Long, node As Long, nextNode As Long
    Dim amount As Double, needed As Double, sumW As Double, sumD As Double
    nw = UBound(withdrawals): nd = UBound(deposits): sink = nw + nd + 1
    ReDim capacity(0 To sink, 0 To sink): ReDim parent(0 To sink): ReDim queue(0 To sink)
    For i = 1 To nw
        capacity(0, i) = CDbl(withdrawals(i))
        sumW = sumW + CDbl(withdrawals(i))
    Next i
    For j = 1 To nd
        capacity(nw + j, sink) = CDbl(deposits(j))
        sumD = sumD + CDbl(deposits(j))
    Next j
    needed = sumW
    If sumD < needed Then needed = sumD
    For i = 1 To nw
        For j = 1 To nd
            If CBool(allowed(i, j)) Then capacity(i, nw + j) = needed
        Next j
    Next i
    Do While TemporalMatchCapacity < needed
        For i = 0 To sink: parent(i) = -1: Next i
        parent(0) = 0: queue(0) = 0: head = 0: tail = 1
        Do While head < tail And parent(sink) = -1
            node = queue(head): head = head + 1
            For nextNode = 1 To sink
                If parent(nextNode) = -1 And capacity(node, nextNode) > 0 Then
                    parent(nextNode) = node: queue(tail) = nextNode: tail = tail + 1
                    If nextNode = sink Then Exit For
                End If
            Next nextNode
        Loop
        If parent(sink) = -1 Then Exit Do
        amount = needed - TemporalMatchCapacity: node = sink
        Do While node <> 0
            If capacity(parent(node), node) < amount Then amount = capacity(parent(node), node)
            node = parent(node)
        Loop
        node = sink
        Do While node <> 0
            capacity(parent(node), node) = capacity(parent(node), node) - amount
            capacity(node, parent(node)) = capacity(node, parent(node)) + amount
            node = parent(node)
        Loop
        TemporalMatchCapacity = TemporalMatchCapacity + amount
    Loop
End Function

Public Function AnalysisCandidateOrder(ByVal ids As Object, ByRef possibleAmount As Double, ByRef uncovered As Double) As Long
    Dim ws As Collection, ds As Collection, uid As Variant, w() As Variant, d() As Variant, certain() As Variant, possible() As Variant
    Dim i As Long, j As Long, order As Long, sumW As Double, sumD As Double, needed As Double, strictAmount As Double
    Set ws = New Collection: Set ds = New Collection
    For Each uid In ids.Keys
        If AnalysisSide(CStr(uid)) = "W" Then ws.Add CStr(uid) Else ds.Add CStr(uid)
    Next uid
    AnalysisCandidateOrder = -1: possibleAmount = 0: uncovered = 0
    If ws.Count = 0 Or ds.Count = 0 Then Exit Function
    ReDim w(1 To ws.Count): ReDim d(1 To ds.Count)
    ReDim certain(1 To ws.Count, 1 To ds.Count): ReDim possible(1 To ws.Count, 1 To ds.Count)
    For i = 1 To ws.Count: w(i) = AnalysisAmount(CStr(ws(i))): sumW = sumW + CDbl(w(i)): Next i
    For j = 1 To ds.Count: d(j) = AnalysisAmount(CStr(ds(j))): sumD = sumD + CDbl(d(j)): Next j
    needed = Application.Min(sumW, sumD)
    For i = 1 To ws.Count
        For j = 1 To ds.Count
            order = AnalysisChronology(CStr(ws(i)), CStr(ds(j)))
            certain(i, j) = (order > 0): possible(i, j) = (order >= 0)
        Next j
    Next i
    strictAmount = TemporalMatchCapacity(w, d, certain)
    If strictAmount >= needed Then
        possibleAmount = needed: AnalysisCandidateOrder = 1
    Else
        possibleAmount = TemporalMatchCapacity(w, d, possible)
        uncovered = needed - possibleAmount
        If possibleAmount >= needed Then AnalysisCandidateOrder = 0
    End If
End Function

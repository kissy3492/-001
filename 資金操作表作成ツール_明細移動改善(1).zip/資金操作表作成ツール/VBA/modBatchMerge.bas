Attribute VB_Name = "modBatchMerge"
Option Explicit

Public Const SH_BATCH_CONFLICT As String = "W_�܂Ƃߋ���"
Private mConflictRow As Long

Public Function BatchValueEqual(ByVal a As Variant, ByVal b As Variant, ByVal money As Boolean) As Boolean
    Dim leftValue As Variant, rightValue As Variant, leftOK As Boolean, rightOK As Boolean
    If money Then
        If CellText(a) = "-" Then a = Empty
        If CellText(b) = "-" Then b = Empty
        leftValue = ParseMoney(a, True, leftOK): rightValue = ParseMoney(b, True, rightOK)
        If leftOK And rightOK Then
            If HasText(leftValue) <> HasText(rightValue) Then Exit Function
            If Not HasText(leftValue) Then BatchValueEqual = True: Exit Function
            BatchValueEqual = CDbl(leftValue) = CDbl(rightValue): Exit Function
        End If
    End If
    If IsError(a) Or IsError(b) Then Exit Function
    BatchValueEqual = (CellText(a) = CellText(b))
End Function

Public Function MergeBatchValue(ByVal baseline As Variant, ByVal current As Variant, ByVal edited As Variant, ByVal money As Boolean, ByRef conflict As Boolean) As Variant
    conflict = False
    If BatchValueEqual(edited, baseline, money) Then
        MergeBatchValue = current
    ElseIf BatchValueEqual(current, baseline, money) Or BatchValueEqual(current, edited, money) Then
        MergeBatchValue = edited
    Else
        conflict = True: MergeBatchValue = current
    End If
End Function

Public Function BatchRowsByID(ByVal data As Variant, ByVal idCol As Long, Optional ByVal dateCol As Long = 0) As Object
    Dim result As Object, r As Long, key As String
    Set result = CreateObject("Scripting.Dictionary")
    For r = 2 To UBound(data, 1)
        key = CellText(data(r, idCol))
        If dateCol > 0 Then key = key & "|" & CStr(CLng(data(r, dateCol)))
        result(key) = r
    Next r
    Set BatchRowsByID = result
End Function

Public Function ReadBatchConflicts() As Variant
    Dim data As Variant
    If SheetExists(SH_BATCH_CONFLICT) Then
        ReadBatchConflicts = ReadStore(GetSheet(SH_BATCH_CONFLICT), 7)
    Else
        ReDim data(1 To 1, 1 To 7): data(1, 1) = "�s": data(1, 2) = "��": data(1, 3) = "����ID"
        data(1, 4) = "�J�n�l": data(1, 5) = "���ݒl": data(1, 6) = "���͒l": data(1, 7) = "���e"
        ReadBatchConflicts = data
    End If
End Function

Public Function MergeAccountBatch(ByVal raw As Variant, ByVal mode As String, ByVal baseAcc As Variant, ByVal baseBal As Variant, ByVal currentAcc As Variant, ByVal currentBal As Variant, ByVal dates As Variant, ByVal previous As Variant, ByVal drafts As Object) As Collection
    Dim result As New Collection, currentRows As Object, baseRows As Object, currentPoints As Object, basePoints As Object, changed As Object
    Dim merged As Variant, display As Variant, pending As Variant, r As Long, c As Long, p As Long, ar As Long, br As Long
    Dim id As String, key As String, baseline As Variant, current As Variant, value As Variant, conflict As Boolean, money As Boolean
    Dim parsed As Variant, ok As Boolean, issue As String, selected As Object, pendingRows As Object, field As Variant, identityIssue As String
    Dim bIdentity As Variant, cIdentity As Variant, eIdentity As Variant, dIdentity As Variant, blocked As Object, pairKey As Variant
    Set currentRows = BatchRowsByID(currentAcc, 1): Set baseRows = BatchRowsByID(baseAcc, 1)
    Set selected = CreateObject("Scripting.Dictionary"): Set pendingRows = CreateObject("Scripting.Dictionary")
    Set changed = CreateObject("Scripting.Dictionary")
    money = (mode = "�c��")
    For r = 1 To UBound(raw, 1): selected(CellText(raw(r, 1))) = True: Next r
    If money Then Set currentPoints = BalanceValuesByKey(currentBal, selected): Set basePoints = BalanceValuesByKey(baseBal, selected)
    display = raw: merged = raw
    ReDim pending(1 To UBound(raw, 1) * UBound(raw, 2) + 1, 1 To 7)
    For c = 1 To 7: pending(1, c) = previous(1, c): Next c
    p = 1
    For r = 1 To UBound(raw, 1)
        id = CellText(raw(r, 1))
        If Not currentRows.Exists(id) Then
            AddBatchPending pending, pendingRows, p, r + 5, 2, id, Empty, Empty, raw(r, 2), "���̌����͍폜�ς݁i���͕͂ێ��j"
        Else
            ar = CLng(currentRows(id)): br = 0: identityIssue = ""
            If baseRows.Exists(id) Then br = CLng(baseRows(id))
            If Not money Then
                bIdentity = AccountDataRow(baseAcc, id): cIdentity = AccountDataRow(currentAcc, id)
                eIdentity = EmptyAccountBaseline()
                For c = 1 To 10: eIdentity(1, c) = raw(r, c): Next c
                If Not HasText(bIdentity(1, 1)) Then bIdentity = cIdentity
                If Not SameAccountIdentity(eIdentity, bIdentity) Then
                    If Not SameAccountIdentity(cIdentity, bIdentity) And Not SameAccountIdentity(eIdentity, cIdentity) Then identityIssue = "�������ڂ�ʑ���ł��ύX"
                    If drafts.Exists(id & "|I") And Not SameAccountIdentity(eIdentity, cIdentity) Then
                        dIdentity = drafts(id & "|I")
                        If Not SameAccountIdentity(eIdentity, dIdentity) Then identityIssue = "���̍��ڂɒ����r���̓��͂���"
                    End If
                End If
            End If
            For c = IIf(money, 7, 2) To UBound(raw, 2)
                If money Or (c <> 8 And c <> 9) Then
                    baseline = Empty: current = Empty: key = "": issue = ""
                    If money Then
                        key = CStr(CLng(dates(1, c - 6)))
                        If basePoints.Exists(id & "|" & key) Then baseline = basePoints(id & "|" & key)
                        If currentPoints.Exists(id & "|" & key) Then current = currentPoints(id & "|" & key)
                    Else
                        If br > 0 Then baseline = baseAcc(br, c) Else baseline = currentAcc(ar, c)
                        current = currentAcc(ar, c)
                    End If
                    value = MergeBatchValue(baseline, current, raw(r, c), money, conflict)
                    If conflict Then issue = "�������ڂ�ʑ���ł��ύX"
                    '�ύX���Ă��Ȃ������l�̕s���ŁA�ʂ̍��ڂ܂Ŏ~�߂Ȃ��B
                    If Not conflict And Not BatchValueEqual(value, current, money) Then
                        If money Then
                            If CellText(value) = "-" Then value = Empty
                            parsed = ParseMoney(value, True, ok)
                            If Not ok Then issue = "�c���͐����܂��͋󗓂œ��͂��Ă�������"
                        ElseIf IsError(value) Then
                            issue = "�Z���̃G���[��������Ă�������"
                        ElseIf (c = 2 Or c = 4 Or c = 6 Or c = 7) And Not HasText(value) Then
                            issue = "��s���E�����E�ȖځE�����ԍ��͋󗓂ɂł��܂���"
                        End If
                        If Len(issue) = 0 And DraftFieldConflict(drafts, id, c, key, value, money) Then issue = "���̍��ڂɒ����r���̓��͂���"
                    End If
                    If Len(issue) > 0 Then
                        merged(r, c) = current
                        AddBatchPending pending, pendingRows, p, r + 5, c, id, baseline, current, raw(r, c), issue
                        If Not money And (c = 2 Or c = 3 Or c = 6 Or c = 7) Then identityIssue = issue
                    Else
                        merged(r, c) = value: display(r, c) = value
                    End If
                End If
            Next c
            If Not money And Len(identityIssue) > 0 Then
                For Each field In Array(2, 3, 6, 7)
                    c = CLng(field): merged(r, c) = currentAcc(ar, c): display(r, c) = raw(r, c)
                    AddBatchPending pending, pendingRows, p, r + 5, c, id, bIdentity(1, c), currentAcc(ar, c), raw(r, c), identityIssue
                Next field
            End If
        End If
    Next r
    If Not money Then
        Set blocked = SettleBatchIdentities(merged, currentAcc)
        For r = 1 To UBound(raw, 1)
            id = CellText(raw(r, 1))
            If blocked.Exists(id) Then
                ar = CLng(currentRows(id)): bIdentity = AccountDataRow(baseAcc, id)
                For Each field In Array(2, 3, 6, 7)
                    c = CLng(field): display(r, c) = raw(r, c)
                    AddBatchPending pending, pendingRows, p, r + 5, c, id, bIdentity(1, c), currentAcc(ar, c), raw(r, c), "�ύX��̋�s�E�x�X�E�ȖځE�ԍ����ʌ����Əd��"
                Next field
            End If
        Next r
    End If
    For r = 1 To UBound(raw, 1)
        id = CellText(raw(r, 1))
        If currentRows.Exists(id) Then
            ar = CLng(currentRows(id))
            For c = IIf(money, 7, 2) To UBound(raw, 2)
                If money Or (c <> 8 And c <> 9) Then
                    current = Empty
                    If money Then
                        key = id & "|" & CStr(CLng(dates(1, c - 6)))
                        If currentPoints.Exists(key) Then current = currentPoints(key)
                    Else
                        current = currentAcc(ar, c)
                    End If
                    If Not BatchValueEqual(merged(r, c), current, money) Then changed(id) = True
                End If
            Next c
        End If
    Next r
    result.Add merged, "raw": result.Add display, "display": result.Add FitStoreRows(pending, p), "conflicts"
    result.Add changed, "ids": result.Add UBound(raw, 1), "count"
    Set MergeAccountBatch = result
End Function
Public Sub ShowBatchConflicts(ByVal data As Variant, Optional ByVal previous As Variant)
    Dim ws As Worksheet, store As Worksheet, old As Variant, r As Long, cell As Range
    Set ws = GetSheet(SH_BATCH)
    If IsMissing(previous) Then old = ReadBatchConflicts() Else old = previous
    For r = 2 To UBound(old, 1)
        Set cell = ws.Cells(CLng(old(r, 1)), CLng(old(r, 2)))
        cell.ClearComments: cell.Interior.Color = RGB(239, 246, 255)
    Next r
    Set store = GetOrCreateSheet(SH_BATCH_CONFLICT, False)
    store.Columns("A:G").NumberFormat = "@": WriteStore store, data: store.Visible = xlSheetVeryHidden
    For r = 2 To UBound(data, 1)
        Set cell = ws.Cells(CLng(data(r, 1)), CLng(data(r, 2)))
        cell.ClearComments: cell.Interior.Color = RGB(255, 237, 213)
        cell.AddComment CStr(data(r, 7)) & vbLf & "���݂̓o�^�l�F" & CellText(data(r, 5)) & vbLf & "����̓��͒l�F" & CellText(data(r, 6)) & vbLf & "�l�𒼐ڒ����ł��܂��B�������ڂ̋����͉E�N���b�N�Œl��I�ׂ܂��B"
    Next r
    ws.Range("A3").Value2 = (UBound(data, 1) - 1) & "���ڂ͖����f�ŕێ��B�F�t���Z��������B�������ڂ̋����͉E�N���b�N�Œl��I�сA�u���f����v�B"
End Sub

Public Function BatchConflictMenu(ByVal target As Range) As Boolean
    Dim data As Variant, r As Long, menu As CommandBar
    If BatchMode() <> "�c��" And BatchMode() <> "�������" Then Exit Function
    data = ReadBatchConflicts()
    For r = 2 To UBound(data, 1)
        If CLng(data(r, 1)) = target.Row And CLng(data(r, 2)) = target.Column Then mConflictRow = r: Exit For
    Next r
    If r > UBound(data, 1) Then Exit Function
    BatchConflictMenu = True
    On Error GoTo Done
    Set menu = Application.CommandBars.Add(Position:=msoBarPopup, Temporary:=True)
    If CellText(data(r, 7)) = "�������ڂ�ʑ���ł��ύX" Then
        AddInputMenuItem menu, "����̓��͒l���g��", "UseBatchEditedValue"
        AddInputMenuItem menu, "���݂̓o�^�l���g��", "UseBatchCurrentValue"
    ElseIf CellText(data(r, 7)) = "���̍��ڂɒ����r���̓��͂���" Then
        AddInputMenuItem menu, "�����r���̌������J��", "OpenBatchDraftAccount"
    ElseIf CellText(data(r, 7)) = "���̌����͍폜�ς݁i���͕͂ێ��j" Then
        AddInputMenuItem menu, "���̍폜�ς݌����̍s��������", "RemoveDeletedBatchRow"
    Else
        BatchConflictMenu = False
        GoTo Done
    End If
    menu.ShowPopup
Done:
    On Error Resume Next
    If Not menu Is Nothing Then menu.Delete
    On Error GoTo 0
End Function

Public Sub UseBatchEditedValue()
    ResolveBatchValue True
End Sub

Public Sub UseBatchCurrentValue()
    ResolveBatchValue False
End Sub

Private Sub ResolveBatchValue(ByVal useEdited As Boolean)
    Dim ws As Worksheet, store As Worksheet, data As Variant, r As Long, c As Long, started As Boolean, message As String, account As Variant, field As Variant
    On Error GoTo EH
    data = ReadBatchConflicts(): If mConflictRow < 2 Or mConflictRow > UBound(data, 1) Then Exit Sub
    AppBegin: started = True
    Set ws = GetSheet(SH_BATCH): Set store = GetSheet(SH_BATCH_CONFLICT)
    r = CLng(data(mConflictRow, 1)): c = CLng(data(mConflictRow, 2))
    If Not useEdited Then
        If BatchMode() = "�������" And (c = 2 Or c = 3 Or c = 6 Or c = 7) Then
            account = AccountDataRow(ReadStore(GetSheet(SH_ACCOUNTS), 10), CellText(data(mConflictRow, 3)))
            For Each field In Array(2, 3, 6, 7): ws.Cells(r, CLng(field)).Value2 = account(1, CLng(field)): Next field
        Else
            ws.Cells(r, c).Value2 = data(mConflictRow, 5)
        End If
    End If
    '�I���������_�̓o�^�l���J�n�l�ɂ���B�ȍ~�ɍĕύX���ꂽ�ꍇ�͍Ăт��̍��ڂ������c���B
    store.Cells(mConflictRow, 4).Value2 = data(mConflictRow, 5)
    RebaseBatchChosenField CellText(data(mConflictRow, 3)), c, ws.Cells(5, c).Value2, data(mConflictRow, 5)
    ws.Cells(r, c).Interior.Color = RGB(239, 246, 255): ws.Cells(r, c).ClearComments
    MarkFileNeedsSave
    EndAppScope started
    Exit Sub
EH:
    message = Err.Description: EndAppScope started
    MsgBox "�l��I���ł��܂���ł����B���͎͂c���Ă��܂��B" & message, vbExclamation
End Sub

Public Sub OpenBatchDraftAccount()
    Dim data As Variant
    On Error GoTo EH
    data = ReadBatchConflicts()
    If mConflictRow >= 2 And mConflictRow <= UBound(data, 1) Then OpenAccountOrDraft CellText(data(mConflictRow, 3)), True
    Exit Sub
EH:
    MsgBox Err.Description, vbExclamation
End Sub

Public Sub RemoveDeletedBatchRow()
    Dim data As Variant, raw As Variant, ws As Worksheet, r As Long, c As Long, nextRow As Long, n As Long, columns As Long, emptyData As Variant, started As Boolean, message As String, i As Long, count As Long
    On Error GoTo EH
    data = ReadBatchConflicts(): If mConflictRow < 2 Or mConflictRow > UBound(data, 1) Then Exit Sub
    Set ws = GetSheet(SH_BATCH): n = CLng(ws.Range("XFD2").Value2): columns = CLng(ws.Range("XFD3").Value2)
    r = CLng(data(mConflictRow, 1))
    AppBegin: started = True
    raw = ws.Range("A6").Resize(n, columns).Value2
    For nextRow = r - 5 To n - 1
        For c = 1 To columns: raw(nextRow, c) = raw(nextRow + 1, c): Next c
    Next nextRow
    ReDim emptyData(1 To UBound(data, 1), 1 To 7)
    For c = 1 To 7: emptyData(1, c) = data(1, c): Next c
    count = 1
    For i = 2 To UBound(data, 1)
        If CLng(data(i, 1)) <> r Then
            count = count + 1
            For c = 1 To 7: emptyData(count, c) = data(i, c): Next c
            If CLng(data(i, 1)) > r Then emptyData(count, 1) = CLng(data(i, 1)) - 1
        End If
    Next i
    If n = 1 Then
        CloseBatchInput
    Else
        ws.Range("A6").Resize(n - 1, columns).Value2 = FitStoreRows(raw, n - 1)
        ws.Range("A" & n + 5).Resize(1, columns).ClearContents
        ws.Range("XFD2").Value2 = n - 1
        ShowBatchConflicts FitStoreRows(emptyData, count), data
    End If
    MarkFileNeedsSave
    EndAppScope started
    Exit Sub
EH:
    message = Err.Description: EndAppScope started
    MsgBox message, vbExclamation
End Sub

Public Function BalanceValuesByKey(ByVal data As Variant, ByVal ids As Object) As Object
    Dim result As Object, r As Long, id As String, key As String, day As Variant
    Set result = CreateObject("Scripting.Dictionary")
    For r = 2 To UBound(data, 1)
        id = CellText(data(r, 13))
        If ids.Exists(id) Then
            If Not TryStoredDate(data(r, 8), day) Then Err.Raise vbObjectError + 3315, , "�Ώی����̎c�����t��������Ă��������B"
            key = id & "|" & CStr(CLng(CDate(day)))
            If result.Exists(key) Then Err.Raise vbObjectError + 3316, , "�Ώی����̓������t�Ɏc�����d�Ȃ��Ă��܂��B"
            result.Add key, data(r, 10)
        End If
    Next r
    Set BalanceValuesByKey = result
End Function

Public Function ChangedBatchRows(ByVal data As Variant, ByVal ids As Object) As Variant
    Dim result As Variant, r As Long, c As Long, n As Long
    ReDim result(1 To ids.Count, 1 To UBound(data, 2))
    For r = 1 To UBound(data, 1)
        If ids.Exists(CellText(data(r, 1))) Then
            n = n + 1
            For c = 1 To UBound(data, 2): result(n, c) = data(r, c): Next c
        End If
    Next r
    ChangedBatchRows = FitStoreRows(result, n)
End Function


Private Sub AddBatchPending(ByRef data As Variant, ByVal rows As Object, ByRef count As Long, ByVal row As Long, ByVal col As Long, ByVal id As String, ByVal baseline As Variant, ByVal current As Variant, ByVal edited As Variant, ByVal issue As String)
    Dim key As String, r As Long
    key = row & "|" & col
    If rows.Exists(key) Then r = CLng(rows(key)) Else count = count + 1: r = count: rows(key) = r
    data(r, 1) = row: data(r, 2) = col: data(r, 3) = id: data(r, 4) = baseline
    data(r, 5) = current: data(r, 6) = edited: data(r, 7) = issue
End Sub

Public Function SettleBatchIdentities(ByRef proposed As Variant, ByVal current As Variant) As Object
    Dim currentRows As Object, proposedRows As Object, counts As Object, reject As Object, blocked As Object
    Dim r As Long, pr As Long, c As Long, id As String, key As String, oldKey As String, field As Variant, candidate As Variant
    Set currentRows = BatchRowsByID(current, 1): Set proposedRows = CreateObject("Scripting.Dictionary")
    Set blocked = CreateObject("Scripting.Dictionary")
    For r = 1 To UBound(proposed, 1): proposedRows(CellText(proposed(r, 1))) = r: Next r
    Do
        Set counts = CreateObject("Scripting.Dictionary"): Set reject = CreateObject("Scripting.Dictionary")
        For r = 2 To UBound(current, 1)
            id = CellText(current(r, 1))
            If proposedRows.Exists(id) Then
                pr = CLng(proposedRows(id)): key = AccountIdentityKey(CellText(proposed(pr, 2)), CellText(proposed(pr, 3)), CellText(proposed(pr, 6)), CellText(proposed(pr, 7)))
            Else
                key = AccountIdentityKey(CellText(current(r, 2)), CellText(current(r, 3)), CellText(current(r, 6)), CellText(current(r, 7)))
            End If
            If proposedRows.Exists(id) Then
                pr = CLng(proposedRows(id))
                If Not CompleteAccountIdentity(CellText(proposed(pr, 2)), CellText(proposed(pr, 3)), CellText(proposed(pr, 6)), CellText(proposed(pr, 7))) Then key = key & Chr$(29) & id
            Else
                If Not CompleteAccountIdentity(CellText(current(r, 2)), CellText(current(r, 3)), CellText(current(r, 6)), CellText(current(r, 7))) Then key = key & Chr$(29) & id
            End If
            counts(key) = CLng(counts(key)) + 1
        Next r
        For pr = 1 To UBound(proposed, 1)
            id = CellText(proposed(pr, 1))
            If currentRows.Exists(id) Then
                r = CLng(currentRows(id))
                oldKey = AccountIdentityKey(CellText(current(r, 2)), CellText(current(r, 3)), CellText(current(r, 6)), CellText(current(r, 7)))
                key = AccountIdentityKey(CellText(proposed(pr, 2)), CellText(proposed(pr, 3)), CellText(proposed(pr, 6)), CellText(proposed(pr, 7)))
                If key <> oldKey And CompleteAccountIdentity(CellText(proposed(pr, 2)), CellText(proposed(pr, 3)), CellText(proposed(pr, 6)), CellText(proposed(pr, 7))) Then
                    If CLng(counts(key)) > 1 Then reject(id) = pr
                End If
            End If
        Next pr
        If reject.Count = 0 Then Exit Do
        '�����ŏI�ĂŔ��肵���ύX�𓯎��ɖ߂��B�����E�z���s���ŋ��ۂ��Ȃ��B
        For Each candidate In reject.Keys
            id = CStr(candidate): pr = CLng(reject(id)): r = CLng(currentRows(id)): blocked(id) = True
            For Each field In Array(2, 3, 6, 7): c = CLng(field): proposed(pr, c) = current(r, c): Next field
        Next candidate
    Loop
    Set SettleBatchIdentities = blocked
End Function

Public Function NextBatchAccountBaseline(ByVal current As Variant, ByVal pending As Variant, ByVal mode As String) As Variant
    Dim result As Variant, rows As Object, r As Long, c As Long, id As String
    result = current
    If mode = "�������" Then
        Set rows = BatchRowsByID(current, 1)
        For r = 2 To UBound(pending, 1)
            id = CellText(pending(r, 3)): c = CLng(pending(r, 2))
            If rows.Exists(id) Then result(CLng(rows(id)), c) = pending(r, 4)
        Next r
    End If
    NextBatchAccountBaseline = result
End Function

Public Function NextBatchBalanceBaseline(ByVal current As Variant, ByVal previous As Variant, ByVal pending As Variant, ByVal mode As String, ByVal dates As Variant) As Variant
    Dim held As Object, result As Variant, r As Long, c As Long, n As Long, key As String, day As Variant
    If mode <> "�c��" Then NextBatchBalanceBaseline = current: Exit Function
    Set held = CreateObject("Scripting.Dictionary")
    For r = 2 To UBound(pending, 1)
        c = CLng(pending(r, 2))
        If c >= 7 Then held(CellText(pending(r, 3)) & "|" & CStr(CLng(dates(1, c - 6)))) = True
    Next r
    ReDim result(1 To UBound(current, 1) + UBound(previous, 1), 1 To 13)
    n = 1: For c = 1 To 13: result(1, c) = current(1, c): Next c
    For r = 2 To UBound(current, 1)
        key = ""
        If TryStoredDate(current(r, 8), day) Then key = CellText(current(r, 13)) & "|" & CStr(CLng(CDate(day)))
        If Not held.Exists(key) Then
            n = n + 1: For c = 1 To 13: result(n, c) = current(r, c): Next c
        End If
    Next r
    For r = 2 To UBound(previous, 1)
        key = ""
        If TryStoredDate(previous(r, 8), day) Then key = CellText(previous(r, 13)) & "|" & CStr(CLng(CDate(day)))
        If held.Exists(key) Then
            n = n + 1: For c = 1 To 13: result(n, c) = previous(r, c): Next c
        End If
    Next r
    NextBatchBalanceBaseline = FitStoreRows(result, n)
End Function


Private Sub RebaseBatchChosenField(ByVal id As String, ByVal field As Long, ByVal day As Variant, ByVal value As Variant)
    Dim store As Worksheet, data As Variant, rows As Object, r As Long, c As Long, key As String, result As Variant, n As Long, account As Variant, rowDay As Variant, identityField As Variant
    If BatchMode() = "�������" Then
        Set store = GetSheet(SH_BATCH_ACC): data = ReadStore(store, 10): Set rows = BatchRowsByID(data, 1)
        If rows.Exists(id) Then
            If field = 2 Or field = 3 Or field = 6 Or field = 7 Then
                account = AccountDataRow(ReadStore(GetSheet(SH_ACCOUNTS), 10), id)
                For Each identityField In Array(2, 3, 6, 7): store.Cells(CLng(rows(id)), CLng(identityField)).Value2 = account(1, CLng(identityField)): Next identityField
            Else
                store.Cells(CLng(rows(id)), field).Value2 = value
            End If
        End If
    Else
        Set store = GetSheet(SH_BATCH_BAL): data = ReadStore(store, 13)
        For r = 2 To UBound(data, 1)
            If CellText(data(r, 13)) = id And TryStoredDate(data(r, 8), rowDay) Then
                If CLng(CDate(rowDay)) = CLng(day) Then store.Cells(r, 10).Value2 = value: Exit Sub
            End If
        Next r
        If HasText(value) Then
            account = AccountDataRow(ReadStore(GetSheet(SH_ACCOUNTS), 10), id)
            ReDim result(1 To 1, 1 To 13)
            result(1, 1) = account(1, 4): result(1, 2) = account(1, 2): result(1, 3) = account(1, 3)
            result(1, 4) = account(1, 6): result(1, 5) = account(1, 7): result(1, 8) = day: result(1, 10) = value: result(1, 13) = id
            store.Cells(LastRow(store) + 1, 1).Resize(1, 13).Value2 = result
        End If
    End If
End Sub

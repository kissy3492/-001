Attribute VB_Name = "modAnalysisData"
Option Explicit

Private mAnalysisRows As Variant
Private mAnalysisIDs As Object
Private mAnalysisDays As Object
Private mAnalysisAccounts As Object
Private mAnalysisReady As Boolean
Private mDataGeneration As Long
Private mTimeGrains As Object

Public Sub InvalidateAnalysisData()
    mAnalysisReady = False
    ResetPeopleCache
    mDataGeneration = mDataGeneration + 1
    PauseAnalysisSearch
    ResetAnalysisSelectionCache
End Sub

Public Sub LoadAnalysisData()
    Dim r As Long, count As Long, order() As Long, uid As String, dayKey As String, accountKey As String
    Dim bucket As Collection, d As Variant
    If mAnalysisReady Then Exit Sub
    EnsureTransactionIdentity
    mAnalysisRows = ReadStore(GetSheet(SH_WORK_TX), TX_STORE_COLS)
    Set mTimeGrains = AnalysisTimeGrains()
    Set mAnalysisIDs = CreateObject("Scripting.Dictionary")
    Set mAnalysisDays = CreateObject("Scripting.Dictionary")
    Set mAnalysisAccounts = CreateObject("Scripting.Dictionary")
    ReDim order(1 To Application.Max(1, UBound(mAnalysisRows, 1) - 1))
    For r = 2 To UBound(mAnalysisRows, 1)
        If CellText(mAnalysisRows(r, TX_KIND_COL)) = "���" Then
            uid = CellText(mAnalysisRows(r, TX_UID_COL))
            If Len(uid) > 0 Then
                mAnalysisIDs(uid) = r
                If TryStoredDate(mAnalysisRows(r, 6), d) Then
                    If AnalysisRowAmount(r) > 0 Then count = count + 1: order(count) = r
                End If
            End If
        End If
    Next r
    If count > 1 Then SortAnalysisRows order, 1, count
    For r = 1 To count
        dayKey = CStr(CLng(Int(CDbl(mAnalysisRows(order(r), 6))))) & ":" & AnalysisRowSide(order(r))
        If Not mAnalysisDays.Exists(dayKey) Then
            Set bucket = New Collection: mAnalysisDays.Add dayKey, bucket
        End If
        Set bucket = mAnalysisDays(dayKey): bucket.Add CellText(mAnalysisRows(order(r), TX_UID_COL))
        accountKey = CellText(mAnalysisRows(order(r), TX_ID_COL)) & ":" & AnalysisRowSide(order(r))
        If Not mAnalysisAccounts.Exists(accountKey) Then
            Set bucket = New Collection: mAnalysisAccounts.Add accountKey, bucket
        End If
        Set bucket = mAnalysisAccounts(accountKey): bucket.Add CellText(mAnalysisRows(order(r), TX_UID_COL))
    Next r
    mAnalysisReady = True
End Sub

Private Function AnalysisRowAmount(ByVal r As Long) As Double
    AnalysisRowAmount = Val(CellText(mAnalysisRows(r, 8))) + Val(CellText(mAnalysisRows(r, 9)))
End Function

Private Function AnalysisRowSide(ByVal r As Long) As String
    If Val(CellText(mAnalysisRows(r, 8))) > 0 Then AnalysisRowSide = "W" Else AnalysisRowSide = "D"
End Function

Private Sub SortAnalysisRows(ByRef rows() As Long, ByVal lo As Long, ByVal hi As Long)
    Dim i As Long, j As Long, pivot As Double, swapRow As Long
    i = lo: j = hi: pivot = AnalysisRowAmount(rows((lo + hi) \ 2))
    Do While i <= j
        Do While AnalysisRowAmount(rows(i)) < pivot: i = i + 1: Loop
        Do While AnalysisRowAmount(rows(j)) > pivot: j = j - 1: Loop
        If i <= j Then
            swapRow = rows(i): rows(i) = rows(j): rows(j) = swapRow
            i = i + 1: j = j - 1
        End If
    Loop
    If lo < j Then SortAnalysisRows rows, lo, j
    If i < hi Then SortAnalysisRows rows, i, hi
End Sub

Public Function AnalysisIDs() As Object
    LoadAnalysisData
    Set AnalysisIDs = mAnalysisIDs
End Function

Public Function AnalysisValue(ByVal uid As String, ByVal column As Long) As Variant
    LoadAnalysisData
    If mAnalysisIDs.Exists(uid) Then AnalysisValue = mAnalysisRows(CLng(mAnalysisIDs(uid)), column)
End Function

Public Function AnalysisAmount(ByVal uid As String) As Double
    AnalysisAmount = Val(CellText(AnalysisValue(uid, 8))) + Val(CellText(AnalysisValue(uid, 9)))
End Function

Public Function AnalysisSide(ByVal uid As String) As String
    If Val(CellText(AnalysisValue(uid, 8))) > 0 Then
        AnalysisSide = "W"
    ElseIf Val(CellText(AnalysisValue(uid, 9))) > 0 Then
        AnalysisSide = "D"
    End If
End Function

Public Function AnalysisDayBucket(ByVal dayNumber As Long, ByVal side As String) As Collection
    Dim key As String
    LoadAnalysisData: key = CStr(dayNumber) & ":" & side
    If mAnalysisDays.Exists(key) Then Set AnalysisDayBucket = mAnalysisDays(key) Else Set AnalysisDayBucket = New Collection
End Function

Public Function AnalysisAccountBucket(ByVal accountID As String, ByVal side As String) As Collection
    Dim key As String
    LoadAnalysisData: key = accountID & ":" & side
    If mAnalysisAccounts.Exists(key) Then Set AnalysisAccountBucket = mAnalysisAccounts(key) Else Set AnalysisAccountBucket = New Collection
End Function

Public Function AnalysisLowerBound(ByVal bucket As Collection, ByVal amount As Double) As Long
    Dim lo As Long, hi As Long, mid As Long
    lo = 1: hi = bucket.Count + 1
    Do While lo < hi
        mid = (lo + hi) \ 2
        If AnalysisAmount(CStr(bucket(mid))) < amount Then lo = mid + 1 Else hi = mid
    Loop
    AnalysisLowerBound = lo
End Function

Public Function AnalysisDateText(ByVal uid As String) As String
    Dim value As Variant
    If TryStoredDate(AnalysisValue(uid, 6), value) Then AnalysisDateText = Format$(CDate(value), "yyyy/m/d")
End Function

Public Function AnalysisTimeText(ByVal uid As String) As String
    Dim value As Variant
    value = AnalysisValue(uid, 7)
    If HasText(value) And IsNumeric(value) Then AnalysisTimeText = PreciseInputTimeText(value, AnalysisTimeGrain(uid)) Else AnalysisTimeText = "--:--"
End Function

Public Function AnalysisAccountText(ByVal uid As String) As String
    AnalysisAccountText = DisplayPersonWithRelationship(CellText(AnalysisValue(uid, 3)), CellText(AnalysisValue(uid, 14))) & " / " & _
        CellText(AnalysisValue(uid, 1)) & " " & CellText(AnalysisValue(uid, 2)) & " " & CellText(AnalysisValue(uid, 4)) & " " & CellText(AnalysisValue(uid, 5))
End Function

Public Function AnalysisChronology(ByVal firstID As String, ByVal secondID As String) As Long
    AnalysisChronology = CompareRecordedTimes(CDbl(AnalysisValue(firstID, 6)), AnalysisValue(firstID, 7), AnalysisTimeGrain(firstID), CDbl(AnalysisValue(secondID, 6)), AnalysisValue(secondID, 7), AnalysisTimeGrain(secondID))
End Function

Public Function AnalysisTimeGrain(ByVal uid As String) As Long
    Dim value As Variant
    value = AnalysisValue(uid, 7)
    AnalysisTimeGrain = RecordedTimeGrain(uid, value, mTimeGrains)
End Function

Public Function AnalysisVisibleIDs() As Object
    Dim result As Object, ws As Worksheet, visible As Range, area As Range, ids As Variant, r As Long, lastR As Long, firstR As Long
    Set result = CreateObject("Scripting.Dictionary")
    Set ws = GetSheet(SH_OUTPUT_TX): firstR = CashReportHeader(ws) + 1: lastR = LastRow(ws, REPORT_UID_COL)
    If lastR < firstR Then Set AnalysisVisibleIDs = result: Exit Function
    ids = ws.Cells(firstR, REPORT_UID_COL).Resize(Application.Max(2, lastR - firstR + 1), 1).Value2
    On Error Resume Next
    Set visible = ws.Range("A" & firstR & ":A" & lastR).SpecialCells(xlCellTypeVisible)
    On Error GoTo 0
    If Not visible Is Nothing Then
        For Each area In visible.Areas
            For r = area.Row To area.Row + area.Rows.Count - 1
                If HasText(ids(r - firstR + 1, 1)) Then result(CellText(ids(r - firstR + 1, 1))) = True
            Next r
        Next area
    End If
    Set AnalysisVisibleIDs = result
End Function

Public Function AnalysisSelectedIDs(ByVal target As Range) As Object
    Dim result As Object, area As Range, r As Long, lastR As Long, firstR As Long, uid As String, part As Range
    Set result = CreateObject("Scripting.Dictionary")
    firstR = CashReportHeader(target.Worksheet) + 1: lastR = LastRow(target.Worksheet, REPORT_UID_COL)
    If lastR < firstR Then Set AnalysisSelectedIDs = result: Exit Function
    Set part = Intersect(target, target.Worksheet.Range("A" & firstR & ":M" & lastR))
    If Not part Is Nothing Then
        For Each area In part.Areas
            For r = area.Row To area.Row + area.Rows.Count - 1
                If Not target.Worksheet.Rows(r).Hidden Then
                    uid = CellText(target.Worksheet.Cells(r, REPORT_UID_COL).Value2)
                    If Len(uid) > 0 Then result(uid) = True
                End If
            Next r
        Next area
    End If
    Set AnalysisSelectedIDs = result
End Function

Public Function AnalysisAggregates(ByVal mode As String, ByVal scope As Object) As Collection
    Dim result As New Collection, groups As Object, uid As Variant, key As String, item As Object, label As String
    Set groups = CreateObject("Scripting.Dictionary")
    For Each uid In scope.Keys
        Select Case mode
            Case "�l��": key = AnalysisPersonID(CStr(uid)): label = DisplayPersonWithRelationship(CellText(AnalysisValue(CStr(uid), 3)), CellText(AnalysisValue(CStr(uid), 14)))
            Case "��": key = Format$(CDbl(AnalysisValue(CStr(uid), 6)), "yyyy/mm"): label = key
            Case "�E�v": key = CellText(AnalysisValue(CStr(uid), 12)): label = key: If Len(label) = 0 Then label = "�E�v�Ȃ�"
            Case Else: key = CellText(AnalysisValue(CStr(uid), TX_ID_COL)): label = AnalysisAccountText(CStr(uid))
        End Select
        If Not groups.Exists(key) Then
            Set item = CreateObject("Scripting.Dictionary")
            item("key") = key: item("label") = label: item("count") = 0: item("out") = 0#: item("in") = 0#: item("ids") = ""
            groups.Add key, item: result.Add item
        End If
        Set item = groups(key)
        item("count") = CLng(item("count")) + 1
        item("out") = CDbl(item("out")) + Val(CellText(AnalysisValue(CStr(uid), 8)))
        item("in") = CDbl(item("in")) + Val(CellText(AnalysisValue(CStr(uid), 9)))
        item("ids") = CStr(item("ids")) & CStr(uid) & "|"
    Next uid
    Set AnalysisAggregates = result
End Function

Public Function AnalysisDataGeneration() As Long
    AnalysisDataGeneration = mDataGeneration
End Function

Attribute VB_Name = "modInputCapacity"
Option Explicit

Private Const CELL_INPUT_LAST_ROW As String = "X15"
Private Const INPUT_ROW_STEP As Long = 500
Private mInputLastRow As Long
Private mColumnDefaultsReady As Boolean

Public Function InputLastTransactionRow() As Long
    Dim v As Variant
    If mInputLastRow = 0 Then
        v = GetSheet(SH_INPUT).Range(CELL_INPUT_LAST_ROW).Value2
        mInputLastRow = TX_LAST_ROW
        If IsNumeric(v) Then
            If CDbl(v) >= TX_LAST_ROW And CDbl(v) <= GetSheet(SH_INPUT).Rows.Count Then mInputLastRow = CLng(v)
        End If
    End If
    InputLastTransactionRow = mInputLastRow
End Function

Public Sub ResetInputCapacityCache()
    mInputLastRow = 0
End Sub

Public Function InputTransactionRange() As Range
    Set InputTransactionRange = GetSheet(SH_INPUT).Range("B" & TX_FIRST_ROW & ":K" & InputLastTransactionRow())
End Function

Public Function InputEntryRange() As Range
    '���͂��󂯂�͈͂ƁA�r���E���͋K����p�ӂ����s���𕪂���B
    Set InputEntryRange = GetSheet(SH_INPUT).Range("B" & TX_FIRST_ROW & ":K" & GetSheet(SH_INPUT).Rows.Count)
End Function

Public Sub PrepareInputColumnDefaults(ByVal ws As Worksheet)
    Dim formats(1 To TX_HEADER_ROW, 1 To 10) As Variant, r As Long, c As Long, cell As Range
    If mColumnDefaultsReady Then Exit Sub
    '��̊��菑��������ݒ肷��B�S�s�̌r���E���͋K���͍쐬���Ȃ��B
    For r = 1 To TX_HEADER_ROW
        For c = 1 To 10: formats(r, c) = ws.Cells(r, c + 1).NumberFormat: Next c
    Next r
    ws.Columns("B:D").NumberFormat = "0"
    ws.Columns("E:E").NumberFormat = "@"
    ws.Columns("F:G").NumberFormat = "#,##0"
    ws.Columns("H:K").NumberFormat = "@"
    '�������E�c�����́A���ꂼ��̏�����ێ�����B
    For r = 1 To TX_HEADER_ROW
        For c = 1 To 10
            Set cell = ws.Cells(r, c + 1)
            If cell.MergeCells Then
                If cell.Address = cell.MergeArea.Cells(1, 1).Address Then cell.MergeArea.NumberFormat = formats(r, c)
            Else
                cell.NumberFormat = formats(r, c)
            End If
        Next c
    Next r
    mColumnDefaultsReady = True
End Sub

Public Sub ExtendInputForChange(ByVal target As Range)
    Dim body As Range, area As Range, hit As Range, last As Long, prepared As Long
    Set body = Intersect(target, InputEntryRange())
    If body Is Nothing Then Exit Sub
    prepared = InputLastTransactionRow(): last = prepared
    For Each area In body.Areas
        If area.Row + area.Rows.Count - 1 >= prepared Then
            Set hit = area.Find(What:="*", After:=area.Cells(1, 1), LookIn:=xlFormulas, LookAt:=xlPart, _
                               SearchOrder:=xlByRows, SearchDirection:=xlPrevious, MatchCase:=False, MatchByte:=False, SearchFormat:=False)
            If Not hit Is Nothing Then last = Application.Max(last, hit.Row + IIf(hit.Row < target.Worksheet.Rows.Count, 1, 0))
        End If
    Next area
    If last > prepared Then EnsureTransactionCapacity last - TX_FIRST_ROW + 1
End Sub

Public Function ChangedTransactionCells(ByVal target As Range) As Range
    Dim last As Long, area As Range, ws As Worksheet
    Set ws = GetSheet(SH_INPUT): last = InputLastTransactionRow()
    For Each area In target.Areas
        If area.Row + area.Rows.Count - 1 > last Then last = Application.Max(last, LastInputDataRow())
    Next area
    Set ChangedTransactionCells = Intersect(target, ws.Range("B" & TX_FIRST_ROW & ":K" & last))
End Function

Public Sub NormalizeEditedEntryValues(ByVal target As Range)
    Dim body As Range, part As Range, area As Range, cell As Range, raw As Variant, formats As Variant
    Dim r As Long, c As Long, value As Variant, parsed As Variant, fmt As String, timeColumn As Boolean, ok As Boolean
    Set body = ChangedTransactionCells(target)
    If body Is Nothing Then Exit Sub
    Set part = Intersect(body, target.Worksheet.Range("E:E,H:I"))
    If part Is Nothing Then Exit Sub
    For Each area In part.Areas
        If area.Cells.CountLarge = 1 Then
            ReDim raw(1 To 1, 1 To 1): raw(1, 1) = area.Value2
        Else
            raw = area.Value2
        End If
        For c = 1 To UBound(raw, 2)
            timeColumn = (area.Column + c - 1 = COL_TX_TIME)
            formats = area.Columns(c).NumberFormat
            If Not timeColumn And Not IsNull(formats) Then
                fmt = CStr(formats)
                If Len(fmt) <= 1 Or Len(Replace(fmt, "0", "")) <> 0 Then GoTo NextColumn
            End If
            For r = 1 To UBound(raw, 1)
                value = raw(r, c)
                If Not IsError(value) And Not IsNull(value) And Not IsEmpty(value) Then
                    If VarType(value) <> vbString And IsNumeric(value) Then
                        Set cell = area.Cells(r, c)
                        If Not cell.HasFormula Then
                            If timeColumn Then
                                If VarType(cell.Value) = vbDate Then
                                    parsed = NormalizeTimeInput(cell.Value, ok)
                                Else
                                    parsed = NormalizeTimeInput(value, ok)
                                End If
                                If ok And HasText(parsed) Then
                                    fmt = CStr(cell.NumberFormat)
                                    cell.NumberFormat = "@": cell.Value2 = PreciseInputTimeText(parsed, IIf(InStr(1, fmt, "ss", vbTextCompare) > 0, 1, InputTimeGrain(parsed)))
                                End If
                            Else
                                If IsNull(formats) Then fmt = CStr(cell.NumberFormat)
                                If Len(fmt) > 1 And Len(Replace(fmt, "0", "")) = 0 Then
                                    cell.NumberFormat = "@": cell.Value2 = Format$(CDbl(value), fmt)
                                End If
                            End If
                        End If
                    End If
                End If
            Next r
NextColumn:
        Next c
    Next area
End Sub

Public Sub RefreshEditedEntryStyle(ByVal target As Range)
    Dim body As Range, part As Range, area As Range, ws As Worksheet, message As String
    Set ws = target.Worksheet: Set body = ChangedTransactionCells(target)
    If body Is Nothing Then Exit Sub
    On Error GoTo EH
    ws.Unprotect Password:=TOOL_PASSWORD
    '�\�t�����̐F�E�ی�E���͋K������͗��֎����z���Ȃ��B�l�␔���͕ς��Ȃ��B
    body.Locked = False
    body.Font.Name = "Yu Gothic UI": body.Font.Size = 11
    body.Font.Color = RGB(15, 23, 42): body.Interior.Color = vbWhite
    Set part = Intersect(body, ws.Columns("B:D"))
    If Not part Is Nothing Then part.NumberFormat = "0"
    Set part = Intersect(body, ws.Range("E:E,H:K"))
    If Not part Is Nothing Then part.NumberFormat = "@"
    Set part = Intersect(body, ws.Columns("F:G"))
    If Not part Is Nothing Then part.NumberFormat = "#,##0"
    Set part = Intersect(body, ws.Columns("B:I"))
    If Not part Is Nothing Then
        For Each area In part.Areas: ApplyValidationInputOnly area, xlIMEModeOff: Next area
    End If
    Set part = Intersect(body, ws.Columns("J:J"))
    If Not part Is Nothing Then
        For Each area In part.Areas: ApplyValidationList area, NM_LST_TEKIYO, xlIMEModeHiragana, True: Next area
    End If
    Set part = Intersect(body, ws.Columns("K:K"))
    If Not part Is Nothing Then
        For Each area In part.Areas: ApplyValidationInputOnly area, xlIMEModeHiragana: Next area
    End If
    ProtectInputSheet
    Exit Sub
EH:
    message = Err.Description
    On Error Resume Next
    ProtectInputSheet
    On Error GoTo 0
    Err.Raise vbObjectError + 2903, "RefreshEditedEntryStyle", "�\��t�����l�͎c���Ă��܂��B���͗��̕\���X�V�������ł��܂���ł����B" & vbCrLf & message
End Sub

Public Function LastInputDataRow() As Long
    Dim hit As Range
    Set hit = InputEntryRange().Find(What:="*", After:=GetSheet(SH_INPUT).Cells(TX_FIRST_ROW, COL_TX_YEAR), _
        LookIn:=xlFormulas, LookAt:=xlPart, SearchOrder:=xlByRows, SearchDirection:=xlPrevious, MatchCase:=False, MatchByte:=False, SearchFormat:=False)
    LastInputDataRow = TX_FIRST_ROW - 1
    If Not hit Is Nothing Then LastInputDataRow = hit.Row
End Function

Public Sub EnsureTransactionCapacity(ByVal requiredCount As Long)
    Dim appStarted As Boolean
    Dim ws As Worksheet, oldLast As Long, newLast As Long, maxCount As Long
    Dim message As String, started As Boolean
    Set ws = GetSheet(SH_INPUT)
    oldLast = InputLastTransactionRow()
    If requiredCount <= oldLast - TX_FIRST_ROW + 1 Then Exit Sub
    maxCount = ws.Rows.Count - TX_FIRST_ROW + 1
    If requiredCount > maxCount Then Err.Raise vbObjectError + 2901, , "Excel�̍s���𒴂��邽�߁A����ȏ㖾�ׂ�ǉ��ł��܂���B"
    newLast = TX_FIRST_ROW - 1 + Application.Min(maxCount, ((requiredCount + INPUT_ROW_STEP - 1) \ INPUT_ROW_STEP) * INPUT_ROW_STEP)
    On Error GoTo EH
    AppBegin "���ח����L���Ă��܂�..."
    appStarted = True
    started = True
    ws.Unprotect Password:=TOOL_PASSWORD
    FormatAdditionalInputRows ws, oldLast + 1, newLast
    ws.ScrollArea = "A:K"
    ws.Range(CELL_INPUT_LAST_ROW).Value2 = newLast
    mInputLastRow = newLast
    ProtectInputSheet
    EndAppScope appStarted
    Exit Sub
EH:
    message = Err.Description
    On Error Resume Next
    ProtectInputSheet
    On Error GoTo 0
    If started Then EndAppScope appStarted
    Err.Raise vbObjectError + 2902, "EnsureTransactionCapacity", "���ח���ǉ��ł��܂���ł����B���͍ς݂̓��e�͎c���Ă��܂��B" & vbCrLf & message
End Sub

Private Sub FormatAdditionalInputRows(ByVal ws As Worksheet, ByVal firstRow As Long, ByVal lastRow As Long)
    Dim body As Range
    Set body = ws.Range("B" & firstRow & ":K" & lastRow)
    With body
        .Font.Name = "Yu Gothic UI": .Font.Size = 11: .Font.Color = RGB(15, 23, 42)
        .Interior.Color = vbWhite: .WrapText = False: .Locked = False
        .Borders.LineStyle = xlContinuous: .Borders.Color = RGB(226, 232, 240)
        .NumberFormat = "General"
    End With
    ws.Rows(firstRow & ":" & lastRow).RowHeight = 25
    ws.Range("B" & firstRow & ":D" & lastRow).NumberFormat = "0"
    ws.Range("E" & firstRow & ":E" & lastRow).NumberFormat = "@"
    ws.Range("F" & firstRow & ":G" & lastRow).NumberFormat = "#,##0"
    ws.Range("F" & firstRow & ":G" & lastRow).ShrinkToFit = True
    ws.Range("B" & firstRow & ":E" & lastRow).HorizontalAlignment = xlCenter
    ws.Range("F" & firstRow & ":G" & lastRow).HorizontalAlignment = xlRight
    ws.Range("H" & firstRow & ":K" & lastRow).HorizontalAlignment = xlLeft
    ws.Range("H" & firstRow & ":K" & lastRow).NumberFormat = "@"
    ApplyValidationInputOnly ws.Range("B" & firstRow & ":G" & lastRow), xlIMEModeOff
    ApplyValidationInputOnly ws.Range("H" & firstRow & ":I" & lastRow), xlIMEModeOff
    ApplyValidationList ws.Range("J" & firstRow & ":J" & lastRow), NM_LST_TEKIYO, xlIMEModeHiragana, True
    ApplyValidationInputOnly ws.Range("K" & firstRow & ":K" & lastRow), xlIMEModeHiragana
End Sub

Public Sub AddTransactionInputRows()
    Dim message As String
    On Error GoTo EH
    EnsureTransactionCapacity InputLastTransactionRow() - TX_FIRST_ROW + 1 + INPUT_ROW_STEP
    Exit Sub
EH:
    message = Err.Description
    MsgBox message, vbExclamation
End Sub

Public Sub GoToTransactionEnd()
    Dim r As Long, ws As Worksheet, message As String
    On Error GoTo EH
    Set ws = GetSheet(SH_INPUT)
    r = LastInputDataRow() + 1
    EnsureTransactionCapacity r - TX_FIRST_ROW + 1
    SafeSelectCell ws, ws.Cells(r, IIf(r = TX_FIRST_ROW, COL_TX_YEAR, COL_TX_DAY)).Address
    Exit Sub
EH:
    message = Err.Description
    MsgBox message, vbExclamation
End Sub

Public Sub CopyPreviousDescription()
    Dim ws As Worksheet, values As Variant, r As Long, s As String, message As String
    On Error GoTo EH
    If Not ActiveWorkbook Is ThisWorkbook Then Exit Sub
    Set ws = GetSheet(SH_INPUT)
    If Not ActiveSheet Is ws Then Exit Sub
    If ActiveCell.Row <= TX_FIRST_ROW Or ActiveCell.Row > InputLastTransactionRow() Then Exit Sub
    values = ws.Range("J" & TX_FIRST_ROW & ":J" & ActiveCell.Row - 1).Value2
    If Not IsArray(values) Then
        s = CellText(values)
    Else
        For r = UBound(values, 1) To 1 Step -1
            s = CellText(values(r, 1))
            If Len(s) > 0 And s <> "����" Then Exit For
        Next r
    End If
    If Len(s) = 0 Or s = "����" Then Exit Sub
    ws.Cells(ActiveCell.Row, COL_TX_TEKIYO).Value2 = s
    SafeSelectCell ws, ws.Cells(ActiveCell.Row, COL_TX_TEKIYO).Address
    Exit Sub
EH:
    message = Err.Description
    MsgBox message, vbExclamation
End Sub

Public Sub FitEmptyTransactionCapacity(ByVal requiredCount As Long)
    Dim ws As Worksheet, desired As Long, oldLast As Long
    Set ws = GetSheet(SH_INPUT)
    oldLast = InputLastTransactionRow()
    desired = Application.Max(TX_LAST_ROW, TX_FIRST_ROW - 1 + ((requiredCount + INPUT_ROW_STEP - 1) \ INPUT_ROW_STEP) * INPUT_ROW_STEP)
    If desired >= oldLast Then Exit Sub
    '�����ؑցE���׏����ŋ�ɂȂ������͗��������k�߂�B
    ws.Range(CELL_INPUT_LAST_ROW).Value2 = desired
    mInputLastRow = desired
    ws.ScrollArea = "A:K"
End Sub

Attribute VB_Name = "modPeople"
Option Explicit

Private Const SH_PEOPLE As String = "W_�l������"
Private mPeople As Object

Private Sub LoadPeople()
    Dim data As Variant, accounts As Variant, previous As Object, groups As Object, nextPeople As Object
    Dim key As String, aid As String, r As Long, changed As Boolean, entry As Variant, oldEntry As Variant
    On Error GoTo EH
    If Not mPeople Is Nothing Then Exit Sub
    Set previous = CreateObject("Scripting.Dictionary")
    Set groups = CreateObject("Scripting.Dictionary"): Set nextPeople = CreateObject("Scripting.Dictionary")
    If SheetExists(SH_PEOPLE) Then
        data = ReadStore(GetSheet(SH_PEOPLE), 3)
        For r = 2 To UBound(data, 1)
            If HasText(data(r, 1)) Then previous(CellText(data(r, 1))) = Array(CellText(data(r, 2)), CellText(data(r, 3)))
        Next r
    End If
    accounts = ReadStore(GetSheet(SH_ACCOUNTS), 10)
    For r = 2 To UBound(accounts, 1)
        aid = CellText(accounts(r, 1))
        If Len(aid) > 0 Then
            If previous.Exists(aid) Then
                entry = previous(aid)
                If CStr(entry(1)) = "�蓮" And Len(CStr(entry(0))) > 0 Then
                    nextPeople(aid) = entry
                    GoTo NextAccount
                End If
            End If
            key = AutomaticPersonKey(accounts, r)
            If Not groups.Exists(key) Then
                groups(key) = aid
            ElseIf StrComp(aid, CStr(groups(key)), vbBinaryCompare) < 0 Then
                groups(key) = aid
            End If
        End If
NextAccount:
    Next r
    For r = 2 To UBound(accounts, 1)
        aid = CellText(accounts(r, 1))
        If Len(aid) > 0 And Not nextPeople.Exists(aid) Then
            key = AutomaticPersonKey(accounts, r)
            nextPeople(aid) = Array("U_AUTO_" & CStr(groups(key)), "����")
        End If
        If Len(aid) > 0 Then
            entry = nextPeople(aid)
            If previous.Exists(aid) Then
                oldEntry = previous(aid)
                If CStr(entry(0)) <> CStr(oldEntry(0)) Or CStr(entry(1)) <> CStr(oldEntry(1)) Then changed = True
            Else
                changed = True
            End If
        End If
    Next r
    If previous.Count <> nextPeople.Count Then changed = True
    Set mPeople = nextPeople
    If changed Then StorePeople
    Exit Sub
EH:
    Dim message As String
    message = Err.Description
    ResetPeopleCache
    Err.Raise vbObjectError + 3510, "LoadPeople", message
End Sub

Private Function AutomaticPersonKey(ByVal accounts As Variant, ByVal row As Long) As String
    If HasText(accounts(row, 4)) Then
        AutomaticPersonKey = "N" & Chr$(30) & CellText(accounts(row, 4)) & Chr$(30) & CellText(accounts(row, 5))
    Else
        AutomaticPersonKey = "A" & Chr$(30) & CellText(accounts(row, 1))
    End If
End Function

Private Sub StorePeople()
    Dim ws As Worksheet, data As Variant, previous As Variant, aid As Variant, entry As Variant, r As Long
    Dim started As Boolean, writing As Boolean, message As String
    On Error GoTo EH
    Set ws = GetOrCreateSheet(SH_PEOPLE, False)
    previous = ReadStore(ws, 3)
    ReDim data(1 To mPeople.Count + 1, 1 To 3)
    data(1, 1) = "����ID": data(1, 2) = "�l��ID": data(1, 3) = "�܂Ƃߕ�"
    r = 1
    For Each aid In mPeople.Keys
        r = r + 1: entry = mPeople(aid)
        data(r, 1) = CStr(aid): data(r, 2) = entry(0): data(r, 3) = entry(1)
    Next aid
    AppBegin "", False: started = True
    ws.Columns("A:C").NumberFormat = "@": writing = True
    WriteStore ws, data
    writing = False
    ws.Visible = xlSheetVeryHidden
    MarkFileNeedsSave
    EndAppScope started
    Exit Sub
EH:
    message = Err.Description
    On Error Resume Next
    If writing Then
        Err.Clear: WriteStore ws, previous
        If Err.Number <> 0 Then message = message & vbCrLf & "�l���Ή��̕������������ł��F" & Err.Description
    End If
    ResetPeopleCache
    EndAppScope started
    On Error GoTo 0
    Err.Raise vbObjectError + 3511, "StorePeople", message
End Sub

Public Sub ResetPeopleCache()
    Set mPeople = Nothing
End Sub

Public Function AnalysisPersonID(ByVal uid As String) As String
    AnalysisPersonID = AccountPersonID(CellText(AnalysisValue(uid, TX_ID_COL)))
End Function

Public Function AccountPersonID(ByVal aid As String) As String
    Dim entry As Variant
    LoadPeople
    If mPeople.Exists(aid) Then entry = mPeople(aid): AccountPersonID = CStr(entry(0)) Else AccountPersonID = aid
End Function

Public Sub GroupSelectedPeople()
    SetSelectedPeople False
End Sub

Public Sub SeparateSelectedPeople()
    SetSelectedPeople True
End Sub

Private Sub SetSelectedPeople(ByVal separate As Boolean)
    Dim accounts As Object, aid As Variant, personID As String
    On Error GoTo EH
    LoadPeople: Set accounts = PanelSelectedAccountIDs()
    If accounts.Count = 0 Then AnalysisPanelMessage "��������\�őΏی����̖��ׂ�I�����Ă��������B": Exit Sub
    If Not separate And accounts.Count < 2 Then AnalysisPanelMessage "�܂Ƃ߂������2�ȏ�I�����Ă��������iCtrl�Œǉ��I���j�B": Exit Sub
    personID = NewInternalID("U")
    For Each aid In accounts.Keys
        If separate Then personID = NewInternalID("U")
        mPeople(CStr(aid)) = Array(personID, "�蓮")
    Next aid
    StorePeople
    InvalidateOutputViews
    ShowAnalysisPeople
    Exit Sub
EH:
    ResetPeopleCache
    AnalysisPanelMessage "�l���̂܂Ƃߕ���ۑ��ł��܂���ł����B" & Err.Description
End Sub

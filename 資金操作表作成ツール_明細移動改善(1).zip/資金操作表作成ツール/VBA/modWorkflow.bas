Attribute VB_Name = "modWorkflow"
Option Explicit

Public Sub InvalidateOutputViews(Optional ByVal cashOnly As Boolean = False)
    Dim ws As Worksheet, current As String
    Set ws = GetSheet(SH_INPUT)
    InvalidateAnalysisData
    MarkFileNeedsSave
    current = CellText(ws.Range("X7").Value2)
    If cashOnly Then
        If current = "0" Then ws.Range("X7").Value2 = "2"
    ElseIf current <> "1" Then
        ws.Range("X7").Value2 = "1"
    End If
End Sub

Public Sub ApplySettingsAndReturn()
    Dim appStarted As Boolean
    On Error GoTo EH
    AppBegin "�ݒ�𔽉f���Ă��܂�..."
    appStarted = True
    BuildBalanceInputFields False
    BuildOperationPanel GetSheet(SH_INPUT)
    ResetInputNavigation
    ShowInputSheet
    EndAppScope appStarted
    Exit Sub
EH:
    Dim originalErrorText As String
    originalErrorText = Err.Description
    EndAppScope appStarted
    MsgBox "�ݒ�𔽉f�ł��܂���ł����B" & vbCrLf & originalErrorText, vbExclamation
End Sub

Public Sub OpenShopNames()
    Dim appStarted As Boolean
    If Not RequireToolReady() Then Exit Sub
    On Error GoTo EH
    AppBegin "�戵�X��\�����Ă��܂�..."
    appStarted = True
    EnsureCurrentOutputs
    GetSheet(SH_SHOP_TARGET).Activate
    EndAppScope appStarted
    Exit Sub
EH:
    Dim originalErrorText As String
    originalErrorText = Err.Description
    EndAppScope appStarted
    MsgBox originalErrorText, vbExclamation
End Sub

Public Sub ApplyShopNamesToOutput(Optional ByVal destination As Worksheet = Nothing, Optional ByVal mappingSheet As Worksheet = Nothing)
    Dim ws As Worksheet, target As Worksheet, map As Object, r As Long, key As String, s As String
    Dim mappings As Variant, source As Variant, shops As Variant, count As Long, changed As Boolean, firstR As Long
    If destination Is Nothing Then Set ws = GetSheet(SH_OUTPUT_TX) Else Set ws = destination
    If mappingSheet Is Nothing Then Set target = GetSheet(SH_SHOP_TARGET) Else Set target = mappingSheet
    Set map = CreateObject("Scripting.Dictionary")
    mappings = ReadStore(target, 8)
    For r = 2 To UBound(mappings, 1)
        s = CellText(mappings(r, SHOP_TGT_COL_RESULT))
        If Len(s) > 0 And CellText(mappings(r, SHOP_TGT_COL_STATUS)) <> "�ۗ�" Then
            key = CellText(mappings(r, SHOP_TGT_COL_BANK)) & Chr$(30) & NormalizeShopCodeText(CellText(mappings(r, SHOP_TGT_COL_CODE)))
            map(key) = s
        End If
    Next r
    If map.Count = 0 Then Exit Sub
    firstR = CashReportHeader(ws) + 1
    count = LastRow(ws, 6) - firstR + 1
    If count < 1 Then Exit Sub
    source = ws.Cells(firstR, 1).Resize(count, 13).Value2
    ReDim shops(1 To count, 1 To 1)
    For r = 1 To count
        shops(r, 1) = source(r, OUT_COL_SHOP)
        s = CellText(source(r, OUT_COL_SHOP))
        If IsCodeLikeShop(s) Then
            key = CellText(source(r, OUT_COL_BANK)) & Chr$(30) & NormalizeShopCodeText(s)
            If map.Exists(key) Then shops(r, 1) = map(key): changed = True
        End If
    Next r
    If changed Then ws.Cells(firstR, OUT_COL_SHOP).Resize(count, 1).Value2 = shops
End Sub


Public Sub EnsureCurrentOutputs()
    Dim dirty As String
    dirty = CellText(GetSheet(SH_INPUT).Range("X7").Value2)
    If dirty <> "0" Then RefreshAllOutputs (dirty = "2")
    If GetSheet(SH_OUTPUT_TX).Visible <> xlSheetVisible Then GetSheet(SH_OUTPUT_TX).Visible = xlSheetVisible
    If GetSheet(SH_OUTPUT_BAL).Visible <> xlSheetVisible Then GetSheet(SH_OUTPUT_BAL).Visible = xlSheetVisible
    If GetSheet(SH_SHOP_TARGET).Visible <> xlSheetVisible Then GetSheet(SH_SHOP_TARGET).Visible = xlSheetVisible
End Sub

Public Sub ProtectGeneratedOutput(ByVal ws As Worksheet)
    ws.Protect Password:=TOOL_PASSWORD, UserInterfaceOnly:=True, DrawingObjects:=True, AllowFiltering:=True
    ws.EnableSelection = xlNoRestrictions
End Sub

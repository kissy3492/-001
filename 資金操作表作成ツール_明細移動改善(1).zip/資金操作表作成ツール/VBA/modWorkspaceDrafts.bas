Attribute VB_Name = "modWorkspaceDrafts"
Option Explicit

Public Const SH_PARKED_DRAFTS As String = "W_������"
Public Const CELL_DRAFT_KEY As String = "X17"
Private mPosition As String
Private mScrollRow As Long
Private mScrollColumn As Long

Public Sub EnsureParkedDraftStore()
    Dim ws As Worksheet
    Set ws = GetOrCreateSheet(SH_PARKED_DRAFTS, False)
    If Not HasText(ws.Cells(1, 1).Value2) Then
        SetRowValues ws.Cells(1, 1), Array("������ID", "���e", "�s", "�l1", "�l2", "�l3", "�l4", "�l5", "�l6", "�l7", "�l8", "�l9", "�l10", "����ID")
        ws.Columns("A:N").NumberFormat = "@"
    End If
    ws.Visible = xlSheetVeryHidden
End Sub

Public Function CurrentDraftKey() As String
    CurrentDraftKey = CurrentEditAccountID()
    If Len(CurrentDraftKey) = 0 Then CurrentDraftKey = CellText(GetSheet(SH_INPUT).Range(CELL_DRAFT_KEY).Value2)
End Function

Public Function ParkedDraftData() As Variant
    EnsureParkedDraftStore
    ParkedDraftData = ReadStore(GetSheet(SH_PARKED_DRAFTS), 14)
End Function

Public Function DraftHeaderRows(ByVal data As Variant) As Object
    Dim result As Object, r As Long
    Set result = CreateObject("Scripting.Dictionary")
    For r = 2 To UBound(data, 1)
        If CellText(data(r, 2)) = "����" Then result(CellText(data(r, 1))) = r
    Next r
    Set DraftHeaderRows = result
End Function

Public Sub RememberInputPosition(ByVal target As Range)
    If target Is Nothing Then Exit Sub
    If target.Worksheet.Name <> SH_INPUT Then Exit Sub
    mPosition = target.Cells(1, 1).Address(False, False)
    If ActiveSheet.Name = SH_INPUT Then
        mScrollRow = ActiveWindow.ScrollRow: mScrollColumn = ActiveWindow.ScrollColumn
    End If
End Sub

Public Function DraftAccountMemos(ByVal data As Variant) As Object
    Dim result As Object, r As Long
    Set result = CreateObject("Scripting.Dictionary")
    For r = 2 To UBound(data, 1)
        If CellText(data(r, 2)) = "���" And CellText(data(r, 3)) = "1" Then
            '���1��4�Ԗڂ͌��������iX4�j�B�󗓂ւ̒������㏑���Ώۂɂ���B
            result(CellText(data(r, 1))) = data(r, 7)
        End If
    Next r
    Set DraftAccountMemos = result
End Function

Public Sub FlushInputPosition()
    Dim ws As Worksheet
    Set ws = GetSheet(SH_INPUT)
    If Len(mPosition) = 0 Then Exit Sub
    ws.Range("X18").Value2 = mPosition
    ws.Range("X19").Value2 = mScrollRow
    ws.Range("X20").Value2 = mScrollColumn
End Sub

Public Sub ResumeInputPosition()
    Dim ws As Worksheet, target As Range, r As Long, c As Long, addressText As String
    Set ws = GetSheet(SH_INPUT)
    addressText = CellText(ws.Range("X18").Value2)
    mPosition = ""
    If Len(addressText) = 0 Then Exit Sub
    On Error GoTo Done
    Set target = ws.Range(addressText)
    If target.Cells.CountLarge <> 1 Then Exit Sub
    If target.Column < 2 Or target.Column > 11 Then Exit Sub
    If target.Row > InputLastTransactionRow() Then Exit Sub
    SafeSelectCell ws, target.Address
    r = CLng(Val(CellText(ws.Range("X19").Value2)))
    c = CLng(Val(CellText(ws.Range("X20").Value2)))
    If r >= TX_FIRST_ROW And r <= InputLastTransactionRow() Then ActiveWindow.ScrollRow = r
    If c >= 1 And c <= 11 Then ActiveWindow.ScrollColumn = c
    RememberInputPosition target
Done:
End Sub

Public Sub ParkCurrentInput()
    Dim appStarted As Boolean, state As Collection, data As Variant, block As Variant, nextData As Variant
    Dim key As String, headers As Object, k As Variant, n As Long, message As String
    On Error GoTo EH
    ReconcileInputFormulaState
    If Not InputIsDirty Then Exit Sub
    AppBegin
    appStarted = True
    data = ParkedDraftData()
    key = CurrentDraftKey()
    If Len(key) = 0 Then
        key = NewInternalID("N")
        GetSheet(SH_INPUT).Range(CELL_DRAFT_KEY).Value2 = key
        AdoptInputHistoryDraftKey
    End If
    Set state = CaptureInputState()
    block = EncodeParkedState(key, state)
    n = UBound(block, 1)
    nextData = ReplaceAccountRows(data, block, n, 1, key)
    WriteDraftData nextData, data
    EndAppScope appStarted
    Exit Sub
EH:
    message = Err.Description
    EndAppScope appStarted
    Err.Raise vbObjectError + 3101, "ParkCurrentInput", "���͓r����ێ��ł��Ȃ��������߁A�����̐؂�ւ����~�߂܂����B���݂̓��͎͂c���Ă��܂��B" & vbCrLf & message
End Sub

Private Sub WriteDraftData(ByVal nextData As Variant, ByVal oldData As Variant)
    Dim message As String
    On Error GoTo EH
    If SameDraftData(nextData, oldData) Then Exit Sub
    WriteStore GetSheet(SH_PARKED_DRAFTS), nextData
    MarkFileNeedsSave
    Exit Sub
EH:
    message = Err.Description
    On Error Resume Next
    Err.Clear
    WriteStore GetSheet(SH_PARKED_DRAFTS), oldData
    If Err.Number <> 0 Then message = message & vbCrLf & "�������̕������������ł��B�ۑ��ς݂̃u�b�N����ĊJ���Ă��������B"
    On Error GoTo 0
    Err.Raise vbObjectError + 3102, "WriteDraftData", message
End Sub

Public Sub RemoveParkedDraft(ByVal key As String)
    Dim data As Variant, nextData As Variant, noRows As Variant, headers As Object
    If Len(key) = 0 Then Exit Sub
    data = ParkedDraftData(): Set headers = DraftHeaderRows(data)
    If Not headers.Exists(key) Then Exit Sub
    nextData = ReplaceAccountRows(data, noRows, 0, 1, key)
    WriteDraftData nextData, data
End Sub

Private Function ReadParkedState(ByVal key As String) As Collection
    Set ReadParkedState = DecodeParkedState(ParkedDraftData(), key, GetSheet(SH_INPUT).Range("X1:X20").Value2)
End Function

Public Function DecodeParkedState(ByVal data As Variant, ByVal key As String, ByVal currentMetadata As Variant) As Collection
    Dim r As Long, c As Long, i As Long, txCount As Long, balanceCount As Long
    Dim values(0 To 7) As Variant, meta(1 To 20, 1 To 1) As Variant, tx As Variant, balances As Variant
    Dim result As New Collection, found As Boolean, bookmark As String, accountBase As Variant, balanceBase As Variant, baseCount As Long
    Dim formulas As Object
    Set formulas = CreateObject("Scripting.Dictionary")
    accountBase = EmptyAccountBaseline()
    For r = 2 To UBound(data, 1)
        If CellText(data(r, 1)) = key Then
            Select Case CellText(data(r, 2))
                Case "����"
                    found = True
                    For c = 0 To 7: values(c) = data(r, c + 4): Next c
                Case "������": bookmark = CellText(data(r, 4))
                Case "����": formulas(CellText(data(r, 3))) = Array(data(r, 4), CellText(data(r, 5)), CLng(Val(CellText(data(r, 6)))), CellText(data(r, 7)))
                Case "�J�n����"
                    For c = 1 To 10: accountBase(1, c) = data(r, c + 3): Next c
                Case "�J�n�c��": baseCount = Application.Max(baseCount, CLng(data(r, 3)))
                Case "���"
                    i = CLng(data(r, 3))
                    For c = 1 To 10: meta((i - 1) * 10 + c, 1) = data(r, c + 3): Next c
                Case "����": txCount = Application.Max(txCount, CLng(data(r, 3)))
                Case "�c��": balanceCount = Application.Max(balanceCount, CLng(data(r, 3)))
            End Select
        End If
    Next r
    If Not found Then Exit Function
    ReDim tx(1 To Application.Max(1, txCount), 1 To 11)
    ReDim balances(1 To Application.Max(1, balanceCount), 1 To 3)
    ReDim balanceBase(1 To Application.Max(1, baseCount), 1 To 3)
    For r = 2 To UBound(data, 1)
        If CellText(data(r, 1)) = key Then
            If CellText(data(r, 2)) = "����" Then
                For c = 1 To 11: tx(CLng(data(r, 3)), c) = data(r, c + 3): Next c
            ElseIf CellText(data(r, 2)) = "�c��" Then
                For c = 1 To 3: balances(CLng(data(r, 3)), c) = data(r, c + 3): Next c
            ElseIf CellText(data(r, 2)) = "�J�n�c��" Then
                For c = 1 To 3: balanceBase(CLng(data(r, 3)), c) = data(r, c + 3): Next c
            End If
        End If
    Next r
    '���[�̍X�V��ԂƉ�ʂ̐���E�E�v�����́A������؂�ւ��Ċ����߂��Ȃ��B
    meta(7, 1) = currentMetadata(7, 1)
    meta(14, 1) = currentMetadata(14, 1)
    meta(16, 1) = currentMetadata(16, 1)
    result.Add values, "fields": result.Add tx, "transactions"
    result.Add meta, "metadata": result.Add balances, "balances"
    result.Add bookmark, "bookmark"
    result.Add accountBase, "accountBase": result.Add balanceBase, "balanceBase"
    result.Add formulas, "formulas"
    Set DecodeParkedState = result
End Function

Public Sub OpenAccountOrDraft(ByVal key As String, Optional ByVal appendMode As Boolean = False)
    Dim state As Collection, previous As Collection, appStarted As Boolean, changing As Boolean, message As String
    On Error GoTo EH
    If key = CurrentDraftKey() Then
        ShowInputSheet
        If appendMode Then GoToTransactionEnd Else ResumeInputPosition
        Exit Sub
    End If
    AppBegin "���͂�؂�ւ��Ă��܂�..."
    appStarted = True
    ParkCurrentInput
    Set previous = CaptureInputState()
    Set state = ReadParkedState(key)
    If state Is Nothing Then
        If Not LoadAccountForEdit(key, appendMode) Then EndAppScope appStarted: Exit Sub
    Else
        changing = True
        RestoreInputState state
        ShowInputSheet
        If appendMode Then GoToTransactionEnd Else ResumeInputPosition
        changing = False
    End If
    ClearInputUndo
    EndAppScope appStarted
    Exit Sub
EH:
    message = Err.Description
    On Error Resume Next
    If changing Then
        Err.Clear
        RestoreInputState previous
        If Err.Number <> 0 Then message = message & vbCrLf & "���͉�ʂ̕������������ł��B�����ʂ̉������͕ێ����Ă��܂��B"
    End If
    EndAppScope appStarted
    On Error GoTo 0
    MsgBox "���͂�؂�ւ����܂���ł����B" & vbCrLf & message, vbExclamation
End Sub

Public Sub StartAnotherAccount()
    Dim appStarted As Boolean, message As String, switched As Boolean
    On Error GoTo EH
    AppBegin
    appStarted = True
    ParkCurrentInput
    ClearInputForNextAccount GetPostTransferKeepPolicy(), True, True
    switched = True
    ShowInputSheet
    FocusAfterPostTransferCleanup GetPostTransferKeepPolicy()
    EndAppScope appStarted
    Exit Sub
EH:
    message = Err.Description
    Resume Recover
Recover:
    On Error Resume Next
    EndAppScope appStarted
    On Error GoTo 0
    If switched Then
        message = "�V���������ւ̐ؑւ͊������܂����B��ʂ��ĕ\�����Ă��������B" & vbCrLf & message
    Else
        message = "�V���������֐؂�ւ����܂���ł����B" & vbCrLf & message
    End If
    MsgBox message, vbExclamation
End Sub


Public Sub ResetRememberedPosition()
    mPosition = "": mScrollRow = 0: mScrollColumn = 0
End Sub

Public Sub DeleteUnregisteredDraft(ByVal key As String)
    Dim appStarted As Boolean, state As Collection, changed As Boolean, committed As Boolean, message As String
    Dim drafts As Variant, writing As Boolean, restoring As String
    On Error GoTo EH
    If MsgBox("�I�������V�K�����̓��͓r���̓��e���폜���܂����H", vbYesNo + vbExclamation + vbDefaultButton2, "�������̍폜") <> vbYes Then Exit Sub
    AppBegin
    appStarted = True
    drafts = ParkedDraftData()
    If CurrentDraftKey() = key Then
        Set state = CaptureInputState(): changed = True
        ClearInputForNextAccount KEEP_NONE, True, True, True
    End If
    writing = True
    RemoveParkedDraft key
    committed = True
    If changed Then ClearInputUndo
    ShowRegisteredAccounts
    EndAppScope appStarted
    Exit Sub
EH:
    message = Err.Description
    Resume Recover
Recover:
    On Error Resume Next
    If writing And Not committed Then
        Err.Clear
        WriteStore GetSheet(SH_PARKED_DRAFTS), drafts
        If Err.Number <> 0 Then restoring = " ������"
    End If
    If changed And Not committed Then
        Err.Clear
        RestoreInputState state
        If Err.Number <> 0 Then restoring = restoring & " ���͉��"
    End If
    If Len(restoring) > 0 Then ClearInputUndo
    Err.Clear
    ProtectInputSheet
    If Err.Number <> 0 Then message = message & vbCrLf & "���͉�ʂ̕ی��߂��܂���ł����B"
    EndAppScope appStarted
    On Error GoTo 0
    If Len(restoring) > 0 Then
        message = "�����������F" & restoring & "�B�㏑�������ۑ��ς݃u�b�N����m�F���Ă��������B" & vbCrLf & message
    ElseIf committed Then
        message = "�������̍폜�͊������܂����B�o�^�����̈ꗗ���ĕ\�����Ă��������B" & vbCrLf & message
    Else
        message = "���������폜�ł��܂���ł����B�폜�O�̓��͂Ɖ�������ێ����Ă��܂��B" & vbCrLf & message
    End If
    MsgBox message, vbExclamation
End Sub

Public Function SameDraftData(ByVal leftData As Variant, ByVal rightData As Variant) As Boolean
    Dim r As Long, c As Long
    If UBound(leftData, 1) <> UBound(rightData, 1) Then Exit Function
    If UBound(leftData, 2) <> UBound(rightData, 2) Then Exit Function
    For r = 1 To UBound(leftData, 1)
        For c = 1 To UBound(leftData, 2)
            If Not InputValuesEqual(leftData(r, c), rightData(r, c)) Then Exit Function
        Next c
    Next r
    SameDraftData = True
End Function

Public Function HasParkedInputs() As Boolean
    Dim data As Variant, headers As Object
    data = ParkedDraftData(): Set headers = DraftHeaderRows(data)
    HasParkedInputs = (headers.Count > 0)
End Function

Public Function EncodeParkedState(ByVal key As String, ByVal state As Collection) As Variant
    Dim values As Variant, tx As Variant, balances As Variant, meta As Variant, block As Variant, accountBase As Variant, balanceBase As Variant
    Dim r As Long, c As Long, i As Long, n As Long, formulas As Object, keyCell As Variant, token As Variant
    Set formulas = StateInputFormulas(state)
    values = state("fields"): tx = state("transactions"): balances = state("balances"): meta = state("metadata")
    accountBase = StateAccountBaseline(state): balanceBase = StateBalanceBaseline(state)
    ReDim block(1 To 5 + UBound(tx, 1) + UBound(balances, 1) + UBound(balanceBase, 1) + formulas.Count, 1 To 14)
    block(1, 2) = "����"
    For c = 0 To 7: block(1, c + 4) = values(c): Next c
    For i = 1 To 2
        block(i + 1, 2) = "���": block(i + 1, 3) = i
        For c = 1 To 10: block(i + 1, c + 3) = meta((i - 1) * 10 + c, 1): Next c
    Next i
    n = 3
    For r = 1 To UBound(tx, 1)
        n = n + 1: block(n, 2) = "����": block(n, 3) = r
        For c = 1 To UBound(tx, 2): block(n, c + 3) = tx(r, c): Next c
    Next r
    For r = 1 To UBound(balances, 1)
        n = n + 1: block(n, 2) = "�c��": block(n, 3) = r
        For c = 1 To 3: block(n, c + 3) = balances(r, c): Next c
    Next r
    n = n + 1: block(n, 2) = "�J�n����"
    For c = 1 To 10: block(n, c + 3) = accountBase(1, c): Next c
    For r = 1 To UBound(balanceBase, 1)
        n = n + 1: block(n, 2) = "�J�n�c��": block(n, 3) = r
        For c = 1 To 3: block(n, c + 3) = balanceBase(r, c): Next c
    Next r
    n = n + 1: block(n, 2) = "������": block(n, 4) = StateBookmark(state)
    For Each keyCell In formulas.Keys
        token = formulas(keyCell): n = n + 1
        block(n, 2) = "����": block(n, 3) = CStr(keyCell)
        block(n, 4) = token(0): block(n, 5) = token(1): block(n, 6) = InputTokenDialect(token)
        If UBound(token) >= 3 Then block(n, 7) = token(3)
    Next keyCell
    For r = 1 To n: block(r, 1) = key: Next r
    EncodeParkedState = block
End Function

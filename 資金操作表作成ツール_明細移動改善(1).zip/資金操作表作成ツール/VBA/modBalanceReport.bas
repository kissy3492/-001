Attribute VB_Name = "modBalanceReport"
Option Explicit

Private Const BAL_PAGE_BODY_POINTS As Double = 300
Private Const BAL_PAGE_ACCOUNT_LIMIT As Long = 12
Private Const BAL_NOTE_HEIGHT As Double = 48

Public Sub BuildBalanceTransitionSheetCore(ByVal activateAfter As Boolean, Optional ByVal destination As Worksheet = Nothing)
    Dim acc As Variant, bal As Variant, ws As Worksheet, people As Object, lookup As Object
    Dim labels As Collection, dates As Collection, group As Collection, notes As Collection
    Dim p As Variant, item As Variant, key As String, r As Long, ar As Long, i As Long, j As Long
    Dim block As Long, lastIndex As Long, blockSize As Long, outR As Long, totalR As Long
    Dim pageRecords As Long, pageCount As Long, subtotalCount As Long, subtotalRow As Long
    Dim pageHeight As Double, rowHeight As Double, record As Variant, previousTotal As String, currentTotal As String
    Dim pageCells(1 To 5) As String, pageTotals(1 To 5) As String
    Dim manualBreaks As Long, personLabel As String
    acc = ReportSourceData(SH_ACCOUNTS, 10, 1): bal = ReportSourceData(SH_WORK_BAL, 13, BAL_ID_COL, 8)
    BuildBalanceCollections labels, dates, False
    AddStoredBalanceDates labels, dates, bal
    FilterReportBalanceDates labels, dates
    Set people = CreateObject("Scripting.Dictionary"): Set lookup = CreateObject("Scripting.Dictionary")
    For r = 2 To UBound(acc, 1)
        key = AccountPersonID(CellText(acc(r, 1)))
        If Not people.Exists(key) Then
            Set group = New Collection
            people.Add key, group
        End If
        Set group = people(key): group.Add r
    Next r
    For r = 2 To UBound(bal, 1)
        key = CStr(bal(r, BAL_ID_COL)) & "|" & CStr(CLng(bal(r, 8)))
        If lookup.Exists(key) Then Err.Raise vbObjectError + 2401, , "���������E����̎c������������܂��B�o�^��������m�F���Ă��������B"
        lookup.Add key, bal(r, 10)
    Next r
    If destination Is Nothing Then Set ws = GetSheet(SH_OUTPUT_BAL) Else Set ws = destination
    ws.Unprotect Password:=TOOL_PASSWORD
    ws.Cells.UnMerge: ws.Cells.Clear: ws.ResetAllPageBreaks
    ws.Visible = xlSheetVisible
    ws.Columns("A:D").NumberFormat = "@": ws.Columns("L:L").NumberFormat = "@"
    ws.Columns("E:F").NumberFormat = "yyyy/m/d": ws.Columns("G:K").NumberFormat = "#,##0"
    ApplyBalanceOutputColumns ws
    ws.Range("A1").Value2 = "�c�����ڕ\"
    ws.Range("A2").Value2 = "�󗓁F�����́@�@�|�F�J�ݑO�E����Ŏc�������́@�@0�F�c���[���i���͍ς݋��z��D��j"
    If dates.Count = 0 Then ws.Range("A4").Value2 = "�w����ԂɎc���̊��������܂���B"
    outR = 4
    If dates.Count = 0 Then outR = 5
    For Each p In people.Keys
        Set group = people(p)
        personLabel = BalancePersonLabel(acc, group)
        previousTotal = ""
        For block = 1 To dates.Count Step 5
            lastIndex = Application.Min(block + 4, dates.Count): blockSize = lastIndex - block + 1
            For j = 1 To 5: pageCells(j) = "": pageTotals(j) = "": Next j
            pageRecords = 0: pageHeight = 0: pageCount = 1: subtotalCount = 0
            ar = CLng(group(1))
            BeginBalancePage ws, outR, personLabel, dates, block, lastIndex, False, manualBreaks
            For Each item In group
                ar = CLng(item)
                record = BalanceReportRecord(acc, ar, dates, block, lastIndex, lookup, notes)
                rowHeight = WriteBalanceRecord(ws, outR, record)
                If pageHeight + rowHeight > BAL_PAGE_BODY_POINTS Or pageRecords >= BAL_PAGE_ACCOUNT_LIMIT Then
                    ws.Range("A" & outR & ":L" & outR).ClearContents
                    subtotalRow = CloseBalancePage(ws, outR, pageCells, pageTotals, subtotalCount, blockSize)
                    outR = outR + 1
                    BeginBalancePage ws, outR, personLabel, dates, block, lastIndex, True, manualBreaks
                    pageHeight = 0: pageRecords = 0: pageCount = pageCount + 1
                    rowHeight = WriteBalanceRecord(ws, outR, record)
                End If
                For j = 1 To blockSize: pageCells(j) = AppendReportReference(pageCells(j), ws.Cells(outR, j + 6).Address): Next j
                pageRecords = pageRecords + 1: pageHeight = pageHeight + rowHeight: outR = outR + 1
                For i = 1 To notes.Count
                    If pageHeight + BAL_NOTE_HEIGHT > BAL_PAGE_BODY_POINTS Then
                        subtotalRow = CloseBalancePage(ws, outR, pageCells, pageTotals, subtotalCount, blockSize)
                        outR = outR + 1
                        BeginBalancePage ws, outR, personLabel, dates, block, lastIndex, True, manualBreaks
                        pageHeight = 0: pageRecords = 0: pageCount = pageCount + 1
                    End If
                    With ws.Range("A" & outR & ":L" & outR)
                        .Merge: .Value2 = notes(i): .WrapText = True
                        .Font.Name = "Yu Gothic UI": .Font.Size = 10: .Font.Color = RGB(71, 85, 105)
                        .VerticalAlignment = xlCenter
                        .Interior.Color = RGB(248, 250, 252)
                    End With
                    ws.Rows(outR).RowHeight = BAL_NOTE_HEIGHT
                    pageHeight = pageHeight + BAL_NOTE_HEIGHT: outR = outR + 1
                Next i
            Next item
            subtotalRow = CloseBalancePage(ws, outR, pageCells, pageTotals, subtotalCount, blockSize)
            If pageCount = 1 And subtotalRow > 0 Then
                totalR = subtotalRow: ws.Cells(totalR, 1).Value2 = "���v"
            Else
                totalR = outR: outR = outR + 1
                ws.Cells(totalR, 1).Value2 = "�S�������v"
                For j = 1 To blockSize
                    ws.Cells(totalR, j + 6).Formula = "=" & pageTotals(j)
                Next j
                FormatBalanceTotal ws, totalR
            End If
            ws.Cells(outR, 1).Value2 = "�O���_���z": ws.Rows(outR).RowHeight = 25
            For j = 1 To blockSize
                currentTotal = ws.Cells(totalR, j + 6).Address
                If Len(previousTotal) > 0 Then ws.Cells(outR, j + 6).Formula = "=IF(AND(ISNUMBER(" & currentTotal & "),ISNUMBER(" & previousTotal & "))," & currentTotal & "-" & previousTotal & ","""")"
                previousTotal = currentTotal
            Next j
            outR = outR + 3
        Next block
    Next p
    If people.Count = 0 Then ws.Range("A4").Value2 = "�o�^�ς݂̌���������܂���B"
    FormatBalanceTransitionOutputLayout ws
    ws.Calculate
    ProtectGeneratedOutput ws
    If activateAfter Then ws.Activate
End Sub

Private Function BalancePersonLabel(ByVal accounts As Variant, ByVal members As Collection) As String
    Dim labels As Object, member As Variant, row As Long, label As String
    Set labels = CreateObject("Scripting.Dictionary")
    For Each member In members
        row = CLng(member)
        label = DisplayPersonWithRelationship(CellText(accounts(row, 4)), CellText(accounts(row, 5)))
        labels(label) = True
    Next member
    BalancePersonLabel = Join(labels.Keys, "�E")
End Function

Private Sub AddBalancePageBreak(ByVal ws As Worksheet, ByVal rowNo As Long, ByRef manualBreaks As Long)
    If rowNo <= 4 Or manualBreaks >= 1000 Then Exit Sub
    '����ʒu�̒���������ł��؂�A�c��̌����E���t�E���v�̐����͑�����B
    On Error GoTo AutomaticPages
    ws.HPageBreaks.Add Before:=ws.Cells(rowNo, 1)
    manualBreaks = manualBreaks + 1
    Exit Sub
AutomaticPages:
    manualBreaks = 1000
End Sub

Private Sub BeginBalancePage(ByVal ws As Worksheet, ByRef rowNo As Long, ByVal person As String, ByVal dates As Collection, ByVal firstIndex As Long, ByVal lastIndex As Long, ByVal continued As Boolean, ByRef manualBreaks As Long)
    Dim j As Long
    AddBalancePageBreak ws, rowNo, manualBreaks
    With ws.Range("A" & rowNo & ":L" & rowNo)
        .Merge: .Value2 = "�����F" & person & IIf(continued, "�@�i�����j", "")
        .Font.Name = "Yu Gothic UI": .Font.Size = 11: .Font.Bold = True
        .Interior.Color = RGB(239, 246, 255)
    End With
    ws.Rows(rowNo).RowHeight = 26: rowNo = rowNo + 1
    SetRowValues ws.Cells(rowNo, 1), Array("��s��", "�x�X��", "�Ȗ�", "�����ԍ�", "�J�ݓ�", "����")
    For j = firstIndex To lastIndex
        ws.Cells(rowNo, 7 + j - firstIndex).Value2 = Format$(CDate(dates(j)), "yyyy/m/d") & vbLf & "�c��"
    Next j
    ws.Cells(rowNo, 12).Value2 = "����"
    FormatOutputHeader ws.Range("A" & rowNo & ":L" & rowNo)
    ws.Range("A" & rowNo & ":L" & rowNo).Font.Size = 11
    ws.Rows(rowNo).RowHeight = 38: rowNo = rowNo + 1
End Sub

Private Function BalanceReportRecord(ByVal acc As Variant, ByVal ar As Long, ByVal dates As Collection, ByVal firstIndex As Long, ByVal lastIndex As Long, ByVal lookup As Object, ByRef notes As Collection) As Variant
    Dim record As Variant, fields As Variant, headings As Variant, i As Long, c As Long, j As Long
    Dim text As String, key As String, d As Date, pos As Long
    ReDim record(1 To 1, 1 To 12)
    Set notes = New Collection
    fields = Array(2, 3, 6, 7, 10): headings = Array("��s��", "�x�X��", "�Ȗ�", "�����ԍ�", "����")
    For i = 0 To 4
        c = i + 1: If i = 4 Then c = 12
        text = Replace(Replace(Replace(CStr(acc(ar, CLng(fields(i)))), vbCr, " "), vbLf, " "), vbTab, " ")
        record(1, c) = Left$(text, 60)
        If Len(text) > 60 Then
            record(1, c) = record(1, c) & "�c"
            For pos = 61 To Len(text) Step 120
                notes.Add "���� " & Left$(CStr(acc(ar, 7)), 24) & " �^ " & CStr(headings(i)) & "�i�����j�F" & Mid$(text, pos, 120)
            Next pos
        End If
    Next i
    record(1, 5) = acc(ar, 8): record(1, 6) = acc(ar, 9)
    For j = firstIndex To lastIndex
        d = CDate(dates(j)): key = CStr(acc(ar, 1)) & "|" & CStr(CLng(d))
        If lookup.Exists(key) Then
            record(1, 7 + j - firstIndex) = lookup(key)
        ElseIf Not AccountExistsAtDate(d, acc(ar, 8), acc(ar, 9)) Then
            record(1, 7 + j - firstIndex) = "-"
        End If
    Next j
    BalanceReportRecord = record
End Function

Private Function WriteBalanceRecord(ByVal ws As Worksheet, ByVal rowNo As Long, ByVal record As Variant) As Double
    With ws.Range("A" & rowNo & ":L" & rowNo)
        .Value2 = record: .Font.Name = "Yu Gothic UI": .Font.Size = 11
        .WrapText = True: .VerticalAlignment = xlCenter
        .Borders.LineStyle = xlContinuous: .Borders.Color = RGB(220, 226, 233)
    End With
    With ws.Range("G" & rowNo & ":K" & rowNo)
        .WrapText = False: .ShrinkToFit = True
    End With
    ws.Rows(rowNo).AutoFit
    If ws.Rows(rowNo).RowHeight < 25 Then ws.Rows(rowNo).RowHeight = 25
    WriteBalanceRecord = ws.Rows(rowNo).RowHeight
End Function

Private Function CloseBalancePage(ByVal ws As Worksheet, ByRef rowNo As Long, ByRef cells() As String, ByRef totals() As String, ByRef count As Long, ByVal blockSize As Long) As Long
    Dim j As Long, part As Variant, missing As String
    If Len(cells(1)) = 0 Then Exit Function
    ws.Cells(rowNo, 1).Value2 = "�����܂ł̌v"
    For j = 1 To blockSize
        missing = ""
        For Each part In Split(cells(j), ",")
            If Len(missing) > 0 Then missing = missing & "+"
            missing = missing & "COUNTBLANK(" & CStr(part) & ")"
        Next part
        If Len(totals(j)) = 0 Then
            ws.Cells(rowNo, j + 6).Formula = "=IF(" & missing & ">0,""�����͂���"",SUM(" & cells(j) & "))"
        Else
            ws.Cells(rowNo, j + 6).Formula = "=IF(OR(" & missing & ">0,NOT(ISNUMBER(" & totals(j) & "))),""�����͂���"",SUM(" & cells(j) & "," & totals(j) & "))"
        End If
        totals(j) = ws.Cells(rowNo, j + 6).Address
        cells(j) = ""
    Next j
    FormatBalanceTotal ws, rowNo
    count = count + 1: CloseBalancePage = rowNo: rowNo = rowNo + 1
End Function

Private Sub FormatBalanceTotal(ByVal ws As Worksheet, ByVal rowNo As Long)
    With ws.Range("A" & rowNo & ":L" & rowNo)
        .Font.Name = "Yu Gothic UI": .Font.Size = 11: .Font.Bold = True
        .Interior.Color = RGB(236, 247, 241): .WrapText = True
    End With
    With ws.Range("G" & rowNo & ":K" & rowNo)
        .WrapText = False: .ShrinkToFit = True
    End With
    ws.Rows(rowNo).RowHeight = 25
End Sub

Private Function AppendReportReference(ByVal existing As String, ByVal reference As String) As String
    If Len(existing) = 0 Then AppendReportReference = reference Else AppendReportReference = existing & "," & reference
End Function

Public Sub AddStoredBalanceDates(ByRef labels As Collection, ByRef dates As Collection, ByVal bal As Variant)
    Dim map As Object, r As Long, i As Long, j As Long, keys As Variant, tmp As Variant
    Set map = CreateObject("Scripting.Dictionary")
    For i = 1 To dates.Count: map(CStr(CLng(CDate(dates(i))))) = labels(i): Next i
    For r = 2 To UBound(bal, 1): map(CStr(CLng(bal(r, 8)))) = bal(r, 9): Next r
    keys = map.Keys
    SortNumericKeys keys
    Set labels = New Collection: Set dates = New Collection
    For i = 0 To map.Count - 1
        labels.Add map(keys(i)): dates.Add CDate(CLng(keys(i)))
    Next i
End Sub

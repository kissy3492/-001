Attribute VB_Name = "modAccountStore"
Option Explicit

Public Const SH_ACCOUNTS As String = "W_����"
Public Const SH_ACCOUNT_LIST As String = "�o�^����"
Public Const SH_BAL_DRAFT As String = "W_���͎c��"
Public Const CELL_EDIT_ID As String = "X1"
Public Const CELL_DIRTY As String = "X2"
Public Const CELL_BAL_PAGE As String = "X3"
Public Const CELL_BAL_MEMO As String = "X4"
Public Const CELL_YEAR_SNAPSHOT As String = "X5"
Public Const CELL_YEAR_ADD As String = "X6"
Public Const TX_ID_COL As Long = 15
Public Const TX_KIND_COL As Long = 16
Public Const BAL_ID_COL As Long = 13

Public Function CurrentEditAccountID() As String
    CurrentEditAccountID = CellText(GetSheet(SH_INPUT).Range(CELL_EDIT_ID).Value2)
End Function

Public Function InputIsDirty() As Boolean
    InputIsDirty = (CellText(GetSheet(SH_INPUT).Range(CELL_DIRTY).Value2) = "1")
End Function

Public Sub MarkInputDirty(ByVal Target As Range)
    Dim ws As Worksheet
    Set ws = Target.Worksheet
    If Intersect(Target, Union(ws.Range("B5:K6,B10:K10"), InputEntryRange())) Is Nothing Then Exit Sub
    MarkFileNeedsSave
    ws.Range(CELL_DIRTY).Value2 = "1"
    UpdateInputStateLabel
    If Len(CellText(ws.Range(CELL_YEAR_SNAPSHOT).Value2)) = 0 Then
        ws.Range(CELL_YEAR_SNAPSHOT).Value2 = GetCfgCell(ROW_CFG_YEAR_MODE).Value2
        ws.Range(CELL_YEAR_ADD).Value2 = GetCfgLong(ROW_CFG_YEAR_ADD, 2000)
        ws.Range("X8").Value2 = GetCfgLong(ROW_CFG_BAL_START_YEAR, Year(Date) - 4)
        ws.Range("X9").Value2 = GetCfgLong(ROW_CFG_BAL_END_YEAR, Year(Date))
        If IsDate(GetCfgDateValue(ROW_CFG_INHERITANCE_DATE)) Then
            ws.Range("X10").Value2 = Year(CDate(GetCfgDateValue(ROW_CFG_INHERITANCE_DATE)))
        Else
            ws.Range("X10").Value2 = CLng((CDbl(ws.Range("X8").Value2) + CDbl(ws.Range("X9").Value2)) / 2)
        End If
    End If
End Sub

Public Function InputYearAdd() As Long
    InputYearAdd = GetCfgLong(ROW_CFG_YEAR_ADD, 2000)
    If HasText(GetSheet(SH_INPUT).Range(CELL_YEAR_ADD).Value2) Then _
        InputYearAdd = CLng(GetSheet(SH_INPUT).Range(CELL_YEAR_ADD).Value2)
End Function

Public Sub EnsureAccountStore()
    Dim ws As Worksheet
    If SheetExists(SH_ACCOUNTS) Then Set ws = GetSheet(SH_ACCOUNTS) Else Set ws = GetOrCreateSheet(SH_ACCOUNTS, False)
    If Not HasText(ws.Cells(1, 1).Value2) Then
        SetRowValues ws.Cells(1, 1), Array("����ID", "��s��", "�x�X��", "����", "����", "�Ȗ�", "�����ԍ�", "�J�ݓ�", "����", "����")
        ws.Columns("A:G").NumberFormat = "@"
        ws.Columns("H:I").NumberFormat = "yyyy/m/d"
        ws.Columns("J:J").NumberFormat = "@"
    End If
    If ws.Visible <> xlSheetVeryHidden Then ws.Visible = xlSheetVeryHidden
    EnsureTransactionIdentity
    If SheetExists(SH_BAL_DRAFT) Then Set ws = GetSheet(SH_BAL_DRAFT) Else Set ws = GetOrCreateSheet(SH_BAL_DRAFT, False)
    If Not HasText(ws.Cells(1, 1).Value2) Then
        SetRowValues ws.Cells(1, 1), Array("���", "���o��", "���͒l")
        ws.Columns(1).NumberFormat = "yyyy/m/d"
    End If
    If ws.Visible <> xlSheetVeryHidden Then ws.Visible = xlSheetVeryHidden
End Sub

Public Function AccountRow(ByVal accountID As String) As Long
    Dim hit As Variant
    If Len(accountID) = 0 Then Exit Function
    hit = Application.Match(accountID, GetSheet(SH_ACCOUNTS).Columns(1), 0)
    If Not IsError(hit) Then AccountRow = CLng(hit)
End Function

Public Function NextAccountID() As String
    NextAccountID = NewInternalID("A")
End Function

Public Function AccountIdentityKey(ByVal bank As String, ByVal branch As String, ByVal subject As String, ByVal number As String) As String
    AccountIdentityKey = Trim$(bank) & Chr$(30) & Trim$(branch) & Chr$(30) & Trim$(subject) & Chr$(30) & NormalizeAccountHyphen(number)
End Function

Public Function DuplicateAccountID(ByVal bank As String, ByVal branch As String, ByVal subject As String, ByVal number As String, ByVal excludeID As String) As String
    Dim data As Variant, r As Long, key As String
    If Not CompleteAccountIdentity(bank, branch, subject, number) Then Exit Function
    key = AccountIdentityKey(bank, branch, subject, number)
    data = ReadStore(GetSheet(SH_ACCOUNTS), 10)
    For r = 2 To UBound(data, 1)
        If CStr(data(r, 1)) <> excludeID Then
            If AccountIdentityKey(CStr(data(r, 2)), CStr(data(r, 3)), CStr(data(r, 6)), CStr(data(r, 7))) = key Then
                DuplicateAccountID = CStr(data(r, 1)): Exit Function
            End If
        End If
    Next r
End Function

Public Function ReadStore(ByVal ws As Worksheet, ByVal columnsCount As Long) As Variant
    Dim n As Long
    n = LastRow(ws, 1)
    If n < 1 Then n = 1
    ReadStore = ws.Cells(1, 1).Resize(n, columnsCount).Value2
End Function

Public Sub WriteStore(ByVal ws As Worksheet, ByVal data As Variant)
    Dim oldRows As Long, newRows As Long, nCols As Long
    oldRows = LastRow(ws, 1): newRows = UBound(data, 1): nCols = UBound(data, 2)
    ws.Cells(1, 1).Resize(newRows, nCols).Value2 = data
    If ws.Name = SH_PARKED_DRAFTS Then ResetPendingAccountCache
    If oldRows > newRows Then ws.Cells(newRows + 1, 1).Resize(oldRows - newRows, nCols).ClearContents
End Sub

Public Function ReplaceAccountRows(ByVal oldData As Variant, ByVal newData As Variant, ByVal newCount As Long, ByVal idColumn As Long, ByVal accountID As String) As Variant
    Dim result As Variant, r As Long, c As Long, n As Long, dest As Long, inserted As Boolean
    n = 1 + newCount
    For r = 2 To UBound(oldData, 1)
        If CStr(oldData(r, idColumn)) <> accountID Then n = n + 1
    Next r
    ReDim result(1 To n, 1 To UBound(oldData, 2))
    For c = 1 To UBound(oldData, 2): result(1, c) = oldData(1, c): Next c
    dest = 1
    For r = 2 To UBound(oldData, 1)
        If CStr(oldData(r, idColumn)) = accountID Then
            If Not inserted Then CopyReplacementRows result, dest, newData, newCount: inserted = True
        Else
            dest = dest + 1
            For c = 1 To UBound(oldData, 2): result(dest, c) = oldData(r, c): Next c
        End If
    Next r
    If Not inserted Then CopyReplacementRows result, dest, newData, newCount
    ReplaceAccountRows = result
End Function

Private Sub CopyReplacementRows(ByRef result As Variant, ByRef dest As Long, ByVal rows As Variant, ByVal count As Long)
    Dim r As Long, c As Long
    For r = 1 To count
        dest = dest + 1
        For c = 1 To UBound(result, 2): result(dest, c) = rows(r, c): Next c
    Next r
End Sub

Public Sub ShowRegisteredAccounts()
    Dim appStarted As Boolean
    Dim ws As Worksheet, data As Variant, r As Long, c As Long, out As Variant
    Dim drafts As Variant, headers As Object, key As Variant, dr As Long, n As Long, dest As Long
    Dim query As String, message As String
    Dim draftMemos As Object
    On Error GoTo EH
    EnsureAccountStore
    AppBegin "������\�����Ă��܂�..."
    appStarted = True
    ParkCurrentInput
    Set ws = GetOrCreateSheet(SH_ACCOUNT_LIST, False)
    query = CellText(ws.Range("B3").Value2)
    ws.Unprotect Password:=TOOL_PASSWORD
    If ws.AutoFilterMode Then ws.AutoFilterMode = False
    ws.Cells.UnMerge
    ws.Cells.Clear
    DeleteToolShapes ws, False
    data = ReadStore(GetSheet(SH_ACCOUNTS), 10)
    drafts = ParkedDraftData(): Set headers = DraftHeaderRows(drafts)
    Set draftMemos = DraftAccountMemos(drafts)
    n = UBound(data, 1) - 1
    For Each key In headers.Keys
        If Left$(CStr(key), 1) = "N" Then n = n + 1
    Next key
    ReDim out(1 To Application.Max(1, n), 1 To 11)
    For r = 2 To UBound(data, 1)
        dest = dest + 1
        For c = 2 To 10: out(dest, c - 1) = data(r, c): Next c
        out(dest, 10) = data(r, 1): out(dest, 11) = "�o�^�ς�"
        If headers.Exists(CStr(data(r, 1))) Then
            dr = CLng(headers(CStr(data(r, 1))))
            For c = 1 To 8: out(dest, c) = drafts(dr, c + 3): Next c
            If draftMemos.Exists(CStr(data(r, 1))) Then out(dest, 9) = draftMemos(CStr(data(r, 1)))
            out(dest, 11) = "�����r��"
        End If
    Next r
    For Each key In headers.Keys
        If Left$(CStr(key), 1) = "N" Then
            dest = dest + 1: dr = CLng(headers(CStr(key)))
            For c = 1 To 8: out(dest, c) = drafts(dr, c + 3): Next c
            If draftMemos.Exists(CStr(key)) Then out(dest, 9) = draftMemos(CStr(key))
            out(dest, 10) = CStr(key): out(dest, 11) = "�V�K���͒�"
        End If
    Next key
    ws.Cells.Font.Name = "Yu Gothic UI": ws.Cells.Font.Size = 10
    ws.Cells.Font.Color = RGB(30, 41, 59): ws.Cells.Interior.Color = vbWhite
    ws.Columns("A:F").NumberFormat = "@": ws.Columns("I:L").NumberFormat = "@"
    ws.Columns("G:H").NumberFormat = "yyyy/m/d"
    ws.Range("A1").Value2 = "�o�^�����E���͓r��"
    ws.Range("A2").Value2 = "�_�u���N���b�N�ő���������́E�����ł��܂��B���͓r���̓��e���ێ����Ă��܂��B"
    ws.Range("A1").Font.Size = 16: ws.Range("A1").Font.Bold = True
    ws.Rows(1).RowHeight = 36: ws.Rows(2).RowHeight = 25: ws.Rows(3).RowHeight = 29
    ws.Columns("A:A").ColumnWidth = 18: ws.Columns("B:B").ColumnWidth = 15
    ws.Columns("C:C").ColumnWidth = 15: ws.Columns("D:D").ColumnWidth = 8
    ws.Columns("E:E").ColumnWidth = 14: ws.Columns("F:F").ColumnWidth = 18
    ws.Columns("G:H").ColumnWidth = 13: ws.Columns("I:I").ColumnWidth = 18
    ws.Columns("K:K").ColumnWidth = 13
    ws.Columns("J:J").Hidden = True: ws.Columns("L:L").Hidden = True
    ws.Range("A3").Value2 = "����������"
    MergeAndFormat ws.Range("B3:D3"), query
    ws.Range("B3:D3").NumberFormat = "@": ws.Range("B3:D3").Locked = False
    ws.Range("B3:D3").Borders.LineStyle = xlContinuous
    ws.Range("B3:D3").Borders.Color = RGB(37, 99, 235)
    ws.Range("B3:D3").Interior.Color = RGB(239, 246, 255)
    MergeAndFormat ws.Range("E3:F3"), ""
    MergeAndFormat ws.Range("G3:K3"), "�����E��s�E�ԍ��ȂǁB�󗓂őS���\��"
    ws.Range("G3:K3").Font.Size = 9: ws.Range("G3:K3").Font.Color = RGB(71, 85, 105)
    SetRowValues ws.Range("A4"), Array("��s��", "�x�X��", "����", "����", "�Ȗ�", "�����ԍ�", "�J�ݓ�", "����", "����", "����ID", "��Ə��", "�����Ώ�")
    If n > 0 Then ws.Range("A5").Resize(n, 11).Value2 = out
    ws.Rows("4:" & Application.Max(5, n + 4)).RowHeight = 28
    FormatHeader ws.Range("A4:L4"), RGB(226, 232, 240)
    If n > 0 Then
        With ws.Range("K5:K" & n + 4)
            .FormatConditions.Delete
            .FormatConditions.Add Type:=xlCellValue, Operator:=xlNotEqual, Formula1:="=""�o�^�ς�"""
            .FormatConditions(1).Interior.Color = RGB(255, 247, 224)
            .FormatConditions(1).Font.Color = RGB(120, 73, 0)
        End With
    End If
    AddUIButton ws, ws.Range("E1").Left, ws.Range("E1").Top + 4, 116, 27, "�I�����������", "LoadSelectedAccountForEdit", "primary"
    AddUIButton ws, ws.Range("E1").Left + 124, ws.Range("E1").Top + 4, 116, 27, "�����֒ǉ�����", "LoadSelectedAccountForAppend", "tool"
    AddUIButton ws, ws.Range("E1").Left + 248, ws.Range("E1").Top + 4, 104, 27, "�܂Ƃ߂đ��� ��", "ShowAccountActions", "tool"
    AddUIButton ws, ws.Range("E1").Left + 360, ws.Range("E1").Top + 4, 104, 27, "���֖͂߂�", "ShowInputSheet", "tool"
    FilterRegisteredAccounts
    ws.Visible = xlSheetVisible: ws.Activate
    ActiveWindow.DisplayGridlines = False: ActiveWindow.Zoom = 95
    ws.Range("B3").Select
    ActiveWindow.FreezePanes = False
    ActiveWindow.SplitColumn = 0: ActiveWindow.SplitRow = 4: ActiveWindow.FreezePanes = True
    EndAppScope appStarted
    Exit Sub
EH:
    message = Err.Description
    EndAppScope appStarted
    MsgBox "������\���ł��܂���ł����B" & vbCrLf & message, vbExclamation
End Sub

Public Sub LoadSelectedAccountForEdit()
    LoadSelectedAccount False
End Sub

Public Sub LoadSelectedAccountForAppend()
    LoadSelectedAccount True
End Sub

Private Sub LoadSelectedAccount(ByVal appendMode As Boolean)
    Dim accountID As String
    If ActiveSheet.Name <> SH_ACCOUNT_LIST Then Exit Sub
    If ActiveCell.Row < 5 Then Exit Sub
    accountID = CellText(ActiveSheet.Cells(ActiveCell.Row, 10).Value2)
    If Len(accountID) = 0 Then Exit Sub
    OpenAccountOrDraft accountID, appendMode
End Sub

Public Function LoadAccountForEdit(ByVal accountID As String, Optional ByVal appendMode As Boolean = False) As Boolean
    Dim appStarted As Boolean
    Dim data As Variant, balances As Variant, info As Variant, inputData As Variant
    Dim r As Long, n As Long, c As Long, ar As Long, d As Date, ws As Worksheet
    Dim state As Collection, nextRow As Long, parsedTime As Variant, timeOK As Boolean
    Dim parsedDay As Variant, firstDateErrorRow As Long, errorID As String, inputRows As Long
    Dim layoutTrusted As Boolean, rawNotice As String
    Dim changing As Boolean, message As String, restoreFailed As Boolean
    On Error GoTo EH
    ar = AccountRow(accountID)
    If ar < 2 Then Err.Raise vbObjectError + 2101, , "�������������������܂���B"
    data = ReadStore(GetSheet(SH_WORK_TX), TX_STORE_COLS)
    balances = ReadStore(GetSheet(SH_WORK_BAL), 13)
    For r = 2 To UBound(data, 1)
        If CStr(data(r, TX_ID_COL)) = accountID And CStr(data(r, TX_KIND_COL)) = "���" Then n = n + 1
    Next r
    ReDim inputData(1 To Application.Max(1, n), 1 To 11)
    n = 0
    For r = 2 To UBound(data, 1)
        If CStr(data(r, TX_ID_COL)) = accountID And CStr(data(r, TX_KIND_COL)) = "���" Then
            n = n + 1
            If TryStoredDate(data(r, OUT_COL_DATE), parsedDay) Then
                d = CDate(parsedDay)
                inputData(n, 1) = Year(d): inputData(n, 2) = Month(d): inputData(n, 3) = Day(d)
            Else
                inputData(n, 1) = "���t�v�����F" & CellText(data(r, OUT_COL_DATE))
                If firstDateErrorRow = 0 Then firstDateErrorRow = TX_FIRST_ROW + n - 1
            End If
            parsedTime = NormalizeTimeInput(data(r, OUT_COL_TIME), timeOK)
            If timeOK Then
                If HasText(parsedTime) Then inputData(n, 4) = InputTimeText(parsedTime)
            Else
                inputData(n, 4) = CellText(data(r, OUT_COL_TIME))
            End If
            For c = 8 To 13: inputData(n, c - 3) = data(r, c): Next c
            inputData(n, 11) = data(r, TX_UID_COL)
        End If
    Next r
    If firstDateErrorRow > 0 Then errorID = CellText(inputData(firstDateErrorRow - TX_FIRST_ROW + 1, 11))
    inputData = PositionAccountInputData(inputData, accountID, layoutTrusted)
    inputRows = UBound(inputData, 1)
    If Len(errorID) > 0 Then
        For r = 1 To inputRows
            If CellText(inputData(r, 11)) = errorID Then firstDateErrorRow = TX_FIRST_ROW + r - 1: Exit For
        Next r
    End If
    info = GetSheet(SH_ACCOUNTS).Cells(ar, 1).Resize(1, 10).Value2
    '�ǂݍ��߂Ȃ����t������΁A���͗�������������O�ɒm�点��B
    ValidateAccountBalanceLoad balances, accountID
    AppBegin "������ǂݍ���ł��܂�..."
    appStarted = True
    Set ws = GetSheet(SH_INPUT)
    Set state = CaptureInputState()
    changing = True
    EnsureTransactionCapacity Application.Min(inputRows + 1, ws.Rows.Count - TX_FIRST_ROW + 1)
    ws.Unprotect Password:=TOOL_PASSWORD
    InputTransactionRange().ClearContents
    ClearInputTransactionIDs
    FitEmptyTransactionCapacity inputRows + 1
    ws.Range(CELL_BANK).Value2 = info(1, 2): ws.Range(CELL_BRANCH).Value2 = info(1, 3)
    ws.Range(CELL_PERSON).Value2 = info(1, 4): ws.Range(CELL_RELATIONSHIP).Value2 = info(1, 5)
    ws.Range(CELL_ACCOUNT_TYPE).Value2 = info(1, 6): ws.Range(CELL_ACCOUNT_NO).Value2 = info(1, 7)
    WriteAccountDateInput ws.Range(CELL_OPEN_DATE), info(1, 8)
    WriteAccountDateInput ws.Range(CELL_CLOSE_DATE), info(1, 9)
    WriteInputValueBlock ws.Cells(TX_FIRST_ROW, COL_TX_YEAR).Resize(UBound(inputData, 1), 11), inputData
    ws.Range("X17:X20").ClearContents
    ws.Range("X22").Value2 = RegisteredBookmark(accountID)
    ResetRememberedPosition
    ws.Range(CELL_EDIT_ID).Value2 = accountID
    ws.Range(CELL_DIRTY).Value2 = "0"
    ws.Range(CELL_YEAR_SNAPSHOT).ClearContents: ws.Range(CELL_YEAR_ADD).ClearContents
    ws.Range("X8:X10").ClearContents
    LoadBalanceDraft balances, accountID, CStr(info(1, 10))
    WriteInputBaseline info, AccountBalanceBaseline(balances, accountID)
    rawNotice = RestoreRegisteredInputRaw(accountID, layoutTrusted)
    ApplyInputSettings False
    BuildOperationPanel ws
    ResetInputNavigation
    ShowInputSheet
    If appendMode Then
        nextRow = TX_FIRST_ROW + IIf(n = 0 And Not layoutTrusted, 0, inputRows)
        If nextRow > InputLastTransactionRow() Then nextRow = InputLastTransactionRow()
        SetInputSections False, False
        ws.Cells(nextRow, IIf(n > 0, COL_TX_DAY, COL_TX_YEAR)).Select
        SetInputStatus "�����ɒǉ����͂ł��܂��B�N�E���͒��O�s����⊮���܂��B������Ɂu�����𔽉f�v�������Ă��������B"
    Else
        SetInputSections True, False
        SafeSelectCell ws, CELL_ACCOUNT_NO
        SetInputStatus "�������@���ׂ̒ǉ��E�폜�A�������E�c���̒������ł��܂��B"
    End If
    If Len(rawNotice) > 0 Then SetInputStatus rawNotice
    If firstDateErrorRow > 0 Then
        MarkInputDirty ws.Cells(firstDateErrorRow, COL_TX_YEAR)
        SafeSelectCell ws, ws.Cells(firstDateErrorRow, COL_TX_YEAR).Address
        SetInputStatus "���t��ǂ߂Ȃ����ׂ�����܂��B�u���t�v�����v�̍s�̔N�E���E������͂��Ă��甽�f���Ă��������B"
    End If
    changing = False
    ClearInputUndo
    EndAppScope appStarted
    LoadAccountForEdit = True
    Exit Function
EH:
    message = Err.Description
    If changing Then
        On Error Resume Next
        Err.Clear
        RestoreInputState state
        If Err.Number <> 0 Then restoreFailed = True
        On Error GoTo 0
    End If
    EndAppScope appStarted
    If restoreFailed Then message = message & vbCrLf & "���͉�ʂ̕������������ł��B�o�^�ς݃f�[�^�͕ύX���Ă��܂���B�o�^��������J�������Ă��������B"
    MsgBox "������ǂݍ��߂܂���ł����B" & vbCrLf & message, vbExclamation
End Function


Public Function CompleteAccountIdentity(ByVal bank As String, ByVal branch As String, ByVal subject As String, ByVal number As String) As Boolean
    CompleteAccountIdentity = KnownAccountIdentityPart(bank) And KnownAccountIdentityPart(branch) And KnownAccountIdentityPart(subject) And KnownAccountIdentityPart(NormalizeAccountHyphen(number))
End Function

Public Function PossibleDuplicateAccountID(ByVal bank As String, ByVal branch As String, ByVal subject As String, ByVal number As String, ByVal excludeID As String) As String
    Dim data As Variant, r As Long
    If Len(Trim$(bank)) = 0 Or Len(Trim$(subject)) = 0 Or Len(NormalizeAccountHyphen(number)) = 0 Then Exit Function
    data = ReadStore(GetSheet(SH_ACCOUNTS), 10)
    For r = 2 To UBound(data, 1)
        If CellText(data(r, 1)) <> excludeID Then
            If Trim$(bank) = CellText(data(r, 2)) And Trim$(subject) = CellText(data(r, 6)) And NormalizeAccountHyphen(number) = NormalizeAccountHyphen(CellText(data(r, 7))) Then
                If Not KnownAccountIdentityPart(branch) Or Not KnownAccountIdentityPart(CellText(data(r, 3))) Then PossibleDuplicateAccountID = CellText(data(r, 1)): Exit Function
            End If
        End If
    Next r
End Function

Public Function ImportAccountIdentityKey(ByVal bank As String, ByVal branch As String, ByVal subject As String, ByVal number As String, ByVal person As String) As String
    ImportAccountIdentityKey = AccountIdentityKey(bank, branch, subject, number)
    If Not CompleteAccountIdentity(bank, branch, subject, number) Then ImportAccountIdentityKey = ImportAccountIdentityKey & Chr$(30) & Trim$(person)
End Function


Public Function KnownAccountIdentityPart(ByVal value As String) As Boolean
    Select Case Trim$(value)
        Case "", "�s��", "���m�F", "�s��", "������", "?", "�H", "-", "--": Exit Function
    End Select
    KnownAccountIdentityPart = True
End Function

Attribute VB_Name = "modImportMerge"
Option Explicit

Public Const IMPORT_ORIGIN_COLS As Long = 30
Private Const IMPORT_ACTION_COL As Long = 310
Private Const IMPORT_MATCH_COL As Long = 311

Private Function OriginRow(ByVal data As Variant, ByVal row As Long) As Variant
    Dim value(1 To IMPORT_ORIGIN_COLS) As Variant, c As Long
    For c = 1 To Application.Min(IMPORT_ORIGIN_COLS, UBound(data, 2)): value(c) = data(row, c): Next c
    OriginRow = value
End Function

Public Function ReadImportHistoryTokens() As Object
    Dim result As Object, data As Variant, r As Long
    Set result = CreateObject("Scripting.Dictionary")
    If SheetExists("W_�o�T") Then
        data = ReadStore(GetSheet("W_�o�T"), IMPORT_ORIGIN_COLS)
        For r = 2 To UBound(data, 1): result("O|" & CellText(data(r, 1))) = Array(OriginRow(data, r), ""): Next r
    End If
    Set ReadImportHistoryTokens = result
End Function

Public Sub AddImportOperationHistory(ByVal state As Collection, ByVal before As Object, ByVal after As Object)
    Dim oldData As Variant, current As Variant, oldRows As Object, seen As Object, key As String, r As Long, a As Variant, b As Variant
    On Error Resume Next
    oldData = state("origins")
    On Error GoTo 0
    If Not IsArray(oldData) Then Exit Sub
    current = ReadStore(ImportOriginStore(), IMPORT_ORIGIN_COLS)
    Set oldRows = BatchRowsByID(oldData, 1): Set seen = CreateObject("Scripting.Dictionary")
    For r = 2 To UBound(current, 1)
        key = CellText(current(r, 1)): seen(key) = True: a = Empty: b = OriginRow(current, r)
        If oldRows.Exists(key) Then a = OriginRow(oldData, CLng(oldRows(key)))
        If Not InputValuesEqual(a, b) Then
            before("O|" & key) = Array(a, ""): after("O|" & key) = Array(b, "")
        End If
    Next r
    For r = 2 To UBound(oldData, 1)
        key = CellText(oldData(r, 1))
        If Not seen.Exists(key) Then before("O|" & key) = Array(OriginRow(oldData, r), ""): after("O|" & key) = Array(Empty, "")
    Next r
End Sub

Public Sub ApplyImportHistoryChanges(ByVal changes As Collection, ByVal side As Long)
    Dim edits As Object, change As Variant, key As Variant, token As Variant, record As Variant
    Dim oldData As Variant, result As Variant, r As Long, c As Long, n As Long, uid As String
    Set edits = CreateObject("Scripting.Dictionary")
    For Each change In changes
        If Left$(CStr(change(0)), 2) = "O|" Then edits(Mid$(CStr(change(0)), 3)) = change(side)
    Next change
    If edits.Count = 0 Then Exit Sub
    oldData = ReadStore(ImportOriginStore(), IMPORT_ORIGIN_COLS)
    ReDim result(1 To UBound(oldData, 1) + edits.Count, 1 To IMPORT_ORIGIN_COLS)
    For c = 1 To IMPORT_ORIGIN_COLS: result(1, c) = oldData(1, c): Next c
    n = 1
    For r = 2 To UBound(oldData, 1)
        uid = CellText(oldData(r, 1))
        If edits.Exists(uid) Then
            token = edits(uid)
            If IsArray(token(0)) Then
                record = token(0): n = n + 1
                For c = 1 To IMPORT_ORIGIN_COLS: result(n, c) = record(c): Next c
            End If
            edits.Remove uid
        Else
            n = n + 1
            For c = 1 To IMPORT_ORIGIN_COLS: result(n, c) = oldData(r, c): Next c
        End If
    Next r
    For Each key In edits.Keys
        token = edits(key)
        If IsArray(token(0)) Then
            record = token(0): n = n + 1
            For c = 1 To IMPORT_ORIGIN_COLS: result(n, c) = record(c): Next c
        End If
    Next key
    WriteStore ImportOriginStore(), FitStoreRows(result, n)
End Sub

Public Function OriginMappingKey(ByVal map As Object) As String
    Dim field As Variant
    For Each field In Array("���t", "�N", "��", "��", "����", "�o��", "����", "�戵�X", "�@��", "�E�v", "���̑�")
        If map.Exists(CStr(field)) Then OriginMappingKey = OriginMappingKey & CStr(field) & "=" & map(CStr(field)) & ";"
    Next field
End Function

Private Function NormalizedOriginMapping(ByVal text As String) As String
    Dim map As Object, part As Variant, pair As Variant
    Set map = CreateObject("Scripting.Dictionary")
    For Each part In Split(text, ";")
        pair = Split(CStr(part), "=")
        If UBound(pair) = 1 Then map(CStr(pair(0))) = CStr(pair(1))
    Next part
    NormalizedOriginMapping = OriginMappingKey(map)
End Function

Private Function FramedOriginValue(ByVal value As Variant) As String
    Dim text As String
    If IsNull(value) Then text = "Null" Else text = CStr(value)
    FramedOriginValue = CStr(VarType(value)) & ":" & Len(text) & ":" & text
End Function

Private Function OriginSourceKey(ByVal record As Variant) As String
    OriginSourceKey = LCase$(CellText(record(3))) & Chr$(30) & CellText(record(4)) & Chr$(30) & CellText(record(6)) & Chr$(30) & NormalizedOriginMapping(CellText(record(7))) & Chr$(30) & CellText(record(8))
End Function

Private Function OriginContentKey(ByVal record As Variant) As String
    Dim c As Long
    OriginContentKey = OriginSourceKey(record)
    For c = 9 To 19: OriginContentKey = OriginContentKey & FramedOriginValue(record(c)): Next c
End Function

Private Sub AddOriginIndex(ByVal index As Object, ByVal key As String, ByVal row As Long)
    Dim items As Collection
    If index.Exists(key) Then Set items = index(key) Else Set items = New Collection: index.Add key, items
    items.Add row
End Sub

Private Function MatchingOriginRow(ByVal exact As Object, ByVal record As Variant, ByVal originals As Variant, ByVal used As Object) As Long
    Dim candidates As Collection, candidate As Variant, possible As Long, count As Long, oldRecord As Variant, c As Long, same As Boolean
    If Not exact.Exists(OriginContentKey(record)) Then Exit Function
    Set candidates = exact(OriginContentKey(record))
    For Each candidate In candidates
        If Not used.Exists(CStr(candidate)) Then
            oldRecord = OriginRow(originals, CLng(candidate)): same = True
            For c = 9 To 19
                If Not InputValuesEqual(oldRecord(c), record(c)) Then same = False: Exit For
            Next c
            If same Then
                If CellText(oldRecord(5)) = CellText(record(5)) Then MatchingOriginRow = CLng(candidate): Exit Function
                possible = CLng(candidate): count = count + 1
            End If
        End If
    Next candidate
    If count = 1 Then MatchingOriginRow = possible
End Function

Public Function ImportFieldEqual(ByVal a As Variant, ByVal b As Variant, ByVal field As Long) As Boolean
    Dim leftValue As Variant, rightValue As Variant, leftOK As Boolean, rightOK As Boolean
    If InputValuesEqual(a, b) Then ImportFieldEqual = True: Exit Function
    If IsError(a) Or IsError(b) Or IsEmpty(a) Or IsEmpty(b) Or IsNull(a) Or IsNull(b) Then Exit Function
    Select Case field
        Case 1
            leftValue = NormalizeYearInput(a, InputYearAdd(), leftOK): rightValue = NormalizeYearInput(b, InputYearAdd(), rightOK)
        Case 2, 3, 5, 6
            leftValue = ParseMoney(a, False, leftOK): rightValue = ParseMoney(b, False, rightOK)
        Case 4
            leftValue = NormalizeTimeInput(a, leftOK): rightValue = NormalizeTimeInput(b, rightOK)
        Case Else: Exit Function
    End Select
    If leftOK And rightOK Then ImportFieldEqual = InputValuesEqual(leftValue, rightValue)
End Function

Public Function PlanMappedImport(ByVal original As Variant, ByVal incoming As Variant, ByVal output As Variant, ByVal sourceRows As Variant, ByVal ws As Worksheet, ByVal target As Worksheet, ByVal owner As String) As Collection
    Dim result As New Collection, resolved As New Collection, edits As Object, exact As Object, positions As Object, sources As Object, used As Object, inputRows As Object, documents As Object
    Dim raw As Variant, nextOrigins As Variant, record As Variant, previous As Variant, token As Variant, values As Variant, candidates As Collection
    Dim r As Long, c As Long, n As Long, match As Long, atRow As Long, nextRow As Long, displayRow As Long, originRowIndex As Long
    Dim added As Long, updated As Long, unchanged As Long, pending As Long, conflict As Boolean, rowChanged As Boolean
    Dim uid As String, action As String, sourceKey As String, rowKey As String, notice As String, explicitID As String, current As Variant, baseline As Variant
    Set edits = CreateObject("Scripting.Dictionary"): Set exact = CreateObject("Scripting.Dictionary"): Set positions = CreateObject("Scripting.Dictionary")
    Set documents = CreateObject("Scripting.Dictionary")
    Set sources = CreateObject("Scripting.Dictionary"): Set used = CreateObject("Scripting.Dictionary"): Set inputRows = CreateObject("Scripting.Dictionary")
    raw = target.Cells(TX_FIRST_ROW, COL_TX_YEAR).Resize(Application.Max(1, LastInputDataRow() - TX_FIRST_ROW + 1), 11).Value2
    For r = 1 To UBound(raw, 1)
        uid = CellText(raw(r, 11)): If Len(uid) > 0 Then inputRows(uid) = TX_FIRST_ROW + r - 1
    Next r
    For r = 2 To UBound(original, 1)
        record = OriginRow(original, r): uid = CellText(record(1))
        If inputRows.Exists(uid) Or CellText(record(30)) = owner Then
            sourceKey = OriginSourceKey(record): sources(sourceKey) = True
            documents(OriginDocumentKey(record)) = True
            AddOriginIndex exact, OriginContentKey(record), r
            AddOriginIndex positions, sourceKey & Chr$(30) & CellText(record(5)), r
        End If
    Next r
    ReDim nextOrigins(1 To UBound(original, 1) + UBound(output, 1), 1 To IMPORT_ORIGIN_COLS)
    For r = 1 To UBound(original, 1)
        For c = 1 To IMPORT_ORIGIN_COLS: nextOrigins(r, c) = original(r, c): Next c
    Next r
    n = UBound(original, 1): nextRow = Application.Max(TX_FIRST_ROW, LastInputDataRow() + 1)
    For r = 1 To UBound(output, 1)
        record = OriginRow(incoming, r + 1): displayRow = CLng(sourceRows(r)) + 6
        action = CellText(ws.Cells(displayRow, IMPORT_ACTION_COL).Value2)
        explicitID = CellText(ws.Cells(displayRow, IMPORT_MATCH_COL).Value2)
        sourceKey = OriginSourceKey(record): rowKey = sourceKey & Chr$(30) & CellText(record(5))
        match = 0: conflict = False: rowChanged = False: notice = "": atRow = 0
        If action = "skip" Then unchanged = unchanged + 1: notice = "����͌�����": GoTo ShowStatus
        If action <> "add" Then match = MatchingOriginRow(exact, record, original, used)
        If action = "source" Or action = "keep" Or action = "match" Then
            If positions.Exists(rowKey) Then
                Set candidates = positions(rowKey)
                If candidates.Count = 1 Then match = CLng(candidates(1))
            End If
            If Len(explicitID) > 0 Then
                match = 0
                For c = 2 To UBound(original, 1)
                    If CellText(original(c, 1)) = explicitID Then match = c: Exit For
                Next c
            End If
        End If
        If match > 0 Then
            If used.Exists(CStr(match)) Then match = 0
        End If
        If match = 0 And action <> "add" And (sources.Exists(sourceKey) Or documents.Exists(OriginDocumentKey(record)) Or Len(explicitID) > 0 Or action = "match" Or action = "source" Or action = "keep") Then
            pending = pending + 1: notice = "���s�̑Ή����m�F�F�E�N���b�N�ōX�V�E�ǉ��E������"
            If positions.Exists(rowKey) Then
                Set candidates = positions(rowKey)
                If candidates.Count = 1 Then ws.Cells(displayRow, IMPORT_MATCH_COL).Value2 = original(CLng(candidates(1)), 1)
            End If
            GoTo ShowStatus
        End If
        If match = 0 Then
            atRow = nextRow: nextRow = nextRow + 1: n = n + 1: originRowIndex = n
            uid = NewInternalID("T"): record(1) = uid: added = added + 1
            edits("C|L" & atRow) = Array(uid, "")
            For c = 1 To 10
                edits("C|" & Chr$(COL_TX_YEAR + c - 1 + 64) & atRow) = Array(output(r, c), "")
                record(19 + c) = output(r, c)
            Next c
            notice = "�ǉ��\��"
        Else
            used(CStr(match)) = True: previous = OriginRow(original, match): uid = CellText(previous(1))
            If Not inputRows.Exists(uid) Then
                pending = pending + 1: notice = "���̌����ׂ͓��͗��ɂ���܂���B�ǉ�����ꍇ�͉E�N���b�N": GoTo ShowStatus
            End If
            atRow = CLng(inputRows(uid)): originRowIndex = match: record(1) = uid
            For c = 1 To 10
                token = InputCellToken(target.Cells(atRow, COL_TX_YEAR + c - 1)): current = token(0)
                baseline = previous(19 + c)
                If Len(CellText(previous(30))) = 0 Then baseline = output(r, c)
                record(19 + c) = baseline
                If action = "source" Then
                    If Len(CStr(token(1))) > 0 Or Not ImportFieldEqual(current, output(r, c), c) Then
                        edits("C|" & Chr$(COL_TX_YEAR + c - 1 + 64) & atRow) = Array(output(r, c), ""): rowChanged = True
                    End If
                    record(19 + c) = output(r, c)
                ElseIf action = "keep" Then
                    record(19 + c) = output(r, c)
                ElseIf ImportFieldEqual(baseline, output(r, c), c) Then
                    '�����������Ȃ������E���������̂܂ܕێ�����B
                ElseIf Len(CStr(token(1))) = 0 And ImportFieldEqual(current, baseline, c) Then
                    edits("C|" & Chr$(COL_TX_YEAR + c - 1 + 64) & atRow) = Array(output(r, c), "")
                    record(19 + c) = output(r, c): rowChanged = True
                ElseIf Len(CStr(token(1))) = 0 And ImportFieldEqual(current, output(r, c), c) Then
                    record(19 + c) = output(r, c)
                Else
                    conflict = True
                End If
            Next c
            If rowChanged Then updated = updated + 1 Else unchanged = unchanged + 1
            notice = IIf(rowChanged, "�X�V�\��", "�捞�ς݁E���݂̓��͂�ێ�")
            If conflict Then
                pending = pending + 1: notice = "������Ǝ����X�V�������F�E�N���b�N�Ŏg���l��I��"
                ws.Cells(displayRow, IMPORT_MATCH_COL).Value2 = uid
            End If
        End If
        If match > 0 Then record(2) = previous(2)
        record(30) = owner
        For c = 1 To IMPORT_ORIGIN_COLS: nextOrigins(originRowIndex, c) = record(c): Next c
        If Not conflict Then resolved.Add displayRow
ShowStatus:
        ws.Cells(displayRow, CLng(ws.Range("XFD3").Value2) + 1).Value2 = notice
    Next r
    result.Add edits, "edits": result.Add FitStoreRows(nextOrigins, n), "origins"
    result.Add added, "added": result.Add updated, "updated": result.Add unchanged, "unchanged": result.Add pending, "pending"
    result.Add nextRow, "nextRow": result.Add resolved, "resolved"
    Set PlanMappedImport = result
End Function

Public Function ShowMappedImportChoice(ByVal target As Range) As Boolean
    Dim menu As Object, ws As Worksheet, row As Long
    If BatchMode() <> "���׎捞" Then Exit Function
    Set ws = GetSheet(SH_BATCH): row = target.Row
    If row < 7 Or row > CLng(ws.Range("XFD2").Value2) + 6 Then Exit Function
    On Error GoTo Done
    Set menu = Application.CommandBars.Add(Position:=5, Temporary:=True)
    AddInputMenuItem menu, "�Ή�����������ׂ��w�肵�čX�V", "ChooseMappedExistingRow"
    If HasText(ws.Cells(row, IMPORT_MATCH_COL).Value2) Then
        AddInputMenuItem menu, "�������s�̍X�V�Ƃ��ďƍ�����", "MatchMappedSourceRow"
        AddInputMenuItem menu, "���̖��ׂ͍���̎����̒l���g��", "UseMappedSourceRow"
        AddInputMenuItem menu, "�������s�̍X�V�Ƃ��Č��݂̓��͂��c��", "KeepMappedEditedRow"
    End If
    AddInputMenuItem menu, "�ʂ̖��ׂƂ��Ēǉ�", "AddMappedSourceRow", True
    AddInputMenuItem menu, "����͎�荞�܂Ȃ�", "SkipMappedSourceRow"
    menu.ShowPopup
    ShowMappedImportChoice = True
Done:
    On Error Resume Next
    If Not menu Is Nothing Then menu.Delete
End Function

Private Sub SetMappedRowAction(ByVal action As String)
    Dim ws As Worksheet, chosen As Range, area As Range, row As Long, rows As Object, key As Variant
    If BatchMode() <> "���׎捞" Then Exit Sub
    Set ws = GetSheet(SH_BATCH)
    If ActiveSheet.Name <> SH_BATCH Or ActiveCell.Row < 7 Then Exit Sub
    Set rows = CreateObject("Scripting.Dictionary")
    If TypeName(Selection) <> "Range" Then Exit Sub
    Set chosen = Intersect(Selection, ws.Range(ws.Cells(7, 1), ws.Cells(CLng(ws.Range("XFD2").Value2) + 6, CLng(ws.Range("XFD3").Value2) + 1)))
    If chosen Is Nothing Then Exit Sub
    For Each area In chosen.Areas
        For row = area.Row To area.Row + area.Rows.Count - 1: rows(CStr(row)) = True: Next row
    Next area
    For Each key In rows.Keys
        row = CLng(key)
        ws.Cells(row, IMPORT_ACTION_COL).Value2 = action
        If action = "add" Or action = "skip" Then ws.Cells(row, IMPORT_MATCH_COL).ClearContents
        ws.Cells(row, CLng(ws.Range("XFD3").Value2) + 1).Value2 = "�I���ς݁F��̔��f�œK�p"
    Next key
    MarkFileNeedsSave
End Sub

Public Sub MatchMappedSourceRow()
    SetMappedRowAction "match"
End Sub
Public Sub UseMappedSourceRow()
    SetMappedRowAction "source"
End Sub
Public Sub KeepMappedEditedRow()
    SetMappedRowAction "keep"
End Sub
Public Sub AddMappedSourceRow()
    SetMappedRowAction "add"
End Sub
Public Sub SkipMappedSourceRow()
    SetMappedRowAction "skip"
End Sub
Public Sub ChooseMappedExistingRow()
    Dim value As Variant, row As Long, sourceRow As Long, uid As String, ws As Worksheet
    If BatchMode() <> "���׎捞" Then Exit Sub
    Set ws = GetSheet(SH_BATCH)
    If ActiveSheet.Name <> SH_BATCH Then Exit Sub
    sourceRow = ActiveCell.Row
    If sourceRow < 7 Or sourceRow > CLng(ws.Range("XFD2").Value2) + 6 Then Exit Sub
    value = Application.InputBox("�X�V������͗���Excel�s�ԍ�����͂��Ă��������B�I�𒆂̌�����1�s�ɑΉ������܂��B", "�������ׂ̎w��", Type:=1)
    If VarType(value) = vbBoolean Then Exit Sub
    If value <> Fix(value) Or value < TX_FIRST_ROW Or value > LastInputDataRow() Then Exit Sub
    row = CLng(value): uid = CellText(GetSheet(SH_INPUT).Cells(row, INPUT_UID_COL).Value2)
    If Len(uid) = 0 Then
        MsgBox "�捞�ς݂̖��ׂ��w�肵�Ă��������B���捞�̍s�́u�ʂ̖��ׂƂ��Ēǉ��v�Ŏ�荞�߂܂��B", vbInformation
        Exit Sub
    End If
    ws.Cells(sourceRow, IMPORT_MATCH_COL).Value2 = uid
    ws.Cells(sourceRow, IMPORT_ACTION_COL).Value2 = "match"
    ws.Cells(sourceRow, CLng(ws.Range("XFD3").Value2) + 1).Value2 = "�Ή���F����" & row & "�s�^��̔��f�œK�p"
    MarkFileNeedsSave
End Sub


Private Function OriginDocumentKey(ByVal record As Variant) As String
    OriginDocumentKey = LCase$(CellText(record(3))) & Chr$(30) & LCase$(CellText(record(4)))
End Function

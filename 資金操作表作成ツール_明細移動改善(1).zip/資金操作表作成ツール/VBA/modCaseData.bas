Attribute VB_Name = "modCaseData"
Option Explicit

Private Function CaseStoreLayout() As Variant
    '�����ƕ����������ۑ�����g���B���ʌ��E��Ή��̐ݒ�͊܂߂Ȃ��B
    CaseStoreLayout = Array(Array(SH_WORK_TX, TX_STORE_COLS), Array(SH_WORK_BAL, 13), _
        Array(SH_ACCOUNTS, 10), Array(SH_PARKED_DRAFTS, 14), Array("W_������", 2), _
        Array(SH_ANALYSIS_RELATIONS, 12), Array("W_���͉�����", 6), _
        Array("W_�o�T", IMPORT_ORIGIN_COLS), Array(SH_INPUT_RAW, INPUT_RAW_COLS), Array("W_�l������", 3), Array(SH_SHOP_TARGET, 8))
End Function

Public Function CaptureCaseStores() As Object
    Dim stores As Object, item As Variant
    Set stores = CreateObject("Scripting.Dictionary")
    For Each item In CaseStoreLayout()
        If SheetExists(CStr(item(0))) Then stores.Add CStr(item(0)), ReadStore(GetSheet(CStr(item(0))), CLng(item(1)))
    Next item
    Set CaptureCaseStores = stores
End Function

Public Sub ClearCaseStores(ByVal stores As Object)
    Dim name As Variant, data As Variant, ws As Worksheet
    For Each name In stores.Keys
        data = stores(name)
        Set ws = GetSheet(CStr(name)): ws.Unprotect Password:=TOOL_PASSWORD
        ClearStoreBody ws, UBound(data, 2)
    Next name
End Sub

Public Function RestoreCaseStores(ByVal stores As Object) As String
    Dim name As Variant
    If stores Is Nothing Then Exit Function
    On Error Resume Next
    For Each name In stores.Keys
        Err.Clear
        WriteStore GetSheet(CStr(name)), stores(name)
        If Err.Number <> 0 Then RestoreCaseStores = RestoreCaseStores & " " & CStr(name) & "�F" & Err.Description
    Next name
    On Error GoTo 0
End Function

Public Sub NormalizeExportScopeCells()
    Dim ws As Worksheet, r As Long, cell As Range
    Set ws = GetSheet(SH_CONFIG)
    For r = 28 To 36
        Set cell = ws.Cells(r, 2)
        If cell.MergeCells Then
            If cell.MergeArea.Column = 2 And cell.MergeArea.Columns.Count = 3 And cell.MergeArea.Rows.Count = 1 Then cell.MergeArea.UnMerge
        End If
    Next r
End Sub

Public Sub ClearExportScopeForCase()
    NormalizeExportScopeCells
    GetSheet(SH_CONFIG).Range("C29:C33").ClearContents
End Sub

Attribute VB_Name = "modAnalysisOutput"
Option Explicit

Public Function CaptureCashFilters(ByVal ws As Worksheet) As Collection
    Dim result As New Collection, filter As Object, item As Object, i As Long, criteria As Variant
    If ws.AutoFilterMode Then
        For i = 1 To ws.AutoFilter.Filters.Count
            Set filter = ws.AutoFilter.Filters(i)
            If filter.On Then
                Set item = CreateObject("Scripting.Dictionary")
                item("field") = i: item("operator") = filter.Operator
                On Error Resume Next
                Err.Clear: criteria = Empty: criteria = filter.Criteria1
                If Err.Number = 0 Then item("first") = criteria
                Err.Clear: criteria = Empty: criteria = filter.Criteria2
                If Err.Number = 0 Then item("second") = criteria
                On Error GoTo 0
                result.Add item
            End If
        Next i
    End If
    Set CaptureCashFilters = result
End Function

Public Sub RestoreCashFilters(ByVal ws As Worksheet, ByVal filters As Collection)
    Dim item As Object, target As Range, lastR As Long
    If filters Is Nothing Then Exit Sub
    lastR = Application.Max(CashReportHeader(ws), LastRow(ws, 6))
    Set target = ws.Range("A" & CashReportHeader(ws) & ":M" & lastR)
    For Each item In filters
        If item.Exists("first") And item.Exists("second") Then
            target.AutoFilter Field:=CLng(item("field")), Criteria1:=item("first"), Operator:=CLng(item("operator")), Criteria2:=item("second")
        ElseIf item.Exists("first") Then
            target.AutoFilter Field:=CLng(item("field")), Criteria1:=item("first"), Operator:=CLng(item("operator"))
        ElseIf item.Exists("second") Then
            target.AutoFilter Field:=CLng(item("field")), Operator:=CLng(item("operator")), Criteria2:=item("second")
        End If
    Next item
End Sub

Public Function AnalysisBalanceChanges(ByVal scope As Object) As Collection
    Dim accounts As Object, points As Variant
    Set accounts = AnalysisBalanceAccounts()
    points = ReadStore(GetSheet(SH_WORK_BAL), 13)
    Set AnalysisBalanceChanges = BuildAnalysisBalanceChanges(points, accounts)
End Function

Public Function BuildAnalysisBalanceChanges(ByVal points As Variant, ByVal accounts As Object) As Collection
    Dim result As New Collection, groups As Object, bucket As Collection
    Dim key As Variant, r As Long, i As Long, j As Long, indices() As Long, nextRow As Long, item As Object
    Dim firstRow As Long, currentRow As Long
    Set groups = CreateObject("Scripting.Dictionary")
    For r = 2 To UBound(points, 1)
        key = CellText(points(r, 13))
        If accounts.Exists(key) Then
            If HasText(points(r, 10)) And IsNumeric(points(r, 10)) And IsNumeric(points(r, 8)) Then
                If Not groups.Exists(key) Then Set bucket = New Collection: groups.Add key, bucket
                Set bucket = groups(key): bucket.Add r
            End If
        End If
    Next r
    For Each key In groups.Keys
        Set bucket = groups(key)
        If bucket.Count >= 1 Then
            ReDim indices(1 To bucket.Count)
            For i = 1 To bucket.Count: indices(i) = CLng(bucket(i)): Next i
            For i = 2 To bucket.Count
                nextRow = indices(i): j = i - 1
                Do While j >= 1
                    If CDbl(points(indices(j), 8)) <= CDbl(points(nextRow, 8)) Then Exit Do
                    indices(j + 1) = indices(j): j = j - 1
                Loop
                indices(j + 1) = nextRow
            Next i
            For i = IIf(bucket.Count = 1, 1, 2) To bucket.Count
                currentRow = indices(i): firstRow = currentRow
                If i > 1 Then firstRow = indices(i - 1)
                Set item = CreateObject("Scripting.Dictionary")
                item("label") = CellText(points(currentRow, 1)) & " / " & CellText(points(currentRow, 2)) & " " & CellText(points(currentRow, 3)) & " " & CellText(points(currentRow, 4)) & " " & CellText(points(currentRow, 5))
                item("from") = points(firstRow, 8): item("to") = points(currentRow, 8)
                item("before") = CDbl(points(firstRow, 10)): item("after") = CDbl(points(currentRow, 10))
                If bucket.Count = 1 Then item("from") = Empty: item("before") = Empty
                result.Add item
            Next i
        End If
    Next key
    Set BuildAnalysisBalanceChanges = result
End Function

Public Function SaveAnalysisPath(ByVal links As String, Optional ByVal existingPath As String = "") As String
    SaveAnalysisPath = RegisterAnalysisPath(links, existingPath)
End Function

Public Sub ExportCurrentAnalysis()
    Dim items As Collection, mode As String, path As Variant, book As Workbook, ws As Worksheet, item As Object
    Dim ids As Object, uid As Variant, row As Long, started As Boolean, message As String, i As Long, details As Object, member As Object
    Dim firstMember As Boolean, pathDetails As Object, context As Object, exportPathID As String, exportGroups As Object, group As Variant
    Dim fs As Object, stage As String, backup As String, moved As Boolean, installed As Boolean, restoreIssue As String
    Dim exportNote As String, relationID As String, searchState As Collection
    On Error GoTo EH
    FlushPendingAnalysisEdits
    Set context = NewRelationContext()
    Set items = CurrentAnalysisExportItems(context): mode = CurrentAnalysisExportMode()
    If items.Count = 0 Then AnalysisPanelMessage "�o�͂���W�v�E���E�֘A�t����\�����Ă��������B": Exit Sub
    path = Application.GetSaveAsFilename(InitialFileName:="�W�v�E�֘A���.xlsx", FileFilter:="Excel �u�b�N (*.xlsx), *.xlsx", Title:="�W�v�E��r�̕ۑ���")
    If VarType(path) = vbBoolean Then Exit Sub
    If LCase$(Right$(CStr(path), 5)) <> ".xlsx" Then path = CStr(path) & ".xlsx"
    If Len(Dir$(CStr(path))) > 0 Then
        If MsgBox("�����̃t�@�C�����㏑�����܂����H", vbYesNo + vbQuestion + vbDefaultButton2) <> vbYes Then Exit Sub
    End If
    Set fs = CreateObject("Scripting.FileSystemObject")
    stage = fs.BuildPath(fs.GetParentFolderName(CStr(path)), fs.GetTempName)
    fs.CreateFolder stage
    backup = fs.BuildPath(stage, "previous.xlsx")
    Set searchState = SuspendAnalysisSearch()
    AppBegin "�W�v�E��r���o�͂��Ă��܂�...": started = True
    RefreshCurrentAnalysisScope True
    Set context = NewRelationContext()
    Set items = CurrentAnalysisExportItems(context): mode = CurrentAnalysisExportMode()
    exportNote = CurrentAnalysisExportNote(): relationID = AnalysisPanelRelationID()
    Set book = Workbooks.Add(xlWBATWorksheet): Set ws = book.Worksheets(1): ws.Name = "�W�v�E�֘A���"
    ws.Columns("A:M").NumberFormat = "@"
    ws.Range("A1").Value2 = "�o�^�ςݖ��ׂ̏W�v�E��r"
    ws.Range("A2:M2").Merge: ws.Range("A2").Value2 = Format$(Now, "yyyy/m/d hh:mm") & " / " & exportNote
    SetRowValues ws.Range("A4"), Array("�g����", "�����E����", "���t", "����", "�o��", "����", "���z�E����", "�E�v�E����", "�w��z", "���z������", "�O����t", "������t", "���e")
    row = 4
    For Each item In items
        i = i + 1
        Select Case mode
            Case "aggregate"
                row = row + 1: ws.Cells(row, 2).Value2 = item("label"): ws.Cells(row, 5).Value2 = item("out"): ws.Cells(row, 6).Value2 = item("in")
                ws.Cells(row, 7).Value2 = CDbl(item("in")) - CDbl(item("out")): ws.Cells(row, 13).Value2 = item("count") & "��"
            Case "balance"
                row = row + 1: ws.Cells(row, 2).Value2 = item("label"): ws.Cells(row, 5).Value2 = item("before"): ws.Cells(row, 6).Value2 = item("after")
                If HasText(item("before")) Then
                    ws.Cells(row, 7).Value2 = CDbl(item("after")) - CDbl(item("before"))
                    ws.Cells(row, 11).Value2 = Format$(CDbl(item("from")), "yyyy/m/d")
                Else
                    ws.Cells(row, 13).Value2 = "�o�^�c����1���_�F�����͖��v�Z"
                End If
                ws.Cells(row, 12).Value2 = Format$(CDbl(item("to")), "yyyy/m/d")
            Case "candidates"
                Set ids = AnalysisIDSet(CStr(item("ids"))): firstMember = True
                For Each uid In ids.Keys
                    row = row + 1: WriteAnalysisExportTransaction ws, row, CStr(uid), "��� " & i
                    If firstMember Then ws.Cells(row, 7).Value2 = item("difference"): firstMember = False
                    ws.Cells(row, 13).Value2 = CStr(item("shape")) & " / " & CStr(item("evidence"))
                    If CandidateHasCompetition(item) Then ws.Cells(row, 13).Value2 = "�������� / " & CellText(ws.Cells(row, 13).Value2)
                Next uid
            Case "pairs"
                row = row + 1: WriteAnalysisExportTransaction ws, row, CStr(item("from")), "�ʔz�� " & i
                ws.Cells(row, 9).Value2 = item("amount"): ws.Cells(row, 10).Value2 = AnalysisEditExportValue(item)
                Set details = RelationDetails(relationID, context)
                ws.Cells(row, 13).Value2 = "������F" & AnalysisAccountText(CStr(item("to"))) & " / " & AnalysisDateText(CStr(item("to"))) & " " & AnalysisTimeText(CStr(item("to"))) & " / " & CStr(details("status"))
                ws.Cells(row, 8).Value2 = CellText(ws.Cells(row, 8).Value2) & " / " & CStr(details("memo"))
            Case "connections"
                row = row + 1: WriteAnalysisExportTransaction ws, row, CStr(item("from")), "�ڑ����̓���"
                ws.Cells(row, 13).Value2 = "�ڑ� " & i & " / �ڑ��z�͖��w��"
                row = row + 1: WriteAnalysisExportTransaction ws, row, CStr(item("to")), "�ڑ���̏o��"
                ws.Cells(row, 13).Value2 = "�ڑ� " & i & " / �ڑ��z�͖��w��"
            Case "detail"
                If item("type") = "T" Then
                    row = row + 1: WriteAnalysisExportTransaction ws, row, CStr(item("id")), "��r"
                    If item.Exists("amount") Then ws.Cells(row, 9).Value2 = item("amount"): ws.Cells(row, 10).Value2 = AnalysisEditExportValue(item)
                    ws.Cells(row, 13).Value2 = item("status")
                    If Len(relationID) > 0 Then
                        Set details = RelationDetails(relationID, context)
                        ws.Cells(row, 8).Value2 = CellText(ws.Cells(row, 8).Value2) & " / " & CStr(details("memo"))
                        ws.Cells(row, 13).Value2 = CStr(details("status")) & " / " & CStr(item("status")) & " / " & CStr(details("sourceContext"))
                    End If
                Else
                    Set details = RelationDetails(CStr(item("id")), context)
                    ExportRelationMembers ws, row, details, "��� " & i
                    If i > 1 Then ws.Cells(row, 13).Value2 = CellText(ws.Cells(row, 13).Value2) & " / " & AnalysisPathConnectionText(item)
                End If
            Case "records"
                Set details = RelationDetails(CStr(item("id")), context)
                If details("kind") = "G" Then
                    ExportRelationMembers ws, row, details, "�֘A " & i
                Else
                    Set pathDetails = details
                    For Each member In pathDetails("rows")
                        Set details = RelationDetails(CStr(member("id")), context)
                        ExportRelationMembers ws, row, details, "�o�H " & i & " �̋��"
                        ws.Cells(row, 13).Value2 = CellText(ws.Cells(row, 13).Value2) & " / " & AnalysisPathConnectionText(member)
                    Next member
                End If
        End Select
    Next item
    If mode = "detail" And Len(relationID) > 0 Then
        Set details = RelationDetails(relationID, context)
        If details("kind") = "P" Then exportPathID = relationID
    ElseIf mode = "records" Then
        For Each item In items
            If item("kind") = "P" Then exportPathID = CStr(item("id")): Exit For
        Next item
    End If
    Set exportGroups = CreateObject("Scripting.Dictionary")
    If Len(exportPathID) > 0 Then
        ExportNetworkConnections book, exportPathID, context("data")
        Set exportGroups = AnalysisIDSet(RelationMemberKeys(exportPathID, context("data")))
    ElseIf mode = "detail" Or mode = "pairs" Then
        If Len(relationID) > 0 Then exportGroups(relationID) = True
    ElseIf mode = "records" Then
        For Each item In items
            If item("kind") = "G" Then exportGroups(CStr(item("id"))) = True
        Next item
    End If
    ExportPairAllocations book, exportGroups, context
    If mode = "balance" Then ws.Range("E4").Value2 = "�O��c��": ws.Range("F4").Value2 = "����c��"
    ws.Columns("A:A").ColumnWidth = 13: ws.Columns("B:B").ColumnWidth = 40
    ws.Columns("C:D").ColumnWidth = 12: ws.Columns("E:G").ColumnWidth = 15: ws.Columns("H:H").ColumnWidth = 30
    ws.Columns("I:M").ColumnWidth = 16
    ws.Range("A1:M" & row).Font.Name = "Yu Gothic UI": ws.Range("A1:M" & row).Font.Size = 11
    ws.Range("E5:G" & row).NumberFormat = "#,##0": ws.Range("I5:J" & row).NumberFormat = "#,##0"
    ws.Range("A2:M2").WrapText = True: ws.Rows(2).RowHeight = 54
    ws.Range("A4:M" & row).WrapText = True: ws.Rows("4:" & row).AutoFit
    FormatHeader ws.Range("A4:M4")
    ws.PageSetup.PrintArea = ws.Range("A1:M" & row).Address
    ApplyReadablePrintSettings ws, "$1:$4"
    AddAnalysisPortrait ws
    book.SaveAs Filename:=fs.BuildPath(stage, "new.xlsx"), FileFormat:=xlOpenXMLWorkbook, CreateBackup:=False
    book.Close SaveChanges:=False: Set book = Nothing
    If fs.FileExists(CStr(path)) Then fs.MoveFile CStr(path), backup: moved = True
    fs.MoveFile fs.BuildPath(stage, "new.xlsx"), CStr(path): installed = True
    On Error Resume Next
    fs.DeleteFolder stage, True
    On Error GoTo EH
    EndAppScope started
    ResumeSuspendedAnalysisSearch searchState
    AnalysisPanelMessage "�W�v�E��r���o�͂��܂����B"
    Exit Sub
EH:
    message = Err.Description
    On Error Resume Next
    If Not book Is Nothing Then book.Close SaveChanges:=False
    If Not installed And moved Then
        Err.Clear: fs.MoveFile backup, CStr(path)
        If Err.Number <> 0 Then restoreIssue = " ���t�@�C���̑ޔ��F" & backup
    End If
    If Len(stage) > 0 And Len(restoreIssue) = 0 Then fs.DeleteFolder stage, True
    EndAppScope started
    ResumeSuspendedAnalysisSearch searchState
    On Error GoTo 0
    If installed Then
        AnalysisPanelMessage "�t�@�C���͏o�͍ς݂ł��B��ʍX�V�������ł��܂���ł����B" & message
    Else
        AnalysisPanelMessage "�o�͂ł��܂���ł����B" & message & restoreIssue
    End If
End Sub

Public Function AnalysisEditExportValue(ByVal item As Object) As Variant
    Dim state As String, raw As Variant
    If item.Exists("draft") Then raw = item("draft")
    AnalysisEditExportValue = raw
    If item.Exists("editState") Then state = CellText(item("editState"))
    If state = "�����\��" Or state = "�ȑO�̓���" Then AnalysisEditExportValue = Trim$(state & " " & CellText(raw))
End Function

Private Sub WriteAnalysisExportTransaction(ByVal ws As Worksheet, ByVal row As Long, ByVal uid As String, ByVal label As String)
    ws.Cells(row, 1).Value2 = label: ws.Cells(row, 2).Value2 = AnalysisAccountText(uid)
    ws.Cells(row, 3).Value2 = AnalysisDateText(uid): ws.Cells(row, 4).Value2 = AnalysisTimeText(uid)
    ws.Cells(row, 5).Value2 = AnalysisValue(uid, 8): ws.Cells(row, 6).Value2 = AnalysisValue(uid, 9): ws.Cells(row, 8).Value2 = AnalysisValue(uid, 12)
    If Len(AnalysisSourceText(uid)) > 0 Then ws.Cells(row, 8).Value2 = CellText(ws.Cells(row, 8).Value2) & " / �o�T�F" & AnalysisSourceText(uid)
End Sub

Private Sub ExportRelationMembers(ByVal ws As Worksheet, ByRef row As Long, ByVal details As Object, ByVal label As String)
    Dim member As Object
    For Each member In details("rows")
        If member("type") = "T" Then
            row = row + 1: WriteAnalysisExportTransaction ws, row, CStr(member("id")), label
            ws.Cells(row, 9).Value2 = member("amount"): ws.Cells(row, 10).Value2 = AnalysisEditExportValue(member)
            ws.Cells(row, 8).Value2 = CellText(ws.Cells(row, 8).Value2) & " / " & CStr(details("memo"))
            ws.Cells(row, 13).Value2 = CStr(details("status")) & " / " & CStr(details("sourceContext"))
        End If
    Next member
End Sub

Public Sub TryInstallAnalysisPanel(Optional ByVal filters As Collection = Nothing)
    Dim original As Worksheet, snapshots As New Collection, snapshot As Collection, shopSnapshot As Collection
    Dim started As Boolean, writing As Boolean, insertedRows As Long, oldHeader As Long, issue As String, restoring As String
    On Error GoTo EH
    Set original = GetSheet(SH_OUTPUT_TX): oldHeader = CashReportHeader(original)
    If oldHeader = ANALYSIS_PANEL_ROWS + 1 Then Exit Sub
    If filters Is Nothing Then Set filters = CaptureCashFilters(original)
    AppBegin: started = True
    Set snapshot = CaptureOutputSnapshot(original): snapshots.Add snapshot
    If SheetExists(SH_SHOP_TARGET) Then
        Set shopSnapshot = CaptureOutputSnapshot(GetSheet(SH_SHOP_TARGET)): snapshots.Add shopSnapshot
    End If
    writing = True
    AttachAnalysisPanel original, insertedRows
    RestoreCashFilters original, filters
    RefreshShopRowReferences
    writing = False
    DeleteOutputSnapshots snapshots
    EndAppScope started
    Exit Sub
EH:
    issue = Err.Description
    On Error Resume Next
    If writing Then
        Err.Clear
        original.Unprotect Password:=TOOL_PASSWORD
        If insertedRows > 0 Then original.Rows(oldHeader & ":" & oldHeader + insertedRows - 1).Delete Shift:=xlUp
        If Err.Number <> 0 Then restoring = " �s�ʒu": Err.Clear
        RestoreOutputSnapshot original, snapshot
        If Err.Number <> 0 Then restoring = restoring & " ��������\": Err.Clear
        If Not shopSnapshot Is Nothing Then RestoreOutputSnapshot GetSheet(SH_SHOP_TARGET), shopSnapshot
        If Err.Number <> 0 Then restoring = restoring & " �戵�X�ꗗ"
    End If
    If Len(restoring) = 0 Then DeleteOutputSnapshots snapshots
    ResetAnalysisSelectionCache
    EndAppScope started
    Application.StatusBar = "���͗���\���ł��܂���ł����B " & issue
    If Len(restoring) > 0 Then Application.StatusBar = "���[�\���̕����������F" & restoring & "�B�ޔ��V�[�g��ێ����Ă��܂��B " & issue
    On Error GoTo 0
End Sub

Public Function AnalysisBalanceAccounts() As Object
    Dim result As Object, accounts As Variant, filters As Collection, r As Long, values As Variant
    Set result = CreateObject("Scripting.Dictionary")
    accounts = ReadStore(GetSheet(SH_ACCOUNTS), 10)
    Set filters = CaptureCashFilters(GetSheet(SH_OUTPUT_TX))
    For r = 2 To UBound(accounts, 1)
        values = Array(accounts(r, 2), accounts(r, 3), DisplayPersonWithRelationship(CellText(accounts(r, 4)), CellText(accounts(r, 5))), accounts(r, 6), accounts(r, 7))
        If AccountMatchesCashFilters(values, filters) Then result(CellText(accounts(r, 1))) = True
    Next r
    Set AnalysisBalanceAccounts = result
End Function

Public Function AccountMatchesCashFilters(ByVal values As Variant, ByVal filters As Collection) As Boolean
    Dim item As Object, field As Long, op As Long, firstMatch As Boolean, secondMatch As Boolean, value As String
    For Each item In filters
        field = CLng(item("field"))
        op = CLng(item("operator"))
        If field >= 1 And field <= 5 And (op = 0 Or op = xlAnd Or op = xlOr Or op = xlFilterValues) Then
            value = CellText(values(field - 1))
            firstMatch = True: secondMatch = True
            If item.Exists("first") Then firstMatch = CashCriterionMatches(value, item("first"))
            If item.Exists("second") Then secondMatch = CashCriterionMatches(value, item("second"))
            If op = xlOr Then
                If Not firstMatch And Not secondMatch Then Exit Function
            Else
                If Not firstMatch Or Not secondMatch Then Exit Function
            End If
        End If
    Next item
    AccountMatchesCashFilters = True
End Function

Public Function CashCriterionMatches(ByVal value As String, ByVal criterion As Variant) As Boolean
    Dim part As Variant, text As String, op As String, comparison As Long
    If IsArray(criterion) Then
        For Each part In criterion
            If StrComp(value, CellText(part), vbTextCompare) = 0 Then CashCriterionMatches = True: Exit Function
        Next part
        Exit Function
    End If
    text = CellText(criterion): op = "="
    If Left$(text, 2) = "<>" Or Left$(text, 2) = ">=" Or Left$(text, 2) = "<=" Then
        op = Left$(text, 2): text = Mid$(text, 3)
    ElseIf Left$(text, 1) = "=" Or Left$(text, 1) = ">" Or Left$(text, 1) = "<" Then
        op = Left$(text, 1): text = Mid$(text, 2)
    End If
    If op = "=" Or op = "<>" Then
        CashCriterionMatches = (LCase$(value) Like LCase$(CashWildcardPattern(text)))
        If op = "<>" Then CashCriterionMatches = Not CashCriterionMatches
        Exit Function
    End If
    comparison = StrComp(value, text, vbTextCompare)
    Select Case op
        Case ">": CashCriterionMatches = comparison > 0
        Case "<": CashCriterionMatches = comparison < 0
        Case ">=": CashCriterionMatches = comparison >= 0
        Case "<=": CashCriterionMatches = comparison <= 0
    End Select
End Function

Private Function CashWildcardPattern(ByVal text As String) As String
    Dim i As Long, ch As String, escaped As Boolean, pattern As String
    For i = 1 To Len(text)
        ch = Mid$(text, i, 1)
        If ch = "~" And Not escaped And i < Len(text) Then
            escaped = True
        Else
            Select Case ch
                Case "[": pattern = pattern & "[[]"
                Case "#": pattern = pattern & "[#]"
                Case "*", "?"
                    If escaped Then pattern = pattern & "[" & ch & "]" Else pattern = pattern & ch
                Case Else: pattern = pattern & ch
            End Select
            escaped = False
        End If
    Next i
    CashWildcardPattern = pattern
End Function

Public Function AnalysisPathConnectionText(ByVal member As Object) As String
    Dim fromID As String, toID As String
    fromID = CStr(member("from")): toID = CStr(member("to"))
    If Len(fromID) = 0 Or Len(toID) = 0 Then AnalysisPathConnectionText = "�ڑ��_�̋L�^�Ȃ�": Exit Function
    If Not AnalysisIDs().Exists(fromID) Or Not AnalysisIDs().Exists(toID) Then AnalysisPathConnectionText = "�ڑ��_�̌����ׂ͍폜�ς�": Exit Function
    AnalysisPathConnectionText = "�N�_���� " & AnalysisDateText(fromID) & " " & AnalysisTimeText(fromID) & " " & Format$(AnalysisAmount(fromID), "#,##0") & "�~ / ���̏o�� " & AnalysisDateText(toID) & " " & AnalysisTimeText(toID) & " " & Format$(AnalysisAmount(toID), "#,##0") & "�~"
    If AnalysisSide(fromID) <> "D" Or AnalysisSide(toID) <> "W" Or CellText(AnalysisValue(fromID, TX_ID_COL)) <> CellText(AnalysisValue(toID, TX_ID_COL)) Then AnalysisPathConnectionText = AnalysisPathConnectionText & "�i�ڑ��_�̓��e����������Ă��܂��j"
End Function

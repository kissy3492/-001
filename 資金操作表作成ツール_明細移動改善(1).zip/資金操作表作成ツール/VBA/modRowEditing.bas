Attribute VB_Name = "modRowEditing"
Option Explicit

Public Sub ClearInputUndo()
    ResetInputHistory
End Sub

Public Function InputUndoCaption() As String
    InputUndoCaption = InputHistoryUndoText()
End Function

Public Function InputRedoCaption() As String
    InputRedoCaption = InputHistoryRedoText()
End Function

Public Sub KeepInputUndo(ByVal state As Collection, ByVal caption As String, ByVal addressText As String)
    KeepInputHistory state, caption, addressText
End Sub

Public Sub UndoInputOperation()
    UndoInputHistory
End Sub

Public Sub RedoInputOperation()
    RedoInputHistory
End Sub

Public Sub InsertTransactionRows()
    EditTransactionSelection "insert"
End Sub

Public Sub DuplicateTransactionRows()
    EditTransactionSelection "duplicate"
End Sub

Public Sub DeleteTransactionRows()
    EditTransactionSelection "delete"
End Sub

Public Sub ClearSelectedTransactionRows()
    EditTransactionSelection "clear"
End Sub

Public Sub CopyPreviousSelectedFields()
    EditTransactionSelection "copy"
End Sub

Public Sub SwapSelectedAmounts()
    EditTransactionSelection "swap"
End Sub

Public Function TransactionSelection() As Range
    If Not ActiveWorkbook Is ThisWorkbook Then Exit Function
    If ActiveSheet.Name <> SH_INPUT Then Exit Function
    If TypeName(Selection) <> "Range" Then Exit Function
    If Selection.Areas.Count <> 1 Then Exit Function
    Set TransactionSelection = Intersect(Selection, InputTransactionRange())
End Function

Private Sub EditTransactionSelection(ByVal operation As String)
    Dim chosen As Range, ws As Worksheet, state As Collection, raw As Variant, normalized As Variant
    Dim first As Long, count As Long, last As Long, n As Long, r As Long, c As Long, insertAt As Long
    Dim caption As String, addressText As String, token As Variant, other As Variant, allowed As Boolean
    Dim appStarted As Boolean, writing As Boolean, message As String, structural As Boolean, references As Object
    Dim affected As Range, structureApplied As Boolean, selectedRow As Long, selectedCol As Long, selectedCols As Long
    On Error GoTo EH
    Set chosen = TransactionSelection()
    If chosen Is Nothing Then
        MsgBox "���ׂ̑Ώۍs��I�����Ă��������B�����s���܂Ƃ߂đI�ׂ܂��B", vbInformation
        Exit Sub
    End If
    Set ws = chosen.Worksheet
    selectedRow = chosen.Row: selectedCol = chosen.Column: selectedCols = chosen.Columns.Count
    first = selectedRow - TX_FIRST_ROW + 1: count = chosen.Rows.Count
    last = LastInputDataRow() - TX_FIRST_ROW + 1
    If operation <> "insert" And first > last And operation <> "copy" Then Exit Sub
    n = Application.Max(1, last, first + count - 1)
    structural = (operation = "insert" Or operation = "duplicate" Or operation = "delete")
    If operation = "insert" Or operation = "duplicate" Then
        If n + count > ws.Rows.Count - TX_FIRST_ROW + 1 Then Err.Raise vbObjectError + 3003, , "�I�������s����}�������Excel�̍s���𒴂��܂��B"
    End If
    Select Case operation
        Case "insert": caption = "���ׂ̑}��"
        Case "duplicate": caption = "���ׂ̕���"
        Case "delete": caption = "���ׂ̍폜"
        Case "clear": caption = "���ׂ̓��e����"
        Case "swap": caption = "�o���E�����̓���ւ�"
        Case "copy"
            caption = "�O�s����̃R�s�["
            If first = 1 Then Exit Sub
            For c = selectedCol To selectedCol + selectedCols - 1
                If c >= COL_TX_SHOP And c <= COL_TX_OTHER Then allowed = True
            Next c
            If Not allowed Then
                MsgBox "�戵�X�E�@�ԁE�E�v�E���̑�����A�R�s�[���鍀�ڂ�I��ł��������B", vbInformation
                Exit Sub
            End If
        Case Else: Exit Sub
    End Select
    Set affected = ws.Cells(selectedRow, COL_TX_YEAR).Resize(count, 11)
    If structural Then Set affected = ws.Cells(selectedRow, COL_TX_YEAR).Resize(n - first + 1, 11)
    RequireIndependentInputCells affected
    If operation = "copy" Then RequireIndependentInputCells ws.Cells(selectedRow - 1, selectedCol).Resize(1, selectedCols)
    addressText = chosen.Cells(1, 1).Address
    AppBegin caption & "�𔽉f���Ă��܂�...": appStarted = True
    Set state = CaptureInputState(False)
    If structural Then
        Set references = ReadWorkbookFormulaReferences()
        state.Add references, "references"
    End If
    raw = state("transactions"): normalized = raw
    If operation = "insert" Or operation = "duplicate" Then PreserveFollowingContext normalized, first
    If operation = "duplicate" Or operation = "delete" Or operation = "clear" Then PreserveFollowingContext normalized, first + count
    writing = True
    EnsureTransactionCapacity n + IIf(operation = "insert" Or operation = "duplicate", count, 0) + 1
    ws.Unprotect Password:=TOOL_PASSWORD
    ApplyRowContextValues ws, raw, normalized
    Select Case operation
        Case "insert", "duplicate"
            insertAt = selectedRow
            If operation = "duplicate" Then insertAt = insertAt + count
            ws.Cells(insertAt, COL_TX_YEAR).Resize(count, 11).Insert Shift:=xlDown
            structureApplied = True
            ws.Cells(insertAt, COL_TX_YEAR).Resize(count, 11).ClearContents
            If operation = "duplicate" Then
                ws.Cells(selectedRow, COL_TX_YEAR).Resize(count, 10).Copy Destination:=ws.Cells(insertAt, COL_TX_YEAR)
                For r = insertAt To insertAt + count - 1: ws.Cells(r, INPUT_UID_COL).Value2 = NewInternalID("T"): Next r
            End If
        Case "delete"
            insertAt = selectedRow
            ws.Cells(insertAt, COL_TX_YEAR).Resize(count, 11).Delete Shift:=xlUp
            structureApplied = True
        Case "clear"
            ws.Cells(selectedRow, COL_TX_YEAR).Resize(count, 11).ClearContents
        Case "copy"
            For c = selectedCol To selectedCol + selectedCols - 1
                If c >= COL_TX_SHOP And c <= COL_TX_OTHER Then
                    token = InputCellToken(ws.Cells(selectedRow - 1, c))
                    For r = selectedRow To selectedRow + count - 1: WriteInputCellToken ws.Cells(r, c), token, True: Next r
                End If
            Next c
        Case "swap"
            For r = selectedRow To selectedRow + count - 1
                token = InputCellToken(ws.Cells(r, COL_TX_WITHDRAW)): other = InputCellToken(ws.Cells(r, COL_TX_DEPOSIT))
                WriteInputCellToken ws.Cells(r, COL_TX_WITHDRAW), other
                WriteInputCellToken ws.Cells(r, COL_TX_DEPOSIT), token
            Next r
    End Select
    If structural Then
        ResetInputMoveAnchor
        ApplyInputSettings False
    End If
    Set affected = ws.Cells(selectedRow, COL_TX_YEAR).Resize(Application.Max(count, LastInputDataRow() - selectedRow + 1), 10)
    OnInputChange affected
    ResetInputNavigation
    SafeSelectCell ws, addressText
    KeepInputUndo state, caption, addressText
    writing = False
    SetInputStatus caption & "���s���܂����B" & IIf(Len(InputUndoCaption()) > 0, "���ɖ߂��E��蒼�����g���܂��B", "�����������͋L�^�ł��܂���ł����B���͕͂ێ����Ă��܂��B")
    EndAppScope appStarted
    RefreshInputHistoryCommands
    Exit Sub
EH:
    message = Err.Description
    On Error Resume Next
    If writing Then
        Err.Clear
        If structureApplied Then
            If operation = "delete" Then
                ws.Cells(insertAt, COL_TX_YEAR).Resize(count, 11).Insert Shift:=xlDown
            Else
                ws.Cells(insertAt, COL_TX_YEAR).Resize(count, 11).Delete Shift:=xlUp
            End If
        End If
        RestoreInputState state
        If Not references Is Nothing Then RestoreFormulaReferences references
        If Err.Number <> 0 Then message = message & vbCrLf & "���͂̕������������ł��B�ۑ��ς݂̃u�b�N�͕ێ����Ă��������B"
    End If
    EndAppScope appStarted
    On Error GoTo 0
    MsgBox "���ב���������ł��܂���ł����B" & vbCrLf & message, vbExclamation
End Sub

Private Sub ApplyRowContextValues(ByVal ws As Worksheet, ByVal before As Variant, ByVal after As Variant)
    Dim r As Long, field As Variant, cell As Range
    For r = 1 To UBound(before, 1)
        For Each field In Array(1, 2, 3, 9)
            If Not InputValuesEqual(before(r, CLng(field)), after(r, CLng(field))) Then
                Set cell = ws.Cells(TX_FIRST_ROW + r - 1, COL_TX_YEAR + CLng(field) - 1)
                If Not cell.HasFormula Then
                    RequireIndependentInputCells cell
                    WriteInputCellToken cell, Array(after(r, CLng(field)), "")
                End If
            End If
        Next field
    Next r
End Sub

Public Sub PreserveFollowingContext(ByRef data As Variant, ByVal boundary As Long)
    Dim r As Long, c As Long, cy As Long, cm As Long, cd As Long, ok As Boolean
    Dim d As Variant, memo As String, text As String, hasValues As Boolean, yearAdd As Long
    Dim dateFixed As Boolean, memoFixed As Boolean
    yearAdd = InputYearAdd()
    For r = 1 To UBound(data, 1)
        d = ResolveInputDate(data(r, 1), data(r, 2), data(r, 3), cy, cm, cd, yearAdd, ok)
        text = CellText(data(r, 9))
        If IsError(data(r, 9)) Then
            memo = ""
        ElseIf Len(text) > 0 And text <> "����" Then
            memo = text
        End If
        If r >= boundary Then
            hasValues = False
            For c = 1 To 10
                If IsError(data(r, c)) Or HasText(data(r, c)) Then hasValues = True: Exit For
            Next c
            If hasValues And Not dateFixed Then
                If ok Then
                    data(r, 1) = cy: data(r, 2) = cm: data(r, 3) = cd
                Else
                    '���m�萬���́A�ړ���̑O�s�������ĕ⊮���Ȃ��B
                    If Not IsError(data(r, 1)) And Not HasText(data(r, 1)) Then data(r, 1) = IIf(cy <> 0, cy, "�s��")
                    If Not IsError(data(r, 2)) And Not HasText(data(r, 2)) Then data(r, 2) = IIf(cm <> 0, cm, "�s��")
                    If Not IsError(data(r, 3)) And Not HasText(data(r, 3)) Then data(r, 3) = IIf(cd <> 0, cd, "�s��")
                End If
                dateFixed = True
            End If
            '���t�̂���擪�s�œE�v����ł��A���̐�́u����v�܂œƗ����Ď��B
            If Not memoFixed Then
                If IsError(data(r, 9)) Then
                    memoFixed = True
                ElseIf Len(text) > 0 Then
                    If text = "����" Then data(r, 9) = IIf(Len(memo) > 0, memo, "�s��")
                    memoFixed = True
                End If
            End If
            If dateFixed And memoFixed Then Exit Sub
        End If
    Next r
End Sub

Attribute VB_Name = "modFinalExport"
Option Explicit

Public Sub ExportFinalWorkbooks()
    ExportWorkbooksCore False
End Sub

Public Sub ExportFilteredWorkbooks()
    ExportWorkbooksCore True
End Sub

Private Sub ExportWorkbooksCore(ByVal filtered As Boolean)
    Dim appStarted As Boolean
    Dim folder As String, stage As String, names As Variant, paths(0 To 1) As String, backups(0 To 1) As String
    Dim installed(0 To 1) As Boolean, moved(0 To 1) As Boolean, i As Long
    Dim fd As FileDialog, fs As Object, message As String, restoreMessage As String
    Dim committed As Boolean, prefix As String, count As Long, temporary(0 To 1) As Worksheet, source(0 To 1) As Worksheet
    If Not RequireToolReady() Then Exit Sub

    On Error GoTo EH
    EnsureAccountStore
    If LastRow(GetSheet(SH_ACCOUNTS)) < 2 Then MsgBox "�o�͂���������o�^����Ă��܂���B", vbInformation: Exit Sub
    ClearExportScope
    If filtered Then
        count = PrepareExportScope(prefix)
    End If
    Set fd = Application.FileDialog(msoFileDialogFolderPicker)
    fd.Title = "Excel�t�@�C���̕ۑ���"
    If filtered Then fd.Title = count & "�������w������ŏo�́F�ۑ���"
    If fd.Show <> -1 Then ClearExportScope: Exit Sub
    folder = fd.SelectedItems(1)
    Set fs = CreateObject("Scripting.FileSystemObject")
    names = Array(prefix & "01_��������\.xlsx", prefix & "02_�c�����ڕ\.xlsx")
    For i = 0 To 1
        paths(i) = fs.BuildPath(folder, CStr(names(i)))
        If fs.FileExists(paths(i)) Then message = message & CStr(names(i)) & vbCrLf
    Next i
    If Len(message) > 0 Then
        If MsgBox("�����̃t�@�C�����㏑�����܂����H" & vbCrLf & message, vbYesNo + vbQuestion + vbDefaultButton2) <> vbYes Then ClearExportScope: Exit Sub
    End If
    AppBegin "Excel�t�@�C�����쐬���Ă��܂�..."
    appStarted = True
    Set source(0) = GetSheet(SH_OUTPUT_TX): Set source(1) = GetSheet(SH_OUTPUT_BAL)
    For i = 0 To 1
        source(i).Copy After:=ThisWorkbook.Sheets(ThisWorkbook.Sheets.Count)
        Set temporary(i) = ThisWorkbook.Worksheets(ThisWorkbook.Sheets.Count)
        Set source(i) = temporary(i)
    Next i
    SetExportScopeActive filtered
    BuildCashOperationSheetCore False, source(0), False
    ApplyShopNamesToOutput source(0)
    BuildBalanceTransitionSheetCore False, source(1)
    SetExportScopeActive False
    stage = fs.BuildPath(folder, fs.GetTempName)
    fs.CreateFolder stage
    ExportOneSheetAsXlsx source(0), "��������\", fs.BuildPath(stage, CStr(names(0)))
    ExportOneSheetAsXlsx source(1), "�c�����ڕ\", fs.BuildPath(stage, CStr(names(1)))
    '2�t�@�C���Ƃ��ۑ����I���Ă�������t�@�C�������ւ���B
    For i = 0 To 1
        backups(i) = fs.BuildPath(stage, CStr(i) & ".bak")
        If fs.FileExists(paths(i)) Then
            fs.MoveFile paths(i), backups(i): moved(i) = True
        End If
        fs.MoveFile fs.BuildPath(stage, CStr(names(i))), paths(i): installed(i) = True
    Next i
    committed = True
    ClearExportScope
    On Error Resume Next
    GetSheet(SH_INPUT).Activate
    For i = 0 To 1
        If Not temporary(i) Is Nothing Then
            temporary(i).Visible = xlSheetVeryHidden
            temporary(i).Delete
        End If
    Next i
    fs.DeleteFolder stage, True
    On Error GoTo EH
    EndAppScope appStarted
    ShowInputSheet
    SetInputStatus "Excel�o�͂��������܂����B�@" & folder
    Exit Sub
EH:
    message = Err.Description
    ClearExportScope
    On Error Resume Next
    GetSheet(SH_INPUT).Activate
    For i = 0 To 1
        If Not temporary(i) Is Nothing Then
            temporary(i).Visible = xlSheetVeryHidden
            temporary(i).Delete
        End If
    Next i
    If Not committed And Not fs Is Nothing Then
        For i = 1 To 0 Step -1
            Err.Clear
            If installed(i) Then fs.DeleteFile paths(i), True
            If Err.Number <> 0 Then restoreMessage = restoreMessage & CStr(names(i)) & "�i�V�K�t�@�C���̏����j "
            Err.Clear
            If moved(i) Then fs.MoveFile backups(i), paths(i)
            If Err.Number <> 0 Then restoreMessage = restoreMessage & CStr(names(i)) & "�i���t�@�C���̕����j "
        Next i
        If Len(stage) > 0 And Len(restoreMessage) = 0 Then fs.DeleteFolder stage, True
    End If
    EndAppScope appStarted
    On Error GoTo 0
    If Len(restoreMessage) > 0 Then
        message = message & vbCrLf & "�����ł��Ȃ������t�@�C���F" & restoreMessage & vbCrLf & "���t�@�C���̑ޔ��F" & stage
    End If
    If committed Then
        MsgBox "Excel�t�@�C���̏o�͂͊������܂����B��ʂ̍X�V�������ł��܂���ł����B" & vbCrLf & folder & vbCrLf & message, vbExclamation
    Else
        MsgBox "Excel�o�͂������ł��܂���ł����B" & vbCrLf & message, vbExclamation
    End If
End Sub

Private Sub ExportOneSheetAsXlsx(ByVal src As Worksheet, ByVal sheetName As String, ByVal savePath As String)
    Dim wb As Workbook, ws As Worksheet, e As Long, message As String
    On Error GoTo EH
    src.Copy
    Set wb = ActiveWorkbook: Set ws = wb.Worksheets(1)
    ws.Name = sheetName
    ws.Unprotect Password:=TOOL_PASSWORD
    DeleteToolShapes ws, True
    ws.Columns("N:T").Delete
    ws.Calculate
    ws.Range("A1").Select
    wb.SaveAs Filename:=savePath, FileFormat:=xlOpenXMLWorkbook, CreateBackup:=False
    wb.Close SaveChanges:=False
    Exit Sub
EH:
    e = Err.Number: message = Err.Description
    On Error Resume Next
    If Not wb Is Nothing Then wb.Close SaveChanges:=False
    On Error GoTo 0
    Err.Raise e, "ExportOneSheetAsXlsx", message
End Sub

Attribute VB_Name = "modUI"
Option Explicit

Private mButtonSeq As Long

Public Sub BuildOperationPanel(ByVal ws As Worksheet)
    Dim x As Double, y As Double, w As Double, gap As Double, bw As Double, i As Long
    Dim captions As Variant, actions As Variant, caption As String, nextCaption As String
    If ws Is Nothing Then Exit Sub
    ws.Unprotect Password:=TOOL_PASSWORD
    For i = ws.Shapes.Count To 1 Step -1
        If Left$(ws.Shapes(i).Name, Len(UI_PREFIX)) = UI_PREFIX And ws.Shapes(i).Name <> UI_PREFIX & "balance_page" Then ws.Shapes(i).Delete
    Next i
    PolishInputLayout ws
    ApplyInputVisualStyle ws
    mButtonSeq = 0
    x = ws.Range("B3").Left: y = ws.Range("B3").Top + 3
    gap = 6: w = ws.Range("B3:K3").Width: bw = (w - gap * 6) / 7
    caption = "�]�L���Ď���"
    If Len(CurrentEditAccountID()) > 0 Then caption = "�����𔽉f"
    nextCaption = IIf(Len(CurrentEditAccountID()) > 0, "���f���Ď��}��", "�]�L���Ď��}��")
    captions = Array(caption, nextCaption, "�o�^����", "���[��\��", "Excel�o��", "�ۑ�", "�ݒ�")
    actions = Array("TransferCurrentAccount", "TransferCurrentAccountNextBranch", "ShowRegisteredAccounts", "BuildAllOutputSheets", "ShowExportOptions", "SaveToolWorkbook", "ShowConfigSheet")
    For i = 0 To 6
        AddUIButton ws, x + i * (bw + gap), y, bw, 29, CStr(captions(i)), CStr(actions(i)), IIf(i = 0, "primary", "tool")
    Next i
    ws.Range("B7:K7").UnMerge
    MergeAndFormat ws.Range("B7:G7"), ""
    MergeAndFormat ws.Range("H7:K7"), ""
    ws.Range("B7:K7").WrapText = False
    ws.Range("B7:K7").Borders.LineStyle = xlNone
    RefreshFileSaveLabel
    LockToolShapes ws
    ApplyInputSections ws
    ws.Range("X14").Value2 = "10"
End Sub

Public Sub AddPanelBack(ByVal ws As Worksheet, ByVal x As Double, ByVal y As Double, ByVal w As Double, ByVal h As Double)
    Dim shp As Shape
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    Set shp = ws.Shapes.AddShape(msoShapeRoundedRectangle, x, y, w, h)
    If Not shp Is Nothing Then
        With shp
            .Name = UI_PREFIX & "panel_back"
            .Fill.ForeColor.RGB = RGB(255, 255, 255)
            .Line.ForeColor.RGB = RGB(203, 213, 225)
            .Line.Weight = 1
            '�p�l���w�i�͌�h���b�O�œ����Ȃ��悤���b�N����B
            'xlMove�ɂ��āA�񕝒������ɃJ�[�h���s�p�ӂɐL�k���Ȃ��悤�ɂ���B
            .Placement = xlMoveAndSize
            .Locked = True
            .ZOrder msoSendToBack
            .Shadow.Visible = msoTrue
            .Shadow.Transparency = 0.88
            .Shadow.Blur = 7
            .Shadow.OffsetX = 0
            .Shadow.OffsetY = 2
        End With
    End If
    On Error GoTo 0
End Sub

Public Sub AddUIButton(ByVal ws As Worksheet, ByVal x As Double, ByVal y As Double, ByVal w As Double, ByVal h As Double, ByVal caption As String, ByVal macroName As String, ByVal styleName As String)
    Dim shp As Shape
    Dim btn As Object, creationError As String
    Dim fillColor As Long, lineColor As Long, fontColor As Long
    If ws Is Nothing Then Exit Sub
    GetButtonColors styleName, fillColor, lineColor, fontColor
    If IsLightExcelColor(fillColor) And IsLightExcelColor(fontColor) Then fontColor = RGB(15, 23, 42)
    On Error Resume Next
    Set shp = ws.Shapes.AddShape(msoShapeRoundedRectangle, x, y, w, h)
    If Not shp Is Nothing Then
        mButtonSeq = mButtonSeq + 1
        With shp
            .TextFrame.Characters.Text = caption
            .TextFrame.HorizontalAlignment = xlHAlignCenter
            .TextFrame.VerticalAlignment = xlVAlignCenter
            .TextFrame.MarginLeft = 2
            .TextFrame.MarginRight = 2
            .TextFrame.MarginTop = 0
            .TextFrame.MarginBottom = 0
            .TextFrame.Characters.Font.Name = "Yu Gothic UI"
            .TextFrame.Characters.Font.Size = 10.5
            .TextFrame.Characters.Font.Bold = True
            .TextFrame.Characters.Font.Color = fontColor
            .Fill.ForeColor.RGB = fillColor
            .Line.ForeColor.RGB = lineColor
            .Line.Weight = 0.8
            '�p�l���w�i�͌�h���b�O�œ����Ȃ��悤���b�N����B
            'xlMove�ɂ��āA�񕝒������ɃJ�[�h���s�p�ӂɐL�k���Ȃ��悤�ɂ���B
            .Placement = xlMoveAndSize
            .Locked = True
            .DrawingObject.PrintObject = False
            .Shadow.Visible = msoFalse
        End With
        On Error GoTo 0
        shp.Name = UI_PREFIX & "btn_" & CStr(mButtonSeq)
        shp.AlternativeText = macroName
        AssignToolButtonAction shp, macroName
        Exit Sub
    End If
    Err.Clear
    Set btn = ws.Buttons.Add(x, y, w, h)
    If btn Is Nothing Then
        creationError = Err.Description
        On Error GoTo 0
        Err.Raise vbObjectError + 2803, "AddUIButton", "�{�^���u" & caption & "�v���쐬�ł��܂���ł����B" & creationError
    End If
    On Error GoTo 0
    btn.Caption = caption
    mButtonSeq = mButtonSeq + 1
    Set shp = ws.Shapes(btn.Name)
    shp.Name = UI_PREFIX & "btn_" & CStr(mButtonSeq)
    shp.AlternativeText = macroName
    AssignToolButtonAction shp, macroName
    shp.Locked = True: shp.Placement = xlMoveAndSize
    shp.DrawingObject.PrintObject = False
End Sub

Private Sub GetButtonColors(ByVal styleName As String, ByRef fillColor As Long, ByRef lineColor As Long, ByRef fontColor As Long)
    fontColor = RGB(15, 23, 42)
    Select Case LCase$(styleName)
        Case "hero"
            fillColor = RGB(20, 184, 166)
            lineColor = RGB(13, 148, 136)
            fontColor = RGB(255, 255, 255)
        Case "primary"
            fillColor = RGB(37, 99, 235)
            lineColor = RGB(29, 78, 216)
            fontColor = RGB(255, 255, 255)
        Case "accent"
            fillColor = RGB(14, 165, 233)
            lineColor = RGB(2, 132, 199)
            fontColor = RGB(255, 255, 255)
        Case "export"
            fillColor = RGB(124, 58, 237)
            lineColor = RGB(109, 40, 217)
            fontColor = RGB(255, 255, 255)
        Case "danger"
            fillColor = RGB(239, 68, 68)
            lineColor = RGB(220, 38, 38)
            fontColor = RGB(255, 255, 255)
        Case "neutral"
            fillColor = RGB(241, 245, 249)
            lineColor = RGB(203, 213, 225)
            fontColor = RGB(15, 23, 42)
        Case "tool"
            fillColor = RGB(255, 255, 255)
            lineColor = RGB(203, 213, 225)
            fontColor = RGB(30, 64, 175)
        Case "soft"
            fillColor = RGB(248, 250, 252)
            lineColor = RGB(226, 232, 240)
            fontColor = RGB(51, 65, 85)
        Case Else
            fillColor = RGB(248, 250, 252)
            lineColor = RGB(203, 213, 225)
            fontColor = RGB(15, 23, 42)
    End Select
End Sub

Public Sub AddConfigButton(ByVal ws As Worksheet, ByVal cellAddress As String, ByVal caption As String, ByVal macroName As String)
    Dim a As Range
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    Set a = ws.Range(cellAddress)
    On Error GoTo 0
    If a Is Nothing Then Exit Sub
    AddUIButton ws, a.Left, a.Top, 150, 28, caption, macroName, "tool"
End Sub

Public Sub BuildInputHelpCards(ByVal ws As Worksheet)
    If ws Is Nothing Then Exit Sub
    ws.Range("M2:T14").ClearContents
End Sub

Public Sub RefreshButtonActions(Optional ByVal targetBookName As String = "")
    Dim ws As Worksheet, issue As String, allIssues As String, started As Boolean
    Dim errorText As String
    On Error GoTo EH
    AppBegin "����{�^����ݒ肵�Ă��܂�...", False: started = True
    For Each ws In ThisWorkbook.Worksheets
        issue = RefreshSheetButtonActions(ws, targetBookName)
        If Len(issue) > 0 Then allIssues = allIssues & vbCrLf & issue
    Next ws
    EndAppScope started
    If Len(allIssues) > 0 Then
        Err.Raise vbObjectError + 2802, "RefreshButtonActions", "����{�^���̐ݒ���ꕔ�����ł��܂���ł����B" & allIssues
    End If
    Exit Sub
EH:
    errorText = Err.Description
    Resume Recover
Recover:
    On Error Resume Next
    EndAppScope started
    On Error GoTo 0
    Err.Raise vbObjectError + 2802, "RefreshButtonActions", errorText
End Sub

Private Function RefreshSheetButtonActions(ByVal ws As Worksheet, ByVal targetBookName As String) As String
    Dim shp As Shape, macroName As String, currentAction As String, desired As String
    Dim protection As Variant, restoreProtection As Boolean, issue As String, allIssues As String
    Dim oldWindow As Window, oldSheet As Object, oldVisible As XlSheetVisibility
    Dim contextChanged As Boolean, stepText As String, shapeName As String, actionRead As Boolean
    On Error GoTo EH
    If ws.Shapes.Count = 0 Then Exit Function
    For Each shp In ws.Shapes
        shapeName = "": macroName = "": stepText = "�{�^���̊m�F"
        shapeName = shp.Name
        issue = "": macroName = ReadToolButtonMacro(shp, issue)
        If Len(issue) > 0 Then
            '���m�{�^���̏��擾���ی�ɑj�܂ꂽ�ꍇ�́A������ɓǂݒ����B
            stepText = "�{�^������ǂނ��߂̕ی����"
            If Not restoreProtection Then
                protection = CaptureButtonProtection(ws)
                If IsArray(protection) Then
                    restoreProtection = True
                    ws.Unprotect Password:=TOOL_PASSWORD
                End If
            End If
            issue = "": macroName = ReadToolButtonMacro(shp, issue)
        End If
        If Len(issue) > 0 Then allIssues = allIssues & vbCrLf & ws.Name & " / " & shapeName & "�F" & issue
        If Len(macroName) > 0 Then
            desired = MacroRef(macroName, targetBookName)
            actionRead = TryReadButtonAction(shp, currentAction)
            If Not actionRead Or Not ButtonActionMatches(currentAction, macroName, targetBookName) Then
                stepText = "�{�^����ύX���邽�߂̕ی����"
                If Not restoreProtection Then
                    protection = CaptureButtonProtection(ws)
                    If IsArray(protection) Then
                        restoreProtection = True
                        ws.Unprotect Password:=TOOL_PASSWORD
                    End If
                End If
                stepText = "�Q�Ɛ� " & desired & " �̐ݒ�"
                issue = TrySetButtonAction(shp, desired)
                If Len(issue) > 0 Then
                    '��\���E��A�N�e�B�u�������̏ꍇ�ɔ����A���s�������\����Ԃ𐮂��čĎ��s����B
                    If Not contextChanged Then
                        Set oldWindow = ActiveWindow: Set oldSheet = ActiveSheet
                        oldVisible = ws.Visible: contextChanged = True
                        ws.Visible = xlSheetVisible
                        ws.Activate
                    End If
                    issue = TrySetButtonAction(shp, desired)
                End If
                If Len(issue) > 0 Then allIssues = allIssues & vbCrLf & ws.Name & " / " & shapeName & " / " & macroName & "�F" & issue
            End If
        End If
    Next shp
    GoTo Finish
EH:
    allIssues = allIssues & vbCrLf & ws.Name & " / " & shapeName & " / " & stepText & "�F" & CStr(Err.Number) & " " & Err.Description
    Resume Finish
Finish:
    '�ŏ��̃G���[�������I�����Ă��畜������B��̕������s�Ŏ����~�߂Ȃ��B
    On Error Resume Next
    If restoreProtection Then
        Err.Clear
        RestoreButtonProtection ws, protection
        If Err.Number <> 0 Then allIssues = allIssues & vbCrLf & ws.Name & " / �ی��߂������F" & Err.Description
    End If
    If contextChanged Then
        Err.Clear
        If Not oldWindow Is Nothing Then oldWindow.Activate
        If Err.Number <> 0 Then allIssues = allIssues & vbCrLf & "���̃E�B���h�E�F" & Err.Description
        Err.Clear
        If Not oldSheet Is Nothing Then oldSheet.Activate
        If Err.Number <> 0 Then allIssues = allIssues & vbCrLf & "���̕\���V�[�g�F" & Err.Description
        Err.Clear
        ws.Visible = oldVisible
        If Err.Number <> 0 Then allIssues = allIssues & vbCrLf & ws.Name & " / �\����ԁF" & Err.Description
    End If
    On Error GoTo 0
    RefreshSheetButtonActions = allIssues
End Function

Private Function ReadToolButtonMacro(ByVal shp As Shape, ByRef issue As String) As String
    Dim shapeName As String, macroName As String, action As String, owned As Boolean
    On Error GoTo EH
    shapeName = shp.Name: owned = (Left$(shapeName, Len(UI_PREFIX)) = UI_PREFIX)
    If owned Then
        '�w�i�⑕���ɂ�OnAction��₢���킹�Ȃ��B��փe�L�X�g�𖳏����Ƀ}�N�����Ƃ��Ĉ���Ȃ��B
        If shapeName = UI_PREFIX & "panel_back" Then Exit Function
        If shp.Type <> msoAutoShape And shp.Type <> msoTextBox And shp.Type <> msoFormControl Then Exit Function
        Select Case shapeName
            Case UI_PREFIX & "account_toggle": macroName = "ToggleAccountDetails"
            Case UI_PREFIX & "balance_toggle": macroName = "ToggleBalanceDetails"
            Case UI_PREFIX & "branch_plus": macroName = "IncrementAccountBranchNo"
            Case UI_PREFIX & "input_actions": macroName = "ShowInputActions"
            Case UI_PREFIX & "balance_page": macroName = "NextBalancePage"
        End Select
        If Len(macroName) = 0 Then macroName = ReadButtonMetadata(shp)
        If Len(macroName) = 0 Then
            If TryReadButtonAction(shp, action) Then macroName = LegacyToolButtonMacro(action)
        End If
        If Len(macroName) = 0 Then
            If Left$(shapeName, Len(UI_PREFIX & "btn_")) = UI_PREFIX & "btn_" Or Left$(shapeName, Len(UI_PREFIX & "legacy_")) = UI_PREFIX & "legacy_" Then
                issue = "����̊��蓖�Ă�ǂݎ��܂���B"
            End If
        End If
    ElseIf shp.Type = msoFormControl Then
        '���`���̎��{�^�������������p���B�`�F�b�N�{�b�N�X��O���I�u�W�F�N�g�͕ύX���Ȃ��B
        If shp.FormControlType <> xlButtonControl Then Exit Function
        If TryReadButtonAction(shp, action) Then macroName = LegacyToolButtonMacro(action)
    End If
    ReadToolButtonMacro = macroName
    Exit Function
EH:
    If owned Then issue = CStr(Err.Number) & " " & Err.Description
End Function

Private Function ReadButtonMetadata(ByVal shp As Shape) As String
    On Error GoTo Unavailable
    ReadButtonMetadata = LegacyToolButtonMacro(shp.AlternativeText)
Unavailable:
End Function

Private Function TryReadButtonAction(ByVal shp As Shape, ByRef action As String) As Boolean
    action = ""
    On Error GoTo Unavailable
    action = shp.OnAction
    TryReadButtonAction = True
Unavailable:
End Function

Public Sub AssignToolButtonAction(ByVal shp As Shape, ByVal macroName As String)
    Dim issue As String
    issue = TrySetButtonAction(shp, MacroRef(macroName))
    If Len(issue) > 0 Then
        Err.Raise vbObjectError + 2804, "AssignToolButtonAction", "�{�^���u" & macroName & "�v��ݒ�ł��܂���ł����B" & vbCrLf & shp.Parent.Name & " / " & shp.Name & "�F" & issue
    End If
End Sub

Private Function TrySetButtonAction(ByVal shp As Shape, ByVal action As String) As String
    Dim firstError As String, drawing As Object
    On Error GoTo ShapeFailed
    shp.OnAction = action
    Exit Function
ShapeFailed:
    firstError = CStr(Err.Number) & " " & Err.Description
    Resume DrawingFallback
DrawingFallback:
    On Error GoTo DrawingFailed
    '�}�`�Ə]����DrawingObject�ŗ��p�ł���C���^�[�t�F�C�X�̍����z������B
    Set drawing = shp.DrawingObject
    drawing.OnAction = action
    Exit Function
DrawingFailed:
    TrySetButtonAction = firstError & " / " & CStr(Err.Number) & " " & Err.Description
End Function

Public Function ButtonActionMatches(ByVal action As String, ByVal macroName As String, Optional ByVal targetBookName As String = "") As Boolean
    Dim bookPart As String, macroPart As String, pos As Long
    If Len(targetBookName) = 0 Then targetBookName = ThisWorkbook.Name
    action = Trim$(action): pos = InStrRev(action, "!")
    If pos = 0 Then
        macroPart = action: bookPart = ThisWorkbook.Name
    Else
        macroPart = Mid$(action, pos + 1): bookPart = Left$(action, pos - 1)
        If Len(bookPart) >= 2 Then
            If Left$(bookPart, 1) = "'" And Right$(bookPart, 1) = "'" Then bookPart = Mid$(bookPart, 2, Len(bookPart) - 2)
        End If
        bookPart = Replace(bookPart, "''", "'")
    End If
    If StrComp(macroPart, macroName, vbTextCompare) <> 0 Then Exit Function
    If StrComp(bookPart, targetBookName, vbTextCompare) = 0 Then
        ButtonActionMatches = True
    ElseIf StrComp(targetBookName, ThisWorkbook.Name, vbTextCompare) = 0 Then
        ButtonActionMatches = (StrComp(bookPart, ThisWorkbook.FullName, vbTextCompare) = 0)
    End If
End Function

Private Function CaptureButtonProtection(ByVal ws As Worksheet) As Variant
    If Not ws.ProtectContents And Not ws.ProtectDrawingObjects And Not ws.ProtectScenarios Then Exit Function
    With ws.Protection
        CaptureButtonProtection = Array(ws.ProtectDrawingObjects, ws.ProtectContents, ws.ProtectScenarios, ws.ProtectionMode, ws.EnableSelection, _
            .AllowFormattingCells, .AllowFormattingColumns, .AllowFormattingRows, .AllowInsertingColumns, .AllowInsertingRows, _
            .AllowInsertingHyperlinks, .AllowDeletingColumns, .AllowDeletingRows, .AllowSorting, .AllowFiltering, .AllowUsingPivotTables)
    End With
End Function

Private Sub RestoreButtonProtection(ByVal ws As Worksheet, ByVal state As Variant)
    ws.Protect Password:=TOOL_PASSWORD, DrawingObjects:=CBool(state(0)), Contents:=CBool(state(1)), Scenarios:=CBool(state(2)), _
        UserInterfaceOnly:=CBool(state(3)), AllowFormattingCells:=CBool(state(5)), AllowFormattingColumns:=CBool(state(6)), _
        AllowFormattingRows:=CBool(state(7)), AllowInsertingColumns:=CBool(state(8)), AllowInsertingRows:=CBool(state(9)), _
        AllowInsertingHyperlinks:=CBool(state(10)), AllowDeletingColumns:=CBool(state(11)), AllowDeletingRows:=CBool(state(12)), _
        AllowSorting:=CBool(state(13)), AllowFiltering:=CBool(state(14)), AllowUsingPivotTables:=CBool(state(15))
    ws.EnableSelection = CLng(state(4))
End Sub

Public Sub FormatHeader(ByVal rng As Range, Optional ByVal fillColor As Long = 0)
    If rng Is Nothing Then Exit Sub
    If fillColor = 0 Then fillColor = RGB(226, 232, 240)
    With rng
        .Font.Bold = True
        .Font.Color = RGB(15, 23, 42)
        .Interior.Color = fillColor
        .Borders.LineStyle = xlContinuous
        .Borders.Color = RGB(203, 213, 225)
        .VerticalAlignment = xlCenter
    End With
End Sub

Public Sub FormatOutputHeader(ByVal rng As Range)
    If rng Is Nothing Then Exit Sub
    With rng
        .Font.Bold = True
        .Font.Size = 14
        .Font.Color = RGB(255, 255, 255)
        .Interior.Color = RGB(30, 64, 175)
        .HorizontalAlignment = xlCenter
        .VerticalAlignment = xlCenter
        .Borders.LineStyle = xlContinuous
        .Borders.Color = RGB(147, 197, 253)
    End With
End Sub

Private Function LegacyToolButtonMacro(ByVal action As String) As String
    Dim nameText As String, pos As Long
    pos = InStrRev(action, "!")
    If pos > 0 Then nameText = Mid$(action, pos + 1) Else nameText = action
    Select Case nameText
        Case "ApplyBatchInput", "LeaveBatchInput", "DiscardBatchInput", "ShowAccountActions": LegacyToolButtonMacro = nameText
        Case "ShowExportOptions", "ExportFilteredWorkbooks", "ShowCurrentReportSortMenu", "ToggleMappedHeader": LegacyToolButtonMacro = nameText
        Case "AddTransactionInputRows", "ApplySettingsAndReturn", "BuildAllOutputSheets", "ClearAllInputFields": LegacyToolButtonMacro = nameText
        Case "ClearBalanceInput", "ClearInputKeepBankBranch", "ClearInputKeepPerson", "ClearTransactionInput": LegacyToolButtonMacro = nameText
        Case "CopyPreviousDescription", "DeleteSelectedAccount", "DiscardInput", "ExportFinalWorkbooks": LegacyToolButtonMacro = nameText
        Case "GoToTransactionEnd", "ImportExistingToolData", "IncrementAccountBranchNo", "InitializeToolData": LegacyToolButtonMacro = nameText
        Case "InputTabNext", "InputTabPrev", "LoadSelectedAccountForAppend", "LoadSelectedAccountForEdit": LegacyToolButtonMacro = nameText
        Case "NextBalancePage", "OpenShopNames", "RestoreToolFormatting", "SaveToolBackup": LegacyToolButtonMacro = nameText
        Case "SaveToolWorkbook", "SaveToolWorkbookAs", "ShowCandidateSheets", "ShowConfigSheet": LegacyToolButtonMacro = nameText
        Case "ShowInputActions", "ShowInputSheet", "ShowRegisteredAccounts", "ToggleAccountDetails": LegacyToolButtonMacro = nameText
        Case "ToggleBalanceDetails", "TransferCurrentAccount", "TransferCurrentAccountKeepBankBranch", "TransferCurrentAccountNextBranch": LegacyToolButtonMacro = nameText
    End Select
End Function

Public Sub ApplyInputVisualStyle(ByVal ws As Worksheet)
    With ws.Range("B2:K2")
        .Interior.Color = vbWhite: .Font.Color = RGB(15, 23, 42)
        .Font.Name = "Yu Gothic UI": .Font.Size = 17: .Font.Bold = True
        .HorizontalAlignment = xlLeft: .Borders.LineStyle = xlNone
    End With
    With ws.Range("B5,E5,H5,J5,B6,E6,H6,J6")
        .Interior.Color = RGB(241, 245, 249): .Font.Color = RGB(71, 85, 105)
        .Font.Bold = False
    End With
    With ws.Range("C5:D5,F5:G5,I5,K5,C6:D6,F6:G6,I6,K6")
        .Interior.Color = vbWhite: .Font.Color = RGB(15, 23, 42): .Font.Size = 11
    End With
    With ws.Range("B14:K14")
        .Interior.Color = RGB(51, 65, 85): .Font.Color = vbWhite
        .Borders.Color = RGB(226, 232, 240): .HorizontalAlignment = xlCenter
    End With
    ws.Range("F14").Interior.Color = RGB(146, 64, 14)
    ws.Range("G14").Interior.Color = RGB(15, 99, 88)
    ws.Range("B15:K" & InputLastTransactionRow()).Font.Size = 11
    ws.Range("F15:G" & InputLastTransactionRow()).ShrinkToFit = True
    ws.Range("B15:E" & InputLastTransactionRow()).HorizontalAlignment = xlCenter
    ws.Range("F15:G" & InputLastTransactionRow()).HorizontalAlignment = xlRight
    ws.Range("H15:K" & InputLastTransactionRow()).HorizontalAlignment = xlLeft
End Sub

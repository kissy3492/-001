@echo off
cd /d "%~dp0"
cscript //nologo "%~dp0UPDATE_TOOL.vbs" %*
pause

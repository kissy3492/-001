# 01 関数単位監査レポート

## DrawPersonCardShape

被相続人カードが `Nothing` になる根本原因候補を潰すため、図形作成以外の失敗を非致命化した。

## BuildCohabitationTable / WriteCohabCommonTable

住所一致かつ期間重複ありの行は `同居推定` とし、期間の不確実性は確認ポイントへ残す方式に変更した。

## 未実施

実機VBEコンパイル、Windows上の一括インポート、印刷プレビューは未実施。

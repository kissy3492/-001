# 01_人物情報 機能・マクロ静的監査レポート

## 対象

- 対象ZIP: `01_人物情報.zip`
- 対象範囲: 01のみ
- 監査対象: `modules/*.bas`、`ThisWorkbook_code.txt`、一括取込BAT/VBS、IMPORT_ORDER
- 主眼: VBEコンパイルエラー、未定義マクロ、OnAction/OnKey不整合、VBA特有の非短絡評価、組込み名衝突、行継続、文字コード、古い標準モジュール残存対策

## 結論

静的監査で、実行時マクロエラーになり得るVBA特有の非短絡評価リスクを2件検出し、修正しました。
また、即時構文エラーではないものの、Excelの `Rows` メンバーと紛らわしい `rows` 変数・引数を7プロシージャで検出し、明確な名前へ変更しました。

修正後の静的監査では、未定義OnAction/OnKey、Public重複、Option Explicit不足、Sub/Function開始終了不一致、IIf、0引数Subの括弧呼び出し、危険な非短絡ガード、組込み名シャドーイングは検出0です。

## 今回検出して修正したもの

### 1. `ws Is Nothing Or ws.Name ...` の非短絡評価

VBAの `Or` は短絡評価しません。したがって、以下のような書き方は `ws Is Nothing` がTrueでも `ws.Name` が評価され、実行時エラー91などにつながります。

```vb
If ws Is Nothing Or ws.Name <> SH_ADDR_TABLE Then ...
```

該当箇所:

- `modWorkflow.bas` / `LoadSelectedAddressHistoryForEdit`
- `modWorkflow.bas` / `DeleteSelectedAddressFromTable`

修正内容:

```vb
Dim ws As Worksheet, activeObj As Object
Set activeObj = ActiveSheet
If Not TypeOf activeObj Is Worksheet Then Err.Raise 5, , "住所履歴早見表で..."
Set ws = activeObj
If ws.Name <> SH_ADDR_TABLE Then Err.Raise 5, , "住所履歴早見表で..."
```

これで、アクティブシートが想定外でも `ws.Name` を無理に読みに行かない構造になっています。

### 2. `rows` 変数・引数の名前衝突リスク

VBE上で即時構文エラーになるものではありませんが、Excel/VBAでは `Rows` が頻出メンバーであり、`rows(i)` のような書き方は読み手にも解析にも紛らわしくなります。

対象:

- `SiblingCollectionWidth`
- `CollectionFamilyTreeWidth`
- `MaxDescendantDepthForPerson`
- `MaxSiblingCountForPerson`
- `FamilyTreeBlockWidth`
- `DrawDescendantFamilyBlock`
- `DrawUnlinkedGrandchildren`

修正内容:

- `rows` → `siblingRows`
- `rows` → `personRows`
- `rows` → `childRows`
- `rows` → `unlinkedRows`

関係図ロジックの可読性と将来のデバッグ性を優先した整理です。

## 静的監査結果

| 項目 | 結果 |
|---|---:|
| VBAコードファイル | 17 |
| 標準モジュール `.bas` | 16 |
| ThisWorkbookコード | 1 |
| Sub / Function / Property 合計 | 624 |
| Public | 194 |
| Private | 430 |
| 開始数 / 終了数 | 624 / 624 |
| CP932デコードエラー | 0 |
| Option Explicit不足 | 0 |
| 未終了プロシージャ | 0 |
| Public重複 | 0 |
| 同一モジュール内重複 | 0 |
| If / For / Do / With / Select ブロック不整合 | 0 |
| 行継続異常 | 0 |
| 文字列クォート不整合 | 0 |
| OnAction / AddButton / OnKey 未定義 | 0 |
| Private関数の他モジュール跨ぎ呼び出し候補 | 0 |
| 0引数Subの括弧呼び出し候補 | 0 |
| IIf残存 | 0 |
| 高リスク非短絡ガード | 0 |
| 組込み名シャドーイング | 0 |
| プロシージャ外の不審な実行文 | 0 |
| IMPORT_ORDER不足 | 0 |
| IMPORT_ORDER余剰 | 0 |

## 一括取込・文字コード

| 項目 | 結果 |
|---|---:|
| ルート `IMPORT_01_MODULES.bat` ASCII | OK |
| `import/IMPORT_01_MODULES.bat` ASCII | OK |
| `IMPORT_01_MODULES.vbs` UTF-16LE BOM | OK |
| VBS内 `ADODB.Stream` 使用 | OK |
| VBS内 `shift_jis` 読込 | OK |
| VBS内非ASCII文字 | 0 |
| `IMPORT_ORDER.txt` 件数 | 17 |
| `modules/*.bas` の不足・余剰 | 0 / 0 |

## MsgBox確認

直接 `MsgBox` は7件です。用途は以下に限定されています。

- エラー詳細
- データ初期化確認
- 人物削除確認
- 住所削除確認

成功通知ポップアップは検出していません。

## 機能面の所見

静的に見る限り、少なくとも以下の即時停止リスクは潰せています。

- ボタンから存在しないマクロを呼ぶ問題
- `OnKey` で存在しない移動マクロを呼ぶ問題
- `IIf` の非短絡評価
- `ws Is Nothing Or ws.Name` 型の実行時エラー
- `CDate` / `DateValue` 系の名前衝突
- `rows` のようなExcelメンバー名との曖昧なローカル名
- 行継続 `_` の後に空行・コメントが入る構文エラー
- Sub/Function の閉じ忘れ
- 旧標準モジュール残存による未定義再発リスク

## 残る重要注意点

この環境では実ExcelのVBEコンパイルを実行できません。静的にはかなり強く見ていますが、Excel実機では以下を必ず確認してください。

1. VBEで `Debug > Compile VBAProject`
2. `IMPORT_01_MODULES.bat` による一括取込
3. 起動時 `Workbook_Open` のレイアウト復旧
4. Tab / Enter 移動
5. 人物登録・訂正・削除
6. 住所追加・訂正・削除
7. 相続関係図作成
8. 孫・曽孫・玄孫、兄弟姉妹、その他関係人の配置と線
9. 住所一覧・同居判定表の印刷プレビュー

## 未実施

完成扱いにはしていません。未実施は以下です。

- 実機ExcelでのVBEコンパイル
- Windows上での一括取込実行
- 実Excelでの人物・住所・婚姻履歴操作
- 実ExcelでのTab / Enter移動確認
- 実データでの相続関係図作成確認
- 住所一覧・同居判定表の印刷プレビュー
- 実データ通し検証

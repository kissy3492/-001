Option Explicit

Const vbext_ct_Document = 100

Dim fso, scriptFolder, rootFolder, srcFolder, targetPath
Dim xl, wb, vbProj, backupPath
Dim moduleFiles, i, setupErr

Set fso = CreateObject("Scripting.FileSystemObject")
scriptFolder = fso.GetParentFolderName(WScript.ScriptFullName)
rootFolder = fso.GetParentFolderName(scriptFolder)

moduleFiles = Array( _
    "modConstants.bas", _
    "modVisualTheme.bas", _
    "modRuntimeGuard.bas", _
    "modUtilities.bas", _
    "modQuietUi.bas", _
    "modIdManager.bas", _
    "modSheetVisibility.bas", _
    "modUsability.bas", _
    "modMarriageHistory.bas", _
    "modMarriageHistoryReview.bas", _
    "modRelationshipDiagramAudit.bas", _
    "modSetup.bas", _
    "modWorkflow.bas", _
    "modOutputs.bas", _
    "modPreflight.bas", _
    "modRepairTool.bas" _
)

srcFolder = FindSourceFolder(rootFolder, moduleFiles)
If Len(srcFolder) = 0 Then
    WScript.Echo "Source folder was not found. Put this import folder next to the 01 source folder."
    WScript.Quit 1
End If

If WScript.Arguments.Count >= 1 Then
    targetPath = WScript.Arguments(0)
Else
    targetPath = InputBox("Enter the full path of the target 01 .xlsm file." & vbCrLf & _
                          "Tip: drag and drop the .xlsm file onto IMPORT_01_MODULES.bat.", _
                          "Import 01 modules")
End If

If Len(Trim(targetPath)) = 0 Then WScript.Quit 1
If Not fso.FileExists(targetPath) Then
    WScript.Echo "Target workbook was not found: " & targetPath
    WScript.Quit 1
End If

For i = 0 To UBound(moduleFiles)
    If Not fso.FileExists(fso.BuildPath(srcFolder, moduleFiles(i))) Then
        WScript.Echo "Source module was not found: " & moduleFiles(i)
        WScript.Quit 1
    End If
Next
If Not fso.FileExists(fso.BuildPath(srcFolder, "ThisWorkbook_code.txt")) Then
    WScript.Echo "ThisWorkbook_code.txt was not found."
    WScript.Quit 1
End If

On Error Resume Next
backupPath = MakeBackupPath(targetPath)
fso.CopyFile targetPath, backupPath, False
If Err.Number <> 0 Then
    WScript.Echo "Backup failed: " & Err.Description
    WScript.Quit 1
End If
On Error GoTo 0

On Error Resume Next
Set xl = CreateObject("Excel.Application")
If Err.Number <> 0 Then
    WScript.Echo "Excel could not be started: " & Err.Description
    WScript.Quit 1
End If
On Error GoTo 0

xl.Visible = True
xl.DisplayAlerts = False

On Error Resume Next
Set wb = xl.Workbooks.Open(targetPath)
If Err.Number <> 0 Then
    WScript.Echo "Target workbook could not be opened: " & Err.Description
    xl.Quit
    WScript.Quit 1
End If
On Error GoTo 0

On Error Resume Next
Set vbProj = wb.VBProject
If Err.Number <> 0 Then
    WScript.Echo "VBA project access was denied." & vbCrLf & _
                 "Enable: Trust access to the VBA project object model." & vbCrLf & _
                 "Backup: " & backupPath
    wb.Close False
    xl.Quit
    WScript.Quit 1
End If
On Error GoTo 0

For i = 0 To UBound(moduleFiles)
    RemoveComponentByFileName moduleFiles(i)
Next

For i = 0 To UBound(moduleFiles)
    vbProj.VBComponents.Import fso.BuildPath(srcFolder, moduleFiles(i))
Next

ReplaceThisWorkbookCode fso.BuildPath(srcFolder, "ThisWorkbook_code.txt")

setupErr = ""
On Error Resume Next
xl.Run "'" & wb.Name & "'!SetupWorkbook"
If Err.Number <> 0 Then
    setupErr = Err.Description
    Err.Clear
End If
On Error GoTo 0

wb.Save
xl.DisplayAlerts = True

If Len(setupErr) > 0 Then
    WScript.Echo "Imported 01 modules, but SetupWorkbook did not complete." & vbCrLf & _
                 "Open the workbook, compile VBA, then run SetupWorkbook manually." & vbCrLf & _
                 "Error: " & setupErr & vbCrLf & _
                 "Target: " & targetPath & vbCrLf & _
                 "Backup: " & backupPath
Else
    WScript.Echo "Imported 01 modules and rebuilt the 01 input screen." & vbCrLf & _
                 "Target: " & targetPath & vbCrLf & _
                 "Backup: " & backupPath
End If

Sub RemoveComponentByFileName(ByVal fileName)
    Dim moduleName, comp
    moduleName = fso.GetBaseName(fileName)
    On Error Resume Next
    Set comp = vbProj.VBComponents(moduleName)
    If Err.Number = 0 Then
        If comp.Type <> vbext_ct_Document Then vbProj.VBComponents.Remove comp
    End If
    Err.Clear
    On Error GoTo 0
End Sub

Sub ReplaceThisWorkbookCode(ByVal codePath)
    Dim comp, cm, txt
    On Error Resume Next
    Set comp = vbProj.VBComponents(wb.CodeName)
    If comp Is Nothing Then Set comp = vbProj.VBComponents("ThisWorkbook")
    If Err.Number <> 0 Or comp Is Nothing Then
        WScript.Echo "ThisWorkbook module was not found."
        WScript.Quit 1
    End If
    On Error GoTo 0

    Set cm = comp.CodeModule
    If cm.CountOfLines > 0 Then cm.DeleteLines 1, cm.CountOfLines
    txt = ReadAllText(codePath)
    cm.AddFromString txt
End Sub

Function ReadAllText(ByVal path)
    Dim ts
    Set ts = fso.OpenTextFile(path, 1, False)
    ReadAllText = ts.ReadAll
    ts.Close
End Function

Function FindSourceFolder(ByVal baseFolder, ByVal files)
    Dim folder, subFolder, ok, j
    If FolderHasAllFiles(baseFolder, files) Then
        FindSourceFolder = baseFolder
        Exit Function
    End If
    Set folder = fso.GetFolder(baseFolder)
    For Each subFolder In folder.SubFolders
        If FolderHasAllFiles(subFolder.Path, files) Then
            FindSourceFolder = subFolder.Path
            Exit Function
        End If
    Next
    FindSourceFolder = ""
End Function

Function FolderHasAllFiles(ByVal folderPath, ByVal files)
    Dim j
    FolderHasAllFiles = False
    If Not fso.FileExists(fso.BuildPath(folderPath, "ThisWorkbook_code.txt")) Then Exit Function
    For j = 0 To UBound(files)
        If Not fso.FileExists(fso.BuildPath(folderPath, files(j))) Then Exit Function
    Next
    FolderHasAllFiles = True
End Function

Function MakeBackupPath(ByVal path)
    Dim folder, baseName, ext, stamp
    folder = fso.GetParentFolderName(path)
    baseName = fso.GetBaseName(path)
    ext = fso.GetExtensionName(path)
    stamp = Year(Now) & Right("0" & Month(Now), 2) & Right("0" & Day(Now), 2) & "_" & _
            Right("0" & Hour(Now), 2) & Right("0" & Minute(Now), 2) & Right("0" & Second(Now), 2)
    MakeBackupPath = fso.BuildPath(folder, baseName & "_backup_before_01_import_" & stamp & "." & ext)
End Function

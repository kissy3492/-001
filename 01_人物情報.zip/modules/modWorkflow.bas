Attribute VB_Name = "modWorkflow"

Option Explicit

Public Sub BeginDecedentEntry()

    PrepareInput MODE_DECEDENT

End Sub

Public Sub BeginAddSpouse()

    PrepareInput MODE_SPOUSE

End Sub

Public Sub BeginAddFather()

    PrepareInput MODE_FATHER

End Sub

Public Sub BeginAddMother()

    PrepareInput MODE_MOTHER

End Sub

Public Sub BeginAddChild()

    PrepareInput MODE_CHILD

End Sub

Public Sub BeginAddSibling()

    PrepareInput MODE_SIBLING

End Sub

Public Sub BeginAddGrandchild()

    PrepareInput MODE_GRANDCHILD

End Sub

Public Sub BeginAddOther()

    PrepareInput MODE_OTHER

End Sub

Private Sub PrepareInput(ByVal modeName As String)

    On Error GoTo EH

    Dim ws As Worksheet, baseId As String, autoSurname As String

    Set ws = ThisWorkbook.Worksheets(SH_INPUT)

    ws.Unprotect Password:=TOOL_PASSWORD

    If modeName <> MODE_DECEDENT Then

        baseId = CleanText(ws.Range(CELL_BASE_ID).Value)

        If Len(baseId) = 0 Then

            QuietWarn "��Ɋ�l����I��ł��������B�푊���l�o�^��͎����Ŋ�l���ɂȂ�܂��B", False, "�l������"

            GoTo CleanExit

        End If

    End If

    ws.Range(CELL_PERSON_ID & ":" & CELL_DEATH_PLACE).ClearContents

    ws.Range(CELL_PENDING_ADDR_KEY).ClearContents
    ws.Range(CELL_ADDR_EDIT_ID).ClearContents

    ws.Range(CELL_ADDR_CAND & ":" & CELL_ADDR_NOTE).ClearContents
    ws.Range(CELL_ADDR_KEY).ClearContents
    ws.Range(CELL_ADDR_SOURCE).ClearContents
    ws.Range(CELL_ADDR_EDIT_ID).ClearContents
    ws.Range(CELL_ADDR_TYPE).Value = "���Z�n"

    ws.Range(CELL_ADDR_START_KIND).Value = "���Z�J�n"

    ws.Range(CELL_MODE).Value = modeName

    ws.Range(CELL_SHOW_DIAGRAM).Value = SHOW_YES

    autoSurname = SuggestSurname(modeName, baseId)

    ws.Range(CELL_AUTO_SURNAME).Value = autoSurname

    ws.Range(CELL_SURNAME).Value = autoSurname

    ws.Range(CELL_GENDER).Value = SuggestedGender(modeName, baseId)

    Select Case modeName

        Case MODE_DECEDENT

            ws.Range(CELL_REL_TO_DECEDENT).Value = MODE_DECEDENT

            ws.Range(CELL_SURNAME).ClearContents

        Case Else

            ws.Range(CELL_REL_TO_DECEDENT).Value = ResolveRelationTextForRegistration(modeName, baseId, "", _
                CleanText(ws.Range(CELL_GENDER).Value), ws.Range(CELL_BIRTH).Value)

    End Select

    CopyBaseCurrentAddress False

    EnsureCandidatesWarmForInputMode

    UpdateInputGuide modeName

    ws.Range(CELL_GIVEN_NAME).Select

CleanExit:

    On Error Resume Next

    EnsurePersonInputValidationOnly ws

    ApplyInputUsability

    On Error GoTo 0

    Exit Sub

EH:

    Dim errNum As Long, errDesc As String, errSrc As String

    errNum = Err.Number: errDesc = Err.Description: errSrc = Err.Source

    On Error Resume Next

    EnsurePersonInputValidationOnly ws

    ApplyInputUsability

    On Error GoTo 0

    RuntimeShowErrorValues "PrepareInput", "�l�����͊J�n", _
        "��l���E���͌��E�V�[�g�ی��Ԃ��m�F���Ă��������B", "", errNum, errDesc, errSrc

End Sub

Public Sub ClearPersonInput()

    On Error GoTo EH

    Dim ws As Worksheet, pendingKey As String

    Set ws = ThisWorkbook.Worksheets(SH_INPUT)

    ws.Unprotect Password:=TOOL_PASSWORD

    pendingKey = CleanText(ws.Range(CELL_PENDING_ADDR_KEY).Value)
    If Len(pendingKey) > 0 Then ClearPendingAddresses pendingKey

    ws.Range(CELL_PERSON_ID & ":" & CELL_DEATH_PLACE).ClearContents

    ws.Range(CELL_PENDING_ADDR_KEY).ClearContents
    ws.Range(CELL_ADDR_EDIT_ID).ClearContents

    ws.Range(CELL_ADDR_CAND & ":" & CELL_ADDR_NOTE).ClearContents
    ws.Range(CELL_ADDR_KEY).ClearContents
    ws.Range(CELL_ADDR_SOURCE).ClearContents
    ws.Range(CELL_ADDR_EDIT_ID).ClearContents
    ws.Range(CELL_ADDR_TYPE).Value = "���Z�n"

    ws.Range(CELL_ADDR_START_KIND).Value = "���Z�J�n"

    ws.Range(CELL_SHOW_DIAGRAM).Value = SHOW_YES

CleanExit:

    EnsurePersonInputValidationOnly ws

    ApplyInputUsability

    Exit Sub

EH:

    Resume CleanExit

End Sub

Private Function SuggestSurname(ByVal modeName As String, ByVal baseId As String) As String

    Dim decId As String, s As String

    If modeName = MODE_OTHER Then

        SuggestSurname = ""

        Exit Function

    End If

    If modeName = MODE_DECEDENT Then

        SuggestSurname = ""

        Exit Function

    End If

    If Len(baseId) > 0 Then s = GetPersonValue(baseId, P_SURNAME)

    decId = GetDecedentId()

    Select Case modeName

        Case MODE_FATHER, MODE_MOTHER, MODE_SIBLING

            If Len(decId) > 0 Then SuggestSurname = GetPersonValue(decId, P_SURNAME) Else SuggestSurname = s

        Case Else

            SuggestSurname = s

    End Select

End Function

Public Sub LoadBaseFromSelection()

    Dim ws As Worksheet, sel As String, pid As String

    Set ws = ThisWorkbook.Worksheets(SH_INPUT)

    sel = CleanText(ws.Range(CELL_BASE_SELECT).Value)

    pid = ParseIdFromCandidate(sel)

    If Len(pid) = 0 Or FindPersonRow(pid) = 0 Then

        QuietWarn "��l����₩��l����I��ł��������B", False, "��l���I��"

        Exit Sub

    End If

    SetBasePerson pid

End Sub

Public Sub SetDecedentAsBase()

    Dim pid As String

    pid = GetDecedentId()

    If Len(pid) = 0 Then

        QuietWarn "�푊���l���܂��o�^����Ă��܂���B", False, "��l���I��"

        Exit Sub

    End If

    SetBasePerson pid

End Sub

Public Sub SetBasePerson(ByVal personId As String)

    Dim ws As Worksheet, r As Long, addr As String

    Set ws = ThisWorkbook.Worksheets(SH_INPUT)

    r = FindPersonRow(personId)

    If r = 0 Then Exit Sub

    ws.Range(CELL_BASE_ID).Value = personId

    ws.Range(CELL_BASE_NAME).Value = ThisWorkbook.Worksheets(SH_W_PERSON).Cells(r, P_DISPLAY).Value

    ws.Range(CELL_BASE_REL).Value = ThisWorkbook.Worksheets(SH_W_PERSON).Cells(r, P_REL_DEC).Value

    addr = GetCurrentAddressText(personId)

    ws.Range(CELL_BASE_ADDRESS).Value = addr

    ws.Range(CELL_BASE_SELECT).Value = personId & " " & ws.Range(CELL_BASE_NAME).Value

    If Len(CleanText(ws.Range(CELL_MODE).Value)) > 0 Then UpdateInputGuide CleanText(ws.Range(CELL_MODE).Value)

End Sub

Public Function FindPersonRow(ByVal personId As String) As Long

    Dim ws As Worksheet, r As Long, lastR As Long

    Set ws = ThisWorkbook.Worksheets(SH_W_PERSON)

    lastR = LastRow(ws, 1)

    For r = 2 To lastR

        If CStr(ws.Cells(r, P_ID).Value) = personId And CStr(ws.Cells(r, P_STATUS).Value) <> STATUS_CANCEL Then

            FindPersonRow = r

            Exit Function

        End If

    Next r

End Function

Public Function GetPersonValue(ByVal personId As String, ByVal colNum As Long) As String

    Dim r As Long

    r = FindPersonRow(personId)

    If r > 0 Then GetPersonValue = CStr(ThisWorkbook.Worksheets(SH_W_PERSON).Cells(r, colNum).Value)

End Function

Public Function GetDecedentId() As String

    Dim ws As Worksheet, r As Long, lastR As Long

    Set ws = ThisWorkbook.Worksheets(SH_W_PERSON)

    lastR = LastRow(ws, 1)

    For r = 2 To lastR

        If CStr(ws.Cells(r, P_TYPE).Value) = MODE_DECEDENT And CStr(ws.Cells(r, P_STATUS).Value) <> STATUS_CANCEL Then

            GetDecedentId = CStr(ws.Cells(r, P_ID).Value)

            Exit Function

        End If

    Next r

End Function

Public Function GetInheritanceDate() As Variant

    Dim ws As Worksheet

    Set ws = ThisWorkbook.Worksheets(SH_CONFIG)

    If IsDate(ws.Range(CELL_CONFIG_INHERIT_DATE).Value) Then

        GetInheritanceDate = ws.Range(CELL_CONFIG_INHERIT_DATE).Value

    Else

        GetInheritanceDate = ""

    End If

End Function

Public Sub RegisterInputPerson()

    On Error GoTo EH

    AppBegin

    Dim wsIn As Worksheet, wsP As Worksheet, modeName As String, pid As String, r As Long

    Dim surname As String, givenName As String, former As String, autoSurname As String

    Dim displayName As String, personType As String, relationText As String, baseId As String

    Dim gender As String, birthDate As Variant, deathDate As Variant, occupation As String, note As String

    Dim deathPlace As String, pendingKey As String, relationBaseId As String

    Set wsIn = ThisWorkbook.Worksheets(SH_INPUT)

    Set wsP = ThisWorkbook.Worksheets(SH_W_PERSON)

    modeName = CleanText(wsIn.Range(CELL_MODE).Value)

    If Len(modeName) = 0 Then modeName = MODE_DECEDENT

    baseId = CleanText(wsIn.Range(CELL_BASE_ID).Value)

    If modeName <> MODE_DECEDENT And Len(baseId) = 0 Then Err.Raise 5, , "��l�������ݒ�ł��B"

    surname = CleanText(wsIn.Range(CELL_SURNAME).Value)

    givenName = CleanText(wsIn.Range(CELL_GIVEN_NAME).Value)

    former = CleanText(wsIn.Range(CELL_FORMER_SURNAME).Value)

    autoSurname = CleanText(wsIn.Range(CELL_AUTO_SURNAME).Value)

    If Len(surname) = 0 And Len(autoSurname) > 0 Then surname = autoSurname

    If Len(givenName) = 0 Then Err.Raise 5, , "������͂��Ă��������B"

    If Len(surname) = 0 Then Err.Raise 5, , "������͂��Ă��������B"

    '�������͌���m�F�ƂȂ���������邽�߁A�l���o�^���͎̂~�߂Ȃ��B
    '�����͂�C_�`�F�b�N/���n�񖢔��f�ň����A���͓������d�����Ȃ��B

    gender = CleanText(wsIn.Range(CELL_GENDER).Value)

    relationText = CleanText(wsIn.Range(CELL_REL_TO_DECEDENT).Value)

    birthDate = SameDateOrBlank(wsIn.Range(CELL_BIRTH).Value)

    deathDate = SameDateOrBlank(wsIn.Range(CELL_DEATH).Value)

    relationText = ResolveRelationTextForRegistration(modeName, baseId, relationText, gender, birthDate)
    relationText = NormalizedRelationLabel(relationText)
    wsIn.Range(CELL_REL_TO_DECEDENT).Value = relationText

    If Len(autoSurname) > 0 And surname <> autoSurname And Len(former) = 0 _
            And ShouldAutoFormerSurname(modeName, relationText) Then

        former = autoSurname

        wsIn.Range(CELL_FORMER_SURNAME).Value = former

    End If

    displayName = ComposeDisplayName(surname, givenName, former)
    If modeName = MODE_SPOUSE And IsDate(wsIn.Range(CELL_DIVORCE).Value) Then relationText = "�O�z���"

    If modeName = MODE_DECEDENT Then
        personType = MODE_DECEDENT
    ElseIf modeName = MODE_OTHER Then
        personType = "�֌W��"
    Else
        personType = "�e��"
    End If

    If modeName = MODE_CHILD Or modeName = MODE_GRANDCHILD Then
        If InStr(relationText, "�z��҂̎q") > 0 Then
            personType = "�e��"
        Else
            personType = "�����l"
        End If
    End If

    If modeName = MODE_SPOUSE And baseId = GetDecedentId() Then personType = "�����l"

    occupation = CleanText(wsIn.Range(CELL_OCCUPATION).Value)

    note = CleanText(wsIn.Range(CELL_NOTE).Value)

    deathPlace = CleanText(wsIn.Range(CELL_DEATH_PLACE).Value)
    If modeName <> MODE_DECEDENT Then deathPlace = ""
    pendingKey = CleanText(wsIn.Range(CELL_PENDING_ADDR_KEY).Value)
    pid = CleanText(wsIn.Range(CELL_PERSON_ID).Value)
    If Len(pid) = 0 Then
        r = FindLikelyExistingPersonRow(displayName, birthDate, deathDate, modeName)
        If r > 0 Then
            pid = CStr(wsP.Cells(r, P_ID).Value)
        Else
            pid = NextId("�l��")
            r = NextBlankRow(wsP, 1)
            wsP.Cells(r, P_CREATED).Value = Now
        End If
    Else
        r = FindPersonRow(pid)
        If r = 0 Then r = NextBlankRow(wsP, 1)
    End If
    wsP.Cells(r, P_ID).Value = pid

    If Len(wsP.Cells(r, P_ORDER).Value) = 0 Then wsP.Cells(r, P_ORDER).Value = r - 1

    wsP.Cells(r, P_TYPE).Value = personType

    wsP.Cells(r, P_SURNAME).Value = surname

    wsP.Cells(r, P_GIVEN).Value = givenName

    wsP.Cells(r, P_FORMER).Value = former

    wsP.Cells(r, P_DISPLAY).Value = displayName

    If Len(autoSurname) > 0 And surname = autoSurname Then
        wsP.Cells(r, P_SUR_MODE).Value = "����"
    Else
        wsP.Cells(r, P_SUR_MODE).Value = "�����"
    End If

    'P_SUR_SRC�͋����u���⊮�̊�l���v�����A�����֌W�}�̐e�q�������ɂ��g���B
    '�q�E���ȉ��͌�i�Ŏ��ۂ̐eID�ɏ㏑�����A�����ŋ����⊮������Ȃ��P�[�X�ł��e�q��������Ȃ��B
    If modeName <> MODE_DECEDENT And Len(baseId) > 0 Then
        'P_SUR_SRC �͋����̂܂܂����A�}�̐e�q�~�ςł��g�����ߊ�l��ID��ێ�����B
        '���⊮�������l���ł��A���E�]���ȉ����ォ�琳�����e�̉��֖߂���悤�ɂ���B
        wsP.Cells(r, P_SUR_SRC).Value = baseId
    Else
        wsP.Cells(r, P_SUR_SRC).Value = ""
    End If

    wsP.Cells(r, P_REL_DEC).Value = relationText

    wsP.Cells(r, P_REL_DISP).Value = relationText

    wsP.Cells(r, P_GENDER).Value = gender

    wsP.Cells(r, P_BIRTH).Value = birthDate

    wsP.Cells(r, P_DEATH).Value = deathDate

    wsP.Cells(r, P_OCC).Value = occupation

    If Len(CleanText(wsIn.Range(CELL_SHOW_DIAGRAM).Value)) = 0 Then
        wsP.Cells(r, P_SHOW).Value = SHOW_YES
    Else
        wsP.Cells(r, P_SHOW).Value = wsIn.Range(CELL_SHOW_DIAGRAM).Value
    End If

    wsP.Cells(r, P_NOTE).Value = note

    wsP.Cells(r, P_DEATH_PLACE).Value = deathPlace

    SavePersonMarriageFactFields wsP, r, wsIn.Range(CELL_MARRIAGE).Value, wsIn.Range(CELL_DIVORCE).Value

    wsP.Cells(r, P_STATUS).Value = STATUS_ACTIVE

    wsP.Cells(r, P_UPDATED).Value = Now

    wsIn.Range(CELL_PERSON_ID).Value = pid

    If modeName = MODE_DECEDENT Then

        ThisWorkbook.Worksheets(SH_CONFIG).Range(CELL_CONFIG_INHERIT_DATE).Value = deathDate
        UpsertMarriageHistory pid, "", "", wsIn.Range(CELL_MARRIAGE).Value, wsIn.Range(CELL_DIVORCE).Value, "�l������", "", ""

    Else

        relationBaseId = RelationBaseForRegistration(modeName, baseId, birthDate)
        If modeName = MODE_CHILD Or modeName = MODE_GRANDCHILD Then
            '���������ŋ����⊮���s�v�ȏꍇ���A�}��̒���e�𕜌��ł���悤���ۂ̐eID��ێ�����B
            wsP.Cells(r, P_SUR_SRC).Value = relationBaseId
        End If
        AddRelationIfNeeded relationBaseId, pid, modeName, relationText, wsIn.Range(CELL_MARRIAGE).Value, wsIn.Range(CELL_DIVORCE).Value
        If modeName = MODE_SPOUSE Then
            UpsertMarriageHistory baseId, pid, displayName, wsIn.Range(CELL_MARRIAGE).Value, wsIn.Range(CELL_DIVORCE).Value, "�z��ғo�^", "", ""
        Else
            UpsertMarriageHistory pid, "", "", wsIn.Range(CELL_MARRIAGE).Value, wsIn.Range(CELL_DIVORCE).Value, "�l������", "", ""
        End If

    End If

    RegisterAddressFromInput pid
    If Len(pendingKey) > 0 Then
        FlushPendingAddressesToPerson pendingKey, pid
        wsIn.Range(CELL_PENDING_ADDR_KEY).ClearContents
    End If

    RefreshCandidatesAfterPersonRegister pid

    Dim nextBaseId As String

    nextBaseId = pid

    SetBasePerson nextBaseId

    wsIn.Range(CELL_BASE_SELECT).Value = nextBaseId & " " & GetPersonValue(nextBaseId, P_DISPLAY)

    ApplyInputUsability False

    WriteGuideAfterRegister modeName, displayName, nextBaseId

    SetPersonInputStatus "�o�^����: " & displayName & "�B�����Ċ֌W�{�^�����玟�̐l������͂ł��܂��B"

CleanExit:

    AppEnd

    Exit Sub

EH:

    Dim errNum As Long, errDesc As String, errSrc As String

    errNum = Err.Number: errDesc = Err.Description: errSrc = Err.Source

    On Error Resume Next

    If Not wsIn Is Nothing Then

        EnsurePersonInputValidationOnly wsIn

        ApplyInputUsability

    End If

    AppEnd

    On Error GoTo 0

    RuntimeShowErrorValues "RegisterInputPerson", "�l���o�^", _
        "�K�{���ځA��l���A���V�[�g�A�V�[�g�ی��Ԃ��m�F���Ă��������B", _
        "", errNum, errDesc, errSrc

End Sub

Private Function FindLikelyExistingPersonRow(ByVal displayName As String, _
        ByVal birthDate As Variant, _
        ByVal deathDate As Variant, _
        ByVal modeName As String) As Long
    '�l��ID����̂܂ܓ����l�����ēo�^�������ɁA���ʂȏd���l�������Ȃ��B
    '���������ł͓����������득�������邽�߁A���t��񂪂���ꍇ�A�܂��͔푊���l������1������ꍇ���������X�V����B
    Dim ws As Worksheet, r As Long, lastR As Long
    If Len(displayName) = 0 Then Exit Function
    Set ws = ThisWorkbook.Worksheets(SH_W_PERSON)
    lastR = LastRow(ws, 1)
    For r = 2 To lastR
        If CStr(ws.Cells(r, P_STATUS).Value) <> STATUS_CANCEL Then
            If CStr(ws.Cells(r, P_DISPLAY).Value) = displayName Then
                If modeName = MODE_DECEDENT And CStr(ws.Cells(r, P_TYPE).Value) = MODE_DECEDENT Then
                    FindLikelyExistingPersonRow = r
                    Exit Function
                End If
                If HasAnyDateForDuplicate(birthDate, deathDate) Then
                    If SameDateValueOrBlank(ws.Cells(r, P_BIRTH).Value, birthDate) Then
                        If SameDateValueOrBlank(ws.Cells(r, P_DEATH).Value, deathDate) Then
                            FindLikelyExistingPersonRow = r
                            Exit Function
                        End If
                    End If
                End If
            End If
        End If
    Next r
End Function

Private Function HasAnyDateForDuplicate(ByVal birthDate As Variant, ByVal deathDate As Variant) As Boolean
    HasAnyDateForDuplicate = (IsDate(birthDate) Or IsDate(deathDate))
End Function

Private Function RecommendedNextBase(ByVal modeName As String, ByVal baseId As String, ByVal newPersonId As String) As String

    '�o�^�����l�������̂܂܎��̊�l���ɂ���B

    '�u�����͂��Ă���l���̊֌W�҂𑱂��ēo�^����v������D�悷��B

    RecommendedNextBase = newPersonId

End Function

Private Function NextActionMessage(ByVal modeName As String, ByVal nextBaseId As String) As String

    Dim baseName As String

    baseName = GetPersonValue(nextBaseId, P_DISPLAY)

    NextActionMessage = "���݂̊�l�����u" & baseName & "�v�ɂ��܂����B" & _
        "���́A���̐l���̔z��ҁE���E��E�q�E�Z��o���Ȃǂ��֌W�{�^������ǉ����Ă��������B" & _
        "�ʂ̐l���̊֌W�҂֖߂�ꍇ�́A��l�����őI�Ԃ��u�푊���l�ɖ߂�v�������܂��B"

End Function

Private Sub WriteGuideAfterRegister(ByVal modeName As String, ByVal displayName As String, ByVal nextBaseId As String)

    Dim ws As Worksheet, guide As String, baseName As String

    Set ws = ThisWorkbook.Worksheets(SH_INPUT)

    baseName = GetPersonValue(nextBaseId, P_DISPLAY)
    guide = "�o�^�����F" & displayName & "�@���̊�l���F" & baseName & "�@�֌W�{�^�����玟�̐l����ǉ��ł��܂��B"
    ws.Range("B3").Value = guide
    Application.StatusBar = NextActionMessage(modeName, nextBaseId)

End Sub

Private Sub SetPersonInputStatus(ByVal messageText As String)

    On Error Resume Next

    Application.StatusBar = messageText

    ThisWorkbook.Worksheets(SH_INPUT).Range("B3").Value = Left$(CleanText(messageText), 120)

    On Error GoTo 0

End Sub

Private Sub UpdateInputGuide(ByVal modeName As String)

    Dim ws As Worksheet, guide As String, baseId As String, baseName As String

    Set ws = ThisWorkbook.Worksheets(SH_INPUT)

    baseId = CleanText(ws.Range(CELL_BASE_ID).Value)

    baseName = GetPersonValue(baseId, P_DISPLAY)

    Select Case modeName

        Case MODE_DECEDENT

            guide = "�菇1�F�푊���l��o�^���܂��B���E���E���S���E�Z������͂��Ă��������B���S���������J�n���ɂȂ�܂��B�o�^��A�z��ҁA���A��A�q�̏��Ɋ֌W�҂�ǉ����܂��B"

        Case MODE_SPOUSE

            guide = "�z��Ғǉ��F�����������m�F�ł��l���o�^�ł��܂��B���t��������ꍇ�����������E�����������A���m�F��C_�`�F�b�N�Ōォ��ׂ��܂��B�����͕K�v�Ȑl�������͂��܂��B"

        Case MODE_FATHER

            guide = "���ǉ��F���͔푊���l���̐��������\�����܂��B�Z���͔푊���l��O��Z������R�s�[�ł��܂��B�o�^��͔푊���l����ɖ߂��Ď���ǉ����܂��B"

        Case MODE_MOTHER

            guide = "��ǉ��F���͔푊���l���̐��������\�����܂��B�����͕�����ꍇ�������͂��܂��B�Z���͊�l���Ɠ��l�A�܂��͑O��Z��������őI�ׂ܂��B"

        Case MODE_CHILD

            guide = "�q�ǉ��F��l���̎q��o�^���܂��B��l�����q�E���Ȃ�A�푊���l���猩�������͑��E�]���֎������肵�܂��B"

        Case MODE_SIBLING

            guide = "�Z��o���ǉ��F���͔푊���l���̐��������\�����܂��B���ʂƐ��N����������ΌZ�E��E�o�E�����������肵�܂��B"

        Case MODE_GRANDCHILD

            guide = "���E���ʐ���ǉ��F��l�����q�Ȃ瑷�A���Ȃ�]���Ƃ��Ĉ����܂��B�e�q���𐳂����o�����߁A���ۂ̐e����l���ɂ��ēo�^���Ă��������B"

        Case Else

            guide = "���̑��֌W�ҁF���E�Z���͌�₩��I�ׂ܂��B�֌W����l�ɁA������̈ʒu�t����Z������Ă��������B"

    End Select

    If Len(baseName) > 0 Then guide = "��l���F" & baseName & "�@" & guide

    If Len(baseName) > 0 Then
        ws.Range("B3").Value = "���͒��F" & modeName & "�@��l���F" & baseName
    Else
        ws.Range("B3").Value = "���͒��F" & modeName
    End If
    Application.StatusBar = guide

End Sub

Private Function AutoRelationText(ByVal modeName As String, _
        ByVal baseId As String, _
        ByVal gender As String, _
        ByVal birthDate As Variant) As String

    Dim decId As String, baseRel As String

    decId = GetDecedentId()

    baseRel = GetPersonValue(baseId, P_REL_DEC)

    If Len(baseRel) = 0 Then baseRel = "��l��"

    Select Case modeName

        Case MODE_DECEDENT

            AutoRelationText = "�푊���l"

        Case MODE_SPOUSE

            If Len(baseId) = 0 Or baseId = decId Then

                AutoRelationText = "�z���"

            ElseIf NormalizedRelationLabel(baseRel) = "��" Then

                AutoRelationText = "��"

            ElseIf NormalizedRelationLabel(baseRel) = "��" Then

                AutoRelationText = "��"

            Else

                AutoRelationText = RelationViaBase(baseRel, "�z���", "�z���")

            End If

        Case MODE_FATHER

            If Len(baseId) = 0 Or baseId = decId Then

                AutoRelationText = "��"

            Else

                AutoRelationText = RelationViaBase(baseRel, "��", "��")

            End If

        Case MODE_MOTHER

            If Len(baseId) = 0 Or baseId = decId Then

                AutoRelationText = "��"

            Else

                AutoRelationText = RelationViaBase(baseRel, "��", "��")

            End If

        Case MODE_CHILD

            If Len(baseId) > 0 And baseId <> decId Then

                If BaseIsDirectChildRelation(baseRel) Then

                    AutoRelationText = "��"

                ElseIf BaseIsGrandchildRelation(baseRel) Then

                    AutoRelationText = "�]��"

                Else

                    AutoRelationText = RelationViaBase(baseRel, "�q", "�q")

                End If

            Else

                AutoRelationText = ChildRelationText(gender)

            End If

        Case MODE_SIBLING

            If Len(baseId) = 0 Or baseId = decId Then

                AutoRelationText = SiblingRelationText(gender, birthDate)

            Else

                AutoRelationText = RelationViaBase(baseRel, "�Z��o��", "�Z��o��")

            End If

        Case MODE_GRANDCHILD

            If Len(baseId) = 0 Or baseId = decId Then

                AutoRelationText = "��"

            ElseIf BaseIsDirectChildRelation(baseRel) Then

                AutoRelationText = "��"

            ElseIf BaseIsGrandchildRelation(baseRel) Then

                AutoRelationText = "�]��"

            ElseIf BaseIsGreatGrandchildRelation(baseRel) Then

                AutoRelationText = "����"

            Else

                AutoRelationText = RelationViaBase(baseRel, "�q", "��")

            End If

        Case Else

            If Len(baseId) > 0 And baseId <> decId Then

                AutoRelationText = RelationViaBase(baseRel, "�֌W��", "�֌W��")

            Else

                AutoRelationText = "�֌W��"

            End If

    End Select

End Function

Private Function ResolveRelationTextForRegistration(ByVal modeName As String, _
        ByVal baseId As String, _
        ByVal currentText As String, _
        ByVal gender As String, _
        ByVal birthDate As Variant) As String

    Dim suggested As String
    Dim bloodlineId As String, baseRel As String, bloodRel As String
    Dim marriageDate As Variant, divorceDate As Variant
    Dim level As Long, nextRel As String

    suggested = currentText
    If ShouldRecalculateAutoRelation(modeName, suggested) Then
        suggested = AutoRelationText(modeName, baseId, gender, birthDate)
    End If

    If modeName = MODE_CHILD Or modeName = MODE_GRANDCHILD Then
        baseRel = GetPersonValue(baseId, P_REL_DEC)
        If IsBaseSpouseOfDescendant(baseId, bloodlineId, marriageDate, divorceDate, birthDate) Then
            bloodRel = GetPersonValue(bloodlineId, P_REL_DEC)
            level = DescendantLevelFromRelation(bloodRel)
            nextRel = NextDescendantRelation(level)
            If Not IsDate(birthDate) Then
                ResolveRelationTextForRegistration = nextRel & "�i�������ԗv�m�F�j"
            ElseIf DateWithinMarriagePeriod(birthDate, marriageDate, divorceDate) Then
                ResolveRelationTextForRegistration = nextRel
            Else
                ResolveRelationTextForRegistration = bloodRel & "�̔z��҂̎q�i�O�z��҂Ƃ̎q�j"
            End If
            Exit Function
        End If

        level = DescendantLevelFromRelation(baseRel)
        If level >= 1 Then
            nextRel = NextDescendantRelation(level)
            If HasSpousePeriodForPerson(baseId, marriageDate, divorceDate, birthDate) Then
                If Not IsDate(birthDate) Then
                    ResolveRelationTextForRegistration = nextRel & "�i�������ԗv�m�F�j"
                    Exit Function
                ElseIf Not DateWithinMarriagePeriod(birthDate, marriageDate, divorceDate) Then
                    ResolveRelationTextForRegistration = nextRel & "�i�O�z��҂Ƃ̎q�j"
                    Exit Function
                End If
            End If
            ResolveRelationTextForRegistration = nextRel
            Exit Function
        End If
    End If

    ResolveRelationTextForRegistration = suggested

End Function

Private Function RelationBaseForRegistration(ByVal modeName As String, ByVal baseId As String, ByVal birthDate As Variant) As String

    Dim bloodlineId As String, marriageDate As Variant, divorceDate As Variant
    RelationBaseForRegistration = baseId
    If modeName = MODE_CHILD Or modeName = MODE_GRANDCHILD Then
        If IsBaseSpouseOfDescendant(baseId, bloodlineId, marriageDate, divorceDate, birthDate) Then
            If Not IsDate(birthDate) Or DateWithinMarriagePeriod(birthDate, marriageDate, divorceDate) Then
                RelationBaseForRegistration = bloodlineId
            End If
        End If
    End If

End Function

Private Function DescendantLevelFromRelation(ByVal relText As String) As Long

    relText = NormalizedRelationLabel(CleanText(relText))
    If InStr(relText, "�z���") > 0 Then Exit Function
    If BaseIsDirectChildRelation(relText) Then
        DescendantLevelFromRelation = 1
    ElseIf relText = "��" Or Left$(relText, 2) = "���i" Then
        DescendantLevelFromRelation = 2
    ElseIf IsGreatGrandchildLabelText(relText) Then
        DescendantLevelFromRelation = 3
    ElseIf relText = "����" Or Left$(relText, 2) = "����" Then
        DescendantLevelFromRelation = 4
    End If

End Function

Private Function IsGreatGrandchildLabelText(ByVal relText As String) As Boolean

    relText = CleanText(relText)
    If relText = "�]��" Or Left$(relText, 2) = "�]��" Then
        IsGreatGrandchildLabelText = True
    ElseIf relText = "�\��" Or Left$(relText, 2) = "�\��" Then
        IsGreatGrandchildLabelText = True
    ElseIf relText = "�Б�" Or Left$(relText, 3) = "�Б�" Then
        IsGreatGrandchildLabelText = True
    End If

End Function

Private Function RelationTextContainsGreatGrandchildLabel(ByVal relText As String) As Boolean

    relText = CleanText(relText)
    If InStr(relText, "�]��") > 0 Then
        RelationTextContainsGreatGrandchildLabel = True
    ElseIf InStr(relText, "�\��") > 0 Then
        RelationTextContainsGreatGrandchildLabel = True
    ElseIf InStr(relText, "�Б�") > 0 Then
        RelationTextContainsGreatGrandchildLabel = True
    End If

End Function

Private Function NextDescendantRelation(ByVal parentLevel As Long) As String

    Select Case parentLevel
        Case 1
            NextDescendantRelation = "��"
        Case 2
            NextDescendantRelation = "�]��"
        Case 3
            NextDescendantRelation = "����"
        Case 4
            NextDescendantRelation = "����"
        Case Else
            NextDescendantRelation = "�q"
    End Select

End Function

Private Function NextDescendantRelationLabelForChild(ByVal parentLevel As Long, ByVal currentLabel As String) As String

    Dim baseLabel As String
    baseLabel = NextDescendantRelation(parentLevel)
    If Len(baseLabel) = 0 Then Exit Function
    currentLabel = CleanText(currentLabel)
    If InStr(currentLabel, "�O�z���") > 0 Then
        NextDescendantRelationLabelForChild = baseLabel & "�i�O�z��҂Ƃ̎q�j"
    ElseIf InStr(currentLabel, "�������ԗv�m�F") > 0 Then
        NextDescendantRelationLabelForChild = baseLabel & "�i�������ԗv�m�F�j"
    Else
        NextDescendantRelationLabelForChild = baseLabel
    End If

End Function

Private Function IsBaseSpouseOfDescendant(ByVal baseId As String, _
        ByRef bloodlineId As String, _
        ByRef marriageDate As Variant, _
        ByRef divorceDate As Variant, _
        Optional ByVal targetDate As Variant) As Boolean

    Dim wr As Worksheet, r As Long, otherId As String, otherRel As String
    Dim firstBloodId As String, firstMarriage As Variant, firstDivorce As Variant
    Dim baseRow As Long, storedBaseId As String, storedRel As String, baseRelText As String
    If Len(baseId) = 0 Then Exit Function

    '�z��Ҋ֌W�s�����������f�[�^�ł��A�o�^���̊�l��ID���猌�����֖߂��B
    '�������A�������E������������ꍇ�́A�q�̏o�������_�ŕv�w���ԓ�������i�Ŕ���ł���悤���t���擾����B
    baseRow = FindPersonRow(baseId)
    If baseRow > 0 Then
        baseRelText = CleanText(GetPersonValue(baseId, P_REL_DEC)) & " " & CleanText(GetPersonValue(baseId, P_REL_DISP))
        If InStr(1, baseRelText, "�z���", vbTextCompare) > 0 Then
            storedBaseId = CleanText(ThisWorkbook.Worksheets(SH_W_PERSON).Cells(baseRow, P_SUR_SRC).Value)
            storedRel = CleanText(GetPersonValue(storedBaseId, P_REL_DEC))
            If DescendantLevelFromRelation(storedRel) >= 1 Then
                bloodlineId = storedBaseId
                SpouseRelationDatesForPair baseId, storedBaseId, marriageDate, divorceDate
                IsBaseSpouseOfDescendant = True
                Exit Function
            End If
        End If
    End If

    Set wr = ThisWorkbook.Worksheets(SH_W_REL)
    For r = 2 To LastRow(wr, 1)
        If CStr(wr.Cells(r, R_STATUS).Value) <> STATUS_CANCEL And CStr(wr.Cells(r, R_TYPE).Value) = "�z���" Then
            otherId = ""
            If CStr(wr.Cells(r, R_BASE_ID).Value) = baseId Then
                otherId = CStr(wr.Cells(r, R_OTHER_ID).Value)
            ElseIf CStr(wr.Cells(r, R_OTHER_ID).Value) = baseId Then
                otherId = CStr(wr.Cells(r, R_BASE_ID).Value)
            End If
            If Len(otherId) > 0 Then
                otherRel = GetPersonValue(otherId, P_REL_DEC)
                If DescendantLevelFromRelation(otherRel) >= 1 Then
                    If Len(firstBloodId) = 0 Then
                        firstBloodId = otherId
                        firstMarriage = wr.Cells(r, R_MARRIAGE).Value
                        firstDivorce = wr.Cells(r, R_DIVORCE).Value
                    End If
                    If Not IsDate(targetDate) Or DateWithinMarriagePeriod(targetDate, wr.Cells(r, R_MARRIAGE).Value, wr.Cells(r, R_DIVORCE).Value) Then
                        bloodlineId = otherId
                        marriageDate = wr.Cells(r, R_MARRIAGE).Value
                        divorceDate = wr.Cells(r, R_DIVORCE).Value
                        IsBaseSpouseOfDescendant = True
                        Exit Function
                    End If
                End If
            End If
        End If
    Next r
    If Len(firstBloodId) > 0 Then
        bloodlineId = firstBloodId
        marriageDate = firstMarriage
        divorceDate = firstDivorce
        IsBaseSpouseOfDescendant = True
    End If

End Function

Private Function SpouseRelationDatesForPair(ByVal leftId As String, ByVal rightId As String, ByRef marriageDate As Variant, ByRef divorceDate As Variant) As Boolean

    Dim wr As Worksheet, r As Long, b As String, o As String
    leftId = CleanText(leftId)
    rightId = CleanText(rightId)
    If Len(leftId) = 0 Or Len(rightId) = 0 Then Exit Function
    If Not SheetExists(SH_W_REL, ThisWorkbook) Then Exit Function
    Set wr = ThisWorkbook.Worksheets(SH_W_REL)
    For r = 2 To LastRow(wr, 1)
        If CStr(wr.Cells(r, R_STATUS).Value) <> STATUS_CANCEL And CStr(wr.Cells(r, R_TYPE).Value) = "�z���" Then
            b = CleanText(wr.Cells(r, R_BASE_ID).Value)
            o = CleanText(wr.Cells(r, R_OTHER_ID).Value)
            If (b = leftId And o = rightId) Or (b = rightId And o = leftId) Then
                marriageDate = wr.Cells(r, R_MARRIAGE).Value
                divorceDate = wr.Cells(r, R_DIVORCE).Value
                SpouseRelationDatesForPair = True
                Exit Function
            End If
        End If
    Next r

End Function

Private Function IsBaseSpouseOfDirectChild(ByVal baseId As String, _
        ByRef directChildId As String, _
        ByRef marriageDate As Variant, _
        ByRef divorceDate As Variant) As Boolean

    Dim wr As Worksheet, r As Long, otherId As String
    If Len(baseId) = 0 Then Exit Function
    Set wr = ThisWorkbook.Worksheets(SH_W_REL)
    For r = 2 To LastRow(wr, 1)
        If CStr(wr.Cells(r, R_STATUS).Value) <> STATUS_CANCEL And CStr(wr.Cells(r, R_TYPE).Value) = "�z���" Then
            otherId = ""
            If CStr(wr.Cells(r, R_BASE_ID).Value) = baseId Then
                otherId = CStr(wr.Cells(r, R_OTHER_ID).Value)
            ElseIf CStr(wr.Cells(r, R_OTHER_ID).Value) = baseId Then
                otherId = CStr(wr.Cells(r, R_BASE_ID).Value)
            End If
            If Len(otherId) > 0 Then
                If BaseIsDirectChildRelation(GetPersonValue(otherId, P_REL_DEC)) Then
                    directChildId = otherId
                    marriageDate = wr.Cells(r, R_MARRIAGE).Value
                    divorceDate = wr.Cells(r, R_DIVORCE).Value
                    IsBaseSpouseOfDirectChild = True
                    Exit Function
                End If
            End If
        End If
    Next r

End Function

Private Function IsBaseSpouseOfGrandchild(ByVal baseId As String, _
        ByRef grandChildId As String, _
        ByRef marriageDate As Variant, _
        ByRef divorceDate As Variant) As Boolean

    Dim wr As Worksheet, r As Long, otherId As String
    If Len(baseId) = 0 Then Exit Function
    Set wr = ThisWorkbook.Worksheets(SH_W_REL)
    For r = 2 To LastRow(wr, 1)
        If CStr(wr.Cells(r, R_STATUS).Value) <> STATUS_CANCEL And CStr(wr.Cells(r, R_TYPE).Value) = "�z���" Then
            otherId = ""
            If CStr(wr.Cells(r, R_BASE_ID).Value) = baseId Then
                otherId = CStr(wr.Cells(r, R_OTHER_ID).Value)
            ElseIf CStr(wr.Cells(r, R_OTHER_ID).Value) = baseId Then
                otherId = CStr(wr.Cells(r, R_BASE_ID).Value)
            End If
            If Len(otherId) > 0 Then
                If BaseIsGrandchildRelation(GetPersonValue(otherId, P_REL_DEC)) Then
                    grandChildId = otherId
                    marriageDate = wr.Cells(r, R_MARRIAGE).Value
                    divorceDate = wr.Cells(r, R_DIVORCE).Value
                    IsBaseSpouseOfGrandchild = True
                    Exit Function
                End If
            End If
        End If
    Next r

End Function

Private Function HasSpousePeriodForPerson(ByVal personId As String, _
        ByRef marriageDate As Variant, _
        ByRef divorceDate As Variant, _
        Optional ByVal targetDate As Variant) As Boolean

    Dim wr As Worksheet, we As Worksheet, wp As Worksheet, r As Long, personRow As Long
    Dim firstM As Variant, firstD As Variant, hasAny As Boolean
    If Len(personId) = 0 Then Exit Function

    Set wr = ThisWorkbook.Worksheets(SH_W_REL)
    For r = 2 To LastRow(wr, 1)
        If CStr(wr.Cells(r, R_STATUS).Value) <> STATUS_CANCEL And CStr(wr.Cells(r, R_TYPE).Value) = "�z���" Then
            If CStr(wr.Cells(r, R_BASE_ID).Value) = personId Or CStr(wr.Cells(r, R_OTHER_ID).Value) = personId Then
                If IsDate(wr.Cells(r, R_MARRIAGE).Value) Or IsDate(wr.Cells(r, R_DIVORCE).Value) Then
                    If Not hasAny Then
                        firstM = wr.Cells(r, R_MARRIAGE).Value
                        firstD = wr.Cells(r, R_DIVORCE).Value
                        hasAny = True
                    End If
                    If Not IsDate(targetDate) Or DateWithinMarriagePeriod(targetDate, wr.Cells(r, R_MARRIAGE).Value, wr.Cells(r, R_DIVORCE).Value) Then
                        marriageDate = wr.Cells(r, R_MARRIAGE).Value
                        divorceDate = wr.Cells(r, R_DIVORCE).Value
                        HasSpousePeriodForPerson = True
                        Exit Function
                    End If
                End If
            End If
        End If
    Next r

    '�z��҂�l���o�^���Ă��Ȃ����������A��������̍������ԂƂ��Ďg���B
    '�����C�x���g��P�Ƃ̊J�����ԂƂ��Ĉ����ƁA������̏o���܂ō����������ɂȂ邽�߁A
    '����̓C�x���g������Ԃ�g�ݗ��ĂĔ��肷��B
    If ManualMarriagePeriodForPerson(personId, targetDate, marriageDate, divorceDate) Then
        If Not hasAny Then
            firstM = marriageDate
            firstD = divorceDate
            hasAny = True
        End If
        If Not IsDate(targetDate) Or DateWithinMarriagePeriod(targetDate, marriageDate, divorceDate) Then
            HasSpousePeriodForPerson = True
            Exit Function
        End If
    End If

    personRow = FindPersonRow(personId)
    If personRow > 0 Then
        Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)
        If IsDate(wp.Cells(personRow, P_MARRIAGE).Value) Or IsDate(wp.Cells(personRow, P_DIVORCE).Value) Then
            If Not hasAny Then
                firstM = wp.Cells(personRow, P_MARRIAGE).Value
                firstD = wp.Cells(personRow, P_DIVORCE).Value
                hasAny = True
            End If
            If Not IsDate(targetDate) Or DateWithinMarriagePeriod(targetDate, wp.Cells(personRow, P_MARRIAGE).Value, wp.Cells(personRow, P_DIVORCE).Value) Then
                marriageDate = wp.Cells(personRow, P_MARRIAGE).Value
                divorceDate = wp.Cells(personRow, P_DIVORCE).Value
                HasSpousePeriodForPerson = True
                Exit Function
            End If
        End If
    End If

    If hasAny Then
        marriageDate = firstM
        divorceDate = firstD
        HasSpousePeriodForPerson = True
    End If

End Function

Private Function ManualMarriagePeriodForPerson(ByVal personId As String, _
        ByVal targetDate As Variant, _
        ByRef marriageDate As Variant, _
        ByRef divorceDate As Variant) As Boolean

    Dim we As Worksheet, r As Long, d As Date, t As Date
    Dim firstM As Variant, firstD As Variant, bestM As Variant, bestD As Variant
    Dim hasAny As Boolean, m As Variant, dAfterM As Variant
    If Len(personId) = 0 Then Exit Function
    If Not SheetExists(SH_W_EVENT, ThisWorkbook) Then Exit Function
    Set we = ThisWorkbook.Worksheets(SH_W_EVENT)

    For r = 2 To LastRow(we, 1)
        If CStr(we.Cells(r, E_PERSON_ID).Value) = personId _
                And CStr(we.Cells(r, E_STATUS).Value) <> STATUS_CANCEL _
                And IsDate(we.Cells(r, E_DATE).Value) Then
            If CStr(we.Cells(r, E_TYPE).Value) = "����" Or CStr(we.Cells(r, E_TYPE).Value) = "����" Then
                If Not hasAny Then
                    If CStr(we.Cells(r, E_TYPE).Value) = "����" Then firstM = we.Cells(r, E_DATE).Value Else firstD = we.Cells(r, E_DATE).Value
                    hasAny = True
                End If
                If CStr(we.Cells(r, E_TYPE).Value) = "����" Then
                    If Not IsDate(firstM) Then
                        firstM = we.Cells(r, E_DATE).Value
                    ElseIf CDate(we.Cells(r, E_DATE).Value) < CDate(firstM) Then
                        firstM = we.Cells(r, E_DATE).Value
                    End If
                ElseIf CStr(we.Cells(r, E_TYPE).Value) = "����" Then
                    If Not IsDate(firstD) Then
                        firstD = we.Cells(r, E_DATE).Value
                    ElseIf CDate(we.Cells(r, E_DATE).Value) < CDate(firstD) Then
                        firstD = we.Cells(r, E_DATE).Value
                    End If
                End If
            End If
        End If
    Next r
    If Not hasAny Then Exit Function

    If IsDate(targetDate) Then
        t = CDate(targetDate)
        'target���ȑO�̍ŐV������T���B
        For r = 2 To LastRow(we, 1)
            If CStr(we.Cells(r, E_PERSON_ID).Value) = personId _
                    And CStr(we.Cells(r, E_STATUS).Value) <> STATUS_CANCEL _
                    And CStr(we.Cells(r, E_TYPE).Value) = "����" _
                    And IsDate(we.Cells(r, E_DATE).Value) Then
                d = CDate(we.Cells(r, E_DATE).Value)
                If d <= t Then
                    If Not IsDate(bestM) Then
                        bestM = d
                    ElseIf d > CDate(bestM) Then
                        bestM = d
                    End If
                End If
            End If
        Next r
        If IsDate(bestM) Then
            '���̍�����̍ŏ��̗�����T���B
            For r = 2 To LastRow(we, 1)
                If CStr(we.Cells(r, E_PERSON_ID).Value) = personId _
                        And CStr(we.Cells(r, E_STATUS).Value) <> STATUS_CANCEL _
                        And CStr(we.Cells(r, E_TYPE).Value) = "����" _
                        And IsDate(we.Cells(r, E_DATE).Value) Then
                    d = CDate(we.Cells(r, E_DATE).Value)
                    If d >= CDate(bestM) Then
                        If Not IsDate(dAfterM) Then
                            dAfterM = d
                        ElseIf d < CDate(dAfterM) Then
                            dAfterM = d
                        End If
                    End If
                End If
            Next r
            marriageDate = bestM
            divorceDate = dAfterM
            ManualMarriagePeriodForPerson = True
            Exit Function
        End If
    End If

    marriageDate = firstM
    divorceDate = firstD
    ManualMarriagePeriodForPerson = True

End Function

Private Function DateWithinMarriagePeriod(ByVal targetDate As Variant, ByVal marriageDate As Variant, ByVal divorceDate As Variant) As Boolean

    If Not IsDate(targetDate) Then DateWithinMarriagePeriod = True: Exit Function
    If IsDate(marriageDate) Then
        If CDate(targetDate) < CDate(marriageDate) Then Exit Function
    End If
    If IsDate(divorceDate) Then
        If CDate(targetDate) > CDate(divorceDate) Then Exit Function
    End If
    DateWithinMarriagePeriod = True

End Function

Private Function RelationViaBase(ByVal baseRel As String, ByVal suffixText As String, ByVal fallbackText As String) As String

    baseRel = CleanText(baseRel)

    If Len(baseRel) = 0 Or baseRel = "�푊���l" Then

        RelationViaBase = fallbackText

    ElseIf InStr(baseRel, "��") > 0 Then

        RelationViaBase = baseRel & "�E" & suffixText

    Else

        RelationViaBase = baseRel & "��" & suffixText

    End If

End Function

Private Function BaseIsDirectChildRelation(ByVal baseRel As String) As Boolean

    baseRel = CleanText(baseRel)
    If InStr(baseRel, "�i") > 0 Then baseRel = Left$(baseRel, InStr(baseRel, "�i") - 1)
    If baseRel = "�q" Or baseRel = "�{�q" Then
        BaseIsDirectChildRelation = True
    ElseIf ChildOrdinalIndex(baseRel, "�j") > 0 Or ChildOrdinalIndex(baseRel, "��") > 0 Then
        BaseIsDirectChildRelation = True
    End If

End Function

Private Function BaseIsGrandchildRelation(ByVal baseRel As String) As Boolean

    baseRel = CleanText(baseRel)
    If InStr(baseRel, "�z���") > 0 Then Exit Function
    BaseIsGrandchildRelation = (baseRel = "��" Or Left$(baseRel, 2) = "���i")

End Function

Private Function BaseIsGreatGrandchildRelation(ByVal baseRel As String) As Boolean

    baseRel = CleanText(baseRel)
    If InStr(baseRel, "�z���") > 0 Then Exit Function
    BaseIsGreatGrandchildRelation = IsGreatGrandchildLabelText(baseRel)

End Function


Private Function IsDirectDescendantRelationText(ByVal relText As String) As Boolean

    relText = CleanText(relText)
    If InStr(relText, "�z���") > 0 Then Exit Function
    If BaseIsDirectChildRelation(relText) Then
        IsDirectDescendantRelationText = True
    ElseIf relText = "��" Or relText = "�]��" Or relText = "�Б�" Or relText = "�\��" Or relText = "����" Or Left$(relText, 2) = "���i" Or Left$(relText, 3) = "�Б�" Or Left$(relText, 2) = "����" Then
        IsDirectDescendantRelationText = True
    End If

End Function

Private Function SuggestedGender(ByVal modeName As String, ByVal baseId As String) As String

    Dim baseGender As String

    Select Case modeName

        Case MODE_FATHER

            SuggestedGender = "�j"

        Case MODE_MOTHER

            SuggestedGender = "��"

        Case MODE_SPOUSE

            baseGender = GetPersonValue(baseId, P_GENDER)

            If baseGender = "�j" Then

                SuggestedGender = "��"

            ElseIf baseGender = "��" Then

                SuggestedGender = "�j"

            End If

    End Select

End Function


Public Sub NormalizePersonRelationLabels()

    Dim ws As Worksheet, r As Long, relText As String, fixedText As String
    If Not SheetExists(SH_W_PERSON, ThisWorkbook) Then Exit Sub
    Set ws = ThisWorkbook.Worksheets(SH_W_PERSON)
    For r = 2 To LastRow(ws, 1)
        If CStr(ws.Cells(r, P_STATUS).Value) <> STATUS_CANCEL Then
            relText = CleanText(ws.Cells(r, P_REL_DEC).Value)
            fixedText = NormalizedRelationLabel(relText)
            fixedText = NormalizeParentSpouseRelationLabel(ws, r, fixedText)
            fixedText = NormalizeRelationLabelByStoredParent(ws, r, fixedText)
            If Len(fixedText) > 0 And fixedText <> relText Then
                ws.Cells(r, P_REL_DEC).Value = fixedText
                ws.Cells(r, P_REL_DISP).Value = fixedText
            End If
        End If
    Next r

End Sub

Private Function NormalizeParentSpouseRelationLabel(ByVal ws As Worksheet, ByVal personRow As Long, ByVal currentLabel As String) As String

    Dim rawText As String, srcId As String, srcRel As String, noteText As String
    NormalizeParentSpouseRelationLabel = currentLabel
    If ws Is Nothing Then Exit Function
    If personRow <= 0 Then Exit Function
    rawText = CleanText(ws.Cells(personRow, P_REL_DEC).Value) & " " & CleanText(ws.Cells(personRow, P_REL_DISP).Value)
    noteText = CleanText(ws.Cells(personRow, P_NOTE).Value)
    If InStr(1, noteText, "�O�z���", vbTextCompare) > 0 Or InStr(1, noteText, "�p", vbTextCompare) > 0 Or InStr(1, noteText, "���", vbTextCompare) > 0 Or InStr(1, noteText, "��v", vbTextCompare) > 0 Then Exit Function
    srcId = CleanText(ws.Cells(personRow, P_SUR_SRC).Value)
    If Len(srcId) > 0 Then srcRel = NormalizedRelationLabel(CleanText(GetPersonValue(srcId, P_REL_DEC)))
    If InStr(1, rawText, "���̔z���", vbTextCompare) > 0 Or (srcRel = "��" And InStr(1, rawText, "�z���", vbTextCompare) > 0) Then
        NormalizeParentSpouseRelationLabel = "��"
    ElseIf InStr(1, rawText, "��̔z���", vbTextCompare) > 0 Or (srcRel = "��" And InStr(1, rawText, "�z���", vbTextCompare) > 0) Then
        NormalizeParentSpouseRelationLabel = "��"
    End If

End Function

Private Function NormalizeRelationLabelByStoredParent(ByVal ws As Worksheet, ByVal personRow As Long, ByVal currentLabel As String) As String

    Dim parentId As String, parentRow As Long, childId As String
    Dim parentRel As String, parentLevel As Long, childLevel As Long, expectedLabel As String
    NormalizeRelationLabelByStoredParent = currentLabel
    If ws Is Nothing Then Exit Function
    If personRow <= 0 Then Exit Function
    If InStr(1, currentLabel, "�z���", vbTextCompare) > 0 Then Exit Function

    childId = CleanText(ws.Cells(personRow, P_ID).Value)
    childLevel = DescendantLevelFromRelation(currentLabel)
    If Len(childId) = 0 Or childLevel <= 0 Then Exit Function

    '��1���: �o�^���Ɏc������l��ID�B�����⊮���s�v�ȓ����P�[�X�ł��e�q���̕����Ɏg���B
    parentId = CleanText(ws.Cells(personRow, P_SUR_SRC).Value)
    If Not RelationLabelParentCandidateIsUsable(parentId, childId, childLevel, True) Then
        parentId = ""
    End If

    '��2���: W_�֌W�̐e�q�s�B���f�[�^�� P_SUR_SRC ����ł��AR_BASE_ID=�e/R_OTHER_ID=�q �̍s���c��ꍇ������B
    If Len(parentId) = 0 Then parentId = UniqueRelationParentIdForLabelCorrection(childId, childLevel)
    If Len(parentId) = 0 Then Exit Function

    parentRow = FindPersonRow(parentId)
    If parentRow = 0 Then Exit Function
    parentRel = NormalizedRelationLabel(CleanText(ws.Cells(parentRow, P_REL_DEC).Value))
    parentLevel = DescendantLevelFromRelation(parentRel)

    '���ۂ̐eID���c���Ă���̂ɁA�q�̐��ド�x�����e�Ɠ�����������󂢏ꍇ��1���㉺�֒����B
    '��: �]����e�ɂ��ēo�^���ꂽ�q���u�]���v�̂܂܂Ȃ�u�����v�ɕ␳����B
    If parentLevel > 0 Then
        If childLevel <= parentLevel Then
            expectedLabel = NextDescendantRelationLabelForChild(parentLevel, currentLabel)
            If Len(expectedLabel) > 0 Then NormalizeRelationLabelByStoredParent = expectedLabel
        End If
    End If

End Function

Private Function RelationLabelParentCandidateIsUsable(ByVal candidateId As String, ByVal childId As String, ByVal childLevel As Long, Optional ByVal allowStaleChildLevel As Boolean = False) As Boolean

    Dim parentRow As Long, parentLevel As Long, parentRel As String
    candidateId = CleanText(candidateId)
    childId = CleanText(childId)
    If Len(candidateId) = 0 Or Len(childId) = 0 Then Exit Function
    If candidateId = childId Then Exit Function
    parentRow = FindPersonRow(candidateId)
    If parentRow = 0 Then Exit Function
    parentRel = NormalizedRelationLabel(CleanText(ThisWorkbook.Worksheets(SH_W_PERSON).Cells(parentRow, P_REL_DEC).Value))
    parentLevel = DescendantLevelFromRelation(parentRel)
    If parentLevel <= 0 Then Exit Function
    If childLevel = parentLevel + 1 Then
        RelationLabelParentCandidateIsUsable = True
    ElseIf allowStaleChildLevel Then
        RelationLabelParentCandidateIsUsable = (childLevel <= parentLevel)
    End If

End Function

Private Function UniqueRelationParentIdForLabelCorrection(ByVal childId As String, ByVal childLevel As Long) As String

    Dim wr As Worksheet, r As Long, candidateId As String, foundId As String, foundCount As Long
    Dim currentDirection As Boolean
    childId = CleanText(childId)
    If Len(childId) = 0 Or childLevel <= 0 Then Exit Function
    If Not SheetExists(SH_W_REL, ThisWorkbook) Then Exit Function
    Set wr = ThisWorkbook.Worksheets(SH_W_REL)
    For r = 2 To LastRow(wr, 1)
        If CleanText(wr.Cells(r, R_STATUS).Value) <> STATUS_CANCEL And CleanText(wr.Cells(r, R_TYPE).Value) = "�e�q" Then
            candidateId = ""
            currentDirection = False
            '���s�o�^�� R_BASE_ID=�e / R_OTHER_ID=�q�B�����͖��������Ƃ��ċ����M������B
            If CleanText(wr.Cells(r, R_OTHER_ID).Value) = childId Then
                candidateId = CleanText(wr.Cells(r, R_BASE_ID).Value)
                currentDirection = True
            ElseIf CleanText(wr.Cells(r, R_BASE_ID).Value) = childId Then
                '���ł̋t�����s�����~�ρB������������E�󂢐���̋~�ς͂��Ȃ��B
                candidateId = CleanText(wr.Cells(r, R_OTHER_ID).Value)
            End If
            If RelationLabelParentCandidateIsUsable(candidateId, childId, childLevel, currentDirection) Then
                If Len(foundId) = 0 Then
                    foundId = candidateId
                    foundCount = 1
                ElseIf foundId <> candidateId Then
                    UniqueRelationParentIdForLabelCorrection = ""
                    Exit Function
                End If
            End If
        End If
    Next r
    If foundCount = 1 Then UniqueRelationParentIdForLabelCorrection = foundId

End Function

Private Function NormalizedRelationLabel(ByVal relText As String) As String

    Dim rawText As String
    rawText = CleanText(relText)
    relText = rawText
    If Len(relText) = 0 Then Exit Function

    '���[�E���͌��̐��K�\�L�́u�]���v�B���\�L�u�Б��v�u�\���v�͓ǂݍ��݌݊��Ƃ��Ď󂯂�B
    If RelationTextContainsGreatGrandchildLabel(relText) Then
        If InStr(relText, "�z���") > 0 Then
            If InStr(relText, "�q") > 0 Then
                NormalizedRelationLabel = RelationLabelWithNotes("����", rawText)
                Exit Function
            End If
        End If
        If InStr(relText, "�̎q") > 0 Or InStr(relText, "�E�q") > 0 Then
            NormalizedRelationLabel = RelationLabelWithNotes("����", rawText)
            Exit Function
        End If
    End If

    If InStr(relText, "��") > 0 Then
        If Not RelationTextContainsGreatGrandchildLabel(relText) Then
            If InStr(relText, "�z���") > 0 Then
                If InStr(relText, "�q") > 0 Then
                    NormalizedRelationLabel = RelationLabelWithNotes("�]��", rawText)
                    Exit Function
                End If
            End If
            If InStr(relText, "���̎q") > 0 Or InStr(relText, "���E�q") > 0 Then
                NormalizedRelationLabel = RelationLabelWithNotes("�]��", rawText)
                Exit Function
            End If
        End If
    End If

    If (relText = "��" Or Left$(relText, 2) = "���i") And InStr(relText, "�̔z���") = 0 Then
        NormalizedRelationLabel = relText
    ElseIf IsGreatGrandchildLabelText(relText) And InStr(relText, "�̔z���") = 0 Then
        NormalizedRelationLabel = RelationLabelWithNotes("�]��", rawText)
    ElseIf (relText = "����" Or Left$(relText, 2) = "����") And InStr(relText, "�̔z���") = 0 Then
        NormalizedRelationLabel = relText
    Else
        NormalizedRelationLabel = relText
    End If

End Function

Private Function RelationLabelWithNotes(ByVal baseLabel As String, ByVal rawText As String) As String

    Dim s As String
    s = baseLabel
    rawText = CleanText(rawText)
    If InStr(rawText, "�O�z���") > 0 Then
        If InStr(s, "�O�z���") = 0 Then s = s & "�i�O�z��҂Ƃ̎q�j"
    ElseIf InStr(rawText, "�������ԗv�m�F") > 0 Then
        If InStr(s, "�������ԗv�m�F") = 0 Then s = s & "�i�������ԗv�m�F�j"
    End If
    RelationLabelWithNotes = s

End Function

Public Sub RefreshCurrentRelationText()

    Dim ws As Worksheet, modeName As String, baseId As String

    Set ws = ThisWorkbook.Worksheets(SH_INPUT)

    modeName = CleanText(ws.Range(CELL_MODE).Value)

    If Len(modeName) = 0 Then Exit Sub

    baseId = CleanText(ws.Range(CELL_BASE_ID).Value)

    ws.Range(CELL_REL_TO_DECEDENT).Value = ResolveRelationTextForRegistration(modeName, baseId, _
        CleanText(ws.Range(CELL_REL_TO_DECEDENT).Value), CleanText(ws.Range(CELL_GENDER).Value), ws.Range(CELL_BIRTH).Value)

End Sub

Private Function ChildRelationText(ByVal gender As String) As String

    If gender = "�j" Then
        ChildRelationText = ChildOrdinalLabel("�j", NextChildOrdinal("�j"))
    ElseIf gender = "��" Then
        ChildRelationText = ChildOrdinalLabel("��", NextChildOrdinal("��"))
    Else
        ChildRelationText = "�q"
    End If

End Function

Private Function CountRelationStartsWith(ByVal a As String, ByVal b As String, ByVal c As String, ByVal g As String) As Long

    Dim ws As Worksheet, r As Long, lastR As Long, v As String

    Set ws = ThisWorkbook.Worksheets(SH_W_PERSON)

    lastR = LastRow(ws, 1)

    For r = 2 To lastR

        v = CStr(ws.Cells(r, P_REL_DEC).Value)

        If v = a Or v = b Or v = c Or InStr(v, g) > 0 Then CountRelationStartsWith = CountRelationStartsWith + 1

    Next r

End Function

Private Function ShouldRecalculateAutoRelation(ByVal modeName As String, ByVal relText As String) As Boolean

    relText = CleanText(relText)
    If Len(relText) = 0 Then
        ShouldRecalculateAutoRelation = True
        Exit Function
    End If
    If relText = "�q" Or relText = "�Z��o��" Or relText = "��l���̎q" Then
        ShouldRecalculateAutoRelation = True
        Exit Function
    End If
    Select Case modeName
        Case MODE_CHILD
            ShouldRecalculateAutoRelation = IsDirectChildAutoRelation(relText) _
                Or InStr(1, relText, "�������ԗv�m�F", vbTextCompare) > 0 _
                Or InStr(1, relText, "�O�z��҂Ƃ̎q", vbTextCompare) > 0
        Case MODE_SIBLING
            ShouldRecalculateAutoRelation = (relText = "�Z" Or relText = "��" Or relText = "�o" Or relText = "��" _
                Or relText = "�Z��" Or relText = "�o��" Or relText = "�Z��o��")
        Case MODE_GRANDCHILD
            ShouldRecalculateAutoRelation = (relText = "��" Or relText = "�]��" Or relText = "�Б�" Or relText = "�\��" Or relText = "����" _
                Or InStr(1, relText, "�������ԗv�m�F", vbTextCompare) > 0 _
                Or InStr(1, relText, "�O�z��҂Ƃ̎q", vbTextCompare) > 0)
        Case MODE_FATHER, MODE_MOTHER, MODE_SPOUSE
            ShouldRecalculateAutoRelation = (relText = modeName Or InStr(1, relText, "��" & modeName, vbTextCompare) > 0)
    End Select

End Function

Private Function IsDirectChildAutoRelation(ByVal relText As String) As Boolean

    relText = CleanText(relText)
    If InStr(relText, "�i") > 0 Then relText = Left$(relText, InStr(relText, "�i") - 1)
    If relText = "�q" Then
        IsDirectChildAutoRelation = True
    ElseIf ChildOrdinalIndex(relText, "�j") > 0 Or ChildOrdinalIndex(relText, "��") > 0 Then
        IsDirectChildAutoRelation = True
    End If

End Function

Private Function NextChildOrdinal(ByVal gender As String) As Long

    Dim ws As Worksheet, r As Long, lastR As Long, relText As String, idx As Long, maxIdx As Long
    Set ws = ThisWorkbook.Worksheets(SH_W_PERSON)
    lastR = LastRow(ws, 1)
    For r = 2 To lastR
        If CStr(ws.Cells(r, P_STATUS).Value) <> STATUS_CANCEL Then
            relText = CleanText(ws.Cells(r, P_REL_DEC).Value)
            idx = ChildOrdinalIndex(relText, gender)
            If idx > maxIdx Then maxIdx = idx
        End If
    Next r
    NextChildOrdinal = maxIdx + 1
    If NextChildOrdinal < 1 Then NextChildOrdinal = 1

End Function

Private Function ChildOrdinalIndex(ByVal relText As String, ByVal gender As String) As Long

    relText = CleanText(relText)
    If InStr(relText, "�i") > 0 Then relText = Left$(relText, InStr(relText, "�i") - 1)
    If gender = "�j" Then
        Select Case relText
            Case "���j": ChildOrdinalIndex = 1
            Case "��j": ChildOrdinalIndex = 2
            Case "�O�j": ChildOrdinalIndex = 3
            Case "�l�j": ChildOrdinalIndex = 4
            Case "�ܒj": ChildOrdinalIndex = 5
            Case "�Z�j": ChildOrdinalIndex = 6
            Case "���j": ChildOrdinalIndex = 7
            Case "���j": ChildOrdinalIndex = 8
            Case "��j": ChildOrdinalIndex = 9
            Case "�\�j": ChildOrdinalIndex = 10
        End Select
    ElseIf gender = "��" Then
        Select Case relText
            Case "����": ChildOrdinalIndex = 1
            Case "��": ChildOrdinalIndex = 2
            Case "�O��": ChildOrdinalIndex = 3
            Case "�l��": ChildOrdinalIndex = 4
            Case "�܏�": ChildOrdinalIndex = 5
            Case "�Z��": ChildOrdinalIndex = 6
            Case "����": ChildOrdinalIndex = 7
            Case "����": ChildOrdinalIndex = 8
            Case "�㏗": ChildOrdinalIndex = 9
            Case "�\��": ChildOrdinalIndex = 10
        End Select
    End If

End Function

Private Function ChildOrdinalLabel(ByVal gender As String, ByVal idx As Long) As String

    Dim suffixText As String
    If gender = "��" Then
        suffixText = "��"
    Else
        suffixText = "�j"
    End If
    Select Case idx
        Case 1
            If gender = "��" Then
                ChildOrdinalLabel = "����"
            Else
                ChildOrdinalLabel = "���j"
            End If
        Case 2
            ChildOrdinalLabel = "��" & suffixText
        Case 3
            ChildOrdinalLabel = "�O" & suffixText
        Case 4
            ChildOrdinalLabel = "�l" & suffixText
        Case 5
            ChildOrdinalLabel = "��" & suffixText
        Case 6
            ChildOrdinalLabel = "�Z" & suffixText
        Case 7
            ChildOrdinalLabel = "��" & suffixText
        Case 8
            ChildOrdinalLabel = "��" & suffixText
        Case 9
            ChildOrdinalLabel = "��" & suffixText
        Case 10
            ChildOrdinalLabel = "�\" & suffixText
        Case Else
            ChildOrdinalLabel = "�q"
    End Select

End Function

Private Function SiblingRelationText(ByVal gender As String, ByVal birthDate As Variant) As String

    Dim decId As String, decBirth As Variant, older As Boolean

    decId = GetDecedentId()

    decBirth = GetPersonValue(decId, P_BIRTH)

    If Not IsDate(birthDate) Or Not IsDate(decBirth) Then
        If gender = "�j" Then
            SiblingRelationText = "�Z��"
        ElseIf gender = "��" Then
            SiblingRelationText = "�o��"
        Else
            SiblingRelationText = "�Z��o��"
        End If
        Exit Function
    End If

    older = CDate(birthDate) < CDate(decBirth)

    If gender = "�j" Then
        If older Then
            SiblingRelationText = "�Z"
        Else
            SiblingRelationText = "��"
        End If
    ElseIf gender = "��" Then
        If older Then
            SiblingRelationText = "�o"
        Else
            SiblingRelationText = "��"
        End If
    Else
        SiblingRelationText = "�Z��o��"
    End If

End Function

Private Sub AddRelationIfNeeded(ByVal baseId As String, _
        ByVal otherId As String, _
        ByVal modeName As String, _
        ByVal relationText As String, _
        ByVal marriageDate As Variant, _
        ByVal divorceDate As Variant)
    If Len(baseId) = 0 Or Len(otherId) = 0 Then Exit Sub
    If baseId = otherId Then Exit Sub

    Dim ws As Worksheet, r As Long, relationType As String
    Dim writeBaseId As String, writeOtherId As String

    Set ws = ThisWorkbook.Worksheets(SH_W_REL)
    relationType = "���̑�"
    writeBaseId = baseId
    writeOtherId = otherId

    If modeName = MODE_SPOUSE Then relationType = "�z���"
    If modeName = MODE_CHILD Or modeName = MODE_FATHER Or modeName = MODE_MOTHER Or modeName = MODE_GRANDCHILD Then relationType = "�e�q"
    If modeName = MODE_SIBLING Then relationType = "�Z��o��"

    '�e�q�֌W�͕K�� R_BASE_ID=�e�AR_OTHER_ID=�q �ɐ��K�����ĕۑ�����B
    '����o�^���� base=�q / other=�e �ɂȂ�₷���A�}�E���n��E���͂ŋt�������̂ɂȂ邽�ߓ����Œׂ��B
    If relationType = "�e�q" Then
        If modeName = MODE_FATHER Or modeName = MODE_MOTHER Then
            writeBaseId = otherId
            writeOtherId = baseId
        Else
            writeBaseId = baseId
            writeOtherId = otherId
        End If
    End If

    r = FindExistingRelationRow(writeBaseId, writeOtherId, relationType)
    If r = 0 And (relationType = "�z���" Or relationType = "�Z��o��" Or relationType = "�e�q") Then
        r = FindExistingRelationRow(writeOtherId, writeBaseId, relationType)
    End If
    If r = 0 Then
        r = NextBlankRow(ws, 1)
        ws.Cells(r, R_ID).Value = NextId("�֌W")
        ws.Cells(r, R_CREATED).Value = Now
    End If
    ws.Cells(r, R_BASE_ID).Value = writeBaseId
    ws.Cells(r, R_OTHER_ID).Value = writeOtherId
    ws.Cells(r, R_TYPE).Value = relationType
    ws.Cells(r, R_DISPLAY).Value = relationText
    If relationType = "�z���" Then
        ws.Cells(r, R_MARRIAGE).Value = SameDateOrBlank(marriageDate)
        ws.Cells(r, R_DIVORCE).Value = SameDateOrBlank(divorceDate)
    Else
        ws.Cells(r, R_MARRIAGE).ClearContents
        ws.Cells(r, R_DIVORCE).ClearContents
    End If
    ws.Cells(r, R_AUTO).Value = "����"
    ws.Cells(r, R_STATUS).Value = STATUS_ACTIVE
    ws.Cells(r, R_UPDATED).Value = Now
End Sub

Private Function FindExistingRelationRow(ByVal baseId As String, ByVal otherId As String, ByVal relationType As String) As Long
    Dim ws As Worksheet, r As Long, lastR As Long
    Set ws = ThisWorkbook.Worksheets(SH_W_REL)
    lastR = LastRow(ws, 1)
    For r = 2 To lastR
        If CStr(ws.Cells(r, R_STATUS).Value) <> STATUS_CANCEL Then
            If CStr(ws.Cells(r, R_BASE_ID).Value) = baseId _
                    And CStr(ws.Cells(r, R_OTHER_ID).Value) = otherId _
                    And CStr(ws.Cells(r, R_TYPE).Value) = relationType Then
                FindExistingRelationRow = r
                Exit Function
            End If
        End If
    Next r
End Function

Private Sub RegisterAddressFromInput(ByVal personId As String)

    Dim wsIn As Worksheet, addressText As String, addressKey As String, candId As String

    Dim addrId As String, r As Long, wsA As Worksheet, personRow As Long

    Dim addrType As String, startValue As Variant, endValue As Variant, startKind As String

    Set wsIn = ThisWorkbook.Worksheets(SH_INPUT)

    addressText = CleanText(wsIn.Range(CELL_ADDR_TEXT).Value)

    If Len(addressText) = 0 Or Len(personId) = 0 Then Exit Sub

    addressKey = CleanText(wsIn.Range(CELL_ADDR_KEY).Value)

    If Len(addressKey) = 0 Then addressKey = NormalizeAddress(addressText)

    wsIn.Range(CELL_ADDR_KEY).Value = addressKey

    addrType = CleanText(wsIn.Range(CELL_ADDR_TYPE).Value)

    If Len(addrType) = 0 Then addrType = "���Z�n"

    startValue = SameDateOrBlank(wsIn.Range(CELL_ADDR_START).Value)

    endValue = SameDateOrBlank(wsIn.Range(CELL_ADDR_END).Value)

    startKind = AddressStartKindFromInput(personId)

    candId = GetOrCreateAddressCandidate(addressText, addressKey, personId)

    Set wsA = ThisWorkbook.Worksheets(SH_W_ADDR_HIST)

    r = FindMatchingAddressHistoryRow(personId, addressKey, addrType, startValue, endValue)

    If r > 0 Then

        addrId = CStr(wsA.Cells(r, A_ID).Value)

        wsA.Cells(r, A_CAND_ID).Value = candId

        wsA.Cells(r, A_TEXT).Value = addressText

        wsA.Cells(r, A_KEY).Value = addressKey

        wsA.Cells(r, A_SOURCE).Value = CleanText(wsIn.Range(CELL_ADDR_SOURCE).Value)

        wsA.Cells(r, A_COPY_PERSON_ID).Value = CleanText(wsIn.Range(CELL_BASE_ID).Value)

        wsA.Cells(r, A_NOTE).Value = CleanText(wsIn.Range(CELL_ADDR_NOTE).Value)

        wsA.Cells(r, A_STATUS).Value = STATUS_ACTIVE

        wsA.Cells(r, A_UPDATED).Value = Now

        wsA.Cells(r, A_START_KIND).Value = startKind

    Else

        r = NextBlankRow(wsA, 1)

        addrId = NextId("�Z������")

        wsA.Cells(r, A_ID).Value = addrId

        wsA.Cells(r, A_PERSON_ID).Value = personId

        wsA.Cells(r, A_CAND_ID).Value = candId

        wsA.Cells(r, A_TYPE).Value = addrType

        wsA.Cells(r, A_START).Value = startValue

        wsA.Cells(r, A_END).Value = endValue

        wsA.Cells(r, A_TEXT).Value = addressText

        wsA.Cells(r, A_KEY).Value = addressKey

        wsA.Cells(r, A_SOURCE).Value = CleanText(wsIn.Range(CELL_ADDR_SOURCE).Value)

        wsA.Cells(r, A_COPY_PERSON_ID).Value = CleanText(wsIn.Range(CELL_BASE_ID).Value)

        wsA.Cells(r, A_NOTE).Value = CleanText(wsIn.Range(CELL_ADDR_NOTE).Value)

        wsA.Cells(r, A_STATUS).Value = STATUS_ACTIVE

        wsA.Cells(r, A_CREATED).Value = Now

        wsA.Cells(r, A_UPDATED).Value = Now

        wsA.Cells(r, A_START_KIND).Value = startKind

    End If

    UpdateRepresentativeAddressId personId

End Sub


Private Function AddressStartKindFromInput(ByVal personId As String) As String

    Dim v As String
    v = CleanText(ThisWorkbook.Worksheets(SH_INPUT).Range(CELL_ADDR_START_KIND).Value)
    If v = "�c����" Or v = "���Z�J�n" Then
        AddressStartKindFromInput = v
    Else
        AddressStartKindFromInput = "���Z�J�n"
    End If

End Function

Public Sub MarkAddressStartConfirmed()

    On Error Resume Next
    ThisWorkbook.Worksheets(SH_INPUT).Range(CELL_ADDR_START_KIND).Value = "���Z�J�n"
    SetPersonInputStatus "�Z���J�n���̈������w���Z�J�n�x�ɂ��܂����B"
    On Error GoTo 0

End Sub

Public Sub MarkAddressStartObserved()

    On Error Resume Next
    ThisWorkbook.Worksheets(SH_INPUT).Range(CELL_ADDR_START_KIND).Value = "�c����"
    SetPersonInputStatus "�Z���J�n���̈������w�c�����x�ɂ��܂����B�ŏ��̏Z���ȂǁA���ۂ̈ړ]�����s���ȏꍇ�Ɏg���܂��B"
    On Error GoTo 0

End Sub

Private Function FindMatchingAddressHistoryRow(ByVal personId As String, _
        ByVal addressKey As String, _
        ByVal addrType As String, _
        ByVal startValue As Variant, _
        ByVal endValue As Variant) As Long

    Dim ws As Worksheet, r As Long, lastR As Long

    Set ws = ThisWorkbook.Worksheets(SH_W_ADDR_HIST)

    lastR = LastRow(ws, 1)

    For r = 2 To lastR

        If CStr(ws.Cells(r, A_PERSON_ID).Value) = personId Then
            If CStr(ws.Cells(r, A_STATUS).Value) <> STATUS_CANCEL Then
                If CStr(ws.Cells(r, A_KEY).Value) = addressKey Then
                    If CleanText(ws.Cells(r, A_TYPE).Value) = addrType Then
                        If SameDateValueOrBlank(ws.Cells(r, A_START).Value, startValue) Then
                            If SameDateValueOrBlank(ws.Cells(r, A_END).Value, endValue) Then

                                FindMatchingAddressHistoryRow = r

                                Exit Function

                            End If
                        End If
                    End If
                End If
            End If
        End If

    Next r

End Function

Private Function SameDateValueOrBlank(ByVal a As Variant, ByVal b As Variant) As Boolean

    If IsDate(a) Or IsDate(b) Then

        If IsDate(a) Then
            If IsDate(b) Then SameDateValueOrBlank = (CLng(CDate(a)) = CLng(CDate(b)))
        End If

    Else

        If Len(CleanText(a)) = 0 Then
            If Len(CleanText(b)) = 0 Then SameDateValueOrBlank = True
        End If

    End If

End Function

Private Function GetOrCreateAddressCandidate(ByVal addressText As String, ByVal addressKey As String, ByVal personId As String) As String

    Dim ws As Worksheet, r As Long, lastR As Long

    Set ws = ThisWorkbook.Worksheets(SH_W_ADDR_CAND)

    lastR = LastRow(ws, 1)

    For r = 2 To lastR

        If CStr(ws.Cells(r, AC_KEY).Value) = addressKey Then

            ws.Cells(r, AC_LAST_PERSON).Value = personId

            ws.Cells(r, AC_USE_COUNT).Value = Val(ws.Cells(r, AC_USE_COUNT).Value) + 1

            ws.Cells(r, AC_LAST_USED).Value = Now

            GetOrCreateAddressCandidate = CStr(ws.Cells(r, AC_ID).Value)

            Exit Function

        End If

    Next r

    r = NextBlankRow(ws, 1)

    GetOrCreateAddressCandidate = NextId("�Z�����")

    ws.Cells(r, AC_ID).Value = GetOrCreateAddressCandidate

    ws.Cells(r, AC_TEXT).Value = addressText

    ws.Cells(r, AC_KEY).Value = addressKey

    ws.Cells(r, AC_FIRST_PERSON).Value = personId

    ws.Cells(r, AC_LAST_PERSON).Value = personId

    ws.Cells(r, AC_USE_COUNT).Value = 1

    ws.Cells(r, AC_LAST_USED).Value = Now

End Function

Public Sub AddAddressAndStartNext()
    On Error GoTo EH
    AppBegin
    Dim ws As Worksheet, pid As String, addedEnd As Variant

    Set ws = ThisWorkbook.Worksheets(SH_INPUT)

    pid = CleanText(ws.Range(CELL_PERSON_ID).Value)

    If Len(CleanText(ws.Range(CELL_ADDR_TEXT).Value)) = 0 Then Err.Raise 5, , "�ǉ�����Z������͂��Ă��������B"

    If Len(CleanText(ws.Range(CELL_ADDR_EDIT_ID).Value)) > 0 Then
        UpdateAddressHistoryFromInputById CleanText(ws.Range(CELL_ADDR_EDIT_ID).Value), pid
        addedEnd = ws.Range(CELL_ADDR_END).Value
        RefreshAddressCandidateListOnly
        RefreshDateCandidateListOnly
        BeginNextAddressForCurrentPerson addedEnd
        SetPersonInputStatus "�Z��������������܂����B���̏Z���𑱂��ē��͂ł��܂��B"
        AppEnd
        Exit Sub
    End If

    addedEnd = ws.Range(CELL_ADDR_END).Value

    If Len(pid) = 0 Then
        StageAddressFromInput PendingAddressKeyForInput(True)
        RefreshDateCandidateListOnly
        BeginNextAddressForCurrentPerson addedEnd
        SetPersonInputStatus "�Z�������ǉ����܂����B�l����o�^����ƁA���̏Z���������܂Ƃ߂ēo�^����܂��B"
    Else
        RegisterAddressFromInput pid
        RefreshAddressCandidateListOnly
        RefreshDateCandidateListOnly
        BeginNextAddressForCurrentPerson addedEnd
        SetPersonInputStatus "�Z��������ǉ����܂����B���̏Z���𑱂��ē��͂ł��܂��B"
    End If
    AppEnd
    Exit Sub
EH:
    AppEnd
    RuntimeShowError "AddAddressAndStartNext", "�Z������ǉ�", "�l��ID�E�Z���E�J�n���E�I�����̓��͏�Ԃ��m�F���Ă��������B"

End Sub

Public Sub AddAddressForCurrentPerson()
    On Error GoTo EH
    AppBegin
    Dim ws As Worksheet, pid As String

    Set ws = ThisWorkbook.Worksheets(SH_INPUT)

    pid = CleanText(ws.Range(CELL_PERSON_ID).Value)

    If Len(CleanText(ws.Range(CELL_ADDR_TEXT).Value)) = 0 Then Err.Raise 5, , "�ǉ�����Z������͂��Ă��������B"

    If Len(pid) = 0 Then
        StageAddressFromInput PendingAddressKeyForInput(True)
        RefreshDateCandidateListOnly
        SetPersonInputStatus "�Z�������ǉ����܂����B�l����o�^����ƁA���̏Z���������܂Ƃ߂ēo�^����܂��B"
    Else
        RegisterAddressFromInput pid
        RefreshAddressCandidateListOnly
        RefreshDateCandidateListOnly
        SetPersonInputStatus "�Z��������ǉ����܂����B"
    End If

    ApplyInputUsability False
    AppEnd
    Exit Sub
EH:
    AppEnd
    RuntimeShowError "AddAddressForCurrentPerson", "�Z������ǉ�", "�l��ID�E�Z���E�J�n���E�I�����̓��͏�Ԃ��m�F���Ă��������B"

End Sub

Public Sub BeginNextAddressForCurrentPerson(Optional ByVal previousEndDate As Variant)

    On Error Resume Next

    Dim ws As Worksheet, nextStart As Variant

    Set ws = ThisWorkbook.Worksheets(SH_INPUT)

    If IsMissing(previousEndDate) Then previousEndDate = ws.Range(CELL_ADDR_END).Value

    If IsDate(previousEndDate) Then nextStart = DateAdd("d", 1, CDate(previousEndDate))

    ws.Range(CELL_ADDR_CAND & ":" & CELL_ADDR_NOTE).ClearContents
    ws.Range(CELL_ADDR_KEY).ClearContents
    ws.Range(CELL_ADDR_SOURCE).ClearContents
    ws.Range(CELL_ADDR_EDIT_ID).ClearContents

    ws.Range(CELL_ADDR_TYPE).Value = "���Z�n"

    ws.Range(CELL_ADDR_START_KIND).Value = "���Z�J�n"

    If IsDate(nextStart) Then ws.Range(CELL_ADDR_START).Value = nextStart

    ApplyInputUsability

    ws.Range(CELL_ADDR_TEXT).Select

    On Error GoTo 0

End Sub

Public Sub LoadBasePersonForEdit()
    On Error GoTo EH
    AppBegin
    Dim ws As Worksheet, sel As String, pid As String
    Set ws = ThisWorkbook.Worksheets(SH_INPUT)
    sel = CleanText(ws.Range(CELL_BASE_SELECT).Value)
    pid = ParseIdFromCandidate(sel)
    If Len(pid) = 0 Then pid = CleanText(ws.Range(CELL_BASE_ID).Value)
    If Len(pid) = 0 Or FindPersonRow(pid) = 0 Then Err.Raise 5, , "��������l������l����₩��I��ł��������B"
    LoadPersonIntoInputForEdit pid
    SetPersonInputStatus "�l����������p�ɓǂݍ��݂܂����B�����Ă���w�o�^�E�X�V�x�������Ă��������B"
    AppEnd
    Exit Sub
EH:
    AppEnd
    RuntimeShowError "LoadBasePersonForEdit", "�l�������Ǎ�", "��l�����E�l���ꗗ�E���̓V�[�g�̏�Ԃ��m�F���Ă��������B"
End Sub

Public Sub DeleteCurrentInputPerson()
    On Error GoTo EH
    Dim ws As Worksheet, pid As String, personName As String
    Set ws = ThisWorkbook.Worksheets(SH_INPUT)
    pid = CleanText(ws.Range(CELL_PERSON_ID).Value)
    If Len(pid) = 0 Then pid = CleanText(ws.Range(CELL_BASE_ID).Value)
    If Len(pid) = 0 Or FindPersonRow(pid) = 0 Then Err.Raise 5, , "�폜����l����l�������Ǎ��œǂݍ��ނ��A��l����₩��I��ł��������B"
    personName = GetPersonValue(pid, P_DISPLAY)
    If MsgBox("�l���w" & personName & "�x���폜���܂��B" & vbCrLf & _
              "�֘A����Z�������E�֌W�E������������������ɂ��܂��B���ɖ߂��ꍇ�͍�ƃV�[�g�Ŏ����߂��K�v������܂��B", _
              vbExclamation + vbYesNo, "�l���폜�m�F") <> vbYes Then Exit Sub
    AppBegin
    CancelCurrentPersonRelatedRows pid
    ClearPersonInput
    RefreshCandidates
    SetPersonInputStatus "�l�����폜���܂����B"
    AppEnd
    Exit Sub
EH:
    AppEnd
    RuntimeShowError "DeleteCurrentInputPerson", "�l���폜", "�l��ID�A�֌W�\�A�Z�������A���������̏�Ԃ��m�F���Ă��������B"
End Sub

Private Sub CancelCurrentPersonRelatedRows(ByVal personId As String)
    Dim wsP As Worksheet, wsA As Worksheet, wsR As Worksheet, wsM As Worksheet, r As Long
    If Len(personId) = 0 Then Exit Sub
    Set wsP = ThisWorkbook.Worksheets(SH_W_PERSON)
    r = FindPersonRow(personId)
    If r > 0 Then
        wsP.Cells(r, P_STATUS).Value = STATUS_CANCEL
        wsP.Cells(r, P_UPDATED).Value = Now
        wsP.Cells(r, P_SHOW).Value = SHOW_NO
    End If
    If SheetExists(SH_W_ADDR_HIST, ThisWorkbook) Then
        Set wsA = ThisWorkbook.Worksheets(SH_W_ADDR_HIST)
        For r = 2 To LastRow(wsA, A_ID)
            If CleanText(wsA.Cells(r, A_PERSON_ID).Value) = personId Then
                wsA.Cells(r, A_STATUS).Value = STATUS_CANCEL
                wsA.Cells(r, A_UPDATED).Value = Now
            End If
        Next r
    End If
    If SheetExists(SH_W_REL, ThisWorkbook) Then
        Set wsR = ThisWorkbook.Worksheets(SH_W_REL)
        For r = 2 To LastRow(wsR, R_ID)
            If CleanText(wsR.Cells(r, R_BASE_ID).Value) = personId Or CleanText(wsR.Cells(r, R_OTHER_ID).Value) = personId Then
                wsR.Cells(r, R_STATUS).Value = STATUS_CANCEL
                wsR.Cells(r, R_UPDATED).Value = Now
            End If
        Next r
    End If
    If SheetExists(SH_W_MARRIAGE_HIST, ThisWorkbook) Then
        Set wsM = ThisWorkbook.Worksheets(SH_W_MARRIAGE_HIST)
        For r = 2 To LastRow(wsM, MH_ID)
            If CleanText(wsM.Cells(r, MH_PERSON_ID).Value) = personId Or CleanText(wsM.Cells(r, MH_COUNTERPART_ID).Value) = personId Then
                wsM.Cells(r, MH_STATUS).Value = STATUS_CANCEL
                wsM.Cells(r, MH_SHOW).Value = SHOW_NO
                wsM.Cells(r, MH_UPDATED).Value = Now
            End If
        Next r
    End If
End Sub

Private Sub LoadPersonIntoInputForEdit(ByVal personId As String)
    Dim wsIn As Worksheet, wsP As Worksheet, r As Long, baseId As String, bestAddrRow As Long
    If Len(personId) = 0 Then Exit Sub
    r = FindPersonRow(personId)
    If r = 0 Then Exit Sub
    Set wsIn = ThisWorkbook.Worksheets(SH_INPUT)
    Set wsP = ThisWorkbook.Worksheets(SH_W_PERSON)
    wsIn.Unprotect Password:=TOOL_PASSWORD
    wsIn.Range(CELL_PERSON_ID).Value = personId
    wsIn.Range(CELL_PENDING_ADDR_KEY).ClearContents
    wsIn.Range(CELL_ADDR_EDIT_ID).ClearContents
    wsIn.Range(CELL_MODE).Value = PersonEditModeFromRow(r)
    baseId = CleanText(wsP.Cells(r, P_SUR_SRC).Value)
    If Len(baseId) = 0 And CleanText(wsP.Cells(r, P_TYPE).Value) <> MODE_DECEDENT Then baseId = GetDecedentId()
    If Len(baseId) > 0 And FindPersonRow(baseId) > 0 And baseId <> personId Then SetBasePerson baseId
    If Len(baseId) > 0 And FindPersonRow(baseId) > 0 Then
        wsIn.Range(CELL_AUTO_SURNAME).Value = GetPersonValue(baseId, P_SURNAME)
    Else
        wsIn.Range(CELL_AUTO_SURNAME).ClearContents
    End If
    wsIn.Range(CELL_SURNAME).Value = wsP.Cells(r, P_SURNAME).Value
    wsIn.Range(CELL_GIVEN_NAME).Value = wsP.Cells(r, P_GIVEN).Value
    wsIn.Range(CELL_FORMER_SURNAME).Value = wsP.Cells(r, P_FORMER).Value
    wsIn.Range(CELL_GENDER).Value = wsP.Cells(r, P_GENDER).Value
    wsIn.Range(CELL_REL_TO_DECEDENT).Value = wsP.Cells(r, P_REL_DEC).Value
    wsIn.Range(CELL_BIRTH).Value = wsP.Cells(r, P_BIRTH).Value
    wsIn.Range(CELL_DEATH).Value = wsP.Cells(r, P_DEATH).Value
    wsIn.Range(CELL_OCCUPATION).Value = wsP.Cells(r, P_OCC).Value
    wsIn.Range(CELL_MARRIAGE).Value = wsP.Cells(r, P_MARRIAGE).Value
    wsIn.Range(CELL_DIVORCE).Value = wsP.Cells(r, P_DIVORCE).Value
    wsIn.Range(CELL_NOTE).Value = wsP.Cells(r, P_NOTE).Value
    wsIn.Range(CELL_SHOW_DIAGRAM).Value = wsP.Cells(r, P_SHOW).Value
    If Len(CleanText(wsIn.Range(CELL_SHOW_DIAGRAM).Value)) = 0 Then wsIn.Range(CELL_SHOW_DIAGRAM).Value = SHOW_YES
    wsIn.Range(CELL_DEATH_PLACE).Value = wsP.Cells(r, P_DEATH_PLACE).Value
    bestAddrRow = BestAddressHistoryRowForPerson(personId)
    If bestAddrRow > 0 Then
        LoadAddressFieldsFromHistoryRow bestAddrRow
    Else
        wsIn.Range(CELL_ADDR_CAND & ":" & CELL_ADDR_NOTE).ClearContents
        wsIn.Range(CELL_ADDR_KEY).ClearContents
        wsIn.Range(CELL_ADDR_SOURCE).ClearContents
        wsIn.Range(CELL_ADDR_TYPE).Value = "���Z�n"
        wsIn.Range(CELL_ADDR_START_KIND).Value = "���Z�J�n"
        wsIn.Range(CELL_ADDR_EDIT_ID).ClearContents
    End If
    EnsurePersonInputValidationOnly wsIn
    EnsurePersonInputDateDisplay wsIn
    ApplyInputUsability False
    If Not ActiveSheet Is Nothing Then
        If ActiveSheet.Name = wsIn.Name Then wsIn.Range(CELL_GIVEN_NAME).Select
    End If
End Sub

Private Function PersonEditModeFromRow(ByVal personRow As Long) As String
    Dim relText As String, pType As String
    If personRow <= 0 Then PersonEditModeFromRow = MODE_OTHER: Exit Function
    With ThisWorkbook.Worksheets(SH_W_PERSON)
        pType = CleanText(.Cells(personRow, P_TYPE).Value)
        relText = NormalizedRelationLabel(CleanText(.Cells(personRow, P_REL_DEC).Value))
    End With
    If pType = MODE_DECEDENT Or relText = MODE_DECEDENT Then
        PersonEditModeFromRow = MODE_DECEDENT
    ElseIf relText = "�z���" Or relText = "�O�z���" Then
        PersonEditModeFromRow = MODE_SPOUSE
    ElseIf relText = "��" Then
        PersonEditModeFromRow = MODE_FATHER
    ElseIf relText = "��" Then
        PersonEditModeFromRow = MODE_MOTHER
    ElseIf BaseIsDirectChildRelation(relText) Then
        PersonEditModeFromRow = MODE_CHILD
    ElseIf relText = "��" Or relText = "�]��" Or relText = "�Б�" Or relText = "�\��" Or relText = "����" Or Left$(relText, 2) = "���i" Or Left$(relText, 3) = "�Б�" Or Left$(relText, 2) = "����" Then
        PersonEditModeFromRow = MODE_GRANDCHILD
    ElseIf InStr(1, relText, "�Z", vbTextCompare) > 0 Or InStr(1, relText, "��", vbTextCompare) > 0 _
            Or InStr(1, relText, "�o", vbTextCompare) > 0 Or InStr(1, relText, "��", vbTextCompare) > 0 Then
        PersonEditModeFromRow = MODE_SIBLING
    Else
        PersonEditModeFromRow = MODE_OTHER
    End If
End Function

Public Sub LoadSelectedAddressHistoryForEdit()
    On Error GoTo EH
    AppBegin
    Dim ws As Worksheet, activeObj As Object
    Dim rowNo As Long, addrId As String, histRow As Long, personId As String
    Set activeObj = ActiveSheet
    If Not TypeOf activeObj Is Worksheet Then Err.Raise 5, , "�Z�����𑁌��\�Œ�������s��I�����Ă��������B"
    Set ws = activeObj
    If ws.Name <> SH_ADDR_TABLE Then Err.Raise 5, , "�Z�����𑁌��\�Œ�������s��I�����Ă��������B"
    rowNo = ActiveCell.Row
    If rowNo < 9 Then Err.Raise 5, , "��������Z�������̖��׍s��I�����Ă��������B"
    addrId = CleanText(ws.Cells(rowNo, 10).Value)
    histRow = FindAddressHistoryRowById(addrId)
    If histRow = 0 Then Err.Raise 5, , "�Z������ID���m�F�ł��܂���B�Z�����𑁌��\����蒼���Ă��������B"
    personId = CleanText(ThisWorkbook.Worksheets(SH_W_ADDR_HIST).Cells(histRow, A_PERSON_ID).Value)
    ShowOnlyInputCore True
    LoadPersonIntoInputForEdit personId
    LoadAddressFieldsFromHistoryRow histRow
    SetPersonInputStatus "�Z������������p�ɓǂݍ��݂܂����B�����Ă���w�Z�������x�������Ă��������B"
    AppEnd
    Exit Sub
EH:
    AppEnd
    RuntimeShowError "LoadSelectedAddressHistoryForEdit", "�Z����������Ǎ�", "�Z�����𑁌��\�Ŗ��׍s��I��ł��������B"
End Sub

Public Sub DeleteSelectedAddressFromTable()
    On Error GoTo EH
    Dim ws As Worksheet, activeObj As Object
    Dim rowNo As Long, addrId As String, histRow As Long, labelText As String
    Set activeObj = ActiveSheet
    If Not TypeOf activeObj Is Worksheet Then Err.Raise 5, , "�Z�����𑁌��\�ō폜����s��I�����Ă��������B"
    Set ws = activeObj
    If ws.Name <> SH_ADDR_TABLE Then Err.Raise 5, , "�Z�����𑁌��\�ō폜����s��I�����Ă��������B"
    rowNo = ActiveCell.Row
    If rowNo < 9 Then Err.Raise 5, , "�폜����Z�������̖��׍s��I�����Ă��������B"
    addrId = CleanText(ws.Cells(rowNo, 10).Value)
    histRow = FindAddressHistoryRowById(addrId)
    If histRow = 0 Then Err.Raise 5, , "�Z������ID���m�F�ł��܂���B�Z�����𑁌��\����蒼���Ă��������B"
    labelText = CleanText(ws.Cells(rowNo, 2).Value) & " / " & CleanText(ws.Cells(rowNo, 8).Value)
    If MsgBox("�I�������Z���������폜���܂��B" & vbCrLf & labelText, vbExclamation + vbYesNo, "�Z���폜�m�F") <> vbYes Then Exit Sub
    AppBegin
    CancelAddressHistoryRow histRow
    BuildAddressHistoryTable
    ApplyOutputUsability
    ThisWorkbook.Worksheets(SH_ADDR_TABLE).Activate
    AppEnd
    Exit Sub
EH:
    AppEnd
    RuntimeShowError "DeleteSelectedAddressFromTable", "�Z�������폜", "�Z�����𑁌��\�Ŗ��׍s��I��ł��������B"
End Sub

Public Sub UpdateSelectedAddressFromInput()
    On Error GoTo EH
    AppBegin
    Dim ws As Worksheet, pid As String, addrId As String, histRow As Long
    Set ws = ThisWorkbook.Worksheets(SH_INPUT)
    pid = CleanText(ws.Range(CELL_PERSON_ID).Value)
    If Len(pid) = 0 Then Err.Raise 5, , "��ɐl����o�^���邩�A�l�������Ǎ��Ől����ǂݍ���ł��������B"
    If Len(CleanText(ws.Range(CELL_ADDR_TEXT).Value)) = 0 Then Err.Raise 5, , "������̏Z������͂��Ă��������B"
    addrId = CleanText(ws.Range(CELL_ADDR_EDIT_ID).Value)
    histRow = FindAddressHistoryRowById(addrId)
    If histRow = 0 Then histRow = FindAddressHistoryRowFromInput(pid)
    If histRow = 0 Then Err.Raise 5, , "�����Ώۂ̏Z��������������܂���B�Z���ꗗ����Ώۍs��ǂݍ���ł��������B"
    UpdateAddressHistoryFromInputByRow histRow, pid
    RefreshAddressCandidateListOnly
    RefreshDateCandidateListOnly
    UpdateRepresentativeAddressId pid
    SetPersonInputStatus "�Z��������������܂����B"
    AppEnd
    Exit Sub
EH:
    AppEnd
    RuntimeShowError "UpdateSelectedAddressFromInput", "�Z���������", "�����Ώۂ̏Z�������A�l��ID�A���t�A�Z�����͂��m�F���Ă��������B"
End Sub

Public Sub DeleteSelectedAddressFromInput()
    On Error GoTo EH
    Dim ws As Worksheet, pid As String, addrId As String, histRow As Long, pendingRow As Long, labelText As String
    Set ws = ThisWorkbook.Worksheets(SH_INPUT)
    pid = CleanText(ws.Range(CELL_PERSON_ID).Value)
    addrId = CleanText(ws.Range(CELL_ADDR_EDIT_ID).Value)
    histRow = FindAddressHistoryRowById(addrId)
    If histRow = 0 And Len(pid) > 0 Then histRow = FindAddressHistoryRowFromInput(pid)
    If histRow > 0 Then
        labelText = CleanText(ThisWorkbook.Worksheets(SH_W_ADDR_HIST).Cells(histRow, A_TEXT).Value)
        If MsgBox("���̏Z���������폜���܂��B" & vbCrLf & labelText, vbExclamation + vbYesNo, "�Z���폜�m�F") <> vbYes Then Exit Sub
        AppBegin
        CancelAddressHistoryRow histRow
        BeginNextAddressForCurrentPerson
        RefreshAddressCandidateListOnly
        RefreshDateCandidateListOnly
        If Len(pid) > 0 Then UpdateRepresentativeAddressId pid
        SetPersonInputStatus "�Z���������폜���܂����B"
        AppEnd
        Exit Sub
    End If

    pendingRow = FindLastPendingAddressRow(CleanText(ws.Range(CELL_PENDING_ADDR_KEY).Value))
    If pendingRow = 0 Then Err.Raise 5, , "�폜�Ώۂ̏Z��������������܂���B�Z���ꗗ����Ώۍs��ǂݍ���ł��������B"
    labelText = CleanText(ThisWorkbook.Worksheets(SH_W_ADDR_PENDING).Cells(pendingRow, AP_ADDR_TEXT).Value)
    If MsgBox("���ǉ������Z�����폜���܂��B" & vbCrLf & labelText, vbExclamation + vbYesNo, "�Z���폜�m�F") <> vbYes Then Exit Sub
    AppBegin
    ThisWorkbook.Worksheets(SH_W_ADDR_PENDING).Cells(pendingRow, AP_STATUS).Value = STATUS_CANCEL
    BeginNextAddressForCurrentPerson
    SetPersonInputStatus "���ǉ��Z�����폜���܂����B"
    AppEnd
    Exit Sub
EH:
    AppEnd
    RuntimeShowError "DeleteSelectedAddressFromInput", "�Z�������폜", "�폜�Ώۂ̏Z�������A�l��ID�A�Z�����͂��m�F���Ă��������B"
End Sub

Private Sub UpdateAddressHistoryFromInputById(ByVal addressHistoryId As String, ByVal personId As String)
    Dim histRow As Long
    histRow = FindAddressHistoryRowById(addressHistoryId)
    If histRow = 0 Then Err.Raise 5, , "�����Ώۂ̏Z��������������܂���B"
    If Len(personId) = 0 Then personId = CleanText(ThisWorkbook.Worksheets(SH_W_ADDR_HIST).Cells(histRow, A_PERSON_ID).Value)
    UpdateAddressHistoryFromInputByRow histRow, personId
End Sub

Private Sub UpdateAddressHistoryFromInputByRow(ByVal histRow As Long, ByVal personId As String)
    Dim wsIn As Worksheet, wsA As Worksheet, addressText As String, addressKey As String, addrType As String, candId As String
    If histRow <= 0 Then Exit Sub
    Set wsIn = ThisWorkbook.Worksheets(SH_INPUT)
    Set wsA = ThisWorkbook.Worksheets(SH_W_ADDR_HIST)
    addressText = CleanText(wsIn.Range(CELL_ADDR_TEXT).Value)
    If Len(addressText) = 0 Then Err.Raise 5, , "�Z������͂��Ă��������B"
    addressKey = CleanText(wsIn.Range(CELL_ADDR_KEY).Value)
    If Len(addressKey) = 0 Then addressKey = NormalizeAddress(addressText)
    addrType = CleanText(wsIn.Range(CELL_ADDR_TYPE).Value)
    If Len(addrType) = 0 Then addrType = "���Z�n"
    If Len(personId) = 0 Then personId = CleanText(wsA.Cells(histRow, A_PERSON_ID).Value)
    candId = GetOrCreateAddressCandidate(addressText, addressKey, personId)
    wsA.Cells(histRow, A_PERSON_ID).Value = personId
    wsA.Cells(histRow, A_CAND_ID).Value = candId
    wsA.Cells(histRow, A_TYPE).Value = addrType
    wsA.Cells(histRow, A_START).Value = SameDateOrBlank(wsIn.Range(CELL_ADDR_START).Value)
    wsA.Cells(histRow, A_END).Value = SameDateOrBlank(wsIn.Range(CELL_ADDR_END).Value)
    wsA.Cells(histRow, A_TEXT).Value = addressText
    wsA.Cells(histRow, A_KEY).Value = addressKey
    wsA.Cells(histRow, A_SOURCE).Value = CleanText(wsIn.Range(CELL_ADDR_SOURCE).Value)
    wsA.Cells(histRow, A_COPY_PERSON_ID).Value = CleanText(wsIn.Range(CELL_BASE_ID).Value)
    wsA.Cells(histRow, A_NOTE).Value = CleanText(wsIn.Range(CELL_ADDR_NOTE).Value)
    wsA.Cells(histRow, A_STATUS).Value = STATUS_ACTIVE
    wsA.Cells(histRow, A_UPDATED).Value = Now
    wsA.Cells(histRow, A_START_KIND).Value = AddressStartKindFromInput(personId)
    wsIn.Range(CELL_ADDR_KEY).Value = addressKey
    wsIn.Range(CELL_ADDR_EDIT_ID).Value = wsA.Cells(histRow, A_ID).Value
End Sub

Private Function FindAddressHistoryRowById(ByVal addressHistoryId As String) As Long
    Dim wsA As Worksheet, r As Long
    addressHistoryId = CleanText(addressHistoryId)
    If Len(addressHistoryId) = 0 Then Exit Function
    If Not SheetExists(SH_W_ADDR_HIST, ThisWorkbook) Then Exit Function
    Set wsA = ThisWorkbook.Worksheets(SH_W_ADDR_HIST)
    For r = 2 To LastRow(wsA, A_ID)
        If CleanText(wsA.Cells(r, A_ID).Value) = addressHistoryId And CleanText(wsA.Cells(r, A_STATUS).Value) <> STATUS_CANCEL Then
            FindAddressHistoryRowById = r
            Exit Function
        End If
    Next r
End Function

Private Function FindAddressHistoryRowFromInput(ByVal personId As String) As Long
    Dim wsIn As Worksheet, addressKey As String, addrType As String
    Set wsIn = ThisWorkbook.Worksheets(SH_INPUT)
    addressKey = CleanText(wsIn.Range(CELL_ADDR_KEY).Value)
    If Len(addressKey) = 0 Then addressKey = NormalizeAddress(wsIn.Range(CELL_ADDR_TEXT).Value)
    addrType = CleanText(wsIn.Range(CELL_ADDR_TYPE).Value)
    If Len(addrType) = 0 Then addrType = "���Z�n"
    FindAddressHistoryRowFromInput = FindMatchingAddressHistoryRow(personId, addressKey, addrType, _
        SameDateOrBlank(wsIn.Range(CELL_ADDR_START).Value), SameDateOrBlank(wsIn.Range(CELL_ADDR_END).Value))
End Function

Private Sub LoadAddressFieldsFromHistoryRow(ByVal histRow As Long)
    Dim wsIn As Worksheet, wsA As Worksheet
    If histRow <= 0 Then Exit Sub
    Set wsIn = ThisWorkbook.Worksheets(SH_INPUT)
    Set wsA = ThisWorkbook.Worksheets(SH_W_ADDR_HIST)
    wsIn.Range(CELL_ADDR_CAND).ClearContents
    wsIn.Range(CELL_ADDR_TEXT).Value = wsA.Cells(histRow, A_TEXT).Value
    wsIn.Range(CELL_ADDR_KEY).Value = wsA.Cells(histRow, A_KEY).Value
    wsIn.Range(CELL_ADDR_TYPE).Value = wsA.Cells(histRow, A_TYPE).Value
    wsIn.Range(CELL_ADDR_START).Value = wsA.Cells(histRow, A_START).Value
    wsIn.Range(CELL_ADDR_END).Value = wsA.Cells(histRow, A_END).Value
    wsIn.Range(CELL_ADDR_SOURCE).Value = wsA.Cells(histRow, A_SOURCE).Value
    wsIn.Range(CELL_ADDR_NOTE).Value = wsA.Cells(histRow, A_NOTE).Value
    If Len(CleanText(wsA.Cells(histRow, A_START_KIND).Value)) = 0 Then
        wsIn.Range(CELL_ADDR_START_KIND).Value = "���Z�J�n"
    Else
        wsIn.Range(CELL_ADDR_START_KIND).Value = CleanText(wsA.Cells(histRow, A_START_KIND).Value)
    End If
    wsIn.Range(CELL_ADDR_EDIT_ID).Value = wsA.Cells(histRow, A_ID).Value
    EnsurePersonInputDateDisplay wsIn
End Sub

Private Sub CancelAddressHistoryRow(ByVal histRow As Long)
    Dim wsA As Worksheet, personId As String
    If histRow <= 0 Then Exit Sub
    Set wsA = ThisWorkbook.Worksheets(SH_W_ADDR_HIST)
    personId = CleanText(wsA.Cells(histRow, A_PERSON_ID).Value)
    wsA.Cells(histRow, A_STATUS).Value = STATUS_CANCEL
    wsA.Cells(histRow, A_UPDATED).Value = Now
    If Len(personId) > 0 Then UpdateRepresentativeAddressId personId
End Sub

Private Function FindLastPendingAddressRow(ByVal pendingKey As String) As Long
    Dim wsP As Worksheet, r As Long
    pendingKey = CleanText(pendingKey)
    If Len(pendingKey) = 0 Then Exit Function
    If Not SheetExists(SH_W_ADDR_PENDING, ThisWorkbook) Then Exit Function
    Set wsP = ThisWorkbook.Worksheets(SH_W_ADDR_PENDING)
    For r = LastRow(wsP, AP_KEY) To 2 Step -1
        If CleanText(wsP.Cells(r, AP_KEY).Value) = pendingKey And CleanText(wsP.Cells(r, AP_STATUS).Value) = STATUS_ACTIVE Then
            FindLastPendingAddressRow = r
            Exit Function
        End If
    Next r
End Function

Private Function PendingAddressKeyForInput(Optional ByVal createIfMissing As Boolean = True) As String

    Dim ws As Worksheet, k As String
    Set ws = ThisWorkbook.Worksheets(SH_INPUT)
    k = CleanText(ws.Range(CELL_PENDING_ADDR_KEY).Value)
    If Len(k) = 0 And createIfMissing Then
        k = "TMP" & Format(Now, "yyyymmddhhmmss") & Format(Int(Rnd() * 10000), "0000")
        ws.Range(CELL_PENDING_ADDR_KEY).Value = k
    End If
    PendingAddressKeyForInput = k

End Function

Private Sub StageAddressFromInput(ByVal pendingKey As String)

    Dim wsIn As Worksheet, wsP As Worksheet, r As Long, addressText As String, addressKey As String
    If Len(pendingKey) = 0 Then Exit Sub
    Set wsIn = ThisWorkbook.Worksheets(SH_INPUT)
    Set wsP = ThisWorkbook.Worksheets(SH_W_ADDR_PENDING)
    addressText = CleanText(wsIn.Range(CELL_ADDR_TEXT).Value)
    If Len(addressText) = 0 Then Exit Sub
    addressKey = CleanText(wsIn.Range(CELL_ADDR_KEY).Value)
    If Len(addressKey) = 0 Then addressKey = NormalizeAddress(addressText)
    wsIn.Range(CELL_ADDR_KEY).Value = addressKey
    r = NextBlankRow(wsP, 1)
    wsP.Cells(r, AP_KEY).Value = pendingKey
    wsP.Cells(r, AP_SEQ).Value = PendingAddressCount(pendingKey) + 1
    wsP.Cells(r, AP_ADDR_TEXT).Value = addressText
    wsP.Cells(r, AP_ADDR_KEY).Value = addressKey
    If Len(CleanText(wsIn.Range(CELL_ADDR_TYPE).Value)) = 0 Then
        wsP.Cells(r, AP_ADDR_TYPE).Value = "���Z�n"
    Else
        wsP.Cells(r, AP_ADDR_TYPE).Value = CleanText(wsIn.Range(CELL_ADDR_TYPE).Value)
    End If
    wsP.Cells(r, AP_START).Value = SameDateOrBlank(wsIn.Range(CELL_ADDR_START).Value)
    wsP.Cells(r, AP_END).Value = SameDateOrBlank(wsIn.Range(CELL_ADDR_END).Value)
    wsP.Cells(r, AP_SOURCE).Value = CleanText(wsIn.Range(CELL_ADDR_SOURCE).Value)
    wsP.Cells(r, AP_NOTE).Value = CleanText(wsIn.Range(CELL_ADDR_NOTE).Value)
    wsP.Cells(r, AP_COPY_PERSON_ID).Value = CleanText(wsIn.Range(CELL_BASE_ID).Value)
    wsP.Cells(r, AP_CREATED).Value = Now
    wsP.Cells(r, AP_START_KIND).Value = AddressStartKindFromInput("")
    wsP.Cells(r, AP_STATUS).Value = STATUS_ACTIVE

End Sub

Private Function PendingAddressCount(ByVal pendingKey As String) As Long

    Dim ws As Worksheet, r As Long
    If Len(pendingKey) = 0 Then Exit Function
    Set ws = ThisWorkbook.Worksheets(SH_W_ADDR_PENDING)
    For r = 2 To LastRow(ws, 1)
        If CStr(ws.Cells(r, AP_KEY).Value) = pendingKey And CStr(ws.Cells(r, AP_STATUS).Value) = STATUS_ACTIVE Then PendingAddressCount = PendingAddressCount + 1
    Next r

End Function

Private Sub FlushPendingAddressesToPerson(ByVal pendingKey As String, ByVal personId As String)

    Dim wsIn As Worksheet, wsP As Worksheet, r As Long
    If Len(pendingKey) = 0 Or Len(personId) = 0 Then Exit Sub
    Set wsIn = ThisWorkbook.Worksheets(SH_INPUT)
    Set wsP = ThisWorkbook.Worksheets(SH_W_ADDR_PENDING)
    For r = 2 To LastRow(wsP, 1)
        If CStr(wsP.Cells(r, AP_KEY).Value) = pendingKey And CStr(wsP.Cells(r, AP_STATUS).Value) = STATUS_ACTIVE Then
            wsIn.Range(CELL_ADDR_TEXT).Value = wsP.Cells(r, AP_ADDR_TEXT).Value
            wsIn.Range(CELL_ADDR_KEY).Value = wsP.Cells(r, AP_ADDR_KEY).Value
            wsIn.Range(CELL_ADDR_TYPE).Value = wsP.Cells(r, AP_ADDR_TYPE).Value
            wsIn.Range(CELL_ADDR_START).Value = wsP.Cells(r, AP_START).Value
            wsIn.Range(CELL_ADDR_END).Value = wsP.Cells(r, AP_END).Value
            wsIn.Range(CELL_ADDR_SOURCE).Value = wsP.Cells(r, AP_SOURCE).Value
            wsIn.Range(CELL_ADDR_NOTE).Value = wsP.Cells(r, AP_NOTE).Value
            If Len(CleanText(wsP.Cells(r, AP_START_KIND).Value)) = 0 Then
                wsIn.Range(CELL_ADDR_START_KIND).Value = "���Z�J�n"
            Else
                wsIn.Range(CELL_ADDR_START_KIND).Value = CleanText(wsP.Cells(r, AP_START_KIND).Value)
            End If
            RegisterAddressFromInput personId
            wsP.Cells(r, AP_STATUS).Value = "�o�^��"
        End If
    Next r
    RefreshAddressCandidateListOnly

End Sub

Private Sub ClearPendingAddresses(ByVal pendingKey As String)

    Dim ws As Worksheet, r As Long
    If Len(pendingKey) = 0 Then Exit Sub
    If Not SheetExists(SH_W_ADDR_PENDING, ThisWorkbook) Then Exit Sub
    Set ws = ThisWorkbook.Worksheets(SH_W_ADDR_PENDING)
    For r = 2 To LastRow(ws, 1)
        If CStr(ws.Cells(r, AP_KEY).Value) = pendingKey Then ws.Cells(r, AP_STATUS).Value = STATUS_CANCEL
    Next r

End Sub

Private Sub SavePersonMarriageFactFields(ByVal wsP As Worksheet, _
        ByVal personRow As Long, _
        ByVal marriageDate As Variant, _
        ByVal divorceDate As Variant)

    If wsP Is Nothing Then Exit Sub
    If personRow <= 0 Then Exit Sub
    If IsDate(marriageDate) Then
        wsP.Cells(personRow, P_MARRIAGE).Value = CDate(marriageDate)
    Else
        wsP.Cells(personRow, P_MARRIAGE).ClearContents
    End If
    If IsDate(divorceDate) Then
        wsP.Cells(personRow, P_DIVORCE).Value = CDate(divorceDate)
    Else
        wsP.Cells(personRow, P_DIVORCE).ClearContents
    End If

End Sub

Private Sub UpdatePersonMarriageFactFields(ByVal personId As String, _
        ByVal marriageDate As Variant, _
        ByVal divorceDate As Variant)

    Dim wsP As Worksheet, r As Long
    If Len(personId) = 0 Then Exit Sub
    Set wsP = ThisWorkbook.Worksheets(SH_W_PERSON)
    r = FindPersonRow(personId)
    If r = 0 Then Exit Sub
    If IsDate(marriageDate) Then wsP.Cells(r, P_MARRIAGE).Value = CDate(marriageDate)
    If IsDate(divorceDate) Then wsP.Cells(r, P_DIVORCE).Value = CDate(divorceDate)

End Sub

Public Sub RegisterMarriageFactForBasePerson()

    On Error GoTo EH
    AppBegin
    Dim ws As Worksheet, pid As String, mDate As Variant, dDate As Variant, counterpart As String
    Set ws = ThisWorkbook.Worksheets(SH_INPUT)
    pid = CleanText(ws.Range(CELL_BASE_ID).Value)
    If Len(pid) = 0 Then pid = CleanText(ws.Range(CELL_PERSON_ID).Value)
    If Len(pid) = 0 Then Err.Raise 5, , "����������R�Â���l�����A��l���Ƃ��đI��ł��������B"
    mDate = ws.Range(CELL_MARRIAGE).Value
    dDate = ws.Range(CELL_DIVORCE).Value
    If Not IsDate(mDate) And Not IsDate(dDate) Then Err.Raise 5, , "�������܂��͗���������͂��Ă��������B"
    counterpart = CleanText(Trim(CleanText(ws.Range(CELL_SURNAME).Value) & " " & CleanText(ws.Range(CELL_GIVEN_NAME).Value)))
    If Len(counterpart) = 0 Then counterpart = CleanText(ws.Range(CELL_NOTE).Value)
    UpsertMarriageHistory pid, "", counterpart, mDate, dDate, "�����������", "", ""
    UpdatePersonMarriageFactFields pid, mDate, dDate
    RefreshMarriageDateCandidatesOnly mDate, dDate
    RefreshCandidatesAfterPersonRegister pid
    SetPersonInputStatus "�����E�����̎��������������Ƃ��ēo�^���܂����B"
    AppEnd
    Exit Sub
EH:
    AppEnd
    RuntimeShowError "RegisterMarriageFactForBasePerson", "���������o�^", "��l���A�������E�������A���薼�������m�F���Ă��������B"

End Sub


Public Sub SyncMarriageHistoryFromLegacyTables()
    '���`���̐l���P�ƍ�����/��������W_�֌W�̔z��ғ��t���A�Ɨ�����W_���������֔�j��Ŏ�荞�ށB
    '�ڍs�����̎��̂� modMarriageHistory ���ɏW�񂵁A�o�͏����Ŋ֌W�\�����������Ȃ��B
    On Error GoTo EH
    EnsureMarriageHistoryWorkSheet
    BackfillMarriageHistoryFromLegacyFacts
    Exit Sub
EH:
    On Error Resume Next
    RuntimeAppendLog "WARN", "SyncMarriageHistoryFromLegacyTables", "���������ڍs", "", Err.Number, Err.Description, Err.Source
    On Error GoTo 0
End Sub

Private Sub RegisterMarriageFactsForPerson(ByVal personId As String, _
        ByVal marriageDate As Variant, _
        ByVal divorceDate As Variant, _
        Optional ByVal counterpart As String = "")

    counterpart = CleanText(counterpart)
    If Len(personId) = 0 Then Exit Sub
    If IsDate(marriageDate) Then
        UpsertManualTimelineEvent personId, marriageDate, "����", "����", "��������", "����|" & Format(CDate(marriageDate), "yyyymmdd")
    End If
    If IsDate(divorceDate) Then
        If Len(counterpart) > 0 Then
            UpsertManualTimelineEvent personId, divorceDate, "����", "�����F" & counterpart, "��������", "����|" & Format(CDate(divorceDate), "yyyymmdd") & "|" & counterpart
        Else
            UpsertManualTimelineEvent personId, divorceDate, "����", "����", "��������", "����|" & Format(CDate(divorceDate), "yyyymmdd")
        End If
    End If

End Sub

Private Sub UpsertManualTimelineEvent(ByVal personId As String, _
        ByVal eventDate As Variant, _
        ByVal eventType As String, _
        ByVal content As String, _
        ByVal srcType As String, _
        ByVal srcId As String)

    Dim ws As Worksheet, r As Long
    If Len(personId) = 0 Or Not IsDate(eventDate) Then Exit Sub
    Set ws = ThisWorkbook.Worksheets(SH_W_EVENT)
    For r = 2 To LastRow(ws, 1)
        If CStr(ws.Cells(r, E_PERSON_ID).Value) = personId Then
            If IsDate(ws.Cells(r, E_DATE).Value) And IsDate(eventDate) Then
                If CLng(CDate(ws.Cells(r, E_DATE).Value)) = CLng(CDate(eventDate)) Then
                    If CStr(ws.Cells(r, E_TYPE).Value) = eventType _
                            And CStr(ws.Cells(r, E_SOURCE_TYPE).Value) = srcType _
                            And CStr(ws.Cells(r, E_SOURCE_ID).Value) = srcId Then
                        ws.Cells(r, E_CONTENT).Value = content
                        ws.Cells(r, E_AUTO).Value = "�����"
                        ws.Cells(r, E_SHOW).Value = SHOW_YES
                        ws.Cells(r, E_STATUS).Value = STATUS_ACTIVE
                        Exit Sub
                    End If
                End If
            End If
        End If
    Next r
    r = NextBlankRow(ws, 1)
    ws.Cells(r, E_ID).Value = NextId("�C�x���g")
    ws.Cells(r, E_PERSON_ID).Value = personId
    ws.Cells(r, E_DATE).Value = eventDate
    ws.Cells(r, E_YEAR).Value = Year(CDate(eventDate))
    ws.Cells(r, E_TYPE).Value = eventType
    ws.Cells(r, E_CONTENT).Value = content
    ws.Cells(r, E_AUTO).Value = "�����"
    ws.Cells(r, E_SOURCE_TYPE).Value = srcType
    ws.Cells(r, E_SOURCE_ID).Value = srcId
    ws.Cells(r, E_SHOW).Value = SHOW_YES
    ws.Cells(r, E_STATUS).Value = STATUS_ACTIVE

End Sub


Public Sub FillFormerSurnameFromAuto(Optional ByVal showMessage As Boolean = True)

    Dim ws As Worksheet, modeName As String, autoSurname As String, currentSurname As String, relText As String
    Set ws = ThisWorkbook.Worksheets(SH_INPUT)
    modeName = CleanText(ws.Range(CELL_MODE).Value)
    autoSurname = CleanText(ws.Range(CELL_AUTO_SURNAME).Value)
    currentSurname = CleanText(ws.Range(CELL_SURNAME).Value)
    If Len(autoSurname) = 0 Or Len(currentSurname) = 0 Then Exit Sub
    If StrComp(autoSurname, currentSurname, vbTextCompare) = 0 Then Exit Sub
    If Len(CleanText(ws.Range(CELL_FORMER_SURNAME).Value)) > 0 Then Exit Sub

    relText = ResolveRelationTextForRegistration(modeName, CleanText(ws.Range(CELL_BASE_ID).Value), _
        CleanText(ws.Range(CELL_REL_TO_DECEDENT).Value), CleanText(ws.Range(CELL_GENDER).Value), ws.Range(CELL_BIRTH).Value)

    If ShouldAutoFormerSurname(modeName, relText) Then
        ws.Range(CELL_FORMER_SURNAME).Value = autoSurname
        If showMessage Then SetPersonInputStatus "�����Ɂw" & autoSurname & "�x��⊮���܂����B�s�v�ȏꍇ���������Ă��������B"
    ElseIf showMessage Then
        SetPersonInputStatus "���̊֌W�ł͋����������⊮���܂���B�K�v�ȏꍇ�����������֓��͂��Ă��������B"
    End If

End Sub

Private Function ShouldAutoFormerSurname(ByVal modeName As String, ByVal relText As String) As Boolean

    relText = CleanText(relText)

    '�����⊮�͐��ʂŌ��߂Ȃ��B
    '�u��l���R���̐����v�ƌ��ݐ����Ⴄ�ꍇ�ɁA�q�E���E�]���E�����Ȃǂ̎q���n�����⊮����B
    '�������A�z��Җ{�l��u�z��҂̎q�v�Ɩ������ꂽ�l���ɂ́A��l�����̋���������ɓ���Ȃ��B
    If InStr(1, relText, "�z���", vbTextCompare) > 0 Then Exit Function

    If IsDirectDescendantRelationText(relText) Then
        ShouldAutoFormerSurname = True
    ElseIf Len(relText) = 0 Then
        ShouldAutoFormerSurname = (modeName = MODE_CHILD Or modeName = MODE_GRANDCHILD)
    End If

End Function

Public Sub MakeAddressKeyFromInput()

    Dim ws As Worksheet

    Set ws = ThisWorkbook.Worksheets(SH_INPUT)

    ws.Range(CELL_ADDR_KEY).Value = NormalizeAddress(ws.Range(CELL_ADDR_TEXT).Value)

End Sub

Public Sub ApplySelectedAddressCandidate()

    Dim ws As Worksheet, sel As String, id As String, r As Long

    Set ws = ThisWorkbook.Worksheets(SH_INPUT)

    sel = CleanText(ws.Range(CELL_ADDR_CAND).Value)

    If Len(sel) = 0 Then Exit Sub

    If InStr(sel, "��l���Ɠ��l") > 0 Then
        CopyBaseCurrentAddress False
        Exit Sub
    End If

    id = ParseIdFromCandidate(sel)

    r = FindAddressCandidateRow(id)

    If r = 0 Then Exit Sub

    ws.Range(CELL_ADDR_TEXT).Value = ThisWorkbook.Worksheets(SH_W_ADDR_CAND).Cells(r, AC_TEXT).Value

    ws.Range(CELL_ADDR_KEY).Value = ThisWorkbook.Worksheets(SH_W_ADDR_CAND).Cells(r, AC_KEY).Value

End Sub

Public Sub CopyBaseCurrentAddress(Optional ByVal showMessage As Boolean = True)

    Dim ws As Worksheet, baseId As String, addrText As String, addrKey As String

    Set ws = ThisWorkbook.Worksheets(SH_INPUT)

    baseId = CleanText(ws.Range(CELL_BASE_ID).Value)

    If Len(baseId) = 0 Then Exit Sub

    GetCurrentAddressParts baseId, addrText, addrKey

    If Len(addrText) > 0 Then

        ws.Range(CELL_ADDR_TEXT).Value = addrText

        ws.Range(CELL_ADDR_KEY).Value = addrKey

        If showMessage Then NotifyInfo "��l���̏Z�����R�s�[���܂����B"

    End If

End Sub


Public Sub CopyBaseAddressHistoryToCurrentOrPending()

    On Error GoTo EH
    AppBegin
    Dim wsIn As Worksheet, baseId As String, pid As String, pendingKey As String
    Dim wsA As Worksheet, r As Long, copied As Long
    Set wsIn = ThisWorkbook.Worksheets(SH_INPUT)
    baseId = CleanText(wsIn.Range(CELL_BASE_ID).Value)
    pid = CleanText(wsIn.Range(CELL_PERSON_ID).Value)
    If Len(baseId) = 0 Then Err.Raise 5, , "��l�������ݒ�ł��B"
    If Len(pid) = 0 Then pendingKey = PendingAddressKeyForInput(True)
    Set wsA = ThisWorkbook.Worksheets(SH_W_ADDR_HIST)
    For r = 2 To LastRow(wsA, 1)
        If CStr(wsA.Cells(r, A_PERSON_ID).Value) = baseId _
                And CStr(wsA.Cells(r, A_STATUS).Value) <> STATUS_CANCEL _
                And Len(CleanText(wsA.Cells(r, A_TEXT).Value)) > 0 Then
            If Len(pid) > 0 Then
                CopyAddressHistoryRowToPerson r, pid, baseId
            Else
                StageAddressHistoryRowToPending r, pendingKey, baseId
            End If
            copied = copied + 1
        End If
    Next r
    If copied = 0 Then Err.Raise 5, , "��l���̏Z������������܂���B"
    If Len(pid) > 0 Then
        RefreshAddressCandidateListOnly
        UpdateRepresentativeAddressId pid
        SetPersonInputStatus "��l���̏Z��������" & copied & "���R�s�[���܂����B"
    Else
        SetPersonInputStatus "��l���̏Z�����������ǉ����܂����B�l���o�^����" & copied & "���܂Ƃ߂ēo�^���܂��B"
    End If
    AppEnd
    Exit Sub
EH:
    AppEnd
    RuntimeShowError "CopyBaseAddressHistoryToCurrentOrPending", "�Z�������R�s�[", "��l���ƏZ�������̏�Ԃ��m�F���Ă��������B"

End Sub

Private Sub CopyAddressHistoryRowToPerson(ByVal srcRow As Long, ByVal personId As String, ByVal copySourcePersonId As String)

    Dim wsA As Worksheet, r As Long, candId As String
    Set wsA = ThisWorkbook.Worksheets(SH_W_ADDR_HIST)
    candId = GetOrCreateAddressCandidate(CStr(wsA.Cells(srcRow, A_TEXT).Value), CStr(wsA.Cells(srcRow, A_KEY).Value), personId)
    r = FindMatchingAddressHistoryRow(personId, CStr(wsA.Cells(srcRow, A_KEY).Value), CStr(wsA.Cells(srcRow, A_TYPE).Value), wsA.Cells(srcRow, A_START).Value, wsA.Cells(srcRow, A_END).Value)
    If r = 0 Then
        r = NextBlankRow(wsA, 1)
        wsA.Cells(r, A_ID).Value = NextId("�Z������")
        wsA.Cells(r, A_CREATED).Value = Now
    End If
    wsA.Cells(r, A_PERSON_ID).Value = personId
    wsA.Cells(r, A_CAND_ID).Value = candId
    wsA.Cells(r, A_TYPE).Value = wsA.Cells(srcRow, A_TYPE).Value
    wsA.Cells(r, A_START).Value = wsA.Cells(srcRow, A_START).Value
    wsA.Cells(r, A_END).Value = wsA.Cells(srcRow, A_END).Value
    wsA.Cells(r, A_TEXT).Value = wsA.Cells(srcRow, A_TEXT).Value
    wsA.Cells(r, A_KEY).Value = wsA.Cells(srcRow, A_KEY).Value
    wsA.Cells(r, A_SOURCE).Value = wsA.Cells(srcRow, A_SOURCE).Value
    wsA.Cells(r, A_COPY_PERSON_ID).Value = copySourcePersonId
    wsA.Cells(r, A_COPY_ADDR_ID).Value = wsA.Cells(srcRow, A_ID).Value
    wsA.Cells(r, A_NOTE).Value = wsA.Cells(srcRow, A_NOTE).Value
    wsA.Cells(r, A_STATUS).Value = STATUS_ACTIVE
    wsA.Cells(r, A_UPDATED).Value = Now
    If Len(CleanText(wsA.Cells(srcRow, A_START_KIND).Value)) = 0 Then
        wsA.Cells(r, A_START_KIND).Value = "���Z�J�n"
    Else
        wsA.Cells(r, A_START_KIND).Value = CleanText(wsA.Cells(srcRow, A_START_KIND).Value)
    End If

End Sub

Private Sub StageAddressHistoryRowToPending(ByVal srcRow As Long, ByVal pendingKey As String, ByVal copySourcePersonId As String)

    Dim wsA As Worksheet, wsP As Worksheet, r As Long
    If Len(pendingKey) = 0 Then Exit Sub
    Set wsA = ThisWorkbook.Worksheets(SH_W_ADDR_HIST)
    Set wsP = ThisWorkbook.Worksheets(SH_W_ADDR_PENDING)
    r = NextBlankRow(wsP, 1)
    wsP.Cells(r, AP_KEY).Value = pendingKey
    wsP.Cells(r, AP_SEQ).Value = PendingAddressCount(pendingKey) + 1
    wsP.Cells(r, AP_ADDR_TEXT).Value = wsA.Cells(srcRow, A_TEXT).Value
    wsP.Cells(r, AP_ADDR_KEY).Value = wsA.Cells(srcRow, A_KEY).Value
    wsP.Cells(r, AP_ADDR_TYPE).Value = wsA.Cells(srcRow, A_TYPE).Value
    wsP.Cells(r, AP_START).Value = wsA.Cells(srcRow, A_START).Value
    wsP.Cells(r, AP_END).Value = wsA.Cells(srcRow, A_END).Value
    wsP.Cells(r, AP_SOURCE).Value = wsA.Cells(srcRow, A_SOURCE).Value
    wsP.Cells(r, AP_NOTE).Value = wsA.Cells(srcRow, A_NOTE).Value
    wsP.Cells(r, AP_COPY_PERSON_ID).Value = copySourcePersonId
    wsP.Cells(r, AP_CREATED).Value = Now
    wsP.Cells(r, AP_STATUS).Value = STATUS_ACTIVE
    If Len(CleanText(wsA.Cells(srcRow, A_START_KIND).Value)) = 0 Then
        wsP.Cells(r, AP_START_KIND).Value = "���Z�J�n"
    Else
        wsP.Cells(r, AP_START_KIND).Value = CleanText(wsA.Cells(srcRow, A_START_KIND).Value)
    End If

End Sub

Public Sub CopyLastAddress()

    Dim ws As Worksheet, r As Long

    Set ws = ThisWorkbook.Worksheets(SH_W_ADDR_CAND)

    r = LastRow(ws, AC_LAST_USED)

    If r < 2 Then Exit Sub

    ThisWorkbook.Worksheets(SH_INPUT).Range(CELL_ADDR_TEXT).Value = ws.Cells(r, AC_TEXT).Value

    ThisWorkbook.Worksheets(SH_INPUT).Range(CELL_ADDR_KEY).Value = ws.Cells(r, AC_KEY).Value

End Sub

Public Sub UseMarriageDateAsAddressStart()

    Dim ws As Worksheet

    Set ws = ThisWorkbook.Worksheets(SH_INPUT)

    If IsDate(ws.Range(CELL_MARRIAGE).Value) Then
        ws.Range(CELL_ADDR_START).Value = CDate(ws.Range(CELL_MARRIAGE).Value)
        ws.Range(CELL_ADDR_START_KIND).Value = "���Z�J�n"
        EnsurePersonInputDateDisplay ws
        SetPersonInputStatus "���������Z���J�n���ɔ��f���܂����B"
    Else
        SetPersonInputStatus "�������������͂܂��͓��t�Ƃ��ēǂ߂Ȃ����߁A�Z���J�n���ɔ��f���Ă��܂���B"
    End If

End Sub

Public Sub UseBirthDateAsAddressStart()

    Dim ws As Worksheet

    Set ws = ThisWorkbook.Worksheets(SH_INPUT)

    If IsDate(ws.Range(CELL_BIRTH).Value) Then
        ws.Range(CELL_ADDR_START).Value = CDate(ws.Range(CELL_BIRTH).Value)
        ws.Range(CELL_ADDR_START_KIND).Value = "���Z�J�n"
        EnsurePersonInputDateDisplay ws
        SetPersonInputStatus "�o�������Z���J�n���ɔ��f���܂����B"
    Else
        SetPersonInputStatus "�o�����������͂܂��͓��t�Ƃ��ēǂ߂Ȃ����߁A�Z���J�n���ɔ��f���Ă��܂���B"
    End If

End Sub

Public Sub UseDeathDateAsAddressEnd()

    Dim ws As Worksheet

    Set ws = ThisWorkbook.Worksheets(SH_INPUT)

    If IsDate(ws.Range(CELL_DEATH).Value) Then
        ws.Range(CELL_ADDR_END).Value = CDate(ws.Range(CELL_DEATH).Value)
        EnsurePersonInputDateDisplay ws
        SetPersonInputStatus "���S�����Z���I�����ɔ��f���܂����B"
    Else
        SetPersonInputStatus "���S���������͂܂��͓��t�Ƃ��ēǂ߂Ȃ����߁A�Z���I�����ɔ��f���Ă��܂���B"
    End If

End Sub

Public Sub UseDivorceDateAsAddressEnd()

    Dim ws As Worksheet

    Set ws = ThisWorkbook.Worksheets(SH_INPUT)

    If IsDate(ws.Range(CELL_DIVORCE).Value) Then
        ws.Range(CELL_ADDR_END).Value = CDate(ws.Range(CELL_DIVORCE).Value)
        EnsurePersonInputDateDisplay ws
        SetPersonInputStatus "���������Z���I�����ɔ��f���܂����B"
    Else
        SetPersonInputStatus "�������������͂܂��͓��t�Ƃ��ēǂ߂Ȃ����߁A�Z���I�����ɔ��f���Ă��܂���B"
    End If

End Sub

Public Function FindAddressCandidateRow(ByVal candId As String) As Long

    Dim ws As Worksheet, r As Long, lastR As Long

    Set ws = ThisWorkbook.Worksheets(SH_W_ADDR_CAND)

    lastR = LastRow(ws, 1)

    For r = 2 To lastR

        If CStr(ws.Cells(r, AC_ID).Value) = candId Then FindAddressCandidateRow = r: Exit Function

    Next r

End Function

Public Sub GetCurrentAddressParts(ByVal personId As String, ByRef addressText As String, ByRef addressKey As String)

    Dim ws As Worksheet, bestR As Long

    If Len(CleanText(personId)) = 0 Then Exit Sub

    If Not SheetExists(SH_W_ADDR_HIST, ThisWorkbook) Then Exit Sub

    Set ws = ThisWorkbook.Worksheets(SH_W_ADDR_HIST)

    bestR = BestAddressHistoryRowForPerson(personId)

    If bestR > 0 Then

        addressText = CStr(ws.Cells(bestR, A_TEXT).Value)

        addressKey = CStr(ws.Cells(bestR, A_KEY).Value)

    End If

End Sub

Public Function GetCurrentAddressText(ByVal personId As String) As String

    Dim t As String, k As String

    GetCurrentAddressParts personId, t, k

    GetCurrentAddressText = t

End Function

Public Sub RefreshRepresentativeAddresses()

    On Error Resume Next

    Dim wsP As Worksheet, r As Long, pid As String

    If Not SheetExists(SH_W_PERSON, ThisWorkbook) Then Exit Sub

    Set wsP = ThisWorkbook.Worksheets(SH_W_PERSON)

    For r = 2 To LastRow(wsP, 1)

        pid = CleanText(wsP.Cells(r, P_ID).Value)

        If Len(pid) > 0 And CStr(wsP.Cells(r, P_STATUS).Value) <> STATUS_CANCEL Then

            UpdateRepresentativeAddressId pid

        End If

    Next r

    On Error GoTo 0

End Sub

Public Sub UpdateRepresentativeAddressId(ByVal personId As String)

    Dim personRow As Long, bestR As Long

    If Len(CleanText(personId)) = 0 Then Exit Sub

    personRow = FindPersonRow(personId)

    If personRow = 0 Then Exit Sub

    bestR = BestAddressHistoryRowForPerson(personId)

    If bestR > 0 Then

        ThisWorkbook.Worksheets(SH_W_PERSON).Cells(personRow, P_REP_ADDR_ID).Value = _
            ThisWorkbook.Worksheets(SH_W_ADDR_HIST).Cells(bestR, A_ID).Value

    End If

End Sub

Private Function BestAddressHistoryRowForPerson(ByVal personId As String) As Long

    Dim ws As Worksheet, r As Long, lastR As Long

    Dim bestScore As Double, score As Double

    If Not SheetExists(SH_W_ADDR_HIST, ThisWorkbook) Then Exit Function

    Set ws = ThisWorkbook.Worksheets(SH_W_ADDR_HIST)

    lastR = LastRow(ws, 1)

    bestScore = -1E+20

    For r = 2 To lastR

        If CStr(ws.Cells(r, A_PERSON_ID).Value) = personId _
                And CStr(ws.Cells(r, A_STATUS).Value) <> STATUS_CANCEL _
                And Len(CStr(ws.Cells(r, A_ID).Value)) > 0 Then

            score = AddressRepresentativeScore(ws, r)

            If score > bestScore Then

                bestScore = score

                BestAddressHistoryRowForPerson = r

            End If

        End If

    Next r

End Function

Private Function AddressRepresentativeScore(ByVal ws As Worksheet, ByVal rowNo As Long) As Double

    Dim baseDate As Variant, st As Variant, en As Variant, score As Double

    baseDate = PreferredAddressBaseDate()

    st = ws.Cells(rowNo, A_START).Value

    en = ws.Cells(rowNo, A_END).Value

    score = rowNo

    If CleanText(ws.Cells(rowNo, A_TYPE).Value) = "���Z�n" Then score = score + 100000

    If IsDate(st) Then score = score + CDbl(CDate(st)) / 100

    If IsDate(baseDate) Then

        If IsDate(st) Then

            If CDate(st) <= CDate(baseDate) Then score = score + 200000 Else score = score - 50000

        End If

        If IsDate(en) Then

            If CDate(en) >= CDate(baseDate) Then score = score + 200000 Else score = score - 20000

        Else

            score = score + 150000

        End If

    ElseIf Not IsDate(en) Then

        score = score + 50000

    End If

    AddressRepresentativeScore = score

End Function

Private Function PreferredAddressBaseDate() As Variant

    On Error Resume Next

    PreferredAddressBaseDate = ThisWorkbook.Worksheets(SH_CONFIG).Range(CELL_CONFIG_INHERIT_DATE).Value

    If Not IsDate(PreferredAddressBaseDate) Then _
        PreferredAddressBaseDate = ThisWorkbook.Worksheets(SH_CONFIG).Range(CELL_CONFIG_BASE_DATE).Value

    If Not IsDate(PreferredAddressBaseDate) Then PreferredAddressBaseDate = Date

    On Error GoTo 0

End Function

Private Sub EnsureCandidatesWarmForInputMode()

    '���̓��[�h�ؑւ̃z�b�g�p�X�ł͌��S�Đ����𑖂点�Ȃ��B
    '���V�[�g�����\�z�E��̏ꍇ�����A�C���Ƃ��Ĉ�x�����č\�z����B
    On Error GoTo EH
    Dim wsC As Worksheet
    Set wsC = ThisWorkbook.Worksheets(SH_W_CAND)
    If LastRow(wsC, 4) < 2 Then
        If LastRow(ThisWorkbook.Worksheets(SH_W_PERSON), 1) >= 2 Then
            RefreshCandidates
        End If
    End If
    Exit Sub
EH:
    RuntimeAppendLog "WARN", "EnsureCandidatesWarmForInputMode", "��≷��", "���͐ؑ�", Err.Number, Err.Description, Err.Source
    Err.Clear

End Sub

Public Sub RefreshCandidates()

    Dim wsC As Worksheet, wsP As Worksheet, wsA As Worksheet, r As Long, outR As Long, dict As Object, key As Variant

    Set wsC = ThisWorkbook.Worksheets(SH_W_CAND)

    wsC.Range("A2:O" & Application.Max(500, LastRow(wsC, 1), LastRow(wsC, 2), LastRow(wsC, 4), LastRow(wsC, 12), LastRow(wsC, 15))).ClearContents

    Set dict = CreateObject("Scripting.Dictionary")

    Set wsP = ThisWorkbook.Worksheets(SH_W_PERSON)

    For r = 2 To LastRow(wsP, 1)

        If CStr(wsP.Cells(r, P_STATUS).Value) <> STATUS_CANCEL Then

            If Len(CStr(wsP.Cells(r, P_SURNAME).Value)) > 0 Then dict(CStr(wsP.Cells(r, P_SURNAME).Value)) = 1

            If Len(CStr(wsP.Cells(r, P_FORMER).Value)) > 0 Then dict(CStr(wsP.Cells(r, P_FORMER).Value)) = 1

        End If

    Next r

    outR = 2

    For Each key In dict.Keys

        wsC.Cells(outR, 1).Value = key

        outR = outR + 1

    Next key

    Set wsA = ThisWorkbook.Worksheets(SH_W_ADDR_CAND)

    outR = 2
    wsC.Cells(outR, 2).Value = "��l���Ɠ��l"
    wsC.Cells(outR, 3).Value = "__BASE__"
    outR = outR + 1
    For r = 2 To LastRow(wsA, 1)

        If Len(CStr(wsA.Cells(r, AC_ID).Value)) > 0 Then

            wsC.Cells(outR, 2).Value = wsA.Cells(r, AC_ID).Value & " " & wsA.Cells(r, AC_TEXT).Value
            wsC.Cells(outR, 3).Value = wsA.Cells(r, AC_ID).Value
            wsC.Cells(outR, 15).Value = wsA.Cells(r, AC_TEXT).Value

            outR = outR + 1

        End If

    Next r

    outR = 2
    For r = 2 To LastRow(wsP, 1)

        If Len(CStr(wsP.Cells(r, P_ID).Value)) > 0 And CStr(wsP.Cells(r, P_STATUS).Value) <> STATUS_CANCEL Then

            wsC.Cells(outR, 4).Value = wsP.Cells(r, P_ID).Value & " " & wsP.Cells(r, P_DISPLAY).Value & "�i" & wsP.Cells(r, P_REL_DEC).Value & "�j"

            wsC.Cells(outR, 5).Value = wsP.Cells(r, P_ID).Value

            outR = outR + 1

        End If

    Next r

    FillStaticCandidates wsC

    FillDateCandidates wsC

    CompactCandidateColumn wsC, 1
    CompactCandidatePairColumns wsC, 2, 3
    CompactCandidateColumn wsC, 15
    CompactCandidatePairColumns wsC, 4, 5
    CompactCandidateColumn wsC, 12
    CompactCandidateColumn wsC, 13
    CompactCandidateColumn wsC, 14
    CompactCandidateColumn wsC, 15

End Sub

Private Sub RefreshAddressCandidateListOnly()

    '�Z���ǉ���̃z�b�g�p�X�ł́A�l��������t���܂ō�蒼���Ȃ��B
    '�Z�����񂾂����X�V���A�o�^����̌y���Ɠ��͌��̈ێ��𗼗�����B
    Dim wsC As Worksheet, wsA As Worksheet, r As Long, clearLast As Long, outR As Long

    Set wsC = ThisWorkbook.Worksheets(SH_W_CAND)
    Set wsA = ThisWorkbook.Worksheets(SH_W_ADDR_CAND)

    clearLast = Application.Max(500, LastRow(wsC, 2), LastRow(wsC, 3), LastRow(wsC, 15), LastRow(wsA, 1))
    wsC.Range("B2:C" & clearLast).ClearContents
    wsC.Range("O2:O" & clearLast).ClearContents

    outR = 2
    wsC.Cells(outR, 2).Value = "��l���Ɠ��l"
    wsC.Cells(outR, 3).Value = "__BASE__"
    outR = outR + 1
    For r = 2 To LastRow(wsA, 1)

        If Len(CStr(wsA.Cells(r, AC_ID).Value)) > 0 Then

            wsC.Cells(outR, 2).Value = wsA.Cells(r, AC_ID).Value & " " & wsA.Cells(r, AC_TEXT).Value
            wsC.Cells(outR, 3).Value = wsA.Cells(r, AC_ID).Value
            wsC.Cells(outR, 15).Value = wsA.Cells(r, AC_TEXT).Value
            outR = outR + 1

        End If

    Next r

    CompactCandidatePairColumns wsC, 2, 3

End Sub

Private Sub RefreshCandidatesAfterPersonRegister(ByVal personId As String)

    '�l���o�^����̃z�b�g�p�X�ł� W_��� �S�̂������č�蒼���Ȃ��B
    '���E�l�����E�Z�����E������͂������t�������������f����B
    On Error GoTo EH

    Dim wsC As Worksheet, wsP As Worksheet, wsIn As Worksheet
    Dim pr As Long, candidateText As String

    If Len(personId) = 0 Then Exit Sub

    Set wsC = ThisWorkbook.Worksheets(SH_W_CAND)
    Set wsP = ThisWorkbook.Worksheets(SH_W_PERSON)
    Set wsIn = ThisWorkbook.Worksheets(SH_INPUT)

    pr = FindPersonRow(personId)
    If pr > 0 Then
        AddCandidateTextUnique wsC, 1, CStr(wsP.Cells(pr, P_SURNAME).Value), 0
        AddCandidateTextUnique wsC, 1, CStr(wsP.Cells(pr, P_FORMER).Value), 0
        candidateText = CStr(wsP.Cells(pr, P_ID).Value) & " " & _
            CStr(wsP.Cells(pr, P_DISPLAY).Value) & "�i" & CStr(wsP.Cells(pr, P_REL_DEC).Value) & "�j"
        UpsertPersonCandidate wsC, CStr(wsP.Cells(pr, P_ID).Value), candidateText
    End If

    RefreshAddressCandidateListOnly
    AddDateCandidateToColumnUnique wsC, 12, wsIn.Range(CELL_MARRIAGE).Value, 0
    AddDateCandidateToColumnUnique wsC, 13, wsIn.Range(CELL_DIVORCE).Value, 0
    AddDateCandidateToColumnUnique wsC, 14, wsIn.Range(CELL_BIRTH).Value, 0
    AddDateCandidateToColumnUnique wsC, 14, wsIn.Range(CELL_DEATH).Value, 0
    AddDateCandidateToColumnUnique wsC, 14, wsIn.Range(CELL_ADDR_START).Value, 0
    AddDateCandidateToColumnUnique wsC, 14, wsIn.Range(CELL_ADDR_END).Value, 0
    Exit Sub

EH:
    RuntimeAppendLog "WARN", "RefreshCandidatesAfterPersonRegister", "��⍷���X�V", personId, Err.Number, Err.Description, Err.Source
    Err.Clear

End Sub

Private Sub UpsertPersonCandidate(ByVal wsC As Worksheet, ByVal personId As String, ByVal candidateText As String)

    Dim r As Long, firstBlank As Long
    personId = CleanText(personId)
    candidateText = CleanText(candidateText)
    If Len(personId) = 0 Or Len(candidateText) = 0 Then Exit Sub

    Dim maxRow As Long
    maxRow = Application.Max(LastRow(wsC, 4) + 50, LastRow(wsC, 5) + 50, 500)
    For r = 2 To maxRow
        If CleanText(wsC.Cells(r, 5).Value) = personId Then
            wsC.Cells(r, 4).Value = candidateText
            wsC.Cells(r, 5).Value = personId
            Exit Sub
        End If
        If firstBlank = 0 Then
            If Len(CleanText(wsC.Cells(r, 4).Value)) = 0 And Len(CleanText(wsC.Cells(r, 5).Value)) = 0 Then firstBlank = r
        End If
    Next r

    If firstBlank > 0 Then
        wsC.Cells(firstBlank, 4).Value = candidateText
        wsC.Cells(firstBlank, 5).Value = personId
    End If

End Sub

Private Sub AddCandidateTextUnique(ByVal wsC As Worksheet, ByVal colNum As Long, ByVal textValue As String, ByVal maxRow As Long)

    Dim r As Long, firstBlank As Long, v As String
    v = CleanText(textValue)
    If Len(v) = 0 Then Exit Sub
    If maxRow < 2 Then maxRow = Application.Max(LastRow(wsC, colNum) + 50, 500)

    For r = 2 To maxRow
        If StrComp(CleanText(wsC.Cells(r, colNum).Value), v, vbTextCompare) = 0 Then Exit Sub
        If firstBlank = 0 And Len(CleanText(wsC.Cells(r, colNum).Value)) = 0 Then firstBlank = r
    Next r

    If firstBlank > 0 Then wsC.Cells(firstBlank, colNum).Value = v

End Sub

Private Sub AddDateCandidateToColumnUnique(ByVal wsC As Worksheet, ByVal colNum As Long, ByVal candidateDate As Variant, ByVal maxRow As Long)

    Dim r As Long, firstBlank As Long, serialValue As Long
    If Not IsDate(candidateDate) Then Exit Sub
    If maxRow < 2 Then maxRow = Application.Max(LastRow(wsC, colNum) + 50, 500)
    serialValue = CLng(DateValue(CDate(candidateDate)))

    For r = 2 To maxRow
        If IsDate(wsC.Cells(r, colNum).Value) Then
            If CLng(DateValue(CDate(wsC.Cells(r, colNum).Value))) = serialValue Then Exit Sub
        End If
        If firstBlank = 0 And Len(CleanText(wsC.Cells(r, colNum).Value)) = 0 Then firstBlank = r
    Next r

    If firstBlank > 0 Then
        wsC.Cells(firstBlank, colNum).Value = CDate(candidateDate)
        wsC.Cells(firstBlank, colNum).NumberFormatLocal = "yyyy/m/d"
    End If

End Sub

Private Sub CompactCandidateColumn(ByVal wsC As Worksheet, ByVal colNum As Long)

    Dim lastR As Long, r As Long, outR As Long, values As Collection, v As Variant
    If wsC Is Nothing Then Exit Sub
    lastR = LastRow(wsC, colNum)
    If lastR < 2 Then Exit Sub

    Set values = New Collection
    For r = 2 To lastR
        If Len(CleanText(wsC.Cells(r, colNum).Value)) > 0 Then values.Add wsC.Cells(r, colNum).Value
    Next r

    wsC.Range(wsC.Cells(2, colNum), wsC.Cells(lastR, colNum)).ClearContents
    outR = 2
    For Each v In values
        wsC.Cells(outR, colNum).Value = v
        outR = outR + 1
    Next v

End Sub

Private Sub CompactCandidatePairColumns(ByVal wsC As Worksheet, ByVal displayCol As Long, ByVal idCol As Long)

    Dim lastR As Long, r As Long, outR As Long
    Dim displayValues As Collection, idValues As Collection

    If wsC Is Nothing Then Exit Sub
    lastR = Application.Max(LastRow(wsC, displayCol), LastRow(wsC, idCol))
    If lastR < 2 Then Exit Sub

    Set displayValues = New Collection
    Set idValues = New Collection
    For r = 2 To lastR
        If Len(CleanText(wsC.Cells(r, displayCol).Value)) > 0 Or Len(CleanText(wsC.Cells(r, idCol).Value)) > 0 Then
            displayValues.Add wsC.Cells(r, displayCol).Value
            idValues.Add wsC.Cells(r, idCol).Value
        End If
    Next r

    wsC.Range(wsC.Cells(2, displayCol), wsC.Cells(lastR, idCol)).ClearContents
    outR = 2
    For r = 1 To displayValues.Count
        wsC.Cells(outR, displayCol).Value = displayValues(r)
        wsC.Cells(outR, idCol).Value = idValues(r)
        outR = outR + 1
    Next r

End Sub

Private Sub FillDateCandidates(ByVal wsC As Worksheet)

    Dim dictM As Object, dictD As Object, dictA As Object

    Dim wsR As Worksheet, wsP As Worksheet, wsA As Worksheet, r As Long, key As Variant, outR As Long

    Set dictM = CreateObject("Scripting.Dictionary")

    Set dictD = CreateObject("Scripting.Dictionary")

    Set dictA = CreateObject("Scripting.Dictionary")

    Set wsR = ThisWorkbook.Worksheets(SH_W_REL)

    For r = 2 To LastRow(wsR, 1)

        If CStr(wsR.Cells(r, R_STATUS).Value) <> STATUS_CANCEL Then

            AddDateCandidate dictM, wsR.Cells(r, R_MARRIAGE).Value

            AddDateCandidate dictA, wsR.Cells(r, R_MARRIAGE).Value

            AddDateCandidate dictD, wsR.Cells(r, R_DIVORCE).Value

            AddDateCandidate dictA, wsR.Cells(r, R_DIVORCE).Value

        End If

    Next r

    Set wsP = ThisWorkbook.Worksheets(SH_W_PERSON)

    For r = 2 To LastRow(wsP, 1)

        If CStr(wsP.Cells(r, P_STATUS).Value) <> STATUS_CANCEL Then

            AddDateCandidate dictA, wsP.Cells(r, P_BIRTH).Value

            AddDateCandidate dictA, wsP.Cells(r, P_DEATH).Value

        End If

    Next r

    Set wsA = ThisWorkbook.Worksheets(SH_W_ADDR_HIST)

    For r = 2 To LastRow(wsA, 1)

        If CStr(wsA.Cells(r, A_STATUS).Value) <> STATUS_CANCEL Then

            AddDateCandidate dictA, wsA.Cells(r, A_START).Value

            AddDateCandidate dictA, wsA.Cells(r, A_END).Value

        End If

    Next r

    AddRelationAndEventDatesToCandidateDictionaries dictM, dictD, dictA

    outR = 2

    For Each key In dictM.Keys

        wsC.Cells(outR, 12).Value = CDate(dictM(key))

        outR = outR + 1

    Next key

    outR = 2

    For Each key In dictD.Keys

        wsC.Cells(outR, 13).Value = CDate(dictD(key))

        outR = outR + 1

    Next key

    outR = 2

    For Each key In dictA.Keys

        wsC.Cells(outR, 14).Value = CDate(dictA(key))

        outR = outR + 1

    Next key

    wsC.Range("L2:N500").NumberFormatLocal = "yyyy/m/d"

End Sub

Private Sub AddRelationAndEventDatesToCandidateDictionaries(ByVal dictM As Object, ByVal dictD As Object, ByVal dictA As Object)

    Dim wr As Worksheet, we As Worksheet, r As Long
    If SheetExists(SH_W_REL, ThisWorkbook) Then
        Set wr = ThisWorkbook.Worksheets(SH_W_REL)
        For r = 2 To LastRow(wr, 1)
            If CStr(wr.Cells(r, R_STATUS).Value) <> STATUS_CANCEL Then
                AddDateCandidate dictM, wr.Cells(r, R_MARRIAGE).Value
                AddDateCandidate dictD, wr.Cells(r, R_DIVORCE).Value
                AddDateCandidate dictA, wr.Cells(r, R_MARRIAGE).Value
                AddDateCandidate dictA, wr.Cells(r, R_DIVORCE).Value
            End If
        Next r
    End If
    If SheetExists(SH_W_MARRIAGE_HIST, ThisWorkbook) Then
        Set wr = ThisWorkbook.Worksheets(SH_W_MARRIAGE_HIST)
        For r = 2 To LastRow(wr, 1)
            If CStr(wr.Cells(r, MH_STATUS).Value) <> STATUS_CANCEL Then
                AddDateCandidate dictM, wr.Cells(r, MH_MARRIAGE).Value
                AddDateCandidate dictD, wr.Cells(r, MH_DIVORCE).Value
                AddDateCandidate dictA, wr.Cells(r, MH_MARRIAGE).Value
                AddDateCandidate dictA, wr.Cells(r, MH_DIVORCE).Value
            End If
        Next r
    End If
    If SheetExists(SH_W_EVENT, ThisWorkbook) Then
        Set we = ThisWorkbook.Worksheets(SH_W_EVENT)
        For r = 2 To LastRow(we, 1)
            If CStr(we.Cells(r, E_STATUS).Value) <> STATUS_CANCEL Then
                AddDateCandidate dictA, we.Cells(r, E_DATE).Value
                If CStr(we.Cells(r, E_TYPE).Value) = "����" Then AddDateCandidate dictM, we.Cells(r, E_DATE).Value
                If CStr(we.Cells(r, E_TYPE).Value) = "����" Then AddDateCandidate dictD, we.Cells(r, E_DATE).Value
            End If
        Next r
    End If

End Sub

Private Sub RefreshDateCandidateListOnly()

    Dim wsC As Worksheet, lastClear As Long
    If Not SheetExists(SH_W_CAND, ThisWorkbook) Then Exit Sub
    Set wsC = ThisWorkbook.Worksheets(SH_W_CAND)
    lastClear = Application.Max(500, LastRow(wsC, 12), LastRow(wsC, 13), LastRow(wsC, 14))
    wsC.Range("L2:N" & lastClear).ClearContents
    FillDateCandidates wsC
    CompactCandidateColumn wsC, 12
    CompactCandidateColumn wsC, 13
    CompactCandidateColumn wsC, 14

End Sub

Private Sub RefreshMarriageDateCandidatesOnly(ByVal marriageDate As Variant, ByVal divorceDate As Variant)

    Dim wsC As Worksheet
    If Not SheetExists(SH_W_CAND, ThisWorkbook) Then Exit Sub
    Set wsC = ThisWorkbook.Worksheets(SH_W_CAND)
    AddDateCandidateToColumnUnique wsC, 12, marriageDate, 0
    AddDateCandidateToColumnUnique wsC, 13, divorceDate, 0
    AddDateCandidateToColumnUnique wsC, 14, marriageDate, 0
    AddDateCandidateToColumnUnique wsC, 14, divorceDate, 0

End Sub

Private Sub AddDateCandidate(ByVal dict As Object, ByVal v As Variant)

    If IsDate(v) Then dict(Format(CDate(v), "yyyy/mm/dd")) = CDate(v)

End Sub

Private Sub FillStaticCandidates(ByVal wsC As Worksheet)

    Dim arr, i As Long

    arr = Array("�ː�", "�ːЕ��[", "�Z���[", "�Z���[���[", "�\�q", "����", "�Œ莑�Y����", "���Z����", "�a������", "�،�����", "�ی�����", "�o�L����", "�{�ݎ���", "�a�@����", "��쎑��", "�e���\�q", "�X�֕�", "��������", "���L�^", "�{�݌_��", "���̑�")
    For i = 0 To UBound(arr)
        wsC.Cells(2 + i, 6).Value = arr(i)
    Next i

    arr = Array("���E", "��Ј�", "��Ж���", "���c��", "������", "����", "��t", "�Ō�t", "�m��", "�ŗ��m", "�ٌ�m", "�_��", "����", "�s���Y����", "��w�E��v", "�w��", "�N����", "�{�ݓ���", "���@��", "�v���", "�ސE", "�Ǝ��]��", "�s��", "���̑�")
    For i = 0 To UBound(arr)
        wsC.Cells(2 + i, 7).Value = arr(i)
    Next i

    arr = Array("�푊���l", "�z���", "�O�z���", "��", "��", "�{��", "�{��", "�c��", "�c��", "���j", "��j", "�O�j", "�l�j", "�ܒj", "�Z�j", "����", "��", "�O��", "�l��", "�܏�", "�Z��", "�q", "�{�q", "��", "�]��", "����", "�Z", "��", "�o", "��", "�Z��", "�o��", "�Z��o��", "�ٕ��Z��", "�ٕ�Z��", "�����Z��", "��", "��", "��P�����l", "����", "�����", "�������", "�⌾���s��", "���N�㌩�l", "�֌W��", "���̑��̊֌W�l")
    For i = 0 To UBound(arr)
        wsC.Cells(2 + i, 8).Value = arr(i)
    Next i

    arr = Array("���Z�n", "�Z���[�Z��", "������", "�{��", "�V�l�z�[��", "�T�[�r�X�t������Ҍ����Z��", "�a�@", "���{��", "�{��", "���S�ꏊ", "�ꎞ�؍ݐ�", "�]����", "�C�O�Z��", "�s��", "���̑�")
    For i = 0 To UBound(arr)
        wsC.Cells(2 + i, 9).Value = arr(i)
    Next i

    arr = Array("�j", "��", "�s��")
    For i = 0 To UBound(arr)
        wsC.Cells(2 + i, 10).Value = arr(i)
    Next i

    arr = Array(SHOW_YES, SHOW_NO)
    For i = 0 To UBound(arr)
        wsC.Cells(2 + i, 11).Value = arr(i)
    Next i

End Sub


# 01 人物情報 関数監査メモ

## 重点監査対象

相続関係図の人物関係解決経路を重点監査した。

## 確認した主経路

- `BuildRelationshipDiagram`
- `GetFatherRowForDiagram`
- `GetMotherRowForDiagram`
- `GetRootChildRows`
- `GetChildRowsForParent`
- `InferredDiagramParentIdForChildRow`
- `DiagramBestExplicitParentIdForChildRow`
- `DiagramStoredBaseParentIdForDrawing`
- `DiagramPrimaryParentIdForDrawing`
- `DiagramRelationAndNoteForPersonRow`
- `NormalizeDiagramRelationText`
- `DrawDescendantFamilyBlock`

## 結論

前回までの修正は、親子行や配偶者行の救済を増やしていたが、関係ラベル自体が `孫 孫`、`母 母` のように壊れた状態で判定関数へ流れていたため、救済ロジックの前提が崩れていた。

今回、関係ラベルの正規化を親子解決の入口に置き、孫の配偶者の子を婚姻日・出生日で血族側へ戻す経路を追加した。

## 実機確認で見る点

- 父の配偶者が母として父母ペアに出ること。
- 孫の配偶者の子が、孫夫婦の下に曽孫として出ること。
- 曽孫が未接続人物や被相続人直下へ逃げないこと。
- カード内文字が上下に隠れないこと。

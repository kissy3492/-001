@echo off
cd /d "%~dp0"
cscript //nologo IMPORT_04_MODULES.vbs %*
pause

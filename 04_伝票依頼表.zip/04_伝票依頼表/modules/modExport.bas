Attribute VB_Name = "modExport"

Option Explicit

Public Sub SaveVoucherCommonData()

    On Error GoTo EH

    EnsureVoucherBuildFreshForExport "���ʕۑ�"

    AppBegin "�`�[�˗��f�[�^�����ʕۑ���..."

    Dim p As String

    p = CommonDataPath()

    If Dir$(p) = vbNullString Then Err.Raise vbObjectError + 501, , COMMON_DATA_FILE & " ��������܂���B"

    Dim wb As Workbook

    BackupCommonDataBeforeUpdate p

    Set wb = Workbooks.Open(Filename:=p, ReadOnly:=False, UpdateLinks:=False, IgnoreReadOnlyRecommended:=True, Notify:=False, AddToMru:=False)

    If wb.ReadOnly Then Err.Raise vbObjectError + 8603, "SaveVoucherCommonData", "00_���ʃf�[�^.xlsx ���ǂݎ���p�ŊJ����Ă��܂��B�ʂ�Excel�ŊJ���Ă���ꍇ�͕��Ă�������: " & p

    WriteSettingTable wb

    CopyTableToCommon wb, SH_W_DEST, OUT_DEST

    CopyTableToCommon wb, SH_W_DATES, OUT_DATES

    CopyTableToCommon wb, SH_W_CONTROL, OUT_DETAIL

    wb.Save

    wb.Close SaveChanges:=False

    WriteLog "�`�[�˗��f�[�^�����ʕۑ�"

    AppEnd ""

    NotifyInfo "���ʃf�[�^�֕ۑ����܂����B"

    Exit Sub

EH:

    Dim errNum As Long, errDesc As String, errSrc As String

    errNum = Err.Number: errDesc = Err.Description: errSrc = Err.Source

    On Error Resume Next

    If Not wb Is Nothing Then wb.Close SaveChanges:=False

    AppEnd ""

    On Error GoTo 0

    RuntimeShowErrorValues "SaveVoucherCommonData", "���ʃf�[�^�ۑ�", "00_���ʃf�[�^.xlsx�����Ă��邩�A�Č��t�H���_�ɑ��݂��邩�m�F���Ă��������B", p, errNum, errDesc, errSrc

End Sub

Private Sub WriteSettingTable(ByVal wb As Workbook)

    Dim sh As Worksheet

    Set sh = ResetCommonSheet(wb, OUT_SETTING)

    sh.Range("A1:B1").Value = Array("����", "�l")

    Dim data As Variant, i As Long

    data = Array( _
        Array("schema", TOOL_SCHEMA), _
        Array("created_at", Now), _
        Array("source_tool", ThisWorkbook.Name), _
        Array("�O���s�c�Ɠ����܂߂�", SettingText("�O���s�c�Ɠ����܂߂�", "����")), _
        Array("�O�����", 1), _
        Array("�˗��p1�y�[�W�ő����", SettingLong("�˗��p1�y�[�W�ő����", 60)), _
        Array("�˗���ʃZ�b�g�o��", SettingText("�˗���ʃZ�b�g�o��", "����")), _
        Array("�˗��搔", Application.Max(LastRow(Ws(SH_W_DEST), 1) - 1, 0)))

    For i = 0 To UBound(data)

        sh.Cells(i + 2, 1).Value = data(i)(0)

        sh.Cells(i + 2, 2).Value = data(i)(1)

    Next i

    FormatCommonHeader sh

    UpdateCommonLinkControlSheet wb, "�`�[�˗��X�L�[�}�o�[�W����", TOOL_SCHEMA, "04���̏o�͎d�l"

    UpdateCommonLinkControlSheet wb, "�ۑ�����", Now, "���ʃf�[�^���Ō�ɍX�V��������"

End Sub

Private Sub UpdateCommonLinkControlSheet(ByVal wb As Workbook, ByVal keyText As String, ByVal valueText As Variant, ByVal descText As String)

    Dim ws As Worksheet, r As Long, lastR As Long

    On Error Resume Next

    Set ws = wb.Worksheets("T_�A�g�ݒ�")

    On Error GoTo 0

    If ws Is Nothing Then

        Set ws = wb.Worksheets.Add(Before:=wb.Worksheets(1))

        ws.Name = "T_�A�g�ݒ�"

        ws.Range("A1:C1").Value = Array("�L�[", "�l", "����")

    End If

    If Len(Nz(ws.Cells(1, 1).Value)) = 0 Then ws.Range("A1:C1").Value = Array("�L�[", "�l", "����")

    lastR = LastRow(ws, 1)

    If lastR < 1 Then lastR = 1

    For r = 2 To lastR

        If Nz(ws.Cells(r, 1).Value) = keyText Then

            ws.Cells(r, 2).Value = valueText

            ws.Cells(r, 3).Value = descText

            Exit Sub

        End If

    Next r

    ws.Cells(lastR + 1, 1).Value = keyText

    ws.Cells(lastR + 1, 2).Value = valueText

    ws.Cells(lastR + 1, 3).Value = descText

    ws.Columns("A:C").AutoFit

End Sub

Private Sub CopyTableToCommon(ByVal wb As Workbook, ByVal srcSheetName As String, ByVal dstSheetName As String)

    Dim src As Worksheet, dst As Worksheet, lr As Long, lc As Long

    Set src = Ws(srcSheetName)

    Set dst = ResetCommonSheet(wb, dstSheetName)

    lr = LastRow(src, 1)

    lc = LastCol(src, 1)

    dst.Range(dst.Cells(1, 1), dst.Cells(lr, lc)).Value = src.Range(src.Cells(1, 1), src.Cells(lr, lc)).Value

    FormatCommonHeader dst

    dst.Columns.AutoFit

End Sub

Private Function ResetCommonSheet(ByVal wb As Workbook, ByVal sheetName As String) As Worksheet

    Dim sh As Worksheet, lo As ListObject

    If SheetExists(sheetName, wb) Then

        Set sh = wb.Worksheets(sheetName)

    Else

        Set sh = wb.Worksheets.Add(After:=wb.Worksheets(wb.Worksheets.Count))

        sh.Name = sheetName

    End If

    On Error Resume Next

    sh.Unprotect

    If sh.AutoFilterMode Then sh.AutoFilterMode = False

    For Each lo In sh.ListObjects

        lo.Unlist

    Next lo

    sh.Cells.Clear

    On Error GoTo 0

    Set ResetCommonSheet = sh

End Function

Private Sub FormatCommonHeader(ByVal sh As Worksheet)

    With sh.Rows(1)

        .Interior.Color = C_NAVY

        .Font.Color = vbWhite

        .Font.Bold = True

    End With

    sh.Cells.Font.Name = "Meiryo UI"

    sh.Cells.Font.Size = 10

End Sub

Public Sub ExportVoucherWorkbooks()

    On Error GoTo EH

    EnsureVoucherBuildFreshForExport "�ŏI�o��"

    AppBegin "�`�[�˗��\���o�͒�..."

    If IsSettingYes("�ŏI�o�͑O�`�F�b�N", True) Then

        RunVoucherCheck

        If HasVoucherCheckError() Then Err.Raise vbObjectError + 502, , "�����`�F�b�N�ɃG���[������܂��BC_�`�F�b�N���m�F���Ă��������B"

    End If

    Dim outFolder As String

    outFolder = OutputPath()

    If Not ConfirmVoucherOverwrite(outFolder) Then

        AppEnd ""

        Exit Sub

    End If

    ValidateVoucherExportReady

    ExportRequestBook outFolder & Application.PathSeparator & "11_�`�[�˗��\_�˗��p.xlsx"

    ExportControlBook outFolder & Application.PathSeparator & "12_�`�[�˗��\_�T���p.xlsx"

    If IsSettingYes("�˗���ʃZ�b�g�o��", True) Then ExportDestinationSetBooks outFolder

    AppEnd ""

    If IsSettingYes("�˗���ʃZ�b�g�o��", True) Then
        NotifyInfo "�`�[�˗��\���o�͂��܂����B11_�`�[�˗��\_�˗��p.xlsx / 12_�`�[�˗��\_�T���p.xlsx / 13_�`�[�˗��\_�˗���ʃZ�b�g"
    Else
        NotifyInfo "�`�[�˗��\���o�͂��܂����B11_�`�[�˗��\_�˗��p.xlsx / 12_�`�[�˗��\_�T���p.xlsx"
    End If

    Exit Sub

EH:

    Dim errNum As Long, errDesc As String, errSrc As String

    errNum = Err.Number: errDesc = Err.Description: errSrc = Err.Source

    On Error Resume Next

    AppEnd ""

    On Error GoTo 0

    RuntimeShowErrorValues "ExportVoucherWorkbooks", "�`�[�˗��\�o��", "�˗���ꗗ�ō쐬�Ώۂ����邩�A�o�̓t�@�C�����J���Ă��Ȃ����m�F���Ă��������B", outFolder, errNum, errDesc, errSrc

End Sub

Private Sub ExportRequestBook(ByVal filePath As String)

    Dim wb As Workbook, dest As Worksheet, dr As Long

    Set wb = Workbooks.Add(xlWBATWorksheet)

    Application.DisplayAlerts = False

    Do While wb.Worksheets.Count > 1

        wb.Worksheets(wb.Worksheets.Count).Delete

    Loop

    Application.DisplayAlerts = True

    Set dest = Ws(SH_W_DEST)

    For dr = 2 To LastRow(dest, DS_ID)

        If dest.Cells(dr, DS_TARGET).Value = "�쐬" Then

            Dim sh As Worksheet

            If wb.Worksheets.Count = 1 And wb.Worksheets(1).UsedRange.Count = 1 And wb.Worksheets(1).Range("A1").Value = "" Then

                Set sh = wb.Worksheets(1)

            Else

                Set sh = wb.Worksheets.Add(After:=wb.Worksheets(wb.Worksheets.Count))

            End If

            sh.Name = UniqueSheetName(wb, SafeSheetName(dest.Cells(dr, DS_BANK).Value & "_" & dest.Cells(dr, DS_SHOP).Value, "�˗�_"))

            RenderRequestSheetForDest wb, sh, dr

        End If

    Next dr

    If RuntimeCountVisibleWorkbookSheets(wb) = 0 Then Err.Raise vbObjectError + 8801, "ExportRequestBook", "�˗��p�u�b�N�ɏo�͑ΏۃV�[�g������܂���B"

    RuntimeSafeSaveAsXlsxAndClose wb, filePath, "ExportRequestBook", "�˗��p�u�b�N�ۑ�"

End Sub

Private Sub ExportControlBook(ByVal filePath As String)

    Dim wb As Workbook, dest As Worksheet, dr As Long

    Set wb = Workbooks.Add(xlWBATWorksheet)

    Set dest = Ws(SH_W_DEST)

    For dr = 2 To LastRow(dest, DS_ID)

        If dest.Cells(dr, DS_TARGET).Value = "�쐬" Then

            Dim sh As Worksheet

            If wb.Worksheets.Count = 1 And wb.Worksheets(1).UsedRange.Count = 1 And wb.Worksheets(1).Range("A1").Value = "" Then

                Set sh = wb.Worksheets(1)

            Else

                Set sh = wb.Worksheets.Add(After:=wb.Worksheets(wb.Worksheets.Count))

            End If

            sh.Name = UniqueSheetName(wb, SafeSheetName(dest.Cells(dr, DS_BANK).Value & "_" & dest.Cells(dr, DS_SHOP).Value, "�T��_"))

            RenderControlSheetForDest wb, sh, dr

        End If

    Next dr

    If RuntimeCountVisibleWorkbookSheets(wb) = 0 Then Err.Raise vbObjectError + 8802, "ExportControlBook", "�T���p�u�b�N�ɏo�͑ΏۃV�[�g������܂���B"

    RuntimeSafeSaveAsXlsxAndClose wb, filePath, "ExportControlBook", "�T���p�u�b�N�ۑ�"

End Sub

Private Sub ExportDestinationSetBooks(ByVal outFolder As String)

    Dim setFolder As String

    setFolder = RuntimeCombinePath(outFolder, "13_�`�[�˗��\_�˗���ʃZ�b�g")

    RuntimeEnsureFolderExists setFolder, "ExportDestinationSetBooks"

    Dim dest As Worksheet, dr As Long, fileName As String, wb As Workbook, req As Worksheet, ctl As Worksheet

    Set dest = Ws(SH_W_DEST)

    For dr = 2 To LastRow(dest, DS_ID)

        If dest.Cells(dr, DS_TARGET).Value = "�쐬" Then

            Set wb = Workbooks.Add(xlWBATWorksheet)

            Set req = wb.Worksheets(1)

            req.Name = "�˗��p"

            RenderRequestSheetForDest wb, req, dr

            Set ctl = wb.Worksheets.Add(After:=req)

            ctl.Name = "�T���p"

            RenderControlSheetForDest wb, ctl, dr

            fileName = "�`�[�˗��\_" & SafeFileName(dest.Cells(dr, DS_ID).Value & "_" & dest.Cells(dr, DS_BANK).Value & "_" & dest.Cells(dr, DS_SHOP).Value) & ".xlsx"

            RuntimeSafeSaveAsXlsxAndClose wb, setFolder & Application.PathSeparator & fileName, _
                    "ExportDestinationSetBooks", "�˗���ʃZ�b�g�ۑ�"

        End If

    Next dr

End Sub

Private Sub ValidateVoucherExportReady()

    Dim dest As Worksheet, dr As Long, targetCount As Long
    Dim reqDates As Worksheet, controls As Worksheet

    If Not SheetExists(SH_W_DEST) Then Err.Raise vbObjectError + 8830, "ValidateVoucherExportReady", "W_�˗��� �V�[�g������܂���B��ɋ��ʃf�[�^�Ǎ��ƈ˗��\�쐬�����s���Ă��������B"

    If Not SheetExists(SH_W_DATES) Then Err.Raise vbObjectError + 8831, "ValidateVoucherExportReady", "W_�˗��� �V�[�g������܂���B��Ɉ˗��\�쐬�����s���Ă��������B"

    If Not SheetExists(SH_W_CONTROL) Then Err.Raise vbObjectError + 8832, "ValidateVoucherExportReady", "W_�T������ �V�[�g������܂���B��Ɉ˗��\�쐬�����s���Ă��������B"

    Set dest = Ws(SH_W_DEST)
    Set reqDates = Ws(SH_W_DATES)
    Set controls = Ws(SH_W_CONTROL)

    For dr = 2 To LastRow(dest, DS_ID)

        If CStr(dest.Cells(dr, DS_TARGET).Value) = "�쐬" Then targetCount = targetCount + 1

    Next dr

    If targetCount = 0 Then

        Err.Raise vbObjectError + 8833, "ValidateVoucherExportReady", "�˗���ꗗ�Ɂw�쐬�x�Ώۂ�����܂���B�˗��\�쐬�����s���邩�A�˗���ꗗ�̑Ώۗ���m�F���Ă��������B"

    End If

    If LastRow(reqDates, RD_ID) <= 1 Then

        Err.Raise vbObjectError + 8834, "ValidateVoucherExportReady", "�˗��p�̓��t�f�[�^������܂���B�˗��\�쐬�����s���Ă��������B"

    End If

    If LastRow(controls, CD_DEST_ID) <= 1 Then

        Err.Raise vbObjectError + 8835, "ValidateVoucherExportReady", "�T���p�̍������ׂ�����܂���B�˗��\�쐬�����s���Ă��������B"

    End If

End Sub

Private Function UniqueSheetName(ByVal wb As Workbook, ByVal baseName As String) As String

    Dim s As String, i As Long

    s = Left$(baseName, 31)

    i = 1

    Do While SheetExists(s, wb)

        i = i + 1

        s = Left$(baseName, 28) & "_" & i

    Loop

    UniqueSheetName = s

End Function

Private Sub RenderRequestSheetForDest(ByVal wb As Workbook, ByVal sh As Worksheet, ByVal destRow As Long)

    Dim tmp As Worksheet, dates As Worksheet, dest As Worksheet

    Set dates = Ws(SH_W_DATES)

    Set dest = Ws(SH_W_DEST)

    sh.Cells.Font.Name = "Meiryo UI"

    sh.Cells.Font.Size = 10

    sh.Columns("A").ColumnWidth = 2

    sh.Columns("B").ColumnWidth = 18

    sh.Columns("C").ColumnWidth = 30

    sh.Columns("D:F").ColumnWidth = 3

    Dim rowTop As Long, dummy As Long

    rowTop = 2

    dummy = RenderRequestSectionExternal(sh, dates, dest, destRow, rowTop)

    PolishExportRequestSheet sh, dummy

End Sub

Private Sub PolishExportRequestSheet(ByVal sh As Worksheet, ByVal lastRowTop As Long)

    Dim lastR As Long

    If sh Is Nothing Then Exit Sub

    lastR = Application.Max(5, lastRowTop - 1)

    On Error Resume Next

    ThemeApplyPrintTable sh.Range("B2:C" & CStr(lastR)), 0

    ThemeCapRowHeights sh.Range("B2:C" & CStr(lastR)), 18, 36

    ThemeApplyMonochromePrint sh, sh.Range("B2:C" & CStr(lastR)).Address, False, "", 1, 0

    On Error GoTo 0

End Sub

Private Sub PolishExportControlSheet(ByVal sh As Worksheet, ByVal lastR As Long)

    If sh Is Nothing Then Exit Sub

    If lastR < 6 Then lastR = 6

    On Error Resume Next

    ThemeApplyPrintTable sh.Range("B6:J" & CStr(lastR)), 1

    ThemeCapRowHeights sh.Range("B6:J" & CStr(lastR)), 18, 72

    ThemeApplyMonochromePrint sh, sh.Range("B1:J" & CStr(lastR)).Address, True, "$6:$6", 1, 0

    On Error GoTo 0

End Sub

Private Function RenderRequestSectionExternal(ByVal sh As Worksheet, _
        ByVal dates As Worksheet, _
        ByVal dest As Worksheet, _
        ByVal destRow As Long, _
        ByVal rowTop As Long) As Long

    Dim allRows As Collection, r As Long

    Set allRows = New Collection

    For r = 2 To LastRow(dates, RD_ID)

        If dates.Cells(r, RD_DEST_ID).Value = dest.Cells(destRow, DS_ID).Value Then

            If IsDate(dates.Cells(r, RD_REQUEST_DATE).Value) Then allRows.Add r

        End If

    Next r

    Dim perPage As Long, idx As Long, startIdx As Long, endIdx As Long, pageNo As Long

    Dim pageRow As Long, srcRow As Long, reqDate As Date

    perPage = SettingLong("�˗��p1�y�[�W�ő����", 60)

    If perPage <= 0 Or perPage > 60 Then perPage = 60

    idx = 1

    pageNo = 1

    Do While idx <= allRows.Count Or (allRows.Count = 0 And pageNo = 1)

        startIdx = idx

        endIdx = WorksheetFunction.Min(idx + perPage - 1, allRows.Count)

        ' �˗��p�͋�s���E�x�X���E���t�����Ɍ��肷��B���������͍T���p�ɂ����o���B

        sh.Cells(rowTop, 2).Value = "��s��"

        sh.Cells(rowTop, 3).Value = dest.Cells(destRow, DS_BANK).Value

        sh.Cells(rowTop + 1, 2).Value = "�x�X��"

        sh.Cells(rowTop + 1, 3).Value = dest.Cells(destRow, DS_SHOP).Value

        sh.Range(sh.Cells(rowTop, 2), sh.Cells(rowTop + 1, 2)).Interior.Color = C_LIGHT_GRAY

        sh.Range(sh.Cells(rowTop, 2), sh.Cells(rowTop + 1, 3)).Font.Bold = True

        ThemeApplyCompleteBordersColor sh.Range(sh.Cells(rowTop, 2), sh.Cells(rowTop + 1, 3)), C_BORDER

        sh.Cells(rowTop + 3, 2).Value = "���t"

        With sh.Cells(rowTop + 3, 2)

            .Interior.Color = C_NAVY

            .Font.Color = vbWhite

            .Font.Bold = True

            .HorizontalAlignment = xlCenter

        End With

        pageRow = rowTop + 4

        If allRows.Count = 0 Then

            pageRow = pageRow + 1

        Else

            For idx = startIdx To endIdx

                srcRow = CLng(allRows(idx))

                reqDate = CDate(dates.Cells(srcRow, RD_REQUEST_DATE).Value)

                sh.Cells(pageRow, 2).Value = FormatJPDate(reqDate, False)

                sh.Cells(pageRow, 2).HorizontalAlignment = xlCenter

                If pageRow Mod 2 = 0 Then sh.Cells(pageRow, 2).Interior.Color = ThemeColor("canvas")

                pageRow = pageRow + 1

            Next idx

        End If

        ThemeApplyCompleteBordersColor sh.Range(sh.Cells(rowTop + 3, 2), sh.Cells(pageRow - 1, 2)), C_BORDER

        rowTop = pageRow + 2

        If idx > allRows.Count Then Exit Do

        sh.HPageBreaks.Add Before:=sh.Cells(rowTop, 1)

        pageNo = pageNo + 1

    Loop

    RenderRequestSectionExternal = rowTop

End Function

Private Sub RenderControlSheetForDest(ByVal wb As Workbook, ByVal sh As Worksheet, ByVal destRow As Long)

    Dim src As Worksheet, dest As Worksheet, r As Long, outR As Long, curDate As Variant, d As Date, dateChanged As Boolean

    Set src = Ws(SH_W_CONTROL)

    Set dest = Ws(SH_W_DEST)

    sh.Cells.Font.Name = "Meiryo UI"

    sh.Cells.Font.Size = 9

    sh.Columns("A").ColumnWidth = 2

    sh.Columns("B").ColumnWidth = 14

    sh.Columns("C").ColumnWidth = 16

    sh.Columns("D").ColumnWidth = 10

    sh.Columns("E").ColumnWidth = 12

    sh.Columns("F").ColumnWidth = 12

    sh.Columns("G").ColumnWidth = 18

    sh.Columns("H").ColumnWidth = 16

    sh.Columns("I").ColumnWidth = 42

    sh.Columns("J").ColumnWidth = 14

    sh.Range("B1:J2").Merge

    sh.Range("B1").Value = "�`�[�˗��T���@" & dest.Cells(destRow, DS_BANK).Value & "�@" & dest.Cells(destRow, DS_SHOP).Value

    sh.Range("B1").Interior.Color = C_DARK

    sh.Range("B1").Font.Color = vbWhite

    sh.Range("B1").Font.Bold = True

    sh.Range("B1").Font.Size = 14

    sh.Range("B1").HorizontalAlignment = xlCenter

    outR = 4

    curDate = Empty

    For r = 2 To LastRow(src, CD_DEST_ID)

        If src.Cells(r, CD_DEST_ID).Value = dest.Cells(destRow, DS_ID).Value Then

            If IsDate(src.Cells(r, CD_TX_DATE).Value) Then

                d = CDate(src.Cells(r, CD_TX_DATE).Value)

                dateChanged = False
                If IsEmpty(curDate) Then
                    dateChanged = True
                ElseIf CLng(curDate) <> CLng(d) Then
                    dateChanged = True
                End If
                If dateChanged Then

                    If Not IsEmpty(curDate) Then outR = outR + 1

                    curDate = d

                    sh.Range(sh.Cells(outR, 2), sh.Cells(outR, 10)).Merge

                    sh.Cells(outR, 2).Value = "�˗��Ώۓ��i��������j�F" & FormatJPDate(d, True) & "�@�Ώێ�� " & src.Cells(r, CD_DATE_COUNT).Value & "��"

                    sh.Cells(outR, 2).Interior.Color = C_NAVY

                    sh.Cells(outR, 2).Font.Color = vbWhite

                    sh.Cells(outR, 2).Font.Bold = True

                    outR = outR + 1

                    sh.Range(sh.Cells(outR, 2), sh.Cells(outR, 10)).Value = Array("�敪", "�l��", "����", "�o��", "����", "���͌��ID", "���ID", "�E�v�E����", "�m�F")

                    sh.Range(sh.Cells(outR, 2), sh.Cells(outR, 10)).Interior.Color = ThemeColor("section")

                    sh.Range(sh.Cells(outR, 2), sh.Cells(outR, 10)).Font.Bold = True

                    outR = outR + 1

                End If

            End If

            sh.Cells(outR, 2).Value = src.Cells(r, CD_KIND).Value

            sh.Cells(outR, 3).Value = src.Cells(r, CD_PERSON).Value

            sh.Cells(outR, 4).Value = src.Cells(r, CD_RELATION).Value

            sh.Cells(outR, 5).Value = src.Cells(r, CD_OUT).Value

            sh.Cells(outR, 6).Value = src.Cells(r, CD_IN).Value

            sh.Cells(outR, 7).Value = src.Cells(r, CD_ANALYSIS_ID).Value

            sh.Cells(outR, 8).Value = src.Cells(r, CD_TX_ID).Value

            If IsSettingYes("�T���p�E�v�\��", True) Then sh.Cells(outR, 9).Value = JoinNonEmpty(src.Cells(r, CD_SUMMARY).Value, src.Cells(r, CD_MEMO).Value, " / ")

            sh.Cells(outR, 10).Value = "�� �擾�m�F"

            If outR Mod 2 = 0 Then sh.Range(sh.Cells(outR, 2), sh.Cells(outR, 10)).Interior.Color = ThemeColor("canvas")

            outR = outR + 1

        End If

    Next r

    If outR = 4 Then sh.Cells(4, 2).Value = "�Ώۖ��ׂȂ�"

    With sh.Range("B4:J" & Application.Max(outR - 1, 4))

        .WrapText = True

        .VerticalAlignment = xlTop

    End With

    ThemeApplyCompleteBordersColor sh.Range("B4:J" & Application.Max(outR - 1, 4)), C_BORDER

    sh.Columns("E:F").NumberFormat = "#,##0"

    PolishExportControlSheet sh, Application.Max(outR - 1, 4)

End Sub

Private Function ConfirmVoucherOverwrite(ByVal outFolder As String) As Boolean

    Dim msg As String, p1 As String, p2 As String

    p1 = outFolder & Application.PathSeparator & "11_�`�[�˗��\_�˗��p.xlsx"

    p2 = outFolder & Application.PathSeparator & "12_�`�[�˗��\_�T���p.xlsx"

    If Len(Dir$(p1)) > 0 Then msg = msg & "�E" & p1 & vbCrLf

    If Len(Dir$(p2)) > 0 Then msg = msg & "�E" & p2 & vbCrLf

    If Len(msg) = 0 Then

        ConfirmVoucherOverwrite = True

    Else

        ConfirmVoucherOverwrite = (MsgBox("�ȉ��̓`�[�˗��\�͊��ɑ��݂��܂��B�o�b�N�A�b�v���쐬���ď㏑�����܂����H" & vbCrLf & vbCrLf & msg, vbQuestion + vbYesNo, "�㏑���m�F") = vbYes)

    End If

End Function

Private Sub PrepareOutputPathWithBackup(ByVal filePath As String)

    If Len(filePath) = 0 Then Exit Sub

    If Len(Dir$(filePath)) = 0 Then Exit Sub

    RuntimeBackupAndRemoveExistingFile filePath, "PrepareOutputPathWithBackup"

    WriteLog "�����o�͂�ޔ�: " & filePath

End Sub

Private Sub BackupCommonDataBeforeUpdate(ByVal filePath As String)

    Dim backupPath As String

    If Len(filePath) = 0 Then Exit Sub

    If Len(Dir$(filePath)) = 0 Then Exit Sub

    backupPath = RuntimeUniqueBackupPath(filePath)

    FileCopy filePath, backupPath

    WriteLog "���ʃf�[�^�X�V�O�o�b�N�A�b�v: " & backupPath

End Sub


Attribute VB_Name = "modVoucherViewGuard"
Option Explicit

Public Sub AuditVoucherSheetVisibility(Optional ByVal showCheck As Boolean = True)
    Dim wsC As Worksheet, sh As Worksheet, r As Long, expectedText As String
    On Error GoTo EH
    Set wsC = GetOrCreateSheet(SH_CHECK)
    wsC.Cells.Clear
    wsC.Range("A1:E1").Value = Array("�敪", "�V�[�g", "���ݏ��", "�ʏ펞�̈���", "����")
    ThemeApplyHeader wsC.Range("A1:E1")
    r = 2
    For Each sh In ThisWorkbook.Worksheets
        expectedText = ExpectedVoucherSheetVisibility(sh.Name)
        wsC.Cells(r, 1).Value = IIf(sh.Visible = xlSheetVisible, "�\��", "��\��")
        wsC.Cells(r, 2).Value = sh.Name
        wsC.Cells(r, 3).Value = VoucherVisibleStateText(sh.Visible)
        wsC.Cells(r, 4).Value = expectedText
        If sh.Visible = xlSheetVisible And expectedText = "����/��\��" Then wsC.Cells(r, 5).Value = "�v��\��" Else wsC.Cells(r, 5).Value = "OK"
        r = r + 1
    Next sh
    wsC.Columns("A:E").AutoFit
    If showCheck Then
        HideUnusedVoucherSheets True, False, False, True
        wsC.Activate
    End If
    Exit Sub
EH:
    QuietWarn "04�\���č��Ɏ��s���܂���: " & Err.Description, True, "�\���č�"
End Sub

Private Function ExpectedVoucherSheetVisibility(ByVal sheetName As String) As String
    If sheetName = SH_MAIN Then
        ExpectedVoucherSheetVisibility = "�ʏ펞�\��"
    ElseIf sheetName = SH_SETTINGS Or sheetName = SH_CHECK Then
        ExpectedVoucherSheetVisibility = "�K�v���̂ݕ\��"
    ElseIf IsVoucherSetSheetName(sheetName) Then
        ExpectedVoucherSheetVisibility = "�쐬��\��"
    Else
        ExpectedVoucherSheetVisibility = "����/��\��"
    End If
End Function

Private Function VoucherVisibleStateText(ByVal v As XlSheetVisibility) As String
    Select Case v
        Case xlSheetVisible: VoucherVisibleStateText = "Visible"
        Case xlSheetHidden: VoucherVisibleStateText = "Hidden"
        Case xlSheetVeryHidden: VoucherVisibleStateText = "VeryHidden"
        Case Else: VoucherVisibleStateText = CStr(v)
    End Select
End Function

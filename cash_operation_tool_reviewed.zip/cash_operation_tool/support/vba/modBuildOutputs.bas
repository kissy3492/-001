﻿Attribute VB_Name = "modBuildOutputs"
Option Explicit

Private Const MAX_PRACTICAL_OUTPUT_ROWS As Long = 200000
Private Const OUTPUT_VERIFY_CHUNK_ROWS As Long = 2000
Private Const OUTPUT_CAPACITY_LONG_MAX As Double = 2147483647#
Private Const OUTPUT_ARRAY_EQUIVALENT_COLUMNS As Long = 16
Private Const OUTPUT_ATOMIC_SNAPSHOT_COPIES As Long = 3
Private Const OUTPUT_ANALYSIS_SNAPSHOT_SETS As Long = 2

Private Type GeneratedOutputSnapshot
    Captured As Boolean
    HeaderData As Variant
    Data As Variant
    LastRow As Long
    LastColumn As Long
    UsedLastColumn As Long
    MaximumDataRows As Long
    LabelText As String
    Visibility As Long
    WasProtected As Boolean
    EntryActiveSheetName As String
    EntryActiveCellAddress As String
    SelectionAddress As String
    WasActive As Boolean
    WindowStateCaptured As Boolean
    FreezePanes As Boolean
    SplitRow As Long
    SplitColumn As Long
    ScrollRow As Long
    ScrollColumn As Long
    Zoom As Long
    WorkbookWasSaved As Boolean
End Type

Private Function SmallerOutputWorkRows(ByVal firstValue As Double, _
                                       ByVal secondValue As Double) As Double
    If firstValue < secondValue Then
        SmallerOutputWorkRows = firstValue
    Else
        SmallerOutputWorkRows = secondValue
    End If
End Function

Private Function LargerOutputWorkRows(ByVal firstValue As Double, _
                                      ByVal secondValue As Double) As Double
    If firstValue > secondValue Then
        LargerOutputWorkRows = firstValue
    Else
        LargerOutputWorkRows = secondValue
    End If
End Function

Private Sub RequireNonNegativeOutputWorkRows(ByVal firstValue As Double, _
                                             ByVal secondValue As Double, _
                                             Optional ByVal thirdValue As Double = 0#)
    If firstValue < 0# Or secondValue < 0# Or thirdValue < 0# Then _
        Err.Raise vbObjectError + 4232, "RequireNonNegativeOutputWorkRows", _
                  "帳票生成の容量計画に負数が含まれています。"
End Sub

Private Function OutputArrayWorkRows(ByVal rowCount As Double, _
                                     ByVal columnCount As Long) As Double
    Dim widthUnits As Long
    If rowCount < 0# Or columnCount < 1 Then _
        Err.Raise vbObjectError + 4232, "OutputArrayWorkRows", _
                  "帳票生成の配列容量計画が不正です。"
    '共有容量閾値の1行は、最大16列のVariant配列1行に相当する。
    widthUnits = (columnCount + OUTPUT_ARRAY_EQUIVALENT_COLUMNS - 1) \ OUTPUT_ARRAY_EQUIVALENT_COLUMNS
    OutputArrayWorkRows = rowCount * CDbl(widthUnits)
End Function

Private Function GeneratedOutputSnapshotWorkRows(ByVal rowCount As Double, _
                                                 ByVal columnCount As Long) As Double
    If rowCount < 0# Or columnCount < 1 Then _
        Err.Raise vbObjectError + 4232, "GeneratedOutputSnapshotWorkRows", _
                  "帳票退避の容量計画が不正です。"
    '退避本体、退避時の厳密読戻し、復元時の厳密読戻しを同時保持し得る上界。
    GeneratedOutputSnapshotWorkRows = _
        CDbl(OUTPUT_ATOMIC_SNAPSHOT_COPIES) * _
        OutputArrayWorkRows(rowCount, columnCount)
End Function

Private Function CashOutputCapacityRows( _
        ByVal transactionRows As Double, ByVal workCashDataRows As Double, _
        ByVal convertedDataRows As Double, ByVal viewDataRows As Double) As Double
    Dim plannedRows As Double
    RequireNonNegativeOutputWorkRows transactionRows, workCashDataRows, _
                                     convertedDataRows
    If viewDataRows < 0# Then _
        Err.Raise vbObjectError + 4232, "CashOutputCapacityRows", _
                  "資金操作表の容量計画に負数が含まれています。"
    plannedRows = transactionRows + 2#
    plannedRows = LargerOutputWorkRows(plannedRows, 1# + workCashDataRows)
    plannedRows = LargerOutputWorkRows(plannedRows, 1# + convertedDataRows)
    plannedRows = LargerOutputWorkRows(plannedRows, 1# + viewDataRows)
    CashOutputCapacityRows = plannedRows
End Function

Private Function InternalStoreIntegrityWorkRows( _
        ByVal accountRows As Double, ByVal transactionRows As Double, _
        ByVal balanceRows As Double) As Double
    Dim oneCopyRows As Double
    '通常帳票後のauthoritativeOnly検査が読むのはW_口座・W_取引・W_残高だけ。
    '人物候補はこの経路で配列化しないため、無関係な候補件数を容量へ加算しない。
    RequireNonNegativeOutputWorkRows accountRows, transactionRows, balanceRows
    oneCopyRows = _
        OutputArrayWorkRows(accountRows, ACC_COL_TRANSFER_ID) + _
        OutputArrayWorkRows(transactionRows, WORK_TX_COL_PERSON_ID) + _
        OutputArrayWorkRows(balanceRows, WORK_BAL_COL_PERSON_ID)
    '配列本体、辞書投入中の保持、厳密読戻しを含む3copy相当の保守的上界。
    InternalStoreIntegrityWorkRows = _
        CDbl(OUTPUT_ATOMIC_SNAPSHOT_COPIES) * oneCopyRows
End Function

Private Function CashOperationBuildWorkRows(ByVal transactionRows As Double, _
                                            ByVal plannedCashRows As Double) As Double
    Dim verifyRows As Double
    RequireNonNegativeOutputWorkRows transactionRows, plannedCashRows
    verifyRows = SmallerOutputWorkRows(plannedCashRows, CDbl(OUTPUT_VERIFY_CHUNK_ROWS))
    '21列原本、17列出力、並べ替え用5配列、17列検証チャンクの保守的上界。
    CashOperationBuildWorkRows = _
        OutputArrayWorkRows(transactionRows, WORK_TX_COL_PERSON_ID) + _
        OutputArrayWorkRows(plannedCashRows, OUT_COL_INPUT_ORDER) + _
        5# * plannedCashRows + _
        OutputArrayWorkRows(verifyRows, OUT_COL_INPUT_ORDER) + _
        GeneratedOutputSnapshotWorkRows(plannedCashRows, 21) + _
        GeneratedOutputSnapshotWorkRows(plannedCashRows, CASH_VIEW_INTERNAL_LAST_COL) + _
        GeneratedOutputSnapshotWorkRows(9#, CASH_VIEW_INTERNAL_LAST_COL)
End Function

Private Function BalanceTransitionBuildWorkRows(ByVal accountRows As Double, _
                                                ByVal balanceRows As Double, _
                                                ByVal transactionRows As Double, _
                                                ByVal plannedOutputRows As Double) As Double
    Dim verifyRows As Double
    Dim maximumDerivedRows As Double
    RequireNonNegativeOutputWorkRows accountRows, balanceRows, transactionRows
    If plannedOutputRows < 0# Then _
        Err.Raise vbObjectError + 4232, "BalanceTransitionBuildWorkRows", _
                  "残高推移表の出力容量計画に負数が含まれています。"
    verifyRows = SmallerOutputWorkRows(plannedOutputRows, CDbl(OUTPUT_VERIFY_CHUNK_ROWS))
    maximumDerivedRows = accountRows * CDbl(BAL_MAX_LABELS)
    '年末派生は元21列配列と同時に、日別group、日順、口座順、winner候補を保持する。
    'nested Variant候補を含むため、取引1件あたり4行相当を保守的に追加する。
    BalanceTransitionBuildWorkRows = _
        OutputArrayWorkRows(accountRows, ACC_COL_TRANSFER_ID) + _
        OutputArrayWorkRows(balanceRows, WORK_BAL_COL_PERSON_ID) + _
        OutputArrayWorkRows(transactionRows, WORK_TX_COL_PERSON_ID) + _
        4# * transactionRows + _
        OutputArrayWorkRows(maximumDerivedRows, DERIVED_YEAR_END_LAST_COL) + _
        OutputArrayWorkRows(plannedOutputRows, 7 + BAL_MAX_LABELS) + _
        OutputArrayWorkRows(verifyRows, 7 + BAL_MAX_LABELS) + _
        GeneratedOutputSnapshotWorkRows(plannedOutputRows, 7 + BAL_MAX_LABELS)
End Function

Private Function BalanceReconciliationBuildWorkRows( _
        ByVal accountRows As Double, ByVal transactionRows As Double, _
        ByVal balanceRows As Double, ByVal existingOutputRows As Double) As Double
    '残高検算coreと同じ公開estimatorを唯一の容量正本にする。
    BalanceReconciliationBuildWorkRows = _
        EstimateBalanceReconciliationWorkRows( _
            accountRows, transactionRows, balanceRows, existingOutputRows)
End Function

Private Function TransactionAnalysisBuildWorkRows(ByVal transactionRows As Double, _
                                                  ByVal existingAnalysisRows As Double) As Double
    Dim verifyRows As Double
    RequireNonNegativeOutputWorkRows transactionRows, existingAnalysisRows
    verifyRows = SmallerOutputWorkRows(transactionRows, CDbl(OUTPUT_VERIFY_CHUNK_ROWS))
    '21列原本、6本の分類行配列、入金額・並べ替え配列、既存判断、最大34列バッファ。
    TransactionAnalysisBuildWorkRows = _
        OutputArrayWorkRows(transactionRows, WORK_TX_COL_PERSON_ID) + _
        8# * transactionRows + existingAnalysisRows + _
        OutputArrayWorkRows(verifyRows, SHIFT_ANALYSIS_LAST_COL)
End Function

Private Function ShopConversionBuildWorkRows(ByVal existingTargetRows As Double, _
                                             ByVal plannedCashRows As Double) As Double
    Dim verifyRows As Double
    RequireNonNegativeOutputWorkRows existingTargetRows, plannedCashRows
    verifyRows = SmallerOutputWorkRows(plannedCashRows, CDbl(OUTPUT_VERIFY_CHUNK_ROWS))
    '更新前一覧・変換辞書用一覧に加え、確認状況更新中の8列再読込と1列状態配列、
    '旧21列/新17列出力、変換状態配列、書式処理の行種別・摘要配列、
    '復元検証チャンクを同時保持する上界。
    ShopConversionBuildWorkRows = _
        3# * OutputArrayWorkRows(existingTargetRows, SHOP_TGT_LAST_COL) + _
        existingTargetRows + _
        2# * OutputArrayWorkRows(plannedCashRows, OUT_COL_INPUT_ORDER) + _
        3# * plannedCashRows + _
        OutputArrayWorkRows(verifyRows, OUT_COL_INPUT_ORDER)
End Function

Private Function FinalExportBuildWorkRows(ByVal plannedCashRows As Double, _
                                          ByVal plannedBalanceRows As Double) As Double
    Dim cashWork As Double, balanceWork As Double
    Dim cashVerifyRows As Double, balanceVerifyRows As Double
    RequireNonNegativeOutputWorkRows plannedCashRows, plannedBalanceRows
    cashVerifyRows = SmallerOutputWorkRows(plannedCashRows, CDbl(OUTPUT_VERIFY_CHUNK_ROWS))
    balanceVerifyRows = SmallerOutputWorkRows(plannedBalanceRows, CDbl(OUTPUT_VERIFY_CHUNK_ROWS))
    'シート複製、期待値配列、保存後の分割読戻しを16列相当行へ換算する。
    cashWork = 2# * OutputArrayWorkRows(plannedCashRows, 13) + _
               OutputArrayWorkRows(cashVerifyRows, 13)
    balanceWork = 2# * OutputArrayWorkRows(plannedBalanceRows, _
                                          7 + BAL_MAX_LABELS) + _
                  OutputArrayWorkRows(balanceVerifyRows, 7 + BAL_MAX_LABELS)
    FinalExportBuildWorkRows = LargerOutputWorkRows(cashWork, balanceWork)
End Function

Private Function OutputSheetDataRows(ByVal sheetName As String, _
                                     ByVal lastColumn As Long) As Long
    Dim lastRow As Long
    If lastColumn < 1 Then _
        Err.Raise vbObjectError + 4232, "OutputSheetDataRows", _
                  "帳票生成の容量計画列が不正です。"
    If Not SheetExists(sheetName) Then Exit Function
    lastRow = LastDataRowInColumns(GetSheet(sheetName), 1, lastColumn)
    If lastRow >= 2 Then OutputSheetDataRows = lastRow - 1
End Function

Private Function ExistingAnalysisWorkRows() As Double
    ExistingAnalysisWorkRows = OutputArrayWorkRows( _
        CDbl(OutputSheetDataRows(SH_ANALYSIS_SHIFT, SHIFT_ANALYSIS_LAST_COL)), _
        SHIFT_ANALYSIS_LAST_COL)
    ExistingAnalysisWorkRows = ExistingAnalysisWorkRows + OutputArrayWorkRows( _
        CDbl(OutputSheetDataRows(SH_ANALYSIS_FLOW, FLOW_ANALYSIS_LAST_COL)), _
        FLOW_ANALYSIS_LAST_COL)
    ExistingAnalysisWorkRows = ExistingAnalysisWorkRows + OutputArrayWorkRows( _
        CDbl(OutputSheetDataRows(SH_ANALYSIS_UNKNOWN, UNKNOWN_ANALYSIS_LAST_COL)), _
        UNKNOWN_ANALYSIS_LAST_COL)
    ExistingAnalysisWorkRows = ExistingAnalysisWorkRows + OutputArrayWorkRows( _
        CDbl(OutputSheetDataRows(SH_ANALYSIS_RESULT, ANALYSIS_RESULT_LAST_COL)), _
        ANALYSIS_RESULT_LAST_COL)
    ExistingAnalysisWorkRows = ExistingAnalysisWorkRows + OutputArrayWorkRows( _
        CDbl(OutputSheetDataRows(SH_WORK_ANALYSIS_GROUP, ANALYSIS_GROUP_LAST_COL)), _
        ANALYSIS_GROUP_LAST_COL)
    ExistingAnalysisWorkRows = ExistingAnalysisWorkRows + OutputArrayWorkRows( _
        CDbl(OutputSheetDataRows(SH_WORK_ANALYSIS_REVIEW, _
                                 ANALYSIS_REVIEW_STORE_LAST_COL)), _
        ANALYSIS_REVIEW_STORE_LAST_COL)
    ExistingAnalysisWorkRows = ExistingAnalysisWorkRows + OutputArrayWorkRows( _
        CDbl(OutputSheetDataRows(SH_WORK_ANALYSIS_HISTORY, _
                                 ANALYSIS_HISTORY_STORE_LAST_COL)), _
        ANALYSIS_HISTORY_STORE_LAST_COL)
    ExistingAnalysisWorkRows = ExistingAnalysisWorkRows + OutputArrayWorkRows( _
        CDbl(OutputSheetDataRows(SH_WORK_MANUAL_FLOW, MANUAL_FLOW_STORE_LAST_COL)), _
        MANUAL_FLOW_STORE_LAST_COL)
    '手動候補は既存dataとロールバックsnapshotを同時保持するため、同じ幅をもう1本分加える。
    ExistingAnalysisWorkRows = ExistingAnalysisWorkRows + OutputArrayWorkRows( _
        CDbl(OutputSheetDataRows(SH_WORK_MANUAL_FLOW, MANUAL_FLOW_STORE_LAST_COL)), _
        MANUAL_FLOW_STORE_LAST_COL)
End Function

Private Function AllocationLedgerOuterSnapshotWorkRows( _
        ByVal storedDataRows As Double) As Double
    RequireNonNegativeOutputWorkRows storedDataRows, 0#
    AllocationLedgerOuterSnapshotWorkRows = _
        GeneratedOutputSnapshotWorkRows(1# + storedDataRows, 10)
End Function

Private Function AnalysisOuterSnapshotWorkRows( _
        ByVal plannedCashRows As Double) As Double
    Dim snapshotRows As Double
    RequireNonNegativeOutputWorkRows plannedCashRows, 0#
    '分析外側transactionの11表と配賦元帳O:Xは、各見出しを含む
    '開始時データを3copy相当で保持する。配賦元帳は同じW_分析判断台帳の
    'A:Mとは別配列ですべて退避するため、両方を個別に見積もる。
    snapshotRows = snapshotRows + GeneratedOutputSnapshotWorkRows( _
        1# + CDbl(OutputSheetDataRows(SH_ANALYSIS_SHIFT, SHIFT_ANALYSIS_LAST_COL)), _
        SHIFT_ANALYSIS_LAST_COL)
    snapshotRows = snapshotRows + GeneratedOutputSnapshotWorkRows( _
        1# + CDbl(OutputSheetDataRows(SH_ANALYSIS_FLOW, FLOW_ANALYSIS_LAST_COL)), _
        FLOW_ANALYSIS_LAST_COL)
    snapshotRows = snapshotRows + GeneratedOutputSnapshotWorkRows( _
        1# + CDbl(OutputSheetDataRows(SH_ANALYSIS_UNKNOWN, UNKNOWN_ANALYSIS_LAST_COL)), _
        UNKNOWN_ANALYSIS_LAST_COL)
    snapshotRows = snapshotRows + GeneratedOutputSnapshotWorkRows( _
        1# + CDbl(OutputSheetDataRows(SH_ANALYSIS_RESULT, ANALYSIS_RESULT_LAST_COL)), _
        ANALYSIS_RESULT_LAST_COL)
    snapshotRows = snapshotRows + GeneratedOutputSnapshotWorkRows( _
        1# + CDbl(OutputSheetDataRows(SH_WORK_ANALYSIS_GROUP, ANALYSIS_GROUP_LAST_COL)), _
        ANALYSIS_GROUP_LAST_COL)
    snapshotRows = snapshotRows + GeneratedOutputSnapshotWorkRows( _
        1# + CDbl(OutputSheetDataRows(SH_ANALYSIS_DETAIL, 12)), 12)
    snapshotRows = snapshotRows + GeneratedOutputSnapshotWorkRows( _
        1# + CDbl(OutputSheetDataRows(SH_WORK_ANALYSIS_REVIEW, _
                                     ANALYSIS_REVIEW_STORE_LAST_COL)), _
        ANALYSIS_REVIEW_STORE_LAST_COL)
    snapshotRows = snapshotRows + AllocationLedgerOuterSnapshotWorkRows( _
        CDbl(AllocationLedgerStoredRowCount()))
    snapshotRows = snapshotRows + GeneratedOutputSnapshotWorkRows( _
        1# + CDbl(OutputSheetDataRows(SH_WORK_ANALYSIS_HISTORY, _
                                     ANALYSIS_HISTORY_STORE_LAST_COL)), _
        ANALYSIS_HISTORY_STORE_LAST_COL)
    snapshotRows = snapshotRows + GeneratedOutputSnapshotWorkRows( _
        1# + CDbl(OutputSheetDataRows(SH_WORK_MANUAL_FLOW, _
                                     MANUAL_FLOW_STORE_LAST_COL)), _
        MANUAL_FLOW_STORE_LAST_COL)
    snapshotRows = snapshotRows + GeneratedOutputSnapshotWorkRows( _
        1# + CDbl(OutputSheetDataRows(SH_WORK_STATE, 2)), 2)
    snapshotRows = snapshotRows + GeneratedOutputSnapshotWorkRows( _
        1# + CDbl(OutputSheetDataRows(SH_CHECK, 4)), 4)
    snapshotRows = snapshotRows + GeneratedOutputSnapshotWorkRows( _
        plannedCashRows, CASH_VIEW_INTERNAL_LAST_COL)
    snapshotRows = snapshotRows + GeneratedOutputSnapshotWorkRows( _
        9#, CASH_VIEW_INTERNAL_LAST_COL)
    AnalysisOuterSnapshotWorkRows = snapshotRows
End Function

Private Function AnalysisOperationSnapshotPeakWorkRows( _
        ByVal oneSnapshotSetRows As Double) As Double
    If oneSnapshotSetRows < 0# Then _
        Err.Raise vbObjectError + 4232, _
                  "AnalysisOperationSnapshotPeakWorkRows", _
                  "分析の同時退避容量に負数があります。"
    AnalysisOperationSnapshotPeakWorkRows = _
        CDbl(OUTPUT_ANALYSIS_SNAPSHOT_SETS) * oneSnapshotSetRows
End Function

Private Function OutputOuterOperationSnapshotWorkRows( _
        ByVal includeCashOperation As Boolean, _
        ByVal includeBalanceTransition As Boolean, _
        ByVal includeBalanceReconciliation As Boolean, _
        ByVal includeTransactionAnalysis As Boolean, _
        ByVal includeShopConversion As Boolean, _
        ByVal cashRows As Double, ByVal balanceRows As Double, _
        ByVal reconciliationRows As Double, ByVal shopRows As Double) As Double
    Dim snapshotRows As Double
    RequireNonNegativeOutputWorkRows cashRows, balanceRows, reconciliationRows
    If shopRows < 0# Then _
        Err.Raise vbObjectError + 4232, _
                  "OutputOuterOperationSnapshotWorkRows", _
                  "一括帳票の退避容量に負数があります。"
    If includeCashOperation Then _
        snapshotRows = snapshotRows + _
            GeneratedOutputSnapshotWorkRows(cashRows, OUT_COL_INPUT_ORDER)
    If includeBalanceTransition Then _
        snapshotRows = snapshotRows + _
            GeneratedOutputSnapshotWorkRows(balanceRows, 7 + BAL_MAX_LABELS)
    If includeBalanceReconciliation Then _
        snapshotRows = snapshotRows + _
            GeneratedOutputSnapshotWorkRows( _
                reconciliationRows, BALANCE_RECONCILIATION_LAST_COL)
    If includeShopConversion Then
        snapshotRows = snapshotRows + _
            GeneratedOutputSnapshotWorkRows(shopRows, SHOP_TGT_LAST_COL)
        snapshotRows = snapshotRows + _
            GeneratedOutputSnapshotWorkRows(cashRows, OUT_COL_INPUT_ORDER)
    End If
    If includeTransactionAnalysis Then
        '一括更新中は外側transactionを保持したまま、取引分析coreも内側退避を作る。
        snapshotRows = snapshotRows + _
            AnalysisOperationSnapshotPeakWorkRows( _
                AnalysisOuterSnapshotWorkRows(cashRows))
    End If
    OutputOuterOperationSnapshotWorkRows = snapshotRows
End Function

Public Function RequireOutputBuildCapacity(ByVal operationName As String, _
                                           ByVal includeCashOperation As Boolean, _
                                           ByVal includeBalanceTransition As Boolean, _
                                           ByVal includeBalanceReconciliation As Boolean, _
                                           ByVal includeTransactionAnalysis As Boolean, _
                                           ByVal includeShopConversion As Boolean, _
                                           ByVal includeFinalExport As Boolean, _
                                           Optional ByVal includeOuterOperationSnapshots As Boolean = False) As Boolean
    Dim txRows As Long, accountRows As Long, balanceRows As Long
    Dim cashRows As Double, balanceOutputRows As Double, reconciliationRows As Double
    Dim existingReconciliationRows As Double
    Dim shopRows As Double
    Dim candidateRows As Double, workRows As Double, analysisRows As Double
    Dim integrityRows As Double
    Dim outerSnapshotRows As Double

    txRows = OutputSheetDataRows(SH_WORK_TX, WORK_TX_COL_PERSON_ID)
    accountRows = OutputSheetDataRows(SH_WORK_ACCOUNT, ACC_COL_TRANSFER_ID)
    balanceRows = OutputSheetDataRows(SH_WORK_BAL, WORK_BAL_COL_PERSON_ID)
    '資金操作は最大1件の相続開始日行とヘッダーを含め、内部表・変換表・正式表示の
    'いずれかだけが旧版最大行を保持する場合も退避前に過小評価しない。
    cashRows = CashOutputCapacityRows( _
        CDbl(txRows), _
        CDbl(OutputSheetDataRows(SH_WORK_CASH, OUT_COL_INPUT_ORDER)), _
        CDbl(OutputSheetDataRows(SH_OUTPUT_TX_CONVERTED, OUT_COL_INPUT_ORDER)), _
        CDbl(OutputSheetDataRows(SH_OUTPUT_TX, CASH_VIEW_INTERNAL_LAST_COL)))

    balanceOutputRows = 1# + 7# * CDbl(accountRows)
    candidateRows = 1# + CDbl(OutputSheetDataRows(SH_OUTPUT_BAL, _
                                                  7 + BAL_MAX_LABELS))
    balanceOutputRows = LargerOutputWorkRows(balanceOutputRows, candidateRows)
    existingReconciliationRows = 1# + _
        CDbl(OutputSheetDataRows(SH_BALANCE_RECONCILIATION, _
                                 BALANCE_RECONCILIATION_LAST_COL))
    reconciliationRows = EstimateBalanceReconciliationOutputRows( _
                            CDbl(accountRows), CDbl(txRows), CDbl(balanceRows))
    reconciliationRows = LargerOutputWorkRows( _
                            reconciliationRows, existingReconciliationRows)
    '旧一覧snapshotは空一覧でもヘッダーと初期空行を保持する。
    shopRows = LargerOutputWorkRows(2#, 1# + _
        CDbl(OutputSheetDataRows(SH_SHOP_TARGET, SHOP_TGT_LAST_COL)))

    If includeCashOperation Then _
        workRows = LargerOutputWorkRows(workRows, _
            CashOperationBuildWorkRows(CDbl(txRows), cashRows))
    If includeBalanceTransition Then _
        workRows = LargerOutputWorkRows(workRows, _
            BalanceTransitionBuildWorkRows(CDbl(accountRows), CDbl(balanceRows), _
                                           CDbl(txRows), _
                                           balanceOutputRows))
    If includeBalanceReconciliation Then _
        workRows = LargerOutputWorkRows(workRows, _
            BalanceReconciliationBuildWorkRows( _
                CDbl(accountRows), CDbl(txRows), CDbl(balanceRows), _
                existingReconciliationRows))
    If includeTransactionAnalysis Then
        analysisRows = ExistingAnalysisWorkRows()
        workRows = LargerOutputWorkRows(workRows, _
            TransactionAnalysisBuildWorkRows(CDbl(txRows), analysisRows))
    End If
    If includeShopConversion Then _
        workRows = LargerOutputWorkRows(workRows, _
            ShopConversionBuildWorkRows(shopRows, cashRows))
    If includeFinalExport Then _
        workRows = LargerOutputWorkRows(workRows, _
            FinalExportBuildWorkRows(cashRows, balanceOutputRows))

    integrityRows = InternalStoreIntegrityWorkRows( _
        CDbl(accountRows), CDbl(txRows), CDbl(balanceRows))
    workRows = LargerOutputWorkRows(workRows, integrityRows)

    If includeOuterOperationSnapshots Then
        outerSnapshotRows = OutputOuterOperationSnapshotWorkRows( _
            includeCashOperation, includeBalanceTransition, _
            includeBalanceReconciliation, includeTransactionAnalysis, _
            includeShopConversion, cashRows, balanceOutputRows, _
            reconciliationRows, shopRows)
        workRows = workRows + outerSnapshotRows
    End If

    If workRows > OUTPUT_CAPACITY_LONG_MAX Then _
        Err.Raise vbObjectError + 4233, "RequireOutputBuildCapacity", _
                  "帳票生成の安全容量をLong範囲で表現できません。"
    If Len(operationName) = 0 Then operationName = "帳票生成"
    RequireOutputBuildCapacity = ConfirmLargeArrayOperation( _
        CLng(workRows), operationName & "（関連保管・予定出力の事前安全検査）")
End Function


Private Sub CaptureGeneratedOutputSnapshot( _
        ByVal ws As Worksheet, ByVal lastColumn As Long, _
        ByVal maximumDataRows As Long, ByVal labelText As String, _
        ByRef snapshot As GeneratedOutputSnapshot)
    Dim headerRange As Range, formulaCell As Range
    Dim headerRows As Long, usedLastRow As Long
    If ws Is Nothing Or lastColumn < 1 Or maximumDataRows < 0 Then _
        Err.Raise vbObjectError + 4234, "CaptureGeneratedOutputSnapshot", _
                  labelText & "の退避条件が不正です。"

    snapshot.LastColumn = lastColumn
    snapshot.MaximumDataRows = maximumDataRows
    snapshot.LabelText = labelText
    snapshot.Visibility = CLng(ws.Visible)
    snapshot.WasProtected = ws.ProtectContents
    snapshot.WorkbookWasSaved = ThisWorkbook.Saved
    Set headerRange = ws.Range(ws.Cells(1, 1), ws.Cells(1, lastColumn))
    If Not TryFindFirstFormulaCell(headerRange, formulaCell) Then _
        Err.Raise vbObjectError + 4235, "CaptureGeneratedOutputSnapshot", _
                  labelText & "の見出し数式検査に失敗しました。"
    If Not formulaCell Is Nothing Then _
        Err.Raise vbObjectError + 4235, "CaptureGeneratedOutputSnapshot", _
                  labelText & "の見出しに数式があります。"
    snapshot.HeaderData = headerRange.Value2
    headerRows = 1
    If VariantMatrixContainsError(snapshot.HeaderData, headerRows, lastColumn) Or _
       Not RangeValue2MatchesMatrixStrict( _
               headerRange, snapshot.HeaderData, headerRows, lastColumn) Then _
        Err.Raise vbObjectError + 4236, "CaptureGeneratedOutputSnapshot", _
                  labelText & "の見出しを型まで厳密に退避できません。"
    CaptureAtomicConstantWorksheetData ws, lastColumn, maximumDataRows, _
        snapshot.Data, snapshot.LastRow, labelText
    usedLastRow = LastUsedRowInSheet(ws)
    If usedLastRow < 1 Then usedLastRow = 1
    snapshot.UsedLastColumn = LastUsedColumnInSheet(ws, usedLastRow)
    If snapshot.UsedLastColumn < 1 Then snapshot.UsedLastColumn = 1
    If snapshot.UsedLastColumn > lastColumn Then _
        Err.Raise vbObjectError + 4237, "CaptureGeneratedOutputSnapshot", _
                  labelText & "の退避対象外列に値があります。"

    If Not ActiveSheet Is Nothing Then
        If TypeName(ActiveSheet) = "Worksheet" Then
            snapshot.EntryActiveSheetName = ActiveSheet.Name
            snapshot.WasActive = (StrComp(ActiveSheet.Name, ws.Name, _
                                           vbBinaryCompare) = 0)
            If Not ActiveCell Is Nothing Then _
                snapshot.EntryActiveCellAddress = ActiveCell.Address(False, False)
            If TypeName(Selection) = "Range" Then _
                snapshot.SelectionAddress = Selection.Address(False, False)
            If Not ActiveWindow Is Nothing Then
                snapshot.FreezePanes = ActiveWindow.FreezePanes
                snapshot.SplitRow = CLng(ActiveWindow.SplitRow)
                snapshot.SplitColumn = CLng(ActiveWindow.SplitColumn)
                snapshot.ScrollRow = ActiveWindow.ScrollRow
                snapshot.ScrollColumn = ActiveWindow.ScrollColumn
                snapshot.Zoom = CLng(ActiveWindow.Zoom)
                snapshot.WindowStateCaptured = True
            End If
        End If
    End If
    snapshot.Captured = True
End Sub

Private Sub RestoreGeneratedOutputSnapshot( _
        ByVal ws As Worksheet, ByRef snapshot As GeneratedOutputSnapshot)
    If ws Is Nothing Or Not snapshot.Captured Then _
        Err.Raise vbObjectError + 4238, "RestoreGeneratedOutputSnapshot", _
                  "帳票の退避情報がありません。"
    RestoreGeneratedOutputContent ws, snapshot
    RestoreGeneratedOutputEntryView snapshot
    RestoreGeneratedOutputSurface ws, snapshot
    If snapshot.WorkbookWasSaved Then ThisWorkbook.Saved = True
End Sub

Private Sub RestoreGeneratedOutputContent( _
        ByVal ws As Worksheet, ByRef snapshot As GeneratedOutputSnapshot)
    Dim headerRange As Range, fullRange As Range
    Dim dataRows As Long, formatLastRow As Long, actualLastColumn As Long
    formatLastRow = snapshot.LastRow
    If formatLastRow < 1 Then formatLastRow = 1

    Select Case ws.Name
        Case SH_WORK_CASH, SH_OUTPUT_TX_CONVERTED
            ClearGeneratedOutputSheet ws, 21
            ws.Range("A1:E" & CStr(formatLastRow)).NumberFormatLocal = "@"
            ws.Range("J1:L" & CStr(formatLastRow)).NumberFormatLocal = "@"
            ws.Range("N1:P" & CStr(formatLastRow)).NumberFormatLocal = "@"
        Case SH_OUTPUT_BAL
            ClearGeneratedOutputSheet ws, 7 + BAL_MAX_LABELS
            actualLastColumn = snapshot.UsedLastColumn
            If actualLastColumn < 7 Then actualLastColumn = 7
            Set fullRange = ws.Range(ws.Cells(1, 1), _
                                     ws.Cells(formatLastRow, actualLastColumn))
            fullRange.NumberFormatLocal = "#,##0.########"
            ws.Range(ws.Cells(1, 1), _
                     ws.Cells(formatLastRow, 4)).NumberFormatLocal = "@"
            ws.Range(ws.Cells(1, 5), _
                     ws.Cells(formatLastRow, 6)).NumberFormatLocal = "yyyy/m/d"
            ws.Range(ws.Cells(1, actualLastColumn), _
                     ws.Cells(formatLastRow, actualLastColumn)).NumberFormatLocal = "@"
        Case SH_SHOP_TARGET
            SetupShopConversionTargetSheet ws
            ws.Range("B1:C" & CStr(formatLastRow)).NumberFormatLocal = "@"
            ws.Range("E1:G" & CStr(formatLastRow)).NumberFormatLocal = "@"
            ws.Range("H1:H" & CStr(formatLastRow)).NumberFormatLocal = _
                "yyyy/m/d h:mm"
        Case Else
            Err.Raise vbObjectError + 4239, "RestoreGeneratedOutputContent", _
                      "復元対象の帳票が不正です: " & ws.Name
    End Select

    Set headerRange = ws.Range(ws.Cells(1, 1), _
                               ws.Cells(1, snapshot.LastColumn))
    headerRange.Value2 = snapshot.HeaderData
    If Not RangeValue2MatchesMatrixStrict( _
               headerRange, snapshot.HeaderData, 1, snapshot.LastColumn) Then _
        Err.Raise vbObjectError + 4240, "RestoreGeneratedOutputContent", _
                  snapshot.LabelText & "の見出しを厳密に復元できません。"
    RestoreAtomicConstantWorksheetData ws, snapshot.LastColumn, _
        snapshot.MaximumDataRows, snapshot.Data, snapshot.LastRow, _
        snapshot.LabelText

    Select Case ws.Name
        Case SH_WORK_CASH, SH_OUTPUT_TX_CONVERTED
            ws.Columns("N:Q").Hidden = True
            FormatCashOperationOutputLayout ws
            SafeFreezeOutputHeader ws
        Case SH_OUTPUT_BAL
            FormatBalanceTransitionOutputLayout ws
        Case SH_SHOP_TARGET
            FormatShopConversionTargetSheet ws
    End Select

    If Not RangeValue2MatchesMatrixStrict( _
               headerRange, snapshot.HeaderData, 1, snapshot.LastColumn) Then _
        Err.Raise vbObjectError + 4241, "RestoreGeneratedOutputContent", _
                  snapshot.LabelText & "の書式再構成後に見出し値が変化しました。"
    dataRows = snapshot.LastRow - 1
    If dataRows > 0 Then
        If Not RangeValue2MatchesMatrixStrict( _
                   ws.Range(ws.Cells(2, 1), _
                            ws.Cells(snapshot.LastRow, snapshot.LastColumn)), _
                   snapshot.Data, dataRows, snapshot.LastColumn) Then _
            Err.Raise vbObjectError + 4242, "RestoreGeneratedOutputContent", _
                      snapshot.LabelText & "の書式再構成後の値が退避値と一致しません。"
    End If
    If LastDataRowInColumns(ws, 1, snapshot.LastColumn) <> snapshot.LastRow Then _
        Err.Raise vbObjectError + 4243, "RestoreGeneratedOutputContent", _
                  snapshot.LabelText & "の復元行数が一致しません。"
End Sub

Private Sub RestoreGeneratedOutputSurface( _
        ByVal ws As Worksheet, ByRef snapshot As GeneratedOutputSnapshot)
    If snapshot.WasProtected Then
        If ws.Name = SH_SHOP_TARGET Then
            ProtectShopConversionTargetSheet True
        Else
            ProtectGeneratedOutputSheet ws, True
        End If
    Else
        ws.Unprotect Password:=TOOL_PASSWORD
    End If
    ws.Visible = snapshot.Visibility
    If ws.ProtectContents <> snapshot.WasProtected Or _
       CLng(ws.Visible) <> snapshot.Visibility Then _
        Err.Raise vbObjectError + 4244, "RestoreGeneratedOutputSurface", _
                  snapshot.LabelText & "の保護または表示状態を復元できません。"
End Sub

Private Sub RestoreGeneratedOutputEntryView( _
        ByRef snapshot As GeneratedOutputSnapshot)
    Dim ws As Worksheet, restoredAddress As String
    If Len(snapshot.EntryActiveSheetName) = 0 Then Exit Sub
    If Not SheetExists(snapshot.EntryActiveSheetName) Then _
        Err.Raise vbObjectError + 4245, "RestoreGeneratedOutputEntryView", _
                  "操作開始時のシートが見つかりません。"
    Set ws = GetSheet(snapshot.EntryActiveSheetName)
    If ws.Visible <> xlSheetVisible Then ws.Visible = xlSheetVisible
    If ws.Visible <> xlSheetVisible Then _
        Err.Raise vbObjectError + 4246, "RestoreGeneratedOutputEntryView", _
                  "操作開始時のシートが表示状態ではありません。"
    ws.Activate
    If snapshot.WindowStateCaptured Then
        If ActiveWindow Is Nothing Then _
            Err.Raise vbObjectError + 4247, "RestoreGeneratedOutputEntryView", _
                      "操作開始時のウィンドウを復元できません。"
        ActiveWindow.FreezePanes = False
        ActiveWindow.SplitRow = snapshot.SplitRow
        ActiveWindow.SplitColumn = snapshot.SplitColumn
        ActiveWindow.FreezePanes = snapshot.FreezePanes
        ActiveWindow.Zoom = snapshot.Zoom
        ActiveWindow.ScrollRow = snapshot.ScrollRow
        ActiveWindow.ScrollColumn = snapshot.ScrollColumn
        If ActiveWindow.FreezePanes <> snapshot.FreezePanes Or _
           CLng(ActiveWindow.SplitRow) <> snapshot.SplitRow Or _
           CLng(ActiveWindow.SplitColumn) <> snapshot.SplitColumn Or _
           ActiveWindow.Zoom <> snapshot.Zoom Or _
           ActiveWindow.ScrollRow <> snapshot.ScrollRow Or _
           ActiveWindow.ScrollColumn <> snapshot.ScrollColumn Then _
            Err.Raise vbObjectError + 4248, "RestoreGeneratedOutputEntryView", _
                      "操作開始時の固定・倍率・スクロール位置が一致しません。"
    End If
    If Len(snapshot.SelectionAddress) > 0 Then
        ws.Range(snapshot.SelectionAddress).Select
        If TypeName(Selection) <> "Range" Then _
            Err.Raise vbObjectError + 4249, "RestoreGeneratedOutputEntryView", _
                      "操作開始時の選択範囲を復元できません。"
        restoredAddress = Selection.Address(False, False)
        If StrComp(restoredAddress, snapshot.SelectionAddress, _
                   vbBinaryCompare) <> 0 Then _
            Err.Raise vbObjectError + 4249, "RestoreGeneratedOutputEntryView", _
                      "操作開始時の選択範囲が一致しません。"
    ElseIf Len(snapshot.EntryActiveCellAddress) > 0 Then
        ws.Range(snapshot.EntryActiveCellAddress).Select
    End If
    If StrComp(ActiveSheet.Name, snapshot.EntryActiveSheetName, _
               vbBinaryCompare) <> 0 Then _
        Err.Raise vbObjectError + 4250, "RestoreGeneratedOutputEntryView", _
                  "操作開始時のアクティブシートを復元できません。"
End Sub

Private Sub AppendOutputRollbackDetail( _
        ByRef detailText As String, ByVal addedText As String)
    If Len(Trim$(addedText)) = 0 Then Exit Sub
    If Len(detailText) > 0 Then detailText = detailText & " / "
    detailText = detailText & addedText
End Sub

Private Sub RequireApplicationStateRestored(ByVal sourceName As String)
    Dim stateProblems As String
    If Not AppStateIsRestored(stateProblems) Then _
        Err.Raise vbObjectError + 4258, sourceName, _
                  "Excel状態の復元を確認できません: " & stateProblems
End Sub

Private Function TryRestoreApplicationState( _
        ByRef applicationLeaseStarted As Boolean, _
        ByVal entryEvents As Boolean, _
        ByRef detailText As String) As Boolean
    '所有したAppBeginだけをAppEndで一段閉じる。未所有または入れ子の外側leaseを
    'AppForceRestoreで巻き戻さない。開始イベント=Trueの時だけ全体復元も照合する。
    Dim normalRestoreProblems As String
    Dim appEndErrorNumber As Long, appEndErrorDescription As String
    detailText = vbNullString
    If Not applicationLeaseStarted Then
        If Not entryEvents Then
            TryRestoreApplicationState = True
            Exit Function
        End If
        On Error GoTo EH
        If AppStateIsRestored(normalRestoreProblems) Then
            TryRestoreApplicationState = True
        Else
            detailText = "開始時から残るExcel状態を完全復元済みとして確認できません: " & _
                         normalRestoreProblems
        End If
        Exit Function
    End If

    On Error Resume Next
    Err.Clear
    AppEnd
    appEndErrorNumber = Err.Number
    appEndErrorDescription = Err.Description
    Err.Clear
    On Error GoTo 0
    If appEndErrorNumber <> 0 Then
        detailText = "所有したApplication leaseを閉じられません: Err " & _
                     CStr(appEndErrorNumber) & " " & appEndErrorDescription
        Exit Function
    End If
    applicationLeaseStarted = False
    If Not entryEvents Then
        TryRestoreApplicationState = True
        Exit Function
    End If
    On Error GoTo EH
    If AppStateIsRestored(normalRestoreProblems) Then
        TryRestoreApplicationState = True
    Else
        detailText = "開始時のExcel設定へ復旧できません: " & _
                     normalRestoreProblems
    End If
    Exit Function
EH:
    detailText = "Excel状態の復旧確認で Err " & CStr(Err.Number) & ": " & _
                 Err.Description
    Err.Clear
End Function

Private Function TryGetOutputEnableEvents( _
        ByRef currentValue As Boolean, _
        ByRef detailText As String) As Boolean
    Dim errorNumber As Long, errorDescription As String
    detailText = vbNullString
    On Error GoTo EH
    currentValue = Application.EnableEvents
    TryGetOutputEnableEvents = True
    Exit Function
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    detailText = "Err " & CStr(errorNumber) & ": " & errorDescription
    Err.Clear
End Function

Private Function TrySetOutputEnableEventsExact( _
        ByVal desiredValue As Boolean, _
        ByRef detailText As String) As Boolean
    Dim errorNumber As Long, errorDescription As String
    detailText = vbNullString
    On Error GoTo EH
    Application.EnableEvents = desiredValue
    If Application.EnableEvents <> desiredValue Then _
        Err.Raise vbObjectError + 4270, _
                  "TrySetOutputEnableEventsExact", _
                  "EnableEventsの書込み後読戻しが一致しません。"
    TrySetOutputEnableEventsExact = True
    Exit Function
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    detailText = "Err " & CStr(errorNumber) & ": " & errorDescription
    Err.Clear
End Function

Private Function TryKeepOutputEventsDisabledExact( _
        ByRef detailText As String) As Boolean
    TryKeepOutputEventsDisabledExact = _
        TrySetOutputEnableEventsExact(False, detailText)
End Function

Private Function TryRestoreOutputEntryEvents( _
        ByVal entryValue As Boolean, _
        ByVal recoveryReason As String, _
        ByVal recoveryWritesAllowed As Boolean, _
        ByRef recoveryStateSet As Boolean, _
        ByRef recoveryAttempted As Boolean, _
        ByRef recoveryTerminalFailure As Boolean, _
        ByRef reportingAllowed As Boolean, _
        ByRef detailText As String) As Boolean
    Dim firstDetail As String, retryDetail As String
    Dim stopDetail As String, recoveryDetail As String
    Dim finalDetail As String, safeStopDetail As String
    Dim postRecoveryDetail As String
    Dim eventsStopped As Boolean, postRecoveryEventsStopped As Boolean
    Dim applicationStateRestoredExact As Boolean
    detailText = vbNullString
    reportingAllowed = False
    If recoveryAttempted Or recoveryTerminalFailure Then
        If Not TryKeepOutputEventsDisabledExact(safeStopDetail) Then _
            AppendOutputRollbackDetail detailText, _
                "Recovery終端後のExcelイベントFalse収束にも失敗しました: " & _
                safeStopDetail
        Err.Raise vbObjectError + 4499, _
                  "OutputRecoveryFatal/TryRestoreOutputEntryEvents", _
                  "Recovery強制設定試行後の開始値復元を拒否しました。" & _
                  IIf(Len(detailText) > 0, " / " & detailText, vbNullString)
    End If
    If TrySetOutputEnableEventsExact(entryValue, firstDetail) Then
        reportingAllowed = True
        TryRestoreOutputEntryEvents = True
        Exit Function
    End If
    If TrySetOutputEnableEventsExact(entryValue, retryDetail) Then
        reportingAllowed = True
        TryRestoreOutputEntryEvents = True
        Exit Function
    End If
    detailText = "Excelイベントを開始値へ復元できません。初回=" & _
                 firstDetail & " / 再試行=" & retryDetail
    eventsStopped = TryKeepOutputEventsDisabledExact(stopDetail)
    If Not eventsStopped Then
        AppendOutputRollbackDetail detailText, _
            "Recovery記録前のExcelイベント停止に失敗しました: " & _
            stopDetail
        Exit Function
    End If
    reportingAllowed = True

    '開始値=Falseは直前のexact収束で復元済み。Recoveryや再有効化は不要である。
    If Not entryValue Then
        TryRestoreOutputEntryEvents = True
        Exit Function
    End If

    '開始値=Trueを二度復元できなかった後は、安全なRecovery隔離が確定した場合だけ
    '再有効化を許す。既存のBooleanを信用せず、この失敗経路で改めて二重読戻しする。
    If recoveryWritesAllowed And Not recoveryAttempted And _
       Not recoveryTerminalFailure Then
        recoveryStateSet = _
            TryEnterOutputRecoveryState( _
                recoveryReason, recoveryDetail, recoveryAttempted, _
                recoveryTerminalFailure)
        If Not recoveryStateSet Then _
            AppendOutputRollbackDetail detailText, _
                "開始イベント復元失敗後のRecovery記録に失敗しました: " & _
                recoveryDetail
    ElseIf recoveryAttempted Or recoveryTerminalFailure Then
        AppendOutputRollbackDetail detailText, _
            "この終了処理ではRecovery強制設定を既に試行済みのため、" & _
            "再試行せずExcelイベントをFalseで停止します。"
    Else
        AppendOutputRollbackDetail detailText, _
            "失敗復旧開始時のイベント停止が未確認だったため、Recovery書込みを実行しません。"
    End If

    'TryEnterOutputRecoveryStateはEnforce成功後のFalse exact、二重Recovery、
    'Application完全復元を同じ一回の試行内で確認する。ここではFalseだけを再確認し、
    'AppForceRestoreやRecoveryの再試行で外側leaseを巻き戻さない。
    If recoveryAttempted And recoveryStateSet And _
       Not recoveryTerminalFailure Then
        postRecoveryEventsStopped = _
            TryKeepOutputEventsDisabledExact(postRecoveryDetail)
        If Not postRecoveryEventsStopped Then _
            AppendOutputRollbackDetail detailText, _
                "Recovery記録後のExcelイベント停止を確認できません: " & _
                postRecoveryDetail
        applicationStateRestoredExact = postRecoveryEventsStopped
    End If

    If Not recoveryAttempted Or Not recoveryStateSet Or _
       Not applicationStateRestoredExact Or Not postRecoveryEventsStopped Then
        eventsStopped = TryKeepOutputEventsDisabledExact(safeStopDetail)
        reportingAllowed = eventsStopped And Not recoveryTerminalFailure
        If eventsStopped Then
            AppendOutputRollbackDetail detailText, _
                "安全条件が揃わないためExcelイベントをFalseで停止しました。"
        Else
            AppendOutputRollbackDetail detailText, _
                "ExcelイベントのFalse収束にも失敗しました: " & _
                safeStopDetail
        End If
        Exit Function
    End If

    If TrySetOutputEnableEventsExact(entryValue, finalDetail) Then
        reportingAllowed = True
        TryRestoreOutputEntryEvents = True
        AppendOutputRollbackDetail detailText, _
            "Recovery記録と安全状態確認後の開始値復元再試行は成功しました。"
    Else
        AppendOutputRollbackDetail detailText, _
            "Recovery記録後も開始値へ復元できません: " & _
            finalDetail
        reportingAllowed = _
            TryKeepOutputEventsDisabledExact(safeStopDetail)
        If reportingAllowed Then
            AppendOutputRollbackDetail detailText, _
                "安全停止のためExcelイベントをFalseへ戻しました。"
        Else
            AppendOutputRollbackDetail detailText, _
                "Excelイベントの安全停止再試行にも失敗しました: " & _
                safeStopDetail
        End If
    End If
End Function

Private Function TryRecordOutputRecoveryWithRetry( _
        ByVal reasonText As String, _
        ByRef eventsStopped As Boolean, _
        ByRef recoveryAttempted As Boolean, _
        ByRef recoveryTerminalFailure As Boolean, _
        ByRef detailText As String) As Boolean
    Dim recoveryDetail As String, stopDetail As String
    If recoveryAttempted Or recoveryTerminalFailure Then
        eventsStopped = TryKeepOutputEventsDisabledExact(stopDetail)
        If Not eventsStopped Then _
            AppendOutputRollbackDetail detailText, _
                "Recovery終端後のExcelイベントFalse収束にも失敗しました: " & _
                stopDetail
        Err.Raise vbObjectError + 4499, _
                  "OutputRecoveryFatal/TryRecordOutputRecoveryWithRetry", _
                  "Recovery強制設定はこの終了処理で既に試行済みです。" & _
                  IIf(Len(detailText) > 0, " / " & detailText, vbNullString)
    End If
    If Not eventsStopped Then Exit Function
    If TryEnterOutputRecoveryState( _
           reasonText, recoveryDetail, recoveryAttempted, _
           recoveryTerminalFailure) Then
        TryRecordOutputRecoveryWithRetry = True
        Exit Function
    End If
    AppendOutputRollbackDetail detailText, _
        "要復旧状態の設定に失敗しました: " & recoveryDetail
    eventsStopped = TryKeepOutputEventsDisabledExact(stopDetail)
    If Not eventsStopped Then
        AppendOutputRollbackDetail detailText, _
            "Recovery失敗後のExcelイベントFalse収束に失敗しました: " & _
            stopDetail
    Else
        AppendOutputRollbackDetail detailText, _
            "Recovery強制設定は再試行せず、ExcelイベントをFalseで停止しました。"
    End If
End Function

Private Sub FinalizeOutputFailureState( _
        ByVal operationName As String, _
        ByVal entryEventsCaptured As Boolean, _
        ByVal entryEvents As Boolean, _
        ByVal recoveryWritesAllowed As Boolean, _
        ByRef applicationLeaseStarted As Boolean, _
        ByRef rollbackOK As Boolean, _
        ByRef recoveryStateSet As Boolean, _
        ByRef recoveryAttempted As Boolean, _
        ByRef recoveryTerminalFailure As Boolean, _
        ByRef applicationStateRestoredExact As Boolean, _
        ByRef reportingAllowed As Boolean, _
        ByRef rollbackDetail As String, _
        ByRef restoreDetail As String)
    Dim eventsStopped As Boolean
    Dim eventDetail As String, applicationDetail As String

    reportingAllowed = False
    applicationStateRestoredExact = False
    eventsStopped = False
    If recoveryAttempted Or recoveryTerminalFailure Then _
        GoTo RecoveryTerminalFailure
    If entryEventsCaptured And recoveryWritesAllowed Then
        eventsStopped = TryKeepOutputEventsDisabledExact(eventDetail)
        If Not eventsStopped Then
            rollbackOK = False
            AppendOutputRollbackDetail rollbackDetail, _
                "Recovery記録前にExcelイベント停止を確認できません: " & _
                eventDetail
        End If
    ElseIf Not entryEventsCaptured Then
        rollbackOK = False
    End If

    'Recoveryを含むsheet書込みは、直前にFalse exactを確認できた区間だけで行う。
    'Enforceはこの終了処理全体で一回だけ試行し、失敗後はFalse収束以外を行わない。
    If Not rollbackOK And eventsStopped And Not recoveryStateSet And _
       Not recoveryAttempted And Not recoveryTerminalFailure Then _
        recoveryStateSet = TryRecordOutputRecoveryWithRetry( _
                               operationName & ": " & rollbackDetail, _
                               eventsStopped, recoveryAttempted, _
                               recoveryTerminalFailure, rollbackDetail)
    If recoveryTerminalFailure Then GoTo RecoveryTerminalFailure

    'Recovery内のAppForceRestoreで外側leaseが閉じても、次工程の前にFalseを再確定する。
    If eventsStopped Then
        eventsStopped = TryKeepOutputEventsDisabledExact(eventDetail)
        If Not eventsStopped Then
            rollbackOK = False
            AppendOutputRollbackDetail rollbackDetail, _
                "Application状態復元前にExcelイベント停止を確認できません: " & _
                eventDetail
        End If
    End If

    If Not eventsStopped Then
        applicationStateRestoredExact = False
        AppendOutputRollbackDetail rollbackDetail, _
            "Excelイベント停止を確認できないため、Application状態の" & _
            "復元処理を呼び出しませんでした。"
    ElseIf recoveryStateSet Then
        'TryEnterOutputRecoveryState内でApplication状態を読戻し済みである。
        'ここでAppForceRestoreを再度呼び、別leaseを巻き戻してはならない。
        applicationLeaseStarted = False
        applicationStateRestoredExact = True
    Else
        applicationStateRestoredExact = _
            TryRestoreApplicationState( _
                applicationLeaseStarted, entryEvents, applicationDetail)
        If Not applicationStateRestoredExact Then
            rollbackOK = False
            AppendOutputRollbackDetail rollbackDetail, applicationDetail
            restoreDetail = " / Excel状態の復元エラー: " & applicationDetail
        Else
            restoreDetail = vbNullString
        End If
    End If

    'AppForceRestoreはEnableEventsを開始値へ戻し得る。診断書込み前に必ずFalseへ借り直す。
    eventsStopped = False
    If entryEventsCaptured And recoveryWritesAllowed Then
        eventsStopped = TryKeepOutputEventsDisabledExact(eventDetail)
        If Not eventsStopped Then
            rollbackOK = False
            AppendOutputRollbackDetail rollbackDetail, _
                "Excel状態復元後にイベント停止を確認できません: " & _
                eventDetail
        End If
    End If

    If Not applicationStateRestoredExact And eventsStopped Then
        If Not recoveryStateSet And Not recoveryAttempted And _
           Not recoveryTerminalFailure Then _
            recoveryStateSet = TryRecordOutputRecoveryWithRetry( _
                                   operationName & ": " & rollbackDetail, _
                                   eventsStopped, recoveryAttempted, _
                                   recoveryTerminalFailure, rollbackDetail)
        If recoveryTerminalFailure Then GoTo RecoveryTerminalFailure
        If eventsStopped Then
            eventsStopped = TryKeepOutputEventsDisabledExact(eventDetail)
            If Not eventsStopped Then _
                AppendOutputRollbackDetail rollbackDetail, _
                    "Recovery後にイベント停止を確認できません: " & _
                    eventDetail
        End If
        If recoveryStateSet And eventsStopped Then
            'Recovery成功の同一試行内でApplication状態も確認済みである。
            applicationLeaseStarted = False
            applicationStateRestoredExact = True
            restoreDetail = vbNullString
        End If
    End If

    If Not rollbackOK And eventsStopped And Not recoveryStateSet And _
       Not recoveryAttempted And Not recoveryTerminalFailure Then
        recoveryStateSet = TryRecordOutputRecoveryWithRetry( _
                               operationName & ": " & rollbackDetail, _
                               eventsStopped, recoveryAttempted, _
                               recoveryTerminalFailure, rollbackDetail)
        If recoveryTerminalFailure Then GoTo RecoveryTerminalFailure
        If eventsStopped Then
            eventsStopped = TryKeepOutputEventsDisabledExact(eventDetail)
            If Not eventsStopped Then _
                AppendOutputRollbackDetail rollbackDetail, _
                    "Recovery記録後にイベント停止を確認できません: " & _
                    eventDetail
        End If
    End If

    reportingAllowed = entryEventsCaptured And recoveryWritesAllowed And _
                       eventsStopped And applicationStateRestoredExact And _
                       (rollbackOK Or recoveryStateSet) And _
                       Not recoveryTerminalFailure
    If Not reportingAllowed Then _
        AppendOutputRollbackDetail rollbackDetail, _
            "ExcelイベントのFalse exactを確認できないため、" & _
            "状態・チェックへの追加書込みを行いません。"
    Exit Sub

RecoveryTerminalFailure:
    'EnforceのエラーまたはRecovery二重確認失敗後は、ブック・AppForce・
    '開始値Trueへ一切進まず、Application.EnableEvents=Falseだけへ収束させる。
    rollbackOK = False
    recoveryStateSet = False
    applicationStateRestoredExact = False
    reportingAllowed = False
    If TryKeepOutputEventsDisabledExact(eventDetail) Then
        AppendOutputRollbackDetail rollbackDetail, _
            "Recovery強制設定の安全条件を確認できないため、" & _
            "ExcelイベントをFalseで停止しました。"
    Else
        AppendOutputRollbackDetail rollbackDetail, _
            "Recovery強制設定失敗後のExcelイベントFalse収束にも失敗しました: " & _
            eventDetail
    End If
    restoreDetail = restoreDetail & _
                    " / Recovery安全条件未成立のため通常状態へ戻していません。"
    Err.Raise vbObjectError + 4499, _
              "OutputRecoveryFatal/FinalizeOutputFailureState", _
              operationName & restoreDetail & _
              IIf(Len(rollbackDetail) > 0, _
                  " / 復元確認: " & rollbackDetail, vbNullString)
End Sub

Private Sub CompleteOutputFailureEventLease( _
        ByVal operationName As String, _
        ByVal entryEventsCaptured As Boolean, _
        ByVal entryEvents As Boolean, _
        ByVal recoveryWritesAllowed As Boolean, _
        ByRef rollbackOK As Boolean, _
        ByRef recoveryStateSet As Boolean, _
        ByRef recoveryAttempted As Boolean, _
        ByRef recoveryTerminalFailure As Boolean, _
        ByVal applicationStateRestoredExact As Boolean, _
        ByRef rollbackDetail As String, _
        ByRef restoreDetail As String)
    Dim entryRestoreDetail As String
    Dim finalReportingAllowed As Boolean
    Dim eventContainmentConfirmed As Boolean
    Dim containmentDetail As String, retryContainmentDetail As String
    Dim rollbackOrRecoveryConfirmed As Boolean
    Dim safeToRestoreEntry As Boolean

    If recoveryAttempted Or recoveryTerminalFailure Then
        If Not TryKeepOutputEventsDisabledExact(containmentDetail) Then _
            AppendOutputRollbackDetail rollbackDetail, _
                "Recovery終端後のExcelイベントFalse収束にも失敗しました: " & _
                containmentDetail
        Err.Raise vbObjectError + 4499, _
                  "OutputRecoveryFatal/CompleteOutputFailureEventLease", _
                  operationName & _
                  "ではRecovery強制設定試行後の終了処理を拒否しました。" & _
                  IIf(Len(rollbackDetail) > 0, _
                      " / 復元確認: " & rollbackDetail, vbNullString)
    End If

    If Not entryEventsCaptured Then
        rollbackOK = False
        AppendOutputRollbackDetail rollbackDetail, _
            "Excelイベントの開始値が不明なため復元できません。"
        restoreDetail = " / Excelイベント状態を確認できません。"
        Exit Sub
    End If

    '診断書込み後にもFalse exactを独立に再確認し、過去のBooleanだけで再開しない。
    eventContainmentConfirmed = _
        TryKeepOutputEventsDisabledExact(containmentDetail)

    '開始値=Falseなら再開判断は不要。False exactへの収束自体がlease復元である。
    If Not entryEvents Then
        If eventContainmentConfirmed Then Exit Sub
        If TryKeepOutputEventsDisabledExact(retryContainmentDetail) Then Exit Sub
        rollbackOK = False
        AppendOutputRollbackDetail rollbackDetail, _
            "開始値=Falseへのイベント収束に失敗しました: 初回=" & _
            containmentDetail & " / 再試行=" & retryContainmentDetail
        restoreDetail = restoreDetail & _
                        " / Excelイベント状態を確認できません。"
        Exit Sub
    End If

    rollbackOrRecoveryConfirmed = rollbackOK Or recoveryStateSet
    safeToRestoreEntry = eventContainmentConfirmed And _
        recoveryWritesAllowed And applicationStateRestoredExact And _
        rollbackOrRecoveryConfirmed And Not recoveryTerminalFailure
    If Not safeToRestoreEntry Then
        If Not eventContainmentConfirmed Then _
            AppendOutputRollbackDetail rollbackDetail, _
                "終了時のExcelイベントFalse exactを確認できません: " & _
                containmentDetail
        If Not recoveryWritesAllowed Then _
            AppendOutputRollbackDetail rollbackDetail, _
                "失敗復旧開始時から診断完了までのイベント隔離を確認できません。"
        If Not applicationStateRestoredExact Then _
            AppendOutputRollbackDetail rollbackDetail, _
                "Application状態の完全復元を確認できません。"
        If Not rollbackOrRecoveryConfirmed Then _
            AppendOutputRollbackDetail rollbackDetail, _
                "開始時状態へのrollbackまたは独立ラッチ・案件health双方の" & _
                "Recovery確定がありません。"
        If TryKeepOutputEventsDisabledExact(retryContainmentDetail) Then
            AppendOutputRollbackDetail rollbackDetail, _
                "安全条件が揃わないためExcelイベントをFalseで停止しました。"
        Else
            AppendOutputRollbackDetail rollbackDetail, _
                "ExcelイベントのFalse収束にも失敗しました: " & _
                retryContainmentDetail
        End If
        restoreDetail = restoreDetail & _
                        " / 安全条件未成立のためExcelイベントを再開していません。"
        rollbackOK = False
        Exit Sub
    End If

    'この呼出しより後ではsheetへ一切書き込まない。失敗時はFalse exact下だけで
    'Recoveryを記録し、開始値への最終再試行、それも失敗した場合のFalse収束を行う。
    If Not TryRestoreOutputEntryEvents( _
               entryEvents, operationName & ": " & rollbackDetail, _
               recoveryWritesAllowed, recoveryStateSet, recoveryAttempted, _
               recoveryTerminalFailure, _
               finalReportingAllowed, entryRestoreDetail) Then
        rollbackOK = False
        AppendOutputRollbackDetail rollbackDetail, entryRestoreDetail
        restoreDetail = restoreDetail & _
                        " / Excelイベントの開始状態を復元できません。"
    End If
End Sub

Private Function TryRestoreGeneratedOutputForFailure( _
        ByVal ws As Worksheet, ByRef snapshot As GeneratedOutputSnapshot, _
        ByVal contentWasMutated As Boolean, ByRef detailText As String) As Boolean
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim eventDetail As String
    detailText = vbNullString
    If Not snapshot.Captured Then
        TryRestoreGeneratedOutputForFailure = True
        Exit Function
    End If
    On Error GoTo EH
    If contentWasMutated Then
        RestoreGeneratedOutputSnapshot ws, snapshot
    Else
        RestoreGeneratedOutputSurface ws, snapshot
        If snapshot.WorkbookWasSaved Then
            ThisWorkbook.Saved = True
            If Not ThisWorkbook.Saved Then _
                Err.Raise vbObjectError + 4259, _
                          "TryRestoreGeneratedOutputForFailure", _
                          "ブックの保存状態を操作開始前へ戻せません。"
        End If
    End If
    TryRestoreGeneratedOutputForFailure = True
    Exit Function
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    Err.Clear
    If IsOutputUpstreamRecoveryFatal(errorNumber, errorSource) Then
        Call TryKeepOutputEventsDisabledExact(eventDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    detailText = "Err " & CStr(errorNumber) & ": " & errorDescription
End Function

Private Function TryRestoreReconciliationForFailure( _
        ByRef snapshotCaptured As Boolean, ByRef detailText As String) As Boolean
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim eventDetail As String
    detailText = vbNullString
    If Not snapshotCaptured Then
        TryRestoreReconciliationForFailure = True
        Exit Function
    End If
    On Error GoTo EH
    RestoreBalanceReconciliationOperationSnapshot snapshotCaptured
    TryRestoreReconciliationForFailure = True
    Exit Function
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    Err.Clear
    If IsOutputUpstreamRecoveryFatal(errorNumber, errorSource) Then
        Call TryKeepOutputEventsDisabledExact(eventDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    detailText = "Err " & CStr(errorNumber) & ": " & errorDescription
End Function

Private Function IsOutputUpstreamRecoveryFatal( _
        ByVal errorNumber As Long, ByVal errorSource As String) As Boolean
    Dim sourcePrefix As String

    Select Case errorNumber
        Case vbObjectError + 3599, vbObjectError + 4499
            IsOutputUpstreamRecoveryFatal = True
            Exit Function
        Case vbObjectError + 5191
            sourcePrefix = "AnalysisWorkspaceRecoveryFatal/"
        Case vbObjectError + 5192
            sourcePrefix = "SetupConvergeRecoveryFatal/"
        Case vbObjectError + 5194
            sourcePrefix = "CashAnalysisRecoveryFatal/"
        Case vbObjectError + 5195
            sourcePrefix = "TransactionAnalysisRecoveryFatal/"
        Case vbObjectError + 5196
            sourcePrefix = "CashManualSelectionRecoveryFatal/"
        Case vbObjectError + 5197
            sourcePrefix = "ClearRecoveryFatal/"
        Case Else
            Exit Function
    End Select

    IsOutputUpstreamRecoveryFatal = _
        (Len(errorSource) >= Len(sourcePrefix)) And _
        (StrComp(Left$(errorSource, Len(sourcePrefix)), _
                 sourcePrefix, vbBinaryCompare) = 0)
End Function

Private Function TryReleaseReconciliationSnapshot( _
        ByRef snapshotCaptured As Boolean, ByRef detailText As String) As Boolean
    detailText = vbNullString
    If Not snapshotCaptured Then
        TryReleaseReconciliationSnapshot = True
        Exit Function
    End If
    On Error GoTo EH
    ReleaseBalanceReconciliationOperationSnapshot snapshotCaptured
    TryReleaseReconciliationSnapshot = True
    Exit Function
EH:
    detailText = "Err " & CStr(Err.Number) & ": " & Err.Description
    Err.Clear
End Function

Private Function TryRollbackAnalysisForFailure( _
        ByRef transactionStarted As Boolean, ByRef detailText As String) As Boolean
    Dim rollbackResult As Boolean
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim eventDetail As String
    detailText = vbNullString
    If Not transactionStarted Then
        TryRollbackAnalysisForFailure = True
        Exit Function
    End If
    On Error GoTo EH
    rollbackResult = RollbackAnalysisOperationTransaction(detailText)
    If Not rollbackResult Then
        If Len(detailText) = 0 Then detailText = "分析transactionの復元結果がFalseです。"
        Exit Function
    End If
    transactionStarted = False
    TryRollbackAnalysisForFailure = True
    Exit Function
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    Err.Clear
    If IsOutputUpstreamRecoveryFatal(errorNumber, errorSource) Then
        Call TryKeepOutputEventsDisabledExact(eventDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    If Len(detailText) > 0 Then detailText = detailText & " / "
    detailText = detailText & "Err " & CStr(errorNumber) & ": " & _
                 errorDescription
End Function

Private Function TryRestoreOutputStateForFailure( _
        ByVal outputDirtyValue As String, ByVal analysisDirtyValue As String, _
        ByVal lastBuildValue As String, ByVal workbookWasSaved As Boolean, _
        ByRef detailText As String) As Boolean
    detailText = vbNullString
    On Error GoTo EH
    RestoreOutputStateSnapshot outputDirtyValue, analysisDirtyValue, _
                               lastBuildValue, workbookWasSaved
    TryRestoreOutputStateForFailure = True
    Exit Function
EH:
    detailText = "Err " & CStr(Err.Number) & ": " & Err.Description
    Err.Clear
End Function

Private Function TryReadRollbackRecoveryLatch( _
        ByRef latchSet As Boolean, ByRef detailText As String) As Boolean
    detailText = vbNullString
    On Error GoTo EH
    If Not TryGetRollbackRecoveryLatch(latchSet) Then
        detailText = "復旧ラッチを一意に読み戻せません。"
        Exit Function
    End If
    TryReadRollbackRecoveryLatch = True
    Exit Function
EH:
    detailText = "Err " & CStr(Err.Number) & ": " & Err.Description
    Err.Clear
End Function

Private Function TryEnterOutputRecoveryState( _
        ByVal reasonText As String, ByRef detailText As String, _
        ByRef recoveryAttempted As Boolean, _
        ByRef recoveryTerminalFailure As Boolean) As Boolean
    Dim eventDetail As String, finalStopDetail As String
    Dim enforceErrorNumber As Long, enforceErrorDescription As String
    Dim enforceErrorSource As String
    detailText = vbNullString
    If recoveryAttempted Or recoveryTerminalFailure Then
        recoveryTerminalFailure = True
        detailText = "Recovery強制設定はこの終了処理で既に試行済みです。"
        GoTo RaiseTerminal
    End If
    If Not TryKeepOutputEventsDisabledExact(eventDetail) Then
        recoveryTerminalFailure = True
        detailText = "Recovery強制設定前のExcelイベント停止を確認できません: " & _
                     eventDetail
        GoTo RaiseTerminal
    End If

    'Enforce本体を一度でも呼んだ後は、正常return／errorのどちらでも終端である。
    '戻り値や既存Recovery状態を読まず、fresh False exactの後にそのまま伝播する。
    recoveryAttempted = True
    recoveryTerminalFailure = True
    On Error Resume Next
    Err.Clear
    EnforceRollbackRecoveryState reasonText
    enforceErrorNumber = Err.Number
    enforceErrorDescription = Err.Description
    enforceErrorSource = Err.Source
    Err.Clear
    Call TryKeepOutputEventsDisabledExact(finalStopDetail)
    On Error GoTo 0
    If enforceErrorNumber <> 0 Then
        Err.Raise vbObjectError + 4499, _
                  "OutputRecoveryFatal/TryEnterOutputRecoveryState", _
                  enforceErrorDescription
    End If
    Err.Raise vbObjectError + 4499, _
              "OutputRecoveryFatal/TryEnterOutputRecoveryState", _
              "EnforceRollbackRecoveryStateが正常returnしたため、契約違反として終端します。"

RaiseTerminal:
    If TryKeepOutputEventsDisabledExact(finalStopDetail) Then
        AppendOutputRollbackDetail detailText, _
            "以後のRecovery再試行・ブック読書き・Application復元を停止し、" & _
            "ExcelイベントをFalseで保持しました。"
    Else
        AppendOutputRollbackDetail detailText, _
            "ExcelイベントのFalse収束にも失敗しました: " & finalStopDetail
    End If
    Err.Raise vbObjectError + 4499, _
              "OutputRecoveryFatal/TryEnterOutputRecoveryState", _
              detailText
End Function

Private Function TryRecordOutputCheck( _
        ByVal levelText As String, ByVal sourceText As String, _
        ByVal detailToRecord As String) As Boolean
    On Error GoTo EH
    AddCheck levelText, sourceText, detailToRecord
    TryRecordOutputCheck = True
    Exit Function
EH:
    Err.Clear
End Function

Private Function TrySetOutputStatus( _
        ByVal statusText As String, Optional ByVal isError As Boolean = False) As Boolean
    On Error GoTo EH
    SetInputStatus statusText, isError
    TrySetOutputStatus = True
    Exit Function
EH:
    Err.Clear
End Function

Private Function TryShowOutputMessage( _
        ByVal messageText As String, ByVal styleValue As VbMsgBoxStyle, _
        Optional ByVal titleText As String = vbNullString) As Boolean
    On Error GoTo EH
    MsgBox messageText, styleValue, titleText
    TryShowOutputMessage = True
    Exit Function
EH:
    Err.Clear
End Function

Private Sub CaptureOutputStateSnapshot( _
        ByRef outputDirtyValue As String, _
        ByRef analysisDirtyValue As String, _
        ByRef lastBuildValue As String, _
        ByRef workbookWasSaved As Boolean)
    Dim stateCaptured As Boolean

    stateCaptured = _
        TryGetExactStateValue(STATE_OUTPUT_DIRTY, outputDirtyValue)
    If Not stateCaptured Then _
        Err.Raise vbObjectError + 4251, "CaptureOutputStateSnapshot", _
                  "帳票更新状態を操作開始前に一意に退避できません。"
    stateCaptured = _
        TryGetExactStateValue(STATE_ANALYSIS_REVIEW_DIRTY, _
                              analysisDirtyValue)
    If Not stateCaptured Then _
        Err.Raise vbObjectError + 4251, "CaptureOutputStateSnapshot", _
                  "帳票更新状態を操作開始前に一意に退避できません。"
    stateCaptured = _
        TryGetExactStateValue(STATE_LAST_BUILD, lastBuildValue)
    If Not stateCaptured Then _
        Err.Raise vbObjectError + 4251, "CaptureOutputStateSnapshot", _
                  "帳票更新状態を操作開始前に一意に退避できません。"
    workbookWasSaved = ThisWorkbook.Saved
End Sub

Private Sub RestoreOutputStateSnapshot( _
        ByVal outputDirtyValue As String, _
        ByVal analysisDirtyValue As String, _
        ByVal lastBuildValue As String, _
        ByVal workbookWasSaved As Boolean)
    Dim actualValue As String
    SetStateValue STATE_ANALYSIS_REVIEW_DIRTY, analysisDirtyValue
    SetStateValue STATE_LAST_BUILD, lastBuildValue
    SetStateValue STATE_OUTPUT_DIRTY, outputDirtyValue
    If Not TryGetExactStateValue(STATE_ANALYSIS_REVIEW_DIRTY, actualValue) Or _
       StrComp(actualValue, analysisDirtyValue, vbBinaryCompare) <> 0 Then _
        Err.Raise vbObjectError + 4252, "RestoreOutputStateSnapshot", _
                  "分析判断の更新状態を操作開始前へ復元できません。"
    If Not TryGetExactStateValue(STATE_LAST_BUILD, actualValue) Or _
       StrComp(actualValue, lastBuildValue, vbBinaryCompare) <> 0 Then _
        Err.Raise vbObjectError + 4252, "RestoreOutputStateSnapshot", _
                  "最終帳票更新時刻を操作開始前へ復元できません。"
    If Not TryGetExactStateValue(STATE_OUTPUT_DIRTY, actualValue) Or _
       StrComp(actualValue, outputDirtyValue, vbBinaryCompare) <> 0 Then _
        Err.Raise vbObjectError + 4252, "RestoreOutputStateSnapshot", _
                  "帳票の更新状態を操作開始前へ復元できません。"
    RefreshMainActionCaption
    ThisWorkbook.Saved = workbookWasSaved
    If ThisWorkbook.Saved <> workbookWasSaved Then _
        Err.Raise vbObjectError + 4252, "RestoreOutputStateSnapshot", _
                  "ブックの保存状態を操作開始前へ復元できません。"
End Sub

Private Function ConvergeBuiltOutputUserInterface( _
        ByRef detailText As String) As Boolean
    '帳票のfreshness確定後にだけ行う、表示・保護の独立収束工程。
    Dim visibilityDetail As String
    Dim ws As Worksheet
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim eventDetail As String
    detailText = vbNullString
    On Error GoTo EH

    If SheetExists(SH_OUTPUT_TX) Then
        Set ws = GetSheet(SH_OUTPUT_TX)
        ProtectCashAnalysisViewSheet
        ws.Visible = xlSheetVisible
        If ws.Visible <> xlSheetVisible Or Not ws.ProtectContents Or _
           Not ws.ProtectDrawingObjects Then _
            Err.Raise vbObjectError + 4256, "ConvergeBuiltOutputUserInterface", _
                      "資金操作表の表示・保護を確認できません。"
        '倍率と固定位置は利用者・ウィンドウ状態なので、収束失敗の判定には使わない。
        On Error Resume Next
        ApplyCashAnalysisViewWindowStyle True
        Err.Clear
        On Error GoTo EH
    End If
    If SheetExists(SH_OUTPUT_BAL) Then
        Set ws = GetSheet(SH_OUTPUT_BAL)
        ProtectGeneratedOutputSheet ws, True
        ws.Visible = xlSheetVisible
        If ws.Visible <> xlSheetVisible Or Not ws.ProtectContents Then _
            Err.Raise vbObjectError + 4256, "ConvergeBuiltOutputUserInterface", _
                      "残高推移表の表示・保護を確認できません。"
    End If
    If SheetExists(SH_SHOP_TARGET) Then
        Set ws = GetSheet(SH_SHOP_TARGET)
        ProtectShopConversionTargetSheet True
        ws.Visible = xlSheetVisible
        If ws.Visible <> xlSheetVisible Or Not ws.ProtectContents Or _
           Not ws.ProtectDrawingObjects Then _
            Err.Raise vbObjectError + 4256, "ConvergeBuiltOutputUserInterface", _
                      "取扱店変換対象の表示・保護を確認できません。"
    End If
    If SheetExists(SH_OUTPUT_TX_CONVERTED) Then _
        ProtectGeneratedOutputSheet GetSheet(SH_OUTPUT_TX_CONVERTED), True
    If SheetExists(SH_BALANCE_RECONCILIATION) Then _
        ProtectGeneratedOutputSheet GetSheet(SH_BALANCE_RECONCILIATION), True

    If Not ConvergeDailySheetVisibility(False, visibilityDetail) Then _
        Err.Raise vbObjectError + 4257, "ConvergeBuiltOutputUserInterface", _
                  "シート表示を収束できません。" & _
                  IIf(Len(visibilityDetail) > 0, " " & visibilityDetail, vbNullString)
    ConvergeBuiltOutputUserInterface = True
    Exit Function
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    Err.Clear
    If IsOutputUpstreamRecoveryFatal(errorNumber, errorSource) Then
        Call TryKeepOutputEventsDisabledExact(eventDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    detailText = "Err " & CStr(errorNumber) & ": " & errorDescription
    ConvergeBuiltOutputUserInterface = False
End Function

Public Sub BuildAllOutputSheets()
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim restoreDetail As String
    Dim leaseDetail As String
    Dim structureProblems As String
    Dim uiConverged As Boolean, uiConvergenceDetail As String
    Dim successMessage As String, successTitle As String
    Dim successStyle As VbMsgBoxStyle
    Dim confirmedAnalysisWorkloadRows As Double
    Dim wsWorkCash As Worksheet, wsBalance As Worksheet
    Dim wsShop As Worksheet, wsConverted As Worksheet
    Dim workCashSnapshot As GeneratedOutputSnapshot
    Dim balanceSnapshot As GeneratedOutputSnapshot
    Dim shopSnapshot As GeneratedOutputSnapshot
    Dim convertedSnapshot As GeneratedOutputSnapshot
    Dim reconciliationSnapshotCaptured As Boolean
    Dim stateSnapshotCaptured As Boolean
    Dim analysisTransactionStarted As Boolean, outerMutationStarted As Boolean
    Dim applicationLeaseStarted As Boolean
    Dim entryEvents As Boolean, entryEventsCaptured As Boolean
    Dim entryEventsRestored As Boolean, operationSucceeded As Boolean
    Dim cleanupEventsStopped As Boolean, reportingAllowed As Boolean
    Dim operationCommitted As Boolean
    Dim rollbackOK As Boolean, analysisRollbackOK As Boolean
    Dim recoveryStateSet As Boolean
    Dim recoveryAttempted As Boolean, recoveryTerminalFailure As Boolean
    Dim applicationStateRestoredExact As Boolean
    Dim rollbackDetail As String, analysisRollbackDetail As String
    Dim outputDirtyValue As String, analysisDirtyValue As String
    Dim lastBuildValue As String, workbookWasSaved As Boolean
    On Error GoTo EH
    'OnAction入口自身が外側イベントleaseを所有する。AppBeginはFalseを開始値として
    '捕捉し、全preflight・build・診断の完了後にだけ元の開始値へ返す。
    If Not TryGetOutputEnableEvents(entryEvents, leaseDetail) Then _
        Err.Raise vbObjectError + 4271, "BuildAllOutputSheets", _
                  "Excelイベントの開始状態を取得できません。 " & _
                  leaseDetail
    entryEventsCaptured = True
    If Not TryKeepOutputEventsDisabledExact(leaseDetail) Then _
        Err.Raise vbObjectError + 4277, "BuildAllOutputSheets", _
                  "Excelイベントを安全に停止できないため、" & _
                  "帳票・分析更新を開始していません。 " & leaseDetail
    cleanupEventsStopped = True

    If Not RequireCashAnalysisManualModeFinished("帳票・分析の更新") Then _
        GoTo CLEAN_EXIT
    If HasSelectedAnalysisDetailTransactions() Then
        MsgBox "候補詳細に、手動候補として未登録の選択取引があります。" & vbCrLf & _
               "帳票・分析の更新前に、候補を登録するか選択を解除してください。" & vbCrLf & _
               "選択内容を黙って破棄することはありません。", _
               vbInformation, "手動候補の選択を完了してください"
        GoTo CLEAN_EXIT
    End If
    If Not RequireToolReady() Then GoTo CLEAN_EXIT
    If Not RequireOutputBuildCapacity("帳票・分析の更新", True, True, True, _
                                      True, True, False, True) Then
        TrySetOutputStatus _
            "帳票・分析更新を開始せず中止しました。" & _
            "内部データと既存帳票は変更していません。"
        GoTo CLEAN_EXIT
    End If
    If Not RequireNoPendingAccountInput("帳票・分析の更新") Then _
        GoTo CLEAN_EXIT
    If Not RequireInternalStoresSafeForWrite(False, False) Then _
        GoTo CLEAN_EXIT
    If Not EnsureCaseReadyForOutputs(True) Then GoTo CLEAN_EXIT
    AppBegin "帳票・分析更新中..."
    applicationLeaseStarted = True
    '分析11表・正式表示と、分析判断台帳を外側transactionで同一時点に固定する。
    BeginAnalysisOperationTransaction "帳票・分析の一括更新"
    analysisTransactionStarted = True
    confirmedAnalysisWorkloadRows = AnalysisOperationConfirmedWorkloadRows()
    Set wsWorkCash = GetSheet(SH_WORK_CASH)
    Set wsBalance = GetSheet(SH_OUTPUT_BAL)
    Set wsShop = GetSheet(SH_SHOP_TARGET)
    Set wsConverted = GetSheet(SH_OUTPUT_TX_CONVERTED)
    CaptureGeneratedOutputSnapshot wsWorkCash, OUT_COL_INPUT_ORDER, _
        MAX_PRACTICAL_OUTPUT_ROWS, "予定資金表（操作開始時）", workCashSnapshot
    CaptureGeneratedOutputSnapshot wsBalance, 7 + BAL_MAX_LABELS, _
        MAX_PRACTICAL_OUTPUT_ROWS, "残高推移表（操作開始時）", balanceSnapshot
    CaptureBalanceReconciliationOperationSnapshot _
        reconciliationSnapshotCaptured
    CaptureGeneratedOutputSnapshot wsShop, SHOP_TGT_LAST_COL, _
        MAX_PRACTICAL_OUTPUT_ROWS, "取扱店変換対象（操作開始時）", shopSnapshot
    CaptureGeneratedOutputSnapshot wsConverted, OUT_COL_INPUT_ORDER, _
        MAX_PRACTICAL_OUTPUT_ROWS, "取扱店反映済み表（操作開始時）", _
        convertedSnapshot
    'MarkOutputsDirty/MarkOutputsCleanを含むfreshness状態も、生成表と同じ
    '操作開始時点へだけ戻せるよう、最初の状態変更前にexact退避する。
    CaptureOutputStateSnapshot outputDirtyValue, analysisDirtyValue, _
                               lastBuildValue, workbookWasSaved
    stateSnapshotCaptured = True
    outerMutationStarted = True
    '途中失敗時に旧の「更新済み」状態を残さない。全帳票完了後だけ正常に戻す。
    MarkOutputsDirty
    BuildCashOperationSheetCore False, True
    BuildBalanceTransitionSheetCore False, True
    BuildBalanceReconciliationCore False, True
    BuildShopConversionTargetSheetCore False, True
    ApplyShopConversionCore False, False, True
    BuildTransactionAnalysisSheetsCore False, True, _
                                       confirmedAnalysisWorkloadRows, False
    BuildCashAnalysisViewCore False, False, True
    If Not ValidateAuthoritativeDataStructure(structureProblems, True, False) Then _
        Err.Raise vbObjectError + 4255, "BuildAllOutputSheets", _
                  "帳票更新後の中核データ構造が不正です: " & _
                  Left$(Replace(structureProblems, vbCrLf, " / "), 3000)
    MarkOutputsClean
    If SheetExists(SH_OUTPUT_TX) Then ThisWorkbook.Worksheets(SH_OUTPUT_TX).Visible = xlSheetVisible
    If SheetExists(SH_OUTPUT_BAL) Then ThisWorkbook.Worksheets(SH_OUTPUT_BAL).Visible = xlSheetVisible
    If SheetExists(SH_SHOP_TARGET) Then ThisWorkbook.Worksheets(SH_SHOP_TARGET).Visible = xlSheetVisible
    CommitAnalysisOperationTransaction
    operationCommitted = True
    analysisTransactionStarted = False
    ReleaseBalanceReconciliationOperationSnapshot _
        reconciliationSnapshotCaptured
    outerMutationStarted = False
    If Not TryKeepOutputEventsDisabledExact(leaseDetail) Then _
        Err.Raise vbObjectError + 4274, "BuildAllOutputSheets", _
                  "確定後画面処理前にExcelイベント停止を確認できません。 " & _
                  leaseDetail
    'データ確定後に、表示・保護を別工程で収束させる。ここで失敗しても最新帳票を
    'ロールバックせず、全面成功とも表示せず、診断へ根拠を残す。
    uiConverged = ConvergeBuiltOutputUserInterface(uiConvergenceDetail)
    '画面・保護・状態・チェックの全書込みは、AppBeginのFalse exact lease内で完了する。
    If uiConverged Then
        TrySetOutputStatus _
            "帳票・分析は最新です。資金操作表の上部で候補と元取引を同時に確認できます。"
        successMessage = _
            "帳票・検算・取扱店一覧・分析候補を最新化しました。" & vbCrLf & _
            "資金操作表の上部で候補を切り替え、直下の元取引と同じ画面で確認できます。" & vbCrLf & _
            "取扱店の確認後は［入力内容を反映］を押してください。"
        successStyle = vbInformation
        successTitle = "帳票・分析の更新完了"
    Else
        TryRecordOutputCheck "警告", "帳票更新後の画面・保護", _
                             uiConvergenceDetail
        TrySetOutputStatus _
            "帳票データは最新ですが、画面表示または保護を完全に整えられませんでした。", _
            True
        successMessage = _
            "帳票データと分析結果の更新は完了しています。" & vbCrLf & _
            "ただし、画面表示または保護の収束を確認できませんでした。" & vbCrLf & _
            "C_チェックを確認し、［表示を整え直す］を実行してください。" & vbCrLf & vbCrLf & _
            Left$(uiConvergenceDetail, 2000)
        successStyle = vbExclamation
        successTitle = "帳票は最新・画面保護は要確認"
    End If
    'AppBeginの開始値は外側leaseのFalse。元のentry値はCLEAN_EXITで最後に戻す。
    AppEnd
    applicationLeaseStarted = False
    RequireApplicationStateRestored "BuildAllOutputSheets"
    operationSucceeded = True

CLEAN_EXIT:
    entryEventsRestored = True
    If entryEventsCaptured Then
        entryEventsRestored = TryRestoreOutputEntryEvents( _
                                  entryEvents, _
                                  "帳票・分析更新の終了時イベント復元", _
                                  cleanupEventsStopped, recoveryStateSet, _
                                  recoveryAttempted, recoveryTerminalFailure, _
                                  reportingAllowed, leaseDetail)
        entryEventsCaptured = False
    End If
    '開始値復元後はMsgBox以外の処理を行わず、sheetへは一切書き込まない。
    If Not entryEventsRestored Or recoveryStateSet Then
        TryShowOutputMessage _
            IIf(operationSucceeded, _
                "帳票・分析の更新結果は確定済みです。", _
                "帳票・分析の更新処理は開始していません。") & vbCrLf & _
            IIf(recoveryStateSet, _
                "終了時のExcelイベント復元で異常を検出し、案件を要復旧として停止しました。", _
                "終了時のExcelイベント状態を一意に確認できません。通常操作を停止してください。") & _
            IIf(Len(leaseDetail) > 0, vbCrLf & leaseDetail, vbNullString), _
            vbExclamation, "帳票・分析更新後の安全状態を要確認"
    ElseIf operationSucceeded Then
        TryShowOutputMessage successMessage, successStyle, successTitle
    End If
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    Err.Clear
    '下位transaction/workspaceが既にterminal Recoveryを所有したfatalは、
    '生成表rollback・二重Enforce・Application cleanup・entry=Trueへ進めない。
    If IsOutputUpstreamRecoveryFatal(errorNumber, errorSource) Then
        Call TryKeepOutputEventsDisabledExact(leaseDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    rollbackOK = True
    cleanupEventsStopped = False
    If Not entryEventsCaptured Then
        rollbackOK = False
        AppendOutputRollbackDetail rollbackDetail, _
            "Excelイベントの開始状態を取得できていません。"
    ElseIf TryKeepOutputEventsDisabledExact(leaseDetail) Then
        cleanupEventsStopped = True
    Else
        rollbackOK = False
        AppendOutputRollbackDetail rollbackDetail, _
            "失敗復旧の開始前にExcelイベント停止を確認できません: " & _
            leaseDetail
    End If

    If operationCommitted Then
        rollbackOK = False
        AppendOutputRollbackDetail rollbackDetail, _
            "帳票・分析は確定済みのため、旧生成表への巻戻しは行いません。"
        If reconciliationSnapshotCaptured And cleanupEventsStopped Then
            If Not TryReleaseReconciliationSnapshot( _
                       reconciliationSnapshotCaptured, analysisRollbackDetail) Then
                AppendOutputRollbackDetail rollbackDetail, _
                    "確定後の残高検算退避情報を解放できません: " & _
                    analysisRollbackDetail
            End If
        End If
    ElseIf cleanupEventsStopped Then
        If outerMutationStarted Then
            If reconciliationSnapshotCaptured Then
                If Not TryRestoreReconciliationForFailure( _
                           reconciliationSnapshotCaptured, analysisRollbackDetail) Then
                    rollbackOK = False
                    AppendOutputRollbackDetail rollbackDetail, _
                        "残高検算の一括復元エラー: " & analysisRollbackDetail
                End If
            End If
            If convertedSnapshot.Captured Then
                If Not TryRestoreGeneratedOutputForFailure( _
                           wsConverted, convertedSnapshot, True, _
                           analysisRollbackDetail) Then
                    rollbackOK = False
                    AppendOutputRollbackDetail rollbackDetail, _
                        "取扱店反映済み表の一括復元エラー: " & analysisRollbackDetail
                End If
            End If
            If shopSnapshot.Captured Then
                If Not TryRestoreGeneratedOutputForFailure( _
                           wsShop, shopSnapshot, True, analysisRollbackDetail) Then
                    rollbackOK = False
                    AppendOutputRollbackDetail rollbackDetail, _
                        "取扱店変換対象の一括復元エラー: " & analysisRollbackDetail
                End If
            End If
            If balanceSnapshot.Captured Then
                If Not TryRestoreGeneratedOutputForFailure( _
                           wsBalance, balanceSnapshot, True, _
                           analysisRollbackDetail) Then
                    rollbackOK = False
                    AppendOutputRollbackDetail rollbackDetail, _
                        "残高推移表の一括復元エラー: " & analysisRollbackDetail
                End If
            End If
            If workCashSnapshot.Captured Then
                If Not TryRestoreGeneratedOutputForFailure( _
                           wsWorkCash, workCashSnapshot, True, _
                           analysisRollbackDetail) Then
                    rollbackOK = False
                    AppendOutputRollbackDetail rollbackDetail, _
                        "予定資金表の一括復元エラー: " & analysisRollbackDetail
                End If
            End If
        ElseIf reconciliationSnapshotCaptured Then
            If Not TryReleaseReconciliationSnapshot( _
                       reconciliationSnapshotCaptured, analysisRollbackDetail) Then
                rollbackOK = False
                AppendOutputRollbackDetail rollbackDetail, _
                    "残高検算の退避情報を解放できません: " & analysisRollbackDetail
            End If
        End If
        If analysisTransactionStarted Then
            If Not TryRollbackAnalysisForFailure( _
                       analysisTransactionStarted, analysisRollbackDetail) Then
                rollbackOK = False
                AppendOutputRollbackDetail rollbackDetail, _
                    "分析・正式表示の一括復元エラー: " & analysisRollbackDetail
            End If
        End If
        '生成表・分析・検算が全て戻った場合だけ、開始時のfreshness/Savedを戻す。
        '一部でも不成立なら旧clean表示を復活させず、後段でRecoveryへ収束させる。
        If rollbackOK And stateSnapshotCaptured Then
            If Not TryRestoreOutputStateForFailure( _
                       outputDirtyValue, analysisDirtyValue, lastBuildValue, _
                       workbookWasSaved, analysisRollbackDetail) Then
                rollbackOK = False
                AppendOutputRollbackDetail rollbackDetail, _
                    "帳票・分析更新状態の一括復元エラー: " & _
                    analysisRollbackDetail
            End If
        End If
    ElseIf outerMutationStarted Or analysisTransactionStarted Or _
           stateSnapshotCaptured Then
        rollbackOK = False
        AppendOutputRollbackDetail rollbackDetail, _
            "Excelイベント停止が未確認のため、" & _
            "生成表・分析・検算・帳票状態の退避値を再書込みしませんでした。"
    End If

    FinalizeOutputFailureState "帳票・分析更新の失敗復旧", _
        entryEventsCaptured, entryEvents, cleanupEventsStopped, _
        applicationLeaseStarted, rollbackOK, _
        recoveryStateSet, recoveryAttempted, recoveryTerminalFailure, _
        applicationStateRestoredExact, _
        reportingAllowed, rollbackDetail, restoreDetail

    If operationCommitted Then
        If reportingAllowed Then
            If recoveryStateSet Then
                TrySetOutputStatus _
                    "帳票・分析の更新は確定済みですが、後処理に失敗したため要復旧状態を記録しました。", _
                    True
            Else
                TrySetOutputStatus _
                    "帳票・分析の更新は確定済みですが、Excelの安全状態を確認できず通常操作へ戻せません。", _
                    True
            End If
            TryRecordOutputCheck "エラー", "帳票・分析更新の確定後処理", _
                "Err " & CStr(errorNumber) & ": " & errorDescription & _
                restoreDetail & " / 復元確認: " & rollbackDetail
        End If
        CompleteOutputFailureEventLease _
            "帳票・分析更新の失敗復旧", entryEventsCaptured, entryEvents, _
            reportingAllowed, rollbackOK, recoveryStateSet, _
            recoveryAttempted, recoveryTerminalFailure, _
            applicationStateRestoredExact, rollbackDetail, restoreDetail
        TryShowOutputMessage _
            "帳票・分析の更新結果は確定済みです。" & vbCrLf & _
            IIf(recoveryStateSet, _
                "後処理の失敗を要復旧状態として記録しました。", _
                "後処理後の安全状態を確認できず、通常操作へ戻せません。") & _
            vbCrLf & "現在のブックを上書きせず、C_チェックを確認してください。" & _
            restoreDetail & IIf(Len(rollbackDetail) > 0, _
                vbCrLf & "復元確認: " & rollbackDetail, vbNullString), _
            vbExclamation, "更新確定済み・後処理は要確認"
        Exit Sub
    End If
    If reportingAllowed Then
        If IsUserCancelError(errorNumber) Then
            If rollbackOK Then
                TrySetOutputStatus _
                    "帳票・分析更新を中断し、操作開始前の帳票・分析へ戻しました。"
            Else
                If recoveryStateSet Then
                    TrySetOutputStatus _
                        "帳票・分析更新を中断し、要復旧状態を記録しました。", True
                Else
                    TrySetOutputStatus _
                        "帳票・分析更新の中断後に安全状態を確認できず、通常操作へ戻せません。", True
                End If
                TryRecordOutputCheck "エラー", "帳票・分析更新の中断復旧", _
                    "Err " & CStr(errorNumber) & ": " & errorDescription & _
                    restoreDetail & " / 復元確認: " & rollbackDetail
            End If
        Else
            If rollbackOK Then
                TrySetOutputStatus _
                    "帳票・分析更新に失敗しましたが、操作開始前の帳票・分析へ戻しました。"
            Else
                If recoveryStateSet Then
                    TrySetOutputStatus _
                        "帳票・分析更新に失敗し、要復旧状態を記録しました。", True
                Else
                    TrySetOutputStatus _
                        "帳票・分析更新に失敗し、安全状態を確認できず通常操作へ戻せません。", True
                End If
                TryRecordOutputCheck "エラー", "帳票・分析更新", _
                    "Err " & CStr(errorNumber) & ": " & errorDescription & _
                    restoreDetail & " / 復元確認: " & rollbackDetail
            End If
        End If
    End If
    CompleteOutputFailureEventLease _
        "帳票・分析更新の失敗復旧", entryEventsCaptured, entryEvents, _
        reportingAllowed, rollbackOK, recoveryStateSet, _
        recoveryAttempted, recoveryTerminalFailure, _
        applicationStateRestoredExact, rollbackDetail, restoreDetail
    If IsUserCancelError(errorNumber) Then
        If rollbackOK Then
            TryShowOutputMessage _
                "帳票・分析更新を中断しました。旧帳票を更新済みとは扱いません。", _
                vbInformation
        Else
            TryShowOutputMessage _
                "帳票・分析更新を中断しましたが、操作開始前の状態へ完全には戻せませんでした。" & _
                vbCrLf & IIf(recoveryStateSet, _
                    "要復旧状態を記録しました。", _
                    "安全状態を確認できず、通常操作へ戻せません。") & _
                "現在のブックを上書きせず、C_チェックを確認してください。" & _
                restoreDetail & IIf(Len(rollbackDetail) > 0, _
                    vbCrLf & "復元確認: " & rollbackDetail, vbNullString), _
                vbExclamation, "帳票・分析更新の安全状態を要確認"
        End If
        Exit Sub
    End If
    TryShowOutputMessage _
        "帳票・分析更新中にエラーが発生しました。" & vbCrLf & _
        "Err " & errorNumber & ": " & errorDescription & restoreDetail & _
        IIf(Len(rollbackDetail) > 0, vbCrLf & "復元確認: " & rollbackDetail, _
            vbNullString), vbExclamation
End Sub

Public Sub BuildCashOperationSheet()
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim restoreDetail As String
    Dim leaseDetail As String
    Dim confirmedAnalysisWorkloadRows As Double
    Dim wsWorkCash As Worksheet, wsShop As Worksheet
    Dim workCashSnapshot As GeneratedOutputSnapshot
    Dim shopSnapshot As GeneratedOutputSnapshot
    Dim analysisTransactionStarted As Boolean, outerMutationStarted As Boolean
    Dim applicationLeaseStarted As Boolean
    Dim entryEvents As Boolean, entryEventsCaptured As Boolean
    Dim entryEventsRestored As Boolean, operationSucceeded As Boolean
    Dim cleanupEventsStopped As Boolean, reportingAllowed As Boolean
    Dim operationCommitted As Boolean
    Dim rollbackOK As Boolean, analysisRollbackOK As Boolean
    Dim recoveryStateSet As Boolean
    Dim recoveryAttempted As Boolean, recoveryTerminalFailure As Boolean
    Dim applicationStateRestoredExact As Boolean
    Dim rollbackDetail As String, analysisRollbackDetail As String
    On Error GoTo EH
    If Not TryGetOutputEnableEvents(entryEvents, leaseDetail) Then _
        Err.Raise vbObjectError + 4272, "BuildCashOperationSheet", _
                  "Excelイベントの開始状態を取得できません。 " & _
                  leaseDetail
    entryEventsCaptured = True
    If Not TryKeepOutputEventsDisabledExact(leaseDetail) Then _
        Err.Raise vbObjectError + 4278, "BuildCashOperationSheet", _
                  "Excelイベントを安全に停止できないため、" & _
                  "資金操作表作成を開始していません。 " & leaseDetail
    cleanupEventsStopped = True

    If Not RequireCashAnalysisManualModeFinished("資金操作表の作成") Then _
        GoTo CLEAN_EXIT
    If HasSelectedAnalysisDetailTransactions() Then
        MsgBox "候補詳細に、手動候補として未登録の選択取引があります。" & vbCrLf & _
               "資金操作表の作成前に、候補を登録するか選択を解除してください。" & vbCrLf & _
               "選択内容を黙って破棄することはありません。", _
               vbInformation, "手動候補の選択を完了してください"
        GoTo CLEAN_EXIT
    End If
    If Not RequireToolReady() Then GoTo CLEAN_EXIT
    If Not RequireOutputBuildCapacity("資金操作表の作成", True, False, False, _
                                      True, True, False, True) Then
        TrySetOutputStatus _
            "資金操作表の作成を開始せず中止しました。" & _
            "内部データと既存帳票は変更していません。"
        GoTo CLEAN_EXIT
    End If
    If Not RequireNoPendingAccountInput("資金操作表の作成") Then _
        GoTo CLEAN_EXIT
    If Not RequireInternalStoresSafeForWrite(False, False) Then _
        GoTo CLEAN_EXIT
    If Not EnsureCaseReadyForOutputs(True) Then GoTo CLEAN_EXIT
    AppBegin "資金操作表作成中..."
    applicationLeaseStarted = True
    BeginAnalysisOperationTransaction "資金操作表の一括作成"
    analysisTransactionStarted = True
    confirmedAnalysisWorkloadRows = AnalysisOperationConfirmedWorkloadRows()
    Set wsWorkCash = GetSheet(SH_WORK_CASH)
    Set wsShop = GetSheet(SH_SHOP_TARGET)
    CaptureGeneratedOutputSnapshot wsWorkCash, OUT_COL_INPUT_ORDER, _
        MAX_PRACTICAL_OUTPUT_ROWS, "予定資金表（操作開始時）", workCashSnapshot
    CaptureGeneratedOutputSnapshot wsShop, SHOP_TGT_LAST_COL, _
        MAX_PRACTICAL_OUTPUT_ROWS, "取扱店変換対象（操作開始時）", shopSnapshot
    outerMutationStarted = True
    MarkOutputsDirty
    BuildCashOperationSheetCore False, True
    BuildShopConversionTargetSheetCore False, True
    BuildTransactionAnalysisSheetsCore False, True, _
                                       confirmedAnalysisWorkloadRows, False
    BuildCashAnalysisViewCore True, False, True
    CommitAnalysisOperationTransaction
    operationCommitted = True
    analysisTransactionStarted = False
    outerMutationStarted = False
    If Not TryKeepOutputEventsDisabledExact(leaseDetail) Then _
        Err.Raise vbObjectError + 4275, "BuildCashOperationSheet", _
                  "確定後のExcelイベント停止を確認できません。 " & leaseDetail
    AppEnd
    applicationLeaseStarted = False
    RequireApplicationStateRestored "BuildCashOperationSheet"
    operationSucceeded = True

CLEAN_EXIT:
    entryEventsRestored = True
    If entryEventsCaptured Then
        entryEventsRestored = TryRestoreOutputEntryEvents( _
                                  entryEvents, _
                                  "資金操作表作成の終了時イベント復元", _
                                  cleanupEventsStopped, recoveryStateSet, _
                                  recoveryAttempted, recoveryTerminalFailure, _
                                  reportingAllowed, leaseDetail)
        entryEventsCaptured = False
    End If
    If Not entryEventsRestored Or recoveryStateSet Then
        TryShowOutputMessage _
            IIf(operationSucceeded, _
                "資金操作表・分析の作成結果は確定済みです。", _
                "資金操作表の作成処理は開始していません。") & vbCrLf & _
            IIf(recoveryStateSet, _
                "終了時のExcelイベント復元で異常を検出し、案件を要復旧として停止しました。", _
                "終了時のExcelイベント状態を一意に確認できません。通常操作を停止してください。") & _
            IIf(Len(leaseDetail) > 0, vbCrLf & leaseDetail, vbNullString), _
            vbExclamation, "資金操作表作成後の安全状態を要確認"
    ElseIf operationSucceeded Then
        TryShowOutputMessage _
            "資金操作表を作成しました。" & vbCrLf & _
            "上部の分析パネルで、資金移動・不明出金・不明入金を元取引と同時に確認できます。" & vbCrLf & _
            "取扱店空欄の取引行は支店名で補完し、コード形式の取扱店は別シートに整理しました。", _
            vbInformation
    End If
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    Err.Clear
    If IsOutputUpstreamRecoveryFatal(errorNumber, errorSource) Then
        Call TryKeepOutputEventsDisabledExact(leaseDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    rollbackOK = True
    cleanupEventsStopped = False
    If Not entryEventsCaptured Then
        rollbackOK = False
        AppendOutputRollbackDetail rollbackDetail, _
            "Excelイベントの開始状態を取得できていません。"
    ElseIf TryKeepOutputEventsDisabledExact(leaseDetail) Then
        cleanupEventsStopped = True
    Else
        rollbackOK = False
        AppendOutputRollbackDetail rollbackDetail, _
            "失敗復旧の開始前にExcelイベント停止を確認できません: " & _
            leaseDetail
    End If

    If operationCommitted Then
        rollbackOK = False
        AppendOutputRollbackDetail rollbackDetail, _
            "資金操作表・分析は確定済みのため、旧生成表への巻戻しは行いません。"
    ElseIf cleanupEventsStopped Then
        If outerMutationStarted Then
            If shopSnapshot.Captured Then
                If Not TryRestoreGeneratedOutputForFailure( _
                           wsShop, shopSnapshot, True, analysisRollbackDetail) Then
                    rollbackOK = False
                    AppendOutputRollbackDetail rollbackDetail, _
                        "取扱店変換対象の一括復元エラー: " & analysisRollbackDetail
                End If
            End If
            If workCashSnapshot.Captured Then
                If Not TryRestoreGeneratedOutputForFailure( _
                           wsWorkCash, workCashSnapshot, True, _
                           analysisRollbackDetail) Then
                    rollbackOK = False
                    AppendOutputRollbackDetail rollbackDetail, _
                        "予定資金表の一括復元エラー: " & analysisRollbackDetail
                End If
            End If
        End If
        If analysisTransactionStarted Then
            If Not TryRollbackAnalysisForFailure( _
                       analysisTransactionStarted, analysisRollbackDetail) Then
                rollbackOK = False
                AppendOutputRollbackDetail rollbackDetail, _
                    "分析・正式表示の一括復元エラー: " & analysisRollbackDetail
            End If
        End If
    ElseIf outerMutationStarted Or analysisTransactionStarted Then
        rollbackOK = False
        AppendOutputRollbackDetail rollbackDetail, _
            "Excelイベント停止が未確認のため、" & _
            "資金操作表・分析の退避値を再書込みしませんでした。"
    End If

    FinalizeOutputFailureState "資金操作表作成の失敗復旧", _
        entryEventsCaptured, entryEvents, cleanupEventsStopped, _
        applicationLeaseStarted, rollbackOK, _
        recoveryStateSet, recoveryAttempted, recoveryTerminalFailure, _
        applicationStateRestoredExact, _
        reportingAllowed, rollbackDetail, restoreDetail
    If Not rollbackOK And reportingAllowed Then
        TryRecordOutputCheck "エラー", "資金操作表作成", _
            "Err " & CStr(errorNumber) & ": " & errorDescription & _
            restoreDetail & " / 復元確認: " & rollbackDetail
    End If
    CompleteOutputFailureEventLease _
        "資金操作表作成の失敗復旧", entryEventsCaptured, entryEvents, _
        reportingAllowed, rollbackOK, recoveryStateSet, _
        recoveryAttempted, recoveryTerminalFailure, _
        applicationStateRestoredExact, rollbackDetail, restoreDetail
    If operationCommitted Then
        TryShowOutputMessage _
            "資金操作表・分析の作成結果は確定済みです。" & vbCrLf & _
            IIf(recoveryStateSet, _
                "後処理の失敗を要復旧状態として記録しました。", _
                "後処理後の安全状態を確認できず、通常操作へ戻せません。") & vbCrLf & _
            "現在のブックを上書きせず、C_チェックを確認してください。" & _
            restoreDetail & IIf(Len(rollbackDetail) > 0, _
                vbCrLf & "復元確認: " & rollbackDetail, vbNullString), _
            vbExclamation, "資金操作表は確定済み・後処理は要確認"
    ElseIf rollbackOK Then
        TryShowOutputMessage _
            "資金操作表作成中にエラーが発生しましたが、" & _
            "操作開始前の状態へ戻しました。" & vbCrLf & _
            "Err " & errorNumber & ": " & errorDescription, vbExclamation
    Else
        TryShowOutputMessage _
            "資金操作表作成中にエラーが発生しました。" & vbCrLf & _
            IIf(recoveryStateSet, _
                "復元不成立を要復旧状態として記録しました。", _
                "安全状態を確認できず、通常操作へ戻せません。") & vbCrLf & _
            "現在のブックを上書きせず、C_チェックを確認してください。" & vbCrLf & _
        "Err " & errorNumber & ": " & errorDescription & restoreDetail & _
        IIf(Len(rollbackDetail) > 0, vbCrLf & "復元確認: " & rollbackDetail, _
            vbNullString), vbExclamation
    End If
End Sub

Public Sub BuildCashOperationSheetCore(ByVal activateAfter As Boolean, _
                                       Optional ByVal capacityConfirmed As Boolean = False)
    Dim wsSrc As Worksheet, wsOut As Worksheet
    Dim lastR As Long, r As Long, outR As Long, outCount As Long, writeIndex As Long, c As Long
    Dim inheritanceDate As Variant
    Dim outData() As Variant, sourceData As Variant
    Dim recordType As String
    Dim showOpenRows As Boolean, showCloseRows As Boolean, showBalanceRows As Boolean, includeInheritance As Boolean
    Dim outputMutationStarted As Boolean
    Dim originalVisibility As XlSheetVisibility
    Dim outputSnapshot As GeneratedOutputSnapshot
    Dim rollbackOK As Boolean
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim rollbackDetail As String, eventDetail As String

    On Error GoTo EH
    If Not capacityConfirmed Then
        If Not RequireOutputBuildCapacity("資金操作表の作成", True, False, False, _
                                          False, False, False) Then Err.Raise 18
        capacityConfirmed = True
    End If
    Set wsSrc = GetSheet(SH_WORK_TX)
    Set wsOut = GetSheet(SH_WORK_CASH)
    originalVisibility = wsOut.Visible
    CaptureGeneratedOutputSnapshot wsOut, OUT_COL_INPUT_ORDER, _
        MAX_PRACTICAL_OUTPUT_ROWS, "資金操作表（内部生成）", outputSnapshot

    lastR = LastUsedRowInSheet(wsSrc)
    If lastR < 1 Then lastR = 1

    '設定で有効な場合だけ、相続開始日を独立行として挿入する。
    'この行は日付と摘要欄だけを表示し、後続の時系列ソートで自然な位置へ並べる。
    inheritanceDate = GetCfgDateValue(ROW_CFG_INHERITANCE_DATE)
    includeInheritance = ShowInheritanceStartRow() And IsDate(inheritanceDate)
    If includeInheritance Then outCount = 1

    showOpenRows = ShowOpenDateRow()
    showCloseRows = ShowCloseDateRow()
    showBalanceRows = ShowBalanceRowsInCashOperation()
    If lastR >= 2 Then
        sourceData = wsSrc.Range(wsSrc.Cells(2, 1), wsSrc.Cells(lastR, WORK_TX_COL_PERSON_ID)).Value2
        For r = 1 To UBound(sourceData, 1)
            recordType = CellText(sourceData(r, WORK_TX_COL_RECORD_TYPE))
            If Len(CellText(sourceData(r, WORK_TX_COL_ACCOUNT_ID))) = 0 Then _
                Err.Raise vbObjectError + 4214, "BuildCashOperationSheetCore", _
                          "W_取引 " & CStr(r + 1) & "行目に口座IDがありません。該当する登録内容を確認してください。"
            If Len(CellText(sourceData(r, WORK_TX_COL_TRANSACTION_ID))) = 0 Then _
                Err.Raise vbObjectError + 4215, "BuildCashOperationSheetCore", _
                          "W_取引 " & CStr(r + 1) & "行目に取引IDがありません。該当する登録内容を確認してください。"
            If Len(recordType) = 0 Then _
                Err.Raise vbObjectError + 4216, "BuildCashOperationSheetCore", _
                          "W_取引 " & CStr(r + 1) & "行目に行種別がありません。該当する登録内容を確認してください。"
            If ShouldOutputCashRecordType(recordType, showOpenRows, showCloseRows, showBalanceRows) Then _
                outCount = outCount + 1
        Next r
    End If

    If outCount > wsOut.Rows.Count - 1 Then _
        Err.Raise vbObjectError + 4205, "BuildCashOperationSheetCore", "資金操作表がExcelの行上限を超えます。案件を分割してください。"
    If outCount > MAX_PRACTICAL_OUTPUT_ROWS Then _
        Err.Raise vbObjectError + 4212, "BuildCashOperationSheetCore", _
                  "資金操作表が実用上限（" & Format$(MAX_PRACTICAL_OUTPUT_ROWS, "#,##0") & _
                  "行）を超えます。メモリ不足を防ぐため案件を分割してください。"
    If outCount > 0 Then
        ReDim outData(1 To outCount, 1 To OUT_COL_INPUT_ORDER)
        If includeInheritance Then
            writeIndex = writeIndex + 1
            outData(writeIndex, OUT_COL_DATE) = CDate(inheritanceDate)
            outData(writeIndex, OUT_COL_TEKIYO) = "相続開始日"
            outData(writeIndex, OUT_COL_RECORD_TYPE) = RECORD_INHERITANCE
            outData(writeIndex, OUT_COL_INPUT_ORDER) = 0
        End If
        If lastR >= 2 Then
            For r = 1 To UBound(sourceData, 1)
                recordType = CellText(sourceData(r, WORK_TX_COL_RECORD_TYPE))
                If ShouldOutputCashRecordType(recordType, showOpenRows, showCloseRows, showBalanceRows) Then
                    writeIndex = writeIndex + 1
                    For c = OUT_COL_BANK To OUT_COL_OTHER
                        outData(writeIndex, c) = sourceData(r, c)
                    Next c
                    outData(writeIndex, OUT_COL_PERSON) = DisplayPersonWithRelationship( _
                        CellText(sourceData(r, OUT_COL_PERSON)), _
                        CellText(sourceData(r, WORK_TX_COL_RELATIONSHIP)))
                    outData(writeIndex, OUT_COL_ACCOUNT_ID) = sourceData(r, WORK_TX_COL_ACCOUNT_ID)
                    outData(writeIndex, OUT_COL_TRANSACTION_ID) = sourceData(r, WORK_TX_COL_TRANSACTION_ID)
                    outData(writeIndex, OUT_COL_RECORD_TYPE) = sourceData(r, WORK_TX_COL_RECORD_TYPE)
                    outData(writeIndex, OUT_COL_INPUT_ORDER) = sourceData(r, WORK_TX_COL_INPUT_ORDER)
                End If
            Next r
        End If
        If writeIndex <> outCount Then _
            Err.Raise vbObjectError + 4208, "BuildCashOperationSheetCore", "資金操作表の件数計算が一致しません。"
    End If

    '内部データの検証と出力配列作成が終わるまで、前回の正常な帳票を消さない。
    outputMutationStarted = True
    ClearGeneratedOutputSheet wsOut, 21
    '識別子・説明文字列は、値より先に文字列書式を設定する。
    wsOut.Range("A1:E" & CStr(Application.Max(1, 1 + outCount))).NumberFormatLocal = "@"
    wsOut.Range("J1:L" & CStr(Application.Max(1, 1 + outCount))).NumberFormatLocal = "@"
    wsOut.Range("N1:P" & CStr(Application.Max(1, 1 + outCount))).NumberFormatLocal = "@"
    SetRowValues wsOut.Range("A1"), Array("銀行名", "支店名", "氏名", "科目", "口座番号", "日付", "時刻", "出金", "入金", "取扱店", "機番", "摘要欄", "残高", "口座ID", "取引ID", "行種別", "入力順")
    FormatOutputHeader wsOut.Range("A1:Q1")
    wsOut.Columns("N:Q").Hidden = True
    If outCount > 0 Then
        wsOut.Range(wsOut.Cells(2, 1), _
                    wsOut.Cells(1 + outCount, OUT_COL_INPUT_ORDER)).Value2 = outData
        VerifyGeneratedRangeValue2 wsOut, outData, 2, 1, outCount, _
                                   OUT_COL_INPUT_ORDER, "資金操作表（内部生成）", False
    End If
    outR = 2 + outCount

    If outR > 2 Then
        SortCashOperation wsOut
        FillBlankShopWithBranch wsOut
    End If
    FormatCashOperationOutputLayout wsOut
    SafeFreezeOutputHeader wsOut
    ProtectGeneratedOutputSheet wsOut, True
    SetSheetVeryHiddenSafe wsOut
    If activateAfter Then
        BuildCashAnalysisViewCore True, True, capacityConfirmed
    End If
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    Err.Clear
    If IsOutputUpstreamRecoveryFatal(errorNumber, errorSource) Then
        Call TryKeepOutputEventsDisabledExact(eventDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    rollbackOK = True
    If outputSnapshot.Captured Then
        If Not TryRestoreGeneratedOutputForFailure( _
                   wsOut, outputSnapshot, outputMutationStarted, _
                   rollbackDetail) Then
            rollbackOK = False
            rollbackDetail = _
                "資金操作表（内部生成）の復元エラー: " & rollbackDetail
        End If
    End If
    If Not rollbackOK Then _
        AppendOutputRollbackDetail rollbackDetail, _
            "Recovery強制設定は、このCoreを所有する外側transactionの" & _
            "失敗処理へ一回だけ委ねます。"
    If Len(rollbackDetail) > 0 Then _
        errorDescription = errorDescription & " / 復元確認: " & rollbackDetail
    Err.Raise errorNumber, "BuildCashOperationSheetCore", errorDescription
End Sub

Private Function ShouldOutputCashRecordType(ByVal recordType As String, ByVal showOpenRows As Boolean, _
                                            ByVal showCloseRows As Boolean, ByVal showBalanceRows As Boolean) As Boolean
    If recordType = RECORD_OPEN Then
        ShouldOutputCashRecordType = showOpenRows
    ElseIf recordType = RECORD_CLOSE Then
        ShouldOutputCashRecordType = showCloseRows
    ElseIf recordType = RECORD_BALANCE Then
        ShouldOutputCashRecordType = showBalanceRows
    Else
        ShouldOutputCashRecordType = True
    End If
End Function

Public Sub SortCashOperation(ByVal ws As Worksheet)
    Dim lastR As Long
    Dim r As Long, dataCount As Long
    Dim recordType As String, tekiyoText As String
    Dim recordTypes As Variant, tekiyoValues As Variant, timeValues As Variant, orderValues As Variant
    Dim sortData() As Variant
    Dim errorNumber As Long, errorDescription As String
    Dim cleanupErrorNumber As Long, cleanupErrorDescription As String
    Dim remainingHelperValues As Double
    If ws Is Nothing Then Exit Sub
    lastR = LastUsedRowInSheet(ws)
    If lastR < 3 Then Exit Sub

    '日付→行種別→時刻→入力順。内部ID列N:Qは削除せず、最終xlsx作成時だけ除く。
    On Error GoTo CleanUp
    Err.Clear
    SetRowValues ws.Cells(1, 18), Array("行種別順", "時刻有無", "時刻キー", "安定順")
    dataCount = lastR - 1
    recordTypes = ws.Range(ws.Cells(2, OUT_COL_RECORD_TYPE), ws.Cells(lastR, OUT_COL_RECORD_TYPE)).Value2
    tekiyoValues = ws.Range(ws.Cells(2, OUT_COL_TEKIYO), ws.Cells(lastR, OUT_COL_TEKIYO)).Value2
    timeValues = ws.Range(ws.Cells(2, OUT_COL_TIME), ws.Cells(lastR, OUT_COL_TIME)).Value2
    orderValues = ws.Range(ws.Cells(2, OUT_COL_INPUT_ORDER), ws.Cells(lastR, OUT_COL_INPUT_ORDER)).Value2
    ReDim sortData(1 To dataCount, 1 To 4)
    For r = 1 To dataCount
        recordType = CellText(recordTypes(r, 1))
        tekiyoText = CellText(tekiyoValues(r, 1))
        sortData(r, 1) = CashOperationRecordTypeOrder(recordType, tekiyoText)
        If Len(CellText(timeValues(r, 1))) > 0 Then
            sortData(r, 2) = 0
            sortData(r, 3) = CashOperationTimeSortKey(timeValues(r, 1))
        Else
            sortData(r, 2) = 1
            sortData(r, 3) = 0
        End If
        If IsNumeric(orderValues(r, 1)) Then
            sortData(r, 4) = CDbl(orderValues(r, 1))
        Else
            sortData(r, 4) = r
        End If
    Next r
    ws.Range(ws.Cells(2, 18), ws.Cells(lastR, 21)).Value2 = sortData

    With ws.Sort
        .SortFields.Clear
        .SortFields.Add Key:=ws.Range("F2:F" & lastR), SortOn:=xlSortOnValues, Order:=xlAscending, DataOption:=xlSortNormal
        .SortFields.Add Key:=ws.Range("R2:R" & lastR), SortOn:=xlSortOnValues, Order:=xlAscending, DataOption:=xlSortNormal
        .SortFields.Add Key:=ws.Range("S2:S" & lastR), SortOn:=xlSortOnValues, Order:=xlAscending, DataOption:=xlSortNormal
        .SortFields.Add Key:=ws.Range("T2:T" & lastR), SortOn:=xlSortOnValues, Order:=xlAscending, DataOption:=xlSortNormal
        .SortFields.Add Key:=ws.Range("U2:U" & lastR), SortOn:=xlSortOnValues, Order:=xlAscending, DataOption:=xlSortNormal
        .SetRange ws.Range("A1:U" & lastR)
        .Header = xlYes
        .Apply
    End With
CleanUp:
    errorNumber = Err.Number
    errorDescription = Err.Description
    If Not TryClearCashSortHelperValues( _
               ws, lastR, cleanupErrorDescription) Then _
        cleanupErrorNumber = vbObjectError + 4227
    If Not TryHideCashSortHelperColumns(ws, cleanupErrorDescription) Then
        If cleanupErrorNumber = 0 Then cleanupErrorNumber = vbObjectError + 4227
    End If
    If errorNumber <> 0 Then
        If cleanupErrorNumber <> 0 Then _
            errorDescription = errorDescription & " / 一時列の後処理エラー: " & _
                               cleanupErrorDescription
        Err.Raise errorNumber, "SortCashOperation", errorDescription
    End If
    If cleanupErrorNumber <> 0 Then _
        Err.Raise cleanupErrorNumber, "SortCashOperation", cleanupErrorDescription
End Sub

Private Function CashOperationRecordTypeOrder(ByVal recordType As String, ByVal tekiyoText As String) As Long
    If Len(recordType) = 0 Then
        If tekiyoText = "口座開設日" Then recordType = RECORD_OPEN
        If tekiyoText = "口座解約日" Then recordType = RECORD_CLOSE
        If tekiyoText = "相続開始日" Then recordType = RECORD_INHERITANCE
        If InStr(1, tekiyoText, "残高", vbTextCompare) > 0 Then recordType = RECORD_BALANCE
    End If
    Select Case recordType
        Case RECORD_OPEN: CashOperationRecordTypeOrder = 10
        Case RECORD_TRANSACTION: CashOperationRecordTypeOrder = 20
        Case RECORD_INHERITANCE: CashOperationRecordTypeOrder = 30
        Case RECORD_BALANCE: CashOperationRecordTypeOrder = 40
        Case RECORD_CLOSE: CashOperationRecordTypeOrder = 50
        Case Else: CashOperationRecordTypeOrder = 20
    End Select
End Function

Private Function CashOperationTimeSortKey(ByVal v As Variant) As Double
    On Error GoTo EH
    If IsDate(v) Then
        CashOperationTimeSortKey = CDbl(CDate(v)) - Fix(CDbl(CDate(v)))
    ElseIf IsNumeric(v) Then
        CashOperationTimeSortKey = CDbl(v) - Fix(CDbl(v))
    Else
        CashOperationTimeSortKey = 0
    End If
    Exit Function
EH:
    CashOperationTimeSortKey = 0
End Function

Public Sub BuildBalanceTransitionSheet()
    Dim wsBalance As Worksheet
    Dim balanceSnapshot As GeneratedOutputSnapshot
    Dim reconciliationSnapshotCaptured As Boolean
    Dim stateSnapshotCaptured As Boolean
    Dim outerMutationStarted As Boolean, rollbackOK As Boolean
    Dim applicationLeaseStarted As Boolean
    Dim entryEvents As Boolean, entryEventsCaptured As Boolean
    Dim entryEventsRestored As Boolean, operationSucceeded As Boolean
    Dim cleanupEventsStopped As Boolean, reportingAllowed As Boolean
    Dim operationCommitted As Boolean
    Dim recoveryStateSet As Boolean
    Dim recoveryAttempted As Boolean, recoveryTerminalFailure As Boolean
    Dim applicationStateRestoredExact As Boolean
    Dim recoveryLatchSet As Boolean, latchReadSucceeded As Boolean
    Dim outputDirtyValue As String, analysisDirtyValue As String
    Dim lastBuildValue As String, workbookWasSaved As Boolean
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim restoreDetail As String, rollbackDetail As String, cleanupDetail As String
    Dim leaseDetail As String
    On Error GoTo EH
    If Not TryGetOutputEnableEvents(entryEvents, leaseDetail) Then _
        Err.Raise vbObjectError + 4273, "BuildBalanceTransitionSheet", _
                  "Excelイベントの開始状態を取得できません。 " & _
                  leaseDetail
    entryEventsCaptured = True
    If Not TryKeepOutputEventsDisabledExact(leaseDetail) Then _
        Err.Raise vbObjectError + 4279, "BuildBalanceTransitionSheet", _
                  "Excelイベントを安全に停止できないため、" & _
                  "残高帳票作成を開始していません。 " & leaseDetail
    cleanupEventsStopped = True

    If Not RequireToolReady() Then GoTo CLEAN_EXIT
    If Not RequireOutputBuildCapacity("残高推移表・残高検算の作成", False, True, _
                                      True, False, False, False, True) Then
        TrySetOutputStatus _
            "残高推移表・残高検算の作成を開始せず中止しました。" & _
            "内部データと既存帳票は変更していません。"
        GoTo CLEAN_EXIT
    End If
    If Not RequireNoPendingAccountInput("残高推移表の作成") Then _
        GoTo CLEAN_EXIT
    If Not RequireInternalStoresSafeForWrite(False, False) Then _
        GoTo CLEAN_EXIT
    If Not EnsureCaseReadyForOutputs(True) Then GoTo CLEAN_EXIT
    AppBegin "残高推移表作成中..."
    applicationLeaseStarted = True
    '帳票transactionのsnapshotはApplication lease開始後に取得する。
    Set wsBalance = GetSheet(SH_OUTPUT_BAL)
    CaptureGeneratedOutputSnapshot wsBalance, 7 + BAL_MAX_LABELS, _
        MAX_PRACTICAL_OUTPUT_ROWS, "残高推移表（操作開始時）", balanceSnapshot
    CaptureBalanceReconciliationOperationSnapshot _
        reconciliationSnapshotCaptured
    CaptureOutputStateSnapshot outputDirtyValue, analysisDirtyValue, _
                               lastBuildValue, workbookWasSaved
    stateSnapshotCaptured = True
    outerMutationStarted = True
    MarkOutputsDirty
    BuildBalanceTransitionSheetCore True, True
    BuildBalanceReconciliationCore False, True
    operationCommitted = True
    outerMutationStarted = False
    ReleaseBalanceReconciliationOperationSnapshot _
        reconciliationSnapshotCaptured
    If Not TryKeepOutputEventsDisabledExact(leaseDetail) Then _
        Err.Raise vbObjectError + 4276, "BuildBalanceTransitionSheet", _
                  "確定後のExcelイベント停止を確認できません。 " & leaseDetail
    AppEnd
    applicationLeaseStarted = False
    RequireApplicationStateRestored "BuildBalanceTransitionSheet"
    operationSucceeded = True

CLEAN_EXIT:
    entryEventsRestored = True
    If entryEventsCaptured Then
        entryEventsRestored = TryRestoreOutputEntryEvents( _
                                  entryEvents, _
                                  "残高推移表作成の終了時イベント復元", _
                                  cleanupEventsStopped, recoveryStateSet, _
                                  recoveryAttempted, recoveryTerminalFailure, _
                                  reportingAllowed, leaseDetail)
        entryEventsCaptured = False
    End If
    If Not entryEventsRestored Or recoveryStateSet Then
        TryShowOutputMessage _
            IIf(operationSucceeded, _
                "残高推移表・残高検算の作成結果は確定済みです。", _
                "残高推移表・残高検算の作成処理は開始していません。") & vbCrLf & _
            IIf(recoveryStateSet, _
                "終了時のExcelイベント復元で異常を検出し、案件を要復旧として停止しました。", _
                "終了時のExcelイベント状態を一意に確認できません。通常操作を停止してください。") & _
            IIf(Len(leaseDetail) > 0, vbCrLf & leaseDetail, vbNullString), _
            vbExclamation, "残高帳票作成後の安全状態を要確認"
    ElseIf operationSucceeded Then
        TryShowOutputMessage _
            "残高推移表と残高検算を作成しました。" & vbCrLf & _
            "残高検算は、不一致または時刻記載なしの日計確認がある場合に表示します。", _
            vbInformation
    End If
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    Err.Clear
    If IsOutputUpstreamRecoveryFatal(errorNumber, errorSource) Then
        Call TryKeepOutputEventsDisabledExact(leaseDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    rollbackOK = True
    cleanupEventsStopped = False
    '最初にFalse exactを確認する。未確認なら以後のsheet書込みを行わない。
    If Not entryEventsCaptured Then
        rollbackOK = False
        AppendOutputRollbackDetail rollbackDetail, _
            "Excelイベントの開始状態を取得できていません。"
    ElseIf TryKeepOutputEventsDisabledExact(leaseDetail) Then
        cleanupEventsStopped = True
    Else
        rollbackOK = False
        AppendOutputRollbackDetail rollbackDetail, _
            "失敗復旧の開始前にExcelイベント停止を確認できません: " & _
            leaseDetail
    End If

    If operationCommitted Then
        rollbackOK = False
        AppendOutputRollbackDetail rollbackDetail, _
            "残高推移表・残高検算は確定済みのため、旧生成表への巻戻しは行いません。"
        If reconciliationSnapshotCaptured And cleanupEventsStopped Then
            If Not TryReleaseReconciliationSnapshot( _
                       reconciliationSnapshotCaptured, cleanupDetail) Then
                AppendOutputRollbackDetail rollbackDetail, _
                    "確定後の残高検算退避情報を解放できません: " & _
                    cleanupDetail
            End If
        End If
    ElseIf cleanupEventsStopped Then
        If outerMutationStarted Then
            If reconciliationSnapshotCaptured Then
                If Not TryRestoreReconciliationForFailure( _
                           reconciliationSnapshotCaptured, cleanupDetail) Then
                    rollbackOK = False
                    AppendOutputRollbackDetail rollbackDetail, _
                        "残高検算の操作単位復元エラー: " & cleanupDetail
                End If
            End If
            If balanceSnapshot.Captured Then
                If Not TryRestoreGeneratedOutputForFailure( _
                           wsBalance, balanceSnapshot, True, cleanupDetail) Then
                    rollbackOK = False
                    AppendOutputRollbackDetail rollbackDetail, _
                        "残高推移表の操作単位復元エラー: " & cleanupDetail
                End If
            End If
            latchReadSucceeded = _
                TryReadRollbackRecoveryLatch(recoveryLatchSet, cleanupDetail)
            If Not latchReadSucceeded Or recoveryLatchSet Then
                rollbackOK = False
                AppendOutputRollbackDetail rollbackDetail, _
                    "内側帳票処理のロールバック要復旧状態が残っています。" & _
                    IIf(Len(cleanupDetail) > 0, _
                        " " & cleanupDetail, vbNullString)
            End If
        End If
        If reconciliationSnapshotCaptured Then
            If Not TryReleaseReconciliationSnapshot( _
                       reconciliationSnapshotCaptured, cleanupDetail) Then
                rollbackOK = False
                AppendOutputRollbackDetail rollbackDetail, _
                    "残高検算の退避情報を解放できません: " & cleanupDetail
            End If
        End If
        '旧内容へのrollbackが全て成立した場合だけ旧freshnessへ戻す。
        If rollbackOK And stateSnapshotCaptured Then
            If Not TryRestoreOutputStateForFailure( _
                       outputDirtyValue, analysisDirtyValue, lastBuildValue, _
                       workbookWasSaved, cleanupDetail) Then
                rollbackOK = False
                AppendOutputRollbackDetail rollbackDetail, _
                    "帳票更新状態の復元エラー: " & cleanupDetail
            End If
        End If
    ElseIf outerMutationStarted Or reconciliationSnapshotCaptured Or _
           balanceSnapshot.Captured Or stateSnapshotCaptured Then
        rollbackOK = False
        AppendOutputRollbackDetail rollbackDetail, _
            "Excelイベント停止が未確認のため、" & _
            "残高推移表・検算・帳票状態の退避値を再書込みしませんでした。"
    End If

    FinalizeOutputFailureState "残高推移表作成の失敗復旧", _
        entryEventsCaptured, entryEvents, cleanupEventsStopped, _
        applicationLeaseStarted, rollbackOK, _
        recoveryStateSet, recoveryAttempted, recoveryTerminalFailure, _
        applicationStateRestoredExact, reportingAllowed, _
        rollbackDetail, restoreDetail

    If Not rollbackOK And reportingAllowed Then
        TryRecordOutputCheck "エラー", "残高推移表作成", _
            "Err " & CStr(errorNumber) & ": " & errorDescription & restoreDetail & _
            IIf(Len(rollbackDetail) > 0, _
                " / 復元確認: " & rollbackDetail, vbNullString)
    End If
    CompleteOutputFailureEventLease _
        "残高推移表作成の失敗復旧", entryEventsCaptured, entryEvents, _
        reportingAllowed, rollbackOK, recoveryStateSet, _
        recoveryAttempted, recoveryTerminalFailure, _
        applicationStateRestoredExact, rollbackDetail, restoreDetail
    If operationCommitted Then
        TryShowOutputMessage _
            "残高推移表・残高検算の作成結果は確定済みです。" & vbCrLf & _
            IIf(recoveryStateSet, _
                "後処理の失敗を要復旧状態として記録しました。", _
                "後処理後の安全状態を確認できず、通常操作へ戻せません。") & _
            vbCrLf & "現在のブックを上書きせず、C_チェックを確認してください。" & _
            restoreDetail & IIf(Len(rollbackDetail) > 0, _
                vbCrLf & "復元確認: " & rollbackDetail, vbNullString), _
            vbExclamation, "残高帳票は確定済み・後処理は要確認"
    ElseIf rollbackOK Then
        TryShowOutputMessage _
            "残高推移表作成中にエラーが発生しましたが、" & _
            "操作開始前の状態へ戻しました。" & vbCrLf & _
            "Err " & errorNumber & ": " & errorDescription, vbExclamation
    Else
        TryShowOutputMessage _
            "残高推移表作成中にエラーが発生しました。" & vbCrLf & _
            IIf(recoveryStateSet, _
                "復元不成立を要復旧状態として記録しました。", _
                "安全状態を確認できず、通常操作へ戻せません。") & vbCrLf & _
            "現在のブックを上書きせず、C_チェックを確認してください。" & vbCrLf & _
            "Err " & errorNumber & ": " & errorDescription & restoreDetail & _
            IIf(Len(rollbackDetail) > 0, _
                vbCrLf & "復元確認: " & rollbackDetail, vbNullString), _
            vbExclamation
    End If
End Sub

Private Function TryClearCashSortHelperValues( _
        ByVal ws As Worksheet, ByVal lastR As Long, _
        ByRef detailText As String) As Boolean
    Dim remainingHelperValues As Double
    detailText = vbNullString
    On Error GoTo EH
    ws.Range("R1:U" & lastR).ClearContents
    remainingHelperValues = Application.CountA(ws.Range("R1:U" & lastR))
    If remainingHelperValues <> 0 Then _
        Err.Raise vbObjectError + 4227, "TryClearCashSortHelperValues", _
                  "並べ替え用の一時値を消去できませんでした。"
    TryClearCashSortHelperValues = True
    Exit Function
EH:
    detailText = "一時値の消去: Err " & CStr(Err.Number) & ": " & Err.Description
    Err.Clear
End Function

Private Function TryHideCashSortHelperColumns( _
        ByVal ws As Worksheet, ByRef detailText As String) As Boolean
    Dim addedDetail As String
    On Error GoTo EH
    ws.Columns("N:U").Hidden = True
    If Not ws.Columns("N:U").Hidden Then _
        Err.Raise vbObjectError + 4227, "TryHideCashSortHelperColumns", _
                  "内部列を再び非表示にできませんでした。"
    TryHideCashSortHelperColumns = True
    Exit Function
EH:
    addedDetail = "内部列の非表示: Err " & CStr(Err.Number) & ": " & _
                  Err.Description
    If Len(detailText) > 0 Then detailText = detailText & " / "
    detailText = detailText & addedDetail
    Err.Clear
End Function

Public Sub BuildBalanceTransitionSheetCore(ByVal activateAfter As Boolean, _
                                           Optional ByVal capacityConfirmed As Boolean = False)
    Dim wsSrc As Worksheet, wsAcc As Worksheet, wsTx As Worksheet, wsOut As Worksheet
    Dim labels As Collection, dates As Collection
    Dim personKeys As Collection, personAccountKeys As Collection
    Dim lastR As Long, lastAccR As Long, lastTxR As Long
    Dim r As Long, outR As Long, i As Long
    Dim personKey As Variant, accKey As Variant
    Dim firstR As Long, accountCount As Long
    Dim requiredLastRow As Double, outputRows As Long, outputLastCol As Long
    Dim totals() As Variant, missingCounts() As Long, val As Variant
    Dim accountData As Variant, balanceData As Variant, transactionData As Variant
    Dim derivedBalanceData As Variant, outputData() As Variant
    Dim accountRowByKey As Object, accountKeysByPerson As Object
    Dim masterRowByID As Object, balanceByDate As Object, memoByAccount As Object
    Dim personAliases As Object, personRelationships As Object
    Dim balanceLookupKey As String, accountID As String, personKeyText As String
    Dim accountKeyText As String, memoText As String, derivationProblems As String
    Dim firstDerivedYear As Long, lastDerivedYear As Long
    Dim outputMutationStarted As Boolean
    Dim originalVisibility As XlSheetVisibility
    Dim outputSnapshot As GeneratedOutputSnapshot
    Dim rollbackOK As Boolean
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim rollbackDetail As String, eventDetail As String

    On Error GoTo EH
    If Not capacityConfirmed Then
        If Not RequireOutputBuildCapacity("残高推移表の作成", False, True, False, _
                                          False, False, False) Then Err.Raise 18
    End If
    Set wsSrc = GetSheet(SH_WORK_BAL)
    Set wsAcc = GetSheet(SH_WORK_ACCOUNT)
    Set wsTx = GetSheet(SH_WORK_TX)
    Set wsOut = GetSheet(SH_OUTPUT_BAL)
    originalVisibility = wsOut.Visible
    CaptureGeneratedOutputSnapshot wsOut, 7 + BAL_MAX_LABELS, _
        MAX_PRACTICAL_OUTPUT_ROWS, "残高推移表", outputSnapshot

    BuildBalanceCollections labels, dates
    CapBalanceCollections labels, dates, BAL_MAX_LABELS

    Set personKeys = New Collection
    Set accountRowByKey = CreateObject("Scripting.Dictionary")
    Set accountKeysByPerson = CreateObject("Scripting.Dictionary")
    Set masterRowByID = CreateObject("Scripting.Dictionary")
    Set balanceByDate = CreateObject("Scripting.Dictionary")
    Set memoByAccount = CreateObject("Scripting.Dictionary")
    Set personAliases = CreateObject("Scripting.Dictionary")
    Set personRelationships = CreateObject("Scripting.Dictionary")
    accountRowByKey.CompareMode = vbTextCompare
    accountKeysByPerson.CompareMode = vbTextCompare
    masterRowByID.CompareMode = vbTextCompare
    balanceByDate.CompareMode = vbTextCompare
    memoByAccount.CompareMode = vbTextCompare
    personAliases.CompareMode = vbTextCompare
    personRelationships.CompareMode = vbTextCompare

    '残高が未入力の口座も必ず表示するため、口座一覧はW_残高ではなくW_口座から作る。
    lastAccR = LastUsedRowInSheet(wsAcc)
    If lastAccR >= 2 Then
        accountData = wsAcc.Range(wsAcc.Cells(2, 1), wsAcc.Cells(lastAccR, ACC_COL_TRANSFER_ID)).Value2
        For r = 1 To UBound(accountData, 1)
            accountID = CellText(accountData(r, ACC_COL_ID))
            If Len(accountID) = 0 Then
                Err.Raise vbObjectError + 4217, "BuildBalanceTransitionSheetCore", _
                          "W_口座 " & CStr(r + 1) & "行目に口座IDがありません。該当する登録内容を確認してください。"
            End If
            If masterRowByID.Exists(accountID) Then
                Err.Raise vbObjectError + 4201, "BuildBalanceTransitionSheetCore", "口座IDが重複しています: " & accountID
            End If
            masterRowByID.Add accountID, r
            personKeyText = MakeBalancePersonKey( _
                CellText(accountData(r, ACC_COL_PERSON_ID)), CellText(accountData(r, ACC_COL_PERSON)))
            AddBalancePersonIdentity CellText(accountData(r, ACC_COL_PERSON)), _
                                     CellText(accountData(r, ACC_COL_RELATIONSHIP)), _
                                     personKeyText, personAliases, personRelationships
            accountKeyText = personKeyText & Chr$(30) & accountID
            If accountRowByKey.Exists(accountKeyText) Then
                Err.Raise vbObjectError + 4201, "BuildBalanceTransitionSheetCore", "口座IDが重複しています: " & accountID
            End If
            AddUniqueCollection personKeys, personKeyText
            If accountKeysByPerson.Exists(personKeyText) Then
                Set personAccountKeys = accountKeysByPerson(personKeyText)
            Else
                Set personAccountKeys = New Collection
                accountKeysByPerson.Add personKeyText, personAccountKeys
            End If
            personAccountKeys.Add accountKeyText
            accountRowByKey.Add accountKeyText, r
            accountCount = accountCount + 1
        Next r
    End If

    requiredLastRow = 1# + CDbl(accountCount) + 6# * CDbl(personKeys.Count)
    If requiredLastRow > CDbl(wsOut.Rows.Count) Then
        Err.Raise vbObjectError + 4206, "BuildBalanceTransitionSheetCore", _
                  "残高推移表がExcelの行上限を超えます。案件を分割してください。"
    End If
    If requiredLastRow > CDbl(MAX_PRACTICAL_OUTPUT_ROWS) Then
        Err.Raise vbObjectError + 4213, "BuildBalanceTransitionSheetCore", _
                  "残高推移表が実用上限（" & Format$(MAX_PRACTICAL_OUTPUT_ROWS, "#,##0") & _
                  "行）を超えます。メモリ不足を防ぐため案件を分割してください。"
    End If

    lastR = LastUsedRowInSheet(wsSrc)
    If lastR >= 2 Then
        balanceData = wsSrc.Range(wsSrc.Cells(2, 1), wsSrc.Cells(lastR, WORK_BAL_COL_PERSON_ID)).Value2
        For r = 1 To UBound(balanceData, 1)
            accountID = CellText(balanceData(r, WORK_BAL_COL_ACCOUNT_ID))
            If Len(accountID) = 0 Then
                Err.Raise vbObjectError + 4218, "BuildBalanceTransitionSheetCore", _
                          "W_残高 " & CStr(r + 1) & "行目に口座IDがありません。該当する登録内容を確認してください。"
            End If
            If Len(CellText(balanceData(r, WORK_BAL_COL_BALANCE_ID))) = 0 Then
                Err.Raise vbObjectError + 4219, "BuildBalanceTransitionSheetCore", _
                          "W_残高 " & CStr(r + 1) & "行目に残高IDがありません。該当する登録内容を確認してください。"
            End If
            If Not IsDate(balanceData(r, 8)) Then
                Err.Raise vbObjectError + 4207, "BuildBalanceTransitionSheetCore", _
                          "残高基準日が不正です: " & accountID & " / W_残高 " & CStr(r + 1) & "行目"
            End If
            If Not masterRowByID.Exists(accountID) Then
                Err.Raise vbObjectError + 4202, "BuildBalanceTransitionSheetCore", "残高が存在しない口座IDを参照しています: " & accountID
            End If
            balanceLookupKey = BalanceDateLookupKey(accountID, balanceData(r, 8))
            If balanceByDate.Exists(balanceLookupKey) Then
                Err.Raise vbObjectError + 4203, "BuildBalanceTransitionSheetCore", _
                          "同一口座・同一基準日の残高が重複しています: " & accountID & " / " & _
                          Format$(CDate(balanceData(r, 8)), "yyyy/m/d")
            End If
            balanceByDate.Add balanceLookupKey, balanceData(r, 10)
            memoText = CellText(balanceData(r, 11))
            If Len(memoText) > 0 Then
                If memoByAccount.Exists(accountID) Then
                    If StrComp(CStr(memoByAccount(accountID)), memoText, vbBinaryCompare) <> 0 Then
                        Err.Raise vbObjectError + 4220, "BuildBalanceTransitionSheetCore", _
                                  "同一口座の残高メモに異なる内容があります: " & accountID
                    End If
                Else
                    memoByAccount.Add accountID, memoText
                End If
            End If
        Next r
    End If

    'W_取引の取引後残高から、表示対象の年末だけを派生する。W_残高は更新せず、
    '同じ口座・年末日に独立残高がある場合は一致を必須にしてから辞書へ統合する。
    For i = 1 To dates.Count
        If IsDate(dates(i)) Then
            If Month(CDate(dates(i))) = 12 And Day(CDate(dates(i))) = 31 Then
                If firstDerivedYear = 0 Then firstDerivedYear = Year(CDate(dates(i)))
                lastDerivedYear = Year(CDate(dates(i)))
            End If
        End If
    Next i
    If firstDerivedYear > 0 Then
        lastTxR = LastUsedRowInSheet(wsTx)
        If lastTxR >= 2 Then _
            transactionData = wsTx.Range( _
                wsTx.Cells(2, 1), wsTx.Cells(lastTxR, WORK_TX_COL_PERSON_ID)).Value2
        If Not DeriveYearEndBalancesFromTransactions( _
                   transactionData, firstDerivedYear, lastDerivedYear, _
                   derivedBalanceData, derivationProblems) Then _
            Err.Raise vbObjectError + 4260, "BuildBalanceTransitionSheetCore", _
                      "取引後残高から年末残高を派生できません: " & _
                      Left$(Replace(derivationProblems, vbCrLf, " / "), 3000)
        MergeDerivedYearEndBalances balanceByDate, masterRowByID, _
                                    derivedBalanceData
    End If

    outputRows = CLng(requiredLastRow)
    outputLastCol = 7 + labels.Count
    ReDim outputData(1 To outputRows, 1 To outputLastCol)
    outputData(1, 1) = "残高推移表"
    outR = 3
    For Each personKey In personKeys
        outputData(outR, 1) = "氏名: " & BalancePersonDisplay(CStr(personKey), personAliases, personRelationships)
        outR = outR + 1

        outputData(outR, 1) = "銀行名"
        outputData(outR, 2) = "支店名"
        outputData(outR, 3) = "科目"
        outputData(outR, 4) = "口座番号"
        outputData(outR, 5) = "口座開設日"
        outputData(outR, 6) = "口座解約日"
        For i = 1 To labels.Count
            outputData(outR, 6 + i) = labels(i)
        Next i
        outputData(outR, outputLastCol) = "その他"
        ReDim totals(1 To labels.Count)
        ReDim missingCounts(1 To labels.Count)
        outR = outR + 1

        If accountKeysByPerson.Exists(CStr(personKey)) Then
            Set personAccountKeys = accountKeysByPerson(CStr(personKey))
            For Each accKey In personAccountKeys
                firstR = CLng(accountRowByKey(CStr(accKey)))
                accountID = CellText(accountData(firstR, ACC_COL_ID))
                outputData(outR, 1) = accountData(firstR, ACC_COL_BANK)
                outputData(outR, 2) = accountData(firstR, ACC_COL_BRANCH)
                outputData(outR, 3) = accountData(firstR, ACC_COL_TYPE)
                outputData(outR, 4) = accountData(firstR, ACC_COL_NO)
                outputData(outR, 5) = accountData(firstR, ACC_COL_OPEN_DATE)
                outputData(outR, 6) = accountData(firstR, ACC_COL_CLOSE_DATE)
                For i = 1 To labels.Count
                    If Not AccountExistsAtDate(CDate(dates(i)), accountData(firstR, ACC_COL_OPEN_DATE), _
                                               accountData(firstR, ACC_COL_CLOSE_DATE)) Then
                        outputData(outR, 6 + i) = "-"
                    Else
                        balanceLookupKey = BalanceDateLookupKey(accountID, dates(i))
                        If balanceByDate.Exists(balanceLookupKey) Then
                            val = balanceByDate(balanceLookupKey)
                            If HasText(val) And IsNumeric(val) Then
                                outputData(outR, 6 + i) = val
                                If IsEmpty(totals(i)) Then
                                    totals(i) = CDec(val)
                                Else
                                    totals(i) = CDec(totals(i)) + CDec(val)
                                End If
                            Else
                                missingCounts(i) = missingCounts(i) + 1
                            End If
                        Else
                            '口座が存在するのに残高がない時は0とみなさず、未確認として集計する。
                            missingCounts(i) = missingCounts(i) + 1
                        End If
                    End If
                Next i
                If memoByAccount.Exists(accountID) Then outputData(outR, outputLastCol) = memoByAccount(accountID)
                outR = outR + 1
            Next accKey
        End If

        outputData(outR, 1) = "未確認口座数"
        For i = 1 To labels.Count
            outputData(outR, 6 + i) = missingCounts(i)
        Next i
        outR = outR + 1

        outputData(outR, 1) = "合計"
        For i = 1 To labels.Count
            If missingCounts(i) = 0 Then
                If IsEmpty(totals(i)) Then
                    outputData(outR, 6 + i) = 0
                Else
                    outputData(outR, 6 + i) = totals(i)
                End If
            Else
                outputData(outR, 6 + i) = "未確認"
            End If
        Next i
        outR = outR + 1

        outputData(outR, 1) = "前時点比"
        For i = 2 To labels.Count
            If missingCounts(i) = 0 And missingCounts(i - 1) = 0 Then
                If IsEmpty(totals(i)) And IsEmpty(totals(i - 1)) Then
                    outputData(outR, 6 + i) = 0
                ElseIf IsEmpty(totals(i)) Then
                    outputData(outR, 6 + i) = -CDec(totals(i - 1))
                ElseIf IsEmpty(totals(i - 1)) Then
                    outputData(outR, 6 + i) = CDec(totals(i))
                Else
                    outputData(outR, 6 + i) = CDec(totals(i)) - CDec(totals(i - 1))
                End If
            Else
                outputData(outR, 6 + i) = "未確認"
            End If
        Next i
        outR = outR + 2
    Next personKey
    If outR - 2 <> outputRows Then _
        Err.Raise vbObjectError + 4211, "BuildBalanceTransitionSheetCore", "残高推移表の件数計算が一致しません。"

    '集計・整合性検証の完了後にまとめて置き換える。
    outputMutationStarted = True
    ClearGeneratedOutputSheet wsOut, 27
    '口座番号などの識別文字列は値より先に文字列書式を設定し、先頭ゼロと式様文字列を保つ。
    wsOut.Range(wsOut.Cells(1, 1), wsOut.Cells(outputRows, outputLastCol)).NumberFormatLocal = "#,##0.########"
    wsOut.Range(wsOut.Cells(1, 1), wsOut.Cells(outputRows, 4)).NumberFormatLocal = "@"
    wsOut.Range(wsOut.Cells(1, 5), wsOut.Cells(outputRows, 6)).NumberFormatLocal = "yyyy/m/d"
    wsOut.Range(wsOut.Cells(1, outputLastCol), _
                wsOut.Cells(outputRows, outputLastCol)).NumberFormatLocal = "@"
    wsOut.Range(wsOut.Cells(1, 1), wsOut.Cells(outputRows, outputLastCol)).Value2 = outputData
    VerifyGeneratedRangeValue2 wsOut, outputData, 1, 1, outputRows, _
                               outputLastCol, "残高推移表", False
    FormatBalanceTransitionOutputLayout wsOut
    ProtectGeneratedOutputSheet wsOut, True
    If activateAfter Then
        wsOut.Visible = xlSheetVisible
        wsOut.Activate
    Else
        wsOut.Visible = originalVisibility
    End If
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    Err.Clear
    If IsOutputUpstreamRecoveryFatal(errorNumber, errorSource) Then
        Call TryKeepOutputEventsDisabledExact(eventDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    rollbackOK = True
    If outputSnapshot.Captured Then
        If Not TryRestoreGeneratedOutputForFailure( _
                   wsOut, outputSnapshot, outputMutationStarted, _
                   rollbackDetail) Then
            rollbackOK = False
            rollbackDetail = "残高推移表の復元エラー: " & rollbackDetail
        End If
    End If
    If Not rollbackOK Then _
        AppendOutputRollbackDetail rollbackDetail, _
            "Recovery強制設定は、このCoreを所有する外側transactionの" & _
            "失敗処理へ一回だけ委ねます。"
    If Len(rollbackDetail) > 0 Then _
        errorDescription = errorDescription & " / 復元確認: " & rollbackDetail
    Err.Raise errorNumber, "BuildBalanceTransitionSheetCore", errorDescription
End Sub

Private Sub MergeDerivedYearEndBalances( _
        ByVal balanceByDate As Object, ByVal masterRowByID As Object, _
        ByRef derivedBalanceData As Variant)
    Dim r As Long
    Dim accountID As String, lookupKey As String
    Dim independentValue As Variant, derivedValue As Variant
    Dim targetDate As Date, sourceDateText As String, sourceTransactionID As String
    Dim conflictDetail As String
    If balanceByDate Is Nothing Or masterRowByID Is Nothing Then _
        Err.Raise vbObjectError + 4261, "MergeDerivedYearEndBalances", _
                  "年末残高の統合辞書を取得できません。"
    If Not IsArray(derivedBalanceData) Then Exit Sub

    For r = LBound(derivedBalanceData, 1) To UBound(derivedBalanceData, 1)
        accountID = CellText(derivedBalanceData( _
            r, DERIVED_YEAR_END_COL_ACCOUNT_ID))
        If Len(accountID) = 0 Or Not masterRowByID.Exists(accountID) Then _
            Err.Raise vbObjectError + 4262, "MergeDerivedYearEndBalances", _
                      "派生年末残高が存在しない口座IDを参照しています: " & accountID
        If Not IsDate(derivedBalanceData(r, DERIVED_YEAR_END_COL_DATE)) Then _
            Err.Raise vbObjectError + 4262, "MergeDerivedYearEndBalances", _
                      "派生年末残高の日付が不正です: " & accountID
        targetDate = CDate(derivedBalanceData(r, DERIVED_YEAR_END_COL_DATE))
        derivedValue = derivedBalanceData(r, DERIVED_YEAR_END_COL_BALANCE)
        If Not HasText(derivedValue) Or Not IsNumeric(derivedValue) Then _
            Err.Raise vbObjectError + 4262, "MergeDerivedYearEndBalances", _
                      "派生年末残高が数値ではありません: " & accountID & " / " & _
                      Format$(targetDate, "yyyy/m/d")
        lookupKey = BalanceDateLookupKey(accountID, targetDate)
        If balanceByDate.Exists(lookupKey) Then
            independentValue = balanceByDate(lookupKey)
            If HasText(independentValue) Then
                If Not IsNumeric(independentValue) Or _
                   CDec(independentValue) <> CDec(derivedValue) Then
                    sourceDateText = CellText(derivedBalanceData( _
                        r, DERIVED_YEAR_END_COL_SOURCE_DATE))
                    sourceTransactionID = CellText(derivedBalanceData( _
                        r, DERIVED_YEAR_END_COL_TRANSACTION_ID))
                    conflictDetail = "口座ID=" & accountID & _
                        " / 対象年末=" & Format$(targetDate, "yyyy/m/d") & _
                        " / W_残高=" & CellText(independentValue) & _
                        " / 取引後残高派生=" & CellText(derivedValue) & _
                        " / 根拠日=" & sourceDateText & _
                        " / 取引ID=" & sourceTransactionID
                    TryRecordOutputCheck "エラー", "年末残高の不整合", _
                                         conflictDetail
                    Err.Raise vbObjectError + 4263, _
                              "MergeDerivedYearEndBalances", _
                              "独立入力した年末残高と取引後残高の派生値が一致しません: " & _
                              conflictDetail
                End If
                '一致時は独立W_残高を1件だけ使用し、重複表示しない。
            Else
                balanceByDate(lookupKey) = derivedValue
            End If
        Else
            balanceByDate.Add lookupKey, derivedValue
        End If
    Next r
End Sub

Public Sub ClearGeneratedOutputSheet(ByVal ws As Worksheet, ByVal lastColumn As Long)
    Dim clearLastRow As Long
    Dim searchRange As Range, foundCell As Range
    If ws Is Nothing Then Exit Sub
    If lastColumn < 1 Then Err.Raise vbObjectError + 4209, "ClearGeneratedOutputSheet", "消去列数が不正です。"
    ws.Unprotect Password:=TOOL_PASSWORD
    DeleteToolShapes ws, True
    If ws.Shapes.Count > 0 Then _
        Err.Raise vbObjectError + 4210, "ClearGeneratedOutputSheet", "出力シートの図形を消去できません: " & ws.Name
    Set searchRange = ws.Range(ws.Cells(1, 1), ws.Cells(ws.Rows.Count, lastColumn))
    Set foundCell = searchRange.Find(What:="*", After:=searchRange.Cells(1, 1), LookIn:=xlFormulas, _
                                     LookAt:=xlPart, SearchOrder:=xlByRows, SearchDirection:=xlPrevious, _
                                     MatchCase:=False, MatchByte:=False, SearchFormat:=False)
    If Not foundCell Is Nothing Then clearLastRow = foundCell.Row
    If clearLastRow < 1 Then clearLastRow = 1
    With ws.Range(ws.Cells(1, 1), ws.Cells(clearLastRow, lastColumn))
        .UnMerge
        .Clear
    End With
    If ws.AutoFilterMode Then ws.AutoFilterMode = False
End Sub

Public Sub SecureGeneratedOutputAfterFailure(ByVal ws As Worksheet, _
                                             ByVal outputWasModified As Boolean, _
                                             ByVal originalVisibility As XlSheetVisibility)
    '生成途中の表を、利用者が正常な完成表と誤認できる状態で残さない。
    'このhelperはRecoveryを所有しない。失敗はFalse exactのまま外側ownerへ返す。
    Dim detailText As String, outputLabel As String
    Dim applicationProblems As String
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim entryEvents As Boolean, entryEventsCaptured As Boolean
    Dim eventsStopped As Boolean
    If ws Is Nothing Then Exit Sub
    On Error GoTo EH
    If Not TryGetOutputEnableEvents(entryEvents, detailText) Then _
        Err.Raise vbObjectError + 4265, "SecureGeneratedOutputAfterFailure", _
                  "Excelイベントの開始状態を取得できません: " & detailText
    entryEventsCaptured = True
    If Not TryKeepOutputEventsDisabledExact(detailText) Then _
        Err.Raise vbObjectError + 4265, "SecureGeneratedOutputAfterFailure", _
                  "失敗後保護の開始前にExcelイベントを停止できません: " & _
                  detailText
    outputLabel = ws.Name
    EmergencyProtectToolSheet ws
    If outputWasModified Then
        SetSheetVeryHiddenSafe ws
        If ws.Visible <> xlSheetVeryHidden Then _
            Err.Raise vbObjectError + 4265, "SecureGeneratedOutputAfterFailure", _
                      "生成途中の帳票を非公開にできません。"
    Else
        ws.Visible = originalVisibility
        If ws.Visible <> originalVisibility Then _
            Err.Raise vbObjectError + 4265, "SecureGeneratedOutputAfterFailure", _
                      "帳票の表示状態を操作開始前へ戻せません。"
    End If
    If Not TryKeepOutputEventsDisabledExact(detailText) Then _
        Err.Raise vbObjectError + 4265, "SecureGeneratedOutputAfterFailure", _
                  "失敗後保護の確認後にExcelイベントを停止できません: " & _
                  detailText
    If entryEvents Then
        If Not AppStateIsRestored(applicationProblems) Then _
            Err.Raise vbObjectError + 4265, _
                      "SecureGeneratedOutputAfterFailure", _
                      "Application状態が未復元のためExcelイベントを再開しません: " & _
                      applicationProblems
        If Not TryKeepOutputEventsDisabledExact(detailText) Then _
            Err.Raise vbObjectError + 4265, _
                      "SecureGeneratedOutputAfterFailure", _
                      "Excelイベント再開直前のFalse exactを確認できません: " & _
                      detailText
        If Not TrySetOutputEnableEventsExact(entryEvents, detailText) Then _
            Err.Raise vbObjectError + 4265, _
                      "SecureGeneratedOutputAfterFailure", _
                      "Excelイベントの開始値を復元できません: " & detailText
    End If
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    Err.Clear
    If IsOutputUpstreamRecoveryFatal(errorNumber, errorSource) Then
        Call TryKeepOutputEventsDisabledExact(detailText)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    eventsStopped = TryKeepOutputEventsDisabledExact(detailText)
    If Not eventsStopped Then _
        AppendOutputRollbackDetail errorDescription, _
            "外側Recovery ownerへの伝播前にExcelイベントFalse収束を確認できません: " & _
            detailText
    If Len(outputLabel) > 0 Then _
        AppendOutputRollbackDetail errorDescription, _
            "対象帳票=" & outputLabel
    Err.Raise errorNumber, errorSource, errorDescription
End Sub

Public Sub VerifyGeneratedRangeValue2(ByVal ws As Worksheet, ByRef expectedValues As Variant, _
                                      ByVal firstRow As Long, ByVal firstColumn As Long, _
                                      ByVal rowCount As Long, ByVal columnCount As Long, _
                                      ByVal labelText As String, _
                                      Optional ByVal requireExactVarType As Boolean = False)
    Const VERIFY_CHUNK_ROWS As Long = 2000
    Dim actualValues As Variant
    Dim chunkRange As Range, formulaCell As Range
    Dim expectedRowBase As Long, expectedColumnBase As Long
    Dim chunkFirst As Long, chunkCount As Long
    Dim r As Long, c As Long
    Dim expectedValue As Variant, actualValue As Variant
    Dim cellAddress As String

    If ws Is Nothing Then _
        Err.Raise vbObjectError + 4221, "VerifyGeneratedRangeValue2", _
                  labelText & "の出力先を確認できません。"
    If rowCount < 1 Or columnCount < 1 Then Exit Sub
    If Not IsArray(expectedValues) Then _
        Err.Raise vbObjectError + 4222, "VerifyGeneratedRangeValue2", _
                  labelText & "の期待値配列が不正です。"
    If UBound(expectedValues, 1) - LBound(expectedValues, 1) + 1 < rowCount Or _
       UBound(expectedValues, 2) - LBound(expectedValues, 2) + 1 < columnCount Then _
        Err.Raise vbObjectError + 4223, "VerifyGeneratedRangeValue2", _
                  labelText & "の期待値配列サイズが不足しています。"

    expectedRowBase = LBound(expectedValues, 1)
    expectedColumnBase = LBound(expectedValues, 2)
    For chunkFirst = 0 To rowCount - 1 Step VERIFY_CHUNK_ROWS
        chunkCount = CLng(Application.Min(VERIFY_CHUNK_ROWS, rowCount - chunkFirst))
        Set chunkRange = ws.Range( _
            ws.Cells(firstRow + chunkFirst, firstColumn), _
            ws.Cells(firstRow + chunkFirst + chunkCount - 1, _
                     firstColumn + columnCount - 1))
        Set formulaCell = Nothing
        If Not TryFindFirstFormulaCell(chunkRange, formulaCell) Then _
            Err.Raise vbObjectError + 4225, "VerifyGeneratedRangeValue2", _
                      labelText & "の数式検査を完了できません。"
        If Not formulaCell Is Nothing Then _
            Err.Raise vbObjectError + 4226, "VerifyGeneratedRangeValue2", _
                      labelText & "に数式として解釈された値があります: " & _
                      formulaCell.Address(False, False)
        actualValues = chunkRange.Value2
        For r = 1 To chunkCount
            For c = 1 To columnCount
                expectedValue = expectedValues(expectedRowBase + chunkFirst + r - 1, _
                                               expectedColumnBase + c - 1)
                If chunkCount = 1 And columnCount = 1 Then
                    actualValue = actualValues
                Else
                    actualValue = actualValues(r, c)
                End If
                If Not GeneratedValuesMatch(expectedValue, actualValue, requireExactVarType) Then
                    cellAddress = ws.Cells(firstRow + chunkFirst + r - 1, _
                                           firstColumn + c - 1).Address(False, False)
                    Err.Raise vbObjectError + 4224, "VerifyGeneratedRangeValue2", _
                              labelText & "の書込み確認が一致しません: " & cellAddress & _
                              "（期待型 " & CStr(VarType(expectedValue)) & _
                              " / 実値型 " & CStr(VarType(actualValue)) & "）"
                End If
            Next c
        Next r
    Next chunkFirst
End Sub

Private Function GeneratedValuesMatch(ByVal expectedValue As Variant, ByVal actualValue As Variant, _
                                      ByVal requireExactVarType As Boolean) As Boolean
    Dim expectedKind As Long, actualKind As Long
    expectedKind = GeneratedValueKind(expectedValue)
    actualKind = GeneratedValueKind(actualValue)
    If expectedKind <> actualKind Then Exit Function
    If requireExactVarType Then
        If VarType(expectedValue) <> VarType(actualValue) Then Exit Function
    End If
    Select Case expectedKind
        Case vbEmpty, vbNull
            GeneratedValuesMatch = True
        Case vbString
            GeneratedValuesMatch = (StrComp(CStr(expectedValue), CStr(actualValue), vbBinaryCompare) = 0)
        Case vbBoolean
            GeneratedValuesMatch = (CBool(expectedValue) = CBool(actualValue))
        Case vbDouble
            GeneratedValuesMatch = (CDbl(expectedValue) = CDbl(actualValue))
        Case Else
            'Excelエラー値・配列・オブジェクトは、提出用または生成表のセル値として認めない。
            GeneratedValuesMatch = False
    End Select
End Function

Private Function GeneratedValueKind(ByVal valueIn As Variant) As Long
    Select Case VarType(valueIn)
        Case vbEmpty
            GeneratedValueKind = vbEmpty
        Case vbNull
            GeneratedValueKind = vbNull
        Case vbString
            GeneratedValueKind = vbString
        Case vbBoolean
            GeneratedValueKind = vbBoolean
        Case vbByte, vbInteger, vbLong, vbSingle, vbDouble, vbCurrency, vbDecimal, vbDate
            GeneratedValueKind = vbDouble
        Case Else
            GeneratedValueKind = VarType(valueIn)
    End Select
End Function

Private Function MakeBalancePersonKey(ByVal personID As String, ByVal personName As String) As String
    personID = CellText(personID)
    personName = CellText(personName)
    If Len(personID) = 0 Then _
        Err.Raise vbObjectError + 4228, "MakeBalancePersonKey", _
                  "口座名義人「" & personName & _
                  "」の人物IDがありません。氏名では代替せず、人物整合性を修正してください。"
    If Not IsInternalIdValue(personID, "P") Then _
        Err.Raise vbObjectError + 4229, "MakeBalancePersonKey", _
                  "人物IDの形式が不正です: " & personID
    If Len(NormalizePersonNameKey(personName)) = 0 Then _
        Err.Raise vbObjectError + 4230, "MakeBalancePersonKey", _
                  "人物ID " & personID & " の口座名義人がありません。"
    MakeBalancePersonKey = personID
End Function

Private Sub AddBalancePersonIdentity(ByVal personName As String, ByVal relationshipText As String, _
                                     ByVal personKey As String, _
                                     ByVal aliasesByPerson As Object, ByVal relationshipsByPerson As Object)
    Dim aliases As Object
    personName = CellText(personName)
    relationshipText = CellText(relationshipText)
    If aliasesByPerson.Exists(personKey) Then
        Set aliases = aliasesByPerson(personKey)
    Else
        Set aliases = CreateObject("Scripting.Dictionary")
        aliases.CompareMode = vbTextCompare
        aliasesByPerson.Add personKey, aliases
    End If
    If Len(personName) > 0 Then aliases(personName) = True
    If Len(relationshipText) > 0 Then
        If relationshipsByPerson.Exists(personKey) Then
            If NormalizeRelationshipKey(CStr(relationshipsByPerson(personKey))) <> _
               NormalizeRelationshipKey(relationshipText) Then
                Err.Raise vbObjectError + 4204, "BuildBalanceTransitionSheetCore", _
                          "同一人物IDの続柄が一致しません: " & personKey
            End If
        Else
            relationshipsByPerson.Add personKey, relationshipText
        End If
    End If
End Sub

Private Function BalancePersonDisplay(ByVal personKey As String, ByVal aliasesByPerson As Object, _
                                      ByVal relationshipsByPerson As Object) As String
    Dim aliases As Object, item As Variant, displayText As String, relationshipText As String
    If aliasesByPerson.Exists(personKey) Then
        Set aliases = aliasesByPerson(personKey)
        For Each item In aliases.Keys
            If Len(displayText) > 0 Then displayText = displayText & "／"
            displayText = displayText & CStr(item)
        Next item
    End If
    If Len(displayText) = 0 Then _
        Err.Raise vbObjectError + 4231, "BalancePersonDisplay", _
                  "人物ID " & personKey & " の表示名義を確認できません。"
    If UseRelationshipDisplay() Then
        If relationshipsByPerson.Exists(personKey) Then relationshipText = CStr(relationshipsByPerson(personKey))
    End If
    BalancePersonDisplay = DisplayPersonWithRelationship(displayText, relationshipText)
End Function

Private Function BalanceDateLookupKey(ByVal accountID As String, ByVal balanceDate As Variant) As String
    If IsDate(balanceDate) Then BalanceDateLookupKey = accountID & Chr$(29) & Format$(CDate(balanceDate), "yyyymmdd")
End Function

Private Sub AddUniqueCollection(ByVal col As Collection, ByVal key As String)
    Dim errorNumber As Long, errorDescription As String
    On Error GoTo EH
    col.Add key, key
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    Err.Clear
    'Collectionの同一キーだけは「既に追加済み」として正常。その他の障害は隠さない。
    If errorNumber <> 457 Then _
        Err.Raise errorNumber, "AddUniqueCollection", errorDescription
End Sub

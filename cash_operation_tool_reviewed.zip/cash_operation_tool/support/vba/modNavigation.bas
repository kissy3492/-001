﻿Attribute VB_Name = "modNavigation"
Option Explicit

#If VBA7 Then
Private Declare PtrSafe Function GetAsyncKeyState Lib "user32" (ByVal virtualKey As Long) As Integer
#Else
Private Declare Function GetAsyncKeyState Lib "user32" (ByVal virtualKey As Long) As Integer
#End If

Private Const VK_TAB As Long = &H9&
Private Const VK_RETURN As Long = &HD&
Private Const VK_SHIFT As Long = &H10&
Private Const NAVIGATION_RECOVERY_HARD_BARRIER_ERROR As Long = _
    vbObjectError + 4499
Private Const NAVIGATION_RECOVERY_HARD_BARRIER_SOURCE As String = _
    "NavigationRecoveryFatal/"

Private mLastHighlightRow As Long
Private mLastEditedRow As Long
Private mLastEditedCol As Long
Private mPendingMultiPasteValidation As Boolean

'入力エラーが1件残るだけでSelectionChangeのたびに最大10,000行を再走査しないよう、
'エラー種別・先頭セル・件数を入力変更時にだけ更新する。
Private mPendingInputErrors As Object
Private mPendingInputErrorCacheReady As Boolean
Private mPendingDateErrorCount As Long
Private mPendingTimeErrorCount As Long
Private mPendingAmountErrorCount As Long
Private mPendingFirstErrorAddress As String
Private mPendingFirstErrorPriority As Double
Private mPendingFirstErrorDirty As Boolean
Private mInputErrorCacheRefreshRequired As Boolean
Private mEnablingInputKeys As Boolean
Private mPreviousInputAddress As String
Private mNativeSelectionRedirecting As Boolean
Private Const PENDING_ERROR_INCREMENTAL_PASTE_MAX_CELLS As Long = 256

'同一口座番号警告は、入力行を移動するたびに作業シート全体を走査すると重くなる。
'現在の口座情報＋作業シート件数をキーにキャッシュし、同じ状態では再走査しない。
Private mDuplicateCacheKey As String
Private mDuplicateCacheMessage As String

'選択行が下へ進むたびに先頭行から日付を再計算すると、明細が多いほど操作が重くなる。
'補完済みの年月日とエラー有無を行単位で保持し、編集行以降だけを再計算する。
Private mDateCacheYear() As Long
Private mDateCacheMonth() As Long
Private mDateCacheDay() As Long
Private mDateCacheAnyDate() As Boolean
Private mDateCacheAnyInvalid() As Boolean
Private mDateCacheAnyIncomplete() As Boolean
Private mDateCacheValidThrough As Long
Private mDateCacheYearAdd As Long
Private mDateCacheReady As Boolean

Public Sub EnableInputKeys()
    '呼出元が設定画面やエラー処理でも、実際にこのブックの入力シートが有効な時だけ
    'このブック固有のCtrl操作だけを有効にする。Tab/EnterはExcel標準キーを奪わず、
    'SelectionChangeで入力順だけを案内する。
    Dim hasSetupTrace As Boolean, healthIsNormal As Boolean
    Dim ignoredKeyState As Integer
    Dim bindingDetail As String, releaseDetail As String
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    On Error GoTo EH
    mEnablingInputKeys = True
    DisableInputKeys
    mEnablingInputKeys = False
    '読み取り専用で入力だけ進めても登録時に失うため、最初から入力ナビゲーションを無効にする。
    If ThisWorkbook.ReadOnly Then Exit Sub
    '要復旧・状態不明のブックでは、シートが表示されても入力キーを復活させない。
    '状態取得自体に失敗した場合も、誤操作を許すより割当なしのまま安全側に止める。
    hasSetupTrace = ToolHasSetupTrace()
    If hasSetupTrace Then
        healthIsNormal = ToolDataHealthIsNormal()
        If Not healthIsNormal Then Exit Sub
    End If
    If ActiveWorkbook Is ThisWorkbook Then
        If ActiveSheet.Name = SH_INPUT Then
            'イベントを通らない一括変更は各処理が明示的にキャッシュを無効化する。
            '単なるシート・ウィンドウ往復では有効なキャッシュを保持し、全件再走査を避ける。
            If Not mPendingInputErrorCacheReady Or mInputErrorCacheRefreshRequired Then
                InvalidateDateComplementCache TX_FIRST_ROW
                RebuildPendingInputErrorCache ThisWorkbook.Worksheets(SH_INPUT)
            End If
            'Alt+Tab等でこのブックへ戻った直後の古いlow-bitを消費する。
            '次のマウス選択をTab操作と誤認しないためであり、キー割当は変更しない。
            ignoredKeyState = GetAsyncKeyState(VK_TAB)
            ignoredKeyState = GetAsyncKeyState(VK_RETURN)
            ignoredKeyState = GetAsyncKeyState(VK_SHIFT)
            If TypeName(Selection) = "Range" Then
                If Selection.Parent Is ThisWorkbook.Worksheets(SH_INPUT) Then _
                    mPreviousInputAddress = Selection.Cells(1, 1).Address(False, False)
            End If
            '入力表からマウスへ手を移さず、登録・エラー移動・詳細切替を行う。
            '全割当が成功した時だけ有効とし、途中失敗時は全解除へ補償する。
            If Not TryApplyInputKeyBindings(IsEditMode(), bindingDetail) Then _
                Err.Raise vbObjectError + 3325, "EnableInputKeys", _
                          "入力ショートカットを一括設定できませんでした。" & _
                          IIf(Len(bindingDetail) > 0, " " & bindingDetail, vbNullString)
            Exit Sub
        End If
    End If
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    mEnablingInputKeys = False
    releaseDetail = vbNullString
    If Not TryReleaseAllInputKeys(releaseDetail) Then
        AppendNavigationSafetyDetail errorDescription, _
            "入力ショートカットの全解除失敗: " & releaseDetail
    End If
    mPreviousInputAddress = vbNullString
    mNativeSelectionRedirecting = False
    On Error Resume Next
    SetInputStatus "入力ショートカットを安全に設定できませんでした。" & _
                   "診断実行でExcelのキー割当を確認してください。", True
    AddCheck "エラー", "入力ショートカット設定", _
             "Err " & CStr(errorNumber) & ": " & errorDescription
    On Error GoTo 0
    Err.Raise errorNumber, "EnableInputKeys", errorDescription
End Sub

Public Sub DisableInputKeys()
    Dim interactiveState As Boolean
    Dim releaseDetail As String
    'OnKeyはExcel全体へ作用するため、このブックが登録したCtrl操作だけを解除する。
    '標準Tab/Enterには一度も触れず、他ブック・アドインの割当を破壊しない。
    '画面を離れただけでは入力値は変わらない。
    '通常のシート・ウィンドウ移動ではキャッシュを維持する。一方、AppBegin中の一括書換えは
    'イベントを通らない可能性があるため、呼出元の明示漏れがあっても次回表示時に再構築する。
    If Not mEnablingInputKeys Then
        On Error Resume Next
        Err.Clear
        interactiveState = Application.Interactive
        If Err.Number <> 0 Or Not interactiveState Then _
            mInputErrorCacheRefreshRequired = True
        Err.Clear
        On Error GoTo 0
    End If
    mPreviousInputAddress = vbNullString
    mNativeSelectionRedirecting = False
    If TryReleaseAllInputKeys(releaseDetail) Then Exit Sub
    On Error Resume Next
    SetInputStatus "入力ショートカットを完全に解除できませんでした。" & _
                   "Excelを再起動し、診断実行で状態を確認してください。", True
    AddCheck "エラー", "入力ショートカット解除", releaseDetail
    On Error GoTo 0
    Err.Raise vbObjectError + 3326, "DisableInputKeys", _
              "入力ショートカットの全解除に失敗しました。" & _
              IIf(Len(releaseDetail) > 0, " " & releaseDetail, vbNullString)
End Sub

Private Function TryReleaseAllInputKeys(ByRef detailText As String) As Boolean
    'Application.OnKeyにはgetterがないため、各解除呼出しの成否を直後に検査し、
    '1件が失敗しても残りを必ず解除することを読戻し相当の収束契約とする。
    detailText = vbNullString
    TryReleaseAllInputKeys = True
    On Error Resume Next
    Err.Clear
    Application.OnKey "^~"
    If Err.Number <> 0 Then
        TryReleaseAllInputKeys = False
        AppendNavigationSafetyDetail detailText, _
            "Ctrl+Enter解除: Err " & CStr(Err.Number) & " " & Err.Description
        Err.Clear
    End If
    Application.OnKey "^+~"
    If Err.Number <> 0 Then
        TryReleaseAllInputKeys = False
        AppendNavigationSafetyDetail detailText, _
            "Ctrl+Shift+Enter解除: Err " & CStr(Err.Number) & " " & Err.Description
        Err.Clear
    End If
    Application.OnKey "^+e"
    If Err.Number <> 0 Then
        TryReleaseAllInputKeys = False
        AppendNavigationSafetyDetail detailText, _
            "Ctrl+Shift+E解除: Err " & CStr(Err.Number) & " " & Err.Description
        Err.Clear
    End If
    Application.OnKey "^+b"
    If Err.Number <> 0 Then
        TryReleaseAllInputKeys = False
        AppendNavigationSafetyDetail detailText, _
            "Ctrl+Shift+B解除: Err " & CStr(Err.Number) & " " & Err.Description
        Err.Clear
    End If
    On Error GoTo 0
End Function

Private Function TryApplyInputKeyBindings( _
        ByVal correctionMode As Boolean, _
        ByRef detailText As String) As Boolean
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim releaseDetail As String
    detailText = vbNullString
    '直前にも全解除して、反復呼出しや別windowからの収束で旧割当を残さない。
    If Not TryReleaseAllInputKeys(releaseDetail) Then
        detailText = "設定前の全解除失敗: " & releaseDetail
        Exit Function
    End If
    '各呼出しは同じ局所handlerへ直ちに遷移するため、成功は5件すべてが
    '例外なしで完了した場合にだけ確定する。
    On Error GoTo EH
    Application.OnKey "^~", MacroRef("SaveCurrentAccount")
    If correctionMode Then
        Application.OnKey "^+~", MacroRef("CancelCorrection")
    Else
        Application.OnKey "^+~", MacroRef("SaveCurrentAccountNextBranch")
    End If
            Application.OnKey "^+e", MacroRef("GoToFirstInputError")
    Application.OnKey "^+b", MacroRef("ToggleInputDetails")
    TryApplyInputKeyBindings = True
    Exit Function
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    On Error GoTo 0
    detailText = "割当処理: Err " & CStr(errorNumber) & " " & errorDescription
    releaseDetail = vbNullString
    If Not TryReleaseAllInputKeys(releaseDetail) Then _
        AppendNavigationSafetyDetail detailText, _
            "失敗後の全解除: " & releaseDetail
End Function

Public Sub InvalidateDuplicateAccountWarningCache()
    '転記・初期化・手動編集などで作業シートの内容が変わった時に呼ぶ。
    '古い「重複なし」判定が残ると警告を見落とすため、明示的に破棄する。
    mDuplicateCacheKey = vbNullString
    mDuplicateCacheMessage = vbNullString
End Sub

Public Sub InvalidateDateComplementCache(Optional ByVal fromSheetRow As Variant)
    Dim keepThrough As Long, firstAffectedRow As Long
    If IsMissing(fromSheetRow) Then
        mDateCacheReady = False
        mDateCacheValidThrough = 0
        InvalidatePendingInputErrorCache
        Exit Sub
    End If
    firstAffectedRow = CLng(fromSheetRow)
    If firstAffectedRow <= TX_FIRST_ROW Then
        mDateCacheReady = False
        mDateCacheValidThrough = 0
        Exit Sub
    End If
    If Not mDateCacheReady Then Exit Sub
    keepThrough = firstAffectedRow - TX_FIRST_ROW
    If keepThrough < mDateCacheValidThrough Then mDateCacheValidThrough = keepThrough
End Sub

Public Sub InvalidatePendingInputErrorCache( _
        Optional ByVal validateOnNextSelection As Boolean = False)
    'セットアップ・入力全消去・訂正読込など、イベントを通らない一括変更用。
    Set mPendingInputErrors = Nothing
    mPendingInputErrorCacheReady = False
    mPendingDateErrorCount = 0
    mPendingTimeErrorCount = 0
    mPendingAmountErrorCount = 0
    mPendingFirstErrorAddress = vbNullString
    mPendingFirstErrorPriority = 0
    mPendingFirstErrorDirty = False
    mInputErrorCacheRefreshRequired = True
    mPendingMultiPasteValidation = validateOnNextSelection
End Sub

Public Sub RestoreInputNavigation()
    '旧版ボタン・緊急時の直接実行用。現行の設定パネルでは、書式・保護も直す
    'RestoreToolFormattingへ復旧操作を一本化している。
    Const restoredStatus As String = _
        "Tab・Enter移動を復旧しました。摘要の次は次行の日へ移動します。"
    Dim ws As Worksheet
    Dim workbookWasSaved As Boolean
    Dim initialEvents As Boolean, restoreEvents As Boolean
    Dim initialEventsCaptured As Boolean, restoreEventsCaptured As Boolean
    Dim appStateProblems As String
    Dim eventStateDetail As String, eventRestoreDetail As String
    Dim containmentDetail As String, statusDetail As String
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim eventsContained As Boolean, entryEventsRestored As Boolean
    On Error GoTo EH

    '直接実行時のExcelイベント値を、ブック・キー・状態欄へ一切書く前に厳密に保存する。
    If Not TryGetNavigationEnableEvents(initialEvents, eventStateDetail) Then _
        Err.Raise vbObjectError + 3348, "RestoreInputNavigation", _
                  "復旧開始前のExcelイベント状態を一意に保存できません。 " & _
                  eventStateDetail
    initialEventsCaptured = True

    'このツールがAppBeginで退避したApplication状態だけを復元する。
    '所有記録のないEnableEvents=Falseを他ブック・アドインの利用中と区別できないため、
    '安全既定値への強制変更やEnableEvents=Trueの直書きは行わない。
    AppForceRestore
    If Not AppStateIsRestored(appStateProblems) Then _
        Err.Raise vbObjectError + 3349, "RestoreInputNavigation", _
                  "捕捉済みApplication状態の復元完了を確認できません。 " & _
                  appStateProblems

    'AppForceRestoreが所有済みleaseを復元した場合は、その復元後の値が実際の返却先となる。
    '後続処理の間は必ずFalseに再取得し、この値を最終操作として戻す。
    eventStateDetail = vbNullString
    If Not TryGetNavigationEnableEvents(restoreEvents, eventStateDetail) Then _
        Err.Raise vbObjectError + 3350, "RestoreInputNavigation", _
                  "Application状態復元後のExcelイベント状態を一意に保存できません。 " & _
                  eventStateDetail
    restoreEventsCaptured = True
    eventStateDetail = vbNullString
    If Not TryStopNavigationEventsForBookWrites(eventStateDetail) Then _
        Err.Raise vbObjectError + 3351, "RestoreInputNavigation", _
                  "入力ナビゲーション復旧中のExcelイベント停止を確認できません。 " & _
                  eventStateDetail
    eventsContained = True

    If Not SheetExists(SH_INPUT) Then _
        Err.Raise vbObjectError + 3101, "RestoreInputNavigation", "入力シートが見つかりません。"
    Set ws = ThisWorkbook.Worksheets(SH_INPUT)
    workbookWasSaved = ThisWorkbook.Saved
    ws.Visible = xlSheetVisible
    ws.Activate
    ProtectInputSheet True
    'ProtectInputSheetは独自の入れ子leaseを持つ。戻り後も外側のFalseが維持されたことを再確認する。
    eventStateDetail = vbNullString
    If Not TryStopNavigationEventsForBookWrites(eventStateDetail) Then _
        Err.Raise vbObjectError + 3352, "RestoreInputNavigation", _
                  "入力シート保護後のExcelイベント停止を確認できません。 " & _
                  eventStateDetail
    If Not ws.ProtectContents Or Not ws.ProtectDrawingObjects Then _
        Err.Raise vbObjectError + 3353, "RestoreInputNavigation", _
                  "入力シートのセル保護または図形保護を読み戻せません。"
    EnableInputKeys
    If Not ThisWorkbook.ReadOnly Then ws.Cells(TX_FIRST_ROW, COL_TX_DAY).Select
    SetInputStatus restoredStatus
    If Not TryConfirmInputNavigationStatus(ws, restoredStatus, statusDetail) Then _
        Err.Raise vbObjectError + 3354, "RestoreInputNavigation", statusDetail
    If workbookWasSaved Then
        ThisWorkbook.Saved = True
        If Not ThisWorkbook.Saved Then _
            Err.Raise vbObjectError + 3355, "RestoreInputNavigation", _
                      "復旧前の保存済み状態を読み戻せません。"
    End If

    'ブック・キー・状態欄・Savedへの操作完了後にだけ、復元後lease値を最後に返す。
    eventRestoreDetail = vbNullString
    entryEventsRestored = _
        TryRestoreInputNavigationEventsFinal(restoreEvents, eventRestoreDetail)
    If Not entryEventsRestored Then
        On Error Resume Next
        MsgBox "入力ナビゲーションは復旧しましたが、Excelイベント状態を" & _
               "所有済みの返却先値へ戻せませんでした。" & vbCrLf & _
               "ブックへの復旧状態記録は追加していません。" & vbCrLf & _
               "Excelイベントと案件の安全状態は不明です。現在のブックを上書きしないでください。" & _
               IIf(Len(eventRestoreDetail) > 0, vbCrLf & eventRestoreDetail, vbNullString), _
               vbCritical, "Excelイベント状態を確認できません"
        On Error GoTo 0
    End If
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    Err.Clear

    If IsNavigationRecoveryHardBarrier(errorNumber, errorSource) Then
        Call TryStopNavigationEventsForBookWrites(containmentDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If

    '失敗後は先にFalseの読戻しへ収束させる。Force自体またはApplication
    '復元確認が失敗した場合はTrueを推測せず、ブックへは何も記録しない。
    containmentDetail = vbNullString
    eventsContained = TryStopNavigationEventsForBookWrites(containmentDetail)
    If restoreEventsCaptured And eventsContained Then
        eventRestoreDetail = vbNullString
        entryEventsRestored = _
            TryRestoreInputNavigationEventsFinal(restoreEvents, eventRestoreDetail)
    Else
        entryEventsRestored = False
        If Not initialEventsCaptured Then _
            AppendNavigationSafetyDetail containmentDetail, _
                "開始時のExcelイベント値も保存できていません。"
        If initialEventsCaptured And Not restoreEventsCaptured Then _
            AppendNavigationSafetyDetail containmentDetail, _
                "Application復元後の返却先値は保存できていません。"
    End If

    'ここから後はシート・キー・状態欄・Savedを変更しない。
    On Error Resume Next
    MsgBox "Tab移動を復旧できませんでした。" & vbCrLf & _
           "Err " & CStr(errorNumber) & _
           IIf(Len(errorSource) > 0, " [" & errorSource & "]", vbNullString) & _
           ": " & errorDescription & vbCrLf & _
           IIf(entryEventsRestored, _
               "Excelイベント状態は所有済みの返却先値へ戻しました。", _
               "Excelイベントと案件の安全状態は不明です。" & _
               "現在のブックを上書きしないでください。" & _
               IIf(Len(containmentDetail) > 0, vbCrLf & containmentDetail, vbNullString) & _
               IIf(Len(eventRestoreDetail) > 0, vbCrLf & eventRestoreDetail, vbNullString)), _
           vbExclamation, "入力ナビゲーション復旧失敗"
    On Error GoTo 0
End Sub

Public Sub InputTabNext()
    MoveInputCell False
End Sub

Public Sub InputTabPrev()
    MoveInputCell True
End Sub

Public Sub GoToFirstInputError()
    Dim ws As Worksheet
    Dim targetCell As Range
    Dim workbookWasSaved As Boolean
    Dim errorNumber As Long, errorSource As String, errorDescription As String
    Dim eventStateDetail As String
    On Error GoTo EH
    If ActiveWorkbook Is Nothing Then Exit Sub
    If Not ActiveWorkbook Is ThisWorkbook Then Exit Sub
    If TypeName(ActiveSheet) <> "Worksheet" Then Exit Sub
    If ActiveSheet.Name <> SH_INPUT Then Exit Sub
    workbookWasSaved = ThisWorkbook.Saved
    Set ws = ActiveSheet

    If Not mPendingInputErrorCacheReady Or mInputErrorCacheRefreshRequired Then _
        RebuildPendingInputErrorCache ws
    If Not PendingInputErrorCacheHasErrors() Then
        SetInputStatus "未修正の入力エラーはありません。"
        GoTo CleanExit
    End If
    RefreshPendingFirstError
    If Len(mPendingFirstErrorAddress) = 0 Then
        SetInputStatus "入力エラーの位置を確定できませんでした。診断実行で全体状態を確認してください。", True
        GoTo CleanExit
    End If
    Set targetCell = ws.Range(mPendingFirstErrorAddress)
    If targetCell.EntireRow.Hidden Or targetCell.EntireColumn.Hidden Then _
        SetInputDetailsExpanded ws, True, True
    Application.Goto targetCell, False
    ShowAllPendingInputErrors ws
CleanExit:
    If workbookWasSaved Then ThisWorkbook.Saved = True
    Exit Sub
EH:
    errorNumber = Err.Number
    errorSource = Err.Source
    errorDescription = Err.Description
    If IsNavigationRecoveryHardBarrier(errorNumber, errorSource) Then
        'Recovery terminalを返した下位処理の後は、状態表示・Saved復元を含む
        'ブック書込みへ進まず、fresh Falseだけを再確認して元例外を保つ。
        On Error Resume Next
        Err.Clear
        Call TryStopNavigationEventsForBookWrites(eventStateDetail)
        Err.Clear
        On Error GoTo 0
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    On Error Resume Next
    SetInputStatus "先頭エラーへ移動できませんでした。Err " & _
                   CStr(errorNumber) & ": " & errorDescription, True
    If workbookWasSaved Then ThisWorkbook.Saved = True
    On Error GoTo 0
End Sub

Public Sub MoveInputCell(ByVal backwards As Boolean)
    Dim ws As Worksheet
    Dim nextCell As Range
    Dim errorNumber As Long, errorDescription As String
    Dim inputSheetConfirmed As Boolean
    On Error GoTo EH
    If ActiveWorkbook Is Nothing Then GoTo StandardFallback
    If Not ActiveWorkbook Is ThisWorkbook Then GoTo StandardFallback
    If ActiveSheet Is Nothing Then GoTo StandardFallback
    If TypeName(ActiveSheet) <> "Worksheet" Then GoTo StandardFallback
    If ActiveSheet.Name <> SH_INPUT Then GoTo StandardFallback
    inputSheetConfirmed = True
    Set ws = ActiveSheet
    Set nextCell = GetNextInputCell(ws, ActiveCell, backwards)
    '編集確定直後のOnKeyより前に、日付・時刻・金額・出入金の組合せを再確認する。
    If Not CurrentInputCellAllowsNavigation(ActiveCell, nextCell) Then Exit Sub
    If Not nextCell Is Nothing Then
        Application.Goto nextCell, False
        Exit Sub
    End If
    Exit Sub
StandardFallback:
    On Error Resume Next
    If backwards Then ActiveCell.Offset(0, -1).Select Else ActiveCell.Offset(0, 1).Select
    On Error GoTo 0
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    If Not inputSheetConfirmed Then GoTo StandardFallback
    '入力シート内の検証・移動先解決エラーは、隣セルへ逃がすと不正入力を通過させる。
    '現在セルに留め、画面内とチェック結果へ同じ原因を残す。
    On Error Resume Next
    SetInputStatus "入力セルを移動できませんでした。現在のセルを確認し、必要なら「診断実行」を行ってください。", True
    If SheetExists(SH_CHECK) Then _
        AddCheck "エラー", "入力ナビゲーション", _
                 "Err " & CStr(errorNumber) & ": " & errorDescription
    On Error GoTo 0
End Sub

Public Function GetNextInputCell(ByVal ws As Worksheet, ByVal cur As Range, ByVal backwards As Boolean) As Range
    Dim r As Long, c As Long, memoCol As Long
    If ws Is Nothing Or cur Is Nothing Then Exit Function
    r = cur.Row: c = cur.Column
    memoCol = BalanceMemoCol(ws)
    If IsAccountCell(cur) Then
        Set GetNextInputCell = NextAccountCell(ws, cur, backwards)
        Exit Function
    End If
    If r = BAL_VALUE_ROW And c >= BAL_FIRST_COL And c <= memoCol Then
        Set GetNextInputCell = NextBalanceCell(ws, cur, backwards, memoCol)
        Exit Function
    End If
    If r >= TX_FIRST_ROW And r <= TX_LAST_ROW And c >= COL_TX_YEAR And c <= COL_TX_OTHER Then
        Set GetNextInputCell = NextTransactionCell(ws, cur, backwards)
        Exit Function
    End If
    Set GetNextInputCell = ws.Range(CELL_BANK)
End Function

Private Function IsAccountCell(ByVal cur As Range) As Boolean
    Dim a As String
    If cur Is Nothing Then Exit Function
    a = cur.Address(False, False)
    IsAccountCell = (a = CELL_BANK Or a = CELL_BRANCH Or a = CELL_PERSON Or _
                     (UseRelationshipDisplay() And a = CELL_RELATIONSHIP) Or _
                     a = CELL_ACCOUNT_TYPE Or a = CELL_ACCOUNT_NO Or a = CELL_OPEN_DATE Or a = CELL_CLOSE_DATE)
End Function

Private Function NextAccountCell(ByVal ws As Worksheet, ByVal cur As Range, ByVal backwards As Boolean) As Range
    Dim arr As Variant, i As Long
    '開設日・解約日は「詳細・残高」で任意入力するため、通常Tab順路から外す。
    If cur.Address(False, False) = CELL_OPEN_DATE Then
        If backwards Then
            Set NextAccountCell = LastCoreAccountCell(ws)
        Else
            Set NextAccountCell = ws.Range(CELL_CLOSE_DATE)
        End If
        Exit Function
    ElseIf cur.Address(False, False) = CELL_CLOSE_DATE Then
        If backwards Then
            Set NextAccountCell = ws.Range(CELL_OPEN_DATE)
        Else
            Set NextAccountCell = FirstAvailableBalanceInputCell(ws)
        End If
        Exit Function
    End If
    '氏名候補から続柄が自動補完済みなら、通常のTab順路で同じ値を
    '再確認させない。続柄が空欄・数式・エラーの時だけ入力停止点に残す。
    'クリックで続柄欄へ入った場合の前後移動は、順路から省いた状態でも明示する。
    If UseRelationshipDisplay() And _
       cur.Address(False, False) = CELL_RELATIONSHIP And _
       Not RelationshipNeedsTabStop(ws) Then
        If backwards Then
            Set NextAccountCell = ws.Range(CELL_ACCOUNT_NO)
        Else
            Set NextAccountCell = ws.Cells(TX_FIRST_ROW, COL_TX_YEAR)
        End If
        Exit Function
    End If
    If UseRelationshipDisplay() And RelationshipNeedsTabStop(ws) Then
        arr = Array(CELL_BANK, CELL_BRANCH, CELL_PERSON, CELL_ACCOUNT_TYPE, CELL_ACCOUNT_NO, CELL_RELATIONSHIP)
    Else
        arr = Array(CELL_BANK, CELL_BRANCH, CELL_PERSON, CELL_ACCOUNT_TYPE, CELL_ACCOUNT_NO)
    End If
    For i = LBound(arr) To UBound(arr)
        If cur.Address(False, False) = CStr(arr(i)) Then
            If backwards Then
                If i = LBound(arr) Then Set NextAccountCell = ws.Range(CELL_BANK) Else Set NextAccountCell = ws.Range(CStr(arr(i - 1)))
            Else
                If i = UBound(arr) Then
                    '最初の明細だけは年・月が未定のため、年から開始する。
                    Set NextAccountCell = ws.Cells(TX_FIRST_ROW, COL_TX_YEAR)
                Else
                    Set NextAccountCell = ws.Range(CStr(arr(i + 1)))
                End If
            End If
            Exit Function
        End If
    Next i
    Set NextAccountCell = ws.Range(CELL_BANK)
End Function

Private Function LastCoreAccountCell(ByVal ws As Worksheet) As Range
    If ws Is Nothing Then Exit Function
    If UseRelationshipDisplay() And RelationshipNeedsTabStop(ws) Then
        Set LastCoreAccountCell = ws.Range(CELL_RELATIONSHIP)
    Else
        Set LastCoreAccountCell = ws.Range(CELL_ACCOUNT_NO)
    End If
End Function

Private Function RelationshipNeedsTabStop(ByVal ws As Worksheet) As Boolean
    Dim relationshipCell As Range
    If ws Is Nothing Then Exit Function
    Set relationshipCell = EffectiveRange(ws.Range(CELL_RELATIONSHIP)).Cells(1, 1)
    If relationshipCell.HasFormula Or IsError(relationshipCell.Value) Then
        RelationshipNeedsTabStop = True
    Else
        RelationshipNeedsTabStop = Not HasText(relationshipCell.Value)
    End If
End Function

Private Function NextBalanceCell(ByVal ws As Worksheet, ByVal cur As Range, ByVal backwards As Boolean, ByVal memoCol As Long) As Range
    '開設日前・解約日後でロックされた残高欄は、Tab移動でも飛ばす。
    '残高欄の後は、残高入力エリア末尾のメモ欄へ進む。
    If cur Is Nothing Then Exit Function
    If backwards Then
        Set NextBalanceCell = NextAvailableBalanceInputCell(ws, cur.Column, True)
    Else
        Set NextBalanceCell = NextAvailableBalanceInputCell(ws, cur.Column, False)
    End If
End Function

Private Function NextTransactionCell(ByVal ws As Worksheet, ByVal cur As Range, ByVal backwards As Boolean) As Range
    Dim cols As Variant, idx As Long, i As Long, targetCol As Long
    cols = TransactionRoute(GetInputMode())

    '【年・月の考え方】
    '2行目以降の連続入力では「日」から流す。一方、年替わりだけは素早く直せるよう、
    '日セルで Shift+Tab した場合は月ではなく年へ直接戻す。月セルはクリック・矢印キーでは編集可能。
    If cur.Column = COL_TX_YEAR And Not backwards Then Set NextTransactionCell = ws.Cells(cur.Row, COL_TX_MONTH): Exit Function
    If cur.Column = COL_TX_MONTH And Not backwards Then Set NextTransactionCell = ws.Cells(cur.Row, COL_TX_DAY): Exit Function
    If cur.Column = COL_TX_DAY And backwards Then Set NextTransactionCell = ws.Cells(cur.Row, COL_TX_YEAR): Exit Function
    If cur.Column = COL_TX_MONTH And backwards Then Set NextTransactionCell = ws.Cells(cur.Row, COL_TX_YEAR): Exit Function
    If cur.Column = COL_TX_YEAR And backwards Then
        If cur.Row <= TX_FIRST_ROW Then
            Set NextTransactionCell = LastVisibleBalanceOrAccountCell(ws)
        Else
            Set NextTransactionCell = ws.Cells(cur.Row - 1, CLng(cols(UBound(cols))))
        End If
        Exit Function
    End If

    '取引後残高列は通常モードではTabルートから外し、専用モード時だけ通す。
    If cur.Column = COL_TX_OTHER Then
        If backwards Then
            targetCol = CLng(cols(UBound(cols)))
            If targetCol = cur.Column And UBound(cols) > LBound(cols) Then _
                targetCol = CLng(cols(UBound(cols) - 1))
            Set NextTransactionCell = ws.Cells(cur.Row, targetCol)
        ElseIf cur.Row < TX_LAST_ROW Then
            Set NextTransactionCell = ws.Cells(cur.Row + 1, COL_TX_DAY)
        Else
            Set NextTransactionCell = ws.Cells(TX_LAST_ROW, COL_TX_OTHER)
        End If
        Exit Function
    End If

    idx = -1
    For i = LBound(cols) To UBound(cols)
        If CLng(cols(i)) = cur.Column Then idx = i: Exit For
    Next i
    If idx = -1 Then Set NextTransactionCell = ws.Cells(cur.Row, COL_TX_DAY): Exit Function
    If backwards Then
        If idx = LBound(cols) Then
            If cur.Row <= TX_FIRST_ROW Then Set NextTransactionCell = ws.Cells(TX_FIRST_ROW, COL_TX_DAY) Else Set NextTransactionCell = ws.Cells(cur.Row - 1, CLng(cols(UBound(cols))))
        Else
            targetCol = CLng(cols(idx - 1))
            '出金入力時に前進で入金欄を飛ばした場合、Shift+Tabも対称に出金欄へ戻す。
            '両方入力済みなら入金欄へ戻し、F/G間で片方を消せるようにする。
            If targetCol = COL_TX_DEPOSIT And _
               HasText(ws.Cells(cur.Row, COL_TX_WITHDRAW).Value) And _
               TransactionAmountCellIsTrulyEmpty(ws.Cells(cur.Row, COL_TX_DEPOSIT)) Then _
                targetCol = COL_TX_WITHDRAW
            Set NextTransactionCell = ws.Cells(cur.Row, targetCol)
        End If
    Else
        If cur.Column = COL_TX_WITHDRAW And HasText(cur.Value) And _
           TransactionAmountCellIsTrulyEmpty(ws.Cells(cur.Row, COL_TX_DEPOSIT)) Then
            targetCol = RouteColumnAfter(cols, COL_TX_DEPOSIT)
            Set NextTransactionCell = ws.Cells(cur.Row, targetCol)
            Exit Function
        End If
        If idx = UBound(cols) Then
            If cur.Row >= TX_LAST_ROW Then Set NextTransactionCell = ws.Cells(TX_LAST_ROW, CLng(cols(idx))) Else Set NextTransactionCell = ws.Cells(cur.Row + 1, COL_TX_DAY)
        Else
            Set NextTransactionCell = ws.Cells(cur.Row, CLng(cols(idx + 1)))
        End If
    End If
End Function

Private Function LastVisibleBalanceOrAccountCell(ByVal ws As Worksheet) As Range
    '詳細を開いていても、通常明細のShift+Tab順路へ任意入力欄を混在させない。
    '開設日・解約日・残高は各欄をクリックした時だけ専用順路として移動する。
    If ws Is Nothing Then Exit Function
    Set LastVisibleBalanceOrAccountCell = LastCoreAccountCell(ws)
End Function

Private Function TransactionAmountCellIsTrulyEmpty(ByVal targetCell As Range) As Boolean
    '数式の空文字やExcelエラーは修正対象なので、見かけが空でもTabで飛ばさない。
    If targetCell Is Nothing Then Exit Function
    If targetCell.HasFormula Or IsError(targetCell.Value) Then Exit Function
    TransactionAmountCellIsTrulyEmpty = Not HasText(targetCell.Value)
End Function

Private Function TransactionRoute(ByVal modeText As String) As Variant
    If modeText = MODE_SIMPLE Then
        TransactionRoute = Array(COL_TX_DAY, COL_TX_WITHDRAW, COL_TX_DEPOSIT, COL_TX_SHOP)
    ElseIf modeText = MODE_NO_TIME Then
        TransactionRoute = Array(COL_TX_DAY, COL_TX_WITHDRAW, COL_TX_DEPOSIT, COL_TX_SHOP, COL_TX_MACHINE, COL_TX_TEKIYO)
    ElseIf modeText = MODE_NO_MACHINE Then
        TransactionRoute = Array(COL_TX_DAY, COL_TX_TIME, COL_TX_WITHDRAW, COL_TX_DEPOSIT, COL_TX_SHOP, COL_TX_TEKIYO)
    ElseIf modeText = MODE_NO_TEKIYO Then
        TransactionRoute = Array(COL_TX_DAY, COL_TX_TIME, COL_TX_WITHDRAW, COL_TX_DEPOSIT, COL_TX_SHOP, COL_TX_MACHINE)
    ElseIf modeText = MODE_WITH_OTHER Or modeText = "その他あり" Then
        TransactionRoute = Array(COL_TX_DAY, COL_TX_TIME, COL_TX_WITHDRAW, COL_TX_DEPOSIT, COL_TX_SHOP, COL_TX_MACHINE, COL_TX_TEKIYO, COL_TX_OTHER)
    Else
        TransactionRoute = Array(COL_TX_DAY, COL_TX_TIME, COL_TX_WITHDRAW, COL_TX_DEPOSIT, COL_TX_SHOP, COL_TX_MACHINE, COL_TX_TEKIYO)
    End If
End Function

Private Function RouteColumnAfter(ByVal cols As Variant, ByVal afterCol As Long) As Long
    Dim i As Long
    For i = LBound(cols) To UBound(cols) - 1
        If CLng(cols(i)) = afterCol Then RouteColumnAfter = CLng(cols(i + 1)): Exit Function
    Next i
    RouteColumnAfter = COL_TX_SHOP
End Function

'Tab/Enter自体はApplication.OnKeyで上書きしない。Windowsが通知する実キー状態を
'SelectionChange内で読むだけにし、マウス・矢印キーで任意セルを選ぶ操作とは分離する。
Private Function RedirectNativeInputKeySelection(ByVal selectedCell As Range) As Boolean
    Dim previousCell As Range, desiredCell As Range
    Dim nativeKeyPressed As Boolean, backwards As Boolean
    Dim tabState As Integer, returnState As Integer, shiftState As Integer
    Dim errorNumber As Long, errorDescription As String

    On Error GoTo EH
    If selectedCell Is Nothing Then Exit Function
    If mNativeSelectionRedirecting Then
        mPreviousInputAddress = selectedCell.Address(False, False)
        Exit Function
    End If

    tabState = GetAsyncKeyState(VK_TAB)
    returnState = GetAsyncKeyState(VK_RETURN)
    shiftState = GetAsyncKeyState(VK_SHIFT)
    NativeInputDirectionFromStates tabState, returnState, shiftState, _
                                   nativeKeyPressed, backwards
    If Not nativeKeyPressed Or Len(mPreviousInputAddress) = 0 Then
        mPreviousInputAddress = selectedCell.Address(False, False)
        Exit Function
    End If

    Set previousCell = selectedCell.Worksheet.Range(mPreviousInputAddress)
    Set desiredCell = GetNextInputCell(selectedCell.Worksheet, previousCell, backwards)
    If desiredCell Is Nothing Then
        mPreviousInputAddress = selectedCell.Address(False, False)
        Exit Function
    End If
    If Not CurrentInputCellAllowsNavigation(previousCell, desiredCell) Then _
        Set desiredCell = previousCell
    If StrComp(selectedCell.Address(False, False), _
               desiredCell.Address(False, False), vbBinaryCompare) = 0 Then
        mPreviousInputAddress = selectedCell.Address(False, False)
        Exit Function
    End If

    mPreviousInputAddress = desiredCell.Address(False, False)
    mNativeSelectionRedirecting = True
    Application.Goto desiredCell, False
    mNativeSelectionRedirecting = False
    RedirectNativeInputKeySelection = True
    Exit Function
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    mNativeSelectionRedirecting = False
    Err.Raise errorNumber, "RedirectNativeInputKeySelection", errorDescription
End Function

Private Sub NativeInputDirectionFromStates( _
        ByVal tabState As Integer, ByVal returnState As Integer, _
        ByVal shiftState As Integer, ByRef nativeKeyPressed As Boolean, _
        ByRef backwards As Boolean)
    nativeKeyPressed = _
        (NativeInputKeyStateWasPressed(tabState) Or _
         NativeInputKeyStateWasPressed(returnState))
    backwards = _
        (nativeKeyPressed And NativeModifierKeyStateIsDown(shiftState))
End Sub

Private Function NativeInputKeyStateWasPressed(ByVal keyState As Integer) As Boolean
    NativeInputKeyStateWasPressed = _
        (((CLng(keyState) And &H8000&) <> 0) Or _
         ((CLng(keyState) And &H1&) <> 0))
End Function

Private Function NativeModifierKeyStateIsDown(ByVal keyState As Integer) As Boolean
    'GetAsyncKeyStateのlow-bitは「前回照会以降に押された」履歴であり、現在も
    'Shiftを押していることを意味しない。大文字入力後の通常TabをShift+Tabと
    '誤認しないよう、修飾キーはhigh-bit（現在押下中）だけで判定する。
    NativeModifierKeyStateIsDown = _
        ((CLng(keyState) And &H8000&) <> 0)
End Function


Public Sub OnInputSelectionChange(ByVal Target As Range)
    Dim t As Range
    Dim workbookWasSaved As Boolean
    Dim errorNumber As Long, errorDescription As String
    On Error GoTo EH
    If Target Is Nothing Then Exit Sub
    Set t = Target
    If t.Cells.CountLarge > 1 Then
        If t.MergeCells Then
            Set t = t.MergeArea.Cells(1, 1)
        Else
            Exit Sub
        End If
    End If
    If t.Worksheet.Name <> SH_INPUT Then Exit Sub
    If RedirectNativeInputKeySelection(t) Then Exit Sub
    workbookWasSaved = ThisWorkbook.Saved
    '取引後残高列は通常Tabルート外だが、クリック・矢印キーでは編集できる。
    'ここで自動退避させると、入力中のメモが書けなくなる。
    UpdateCurrentRowHighlight t
    If Not ShowPendingInputErrorIfAny(t.Worksheet, t) Then UpdateComplementStatus t
    If workbookWasSaved Then ThisWorkbook.Saved = True
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    On Error Resume Next
    If workbookWasSaved Then ThisWorkbook.Saved = True
    On Error GoTo 0
    Err.Raise errorNumber, "OnInputSelectionChange", errorDescription
End Sub

Public Sub OnInputChange(ByVal Target As Range)
    Dim t As Range, firstInvalidDate As Range
    Dim previousEvents As Boolean
    Dim eventsCaptured As Boolean
    Dim accountDateOK As Boolean
    Dim invalidDateCount As Long
    Dim accountDateOrderInvalid As Boolean
    Dim eventsReadyForRecovery As Boolean, protectOK As Boolean
    Dim safeToRestoreEntry As Boolean, applicationStateSafe As Boolean
    Dim recoveryStateConfirmed As Boolean
    Dim eventStateDetail As String, recoveryDetail As String
    Dim postRecoveryStopDetail As String, applicationStateProblems As String
    Dim protectErrorNumber As Long, recoveryErrorNumber As Long
    Dim protectErrorDescription As String, protectErrorSource As String
    Dim recoveryErrorDescription As String
    Dim errorNumber As Long, errorSource As String, errorDescription As String
    On Error GoTo InputEH
    If Target Is Nothing Then Exit Sub
    If Not TryGetNavigationEnableEvents(previousEvents, eventStateDetail) Then
        StopAfterNavigationEventStateFailure "OnInputChange/開始状態取得", eventStateDetail
        Err.Raise vbObjectError + 3327, "OnInputChange", _
                  "Excelイベントの開始状態を取得できませんでした。 " & eventStateDetail
    End If
    eventsCaptured = True
    If Not TryStopNavigationEventsForBookWrites(eventStateDetail) Then
        recoveryDetail = _
            "入力変更処理の開始前にExcelイベントを停止して読戻し確認できませんでした。 " & _
            eventStateDetail
        On Error Resume Next
        MsgBox recoveryDetail & vbCrLf & _
               "入力補助・状態表示・キャッシュ更新は行わず、案件の安全状態は不明です。", _
               vbCritical, "入力変更を安全に処理できません"
        On Error GoTo InputEH
        If Not TryRestoreNavigationEnableEvents( _
                   previousEvents, "OnInputChange/処理開始前", _
                   eventStateDetail) Then _
            AppendNavigationSafetyDetail recoveryDetail, eventStateDetail
        eventsCaptured = False
        Err.Raise vbObjectError + 3345, "OnInputChange", recoveryDetail
    End If
    Set t = Target
    If t.Cells.CountLarge > 1 Then
        If t.MergeCells Then
            Set t = t.MergeArea.Cells(1, 1)
        Else
            HandleMultiCellInputChange t
            GoTo SafeExit
        End If
    End If
    If t.Worksheet.Name <> SH_INPUT Then GoTo SafeExit

    '候補への学習は登録成功時だけ行う。入力途中の誤字を候補に残さない。
    If t.Address(False, False) = CELL_BANK Or t.Address(False, False) = CELL_BRANCH Or t.Address(False, False) = CELL_PERSON Or t.Address(False, False) = CELL_RELATIONSHIP Then
        If t.Address(False, False) = CELL_PERSON Then FillRelationshipFromPerson t.Worksheet
        UpdateComplementStatus t
        GoTo SafeExit
    End If

    If t.Address(False, False) = CELL_ACCOUNT_TYPE Or t.Address(False, False) = CELL_ACCOUNT_NO Then
        UpdateComplementStatus t
        GoTo SafeExit
    End If

    If t.Address(False, False) = CELL_OPEN_DATE Or t.Address(False, False) = CELL_CLOSE_DATE Then
        '開設日・解約日は、和暦数字入力をその場で yyyy/m/d 表示へ整え、残高欄の入力可否を更新する。
        mLastEditedRow = t.Row
        mLastEditedCol = t.Column
        On Error GoTo AccountDateEH
        If Not TrySetNavigationEnableEventsExact(False, eventStateDetail) Then _
            Err.Raise vbObjectError + 3328, "OnInputChange/口座日付", _
                      "口座日付の正規化前にExcelイベントを停止できませんでした。 " & _
                      eventStateDetail
        accountDateOK = NormalizeAccountDatePair(t.Worksheet, firstInvalidDate, _
                                                  invalidDateCount, accountDateOrderInvalid)
        '正規化後の状態記録・再保護・入力案内も同じFalse lease内で完了し、
        '開始時イベント値の復元は共通SafeExitで最後に行う。
        If Not accountDateOK Then
            mPendingMultiPasteValidation = True
            TrackPendingErrorsAfterChange t.Worksheet, t, False, True
            If accountDateOrderInvalid Then
                SetInputStatus "解約日は開設日以降にしてください。", True
            Else
                SetInputStatus firstInvalidDate.Address(False, False) & _
                               " の日付を解釈できません。西暦または元号コードの日付を確認してください。", True
            End If
            GoTo SafeExit
        End If
        t.Worksheet.Unprotect Password:=TOOL_PASSWORD
        ApplyBalanceAvailability t.Worksheet
        ProtectInputSheet True
        TrackPendingErrorsAfterChange t.Worksheet, t, False, False
        If Not UpdateDuplicateAccountStatus(t.Worksheet) Then UpdateComplementStatus t
        GoTo SafeExit
    End If

    If t.Row = BAL_VALUE_ROW And t.Column >= BAL_FIRST_COL And _
       t.Column < BalanceMemoCol(t.Worksheet) Then
        mLastEditedRow = t.Row
        mLastEditedCol = t.Column
        If Not NormalizeTransactionAmountEntry(t) Then
            mPendingMultiPasteValidation = True
            TrackPendingErrorsAfterChange t.Worksheet, t, False, True
            SetInputStatus t.Address(False, False) & _
                           " の残高を解釈できません。数字・カンマ・円記号を確認してください。", True
            GoTo SafeExit
        End If
        TrackPendingErrorsAfterChange t.Worksheet, t, False, False
        UpdateComplementStatus t
        GoTo SafeExit
    End If

    If t.Row < TX_FIRST_ROW Or t.Row > TX_LAST_ROW Then GoTo SafeExit

    mLastEditedRow = t.Row
    mLastEditedCol = t.Column
    InvalidateDateComplementCache t.Row

    If t.Column >= COL_TX_YEAR And t.Column <= COL_TX_DAY Then
        If TransactionDateRowHasUnsupportedValue(t.Worksheet, t.Row, firstInvalidDate) Then
            mPendingMultiPasteValidation = True
            TrackPendingErrorsAfterChange t.Worksheet, t, True, True
            SetInputStatus firstInvalidDate.Address(False, False) & _
                           " の日付欄には数式・Excelエラーを入力できません。", True
            GoTo SafeExit
        End If
        TrackPendingErrorsAfterChange t.Worksheet, t, True, False
        UpdateComplementStatus t
        GoTo SafeExit
    End If

    If t.Column = COL_TX_TIME Then
        If Not NormalizeTransactionTimeEntry(t) Then
            mPendingMultiPasteValidation = True
            TrackPendingErrorsAfterChange t.Worksheet, t, False, True
            SetInputStatus CStr(t.Row) & "行目の時刻を解釈できません。00:00～23:59で入力してください。", True
            GoTo SafeExit
        End If
        TrackPendingErrorsAfterChange t.Worksheet, t, False, False
        UpdateComplementStatus t
        GoTo SafeExit
    End If

    If t.Column = COL_TX_WITHDRAW Or t.Column = COL_TX_DEPOSIT Or _
       t.Column = COL_TX_BALANCE Then
        If Not NormalizeTransactionAmountEntry(t) Then
            mPendingMultiPasteValidation = True
            TrackPendingErrorsAfterChange t.Worksheet, t, False, True
            SetInputStatus CStr(t.Row) & "行目の金額を解釈できません。数字・カンマ・円記号を確認してください。", True
            GoTo SafeExit
        End If
        If (t.Column = COL_TX_WITHDRAW Or t.Column = COL_TX_DEPOSIT) And _
           TransactionAmountPairHasProblem(t.Worksheet, t.Row) Then
            mPendingMultiPasteValidation = True
            TrackPendingErrorsAfterChange t.Worksheet, t, False, True
            GoTo SafeExit
        End If
    End If
    TrackPendingErrorsAfterChange t.Worksheet, t, False, False
    UpdateComplementStatus t
SafeExit:
    If eventsCaptured Then
        If Not TryRestoreNavigationEnableEvents( _
                   previousEvents, "OnInputChange", eventStateDetail) Then
            eventsCaptured = False
            Err.Raise vbObjectError + 3330, "OnInputChange", eventStateDetail
        End If
        eventsCaptured = False
    End If
    Exit Sub
InputEH:
    errorNumber = Err.Number
    errorSource = Err.Source
    errorDescription = Err.Description
    If IsNavigationRecoveryHardBarrier(errorNumber, errorSource) Then
        Call TryStopNavigationEventsForBookWrites(eventStateDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    If eventsCaptured Then
        eventsReadyForRecovery = _
            TryStopNavigationEventsForBookWrites(eventStateDetail)
        If eventsReadyForRecovery Then
            On Error Resume Next
            '入力値が変更済みなのに補助処理が止まった場合は、次の選択移動で全体を再確認する。
            InvalidatePendingInputErrorCache True
            On Error GoTo 0
        Else
            AppendNavigationSafetyDetail errorDescription, _
                "Excelイベント停止を確認できないため、入力エラーキャッシュの更新を見送りました: " & _
                eventStateDetail
        End If
        If Not TryRestoreNavigationEnableEvents( _
                   previousEvents, "OnInputChange", eventStateDetail) Then _
            AppendNavigationSafetyDetail errorDescription, eventStateDetail
        eventsCaptured = False
    End If
    Err.Raise errorNumber, "OnInputChange", errorDescription
AccountDateEH:
    errorNumber = Err.Number
    errorSource = Err.Source
    errorDescription = Err.Description
    If IsNavigationRecoveryHardBarrier(errorNumber, errorSource) Then
        Call TryStopNavigationEventsForBookWrites(eventStateDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    eventsReadyForRecovery = eventsCaptured
    If eventsCaptured Then
        If Not TrySetNavigationEnableEventsExact(False, eventStateDetail) Then
            eventsReadyForRecovery = False
            AppendNavigationSafetyDetail recoveryDetail, _
                "入力シート再保護前にExcelイベントを停止して読戻し確認できません: " & _
                eventStateDetail
        End If
    Else
        eventsReadyForRecovery = False
        AppendNavigationSafetyDetail recoveryDetail, _
            "Excelイベントの開始状態を取得できませんでした: " & eventStateDetail
    End If

    If eventsReadyForRecovery Then
        On Error Resume Next
        Err.Clear
        ProtectInputSheet True
        protectErrorNumber = Err.Number
        protectErrorDescription = Err.Description
        protectErrorSource = Err.Source
        Err.Clear
        On Error GoTo 0
        If IsNavigationRecoveryHardBarrier( _
               protectErrorNumber, protectErrorSource) Then
            Call TryStopNavigationEventsForBookWrites(eventStateDetail)
            Err.Raise protectErrorNumber, protectErrorSource, _
                      protectErrorDescription
        End If
        On Error Resume Next
        InvalidatePendingInputErrorCache True
        Err.Clear
        On Error GoTo 0
        protectOK = (protectErrorNumber = 0)
    Else
        protectOK = False
        AppendNavigationSafetyDetail recoveryDetail, _
            "イベント停止未確認のため、入力シートの再保護を見送りました。"
    End If
    If Not protectOK Then _
        AppendNavigationSafetyDetail recoveryDetail, _
            "入力シート再保護エラー: Err " & CStr(protectErrorNumber) & _
            " " & protectErrorDescription

    If eventsReadyForRecovery And Not protectOK Then
        On Error Resume Next
        Err.Clear
        EnforceRollbackRecoveryState recoveryDetail
        recoveryErrorNumber = Err.Number
        recoveryErrorDescription = Err.Description
        Err.Clear
        On Error GoTo 0

        'Enforce後は必ずfresh Falseを取り直す。Err時は既存のラッチ/healthを
        'stale値として読まず、診断・状態表示・開始値True復元へ進まない。
        postRecoveryStopDetail = vbNullString
        eventsReadyForRecovery = _
            TryStopNavigationEventsForBookWrites(postRecoveryStopDetail)
        If recoveryErrorNumber <> 0 Then
            AppendNavigationSafetyDetail recoveryDetail, _
                "要復旧状態の強制設定エラー: Err " & _
                CStr(recoveryErrorNumber) & " " & recoveryErrorDescription
            If Not eventsReadyForRecovery Then _
                AppendNavigationSafetyDetail recoveryDetail, _
                    "Enforce失敗後のExcelイベントFalse収束も確認できません: " & _
                    postRecoveryStopDetail
            Err.Raise NAVIGATION_RECOVERY_HARD_BARRIER_ERROR, _
                      NAVIGATION_RECOVERY_HARD_BARRIER_SOURCE & _
                          "OnInputChange.AccountDate/EnforceError", _
                      recoveryDetail
        End If
        If Not eventsReadyForRecovery Then
            AppendNavigationSafetyDetail recoveryDetail, _
                "Recovery処理後のExcelイベント停止を確認できません: " & _
                postRecoveryStopDetail
            Err.Raise NAVIGATION_RECOVERY_HARD_BARRIER_ERROR, _
                      NAVIGATION_RECOVERY_HARD_BARRIER_SOURCE & _
                          "OnInputChange.AccountDate/PostFalseFailed", _
                      recoveryDetail
        End If
        If Not TryConfirmNavigationRecoveryBarrierReady(recoveryDetail) Then _
            Err.Raise NAVIGATION_RECOVERY_HARD_BARRIER_ERROR, _
                      NAVIGATION_RECOVERY_HARD_BARRIER_SOURCE & _
                          "OnInputChange.AccountDate/RecoveryGateFailed", _
                      recoveryDetail
        Err.Raise NAVIGATION_RECOVERY_HARD_BARRIER_ERROR, _
                  NAVIGATION_RECOVERY_HARD_BARRIER_SOURCE & _
                      "OnInputChange.AccountDate/EnforceReturned", _
                  recoveryDetail
    ElseIf Not eventsReadyForRecovery Then
        AppendNavigationSafetyDetail recoveryDetail, _
            "Recovery書込みを見送り、案件の安全状態は不明です。"
    End If

    If eventsCaptured Then
        safeToRestoreEntry = Not previousEvents
        If previousEvents Then
            safeToRestoreEntry = protectOK
            If Not safeToRestoreEntry And recoveryErrorNumber = 0 And _
               eventsReadyForRecovery And recoveryStateConfirmed Then
                applicationStateProblems = vbNullString
                applicationStateSafe = _
                    AppStateIsRestored(applicationStateProblems)
                safeToRestoreEntry = applicationStateSafe
                If Not applicationStateSafe Then _
                    AppendNavigationSafetyDetail recoveryDetail, _
                        "Application状態の安全を確認できません: " & _
                        applicationStateProblems
            End If
        End If
        If safeToRestoreEntry Then
            If Not TryRestoreNavigationEnableEvents( _
                       previousEvents, "OnInputChange/口座日付", _
                       eventStateDetail) Then _
                AppendNavigationSafetyDetail recoveryDetail, eventStateDetail
        Else
            eventStateDetail = vbNullString
            If Not TryStopNavigationEventsForBookWrites(eventStateDetail) Then _
                AppendNavigationSafetyDetail recoveryDetail, _
                    "開始値Trueを禁止した後のFalse収束も確認できません: " & _
                    eventStateDetail
        End If
        eventsCaptured = False
    End If
    If Len(recoveryDetail) > 0 Then _
        AppendNavigationSafetyDetail errorDescription, recoveryDetail
    Err.Raise errorNumber, "OnInputChange/口座日付", errorDescription
End Sub

Public Sub OnConfigChange(ByVal Target As Range)
    Dim watched As Range, watchedAnalysis As Range, watchedEra As Range
    Dim watchedBalance As Range, watchedBalanceYears As Range
    Dim watchedDateInterpretation As Range
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim balanceDetail As String
    Dim safetyDetail As String, undoDetail As String
    Dim configurationStopConfirmed As Boolean
    Dim recoveryEnforcementFailed As Boolean
    Dim localRollbackConfirmed As Boolean
    Dim normalChangeCompleted As Boolean, safeToRestoreEntry As Boolean
    Dim applicationStateSafe As Boolean
    Dim previousEvents As Boolean, eventsCaptured As Boolean
    Dim eventsReadyForBookWrites As Boolean
    Dim eventRestoreDetail As String, finalEventStateDetail As String
    Dim applicationStateProblems As String
    If Target Is Nothing Then Exit Sub
    If Target.Worksheet.Name <> SH_CONFIG Then Exit Sub
    Set watched = Intersect(Target, Union( _
        Target.Worksheet.Range("C4:C17"), _
        Target.Worksheet.Range( _
            Target.Worksheet.Cells(ROW_CFG_ANALYSIS_MIN_AMOUNT, COL_CFG_ANALYSIS_VALUE), _
            Target.Worksheet.Cells(ROW_CFG_ANALYSIS_UNKNOWN_MIN, COL_CFG_ANALYSIS_VALUE)), _
        Target.Worksheet.Range( _
            Target.Worksheet.Cells(ERA_MASTER_FIRST_ROW, ERA_COL_CODE), _
            Target.Worksheet.Cells(ERA_MASTER_MAX_ROW, ERA_COL_ENABLED))))
    If watched Is Nothing Then Exit Sub
    On Error GoTo EH
    If Not TryGetNavigationEnableEvents(previousEvents, eventRestoreDetail) Then
        StopAfterNavigationEventStateFailure _
            "OnConfigChange/開始状態取得", eventRestoreDetail
        Err.Raise vbObjectError + 3346, "OnConfigChange", _
                  "Excelイベントの開始状態を取得できませんでした。 " & _
                  eventRestoreDetail
    End If
    eventsCaptured = True
    If Not TryStopNavigationEventsForBookWrites(eventRestoreDetail) Then
        safetyDetail = _
            "設定変更処理の開始前にExcelイベントを停止して読戻し確認できませんでした。 " & _
            eventRestoreDetail
        On Error Resume Next
        MsgBox safetyDetail & vbCrLf & _
               "ブックへの要更新・入力更新・状態表示は行わず、案件の安全状態は不明です。", _
               vbCritical, "設定変更を安全に処理できません"
        On Error GoTo EH
        If Not TryRestoreNavigationEnableEvents( _
                   previousEvents, "OnConfigChange/処理開始前", _
                   eventRestoreDetail) Then _
            AppendNavigationSafetyDetail safetyDetail, eventRestoreDetail
        eventsCaptured = False
        Err.Raise vbObjectError + 3347, "OnConfigChange", safetyDetail
    End If
    eventsReadyForBookWrites = True
    Set watchedBalance = Intersect(watched, Target.Worksheet.Range("C4:C6"))
    Set watchedBalanceYears = Intersect(watched, Target.Worksheet.Range( _
        Target.Worksheet.Cells(ROW_CFG_BAL_START_YEAR, COL_CFG_VALUE), _
        Target.Worksheet.Cells(ROW_CFG_BAL_END_YEAR, COL_CFG_VALUE)))
    Set watchedDateInterpretation = Intersect(watched, Union( _
        Target.Worksheet.Cells(ROW_CFG_INHERITANCE_DATE, COL_CFG_VALUE), _
        Target.Worksheet.Cells(ROW_CFG_YEAR_ADD, COL_CFG_VALUE), _
        Target.Worksheet.Cells(ROW_CFG_YEAR_MODE, COL_CFG_VALUE), _
        Target.Worksheet.Range( _
            Target.Worksheet.Cells(ERA_MASTER_FIRST_ROW, ERA_COL_CODE), _
            Target.Worksheet.Cells(ERA_MASTER_MAX_ROW, ERA_COL_ENABLED))))
    If Not watchedDateInterpretation Is Nothing And SheetExists(SH_INPUT) Then
        '相続開始日・年加算値・年入力方式・元号マスタは、残高欄だけでなく未登録の取引日と
        '口座日付の解釈も変える。入力が残る間は変更を即時に戻し、無警告で
        '別年登録される経路を作らない。
        If IsEditMode() Or CurrentAccountInputHasData() Then
            'Worksheet_Change直後、ブックへ別の書込みを行う前に設定変更を取り消す。
            If TryUndoConfigurationChange( _
                   undoDetail, eventsReadyForBookWrites) Then
                localRollbackConfirmed = True
                SetInputStatus "未登録入力・訂正内容の日付を保護するため設定変更を取り消しました。先に登録・訂正完了または入力消去を行ってください。", True
            ElseIf eventsReadyForBookWrites Then
                'Undo不能時は安全状態を永続化し、入力消去まで登録をfail-closedにする。
                configurationStopConfirmed = _
                    StopConfigurationAfterUndoFailure( _
                        safetyDetail, eventsReadyForBookWrites, _
                        recoveryEnforcementFailed)
                If Len(undoDetail) > 0 Then
                    If Len(safetyDetail) > 0 Then safetyDetail = undoDetail & " / " & safetyDetail Else safetyDetail = undoDetail
                End If
                If eventsReadyForBookWrites Then
                    If configurationStopConfirmed Then
                        SetInputStatus "入力中に暦設定が変更され、自動で元へ戻せませんでした。誤登録防止のため入力消去まで登録を停止しています。", True
                    End If
                    MsgBox "未登録入力がある状態で日付の解釈設定が変更され、自動で取り消せませんでした。" & vbCrLf & _
                           IIf(configurationStopConfirmed, _
                               "誤った年で登録しないため、現在の入力は登録できません。内容を控え、［入力内容を消去］後に現在の設定で再入力してください。", _
                               "案件の安全状態を確認できません。C_チェックを確認し、現在のブックを上書きしないでください。") & _
                           IIf(Len(safetyDetail) > 0, vbCrLf & vbCrLf & safetyDetail, ""), _
                           vbExclamation, "日付設定の変更を安全に戻せません"
                Else
                    MsgBox "日付設定の変更を安全に取り消せず、Excelイベントの停止も再確認できませんでした。" & _
                           vbCrLf & "ブックへの停止・復旧・診断記録を見送り、案件の安全状態は不明です。" & _
                           vbCrLf & "現在のブックを上書きしないでください。" & _
                           IIf(Len(safetyDetail) > 0, vbCrLf & vbCrLf & safetyDetail, ""), _
                           vbCritical, "日付設定の安全状態を確認できません"
                End If
            Else
                safetyDetail = undoDetail
                AppendNavigationSafetyDetail safetyDetail, _
                    "Excelイベント停止を確認できないため、ブックへの停止・Recovery・診断・状態表示の書込みを見送りました。案件の安全状態は不明です。"
                MsgBox "日付設定の変更を安全に取り消せず、Excelイベントの停止も確認できませんでした。" & _
                       vbCrLf & "ブックへの復旧記録を見送り、案件の安全状態は不明です。" & _
                       vbCrLf & "現在のブックを上書きしないでください。" & _
                       IIf(Len(safetyDetail) > 0, vbCrLf & vbCrLf & safetyDetail, ""), _
                       vbCritical, "日付設定の安全状態を確認できません"
            End If
            GoTo ConfigurationUndoExit
        End If
    End If
    If Not watchedBalanceYears Is Nothing And SheetExists(SH_INPUT) Then
        'C5/C6は残高表示範囲だけを変え、取引日や口座日付の解釈は変えない。
        '残高値・メモが空なら、ほかの未登録入力や訂正中入力を保持したまま再構築する。
        If HasPendingBalanceInputValues(GetSheet(SH_INPUT)) Then
            If TryUndoConfigurationChange( _
                   undoDetail, eventsReadyForBookWrites) Then
                localRollbackConfirmed = True
                SetInputStatus "入力中の残高・メモを保護するため残高表示年の変更を取り消しました。先に口座を登録するか、残高入力を消去してください。", True
            ElseIf eventsReadyForBookWrites Then
                configurationStopConfirmed = _
                    StopConfigurationAfterUndoFailure( _
                        safetyDetail, eventsReadyForBookWrites, _
                        recoveryEnforcementFailed)
                If Len(undoDetail) > 0 Then
                    If Len(safetyDetail) > 0 Then safetyDetail = undoDetail & " / " & safetyDetail Else safetyDetail = undoDetail
                End If
                If eventsReadyForBookWrites Then
                    If configurationStopConfirmed Then
                        SetInputStatus "残高表示年を元へ戻せず、入力中の残高を安全に再構築できないため、入力消去まで登録を停止しています。", True
                    End If
                    MsgBox "入力中の残高またはメモがある状態で残高表示年が変更され、自動で取り消せませんでした。" & vbCrLf & _
                           IIf(configurationStopConfirmed, _
                               "現在の入力は登録できません。内容を控え、［入力内容を消去］後に現在の設定で再入力してください。", _
                               "案件の安全状態を確認できません。C_チェックを確認し、現在のブックを上書きしないでください。") & _
                           IIf(Len(safetyDetail) > 0, vbCrLf & vbCrLf & safetyDetail, ""), _
                           vbExclamation, "残高表示年の変更を安全に戻せません"
                Else
                    MsgBox "残高表示年の変更を安全に取り消せず、Excelイベントの停止も再確認できませんでした。" & _
                           vbCrLf & "ブックへの停止・復旧・診断記録を見送り、案件の安全状態は不明です。" & _
                           vbCrLf & "現在のブックを上書きしないでください。" & _
                           IIf(Len(safetyDetail) > 0, vbCrLf & vbCrLf & safetyDetail, ""), _
                           vbCritical, "残高設定の安全状態を確認できません"
                End If
            Else
                safetyDetail = undoDetail
                AppendNavigationSafetyDetail safetyDetail, _
                    "Excelイベント停止を確認できないため、ブックへの停止・Recovery・診断・状態表示の書込みを見送りました。案件の安全状態は不明です。"
                MsgBox "残高表示年の変更を安全に取り消せず、Excelイベントの停止も確認できませんでした。" & _
                       vbCrLf & "ブックへの復旧記録を見送り、案件の安全状態は不明です。" & _
                       vbCrLf & "現在のブックを上書きしないでください。" & _
                       IIf(Len(safetyDetail) > 0, vbCrLf & vbCrLf & safetyDetail, ""), _
                       vbCritical, "残高設定の安全状態を確認できません"
            End If
            GoTo ConfigurationUndoExit
        End If
    End If
    MarkOutputsDirty
    If Not Intersect(watched, Union( _
        Target.Worksheet.Cells(ROW_CFG_YEAR_ADD, COL_CFG_VALUE), _
        Target.Worksheet.Cells(ROW_CFG_YEAR_MODE, COL_CFG_VALUE))) Is Nothing Then _
        InvalidateDateComplementCache
    If Not Intersect(watched, Target.Worksheet.Cells(ROW_CFG_RELATIONSHIP, COL_CFG_VALUE)) Is Nothing Then _
        ApplyRelationshipSettingToInput True
    If Not Intersect(watched, Target.Worksheet.Cells(ROW_CFG_INHERITANCE_DATE, COL_CFG_VALUE)) Is Nothing Then
        If IsDate(GetCfgDateValue(ROW_CFG_INHERITANCE_DATE)) Then
            Target.Worksheet.Cells(ROW_CFG_INHERITANCE_DATE, COL_CFG_VALUE).Interior.Color = RGB(220, 252, 231)
        Else
            Target.Worksheet.Cells(ROW_CFG_INHERITANCE_DATE, COL_CFG_VALUE).Interior.Color = RGB(254, 249, 195)
        End If
    End If
    Set watchedAnalysis = Intersect(watched, Target.Worksheet.Range( _
        Target.Worksheet.Cells(ROW_CFG_ANALYSIS_MIN_AMOUNT, COL_CFG_ANALYSIS_VALUE), _
        Target.Worksheet.Cells(ROW_CFG_ANALYSIS_UNKNOWN_MIN, COL_CFG_ANALYSIS_VALUE)))
    Set watchedEra = Intersect(watched, Target.Worksheet.Range( _
        Target.Worksheet.Cells(ERA_MASTER_FIRST_ROW, ERA_COL_CODE), _
        Target.Worksheet.Cells(ERA_MASTER_MAX_ROW, ERA_COL_ENABLED)))
    If Not watchedEra Is Nothing Then
        InvalidateDateComplementCache
        SetInputStatus "元号マスタを変更しました。開始日・終了日を確認してください。"
    ElseIf Not watchedAnalysis Is Nothing Then
        SetInputStatus "分析条件を変更しました。『帳票・分析を更新』で候補を再抽出してください。"
    ElseIf Not watchedBalance Is Nothing Then
        If EnsureBalanceInputStructureCurrent(GetSheet(SH_INPUT), balanceDetail) Then
            SetInputStatus "残高基準の設定を変更し、残高入力欄を自動更新しました。"
        Else
            SetInputStatus "残高基準の設定を確認してください: " & balanceDetail, True
        End If
    Else
        SetInputStatus "設定を変更しました。最終出力時に帳票を最新化します。"
    End If
    normalChangeCompleted = True
    GoTo ConfigurationUndoExit
ConfigurationUndoExit:
    '開始値へ戻せるのは、確実な局所Undo、正常変更完了、または独立ラッチと
    'healthの二重確認を完了したRecoveryのどれかと、post-False・Application安全を
    '同時に確認できた場合だけとする。
    finalEventStateDetail = vbNullString
    eventsReadyForBookWrites = _
        TryStopNavigationEventsForBookWrites(finalEventStateDetail)
    If recoveryEnforcementFailed Then
        applicationStateSafe = False
    Else
        applicationStateProblems = vbNullString
        applicationStateSafe = AppStateIsRestored(applicationStateProblems)
    End If
    safeToRestoreEntry = eventsReadyForBookWrites And applicationStateSafe And _
        (normalChangeCompleted Or localRollbackConfirmed Or _
         configurationStopConfirmed)
    If eventsCaptured Then
        If safeToRestoreEntry Then
            If Not TryRestoreNavigationEnableEvents( _
                       previousEvents, "OnConfigChange/終了", _
                       eventRestoreDetail) Then
                eventsCaptured = False
                Err.Raise vbObjectError + 3344, "OnConfigChange", _
                          "設定変更の取消後にExcelイベント状態を復元できませんでした。 " & _
                          eventRestoreDetail
            End If
        Else
            If Not eventsReadyForBookWrites Then _
                AppendNavigationSafetyDetail safetyDetail, _
                    "終了時のExcelイベントをFalseへ収束できず、状態は不明です: " & _
                    finalEventStateDetail
            If Not applicationStateSafe Then _
                AppendNavigationSafetyDetail safetyDetail, _
                    "Application状態の安全を確認できません: " & _
                    applicationStateProblems
            If eventsReadyForBookWrites Then _
                AppendNavigationSafetyDetail safetyDetail, _
                    "局所Undoまたは要復旧の確定条件が揃わないため、" & _
                    "ExcelイベントをFalseに保持しました。"
            On Error Resume Next
            MsgBox "設定変更後の安全状態を一意に確定できないため、" & _
                   "Excelイベントを開始値へ戻していません。" & vbCrLf & _
                   "現在のブックを上書きしないでください。" & _
                   IIf(Len(safetyDetail) > 0, vbCrLf & vbCrLf & safetyDetail, vbNullString), _
                   vbCritical, "設定変更後の安全状態を確認できません"
            On Error GoTo EH
        End If
        eventsCaptured = False
    End If
    Exit Sub
EH:
    errorNumber = Err.Number
    errorSource = Err.Source
    errorDescription = Err.Description
    If IsNavigationRecoveryHardBarrier(errorNumber, errorSource) Then
        Call TryStopNavigationEventsForBookWrites(finalEventStateDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    If eventsCaptured Then
        finalEventStateDetail = vbNullString
        eventsReadyForBookWrites = _
            TryStopNavigationEventsForBookWrites(finalEventStateDetail)
        If recoveryEnforcementFailed Then
            applicationStateSafe = False
        Else
            applicationStateProblems = vbNullString
            applicationStateSafe = AppStateIsRestored(applicationStateProblems)
        End If
        safeToRestoreEntry = eventsReadyForBookWrites And _
            applicationStateSafe And _
            (localRollbackConfirmed Or configurationStopConfirmed)
        If safeToRestoreEntry Then
            If Not TryRestoreNavigationEnableEvents( _
                       previousEvents, "OnConfigChange/異常終了", _
                       eventRestoreDetail) Then _
                AppendNavigationSafetyDetail errorDescription, _
                    "Excelイベント状態の復元エラー: " & eventRestoreDetail
        Else
            If Not eventsReadyForBookWrites Then _
                AppendNavigationSafetyDetail errorDescription, _
                    "異常終了時のExcelイベントをFalseへ収束できません: " & _
                    finalEventStateDetail
            If Not applicationStateSafe Then _
                AppendNavigationSafetyDetail errorDescription, _
                    "Application状態の安全を確認できません: " & _
                    applicationStateProblems
            If eventsReadyForBookWrites Then _
                AppendNavigationSafetyDetail errorDescription, _
                    "局所Undoまたは要復旧を確定できないため、" & _
                    "ExcelイベントをFalseに保持しました。"
        End If
        eventsCaptured = False
    End If
    Err.Raise errorNumber, "OnConfigChange", errorDescription
End Sub

Private Function TryUndoConfigurationChange( _
        ByRef detailText As String, _
        ByRef eventsStoppedConfirmed As Boolean) As Boolean
    'Worksheet_Changeが発火した時点で設定値は変更済みであるため、イベント制御の
    'False lease確認・Undoのどの失敗も、呼出元で登録停止へ倒せるよう結果化する。
    Dim undoSucceeded As Boolean
    Dim eventStateDetail As String

    detailText = vbNullString
    On Error Resume Next
    Err.Clear
    'OnConfigChangeが保持するhandler-wide False leaseをUndo直前にも再確認する。
    eventsStoppedConfirmed = _
        TryStopNavigationEventsForBookWrites(eventStateDetail)
    If Not eventsStoppedConfirmed Then
        AppendNavigationSafetyDetail detailText, eventStateDetail
        GoTo Complete
    End If

    Err.Clear
    Application.Undo
    If Err.Number <> 0 Then
        AppendNavigationSafetyDetail detailText, "設定変更の取消: Err " & _
                                     CStr(Err.Number) & " " & Err.Description
        Err.Clear
    Else
        undoSucceeded = True
    End If

Complete:
    '呼出元の停止記録・状態表示・診断隔離が終わるまでFalse leaseを保持する。
    '開始値への厳密復元はOnConfigChangeの共通最終処理だけが行う。
    TryUndoConfigurationChange = (undoSucceeded And eventsStoppedConfirmed)
    Err.Clear
    On Error GoTo 0
End Function

Private Sub AppendNavigationSafetyDetail(ByRef detailText As String, ByVal itemText As String)
    If Len(itemText) = 0 Then Exit Sub
    If Len(detailText) > 0 Then detailText = detailText & " / "
    detailText = detailText & itemText
End Sub

Private Function IsNavigationRecoveryHardBarrier( _
        ByVal errorNumber As Long, _
        ByVal errorSource As String) As Boolean
    Dim expectedSource As String

    '3599/4499は複数moduleが共有するcode-only hard barrierである。
    If errorNumber = vbObjectError + 3599 Or _
       errorNumber = vbObjectError + 4499 Then
        IsNavigationRecoveryHardBarrier = True
        Exit Function
    End If
    Select Case errorNumber
        Case vbObjectError + 5191
            expectedSource = "AnalysisWorkspaceRecoveryFatal/"
        Case vbObjectError + 5192
            expectedSource = "SetupConvergeRecoveryFatal/"
        Case vbObjectError + 5194
            expectedSource = "CashAnalysisRecoveryFatal/"
        Case vbObjectError + 5195
            expectedSource = "TransactionAnalysisRecoveryFatal/"
        Case vbObjectError + 5196
            expectedSource = "CashManualSelectionRecoveryFatal/"
        Case vbObjectError + 5197
            expectedSource = "ClearRecoveryFatal/"
        Case Else
            Exit Function
    End Select
    If Len(errorSource) < Len(expectedSource) Then Exit Function
    IsNavigationRecoveryHardBarrier = _
        (StrComp(Left$(errorSource, Len(expectedSource)), expectedSource, _
                 vbBinaryCompare) = 0)
End Function

Private Function TryConfirmNavigationRecoveryBarrierReady( _
        ByRef detailText As String) As Boolean
    Dim confirmationDetail As String
    Dim applicationStateProblems As String
    Dim finalStopDetail As String

    If Not TryConfirmNavigationRecoveryState(confirmationDetail) Then
        AppendNavigationSafetyDetail detailText, _
            "Recoveryの二重状態を確認できません: " & confirmationDetail
        Call TryStopNavigationEventsForBookWrites(finalStopDetail)
        Exit Function
    End If
    applicationStateProblems = vbNullString
    If Not AppStateIsRestored(applicationStateProblems) Then
        AppendNavigationSafetyDetail detailText, _
            "Application状態の安全を確認できません: " & _
            applicationStateProblems
        Call TryStopNavigationEventsForBookWrites(finalStopDetail)
        Exit Function
    End If
    If Not TryStopNavigationEventsForBookWrites(finalStopDetail) Then
        AppendNavigationSafetyDetail detailText, _
            "最終Excelイベント停止を確認できません: " & finalStopDetail
        Exit Function
    End If
    TryConfirmNavigationRecoveryBarrierReady = True
End Function

Private Function TryConfirmInputNavigationStatus( _
        ByVal ws As Worksheet, _
        ByVal expectedText As String, _
        ByRef detailText As String) As Boolean
    Dim actualValue As Variant
    Dim errorNumber As Long, errorDescription As String
    detailText = vbNullString
    On Error GoTo EH
    If ws Is Nothing Then _
        Err.Raise vbObjectError + 3356, "TryConfirmInputNavigationStatus", _
                  "入力状態欄のシートを取得できません。"
    actualValue = ws.Range(CELL_STATUS).Value2
    If IsError(actualValue) Or IsNull(actualValue) Then _
        Err.Raise vbObjectError + 3357, "TryConfirmInputNavigationStatus", _
                  "入力状態欄を文字列として読み戻せません。"
    If StrComp(CStr(actualValue), expectedText, vbBinaryCompare) <> 0 Then _
        Err.Raise vbObjectError + 3358, "TryConfirmInputNavigationStatus", _
                  "入力状態欄の書込み後読戻しが一致しません。"
    TryConfirmInputNavigationStatus = True
    Exit Function
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    detailText = "入力状態欄を厳密に書込み確認できません。Err " & _
                 CStr(errorNumber) & ": " & errorDescription
    Err.Clear
End Function

Private Function TryGetNavigationEnableEvents( _
        ByRef currentValue As Boolean, _
        ByRef detailText As String) As Boolean
    Dim errorNumber As Long, errorDescription As String
    detailText = vbNullString
    On Error GoTo EH
    currentValue = Application.EnableEvents
    TryGetNavigationEnableEvents = True
    Exit Function
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    detailText = "Err " & CStr(errorNumber) & ": " & errorDescription
    Err.Clear
End Function

Private Function TrySetNavigationEnableEventsExact( _
        ByVal desiredValue As Boolean, _
        ByRef detailText As String) As Boolean
    Dim errorNumber As Long, errorDescription As String
    detailText = vbNullString
    On Error GoTo EH
    Application.EnableEvents = desiredValue
    If Application.EnableEvents <> desiredValue Then _
        Err.Raise vbObjectError + 3331, "TrySetNavigationEnableEventsExact", _
                  "EnableEventsの書込み後読戻しが一致しません。"
    TrySetNavigationEnableEventsExact = True
    Exit Function
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    detailText = "Err " & CStr(errorNumber) & ": " & errorDescription
    Err.Clear
End Function

Private Function TryRestoreInputNavigationEventsFinal( _
        ByVal previousValue As Boolean, _
        ByRef detailText As String) As Boolean
    '入力ナビゲーション復旧の最終処理専用。失敗後はブックへ復旧記録を追加せず、
    'Falseへの読戻し収束だけを行う。
    Dim firstDetail As String, retryDetail As String, stopDetail As String
    detailText = vbNullString
    If TrySetNavigationEnableEventsExact(previousValue, firstDetail) Then
        TryRestoreInputNavigationEventsFinal = True
        Exit Function
    End If
    If TrySetNavigationEnableEventsExact(previousValue, retryDetail) Then
        TryRestoreInputNavigationEventsFinal = True
        Exit Function
    End If
    detailText = "Excelイベント状態を所有済みの返却先値へ復元できませんでした。初回=" & _
                 firstDetail & " / 再試行=" & retryDetail
    If TryStopNavigationEventsForBookWrites(stopDetail) Then
        AppendNavigationSafetyDetail detailText, _
            "失敗後のExcelイベントはFalseと読み戻し確認しました。"
    Else
        AppendNavigationSafetyDetail detailText, _
            "失敗後のExcelイベントをFalseへ収束できず、状態は不明です: " & _
            stopDetail
    End If
End Function

Private Function TryStopNavigationEventsForBookWrites( _
        ByRef detailText As String) As Boolean
    Dim firstDetail As String, retryDetail As String
    detailText = vbNullString
    If TrySetNavigationEnableEventsExact(False, firstDetail) Then
        TryStopNavigationEventsForBookWrites = True
        Exit Function
    End If
    If TrySetNavigationEnableEventsExact(False, retryDetail) Then
        TryStopNavigationEventsForBookWrites = True
        Exit Function
    End If
    detailText = "ExcelイベントをFalseへ停止して読戻し確認できませんでした。初回=" & _
                 firstDetail & " / 再試行=" & retryDetail
End Function

Private Function TryConfirmNavigationRecoveryState( _
        ByRef detailText As String) As Boolean
    Dim latchIsSet As Boolean, latchReadSucceeded As Boolean
    Dim healthValue As String, healthReadSucceeded As Boolean
    latchReadSucceeded = TryGetRollbackRecoveryLatch(latchIsSet)
    healthReadSucceeded = TryGetExactStateValue(STATE_DATA_HEALTH, healthValue)
    If Not latchReadSucceeded Or Not latchIsSet Then _
        AppendNavigationSafetyDetail detailText, _
            "独立復旧ラッチを設定済みとして一意に確認できません。"
    If Not healthReadSucceeded Or _
       StrComp(healthValue, DATA_HEALTH_NEEDS_RECOVERY, vbBinaryCompare) <> 0 Then _
        AppendNavigationSafetyDetail detailText, _
            "案件要復旧状態を一意に確認できません。"
    TryConfirmNavigationRecoveryState = _
        latchReadSucceeded And latchIsSet And healthReadSucceeded And _
        (StrComp(healthValue, DATA_HEALTH_NEEDS_RECOVERY, vbBinaryCompare) = 0)
End Function

Private Function TryRestoreNavigationEnableEvents( _
        ByVal previousValue As Boolean, _
        ByVal operationName As String, _
        ByRef detailText As String) As Boolean
    Dim firstDetail As String, retryDetail As String
    detailText = vbNullString
    If TrySetNavigationEnableEventsExact(previousValue, firstDetail) Then
        TryRestoreNavigationEnableEvents = True
        Exit Function
    End If
    '一時的なCOM失敗なら同じ開始値への再試行で収束させる。成功しない場合だけ要復旧へ倒す。
    If TrySetNavigationEnableEventsExact(previousValue, retryDetail) Then
        TryRestoreNavigationEnableEvents = True
        Exit Function
    End If
    detailText = "Excelイベント状態を開始値へ復元できませんでした。初回=" & _
                 firstDetail & " / 再試行=" & retryDetail
    '中央Recoveryを一度でも試行した後は、この入口をterminalとする。
    'StopAfterは試行時にhard barrierをraiseし、試行前停止不能時だけFalseを返す。
    'いずれの場合も開始値Trueへの再試行は行わない。
    Call StopAfterNavigationEventStateFailure(operationName, detailText)
End Function

Private Function StopAfterNavigationEventStateFailure( _
        ByVal operationName As String, _
        ByRef detailText As String) As Boolean
    Dim recoveryDetail As String, stopDetail As String
    Dim postRecoveryStopDetail As String
    Dim recoveryErrorNumber As Long, recoveryErrorDescription As String
    Dim postRecoveryStopped As Boolean
    recoveryDetail = operationName & ": " & detailText
    If Not TryStopNavigationEventsForBookWrites(stopDetail) Then
        AppendNavigationSafetyDetail recoveryDetail, _
            "イベント停止未確認のため、ブックへのRecovery・診断・状態表示の書込みを見送りました: " & _
            stopDetail
        AppendNavigationSafetyDetail recoveryDetail, _
            "Excelイベント状態と案件の安全状態は不明です。"
        detailText = recoveryDetail
        Exit Function
    End If
    AppendNavigationSafetyDetail recoveryDetail, _
        "要復旧記録前にExcelイベント停止を読戻し確認しました。"
    On Error Resume Next
    Err.Clear
    EnforceRollbackRecoveryState recoveryDetail
    recoveryErrorNumber = Err.Number
    recoveryErrorDescription = Err.Description
    Err.Clear
    On Error GoTo 0

    '共通Recoveryは自身の開始値へイベントを返す契約のため、
    '外側へhard barrierを伝播する前にFalseを改めて読み戻す。
    postRecoveryStopDetail = vbNullString
    postRecoveryStopped = _
        TryStopNavigationEventsForBookWrites(postRecoveryStopDetail)
    If Not postRecoveryStopped Then _
        AppendNavigationSafetyDetail recoveryDetail, _
            "共通復旧処理後のExcelイベント停止を確認できません: " & _
            postRecoveryStopDetail
    If recoveryErrorNumber <> 0 Then
        AppendNavigationSafetyDetail recoveryDetail, _
            "要復旧状態の強制設定エラー: Err " & _
            CStr(recoveryErrorNumber) & " " & recoveryErrorDescription
        detailText = recoveryDetail
        Err.Raise NAVIGATION_RECOVERY_HARD_BARRIER_ERROR, _
                  NAVIGATION_RECOVERY_HARD_BARRIER_SOURCE & _
                      "StopAfterNavigationEventStateFailure/EnforceError", _
                  recoveryDetail
    End If
    If Not postRecoveryStopped Then
        detailText = recoveryDetail
        Err.Raise NAVIGATION_RECOVERY_HARD_BARRIER_ERROR, _
                  NAVIGATION_RECOVERY_HARD_BARRIER_SOURCE & _
                      "StopAfterNavigationEventStateFailure/PostFalseFailed", _
                  recoveryDetail
    End If
    If Not TryConfirmNavigationRecoveryBarrierReady(recoveryDetail) Then
        detailText = recoveryDetail
        Err.Raise NAVIGATION_RECOVERY_HARD_BARRIER_ERROR, _
                  NAVIGATION_RECOVERY_HARD_BARRIER_SOURCE & _
                      "StopAfterNavigationEventStateFailure/RecoveryGateFailed", _
                  recoveryDetail
    End If
    detailText = recoveryDetail
    Err.Raise NAVIGATION_RECOVERY_HARD_BARRIER_ERROR, _
              NAVIGATION_RECOVERY_HARD_BARRIER_SOURCE & _
                  "StopAfterNavigationEventStateFailure/EnforceReturned", _
              recoveryDetail
End Function

Private Function StopConfigurationAfterUndoFailure( _
        ByRef detailText As String, _
        ByRef eventsStoppedConfirmed As Boolean, _
        ByRef recoveryEnforcementFailed As Boolean) As Boolean
    '停止値は書込み例外がないだけで成功とせず、必須キーの一意読取りとFalse一致まで確認する。
    Dim stoppedValue As String, dirtyValue As String
    Dim errorNumber As Long, errorDescription As String
    Dim recoveryErrorNumber As Long, recoveryErrorDescription As String
    Dim recoveryErrorSource As String
    Dim stopConfirmed As Boolean, dirtyConfirmed As Boolean
    Dim eventStateDetail As String, postRecoveryStopDetail As String

    detailText = vbNullString
    eventsStoppedConfirmed = _
        TryStopNavigationEventsForBookWrites(eventStateDetail)
    If Not eventsStoppedConfirmed Then
        AppendNavigationSafetyDetail detailText, _
            "Excelイベント停止を確認できないため、ブックへの停止・Recovery・診断・状態表示の書込みを見送りました: " & _
            eventStateDetail
        AppendNavigationSafetyDetail detailText, _
            "Excelイベント状態と案件の安全状態は不明です。"
        Exit Function
    End If
    On Error Resume Next
    Err.Clear
    SetStateValue STATE_INPUT_DATE_CONFIG_SAFE, STATE_FALSE
    If Err.Number <> 0 Then
        errorNumber = Err.Number
        errorDescription = Err.Description
        detailText = "日付安全状態の停止書込み: Err " & _
                     CStr(errorNumber) & " " & errorDescription
        Err.Clear
    Else
        stopConfirmed = TryGetExactStateValue(STATE_INPUT_DATE_CONFIG_SAFE, stoppedValue)
        If Not stopConfirmed Or stoppedValue <> STATE_FALSE Then _
            detailText = "日付安全状態をFalseとして一意に読み返せません。"
    End If

    Err.Clear
    MarkOutputsDirty
    If Err.Number <> 0 Then
        If Len(detailText) > 0 Then detailText = detailText & " / "
        detailText = detailText & "帳票要更新状態の記録: Err " & _
                     CStr(Err.Number) & " " & Err.Description
        Err.Clear
    Else
        dirtyConfirmed = TryGetExactStateValue(STATE_OUTPUT_DIRTY, dirtyValue)
        If Not dirtyConfirmed Or dirtyValue <> STATE_TRUE Then
            If Len(detailText) > 0 Then detailText = detailText & " / "
            detailText = detailText & "帳票要更新状態をTrueとして一意に読み返せません。"
        End If
    End If

    '局所の停止・帳票無効化だけでは、Undo不能後に開始時イベント値へ戻せる
    'Recovery確定とは扱わない。共通経路を一度試行した時点でhard barrierを返し、
    '外側ownerによる二重Enforceや通常終了処理を禁止する。
    Err.Clear
    EnforceRollbackRecoveryState detailText
    recoveryErrorNumber = Err.Number
    recoveryErrorSource = Err.Source
    recoveryErrorDescription = Err.Description
    Err.Clear

    '共通Recoveryが捕捉した開始値へイベントを返すため、後続のラッチ・health読取り、
    '診断、キー解除、隔離準備の全てより前にFalseを再取得する。
    eventsStoppedConfirmed = _
        TryStopNavigationEventsForBookWrites(postRecoveryStopDetail)
    recoveryEnforcementFailed = (recoveryErrorNumber <> 0)
    If recoveryErrorNumber <> 0 Then
        AppendNavigationSafetyDetail detailText, _
            "共通復旧停止処理: Err " & CStr(recoveryErrorNumber) & _
            " " & recoveryErrorDescription
    End If
    If Not eventsStoppedConfirmed Then
        AppendNavigationSafetyDetail detailText, _
            "共通復旧処理後のExcelイベント停止を確認できないため、" & _
            "復旧状態の読取り・診断・キー解除・隔離準備を見送りました: " & _
            postRecoveryStopDetail
        AppendNavigationSafetyDetail detailText, _
            "Excelイベント状態と案件の安全状態は不明です。"
    End If
    On Error GoTo 0
    If recoveryErrorNumber <> 0 Then
        Err.Raise NAVIGATION_RECOVERY_HARD_BARRIER_ERROR, _
                  NAVIGATION_RECOVERY_HARD_BARRIER_SOURCE & _
                      "StopConfigurationAfterUndoFailure/EnforceError", _
                  detailText
    End If
    If Not eventsStoppedConfirmed Then _
        Err.Raise NAVIGATION_RECOVERY_HARD_BARRIER_ERROR, _
                  NAVIGATION_RECOVERY_HARD_BARRIER_SOURCE & _
                      "StopConfigurationAfterUndoFailure/PostFalseFailed", _
                  detailText
    If Not TryConfirmNavigationRecoveryBarrierReady(detailText) Then _
        Err.Raise NAVIGATION_RECOVERY_HARD_BARRIER_ERROR, _
                  NAVIGATION_RECOVERY_HARD_BARRIER_SOURCE & _
                      "StopConfigurationAfterUndoFailure/RecoveryGateFailed", _
                  detailText
    Err.Raise NAVIGATION_RECOVERY_HARD_BARRIER_ERROR, _
              NAVIGATION_RECOVERY_HARD_BARRIER_SOURCE & _
                  "StopConfigurationAfterUndoFailure/EnforceReturned", _
              detailText
End Function

Private Sub HandleMultiCellInputChange(ByVal Target As Range)
    '複数行貼り付けを拒否せず、時刻と金額を一括で正規化する。
    '候補更新・セル移動・メッセージボックスは行わないため、大量貼り付けでも軽い。
    Dim ws As Worksheet
    Dim rng As Range, area As Range, changedRowDate As Range
    Dim firstInvalid As Range, firstInvalidDate As Range
    Dim dateRows As Object
    Dim memoCol As Long, invalidAmountCount As Long, invalidDateCount As Long
    Dim accountInvalidDateCount As Long
    Dim invalidTimeCount As Long, rowNo As Long, dateIndex As Long
    Dim minChangedRow As Long, minDateRow As Long, maxDateRow As Long
    Dim noticeFirstRow As Long, noticeLastRow As Long
    Dim problemSummary As String
    Dim protectionChanged As Boolean, accountDateOrderInvalid As Boolean
    Dim previousEvents As Boolean, eventsCaptured As Boolean
    Dim eventStateDetail As String
    Dim cleanupErrorNumber As Long, cleanupErrorDescription As String
    Dim cleanupErrorSource As String
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    If Target Is Nothing Then Exit Sub
    Set ws = Target.Worksheet
    If ws.Name <> SH_INPUT Then Exit Sub
    noticeFirstRow = ws.Rows.Count
    For Each area In Target.Areas
        If area.Row < noticeFirstRow Then noticeFirstRow = area.Row
        If area.Row + area.Rows.Count - 1 > noticeLastRow Then _
            noticeLastRow = area.Row + area.Rows.Count - 1
    Next area
    Set rng = Intersect(Target, ws.Range(ws.Cells(TX_FIRST_ROW, COL_TX_YEAR), _
                                         ws.Cells(TX_LAST_ROW, COL_TX_OTHER)))
    If Not rng Is Nothing Then
        minChangedRow = TX_LAST_ROW
        For Each area In rng.Areas
            If area.Row < minChangedRow Then minChangedRow = area.Row
        Next area
        InvalidateDateComplementCache minChangedRow
    End If
    On Error GoTo CleanUp
    If Not TryGetNavigationEnableEvents(previousEvents, eventStateDetail) Then
        StopAfterNavigationEventStateFailure _
            "HandleMultiCellInputChange/開始状態取得", eventStateDetail
        Err.Raise vbObjectError + 3341, "HandleMultiCellInputChange", _
                  "Excelイベントの開始状態を取得できませんでした。 " & eventStateDetail
    End If
    eventsCaptured = True
    If Not TrySetNavigationEnableEventsExact(False, eventStateDetail) Then _
        Err.Raise vbObjectError + 3342, "HandleMultiCellInputChange", _
                  "複数セル正規化前にExcelイベントを停止できませんでした。 " & _
                  eventStateDetail

    Set rng = Intersect(Target, ws.Range(ws.Cells(TX_FIRST_ROW, COL_TX_YEAR), _
                                         ws.Cells(TX_LAST_ROW, COL_TX_DAY)))
    If Not rng Is Nothing Then
        Set dateRows = CreateObject("Scripting.Dictionary")
        minDateRow = TX_LAST_ROW
        For Each area In rng.Areas
            For rowNo = area.Row To area.Row + area.Rows.Count - 1
                If Not dateRows.Exists(CStr(rowNo)) Then dateRows.Add CStr(rowNo), True
                If rowNo < minDateRow Then minDateRow = rowNo
                If rowNo > maxDateRow Then maxDateRow = rowNo
            Next rowNo
        Next area
        EnsureDateComplementCache ws, maxDateRow
        For rowNo = minDateRow To maxDateRow
            If dateRows.Exists(CStr(rowNo)) Then
                dateIndex = rowNo - TX_FIRST_ROW + 1
                'EnsureDateComplementCacheは範囲を配列で読み、数式行も一括取得する。
                If mDateCacheAnyInvalid(dateIndex) Or _
                   mDateCacheAnyIncomplete(dateIndex) Then
                    invalidDateCount = invalidDateCount + 1
                    If firstInvalid Is Nothing Then
                        Set changedRowDate = Intersect(rng, ws.Range(ws.Cells(rowNo, COL_TX_YEAR), _
                                                                     ws.Cells(rowNo, COL_TX_DAY)))
                        Set firstInvalid = changedRowDate.Cells(1, 1)
                    End If
                End If
            End If
        Next rowNo
    End If
    Set rng = Intersect(Target, ws.Range(ws.Cells(TX_FIRST_ROW, COL_TX_TIME), ws.Cells(TX_LAST_ROW, COL_TX_TIME)))
    If Not rng Is Nothing Then
        NormalizeTransactionTimeRangeBatch rng, invalidTimeCount, firstInvalid
    End If
    Set rng = Intersect(Target, Union( _
        ws.Range(ws.Cells(TX_FIRST_ROW, COL_TX_WITHDRAW), ws.Cells(TX_LAST_ROW, COL_TX_DEPOSIT)), _
        ws.Range(ws.Cells(TX_FIRST_ROW, COL_TX_BALANCE), ws.Cells(TX_LAST_ROW, COL_TX_BALANCE))))
    If Not rng Is Nothing Then
        NormalizeTransactionAmountRangeBatch rng, invalidAmountCount, firstInvalid
    End If
    memoCol = BalanceMemoCol(ws)
    If memoCol > BAL_FIRST_COL Then
        Set rng = Intersect(Target, ws.Range(ws.Cells(BAL_VALUE_ROW, BAL_FIRST_COL), _
                                             ws.Cells(BAL_VALUE_ROW, memoCol - 1)))
        If Not rng Is Nothing Then
            NormalizeTransactionAmountRangeBatch rng, invalidAmountCount, firstInvalid
        End If
    End If
    Set rng = Intersect(Target, Union(ws.Range(CELL_OPEN_DATE), ws.Range(CELL_CLOSE_DATE)))
    If Not rng Is Nothing Then
        Call NormalizeAccountDatePair(ws, firstInvalidDate, accountInvalidDateCount, accountDateOrderInvalid)
        If accountInvalidDateCount > 0 And firstInvalid Is Nothing Then Set firstInvalid = firstInvalidDate
        invalidDateCount = invalidDateCount + accountInvalidDateCount
        If accountInvalidDateCount = 0 Then
            ws.Unprotect Password:=TOOL_PASSWORD
            protectionChanged = True
            ApplyBalanceAvailability ws
            ProtectInputSheet True
            protectionChanged = False
        End If
    End If
CleanUp:
    errorNumber = Err.Number
    errorSource = Err.Source
    errorDescription = Err.Description
    If IsNavigationRecoveryHardBarrier(errorNumber, errorSource) Then
        Call TryStopNavigationEventsForBookWrites(eventStateDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    On Error Resume Next
    Err.Clear
    If protectionChanged Then ProtectInputSheet True
    cleanupErrorNumber = Err.Number
    cleanupErrorDescription = Err.Description
    cleanupErrorSource = Err.Source
    Err.Clear
    On Error GoTo 0
    If IsNavigationRecoveryHardBarrier( _
           cleanupErrorNumber, cleanupErrorSource) Then
        Call TryStopNavigationEventsForBookWrites(eventStateDetail)
        Err.Raise cleanupErrorNumber, cleanupErrorSource, _
                  cleanupErrorDescription
    End If
    If cleanupErrorNumber <> 0 Then
        If errorNumber = 0 Then
            errorNumber = cleanupErrorNumber
            errorDescription = cleanupErrorDescription
        Else
            AppendNavigationSafetyDetail errorDescription, _
                "入力シート再保護: Err " & CStr(cleanupErrorNumber) & _
                " " & cleanupErrorDescription
        End If
    End If
    If eventsCaptured Then
        If Not TryRestoreNavigationEnableEvents( _
                   previousEvents, "HandleMultiCellInputChange", eventStateDetail) Then
            If errorNumber = 0 Then
                errorNumber = vbObjectError + 3343
                errorDescription = eventStateDetail
            Else
                AppendNavigationSafetyDetail errorDescription, eventStateDetail
            End If
        End If
        eventsCaptured = False
    End If
    If errorNumber <> 0 Then
        '正規化途中で止まった場合は半更新の辞書を次の操作へ持ち越さない。
        InvalidatePendingInputErrorCache True
        Err.Raise errorNumber, "HandleMultiCellInputChange", errorDescription
    End If
    '小規模貼付は変更行だけを再検査する。明示年月日の変更だけは後続行の
    '省略日付へ影響するため必要範囲へ波及し、大量貼付・状態不明時は配列一括へ戻す。
    If mPendingInputErrorCacheReady And Not mInputErrorCacheRefreshRequired And _
       CDbl(Target.Cells.CountLarge) <= PENDING_ERROR_INCREMENTAL_PASTE_MAX_CELLS Then
        If Not TryRefreshPendingInputErrorCacheForMultiTarget(ws, Target) Then _
            RebuildPendingInputErrorCache ws
    Else
        RebuildPendingInputErrorCache ws
    End If
    mPendingMultiPasteValidation = PendingInputErrorCacheHasErrors()
    If ShowAllPendingInputErrors(ws) Then
        mPendingMultiPasteValidation = True
        AppendMultiPasteUndoNotice ws
        Exit Sub
    End If
    '全体走査で拾えない予期しない正規化失敗だけは、貼付範囲の情報で安全側に止める。
    If invalidDateCount > 0 Or invalidTimeCount > 0 Or invalidAmountCount > 0 Then
        mPendingMultiPasteValidation = True
        If firstInvalid Is Nothing Then Set firstInvalid = Target.Cells(1, 1)
        mLastEditedRow = firstInvalid.Row
        mLastEditedCol = firstInvalid.Column
        If invalidDateCount > 0 Then problemSummary = "日付 " & CStr(invalidDateCount) & "件"
        If invalidTimeCount > 0 Then
            If Len(problemSummary) > 0 Then problemSummary = problemSummary & "、"
            problemSummary = problemSummary & "時刻 " & CStr(invalidTimeCount) & "件"
        End If
        If invalidAmountCount > 0 Then
            If Len(problemSummary) > 0 Then problemSummary = problemSummary & "、"
            problemSummary = problemSummary & "金額 " & CStr(invalidAmountCount) & "件"
        End If
        SetInputStatus "貼り付けた値に解釈不能または日付逆転があります（" & problemSummary & _
                       "）。先頭: " & firstInvalid.Address(False, False), True
        AppendMultiPasteUndoNotice ws
        Exit Sub
    End If
    mPendingMultiPasteValidation = False
    If UpdateDuplicateAccountStatus(ws) Then
        AppendMultiPasteUndoNotice ws
        Exit Sub
    End If
    SetInputStatus "貼り付け " & Format$(CDbl(Target.Cells.CountLarge), "#,##0") & _
                   "セル（" & CStr(noticeFirstRow) & "～" & CStr(noticeLastRow) & _
                   "行）を反映しました。続行前に件数・先頭・末尾を確認してください。"
    AppendMultiPasteUndoNotice ws
End Sub

Private Sub AppendMultiPasteUndoNotice(ByVal ws As Worksheet)
    'エラー・重複警告を上書きせず、複数セル貼付で失われる標準Undoの制約だけを毎回追記する。
    '別の案内で上書きされた後の貼付でも、制約を利用者が見落とさないようにする。
    Const NOTICE_TEXT As String = "標準Ctrl+Z不可。範囲消去または元資料から再貼付してください。"
    Dim currentText As String, updatedText As String
    If ws Is Nothing Then Exit Sub
    On Error GoTo EH
    currentText = CellText(ws.Range(CELL_STATUS).Value)
    If InStr(1, currentText, "標準Ctrl+Z不可", vbBinaryCompare) > 0 Then
        updatedText = currentText
    ElseIf Len(currentText) > 0 Then
        updatedText = currentText & "　" & NOTICE_TEXT
    Else
        updatedText = NOTICE_TEXT
    End If
    ws.Range(CELL_STATUS).Value = updatedText
    If InStr(1, CellText(ws.Range(CELL_STATUS).Value), _
             "標準Ctrl+Z不可", vbBinaryCompare) = 0 Then _
        Err.Raise vbObjectError + 3324, "AppendMultiPasteUndoNotice", _
                  "複数セル貼付後のUndo制約を表示できませんでした。"
    Exit Sub
EH:
    '注意追記の失敗で利用者が貼り付けた値や既存エラー表示を壊さない。
    Err.Clear
End Sub

Private Sub NormalizeTransactionTimeRangeBatch(ByVal targetRange As Range, _
                                                ByRef invalidCount As Long, _
                                                ByRef firstInvalid As Range)
    '通常の値貼付はValue2配列で検査・正規化し、セル単位COM呼出しを避ける。
    '数式を含む範囲だけは、数式を値へ置換しないため安全な既存経路へ戻す。
    Dim area As Range, cell As Range
    Dim inputData As Variant, normalized As Variant
    Dim r As Long, c As Long, ok As Boolean
    For Each area In targetRange.Areas
        If area.Cells.CountLarge = 1 Or RangeContainsFormula(area) Then
            For Each cell In area.Cells
                If Not NormalizeTransactionTimeEntry(cell) Then
                    invalidCount = invalidCount + 1
                    If firstInvalid Is Nothing Then Set firstInvalid = cell
                End If
            Next cell
        Else
            inputData = area.Value2
            For r = 1 To area.Rows.Count
                For c = 1 To area.Columns.Count
                    ok = False
                    If Not IsError(inputData(r, c)) Then
                        If Not HasText(inputData(r, c)) Then
                            ok = True
                        Else
                            normalized = NormalizeTimeInput(inputData(r, c), ok)
                            If ok Then ok = IsDate(normalized)
                            If ok Then inputData(r, c) = Format$(CDate(normalized), "hhmm")
                        End If
                    End If
                    If Not ok Then
                        invalidCount = invalidCount + 1
                        If firstInvalid Is Nothing Then Set firstInvalid = area.Cells(r, c)
                    End If
                Next c
            Next r
            area.NumberFormatLocal = "@"
            area.Value2 = inputData
            area.HorizontalAlignment = xlRight
        End If
    Next area
End Sub

Private Sub NormalizeTransactionAmountRangeBatch(ByVal targetRange As Range, _
                                                  ByRef invalidCount As Long, _
                                                  ByRef firstInvalid As Range)
    Dim area As Range, cell As Range
    Dim inputData As Variant, normalized As Variant
    Dim r As Long, c As Long, absoluteCol As Long, ok As Boolean
    Dim transactionAmount As Boolean
    For Each area In targetRange.Areas
        If area.Cells.CountLarge = 1 Or RangeContainsFormula(area) Then
            For Each cell In area.Cells
                If Not NormalizeTransactionAmountEntry(cell) Then
                    invalidCount = invalidCount + 1
                    If firstInvalid Is Nothing Then Set firstInvalid = cell
                End If
            Next cell
        Else
            inputData = area.Value2
            For r = 1 To area.Rows.Count
                For c = 1 To area.Columns.Count
                    absoluteCol = area.Column + c - 1
                    transactionAmount = area.Row + r - 1 >= TX_FIRST_ROW And _
                                        area.Row + r - 1 <= TX_LAST_ROW And _
                                        (absoluteCol = COL_TX_WITHDRAW Or _
                                         absoluteCol = COL_TX_DEPOSIT)
                    ok = AmountValueIsValid(inputData(r, c), False, transactionAmount)
                    If ok And HasText(inputData(r, c)) Then
                        normalized = TryParseAmount(inputData(r, c), ok)
                        If ok Then inputData(r, c) = normalized
                    End If
                    If Not ok Then
                        invalidCount = invalidCount + 1
                        If firstInvalid Is Nothing Then Set firstInvalid = area.Cells(r, c)
                    End If
                Next c
            Next r
            area.NumberFormatLocal = "#,##0.########"
            area.Value2 = inputData
            area.HorizontalAlignment = xlRight
        End If
    Next area
End Sub

Private Function RangeContainsFormula(ByVal targetRange As Range) As Boolean
    Dim formulaState As Variant
    If targetRange Is Nothing Then Exit Function
    formulaState = targetRange.HasFormula
    If IsNull(formulaState) Then
        RangeContainsFormula = True
    Else
        RangeContainsFormula = CBool(formulaState)
    End If
End Function

Private Sub TrackPendingErrorsAfterChange(ByVal ws As Worksheet, _
                                          ByVal Target As Range, _
                                          ByVal dateCascade As Boolean, _
                                          ByVal buildIfMissing As Boolean)
    If ws Is Nothing Or Target Is Nothing Then Exit Sub
    If Not mPendingInputErrorCacheReady Then
        If Not buildIfMissing Then Exit Sub
        RebuildPendingInputErrorCache ws
    Else
        RefreshPendingInputErrorCacheForTarget ws, Target, dateCascade
    End If
    mPendingMultiPasteValidation = PendingInputErrorCacheHasErrors()
End Sub

Private Sub RefreshPendingInputErrorCacheForTarget(ByVal ws As Worksheet, _
                                                   ByVal Target As Range, _
                                                   ByVal dateCascade As Boolean)
    Dim memoCol As Long, lastInputRow As Long, c As Long
    If Not Intersect(Target, Union(ws.Range(CELL_OPEN_DATE), _
                                   ws.Range(CELL_CLOSE_DATE))) Is Nothing Then
        RefreshPendingAccountDateErrors ws
        '口座期間の変更で旧版プレースホルダーが消える場合も、残高キャッシュを同期する。
        memoCol = BalanceMemoCol(ws)
        For c = BAL_FIRST_COL To memoCol - 1
            RefreshPendingBalanceAmountError ws, c
        Next c
    End If

    memoCol = BalanceMemoCol(ws)
    If memoCol > BAL_FIRST_COL Then
        If Target.Row = BAL_VALUE_ROW Then
            For c = Application.Max(Target.Column, BAL_FIRST_COL) To _
                    Application.Min(Target.Column + Target.Columns.Count - 1, memoCol - 1)
                RefreshPendingBalanceAmountError ws, c
            Next c
        End If
    End If

    If Target.Row < TX_FIRST_ROW Or Target.Row > TX_LAST_ROW Then Exit Sub
    If dateCascade Then
        lastInputRow = LastPopulatedTransactionInputRow(ws)
        If lastInputRow < Target.Row Then lastInputRow = Target.Row
        RefreshPendingDateErrorRange ws, Target.Row, lastInputRow
    Else
        RefreshPendingTransactionRowErrors ws, Target.Row
    End If
End Sub

Private Function TryRefreshPendingInputErrorCacheForMultiTarget( _
        ByVal ws As Worksheet, ByVal Target As Range) As Boolean
    Dim accountDateCells As Range, balanceCells As Range
    Dim transactionCells As Range, explicitDateCells As Range
    Dim area As Range
    Dim changedRows As Object, changedBalanceColumns As Object
    Dim key As Variant
    Dim rowNo As Long, columnNo As Long, memoCol As Long
    Dim minDateRow As Long, maxDateRow As Long, lastInputRow As Long

    If ws Is Nothing Or Target Is Nothing Then Exit Function
    On Error GoTo Failed
    Set changedRows = CreateObject("Scripting.Dictionary")
    changedRows.CompareMode = vbBinaryCompare
    Set changedBalanceColumns = CreateObject("Scripting.Dictionary")
    changedBalanceColumns.CompareMode = vbBinaryCompare

    Set accountDateCells = Intersect(Target, Union(ws.Range(CELL_OPEN_DATE), _
                                                    ws.Range(CELL_CLOSE_DATE)))
    memoCol = BalanceMemoCol(ws)
    If memoCol > BAL_FIRST_COL Then
        Set balanceCells = Intersect(Target, ws.Range( _
            ws.Cells(BAL_VALUE_ROW, BAL_FIRST_COL), _
            ws.Cells(BAL_VALUE_ROW, memoCol - 1)))
        If Not balanceCells Is Nothing Then
            For Each area In balanceCells.Areas
                For columnNo = area.Column To area.Column + area.Columns.Count - 1
                    changedBalanceColumns(CStr(columnNo)) = True
                Next columnNo
            Next area
        End If
        '口座期間の変更はApplyBalanceAvailabilityで複数残高セルを更新し得る。
        If Not accountDateCells Is Nothing Then
            For columnNo = BAL_FIRST_COL To memoCol - 1
                changedBalanceColumns(CStr(columnNo)) = True
            Next columnNo
        End If
    End If

    Set transactionCells = Intersect(Target, ws.Range( _
        ws.Cells(TX_FIRST_ROW, COL_TX_YEAR), _
        ws.Cells(TX_LAST_ROW, COL_TX_OTHER)))
    If Not transactionCells Is Nothing Then
        For Each area In transactionCells.Areas
            For rowNo = area.Row To area.Row + area.Rows.Count - 1
                changedRows(CStr(rowNo)) = True
            Next rowNo
        Next area
    End If
    If changedRows.Count > PENDING_ERROR_INCREMENTAL_PASTE_MAX_CELLS Then GoTo Failed

    If Not accountDateCells Is Nothing Then RefreshPendingAccountDateErrors ws
    For Each key In changedBalanceColumns.Keys
        RefreshPendingBalanceAmountError ws, CLng(key)
    Next key
    For Each key In changedRows.Keys
        RefreshPendingTransactionRowErrors ws, CLng(key)
    Next key

    '年・月・日の変更は、後続行で省略された年月日の解釈だけを再評価する。
    Set explicitDateCells = Intersect(Target, ws.Range( _
        ws.Cells(TX_FIRST_ROW, COL_TX_YEAR), _
        ws.Cells(TX_LAST_ROW, COL_TX_DAY)))
    If Not explicitDateCells Is Nothing Then
        minDateRow = TX_LAST_ROW
        maxDateRow = TX_FIRST_ROW
        For Each area In explicitDateCells.Areas
            If area.Row < minDateRow Then minDateRow = area.Row
            If area.Row + area.Rows.Count - 1 > maxDateRow Then _
                maxDateRow = area.Row + area.Rows.Count - 1
        Next area
        lastInputRow = LastPopulatedTransactionInputRow(ws)
        '末尾行を消した場合も、消去前のエラー辞書キーを確実に除去する。
        If lastInputRow < maxDateRow Then lastInputRow = maxDateRow
        RefreshPendingDateErrorRange ws, minDateRow, lastInputRow
    End If

    mInputErrorCacheRefreshRequired = False
    TryRefreshPendingInputErrorCacheForMultiTarget = True
    Exit Function
Failed:
    '差分更新に失敗した辞書は利用せず、呼出元で一括再構築する。
    InvalidatePendingInputErrorCache True
End Function

Private Sub RebuildPendingInputErrorCache(ByVal ws As Worksheet)
    '貼付直後または初回エラー時だけ全体を配列取得する。SelectionChangeからは呼び直さない。
    Dim lastInputRow As Long, itemCount As Long, r As Long, sheetRow As Long
    Dim inputRange As Range, inputData As Variant, formulaCells As Object
    Dim memoCol As Long, c As Long, balanceRange As Range, balanceData As Variant
    Dim balanceFormulaCells As Object
    If ws Is Nothing Then Exit Sub
    mPendingInputErrorCacheReady = False
    Set mPendingInputErrors = CreateObject("Scripting.Dictionary")
    mPendingInputErrors.CompareMode = vbBinaryCompare
    mPendingDateErrorCount = 0
    mPendingTimeErrorCount = 0
    mPendingAmountErrorCount = 0
    mPendingFirstErrorAddress = vbNullString
    mPendingFirstErrorPriority = 0
    mPendingFirstErrorDirty = False

    RefreshPendingAccountDateErrors ws
    lastInputRow = LastPopulatedTransactionInputRow(ws)
    If lastInputRow >= TX_FIRST_ROW Then
        EnsureDateComplementCache ws, lastInputRow
        Set inputRange = ws.Range(ws.Cells(TX_FIRST_ROW, COL_TX_TIME), _
                                  ws.Cells(lastInputRow, COL_TX_BALANCE))
        inputData = inputRange.Value2
        Set formulaCells = FormulaCellAddressMap(inputRange)
        itemCount = lastInputRow - TX_FIRST_ROW + 1
        For r = 1 To itemCount
            sheetRow = TX_FIRST_ROW + r - 1
            AddPendingTransactionErrorsFromArray ws, sheetRow, r, inputData, formulaCells
        Next r
    End If

    memoCol = BalanceMemoCol(ws)
    If memoCol > BAL_FIRST_COL Then
        Set balanceRange = ws.Range(ws.Cells(BAL_VALUE_ROW, BAL_FIRST_COL), _
                                    ws.Cells(BAL_VALUE_ROW, memoCol - 1))
        balanceData = balanceRange.Value2
        Set balanceFormulaCells = FormulaCellAddressMap(balanceRange)
        If balanceRange.Cells.CountLarge = 1 Then
            AddPendingBalanceErrorFromValue ws, BAL_FIRST_COL, balanceData, _
                balanceFormulaCells.Exists(FormulaCellKey(BAL_VALUE_ROW, BAL_FIRST_COL))
        Else
            For c = 1 To balanceRange.Columns.Count
                AddPendingBalanceErrorFromValue ws, BAL_FIRST_COL + c - 1, balanceData(1, c), _
                    balanceFormulaCells.Exists(FormulaCellKey(BAL_VALUE_ROW, BAL_FIRST_COL + c - 1))
            Next c
        End If
    End If
    mPendingInputErrorCacheReady = True
    mInputErrorCacheRefreshRequired = False
    mPendingMultiPasteValidation = PendingInputErrorCacheHasErrors()
End Sub

Private Sub AddPendingTransactionErrorsFromArray(ByVal ws As Worksheet, _
                                                  ByVal sheetRow As Long, _
                                                  ByVal arrayRow As Long, _
                                                  ByVal inputData As Variant, _
                                                  ByVal formulaCells As Object)
    Dim rowIndex As Long, transactionTimeValue As Variant, withdrawValue As Variant
    Dim depositValue As Variant, balanceValue As Variant
    Dim basePriority As Double
    rowIndex = sheetRow - TX_FIRST_ROW + 1
    basePriority = 1000# + CDbl(rowIndex) * 10#
    If mDateCacheAnyInvalid(rowIndex) Or mDateCacheAnyIncomplete(rowIndex) Then _
        AddPendingInputError "TD:" & CStr(sheetRow), "D", _
            ws.Cells(sheetRow, COL_TX_DAY).Address(False, False), basePriority

    transactionTimeValue = inputData(arrayRow, COL_TX_TIME - COL_TX_TIME + 1)
    withdrawValue = inputData(arrayRow, COL_TX_WITHDRAW - COL_TX_TIME + 1)
    depositValue = inputData(arrayRow, COL_TX_DEPOSIT - COL_TX_TIME + 1)
    balanceValue = inputData(arrayRow, COL_TX_BALANCE - COL_TX_TIME + 1)
    If Not TimeValueIsValid(transactionTimeValue, _
            formulaCells.Exists(FormulaCellKey(sheetRow, COL_TX_TIME))) Then _
        AddPendingInputError "TT:" & CStr(sheetRow), "T", _
            ws.Cells(sheetRow, COL_TX_TIME).Address(False, False), basePriority + 1#
    If Not AmountValueIsValid(withdrawValue, _
            formulaCells.Exists(FormulaCellKey(sheetRow, COL_TX_WITHDRAW)), True) Then _
        AddPendingInputError "TAW:" & CStr(sheetRow), "A", _
            ws.Cells(sheetRow, COL_TX_WITHDRAW).Address(False, False), basePriority + 2#
    If Not AmountValueIsValid(depositValue, _
            formulaCells.Exists(FormulaCellKey(sheetRow, COL_TX_DEPOSIT)), True) Then _
        AddPendingInputError "TAD:" & CStr(sheetRow), "A", _
            ws.Cells(sheetRow, COL_TX_DEPOSIT).Address(False, False), basePriority + 3#
    If HasText(withdrawValue) And HasText(depositValue) Then _
        AddPendingInputError "TAP:" & CStr(sheetRow), "A", _
            ws.Cells(sheetRow, COL_TX_WITHDRAW).Address(False, False), basePriority + 4#
    If Not AmountValueIsValid(balanceValue, _
            formulaCells.Exists(FormulaCellKey(sheetRow, COL_TX_BALANCE)), False) Then _
        AddPendingInputError "TAB:" & CStr(sheetRow), "A", _
            ws.Cells(sheetRow, COL_TX_BALANCE).Address(False, False), basePriority + 5#
End Sub

Private Sub RefreshPendingTransactionRowErrors(ByVal ws As Worksheet, ByVal sheetRow As Long)
    Dim rowIndex As Long, basePriority As Double
    If sheetRow < TX_FIRST_ROW Or sheetRow > TX_LAST_ROW Then Exit Sub
    RemovePendingInputError "TD:" & CStr(sheetRow)
    RemovePendingInputError "TT:" & CStr(sheetRow)
    RemovePendingInputError "TAW:" & CStr(sheetRow)
    RemovePendingInputError "TAD:" & CStr(sheetRow)
    RemovePendingInputError "TAP:" & CStr(sheetRow)
    RemovePendingInputError "TAB:" & CStr(sheetRow)
    EnsureDateComplementCache ws, sheetRow
    rowIndex = sheetRow - TX_FIRST_ROW + 1
    basePriority = 1000# + CDbl(rowIndex) * 10#
    If mDateCacheAnyInvalid(rowIndex) Or mDateCacheAnyIncomplete(rowIndex) Then _
        AddPendingInputError "TD:" & CStr(sheetRow), "D", _
            ws.Cells(sheetRow, COL_TX_DAY).Address(False, False), basePriority
    If Not TimeEntryIsValidWithoutChange(ws.Cells(sheetRow, COL_TX_TIME)) Then _
        AddPendingInputError "TT:" & CStr(sheetRow), "T", _
            ws.Cells(sheetRow, COL_TX_TIME).Address(False, False), basePriority + 1#
    If Not AmountEntryIsValidWithoutChange(ws.Cells(sheetRow, COL_TX_WITHDRAW), False) Then _
        AddPendingInputError "TAW:" & CStr(sheetRow), "A", _
            ws.Cells(sheetRow, COL_TX_WITHDRAW).Address(False, False), basePriority + 2#
    If Not AmountEntryIsValidWithoutChange(ws.Cells(sheetRow, COL_TX_DEPOSIT), False) Then _
        AddPendingInputError "TAD:" & CStr(sheetRow), "A", _
            ws.Cells(sheetRow, COL_TX_DEPOSIT).Address(False, False), basePriority + 3#
    If HasText(ws.Cells(sheetRow, COL_TX_WITHDRAW).Value) And _
       HasText(ws.Cells(sheetRow, COL_TX_DEPOSIT).Value) Then _
        AddPendingInputError "TAP:" & CStr(sheetRow), "A", _
            ws.Cells(sheetRow, COL_TX_WITHDRAW).Address(False, False), basePriority + 4#
    If Not AmountEntryIsValidWithoutChange(ws.Cells(sheetRow, COL_TX_BALANCE)) Then _
        AddPendingInputError "TAB:" & CStr(sheetRow), "A", _
            ws.Cells(sheetRow, COL_TX_BALANCE).Address(False, False), basePriority + 5#
End Sub

Private Sub RefreshPendingDateErrorRange(ByVal ws As Worksheet, _
                                         ByVal firstRow As Long, _
                                         ByVal lastRow As Long)
    Dim r As Long, rowIndex As Long, basePriority As Double
    If firstRow < TX_FIRST_ROW Then firstRow = TX_FIRST_ROW
    If lastRow > TX_LAST_ROW Then lastRow = TX_LAST_ROW
    If lastRow < firstRow Then Exit Sub
    EnsureDateComplementCache ws, lastRow
    For r = firstRow To lastRow
        RemovePendingInputError "TD:" & CStr(r)
        rowIndex = r - TX_FIRST_ROW + 1
        If mDateCacheAnyInvalid(rowIndex) Or mDateCacheAnyIncomplete(rowIndex) Then
            basePriority = 1000# + CDbl(rowIndex) * 10#
            AddPendingInputError "TD:" & CStr(r), "D", _
                ws.Cells(r, COL_TX_DAY).Address(False, False), basePriority
        End If
    Next r
End Sub

Private Sub RefreshPendingBalanceAmountError(ByVal ws As Worksheet, ByVal columnNo As Long)
    Dim keyText As String
    keyText = "BA:" & CStr(columnNo)
    RemovePendingInputError keyText
    If Not AmountEntryIsValidWithoutChange(ws.Cells(BAL_VALUE_ROW, columnNo)) Then _
        AddPendingInputError keyText, "A", _
            ws.Cells(BAL_VALUE_ROW, columnNo).Address(False, False), 10000000# + CDbl(columnNo)
End Sub

Private Sub AddPendingBalanceErrorFromValue(ByVal ws As Worksheet, _
                                            ByVal columnNo As Long, _
                                            ByVal cellValue As Variant, _
                                            ByVal hasFormula As Boolean)
    If Not AmountValueIsValid(cellValue, hasFormula, False) Then _
        AddPendingInputError "BA:" & CStr(columnNo), "A", _
            ws.Cells(BAL_VALUE_ROW, columnNo).Address(False, False), 10000000# + CDbl(columnNo)
End Sub

Private Sub RefreshPendingAccountDateErrors(ByVal ws As Worksheet)
    Dim openCell As Range, closeCell As Range
    Dim openValue As Variant, closeValue As Variant
    Dim openOK As Boolean, closeOK As Boolean
    Set openCell = ws.Range(CELL_OPEN_DATE)
    Set closeCell = ws.Range(CELL_CLOSE_DATE)
    RemovePendingInputError "AO"
    RemovePendingInputError "AC"
    RemovePendingInputError "AORD"
    If Not openCell.HasFormula And Not IsError(openCell.Value) Then _
        openValue = ResolveAccountDateInput(openCell.Value, openOK)
    If Not closeCell.HasFormula And Not IsError(closeCell.Value) Then _
        closeValue = ResolveAccountDateInput(closeCell.Value, closeOK)
    If Not openOK Then _
        AddPendingInputError "AO", "D", openCell.Address(False, False), 1#
    If Not closeOK Then _
        AddPendingInputError "AC", "D", closeCell.Address(False, False), 2#
    If openOK And closeOK And IsDate(openValue) And IsDate(closeValue) Then
        If CDate(openValue) > CDate(closeValue) Then _
            AddPendingInputError "AORD", "D", closeCell.Address(False, False), 3#
    End If
End Sub

Private Function FormulaCellAddressMap(ByVal targetRange As Range) As Object
    Dim result As Object, formulaCells As Range, cell As Range
    Dim specialCellsError As Long, specialCellsDescription As String
    Set result = CreateObject("Scripting.Dictionary")
    result.CompareMode = vbBinaryCompare
    On Error Resume Next
    Err.Clear
    Set formulaCells = targetRange.SpecialCells(xlCellTypeFormulas)
    specialCellsError = Err.Number
    specialCellsDescription = Err.Description
    Err.Clear
    On Error GoTo EH
    If specialCellsError <> 0 And specialCellsError <> 1004 Then _
        Err.Raise specialCellsError, "FormulaCellAddressMap", specialCellsDescription
    If Not formulaCells Is Nothing Then
        For Each cell In formulaCells.Cells
            result(FormulaCellKey(cell.Row, cell.Column)) = True
        Next cell
    End If
    Set FormulaCellAddressMap = result
    Exit Function
EH:
    Err.Raise Err.Number, "FormulaCellAddressMap", Err.Description
End Function

Private Function FormulaCellKey(ByVal rowNo As Long, ByVal columnNo As Long) As String
    FormulaCellKey = CStr(rowNo) & ":" & CStr(columnNo)
End Function

Private Function TimeValueIsValid(ByVal cellValue As Variant, _
                                  ByVal hasFormula As Boolean) As Boolean
    Dim normalized As Variant, ok As Boolean
    If hasFormula Or IsError(cellValue) Then Exit Function
    If Not HasText(cellValue) Then
        TimeValueIsValid = True
        Exit Function
    End If
    normalized = NormalizeTimeInput(cellValue, ok)
    TimeValueIsValid = ok And IsDate(normalized)
End Function

Private Function AmountValueIsValid(ByVal cellValue As Variant, _
                                    ByVal hasFormula As Boolean, _
                                    ByVal transactionAmount As Boolean) As Boolean
    Dim normalized As Variant, ok As Boolean
    If hasFormula Or IsError(cellValue) Then Exit Function
    If Not HasText(cellValue) Then
        AmountValueIsValid = True
        Exit Function
    End If
    normalized = TryParseAmount(cellValue, ok)
    If Not ok Or Not HasText(normalized) Then Exit Function
    If transactionAmount Then
        If CDbl(normalized) < 0 Then Exit Function
    End If
    AmountValueIsValid = True
End Function

Private Sub AddPendingInputError(ByVal keyText As String, _
                                 ByVal errorKind As String, _
                                 ByVal cellAddress As String, _
                                 ByVal sortPriority As Double)
    If mPendingInputErrors Is Nothing Then Exit Sub
    If mPendingInputErrors.Exists(keyText) Then RemovePendingInputError keyText
    mPendingInputErrors.Add keyText, Array(errorKind, cellAddress, sortPriority)
    Select Case errorKind
        Case "D": mPendingDateErrorCount = mPendingDateErrorCount + 1
        Case "T": mPendingTimeErrorCount = mPendingTimeErrorCount + 1
        Case "A": mPendingAmountErrorCount = mPendingAmountErrorCount + 1
    End Select
    If Len(mPendingFirstErrorAddress) = 0 Or sortPriority < mPendingFirstErrorPriority Then
        mPendingFirstErrorAddress = cellAddress
        mPendingFirstErrorPriority = sortPriority
        mPendingFirstErrorDirty = False
    End If
End Sub

Private Sub RemovePendingInputError(ByVal keyText As String)
    Dim item As Variant
    If mPendingInputErrors Is Nothing Then Exit Sub
    If Not mPendingInputErrors.Exists(keyText) Then Exit Sub
    item = mPendingInputErrors(keyText)
    Select Case CStr(item(0))
        Case "D": mPendingDateErrorCount = mPendingDateErrorCount - 1
        Case "T": mPendingTimeErrorCount = mPendingTimeErrorCount - 1
        Case "A": mPendingAmountErrorCount = mPendingAmountErrorCount - 1
    End Select
    If CDbl(item(2)) = mPendingFirstErrorPriority Then mPendingFirstErrorDirty = True
    mPendingInputErrors.Remove keyText
End Sub

Private Function PendingInputErrorCacheHasErrors() As Boolean
    If mPendingInputErrors Is Nothing Then Exit Function
    PendingInputErrorCacheHasErrors = (mPendingInputErrors.Count > 0)
End Function

Private Sub RefreshPendingFirstError()
    Dim keyText As Variant, item As Variant, priority As Double
    If Not mPendingFirstErrorDirty Then Exit Sub
    mPendingFirstErrorAddress = vbNullString
    mPendingFirstErrorPriority = 0
    For Each keyText In mPendingInputErrors.Keys
        item = mPendingInputErrors(keyText)
        priority = CDbl(item(2))
        If Len(mPendingFirstErrorAddress) = 0 Or priority < mPendingFirstErrorPriority Then
            mPendingFirstErrorAddress = CStr(item(1))
            mPendingFirstErrorPriority = priority
        End If
    Next keyText
    mPendingFirstErrorDirty = False
End Sub

Private Function NormalizeAccountDatePair(ByVal ws As Worksheet, _
                                          ByRef firstInvalid As Range, _
                                          ByRef invalidCount As Long, _
                                          ByRef orderInvalid As Boolean) As Boolean
    '片方だけを直したときに、もう片方の不正値を見落として緑表示へ戻さない。
    Dim cell As Range
    invalidCount = 0
    orderInvalid = False
    Set firstInvalid = Nothing
    If ws Is Nothing Then Exit Function

    For Each cell In Union(ws.Range(CELL_OPEN_DATE), ws.Range(CELL_CLOSE_DATE)).Cells
        If Not NormalizeAccountDateEntry(cell) Then
            invalidCount = invalidCount + 1
            If firstInvalid Is Nothing Then Set firstInvalid = cell
        End If
    Next cell
    If invalidCount > 0 Then Exit Function

    If IsDate(ws.Range(CELL_OPEN_DATE).Value) And IsDate(ws.Range(CELL_CLOSE_DATE).Value) Then
        If CDate(ws.Range(CELL_OPEN_DATE).Value) > CDate(ws.Range(CELL_CLOSE_DATE).Value) Then
            invalidCount = 1
            orderInvalid = True
            Set firstInvalid = ws.Range(CELL_CLOSE_DATE)
            Exit Function
        End If
    End If
    NormalizeAccountDatePair = True
End Function

Private Function ShowPendingInputErrorIfAny(ByVal ws As Worksheet, _
                                            ByVal currentCell As Range) As Boolean
    'クリックや矢印移動だけで、直していない入力エラーの赤い案内を消さない。
    Dim editedCell As Range, firstInvalidDate As Range
    Dim invalidDateCount As Long
    Dim orderInvalid As Boolean
    If ws Is Nothing Then Exit Function
    If mPendingMultiPasteValidation Then
        If ShowAllPendingInputErrors(ws) Then
            ShowPendingInputErrorIfAny = True
            Exit Function
        End If
        mPendingMultiPasteValidation = False
    End If
    If mLastEditedRow < 1 Or mLastEditedCol < 1 Then Exit Function
    If mLastEditedRow > ws.Rows.Count Or mLastEditedCol > ws.Columns.Count Then Exit Function
    Set editedCell = ws.Cells(mLastEditedRow, mLastEditedCol)

    If editedCell.Row >= TX_FIRST_ROW And editedCell.Row <= TX_LAST_ROW And _
       (editedCell.Column < COL_TX_YEAR Or editedCell.Column > COL_TX_DAY) Then
        EnsureDateComplementCache ws, editedCell.Row
        If mDateCacheAnyInvalid(editedCell.Row - TX_FIRST_ROW + 1) Or _
           mDateCacheAnyIncomplete(editedCell.Row - TX_FIRST_ROW + 1) Then
            mPendingMultiPasteValidation = True
            SetInputStatus CStr(editedCell.Row) & _
                           "行目は取引内容に対する日付が未完成または不正です。年・月・日を確認してください。", True
            ShowPendingInputErrorIfAny = True
            Exit Function
        End If
    End If

    If editedCell.Address(False, False) = CELL_OPEN_DATE Or _
       editedCell.Address(False, False) = CELL_CLOSE_DATE Then
        If AccountDatePairHasProblem(ws, firstInvalidDate, invalidDateCount, orderInvalid) Then
            mPendingMultiPasteValidation = True
            If orderInvalid Then
                SetInputStatus "解約日は開設日以降にしてください。", True
            Else
                SetInputStatus firstInvalidDate.Address(False, False) & _
                               " の日付を解釈できません。修正してください。", True
            End If
            ShowPendingInputErrorIfAny = True
        End If
        Exit Function
    End If

    If editedCell.Row >= TX_FIRST_ROW And editedCell.Row <= TX_LAST_ROW Then
        If editedCell.Column >= COL_TX_YEAR And editedCell.Column <= COL_TX_DAY Then
            If TransactionDateRowHasUnsupportedValue(ws, editedCell.Row, firstInvalidDate) Then
                mPendingMultiPasteValidation = True
                SetInputStatus firstInvalidDate.Address(False, False) & _
                               " の日付欄には数式・Excelエラーを入力できません。", True
                ShowPendingInputErrorIfAny = True
                Exit Function
            End If
            EnsureDateComplementCache ws, editedCell.Row
            If mDateCacheAnyInvalid(editedCell.Row - TX_FIRST_ROW + 1) Then
                '年・月の変更直後は、未入力の後続列へ継承された月日との暫定不整合があり得る。
                '現在セル自体の構文が正しく、同じ行の日付欄内へ移動する間は修正を続けられる。
                If Not DateInputCellHasSyntaxProblem(editedCell) And _
                   editedCell.Column < COL_TX_DAY And Not currentCell Is Nothing Then
                    If currentCell.Row = editedCell.Row And _
                       currentCell.Column >= COL_TX_YEAR And _
                       currentCell.Column <= COL_TX_DAY Then Exit Function
                End If
                mPendingMultiPasteValidation = True
                SetInputStatus CStr(editedCell.Row) & "行目の日付を完成・修正してください。", True
                ShowPendingInputErrorIfAny = True
            ElseIf mDateCacheAnyIncomplete(editedCell.Row - TX_FIRST_ROW + 1) Then
                '年→月→日の同じ行内は入力途中として許可し、日付欄の外へ出る時だけ止める。
                If Not currentCell Is Nothing Then
                    If currentCell.Row = editedCell.Row And _
                       currentCell.Column >= COL_TX_YEAR And _
                       currentCell.Column <= COL_TX_DAY Then Exit Function
                End If
                mPendingMultiPasteValidation = True
                SetInputStatus CStr(editedCell.Row) & "行目の日付を完成してから他の項目へ進んでください。", True
                ShowPendingInputErrorIfAny = True
            End If
            Exit Function
        End If
        If editedCell.Column = COL_TX_TIME Then
            If Not TimeEntryIsValidWithoutChange(editedCell) Then
                mPendingMultiPasteValidation = True
                SetInputStatus CStr(editedCell.Row) & "行目の時刻を解釈できません。修正してください。", True
                ShowPendingInputErrorIfAny = True
            End If
            Exit Function
        End If
    End If

    If IsAmountInputCell(editedCell) Then
        If Not AmountEntryIsValidWithoutChange(editedCell) Then
            mPendingMultiPasteValidation = True
            SetInputStatus editedCell.Address(False, False) & _
                           " の金額を解釈できません。修正してください。", True
            ShowPendingInputErrorIfAny = True
        End If
    End If
End Function

Private Function TransactionDateRowHasUnsupportedValue(ByVal ws As Worksheet, _
                                                       ByVal rowNo As Long, _
                                                       ByRef firstInvalid As Range) As Boolean
    Dim cell As Range
    Set firstInvalid = Nothing
    If ws Is Nothing Then Exit Function
    If rowNo < TX_FIRST_ROW Or rowNo > TX_LAST_ROW Then Exit Function
    For Each cell In ws.Range(ws.Cells(rowNo, COL_TX_YEAR), ws.Cells(rowNo, COL_TX_DAY)).Cells
        If cell.HasFormula Or IsError(cell.Value) Then
            Set firstInvalid = cell
            TransactionDateRowHasUnsupportedValue = True
            Exit Function
        End If
    Next cell
End Function

Private Function AccountDatePairHasProblem(ByVal ws As Worksheet, _
                                           ByRef firstInvalid As Range, _
                                           ByRef invalidCount As Long, _
                                           ByRef orderInvalid As Boolean) As Boolean
    Dim cell As Range
    Dim ok As Boolean
    Dim resolved As Variant
    Dim openDate As Variant, closeDate As Variant
    invalidCount = 0
    orderInvalid = False
    Set firstInvalid = Nothing
    If ws Is Nothing Then Exit Function

    For Each cell In Union(ws.Range(CELL_OPEN_DATE), ws.Range(CELL_CLOSE_DATE)).Cells
        ok = False
        If Not cell.HasFormula And Not IsError(cell.Value) Then
            resolved = ResolveAccountDateInput(cell.Value, ok)
        End If
        If Not ok Then
            invalidCount = invalidCount + 1
            If firstInvalid Is Nothing Then Set firstInvalid = cell
        ElseIf cell.Address(False, False) = CELL_OPEN_DATE Then
            openDate = resolved
        Else
            closeDate = resolved
        End If
    Next cell
    If invalidCount > 0 Then
        AccountDatePairHasProblem = True
        Exit Function
    End If
    If IsDate(openDate) And IsDate(closeDate) Then
        If CDate(openDate) > CDate(closeDate) Then
            invalidCount = 1
            orderInvalid = True
            Set firstInvalid = ws.Range(CELL_CLOSE_DATE)
            AccountDatePairHasProblem = True
        End If
    End If
End Function

Private Function IsAmountInputCell(ByVal targetCell As Range) As Boolean
    Dim memoCol As Long
    If targetCell Is Nothing Then Exit Function
    If targetCell.Row >= TX_FIRST_ROW And targetCell.Row <= TX_LAST_ROW Then
        IsAmountInputCell = (targetCell.Column = COL_TX_WITHDRAW Or _
                             targetCell.Column = COL_TX_DEPOSIT Or _
                             targetCell.Column = COL_TX_BALANCE)
        Exit Function
    End If
    If targetCell.Row <> BAL_VALUE_ROW Then Exit Function
    memoCol = BalanceMemoCol(targetCell.Worksheet)
    IsAmountInputCell = (targetCell.Column >= BAL_FIRST_COL And targetCell.Column < memoCol)
End Function

Private Function AmountEntryIsValidWithoutChange(ByVal targetCell As Range, _
                                                  Optional ByVal includePairCheck As Boolean = True) As Boolean
    Dim normalized As Variant
    Dim ok As Boolean
    If targetCell Is Nothing Then Exit Function
    If targetCell.HasFormula Then Exit Function
    If IsError(targetCell.Value) Then Exit Function
    If Not HasText(targetCell.Value) Then
        AmountEntryIsValidWithoutChange = True
        Exit Function
    End If
    normalized = TryParseAmount(targetCell.Value, ok)
    If Not ok Or Not HasText(normalized) Then Exit Function
    If targetCell.Row >= TX_FIRST_ROW And targetCell.Row <= TX_LAST_ROW And _
       (targetCell.Column = COL_TX_WITHDRAW Or targetCell.Column = COL_TX_DEPOSIT) Then
        If CDbl(normalized) < 0 Then Exit Function
        If includePairCheck Then
            If HasText(targetCell.Worksheet.Cells(targetCell.Row, COL_TX_WITHDRAW).Value) And _
               HasText(targetCell.Worksheet.Cells(targetCell.Row, COL_TX_DEPOSIT).Value) Then Exit Function
        End If
    End If
    AmountEntryIsValidWithoutChange = True
End Function

Private Function TimeEntryIsValidWithoutChange(ByVal targetCell As Range) As Boolean
    Dim normalized As Variant
    Dim ok As Boolean
    If targetCell Is Nothing Then Exit Function
    If targetCell.HasFormula Then Exit Function
    If IsError(targetCell.Value) Then Exit Function
    normalized = NormalizeTimeInput(targetCell.Value, ok)
    If Not ok Then Exit Function
    If Not HasText(targetCell.Value) Then
        TimeEntryIsValidWithoutChange = True
    ElseIf IsDate(normalized) Then
        TimeEntryIsValidWithoutChange = True
    End If
End Function

Private Function CurrentInputCellAllowsNavigation(ByVal targetCell As Range, _
                                                  ByVal destinationCell As Range) As Boolean
    Dim ws As Worksheet, firstInvalid As Range
    Dim invalidCount As Long, orderInvalid As Boolean, rowIndex As Long
    Dim currentDateOK As Boolean, resolvedAccountDate As Variant
    CurrentInputCellAllowsNavigation = True
    If targetCell Is Nothing Then Exit Function
    If targetCell.Worksheet.Name <> SH_INPUT Then Exit Function
    Set ws = targetCell.Worksheet
    If targetCell.Address(False, False) = CELL_OPEN_DATE Or _
       targetCell.Address(False, False) = CELL_CLOSE_DATE Then
        '現在セル自体が不正なら移動させない。他方だけが不正、または順序だけが逆転している場合は、
        '開設日・解約日の間だけ移動を許可し、通常のTab導線で修正先へ到達できるようにする。
        If Not targetCell.HasFormula And Not IsError(targetCell.Value) Then _
            resolvedAccountDate = ResolveAccountDateInput(targetCell.Value, currentDateOK)
        If Not currentDateOK Then
            CurrentInputCellAllowsNavigation = False
            SetInputStatus targetCell.Address(False, False) & " の日付を修正してから移動してください。", True
            Exit Function
        End If
        If AccountDatePairHasProblem(ws, firstInvalid, invalidCount, orderInvalid) Then
            If Not destinationCell Is Nothing Then
                If destinationCell.Address(False, False) = CELL_OPEN_DATE Or _
                   destinationCell.Address(False, False) = CELL_CLOSE_DATE Then Exit Function
            End If
            CurrentInputCellAllowsNavigation = False
            If orderInvalid Then
                SetInputStatus "解約日は開設日以降にしてください。", True
            Else
                SetInputStatus firstInvalid.Address(False, False) & " の日付を修正してから移動してください。", True
            End If
        End If
        Exit Function
    End If
    If targetCell.Row >= TX_FIRST_ROW And targetCell.Row <= TX_LAST_ROW Then
        If targetCell.Column >= COL_TX_YEAR And targetCell.Column <= COL_TX_DAY Then
            If TransactionDateRowHasUnsupportedValue(ws, targetCell.Row, firstInvalid) Then
                CurrentInputCellAllowsNavigation = False
                SetInputStatus firstInvalid.Address(False, False) & " の日付欄を修正してから移動してください。", True
                Exit Function
            End If
            EnsureDateComplementCache ws, targetCell.Row
            rowIndex = targetCell.Row - TX_FIRST_ROW + 1
            '同じ行の年・月・日内は入力を続けられる。Shift+Tabや通常Tabで日付群の外へ
            '出る時は、どの列からでも未完成・暫定不整合を止める。
            If mDateCacheAnyInvalid(rowIndex) Or mDateCacheAnyIncomplete(rowIndex) Then
                If Not DateInputCellHasSyntaxProblem(targetCell) And _
                   Not destinationCell Is Nothing Then
                    If destinationCell.Row = targetCell.Row And _
                       destinationCell.Column >= COL_TX_YEAR And _
                       destinationCell.Column <= COL_TX_DAY Then Exit Function
                End If
                CurrentInputCellAllowsNavigation = False
                SetInputStatus CStr(targetCell.Row) & "行目の日付を完成・修正してから移動してください。", True
            End If
            Exit Function
        End If
        If targetCell.Column = COL_TX_TIME Then
            If Not NormalizeTransactionTimeEntry(targetCell) Then
                CurrentInputCellAllowsNavigation = False
                SetInputStatus CStr(targetCell.Row) & "行目の時刻を修正してから移動してください。", True
            End If
            Exit Function
        End If
    End If
    If Not IsAmountInputCell(targetCell) Then Exit Function
    If Not NormalizeTransactionAmountEntry(targetCell) Then
        CurrentInputCellAllowsNavigation = False
        SetInputStatus targetCell.Address(False, False) & _
                       " の金額を修正してから移動してください。", True
        Exit Function
    End If
    If targetCell.Row >= TX_FIRST_ROW And targetCell.Row <= TX_LAST_ROW And _
       (targetCell.Column = COL_TX_WITHDRAW Or targetCell.Column = COL_TX_DEPOSIT) Then
        If TransactionAmountPairHasProblem(ws, targetCell.Row) Then
            '両方入力の修正中だけはF/G相互の移動を許可する。片方を消す前に
            '同じ行の金額欄以外へ出る経路は、従来どおり拒否する。
            CurrentInputCellAllowsNavigation = False
            If Not destinationCell Is Nothing Then
                If destinationCell.Row = targetCell.Row And _
                   ((targetCell.Column = COL_TX_WITHDRAW And _
                     destinationCell.Column = COL_TX_DEPOSIT) Or _
                    (targetCell.Column = COL_TX_DEPOSIT And _
                     destinationCell.Column = COL_TX_WITHDRAW)) Then _
                    CurrentInputCellAllowsNavigation = True
            End If
        End If
    End If
End Function

Private Function DateInputCellHasSyntaxProblem(ByVal targetCell As Range) As Boolean
    '現在セル単体の構文・範囲だけを検査する。継承した年月日との組合せ不整合は、
    '後続の日付セルを入力する余地があるためここでは不正扱いしない。
    Dim valueText As String
    Dim normalizedYear As Long, parsedMonth As Long, parsedDay As Long
    Dim ok As Boolean
    On Error GoTo InvalidValue
    If targetCell Is Nothing Then Exit Function
    If targetCell.HasFormula Or IsError(targetCell.Value) Then GoTo InvalidValue
    If Not HasText(targetCell.Value) Then Exit Function
    Select Case targetCell.Column
        Case COL_TX_YEAR
            normalizedYear = NormalizeYearInput(targetCell.Value, _
                                                GetCfgLong(ROW_CFG_YEAR_ADD, 2000), ok)
            If Not ok Or normalizedYear < 1900 Or normalizedYear > 9999 Then GoTo InvalidValue
        Case COL_TX_MONTH
            valueText = NormalizeNumberText(CellText(targetCell.Value))
            If Len(valueText) = 0 Or Len(valueText) > 2 Or _
               Not IsUnsignedIntegerText(valueText) Then GoTo InvalidValue
            parsedMonth = CLng(valueText)
            If parsedMonth < 1 Or parsedMonth > 12 Then GoTo InvalidValue
        Case COL_TX_DAY
            valueText = NormalizeNumberText(CellText(targetCell.Value))
            If Len(valueText) >= 3 Then
                If Not ParseMonthDay(targetCell.Value, parsedMonth, parsedDay) Then GoTo InvalidValue
            Else
                If Len(valueText) = 0 Or Len(valueText) > 2 Or _
                   Not IsUnsignedIntegerText(valueText) Then GoTo InvalidValue
                parsedDay = CLng(valueText)
                If parsedDay < 1 Or parsedDay > 31 Then GoTo InvalidValue
            End If
    End Select
    Exit Function
InvalidValue:
    DateInputCellHasSyntaxProblem = True
End Function

Private Function TransactionAmountPairHasProblem(ByVal ws As Worksheet, ByVal rowNo As Long) As Boolean
    If ws Is Nothing Then Exit Function
    If rowNo < TX_FIRST_ROW Or rowNo > TX_LAST_ROW Then Exit Function
    If HasText(ws.Cells(rowNo, COL_TX_WITHDRAW).Value) And _
       HasText(ws.Cells(rowNo, COL_TX_DEPOSIT).Value) Then
        SetInputStatus CStr(rowNo) & "行目は出金と入金のどちらか一方だけを入力してください。", True
        TransactionAmountPairHasProblem = True
    End If
End Function

Private Function ShowAllPendingInputErrors(ByVal ws As Worksheet) As Boolean
    '初回だけ配列で作ったキャッシュを表示する。SelectionChangeではセルを再走査しない。
    Dim problemSummary As String
    If ws Is Nothing Then Exit Function
    If Not mPendingInputErrorCacheReady Then RebuildPendingInputErrorCache ws
    If Not PendingInputErrorCacheHasErrors() Then Exit Function
    RefreshPendingFirstError
    If mPendingDateErrorCount > 0 Then _
        problemSummary = "日付 " & CStr(mPendingDateErrorCount) & "件"
    If mPendingTimeErrorCount > 0 Then
        If Len(problemSummary) > 0 Then problemSummary = problemSummary & "、"
        problemSummary = problemSummary & "時刻 " & CStr(mPendingTimeErrorCount) & "件"
    End If
    If mPendingAmountErrorCount > 0 Then
        If Len(problemSummary) > 0 Then problemSummary = problemSummary & "、"
        problemSummary = problemSummary & "金額 " & CStr(mPendingAmountErrorCount) & "件"
    End If
    SetInputStatus "未修正の入力エラーがあります（" & problemSummary & "）。先頭: " & _
                   mPendingFirstErrorAddress, True
    ShowAllPendingInputErrors = True
End Function

Private Function NormalizeTransactionAmountEntry(ByVal targetCell As Range) As Boolean
    Dim normalized As Variant
    Dim ok As Boolean
    Dim previousEvents As Boolean
    Dim eventsCaptured As Boolean
    Dim eventStateDetail As String
    Dim errorNumber As Long, errorSource As String, errorDescription As String
    NormalizeTransactionAmountEntry = False
    If targetCell Is Nothing Then Exit Function
    '数式（空文字を返す式を含む）とExcelエラー値を空欄として通さない。
    If targetCell.HasFormula Then Exit Function
    If IsError(targetCell.Value) Then Exit Function
    If Not HasText(targetCell.Value) Then
        NormalizeTransactionAmountEntry = True
        Exit Function
    End If
    '数式は表示値へ黙って置換せず、登録時の数式検査と同じく不正入力として扱う。
    normalized = TryParseAmount(targetCell.Value, ok)
    If Not ok Or Not HasText(normalized) Then Exit Function
    If targetCell.Row >= TX_FIRST_ROW And targetCell.Row <= TX_LAST_ROW And _
       (targetCell.Column = COL_TX_WITHDRAW Or targetCell.Column = COL_TX_DEPOSIT) Then
        If CDbl(normalized) < 0 Then Exit Function
    End If
    On Error GoTo EH
    If Not TryGetNavigationEnableEvents(previousEvents, eventStateDetail) Then
        StopAfterNavigationEventStateFailure _
            "NormalizeTransactionAmountEntry/開始状態取得", eventStateDetail
        Err.Raise vbObjectError + 3332, "NormalizeTransactionAmountEntry", _
                  "Excelイベントの開始状態を取得できませんでした。 " & eventStateDetail
    End If
    eventsCaptured = True
    If Not TrySetNavigationEnableEventsExact(False, eventStateDetail) Then _
        Err.Raise vbObjectError + 3333, "NormalizeTransactionAmountEntry", _
                  "金額正規化前にExcelイベントを停止できませんでした。 " & eventStateDetail
    targetCell.NumberFormatLocal = "#,##0.########"
    targetCell.Value = normalized
    targetCell.HorizontalAlignment = xlRight
    If Not TryRestoreNavigationEnableEvents( _
               previousEvents, "NormalizeTransactionAmountEntry", eventStateDetail) Then
        eventsCaptured = False
        Err.Raise vbObjectError + 3334, "NormalizeTransactionAmountEntry", eventStateDetail
    End If
    eventsCaptured = False
    NormalizeTransactionAmountEntry = True
    Exit Function
EH:
    errorNumber = Err.Number
    errorSource = Err.Source
    errorDescription = Err.Description
    If IsNavigationRecoveryHardBarrier(errorNumber, errorSource) Then
        Call TryStopNavigationEventsForBookWrites(eventStateDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    If eventsCaptured Then
        If Not TryRestoreNavigationEnableEvents( _
                   previousEvents, "NormalizeTransactionAmountEntry", eventStateDetail) Then _
            AppendNavigationSafetyDetail errorDescription, eventStateDetail
        eventsCaptured = False
    End If
    Err.Raise errorNumber, "NormalizeTransactionAmountEntry", errorDescription
End Function

Private Function NormalizeTransactionTimeEntry(ByVal targetCell As Range) As Boolean
    Dim normalized As Variant
    Dim ok As Boolean
    Dim previousEvents As Boolean
    Dim eventsCaptured As Boolean
    Dim eventStateDetail As String
    Dim errorNumber As Long, errorSource As String, errorDescription As String
    NormalizeTransactionTimeEntry = False
    If targetCell Is Nothing Then Exit Function
    If targetCell.HasFormula Then Exit Function
    If IsError(targetCell.Value) Then Exit Function
    If Not HasText(targetCell.Value) Then
        NormalizeTransactionTimeEntry = True
        Exit Function
    End If
    normalized = NormalizeTimeInput(targetCell.Value, ok)
    If Not ok Or Not IsDate(normalized) Then Exit Function
    On Error GoTo EH
    If Not TryGetNavigationEnableEvents(previousEvents, eventStateDetail) Then
        StopAfterNavigationEventStateFailure _
            "NormalizeTransactionTimeEntry/開始状態取得", eventStateDetail
        Err.Raise vbObjectError + 3335, "NormalizeTransactionTimeEntry", _
                  "Excelイベントの開始状態を取得できませんでした。 " & eventStateDetail
    End If
    eventsCaptured = True
    If Not TrySetNavigationEnableEventsExact(False, eventStateDetail) Then _
        Err.Raise vbObjectError + 3336, "NormalizeTransactionTimeEntry", _
                  "時刻正規化前にExcelイベントを停止できませんでした。 " & eventStateDetail
    targetCell.NumberFormatLocal = "@"
    targetCell.Value = Format$(CDate(normalized), "hhmm")
    targetCell.HorizontalAlignment = xlRight
    If Not TryRestoreNavigationEnableEvents( _
               previousEvents, "NormalizeTransactionTimeEntry", eventStateDetail) Then
        eventsCaptured = False
        Err.Raise vbObjectError + 3337, "NormalizeTransactionTimeEntry", eventStateDetail
    End If
    eventsCaptured = False
    NormalizeTransactionTimeEntry = True
    Exit Function
EH:
    errorNumber = Err.Number
    errorSource = Err.Source
    errorDescription = Err.Description
    If IsNavigationRecoveryHardBarrier(errorNumber, errorSource) Then
        Call TryStopNavigationEventsForBookWrites(eventStateDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    If eventsCaptured Then
        If Not TryRestoreNavigationEnableEvents( _
                   previousEvents, "NormalizeTransactionTimeEntry", eventStateDetail) Then _
            AppendNavigationSafetyDetail errorDescription, eventStateDetail
        eventsCaptured = False
    End If
    Err.Raise errorNumber, "NormalizeTransactionTimeEntry", errorDescription
End Function

Private Sub FillRelationshipFromPerson(ByVal ws As Worksheet)
    Dim relationshipText As String
    Dim previousEvents As Boolean
    Dim eventsCaptured As Boolean
    Dim eventStateDetail As String
    Dim errorNumber As Long, errorSource As String, errorDescription As String
    If ws Is Nothing Then Exit Sub
    If Not UseRelationshipDisplay() Then Exit Sub
    relationshipText = RelationshipForName(CellText(ws.Range(CELL_PERSON).Value))
    On Error GoTo EH
    If Not TryGetNavigationEnableEvents(previousEvents, eventStateDetail) Then
        StopAfterNavigationEventStateFailure _
            "FillRelationshipFromPerson/開始状態取得", eventStateDetail
        Err.Raise vbObjectError + 3338, "FillRelationshipFromPerson", _
                  "Excelイベントの開始状態を取得できませんでした。 " & eventStateDetail
    End If
    eventsCaptured = True
    If Not TrySetNavigationEnableEventsExact(False, eventStateDetail) Then _
        Err.Raise vbObjectError + 3339, "FillRelationshipFromPerson", _
                  "続柄補完前にExcelイベントを停止できませんでした。 " & eventStateDetail
    '氏名を単独で変更した時は、前の人物の続柄を残さない。
    '複数セル貼り付けはこの処理を通らないため、氏名と続柄の同時貼り付けは保持される。
    ws.Range(CELL_RELATIONSHIP).Value = relationshipText
    If Not TryRestoreNavigationEnableEvents( _
               previousEvents, "FillRelationshipFromPerson", eventStateDetail) Then
        eventsCaptured = False
        Err.Raise vbObjectError + 3340, "FillRelationshipFromPerson", eventStateDetail
    End If
    eventsCaptured = False
    Exit Sub
EH:
    errorNumber = Err.Number
    errorSource = Err.Source
    errorDescription = Err.Description
    If IsNavigationRecoveryHardBarrier(errorNumber, errorSource) Then
        Call TryStopNavigationEventsForBookWrites(eventStateDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    If eventsCaptured Then
        If Not TryRestoreNavigationEnableEvents( _
                   previousEvents, "FillRelationshipFromPerson", eventStateDetail) Then _
            AppendNavigationSafetyDetail errorDescription, eventStateDetail
        eventsCaptured = False
    End If
    Err.Raise errorNumber, "FillRelationshipFromPerson", errorDescription
End Sub

Private Sub UpdateCurrentRowHighlight(ByVal Target As Range)
    Dim ws As Worksheet
    Set ws = Target.Worksheet
    If mLastHighlightRow >= TX_FIRST_ROW And mLastHighlightRow <= TX_LAST_ROW Then
        RestoreTransactionRowStyle ws, mLastHighlightRow
    End If
    If Target.Row >= TX_FIRST_ROW And Target.Row <= TX_LAST_ROW Then
        With ws.Range(ws.Cells(Target.Row, COL_TX_YEAR), ws.Cells(Target.Row, COL_TX_OTHER))
            .Interior.Color = RGB(219, 234, 254)
            .Font.Color = RGB(15, 23, 42)
            .Borders.Color = RGB(37, 99, 235)
        End With
        mLastHighlightRow = Target.Row
    Else
        mLastHighlightRow = 0
    End If
End Sub

Private Sub RestoreTransactionRowStyle(ByVal ws As Worksheet, ByVal rowNo As Long)
    If ws Is Nothing Then Exit Sub
    With ws.Range(ws.Cells(rowNo, COL_TX_YEAR), ws.Cells(rowNo, COL_TX_OTHER))
        If (rowNo - TX_FIRST_ROW) Mod 2 = 0 Then
            .Interior.Color = RGB(255, 255, 255)
        Else
            .Interior.Color = RGB(248, 250, 252)
        End If
        .Font.Color = RGB(15, 23, 42)
        .Borders.Color = RGB(226, 232, 240)
    End With
End Sub
Private Sub UpdateComplementStatus(ByVal Target As Range)
    Dim ws As Worksheet, cy As Long, cm As Long, cd As Long
    Dim timeOK As Boolean, timeInvalid As Boolean, tVal As Variant
    Dim textY As String, textM As String, textD As String, textTime As String
    Dim anyDateRow As Boolean, anyDateInvalid As Boolean, anyDateIncomplete As Boolean
    Dim targetDataRow As Long
    Set ws = Target.Worksheet

    If mPendingMultiPasteValidation Then
        If ShowAllPendingInputErrors(ws) Then Exit Sub
        mPendingMultiPasteValidation = False
    End If

    '同じ口座番号が既に転記済みなら、入力補助欄を警告カードとして使う。
    'メッセージボックスを出すと入力の手が止まるため、画面内の色と文言だけで知らせる。
    If UpdateDuplicateAccountStatus(ws) Then Exit Sub

    ApplyStatusStyle ws, False
    If Target.Row < TX_FIRST_ROW Or Target.Row > TX_LAST_ROW Then
        ws.Range(CELL_STATUS).Value = InputFieldHint(Target)
        Exit Sub
    End If
    textTime = "--:--"
    targetDataRow = Target.Row - TX_FIRST_ROW + 1
    EnsureDateComplementCache ws, Target.Row
    cy = mDateCacheYear(targetDataRow)
    cm = mDateCacheMonth(targetDataRow)
    cd = mDateCacheDay(targetDataRow)
    anyDateRow = mDateCacheAnyDate(targetDataRow)
    anyDateInvalid = mDateCacheAnyInvalid(targetDataRow)
    anyDateIncomplete = mDateCacheAnyIncomplete(targetDataRow)
    '時刻は前行から補完しない。選択中の行に入力がある場合だけ表示する。
    If HasText(ws.Cells(Target.Row, COL_TX_TIME).Value2) Then
        tVal = NormalizeTimeInput(ws.Cells(Target.Row, COL_TX_TIME).Value2, timeOK)
        If timeOK Then
            If IsDate(tVal) Then
                textTime = Format$(CDate(tVal), "hh:mm")
            Else
                textTime = "時刻要確認"
                timeInvalid = True
            End If
        Else
            textTime = "時刻要確認"
            timeInvalid = True
        End If
    End If
    If timeInvalid Then
        mPendingMultiPasteValidation = True
        ApplyStatusStyle ws, True
    End If
    If anyDateRow And anyDateInvalid Then
        If Target.Column >= COL_TX_YEAR And Target.Column <= COL_TX_MONTH And _
           Not DateInputCellHasSyntaxProblem(Target) Then
            '年・月を順に訂正している途中の暫定不整合は、日セルへ進むまで通常の入力中表示にする。
            If Not timeInvalid Then ApplyStatusStyle ws, False
            ws.Range(CELL_STATUS).Value = "日付補完　入力中　／　入力時刻　" & textTime
        Else
            mPendingMultiPasteValidation = True
            ApplyStatusStyle ws, True
            ws.Range(CELL_STATUS).Value = "日付補完　要確認　／　入力時刻　" & textTime
        End If
    ElseIf anyDateRow And anyDateIncomplete Then
        If Target.Column < COL_TX_YEAR Or Target.Column > COL_TX_DAY Then
            mPendingMultiPasteValidation = True
            ApplyStatusStyle ws, True
            ws.Range(CELL_STATUS).Value = "日付補完　取引行の日付が未完成　／　入力時刻　" & textTime
        Else
            ws.Range(CELL_STATUS).Value = "日付補完　入力中　／　入力時刻　" & textTime
        End If
    Else
        If cy = 0 Then textY = "-" Else textY = CStr(cy)
        If cm = 0 Then textM = "-" Else textM = CStr(cm)
        If cd = 0 Then textD = "-" Else textD = CStr(cd)
        ws.Range(CELL_STATUS).Value = "日付補完 " & textY & "/" & textM & "/" & textD & _
                                     "　時刻 " & textTime & "　｜　" & InputFieldHint(Target)
    End If
End Sub

Private Function InputFieldHint(ByVal Target As Range) As String
    '警告がないときだけ、今入力している項目の案内を画面内に表示する。
    Dim addressText As String
    addressText = Target.Address(False, False)
    Select Case addressText
        Case CELL_BANK, CELL_BRANCH
            InputFieldHint = "銀行・支店名：候補から選択、または直接入力。候補は登録成功後に追加。"
        Case CELL_PERSON
            InputFieldHint = "名義人：同じ人物は登録済みの候補を選択。続柄は既存情報を引継ぎ。"
        Case CELL_ACCOUNT_TYPE
            InputFieldHint = "科目：候補から選択。Tabで口座番号へ進みます。"
        Case CELL_ACCOUNT_NO
            InputFieldHint = "口座番号：先頭の0も入力。登録済み口座は「口座一覧」から修正。"
        Case CELL_RELATIONSHIP
            InputFieldHint = "続柄：資料に記載された続柄を入力。表示の要否は設定で変更できます。"
        Case CELL_OPEN_DATE, CELL_CLOSE_DATE
            InputFieldHint = "開設日・解約日：分かる場合に入力。日付の入力方式は設定に従います。"
        Case Else
            If Target.Row >= TX_FIRST_ROW And Target.Row <= TX_LAST_ROW Then
                Select Case Target.Column
                    Case COL_TX_YEAR, COL_TX_MONTH, COL_TX_DAY
                        InputFieldHint = "先頭行は年月日を入力。以後、空欄は直前の日付を補完。"
                    Case COL_TX_TIME
                        InputFieldHint = "任意：9:30、0930など。空欄は時刻不明（前行を引継ぎません）。"
                    Case COL_TX_WITHDRAW, COL_TX_DEPOSIT
                        InputFieldHint = "出金・入金は片側だけ。カンマ・全角数字は入力後に整形。"
                    Case COL_TX_SHOP
                        InputFieldHint = "取扱店：通帳の店名・店番を入力。店番の先頭0は保持。"
                    Case COL_TX_MACHINE
                        InputFieldHint = "機番：記載がある場合に入力。分からなければ空欄。"
                    Case COL_TX_TEKIYO
                        InputFieldHint = "摘要：候補または直接入力。相手先など確認に役立つ記載を残す。"
                    Case COL_TX_BALANCE
                        InputFieldHint = "取引後残高：記載があれば入力。入出金との整合を残高検算で確認。"
                End Select
            Else
                InputFieldHint = "残高は資料に記載された金額を入力。Ctrl+Enter：登録 ／ 入力エラーへ：修正箇所に移動。"
            End If
    End Select
End Function

Private Sub EnsureDateComplementCache(ByVal ws As Worksheet, ByVal throughSheetRow As Long)
    Dim itemCount As Long, targetIndex As Long, startIndex As Long
    Dim r As Long, c As Long, cy As Long, cm As Long, cd As Long, sheetRow As Long
    Dim yAdd As Long, ok As Boolean, rowHasData As Boolean
    Dim anyDateRow As Boolean, rowDateInvalid As Boolean, rowDateIncomplete As Boolean
    Dim rowDateUnsupported As Boolean
    Dim inputData As Variant, resolvedDate As Variant
    Dim dateInputRange As Range
    Dim formulaRows As Object
    If ws Is Nothing Then Exit Sub
    itemCount = TX_LAST_ROW - TX_FIRST_ROW + 1
    targetIndex = throughSheetRow - TX_FIRST_ROW + 1
    If targetIndex < 1 Then Exit Sub
    If targetIndex > itemCount Then targetIndex = itemCount
    yAdd = GetCfgLong(ROW_CFG_YEAR_ADD, 2000)

    If Not mDateCacheReady Or mDateCacheYearAdd <> yAdd Then
        ReDim mDateCacheYear(1 To itemCount)
        ReDim mDateCacheMonth(1 To itemCount)
        ReDim mDateCacheDay(1 To itemCount)
        ReDim mDateCacheAnyDate(1 To itemCount)
        ReDim mDateCacheAnyInvalid(1 To itemCount)
        ReDim mDateCacheAnyIncomplete(1 To itemCount)
        mDateCacheValidThrough = 0
        mDateCacheYearAdd = yAdd
        mDateCacheReady = True
    End If
    If targetIndex <= mDateCacheValidThrough Then Exit Sub

    If mDateCacheValidThrough > 0 Then
        cy = mDateCacheYear(mDateCacheValidThrough)
        cm = mDateCacheMonth(mDateCacheValidThrough)
        cd = mDateCacheDay(mDateCacheValidThrough)
        anyDateRow = mDateCacheAnyDate(mDateCacheValidThrough)
    End If
    startIndex = mDateCacheValidThrough + 1
    Set dateInputRange = ws.Range( _
        ws.Cells(TX_FIRST_ROW + startIndex - 1, COL_TX_YEAR), _
        ws.Cells(TX_FIRST_ROW + targetIndex - 1, COL_TX_DAY))
    Set formulaRows = TransactionDateFormulaRowMap(dateInputRange)
    inputData = ws.Range( _
        ws.Cells(TX_FIRST_ROW + startIndex - 1, COL_TX_YEAR), _
        ws.Cells(TX_FIRST_ROW + targetIndex - 1, COL_TX_OTHER)).Value2

    For r = 1 To targetIndex - startIndex + 1
        rowHasData = False
        rowDateInvalid = False
        rowDateIncomplete = False
        sheetRow = TX_FIRST_ROW + startIndex + r - 2
        rowDateUnsupported = formulaRows.Exists(CStr(sheetRow)) Or _
                             IsError(inputData(r, 1)) Or _
                             IsError(inputData(r, COL_TX_MONTH - COL_TX_YEAR + 1)) Or _
                             IsError(inputData(r, COL_TX_DAY - COL_TX_YEAR + 1))
        For c = 1 To COL_TX_OTHER - COL_TX_YEAR + 1
            If HasText(inputData(r, c)) Then rowHasData = True: Exit For
        Next c
        If rowDateUnsupported Then rowHasData = True
        If rowHasData Then
            anyDateRow = True
            If rowDateUnsupported Then
                '数式結果やExcelエラーを補完基準へ採用しない。後続行の年月日を汚染させない。
                rowDateInvalid = True
            Else
                resolvedDate = ResolveInputDate(inputData(r, 1), _
                    inputData(r, COL_TX_MONTH - COL_TX_YEAR + 1), _
                    inputData(r, COL_TX_DAY - COL_TX_YEAR + 1), _
                    cy, cm, cd, yAdd, ok)
                If Not ok Then
                    If DateInputHasExplicitProblem(inputData(r, 1), _
                            inputData(r, COL_TX_MONTH - COL_TX_YEAR + 1), _
                            inputData(r, COL_TX_DAY - COL_TX_YEAR + 1), _
                            cy, cm, cd, yAdd) Then
                        rowDateInvalid = True
                    Else
                        rowDateIncomplete = True
                    End If
                End If
            End If
        End If
        c = startIndex + r - 1
        mDateCacheYear(c) = cy
        mDateCacheMonth(c) = cm
        mDateCacheDay(c) = cd
        mDateCacheAnyDate(c) = anyDateRow
        '不正・入力途中は現在行だけの状態。ResolveInputDateは失敗時に補完基準を
        '更新しないため、後続の正常行まで過去エラーで赤表示し続けない。
        mDateCacheAnyInvalid(c) = rowDateInvalid
        mDateCacheAnyIncomplete(c) = rowDateIncomplete
    Next r
    mDateCacheValidThrough = targetIndex
End Sub

Private Function TransactionDateFormulaRowMap(ByVal targetRange As Range) As Object
    'SpecialCellsを一度だけ呼び、数式セルがある行だけを辞書化する。
    'キャッシュ作成時に最大10,000行をセル単位のCOM呼出しで走査しない。
    Dim result As Object
    Dim formulaCells As Range, cell As Range
    Dim specialCellsError As Long, specialCellsDescription As String
    Set result = CreateObject("Scripting.Dictionary")
    result.CompareMode = vbBinaryCompare
    If targetRange Is Nothing Then
        Set TransactionDateFormulaRowMap = result
        Exit Function
    End If

    On Error Resume Next
    Set formulaCells = targetRange.SpecialCells(xlCellTypeFormulas)
    specialCellsError = Err.Number
    specialCellsDescription = Err.Description
    Err.Clear
    On Error GoTo EH
    If specialCellsError <> 0 And specialCellsError <> 1004 Then _
        Err.Raise specialCellsError, "TransactionDateFormulaRowMap", specialCellsDescription
    If Not formulaCells Is Nothing Then
        For Each cell In formulaCells.Cells
            If Not result.Exists(CStr(cell.Row)) Then result.Add CStr(cell.Row), True
        Next cell
    End If
    Set TransactionDateFormulaRowMap = result
    Exit Function
EH:
    Err.Raise Err.Number, "TransactionDateFormulaRowMap", Err.Description
End Function

Private Function DateInputHasExplicitProblem(ByVal yearValue As Variant, _
                                             ByVal monthValue As Variant, _
                                             ByVal dayValue As Variant, _
                                             ByVal baseYear As Long, _
                                             ByVal baseMonth As Long, _
                                             ByVal baseDay As Long, _
                                             ByVal yearAdd As Long) As Boolean
    Dim candidateYear As Long, candidateMonth As Long, candidateDay As Long
    Dim parsedMonth As Long, parsedDay As Long
    Dim valueText As String
    Dim yearOK As Boolean
    Dim candidateDate As Date
    On Error GoTo InvalidValue
    candidateYear = baseYear
    candidateMonth = baseMonth
    candidateDay = baseDay
    If HasText(yearValue) Then
        candidateYear = NormalizeYearInput(yearValue, yearAdd, yearOK)
        If Not yearOK Then GoTo InvalidValue
    End If
    If HasText(monthValue) Then
        valueText = NormalizeNumberText(CellText(monthValue))
        If Len(valueText) = 0 Or Len(valueText) > 2 Or _
           Not IsUnsignedIntegerText(valueText) Then GoTo InvalidValue
        candidateMonth = CLng(valueText)
        If candidateMonth < 1 Or candidateMonth > 12 Then GoTo InvalidValue
    End If
    If HasText(dayValue) Then
        valueText = NormalizeNumberText(CellText(dayValue))
        If Len(valueText) >= 3 Then
            If Not ParseMonthDay(dayValue, parsedMonth, parsedDay) Then GoTo InvalidValue
            candidateMonth = parsedMonth
            candidateDay = parsedDay
        Else
            If Len(valueText) = 0 Or Len(valueText) > 2 Or _
               Not IsUnsignedIntegerText(valueText) Then GoTo InvalidValue
            candidateDay = CLng(valueText)
            If candidateDay < 1 Or candidateDay > 31 Then GoTo InvalidValue
        End If
    End If
    '年月日のいずれかがまだ無い状態は不正ではなく入力途中。
    If candidateYear = 0 Or candidateMonth = 0 Or candidateDay = 0 Then Exit Function
    candidateDate = DateSerial(candidateYear, candidateMonth, candidateDay)
    If Year(candidateDate) <> candidateYear Or Month(candidateDate) <> candidateMonth Or _
       Day(candidateDate) <> candidateDay Then GoTo InvalidValue
    Exit Function
InvalidValue:
    DateInputHasExplicitProblem = True
End Function


Public Function UpdateDuplicateAccountStatus(ByVal ws As Worksheet) As Boolean
    Dim msg As String
    If ws Is Nothing Then Exit Function
    msg = DuplicateAccountWarningMessage(ws)
    If Len(msg) > 0 Then
        ApplyStatusStyle ws, True
        ws.Range(CELL_STATUS).Value = msg
        UpdateDuplicateAccountStatus = True
    Else
        ApplyStatusStyle ws, False
    End If
End Function

Private Function DuplicateAccountWarningMessage(ByVal ws As Worksheet) As String
    Dim bankName As String, branchName As String, personName As String, accType As String, accNo As String
    Dim hitInfo As String
    Dim cacheKey As String
    If ws Is Nothing Then Exit Function

    accNo = NormalizeAccountHyphen(CellText(ws.Range(CELL_ACCOUNT_NO).Value))
    If Len(accNo) = 0 Then
        InvalidateDuplicateAccountWarningCache
        Exit Function
    End If

    bankName = CellText(ws.Range(CELL_BANK).Value)
    branchName = CellText(ws.Range(CELL_BRANCH).Value)
    personName = CellText(ws.Range(CELL_PERSON).Value)
    accType = CellText(ws.Range(CELL_ACCOUNT_TYPE).Value)

    cacheKey = DuplicateAccountCacheKey(bankName, branchName, personName, accType, accNo)
    If cacheKey = mDuplicateCacheKey Then
        DuplicateAccountWarningMessage = mDuplicateCacheMessage
        Exit Function
    End If

    '口座マスタだけを検索する。取引・残高を全行走査しないため、件数が増えても軽い。
    If Len(bankName) > 0 And Len(accType) > 0 Then
        hitInfo = FindAccountIDByLocator(bankName, branchName, accType, accNo, CurrentEditAccountID())
    End If
    If Len(hitInfo) > 0 Then
        DuplicateAccountWarningMessage = "確認　同じ銀行・支店・科目・口座番号は登録済みです：" & accNo & _
                                         "　名義訂正も［登録済み口座］から行ってください。"
    End If

    mDuplicateCacheKey = cacheKey
    mDuplicateCacheMessage = DuplicateAccountWarningMessage
End Function

Private Function DuplicateAccountCacheKey(ByVal bankName As String, ByVal branchName As String, ByVal personName As String, ByVal accType As String, ByVal accNo As String) As String
    '口座情報だけでなく、作業シートの最終行もキーに含める。
    '転記後に行数が増えた場合は同じ口座番号でも再判定される。
    Dim accountLast As Long

    If SheetExists(SH_WORK_ACCOUNT) Then accountLast = LastUsedRowInSheet(GetSheet(SH_WORK_ACCOUNT))

    DuplicateAccountCacheKey = bankName & Chr$(30) & branchName & Chr$(30) & personName & Chr$(30) & _
                               accType & Chr$(30) & accNo & Chr$(30) & CurrentEditAccountID() & Chr$(30) & CStr(accountLast)
End Function

Private Sub ApplyStatusStyle(ByVal ws As Worksheet, ByVal warningMode As Boolean)
    Dim rng As Range
    Dim fillColor As Long, textColor As Long, borderColor As Long
    If ws Is Nothing Then Exit Sub
    Set rng = EffectiveRange(ws.Range(CELL_STATUS))
    If warningMode Then
        fillColor = RGB(254, 226, 226)
        textColor = RGB(153, 27, 27)
        borderColor = RGB(248, 113, 113)
    Else
        fillColor = RGB(240, 253, 250)
        textColor = RGB(15, 118, 110)
        borderColor = RGB(153, 246, 228)
    End If
    '選択移動のたびに同じ書式をExcelへ書き戻さない。
    If rng.Interior.Color = fillColor And rng.Font.Color = textColor Then Exit Sub
    rng.Interior.Color = fillColor
    rng.Font.Color = textColor
    rng.Borders.Color = borderColor
    rng.Font.Bold = True
    rng.Font.Size = 10
    rng.HorizontalAlignment = xlLeft
    rng.VerticalAlignment = xlCenter
    rng.WrapText = True
    rng.ShrinkToFit = False
End Sub

Attribute VB_Name = "modAppState"
Option Explicit
Private mDepth As Long
Private mEvents As Boolean, mScreen As Boolean, mAlerts As Boolean
Private mCalc As XlCalculation, mStatus As Variant

Public Sub AppBegin(Optional ByVal statusText As String = "������...")
    If mDepth = 0 Then
        mEvents = Application.EnableEvents: mScreen = Application.ScreenUpdating
        mAlerts = Application.DisplayAlerts: mCalc = Application.Calculation
        mStatus = Application.StatusBar
        If VarType(mStatus) = vbString Then
            If Left$(CStr(mStatus), 7) = "�ۑ����܂����F" Or Left$(CStr(mStatus), 6) = "�o�b�N�A�b�v" Then mStatus = False
        End If
    End If
    mDepth = mDepth + 1
    Application.EnableEvents = False: Application.ScreenUpdating = False
    Application.DisplayAlerts = False
    On Error Resume Next
    Application.Calculation = xlCalculationManual
    Application.StatusBar = statusText
    On Error GoTo 0
End Sub

Public Sub AppEnd()
    If mDepth = 0 Then Exit Sub
    mDepth = mDepth - 1
    If mDepth > 0 Then Exit Sub
    On Error Resume Next
    Application.Calculation = mCalc
    Application.ScreenUpdating = mScreen: Application.DisplayAlerts = mAlerts
    Application.StatusBar = mStatus
    SyncInputEnterSelection
    Application.EnableEvents = mEvents
    On Error GoTo 0
End Sub

Public Sub AppForceRestore()
    If mDepth > 0 Then mDepth = 1: AppEnd
End Sub

Attribute VB_Name = "modNavigation"
Option Explicit

Private mLastHighlightRow As Long
Private mDateThrough As Long
Private mDateCapacity As Long
Private mStatusStyle As Long
Private mKeyBinding As String
Private mDateYear() As Long
Private mDateMonth() As Long
Private mDateDay() As Long

'��������ԍ��x���́A���͍s���ړ����邽�тɍ�ƃV�[�g�S�̂𑖍�����Əd���Ȃ�B
'���݂̌������{��ƃV�[�g�������L�[�ɃL���b�V�����A������Ԃł͍đ������Ȃ��B
Private mDuplicateCacheKey As String
Private mDuplicateCacheMessage As String

Public Sub EnableInputKeys()
    Dim binding As String
    If Not ActiveWorkbook Is ThisWorkbook Then Exit Sub
    If ActiveSheet.Name <> SH_INPUT Then Exit Sub
    PrepareTransactionAmountEntry
    SyncInputEnterSelection
    binding = MacroRef("InputTabNext")
    If mKeyBinding = binding Then Exit Sub
    On Error GoTo Done
    Application.OnKey "{TAB}", binding
    Application.OnKey "+{TAB}", MacroRef("InputTabPrev")
    Application.OnKey "^+d", MacroRef("CopyPreviousDescription")
    mKeyBinding = binding
Done:
End Sub

Public Sub DisableInputKeys()
    DisableInputEnter
    mKeyBinding = ""
    On Error Resume Next
    Application.OnKey "{TAB}"
    Application.OnKey "+{TAB}"
    Application.OnKey "^+d"
    On Error GoTo 0
End Sub

Public Sub InvalidateDuplicateAccountWarningCache()
    '�]�L�E�������E�蓮�ҏW�Ȃǂō�ƃV�[�g�̓��e���ς�������ɌĂԁB
    '�Â��u�d���Ȃ��v���肪�c��ƌx���������Ƃ����߁A�����I�ɔj������B
    mDuplicateCacheKey = vbNullString
    mDuplicateCacheMessage = vbNullString
End Sub



Public Sub InputTabNext()
    MoveInputCell False
End Sub

Public Sub InputTabPrev()
    MoveInputCell True
End Sub

Public Sub MoveInputCell(ByVal backwards As Boolean)
    Dim ws As Worksheet
    Dim nextCell As Range
    On Error GoTo Fallback
    If ActiveSheet Is Nothing Then GoTo Fallback
    If Not ActiveWorkbook Is ThisWorkbook Then GoTo Fallback
    If ActiveSheet.Name <> SH_INPUT Then GoTo Fallback
    Set ws = ActiveSheet
    Set nextCell = GetNextInputCell(ws, ActiveCell, backwards)
    If Not nextCell Is Nothing Then
        PrepareInputSelection nextCell
        Application.Goto nextCell, False
        SyncInputEnterSelection
        Exit Sub
    End If
Fallback:
    On Error Resume Next
    If backwards Then ActiveCell.Offset(0, -1).Select Else ActiveCell.Offset(0, 1).Select
    On Error GoTo 0
End Sub

Public Function GetNextInputCell(ByVal ws As Worksheet, ByVal cur As Range, ByVal backwards As Boolean) As Range
    Dim r As Long, c As Long, memoCol As Long
    If ws Is Nothing Or cur Is Nothing Then Exit Function
    r = cur.Row: c = cur.Column
    memoCol = BalanceMemoCol(ws)
    If IsAccountCell(cur) Then
        Set GetNextInputCell = NextAccountCell(ws, cur, backwards)
        Exit Function
    End If
    If r = BAL_VALUE_ROW And c >= BAL_FIRST_COL And c <= memoCol Then
        Set GetNextInputCell = NextBalanceCell(ws, cur, backwards, memoCol)
        Exit Function
    End If
    If r >= TX_FIRST_ROW And r <= InputLastTransactionRow() And c >= COL_TX_YEAR And c <= COL_TX_OTHER Then
        Set GetNextInputCell = NextTransactionCell(ws, cur, backwards)
        Exit Function
    End If
    Set GetNextInputCell = ws.Range(CELL_BANK)
End Function

Private Function IsAccountCell(ByVal cur As Range) As Boolean
    Dim a As String
    If cur Is Nothing Then Exit Function
    a = cur.Address(False, False)
    IsAccountCell = (a = CELL_BANK Or a = CELL_BRANCH Or a = CELL_PERSON Or _
                     (UseRelationshipDisplay() And a = CELL_RELATIONSHIP) Or _
                     a = CELL_ACCOUNT_TYPE Or a = CELL_ACCOUNT_NO Or a = CELL_OPEN_DATE Or a = CELL_CLOSE_DATE)
End Function

Private Function NextAccountCell(ByVal ws As Worksheet, ByVal cur As Range, ByVal backwards As Boolean) As Range
    Dim arr As Variant, i As Long
    If UseRelationshipDisplay() Then
        arr = Array(CELL_BANK, CELL_BRANCH, CELL_PERSON, CELL_RELATIONSHIP, CELL_ACCOUNT_TYPE, CELL_ACCOUNT_NO, CELL_OPEN_DATE, CELL_CLOSE_DATE)
    Else
        arr = Array(CELL_BANK, CELL_BRANCH, CELL_PERSON, CELL_ACCOUNT_TYPE, CELL_ACCOUNT_NO, CELL_OPEN_DATE, CELL_CLOSE_DATE)
    End If
    For i = LBound(arr) To UBound(arr)
        If cur.Address(False, False) = CStr(arr(i)) Then
            If backwards Then
                If i = LBound(arr) Then Set NextAccountCell = ws.Range(CELL_BANK) Else Set NextAccountCell = ws.Range(CStr(arr(i - 1)))
            Else
                If i = UBound(arr) Then
                    Set NextAccountCell = FirstAvailableBalanceInputCell(ws)
                Else
                    Set NextAccountCell = ws.Range(CStr(arr(i + 1)))
                End If
            End If
            Exit Function
        End If
    Next i
    Set NextAccountCell = ws.Range(CELL_BANK)
End Function

Private Function NextBalanceCell(ByVal ws As Worksheet, ByVal cur As Range, ByVal backwards As Boolean, ByVal memoCol As Long) As Range
    '�J�ݓ��O�E������Ń��b�N���ꂽ�c�����́ATab�ړ��ł���΂��B
    '���̑����͏�ɓ��͉\�Ȃ̂ŁA�c���������ׂđΏۊO�ł��Ō�ɓ��B�ł���B
    If cur Is Nothing Then Exit Function
    If backwards Then
        Set NextBalanceCell = NextAvailableBalanceInputCell(ws, cur.Column, True)
    Else
        Set NextBalanceCell = NextAvailableBalanceInputCell(ws, cur.Column, False)
    End If
End Function

Private Function NextTransactionCell(ByVal ws As Worksheet, ByVal cur As Range, ByVal backwards As Boolean) As Range
    Dim cols As Variant, idx As Long, i As Long, targetCol As Long
    If Not backwards And cur.Row >= InputLastTransactionRow() Then EnsureTransactionCapacity cur.Row - TX_FIRST_ROW + 2
    cols = TransactionRoute(GetInputMode())

    '�y�N�E���̍l�����z
    '2�s�ڈȍ~�̘A�����͂ł́u���v���痬���B����A�N�ւ�肾���͑f����������悤�A
    '���Z���� Shift+Tab �����ꍇ�͌��ł͂Ȃ��N�֒��ږ߂��B���Z���̓N���b�N�E���L�[�ł͕ҏW�\�B
    If cur.Column = COL_TX_YEAR And Not backwards Then Set NextTransactionCell = ws.Cells(cur.Row, COL_TX_MONTH): Exit Function
    If cur.Column = COL_TX_MONTH And Not backwards Then Set NextTransactionCell = ws.Cells(cur.Row, COL_TX_DAY): Exit Function
    If cur.Column = COL_TX_DAY And backwards Then Set NextTransactionCell = ws.Cells(cur.Row, COL_TX_YEAR): Exit Function
    If cur.Column = COL_TX_MONTH And backwards Then Set NextTransactionCell = ws.Cells(cur.Row, COL_TX_YEAR): Exit Function
    If cur.Column = COL_TX_YEAR And backwards Then
        If cur.Row <= TX_FIRST_ROW Then
            Set NextTransactionCell = ws.Cells(cur.Row, COL_TX_YEAR)
        Else
            Set NextTransactionCell = ws.Cells(cur.Row - 1, CLng(cols(UBound(cols))))
        End If
        Exit Function
    End If

    '�ʏ탂�[�h�ł͂��̑����Tab���[�g����O���Ă���B
    '�������N���b�N�E���L�[�œ��������Tab���������ꍇ�́A�����s�̓��ł͂Ȃ����s�̓��֑���B
    If cur.Column = COL_TX_OTHER Then
        If backwards Then
            Set NextTransactionCell = ws.Cells(cur.Row, COL_TX_TEKIYO)
        ElseIf cur.Row < InputLastTransactionRow() Then
            Set NextTransactionCell = ws.Cells(cur.Row + 1, COL_TX_DAY)
        Else
            Set NextTransactionCell = ws.Cells(InputLastTransactionRow(), COL_TX_OTHER)
        End If
        Exit Function
    End If

    idx = -1
    For i = LBound(cols) To UBound(cols)
        If CLng(cols(i)) = cur.Column Then idx = i: Exit For
    Next i
    If idx = -1 Then Set NextTransactionCell = ws.Cells(cur.Row, COL_TX_DAY): Exit Function
    If backwards Then
        If idx = LBound(cols) Then
            If cur.Row <= TX_FIRST_ROW Then Set NextTransactionCell = ws.Cells(TX_FIRST_ROW, COL_TX_DAY) Else Set NextTransactionCell = ws.Cells(cur.Row - 1, CLng(cols(UBound(cols))))
        Else
            Set NextTransactionCell = ws.Cells(cur.Row, CLng(cols(idx - 1)))
        End If
    Else
        If cur.Column = COL_TX_WITHDRAW And HasText(cur.Value) Then
            targetCol = RouteColumnAfter(cols, COL_TX_DEPOSIT)
            Set NextTransactionCell = ws.Cells(cur.Row, targetCol)
            Exit Function
        End If
        If idx = UBound(cols) Then
            If cur.Row >= InputLastTransactionRow() Then Set NextTransactionCell = ws.Cells(InputLastTransactionRow(), CLng(cols(idx))) Else Set NextTransactionCell = ws.Cells(cur.Row + 1, COL_TX_DAY)
        Else
            Set NextTransactionCell = ws.Cells(cur.Row, CLng(cols(idx + 1)))
        End If
    End If
End Function

Private Function TransactionRoute(ByVal modeText As String) As Variant
    If modeText = MODE_SIMPLE Then
        TransactionRoute = Array(COL_TX_DAY, COL_TX_WITHDRAW, COL_TX_DEPOSIT, COL_TX_SHOP)
    ElseIf modeText = MODE_NO_TIME Then
        TransactionRoute = Array(COL_TX_DAY, COL_TX_WITHDRAW, COL_TX_DEPOSIT, COL_TX_SHOP, COL_TX_MACHINE, COL_TX_TEKIYO)
    ElseIf modeText = MODE_NO_MACHINE Then
        TransactionRoute = Array(COL_TX_DAY, COL_TX_TIME, COL_TX_WITHDRAW, COL_TX_DEPOSIT, COL_TX_SHOP, COL_TX_TEKIYO)
    ElseIf modeText = MODE_NO_TEKIYO Then
        TransactionRoute = Array(COL_TX_DAY, COL_TX_TIME, COL_TX_WITHDRAW, COL_TX_DEPOSIT, COL_TX_SHOP, COL_TX_MACHINE)
    ElseIf modeText = MODE_WITH_OTHER Then
        TransactionRoute = Array(COL_TX_DAY, COL_TX_TIME, COL_TX_WITHDRAW, COL_TX_DEPOSIT, COL_TX_SHOP, COL_TX_MACHINE, COL_TX_TEKIYO, COL_TX_OTHER)
    Else
        TransactionRoute = Array(COL_TX_DAY, COL_TX_TIME, COL_TX_WITHDRAW, COL_TX_DEPOSIT, COL_TX_SHOP, COL_TX_MACHINE, COL_TX_TEKIYO)
    End If
End Function

Private Function RouteColumnAfter(ByVal cols As Variant, ByVal afterCol As Long) As Long
    Dim i As Long
    For i = LBound(cols) To UBound(cols) - 1
        If CLng(cols(i)) = afterCol Then RouteColumnAfter = CLng(cols(i + 1)): Exit Function
    Next i
    RouteColumnAfter = COL_TX_SHOP
End Function

Public Sub OnInputSelectionChange(ByVal Target As Range)
    Dim t As Range
    If Target Is Nothing Then Exit Sub
    EnableInputKeys
    Set t = SingleInputCell(Target)
    If t Is Nothing Then Exit Sub
    PrepareInputSelection t
    UpdateCurrentRowHighlight t
    UpdateComplementStatus t
End Sub

Public Function InputNavigationCell(ByVal Target As Range) As Range
    Dim t As Range, ws As Worksheet
    If Target Is Nothing Then Exit Function
    If Not ActiveWorkbook Is ThisWorkbook Then Exit Function
    Set ws = GetSheet(SH_INPUT)
    If Not Target.Worksheet Is ws Then Exit Function
    If Not ActiveSheet Is ws Then Exit Function
    Set t = SingleInputCell(Target)
    If t Is Nothing Then Exit Function
    If t.Locked Then Exit Function
    If IsAccountCell(t) Then
        Set InputNavigationCell = t
    ElseIf t.Row = BAL_VALUE_ROW And t.Column >= BAL_FIRST_COL And t.Column <= BalanceMemoCol(ws) Then
        Set InputNavigationCell = t
    ElseIf t.Row >= TX_FIRST_ROW And t.Row <= InputLastTransactionRow() And _
           t.Column >= COL_TX_YEAR And t.Column <= COL_TX_OTHER Then
        Set InputNavigationCell = t
    End If
End Function

Public Sub OnInputChange(ByVal Target As Range)
    Dim t As Range, body As Range, area As Range, descriptions As Range
    Dim address As Variant, ws As Worksheet, datesChanged As Boolean
    If Target Is Nothing Then Exit Sub
    Set ws = Target.Worksheet
    MarkInputDirty Target
    NormalizeTransactionAmountChange Target
    Set descriptions = Intersect(Target, ws.Range("J" & TX_FIRST_ROW & ":J" & InputLastTransactionRow()))
    If Not descriptions Is Nothing Then RememberDescriptionRange descriptions
    Set body = Intersect(Target, ws.Range("B15:K" & InputLastTransactionRow()))
    If Not body Is Nothing Then
        For Each area In body.Areas
            InvalidateDateCacheFrom area.Row
            If area.Row + area.Rows.Count - 1 >= InputLastTransactionRow() Then EnsureTransactionCapacity InputLastTransactionRow() - TX_FIRST_ROW + 2
        Next area
    End If
    For Each address In Array(CELL_BANK, CELL_BRANCH, CELL_PERSON)
        If Not Intersect(Target, ws.Range(CStr(address)).MergeArea) Is Nothing Then UpdateCandidateFromTarget ws.Range(CStr(address))
    Next address
    For Each address In Array(CELL_OPEN_DATE, CELL_CLOSE_DATE)
        If Not Intersect(Target, ws.Range(CStr(address))) Is Nothing Then
            NormalizeAccountDateEntry ws.Range(CStr(address))
            datesChanged = True
        End If
    Next address
    If datesChanged Then
        ws.Unprotect Password:=TOOL_PASSWORD
        ApplyBalanceAvailability ws
        ProtectInputSheet
    End If
    '�l�ύX�ł͑I����ς��Ȃ��B�N���b�N�E���ɂ�������D�悷��B
    Set t = SingleInputCell(Target)
    If t Is Nothing Then Set t = Target.Cells(1, 1)
    UpdateComplementStatus t
End Sub

Private Function SingleInputCell(ByVal Target As Range) As Range
    Dim first As Range, merged As Range
    If Target Is Nothing Then Exit Function
    Set first = Target.Cells(1, 1)
    If Target.Cells.CountLarge = 1 Then Set SingleInputCell = first: Exit Function
    If Target.Areas.Count <> 1 Or Not first.MergeCells Then Exit Function
    Set merged = first.MergeArea
    If Target.Address = merged.Address Then Set SingleInputCell = first
End Function

Private Sub UpdateCurrentRowHighlight(ByVal Target As Range)
    Dim ws As Worksheet
    Set ws = Target.Worksheet
    If Target.Row = mLastHighlightRow Then Exit Sub
    If mLastHighlightRow >= TX_FIRST_ROW And mLastHighlightRow <= InputLastTransactionRow() Then
        RestoreTransactionRowStyle ws, mLastHighlightRow
    End If
    If Target.Row >= TX_FIRST_ROW And Target.Row <= InputLastTransactionRow() Then
        With ws.Range(ws.Cells(Target.Row, COL_TX_YEAR), ws.Cells(Target.Row, COL_TX_OTHER))
            .Interior.Color = RGB(219, 234, 254)
            .Font.Color = RGB(15, 23, 42)
            .Borders.Color = RGB(37, 99, 235)
        End With
        mLastHighlightRow = Target.Row
    Else
        mLastHighlightRow = 0
    End If
End Sub

Private Sub RestoreTransactionRowStyle(ByVal ws As Worksheet, ByVal rowNo As Long)
    If ws Is Nothing Then Exit Sub
    With ws.Range(ws.Cells(rowNo, COL_TX_YEAR), ws.Cells(rowNo, COL_TX_OTHER))
        If (rowNo - TX_FIRST_ROW) Mod 2 = 0 Then
            .Interior.Color = RGB(255, 255, 255)
        Else
            .Interior.Color = RGB(248, 250, 252)
        End If
        .Font.Color = RGB(15, 23, 42)
        .Borders.Color = RGB(226, 232, 240)
    End With
End Sub
Private Sub UpdateComplementStatus(ByVal Target As Range)
    Dim ws As Worksheet, r As Long, timeOK As Boolean, tVal As Variant
    Dim textY As String, textM As String, textD As String, textTime As String, caption As String
    Set ws = Target.Worksheet
    If UpdateDuplicateAccountStatus(ws) Then Exit Sub
    caption = TransactionAmountStatus(Target)
    If Len(caption) > 0 Then
        If CellText(ws.Range(CELL_STATUS).Value2) <> caption Then ws.Range(CELL_STATUS).Value2 = caption
        Exit Sub
    End If
    If Target.Row < TX_FIRST_ROW Or Target.Row > InputLastTransactionRow() Then
        If CellText(ws.Range(CELL_STATUS).Value2) <> "�⊮�l�@-�N�@-���@-���@--:--" Then ws.Range(CELL_STATUS).Value2 = "�⊮�l�@-�N�@-���@-���@--:--"
        Exit Sub
    End If
    r = Target.Row
    EnsureDateCache ws, r
    textTime = "--:--"
    tVal = NormalizeTimeInput(ws.Cells(r, COL_TX_TIME).Value, timeOK)
    If timeOK And HasText(tVal) Then textTime = Format$(CDate(tVal), "hh:mm")
    If mDateYear(r) = 0 Then textY = "-" Else textY = CStr(mDateYear(r))
    If mDateMonth(r) = 0 Then textM = "-" Else textM = CStr(mDateMonth(r))
    If mDateDay(r) = 0 Then textD = "-" Else textD = CStr(mDateDay(r))
    caption = "�⊮�l�@" & textY & "�N�@" & textM & "���@" & textD & "���@" & textTime
    If CellText(ws.Range(CELL_STATUS).Value2) <> caption Then ws.Range(CELL_STATUS).Value2 = caption
End Sub

Public Sub ResetInputNavigation()
    ResetInputCapacityCache
    EnsureDateCacheCapacity InputLastTransactionRow()
    mStatusStyle = -1
    mDateThrough = TX_FIRST_ROW - 1
    mDateYear(mDateThrough) = 0: mDateMonth(mDateThrough) = 0: mDateDay(mDateThrough) = 0
    If mLastHighlightRow >= TX_FIRST_ROW And mLastHighlightRow <= InputLastTransactionRow() Then RestoreTransactionRowStyle GetSheet(SH_INPUT), mLastHighlightRow
    mLastHighlightRow = 0
    InvalidateDuplicateAccountWarningCache
End Sub

Private Sub InvalidateDateCacheFrom(ByVal rowNo As Long)
    If mDateThrough < TX_FIRST_ROW Then Exit Sub
    If rowNo <= mDateThrough Then mDateThrough = rowNo - 1
End Sub

Private Sub EnsureDateCache(ByVal ws As Worksheet, ByVal throughRow As Long)
    Dim raw As Variant, startRow As Long, i As Long, r As Long, cy As Long, cm As Long, cd As Long
    Dim resultDate As Variant, ok As Boolean, yearAdd As Long
    EnsureDateCacheCapacity throughRow
    If mDateThrough < TX_FIRST_ROW - 1 Then ResetInputNavigation
    If throughRow <= mDateThrough Then Exit Sub
    startRow = mDateThrough + 1
    cy = mDateYear(mDateThrough): cm = mDateMonth(mDateThrough): cd = mDateDay(mDateThrough)
    raw = ws.Cells(startRow, COL_TX_YEAR).Resize(throughRow - startRow + 1, 3).Value2
    yearAdd = InputYearAdd()
    For i = 1 To UBound(raw, 1)
        r = startRow + i - 1
        resultDate = ResolveInputDate(raw(i, 1), raw(i, 2), raw(i, 3), cy, cm, cd, yearAdd, ok)
        mDateYear(r) = cy: mDateMonth(r) = cm: mDateDay(r) = cd
    Next i
    mDateThrough = throughRow
End Sub



Public Function UpdateDuplicateAccountStatus(ByVal ws As Worksheet) As Boolean
    Dim msg As String
    If ws Is Nothing Then Exit Function
    msg = DuplicateAccountWarningMessage(ws)
    If Len(msg) > 0 Then
        ApplyStatusStyle ws, True
        If CellText(ws.Range(CELL_STATUS).Value2) <> msg Then ws.Range(CELL_STATUS).Value2 = msg
        UpdateDuplicateAccountStatus = True
    Else
        ApplyStatusStyle ws, False
    End If
End Function

Private Function DuplicateAccountWarningMessage(ByVal ws As Worksheet) As String
    Dim accountID As String, key As String, editID As String
    editID = CurrentEditAccountID()
    key = editID & Chr$(29) & AccountIdentityKey(CellText(ws.Range(CELL_BANK).Value2), CellText(ws.Range(CELL_BRANCH).Value2), CellText(ws.Range(CELL_ACCOUNT_TYPE).Value2), CellText(ws.Range(CELL_ACCOUNT_NO).Value2))
    If key <> mDuplicateCacheKey Then
        accountID = DuplicateAccountID(CellText(ws.Range(CELL_BANK).Value2), CellText(ws.Range(CELL_BRANCH).Value2), CellText(ws.Range(CELL_ACCOUNT_TYPE).Value2), CellText(ws.Range(CELL_ACCOUNT_NO).Value2), editID)
        mDuplicateCacheMessage = ""
        If Len(accountID) > 0 Then mDuplicateCacheMessage = "�o�^�ς݂̌����ł��B�u�o�^�����v����J���Ēǉ��E�����ł��܂��B"
        mDuplicateCacheKey = key
    End If
    DuplicateAccountWarningMessage = mDuplicateCacheMessage
End Function









Private Sub ApplyStatusStyle(ByVal ws As Worksheet, ByVal warningMode As Boolean)
    Dim rng As Range
    If ws Is Nothing Then Exit Sub
    If mStatusStyle = IIf(warningMode, 1, 0) Then Exit Sub
    Set rng = ws.Range(CELL_STATUS & ":K12")
    If warningMode Then
        rng.Interior.Color = RGB(254, 226, 226)
        rng.Font.Color = RGB(153, 27, 27)
        rng.Borders.Color = RGB(248, 113, 113)
    Else
        rng.Interior.Color = RGB(236, 253, 245)
        rng.Font.Color = RGB(15, 118, 110)
        rng.Borders.Color = RGB(94, 234, 212)
    End If
    rng.Font.Bold = True
    rng.HorizontalAlignment = xlCenter
    rng.VerticalAlignment = xlCenter
    mStatusStyle = IIf(warningMode, 1, 0)
End Sub

Private Sub EnsureDateCacheCapacity(ByVal lastRow As Long)
    If mDateCapacity >= lastRow Then Exit Sub
    If mDateCapacity = 0 Then
        ReDim mDateYear(0 To lastRow): ReDim mDateMonth(0 To lastRow): ReDim mDateDay(0 To lastRow)
    Else
        ReDim Preserve mDateYear(0 To lastRow): ReDim Preserve mDateMonth(0 To lastRow): ReDim Preserve mDateDay(0 To lastRow)
    End If
    mDateCapacity = lastRow
End Sub

Public Sub InvalidateInputStatusAppearance()
    mStatusStyle = -1
End Sub

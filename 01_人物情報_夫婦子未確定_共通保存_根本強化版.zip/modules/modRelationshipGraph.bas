Attribute VB_Name = "modRelationshipGraph"
Option Explicit

'�����֌W�}��p�̊m��e�����f���B
'�`�撆�� P_SUR_SRC / W_�֌W / �����������s�x���肵�Ȃ����߂̒��ԃ��f���B

Private gBuilt As Boolean
Private gDecedentId As String
Private gPersonRows As Object
Private gParentByChild As Object
Private gParentScoreByChild As Object
Private gParentSourceByChild As Object
Private gChildrenByParent As Object
Private gChildEdgeKeys As Object
Private gSpouseByPerson As Object
Private gSpouseScoreByPerson As Object
Private gAllSpousesByPerson As Object
Private gCoupleMarriage As Object
Private gCoupleDivorce As Object
Private gCoupleSource As Object
Private gCoupleChildByChild As Object
Private gPureSpouse As Object
Private gSpouseBloodlineById As Object
Private gDisplayRelById As Object
Private gGraphWarnings As Object
Private gBlockedParentFallbackByChild As Object

Public Sub DiagramGraphReset()
    gBuilt = False
    gDecedentId = vbNullString
    Set gPersonRows = Nothing
    Set gParentByChild = Nothing
    Set gParentScoreByChild = Nothing
    Set gParentSourceByChild = Nothing
    Set gChildrenByParent = Nothing
    Set gChildEdgeKeys = Nothing
    Set gSpouseByPerson = Nothing
    Set gSpouseScoreByPerson = Nothing
    Set gAllSpousesByPerson = Nothing
    Set gCoupleMarriage = Nothing
    Set gCoupleDivorce = Nothing
    Set gCoupleSource = Nothing
    Set gCoupleChildByChild = Nothing
    Set gPureSpouse = Nothing
    Set gSpouseBloodlineById = Nothing
    Set gDisplayRelById = Nothing
    Set gGraphWarnings = Nothing
    Set gBlockedParentFallbackByChild = Nothing
End Sub

Public Function DiagramGraphIsBuilt() As Boolean
    DiagramGraphIsBuilt = gBuilt
End Function

Public Function DiagramGraphEnsureBuilt(ByVal decedentId As String) As Boolean
    decedentId = CleanText(decedentId)
    If gBuilt Then
        If CleanText(gDecedentId) = decedentId Then
            DiagramGraphEnsureBuilt = True
            Exit Function
        End If
    End If
    If Len(decedentId) = 0 Then Exit Function
    BuildDiagramGraphForRelationshipDiagram decedentId
    DiagramGraphEnsureBuilt = gBuilt
End Function

Public Function DiagramGraphRebuildFresh(ByVal decedentId As String, Optional ByVal raiseOnError As Boolean = False) As Boolean
    On Error GoTo EH
    decedentId = CleanText(decedentId)
    DiagramGraphReset
    If Len(decedentId) = 0 Then Exit Function
    EnsureMarriageHistoryWorkSheet
    SyncMarriageHistoryFromLegacyTables
    BuildDiagramGraphForRelationshipDiagram decedentId
    DiagramGraphRebuildFresh = gBuilt
    Exit Function
EH:
    gBuilt = False
    If raiseOnError Then Err.Raise Err.Number, Err.Source, Err.Description
End Function

Public Sub BuildDiagramGraphForRelationshipDiagram(ByVal decedentId As String)
    On Error GoTo EH
    DiagramGraphReset
    gDecedentId = CleanText(decedentId)
    GraphInitDictionaries
    GraphLoadVisiblePersons
    If Len(gDecedentId) = 0 Then Err.Raise vbObjectError + 9201, "BuildDiagramGraphForRelationshipDiagram", "�푊���l�l��ID����ł��B"
    If Not gPersonRows.Exists(gDecedentId) Then Err.Raise vbObjectError + 9202, "BuildDiagramGraphForRelationshipDiagram", "�푊���l���\���Ώېl���\�ɑ��݂��܂���B"

    GraphLoadSpouseEdgesFromRelations
    GraphLoadSpouseEdgesFromPersonBase
    GraphMergeSpouseDatesFromPersonFields
    GraphMergeSpouseDatesFromMarriageHistory
    GraphMarkPureSpouses
    GraphLoadExplicitParentChildEdges
    GraphLoadBasePersonParentChildEdges
    GraphLoadRelationLabelFallbackEdges
    GraphResolveParentSpouseFacts
    GraphResolveUniqueGenerationFallbacks
    GraphRebuildChildrenIndex
    gBuilt = True
    GraphBuildDisplayRelations
    GraphValidateModel
    Exit Sub
EH:
    GraphAddWarning "BuildDiagramGraphForRelationshipDiagram", Err.Description
    gBuilt = False
    Err.Raise Err.Number, Err.Source, Err.Description
End Sub

Private Sub GraphInitDictionaries()
    Set gPersonRows = CreateObject("Scripting.Dictionary")
    Set gParentByChild = CreateObject("Scripting.Dictionary")
    Set gParentScoreByChild = CreateObject("Scripting.Dictionary")
    Set gParentSourceByChild = CreateObject("Scripting.Dictionary")
    Set gChildrenByParent = CreateObject("Scripting.Dictionary")
    Set gChildEdgeKeys = CreateObject("Scripting.Dictionary")
    Set gSpouseByPerson = CreateObject("Scripting.Dictionary")
    Set gSpouseScoreByPerson = CreateObject("Scripting.Dictionary")
    Set gAllSpousesByPerson = CreateObject("Scripting.Dictionary")
    Set gCoupleMarriage = CreateObject("Scripting.Dictionary")
    Set gCoupleDivorce = CreateObject("Scripting.Dictionary")
    Set gCoupleSource = CreateObject("Scripting.Dictionary")
    Set gCoupleChildByChild = CreateObject("Scripting.Dictionary")
    Set gPureSpouse = CreateObject("Scripting.Dictionary")
    Set gSpouseBloodlineById = CreateObject("Scripting.Dictionary")
    Set gDisplayRelById = CreateObject("Scripting.Dictionary")
    Set gGraphWarnings = CreateObject("Scripting.Dictionary")
    Set gBlockedParentFallbackByChild = CreateObject("Scripting.Dictionary")
End Sub

Private Sub GraphLoadVisiblePersons()
    Dim wp As Worksheet, r As Long, pid As String
    If Not SheetExists(SH_W_PERSON, ThisWorkbook) Then Exit Sub
    Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)
    For r = 2 To LastRow(wp, P_ID)
        pid = CleanText(wp.Cells(r, P_ID).Value)
        If Len(pid) > 0 Then
            If CleanText(wp.Cells(r, P_STATUS).Value) <> STATUS_CANCEL Then
                If CleanText(wp.Cells(r, P_SHOW).Value) <> SHOW_NO Then
                    If Not gPersonRows.Exists(pid) Then gPersonRows.Add pid, r
                End If
            End If
        End If
    Next r
End Sub

Private Sub GraphLoadSpouseEdgesFromRelations()
    Dim wr As Worksheet, r As Long, a As String, b As String, relType As String
    If Not SheetExists(SH_W_REL, ThisWorkbook) Then Exit Sub
    Set wr = ThisWorkbook.Worksheets(SH_W_REL)
    For r = 2 To LastRow(wr, R_ID)
        If CleanText(wr.Cells(r, R_STATUS).Value) <> STATUS_CANCEL Then
            relType = CleanText(wr.Cells(r, R_TYPE).Value)
            If relType = "�z���" Then
                a = CleanText(wr.Cells(r, R_BASE_ID).Value)
                b = CleanText(wr.Cells(r, R_OTHER_ID).Value)
                GraphAddSpouseEdge a, b, wr.Cells(r, R_MARRIAGE).Value, wr.Cells(r, R_DIVORCE).Value, "W_�֌W:�z���", 900
            End If
        End If
    Next r
End Sub

Private Sub GraphLoadSpouseEdgesFromPersonBase()
    Dim wp As Worksheet, r As Long, pid As String, baseId As String, relText As String
    If Not SheetExists(SH_W_PERSON, ThisWorkbook) Then Exit Sub
    Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)
    For r = 2 To LastRow(wp, P_ID)
        pid = CleanText(wp.Cells(r, P_ID).Value)
        If Len(pid) > 0 And gPersonRows.Exists(pid) Then
            baseId = CleanText(wp.Cells(r, P_SUR_SRC).Value)
            relText = GraphPersonRawRelationByRow(r)
            If Len(baseId) > 0 And gPersonRows.Exists(baseId) Then
                If GraphRelationLooksLikeSpouse(relText) Then
                    GraphAddSpouseEdge baseId, pid, wp.Cells(r, P_MARRIAGE).Value, wp.Cells(r, P_DIVORCE).Value, "P_SUR_SRC:�z���", 820
                End If
            End If
        End If
    Next r
End Sub

Private Sub GraphAddSpouseEdge(ByVal personA As String, ByVal personB As String, ByVal marriageDate As Variant, ByVal divorceDate As Variant, ByVal sourceText As String, ByVal score As Long)
    Dim key As String
    personA = CleanText(personA)
    personB = CleanText(personB)
    If Len(personA) = 0 Or Len(personB) = 0 Then Exit Sub
    If personA = personB Then Exit Sub
    If Not gPersonRows.Exists(personA) Then Exit Sub
    If Not gPersonRows.Exists(personB) Then Exit Sub

    GraphAddAllSpouse personA, personB
    GraphAddAllSpouse personB, personA
    GraphSetPreferredSpouse personA, personB, score, divorceDate
    GraphSetPreferredSpouse personB, personA, score, divorceDate

    key = GraphPairKey(personA, personB)
    If Len(key) = 0 Then Exit Sub
    If Not gCoupleMarriage.Exists(key) Then
        gCoupleMarriage.Add key, marriageDate
        gCoupleDivorce.Add key, divorceDate
        gCoupleSource.Add key, sourceText
    Else
        If Not IsDate(gCoupleMarriage(key)) And IsDate(marriageDate) Then gCoupleMarriage(key) = marriageDate
        If Not IsDate(gCoupleDivorce(key)) And IsDate(divorceDate) Then gCoupleDivorce(key) = divorceDate
        If Len(CleanText(gCoupleSource(key))) = 0 Then gCoupleSource(key) = sourceText
    End If
End Sub

Private Sub GraphAddAllSpouse(ByVal personId As String, ByVal spouseId As String)
    Dim col As Collection, i As Long
    personId = CleanText(personId)
    spouseId = CleanText(spouseId)
    If Len(personId) = 0 Or Len(spouseId) = 0 Then Exit Sub
    If personId = spouseId Then Exit Sub
    If gAllSpousesByPerson Is Nothing Then Exit Sub
    If Not gAllSpousesByPerson.Exists(personId) Then
        Set col = New Collection
        gAllSpousesByPerson.Add personId, col
    Else
        Set col = gAllSpousesByPerson(personId)
    End If
    For i = 1 To col.Count
        If CleanText(CStr(col(i))) = spouseId Then Exit Sub
    Next i
    col.Add spouseId
End Sub

Private Sub GraphSetPreferredSpouse(ByVal personId As String, ByVal spouseId As String, ByVal score As Long, ByVal divorceDate As Variant)
    Dim currentScore As Long, adjustedScore As Long
    If Len(personId) = 0 Or Len(spouseId) = 0 Then Exit Sub
    adjustedScore = score
    If Not GraphHasDate(divorceDate) Then adjustedScore = adjustedScore + 25
    If Not gSpouseScoreByPerson.Exists(personId) Then
        gSpouseByPerson.Add personId, spouseId
        gSpouseScoreByPerson.Add personId, adjustedScore
    Else
        currentScore = CLng(gSpouseScoreByPerson(personId))
        If adjustedScore > currentScore Then
            gSpouseByPerson(personId) = spouseId
            gSpouseScoreByPerson(personId) = adjustedScore
        End If
    End If
End Sub

Private Sub GraphMergeSpouseDatesFromPersonFields()
    Dim key As Variant, ids As Variant, leftId As String, rightId As String
    Dim m As Variant, d As Variant
    If gCoupleMarriage Is Nothing Then Exit Sub
    For Each key In gCoupleMarriage.Keys
        ids = Split(CStr(key), "|")
        If UBound(ids) >= 1 Then
            leftId = CStr(ids(0))
            rightId = CStr(ids(1))
            If Not GraphHasDate(gCoupleMarriage(CStr(key))) Then
                m = GraphFirstPersonDateForPair(leftId, rightId, True)
                If GraphHasDate(m) Then gCoupleMarriage(CStr(key)) = m
            End If
            If Not GraphHasDate(gCoupleDivorce(CStr(key))) Then
                d = GraphFirstPersonDateForPair(leftId, rightId, False)
                If GraphHasDate(d) Then gCoupleDivorce(CStr(key)) = d
            End If
        End If
    Next key
End Sub

Private Function GraphFirstPersonDateForPair(ByVal leftId As String, ByVal rightId As String, ByVal wantMarriage As Boolean) As Variant
    Dim v As Variant
    v = GraphPersonDateField(leftId, wantMarriage)
    If GraphHasDate(v) Then
        GraphFirstPersonDateForPair = v
        Exit Function
    End If
    v = GraphPersonDateField(rightId, wantMarriage)
    If GraphHasDate(v) Then GraphFirstPersonDateForPair = v
End Function

Private Sub GraphMergeSpouseDatesFromMarriageHistory()
    Dim key As Variant, ids As Variant, leftId As String, rightId As String
    Dim m As Variant, d As Variant
    If gCoupleMarriage Is Nothing Then Exit Sub
    For Each key In gCoupleMarriage.Keys
        ids = Split(CStr(key), "|")
        If UBound(ids) >= 1 Then
            leftId = CStr(ids(0))
            rightId = CStr(ids(1))
            If Not GraphHasDate(gCoupleMarriage(CStr(key))) Then
                m = GraphFirstMarriageHistoryDateForPair(leftId, rightId, True)
                If GraphHasDate(m) Then gCoupleMarriage(CStr(key)) = m
            End If
            If Not GraphHasDate(gCoupleDivorce(CStr(key))) Then
                d = GraphFirstMarriageHistoryDateForPair(leftId, rightId, False)
                If GraphHasDate(d) Then gCoupleDivorce(CStr(key)) = d
            End If
        End If
    Next key
End Sub

Private Function GraphFirstMarriageHistoryDateForPair(ByVal leftId As String, ByVal rightId As String, ByVal wantMarriage As Boolean) As Variant
    Dim mh As Worksheet, r As Long, pid As String, cpId As String, v As Variant
    Dim best As Variant
    If Not SheetExists(SH_W_MARRIAGE_HIST, ThisWorkbook) Then Exit Function
    Set mh = ThisWorkbook.Worksheets(SH_W_MARRIAGE_HIST)
    For r = 2 To LastRow(mh, MH_ID)
        If CleanText(mh.Cells(r, MH_STATUS).Value) <> STATUS_CANCEL Then
            If CleanText(mh.Cells(r, MH_SHOW).Value) <> SHOW_NO Then
                pid = CleanText(mh.Cells(r, MH_PERSON_ID).Value)
                cpId = CleanText(mh.Cells(r, MH_COUNTERPART_ID).Value)
                If GraphMarriageHistoryRowMatchesPair(pid, cpId, leftId, rightId) Then
                    If wantMarriage Then
                        v = mh.Cells(r, MH_MARRIAGE).Value
                    Else
                        v = mh.Cells(r, MH_DIVORCE).Value
                    End If
                    If GraphDateToSerialOk(v) Then
                        If Not GraphDateToSerialOk(best) Then
                            best = v
                        ElseIf GraphDateSerial(v) < GraphDateSerial(best) Then
                            best = v
                        End If
                    End If
                End If
            End If
        End If
    Next r
    GraphFirstMarriageHistoryDateForPair = best
End Function

Private Function GraphMarriageHistoryRowMatchesPair(ByVal pid As String, ByVal cpId As String, ByVal leftId As String, ByVal rightId As String) As Boolean
    pid = CleanText(pid)
    cpId = CleanText(cpId)
    leftId = CleanText(leftId)
    rightId = CleanText(rightId)
    If Len(pid) = 0 Then Exit Function
    If (pid = leftId And cpId = rightId) Or (pid = rightId And cpId = leftId) Then
        GraphMarriageHistoryRowMatchesPair = True
        Exit Function
    End If
    '����l�������o�^�̍��������ł��A�l���ɔz��҂�1�l�����m�肵�Ă���ꍇ�́A���̕v�w���ԂƂ��Ďg���B
    If Len(cpId) = 0 Then
        If pid = leftId Then
            If DiagramGraphSpouseId(leftId) = rightId Then GraphMarriageHistoryRowMatchesPair = True
        ElseIf pid = rightId Then
            If DiagramGraphSpouseId(rightId) = leftId Then GraphMarriageHistoryRowMatchesPair = True
        End If
    End If
End Function

Private Function GraphMarriageHistoryPairCoversChild(ByVal leftId As String, ByVal rightId As String, ByVal childId As String, ByVal childBirth As Variant) As Boolean
    Dim mh As Worksheet, r As Long, pid As String, cpId As String, m As Variant, d As Variant
    If Not GraphDateToSerialOk(childBirth) Then Exit Function
    If Not SheetExists(SH_W_MARRIAGE_HIST, ThisWorkbook) Then Exit Function
    Set mh = ThisWorkbook.Worksheets(SH_W_MARRIAGE_HIST)
    For r = 2 To LastRow(mh, MH_ID)
        If CleanText(mh.Cells(r, MH_STATUS).Value) <> STATUS_CANCEL Then
            If CleanText(mh.Cells(r, MH_SHOW).Value) <> SHOW_NO Then
                pid = CleanText(mh.Cells(r, MH_PERSON_ID).Value)
                cpId = CleanText(mh.Cells(r, MH_COUNTERPART_ID).Value)
                If GraphMarriageHistoryRowMatchesPair(pid, cpId, leftId, rightId) Then
                    m = mh.Cells(r, MH_MARRIAGE).Value
                    d = mh.Cells(r, MH_DIVORCE).Value
                    If GraphDateWithinOpenPeriod(childBirth, m, d) Then
                        GraphMarriageHistoryPairCoversChild = True
                        Exit Function
                    End If
                End If
            End If
        End If
    Next r
End Function

Private Function GraphDateWithinOpenPeriod(ByVal targetDate As Variant, ByVal startDate As Variant, ByVal endDate As Variant) As Boolean
    If Not GraphDateToSerialOk(targetDate) Then Exit Function
    '�v�w�̎q����ł́A�����J�n�����Ȃ����Ԃ��m�舵�����Ȃ��B
    If Not GraphDateToSerialOk(startDate) Then Exit Function
    If GraphDateSerial(targetDate) < GraphDateSerial(startDate) Then Exit Function
    If GraphDateToSerialOk(endDate) Then
        If GraphDateSerial(targetDate) > GraphDateSerial(endDate) Then Exit Function
    End If
    GraphDateWithinOpenPeriod = True
End Function

Private Function GraphPersonDateField(ByVal personId As String, ByVal wantMarriage As Boolean) As Variant
    Dim rowNo As Long
    If Len(personId) = 0 Then Exit Function
    If gPersonRows Is Nothing Then Exit Function
    If Not gPersonRows.Exists(personId) Then Exit Function
    rowNo = CLng(gPersonRows(personId))
    If wantMarriage Then
        GraphPersonDateField = ThisWorkbook.Worksheets(SH_W_PERSON).Cells(rowNo, P_MARRIAGE).Value
    Else
        GraphPersonDateField = ThisWorkbook.Worksheets(SH_W_PERSON).Cells(rowNo, P_DIVORCE).Value
    End If
End Function

Private Sub GraphMarkPureSpouses()
    Dim pid As Variant, baseId As String, relText As String, rowNo As Long, spouseId As String

    'W_�֌W�̔z��ҍs�́A�o�^���́u��l�����z��ҁv�̌������ŗD��Ɏg���B
    '�ߋ��̑����␳�Ŕz��҃J�[�h���u���v�u�]���v���ɉ��Ă��Ă��A�����Ŕz��҂Ƃ��ĕ�������B
    GraphMarkPureSpousesFromRelationOrientation

    For Each pid In gPersonRows.Keys
        rowNo = CLng(gPersonRows(CStr(pid)))
        baseId = CleanText(ThisWorkbook.Worksheets(SH_W_PERSON).Cells(rowNo, P_SUR_SRC).Value)
        relText = GraphPersonRawRelationByRow(rowNo)
        If Len(baseId) > 0 Then
            If gPersonRows.Exists(baseId) Then
                If GraphSpouseRelationExists(CStr(pid), baseId) Then
                    GraphMarkPureSpouse CStr(pid), baseId, "P_SUR_SRC+�z��Ҋ֌W"
                ElseIf GraphRelationLooksLikeSpouse(relText) Then
                    GraphMarkPureSpouse CStr(pid), baseId, "����:�z���"
                End If
            End If
        End If
    Next pid

    For Each pid In gPersonRows.Keys
        spouseId = DiagramGraphSpouseId(CStr(pid))
        If Len(spouseId) > 0 Then
            If GraphRelationLooksLikeSpouse(GraphPersonRawRelationById(spouseId)) And GraphBloodlinePriority(CStr(pid)) > 0 Then
                GraphMarkPureSpouse spouseId, CStr(pid), "�z��ґ���"
            End If
            If GraphRelationLooksLikeSpouse(GraphPersonRawRelationById(CStr(pid))) And GraphBloodlinePriority(spouseId) > 0 Then
                GraphMarkPureSpouse CStr(pid), spouseId, "�z��ґ���"
            End If
        End If
    Next pid
End Sub

Private Sub GraphMarkPureSpousesFromRelationOrientation()
    Dim wr As Worksheet, r As Long, a As String, b As String
    If Not SheetExists(SH_W_REL, ThisWorkbook) Then Exit Sub
    Set wr = ThisWorkbook.Worksheets(SH_W_REL)
    For r = 2 To LastRow(wr, R_ID)
        If CleanText(wr.Cells(r, R_STATUS).Value) <> STATUS_CANCEL Then
            If CleanText(wr.Cells(r, R_TYPE).Value) = "�z���" Then
                a = CleanText(wr.Cells(r, R_BASE_ID).Value)
                b = CleanText(wr.Cells(r, R_OTHER_ID).Value)
                If Len(a) > 0 And Len(b) > 0 Then
                    If gPersonRows.Exists(a) And gPersonRows.Exists(b) Then
                        If GraphPersonLooksLikeSpouseOf(a, b) Then
                            GraphMarkPureSpouse a, b, "W_�֌W:�z��Ҍ���"
                        ElseIf GraphPersonLooksLikeSpouseOf(b, a) Then
                            GraphMarkPureSpouse b, a, "W_�֌W:�z��Ҍ���"
                        Else
                            '�����q�����x���ɉ��Ă���ꍇ�ł��A���͎d�l�� R_BASE_ID=��l�� / R_OTHER_ID=�z��ҁB
                            GraphMarkPureSpouse b, a, "W_�֌W:�z��ғo�^����"
                        End If
                    End If
                End If
            End If
        End If
    Next r
End Sub

Private Function GraphPersonLooksLikeSpouseOf(ByVal spouseId As String, ByVal bloodlineId As String) As Boolean
    Dim rowNo As Long, relText As String, baseId As String
    spouseId = CleanText(spouseId)
    bloodlineId = CleanText(bloodlineId)
    If Len(spouseId) = 0 Or Len(bloodlineId) = 0 Then Exit Function
    If Not gPersonRows.Exists(spouseId) Then Exit Function
    rowNo = CLng(gPersonRows(spouseId))
    relText = GraphPersonRawRelationByRow(rowNo)
    baseId = CleanText(ThisWorkbook.Worksheets(SH_W_PERSON).Cells(rowNo, P_SUR_SRC).Value)
    If baseId = bloodlineId And GraphRelationLooksLikeSpouse(relText) Then
        GraphPersonLooksLikeSpouseOf = True
    ElseIf GraphRelationLooksLikeSpouse(relText) Then
        GraphPersonLooksLikeSpouseOf = True
    End If
End Function

Private Function GraphBloodlinePriority(ByVal personId As String) As Long
    Dim relText As String, lv As Long
    personId = CleanText(personId)
    If Len(personId) = 0 Then Exit Function
    If personId = gDecedentId Then GraphBloodlinePriority = 1000: Exit Function
    relText = GraphBaseRelationLabel(GraphPersonRawRelationById(personId))
    If relText = "��" Or relText = "��" Then GraphBloodlinePriority = 900: Exit Function
    lv = GraphDescendantLevelText(relText)
    If lv > 0 Then GraphBloodlinePriority = 800 - lv: Exit Function
    If GraphIsDirectChildLabel(relText) Then GraphBloodlinePriority = 820: Exit Function
End Function

Private Sub GraphMarkPureSpouse(ByVal spouseId As String, ByVal bloodlineId As String, ByVal reasonText As String)
    spouseId = CleanText(spouseId)
    bloodlineId = CleanText(bloodlineId)
    If Len(spouseId) = 0 Or Len(bloodlineId) = 0 Then Exit Sub
    If spouseId = bloodlineId Then Exit Sub
    If Not gPersonRows.Exists(spouseId) Or Not gPersonRows.Exists(bloodlineId) Then Exit Sub
    If Not gPureSpouse.Exists(spouseId) Then
        gPureSpouse.Add spouseId, True
        gSpouseBloodlineById.Add spouseId, bloodlineId
    Else
        gSpouseBloodlineById(spouseId) = bloodlineId
    End If
End Sub

Private Sub GraphLoadExplicitParentChildEdges()
    Dim wr As Worksheet, r As Long, a As String, b As String, parentId As String, childId As String
    If Not SheetExists(SH_W_REL, ThisWorkbook) Then Exit Sub
    Set wr = ThisWorkbook.Worksheets(SH_W_REL)
    For r = 2 To LastRow(wr, R_ID)
        If CleanText(wr.Cells(r, R_STATUS).Value) <> STATUS_CANCEL Then
            If CleanText(wr.Cells(r, R_TYPE).Value) = "�e�q" Then
                a = CleanText(wr.Cells(r, R_BASE_ID).Value)
                b = CleanText(wr.Cells(r, R_OTHER_ID).Value)
                If GraphResolveParentChildDirection(a, b, parentId, childId) Then
                    GraphAddCandidateParent childId, parentId, 900, "W_�֌W:�e�q"
                End If
            End If
        End If
    Next r
End Sub

Private Function GraphResolveParentChildDirection(ByVal baseId As String, ByVal otherId As String, ByRef parentId As String, ByRef childId As String) As Boolean
    Dim baseLevel As Long, otherLevel As Long
    Dim basePure As Boolean, otherPure As Boolean
    baseId = CleanText(baseId)
    otherId = CleanText(otherId)
    If Len(baseId) = 0 Or Len(otherId) = 0 Then Exit Function
    If baseId = otherId Then Exit Function
    If Not gPersonRows.Exists(baseId) Or Not gPersonRows.Exists(otherId) Then Exit Function

    basePure = DiagramGraphIsPureSpouseId(baseId)
    otherPure = DiagramGraphIsPureSpouseId(otherId)

    '�z��҂�e���Ƃ���e�q�s�́A�������x���ŋt�������肵�Ȃ��B
    '��: ���̔z��ҁ��q �́AGraphAddCandidateParent �ō������ԓ��o���Ȃ� �����]�� �ɐ��K������B
    If basePure And Not otherPure Then
        parentId = baseId: childId = otherId: GraphResolveParentChildDirection = True: Exit Function
    End If
    If otherPure And Not basePure Then
        parentId = otherId: childId = baseId: GraphResolveParentChildDirection = True: Exit Function
    End If

    baseLevel = GraphEffectiveDescendantLevelById(baseId)
    otherLevel = GraphEffectiveDescendantLevelById(otherId)

    If baseId = gDecedentId And otherLevel = 1 Then
        parentId = baseId: childId = otherId: GraphResolveParentChildDirection = True: Exit Function
    End If
    If otherId = gDecedentId And GraphIsParentRelationById(baseId) Then
        parentId = baseId: childId = otherId: GraphResolveParentChildDirection = True: Exit Function
    End If
    If baseLevel > 0 And otherLevel = baseLevel + 1 Then
        parentId = baseId: childId = otherId: GraphResolveParentChildDirection = True: Exit Function
    End If
    If otherLevel > 0 And baseLevel = otherLevel + 1 Then
        parentId = otherId: childId = baseId: GraphResolveParentChildDirection = True: Exit Function
    End If

    '�������m��ł��Ȃ����f�[�^�́A���͎d�l�ǂ��� R_BASE_ID=�e / R_OTHER_ID=�q �Ƃ��ċ~�ς���B
    parentId = baseId
    childId = otherId
    GraphResolveParentChildDirection = True
End Function

Private Function GraphEffectiveDescendantLevelById(ByVal personId As String) As Long
    Dim bloodId As String
    personId = CleanText(personId)
    If Len(personId) = 0 Then Exit Function
    If DiagramGraphIsPureSpouseId(personId) Then
        If Not gSpouseBloodlineById Is Nothing Then
            If gSpouseBloodlineById.Exists(personId) Then
                bloodId = CleanText(gSpouseBloodlineById(personId))
                If Len(bloodId) > 0 Then
                    GraphEffectiveDescendantLevelById = GraphDescendantLevelById(bloodId)
                    Exit Function
                End If
            End If
        End If
    End If
    GraphEffectiveDescendantLevelById = GraphDescendantLevelById(personId)
End Function

Private Sub GraphLoadBasePersonParentChildEdges()
    Dim wp As Worksheet, pid As Variant, rowNo As Long, baseId As String, relText As String
    Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)
    For Each pid In gPersonRows.Keys
        If CStr(pid) <> gDecedentId Then
            rowNo = CLng(gPersonRows(CStr(pid)))
            baseId = CleanText(wp.Cells(rowNo, P_SUR_SRC).Value)
            relText = GraphPersonRawRelationByRow(rowNo)
            If Len(baseId) > 0 And gPersonRows.Exists(baseId) Then
                If Not DiagramGraphIsPureSpouseId(CStr(pid)) Then
                    If Not GraphPersonShouldStayOther(CStr(pid)) Then
                        If GraphRelationLooksLikeChild(relText) Or GraphDescendantLevelText(relText) > 0 Or DiagramGraphIsPureSpouseId(baseId) Then
                            GraphAddCandidateParent CStr(pid), baseId, 620, "�o�^����l��ID"
                        End If
                    End If
                End If
            End If
        End If
    Next pid
End Sub

Private Sub GraphLoadRelationLabelFallbackEdges()
    Dim pid As Variant, relText As String, lv As Long, parentId As String
    For Each pid In gPersonRows.Keys
        If Not gParentByChild.Exists(CStr(pid)) Then
            If Not GraphChildParentFallbackBlocked(CStr(pid)) Then
            If Not DiagramGraphIsPureSpouseId(CStr(pid)) Then
                relText = GraphPersonRawRelationById(CStr(pid))
                lv = GraphDescendantLevelText(relText)
                If GraphPersonShouldStayOther(CStr(pid)) Then
                    '���ҁE���ҁE�㗝�l���́A��l��ID��B���ȑ�������e�q���֍��������Ȃ��B
                ElseIf lv = 1 Then
                    GraphAddCandidateParent CStr(pid), gDecedentId, 260, "����:���q"
                ElseIf lv > 1 Then
                    parentId = GraphUniqueBloodlineAtLevel(lv - 1)
                    If Len(parentId) > 0 Then GraphAddCandidateParent CStr(pid), parentId, 210, "����:���㐢����"
                End If
            End If
            End If
        End If
    Next pid
End Sub

Private Sub GraphResolveParentSpouseFacts()
    Dim fatherId As String, motherId As String, pid As Variant, bloodId As String, relText As String
    fatherId = vbNullString
    motherId = vbNullString
    For Each pid In gPersonRows.Keys
        relText = GraphBaseRelationLabel(GraphPersonRawRelationById(CStr(pid)))
        If relText = "��" Then fatherId = CStr(pid)
        If relText = "��" Then motherId = CStr(pid)
    Next pid

    For Each pid In gPersonRows.Keys
        If DiagramGraphIsPureSpouseId(CStr(pid)) Then
            bloodId = CleanText(gSpouseBloodlineById(CStr(pid)))
            If Len(bloodId) > 0 Then
                If bloodId = fatherId Then
                    motherId = CStr(pid)
                    GraphAddCandidateParent gDecedentId, CStr(pid), 940, "���̔z���=��"
                    GraphAddCandidateParent gDecedentId, fatherId, 940, "��"
                ElseIf bloodId = motherId Then
                    fatherId = CStr(pid)
                    GraphAddCandidateParent gDecedentId, CStr(pid), 940, "��̔z���=��"
                    GraphAddCandidateParent gDecedentId, motherId, 940, "��"
                End If
            End If
        End If
    Next pid
End Sub

Private Sub GraphResolveUniqueGenerationFallbacks()
    Dim pid As Variant, lv As Long, parentId As String
    For Each pid In gPersonRows.Keys
        If Not gParentByChild.Exists(CStr(pid)) Then
            If Not GraphChildParentFallbackBlocked(CStr(pid)) Then
            If Not DiagramGraphIsPureSpouseId(CStr(pid)) Then
                If GraphPersonShouldStayOther(CStr(pid)) Then
                    '���̑��֌W�l�͒��㐢���ӕ⊮�̑Ώۂɂ��Ȃ��B
                Else
                    lv = GraphDescendantLevelById(CStr(pid))
                    If lv > 1 Then
                        parentId = GraphUniqueBloodlineAtLevel(lv - 1)
                        If Len(parentId) > 0 Then GraphAddCandidateParent CStr(pid), parentId, 180, "���㐢���ӕ⊮"
                    End If
                End If
            End If
            End If
        End If
    Next pid
End Sub

Private Function GraphUniqueBloodlineAtLevel(ByVal levelNo As Long) As String
    Dim pid As Variant, hit As String
    For Each pid In gPersonRows.Keys
        If Not DiagramGraphIsPureSpouseId(CStr(pid)) Then
            If GraphResolvedLevelForId(CStr(pid), 0) = levelNo Then
                If Len(hit) > 0 Then Exit Function
                hit = CStr(pid)
            End If
        End If
    Next pid
    GraphUniqueBloodlineAtLevel = hit
End Function

Private Sub GraphAddCandidateParent(ByVal childId As String, ByVal candidateParentId As String, ByVal score As Long, ByVal sourceText As String)
    Dim parentId As String, existingScore As Long, spouseId As String
    childId = CleanText(childId)
    candidateParentId = CleanText(candidateParentId)
    If Len(childId) = 0 Or Len(candidateParentId) = 0 Then Exit Sub
    If childId = candidateParentId Then Exit Sub
    If Not gPersonRows.Exists(childId) Or Not gPersonRows.Exists(candidateParentId) Then Exit Sub
    If DiagramGraphIsPureSpouseId(childId) Then Exit Sub
    If GraphPersonShouldStayOther(childId) Then Exit Sub
    If GraphPersonShouldStayOther(candidateParentId) Then Exit Sub

    parentId = candidateParentId
    If DiagramGraphIsPureSpouseId(candidateParentId) Then
        spouseId = CleanText(gSpouseBloodlineById(candidateParentId))
        If Len(spouseId) > 0 Then
            If GraphCoupleAllowsChild(spouseId, candidateParentId, childId) Then
                parentId = spouseId
                score = score + 220
                gCoupleChildByChild(childId) = GraphPairKey(spouseId, candidateParentId)
                sourceText = sourceText & "+�v�w���ԓ��o��"
            Else
                '��l�����z��ґ��ŁA�������ԓ��o���Ɗm�F�ł��Ȃ��ꍇ�͕v�w�������֍����Ȃ��B
                '���͏�͊�l���̎q�Ȃ̂ŁA�z��҃J�[�h�N�_�̎q�Ƃ��Ė�������B
                sourceText = sourceText & "+�z��ґ��q/�v�w�q���m��"
                GraphBlockParentFallback childId, "�v�w�q���m��"
                GraphAddWarning "�v�w�q���m��:" & childId, GraphPersonNameById(childId) & " �� " & GraphPersonNameById(candidateParentId) & " ���̎q���ł��B�������E�o���N�����E����������v�w�̎q�Ɗm��ł��Ȃ����߁A�v�w�������ł͂Ȃ��z��҃J�[�h�N�_�ŕ\�����܂��B"
            End If
        End If
    Else
        spouseId = DiagramGraphSpouseId(candidateParentId)
        If Len(spouseId) > 0 Then
            If GraphCoupleAllowsChild(candidateParentId, spouseId, childId) Then
                gCoupleChildByChild(childId) = GraphPairKey(candidateParentId, spouseId)
            End If
        End If
    End If

    If gParentScoreByChild.Exists(childId) Then
        existingScore = CLng(gParentScoreByChild(childId))
        If score < existingScore Then Exit Sub
        If score = existingScore Then
            If GraphParentSourcePriority(sourceText) <= GraphParentSourcePriority(CleanText(gParentSourceByChild(childId))) Then Exit Sub
        End If
    End If
    gParentByChild(childId) = parentId
    gParentScoreByChild(childId) = score
    gParentSourceByChild(childId) = sourceText
End Sub

Private Sub GraphBlockParentFallback(ByVal childId As String, ByVal reasonText As String)
    childId = CleanText(childId)
    reasonText = CleanText(reasonText)
    If Len(childId) = 0 Then Exit Sub
    If gBlockedParentFallbackByChild Is Nothing Then Exit Sub
    If Len(reasonText) = 0 Then reasonText = "�v�w�q���薢�m��"
    If gBlockedParentFallbackByChild.Exists(childId) Then
        gBlockedParentFallbackByChild(childId) = reasonText
    Else
        gBlockedParentFallbackByChild.Add childId, reasonText
    End If
End Sub

Private Function GraphChildParentFallbackBlocked(ByVal childId As String) As Boolean
    childId = CleanText(childId)
    If Len(childId) = 0 Then Exit Function
    If gBlockedParentFallbackByChild Is Nothing Then Exit Function
    GraphChildParentFallbackBlocked = gBlockedParentFallbackByChild.Exists(childId)
End Function

Private Function GraphBlockedParentReason(ByVal childId As String) As String
    childId = CleanText(childId)
    If Len(childId) = 0 Then Exit Function
    If gBlockedParentFallbackByChild Is Nothing Then Exit Function
    If gBlockedParentFallbackByChild.Exists(childId) Then GraphBlockedParentReason = CleanText(gBlockedParentFallbackByChild(childId))
End Function

Private Function GraphParentSourcePriority(ByVal sourceText As String) As Long
    sourceText = CleanText(sourceText)
    If InStr(1, sourceText, "�v�w���ԓ��o��", vbTextCompare) > 0 Then GraphParentSourcePriority = 600: Exit Function
    If InStr(1, sourceText, "W_�֌W:�e�q", vbTextCompare) > 0 Then GraphParentSourcePriority = 500: Exit Function
    If InStr(1, sourceText, "���̔z���=��", vbTextCompare) > 0 Or InStr(1, sourceText, "��̔z���=��", vbTextCompare) > 0 Then GraphParentSourcePriority = 450: Exit Function
    If InStr(1, sourceText, "�o�^����l��ID", vbTextCompare) > 0 Then GraphParentSourcePriority = 300: Exit Function
    If InStr(1, sourceText, "����", vbTextCompare) > 0 Then GraphParentSourcePriority = 200: Exit Function
    If InStr(1, sourceText, "���㐢��", vbTextCompare) > 0 Then GraphParentSourcePriority = 100: Exit Function
End Function

Private Function GraphCoupleAllowsChild(ByVal leftId As String, ByVal rightId As String, ByVal childId As String) As Boolean
    Dim key As String, birthValue As Variant, marriageDate As Variant, divorceDate As Variant, rowNo As Long
    If Len(leftId) = 0 Or Len(rightId) = 0 Or Len(childId) = 0 Then Exit Function
    If Not gPersonRows.Exists(childId) Then Exit Function
    If GraphChildHasSeparateParentNote(childId) Then Exit Function
    key = GraphPairKey(leftId, rightId)
    If Len(key) = 0 Then Exit Function
    If Not gCoupleMarriage.Exists(key) Then Exit Function
    rowNo = CLng(gPersonRows(childId))
    birthValue = ThisWorkbook.Worksheets(SH_W_PERSON).Cells(rowNo, P_BIRTH).Value
    marriageDate = gCoupleMarriage(key)
    divorceDate = gCoupleDivorce(key)
    If Not GraphDateToSerialOk(birthValue) Then Exit Function
    If GraphMarriageHistoryPairCoversChild(leftId, rightId, childId, birthValue) Then
        GraphCoupleAllowsChild = True
        Exit Function
    End If
    If Not GraphDateToSerialOk(marriageDate) Then Exit Function
    If GraphDateSerial(birthValue) < GraphDateSerial(marriageDate) Then Exit Function
    If GraphDateToSerialOk(divorceDate) Then
        If GraphDateSerial(birthValue) > GraphDateSerial(divorceDate) Then Exit Function
    End If
    GraphCoupleAllowsChild = True
End Function

Private Function GraphChildHasSeparateParentNote(ByVal childId As String) As Boolean
    Dim rowNo As Long, s As String, wp As Worksheet
    If Not gPersonRows.Exists(childId) Then Exit Function
    Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)
    rowNo = CLng(gPersonRows(childId))
    s = CleanText(wp.Cells(rowNo, P_REL_DEC).Value) & " " & CleanText(wp.Cells(rowNo, P_REL_DISP).Value) & " " & CleanText(wp.Cells(rowNo, P_NOTE).Value)
    GraphChildHasSeparateParentNote = (InStr(s, "�O�z���") > 0 Or InStr(s, "�O��") > 0 Or InStr(s, "�O�v") > 0 Or InStr(s, "�ʕ�") > 0 Or InStr(s, "�ʕ�") > 0 Or InStr(s, "�A��q") > 0)
End Function

Private Sub GraphRebuildChildrenIndex()
    Dim childId As Variant, parentId As String, key As String, col As Collection
    Set gChildrenByParent = CreateObject("Scripting.Dictionary")
    Set gChildEdgeKeys = CreateObject("Scripting.Dictionary")
    For Each childId In gParentByChild.Keys
        parentId = CleanText(gParentByChild(CStr(childId)))
        If Len(parentId) > 0 And gPersonRows.Exists(parentId) Then
            key = parentId & "|" & CStr(childId)
            If Not gChildEdgeKeys.Exists(key) Then
                If Not gChildrenByParent.Exists(parentId) Then
                    Set col = New Collection
                    gChildrenByParent.Add parentId, col
                End If
                gChildrenByParent(parentId).Add CLng(gPersonRows(CStr(childId)))
                gChildEdgeKeys.Add key, True
            End If
        End If
    Next childId
End Sub

Private Sub GraphBuildDisplayRelations()
    Dim pid As Variant, i As Long, changed As Boolean, parentId As String, parentLabel As String, labelText As String
    Dim childId As Variant, rowNo As Long, fallbackText As String

    If Len(gDecedentId) > 0 Then gDisplayRelById(gDecedentId) = "�푊���l"

    For Each pid In gPersonRows.Keys
        fallbackText = GraphBaseRelationLabel(GraphPersonRawRelationById(CStr(pid)))
        If DiagramGraphIsPureSpouseId(CStr(pid)) Then
            gDisplayRelById(CStr(pid)) = GraphSpouseDisplayLabel(CStr(pid))
        ElseIf fallbackText = "��" Or fallbackText = "��" Then
            gDisplayRelById(CStr(pid)) = fallbackText
        ElseIf CStr(pid) <> gDecedentId And Len(fallbackText) > 0 Then
            If GraphDescendantLevelText(fallbackText) = 0 Then gDisplayRelById(CStr(pid)) = fallbackText
        End If
    Next pid

    For i = 1 To 12
        changed = False
        For Each childId In gParentByChild.Keys
            If Not DiagramGraphIsPureSpouseId(CStr(childId)) Then
                parentId = CleanText(gParentByChild(CStr(childId)))
                parentLabel = DiagramGraphDisplayRelation(parentId, GraphPersonRawRelationById(parentId))
                If Len(parentLabel) > 0 Then
                    rowNo = CLng(gPersonRows(CStr(childId)))
                    fallbackText = GraphBaseRelationLabel(GraphPersonRawRelationByRow(rowNo))
                    If DiagramGraphIsPureSpouseId(parentId) Then
                        labelText = parentLabel & "�̎q"
                    Else
                        labelText = GraphChildDisplayLabelFromParentLabel(parentLabel, fallbackText)
                    End If
                    If Len(labelText) > 0 Then
                        If Not gDisplayRelById.Exists(CStr(childId)) Then
                            gDisplayRelById.Add CStr(childId), labelText
                            changed = True
                        ElseIf gDisplayRelById(CStr(childId)) <> labelText Then
                            If GraphDescendantLevelText(labelText) > 0 Then
                                gDisplayRelById(CStr(childId)) = labelText
                                changed = True
                            End If
                        End If
                    End If
                End If
            End If
        Next childId
        If Not changed Then Exit For
    Next i

    For Each pid In gPersonRows.Keys
        If DiagramGraphIsPureSpouseId(CStr(pid)) Then
            gDisplayRelById(CStr(pid)) = GraphSpouseDisplayLabel(CStr(pid))
        ElseIf Not gDisplayRelById.Exists(CStr(pid)) Then
            gDisplayRelById.Add CStr(pid), GraphBaseRelationLabel(GraphPersonRawRelationById(CStr(pid)))
        End If
    Next pid
End Sub

Private Function GraphChildDisplayLabelFromParentLabel(ByVal parentLabel As String, ByVal fallbackText As String) As String
    Dim parentLevel As Long, childFallback As String
    parentLabel = GraphBaseRelationLabel(parentLabel)
    childFallback = GraphBaseRelationLabel(fallbackText)
    If InStr(1, parentLabel, "�z���", vbTextCompare) > 0 Then
        GraphChildDisplayLabelFromParentLabel = parentLabel & "�̎q"
    ElseIf parentLabel = "�푊���l" Then
        If GraphIsDirectChildLabel(childFallback) Then
            GraphChildDisplayLabelFromParentLabel = childFallback
        Else
            GraphChildDisplayLabelFromParentLabel = "�q"
        End If
    ElseIf parentLabel = "��" Or parentLabel = "��" Then
        GraphChildDisplayLabelFromParentLabel = "�푊���l"
    Else
        parentLevel = GraphDescendantLevelText(parentLabel)
        Select Case parentLevel
            Case 1: GraphChildDisplayLabelFromParentLabel = "��"
            Case 2: GraphChildDisplayLabelFromParentLabel = "�]��"
            Case 3: GraphChildDisplayLabelFromParentLabel = "����"
            Case Else
                If Len(childFallback) > 0 Then GraphChildDisplayLabelFromParentLabel = childFallback
        End Select
    End If
End Function

Private Function GraphSpouseDisplayLabel(ByVal spouseId As String) As String
    Dim bloodId As String, baseLabel As String
    bloodId = vbNullString
    If gSpouseBloodlineById.Exists(spouseId) Then bloodId = CleanText(gSpouseBloodlineById(spouseId))
    baseLabel = DiagramGraphDisplayRelation(bloodId, GraphPersonRawRelationById(bloodId))
    baseLabel = GraphBaseRelationLabel(baseLabel)
    Select Case baseLabel
        Case "��": GraphSpouseDisplayLabel = "��"
        Case "��": GraphSpouseDisplayLabel = "��"
        Case "�푊���l": GraphSpouseDisplayLabel = "�z���"
        Case "": GraphSpouseDisplayLabel = "�z���"
        Case Else: GraphSpouseDisplayLabel = baseLabel & "�̔z���"
    End Select
End Function

Public Function DiagramGraphChildRows(ByVal parentId As String) As Collection
    Dim col As New Collection
    parentId = CleanText(parentId)
    If gBuilt Then
        If Not gChildrenByParent Is Nothing Then
            GraphAppendChildRowsForParent col, parentId
            GraphAppendChildRowsForAllSpouses col, parentId
        End If
    End If
    Set DiagramGraphChildRows = col
End Function

Private Sub GraphAppendChildRowsForAllSpouses(ByVal col As Collection, ByVal parentId As String)
    Dim spouses As Collection, i As Long, spouseId As String
    Dim src As Collection, j As Long, rowNo As Long, childId As String
    parentId = CleanText(parentId)
    If Len(parentId) = 0 Then Exit Sub
    If gAllSpousesByPerson Is Nothing Then Exit Sub
    If gChildrenByParent Is Nothing Then Exit Sub
    If Not gAllSpousesByPerson.Exists(parentId) Then Exit Sub
    Set spouses = gAllSpousesByPerson(parentId)
    For i = 1 To spouses.Count
        spouseId = CleanText(CStr(spouses(i)))
        If Len(spouseId) > 0 Then
            If gChildrenByParent.Exists(spouseId) Then
                Set src = gChildrenByParent(spouseId)
                For j = 1 To src.Count
                    rowNo = CLng(src(j))
                    childId = CleanText(ThisWorkbook.Worksheets(SH_W_PERSON).Cells(rowNo, P_ID).Value)
                    If DiagramGraphChildUsesCoupleOrigin(childId, parentId, spouseId) _
                            Or DiagramGraphParentIdForChildId(childId) = spouseId Then
                        GraphAppendSingleChildRow col, rowNo
                    End If
                Next j
            End If
        End If
    Next i
End Sub

Private Sub GraphAppendSingleChildRow(ByVal col As Collection, ByVal rowNo As Long)
    Dim i As Long, pid As String, existingId As String
    If col Is Nothing Then Exit Sub
    If rowNo <= 0 Then Exit Sub
    pid = CleanText(ThisWorkbook.Worksheets(SH_W_PERSON).Cells(rowNo, P_ID).Value)
    If Len(pid) = 0 Then Exit Sub
    For i = 1 To col.Count
        existingId = CleanText(ThisWorkbook.Worksheets(SH_W_PERSON).Cells(CLng(col(i)), P_ID).Value)
        If existingId = pid Then Exit Sub
    Next i
    col.Add rowNo
End Sub

Private Sub GraphAppendChildRowsForParent(ByVal col As Collection, ByVal parentId As String)
    Dim src As Collection, i As Long, rowNo As Long
    If col Is Nothing Then Exit Sub
    parentId = CleanText(parentId)
    If Len(parentId) = 0 Then Exit Sub
    If gChildrenByParent Is Nothing Then Exit Sub
    If Not gChildrenByParent.Exists(parentId) Then Exit Sub
    Set src = gChildrenByParent(parentId)
    For i = 1 To src.Count
        rowNo = CLng(src(i))
        GraphAppendSingleChildRow col, rowNo
    Next i
End Sub

Public Function DiagramGraphParentIdForChildId(ByVal childId As String) As String
    childId = CleanText(childId)
    If gBuilt Then
        If gParentByChild.Exists(childId) Then DiagramGraphParentIdForChildId = CleanText(gParentByChild(childId))
    End If
End Function

Public Function DiagramGraphParentIdForChildRow(ByVal childRow As Long) As String
    Dim pid As String
    If childRow <= 0 Then Exit Function
    pid = CleanText(ThisWorkbook.Worksheets(SH_W_PERSON).Cells(childRow, P_ID).Value)
    DiagramGraphParentIdForChildRow = DiagramGraphParentIdForChildId(pid)
End Function

Public Function DiagramGraphSpouseId(ByVal personId As String) As String
    personId = CleanText(personId)
    If Not gSpouseByPerson Is Nothing Then
        If gSpouseByPerson.Exists(personId) Then DiagramGraphSpouseId = CleanText(gSpouseByPerson(personId))
    End If
End Function

Public Function DiagramGraphSpouseRow(ByVal personId As String) As Long
    Dim spouseId As String
    If Not gBuilt Then Exit Function
    spouseId = DiagramGraphSpouseId(personId)
    If Len(spouseId) > 0 Then
        If gPersonRows.Exists(spouseId) Then DiagramGraphSpouseRow = CLng(gPersonRows(spouseId))
    End If
End Function

Private Function GraphParentChildRelationExists(ByVal parentId As String, ByVal childId As String) As Boolean
    Dim wr As Worksheet, r As Long, a As String, b As String, p As String, c As String
    parentId = CleanText(parentId)
    childId = CleanText(childId)
    If Len(parentId) = 0 Or Len(childId) = 0 Then Exit Function
    If Not SheetExists(SH_W_REL, ThisWorkbook) Then Exit Function
    Set wr = ThisWorkbook.Worksheets(SH_W_REL)
    For r = 2 To LastRow(wr, R_ID)
        If CleanText(wr.Cells(r, R_STATUS).Value) <> STATUS_CANCEL Then
            If CleanText(wr.Cells(r, R_TYPE).Value) = "�e�q" Then
                a = CleanText(wr.Cells(r, R_BASE_ID).Value)
                b = CleanText(wr.Cells(r, R_OTHER_ID).Value)
                If GraphResolveParentChildDirection(a, b, p, c) Then
                    If p = parentId And c = childId Then GraphParentChildRelationExists = True: Exit Function
                End If
            End If
        End If
    Next r
End Function

Public Function DiagramGraphFatherRow(ByVal decedentId As String) As Long
    Dim pid As Variant, relText As String
    If Not gBuilt Then Exit Function
    decedentId = CleanText(decedentId)
    For Each pid In gPersonRows.Keys
        relText = DiagramGraphDisplayRelation(CStr(pid), GraphPersonRawRelationById(CStr(pid)))
        rawRelText = GraphPersonRawRelationById(CStr(pid))
        If relText = "��" Then
            If DiagramGraphParentIdForChildId(decedentId) = CStr(pid) Or GraphParentChildRelationExists(CStr(pid), decedentId) Then
                DiagramGraphFatherRow = CLng(gPersonRows(CStr(pid)))
                Exit Function
            End If
        End If
    Next pid
    For Each pid In gPersonRows.Keys
        If DiagramGraphDisplayRelation(CStr(pid), GraphPersonRawRelationById(CStr(pid))) = "��" Then
            DiagramGraphFatherRow = CLng(gPersonRows(CStr(pid)))
            Exit Function
        End If
    Next pid
End Function

Public Function DiagramGraphMotherRow(ByVal decedentId As String) As Long
    Dim pid As Variant, relText As String
    If Not gBuilt Then Exit Function
    decedentId = CleanText(decedentId)
    For Each pid In gPersonRows.Keys
        relText = DiagramGraphDisplayRelation(CStr(pid), GraphPersonRawRelationById(CStr(pid)))
        If relText = "��" Then
            If DiagramGraphParentIdForChildId(decedentId) = CStr(pid) Or GraphParentChildRelationExists(CStr(pid), decedentId) Then
                DiagramGraphMotherRow = CLng(gPersonRows(CStr(pid)))
                Exit Function
            End If
        End If
    Next pid
    For Each pid In gPersonRows.Keys
        If DiagramGraphDisplayRelation(CStr(pid), GraphPersonRawRelationById(CStr(pid))) = "��" Then
            DiagramGraphMotherRow = CLng(gPersonRows(CStr(pid)))
            Exit Function
        End If
    Next pid
End Function

Public Function DiagramGraphDisplayRelation(ByVal personId As String, ByVal fallbackText As String) As String
    personId = CleanText(personId)
    If gBuilt Then
        If Not gDisplayRelById Is Nothing Then
            If gDisplayRelById.Exists(personId) Then
                DiagramGraphDisplayRelation = CleanText(gDisplayRelById(personId))
                Exit Function
            End If
        End If
    End If
    DiagramGraphDisplayRelation = GraphBaseRelationLabel(fallbackText)
End Function

Public Function DiagramGraphIsPureSpouseId(ByVal personId As String) As Boolean
    personId = CleanText(personId)
    If Not gPureSpouse Is Nothing Then
        If gPureSpouse.Exists(personId) Then DiagramGraphIsPureSpouseId = True
    End If
End Function

Public Function DiagramGraphIsUnresolvedKinId(ByVal personId As String) As Boolean
    Dim relText As String
    personId = CleanText(personId)
    If Len(personId) = 0 Then Exit Function
    If Not gBuilt Then Exit Function
    If Not gPersonRows.Exists(personId) Then Exit Function
    If personId = gDecedentId Then Exit Function
    If DiagramGraphIsPureSpouseId(personId) Then Exit Function
    If GraphPersonShouldStayOther(personId) Then Exit Function
    If GraphChildParentFallbackBlocked(personId) Then DiagramGraphIsUnresolvedKinId = True: Exit Function
    If gParentByChild.Exists(personId) Then Exit Function
    relText = DiagramGraphDisplayRelation(personId, GraphPersonRawRelationById(personId))
    If GraphDescendantLevelText(relText) > 0 Then DiagramGraphIsUnresolvedKinId = True
    If GraphBaseRelationLabel(relText) = "��" Or GraphBaseRelationLabel(relText) = "��" Then DiagramGraphIsUnresolvedKinId = True
End Function

Public Function DiagramGraphChildUsesCoupleOrigin(ByVal childId As String, ByVal parentId As String, ByVal spouseId As String) As Boolean
    Dim key As String, pairA As String, pairB As String
    childId = CleanText(childId)
    parentId = CleanText(parentId)
    spouseId = CleanText(spouseId)
    If Not gBuilt Then Exit Function
    If Len(childId) = 0 Or Len(parentId) = 0 Or Len(spouseId) = 0 Then Exit Function
    If Not gCoupleChildByChild.Exists(childId) Then Exit Function
    key = CleanText(gCoupleChildByChild(childId))
    If Len(key) = 0 Then Exit Function
    pairA = GraphPairKey(parentId, spouseId)
    pairB = GraphPairKey(spouseId, parentId)
    DiagramGraphChildUsesCoupleOrigin = (key = pairA Or key = pairB)
End Function

Public Function DiagramGraphChildIsSpouseSideUnconfirmed(ByVal childId As String) As Boolean
    childId = CleanText(childId)
    If Len(childId) = 0 Then Exit Function
    If Not gBuilt Then Exit Function
    DiagramGraphChildIsSpouseSideUnconfirmed = GraphChildParentFallbackBlocked(childId)
End Function

Public Function DiagramGraphUnconfirmedReason(ByVal childId As String) As String
    childId = CleanText(childId)
    If Len(childId) = 0 Then Exit Function
    If Not gBuilt Then Exit Function
    DiagramGraphUnconfirmedReason = GraphBlockedParentReason(childId)
End Function

Private Sub GraphValidateModel()
    Dim pid As Variant, relText As String, lv As Long, spouseCount As Long
    Dim parentId As String, sourceText As String, rawRelText As String
    If gPersonRows Is Nothing Then Exit Sub
    For Each pid In gPersonRows.Keys
        rawRelText = GraphPersonRawRelationById(CStr(pid))
        relText = DiagramGraphDisplayRelation(CStr(pid), rawRelText)
        lv = GraphDescendantLevelText(relText)
        If lv > 1 Then
            If Not gParentByChild.Exists(CStr(pid)) Then GraphAddWarning "�������e:" & CStr(pid), GraphPersonNameById(CStr(pid)) & " �� " & relText & " �ł����m��e������܂���B"
        End If
        If DiagramGraphIsPureSpouseId(CStr(pid)) Then
            If GraphDescendantLevelText(GraphBaseRelationLabel(GraphPersonRawRelationById(CStr(pid)))) > 0 Then
                GraphAddWarning "�z��ґ�������:" & CStr(pid), GraphPersonNameById(CStr(pid)) & " �͌��������q���n�ł����A�z��Ҋ֌W���� " & relText & " �Ƃ��Ĉ����܂��B"
            End If
        End If
        If GraphPersonShouldStayOther(CStr(pid)) Then
            If gParentByChild.Exists(CStr(pid)) Then GraphAddWarning "���̑��֌W�l�e�q����:" & CStr(pid), GraphPersonNameById(CStr(pid)) & " �͂��̑��֌W�l�ł����e�q���ɓ����Ă��܂��B���͊֌W���m�F���Ă��������B"
        End If
        If GraphChildParentFallbackBlocked(CStr(pid)) Then
            GraphAddWarning "�z��ґ��q�v�m�F:" & CStr(pid), GraphPersonNameById(CStr(pid)) & " �͕v�w�̎q�Ɗm��ł��Ȃ����߁A�v�w�������ł͂Ȃ��z��҃J�[�h�N�_�ň����܂��B"
        End If
        If gParentByChild.Exists(CStr(pid)) Then
            parentId = CleanText(gParentByChild(CStr(pid)))
            sourceText = vbNullString
            If gParentSourceByChild.Exists(CStr(pid)) Then sourceText = CleanText(gParentSourceByChild(CStr(pid)))
            If (GraphRelationLooksLikeSpouseChild(rawRelText) Or InStr(1, rawRelText, "�v�w�q���m��", vbTextCompare) > 0 Or InStr(1, rawRelText, "�������ԊO", vbTextCompare) > 0) _
                    And Not DiagramGraphIsPureSpouseId(parentId) _
                    And InStr(1, sourceText, "�v�w���ԓ��o��", vbTextCompare) = 0 Then
                GraphAddWarning "�v�w�q���m�茌����:" & CStr(pid), GraphPersonNameById(CStr(pid)) & " �͔z��ґ��̎q���ł����A�v�w���ԓ��o���̍����Ȃ��Ɍ������e�q�Ƃ��Ĉ����Ă��܂��B�������E�o���N�����E�֌W�s���m�F���Ă��������B"
            End If
        End If
        spouseCount = DiagramGraphSpouseCount(CStr(pid))
        If spouseCount > 1 Then
            GraphAddWarning "�����z���:" & CStr(pid), GraphPersonNameById(CStr(pid)) & " �ɕ����̔z��Ҋ֌W������܂��B�}�͑�\�z��҂𒆐S�ɕ`�悵�A�S�����͍��������m�F�Ŋm�F���Ă��������B"
        End If
    Next pid
End Sub

Public Function DiagramGraphSpouseCount(ByVal personId As String) As Long
    Dim col As Collection
    personId = CleanText(personId)
    If gAllSpousesByPerson Is Nothing Then Exit Function
    If gAllSpousesByPerson.Exists(personId) Then
        Set col = gAllSpousesByPerson(personId)
        DiagramGraphSpouseCount = col.Count
    End If
End Function

Private Function DiagramGraphSpouseIdsText(ByVal personId As String) As String
    Dim col As Collection, i As Long, s As String, sid As String
    personId = CleanText(personId)
    If gAllSpousesByPerson Is Nothing Then Exit Function
    If Not gAllSpousesByPerson.Exists(personId) Then Exit Function
    Set col = gAllSpousesByPerson(personId)
    For i = 1 To col.Count
        sid = CleanText(CStr(col(i)))
        If Len(sid) > 0 Then
            If Len(s) > 0 Then s = s & ", "
            s = s & sid
        End If
    Next i
    DiagramGraphSpouseIdsText = s
End Function

Public Sub DiagramGraphWriteDiagnostics(ByVal decedentId As String)
    On Error GoTo EH
    Dim ws As Worksheet, outR As Long, pid As Variant, rowNo As Long, parentId As String, spouseId As String, childKey As String
    If Not gBuilt Then Exit Sub
    If Not SheetExists(SH_CHECK, ThisWorkbook) Then Exit Sub
    Set ws = ThisWorkbook.Worksheets(SH_CHECK)
    DiagramGraphClearPriorDiagnostics ws
    outR = LastRow(ws, 1) + 2
    If outR < 2 Then outR = 2
    ws.Cells(outR, 1).Value = "�����֌W�}���f���f�f"
    ws.Cells(outR, 2).Value = Now
    outR = outR + 1
    ws.Cells(outR, 1).Value = "�l��ID"
    ws.Cells(outR, 2).Value = "����"
    ws.Cells(outR, 3).Value = "������"
    ws.Cells(outR, 4).Value = "�}�㑱��"
    ws.Cells(outR, 5).Value = "��l��ID"
    ws.Cells(outR, 6).Value = "�m��eID"
    ws.Cells(outR, 7).Value = "�m��e��"
    ws.Cells(outR, 8).Value = "�z���ID"
    ws.Cells(outR, 9).Value = "�z��Җ�"
    ws.Cells(outR, 10).Value = "�v�w�̎q"
    ws.Cells(outR, 11).Value = "����"
    ws.Cells(outR, 12).Value = "���N����"
    ws.Cells(outR, 13).Value = "������"
    ws.Cells(outR, 14).Value = "������"
    ws.Cells(outR, 15).Value = "�z��Ґ�"
    ws.Cells(outR, 16).Value = "�S�z���ID"
    ws.Cells(outR, 17).Value = "���N�_"
    ws.Cells(outR, 18).Value = "�m�F���b�Z�[�W"
    outR = outR + 1
    For Each pid In gPersonRows.Keys
        rowNo = CLng(gPersonRows(CStr(pid)))
        parentId = DiagramGraphParentIdForChildId(CStr(pid))
        spouseId = DiagramGraphSpouseId(CStr(pid))
        childKey = vbNullString
        If gCoupleChildByChild.Exists(CStr(pid)) Then childKey = CleanText(gCoupleChildByChild(CStr(pid)))
        ws.Cells(outR, 1).Value = CStr(pid)
        ws.Cells(outR, 2).Value = GraphPersonNameById(CStr(pid))
        ws.Cells(outR, 3).Value = GraphPersonRawRelationById(CStr(pid))
        ws.Cells(outR, 4).Value = DiagramGraphDisplayRelation(CStr(pid), GraphPersonRawRelationById(CStr(pid)))
        ws.Cells(outR, 5).Value = CleanText(ThisWorkbook.Worksheets(SH_W_PERSON).Cells(rowNo, P_SUR_SRC).Value)
        ws.Cells(outR, 6).Value = parentId
        ws.Cells(outR, 7).Value = GraphPersonNameById(parentId)
        ws.Cells(outR, 8).Value = spouseId
        ws.Cells(outR, 9).Value = GraphPersonNameById(spouseId)
        If Len(childKey) > 0 Then ws.Cells(outR, 10).Value = "�͂�: " & childKey
        If gParentSourceByChild.Exists(CStr(pid)) Then
            ws.Cells(outR, 11).Value = CleanText(gParentSourceByChild(CStr(pid)))
        ElseIf GraphChildParentFallbackBlocked(CStr(pid)) Then
            ws.Cells(outR, 11).Value = "�v�w�q���m��"
        End If
        ws.Cells(outR, 12).Value = ThisWorkbook.Worksheets(SH_W_PERSON).Cells(rowNo, P_BIRTH).Value
        If Len(spouseId) > 0 Then
            ws.Cells(outR, 13).Value = gCoupleMarriage(GraphPairKey(CStr(pid), spouseId))
            ws.Cells(outR, 14).Value = gCoupleDivorce(GraphPairKey(CStr(pid), spouseId))
        End If
        ws.Cells(outR, 15).Value = DiagramGraphSpouseCount(CStr(pid))
        ws.Cells(outR, 16).Value = DiagramGraphSpouseIdsText(CStr(pid))
        If Len(childKey) > 0 Then
            ws.Cells(outR, 17).Value = "�v�w����"
        ElseIf Len(parentId) > 0 Then
            ws.Cells(outR, 17).Value = "�e�J�[�h"
        ElseIf GraphPersonShouldStayOther(CStr(pid)) Then
            ws.Cells(outR, 17).Value = "���̑��֌W�l"
        ElseIf GraphDescendantLevelText(DiagramGraphDisplayRelation(CStr(pid), GraphPersonRawRelationById(CStr(pid)))) > 0 Then
            ws.Cells(outR, 17).Value = "�֌W������"
        End If
        ws.Cells(outR, 18).Value = DiagramGraphHumanMessage(CStr(pid), parentId, spouseId, childKey)
        outR = outR + 1
    Next pid
    ws.Columns("A:R").AutoFit
    DiagramGraphWriteWarningDiagnostics ws, outR + 1
    Exit Sub
EH:
    Err.Clear
End Sub

Private Sub DiagramGraphWriteWarningDiagnostics(ByVal ws As Worksheet, ByVal startRow As Long)
    Dim key As Variant, r As Long
    If ws Is Nothing Then Exit Sub
    If gGraphWarnings Is Nothing Then Exit Sub
    If gGraphWarnings.Count = 0 Then Exit Sub
    r = startRow
    If r < 2 Then r = 2
    ws.Cells(r, 1).Value = "�����֌W�}���f���x��"
    r = r + 1
    ws.Cells(r, 1).Value = "�L�["
    ws.Cells(r, 2).Value = "���e"
    r = r + 1
    For Each key In gGraphWarnings.Keys
        ws.Cells(r, 1).Value = CStr(key)
        ws.Cells(r, 2).Value = CleanText(gGraphWarnings(CStr(key)))
        r = r + 1
    Next key
End Sub

Private Sub DiagramGraphClearPriorDiagnostics(ByVal ws As Worksheet)
    Dim r As Long, firstR As Long, lastR As Long
    If ws Is Nothing Then Exit Sub
    lastR = Application.Max(LastRow(ws, 1), LastRow(ws, 18))
    For r = 1 To lastR
        If CleanText(ws.Cells(r, 1).Value) = "�����֌W�}���f���f�f" Or CleanText(ws.Cells(r, 1).Value) = "�����֌W�}���f���x��" Then
            firstR = r
            Exit For
        End If
    Next r
    If firstR > 0 Then
        ws.Range(ws.Rows(firstR), ws.Rows(lastR)).Delete
    Else
        ws.Range("I4:R" & CStr(Application.Max(4, lastR))).ClearContents
    End If
End Sub

Private Function GraphPersonNameById(ByVal personId As String) As String
    Dim rowNo As Long, wp As Worksheet
    personId = CleanText(personId)
    If Len(personId) = 0 Then Exit Function
    If gPersonRows Is Nothing Then Exit Function
    If Not gPersonRows.Exists(personId) Then Exit Function
    Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)
    rowNo = CLng(gPersonRows(personId))
    GraphPersonNameById = CleanText(wp.Cells(rowNo, P_DISPLAY).Value)
    If Len(GraphPersonNameById) = 0 Then GraphPersonNameById = CleanText(CStr(wp.Cells(rowNo, P_SURNAME).Value) & " " & CStr(wp.Cells(rowNo, P_GIVEN).Value))
End Function

Private Function GraphSpouseRelationExists(ByVal personA As String, ByVal personB As String) As Boolean
    Dim key As String
    key = GraphPairKey(personA, personB)
    If Len(key) = 0 Then Exit Function
    If Not gCoupleMarriage Is Nothing Then GraphSpouseRelationExists = gCoupleMarriage.Exists(key)
End Function

Private Function GraphPersonRawRelationById(ByVal personId As String) As String
    If Len(personId) = 0 Then Exit Function
    If gPersonRows Is Nothing Then Exit Function
    If Not gPersonRows.Exists(personId) Then Exit Function
    GraphPersonRawRelationById = GraphPersonRawRelationByRow(CLng(gPersonRows(personId)))
End Function

Private Function GraphPersonRawRelationByRow(ByVal rowNo As Long) As String
    Dim wp As Worksheet, a As String, b As String
    If rowNo <= 0 Then Exit Function
    Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)
    a = CleanText(wp.Cells(rowNo, P_REL_DEC).Value)
    b = CleanText(wp.Cells(rowNo, P_REL_DISP).Value)
    If Len(a) = 0 Then
        GraphPersonRawRelationByRow = b
    ElseIf Len(b) = 0 Or b = a Then
        GraphPersonRawRelationByRow = a
    ElseIf InStr(1, a, b, vbTextCompare) > 0 Then
        GraphPersonRawRelationByRow = a
    ElseIf InStr(1, b, a, vbTextCompare) > 0 Then
        GraphPersonRawRelationByRow = b
    Else
        GraphPersonRawRelationByRow = a & " " & b
    End If
End Function

Private Function GraphPairKey(ByVal leftId As String, ByVal rightId As String) As String
    leftId = CleanText(leftId)
    rightId = CleanText(rightId)
    If Len(leftId) = 0 Or Len(rightId) = 0 Then Exit Function
    If leftId < rightId Then
        GraphPairKey = leftId & "|" & rightId
    Else
        GraphPairKey = rightId & "|" & leftId
    End If
End Function

Private Function GraphRelationLooksLikeSpouse(ByVal relText As String) As Boolean
    Dim rawText As String, baseText As String
    rawText = CleanText(relText)
    If Len(rawText) = 0 Then Exit Function
    If GraphRelationLooksLikeSpouseChild(rawText) Then Exit Function
    baseText = GraphBaseRelationLabel(rawText)
    If baseText = "�z���" Or baseText = "��" Or baseText = "�v" Then
        GraphRelationLooksLikeSpouse = True
    ElseIf Right$(baseText, 4) = "�̔z���" Then
        GraphRelationLooksLikeSpouse = True
    End If
End Function

Private Function GraphRelationLooksLikeSpouseChild(ByVal relText As String) As Boolean
    relText = CleanText(relText)
    GraphRelationLooksLikeSpouseChild = (InStr(1, relText, "�z��҂̎q", vbTextCompare) > 0 _
        Or InStr(1, relText, "�z��҂Ƃ̎q", vbTextCompare) > 0 _
        Or InStr(1, relText, "�O�z��҂Ƃ̎q", vbTextCompare) > 0 _
        Or InStr(1, relText, "�A��q", vbTextCompare) > 0 _
        Or InStr(1, relText, "�ʕ�", vbTextCompare) > 0 _
        Or InStr(1, relText, "�ʕ�", vbTextCompare) > 0)
End Function

Private Function GraphRelationLooksLikeChild(ByVal relText As String) As Boolean
    GraphRelationLooksLikeChild = (GraphDescendantLevelText(relText) > 0 Or GraphIsDirectChildLabel(GraphBaseRelationLabel(relText)))
End Function

Private Function GraphIsParentRelationById(ByVal personId As String) As Boolean
    Dim s As String
    s = GraphBaseRelationLabel(GraphPersonRawRelationById(personId))
    GraphIsParentRelationById = (s = "��" Or s = "��")
End Function

Private Function GraphDescendantLevelById(ByVal personId As String) As Long
    GraphDescendantLevelById = GraphDescendantLevelText(GraphPersonRawRelationById(personId))
End Function

Private Function GraphResolvedLevelForId(ByVal personId As String, ByVal depth As Long) As Long
    Dim relText As String, parentId As String, pLevel As Long
    If depth > 12 Then Exit Function
    If Len(personId) = 0 Then Exit Function
    If DiagramGraphIsPureSpouseId(personId) Then Exit Function
    relText = DiagramGraphDisplayRelation(personId, GraphPersonRawRelationById(personId))
    GraphResolvedLevelForId = GraphDescendantLevelText(relText)
    If GraphResolvedLevelForId > 0 Then Exit Function
    If gParentByChild.Exists(personId) Then
        parentId = CleanText(gParentByChild(personId))
        pLevel = GraphResolvedLevelForId(parentId, depth + 1)
        If pLevel > 0 Then GraphResolvedLevelForId = pLevel + 1
    End If
End Function

Private Function GraphDescendantLevelText(ByVal relText As String) As Long
    relText = GraphBaseRelationLabel(relText)
    If GraphIsDirectChildLabel(relText) Then
        GraphDescendantLevelText = 1
    ElseIf relText = "��" Then
        GraphDescendantLevelText = 2
    ElseIf relText = "�]��" Then
        GraphDescendantLevelText = 3
    ElseIf relText = "����" Then
        GraphDescendantLevelText = 4
    End If
End Function

Private Function GraphIsDirectChildLabel(ByVal relText As String) As Boolean
    relText = GraphBaseRelationLabel(relText)
    Select Case relText
        Case "���j", "��j", "�O�j", "�l�j", "�ܒj", "�Z�j", "����", "��", "�O��", "�l��", "�܏�", "�Z��", "�q", "�{�q"
            GraphIsDirectChildLabel = True
    End Select
End Function

Private Function GraphBaseRelationLabel(ByVal relText As String) As String
    Dim s As String, p As Long, tokens As Variant, i As Long, t As String
    s = CleanText(relText)
    s = Replace(s, "�\��", "�]��")
    s = Replace(s, "�Б�", "�]��")
    s = Replace(s, "�\", "�]")
    s = Replace(s, "�@", " ")
    Do While InStr(s, "  ") > 0
        s = Replace(s, "  ", " ")
    Loop
    If GraphRelationLooksLikeSpouseChild(s) Then
        If InStr(1, s, "�]���̔z���", vbTextCompare) > 0 Then GraphBaseRelationLabel = "�]���̔z��҂̎q": Exit Function
        If InStr(1, s, "���̔z���", vbTextCompare) > 0 Then GraphBaseRelationLabel = "���̔z��҂̎q": Exit Function
        If InStr(1, s, "�q�̔z���", vbTextCompare) > 0 Or InStr(1, s, "���j�̔z���", vbTextCompare) > 0 Or InStr(1, s, "�����̔z���", vbTextCompare) > 0 Then GraphBaseRelationLabel = "�q�̔z��҂̎q": Exit Function
        If InStr(1, s, "�O�z���", vbTextCompare) > 0 Then GraphBaseRelationLabel = "�O�z��҂Ƃ̎q": Exit Function
        If InStr(1, s, "�A��q", vbTextCompare) > 0 Then GraphBaseRelationLabel = "�A��q": Exit Function
        If InStr(1, s, "�ʕ�", vbTextCompare) > 0 Then GraphBaseRelationLabel = "�ʕ��̎q": Exit Function
        If InStr(1, s, "�ʕ�", vbTextCompare) > 0 Then GraphBaseRelationLabel = "�ʕ�̎q": Exit Function
        GraphBaseRelationLabel = "�z��ґ��̎q"
        Exit Function
    End If
    If InStr(s, "�z���") > 0 Then
        If InStr(s, "��") > 0 Then GraphBaseRelationLabel = "���̔z���": Exit Function
        If InStr(s, "��") > 0 Then GraphBaseRelationLabel = "��̔z���": Exit Function
        If InStr(s, "����") > 0 Then GraphBaseRelationLabel = "�����̔z���": Exit Function
        If InStr(s, "�]��") > 0 Then GraphBaseRelationLabel = "�]���̔z���": Exit Function
        If InStr(s, "��") > 0 Then GraphBaseRelationLabel = "���̔z���": Exit Function
        If InStr(s, "�q") > 0 Or InStr(s, "���j") > 0 Or InStr(s, "����") > 0 Then GraphBaseRelationLabel = "�q�̔z���": Exit Function
        GraphBaseRelationLabel = "�z���": Exit Function
    End If
    tokens = Split(s, " ")
    For i = LBound(tokens) To UBound(tokens)
        t = CleanText(tokens(i))
        If Len(t) > 0 Then
            If t = "�푊���l" Or t = "��" Or t = "��" Or t = "��" Or t = "�]��" Or t = "����" Or GraphIsDirectChildToken(t) Then
                GraphBaseRelationLabel = t
                Exit Function
            End If
        End If
    Next i
    If InStr(s, "����") > 0 Then GraphBaseRelationLabel = "����": Exit Function
    If InStr(s, "�]��") > 0 Then GraphBaseRelationLabel = "�]��": Exit Function
    If InStr(s, "��") > 0 Then GraphBaseRelationLabel = "��": Exit Function
    If InStr(s, "�푊���l") > 0 Then GraphBaseRelationLabel = "�푊���l": Exit Function
    If InStr(s, "��") > 0 Then GraphBaseRelationLabel = "��": Exit Function
    If InStr(s, "��") > 0 Then GraphBaseRelationLabel = "��": Exit Function
    For i = LBound(tokens) To UBound(tokens)
        t = CleanText(tokens(i))
        If GraphIsDirectChildToken(t) Then GraphBaseRelationLabel = t: Exit Function
    Next i
    GraphBaseRelationLabel = s
End Function

Private Function GraphIsDirectChildToken(ByVal s As String) As Boolean
    Select Case CleanText(s)
        Case "���j", "��j", "�O�j", "�l�j", "�ܒj", "�Z�j", "����", "��", "�O��", "�l��", "�܏�", "�Z��", "�q", "�{�q"
            GraphIsDirectChildToken = True
    End Select
End Function

Private Function GraphHasDate(ByVal v As Variant) As Boolean
    GraphHasDate = GraphDateToSerialOk(v)
End Function

Private Function GraphDateToSerialOk(ByVal v As Variant) As Boolean
    Dim ignored As Double, ok As Boolean
    ignored = GraphDateSerialInternal(v, ok)
    GraphDateToSerialOk = ok
End Function

Private Function GraphDateSerial(ByVal v As Variant) As Double
    Dim ok As Boolean
    GraphDateSerial = GraphDateSerialInternal(v, ok)
End Function

Private Function GraphDateSerialInternal(ByVal v As Variant, ByRef ok As Boolean) As Double
    Dim s As String, eraChar As String, y As Long, m As Long, d As Long, parts As Variant
    ok = False
    If IsDate(v) Then
        ok = True
        GraphDateSerialInternal = CDbl(CDate(v))
        Exit Function
    End If
    s = UCase$(CleanText(v))
    If Len(s) = 0 Then Exit Function
    s = Replace(s, "�ߘa", "R")
    s = Replace(s, "����", "H")
    s = Replace(s, "���a", "S")
    s = Replace(s, "�吳", "T")
    s = Replace(s, "����", "M")
    s = Replace(s, "���N", "1�N")
    s = Replace(s, "�N", ".")
    s = Replace(s, "��", ".")
    s = Replace(s, "��", "")
    s = Replace(s, "/", ".")
    s = Replace(s, "-", ".")
    s = Replace(s, " ", "")
    If Len(s) < 4 Then Exit Function
    eraChar = Left$(s, 1)
    If InStr("RHSTM", eraChar) = 0 Then Exit Function
    s = Mid$(s, 2)
    parts = Split(s, ".")
    If UBound(parts) < 2 Then Exit Function
    If Not IsNumeric(parts(0)) Then Exit Function
    If Not IsNumeric(parts(1)) Then Exit Function
    If Not IsNumeric(parts(2)) Then Exit Function
    y = CLng(parts(0))
    m = CLng(parts(1))
    d = CLng(parts(2))
    Select Case eraChar
        Case "R": y = y + 2018
        Case "H": y = y + 1988
        Case "S": y = y + 1925
        Case "T": y = y + 1911
        Case "M": y = y + 1867
    End Select
    If y < 1800 Or m < 1 Or m > 12 Or d < 1 Or d > 31 Then Exit Function
    On Error GoTo EH
    GraphDateSerialInternal = CDbl(DateSerial(y, m, d))
    ok = True
    Exit Function
EH:
    ok = False
    Err.Clear
End Function

Private Function GraphPersonShouldStayOther(ByVal personId As String) As Boolean
    Dim rowNo As Long, wp As Worksheet, relText As String, typeText As String, noteText As String
    personId = CleanText(personId)
    If Len(personId) = 0 Then Exit Function
    If personId = gDecedentId Then Exit Function
    If gPersonRows Is Nothing Then Exit Function
    If Not gPersonRows.Exists(personId) Then Exit Function
    If DiagramGraphIsPureSpouseId(personId) Then Exit Function
    Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)
    rowNo = CLng(gPersonRows(personId))
    relText = GraphPersonRawRelationByRow(rowNo)
    typeText = CleanText(wp.Cells(rowNo, P_TYPE).Value)
    noteText = CleanText(wp.Cells(rowNo, P_NOTE).Value)
    If GraphRelationLooksLikeChild(relText) Then Exit Function
    If GraphDescendantLevelText(relText) > 0 Then Exit Function
    If GraphIsParentRelationById(personId) Then Exit Function
    If GraphRelationLooksLikeSpouse(relText) Then Exit Function
    If typeText = "�֌W��" Then
        GraphPersonShouldStayOther = True
        Exit Function
    End If
    If GraphRelationLooksLikeOtherText(relText) Then GraphPersonShouldStayOther = True: Exit Function
    If GraphRelationLooksLikeOtherText(noteText) Then GraphPersonShouldStayOther = True
End Function

Private Function GraphRelationLooksLikeOtherText(ByVal relText As String) As Boolean
    relText = CleanText(relText)
    If Len(relText) = 0 Then Exit Function
    If InStr(1, relText, "�֌W��", vbTextCompare) > 0 Then GraphRelationLooksLikeOtherText = True: Exit Function
    If InStr(1, relText, "���", vbTextCompare) > 0 Then GraphRelationLooksLikeOtherText = True: Exit Function
    If InStr(1, relText, "��", vbTextCompare) > 0 Then GraphRelationLooksLikeOtherText = True: Exit Function
    If InStr(1, relText, "��", vbTextCompare) > 0 Then GraphRelationLooksLikeOtherText = True: Exit Function
    If InStr(1, relText, "�㗝�l", vbTextCompare) > 0 Then GraphRelationLooksLikeOtherText = True: Exit Function
    If InStr(1, relText, "�", vbTextCompare) > 0 Then GraphRelationLooksLikeOtherText = True: Exit Function
    If InStr(1, relText, "����", vbTextCompare) > 0 Then GraphRelationLooksLikeOtherText = True
End Function

Private Function DiagramGraphHumanMessage(ByVal personId As String, ByVal parentId As String, ByVal spouseId As String, ByVal childKey As String) As String
    Dim relText As String, parentName As String, spouseName As String
    personId = CleanText(personId)
    relText = DiagramGraphDisplayRelation(personId, GraphPersonRawRelationById(personId))
    parentName = GraphPersonNameById(parentId)
    spouseName = GraphPersonNameById(spouseId)
    If Len(childKey) > 0 Then
        DiagramGraphHumanMessage = GraphPersonNameById(personId) & " �� " & parentName & "�E" & spouseName & " �̍������ԓ��o���Ƃ��Ĕ��肵�܂����B���͕v�w�������牺�낵�܂��B"
    ElseIf Len(parentId) > 0 And DiagramGraphIsPureSpouseId(parentId) Then
        DiagramGraphHumanMessage = GraphPersonNameById(personId) & " �� " & parentName & " ���̎q�Ƃ��Ĉ����܂��B�������ԓ��o���Ɗm��ł��Ȃ����߁A���͕v�w�����ł͂Ȃ��z��҃J�[�h���牺�낵�܂��B"
    ElseIf Len(parentId) > 0 Then
        DiagramGraphHumanMessage = GraphPersonNameById(personId) & " �� " & parentName & " �̎q�Ƃ��Ĕ��肵�܂����B���͐e�J�[�h���牺�낵�܂��B"
    ElseIf DiagramGraphIsPureSpouseId(personId) Then
        DiagramGraphHumanMessage = GraphPersonNameById(personId) & " �� " & spouseName & " �̔z��҂Ƃ��Ĉ����܂��B�q������ɂ͕ϊ����܂���B"
    ElseIf GraphPersonShouldStayOther(personId) Then
        DiagramGraphHumanMessage = GraphPersonNameById(personId) & " �͂��̑��֌W�l�Ƃ��Ĉ����܂��B�e�q���ɂ͍��������܂���B"
    ElseIf GraphChildParentFallbackBlocked(personId) Then
        DiagramGraphHumanMessage = GraphPersonNameById(personId) & " �͔z��ґ��̎q���ł����v�w���ԓ��o���Ɗm��ł��܂���B�������E�o���N�����E�O�z���/�A��q���L���m�F���Ă��������B"
    ElseIf GraphDescendantLevelText(relText) > 0 Then
        DiagramGraphHumanMessage = GraphPersonNameById(personId) & " �� " & relText & " �ł����m��e������܂���B��l���E�e�q�֌W�E�������Ԃ��m�F���Ă��������B"
    End If
End Function

Private Sub GraphAddWarning(ByVal keyText As String, ByVal msg As String)
    If gGraphWarnings Is Nothing Then Exit Sub
    keyText = CleanText(keyText)
    If Len(keyText) = 0 Then keyText = "warning" & CStr(gGraphWarnings.Count + 1)
    If Not gGraphWarnings.Exists(keyText) Then gGraphWarnings.Add keyText, msg
End Sub

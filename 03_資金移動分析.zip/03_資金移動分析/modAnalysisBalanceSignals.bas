Attribute VB_Name = "modAnalysisBalanceSignals"
Option Explicit

'�����c�����������O�c���E�ϓ�����⊮���鏈���𕪐͖{�̂��番������B
Public Sub EnrichAnalysisTransactionAfterBalanceContext(ByVal txById As Object)
    Dim k As Variant, rec As Object
    Dim afterValue As Double, beforeValue As Double, outAmt As Double, inAmt As Double

    If txById Is Nothing Then Exit Sub
    For Each k In txById.Keys
        Set rec = txById(k)
        If Not rec Is Nothing Then
            If AnalysisBalanceKeyExists(rec, "BalanceAfter") Then
                If IsNumeric(rec("BalanceAfter")) Then
                    afterValue = CDbl(rec("BalanceAfter"))
                    outAmt = 0#: inAmt = 0#
                    If AnalysisBalanceKeyExists(rec, "Out") Then
                        If IsNumeric(rec("Out")) Then outAmt = CDbl(rec("Out"))
                    End If
                    If AnalysisBalanceKeyExists(rec, "In") Then
                        If IsNumeric(rec("In")) Then inAmt = CDbl(rec("In"))
                    End If
                    beforeValue = afterValue + outAmt - inAmt
                    rec("BalanceBefore") = beforeValue
                    rec("BalanceAfterKnown") = True
                    If beforeValue > 0 Then rec("BalanceChangeRate") = Application.Max(outAmt, inAmt) / beforeValue
                End If
            End If
        End If
    Next k
End Sub


Public Function ParseAnalysisTransactionBalanceValue(ByVal v As Variant) As Variant
    Dim s As String
    If IsNumeric(v) Then ParseAnalysisTransactionBalanceValue = CDbl(v): Exit Function
    s = Trim$(CStr(v))
    If Len(s) = 0 Then ParseAnalysisTransactionBalanceValue = "": Exit Function
    s = Replace(s, "�~", "")
    s = Replace(s, ",", "")
    s = Replace(s, " ", "")
    s = Replace(s, "�@", "")
    s = Replace(s, "�c��", "")
    s = Replace(s, "�c", "")
    If IsNumeric(s) Then ParseAnalysisTransactionBalanceValue = CDbl(s) Else ParseAnalysisTransactionBalanceValue = ""
End Function

Public Function BuildAnalysisTransactionBalanceSignalSummary(ByVal outs As Collection, ByVal ins As Collection) As String
    BuildAnalysisTransactionBalanceSignalSummary = AnalysisBalanceSignalForSide(outs, True)
    BuildAnalysisTransactionBalanceSignalSummary = JoinNonBlank(BuildAnalysisTransactionBalanceSignalSummary, AnalysisBalanceSignalForSide(ins, False), " / ")
End Function

Private Function AnalysisBalanceSignalForSide(ByVal recs As Collection, ByVal useOut As Boolean) As String
    Dim rec As Object, beforeValue As Double, afterValue As Double, amountValue As Double, ratio As Double, whoText As String
    If recs Is Nothing Then Exit Function
    For Each rec In recs
        If AnalysisBalanceKeyExists(rec, "BalanceAfter") Then
            If AnalysisBalanceKeyExists(rec, "BalanceBefore") Then
                If IsNumeric(rec("BalanceAfter")) Then
                    If IsNumeric(rec("BalanceBefore")) Then
                        beforeValue = CDbl(rec("BalanceBefore"))
                        afterValue = CDbl(rec("BalanceAfter"))
                        If useOut Then
                            If AnalysisBalanceKeyExists(rec, "Out") Then
                                If IsNumeric(rec("Out")) Then amountValue = CDbl(rec("Out")) Else amountValue = 0#
                            Else
                                amountValue = 0#
                            End If
                        Else
                            If AnalysisBalanceKeyExists(rec, "In") Then
                                If IsNumeric(rec("In")) Then amountValue = CDbl(rec("In")) Else amountValue = 0#
                            Else
                                amountValue = 0#
                            End If
                        End If
                        If beforeValue > 0 Then
                            ratio = amountValue / beforeValue
                            If AnalysisBalanceKeyExists(rec, "Name") Then whoText = CStr(rec("Name"))
                            If useOut Then
                                If amountValue > 0 Then
                                    If ratio >= 0.3 Then
                                        AnalysisBalanceSignalForSide = "������׎c���}���i" & ClipText(whoText, 8) & " �o����c��" & Format$(afterValue, "#,##0") & "�~ / ���O����" & Format$(beforeValue, "#,##0") & "�~�j"
                                        Exit Function
                                    End If
                                End If
                            Else
                                If amountValue > 0 Then
                                    If beforeValue > 0 Then
                                        If afterValue >= beforeValue * 1.3 Then
                                            AnalysisBalanceSignalForSide = "������׎c���}���i" & ClipText(whoText, 8) & " ������c��" & Format$(afterValue, "#,##0") & "�~ / ���O����" & Format$(beforeValue, "#,##0") & "�~�j"
                                            Exit Function
                                        End If
                                    End If
                                End If
                            End If
                        End If
                    End If
                End If
            End If
        End If
    Next rec
End Function

Private Function AnalysisBalanceKeyExists(ByVal dict As Object, ByVal keyText As String) As Boolean
    On Error Resume Next
    If dict Is Nothing Then Exit Function
    AnalysisBalanceKeyExists = dict.Exists(keyText)
    On Error GoTo 0
End Function

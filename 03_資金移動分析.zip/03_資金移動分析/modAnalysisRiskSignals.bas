Attribute VB_Name = "modAnalysisRiskSignals"
Option Explicit

'���̓G���W�����剻���~�߂邽�߂̃��X�N�V�O�i�������w�B
'�����ł́A��␶�����̂��̂ł͂Ȃ��u���Ɍ��ɂȂ�������Q�֕t���钍�ӃV�O�i���v�������B
'�G���W�����̃O���[�o����Ԃ֒��ڐG�炸�A�K�v�ȃC���f�b�N�X�Ƃ������l�𖾎��I�Ɏ󂯎��B

Public Function BuildRiskSignalSummary(ByVal outs As Collection, _
        ByVal ins As Collection, _
        ByVal decedentId As String, _
        ByVal inheritanceDate As Variant, _
        ByVal minShift As Double, _
        ByVal unknownThreshold As Double, _
        ByVal relationPairs As Object, _
        ByVal marriageByPerson As Object, _
        ByVal personInfo As Object, _
        ByVal timeCluster As Object, _
        ByVal accountPatternCount As Object) As String

    Dim d As Object, rec As Object
    Set d = CreateObject("Scripting.Dictionary")

    If Not outs Is Nothing Then
        For Each rec In outs
            If RiskKeyExists(rec, "PersonId") Then
                If CStr(rec("PersonId")) = decedentId Then
                    If IsDate(inheritanceDate) Then
                        If RiskKeyExists(rec, "Date") Then
                        If IsDate(rec("Date")) Then
                            If CDate(rec("Date")) >= CDate(inheritanceDate) Then d("�푊���l�̑�����o��") = True
                        End If
                        End If
                    End If
                End If
            End If
            If RiskKeyExists(rec, "AgeAtTx") Then
                If InStr(1, CStr(rec("AgeAtTx")), "���S��", vbTextCompare) > 0 Then d("���S����") = True
            End If
        Next rec
    End If

    If Not ins Is Nothing Then
        For Each rec In ins
            If RiskKeyExists(rec, "AgeAtTx") Then
                If InStr(1, CStr(rec("AgeAtTx")), "���S��", vbTextCompare) > 0 Then d("���S����") = True
            End If
        Next rec
    End If

    AddRiskText d, RiskYoungHighAmount(outs, ins, minShift)
    AddRiskText d, RiskLifeEventAroundHighAmount(outs, ins, minShift, marriageByPerson, personInfo, relationPairs)
    AddRiskText d, RiskMoveAroundHighAmount(outs, ins, minShift)
    AddRiskText d, RiskTimeCluster(outs, ins, timeCluster)
    AddRiskText d, RiskAccountOperationPattern(outs, ins, accountPatternCount)
    If Len(RiskTimeCluster(outs, ins, timeCluster)) > 0 Then
        AddRiskText d, "���`�O�Ǘ��m�F�i�������сE�������`�j"
    ElseIf Len(RiskAccountOperationPattern(outs, ins, accountPatternCount)) > 0 Then
        AddRiskText d, "���`�O�Ǘ��m�F�i�ގ������є����j"
    End If
    AddRiskText d, RiskGiftAddBack(outs, ins, decedentId, inheritanceDate, relationPairs, personInfo)
    AddRiskText d, RiskPreInheritanceWithdrawal(outs, decedentId, inheritanceDate, unknownThreshold)

    BuildRiskSignalSummary = RiskJoinDictionaryKeys(d, " / ")
End Function

Private Sub AddRiskText(ByVal d As Object, ByVal s As String)
    If d Is Nothing Then Exit Sub
    If Len(s) > 0 Then d(s) = True
End Sub

Private Function RiskYoungHighAmount(ByVal outs As Collection, ByVal ins As Collection, ByVal minShift As Double) As String
    RiskYoungHighAmount = RiskYoungHighAmountForSide(outs, True, minShift)
    RiskYoungHighAmount = JoinNonBlank(RiskYoungHighAmount, RiskYoungHighAmountForSide(ins, False, minShift), " / ")
End Function

Private Function RiskYoungHighAmountForSide(ByVal recs As Collection, ByVal useOut As Boolean, ByVal minShift As Double) As String
    Dim rec As Object, ageYears As Long, amountValue As Double, whoText As String
    If recs Is Nothing Then Exit Function
    For Each rec In recs
        ageYears = -1
        amountValue = 0
        If RiskKeyExists(rec, "AgeYearsAtTx") Then ageYears = CLng(rec("AgeYearsAtTx"))
        If useOut Then
            If RiskKeyExists(rec, "Out") Then amountValue = CDbl(rec("Out"))
        Else
            If RiskKeyExists(rec, "In") Then amountValue = CDbl(rec("In"))
        End If
        If ageYears >= 0 And ageYears < YOUNG_ATTENTION_AGE_YEARS And amountValue >= minShift Then
            If RiskKeyExists(rec, "Name") Then whoText = CStr(rec("Name"))
            If Len(whoText) = 0 Then
                If RiskKeyExists(rec, "PersonId") Then whoText = CStr(rec("PersonId"))
            End If
            RiskYoungHighAmountForSide = "��N���Ӎ��z����i20�Ζ���: " & ClipText(whoText, 8) & " " & CStr(ageYears) & "�΁j"
            Exit Function
        End If
    Next rec
End Function

Private Function RiskLifeEventAroundHighAmount(ByVal outs As Collection, ByVal ins As Collection, ByVal minShift As Double, ByVal marriageByPerson As Object, ByVal personInfo As Object, ByVal relationPairs As Object) As String
    RiskLifeEventAroundHighAmount = RiskLifeEventAroundHighAmountForSide(outs, True, minShift, marriageByPerson, personInfo, relationPairs)
    RiskLifeEventAroundHighAmount = JoinNonBlank(RiskLifeEventAroundHighAmount, RiskLifeEventAroundHighAmountForSide(ins, False, minShift, marriageByPerson, personInfo, relationPairs), " / ")
End Function

Private Function RiskLifeEventAroundHighAmountForSide(ByVal recs As Collection, ByVal useOut As Boolean, ByVal minShift As Double, ByVal marriageByPerson As Object, ByVal personInfo As Object, ByVal relationPairs As Object) As String
    Dim rec As Object, amountValue As Double, personId As String, txDate As Date
    Dim eventText As String, sideText As String
    If recs Is Nothing Then Exit Function
    If useOut Then sideText = "�o��" Else sideText = "����"
    For Each rec In recs
        If RiskKeyExists(rec, "PersonId") Then
            If RiskKeyExists(rec, "Date") Then
                If IsDate(rec("Date")) Then
                    personId = CStr(rec("PersonId"))
                    txDate = CDate(rec("Date"))
                amountValue = RiskRecordAmount(rec, useOut)
                If amountValue >= minShift Then
                    eventText = RiskMarriageEventNearText(personId, txDate, DEFAULT_MOVE_NEAR_WINDOW_DAYS, marriageByPerson)
                    If Len(eventText) > 0 Then
                        RiskLifeEventAroundHighAmountForSide = "�����O��̍��z" & sideText & "�i" & ClipText(RiskPersonDisplayName(personId, personInfo), 8) & " / " & ClipText(eventText, 18) & "�j"
                        Exit Function
                    End If
                    eventText = RiskRelatedBirthNearText(personId, txDate, DEFAULT_MOVE_NEAR_WINDOW_DAYS, personInfo, relationPairs)
                    If Len(eventText) > 0 Then
                        RiskLifeEventAroundHighAmountForSide = "�o���O��̍��z" & sideText & "�i" & ClipText(RiskPersonDisplayName(personId, personInfo), 8) & " / " & ClipText(eventText, 18) & "�j"
                        Exit Function
                    End If
                End If
            End If
        End If
    End If
    Next rec
End Function

Private Function RiskMoveAroundHighAmount(ByVal outs As Collection, ByVal ins As Collection, ByVal minShift As Double) As String
    RiskMoveAroundHighAmount = RiskMoveAroundHighAmountForSide(outs, True, minShift)
    RiskMoveAroundHighAmount = JoinNonBlank(RiskMoveAroundHighAmount, RiskMoveAroundHighAmountForSide(ins, False, minShift), " / ")
End Function

Private Function RiskMoveAroundHighAmountForSide(ByVal recs As Collection, ByVal useOut As Boolean, ByVal minShift As Double) As String
    Dim rec As Object, amountValue As Double, whoText As String, moveText As String
    If recs Is Nothing Then Exit Function
    For Each rec In recs
        amountValue = RiskRecordAmount(rec, useOut)
        If amountValue >= minShift Then
            If useOut Then
                If RiskKeyExists(rec, "RelatedMoveNearTx") Then moveText = CStr(rec("RelatedMoveNearTx")) Else moveText = ""
            Else
                If RiskKeyExists(rec, "AddressChangeNearTx") Then moveText = CStr(rec("AddressChangeNearTx")) Else moveText = ""
            End If
            If Len(moveText) > 0 Then
                If RiskKeyExists(rec, "Name") Then whoText = CStr(rec("Name"))
                If Len(whoText) = 0 Then
                    If RiskKeyExists(rec, "PersonId") Then whoText = CStr(rec("PersonId"))
                End If
                If useOut Then
                    RiskMoveAroundHighAmountForSide = "�]���O��̍��z�o���i" & ClipText(whoText, 8) & " / " & ClipText(moveText, 24) & "�j"
                Else
                    RiskMoveAroundHighAmountForSide = "�]���O��̍��z�����i" & ClipText(whoText, 8) & " " & ClipText(moveText, 12) & "�j"
                End If
                Exit Function
            End If
        End If
    Next rec
End Function

Private Function RiskTimeCluster(ByVal outs As Collection, ByVal ins As Collection, ByVal timeCluster As Object) As String
    RiskTimeCluster = RiskTimeClusterForSide(outs, timeCluster)
    If Len(RiskTimeCluster) = 0 Then RiskTimeCluster = RiskTimeClusterForSide(ins, timeCluster)
End Function

Private Function RiskTimeClusterForSide(ByVal recs As Collection, ByVal timeCluster As Object) As String
    Dim rec As Object, col As Collection, accountCount As Long, personCount As Long
    If recs Is Nothing Then Exit Function
    If timeCluster Is Nothing Then Exit Function
    For Each rec In recs
        Set col = RiskNearbyTimeClusterRecords(rec, timeCluster)
        accountCount = RiskDistinctCount(col, "AccountId")
        personCount = RiskDistinctCount(col, "PersonId")
        If Not col Is Nothing Then
            If col.Count >= 3 And (accountCount >= 2 Or personCount >= 2) Then
                RiskTimeClusterForSide = "���������t�߂ɕ������`����W���i" & CStr(col.Count) & "���j"
                Exit Function
            End If
        End If
    Next rec
End Function

Private Function RiskAccountOperationPattern(ByVal outs As Collection, ByVal ins As Collection, ByVal accountPatternCount As Object) As String
    RiskAccountOperationPattern = RiskAccountOperationPatternForSide(outs, accountPatternCount)
    If Len(RiskAccountOperationPattern) = 0 Then RiskAccountOperationPattern = RiskAccountOperationPatternForSide(ins, accountPatternCount)
End Function

Private Function RiskAccountOperationPatternForSide(ByVal recs As Collection, ByVal accountPatternCount As Object) As String
    Dim rec As Object, acc As String, cnt As Long, whoText As String
    If recs Is Nothing Then Exit Function
    If accountPatternCount Is Nothing Then Exit Function
    For Each rec In recs
        If RiskKeyExists(rec, "AccountId") Then acc = CStr(rec("AccountId")) Else acc = ""
        If Len(acc) > 0 And accountPatternCount.Exists(acc) Then
            cnt = CLng(accountPatternCount(acc))
            If cnt >= 3 Then
                If RiskKeyExists(rec, "Name") Then whoText = CStr(rec("Name")) Else whoText = acc
                RiskAccountOperationPatternForSide = "�ގ������тɔ������镡����������i" & ClipText(whoText, 8) & " " & CStr(cnt) & "��j"
                Exit Function
            End If
        End If
    Next rec
End Function

Private Function RiskGiftAddBack(ByVal outs As Collection, ByVal ins As Collection, ByVal decedentId As String, ByVal inheritanceDate As Variant, ByVal relationPairs As Object, ByVal personInfo As Object) As String
    Dim rec As Object, hasDecedentOutInPeriod As Boolean, hasRelatedInInPeriod As Boolean
    If Not outs Is Nothing Then
        For Each rec In outs
            If RiskIsDecedentRecord(rec, decedentId) Then
                If RiskKeyExists(rec, "Date") Then
                    If IsDate(rec("Date")) Then
                        If RiskIsGiftAddBackPeriodDate(CDate(rec("Date")), inheritanceDate) Then
                            hasDecedentOutInPeriod = True
                            Exit For
                        End If
                    End If
                End If
            End If
        Next rec
    End If
    If Not ins Is Nothing Then
        For Each rec In ins
            If RiskKeyExists(rec, "Date") Then
                If IsDate(rec("Date")) Then
                    If RiskIsGiftAddBackPeriodDate(CDate(rec("Date")), inheritanceDate) Then
                        If RiskIsRelatedOrKinNonDecedentRecord(rec, decedentId, relationPairs, personInfo) Then
                            hasRelatedInInPeriod = True
                            Exit For
                        End If
                    End If
                End If
            End If
        Next rec
    End If
    If hasDecedentOutInPeriod And hasRelatedInInPeriod Then
        RiskGiftAddBack = "��N���^���Z���ԓ��V�t�g�m�F"
    ElseIf hasRelatedInInPeriod Then
        If outs Is Nothing Then
            RiskGiftAddBack = "��N���^���Z���ԓ��̍��z�s�������m�F"
        ElseIf outs.Count = 0 Then
            RiskGiftAddBack = "��N���^���Z���ԓ��̍��z�s�������m�F"
        End If
    End If
End Function

Private Function RiskPreInheritanceWithdrawal(ByVal outs As Collection, ByVal decedentId As String, ByVal inheritanceDate As Variant, ByVal unknownThreshold As Double) As String
    Dim rec As Object, daysBefore As Long, amountValue As Double, bestDays As Long
    If outs Is Nothing Then Exit Function
    bestDays = 999999
    For Each rec In outs
        If RiskIsDecedentRecord(rec, decedentId) Then
            If RiskKeyExists(rec, "Date") Then
                If IsDate(rec("Date")) Then
                    daysBefore = RiskDaysBeforeInheritance(CDate(rec("Date")), inheritanceDate)
                    If daysBefore >= 0 And daysBefore <= 365 Then
                        If RiskKeyExists(rec, "Out") Then amountValue = CDbl(rec("Out")) Else amountValue = 0
                        If amountValue >= unknownThreshold Then
                            If daysBefore < bestDays Then bestDays = daysBefore
                        End If
                    End If
                End If
            End If
        End If
    Next rec
    If bestDays <= 7 Then
        RiskPreInheritanceWithdrawal = "���S���O����o���m�F�i7�����j"
    ElseIf bestDays <= 30 Then
        RiskPreInheritanceWithdrawal = "�������O����o���m�F�i30�����j"
    ElseIf bestDays <= 90 Then
        RiskPreInheritanceWithdrawal = "�������O����o���m�F�i90�����j"
    ElseIf bestDays <= 365 Then
        RiskPreInheritanceWithdrawal = "�����O1�N������o���m�F"
    End If
End Function

Private Function RiskMarriageEventNearText(ByVal personId As String, ByVal txDate As Date, ByVal windowDays As Long, ByVal marriageByPerson As Object) As String
    Dim col As Collection, item As Object, daysDiff As Long, bestDays As Long, bestText As String
    If marriageByPerson Is Nothing Then Exit Function
    If Len(personId) = 0 Then Exit Function
    If Not marriageByPerson.Exists(personId) Then Exit Function
    bestDays = 999999
    Set col = marriageByPerson(personId)
    For Each item In col
        If RiskKeyExists(item, "Date") Then
            If IsDate(item("Date")) Then
                daysDiff = Abs(DateDiff("d", DateValue(CDate(item("Date"))), DateValue(txDate)))
                If daysDiff <= windowDays And daysDiff < bestDays Then
                    bestDays = daysDiff
                    bestText = CStr(item("Text")) & " " & CStr(daysDiff) & "����"
                End If
            End If
        End If
    Next item
    RiskMarriageEventNearText = bestText
End Function

Private Function RiskRelatedBirthNearText(ByVal personId As String, ByVal txDate As Date, ByVal windowDays As Long, ByVal personInfo As Object, ByVal relationPairs As Object) As String
    Dim pid As Variant, info As Object, birthDate As Variant, daysDiff As Long, bestDays As Long, bestText As String
    Dim related As Boolean
    If personInfo Is Nothing Then Exit Function
    If Len(personId) = 0 Then Exit Function
    bestDays = 999999
    For Each pid In personInfo.Keys
        related = (CStr(pid) = personId)
        If Not related Then
            If Not relationPairs Is Nothing Then related = relationPairs.Exists(RiskRelationPairKey(personId, CStr(pid)))
        End If
        If related Then
            Set info = personInfo(pid)
            If Not info Is Nothing Then
                If RiskKeyExists(info, "Birth") Then
                    birthDate = info("Birth")
                    If IsDate(birthDate) Then
                        daysDiff = Abs(DateDiff("d", DateValue(CDate(birthDate)), DateValue(txDate)))
                        If daysDiff <= windowDays And daysDiff < bestDays Then
                            bestDays = daysDiff
                            bestText = "�o��:" & RiskPersonDisplayName(CStr(pid), personInfo) & " " & CStr(daysDiff) & "����"
                        End If
                    End If
                End If
            End If
        End If
    Next pid
    RiskRelatedBirthNearText = bestText
End Function

Private Function RiskNearbyTimeClusterRecords(ByVal rec As Object, ByVal timeCluster As Object) As Collection
    Dim emptyCol As New Collection
    Dim key As String, dayKey As String, bucket As Long, offset As Long, k As String
    Dim col As Collection, item As Variant
    If rec Is Nothing Or timeCluster Is Nothing Then Set RiskNearbyTimeClusterRecords = emptyCol: Exit Function
    If Not RiskKeyExists(rec, "Date") Then Set RiskNearbyTimeClusterRecords = emptyCol: Exit Function
    dayKey = Format$(CDate(rec("Date")), "yyyymmdd")
    bucket = 0
    If RiskKeyExists(rec, "TimeBucket") Then bucket = CLng(rec("TimeBucket"))
    Set col = New Collection
    For offset = -1 To 1
        k = dayKey & "|" & CStr(bucket + offset)
        If timeCluster.Exists(k) Then
            For Each item In timeCluster(k)
                col.Add item
            Next item
        End If
    Next offset
    Set RiskNearbyTimeClusterRecords = col
End Function

Private Function RiskRecordAmount(ByVal rec As Object, ByVal useOut As Boolean) As Double
    If rec Is Nothing Then Exit Function
    If useOut Then
        If RiskKeyExists(rec, "Out") Then RiskRecordAmount = CDbl(rec("Out"))
    Else
        If RiskKeyExists(rec, "In") Then RiskRecordAmount = CDbl(rec("In"))
    End If
End Function

Private Function RiskIsDecedentRecord(ByVal rec As Object, ByVal decedentId As String) As Boolean
    If rec Is Nothing Then Exit Function
    If Len(decedentId) = 0 Then Exit Function
    If RiskKeyExists(rec, "PersonId") Then RiskIsDecedentRecord = (CStr(rec("PersonId")) = decedentId)
End Function

Private Function RiskIsRelatedOrKinNonDecedentRecord(ByVal rec As Object, ByVal decedentId As String, ByVal relationPairs As Object, ByVal personInfo As Object) As Boolean
    Dim pid As String, relText As String
    If rec Is Nothing Then Exit Function
    If Not RiskKeyExists(rec, "PersonId") Then Exit Function
    pid = CStr(rec("PersonId"))
    If Len(pid) = 0 Then Exit Function
    If Len(decedentId) > 0 And pid = decedentId Then Exit Function
    If Not personInfo Is Nothing Then
        If personInfo.Exists(pid) Then
            If RiskKeyExists(personInfo(pid), "Relation") Then relText = CStr(personInfo(pid)("Relation"))
            If RiskRelationLooksKinship(relText) Then RiskIsRelatedOrKinNonDecedentRecord = True: Exit Function
        End If
    End If
    If Not relationPairs Is Nothing And Len(decedentId) > 0 Then
        If relationPairs.Exists(RiskRelationPairKey(decedentId, pid)) Then RiskIsRelatedOrKinNonDecedentRecord = True
    End If
End Function

Private Function RiskRelationLooksKinship(ByVal relText As String) As Boolean
    RiskRelationLooksKinship = (InStr(relText, "�z���") > 0 Or InStr(relText, "�q") > 0 Or InStr(relText, "��") > 0 Or _
        InStr(relText, "��") > 0 Or InStr(relText, "��") > 0 Or InStr(relText, "�Z") > 0 Or InStr(relText, "��") > 0 Or _
        InStr(relText, "�o") > 0 Or InStr(relText, "��") > 0 Or InStr(relText, "��") > 0 Or InStr(relText, "��") > 0)
End Function

Private Function RiskIsGiftAddBackPeriodDate(ByVal atDate As Date, ByVal inheritanceDate As Variant) As Boolean
    Dim startDate As Variant, inhDate As Date
    If Not IsDate(inheritanceDate) Then Exit Function
    inhDate = DateValue(CDate(inheritanceDate))
    If DateValue(atDate) > inhDate Then Exit Function
    startDate = RiskGiftAddBackPeriodStartDate(inhDate)
    If Not IsDate(startDate) Then Exit Function
    If DateValue(atDate) < DateValue(CDate(startDate)) Then Exit Function
    If DateValue(atDate) > inhDate Then Exit Function
    RiskIsGiftAddBackPeriodDate = True
End Function

Private Function RiskGiftAddBackPeriodStartDate(ByVal inheritanceDate As Date) As Variant
    Dim d As Date
    d = DateValue(inheritanceDate)
    If d <= DateSerial(2026, 12, 31) Then
        RiskGiftAddBackPeriodStartDate = DateAdd("yyyy", -3, d)
    ElseIf d <= DateSerial(2030, 12, 31) Then
        RiskGiftAddBackPeriodStartDate = DateSerial(2024, 1, 1)
    Else
        RiskGiftAddBackPeriodStartDate = DateAdd("yyyy", -7, d)
    End If
End Function

Private Function RiskDaysBeforeInheritance(ByVal atDate As Date, ByVal inheritanceDate As Variant) As Long
    RiskDaysBeforeInheritance = -1
    If Not IsDate(inheritanceDate) Then Exit Function
    If DateValue(atDate) > DateValue(CDate(inheritanceDate)) Then Exit Function
    RiskDaysBeforeInheritance = DateDiff("d", DateValue(atDate), DateValue(CDate(inheritanceDate)))
End Function

Private Function RiskPersonDisplayName(ByVal personId As String, ByVal personInfo As Object) As String
    If personInfo Is Nothing Then Exit Function
    If Len(personId) = 0 Then Exit Function
    If personInfo.Exists(personId) Then
        If RiskKeyExists(personInfo(personId), "Name") Then RiskPersonDisplayName = CStr(personInfo(personId)("Name"))
    End If
    If Len(RiskPersonDisplayName) = 0 Then RiskPersonDisplayName = personId
End Function

Private Function RiskRelationPairKey(ByVal a As String, ByVal b As String) As String
    If StrComp(a, b, vbTextCompare) <= 0 Then RiskRelationPairKey = a & "|" & b Else RiskRelationPairKey = b & "|" & a
End Function

Private Function RiskDistinctCount(ByVal col As Collection, ByVal fieldName As String) As Long
    Dim d As Object, rec As Object, k As String
    Set d = CreateObject("Scripting.Dictionary")
    If col Is Nothing Then Exit Function
    For Each rec In col
        If RiskKeyExists(rec, fieldName) Then
            k = CStr(rec(fieldName))
            If Len(k) > 0 Then d(k) = True
        End If
    Next rec
    RiskDistinctCount = d.Count
End Function

Private Function RiskJoinDictionaryKeys(ByVal d As Object, Optional ByVal sep As String = " / ") As String
    Dim k As Variant, s As String
    If d Is Nothing Then Exit Function
    For Each k In d.Keys
        If Len(s) > 0 Then s = s & sep
        s = s & CStr(k)
    Next k
    RiskJoinDictionaryKeys = s
End Function

Private Function RiskKeyExists(ByVal d As Object, ByVal keyText As String) As Boolean
    On Error Resume Next
    If d Is Nothing Then
        RiskKeyExists = False
    Else
        RiskKeyExists = d.Exists(keyText)
    End If
    On Error GoTo 0
End Function

﻿# 03 資金移動分析 作り直しレポート

## 対応内容

- 03だけのパッケージとして再構成。
- 一括取込スクリプトを作り直し。
- `IMPORT_03_MODULES.bat` はASCIIのみで作成。
- `IMPORT_03_MODULES.vbs` はUTF-16LE BOM付きで作成。
- VBAソースはVBE取り込み用にShift-JIS/CP932のまま維持。
- ソース格納先を `modules` に統一し、bat/vbsが日本語フォルダ名に依存しないよう修正。
- 取り込み前に古い非ドキュメントVBAモジュールを全削除し、古いモジュール残存による未定義を起こしにくくした。
- `ThisWorkbook_code.txt` / `Sheet_Main_code.txt` はADODB.StreamでShift-JISとして読み込むようにした。
- 入力シート名はVBS内でUnicodeコードポイントから生成し、VBS本文の日本語文字列依存を減らした。

## 反映方法

対象の03 `.xlsm` を閉じた状態で、ZIP展開後の以下にドラッグ＆ドロップしてください。

```text
03_資金移動分析\IMPORT_03_MODULES.bat
```

## 注意

`.bas` と `*_code.txt` はVBE取り込み用にCP932です。UTF-8専用エディタで開くと文字化けして見えることがありますが、VBE取り込み用としてはこの文字コードを維持しています。

# 03_資金移動分析 機能・マクロコード監査レポート

## 結論

03_資金移動分析 だけを対象に、未定義、OnAction/OnKey、VBA構文、ブロック不整合、0引数Subの括弧呼び出し、Private跨ぎ呼び出し、IIf、危険な非短絡評価、組込み名衝突、一括取込文字コードを監査しました。

実行時エラーや構文エラーにつながり得る箇所は修正済みです。実機ExcelでのVBEコンパイルは未実施なので、完成扱いにはしていません。

## 修正した箇所

- ZIPのルートフォルダ名が文字化けしていたため、`03_資金移動分析` として再構成。
- `modAnalysisEngine.bas` の `Not mSuppressDuplicateShift Or Not mMatched.Exists(...)` を分解し、`mMatched Is Nothing` もガード。
- `HasSameAddressAtTransaction` / `AddressHintForRecords` の辞書 `.Exists` 判定を分解し、キー文字列化後に判定する形へ修正。
- `modAnalysisExecutionGate.bas` の `accounts.Exists(accId) And accounts(accId)` を分解し、存在しないキー参照を防止。
- `modAnalysisRiskSignals.bas` の辞書 `.Exists` 判定を分解し、修正後のIfネスト整合も確認。
- `ThisWorkbook_code.txt` のフラグ系シート判定を `Select Case` ヘルパーへ分離。
- `CollectionsShareValue` の `Len(keyText)>0 And seen.Exists(keyText)` を分解。
- `modVisualTheme.bas` の `Or` 判定を分解。

## 静的監査結果

| 項目 | 件数 |
|---|---:|
| VBAコードファイル | 38 |
| Sub/Function/Property合計 | 587 |
| 開始数/終了数 | 587 / 587 |
| CP932デコードエラー | 0 |
| Option Explicit不足 | 0 |
| 未終了プロシージャ | 0 |
| Public重複 | 0 |
| 同一モジュール内重複 | 0 |
| プロシージャ外の不審な実行文 | 0 |
| If/For/Do/With/Selectブロック不整合 | 0 |
| 行継続異常 | 0 |
| 文字列クォート不整合 | 0 |
| OnAction/AddButton/OnKey未定義 | 0 |
| 未解決Call/裸Sub呼び出し候補 | 0 |
| Private関数の他モジュール跨ぎ呼び出し候補 | 0 |
| 0引数Subの括弧呼び出し候補 | 0 |
| IIf残存 | 0 |
| 高リスク非短絡評価 | 0 |
| Nothingガード非短絡リスク | 0 |
| 組込み名シャドーイング候補 | 0 |
| 成功通知MsgBox候補 | 0 |

## 非短絡評価の扱い

VBAの `And` / `Or` は短絡評価しないため、広めの候補抽出では 0 件をレビュー対象にしました。そのうち、`IsNumeric` 後の `CDbl`、`IsEmpty` 後の `CLng`、列番号ガード後の `Cells(r, col)`、Dictionary `.Exists` 後のItem参照など、実行時エラーへ直結し得る高リスク候補は修正後 0 件です。

## 一括取込・文字コード

- `IMPORT_03_MODULES.bat`: {'ascii': True, 'bytes': 372}
- `import/IMPORT_03_MODULES.bat`: {'ascii': True, 'bytes': 317}
- `import/IMPORT_03_MODULES.vbs`: {'bom': True, 'bytes': 19052, 'utf16le': True, 'adodb_stream': True, 'shift_jis': True, 'non_ascii_count': 0, 'removes_non_document_components': True}

`IMPORT_ORDER.txt` の不足: 0、余剰: 0

## 未実施

- 実機ExcelでのVBEコンパイル
- Windows上での一括取込実行
- 実Excel操作
- 印刷プレビュー
- 実データ通し検証

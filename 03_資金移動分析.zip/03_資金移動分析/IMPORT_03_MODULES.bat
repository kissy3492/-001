@echo off
setlocal
set "ROOT=%~dp0"
set "VBS=%ROOT%import\IMPORT_03_MODULES.vbs"
if not exist "%VBS%" (
  echo IMPORT_03_MODULES.vbs was not found.
  echo Folder: %ROOT%import
  pause
  exit /b 1
)
if "%~1"=="" (
  cscript //nologo "%VBS%"
) else (
  cscript //nologo "%VBS%" "%~1"
)
set "RC=%ERRORLEVEL%"
echo.
echo Exit code: %RC%
pause
exit /b %RC%

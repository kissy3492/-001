Attribute VB_Name = "modAnalysisAccountContext"
Option Explicit

'W_�������A����Ǎ����̕⊮�p�R���e�L�X�g�ɕϊ�����B
'������̐l��ID�E�����E��s��������ł��A����ID������S�ɕ⊮�ł���͈͂����₤�B
Public Function BuildAnalysisAccountContextIndex() As Object
    Dim d As Object, ws As Worksheet, lastR As Long, r As Long
    Dim colAcc As Long, colPerson As Long, colName As Long, colRel As Long
    Dim colBank As Long, colBranch As Long, colType As Long, colNo As Long, colStatus As Long
    Dim accountId As String, ctx As Object, statusText As String

    Set d = CreateObject("Scripting.Dictionary")
    If Not SheetExists(SH_WORK_ACCOUNT) Then
        Set BuildAnalysisAccountContextIndex = d
        Exit Function
    End If

    Set ws = GetSheet(SH_WORK_ACCOUNT)
    colAcc = FirstHeaderColumn(ws, Array("����ID"), 1)
    colPerson = FirstHeaderColumn(ws, Array("�l��ID"), 1)
    colName = FirstHeaderColumn(ws, Array("����", "�����\��", "�l����", "���`�l"), 1)
    colRel = FirstHeaderColumn(ws, Array("����", "�\���p����"), 1)
    colBank = FirstHeaderColumn(ws, Array("��s��", "���Z�@�֖�"), 1)
    colBranch = FirstHeaderColumn(ws, Array("�x�X��", "�X��"), 1)
    colType = FirstHeaderColumn(ws, Array("�Ȗ�", "�a�����", "���"), 1)
    colNo = FirstHeaderColumn(ws, Array("�����ԍ�", "����No", "�����m��"), 1)
    colStatus = FirstHeaderColumn(ws, Array("�f�[�^���", "���"), 1)

    If colAcc = 0 Then
        Set BuildAnalysisAccountContextIndex = d
        Exit Function
    End If

    lastR = LastRow(ws, colAcc)
    For r = 2 To lastR
        accountId = CellText(ws.Cells(r, colAcc).Value)
        If Len(accountId) > 0 Then
            statusText = ""
            If colStatus > 0 Then statusText = CellText(ws.Cells(r, colStatus).Value)
            If Not AnalysisAccountContextInactiveStatus(statusText) Then
                Set ctx = CreateObject("Scripting.Dictionary")
                ctx("PersonId") = AnalysisAccountContextCell(ws, r, colPerson)
                ctx("Name") = AnalysisAccountContextCell(ws, r, colName)
                ctx("Relation") = AnalysisAccountContextCell(ws, r, colRel)
                ctx("Bank") = AnalysisAccountContextCell(ws, r, colBank)
                ctx("Branch") = AnalysisAccountContextCell(ws, r, colBranch)
                ctx("AccountType") = AnalysisAccountContextCell(ws, r, colType)
                ctx("AccountNo") = AnalysisAccountContextCell(ws, r, colNo)
                If Not d.Exists(accountId) Then d.Add accountId, ctx
            End If
        End If
    Next r

    Set BuildAnalysisAccountContextIndex = d
End Function

Public Function AnalysisAccountContextValue(ByVal contextIndex As Object, ByVal accountId As String, ByVal keyText As String) As String
    Dim ctx As Object
    If contextIndex Is Nothing Then Exit Function
    accountId = CellText(accountId)
    If Len(accountId) = 0 Then Exit Function
    If Not contextIndex.Exists(accountId) Then Exit Function
    Set ctx = contextIndex(accountId)
    If ctx Is Nothing Then Exit Function
    If ctx.Exists(keyText) Then AnalysisAccountContextValue = CellText(ctx(keyText))
End Function

Private Function AnalysisAccountContextCell(ByVal ws As Worksheet, ByVal r As Long, ByVal c As Long) As String
    If c <= 0 Then
        AnalysisAccountContextCell = ""
    Else
        AnalysisAccountContextCell = CellText(ws.Cells(r, c).Value)
    End If
End Function

Private Function AnalysisAccountContextInactiveStatus(ByVal statusText As String) As Boolean
    statusText = Trim$(statusText)
    If Len(statusText) = 0 Then Exit Function
    AnalysisAccountContextInactiveStatus = (statusText = "���" Or statusText = "�폜" Or statusText = "����" Or statusText = "�ΏۊO")
End Function

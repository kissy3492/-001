@echo off
setlocal
set "VBS=%~dp0IMPORT_03_MODULES.vbs"
if not exist "%VBS%" (
  echo IMPORT_03_MODULES.vbs was not found.
  pause
  exit /b 1
)
if "%~1"=="" (
  cscript //nologo "%VBS%"
) else (
  cscript //nologo "%VBS%" "%~1"
)
set "RC=%ERRORLEVEL%"
echo.
echo Exit code: %RC%
pause
exit /b %RC%

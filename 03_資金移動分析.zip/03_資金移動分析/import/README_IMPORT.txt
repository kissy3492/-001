03 import script

1. Close the target 03 .xlsm file.
2. Drag and drop the target .xlsm file onto IMPORT_03_MODULES.bat.
3. The script creates a backup, removes old non-document VBA modules, imports the modules in modules\IMPORT_ORDER.txt, runs SetupWorkbook, refreshes button actions, and runs the self-check.

If VBA project access is denied, enable this Excel option:
File > Options > Trust Center > Trust Center Settings > Macro Settings > Trust access to the VBA project object model.

Notes:
- .bas and *_code.txt files are encoded in Shift-JIS for VBE import.
- Do not resave the module source files as UTF-8 before import.

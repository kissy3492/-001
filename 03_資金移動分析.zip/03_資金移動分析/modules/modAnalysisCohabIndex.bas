Attribute VB_Name = "modAnalysisCohabIndex"
Option Explicit

'�����y�A�����𕪐͖{�̂��番������B
'W_�����̌��o���h����z�����A�l�����œ����Ă���l���l��ID�֊񂹂�B
Public Function BuildAnalysisCohabPairIndex(ByVal personInfo As Object) As Object
    Dim dict As Object, ws As Worksheet, lastR As Long, r As Long, headerRow As Long
    Dim c1 As Long, c2 As Long, p1 As String, p2 As String

    Set dict = CreateObject("Scripting.Dictionary")
    If Not SheetExists(SH_WORK_COHAB) Then Set BuildAnalysisCohabPairIndex = dict: Exit Function

    Set ws = GetSheet(SH_WORK_COHAB)
    headerRow = DetectAnalysisCohabHeaderRow(ws)
    If headerRow = 0 Then Set BuildAnalysisCohabPairIndex = dict: Exit Function

    c1 = FirstHeaderColumn(ws, Array("�l��ID_A", "�l��AID", "�l��A�l��ID", "�l��A"), headerRow)
    c2 = FirstHeaderColumn(ws, Array("�l��ID_B", "�l��BID", "�l��B�l��ID", "�l��B"), headerRow)
    If c1 = 0 Or c2 = 0 Then Set BuildAnalysisCohabPairIndex = dict: Exit Function

    lastR = LastRow(ws, 1)
    For r = headerRow + 1 To lastR
        p1 = CoerceAnalysisPersonId(CellText(ws.Cells(r, c1).Value), personInfo)
        p2 = CoerceAnalysisPersonId(CellText(ws.Cells(r, c2).Value), personInfo)
        If Len(p1) > 0 And Len(p2) > 0 And p1 <> p2 Then dict(BuildPairKey(p1, p2)) = True
    Next r

    Set BuildAnalysisCohabPairIndex = dict
End Function

Private Function DetectAnalysisCohabHeaderRow(ByVal ws As Worksheet) As Long
    Dim rr As Long
    If ws Is Nothing Then Exit Function
    For rr = 1 To Application.Min(5, LastUsedRowInSheet(ws))
        If FirstHeaderColumn(ws, Array("�l��ID_A", "�l��AID", "�l��A�l��ID", "�l��A"), rr) > 0 _
                And FirstHeaderColumn(ws, Array("�l��ID_B", "�l��BID", "�l��B�l��ID", "�l��B"), rr) > 0 Then
            DetectAnalysisCohabHeaderRow = rr
            Exit Function
        End If
    Next rr
End Function

Private Function CoerceAnalysisPersonId(ByVal valueText As String, ByVal personInfo As Object) As String
    Dim k As Variant, info As Object, cleanValue As String, cleanName As String
    cleanValue = CellText(valueText)
    If Len(cleanValue) = 0 Then Exit Function

    If Not personInfo Is Nothing Then
        If personInfo.Exists(cleanValue) Then
            CoerceAnalysisPersonId = cleanValue
            Exit Function
        End If
        For Each k In personInfo.Keys
            Set info = personInfo(k)
            If Not info Is Nothing Then
                If info.Exists("Name") Then
                    cleanName = CellText(info("Name"))
                    If cleanName = cleanValue Then
                        CoerceAnalysisPersonId = CStr(k)
                        Exit Function
                    End If
                End If
            End If
        Next k
    End If

    CoerceAnalysisPersonId = cleanValue
End Function

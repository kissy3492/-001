Attribute VB_Name = "modAnalysisEngine"

Option Explicit



Private mTxById As Object

Private mMatched As Object

Private mDedupe As Object

Private mManualExcludedTxIds As Object

Private mManualVoucherOverrides As Object

Private mManualDecisionOverrides As Object

Private mManualMemoOverrides As Object

Private mCohabPairs As Object

Private mRelationPairs As Object

Private mMarriageByPerson As Object

Private mPersonInfo As Object

Private mAddressByPerson As Object

Private mTimeCluster As Object

Private mAccountOperationPatternCount As Object

Private mNextResultRow As Long

Private mNextDetailRow As Long

Private mDecedentId As String

Private mInheritanceDate As Variant

Private mMinShift As Double

Private mDateWindow As Long

Private mAmountTol As Double

Private mAmountRate As Double

Private mMaxCombo As Long

Private mMaxSideCandidates As Long

Private mUnknownThreshold As Double

Private mVoucherThreshold As Double

Private mEnableOneToOne As Boolean

Private mEnableOneToMany As Boolean

Private mEnableManyToOne As Boolean

Private mEnableManyToMany As Boolean

Private mEnableUnknowns As Boolean

Private mSuppressDuplicateShift As Boolean

Private mMaxResults As Long

Private mMaxCombosPerBase As Long

Private mMaxMtmPairTests As Long

Private mVoucherInheritanceAlways As Boolean

Private mVoucherUnknowns As Boolean

Private mExcludeSummaryKeywords As String

Private mStopIfTooBroad As Boolean

Private mFocusYears As Long

Private mMinScore As Long

Private mContextScore As Boolean

Private mStopRequested As Boolean

Private mResultCount As Long

Private mExcludedKeywordList As Variant
Private mDuplicateTxCount As Long
Private mBothAmountTxCount As Long
Private mMissingRequiredTxCount As Long
Private mManualExcludedTxCount As Long
Private mLoadedTxCount As Long
Private mEnhancedTagCount As Long
Private mContextCandidateCount As Long
Private mUnknownComboCount As Long
Private mUnknownComboPairTests As Long
Private mUnknownComboLimitReached As Boolean
Private mUnknownComboBuildLimitReached As Boolean
Private mUnknownComboPairLimitReached As Boolean



Public Sub RunAnalysis()
    Dim stepText As String, fatalText As String, diagText As String
    Dim errNum As Long, errDesc As String, errSrc As String
    Dim outs As Collection, ins As Collection, insByDate As Object, outByDate As Object
    Dim needCommonLoad As Boolean

    On Error GoTo EH

    stepText = "�ۑ���Ԋm�F"
    If Not RequireSavedWorkbook() Then Exit Sub

    stepText = "����Ǎ���Ԋm�F"
    needCommonLoad = False
    If Not SheetExists(SH_WORK_TX) Then
        needCommonLoad = True
    ElseIf LastRow(GetSheet(SH_WORK_TX), 1) < 2 Then
        needCommonLoad = True
    End If
    If needCommonLoad Then
        stepText = "���ʃf�[�^�Ǎ�"
        QuietInfo "����f�[�^���Ǎ��̂��߁A���ʃf�[�^�Ǎ����������s���܂��B", False, "���͎��s"
        LoadCommonData
    End If

    stepText = "���͑O���s�Q�[�g"
    If Not RequireAnalysisExecutionReady(True, False) Then
        QuietWarn "���͂��~�߂܂����BC_�`�F�b�N�ɓǍ��f�[�^�EID�����E�����������o���܂����B", False, "���͎��s"
        Exit Sub
    End If

    stepText = "���͑O�K�{�f�[�^����"
    fatalText = AnalysisFatalReadinessIssueText()
    If Len(fatalText) > 0 Then
        WriteAnalysisFatalCheck fatalText, stepText
        QuietWarn "���͂��~�߂܂����BC_�`�F�b�N�ɕs���V�[�g�E�s����E�����������o���܂����B", False, "���͎��s"
        Exit Sub
    End If

    stepText = "���͏���"
    AppBegin "�����ړ����͂����s��..."

    stepText = "�\���ҏW���f"
    ApplyVisibleTransactionDecisions True, False

    stepText = "����ID������"
    ResetAnalysisIds

    stepText = "�o�̓e�[�u��������"
    InitResultHeaders GetSheet(SH_WORK_RESULT)
    InitDetailHeaders GetSheet(SH_WORK_DETAIL)
    mNextResultRow = 2
    mNextDetailRow = 2

    stepText = "�����C���f�b�N�X������"
    Set mTxById = CreateObject("Scripting.Dictionary")
    Set mMatched = CreateObject("Scripting.Dictionary")
    Set mDedupe = CreateObject("Scripting.Dictionary")
    Set mManualExcludedTxIds = CreateObject("Scripting.Dictionary")
    Set mManualVoucherOverrides = CreateObject("Scripting.Dictionary")
    Set mManualDecisionOverrides = CreateObject("Scripting.Dictionary")
    Set mManualMemoOverrides = CreateObject("Scripting.Dictionary")

    stepText = "�蓮���f�Ǎ�"
    LoadManualExcludedTxIds mManualExcludedTxIds
    LoadManualStateOverrides mManualVoucherOverrides, mManualDecisionOverrides, mManualMemoOverrides

    stepText = "���͐ݒ�Ǎ�"
    ReadAnalysisSettings

    stepText = "���͍ޗ��C���f�b�N�X�쐬"
    Set mPersonInfo = BuildPersonInfoIndex()
    Set mAddressByPerson = BuildAddressByPersonIndex()
    Set mRelationPairs = BuildRelationPairIndex()
    Set mMarriageByPerson = BuildMarriageDateIndex()
    Set mCohabPairs = BuildCohabPairIndex()
    Set mTimeCluster = CreateObject("Scripting.Dictionary")
    Set mAccountOperationPatternCount = CreateObject("Scripting.Dictionary")

    stepText = "����R���N�V��������"
    Set outs = New Collection
    Set ins = New Collection
    Set insByDate = CreateObject("Scripting.Dictionary")
    Set outByDate = CreateObject("Scripting.Dictionary")

    stepText = "����Ǎ�"
    LoadTransactionRecords outs, ins, outByDate, insByDate

    stepText = "�c���E�O��֌W�t�^"
    EnrichTransactionAfterBalanceContext

    stepText = "�g�����������"
    If Not ValidateComplexityBeforeRun(outs.Count, ins.Count) Then GoTo SafeExit

    stepText = "��␶���p�C�v���C��"
    RunAnalysisCandidatePipeline outs, ins, outByDate, insByDate, _
        mEnableOneToOne, mEnableOneToMany, mEnableManyToOne, mEnableManyToMany, mEnableUnknowns

    stepText = "����^�O�\�\�z"
    BuildAnalysisTagPipeline outs, ins

    stepText = "���͏W�v�\�\�z"
    BuildAnalysisAggregateWorkSheet

SafeExit:
    stepText = "���̓^�O�\����"
    If Not mTxById Is Nothing Then
        If Not SheetExists(SH_WORK_TX_TAG) Then GetOrCreateSheet SH_WORK_TX_TAG, False
        If LastRow(GetSheet(SH_WORK_TX_TAG), 1) < 1 Then InitTransactionTagHeaders GetSheet(SH_WORK_TX_TAG), True
    End If

    stepText = "�\��2��ʍč\�z"
    BuildAnalysisResultSheet
    BuildInvestigationIssueSheet True
    BuildFlaggedTransactionSheet
    BuildFlagExtractSheet

    stepText = "���ʃf�[�^�ۑ�"
    If SettingYes(ROW_AUTO_SAVE_COMMON, True) Then SaveAnalysisToCommonData True

    stepText = "���͐f�f�L�^"
    WriteAnalysisRunDiagnosticCheck "�ʏ핪��"

    stepText = "��ʕ\������"
    If SettingYes(ROW_KEEP_OUTPUT_VISIBLE, True) Then ShowOutputSheets Else HideDailySheets False

    AppEnd
    AppendLog "���͎��s", "����", "��⌏��: " & CStr(Application.Max(0, LastRow(GetSheet(SH_WORK_RESULT), 1) - 1))

    diagText = AnalysisRunDiagnosticText()
    If Len(diagText) > 0 Then
        QuietWarn "���͂��������܂����B��⌏��: " & CStr(Application.Max(0, LastRow(GetSheet(SH_WORK_RESULT), 1) - 1)) & " / ����: " & diagText, True, "���͎��s"
    Else
        NotifyInfo "���͂��������܂����B" & vbCrLf & _
               "��⌏��: " & CStr(Application.Max(0, LastRow(GetSheet(SH_WORK_RESULT), 1) - 1))
    End If
    Exit Sub

EH:
    errNum = Err.Number: errDesc = Err.Description: errSrc = Err.Source
    On Error Resume Next
    AppEnd
    AppendLog "���͎��s", "���s", "�H��=" & stepText & " / " & errDesc
    WriteAnalysisFatalCheck "�H��=" & stepText & vbCrLf & "Err.Number=" & CStr(errNum) & vbCrLf & "Err.Source=" & errSrc & vbCrLf & "Err.Description=" & errDesc, "���͎��s���G���["
    On Error GoTo 0
    RuntimeShowErrorValues "RunAnalysis", "���͎��s - " & stepText, _
        "C_�`�F�b�N�ɒ�~�H���E�Ǎ��p�X�E�K�{�V�[�g/����o���܂����B", CommonDataPath(), errNum, errDesc, errSrc
End Sub



Public Sub AnalyzeUnknownFlagAmountCombinationsOnly()
    On Error GoTo EH

    If Not RequireSavedWorkbook() Then Exit Sub
    If Not SheetExists(SH_WORK_RESULT) Then
        QuietWarn "��ɒʏ�̕��͂����s���Ă��������B�s���o���E�s�������t���O���܂�����܂���B", False, "�s���g��������"
        Exit Sub
    ElseIf LastRow(GetSheet(SH_WORK_RESULT), RES_COL_ID) < 2 Then
        QuietWarn "��ɒʏ�̕��͂����s���Ă��������B�s���o���E�s�������t���O���܂�����܂���B", False, "�s���g��������"
        Exit Sub
    End If

    AppBegin "�s�����o���̋��z�g���������𕪐͒�..."
    PersistVisibleFlagSheetManualExclusions True

    Set mTxById = CreateObject("Scripting.Dictionary")
    Set mMatched = CreateObject("Scripting.Dictionary")
    Set mDedupe = CreateObject("Scripting.Dictionary")
    Set mManualExcludedTxIds = CreateObject("Scripting.Dictionary")
    Set mManualVoucherOverrides = CreateObject("Scripting.Dictionary")
    Set mManualDecisionOverrides = CreateObject("Scripting.Dictionary")
    Set mManualMemoOverrides = CreateObject("Scripting.Dictionary")
    LoadManualExcludedTxIds mManualExcludedTxIds
    LoadManualStateOverrides mManualVoucherOverrides, mManualDecisionOverrides, mManualMemoOverrides

    ReadAnalysisSettings
    Set mPersonInfo = BuildPersonInfoIndex()
    Set mAddressByPerson = BuildAddressByPersonIndex()
    Set mRelationPairs = BuildRelationPairIndex()
    Set mMarriageByPerson = BuildMarriageDateIndex()
    Set mCohabPairs = BuildCohabPairIndex()
    Set mTimeCluster = CreateObject("Scripting.Dictionary")
    Set mAccountOperationPatternCount = CreateObject("Scripting.Dictionary")

    Dim outs As Collection, ins As Collection, insByDate As Object, outByDate As Object
    Set outs = New Collection
    Set ins = New Collection
    Set insByDate = CreateObject("Scripting.Dictionary")
    Set outByDate = CreateObject("Scripting.Dictionary")
    LoadTransactionRecords outs, ins, outByDate, insByDate
    EnrichTransactionAfterBalanceContext

    RemoveUnknownComboCandidates

    mNextResultRow = LastRow(GetSheet(SH_WORK_RESULT), RES_COL_ID) + 1
    If mNextResultRow < 2 Then mNextResultRow = 2
    mNextDetailRow = LastRow(GetSheet(SH_WORK_DETAIL), DET_COL_ID) + 1
    If mNextDetailRow < 2 Then mNextDetailRow = 2

    RunUnknownFlagCombinationPipeline

    BuildAnalysisAggregateWorkSheet

    BuildAnalysisResultSheet
    BuildInvestigationIssueSheet True
    BuildFlaggedTransactionSheet
    BuildFlagExtractSheet
    If SettingYes(ROW_AUTO_SAVE_COMMON, True) Then SaveAnalysisToCommonData True
    WriteAnalysisRunDiagnosticCheck "�s�����o���g�����̂�"
    ShowOutputSheets

    AppEnd
    Dim diagText As String
    diagText = AnalysisRunDiagnosticText()
    If mUnknownComboCount > 0 Then
        If Len(diagText) > 0 Then
            QuietWarn "�s���o���E�s�������t���O�����ŁA���t�͈͂Ȃ��̋��z�g�������� " & CStr(mUnknownComboCount) & "���ǉ����܂����B����: " & diagText, True, "�s���g��������"
        Else
            NotifyInfo "�s���o���E�s�������t���O�����ŁA���t�͈͂Ȃ��̋��z�g�������� " & CStr(mUnknownComboCount) & " ���ǉ����܂����B"
        End If
    Else
        If Len(diagText) > 0 Then
            QuietWarn "�s���o���E�s�������t���O�����ň�v����V�K�̋��z�g�����͂���܂���ł����B����: " & diagText, True, "�s���g��������"
        Else
            NotifyInfo "�s���o���E�s�������t���O�����ň�v����V�K�̋��z�g�����͂���܂���ł����B"
        End If
    End If
    Exit Sub
EH:
    AppEnd
    RuntimeShowError "AnalyzeUnknownFlagAmountCombinationsOnly", "�s�����o���g����", "�s���o���E�s�������t���O�A�蓮���O�A���z���e�����m�F���Ă��������B"
End Sub

Private Sub RemoveUnknownComboCandidates()
    Dim wsRes As Worksheet, wsDet As Worksheet, idSet As Object
    Dim lastR As Long, r As Long, analysisId As String

    If Not SheetExists(SH_WORK_RESULT) Then Exit Sub
    If Not SheetExists(SH_WORK_DETAIL) Then Exit Sub
    Set idSet = CreateObject("Scripting.Dictionary")
    Set wsRes = GetSheet(SH_WORK_RESULT)
    Set wsDet = GetSheet(SH_WORK_DETAIL)

    lastR = LastRow(wsRes, RES_COL_ID)
    For r = lastR To 2 Step -1
        If CellText(wsRes.Cells(r, RES_COL_KIND).Value) = KIND_UNKNOWN_COMBO Then
            analysisId = CellText(wsRes.Cells(r, RES_COL_ID).Value)
            If Len(analysisId) > 0 Then idSet(analysisId) = True
            wsRes.Rows(r).Delete
        End If
    Next r

    lastR = LastRow(wsDet, DET_COL_ID)
    For r = lastR To 2 Step -1
        analysisId = CellText(wsDet.Cells(r, DET_COL_ANALYSIS_ID).Value)
        If idSet.Exists(analysisId) Then
            wsDet.Rows(r).Delete
        ElseIf CellText(wsDet.Cells(r, DET_COL_KIND).Value) = KIND_UNKNOWN_COMBO Then
            wsDet.Rows(r).Delete
        End If
    Next r

    If SheetExists(SH_WORK_UNKNOWN_COMBO) Then InitUnknownComboHeaders GetSheet(SH_WORK_UNKNOWN_COMBO), True
End Sub

Private Sub ReadAnalysisSettings()

    mDecedentId = CellText(GetSheet(SH_MAIN).Cells(ROW_DECEDENT_ID, COL_VALUE).Value)

    If IsDate(GetSheet(SH_MAIN).Cells(ROW_INHERITANCE_DATE, COL_VALUE).Value) Then

        mInheritanceDate = CDate(GetSheet(SH_MAIN).Cells(ROW_INHERITANCE_DATE, COL_VALUE).Value)

    Else

        mInheritanceDate = Empty

    End If

    mMinShift = GetSettingDouble(ROW_MIN_SHIFT_AMOUNT, DEFAULT_MIN_SHIFT_AMOUNT)

    mDateWindow = GetSettingLong(ROW_DATE_WINDOW, DEFAULT_DATE_WINDOW)

    mAmountTol = GetSettingDouble(ROW_AMOUNT_TOLERANCE, DEFAULT_AMOUNT_TOLERANCE)

    mAmountRate = NzDbl(GetSheet(SH_MAIN).Cells(ROW_AMOUNT_TOLERANCE_RATE, COL_VALUE).Value, DEFAULT_AMOUNT_TOLERANCE_RATE)

    mMaxCombo = GetSettingLong(ROW_MAX_COMBO, DEFAULT_MAX_COMBO)

    If mMaxCombo < 1 Then mMaxCombo = 1

    If mMaxCombo > MAX_ALLOWED_COMBO Then mMaxCombo = MAX_ALLOWED_COMBO

    mMaxSideCandidates = GetSettingLong(ROW_MAX_SIDE_CANDIDATES, DEFAULT_MAX_SIDE_CANDIDATES)

    If mMaxSideCandidates < 3 Then mMaxSideCandidates = 3

    If mMaxSideCandidates > 18 Then mMaxSideCandidates = 18

    mUnknownThreshold = GetSettingDouble(ROW_UNKNOWN_THRESHOLD, DEFAULT_UNKNOWN_THRESHOLD)

    mVoucherThreshold = GetSettingDouble(ROW_VOUCHER_THRESHOLD, DEFAULT_VOUCHER_THRESHOLD)

    mEnableOneToOne = SettingYes(ROW_ENABLE_ONE_TO_ONE, True)

    mEnableOneToMany = SettingYes(ROW_ENABLE_ONE_TO_MANY, True)

    mEnableManyToOne = SettingYes(ROW_ENABLE_MANY_TO_ONE, True)

    mEnableManyToMany = SettingYes(ROW_ENABLE_MANY_TO_MANY, True)

    mEnableUnknowns = SettingYes(ROW_ENABLE_UNKNOWNS, True)

    mSuppressDuplicateShift = SettingYes(ROW_SUPPRESS_DUPLICATE_SHIFT, True)

    mMaxResults = GetSettingLong(ROW_MAX_RESULTS, DEFAULT_MAX_RESULTS)

    If mMaxResults < 100 Then mMaxResults = 100

    If mMaxResults > 50000 Then mMaxResults = 50000

    mMaxCombosPerBase = GetSettingLong(ROW_MAX_COMBOS_PER_BASE, DEFAULT_MAX_COMBOS_PER_BASE)

    If mMaxCombosPerBase < 50 Then mMaxCombosPerBase = 50

    If mMaxCombosPerBase > 5000 Then mMaxCombosPerBase = 5000

    mMaxMtmPairTests = GetSettingLong(ROW_MAX_MTM_PAIR_TESTS, DEFAULT_MAX_MTM_PAIR_TESTS)

    If mMaxMtmPairTests < 1000 Then mMaxMtmPairTests = 1000

    If mMaxMtmPairTests > 300000 Then mMaxMtmPairTests = 300000

    mVoucherInheritanceAlways = SettingYes(ROW_VOUCHER_INHERITANCE_ALWAYS, True)

    mVoucherUnknowns = SettingYes(ROW_VOUCHER_UNKNOWNS, True)

    mExcludeSummaryKeywords = CellText(GetSheet(SH_MAIN).Cells(ROW_EXCLUDE_SUMMARY_KEYWORDS, COL_VALUE).Value)

    mStopIfTooBroad = SettingYes(ROW_STOP_IF_TOO_BROAD, True)

    mFocusYears = GetSettingLong(ROW_INHERITANCE_FOCUS_YEARS, DEFAULT_INHERITANCE_FOCUS_YEARS)

    If mFocusYears < 1 Then mFocusYears = DEFAULT_INHERITANCE_FOCUS_YEARS

    If mFocusYears > 20 Then mFocusYears = 20

    mMinScore = GetSettingLong(ROW_MIN_SCORE, DEFAULT_MIN_SCORE)

    If mMinScore < 0 Then mMinScore = 0

    If mMinScore > 100 Then mMinScore = 100

    mContextScore = SettingYes(ROW_CONTEXT_SCORE, True)

    mExcludedKeywordList = SplitExcludeKeywords(mExcludeSummaryKeywords)

    mStopRequested = False

    mResultCount = 0
    mDuplicateTxCount = 0
    mBothAmountTxCount = 0
    mMissingRequiredTxCount = 0
    mManualExcludedTxCount = 0
    mLoadedTxCount = 0
    mEnhancedTagCount = 0
    mContextCandidateCount = 0
    mUnknownComboCount = 0
    mUnknownComboPairTests = 0
    mUnknownComboLimitReached = False
    mUnknownComboBuildLimitReached = False
    mUnknownComboPairLimitReached = False

End Sub



Public Function AnalysisRunDiagnosticText() As String
    Dim msg As String
    If mMissingRequiredTxCount > 0 Then msg = JoinNonBlank(msg, "���ID�܂��͓��t�s�� " & CStr(mMissingRequiredTxCount) & "�������O", " / ")
    If mDuplicateTxCount > 0 Then msg = JoinNonBlank(msg, "�d�����ID " & CStr(mDuplicateTxCount) & "�������O", " / ")
    If mBothAmountTxCount > 0 Then msg = JoinNonBlank(msg, "�o���E������������ " & CStr(mBothAmountTxCount) & "�������O", " / ")
    If mManualExcludedTxCount > 0 Then msg = JoinNonBlank(msg, "�蓮������O " & CStr(mManualExcludedTxCount) & "����K�p", " / ")
    If mEnhancedTagCount > 0 Then msg = JoinNonBlank(msg, "�C�x���g�E����ގ��^�O " & CStr(mEnhancedTagCount) & "���", " / ")
    If mContextCandidateCount > 0 Then msg = JoinNonBlank(msg, "�����P�ƌ�� " & CStr(mContextCandidateCount) & "����ǉ�", " / ")
    If mUnknownComboCount > 0 Then msg = JoinNonBlank(msg, "�s�����o���g���� " & CStr(mUnknownComboCount) & "����ǉ��i���t�͈͂Ȃ��j", " / ")
    If mUnknownComboBuildLimitReached Then msg = JoinNonBlank(msg, "�s���g�����̕Б��g����������� " & CStr(mMaxCombosPerBase) & "���ɓ��B�i�������̑g��������j", " / ")
    If mUnknownComboPairLimitReached Then msg = JoinNonBlank(msg, "�s���g�����̏ƍ���� " & CStr(mMaxMtmPairTests) & "�g�ɓ��B�i�������̑g��������j", " / ")
    If mUnknownComboLimitReached And Not mUnknownComboBuildLimitReached And Not mUnknownComboPairLimitReached Then msg = JoinNonBlank(msg, "�s���g��������ɓ��B�i�������̑g��������j", " / ")
    If mStopRequested Then msg = JoinNonBlank(msg, "���\����� " & CStr(mMaxResults) & "���ɓ��B�i���ʌ��͖��\���j", " / ")
    AnalysisRunDiagnosticText = msg
End Function

Private Sub WriteAnalysisRunDiagnosticCheck(ByVal runModeText As String)
    Dim wsC As Worksheet, outR As Long, candidateCount As Long, detailCount As Long, tagCount As Long
    Dim personRows As Long, accountRows As Long, txRows As Long, addressRows As Long, cohabRows As Long, marriageRows As Long, msg As String
    On Error GoTo EH
    Set wsC = GetSheet(SH_CHECK)
    wsC.Cells.Clear
    SetRowValues wsC.Range("A1"), Array("�敪", "���e", "�Ή�")
    FormatHeader wsC.Range("A1:C1"), ThemeColor("header")
    outR = 2

    candidateCount = SheetDataCount(SH_WORK_RESULT, RES_COL_ID)
    detailCount = SheetDataCount(SH_WORK_DETAIL, DET_COL_ID)
    tagCount = SheetDataCount(SH_WORK_TX_TAG, 1)
    personRows = SheetDataCount(SH_WORK_PERSON, 1)
    accountRows = SheetDataCount(SH_WORK_ACCOUNT, 1)
    txRows = SheetDataCount(SH_WORK_TX, 1)
    addressRows = SheetDataCount(SH_WORK_ADDRESS, 1)
    cohabRows = SheetDataCount(SH_WORK_COHAB, 1)
    marriageRows = SheetDataCount(SH_WORK_MARRIAGE_HIST, 1)

    AddAnalysisRunCheck wsC, outR, "�m�F", "���̓��[�h", runModeText
    AddAnalysisRunCheck wsC, outR, "�m�F", "�Ǎ��p�X", CommonDataPath()
    AddAnalysisRunCheck wsC, outR, "�m�F", "�Ǎ�����", "�l�� " & CStr(personRows) & " / �������� " & CStr(marriageRows) & " / ���� " & CStr(accountRows) & " / ��� " & CStr(txRows) & " / �Z�� " & CStr(addressRows) & " / ���� " & CStr(cohabRows)
    AddAnalysisRunCheck wsC, outR, "�m�F", "���͌���", "��� " & CStr(candidateCount) & " / ���� " & CStr(detailCount) & " / ����^�O " & CStr(tagCount) & " / �Ǎ��Ώێ�� " & CStr(mLoadedTxCount)
    AddAnalysisRunCheck wsC, outR, "�m�F", "�g�p�ޗ�", "�l���E�����E�����E�Z���E�����E�N��E�����сE�戵�X�E�c���E���z������Ǎ��Ώۂɂ��Ă��܂��B����0�̍ޗ��͔���Ɏg���Ă��܂���B"
    AppendAnalysisRuleCatalogChecks wsC, outR
    AppendAnalysisPipelineQualityChecks wsC, outR

    If mMissingRequiredTxCount > 0 Then AddAnalysisRunCheck wsC, outR, "�x��", "�K�{���s���̎�������O", CStr(mMissingRequiredTxCount) & "���BT_����̎��ID/���t���m�F���Ă��������B"
    If mDuplicateTxCount > 0 Then AddAnalysisRunCheck wsC, outR, "�x��", "�d�����ID�����O", CStr(mDuplicateTxCount) & "���B02���ŏd���]�L/���ʕۑ����m�F���Ă��������B"
    If mBothAmountTxCount > 0 Then AddAnalysisRunCheck wsC, outR, "�x��", "�o���E�������������͂̎�������O", CStr(mBothAmountTxCount) & "���B���\�̗񂸂�╄�����m�F���Ă��������B"
    If mManualExcludedTxCount > 0 Then AddAnalysisRunCheck wsC, outR, "�m�F", "�蓮���O��K�p", CStr(mManualExcludedTxCount) & "���B���O�����{�^���Ŗ߂��܂��B"
    If mStopRequested Then AddAnalysisRunCheck wsC, outR, "�x��", "���\������ɓ��B", "�ő� " & CStr(mMaxResults) & "���Œ�~�B���ʌ��͖��\���ł��B�����܂��͏�����������Ă��������B"
    If mUnknownComboBuildLimitReached Then AddAnalysisRunCheck wsC, outR, "�x��", "�s���g�����̐�������ɓ��B", "���������� " & CStr(mMaxCombosPerBase) & "���B�������̑g����������܂��B"
    If mUnknownComboPairLimitReached Then AddAnalysisRunCheck wsC, outR, "�x��", "�s���g�����̏ƍ�����ɓ��B", CStr(mMaxMtmPairTests) & "�g�Œ�~�B�������̑g����������܂��B"
    If mUnknownComboLimitReached And Not mUnknownComboBuildLimitReached And Not mUnknownComboPairLimitReached Then AddAnalysisRunCheck wsC, outR, "�x��", "�s���g�����̏���ɓ��B", "�������̑g����������܂��B"

    msg = AnalysisRunDiagnosticText()
    If Len(msg) = 0 Then
        AddAnalysisRunCheck wsC, outR, "OK", "���͐f�f", "������B�E�������E���O�x���͂���܂���B"
    Else
        AddAnalysisRunCheck wsC, outR, "�m�F", "���͐f�f�v��", msg
    End If

    FormatBody wsC.Range("A2:C" & CStr(Application.Max(2, outR - 1)))
    AutoFitSheetSmart wsC, "A:C", 8, 80
    wsC.Visible = xlSheetHidden
    Exit Sub
EH:
    '�f�f�L�^�̎��s�ŕ��͌��ʎ��̂��󂳂Ȃ��B
End Sub

Private Sub AddAnalysisRunCheck(ByVal ws As Worksheet, ByRef outR As Long, ByVal kindText As String, ByVal contentText As String, ByVal actionText As String)
    ws.Cells(outR, 1).Value = kindText
    ws.Cells(outR, 2).Value = contentText
    ws.Cells(outR, 3).Value = actionText
    Select Case kindText
        Case "�x��": ws.Range(ws.Cells(outR, 1), ws.Cells(outR, 3)).Interior.Color = ThemeColor("warning-soft")
        Case "�G���[": ws.Range(ws.Cells(outR, 1), ws.Cells(outR, 3)).Interior.Color = ThemeColor("danger-soft")
        Case Else: ws.Range(ws.Cells(outR, 1), ws.Cells(outR, 3)).Interior.Color = ThemeColor("success-bg")
    End Select
    outR = outR + 1
End Sub

Private Function SheetDataCount(ByVal sheetName As String, ByVal keyCol As Long) As Long
    If Not SheetExists(sheetName) Then Exit Function
    SheetDataCount = Application.Max(0, LastRow(GetSheet(sheetName), keyCol) - 1)
End Function



Public Sub LoadManualExcludedTxIds(ByVal dict As Object)

    Dim ws As Worksheet, lastR As Long, r As Long, txId As String

    If dict Is Nothing Then Exit Sub

    If Not SheetExists(SH_MANUAL_EXCLUDE) Then Exit Sub

    Set ws = GetSheet(SH_MANUAL_EXCLUDE)

    lastR = LastRow(ws, 1)

    For r = 2 To lastR

        txId = CellText(ws.Cells(r, 1).Value)

        If Len(txId) > 0 Then

            If Not dict.Exists(txId) Then dict.Add txId, True

        End If

    Next r

End Sub





Private Sub LoadManualStateOverrides(ByVal voucherDict As Object, ByVal decisionDict As Object, ByVal memoDict As Object)

    Dim ws As Worksheet, lastR As Long, r As Long, k As String

    If voucherDict Is Nothing Then Exit Sub
    If decisionDict Is Nothing Then Exit Sub
    If memoDict Is Nothing Then Exit Sub

    If Not SheetExists(SH_MANUAL_STATE) Then Exit Sub

    Set ws = GetSheet(SH_MANUAL_STATE)

    lastR = LastRow(ws, 1)

    For r = 2 To lastR

        k = CellText(ws.Cells(r, 1).Value)

        If Len(k) > 0 Then

            If Len(CellText(ws.Cells(r, 3).Value)) > 0 Then voucherDict(k) = CellText(ws.Cells(r, 3).Value)

            If Len(CellText(ws.Cells(r, 4).Value)) > 0 Then decisionDict(k) = CellText(ws.Cells(r, 4).Value)

            If Len(CellText(ws.Cells(r, 5).Value)) > 0 Then memoDict(k) = CellText(ws.Cells(r, 5).Value)

        End If

    Next r

End Sub



Private Sub LoadTransactionRecords(ByRef outs As Collection, ByRef ins As Collection, ByRef outByDate As Object, ByRef insByDate As Object)

    Dim ws As Worksheet, lastR As Long, r As Long, data As Variant

    Dim colTx As Long, colAcc As Long, colPerson As Long, colName As Long, colRel As Long

    Dim colBank As Long, colBranch As Long, colType As Long, colNo As Long, colDate As Long, colTime As Long

    Dim colOut As Long, colIn As Long, colShop As Long, colShopFilled As Long, colShopConverted As Long, colShopFinal As Long

    Dim colSummary As Long, colOther As Long, colAfterBalance As Long, colAfterBalanceRaw As Long

    Dim colRowKind As Long, colStatus As Long

    Dim d As Object, txDate As Variant, outAmt As Double, inAmt As Double, dateKey As String, afterBalanceValue As Variant
    Dim accountContext As Object, accountIdText As String, personIdText As String
    Dim nameText As String, relationText As String, bankText As String, branchText As String, typeText As String, accountNoText As String
    Set accountContext = BuildAnalysisAccountContextIndex()

    Set ws = GetSheet(SH_WORK_TX)

    colTx = FirstHeaderColumn(ws, Array("���ID"), 1)

    colAcc = FirstHeaderColumn(ws, Array("����ID"), 1)

    colPerson = FirstHeaderColumn(ws, Array("�l��ID"), 1)

    colName = FirstHeaderColumn(ws, Array("����", "�����\��", "�l����", "���`�l", "���`�l��", "������`"), 1)

    colRel = FirstHeaderColumn(ws, Array("����"), 1)

    colBank = FirstHeaderColumn(ws, Array("��s��", "���Z�@�֖�", "��s", "���Z�@��"), 1)

    colBranch = FirstHeaderColumn(ws, Array("�x�X��", "�X��", "�x�X", "�戵�X", "�X�ܖ�"), 1)

    colType = FirstHeaderColumn(ws, Array("�Ȗ�", "�a�����", "���", "�������"), 1)

    colNo = FirstHeaderColumn(ws, Array("�����ԍ�", "����No", "�����m��", "����NO", "����No.", "�����ԍ����K��"), 1)

    colDate = FirstHeaderColumn(ws, Array("���t", "�����", "����N����", "�N����", "�������", "������", "�����"), 1)

    colTime = FirstHeaderColumn(ws, Array("����", "�������", "����", "�������", "���������"), 1)

    colOut = FirstHeaderColumn(ws, Array("�o��", "�o���z", "�x���z", "���x��", "���ߋ��z", "�����z"), 1)

    colIn = FirstHeaderColumn(ws, Array("����", "�����z", "�a���z", "�a�����z", "���a��", "���a����"), 1)

    colShop = FirstHeaderColumn(ws, Array("�戵�X����", "�戵�X", "�戵�X�R�[�h", "�X��", "�X��"), 1)

    colShopFilled = FirstHeaderColumn(ws, Array("�戵�X�⊮�l"), 1)

    colShopConverted = FirstHeaderColumn(ws, Array("�戵�X�ϊ���"), 1)

    colShopFinal = FirstHeaderColumn(ws, Array("�戵�X�m��l"), 1)

    colSummary = FirstHeaderColumn(ws, Array("�E�v", "�E�v��", "��������e", "���e", "������e", "���l", "����"), 1)

    colOther = FirstHeaderColumn(ws, Array("���̑�", "���l", "����"), 1)
    colAfterBalance = FirstHeaderColumn(ws, Array("�����c��", "�c��", "�������c��", "�����̎c��", "���ݎc��"), 1)
    colAfterBalanceRaw = FirstHeaderColumn(ws, Array("�����c������"), 1)

    colRowKind = FirstHeaderColumn(ws, Array("���s���", "�s���"), 1)

    colStatus = FirstHeaderColumn(ws, Array("�f�[�^���", "���"), 1)



    If colTx = 0 Or colDate = 0 Or colOut = 0 Or colIn = 0 Then Err.Raise vbObjectError + 9501, "LoadTransactionRecords", "T_����̕K�{�񂪕s�����Ă��܂��B"



    lastR = LastRow(ws, colTx)

    If lastR < 2 Then Exit Sub

    data = ws.Range(ws.Cells(1, 1), ws.Cells(lastR, LastUsedColumnFast(ws))).Value



    For r = 2 To UBound(data, 1)

        If colRowKind > 0 Then

            If Len(CellText(ArrayCell(data, r, colRowKind))) > 0 And CellText(ArrayCell(data, r, colRowKind)) <> "���" Then GoTo NextTransactionRecord

        End If

        If colStatus > 0 Then

            If IsInactiveTransactionStatus(CellText(ArrayCell(data, r, colStatus))) Then GoTo NextTransactionRecord

        End If

        txDate = ToDateOrEmpty(ArrayCell(data, r, colDate))

        outAmt = NzDbl(ArrayCell(data, r, colOut), 0)

        inAmt = NzDbl(ArrayCell(data, r, colIn), 0)

        If Len(CellText(ArrayCell(data, r, colTx))) = 0 Then
            If outAmt > 0 Or inAmt > 0 Then mMissingRequiredTxCount = mMissingRequiredTxCount + 1
            GoTo NextTransactionRecord
        End If
        If Not IsDate(txDate) Then
            If outAmt > 0 Or inAmt > 0 Then mMissingRequiredTxCount = mMissingRequiredTxCount + 1
            GoTo NextTransactionRecord
        End If

        Set d = CreateObject("Scripting.Dictionary")

            d("Row") = r

            d("TxId") = CellText(ArrayCell(data, r, colTx))

            accountIdText = ArrayText(data, r, colAcc)
            personIdText = ArrayText(data, r, colPerson)
            nameText = ArrayText(data, r, colName)
            relationText = ArrayText(data, r, colRel)
            bankText = ArrayText(data, r, colBank)
            branchText = ArrayText(data, r, colBranch)
            typeText = ArrayText(data, r, colType)
            accountNoText = ArrayText(data, r, colNo)

            If Len(personIdText) = 0 Then personIdText = AnalysisAccountContextValue(accountContext, accountIdText, "PersonId")
            If Len(nameText) = 0 Then nameText = AnalysisAccountContextValue(accountContext, accountIdText, "Name")
            If Len(relationText) = 0 Then relationText = AnalysisAccountContextValue(accountContext, accountIdText, "Relation")
            If Len(bankText) = 0 Then bankText = AnalysisAccountContextValue(accountContext, accountIdText, "Bank")
            If Len(branchText) = 0 Then branchText = AnalysisAccountContextValue(accountContext, accountIdText, "Branch")
            If Len(typeText) = 0 Then typeText = AnalysisAccountContextValue(accountContext, accountIdText, "AccountType")
            If Len(accountNoText) = 0 Then accountNoText = AnalysisAccountContextValue(accountContext, accountIdText, "AccountNo")

            d("AccountId") = accountIdText

            d("PersonId") = personIdText

            d("Name") = nameText

            d("Relation") = relationText

            d("Bank") = bankText

            d("Branch") = branchText

            d("AccountType") = typeText

            d("AccountNo") = accountNoText

            d("Date") = DateValue(CDate(txDate))

            d("DateKey") = CStr(DateOnlySerial(CDate(txDate)))

            ApplyRecordTimeFields d, ArrayCell(data, r, colTime), r

            EnrichTransactionContext d

            d("Out") = outAmt

            d("In") = inAmt

            d("Shop") = GetFinalShopFromArray(data, r, colShopFinal, colShopConverted, colShopFilled, colShop, colBranch)
            If Len(CStr(d("Shop"))) = 0 Then d("Shop") = branchText

            d("Summary") = ArrayText(data, r, colSummary)

            d("Other") = ArrayText(data, r, colOther)
            d("BalanceAfterRaw") = ArrayText(data, r, colAfterBalanceRaw)
            afterBalanceValue = TransactionAfterBalanceValue(ArrayCell(data, r, colAfterBalance))
            If Len(CellText(afterBalanceValue)) > 0 Then
                d("BalanceAfter") = CDbl(afterBalanceValue)
                d("BalanceAfterSource") = "�����c��"
            ElseIf colAfterBalance = 0 And Len(CellText(TransactionAfterBalanceValue(d("Other")))) > 0 Then
                '����݊��p�B��22��̋��ʃf�[�^�����A���̑����������c���Ƃ��ēǂށB
                d("BalanceAfter") = CDbl(TransactionAfterBalanceValue(d("Other")))
                d("BalanceAfterSource") = "���`�����̑���"
            End If

            If IsExcludedTransaction(d) Then
                mManualExcludedTxCount = mManualExcludedTxCount + 1
                GoTo NextTransactionRecord
            End If

            If outAmt > 0 And inAmt > 0 Then
                mBothAmountTxCount = mBothAmountTxCount + 1
                GoTo NextTransactionRecord
            End If

            If mTxById.Exists(d("TxId")) Then
                mDuplicateTxCount = mDuplicateTxCount + 1
                GoTo NextTransactionRecord
            Else
                mTxById.Add d("TxId"), d
                mLoadedTxCount = mLoadedTxCount + 1
            End If

            If outAmt > 0 Or inAmt > 0 Then AddTimeClusterRecord d

            dateKey = d("DateKey")

            If outAmt > 0 Then

                outs.Add d

                AddToDateIndex outByDate, dateKey, d

            End If

            If inAmt > 0 Then

                ins.Add d

                AddToDateIndex insByDate, dateKey, d

            End If

NextTransactionRecord:

    Next r

    If mMissingRequiredTxCount > 0 Then AppendLog "����Ǎ�", "�m�F", "���ID�܂��͓��t�s�� " & CStr(mMissingRequiredTxCount) & "�����������͂���u�����܂����B"
    If mDuplicateTxCount > 0 Then AppendLog "����Ǎ�", "�m�F", "���ID�d�� " & CStr(mDuplicateTxCount) & "�����������͂���u�����܂����B02���ŋ��ʃf�[�^�ۑ����Ď��s���Ă��������B"
    If mBothAmountTxCount > 0 Then AppendLog "����Ǎ�", "�m�F", "�o���E�����������v���X�̍s " & CStr(mBothAmountTxCount) & "�����������͂���u�����܂����B"
    If mManualExcludedTxCount > 0 Then AppendLog "����Ǎ�", "�m�F", "�蓮�Ŏ�����O���ꂽ�s " & CStr(mManualExcludedTxCount) & "���𕪐͑Ώۂ���O���܂����B"

End Sub



Private Function ArrayCell(ByRef data As Variant, ByVal r As Long, ByVal c As Long) As Variant

    If c <= 0 Then

        ArrayCell = Empty

    ElseIf c > UBound(data, 2) Then

        ArrayCell = Empty

    Else

        ArrayCell = data(r, c)

    End If

End Function



Private Function ArrayText(ByRef data As Variant, ByVal r As Long, ByVal c As Long) As String

    ArrayText = CellText(ArrayCell(data, r, c))

End Function

Private Function IsInactiveTransactionStatus(ByVal statusText As String) As Boolean
    statusText = Trim$(statusText)
    If Len(statusText) = 0 Then Exit Function
    IsInactiveTransactionStatus = (statusText = "���" Or statusText = "�폜" Or statusText = "����" Or statusText = "�ΏۊO")
End Function




Private Function GetCellByCol(ByVal ws As Worksheet, ByVal r As Long, ByVal c As Long) As String
    If c <= 0 Then
        GetCellByCol = ""
    Else
        GetCellByCol = CellText(ws.Cells(r, c).Value)
    End If
End Function

Private Function LastUsedColumnFast(ByVal ws As Worksheet) As Long

    Dim f As Range

    On Error Resume Next

    Set f = ws.Cells.Find(What:="*", After:=ws.Cells(1, 1), LookIn:=xlFormulas, LookAt:=xlPart, SearchOrder:=xlByColumns, SearchDirection:=xlPrevious)

    On Error GoTo 0

    If f Is Nothing Then

        LastUsedColumnFast = 1

    Else

        LastUsedColumnFast = f.Column

    End If

End Function



Private Sub ApplyRecordTimeFields(ByVal rec As Object, ByVal timeValue As Variant, ByVal inputOrder As Long)

    Dim t As Variant

    t = TimeFractionOrEmpty(timeValue)

    If IsEmpty(t) Then

        rec("HasTime") = False

        rec("TimeQuality") = "�����Ȃ�"

        rec("TimeFraction") = 0#

        '�����Ȃ��� 0:00 / �����Ɋ񂹂Ȃ��B���t�{���ד������ł������ׁA���������͒f�肵�Ȃ��B
        rec("DateTimeSort") = CDbl(DateOnlySerial(rec("Date"))) + InputOrderFraction(inputOrder)

    Else

        rec("HasTime") = True

        rec("TimeQuality") = "��������"

        rec("TimeFraction") = CDbl(t)

        rec("DateTimeSort") = CDbl(DateOnlySerial(rec("Date"))) + CDbl(t)

    End If

    rec("InputOrder") = inputOrder

End Sub

Private Function InputOrderFraction(ByVal inputOrder As Long) As Double

    If inputOrder <= 0 Then Exit Function

    InputOrderFraction = CDbl(inputOrder Mod 100000) / 100000000#

End Function




Private Sub EnrichTransactionContext(ByVal rec As Object)

    Dim personId As String, txDate As Date, ageYears As Long

    If rec Is Nothing Then Exit Sub

    rec("AgeAtTx") = ""

    rec("AgeYearsAtTx") = -1

    rec("AddressAtTx") = ""

    rec("AddressKeyAtTx") = ""

    rec("AddressChangeNearTx") = ""
    rec("RelatedMoveNearTx") = ""

    personId = CStr(rec("PersonId"))

    If Len(personId) = 0 Then Exit Sub
    If Not IsDate(rec("Date")) Then Exit Sub

    txDate = CDate(rec("Date"))

    rec("AgeAtTx") = PersonAgeAtDate(personId, txDate)

    ageYears = PersonAgeYearsAtDate(personId, txDate)

    rec("AgeYearsAtTx") = ageYears

    rec("AddressAtTx") = PersonAddressAtDate(personId, txDate, False)

    rec("AddressKeyAtTx") = PersonAddressAtDate(personId, txDate, True)

    rec("AddressChangeNearTx") = AddressChangeNearDate(personId, txDate, DEFAULT_MOVE_NEAR_WINDOW_DAYS)

    rec("RelatedMoveNearTx") = RelatedMoveNearTransaction(personId, txDate, DEFAULT_MOVE_NEAR_WINDOW_DAYS)

End Sub

Private Sub AddTimeClusterRecord(ByVal rec As Object)

    Dim k As String, col As Collection

    If rec Is Nothing Then Exit Sub

    If mTimeCluster Is Nothing Then Set mTimeCluster = CreateObject("Scripting.Dictionary")

    k = TimeClusterKey(rec)

    If Len(k) = 0 Then Exit Sub

    If mTimeCluster.Exists(k) Then

        Set col = mTimeCluster(k)

    Else

        Set col = New Collection

        mTimeCluster.Add k, col

    End If

    UpdateAccountOperationPatternCount col, rec

    col.Add rec

End Sub

Private Sub UpdateAccountOperationPatternCount(ByVal existingRecords As Collection, ByVal rec As Object)

    Dim other As Object, acc As String, otherAcc As String, personId As String, otherPersonId As String

    If existingRecords Is Nothing Then Exit Sub

    If rec Is Nothing Then Exit Sub

    acc = CStr(rec("AccountId"))

    personId = CStr(rec("PersonId"))

    If Len(acc) = 0 Then Exit Sub

    If mAccountOperationPatternCount Is Nothing Then Set mAccountOperationPatternCount = CreateObject("Scripting.Dictionary")

    For Each other In existingRecords

        otherAcc = CStr(other("AccountId"))

        otherPersonId = CStr(other("PersonId"))

        If Len(otherAcc) > 0 Then

            If otherAcc <> acc Or otherPersonId <> personId Then

                IncrementAccountOperationPattern acc

                IncrementAccountOperationPattern otherAcc

            End If

        End If

    Next other

End Sub

Private Sub IncrementAccountOperationPattern(ByVal accountId As String)

    If Len(accountId) = 0 Then Exit Sub

    If mAccountOperationPatternCount Is Nothing Then Set mAccountOperationPatternCount = CreateObject("Scripting.Dictionary")

    If mAccountOperationPatternCount.Exists(accountId) Then

        mAccountOperationPatternCount(accountId) = CLng(mAccountOperationPatternCount(accountId)) + 1

    Else

        mAccountOperationPatternCount.Add accountId, 1

    End If

End Sub

Private Function NearbyTimeClusterRecords(ByVal rec As Object) As Collection

    Dim result As New Collection, dayKey As Long, bucket As Long, offset As Long, k As String, src As Collection, item As Object

    Set NearbyTimeClusterRecords = result

    If rec Is Nothing Then Exit Function

    If mTimeCluster Is Nothing Then Exit Function

    If Not KeyExists(rec, "HasTime") Then Exit Function

    If Not CBool(rec("HasTime")) Then Exit Function

    dayKey = DateOnlySerial(rec("Date"))

    If dayKey = 0 Then Exit Function

    bucket = CLng(Fix(CDbl(rec("TimeFraction")) * 1440# / 15#))

    For offset = -1 To 1

        k = CStr(dayKey) & "|" & CStr(bucket + offset)

        If mTimeCluster.Exists(k) Then

            Set src = mTimeCluster(k)

            For Each item In src

                result.Add item

            Next item

        End If

    Next offset

End Function

Private Function TimeClusterKey(ByVal rec As Object) As String

    Dim dayKey As Long, bucket As Long

    If rec Is Nothing Then Exit Function

    If Not KeyExists(rec, "HasTime") Then Exit Function

    If Not CBool(rec("HasTime")) Then Exit Function

    dayKey = DateOnlySerial(rec("Date"))

    If dayKey = 0 Then Exit Function

    bucket = CLng(Fix(CDbl(rec("TimeFraction")) * 1440# / 15#))

    TimeClusterKey = CStr(dayKey) & "|" & CStr(bucket)

End Function

Private Function TimeBucketMinutes(ByVal rec As Object) As Long

    If rec Is Nothing Then Exit Function

    If KeyExists(rec, "HasTime") Then
        If CBool(rec("HasTime")) Then TimeBucketMinutes = CLng(Fix(CDbl(rec("TimeFraction")) * 1440# / 15#)) * 15
    End If

End Function

Private Function TimeFractionOrEmpty(ByVal v As Variant) As Variant

    Dim s As String, x As Double, hh As Long, mm As Long

    On Error GoTo EH

    If IsError(v) Or IsNull(v) Or IsEmpty(v) Then Exit Function

    s = CellText(v)

    On Error Resume Next
    s = StrConv(s, vbNarrow)
    On Error GoTo EH

    If Len(s) = 0 Then Exit Function

    s = Replace$(s, "�F", ":")
    s = Replace$(s, "��", ":")
    s = Replace$(s, "��", "")
    s = Replace$(s, " ", "")
    s = Replace$(s, "�@", "")



    ' ���l���͂͐�Ɏ����Ƃ��ĉ��߂���B1200 ����t�V���A���������� 0:00 �ɂ��Ȃ����߁B

    If IsNumeric(s) Then

        x = CDbl(s)

        If x >= 0 And x < 1 Then

            TimeFractionOrEmpty = x

            Exit Function

        End If

        If x >= 100 And x <= 2359 Then

            hh = CLng(Fix(x / 100#))

            mm = CLng(x - hh * 100)

            If hh >= 0 And hh < 24 And mm >= 0 And mm < 60 Then

                TimeFractionOrEmpty = (hh * 60# + mm) / 1440#

                Exit Function

            End If

        End If

        If x >= 0 And x < 24 Then

            TimeFractionOrEmpty = x / 24#

            Exit Function

        End If

    End If



    If InStr(1, s, ":", vbTextCompare) > 0 Then

        x = CDbl(CDate(s)) - Int(CDbl(CDate(s)))

        TimeFractionOrEmpty = x

        Exit Function

    End If



    If IsDate(v) Then

        x = CDbl(CDate(v)) - Int(CDbl(CDate(v)))

        If x < 0 Then x = 0

        TimeFractionOrEmpty = x

        Exit Function

    End If

    Exit Function

EH:

    TimeFractionOrEmpty = Empty

End Function



Private Function DateOnlySerial(ByVal v As Variant) As Long

    If IsDate(v) Then DateOnlySerial = CLng(DateValue(CDate(v)))

End Function



Private Function GetFinalShopFromArray(ByRef data As Variant, _
        ByVal r As Long, _
        ByVal colShopFinal As Long, _
        ByVal colShopConverted As Long, _
        ByVal colShopFilled As Long, _
        ByVal colShopRaw As Long, _
        ByVal colBranch As Long) As String

    GetFinalShopFromArray = ArrayText(data, r, colShopFinal)

    If Len(GetFinalShopFromArray) = 0 Then GetFinalShopFromArray = ArrayText(data, r, colShopConverted)

    If Len(GetFinalShopFromArray) = 0 Then GetFinalShopFromArray = ArrayText(data, r, colShopFilled)

    If Len(GetFinalShopFromArray) = 0 Then GetFinalShopFromArray = ArrayText(data, r, colShopRaw)

    If Len(GetFinalShopFromArray) = 0 Then GetFinalShopFromArray = ArrayText(data, r, colBranch)

End Function



Private Sub AddToDateIndex(ByVal idx As Object, ByVal dateKey As String, ByVal rec As Object)

    Dim col As Collection

    If idx.Exists(dateKey) Then

        Set col = idx(dateKey)

    Else

        Set col = New Collection

        idx.Add dateKey, col

    End If

    col.Add rec

End Sub



Public Sub FindOneToOne(ByVal outs As Collection, ByVal insByDate As Object)

    Dim o As Object, candidates As Collection, i As Long, recIn As Object

    For Each o In outs

        If ResultLimitReached() Then Exit Sub

        If Not ShouldSkipShiftRecord(o) Then
            If CDbl(o("Out")) >= mMinShift Then

                Set candidates = CandidateRecordsByFlow(insByDate, o, mDateWindow, mMaxSideCandidates * 3, True)

                For i = 1 To candidates.Count

                    If ResultLimitReached() Then Exit Sub

                    Set recIn = candidates(i)

                    If Not ShouldSkipShiftRecord(recIn) Then
                        If CDbl(recIn("In")) >= mMinShift Then

                            If AmountClose(CDbl(o("Out")), CDbl(recIn("In"))) Then

                                AddAnalysisCandidate "1��1", CollectionFromOne(o), CollectionFromOne(recIn)

                            End If

                        End If
                    End If

                Next i

            End If
        End If

    Next o

End Sub



Public Sub FindOneToMany(ByVal outs As Collection, ByVal insByDate As Object)

    Dim o As Object, candidates As Collection, combos As Collection, c As Object, i As Long

    If mMaxCombo < 2 Then Exit Sub

    For Each o In outs

        If ResultLimitReached() Then Exit Sub

        If Not ShouldSkipShiftRecord(o) Then
            If CDbl(o("Out")) >= mMinShift Then

                Set candidates = CandidateRecordsByFlow(insByDate, o, mDateWindow, mMaxSideCandidates, True)

                Set candidates = FilterCandidatesForShift(candidates)

                Set combos = BuildCombosNearAmount(candidates, 2, mMaxCombo, CDbl(o("Out")))

                For i = 1 To combos.Count

                    If ResultLimitReached() Then Exit Sub

                    Set c = combos(i)

                    AddAnalysisCandidate "1�Ε���", CollectionFromOne(o), c("Records")

                Next i

            End If
        End If

    Next o

End Sub



Public Sub FindManyToOne(ByVal ins As Collection, ByVal outByDate As Object)

    Dim recIn As Object, candidates As Collection, combos As Collection, c As Object, i As Long

    If mMaxCombo < 2 Then Exit Sub

    For Each recIn In ins

        If ResultLimitReached() Then Exit Sub

        If Not ShouldSkipShiftRecord(recIn) Then
            If CDbl(recIn("In")) >= mMinShift Then

                Set candidates = CandidateRecordsByFlow(outByDate, recIn, mDateWindow, mMaxSideCandidates, False)

                Set candidates = FilterCandidatesForShift(candidates)

                Set combos = BuildCombosNearAmount(candidates, 2, mMaxCombo, CDbl(recIn("In")), True)

                For i = 1 To combos.Count

                    If ResultLimitReached() Then Exit Sub

                    Set c = combos(i)

                    AddAnalysisCandidate "������1", c("Records"), CollectionFromOne(recIn)

                Next i

            End If
        End If

    Next recIn

End Sub



Public Sub FindManyToMany(ByVal outs As Collection, ByVal ins As Collection, ByVal outByDate As Object, ByVal insByDate As Object)

    Dim base As Object, outCandidates As Collection, inCandidates As Collection

    Dim outCombos As Collection, inCombos As Collection, inComboIndex As Object, matches As Collection

    Dim co As Object, ci As Object, i As Long, j As Long, pairTests As Long

    If mMaxCombo < 2 Then Exit Sub



    For Each base In outs

        If ResultLimitReached() Then Exit Sub

        If Not ShouldSkipShiftRecord(base) Then
            If CDbl(base("Out")) >= mMinShift Then

                Set outCandidates = CandidateRecordsByDate(outByDate, CDate(base("Date")), mDateWindow, mMaxSideCandidates)

            Set inCandidates = CandidateRecordsByFlow(insByDate, base, mDateWindow, mMaxSideCandidates, True)

            Set outCandidates = FilterCandidatesForShift(outCandidates)

            Set inCandidates = FilterCandidatesForShift(inCandidates)

            Set outCombos = BuildCombos(outCandidates, 2, mMaxCombo, True)

            Set inCombos = BuildCombos(inCandidates, 2, mMaxCombo)

            Set inComboIndex = BuildComboAmountIndex(inCombos)

            pairTests = 0

            For i = 1 To outCombos.Count

                If ResultLimitReached() Then Exit Sub

                Set co = outCombos(i)

                If CDbl(co("Sum")) >= mMinShift Then

                    Set matches = CandidateCombosByAmountIndexed(inComboIndex, CDbl(co("Sum")))

                    For j = 1 To matches.Count

                        pairTests = pairTests + 1

                        If pairTests > mMaxMtmPairTests Then Exit For

                        Set ci = matches(j)

                        AddAnalysisCandidate "�����Ε���", co("Records"), ci("Records")

                        If ResultLimitReached() Then Exit Sub

                    Next j

                End If

                If pairTests > mMaxMtmPairTests Then Exit For

            Next i

            End If
        End If

    Next base

End Sub



Public Sub FindUnknowns(ByVal outs As Collection, ByVal ins As Collection)

    Dim o As Object, i As Object

    For Each o In outs

        If ResultLimitReached() Then Exit Sub

        If CDbl(o("Out")) >= mUnknownThreshold Then

            If Not mSuppressDuplicateShift Then

                AddUnknownCandidate KIND_UNKNOWN_OUT, o

            ElseIf mMatched Is Nothing Then

                AddUnknownCandidate KIND_UNKNOWN_OUT, o

            ElseIf Not mMatched.Exists(CStr(o("TxId"))) Then

                AddUnknownCandidate KIND_UNKNOWN_OUT, o

            End If

        End If

    Next o

    For Each i In ins

        If ResultLimitReached() Then Exit Sub

        If CDbl(i("In")) >= mUnknownThreshold Then

            If Not mSuppressDuplicateShift Then

                AddUnknownCandidate KIND_UNKNOWN_IN, i

            ElseIf mMatched Is Nothing Then

                AddUnknownCandidate KIND_UNKNOWN_IN, i

            ElseIf Not mMatched.Exists(CStr(i("TxId"))) Then

                AddUnknownCandidate KIND_UNKNOWN_IN, i

            End If

        End If

    Next i

End Sub



Public Sub FindUnknownFlagAmountCombinations()

    Dim unknownOuts As Collection, unknownIns As Collection
    Dim outCombos As Collection, inCombos As Collection, inComboIndex As Object, matches As Collection
    Dim co As Object, ci As Object, i As Long, j As Long, pairTests As Long
    Dim wsAudit As Worksheet

    If Not mEnableUnknowns Then Exit Sub
    If ResultLimitReached() Then Exit Sub

    Set unknownOuts = UnknownFlaggedRecords(KIND_UNKNOWN_OUT, "�o��")
    Set unknownIns = UnknownFlaggedRecords(KIND_UNKNOWN_IN, "����")

    If unknownOuts.Count = 0 Or unknownIns.Count = 0 Then Exit Sub

    Set unknownOuts = SortRecordsByAmountDesc(unknownOuts, True)
    Set unknownIns = SortRecordsByAmountDesc(unknownIns, False)

    If SheetExists(SH_WORK_UNKNOWN_COMBO) Then
        Set wsAudit = GetSheet(SH_WORK_UNKNOWN_COMBO)
    Else
        Set wsAudit = GetOrCreateSheet(SH_WORK_UNKNOWN_COMBO, False)
    End If
    InitUnknownComboHeaders wsAudit, True

    ' ���t���͎g��Ȃ��B�Ώۂ́A�ʏ핪�͂Łu�s���o���v�u�s�������v�Ƃ��ăt���O����������������B
    Set outCombos = BuildCombos(unknownOuts, 1, mMaxCombo, True, True)
    Set inCombos = BuildCombos(unknownIns, 1, mMaxCombo, False, True)
    Set inComboIndex = BuildComboAmountIndex(inCombos)

    For i = 1 To outCombos.Count
        If ResultLimitReached() Then Exit For
        Set co = outCombos(i)
        Set matches = CandidateCombosByAmountIndexed(inComboIndex, CDbl(co("Sum")))
        For j = 1 To matches.Count
            pairTests = pairTests + 1
            If pairTests > mMaxMtmPairTests Then
                mUnknownComboLimitReached = True
                mUnknownComboPairLimitReached = True
                Exit For
            End If
            Set ci = matches(j)
            If Not CollectionsShareValue(co("Records"), ci("Records"), "TxId") Then
                AppendUnknownFlagComboCandidate co("Records"), ci("Records")
                If ResultLimitReached() Then Exit For
            End If
        Next j
        If mUnknownComboPairLimitReached Or ResultLimitReached() Then Exit For
    Next i

    mUnknownComboPairTests = pairTests
    If mUnknownComboCount > 0 Then AppendLog "�s�����o���g����", "���ǉ�", "���t�͈͂Ȃ��E�s���t���O���� " & CStr(mUnknownComboCount) & "�� / ���� " & CStr(pairTests) & "�g"
    If mUnknownComboBuildLimitReached Or mUnknownComboPairLimitReached Then
        AppendLog "�s�����o���g����", "������B", UnknownComboLimitWarningText()
        WriteUnknownComboLimitAudit UnknownComboLimitWarningText()
    End If

End Sub

Private Function UnknownFlaggedRecords(ByVal kindText As String, ByVal sideText As String) As Collection

    Dim result As New Collection, seen As Object
    Dim wsRes As Worksheet, lastR As Long, r As Long, analysisId As String

    Set seen = CreateObject("Scripting.Dictionary")
    If Not SheetExists(SH_WORK_RESULT) Then
        Set UnknownFlaggedRecords = result
        Exit Function
    End If
    If Not SheetExists(SH_WORK_DETAIL) Then
        Set UnknownFlaggedRecords = result
        Exit Function
    End If

    Set wsRes = GetSheet(SH_WORK_RESULT)
    lastR = LastRow(wsRes, RES_COL_ID)
    For r = 2 To lastR
        If CellText(wsRes.Cells(r, RES_COL_KIND).Value) = kindText Then
            If Not IsExcludeDecision(CellText(wsRes.Cells(r, RES_COL_SHIFT_DECISION).Value)) Then
                analysisId = CellText(wsRes.Cells(r, RES_COL_ID).Value)
                If Len(analysisId) > 0 Then AddUnknownFlaggedDetailRecords analysisId, sideText, seen, result
            End If
        End If
    Next r

    Set UnknownFlaggedRecords = result

End Function

Private Sub AddUnknownFlaggedDetailRecords(ByVal analysisId As String, ByVal sideText As String, ByVal seen As Object, ByVal result As Collection)

    Dim wsDet As Worksheet, lastR As Long, r As Long, txId As String

    If mTxById Is Nothing Then Exit Sub
    Set wsDet = GetSheet(SH_WORK_DETAIL)
    lastR = LastRow(wsDet, DET_COL_ID)
    For r = 2 To lastR
        If CellText(wsDet.Cells(r, DET_COL_ANALYSIS_ID).Value) = analysisId Then
            If CellText(wsDet.Cells(r, DET_COL_SIDE).Value) = sideText Then
                txId = CellText(wsDet.Cells(r, DET_COL_TX_ID).Value)
                If Len(txId) > 0 Then
                    If Not seen.Exists(txId) Then
                        If mTxById.Exists(txId) Then
                            seen.Add txId, True
                            result.Add mTxById(txId)
                        End If
                    End If
                End If
            End If
        End If
    Next r

End Sub

Private Function SortRecordsByAmountDesc(ByVal records As Collection, ByVal useOut As Boolean) As Collection
    Set SortRecordsByAmountDesc = AnalysisSortRecordsByAmountDesc(records, useOut)
End Function

Private Function RecordAmountForSide(ByVal rec As Object, ByVal useOut As Boolean) As Double
    RecordAmountForSide = AnalysisRecordAmountForSide(rec, useOut)
End Function

Private Function WorkResultStateKeyExists(ByVal patternText As String, ByVal outIds As String, ByVal inIds As String) As Boolean

    Dim ws As Worksheet, lastR As Long, r As Long, keyText As String, targetKey As String

    If Not SheetExists(SH_WORK_RESULT) Then Exit Function
    targetKey = BuildAnalysisStateKey(patternText, outIds, inIds)
    Set ws = GetSheet(SH_WORK_RESULT)
    lastR = LastRow(ws, RES_COL_ID)
    For r = 2 To lastR
        keyText = BuildAnalysisStateKey(CellText(ws.Cells(r, RES_COL_PATTERN).Value), CellText(ws.Cells(r, RES_COL_OUT_IDS).Value), CellText(ws.Cells(r, RES_COL_IN_IDS).Value))
        If keyText = targetKey Then
            WorkResultStateKeyExists = True
            Exit Function
        End If
    Next r

End Function

Private Sub AppendUnknownFlagComboCandidate(ByVal outRecords As Collection, ByVal inRecords As Collection)

    If ResultLimitReached() Then Exit Sub

    Dim outIds As String, inIds As String, key As String, stateKey As String
    Dim outSum As Double, inSum As Double, diff As Double, score As Long
    Dim analysisId As String, voucher As String, decisionText As String, operationMemoText As String
    Dim reasonText As String, summaryText As String, relationText As String, riskText As String
    Dim ageHint As String, addressHint As String, shops As String

    If outRecords Is Nothing Or inRecords Is Nothing Then Exit Sub
    If outRecords.Count = 0 Or inRecords.Count = 0 Then Exit Sub

    outIds = SortedIds(outRecords)
    inIds = SortedIds(inRecords)
    key = "UNKNOWNCOMBO|O:" & outIds & "|I:" & inIds
    If mDedupe.Exists(key) Then Exit Sub
    mDedupe.Add key, True

    outSum = SumRecords(outRecords, True)
    inSum = SumRecords(inRecords, False)
    diff = outSum - inSum
    If Not AmountClose(outSum, inSum) Then Exit Sub

    score = ScoreUnknownFlagCombination(outRecords, inRecords, diff)
    stateKey = BuildAnalysisStateKey("���ԕs��E�s�����o���̂�", outIds, inIds)
    If WorkResultStateKeyExists("���ԕs��E�s�����o���̂�", outIds, inIds) Then Exit Sub
    If score < Application.Max(45, mMinScore - 10) Then
        If mManualDecisionOverrides Is Nothing Then Exit Sub
        If Not mManualDecisionOverrides.Exists(stateKey) Then Exit Sub
    End If

    voucher = VOUCHER_YES
    If Application.Max(outSum, inSum) < mVoucherThreshold Then voucher = VOUCHER_NO
    decisionText = DECISION_USE
    operationMemoText = "�s���o���E�s�������t���O�����œ��t�͈͂Ȃ��ɋ��z�ƍ��B��t���O�Ȃ玑������\_���͍ς܂��̓t���O���o�Ŏ�����O���čĕ��́B"

    If Not mManualVoucherOverrides Is Nothing Then
        If mManualVoucherOverrides.Exists(stateKey) Then voucher = CStr(mManualVoucherOverrides(stateKey))
        If mManualDecisionOverrides.Exists(stateKey) Then decisionText = CStr(mManualDecisionOverrides(stateKey))
        If mManualMemoOverrides.Exists(stateKey) Then operationMemoText = CStr(mManualMemoOverrides(stateKey))
    End If
    decisionText = NormalizeDecisionText(decisionText)
    If IsExcludeDecision(decisionText) Then voucher = VOUCHER_NO

    relationText = NameRelation(outRecords, inRecords)
    riskText = RiskSignalText(outRecords, inRecords)
    shops = ShopList(outRecords, inRecords)
    summaryText = "�s���t���O����E���ԕs��̋��z�g������v"
    summaryText = JoinNonBlank(summaryText, SummaryList(outRecords, inRecords), " / ")
    reasonText = "�s���o�����v " & Format$(outSum, "#,##0") & "�~ �ƕs���������v " & Format$(inSum, "#,##0") & "�~����v�B���t���E�O��֌W�͔�������Ɏg���Ă��܂���B"
    ageHint = AgeHintForRecords(outRecords, inRecords)
    addressHint = AddressHintForRecords(outRecords, inRecords)

    analysisId = NextId("���͌��")
    WriteResultRow analysisId, KIND_UNKNOWN_COMBO, "���ԕs��E�s�����o���̂�", score, voucher, _
        RecordsDateTimeRangeText(outRecords), RecordsDateTimeRangeText(inRecords), _
        outSum, inSum, diff, PersonList(outRecords), PersonList(inRecords), relationText, _
        JoinNonBlank("���ԕs��", InheritanceTiming(outRecords), " / "), riskText, _
        outIds, inIds, shops, summaryText, reasonText, decisionText, operationMemoText, ageHint, addressHint

    If Not IsExcludeDecision(decisionText) Then
        WriteDetailRows analysisId, KIND_UNKNOWN_COMBO, voucher, "�o��", outRecords, True
        WriteDetailRows analysisId, KIND_UNKNOWN_COMBO, voucher, "����", inRecords, False
        WriteUnknownComboAudit analysisId, outIds, inIds, outSum, inSum, diff, reasonText, operationMemoText
        mUnknownComboCount = mUnknownComboCount + 1
    End If

End Sub

Private Function ScoreUnknownFlagCombination(ByVal outRecords As Collection, ByVal inRecords As Collection, ByVal diff As Double) As Long
    ScoreUnknownFlagCombination = CalculateUnknownFlagComboScore(diff, _
        AmountClose(SumRecords(outRecords, True), SumRecords(inRecords, False)), _
        SameShopOrBankHint(outRecords, inRecords), _
        HasSameAddressAtTransaction(outRecords, inRecords), _
        Len(CohabitationText(outRecords, inRecords)) > 0, _
        Len(RiskSignalText(outRecords, inRecords)) > 0, _
        outRecords.Count, inRecords.Count)
End Function

Private Sub WriteUnknownComboAudit(ByVal analysisId As String, ByVal outIds As String, ByVal inIds As String, ByVal outSum As Double, ByVal inSum As Double, ByVal diff As Double, ByVal evidenceText As String, ByVal actionText As String)

    Dim ws As Worksheet, r As Long

    If SheetExists(SH_WORK_UNKNOWN_COMBO) Then
        Set ws = GetSheet(SH_WORK_UNKNOWN_COMBO)
    Else
        Set ws = GetOrCreateSheet(SH_WORK_UNKNOWN_COMBO, False)
    End If
    If LastRow(ws, 1) < 1 Then InitUnknownComboHeaders ws, True

    r = LastRow(ws, 1) + 1
    If r < 2 Then r = 2
    ws.Cells(r, 1).Value = analysisId
    ws.Cells(r, 2).Value = outIds
    ws.Cells(r, 3).Value = inIds
    ws.Cells(r, 4).Value = outSum
    ws.Cells(r, 5).Value = inSum
    ws.Cells(r, 6).Value = diff
    ws.Cells(r, 7).Value = "���ԕs��E�s�����o���̂�"
    ws.Cells(r, 8).Value = evidenceText
    ws.Cells(r, 9).Value = actionText
    ws.Cells(r, 10).Value = Now

End Sub

Private Function UnknownComboLimitWarningText() As String

    Dim msg As String
    If mUnknownComboBuildLimitReached Then msg = JoinNonBlank(msg, "�Б��g����������� " & CStr(mMaxCombosPerBase) & "���ɓ��B", " / ")
    If mUnknownComboPairLimitReached Then msg = JoinNonBlank(msg, "�ƍ���� " & CStr(mMaxMtmPairTests) & "�g�ɓ��B", " / ")
    If Len(msg) = 0 And mUnknownComboLimitReached Then msg = "�s�����o���g�����̏���ɓ��B"
    If Len(msg) > 0 Then msg = msg & "�B�s���o���E�s�������t���O�������ꍇ�͖������E�������̑g����������܂��B��t���O��������O���čĕ��͂��邩�A����ݒ���グ�čĎ��s���Ă��������B"
    UnknownComboLimitWarningText = msg

End Function

Private Sub WriteUnknownComboLimitAudit(ByVal warningText As String)

    Dim ws As Worksheet, outR As Long
    If Len(warningText) = 0 Then Exit Sub
    If SheetExists(SH_WORK_UNKNOWN_COMBO) Then
        Set ws = GetSheet(SH_WORK_UNKNOWN_COMBO)
    Else
        Set ws = GetOrCreateSheet(SH_WORK_UNKNOWN_COMBO, False)
    End If
    If LastRow(ws, 1) < 1 Then InitUnknownComboHeaders ws, True
    outR = LastRow(ws, 1) + 1
    If outR < 2 Then outR = 2
    ws.Cells(outR, 1).Value = "�x��"
    ws.Cells(outR, 7).Value = "������B"
    ws.Cells(outR, 8).Value = warningText
    ws.Cells(outR, 9).Value = "��������\_���͍ς܂��̓t���O���o�Ō�t���O��������O���A���O�ĕ��͂܂��͕s���g�������Ď��s���Ă��������B"
    ws.Cells(outR, 10).Value = Now

End Sub

Private Function ValidateComplexityBeforeRun(ByVal outCount As Long, ByVal inCount As Long) As Boolean

    ValidateComplexityBeforeRun = True

    If Not mStopIfTooBroad Then Exit Function

    If mMaxCombo > 10 Then

        QuietWarn "�ő�g����������10���܂łł��B�ݒ���������Ă��������B", False, "���͐ݒ�"

        ValidateComplexityBeforeRun = False

        Exit Function

    End If

    If mEnableManyToMany And mMaxCombo >= 6 Then

        ValidateComplexityBeforeRun = (MsgBox("�ő�g�����������傫�߂ł��B" & vbCrLf & _
                                              "���̃c�[���͌�␶������E�ƍ�����Ŏ~�߂邽�ߖ�������O(n^k)�����ɂ͂��܂��񂪁A���R��⏈�����ԑ����͋N���蓾�܂��B���s���܂����B", vbQuestion + vbYesNo) = vbYes)

        If Not ValidateComplexityBeforeRun Then Exit Function

    End If

    If mEnableManyToMany And mMaxCombo >= 3 And mDateWindow > 7 And mMaxSideCandidates > 12 Then

        ValidateComplexityBeforeRun = (MsgBox("�����Ε����̏������L�߂ł��B�������d���Ȃ�\��������܂��B" & vbCrLf & _
                                              "���t���e�����E������E�ő�g�����������i�邱�Ƃ𐄏����܂��B���s���܂����B", vbQuestion + vbYesNo) = vbYes)

        Exit Function

    End If

    If outCount * inCount > 5000000# And mEnableManyToMany Then

        ValidateComplexityBeforeRun = (MsgBox("��������������A�����Ε������܂߂�Əd���Ȃ�\��������܂��B" & vbCrLf & _
                                              "���1��1�E1�Ε����E������1�����ŕ��͂��邱�Ƃ𐄏����܂��B���s���܂����B", vbQuestion + vbYesNo) = vbYes)

    End If

End Function



Private Function ResultLimitReached() As Boolean

    If mStopRequested Then

        ResultLimitReached = True

        Exit Function

    End If

    If mMaxResults > 0 Then

        If mResultCount >= mMaxResults Then

            mStopRequested = True

            AppendLog "���͏��", "��~", "�ő��⌏���ɒB���܂���: " & CStr(mMaxResults)

            ResultLimitReached = True

        End If

    End If

End Function



Private Function ShouldSkipShiftRecord(ByVal rec As Object) As Boolean

    ' ����P�ʂ̎蓮���O�����������ŏ��O����B

    ' ��x��≻��������𑦍��ɊO���ƁA���Ó��ȕʌ����E���Ȃ��댯�����邽�߁A

    ' ��␶�����͐撅���Ŏ����ׂ��Ȃ��B

    Dim txId As String

    txId = CStr(rec("TxId"))

    ShouldSkipShiftRecord = False

    If Not mManualExcludedTxIds Is Nothing Then

        If mManualExcludedTxIds.Exists(txId) Then ShouldSkipShiftRecord = True

    End If

End Function



Private Function FilterCandidatesForShift(ByVal records As Collection) As Collection

    Dim out As New Collection, rec As Object

    For Each rec In records

        If Not ShouldSkipShiftRecord(rec) Then out.Add rec

    Next rec

    Set FilterCandidatesForShift = out

End Function



Private Function IsExcludedTransaction(ByVal rec As Object) As Boolean

    Dim i As Long, s As String, w As String

    IsExcludedTransaction = False

    If IsEmpty(mExcludedKeywordList) Then Exit Function

    s = CStr(rec("Summary")) & " " & CStr(rec("Other"))

    For i = LBound(mExcludedKeywordList) To UBound(mExcludedKeywordList)

        w = CStr(mExcludedKeywordList(i))

        If Len(w) > 0 Then

            If InStr(1, s, w, vbTextCompare) > 0 Then

                IsExcludedTransaction = True

                Exit Function

            End If

        End If

    Next i

End Function



Private Function SplitExcludeKeywords(ByVal keywordsText As String) As Variant

    Dim raw As Variant, out() As String, i As Long, n As Long, w As String

    If Len(Trim$(keywordsText)) = 0 Then

        SplitExcludeKeywords = Empty

        Exit Function

    End If

    raw = Split(keywordsText, ",")

    ReDim out(0 To UBound(raw))

    For i = LBound(raw) To UBound(raw)

        w = Trim$(CStr(raw(i)))

        If Len(w) > 0 Then

            out(n) = w

            n = n + 1

        End If

    Next i

    If n = 0 Then

        SplitExcludeKeywords = Empty

    Else

        ReDim Preserve out(0 To n - 1)

        SplitExcludeKeywords = out

    End If

End Function



Private Function VoucherFlagForCandidate(ByVal kindText As String, ByVal amountValue As Double) As String
    VoucherFlagForCandidate = AnalysisVoucherFlagForCandidate(kindText, amountValue, mVoucherThreshold, mVoucherInheritanceAlways)
End Function

Private Function VoucherFlagForUnknown(ByVal amountValue As Double) As String
    VoucherFlagForUnknown = AnalysisVoucherFlagForUnknown(amountValue, mVoucherThreshold, mVoucherUnknowns)
End Function



Private Function CandidateRecordsByDate(ByVal idx As Object, ByVal baseDate As Date, ByVal windowDays As Long, ByVal limitCount As Long) As Collection

    ' ����ɋ߂����Ō�≻����B���t�� DateValue �Ŋۂ߁A�����̒[���œ��t�L�[������Ȃ��悤�ɂ���B

    Dim out As New Collection, offset As Long, k As String, col As Collection, ordered As Collection, i As Long

    Dim offsets As Collection, v As Variant

    Set offsets = New Collection

    offsets.Add 0

    For offset = 1 To windowDays

        offsets.Add -offset

        offsets.Add offset

    Next offset

    For Each v In offsets

        k = CStr(DateOnlySerial(baseDate) + CLng(v))

        If idx.Exists(k) Then

            Set col = idx(k)

            Set ordered = SortCandidateCollection(col, Nothing, True)

            For i = 1 To ordered.Count

                out.Add ordered(i)

                If out.Count >= limitCount Then

                    Set CandidateRecordsByDate = out

                    Exit Function

                End If

            Next i

        End If

    Next v

    Set CandidateRecordsByDate = out

End Function



Private Function CandidateRecordsByFlow(ByVal idx As Object, _
        ByVal baseRec As Object, _
        ByVal windowDays As Long, _
        ByVal limitCount As Long, _
        ByVal wantInSide As Boolean) As Collection

    ' wantInSide=True  : baseRec �͏o���B�������͓����Ȍゾ���B�������o���ɂ���� base �o�������Ȍゾ���B

    ' wantInSide=False : baseRec �͓����B���o���͓����ȑO�����B�������o���ɂ���� base ���������ȑO�����B

    Dim out As New Collection, offset As Long, k As String, col As Collection, ordered As Collection, i As Long, rec As Object

    If baseRec Is Nothing Then

        Set CandidateRecordsByFlow = out

        Exit Function

    End If



    For offset = 0 To windowDays

        If wantInSide Then

            k = CStr(DateOnlySerial(baseRec("Date")) + offset)

        Else

            k = CStr(DateOnlySerial(baseRec("Date")) - offset)

        End If

        If idx.Exists(k) Then

            Set col = idx(k)

            Set ordered = SortCandidateCollection(col, baseRec, wantInSide)

            For i = 1 To ordered.Count

                Set rec = ordered(i)

                If IsDirectionalRecordPairPossible(baseRec, rec, wantInSide) Then

                    out.Add rec

                    If out.Count >= limitCount Then

                        Set CandidateRecordsByFlow = out

                        Exit Function

                    End If

                End If

            Next i

        End If

    Next offset

    Set CandidateRecordsByFlow = out

End Function



Private Function IsDirectionalRecordPairPossible(ByVal baseRec As Object, ByVal candidateRec As Object, ByVal wantInSide As Boolean) As Boolean

    Dim baseDay As Long, candDay As Long

    IsDirectionalRecordPairPossible = True

    If baseRec Is Nothing Or candidateRec Is Nothing Then Exit Function

    baseDay = DateOnlySerial(baseRec("Date"))

    candDay = DateOnlySerial(candidateRec("Date"))

    If baseDay = 0 Or candDay = 0 Then Exit Function



    If wantInSide Then

        ' base �o�� �� candidate ����

        If candDay < baseDay Then IsDirectionalRecordPairPossible = False: Exit Function

        If candDay = baseDay And CBool(baseRec("HasTime")) And CBool(candidateRec("HasTime")) Then

            If CDbl(candidateRec("TimeFraction")) + 0.00000001 < CDbl(baseRec("TimeFraction")) Then IsDirectionalRecordPairPossible = False

        End If

    Else

        ' candidate �o�� �� base ����

        If candDay > baseDay Then IsDirectionalRecordPairPossible = False: Exit Function

        If candDay = baseDay And CBool(baseRec("HasTime")) And CBool(candidateRec("HasTime")) Then

            If CDbl(candidateRec("TimeFraction")) > CDbl(baseRec("TimeFraction")) + 0.00000001 Then IsDirectionalRecordPairPossible = False

        End If

    End If

End Function



Private Function SortCandidateCollection(ByVal records As Collection, ByVal baseRec As Object, ByVal wantInSide As Boolean) As Collection

    Dim out As New Collection, rec As Object, i As Long, inserted As Boolean

    For Each rec In records

        inserted = False

        For i = 1 To out.Count

            If CandidateSortKey(rec, baseRec, wantInSide) < CandidateSortKey(out(i), baseRec, wantInSide) Then

                out.Add rec, , i

                inserted = True

                Exit For

            End If

        Next i

        If Not inserted Then out.Add rec

    Next rec

    Set SortCandidateCollection = out

End Function



Private Function CandidateSortKey(ByVal rec As Object, ByVal baseRec As Object, ByVal wantInSide As Boolean) As Double

    Dim keyValue As Double, baseDay As Long, recDay As Long, recTimePenalty As Double

    If rec Is Nothing Then CandidateSortKey = 999999999#: Exit Function

    recDay = DateOnlySerial(rec("Date"))

    If Not baseRec Is Nothing Then

        baseDay = DateOnlySerial(baseRec("Date"))

        keyValue = Abs(recDay - baseDay) * 1000000#

        If recDay = baseDay Then

            If CBool(rec("HasTime")) And CBool(baseRec("HasTime")) Then

                keyValue = keyValue + Abs(CDbl(rec("TimeFraction")) - CDbl(baseRec("TimeFraction"))) * 100000#

            ElseIf CBool(rec("HasTime")) Then

                keyValue = keyValue + CDbl(rec("TimeFraction")) * 1000#

            Else

                keyValue = keyValue + 5000#

            End If

        Else

            If CBool(rec("HasTime")) Then keyValue = keyValue + CDbl(rec("TimeFraction")) * 1000#

        End If

    Else

        keyValue = recDay * 1000000#

        If CBool(rec("HasTime")) Then

            keyValue = keyValue + CDbl(rec("TimeFraction")) * 100000#

        Else

            keyValue = keyValue + 5000#

        End If

    End If

    If KeyExists(rec, "InputOrder") Then keyValue = keyValue + CDbl(rec("InputOrder")) / 1000000#

    CandidateSortKey = keyValue

End Function



Private Function CollectionFromOne(ByVal rec As Object) As Collection

    Dim c As New Collection

    c.Add rec

    Set CollectionFromOne = c

End Function



Private Function BuildCombos(ByVal records As Collection, ByVal minDepth As Long, ByVal maxDepth As Long, Optional ByVal useOut As Boolean = False, Optional ByVal markUnknownLimit As Boolean = False) As Collection
    Set BuildCombos = AnalysisBuildCombos(records, minDepth, maxDepth, useOut, mMaxCombosPerBase)
    If Not BuildCombos Is Nothing Then
        If BuildCombos.Count >= mMaxCombosPerBase And markUnknownLimit Then
            mUnknownComboLimitReached = True
            mUnknownComboBuildLimitReached = True
        End If
    End If
End Function

Private Function BuildCombosNearAmount(ByVal records As Collection, _
        ByVal minDepth As Long, _
        ByVal maxDepth As Long, _
        ByVal targetAmount As Double, _
        Optional ByVal useOut As Boolean = False) As Collection
    Set BuildCombosNearAmount = AnalysisBuildCombosNearAmount(records, minDepth, maxDepth, targetAmount, useOut, mMaxCombosPerBase, mAmountTol, mAmountRate)
End Function

Private Function AmountClose(ByVal outAmt As Double, ByVal inAmt As Double) As Boolean
    AmountClose = AnalysisAmountClose(outAmt, inAmt, mAmountTol, mAmountRate)
End Function

Private Function EffectiveTolerance(ByVal outAmt As Double, ByVal inAmt As Double) As Double
    EffectiveTolerance = AnalysisEffectiveTolerance(outAmt, inAmt, mAmountTol, mAmountRate)
End Function

Private Function AmountBucketUnit() As Double
    AmountBucketUnit = AnalysisAmountBucketUnit(mAmountTol)
End Function

Private Function AmountBucketKey(ByVal amountValue As Double) As Long
    AmountBucketKey = CLng(Fix(amountValue / AmountBucketUnit()))
End Function

Private Function BuildComboAmountIndex(ByVal combos As Collection) As Object
    Set BuildComboAmountIndex = AnalysisBuildComboAmountIndex(combos, AmountBucketUnit())
End Function

Private Function CandidateCombosByAmountIndexed(ByVal idx As Object, ByVal amountValue As Double) As Collection
    Set CandidateCombosByAmountIndexed = AnalysisCandidateCombosByAmountIndexed(idx, amountValue, AmountBucketUnit(), mAmountTol, mAmountRate)
End Function



Private Sub AddAnalysisCandidate(ByVal patternText As String, ByVal outRecords As Collection, ByVal inRecords As Collection)

    If ResultLimitReached() Then Exit Sub

    If Not IsTemporalFlowValid(outRecords, inRecords) Then Exit Sub

    If CollectionsShareValue(outRecords, inRecords, "TxId") Then Exit Sub

    Dim outIds As String, inIds As String, key As String

    outIds = SortedIds(outRecords)

    inIds = SortedIds(inRecords)

    key = patternText & "|O:" & outIds & "|I:" & inIds

    If mDedupe.Exists(key) Then Exit Sub

    mDedupe.Add key, True



    Dim kindText As String, analysisId As String, score As Long

    Dim outSum As Double, inSum As Double, diff As Double

    Dim outPerson As String, inPerson As String, nameRel As String, inhTiming As String, cohab As String

    Dim outDateMin As Variant, outDateMax As Variant, inDateMin As Variant, inDateMax As Variant

    Dim shops As String, summaryText As String, memo As String, voucher As String

    Dim stateKey As String, decisionText As String, operationMemoText As String

    Dim ageHint As String, addressHint As String, temporalHint As String

    analysisId = NextId("���͌��")

    outSum = SumRecords(outRecords, True)

    inSum = SumRecords(inRecords, False)

    diff = outSum - inSum

    kindText = ShiftKindFromOutRecords(outRecords)

    score = ScoreCandidate(outRecords, inRecords, diff)

    stateKey = BuildAnalysisStateKey(patternText, outIds, inIds)

    If score < mMinScore Then

        If mManualDecisionOverrides Is Nothing Then Exit Sub

        If Not mManualDecisionOverrides.Exists(stateKey) Then Exit Sub

    End If

    voucher = VoucherFlagForCandidate(kindText, Application.Max(outSum, inSum))

    decisionText = DECISION_USE

    operationMemoText = "C/D��̓_�u���N���b�N�ŐؑցBM��͎��R�����B"

    If Not mManualVoucherOverrides Is Nothing Then

        If mManualVoucherOverrides.Exists(stateKey) Then voucher = CStr(mManualVoucherOverrides(stateKey))

        If mManualDecisionOverrides.Exists(stateKey) Then decisionText = CStr(mManualDecisionOverrides(stateKey))

        If mManualMemoOverrides.Exists(stateKey) Then operationMemoText = CStr(mManualMemoOverrides(stateKey))

    End If

    decisionText = NormalizeDecisionText(decisionText)

    If IsExcludeDecision(decisionText) Then voucher = VOUCHER_NO

    outPerson = PersonList(outRecords)

    inPerson = PersonList(inRecords)

    nameRel = NameRelation(outRecords, inRecords)

    inhTiming = InheritanceTiming(outRecords)

    cohab = CohabitationText(outRecords, inRecords)

    cohab = JoinNonBlank(cohab, RiskSignalText(outRecords, inRecords), " / ")

    DateMinMax outRecords, outDateMin, outDateMax

    DateMinMax inRecords, inDateMin, inDateMax

    shops = ShopList(outRecords, inRecords)

    summaryText = SummaryList(outRecords, inRecords)

    summaryText = JoinNonBlank(SummaryKeywordFlowHint(outRecords, inRecords), summaryText, " / ")

    temporalHint = TemporalFlowHintText(outRecords, inRecords)

    If Len(temporalHint) > 0 Then summaryText = JoinNonBlank(temporalHint, summaryText, " / ")

    ageHint = AgeHintForRecords(outRecords, inRecords)

    addressHint = AddressHintForRecords(outRecords, inRecords)

    memo = CandidateReasonText(outRecords, inRecords, diff, score, temporalHint)



    WriteResultRow analysisId, kindText, patternText, score, voucher, _
        RecordsDateTimeRangeText(outRecords), RecordsDateTimeRangeText(inRecords), _
        outSum, inSum, diff, outPerson, inPerson, nameRel, inhTiming, cohab, _
        outIds, inIds, shops, summaryText, memo, decisionText, _
        operationMemoText, ageHint, addressHint

    If Not IsExcludeDecision(decisionText) Then

        WriteDetailRows analysisId, kindText, voucher, "�o��", outRecords, True

        WriteDetailRows analysisId, kindText, voucher, "����", inRecords, False

        MarkMatched outRecords, analysisId

        MarkMatched inRecords, analysisId

    End If

End Sub



Private Sub AddUnknownCandidate(ByVal kindText As String, ByVal rec As Object)

    If ResultLimitReached() Then Exit Sub

    Dim analysisId As String, voucher As String, amountValue As Double, idsOut As String, idsIn As String

    Dim outSum As Double, inSum As Double, outDateText As String, inDateText As String

    Dim stateKey As String, decisionText As String, operationMemoText As String

    Dim ageHint As String, addressHint As String, riskHint As String
    Dim singleOutPerson As String, singleInPerson As String, singleTiming As String

    analysisId = NextId("���͌��")

    If kindText = KIND_UNKNOWN_OUT Then

        amountValue = CDbl(rec("Out"))

        outSum = amountValue

        idsOut = CStr(rec("TxId"))

        outDateText = RecordDateTimeText(rec)

    Else

        amountValue = CDbl(rec("In"))

        inSum = amountValue

        idsIn = CStr(rec("TxId"))

        inDateText = RecordDateTimeText(rec)

    End If

    voucher = VoucherFlagForUnknown(amountValue)

    decisionText = DECISION_USE

    operationMemoText = "C/D��̓_�u���N���b�N�ŐؑցBM��͎��R�����B"

    stateKey = BuildAnalysisStateKey("�P��", idsOut, idsIn)

    If Not mManualVoucherOverrides Is Nothing Then

        If mManualVoucherOverrides.Exists(stateKey) Then voucher = CStr(mManualVoucherOverrides(stateKey))

        If mManualDecisionOverrides.Exists(stateKey) Then decisionText = CStr(mManualDecisionOverrides(stateKey))

        If mManualMemoOverrides.Exists(stateKey) Then operationMemoText = CStr(mManualMemoOverrides(stateKey))

    End If

    decisionText = NormalizeDecisionText(decisionText)

    If IsExcludeDecision(decisionText) Then voucher = VOUCHER_NO

    ageHint = AgeHintForRecord(rec)

    addressHint = AddressHintForRecord(rec)

    riskHint = RiskSignalForSingle(rec)

    singleOutPerson = ""
    singleInPerson = ""
    If kindText = KIND_UNKNOWN_OUT Then
        singleOutPerson = CStr(rec("Name"))
    ElseIf kindText = KIND_UNKNOWN_IN Then
        singleInPerson = CStr(rec("Name"))
    End If
    If IsAfterInheritanceRecord(rec) Then
        singleTiming = "�����J�n��"
    Else
        singleTiming = "�����J�n�O/�s��"
    End If

    WriteResultRow analysisId, kindText, "�P��", 40, voucher, outDateText, inDateText, outSum, inSum, outSum - inSum, _
                   singleOutPerson, singleInPerson, _
                   "", singleTiming, riskHint, _
                   idsOut, idsIn, CStr(rec("Bank")) & " " & CStr(rec("Shop")), CStr(rec("Summary")), "�Ή�����Ȃ�", decisionText, operationMemoText, ageHint, addressHint

    If Not IsExcludeDecision(decisionText) Then

        If kindText = KIND_UNKNOWN_OUT Then

            WriteDetailRows analysisId, kindText, voucher, "�o��", CollectionFromOne(rec), True

        Else

            WriteDetailRows analysisId, kindText, voucher, "����", CollectionFromOne(rec), False

        End If

    End If

End Sub



Private Sub WriteResultRow(ByVal analysisId As String, ByVal kindText As String, ByVal patternText As String, ByVal score As Long, ByVal voucher As String, _
                           ByVal outDateText As String, ByVal inDateText As String, ByVal outSum As Double, ByVal inSum As Double, ByVal diff As Double, _
                           ByVal outPerson As String, ByVal inPerson As String, ByVal nameRel As String, ByVal inhTiming As String, ByVal cohab As String, _
                           ByVal outIds As String, ByVal inIds As String, ByVal shops As String, ByVal summaryText As String, ByVal memo As String, _
                           Optional ByVal decisionText As String = "", Optional ByVal operationMemoText As String = "", _
                           Optional ByVal ageHint As String = "", Optional ByVal addressHint As String = "")

    Dim ws As Worksheet, r As Long

    Set ws = GetSheet(SH_WORK_RESULT)

    If Len(decisionText) = 0 Then decisionText = DECISION_USE

    If Len(operationMemoText) = 0 Then operationMemoText = "C/D��̓_�u���N���b�N�ŐؑցBM��͎��R�����B"

    If mNextResultRow < 2 Then mNextResultRow = LastRow(ws, 1) + 1

    r = mNextResultRow

    mNextResultRow = mNextResultRow + 1

    ws.Cells(r, RES_COL_ID).Value = analysisId

    ws.Cells(r, RES_COL_KIND).Value = kindText

    ws.Cells(r, RES_COL_PATTERN).Value = patternText

    ws.Cells(r, RES_COL_SCORE).Value = score

    ws.Cells(r, RES_COL_VOUCHER).Value = voucher

    ws.Cells(r, RES_COL_OUT_DATE).Value = outDateText

    ws.Cells(r, RES_COL_IN_DATE).Value = inDateText

    ws.Cells(r, RES_COL_OUT_AMOUNT).Value = outSum

    ws.Cells(r, RES_COL_IN_AMOUNT).Value = inSum

    ws.Cells(r, RES_COL_DIFF).Value = diff

    ws.Cells(r, RES_COL_OUT_PERSON).Value = outPerson

    ws.Cells(r, RES_COL_IN_PERSON).Value = inPerson

    ws.Cells(r, RES_COL_NAME_REL).Value = nameRel

    ws.Cells(r, RES_COL_INH_TIMING).Value = inhTiming

    ws.Cells(r, RES_COL_COHAB).Value = cohab

    ws.Cells(r, RES_COL_OUT_IDS).Value = outIds

    ws.Cells(r, RES_COL_IN_IDS).Value = inIds

    ws.Cells(r, RES_COL_SHOPS).Value = shops

    ws.Cells(r, RES_COL_SUMMARY).Value = summaryText

    ws.Cells(r, RES_COL_MEMO).Value = memo

    ws.Cells(r, RES_COL_SHIFT_DECISION).Value = decisionText

    ws.Cells(r, RES_COL_OPERATION_MEMO).Value = operationMemoText

    ws.Cells(r, RES_COL_AGE_HINT).Value = ageHint

    ws.Cells(r, RES_COL_ADDRESS_HINT).Value = addressHint

    mResultCount = mResultCount + 1

End Sub



Private Sub WriteDetailRows(ByVal analysisId As String, _
        ByVal kindText As String, _
        ByVal voucher As String, _
        ByVal sideText As String, _
        ByVal recs As Collection, _
        ByVal useOut As Boolean)

    Dim ws As Worksheet, outR As Long, rec As Object, amountValue As Variant

    Set ws = GetSheet(SH_WORK_DETAIL)

    For Each rec In recs

        If mNextDetailRow < 2 Then mNextDetailRow = LastRow(ws, 1) + 1

        outR = mNextDetailRow

        mNextDetailRow = mNextDetailRow + 1

        ws.Cells(outR, DET_COL_ID).Value = NextId("���͖���")

        ws.Cells(outR, DET_COL_ANALYSIS_ID).Value = analysisId

        ws.Cells(outR, DET_COL_SIDE).Value = sideText

        ws.Cells(outR, DET_COL_TX_ID).Value = rec("TxId")

        ws.Cells(outR, DET_COL_DATE).Value = rec("Date")

        If useOut Then
            amountValue = rec("Out")
        Else
            amountValue = rec("In")
        End If
        ws.Cells(outR, DET_COL_AMOUNT).Value = amountValue

        ws.Cells(outR, DET_COL_PERSON_ID).Value = rec("PersonId")

        ws.Cells(outR, DET_COL_PERSON_NAME).Value = rec("Name")

        ws.Cells(outR, DET_COL_ACCOUNT_ID).Value = rec("AccountId")

        ws.Cells(outR, DET_COL_BANK).Value = rec("Bank")

        ws.Cells(outR, DET_COL_BRANCH).Value = rec("Branch")

        ws.Cells(outR, DET_COL_ACCOUNT_TYPE).Value = rec("AccountType")

        ws.Cells(outR, DET_COL_ACCOUNT_NO).Value = rec("AccountNo")

        ws.Cells(outR, DET_COL_SHOP).Value = rec("Shop")

        ws.Cells(outR, DET_COL_SUMMARY).Value = rec("Summary")

        ws.Cells(outR, DET_COL_KIND).Value = kindText

        ws.Cells(outR, DET_COL_VOUCHER).Value = voucher

    Next rec

End Sub



Private Function SortedIds(ByVal recs As Collection) As String

    Dim arr() As String, i As Long, j As Long, tmp As String, rec As Object

    If recs.Count = 0 Then Exit Function

    ReDim arr(1 To recs.Count)

    i = 1

    For Each rec In recs

        arr(i) = CStr(rec("TxId"))

        i = i + 1

    Next rec

    For i = LBound(arr) To UBound(arr) - 1

        For j = i + 1 To UBound(arr)

            If arr(j) < arr(i) Then tmp = arr(i): arr(i) = arr(j): arr(j) = tmp

        Next j

    Next i

    For i = LBound(arr) To UBound(arr)

        If Len(SortedIds) > 0 Then SortedIds = SortedIds & ","

        SortedIds = SortedIds & arr(i)

    Next i

End Function



Private Function SumRecords(ByVal recs As Collection, ByVal useOut As Boolean) As Double

    Dim rec As Object

    For Each rec In recs

        If useOut Then

            SumRecords = SumRecords + CDbl(rec("Out"))

        Else

            SumRecords = SumRecords + CDbl(rec("In"))

        End If

    Next rec

End Function



Private Sub MarkMatched(ByVal recs As Collection, ByVal analysisId As String)

    Dim rec As Object, txId As String

    For Each rec In recs

        txId = CStr(rec("TxId"))

        If mMatched.Exists(txId) Then

            mMatched(txId) = mMatched(txId) & "," & analysisId

        Else

            mMatched.Add txId, analysisId

        End If

    Next rec

End Sub



Private Function ShiftKindFromOutRecords(ByVal outRecords As Collection) As String

    Dim rec As Object

    ShiftKindFromOutRecords = KIND_SHIFT

    For Each rec In outRecords

        If KeyExists(rec, "PersonId") Then
            If CStr(rec("PersonId")) = mDecedentId Then
                If IsDate(mInheritanceDate) Then
                    If KeyExists(rec, "Date") Then
                        If IsDate(rec("Date")) Then
                            If CDate(rec("Date")) >= CDate(mInheritanceDate) Then
                                ShiftKindFromOutRecords = KIND_INHERITANCE_SHIFT
                                Exit Function
                            End If
                        End If
                    End If
                End If
            End If
        End If

    Next rec

End Function

Private Function CandidateReasonText(ByVal outRecords As Collection, _
        ByVal inRecords As Collection, _
        ByVal diff As Double, _
        ByVal score As Long, _
        ByVal temporalHint As String) As String

    Dim s As String, amountHint As String, rel As String, comboText As String

    If diff = 0 Then
        amountHint = "���z��v"
    ElseIf Abs(diff) <= mAmountTol Then
        amountHint = "���e����"
    Else
        amountHint = "���z " & Format$(diff, "#,##0")
    End If

    comboText = CStr(outRecords.Count) & "�o���~" & CStr(inRecords.Count) & "����"
    s = "�M���x" & CStr(score) & " / " & amountHint & " / " & comboText
    s = JoinNonBlank(s, temporalHint, " / ")

    rel = NameRelation(outRecords, inRecords)
    If Len(rel) > 0 Then s = JoinNonBlank(s, rel, " / ")
    If CollectionsShareValue(outRecords, inRecords, "AccountId") Then s = JoinNonBlank(s, "��������܂�", " / ")
    If InStr(temporalHint, "�����s��") > 0 Or InStr(temporalHint, "�����ꕔ�s��") > 0 Then s = JoinNonBlank(s, "�����͓��t�x�[�X", " / ")

    CandidateReasonText = ClipText(s, 240)

End Function

Private Function ScoreCandidate(ByVal outRecords As Collection, ByVal inRecords As Collection, ByVal diff As Double) As Long
    Dim outDateMin As Variant, outDateMax As Variant, inDateMin As Variant, inDateMax As Variant
    Dim effTol As Double, flowHint As String, gapMinutes As Long, ctx As Object
    Dim riskSummary As String

    DateMinMax outRecords, outDateMin, outDateMax
    DateMinMax inRecords, inDateMin, inDateMax
    effTol = EffectiveTolerance(SumRecords(outRecords, True), SumRecords(inRecords, False))
    flowHint = TemporalFlowHintText(outRecords, inRecords)
    gapMinutes = SameDayKnownTimeGapMinutes(outRecords, inRecords)

    Set ctx = CreateObject("Scripting.Dictionary")
    If mContextScore Then
        ctx("SameName") = (NameRelation(outRecords, inRecords) = "���ꖼ�`")
        ctx("Cohabitation") = (Len(CohabitationText(outRecords, inRecords)) > 0)
        ctx("SameAddress") = HasSameAddressAtTransaction(outRecords, inRecords)
        ctx("InheritanceShift") = (ShiftKindFromOutRecords(outRecords) = KIND_INHERITANCE_SHIFT)
        ctx("SameShopOrBank") = SameShopOrBankHint(outRecords, inRecords)
        ctx("SummaryKeywordFlow") = (Len(SummaryKeywordFlowHint(outRecords, inRecords)) > 0)
        riskSummary = BuildIntegratedAnalysisRiskSignalSummary(outRecords, inRecords, mDecedentId, mInheritanceDate, _
            mMinShift, mUnknownThreshold, mRelationPairs, mMarriageByPerson, mPersonInfo, mTimeCluster, mAccountOperationPatternCount)
        ctx("TimeCluster") = AnalysisRiskSummaryHasTimeCluster(riskSummary)
        ctx("YoungHighAmount") = AnalysisRiskSummaryHasYoungHighAmount(riskSummary)
        ctx("MoveAroundHighAmount") = AnalysisRiskSummaryHasMoveAroundHighAmount(riskSummary)
        ctx("LifeEventAroundHighAmount") = AnalysisRiskSummaryHasLifeEventAroundHighAmount(riskSummary)
        ctx("AccountOperationPattern") = AnalysisRiskSummaryHasAccountPattern(riskSummary)
        ctx("CentralizedManagement") = AnalysisRiskSummaryHasCentralizedManagement(riskSummary)
        ctx("GiftAddBack") = AnalysisRiskSummaryHasGiftAddBack(riskSummary)
        ctx("PreInheritanceWithdrawal") = AnalysisRiskSummaryHasPreInheritanceWithdrawal(riskSummary)
        ctx("BalanceSignal") = AnalysisRiskSummaryHasBalanceSignal(riskSummary)
    End If

    ScoreCandidate = CalculateCandidateScore(diff, mAmountTol, effTol, outDateMin, inDateMin, _
        mDateWindow, outRecords.Count + inRecords.Count, _
        CollectionsShareValue(outRecords, inRecords, "AccountId"), mContextScore, _
        gapMinutes, flowHint, ctx)
End Function



Private Function HasSameAddressAtTransaction(ByVal outs As Collection, ByVal ins As Collection) As Boolean

    Dim outAddr As Object, inAddr As Object, k As Variant

    Set outAddr = AddressDictForSide(outs)

    Set inAddr = AddressDictForSide(ins)

    Dim keyText As String

    For Each k In outAddr.Keys

        keyText = CStr(k)
        If Len(keyText) > 0 Then
            If inAddr.Exists(keyText) Then
                HasSameAddressAtTransaction = True
                Exit Function
            End If
        End If

    Next k

End Function



Private Function CollectionsShareValue(ByVal leftRecords As Collection, ByVal rightRecords As Collection, ByVal fieldName As String) As Boolean

    Dim seen As Object, rec As Object, keyText As String

    Set seen = CreateObject("Scripting.Dictionary")

    If leftRecords Is Nothing Or rightRecords Is Nothing Then Exit Function

    For Each rec In leftRecords

        If KeyExists(rec, fieldName) Then

            keyText = CStr(rec(fieldName))

            If Len(keyText) > 0 Then seen(keyText) = True

        End If

    Next rec

    For Each rec In rightRecords

        If KeyExists(rec, fieldName) Then

            keyText = CStr(rec(fieldName))

            If Len(keyText) > 0 Then

                If seen.Exists(keyText) Then

                    CollectionsShareValue = True

                    Exit Function

                End If

            End If

        End If

    Next rec

End Function



Private Function SameShopOrBankHint(ByVal outs As Collection, ByVal ins As Collection) As Boolean

    Dim d As Object, rec As Object, keyText As String

    Set d = CreateObject("Scripting.Dictionary")

    For Each rec In outs

        keyText = CStr(rec("Bank")) & "|" & CStr(rec("Shop"))

        If Len(Replace$(keyText, "|", "")) > 0 Then d(keyText) = True

    Next rec

    For Each rec In ins

        keyText = CStr(rec("Bank")) & "|" & CStr(rec("Shop"))

        If d.Exists(keyText) Then

            SameShopOrBankHint = True

            Exit Function

        End If

    Next rec

End Function



Private Sub DateMinMax(ByVal recs As Collection, ByRef dMin As Variant, ByRef dMax As Variant)

    Dim rec As Object, d As Date

    dMin = Empty: dMax = Empty

    For Each rec In recs

        If IsDate(rec("Date")) Then

            d = DateValue(CDate(rec("Date")))

            If Not IsDate(dMin) Then

                dMin = d

            ElseIf d < CDate(dMin) Then

                dMin = d

            End If

            If Not IsDate(dMax) Then

                dMax = d

            ElseIf d > CDate(dMax) Then

                dMax = d

            End If

        End If

    Next rec

End Sub



Private Function PersonList(ByVal recs As Collection) As String

    Dim d As Object, rec As Object, key As String

    Set d = CreateObject("Scripting.Dictionary")

    For Each rec In recs

        key = CStr(rec("Name"))

        If Len(key) = 0 Then key = CStr(rec("PersonId"))

        If Len(key) > 0 Then d(key) = True

    Next rec

    PersonList = JoinDictionaryKeys(d, " / ")

End Function



Private Function JoinDictionaryKeys(ByVal d As Object, ByVal sep As String) As String

    Dim k As Variant

    For Each k In d.Keys

        If Len(JoinDictionaryKeys) > 0 Then JoinDictionaryKeys = JoinDictionaryKeys & sep

        JoinDictionaryKeys = JoinDictionaryKeys & CStr(k)

    Next k

End Function



Private Function NameRelation(ByVal outs As Collection, ByVal ins As Collection) As String

    Dim dOut As Object, dIn As Object, rec As Object, k As Variant

    Set dOut = CreateObject("Scripting.Dictionary")

    Set dIn = CreateObject("Scripting.Dictionary")

    For Each rec In outs

        If Len(CStr(rec("PersonId"))) > 0 Then dOut(CStr(rec("PersonId"))) = True

    Next rec

    For Each rec In ins

        If Len(CStr(rec("PersonId"))) > 0 Then dIn(CStr(rec("PersonId"))) = True

    Next rec

    If dOut.Count = 1 And dIn.Count = 1 Then

        For Each k In dOut.Keys

            If dIn.Exists(k) Then NameRelation = "���ꖼ�`" Else NameRelation = "�ʖ��`"

            Exit Function

        Next k

    End If

    If dOut.Count = 0 Or dIn.Count = 0 Then

        NameRelation = ""

    Else

        NameRelation = "�������`"

    End If

End Function



Private Function InheritanceTiming(ByVal outs As Collection) As String

    Dim rec As Object, hasAfter As Boolean, hasBefore As Boolean

    If Not IsDate(mInheritanceDate) Then

        InheritanceTiming = "�s��"

        Exit Function

    End If

    For Each rec In outs

        If IsDate(rec("Date")) Then

            If CDate(rec("Date")) >= CDate(mInheritanceDate) Then hasAfter = True Else hasBefore = True

        End If

    Next rec

    If hasAfter And hasBefore Then

        InheritanceTiming = "�O�㍬��"

    ElseIf hasAfter Then

        InheritanceTiming = "�����J�n��"

    Else

        InheritanceTiming = "�����J�n�O"

    End If

End Function



Private Function IsAfterInheritanceRecord(ByVal rec As Object) As Boolean

    IsAfterInheritanceRecord = False

    If IsDate(mInheritanceDate) Then
        If IsDate(rec("Date")) Then

            IsAfterInheritanceRecord = (CDate(rec("Date")) >= CDate(mInheritanceDate))

        End If
    End If

End Function



Private Function CohabitationText(ByVal outs As Collection, ByVal ins As Collection) As String

    Dim recO As Object, recI As Object

    For Each recO In outs

        For Each recI In ins

            If AreCohabited(CStr(recO("PersonId")), CStr(recI("PersonId"))) Then

                CohabitationText = "����"

                Exit Function

            End If

        Next recI

    Next recO

    CohabitationText = ""

End Function



Private Function BuildCohabPairIndex() As Object
    Set BuildCohabPairIndex = BuildAnalysisCohabPairIndex(mPersonInfo)
End Function



Private Function AreCohabited(ByVal p1 As String, ByVal p2 As String) As Boolean

    If Len(p1) = 0 Or Len(p2) = 0 Or p1 = p2 Then Exit Function

    If mCohabPairs Is Nothing Then Set mCohabPairs = BuildCohabPairIndex()

    AreCohabited = mCohabPairs.Exists(BuildPairKey(p1, p2))

End Function



Private Function ShopList(ByVal outs As Collection, ByVal ins As Collection) As String

    Dim d As Object, rec As Object

    Set d = CreateObject("Scripting.Dictionary")

    For Each rec In outs

        If Len(CStr(rec("Bank")) & CStr(rec("Shop"))) > 0 Then d(CStr(rec("Bank")) & " " & CStr(rec("Shop"))) = True

    Next rec

    For Each rec In ins

        If Len(CStr(rec("Bank")) & CStr(rec("Shop"))) > 0 Then d(CStr(rec("Bank")) & " " & CStr(rec("Shop"))) = True

    Next rec

    ShopList = JoinDictionaryKeys(d, " / ")

End Function



Private Function SummaryList(ByVal outs As Collection, ByVal ins As Collection) As String

    Dim d As Object, rec As Object, s As String

    Set d = CreateObject("Scripting.Dictionary")

    For Each rec In outs

        s = CStr(rec("Summary"))

        If Len(s) > 0 Then d("�o:" & s) = True

    Next rec

    For Each rec In ins

        s = CStr(rec("Summary"))

        If Len(s) > 0 Then d("��:" & s) = True

    Next rec

    SummaryList = JoinDictionaryKeys(d, " / ")

End Function



Private Function SummaryKeywordFlowHint(ByVal outs As Collection, ByVal ins As Collection) As String

    ' �E�v�̕����͋��Z�@�ւ��Ƃɗh��邽�߁A���ޖ��ɂ͎g�킸�A�⏕�q���g�Ƃ��Čy�������B

    Dim outText As String, inText As String

    outText = CombinedSummaryText(outs)

    inText = CombinedSummaryText(ins)

    If HasAnyKeyword(outText, Array("�U��", "�U��", "����", "�����ړ�")) And HasAnyKeyword(inText, Array("�U��", "�U��", "����", "���", "�����ړ�")) Then

        SummaryKeywordFlowHint = "�E�v: �U���E�U�֌n"

    ElseIf HasAnyKeyword(outText, Array("ATM", "�`�s�l", "����", "����", "����")) And HasAnyKeyword(inText, Array("ATM", "�`�s�l", "����", "����", "�a��")) Then

        SummaryKeywordFlowHint = "�E�v: �����EATM�n"

    End If

End Function



Private Function CombinedSummaryText(ByVal recs As Collection) As String

    Dim rec As Object

    If recs Is Nothing Then Exit Function

    For Each rec In recs

        CombinedSummaryText = CombinedSummaryText & " " & CStr(rec("Summary")) & " " & CStr(rec("Other"))

    Next rec

End Function



Private Function HasAnyKeyword(ByVal textValue As String, ByVal keywords As Variant) As Boolean

    Dim i As Long

    For i = LBound(keywords) To UBound(keywords)

        If InStr(1, textValue, CStr(keywords(i)), vbTextCompare) > 0 Then

            HasAnyKeyword = True

            Exit Function

        End If

    Next i

End Function





Private Function BuildPersonInfoIndex() As Object

    Dim dict As Object, ws As Worksheet, lastR As Long, r As Long

    Dim colId As Long, colName As Long, colRel As Long, colBirth As Long, colDeath As Long

    Dim pid As String, info As Object

    Set dict = CreateObject("Scripting.Dictionary")

    If Not SheetExists(SH_WORK_PERSON) Then Set BuildPersonInfoIndex = dict: Exit Function

    Set ws = GetSheet(SH_WORK_PERSON)

    colId = FirstHeaderColumn(ws, Array("�l��ID"), 1)

    colName = FirstHeaderColumn(ws, Array("�����\��", "����"), 1)

    colRel = FirstHeaderColumn(ws, Array("�푊���l���猩������", "����", "�\���p����"), 1)

    colBirth = FirstHeaderColumn(ws, Array("���N����"), 1)

    colDeath = FirstHeaderColumn(ws, Array("���S��"), 1)

    If colId = 0 Then Set BuildPersonInfoIndex = dict: Exit Function

    lastR = LastRow(ws, colId)

    For r = 2 To lastR

        pid = CellText(ws.Cells(r, colId).Value)

        If Len(pid) > 0 Then

            Set info = CreateObject("Scripting.Dictionary")

            info("Name") = GetCellByCol(ws, r, colName)

            info("Relation") = GetCellByCol(ws, r, colRel)

            If colBirth > 0 Then info("Birth") = ToDateOrEmpty(ws.Cells(r, colBirth).Value) Else info("Birth") = Empty

            If colDeath > 0 Then info("Death") = ToDateOrEmpty(ws.Cells(r, colDeath).Value) Else info("Death") = Empty

            If dict.Exists(pid) Then dict.Remove pid

            dict.Add pid, info

        End If

    Next r

    Set BuildPersonInfoIndex = dict

End Function




Private Function BuildMarriageDateIndex() As Object
    '���啪�̓G���W������A�����C�x���g�����̓ǂݎ��Ӗ��𕪗��B
    'T_��������������΂������Ɏg���A���`����T_�֌W���������݊��ޗ��Ƃ��ēǂށB
    Set BuildMarriageDateIndex = BuildMarriageLifeEventIndex(mPersonInfo)
End Function

Private Sub AddLifeEventToIndex(ByVal dict As Object, ByVal personId As String, ByVal eventDate As Date, ByVal eventText As String)

    Dim col As Collection, item As Object
    If dict Is Nothing Or Len(personId) = 0 Then Exit Sub
    If dict.Exists(personId) Then
        Set col = dict(personId)
    Else
        Set col = New Collection
        dict.Add personId, col
    End If
    Set item = CreateObject("Scripting.Dictionary")
    item("Date") = DateValue(eventDate)
    item("Text") = eventText
    col.Add item

End Sub

Private Function BuildRelationPairIndex() As Object
    Set BuildRelationPairIndex = BuildAnalysisRelationPairIndex()
End Function

Private Function RelationPairKey(ByVal personId1 As String, ByVal personId2 As String) As String
    RelationPairKey = personId1 & "|" & personId2
End Function

Private Function IsMovePaymentRelevantPerson(ByVal txPersonId As String, ByVal moverPersonId As String) As Boolean

    If Len(txPersonId) = 0 Or Len(moverPersonId) = 0 Then Exit Function
    If txPersonId = moverPersonId Then IsMovePaymentRelevantPerson = True: Exit Function
    If Len(mDecedentId) > 0 And txPersonId = mDecedentId Then IsMovePaymentRelevantPerson = True: Exit Function

    If Not mRelationPairs Is Nothing Then
        If mRelationPairs.Exists(RelationPairKey(txPersonId, moverPersonId)) Then
            IsMovePaymentRelevantPerson = True
            Exit Function
        End If
    End If

    If IsKinshipPerson(txPersonId) And IsKinshipPerson(moverPersonId) Then
        IsMovePaymentRelevantPerson = True
        Exit Function
    End If

End Function

Private Function IsKinshipPerson(ByVal personId As String) As Boolean

    Dim info As Object, relText As String

    If Len(personId) = 0 Then Exit Function
    If Len(mDecedentId) > 0 And personId = mDecedentId Then IsKinshipPerson = True: Exit Function
    If mPersonInfo Is Nothing Then Exit Function
    If Not mPersonInfo.Exists(personId) Then Exit Function

    Set info = mPersonInfo(personId)
    If info.Exists("Relation") Then relText = CStr(info("Relation"))
    IsKinshipPerson = RelationTextLooksKinship(relText)

End Function

Private Function RelationTextLooksKinship(ByVal relText As String) As Boolean

    relText = Trim$(relText)
    If Len(relText) = 0 Then Exit Function
    If InStr(1, relText, "�֌W��", vbTextCompare) > 0 Then Exit Function
    If InStr(1, relText, "���̑�", vbTextCompare) > 0 Then Exit Function
    If InStr(1, relText, "�m�l", vbTextCompare) > 0 Then Exit Function
    If InStr(1, relText, "�s��", vbTextCompare) > 0 Then Exit Function
    RelationTextLooksKinship = True

End Function

Private Function PersonDisplayNameSafe(ByVal personId As String) As String

    Dim info As Object
    If Len(personId) = 0 Then Exit Function
    If mPersonInfo Is Nothing Then Exit Function
    If Not mPersonInfo.Exists(personId) Then Exit Function
    Set info = mPersonInfo(personId)
    If info.Exists("Name") Then PersonDisplayNameSafe = CStr(info("Name"))

End Function

Private Function BuildAddressByPersonIndex() As Object
    Set BuildAddressByPersonIndex = BuildAnalysisAddressByPersonIndex()
End Function

Private Function PersonAgeAtDate(ByVal personId As String, ByVal atDate As Date) As String

    Dim info As Object, b As Variant, d As Variant, age As Long

    If mPersonInfo Is Nothing Then Exit Function

    If Not mPersonInfo.Exists(personId) Then Exit Function

    Set info = mPersonInfo(personId)

    b = info("Birth")

    d = info("Death")

    If Not IsDate(b) Then Exit Function

    If atDate < CDate(b) Then PersonAgeAtDate = "�o���O": Exit Function

    If IsDate(d) Then

        If atDate > CDate(d) Then

            age = AgeYears(CDate(b), CDate(d))

            PersonAgeAtDate = "���S��/���S��" & CStr(age) & "��"

            Exit Function

        End If

    End If

    age = AgeYears(CDate(b), atDate)

    PersonAgeAtDate = CStr(age) & "��"

End Function




Private Function PersonAgeYearsAtDate(ByVal personId As String, ByVal atDate As Date) As Long

    Dim info As Object, b As Variant, d As Variant

    PersonAgeYearsAtDate = -1

    If mPersonInfo Is Nothing Then Exit Function

    If Not mPersonInfo.Exists(personId) Then Exit Function

    Set info = mPersonInfo(personId)

    b = info("Birth")

    d = info("Death")

    If Not IsDate(b) Then Exit Function

    If atDate < CDate(b) Then Exit Function

    If IsDate(d) Then

        If atDate > CDate(d) Then

            PersonAgeYearsAtDate = AgeYears(CDate(b), CDate(d))

            Exit Function

        End If

    End If

    PersonAgeYearsAtDate = AgeYears(CDate(b), atDate)

End Function

Private Function AddressChangeNearDate(ByVal personId As String, ByVal atDate As Date, ByVal windowDays As Long) As String

    Dim col As Collection, rec As Object, s As Variant, e As Variant, diffDays As Long

    If mAddressByPerson Is Nothing Then Exit Function

    If Not mAddressByPerson.Exists(personId) Then Exit Function

    Set col = mAddressByPerson(personId)

    For Each rec In col

        s = rec("Start")

        e = rec("End")

        If IsDate(s) Then

            diffDays = Abs(DateDiff("d", CDate(s), atDate))

            If diffDays <= windowDays Then

                AddressChangeNearDate = "�]���J�n" & CStr(diffDays) & "����"

                Exit Function

            End If

        End If

        If IsDate(e) Then

            diffDays = Abs(DateDiff("d", CDate(e), atDate))

            If diffDays <= windowDays Then

                AddressChangeNearDate = "�]���I��" & CStr(diffDays) & "����"

                Exit Function

            End If

        End If

    Next rec

End Function


Private Function RelatedMoveNearTransaction(ByVal txPersonId As String, ByVal atDate As Date, ByVal windowDays As Long) As String

    Dim moverId As Variant, moveText As String, moverName As String

    If Len(txPersonId) = 0 Then Exit Function
    If mAddressByPerson Is Nothing Then Exit Function

    For Each moverId In mAddressByPerson.Keys
        If IsMovePaymentRelevantPerson(txPersonId, CStr(moverId)) Then
            moveText = AddressChangeNearDate(CStr(moverId), atDate, windowDays)
            If Len(moveText) > 0 Then
                moverName = PersonDisplayNameSafe(CStr(moverId))
                If Len(moverName) = 0 Then moverName = CStr(moverId)
                RelatedMoveNearTransaction = "�]����:" & ClipText(moverName, 8) & " " & moveText
                Exit Function
            End If
        End If
    Next moverId

End Function

Private Function PersonAgeAtInheritance(ByVal personId As String) As String

    If IsDate(mInheritanceDate) Then PersonAgeAtInheritance = PersonAgeAtDate(personId, CDate(mInheritanceDate))

End Function



Private Function AgeYears(ByVal birthDate As Date, ByVal atDate As Date) As Long

    AgeYears = Year(atDate) - Year(birthDate)

    If Month(atDate) < Month(birthDate) Or (Month(atDate) = Month(birthDate) And Day(atDate) < Day(birthDate)) Then AgeYears = AgeYears - 1

End Function



Private Function PersonAddressAtDate(ByVal personId As String, ByVal atDate As Date, ByVal returnKey As Boolean) As String

    Dim col As Collection, rec As Object, s As Variant, e As Variant
    Dim startOk As Boolean, endOk As Boolean

    If mAddressByPerson Is Nothing Then Exit Function

    If Not mAddressByPerson.Exists(personId) Then Exit Function

    Set col = mAddressByPerson(personId)

    For Each rec In col

        s = rec("Start"): e = rec("End")

        startOk = True
        endOk = True
        If IsDate(s) Then startOk = (CDate(s) <= atDate)
        If IsDate(e) Then endOk = (CDate(e) >= atDate)
        If startOk And endOk Then

            If returnKey Then PersonAddressAtDate = CStr(rec("Key")) Else PersonAddressAtDate = CStr(rec("Address"))

            Exit Function

        End If

    Next rec

End Function



Private Function AgeHintForRecords(ByVal outs As Collection, ByVal ins As Collection) As String

    AgeHintForRecords = JoinNonBlank(AgeHintForSide(outs), AgeHintForSide(ins), " / ")

    If Len(AgeHintForRecords) > 0 Then AgeHintForRecords = "�N��: " & AgeHintForRecords

End Function



Private Function AgeHintForSide(ByVal recs As Collection) As String

    Dim d As Object, rec As Object, displayAge As String, nameText As String

    Set d = CreateObject("Scripting.Dictionary")

    For Each rec In recs

        displayAge = CStr(rec("AgeAtTx"))

        If Len(displayAge) > 0 Then

            nameText = CStr(rec("Name"))

            If Len(nameText) = 0 Then nameText = CStr(rec("PersonId"))

            d(ClipText(nameText, 8) & " " & displayAge) = True

        End If

    Next rec

    AgeHintForSide = ClipText(JoinDictionaryKeys(d, " / "), 48)

End Function



Private Function AgeHintForRecord(ByVal rec As Object) As String

    If rec Is Nothing Then Exit Function

    If Not KeyExists(rec, "AgeAtTx") Then Exit Function

    If Len(CStr(rec("AgeAtTx"))) > 0 Then AgeHintForRecord = "�N��: " & CStr(rec("AgeAtTx"))

End Function



Private Function AddressHintForRecords(ByVal outs As Collection, ByVal ins As Collection) As String

    Dim outAddr As Object, inAddr As Object, k As Variant, outText As String, inText As String, body As String

    Set outAddr = AddressDictForSide(outs)

    Set inAddr = AddressDictForSide(ins)

    Dim keyText As String

    For Each k In outAddr.Keys

        keyText = CStr(k)
        If Len(keyText) > 0 Then
            If inAddr.Exists(keyText) Then
                AddressHintForRecords = "�Z��: ���� " & ClipText(CStr(outAddr(keyText)), 20)
                Exit Function
            End If
        End If

    Next k

    outText = ClipText(DictionaryItemsText(outAddr, " / "), 20)

    inText = ClipText(DictionaryItemsText(inAddr, " / "), 20)

    If Len(outText) > 0 Then body = "�o " & outText

    If Len(inText) > 0 Then body = JoinNonBlank(body, "�� " & inText, " / ")

    If Len(body) > 0 Then AddressHintForRecords = "�Z��: " & body

End Function



Private Function AddressDictForSide(ByVal recs As Collection) As Object

    Dim d As Object, rec As Object, keyText As String, addrText As String

    Set d = CreateObject("Scripting.Dictionary")

    For Each rec In recs

        keyText = CStr(rec("AddressKeyAtTx"))

        addrText = CStr(rec("AddressAtTx"))

        If Len(keyText) > 0 Then

            If Len(addrText) = 0 Then addrText = keyText

            d(keyText) = addrText

        End If

    Next rec

    Set AddressDictForSide = d

End Function



Private Function DictionaryItemsText(ByVal d As Object, ByVal sep As String) As String

    Dim k As Variant

    For Each k In d.Keys

        DictionaryItemsText = JoinNonBlank(DictionaryItemsText, CStr(d(k)), sep)

    Next k

End Function



Private Function AddressHintForRecord(ByVal rec As Object) As String

    If rec Is Nothing Then Exit Function

    If Not KeyExists(rec, "AddressAtTx") Then Exit Function

    If Len(CStr(rec("AddressAtTx"))) > 0 Then AddressHintForRecord = "�Z��: " & ClipText(CStr(rec("AddressAtTx")), 30)

End Function




Private Function RiskSignalText(ByVal outs As Collection, ByVal ins As Collection) As String
    RiskSignalText = BuildIntegratedAnalysisRiskSignalSummary(outs, ins, mDecedentId, mInheritanceDate, _
        mMinShift, mUnknownThreshold, mRelationPairs, mMarriageByPerson, mPersonInfo, mTimeCluster, mAccountOperationPatternCount)
End Function
Private Function RiskSignalForSingle(ByVal rec As Object) As String

    Dim outs As New Collection, ins As New Collection

    If rec Is Nothing Then Exit Function

    If KeyExists(rec, "Out") Then

        If CDbl(rec("Out")) > 0 Then outs.Add rec

    End If

    If KeyExists(rec, "In") Then

        If CDbl(rec("In")) > 0 Then ins.Add rec

    End If

    RiskSignalForSingle = RiskSignalText(outs, ins)

End Function


Public Sub BuildTransactionTagWorkSheet(ByVal outs As Collection, ByVal ins As Collection)

    Dim ws As Worksheet
    Dim tagMap As Object
    Dim dayIndex As Object, shopIndex As Object, repeatIndex As Object
    Dim allRecs As Collection
    Dim k As Variant, rec As Object, item As Object, outR As Long

    If SheetExists(SH_WORK_TX_TAG) Then
        Set ws = GetSheet(SH_WORK_TX_TAG)
    Else
        Set ws = GetOrCreateSheet(SH_WORK_TX_TAG, False)
    End If
    InitTransactionTagHeaders ws, True

    Set tagMap = CreateObject("Scripting.Dictionary")
    Set allRecs = AllTransactionRecordCollection()

    For Each rec In allRecs
        AddEventAndContextTags tagMap, rec
        AddTimeSimilarityTags tagMap, rec
    Next rec

    Set dayIndex = BuildRecordClusterIndex(allRecs, "day")
    AddClusterTags tagMap, dayIndex, "����������������", "����ގ�", "�������ɕ������`�E���������̎�����W��", "�ʒ��E�J�[�h�E��ӂ̊Ǘ��ҁA���X�ҁAATM����҂��m�F", 2

    Set shopIndex = BuildRecordClusterIndex(allRecs, "shopday")
    AddClusterTags tagMap, shopIndex, "�戵�X�W��", "����ގ�", "������s�E�戵�X�E�����ɕ������`�����������Ă���", "�����戵�X�A���X�ҁA�`�[�A���������҂��m�F", 2

    Set repeatIndex = BuildRecordClusterIndex(allRecs, "repeat")
    AddClusterTags tagMap, repeatIndex, "���z��������", "����ގ�", "��������œ��z�܂��͋ߎ��z�̓��o��������", "����I�Ȑ�����A�ԍρA���^�A���`�a���Ǘ��̂����ꂩ���m�F", 1

    AppendStandaloneContextCandidates tagMap

    outR = 2
    For Each k In tagMap.Keys
        Set item = tagMap(k)
        ws.Cells(outR, 1).Value = CStr(k)
        ws.Cells(outR, 2).Value = CStr(item("Tags"))
        ws.Cells(outR, 3).Value = CLng(item("Severity"))
        ws.Cells(outR, 4).Value = CStr(item("Categories"))
        ws.Cells(outR, 5).Value = CStr(item("Evidence"))
        ws.Cells(outR, 6).Value = CStr(item("Action"))
        ws.Cells(outR, 7).Value = CStr(item("People"))
        ws.Cells(outR, 8).Value = CStr(item("Dates"))
        ws.Cells(outR, 9).Value = CStr(item("Sources"))
        ws.Cells(outR, 10).Value = Now
        outR = outR + 1
    Next k

    If outR > 2 Then
        FormatBody ws.Range("A2:J" & CStr(outR - 1))
        AutoFitSheetSmart ws, "A:J", 8, 45
    End If

    mEnhancedTagCount = tagMap.Count

End Sub

Private Function AllTransactionRecordCollection() As Collection

    Dim col As New Collection, k As Variant

    If Not mTxById Is Nothing Then
        For Each k In mTxById.Keys
            col.Add mTxById(k)
        Next k
    End If

    Set AllTransactionRecordCollection = col

End Function

Private Sub AddEventAndContextTags(ByVal tagMap As Object, ByVal rec As Object)

    Dim amountValue As Double, txDate As Date, personId As String, sideText As String
    Dim evidence As String, peopleText As String, eventText As String, daysBefore As Long
    Dim beforeValue As Double, afterValue As Double, ratio As Double
    Dim tagSeverity As Long

    If rec Is Nothing Then Exit Sub
    If Not KeyExists(rec, "TxId") Then Exit Sub
    If Not IsDate(rec("Date")) Then Exit Sub

    txDate = CDate(rec("Date"))
    personId = ""
    If KeyExists(rec, "PersonId") Then personId = CStr(rec("PersonId"))
    peopleText = PersonDisplayNameSafe(personId)
    If Len(peopleText) = 0 Then
        If KeyExists(rec, "Name") Then peopleText = CStr(rec("Name"))
    End If
    sideText = TransactionSideText(rec)
    amountValue = TransactionAmountValue(rec)

    If amountValue >= mMinShift Then
        If KeyExists(rec, "AddressChangeNearTx") Then
            If Len(CStr(rec("AddressChangeNearTx"))) > 0 Then
                evidence = sideText & " " & Format$(amountValue, "#,##0") & "�~ / " & CStr(rec("AddressChangeNearTx"))
                AddTxTag tagMap, rec, "�{�l�]���A��", 2, "�C�x���g�A��", evidence, "�Z���ٓ��̗��R�A�Z���E���z��E�����x���E���^�����m�F", peopleText, Format$(txDate, "yyyy/m/d"), "�Z������"
            End If
        End If

        If KeyExists(rec, "RelatedMoveNearTx") Then
            If Len(CStr(rec("RelatedMoveNearTx"))) > 0 Then
                evidence = sideText & " " & Format$(amountValue, "#,##0") & "�~ / " & CStr(rec("RelatedMoveNearTx"))
                AddTxTag tagMap, rec, "�e���]���A��", 3, "�C�x���g�A��", evidence, "�]���҂Ƃ̊֌W�A�Z��֘A�x�o�A�푊���l���S�̗L���A���^�����m�F", peopleText, Format$(txDate, "yyyy/m/d"), "�Z�������E�֌W"
            End If
        End If

        eventText = RelatedMarriageNearText(personId, txDate, DEFAULT_MOVE_NEAR_WINDOW_DAYS)
        If Len(eventText) > 0 Then
            evidence = sideText & " " & Format$(amountValue, "#,##0") & "�~ / " & eventText
            AddTxTag tagMap, rec, "�����A��", 3, "�C�x���g�A��", evidence, "������p�A�V�����x���A�ݕt�E�ԍρA���^�Ő\���̗v�ۂ��m�F", peopleText, Format$(txDate, "yyyy/m/d"), "�֌W�E������"
        End If

        eventText = RelatedBirthNearText(personId, txDate, DEFAULT_MOVE_NEAR_WINDOW_DAYS)
        If Len(eventText) > 0 Then
            evidence = sideText & " " & Format$(amountValue, "#,##0") & "�~ / " & eventText
            AddTxTag tagMap, rec, "�o���A��", 2, "�C�x���g�A��", evidence, "�o�Y��E�玙��E������E���玑���E���^�����m�F", peopleText, Format$(txDate, "yyyy/m/d"), "���N�����E�֌W"
        End If

        If KeyExists(rec, "AgeYearsAtTx") Then
            If CLng(rec("AgeYearsAtTx")) >= 0 Then
                If CLng(rec("AgeYearsAtTx")) < YOUNG_ATTENTION_AGE_YEARS Then
                    evidence = peopleText & " " & CStr(rec("AgeYearsAtTx")) & "�� / " & sideText & " " & Format$(amountValue, "#,##0") & "�~"
                    AddTxTag tagMap, rec, "��N�ҍ��z", 2, "�l������", evidence, "�{�l�����A�e���Ǘ��A���^�E���`�a���Y�������m�F", peopleText, Format$(txDate, "yyyy/m/d"), "���N����"
                End If
            End If
        End If

        If IsDecedentRecord(rec) Then
            If KeyExists(rec, "Out") Then
                If CDbl(rec("Out")) >= mUnknownThreshold Then
                    daysBefore = DaysBeforeInheritance(txDate)
                    If daysBefore >= 0 Then
                        If daysBefore <= 365 Then
                            evidence = "�����J�n" & CStr(daysBefore) & "���O / �o�� " & Format$(CDbl(rec("Out")), "#,##0") & "�~"
                            If daysBefore <= 30 Then
                                tagSeverity = 3
                            Else
                                tagSeverity = 2
                            End If
                            AddTxTag tagMap, rec, "�����O����o��", tagSeverity, "�������O", evidence, "���o�ړI�A�����ۊǁA���V��E������E���^�E���`�a���ړ����m�F", peopleText, Format$(txDate, "yyyy/m/d"), "�����J�n��"
                        End If
                    End If
                End If
            End If
        End If

        If IsAfterInheritanceRecord(rec) Then
            evidence = "�����J�n�� / " & sideText & " " & Format$(amountValue, "#,##0") & "�~"
            AddTxTag tagMap, rec, "�����J�n����", 3, "�����J�n��", evidence, "�����J�n��̕��߁E�������R�A�㗝�����A��Y�����m�F", peopleText, Format$(txDate, "yyyy/m/d"), "�����J�n��"
        End If

        If KeyExists(rec, "BalanceAfter") Then
            If KeyExists(rec, "BalanceBefore") Then
                beforeValue = CDbl(rec("BalanceBefore"))
                afterValue = CDbl(rec("BalanceAfter"))
                If beforeValue > 0 Then ratio = amountValue / beforeValue Else ratio = 0#
                If KeyExists(rec, "Out") Then
                    If CDbl(rec("Out")) > 0 Then
                        If ratio >= 0.5 Or afterValue <= beforeValue * 0.1 Then
                            evidence = "�o����c�� " & Format$(afterValue, "#,##0") & "�~ / ���O���� " & Format$(beforeValue, "#,##0") & "�~"
                            AddTxTag tagMap, rec, "�c���}��", 3, "�c���ُ�", evidence, "�o����̎������݁A�����ۊǁA�ړ���A�`�[�m�F��D��", peopleText, Format$(txDate, "yyyy/m/d"), "�����c��"
                        End If
                    End If
                End If
                If KeyExists(rec, "In") Then
                    If CDbl(rec("In")) > 0 Then
                        If ratio >= 0.5 Then
                            evidence = "������c�� " & Format$(afterValue, "#,##0") & "�~ / ���O���� " & Format$(beforeValue, "#,##0") & "�~"
                            AddTxTag tagMap, rec, "�c���}��", 2, "�c���ُ�", evidence, "���������A����������̈ړ��A���^�E�ԍρE�ؓ����m�F", peopleText, Format$(txDate, "yyyy/m/d"), "�����c��"
                        End If
                    End If
                End If
            End If
        End If
    End If

End Sub

Private Sub AddTimeSimilarityTags(ByVal tagMap As Object, ByVal rec As Object)

    Dim col As Collection, accountCount As Long, personCount As Long, evidence As String
    Dim cnt As Long, peopleText As String

    If rec Is Nothing Then Exit Sub
    If Not KeyExists(rec, "TxId") Then Exit Sub

    Set col = NearbyTimeClusterRecords(rec)
    If Not col Is Nothing Then
        accountCount = DistinctCountInCluster(col, "AccountId")
        personCount = DistinctCountInCluster(col, "PersonId")
        If col.Count >= 3 And (accountCount >= 2 Or personCount >= 2) Then
            evidence = "����15���ёO�� " & CStr(col.Count) & "�� / ����" & CStr(accountCount) & " / �l��" & CStr(personCount)
            AddTxTag tagMap, rec, "�������ѕ������`", 3, "����ގ�", evidence, "ATM�E�����̑���ҁA�ʒ��E�J�[�h�E��ӊǗ��҂��m�F", ClusterPeopleText(col), Format$(CDate(rec("Date")), "yyyy/m/d"), "�������"
        End If
    End If

    If Not mAccountOperationPatternCount Is Nothing Then
        If KeyExists(rec, "AccountId") Then
            If mAccountOperationPatternCount.Exists(CStr(rec("AccountId"))) Then
                cnt = CLng(mAccountOperationPatternCount(CStr(rec("AccountId"))))
                If cnt >= 3 Then
                    peopleText = PersonDisplayNameSafe(CStr(rec("PersonId")))
                    If Len(peopleText) = 0 Then peopleText = CStr(rec("Name"))
                    evidence = "�ގ������тŕ��������Ɛڑ� " & CStr(cnt) & "��"
                    AddTxTag tagMap, rec, "������������", 2, "����ގ�", evidence, "����l���ɂ�镡�������Ǘ��A�Ƒ������̈ꊇ������m�F", peopleText, Format$(CDate(rec("Date")), "yyyy/m/d"), "�������"
                End If
            End If
        End If
    End If

End Sub

Private Function BuildRecordClusterIndex(ByVal records As Collection, ByVal modeText As String) As Object

    Dim idx As Object, rec As Object, k As String, col As Collection
    Set idx = CreateObject("Scripting.Dictionary")

    If records Is Nothing Then
        Set BuildRecordClusterIndex = idx
        Exit Function
    End If

    For Each rec In records
        k = RecordClusterKey(rec, modeText)
        If Len(k) > 0 Then
            If idx.Exists(k) Then
                Set col = idx(k)
            Else
                Set col = New Collection
                idx.Add k, col
            End If
            col.Add rec
        End If
    Next rec

    Set BuildRecordClusterIndex = idx

End Function

Private Function RecordClusterKey(ByVal rec As Object, ByVal modeText As String) As String

    Dim amountValue As Double, shopText As String, bankText As String, sideText As String

    If rec Is Nothing Then Exit Function
    If Not KeyExists(rec, "DateKey") Then Exit Function

    Select Case LCase$(modeText)
        Case "day"
            RecordClusterKey = CStr(rec("DateKey"))
        Case "shopday"
            shopText = ""
            If KeyExists(rec, "Shop") Then shopText = NormalizePatternText(CStr(rec("Shop")))
            bankText = ""
            If KeyExists(rec, "Bank") Then bankText = NormalizePatternText(CStr(rec("Bank")))
            If Len(shopText) = 0 And Len(bankText) = 0 Then Exit Function
            RecordClusterKey = CStr(rec("DateKey")) & "|" & bankText & "|" & shopText
        Case "repeat"
            amountValue = TransactionAmountValue(rec)
            If amountValue < mUnknownThreshold Then Exit Function
            If Not KeyExists(rec, "AccountId") Then Exit Function
            If Len(CStr(rec("AccountId"))) = 0 Then Exit Function
            sideText = TransactionSideText(rec)
            RecordClusterKey = CStr(rec("AccountId")) & "|" & sideText & "|" & CStr(CLng(amountValue / 1000#))
    End Select

End Function

Private Sub AddClusterTags(ByVal tagMap As Object, ByVal idx As Object, ByVal tagText As String, ByVal categoryText As String, ByVal evidencePrefix As String, ByVal actionText As String, ByVal severityValue As Long)

    Dim k As Variant, col As Collection, rec As Object
    Dim accountCount As Long, personCount As Long, dateCount As Long, evidence As String

    If idx Is Nothing Then Exit Sub

    For Each k In idx.Keys
        Set col = idx(k)
        If Not col Is Nothing Then
            accountCount = DistinctCountInCluster(col, "AccountId")
            personCount = DistinctCountInCluster(col, "PersonId")
            dateCount = DistinctDateCountInCluster(col)
            If col.Count >= 3 And (accountCount >= 2 Or personCount >= 2 Or dateCount >= 3) Then
                evidence = evidencePrefix & " / ����" & CStr(col.Count) & " / ����" & CStr(accountCount) & " / �l��" & CStr(personCount)
                For Each rec In col
                    AddTxTag tagMap, rec, tagText, severityValue, categoryText, evidence, actionText, ClusterPeopleText(col), ClusterDateRangeText(col), "����p�^�[��"
                Next rec
            End If
        End If
    Next k

End Sub

Private Sub AddTxTag(ByVal tagMap As Object, ByVal rec As Object, ByVal tagText As String, ByVal severityValue As Long, ByVal categoryText As String, ByVal evidenceText As String, ByVal actionText As String, ByVal peopleText As String, ByVal dateText As String, ByVal sourceText As String)

    Dim txId As String, item As Object

    If tagMap Is Nothing Or rec Is Nothing Then Exit Sub
    If Not KeyExists(rec, "TxId") Then Exit Sub
    txId = CStr(rec("TxId"))
    If Len(txId) = 0 Or Len(tagText) = 0 Then Exit Sub

    If tagMap.Exists(txId) Then
        Set item = tagMap(txId)
    Else
        Set item = CreateObject("Scripting.Dictionary")
        item("Tags") = ""
        item("Severity") = 0
        item("Categories") = ""
        item("Evidence") = ""
        item("Action") = ""
        item("People") = ""
        item("Dates") = ""
        item("Sources") = ""
        tagMap.Add txId, item
    End If

    item("Tags") = AppendUniqueText(CStr(item("Tags")), tagText, " / ")
    If severityValue > CLng(item("Severity")) Then item("Severity") = severityValue
    item("Categories") = AppendUniqueText(CStr(item("Categories")), categoryText, " / ")
    item("Evidence") = AppendUniqueText(CStr(item("Evidence")), evidenceText, " / ")
    item("Action") = AppendUniqueText(CStr(item("Action")), actionText, " / ")
    item("People") = AppendUniqueText(CStr(item("People")), peopleText, " / ")
    item("Dates") = AppendUniqueText(CStr(item("Dates")), dateText, " / ")
    item("Sources") = AppendUniqueText(CStr(item("Sources")), sourceText, " / ")

End Sub

Private Function AppendUniqueText(ByVal baseText As String, ByVal addText As String, ByVal sep As String) As String

    addText = Trim$(addText)
    If Len(addText) = 0 Then
        AppendUniqueText = baseText
    ElseIf Len(baseText) = 0 Then
        AppendUniqueText = addText
    ElseIf InStr(1, sep & baseText & sep, sep & addText & sep, vbTextCompare) > 0 Then
        AppendUniqueText = baseText
    Else
        AppendUniqueText = baseText & sep & addText
    End If

End Function

Private Function TransactionAmountValue(ByVal rec As Object) As Double

    If rec Is Nothing Then Exit Function
    If KeyExists(rec, "Out") Then
        If CDbl(rec("Out")) > TransactionAmountValue Then TransactionAmountValue = CDbl(rec("Out"))
    End If
    If KeyExists(rec, "In") Then
        If CDbl(rec("In")) > TransactionAmountValue Then TransactionAmountValue = CDbl(rec("In"))
    End If

End Function

Private Function TransactionSideText(ByVal rec As Object) As String

    If rec Is Nothing Then Exit Function
    If KeyExists(rec, "Out") Then
        If CDbl(rec("Out")) > 0 Then TransactionSideText = "�o��": Exit Function
    End If
    If KeyExists(rec, "In") Then
        If CDbl(rec("In")) > 0 Then TransactionSideText = "����": Exit Function
    End If
    TransactionSideText = "���"

End Function

Private Function NormalizePatternText(ByVal textValue As String) As String

    NormalizePatternText = Trim$(Replace$(Replace$(textValue, "�@", " "), vbTab, " "))

End Function

Private Function ClusterPeopleText(ByVal col As Collection) As String

    Dim d As Object, rec As Object, t As String
    Set d = CreateObject("Scripting.Dictionary")
    If col Is Nothing Then Exit Function
    For Each rec In col
        t = ""
        If KeyExists(rec, "PersonId") Then t = PersonDisplayNameSafe(CStr(rec("PersonId")))
        If Len(t) = 0 Then
            If KeyExists(rec, "Name") Then t = CStr(rec("Name"))
        End If
        If Len(t) = 0 Then
            If KeyExists(rec, "PersonId") Then t = CStr(rec("PersonId"))
        End If
        If Len(t) > 0 Then
            If Not d.Exists(t) Then d.Add t, True
        End If
    Next rec
    ClusterPeopleText = JoinDictionaryKeys(d, "�A")

End Function

Private Function DistinctDateCountInCluster(ByVal col As Collection) As Long

    Dim d As Object, rec As Object, k As String
    Set d = CreateObject("Scripting.Dictionary")
    If col Is Nothing Then Exit Function
    For Each rec In col
        If KeyExists(rec, "DateKey") Then
            k = CStr(rec("DateKey"))
            If Len(k) > 0 Then
                If Not d.Exists(k) Then d.Add k, True
            End If
        End If
    Next rec
    DistinctDateCountInCluster = d.Count

End Function

Private Function ClusterDateRangeText(ByVal col As Collection) As String

    Dim rec As Object, dMin As Date, dMax As Date, hasDate As Boolean
    If col Is Nothing Then Exit Function
    For Each rec In col
        If KeyExists(rec, "Date") Then
            If IsDate(rec("Date")) Then
                If Not hasDate Then
                    dMin = DateValue(CDate(rec("Date")))
                    dMax = dMin
                    hasDate = True
                Else
                    If DateValue(CDate(rec("Date"))) < dMin Then dMin = DateValue(CDate(rec("Date")))
                    If DateValue(CDate(rec("Date"))) > dMax Then dMax = DateValue(CDate(rec("Date")))
                End If
            End If
        End If
    Next rec
    If hasDate Then
        If dMin = dMax Then
            ClusterDateRangeText = Format$(dMin, "yyyy/m/d")
        Else
            ClusterDateRangeText = Format$(dMin, "yyyy/m/d") & "-" & Format$(dMax, "yyyy/m/d")
        End If
    End If

End Function

Private Function RelatedMarriageNearText(ByVal personId As String, ByVal txDate As Date, ByVal windowDays As Long) As String

    Dim pid As Variant, col As Collection, item As Object, daysDiff As Long, bestDays As Long, bestText As String
    Dim related As Boolean

    If mMarriageByPerson Is Nothing Then Exit Function
    If Len(personId) = 0 Then Exit Function
    bestDays = 999999

    For Each pid In mMarriageByPerson.Keys
        related = (CStr(pid) = personId)
        If Not related Then
            If Not mRelationPairs Is Nothing Then related = mRelationPairs.Exists(RelationPairKey(personId, CStr(pid)))
        End If
        If related Then
            Set col = mMarriageByPerson(pid)
            For Each item In col
                If KeyExists(item, "Date") Then
                    If IsDate(item("Date")) Then
                        daysDiff = Abs(DateDiff("d", DateValue(CDate(item("Date"))), DateValue(txDate)))
                        If daysDiff <= windowDays And daysDiff < bestDays Then
                            bestDays = daysDiff
                            If KeyExists(item, "Text") Then
                                bestText = CStr(item("Text")) & " " & CStr(daysDiff) & "����"
                            Else
                                bestText = "����:" & PersonDisplayNameSafe(CStr(pid)) & " " & CStr(daysDiff) & "����"
                            End If
                        End If
                    End If
                End If
            Next item
        End If
    Next pid

    RelatedMarriageNearText = bestText

End Function

Private Sub AppendStandaloneContextCandidates(ByVal tagMap As Object)

    Dim existingDetail As Object, k As Variant, item As Object, rec As Object
    Dim analysisId As String, kindText As String, score As Long, voucher As String
    Dim stateKey As String, decisionText As String, operationMemoText As String
    Dim outDateText As String, inDateText As String, outSum As Double, inSum As Double, idsOut As String, idsIn As String
    Dim personText As String, categoryText As String
    Dim outPersonText As String, inPersonText As String, inhTimingText As String

    Set existingDetail = ExistingDetailTxIdSet()
    If tagMap Is Nothing Then Exit Sub
    If mTxById Is Nothing Then Exit Sub

    For Each k In tagMap.Keys
        If Not existingDetail.Exists(CStr(k)) Then
            If mTxById.Exists(CStr(k)) Then
                Set item = tagMap(k)
                If CLng(item("Severity")) >= 2 Then
                    If ResultLimitReached() Then Exit For
                    Set rec = mTxById(CStr(k))
                    analysisId = NextId("���͌��")
                    categoryText = CStr(item("Categories"))
                    kindText = ContextKindFromCategory(categoryText)
                    score = 55 + CLng(item("Severity")) * 10
                    If score > 95 Then score = 95
                    voucher = VOUCHER_NO
                    If TransactionAmountValue(rec) >= mVoucherThreshold Then voucher = VOUCHER_YES
                    decisionText = DECISION_USE
                    operationMemoText = "�����^�O�P�ƌ��B�^�O�t����������\�ƃt���O���o�ō����m�F�B"
                    idsOut = "": idsIn = "": outSum = 0#: inSum = 0#: outDateText = "": inDateText = ""
                    If KeyExists(rec, "Out") Then
                        If CDbl(rec("Out")) > 0 Then
                            idsOut = CStr(k)
                            outSum = CDbl(rec("Out"))
                            outDateText = RecordDateTimeText(rec)
                        End If
                    End If
                    If KeyExists(rec, "In") Then
                        If CDbl(rec("In")) > 0 Then
                            idsIn = CStr(k)
                            inSum = CDbl(rec("In"))
                            inDateText = RecordDateTimeText(rec)
                        End If
                    End If
                    stateKey = BuildAnalysisStateKey("�����^�O", idsOut, idsIn)
                    If Not mManualVoucherOverrides Is Nothing Then
                        If mManualVoucherOverrides.Exists(stateKey) Then voucher = CStr(mManualVoucherOverrides(stateKey))
                        If mManualDecisionOverrides.Exists(stateKey) Then decisionText = CStr(mManualDecisionOverrides(stateKey))
                        If mManualMemoOverrides.Exists(stateKey) Then operationMemoText = CStr(mManualMemoOverrides(stateKey))
                    End If
                    decisionText = NormalizeDecisionText(decisionText)
                    If IsExcludeDecision(decisionText) Then voucher = VOUCHER_NO
                    personText = CStr(rec("Name"))
                    outPersonText = ""
                    inPersonText = ""
                    If Len(idsOut) > 0 Then outPersonText = personText
                    If Len(idsIn) > 0 Then inPersonText = personText
                    If IsAfterInheritanceRecord(rec) Then
                        inhTimingText = "�����J�n��"
                    Else
                        inhTimingText = "�����J�n�O/�s��"
                    End If
                    WriteResultRow analysisId, kindText, "�����^�O", score, voucher, outDateText, inDateText, outSum, inSum, outSum - inSum, _
                        outPersonText, inPersonText, "", _
                        inhTimingText, CStr(item("Tags")), _
                        idsOut, idsIn, CStr(rec("Bank")) & " " & CStr(rec("Shop")), CStr(item("Evidence")), _
                        CStr(item("Action")), decisionText, operationMemoText, AgeHintForRecord(rec), AddressHintForRecord(rec)
                    If Not IsExcludeDecision(decisionText) Then
                        If Len(idsOut) > 0 Then WriteDetailRows analysisId, kindText, voucher, "�o��", CollectionFromOne(rec), True
                        If Len(idsIn) > 0 Then WriteDetailRows analysisId, kindText, voucher, "����", CollectionFromOne(rec), False
                    End If
                    mContextCandidateCount = mContextCandidateCount + 1
                End If
            End If
        End If
    Next k

End Sub

Private Function ExistingDetailTxIdSet() As Object

    Dim d As Object, ws As Worksheet, lastR As Long, r As Long, txId As String
    Set d = CreateObject("Scripting.Dictionary")
    Set ws = GetSheet(SH_WORK_DETAIL)
    lastR = LastRow(ws, DET_COL_TX_ID)
    For r = 2 To lastR
        txId = CellText(ws.Cells(r, DET_COL_TX_ID).Value)
        If Len(txId) > 0 Then
            If Not d.Exists(txId) Then d.Add txId, True
        End If
    Next r
    Set ExistingDetailTxIdSet = d

End Function

Private Function ContextKindFromCategory(ByVal categoryText As String) As String

    If InStr(categoryText, "�C�x���g�A��") > 0 Or InStr(categoryText, "�������O") > 0 Or InStr(categoryText, "�����J�n��") > 0 Then
        ContextKindFromCategory = KIND_EVENT_FLAG
    ElseIf InStr(categoryText, "����ގ�") > 0 Then
        ContextKindFromCategory = KIND_OPERATION_FLAG
    Else
        ContextKindFromCategory = KIND_CONTEXT_FLAG
    End If

End Function

Private Sub EnrichTransactionAfterBalanceContext()
    EnrichAnalysisTransactionAfterBalanceContext mTxById
End Sub



Private Function TransactionAfterBalanceValue(ByVal v As Variant) As Variant
    TransactionAfterBalanceValue = ParseAnalysisTransactionBalanceValue(v)
End Function
Private Function RelatedBirthNearText(ByVal personId As String, ByVal txDate As Date, ByVal windowDays As Long) As String

    Dim pid As Variant, info As Object, birthDate As Variant, daysDiff As Long, bestDays As Long, bestText As String
    Dim related As Boolean
    If mPersonInfo Is Nothing Then Exit Function
    If Len(personId) = 0 Then Exit Function
    bestDays = 999999
    For Each pid In mPersonInfo.Keys
        related = (CStr(pid) = personId)
        If Not related Then
            If Not mRelationPairs Is Nothing Then
                related = mRelationPairs.Exists(RelationPairKey(personId, CStr(pid)))
            End If
        End If
        If related Then
            Set info = mPersonInfo(pid)
            If Not info Is Nothing Then
                If KeyExists(info, "Birth") Then
                    birthDate = info("Birth")
                    If IsDate(birthDate) Then
                        daysDiff = Abs(DateDiff("d", DateValue(CDate(birthDate)), DateValue(txDate)))
                        If daysDiff <= windowDays And daysDiff < bestDays Then
                            bestDays = daysDiff
                            bestText = "�o��:" & PersonDisplayNameSafe(CStr(pid)) & " " & CStr(daysDiff) & "����"
                        End If
                    End If
                End If
            End If
        End If
    Next pid
    RelatedBirthNearText = bestText

End Function

Private Function IsDecedentRecord(ByVal rec As Object) As Boolean

    If rec Is Nothing Then Exit Function
    If Len(mDecedentId) = 0 Then Exit Function
    If KeyExists(rec, "PersonId") Then IsDecedentRecord = (CStr(rec("PersonId")) = mDecedentId)

End Function

Private Function DaysBeforeInheritance(ByVal atDate As Date) As Long

    DaysBeforeInheritance = -1
    If Not IsDate(mInheritanceDate) Then Exit Function
    If DateValue(atDate) > DateValue(CDate(mInheritanceDate)) Then Exit Function
    DaysBeforeInheritance = DateDiff("d", DateValue(atDate), DateValue(CDate(mInheritanceDate)))

End Function

Private Function DistinctCountInCluster(ByVal col As Collection, ByVal fieldName As String) As Long

    Dim d As Object, rec As Object, k As String

    Set d = CreateObject("Scripting.Dictionary")

    If col Is Nothing Then Exit Function

    For Each rec In col

        If KeyExists(rec, fieldName) Then

            k = CStr(rec(fieldName))

            If Len(k) > 0 Then d(k) = True

        End If

    Next rec

    DistinctCountInCluster = d.Count

End Function



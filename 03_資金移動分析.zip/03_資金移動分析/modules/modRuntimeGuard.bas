Attribute VB_Name = "modRuntimeGuard"
Option Explicit

'====================================================================================
' �n���^�p�����̈��艻���C���[
'------------------------------------------------------------------------------------
' �ړI:
'   �E�G���[������Ԃ����A�����E�i�K�E�ΏہEErr����K���\������B
'   �E�o�͂� temp �ۑ� -> ���� -> �����ޔ� -> �������֒u�� -> ���s�������A�ōs���B
'   �E�ۑ���t�H���_�͑��K�w�ł��쐬����B
'   �E���O�p�V�[�g������ɕ\�֏o�����A�ʏ푀��Ŏg���V�[�g������\������B
'====================================================================================

Public Function RuntimeErrorText(ByVal procName As String, _
        Optional ByVal stepText As String = "", _
        Optional ByVal hintText As String = "", _
        Optional ByVal targetPath As String = "") As String
    RuntimeErrorText = RuntimeErrorTextFromValues(procName, stepText, hintText, targetPath, _
                                                  Err.Number, Err.Description, Err.Source)
End Function

Private Function RuntimeErrorTextFromValues(ByVal procName As String, _
        ByVal stepText As String, _
        ByVal hintText As String, _
        ByVal targetPath As String, _
        ByVal errNumber As Long, _
        ByVal errDescription As String, _
        ByVal errSource As String) As String
    Dim d As String, src As String, msg As String, srcText As String
    d = errDescription
    src = errSource
    If Len(d) = 0 Then
        d = "�G���[���e����ł��B�ۑ���t�@�C���̃��b�N�A�ۑ���t�H���_�̌����A" & _
            "�K�{�V�[�g�s���A�܂��̓V�[�g�ی��Ԃ������̉\��������܂��B"
    End If

    If Len(src) = 0 Then
        srcText = "(�Ȃ�)"
    Else
        srcText = src
    End If

    msg = "�����Ɏ��s���܂����B" & vbCrLf & vbCrLf & _
          "����: " & procName & vbCrLf
    If Len(stepText) > 0 Then msg = msg & "�i�K: " & stepText & vbCrLf
    If Len(targetPath) > 0 Then msg = msg & "�Ώ�: " & targetPath & vbCrLf
    msg = msg & "Err.Number: " & CStr(errNumber) & vbCrLf & _
                "Err.Source: " & srcText & vbCrLf & _
                "���e: " & d
    If Len(hintText) > 0 Then msg = msg & vbCrLf & vbCrLf & "�m�F: " & hintText
    RuntimeErrorTextFromValues = msg
End Function

Public Sub RuntimeShowError(ByVal procName As String, _
        Optional ByVal stepText As String = "", _
        Optional ByVal hintText As String = "", _
        Optional ByVal targetPath As String = "")
    Dim n As Long, d As String, src As String, msg As String
    n = Err.Number
    d = Err.Description
    src = Err.Source
    msg = RuntimeErrorTextFromValues(procName, stepText, hintText, targetPath, n, d, src)

    On Error Resume Next
    Application.DisplayAlerts = True
    Application.EnableEvents = True
    Application.ScreenUpdating = True
    Application.StatusBar = False
    RuntimeAppendLog "ERROR", procName, stepText, targetPath, n, d, src
    Err.Clear
    On Error GoTo 0

    MsgBox msg, vbExclamation, "�G���[�ڍ�"
End Sub

Public Sub RuntimeShowErrorValues(ByVal procName As String, _
        ByVal stepText As String, _
        ByVal hintText As String, _
        ByVal targetPath As String, _
        ByVal errNumber As Long, _
        ByVal errDescription As String, _
        ByVal errSource As String)
    Dim msg As String
    msg = RuntimeErrorTextFromValues(procName, stepText, hintText, targetPath, _
                                     errNumber, errDescription, errSource)
    On Error Resume Next
    Application.DisplayAlerts = True
    Application.EnableEvents = True
    Application.ScreenUpdating = True
    Application.StatusBar = False
    RuntimeAppendLog "ERROR", procName, stepText, targetPath, errNumber, errDescription, errSource
    Err.Clear
    On Error GoTo 0
    MsgBox msg, vbExclamation, "�G���[�ڍ�"
End Sub

Public Sub RuntimeAppendLog(ByVal levelText As String, _
        ByVal procName As String, _
        ByVal stepText As String, _
        ByVal targetPath As String, _
        ByVal errNumber As Long, _
        ByVal errDescription As String, _
        ByVal errSource As String)
    Dim sh As Worksheet, r As Long, prevVisible As XlSheetVisibility
    On Error Resume Next
    Set sh = RuntimeGetOrCreateLogSheet()
    If sh Is Nothing Then Exit Sub
    prevVisible = sh.Visible
    sh.Visible = xlSheetVisible
    If Len(CStr(sh.Cells(1, 1).Value)) = 0 Then
        sh.Range("A1:H1").Value = Array("����", "�敪", "����", "�i�K", "�Ώ�", _
                                         "Err.Number", "Err.Source", "���e")
        sh.Rows(1).Font.Bold = True
    End If
    r = sh.Cells(sh.Rows.Count, 1).End(xlUp).Row + 1
    If r < 2 Then r = 2
    sh.Cells(r, 1).Value = Now
    sh.Cells(r, 2).Value = levelText
    sh.Cells(r, 3).Value = procName
    sh.Cells(r, 4).Value = stepText
    sh.Cells(r, 5).Value = targetPath
    sh.Cells(r, 6).Value = errNumber
    sh.Cells(r, 7).Value = errSource
    sh.Cells(r, 8).Value = errDescription
    sh.Columns("A:H").AutoFit
    If prevVisible <> xlSheetVisible Then sh.Visible = prevVisible
    If sh.Name = "���s���O" Then sh.Visible = xlSheetVeryHidden
    On Error GoTo 0
End Sub

Private Function RuntimeGetOrCreateLogSheet() As Worksheet
    Dim nm As Variant, sh As Worksheet
    For Each nm In Array("W_�A�g���O", "W_�Z�b�g�A�b�v���O", "C_�`�F�b�N", "���s���O")
        On Error Resume Next
        Set sh = ThisWorkbook.Worksheets(CStr(nm))
        On Error GoTo 0
        If Not sh Is Nothing Then
            Set RuntimeGetOrCreateLogSheet = sh
            Exit Function
        End If
    Next nm
    On Error Resume Next
    Set sh = ThisWorkbook.Worksheets.Add(After:=ThisWorkbook.Worksheets(ThisWorkbook.Worksheets.Count))
    sh.Name = "���s���O"
    sh.Visible = xlSheetVeryHidden
    Set RuntimeGetOrCreateLogSheet = sh
    On Error GoTo 0
End Function

Public Function RuntimeCombinePath(ByVal folderPath As String, ByVal fileName As String) As String
    Dim lastChar As String
    If Len(folderPath) = 0 Then
        RuntimeCombinePath = fileName
        Exit Function
    End If
    lastChar = Right$(folderPath, 1)
    If lastChar = Application.PathSeparator Or lastChar = "/" Or lastChar = ChrW$(92) Then
        RuntimeCombinePath = folderPath & fileName
    Else
        RuntimeCombinePath = folderPath & Application.PathSeparator & fileName
    End If
End Function

Public Function RuntimeParentFolder(ByVal filePath As String) As String
    Dim p As Long
    If Len(filePath) = 0 Then Exit Function
    p = InStrRev(filePath, Application.PathSeparator)
    If p = 0 Then p = InStrRev(filePath, ChrW$(92))
    If p = 0 Then p = InStrRev(filePath, "/")
    If p <= 0 Then Exit Function
    If p <= 3 And Mid$(filePath, 2, 1) = ":" Then
        RuntimeParentFolder = Left$(filePath, 3)
    Else
        RuntimeParentFolder = Left$(filePath, p - 1)
    End If
End Function

Private Function RuntimeFolderExists(ByVal folderPath As String) As Boolean
    If Len(folderPath) = 0 Then Exit Function
    On Error Resume Next
    RuntimeFolderExists = ((GetAttr(folderPath) And vbDirectory) = vbDirectory)
    If Err.Number <> 0 Then
        Err.Clear
        RuntimeFolderExists = False
    End If
    On Error GoTo 0
End Function

Private Function RuntimeIsRootFolder(ByVal folderPath As String) As Boolean
    Dim p As String, rest As String, firstSlash As Long, secondSlash As Long
    p = Replace(folderPath, "/", ChrW$(92))
    If Len(p) <= 3 And Mid$(p, 2, 1) = ":" Then
        RuntimeIsRootFolder = True
        Exit Function
    End If
    If Left$(p, 2) = ChrW$(92) & ChrW$(92) Then
        rest = Mid$(p, 3)
        firstSlash = InStr(1, rest, ChrW$(92), vbTextCompare)
        If firstSlash = 0 Then RuntimeIsRootFolder = True: Exit Function
        secondSlash = InStr(firstSlash + 1, rest, ChrW$(92), vbTextCompare)
        If secondSlash = 0 Then RuntimeIsRootFolder = True
    End If
End Function

Public Function RuntimeUniqueBackupPath(ByVal filePath As String) As String
    Dim basePath As String, i As Long
    If Len(filePath) = 0 Then Exit Function
    basePath = filePath & ".bak_" & Format$(Now, "yyyymmdd_hhnnss")
    RuntimeUniqueBackupPath = basePath
    Do While Len(Dir$(RuntimeUniqueBackupPath)) > 0
        i = i + 1
        RuntimeUniqueBackupPath = basePath & "_" & Format$(i, "00")
    Loop
End Function

Public Function RuntimeUniqueTempPath(ByVal finalPath As String) As String
    Dim basePath As String, i As Long
    basePath = finalPath & ".tmp_" & Format$(Now, "yyyymmdd_hhnnss") & ".xlsx"
    RuntimeUniqueTempPath = basePath
    Do While Len(Dir$(RuntimeUniqueTempPath)) > 0
        i = i + 1
        RuntimeUniqueTempPath = finalPath & ".tmp_" & Format$(Now, "yyyymmdd_hhnnss") & _
                                "_" & Format$(i, "00") & ".xlsx"
    Loop
End Function

Public Sub RuntimeEnsureFolderExists(ByVal folderPath As String, ByVal procName As String)
    Dim parentPath As String
    If Len(folderPath) = 0 Then
        Err.Raise vbObjectError + 8701, procName, _
                  "�ۑ���t�H���_����ł��B���̃u�b�N���Č��t�H���_�֕ۑ����Ă�����s���Ă��������B"
    End If
    If RuntimeFolderExists(folderPath) Then Exit Sub
    If Not RuntimeIsRootFolder(folderPath) Then
        parentPath = RuntimeParentFolder(folderPath)
        If Len(parentPath) > 0 And parentPath <> folderPath Then
            If Not RuntimeFolderExists(parentPath) Then RuntimeEnsureFolderExists parentPath, procName
        End If
    End If
    On Error GoTo EH
    MkDir folderPath
    If Not RuntimeFolderExists(folderPath) Then Err.Raise vbObjectError + 8702
    Exit Sub
EH:
    Err.Raise vbObjectError + 8702, procName, _
              "�ۑ���t�H���_���쐬�ł��܂���: " & folderPath & vbCrLf & Err.Description
End Sub

Public Function RuntimeIsFileLocked(ByVal filePath As String) As Boolean
    Dim ff As Integer
    If Len(filePath) = 0 Then Exit Function
    If Len(Dir$(filePath)) = 0 Then Exit Function
    On Error Resume Next
    ff = FreeFile
    Open filePath For Binary Access Read Write Lock Read Write As #ff
    If Err.Number <> 0 Then RuntimeIsFileLocked = True
    If ff <> 0 Then Close #ff
    Err.Clear
    On Error GoTo 0
End Function

Public Sub RuntimeValidateOutputPath(ByVal filePath As String, ByVal procName As String)
    Dim folderPath As String
    If Len(filePath) = 0 Then Err.Raise vbObjectError + 8713, procName, "�o�̓t�@�C��������ł��B"
    folderPath = RuntimeParentFolder(filePath)
    If Len(folderPath) = 0 Then Err.Raise vbObjectError + 8714, procName, _
        "�o�͐�t�H���_�𔻒�ł��܂���: " & filePath
    RuntimeEnsureFolderExists folderPath, procName
End Sub

Public Sub RuntimeBackupAndRemoveExistingFile(ByVal filePath As String, ByVal procName As String)
    Dim backupPath As String
    If Len(filePath) = 0 Then Exit Sub
    If Len(Dir$(filePath)) = 0 Then Exit Sub
    If RuntimeIsFileLocked(filePath) Then Err.Raise vbObjectError + 8715, procName, _
        "�����t�@�C�����J����Ă��邩�������ł��B���Ă���Ď��s���Ă�������: " & filePath
    backupPath = RuntimeUniqueBackupPath(filePath)
    Name filePath As backupPath
    RuntimeAppendLog "INFO", procName, "�����t�@�C���ޔ�", filePath, 0, "�o�b�N�A�b�v: " & backupPath, ""
End Sub

Public Sub RuntimeSafeSaveAsXlsxAndClose(ByRef wb As Workbook, _
        ByVal filePath As String, _
        ByVal procName As String, _
        Optional ByVal stepText As String = "�o�̓t�@�C���ۑ�")
    Dim folderPath As String, tmpPath As String, backupPath As String, logDetail As String
    Dim prevAlerts As Boolean, savedTmp As Boolean
    Dim originalMoved As Boolean, finalNamed As Boolean
    Dim errNum As Long, errDesc As String, errSrc As String

    prevAlerts = Application.DisplayAlerts
    On Error GoTo EH
    If wb Is Nothing Then Err.Raise vbObjectError + 8710, procName, "�ۑ��Ώۃu�b�N���쐬�ł��Ă��܂���B"
    RuntimeValidateOutputPath filePath, procName
    folderPath = RuntimeParentFolder(filePath)
    If RuntimeIsFileLocked(filePath) Then
        Err.Raise vbObjectError + 8711, procName, _
                  "�����̏o�̓t�@�C�����J����Ă��邩�A�������Ń��b�N����Ă��܂��B���Ă���Ď��s���Ă��������B"
    End If

    tmpPath = RuntimeUniqueTempPath(filePath)
    Application.DisplayAlerts = False
    wb.SaveAs Filename:=tmpPath, FileFormat:=xlOpenXMLWorkbook
    savedTmp = True
    wb.Close SaveChanges:=False
    Set wb = Nothing
    Application.DisplayAlerts = prevAlerts

    If Len(Dir$(tmpPath)) = 0 Then Err.Raise vbObjectError + 8712, procName, _
        "�ꎞ�ۑ��t�@�C�����m�F�ł��܂���: " & tmpPath

    If Len(Dir$(filePath)) > 0 Then
        backupPath = RuntimeUniqueBackupPath(filePath)
        Name filePath As backupPath
        originalMoved = True
    End If
    Name tmpPath As filePath
    finalNamed = True
    If Len(backupPath) > 0 Then
        logDetail = "�o�b�N�A�b�v: " & backupPath
    Else
        logDetail = "�ۑ�����"
    End If
    RuntimeAppendLog "INFO", procName, stepText, filePath, 0, logDetail, ""
    Exit Sub

EH:
    errNum = Err.Number
    errDesc = Err.Description
    errSrc = Err.Source
    On Error Resume Next
    Application.DisplayAlerts = prevAlerts
    If Not wb Is Nothing Then wb.Close SaveChanges:=False
    If originalMoved And Not finalNamed Then
        If Len(filePath) > 0 Then
            If Len(Dir$(filePath)) = 0 Then
                If Len(backupPath) > 0 Then
                    If Len(Dir$(backupPath)) > 0 Then Name backupPath As filePath
                End If
            End If
        End If
    End If
    If savedTmp Then
        If Len(tmpPath) > 0 Then
            If Len(Dir$(tmpPath)) > 0 Then RuntimeAppendLog "WARN", procName, "�ꎞ�t�@�C���c��", tmpPath, errNum, errDesc, errSrc
        End If
    End If
    On Error GoTo 0
    If Len(errDesc) = 0 Then errDesc = "�ۑ����������s���܂����B"
    If Len(filePath) > 0 Then errDesc = errDesc & vbCrLf & "�Ώ�: " & filePath
    Err.Raise errNum, procName & "/" & stepText, errDesc
End Sub

Public Sub RuntimeEnsureSheetsVisible(ByVal sheetNames As Variant)
    Dim i As Long, nm As String
    On Error GoTo EH
    For i = LBound(sheetNames) To UBound(sheetNames)
        nm = CStr(sheetNames(i))
        If Not RuntimeSheetExists(nm) Then Err.Raise vbObjectError + 8720, _
            "RuntimeEnsureSheetsVisible", "�K�{�V�[�g������܂���: " & nm
        ThisWorkbook.Worksheets(nm).Visible = xlSheetVisible
    Next i
    Exit Sub
EH:
    Err.Raise Err.Number, "RuntimeEnsureSheetsVisible", Err.Description
End Sub


Public Function RuntimeSnapshotOpenWorkbooks() As Object
    Dim d As Object
    Dim wb As Workbook
    Dim k As String
    Set d = CreateObject("Scripting.Dictionary")
    For Each wb In Application.Workbooks
        k = RuntimeWorkbookIdentity(wb)
        If Len(k) > 0 Then d(k) = True
    Next wb
    Set RuntimeSnapshotOpenWorkbooks = d
End Function

Public Function RuntimeFindWorkbookNotInSnapshot(ByVal beforeBooks As Object) As Workbook
    Dim wb As Workbook
    Dim k As String
    For Each wb In Application.Workbooks
        k = RuntimeWorkbookIdentity(wb)
        If beforeBooks Is Nothing Then
            Set RuntimeFindWorkbookNotInSnapshot = wb
            Exit Function
        End If
        If Not beforeBooks.Exists(k) Then
            Set RuntimeFindWorkbookNotInSnapshot = wb
            Exit Function
        End If
    Next wb
End Function

Private Function RuntimeWorkbookIdentity(ByVal wb As Workbook) As String
    On Error Resume Next
    RuntimeWorkbookIdentity = wb.Name & ChrW$(30) & wb.FullName
    On Error GoTo 0
End Function

Public Function RuntimeSheetExists(ByVal sheetName As String) As Boolean
    Dim sh As Worksheet
    On Error Resume Next
    Set sh = ThisWorkbook.Worksheets(sheetName)
    RuntimeSheetExists = Not sh Is Nothing
    On Error GoTo 0
End Function

Public Function RuntimeCountVisibleWorkbookSheets(ByVal wb As Workbook) As Long
    Dim sh As Worksheet
    If wb Is Nothing Then Exit Function
    For Each sh In wb.Worksheets
        If sh.Visible = xlSheetVisible Then RuntimeCountVisibleWorkbookSheets = RuntimeCountVisibleWorkbookSheets + 1
    Next sh
End Function

Attribute VB_Name = "modAnalysisOutput"
Option Explicit

' �l�Ԃ��둀�삵�Ȃ����͌��ʉ�ʁB�_�u���N���b�N�ؑցE�����ҏW�E�ĕ��͂����S������B
' �\����� A:M �ɏW�񂵁A�A�g�E�ĕ��͂ɕK�v�Ȑ��f�[�^�� AA:AV �ɔ�\���ێ�����B
Private Const VIEW_HEADER_ROW As Long = 7
Private Const VIEW_FIRST_DATA_ROW As Long = 8
Private Const VIEW_COL_ID As Long = 1
Private Const VIEW_COL_KIND As Long = 2
Private Const VIEW_COL_VOUCHER As Long = 3
Private Const VIEW_COL_DECISION As Long = 4
Private Const VIEW_COL_PATTERN As Long = 5
Private Const VIEW_COL_AMOUNT As Long = 6
Private Const VIEW_COL_DIFF As Long = 7
Private Const VIEW_COL_DATES As Long = 8
Private Const VIEW_COL_OUT_PERSON As Long = 9
Private Const VIEW_COL_IN_PERSON As Long = 10
Private Const VIEW_COL_RELATION As Long = 11
Private Const VIEW_COL_SUMMARY As Long = 12
Private Const VIEW_COL_MEMO As Long = 13
Private Const VIEW_LAST_COL As Long = 13
Private Const RAW_START_COL As Long = 27 ' AA
Private Const FLAG_HEADER_ROW As Long = 7
Private Const FLAG_FIRST_DATA_ROW As Long = 8
Private Const FLAG_LEFT_COLS As Long = 21
Private Const FLAG_ORIG_START_COL As Long = 23


Public Sub BuildAnalysisResultSheet()
    Dim src As Worksheet, dst As Worksheet
    Dim lastR As Long, viewLastR As Long, r As Long, outR As Long
    Set src = GetSheet(SH_WORK_RESULT)
    Set dst = GetSheet(SH_RESULT)

    On Error Resume Next
    dst.Unprotect Password:=TOOL_PASSWORD
    dst.ScrollArea = ""
    dst.Cells.EntireColumn.Hidden = False
    dst.Cells.UnMerge
    dst.Cells.Clear
    DeleteAllShapes dst
    On Error GoTo 0

    lastR = LastRow(src, 1)
    If lastR < 1 Then lastR = 1
    viewLastR = VIEW_HEADER_ROW + lastR - 1

    BuildResultTopArea dst
    BuildCompactHeaders dst

    ' ���f�[�^�͔�\����ɕێ��B�A�g�ۑ��E�蓮���O�E�ĕ��͂Ŏg���B
    dst.Range(dst.Cells(VIEW_HEADER_ROW, RAW_START_COL), dst.Cells(viewLastR, RAW_START_COL + RES_LAST_COL - 1)).Value = _
        src.Range(src.Cells(1, 1), src.Cells(lastR, RES_LAST_COL)).Value

    If lastR >= 2 Then
        For r = 2 To lastR
            outR = VIEW_HEADER_ROW + r - 1
            WriteCompactResultRow dst, src, r, outR
        Next r
        FormatBody dst.Range(dst.Cells(VIEW_FIRST_DATA_ROW, 1), dst.Cells(viewLastR, VIEW_LAST_COL))
        dst.Range(dst.Cells(VIEW_FIRST_DATA_ROW, VIEW_COL_DIFF), dst.Cells(viewLastR, VIEW_COL_DIFF)).NumberFormatLocal = "#,##0"
        ColorResultRows dst, viewLastR
        PrepareManualEditing dst, viewLastR
        BuildResultSummaryCards dst, viewLastR
    Else
        BuildResultSummaryCards dst, VIEW_HEADER_ROW
    End If

    dst.Range(dst.Cells(VIEW_HEADER_ROW, 1), dst.Cells(viewLastR, VIEW_LAST_COL)).AutoFilter
    ApplyCompactResultLayout dst, viewLastR
    ThemeApplyPrintTable dst.Range(dst.Cells(VIEW_HEADER_ROW, 1), dst.Cells(viewLastR, VIEW_LAST_COL)), 1
    ThemeCapRowHeights dst.Range(dst.Cells(VIEW_FIRST_DATA_ROW, 1), dst.Cells(viewLastR, VIEW_LAST_COL)), 24, 84
    ThemeApplyMonochromePrint dst, dst.Range(dst.Cells(1, 1), dst.Cells(viewLastR, VIEW_LAST_COL)).Address, True, "$7:$7", 1, 0
    AddResultSheetControls dst
    ThemeMarkMacroButtonsNonPrintable dst

    If dst.Visible = xlSheetVisible Then
        dst.Activate
        ActiveWindow.FreezePanes = False
        dst.Range("A" & CStr(VIEW_FIRST_DATA_ROW)).Select
        ActiveWindow.FreezePanes = True
        ActiveWindow.Zoom = 90
    End If

    ProtectOutputSheet dst
End Sub

Private Sub BuildResultTopArea(ByVal ws As Worksheet)
    ws.Range("A1:M1").Merge
    ws.Range("A1").Value = "03_�����ړ����̓c�[���b���͌���"
    With ws.Range("A1")
        .Interior.Color = ThemeColor("title")
        .Font.Color = vbWhite
        .Font.Bold = True
        .Font.Size = 17
        .HorizontalAlignment = xlCenter
        .VerticalAlignment = xlCenter
    End With
    ws.Rows(1).RowHeight = 34

    ws.Range("A2:G4").Merge
    ws.Range("A2").Value = "�ォ�珇�Ɋm�F���AC��̓`�[�v�ۂ�D��̗̍p���f�������ŏ�����Ő����܂��B" & vbCrLf & _
                           "�`�[=�v��04�֘A�g����܂��B��⏜�O�͑g�������������O�A������O�͍ĕ��͂���O����������ł��BM�񃁃��͍ĕ��͌���ێ����܂��B"
    With ws.Range("A2")
        .Interior.Color = ThemeColor("section")
        .Font.Color = ThemeColor("header")
        .Font.Bold = True
        .WrapText = True
        .VerticalAlignment = xlCenter
    End With

    ws.Range("H2:I4").Merge
    ws.Range("J2:K4").Merge
    ws.Range("L2:M4").Merge
    FormatMiniCard ws.Range("H2"), "�`�[�˗� �v", ThemeColor("red")
    FormatMiniCard ws.Range("J2"), "���O�w��", ThemeColor("muted")
    FormatMiniCard ws.Range("L2"), "��␔", ThemeColor("header")
    ws.Rows("2:4").RowHeight = 22
    ThemeApplyPanelBorders ws.Range("A2:M4")
End Sub

Private Sub FormatMiniCard(ByVal cell As Range, ByVal titleText As String, ByVal fillColor As Long)
    cell.Value = titleText & vbCrLf & "-"
    With cell
        .Interior.Color = fillColor
        .Font.Color = vbWhite
        .Font.Bold = True
        .Font.Size = 11
        .HorizontalAlignment = xlCenter
        .VerticalAlignment = xlCenter
        .WrapText = True
    End With
End Sub

Private Sub BuildResultSummaryCards(ByVal ws As Worksheet, ByVal viewLastR As Long)
    Dim nTotal As Long, nVoucher As Long, nExclude As Long
    If viewLastR >= VIEW_FIRST_DATA_ROW Then
        nTotal = Application.WorksheetFunction.CountA(ws.Range(ws.Cells(VIEW_FIRST_DATA_ROW, VIEW_COL_ID), ws.Cells(viewLastR, VIEW_COL_ID)))
        nVoucher = Application.WorksheetFunction.CountIf(ws.Range(ws.Cells(VIEW_FIRST_DATA_ROW, VIEW_COL_VOUCHER), ws.Cells(viewLastR, VIEW_COL_VOUCHER)), VOUCHER_YES)
        Dim rr As Long
        For rr = VIEW_FIRST_DATA_ROW To viewLastR
            If IsExcludeDecision(CellText(ws.Cells(rr, VIEW_COL_DECISION).Value)) Then nExclude = nExclude + 1
        Next rr
    End If
    ws.Range("H2").Value = "�`�[�˗� �v" & vbCrLf & CStr(nVoucher)
    ws.Range("J2").Value = "���O�w��" & vbCrLf & CStr(nExclude)
    ws.Range("L2").Value = "��␔" & vbCrLf & CStr(nTotal)
End Sub

Private Sub BuildCompactHeaders(ByVal ws As Worksheet)
    Dim diagText As String
    diagText = AnalysisRunDiagnosticText()
    ws.Range("A6:M6").Merge
    With ws.Range("A6")
        If Len(diagText) > 0 Then
            .Value = "����: " & diagText & vbCrLf & "��=�`�[�˗��A��=�̗p���f�A��=�������́B�o�́E04�A�g�ł͕\�����C��ED��EM��̎蓮�ύX��D�悵�܂��B"
            .Interior.Color = ThemeColor("warning-soft")
            .Font.Color = ThemeColor("warning-text")
        Else
            .Value = "��=�`�[�˗��A��=�̗p���f�A��=�������́B�o�́E04�A�g�ł͔�\���̐��f�[�^��ł͂Ȃ��A�\�����C��ED��EM��̎蓮�ύX��D�悵�܂��B"
            .Interior.Color = ThemeColor("canvas")
            .Font.Color = ThemeColor("muted")
        End If
        .Font.Bold = True
        .WrapText = True
        .VerticalAlignment = xlCenter
    End With
    If Len(diagText) > 0 Then
        ws.Rows(6).RowHeight = 42
    Else
        ws.Rows(6).RowHeight = 28
    End If
    SetRowValues ws.Cells(VIEW_HEADER_ROW, 1), Array("���ID", "�敪", "�`�[", "���f", "�g����/�M���x", "���z", "���z", "���t", "�o����", "������", "�֌W/�N��", "�v�_/�Z��", "����")
    FormatHeader ws.Range(ws.Cells(VIEW_HEADER_ROW, 1), ws.Cells(VIEW_HEADER_ROW, VIEW_LAST_COL)), ThemeColor("header")
    ws.Rows(VIEW_HEADER_ROW).RowHeight = 27
End Sub

Private Sub WriteCompactResultRow(ByVal dst As Worksheet, ByVal src As Worksheet, ByVal srcRow As Long, ByVal outR As Long)
    Dim outAmt As Variant, inAmt As Variant, diffVal As Variant, relationText As String
    outAmt = src.Cells(srcRow, RES_COL_OUT_AMOUNT).Value
    inAmt = src.Cells(srcRow, RES_COL_IN_AMOUNT).Value
    diffVal = src.Cells(srcRow, RES_COL_DIFF).Value
    relationText = JoinNonBlank(CellText(src.Cells(srcRow, RES_COL_NAME_REL).Value), CellText(src.Cells(srcRow, RES_COL_INH_TIMING).Value), vbLf)
    If Len(CellText(src.Cells(srcRow, RES_COL_COHAB).Value)) > 0 Then relationText = JoinNonBlank(relationText, CellText(src.Cells(srcRow, RES_COL_COHAB).Value), vbLf)
    If Len(CellText(src.Cells(srcRow, RES_COL_AGE_HINT).Value)) > 0 Then relationText = JoinNonBlank(relationText, CellText(src.Cells(srcRow, RES_COL_AGE_HINT).Value), vbLf)

    dst.Cells(outR, VIEW_COL_ID).Value = src.Cells(srcRow, RES_COL_ID).Value
    dst.Cells(outR, VIEW_COL_KIND).Value = src.Cells(srcRow, RES_COL_KIND).Value
    dst.Cells(outR, VIEW_COL_VOUCHER).Value = src.Cells(srcRow, RES_COL_VOUCHER).Value
    dst.Cells(outR, VIEW_COL_DECISION).Value = src.Cells(srcRow, RES_COL_SHIFT_DECISION).Value
    dst.Cells(outR, VIEW_COL_PATTERN).Value = CellText(src.Cells(srcRow, RES_COL_PATTERN).Value) & vbLf & "�M���x " & CellText(src.Cells(srcRow, RES_COL_SCORE).Value) & "�_"
    dst.Cells(outR, VIEW_COL_AMOUNT).Value = "�o " & FormatNumberText(outAmt) & vbCrLf & "�� " & FormatNumberText(inAmt)
    dst.Cells(outR, VIEW_COL_DIFF).Value = diffVal
    dst.Cells(outR, VIEW_COL_DATES).Value = "�o " & CellText(src.Cells(srcRow, RES_COL_OUT_DATE).Value) & vbCrLf & "�� " & CellText(src.Cells(srcRow, RES_COL_IN_DATE).Value)
    dst.Cells(outR, VIEW_COL_OUT_PERSON).Value = CellText(src.Cells(srcRow, RES_COL_OUT_PERSON).Value)
    dst.Cells(outR, VIEW_COL_IN_PERSON).Value = CellText(src.Cells(srcRow, RES_COL_IN_PERSON).Value)
    dst.Cells(outR, VIEW_COL_RELATION).Value = relationText
    dst.Cells(outR, VIEW_COL_SUMMARY).Value = JoinNonBlank( _
        CellText(src.Cells(srcRow, RES_COL_SHOPS).Value), _
        CellText(src.Cells(srcRow, RES_COL_SUMMARY).Value), vbLf)
    If Len(CellText(src.Cells(srcRow, RES_COL_ADDRESS_HINT).Value)) > 0 Then
        dst.Cells(outR, VIEW_COL_SUMMARY).Value = JoinNonBlank( _
            CellText(dst.Cells(outR, VIEW_COL_SUMMARY).Value), _
            CellText(src.Cells(srcRow, RES_COL_ADDRESS_HINT).Value), vbLf)
    End If
    dst.Cells(outR, VIEW_COL_MEMO).Value = src.Cells(srcRow, RES_COL_OPERATION_MEMO).Value
End Sub

Private Function FormatNumberText(ByVal v As Variant) As String
    If IsNumeric(v) Then
        FormatNumberText = Format$(CDbl(v), "#,##0")
    Else
        FormatNumberText = CellText(v)
    End If
End Function

Private Sub ApplyCompactResultLayout(ByVal ws As Worksheet, ByVal viewLastR As Long)
    ws.Columns("A:A").ColumnWidth = 10
    ws.Columns("B:B").ColumnWidth = 13
    ws.Columns("C:D").ColumnWidth = 8
    ws.Columns("E:E").ColumnWidth = 11
    ws.Columns("F:F").ColumnWidth = 15
    ws.Columns("G:G").ColumnWidth = 10
    ws.Columns("H:H").ColumnWidth = 16
    ws.Columns("I:J").ColumnWidth = 15
    ws.Columns("K:K").ColumnWidth = 16
    ws.Columns("L:L").ColumnWidth = 31
    ws.Columns("M:M").ColumnWidth = 25
    ws.Range(ws.Cells(1, 1), ws.Cells(Application.Max(viewLastR, VIEW_FIRST_DATA_ROW), VIEW_LAST_COL)).WrapText = True
    ws.Range(ws.Cells(1, 1), ws.Cells(Application.Max(viewLastR, VIEW_FIRST_DATA_ROW), VIEW_LAST_COL)).VerticalAlignment = xlCenter
    If viewLastR >= VIEW_FIRST_DATA_ROW Then ws.Rows(CStr(VIEW_FIRST_DATA_ROW) & ":" & CStr(viewLastR)).RowHeight = 46
    ws.Columns("N:XFD").Hidden = True
    ws.ScrollArea = "A1:M" & CStr(Application.Max(200, viewLastR + 20))
End Sub

Private Sub AddResultSheetControls(ByVal ws As Worksheet)
    AddResultButton ws, "�ĕ���", "ReAnalyzeFromResultSheet", ws.Range("A5"), ThemeColor("orange")
    AddResultButton ws, "�ύX���f", "ApplyManualEditsFromResultSheet", ws.Range("C5"), ThemeColor("red")
    AddResultButton ws, "���ʕۑ�", "SaveAnalysisToCommonData", ws.Range("E5"), ThemeColor("teal")
    AddResultButton ws, "���O����", "ClearManualExclusions", ws.Range("G5"), ThemeColor("muted")
    AddResultButton ws, "������", "ShowMainSheet", ws.Range("I5"), ThemeColor("header")
    AddResultButton ws, "�ŏI�o��", "ExportAnalysisWorkbook", ws.Range("K5"), ThemeColor("purple")
    AddResultButton ws, "�ǐ�", "TraceSelectedUnknownOutToLaterUnknownIns", ws.Range("M5"), ThemeColor("purple")
End Sub

Private Sub AddResultButton(ByVal ws As Worksheet, ByVal caption As String, ByVal macroName As String, ByVal anchor As Range, ByVal fillColor As Long)
    Dim shp As Shape
    Dim target As Range
    Const M As Double = 2
    If anchor.Column >= VIEW_LAST_COL Then
        Set target = anchor
    Else
        Set target = ws.Range(anchor, anchor.Offset(0, 1))
    End If
    Set shp = ws.Shapes.AddShape(msoShapeRoundedRectangle, target.Left + M, target.Top + M, _
        Application.Max(6, target.Width - M * 2), Application.Max(6, target.Height - M * 2))
    shp.Name = "btn_result_" & macroName
    ThemeStyleButtonShapeWithColor shp, caption, fillColor, fillColor, ThemeReadableFontColor(fillColor), macroName
End Sub

Private Sub PrepareManualEditing(ByVal ws As Worksheet, ByVal viewLastR As Long)
    On Error Resume Next
    ws.Cells.Locked = True
    With ws.Range(ws.Cells(VIEW_FIRST_DATA_ROW, VIEW_COL_VOUCHER), ws.Cells(viewLastR, VIEW_COL_VOUCHER))
        .Locked = False
        .Interior.Color = ThemeColor("warning-soft")
        .Validation.Delete
        .Validation.Add Type:=xlValidateList, AlertStyle:=xlValidAlertStop, Operator:=xlBetween, Formula1:=VOUCHER_YES & "," & VOUCHER_NO
        .Validation.IgnoreBlank = True
        .Validation.InCellDropdown = True
    End With
    With ws.Range(ws.Cells(VIEW_FIRST_DATA_ROW, VIEW_COL_DECISION), ws.Cells(viewLastR, VIEW_COL_DECISION))
        .Locked = False
        .Interior.Color = ThemeColor("success-bg")
        .Validation.Delete
        .Validation.Add Type:=xlValidateList, AlertStyle:=xlValidAlertStop, Operator:=xlBetween, Formula1:=DECISION_USE & "," & DECISION_EXCLUDE & "," & DECISION_TX_EXCLUDE
        .Validation.IgnoreBlank = True
        .Validation.InCellDropdown = True
    End With
    ws.Cells(VIEW_HEADER_ROW, VIEW_COL_VOUCHER).Interior.Color = ThemeColor("red")
    ws.Cells(VIEW_HEADER_ROW, VIEW_COL_VOUCHER).Font.Color = vbWhite
    With ws.Range(ws.Cells(VIEW_FIRST_DATA_ROW, VIEW_COL_MEMO), ws.Cells(viewLastR, VIEW_COL_MEMO))
        .Locked = False
        .Interior.Color = vbWhite
        .Validation.Delete
    End With
    ws.Cells(VIEW_HEADER_ROW, VIEW_COL_DECISION).Interior.Color = ThemeColor("green")
    ws.Cells(VIEW_HEADER_ROW, VIEW_COL_DECISION).Font.Color = vbWhite
    ws.Cells(VIEW_HEADER_ROW, VIEW_COL_MEMO).Interior.Color = ThemeColor("muted-strong")
    ws.Cells(VIEW_HEADER_ROW, VIEW_COL_MEMO).Font.Color = vbWhite
    On Error GoTo 0
End Sub

Public Sub HandleAnalysisResultSelectionChange(ByVal Target As Range)
    Dim ws As Worksheet, msg As String, r As Long
    If Target Is Nothing Then Exit Sub
    If Target.Worksheet.Name <> SH_RESULT Then Exit Sub
    If Target.Cells.CountLarge > 1 Then Exit Sub
    Set ws = Target.Worksheet
    r = Target.Row
    If r < VIEW_FIRST_DATA_ROW Then
        Application.StatusBar = "���͌��ʂł��BC��=�`�[�AD��=�̗p���f�AM��=������ҏW�ł��܂��B���f�͑����ۑ�����܂��B"
        Exit Sub
    End If
    If Len(CellText(ws.Cells(r, VIEW_COL_ID).Value)) = 0 Then Exit Sub
    Select Case Target.Column
        Case VIEW_COL_VOUCHER
            msg = "�`�[�v�ۂł��B�v/�s�v��I�ԂƁA�`�[�˗����֑������f���܂��B"
        Case VIEW_COL_DECISION
            msg = "�̗p���f�ł��B�ʏ�͌�⏜�O���g���A������O�͍ĕ��͂���O���������T�d�Ɏg���܂��B"
        Case VIEW_COL_MEMO
            msg = "�������ł��B���f���R�E�m�F�ώ����������ƁA�ĕ��͌���ێ�����܂��B"
        Case VIEW_COL_KIND
            msg = "���ނł��B�s���o���s��I��ŕs���o���ǐՂ����s�ł��܂��B"
        Case VIEW_COL_SUMMARY
            msg = "�����v��ł��B�戵�X�A�������A�Z���E�N��E�c���}�ςȂǂ̔��f�ޗ����m�F���܂��B"
        Case VIEW_COL_DATES
            msg = "�o�����E�������ł��B�����őo���Ɏ���������ꍇ�͏o���������̏��������܂��B"
        Case Else
            msg = "���͌��s�ł��B�`�[�˗��E���f�E���̓����́A��������\_���͍ς܂��̓t���O���o�̕\�����̗�ŕҏW���܂��B"
    End Select
    Application.StatusBar = msg
End Sub

Public Sub HandleAnalysisResultChange(ByVal Target As Range)
    '�h���b�v�_�E���⃁���̎���͂��A���̏�œ�����Ԃ֔��f����B
    '�u�ύX���f�v�{�^���������Y��Ă��A�ĕ��́E���ʕۑ��Ŕ��f���߂�Ȃ��悤�ɂ���B
    Static handling As Boolean
    Dim ws As Worksheet, watch As Range, hit As Range, cell As Range
    Dim lastR As Long, r As Long, voucherText As String, decisionText As String
    Dim prevEvents As Boolean
    If handling Then Exit Sub
    If Target Is Nothing Then Exit Sub
    If Target.Worksheet.Name <> SH_RESULT Then Exit Sub
    Set ws = Target.Worksheet
    lastR = LastRow(ws, VIEW_COL_ID)
    If lastR < VIEW_FIRST_DATA_ROW Then Exit Sub
    Set watch = Union(ws.Range(ws.Cells(VIEW_FIRST_DATA_ROW, VIEW_COL_VOUCHER), ws.Cells(lastR, VIEW_COL_VOUCHER)), _
                      ws.Range(ws.Cells(VIEW_FIRST_DATA_ROW, VIEW_COL_DECISION), ws.Cells(lastR, VIEW_COL_DECISION)), _
                      ws.Range(ws.Cells(VIEW_FIRST_DATA_ROW, VIEW_COL_MEMO), ws.Cells(lastR, VIEW_COL_MEMO)))
    Set hit = Intersect(Target, watch)
    If hit Is Nothing Then Exit Sub

    handling = True
    prevEvents = Application.EnableEvents
    On Error GoTo SafeExit
    Application.EnableEvents = False
    ws.Unprotect Password:=TOOL_PASSWORD

    For Each cell In hit.Cells
        r = cell.Row
        If Len(CellText(ws.Cells(r, VIEW_COL_ID).Value)) > 0 Then
            If cell.Column = VIEW_COL_VOUCHER Then
                voucherText = CellText(cell.Value)
                If voucherText <> VOUCHER_YES Then voucherText = VOUCHER_NO
                cell.Value = voucherText
                ws.Cells(r, RAW_START_COL + RES_COL_VOUCHER - 1).Value = voucherText
            ElseIf cell.Column = VIEW_COL_DECISION Then
                decisionText = NormalizeDecisionText(CellText(cell.Value))
                If Len(decisionText) = 0 Then decisionText = DECISION_USE
                cell.Value = decisionText
                If IsExcludeDecision(decisionText) Then
                    ws.Cells(r, VIEW_COL_VOUCHER).Value = VOUCHER_NO
                    ws.Cells(r, RAW_START_COL + RES_COL_VOUCHER - 1).Value = VOUCHER_NO
                End If
                ws.Cells(r, RAW_START_COL + RES_COL_SHIFT_DECISION - 1).Value = decisionText
                ws.Cells(r, RAW_START_COL + RES_COL_OPERATION_MEMO - 1).Value = ws.Cells(r, VIEW_COL_MEMO).Value
            ElseIf cell.Column = VIEW_COL_MEMO Then
                ws.Cells(r, RAW_START_COL + RES_COL_OPERATION_MEMO - 1).Value = cell.Value
            End If
        End If
    Next cell

    ColorResultRows ws, lastR
    PersistManualStateFromResultSheet True
    SyncVoucherFlagsFromResultSheet True
    BuildResultSummaryCards ws, lastR
SafeExit:
    ProtectOutputSheet ws
    Application.EnableEvents = prevEvents
    handling = False
End Sub

Public Sub ApplyVoucherFlagsFromResultSheet()
    ApplyManualEditsFromResultSheet
End Sub

Public Sub ApplyManualEditsFromResultSheet()
    On Error GoTo EH
    AppBegin "�蓮�ύX�𔽉f��..."
    If SheetExists(SH_RESULT) Then
        PersistManualStateFromResultSheet True
        SyncVoucherFlagsFromResultSheet True
        ApplyManualExclusionsFromResultSheet True
    End If
    ApplyVisibleTransactionDecisions True, False
    BuildDetailOutputSheet
    BuildFlaggedTransactionSheet
    BuildFlagExtractSheet
    AppEnd
    NotifyInfo "�\�����̎�������\_���͍ρE�t���O���o�̎蓮�ύX�𔽉f���܂����B"
    Exit Sub
EH:
    AppEnd
    RuntimeShowError "ApplyManualEditsFromResultSheet", "�蓮�ύX���f", "�`�[�˗���E���f��E���̓�������m�F���Ă��������B"
End Sub

Public Sub ReAnalyzeFromResultSheet()
    ReAnalyzeFromVisibleFlagSheets
End Sub

Public Sub ReAnalyzeFromVisibleFlagSheets()
    If SheetExists(SH_RESULT) Then
        PersistManualStateFromResultSheet True
        ApplyManualExclusionsFromResultSheet True
    End If
    ApplyVisibleTransactionDecisions True, False
    RunAnalysis
End Sub

Public Sub ShowMainSheet()
    HideDailySheets False
End Sub

Public Sub ClearManualExclusions()
    If MsgBox("�蓮���O�������ID�ƁA���̏��O���f���������܂��B" & vbCrLf & _
              "�`�[�˗��̎蓮�ύX�⃁���͂ł��邾���ێ����܂��B��낵���ł����B", vbQuestion + vbYesNo) <> vbYes Then Exit Sub
    InitManualExcludeHeaders GetSheet(SH_MANUAL_EXCLUDE)
    ClearExcludeDecisionsInManualState
    AppendLog "�蓮���O����", "����", "W_�蓮���O�����������AW_�蓮�����̏��O���f���̗p�֖߂��܂���"
    If SheetExists(SH_WORK_TX) Then
        BuildFlaggedTransactionSheet
        BuildFlagExtractSheet
        ShowOutputSheets
    End If
    NotifyInfo "�蓮���O���������܂����B�ĕ��͂���Ə��O�����ēx�܂߂Ċm�F�ł��܂��B"
End Sub

Private Sub ClearExcludeDecisionsInManualState()
    Dim ws As Worksheet, lastR As Long, r As Long
    If Not SheetExists(SH_MANUAL_STATE) Then Exit Sub
    Set ws = GetSheet(SH_MANUAL_STATE)
    lastR = LastRow(ws, 1)
    For r = 2 To lastR
        If IsExcludeDecision(CellText(ws.Cells(r, 4).Value)) Then
            ws.Cells(r, 4).Value = DECISION_USE
            If Len(CellText(ws.Cells(r, 5).Value)) = 0 Or InStr(CellText(ws.Cells(r, 5).Value), "���O") > 0 Then
                ws.Cells(r, 5).Value = "���O�����ς�"
            End If
            ws.Cells(r, 6).Value = Now
        End If
    Next r
End Sub


Public Sub PersistManualStateFromResultSheet(Optional ByVal silent As Boolean = True)
    Dim ws As Worksheet, st As Worksheet, lastR As Long, r As Long, outR As Long
    Dim keyText As String, outIds As String, inIds As String, patternText As String
    Dim stateRowByKey As Object, stateLastR As Long, existingKey As String, updatedCount As Long
    If Not SheetExists(SH_RESULT) Then Exit Sub
    Set ws = GetSheet(SH_RESULT)
    Set st = GetSheet(SH_MANUAL_STATE)
    InitManualStateHeaders st, False
    Set stateRowByKey = CreateObject("Scripting.Dictionary")
    stateLastR = LastRow(st, 1)
    For r = 2 To stateLastR
        existingKey = CellText(st.Cells(r, 1).Value)
        If Len(existingKey) > 0 Then stateRowByKey(existingKey) = r
    Next r
    lastR = LastRow(ws, VIEW_COL_ID)
    For r = VIEW_FIRST_DATA_ROW To lastR
        If Len(CellText(ws.Cells(r, VIEW_COL_ID).Value)) > 0 Then
            patternText = CellText(ws.Cells(r, RAW_START_COL + RES_COL_PATTERN - 1).Value)
            outIds = CellText(ws.Cells(r, RAW_START_COL + RES_COL_OUT_IDS - 1).Value)
            inIds = CellText(ws.Cells(r, RAW_START_COL + RES_COL_IN_IDS - 1).Value)
            keyText = BuildAnalysisStateKey(patternText, outIds, inIds)
            If stateRowByKey.Exists(keyText) Then
                outR = CLng(stateRowByKey(keyText))
            Else
                outR = LastRow(st, 1) + 1
                If outR < 2 Then outR = 2
                stateRowByKey.Add keyText, outR
            End If
            st.Cells(outR, 1).Value = keyText
            st.Cells(outR, 2).Value = ws.Cells(r, VIEW_COL_ID).Value
            st.Cells(outR, 3).Value = ws.Cells(r, VIEW_COL_VOUCHER).Value
            st.Cells(outR, 4).Value = ws.Cells(r, VIEW_COL_DECISION).Value
            st.Cells(outR, 5).Value = ws.Cells(r, VIEW_COL_MEMO).Value
            st.Cells(outR, 6).Value = Now
            updatedCount = updatedCount + 1
        End If
    Next r
    If Not silent Then AppendLog "�蓮�����ۑ�", "����", "W_�蓮�����֍����ۑ� " & CStr(updatedCount) & "��"
End Sub

Public Sub SyncVoucherFlagsFromResultSheet(Optional ByVal silent As Boolean = True)
    Dim wsResult As Worksheet, wsWork As Worksheet, wsDetail As Worksheet
    Dim lastR As Long, r As Long, idText As String, voucherText As String, decisionText As String, found As Range
    If Not SheetExists(SH_RESULT) Then Exit Sub
    Set wsResult = GetSheet(SH_RESULT)
    Set wsWork = GetSheet(SH_WORK_RESULT)
    Set wsDetail = GetSheet(SH_WORK_DETAIL)
    lastR = LastRow(wsResult, VIEW_COL_ID)
    For r = VIEW_FIRST_DATA_ROW To lastR
        idText = CellText(wsResult.Cells(r, VIEW_COL_ID).Value)
        voucherText = CellText(wsResult.Cells(r, VIEW_COL_VOUCHER).Value)
        decisionText = CellText(wsResult.Cells(r, VIEW_COL_DECISION).Value)
        If IsExcludeDecision(decisionText) Then voucherText = VOUCHER_NO
        If voucherText <> VOUCHER_YES Then voucherText = VOUCHER_NO
        If Len(idText) > 0 Then
            Set found = wsWork.Columns(RES_COL_ID).Find(What:=idText, LookIn:=xlValues, LookAt:=xlWhole)
            If Not found Is Nothing Then
                wsWork.Cells(found.Row, RES_COL_VOUCHER).Value = voucherText
                wsWork.Cells(found.Row, RES_COL_SHIFT_DECISION).Value = decisionText
                wsWork.Cells(found.Row, RES_COL_OPERATION_MEMO).Value = CellText(wsResult.Cells(r, VIEW_COL_MEMO).Value)
            End If
            ApplyVoucherToDetail wsDetail, idText, voucherText
        End If
    Next r
    If Not silent Then AppendLog "�`�[�˗��t���O���f", "����", "���͌��ʃV�[�g���甽�f"
End Sub

Private Sub ApplyVoucherToDetail(ByVal wsDetail As Worksheet, ByVal analysisId As String, ByVal voucherText As String)
    Dim lastR As Long, r As Long
    lastR = LastRow(wsDetail, DET_COL_ID)
    For r = 2 To lastR
        If CellText(wsDetail.Cells(r, DET_COL_ANALYSIS_ID).Value) = analysisId Then wsDetail.Cells(r, DET_COL_VOUCHER).Value = voucherText
    Next r
End Sub

Private Sub ColorResultRows(ByVal ws As Worksheet, ByVal viewLastR As Long)
    Dim r As Long, kindText As String, colorValue As Long
    For r = VIEW_FIRST_DATA_ROW To viewLastR
        kindText = CellText(ws.Cells(r, VIEW_COL_KIND).Value)
        Select Case kindText
            Case KIND_SHIFT
                colorValue = ThemeColor("info-soft")
            Case KIND_INHERITANCE_SHIFT
                colorValue = ThemeColor("purple-soft")
            Case KIND_UNKNOWN_IN
                colorValue = ThemeColor("warning-soft")
            Case KIND_UNKNOWN_OUT
                colorValue = ThemeColor("orange-soft")
            Case Else
                colorValue = ThemeColor("locked")
        End Select
        ws.Range(ws.Cells(r, 1), ws.Cells(r, VIEW_LAST_COL)).Interior.Color = colorValue
        If IsTxExcludeDecision(CellText(ws.Cells(r, VIEW_COL_DECISION).Value)) Then
            ws.Range(ws.Cells(r, 1), ws.Cells(r, VIEW_LAST_COL)).Interior.Color = ThemeColor("locked")
            ws.Cells(r, VIEW_COL_DECISION).Interior.Color = ThemeColor("warning-text")
            ws.Cells(r, VIEW_COL_DECISION).Font.Color = vbWhite
            ws.Cells(r, VIEW_COL_DECISION).Font.Bold = True
        ElseIf IsExcludeDecision(CellText(ws.Cells(r, VIEW_COL_DECISION).Value)) Then
            ws.Range(ws.Cells(r, 1), ws.Cells(r, VIEW_LAST_COL)).Interior.Color = ThemeColor("locked")
            ws.Cells(r, VIEW_COL_DECISION).Interior.Color = ThemeColor("muted")
            ws.Cells(r, VIEW_COL_DECISION).Font.Color = vbWhite
            ws.Cells(r, VIEW_COL_DECISION).Font.Bold = True
        Else
            ws.Cells(r, VIEW_COL_DECISION).Interior.Color = ThemeColor("success-bg")
            ws.Cells(r, VIEW_COL_DECISION).Font.Color = ThemeColor("success-text")
        End If
        If CellText(ws.Cells(r, VIEW_COL_VOUCHER).Value) = VOUCHER_YES Then
            ws.Cells(r, VIEW_COL_VOUCHER).Interior.Color = ThemeColor("red")
            ws.Cells(r, VIEW_COL_VOUCHER).Font.Color = vbWhite
            ws.Cells(r, VIEW_COL_VOUCHER).Font.Bold = True
        Else
            ws.Cells(r, VIEW_COL_VOUCHER).Interior.Color = ThemeColor("warning-soft")
            ws.Cells(r, VIEW_COL_VOUCHER).Font.Color = ThemeColor("muted")
            ws.Cells(r, VIEW_COL_VOUCHER).Font.Bold = False
        End If
    Next r
End Sub

Public Sub HandleAnalysisResultDoubleClick(ByVal Target As Range, ByRef Cancel As Boolean)
    If Target Is Nothing Then Exit Sub
    If Target.CountLarge <> 1 Then Exit Sub
    If Target.Row < VIEW_FIRST_DATA_ROW Then Exit Sub
    If Target.Column <> VIEW_COL_VOUCHER And Target.Column <> VIEW_COL_DECISION Then Exit Sub
    If CellText(GetSheet(SH_RESULT).Cells(Target.Row, VIEW_COL_ID).Value) = "" Then Exit Sub
    Cancel = True
    Dim prevEvents As Boolean
    prevEvents = Application.EnableEvents
    On Error GoTo SafeExit
    Application.EnableEvents = False
    GetSheet(SH_RESULT).Unprotect Password:=TOOL_PASSWORD
    If Target.Column = VIEW_COL_VOUCHER Then
        If CellText(Target.Value) = VOUCHER_YES Then
            Target.Value = VOUCHER_NO
            Target.Interior.Color = ThemeColor("warning-soft")
            Target.Font.Color = ThemeColor("muted")
            Target.Font.Bold = False
        Else
            Target.Value = VOUCHER_YES
            Target.Interior.Color = ThemeColor("red")
            Target.Font.Color = vbWhite
            Target.Font.Bold = True
        End If
        GetSheet(SH_RESULT).Cells(Target.Row, RAW_START_COL + RES_COL_VOUCHER - 1).Value = Target.Value
    ElseIf Target.Column = VIEW_COL_DECISION Then
        Select Case NormalizeDecisionText(CellText(Target.Value))
            Case DECISION_USE
                Target.Value = DECISION_EXCLUDE
                Target.Interior.Color = ThemeColor("muted")
                Target.Font.Color = vbWhite
                Target.Font.Bold = True
                GetSheet(SH_RESULT).Cells(Target.Row, VIEW_COL_MEMO).Value = "��⏜�O�B�ĕ��͌�����̑g�������������O���A������̂͑����Ɏg���܂��B"
                With GetSheet(SH_RESULT).Cells(Target.Row, VIEW_COL_VOUCHER)
                    .Value = VOUCHER_NO
                    .Interior.Color = ThemeColor("warning-soft")
                    .Font.Color = ThemeColor("muted")
                    .Font.Bold = False
                End With
                GetSheet(SH_RESULT).Cells(Target.Row, RAW_START_COL + RES_COL_VOUCHER - 1).Value = VOUCHER_NO
            Case DECISION_EXCLUDE
                Target.Value = DECISION_TX_EXCLUDE
                Target.Interior.Color = ThemeColor("warning-text")
                Target.Font.Color = vbWhite
                Target.Font.Bold = True
                GetSheet(SH_RESULT).Cells(Target.Row, VIEW_COL_MEMO).Value = "������O�B�ĕ��͂ł��̌��Ɋ܂܂����ID���V�t�g��₩��O���܂��B"
                With GetSheet(SH_RESULT).Cells(Target.Row, VIEW_COL_VOUCHER)
                    .Value = VOUCHER_NO
                    .Interior.Color = ThemeColor("warning-soft")
                    .Font.Color = ThemeColor("muted")
                    .Font.Bold = False
                End With
                GetSheet(SH_RESULT).Cells(Target.Row, RAW_START_COL + RES_COL_VOUCHER - 1).Value = VOUCHER_NO
            Case Else
                Target.Value = DECISION_USE
                Target.Interior.Color = ThemeColor("success-bg")
                Target.Font.Color = ThemeColor("success-text")
                Target.Font.Bold = False
                GetSheet(SH_RESULT).Cells(Target.Row, VIEW_COL_MEMO).Value = "�̗p�ɖ߂��܂����B������O��߂��ꍇ�͏��O�������m�F���Ă��������B"
        End Select
        GetSheet(SH_RESULT).Cells(Target.Row, RAW_START_COL + RES_COL_SHIFT_DECISION - 1).Value = Target.Value
        GetSheet(SH_RESULT).Cells(Target.Row, RAW_START_COL + RES_COL_OPERATION_MEMO - 1).Value = GetSheet(SH_RESULT).Cells(Target.Row, VIEW_COL_MEMO).Value
    End If
    PersistManualStateFromResultSheet True
SafeExit:
    On Error Resume Next
    BuildResultSummaryCards GetSheet(SH_RESULT), LastRow(GetSheet(SH_RESULT), VIEW_COL_ID)
    On Error GoTo 0
    ProtectOutputSheet GetSheet(SH_RESULT)
    Application.EnableEvents = prevEvents
End Sub

Public Sub ApplyManualExclusionsFromResultSheet(Optional ByVal silent As Boolean = True)
    Dim ws As Worksheet, ex As Worksheet, lastR As Long, r As Long
    Dim idsText As String, idText As String, arr As Variant, i As Long, txId As String, outR As Long
    If Not SheetExists(SH_RESULT) Then Exit Sub
    Set ws = GetSheet(SH_RESULT)
    Set ex = GetSheet(SH_MANUAL_EXCLUDE)
    If LastRow(ex, 1) < 1 Then InitManualExcludeHeaders ex
    lastR = LastRow(ws, VIEW_COL_ID)
    outR = LastRow(ex, 1) + 1
    For r = VIEW_FIRST_DATA_ROW To lastR
        If IsTxExcludeDecision(CellText(ws.Cells(r, VIEW_COL_DECISION).Value)) Then
            idText = CellText(ws.Cells(r, VIEW_COL_ID).Value)
            idsText = JoinNonBlank(CellText(ws.Cells(r, RAW_START_COL + RES_COL_OUT_IDS - 1).Value), CellText(ws.Cells(r, RAW_START_COL + RES_COL_IN_IDS - 1).Value), ",")
            If Len(idsText) > 0 Then
                arr = Split(idsText, ",")
                For i = LBound(arr) To UBound(arr)
                    txId = Trim$(CStr(arr(i)))
                    If Len(txId) > 0 And Not ManualExcludeExists(ex, txId) Then
                        ex.Cells(outR, 1).Value = txId
                        ex.Cells(outR, 2).Value = idText
                        ex.Cells(outR, 3).Value = Now
                        ex.Cells(outR, 4).Value = "���͌��ʃV�[�g�Ŏ�����O�w��"
                        outR = outR + 1
                    End If
                Next i
            End If
        End If
    Next r
    If Not silent Then AppendLog "�蓮���O���f", "����", "���͌��ʃV�[�g����W_�蓮���O�֔��f"
End Sub

Private Function ManualExcludeExists(ByVal ws As Worksheet, ByVal txId As String) As Boolean
    Dim found As Range
    Set found = ws.Columns(1).Find(What:=txId, LookIn:=xlValues, LookAt:=xlWhole)
    ManualExcludeExists = Not found Is Nothing
End Function


Public Sub ApplyVisibleTransactionDecisions(Optional ByVal silent As Boolean = True, Optional ByVal rebuildOutputs As Boolean = False)
    Dim excludeTx As Object, includeTx As Object, memoByTx As Object, idsByTx As Object
    Dim applied As Long, k As Variant

    Set excludeTx = CreateObject("Scripting.Dictionary")
    Set includeTx = CreateObject("Scripting.Dictionary")
    Set memoByTx = CreateObject("Scripting.Dictionary")
    Set idsByTx = CreateObject("Scripting.Dictionary")

    applied = applied + CollectVisibleTransactionDecisions(SH_FLAGGED, excludeTx, includeTx, memoByTx, idsByTx)
    applied = applied + CollectVisibleTransactionDecisions(SH_FLAG_EXTRACT, excludeTx, includeTx, memoByTx, idsByTx)

    For Each k In excludeTx.Keys
        AddManualExcludeFromVisible CStr(k), DictText(idsByTx, CStr(k)), DictText(memoByTx, CStr(k))
    Next k
    For Each k In includeTx.Keys
        If Not excludeTx.Exists(CStr(k)) Then RemoveManualExcludeForTx CStr(k)
    Next k

    If rebuildOutputs And applied > 0 Then
        BuildAnalysisAggregateWorkSheet
        BuildDetailOutputSheet
        BuildFlaggedTransactionSheet
        BuildFlagExtractSheet
    End If
    If Not silent Then AppendLog "�\���\�̎蓮���f���f", "����", "���f�s " & CStr(applied) & "��"
End Sub

Public Sub PersistVisibleFlagSheetManualExclusions(Optional ByVal silent As Boolean = True)
    ApplyVisibleTransactionDecisions silent, False
End Sub

Public Sub ReAnalyzeFromTaggedSheets()
    ReAnalyzeFromVisibleFlagSheets
End Sub

Private Function CollectVisibleTransactionDecisions(ByVal sheetName As String, ByVal excludeTx As Object, ByVal includeTx As Object, ByVal memoByTx As Object, ByVal idsByTx As Object) As Long
    Dim ws As Worksheet, lastR As Long, r As Long
    Dim txCol As Long, voucherCol As Long, decisionCol As Long, idsCol As Long, memoCol As Long
    Dim txId As String, voucherText As String, decisionText As String, analysisIds As String, memoText As String

    If Not SheetExists(sheetName) Then Exit Function
    Set ws = GetSheet(sheetName)
    txCol = HeaderColumn(ws, "���ID", FLAG_HEADER_ROW)
    If txCol = 0 Then Exit Function

    voucherCol = HeaderColumn(ws, "�`�[�˗�", FLAG_HEADER_ROW)
    decisionCol = HeaderColumn(ws, "���f", FLAG_HEADER_ROW)
    idsCol = HeaderColumn(ws, "���͌��ID", FLAG_HEADER_ROW)
    memoCol = HeaderColumn(ws, "���̓���", FLAG_HEADER_ROW)
    lastR = LastRow(ws, txCol)

    For r = FLAG_FIRST_DATA_ROW To lastR
        txId = CellText(ws.Cells(r, txCol).Value)
        If Len(txId) > 0 Then
            voucherText = VOUCHER_NO
            If voucherCol > 0 Then
                voucherText = CellText(ws.Cells(r, voucherCol).Value)
                If voucherText <> VOUCHER_YES Then voucherText = VOUCHER_NO
                ws.Cells(r, voucherCol).Value = voucherText
            End If

            decisionText = DECISION_USE
            If decisionCol > 0 Then
                decisionText = NormalizeDecisionText(CellText(ws.Cells(r, decisionCol).Value))
                If IsExcludeDecision(decisionText) And Not IsTxExcludeDecision(decisionText) Then decisionText = DECISION_USE
                ws.Cells(r, decisionCol).Value = decisionText
            End If

            analysisIds = ""
            memoText = ""
            If idsCol > 0 Then analysisIds = CellText(ws.Cells(r, idsCol).Value)
            If memoCol > 0 Then memoText = CellText(ws.Cells(r, memoCol).Value)

            If IsTxExcludeDecision(decisionText) Then
                excludeTx(txId) = True
            Else
                includeTx(txId) = True
            End If
            If Len(analysisIds) > 0 Then idsByTx(txId) = AppendFlagText(DictText(idsByTx, txId), analysisIds, ",")
            If Len(memoText) > 0 Then memoByTx(txId) = AppendFlagText(DictText(memoByTx, txId), memoText, " / ")
            If Len(analysisIds) > 0 Then UpdateAnalysisIdsFromVisibleRow analysisIds, voucherText, decisionText, memoText
            StyleVisibleDecisionRow ws, r
            CollectVisibleTransactionDecisions = CollectVisibleTransactionDecisions + 1
        End If
    Next r
End Function

Private Function ApplyVisibleTransactionDecisionRow(ByVal ws As Worksheet, ByVal r As Long, Optional ByVal syncOther As Boolean = True) As Long
    Dim txCol As Long, voucherCol As Long, decisionCol As Long, idsCol As Long, memoCol As Long
    Dim txId As String, voucherText As String, decisionText As String, analysisIds As String, memoText As String

    If ws Is Nothing Then Exit Function
    If r < FLAG_FIRST_DATA_ROW Then Exit Function
    txCol = HeaderColumn(ws, "���ID", FLAG_HEADER_ROW)
    If txCol = 0 Then Exit Function
    txId = CellText(ws.Cells(r, txCol).Value)
    If Len(txId) = 0 Then Exit Function

    voucherCol = HeaderColumn(ws, "�`�[�˗�", FLAG_HEADER_ROW)
    decisionCol = HeaderColumn(ws, "���f", FLAG_HEADER_ROW)
    idsCol = HeaderColumn(ws, "���͌��ID", FLAG_HEADER_ROW)
    memoCol = HeaderColumn(ws, "���̓���", FLAG_HEADER_ROW)

    voucherText = VOUCHER_NO
    If voucherCol > 0 Then
        voucherText = CellText(ws.Cells(r, voucherCol).Value)
        If voucherText <> VOUCHER_YES Then voucherText = VOUCHER_NO
        ws.Cells(r, voucherCol).Value = voucherText
    End If

    decisionText = DECISION_USE
    If decisionCol > 0 Then
        decisionText = NormalizeDecisionText(CellText(ws.Cells(r, decisionCol).Value))
        If IsExcludeDecision(decisionText) And Not IsTxExcludeDecision(decisionText) Then decisionText = DECISION_USE
        ws.Cells(r, decisionCol).Value = decisionText
    End If

    If idsCol > 0 Then analysisIds = CellText(ws.Cells(r, idsCol).Value)
    If memoCol > 0 Then memoText = CellText(ws.Cells(r, memoCol).Value)

    If IsTxExcludeDecision(decisionText) Then
        AddManualExcludeFromVisible txId, analysisIds, memoText
    Else
        RemoveManualExcludeForTx txId
    End If
    If Len(analysisIds) > 0 Then UpdateAnalysisIdsFromVisibleRow analysisIds, voucherText, decisionText, memoText
    StyleVisibleDecisionRow ws, r
    If syncOther Then SyncVisibleTransactionDecision ws.Name, txId, voucherText, decisionText, memoText
    ApplyVisibleTransactionDecisionRow = 1
End Function

Private Sub AddManualExcludeFromVisible(ByVal txId As String, ByVal analysisIds As String, ByVal memoText As String)
    Dim ex As Worksheet, outR As Long, found As Range
    If Len(txId) = 0 Then Exit Sub
    Set ex = GetSheet(SH_MANUAL_EXCLUDE)
    InitManualExcludeHeaders ex, False
    Set found = ex.Columns(1).Find(What:=txId, LookIn:=xlValues, LookAt:=xlWhole)
    If found Is Nothing Then
        outR = LastRow(ex, 1) + 1
        If outR < 2 Then outR = 2
    Else
        outR = found.Row
    End If
    ex.Cells(outR, 1).Value = txId
    ex.Cells(outR, 2).Value = analysisIds
    ex.Cells(outR, 3).Value = Now
    ex.Cells(outR, 4).Value = JoinNonBlank("�\���\�Ō�t���O�E������O", memoText, " / ")
End Sub

Private Sub RemoveManualExcludeForTx(ByVal txId As String)
    Dim ex As Worksheet, lastR As Long, r As Long
    If Len(txId) = 0 Then Exit Sub
    If Not SheetExists(SH_MANUAL_EXCLUDE) Then Exit Sub
    Set ex = GetSheet(SH_MANUAL_EXCLUDE)
    lastR = LastRow(ex, 1)
    For r = lastR To 2 Step -1
        If CellText(ex.Cells(r, 1).Value) = txId Then ex.Rows(r).Delete
    Next r
End Sub

Private Sub UpdateAnalysisIdsFromVisibleRow(ByVal analysisIds As String, ByVal voucherText As String, ByVal decisionText As String, ByVal memoText As String)
    Dim arr As Variant, i As Long, idText As String, found As Range
    Dim wsRes As Worksheet, wsDetail As Worksheet
    If Len(analysisIds) = 0 Then Exit Sub
    If Not SheetExists(SH_WORK_RESULT) Or Not SheetExists(SH_WORK_DETAIL) Then Exit Sub
    Set wsRes = GetSheet(SH_WORK_RESULT)
    Set wsDetail = GetSheet(SH_WORK_DETAIL)
    arr = Split(analysisIds, ",")
    For i = LBound(arr) To UBound(arr)
        idText = Trim$(CStr(arr(i)))
        If Len(idText) > 0 Then
            Set found = wsRes.Columns(RES_COL_ID).Find(What:=idText, LookIn:=xlValues, LookAt:=xlWhole)
            If Not found Is Nothing Then
                If voucherText <> VOUCHER_YES Then voucherText = VOUCHER_NO
                If IsTxExcludeDecision(decisionText) Then voucherText = VOUCHER_NO
                wsRes.Cells(found.Row, RES_COL_VOUCHER).Value = voucherText
                wsRes.Cells(found.Row, RES_COL_SHIFT_DECISION).Value = decisionText
                If Len(memoText) > 0 Then wsRes.Cells(found.Row, RES_COL_OPERATION_MEMO).Value = memoText
                ApplyVoucherToDetail wsDetail, idText, voucherText
                UpsertManualStateFromWorkResultRow found.Row
            End If
        End If
    Next i
End Sub

Private Sub UpsertManualStateFromWorkResultRow(ByVal resultRow As Long)
    Dim wsRes As Worksheet, st As Worksheet, keyText As String, outR As Long, found As Range
    If resultRow < 2 Then Exit Sub
    Set wsRes = GetSheet(SH_WORK_RESULT)
    Set st = GetSheet(SH_MANUAL_STATE)
    InitManualStateHeaders st, False
    keyText = BuildAnalysisStateKey(CellText(wsRes.Cells(resultRow, RES_COL_PATTERN).Value), CellText(wsRes.Cells(resultRow, RES_COL_OUT_IDS).Value), CellText(wsRes.Cells(resultRow, RES_COL_IN_IDS).Value))
    If Len(keyText) = 0 Then Exit Sub
    Set found = st.Columns(1).Find(What:=keyText, LookIn:=xlValues, LookAt:=xlWhole)
    If found Is Nothing Then
        outR = LastRow(st, 1) + 1
        If outR < 2 Then outR = 2
    Else
        outR = found.Row
    End If
    st.Cells(outR, 1).Value = keyText
    st.Cells(outR, 2).Value = wsRes.Cells(resultRow, RES_COL_ID).Value
    st.Cells(outR, 3).Value = wsRes.Cells(resultRow, RES_COL_VOUCHER).Value
    st.Cells(outR, 4).Value = wsRes.Cells(resultRow, RES_COL_SHIFT_DECISION).Value
    st.Cells(outR, 5).Value = wsRes.Cells(resultRow, RES_COL_OPERATION_MEMO).Value
    st.Cells(outR, 6).Value = Now
End Sub

Private Sub LoadManualExcludeDictionaries(ByVal excluded As Object, ByVal excludeMemo As Object, Optional ByVal sourceIds As Object = Nothing)
    Dim ws As Worksheet, lastR As Long, r As Long, txId As String
    If excluded Is Nothing Or excludeMemo Is Nothing Then Exit Sub
    If Not SheetExists(SH_MANUAL_EXCLUDE) Then Exit Sub
    Set ws = GetSheet(SH_MANUAL_EXCLUDE)
    lastR = LastRow(ws, 1)
    For r = 2 To lastR
        txId = CellText(ws.Cells(r, 1).Value)
        If Len(txId) > 0 Then
            excluded(txId) = True
            excludeMemo(txId) = CellText(ws.Cells(r, 4).Value)
            If Not sourceIds Is Nothing Then sourceIds(txId) = CellText(ws.Cells(r, 2).Value)
        End If
    Next r
End Sub

Public Sub HandleFlagOutputDoubleClick(ByVal Sh As Object, ByVal Target As Range, ByRef Cancel As Boolean)
    Dim headerText As String, prevEvents As Boolean
    If Target Is Nothing Then Exit Sub
    If Target.CountLarge <> 1 Then Exit Sub
    If Target.Row < FLAG_FIRST_DATA_ROW Then Exit Sub
    headerText = CellText(Target.Worksheet.Cells(FLAG_HEADER_ROW, Target.Column).Value)
    If headerText <> "�`�[�˗�" And headerText <> "���f" Then Exit Sub
    Cancel = True
    prevEvents = Application.EnableEvents
    On Error GoTo SafeExit
    Application.EnableEvents = False
    Target.Worksheet.Unprotect Password:=TOOL_PASSWORD
    If headerText = "�`�[�˗�" Then
        If CellText(Target.Value) = VOUCHER_YES Then Target.Value = VOUCHER_NO Else Target.Value = VOUCHER_YES
    Else
        If IsTxExcludeDecision(CellText(Target.Value)) Then Target.Value = DECISION_USE Else Target.Value = DECISION_TX_EXCLUDE
    End If
    ApplyVisibleTransactionDecisionRow Target.Worksheet, Target.Row, True
SafeExit:
    PrepareFlagOutputEditing Target.Worksheet
    ProtectOutputSheet Target.Worksheet
    Application.EnableEvents = prevEvents
End Sub

Public Sub HandleFlagOutputChange(ByVal Sh As Object, ByVal Target As Range)
    Static handling As Boolean
    Dim cell As Range, headerText As String, prevEvents As Boolean
    If handling Then Exit Sub
    If Target Is Nothing Then Exit Sub
    If Target.Row < FLAG_FIRST_DATA_ROW Then Exit Sub

    handling = True
    prevEvents = Application.EnableEvents
    On Error GoTo SafeExit
    Application.EnableEvents = False
    Target.Worksheet.Unprotect Password:=TOOL_PASSWORD
    For Each cell In Target.Cells
        If cell.Row >= FLAG_FIRST_DATA_ROW Then
            headerText = CellText(cell.Worksheet.Cells(FLAG_HEADER_ROW, cell.Column).Value)
            If headerText = "�`�[�˗�" Or headerText = "���f" Or headerText = "���̓���" Then
                ApplyVisibleTransactionDecisionRow cell.Worksheet, cell.Row, True
            End If
        End If
    Next cell
SafeExit:
    PrepareFlagOutputEditing Target.Worksheet
    ProtectOutputSheet Target.Worksheet
    Application.EnableEvents = prevEvents
    handling = False
End Sub

Public Sub HandleFlagOutputSelectionChange(ByVal Sh As Object, ByVal Target As Range)
    Dim headerText As String
    If Target Is Nothing Then Exit Sub
    If Target.Cells.CountLarge > 1 Then Exit Sub
    headerText = CellText(Target.Worksheet.Cells(FLAG_HEADER_ROW, Target.Column).Value)
    Select Case headerText
        Case "�`�[�˗�"
            Application.StatusBar = "�_�u���N���b�N�ŗv/�s�v��ؑցB04�֏o�������͍T���p�Ɏc���A�˗��p�͋�s���E�x�X���E���t�����ł��B"
        Case "���f"
            Application.StatusBar = "��t���O�̎���͎�����O�ɂ��܂��B���O�ĕ��͂ł��̎�����O���đS���͂������܂��B"
        Case "���̓^�O", "����", "�m�F����", "�֘A�l��/�C�x���g"
            Application.StatusBar = "�C�x���g�E�Z���E�����E�o���E����ގ��E�s���g�����Ȃǂ̕��͍����ł��B"
        Case Else
            Application.StatusBar = False
    End Select
End Sub

Private Sub PrepareFlagOutputEditing(ByVal ws As Worksheet)
    Dim lastR As Long, voucherCol As Long, decisionCol As Long, memoCol As Long, txCol As Long
    If ws Is Nothing Then Exit Sub
    txCol = HeaderColumn(ws, "���ID", FLAG_HEADER_ROW)
    If txCol = 0 Then Exit Sub
    lastR = LastRow(ws, txCol)
    If lastR < FLAG_FIRST_DATA_ROW Then lastR = FLAG_FIRST_DATA_ROW
    voucherCol = HeaderColumn(ws, "�`�[�˗�", FLAG_HEADER_ROW)
    decisionCol = HeaderColumn(ws, "���f", FLAG_HEADER_ROW)
    memoCol = HeaderColumn(ws, "���̓���", FLAG_HEADER_ROW)
    On Error Resume Next
    ws.Cells.Locked = True
    If voucherCol > 0 Then
        With ws.Range(ws.Cells(FLAG_FIRST_DATA_ROW, voucherCol), ws.Cells(lastR, voucherCol))
            .Locked = False
            .Validation.Delete
            .Validation.Add Type:=xlValidateList, AlertStyle:=xlValidAlertStop, Operator:=xlBetween, Formula1:=VOUCHER_YES & "," & VOUCHER_NO
            .Interior.Color = ThemeColor("warning-soft")
        End With
    End If
    If decisionCol > 0 Then
        With ws.Range(ws.Cells(FLAG_FIRST_DATA_ROW, decisionCol), ws.Cells(lastR, decisionCol))
            .Locked = False
            .Validation.Delete
            .Validation.Add Type:=xlValidateList, AlertStyle:=xlValidAlertStop, Operator:=xlBetween, Formula1:=DECISION_USE & "," & DECISION_TX_EXCLUDE
            .Interior.Color = ThemeColor("success-bg")
        End With
    End If
    If memoCol > 0 Then
        With ws.Range(ws.Cells(FLAG_FIRST_DATA_ROW, memoCol), ws.Cells(lastR, memoCol))
            .Locked = False
            .Validation.Delete
            .Interior.Color = vbWhite
        End With
    End If
    On Error GoTo 0
End Sub

Private Sub StyleVisibleDecisionRow(ByVal ws As Worksheet, ByVal r As Long)
    Dim decisionCol As Long, statusCol As Long, decisionText As String
    If ws Is Nothing Then Exit Sub
    decisionCol = HeaderColumn(ws, "���f", FLAG_HEADER_ROW)
    statusCol = HeaderColumn(ws, "�A�g���", FLAG_HEADER_ROW)
    If decisionCol = 0 Or r < FLAG_FIRST_DATA_ROW Then Exit Sub
    decisionText = NormalizeDecisionText(CellText(ws.Cells(r, decisionCol).Value))
    If IsTxExcludeDecision(decisionText) Then
        ws.Cells(r, decisionCol).Interior.Color = ThemeColor("warning-text")
        ws.Cells(r, decisionCol).Font.Color = vbWhite
        ws.Cells(r, decisionCol).Font.Bold = True
        If statusCol > 0 Then ws.Cells(r, statusCol).Value = "�ĕ��͂��珜�O��"
    Else
        ws.Cells(r, decisionCol).Interior.Color = ThemeColor("success-bg")
        ws.Cells(r, decisionCol).Font.Color = ThemeColor("success-text")
        ws.Cells(r, decisionCol).Font.Bold = False
        If statusCol > 0 Then
            If CellText(ws.Cells(r, statusCol).Value) = "�ĕ��͂��珜�O��" Then ws.Cells(r, statusCol).Value = "�蓮�m�F��"
        End If
    End If
End Sub

Private Sub SyncVisibleTransactionDecision(ByVal sourceName As String, ByVal txId As String, ByVal voucherText As String, ByVal decisionText As String, ByVal memoText As String)
    Dim arr As Variant, i As Long, ws As Worksheet, txCol As Long, voucherCol As Long, decisionCol As Long, memoCol As Long
    Dim lastR As Long, r As Long
    If Len(txId) = 0 Then Exit Sub
    arr = Array(SH_FLAGGED, SH_FLAG_EXTRACT)
    For i = LBound(arr) To UBound(arr)
        If CStr(arr(i)) <> sourceName And SheetExists(CStr(arr(i))) Then
            Set ws = GetSheet(CStr(arr(i)))
            txCol = HeaderColumn(ws, "���ID", FLAG_HEADER_ROW)
            voucherCol = HeaderColumn(ws, "�`�[�˗�", FLAG_HEADER_ROW)
            decisionCol = HeaderColumn(ws, "���f", FLAG_HEADER_ROW)
            memoCol = HeaderColumn(ws, "���̓���", FLAG_HEADER_ROW)
            If txCol > 0 Then
                lastR = LastRow(ws, txCol)
                For r = FLAG_FIRST_DATA_ROW To lastR
                    If CellText(ws.Cells(r, txCol).Value) = txId Then
                        If voucherCol > 0 Then ws.Cells(r, voucherCol).Value = voucherText
                        If decisionCol > 0 Then ws.Cells(r, decisionCol).Value = decisionText
                        If memoCol > 0 And Len(memoText) > 0 Then ws.Cells(r, memoCol).Value = memoText
                        StyleVisibleDecisionRow ws, r
                    End If
                Next r
            End If
        End If
    Next i
End Sub

Private Function FlagSourceValue(ByVal ws As Worksheet, ByVal r As Long, ByVal c As Long) As Variant
    If c > 0 Then FlagSourceValue = ws.Cells(r, c).Value Else FlagSourceValue = ""
End Function

Private Function FlagSourceText(ByVal ws As Worksheet, ByVal r As Long, ByVal c As Long) As String
    If c > 0 Then FlagSourceText = CellText(ws.Cells(r, c).Value) Else FlagSourceText = ""
End Function

Private Function FirstFlagSourceColumn(ByVal ws As Worksheet, ByVal headers As Variant) As Long
    FirstFlagSourceColumn = FirstHeaderColumn(ws, headers, 1)
End Function

Private Function CountDataNonBlank(ByVal ws As Worksheet, ByVal colIndex As Long, Optional ByVal firstDataRow As Long = 2) As Long
    Dim lastR As Long, r As Long
    If ws Is Nothing Or colIndex <= 0 Then Exit Function
    lastR = LastRow(ws, colIndex)
    For r = firstDataRow To lastR
        If Len(CellText(ws.Cells(r, colIndex).Value)) > 0 Then CountDataNonBlank = CountDataNonBlank + 1
    Next r
End Function

Private Function CountTagText(ByVal tokenText As String) As Long
    Dim ws As Worksheet, lastR As Long, r As Long, textValue As String
    If Not SheetExists(SH_WORK_TX_TAG) Then Exit Function
    Set ws = GetSheet(SH_WORK_TX_TAG)
    lastR = LastRow(ws, 1)
    For r = 2 To lastR
        textValue = JoinNonBlank(CellText(ws.Cells(r, 2).Value), CellText(ws.Cells(r, 5).Value), " / ")
        If InStr(1, textValue, tokenText, vbTextCompare) > 0 Then CountTagText = CountTagText + 1
    Next r
End Function

Private Function MaterialSummaryText() As String
    Dim tx As Worksheet, txCount As Long
    Dim colPerson As Long, colTime As Long, colShop As Long, colBalance As Long
    Dim personCount As Long, timeCount As Long, shopCount As Long, balanceCount As Long
    Dim addrCount As Long, relCount As Long, tagCount As Long, comboCount As Long
    If SheetExists(SH_WORK_TX) Then
        Set tx = GetSheet(SH_WORK_TX)
        txCount = Application.Max(0, LastRow(tx, 1) - 1)
        colPerson = FirstHeaderColumn(tx, Array("�l��ID", "���`�l�l��ID"), 1)
        colTime = HeaderColumn(tx, "����", 1)
        colShop = FirstHeaderColumn(tx, Array("�戵�X�m��l", "�戵�X", "�x�X��"), 1)
        colBalance = FirstHeaderColumn(tx, Array("�����c��", "�c��"), 1)
        personCount = CountDataNonBlank(tx, colPerson, 2)
        timeCount = CountDataNonBlank(tx, colTime, 2)
        shopCount = CountDataNonBlank(tx, colShop, 2)
        balanceCount = CountDataNonBlank(tx, colBalance, 2)
    End If
    If SheetExists(SH_WORK_ADDRESS) Then addrCount = Application.Max(0, LastRow(GetSheet(SH_WORK_ADDRESS), 1) - 1)
    If SheetExists(SH_WORK_REL) Then relCount = Application.Max(0, LastRow(GetSheet(SH_WORK_REL), 1) - 1)
    If SheetExists(SH_WORK_TX_TAG) Then tagCount = Application.Max(0, LastRow(GetSheet(SH_WORK_TX_TAG), 1) - 1)
    If SheetExists(SH_WORK_UNKNOWN_COMBO) Then comboCount = Application.Max(0, LastRow(GetSheet(SH_WORK_UNKNOWN_COMBO), 1) - 1)
    MaterialSummaryText = "�l���A�g " & CStr(personCount) & "/" & CStr(txCount) & _
                          " / ���� " & CStr(timeCount) & "/" & CStr(txCount) & _
                          " / �戵�X " & CStr(shopCount) & "/" & CStr(txCount) & _
                          " / �c�� " & CStr(balanceCount) & "/" & CStr(txCount) & vbCrLf & _
                          "�Z������ " & CStr(addrCount) & " / �֌W " & CStr(relCount) & _
                          " / �����^�O " & CStr(tagCount) & " / �s���g���� " & CStr(comboCount)
End Function

Private Function EventSummaryText() As String
    EventSummaryText = "�]�� " & CStr(CountTagText("�]��")) & _
                       " / ���� " & CStr(CountTagText("����")) & _
                       " / �o�� " & CStr(CountTagText("�o��")) & _
                       " / ������ " & CStr(CountTagText("������")) & _
                       " / �戵�X " & CStr(CountTagText("�戵�X")) & _
                       " / �c�� " & CStr(CountTagText("�c��"))
End Function

Private Sub BuildVisibleAnalysisDashboard(ByVal ws As Worksheet, ByVal titleText As String, ByVal outputLastC As Long, ByVal dataLastR As Long)
    Dim txCol As Long, flagCol As Long, tagCol As Long, voucherCol As Long, decisionCol As Long, sevCol As Long
    Dim r As Long, totalCount As Long, flagCount As Long, voucherCount As Long, excludeCount As Long, maxSev As Long
    Dim hasAnyFlag As Boolean, sevCurrent As Long
    Dim diagText As String, statusText As String, nextText As String
    txCol = HeaderColumn(ws, "���ID", FLAG_HEADER_ROW)
    flagCol = HeaderColumn(ws, "���̓t���O", FLAG_HEADER_ROW)
    tagCol = HeaderColumn(ws, "���̓^�O", FLAG_HEADER_ROW)
    voucherCol = HeaderColumn(ws, "�`�[�˗�", FLAG_HEADER_ROW)
    decisionCol = HeaderColumn(ws, "���f", FLAG_HEADER_ROW)
    sevCol = HeaderColumn(ws, "�d�v�x", FLAG_HEADER_ROW)
    For r = FLAG_FIRST_DATA_ROW To dataLastR
        If txCol > 0 And Len(CellText(ws.Cells(r, txCol).Value)) > 0 Then
            totalCount = totalCount + 1
            hasAnyFlag = False
            If flagCol > 0 And Len(CellText(ws.Cells(r, flagCol).Value)) > 0 Then hasAnyFlag = True
            If tagCol > 0 And Len(CellText(ws.Cells(r, tagCol).Value)) > 0 Then hasAnyFlag = True
            If hasAnyFlag Then flagCount = flagCount + 1
            If voucherCol > 0 And CellText(ws.Cells(r, voucherCol).Value) = VOUCHER_YES Then voucherCount = voucherCount + 1
            If decisionCol > 0 And IsTxExcludeDecision(CellText(ws.Cells(r, decisionCol).Value)) Then excludeCount = excludeCount + 1
            If sevCol > 0 Then
                sevCurrent = CLng(NzDbl(ws.Cells(r, sevCol).Value, 0))
                If sevCurrent > maxSev Then maxSev = sevCurrent
            End If
        End If
    Next r
    diagText = AnalysisRunDiagnosticText()
    If Len(diagText) = 0 Then
        statusText = "����x���Ȃ��B�\�����̔��f�E�`�[�˗��͕ҏW����Ɠ�����Ԃ֑������f���܂��B"
    Else
        statusText = "����: " & diagText & vbCrLf & "�������E�������̑g����������\��������܂��B������������������čĕ��͂��Ă��������B"
    End If
    If voucherCount > 0 Then
        nextText = "�`�[�˗��u�v�v������܂��B���̓`�[�˗��E���f���m�F���A���ʕۑ�����04�֐i�݂܂��B"
    ElseIf flagCount > 0 Then
        nextText = "�t���O������܂��B��t���O�͔��f��������O�ɂ��āA���O�ĕ��͂��܂��B"
    Else
        nextText = "�����t���O�͂���܂���B���͍ޗ�������Ȃ��ꍇ�͐l���E�Z���E�����E�戵�X�E�c�������čĕ��͂��܂��B"
    End If

    ws.Range(ws.Cells(1, 1), ws.Cells(1, FLAG_LEFT_COLS)).Merge
    With ws.Cells(1, 1)
        .Value = "03_�����ړ����� �| " & titleText
        .Interior.Color = ThemeColor("title")
        .Font.Color = vbWhite
        .Font.Bold = True
        .Font.Size = 16
        .HorizontalAlignment = xlCenter
        .VerticalAlignment = xlCenter
    End With
    ws.Rows(1).RowHeight = 30

    ws.Range("A2:C4").Merge
    ws.Range("D2:G4").Merge
    ws.Range("H2:K4").Merge
    ws.Range("L2:O4").Merge
    ws.Range("P2:U4").Merge
    ws.Range("A2").Value = "���" & vbCrLf & _
        "��� " & CStr(totalCount) & "�� / �t���O " & CStr(flagCount) & "��" & vbCrLf & _
        "�`�[�v " & CStr(voucherCount) & "�� / ���O " & CStr(excludeCount) & "�� / �ő�d�v�x " & CStr(maxSev)
    ws.Range("D2").Value = "���̑���" & vbCrLf & nextText
    ws.Range("H2").Value = "�x��" & vbCrLf & statusText
    ws.Range("L2").Value = "���͍ޗ�" & vbCrLf & MaterialSummaryText()
    ws.Range("P2").Value = "�C�x���g�E����^�O" & vbCrLf & EventSummaryText()
    FormatDashboardCard ws.Range("A2"), ThemeColor("info-soft"), ThemeColor("header")
    FormatDashboardCard ws.Range("D2"), ThemeColor("success-bg"), ThemeColor("success-text")
    If Len(diagText) > 0 Then
        FormatDashboardCard ws.Range("H2"), ThemeColor("warning-soft"), ThemeColor("warning-text")
    Else
        FormatDashboardCard ws.Range("H2"), ThemeColor("canvas"), ThemeColor("muted")
    End If
    FormatDashboardCard ws.Range("L2"), ThemeColor("section"), ThemeColor("header")
    FormatDashboardCard ws.Range("P2"), ThemeColor("purple-soft"), ThemeColor("header")
    ThemeApplyPanelBorders ws.Range("A2:U4")
    ws.Rows("2:4").RowHeight = 24

    ws.Range("A6:U6").Merge
    With ws.Range("A6")
        .Value = "���������Ŋm�F�ł��܂��B�`�[�˗��E���f�E���̓����͕ҏW�B�E���̌��\��͊č��p�Ɏc���Ă��܂��B"
        .Interior.Color = ThemeColor("canvas")
        .Font.Color = ThemeColor("muted")
        .Font.Bold = True
        .WrapText = True
        .VerticalAlignment = xlCenter
    End With
    ws.Rows(6).RowHeight = 24
End Sub

Private Sub FormatDashboardCard(ByVal cell As Range, ByVal fillColor As Long, ByVal fontColor As Long)
    With cell
        .Interior.Color = fillColor
        .Font.Color = fontColor
        .Font.Bold = True
        .Font.Size = 10
        .WrapText = True
        .VerticalAlignment = xlCenter
        .HorizontalAlignment = xlLeft
    End With
End Sub

Private Sub SetFixedVisibleAnalysisWidths(ByVal ws As Worksheet, ByVal outputLastC As Long, ByVal dataLastR As Long)
    If ws Is Nothing Then Exit Sub
    ws.Columns("A:A").ColumnWidth = 13
    ws.Columns("B:B").ColumnWidth = 11
    ws.Columns("C:C").ColumnWidth = 8
    ws.Columns("D:D").ColumnWidth = 13
    ws.Columns("E:G").ColumnWidth = 13
    ws.Columns("H:J").ColumnWidth = 12
    ws.Columns("K:K").ColumnWidth = 17
    ws.Columns("L:L").ColumnWidth = 24
    ws.Columns("M:M").ColumnWidth = 8
    ws.Columns("N:O").ColumnWidth = 9
    ws.Columns("P:P").ColumnWidth = 26
    ws.Columns("Q:Q").ColumnWidth = 26
    ws.Columns("R:R").ColumnWidth = 24
    ws.Columns("S:S").ColumnWidth = 24
    ws.Columns("T:T").ColumnWidth = 16
    ws.Columns("U:U").ColumnWidth = 18
    If outputLastC >= FLAG_ORIG_START_COL Then
        ws.Columns(ColumnLetter(FLAG_ORIG_START_COL) & ":" & ColumnLetter(outputLastC)).ColumnWidth = 11
        ws.Columns(FLAG_ORIG_START_COL).ColumnWidth = 13
        ws.Columns(ColumnLetter(FLAG_ORIG_START_COL) & ":" & ColumnLetter(outputLastC)).Hidden = True
    End If
    ws.Range(ws.Cells(1, 1), ws.Cells(Application.Max(dataLastR, FLAG_FIRST_DATA_ROW), Application.Min(outputLastC, FLAG_LEFT_COLS))).WrapText = True
    If dataLastR >= FLAG_FIRST_DATA_ROW Then ws.Rows(CStr(FLAG_FIRST_DATA_ROW) & ":" & CStr(dataLastR)).RowHeight = 42
    ws.ScrollArea = "A1:U" & CStr(Application.Max(200, dataLastR + 30))
End Sub


Public Sub BuildFlaggedTransactionSheet()
    Dim src As Worksheet, dst As Worksheet, detail As Worksheet, resultWs As Worksheet, tagWs As Worksheet
    Dim lastR As Long, lastC As Long, r As Long, c As Long, outR As Long, outputLastC As Long, dataLastR As Long
    Dim txId As String, flagText As String, tagText As String, statusText As String
    Dim sevValue As Long, voucherText As String, decisionText As String, memoText As String
    Dim flags As Object, ids As Object, vouchers As Object, decisions As Object, memos As Object
    Dim tags As Object, severity As Object, evidence As Object, actions As Object, people As Object
    Dim manualExcluded As Object, manualNotes As Object, manualSource As Object
    Dim colTx As Long, colDate As Long, colTime As Long, colPerson As Long, colBank As Long, colBranch As Long
    Dim colShop As Long, colOut As Long, colIn As Long, colBal As Long

    Set src = GetSheet(SH_WORK_TX)
    Set detail = GetSheet(SH_WORK_DETAIL)
    Set resultWs = GetSheet(SH_WORK_RESULT)
    Set tagWs = GetSheet(SH_WORK_TX_TAG)
    Set dst = GetOrCreateSheet(SH_FLAGGED, False)

    On Error Resume Next
    dst.Unprotect Password:=TOOL_PASSWORD
    dst.ScrollArea = ""
    dst.Cells.EntireColumn.Hidden = False
    dst.Cells.UnMerge
    dst.Cells.Clear
    DeleteAllShapes dst
    On Error GoTo 0

    Set flags = CreateObject("Scripting.Dictionary")
    Set ids = CreateObject("Scripting.Dictionary")
    Set vouchers = CreateObject("Scripting.Dictionary")
    Set decisions = CreateObject("Scripting.Dictionary")
    Set memos = CreateObject("Scripting.Dictionary")
    Set tags = CreateObject("Scripting.Dictionary")
    Set severity = CreateObject("Scripting.Dictionary")
    Set evidence = CreateObject("Scripting.Dictionary")
    Set actions = CreateObject("Scripting.Dictionary")
    Set people = CreateObject("Scripting.Dictionary")
    Set manualExcluded = CreateObject("Scripting.Dictionary")
    Set manualNotes = CreateObject("Scripting.Dictionary")
    Set manualSource = CreateObject("Scripting.Dictionary")

    BuildFlagDictionaries detail, resultWs, flags, ids, vouchers, decisions, memos, evidence, actions, people, severity
    BuildEnhancedTagDictionaries tagWs, tags, severity, evidence, actions, people
    LoadManualExcludeDictionaries manualExcluded, manualNotes, manualSource

    lastR = LastRow(src, 1)
    lastC = LastUsedColumn(src)
    If lastR < 1 Or lastC < 1 Then Exit Sub
    outputLastC = FLAG_ORIG_START_COL + lastC - 1

    colTx = FirstFlagSourceColumn(src, Array("���ID"))
    If colTx = 0 Then colTx = 1
    colDate = FirstFlagSourceColumn(src, Array("���t", "�����"))
    colTime = FirstFlagSourceColumn(src, Array("����"))
    colPerson = FirstFlagSourceColumn(src, Array("�l����", "����", "���`�l"))
    colBank = FirstFlagSourceColumn(src, Array("��s��", "���Z�@��"))
    colBranch = FirstFlagSourceColumn(src, Array("�x�X��", "�x�X"))
    colShop = FirstFlagSourceColumn(src, Array("�戵�X�m��l", "�戵�X", "�����戵�X"))
    colOut = FirstFlagSourceColumn(src, Array("�o��", "�o���z"))
    colIn = FirstFlagSourceColumn(src, Array("����", "�����z"))
    colBal = FirstFlagSourceColumn(src, Array("�����c��", "�c��"))

    SetRowValues dst.Cells(FLAG_HEADER_ROW, 1), Array("���ID", "���t", "����", "����", "��s��", "�x�X��", "�戵�X", "�o��", "����", "�c��", "���̓t���O", "���̓^�O", "�d�v�x", "�`�[�˗�", "���f", "�v�_", "�m�F����", "�֘A�l��/�C�x���g", "���̓���", "�A�g���", "���͌��ID")
    For c = 1 To lastC
        dst.Cells(FLAG_HEADER_ROW, FLAG_ORIG_START_COL + c - 1).Value = "���\_" & CellText(src.Cells(1, c).Value)
    Next c
    FormatHeader dst.Range(dst.Cells(FLAG_HEADER_ROW, 1), dst.Cells(FLAG_HEADER_ROW, outputLastC)), ThemeColor("header")

    For r = 2 To lastR
        outR = FLAG_FIRST_DATA_ROW + r - 2
        txId = CellText(src.Cells(r, colTx).Value)
        flagText = DictText(flags, txId)
        tagText = DictText(tags, txId)
        If Len(tagText) > 0 And Len(flagText) = 0 Then flagText = KIND_CONTEXT_FLAG
        sevValue = DictLong(severity, txId)
        voucherText = DictText(vouchers, txId)
        If voucherText <> VOUCHER_YES Then voucherText = VOUCHER_NO
        decisionText = DictText(decisions, txId)
        If Len(decisionText) = 0 Or IsExcludeDecision(decisionText) And Not IsTxExcludeDecision(decisionText) Then decisionText = DECISION_USE
        memoText = DictText(memos, txId)

        statusText = ""
        If Len(DictText(flags, txId)) > 0 And Len(tagText) > 0 Then
            statusText = "���+�����^�O"
        ElseIf Len(DictText(flags, txId)) > 0 Then
            statusText = "���͌�₠��"
        ElseIf Len(tagText) > 0 Then
            statusText = "�����^�O�̂�"
        End If
        If voucherText = VOUCHER_YES Then statusText = JoinNonBlank(statusText, "04�`�[���", " / ")
        If manualExcluded.Exists(txId) Then
            flagText = AppendFlagText(flagText, "�蓮������O", " / ")
            tagText = AppendFlagText(tagText, "�ĕ��͏��O", " / ")
            decisionText = DECISION_TX_EXCLUDE
            voucherText = VOUCHER_NO
            memoText = AppendFlagText(memoText, DictText(manualNotes, txId), " / ")
            statusText = "�ĕ��͂��珜�O��"
            If sevValue < 1 Then sevValue = 1
        End If

        dst.Cells(outR, 1).Value = txId
        dst.Cells(outR, 2).Value = FlagSourceValue(src, r, colDate)
        dst.Cells(outR, 3).Value = FlagSourceValue(src, r, colTime)
        dst.Cells(outR, 4).Value = FlagSourceValue(src, r, colPerson)
        dst.Cells(outR, 5).Value = FlagSourceValue(src, r, colBank)
        dst.Cells(outR, 6).Value = FlagSourceValue(src, r, colBranch)
        dst.Cells(outR, 7).Value = FlagSourceValue(src, r, colShop)
        dst.Cells(outR, 8).Value = FlagSourceValue(src, r, colOut)
        dst.Cells(outR, 9).Value = FlagSourceValue(src, r, colIn)
        dst.Cells(outR, 10).Value = FlagSourceValue(src, r, colBal)
        dst.Cells(outR, 11).Value = flagText
        dst.Cells(outR, 12).Value = tagText
        If sevValue > 0 Then dst.Cells(outR, 13).Value = sevValue
        dst.Cells(outR, 14).Value = voucherText
        dst.Cells(outR, 15).Value = decisionText
        dst.Cells(outR, 16).Value = DictText(evidence, txId)
        dst.Cells(outR, 17).Value = DictText(actions, txId)
        dst.Cells(outR, 18).Value = DictText(people, txId)
        dst.Cells(outR, 19).Value = memoText
        dst.Cells(outR, 20).Value = statusText
        dst.Cells(outR, 21).Value = DictText(ids, txId)
        dst.Range(dst.Cells(outR, FLAG_ORIG_START_COL), dst.Cells(outR, outputLastC)).Value = src.Range(src.Cells(r, 1), src.Cells(r, lastC)).Value
        If Len(flagText) > 0 Or Len(tagText) > 0 Or Len(statusText) > 0 Then ApplyFlagColor dst.Range(dst.Cells(outR, 1), dst.Cells(outR, FLAG_LEFT_COLS)), JoinNonBlank(flagText, tagText, " / ")
        StyleVisibleDecisionRow dst, outR
    Next r

    dataLastR = FLAG_FIRST_DATA_ROW + Application.Max(0, lastR - 2)
    BuildVisibleAnalysisDashboard dst, "��������\_���͍�", outputLastC, dataLastR
    If dataLastR >= FLAG_FIRST_DATA_ROW Then FormatBody dst.Range(dst.Cells(FLAG_FIRST_DATA_ROW, 1), dst.Cells(dataLastR, outputLastC))
    PrepareFlagOutputEditing dst
    dst.Range(dst.Cells(FLAG_HEADER_ROW, 1), dst.Cells(Application.Max(FLAG_HEADER_ROW, dataLastR), outputLastC)).AutoFilter
    dst.Visible = xlSheetVisible
    dst.Activate
    On Error Resume Next
    ActiveWindow.FreezePanes = False
    dst.Range("A" & CStr(FLAG_FIRST_DATA_ROW)).Select
    ActiveWindow.FreezePanes = True
    On Error GoTo 0
    SetFixedVisibleAnalysisWidths dst, outputLastC, dataLastR
    ThemeApplyPrintTable dst.Range(dst.Cells(FLAG_HEADER_ROW, 1), dst.Cells(Application.Max(FLAG_HEADER_ROW, dataLastR), FLAG_LEFT_COLS)), 1
    ThemeCapRowHeights dst.Range(dst.Cells(FLAG_FIRST_DATA_ROW, 1), dst.Cells(Application.Max(FLAG_FIRST_DATA_ROW, dataLastR), FLAG_LEFT_COLS)), 20, 96
    ThemeApplyMonochromePrint dst, dst.Range(dst.Cells(1, 1), dst.Cells(Application.Max(FLAG_HEADER_ROW, dataLastR), FLAG_LEFT_COLS)).Address, True, "$7:$7", 1, 0
    AddVisibleAnalysisControls dst, outputLastC
    ThemeMarkMacroButtonsNonPrintable dst
    ProtectOutputSheet dst
End Sub

Public Sub BuildFlagExtractSheet()
    Dim src As Worksheet, dst As Worksheet
    Dim lastR As Long, lastC As Long, r As Long, outR As Long, dataLastR As Long
    Dim flagCol As Long, tagCol As Long, sevCol As Long, statusCol As Long
    Dim flagText As String, tagText As String, statusText As String, sevValue As Double

    Set src = GetSheet(SH_FLAGGED)
    Set dst = GetOrCreateSheet(SH_FLAG_EXTRACT, False)

    On Error Resume Next
    dst.Unprotect Password:=TOOL_PASSWORD
    dst.ScrollArea = ""
    dst.Cells.EntireColumn.Hidden = False
    dst.Cells.UnMerge
    dst.Cells.Clear
    DeleteAllShapes dst
    On Error GoTo 0

    lastR = LastRow(src, 1)
    lastC = LastUsedColumn(src)
    If lastR < FLAG_HEADER_ROW Or lastC < 1 Then Exit Sub

    flagCol = HeaderColumn(src, "���̓t���O", FLAG_HEADER_ROW)
    tagCol = HeaderColumn(src, "���̓^�O", FLAG_HEADER_ROW)
    sevCol = HeaderColumn(src, "�d�v�x", FLAG_HEADER_ROW)
    statusCol = HeaderColumn(src, "�A�g���", FLAG_HEADER_ROW)
    If flagCol = 0 Then Exit Sub

    dst.Range(dst.Cells(FLAG_HEADER_ROW, 1), dst.Cells(FLAG_HEADER_ROW, lastC)).Value = src.Range(src.Cells(FLAG_HEADER_ROW, 1), src.Cells(FLAG_HEADER_ROW, lastC)).Value
    FormatHeader dst.Range(dst.Cells(FLAG_HEADER_ROW, 1), dst.Cells(FLAG_HEADER_ROW, lastC)), ThemeColor("header")
    outR = FLAG_FIRST_DATA_ROW
    For r = FLAG_FIRST_DATA_ROW To lastR
        flagText = CellText(src.Cells(r, flagCol).Value)
        tagText = ""
        statusText = ""
        If tagCol > 0 Then tagText = CellText(src.Cells(r, tagCol).Value)
        If statusCol > 0 Then statusText = CellText(src.Cells(r, statusCol).Value)
        sevValue = 0
        If sevCol > 0 Then sevValue = NzDbl(src.Cells(r, sevCol).Value, 0)
        If Len(flagText) > 0 Or Len(tagText) > 0 Or sevValue > 0 Or InStr(statusText, "���O") > 0 Then
            dst.Range(dst.Cells(outR, 1), dst.Cells(outR, lastC)).Value = src.Range(src.Cells(r, 1), src.Cells(r, lastC)).Value
            ApplyFlagColor dst.Range(dst.Cells(outR, 1), dst.Cells(outR, FLAG_LEFT_COLS)), JoinNonBlank(flagText, tagText, " / ")
            StyleVisibleDecisionRow dst, outR
            outR = outR + 1
        End If
    Next r

    dataLastR = Application.Max(FLAG_HEADER_ROW, outR - 1)
    BuildVisibleAnalysisDashboard dst, "�t���O���o", lastC, dataLastR
    If dataLastR >= FLAG_FIRST_DATA_ROW Then FormatBody dst.Range(dst.Cells(FLAG_FIRST_DATA_ROW, 1), dst.Cells(dataLastR, lastC))
    PrepareFlagOutputEditing dst
    dst.Range(dst.Cells(FLAG_HEADER_ROW, 1), dst.Cells(Application.Max(FLAG_HEADER_ROW, dataLastR), lastC)).AutoFilter
    SetFixedVisibleAnalysisWidths dst, lastC, dataLastR
    ThemeApplyPrintTable dst.Range(dst.Cells(FLAG_HEADER_ROW, 1), dst.Cells(Application.Max(FLAG_HEADER_ROW, dataLastR), FLAG_LEFT_COLS)), 1
    ThemeCapRowHeights dst.Range(dst.Cells(FLAG_FIRST_DATA_ROW, 1), dst.Cells(Application.Max(FLAG_FIRST_DATA_ROW, dataLastR), FLAG_LEFT_COLS)), 20, 96
    ThemeApplyMonochromePrint dst, dst.Range(dst.Cells(1, 1), dst.Cells(Application.Max(FLAG_HEADER_ROW, dataLastR), FLAG_LEFT_COLS)).Address, True, "$7:$7", 1, 0
    AddVisibleAnalysisControls dst, lastC
    ThemeMarkMacroButtonsNonPrintable dst
    ProtectOutputSheet dst
End Sub

Private Sub AddVisibleAnalysisControls(ByVal ws As Worksheet, ByVal outputLastC As Long)
    AddVisibleAnalysisButton ws, "�S����", "RunAnalysis", ws.Range("A5"), ThemeColor("teal")
    AddVisibleAnalysisButton ws, "���O�ĕ���", "ReAnalyzeFromVisibleFlagSheets", ws.Range("C5"), ThemeColor("orange")
    AddVisibleAnalysisButton ws, "�s���g����", "AnalyzeUnknownFlagAmountCombinationsOnly", ws.Range("E5"), ThemeColor("purple")
    AddVisibleAnalysisButton ws, "�ύX���f", "ApplyManualEditsFromResultSheet", ws.Range("G5"), ThemeColor("red")
    AddVisibleAnalysisButton ws, "���ʕۑ�/04��", "SaveAnalysisToCommonData", ws.Range("I5"), ThemeColor("teal")
    AddVisibleAnalysisButton ws, "���O����", "ClearManualExclusions", ws.Range("K5"), ThemeColor("muted")
    AddVisibleAnalysisButton ws, "������", "ShowMainSheet", ws.Range("M5"), ThemeColor("header")
    AddVisibleAnalysisButton ws, "�ŏI�o��", "ExportAnalysisWorkbook", ws.Range("O5"), ThemeColor("purple")
    AddVisibleAnalysisButton ws, "�ǐ�", "TraceSelectedUnknownOutToLaterUnknownIns", ws.Range("Q5"), ThemeColor("purple")
End Sub

Private Sub AddVisibleAnalysisDiagnostics(ByVal ws As Worksheet, ByVal anchorCol As Long)
    ' �݊��p�B�x���� BuildVisibleAnalysisDashboard �̍���J�[�h�ɏW�񂷂�B
End Sub

Private Sub AddVisibleAnalysisButton(ByVal ws As Worksheet, ByVal caption As String, ByVal macroName As String, ByVal anchor As Range, ByVal fillColor As Long)
    Dim shp As Shape, target As Range
    Const M As Double = 2
    Set target = ws.Range(anchor, anchor.Offset(0, 1))
    Set shp = ws.Shapes.AddShape(msoShapeRoundedRectangle, target.Left + M, target.Top + M, Application.Max(6, target.Width - M * 2), Application.Max(6, target.Height - M * 2))
    shp.Name = "btn_analysis_" & macroName & "_" & CStr(anchor.Row) & "_" & CStr(anchor.Column)
    ThemeStyleButtonShapeWithColor shp, caption, fillColor, fillColor, ThemeReadableFontColor(fillColor), macroName
End Sub

Private Sub BuildFlagDictionaries(ByVal detail As Worksheet, ByVal resultWs As Worksheet, ByVal flags As Object, ByVal ids As Object, ByVal vouchers As Object, ByVal decisions As Object, ByVal memos As Object, ByVal evidence As Object, ByVal actions As Object, ByVal people As Object, ByVal severity As Object)
    Dim lastR As Long, r As Long, txId As String, kindText As String, analysisId As String
    Dim resultMap As Object, rr As Long, summaryText As String, memoText As String, decisionText As String, voucherText As String, personText As String
    Set resultMap = CreateObject("Scripting.Dictionary")
    If Not resultWs Is Nothing Then
        For rr = 2 To LastRow(resultWs, RES_COL_ID)
            analysisId = CellText(resultWs.Cells(rr, RES_COL_ID).Value)
            If Len(analysisId) > 0 Then resultMap(analysisId) = rr
        Next rr
    End If

    If detail Is Nothing Then Exit Sub
    lastR = LastRow(detail, DET_COL_ID)
    For r = 2 To lastR
        txId = CellText(detail.Cells(r, DET_COL_TX_ID).Value)
        kindText = CellText(detail.Cells(r, DET_COL_KIND).Value)
        analysisId = CellText(detail.Cells(r, DET_COL_ANALYSIS_ID).Value)
        If Len(txId) > 0 Then
            flags(txId) = AppendFlagText(DictText(flags, txId), kindText, ",")
            ids(txId) = AppendFlagText(DictText(ids, txId), analysisId, ",")
            voucherText = CellText(detail.Cells(r, DET_COL_VOUCHER).Value)
            If voucherText = VOUCHER_YES Then
                vouchers(txId) = VOUCHER_YES
            ElseIf Not vouchers.Exists(txId) Then
                vouchers(txId) = VOUCHER_NO
            End If
            personText = JoinNonBlank(CellText(detail.Cells(r, DET_COL_PERSON_NAME).Value), CellText(detail.Cells(r, DET_COL_DATE).Text), " / ")
            people(txId) = AppendFlagText(DictText(people, txId), personText, " / ")
            UpdateSeverity severity, txId, SeverityFromKind(kindText)

            If resultMap.Exists(analysisId) Then
                rr = CLng(resultMap(analysisId))
                decisionText = NormalizeDecisionText(CellText(resultWs.Cells(rr, RES_COL_SHIFT_DECISION).Value))
                If IsTxExcludeDecision(decisionText) Then
                    decisions(txId) = DECISION_TX_EXCLUDE
                ElseIf Not decisions.Exists(txId) Then
                    decisions(txId) = DECISION_USE
                End If
                UpdateSeverity severity, txId, SeverityFromScore(NzDbl(resultWs.Cells(rr, RES_COL_SCORE).Value, 0))
                summaryText = JoinNonBlank(CellText(resultWs.Cells(rr, RES_COL_PATTERN).Value), CellText(resultWs.Cells(rr, RES_COL_SUMMARY).Value), " / ")
                summaryText = JoinNonBlank(summaryText, CellText(resultWs.Cells(rr, RES_COL_INH_TIMING).Value), " / ")
                summaryText = JoinNonBlank(summaryText, CellText(resultWs.Cells(rr, RES_COL_COHAB).Value), " / ")
                summaryText = JoinNonBlank(summaryText, CellText(resultWs.Cells(rr, RES_COL_AGE_HINT).Value), " / ")
                summaryText = JoinNonBlank(summaryText, CellText(resultWs.Cells(rr, RES_COL_ADDRESS_HINT).Value), " / ")
                evidence(txId) = AppendFlagText(DictText(evidence, txId), summaryText, " / ")
                actions(txId) = AppendFlagText(DictText(actions, txId), ActionTextForKind(kindText), " / ")
                memoText = JoinNonBlank(CellText(resultWs.Cells(rr, RES_COL_MEMO).Value), CellText(resultWs.Cells(rr, RES_COL_OPERATION_MEMO).Value), " / ")
                memos(txId) = AppendFlagText(DictText(memos, txId), memoText, " / ")
            Else
                If Not decisions.Exists(txId) Then decisions(txId) = DECISION_USE
                memos(txId) = AppendFlagText(DictText(memos, txId), "���͑Ώ�", " / ")
            End If
        End If
    Next r
End Sub

Private Sub BuildEnhancedTagDictionaries(ByVal tagWs As Worksheet, ByVal tags As Object, ByVal severity As Object, ByVal evidence As Object, ByVal actions As Object, ByVal people As Object)
    Dim lastR As Long, r As Long, txId As String
    If tagWs Is Nothing Then Exit Sub
    lastR = LastRow(tagWs, 1)
    For r = 2 To lastR
        txId = CellText(tagWs.Cells(r, 1).Value)
        If Len(txId) > 0 Then
            tags(txId) = AppendFlagText(DictText(tags, txId), CellText(tagWs.Cells(r, 2).Value), " / ")
            UpdateSeverity severity, txId, CLng(NzDbl(tagWs.Cells(r, 3).Value, 0))
            evidence(txId) = AppendFlagText(DictText(evidence, txId), CellText(tagWs.Cells(r, 5).Value), " / ")
            actions(txId) = AppendFlagText(DictText(actions, txId), CellText(tagWs.Cells(r, 6).Value), " / ")
            people(txId) = AppendFlagText(DictText(people, txId), JoinNonBlank(CellText(tagWs.Cells(r, 7).Value), CellText(tagWs.Cells(r, 8).Value), " / "), " / ")
        End If
    Next r
End Sub

Private Function SeverityFromKind(ByVal kindText As String) As Long
    If kindText = KIND_UNKNOWN_COMBO Then
        SeverityFromKind = 4
    ElseIf kindText = KIND_UNKNOWN_OUT Or kindText = KIND_UNKNOWN_IN Then
        SeverityFromKind = 3
    ElseIf kindText = KIND_INHERITANCE_SHIFT Then
        SeverityFromKind = 4
    ElseIf kindText = KIND_SHIFT Then
        SeverityFromKind = 2
    Else
        SeverityFromKind = 1
    End If
End Function

Private Function SeverityFromScore(ByVal scoreValue As Double) As Long
    If scoreValue >= 90 Then
        SeverityFromScore = 5
    ElseIf scoreValue >= 75 Then
        SeverityFromScore = 4
    ElseIf scoreValue >= 60 Then
        SeverityFromScore = 3
    ElseIf scoreValue > 0 Then
        SeverityFromScore = 2
    Else
        SeverityFromScore = 0
    End If
End Function

Private Function ActionTextForKind(ByVal kindText As String) As String
    If kindText = KIND_UNKNOWN_COMBO Then
        ActionTextForKind = "�s���o���E�s�������t���O�����ŋ��z�g��������v�B���t�ɗ��炸�A�����E������E�Ǘ��ҁE�`�[���m�F"
    ElseIf kindText = KIND_UNKNOWN_OUT Then
        ActionTextForKind = "�s���o���̎g�r�A�茳�������A���`�O�Ǘ��A���^�����m�F"
    ElseIf kindText = KIND_UNKNOWN_IN Then
        ActionTextForKind = "�s�������̌����A�ԍρE�ݕt�E���^�E�������Y�������m�F"
    ElseIf kindText = KIND_INHERITANCE_SHIFT Then
        ActionTextForKind = "�����J�n�O��̎����ړ��Ƃ��āA�g�r�E��v�ҁE�Ǘ��ҁE�\�����f���m�F"
    Else
        ActionTextForKind = "�����E�ړ���E�Ǘ��ҁE�`�[���m�F"
    End If
End Function

Private Sub UpdateSeverity(ByVal severity As Object, ByVal txId As String, ByVal sevValue As Long)
    If Len(txId) = 0 Or sevValue <= 0 Then Exit Sub
    If severity.Exists(txId) Then
        If sevValue > CLng(severity(txId)) Then severity(txId) = sevValue
    Else
        severity(txId) = sevValue
    End If
End Sub

Private Function DictText(ByVal d As Object, ByVal keyText As String) As String
    If d Is Nothing Then Exit Function
    If Len(keyText) = 0 Then Exit Function
    If d.Exists(keyText) Then DictText = CellText(d(keyText))
End Function

Private Function DictLong(ByVal d As Object, ByVal keyText As String) As Long
    If d Is Nothing Then Exit Function
    If Len(keyText) = 0 Then Exit Function
    If d.Exists(keyText) Then DictLong = CLng(NzDbl(d(keyText), 0))
End Function

Private Function AppendFlagText(ByVal baseText As String, ByVal addText As String, Optional ByVal sep As String = " / ") As String
    baseText = Trim$(CStr(baseText))
    addText = Trim$(CStr(addText))
    If Len(addText) = 0 Then
        AppendFlagText = baseText
    ElseIf Len(baseText) = 0 Then
        AppendFlagText = addText
    ElseIf InStr(1, sep & baseText & sep, sep & addText & sep, vbTextCompare) > 0 Or InStr(1, baseText, addText, vbTextCompare) > 0 Then
        AppendFlagText = baseText
    Else
        AppendFlagText = baseText & sep & addText
    End If
End Function

Private Sub ApplyFlagColor(ByVal rng As Range, ByVal flagText As String)
    If InStr(flagText, KIND_UNKNOWN_COMBO) > 0 Then
        rng.Interior.Color = ThemeColor("purple-soft")
    ElseIf InStr(flagText, KIND_INHERITANCE_SHIFT) > 0 Or InStr(flagText, "����") > 0 Then
        rng.Interior.Color = ThemeColor("purple-soft")
    ElseIf InStr(flagText, "�C�x���g") > 0 Or InStr(flagText, "�A��") > 0 Or InStr(flagText, "�]��") > 0 Or InStr(flagText, "����") > 0 Or InStr(flagText, "�o��") > 0 Then
        rng.Interior.Color = ThemeColor("warning-soft")
    ElseIf InStr(flagText, "����") > 0 Or InStr(flagText, "������") > 0 Or InStr(flagText, "����") > 0 Or InStr(flagText, "�戵�X") > 0 Then
        rng.Interior.Color = ThemeColor("info-soft")
    ElseIf InStr(flagText, KIND_SHIFT) > 0 Then
        rng.Interior.Color = ThemeColor("info-soft")
    ElseIf InStr(flagText, KIND_UNKNOWN_IN) > 0 Then
        rng.Interior.Color = ThemeColor("warning-soft")
    ElseIf InStr(flagText, KIND_UNKNOWN_OUT) > 0 Then
        rng.Interior.Color = ThemeColor("orange-soft")
    ElseIf InStr(flagText, "���O") > 0 Then
        rng.Interior.Color = ThemeColor("locked")
    Else
        rng.Interior.Color = ThemeColor("locked")
    End If
End Sub


Public Sub BuildAnalysisAggregateWorkSheet()
    Dim ws As Worksheet, d As Object, k As Variant, item As Object, outR As Long
    If SheetExists(SH_WORK_AGG) Then
        Set ws = GetSheet(SH_WORK_AGG)
    Else
        Set ws = GetOrCreateSheet(SH_WORK_AGG, False)
    End If
    InitAnalysisAggregateHeaders ws, True
    Set d = CreateObject("Scripting.Dictionary")
    AddDetailAggregates d
    AddTagAggregates d
    outR = 2
    For Each k In d.Keys
        Set item = d(k)
        ws.Cells(outR, 1).Value = CStr(k)
        ws.Cells(outR, 2).Value = CStr(item("Axis"))
        ws.Cells(outR, 3).Value = CLng(item("Count"))
        ws.Cells(outR, 4).Value = CDbl(item("Amount"))
        ws.Cells(outR, 5).Value = CDbl(item("MaxAmount"))
        ws.Cells(outR, 6).Value = CStr(item("People"))
        ws.Cells(outR, 7).Value = CStr(item("TxIds"))
        ws.Cells(outR, 8).Value = CStr(item("Evidence"))
        ws.Cells(outR, 9).Value = CStr(item("Action"))
        ws.Cells(outR, 10).Value = Now
        outR = outR + 1
    Next k
    If outR > 2 Then
        FormatBody ws.Range("A2:J" & CStr(outR - 1))
        ws.Range("D:E").NumberFormatLocal = "#,##0"
        AutoFitSheetSmart ws, "A:J", 8, 60
    End If
End Sub

Private Sub AddDetailAggregates(ByVal d As Object)
    Dim ws As Worksheet, lastR As Long, r As Long, kindText As String, personText As String, txId As String, amt As Double
    If Not SheetExists(SH_WORK_DETAIL) Then Exit Sub
    Set ws = GetSheet(SH_WORK_DETAIL)
    lastR = LastRow(ws, DET_COL_ID)
    For r = 2 To lastR
        kindText = CellText(ws.Cells(r, DET_COL_KIND).Value)
        personText = CellText(ws.Cells(r, DET_COL_PERSON_NAME).Value)
        txId = CellText(ws.Cells(r, DET_COL_TX_ID).Value)
        amt = NzDbl(ws.Cells(r, DET_COL_AMOUNT).Value, 0)
        If Len(kindText) > 0 Then AddAggregateItem d, "���敪|" & kindText, "���͌��敪", 1, amt, personText, txId, kindText & "�̖��׏W��", "����敪�̎�������E���z�K�͂��m�F"
        If Len(personText) > 0 Then AddAggregateItem d, "�l��|" & personText, "�l���ʕ��͏W��", 1, amt, personText, txId, kindText, "�l���ʂɃt���O�W���A���`�Ǘ��A�C�x���g�A�����m�F"
    Next r
End Sub

Private Sub AddTagAggregates(ByVal d As Object)
    Dim ws As Worksheet, lastR As Long, r As Long, tagText As String, categoryText As String, peopleText As String, txId As String
    If Not SheetExists(SH_WORK_TX_TAG) Then Exit Sub
    Set ws = GetSheet(SH_WORK_TX_TAG)
    lastR = LastRow(ws, 1)
    For r = 2 To lastR
        txId = CellText(ws.Cells(r, 1).Value)
        tagText = CellText(ws.Cells(r, 2).Value)
        categoryText = CellText(ws.Cells(r, 4).Value)
        peopleText = CellText(ws.Cells(r, 7).Value)
        If Len(categoryText) > 0 Then AddAggregateItem d, "�^�O����|" & categoryText, "�^�O���ޏW��", 1, 0, peopleText, txId, CellText(ws.Cells(r, 5).Value), CellText(ws.Cells(r, 6).Value)
        If Len(tagText) > 0 Then AddAggregateItem d, "�^�O|" & tagText, "�^�O�ʏW��", 1, 0, peopleText, txId, CellText(ws.Cells(r, 5).Value), CellText(ws.Cells(r, 6).Value)
    Next r
End Sub

Private Sub AddAggregateItem(ByVal d As Object, ByVal keyText As String, ByVal axisText As String, ByVal countValue As Long, ByVal amountValue As Double, ByVal peopleText As String, ByVal txId As String, ByVal evidenceText As String, ByVal actionText As String)
    Dim item As Object
    If Len(keyText) = 0 Then Exit Sub
    If d.Exists(keyText) Then
        Set item = d(keyText)
    Else
        Set item = CreateObject("Scripting.Dictionary")
        item("Axis") = axisText
        item("Count") = 0
        item("Amount") = 0#
        item("MaxAmount") = 0#
        item("People") = ""
        item("TxIds") = ""
        item("Evidence") = ""
        item("Action") = ""
        d.Add keyText, item
    End If
    item("Count") = CLng(item("Count")) + countValue
    item("Amount") = CDbl(item("Amount")) + amountValue
    If amountValue > CDbl(item("MaxAmount")) Then item("MaxAmount") = amountValue
    item("People") = AppendAggregateText(CStr(item("People")), peopleText, " / ", 240)
    item("TxIds") = AppendAggregateText(CStr(item("TxIds")), txId, ",", 260)
    item("Evidence") = AppendAggregateText(CStr(item("Evidence")), evidenceText, " / ", 360)
    item("Action") = AppendAggregateText(CStr(item("Action")), actionText, " / ", 360)
End Sub

Private Function AppendAggregateText(ByVal baseText As String, ByVal addText As String, ByVal sep As String, ByVal maxLen As Long) As String
    addText = Trim$(addText)
    If Len(addText) = 0 Then
        AppendAggregateText = baseText
    ElseIf Len(baseText) = 0 Then
        AppendAggregateText = addText
    ElseIf InStr(1, sep & baseText & sep, sep & addText & sep, vbTextCompare) > 0 Then
        AppendAggregateText = baseText
    ElseIf Len(baseText) + Len(sep) + Len(addText) <= maxLen Then
        AppendAggregateText = baseText & sep & addText
    Else
        AppendAggregateText = baseText
    End If
End Function

Public Sub BuildDetailOutputSheet()
    Dim src As Worksheet, dst As Worksheet, lastR As Long
    Set src = GetSheet(SH_WORK_DETAIL)
    Set dst = GetSheet(SH_DETAIL)
    On Error Resume Next
    dst.Unprotect Password:=TOOL_PASSWORD
    dst.Cells.UnMerge
    dst.Cells.Clear
    DeleteAllShapes dst
    On Error GoTo 0

    lastR = LastRow(src, 1)
    dst.Range("A1:Q" & CStr(Application.Max(1, lastR))).Value = src.Range("A1:Q" & CStr(Application.Max(1, lastR))).Value
    FormatHeader dst.Range("A1:Q1"), ThemeColor("header")
    If lastR >= 2 Then
        FormatBody dst.Range("A2:Q" & CStr(lastR))
        dst.Range("E2:E" & CStr(lastR)).NumberFormatLocal = "yyyy/m/d"
        dst.Range("F2:F" & CStr(lastR)).NumberFormatLocal = "#,##0"
    End If
    dst.Range("A1:Q1").AutoFilter
    AutoFitSheetSmart dst, "A:Q", 6, 34
    ThemeApplyPrintTable dst.Range("A1:Q" & CStr(Application.Max(1, lastR))), 1
    ThemeCapRowHeights dst.Range("A2:Q" & CStr(Application.Max(2, lastR))), 20, 72
    ThemeApplyMonochromePrint dst, dst.Range("A1:Q" & CStr(Application.Max(1, lastR))).Address, True, "$1:$1", 1, 0
    ProtectOutputSheet dst
End Sub

Public Sub BuildAllVisibleOutputs()
    '�����A�g�p�̌��ʁE���ׁE�_�_�͍�邪�A���[�U�[�Ɍ������ʂ̓^�O�t����������\�ƃt���O���o�����B
    BuildAnalysisResultSheet
    BuildDetailOutputSheet
    BuildInvestigationIssueSheet True
    BuildAnalysisAggregateWorkSheet
    BuildFlaggedTransactionSheet
    BuildFlagExtractSheet
    ShowOutputSheets
End Sub

Private Sub ProtectOutputSheet(ByVal ws As Worksheet)
    On Error Resume Next
    ThemePrepareSheetForProtection ws
    ws.Protect Password:=TOOL_PASSWORD, UserInterfaceOnly:=True, DrawingObjects:=True, Contents:=True, Scenarios:=True, AllowFiltering:=True, AllowSorting:=True
    ws.EnableSelection = xlNoRestrictions
    On Error GoTo 0
End Sub

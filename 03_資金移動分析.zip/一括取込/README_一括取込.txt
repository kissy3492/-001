03資金移動分析 一括取込

目的:
- 03の標準モジュール、ThisWorkbookコード、分析入力シートコードをまとめて入れ替えます。
- 手作業インポート漏れによる「SubまたはFunctionが定義されていません」を減らすための導入用です。

使い方:
1. 対象の03 .xlsmを閉じます。
2. IMPORT_03_MODULES.bat に対象 .xlsm をドラッグ＆ドロップします。
3. 自動バックアップを作成します。
4. 標準モジュール、ThisWorkbook、分析入力シートコードを入れ替えます。
5. SetupWorkbook、RefreshAnalysisButtonActions、RunToolSelfCheck False を実行します。

Excel側で必要な設定:
- Excelの「VBAプロジェクト オブジェクトモデルへのアクセスを信頼する」を有効にしてください。
- 無効のままだとExcelがVBAコードの一括入替を拒否します。

注意:
- 実行後はVBEでコンパイルしてください。
- 既存ボタンのOnActionがずれている場合は、RefreshAnalysisButtonActionsが補正します。
- レイアウトや表示シート状態が崩れている場合は、SetupWorkbookまたはRepairToolNowを実行してください。

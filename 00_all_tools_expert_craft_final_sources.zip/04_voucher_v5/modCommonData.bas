Attribute VB_Name = "modCommonData"
Option Explicit

Public Sub LoadCommonData()
    On Error GoTo EH
    AppBegin "���ʃf�[�^��ǂݍ��ݒ�..."
    Dim p As String
    p = CommonDataPath()
    If Dir(p) = vbNullString Then Err.Raise vbObjectError + 201, , COMMON_DATA_FILE & " ��������܂���B"

    Dim wb As Workbook
    Set wb = Workbooks.Open(Filename:=p, ReadOnly:=True, UpdateLinks:=False, IgnoreReadOnlyRecommended:=True, Notify:=False, AddToMru:=False)
    ImportVoucherCandidates wb
    wb.Close SaveChanges:=False
    BuildDestinationMaster
    RefreshDestinationList
    UpdateMainStatus
    WriteLog "���ʃf�[�^�Ǎ�����"
    AppEnd ""
    MsgBox "�`�[�˗�����ǂݍ��݂܂����B�˗���m�F�֐i��ł��������B", vbInformation
    Exit Sub
EH:
    On Error Resume Next
    If Not wb Is Nothing Then wb.Close SaveChanges:=False
    AppEnd ""
    RuntimeShowError "LoadCommonData", "���ʃf�[�^�Ǎ�", "���̓c�[�����ŋ��ʃf�[�^�ۑ��ς݂��AT_�`�[��₪���݂��邩�m�F���Ă��������B"
End Sub

Private Sub ImportVoucherCandidates(ByVal srcWb As Workbook)
    If Not SheetExists(SRC_VOUCHER, srcWb) Then
        Err.Raise vbObjectError + 202, , SRC_VOUCHER & " ������܂���B���̓c�[���ŋ��ʃf�[�^�ۑ������s���Ă��������B"
    End If
    Dim src As Worksheet, dst As Worksheet
    Set src = srcWb.Worksheets(SRC_VOUCHER)
    Set dst = Ws(SH_W_CAND)
    ClearSheetKeepHeader dst

    Dim headers As Object
    Set headers = HeaderDictionary(src, 1)

    Dim cVoucherID As Long, cTxID As Long, cTxDateCol As Long, cBank As Long, cShop As Long, cBranch As Long
    Dim cPersonID As Long, cPerson As Long, cRel As Long, cKind As Long, cOut As Long, cIn As Long
    Dim cSummary As Long, cVoucher As Long, cAdopt As Long, cAnalysis As Long, cDetail As Long, cMemo As Long
    cVoucherID = FindHeader(headers, "�`�[���ID", "�˗����ID")
    cTxID = FindHeader(headers, "���ID", "TxID", "TX_ID")
    cTxDateCol = FindHeader(headers, "�˗��Ώۓ�", "�����", "���t", "�������")
    cBank = FindHeader(headers, "��s��", "��s")
    cShop = FindHeader(headers, "�戵�X�m��l", "�戵�X", "�戵�X�\��", "�˗���戵�X")
    cBranch = FindHeader(headers, "�x�X��", "�x�X")
    cPersonID = FindHeader(headers, "�l��ID")
    cPerson = FindHeader(headers, "�l����", "����", "���`�l")
    cRel = FindHeader(headers, "����", "�֌W")
    cKind = FindHeader(headers, "�敪", "���͋敪")
    cOut = FindHeader(headers, "�o��", "�o���z")
    cIn = FindHeader(headers, "����", "�����z")
    cSummary = FindHeader(headers, "�E�v", "�v�_", "���e", "�����E�v")
    cVoucher = FindHeader(headers, "�`�[�˗�", "�`�[", "�`�[�˗��t���O")
    cAdopt = FindHeader(headers, "�̗p", "�V�t�g�̗p", "���f")
    cAnalysis = FindHeader(headers, "���͌��ID", "���ID")
    cDetail = FindHeader(headers, "���͖���ID", "����ID")
    cMemo = FindHeader(headers, "����", "���̓���")

    If cTxDateCol = 0 Or cBank = 0 Or cShop = 0 Then
        Err.Raise vbObjectError + 203, , "T_�`�[�˗����Ɏ�����E��s���E�戵�X�̗񂪕K�v�ł��B"
    End If

    Dim lr As Long, r As Long, outR As Long, target As Boolean
    lr = LastRow(src, 1)
    outR = 2
    For r = 2 To lr
        target = True
        If cVoucher > 0 Then target = (Nz(src.Cells(r, cVoucher).Value) = "�v")
        If cAdopt > 0 Then
            If InStr(Nz(src.Cells(r, cAdopt).Value), "���O") > 0 Then target = False
        End If
        If target Then
            dst.Cells(outR, VC_ID).Value = GetCellText(src, r, cVoucherID)
            If Len(Nz(dst.Cells(outR, VC_ID).Value)) = 0 Then dst.Cells(outR, VC_ID).Value = "VR" & Format$(outR - 1, "000000")
            dst.Cells(outR, VC_ANALYSIS_ID).Value = GetCellText(src, r, cAnalysis)
            dst.Cells(outR, VC_DETAIL_ID).Value = GetCellText(src, r, cDetail)
            dst.Cells(outR, VC_TX_ID).Value = GetCellText(src, r, cTxID)
            dst.Cells(outR, VC_TX_DATE).Value = GetCellValue(src, r, cTxDateCol)
            dst.Cells(outR, VC_BANK).Value = GetCellText(src, r, cBank)
            dst.Cells(outR, VC_BRANCH).Value = GetCellText(src, r, cBranch)
            dst.Cells(outR, VC_SHOP).Value = GetCellText(src, r, cShop)
            dst.Cells(outR, VC_PERSON_ID).Value = GetCellText(src, r, cPersonID)
            dst.Cells(outR, VC_PERSON_NAME).Value = GetCellText(src, r, cPerson)
            dst.Cells(outR, VC_RELATION).Value = GetCellText(src, r, cRel)
            dst.Cells(outR, VC_KIND).Value = GetCellText(src, r, cKind)
            dst.Cells(outR, VC_OUT).Value = GetCellValue(src, r, cOut)
            dst.Cells(outR, VC_IN).Value = GetCellValue(src, r, cIn)
            dst.Cells(outR, VC_SUMMARY).Value = GetCellText(src, r, cSummary)
            dst.Cells(outR, VC_VOUCHER).Value = "�v"
            dst.Cells(outR, VC_ADOPT).Value = IIf(cAdopt > 0, GetCellText(src, r, cAdopt), "�̗p")
            dst.Cells(outR, VC_TARGET).Value = "�v"
            dst.Cells(outR, VC_MEMO).Value = GetCellText(src, r, cMemo)
            dst.Cells(outR, VC_DEST_KEY).Value = DestKey(dst.Cells(outR, VC_BANK).Value, dst.Cells(outR, VC_SHOP).Value)
            dst.Cells(outR, VC_STATUS).Value = "�L��"
            outR = outR + 1
        End If
    Next r
    dst.Columns(VC_TX_DATE).NumberFormatLocal = "yyyy/m/d"
    dst.Columns(VC_OUT).NumberFormat = "#,##0"
    dst.Columns(VC_IN).NumberFormat = "#,##0"
End Sub

Private Function HeaderDictionary(ByVal sh As Worksheet, ByVal headerRow As Long) As Object
    Dim d As Object, c As Long, lc As Long, h As String
    Set d = CreateObject("Scripting.Dictionary")
    lc = LastCol(sh, headerRow)
    For c = 1 To lc
        h = CleanKey(Nz(sh.Cells(headerRow, c).Value))
        If Len(h) > 0 Then
            If Not d.Exists(h) Then d.Add h, c
        End If
    Next c
    Set HeaderDictionary = d
End Function

Private Function FindHeader(ByVal dict As Object, ParamArray names() As Variant) As Long
    Dim i As Long, k As String
    For i = LBound(names) To UBound(names)
        k = CleanKey(CStr(names(i)))
        If dict.Exists(k) Then
            FindHeader = CLng(dict(k))
            Exit Function
        End If
    Next i
    FindHeader = 0
End Function

Private Function GetCellText(ByVal sh As Worksheet, ByVal r As Long, ByVal c As Long) As String
    If c <= 0 Then GetCellText = "" Else GetCellText = Nz(sh.Cells(r, c).Value)
End Function

Private Function GetCellValue(ByVal sh As Worksheet, ByVal r As Long, ByVal c As Long) As Variant
    If c <= 0 Then GetCellValue = Empty Else GetCellValue = sh.Cells(r, c).Value
End Function

Private Sub ClearSheetKeepHeader(ByVal sh As Worksheet)
    Dim lr As Long
    lr = LastRow(sh, 1)
    If lr >= 2 Then sh.Range(sh.Rows(2), sh.Rows(lr)).ClearContents
End Sub

Public Sub BuildDestinationMaster()
    Dim src As Worksheet, dst As Worksheet, dict As Object, r As Long, lr As Long, key As String
    Dim keepTarget As Object, oldR As Long
    Set src = Ws(SH_W_CAND)
    Set dst = Ws(SH_W_DEST)
    Set keepTarget = CreateObject("Scripting.Dictionary")
    For oldR = 2 To LastRow(dst, DS_ID)
        If Len(Nz(dst.Cells(oldR, DS_KEY).Value)) > 0 Then keepTarget(dst.Cells(oldR, DS_KEY).Value) = Nz(dst.Cells(oldR, DS_TARGET).Value, "�쐬")
    Next oldR
    ClearSheetKeepHeader dst
    Set dict = CreateObject("Scripting.Dictionary")
    lr = LastRow(src, 1)
    Dim destR As Long
    destR = 2
    For r = 2 To lr
        If Nz(src.Cells(r, VC_TARGET).Value) = "�v" Then
            key = Nz(src.Cells(r, VC_DEST_KEY).Value)
            If Len(key) = 0 Then key = DestKey(src.Cells(r, VC_BANK).Value, src.Cells(r, VC_SHOP).Value)
            If Not dict.Exists(key) Then
                dict.Add key, destR
                dst.Cells(destR, DS_ID).Value = "VD" & Format$(destR - 1, "0000")
                dst.Cells(destR, DS_KEY).Value = key
                dst.Cells(destR, DS_BANK).Value = src.Cells(r, VC_BANK).Value
                dst.Cells(destR, DS_SHOP).Value = src.Cells(r, VC_SHOP).Value
                If keepTarget.Exists(key) Then
                    dst.Cells(destR, DS_TARGET).Value = keepTarget(key)
                Else
                    dst.Cells(destR, DS_TARGET).Value = "�쐬"
                End If
                dst.Cells(destR, DS_REQ_SHEET).Value = SafeSheetName(dst.Cells(destR, DS_ID).Value & "_" & src.Cells(r, VC_BANK).Value & "_" & src.Cells(r, VC_SHOP).Value, "�˗�_")
                dst.Cells(destR, DS_CTL_SHEET).Value = SafeSheetName(dst.Cells(destR, DS_ID).Value & "_" & src.Cells(r, VC_BANK).Value & "_" & src.Cells(r, VC_SHOP).Value, "�T��_")
                destR = destR + 1
            End If
        End If
    Next r
    UpdateDestinationCounts
End Sub

Public Sub UpdateDestinationCounts()
    Dim cand As Worksheet, dest As Worksheet, r As Long, lr As Long, dr As Long, dlr As Long
    Dim key As String, dRows As Object, dateDict As Object
    Set cand = Ws(SH_W_CAND)
    Set dest = Ws(SH_W_DEST)
    Set dRows = CreateObject("Scripting.Dictionary")
    dlr = LastRow(dest, DS_ID)
    For dr = 2 To dlr
        dRows(dest.Cells(dr, DS_KEY).Value) = dr
        dest.Cells(dr, DS_TX_COUNT).Value = 0
        dest.Cells(dr, DS_TX_DATE_COUNT).Value = 0
    Next dr
    Set dateDict = CreateObject("Scripting.Dictionary")
    lr = LastRow(cand, VC_ID)
    For r = 2 To lr
        If Nz(cand.Cells(r, VC_TARGET).Value) = "�v" Then
            key = cand.Cells(r, VC_DEST_KEY).Value
            If dRows.Exists(key) Then
                dr = dRows(key)
                dest.Cells(dr, DS_TX_COUNT).Value = NzDbl(dest.Cells(dr, DS_TX_COUNT).Value) + 1
                If IsDate(cand.Cells(r, VC_TX_DATE).Value) Then dateDict(key & "|" & CLng(CDate(cand.Cells(r, VC_TX_DATE).Value))) = 1
            End If
        End If
    Next r
    Dim k As Variant, parts As Variant
    For Each k In dateDict.Keys
        parts = Split(CStr(k), "|")
        If dRows.Exists(parts(0)) Then
            dr = dRows(parts(0))
            dest.Cells(dr, DS_TX_DATE_COUNT).Value = NzDbl(dest.Cells(dr, DS_TX_DATE_COUNT).Value) + 1
        End If
    Next k
End Sub

Public Sub RefreshDestinationList()
    Dim sh As Worksheet, src As Worksheet, r As Long, lr As Long, outR As Long
    Set sh = Ws(SH_DEST_LIST)
    Set src = Ws(SH_W_DEST)
    ClearSheetSafe sh
    sh.Cells.Font.Name = "Meiryo UI"
    sh.Cells.Font.Size = 10
    sh.Columns("A").ColumnWidth = 12
    sh.Columns("B").ColumnWidth = 22
    sh.Columns("C").ColumnWidth = 24
    sh.Columns("D").ColumnWidth = 12
    sh.Columns("E").ColumnWidth = 12
    sh.Columns("F").ColumnWidth = 12
    sh.Columns("G").ColumnWidth = 26
    sh.Columns("H").ColumnWidth = 26
    sh.Columns("I").ColumnWidth = 28
    sh.Rows.RowHeight = 21

    sh.Range("A1:I1").Merge
    With sh.Range("A1")
        .Value = "�˗���ꗗ�i��s���{�戵�X���ƂɈ˗��p�E�T���p��1�Z�b�g�쐬�j"
        .Interior.Color = C_DARK
        .Font.Color = vbWhite
        .Font.Bold = True
        .Font.Size = 14
        .HorizontalAlignment = xlCenter
    End With
    sh.Range("A2:I2").Merge
    With sh.Range("A2")
        .Value = "F����_�u���N���b�N����ƍ쐬/���O��ؑցB�˗��p�V�[�g�E�T���p�V�[�g�͕K���˗���P�ʂŕ�����܂��B�����˗���𓯂��˗��\�ɍ��݂����܂���B"
        .Interior.Color = C_LIGHT_BLUE
        .Font.Bold = True
        .Font.Color = C_DARK
        .WrapText = True
    End With
    sh.Range("A4:I4").Value = Array("�˗���ID", "��s��", "�戵�X", "�Ώێ������", "�˗�����", "�쐬�Ώ�", "�˗��p�V�[�g", "�T���p�V�[�g", "����")
    sh.Range("A4:I4").Interior.Color = C_NAVY
    sh.Range("A4:I4").Font.Color = vbWhite
    sh.Range("A4:I4").Font.Bold = True
    sh.Range("A4:I4").HorizontalAlignment = xlCenter

    lr = LastRow(src, DS_ID)
    outR = 5
    For r = 2 To lr
        sh.Cells(outR, 1).Value = src.Cells(r, DS_ID).Value
        sh.Cells(outR, 2).Value = src.Cells(r, DS_BANK).Value
        sh.Cells(outR, 3).Value = src.Cells(r, DS_SHOP).Value
        sh.Cells(outR, 4).Value = src.Cells(r, DS_TX_COUNT).Value
        sh.Cells(outR, 5).Value = src.Cells(r, DS_REQUEST_DATE_COUNT).Value
        sh.Cells(outR, 6).Value = src.Cells(r, DS_TARGET).Value
        sh.Cells(outR, 7).Value = src.Cells(r, DS_REQ_SHEET).Value
        sh.Cells(outR, 8).Value = src.Cells(r, DS_CTL_SHEET).Value
        sh.Cells(outR, 9).Value = src.Cells(r, DS_MEMO).Value
        If outR Mod 2 = 0 Then sh.Range(sh.Cells(outR, 1), sh.Cells(outR, 9)).Interior.Color = ThemeColor("canvas")
        outR = outR + 1
    Next r
    With sh.Range("A4:I" & Application.Max(outR - 1, 5))
        .VerticalAlignment = xlCenter
        .WrapText = True
    End With
    sh.Range("F5:F" & Application.Max(outR - 1, 5)).Validation.Delete
    sh.Range("F5:F" & Application.Max(outR - 1, 5)).Validation.Add Type:=xlValidateList, AlertStyle:=xlValidAlertStop, Formula1:="�쐬,���O"
    AddButton sh, "���͉�ʂ�", "ShowNormalMode", 20, 20, 110, 30, ThemeColor("muted")
    AddButton sh, "�˗��\�쐬", "BuildVoucherSheets", 145, 20, 110, 30, C_ORANGE
    ApplyDestinationListProtection
    ActiveWindow.DisplayGridlines = False
End Sub

Public Sub UpdateMainStatus()
    Dim m As Worksheet
    Set m = Ws(SH_MAIN)
    m.Range("C8").Value = IIf(Dir(CommonDataPath()) = vbNullString, "�����o", "�Ǎ���")
    m.Range("C9").Value = Application.Max(LastRow(Ws(SH_W_CAND), 1) - 1, 0) & "��"
    m.Range("C10").Value = Application.Max(LastRow(Ws(SH_W_DEST), 1) - 1, 0) & "��"
    m.Range("C11").Value = Application.Max(LastRow(Ws(SH_W_DATES), 1) - 1, 0) & "��"
    m.Range("C12").Value = Application.Max(LastRow(Ws(SH_W_CONTROL), 1) - 1, 0) & "��"
    m.Range("C13").Value = HolidayCoverageStatusText()
End Sub

Public Sub ShowDestinationList()
    RefreshDestinationList
    ApplyDestinationListProtection
    ShowAfterBuild
    Ws(SH_DEST_LIST).Visible = xlSheetVisible
    Ws(SH_DEST_LIST).Activate
End Sub

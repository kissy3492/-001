Attribute VB_Name = "modApp"
Option Explicit

Private gDepth As Long
Private gScreenUpdating As Boolean
Private gEnableEvents As Boolean
Private gDisplayAlerts As Boolean
Private gCalculation As XlCalculation
Private gStatusBar As Variant

Public Sub AppBegin(Optional ByVal message As String = "")
    If gDepth = 0 Then
        gScreenUpdating = Application.ScreenUpdating
        gEnableEvents = Application.EnableEvents
        gDisplayAlerts = Application.DisplayAlerts
        gCalculation = Application.Calculation
        gStatusBar = Application.StatusBar
        Application.ScreenUpdating = False
        Application.EnableEvents = False
        Application.DisplayAlerts = False
        Application.Calculation = xlCalculationManual
    End If
    gDepth = gDepth + 1
    If Len(message) > 0 Then Application.StatusBar = message
End Sub

Public Sub AppEnd(Optional ByVal message As String = "")
    If gDepth > 0 Then gDepth = gDepth - 1
    If Len(message) > 0 Then Application.StatusBar = message
    If gDepth = 0 Then
        Application.ScreenUpdating = gScreenUpdating
        Application.EnableEvents = gEnableEvents
        Application.DisplayAlerts = gDisplayAlerts
        Application.Calculation = gCalculation
        Application.StatusBar = gStatusBar
    End If
End Sub

Public Sub AppForceRestore()
    '�G���[���f�E�I�����ً̋}�����B
    On Error Resume Next
    gDepth = 0
    Application.ScreenUpdating = True
    Application.EnableEvents = True
    Application.DisplayAlerts = True
    Application.Calculation = xlCalculationAutomatic
    Application.StatusBar = False
    On Error GoTo 0
End Sub

Public Function CaseFolder() As String
    If Len(ThisWorkbook.Path) = 0 Then
        Err.Raise vbObjectError + 101, , "���̃c�[�����Č��t�H���_�ɕۑ����Ă�����s���Ă��������B"
    End If
    CaseFolder = ThisWorkbook.Path
End Function

Public Function CommonDataPath() As String
    CommonDataPath = RuntimeCombinePath(CaseFolder(), COMMON_DATA_FILE)
End Function

Public Function OutputPath() As String
    Dim p As String
    p = RuntimeCombinePath(CaseFolder(), OUTPUT_FOLDER)
    RuntimeEnsureFolderExists p, "OutputPath"
    OutputPath = p
End Function

Public Function Ws(ByVal sheetName As String) As Worksheet
    Set Ws = ThisWorkbook.Worksheets(sheetName)
End Function

Public Function SheetExists(ByVal sheetName As String, Optional ByVal wb As Workbook) As Boolean
    Dim t As Worksheet
    If wb Is Nothing Then Set wb = ThisWorkbook
    On Error Resume Next
    Set t = wb.Worksheets(sheetName)
    SheetExists = Not t Is Nothing
    On Error GoTo 0
End Function

Public Function GetOrCreateSheet(ByVal sheetName As String, Optional ByVal wb As Workbook) As Worksheet
    If wb Is Nothing Then Set wb = ThisWorkbook
    If SheetExists(sheetName, wb) Then
        Set GetOrCreateSheet = wb.Worksheets(sheetName)
    Else
        Set GetOrCreateSheet = wb.Worksheets.Add(After:=wb.Worksheets(wb.Worksheets.Count))
        GetOrCreateSheet.Name = sheetName
    End If
End Function

Public Sub ClearSheetSafe(ByVal sh As Worksheet)
    On Error Resume Next
    sh.Unprotect Password:=TOOL_PASSWORD
    If Err.Number <> 0 Then Err.Clear: sh.Unprotect
    If sh.AutoFilterMode Then sh.AutoFilterMode = False
    Dim lo As ListObject
    For Each lo In sh.ListObjects
        lo.Unlist
    Next lo
    sh.Cells.Clear
    Dim shp As Shape
    For Each shp In sh.Shapes
        shp.Delete
    Next shp
    On Error GoTo 0
End Sub

Public Function LastRow(ByVal sh As Worksheet, Optional ByVal col As Long = 1) As Long
    LastRow = sh.Cells(sh.Rows.Count, col).End(xlUp).Row
    If LastRow < 1 Then LastRow = 1
End Function

Public Function LastCol(ByVal sh As Worksheet, Optional ByVal rowNum As Long = 1) As Long
    LastCol = sh.Cells(rowNum, sh.Columns.Count).End(xlToLeft).Column
    If LastCol < 1 Then LastCol = 1
End Function

Public Function Nz(ByVal v As Variant, Optional ByVal defaultValue As String = "") As String
    If IsError(v) Or IsNull(v) Or IsEmpty(v) Then
        Nz = defaultValue
    Else
        Nz = CStr(v)
    End If
End Function

Public Function NzDbl(ByVal v As Variant) As Double
    If IsNumeric(v) Then NzDbl = CDbl(v) Else NzDbl = 0
End Function

Public Function CleanKey(ByVal s As String) As String
    s = Replace(s, " ", "")
    s = Replace(s, "�@", "")
    s = Replace(s, vbCr, "")
    s = Replace(s, vbLf, "")
    CleanKey = Trim$(s)
End Function

Public Function DestKey(ByVal bank As String, ByVal shop As String) As String
    DestKey = CleanKey(bank) & "||" & CleanKey(shop)
End Function

Public Function SafeSheetName(ByVal s As String, Optional ByVal prefix As String = "") As String
    Dim bad As Variant, i As Long
    s = prefix & s
    bad = Array("/", "\", "?", "*", "[", "]", ":")
    For i = LBound(bad) To UBound(bad)
        s = Replace(s, CStr(bad(i)), "_")
    Next i
    s = Replace(s, " ", "")
    s = Replace(s, "�@", "")
    If Len(s) = 0 Then s = "�˗���"
    If Len(s) > 31 Then s = Left$(s, 31)
    SafeSheetName = s
End Function

Public Function FormatJPDate(ByVal d As Date, Optional ByVal withWeekday As Boolean = True) As String
    Dim y As Long, era As String, ey As Long
    y = Year(d)
    Select Case d
        Case Is >= DateSerial(2019, 5, 1)
            era = "�ߘa": ey = y - 2018
        Case Is >= DateSerial(1989, 1, 8)
            era = "����": ey = y - 1988
        Case Is >= DateSerial(1926, 12, 25)
            era = "���a": ey = y - 1925
        Case Else
            era = "����": ey = y
    End Select
    If era = "����" Then
        FormatJPDate = Format$(d, "yyyy�Nm��d��")
    ElseIf ey = 1 Then
        FormatJPDate = era & "���N" & Month(d) & "��" & Day(d) & "��"
    Else
        FormatJPDate = era & ey & "�N" & Month(d) & "��" & Day(d) & "��"
    End If
    If withWeekday Then FormatJPDate = FormatJPDate & "�i" & WeekdayNameJP(Weekday(d, vbSunday)) & "�j"
End Function

Public Function WeekdayNameJP(ByVal n As Long) As String
    Dim a As Variant
    a = Array("��", "��", "��", "��", "��", "��", "�y")
    WeekdayNameJP = a(n - 1)
End Function

Public Function NumberText(ByVal v As Variant) As String
    If IsNumeric(v) And CDbl(v) <> 0 Then
        NumberText = Format$(CDbl(v), "#,##0")
    Else
        NumberText = ""
    End If
End Function

Public Function SafeFileName(ByVal s As String, Optional ByVal defaultName As String = "�˗���") As String
    Dim bad As Variant, i As Long
    bad = Array("/", "\", "?", "*", "[", "]", ":", Chr$(34), "<", ">", "|")
    For i = LBound(bad) To UBound(bad)
        s = Replace(s, CStr(bad(i)), "_")
    Next i
    s = Replace(s, vbCr, "")
    s = Replace(s, vbLf, "")
    s = Trim$(s)
    If Len(s) = 0 Then s = defaultName
    If Len(s) > 120 Then s = Left$(s, 120)
    SafeFileName = s
End Function

Public Sub WriteLog(ByVal message As String, Optional ByVal level As String = "INFO")
    Dim sh As Worksheet, r As Long
    Set sh = GetOrCreateSheet(SH_W_LOG)
    If sh.Cells(1, 1).Value = "" Then sh.Range("A1:D1").Value = Array("����", "�敪", "����", "���e")
    r = LastRow(sh, 1) + 1
    sh.Cells(r, 1).Value = Now
    sh.Cells(r, 2).Value = level
    sh.Cells(r, 3).Value = Application.Caller
    sh.Cells(r, 4).Value = message
End Sub

Public Sub ShowNormalMode()
    Dim sh As Worksheet
    If SheetExists(SH_MAIN) Then
        Ws(SH_MAIN).Visible = xlSheetVisible
        Ws(SH_MAIN).Activate
    End If
    For Each sh In ThisWorkbook.Worksheets
        If sh.Name = SH_MAIN Then
            sh.Visible = xlSheetVisible
        Else
            sh.Visible = xlSheetVeryHidden
        End If
    Next sh
    RepairVoucherMainLayout Ws(SH_MAIN)
    ApplyVoucherInputProtection
    Ws(SH_MAIN).Activate
End Sub

Public Sub ShowSettings()
    Dim sh As Worksheet
    For Each sh In ThisWorkbook.Worksheets
        If sh.Name = SH_MAIN Or sh.Name = SH_SETTINGS Then
            sh.Visible = xlSheetVisible
        Else
            sh.Visible = xlSheetVeryHidden
        End If
    Next sh
    ApplySettingsProtection
    Ws(SH_SETTINGS).Activate
End Sub

Public Sub ShowAfterBuild()
    Dim sh As Worksheet, firstSet As Worksheet
    If SheetExists(SH_MAIN) Then
        Ws(SH_MAIN).Visible = xlSheetVisible
        Ws(SH_MAIN).Activate
    End If
    If SheetExists(SH_DEST_LIST) Then Ws(SH_DEST_LIST).Visible = xlSheetVisible
    For Each sh In ThisWorkbook.Worksheets
        If sh.Name = SH_MAIN Or sh.Name = SH_DEST_LIST Or IsVoucherSetSheetName(sh.Name) Then
            sh.Visible = xlSheetVisible
            If firstSet Is Nothing And IsVoucherSetSheetName(sh.Name) Then Set firstSet = sh
        Else
            sh.Visible = xlSheetVeryHidden
        End If
    Next sh
    If Not firstSet Is Nothing Then
        firstSet.Activate
    ElseIf SheetExists(SH_DEST_LIST) Then
        Ws(SH_DEST_LIST).Activate
    ElseIf SheetExists(SH_MAIN) Then
        Ws(SH_MAIN).Activate
    End If
End Sub

Public Sub ProtectOutputSheets()
    Dim nm As Variant, sh As Worksheet
    If SheetExists(SH_DEST_LIST) Then ApplyDestinationListProtection
    For Each nm In Array(SH_REQUEST, SH_CONTROL, SH_CHECK)
        If SheetExists(CStr(nm)) Then
            Set sh = Ws(CStr(nm))
            ProtectSheetReadOnly sh
        End If
    Next nm
    For Each sh In ThisWorkbook.Worksheets
        If IsVoucherSetSheetName(sh.Name) Then ProtectSheetReadOnly sh
    Next sh
End Sub

Public Sub ProtectSheetReadOnly(ByVal sh As Worksheet)
    If sh Is Nothing Then Exit Sub
    On Error Resume Next
    sh.Unprotect Password:=TOOL_PASSWORD
    If Err.Number <> 0 Then Err.Clear: sh.Unprotect
    sh.Cells.Locked = True
    ThemePrepareSheetForProtection sh
    sh.Protect Password:=TOOL_PASSWORD, UserInterfaceOnly:=True, DrawingObjects:=True, Contents:=True, Scenarios:=True, AllowFiltering:=True
    sh.EnableSelection = xlNoRestrictions
    ThemeMarkMacroButtonsNonPrintable sh
    On Error GoTo 0
End Sub

Public Function IsVoucherSetSheetName(ByVal sheetName As String) As Boolean
    IsVoucherSetSheetName = (Left$(sheetName, 3) = "�˗�_" Or Left$(sheetName, 3) = "�T��_")
End Function

Public Function ColumnLetter(ByVal colNum As Long) As String
    ColumnLetter = Split(Cells(1, colNum).Address(False, False), "1")(0)
End Function

Public Sub CapColumns(ByVal sh As Worksheet, ByVal fromCol As Long, ByVal toCol As Long, ByVal maxWidth As Double)
    Dim c As Long
    For c = fromCol To toCol
        If sh.Columns(c).ColumnWidth > maxWidth Then sh.Columns(c).ColumnWidth = maxWidth
    Next c
End Sub

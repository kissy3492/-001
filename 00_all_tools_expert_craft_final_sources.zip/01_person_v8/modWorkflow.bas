Attribute VB_Name = "modWorkflow"
Option Explicit

Public Sub BeginDecedentEntry()
    PrepareInput MODE_DECEDENT
End Sub
Public Sub BeginAddSpouse()
    PrepareInput MODE_SPOUSE
End Sub
Public Sub BeginAddFather()
    PrepareInput MODE_FATHER
End Sub
Public Sub BeginAddMother()
    PrepareInput MODE_MOTHER
End Sub
Public Sub BeginAddChild()
    PrepareInput MODE_CHILD
End Sub
Public Sub BeginAddSibling()
    PrepareInput MODE_SIBLING
End Sub
Public Sub BeginAddGrandchild()
    PrepareInput MODE_GRANDCHILD
End Sub
Public Sub BeginAddOther()
    PrepareInput MODE_OTHER
End Sub

Private Sub PrepareInput(ByVal modeName As String)
    On Error GoTo EH
    Dim ws As Worksheet, baseId As String, autoSurname As String
    Set ws = ThisWorkbook.Worksheets(SH_INPUT)
    ws.Unprotect Password:=TOOL_PASSWORD
    If modeName <> MODE_DECEDENT Then
        baseId = CleanText(ws.Range(CELL_BASE_ID).Value)
        If Len(baseId) = 0 Then
            MsgBox "��Ɋ�l����I��ł��������B�푊���l�o�^��͎����Ŋ�l���ɂȂ�܂��B", vbExclamation
            GoTo CleanExit
        End If
    End If

    ws.Range(CELL_PERSON_ID & ":" & CELL_NOTE).ClearContents
    ws.Range(CELL_ADDR_CAND & ":" & CELL_ADDR_NOTE).ClearContents
    ws.Range(CELL_MODE).Value = modeName
    ws.Range(CELL_SHOW_DIAGRAM).Value = SHOW_YES

    autoSurname = SuggestSurname(modeName, baseId)
    ws.Range(CELL_AUTO_SURNAME).Value = autoSurname
    ws.Range(CELL_SURNAME).Value = autoSurname
    ws.Range(CELL_GENDER).Value = SuggestedGender(modeName, baseId)

    Select Case modeName
        Case MODE_DECEDENT
            ws.Range(CELL_REL_TO_DECEDENT).Value = MODE_DECEDENT
            ws.Range(CELL_SURNAME).ClearContents
        Case Else
            ws.Range(CELL_REL_TO_DECEDENT).Value = AutoRelationText(modeName, baseId, _
                CleanText(ws.Range(CELL_GENDER).Value), ws.Range(CELL_BIRTH).Value)
    End Select

    If modeName = MODE_SPOUSE Or modeName = MODE_MOTHER Then
        ws.Range(CELL_FORMER_SURNAME).Interior.Color = ThemeColor("warning-soft")
    End If
    CopyBaseCurrentAddress False
    RefreshCandidates
    UpdateInputGuide modeName
    ws.Range(CELL_GIVEN_NAME).Select
CleanExit:
    On Error Resume Next
    EnsurePersonInputValidationOnly ws
    RepairPersonInputLayout ws
    ApplyInputUsability
    On Error GoTo 0
    Exit Sub
EH:
    Dim errNum As Long, errDesc As String, errSrc As String
    errNum = Err.Number: errDesc = Err.Description: errSrc = Err.Source
    On Error Resume Next
    EnsurePersonInputValidationOnly ws
    RepairPersonInputLayout ws
    ApplyInputUsability
    On Error GoTo 0
    RuntimeShowErrorValues "PrepareInput", "�l�����͊J�n", _
        "��l���E���͌��E�V�[�g�ی��Ԃ��m�F���Ă��������B", "", errNum, errDesc, errSrc
End Sub

Public Sub ClearPersonInput()
    On Error GoTo EH
    Dim ws As Worksheet
    Set ws = ThisWorkbook.Worksheets(SH_INPUT)
    ws.Unprotect Password:=TOOL_PASSWORD
    ws.Range(CELL_PERSON_ID & ":" & CELL_NOTE).ClearContents
    ws.Range(CELL_ADDR_CAND & ":" & CELL_ADDR_NOTE).ClearContents
    ws.Range(CELL_SHOW_DIAGRAM).Value = SHOW_YES
CleanExit:
    EnsurePersonInputValidationOnly ws
    RepairPersonInputLayout ws
    ApplyInputUsability
    Exit Sub
EH:
    Resume CleanExit
End Sub

Private Function SuggestSurname(ByVal modeName As String, ByVal baseId As String) As String
    Dim decId As String, s As String
    If modeName = MODE_OTHER Then
        SuggestSurname = ""
        Exit Function
    End If
    If modeName = MODE_DECEDENT Then
        SuggestSurname = ""
        Exit Function
    End If
    If Len(baseId) > 0 Then s = GetPersonValue(baseId, P_SURNAME)
    decId = GetDecedentId()
    Select Case modeName
        Case MODE_FATHER, MODE_MOTHER, MODE_SIBLING
            If Len(decId) > 0 Then SuggestSurname = GetPersonValue(decId, P_SURNAME) Else SuggestSurname = s
        Case Else
            SuggestSurname = s
    End Select
End Function

Public Sub LoadBaseFromSelection()
    Dim ws As Worksheet, sel As String, pid As String
    Set ws = ThisWorkbook.Worksheets(SH_INPUT)
    sel = CleanText(ws.Range(CELL_BASE_SELECT).Value)
    pid = ParseIdFromCandidate(sel)
    If Len(pid) = 0 Or FindPersonRow(pid) = 0 Then
        MsgBox "��l����₩��l����I��ł��������B", vbExclamation
        Exit Sub
    End If
    SetBasePerson pid
End Sub

Public Sub SetDecedentAsBase()
    Dim pid As String
    pid = GetDecedentId()
    If Len(pid) = 0 Then
        MsgBox "�푊���l���܂��o�^����Ă��܂���B", vbExclamation
        Exit Sub
    End If
    SetBasePerson pid
End Sub

Public Sub SetBasePerson(ByVal personId As String)
    Dim ws As Worksheet, r As Long, addr As String
    Set ws = ThisWorkbook.Worksheets(SH_INPUT)
    r = FindPersonRow(personId)
    If r = 0 Then Exit Sub
    ws.Range(CELL_BASE_ID).Value = personId
    ws.Range(CELL_BASE_NAME).Value = ThisWorkbook.Worksheets(SH_W_PERSON).Cells(r, P_DISPLAY).Value
    ws.Range(CELL_BASE_REL).Value = ThisWorkbook.Worksheets(SH_W_PERSON).Cells(r, P_REL_DEC).Value
    addr = GetCurrentAddressText(personId)
    ws.Range(CELL_BASE_ADDRESS).Value = addr
    ws.Range(CELL_BASE_SELECT).Value = personId & " " & ws.Range(CELL_BASE_NAME).Value
    If Len(CleanText(ws.Range(CELL_MODE).Value)) > 0 Then UpdateInputGuide CleanText(ws.Range(CELL_MODE).Value)
End Sub

Public Function FindPersonRow(ByVal personId As String) As Long
    Dim ws As Worksheet, r As Long, lastR As Long
    Set ws = ThisWorkbook.Worksheets(SH_W_PERSON)
    lastR = LastRow(ws, 1)
    For r = 2 To lastR
        If CStr(ws.Cells(r, P_ID).Value) = personId And CStr(ws.Cells(r, P_STATUS).Value) <> STATUS_CANCEL Then
            FindPersonRow = r
            Exit Function
        End If
    Next r
End Function

Public Function GetPersonValue(ByVal personId As String, ByVal colNum As Long) As String
    Dim r As Long
    r = FindPersonRow(personId)
    If r > 0 Then GetPersonValue = CStr(ThisWorkbook.Worksheets(SH_W_PERSON).Cells(r, colNum).Value)
End Function

Public Function GetDecedentId() As String
    Dim ws As Worksheet, r As Long, lastR As Long
    Set ws = ThisWorkbook.Worksheets(SH_W_PERSON)
    lastR = LastRow(ws, 1)
    For r = 2 To lastR
        If CStr(ws.Cells(r, P_TYPE).Value) = MODE_DECEDENT And CStr(ws.Cells(r, P_STATUS).Value) <> STATUS_CANCEL Then
            GetDecedentId = CStr(ws.Cells(r, P_ID).Value)
            Exit Function
        End If
    Next r
End Function

Public Function GetInheritanceDate() As Variant
    Dim ws As Worksheet
    Set ws = ThisWorkbook.Worksheets(SH_CONFIG)
    If IsDate(ws.Range(CELL_CONFIG_INHERIT_DATE).Value) Then
        GetInheritanceDate = ws.Range(CELL_CONFIG_INHERIT_DATE).Value
    Else
        GetInheritanceDate = ""
    End If
End Function

Public Sub RegisterInputPerson()
    On Error GoTo EH
    AppBegin
    Dim wsIn As Worksheet, wsP As Worksheet, modeName As String, pid As String, r As Long
    Dim surname As String, givenName As String, former As String, autoSurname As String
    Dim displayName As String, personType As String, relationText As String, baseId As String
    Dim gender As String, birthDate As Variant, deathDate As Variant, occupation As String, note As String
    Set wsIn = ThisWorkbook.Worksheets(SH_INPUT)
    Set wsP = ThisWorkbook.Worksheets(SH_W_PERSON)

    modeName = CleanText(wsIn.Range(CELL_MODE).Value)
    If Len(modeName) = 0 Then modeName = MODE_DECEDENT
    baseId = CleanText(wsIn.Range(CELL_BASE_ID).Value)
    If modeName <> MODE_DECEDENT And Len(baseId) = 0 Then Err.Raise 5, , "��l�������ݒ�ł��B"

    surname = CleanText(wsIn.Range(CELL_SURNAME).Value)
    givenName = CleanText(wsIn.Range(CELL_GIVEN_NAME).Value)
    former = CleanText(wsIn.Range(CELL_FORMER_SURNAME).Value)
    autoSurname = CleanText(wsIn.Range(CELL_AUTO_SURNAME).Value)
    If Len(surname) = 0 And Len(autoSurname) > 0 Then surname = autoSurname
    If Len(givenName) = 0 Then Err.Raise 5, , "������͂��Ă��������B"
    If Len(surname) = 0 Then Err.Raise 5, , "������͂��Ă��������B"
    If Len(autoSurname) > 0 And surname <> autoSurname And Len(former) = 0 Then
        former = autoSurname
        wsIn.Range(CELL_FORMER_SURNAME).Value = former
    End If
    displayName = ComposeDisplayName(surname, givenName, former)
    gender = CleanText(wsIn.Range(CELL_GENDER).Value)
    relationText = CleanText(wsIn.Range(CELL_REL_TO_DECEDENT).Value)
    If Len(relationText) = 0 Or relationText = "�q" Or relationText = "�Z��o��" Then relationText = AutoRelationText(modeName, baseId, gender, wsIn.Range(CELL_BIRTH).Value)
    personType = IIf(modeName = MODE_DECEDENT, MODE_DECEDENT, IIf(modeName = MODE_OTHER, "�֌W��", "�e��"))
    If modeName = MODE_CHILD Or modeName = MODE_GRANDCHILD Then personType = "�����l"
    If modeName = MODE_SPOUSE And baseId = GetDecedentId() Then personType = "�����l"
    birthDate = SameDateOrBlank(wsIn.Range(CELL_BIRTH).Value)
    deathDate = SameDateOrBlank(wsIn.Range(CELL_DEATH).Value)
    occupation = CleanText(wsIn.Range(CELL_OCCUPATION).Value)
    note = CleanText(wsIn.Range(CELL_NOTE).Value)

    pid = CleanText(wsIn.Range(CELL_PERSON_ID).Value)
    If Len(pid) = 0 Then
        pid = NextId("�l��")
        r = NextBlankRow(wsP, 1)
        wsP.Cells(r, P_CREATED).Value = Now
    Else
        r = FindPersonRow(pid)
        If r = 0 Then r = NextBlankRow(wsP, 1)
    End If
    wsP.Cells(r, P_ID).Value = pid
    wsP.Cells(r, P_ORDER).Value = IIf(Len(wsP.Cells(r, P_ORDER).Value) = 0, r - 1, wsP.Cells(r, P_ORDER).Value)
    wsP.Cells(r, P_TYPE).Value = personType
    wsP.Cells(r, P_SURNAME).Value = surname
    wsP.Cells(r, P_GIVEN).Value = givenName
    wsP.Cells(r, P_FORMER).Value = former
    wsP.Cells(r, P_DISPLAY).Value = displayName
    wsP.Cells(r, P_SUR_MODE).Value = IIf(Len(autoSurname) > 0 And surname = autoSurname, "����", "�����")
    wsP.Cells(r, P_SUR_SRC).Value = IIf(Len(autoSurname) > 0, baseId, "")
    wsP.Cells(r, P_REL_DEC).Value = relationText
    wsP.Cells(r, P_REL_DISP).Value = relationText
    wsP.Cells(r, P_GENDER).Value = gender
    wsP.Cells(r, P_BIRTH).Value = birthDate
    wsP.Cells(r, P_DEATH).Value = deathDate
    wsP.Cells(r, P_OCC).Value = occupation
    wsP.Cells(r, P_SHOW).Value = IIf(Len(CleanText(wsIn.Range(CELL_SHOW_DIAGRAM).Value)) = 0, SHOW_YES, wsIn.Range(CELL_SHOW_DIAGRAM).Value)
    wsP.Cells(r, P_NOTE).Value = note
    wsP.Cells(r, P_STATUS).Value = STATUS_ACTIVE
    wsP.Cells(r, P_UPDATED).Value = Now
    wsIn.Range(CELL_PERSON_ID).Value = pid

    If modeName = MODE_DECEDENT Then
        ThisWorkbook.Worksheets(SH_CONFIG).Range(CELL_CONFIG_INHERIT_DATE).Value = deathDate
    Else
        AddRelationIfNeeded baseId, pid, modeName, relationText, wsIn.Range(CELL_MARRIAGE).Value, wsIn.Range(CELL_DIVORCE).Value
    End If

    RegisterAddressFromInput pid
    RefreshCandidates
    ApplyValidations
    BuildConfirmList

    Dim nextBaseId As String
    nextBaseId = pid
    SetBasePerson nextBaseId
    wsIn.Range(CELL_BASE_SELECT).Value = nextBaseId & " " & GetPersonValue(nextBaseId, P_DISPLAY)
    EnsurePersonInputValidationOnly wsIn
    RepairPersonInputLayout wsIn
    ApplyInputUsability
    WriteGuideAfterRegister modeName, displayName, nextBaseId
    MsgBox displayName & " ��o�^���܂����B" & vbCrLf & vbCrLf & NextActionMessage(modeName, nextBaseId), vbInformation
CleanExit:
    AppEnd
    Exit Sub
EH:
    Dim errNum As Long, errDesc As String, errSrc As String
    errNum = Err.Number: errDesc = Err.Description: errSrc = Err.Source
    On Error Resume Next
    If Not wsIn Is Nothing Then
        EnsurePersonInputValidationOnly wsIn
        RepairPersonInputLayout wsIn
        ApplyInputUsability
    End If
    AppEnd
    On Error GoTo 0
    RuntimeShowErrorValues "RegisterInputPerson", "�l���o�^", _
        "�K�{���ځA��l���A���V�[�g�A�V�[�g�ی��Ԃ��m�F���Ă��������B", _
        "", errNum, errDesc, errSrc
End Sub

Private Function RecommendedNextBase(ByVal modeName As String, ByVal baseId As String, ByVal newPersonId As String) As String
    '�o�^�����l�������̂܂܎��̊�l���ɂ���B
    '�u�����͂��Ă���l���̊֌W�҂𑱂��ēo�^����v������D�悷��B
    RecommendedNextBase = newPersonId
End Function

Private Function NextActionMessage(ByVal modeName As String, ByVal nextBaseId As String) As String
    Dim baseName As String
    baseName = GetPersonValue(nextBaseId, P_DISPLAY)
    NextActionMessage = "���݂̊�l�����u" & baseName & "�v�ɂ��܂����B" & _
        "���́A���̐l���̔z��ҁE���E��E�q�E�Z��o���Ȃǂ��֌W�{�^������ǉ����Ă��������B" & _
        "�ʂ̐l���̊֌W�҂֖߂�ꍇ�́A��l�����őI�Ԃ��u�푊���l�ɖ߂�v�������܂��B"
End Function

Private Sub WriteGuideAfterRegister(ByVal modeName As String, ByVal displayName As String, ByVal nextBaseId As String)
    Dim ws As Worksheet, guide As String
    Set ws = ThisWorkbook.Worksheets(SH_INPUT)
    guide = "�o�^�����F" & displayName & vbLf & _
            NextActionMessage(modeName, nextBaseId) & vbLf & _
            "���͂̌����F�������E�Z���E�������E�����͌�₩��I�сA�������e���x���͂��Ȃ��B�Z���L�[�������Ȃ瓯������ɔ��f����܂��B"
    ws.Range("B38").Value = guide
End Sub

Private Sub UpdateInputGuide(ByVal modeName As String)
    Dim ws As Worksheet, guide As String, baseId As String, baseName As String
    Set ws = ThisWorkbook.Worksheets(SH_INPUT)
    baseId = CleanText(ws.Range(CELL_BASE_ID).Value)
    baseName = GetPersonValue(baseId, P_DISPLAY)
    Select Case modeName
        Case MODE_DECEDENT
            guide = "�菇1�F�푊���l��o�^���܂��B���E���E���S���E�Z������͂��Ă��������B���S���������J�n���ɂȂ�܂��B�o�^��A�z��ҁA���A��A�q�̏��Ɋ֌W�҂�ǉ����܂��B"
        Case MODE_SPOUSE
            guide = "�z��Ғǉ��F���ݐ��͊�l���Ɠ������������\�����܂��B�����͕K���m�F���Ă��������B�Z���͊�l���Z���R�s�[�A�J�n���͍����������Ƃ��Ďg���܂��B"
        Case MODE_FATHER
            guide = "���ǉ��F���͔푊���l���̐��������\�����܂��B�Z���͔푊���l��O��Z������R�s�[�ł��܂��B�o�^��͔푊���l����ɖ߂��Ď���ǉ����܂��B"
        Case MODE_MOTHER
            guide = "��ǉ��F���͔푊���l���̐��������\�����܂��B������ڗ����ɓ��͂��Ă��������B�Z���͕��E�푊���l�E�O��Z�������≻�ł��܂��B"
        Case MODE_CHILD
            guide = "�q�ǉ��F���͐e�̐��������\�����܂��B���ʂ�����ƒ��j�E��������������≻���܂��B����ς����ꍇ�͋����Ɍ��̐��������⊮���܂��B"
        Case MODE_SIBLING
            guide = "�Z��o���ǉ��F���͔푊���l���̐��������\�����܂��B���ʂƐ��N����������ΌZ�E��E�o�E�����������肵�܂��B"
        Case MODE_GRANDCHILD
            guide = "���ǉ��F��l���̎q�Ƃ��ēo�^���܂��B���ƏZ���͊�l������R�s�[�ł��܂��B������͑����֌W�}�Ŏq����̂���ɉE���ɔz�u���܂��B"
        Case Else
            guide = "���̑��֌W�ҁF���E�Z���E�����͌�₩��I�ׂ܂��B�֌W����l�ɁA������̈ʒu�t����Z������Ă��������B"
    End Select
    If Len(baseName) > 0 Then guide = "��l���F" & baseName & vbLf & guide
    ws.Range("B38").Value = guide
End Sub

Private Function AutoRelationText(ByVal modeName As String, _
        ByVal baseId As String, _
        ByVal gender As String, _
        ByVal birthDate As Variant) As String
    Dim decId As String, baseRel As String
    decId = GetDecedentId()
    baseRel = GetPersonValue(baseId, P_REL_DEC)
    If Len(baseRel) = 0 Then baseRel = "��l��"

    Select Case modeName
        Case MODE_DECEDENT
            AutoRelationText = "�푊���l"
        Case MODE_SPOUSE
            If Len(baseId) = 0 Or baseId = decId Then
                AutoRelationText = "�z���"
            Else
                AutoRelationText = RelationViaBase(baseRel, "�z���", "�z���")
            End If
        Case MODE_FATHER
            If Len(baseId) = 0 Or baseId = decId Then
                AutoRelationText = "��"
            Else
                AutoRelationText = RelationViaBase(baseRel, "��", "��")
            End If
        Case MODE_MOTHER
            If Len(baseId) = 0 Or baseId = decId Then
                AutoRelationText = "��"
            Else
                AutoRelationText = RelationViaBase(baseRel, "��", "��")
            End If
        Case MODE_CHILD
            If Len(baseId) > 0 And baseId <> decId Then
                If BaseIsDirectChildRelation(baseRel) Then
                    AutoRelationText = "��"
                Else
                    AutoRelationText = RelationViaBase(baseRel, "�q", "�q")
                End If
            Else
                AutoRelationText = ChildRelationText(gender)
            End If
        Case MODE_SIBLING
            If Len(baseId) = 0 Or baseId = decId Then
                AutoRelationText = SiblingRelationText(gender, birthDate)
            Else
                AutoRelationText = RelationViaBase(baseRel, "�Z��o��", "�Z��o��")
            End If
        Case MODE_GRANDCHILD
            If Len(baseId) = 0 Or baseId = decId Then
                AutoRelationText = "��"
            Else
                AutoRelationText = RelationViaBase(baseRel, "��", "��")
            End If
        Case Else
            If Len(baseId) > 0 And baseId <> decId Then
                AutoRelationText = RelationViaBase(baseRel, "�֌W��", "�֌W��")
            Else
                AutoRelationText = "�֌W��"
            End If
    End Select
End Function

Private Function RelationViaBase(ByVal baseRel As String, ByVal suffixText As String, ByVal fallbackText As String) As String
    baseRel = CleanText(baseRel)
    If Len(baseRel) = 0 Or baseRel = "�푊���l" Then
        RelationViaBase = fallbackText
    ElseIf InStr(baseRel, "��") > 0 Then
        RelationViaBase = baseRel & "�E" & suffixText
    Else
        RelationViaBase = baseRel & "��" & suffixText
    End If
End Function

Private Function BaseIsDirectChildRelation(ByVal baseRel As String) As Boolean
    baseRel = CleanText(baseRel)
    BaseIsDirectChildRelation = (baseRel = "�q" Or baseRel = "���j" Or baseRel = "��j" Or _
        baseRel = "�O�j" Or baseRel = "�l�j" Or baseRel = "�ܒj" Or _
        baseRel = "����" Or baseRel = "��" Or baseRel = "�O��" Or _
        baseRel = "�l��" Or baseRel = "�܏�")
End Function

Private Function SuggestedGender(ByVal modeName As String, ByVal baseId As String) As String
    Dim baseGender As String
    Select Case modeName
        Case MODE_FATHER
            SuggestedGender = "�j"
        Case MODE_MOTHER
            SuggestedGender = "��"
        Case MODE_SPOUSE
            baseGender = GetPersonValue(baseId, P_GENDER)
            If baseGender = "�j" Then
                SuggestedGender = "��"
            ElseIf baseGender = "��" Then
                SuggestedGender = "�j"
            End If
    End Select
End Function

Public Sub RefreshCurrentRelationText()
    Dim ws As Worksheet, modeName As String, baseId As String
    Set ws = ThisWorkbook.Worksheets(SH_INPUT)
    modeName = CleanText(ws.Range(CELL_MODE).Value)
    If Len(modeName) = 0 Then Exit Sub
    baseId = CleanText(ws.Range(CELL_BASE_ID).Value)
    ws.Range(CELL_REL_TO_DECEDENT).Value = AutoRelationText(modeName, baseId, _
        CleanText(ws.Range(CELL_GENDER).Value), ws.Range(CELL_BIRTH).Value)
End Sub

Private Function ChildRelationText(ByVal gender As String) As String
    Dim n As Long
    If gender = "�j" Then
        n = CountRelationStartsWith("���j", "��j", "�O�j", "�j") + 1
        ChildRelationText = Array("", "���j", "��j", "�O�j", "�l�j", "�ܒj")(Application.Min(n, 5))
    ElseIf gender = "��" Then
        n = CountRelationStartsWith("����", "��", "�O��", "��") + 1
        ChildRelationText = Array("", "����", "��", "�O��", "�l��", "�܏�")(Application.Min(n, 5))
    Else
        ChildRelationText = "�q"
    End If
End Function

Private Function CountRelationStartsWith(ByVal a As String, ByVal b As String, ByVal c As String, ByVal g As String) As Long
    Dim ws As Worksheet, r As Long, lastR As Long, v As String
    Set ws = ThisWorkbook.Worksheets(SH_W_PERSON)
    lastR = LastRow(ws, 1)
    For r = 2 To lastR
        v = CStr(ws.Cells(r, P_REL_DEC).Value)
        If v = a Or v = b Or v = c Or InStr(v, g) > 0 Then CountRelationStartsWith = CountRelationStartsWith + 1
    Next r
End Function

Private Function SiblingRelationText(ByVal gender As String, ByVal birthDate As Variant) As String
    Dim decId As String, decBirth As Variant, older As Boolean
    decId = GetDecedentId()
    decBirth = GetPersonValue(decId, P_BIRTH)
    If IsDate(birthDate) And IsDate(decBirth) Then older = CDate(birthDate) < CDate(decBirth)
    If gender = "�j" Then
        SiblingRelationText = IIf(older, "�Z", "��")
    ElseIf gender = "��" Then
        SiblingRelationText = IIf(older, "�o", "��")
    Else
        SiblingRelationText = "�Z��o��"
    End If
End Function

Private Sub AddRelationIfNeeded(ByVal baseId As String, _
        ByVal otherId As String, _
        ByVal modeName As String, _
        ByVal relationText As String, _
        ByVal marriageDate As Variant, _
        ByVal divorceDate As Variant)
    If Len(baseId) = 0 Or Len(otherId) = 0 Then Exit Sub
    Dim ws As Worksheet, r As Long, relationType As String
    Set ws = ThisWorkbook.Worksheets(SH_W_REL)
    relationType = "���̑�"
    If modeName = MODE_SPOUSE Then relationType = "�z���"
    If modeName = MODE_CHILD Or modeName = MODE_FATHER Or modeName = MODE_MOTHER Or modeName = MODE_GRANDCHILD Then relationType = "�e�q"
    If modeName = MODE_SIBLING Then relationType = "�Z��o��"
    r = NextBlankRow(ws, 1)
    ws.Cells(r, R_ID).Value = NextId("�֌W")
    ws.Cells(r, R_BASE_ID).Value = baseId
    ws.Cells(r, R_OTHER_ID).Value = otherId
    ws.Cells(r, R_TYPE).Value = relationType
    ws.Cells(r, R_DISPLAY).Value = relationText
    ws.Cells(r, R_MARRIAGE).Value = SameDateOrBlank(marriageDate)
    ws.Cells(r, R_DIVORCE).Value = SameDateOrBlank(divorceDate)
    ws.Cells(r, R_AUTO).Value = "����"
    ws.Cells(r, R_STATUS).Value = STATUS_ACTIVE
    ws.Cells(r, R_CREATED).Value = Now
    ws.Cells(r, R_UPDATED).Value = Now
End Sub

Private Sub RegisterAddressFromInput(ByVal personId As String)
    Dim wsIn As Worksheet, addressText As String, addressKey As String, candId As String, addrId As String, r As Long, wsA As Worksheet
    Set wsIn = ThisWorkbook.Worksheets(SH_INPUT)
    addressText = CleanText(wsIn.Range(CELL_ADDR_TEXT).Value)
    If Len(addressText) = 0 Then Exit Sub
    addressKey = CleanText(wsIn.Range(CELL_ADDR_KEY).Value)
    If Len(addressKey) = 0 Then addressKey = NormalizeAddress(addressText)
    wsIn.Range(CELL_ADDR_KEY).Value = addressKey
    candId = GetOrCreateAddressCandidate(addressText, addressKey, personId)
    Set wsA = ThisWorkbook.Worksheets(SH_W_ADDR_HIST)
    r = NextBlankRow(wsA, 1)
    addrId = NextId("�Z������")
    wsA.Cells(r, A_ID).Value = addrId
    wsA.Cells(r, A_PERSON_ID).Value = personId
    wsA.Cells(r, A_CAND_ID).Value = candId
    wsA.Cells(r, A_TYPE).Value = IIf(Len(CleanText(wsIn.Range(CELL_ADDR_TYPE).Value)) = 0, "���Z�n", wsIn.Range(CELL_ADDR_TYPE).Value)
    wsA.Cells(r, A_START).Value = SameDateOrBlank(wsIn.Range(CELL_ADDR_START).Value)
    wsA.Cells(r, A_END).Value = SameDateOrBlank(wsIn.Range(CELL_ADDR_END).Value)
    wsA.Cells(r, A_TEXT).Value = addressText
    wsA.Cells(r, A_KEY).Value = addressKey
    wsA.Cells(r, A_SOURCE).Value = CleanText(wsIn.Range(CELL_ADDR_SOURCE).Value)
    wsA.Cells(r, A_COPY_PERSON_ID).Value = CleanText(wsIn.Range(CELL_BASE_ID).Value)
    wsA.Cells(r, A_NOTE).Value = CleanText(wsIn.Range(CELL_ADDR_NOTE).Value)
    wsA.Cells(r, A_STATUS).Value = STATUS_ACTIVE
    wsA.Cells(r, A_CREATED).Value = Now
    wsA.Cells(r, A_UPDATED).Value = Now
    ThisWorkbook.Worksheets(SH_W_PERSON).Cells(FindPersonRow(personId), P_REP_ADDR_ID).Value = addrId
End Sub

Private Function GetOrCreateAddressCandidate(ByVal addressText As String, ByVal addressKey As String, ByVal personId As String) As String
    Dim ws As Worksheet, r As Long, lastR As Long
    Set ws = ThisWorkbook.Worksheets(SH_W_ADDR_CAND)
    lastR = LastRow(ws, 1)
    For r = 2 To lastR
        If CStr(ws.Cells(r, AC_KEY).Value) = addressKey Then
            ws.Cells(r, AC_LAST_PERSON).Value = personId
            ws.Cells(r, AC_USE_COUNT).Value = Val(ws.Cells(r, AC_USE_COUNT).Value) + 1
            ws.Cells(r, AC_LAST_USED).Value = Now
            GetOrCreateAddressCandidate = CStr(ws.Cells(r, AC_ID).Value)
            Exit Function
        End If
    Next r
    r = NextBlankRow(ws, 1)
    GetOrCreateAddressCandidate = NextId("�Z�����")
    ws.Cells(r, AC_ID).Value = GetOrCreateAddressCandidate
    ws.Cells(r, AC_TEXT).Value = addressText
    ws.Cells(r, AC_KEY).Value = addressKey
    ws.Cells(r, AC_FIRST_PERSON).Value = personId
    ws.Cells(r, AC_LAST_PERSON).Value = personId
    ws.Cells(r, AC_USE_COUNT).Value = 1
    ws.Cells(r, AC_LAST_USED).Value = Now
End Function

Public Sub MakeAddressKeyFromInput()
    Dim ws As Worksheet
    Set ws = ThisWorkbook.Worksheets(SH_INPUT)
    ws.Range(CELL_ADDR_KEY).Value = NormalizeAddress(ws.Range(CELL_ADDR_TEXT).Value)
End Sub

Public Sub ApplySelectedAddressCandidate()
    Dim ws As Worksheet, sel As String, id As String, r As Long
    Set ws = ThisWorkbook.Worksheets(SH_INPUT)
    sel = CleanText(ws.Range(CELL_ADDR_CAND).Value)
    If Len(sel) = 0 Then Exit Sub
    id = ParseIdFromCandidate(sel)
    r = FindAddressCandidateRow(id)
    If r = 0 Then Exit Sub
    ws.Range(CELL_ADDR_TEXT).Value = ThisWorkbook.Worksheets(SH_W_ADDR_CAND).Cells(r, AC_TEXT).Value
    ws.Range(CELL_ADDR_KEY).Value = ThisWorkbook.Worksheets(SH_W_ADDR_CAND).Cells(r, AC_KEY).Value
End Sub

Public Sub CopyBaseCurrentAddress(Optional ByVal showMessage As Boolean = True)
    Dim ws As Worksheet, baseId As String, addrText As String, addrKey As String
    Set ws = ThisWorkbook.Worksheets(SH_INPUT)
    baseId = CleanText(ws.Range(CELL_BASE_ID).Value)
    If Len(baseId) = 0 Then Exit Sub
    GetCurrentAddressParts baseId, addrText, addrKey
    If Len(addrText) > 0 Then
        ws.Range(CELL_ADDR_TEXT).Value = addrText
        ws.Range(CELL_ADDR_KEY).Value = addrKey
        If showMessage Then MsgBox "��l���̏Z�����R�s�[���܂����B", vbInformation
    End If
End Sub

Public Sub CopyLastAddress()
    Dim ws As Worksheet, r As Long
    Set ws = ThisWorkbook.Worksheets(SH_W_ADDR_CAND)
    r = LastRow(ws, AC_LAST_USED)
    If r < 2 Then Exit Sub
    ThisWorkbook.Worksheets(SH_INPUT).Range(CELL_ADDR_TEXT).Value = ws.Cells(r, AC_TEXT).Value
    ThisWorkbook.Worksheets(SH_INPUT).Range(CELL_ADDR_KEY).Value = ws.Cells(r, AC_KEY).Value
End Sub

Public Sub UseMarriageDateAsAddressStart()
    Dim ws As Worksheet
    Set ws = ThisWorkbook.Worksheets(SH_INPUT)
    If IsDate(ws.Range(CELL_MARRIAGE).Value) Then ws.Range(CELL_ADDR_START).Value = ws.Range(CELL_MARRIAGE).Value
End Sub

Public Sub UseBirthDateAsAddressStart()
    Dim ws As Worksheet
    Set ws = ThisWorkbook.Worksheets(SH_INPUT)
    If IsDate(ws.Range(CELL_BIRTH).Value) Then ws.Range(CELL_ADDR_START).Value = ws.Range(CELL_BIRTH).Value
End Sub

Public Sub UseDeathDateAsAddressEnd()
    Dim ws As Worksheet
    Set ws = ThisWorkbook.Worksheets(SH_INPUT)
    If IsDate(ws.Range(CELL_DEATH).Value) Then ws.Range(CELL_ADDR_END).Value = ws.Range(CELL_DEATH).Value
End Sub

Public Sub UseDivorceDateAsAddressEnd()
    Dim ws As Worksheet
    Set ws = ThisWorkbook.Worksheets(SH_INPUT)
    If IsDate(ws.Range(CELL_DIVORCE).Value) Then ws.Range(CELL_ADDR_END).Value = ws.Range(CELL_DIVORCE).Value
End Sub

Public Function FindAddressCandidateRow(ByVal candId As String) As Long
    Dim ws As Worksheet, r As Long, lastR As Long
    Set ws = ThisWorkbook.Worksheets(SH_W_ADDR_CAND)
    lastR = LastRow(ws, 1)
    For r = 2 To lastR
        If CStr(ws.Cells(r, AC_ID).Value) = candId Then FindAddressCandidateRow = r: Exit Function
    Next r
End Function

Public Sub GetCurrentAddressParts(ByVal personId As String, ByRef addressText As String, ByRef addressKey As String)
    Dim ws As Worksheet, r As Long, lastR As Long, bestR As Long
    Set ws = ThisWorkbook.Worksheets(SH_W_ADDR_HIST)
    lastR = LastRow(ws, 1)
    For r = 2 To lastR
        If CStr(ws.Cells(r, A_PERSON_ID).Value) = personId And CStr(ws.Cells(r, A_STATUS).Value) <> STATUS_CANCEL Then bestR = r
    Next r
    If bestR > 0 Then
        addressText = CStr(ws.Cells(bestR, A_TEXT).Value)
        addressKey = CStr(ws.Cells(bestR, A_KEY).Value)
    End If
End Sub

Public Function GetCurrentAddressText(ByVal personId As String) As String
    Dim t As String, k As String
    GetCurrentAddressParts personId, t, k
    GetCurrentAddressText = t
End Function

Public Sub RefreshCandidates()
    Dim wsC As Worksheet, wsP As Worksheet, wsA As Worksheet, r As Long, outR As Long, dict As Object, key As Variant
    Set wsC = ThisWorkbook.Worksheets(SH_W_CAND)
    wsC.Range("A2:N500").ClearContents
    Set dict = CreateObject("Scripting.Dictionary")
    Set wsP = ThisWorkbook.Worksheets(SH_W_PERSON)
    For r = 2 To LastRow(wsP, 1)
        If CStr(wsP.Cells(r, P_STATUS).Value) <> STATUS_CANCEL Then
            If Len(CStr(wsP.Cells(r, P_SURNAME).Value)) > 0 Then dict(CStr(wsP.Cells(r, P_SURNAME).Value)) = 1
            If Len(CStr(wsP.Cells(r, P_FORMER).Value)) > 0 Then dict(CStr(wsP.Cells(r, P_FORMER).Value)) = 1
        End If
    Next r
    outR = 2
    For Each key In dict.Keys
        wsC.Cells(outR, 1).Value = key
        outR = outR + 1
    Next key

    Set wsA = ThisWorkbook.Worksheets(SH_W_ADDR_CAND)
    For r = 2 To LastRow(wsA, 1)
        If Len(CStr(wsA.Cells(r, AC_ID).Value)) > 0 Then
            wsC.Cells(r, 2).Value = wsA.Cells(r, AC_ID).Value & " " & wsA.Cells(r, AC_TEXT).Value
            wsC.Cells(r, 3).Value = wsA.Cells(r, AC_ID).Value
        End If
    Next r

    For r = 2 To LastRow(wsP, 1)
        If Len(CStr(wsP.Cells(r, P_ID).Value)) > 0 And CStr(wsP.Cells(r, P_STATUS).Value) <> STATUS_CANCEL Then
            wsC.Cells(r, 4).Value = wsP.Cells(r, P_ID).Value & " " & wsP.Cells(r, P_DISPLAY).Value & "�i" & wsP.Cells(r, P_REL_DEC).Value & "�j"
            wsC.Cells(r, 5).Value = wsP.Cells(r, P_ID).Value
        End If
    Next r

    FillStaticCandidates wsC
    FillDateCandidates wsC
End Sub


Private Sub FillDateCandidates(ByVal wsC As Worksheet)
    Dim dictM As Object, dictD As Object, dictA As Object
    Dim wsR As Worksheet, wsP As Worksheet, wsA As Worksheet, r As Long, key As Variant, outR As Long
    Set dictM = CreateObject("Scripting.Dictionary")
    Set dictD = CreateObject("Scripting.Dictionary")
    Set dictA = CreateObject("Scripting.Dictionary")

    Set wsR = ThisWorkbook.Worksheets(SH_W_REL)
    For r = 2 To LastRow(wsR, 1)
        If CStr(wsR.Cells(r, R_STATUS).Value) <> STATUS_CANCEL Then
            AddDateCandidate dictM, wsR.Cells(r, R_MARRIAGE).Value
            AddDateCandidate dictA, wsR.Cells(r, R_MARRIAGE).Value
            AddDateCandidate dictD, wsR.Cells(r, R_DIVORCE).Value
            AddDateCandidate dictA, wsR.Cells(r, R_DIVORCE).Value
        End If
    Next r

    Set wsP = ThisWorkbook.Worksheets(SH_W_PERSON)
    For r = 2 To LastRow(wsP, 1)
        If CStr(wsP.Cells(r, P_STATUS).Value) <> STATUS_CANCEL Then
            AddDateCandidate dictA, wsP.Cells(r, P_BIRTH).Value
            AddDateCandidate dictA, wsP.Cells(r, P_DEATH).Value
        End If
    Next r

    Set wsA = ThisWorkbook.Worksheets(SH_W_ADDR_HIST)
    For r = 2 To LastRow(wsA, 1)
        If CStr(wsA.Cells(r, A_STATUS).Value) <> STATUS_CANCEL Then
            AddDateCandidate dictA, wsA.Cells(r, A_START).Value
            AddDateCandidate dictA, wsA.Cells(r, A_END).Value
        End If
    Next r

    outR = 2
    For Each key In dictM.Keys
        wsC.Cells(outR, 12).Value = CDate(dictM(key))
        outR = outR + 1
    Next key
    outR = 2
    For Each key In dictD.Keys
        wsC.Cells(outR, 13).Value = CDate(dictD(key))
        outR = outR + 1
    Next key
    outR = 2
    For Each key In dictA.Keys
        wsC.Cells(outR, 14).Value = CDate(dictA(key))
        outR = outR + 1
    Next key
    wsC.Range("L2:N500").NumberFormatLocal = "yyyy/m/d"
End Sub

Private Sub AddDateCandidate(ByVal dict As Object, ByVal v As Variant)
    If IsDate(v) Then dict(Format(CDate(v), "yyyy/mm/dd")) = CDate(v)
End Sub
Private Sub FillStaticCandidates(ByVal wsC As Worksheet)
    Dim arr, i As Long
    arr = Array("�ː�", "�ːЕ��[", "�Z���[", "�\�q", "���Z����", "���̑�")
    For i = 0 To UBound(arr): wsC.Cells(2 + i, 6).Value = arr(i): Next i
    arr = Array("���E", "��Ј�", "��Ж���", "���c��", "������", "�N��", "���̑�")
    For i = 0 To UBound(arr): wsC.Cells(2 + i, 7).Value = arr(i): Next i
    arr = Array("�푊���l", "�z���", "��", "��", "���j", "��j", "�O�j", "����", "��", "�O��", "�q", "��", "�Z", "��", "�o", "��", "�֌W��")
    For i = 0 To UBound(arr): wsC.Cells(2 + i, 8).Value = arr(i): Next i
    arr = Array("���Z�n", "�Z���[�Z��", "������", "�{��", "���̑�")
    For i = 0 To UBound(arr): wsC.Cells(2 + i, 9).Value = arr(i): Next i
    arr = Array("�j", "��", "�s��")
    For i = 0 To UBound(arr): wsC.Cells(2 + i, 10).Value = arr(i): Next i
    arr = Array(SHOW_YES, SHOW_NO)
    For i = 0 To UBound(arr): wsC.Cells(2 + i, 11).Value = arr(i): Next i
End Sub

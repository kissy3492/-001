Attribute VB_Name = "modAnalysisEngine"

Option Explicit



Private mTxById As Object

Private mMatched As Object

Private mDedupe As Object

Private mManualExcludedTxIds As Object

Private mManualVoucherOverrides As Object

Private mManualDecisionOverrides As Object

Private mManualMemoOverrides As Object

Private mCohabPairs As Object

Private mRelationPairs As Object

Private mMarriageByPerson As Object

Private mPersonInfo As Object

Private mAddressByPerson As Object

Private mTimeCluster As Object

Private mAccountOperationPatternCount As Object

Private mNextResultRow As Long

Private mNextDetailRow As Long

Private mDecedentId As String

Private mInheritanceDate As Variant

Private mMinShift As Double

Private mDateWindow As Long

Private mAmountTol As Double

Private mAmountRate As Double

Private mMaxCombo As Long

Private mMaxSideCandidates As Long

Private mUnknownThreshold As Double

Private mVoucherThreshold As Double

Private mEnableOneToOne As Boolean

Private mEnableOneToMany As Boolean

Private mEnableManyToOne As Boolean

Private mEnableManyToMany As Boolean

Private mEnableUnknowns As Boolean

Private mSuppressDuplicateShift As Boolean

Private mMaxResults As Long

Private mMaxCombosPerBase As Long

Private mMaxMtmPairTests As Long

Private mVoucherInheritanceAlways As Boolean

Private mVoucherUnknowns As Boolean

Private mExcludeSummaryKeywords As String

Private mStopIfTooBroad As Boolean

Private mFocusYears As Long

Private mMinScore As Long

Private mContextScore As Boolean

Private mStopRequested As Boolean

Private mResultCount As Long

Private mExcludedKeywordList As Variant



Public Sub RunAnalysis()

    If Not RequireSavedWorkbook() Then Exit Sub

    If LastRow(GetSheet(SH_WORK_TX), 1) < 2 Then

        If MsgBox("����f�[�^���ǂݍ��܂�Ă��܂���B���ʃf�[�^�Ǎ������s���܂����B", vbQuestion + vbYesNo) = vbYes Then

            LoadCommonData

        End If

    End If

    If LastRow(GetSheet(SH_WORK_TX), 1) < 2 Then

        MsgBox "���͑Ώۂ̎��������܂���B", vbExclamation

        Exit Sub

    End If



    On Error GoTo EH

    AppBegin "�����ړ����͂����s��..."

    ResetAnalysisIds

    InitResultHeaders GetSheet(SH_WORK_RESULT)

    InitDetailHeaders GetSheet(SH_WORK_DETAIL)

    mNextResultRow = 2

    mNextDetailRow = 2

    Set mTxById = CreateObject("Scripting.Dictionary")

    Set mMatched = CreateObject("Scripting.Dictionary")

    Set mDedupe = CreateObject("Scripting.Dictionary")

    Set mManualExcludedTxIds = CreateObject("Scripting.Dictionary")

    Set mManualVoucherOverrides = CreateObject("Scripting.Dictionary")

    Set mManualDecisionOverrides = CreateObject("Scripting.Dictionary")

    Set mManualMemoOverrides = CreateObject("Scripting.Dictionary")

    LoadManualExcludedTxIds mManualExcludedTxIds

    LoadManualStateOverrides mManualVoucherOverrides, mManualDecisionOverrides, mManualMemoOverrides

    ReadAnalysisSettings

    Set mPersonInfo = BuildPersonInfoIndex()

    Set mAddressByPerson = BuildAddressByPersonIndex()

    Set mRelationPairs = BuildRelationPairIndex()

    Set mMarriageByPerson = BuildMarriageDateIndex()

    Set mCohabPairs = BuildCohabPairIndex()

    Set mTimeCluster = CreateObject("Scripting.Dictionary")

    Set mAccountOperationPatternCount = CreateObject("Scripting.Dictionary")



    Dim outs As Collection, ins As Collection, insByDate As Object, outByDate As Object

    Set outs = New Collection

    Set ins = New Collection

    Set insByDate = CreateObject("Scripting.Dictionary")

    Set outByDate = CreateObject("Scripting.Dictionary")



    LoadTransactionRecords outs, ins, outByDate, insByDate

    EnrichTransactionAfterBalanceContext

    If Not ValidateComplexityBeforeRun(outs.Count, ins.Count) Then GoTo SafeExit

    If mEnableOneToOne Then FindOneToOne outs, insByDate

    If mEnableOneToMany Then FindOneToMany outs, insByDate

    If mEnableManyToOne Then FindManyToOne ins, outByDate

    If mEnableManyToMany Then FindManyToMany outs, ins, outByDate, insByDate

    If mEnableUnknowns Then FindUnknowns outs, ins



SafeExit:

    BuildAnalysisResultSheet

    BuildInvestigationIssueSheet True

    BuildFlaggedTransactionSheet

    If SettingYes(ROW_AUTO_SAVE_COMMON, True) Then SaveAnalysisToCommonData True

    If SettingYes(ROW_KEEP_OUTPUT_VISIBLE, True) Then ShowOutputSheets Else HideDailySheets False



    AppEnd

    AppendLog "���͎��s", "����", "��⌏��: " & CStr(Application.Max(0, LastRow(GetSheet(SH_WORK_RESULT), 1) - 1))

    MsgBox "���͂��������܂����B" & vbCrLf & _
           "��⌏��: " & CStr(Application.Max(0, LastRow(GetSheet(SH_WORK_RESULT), 1) - 1)), vbInformation

    Exit Sub

EH:

    AppEnd

    AppendLog "���͎��s", "���s", Err.Description

    RuntimeShowError "RunAnalysis", "���͎��s", "���ʃf�[�^�Ǎ��A���͏����A���ID�A���t�E���z����m�F���Ă��������B"

End Sub



Private Sub ReadAnalysisSettings()

    mDecedentId = CellText(GetSheet(SH_MAIN).Cells(ROW_DECEDENT_ID, COL_VALUE).Value)

    If IsDate(GetSheet(SH_MAIN).Cells(ROW_INHERITANCE_DATE, COL_VALUE).Value) Then

        mInheritanceDate = CDate(GetSheet(SH_MAIN).Cells(ROW_INHERITANCE_DATE, COL_VALUE).Value)

    Else

        mInheritanceDate = Empty

    End If

    mMinShift = GetSettingDouble(ROW_MIN_SHIFT_AMOUNT, DEFAULT_MIN_SHIFT_AMOUNT)

    mDateWindow = GetSettingLong(ROW_DATE_WINDOW, DEFAULT_DATE_WINDOW)

    mAmountTol = GetSettingDouble(ROW_AMOUNT_TOLERANCE, DEFAULT_AMOUNT_TOLERANCE)

    mAmountRate = NzDbl(GetSheet(SH_MAIN).Cells(ROW_AMOUNT_TOLERANCE_RATE, COL_VALUE).Value, DEFAULT_AMOUNT_TOLERANCE_RATE)

    mMaxCombo = GetSettingLong(ROW_MAX_COMBO, DEFAULT_MAX_COMBO)

    If mMaxCombo < 1 Then mMaxCombo = 1

    If mMaxCombo > MAX_ALLOWED_COMBO Then mMaxCombo = MAX_ALLOWED_COMBO

    mMaxSideCandidates = GetSettingLong(ROW_MAX_SIDE_CANDIDATES, DEFAULT_MAX_SIDE_CANDIDATES)

    If mMaxSideCandidates < 3 Then mMaxSideCandidates = 3

    If mMaxSideCandidates > 18 Then mMaxSideCandidates = 18

    mUnknownThreshold = GetSettingDouble(ROW_UNKNOWN_THRESHOLD, DEFAULT_UNKNOWN_THRESHOLD)

    mVoucherThreshold = GetSettingDouble(ROW_VOUCHER_THRESHOLD, DEFAULT_VOUCHER_THRESHOLD)

    mEnableOneToOne = SettingYes(ROW_ENABLE_ONE_TO_ONE, True)

    mEnableOneToMany = SettingYes(ROW_ENABLE_ONE_TO_MANY, True)

    mEnableManyToOne = SettingYes(ROW_ENABLE_MANY_TO_ONE, True)

    mEnableManyToMany = SettingYes(ROW_ENABLE_MANY_TO_MANY, True)

    mEnableUnknowns = SettingYes(ROW_ENABLE_UNKNOWNS, True)

    mSuppressDuplicateShift = SettingYes(ROW_SUPPRESS_DUPLICATE_SHIFT, True)

    mMaxResults = GetSettingLong(ROW_MAX_RESULTS, DEFAULT_MAX_RESULTS)

    If mMaxResults < 100 Then mMaxResults = 100

    If mMaxResults > 50000 Then mMaxResults = 50000

    mMaxCombosPerBase = GetSettingLong(ROW_MAX_COMBOS_PER_BASE, DEFAULT_MAX_COMBOS_PER_BASE)

    If mMaxCombosPerBase < 50 Then mMaxCombosPerBase = 50

    If mMaxCombosPerBase > 5000 Then mMaxCombosPerBase = 5000

    mMaxMtmPairTests = GetSettingLong(ROW_MAX_MTM_PAIR_TESTS, DEFAULT_MAX_MTM_PAIR_TESTS)

    If mMaxMtmPairTests < 1000 Then mMaxMtmPairTests = 1000

    If mMaxMtmPairTests > 300000 Then mMaxMtmPairTests = 300000

    mVoucherInheritanceAlways = SettingYes(ROW_VOUCHER_INHERITANCE_ALWAYS, True)

    mVoucherUnknowns = SettingYes(ROW_VOUCHER_UNKNOWNS, True)

    mExcludeSummaryKeywords = CellText(GetSheet(SH_MAIN).Cells(ROW_EXCLUDE_SUMMARY_KEYWORDS, COL_VALUE).Value)

    mStopIfTooBroad = SettingYes(ROW_STOP_IF_TOO_BROAD, True)

    mFocusYears = GetSettingLong(ROW_INHERITANCE_FOCUS_YEARS, DEFAULT_INHERITANCE_FOCUS_YEARS)

    If mFocusYears < 1 Then mFocusYears = DEFAULT_INHERITANCE_FOCUS_YEARS

    If mFocusYears > 20 Then mFocusYears = 20

    mMinScore = GetSettingLong(ROW_MIN_SCORE, DEFAULT_MIN_SCORE)

    If mMinScore < 0 Then mMinScore = 0

    If mMinScore > 100 Then mMinScore = 100

    mContextScore = SettingYes(ROW_CONTEXT_SCORE, True)

    mExcludedKeywordList = SplitExcludeKeywords(mExcludeSummaryKeywords)

    mStopRequested = False

    mResultCount = 0

End Sub



Public Sub LoadManualExcludedTxIds(ByVal dict As Object)

    Dim ws As Worksheet, lastR As Long, r As Long, txId As String

    If dict Is Nothing Then Exit Sub

    If Not SheetExists(SH_MANUAL_EXCLUDE) Then Exit Sub

    Set ws = GetSheet(SH_MANUAL_EXCLUDE)

    lastR = LastRow(ws, 1)

    For r = 2 To lastR

        txId = CellText(ws.Cells(r, 1).Value)

        If Len(txId) > 0 Then

            If Not dict.Exists(txId) Then dict.Add txId, True

        End If

    Next r

End Sub





Private Sub LoadManualStateOverrides(ByVal voucherDict As Object, ByVal decisionDict As Object, ByVal memoDict As Object)

    Dim ws As Worksheet, lastR As Long, r As Long, k As String

    If voucherDict Is Nothing Or decisionDict Is Nothing Or memoDict Is Nothing Then Exit Sub

    If Not SheetExists(SH_MANUAL_STATE) Then Exit Sub

    Set ws = GetSheet(SH_MANUAL_STATE)

    lastR = LastRow(ws, 1)

    For r = 2 To lastR

        k = CellText(ws.Cells(r, 1).Value)

        If Len(k) > 0 Then

            If Len(CellText(ws.Cells(r, 3).Value)) > 0 Then voucherDict(k) = CellText(ws.Cells(r, 3).Value)

            If Len(CellText(ws.Cells(r, 4).Value)) > 0 Then decisionDict(k) = CellText(ws.Cells(r, 4).Value)

            If Len(CellText(ws.Cells(r, 5).Value)) > 0 Then memoDict(k) = CellText(ws.Cells(r, 5).Value)

        End If

    Next r

End Sub



Private Sub LoadTransactionRecords(ByRef outs As Collection, ByRef ins As Collection, ByRef outByDate As Object, ByRef insByDate As Object)

    Dim ws As Worksheet, lastR As Long, r As Long, data As Variant

    Dim colTx As Long, colAcc As Long, colPerson As Long, colName As Long, colRel As Long

    Dim colBank As Long, colBranch As Long, colType As Long, colNo As Long, colDate As Long, colTime As Long

    Dim colOut As Long, colIn As Long, colShop As Long, colShopFilled As Long, colShopConverted As Long, colShopFinal As Long

    Dim colSummary As Long, colOther As Long, colAfterBalance As Long, colAfterBalanceRaw As Long

    Dim colRowKind As Long, colStatus As Long

    Dim d As Object, txDate As Variant, outAmt As Double, inAmt As Double, dateKey As String, afterBalanceValue As Variant
    Dim duplicateTxCount As Long, bothAmountCount As Long



    Set ws = GetSheet(SH_WORK_TX)

    colTx = FirstHeaderColumn(ws, Array("���ID"), 1)

    colAcc = FirstHeaderColumn(ws, Array("����ID"), 1)

    colPerson = FirstHeaderColumn(ws, Array("�l��ID"), 1)

    colName = FirstHeaderColumn(ws, Array("����", "�����\��"), 1)

    colRel = FirstHeaderColumn(ws, Array("����"), 1)

    colBank = FirstHeaderColumn(ws, Array("��s��"), 1)

    colBranch = FirstHeaderColumn(ws, Array("�x�X��"), 1)

    colType = FirstHeaderColumn(ws, Array("�Ȗ�"), 1)

    colNo = FirstHeaderColumn(ws, Array("�����ԍ�"), 1)

    colDate = FirstHeaderColumn(ws, Array("���t", "�����"), 1)

    colTime = FirstHeaderColumn(ws, Array("����", "�������", "����"), 1)

    colOut = FirstHeaderColumn(ws, Array("�o��"), 1)

    colIn = FirstHeaderColumn(ws, Array("����"), 1)

    colShop = FirstHeaderColumn(ws, Array("�戵�X����", "�戵�X"), 1)

    colShopFilled = FirstHeaderColumn(ws, Array("�戵�X�⊮�l"), 1)

    colShopConverted = FirstHeaderColumn(ws, Array("�戵�X�ϊ���"), 1)

    colShopFinal = FirstHeaderColumn(ws, Array("�戵�X�m��l"), 1)

    colSummary = FirstHeaderColumn(ws, Array("�E�v", "�E�v��"), 1)

    colOther = FirstHeaderColumn(ws, Array("���̑�"), 1)
    colAfterBalance = FirstHeaderColumn(ws, Array("�����c��"), 1)
    colAfterBalanceRaw = FirstHeaderColumn(ws, Array("�����c������"), 1)

    colRowKind = FirstHeaderColumn(ws, Array("���s���", "�s���"), 1)

    colStatus = FirstHeaderColumn(ws, Array("�f�[�^���"), 1)



    If colTx = 0 Or colDate = 0 Or colOut = 0 Or colIn = 0 Then Err.Raise vbObjectError + 9501, "LoadTransactionRecords", "T_����̕K�{�񂪕s�����Ă��܂��B"



    lastR = LastRow(ws, colTx)

    If lastR < 2 Then Exit Sub

    data = ws.Range(ws.Cells(1, 1), ws.Cells(lastR, LastUsedColumnFast(ws))).Value



    For r = 2 To UBound(data, 1)

        If colRowKind > 0 Then

            If Len(CellText(ArrayCell(data, r, colRowKind))) > 0 And CellText(ArrayCell(data, r, colRowKind)) <> "���" Then GoTo NextTransactionRecord

        End If

        If colStatus > 0 Then

            If CellText(ArrayCell(data, r, colStatus)) = "���" Then GoTo NextTransactionRecord

        End If

        txDate = ToDateOrEmpty(ArrayCell(data, r, colDate))

        outAmt = NzDbl(ArrayCell(data, r, colOut), 0)

        inAmt = NzDbl(ArrayCell(data, r, colIn), 0)

        If Len(CellText(ArrayCell(data, r, colTx))) > 0 And IsDate(txDate) Then

            Set d = CreateObject("Scripting.Dictionary")

            d("Row") = r

            d("TxId") = CellText(ArrayCell(data, r, colTx))

            d("AccountId") = ArrayText(data, r, colAcc)

            d("PersonId") = ArrayText(data, r, colPerson)

            d("Name") = ArrayText(data, r, colName)

            d("Relation") = ArrayText(data, r, colRel)

            d("Bank") = ArrayText(data, r, colBank)

            d("Branch") = ArrayText(data, r, colBranch)

            d("AccountType") = ArrayText(data, r, colType)

            d("AccountNo") = ArrayText(data, r, colNo)

            d("Date") = DateValue(CDate(txDate))

            d("DateKey") = CStr(DateOnlySerial(CDate(txDate)))

            ApplyRecordTimeFields d, ArrayCell(data, r, colTime), r

            EnrichTransactionContext d

            d("Out") = outAmt

            d("In") = inAmt

            d("Shop") = GetFinalShopFromArray(data, r, colShopFinal, colShopConverted, colShopFilled, colShop, colBranch)

            d("Summary") = ArrayText(data, r, colSummary)

            d("Other") = ArrayText(data, r, colOther)
            d("BalanceAfterRaw") = ArrayText(data, r, colAfterBalanceRaw)
            afterBalanceValue = TransactionAfterBalanceValue(ArrayCell(data, r, colAfterBalance))
            If Len(CellText(afterBalanceValue)) > 0 Then
                d("BalanceAfter") = CDbl(afterBalanceValue)
                d("BalanceAfterSource") = "�����c��"
            ElseIf colAfterBalance = 0 And Len(CellText(TransactionAfterBalanceValue(d("Other")))) > 0 Then
                '����݊��p�B��22��̋��ʃf�[�^�����A���̑����������c���Ƃ��ēǂށB
                d("BalanceAfter") = CDbl(TransactionAfterBalanceValue(d("Other")))
                d("BalanceAfterSource") = "���`�����̑���"
            End If

            If IsExcludedTransaction(d) Then GoTo NextTransactionRecord

            If outAmt > 0 And inAmt > 0 Then
                bothAmountCount = bothAmountCount + 1
                GoTo NextTransactionRecord
            End If

            If mTxById.Exists(d("TxId")) Then
                duplicateTxCount = duplicateTxCount + 1
            Else
                mTxById.Add d("TxId"), d
            End If

            If outAmt > 0 Or inAmt > 0 Then AddTimeClusterRecord d

            dateKey = d("DateKey")

            If outAmt > 0 Then

                outs.Add d

                AddToDateIndex outByDate, dateKey, d

            End If

            If inAmt > 0 Then

                ins.Add d

                AddToDateIndex insByDate, dateKey, d

            End If

        End If

NextTransactionRecord:

    Next r

    If duplicateTxCount > 0 Then AppendLog "����Ǎ�", "�x��", "���ID�d�� " & CStr(duplicateTxCount) & "���B���͂͌p�����܂������A02���ŋ��ʃf�[�^�ۑ����Ď��s���Ă��������B"
    If bothAmountCount > 0 Then AppendLog "����Ǎ�", "�m�F", "�o���E�����������v���X�̍s " & CStr(bothAmountCount) & "�����������͂���u�����܂����B"

End Sub



Private Function ArrayCell(ByRef data As Variant, ByVal r As Long, ByVal c As Long) As Variant

    If c <= 0 Then

        ArrayCell = Empty

    ElseIf c > UBound(data, 2) Then

        ArrayCell = Empty

    Else

        ArrayCell = data(r, c)

    End If

End Function



Private Function ArrayText(ByRef data As Variant, ByVal r As Long, ByVal c As Long) As String

    ArrayText = CellText(ArrayCell(data, r, c))

End Function




Private Function GetCellByCol(ByVal ws As Worksheet, ByVal r As Long, ByVal c As Long) As String
    If c <= 0 Then
        GetCellByCol = ""
    Else
        GetCellByCol = CellText(ws.Cells(r, c).Value)
    End If
End Function

Private Function LastUsedColumnFast(ByVal ws As Worksheet) As Long

    Dim f As Range

    On Error Resume Next

    Set f = ws.Cells.Find(What:="*", After:=ws.Cells(1, 1), LookIn:=xlFormulas, LookAt:=xlPart, SearchOrder:=xlByColumns, SearchDirection:=xlPrevious)

    On Error GoTo 0

    If f Is Nothing Then

        LastUsedColumnFast = 1

    Else

        LastUsedColumnFast = f.Column

    End If

End Function



Private Sub ApplyRecordTimeFields(ByVal rec As Object, ByVal timeValue As Variant, ByVal inputOrder As Long)

    Dim t As Variant

    t = TimeFractionOrEmpty(timeValue)

    If IsEmpty(t) Then

        rec("HasTime") = False

        rec("TimeQuality") = "�����Ȃ�"

        rec("TimeFraction") = 0#

        '�����Ȃ��� 0:00 / �����Ɋ񂹂Ȃ��B���t�{���ד������ł������ׁA���������͒f�肵�Ȃ��B
        rec("DateTimeSort") = CDbl(DateOnlySerial(rec("Date"))) + InputOrderFraction(inputOrder)

    Else

        rec("HasTime") = True

        rec("TimeQuality") = "��������"

        rec("TimeFraction") = CDbl(t)

        rec("DateTimeSort") = CDbl(DateOnlySerial(rec("Date"))) + CDbl(t)

    End If

    rec("InputOrder") = inputOrder

End Sub

Private Function InputOrderFraction(ByVal inputOrder As Long) As Double

    If inputOrder <= 0 Then Exit Function

    InputOrderFraction = CDbl(inputOrder Mod 100000) / 100000000#

End Function




Private Sub EnrichTransactionContext(ByVal rec As Object)

    Dim personId As String, txDate As Date, ageYears As Long

    If rec Is Nothing Then Exit Sub

    rec("AgeAtTx") = ""

    rec("AgeYearsAtTx") = -1

    rec("AddressAtTx") = ""

    rec("AddressKeyAtTx") = ""

    rec("AddressChangeNearTx") = ""
    rec("RelatedMoveNearTx") = ""

    personId = CStr(rec("PersonId"))

    If Len(personId) = 0 Or Not IsDate(rec("Date")) Then Exit Sub

    txDate = CDate(rec("Date"))

    rec("AgeAtTx") = PersonAgeAtDate(personId, txDate)

    ageYears = PersonAgeYearsAtDate(personId, txDate)

    rec("AgeYearsAtTx") = ageYears

    rec("AddressAtTx") = PersonAddressAtDate(personId, txDate, False)

    rec("AddressKeyAtTx") = PersonAddressAtDate(personId, txDate, True)

    rec("AddressChangeNearTx") = AddressChangeNearDate(personId, txDate, DEFAULT_MOVE_NEAR_WINDOW_DAYS)

    rec("RelatedMoveNearTx") = RelatedMoveNearTransaction(personId, txDate, DEFAULT_MOVE_NEAR_WINDOW_DAYS)

End Sub

Private Sub AddTimeClusterRecord(ByVal rec As Object)

    Dim k As String, col As Collection

    If rec Is Nothing Then Exit Sub

    If mTimeCluster Is Nothing Then Set mTimeCluster = CreateObject("Scripting.Dictionary")

    k = TimeClusterKey(rec)

    If Len(k) = 0 Then Exit Sub

    If mTimeCluster.Exists(k) Then

        Set col = mTimeCluster(k)

    Else

        Set col = New Collection

        mTimeCluster.Add k, col

    End If

    UpdateAccountOperationPatternCount col, rec

    col.Add rec

End Sub

Private Sub UpdateAccountOperationPatternCount(ByVal existingRecords As Collection, ByVal rec As Object)

    Dim other As Object, acc As String, otherAcc As String, personId As String, otherPersonId As String

    If existingRecords Is Nothing Then Exit Sub

    If rec Is Nothing Then Exit Sub

    acc = CStr(rec("AccountId"))

    personId = CStr(rec("PersonId"))

    If Len(acc) = 0 Then Exit Sub

    If mAccountOperationPatternCount Is Nothing Then Set mAccountOperationPatternCount = CreateObject("Scripting.Dictionary")

    For Each other In existingRecords

        otherAcc = CStr(other("AccountId"))

        otherPersonId = CStr(other("PersonId"))

        If Len(otherAcc) > 0 Then

            If otherAcc <> acc Or otherPersonId <> personId Then

                IncrementAccountOperationPattern acc

                IncrementAccountOperationPattern otherAcc

            End If

        End If

    Next other

End Sub

Private Sub IncrementAccountOperationPattern(ByVal accountId As String)

    If Len(accountId) = 0 Then Exit Sub

    If mAccountOperationPatternCount Is Nothing Then Set mAccountOperationPatternCount = CreateObject("Scripting.Dictionary")

    If mAccountOperationPatternCount.Exists(accountId) Then

        mAccountOperationPatternCount(accountId) = CLng(mAccountOperationPatternCount(accountId)) + 1

    Else

        mAccountOperationPatternCount.Add accountId, 1

    End If

End Sub

Private Function NearbyTimeClusterRecords(ByVal rec As Object) As Collection

    Dim result As New Collection, dayKey As Long, bucket As Long, offset As Long, k As String, src As Collection, item As Object

    Set NearbyTimeClusterRecords = result

    If rec Is Nothing Then Exit Function

    If mTimeCluster Is Nothing Then Exit Function

    If Not KeyExists(rec, "HasTime") Then Exit Function

    If Not CBool(rec("HasTime")) Then Exit Function

    dayKey = DateOnlySerial(rec("Date"))

    If dayKey = 0 Then Exit Function

    bucket = CLng(Fix(CDbl(rec("TimeFraction")) * 1440# / 15#))

    For offset = -1 To 1

        k = CStr(dayKey) & "|" & CStr(bucket + offset)

        If mTimeCluster.Exists(k) Then

            Set src = mTimeCluster(k)

            For Each item In src

                result.Add item

            Next item

        End If

    Next offset

End Function

Private Function TimeClusterKey(ByVal rec As Object) As String

    Dim dayKey As Long, bucket As Long

    If rec Is Nothing Then Exit Function

    If Not KeyExists(rec, "HasTime") Then Exit Function

    If Not CBool(rec("HasTime")) Then Exit Function

    dayKey = DateOnlySerial(rec("Date"))

    If dayKey = 0 Then Exit Function

    bucket = CLng(Fix(CDbl(rec("TimeFraction")) * 1440# / 15#))

    TimeClusterKey = CStr(dayKey) & "|" & CStr(bucket)

End Function

Private Function TimeBucketMinutes(ByVal rec As Object) As Long

    If rec Is Nothing Then Exit Function

    If KeyExists(rec, "HasTime") And CBool(rec("HasTime")) Then TimeBucketMinutes = CLng(Fix(CDbl(rec("TimeFraction")) * 1440# / 15#)) * 15

End Function

Private Function TimeFractionOrEmpty(ByVal v As Variant) As Variant

    Dim s As String, x As Double, hh As Long, mm As Long

    On Error GoTo EH

    If IsError(v) Or IsNull(v) Or IsEmpty(v) Then Exit Function

    s = CellText(v)

    On Error Resume Next
    s = StrConv(s, vbNarrow)
    On Error GoTo EH

    If Len(s) = 0 Then Exit Function

    s = Replace$(s, "�F", ":")
    s = Replace$(s, "��", ":")
    s = Replace$(s, "��", "")
    s = Replace$(s, " ", "")
    s = Replace$(s, "�@", "")



    ' ���l���͂͐�Ɏ����Ƃ��ĉ��߂���B1200 ����t�V���A���������� 0:00 �ɂ��Ȃ����߁B

    If IsNumeric(s) Then

        x = CDbl(s)

        If x >= 0 And x < 1 Then

            TimeFractionOrEmpty = x

            Exit Function

        End If

        If x >= 100 And x <= 2359 Then

            hh = CLng(Fix(x / 100#))

            mm = CLng(x - hh * 100)

            If hh >= 0 And hh < 24 And mm >= 0 And mm < 60 Then

                TimeFractionOrEmpty = (hh * 60# + mm) / 1440#

                Exit Function

            End If

        End If

        If x >= 0 And x < 24 Then

            TimeFractionOrEmpty = x / 24#

            Exit Function

        End If

    End If



    If InStr(1, s, ":", vbTextCompare) > 0 Then

        x = CDbl(CDate(s)) - Int(CDbl(CDate(s)))

        TimeFractionOrEmpty = x

        Exit Function

    End If



    If IsDate(v) Then

        x = CDbl(CDate(v)) - Int(CDbl(CDate(v)))

        If x < 0 Then x = 0

        TimeFractionOrEmpty = x

        Exit Function

    End If

    Exit Function

EH:

    TimeFractionOrEmpty = Empty

End Function



Private Function DateOnlySerial(ByVal v As Variant) As Long

    If IsDate(v) Then DateOnlySerial = CLng(DateValue(CDate(v)))

End Function



Private Function GetFinalShopFromArray(ByRef data As Variant, _
        ByVal r As Long, _
        ByVal colShopFinal As Long, _
        ByVal colShopConverted As Long, _
        ByVal colShopFilled As Long, _
        ByVal colShopRaw As Long, _
        ByVal colBranch As Long) As String

    GetFinalShopFromArray = ArrayText(data, r, colShopFinal)

    If Len(GetFinalShopFromArray) = 0 Then GetFinalShopFromArray = ArrayText(data, r, colShopConverted)

    If Len(GetFinalShopFromArray) = 0 Then GetFinalShopFromArray = ArrayText(data, r, colShopFilled)

    If Len(GetFinalShopFromArray) = 0 Then GetFinalShopFromArray = ArrayText(data, r, colShopRaw)

    If Len(GetFinalShopFromArray) = 0 Then GetFinalShopFromArray = ArrayText(data, r, colBranch)

End Function



Private Sub AddToDateIndex(ByVal idx As Object, ByVal dateKey As String, ByVal rec As Object)

    Dim col As Collection

    If idx.Exists(dateKey) Then

        Set col = idx(dateKey)

    Else

        Set col = New Collection

        idx.Add dateKey, col

    End If

    col.Add rec

End Sub



Private Sub FindOneToOne(ByVal outs As Collection, ByVal insByDate As Object)

    Dim o As Object, candidates As Collection, i As Long, recIn As Object

    For Each o In outs

        If ResultLimitReached() Then Exit Sub

        If Not ShouldSkipShiftRecord(o) And CDbl(o("Out")) >= mMinShift Then

            Set candidates = CandidateRecordsByFlow(insByDate, o, mDateWindow, mMaxSideCandidates * 3, True)

            For i = 1 To candidates.Count

                If ResultLimitReached() Then Exit Sub

                Set recIn = candidates(i)

                If Not ShouldSkipShiftRecord(recIn) And CDbl(recIn("In")) >= mMinShift Then

                    If AmountClose(CDbl(o("Out")), CDbl(recIn("In"))) Then

                        AddAnalysisCandidate "1��1", CollectionFromOne(o), CollectionFromOne(recIn)

                    End If

                End If

            Next i

        End If

    Next o

End Sub



Private Sub FindOneToMany(ByVal outs As Collection, ByVal insByDate As Object)

    Dim o As Object, candidates As Collection, combos As Collection, c As Object, i As Long

    If mMaxCombo < 2 Then Exit Sub

    For Each o In outs

        If ResultLimitReached() Then Exit Sub

        If Not ShouldSkipShiftRecord(o) And CDbl(o("Out")) >= mMinShift Then

            Set candidates = CandidateRecordsByFlow(insByDate, o, mDateWindow, mMaxSideCandidates, True)

            Set candidates = FilterCandidatesForShift(candidates)

            Set combos = BuildCombosNearAmount(candidates, 2, mMaxCombo, CDbl(o("Out")))

            For i = 1 To combos.Count

                If ResultLimitReached() Then Exit Sub

                Set c = combos(i)

                AddAnalysisCandidate "1�Ε���", CollectionFromOne(o), c("Records")

            Next i

        End If

    Next o

End Sub



Private Sub FindManyToOne(ByVal ins As Collection, ByVal outByDate As Object)

    Dim recIn As Object, candidates As Collection, combos As Collection, c As Object, i As Long

    If mMaxCombo < 2 Then Exit Sub

    For Each recIn In ins

        If ResultLimitReached() Then Exit Sub

        If Not ShouldSkipShiftRecord(recIn) And CDbl(recIn("In")) >= mMinShift Then

            Set candidates = CandidateRecordsByFlow(outByDate, recIn, mDateWindow, mMaxSideCandidates, False)

            Set candidates = FilterCandidatesForShift(candidates)

            Set combos = BuildCombosNearAmount(candidates, 2, mMaxCombo, CDbl(recIn("In")), True)

            For i = 1 To combos.Count

                If ResultLimitReached() Then Exit Sub

                Set c = combos(i)

                AddAnalysisCandidate "������1", c("Records"), CollectionFromOne(recIn)

            Next i

        End If

    Next recIn

End Sub



Private Sub FindManyToMany(ByVal outs As Collection, ByVal ins As Collection, ByVal outByDate As Object, ByVal insByDate As Object)

    Dim base As Object, outCandidates As Collection, inCandidates As Collection

    Dim outCombos As Collection, inCombos As Collection, inComboIndex As Object, matches As Collection

    Dim co As Object, ci As Object, i As Long, j As Long, pairTests As Long

    If mMaxCombo < 2 Then Exit Sub



    For Each base In outs

        If ResultLimitReached() Then Exit Sub

        If Not ShouldSkipShiftRecord(base) And CDbl(base("Out")) >= mMinShift Then

            Set outCandidates = CandidateRecordsByDate(outByDate, CDate(base("Date")), mDateWindow, mMaxSideCandidates)

            Set inCandidates = CandidateRecordsByFlow(insByDate, base, mDateWindow, mMaxSideCandidates, True)

            Set outCandidates = FilterCandidatesForShift(outCandidates)

            Set inCandidates = FilterCandidatesForShift(inCandidates)

            Set outCombos = BuildCombos(outCandidates, 2, mMaxCombo, True)

            Set inCombos = BuildCombos(inCandidates, 2, mMaxCombo)

            Set inComboIndex = BuildComboAmountIndex(inCombos)

            pairTests = 0

            For i = 1 To outCombos.Count

                If ResultLimitReached() Then Exit Sub

                Set co = outCombos(i)

                If CDbl(co("Sum")) >= mMinShift Then

                    Set matches = CandidateCombosByAmountIndexed(inComboIndex, CDbl(co("Sum")))

                    For j = 1 To matches.Count

                        pairTests = pairTests + 1

                        If pairTests > mMaxMtmPairTests Then Exit For

                        Set ci = matches(j)

                        AddAnalysisCandidate "�����Ε���", co("Records"), ci("Records")

                        If ResultLimitReached() Then Exit Sub

                    Next j

                End If

                If pairTests > mMaxMtmPairTests Then Exit For

            Next i

        End If

    Next base

End Sub



Private Sub FindUnknowns(ByVal outs As Collection, ByVal ins As Collection)

    Dim o As Object, i As Object

    For Each o In outs

        If ResultLimitReached() Then Exit Sub

        If CDbl(o("Out")) >= mUnknownThreshold Then

            If Not mSuppressDuplicateShift Or Not mMatched.Exists(CStr(o("TxId"))) Then

                AddUnknownCandidate KIND_UNKNOWN_OUT, o

            End If

        End If

    Next o

    For Each i In ins

        If ResultLimitReached() Then Exit Sub

        If CDbl(i("In")) >= mUnknownThreshold Then

            If Not mSuppressDuplicateShift Or Not mMatched.Exists(CStr(i("TxId"))) Then

                AddUnknownCandidate KIND_UNKNOWN_IN, i

            End If

        End If

    Next i

End Sub



Private Function ValidateComplexityBeforeRun(ByVal outCount As Long, ByVal inCount As Long) As Boolean

    ValidateComplexityBeforeRun = True

    If Not mStopIfTooBroad Then Exit Function

    If mMaxCombo > 10 Then

        MsgBox "�ő�g����������10���܂łł��B�ݒ���������Ă��������B", vbExclamation

        ValidateComplexityBeforeRun = False

        Exit Function

    End If

    If mEnableManyToMany And mMaxCombo >= 6 Then

        ValidateComplexityBeforeRun = (MsgBox("�ő�g�����������傫�߂ł��B" & vbCrLf & _
                                              "���̃c�[���͌�␶������E�ƍ�����Ŏ~�߂邽�ߖ�������O(n^k)�����ɂ͂��܂��񂪁A���R��⏈�����ԑ����͋N���蓾�܂��B���s���܂����B", vbQuestion + vbYesNo) = vbYes)

        If Not ValidateComplexityBeforeRun Then Exit Function

    End If

    If mEnableManyToMany And mMaxCombo >= 3 And mDateWindow > 7 And mMaxSideCandidates > 12 Then

        ValidateComplexityBeforeRun = (MsgBox("�����Ε����̏������L�߂ł��B�������d���Ȃ�\��������܂��B" & vbCrLf & _
                                              "���t���e�����E������E�ő�g�����������i�邱�Ƃ𐄏����܂��B���s���܂����B", vbQuestion + vbYesNo) = vbYes)

        Exit Function

    End If

    If outCount * inCount > 5000000# And mEnableManyToMany Then

        ValidateComplexityBeforeRun = (MsgBox("��������������A�����Ε������܂߂�Əd���Ȃ�\��������܂��B" & vbCrLf & _
                                              "���1��1�E1�Ε����E������1�����ŕ��͂��邱�Ƃ𐄏����܂��B���s���܂����B", vbQuestion + vbYesNo) = vbYes)

    End If

End Function



Private Function ResultLimitReached() As Boolean

    If mStopRequested Then

        ResultLimitReached = True

        Exit Function

    End If

    If mMaxResults > 0 Then

        If mResultCount >= mMaxResults Then

            mStopRequested = True

            AppendLog "���͏��", "��~", "�ő��⌏���ɒB���܂���: " & CStr(mMaxResults)

            ResultLimitReached = True

        End If

    End If

End Function



Private Function ShouldSkipShiftRecord(ByVal rec As Object) As Boolean

    ' ����P�ʂ̎蓮���O�����������ŏ��O����B

    ' ��x��≻��������𑦍��ɊO���ƁA���Ó��ȕʌ����E���Ȃ��댯�����邽�߁A

    ' ��␶�����͐撅���Ŏ����ׂ��Ȃ��B

    Dim txId As String

    txId = CStr(rec("TxId"))

    ShouldSkipShiftRecord = False

    If Not mManualExcludedTxIds Is Nothing Then

        If mManualExcludedTxIds.Exists(txId) Then ShouldSkipShiftRecord = True

    End If

End Function



Private Function FilterCandidatesForShift(ByVal records As Collection) As Collection

    Dim out As New Collection, rec As Object

    For Each rec In records

        If Not ShouldSkipShiftRecord(rec) Then out.Add rec

    Next rec

    Set FilterCandidatesForShift = out

End Function



Private Function IsExcludedTransaction(ByVal rec As Object) As Boolean

    Dim i As Long, s As String, w As String

    IsExcludedTransaction = False

    If IsEmpty(mExcludedKeywordList) Then Exit Function

    s = CStr(rec("Summary")) & " " & CStr(rec("Other"))

    For i = LBound(mExcludedKeywordList) To UBound(mExcludedKeywordList)

        w = CStr(mExcludedKeywordList(i))

        If Len(w) > 0 Then

            If InStr(1, s, w, vbTextCompare) > 0 Then

                IsExcludedTransaction = True

                Exit Function

            End If

        End If

    Next i

End Function



Private Function SplitExcludeKeywords(ByVal keywordsText As String) As Variant

    Dim raw As Variant, out() As String, i As Long, n As Long, w As String

    If Len(Trim$(keywordsText)) = 0 Then

        SplitExcludeKeywords = Empty

        Exit Function

    End If

    raw = Split(keywordsText, ",")

    ReDim out(0 To UBound(raw))

    For i = LBound(raw) To UBound(raw)

        w = Trim$(CStr(raw(i)))

        If Len(w) > 0 Then

            out(n) = w

            n = n + 1

        End If

    Next i

    If n = 0 Then

        SplitExcludeKeywords = Empty

    Else

        ReDim Preserve out(0 To n - 1)

        SplitExcludeKeywords = out

    End If

End Function



Private Function VoucherFlagForCandidate(ByVal kindText As String, ByVal amountValue As Double) As String

    If kindText = KIND_INHERITANCE_SHIFT And mVoucherInheritanceAlways Then

        VoucherFlagForCandidate = VOUCHER_YES

    ElseIf amountValue >= mVoucherThreshold Then

        VoucherFlagForCandidate = VOUCHER_YES

    Else

        VoucherFlagForCandidate = VOUCHER_NO

    End If

End Function



Private Function VoucherFlagForUnknown(ByVal amountValue As Double) As String

    If mVoucherUnknowns And amountValue >= mVoucherThreshold Then

        VoucherFlagForUnknown = VOUCHER_YES

    Else

        VoucherFlagForUnknown = VOUCHER_NO

    End If

End Function



Private Function CandidateRecordsByDate(ByVal idx As Object, ByVal baseDate As Date, ByVal windowDays As Long, ByVal limitCount As Long) As Collection

    ' ����ɋ߂����Ō�≻����B���t�� DateValue �Ŋۂ߁A�����̒[���œ��t�L�[������Ȃ��悤�ɂ���B

    Dim out As New Collection, offset As Long, k As String, col As Collection, ordered As Collection, i As Long

    Dim offsets As Collection, v As Variant

    Set offsets = New Collection

    offsets.Add 0

    For offset = 1 To windowDays

        offsets.Add -offset

        offsets.Add offset

    Next offset

    For Each v In offsets

        k = CStr(DateOnlySerial(baseDate) + CLng(v))

        If idx.Exists(k) Then

            Set col = idx(k)

            Set ordered = SortCandidateCollection(col, Nothing, True)

            For i = 1 To ordered.Count

                out.Add ordered(i)

                If out.Count >= limitCount Then

                    Set CandidateRecordsByDate = out

                    Exit Function

                End If

            Next i

        End If

    Next v

    Set CandidateRecordsByDate = out

End Function



Private Function CandidateRecordsByFlow(ByVal idx As Object, _
        ByVal baseRec As Object, _
        ByVal windowDays As Long, _
        ByVal limitCount As Long, _
        ByVal wantInSide As Boolean) As Collection

    ' wantInSide=True  : baseRec �͏o���B�������͓����Ȍゾ���B�������o���ɂ���� base �o�������Ȍゾ���B

    ' wantInSide=False : baseRec �͓����B���o���͓����ȑO�����B�������o���ɂ���� base ���������ȑO�����B

    Dim out As New Collection, offset As Long, k As String, col As Collection, ordered As Collection, i As Long, rec As Object

    If baseRec Is Nothing Then

        Set CandidateRecordsByFlow = out

        Exit Function

    End If



    For offset = 0 To windowDays

        If wantInSide Then

            k = CStr(DateOnlySerial(baseRec("Date")) + offset)

        Else

            k = CStr(DateOnlySerial(baseRec("Date")) - offset)

        End If

        If idx.Exists(k) Then

            Set col = idx(k)

            Set ordered = SortCandidateCollection(col, baseRec, wantInSide)

            For i = 1 To ordered.Count

                Set rec = ordered(i)

                If IsDirectionalRecordPairPossible(baseRec, rec, wantInSide) Then

                    out.Add rec

                    If out.Count >= limitCount Then

                        Set CandidateRecordsByFlow = out

                        Exit Function

                    End If

                End If

            Next i

        End If

    Next offset

    Set CandidateRecordsByFlow = out

End Function



Private Function IsDirectionalRecordPairPossible(ByVal baseRec As Object, ByVal candidateRec As Object, ByVal wantInSide As Boolean) As Boolean

    Dim baseDay As Long, candDay As Long

    IsDirectionalRecordPairPossible = True

    If baseRec Is Nothing Or candidateRec Is Nothing Then Exit Function

    baseDay = DateOnlySerial(baseRec("Date"))

    candDay = DateOnlySerial(candidateRec("Date"))

    If baseDay = 0 Or candDay = 0 Then Exit Function



    If wantInSide Then

        ' base �o�� �� candidate ����

        If candDay < baseDay Then IsDirectionalRecordPairPossible = False: Exit Function

        If candDay = baseDay And CBool(baseRec("HasTime")) And CBool(candidateRec("HasTime")) Then

            If CDbl(candidateRec("TimeFraction")) + 0.00000001 < CDbl(baseRec("TimeFraction")) Then IsDirectionalRecordPairPossible = False

        End If

    Else

        ' candidate �o�� �� base ����

        If candDay > baseDay Then IsDirectionalRecordPairPossible = False: Exit Function

        If candDay = baseDay And CBool(baseRec("HasTime")) And CBool(candidateRec("HasTime")) Then

            If CDbl(candidateRec("TimeFraction")) > CDbl(baseRec("TimeFraction")) + 0.00000001 Then IsDirectionalRecordPairPossible = False

        End If

    End If

End Function



Private Function SortCandidateCollection(ByVal records As Collection, ByVal baseRec As Object, ByVal wantInSide As Boolean) As Collection

    Dim out As New Collection, rec As Object, i As Long, inserted As Boolean

    For Each rec In records

        inserted = False

        For i = 1 To out.Count

            If CandidateSortKey(rec, baseRec, wantInSide) < CandidateSortKey(out(i), baseRec, wantInSide) Then

                out.Add rec, , i

                inserted = True

                Exit For

            End If

        Next i

        If Not inserted Then out.Add rec

    Next rec

    Set SortCandidateCollection = out

End Function



Private Function CandidateSortKey(ByVal rec As Object, ByVal baseRec As Object, ByVal wantInSide As Boolean) As Double

    Dim keyValue As Double, baseDay As Long, recDay As Long, recTimePenalty As Double

    If rec Is Nothing Then CandidateSortKey = 999999999#: Exit Function

    recDay = DateOnlySerial(rec("Date"))

    If Not baseRec Is Nothing Then

        baseDay = DateOnlySerial(baseRec("Date"))

        keyValue = Abs(recDay - baseDay) * 1000000#

        If recDay = baseDay Then

            If CBool(rec("HasTime")) And CBool(baseRec("HasTime")) Then

                keyValue = keyValue + Abs(CDbl(rec("TimeFraction")) - CDbl(baseRec("TimeFraction"))) * 100000#

            ElseIf CBool(rec("HasTime")) Then

                keyValue = keyValue + CDbl(rec("TimeFraction")) * 1000#

            Else

                keyValue = keyValue + 5000#

            End If

        Else

            If CBool(rec("HasTime")) Then keyValue = keyValue + CDbl(rec("TimeFraction")) * 1000#

        End If

    Else

        keyValue = recDay * 1000000#

        If CBool(rec("HasTime")) Then

            keyValue = keyValue + CDbl(rec("TimeFraction")) * 100000#

        Else

            keyValue = keyValue + 5000#

        End If

    End If

    If KeyExists(rec, "InputOrder") Then keyValue = keyValue + CDbl(rec("InputOrder")) / 1000000#

    CandidateSortKey = keyValue

End Function



Private Function CollectionFromOne(ByVal rec As Object) As Collection

    Dim c As New Collection

    c.Add rec

    Set CollectionFromOne = c

End Function



Private Function BuildCombos(ByVal records As Collection, ByVal minDepth As Long, ByVal maxDepth As Long, Optional ByVal useOut As Boolean = False) As Collection

    Dim result As New Collection, tmp As New Collection

    Dim target As Long, maxOutCombos As Long

    maxOutCombos = mMaxCombosPerBase

    If records.Count = 0 Then

        Set BuildCombos = result

        Exit Function

    End If

    For target = minDepth To Application.Min(maxDepth, records.Count)

        BuildCombosRec records, 1, target, tmp, result, useOut, maxOutCombos

        If result.Count >= maxOutCombos Then Exit For

    Next target

    Set BuildCombos = result

End Function



Private Function BuildCombosNearAmount(ByVal records As Collection, _
        ByVal minDepth As Long, _
        ByVal maxDepth As Long, _
        ByVal targetAmount As Double, _
        Optional ByVal useOut As Boolean = False) As Collection

    ' 1�Ε����E������1�ł́A�S�g����������Ă�����z���肷��̂ł͂Ȃ��A

    ' �ڕW�z�{���e���𒴂������_�Ŏ}���肷��B���x�͗��Ƃ����A�g����������}����B

    Dim result As New Collection, tmp As New Collection

    Dim targetDepth As Long, maxOutCombos As Long, tol As Double

    maxOutCombos = mMaxCombosPerBase

    If records Is Nothing Then

        Set BuildCombosNearAmount = result

        Exit Function

    End If

    If records.Count = 0 Or targetAmount <= 0 Then

        Set BuildCombosNearAmount = result

        Exit Function

    End If

    tol = EffectiveTolerance(targetAmount, targetAmount)

    For targetDepth = minDepth To Application.Min(maxDepth, records.Count)

        BuildCombosNearAmountRec records, 1, targetDepth, tmp, result, useOut, maxOutCombos, targetAmount, tol, 0#

        If result.Count >= maxOutCombos Then Exit For

    Next targetDepth

    Set BuildCombosNearAmount = result

End Function



Private Sub BuildCombosNearAmountRec(ByVal records As Collection, _
        ByVal startIdx As Long, _
        ByVal targetDepth As Long, _
        ByVal tmp As Collection, _
        ByVal result As Collection, _
        ByVal useOut As Boolean, _
        ByVal maxOutCombos As Long, _
        ByVal targetAmount As Double, _
        ByVal tol As Double, _
        ByVal currentSum As Double)

    Dim i As Long, amountValue As Double

    If result.Count >= maxOutCombos Then Exit Sub

    If currentSum > targetAmount + tol Then Exit Sub

    If tmp.Count = targetDepth Then

        If Abs(currentSum - targetAmount) <= EffectiveTolerance(currentSum, targetAmount) Then result.Add ComboObject(tmp, useOut)

        Exit Sub

    End If

    For i = startIdx To records.Count

        If useOut Then

            amountValue = CDbl(records(i)("Out"))

        Else

            amountValue = CDbl(records(i)("In"))

        End If

        If amountValue > 0 Then

            tmp.Add records(i)

            BuildCombosNearAmountRec records, i + 1, targetDepth, tmp, result, useOut, maxOutCombos, targetAmount, tol, currentSum + amountValue

            tmp.Remove tmp.Count

            If result.Count >= maxOutCombos Then Exit For

        End If

    Next i

End Sub



Private Sub BuildCombosRec(ByVal records As Collection, _
        ByVal startIdx As Long, _
        ByVal targetDepth As Long, _
        ByVal tmp As Collection, _
        ByVal result As Collection, _
        ByVal useOut As Boolean, _
        ByVal maxOutCombos As Long)

    Dim i As Long

    If result.Count >= maxOutCombos Then Exit Sub

    If tmp.Count = targetDepth Then

        result.Add ComboObject(tmp, useOut)

        Exit Sub

    End If

    For i = startIdx To records.Count

        tmp.Add records(i)

        BuildCombosRec records, i + 1, targetDepth, tmp, result, useOut, maxOutCombos

        tmp.Remove tmp.Count

        If result.Count >= maxOutCombos Then Exit For

    Next i

End Sub



Private Function ComboObject(ByVal recs As Collection, ByVal useOut As Boolean) As Object

    Dim d As Object, r As Object, sumAmt As Double, copy As New Collection, ids As String

    Set d = CreateObject("Scripting.Dictionary")

    For Each r In recs

        copy.Add r

        If useOut Then

            sumAmt = sumAmt + CDbl(r("Out"))

        Else

            sumAmt = sumAmt + CDbl(r("In"))

        End If

        If Len(ids) > 0 Then ids = ids & ","

        ids = ids & CStr(r("TxId"))

    Next r

    d.Add "Records", copy

    d.Add "Sum", sumAmt

    d.Add "Ids", ids

    Set ComboObject = d

End Function



Private Function AmountClose(ByVal outAmt As Double, ByVal inAmt As Double) As Boolean

    AmountClose = (Abs(outAmt - inAmt) <= EffectiveTolerance(outAmt, inAmt))

End Function



Private Function EffectiveTolerance(ByVal outAmt As Double, ByVal inAmt As Double) As Double

    EffectiveTolerance = mAmountTol

    If mAmountRate > 0 Then

        EffectiveTolerance = Application.Max(EffectiveTolerance, Application.Max(outAmt, inAmt) * mAmountRate)

    End If

End Function



Private Function AmountBucketUnit() As Double

    AmountBucketUnit = mAmountTol

    If AmountBucketUnit < 1 Then AmountBucketUnit = 1

End Function



Private Function AmountBucketKey(ByVal amountValue As Double) As Long

    AmountBucketKey = CLng(Fix(amountValue / AmountBucketUnit()))

End Function



Private Function BuildComboAmountIndex(ByVal combos As Collection) As Object

    Dim idx As Object, i As Long, c As Object, k As String, col As Collection

    Set idx = CreateObject("Scripting.Dictionary")

    For i = 1 To combos.Count

        Set c = combos(i)

        k = CStr(AmountBucketKey(CDbl(c("Sum"))))

        If idx.Exists(k) Then

            Set col = idx(k)

        Else

            Set col = New Collection

            idx.Add k, col

        End If

        col.Add c

    Next i

    Set BuildComboAmountIndex = idx

End Function



Private Function CandidateCombosByAmountIndexed(ByVal idx As Object, ByVal amountValue As Double) As Collection

    Dim out As New Collection, tol As Double, unit As Double

    Dim kMin As Long, kMax As Long, k As Long, col As Collection, i As Long, c As Object

    unit = AmountBucketUnit()

    tol = EffectiveTolerance(amountValue, amountValue)

    kMin = CLng(Fix((amountValue - tol) / unit)) - 1

    kMax = CLng(Fix((amountValue + tol) / unit)) + 1

    For k = kMin To kMax

        If idx.Exists(CStr(k)) Then

            Set col = idx(CStr(k))

            For i = 1 To col.Count

                Set c = col(i)

                If AmountClose(amountValue, CDbl(c("Sum"))) Then out.Add c

            Next i

        End If

    Next k

    Set CandidateCombosByAmountIndexed = out

End Function



Private Sub AddAnalysisCandidate(ByVal patternText As String, ByVal outRecords As Collection, ByVal inRecords As Collection)

    If ResultLimitReached() Then Exit Sub

    If Not IsTemporalFlowValid(outRecords, inRecords) Then Exit Sub

    If CollectionsShareValue(outRecords, inRecords, "TxId") Then Exit Sub

    Dim outIds As String, inIds As String, key As String

    outIds = SortedIds(outRecords)

    inIds = SortedIds(inRecords)

    key = patternText & "|O:" & outIds & "|I:" & inIds

    If mDedupe.Exists(key) Then Exit Sub

    mDedupe.Add key, True



    Dim kindText As String, analysisId As String, score As Long

    Dim outSum As Double, inSum As Double, diff As Double

    Dim outPerson As String, inPerson As String, nameRel As String, inhTiming As String, cohab As String

    Dim outDateMin As Variant, outDateMax As Variant, inDateMin As Variant, inDateMax As Variant

    Dim shops As String, summaryText As String, memo As String, voucher As String

    Dim stateKey As String, decisionText As String, operationMemoText As String

    Dim ageHint As String, addressHint As String, temporalHint As String

    analysisId = NextId("���͌��")

    outSum = SumRecords(outRecords, True)

    inSum = SumRecords(inRecords, False)

    diff = outSum - inSum

    kindText = ShiftKindFromOutRecords(outRecords)

    score = ScoreCandidate(outRecords, inRecords, diff)

    stateKey = BuildAnalysisStateKey(patternText, outIds, inIds)

    If score < mMinScore Then

        If mManualDecisionOverrides Is Nothing Then Exit Sub

        If Not mManualDecisionOverrides.Exists(stateKey) Then Exit Sub

    End If

    voucher = VoucherFlagForCandidate(kindText, Application.Max(outSum, inSum))

    decisionText = DECISION_USE

    operationMemoText = "C/D��̓_�u���N���b�N�ŐؑցBM��͎��R�����B"

    If Not mManualVoucherOverrides Is Nothing Then

        If mManualVoucherOverrides.Exists(stateKey) Then voucher = CStr(mManualVoucherOverrides(stateKey))

        If mManualDecisionOverrides.Exists(stateKey) Then decisionText = CStr(mManualDecisionOverrides(stateKey))

        If mManualMemoOverrides.Exists(stateKey) Then operationMemoText = CStr(mManualMemoOverrides(stateKey))

    End If

    decisionText = NormalizeDecisionText(decisionText)

    If IsExcludeDecision(decisionText) Then voucher = VOUCHER_NO

    outPerson = PersonList(outRecords)

    inPerson = PersonList(inRecords)

    nameRel = NameRelation(outRecords, inRecords)

    inhTiming = InheritanceTiming(outRecords)

    cohab = CohabitationText(outRecords, inRecords)

    cohab = JoinNonBlank(cohab, RiskSignalText(outRecords, inRecords), " / ")

    DateMinMax outRecords, outDateMin, outDateMax

    DateMinMax inRecords, inDateMin, inDateMax

    shops = ShopList(outRecords, inRecords)

    summaryText = SummaryList(outRecords, inRecords)

    summaryText = JoinNonBlank(SummaryKeywordFlowHint(outRecords, inRecords), summaryText, " / ")

    temporalHint = TemporalFlowHintText(outRecords, inRecords)

    If Len(temporalHint) > 0 Then summaryText = JoinNonBlank(temporalHint, summaryText, " / ")

    ageHint = AgeHintForRecords(outRecords, inRecords)

    addressHint = AddressHintForRecords(outRecords, inRecords)

    memo = CandidateReasonText(outRecords, inRecords, diff, score, temporalHint)



    WriteResultRow analysisId, kindText, patternText, score, voucher, _
        RecordsDateTimeRangeText(outRecords), RecordsDateTimeRangeText(inRecords), _
        outSum, inSum, diff, outPerson, inPerson, nameRel, inhTiming, cohab, _
        outIds, inIds, shops, summaryText, memo, decisionText, _
        operationMemoText, ageHint, addressHint

    If Not IsExcludeDecision(decisionText) Then

        WriteDetailRows analysisId, kindText, voucher, "�o��", outRecords, True

        WriteDetailRows analysisId, kindText, voucher, "����", inRecords, False

        MarkMatched outRecords, analysisId

        MarkMatched inRecords, analysisId

    End If

End Sub



Private Sub AddUnknownCandidate(ByVal kindText As String, ByVal rec As Object)

    If ResultLimitReached() Then Exit Sub

    Dim analysisId As String, voucher As String, amountValue As Double, idsOut As String, idsIn As String

    Dim outSum As Double, inSum As Double, outDateText As String, inDateText As String

    Dim stateKey As String, decisionText As String, operationMemoText As String

    Dim ageHint As String, addressHint As String, riskHint As String

    analysisId = NextId("���͌��")

    If kindText = KIND_UNKNOWN_OUT Then

        amountValue = CDbl(rec("Out"))

        outSum = amountValue

        idsOut = CStr(rec("TxId"))

        outDateText = RecordDateTimeText(rec)

    Else

        amountValue = CDbl(rec("In"))

        inSum = amountValue

        idsIn = CStr(rec("TxId"))

        inDateText = RecordDateTimeText(rec)

    End If

    voucher = VoucherFlagForUnknown(amountValue)

    decisionText = DECISION_USE

    operationMemoText = "C/D��̓_�u���N���b�N�ŐؑցBM��͎��R�����B"

    stateKey = BuildAnalysisStateKey("�P��", idsOut, idsIn)

    If Not mManualVoucherOverrides Is Nothing Then

        If mManualVoucherOverrides.Exists(stateKey) Then voucher = CStr(mManualVoucherOverrides(stateKey))

        If mManualDecisionOverrides.Exists(stateKey) Then decisionText = CStr(mManualDecisionOverrides(stateKey))

        If mManualMemoOverrides.Exists(stateKey) Then operationMemoText = CStr(mManualMemoOverrides(stateKey))

    End If

    decisionText = NormalizeDecisionText(decisionText)

    If IsExcludeDecision(decisionText) Then voucher = VOUCHER_NO

    ageHint = AgeHintForRecord(rec)

    addressHint = AddressHintForRecord(rec)

    riskHint = RiskSignalForSingle(rec)

    WriteResultRow analysisId, kindText, "�P��", 40, voucher, outDateText, inDateText, outSum, inSum, outSum - inSum, _
                   IIf(kindText = KIND_UNKNOWN_OUT, CStr(rec("Name")), ""), _
                   IIf(kindText = KIND_UNKNOWN_IN, CStr(rec("Name")), ""), _
                   "", IIf(IsAfterInheritanceRecord(rec), "�����J�n��", "�����J�n�O/�s��"), riskHint, _
                   idsOut, idsIn, CStr(rec("Bank")) & " " & CStr(rec("Shop")), CStr(rec("Summary")), "�Ή�����Ȃ�", decisionText, operationMemoText, ageHint, addressHint

    If Not IsExcludeDecision(decisionText) Then

        If kindText = KIND_UNKNOWN_OUT Then

            WriteDetailRows analysisId, kindText, voucher, "�o��", CollectionFromOne(rec), True

        Else

            WriteDetailRows analysisId, kindText, voucher, "����", CollectionFromOne(rec), False

        End If

    End If

End Sub



Private Sub WriteResultRow(ByVal analysisId As String, ByVal kindText As String, ByVal patternText As String, ByVal score As Long, ByVal voucher As String, _
                           ByVal outDateText As String, ByVal inDateText As String, ByVal outSum As Double, ByVal inSum As Double, ByVal diff As Double, _
                           ByVal outPerson As String, ByVal inPerson As String, ByVal nameRel As String, ByVal inhTiming As String, ByVal cohab As String, _
                           ByVal outIds As String, ByVal inIds As String, ByVal shops As String, ByVal summaryText As String, ByVal memo As String, _
                           Optional ByVal decisionText As String = "", Optional ByVal operationMemoText As String = "", _
                           Optional ByVal ageHint As String = "", Optional ByVal addressHint As String = "")

    Dim ws As Worksheet, r As Long

    Set ws = GetSheet(SH_WORK_RESULT)

    If Len(decisionText) = 0 Then decisionText = DECISION_USE

    If Len(operationMemoText) = 0 Then operationMemoText = "C/D��̓_�u���N���b�N�ŐؑցBM��͎��R�����B"

    If mNextResultRow < 2 Then mNextResultRow = LastRow(ws, 1) + 1

    r = mNextResultRow

    mNextResultRow = mNextResultRow + 1

    ws.Cells(r, RES_COL_ID).Value = analysisId

    ws.Cells(r, RES_COL_KIND).Value = kindText

    ws.Cells(r, RES_COL_PATTERN).Value = patternText

    ws.Cells(r, RES_COL_SCORE).Value = score

    ws.Cells(r, RES_COL_VOUCHER).Value = voucher

    ws.Cells(r, RES_COL_OUT_DATE).Value = outDateText

    ws.Cells(r, RES_COL_IN_DATE).Value = inDateText

    ws.Cells(r, RES_COL_OUT_AMOUNT).Value = outSum

    ws.Cells(r, RES_COL_IN_AMOUNT).Value = inSum

    ws.Cells(r, RES_COL_DIFF).Value = diff

    ws.Cells(r, RES_COL_OUT_PERSON).Value = outPerson

    ws.Cells(r, RES_COL_IN_PERSON).Value = inPerson

    ws.Cells(r, RES_COL_NAME_REL).Value = nameRel

    ws.Cells(r, RES_COL_INH_TIMING).Value = inhTiming

    ws.Cells(r, RES_COL_COHAB).Value = cohab

    ws.Cells(r, RES_COL_OUT_IDS).Value = outIds

    ws.Cells(r, RES_COL_IN_IDS).Value = inIds

    ws.Cells(r, RES_COL_SHOPS).Value = shops

    ws.Cells(r, RES_COL_SUMMARY).Value = summaryText

    ws.Cells(r, RES_COL_MEMO).Value = memo

    ws.Cells(r, RES_COL_SHIFT_DECISION).Value = decisionText

    ws.Cells(r, RES_COL_OPERATION_MEMO).Value = operationMemoText

    ws.Cells(r, RES_COL_AGE_HINT).Value = ageHint

    ws.Cells(r, RES_COL_ADDRESS_HINT).Value = addressHint

    mResultCount = mResultCount + 1

End Sub



Private Sub WriteDetailRows(ByVal analysisId As String, _
        ByVal kindText As String, _
        ByVal voucher As String, _
        ByVal sideText As String, _
        ByVal recs As Collection, _
        ByVal useOut As Boolean)

    Dim ws As Worksheet, outR As Long, rec As Object

    Set ws = GetSheet(SH_WORK_DETAIL)

    For Each rec In recs

        If mNextDetailRow < 2 Then mNextDetailRow = LastRow(ws, 1) + 1

        outR = mNextDetailRow

        mNextDetailRow = mNextDetailRow + 1

        ws.Cells(outR, DET_COL_ID).Value = NextId("���͖���")

        ws.Cells(outR, DET_COL_ANALYSIS_ID).Value = analysisId

        ws.Cells(outR, DET_COL_SIDE).Value = sideText

        ws.Cells(outR, DET_COL_TX_ID).Value = rec("TxId")

        ws.Cells(outR, DET_COL_DATE).Value = rec("Date")

        ws.Cells(outR, DET_COL_AMOUNT).Value = IIf(useOut, rec("Out"), rec("In"))

        ws.Cells(outR, DET_COL_PERSON_ID).Value = rec("PersonId")

        ws.Cells(outR, DET_COL_PERSON_NAME).Value = rec("Name")

        ws.Cells(outR, DET_COL_ACCOUNT_ID).Value = rec("AccountId")

        ws.Cells(outR, DET_COL_BANK).Value = rec("Bank")

        ws.Cells(outR, DET_COL_BRANCH).Value = rec("Branch")

        ws.Cells(outR, DET_COL_ACCOUNT_TYPE).Value = rec("AccountType")

        ws.Cells(outR, DET_COL_ACCOUNT_NO).Value = rec("AccountNo")

        ws.Cells(outR, DET_COL_SHOP).Value = rec("Shop")

        ws.Cells(outR, DET_COL_SUMMARY).Value = rec("Summary")

        ws.Cells(outR, DET_COL_KIND).Value = kindText

        ws.Cells(outR, DET_COL_VOUCHER).Value = voucher

    Next rec

End Sub



Private Function SortedIds(ByVal recs As Collection) As String

    Dim arr() As String, i As Long, j As Long, tmp As String, rec As Object

    If recs.Count = 0 Then Exit Function

    ReDim arr(1 To recs.Count)

    i = 1

    For Each rec In recs

        arr(i) = CStr(rec("TxId"))

        i = i + 1

    Next rec

    For i = LBound(arr) To UBound(arr) - 1

        For j = i + 1 To UBound(arr)

            If arr(j) < arr(i) Then tmp = arr(i): arr(i) = arr(j): arr(j) = tmp

        Next j

    Next i

    For i = LBound(arr) To UBound(arr)

        If Len(SortedIds) > 0 Then SortedIds = SortedIds & ","

        SortedIds = SortedIds & arr(i)

    Next i

End Function



Private Function SumRecords(ByVal recs As Collection, ByVal useOut As Boolean) As Double

    Dim rec As Object

    For Each rec In recs

        If useOut Then

            SumRecords = SumRecords + CDbl(rec("Out"))

        Else

            SumRecords = SumRecords + CDbl(rec("In"))

        End If

    Next rec

End Function



Private Function IsTemporalFlowValid(ByVal outRecords As Collection, ByVal inRecords As Collection) As Boolean

    Dim outLatestDay As Long, inEarliestDay As Long

    Dim outLatestKnown As Double, inEarliestKnown As Double

    Dim hasOutKnown As Boolean, hasInKnown As Boolean

    IsTemporalFlowValid = True

    If outRecords Is Nothing Or inRecords Is Nothing Then Exit Function

    If outRecords.Count = 0 Or inRecords.Count = 0 Then Exit Function



    outLatestDay = LatestDateSerialInRecords(outRecords)

    inEarliestDay = EarliestDateSerialInRecords(inRecords)

    If outLatestDay = 0 Or inEarliestDay = 0 Then Exit Function



    ' �u�o���������v�����B���������o�������O�̌��͍��Ȃ��B

    If outLatestDay > inEarliestDay Then

        IsTemporalFlowValid = False

        Exit Function

    End If



    ' �����őo���Ɏ���������ꍇ�́A�ŐV�o������ <= �ő��������� ��K�{�ɂ���B

    If outLatestDay = inEarliestDay Then

        hasOutKnown = LatestKnownDateTimeOnDay(outRecords, outLatestDay, outLatestKnown)

        hasInKnown = EarliestKnownDateTimeOnDay(inRecords, inEarliestDay, inEarliestKnown)

        If hasOutKnown And hasInKnown Then

            If outLatestKnown > inEarliestKnown + 0.00000001 Then IsTemporalFlowValid = False

        End If

    End If

End Function



Private Function EarliestDateSerialInRecords(ByVal recs As Collection) As Long

    Dim rec As Object, d As Long

    For Each rec In recs

        d = DateOnlySerial(rec("Date"))

        If d > 0 Then

            If EarliestDateSerialInRecords = 0 Or d < EarliestDateSerialInRecords Then EarliestDateSerialInRecords = d

        End If

    Next rec

End Function



Private Function LatestDateSerialInRecords(ByVal recs As Collection) As Long

    Dim rec As Object, d As Long

    For Each rec In recs

        d = DateOnlySerial(rec("Date"))

        If d > 0 Then

            If LatestDateSerialInRecords = 0 Or d > LatestDateSerialInRecords Then LatestDateSerialInRecords = d

        End If

    Next rec

End Function



Private Function EarliestKnownDateTimeOnDay(ByVal recs As Collection, ByVal daySerial As Long, ByRef outValue As Double) As Boolean

    Dim rec As Object, v As Double

    For Each rec In recs

        If DateOnlySerial(rec("Date")) = daySerial And CBool(rec("HasTime")) Then

            v = CDbl(daySerial) + CDbl(rec("TimeFraction"))

            If Not EarliestKnownDateTimeOnDay Or v < outValue Then outValue = v

            EarliestKnownDateTimeOnDay = True

        End If

    Next rec

End Function



Private Function LatestKnownDateTimeOnDay(ByVal recs As Collection, ByVal daySerial As Long, ByRef outValue As Double) As Boolean

    Dim rec As Object, v As Double

    For Each rec In recs

        If DateOnlySerial(rec("Date")) = daySerial And CBool(rec("HasTime")) Then

            v = CDbl(daySerial) + CDbl(rec("TimeFraction"))

            If Not LatestKnownDateTimeOnDay Or v > outValue Then outValue = v

            LatestKnownDateTimeOnDay = True

        End If

    Next rec

End Function



Private Function TemporalFlowHintText(ByVal outRecords As Collection, ByVal inRecords As Collection) As String

    Dim outLatestDay As Long, inEarliestDay As Long

    Dim outKnown As Double, inKnown As Double, gapMinutes As Long

    If outRecords Is Nothing Or inRecords Is Nothing Then Exit Function

    If outRecords.Count = 0 Or inRecords.Count = 0 Then Exit Function

    outLatestDay = LatestDateSerialInRecords(outRecords)

    inEarliestDay = EarliestDateSerialInRecords(inRecords)

    If outLatestDay = 0 Or inEarliestDay = 0 Then Exit Function

    If outLatestDay < inEarliestDay Then

        TemporalFlowHintText = "���t��OK"

    ElseIf outLatestDay = inEarliestDay Then

        If LatestKnownDateTimeOnDay(outRecords, outLatestDay, outKnown) And EarliestKnownDateTimeOnDay(inRecords, inEarliestDay, inKnown) Then

            gapMinutes = CLng(Application.Max(0, Round((inKnown - outKnown) * 1440#, 0)))

            TemporalFlowHintText = "����������OK�i" & CStr(gapMinutes) & "����j"

        ElseIf HasAnyTime(outRecords) Or HasAnyTime(inRecords) Then

            TemporalFlowHintText = "�����E�����ꕔ�s��"

        Else

            TemporalFlowHintText = "�����E�����s��"

        End If

    End If

End Function



Private Function SameDayKnownTimeGapMinutes(ByVal outRecords As Collection, ByVal inRecords As Collection) As Long

    Dim outLatestDay As Long, inEarliestDay As Long

    Dim outKnown As Double, inKnown As Double

    SameDayKnownTimeGapMinutes = -1

    If outRecords Is Nothing Or inRecords Is Nothing Then Exit Function

    If outRecords.Count = 0 Or inRecords.Count = 0 Then Exit Function

    outLatestDay = LatestDateSerialInRecords(outRecords)

    inEarliestDay = EarliestDateSerialInRecords(inRecords)

    If outLatestDay = 0 Or outLatestDay <> inEarliestDay Then Exit Function

    If LatestKnownDateTimeOnDay(outRecords, outLatestDay, outKnown) And EarliestKnownDateTimeOnDay(inRecords, inEarliestDay, inKnown) Then

        If inKnown >= outKnown Then SameDayKnownTimeGapMinutes = CLng(Application.Max(0, Round((inKnown - outKnown) * 1440#, 0)))

    End If

End Function



Private Function HasAnyTime(ByVal recs As Collection) As Boolean

    Dim rec As Object

    For Each rec In recs

        If CBool(rec("HasTime")) Then HasAnyTime = True: Exit Function

    Next rec

End Function



Private Function RecordsDateTimeRangeText(ByVal recs As Collection) As String

    Dim rec As Object, minKey As Double, maxKey As Double, minText As String, maxText As String, k As Double

    If recs Is Nothing Then Exit Function

    If recs.Count = 0 Then Exit Function

    For Each rec In recs

        k = RecordDateTimeSortValue(rec)

        If minKey = 0 Or k < minKey Then

            minKey = k

            minText = RecordDateTimeText(rec)

        End If

        If maxKey = 0 Or k > maxKey Then

            maxKey = k

            maxText = RecordDateTimeText(rec)

        End If

    Next rec

    If minText = maxText Then

        RecordsDateTimeRangeText = minText

    Else

        RecordsDateTimeRangeText = minText & "�`" & maxText

    End If

End Function



Private Function RecordDateTimeSortValue(ByVal rec As Object) As Double

    If rec Is Nothing Then Exit Function

    If KeyExists(rec, "DateTimeSort") Then

        RecordDateTimeSortValue = CDbl(rec("DateTimeSort"))

    ElseIf IsDate(rec("Date")) Then

        RecordDateTimeSortValue = CDbl(DateOnlySerial(rec("Date")))

    End If

End Function



Private Function RecordDateTimeText(ByVal rec As Object) As String

    If rec Is Nothing Then Exit Function

    If IsDate(rec("Date")) Then

        If KeyExists(rec, "HasTime") And CBool(rec("HasTime")) Then

            RecordDateTimeText = Format$(CDate(rec("Date")) + CDbl(rec("TimeFraction")), "yyyy/m/d h:mm")

        Else

            RecordDateTimeText = Format$(CDate(rec("Date")), "yyyy/m/d")

        End If

    End If

End Function



Private Function KeyExists(ByVal dict As Object, ByVal keyText As String) As Boolean

    On Error GoTo EH

    If dict Is Nothing Then Exit Function

    KeyExists = dict.Exists(keyText)

    Exit Function

EH:

    KeyExists = False

End Function



Private Sub MarkMatched(ByVal recs As Collection, ByVal analysisId As String)

    Dim rec As Object, txId As String

    For Each rec In recs

        txId = CStr(rec("TxId"))

        If mMatched.Exists(txId) Then

            mMatched(txId) = mMatched(txId) & "," & analysisId

        Else

            mMatched.Add txId, analysisId

        End If

    Next rec

End Sub



Private Function ShiftKindFromOutRecords(ByVal outRecords As Collection) As String

    Dim rec As Object

    ShiftKindFromOutRecords = KIND_SHIFT

    For Each rec In outRecords

        If CStr(rec("PersonId")) = mDecedentId And IsDate(mInheritanceDate) And CDate(rec("Date")) >= CDate(mInheritanceDate) Then

            ShiftKindFromOutRecords = KIND_INHERITANCE_SHIFT

            Exit Function

        End If

    Next rec

End Function



Private Function CandidateReasonText(ByVal outRecords As Collection, _
        ByVal inRecords As Collection, _
        ByVal diff As Double, _
        ByVal score As Long, _
        ByVal temporalHint As String) As String

    Dim s As String, amountHint As String, rel As String, comboText As String

    If diff = 0 Then
        amountHint = "���z��v"
    ElseIf Abs(diff) <= mAmountTol Then
        amountHint = "���e����"
    Else
        amountHint = "���z " & Format$(diff, "#,##0")
    End If

    comboText = CStr(outRecords.Count) & "�o���~" & CStr(inRecords.Count) & "����"
    s = "�M���x" & CStr(score) & " / " & amountHint & " / " & comboText
    s = JoinNonBlank(s, temporalHint, " / ")

    rel = NameRelation(outRecords, inRecords)
    If Len(rel) > 0 Then s = JoinNonBlank(s, rel, " / ")
    If CollectionsShareValue(outRecords, inRecords, "AccountId") Then s = JoinNonBlank(s, "��������܂�", " / ")
    If InStr(temporalHint, "�����s��") > 0 Or InStr(temporalHint, "�����ꕔ�s��") > 0 Then s = JoinNonBlank(s, "�����͓��t�x�[�X", " / ")

    CandidateReasonText = ClipText(s, 240)

End Function

Private Function ScoreCandidate(ByVal outRecords As Collection, ByVal inRecords As Collection, ByVal diff As Double) As Long

    Dim outDateMin As Variant, outDateMax As Variant, inDateMin As Variant, inDateMax As Variant

    Dim daysDiff As Long, score As Long, comboCount As Long, flowHint As String, gapMinutes As Long

    score = 55

    If diff = 0 Then

        score = score + 22

    ElseIf Abs(diff) <= mAmountTol Then

        score = score + 14

    ElseIf EffectiveTolerance(SumRecords(outRecords, True), SumRecords(inRecords, False)) > 0 And Abs(diff) <= EffectiveTolerance(SumRecords(outRecords, True), SumRecords(inRecords, False)) Then

        score = score + 10

    End If

    DateMinMax outRecords, outDateMin, outDateMax

    DateMinMax inRecords, inDateMin, inDateMax

    If IsDate(outDateMin) And IsDate(inDateMin) Then

        daysDiff = DateOnlySerial(inDateMin) - DateOnlySerial(outDateMin)

        If daysDiff = 0 Then

            score = score + 16

            flowHint = TemporalFlowHintText(outRecords, inRecords)

            gapMinutes = SameDayKnownTimeGapMinutes(outRecords, inRecords)

            If gapMinutes >= 0 Then

                If gapMinutes <= 30 Then

                    score = score + 8

                ElseIf gapMinutes <= 120 Then

                    score = score + 6

                Else

                    score = score + 4

                End If

            ElseIf InStr(flowHint, "����������OK") > 0 Then

                score = score + 4

            ElseIf InStr(flowHint, "�����ꕔ�s��") > 0 Then

                score = score - 3

            End If

        ElseIf daysDiff = 1 Then

            score = score + 12

        ElseIf daysDiff > 1 And daysDiff <= mDateWindow Then

            score = score + 6

        End If

    End If

    comboCount = outRecords.Count + inRecords.Count

    If comboCount > 2 Then score = score - Application.Min(12, (comboCount - 2) * 2)

    If CollectionsShareValue(outRecords, inRecords, "AccountId") Then score = score - 10

    If mContextScore Then

        If NameRelation(outRecords, inRecords) = "���ꖼ�`" Then score = score + 4

        If Len(CohabitationText(outRecords, inRecords)) > 0 Then score = score + 4

        If HasSameAddressAtTransaction(outRecords, inRecords) Then score = score + 4

        If ShiftKindFromOutRecords(outRecords) = KIND_INHERITANCE_SHIFT Then score = score + 6

        If SameShopOrBankHint(outRecords, inRecords) Then score = score + 3

        If Len(SummaryKeywordFlowHint(outRecords, inRecords)) > 0 Then score = score + 2

        If Len(TimeClusterSignal(outRecords, inRecords)) > 0 Then score = score + 4

        If Len(YoungHighAmountSignal(outRecords, inRecords)) > 0 Then score = score + 3

        If Len(MoveAroundHighAmountSignal(outRecords, inRecords)) > 0 Then score = score + 4

        If Len(LifeEventAroundHighAmountSignal(outRecords, inRecords)) > 0 Then score = score + 3

        If Len(AccountOperationPatternSignal(outRecords, inRecords)) > 0 Then score = score + 3

        If Len(CentralizedManagementSignal(outRecords, inRecords)) > 0 Then score = score + 4

        If Len(GiftAddBackSignal(outRecords, inRecords)) > 0 Then score = score + 5

        If Len(PreInheritanceWithdrawalSignal(outRecords)) > 0 Then score = score + 4

        If Len(TransactionAfterBalanceSignal(outRecords, inRecords)) > 0 Then score = score + 3

    End If

    If score > 100 Then score = 100

    If score < 0 Then score = 0

    ScoreCandidate = score

End Function



Private Function HasSameAddressAtTransaction(ByVal outs As Collection, ByVal ins As Collection) As Boolean

    Dim outAddr As Object, inAddr As Object, k As Variant

    Set outAddr = AddressDictForSide(outs)

    Set inAddr = AddressDictForSide(ins)

    For Each k In outAddr.Keys

        If Len(CStr(k)) > 0 And inAddr.Exists(k) Then

            HasSameAddressAtTransaction = True

            Exit Function

        End If

    Next k

End Function



Private Function CollectionsShareValue(ByVal leftRecords As Collection, ByVal rightRecords As Collection, ByVal fieldName As String) As Boolean

    Dim seen As Object, rec As Object, keyText As String

    Set seen = CreateObject("Scripting.Dictionary")

    If leftRecords Is Nothing Or rightRecords Is Nothing Then Exit Function

    For Each rec In leftRecords

        If KeyExists(rec, fieldName) Then

            keyText = CStr(rec(fieldName))

            If Len(keyText) > 0 Then seen(keyText) = True

        End If

    Next rec

    For Each rec In rightRecords

        If KeyExists(rec, fieldName) Then

            keyText = CStr(rec(fieldName))

            If Len(keyText) > 0 And seen.Exists(keyText) Then

                CollectionsShareValue = True

                Exit Function

            End If

        End If

    Next rec

End Function



Private Function SameShopOrBankHint(ByVal outs As Collection, ByVal ins As Collection) As Boolean

    Dim d As Object, rec As Object, keyText As String

    Set d = CreateObject("Scripting.Dictionary")

    For Each rec In outs

        keyText = CStr(rec("Bank")) & "|" & CStr(rec("Shop"))

        If Len(Replace$(keyText, "|", "")) > 0 Then d(keyText) = True

    Next rec

    For Each rec In ins

        keyText = CStr(rec("Bank")) & "|" & CStr(rec("Shop"))

        If d.Exists(keyText) Then

            SameShopOrBankHint = True

            Exit Function

        End If

    Next rec

End Function



Private Sub DateMinMax(ByVal recs As Collection, ByRef dMin As Variant, ByRef dMax As Variant)

    Dim rec As Object, d As Date

    dMin = Empty: dMax = Empty

    For Each rec In recs

        If IsDate(rec("Date")) Then

            d = DateValue(CDate(rec("Date")))

            If Not IsDate(dMin) Or d < CDate(dMin) Then dMin = d

            If Not IsDate(dMax) Or d > CDate(dMax) Then dMax = d

        End If

    Next rec

End Sub



Private Function PersonList(ByVal recs As Collection) As String

    Dim d As Object, rec As Object, key As String

    Set d = CreateObject("Scripting.Dictionary")

    For Each rec In recs

        key = CStr(rec("Name"))

        If Len(key) = 0 Then key = CStr(rec("PersonId"))

        If Len(key) > 0 Then d(key) = True

    Next rec

    PersonList = JoinDictionaryKeys(d, " / ")

End Function



Private Function JoinDictionaryKeys(ByVal d As Object, ByVal sep As String) As String

    Dim k As Variant

    For Each k In d.Keys

        If Len(JoinDictionaryKeys) > 0 Then JoinDictionaryKeys = JoinDictionaryKeys & sep

        JoinDictionaryKeys = JoinDictionaryKeys & CStr(k)

    Next k

End Function



Private Function NameRelation(ByVal outs As Collection, ByVal ins As Collection) As String

    Dim dOut As Object, dIn As Object, rec As Object, k As Variant

    Set dOut = CreateObject("Scripting.Dictionary")

    Set dIn = CreateObject("Scripting.Dictionary")

    For Each rec In outs

        If Len(CStr(rec("PersonId"))) > 0 Then dOut(CStr(rec("PersonId"))) = True

    Next rec

    For Each rec In ins

        If Len(CStr(rec("PersonId"))) > 0 Then dIn(CStr(rec("PersonId"))) = True

    Next rec

    If dOut.Count = 1 And dIn.Count = 1 Then

        For Each k In dOut.Keys

            If dIn.Exists(k) Then NameRelation = "���ꖼ�`" Else NameRelation = "�ʖ��`"

            Exit Function

        Next k

    End If

    If dOut.Count = 0 Or dIn.Count = 0 Then

        NameRelation = ""

    Else

        NameRelation = "�������`"

    End If

End Function



Private Function InheritanceTiming(ByVal outs As Collection) As String

    Dim rec As Object, hasAfter As Boolean, hasBefore As Boolean

    If Not IsDate(mInheritanceDate) Then

        InheritanceTiming = "�s��"

        Exit Function

    End If

    For Each rec In outs

        If IsDate(rec("Date")) Then

            If CDate(rec("Date")) >= CDate(mInheritanceDate) Then hasAfter = True Else hasBefore = True

        End If

    Next rec

    If hasAfter And hasBefore Then

        InheritanceTiming = "�O�㍬��"

    ElseIf hasAfter Then

        InheritanceTiming = "�����J�n��"

    Else

        InheritanceTiming = "�����J�n�O"

    End If

End Function



Private Function IsAfterInheritanceRecord(ByVal rec As Object) As Boolean

    IsAfterInheritanceRecord = False

    If IsDate(mInheritanceDate) And IsDate(rec("Date")) Then

        IsAfterInheritanceRecord = (CDate(rec("Date")) >= CDate(mInheritanceDate))

    End If

End Function



Private Function CohabitationText(ByVal outs As Collection, ByVal ins As Collection) As String

    Dim recO As Object, recI As Object

    For Each recO In outs

        For Each recI In ins

            If AreCohabited(CStr(recO("PersonId")), CStr(recI("PersonId"))) Then

                CohabitationText = "����"

                Exit Function

            End If

        Next recI

    Next recO

    CohabitationText = ""

End Function



Private Function BuildCohabPairIndex() As Object

    Dim dict As Object, ws As Worksheet, lastR As Long, r As Long, headerRow As Long

    Dim c1 As Long, c2 As Long, p1 As String, p2 As String

    Set dict = CreateObject("Scripting.Dictionary")

    If Not SheetExists(SH_WORK_COHAB) Then

        Set BuildCohabPairIndex = dict

        Exit Function

    End If

    Set ws = GetSheet(SH_WORK_COHAB)

    headerRow = DetectCohabHeaderRow(ws)

    If headerRow = 0 Then

        Set BuildCohabPairIndex = dict

        Exit Function

    End If

    c1 = FirstHeaderColumn(ws, Array("�l��ID_A", "�l��AID", "�l��A�l��ID", "�l��A"), headerRow)

    c2 = FirstHeaderColumn(ws, Array("�l��ID_B", "�l��BID", "�l��B�l��ID", "�l��B"), headerRow)

    If c1 = 0 Or c2 = 0 Then

        Set BuildCohabPairIndex = dict

        Exit Function

    End If

    lastR = LastRow(ws, 1)

    For r = headerRow + 1 To lastR

        p1 = CoercePersonId(CellText(ws.Cells(r, c1).Value))

        p2 = CoercePersonId(CellText(ws.Cells(r, c2).Value))

        If Len(p1) > 0 And Len(p2) > 0 And p1 <> p2 Then dict(BuildPairKey(p1, p2)) = True

    Next r

    Set BuildCohabPairIndex = dict

End Function



Private Function DetectCohabHeaderRow(ByVal ws As Worksheet) As Long

    Dim rr As Long

    For rr = 1 To Application.Min(5, LastUsedRowInSheet(ws))

        If FirstHeaderColumn(ws, Array("�l��ID_A", "�l��AID", "�l��A�l��ID", "�l��A"), rr) > 0 And _
           FirstHeaderColumn(ws, Array("�l��ID_B", "�l��BID", "�l��B�l��ID", "�l��B"), rr) > 0 Then

            DetectCohabHeaderRow = rr

            Exit Function

        End If

    Next rr

End Function



Private Function CoercePersonId(ByVal valueText As String) As String

    Dim k As Variant, info As Object, cleanValue As String, cleanName As String

    cleanValue = CellText(valueText)

    If Len(cleanValue) = 0 Then Exit Function

    If Not mPersonInfo Is Nothing Then

        If mPersonInfo.Exists(cleanValue) Then

            CoercePersonId = cleanValue

            Exit Function

        End If

        For Each k In mPersonInfo.Keys

            Set info = mPersonInfo(k)

            cleanName = CellText(info("Name"))

            If cleanName = cleanValue Then

                CoercePersonId = CStr(k)

                Exit Function

            End If

        Next k

    End If

    CoercePersonId = cleanValue

End Function



Private Function AreCohabited(ByVal p1 As String, ByVal p2 As String) As Boolean

    If Len(p1) = 0 Or Len(p2) = 0 Or p1 = p2 Then Exit Function

    If mCohabPairs Is Nothing Then Set mCohabPairs = BuildCohabPairIndex()

    AreCohabited = mCohabPairs.Exists(BuildPairKey(p1, p2))

End Function



Private Function ShopList(ByVal outs As Collection, ByVal ins As Collection) As String

    Dim d As Object, rec As Object

    Set d = CreateObject("Scripting.Dictionary")

    For Each rec In outs

        If Len(CStr(rec("Bank")) & CStr(rec("Shop"))) > 0 Then d(CStr(rec("Bank")) & " " & CStr(rec("Shop"))) = True

    Next rec

    For Each rec In ins

        If Len(CStr(rec("Bank")) & CStr(rec("Shop"))) > 0 Then d(CStr(rec("Bank")) & " " & CStr(rec("Shop"))) = True

    Next rec

    ShopList = JoinDictionaryKeys(d, " / ")

End Function



Private Function SummaryList(ByVal outs As Collection, ByVal ins As Collection) As String

    Dim d As Object, rec As Object, s As String

    Set d = CreateObject("Scripting.Dictionary")

    For Each rec In outs

        s = CStr(rec("Summary"))

        If Len(s) > 0 Then d("�o:" & s) = True

    Next rec

    For Each rec In ins

        s = CStr(rec("Summary"))

        If Len(s) > 0 Then d("��:" & s) = True

    Next rec

    SummaryList = JoinDictionaryKeys(d, " / ")

End Function



Private Function SummaryKeywordFlowHint(ByVal outs As Collection, ByVal ins As Collection) As String

    ' �E�v�̕����͋��Z�@�ւ��Ƃɗh��邽�߁A���ޖ��ɂ͎g�킸�A�⏕�q���g�Ƃ��Čy�������B

    Dim outText As String, inText As String

    outText = CombinedSummaryText(outs)

    inText = CombinedSummaryText(ins)

    If HasAnyKeyword(outText, Array("�U��", "�U��", "����", "�����ړ�")) And HasAnyKeyword(inText, Array("�U��", "�U��", "����", "���", "�����ړ�")) Then

        SummaryKeywordFlowHint = "�E�v: �U���E�U�֌n"

    ElseIf HasAnyKeyword(outText, Array("ATM", "�`�s�l", "����", "����", "����")) And HasAnyKeyword(inText, Array("ATM", "�`�s�l", "����", "����", "�a��")) Then

        SummaryKeywordFlowHint = "�E�v: �����EATM�n"

    End If

End Function



Private Function CombinedSummaryText(ByVal recs As Collection) As String

    Dim rec As Object

    If recs Is Nothing Then Exit Function

    For Each rec In recs

        CombinedSummaryText = CombinedSummaryText & " " & CStr(rec("Summary")) & " " & CStr(rec("Other"))

    Next rec

End Function



Private Function HasAnyKeyword(ByVal textValue As String, ByVal keywords As Variant) As Boolean

    Dim i As Long

    For i = LBound(keywords) To UBound(keywords)

        If InStr(1, textValue, CStr(keywords(i)), vbTextCompare) > 0 Then

            HasAnyKeyword = True

            Exit Function

        End If

    Next i

End Function





Private Function BuildPersonInfoIndex() As Object

    Dim dict As Object, ws As Worksheet, lastR As Long, r As Long

    Dim colId As Long, colName As Long, colRel As Long, colBirth As Long, colDeath As Long

    Dim pid As String, info As Object

    Set dict = CreateObject("Scripting.Dictionary")

    If Not SheetExists(SH_WORK_PERSON) Then Set BuildPersonInfoIndex = dict: Exit Function

    Set ws = GetSheet(SH_WORK_PERSON)

    colId = FirstHeaderColumn(ws, Array("�l��ID"), 1)

    colName = FirstHeaderColumn(ws, Array("�����\��", "����"), 1)

    colRel = FirstHeaderColumn(ws, Array("�푊���l���猩������", "����", "�\���p����"), 1)

    colBirth = FirstHeaderColumn(ws, Array("���N����"), 1)

    colDeath = FirstHeaderColumn(ws, Array("���S��"), 1)

    If colId = 0 Then Set BuildPersonInfoIndex = dict: Exit Function

    lastR = LastRow(ws, colId)

    For r = 2 To lastR

        pid = CellText(ws.Cells(r, colId).Value)

        If Len(pid) > 0 Then

            Set info = CreateObject("Scripting.Dictionary")

            info("Name") = GetCellByCol(ws, r, colName)

            info("Relation") = GetCellByCol(ws, r, colRel)

            If colBirth > 0 Then info("Birth") = ToDateOrEmpty(ws.Cells(r, colBirth).Value) Else info("Birth") = Empty

            If colDeath > 0 Then info("Death") = ToDateOrEmpty(ws.Cells(r, colDeath).Value) Else info("Death") = Empty

            If dict.Exists(pid) Then dict.Remove pid

            dict.Add pid, info

        End If

    Next r

    Set BuildPersonInfoIndex = dict

End Function




Private Function BuildMarriageDateIndex() As Object

    Dim dict As Object, ws As Worksheet, lastR As Long, r As Long
    Dim colBase As Long, colOther As Long, colMarriage As Long, colStatus As Long
    Dim baseId As String, otherId As String, statusText As String, marriageDate As Variant

    Set dict = CreateObject("Scripting.Dictionary")
    If Not SheetExists(SH_WORK_REL) Then Set BuildMarriageDateIndex = dict: Exit Function

    Set ws = GetSheet(SH_WORK_REL)
    colBase = FirstHeaderColumn(ws, Array("��l��ID", "�l��ID_A", "�l��A", "�l��ID1"), 1)
    colOther = FirstHeaderColumn(ws, Array("����l��ID", "�l��ID_B", "�l��B", "�l��ID2"), 1)
    colMarriage = FirstHeaderColumn(ws, Array("������", "�����N����"), 1)
    colStatus = FirstHeaderColumn(ws, Array("�f�[�^���"), 1)
    If colBase = 0 Or colOther = 0 Or colMarriage = 0 Then Set BuildMarriageDateIndex = dict: Exit Function

    lastR = LastRow(ws, colBase)
    For r = 2 To lastR
        statusText = GetCellByCol(ws, r, colStatus)
        If statusText <> "���" Then
            marriageDate = ToDateOrEmpty(ws.Cells(r, colMarriage).Value)
            If IsDate(marriageDate) Then
                baseId = GetCellByCol(ws, r, colBase)
                otherId = GetCellByCol(ws, r, colOther)
                If Len(baseId) > 0 Then AddLifeEventToIndex dict, baseId, CDate(marriageDate), "����:" & PersonDisplayNameSafe(otherId)
                If Len(otherId) > 0 Then AddLifeEventToIndex dict, otherId, CDate(marriageDate), "����:" & PersonDisplayNameSafe(baseId)
            End If
        End If
    Next r

    Set BuildMarriageDateIndex = dict

End Function

Private Sub AddLifeEventToIndex(ByVal dict As Object, ByVal personId As String, ByVal eventDate As Date, ByVal eventText As String)

    Dim col As Collection, item As Object
    If dict Is Nothing Or Len(personId) = 0 Then Exit Sub
    If dict.Exists(personId) Then
        Set col = dict(personId)
    Else
        Set col = New Collection
        dict.Add personId, col
    End If
    Set item = CreateObject("Scripting.Dictionary")
    item("Date") = DateValue(eventDate)
    item("Text") = eventText
    col.Add item

End Sub

Private Function BuildRelationPairIndex() As Object

    Dim dict As Object, ws As Worksheet, lastR As Long, r As Long
    Dim colBase As Long, colOther As Long, colStatus As Long
    Dim baseId As String, otherId As String, statusText As String

    Set dict = CreateObject("Scripting.Dictionary")
    If Not SheetExists(SH_WORK_REL) Then Set BuildRelationPairIndex = dict: Exit Function

    Set ws = GetSheet(SH_WORK_REL)
    colBase = FirstHeaderColumn(ws, Array("��l��ID", "�l��ID_A", "�l��A", "�l��ID1"), 1)
    colOther = FirstHeaderColumn(ws, Array("����l��ID", "�l��ID_B", "�l��B", "�l��ID2"), 1)
    colStatus = FirstHeaderColumn(ws, Array("�f�[�^���"), 1)
    If colBase = 0 Or colOther = 0 Then Set BuildRelationPairIndex = dict: Exit Function

    lastR = LastRow(ws, colBase)
    For r = 2 To lastR
        statusText = GetCellByCol(ws, r, colStatus)
        If statusText <> "���" Then
            baseId = GetCellByCol(ws, r, colBase)
            otherId = GetCellByCol(ws, r, colOther)
            If Len(baseId) > 0 And Len(otherId) > 0 Then
                dict(RelationPairKey(baseId, otherId)) = True
                dict(RelationPairKey(otherId, baseId)) = True
            End If
        End If
    Next r

    Set BuildRelationPairIndex = dict

End Function

Private Function RelationPairKey(ByVal personId1 As String, ByVal personId2 As String) As String
    RelationPairKey = personId1 & "|" & personId2
End Function

Private Function IsMovePaymentRelevantPerson(ByVal txPersonId As String, ByVal moverPersonId As String) As Boolean

    If Len(txPersonId) = 0 Or Len(moverPersonId) = 0 Then Exit Function
    If txPersonId = moverPersonId Then IsMovePaymentRelevantPerson = True: Exit Function
    If Len(mDecedentId) > 0 And txPersonId = mDecedentId Then IsMovePaymentRelevantPerson = True: Exit Function

    If Not mRelationPairs Is Nothing Then
        If mRelationPairs.Exists(RelationPairKey(txPersonId, moverPersonId)) Then
            IsMovePaymentRelevantPerson = True
            Exit Function
        End If
    End If

    If IsKinshipPerson(txPersonId) And IsKinshipPerson(moverPersonId) Then
        IsMovePaymentRelevantPerson = True
        Exit Function
    End If

End Function

Private Function IsKinshipPerson(ByVal personId As String) As Boolean

    Dim info As Object, relText As String

    If Len(personId) = 0 Then Exit Function
    If Len(mDecedentId) > 0 And personId = mDecedentId Then IsKinshipPerson = True: Exit Function
    If mPersonInfo Is Nothing Then Exit Function
    If Not mPersonInfo.Exists(personId) Then Exit Function

    Set info = mPersonInfo(personId)
    If info.Exists("Relation") Then relText = CStr(info("Relation"))
    IsKinshipPerson = RelationTextLooksKinship(relText)

End Function

Private Function RelationTextLooksKinship(ByVal relText As String) As Boolean

    relText = Trim$(relText)
    If Len(relText) = 0 Then Exit Function
    If InStr(1, relText, "�֌W��", vbTextCompare) > 0 Then Exit Function
    If InStr(1, relText, "���̑�", vbTextCompare) > 0 Then Exit Function
    If InStr(1, relText, "�m�l", vbTextCompare) > 0 Then Exit Function
    If InStr(1, relText, "�s��", vbTextCompare) > 0 Then Exit Function
    RelationTextLooksKinship = True

End Function

Private Function PersonDisplayNameSafe(ByVal personId As String) As String

    Dim info As Object
    If Len(personId) = 0 Then Exit Function
    If mPersonInfo Is Nothing Then Exit Function
    If Not mPersonInfo.Exists(personId) Then Exit Function
    Set info = mPersonInfo(personId)
    If info.Exists("Name") Then PersonDisplayNameSafe = CStr(info("Name"))

End Function

Private Function BuildAddressByPersonIndex() As Object

    Dim dict As Object, ws As Worksheet, lastR As Long, r As Long

    Dim colPerson As Long, colStart As Long, colEnd As Long, colAddr As Long, colKey As Long

    Dim pid As String, rec As Object, col As Collection

    Set dict = CreateObject("Scripting.Dictionary")

    If Not SheetExists(SH_WORK_ADDRESS) Then Set BuildAddressByPersonIndex = dict: Exit Function

    Set ws = GetSheet(SH_WORK_ADDRESS)

    colPerson = FirstHeaderColumn(ws, Array("�l��ID"), 1)

    colStart = FirstHeaderColumn(ws, Array("�J�n��", "���Z�J�n��"), 1)

    colEnd = FirstHeaderColumn(ws, Array("�I����", "���Z�I����"), 1)

    colAddr = FirstHeaderColumn(ws, Array("�Z������", "�Z��", "�Z��������\"), 1)

    colKey = FirstHeaderColumn(ws, Array("�Z���L�["), 1)

    If colPerson = 0 Then Set BuildAddressByPersonIndex = dict: Exit Function

    lastR = LastRow(ws, colPerson)

    For r = 2 To lastR

        pid = CellText(ws.Cells(r, colPerson).Value)

        If Len(pid) > 0 Then

            Set rec = CreateObject("Scripting.Dictionary")

            If colStart > 0 Then rec("Start") = ToDateOrEmpty(ws.Cells(r, colStart).Value) Else rec("Start") = Empty

            If colEnd > 0 Then rec("End") = ToDateOrEmpty(ws.Cells(r, colEnd).Value) Else rec("End") = Empty

            rec("Address") = GetCellByCol(ws, r, colAddr)

            rec("Key") = GetCellByCol(ws, r, colKey)

            If Len(CStr(rec("Key"))) = 0 Then rec("Key") = CStr(rec("Address"))

            If dict.Exists(pid) Then

                Set col = dict(pid)

            Else

                Set col = New Collection

                dict.Add pid, col

            End If

            col.Add rec

        End If

    Next r

    Set BuildAddressByPersonIndex = dict

End Function



Private Function PersonAgeAtDate(ByVal personId As String, ByVal atDate As Date) As String

    Dim info As Object, b As Variant, d As Variant, age As Long

    If mPersonInfo Is Nothing Then Exit Function

    If Not mPersonInfo.Exists(personId) Then Exit Function

    Set info = mPersonInfo(personId)

    b = info("Birth")

    d = info("Death")

    If Not IsDate(b) Then Exit Function

    If atDate < CDate(b) Then PersonAgeAtDate = "�o���O": Exit Function

    If IsDate(d) And atDate > CDate(d) Then

        age = AgeYears(CDate(b), CDate(d))

        PersonAgeAtDate = "���S��/���S��" & CStr(age) & "��"

    Else

        age = AgeYears(CDate(b), atDate)

        PersonAgeAtDate = CStr(age) & "��"

    End If

End Function




Private Function PersonAgeYearsAtDate(ByVal personId As String, ByVal atDate As Date) As Long

    Dim info As Object, b As Variant, d As Variant

    PersonAgeYearsAtDate = -1

    If mPersonInfo Is Nothing Then Exit Function

    If Not mPersonInfo.Exists(personId) Then Exit Function

    Set info = mPersonInfo(personId)

    b = info("Birth")

    d = info("Death")

    If Not IsDate(b) Then Exit Function

    If atDate < CDate(b) Then Exit Function

    If IsDate(d) And atDate > CDate(d) Then

        PersonAgeYearsAtDate = AgeYears(CDate(b), CDate(d))

    Else

        PersonAgeYearsAtDate = AgeYears(CDate(b), atDate)

    End If

End Function

Private Function AddressChangeNearDate(ByVal personId As String, ByVal atDate As Date, ByVal windowDays As Long) As String

    Dim col As Collection, rec As Object, s As Variant, e As Variant, diffDays As Long

    If mAddressByPerson Is Nothing Then Exit Function

    If Not mAddressByPerson.Exists(personId) Then Exit Function

    Set col = mAddressByPerson(personId)

    For Each rec In col

        s = rec("Start")

        e = rec("End")

        If IsDate(s) Then

            diffDays = Abs(DateDiff("d", CDate(s), atDate))

            If diffDays <= windowDays Then

                AddressChangeNearDate = "�]���J�n" & CStr(diffDays) & "����"

                Exit Function

            End If

        End If

        If IsDate(e) Then

            diffDays = Abs(DateDiff("d", CDate(e), atDate))

            If diffDays <= windowDays Then

                AddressChangeNearDate = "�]���I��" & CStr(diffDays) & "����"

                Exit Function

            End If

        End If

    Next rec

End Function


Private Function RelatedMoveNearTransaction(ByVal txPersonId As String, ByVal atDate As Date, ByVal windowDays As Long) As String

    Dim moverId As Variant, moveText As String, moverName As String

    If Len(txPersonId) = 0 Then Exit Function
    If mAddressByPerson Is Nothing Then Exit Function

    For Each moverId In mAddressByPerson.Keys
        If IsMovePaymentRelevantPerson(txPersonId, CStr(moverId)) Then
            moveText = AddressChangeNearDate(CStr(moverId), atDate, windowDays)
            If Len(moveText) > 0 Then
                moverName = PersonDisplayNameSafe(CStr(moverId))
                If Len(moverName) = 0 Then moverName = CStr(moverId)
                RelatedMoveNearTransaction = "�]����:" & ClipText(moverName, 8) & " " & moveText
                Exit Function
            End If
        End If
    Next moverId

End Function

Private Function PersonAgeAtInheritance(ByVal personId As String) As String

    If IsDate(mInheritanceDate) Then PersonAgeAtInheritance = PersonAgeAtDate(personId, CDate(mInheritanceDate))

End Function



Private Function AgeYears(ByVal birthDate As Date, ByVal atDate As Date) As Long

    AgeYears = Year(atDate) - Year(birthDate)

    If Month(atDate) < Month(birthDate) Or (Month(atDate) = Month(birthDate) And Day(atDate) < Day(birthDate)) Then AgeYears = AgeYears - 1

End Function



Private Function PersonAddressAtDate(ByVal personId As String, ByVal atDate As Date, ByVal returnKey As Boolean) As String

    Dim col As Collection, rec As Object, s As Variant, e As Variant

    If mAddressByPerson Is Nothing Then Exit Function

    If Not mAddressByPerson.Exists(personId) Then Exit Function

    Set col = mAddressByPerson(personId)

    For Each rec In col

        s = rec("Start"): e = rec("End")

        If (Not IsDate(s) Or CDate(s) <= atDate) And (Not IsDate(e) Or CDate(e) >= atDate) Then

            If returnKey Then PersonAddressAtDate = CStr(rec("Key")) Else PersonAddressAtDate = CStr(rec("Address"))

            Exit Function

        End If

    Next rec

End Function



Private Function AgeHintForRecords(ByVal outs As Collection, ByVal ins As Collection) As String

    AgeHintForRecords = JoinNonBlank(AgeHintForSide(outs), AgeHintForSide(ins), " / ")

    If Len(AgeHintForRecords) > 0 Then AgeHintForRecords = "�N��: " & AgeHintForRecords

End Function



Private Function AgeHintForSide(ByVal recs As Collection) As String

    Dim d As Object, rec As Object, displayAge As String, nameText As String

    Set d = CreateObject("Scripting.Dictionary")

    For Each rec In recs

        displayAge = CStr(rec("AgeAtTx"))

        If Len(displayAge) > 0 Then

            nameText = CStr(rec("Name"))

            If Len(nameText) = 0 Then nameText = CStr(rec("PersonId"))

            d(ClipText(nameText, 8) & " " & displayAge) = True

        End If

    Next rec

    AgeHintForSide = ClipText(JoinDictionaryKeys(d, " / "), 48)

End Function



Private Function AgeHintForRecord(ByVal rec As Object) As String

    If rec Is Nothing Then Exit Function

    If Not KeyExists(rec, "AgeAtTx") Then Exit Function

    If Len(CStr(rec("AgeAtTx"))) > 0 Then AgeHintForRecord = "�N��: " & CStr(rec("AgeAtTx"))

End Function



Private Function AddressHintForRecords(ByVal outs As Collection, ByVal ins As Collection) As String

    Dim outAddr As Object, inAddr As Object, k As Variant, outText As String, inText As String, body As String

    Set outAddr = AddressDictForSide(outs)

    Set inAddr = AddressDictForSide(ins)

    For Each k In outAddr.Keys

        If inAddr.Exists(k) And Len(CStr(k)) > 0 Then

            AddressHintForRecords = "�Z��: ���� " & ClipText(CStr(outAddr(k)), 20)

            Exit Function

        End If

    Next k

    outText = ClipText(DictionaryItemsText(outAddr, " / "), 20)

    inText = ClipText(DictionaryItemsText(inAddr, " / "), 20)

    If Len(outText) > 0 Then body = "�o " & outText

    If Len(inText) > 0 Then body = JoinNonBlank(body, "�� " & inText, " / ")

    If Len(body) > 0 Then AddressHintForRecords = "�Z��: " & body

End Function



Private Function AddressDictForSide(ByVal recs As Collection) As Object

    Dim d As Object, rec As Object, keyText As String, addrText As String

    Set d = CreateObject("Scripting.Dictionary")

    For Each rec In recs

        keyText = CStr(rec("AddressKeyAtTx"))

        addrText = CStr(rec("AddressAtTx"))

        If Len(keyText) > 0 Then

            If Len(addrText) = 0 Then addrText = keyText

            d(keyText) = addrText

        End If

    Next rec

    Set AddressDictForSide = d

End Function



Private Function DictionaryItemsText(ByVal d As Object, ByVal sep As String) As String

    Dim k As Variant

    For Each k In d.Keys

        DictionaryItemsText = JoinNonBlank(DictionaryItemsText, CStr(d(k)), sep)

    Next k

End Function



Private Function AddressHintForRecord(ByVal rec As Object) As String

    If rec Is Nothing Then Exit Function

    If Not KeyExists(rec, "AddressAtTx") Then Exit Function

    If Len(CStr(rec("AddressAtTx"))) > 0 Then AddressHintForRecord = "�Z��: " & ClipText(CStr(rec("AddressAtTx")), 30)

End Function




Private Function RiskSignalText(ByVal outs As Collection, ByVal ins As Collection) As String

    Dim d As Object, rec As Object
    Set d = CreateObject("Scripting.Dictionary")

    If Not outs Is Nothing Then
        For Each rec In outs
            If CStr(rec("PersonId")) = mDecedentId And IsDate(mInheritanceDate) Then
                If IsDate(rec("Date")) And CDate(rec("Date")) >= CDate(mInheritanceDate) Then d("�푊���l�̑�����o��") = True
            End If
            If KeyExists(rec, "AgeAtTx") Then
                If InStr(1, CStr(rec("AgeAtTx")), "���S��", vbTextCompare) > 0 Then d("���S����") = True
            End If
        Next rec
    End If

    If Not ins Is Nothing Then
        For Each rec In ins
            If KeyExists(rec, "AgeAtTx") Then
                If InStr(1, CStr(rec("AgeAtTx")), "���S��", vbTextCompare) > 0 Then d("���S����") = True
            End If
        Next rec
    End If

    AppendRiskSignal d, YoungHighAmountSignal(outs, ins)
    AppendRiskSignal d, MoveAroundHighAmountSignal(outs, ins)
    AppendRiskSignal d, LifeEventAroundHighAmountSignal(outs, ins)
    AppendRiskSignal d, TimeClusterSignal(outs, ins)
    AppendRiskSignal d, AccountOperationPatternSignal(outs, ins)
    AppendRiskSignal d, CentralizedManagementSignal(outs, ins)
    AppendRiskSignal d, GiftAddBackSignal(outs, ins)
    AppendRiskSignal d, PreInheritanceWithdrawalSignal(outs)
    AppendRiskSignal d, TransactionAfterBalanceSignal(outs, ins)

    RiskSignalText = JoinDictionaryKeys(d, " / ")

End Function


Private Function RiskSignalForSingle(ByVal rec As Object) As String

    Dim outs As New Collection, ins As New Collection

    If rec Is Nothing Then Exit Function

    If KeyExists(rec, "Out") Then

        If CDbl(rec("Out")) > 0 Then outs.Add rec

    End If

    If KeyExists(rec, "In") Then

        If CDbl(rec("In")) > 0 Then ins.Add rec

    End If

    RiskSignalForSingle = RiskSignalText(outs, ins)

End Function


Private Sub EnrichTransactionAfterBalanceContext()

    Dim k As Variant, rec As Object
    Dim afterValue As Double, beforeValue As Double, outAmt As Double, inAmt As Double

    If mTxById Is Nothing Then Exit Sub
    For Each k In mTxById.Keys
        Set rec = mTxById(k)
        If Not rec Is Nothing Then
            If KeyExists(rec, "BalanceAfter") Then
                afterValue = CDbl(rec("BalanceAfter"))
                outAmt = 0#: inAmt = 0#
                If KeyExists(rec, "Out") Then outAmt = CDbl(rec("Out"))
                If KeyExists(rec, "In") Then inAmt = CDbl(rec("In"))
                beforeValue = afterValue + outAmt - inAmt
                rec("BalanceBefore") = beforeValue
                rec("BalanceAfterKnown") = True
                If beforeValue > 0 Then rec("BalanceChangeRate") = Application.Max(outAmt, inAmt) / beforeValue
            End If
        End If
    Next k

End Sub

Private Function TransactionAfterBalanceValue(ByVal v As Variant) As Variant

    Dim s As String
    If IsNumeric(v) Then TransactionAfterBalanceValue = CDbl(v): Exit Function
    s = CellText(v)
    If Len(s) = 0 Then TransactionAfterBalanceValue = "": Exit Function
    s = Replace$(s, ",", "")
    s = Replace$(s, "�~", "")
    s = Replace$(s, "��", "")
    s = Replace$(s, "�c��", "")
    s = Replace$(s, "�����", "")
    s = Replace$(s, "����", "")
    s = Replace$(s, "�F", "")
    s = Replace$(s, ":", "")
    s = Replace$(s, " ", "")
    s = Replace$(s, "�@", "")
    s = Replace$(s, "��", "-")
    s = Replace$(s, "��", "-")
    If IsNumeric(s) Then TransactionAfterBalanceValue = CDbl(s) Else TransactionAfterBalanceValue = ""

End Function

Private Function TransactionAfterBalanceSignal(ByVal outs As Collection, ByVal ins As Collection) As String

    TransactionAfterBalanceSignal = TransactionAfterBalanceSignalForSide(outs, True)
    TransactionAfterBalanceSignal = JoinNonBlank(TransactionAfterBalanceSignal, TransactionAfterBalanceSignalForSide(ins, False), " / ")

End Function

Private Function TransactionAfterBalanceSignalForSide(ByVal recs As Collection, ByVal useOut As Boolean) As String

    Dim rec As Object, amountValue As Double, beforeValue As Double, afterValue As Double, ratio As Double
    Dim whoText As String
    If recs Is Nothing Then Exit Function

    For Each rec In recs
        If KeyExists(rec, "BalanceAfter") And KeyExists(rec, "BalanceBefore") Then
            amountValue = 0#
            If useOut Then
                If KeyExists(rec, "Out") Then amountValue = CDbl(rec("Out"))
            Else
                If KeyExists(rec, "In") Then amountValue = CDbl(rec("In"))
            End If
            If amountValue >= mMinShift Then
                beforeValue = CDbl(rec("BalanceBefore"))
                afterValue = CDbl(rec("BalanceAfter"))
                ratio = 0#
                If beforeValue > 0 Then ratio = amountValue / beforeValue
                whoText = ""
                If KeyExists(rec, "Name") Then whoText = CStr(rec("Name"))
                If Len(whoText) = 0 And KeyExists(rec, "PersonId") Then whoText = CStr(rec("PersonId"))
                If useOut Then
                    If ratio >= 0.5 Or (beforeValue > 0 And afterValue <= beforeValue * 0.1) Then
                        TransactionAfterBalanceSignalForSide = "������׎c���}���i" & ClipText(whoText, 8) & " �o����c��" & Format$(afterValue, "#,##0") & "�~ / ���O����" & Format$(beforeValue, "#,##0") & "�~�j"
                        Exit Function
                    End If
                Else
                    If ratio >= 0.5 Then
                        TransactionAfterBalanceSignalForSide = "������׎c���}���i" & ClipText(whoText, 8) & " ������c��" & Format$(afterValue, "#,##0") & "�~ / ���O����" & Format$(beforeValue, "#,##0") & "�~�j"
                        Exit Function
                    End If
                End If
            End If
        End If
    Next rec

End Function

Private Sub AppendRiskSignal(ByVal d As Object, ByVal signalText As String)

    If d Is Nothing Then Exit Sub

    If Len(signalText) > 0 Then d(signalText) = True

End Sub

Private Function YoungHighAmountSignal(ByVal outs As Collection, ByVal ins As Collection) As String

    YoungHighAmountSignal = YoungHighAmountSignalForSide(outs, True)

    YoungHighAmountSignal = JoinNonBlank(YoungHighAmountSignal, YoungHighAmountSignalForSide(ins, False), " / ")

End Function

Private Function YoungHighAmountSignalForSide(ByVal recs As Collection, ByVal useOut As Boolean) As String

    Dim rec As Object, ageYears As Long, amountValue As Double, whoText As String

    If recs Is Nothing Then Exit Function

    For Each rec In recs

        ageYears = -1

        amountValue = 0

        If KeyExists(rec, "AgeYearsAtTx") Then ageYears = CLng(rec("AgeYearsAtTx"))

        If useOut Then

            If KeyExists(rec, "Out") Then amountValue = CDbl(rec("Out"))

        Else

            If KeyExists(rec, "In") Then amountValue = CDbl(rec("In"))

        End If

        If ageYears >= 0 And ageYears < YOUNG_ATTENTION_AGE_YEARS And amountValue >= mMinShift Then

            whoText = ""

            If KeyExists(rec, "Name") Then whoText = CStr(rec("Name"))

            If Len(whoText) = 0 And KeyExists(rec, "PersonId") Then whoText = CStr(rec("PersonId"))

            YoungHighAmountSignalForSide = "��N���Ӎ��z����i20�Ζ���: " & ClipText(whoText, 8) & " " & CStr(ageYears) & "�΁j"

            Exit Function

        End If

    Next rec

End Function


Private Function LifeEventAroundHighAmountSignal(ByVal outs As Collection, ByVal ins As Collection) As String

    LifeEventAroundHighAmountSignal = LifeEventAroundHighAmountSignalForSide(outs, True)
    LifeEventAroundHighAmountSignal = JoinNonBlank(LifeEventAroundHighAmountSignal, LifeEventAroundHighAmountSignalForSide(ins, False), " / ")

End Function

Private Function LifeEventAroundHighAmountSignalForSide(ByVal recs As Collection, ByVal useOut As Boolean) As String

    Dim rec As Object, amountValue As Double, personId As String, txDate As Date
    Dim eventText As String, sideText As String
    If recs Is Nothing Then Exit Function
    If useOut Then sideText = "�o��" Else sideText = "����"

    For Each rec In recs
        If KeyExists(rec, "PersonId") And KeyExists(rec, "Date") Then
            If IsDate(rec("Date")) Then
                personId = CStr(rec("PersonId"))
                txDate = CDate(rec("Date"))
                amountValue = 0#
                If useOut Then
                    If KeyExists(rec, "Out") Then amountValue = CDbl(rec("Out"))
                Else
                    If KeyExists(rec, "In") Then amountValue = CDbl(rec("In"))
                End If
                If amountValue >= mMinShift Then
                    eventText = MarriageEventNearText(personId, txDate, DEFAULT_MOVE_NEAR_WINDOW_DAYS)
                    If Len(eventText) > 0 Then
                        LifeEventAroundHighAmountSignalForSide = "�����O��̍��z" & sideText & "�i" & ClipText(PersonDisplayNameSafe(personId), 8) & " / " & ClipText(eventText, 18) & "�j"
                        Exit Function
                    End If
                    eventText = RelatedBirthNearText(personId, txDate, DEFAULT_MOVE_NEAR_WINDOW_DAYS)
                    If Len(eventText) > 0 Then
                        LifeEventAroundHighAmountSignalForSide = "�o���O��̍��z" & sideText & "�i" & ClipText(PersonDisplayNameSafe(personId), 8) & " / " & ClipText(eventText, 18) & "�j"
                        Exit Function
                    End If
                End If
            End If
        End If
    Next rec

End Function

Private Function MarriageEventNearText(ByVal personId As String, ByVal txDate As Date, ByVal windowDays As Long) As String

    Dim col As Collection, item As Object, daysDiff As Long, bestDays As Long, bestText As String
    If mMarriageByPerson Is Nothing Then Exit Function
    If Len(personId) = 0 Then Exit Function
    If Not mMarriageByPerson.Exists(personId) Then Exit Function
    bestDays = 999999
    Set col = mMarriageByPerson(personId)
    For Each item In col
        If KeyExists(item, "Date") Then
            If IsDate(item("Date")) Then
                daysDiff = Abs(DateDiff("d", DateValue(CDate(item("Date"))), DateValue(txDate)))
                If daysDiff <= windowDays And daysDiff < bestDays Then
                    bestDays = daysDiff
                    bestText = CStr(item("Text")) & " " & CStr(daysDiff) & "����"
                End If
            End If
        End If
    Next item
    MarriageEventNearText = bestText

End Function

Private Function RelatedBirthNearText(ByVal personId As String, ByVal txDate As Date, ByVal windowDays As Long) As String

    Dim pid As Variant, info As Object, birthDate As Variant, daysDiff As Long, bestDays As Long, bestText As String
    Dim related As Boolean
    If mPersonInfo Is Nothing Then Exit Function
    If Len(personId) = 0 Then Exit Function
    bestDays = 999999
    For Each pid In mPersonInfo.Keys
        related = (CStr(pid) = personId)
        If Not related Then
            If Not mRelationPairs Is Nothing Then
                related = mRelationPairs.Exists(RelationPairKey(personId, CStr(pid)))
            End If
        End If
        If related Then
            Set info = mPersonInfo(pid)
            If Not info Is Nothing Then
                If KeyExists(info, "Birth") Then
                    birthDate = info("Birth")
                    If IsDate(birthDate) Then
                        daysDiff = Abs(DateDiff("d", DateValue(CDate(birthDate)), DateValue(txDate)))
                        If daysDiff <= windowDays And daysDiff < bestDays Then
                            bestDays = daysDiff
                            bestText = "�o��:" & PersonDisplayNameSafe(CStr(pid)) & " " & CStr(daysDiff) & "����"
                        End If
                    End If
                End If
            End If
        End If
    Next pid
    RelatedBirthNearText = bestText

End Function

Private Function MoveAroundHighAmountSignal(ByVal outs As Collection, ByVal ins As Collection) As String

    MoveAroundHighAmountSignal = MoveAroundHighAmountSignalForSide(outs, True)
    MoveAroundHighAmountSignal = JoinNonBlank(MoveAroundHighAmountSignal, MoveAroundHighAmountSignalForSide(ins, False), " / ")

End Function

Private Function MoveAroundHighAmountSignalForSide(ByVal recs As Collection, ByVal useOut As Boolean) As String

    Dim rec As Object, amountValue As Double, whoText As String, moveText As String

    If recs Is Nothing Then Exit Function

    For Each rec In recs

        amountValue = 0
        If useOut Then
            If KeyExists(rec, "Out") Then amountValue = CDbl(rec("Out"))
            If amountValue >= mMinShift And KeyExists(rec, "RelatedMoveNearTx") Then
                moveText = CStr(rec("RelatedMoveNearTx"))
                If Len(moveText) > 0 Then
                    whoText = PersonDisplayNameSafe(CStr(rec("PersonId")))
                    If Len(whoText) = 0 And KeyExists(rec, "Name") Then whoText = CStr(rec("Name"))
                    If Len(whoText) = 0 Then whoText = CStr(rec("PersonId"))
                    MoveAroundHighAmountSignalForSide = "�]���O��̍��z�o���i" & ClipText(whoText, 8) & " / " & ClipText(moveText, 24) & "�j"
                    Exit Function
                End If
            End If
        Else
            If KeyExists(rec, "In") Then amountValue = CDbl(rec("In"))
            If amountValue >= mMinShift And KeyExists(rec, "AddressChangeNearTx") Then
                moveText = CStr(rec("AddressChangeNearTx"))
                If Len(moveText) > 0 Then
                    whoText = PersonDisplayNameSafe(CStr(rec("PersonId")))
                    If Len(whoText) = 0 And KeyExists(rec, "Name") Then whoText = CStr(rec("Name"))
                    If Len(whoText) = 0 Then whoText = CStr(rec("PersonId"))
                    MoveAroundHighAmountSignalForSide = "�]���O��̍��z�����i" & ClipText(whoText, 8) & " " & ClipText(moveText, 12) & "�j"
                    Exit Function
                End If
            End If
        End If

    Next rec

End Function

Private Function TimeClusterSignal(ByVal outs As Collection, ByVal ins As Collection) As String

    TimeClusterSignal = TimeClusterSignalForSide(outs)

    If Len(TimeClusterSignal) = 0 Then TimeClusterSignal = TimeClusterSignalForSide(ins)

End Function

Private Function TimeClusterSignalForSide(ByVal recs As Collection) As String

    Dim rec As Object, col As Collection, accountCount As Long, personCount As Long

    If recs Is Nothing Then Exit Function

    If mTimeCluster Is Nothing Then Exit Function

    For Each rec In recs

        Set col = NearbyTimeClusterRecords(rec)

        accountCount = DistinctCountInCluster(col, "AccountId")

        personCount = DistinctCountInCluster(col, "PersonId")

        If col.Count >= 3 And (accountCount >= 2 Or personCount >= 2) Then

            TimeClusterSignalForSide = "���������t�߂ɕ������`����W���i" & CStr(col.Count) & "���j"

            Exit Function

        End If

    Next rec

End Function

Private Function AccountOperationPatternSignal(ByVal outs As Collection, ByVal ins As Collection) As String

    AccountOperationPatternSignal = AccountOperationPatternSignalForSide(outs)

    If Len(AccountOperationPatternSignal) = 0 Then AccountOperationPatternSignal = AccountOperationPatternSignalForSide(ins)

End Function

Private Function AccountOperationPatternSignalForSide(ByVal recs As Collection) As String

    Dim rec As Object, acc As String, cnt As Long, whoText As String

    If recs Is Nothing Then Exit Function

    If mAccountOperationPatternCount Is Nothing Then Exit Function

    For Each rec In recs

        acc = CStr(rec("AccountId"))

        If Len(acc) > 0 And mAccountOperationPatternCount.Exists(acc) Then

            cnt = CLng(mAccountOperationPatternCount(acc))

            If cnt >= 3 Then

                whoText = CStr(rec("Name"))

                If Len(whoText) = 0 Then whoText = acc

                AccountOperationPatternSignalForSide = "�ގ������тɔ������镡����������i" & ClipText(whoText, 8) & " " & CStr(cnt) & "��j"

                Exit Function

            End If

        End If

    Next rec

End Function

Private Function CentralizedManagementSignal(ByVal outs As Collection, ByVal ins As Collection) As String

    If Len(TimeClusterSignal(outs, ins)) > 0 Then
        CentralizedManagementSignal = "���`�O�Ǘ��m�F�i�������сE�������`�j"
    ElseIf Len(AccountOperationPatternSignal(outs, ins)) > 0 Then
        CentralizedManagementSignal = "���`�O�Ǘ��m�F�i�ގ������є����j"
    End If

End Function

Private Function GiftAddBackSignal(ByVal outs As Collection, ByVal ins As Collection) As String

    Dim rec As Object
    Dim hasDecedentOutInPeriod As Boolean
    Dim hasRelatedInInPeriod As Boolean

    If Not outs Is Nothing Then
        For Each rec In outs
            If IsDecedentRecord(rec) And IsDate(rec("Date")) Then
                If IsGiftAddBackPeriodDate(CDate(rec("Date"))) Then
                    hasDecedentOutInPeriod = True
                    Exit For
                End If
            End If
        Next rec
    End If

    If Not ins Is Nothing Then
        For Each rec In ins
            If IsDate(rec("Date")) Then
                If IsGiftAddBackPeriodDate(CDate(rec("Date"))) And IsRelatedOrKinNonDecedentRecord(rec) Then
                    hasRelatedInInPeriod = True
                    Exit For
                End If
            End If
        Next rec
    End If

    If hasDecedentOutInPeriod And hasRelatedInInPeriod Then
        GiftAddBackSignal = "��N���^���Z���ԓ��V�t�g�m�F"
    ElseIf hasRelatedInInPeriod Then
        If outs Is Nothing Then
            GiftAddBackSignal = "��N���^���Z���ԓ��̍��z�s�������m�F"
        ElseIf outs.Count = 0 Then
            GiftAddBackSignal = "��N���^���Z���ԓ��̍��z�s�������m�F"
        End If
    End If

End Function

Private Function PreInheritanceWithdrawalSignal(ByVal outs As Collection) As String

    Dim rec As Object, daysBefore As Long, amountValue As Double, bestDays As Long

    If outs Is Nothing Then Exit Function
    bestDays = 999999

    For Each rec In outs
        If IsDecedentRecord(rec) And IsDate(rec("Date")) Then
            daysBefore = DaysBeforeInheritance(CDate(rec("Date")))
            If daysBefore >= 0 And daysBefore <= 365 Then
                amountValue = 0
                If KeyExists(rec, "Out") Then amountValue = CDbl(rec("Out"))
                If amountValue >= mUnknownThreshold Then
                    If daysBefore < bestDays Then bestDays = daysBefore
                End If
            End If
        End If
    Next rec

    If bestDays <= 7 Then
        PreInheritanceWithdrawalSignal = "���S���O����o���m�F�i7�����j"
    ElseIf bestDays <= 30 Then
        PreInheritanceWithdrawalSignal = "�������O����o���m�F�i30�����j"
    ElseIf bestDays <= 90 Then
        PreInheritanceWithdrawalSignal = "�������O����o���m�F�i90�����j"
    ElseIf bestDays <= 365 Then
        PreInheritanceWithdrawalSignal = "�����O1�N������o���m�F"
    End If

End Function

Private Function IsDecedentRecord(ByVal rec As Object) As Boolean

    If rec Is Nothing Then Exit Function
    If Len(mDecedentId) = 0 Then Exit Function
    If KeyExists(rec, "PersonId") Then IsDecedentRecord = (CStr(rec("PersonId")) = mDecedentId)

End Function

Private Function IsRelatedOrKinNonDecedentRecord(ByVal rec As Object) As Boolean

    Dim pid As String
    If rec Is Nothing Then Exit Function
    If Not KeyExists(rec, "PersonId") Then Exit Function
    pid = CStr(rec("PersonId"))
    If Len(pid) = 0 Then Exit Function
    If Len(mDecedentId) > 0 And pid = mDecedentId Then Exit Function
    If IsKinshipPerson(pid) Then IsRelatedOrKinNonDecedentRecord = True: Exit Function
    If Not mRelationPairs Is Nothing And Len(mDecedentId) > 0 Then
        If mRelationPairs.Exists(RelationPairKey(mDecedentId, pid)) Then IsRelatedOrKinNonDecedentRecord = True
    End If

End Function

Private Function IsGiftAddBackPeriodDate(ByVal atDate As Date) As Boolean

    Dim startDate As Variant, inhDate As Date
    If Not IsDate(mInheritanceDate) Then Exit Function
    inhDate = DateValue(CDate(mInheritanceDate))
    If DateValue(atDate) > inhDate Then Exit Function
    startDate = GiftAddBackPeriodStartDate(inhDate)
    If Not IsDate(startDate) Then Exit Function
    IsGiftAddBackPeriodDate = (DateValue(atDate) >= DateValue(CDate(startDate)) And DateValue(atDate) <= inhDate)

End Function

Private Function GiftAddBackPeriodStartDate(ByVal inheritanceDate As Date) As Variant

    Dim d As Date
    d = DateValue(inheritanceDate)
    If d <= DateSerial(2026, 12, 31) Then
        GiftAddBackPeriodStartDate = DateAdd("yyyy", -3, d)
    ElseIf d <= DateSerial(2030, 12, 31) Then
        GiftAddBackPeriodStartDate = DateSerial(2024, 1, 1)
    Else
        GiftAddBackPeriodStartDate = DateAdd("yyyy", -7, d)
    End If

End Function

Private Function DaysBeforeInheritance(ByVal atDate As Date) As Long

    DaysBeforeInheritance = -1
    If Not IsDate(mInheritanceDate) Then Exit Function
    If DateValue(atDate) > DateValue(CDate(mInheritanceDate)) Then Exit Function
    DaysBeforeInheritance = DateDiff("d", DateValue(atDate), DateValue(CDate(mInheritanceDate)))

End Function

Private Function DistinctCountInCluster(ByVal col As Collection, ByVal fieldName As String) As Long

    Dim d As Object, rec As Object, k As String

    Set d = CreateObject("Scripting.Dictionary")

    If col Is Nothing Then Exit Function

    For Each rec In col

        If KeyExists(rec, fieldName) Then

            k = CStr(rec(fieldName))

            If Len(k) > 0 Then d(k) = True

        End If

    Next rec

    DistinctCountInCluster = d.Count

End Function



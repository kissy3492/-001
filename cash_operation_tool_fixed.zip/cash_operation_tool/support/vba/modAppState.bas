﻿Attribute VB_Name = "modAppState"
Option Explicit

Private mStateActive As Boolean
Private mStateDepth As Long
Private mPrevEvents As Boolean
Private mPrevScreenUpdating As Boolean
Private mPrevDisplayAlerts As Boolean
Private mPrevCalculation As XlCalculation
Private mPrevStatusBar As Variant
Private mPrevEnableCancelKey As XlEnableCancelKey
Private mPrevInteractive As Boolean
Private mLastRestoreFailure As String
Private mStatusTextByDepth() As String
Private mDiagnosticDepth As Long
Private mDiagnosticPreviousStatus() As Variant

Public Sub DiagnosticBegin(Optional ByVal statusText As String = "診断中...")
    '読取専用診断では計算・イベント・操作受付を変更しない。VBAリセット時にも
    'Excel全体を手動計算または操作不能のまま残さないため、状態表示だけを借りる。
    Dim errorNumber As Long, errorDescription As String
    Dim cleanupErrorNumber As Long, cleanupErrorDescription As String
    On Error GoTo EH
    mDiagnosticDepth = mDiagnosticDepth + 1
    If mDiagnosticDepth = 1 Then
        ReDim mDiagnosticPreviousStatus(1 To 1)
    Else
        ReDim Preserve mDiagnosticPreviousStatus(1 To mDiagnosticDepth)
    End If
    mDiagnosticPreviousStatus(mDiagnosticDepth) = Application.StatusBar
    Application.StatusBar = statusText
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    '開始失敗時の深さ・退避配列の巻戻しでさらに失敗しても、利用者へ返す
    '元の原因を置き換えない。VBAでは同じEH内の未保護エラーを再捕捉できないため、
    '後片付けだけをbest-effort領域へ明示的に分離する。
    On Error Resume Next
    Err.Clear
    If mDiagnosticDepth > 0 Then mDiagnosticDepth = mDiagnosticDepth - 1
    If mDiagnosticDepth = 0 Then
        Erase mDiagnosticPreviousStatus
    Else
        ReDim Preserve mDiagnosticPreviousStatus(1 To mDiagnosticDepth)
    End If
    cleanupErrorNumber = Err.Number
    cleanupErrorDescription = Err.Description
    Err.Clear
    On Error GoTo 0
    If cleanupErrorNumber <> 0 Then _
        errorDescription = errorDescription & _
                           " / 診断状態の巻戻し未完了: Err " & _
                           CStr(cleanupErrorNumber) & " " & cleanupErrorDescription
    Err.Raise errorNumber, "DiagnosticBegin", errorDescription
End Sub

Public Sub DiagnosticEnd()
    Dim previousStatus As Variant
    Dim errorNumber As Long, errorDescription As String
    If mDiagnosticDepth < 1 Then Exit Sub
    previousStatus = mDiagnosticPreviousStatus(mDiagnosticDepth)
    On Error GoTo EH
    Application.StatusBar = previousStatus
    If Not StatusBarMatches(previousStatus, Application.StatusBar) Then _
        Err.Raise vbObjectError + 1825, "DiagnosticEnd", _
                  "診断前の状態表示を復元できません。"
    mDiagnosticDepth = mDiagnosticDepth - 1
    If mDiagnosticDepth = 0 Then Erase mDiagnosticPreviousStatus
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    Err.Raise errorNumber, "DiagnosticEnd", errorDescription
End Sub

Public Sub AppBegin(Optional ByVal statusText As String = "処理中...")
    Dim errorNumber As Long, errorDescription As String
    Dim restoreFailure As String
    On Error GoTo EH

    '前回のAppEndが一部のApplicationプロパティを戻せなかった場合、
    'mStateActive=True／mStateDepth=0のまま元の退避値を保持している。
    'この状態で新しい退避値を上書きすると、利用者の元設定へ二度と戻せないため、
    '必ず残っている退避値の復元を先に完了させる。
    If mStateDepth = 0 And mStateActive Then
        On Error Resume Next
        Err.Clear
        AppEnd
        restoreFailure = mLastRestoreFailure
        Err.Clear
        On Error GoTo EH
        If mStateActive Then
            Err.Raise vbObjectError + 1823, "AppBegin", _
                      "前回処理後のExcel状態を復元できないため、新しい処理を開始していません。" & _
                      IIf(Len(restoreFailure) > 0, " 復元できない項目: " & restoreFailure, "")
        End If
    End If

    '深さと退避値の生存状態が食い違う場合は、復元先を持たないまま処理を進めない。
    If mStateDepth > 0 And Not mStateActive Then
        Err.Raise vbObjectError + 1824, "AppBegin", _
                  "Excel状態の管理情報が一致しないため、新しい処理を開始していません。"
    End If

    If mStateDepth = 0 Then
        mPrevEvents = Application.EnableEvents
        mPrevScreenUpdating = Application.ScreenUpdating
        mPrevDisplayAlerts = Application.DisplayAlerts
        mPrevCalculation = Application.Calculation
        mPrevStatusBar = Application.StatusBar
        mPrevEnableCancelKey = Application.EnableCancelKey
        mPrevInteractive = Application.Interactive
        mStateActive = True
    End If
    mStateDepth = mStateDepth + 1
    If mStateDepth = 1 Then
        ReDim mStatusTextByDepth(1 To 1)
    Else
        ReDim Preserve mStatusTextByDepth(1 To mStateDepth)
    End If
    mStatusTextByDepth(mStateDepth) = statusText
    Application.EnableEvents = False
    Application.ScreenUpdating = False
    Application.DisplayAlerts = False
    Application.Calculation = xlCalculationManual
    'AppProgressのDoEvents中も入力・ボタン操作を再入させない。開始前検査を通過後に
    '未登録入力や内部データが変わり、旧スナップショットを最新扱いする事故を防ぐ。
    Application.Interactive = False
    'Excelが中断入力を通知した場合はErr 18として呼出元へ返す。
    'Interactive=Falseとの併用時にEscが届くかは環境差があるため、中断可否は断言しない。
    Application.EnableCancelKey = xlErrorHandler
    Application.StatusBar = statusText
    If Application.EnableEvents Or Application.ScreenUpdating Or _
       Application.DisplayAlerts Or Application.Calculation <> xlCalculationManual Or _
       Application.Interactive Or Application.EnableCancelKey <> xlErrorHandler Then _
        Err.Raise vbObjectError + 1821, "AppBegin", _
                  "安全な処理状態へ切り替えられませんでした。データ処理は開始していません。"
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    '初回開始の途中失敗なら退避値へ戻す。入れ子処理なら深さだけ一段戻し、
    '外側の安全状態は維持する。
    On Error Resume Next
    AppEnd
    If mStateActive And Len(mLastRestoreFailure) > 0 Then _
        errorDescription = errorDescription & _
                           " / Excel状態の復元未完了: " & mLastRestoreFailure
    On Error GoTo 0
    Err.Raise errorNumber, "AppBegin", errorDescription
End Sub

Public Sub AppEnd()
    Dim failureText As String
    Dim eventStopDetail As String
    Dim propertyError As Long
    Dim propertyMatches As Boolean
    Dim parentStatusText As String

    If mStateDepth > 1 Then
        '入れ子処理の終了では利用者設定へはまだ戻さず、外側処理の案内へ戻す。
        '元コードは内側の案内を残したため、長い外側処理で工程表示が誤っていた。
        mStateDepth = mStateDepth - 1
        On Error Resume Next
        parentStatusText = mStatusTextByDepth(mStateDepth)
        mStatusTextByDepth(mStateDepth + 1) = vbNullString
        Application.StatusBar = parentStatusText
        On Error GoTo 0
        Exit Sub
    End If
    mStateDepth = 0
    Erase mStatusTextByDepth
    If Not mStateActive Then Exit Sub
    mLastRestoreFailure = vbNullString

    'イベントは最後に戻す。ほかのExcel状態が未復元のままイベントだけ再開すると、
    '再計算・画面更新中のイベントが半端な状態へ再入するためである。
    On Error Resume Next

    propertyMatches = False
    Err.Clear
    Application.ScreenUpdating = mPrevScreenUpdating
    propertyError = Err.Number
    Err.Clear
    propertyMatches = (Application.ScreenUpdating = mPrevScreenUpdating)
    If propertyError = 0 Then propertyError = Err.Number
    AppendRestoreFailure failureText, "画面更新", propertyError, propertyMatches

    propertyMatches = False
    Err.Clear
    Application.DisplayAlerts = mPrevDisplayAlerts
    propertyError = Err.Number
    Err.Clear
    propertyMatches = (Application.DisplayAlerts = mPrevDisplayAlerts)
    If propertyError = 0 Then propertyError = Err.Number
    AppendRestoreFailure failureText, "警告表示", propertyError, propertyMatches

    propertyMatches = False
    Err.Clear
    Application.Calculation = mPrevCalculation
    propertyError = Err.Number
    Err.Clear
    propertyMatches = (Application.Calculation = mPrevCalculation)
    If propertyError = 0 Then propertyError = Err.Number
    AppendRestoreFailure failureText, "計算方法", propertyError, propertyMatches

    propertyMatches = False
    Err.Clear
    Application.EnableCancelKey = mPrevEnableCancelKey
    propertyError = Err.Number
    Err.Clear
    propertyMatches = (Application.EnableCancelKey = mPrevEnableCancelKey)
    If propertyError = 0 Then propertyError = Err.Number
    AppendRestoreFailure failureText, "中断設定", propertyError, propertyMatches

    propertyMatches = False
    Err.Clear
    Application.Interactive = mPrevInteractive
    propertyError = Err.Number
    Err.Clear
    propertyMatches = (Application.Interactive = mPrevInteractive)
    If propertyError = 0 Then propertyError = Err.Number
    AppendRestoreFailure failureText, "操作受付", propertyError, propertyMatches

    propertyMatches = False
    Err.Clear
    Application.StatusBar = mPrevStatusBar
    propertyError = Err.Number
    Err.Clear
    propertyMatches = StatusBarMatches(mPrevStatusBar, Application.StatusBar)
    If propertyError = 0 Then propertyError = Err.Number
    AppendRestoreFailure failureText, "状態表示", propertyError, propertyMatches

    If Len(failureText) = 0 Then
        '非イベント項目を全て退避値へ戻せた時だけ、イベントleaseを開始値へ返す。
        propertyMatches = False
        Err.Clear
        Application.EnableEvents = mPrevEvents
        propertyError = Err.Number
        Err.Clear
        propertyMatches = (Application.EnableEvents = mPrevEvents)
        If propertyError = 0 Then propertyError = Err.Number
        AppendRestoreFailure failureText, "イベント", propertyError, propertyMatches
    End If

    If Len(failureText) > 0 Then
        '非イベント項目またはイベントleaseの復元が未完了なら、callerの
        'rollback/recoveryへイベントが再入しないようFalseをexactに確定する。
        eventStopDetail = vbNullString
        If Not TryHoldApplicationEventsStopped(eventStopDetail) Then _
            AppendForceRestoreDetail failureText, "イベント安全停止", eventStopDetail
    End If
    On Error GoTo 0

    If Len(failureText) = 0 Then
        mStateActive = False
        mLastRestoreFailure = vbNullString
        Exit Sub
    End If

    '退避値を捨てず、AppForceRestoreまたは次回AppEndで再試行できるようにする。
    mStateActive = True
    mLastRestoreFailure = failureText
    On Error Resume Next
    Application.StatusBar = "Excelの表示・操作状態を戻しています。操作せず、もう一度実行してください。"
    On Error GoTo 0
    Err.Raise vbObjectError + 1822, "AppEnd", _
              "Excelの状態を完全に復元できませんでした: " & failureText
End Sub

Private Sub AppendRestoreFailure(ByRef failureText As String, ByVal propertyName As String, _
                                 ByVal errorNumber As Long, ByVal propertyMatches As Boolean)
    If errorNumber = 0 And propertyMatches Then Exit Sub
    If Len(failureText) > 0 Then failureText = failureText & " / "
    failureText = failureText & propertyName
    If errorNumber <> 0 Then failureText = failureText & " (Err " & CStr(errorNumber) & ")"
End Sub

Private Function TryHoldApplicationEventsStopped(ByRef detailText As String) As Boolean
    Dim setterError As Long, setterDescription As String
    Dim readbackError As Long, readbackDescription As String
    Dim currentEvents As Boolean

    detailText = vbNullString
    On Error Resume Next
    Err.Clear
    Application.EnableEvents = False
    setterError = Err.Number
    setterDescription = Err.Description

    Err.Clear
    currentEvents = Application.EnableEvents
    readbackError = Err.Number
    readbackDescription = Err.Description
    Err.Clear
    On Error GoTo 0

    If setterError = 0 And readbackError = 0 And Not currentEvents Then
        TryHoldApplicationEventsStopped = True
        Exit Function
    End If

    If setterError <> 0 Then _
        AppendForceRestoreDetail detailText, "setter", _
                                 "Err " & CStr(setterError) & " " & setterDescription
    If readbackError <> 0 Then
        AppendForceRestoreDetail detailText, "readback", _
                                 "Err " & CStr(readbackError) & " " & readbackDescription
    ElseIf currentEvents Then
        AppendForceRestoreDetail detailText, "readback", _
                                 "EnableEvents=Falseを確認できません（実値=True）。"
    End If
End Function

Private Function StatusBarMatches(ByVal expectedValue As Variant, ByVal actualValue As Variant) As Boolean
    On Error GoTo EH
    If VarType(expectedValue) <> VarType(actualValue) Then Exit Function
    If IsError(expectedValue) Or IsError(actualValue) Then Exit Function
    StatusBarMatches = (CStr(expectedValue) = CStr(actualValue))
    Exit Function
EH:
    StatusBarMatches = False
End Function

Public Sub AppForceRestore(Optional ByVal forceSafeDefaults As Boolean = False)
    '通常のエラー処理では、このツールが退避した状態がある時だけ戻す。
    '非処理中に計算方法などを勝手に変更せず、他ブックの利用者設定を守る。
    'forceSafeDefaultsは既存呼出互換のため残すが、退避のない全体状態は上書きしない。
    'Application.EnableEvents=True等の未所有の既定値へ倒さず、必ず捕捉済みlease値へ戻す。
    Dim failureText As String, stepDetail As String, readbackDetail As String
    Dim eventStopDetail As String

    Do While mDiagnosticDepth > 0
        stepDetail = vbNullString
        If Not TryEndDiagnosticForForceRestore(stepDetail) Then
            AppendForceRestoreDetail failureText, "診断状態", stepDetail
            Exit Do
        End If
    Loop

    If mStateActive Then
        mStateDepth = 0
        stepDetail = vbNullString
        If Not TryEndCapturedApplicationLease(stepDetail) Then
            AppendForceRestoreDetail failureText, "Application lease", stepDetail
        Else
            readbackDetail = vbNullString
            If Not CapturedApplicationStateMatches(readbackDetail) Then
                '後続で同じ退避値へ再試行できるよう、読戻し不一致で退避を破棄しない。
                mStateActive = True
                'AppEnd正常終了後の二次読戻しで不一致が出ても、callerの
                'recoveryへイベントが再入しないようFalseをexactに確定する。
                eventStopDetail = vbNullString
                If Not TryHoldApplicationEventsStopped(eventStopDetail) Then _
                    AppendForceRestoreDetail readbackDetail, _
                                             "イベント安全停止", eventStopDetail
                mLastRestoreFailure = readbackDetail
                AppendForceRestoreDetail failureText, "Application読戻し", readbackDetail
            End If
        End If
    ElseIf mStateDepth <> 0 Then
        AppendForceRestoreDetail failureText, "Application lease", _
                                 "退避値がないまま深さ=" & CStr(mStateDepth) & "が残っています。"
    End If

    If mStateActive And Len(mLastRestoreFailure) > 0 Then
        If InStr(1, failureText, mLastRestoreFailure, vbBinaryCompare) = 0 Then _
            AppendForceRestoreDetail failureText, "復元未完了", mLastRestoreFailure
    ElseIf Not mStateActive And Len(mLastRestoreFailure) > 0 Then
        AppendForceRestoreDetail failureText, "復元管理状態", mLastRestoreFailure
    End If

    If Len(failureText) > 0 Then _
        Err.Raise vbObjectError + 1826, "AppForceRestore", _
                  "Excelの捕捉済み状態を完全に復元できません: " & failureText
End Sub

Public Sub AppForceRestoreForRecoveryTerminal()
    'Recovery終端では、入れ子を含む捕捉済みApplication leaseを全て閉じる。
    'ただし通常のAppForceRestoreで開始時EnableEvents=Trueへ一瞬戻すと、
    'callerがFalseへ再収束する前にWorkbook/Calculate等が再入し得る。
    '捕捉値を一時的にFalseへ差し替え、既存の全項目読戻しをそのまま利用する。
    Dim stateWasActive As Boolean, capturedEvents As Boolean
    Dim errorNumber As Long, errorSource As String
    Dim errorDescription As String

    stateWasActive = mStateActive
    If stateWasActive Then
        capturedEvents = mPrevEvents
        mPrevEvents = False
    End If

    On Error GoTo EH
    AppForceRestore
    If stateWasActive Then mPrevEvents = capturedEvents
    Exit Sub
EH:
    errorNumber = Err.Number
    errorSource = Err.Source
    errorDescription = Err.Description
    Err.Clear
    '失敗時は後続の明示的な復元再試行に備えて、本来の捕捉値を失わない。
    'Application.EnableEvents自体はFalseのままで、callerが直後に再確認する。
    If stateWasActive Then mPrevEvents = capturedEvents
    Err.Raise errorNumber, _
              "AppForceRestoreForRecoveryTerminal/" & errorSource, _
              errorDescription
End Sub

Private Function TryEndDiagnosticForForceRestore(ByRef detailText As String) As Boolean
    detailText = vbNullString
    On Error GoTo EH
    DiagnosticEnd
    TryEndDiagnosticForForceRestore = True
    Exit Function
EH:
    detailText = "Err " & CStr(Err.Number) & " [" & Err.Source & "] " & Err.Description
    Err.Clear
End Function

Private Function TryEndCapturedApplicationLease(ByRef detailText As String) As Boolean
    detailText = vbNullString
    On Error GoTo EH
    AppEnd
    If mStateActive Then _
        Err.Raise vbObjectError + 1826, "TryEndCapturedApplicationLease", _
                  "AppEnd後も復元待ち状態が残っています。" & _
                  IIf(Len(mLastRestoreFailure) > 0, " " & mLastRestoreFailure, "")
    TryEndCapturedApplicationLease = True
    Exit Function
EH:
    detailText = "Err " & CStr(Err.Number) & " [" & Err.Source & "] " & Err.Description
    Err.Clear
End Function

Private Function CapturedApplicationStateMatches(ByRef failureText As String) As Boolean
    '復元呼出しが正常終了しても、捕捉した全項目をもう一度読み戻す。
    Dim propertyError As Long
    Dim propertyMatches As Boolean
    failureText = vbNullString
    On Error Resume Next

    propertyMatches = False
    Err.Clear
    propertyMatches = (Application.ScreenUpdating = mPrevScreenUpdating)
    propertyError = Err.Number
    AppendRestoreFailure failureText, "画面更新", propertyError, propertyMatches

    propertyMatches = False
    Err.Clear
    propertyMatches = (Application.DisplayAlerts = mPrevDisplayAlerts)
    propertyError = Err.Number
    AppendRestoreFailure failureText, "警告表示", propertyError, propertyMatches

    propertyMatches = False
    Err.Clear
    propertyMatches = (Application.Calculation = mPrevCalculation)
    propertyError = Err.Number
    AppendRestoreFailure failureText, "計算方法", propertyError, propertyMatches

    propertyMatches = False
    Err.Clear
    propertyMatches = (Application.EnableCancelKey = mPrevEnableCancelKey)
    propertyError = Err.Number
    AppendRestoreFailure failureText, "中断設定", propertyError, propertyMatches

    propertyMatches = False
    Err.Clear
    propertyMatches = (Application.Interactive = mPrevInteractive)
    propertyError = Err.Number
    AppendRestoreFailure failureText, "操作受付", propertyError, propertyMatches

    propertyMatches = False
    Err.Clear
    propertyMatches = StatusBarMatches(mPrevStatusBar, Application.StatusBar)
    propertyError = Err.Number
    AppendRestoreFailure failureText, "状態表示", propertyError, propertyMatches

    propertyMatches = False
    Err.Clear
    propertyMatches = (Application.EnableEvents = mPrevEvents)
    propertyError = Err.Number
    AppendRestoreFailure failureText, "イベント", propertyError, propertyMatches
    On Error GoTo 0
    CapturedApplicationStateMatches = (Len(failureText) = 0)
End Function

Private Sub AppendForceRestoreDetail(ByRef failureText As String, _
                                     ByVal stepName As String, ByVal detailText As String)
    If Len(failureText) > 0 Then failureText = failureText & " / "
    failureText = failureText & stepName
    If Len(detailText) > 0 Then failureText = failureText & ": " & detailText
End Sub

Public Function AppStateIsRestored(ByRef problemText As String) As Boolean
    problemText = vbNullString
    If mStateActive Then problemText = "処理用Application状態が復元待ちです。"
    If mStateDepth <> 0 Then
        If Len(problemText) > 0 Then problemText = problemText & " / "
        problemText = problemText & "処理状態の深さ=" & CStr(mStateDepth)
    End If
    If mDiagnosticDepth <> 0 Then
        If Len(problemText) > 0 Then problemText = problemText & " / "
        problemText = problemText & "診断状態の深さ=" & CStr(mDiagnosticDepth)
    End If
    If Len(mLastRestoreFailure) > 0 Then
        If Len(problemText) > 0 Then problemText = problemText & " / "
        problemText = problemText & "復元未完了=" & mLastRestoreFailure
    End If
    AppStateIsRestored = (Len(problemText) = 0)
End Function

Public Sub AppProgress(ByVal statusText As String, Optional ByVal currentValue As Long = 0, _
                       Optional ByVal totalValue As Long = 0)
    Dim displayText As String
    displayText = statusText
    If totalValue > 0 Then
        displayText = displayText & "  " & Format$(currentValue, "#,##0") & " / " & _
                      Format$(totalValue, "#,##0")
    End If
    Application.StatusBar = displayText
    DoEvents
End Sub

Public Function IsUserCancelError(ByVal errorNumber As Long) As Boolean
    IsUserCancelError = (errorNumber = 18)
End Function

param(
    [string]$OutputPath = ""
)

$ErrorActionPreference = "Stop"
$sourceDir = Split-Path -Parent $MyInvocation.MyCommand.Path
if ([string]::IsNullOrWhiteSpace($OutputPath)) {
    $OutputPath = Join-Path $sourceDir "cash_operation_input_tool.xlsm"
}
$OutputPath = [System.IO.Path]::GetFullPath($OutputPath)
if ([System.IO.File]::Exists($OutputPath)) {
    throw "Output already exists. Move or rename it first: $OutputPath"
}
$setupErrorPath = [System.IO.Path]::ChangeExtension($OutputPath, ".setup_error.txt")
if ([System.IO.File]::Exists($setupErrorPath)) {
    [System.IO.File]::Delete($setupErrorPath)
}

$excel = $null
$workbooks = $null
$workbook = $null
$vbProject = $null
$vbComponents = $null
$thisWorkbookComponent = $null
$codeModule = $null
$importedComponent = $null
$createdFile = $false
$leaveExcelOpen = $false
$setupInvoked = $false

try {
    $excel = New-Object -ComObject Excel.Application
    $excel.Visible = $false
    $excel.DisplayAlerts = $false
    # Do not let the injected workbook events run before setup has created its sheets.
    $excel.EnableEvents = $false
    $xlWBATWorksheet = -4167
    $workbooks = $excel.Workbooks
    $workbook = $workbooks.Add($xlWBATWorksheet)

    try {
        $vbProject = $workbook.VBProject
        $vbComponents = $vbProject.VBComponents
        $null = $vbComponents.Count
    }
    catch {
        throw "Excel blocked VBA project access. Enable 'Trust access to the VBA project object model', then run CREATE_TOOL.cmd again."
    }

    $moduleFiles = Get-ChildItem -LiteralPath $sourceDir -Filter "*.bas" -File | Sort-Object Name
    if ($moduleFiles.Count -eq 0) {
        throw "No VBA module files were found."
    }
    foreach ($moduleFile in $moduleFiles) {
        $importedComponent = $null
        try {
            $importedComponent = $vbComponents.Import($moduleFile.FullName)
        }
        finally {
            if ($null -ne $importedComponent) {
                try { [void][System.Runtime.InteropServices.Marshal]::ReleaseComObject($importedComponent) } catch {}
                $importedComponent = $null
            }
        }
    }

    $thisWorkbookPath = Join-Path $sourceDir "ThisWorkbook_code.txt"
    if (-not [System.IO.File]::Exists($thisWorkbookPath)) {
        throw "ThisWorkbook_code.txt was not found."
    }
    $thisWorkbookComponent = $vbComponents.Item("ThisWorkbook")
    $codeModule = $thisWorkbookComponent.CodeModule
    if ($codeModule.CountOfLines -gt 0) {
        $codeModule.DeleteLines(1, $codeModule.CountOfLines)
    }
    $cp932 = [System.Text.Encoding]::GetEncoding(932)
    $thisWorkbookCode = [System.IO.File]::ReadAllText($thisWorkbookPath, $cp932)
    $codeModule.AddFromString($thisWorkbookCode)

    $xlOpenXmlWorkbookMacroEnabled = 52
    $workbook.SaveAs($OutputPath, $xlOpenXmlWorkbookMacroEnabled)
    $createdFile = $true

    $excel.DisplayAlerts = $true
    $excel.Visible = $true
    $excel.EnableEvents = $true
    $escapedName = $workbook.Name.Replace("'", "''")
    $setupInvoked = $true
    $excel.Run("'$escapedName'!SetupWorkbook")

    $setupDetail = $excel.Run("'$escapedName'!GetLastSetupFailureDetail")
    if (-not [string]::IsNullOrWhiteSpace([string]$setupDetail)) {
        throw "Setup failed: $setupDetail"
    }
    $toolReady = $excel.Run("'$escapedName'!RequireToolReady")
    if (-not [System.Convert]::ToBoolean($toolReady)) {
        throw "Setup did not leave the tool in a ready state."
    }
    $workbook.Save()
    if (-not [System.Convert]::ToBoolean($workbook.Saved)) {
        throw "Final save was cancelled or did not complete."
    }
    $leaveExcelOpen = $true
    Write-Host "Tool created successfully: $OutputPath"
    Write-Host "Excel remains open. Run the VBA compile command and SelfCheckTool before first use."
    Write-Host "After creation, restore the VBA project access setting according to your organization policy."
}
catch {
    $failureMessage = $_.Exception.Message
    $primarySaveAttempted = $false
    $primarySaveSucceeded = $false
    $primaryWorkbookSavedConfirmed = $false
    $primaryPathExists = $false
    $primaryFileVerified = $false
    [Int64]$primaryFileSize = 0
    $diagnosticCopyPath = ""
    $diagnosticCopyAttempted = $false
    $diagnosticCopySucceeded = $false
    $diagnosticCopyExists = $false
    $diagnosticCopyVerified = $false
    [Int64]$diagnosticCopySize = 0
    $failureDetails = @()
    $preservationRequested = $false
    $excelVisibleConfirmed = $false
    $displayAlertsConfirmed = $false
    $enableEventsConfirmed = $false
    $userControlConfirmed = $false
    $excelContinuationConfirmed = $false
    $sidecarWritten = $false
    [Int64]$sidecarFileSize = 0
    $sidecarFailureMessage = ""
    $postSaveFailure = $createdFile -or [System.IO.File]::Exists($OutputPath)

    if ($postSaveFailure) {
        # Set this first so no secondary diagnostic error can make finally close Excel.
        # Even if one COM reference is unavailable, never close or quit after SaveAs.
        $preservationRequested = $true
        $leaveExcelOpen = $true

        if ($null -ne $excel -and $null -ne $workbook) {
            try {
                if ($setupInvoked) {
                    $null = $excel.Run("'$escapedName'!PrepareFailedSetupForInspection")
                }
            }
            catch {
                $failureDetails += "Failed to prepare the diagnostic view: " + $_.Exception.Message
            }

            try { $excel.EnableEvents = $false } catch {
                $failureDetails += "Failed to disable Excel events for the diagnostic save: " + $_.Exception.Message
            }
            try { $excel.DisplayAlerts = $false } catch {
                $failureDetails += "Failed to disable Excel alerts for the diagnostic save: " + $_.Exception.Message
            }
            $primarySaveExceptionMessage = ""
            $primarySaveAttempted = $true
            try {
                $workbook.Save()
            }
            catch {
                $primarySaveExceptionMessage = $_.Exception.Message
            }

            # Workbook.Save can finish writing before COM reports an exception. Always
            # verify Workbook.Saved and the file on disk in a separate step.
            try {
                $primaryWorkbookSavedConfirmed = [System.Convert]::ToBoolean($workbook.Saved)
                $primaryPathExists = [System.IO.File]::Exists($OutputPath)
                if ($primaryPathExists) {
                    $primaryFileInfo = Get-Item -LiteralPath $OutputPath
                    $primaryFileSize = [Int64]$primaryFileInfo.Length
                }
                $primaryFileVerified = $true
                $primarySaveSucceeded = $primaryWorkbookSavedConfirmed -and `
                                        $primaryPathExists -and $primaryFileSize -gt 0
            }
            catch {
                $failureDetails += "Failed to verify the primary failed-workbook save: " + $_.Exception.Message
            }
            if (-not [string]::IsNullOrWhiteSpace($primarySaveExceptionMessage)) {
                if ($primarySaveSucceeded) {
                    $failureDetails += "Workbook.Save reported an error, but Workbook.Saved and a non-empty output file were verified: " + $primarySaveExceptionMessage
                }
                else {
                    $failureDetails += "Primary failed-workbook save: " + $primarySaveExceptionMessage
                }
            }
            elseif (-not $primarySaveSucceeded) {
                $failureDetails += "Excel did not confirm Workbook.Saved and a non-empty failed-workbook file at the output path."
            }

            if (-not $primarySaveSucceeded) {
                $diagnosticCopyAttempted = $true
                $saveCopyExceptionMessage = ""
                try {
                    $stamp = [DateTime]::Now.ToString("yyyyMMdd_HHmmss")
                    $outputDir = [System.IO.Path]::GetDirectoryName($OutputPath)
                    $outputBase = [System.IO.Path]::GetFileNameWithoutExtension($OutputPath)
                    $diagnosticCopyPath = Join-Path $outputDir ($outputBase + ".setup_failed_" + $stamp + ".xlsm")
                    $suffix = 1
                    while ([System.IO.File]::Exists($diagnosticCopyPath)) {
                        $diagnosticCopyPath = Join-Path $outputDir ($outputBase + ".setup_failed_" + $stamp + "_" + $suffix + ".xlsm")
                        $suffix += 1
                    }
                    $workbook.SaveCopyAs($diagnosticCopyPath)
                }
                catch {
                    $saveCopyExceptionMessage = $_.Exception.Message
                }

                # SaveCopyAs can create the file before COM reports an exception. Always inspect the result.
                try {
                    $diagnosticCopyExists = -not [string]::IsNullOrWhiteSpace($diagnosticCopyPath) -and `
                                            [System.IO.File]::Exists($diagnosticCopyPath)
                    if ($diagnosticCopyExists) {
                        $diagnosticCopyInfo = Get-Item -LiteralPath $diagnosticCopyPath
                        $diagnosticCopySize = [Int64]$diagnosticCopyInfo.Length
                    }
                    $diagnosticCopyVerified = $true
                    $diagnosticCopySucceeded = $diagnosticCopyExists -and $diagnosticCopySize -gt 0
                }
                catch {
                    $failureDetails += "Failed to verify the diagnostic copy: " + $_.Exception.Message
                }

                if (-not [string]::IsNullOrWhiteSpace($saveCopyExceptionMessage)) {
                    if ($diagnosticCopySucceeded) {
                        $failureDetails += "SaveCopyAs reported an error, but a non-empty diagnostic copy was verified: " + $saveCopyExceptionMessage
                    }
                    else {
                        $failureDetails += "Diagnostic copy: " + $saveCopyExceptionMessage
                    }
                }
                elseif (-not $diagnosticCopySucceeded) {
                    $failureDetails += "The diagnostic copy was not created as a non-empty file."
                }
            }

            try { $excel.Visible = $true } catch {
                $failureDetails += "Failed to restore Excel visibility: " + $_.Exception.Message
            }
            try {
                $excelVisibleConfirmed = [System.Convert]::ToBoolean($excel.Visible)
                if (-not $excelVisibleConfirmed) { throw "Excel.Visible remained False." }
            }
            catch {
                $failureDetails += "Failed to confirm Excel visibility: " + $_.Exception.Message
            }
            try { $excel.DisplayAlerts = $true } catch {
                $failureDetails += "Failed to restore Excel alerts: " + $_.Exception.Message
            }
            try {
                $displayAlertsConfirmed = [System.Convert]::ToBoolean($excel.DisplayAlerts)
                if (-not $displayAlertsConfirmed) { throw "Excel.DisplayAlerts remained False." }
            }
            catch {
                $failureDetails += "Failed to confirm Excel alerts: " + $_.Exception.Message
            }
            try { $excel.EnableEvents = $true } catch {
                $failureDetails += "Failed to restore Excel events: " + $_.Exception.Message
            }
            try {
                $enableEventsConfirmed = [System.Convert]::ToBoolean($excel.EnableEvents)
                if (-not $enableEventsConfirmed) { throw "Excel.EnableEvents remained False." }
            }
            catch {
                $failureDetails += "Failed to confirm Excel events: " + $_.Exception.Message
            }
            # UserControl is read-only. Once Excel is visible, read it back instead of
            # attempting an invalid assignment that would create a misleading error.
            try {
                $userControlConfirmed = [System.Convert]::ToBoolean($excel.UserControl)
                if (-not $userControlConfirmed) { throw "Excel.UserControl remained False." }
            }
            catch {
                $failureDetails += "Failed to confirm that Excel remains under user control: " + $_.Exception.Message
            }
            $excelContinuationConfirmed = $excelVisibleConfirmed -and $userControlConfirmed
        }
        else {
            $failureDetails += "Excel continuation could not be confirmed because an Excel or workbook COM reference was unavailable."
        }
    }
    else {
        if ($null -ne $excel) {
            try { $excel.EnableEvents = $false } catch {}
        }
        if ($null -ne $workbook) {
            try { $workbook.Close($false) } catch {}
        }
        if ($null -ne $excel) {
            try { $excel.Quit() } catch {}
        }
    }

    # Re-read both files after all save attempts. Report only facts observed on disk.
    try {
        $primaryPathExists = [System.IO.File]::Exists($OutputPath)
        $primaryFileSize = 0
        if ($primaryPathExists) {
            $primaryFileInfo = Get-Item -LiteralPath $OutputPath
            $primaryFileSize = [Int64]$primaryFileInfo.Length
        }
        $primaryFileVerified = $true
    }
    catch {
        $failureDetails += "Failed to verify the output workbook after recovery: " + $_.Exception.Message
    }
    $saveFailureDetail = $failureDetails -join " / "

    try {
        $saveStatus = if ($primarySaveSucceeded) {
            "SUCCEEDED"
        }
        elseif ($primarySaveAttempted) {
            "FAILED"
        }
        else {
            "NOT ATTEMPTED"
        }
        $copyStatus = if ($diagnosticCopySucceeded) {
            "SUCCEEDED"
        }
        elseif ($diagnosticCopyAttempted) {
            "FAILED"
        }
        elseif ($postSaveFailure -and -not $primarySaveSucceeded) {
            "NOT ATTEMPTED"
        }
        else {
            "NOT NEEDED"
        }
        $primaryFileSizeText = if ($primaryFileVerified) { [string]$primaryFileSize } else { "UNKNOWN" }
        $diagnosticCopySizeText = if ($diagnosticCopyVerified) { [string]$diagnosticCopySize } else { "UNKNOWN" }
        $diagnosticText = @(
            "Tool creation failed.",
            "Error: $failureMessage",
            "Output workbook: $OutputPath",
            "Output workbook exists: $primaryPathExists",
            "Output workbook file verified: $primaryFileVerified",
            "Output workbook size: $primaryFileSizeText",
            "Failed workbook save attempted: $primarySaveAttempted",
            "Workbook.Saved confirmed: $primaryWorkbookSavedConfirmed",
            "Failed workbook save: $saveStatus",
            "Diagnostic copy attempted: $diagnosticCopyAttempted",
            "Diagnostic copy: $copyStatus",
            "Diagnostic copy path: $diagnosticCopyPath",
            "Diagnostic copy exists: $diagnosticCopyExists",
            "Diagnostic copy file verified: $diagnosticCopyVerified",
            "Diagnostic copy size: $diagnosticCopySizeText",
            "Save detail: $saveFailureDetail",
            "Excel preservation requested: $preservationRequested",
            "Excel visible confirmed: $excelVisibleConfirmed",
            "Excel DisplayAlerts confirmed: $displayAlertsConfirmed",
            "Excel EnableEvents confirmed: $enableEventsConfirmed",
            "Excel UserControl confirmed: $userControlConfirmed",
            "Excel continuation confirmed: $excelContinuationConfirmed",
            "Important: The failed workbook is not ready for normal use. Keep it only for diagnosis or Save As."
        ) -join [Environment]::NewLine
        $utf8WithBom = New-Object System.Text.UTF8Encoding($true)
        [System.IO.File]::WriteAllText($setupErrorPath, $diagnosticText, $utf8WithBom)
        $sidecarWritten = [System.IO.File]::Exists($setupErrorPath)
        if ($sidecarWritten) {
            $sidecarFileInfo = Get-Item -LiteralPath $setupErrorPath
            $sidecarFileSize = [Int64]$sidecarFileInfo.Length
            $sidecarWritten = $sidecarFileSize -gt 0
        }
        if (-not $sidecarWritten) {
            throw "The setup error sidecar was not created as a non-empty file."
        }
    }
    catch {
        $sidecarWritten = $false
        $sidecarFailureMessage = $_.Exception.Message
    }

    [Console]::Error.WriteLine("Tool creation failed: " + $failureMessage)
    if (-not [string]::IsNullOrWhiteSpace($saveFailureDetail)) {
        [Console]::Error.WriteLine("Diagnostic detail: " + $saveFailureDetail)
    }
    if ($preservationRequested -and $excelContinuationConfirmed) {
        Write-Host "Tool creation failed, but Excel remains open for diagnosis and Save As."
    }
    elseif ($preservationRequested) {
        [Console]::Error.WriteLine("Excel was not closed by this script, but visible user control could not be confirmed. Use any open Excel window to Save As immediately.")
    }
    if ($primaryPathExists -and $primaryFileSize -gt 0) {
        Write-Host "The output workbook was not deleted: $OutputPath"
    }
    if ($diagnosticCopySucceeded) {
        Write-Host "Diagnostic copy: $diagnosticCopyPath"
    }
    if ($sidecarWritten) {
        Write-Host "Error details: $setupErrorPath"
    }
    else {
        [Console]::Error.WriteLine("The setup error sidecar could not be written: " + $sidecarFailureMessage)
    }
    exit 1
}
finally {
    if (-not $leaveExcelOpen -and $null -ne $excel) {
        try { $excel.Quit() } catch {}
    }
    # Release child COM wrappers before their parents. Visible/UserControl Excel remains open for the user.
    if ($null -ne $importedComponent) {
        try { [void][System.Runtime.InteropServices.Marshal]::ReleaseComObject($importedComponent) } catch {}
        $importedComponent = $null
    }
    if ($null -ne $codeModule) {
        try { [void][System.Runtime.InteropServices.Marshal]::ReleaseComObject($codeModule) } catch {}
        $codeModule = $null
    }
    if ($null -ne $thisWorkbookComponent) {
        try { [void][System.Runtime.InteropServices.Marshal]::ReleaseComObject($thisWorkbookComponent) } catch {}
        $thisWorkbookComponent = $null
    }
    if ($null -ne $vbComponents) {
        try { [void][System.Runtime.InteropServices.Marshal]::ReleaseComObject($vbComponents) } catch {}
        $vbComponents = $null
    }
    if ($null -ne $vbProject) {
        try { [void][System.Runtime.InteropServices.Marshal]::ReleaseComObject($vbProject) } catch {}
        $vbProject = $null
    }
    if ($null -ne $workbook) {
        try { [void][System.Runtime.InteropServices.Marshal]::ReleaseComObject($workbook) } catch {}
        $workbook = $null
    }
    if ($null -ne $workbooks) {
        try { [void][System.Runtime.InteropServices.Marshal]::ReleaseComObject($workbooks) } catch {}
        $workbooks = $null
    }
    if ($null -ne $excel) {
        try { [void][System.Runtime.InteropServices.Marshal]::ReleaseComObject($excel) } catch {}
        $excel = $null
    }
    [GC]::Collect()
    [GC]::WaitForPendingFinalizers()
}

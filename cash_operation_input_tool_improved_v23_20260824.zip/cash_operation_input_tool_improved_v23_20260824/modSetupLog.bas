Attribute VB_Name = "modSetupLog"
Option Explicit

Public Sub ResetSetupLog()
    Dim ws As Worksheet
    On Error GoTo EH
    Set ws = GetOrCreateSheet(SH_SETUP_LOG, True)
    If ws Is Nothing Then Err.Raise vbObjectError + 1701, "ResetSetupLog", "�Z�b�g�A�b�v���O���쐬�ł��܂���B"
    EnsureSetupLogHeader ws
    Exit Sub
EH:
    Err.Raise Err.Number, "ResetSetupLog", Err.Description
End Sub

Public Sub LogStep(ByVal categoryText As String, ByVal stepText As String, Optional ByVal stateText As String = "", Optional ByVal detailText As String = "")
    Dim ws As Worksheet
    Dim r As Long
    On Error Resume Next
    Set ws = GetOrCreateSheet(SH_SETUP_LOG, False)
    If ws Is Nothing Then Exit Sub
    'ResetSetupLog���O�̍H���Ŏ��s���Ă��A���o���̂Ȃ��f�f���O���c���Ȃ��B
    EnsureSetupLogHeader ws
    r = ws.Cells(ws.Rows.Count, 1).End(xlUp).Row + 1
    If r < 2 Then r = 2
    ws.Cells(r, 1).Value = Now
    ws.Cells(r, 2).Value = categoryText
    ws.Cells(r, 3).Value = stepText
    ws.Cells(r, 4).Value = stateText
    ws.Cells(r, 5).Value = detailText
    ws.Rows(r).VerticalAlignment = xlTop
    ws.Cells(r, 5).WrapText = True
    On Error GoTo 0
End Sub

Private Sub EnsureSetupLogHeader(ByVal ws As Worksheet)
    If ws Is Nothing Then Exit Sub
    With ws
        If CellText(.Cells(1, 1).Value2) <> "����" Or _
           CellText(.Cells(1, 2).Value2) <> "�敪" Or _
           CellText(.Cells(1, 3).Value2) <> "�H��" Or _
           CellText(.Cells(1, 4).Value2) <> "���" Or _
           CellText(.Cells(1, 5).Value2) <> "�ڍ�" Then _
            SetRowValues .Range("A1"), Array("����", "�敪", "�H��", "���", "�ڍ�")
        .Range("A1:E1").Font.Bold = True
        .Range("A1:E1").Interior.Color = RGB(68, 114, 196)
        .Range("A1:E1").Font.Color = vbWhite
        .Columns("A:A").ColumnWidth = 20
        .Columns("B:B").ColumnWidth = 12
        .Columns("C:C").ColumnWidth = 26
        .Columns("D:D").ColumnWidth = 16
        .Columns("E:E").ColumnWidth = 80
        .Columns("B:E").NumberFormatLocal = "@"
        .Columns("A:A").NumberFormatLocal = "yyyy/m/d h:mm:ss"
        .Columns("E:E").WrapText = True
        .Rows(1).RowHeight = 24
    End With
End Sub

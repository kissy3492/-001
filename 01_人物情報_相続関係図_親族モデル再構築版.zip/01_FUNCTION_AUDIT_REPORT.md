# 01 人物情報 関数監査レポート

## 監査対象

相続関係図の親族モデル、配偶者期間判定、カード表示、入力時の関係確定。

## 重点確認

### 登録時

- `ResolveRelationTextForRegistration`
- `RelationBaseForRegistration`
- `IsBaseSpouseOfDescendant`
- `ConfirmRelationshipFactsAfterRegister`
- `SpouseRelationDatesForPair`
- `EffectiveRegistrationSpouseDatesForPair`

基準人物が配偶者側でも、婚姻日〜離婚日と出生年月日から血族側の親を確定できるようにした。

### 描画時

- `GetChildRowsForParent`
- `InferredDiagramParentIdForChildRow`
- `DiagramConfirmedParentIdForChildRow`
- `DiagramNormalizeParentCandidateByMarriage`
- `DiagramBloodlinePartnerForSpouseCandidate`
- `DiagramParentCandidateScore`

通常親子候補と配偶者候補を分離し、配偶者補正が直系親子を壊さないようにした。

### 夫婦線起点

- `ChildLinkOriginForDiagram`
- `ChildShouldUseCoupleOriginForDiagram`
- `DiagramSpouseRelationAllowsChild`
- `DiagramSpouseRelationRowCoversChild`
- `DiagramEffectiveSpouseDatesForPair`

出生年月日が夫婦期間内の子だけ、夫婦線中央から下ろす。

### 父母・兄弟姉妹

- `GetFatherRowForDiagram`
- `GetMotherRowForDiagram`
- `GetParentSpouseRowForDiagram`
- `GetSiblingRowsForPerson`
- `GetFirstVisiblePersonRowByRelation`

父の配偶者を母、母の配偶者を父として扱う救済を維持。

### カード

- `DiagramCardText`
- `DiagramCardBodyText`
- `PersonMarriageDateListForCard`
- `DiagramAddressTextForCard`
- `SafeApplyShapeText`
- `DiagramCardHeightFromLines`

カードの表示内容、日付形式、年齢表示、住所表示、文字見切れ対策を確認。

## 結果

静的チェック上の構文不整合、Public重複、TextFrame2残存、IIf残存、Cells(r, 0)候補は検出されなかった。

実機でのVBEコンパイル、描画、印刷プレビューは未実施。

@echo off
setlocal
cscript //nologo "%~dp0import\IMPORT_01_MODULES.vbs" %*
exit /b %ERRORLEVEL%

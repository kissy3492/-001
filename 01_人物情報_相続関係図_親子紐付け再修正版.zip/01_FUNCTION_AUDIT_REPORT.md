# 01 人物情報 関数監査レポート

## 対象

01 人物情報のみ。相続関係図の人物関係正規化・描画・印刷除外に関係する修正を反映。

## 静的確認

- CP932デコード: OK
- Option Explicit: OK
- Sub / Function / Property 開始終了数: 664 / 664
- Public重複: なし
- TextFrame2残存: なし
- IIf残存: なし
- 高リスク非短絡候補: 0件
- OnAction / AddButton 未定義候補: 0件

## 主要変更関数

- `GetFatherRowForDiagram`
- `GetMotherRowForDiagram`
- `GetParentSpouseRowForDiagram`
- `DiagramPrimaryParentIdForDrawing`
- `DiagramStoredBaseParentIdForDrawing`
- `DiagramBestExplicitParentIdForChildRow`
- `GetChildRowsForParent`
- `GetRootChildRows`
- `DiagramRelationDisplayTextForPersonRow`
- `ShouldShowInheritanceAgeOnCard`
- `PolishRelationshipDiagramOutput`
- `AuditDiagramAddStoredBaseParents`
- `NormalizeParentSpouseRelationLabel`
- `IsBaseSpouseOfDescendant`

## 注意

静的監査のみ。実機ExcelのVBEコンパイル・実行結果ではない。

IMPORT_01_MODULES.bat imports all 01 modules into an existing macro-enabled workbook.

Recommended use:
1. Extract the ZIP first. Do not run from inside the ZIP preview.
2. Save or sync the target workbook as a local .xlsm file. Do not pass an http/https URL.
3. Drag the target 01 .xlsm file onto IMPORT_01_MODULES.bat.
4. If a security message appears, enable Trust access to the VBA project object model.
5. After import, open VBE and run Compile VBAProject.

Important:
Manual import without deleting old standard modules is unsafe. Excel can create modOutputs1, modSetup1, etc., while the old modOutputs remains callable. This can make old drawing code run even after new files were imported.

This import script:
- removes old non-document VBA components before import
- keeps ThisWorkbook and sheet modules
- rewrites ThisWorkbook code without deleting sheet modules
- first tries native VBComponents.Import
- if native import fails, retries through ADODB.Stream shift_jis reader and CodeModule.InsertLines
- creates a backup next to the target workbook before changes
- reports the exact failed stage when import does not finish cleanly

Return codes:
0 = imported and SetupWorkbook ran
1 = import failed before save
2 = modules imported, but SetupWorkbook did not complete

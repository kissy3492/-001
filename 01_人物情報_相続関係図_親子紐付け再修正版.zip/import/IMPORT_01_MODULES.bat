@echo off
setlocal
cscript //nologo "%~dp0IMPORT_01_MODULES.vbs" %*
exit /b %ERRORLEVEL%

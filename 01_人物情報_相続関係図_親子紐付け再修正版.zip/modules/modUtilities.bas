Attribute VB_Name = "modUtilities"
Option Explicit

Private mAppDepth As Long
Private mPrevScreenUpdating As Boolean
Private mPrevEnableEvents As Boolean
Private mPrevDisplayAlerts As Boolean
Private mPrevCalculation As XlCalculation
Private mPrevStatusBar As Variant

Public Sub AppBegin(Optional ByVal statusText As String = "������...")
    ' ����q�ďo���ɑΉ�����Excel��Ԃ����S�ɐ��䂷��B
    On Error Resume Next
    If mAppDepth = 0 Then
        mPrevScreenUpdating = Application.ScreenUpdating
        mPrevEnableEvents = Application.EnableEvents
        mPrevDisplayAlerts = Application.DisplayAlerts
        mPrevCalculation = Application.Calculation
        mPrevStatusBar = Application.StatusBar
        Application.ScreenUpdating = False
        Application.EnableEvents = False
        Application.DisplayAlerts = False
        Application.Calculation = xlCalculationManual
    End If
    mAppDepth = mAppDepth + 1
    Application.StatusBar = statusText
    On Error GoTo 0
End Sub

Public Sub AppEnd()
    On Error Resume Next
    If mAppDepth > 0 Then mAppDepth = mAppDepth - 1
    If mAppDepth = 0 Then
        Application.Calculation = mPrevCalculation
        Application.DisplayAlerts = mPrevDisplayAlerts
        Application.EnableEvents = mPrevEnableEvents
        Application.ScreenUpdating = mPrevScreenUpdating
        Application.StatusBar = mPrevStatusBar
    End If
    On Error GoTo 0
End Sub

Public Sub AppForceRestore()
    ' �G���[���f��ً̋}�����B
    On Error Resume Next
    mAppDepth = 0
    Application.Calculation = xlCalculationAutomatic
    Application.DisplayAlerts = True
    Application.EnableEvents = True
    Application.ScreenUpdating = True
    Application.StatusBar = False
    On Error GoTo 0
End Sub
Public Sub NotifyInfo(ByVal messageText As String, ParamArray ignoredArgs() As Variant)
    '�����ʒm�E�y���Ȉē��̓_�C�A���O�Ŏ~�߂��A�X�e�[�^�X�o�[�����Ɏc���B
    Dim s As String
    On Error Resume Next
    s = CStr(messageText)
    s = Replace(s, vbCrLf, " / ")
    s = Replace(s, vbCr, " / ")
    s = Replace(s, vbLf, " / ")
    If Len(s) > 220 Then s = Left$(s, 220) & "..."
    Application.StatusBar = s
    On Error GoTo 0
End Sub


Public Function SheetExists(ByVal sheetName As String, Optional ByVal wb As Workbook) As Boolean
    Dim ws As Worksheet
    If wb Is Nothing Then Set wb = ThisWorkbook
    On Error Resume Next
    Set ws = wb.Worksheets(sheetName)
    SheetExists = Not ws Is Nothing
    On Error GoTo 0
End Function

Public Function EnsureSheet(ByVal sheetName As String, Optional ByVal visibleState As XlSheetVisibility = xlSheetVisible) As Worksheet
    If SheetExists(sheetName, ThisWorkbook) Then
        Set EnsureSheet = ThisWorkbook.Worksheets(sheetName)
    Else
        Set EnsureSheet = ThisWorkbook.Worksheets.Add(After:=ThisWorkbook.Worksheets(ThisWorkbook.Worksheets.Count))
        EnsureSheet.Name = sheetName
    End If
    SetSheetVisibilitySafe EnsureSheet, visibleState
End Function

Public Sub SetSheetVisibilitySafe(ByVal ws As Worksheet, ByVal visibleState As XlSheetVisibility)
    '�A�N�e�B�u�V�[�g��B��̕\���V�[�g�������Ȃ��\���ɂ���ƁA�Z�b�g�A�b�v���~�܂�B
    '�����\�E���������m�F�̍č\�z�����A�K���ʂ̕\���V�[�g���m�ۂ��Ă���B���B
    Dim wb As Workbook, otherWs As Worksheet, candidate As Worksheet
    If ws Is Nothing Then Exit Sub
    Set wb = ws.Parent
    If visibleState = xlSheetVisible Then
        ws.Visible = xlSheetVisible
        Exit Sub
    End If

    For Each candidate In wb.Worksheets
        If candidate.Name <> ws.Name Then
            If candidate.Visible = xlSheetVisible Then
                Set otherWs = candidate
                Exit For
            End If
        End If
    Next candidate

    If otherWs Is Nothing Then
        If SheetExists(SH_INPUT, wb) Then
            If wb.Worksheets(SH_INPUT).Name <> ws.Name Then
                wb.Worksheets(SH_INPUT).Visible = xlSheetVisible
                Set otherWs = wb.Worksheets(SH_INPUT)
            End If
        End If
    End If

    If otherWs Is Nothing Then
        For Each candidate In wb.Worksheets
            If candidate.Name <> ws.Name Then
                candidate.Visible = xlSheetVisible
                Set otherWs = candidate
                Exit For
            End If
        Next candidate
    End If

    If otherWs Is Nothing Then
        ws.Visible = xlSheetVisible
        Exit Sub
    End If

    On Error Resume Next
    If wb.ActiveSheet.Name = ws.Name Then otherWs.Activate
    On Error GoTo 0
    ws.Visible = visibleState
End Sub

Public Sub ClearSheetAll(ByVal ws As Worksheet)
    '�Z�b�g�A�b�v��p�̊��S���C�A�E�g�N���A�B
    '�O�ł܂ł� merged cell ���c��ƁA����Z�b�g�A�b�v�Łu�����Z���̈ꕔ��ύX�ł��܂���v���Ŏ~�܂�B
    '���̂��߁A�l/�����������O�ɕK�������E���͋K���E�����t�������E�}�`�𗎂Ƃ��Ă���č\�z����B
    Dim shp As Shape
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    ws.Unprotect Password:=TOOL_PASSWORD
    ws.ScrollArea = ""
    ws.EnableSelection = xlNoRestrictions
    ws.AutoFilterMode = False
    ws.Cells.Validation.Delete
    ws.Cells.FormatConditions.Delete
    ws.Cells.UnMerge
    ws.Cells.Clear
    ws.Buttons.Delete
    For Each shp In ws.Shapes
        shp.Delete
    Next shp
    ws.Cells.Locked = False
    ws.Cells.FormulaHidden = False
    On Error GoTo 0
End Sub

Public Function LastRow(ByVal ws As Worksheet, Optional ByVal col As Long = 1) As Long
    Dim r As Long
    r = ws.Cells(ws.Rows.Count, col).End(xlUp).Row
    If r < 1 Then r = 1
    LastRow = r
End Function

Public Function NextBlankRow(ByVal ws As Worksheet, Optional ByVal col As Long = 1) As Long
    Dim r As Long
    r = LastRow(ws, col)
    If r = 1 And Len(CStr(ws.Cells(1, col).Value)) = 0 Then
        NextBlankRow = 1
    Else
        NextBlankRow = r + 1
    End If
End Function

Public Sub SetRowValues(ByVal firstCell As Range, ByVal arr As Variant)
    Dim i As Long
    For i = LBound(arr) To UBound(arr)
        firstCell.Offset(0, i - LBound(arr)).Value = arr(i)
    Next i
End Sub

Public Sub HeaderStyle(ByVal rng As Range, Optional ByVal fillColor As Long = 0)
    ThemeApplyHeader rng, fillColor
End Sub

Public Sub SectionStyle(ByVal rng As Range, Optional ByVal titleText As String = "")
    ThemeApplySection rng, titleText
End Sub

Public Sub InputStyle(ByVal rng As Range)
    ThemeApplyInput rng
End Sub

Public Sub LockedStyle(ByVal rng As Range)
    ThemeApplyLocked rng
End Sub

Public Sub ApplySheetCanvas(ByVal ws As Worksheet)
    ThemeApplyCanvas ws
End Sub

Public Sub TitleBannerStyle(ByVal rng As Range, Optional ByVal titleText As String = "")
    ThemeApplyTitle rng, titleText
End Sub

Public Sub FlowBarStyle(ByVal rng As Range)
    If rng Is Nothing Then Exit Sub
    With rng
        .Interior.Color = ThemeColor("flow")
        .Font.Name = THEME_FONT
        .Font.Bold = True
        .Font.Color = ThemeColor("teal")
        .HorizontalAlignment = xlCenter
        .VerticalAlignment = xlCenter
    End With
    ThemeApplyCompleteBorders rng, "border"
End Sub

Public Sub PanelBorderStyle(ByVal rng As Range)
    If rng Is Nothing Then Exit Sub
    ThemeApplyCompleteBorders rng, "border-soft"
End Sub

Public Sub PanelOutlineStyle(ByVal rng As Range, Optional ByVal colorRole As String = "border-soft", Optional ByVal lineWeight As Long = xlMedium)
    '�{�^����u���Z���Ɋi�q���������Ȃ��B�͈͂̊O�g������ǉ�����B
    '�����̌Â����͌Ăяo�����őΏ۔͈͂��ꊇ�N���A���Ă��珈������B
    If rng Is Nothing Then Exit Sub
    ThemeApplyOuterBorders rng, colorRole, lineWeight
End Sub

Private Function ButtonFillColor(ByVal caption As String) As Long
    ButtonFillColor = ThemeButtonFill(caption)
End Function

Public Sub AddButton(ByVal ws As Worksheet, _
        ByVal cellAddress As String, _
        ByVal caption As String, _
        ByVal macroName As String, _
        Optional ByVal width As Double = 120, _
        Optional ByVal height As Double = 28)
    Dim c As Range, shp As Shape, b As Button
    Dim leftPt As Double, topPt As Double, widthPt As Double, heightPt As Double
    Dim formButtonFontSize As Double
    Const BTN_MARGIN As Double = 2.5
    If ws Is Nothing Then Exit Sub
    Set c = ws.Range(cellAddress)
    '�{�^���͕K���A���J�[�͈͂̓����Ɏ��߂�B�ŏ��T�C�Y��D�悵�Čr���O�֏o���Ȃ��B
    widthPt = Application.Max(6, c.Width - BTN_MARGIN * 2)
    heightPt = Application.Max(6, c.Height - BTN_MARGIN * 2)
    If width > 0 Then widthPt = Application.Min(widthPt, width)
    If height > 0 Then heightPt = Application.Min(heightPt, height)
    leftPt = c.Left + Application.Max(0.75, (c.Width - widthPt) / 2)
    topPt = c.Top + Application.Max(0.75, (c.Height - heightPt) / 2)
    On Error GoTo UseFormButton
    Set shp = ws.Shapes.AddShape(msoShapeRoundedRectangle, leftPt, topPt, widthPt, heightPt)
    shp.Name = "btn_" & Replace(caption, " ", "_") & "_" & Format(Timer * 100, "0")
    ThemeStyleButtonShape shp, caption, "", macroName
    Exit Sub
UseFormButton:
    Err.Clear
    If widthPt < 70 Or Len(caption) >= 12 Then
        formButtonFontSize = 9.8
    Else
        formButtonFontSize = 11
    End If
    On Error Resume Next
    Set b = ws.Buttons.Add(leftPt, topPt, widthPt, heightPt)
    With b
        .Caption = caption
        .OnAction = macroName
        .Font.Name = THEME_FONT
        .Font.Size = formButtonFontSize
        .Font.Bold = True
        .Placement = xlMoveAndSize
        .Locked = True
        .PrintObject = False
    End With
    On Error GoTo 0
End Sub

Public Sub AddFixedButton(ByVal ws As Worksheet, _
        ByVal leftPt As Double, _
        ByVal topPt As Double, _
        ByVal widthPt As Double, _
        ByVal heightPt As Double, _
        ByVal caption As String, _
        ByVal macroName As String)
    Dim shp As Shape, b As Button
    If ws Is Nothing Then Exit Sub
    If widthPt < 12 Or heightPt < 12 Then Exit Sub
    On Error GoTo UseFormButton
    Set shp = ws.Shapes.AddShape(msoShapeRoundedRectangle, leftPt, topPt, widthPt, heightPt)
    shp.Name = "btn_" & Replace(caption, " ", "_") & "_" & Format(Timer * 100, "0")
    ThemeStyleButtonShape shp, caption, "", macroName
    Exit Sub
UseFormButton:
    Err.Clear
    On Error Resume Next
    Set b = ws.Buttons.Add(leftPt, topPt, widthPt, heightPt)
    With b
        .Caption = caption
        .OnAction = macroName
        .Font.Name = THEME_FONT
        .Font.Size = 11.5
        .Font.Bold = True
        .Placement = xlMoveAndSize
        .Locked = True
        .PrintObject = False
    End With
    On Error GoTo 0
End Sub

Public Sub CapColumnWidths(ByVal ws As Worksheet, ByVal firstCol As Long, ByVal lastCol As Long, ByVal maxWidth As Double)
    Dim c As Long
    On Error Resume Next
    For c = firstCol To lastCol
        If ws.Columns(c).ColumnWidth > maxWidth Then ws.Columns(c).ColumnWidth = maxWidth
    Next c
    On Error GoTo 0
End Sub

Public Sub CapUsedColumnWidths(ByVal ws As Worksheet, Optional ByVal maxWidth As Double = 38)
    Dim lastC As Long
    Dim f As Range
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    Set f = ws.Cells.Find(What:="*", LookIn:=xlFormulas, SearchOrder:=xlByColumns, SearchDirection:=xlPrevious)
    If Not f Is Nothing Then lastC = f.Column
    If lastC > 0 Then CapColumnWidths ws, 1, lastC, maxWidth
    On Error GoTo 0
End Sub

Public Function CleanText(ByVal v As Variant) As String
    If IsError(v) Or IsNull(v) Or IsEmpty(v) Then
        CleanText = ""
    Else
        CleanText = Trim$(CStr(v))
    End If
End Function

Public Function CellText(ByVal v As Variant) As String
    If IsError(v) Or IsNull(v) Or IsEmpty(v) Then
        CellText = ""
    Else
        CellText = Trim$(CStr(v))
    End If
End Function

Public Function ComposeDisplayName(ByVal surname As String, ByVal givenName As String, ByVal formerSurname As String) As String
    Dim nm As String
    nm = Trim(surname & " " & givenName)
    If Len(formerSurname) > 0 Then nm = nm & "�i�����F" & formerSurname & "�j"
    ComposeDisplayName = nm
End Function

Public Function ParseIdFromCandidate(ByVal s As String) As String
    Dim p As Long
    s = Trim(s)
    p = InStr(1, s, " ")
    If p > 1 Then
        ParseIdFromCandidate = Left$(s, p - 1)
    ElseIf InStr(1, s, ":") > 1 Then
        ParseIdFromCandidate = Left$(s, InStr(1, s, ":") - 1)
    Else
        ParseIdFromCandidate = s
    End If
End Function

Public Function NormalizeAddress(ByVal addressText As String) As String
    Dim s As String
    s = Trim(addressText)
    On Error Resume Next
    s = StrConv(s, vbNarrow)
    On Error GoTo 0
    s = Replace(s, " ", "")
    s = Replace(s, "�@", "")
    s = Replace(s, "�|", "-")
    s = Replace(s, "�[", "-")
    s = Replace(s, "�|", "-")
    s = Replace(s, "����", "-")
    s = Replace(s, "�Ԓn", "-")
    s = Replace(s, "��", "-")
    s = Replace(s, "��", "")
    s = Replace(s, "��", "-")
    Do While InStr(s, "--") > 0
        s = Replace(s, "--", "-")
    Loop
    If Right$(s, 1) = "-" Then s = Left$(s, Len(s) - 1)
    NormalizeAddress = s
End Function

Public Function SameDateOrBlank(ByVal v As Variant) As Variant
    If IsDate(v) Then SameDateOrBlank = CDate(v) Else SameDateOrBlank = ""
End Function

Public Function AgeOnDate(ByVal birthDate As Variant, ByVal baseDate As Variant) As String
    If Not IsDate(birthDate) Or Not IsDate(baseDate) Then
        AgeOnDate = ""
        Exit Function
    End If
    Dim age As Long
    age = Year(CDate(baseDate)) - Year(CDate(birthDate))
    If DateSerial(Year(CDate(baseDate)), Month(CDate(birthDate)), Day(CDate(birthDate))) > CDate(baseDate) Then age = age - 1
    AgeOnDate = CStr(age) & "��"
End Function

Public Function PeriodText(ByVal startDate As Variant, ByVal endDate As Variant) As String
    If Not IsDate(startDate) Or Not IsDate(endDate) Then
        PeriodText = "���ԗv�m�F"
        Exit Function
    End If
    Dim s As Date, e As Date, y As Long, m As Long, d As Long, tmp As Date
    s = CDate(startDate): e = CDate(endDate)
    If e < s Then
        PeriodText = "���ԗv�m�F"
        Exit Function
    End If
    y = Year(e) - Year(s)
    tmp = DateAdd("yyyy", y, s)
    If tmp > e Then
        y = y - 1
        tmp = DateAdd("yyyy", y, s)
    End If
    m = DateDiff("m", tmp, e)
    If DateAdd("m", m, tmp) > e Then m = m - 1
    tmp = DateAdd("m", m, tmp)
    d = DateDiff("d", tmp, e) + 1
    PeriodText = y & "�N" & m & "����" & d & "��"
End Function



Public Function EraYearText(ByVal westernYear As Long) As String
    Select Case westernYear
        Case 2019
            EraYearText = "����31�N�^�ߘa���N"
        Case 1989
            EraYearText = "���a64�N�^�������N"
        Case 1926
            EraYearText = "�吳15�N�^���a���N"
        Case 1912
            EraYearText = "����45�N�^�吳���N"
        Case Is >= 2020
            EraYearText = "�ߘa" & CStr(westernYear - 2018) & "�N"
        Case Is >= 1990
            EraYearText = "����" & CStr(westernYear - 1988) & "�N"
        Case Is >= 1927
            EraYearText = "���a" & CStr(westernYear - 1925) & "�N"
        Case Is >= 1913
            EraYearText = "�吳" & CStr(westernYear - 1911) & "�N"
        Case Is >= 1868
            EraYearText = "����" & CStr(westernYear - 1867) & "�N"
        Case Else
            EraYearText = "����" & CStr(westernYear) & "�N"
    End Select
End Function

Public Function EraDateText(ByVal v As Variant) As String
    If Not IsDate(v) Then
        EraDateText = ""
        Exit Function
    End If
    Dim d As Date, eraName As String, eraYear As Long
    d = CDate(v)
    If d >= DateSerial(2019, 5, 1) Then
        eraName = "�ߘa": eraYear = Year(d) - 2018
    ElseIf d >= DateSerial(1989, 1, 8) Then
        eraName = "����": eraYear = Year(d) - 1988
    ElseIf d >= DateSerial(1926, 12, 25) Then
        eraName = "���a": eraYear = Year(d) - 1925
    ElseIf d >= DateSerial(1912, 7, 30) Then
        eraName = "�吳": eraYear = Year(d) - 1911
    ElseIf d >= DateSerial(1868, 1, 25) Then
        eraName = "����": eraYear = Year(d) - 1867
    Else
        EraDateText = Format(d, "yyyy/m/d")
        Exit Function
    End If
    If eraYear = 1 Then
        EraDateText = eraName & "���N" & Month(d) & "��" & Day(d) & "��"
    Else
        EraDateText = eraName & eraYear & "�N" & Month(d) & "��" & Day(d) & "��"
    End If
End Function

Public Function EnsureWorkbookLocalBaseFolder(Optional ByVal purposeText As String = "�o��") As String
    Dim basePath As String
    basePath = ThisWorkbook.Path
    If Len(basePath) > 0 Then
        If Not RuntimeIsWebPath(basePath) Then
            EnsureWorkbookLocalBaseFolder = basePath
            Exit Function
        End If
    End If

    'SharePoint/OneDrive��URL�Ƃ��ĊJ���Ă���ꍇ�ADir/MkDir/Name�ł͕ۑ��ł��Ȃ��B
    '���̏ꍇ�������[�J���̈Č��t�H���_��I�΂��Ahttps���t�@�C���p�X�Ƃ��Ĉ���Ȃ��B
    EnsureWorkbookLocalBaseFolder = RuntimePickLocalFolder("01 �l�����: " & purposeText & "�̕ۑ��惍�[�J���t�H���_��I��")
End Function

Public Function EnsureOutputFolder() As String
    Dim basePath As String, outPath As String
    basePath = EnsureWorkbookLocalBaseFolder("�����o��")
    If Len(basePath) = 0 Then
        EnsureOutputFolder = ""
        Exit Function
    End If
    outPath = RuntimeCombinePath(basePath, "�o��")
    RuntimeEnsureFolderExists outPath, "EnsureOutputFolder"
    EnsureOutputFolder = outPath
End Function

Public Function QuoteSheet(ByVal sheetName As String) As String
    QuoteSheet = "'" & Replace(sheetName, "'", "''") & "'"
End Function

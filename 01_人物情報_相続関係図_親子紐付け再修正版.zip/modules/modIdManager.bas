Attribute VB_Name = "modIdManager"
Option Explicit

Public Sub InitIdManager(Optional ByVal resetData As Boolean = False)
    Dim ws As Worksheet
    Set ws = EnsureSheet(SH_W_ID, xlSheetVeryHidden)
    If resetData Or LastRow(ws, 1) < 2 Then
        ws.Cells.Clear
        SetRowValues ws.Range("A1"), Array("���", "�ړ���", "���ԍ�", "�ŏI�̔ԓ���")
        SetRowValues ws.Range("A2"), Array("�l��", "P", NextNumberFromExistingIds(SH_W_PERSON, 1, "P"), "")
        SetRowValues ws.Range("A3"), Array("�֌W", "RL", NextNumberFromExistingIds(SH_W_REL, 1, "RL"), "")
        SetRowValues ws.Range("A4"), Array("�Z�����", "AM", NextNumberFromExistingIds(SH_W_ADDR_CAND, 1, "AM"), "")
        SetRowValues ws.Range("A5"), Array("�Z������", "AD", NextNumberFromExistingIds(SH_W_ADDR_HIST, 1, "AD"), "")
        SetRowValues ws.Range("A6"), Array("�C�x���g", "EV", NextNumberFromExistingIds(SH_W_EVENT, 1, "EV"), "")
        SetRowValues ws.Range("A7"), Array("��������", "MH", NextNumberFromExistingIds(SH_W_MARRIAGE_HIST, 1, "MH"), "")
    Else
        EnsureIdRow ws, "�l��", "P", SH_W_PERSON
        EnsureIdRow ws, "�֌W", "RL", SH_W_REL
        EnsureIdRow ws, "�Z�����", "AM", SH_W_ADDR_CAND
        EnsureIdRow ws, "�Z������", "AD", SH_W_ADDR_HIST
        EnsureIdRow ws, "�C�x���g", "EV", SH_W_EVENT
        EnsureIdRow ws, "��������", "MH", SH_W_MARRIAGE_HIST
    End If
    HeaderStyle ws.Range("A1:D1")
End Sub

Private Sub EnsureIdRow(ByVal ws As Worksheet, ByVal kind As String, ByVal prefix As String, ByVal sourceSheet As String)
    Dim r As Long, lastR As Long
    Dim currentValue As Variant
    lastR = LastRow(ws, 1)
    For r = 2 To lastR
        If CStr(ws.Cells(r, 1).Value) = kind Then
            If Len(CStr(ws.Cells(r, 2).Value)) = 0 Then ws.Cells(r, 2).Value = prefix
            currentValue = ws.Cells(r, 3).Value
            If Not IsNumeric(currentValue) Then
                ws.Cells(r, 3).Value = NextNumberFromExistingIds(sourceSheet, 1, prefix)
            ElseIf CLng(currentValue) < 1 Then
                ws.Cells(r, 3).Value = NextNumberFromExistingIds(sourceSheet, 1, prefix)
            End If
            Exit Sub
        End If
    Next r
    r = lastR + 1
    If r < 2 Then r = 2
    SetRowValues ws.Cells(r, 1), Array(kind, prefix, NextNumberFromExistingIds(sourceSheet, 1, prefix), "")
End Sub

Private Function NextNumberFromExistingIds(ByVal sheetName As String, ByVal idCol As Long, ByVal prefix As String) As Long
    Dim ws As Worksheet, r As Long, lastR As Long, s As String, n As Long, maxN As Long
    NextNumberFromExistingIds = 1
    If Not SheetExists(sheetName) Then Exit Function
    Set ws = ThisWorkbook.Worksheets(sheetName)
    lastR = LastRow(ws, idCol)
    For r = 2 To lastR
        s = CStr(ws.Cells(r, idCol).Value)
        If UCase$(Left$(s, Len(prefix))) = UCase$(prefix) Then
            If IsNumeric(Mid$(s, Len(prefix) + 1)) Then
                n = CLng(Mid$(s, Len(prefix) + 1))
                If n > maxN Then maxN = n
            End If
        End If
    Next r
    NextNumberFromExistingIds = maxN + 1
End Function

Public Function NextId(ByVal kind As String) As String
    Dim ws As Worksheet, r As Long, lastR As Long, prefix As String, nextNum As Long
    Dim idFormat As String
    Set ws = EnsureSheet(SH_W_ID, xlSheetVeryHidden)
    lastR = LastRow(ws, 1)
    For r = 2 To lastR
        If CStr(ws.Cells(r, 1).Value) = kind Then
            prefix = CStr(ws.Cells(r, 2).Value)
            nextNum = CLng(ws.Cells(r, 3).Value)
            If kind = "�l��" Then
                idFormat = "0000"
            Else
                idFormat = "000000"
            End If
            NextId = prefix & Format(nextNum, idFormat)
            ws.Cells(r, 3).Value = nextNum + 1
            ws.Cells(r, 4).Value = Now
            Exit Function
        End If
    Next r
    Err.Raise 5, "NextId", "ID��ʂ�������܂���: " & kind
End Function

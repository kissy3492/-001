Attribute VB_Name = "modQuietUi"
Option Explicit

' �ʏ푀����~�߂Ȃ��y�ʒʒm�B�����E�m�F�E���̓K�C�h�͒�~�_�C�A���O�ɂ����A
' �X�e�[�^�X�o�[�ƕK�v����C_�`�F�b�N�ǋL�Ɋ񂹂�B
Public Sub QuietInfo(ByVal messageText As String, Optional ByVal logToCheck As Boolean = False, Optional ByVal operationName As String = "")
    QuietNotify "���", messageText, logToCheck, operationName
End Sub

Public Sub QuietWarn(ByVal messageText As String, Optional ByVal logToCheck As Boolean = True, Optional ByVal operationName As String = "")
    QuietNotify "����", messageText, logToCheck, operationName
End Sub

Private Sub QuietNotify(ByVal kindText As String, ByVal messageText As String, ByVal logToCheck As Boolean, ByVal operationName As String)
    On Error Resume Next
    Application.StatusBar = Replace(Replace(messageText, vbCrLf, " / "), vbLf, " / ")
    If logToCheck Then QuietAppendCheck kindText, operationName, messageText
    On Error GoTo 0
End Sub

Private Sub QuietAppendCheck(ByVal kindText As String, ByVal operationName As String, ByVal detailText As String)
    On Error Resume Next
    Dim ws As Worksheet
    Dim r As Long

    Set ws = ThisWorkbook.Worksheets(SH_CHECK)
    If ws Is Nothing Then Exit Sub

    If Len(CStr(ws.Cells(1, 1).Value)) = 0 Then
        ws.Cells(1, 1).Value = "�敪"
        ws.Cells(1, 2).Value = "�H��"
        ws.Cells(1, 3).Value = "���e"
        ws.Cells(1, 4).Value = "������"
        ws.Cells(1, 5).Value = "����"
    End If

    r = ws.Cells(ws.Rows.Count, 1).End(xlUp).Row + 1
    If r < 2 Then r = 2
    ws.Cells(r, 1).Value = kindText
    If Len(operationName) > 0 Then
        ws.Cells(r, 2).Value = operationName
    Else
        ws.Cells(r, 2).Value = "����ʒm"
    End If
    ws.Cells(r, 3).Value = detailText
    ws.Cells(r, 4).Value = "�K�v�ɉ����Ċm�F"
    ws.Cells(r, 5).Value = Now
    On Error GoTo 0
End Sub

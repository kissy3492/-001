Attribute VB_Name = "modMarriageHistoryReview"
Option Explicit

'W_���������𒼐ڃ��[�U�[�ɐG�点���A�m�F�E�␳�p�̔�����ʂ��o�R������B
'����ID�E��Ԃ͎c���A���薼�E���t�E�\��/�����l�Ԃ�������悤�ɂ���B

Private Const MR_HEADER_ROW As Long = 3
Private Const MR_FIRST_DATA_ROW As Long = 4
Private Const MR_COL_STATUS As Long = 1
Private Const MR_COL_ID As Long = 2
Private Const MR_COL_PERSON_ID As Long = 3
Private Const MR_COL_PERSON_NAME As Long = 4
Private Const MR_COL_COUNTERPART_ID As Long = 5
Private Const MR_COL_COUNTERPART_NAME As Long = 6
Private Const MR_COL_MARRIAGE As Long = 7
Private Const MR_COL_DIVORCE As Long = 8
Private Const MR_COL_STATE As Long = 9
Private Const MR_COL_SOURCE As Long = 10
Private Const MR_COL_NOTE As Long = 11
Private Const MR_COL_SHOW As Long = 12
Private Const MR_COL_DATA_STATUS As Long = 13
Private Const MR_COL_APPLY_MEMO As Long = 14
Private Const MR_COL_PERSON_CANDIDATES As Long = 15
Private Const MR_COL_COUNTERPART_CANDIDATES As Long = 16
Private Const MR_COL_ACTION_HINT As Long = 17

Public Sub BuildMarriageHistoryReviewSheet()
    Dim ws As Worksheet
    Set ws = EnsureSheet(SH_MARRIAGE_REVIEW, xlSheetHidden)
    ClearSheetAll ws
    ApplySheetCanvas ws
    ws.Range("A1:Q1").Merge
    TitleBannerStyle ws.Range("A1:Q1"), "���������m�F"
    ws.Range("A2:Q2").Merge
    ws.Range("A2").Value = "�����E������ W_�������� �𐳖{�ɂ��܂��B���������̕␳�ɉ����A�ŉ��s�ɐl����/�l��ID�E���薼�E���t����͂���ΐV�K�����Ƃ��Ēǉ��ł��܂��B���肪�l�����o�^�Ȃ瑊�薼�����ŕێ����܂��B"
    ws.Range("A2").WrapText = True
    SetRowValues ws.Cells(MR_HEADER_ROW, 1), Array("���", "��������ID", "�l��ID", "�l����", "����l��ID", "���薼", "������", "������", "�������", "����", "���l", "�\��", "�f�[�^���", "���f����", "�l�����", "������", "����q���g")
    HeaderStyle ws.Range("A" & MR_HEADER_ROW & ":Q" & MR_HEADER_ROW)
    ws.Columns("A:A").ColumnWidth = 14
    ws.Columns("B:C").ColumnWidth = 14
    ws.Columns("D:D").ColumnWidth = 18
    ws.Columns("E:E").ColumnWidth = 14
    ws.Columns("F:F").ColumnWidth = 22
    ws.Columns("G:H").ColumnWidth = 12
    ws.Columns("I:J").ColumnWidth = 14
    ws.Columns("K:K").ColumnWidth = 32
    ws.Columns("L:M").ColumnWidth = 12
    ws.Columns("N:N").ColumnWidth = 28
    ws.Columns("O:P").ColumnWidth = 34
    ws.Columns("Q:Q").ColumnWidth = 36
    ws.Rows("2:2").RowHeight = 42
    ws.Range("G:H").NumberFormatLocal = "yyyy/m/d"
    AddButton ws, "S3", "�V�K�s", "AppendMarriageHistoryReviewBlankRow", 100, 26
    AddButton ws, "S5", "�ēǍ�", "RefreshMarriageHistoryReviewSheet", 100, 26
    AddButton ws, "S7", "�ҏW���f", "ApplyMarriageHistoryReviewEdits", 110, 26
    AddButton ws, "S9", "���֖͂߂�", "ShowOnlyInput", 110, 26
    AddMarriageReviewValidation ws
    SetSheetVisibilitySafe ws, xlSheetHidden
End Sub

Public Sub ShowMarriageHistoryReviewSheet()
    On Error GoTo EH
    AppBegin "���������m�F���X�V��..."
    EnsureMarriageHistoryWorkSheet
    BackfillMarriageHistoryFromLegacyFacts
    If Not SheetExists(SH_MARRIAGE_REVIEW, ThisWorkbook) Then BuildMarriageHistoryReviewSheet
    FillMarriageHistoryReviewSheet
    ShowOnlyInputCore False
    With ThisWorkbook.Worksheets(SH_MARRIAGE_REVIEW)
        .Visible = xlSheetVisible
        .Activate
        .Range("A1").Select
    End With
CleanExit:
    AppEnd
    Exit Sub
EH:
    AppEnd
    RuntimeShowError "ShowMarriageHistoryReviewSheet", "���������m�F", "W_���������̃w�b�_�[�A�l��ID�A���t�����m�F���Ă��������B"
End Sub

Public Sub RefreshMarriageHistoryReviewSheet()
    ShowMarriageHistoryReviewSheet
End Sub

Private Sub FillMarriageHistoryReviewSheet()
    Dim ws As Worksheet, mh As Worksheet
    Dim r As Long, outR As Long, lastR As Long, pid As String
    If Not SheetExists(SH_MARRIAGE_REVIEW, ThisWorkbook) Then BuildMarriageHistoryReviewSheet
    EnsureMarriageHistoryWorkSheet
    Set ws = ThisWorkbook.Worksheets(SH_MARRIAGE_REVIEW)
    Set mh = ThisWorkbook.Worksheets(SH_W_MARRIAGE_HIST)
    ws.Range("A" & MR_FIRST_DATA_ROW & ":Q" & ws.Rows.Count).ClearContents
    lastR = LastRow(mh, 1)
    outR = MR_FIRST_DATA_ROW
    For r = 2 To lastR
        If Len(CleanText(mh.Cells(r, MH_ID).Value)) > 0 Then
            pid = CleanText(mh.Cells(r, MH_PERSON_ID).Value)
            ws.Cells(outR, MR_COL_STATUS).Value = MarriageReviewRowStatus(mh, r)
            ws.Cells(outR, MR_COL_ID).Value = mh.Cells(r, MH_ID).Value
            ws.Cells(outR, MR_COL_PERSON_ID).Value = pid
            ws.Cells(outR, MR_COL_PERSON_NAME).Value = GetPersonValue(pid, P_DISPLAY)
            ws.Cells(outR, MR_COL_COUNTERPART_ID).Value = mh.Cells(r, MH_COUNTERPART_ID).Value
            ws.Cells(outR, MR_COL_COUNTERPART_NAME).Value = mh.Cells(r, MH_COUNTERPART_NAME).Value
            ws.Cells(outR, MR_COL_MARRIAGE).Value = mh.Cells(r, MH_MARRIAGE).Value
            ws.Cells(outR, MR_COL_DIVORCE).Value = mh.Cells(r, MH_DIVORCE).Value
            ws.Cells(outR, MR_COL_STATE).Value = mh.Cells(r, MH_STATE).Value
            ws.Cells(outR, MR_COL_SOURCE).Value = mh.Cells(r, MH_SOURCE).Value
            ws.Cells(outR, MR_COL_NOTE).Value = mh.Cells(r, MH_NOTE).Value
            ws.Cells(outR, MR_COL_SHOW).Value = mh.Cells(r, MH_SHOW).Value
            ws.Cells(outR, MR_COL_DATA_STATUS).Value = mh.Cells(r, MH_STATUS).Value
            ws.Cells(outR, MR_COL_PERSON_CANDIDATES).Value = MarriageReviewCandidateText(ws.Cells(outR, MR_COL_PERSON_NAME).Value)
            ws.Cells(outR, MR_COL_COUNTERPART_CANDIDATES).Value = MarriageReviewCandidateText(ws.Cells(outR, MR_COL_COUNTERPART_NAME).Value)
            ws.Cells(outR, MR_COL_ACTION_HINT).Value = "���������B���t�E���薼�E�\��/����𒼂��ĕҏW���f�B�l��ID�𒼂��ꍇ�͎���ID����ӂ̐l�����ɂ��Ă��������B"
            outR = outR + 1
        End If
    Next r
    If outR = MR_FIRST_DATA_ROW Then
        ws.Cells(outR, MR_COL_STATUS).Value = "�V�K���͉�"
        ws.Cells(outR, MR_COL_SHOW).Value = SHOW_YES
        ws.Cells(outR, MR_COL_DATA_STATUS).Value = STATUS_ACTIVE
        ws.Cells(outR, MR_COL_APPLY_MEMO).Value = "�l��ID�܂��͈�ӂɌ��܂�l�����A���薼�A������/�������̂����ꂩ����͂��ĕҏW���f�B"
        ws.Cells(outR, MR_COL_ACTION_HINT).Value = "�����l���o�^���Ȃ��ꍇ�͑��薼�����ŉB�������Ȃ�l��ID�𒼐ڎw��B"
    Else
        ws.Cells(outR, MR_COL_STATUS).Value = "�V�K���͉�"
        ws.Cells(outR, MR_COL_SHOW).Value = SHOW_YES
        ws.Cells(outR, MR_COL_DATA_STATUS).Value = STATUS_ACTIVE
        ws.Cells(outR, MR_COL_ACTION_HINT).Value = "�V�K�����������֒ǉ����͂ł��܂��B"
    End If
    ws.Range("A" & MR_FIRST_DATA_ROW & ":Q" & Application.Max(MR_FIRST_DATA_ROW, outR)).VerticalAlignment = xlCenter
    ws.Range("A" & MR_FIRST_DATA_ROW & ":Q" & Application.Max(MR_FIRST_DATA_ROW, outR)).WrapText = True
    ws.Range("G" & MR_FIRST_DATA_ROW & ":H" & Application.Max(MR_FIRST_DATA_ROW, outR)).NumberFormatLocal = "yyyy/m/d"
End Sub

Public Sub AppendMarriageHistoryReviewBlankRow()
    Dim ws As Worksheet, r As Long
    On Error GoTo EH
    If Not SheetExists(SH_MARRIAGE_REVIEW, ThisWorkbook) Then BuildMarriageHistoryReviewSheet
    Set ws = ThisWorkbook.Worksheets(SH_MARRIAGE_REVIEW)
    ws.Visible = xlSheetVisible
    r = LastRow(ws, MR_COL_STATUS) + 1
    If r < MR_FIRST_DATA_ROW Then r = MR_FIRST_DATA_ROW
    ws.Cells(r, MR_COL_STATUS).Value = "�V�K����"
    ws.Cells(r, MR_COL_SHOW).Value = SHOW_YES
    ws.Cells(r, MR_COL_DATA_STATUS).Value = STATUS_ACTIVE
    ws.Cells(r, MR_COL_SOURCE).Value = "�����������"
    ws.Cells(r, MR_COL_ACTION_HINT).Value = "�l��ID�܂��͐l�����A���薼�A������/�������̂����ꂩ����͂��ĕҏW���f�B"
    ws.Range("A" & r & ":Q" & r).WrapText = True
    ws.Range("G" & r & ":H" & r).NumberFormatLocal = "yyyy/m/d"
    ws.Cells(r, MR_COL_PERSON_NAME).Select
    Exit Sub
EH:
    RuntimeShowError "AppendMarriageHistoryReviewBlankRow", "��������V�K�s", "���������m�F�V�[�g���ēǍ����Ă��������B"
End Sub

Private Function MarriageReviewRowStatus(ByVal mh As Worksheet, ByVal r As Long) As String
    Dim msg As String
    If CleanText(mh.Cells(r, MH_STATUS).Value) = STATUS_CANCEL Then msg = JoinMarriageReviewMsg(msg, "���")
    If Len(CleanText(mh.Cells(r, MH_PERSON_ID).Value)) = 0 Then msg = JoinMarriageReviewMsg(msg, "�l��ID�Ȃ�")
    If Not IsDate(mh.Cells(r, MH_MARRIAGE).Value) And Not IsDate(mh.Cells(r, MH_DIVORCE).Value) Then msg = JoinMarriageReviewMsg(msg, "���t�Ȃ�")
    If IsDate(mh.Cells(r, MH_MARRIAGE).Value) And IsDate(mh.Cells(r, MH_DIVORCE).Value) Then
        If CDate(mh.Cells(r, MH_DIVORCE).Value) < CDate(mh.Cells(r, MH_MARRIAGE).Value) Then msg = JoinMarriageReviewMsg(msg, "���t�t�]")
    End If
    If Len(msg) = 0 Then msg = "OK"
    MarriageReviewRowStatus = msg
End Function

Private Function JoinMarriageReviewMsg(ByVal baseText As String, ByVal addText As String) As String
    If Len(baseText) = 0 Then
        JoinMarriageReviewMsg = addText
    Else
        JoinMarriageReviewMsg = baseText & " / " & addText
    End If
End Function

Public Sub ApplyMarriageHistoryReviewEdits()
    Dim ws As Worksheet, mh As Worksheet
    Dim r As Long, lastR As Long, histId As String, targetRow As Long
    Dim applied As Long, created As Long, skipped As Long
    Dim pid As String, pidMsg As String, cpId As String, cpMsg As String, cpName As String
    Dim mDate As Variant, dDate As Variant, sourceText As String, noteText As String
    On Error GoTo EH
    AppBegin "���������̕ҏW�𔽉f��..."
    If Not SheetExists(SH_MARRIAGE_REVIEW, ThisWorkbook) Then Err.Raise vbObjectError + 1501, , "���������m�F�V�[�g������܂���B"
    EnsureMarriageHistoryWorkSheet
    Set ws = ThisWorkbook.Worksheets(SH_MARRIAGE_REVIEW)
    Set mh = ThisWorkbook.Worksheets(SH_W_MARRIAGE_HIST)
    lastR = MarriageReviewLastInputRow(ws)
    If lastR < MR_FIRST_DATA_ROW Then lastR = MR_FIRST_DATA_ROW
    For r = MR_FIRST_DATA_ROW To lastR
        histId = CleanText(ws.Cells(r, MR_COL_ID).Value)
        If Len(histId) = 0 Then
            If MarriageReviewRowHasInput(ws, r) Then
                pidMsg = "": cpMsg = ""
                pid = ResolveMarriageReviewPersonId(ws.Cells(r, MR_COL_PERSON_ID).Value, ws.Cells(r, MR_COL_PERSON_NAME).Value, True, pidMsg)
                cpName = CleanText(ws.Cells(r, MR_COL_COUNTERPART_NAME).Value)
                cpId = ResolveMarriageReviewPersonId(ws.Cells(r, MR_COL_COUNTERPART_ID).Value, cpName, False, cpMsg)
                mDate = ReviewSameDateOrBlank(ws.Cells(r, MR_COL_MARRIAGE).Value)
                dDate = ReviewSameDateOrBlank(ws.Cells(r, MR_COL_DIVORCE).Value)
                If Len(pid) = 0 Then
                    ws.Cells(r, MR_COL_APPLY_MEMO).Value = "�����f: " & pidMsg
                    skipped = skipped + 1
                ElseIf Not IsDate(mDate) And Not IsDate(dDate) Then
                    ws.Cells(r, MR_COL_APPLY_MEMO).Value = "�����f: �������܂��͗������̂����ꂩ����͂��Ă��������B"
                    skipped = skipped + 1
                Else
                    If Len(cpName) = 0 And Len(cpId) > 0 Then cpName = GetPersonValue(cpId, P_DISPLAY)
                    sourceText = CleanText(ws.Cells(r, MR_COL_SOURCE).Value)
                    If Len(sourceText) = 0 Then sourceText = "�����������"
                    noteText = CleanText(ws.Cells(r, MR_COL_NOTE).Value)
                    If Len(cpMsg) > 0 Then noteText = JoinMarriageReviewMsg(noteText, cpMsg)
                    UpsertMarriageHistory pid, cpId, cpName, mDate, dDate, sourceText, "MR|" & Format$(Now, "yyyymmddhhnnss") & "|" & CStr(r), noteText
                    ws.Cells(r, MR_COL_APPLY_MEMO).Value = "�V�K�쐬�� " & Format$(Now, "yyyy/m/d h:nn")
                    created = created + 1
                End If
            End If
        Else
            targetRow = FindMarriageHistoryRowById(histId)
            If targetRow > 0 Then
                pidMsg = "": cpMsg = ""
                pid = ResolveMarriageReviewPersonId(ws.Cells(r, MR_COL_PERSON_ID).Value, ws.Cells(r, MR_COL_PERSON_NAME).Value, True, pidMsg)
                cpName = CleanText(ws.Cells(r, MR_COL_COUNTERPART_NAME).Value)
                cpId = ResolveMarriageReviewPersonId(ws.Cells(r, MR_COL_COUNTERPART_ID).Value, cpName, False, cpMsg)
                If Len(pid) = 0 Then
                    ws.Cells(r, MR_COL_APPLY_MEMO).Value = "�����f: " & pidMsg
                    skipped = skipped + 1
                Else
                    mh.Cells(targetRow, MH_PERSON_ID).Value = pid
                    mh.Cells(targetRow, MH_COUNTERPART_ID).Value = cpId
                    mh.Cells(targetRow, MH_COUNTERPART_NAME).Value = cpName
                    mh.Cells(targetRow, MH_MARRIAGE).Value = ReviewSameDateOrBlank(ws.Cells(r, MR_COL_MARRIAGE).Value)
                    mh.Cells(targetRow, MH_DIVORCE).Value = ReviewSameDateOrBlank(ws.Cells(r, MR_COL_DIVORCE).Value)
                    mh.Cells(targetRow, MH_STATE).Value = NormalizedMarriageState(ws.Cells(r, MR_COL_STATE).Value, ws.Cells(r, MR_COL_MARRIAGE).Value, ws.Cells(r, MR_COL_DIVORCE).Value)
                    mh.Cells(targetRow, MH_NOTE).Value = JoinMarriageReviewMsg(CleanText(ws.Cells(r, MR_COL_NOTE).Value), cpMsg)
                    mh.Cells(targetRow, MH_SHOW).Value = NormalizedShowFlag(ws.Cells(r, MR_COL_SHOW).Value)
                    mh.Cells(targetRow, MH_STATUS).Value = NormalizedMarriageDataStatus(ws.Cells(r, MR_COL_DATA_STATUS).Value)
                    mh.Cells(targetRow, MH_UPDATED).Value = Now
                    ws.Cells(r, MR_COL_APPLY_MEMO).Value = "���f�� " & Format$(Now, "yyyy/m/d h:nn")
                    applied = applied + 1
                End If
            Else
                ws.Cells(r, MR_COL_APPLY_MEMO).Value = "�����\��ID�Ȃ��B�ēǍ����Ă��������B"
                skipped = skipped + 1
            End If
        End If
    Next r
    FillMarriageHistoryReviewSheet
    AppEnd
    NotifyInfo "��������ҏW�𔽉f���܂����B" & vbCrLf & "�X�V: " & applied & "�� / �V�K: " & created & "�� / �����f: " & skipped & "��"
    Exit Sub
EH:
    AppEnd
    RuntimeShowError "ApplyMarriageHistoryReviewEdits", "��������ҏW���f", "��������ID�A�l��ID�A�l�����A���t�A�\��/��������m�F���Ă��������B"
End Sub

Private Function MarriageReviewLastInputRow(ByVal ws As Worksheet) As Long
    MarriageReviewLastInputRow = Application.Max(LastRow(ws, MR_COL_STATUS), LastRow(ws, MR_COL_PERSON_ID), LastRow(ws, MR_COL_PERSON_NAME), LastRow(ws, MR_COL_COUNTERPART_ID), LastRow(ws, MR_COL_COUNTERPART_NAME), LastRow(ws, MR_COL_MARRIAGE), LastRow(ws, MR_COL_DIVORCE))
End Function

Private Function MarriageReviewRowHasInput(ByVal ws As Worksheet, ByVal r As Long) As Boolean
    MarriageReviewRowHasInput = (Len(CleanText(ws.Cells(r, MR_COL_PERSON_ID).Value)) > 0 _
        Or Len(CleanText(ws.Cells(r, MR_COL_PERSON_NAME).Value)) > 0 _
        Or Len(CleanText(ws.Cells(r, MR_COL_COUNTERPART_ID).Value)) > 0 _
        Or Len(CleanText(ws.Cells(r, MR_COL_COUNTERPART_NAME).Value)) > 0 _
        Or IsDate(ws.Cells(r, MR_COL_MARRIAGE).Value) _
        Or IsDate(ws.Cells(r, MR_COL_DIVORCE).Value))
End Function

Private Function ResolveMarriageReviewPersonId(ByVal idValue As Variant, ByVal nameValue As Variant, ByVal requiredPerson As Boolean, ByRef messageText As String) As String
    Dim idText As String, nameText As String, multiple As Boolean
    idText = CleanText(idValue)
    nameText = CleanText(nameValue)
    If Len(idText) > 0 Then
        If FindPersonRow(idText) > 0 Then
            ResolveMarriageReviewPersonId = idText
        Else
            messageText = "�l��ID���l���\�ɂ���܂���: " & idText
        End If
        Exit Function
    End If
    If Len(nameText) > 0 Then
        ResolveMarriageReviewPersonId = FindMarriageReviewUniquePersonIdByName(nameText, multiple)
        If Len(ResolveMarriageReviewPersonId) > 0 Then Exit Function
        If multiple Then
            messageText = "�l�������������ł��B�l��ID���w�肵�Ă�������: " & nameText
        ElseIf requiredPerson Then
            messageText = "�l�������l���\�Ɍ�����܂���: " & nameText
        Else
            messageText = "����l���͖��o�^�Ƃ��đ��薼�̂ݕێ����܂�: " & nameText
        End If
        Exit Function
    End If
    If requiredPerson Then messageText = "�l��ID�܂��͐l�������K�v�ł��B"
End Function

Private Function FindMarriageReviewUniquePersonIdByName(ByVal nameText As String, ByRef multiple As Boolean) As String
    Dim wp As Worksheet, r As Long, lastR As Long, hit As String, key As String, curKey As String
    multiple = False
    If Not SheetExists(SH_W_PERSON, ThisWorkbook) Then Exit Function
    key = MarriageReviewNameKey(nameText)
    If Len(key) = 0 Then Exit Function
    Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)
    lastR = LastRow(wp, 1)
    For r = 2 To lastR
        If CStr(wp.Cells(r, P_STATUS).Value) <> STATUS_CANCEL Then
            curKey = MarriageReviewNameKey(wp.Cells(r, P_DISPLAY).Value)
            If curKey = key Then
                If Len(hit) > 0 And hit <> CleanText(wp.Cells(r, P_ID).Value) Then
                    multiple = True
                    FindMarriageReviewUniquePersonIdByName = ""
                    Exit Function
                End If
                hit = CleanText(wp.Cells(r, P_ID).Value)
            End If
        End If
    Next r
    FindMarriageReviewUniquePersonIdByName = hit
End Function

Private Function MarriageReviewCandidateText(ByVal nameValue As Variant) As String
    Dim wp As Worksheet, r As Long, lastR As Long, key As String, curKey As String, n As Long, lineText As String
    key = MarriageReviewNameKey(nameValue)
    If Len(key) = 0 Then Exit Function
    If Not SheetExists(SH_W_PERSON, ThisWorkbook) Then Exit Function
    Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)
    lastR = LastRow(wp, 1)
    For r = 2 To lastR
        If CStr(wp.Cells(r, P_STATUS).Value) <> STATUS_CANCEL Then
            curKey = MarriageReviewNameKey(wp.Cells(r, P_DISPLAY).Value)
            If curKey = key Then
                n = n + 1
                If n <= 6 Then
                    lineText = CleanText(wp.Cells(r, P_ID).Value) & " / " & CleanText(wp.Cells(r, P_DISPLAY).Value)
                    If Len(CleanText(wp.Cells(r, P_REL_DEC).Value)) > 0 Then lineText = lineText & " / " & CleanText(wp.Cells(r, P_REL_DEC).Value)
                    If Len(MarriageReviewCandidateText) > 0 Then MarriageReviewCandidateText = MarriageReviewCandidateText & vbCrLf
                    MarriageReviewCandidateText = MarriageReviewCandidateText & "�E" & lineText
                End If
            End If
        End If
    Next r
    If n > 6 Then MarriageReviewCandidateText = MarriageReviewCandidateText & vbCrLf & "�E�ق� " & CStr(n - 6) & " ��"
End Function

Private Function MarriageReviewNameKey(ByVal v As Variant) As String
    Dim s As String
    s = CleanText(v)
    On Error Resume Next
    s = StrConv(s, vbNarrow)
    On Error GoTo 0
    s = Replace$(s, " ", "")
    s = Replace$(s, "�@", "")
    s = Replace$(s, "�E", "")
    s = Replace$(s, "�", "")
    s = Replace$(s, "��", "��")
    s = Replace$(s, "�", "��")
    s = Replace$(s, "�", "��")
    MarriageReviewNameKey = s
End Function

Private Function FindMarriageHistoryRowById(ByVal histId As String) As Long
    Dim mh As Worksheet, r As Long, lastR As Long
    histId = CleanText(histId)
    If Len(histId) = 0 Then Exit Function
    Set mh = ThisWorkbook.Worksheets(SH_W_MARRIAGE_HIST)
    lastR = LastRow(mh, 1)
    For r = 2 To lastR
        If CleanText(mh.Cells(r, MH_ID).Value) = histId Then
            FindMarriageHistoryRowById = r
            Exit Function
        End If
    Next r
End Function

Private Function NormalizedMarriageState(ByVal stateValue As Variant, ByVal marriageDate As Variant, ByVal divorceDate As Variant) As String
    Dim s As String
    s = CleanText(stateValue)
    If s = "����" Or s = "����" Or s = "���t�v�m�F" Then NormalizedMarriageState = s: Exit Function
    If IsDate(divorceDate) Then
        NormalizedMarriageState = "����"
    ElseIf IsDate(marriageDate) Then
        NormalizedMarriageState = "����"
    Else
        NormalizedMarriageState = "���t�v�m�F"
    End If
End Function

Private Function NormalizedShowFlag(ByVal v As Variant) As String
    Dim s As String
    s = CleanText(v)
    If s = SHOW_NO Or s = "��\��" Or s = "N" Or s = "0" Then
        NormalizedShowFlag = SHOW_NO
    Else
        NormalizedShowFlag = SHOW_YES
    End If
End Function

Private Function NormalizedMarriageDataStatus(ByVal v As Variant) As String
    Dim s As String
    s = CleanText(v)
    If s = STATUS_CANCEL Or s = "���" Then NormalizedMarriageDataStatus = STATUS_CANCEL Else NormalizedMarriageDataStatus = STATUS_ACTIVE
End Function

Private Sub AddMarriageReviewValidation(ByVal ws As Worksheet)
    On Error Resume Next
    ws.Range("I" & MR_FIRST_DATA_ROW & ":I500").Validation.Delete
    ws.Range("I" & MR_FIRST_DATA_ROW & ":I500").Validation.Add Type:=xlValidateList, AlertStyle:=xlValidAlertWarning, Operator:=xlBetween, Formula1:="����,����,���t�v�m�F"
    ws.Range("L" & MR_FIRST_DATA_ROW & ":L500").Validation.Delete
    ws.Range("L" & MR_FIRST_DATA_ROW & ":L500").Validation.Add Type:=xlValidateList, AlertStyle:=xlValidAlertWarning, Operator:=xlBetween, Formula1:=SHOW_YES & "," & SHOW_NO
    ws.Range("M" & MR_FIRST_DATA_ROW & ":M500").Validation.Delete
    ws.Range("M" & MR_FIRST_DATA_ROW & ":M500").Validation.Add Type:=xlValidateList, AlertStyle:=xlValidAlertWarning, Operator:=xlBetween, Formula1:=STATUS_ACTIVE & "," & STATUS_CANCEL
    ws.Range("A" & MR_FIRST_DATA_ROW & ":Q500").Locked = False
    ws.Range("B" & MR_FIRST_DATA_ROW & ":B500").Locked = True
    ws.Range("O" & MR_FIRST_DATA_ROW & ":Q500").Locked = True
    On Error GoTo 0
End Sub

Private Function ReviewSameDateOrBlank(ByVal v As Variant) As Variant
    If IsDate(v) Then
        ReviewSameDateOrBlank = CDate(v)
    Else
        ReviewSameDateOrBlank = ""
    End If
End Function

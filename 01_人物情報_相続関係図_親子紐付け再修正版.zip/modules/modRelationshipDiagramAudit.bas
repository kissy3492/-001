Attribute VB_Name = "modRelationshipDiagramAudit"
Option Explicit

'�����֌W�}�̕`��O�č��B
'�}�`�̌����ڂ����Œ��[���̂��B���Ȃ����߁A�e�q�����E�O�z��҂Ƃ̎q�E�Ǘ��q����C_�`�F�b�N�֏o���B

Public Sub AuditRelationshipDiagramBeforeBuild(ByVal decedentId As String)
    Dim wp As Worksheet, wr As Worksheet, wc As Worksheet
    Dim outR As Long, issueCount As Long
    Dim childParents As Object, relRowsByChild As Object
    Dim r As Long, parentId As String, childId As String, reasonText As String
    Dim currentSpouseId As String

    On Error GoTo SafeExit
    If Len(decedentId) = 0 Then Exit Sub
    If Not SheetExists(SH_W_PERSON, ThisWorkbook) Then Exit Sub
    If Not SheetExists(SH_W_REL, ThisWorkbook) Then Exit Sub
    If Not SheetExists(SH_CHECK, ThisWorkbook) Then Exit Sub

    Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)
    Set wr = ThisWorkbook.Worksheets(SH_W_REL)
    Set wc = ThisWorkbook.Worksheets(SH_CHECK)

    On Error Resume Next
    wc.Unprotect Password:=TOOL_PASSWORD
    On Error GoTo SafeExit
    ClearPriorRelationshipDiagramAudit wc
    outR = LastRow(wc, 1) + 1
    If outR < 4 Then outR = 4

    Set childParents = CreateObject("Scripting.Dictionary")
    Set relRowsByChild = CreateObject("Scripting.Dictionary")
    currentSpouseId = DiagramAuditCurrentSpouseId(decedentId)

    For r = 2 To LastRow(wr, 1)
        If CStr(wr.Cells(r, R_STATUS).Value) <> STATUS_CANCEL And CStr(wr.Cells(r, R_TYPE).Value) = "�e�q" Then
            parentId = "": childId = "": reasonText = ""
            If DiagramAuditResolveParentChild(wr, r, parentId, childId, reasonText) Then
                DiagramAuditAddParent childParents, childId, parentId
                DiagramAuditAddParent relRowsByChild, childId, CStr(r)
                If parentId = childId Then
                    DiagramAuditAddCheck wc, outR, "�G���[", "�e�q�֌W�œ���l�����e�q�o���ɓ����Ă��܂��B", childId, DiagramAuditPersonName(childId), "�����֌W�}�č�", "W_�֌W�̐e�q�s���C��", issueCount
                End If
            Else
                If Len(reasonText) > 0 Then
                    DiagramAuditAddCheck wc, outR, "�x��", "�e�q�֌W�̐e�q�������m��ł��܂���B " & reasonText, _
                        CStr(wr.Cells(r, R_BASE_ID).Value), CStr(wr.Cells(r, R_OTHER_ID).Value), "�����֌W�}�č�", "�����Ɛe�q�֌W���m�F", issueCount
                Else
                    DiagramAuditAddCheck wc, outR, "�x��", "�e�q�֌W�̐e�q�������m��ł��܂���B", _
                        CStr(wr.Cells(r, R_BASE_ID).Value), CStr(wr.Cells(r, R_OTHER_ID).Value), "�����֌W�}�č�", "�����Ɛe�q�֌W���m�F", issueCount
                End If
            End If
        End If
    Next r

    '�`�摤�� W_�֌W �����łȂ��A�o�^���̊�l��ID(P_SUR_SRC)�Ɣz��Ҋ֌W���g���Đe�q�𕜌�����B
    '�č������������W�b�N�̂܂܂��Ɓu���ȉ��̐e�q�֌W�Ȃ��v�ƌ�x�����邽�߁A���������������ɂ����f����B
    AuditDiagramAddStoredBaseParents wp, childParents, relRowsByChild

    AuditDiagramVisibleDescendants wp, wc, outR, issueCount, decedentId, currentSpouseId, childParents, relRowsByChild

    If issueCount = 0 Then
        DiagramAuditAddPlain wc, outR, "OK", "�����֌W�}�̐e�q�����E�O�z��ҍ����E�Ǘ��q���̎��O�č��ŏd��x���͂���܂���B", "�����֌W�}�č�", "�}�`�z�u��̌��؂�E���d�Ȃ�͕ʓr�x�����m�F"
    End If

    wc.Columns("A:G").AutoFit
    On Error Resume Next
    wc.Protect Password:=TOOL_PASSWORD, UserInterfaceOnly:=True
SafeExit:
End Sub

Private Sub AuditDiagramVisibleDescendants(ByVal wp As Worksheet, ByVal wc As Worksheet, ByRef outR As Long, ByRef issueCount As Long, _
        ByVal decedentId As String, ByVal currentSpouseId As String, ByVal childParents As Object, ByVal relRowsByChild As Object)
    Dim r As Long, pid As String, relText As String, levelValue As Long, parentList As String
    Dim hasDecParent As Boolean, hasCurrentSpouseParent As Boolean, hasAnyParent As Boolean
    Dim oldSpouseNote As Boolean

    For r = 2 To LastRow(wp, 1)
        If CStr(wp.Cells(r, P_STATUS).Value) <> STATUS_CANCEL And CStr(wp.Cells(r, P_SHOW).Value) <> SHOW_NO Then
            pid = CStr(wp.Cells(r, P_ID).Value)
            If Len(pid) > 0 And pid <> decedentId Then
                relText = DiagramAuditRelationAndNoteForPersonRow(r)
                levelValue = DiagramAuditDescendantLevel(relText)
                If levelValue > 0 Then
                    parentList = DiagramAuditDictText(childParents, pid)
                    hasAnyParent = (Len(parentList) > 0)
                    hasDecParent = DiagramAuditListContains(parentList, decedentId)
                    hasCurrentSpouseParent = (Len(currentSpouseId) > 0 And DiagramAuditListContains(parentList, currentSpouseId))
                    oldSpouseNote = DiagramAuditLooksOldSpouseChild(relText)

                    If levelValue = 1 Then
                        If Not hasDecParent Then
                            DiagramAuditAddCheck wc, outR, "�x��", "�푊���l���猩���q�ł����A�푊���l��e�Ƃ���e�q�֌W���m�F�ł��܂���B", _
                                pid, CStr(wp.Cells(r, P_DISPLAY).Value), "�����֌W�}�č�", "�푊���l���q�̐e�q�֌W��o�^", issueCount
                        End If
                        If oldSpouseNote And hasCurrentSpouseParent Then
                            DiagramAuditAddCheck wc, outR, "�G���[", "�O�z��҂Ƃ̎q�̒��L������܂����A���ݔz��҂��e�Ƃ��ĕR�Â��Ă��܂��B���ݕv�w�����牺����}���̌����ɂȂ�܂��B", _
                                pid, CStr(wp.Cells(r, P_DISPLAY).Value), "�����֌W�}�č�", "�e�q�֌W�Ƒ������L���C��", issueCount
                        ElseIf Len(currentSpouseId) > 0 And hasDecParent And Not hasCurrentSpouseParent Then
                            DiagramAuditAddPlain wc, outR, "�m�F", "���ݔz��҂̐e�q�֌W���Ȃ��q�́A�v�w�����ł͂Ȃ��푊���l�J�[�h������������낵�܂��B", _
                                CStr(wp.Cells(r, P_DISPLAY).Value), "�O�z��҂Ƃ̎q�E�A��q���̒��L���m�F"
                        End If
                    ElseIf levelValue > 1 Then
                        If Not hasAnyParent Then
                            DiagramAuditAddCheck wc, outR, "�G���[", "���ȉ��̐l���ł����A���㐢��̐e�q�֌W���m�F�ł��܂���B�����Ǘ��\����ʐl�����̌����ɂȂ�܂��B", _
                                pid, CStr(wp.Cells(r, P_DISPLAY).Value), "�����֌W�}�č�", "�e�l������q�Ƃ��ēo�^������", issueCount
                        End If
                    End If

                    If DiagramAuditParentCount(parentList) > 2 Then
                        DiagramAuditAddCheck wc, outR, "�x��", "�e�Ƃ��ĕR�Â��l����3���ȏ゠��܂��B���e�E�{�e�E�L�ڌ�����ʂ��Ă��������B", _
                            pid, CStr(wp.Cells(r, P_DISPLAY).Value), "�����֌W�}�č�", "�e�q�֌W�𐮗����A�K�v�Ȃ�{�q���L������", issueCount
                    End If
                End If
            End If
        End If
    Next r
End Sub

Private Sub AuditDiagramAddStoredBaseParents(ByVal wp As Worksheet, ByVal childParents As Object, ByVal relRowsByChild As Object)
    Dim r As Long, pid As String, parentId As String
    If wp Is Nothing Then Exit Sub
    If childParents Is Nothing Then Exit Sub
    For r = 2 To LastRow(wp, 1)
        If CStr(wp.Cells(r, P_STATUS).Value) <> STATUS_CANCEL And CStr(wp.Cells(r, P_SHOW).Value) <> SHOW_NO Then
            pid = CleanText(wp.Cells(r, P_ID).Value)
            If Len(pid) > 0 Then
                parentId = DiagramAuditStoredOrSpouseBaseParentId(wp, r)
                If Len(parentId) > 0 Then
                    DiagramAuditAddParent childParents, pid, parentId
                    If Not relRowsByChild Is Nothing Then DiagramAuditAddParent relRowsByChild, pid, "P_SUR_SRC"
                End If
            End If
        End If
    Next r
End Sub

Private Function DiagramAuditStoredOrSpouseBaseParentId(ByVal wp As Worksheet, ByVal childRow As Long) As String
    Dim childId As String, storedId As String, normalizedId As String
    If wp Is Nothing Then Exit Function
    If childRow <= 0 Then Exit Function
    childId = CleanText(wp.Cells(childRow, P_ID).Value)
    storedId = CleanText(wp.Cells(childRow, P_SUR_SRC).Value)
    If Len(childId) = 0 Or Len(storedId) = 0 Or childId = storedId Then Exit Function
    normalizedId = DiagramAuditPrimaryParentIdForDrawing(storedId, childId, childRow)
    If DiagramAuditParentCandidateUsable(normalizedId, childId, childRow, True) Then
        DiagramAuditStoredOrSpouseBaseParentId = normalizedId
    ElseIf DiagramAuditParentCandidateUsable(storedId, childId, childRow, True) Then
        DiagramAuditStoredOrSpouseBaseParentId = storedId
    End If
End Function

Private Function DiagramAuditPrimaryParentIdForDrawing(ByVal candidateParentId As String, ByVal childId As String, ByVal childRow As Long) As String
    Dim relText As String, storedBloodId As String, partnerId As String
    Dim expectedLevel As Long, childLevel As Long
    candidateParentId = CleanText(candidateParentId)
    childId = CleanText(childId)
    If Len(candidateParentId) = 0 Or Len(childId) = 0 Then Exit Function
    DiagramAuditPrimaryParentIdForDrawing = candidateParentId
    relText = DiagramAuditRelationAndNoteForPersonId(candidateParentId)
    If InStr(1, relText, "�z���", vbTextCompare) = 0 Then Exit Function
    If DiagramAuditLooksSeparateParentChild(DiagramAuditRelationAndNoteForPersonRow(childRow)) Then Exit Function

    storedBloodId = DiagramAuditSpouseStoredBloodlineBaseId(candidateParentId)
    If Len(storedBloodId) > 0 Then
        DiagramAuditPrimaryParentIdForDrawing = storedBloodId
        Exit Function
    End If

    expectedLevel = DiagramAuditParentLevel(relText)
    If expectedLevel <= 0 Then
        childLevel = DiagramAuditDescendantLevel(DiagramAuditRelationAndNoteForPersonRow(childRow))
        If childLevel > 1 Then expectedLevel = childLevel - 1
    End If
    partnerId = DiagramAuditSpousePartnerAtLevel(candidateParentId, expectedLevel)
    If Len(partnerId) > 0 Then DiagramAuditPrimaryParentIdForDrawing = partnerId
End Function

Private Function DiagramAuditParentCandidateUsable(ByVal parentId As String, ByVal childId As String, ByVal childRow As Long, ByVal allowStaleChildLevel As Boolean) As Boolean
    Dim parentRel As String, childRel As String, parentLevel As Long, childLevel As Long
    parentId = CleanText(parentId)
    childId = CleanText(childId)
    If Len(parentId) = 0 Or Len(childId) = 0 Or parentId = childId Then Exit Function
    If FindPersonRow(parentId) <= 0 Then Exit Function
    parentRel = DiagramAuditRelationAndNoteForPersonId(parentId)
    childRel = DiagramAuditRelationAndNoteForPersonRow(childRow)
    parentLevel = DiagramAuditParentLevel(parentRel)
    childLevel = DiagramAuditDescendantLevel(childRel)
    If childLevel <= 0 Then Exit Function
    If parentLevel = 0 Then
        DiagramAuditParentCandidateUsable = (childLevel = 1)
    ElseIf childLevel = parentLevel + 1 Then
        DiagramAuditParentCandidateUsable = True
    ElseIf allowStaleChildLevel Then
        DiagramAuditParentCandidateUsable = (childLevel <= parentLevel)
    End If
End Function

Private Function DiagramAuditSpouseStoredBloodlineBaseId(ByVal spouseId As String) As String
    Dim spouseRow As Long, baseId As String
    spouseRow = FindPersonRow(CleanText(spouseId))
    If spouseRow <= 0 Then Exit Function
    If InStr(1, DiagramAuditRelationAndNoteForPersonRow(spouseRow), "�z���", vbTextCompare) = 0 Then Exit Function
    baseId = CleanText(ThisWorkbook.Worksheets(SH_W_PERSON).Cells(spouseRow, P_SUR_SRC).Value)
    If Len(baseId) = 0 Then Exit Function
    If DiagramAuditParentLevel(DiagramAuditRelationAndNoteForPersonId(baseId)) > 0 Then DiagramAuditSpouseStoredBloodlineBaseId = baseId
End Function

Private Function DiagramAuditSpousePartnerAtLevel(ByVal spouseId As String, ByVal expectedLevel As Long) As String
    Dim wr As Worksheet, r As Long, b As String, o As String, partnerId As String, partnerRel As String
    If Len(spouseId) = 0 Or expectedLevel < 0 Then Exit Function
    If Not SheetExists(SH_W_REL, ThisWorkbook) Then Exit Function
    Set wr = ThisWorkbook.Worksheets(SH_W_REL)
    For r = 2 To LastRow(wr, 1)
        If CStr(wr.Cells(r, R_STATUS).Value) <> STATUS_CANCEL And CStr(wr.Cells(r, R_TYPE).Value) = "�z���" Then
            b = CleanText(wr.Cells(r, R_BASE_ID).Value)
            o = CleanText(wr.Cells(r, R_OTHER_ID).Value)
            partnerId = ""
            If b = spouseId Then
                partnerId = o
            ElseIf o = spouseId Then
                partnerId = b
            End If
            If Len(partnerId) > 0 Then
                partnerRel = DiagramAuditRelationAndNoteForPersonId(partnerId)
                If InStr(1, partnerRel, "�z���", vbTextCompare) = 0 Then
                    If expectedLevel <= 0 Then
                        If DiagramAuditParentLevel(partnerRel) > 0 Then DiagramAuditSpousePartnerAtLevel = partnerId: Exit Function
                    ElseIf DiagramAuditParentLevel(partnerRel) = expectedLevel Then
                        DiagramAuditSpousePartnerAtLevel = partnerId
                        Exit Function
                    End If
                End If
            End If
        End If
    Next r
End Function

Private Function DiagramAuditRelationAndNoteForPersonId(ByVal personId As String) As String
    DiagramAuditRelationAndNoteForPersonId = DiagramAuditRelationAndNoteForPersonRow(FindPersonRow(CleanText(personId)))
End Function

Private Function DiagramAuditRelationAndNoteForPersonRow(ByVal personRow As Long) As String
    Dim wp As Worksheet
    If personRow <= 0 Then Exit Function
    Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)
    DiagramAuditRelationAndNoteForPersonRow = CleanText(wp.Cells(personRow, P_REL_DEC).Value) & " " & CleanText(wp.Cells(personRow, P_REL_DISP).Value) & " " & CleanText(wp.Cells(personRow, P_NOTE).Value)
End Function

Private Function DiagramAuditLooksSeparateParentChild(ByVal relAndNote As String) As Boolean
    relAndNote = CleanText(relAndNote)
    DiagramAuditLooksSeparateParentChild = (InStr(relAndNote, "�O�z���") > 0 _
        Or InStr(relAndNote, "�O��") > 0 _
        Or InStr(relAndNote, "�O�v") > 0 _
        Or InStr(relAndNote, "�ʕ�") > 0 _
        Or InStr(relAndNote, "�ʕ�") > 0 _
        Or InStr(relAndNote, "�A��q") > 0)
End Function

Private Function DiagramAuditResolveParentChild(ByVal wr As Worksheet, ByVal relRow As Long, ByRef parentId As String, ByRef childId As String, ByRef reasonText As String) As Boolean
    Dim baseId As String, otherId As String, baseRow As Long, otherRow As Long
    Dim baseLevel As Long, otherLevel As Long, baseRel As String, otherRel As String
    baseId = CStr(wr.Cells(relRow, R_BASE_ID).Value)
    otherId = CStr(wr.Cells(relRow, R_OTHER_ID).Value)
    If Len(baseId) = 0 Or Len(otherId) = 0 Then reasonText = "�l��ID����ł��B": Exit Function
    If baseId = otherId Then reasonText = "����l��ID�ł��B": Exit Function
    baseRow = FindPersonRow(baseId)
    otherRow = FindPersonRow(otherId)
    If baseRow = 0 Or otherRow = 0 Then reasonText = "�l���\�ɑ��݂��Ȃ��l��ID�ł��B": Exit Function
    baseRel = DiagramAuditRelationAndNoteForPersonId(baseId)
    otherRel = DiagramAuditRelationAndNoteForPersonId(otherId)
    baseLevel = DiagramAuditParentLevel(baseRel)
    otherLevel = DiagramAuditDescendantLevel(otherRel)
    If DiagramAuditIsExpected(baseRel, otherRel) Then
        parentId = baseId: childId = otherId: DiagramAuditResolveParentChild = True: Exit Function
    End If
    If DiagramAuditIsExpected(otherRel, baseRel) Then
        parentId = otherId: childId = baseId: DiagramAuditResolveParentChild = True: Exit Function
    End If

    '���f�[�^�ł́u���̔z��ҁv����ɓo�^�����q���A�����u�q�v�̂܂܎c�邱�Ƃ�����B
    '�e�q�s�̌����� R_BASE_ID=�e / R_OTHER_ID=�q �Ȃ�č�����L���Ȑe�q�s�Ƃ��Ĉ����A
    '�`�摤�Ō������̑��֐��K������B
    If baseLevel > 0 And otherLevel > 0 Then
        If otherLevel <= baseLevel Then
            parentId = baseId: childId = otherId: DiagramAuditResolveParentChild = True: Exit Function
        End If
    End If

    reasonText = "����=" & baseRel & " / " & otherRel
End Function

Private Function DiagramAuditCurrentSpouseId(ByVal decedentId As String) As String
    Dim wr As Worksheet, r As Long, b As String, o As String, otherId As String, relText As String
    If Len(decedentId) = 0 Or Not SheetExists(SH_W_REL, ThisWorkbook) Then Exit Function
    Set wr = ThisWorkbook.Worksheets(SH_W_REL)
    For r = 2 To LastRow(wr, 1)
        If CStr(wr.Cells(r, R_STATUS).Value) <> STATUS_CANCEL And CStr(wr.Cells(r, R_TYPE).Value) = "�z���" Then
            b = CStr(wr.Cells(r, R_BASE_ID).Value): o = CStr(wr.Cells(r, R_OTHER_ID).Value)
            otherId = ""
            If b = decedentId Then otherId = o
            If o = decedentId Then otherId = b
            If Len(otherId) > 0 Then
                relText = GetPersonValue(otherId, P_REL_DEC) & " " & CStr(wr.Cells(r, R_DISPLAY).Value) & " " & CStr(wr.Cells(r, R_NOTE).Value)
                If InStr(relText, "�O�z���") = 0 And InStr(relText, "�O��") = 0 And InStr(relText, "�O�v") = 0 Then
                    DiagramAuditCurrentSpouseId = otherId
                    Exit Function
                End If
            End If
        End If
    Next r
End Function

Private Function DiagramAuditIsExpected(ByVal parentRel As String, ByVal childRel As String) As Boolean
    Dim pLevel As Long, cLevel As Long
    pLevel = DiagramAuditParentLevel(parentRel)
    cLevel = DiagramAuditDescendantLevel(childRel)
    If pLevel = 0 Then
        DiagramAuditIsExpected = (cLevel = 1)
    ElseIf pLevel > 0 Then
        DiagramAuditIsExpected = (cLevel = pLevel + 1)
    End If
End Function

Private Function DiagramAuditParentLevel(ByVal relText As String) As Long
    Dim rawText As String
    rawText = CleanText(relText)
    If Len(rawText) = 0 Then Exit Function
    If InStr(rawText, "�푊���l") > 0 Then Exit Function
    If rawText = "�z���" Or rawText = "�O�z���" Then Exit Function

    '�u���̔z��ҁv�u�]���̔z��ҁv�́A�q�̒��㐢��Ƃ��Ă͌����{�l�Ɠ�������ŕ]������B
    '������0�����ɂ���ƁA���̔z��ҁ��q �̍s���č����s�������Ƃ��Č�x������B
    If InStr(rawText, "�z���") > 0 Then
        If InStr(rawText, "����") > 0 Then
            DiagramAuditParentLevel = 4
        ElseIf DiagramAuditContainsGreatGrandchild(rawText) Then
            DiagramAuditParentLevel = 3
        ElseIf InStr(rawText, "��") > 0 Then
            DiagramAuditParentLevel = 2
        ElseIf DiagramAuditDirectChild(rawText) Then
            DiagramAuditParentLevel = 1
        End If
        Exit Function
    End If

    DiagramAuditParentLevel = DiagramAuditDescendantLevel(rawText)
End Function

Private Function DiagramAuditDescendantLevel(ByVal relText As String) As Long
    relText = DiagramAuditBaseRelation(CleanText(relText))
    If DiagramAuditContainsGreatGrandchild(relText) And InStr(relText, "�z���") > 0 And InStr(relText, "�q") > 0 Then
        DiagramAuditDescendantLevel = 4
    ElseIf InStr(relText, "��") > 0 And Not DiagramAuditContainsGreatGrandchild(relText) And InStr(relText, "�z���") > 0 And InStr(relText, "�q") > 0 Then
        DiagramAuditDescendantLevel = 3
    ElseIf InStr(relText, "�z���") > 0 Then
        Exit Function
    ElseIf DiagramAuditDirectChild(relText) Then
        DiagramAuditDescendantLevel = 1
    ElseIf Left$(relText, 2) = "��" Then
        DiagramAuditDescendantLevel = 2
    ElseIf DiagramAuditIsGreatGrandchild(relText) Then
        DiagramAuditDescendantLevel = 3
    ElseIf Left$(relText, 2) = "����" Then
        DiagramAuditDescendantLevel = 4
    End If
End Function


Private Function DiagramAuditContainsGreatGrandchild(ByVal relText As String) As Boolean
    relText = DiagramAuditBaseRelation(CleanText(relText))
    If InStr(relText, "�]��") > 0 Then
        DiagramAuditContainsGreatGrandchild = True
    ElseIf InStr(relText, "�\��") > 0 Then
        DiagramAuditContainsGreatGrandchild = True
    ElseIf InStr(relText, "�Б�") > 0 Then
        DiagramAuditContainsGreatGrandchild = True
    End If
End Function

Private Function DiagramAuditIsGreatGrandchild(ByVal relText As String) As Boolean
    relText = DiagramAuditBaseRelation(CleanText(relText))
    If relText = "�]��" Or Left$(relText, 2) = "�]��" Then
        DiagramAuditIsGreatGrandchild = True
    ElseIf relText = "�\��" Or Left$(relText, 2) = "�\��" Then
        DiagramAuditIsGreatGrandchild = True
    ElseIf relText = "�Б�" Or Left$(relText, 3) = "�Б�" Then
        DiagramAuditIsGreatGrandchild = True
    End If
End Function

Private Function DiagramAuditBaseRelation(ByVal relText As String) As String
    Dim p As Long, q As Long
    p = InStr(1, relText, "�i", vbTextCompare)
    If p > 1 Then q = InStr(p + 1, relText, "�j", vbTextCompare)
    If p = 0 Then
        p = InStr(1, relText, "(", vbTextCompare)
        If p > 1 Then q = InStr(p + 1, relText, ")", vbTextCompare)
    End If
    If p > 1 And q = Len(relText) Then relText = Left$(relText, p - 1)
    DiagramAuditBaseRelation = relText
End Function

Private Function DiagramAuditDirectChild(ByVal relText As String) As Boolean
    Select Case relText
        Case "�q", "�{�q"
            DiagramAuditDirectChild = True
            Exit Function
    End Select
    Select Case True
        Case InStr(relText, "���j") > 0, InStr(relText, "��j") > 0, InStr(relText, "�O�j") > 0, _
             InStr(relText, "�l�j") > 0, InStr(relText, "�ܒj") > 0, InStr(relText, "�Z�j") > 0, _
             InStr(relText, "����") > 0, InStr(relText, "��") > 0, InStr(relText, "�O��") > 0, _
             InStr(relText, "�l��") > 0, InStr(relText, "�܏�") > 0, InStr(relText, "�Z��") > 0
            DiagramAuditDirectChild = True
            Exit Function
    End Select
    If InStr(relText, "�q") > 0 Then
        If InStr(relText, "��") = 0 Then
            If InStr(relText, "�z���") = 0 Then DiagramAuditDirectChild = True
        End If
    End If
End Function

Private Function DiagramAuditLooksOldSpouseChild(ByVal relText As String) As Boolean
    relText = CleanText(relText)
    DiagramAuditLooksOldSpouseChild = (InStr(relText, "�O�z���") > 0 Or InStr(relText, "�O��") > 0 Or InStr(relText, "�O�v") > 0)
End Function

Private Sub DiagramAuditAddParent(ByVal dict As Object, ByVal childId As String, ByVal parentId As String)
    If Len(childId) = 0 Or Len(parentId) = 0 Then Exit Sub
    If dict.Exists(childId) Then
        If Not DiagramAuditListContains(CStr(dict(childId)), parentId) Then dict(childId) = CStr(dict(childId)) & "," & parentId
    Else
        dict.Add childId, parentId
    End If
End Sub

Private Function DiagramAuditDictText(ByVal dict As Object, ByVal keyText As String) As String
    If dict Is Nothing Then Exit Function
    If dict.Exists(keyText) Then DiagramAuditDictText = CStr(dict(keyText))
End Function

Private Function DiagramAuditListContains(ByVal listText As String, ByVal valueText As String) As Boolean
    Dim arr As Variant, i As Long
    If Len(valueText) = 0 Or Len(listText) = 0 Then Exit Function
    arr = Split(listText, ",")
    For i = LBound(arr) To UBound(arr)
        If Trim$(CStr(arr(i))) = valueText Then DiagramAuditListContains = True: Exit Function
    Next i
End Function

Private Function DiagramAuditParentCount(ByVal listText As String) As Long
    If Len(listText) = 0 Then Exit Function
    DiagramAuditParentCount = UBound(Split(listText, ",")) + 1
End Function

Private Function DiagramAuditPersonName(ByVal personId As String) As String
    If Len(personId) > 0 Then DiagramAuditPersonName = GetPersonValue(personId, P_DISPLAY)
End Function

Private Sub ClearPriorRelationshipDiagramAudit(ByVal ws As Worksheet)
    Dim r As Long
    For r = LastRow(ws, 1) To 2 Step -1
        If CStr(ws.Cells(r, 5).Value) = "�����֌W�}�č�" Then ws.Rows(r).Delete
    Next r
End Sub

Private Sub DiagramAuditAddCheck(ByVal ws As Worksheet, ByRef outR As Long, ByVal levelText As String, ByVal msgText As String, _
        ByVal pid As String, ByVal nameText As String, ByVal targetText As String, ByVal actionText As String, ByRef issueCount As Long)
    ws.Cells(outR, 1).Value = levelText
    ws.Cells(outR, 2).Value = msgText
    ws.Cells(outR, 3).Value = pid
    ws.Cells(outR, 4).Value = nameText
    ws.Cells(outR, 5).Value = targetText
    ws.Cells(outR, 6).Value = actionText
    ws.Cells(outR, 7).Value = Now
    If levelText = "�G���[" Or levelText = "�x��" Then issueCount = issueCount + 1
    outR = outR + 1
End Sub

Private Sub DiagramAuditAddPlain(ByVal ws As Worksheet, ByRef outR As Long, ByVal levelText As String, ByVal msgText As String, ByVal targetText As String, ByVal actionText As String)
    ws.Cells(outR, 1).Value = levelText
    ws.Cells(outR, 2).Value = msgText
    ws.Cells(outR, 5).Value = targetText
    ws.Cells(outR, 6).Value = actionText
    ws.Cells(outR, 7).Value = Now
    outR = outR + 1
End Sub

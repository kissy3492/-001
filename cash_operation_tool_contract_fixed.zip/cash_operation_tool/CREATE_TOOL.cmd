@echo off
setlocal DisableDelayedExpansion
if not exist "%~dp0support\CREATE_TOOL.vbs" goto missing
"%SystemRoot%\System32\cscript.exe" //nologo //E:VBScript "%~dp0support\CREATE_TOOL.vbs" %*
set "CASH_TOOL_EXIT=%ERRORLEVEL%"
if "%CASH_TOOL_EXIT%"=="0" exit /b 0
echo.
echo Creation did not finish. See the message above or create_error.txt.
echo If Windows Script Host is disabled, check with your administrator.
pause
exit /b %CASH_TOOL_EXIT%
:missing
echo Required files are missing. Extract the entire ZIP and try again.
pause
exit /b 1

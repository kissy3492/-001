﻿Attribute VB_Name = "modAdvancedFlowAnalysis"
Option Explicit

'複数取引の組合せは無制限にすると指数的に増えるため、実務上の探索範囲を明示して制御する。
'Top-K内では金額差の小さい候補を優先するが、探索上限または縮約へ到達した実行は
'部分結果を公開しない。旧分析を残して帳票を要更新のまま停止し、条件を絞った再実行を求める。
Private Const FLOW_BUFFER_ROWS As Long = 1000
Private Const FLOW_MAX_SIDE_TRANSACTIONS As Long = 3
Private Const FLOW_MAX_AGGREGATE_TRANSACTIONS As Long = 3
Private Const FLOW_TARGET_TOP_K_PAIRS As Long = 24
Private Const FLOW_LINK_TOP_K_PER_WITHDRAWAL As Long = 24
Private Const FLOW_MAX_MULTI_BUNDLES_64 As Long = 100000
Private Const FLOW_MAX_BUNDLES_64 As Long = 300000
Private Const FLOW_MAX_LINKS_64 As Long = 200000
Private Const FLOW_MAX_RECORDS_64 As Long = 200000
'32bit版Excelでは元取引配列も同時に保持するため、理論上限より先に
'メモリ不足となる。原本を書き換える前に現実的な件数で停止する。
Private Const FLOW_MAX_MULTI_BUNDLES_32 As Long = 30000
Private Const FLOW_MAX_BUNDLES_32 As Long = 100000
Private Const FLOW_MAX_LINKS_32 As Long = 75000
Private Const FLOW_MAX_RECORDS_32 As Long = 75000
Private Const FLOW_MAX_CHAIN_LEGS As Long = 6
Private Const FLOW_MAX_COMBINATION_OPERATIONS As Long = 5000000
Private Const FLOW_MAX_MATCH_OPERATIONS As Long = 5000000
Private Const FLOW_MAX_ADJACENCY_OPERATIONS As Long = 5000000
Private Const FLOW_MAX_TERMINAL_OPERATIONS As Long = 3000000
Private Const FLOW_MAX_ORIGIN_OPERATIONS As Long = 3000000
Private Const FLOW_MAX_LONG_UNKNOWN_OPERATIONS As Long = 5000000
Private Const FLOW_DETAIL_MAX_CHARS As Long = 30000
Private Const FLOW_MULTI_PERSON_KEY As String = "#MULTI#"
Private Const FLOW_CAPACITY_BASE_COLUMNS As Long = 16
Private Const FLOW_CAPACITY_LONG_MAX As Double = 2147483647#

'一回の分析実行にだけ有効な縮約状態。公開APIへ状態引数を追加せず、既存の呼出し互換性を保つ。
Private mFlowSearchReduced As Boolean
Private mFlowTopKReductionUsed As Boolean
Private mFlowResourceLimitReached As Boolean
Private mFlowKnownOmittedCount As Long
Private mFlowDisplayTruncated As Boolean
Private mFlowDisplayOmittedCount As Long
Private mFlowCurrentSideGenerationStopped As Boolean
Private mFlowLinkGenerationStopped As Boolean
Private mFlowRecordLimitReached As Boolean
Private mFlowChainSearchStopped As Boolean
Private mFlowOriginSearchStopped As Boolean

'一回の生成中に確保済み・確認済みの高水位を追跡する。出力行だけでなく、
'同時に保持する束・リンク・レコードも資金フロー行相当へ保守的に換算する。
Private mFlowCapacityActive As Boolean
Private mFlowCapacityPlannedShiftRows As Long
Private mFlowCapacityPlannedUnknownRows As Long
Private mFlowCapacityPlannedManualRows As Long
Private mFlowCapacityScratchRows As Long
Private mFlowWithdrawalBundleCapacity As Long
Private mFlowDepositBundleCapacity As Long
Private mFlowLinkCapacity As Long
Private mFlowRecordCapacity As Long
Private mFlowCheckedPlanRows As Long
Private mFlowConfirmedWorkloadRows As Double
Private mFlowAllowCapacityPrompt As Boolean
Private mFlowAdditionalSnapshotCellWork As Double

Private Type FlowBundle
    RowList As String
    IdList As String
    AccountList As String
    PersonKey As String
    TotalAmount As Double
    ItemCount As Long
    MinDate As Long
    MaxDate As Long
    MinStamp As Double
    MaxStamp As Double
    HasAnyTime As Boolean
    HasAllTimes As Boolean
End Type

Private Type FlowLink
    WithdrawalBundle As Long
    DepositBundle As Long
    DifferenceAmount As Double
    Score As Long
    Rating As String
    Chronology As String
    TimePrecision As String
    PeriodText As String
    KeyText As String
    IsLongTermUnknown As Boolean
End Type

Private Type FlowRecord
    KindCode As Long       '1=複数照合、2=連鎖、3=終端出金、4=上限、5～7=入金起点の各連鎖
    LinkList As String
    ExtraWithdrawalRows As String
    OriginDepositBundle As Long
    Score As Long
    Rating As String
    KeyText As String
End Type

Private Function FlowMaxMultiBundlesPerSide() As Long
#If Win64 Or Mac Then
    FlowMaxMultiBundlesPerSide = FLOW_MAX_MULTI_BUNDLES_64
#Else
    FlowMaxMultiBundlesPerSide = FLOW_MAX_MULTI_BUNDLES_32
#End If
End Function

Private Function FlowMaxBundlesPerSide() As Long
#If Win64 Or Mac Then
    FlowMaxBundlesPerSide = FLOW_MAX_BUNDLES_64
#Else
    FlowMaxBundlesPerSide = FLOW_MAX_BUNDLES_32
#End If
End Function

Private Function FlowMaxLinks() As Long
#If Win64 Or Mac Then
    FlowMaxLinks = FLOW_MAX_LINKS_64
#Else
    FlowMaxLinks = FLOW_MAX_LINKS_32
#End If
End Function

Private Function FlowMaxRecords() As Long
#If Win64 Or Mac Then
    FlowMaxRecords = FLOW_MAX_RECORDS_64
#Else
    FlowMaxRecords = FLOW_MAX_RECORDS_32
#End If
End Function

Private Sub ResetFlowCapacityState()
    mFlowCapacityActive = False
    mFlowCapacityPlannedShiftRows = 0
    mFlowCapacityPlannedUnknownRows = 0
    mFlowCapacityPlannedManualRows = 0
    mFlowCapacityScratchRows = 0
    mFlowWithdrawalBundleCapacity = 0
    mFlowDepositBundleCapacity = 0
    mFlowLinkCapacity = 0
    mFlowRecordCapacity = 0
    mFlowCheckedPlanRows = 0
    mFlowConfirmedWorkloadRows = 0#
    mFlowAllowCapacityPrompt = True
    mFlowAdditionalSnapshotCellWork = 0#
End Sub

Private Function AdvancedFlowCapacityDataRows(ByVal sheetName As String, _
                                               ByVal lastColumn As Long) As Long
    Dim lastR As Long
    If lastColumn < 1 Then _
        Err.Raise vbObjectError + 4722, "AdvancedFlowCapacityDataRows", _
                  "資金フロー容量の検査列が不正です: " & sheetName
    If Not SheetExists(sheetName) Then _
        Err.Raise vbObjectError + 4723, "AdvancedFlowCapacityDataRows", _
                  "資金フロー容量を検査するシートがありません: " & sheetName
    lastR = LastDataRowInColumns(GetSheet(sheetName), 1, lastColumn)
    If lastR >= 2 Then AdvancedFlowCapacityDataRows = lastR - 1
End Function

Private Function FlowCapacityRowsFromSlots(ByVal slotCount As Double) As Long
    Dim rowCount As Double
    If slotCount < 0# Then _
        Err.Raise vbObjectError + 4724, "FlowCapacityRowsFromSlots", _
                  "資金フローの内部容量上界をLong範囲で表現できません。"
    rowCount = Int(slotCount / CDbl(FLOW_CAPACITY_BASE_COLUMNS))
    If slotCount > rowCount * CDbl(FLOW_CAPACITY_BASE_COLUMNS) Then rowCount = rowCount + 1#
    If rowCount > FLOW_CAPACITY_LONG_MAX Then _
        Err.Raise vbObjectError + 4724, "FlowCapacityRowsFromSlots", _
                  "資金フローの内部容量上界をLong範囲で表現できません。"
    FlowCapacityRowsFromSlots = CLng(rowCount)
End Function

Private Function FlowCapacityCombinedRows( _
        ByVal scratchRows As Long, ByVal withdrawalBundleRows As Long, _
        ByVal depositBundleRows As Long, ByVal linkRows As Long, _
        ByVal recordRows As Long, ByVal manualRows As Long) As Long
    Dim totalRows As Double
    If scratchRows < 0 Or withdrawalBundleRows < 0 Or depositBundleRows < 0 Or _
       linkRows < 0 Or recordRows < 0 Or manualRows < 0 Then _
        Err.Raise vbObjectError + 4725, "FlowCapacityCombinedRows", _
                  "資金フローの内部容量に負数があります。"
    totalRows = CDbl(scratchRows) + CDbl(withdrawalBundleRows) + _
                CDbl(depositBundleRows) + CDbl(linkRows) + _
                CDbl(recordRows) + CDbl(manualRows)
    If totalRows > FLOW_CAPACITY_LONG_MAX Then _
        Err.Raise vbObjectError + 4725, "FlowCapacityCombinedRows", _
                  "資金フローの内部容量合算をLong範囲で表現できません。"
    FlowCapacityCombinedRows = CLng(totalRows)
End Function

Private Function ConservativeFlowBundleUpper( _
        ByVal sourceCount As Long, ByVal componentCount As Long, _
        ByVal targetCount As Long) As Long
    Dim multiUpper As Double, totalUpper As Double
    If sourceCount < 0 Or componentCount < 0 Or targetCount < 0 Then _
        Err.Raise vbObjectError + 4726, "ConservativeFlowBundleUpper", _
                  "資金フローの入力件数に負数があります。"
    '全口座・全人物を横断し、0～3日の窓内で2件・3件集合を完全列挙する。
    '日付分布が不明な事前上界では、全件が同日である最悪ケースを採る。
    If componentCount >= 2 Then
        multiUpper = CDbl(componentCount) * CDbl(componentCount - 1) / 2#
        If componentCount >= 3 Then _
            multiUpper = multiUpper + CDbl(componentCount) * _
                CDbl(componentCount - 1) * CDbl(componentCount - 2) / 6#
    End If
    If multiUpper > CDbl(FlowMaxMultiBundlesPerSide()) Then _
        multiUpper = CDbl(FlowMaxMultiBundlesPerSide())
    totalUpper = CDbl(sourceCount) + multiUpper
    If totalUpper > CDbl(FlowMaxBundlesPerSide()) Then _
        totalUpper = CDbl(FlowMaxBundlesPerSide())
    ConservativeFlowBundleUpper = CLng(totalUpper)
End Function

Private Function ConservativeFlowLinkUpper( _
        ByVal withdrawalBundleUpper As Long, ByVal depositBundleUpper As Long) As Long
    Dim totalUpper As Double
    If withdrawalBundleUpper < 0 Or depositBundleUpper < 0 Then _
        Err.Raise vbObjectError + 4727, "ConservativeFlowLinkUpper", _
                  "資金フローの取引束上界に負数があります。"
    If withdrawalBundleUpper = 0 Or depositBundleUpper = 0 Then Exit Function
    'Top-Kは表示行の選択だけに使う。探索・連鎖用リンクの容量は全直積で見積もる。
    totalUpper = CDbl(withdrawalBundleUpper) * CDbl(depositBundleUpper)
    If totalUpper > CDbl(FlowMaxLinks()) Then totalUpper = CDbl(FlowMaxLinks())
    ConservativeFlowLinkUpper = CLng(totalUpper)
End Function

Private Function ConservativeFlowAllocatedCapacity( _
        ByVal logicalUpper As Long, ByVal maximumCapacity As Long) As Long
    Dim capacityRows As Long
    If logicalUpper < 0 Or maximumCapacity < 1 Or logicalUpper > maximumCapacity Then _
        Err.Raise vbObjectError + 4729, "ConservativeFlowAllocatedCapacity", _
                  "資金フローの配列確保上界が不正です。"
    If logicalUpper = 0 Then Exit Function
    capacityRows = 1024
    If capacityRows > maximumCapacity Then capacityRows = maximumCapacity
    Do While capacityRows < logicalUpper
        If capacityRows > maximumCapacity \ 2 Then
            capacityRows = maximumCapacity
        Else
            capacityRows = capacityRows * 2
        End If
    Loop
    ConservativeFlowAllocatedCapacity = capacityRows
End Function

Private Function ConservativeFlowScratchRows( _
        ByVal withdrawalCount As Long, ByVal depositCount As Long, _
        ByVal componentWithdrawalCount As Long, ByVal componentDepositCount As Long, _
        ByVal withdrawalBundleUpper As Long, ByVal depositBundleUpper As Long, _
        ByVal linkUpper As Long) As Long
    Dim withdrawalSlots As Double, depositSlots As Double, linkSlots As Double
    Dim contextSlots As Double, targetSlots As Double, maximumSlots As Double
    If withdrawalCount < 0 Or depositCount < 0 Or componentWithdrawalCount < 0 Or _
       componentDepositCount < 0 Or withdrawalBundleUpper < 0 Or _
       depositBundleUpper < 0 Or linkUpper < 0 Then _
        Err.Raise vbObjectError + 4726, "ConservativeFlowScratchRows", _
                  "資金フローの入力件数に負数があります。"
    If withdrawalCount >= 2 Then contextSlots = 3# * CDbl(withdrawalCount)
    If componentWithdrawalCount >= 2 And depositCount > 0 Then _
        targetSlots = 2# * CDbl(componentWithdrawalCount) + 2# * CDbl(depositCount) + _
                      3# * CDbl(FLOW_TARGET_TOP_K_PAIRS)
    withdrawalSlots = contextSlots
    If targetSlots > withdrawalSlots Then withdrawalSlots = targetSlots

    contextSlots = 0#: targetSlots = 0#
    If depositCount >= 2 Then contextSlots = 3# * CDbl(depositCount)
    If componentDepositCount >= 2 And withdrawalCount > 0 Then _
        targetSlots = 2# * CDbl(componentDepositCount) + 2# * CDbl(withdrawalCount) + _
                      3# * CDbl(FLOW_TARGET_TOP_K_PAIRS)
    depositSlots = contextSlots
    If targetSlots > depositSlots Then depositSlots = targetSlots

    If withdrawalBundleUpper > 0 And depositBundleUpper > 0 Then _
        linkSlots = 2# * CDbl(depositBundleUpper) + _
                    3# * CDbl(FLOW_LINK_TOP_K_PER_WITHDRAWAL)
    If CDbl(linkUpper) > linkSlots Then linkSlots = CDbl(linkUpper)
    maximumSlots = withdrawalSlots
    If depositSlots > maximumSlots Then maximumSlots = depositSlots
    If linkSlots > maximumSlots Then maximumSlots = linkSlots
    ConservativeFlowScratchRows = FlowCapacityRowsFromSlots(maximumSlots)
End Function

Private Sub InitializeFlowCapacityState( _
        ByVal plannedShiftRows As Long, ByVal plannedUnknownRows As Long, _
        ByVal plannedManualFlowRows As Long, ByVal confirmedWorkloadRows As Double, _
        ByVal allowCapacityPrompt As Boolean, _
        ByVal additionalSnapshotCellWork As Double)
    ResetFlowCapacityState
    If plannedShiftRows < -1 Or plannedUnknownRows < -1 Or plannedManualFlowRows < -1 Then _
        Err.Raise vbObjectError + 4728, "InitializeFlowCapacityState", _
                  "資金フローの予定行数が不正です。"
    If plannedShiftRows >= 0 Then
        mFlowCapacityPlannedShiftRows = plannedShiftRows
    Else
        mFlowCapacityPlannedShiftRows = _
            AdvancedFlowCapacityDataRows(SH_ANALYSIS_SHIFT, SHIFT_ANALYSIS_LAST_COL)
    End If
    If plannedUnknownRows >= 0 Then
        mFlowCapacityPlannedUnknownRows = plannedUnknownRows
    Else
        mFlowCapacityPlannedUnknownRows = _
            AdvancedFlowCapacityDataRows(SH_ANALYSIS_UNKNOWN, UNKNOWN_ANALYSIS_LAST_COL)
    End If
    If plannedManualFlowRows >= 0 Then
        mFlowCapacityPlannedManualRows = plannedManualFlowRows
    Else
        mFlowCapacityPlannedManualRows = _
            AdvancedFlowCapacityDataRows(SH_WORK_MANUAL_FLOW, MANUAL_FLOW_STORE_LAST_COL)
    End If
    mFlowConfirmedWorkloadRows = confirmedWorkloadRows
    mFlowAllowCapacityPrompt = allowCapacityPrompt
    If additionalSnapshotCellWork < 0# Then _
        Err.Raise vbObjectError + 4728, "InitializeFlowCapacityState", _
                  "分析更新ロールバック用の退避容量が不正です。"
    mFlowAdditionalSnapshotCellWork = additionalSnapshotCellWork
    mFlowCapacityActive = True
End Sub

Private Sub ResetFlowSearchReductionState()
    mFlowSearchReduced = False
    mFlowTopKReductionUsed = False
    mFlowResourceLimitReached = False
    mFlowKnownOmittedCount = 0
    mFlowDisplayTruncated = False
    mFlowDisplayOmittedCount = 0
    mFlowCurrentSideGenerationStopped = False
    mFlowLinkGenerationStopped = False
    mFlowRecordLimitReached = False
    mFlowChainSearchStopped = False
    mFlowOriginSearchStopped = False
End Sub

Private Sub MarkFlowDisplayTruncated(ByVal omittedCount As Long)
    If omittedCount <= 0 Then Exit Sub
    mFlowDisplayTruncated = True
    If mFlowDisplayOmittedCount > 2000000000 - omittedCount Then
        mFlowDisplayOmittedCount = 2000000000
    Else
        mFlowDisplayOmittedCount = mFlowDisplayOmittedCount + omittedCount
    End If
End Sub

Public Function AdvancedFlowCoverageStatus() As String
    If mFlowSearchReduced Then
        AdvancedFlowCoverageStatus = "ABORTED"
    Else
        AdvancedFlowCoverageStatus = "COMPLETE"
    End If
End Function

Public Function AdvancedFlowDisplayOmittedCount() As Long
    AdvancedFlowDisplayOmittedCount = mFlowDisplayOmittedCount
End Function

Private Function FlowDisplayTruncationNotice() As String
    If Not mFlowDisplayTruncated Then Exit Function
    FlowDisplayTruncationNotice = "探索範囲は完了しました。表示は金額差順の上位候補に限定し、" & _
        Format$(mFlowDisplayOmittedCount, "#,##0") & _
        "件は代替候補件数として保持しています（未探索ではありません）。"
End Function

Private Sub MarkFlowSearchReduced(Optional ByVal knownOmittedCount As Long = 0, _
                                  Optional ByVal usedTopK As Boolean = False, _
                                  Optional ByVal reachedResourceLimit As Boolean = False)
    mFlowSearchReduced = True
    If usedTopK Then mFlowTopKReductionUsed = True
    If reachedResourceLimit Then mFlowResourceLimitReached = True
    If knownOmittedCount > 0 Then
        'Longの上限近傍では件数の加算より、縮約済みである事実を優先して飽和させる。
        If mFlowKnownOmittedCount > 2000000000 - knownOmittedCount Then
            mFlowKnownOmittedCount = 2000000000
        Else
            mFlowKnownOmittedCount = mFlowKnownOmittedCount + knownOmittedCount
        End If
    End If
End Sub

Private Function FlowSearchReductionNotice() As String
    If Not mFlowSearchReduced Then Exit Function
    If mFlowTopKReductionUsed Then
        FlowSearchReductionNotice = _
            "処理時間とメモリを守るため、金額差の小さい候補を優先して探索量を縮約しました。"
    Else
        FlowSearchReductionNotice = _
            "処理時間とメモリを守るため、探索量を安全な範囲へ縮約しました。"
    End If
    If mFlowKnownOmittedCount > 0 Then
        FlowSearchReductionNotice = FlowSearchReductionNotice & " 少なくとも" & _
            Format$(mFlowKnownOmittedCount, "#,##0") & "件の順位外組合せ候補を省略しています。"
    End If
    If mFlowResourceLimitReached Then
        FlowSearchReductionNotice = FlowSearchReductionNotice & _
            " 安全上限に達したため、途中までの候補は採用しません。"
    End If
    FlowSearchReductionNotice = FlowSearchReductionNotice & _
        " 部分結果は資金操作表へ反映していません。条件を絞って再実行してください。"
End Function

Private Function FlowSearchMayPublishResults() As Boolean
    '候補が0件でも、探索を完了できなかった0件と完全探索による0件を混同しない。
    FlowSearchMayPublishResults = Not mFlowSearchReduced
End Function

Private Function FlowSearchMustKeepOutputsDirty() As Boolean
    FlowSearchMustKeepOutputsDirty = mFlowSearchReduced
End Function

Private Sub RequireCompleteFlowSearchBeforeOutput()
    If FlowSearchMayPublishResults() Then Exit Sub
    '公開済みの旧分析には触れず、呼出元が正常完了としてcleanへ戻せない状態を先に固定する。
    If FlowSearchMustKeepOutputsDirty() Then MarkOutputsDirty
    Err.Raise vbObjectError + 4720, "RequireCompleteFlowSearchBeforeOutput", _
              "資金フロー候補の探索が安全上限または縮約条件へ達しました。" & _
              "途中までの候補は反映していません。最低金額を上げるなど条件を絞って再実行してください。"
End Sub

Private Sub RequireAdvancedFlowCapacity( _
        ByVal operationName As String, ByVal plannedShiftRows As Long, _
        ByVal plannedFlowRows As Long, ByVal plannedUnknownRows As Long, _
        ByRef confirmedWorkloadRows As Double, _
        Optional ByVal plannedResultRows As Long = -1, _
        Optional ByVal plannedGroupRows As Long = -1)
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim eventStateDetail As String
    On Error GoTo CapacityFailed
    If ConfirmAnalysisReviewOperationCapacity( _
            operationName, confirmedWorkloadRows, plannedShiftRows, _
            plannedFlowRows, plannedUnknownRows, plannedResultRows, _
            plannedGroupRows, mFlowAllowCapacityPrompt, _
            additionalSnapshotCellWork:=mFlowAdditionalSnapshotCellWork) Then Exit Sub
    Err.Raise 18, "RequireAdvancedFlowCapacity", _
              operationName & "は取り消されました。既存の分析結果は変更していません。"

CapacityFailed:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    If IsAdvancedFlowNestedRecoveryFatal(errorNumber, errorSource) Then
        Call TryKeepAdvancedFlowEventsDisabledExact(eventStateDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    '取消、32-bit上限、容量計算エラーのいずれでも旧結果をclean扱いにしない。
    MarkOutputsDirty
    Err.Raise errorNumber, "RequireAdvancedFlowCapacity", _
              errorSource & " / " & errorDescription
End Sub

Private Sub RequireAdvancedFlowPreSearchCapacity( _
        ByVal withdrawalCount As Long, ByVal depositCount As Long, _
        ByVal componentWithdrawalCount As Long, ByVal componentDepositCount As Long)
    Dim withdrawalBundleUpper As Long, depositBundleUpper As Long, linkUpper As Long
    Dim withdrawalCapacityUpper As Long, depositCapacityUpper As Long, linkCapacityUpper As Long
    Dim plannedFlowRows As Long
    If withdrawalCount > 0 Or _
       (componentWithdrawalCount >= 2 And depositCount > 0) Then _
        withdrawalBundleUpper = ConservativeFlowBundleUpper( _
                                    withdrawalCount, componentWithdrawalCount, depositCount)
    If depositCount > 0 Or _
       (componentDepositCount >= 2 And withdrawalCount > 0) Then _
        depositBundleUpper = ConservativeFlowBundleUpper( _
                                 depositCount, componentDepositCount, withdrawalCount)
    linkUpper = ConservativeFlowLinkUpper(withdrawalBundleUpper, depositBundleUpper)
    withdrawalCapacityUpper = ConservativeFlowAllocatedCapacity( _
                                  withdrawalBundleUpper, FlowMaxBundlesPerSide())
    depositCapacityUpper = ConservativeFlowAllocatedCapacity( _
                               depositBundleUpper, FlowMaxBundlesPerSide())
    linkCapacityUpper = ConservativeFlowAllocatedCapacity(linkUpper, FlowMaxLinks())
    mFlowCapacityScratchRows = ConservativeFlowScratchRows( _
        withdrawalCount, depositCount, componentWithdrawalCount, componentDepositCount, _
        withdrawalBundleUpper, depositBundleUpper, linkUpper)
    plannedFlowRows = FlowCapacityCombinedRows( _
        mFlowCapacityScratchRows, withdrawalCapacityUpper, depositCapacityUpper, _
        linkCapacityUpper, 0, mFlowCapacityPlannedManualRows)
    RequireAdvancedFlowCapacity _
        "資金フロー候補の探索準備", mFlowCapacityPlannedShiftRows, _
        plannedFlowRows, mFlowCapacityPlannedUnknownRows, mFlowConfirmedWorkloadRows
    mFlowCheckedPlanRows = plannedFlowRows
End Sub

Private Sub RequireFlowArrayCapacity( _
        ByVal withdrawalBundleRows As Long, ByVal depositBundleRows As Long, _
        ByVal linkRows As Long, ByVal recordRows As Long)
    Dim plannedFlowRows As Long
    If Not mFlowCapacityActive Then Exit Sub
    plannedFlowRows = FlowCapacityCombinedRows( _
        mFlowCapacityScratchRows, withdrawalBundleRows, depositBundleRows, _
        linkRows, recordRows, mFlowCapacityPlannedManualRows)
    If plannedFlowRows <= mFlowCheckedPlanRows Then Exit Sub
    RequireAdvancedFlowCapacity _
        "資金フロー候補の内部配列拡張", mFlowCapacityPlannedShiftRows, _
        plannedFlowRows, mFlowCapacityPlannedUnknownRows, mFlowConfirmedWorkloadRows
    mFlowCheckedPlanRows = plannedFlowRows
End Sub

Private Sub RequireAdvancedFlowFinalCapacity(ByVal recordCount As Long)
    Dim plannedFlowRows As Long, plannedCandidateRows As Long, plannedResultRows As Long
    plannedFlowRows = FlowCapacityCombinedRows( _
        0, recordCount, 0, 0, 0, mFlowCapacityPlannedManualRows)
    plannedCandidateRows = FlowCapacityCombinedRows( _
        0, mFlowCapacityPlannedShiftRows, plannedFlowRows, 0, 0, 0)
    plannedResultRows = FlowCapacityCombinedRows( _
        0, plannedCandidateRows, mFlowCapacityPlannedUnknownRows, 0, 0, 0)
    RequireAdvancedFlowCapacity _
        "資金フロー候補の生成", mFlowCapacityPlannedShiftRows, plannedFlowRows, _
        mFlowCapacityPlannedUnknownRows, mFlowConfirmedWorkloadRows, _
        plannedResultRows, plannedCandidateRows
End Sub

Private Sub ApplyFlowSearchReductionNotice(ByVal ws As Worksheet)
    Dim headerCell As Range
    If ws Is Nothing Then Exit Sub
    Set headerCell = ws.Cells(1, 16)
    On Error Resume Next
    headerCell.ClearComments
    If mFlowSearchReduced Then
        headerCell.AddComment FlowSearchReductionNotice()
    ElseIf mFlowDisplayTruncated Then
        headerCell.AddComment FlowDisplayTruncationNotice()
        If Not (headerCell.Comment Is Nothing) Then
            headerCell.Comment.Visible = False
            headerCell.Comment.Shape.TextFrame.AutoSize = True
        End If
    End If
    On Error GoTo 0
End Sub

Public Function AdvancedFlowAnalysisHeaders() As Variant
    AdvancedFlowAnalysisHeaders = Array( _
        "評価", "スコア", "分析種別", "順序判定", "時刻精度", "期間", "段階数", "取引数", _
        "起点額", "追跡終端額", "起終点差", "推定資金経路", "推定取引順", "出金内訳", _
        "入金内訳", "判定理由", "確認状況", "確認メモ", "確認キー", "構成取引ID", _
        "起点口座ID", "終点口座ID")
End Function

'Excelシートを更新せず、縮約と保守的スコアの根本条件だけを確認する。
'生成工程から呼べるようPublic Functionとし、成功時だけTrueを返す。

Public Sub BuildAdvancedFlowAnalysisSheetCore( _
        ByRef sourceData As Variant, ByVal sourceRowCount As Long, _
        ByRef withdrawalRows() As Long, ByVal withdrawalCount As Long, _
        ByRef depositRows() As Long, ByVal depositCount As Long, _
        ByRef componentWithdrawalRows() As Long, ByVal componentWithdrawalCount As Long, _
        ByRef componentDepositRows() As Long, ByVal componentDepositCount As Long, _
        ByVal minimumBundleAmount As Double, ByVal dayWindow As Long, _
        ByVal absoluteTolerance As Double, _
        ByVal rateTolerance As Double, ByVal settingsSignature As String, _
        ByVal wsOut As Worksheet, ByVal reviews As Object, _
        ByVal candidateCountByTx As Object, ByVal bestScoreByTx As Object, _
        ByVal bestRatingByTx As Object, ByRef writtenCount As Long, _
        Optional ByVal plannedShiftRows As Long = -1, _
        Optional ByVal plannedUnknownRows As Long = -1, Optional ByVal plannedManualFlowRows As Long = -1, _
        Optional ByRef confirmedWorkloadRows As Double = 0#, _
        Optional ByVal allowCapacityPrompt As Boolean = True, _
        Optional ByVal additionalSnapshotCellWork As Double = 0#)
    Dim withdrawalBundles() As FlowBundle, depositBundles() As FlowBundle
    Dim links() As FlowLink, records() As FlowRecord
    Dim withdrawalBundleCount As Long, depositBundleCount As Long
    Dim linkCount As Long, recordCount As Long
    Dim effectiveDayWindow As Long
    Dim seenRecords As Object
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim failureDetail As String, dirtyDetail As String, recoveryDetail As String

    On Error GoTo BuildFailed
    ResetFlowSearchReductionState
    InitializeFlowCapacityState plannedShiftRows, plannedUnknownRows, plannedManualFlowRows, _
                                confirmedWorkloadRows, allowCapacityPrompt, _
                                additionalSnapshotCellWork
    effectiveDayWindow = AutoCandidateEffectiveDayWindow(dayWindow)
    If minimumBundleAmount < 0# Then _
        Err.Raise vbObjectError + 4703, "BuildAdvancedFlowAnalysisSheetCore", _
                  "資金フロー追跡の最低金額が不正です。"
    If wsOut Is Nothing Then _
        Err.Raise vbObjectError + 4700, "BuildAdvancedFlowAnalysisSheetCore", _
                  "資金フロー追跡の出力先がありません。"
    '入力件数から、束・リンク・作業配列の同時保持上界を探索開始前に確認する。
    RequireAdvancedFlowPreSearchCapacity _
        withdrawalCount, depositCount, componentWithdrawalCount, componentDepositCount
    Set seenRecords = CreateObject("Scripting.Dictionary")
    seenRecords.CompareMode = vbTextCompare

    If sourceRowCount > 0 Then
        If componentWithdrawalCount > 0 Then _
            BuildFlowBundles sourceData, withdrawalRows, withdrawalCount, False, effectiveDayWindow, _
                             componentWithdrawalRows, componentWithdrawalCount, depositRows, _
                             depositCount, absoluteTolerance, rateTolerance, minimumBundleAmount, _
                             withdrawalBundles, _
                             withdrawalBundleCount
        If componentDepositCount > 0 And Not mFlowSearchReduced Then _
            BuildFlowBundles sourceData, depositRows, depositCount, True, effectiveDayWindow, _
                             componentDepositRows, componentDepositCount, withdrawalRows, _
                             withdrawalCount, absoluteTolerance, rateTolerance, minimumBundleAmount, _
                             depositBundles, _
                             depositBundleCount
        If withdrawalBundleCount > 0 And depositBundleCount > 0 And _
           Not mFlowSearchReduced Then
            BuildFlowLinks sourceData, withdrawalBundles, withdrawalBundleCount, _
                           depositBundles, depositBundleCount, effectiveDayWindow, absoluteTolerance, _
                           rateTolerance, links, linkCount, records, recordCount, seenRecords
        End If
        If linkCount > 0 And Not mFlowRecordLimitReached And _
           Not mFlowSearchReduced Then
            BuildFlowChains sourceData, withdrawalBundles, withdrawalBundleCount, _
                            depositBundles, links, linkCount, effectiveDayWindow, absoluteTolerance, _
                            rateTolerance, records, recordCount, seenRecords
            If Not mFlowRecordLimitReached And Not mFlowSearchReduced Then _
                BuildDepositOriginFlowRecords sourceData, withdrawalBundles, depositBundles, _
                                              depositBundleCount, links, linkCount, effectiveDayWindow, _
                                              absoluteTolerance, rateTolerance, records, recordCount, _
                                              seenRecords
        End If
        If withdrawalBundleCount > 0 And depositBundleCount > 0 And _
           Not mFlowRecordLimitReached And Not mFlowSearchReduced Then
            BuildLongHorizonUnknownRecords sourceData, withdrawalBundles, _
                withdrawalBundleCount, depositBundles, depositBundleCount, _
                effectiveDayWindow, absoluteTolerance, rateTolerance, links, linkCount, _
                records, recordCount, seenRecords
        End If
    End If

    'ここより後は候補統計と出力シートを更新する。縮約・上限到達時は必ずその前で停止し、
    '既存結果を候補0件または部分結果で置き換えない。
    RequireCompleteFlowSearchBeforeOutput
    '実際の資金フロー件数を既存分析workloadへ置換合算し、閾値帯を越えた場合だけ再確認する。
    '手動候補と後続workspaceの結果・グループ上界も含め、旧出力の更新より前に確認する。
    RequireAdvancedFlowFinalCapacity recordCount
    UpdateFlowCandidateStats sourceData, withdrawalBundles, depositBundles, links, _
                             records, recordCount, candidateCountByTx, bestScoreByTx, bestRatingByTx
    PrepareAdvancedFlowAnalysisSheet wsOut
    If recordCount > 0 Then
        WriteAdvancedFlowAnalysis sourceData, withdrawalBundles, depositBundles, links, _
                                  records, recordCount, reviews, settingsSignature, _
                                  candidateCountByTx, wsOut, writtenCount
    End If
    If writtenCount <> recordCount Then _
        Err.Raise vbObjectError + 4702, "BuildAdvancedFlowAnalysisSheetCore", _
                  "資金フロー追跡の事前件数と出力件数が一致しません。"
    FinalizeAdvancedFlowAnalysisSheet wsOut, recordCount
    confirmedWorkloadRows = mFlowConfirmedWorkloadRows
    ResetFlowCapacityState
    Exit Sub

BuildFailed:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    If IsAdvancedFlowNestedRecoveryFatal(errorNumber, errorSource) Then
        Call TryKeepAdvancedFlowEventsDisabledExact(failureDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    If Not TryResetAdvancedFlowFailureState(confirmedWorkloadRows, failureDetail) Then _
        AppendAdvancedFlowFailureDetail failureDetail, _
            "容量管理状態の復旧を完了できません。"
    If Not TryConfirmAdvancedFlowOutputsDirty(dirtyDetail) Then
        AppendAdvancedFlowFailureDetail failureDetail, dirtyDetail
        recoveryDetail = _
            "帳票要更新状態を一意に確定できないため、" & _
            "共通Recoveryの所有権を外側の取引分析transactionへ伝播しました。"
        AppendAdvancedFlowFailureDetail failureDetail, recoveryDetail
    End If
    If Len(failureDetail) > 0 Then _
        errorDescription = errorDescription & " / 失敗後の安全状態: " & failureDetail
    Err.Raise errorNumber, "BuildAdvancedFlowAnalysisSheetCore", _
              errorSource & " / " & errorDescription
End Sub

Private Function TryResetAdvancedFlowFailureState( _
        ByRef confirmedWorkloadRows As Double, ByRef detailText As String) As Boolean
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim eventStateDetail As String
    detailText = vbNullString
    On Error GoTo EH
    If mFlowCapacityActive Then confirmedWorkloadRows = mFlowConfirmedWorkloadRows
    ResetFlowCapacityState
    TryResetAdvancedFlowFailureState = True
    Exit Function
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    If IsAdvancedFlowNestedRecoveryFatal(errorNumber, errorSource) Then
        Call TryKeepAdvancedFlowEventsDisabledExact(eventStateDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    detailText = "容量管理復旧: Err " & CStr(errorNumber) & _
                 " [" & errorSource & "] " & errorDescription
    Err.Clear
End Function

Private Function TryConfirmAdvancedFlowOutputsDirty(ByRef detailText As String) As Boolean
    Dim dirtyState As String
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim eventStateDetail As String
    detailText = vbNullString
    On Error GoTo EH
    MarkOutputsDirty
    If Not TryGetExactStateValue(STATE_OUTPUT_DIRTY, dirtyState) Or _
       StrComp(dirtyState, STATE_TRUE, vbBinaryCompare) <> 0 Then _
        Err.Raise vbObjectError + 4731, "TryConfirmAdvancedFlowOutputsDirty", _
                  "帳票要更新状態の書込読戻しが一致しません。"
    TryConfirmAdvancedFlowOutputsDirty = True
    Exit Function
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    If IsAdvancedFlowNestedRecoveryFatal(errorNumber, errorSource) Then
        Call TryKeepAdvancedFlowEventsDisabledExact(eventStateDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    detailText = "帳票要更新状態: Err " & CStr(errorNumber) & _
                 " [" & errorSource & "] " & errorDescription
    Err.Clear
End Function

Private Function IsAdvancedFlowNestedRecoveryFatal( _
        ByVal errorNumber As Long, ByVal errorSource As String) As Boolean
    Select Case errorNumber
        Case vbObjectError + 3599, vbObjectError + 4499
            IsAdvancedFlowNestedRecoveryFatal = True
        Case vbObjectError + 5191
            IsAdvancedFlowNestedRecoveryFatal = _
                (Left$(errorSource, Len("AnalysisWorkspaceRecoveryFatal/")) = _
                    "AnalysisWorkspaceRecoveryFatal/")
        Case vbObjectError + 5192
            IsAdvancedFlowNestedRecoveryFatal = _
                (Left$(errorSource, Len("SetupConvergeRecoveryFatal/")) = _
                    "SetupConvergeRecoveryFatal/")
        Case vbObjectError + 5194
            IsAdvancedFlowNestedRecoveryFatal = _
                (Left$(errorSource, Len("CashAnalysisRecoveryFatal/")) = _
                    "CashAnalysisRecoveryFatal/")
        Case vbObjectError + 5195
            IsAdvancedFlowNestedRecoveryFatal = _
                (Left$(errorSource, Len("TransactionAnalysisRecoveryFatal/")) = _
                    "TransactionAnalysisRecoveryFatal/")
        Case vbObjectError + 5196
            IsAdvancedFlowNestedRecoveryFatal = _
                (Left$(errorSource, Len("CashManualSelectionRecoveryFatal/")) = _
                    "CashManualSelectionRecoveryFatal/")
        Case vbObjectError + 5197
            IsAdvancedFlowNestedRecoveryFatal = _
                (Left$(errorSource, Len("ClearRecoveryFatal/")) = _
                    "ClearRecoveryFatal/")
    End Select
End Function

Private Function TryKeepAdvancedFlowEventsDisabledExact( _
        ByRef detailText As String) As Boolean
    Dim actualValue As Boolean
    Dim setterErrorNumber As Long, setterErrorDescription As String
    Dim readErrorNumber As Long, readErrorDescription As String
    detailText = vbNullString
    On Error Resume Next
    Err.Clear
    Application.EnableEvents = False
    setterErrorNumber = Err.Number
    setterErrorDescription = Err.Description
    Err.Clear
    actualValue = Application.EnableEvents
    readErrorNumber = Err.Number
    readErrorDescription = Err.Description
    Err.Clear
    On Error GoTo 0
    If setterErrorNumber = 0 And readErrorNumber = 0 Then
        If Not actualValue Then
            TryKeepAdvancedFlowEventsDisabledExact = True
            Exit Function
        End If
    End If
    If setterErrorNumber <> 0 Then _
        AppendAdvancedFlowFailureDetail detailText, _
            "setter Err " & CStr(setterErrorNumber) & " " & setterErrorDescription
    If readErrorNumber <> 0 Then
        AppendAdvancedFlowFailureDetail detailText, _
            "readback Err " & CStr(readErrorNumber) & " " & readErrorDescription
    ElseIf actualValue Then
        AppendAdvancedFlowFailureDetail detailText, _
            "EnableEventsのreadbackがTrueです。"
    End If
End Function

Private Sub AppendAdvancedFlowFailureDetail(ByRef detailText As String, _
                                            ByVal newDetail As String)
    newDetail = Trim$(newDetail)
    If Len(newDetail) = 0 Then Exit Sub
    If Len(detailText) > 0 Then detailText = detailText & " / "
    detailText = detailText & newDetail
End Sub

Public Sub PrepareAdvancedFlowAnalysisSheet(ByVal ws As Worksheet)
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim eventStateDetail As String
    If ws Is Nothing Then Exit Sub
    On Error GoTo EH
    ws.Unprotect Password:=TOOL_PASSWORD
    If ws.AutoFilterMode Then ws.AutoFilterMode = False
    ResetWorksheet ws
    SetRowValues ws.Range("A1"), AdvancedFlowAnalysisHeaders()
    FormatOutputHeader ws.Range(ws.Cells(1, 1), ws.Cells(1, FLOW_ANALYSIS_LAST_COL))
    ws.Columns("A:V").NumberFormatLocal = "@"
    ws.Columns("B:B").NumberFormatLocal = "0"
    ws.Columns("G:H").NumberFormatLocal = "0"
    ws.Columns("I:K").NumberFormatLocal = "#,##0.########"
    ApplyAdvancedFlowColumnWidths ws
    ws.Columns("S:V").Hidden = True
    ProtectSingleAnalysisSheet ws
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    If IsAdvancedFlowNestedRecoveryFatal(errorNumber, errorSource) Then
        Call TryKeepAdvancedFlowEventsDisabledExact(eventStateDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    On Error Resume Next
    EmergencyProtectToolSheet ws
    On Error GoTo 0
    Err.Raise errorNumber, "PrepareAdvancedFlowAnalysisSheet", errorSource & " / " & errorDescription
End Sub

Public Sub FinalizeAdvancedFlowAnalysisSheet(ByVal ws As Worksheet, ByVal dataCount As Long)
    Dim lastR As Long
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim eventStateDetail As String
    If ws Is Nothing Then Exit Sub
    On Error GoTo EH
    ws.Unprotect Password:=TOOL_PASSWORD
    lastR = dataCount + 1
    FormatOutputHeader ws.Range(ws.Cells(1, 1), ws.Cells(1, FLOW_ANALYSIS_LAST_COL))
    If dataCount > 1 Then SortAdvancedFlowAnalysis ws, lastR
    ApplyAdvancedFlowColumnWidths ws
    ApplyFlowSearchReductionNotice ws
    ws.Columns("S:V").Hidden = True
    If dataCount > 0 Then
        With ws.Range(ws.Cells(2, 1), ws.Cells(lastR, FLOW_ANALYSIS_LAST_COL))
            .VerticalAlignment = xlTop
            .WrapText = False
        End With
        If dataCount <= 10000 Then
            With ws.Range(ws.Cells(2, 1), ws.Cells(lastR, FLOW_ANALYSIS_LAST_COL)).Borders
                .Color = RGB(226, 232, 240)
                .LineStyle = xlContinuous
            End With
        End If
        ws.Range(ws.Cells(2, 12), ws.Cells(lastR, 18)).WrapText = True
        ws.Range(ws.Cells(2, FLOW_ANALYSIS_STATUS_COL), _
                 ws.Cells(lastR, FLOW_ANALYSIS_MEMO_COL)).Interior.Color = RGB(254, 249, 195)
        ws.Rows("2:" & CStr(lastR)).RowHeight = 54
    End If
    If ws.AutoFilterMode Then ws.AutoFilterMode = False
    ws.Range(ws.Cells(1, 1), ws.Cells(lastR, FLOW_ANALYSIS_LAST_COL)).AutoFilter
    ApplyAnalysisReviewValidation ws, FLOW_ANALYSIS_STATUS_COL, FLOW_ANALYSIS_MEMO_COL, lastR
    SafeFreezeOutputHeader ws
    ProtectSingleAnalysisSheet ws
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    If IsAdvancedFlowNestedRecoveryFatal(errorNumber, errorSource) Then
        Call TryKeepAdvancedFlowEventsDisabledExact(eventStateDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    On Error Resume Next
    EmergencyProtectToolSheet ws
    On Error GoTo 0
    Err.Raise errorNumber, "FinalizeAdvancedFlowAnalysisSheet", errorSource & " / " & errorDescription
End Sub

Private Sub ApplyAdvancedFlowColumnWidths(ByVal ws As Worksheet)
    ws.Columns("A:B").ColumnWidth = 8
    ws.Columns("C:C").ColumnWidth = 24
    ws.Columns("D:F").ColumnWidth = 22
    ws.Columns("G:H").ColumnWidth = 10
    ws.Columns("I:K").ColumnWidth = 16
    ws.Columns("L:L").ColumnWidth = 46
    ws.Columns("M:O").ColumnWidth = 58
    ws.Columns("P:P").ColumnWidth = 60
    ws.Columns("Q:Q").ColumnWidth = 16
    ws.Columns("R:R").ColumnWidth = 38
End Sub

Private Sub SortAdvancedFlowAnalysis(ByVal ws As Worksheet, ByVal lastR As Long)
    With ws.Sort
        .SortFields.Clear
        .SortFields.Add Key:=ws.Range(ws.Cells(2, 2), ws.Cells(lastR, 2)), _
                        SortOn:=xlSortOnValues, Order:=xlDescending, DataOption:=xlSortNormal
        .SortFields.Add Key:=ws.Range(ws.Cells(2, 3), ws.Cells(lastR, 3)), _
                        SortOn:=xlSortOnValues, Order:=xlAscending, DataOption:=xlSortNormal
        .SetRange ws.Range(ws.Cells(1, 1), ws.Cells(lastR, FLOW_ANALYSIS_LAST_COL))
        .Header = xlYes
        .Apply
    End With
End Sub

Private Sub BuildFlowBundles(ByRef sourceData As Variant, ByRef sourceRows() As Long, _
                             ByVal sourceCount As Long, ByVal isDeposit As Boolean, _
                             ByVal dayWindow As Long, ByRef componentRows() As Long, _
                             ByVal componentCount As Long, ByRef targetRows() As Long, _
                             ByVal targetCount As Long, ByVal absoluteTolerance As Double, _
                             ByVal rateTolerance As Double, ByVal minimumBundleAmount As Double, _
                             ByRef bundles() As FlowBundle, _
                             ByRef bundleCount As Long)
    Dim seen As Object
    Dim i As Long, multiCount As Long, operationCount As Long
    Dim selectedRows(1 To FLOW_MAX_SIDE_TRANSACTIONS) As Long
    Set seen = CreateObject("Scripting.Dictionary")
    seen.CompareMode = vbTextCompare
    mFlowCurrentSideGenerationStopped = False

    For i = 1 To sourceCount
        selectedRows(1) = sourceRows(i)
        AddSelectedFlowBundle sourceData, selectedRows, 1, isDeposit, dayWindow, _
                              bundles, bundleCount, multiCount, seen
        If mFlowCurrentSideGenerationStopped Then Exit For
    Next i
    If componentCount >= 2 And Not mFlowCurrentSideGenerationStopped Then _
        GenerateCompleteWindowFlowBundles sourceData, componentRows, componentCount, _
                                          isDeposit, dayWindow, minimumBundleAmount, _
                                          bundles, bundleCount, multiCount, seen, _
                                          operationCount
End Sub

'0～3日窓内の全2件・3件集合を、口座・人物・入力順に依存せず列挙する。
'上限へ達した場合は部分結果を公開せず、既存結果を保持してfail closedとする。
Private Sub GenerateCompleteWindowFlowBundles( _
        ByRef sourceData As Variant, ByRef componentRows() As Long, _
        ByVal componentCount As Long, ByVal isDeposit As Boolean, _
        ByVal dayWindow As Long, ByVal minimumBundleAmount As Double, _
        ByRef bundles() As FlowBundle, ByRef bundleCount As Long, _
        ByRef multiCount As Long, ByVal seen As Object, _
        ByRef operationCount As Long)
    Dim sortedRows() As Long, sortKeys() As String, sortStamps() As Double
    Dim selectedRows(1 To FLOW_MAX_SIDE_TRANSACTIONS) As Long
    Dim firstPos As Long, maxPos As Long, i As Long
    Dim firstDate As Long, effectiveDayWindow As Long
    Dim followerCount As Long, operationUpper As Double
    effectiveDayWindow = AutoCandidateEffectiveDayWindow(dayWindow)
    ReDim sortedRows(1 To componentCount)
    ReDim sortKeys(1 To componentCount)
    ReDim sortStamps(1 To componentCount)
    For i = 1 To componentCount
        sortedRows(i) = componentRows(i)
        sortKeys(i) = "G"
        sortStamps(i) = FlowSortStamp(sourceData, componentRows(i))
    Next i
    If componentCount > 1 Then _
        QuickSortFlowContext sortKeys, sortStamps, sortedRows, 1, componentCount

    '再帰列挙へ入る前に、実際の0～3日窓ごとの2件・3件演算上界をDoubleで合算する。
    '密集データは500万回を回してから止めず、旧結果を保持したまま即時safe stopする。
    maxPos = 1
    For firstPos = 1 To componentCount - 1
        If maxPos < firstPos Then maxPos = firstPos
        firstDate = CLng(VBA.DateValue(CDate( _
                    sourceData(sortedRows(firstPos), OUT_COL_DATE))))
        Do While maxPos < componentCount
            If CLng(VBA.DateValue(CDate( _
                   sourceData(sortedRows(maxPos + 1), OUT_COL_DATE)))) - _
               firstDate > effectiveDayWindow Then Exit Do
            maxPos = maxPos + 1
        Loop
        followerCount = maxPos - firstPos
        operationUpper = operationUpper + _
                         FlowCombinationOperationsForFollowers(followerCount)
        If operationUpper > CDbl(FLOW_MAX_COMBINATION_OPERATIONS) Or _
           operationUpper > CDbl(FlowMaxMultiBundlesPerSide()) Then
            MarkFlowSearchReduced 0, False, True
            mFlowCurrentSideGenerationStopped = True
            Exit Sub
        End If
    Next firstPos

    For firstPos = 1 To componentCount - 1
        If mFlowCurrentSideGenerationStopped Then Exit For
        selectedRows(1) = sortedRows(firstPos)
        firstDate = CLng(VBA.DateValue(CDate( _
                    sourceData(sortedRows(firstPos), OUT_COL_DATE))))
        maxPos = firstPos
        Do While maxPos < componentCount
            If CLng(VBA.DateValue(CDate( _
                   sourceData(sortedRows(maxPos + 1), OUT_COL_DATE)))) - _
               firstDate > effectiveDayWindow Then Exit Do
            maxPos = maxPos + 1
        Loop
        If maxPos > firstPos Then _
            ExtendCompleteWindowCombination sourceData, sortedRows, firstPos + 1, _
                maxPos, selectedRows, 1, isDeposit, dayWindow, minimumBundleAmount, _
                bundles, bundleCount, multiCount, seen, operationCount
    Next firstPos
End Sub

Private Function FlowCombinationOperationsForFollowers( _
        ByVal followerCount As Long) As Double
    If followerCount <= 0 Then Exit Function
    FlowCombinationOperationsForFollowers = CDbl(followerCount)
    If followerCount >= 2 Then _
        FlowCombinationOperationsForFollowers = _
            FlowCombinationOperationsForFollowers + _
            CDbl(followerCount) * CDbl(followerCount - 1) / 2#
End Function

Private Sub ExtendCompleteWindowCombination( _
        ByRef sourceData As Variant, ByRef sortedRows() As Long, _
        ByVal nextPos As Long, ByVal maxPos As Long, _
        ByRef selectedRows() As Long, ByVal selectedCount As Long, _
        ByVal isDeposit As Boolean, ByVal dayWindow As Long, _
        ByVal minimumBundleAmount As Double, ByRef bundles() As FlowBundle, _
        ByRef bundleCount As Long, ByRef multiCount As Long, _
        ByVal seen As Object, ByRef operationCount As Long)
    Dim pos As Long, newCount As Long
    For pos = nextPos To maxPos
        If mFlowCurrentSideGenerationStopped Then Exit For
        operationCount = operationCount + 1
        If operationCount Mod 4096 = 0 Then _
            AppProgress "0～3日内の分割・合算候補を探索しています...", _
                        operationCount, FLOW_MAX_COMBINATION_OPERATIONS
        If operationCount > FLOW_MAX_COMBINATION_OPERATIONS Then
            MarkFlowSearchReduced 0, False, True
            mFlowCurrentSideGenerationStopped = True
            Exit For
        End If
        newCount = selectedCount + 1
        selectedRows(newCount) = sortedRows(pos)
        If FlowSelectedBundleMeetsMinimum( _
                sourceData, selectedRows, newCount, isDeposit, minimumBundleAmount) Then _
            AddSelectedFlowBundle sourceData, selectedRows, newCount, isDeposit, _
                                  dayWindow, bundles, bundleCount, multiCount, seen
        If newCount < FLOW_MAX_SIDE_TRANSACTIONS And pos < maxPos Then _
            ExtendCompleteWindowCombination sourceData, sortedRows, pos + 1, maxPos, _
                selectedRows, newCount, isDeposit, dayWindow, minimumBundleAmount, _
                bundles, bundleCount, multiCount, seen, operationCount
    Next pos
End Sub

Private Function FlowSelectedBundleMeetsMinimum( _
        ByRef sourceData As Variant, ByRef selectedRows() As Long, _
        ByVal selectedCount As Long, ByVal isDeposit As Boolean, _
        ByVal minimumBundleAmount As Double) As Boolean
    Dim i As Long, amountTotal As Double
    If selectedCount < 2 Or minimumBundleAmount < 0# Then Exit Function
    For i = 1 To selectedCount
        If isDeposit Then
            amountTotal = amountTotal + _
                          CDbl(sourceData(selectedRows(i), OUT_COL_DEPOSIT))
        Else
            amountTotal = amountTotal + _
                          CDbl(sourceData(selectedRows(i), OUT_COL_WITHDRAW))
        End If
    Next i
    FlowSelectedBundleMeetsMinimum = _
        (amountTotal + 0.0000001 >= minimumBundleAmount)
End Function


Private Sub KeepBestFlowCandidate( _
        ByVal firstIndex As Long, ByVal secondIndex As Long, ByVal differenceAmount As Double, _
        ByVal maximumCount As Long, ByRef bestFirstIndexes() As Long, _
        ByRef bestSecondIndexes() As Long, ByRef bestDifferences() As Double, _
        ByRef bestCount As Long)
    Dim insertPosition As Long, shiftPosition As Long
    If maximumCount <= 0 Then Exit Sub
    If bestCount < maximumCount Then
        bestCount = bestCount + 1
    ElseIf Not FlowCandidateComesBefore( _
            differenceAmount, firstIndex, secondIndex, bestDifferences(bestCount), _
            bestFirstIndexes(bestCount), bestSecondIndexes(bestCount)) Then
        Exit Sub
    End If

    insertPosition = bestCount
    Do While insertPosition > 1
        If Not FlowCandidateComesBefore( _
                differenceAmount, firstIndex, secondIndex, bestDifferences(insertPosition - 1), _
                bestFirstIndexes(insertPosition - 1), bestSecondIndexes(insertPosition - 1)) Then Exit Do
        insertPosition = insertPosition - 1
    Loop
    For shiftPosition = bestCount To insertPosition + 1 Step -1
        bestDifferences(shiftPosition) = bestDifferences(shiftPosition - 1)
        bestFirstIndexes(shiftPosition) = bestFirstIndexes(shiftPosition - 1)
        bestSecondIndexes(shiftPosition) = bestSecondIndexes(shiftPosition - 1)
    Next shiftPosition
    bestDifferences(insertPosition) = differenceAmount
    bestFirstIndexes(insertPosition) = firstIndex
    bestSecondIndexes(insertPosition) = secondIndex
End Sub

Private Sub ConsiderReservedFlowCandidate( _
        ByVal firstIndex As Long, ByVal secondIndex As Long, _
        ByVal differenceAmount As Double, ByRef reservedFirstIndex As Long, _
        ByRef reservedSecondIndex As Long, ByRef reservedDifference As Double, _
        ByRef reservedFound As Boolean)
    If reservedFound Then
        If Not FlowCandidateComesBefore( _
                differenceAmount, firstIndex, secondIndex, reservedDifference, _
                reservedFirstIndex, reservedSecondIndex) Then Exit Sub
    End If
    reservedFirstIndex = firstIndex
    reservedSecondIndex = secondIndex
    reservedDifference = differenceAmount
    reservedFound = True
End Sub

Private Sub EnsureReservedFlowCandidateIsKept( _
        ByVal reservedFirstIndex As Long, ByVal reservedSecondIndex As Long, _
        ByVal reservedDifference As Double, ByVal reservedFound As Boolean, _
        ByVal maximumCount As Long, ByRef bestFirstIndexes() As Long, _
        ByRef bestSecondIndexes() As Long, ByRef bestDifferences() As Double, _
        ByRef bestCount As Long)
    Dim insertPosition As Long, shiftPosition As Long
    If Not reservedFound Or maximumCount <= 0 Then Exit Sub
    If FlowCandidateIsKept(reservedFirstIndex, reservedSecondIndex, _
                           bestFirstIndexes, bestSecondIndexes, bestCount) Then Exit Sub

    If bestCount < maximumCount Then bestCount = bestCount + 1
    insertPosition = bestCount
    Do While insertPosition > 1
        If Not FlowCandidateComesBefore( _
                reservedDifference, reservedFirstIndex, reservedSecondIndex, _
                bestDifferences(insertPosition - 1), _
                bestFirstIndexes(insertPosition - 1), _
                bestSecondIndexes(insertPosition - 1)) Then Exit Do
        insertPosition = insertPosition - 1
    Loop
    For shiftPosition = bestCount To insertPosition + 1 Step -1
        bestDifferences(shiftPosition) = bestDifferences(shiftPosition - 1)
        bestFirstIndexes(shiftPosition) = bestFirstIndexes(shiftPosition - 1)
        bestSecondIndexes(shiftPosition) = bestSecondIndexes(shiftPosition - 1)
    Next shiftPosition
    bestDifferences(insertPosition) = reservedDifference
    bestFirstIndexes(insertPosition) = reservedFirstIndex
    bestSecondIndexes(insertPosition) = reservedSecondIndex
End Sub

Private Function FlowCandidateIsKept( _
        ByVal firstIndex As Long, ByVal secondIndex As Long, _
        ByRef bestFirstIndexes() As Long, ByRef bestSecondIndexes() As Long, _
        ByVal bestCount As Long) As Boolean
    Dim i As Long
    For i = 1 To bestCount
        If bestFirstIndexes(i) = firstIndex And _
           bestSecondIndexes(i) = secondIndex Then
            FlowCandidateIsKept = True
            Exit Function
        End If
    Next i
End Function


Private Function FlowCandidateComesBefore( _
        ByVal differenceAmount As Double, ByVal firstIndex As Long, ByVal secondIndex As Long, _
        ByVal otherDifference As Double, ByVal otherFirstIndex As Long, _
        ByVal otherSecondIndex As Long) As Boolean
    If differenceAmount < otherDifference - 0.0000001 Then
        FlowCandidateComesBefore = True
    ElseIf differenceAmount <= otherDifference + 0.0000001 Then
        If firstIndex < otherFirstIndex Then
            FlowCandidateComesBefore = True
        ElseIf firstIndex = otherFirstIndex Then
            FlowCandidateComesBefore = (secondIndex < otherSecondIndex)
        End If
    End If
End Function


Private Function FlowSortStamp(ByRef sourceData As Variant, ByVal sourceRow As Long) As Double
    Dim timeFraction As Double
    FlowSortStamp = CDbl(VBA.DateValue(CDate(sourceData(sourceRow, OUT_COL_DATE))))
    If TryGetFlowTime(sourceData(sourceRow, OUT_COL_TIME), timeFraction) Then
        FlowSortStamp = FlowSortStamp + timeFraction
    End If
    '時刻未記載へ架空の時刻を足さない。この値は候補生成の安定順だけに使い、
    '同日内の前後判定には使用しない。
End Function


Private Sub AddSelectedFlowBundle( _
        ByRef sourceData As Variant, ByRef selectedRows() As Long, ByVal selectedCount As Long, _
        ByVal isDeposit As Boolean, ByVal dayWindow As Long, ByRef bundles() As FlowBundle, _
        ByRef bundleCount As Long, ByRef multiCount As Long, ByVal seen As Object)
    Dim rowValues(1 To FLOW_MAX_AGGREGATE_TRANSACTIONS) As Long
    Dim idValues(1 To FLOW_MAX_AGGREGATE_TRANSACTIONS) As String
    Dim accountValues(1 To FLOW_MAX_AGGREGATE_TRANSACTIONS) As String
    Dim uniqueAccounts As Object
    Dim i As Long, sourceRow As Long, accountCount As Long
    Dim rowList As String, idList As String, accountList As String, keyText As String
    Dim personID As String, personKey As String
    Dim totalAmount As Double, minDate As Long, maxDate As Long, transactionDateSerial As Long
    Dim effectiveDayWindow As Long
    Dim timeFraction As Double, hasTime As Boolean
    Dim anyTime As Boolean, allTimes As Boolean
    Set uniqueAccounts = CreateObject("Scripting.Dictionary")
    uniqueAccounts.CompareMode = vbTextCompare
    allTimes = True
    effectiveDayWindow = AutoCandidateEffectiveDayWindow(dayWindow)

    For i = 1 To selectedCount
        sourceRow = selectedRows(i)
        rowValues(i) = sourceRow
        idValues(i) = CellText(sourceData(sourceRow, WORK_TX_COL_TRANSACTION_ID))
        If Len(idValues(i)) = 0 Then Exit Sub
        If isDeposit Then
            totalAmount = totalAmount + CDbl(sourceData(sourceRow, OUT_COL_DEPOSIT))
        Else
            totalAmount = totalAmount + CDbl(sourceData(sourceRow, OUT_COL_WITHDRAW))
        End If
        transactionDateSerial = CLng(VBA.DateValue(CDate(sourceData(sourceRow, OUT_COL_DATE))))
        If i = 1 Or transactionDateSerial < minDate Then minDate = transactionDateSerial
        If i = 1 Or transactionDateSerial > maxDate Then maxDate = transactionDateSerial
        hasTime = TryGetFlowTime(sourceData(sourceRow, OUT_COL_TIME), timeFraction)
        If hasTime Then
            anyTime = True
        Else
            allTimes = False
        End If
        accountValues(i) = CellText(sourceData(sourceRow, WORK_TX_COL_ACCOUNT_ID))
        If Len(accountValues(i)) = 0 Then Exit Sub
        If Not uniqueAccounts.Exists(accountValues(i)) Then uniqueAccounts.Add accountValues(i), True
        personID = RequiredFlowPersonIDForRow( _
                       sourceData, sourceRow, "資金フロー取引束")
        If i = 1 Then
            personKey = personID
        ElseIf StrComp(personKey, FLOW_MULTI_PERSON_KEY, vbBinaryCompare) <> 0 Then
            If StrComp(personKey, personID, vbTextCompare) <> 0 Then _
                personKey = FLOW_MULTI_PERSON_KEY
        End If
    Next i
    If selectedCount > 1 And maxDate - minDate > effectiveDayWindow Then Exit Sub
    If totalAmount <= 0 Then Exit Sub

    SortLongValues rowValues, selectedCount
    SortTextValues idValues, selectedCount
    rowList = JoinLongValues(rowValues, selectedCount)
    idList = JoinTextValues(idValues, selectedCount)
    accountCount = DictionaryKeysToSortedArray(uniqueAccounts, accountValues)
    accountList = JoinTextValues(accountValues, accountCount)
    keyText = CStr(selectedCount) & ":" & idList
    If seen.Exists(keyText) Then Exit Sub

    If Not ReserveFlowBundleSlot(selectedCount, bundleCount, multiCount) Then Exit Sub
    EnsureFlowBundleCapacity bundles, bundleCount + 1, isDeposit
    bundleCount = bundleCount + 1
    With bundles(bundleCount)
        .RowList = rowList
        .IdList = idList
        .AccountList = accountList
        .PersonKey = personKey
        .TotalAmount = totalAmount
        .ItemCount = selectedCount
        .MinDate = minDate
        .MaxDate = maxDate
        .HasAnyTime = anyTime
        .HasAllTimes = allTimes
    End With
    SetFlowBundleStampBounds sourceData, bundles(bundleCount)
    seen.Add keyText, bundleCount
End Sub

Private Function ReserveFlowBundleSlot(ByVal selectedCount As Long, _
                                       ByVal bundleCount As Long, _
                                       ByRef multiCount As Long) As Boolean
    If bundleCount >= FlowMaxBundlesPerSide() Then
        MarkFlowSearchReduced 1, False, True
        mFlowCurrentSideGenerationStopped = True
        Exit Function
    End If
    If selectedCount > 1 Then
        If multiCount >= FlowMaxMultiBundlesPerSide() Then
            MarkFlowSearchReduced 1, False, True
            mFlowCurrentSideGenerationStopped = True
            Exit Function
        End If
        multiCount = multiCount + 1
    End If
    ReserveFlowBundleSlot = True
End Function

Private Sub SetFlowBundleStampBounds(ByRef sourceData As Variant, ByRef bundle As FlowBundle)
    Dim rowParts As Variant, item As Variant
    Dim sourceRow As Long, timeFraction As Double, stampValue As Double
    Dim firstValue As Boolean
    firstValue = True
    rowParts = Split(bundle.RowList, ";")
    For Each item In rowParts
        sourceRow = CLng(item)
        stampValue = CDbl(VBA.DateValue(CDate(sourceData(sourceRow, OUT_COL_DATE))))
        If TryGetFlowTime(sourceData(sourceRow, OUT_COL_TIME), timeFraction) Then _
            stampValue = stampValue + timeFraction
        If firstValue Or stampValue < bundle.MinStamp Then bundle.MinStamp = stampValue
        If firstValue Or stampValue > bundle.MaxStamp Then bundle.MaxStamp = stampValue
        firstValue = False
    Next item
End Sub

Private Sub EnsureFlowBundleCapacity(ByRef bundles() As FlowBundle, ByVal requiredCount As Long, _
                                     ByVal isDeposit As Boolean)
    Dim newCapacity As Long
    If requiredCount > FlowMaxBundlesPerSide() Then _
        Err.Raise vbObjectError + 4710, "EnsureFlowBundleCapacity", _
                  "資金フローの取引束が片側" & _
                  Format$(FlowMaxBundlesPerSide(), "#,##0") & _
                  "件を超えました。最低金額を上げるか、分析対象を分けてください。"
    If requiredCount <= 1 Then
        newCapacity = 1024
        If mFlowCapacityActive Then
            If isDeposit Then
                RequireFlowArrayCapacity mFlowWithdrawalBundleCapacity, newCapacity, _
                                         mFlowLinkCapacity, mFlowRecordCapacity
                mFlowDepositBundleCapacity = newCapacity
            Else
                RequireFlowArrayCapacity newCapacity, mFlowDepositBundleCapacity, _
                                         mFlowLinkCapacity, mFlowRecordCapacity
                mFlowWithdrawalBundleCapacity = newCapacity
            End If
        End If
        ReDim bundles(1 To newCapacity)
    ElseIf requiredCount > UBound(bundles) Then
        newCapacity = UBound(bundles) * 2
        If newCapacity < requiredCount Then newCapacity = requiredCount
        If newCapacity > FlowMaxBundlesPerSide() Then newCapacity = FlowMaxBundlesPerSide()
        If mFlowCapacityActive Then
            If isDeposit Then
                RequireFlowArrayCapacity mFlowWithdrawalBundleCapacity, newCapacity, _
                                         mFlowLinkCapacity, mFlowRecordCapacity
                mFlowDepositBundleCapacity = newCapacity
            Else
                RequireFlowArrayCapacity newCapacity, mFlowDepositBundleCapacity, _
                                         mFlowLinkCapacity, mFlowRecordCapacity
                mFlowWithdrawalBundleCapacity = newCapacity
            End If
        End If
        ReDim Preserve bundles(1 To newCapacity)
    End If
End Sub

Private Sub QuickSortFlowContext(ByRef keys() As String, ByRef stamps() As Double, _
                                 ByRef rows() As Long, ByVal firstIndex As Long, _
                                 ByVal lastIndex As Long)
    Dim low As Long, high As Long, pivotIndex As Long
    Dim pivotKey As String, pivotStamp As Double, pivotRow As Long
    Dim tempKey As String, tempStamp As Double, tempRow As Long
    low = firstIndex
    high = lastIndex
    pivotIndex = (firstIndex + lastIndex) \ 2
    pivotKey = keys(pivotIndex)
    pivotStamp = stamps(pivotIndex)
    pivotRow = rows(pivotIndex)
    Do While low <= high
        Do While CompareFlowContext(keys(low), stamps(low), rows(low), _
                                    pivotKey, pivotStamp, pivotRow) < 0
            low = low + 1
        Loop
        Do While CompareFlowContext(keys(high), stamps(high), rows(high), _
                                    pivotKey, pivotStamp, pivotRow) > 0
            high = high - 1
        Loop
        If low <= high Then
            tempKey = keys(low): keys(low) = keys(high): keys(high) = tempKey
            tempStamp = stamps(low): stamps(low) = stamps(high): stamps(high) = tempStamp
            tempRow = rows(low): rows(low) = rows(high): rows(high) = tempRow
            low = low + 1
            high = high - 1
        End If
    Loop
    If firstIndex < high Then QuickSortFlowContext keys, stamps, rows, firstIndex, high
    If low < lastIndex Then QuickSortFlowContext keys, stamps, rows, low, lastIndex
End Sub

Private Function CompareFlowContext(ByVal firstKey As String, ByVal firstStamp As Double, _
                                    ByVal firstRow As Long, ByVal secondKey As String, _
                                    ByVal secondStamp As Double, ByVal secondRow As Long) As Long
    CompareFlowContext = StrComp(firstKey, secondKey, vbBinaryCompare)
    If CompareFlowContext <> 0 Then Exit Function
    If firstStamp < secondStamp Then
        CompareFlowContext = -1
    ElseIf firstStamp > secondStamp Then
        CompareFlowContext = 1
    ElseIf firstRow < secondRow Then
        CompareFlowContext = -1
    ElseIf firstRow > secondRow Then
        CompareFlowContext = 1
    End If
End Function

Private Sub SortLongValues(ByRef values() As Long, ByVal itemCount As Long)
    Dim i As Long, j As Long, valueToInsert As Long
    For i = 2 To itemCount
        valueToInsert = values(i)
        j = i - 1
        Do While j >= 1
            If values(j) <= valueToInsert Then Exit Do
            values(j + 1) = values(j)
            j = j - 1
        Loop
        values(j + 1) = valueToInsert
    Next i
End Sub

Private Sub SortTextValues(ByRef values() As String, ByVal itemCount As Long)
    Dim i As Long, j As Long, valueToInsert As String
    For i = 2 To itemCount
        valueToInsert = values(i)
        j = i - 1
        Do While j >= 1
            If StrComp(values(j), valueToInsert, vbTextCompare) <= 0 Then Exit Do
            values(j + 1) = values(j)
            j = j - 1
        Loop
        values(j + 1) = valueToInsert
    Next i
End Sub

Private Function JoinLongValues(ByRef values() As Long, ByVal itemCount As Long) As String
    Dim i As Long
    For i = 1 To itemCount
        If i > 1 Then JoinLongValues = JoinLongValues & ";"
        JoinLongValues = JoinLongValues & CStr(values(i))
    Next i
End Function

Private Function JoinTextValues(ByRef values() As String, ByVal itemCount As Long) As String
    Dim i As Long
    For i = 1 To itemCount
        If i > 1 Then JoinTextValues = JoinTextValues & ";"
        JoinTextValues = JoinTextValues & values(i)
    Next i
End Function

Private Function DictionaryKeysToSortedArray(ByVal values As Object, _
                                             ByRef targetValues() As String) As Long
    Dim item As Variant, itemCount As Long
    If values Is Nothing Then Exit Function
    For Each item In values.Keys
        itemCount = itemCount + 1
        targetValues(itemCount) = CStr(item)
    Next item
    If itemCount > 1 Then SortTextValues targetValues, itemCount
    DictionaryKeysToSortedArray = itemCount
End Function

Private Sub BuildFlowLinks( _
        ByRef sourceData As Variant, ByRef withdrawalBundles() As FlowBundle, _
        ByVal withdrawalBundleCount As Long, ByRef depositBundles() As FlowBundle, _
        ByVal depositBundleCount As Long, ByVal dayWindow As Long, _
        ByVal absoluteTolerance As Double, ByVal rateTolerance As Double, _
        ByRef links() As FlowLink, ByRef linkCount As Long, _
        ByRef records() As FlowRecord, ByRef recordCount As Long, ByVal seenRecords As Object)
    Dim depositAmounts() As Double, depositIndexes() As Long
    Dim bestWithdrawalIndexes() As Long, bestDepositIndexes() As Long
    Dim bestDifferences() As Double
    Dim i As Long, j As Long, firstMatch As Long, lastMatch As Long
    Dim bestMatchCount As Long, eligibleMatchCount As Long
    Dim reservedWithdrawalIndex As Long, reservedDepositIndex As Long
    Dim lowerAmount As Double, upperAmount As Double, differenceAmount As Double
    Dim reservedDifference As Double, reservedDifferentFound As Boolean
    Dim matchOperations As Long, stopAfterCurrentWithdrawal As Boolean
    ReDim depositAmounts(1 To depositBundleCount)
    ReDim depositIndexes(1 To depositBundleCount)
    ReDim bestWithdrawalIndexes(1 To FLOW_LINK_TOP_K_PER_WITHDRAWAL)
    ReDim bestDepositIndexes(1 To FLOW_LINK_TOP_K_PER_WITHDRAWAL)
    ReDim bestDifferences(1 To FLOW_LINK_TOP_K_PER_WITHDRAWAL)
    For i = 1 To depositBundleCount
        depositAmounts(i) = depositBundles(i).TotalAmount
        depositIndexes(i) = i
    Next i
    If depositBundleCount > 1 Then _
        QuickSortFlowAmounts depositAmounts, depositIndexes, 1, depositBundleCount

    For i = 1 To withdrawalBundleCount
        If mFlowLinkGenerationStopped Or mFlowRecordLimitReached Then Exit For
        bestMatchCount = 0
        eligibleMatchCount = 0
        reservedDifferentFound = False
        stopAfterCurrentWithdrawal = False
        If i Mod 256 = 0 Then _
            AppProgress "複数取引の金額を照合しています...", i, withdrawalBundleCount
        FlowAmountSearchBounds withdrawalBundles(i).TotalAmount, absoluteTolerance, _
                               rateTolerance, lowerAmount, upperAmount
        firstMatch = LowerBoundFlowAmount(depositAmounts, depositBundleCount, lowerAmount)
        lastMatch = UpperBoundFlowAmount(depositAmounts, depositBundleCount, upperAmount)
        If firstMatch <= lastMatch Then
            For j = firstMatch To lastMatch
                matchOperations = matchOperations + 1
                If matchOperations Mod 8192 = 0 Then _
                    AppProgress "複数取引の金額を照合しています...", matchOperations, _
                                FLOW_MAX_MATCH_OPERATIONS
                If matchOperations > FLOW_MAX_MATCH_OPERATIONS Then
                    MarkFlowSearchReduced 0, False, True
                    stopAfterCurrentWithdrawal = True
                    Exit For
                End If
                differenceAmount = Abs(withdrawalBundles(i).TotalAmount - _
                                       depositBundles(depositIndexes(j)).TotalAmount)
                If AutoCandidateAmountGatePasses( _
                        withdrawalBundles(i).TotalAmount, _
                        depositBundles(depositIndexes(j)).TotalAmount, _
                        absoluteTolerance, rateTolerance) Then
                    If FlowBundlesEligible(sourceData, withdrawalBundles(i), _
                                           depositBundles(depositIndexes(j)), dayWindow) Then
                        eligibleMatchCount = eligibleMatchCount + 1
                        '探索・連鎖用リンクは適格集合を全件保持する。Top-Kはこの後の
                        '直接候補表示行だけに適用し、連鎖探索の入口を削らない。
                        AddFlowLink sourceData, withdrawalBundles, depositBundles, _
                                    i, depositIndexes(j), differenceAmount, absoluteTolerance, _
                                    links, linkCount, records, recordCount, seenRecords, False
                        If mFlowLinkGenerationStopped Or mFlowRecordLimitReached Then Exit For
                        KeepBestFlowCandidate i, linkCount, differenceAmount, _
                                              FLOW_LINK_TOP_K_PER_WITHDRAWAL, _
                                              bestWithdrawalIndexes, bestDepositIndexes, _
                                              bestDifferences, bestMatchCount
                        If FlowBundlePersonKeysAreDifferent( _
                               withdrawalBundles(i).PersonKey, _
                               depositBundles(depositIndexes(j)).PersonKey) Then _
                            ConsiderReservedFlowCandidate _
                                i, linkCount, differenceAmount, _
                                reservedWithdrawalIndex, reservedDepositIndex, _
                                reservedDifference, reservedDifferentFound
                    End If
                End If
            Next j
        End If

        '一つの出金束へ多数の入金束が一致するときも、絶対差の安定順位を保ちつつ、
        '適格な別人物リンクを最低1件予約する。人物区分によってスコアは変更しない。
        EnsureReservedFlowCandidateIsKept _
            reservedWithdrawalIndex, reservedDepositIndex, reservedDifference, _
            reservedDifferentFound, FLOW_LINK_TOP_K_PER_WITHDRAWAL, _
            bestWithdrawalIndexes, bestDepositIndexes, bestDifferences, bestMatchCount
        For j = 1 To bestMatchCount
            AddFlowGroupRecordForExistingLink withdrawalBundles, depositBundles, links, _
                                              bestDepositIndexes(j), records, recordCount, seenRecords
            If mFlowLinkGenerationStopped Or mFlowRecordLimitReached Then Exit For
        Next j
        If eligibleMatchCount > bestMatchCount Then _
            MarkFlowDisplayTruncated eligibleMatchCount - bestMatchCount
        If stopAfterCurrentWithdrawal Then
            mFlowLinkGenerationStopped = True
            Exit For
        End If
    Next i
End Sub

Private Sub BuildLongHorizonUnknownRecords( _
        ByRef sourceData As Variant, ByRef withdrawalBundles() As FlowBundle, _
        ByVal withdrawalBundleCount As Long, ByRef depositBundles() As FlowBundle, _
        ByVal depositBundleCount As Long, ByVal dayWindow As Long, _
        ByVal absoluteTolerance As Double, ByVal rateTolerance As Double, _
        ByRef links() As FlowLink, ByRef linkCount As Long, _
        ByRef records() As FlowRecord, ByRef recordCount As Long, _
        ByVal seenRecords As Object)
    Dim depositAmounts() As Double, depositIndexes() As Long
    Dim bestWithdrawalIndexes() As Long, bestDepositIndexes() As Long
    Dim bestDifferences() As Double
    Dim i As Long, j As Long, firstMatch As Long, lastMatch As Long
    Dim bestCount As Long, eligibleCount As Long, operationCount As Long
    Dim depositIndex As Long, lowerAmount As Double, upperAmount As Double
    Dim differenceAmount As Double, stopAfterCurrentWithdrawal As Boolean
    ReDim depositAmounts(1 To depositBundleCount)
    ReDim depositIndexes(1 To depositBundleCount)
    ReDim bestWithdrawalIndexes(1 To FLOW_LINK_TOP_K_PER_WITHDRAWAL)
    ReDim bestDepositIndexes(1 To FLOW_LINK_TOP_K_PER_WITHDRAWAL)
    ReDim bestDifferences(1 To FLOW_LINK_TOP_K_PER_WITHDRAWAL)
    For i = 1 To depositBundleCount
        depositAmounts(i) = depositBundles(i).TotalAmount
        depositIndexes(i) = i
    Next i
    If depositBundleCount > 1 Then _
        QuickSortFlowAmounts depositAmounts, depositIndexes, 1, depositBundleCount

    '通常の0～3日候補とは別分類。全金額範囲を走査してから表示Top-Kを選ぶため、
    '順位付けが探索母集団を削らない。上限到達時は他の分析と同じく全体をabortする。
    For i = 1 To withdrawalBundleCount
        If mFlowLinkGenerationStopped Or mFlowRecordLimitReached Then Exit For
        bestCount = 0
        eligibleCount = 0
        stopAfterCurrentWithdrawal = False
        FlowAmountSearchBounds withdrawalBundles(i).TotalAmount, absoluteTolerance, _
                               rateTolerance, lowerAmount, upperAmount
        firstMatch = LowerBoundFlowAmount(depositAmounts, depositBundleCount, lowerAmount)
        lastMatch = UpperBoundFlowAmount(depositAmounts, depositBundleCount, upperAmount)
        For j = firstMatch To lastMatch
            If j < 1 Or j > depositBundleCount Then Exit For
            operationCount = operationCount + 1
            If operationCount Mod 8192 = 0 Then _
                AppProgress "長期間隔の不明組合せを探索しています...", operationCount, _
                            FLOW_MAX_LONG_UNKNOWN_OPERATIONS
            If operationCount > FLOW_MAX_LONG_UNKNOWN_OPERATIONS Then
                MarkFlowSearchReduced 0, False, True
                stopAfterCurrentWithdrawal = True
                Exit For
            End If
            depositIndex = depositIndexes(j)
            If AutoCandidateAmountGatePasses( _
                   withdrawalBundles(i).TotalAmount, depositBundles(depositIndex).TotalAmount, _
                   absoluteTolerance, rateTolerance) Then
                If LongHorizonUnknownBundlesEligible( _
                       withdrawalBundles(i), depositBundles(depositIndex), dayWindow) Then
                    eligibleCount = eligibleCount + 1
                    differenceAmount = Abs(withdrawalBundles(i).TotalAmount - _
                                           depositBundles(depositIndex).TotalAmount)
                    KeepBestFlowCandidate i, depositIndex, differenceAmount, _
                                          FLOW_LINK_TOP_K_PER_WITHDRAWAL, _
                                          bestWithdrawalIndexes, bestDepositIndexes, _
                                          bestDifferences, bestCount
                End If
            End If
        Next j
        For j = 1 To bestCount
            AddLongHorizonUnknownLink sourceData, withdrawalBundles, depositBundles, _
                bestWithdrawalIndexes(j), bestDepositIndexes(j), bestDifferences(j), _
                absoluteTolerance, links, linkCount, records, recordCount, seenRecords
            If mFlowLinkGenerationStopped Or mFlowRecordLimitReached Then Exit For
        Next j
        If eligibleCount > bestCount Then _
            MarkFlowDisplayTruncated eligibleCount - bestCount
        If stopAfterCurrentWithdrawal Then
            mFlowLinkGenerationStopped = True
            Exit For
        End If
    Next i
End Sub

Private Function LongHorizonUnknownBundlesEligible( _
        ByRef withdrawalBundle As FlowBundle, ByRef depositBundle As FlowBundle, _
        ByVal dayWindow As Long) As Boolean
    Dim minDate As Long, maxDate As Long
    If Not AutoCandidateGroupShapePasses(withdrawalBundle.ItemCount, _
                                         depositBundle.ItemCount) Then Exit Function
    minDate = withdrawalBundle.MinDate
    If depositBundle.MinDate < minDate Then minDate = depositBundle.MinDate
    maxDate = withdrawalBundle.MaxDate
    If depositBundle.MaxDate > maxDate Then maxDate = depositBundle.MaxDate
    If maxDate - minDate <= AutoCandidateEffectiveDayWindow(dayWindow) Then Exit Function
    If withdrawalBundle.ItemCount = 1 And depositBundle.ItemCount = 1 Then
        If StrComp(withdrawalBundle.AccountList, depositBundle.AccountList, _
                   vbTextCompare) = 0 Then Exit Function
    End If
    LongHorizonUnknownBundlesEligible = True
End Function

Private Sub AddLongHorizonUnknownLink( _
        ByRef sourceData As Variant, ByRef withdrawalBundles() As FlowBundle, _
        ByRef depositBundles() As FlowBundle, ByVal withdrawalIndex As Long, _
        ByVal depositIndex As Long, ByVal differenceAmount As Double, _
        ByVal absoluteTolerance As Double, ByRef links() As FlowLink, _
        ByRef linkCount As Long, ByRef records() As FlowRecord, _
        ByRef recordCount As Long, ByVal seenRecords As Object)
    Dim score As Long, complexityPenalty As Long
    Dim ratingText As String, precisionText As String, periodText As String
    Dim minDate As Long, maxDate As Long, linkKey As String
    If linkCount >= FlowMaxLinks() Then
        MarkFlowSearchReduced 1, False, True
        mFlowLinkGenerationStopped = True
        Exit Sub
    End If
    If differenceAmount < 0.0000001 Then
        score = 45
    ElseIf differenceAmount <= absoluteTolerance + 0.0000001 Then
        score = 35
    Else
        score = 25
    End If
    score = score + 12
    complexityPenalty = withdrawalBundles(withdrawalIndex).ItemCount + _
                        depositBundles(depositIndex).ItemCount - 2
    score = score - 12 - complexityPenalty * 2
    If score < 1 Then score = 1
    If score > 100 Then score = 100
    ratingText = FlowRatingForScore(score)
    If withdrawalBundles(withdrawalIndex).HasAllTimes And _
       depositBundles(depositIndex).HasAllTimes Then
        precisionText = "全件時刻記載あり"
    ElseIf withdrawalBundles(withdrawalIndex).HasAnyTime Or _
           depositBundles(depositIndex).HasAnyTime Then
        precisionText = "一部時刻記載なし"
    Else
        precisionText = "時刻記載なし"
    End If
    minDate = withdrawalBundles(withdrawalIndex).MinDate
    If depositBundles(depositIndex).MinDate < minDate Then _
        minDate = depositBundles(depositIndex).MinDate
    maxDate = withdrawalBundles(withdrawalIndex).MaxDate
    If depositBundles(depositIndex).MaxDate > maxDate Then _
        maxDate = depositBundles(depositIndex).MaxDate
    periodText = CStr(maxDate - minDate) & "日"
    EnsureFlowLinkCapacity links, linkCount + 1
    linkCount = linkCount + 1
    linkKey = "LONG-UNKNOWN:" & withdrawalBundles(withdrawalIndex).IdList & ">" & _
              depositBundles(depositIndex).IdList
    With links(linkCount)
        .WithdrawalBundle = withdrawalIndex
        .DepositBundle = depositIndex
        .DifferenceAmount = differenceAmount
        .Score = score
        .Rating = ratingText
        .Chronology = "長期間隔・順序未確定"
        .TimePrecision = precisionText
        .PeriodText = periodText
        .KeyText = linkKey
        .IsLongTermUnknown = True
    End With
    AddFlowRecord records, recordCount, 8, CStr(linkCount), vbNullString, _
                  score, ratingText, linkKey, seenRecords
End Sub

Private Function FlowBundlesEligible(ByRef sourceData As Variant, _
                                     ByRef withdrawalBundle As FlowBundle, _
                                     ByRef depositBundle As FlowBundle, _
                                     ByVal dayWindow As Long) As Boolean
    If Not AutoCandidateGroupShapePasses(withdrawalBundle.ItemCount, _
                                         depositBundle.ItemCount) Then Exit Function
    '最も近い端点だけでなく、全出金日×全入金日が0～3暦日内であること。
    If Not AutoCandidateBundleDatePasses( _
            withdrawalBundle.MinDate, withdrawalBundle.MaxDate, _
            depositBundle.MinDate, depositBundle.MaxDate, dayWindow) Then Exit Function
    If Not AutoCandidateBundleChronologyPasses( _
            withdrawalBundle.MaxDate, withdrawalBundle.MaxStamp, _
            withdrawalBundle.HasAllTimes, depositBundle.MinDate, _
            depositBundle.MinStamp, depositBundle.HasAllTimes) Then Exit Function
    '候補内の全出金×全入金を検査し、既知時刻の逆順が1組でもあれば不採用とする。
    '時刻欠落は順序を推定せず、order_unknownとして候補を残す。
    If Not FlowFundingChronologyPasses(sourceData, withdrawalBundle.RowList, False, _
                                       depositBundle.RowList, True, vbNullString) Then _
        Exit Function
    '単一の同一口座内だけで完結する出入金は除外する。複対複で同じ口座集合を含む場合は、
    '集合内の別口座間移動があり得るため候補として残す。
    If InStr(1, withdrawalBundle.AccountList, ";", vbBinaryCompare) = 0 And _
       StrComp(withdrawalBundle.AccountList, depositBundle.AccountList, vbTextCompare) = 0 Then Exit Function
    FlowBundlesEligible = True
End Function

Private Sub AddFlowLink( _
        ByRef sourceData As Variant, ByRef withdrawalBundles() As FlowBundle, _
        ByRef depositBundles() As FlowBundle, ByVal withdrawalIndex As Long, _
        ByVal depositIndex As Long, ByVal differenceAmount As Double, _
        ByVal absoluteTolerance As Double, ByRef links() As FlowLink, _
        ByRef linkCount As Long, ByRef records() As FlowRecord, _
        ByRef recordCount As Long, ByVal seenRecords As Object, _
        Optional ByVal publishGroupRecord As Boolean = True)
    Dim score As Long, ratingText As String, chronology As String
    Dim precisionText As String, periodText As String, linkKey As String
    If linkCount >= FlowMaxLinks() Then
        MarkFlowSearchReduced 1, False, True
        mFlowLinkGenerationStopped = True
        Exit Sub
    End If
    EnsureFlowLinkCapacity links, linkCount + 1
    EvaluateFlowLink sourceData, withdrawalBundles(withdrawalIndex), depositBundles(depositIndex), _
                     differenceAmount, absoluteTolerance, score, ratingText, chronology, _
                     precisionText, periodText
    linkCount = linkCount + 1
    linkKey = withdrawalBundles(withdrawalIndex).IdList & ">" & depositBundles(depositIndex).IdList
    With links(linkCount)
        .WithdrawalBundle = withdrawalIndex
        .DepositBundle = depositIndex
        .DifferenceAmount = differenceAmount
        .Score = score
        .Rating = ratingText
        .Chronology = chronology
        .TimePrecision = precisionText
        .PeriodText = periodText
        .KeyText = linkKey
    End With
    If publishGroupRecord Then _
        AddFlowGroupRecordForExistingLink withdrawalBundles, depositBundles, links, _
                                          linkCount, records, recordCount, seenRecords
End Sub

Private Sub AddFlowGroupRecordForExistingLink( _
        ByRef withdrawalBundles() As FlowBundle, ByRef depositBundles() As FlowBundle, _
        ByRef links() As FlowLink, ByVal linkIndex As Long, _
        ByRef records() As FlowRecord, ByRef recordCount As Long, _
        ByVal seenRecords As Object)
    Dim withdrawalIndex As Long, depositIndex As Long
    If linkIndex < 1 Then Exit Sub
    withdrawalIndex = links(linkIndex).WithdrawalBundle
    depositIndex = links(linkIndex).DepositBundle
    If withdrawalBundles(withdrawalIndex).ItemCount > 1 Or _
       depositBundles(depositIndex).ItemCount > 1 Then
        AddFlowRecord records, recordCount, 1, CStr(linkIndex), vbNullString, _
                      links(linkIndex).Score, links(linkIndex).Rating, _
                      "GROUP:" & links(linkIndex).KeyText, seenRecords
    End If
End Sub

Private Sub EvaluateFlowLink( _
        ByRef sourceData As Variant, ByRef withdrawalBundle As FlowBundle, _
        ByRef depositBundle As FlowBundle, ByVal differenceAmount As Double, _
        ByVal absoluteTolerance As Double, ByRef score As Long, ByRef ratingText As String, _
        ByRef chronology As String, ByRef precisionText As String, ByRef periodText As String)
    Dim minDate As Long, maxDate As Long, dayDifference As Long
    Dim complexityPenalty As Long, scoreCeiling As Long, timeEvidencePoints As Long
    Dim personRelationship As String
    If differenceAmount < 0.0000001 Then
        score = 45
    ElseIf differenceAmount <= absoluteTolerance + 0.0000001 Then
        score = 35
    Else
        score = 25
    End If

    If withdrawalBundle.HasAllTimes And depositBundle.HasAllTimes Then
        precisionText = "全件時刻記載あり"
    ElseIf withdrawalBundle.HasAnyTime Or depositBundle.HasAnyTime Then
        precisionText = "一部時刻記載なし"
    Else
        precisionText = "時刻記載なし"
    End If
    DetermineFlowChronology withdrawalBundle, depositBundle, chronology
    If StrComp(chronology, "入金→出金", vbTextCompare) = 0 Or _
       StrComp(chronology, "時系列混在", vbTextCompare) = 0 Then _
        Err.Raise vbObjectError + 4730, "EvaluateFlowLink", _
                  "記録上の逆順を含むため自動資金フロー候補にできません。"

    minDate = withdrawalBundle.MinDate
    If depositBundle.MinDate < minDate Then minDate = depositBundle.MinDate
    maxDate = withdrawalBundle.MaxDate
    If depositBundle.MaxDate > maxDate Then maxDate = depositBundle.MaxDate
    dayDifference = maxDate - minDate
    If dayDifference = 0 Then
        periodText = "同日"
    ElseIf dayDifference = 1 Then
        periodText = "1日"
    ElseIf dayDifference <= 3 Then
        periodText = CStr(dayDifference) & "日"
    Else
        periodText = CStr(dayDifference) & "日"
    End If
    '両束の全取引に時刻記載がある場合だけ、時間的近接を根拠点にする。
    '片側の一件でも未記載なら0点とし、日付近接点で代替しない。
    timeEvidencePoints = FlowTimeEvidencePoints(withdrawalBundle, depositBundle, dayDifference)
    score = score + timeEvidencePoints

    personRelationship = FlowBundlePersonRelationship(sourceData, withdrawalBundle, depositBundle)
    '人物IDがすべて検証済みであることを共通根拠とする。同一人物内か別人物間かで
    '確度点を変えず、関係区分は表示と調査優先度にのみ使用する。
    score = score + 12

    '時系列は資金移動の根幹であり、金額一致や人物一致だけで逆順を高評価へ戻さない。
    Select Case chronology
        Case "出金→入金"
            score = score + 8
        Case "同日内順序不明"
            '時刻欠落又は同一時刻から先後を推定しない。
        Case Else
            Err.Raise vbObjectError + 4719, "EvaluateFlowLink", _
                      "未定義の順序判定です: " & chronology
    End Select

    '時刻未記載そのものによる減点・スコア上限は設けない。
    complexityPenalty = withdrawalBundle.ItemCount + depositBundle.ItemCount - 2
    If complexityPenalty > 0 Then score = score - complexityPenalty * 2
    If scoreCeiling > 0 And score > scoreCeiling Then score = scoreCeiling
    If score < 1 Then score = 1
    If score > 100 Then score = 100
    ratingText = FlowRatingForScore(score)
End Sub

Private Sub DetermineFlowChronology(ByRef withdrawalBundle As FlowBundle, _
                                    ByRef depositBundle As FlowBundle, _
                                    ByRef chronology As String)
    If withdrawalBundle.MaxDate < depositBundle.MinDate Then
        chronology = "出金→入金"
    ElseIf depositBundle.MaxDate < withdrawalBundle.MinDate Then
        chronology = "入金→出金"
    ElseIf withdrawalBundle.HasAllTimes And depositBundle.HasAllTimes Then
        If withdrawalBundle.MaxStamp < depositBundle.MinStamp - 0.000000001 Then
            chronology = "出金→入金"
        ElseIf depositBundle.MaxStamp < withdrawalBundle.MinStamp - 0.000000001 Then
            chronology = "入金→出金"
        ElseIf Abs(withdrawalBundle.MaxStamp - depositBundle.MinStamp) <= 0.000000001 Then
            '最後の出金と最初の入金が同一時刻なら、束内の他取引が厳密に
            '並んでいてもその境界だけは先後を断定できない。
            chronology = "同日内順序不明"
        Else
            chronology = "時系列混在"
        End If
    Else
        chronology = "同日内順序不明"
    End If
End Sub

Private Function FlowTimeEvidencePoints(ByRef withdrawalBundle As FlowBundle, _
                                        ByRef depositBundle As FlowBundle, _
                                        ByVal dayDifference As Long) As Long
    If Not withdrawalBundle.HasAllTimes Or Not depositBundle.HasAllTimes Then Exit Function
    If dayDifference = 0 Then
        FlowTimeEvidencePoints = 24
    ElseIf dayDifference = 1 Then
        FlowTimeEvidencePoints = 13
    ElseIf dayDifference <= 3 Then
        FlowTimeEvidencePoints = 10
    ElseIf dayDifference <= AUTO_CANDIDATE_MAX_CALENDAR_DAYS Then
        FlowTimeEvidencePoints = 6
    End If
End Function

Private Function FlowBundlePersonRelationship(ByRef sourceData As Variant, _
                                              ByRef firstBundle As FlowBundle, _
                                              ByRef secondBundle As FlowBundle) As String
    Dim firstIDs As Object, secondIDs As Object
    If Len(firstBundle.PersonKey) > 0 And Len(secondBundle.PersonKey) > 0 Then
        If FlowBundlePersonKeysAreDifferent( _
               firstBundle.PersonKey, secondBundle.PersonKey) Then
            FlowBundlePersonRelationship = "別人物間"
        Else
            FlowBundlePersonRelationship = "同一人物内"
        End If
        Exit Function
    End If
    Set firstIDs = CreateObject("Scripting.Dictionary")
    Set secondIDs = CreateObject("Scripting.Dictionary")
    firstIDs.CompareMode = vbTextCompare
    secondIDs.CompareMode = vbTextCompare
    AddRequiredFlowPersonIDs sourceData, firstBundle.RowList, firstIDs, _
                             "出金側取引束"
    AddRequiredFlowPersonIDs sourceData, secondBundle.RowList, secondIDs, _
                             "入金側取引束"
    If firstIDs.Count = 1 And secondIDs.Count = 1 And _
       FlowPersonIDSetsEqual(firstIDs, secondIDs) Then
        FlowBundlePersonRelationship = "同一人物内"
    Else
        FlowBundlePersonRelationship = "別人物間"
    End If
End Function

Private Function FlowBundlePersonKeysAreDifferent( _
        ByVal firstPersonKey As String, ByVal secondPersonKey As String) As Boolean
    If Len(firstPersonKey) = 0 Or Len(secondPersonKey) = 0 Then _
        Err.Raise vbObjectError + 4721, "FlowBundlePersonKeysAreDifferent", _
                  "資金フロー取引束の人物ID索引がありません。"
    If StrComp(firstPersonKey, FLOW_MULTI_PERSON_KEY, vbBinaryCompare) = 0 Or _
       StrComp(secondPersonKey, FLOW_MULTI_PERSON_KEY, vbBinaryCompare) = 0 Then
        FlowBundlePersonKeysAreDifferent = True
    Else
        FlowBundlePersonKeysAreDifferent = _
            (StrComp(firstPersonKey, secondPersonKey, vbTextCompare) <> 0)
    End If
End Function

Private Function RequiredFlowPersonIDForRow( _
        ByRef sourceData As Variant, ByVal sourceRow As Long, _
        ByVal contextText As String) As String
    Dim personID As String
    personID = CellText(sourceData(sourceRow, WORK_TX_COL_PERSON_ID))
    If Len(personID) = 0 Then _
        Err.Raise vbObjectError + 4628, "RequiredFlowPersonIDForRow", _
                  contextText & "の人物IDがありません（取引配列行=" & _
                  CStr(sourceRow) & "）。氏名では代替しません。"
    If Not IsInternalIdValue(personID, "P") Then _
        Err.Raise vbObjectError + 4629, "RequiredFlowPersonIDForRow", _
                  contextText & "の人物ID形式が不正です（取引配列行=" & _
                  CStr(sourceRow) & " / 人物ID=" & personID & "）。"
    RequiredFlowPersonIDForRow = personID
End Function

Private Sub AddRequiredFlowPersonIDs(ByRef sourceData As Variant, ByVal rowList As String, _
                                     ByVal personIDs As Object, ByVal contextText As String)
    Dim rowParts As Variant, rowItem As Variant, sourceRow As Long, personID As String
    If Len(rowList) = 0 Then _
        Err.Raise vbObjectError + 4628, "AddRequiredFlowPersonIDs", _
                  contextText & "に取引がありません。"
    rowParts = Split(rowList, ";")
    For Each rowItem In rowParts
        sourceRow = CLng(rowItem)
        personID = RequiredFlowPersonIDForRow(sourceData, sourceRow, contextText)
        If Not personIDs.Exists(personID) Then personIDs.Add personID, True
    Next rowItem
End Sub

Private Function FlowPersonIDSetsEqual(ByVal firstIDs As Object, _
                                        ByVal secondIDs As Object) As Boolean
    Dim personID As Variant
    If firstIDs.Count <> secondIDs.Count Then Exit Function
    For Each personID In firstIDs.Keys
        If Not secondIDs.Exists(CStr(personID)) Then Exit Function
    Next personID
    FlowPersonIDSetsEqual = True
End Function

Private Sub EnsureFlowLinkCapacity(ByRef links() As FlowLink, ByVal requiredCount As Long)
    Dim newCapacity As Long
    If requiredCount <= 1 Then
        newCapacity = 1024
        If mFlowCapacityActive Then
            RequireFlowArrayCapacity mFlowWithdrawalBundleCapacity, _
                                     mFlowDepositBundleCapacity, newCapacity, _
                                     mFlowRecordCapacity
            mFlowLinkCapacity = newCapacity
        End If
        ReDim links(1 To newCapacity)
    ElseIf requiredCount > UBound(links) Then
        newCapacity = UBound(links) * 2
        If newCapacity < requiredCount Then newCapacity = requiredCount
        If newCapacity > FlowMaxLinks() Then newCapacity = FlowMaxLinks()
        If mFlowCapacityActive Then
            RequireFlowArrayCapacity mFlowWithdrawalBundleCapacity, _
                                     mFlowDepositBundleCapacity, newCapacity, _
                                     mFlowRecordCapacity
            mFlowLinkCapacity = newCapacity
        End If
        ReDim Preserve links(1 To newCapacity)
    End If
End Sub

Private Sub AddFlowRecord(ByRef records() As FlowRecord, ByRef recordCount As Long, _
                          ByVal kindCode As Long, ByVal linkList As String, _
                          ByVal extraWithdrawalRows As String, ByVal score As Long, _
                          ByVal ratingText As String, ByVal keyText As String, _
                          ByVal seenRecords As Object)
    If seenRecords.Exists(keyText) Then Exit Sub
    If recordCount >= FlowMaxRecords() Then
        MarkFlowSearchReduced 1, False, True
        mFlowRecordLimitReached = True
        Exit Sub
    End If
    EnsureFlowRecordCapacity records, recordCount + 1
    recordCount = recordCount + 1
    With records(recordCount)
        .KindCode = kindCode
        .LinkList = linkList
        .ExtraWithdrawalRows = extraWithdrawalRows
        .Score = score
        .Rating = ratingText
        .KeyText = keyText
    End With
    seenRecords.Add keyText, recordCount
End Sub

Private Sub EnsureFlowRecordCapacity(ByRef records() As FlowRecord, ByVal requiredCount As Long)
    Dim newCapacity As Long
    If requiredCount <= 1 Then
        newCapacity = 1024
        If mFlowCapacityActive Then
            RequireFlowArrayCapacity mFlowWithdrawalBundleCapacity, _
                                     mFlowDepositBundleCapacity, mFlowLinkCapacity, _
                                     newCapacity
            mFlowRecordCapacity = newCapacity
        End If
        ReDim records(1 To newCapacity)
    ElseIf requiredCount > UBound(records) Then
        newCapacity = UBound(records) * 2
        If newCapacity < requiredCount Then newCapacity = requiredCount
        If newCapacity > FlowMaxRecords() Then newCapacity = FlowMaxRecords()
        If mFlowCapacityActive Then
            RequireFlowArrayCapacity mFlowWithdrawalBundleCapacity, _
                                     mFlowDepositBundleCapacity, mFlowLinkCapacity, _
                                     newCapacity
            mFlowRecordCapacity = newCapacity
        End If
        ReDim Preserve records(1 To newCapacity)
    End If
End Sub

Private Function FlowRatingForScore(ByVal score As Long) As String
    If score >= 80 Then
        FlowRatingForScore = "高"
    ElseIf score >= 60 Then
        FlowRatingForScore = "中"
    Else
        FlowRatingForScore = "低"
    End If
End Function

Private Sub FlowAmountSearchBounds(ByVal amountValue As Double, _
                                   ByVal absoluteTolerance As Double, _
                                   ByVal rateTolerance As Double, _
                                   ByRef lowerAmount As Double, ByRef upperAmount As Double)
    AutoCandidateAmountSearchBounds amountValue, lowerAmount, upperAmount, _
                                    absoluteTolerance, rateTolerance
End Sub

Private Function LowerBoundFlowAmount(ByRef amounts() As Double, ByVal itemCount As Long, _
                                      ByVal targetValue As Double) As Long
    Dim low As Long, high As Long, mid As Long
    low = 1: high = itemCount + 1
    Do While low < high
        mid = low + (high - low) \ 2
        If mid <= itemCount And amounts(mid) < targetValue Then low = mid + 1 Else high = mid
    Loop
    LowerBoundFlowAmount = low
End Function

Private Function UpperBoundFlowAmount(ByRef amounts() As Double, ByVal itemCount As Long, _
                                      ByVal targetValue As Double) As Long
    Dim low As Long, high As Long, mid As Long
    low = 1: high = itemCount + 1
    Do While low < high
        mid = low + (high - low) \ 2
        If mid <= itemCount And amounts(mid) <= targetValue Then low = mid + 1 Else high = mid
    Loop
    UpperBoundFlowAmount = low - 1
End Function

Private Sub QuickSortFlowAmounts(ByRef amounts() As Double, ByRef indexes() As Long, _
                                 ByVal firstIndex As Long, ByVal lastIndex As Long)
    Dim low As Long, high As Long, pivot As Double
    Dim tempAmount As Double, tempIndex As Long
    low = firstIndex: high = lastIndex
    pivot = amounts((firstIndex + lastIndex) \ 2)
    Do While low <= high
        Do While amounts(low) < pivot
            low = low + 1
        Loop
        Do While amounts(high) > pivot
            high = high - 1
        Loop
        If low <= high Then
            tempAmount = amounts(low): amounts(low) = amounts(high): amounts(high) = tempAmount
            tempIndex = indexes(low): indexes(low) = indexes(high): indexes(high) = tempIndex
            low = low + 1: high = high - 1
        End If
    Loop
    If firstIndex < high Then QuickSortFlowAmounts amounts, indexes, firstIndex, high
    If low < lastIndex Then QuickSortFlowAmounts amounts, indexes, low, lastIndex
End Sub

Private Sub BuildFlowChains( _
        ByRef sourceData As Variant, ByRef withdrawalBundles() As FlowBundle, _
        ByVal withdrawalBundleCount As Long, _
        ByRef depositBundles() As FlowBundle, ByRef links() As FlowLink, _
        ByVal linkCount As Long, ByVal dayWindow As Long, _
        ByVal absoluteTolerance As Double, ByVal rateTolerance As Double, _
        ByRef records() As FlowRecord, ByRef recordCount As Long, ByVal seenRecords As Object)
    Dim adjacency As Object, withdrawalByAccount As Object, terminalCandidateSeen As Object
    Dim predecessor() As Long
    Dim path(1 To FLOW_MAX_CHAIN_LEGS) As Long
    Dim usedRows As Object
    Dim i As Long, terminalOperationCount As Long
    Set adjacency = CreateObject("Scripting.Dictionary")
    adjacency.CompareMode = vbTextCompare
    Set terminalCandidateSeen = CreateObject("Scripting.Dictionary")
    terminalCandidateSeen.CompareMode = vbTextCompare
    ReDim predecessor(1 To linkCount)
    BuildFlowAdjacency sourceData, withdrawalBundles, depositBundles, links, linkCount, _
                       dayWindow, absoluteTolerance, rateTolerance, adjacency, predecessor
    If mFlowChainSearchStopped Or mFlowRecordLimitReached Then Exit Sub
    Set withdrawalByAccount = BuildWithdrawalBundleAccountIndex(withdrawalBundles, withdrawalBundleCount)

    For i = 1 To linkCount
        If mFlowChainSearchStopped Or mFlowRecordLimitReached Then Exit For
        If i Mod 512 = 0 Then AppProgress "多段資金フローを接続しています...", i, linkCount
        If FlowLinkCanCarryForward(links(i)) And predecessor(i) = 0 Then
            Set usedRows = CreateObject("Scripting.Dictionary")
            usedRows.CompareMode = vbTextCompare
            path(1) = i
            AddLinkRowsToDictionary withdrawalBundles, depositBundles, links(i), usedRows
            ExploreFlowPath sourceData, withdrawalBundles, depositBundles, links, adjacency, _
                            withdrawalByAccount, dayWindow, absoluteTolerance, rateTolerance, _
                            path, 1, usedRows, terminalCandidateSeen, terminalOperationCount, _
                            records, recordCount, seenRecords
        End If
    Next i
    '到達済みというだけでは再探索を省かない。上限4件の文脈では、前半から
    '到達した時に延長不能でも、そのリンクを起点にすれば有効な後半経路があり得る。
    '根リンクは上で探索済みなので、ここでは先行リンクを持つ全リンクを一度ずつ起点にする。
    For i = 1 To linkCount
        If mFlowChainSearchStopped Or mFlowRecordLimitReached Then Exit For
        If FlowLinkCanCarryForward(links(i)) And predecessor(i) > 0 Then
            Set usedRows = CreateObject("Scripting.Dictionary")
            usedRows.CompareMode = vbTextCompare
            path(1) = i
            AddLinkRowsToDictionary withdrawalBundles, depositBundles, links(i), usedRows
            ExploreFlowPath sourceData, withdrawalBundles, depositBundles, links, adjacency, _
                            withdrawalByAccount, dayWindow, absoluteTolerance, rateTolerance, _
                            path, 1, usedRows, terminalCandidateSeen, terminalOperationCount, _
                            records, recordCount, seenRecords
        End If
    Next i
End Sub

'通常リンクは「出金束と入金束」の照合として保持するため、単発の入金先行候補を
'そのまま多段へ接続すると同じ出金を二度使ってしまう。ここでは、前段入金束を
'独立の起点として既存の出金起点経路へ付加し、入金→出金→入金以降を明示的に作る。
Private Sub BuildDepositOriginFlowRecords( _
        ByRef sourceData As Variant, ByRef withdrawalBundles() As FlowBundle, _
        ByRef depositBundles() As FlowBundle, ByVal depositBundleCount As Long, _
        ByRef links() As FlowLink, ByVal linkCount As Long, ByVal dayWindow As Long, _
        ByVal absoluteTolerance As Double, ByVal rateTolerance As Double, _
        ByRef records() As FlowRecord, ByRef recordCount As Long, ByVal seenRecords As Object)
    Dim depositsByAccount As Object, candidateSeen As Object, usedRows As Object
    Dim baseRecordCount As Long, operationCount As Long
    Dim i As Long, firstLinkIndex As Long, originKind As Long
    If depositBundleCount <= 0 Or linkCount <= 0 Then Exit Sub
    If mFlowRecordLimitReached Then Exit Sub
    Set depositsByAccount = BuildDepositBundleAccountIndex(depositBundles, depositBundleCount)
    Set candidateSeen = CreateObject("Scripting.Dictionary")
    candidateSeen.CompareMode = vbTextCompare
    Set usedRows = CreateObject("Scripting.Dictionary")
    usedRows.CompareMode = vbTextCompare
    baseRecordCount = recordCount

    '1対1の出金→入金リンクにも前段入金を付ける。これにより、全て単発取引でも
    '入金→出金→入金を候補化できる。
    For i = 1 To linkCount
        If mFlowOriginSearchStopped Or mFlowRecordLimitReached Then Exit For
        If i Mod 512 = 0 Then AppProgress "入金起点の連鎖を探索しています...", i, linkCount
        If FlowLinkCanCarryForward(links(i)) Then
            usedRows.RemoveAll
            AddFlowRowsToDictionary withdrawalBundles(links(i).WithdrawalBundle).RowList, usedRows
            AddFlowRowsToDictionary depositBundles(links(i).DepositBundle).RowList, usedRows
            AddOriginCandidatesForPath sourceData, withdrawalBundles, depositBundles, links, _
                CStr(i), vbNullString, 5, links(i).Score - 2, "LINK:" & links(i).KeyText, _
                depositsByAccount, candidateSeen, usedRows, dayWindow, absoluteTolerance, _
                rateTolerance, operationCount, records, recordCount, seenRecords
        End If
    Next i

    '既に作成済みの長い連鎖・終端出金へも同じ方法で起点入金を付加する。
    '上のループで追加したレコードを再帰的に増殖させないよう、開始時件数だけを見る。
    For i = 1 To baseRecordCount
        If mFlowOriginSearchStopped Or mFlowRecordLimitReached Then Exit For
        firstLinkIndex = FirstFlowLinkIndex(records(i).LinkList)
        'VBAのAndは短絡評価されない。0を配列添字へ渡さないよう段階判定する。
        If firstLinkIndex > 0 Then
            If FlowLinkCanCarryForward(links(firstLinkIndex)) Then
                If FlowListItemCount(records(i).LinkList) > 1 Or _
                   Len(records(i).ExtraWithdrawalRows) > 0 Then
                    usedRows.RemoveAll
                    CollectFlowRecordRows withdrawalBundles, depositBundles, links, records(i), usedRows
                    Select Case records(i).KindCode
                        Case 3: originKind = 6
                        Case 4: originKind = 7
                        Case Else: originKind = 5
                    End Select
                    AddOriginCandidatesForPath sourceData, withdrawalBundles, depositBundles, links, _
                        records(i).LinkList, records(i).ExtraWithdrawalRows, originKind, _
                        records(i).Score - 2, records(i).KeyText, depositsByAccount, candidateSeen, _
                        usedRows, dayWindow, absoluteTolerance, rateTolerance, operationCount, _
                        records, recordCount, seenRecords
                End If
            End If
        End If
    Next i
End Sub

Private Sub AddOriginCandidatesForPath( _
        ByRef sourceData As Variant, ByRef withdrawalBundles() As FlowBundle, _
        ByRef depositBundles() As FlowBundle, ByRef links() As FlowLink, _
        ByVal linkList As String, ByVal extraWithdrawalRows As String, ByVal originKind As Long, _
        ByVal baseScore As Long, ByVal baseKey As String, ByVal depositsByAccount As Object, _
        ByVal candidateSeen As Object, ByVal usedRows As Object, ByVal dayWindow As Long, _
        ByVal absoluteTolerance As Double, ByVal rateTolerance As Double, _
        ByRef operationCount As Long, ByRef records() As FlowRecord, ByRef recordCount As Long, _
        ByVal seenRecords As Object)
    Dim firstLinkIndex As Long, firstWithdrawalIndex As Long
    Dim accountParts As Variant, accountItem As Variant
    Dim bundleItems As Collection, bundleItem As Variant, originIndex As Long
    Dim keyText As String, score As Long
    firstLinkIndex = FirstFlowLinkIndex(linkList)
    If firstLinkIndex <= 0 Then Exit Sub
    firstWithdrawalIndex = links(firstLinkIndex).WithdrawalBundle
    candidateSeen.RemoveAll
    accountParts = Split(withdrawalBundles(firstWithdrawalIndex).AccountList, ";")
    For Each accountItem In accountParts
        If depositsByAccount.Exists(CStr(accountItem)) Then
            Set bundleItems = depositsByAccount(CStr(accountItem))
            For Each bundleItem In bundleItems
                originIndex = CLng(bundleItem)
                If Not candidateSeen.Exists(CStr(originIndex)) Then
                    candidateSeen.Add CStr(originIndex), True
                    operationCount = operationCount + 1
                    If operationCount Mod 8192 = 0 Then _
                        AppProgress "入金起点の連鎖候補を照合しています...", operationCount, _
                                    FLOW_MAX_ORIGIN_OPERATIONS
                    If operationCount > FLOW_MAX_ORIGIN_OPERATIONS Then
                        MarkFlowSearchReduced 0, False, True
                        mFlowOriginSearchStopped = True
                        Exit Sub
                    End If
                    If FlowRowListsFitAutomaticTransactionLimit( _
                            usedRows, depositBundles(originIndex).RowList, vbNullString) Then
                        If OriginBundlesCompatible(sourceData, depositBundles(originIndex), _
                                                   withdrawalBundles(firstWithdrawalIndex), dayWindow, _
                                                   absoluteTolerance, rateTolerance) Then
                            score = baseScore
                            If score < 1 Then score = 1
                            If score > 100 Then score = 100
                            keyText = "ORIGIN:" & depositBundles(originIndex).IdList & "|" & baseKey
                            AddOriginFlowRecord records, recordCount, originKind, linkList, _
                                                extraWithdrawalRows, originIndex, score, _
                                                FlowRatingForScore(score), keyText, seenRecords
                        End If
                    End If
                End If
            Next bundleItem
        End If
    Next accountItem
End Sub

Private Sub AddOriginFlowRecord(ByRef records() As FlowRecord, ByRef recordCount As Long, _
                                ByVal kindCode As Long, ByVal linkList As String, _
                                ByVal extraWithdrawalRows As String, ByVal originDepositBundle As Long, _
                                ByVal score As Long, ByVal ratingText As String, ByVal keyText As String, _
                                ByVal seenRecords As Object)
    Dim previousCount As Long
    previousCount = recordCount
    AddFlowRecord records, recordCount, kindCode, linkList, extraWithdrawalRows, score, _
                  ratingText, keyText, seenRecords
    If recordCount > previousCount Then records(recordCount).OriginDepositBundle = originDepositBundle
End Sub

Private Function FirstFlowLinkIndex(ByVal linkList As String) As Long
    Dim parts As Variant
    If Len(linkList) = 0 Then Exit Function
    parts = Split(linkList, ";")
    If IsNumeric(parts(LBound(parts))) Then FirstFlowLinkIndex = CLng(parts(LBound(parts)))
End Function

Private Function OriginBundlesCompatible(ByRef sourceData As Variant, _
                                         ByRef depositBundle As FlowBundle, _
                                         ByRef withdrawalBundle As FlowBundle, _
                                         ByVal dayWindow As Long, _
                                         ByVal absoluteTolerance As Double, _
                                         ByVal rateTolerance As Double) As Boolean
    '起点額は最初の出金段階と同じ口座集合だけで構成する。複数口座を含む束の
    '一部だけが一致する場合は、無関係な入金まで起点額へ含めるため採用しない。
    If StrComp(depositBundle.AccountList, withdrawalBundle.AccountList, vbTextCompare) <> 0 Then _
        Exit Function
    'S44=A。総額だけで異なる口座を相殺せず、同一口座ごとの金額・形状・
    '全日付条件がすべて合格した場合だけ起点として接続する。
    OriginBundlesCompatible = FlowBoundaryAccountsCompatible( _
        sourceData, depositBundle.RowList, withdrawalBundle.RowList, _
        depositBundle.AccountList, dayWindow, absoluteTolerance, rateTolerance)
End Function

Private Sub BuildFlowAdjacency( _
        ByRef sourceData As Variant, ByRef withdrawalBundles() As FlowBundle, _
        ByRef depositBundles() As FlowBundle, ByRef links() As FlowLink, _
        ByVal linkCount As Long, ByVal dayWindow As Long, _
        ByVal absoluteTolerance As Double, ByVal rateTolerance As Double, _
        ByVal adjacency As Object, ByRef predecessor() As Long)
    Dim sourceLinksByAccount As Object, candidateSeen As Object
    Dim accountParts As Variant, accountItem As Variant
    Dim linkList As Collection, nextList As Collection
    Dim candidateItem As Variant
    Dim i As Long, nextIndex As Long, operationCount As Long
    Set sourceLinksByAccount = CreateObject("Scripting.Dictionary")
    sourceLinksByAccount.CompareMode = vbTextCompare
    Set candidateSeen = CreateObject("Scripting.Dictionary")
    candidateSeen.CompareMode = vbTextCompare

    For i = 1 To linkCount
        If FlowLinkCanCarryForward(links(i)) Then
            accountParts = Split(withdrawalBundles(links(i).WithdrawalBundle).AccountList, ";")
            For Each accountItem In accountParts
                If Not sourceLinksByAccount.Exists(CStr(accountItem)) Then
                    Set linkList = New Collection
                    sourceLinksByAccount.Add CStr(accountItem), linkList
                Else
                    Set linkList = sourceLinksByAccount(CStr(accountItem))
                End If
                linkList.Add i
            Next accountItem
        End If
    Next i

    For i = 1 To linkCount
        If FlowLinkCanCarryForward(links(i)) Then
            candidateSeen.RemoveAll
            accountParts = Split(depositBundles(links(i).DepositBundle).AccountList, ";")
            For Each accountItem In accountParts
                If sourceLinksByAccount.Exists(CStr(accountItem)) Then
                    Set linkList = sourceLinksByAccount(CStr(accountItem))
                    For Each candidateItem In linkList
                        nextIndex = CLng(candidateItem)
                        If nextIndex <> i And Not candidateSeen.Exists(CStr(nextIndex)) Then
                            candidateSeen.Add CStr(nextIndex), True
                            operationCount = operationCount + 1
                            If operationCount Mod 8192 = 0 Then _
                                AppProgress "多段資金フローの接続を照合しています...", operationCount, _
                                            FLOW_MAX_ADJACENCY_OPERATIONS
                            If operationCount > FLOW_MAX_ADJACENCY_OPERATIONS Then
                                MarkFlowSearchReduced 0, False, True
                                mFlowChainSearchStopped = True
                                Exit Sub
                            End If
                            If CanFollowFlowLink(sourceData, withdrawalBundles, depositBundles, _
                                                 links(i), links(nextIndex), dayWindow, _
                                                 absoluteTolerance, rateTolerance) Then
                                If Not adjacency.Exists(CStr(i)) Then
                                    Set nextList = New Collection
                                    adjacency.Add CStr(i), nextList
                                Else
                                    Set nextList = adjacency(CStr(i))
                                End If
                                nextList.Add nextIndex
                                predecessor(nextIndex) = predecessor(nextIndex) + 1
                            End If
                        End If
                    Next candidateItem
                End If
            Next accountItem
        End If
    Next i
End Sub

Private Function CanFollowFlowLink( _
        ByRef sourceData As Variant, ByRef withdrawalBundles() As FlowBundle, _
        ByRef depositBundles() As FlowBundle, ByRef firstLink As FlowLink, _
        ByRef secondLink As FlowLink, ByVal dayWindow As Long, _
        ByVal absoluteTolerance As Double, ByVal rateTolerance As Double) As Boolean
    If Not FlowLinkCanCarryForward(firstLink) Or _
       Not FlowLinkCanCarryForward(secondLink) Then Exit Function
    If FlowListsOverlap(withdrawalBundles(firstLink.WithdrawalBundle).RowList, _
                        withdrawalBundles(secondLink.WithdrawalBundle).RowList) Then Exit Function
    If FlowListsOverlap(withdrawalBundles(firstLink.WithdrawalBundle).RowList, _
                        depositBundles(secondLink.DepositBundle).RowList) Then Exit Function
    If FlowListsOverlap(depositBundles(firstLink.DepositBundle).RowList, _
                        withdrawalBundles(secondLink.WithdrawalBundle).RowList) Then Exit Function
    If FlowListsOverlap(depositBundles(firstLink.DepositBundle).RowList, _
                        depositBundles(secondLink.DepositBundle).RowList) Then Exit Function
    CanFollowFlowLink = RelayBundlesCompatible( _
        sourceData, depositBundles(firstLink.DepositBundle), _
        withdrawalBundles(secondLink.WithdrawalBundle), dayWindow, _
        absoluteTolerance, rateTolerance)
End Function

Private Function RelayBundlesCompatible( _
        ByRef sourceData As Variant, ByRef depositBundle As FlowBundle, _
        ByRef withdrawalBundle As FlowBundle, ByVal dayWindow As Long, _
        ByVal absoluteTolerance As Double, ByVal rateTolerance As Double) As Boolean
    Dim commonAccounts As String
    '後続出金束へ先行入金に存在しない口座を混ぜると、共通口座の一致だけで
    '無関係な資金を同じ経路へ取り込める。後続側の全口座に先行入金を必須とする。
    If Not FlowListIsSubset(withdrawalBundle.AccountList, _
                            depositBundle.AccountList) Then Exit Function
    commonAccounts = FlowListIntersection(depositBundle.AccountList, withdrawalBundle.AccountList)
    If Len(commonAccounts) = 0 Then Exit Function
    'S44=A。共通口座の合計だけを比較すると、口座Aの過大額と口座Bの過小額が
    '相殺される。各共通口座を独立に金額AND・許可形状・全日付で検査する。
    RelayBundlesCompatible = FlowBoundaryAccountsCompatible( _
        sourceData, depositBundle.RowList, withdrawalBundle.RowList, commonAccounts, _
        dayWindow, absoluteTolerance, rateTolerance)
End Function

Private Function FlowBoundaryAccountsCompatible( _
        ByRef sourceData As Variant, ByVal priorDepositRows As String, _
        ByVal followingWithdrawalRows As String, ByVal accountList As String, _
        ByVal dayWindow As Long, ByVal absoluteTolerance As Double, _
        ByVal rateTolerance As Double) As Boolean
    Dim accountParts As Variant, accountItem As Variant, accountID As String
    If Len(accountList) = 0 Or Len(priorDepositRows) = 0 Or _
       Len(followingWithdrawalRows) = 0 Then Exit Function
    accountParts = Split(accountList, ";")
    For Each accountItem In accountParts
        accountID = CellText(accountItem)
        If Len(accountID) = 0 Then Exit Function
        If Not FlowBoundaryAccountCompatible( _
                sourceData, priorDepositRows, followingWithdrawalRows, accountID, _
                dayWindow, absoluteTolerance, rateTolerance) Then Exit Function
    Next accountItem
    FlowBoundaryAccountsCompatible = True
End Function

Private Function FlowBoundaryAccountCompatible( _
        ByRef sourceData As Variant, ByVal priorDepositRows As String, _
        ByVal followingWithdrawalRows As String, ByVal accountID As String, _
        ByVal dayWindow As Long, ByVal absoluteTolerance As Double, _
        ByVal rateTolerance As Double) As Boolean
    Dim depositRows As Variant, withdrawalRows As Variant
    Dim rowItem As Variant, sourceRow As Long, transactionDate As Long
    Dim depositCount As Long, withdrawalCount As Long
    Dim depositAmount As Double, withdrawalAmount As Double
    Dim depositMinDate As Long, depositMaxDate As Long
    Dim withdrawalMinDate As Long, withdrawalMaxDate As Long

    depositRows = Split(priorDepositRows, ";")
    For Each rowItem In depositRows
        sourceRow = CLng(rowItem)
        If StrComp(CellText(sourceData(sourceRow, WORK_TX_COL_ACCOUNT_ID)), _
                   accountID, vbTextCompare) = 0 Then
            depositCount = depositCount + 1
            depositAmount = depositAmount + CDbl(sourceData(sourceRow, OUT_COL_DEPOSIT))
            transactionDate = CLng(VBA.DateValue(CDate(sourceData(sourceRow, OUT_COL_DATE))))
            If depositCount = 1 Or transactionDate < depositMinDate Then _
                depositMinDate = transactionDate
            If depositCount = 1 Or transactionDate > depositMaxDate Then _
                depositMaxDate = transactionDate
        End If
    Next rowItem

    withdrawalRows = Split(followingWithdrawalRows, ";")
    For Each rowItem In withdrawalRows
        sourceRow = CLng(rowItem)
        If StrComp(CellText(sourceData(sourceRow, WORK_TX_COL_ACCOUNT_ID)), _
                   accountID, vbTextCompare) = 0 Then
            withdrawalCount = withdrawalCount + 1
            withdrawalAmount = withdrawalAmount + _
                               CDbl(sourceData(sourceRow, OUT_COL_WITHDRAW))
            transactionDate = CLng(VBA.DateValue(CDate(sourceData(sourceRow, OUT_COL_DATE))))
            If withdrawalCount = 1 Or transactionDate < withdrawalMinDate Then _
                withdrawalMinDate = transactionDate
            If withdrawalCount = 1 Or transactionDate > withdrawalMaxDate Then _
                withdrawalMaxDate = transactionDate
        End If
    Next rowItem

    If Not AutoCandidateGroupShapePasses(withdrawalCount, depositCount) Then Exit Function
    If Not AutoCandidateAmountGatePasses(withdrawalAmount, depositAmount, _
                                         absoluteTolerance, rateTolerance) Then Exit Function
    '境界では入金が先、出金が後。AutoCandidateBundleDatePassesの第1束を
    '先行入金、第2束を後続出金として渡し、全日付の直積を0～3日に固定する。
    If Not AutoCandidateBundleDatePasses( _
            depositMinDate, depositMaxDate, withdrawalMinDate, withdrawalMaxDate, _
            dayWindow) Then Exit Function
    If Not FlowFundingChronologyPasses(sourceData, priorDepositRows, True, _
                                       followingWithdrawalRows, False, accountID) Then _
        Exit Function
    If Not HasPlausibleRelayOrder(sourceData, priorDepositRows, _
                                  followingWithdrawalRows, accountID, dayWindow) Then Exit Function
    FlowBoundaryAccountCompatible = True
End Function

'source側×target側の全既知時刻を検査し、targetが1件でもsourceより先なら不採用。
'時刻欠落は順序だけを不明扱いにし、金額・口座・行構造の検証は最後まで続ける。
Private Function FlowFundingChronologyPasses( _
        ByRef sourceData As Variant, ByVal sourceRowsText As String, _
        ByVal sourceUsesDeposit As Boolean, ByVal targetRowsText As String, _
        ByVal targetUsesDeposit As Boolean, ByVal requiredAccountID As String) As Boolean
    Const TIME_EPSILON As Double = 0.000000001
    Dim sourceParts As Variant, targetParts As Variant
    Dim sourceStamps() As Double, targetStamps() As Double
    Dim item As Variant, sourceRow As Long, targetRow As Long
    Dim sourceCount As Long, targetCount As Long, i As Long, j As Long
    Dim sourceKnownTimeCount As Long, targetKnownTimeCount As Long
    Dim timeValue As Double, accountID As String
    Dim sourceAmount As Double, targetAmount As Double
    If Len(sourceRowsText) = 0 Or Len(targetRowsText) = 0 Then Exit Function
    sourceParts = Split(sourceRowsText, ";")
    targetParts = Split(targetRowsText, ";")
    ReDim sourceStamps(1 To UBound(sourceParts) - LBound(sourceParts) + 1)
    ReDim targetStamps(1 To UBound(targetParts) - LBound(targetParts) + 1)
    For Each item In sourceParts
        If Not IsNumeric(item) Then Exit Function
        sourceRow = CLng(item)
        accountID = CellText(sourceData(sourceRow, WORK_TX_COL_ACCOUNT_ID))
        If Len(requiredAccountID) = 0 Or _
           StrComp(accountID, requiredAccountID, vbTextCompare) = 0 Then
            If sourceUsesDeposit Then
                sourceAmount = CDbl(sourceData(sourceRow, OUT_COL_DEPOSIT))
            Else
                sourceAmount = CDbl(sourceData(sourceRow, OUT_COL_WITHDRAW))
            End If
            If sourceAmount <= 0# Then Exit Function
            sourceCount = sourceCount + 1
            If TryGetFlowTime(sourceData(sourceRow, OUT_COL_TIME), timeValue) Then
                sourceKnownTimeCount = sourceKnownTimeCount + 1
                sourceStamps(sourceKnownTimeCount) = _
                    CDbl(VBA.DateValue(CDate(sourceData(sourceRow, OUT_COL_DATE)))) + timeValue
            End If
        End If
    Next item
    For Each item In targetParts
        If Not IsNumeric(item) Then Exit Function
        targetRow = CLng(item)
        accountID = CellText(sourceData(targetRow, WORK_TX_COL_ACCOUNT_ID))
        If Len(requiredAccountID) = 0 Or _
           StrComp(accountID, requiredAccountID, vbTextCompare) = 0 Then
            If targetUsesDeposit Then
                targetAmount = CDbl(sourceData(targetRow, OUT_COL_DEPOSIT))
            Else
                targetAmount = CDbl(sourceData(targetRow, OUT_COL_WITHDRAW))
            End If
            If targetAmount <= 0# Then Exit Function
            targetCount = targetCount + 1
            If TryGetFlowTime(sourceData(targetRow, OUT_COL_TIME), timeValue) Then
                targetKnownTimeCount = targetKnownTimeCount + 1
                targetStamps(targetKnownTimeCount) = _
                    CDbl(VBA.DateValue(CDate(sourceData(targetRow, OUT_COL_DATE)))) + timeValue
            End If
        End If
    Next item
    If sourceCount = 0 Or targetCount = 0 Then Exit Function
    '時刻欠落ペアだけを順序不明として残す。別の既知時刻ペアに逆順があれば、
    '束内の一部欠落で隠さず必ず不採用とする。
    For i = 1 To sourceKnownTimeCount
        For j = 1 To targetKnownTimeCount
            If targetStamps(j) + TIME_EPSILON < sourceStamps(i) Then Exit Function
        Next j
    Next i
    FlowFundingChronologyPasses = True
End Function

Private Function HasPlausibleRelayOrder( _
        ByRef sourceData As Variant, ByVal depositRowsText As String, _
        ByVal withdrawalRowsText As String, ByVal commonAccounts As String, _
        ByVal dayWindow As Long) As Boolean
    Dim depositRows As Variant, withdrawalRows As Variant
    Dim depositItem As Variant, withdrawalItem As Variant
    Dim depositRow As Long, withdrawalRow As Long, accountID As String
    depositRows = Split(depositRowsText, ";")
    withdrawalRows = Split(withdrawalRowsText, ";")
    For Each depositItem In depositRows
        depositRow = CLng(depositItem)
        accountID = CellText(sourceData(depositRow, WORK_TX_COL_ACCOUNT_ID))
        If FlowListContains(commonAccounts, accountID) Then
            For Each withdrawalItem In withdrawalRows
                withdrawalRow = CLng(withdrawalItem)
                If StrComp(accountID, CellText(sourceData(withdrawalRow, WORK_TX_COL_ACCOUNT_ID)), _
                           vbTextCompare) = 0 Then
                    If IsPlausibleFollowingTransaction(sourceData, depositRow, withdrawalRow, dayWindow) Then
                        HasPlausibleRelayOrder = True
                        Exit Function
                    End If
                End If
            Next withdrawalItem
        End If
    Next depositItem
End Function

Private Function IsPlausibleFollowingTransaction(ByRef sourceData As Variant, _
                                                 ByVal firstRow As Long, _
                                                 ByVal secondRow As Long, _
                                                 ByVal dayWindow As Long) As Boolean
    Dim firstDate As Long, secondDate As Long, dayDifference As Long
    Dim firstTime As Double, secondTime As Double
    Dim firstHasTime As Boolean, secondHasTime As Boolean
    firstDate = CLng(VBA.DateValue(CDate(sourceData(firstRow, OUT_COL_DATE))))
    secondDate = CLng(VBA.DateValue(CDate(sourceData(secondRow, OUT_COL_DATE))))
    dayDifference = secondDate - firstDate
    If dayDifference < 0 Or _
       dayDifference > AutoCandidateEffectiveDayWindow(dayWindow) Then Exit Function
    If dayDifference > 0 Then
        IsPlausibleFollowingTransaction = True
        Exit Function
    End If
    firstHasTime = TryGetFlowTime(sourceData(firstRow, OUT_COL_TIME), firstTime)
    secondHasTime = TryGetFlowTime(sourceData(secondRow, OUT_COL_TIME), secondTime)
    If firstHasTime And secondHasTime Then
        IsPlausibleFollowingTransaction = (secondTime >= firstTime - 0.000000001)
    Else
        '同日で片方または両方の時刻がなければ、順序未確認の候補として残す。
        IsPlausibleFollowingTransaction = True
    End If
End Function


Private Function FlowListIntersection(ByVal firstList As String, _
                                      ByVal secondList As String) As String
    Dim items As Variant, item As Variant
    items = Split(firstList, ";")
    For Each item In items
        If FlowListContains(secondList, CStr(item)) Then
            If Len(FlowListIntersection) > 0 Then FlowListIntersection = FlowListIntersection & ";"
            FlowListIntersection = FlowListIntersection & CStr(item)
        End If
    Next item
End Function

Private Function FlowListIsSubset(ByVal subsetList As String, _
                                  ByVal supersetList As String) As Boolean
    Dim items As Variant, item As Variant, itemText As String
    If Len(subsetList) = 0 Or Len(supersetList) = 0 Then Exit Function
    items = Split(subsetList, ";")
    For Each item In items
        itemText = CellText(item)
        If Len(itemText) = 0 Then Exit Function
        If Not FlowListContains(supersetList, itemText) Then Exit Function
    Next item
    FlowListIsSubset = True
End Function

Private Function FlowListContains(ByVal listText As String, ByVal itemText As String) As Boolean
    If Len(listText) = 0 Or Len(itemText) = 0 Then Exit Function
    FlowListContains = (InStr(1, ";" & listText & ";", ";" & itemText & ";", vbTextCompare) > 0)
End Function

Private Function FlowListsOverlap(ByVal firstList As String, ByVal secondList As String) As Boolean
    Dim items As Variant, item As Variant
    If Len(firstList) = 0 Or Len(secondList) = 0 Then Exit Function
    items = Split(firstList, ";")
    For Each item In items
        If FlowListContains(secondList, CStr(item)) Then
            FlowListsOverlap = True
            Exit Function
        End If
    Next item
End Function

Private Function BuildWithdrawalBundleAccountIndex( _
        ByRef withdrawalBundles() As FlowBundle, _
        ByVal withdrawalBundleCount As Long) As Object
    Dim result As Object, bundlesForAccount As Collection
    Dim accountParts As Variant, accountItem As Variant
    Dim i As Long, accountID As String
    Set result = CreateObject("Scripting.Dictionary")
    result.CompareMode = vbTextCompare
    For i = 1 To withdrawalBundleCount
        accountParts = Split(withdrawalBundles(i).AccountList, ";")
        For Each accountItem In accountParts
            accountID = CStr(accountItem)
            If Not result.Exists(accountID) Then
                Set bundlesForAccount = New Collection
                result.Add accountID, bundlesForAccount
            Else
                Set bundlesForAccount = result(accountID)
            End If
            bundlesForAccount.Add i
        Next accountItem
    Next i
    Set BuildWithdrawalBundleAccountIndex = result
End Function

Private Function BuildDepositBundleAccountIndex( _
        ByRef depositBundles() As FlowBundle, ByVal depositBundleCount As Long) As Object
    Dim result As Object, bundlesForAccount As Collection
    Dim accountParts As Variant, accountItem As Variant
    Dim i As Long, accountID As String
    Set result = CreateObject("Scripting.Dictionary")
    result.CompareMode = vbTextCompare
    For i = 1 To depositBundleCount
        accountParts = Split(depositBundles(i).AccountList, ";")
        For Each accountItem In accountParts
            accountID = CStr(accountItem)
            If Not result.Exists(accountID) Then
                Set bundlesForAccount = New Collection
                result.Add accountID, bundlesForAccount
            Else
                Set bundlesForAccount = result(accountID)
            End If
            bundlesForAccount.Add i
        Next accountItem
    Next i
    Set BuildDepositBundleAccountIndex = result
End Function

Private Function FlowLinkCanCarryForward(ByRef link As FlowLink) As Boolean
    '生成入口で既知の逆順は拒否する。ここでも防御的に逆順リンクを接続しない。
    FlowLinkCanCarryForward = _
        (Not link.IsLongTermUnknown And _
         StrComp(link.Chronology, "入金→出金", vbTextCompare) <> 0)
End Function

Private Sub ExploreFlowPath( _
        ByRef sourceData As Variant, ByRef withdrawalBundles() As FlowBundle, _
        ByRef depositBundles() As FlowBundle, ByRef links() As FlowLink, _
        ByVal adjacency As Object, ByVal withdrawalByAccount As Object, _
        ByVal dayWindow As Long, ByVal absoluteTolerance As Double, _
        ByVal rateTolerance As Double, ByRef path() As Long, ByVal depth As Long, _
        ByVal usedRows As Object, ByVal terminalCandidateSeen As Object, _
        ByRef terminalOperationCount As Long, _
        ByRef records() As FlowRecord, ByRef recordCount As Long, ByVal seenRecords As Object)
    Dim nextLinks As Collection
    Dim nextItem As Variant, nextIndex As Long
    Dim extended As Boolean
    If mFlowChainSearchStopped Or mFlowRecordLimitReached Then Exit Sub
    AddTerminalFlowRecordsForPath sourceData, withdrawalBundles, depositBundles, links, _
                                  adjacency, withdrawalByAccount, dayWindow, absoluteTolerance, _
                                  rateTolerance, path, depth, usedRows, terminalCandidateSeen, _
                                  terminalOperationCount, _
                                  records, recordCount, seenRecords
    If mFlowChainSearchStopped Or mFlowRecordLimitReached Then Exit Sub
    If depth >= FLOW_MAX_CHAIN_LEGS Then
        If depth >= 2 Then
            If FlowPathHasUnusedExtension(withdrawalBundles, depositBundles, links, adjacency, _
                                          path, depth, usedRows) Then
                AddChainFlowRecord links, path, depth, 4, records, recordCount, seenRecords
            Else
                AddChainFlowRecord links, path, depth, 2, records, recordCount, seenRecords
            End If
        End If
        Exit Sub
    End If
    If adjacency.Exists(CStr(path(depth))) Then
        Set nextLinks = adjacency(CStr(path(depth)))
        For Each nextItem In nextLinks
            If mFlowChainSearchStopped Or mFlowRecordLimitReached Then Exit For
            nextIndex = CLng(nextItem)
            If Not PathContainsFlowLink(path, depth, nextIndex) Then
                If FlowLinkFitsAutomaticTransactionLimit( _
                        withdrawalBundles, depositBundles, links(nextIndex), usedRows) Then
                    extended = True
                    path(depth + 1) = nextIndex
                    AddLinkRowsToDictionary withdrawalBundles, depositBundles, links(nextIndex), usedRows
                    ExploreFlowPath sourceData, withdrawalBundles, depositBundles, links, adjacency, _
                                    withdrawalByAccount, dayWindow, absoluteTolerance, rateTolerance, _
                                    path, depth + 1, usedRows, terminalCandidateSeen, _
                                    terminalOperationCount, _
                                    records, recordCount, seenRecords
                    RemoveLinkRowsFromDictionary withdrawalBundles, depositBundles, links(nextIndex), usedRows
                End If
            End If
        Next nextItem
    End If
    If Not extended And depth >= 2 Then _
        AddChainFlowRecord links, path, depth, 2, records, recordCount, seenRecords
End Sub

Private Function FlowPathHasUnusedExtension( _
        ByRef withdrawalBundles() As FlowBundle, ByRef depositBundles() As FlowBundle, _
        ByRef links() As FlowLink, ByVal adjacency As Object, ByRef path() As Long, _
        ByVal depth As Long, ByVal usedRows As Object) As Boolean
    Dim nextLinks As Collection, item As Variant, nextIndex As Long
    If Not adjacency.Exists(CStr(path(depth))) Then Exit Function
    Set nextLinks = adjacency(CStr(path(depth)))
    For Each item In nextLinks
        nextIndex = CLng(item)
        If Not PathContainsFlowLink(path, depth, nextIndex) Then
            If FlowLinkFitsAutomaticTransactionLimit( _
                    withdrawalBundles, depositBundles, links(nextIndex), usedRows) Then
                FlowPathHasUnusedExtension = True
                Exit Function
            End If
        End If
    Next item
End Function

Private Sub AddChainFlowRecord(ByRef links() As FlowLink, ByRef path() As Long, _
                               ByVal depth As Long, ByVal kindCode As Long, _
                               ByRef records() As FlowRecord, ByRef recordCount As Long, _
                               ByVal seenRecords As Object)
    Dim i As Long, linkList As String, keyText As String
    Dim weakestScore As Long, score As Long
    weakestScore = 101
    For i = 1 To depth
        If i > 1 Then
            linkList = linkList & ";"
            keyText = keyText & "|"
        End If
        linkList = linkList & CStr(path(i))
        keyText = keyText & links(path(i)).KeyText
        If links(path(i)).Score < weakestScore Then weakestScore = links(path(i)).Score
    Next i
    '連鎖は段数が増えるほど仮説が増える。平均点や段数ボーナスで弱いリンクを
    '覆い隠さず、必ず最弱リンク以下とし、追加段階ごとに減点する。
    score = weakestScore - (depth - 1) * 3
    If kindCode = 4 Then score = score - 3
    If score > 100 Then score = 100
    If score < 1 Then score = 1
    If kindCode = 4 Then
        keyText = "CHAIN-LIMIT:" & keyText
    Else
        keyText = "CHAIN:" & keyText
    End If
    AddFlowRecord records, recordCount, kindCode, linkList, vbNullString, score, _
                  FlowRatingForScore(score), keyText, seenRecords
End Sub

Private Sub AddTerminalFlowRecordsForPath( _
        ByRef sourceData As Variant, ByRef withdrawalBundles() As FlowBundle, _
        ByRef depositBundles() As FlowBundle, ByRef links() As FlowLink, _
        ByVal adjacency As Object, ByVal withdrawalByAccount As Object, _
        ByVal dayWindow As Long, ByVal absoluteTolerance As Double, _
        ByVal rateTolerance As Double, ByRef path() As Long, ByVal depth As Long, _
        ByVal usedRows As Object, ByVal candidateSeen As Object, _
        ByRef terminalOperationCount As Long, _
        ByRef records() As FlowRecord, ByRef recordCount As Long, _
        ByVal seenRecords As Object)
    Dim lastLinkIndex As Long, depositBundleIndex As Long
    Dim accountParts As Variant, accountItem As Variant
    Dim accountBundles As Collection, bundleItem As Variant
    Dim candidateBundleIndex As Long
    Dim linkList As String, pathKey As String, keyText As String
    Dim score As Long
    lastLinkIndex = path(depth)
    depositBundleIndex = links(lastLinkIndex).DepositBundle
    candidateSeen.RemoveAll
    accountParts = Split(depositBundles(depositBundleIndex).AccountList, ";")
    For Each accountItem In accountParts
        If withdrawalByAccount.Exists(CStr(accountItem)) Then
            Set accountBundles = withdrawalByAccount(CStr(accountItem))
            For Each bundleItem In accountBundles
                candidateBundleIndex = CLng(bundleItem)
                If Not candidateSeen.Exists(CStr(candidateBundleIndex)) Then
                    candidateSeen.Add CStr(candidateBundleIndex), True
                    terminalOperationCount = terminalOperationCount + 1
                    If terminalOperationCount Mod 8192 = 0 Then _
                        AppProgress "中継後出金の組合せを照合しています...", terminalOperationCount, _
                                    FLOW_MAX_TERMINAL_OPERATIONS
                    If terminalOperationCount > FLOW_MAX_TERMINAL_OPERATIONS Then
                        MarkFlowSearchReduced 0, False, True
                        mFlowChainSearchStopped = True
                        Exit Sub
                    End If
                    If FlowRowListsFitAutomaticTransactionLimit( _
                            usedRows, withdrawalBundles(candidateBundleIndex).RowList, _
                            vbNullString) Then
                        If Not WithdrawalBundleCoveredByAdjacentLink( _
                                lastLinkIndex, candidateBundleIndex, adjacency, withdrawalBundles, _
                                depositBundles, links, usedRows) Then
                            If RelayBundlesCompatible( _
                                    sourceData, depositBundles(depositBundleIndex), _
                                    withdrawalBundles(candidateBundleIndex), dayWindow, _
                                    absoluteTolerance, rateTolerance) Then
                                linkList = vbNullString
                                pathKey = vbNullString
                                BuildPathIdentity links, path, depth, linkList, pathKey
                                keyText = "TAIL:" & pathKey & ">" & _
                                          withdrawalBundles(candidateBundleIndex).IdList
                                score = ConservativePathScore(links, path, depth) - 2
                                If score < 1 Then score = 1
                                AddFlowRecord records, recordCount, 3, linkList, _
                                              withdrawalBundles(candidateBundleIndex).RowList, score, _
                                              FlowRatingForScore(score), keyText, seenRecords
                            End If
                        End If
                    End If
                End If
            Next bundleItem
        End If
    Next accountItem
End Sub

Private Function WithdrawalBundleCoveredByAdjacentLink( _
        ByVal currentLink As Long, ByVal withdrawalBundleIndex As Long, ByVal adjacency As Object, _
        ByRef withdrawalBundles() As FlowBundle, ByRef depositBundles() As FlowBundle, _
        ByRef links() As FlowLink, ByVal usedRows As Object) As Boolean
    Dim nextLinks As Collection, item As Variant, nextIndex As Long
    If Not adjacency.Exists(CStr(currentLink)) Then Exit Function
    Set nextLinks = adjacency(CStr(currentLink))
    For Each item In nextLinks
        nextIndex = CLng(item)
        If StrComp(withdrawalBundles(links(nextIndex).WithdrawalBundle).IdList, _
                   withdrawalBundles(withdrawalBundleIndex).IdList, vbTextCompare) = 0 Then
            If FlowLinkFitsAutomaticTransactionLimit( _
                    withdrawalBundles, depositBundles, links(nextIndex), usedRows) Then
                WithdrawalBundleCoveredByAdjacentLink = True
                Exit Function
            End If
        End If
    Next item
End Function

Private Sub BuildPathIdentity(ByRef links() As FlowLink, ByRef path() As Long, _
                              ByVal depth As Long, ByRef linkList As String, _
                              ByRef pathKey As String)
    Dim i As Long
    For i = 1 To depth
        If i > 1 Then
            linkList = linkList & ";"
            pathKey = pathKey & "|"
        End If
        linkList = linkList & CStr(path(i))
        pathKey = pathKey & links(path(i)).KeyText
    Next i
End Sub

Private Function ConservativePathScore(ByRef links() As FlowLink, ByRef path() As Long, _
                                       ByVal depth As Long) As Long
    Dim i As Long, weakestScore As Long
    weakestScore = 101
    For i = 1 To depth
        If links(path(i)).Score < weakestScore Then weakestScore = links(path(i)).Score
    Next i
    ConservativePathScore = weakestScore - (depth - 1) * 3
    If ConservativePathScore < 1 Then ConservativePathScore = 1
End Function

Private Function PathContainsFlowLink(ByRef path() As Long, ByVal depth As Long, _
                                      ByVal linkIndex As Long) As Boolean
    Dim i As Long
    For i = 1 To depth
        If path(i) = linkIndex Then
            PathContainsFlowLink = True
            Exit Function
        End If
    Next i
End Function

Private Function FlowLinkFitsAutomaticTransactionLimit( _
        ByRef withdrawalBundles() As FlowBundle, ByRef depositBundles() As FlowBundle, _
        ByRef link As FlowLink, ByVal usedRows As Object) As Boolean
    FlowLinkFitsAutomaticTransactionLimit = FlowRowListsFitAutomaticTransactionLimit( _
        usedRows, withdrawalBundles(link.WithdrawalBundle).RowList, _
        depositBundles(link.DepositBundle).RowList)
End Function

Private Function FlowRowListsFitAutomaticTransactionLimit( _
        ByVal usedRows As Object, ByVal firstRowList As String, _
        ByVal secondRowList As String) As Boolean
    Dim additions As Object
    If usedRows Is Nothing Then Exit Function
    If usedRows.Count > AUTO_CANDIDATE_MAX_GROUP_TRANSACTIONS Then Exit Function
    Set additions = CreateObject("Scripting.Dictionary")
    additions.CompareMode = vbTextCompare
    If Not AddFlowRowsToAutomaticLimitSet(firstRowList, usedRows, additions) Then Exit Function
    If Not AddFlowRowsToAutomaticLimitSet(secondRowList, usedRows, additions) Then Exit Function
    FlowRowListsFitAutomaticTransactionLimit = _
        (usedRows.Count + additions.Count <= AUTO_CANDIDATE_MAX_GROUP_TRANSACTIONS)
End Function

Private Function AddFlowRowsToAutomaticLimitSet( _
        ByVal rowList As String, ByVal usedRows As Object, _
        ByVal additions As Object) As Boolean
    Dim rowParts As Variant, rowItem As Variant
    Dim sourceRow As Long, rowKey As String
    If Len(rowList) = 0 Then
        AddFlowRowsToAutomaticLimitSet = True
        Exit Function
    End If
    rowParts = Split(rowList, ";")
    For Each rowItem In rowParts
        If Not IsNumeric(rowItem) Then Exit Function
        sourceRow = CLng(rowItem)
        If sourceRow < 1 Then Exit Function
        rowKey = CStr(sourceRow)
        '同じ取引を段階間で再利用しない。重複排除で件数だけ小さく見せることも禁止する。
        If usedRows.Exists(rowKey) Or additions.Exists(rowKey) Then Exit Function
        additions.Add rowKey, True
        If usedRows.Count + additions.Count > _
           AUTO_CANDIDATE_MAX_GROUP_TRANSACTIONS Then Exit Function
    Next rowItem
    AddFlowRowsToAutomaticLimitSet = True
End Function


Private Sub AddLinkRowsToDictionary(ByRef withdrawalBundles() As FlowBundle, _
                                    ByRef depositBundles() As FlowBundle, _
                                    ByRef link As FlowLink, ByVal values As Object)
    AddFlowRowsToDictionary withdrawalBundles(link.WithdrawalBundle).RowList, values
    AddFlowRowsToDictionary depositBundles(link.DepositBundle).RowList, values
End Sub

Private Sub RemoveLinkRowsFromDictionary(ByRef withdrawalBundles() As FlowBundle, _
                                         ByRef depositBundles() As FlowBundle, _
                                         ByRef link As FlowLink, ByVal values As Object)
    RemoveFlowRowsFromDictionary withdrawalBundles(link.WithdrawalBundle).RowList, values
    RemoveFlowRowsFromDictionary depositBundles(link.DepositBundle).RowList, values
End Sub

Private Sub AddFlowRowsToDictionary(ByVal rowList As String, ByVal values As Object)
    Dim rows As Variant, item As Variant
    rows = Split(rowList, ";")
    For Each item In rows
        If Not values.Exists(CStr(item)) Then values.Add CStr(item), True
    Next item
End Sub

Private Sub RemoveFlowRowsFromDictionary(ByVal rowList As String, ByVal values As Object)
    Dim rows As Variant, item As Variant
    rows = Split(rowList, ";")
    For Each item In rows
        If values.Exists(CStr(item)) Then values.Remove CStr(item)
    Next item
End Sub

Private Sub UpdateFlowCandidateStats( _
        ByRef sourceData As Variant, ByRef withdrawalBundles() As FlowBundle, _
        ByRef depositBundles() As FlowBundle, ByRef links() As FlowLink, _
        ByRef records() As FlowRecord, ByVal recordCount As Long, _
        ByVal candidateCountByTx As Object, ByVal bestScoreByTx As Object, _
        ByVal bestRatingByTx As Object)
    Dim recordRows As Object
    Dim rowItem As Variant, sourceRow As Long, transactionID As String
    Dim i As Long
    Set recordRows = CreateObject("Scripting.Dictionary")
    recordRows.CompareMode = vbTextCompare
    For i = 1 To recordCount
        recordRows.RemoveAll
        CollectFlowRecordRows withdrawalBundles, depositBundles, links, records(i), recordRows
        For Each rowItem In recordRows.Keys
            sourceRow = CLng(rowItem)
            transactionID = CellText(sourceData(sourceRow, WORK_TX_COL_TRANSACTION_ID))
            UpdateShiftCandidateStats candidateCountByTx, bestScoreByTx, bestRatingByTx, _
                                      transactionID, records(i).Score, records(i).Rating
        Next rowItem
    Next i
End Sub

Private Sub CollectFlowRecordRows( _
        ByRef withdrawalBundles() As FlowBundle, ByRef depositBundles() As FlowBundle, _
        ByRef links() As FlowLink, ByRef record As FlowRecord, ByVal targetRows As Object)
    Dim linkParts As Variant, linkItem As Variant, linkIndex As Long
    linkParts = Split(record.LinkList, ";")
    For Each linkItem In linkParts
        linkIndex = CLng(linkItem)
        AddFlowRowsToDictionary withdrawalBundles(links(linkIndex).WithdrawalBundle).RowList, targetRows
        AddFlowRowsToDictionary depositBundles(links(linkIndex).DepositBundle).RowList, targetRows
    Next linkItem
    If Len(record.ExtraWithdrawalRows) > 0 Then _
        AddFlowRowsToDictionary record.ExtraWithdrawalRows, targetRows
    If record.OriginDepositBundle > 0 Then _
        AddFlowRowsToDictionary depositBundles(record.OriginDepositBundle).RowList, targetRows
End Sub

Private Sub WriteAdvancedFlowAnalysis( _
        ByRef sourceData As Variant, ByRef withdrawalBundles() As FlowBundle, _
        ByRef depositBundles() As FlowBundle, ByRef links() As FlowLink, _
        ByRef records() As FlowRecord, ByVal recordCount As Long, ByVal reviews As Object, _
        ByVal settingsSignature As String, ByVal candidateCountByTx As Object, _
        ByVal wsOut As Worksheet, ByRef writtenCount As Long)
    Dim buffer() As Variant
    Dim bufferCount As Long, nextOutputRow As Long, i As Long
    Dim withdrawalSet As Object, depositSet As Object, allRows As Object, accountLabels As Object
    ReDim buffer(1 To FLOW_BUFFER_ROWS, 1 To FLOW_ANALYSIS_LAST_COL)
    Set withdrawalSet = CreateObject("Scripting.Dictionary")
    Set depositSet = CreateObject("Scripting.Dictionary")
    Set allRows = CreateObject("Scripting.Dictionary")
    Set accountLabels = CreateObject("Scripting.Dictionary")
    withdrawalSet.CompareMode = vbTextCompare
    depositSet.CompareMode = vbTextCompare
    allRows.CompareMode = vbTextCompare
    accountLabels.CompareMode = vbTextCompare
    BuildFlowAccountLabelIndex sourceData, accountLabels
    nextOutputRow = 2
    For i = 1 To recordCount
        bufferCount = bufferCount + 1
        FillAdvancedFlowAnalysisRow buffer, bufferCount, sourceData, withdrawalBundles, _
                                    depositBundles, links, records(i), reviews, withdrawalSet, _
                                    depositSet, allRows, accountLabels, settingsSignature, _
                                    candidateCountByTx
        writtenCount = writtenCount + 1
        If bufferCount = FLOW_BUFFER_ROWS Then
            FlushAnalysisBuffer wsOut, buffer, bufferCount, nextOutputRow, FLOW_ANALYSIS_LAST_COL
            ReDim buffer(1 To FLOW_BUFFER_ROWS, 1 To FLOW_ANALYSIS_LAST_COL)
            bufferCount = 0
        End If
    Next i
    If bufferCount > 0 Then _
        FlushAnalysisBuffer wsOut, buffer, bufferCount, nextOutputRow, FLOW_ANALYSIS_LAST_COL
End Sub

Private Sub FillAdvancedFlowAnalysisRow( _
        ByRef buffer() As Variant, ByVal bufferRow As Long, ByRef sourceData As Variant, _
        ByRef withdrawalBundles() As FlowBundle, ByRef depositBundles() As FlowBundle, _
        ByRef links() As FlowLink, ByRef record As FlowRecord, ByVal reviews As Object, _
        ByVal withdrawalSet As Object, ByVal depositSet As Object, ByVal allRows As Object, _
        ByVal accountLabels As Object, ByVal settingsSignature As String, _
        ByVal candidateCountByTx As Object)
    Dim linkParts As Variant, linkItem As Variant
    Dim firstLink As Long, lastLink As Long, linkIndex As Long, linkCount As Long
    Dim routeText As String, orderText As String, withdrawalText As String, depositText As String
    Dim reasonText As String, analysisType As String, orderDecision As String
    Dim precisionText As String, periodText As String, transactionIDs As String
    Dim personRelationship As String
    Dim evidenceRowList As String, evidenceDigest As String
    Dim originAccounts As String, endpointAccounts As String
    Dim startAmount As Double, endpointAmount As Double, differenceAmount As Double
    Dim transactionCount As Long, stageCount As Long, ambiguityCount As Long
    Dim originOrderUnknown As Boolean, terminalOrderUnknown As Boolean
    Dim reviewValues As Variant
    withdrawalSet.RemoveAll
    depositSet.RemoveAll
    allRows.RemoveAll

    linkParts = Split(record.LinkList, ";")
    linkCount = UBound(linkParts) - LBound(linkParts) + 1
    firstLink = CLng(linkParts(LBound(linkParts)))
    lastLink = CLng(linkParts(UBound(linkParts)))
    If record.OriginDepositBundle > 0 Then
        AddFlowRowsToDictionary depositBundles(record.OriginDepositBundle).RowList, depositSet
        AddFlowRowsToDictionary depositBundles(record.OriginDepositBundle).RowList, allRows
        routeText = FriendlyFlowBundleAccounts(depositBundles(record.OriginDepositBundle), _
                    accountLabels) & "（入金） ⇒ " & _
                    FriendlyFlowBundleAccounts(withdrawalBundles(links(firstLink).WithdrawalBundle), _
                    accountLabels) & "（出金）"
        originOrderUnknown = FlowOriginOrderIsUnknown( _
                             depositBundles(record.OriginDepositBundle), _
                             withdrawalBundles(links(firstLink).WithdrawalBundle))
        orderText = BuildFlowOriginOrder(sourceData, _
                    depositBundles(record.OriginDepositBundle), _
                    withdrawalBundles(links(firstLink).WithdrawalBundle), originOrderUnknown)
    End If
    For Each linkItem In linkParts
        linkIndex = CLng(linkItem)
        AddFlowRowsToDictionary withdrawalBundles(links(linkIndex).WithdrawalBundle).RowList, withdrawalSet
        AddFlowRowsToDictionary depositBundles(links(linkIndex).DepositBundle).RowList, depositSet
        AppendFlowRoute routeText, FriendlyFlowBundleAccounts( _
                        withdrawalBundles(links(linkIndex).WithdrawalBundle), accountLabels), _
                        FriendlyFlowBundleAccounts( _
                        depositBundles(links(linkIndex).DepositBundle), accountLabels)
        If record.OriginDepositBundle > 0 And linkIndex = firstLink Then
            If originOrderUnknown Then
                FlowAppendText orderText, BuildFlowLinkOrder(sourceData, _
                               withdrawalBundles(links(linkIndex).WithdrawalBundle), _
                               depositBundles(links(linkIndex).DepositBundle), _
                               links(linkIndex).Chronology), " / "
            Else
                FlowAppendText orderText, "入金[" & BuildFlowBundleDetails(sourceData, _
                               depositBundles(links(linkIndex).DepositBundle), True) & "]", " ⇒ "
            End If
        Else
            FlowAppendText orderText, BuildFlowLinkOrder(sourceData, _
                           withdrawalBundles(links(linkIndex).WithdrawalBundle), _
                           depositBundles(links(linkIndex).DepositBundle), _
                           links(linkIndex).Chronology), " / "
        End If
    Next linkItem
    CopyFlowDictionaryKeys withdrawalSet, allRows
    CopyFlowDictionaryKeys depositSet, allRows
    If Len(record.ExtraWithdrawalRows) > 0 Then
        AddFlowRowsToDictionary record.ExtraWithdrawalRows, withdrawalSet
        AddFlowRowsToDictionary record.ExtraWithdrawalRows, allRows
        FlowAppendText routeText, " ⇒ （次の入金未特定）", vbNullString
        terminalOrderUnknown = FlowBundleToRowsOrderIsUnknown(sourceData, _
                               depositBundles(links(lastLink).DepositBundle), _
                               record.ExtraWithdrawalRows)
        If terminalOrderUnknown Then
            FlowAppendText orderText, " / 同日内順序不明{直前入金 / 出金[" & _
                           BuildFlowRowListDetails(sourceData, record.ExtraWithdrawalRows, False) & _
                           "]}（時刻記載なし） ⇒ 次の入金未特定", vbNullString
        Else
            FlowAppendText orderText, " ⇒ 出金[" & _
                           BuildFlowRowListDetails(sourceData, record.ExtraWithdrawalRows, False) & _
                           "] ⇒ 次の入金未特定", vbNullString
        End If
    End If

    If record.OriginDepositBundle > 0 Then
        startAmount = depositBundles(record.OriginDepositBundle).TotalAmount
    Else
        startAmount = withdrawalBundles(links(firstLink).WithdrawalBundle).TotalAmount
    End If
    If Len(record.ExtraWithdrawalRows) > 0 Then
        endpointAmount = SumFlowRowListAmount(sourceData, record.ExtraWithdrawalRows, False)
        endpointAccounts = "未特定"
    Else
        endpointAmount = depositBundles(links(lastLink).DepositBundle).TotalAmount
        endpointAccounts = depositBundles(links(lastLink).DepositBundle).AccountList
    End If
    differenceAmount = Abs(startAmount - endpointAmount)
    If record.OriginDepositBundle > 0 Then
        originAccounts = depositBundles(record.OriginDepositBundle).AccountList
    Else
        originAccounts = withdrawalBundles(links(firstLink).WithdrawalBundle).AccountList
    End If
    transactionCount = allRows.Count
    If transactionCount < 1 Or _
       transactionCount > AUTO_CANDIDATE_MAX_GROUP_TRANSACTIONS Then _
        Err.Raise vbObjectError + 4712, "FillAdvancedFlowAnalysisRow", _
                  "自動候補の構成取引数が上限4件を超えています。分析結果は出力していません: " & _
                  record.KeyText
    stageCount = linkCount
    If Len(record.ExtraWithdrawalRows) > 0 Then stageCount = stageCount + 1
    If record.OriginDepositBundle > 0 Then stageCount = stageCount + 1
    DetermineFlowRecordTimeAndPeriod sourceData, allRows, precisionText, periodText
    DetermineFlowRecordLabels sourceData, record, linkCount, withdrawalBundles, _
                              depositBundles, links, firstLink, precisionText, _
                              analysisType, orderDecision, reasonText
    If originOrderUnknown Or terminalOrderUnknown Then _
        orderDecision = "資金経路候補（時刻記載なし・同日内順序不明を含む）"
    personRelationship = FlowRecordPersonRelationship(sourceData, withdrawalSet, depositSet)
    If StrComp(personRelationship, "別人物間", vbBinaryCompare) = 0 Then
        reasonText = AppendAnalysisReason(reasonText, _
                     "別人物間の候補です（構成取引の人物IDはすべて確認済み）。")
    Else
        reasonText = AppendAnalysisReason(reasonText, _
                     "人物ID確認済み（同一人物内）の候補です。")
    End If
    If mFlowSearchReduced Then _
        reasonText = AppendAnalysisReason(reasonText, FlowSearchReductionNotice())
    If mFlowDisplayTruncated Then _
        reasonText = AppendAnalysisReason(reasonText, FlowDisplayTruncationNotice())
    withdrawalText = BuildFlowSetDetails(sourceData, withdrawalSet, False)
    depositText = BuildFlowSetDetails(sourceData, depositSet, True)
    transactionIDs = BuildFlowTransactionIDList(sourceData, allRows)
    ambiguityCount = AnalysisMaximumCandidateCount(candidateCountByTx, transactionIDs)
    If ambiguityCount > 1 Then
        reasonText = AppendAnalysisReason(reasonText, "同一取引を含む候補が最大" & _
                     CStr(ambiguityCount) & "件あり、確定前に重複利用を確認してください。")
    End If
    reasonText = AppendAnalysisReason(reasonText, _
                 "候補は入力済み取引の範囲内での推定です。未収載取引の不存在を意味しません。")
    evidenceRowList = BuildFlowEvidenceRowList(allRows)
    evidenceDigest = AnalysisEvidenceDigest(sourceData, evidenceRowList, _
                     "FLOW|" & settingsSignature & "|" & record.KeyText & _
                     "|AMB=" & CStr(ambiguityCount))
    reviewValues = AnalysisReviewValues(reviews, record.KeyText, evidenceDigest)
    If CBool(reviewValues(2)) Then
        reasonText = AppendAnalysisReason(reasonText, _
                     "前回確認後に根拠取引または分析条件が変わったため、再確認へ戻しました。")
        reviewValues(1) = AppendAnalysisMemo(CStr(reviewValues(1)), _
                          "[自動] 根拠取引または分析条件の変更を検知し、再確認へ戻しました。")
    End If

    buffer(bufferRow, 1) = record.Rating
    buffer(bufferRow, 2) = record.Score
    buffer(bufferRow, 3) = analysisType
    buffer(bufferRow, 4) = orderDecision
    buffer(bufferRow, 5) = precisionText
    buffer(bufferRow, 6) = periodText
    buffer(bufferRow, 7) = stageCount
    buffer(bufferRow, 8) = transactionCount
    buffer(bufferRow, 9) = startAmount
    buffer(bufferRow, 10) = endpointAmount
    buffer(bufferRow, 11) = differenceAmount
    buffer(bufferRow, 12) = routeText
    buffer(bufferRow, 13) = orderText
    buffer(bufferRow, 14) = withdrawalText
    buffer(bufferRow, 15) = depositText
    buffer(bufferRow, 16) = reasonText
    buffer(bufferRow, 17) = reviewValues(0)
    buffer(bufferRow, 18) = reviewValues(1)
    buffer(bufferRow, 19) = AnalysisStoredKey(record.KeyText, evidenceDigest)
    buffer(bufferRow, 20) = transactionIDs
    buffer(bufferRow, 21) = originAccounts
    buffer(bufferRow, 22) = endpointAccounts
End Sub

Private Function FlowOriginOrderIsUnknown(ByRef originDepositBundle As FlowBundle, _
                                          ByRef firstWithdrawalBundle As FlowBundle) As Boolean
    If originDepositBundle.MaxDate <> firstWithdrawalBundle.MinDate Then Exit Function
    FlowOriginOrderIsUnknown = _
        (Not originDepositBundle.HasAllTimes Or Not firstWithdrawalBundle.HasAllTimes)
End Function

Private Function FlowBundleToRowsOrderIsUnknown(ByRef sourceData As Variant, _
                                                ByRef firstBundle As FlowBundle, _
                                                ByVal secondRowList As String) As Boolean
    Dim firstRows As Variant, secondRows As Variant
    Dim firstItem As Variant, secondItem As Variant
    Dim firstRow As Long, secondRow As Long, firstDate As Long, secondDate As Long
    Dim firstTime As Double, secondTime As Double
    Dim firstAccountID As String, secondAccountID As String
    If Len(firstBundle.RowList) = 0 Or Len(secondRowList) = 0 Then Exit Function
    firstRows = Split(firstBundle.RowList, ";")
    secondRows = Split(secondRowList, ";")
    For Each firstItem In firstRows
        firstRow = CLng(firstItem)
        firstDate = CLng(VBA.DateValue(CDate(sourceData(firstRow, OUT_COL_DATE))))
        firstAccountID = CellText(sourceData(firstRow, WORK_TX_COL_ACCOUNT_ID))
        For Each secondItem In secondRows
            secondRow = CLng(secondItem)
            secondDate = CLng(VBA.DateValue(CDate(sourceData(secondRow, OUT_COL_DATE))))
            secondAccountID = CellText(sourceData(secondRow, WORK_TX_COL_ACCOUNT_ID))
            If Len(firstAccountID) > 0 And _
               StrComp(firstAccountID, secondAccountID, vbTextCompare) = 0 And _
               firstDate = secondDate Then
                If Not TryGetFlowTime(sourceData(firstRow, OUT_COL_TIME), firstTime) Or _
                   Not TryGetFlowTime(sourceData(secondRow, OUT_COL_TIME), secondTime) Then
                    FlowBundleToRowsOrderIsUnknown = True
                    Exit Function
                End If
            End If
        Next secondItem
    Next firstItem
End Function

Private Function BuildFlowOriginOrder(ByRef sourceData As Variant, _
                                      ByRef originDepositBundle As FlowBundle, _
                                      ByRef firstWithdrawalBundle As FlowBundle, _
                                      ByVal orderUnknown As Boolean) As String
    Dim depositDetails As String, withdrawalDetails As String
    depositDetails = BuildFlowBundleDetails(sourceData, originDepositBundle, True)
    withdrawalDetails = BuildFlowBundleDetails(sourceData, firstWithdrawalBundle, False)
    If orderUnknown Then
        BuildFlowOriginOrder = "同日内順序不明{入金[" & depositDetails & "] / 出金[" & _
                               withdrawalDetails & "]}（時刻記載なし・起点候補）"
    Else
        BuildFlowOriginOrder = "入金[" & depositDetails & "] ⇒ 出金[" & _
                               withdrawalDetails & "]"
    End If
End Function

Private Function FlowRecordPersonRelationship(ByRef sourceData As Variant, _
                                              ByVal withdrawalRows As Object, _
                                              ByVal depositRows As Object) As String
    Dim withdrawalIDs As Object, depositIDs As Object
    Set withdrawalIDs = CreateObject("Scripting.Dictionary")
    Set depositIDs = CreateObject("Scripting.Dictionary")
    withdrawalIDs.CompareMode = vbTextCompare
    depositIDs.CompareMode = vbTextCompare
    AddRequiredFlowPersonIDsFromRows sourceData, withdrawalRows, withdrawalIDs, "出金側構成取引"
    AddRequiredFlowPersonIDsFromRows sourceData, depositRows, depositIDs, "入金側構成取引"
    If withdrawalIDs.Count = 1 And depositIDs.Count = 1 And _
       FlowPersonIDSetsEqual(withdrawalIDs, depositIDs) Then
        FlowRecordPersonRelationship = "同一人物内"
    Else
        FlowRecordPersonRelationship = "別人物間"
    End If
End Function

Private Sub AddRequiredFlowPersonIDsFromRows(ByRef sourceData As Variant, _
                                             ByVal sourceRows As Object, _
                                             ByVal personIDs As Object, _
                                             ByVal contextText As String)
    Dim rowItem As Variant, sourceRow As Long, personID As String
    If sourceRows Is Nothing Then _
        Err.Raise vbObjectError + 4628, "AddRequiredFlowPersonIDsFromRows", _
                  contextText & "がありません。"
    If sourceRows.Count = 0 Then _
        Err.Raise vbObjectError + 4628, "AddRequiredFlowPersonIDsFromRows", _
                  contextText & "がありません。"
    For Each rowItem In sourceRows.Keys
        sourceRow = CLng(rowItem)
        personID = CellText(sourceData(sourceRow, WORK_TX_COL_PERSON_ID))
        If Len(personID) = 0 Then _
            Err.Raise vbObjectError + 4628, "AddRequiredFlowPersonIDsFromRows", _
                      contextText & "の人物IDがありません（取引配列行=" & _
                      CStr(sourceRow) & "）。氏名では代替しません。"
        If Not IsInternalIdValue(personID, "P") Then _
            Err.Raise vbObjectError + 4629, "AddRequiredFlowPersonIDsFromRows", _
                      contextText & "の人物ID形式が不正です（取引配列行=" & _
                      CStr(sourceRow) & " / 人物ID=" & personID & "）。"
        If Not personIDs.Exists(personID) Then personIDs.Add personID, True
    Next rowItem
End Sub

Private Sub DetermineFlowRecordLabels( _
        ByRef sourceData As Variant, ByRef record As FlowRecord, ByVal linkCount As Long, _
        ByRef withdrawalBundles() As FlowBundle, ByRef depositBundles() As FlowBundle, _
        ByRef links() As FlowLink, ByVal firstLink As Long, ByVal precisionText As String, _
        ByRef analysisType As String, ByRef orderDecision As String, ByRef reasonText As String)
    Dim withdrawalCount As Long, depositCount As Long
    Dim terminalWithdrawalCount As Long, terminalAggregateText As String
    withdrawalCount = withdrawalBundles(links(firstLink).WithdrawalBundle).ItemCount
    depositCount = depositBundles(links(firstLink).DepositBundle).ItemCount
    Select Case record.KindCode
        Case 1
            If withdrawalCount = 1 And depositCount > 1 Then
                analysisType = "1対複（分割入金）"
            ElseIf withdrawalCount > 1 And depositCount = 1 Then
                analysisType = "複対1（合算入金）"
            Else
                analysisType = "複対複（分割・合算）"
            End If
            orderDecision = links(firstLink).Chronology
            reasonText = CStr(withdrawalCount) & "件の出金合計と" & CStr(depositCount) & _
                         "件の入金合計を金額許容内で照合。日付・口座・人物の近接条件から" & _
                         "構成候補を作成しています。"
        Case 8
            analysisType = "長期間隔の不明組合せ"
            orderDecision = "長期間隔・資金順序未確定"
            reasonText = CStr(withdrawalCount) & "件の不明出金と" & CStr(depositCount) & _
                         "件の不明入金を、日数上限を設けず金額許容内で照合しました。" & _
                         "通常の0～3日資金移動候補とは別分類であり、資金移動、目的、" & _
                         "法的性質又は両取引の関係を断定していません。"
        Case 2
            analysisType = "連鎖移動（" & CStr(linkCount) & "段）"
            orderDecision = FlowChainOrderDecision(precisionText, False, sourceData, links, _
                                                   record.LinkList, withdrawalBundles, depositBundles)
            reasonText = "異なる口座間の金額近似を" & CStr(linkCount) & _
                         "段接続し、中継口座の入金後に行われた出金を追跡しています。"
        Case 3
            terminalWithdrawalCount = FlowListItemCount(record.ExtraWithdrawalRows)
            If linkCount = 1 And terminalWithdrawalCount = 1 Then
                analysisType = "中継後出金（次入金未特定）"
            ElseIf linkCount = 1 Then
                analysisType = "中継後複数出金（次入金未特定）"
            ElseIf terminalWithdrawalCount = 1 Then
                analysisType = "連鎖＋中継後出金（次入金未特定）"
            Else
                analysisType = "連鎖＋中継後複数出金（次入金未特定）"
            End If
            orderDecision = FlowChainOrderDecision(precisionText, False, sourceData, links, _
                                                   record.LinkList, withdrawalBundles, depositBundles)
            If terminalWithdrawalCount > 1 Then terminalAggregateText = "合計"
            reasonText = "中継口座への入金後、同額または近い金額の出金" & _
                         terminalAggregateText & _
                         "まで確認できましたが、" & _
                         "その先の入金候補は特定していません。"
        Case 5
            analysisType = "入金起点連鎖（入金→出金→入金・" & CStr(linkCount + 1) & "段）"
            orderDecision = FlowChainOrderDecision(precisionText, False, sourceData, links, _
                                                   record.LinkList, withdrawalBundles, depositBundles)
            reasonText = "同一口座への前段入金と、その後の近似額出金を起点として、" & _
                         "既存の出金→入金経路へ接続しています。原資側から使途側までを" & _
                         "一つの仮説として追跡します。"
        Case 6
            terminalWithdrawalCount = FlowListItemCount(record.ExtraWithdrawalRows)
            analysisType = "入金起点連鎖＋終端出金（次入金未特定）"
            orderDecision = FlowChainOrderDecision(precisionText, False, sourceData, links, _
                                                   record.LinkList, withdrawalBundles, depositBundles)
            reasonText = "前段入金から同一口座の出金、別口座への入金、さらに終端出金まで" & _
                         "追跡しました。その先の入金先は特定していません。"
        Case 7
            analysisType = "入金起点連鎖（探索上限" & CStr(FLOW_MAX_CHAIN_LEGS + 1) & "段）"
            orderDecision = FlowChainOrderDecision(precisionText, True, sourceData, links, _
                                                   record.LinkList, withdrawalBundles, depositBundles)
            reasonText = "前段入金を含む資金経路が探索上限に達したため、この行で区切っています。" & _
                         "続きの候補を個別に確認してください。"
        Case Else
            analysisType = "連鎖移動（探索上限" & CStr(FLOW_MAX_CHAIN_LEGS) & "段）"
            orderDecision = FlowChainOrderDecision(precisionText, True, sourceData, links, _
                                                   record.LinkList, withdrawalBundles, depositBundles)
            reasonText = "資金経路が" & CStr(FLOW_MAX_CHAIN_LEGS) & _
                         "段に達したため、この行で探索を区切っています。続きの候補を個別に確認してください。"
    End Select
    If StrComp(precisionText, "全件時刻記載あり", vbTextCompare) <> 0 Then
        reasonText = reasonText & _
            " 時刻記載なしの取引を含みます。該当する同日取引は同日内順序不明として、" & _
            "前後を断定せず候補化しています。"
    End If
    reasonText = reasonText & " 摘要の有無は候補除外条件に使用していません。"
End Sub

Private Function FlowListItemCount(ByVal listText As String) As Long
    Dim values As Variant
    If Len(listText) = 0 Then Exit Function
    values = Split(listText, ";")
    FlowListItemCount = UBound(values) - LBound(values) + 1
End Function

Private Function FlowChainOrderDecision(ByVal precisionText As String, _
                                        ByVal reachedLimit As Boolean, _
                                        ByRef sourceData As Variant, _
                                        ByRef links() As FlowLink, ByVal linkList As String, _
                                        ByRef withdrawalBundles() As FlowBundle, _
                                        ByRef depositBundles() As FlowBundle) As String
    Dim linkParts As Variant, item As Variant, linkIndex As Long, previousLinkIndex As Long
    Dim hasPostingOrderDifference As Boolean, hasUnknownSameDayOrder As Boolean
    linkParts = Split(linkList, ";")
    For Each item In linkParts
        linkIndex = CLng(item)
        If previousLinkIndex > 0 Then
            If FlowBundleToRowsOrderIsUnknown(sourceData, _
                    depositBundles(links(previousLinkIndex).DepositBundle), _
                    withdrawalBundles(links(linkIndex).WithdrawalBundle).RowList) Then _
                hasUnknownSameDayOrder = True
        End If
        If StrComp(links(linkIndex).Chronology, "同日内順序不明", vbTextCompare) = 0 Then
            hasUnknownSameDayOrder = True
        ElseIf StrComp(links(linkIndex).Chronology, "出金→入金", vbTextCompare) <> 0 And _
           StrComp(links(linkIndex).Chronology, "同時刻", vbTextCompare) <> 0 Then
            hasPostingOrderDifference = True
        End If
        previousLinkIndex = linkIndex
    Next item
    If StrComp(precisionText, "全件時刻記載あり", vbTextCompare) = 0 And _
       Not hasPostingOrderDifference And Not hasUnknownSameDayOrder Then
        FlowChainOrderDecision = "資金経路順（全時刻確認）"
    ElseIf StrComp(precisionText, "全件時刻記載あり", vbTextCompare) = 0 And _
           hasUnknownSameDayOrder Then
        FlowChainOrderDecision = "資金経路候補（同一時刻・順序不明を含む）"
    ElseIf StrComp(precisionText, "全件時刻記載あり", vbTextCompare) = 0 Then
        FlowChainOrderDecision = "資金経路順（記帳順差異あり）"
    ElseIf hasUnknownSameDayOrder Then
        FlowChainOrderDecision = "資金経路候補（時刻記載なし・同日内順序不明を含む）"
    Else
        FlowChainOrderDecision = "資金経路順（日付確認・時刻記載なし）"
    End If
    If reachedLimit Then FlowChainOrderDecision = FlowChainOrderDecision & "・探索上限到達"
End Function

Private Sub DetermineFlowRecordTimeAndPeriod(ByRef sourceData As Variant, ByVal rows As Object, _
                                             ByRef precisionText As String, ByRef periodText As String)
    Dim item As Variant, sourceRow As Long, transactionDateSerial As Long
    Dim minDate As Long, maxDate As Long, anyTime As Boolean, allTimes As Boolean
    Dim timeFraction As Double, firstValue As Boolean
    allTimes = True
    firstValue = True
    For Each item In rows.Keys
        sourceRow = CLng(item)
        transactionDateSerial = CLng(VBA.DateValue(CDate(sourceData(sourceRow, OUT_COL_DATE))))
        If firstValue Or transactionDateSerial < minDate Then minDate = transactionDateSerial
        If firstValue Or transactionDateSerial > maxDate Then maxDate = transactionDateSerial
        If TryGetFlowTime(sourceData(sourceRow, OUT_COL_TIME), timeFraction) Then
            anyTime = True
        Else
            allTimes = False
        End If
        firstValue = False
    Next item
    If allTimes And rows.Count > 0 Then
        precisionText = "全件時刻記載あり"
    ElseIf anyTime Then
        precisionText = "一部時刻記載なし"
    Else
        precisionText = "時刻記載なし"
    End If
    If minDate = maxDate Then
        periodText = Format$(CDate(minDate), "yyyy/m/d") & "（同日）"
    Else
        periodText = Format$(CDate(minDate), "yyyy/m/d") & "～" & _
                     Format$(CDate(maxDate), "yyyy/m/d") & "（" & _
                     CStr(maxDate - minDate) & "日）"
    End If
End Sub

Private Sub AppendFlowRoute(ByRef routeText As String, ByVal sourceAccounts As String, _
                            ByVal destinationAccounts As String)
    Dim segmentText As String
    segmentText = sourceAccounts & " ⇒ " & destinationAccounts
    FlowAppendText routeText, segmentText, " / "
End Sub

Private Function BuildFlowLinkOrder( _
        ByRef sourceData As Variant, ByRef withdrawalBundle As FlowBundle, _
        ByRef depositBundle As FlowBundle, ByVal chronology As String) As String
    Dim withdrawalDetails As String, depositDetails As String
    withdrawalDetails = BuildFlowBundleDetails(sourceData, withdrawalBundle, False)
    depositDetails = BuildFlowBundleDetails(sourceData, depositBundle, True)
    If StrComp(chronology, "長期間隔・順序未確定", vbTextCompare) = 0 Then
        BuildFlowLinkOrder = "長期間隔の不明組合せ{出金[" & withdrawalDetails & _
                             "] / 入金[" & depositDetails & _
                             "]}（関係・資金順序は未確定）"
    ElseIf StrComp(chronology, "入金→出金", vbTextCompare) = 0 Then
        BuildFlowLinkOrder = "入金[" & depositDetails & "] ⇒ 出金[" & _
                             withdrawalDetails & "]"
    ElseIf StrComp(chronology, "時系列混在", vbTextCompare) = 0 Then
        BuildFlowLinkOrder = "時系列混在[" & _
                             BuildFlowMergedTimeline(sourceData, withdrawalBundle, _
                                                     depositBundle) & "]"
    ElseIf StrComp(chronology, "同日内順序不明", vbTextCompare) = 0 Then
        If withdrawalBundle.HasAllTimes And depositBundle.HasAllTimes Then
            BuildFlowLinkOrder = "同日内順序不明{出金[" & withdrawalDetails & "] / 入金[" & _
                                 depositDetails & "]}（同一時刻・資金経路候補）"
        Else
            BuildFlowLinkOrder = "同日内順序不明{出金[" & withdrawalDetails & "] / 入金[" & _
                                 depositDetails & "]}（時刻記載なし・資金経路候補）"
        End If
    Else
        BuildFlowLinkOrder = "出金[" & withdrawalDetails & "] ⇒ 入金[" & _
                             depositDetails & "]"
        If StrComp(chronology, "同時刻", vbTextCompare) = 0 Then _
            BuildFlowLinkOrder = BuildFlowLinkOrder & "（同時刻）"
    End If
End Function

Private Function FriendlyFlowBundleAccounts(ByRef bundle As FlowBundle, _
                                            ByVal accountLabels As Object) As String
    Dim accounts As Variant, item As Variant, accountID As String
    Dim resultText As String
    accounts = Split(bundle.AccountList, ";")
    For Each item In accounts
        accountID = CStr(item)
        If accountLabels.Exists(accountID) Then
            FlowAppendText resultText, CStr(accountLabels(accountID)), "・"
        Else
            FlowAppendText resultText, accountID, "・"
        End If
    Next item
    FriendlyFlowBundleAccounts = resultText
End Function

Private Sub BuildFlowAccountLabelIndex(ByRef sourceData As Variant, ByVal accountLabels As Object)
    Dim r As Long, accountID As String, labelText As String
    For r = 1 To UBound(sourceData, 1)
        accountID = CellText(sourceData(r, WORK_TX_COL_ACCOUNT_ID))
        If Len(accountID) > 0 And Not accountLabels.Exists(accountID) Then
            labelText = CellText(sourceData(r, OUT_COL_BANK))
            If HasText(sourceData(r, OUT_COL_BRANCH)) Then _
                labelText = labelText & " " & CellText(sourceData(r, OUT_COL_BRANCH))
            If HasText(sourceData(r, OUT_COL_ACCOUNT_TYPE)) Then _
                labelText = labelText & " " & CellText(sourceData(r, OUT_COL_ACCOUNT_TYPE))
            If HasText(sourceData(r, OUT_COL_ACCOUNT_NO)) Then _
                labelText = labelText & " " & CellText(sourceData(r, OUT_COL_ACCOUNT_NO))
            If Len(Trim$(labelText)) = 0 Then labelText = accountID
            accountLabels.Add accountID, Trim$(labelText)
        End If
    Next r
End Sub

Private Function BuildFlowBundleDetails(ByRef sourceData As Variant, _
                                        ByRef bundle As FlowBundle, _
                                        ByVal isDeposit As Boolean) As String
    Dim rows As Variant, rowValues() As Long
    Dim i As Long, itemCount As Long
    Dim resultText As String
    rows = Split(bundle.RowList, ";")
    itemCount = UBound(rows) - LBound(rows) + 1
    ReDim rowValues(1 To itemCount)
    For i = 1 To itemCount
        rowValues(i) = CLng(rows(LBound(rows) + i - 1))
    Next i
    If itemCount > 1 Then SortFlowDetailRows sourceData, rowValues, itemCount
    For i = 1 To itemCount
        FlowAppendText resultText, _
                       FormatFlowTransaction(sourceData, rowValues(i), isDeposit), " / "
    Next i
    BuildFlowBundleDetails = resultText
End Function

Private Function BuildFlowMergedTimeline( _
        ByRef sourceData As Variant, ByRef withdrawalBundle As FlowBundle, _
        ByRef depositBundle As FlowBundle) As String
    Dim withdrawalRows As Variant, depositRows As Variant
    Dim rowValues() As Long
    Dim item As Variant, itemCount As Long, i As Long, isDeposit As Boolean
    Dim resultText As String
    withdrawalRows = Split(withdrawalBundle.RowList, ";")
    depositRows = Split(depositBundle.RowList, ";")
    ReDim rowValues(1 To withdrawalBundle.ItemCount + depositBundle.ItemCount)
    For Each item In withdrawalRows
        itemCount = itemCount + 1
        rowValues(itemCount) = CLng(item)
    Next item
    For Each item In depositRows
        itemCount = itemCount + 1
        rowValues(itemCount) = CLng(item)
    Next item
    If itemCount > 1 Then SortFlowDetailRows sourceData, rowValues, itemCount
    For i = 1 To itemCount
        isDeposit = HasText(sourceData(rowValues(i), OUT_COL_DEPOSIT))
        FlowAppendText resultText, _
                       FormatFlowTransaction(sourceData, rowValues(i), isDeposit), " ⇒ "
    Next i
    BuildFlowMergedTimeline = resultText
End Function

Private Sub SortFlowDetailRows(ByRef sourceData As Variant, ByRef rows() As Long, _
                               ByVal itemCount As Long)
    Dim i As Long, j As Long, valueToInsert As Long
    For i = 2 To itemCount
        valueToInsert = rows(i)
        j = i - 1
        Do While j >= 1
            If CompareFlowDetailRows(sourceData, rows(j), valueToInsert) <= 0 Then Exit Do
            rows(j + 1) = rows(j)
            j = j - 1
        Loop
        rows(j + 1) = valueToInsert
    Next i
End Sub

Private Function CompareFlowDetailRows(ByRef sourceData As Variant, _
                                       ByVal firstRow As Long, _
                                       ByVal secondRow As Long) As Long
    Dim firstDate As Long, secondDate As Long
    Dim firstTime As Double, secondTime As Double
    Dim firstHasTime As Boolean, secondHasTime As Boolean
    firstDate = CLng(VBA.DateValue(CDate(sourceData(firstRow, OUT_COL_DATE))))
    secondDate = CLng(VBA.DateValue(CDate(sourceData(secondRow, OUT_COL_DATE))))
    If firstDate < secondDate Then
        CompareFlowDetailRows = -1
        Exit Function
    ElseIf firstDate > secondDate Then
        CompareFlowDetailRows = 1
        Exit Function
    End If
    firstHasTime = TryGetFlowTime(sourceData(firstRow, OUT_COL_TIME), firstTime)
    secondHasTime = TryGetFlowTime(sourceData(secondRow, OUT_COL_TIME), secondTime)
    If firstHasTime And secondHasTime Then
        If firstTime < secondTime Then
            CompareFlowDetailRows = -1
            Exit Function
        ElseIf firstTime > secondTime Then
            CompareFlowDetailRows = 1
            Exit Function
        End If
    End If
    '片方でも時刻がなければ架空時刻で並べない。以下は表示を再現可能にする
    '安定した補助順であり、同日内の前後関係を示すものではない。
    If firstRow < secondRow Then
        CompareFlowDetailRows = -1
    ElseIf firstRow > secondRow Then
        CompareFlowDetailRows = 1
    End If
End Function

Private Function BuildFlowRowListDetails(ByRef sourceData As Variant, _
                                         ByVal rowList As String, _
                                         ByVal isDeposit As Boolean) As String
    Dim rows As Variant, rowValues() As Long
    Dim i As Long, itemCount As Long
    Dim resultText As String
    If Len(rowList) = 0 Then Exit Function
    rows = Split(rowList, ";")
    itemCount = UBound(rows) - LBound(rows) + 1
    ReDim rowValues(1 To itemCount)
    For i = 1 To itemCount
        rowValues(i) = CLng(rows(LBound(rows) + i - 1))
    Next i
    If itemCount > 1 Then SortFlowDetailRows sourceData, rowValues, itemCount
    For i = 1 To itemCount
        FlowAppendText resultText, _
                       FormatFlowTransaction(sourceData, rowValues(i), isDeposit), " / "
    Next i
    BuildFlowRowListDetails = resultText
End Function

Private Function SumFlowRowListAmount(ByRef sourceData As Variant, ByVal rowList As String, _
                                      ByVal isDeposit As Boolean) As Double
    Dim rows As Variant, item As Variant, sourceRow As Long
    If Len(rowList) = 0 Then Exit Function
    rows = Split(rowList, ";")
    For Each item In rows
        sourceRow = CLng(item)
        If isDeposit Then
            SumFlowRowListAmount = SumFlowRowListAmount + CDbl(sourceData(sourceRow, OUT_COL_DEPOSIT))
        Else
            SumFlowRowListAmount = SumFlowRowListAmount + CDbl(sourceData(sourceRow, OUT_COL_WITHDRAW))
        End If
    Next item
End Function

Private Function BuildFlowSetDetails(ByRef sourceData As Variant, ByVal rows As Object, _
                                     ByVal isDeposit As Boolean) As String
    Dim item As Variant, rowValues() As Long
    Dim itemCount As Long, i As Long
    Dim resultText As String
    If rows Is Nothing Then Exit Function
    If rows.Count = 0 Then Exit Function
    ReDim rowValues(1 To rows.Count)
    For Each item In rows.Keys
        itemCount = itemCount + 1
        rowValues(itemCount) = CLng(item)
    Next item
    If itemCount > 1 Then SortFlowDetailRows sourceData, rowValues, itemCount
    For i = 1 To itemCount
        FlowAppendText resultText, _
                       FormatFlowTransaction(sourceData, rowValues(i), isDeposit), " / "
    Next i
    BuildFlowSetDetails = resultText
End Function

Private Function FormatFlowTransaction(ByRef sourceData As Variant, ByVal sourceRow As Long, _
                                       ByVal isDeposit As Boolean) As String
    Dim timeText As String, accountText As String, amountValue As Double
    Dim timeFraction As Double, kindText As String
    If TryGetFlowTime(sourceData(sourceRow, OUT_COL_TIME), timeFraction) Then
        timeText = Format$(timeFraction, "hh:mm")
    Else
        timeText = "時刻記載なし"
    End If
    accountText = CellText(sourceData(sourceRow, OUT_COL_BANK))
    If HasText(sourceData(sourceRow, OUT_COL_BRANCH)) Then _
        accountText = accountText & " " & CellText(sourceData(sourceRow, OUT_COL_BRANCH))
    If HasText(sourceData(sourceRow, OUT_COL_ACCOUNT_TYPE)) Then _
        accountText = accountText & " " & CellText(sourceData(sourceRow, OUT_COL_ACCOUNT_TYPE))
    If HasText(sourceData(sourceRow, OUT_COL_ACCOUNT_NO)) Then _
        accountText = accountText & " " & CellText(sourceData(sourceRow, OUT_COL_ACCOUNT_NO))
    If isDeposit Then
        amountValue = CDbl(sourceData(sourceRow, OUT_COL_DEPOSIT))
        kindText = "入金"
    Else
        amountValue = CDbl(sourceData(sourceRow, OUT_COL_WITHDRAW))
        kindText = "出金"
    End If
    FormatFlowTransaction = Format$(CDate(sourceData(sourceRow, OUT_COL_DATE)), "yyyy/m/d") & _
                            " " & timeText & " " & Trim$(accountText) & " " & kindText & _
                            " " & Format$(amountValue, "#,##0.########")
End Function

Private Function BuildFlowTransactionIDList(ByRef sourceData As Variant, _
                                            ByVal rows As Object) As String
    Dim values() As String, item As Variant, itemCount As Long
    If rows.Count = 0 Then Exit Function
    ReDim values(1 To rows.Count)
    For Each item In rows.Keys
        itemCount = itemCount + 1
        values(itemCount) = CellText(sourceData(CLng(item), WORK_TX_COL_TRANSACTION_ID))
    Next item
    If itemCount > 1 Then SortTextValues values, itemCount
    BuildFlowTransactionIDList = JoinTextValues(values, itemCount)
End Function

Private Function BuildFlowEvidenceRowList(ByVal rows As Object) As String
    Dim values() As Long, item As Variant, itemCount As Long
    If rows.Count = 0 Then Exit Function
    ReDim values(1 To rows.Count)
    For Each item In rows.Keys
        itemCount = itemCount + 1
        values(itemCount) = CLng(item)
    Next item
    If itemCount > 1 Then SortLongValues values, itemCount
    BuildFlowEvidenceRowList = JoinLongValues(values, itemCount)
End Function

Private Sub CopyFlowDictionaryKeys(ByVal sourceValues As Object, ByVal targetValues As Object)
    Dim item As Variant
    For Each item In sourceValues.Keys
        If Not targetValues.Exists(CStr(item)) Then targetValues.Add CStr(item), True
    Next item
End Sub

Private Sub FlowAppendText(ByRef targetText As String, ByVal newText As String, _
                           ByVal separatorText As String)
    Dim availableChars As Long
    If Len(newText) = 0 Or Len(targetText) >= FLOW_DETAIL_MAX_CHARS Then Exit Sub
    availableChars = FLOW_DETAIL_MAX_CHARS - Len(targetText)
    If Len(targetText) > 0 And Len(separatorText) > 0 Then
        If availableChars <= Len(separatorText) Then Exit Sub
        targetText = targetText & separatorText
        availableChars = FLOW_DETAIL_MAX_CHARS - Len(targetText)
    End If
    If Len(newText) <= availableChars Then
        targetText = targetText & newText
    ElseIf availableChars > 1 Then
        targetText = targetText & Left$(newText, availableChars - 1) & "…"
    End If
End Sub

Private Function TryGetFlowTime(ByVal valueIn As Variant, ByRef timeFraction As Double) As Boolean
    Dim ok As Boolean, normalizedTime As Variant
    If Not HasText(valueIn) Then Exit Function
    normalizedTime = NormalizeTimeInput(valueIn, ok)
    If Not ok Then Exit Function
    timeFraction = CDbl(CDate(normalizedTime)) - Fix(CDbl(CDate(normalizedTime)))
    TryGetFlowTime = True
End Function

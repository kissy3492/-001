﻿Attribute VB_Name = "modUI"
Option Explicit

Private mButtonSeq As Long

Private Const INPUT_BUTTON_INSET_POINTS As Double = 2#
Private Const INPUT_BUTTON_MIN_WIDTH_POINTS As Double = 48#
Private Const INPUT_BUTTON_MIN_HEIGHT_POINTS As Double = 24#
Private Const INPUT_BUTTON_GEOMETRY_TOLERANCE_POINTS As Double = 6#
Private Const INPUT_BUTTON_ROW_HEIGHT_POINTS As Double = 29#

Public Sub ResetUIButtonSequence()
    'シートを作り直すたびに図形名を同じ順序へ戻す。
    '再セットアップ後もボタン名を安定させ、途中失敗で番号だけ進む状態を残さない。
    mButtonSeq = 0
End Sub

Private Function UIButtonShapeName(ByVal sequenceNumber As Long, ByVal macroName As String) As String
    'OnActionを読み取れないOffice環境でも、利用者向け代替テキストを機械情報へ戻さず
    '実行先を復元できるよう、非表示の図形名へ正規のマクロ名を保持する。
    UIButtonShapeName = UI_PREFIX & "btn_" & Format$(sequenceNumber, "00") & "__" & macroName
End Function

Public Sub BuildOperationPanel(ByVal ws As Worksheet)
    If ws Is Nothing Then Exit Sub

    EnsureInputOperationRowGeometry ws
    ResetUIButtonSequence
    DeleteToolShapesVerified ws, False

    '右側常設パネルは廃止し、通常表示A:K内の2行に操作を集約する。
    '画面が狭くても明細入力の右側へスクロールしないで操作できる。
    AddInputBarButton ws, "D2:E2", "この口座を登録", "SaveCurrentAccount", "primary"
    AddInputBarButton ws, "F2:G2", "次枝番で登録", "SaveCurrentAccountNextBranch", "tool"
    AddInputBarButton ws, "H2:I2", "帳票・分析を更新", "BuildAllOutputSheets", "hero"
    AddInputBarButton ws, "J2:K2", "最終出力", "ExportFinalWorkbooks", "export"

    AddInputBarButton ws, "B3:C3", "詳細・残高を開く", "ToggleInputDetails", "soft"
    AddInputBarButton ws, "D3:E3", "口座一覧", "OpenRegisteredAccounts", "tool"
    AddInputBarButton ws, "F3:G3", "入力消去", "ClearCurrentAccountInput", "neutral"
    AddInputBarButton ws, "H3:I3", "入力エラーへ", "GoToFirstInputError", "tool"
    AddInputBarButton ws, "J3:K3", "設定", "ShowConfigSheet", "soft"

    '作成直後にボタン・カードをロックし、淡色ボタンの文字色も最終補正する。
    LockToolShapes ws, False
    RefreshMainActionCaption
End Sub

Private Sub AddInputBarButton(ByVal ws As Worksheet, ByVal areaAddress As String, _
                              ByVal caption As String, ByVal macroName As String, _
                              ByVal styleName As String)
    Dim area As Range
    Dim buttonShape As Shape
    Dim buttonName As String
    Dim buttonLeft As Double, buttonTop As Double
    Dim buttonWidth As Double, buttonHeight As Double
    If ws Is Nothing Then Exit Sub
    Set area = ws.Range(areaAddress)
    buttonLeft = area.Left + INPUT_BUTTON_INSET_POINTS
    buttonTop = area.Top + INPUT_BUTTON_INSET_POINTS
    buttonWidth = area.Width - (INPUT_BUTTON_INSET_POINTS * 2#)
    buttonHeight = area.Height - (INPUT_BUTTON_INSET_POINTS * 2#)
    If buttonWidth < INPUT_BUTTON_MIN_WIDTH_POINTS Or _
       buttonHeight < INPUT_BUTTON_MIN_HEIGHT_POINTS Then _
        Err.Raise vbObjectError + 2413, "AddInputBarButton", _
                  "入力画面の操作ボタン領域が小さすぎます: " & areaAddress

    AddUIButton ws, buttonLeft, buttonTop, buttonWidth, buttonHeight, _
                caption, macroName, styleName
    buttonName = UIButtonShapeName(mButtonSeq, macroName)
    Set buttonShape = ws.Shapes(buttonName)
    VerifyInputBarButtonGeometry buttonShape, area, buttonLeft, buttonTop, _
                                 buttonWidth, buttonHeight, caption
End Sub

Private Sub EnsureInputOperationRowGeometry(ByVal ws As Worksheet)
    If ws Is Nothing Then Exit Sub
    ws.Rows(INPUT_PANEL_FIRST_ROW).RowHeight = INPUT_BUTTON_ROW_HEIGHT_POINTS
    ws.Rows(INPUT_PANEL_LAST_ROW).RowHeight = INPUT_BUTTON_ROW_HEIGHT_POINTS
    If Abs(CDbl(ws.Rows(INPUT_PANEL_FIRST_ROW).RowHeight) - _
           INPUT_BUTTON_ROW_HEIGHT_POINTS) > INPUT_BUTTON_GEOMETRY_TOLERANCE_POINTS Or _
       Abs(CDbl(ws.Rows(INPUT_PANEL_LAST_ROW).RowHeight) - _
           INPUT_BUTTON_ROW_HEIGHT_POINTS) > INPUT_BUTTON_GEOMETRY_TOLERANCE_POINTS Then _
        Err.Raise vbObjectError + 2414, "EnsureInputOperationRowGeometry", _
                  "入力画面の操作行を所定の高さへ設定できません。"
End Sub

Private Sub VerifyInputBarButtonGeometry(ByVal buttonShape As Shape, _
                                         ByVal area As Range, _
                                         ByVal expectedLeft As Double, _
                                         ByVal expectedTop As Double, _
                                         ByVal expectedWidth As Double, _
                                         ByVal expectedHeight As Double, _
                                         ByVal caption As String)
    Dim shapeRight As Double, shapeBottom As Double
    If buttonShape Is Nothing Or area Is Nothing Then _
        Err.Raise vbObjectError + 2415, "VerifyInputBarButtonGeometry", _
                  "入力画面の操作ボタンを読み戻せません: " & caption

    shapeRight = buttonShape.Left + buttonShape.Width
    shapeBottom = buttonShape.Top + buttonShape.Height
    If buttonShape.Width + 0.01 < INPUT_BUTTON_MIN_WIDTH_POINTS Or _
       buttonShape.Height + 0.01 < INPUT_BUTTON_MIN_HEIGHT_POINTS Then _
        Err.Raise vbObjectError + 2416, "VerifyInputBarButtonGeometry", _
                  "入力画面の操作ボタンが最小寸法を満たしません: " & caption
    '座標の小数値はDPI・標準フォント・Excel描画エンジンで丸められる。
    'セットアップではセル領域から実用上はみ出していないことだけを確認し、
    'ピクセル単位の一致をブック破損として扱わない。
    If buttonShape.Left < area.Left - INPUT_BUTTON_GEOMETRY_TOLERANCE_POINTS Or _
       buttonShape.Top < area.Top - INPUT_BUTTON_GEOMETRY_TOLERANCE_POINTS Or _
       shapeRight > area.Left + area.Width + INPUT_BUTTON_GEOMETRY_TOLERANCE_POINTS Or _
       shapeBottom > area.Top + area.Height + INPUT_BUTTON_GEOMETRY_TOLERANCE_POINTS Then _
        Err.Raise vbObjectError + 2418, "VerifyInputBarButtonGeometry", _
                  "入力画面の操作ボタンが所定領域からはみ出しています: " & caption
End Sub

Public Sub ToggleInputDetails()
    Dim ws As Worksheet
    Dim showDetails As Boolean
    Dim errorNumber As Long, errorSource As String, errorDescription As String
    Dim eventStateDetail As String
    If Not SheetExists(SH_INPUT) Then Exit Sub
    On Error GoTo EH
    Set ws = GetSheet(SH_INPUT)
    showDetails = Not InputDetailsExpanded(ws)
    SetInputDetailsExpanded ws, showDetails, True
    If showDetails Then
        SetInputStatus "開設日・解約日・残高を表示しました。閉じるときは同じボタン、またはCtrl+Shift+Bを使います。"
    Else
        SetInputStatus "通常入力に戻りました。開設日・解約日・残高の値は保持しています。"
    End If
    Exit Sub
EH:
    errorNumber = Err.Number
    errorSource = Err.Source
    errorDescription = Err.Description
    If IsUIRecoveryHardBarrier(errorNumber, errorSource) Then
        '下位のRecovery terminal後は、入力状態欄を含むブック書込みへ進まない。
        'fresh Falseだけを再確認し、元の番号とSourceを呼出元へ返す。
        On Error Resume Next
        Err.Clear
        Call TryConvergeUIEventsFalse(eventStateDetail)
        Err.Clear
        On Error GoTo 0
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    On Error Resume Next
    SetInputStatus "詳細・残高の表示を切り替えられませんでした。Err " & _
                   CStr(errorNumber) & ": " & errorDescription, True
    On Error GoTo 0
End Sub

Private Function IsUIRecoveryHardBarrier( _
        ByVal errorNumber As Long, _
        ByVal errorSource As String) As Boolean
    Dim expectedSource As String

    If errorNumber = vbObjectError + 3599 Or _
       errorNumber = vbObjectError + 4499 Then
        IsUIRecoveryHardBarrier = True
        Exit Function
    End If
    Select Case errorNumber
        Case vbObjectError + 5191
            expectedSource = "AnalysisWorkspaceRecoveryFatal/"
        Case vbObjectError + 5192
            expectedSource = "SetupConvergeRecoveryFatal/"
        Case vbObjectError + 5194
            expectedSource = "CashAnalysisRecoveryFatal/"
        Case vbObjectError + 5195
            expectedSource = "TransactionAnalysisRecoveryFatal/"
        Case vbObjectError + 5196
            expectedSource = "CashManualSelectionRecoveryFatal/"
        Case vbObjectError + 5197
            expectedSource = "ClearRecoveryFatal/"
        Case Else
            Exit Function
    End Select
    If Len(errorSource) < Len(expectedSource) Then Exit Function
    IsUIRecoveryHardBarrier = _
        (StrComp(Left$(errorSource, Len(expectedSource)), expectedSource, _
                 vbBinaryCompare) = 0)
End Function

Private Function TrySetUIEventsFalseExact(ByRef detailText As String) As Boolean
    Dim errorNumber As Long, errorDescription As String
    detailText = vbNullString
    On Error GoTo EH
    Application.EnableEvents = False
    If Application.EnableEvents Then _
        Err.Raise vbObjectError + 2419, "TrySetUIEventsFalseExact", _
                  "EnableEvents=Falseの書込み後読戻しが一致しません。"
    TrySetUIEventsFalseExact = True
    Exit Function
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    detailText = "Err " & CStr(errorNumber) & ": " & errorDescription
    Err.Clear
End Function

Private Function TryConvergeUIEventsFalse(ByRef detailText As String) As Boolean
    Dim firstDetail As String, retryDetail As String
    detailText = vbNullString
    If TrySetUIEventsFalseExact(firstDetail) Then
        TryConvergeUIEventsFalse = True
        Exit Function
    End If
    If TrySetUIEventsFalseExact(retryDetail) Then
        TryConvergeUIEventsFalse = True
        Exit Function
    End If
    detailText = "ExcelイベントをFalseへ収束できません。初回=" & _
                 firstDetail & " / 再試行=" & retryDetail
End Function

Public Sub RefreshMainActionCaption()
    Dim ws As Worksheet
    Dim shp As Shape
    Dim actionName As String
    Dim captionText As String
    Dim expectedAction As String
    Dim useColors As Boolean
    Dim fillColor As Long, lineColor As Long
    If Not SheetExists(SH_INPUT) Then Exit Sub
    Set ws = GetSheet(SH_INPUT)
    On Error GoTo EH
    For Each shp In ws.Shapes
        actionName = ToolShapeActionName(shp)
        captionText = vbNullString
        expectedAction = vbNullString
        useColors = False
        If actionName = "SaveCurrentAccount" Then
            If IsEditMode() Then
                captionText = "訂正を反映"
            Else
                captionText = "この口座を登録"
            End If
            expectedAction = "SaveCurrentAccount"
        ElseIf actionName = "SaveCurrentAccountNextBranch" Or actionName = "CancelCorrection" Then
            If IsEditMode() Then
                captionText = "訂正を中止"
                expectedAction = "CancelCorrection"
            Else
                captionText = "次枝番で登録"
                expectedAction = "SaveCurrentAccountNextBranch"
            End If
        ElseIf actionName = "BuildAllOutputSheets" Then
            expectedAction = "BuildAllOutputSheets"
            useColors = True
            If OutputsAreDirty() Then
                '状態は橙色で示す。狭い画面でも文字を欠けさせないよう冗長な括弧表記は付けない。
                captionText = "帳票・分析を更新"
                fillColor = RGB(180, 83, 9)
                lineColor = RGB(146, 64, 14)
            Else
                captionText = "帳票・分析を再更新"
                fillColor = RGB(30, 41, 59)
                lineColor = RGB(15, 23, 42)
            End If
        ElseIf actionName = "ExportFinalWorkbooks" Then
            expectedAction = "ExportFinalWorkbooks"
            If OutputsAreDirty() Then
                captionText = "更新して最終出力"
            Else
                captionText = "最終出力"
            End If
        ElseIf actionName = "ToggleInputDetails" Then
            expectedAction = "ToggleInputDetails"
            If InputDetailsExpanded(ws) Then
                captionText = "詳細・残高を閉じる"
            Else
                captionText = "詳細・残高を開く"
            End If
        End If
        If Len(captionText) > 0 Then _
            ApplyInputButtonProjection shp, captionText, expectedAction, _
                                       useColors, fillColor, lineColor
    Next shp
    Exit Sub
EH:
    Err.Raise Err.Number, "RefreshMainActionCaption", Err.Description
End Sub

Private Sub ApplyInputButtonProjection( _
        ByVal shp As Shape, ByVal captionText As String, _
        ByVal expectedAction As String, ByVal useColors As Boolean, _
        ByVal fillColor As Long, ByVal lineColor As Long)
    '状態から求めた投影値だけを差分更新し、全必須値をその場で読戻す。
    If shp Is Nothing Then _
        Err.Raise vbObjectError + 2420, "ApplyInputButtonProjection", _
                  "入力ボタンを取得できません。"
    If StrComp(CellText(shp.TextFrame.Characters.Text), captionText, _
               vbBinaryCompare) <> 0 Then _
        shp.TextFrame.Characters.Text = captionText
    If Len(expectedAction) > 0 Then
        If Not ToolShapeActionMatches(shp, expectedAction, True) Then _
            shp.OnAction = MacroRef(expectedAction)
    End If
    If useColors Then
        If CLng(shp.Fill.ForeColor.RGB) <> fillColor Then _
            shp.Fill.ForeColor.RGB = fillColor
        If CLng(shp.Line.ForeColor.RGB) <> lineColor Then _
            shp.Line.ForeColor.RGB = lineColor
        If CLng(shp.TextFrame.Characters.Font.Color) <> RGB(255, 255, 255) Then _
            shp.TextFrame.Characters.Font.Color = RGB(255, 255, 255)
    End If
    If StrComp(CellText(shp.Title), captionText & " ボタン", _
               vbBinaryCompare) <> 0 Or _
       StrComp(CellText(shp.AlternativeText), _
               captionText & "。クリックして実行します。", _
               vbBinaryCompare) <> 0 Then _
        SetToolShapeAccessibleLabel shp, captionText

    If StrComp(CellText(shp.TextFrame.Characters.Text), captionText, _
               vbBinaryCompare) <> 0 Or _
       (Len(expectedAction) > 0 And _
        Not ToolShapeActionMatches(shp, expectedAction, True)) Then _
        Err.Raise vbObjectError + 2421, "ApplyInputButtonProjection", _
                  "入力ボタンの表示または実行先を更新できません: " & captionText
End Sub

Public Sub AddPanelBack(ByVal ws As Worksheet, ByVal x As Double, ByVal y As Double, ByVal w As Double, ByVal h As Double, _
                        Optional ByVal requirePrintState As Boolean = False)
    Dim shp As Shape
    Dim errorNumber As Long, errorDescription As String
    If ws Is Nothing Then Exit Sub
    On Error GoTo EH
    Set shp = ws.Shapes.AddShape(msoShapeRoundedRectangle, x, y, w, h)
    If shp Is Nothing Then _
        Err.Raise vbObjectError + 2402, "AddPanelBack", _
                  "操作パネルの背景を作成できませんでした。"

    '移動防止に必要な項目だけを厳格に設定し、Officeビルド差のある装飾は分離する。
    shp.Name = UI_PREFIX & "panel_back"
    shp.Placement = xlFreeFloating
    shp.Locked = True
    If StrComp(shp.Name, UI_PREFIX & "panel_back", vbTextCompare) <> 0 Or _
       Not shp.Locked Or shp.Placement <> xlFreeFloating Then _
        Err.Raise vbObjectError + 2403, "AddPanelBack", _
                  "操作パネル背景の固定状態を確認できませんでした。"
    If Not SetToolShapePrintState(ws, shp.Name, False) Then
        If requirePrintState Then _
            Err.Raise vbObjectError + 2404, "AddPanelBack", _
                      "パネル背景を印刷対象外にできません。"
    End If
    ApplyUIPanelAppearance shp
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    On Error Resume Next
    If Not shp Is Nothing Then shp.Delete
    On Error GoTo 0
    Err.Raise errorNumber, "AddPanelBack", errorDescription
End Sub

Private Sub ApplyUIPanelAppearance(ByVal shp As Shape)
    '影や線の一部はOfficeビルド・描画方式によって利用できないことがある。
    '見た目の差だけでセットアップを中断せず、固定・保護は呼出元で厳格検査する。
    If shp Is Nothing Then Exit Sub
    On Error Resume Next
    With shp
        .Fill.ForeColor.RGB = RGB(255, 255, 255)
        .Line.ForeColor.RGB = RGB(203, 213, 225)
        .Line.Weight = 1
        .ZOrder msoSendToBack
        .Shadow.Visible = msoTrue
        .Shadow.Transparency = 0.88
        .Shadow.Blur = 7
        .Shadow.OffsetX = 0
        .Shadow.OffsetY = 2
    End With
    Err.Clear
    On Error GoTo 0
End Sub

Public Sub AddUIButton(ByVal ws As Worksheet, ByVal x As Double, ByVal y As Double, ByVal w As Double, ByVal h As Double, ByVal caption As String, ByVal macroName As String, ByVal styleName As String, _
                       Optional ByVal requirePrintState As Boolean = False)
    Dim shp As Shape
    Dim buttonShape As Shape
    Dim btn As Object
    Dim fillColor As Long, lineColor As Long, fontColor As Long
    Dim expectedName As String
    Dim shapeError As String, buttonError As String, coreError As String, cleanupError As String
    If ws Is Nothing Then Exit Sub
    GetButtonColors styleName, fillColor, lineColor, fontColor
    fontColor = ReadableFontColor(fillColor, fontColor)

    '作成・動作・実効Fill/文字色を厳格に設定する。
    '余白・影・線など可読性を左右しない装飾だけをbest-effortに分離する。
    On Error Resume Next
    Err.Clear
    Set shp = ws.Shapes.AddShape(msoShapeRoundedRectangle, x, y, w, h)
    If Err.Number <> 0 Then shapeError = "図形作成 Err " & CStr(Err.Number) & ": " & Err.Description
    Err.Clear
    On Error GoTo 0
    If Not shp Is Nothing Then
        mButtonSeq = mButtonSeq + 1
        expectedName = UIButtonShapeName(mButtonSeq, macroName)
        On Error Resume Next
        Err.Clear
        shp.Name = expectedName
        shp.TextFrame.Characters.Text = caption
        shp.Placement = xlFreeFloating
        shp.Locked = True
        shp.OnAction = MacroRef(macroName)
        If Err.Number <> 0 Then
            coreError = "図形の必須設定 Err " & CStr(Err.Number) & ": " & Err.Description
        End If
        Err.Clear
        On Error GoTo 0

        If Len(coreError) = 0 Then
            On Error Resume Next
            Err.Clear
            ApplyUIButtonAppearance shp, h, fillColor, lineColor, fontColor
            If Err.Number <> 0 Then _
                coreError = "図形ボタンの色設定・読戻しに失敗: " & Err.Description
            Err.Clear
            On Error GoTo 0
        End If
        If Len(coreError) = 0 Then
            SetToolShapeAccessibleLabel shp, caption
            If Not SetToolShapePrintState(ws, shp.Name, False) Then
                'セットアップ時は旧DrawingObjects APIの利用可否で画面作成を止めない。
                '資金操作表の印刷直前だけ、別経路で非印刷を必須検査する。
                If requirePrintState Then coreError = "図形ボタンを印刷対象外にできません"
            End If
        End If
        If Len(coreError) = 0 Then
            On Error Resume Next
            Err.Clear
            If StrComp(shp.Name, expectedName, vbTextCompare) <> 0 Then
                coreError = "図形ボタンの名前検証に失敗"
            ElseIf StrComp(CellText(shp.TextFrame.Characters.Text), caption, vbBinaryCompare) <> 0 Then
                coreError = "図形ボタンの表示検証に失敗"
            ElseIf Not shp.Locked Then
                coreError = "図形ボタンをロックできません"
            ElseIf shp.Placement <> xlFreeFloating Then
                coreError = "図形ボタンの配置方式を固定できません"
            ElseIf Not ToolShapeActionMatches(shp, macroName, True) Then
                coreError = "図形ボタンの実行先検証に失敗"
            End If
            If Err.Number <> 0 Then _
                coreError = "図形ボタンの必須設定を読み戻せません: " & Err.Description
            Err.Clear
            On Error GoTo 0
        End If
        If Len(coreError) > 0 Then shapeError = coreError
    ElseIf Len(shapeError) = 0 Then
        shapeError = "図形を作成できませんでした"
    End If
    If Not shp Is Nothing Then
        If Len(shapeError) = 0 Then Exit Sub
    End If

    On Error Resume Next
    If Not shp Is Nothing Then
        Err.Clear
        shp.Delete
        If Err.Number = 0 Then
            If mButtonSeq > 0 Then mButtonSeq = mButtonSeq - 1
        Else
            cleanupError = "失敗した図形を削除できません Err " & _
                           CStr(Err.Number) & ": " & Err.Description
        End If
    End If
    On Error GoTo 0
    If Len(cleanupError) > 0 Then _
        Err.Raise vbObjectError + 2405, "AddUIButton", _
                  shapeError & " / " & cleanupError

    On Error Resume Next
    Err.Clear
    Set btn = ws.Buttons.Add(x, y, w, h)
    If Err.Number <> 0 Then _
        buttonError = "フォームボタン作成 Err " & CStr(Err.Number) & ": " & Err.Description
    Err.Clear
    On Error GoTo 0
    If Not btn Is Nothing Then
        mButtonSeq = mButtonSeq + 1
        expectedName = UIButtonShapeName(mButtonSeq, macroName)
        On Error Resume Next
        Err.Clear
        btn.Name = expectedName
        btn.Caption = caption
        btn.OnAction = MacroRef(macroName)
        btn.Locked = True
        btn.Placement = xlFreeFloating
        If Err.Number <> 0 Then
            buttonError = "フォームボタンの必須設定 Err " & CStr(Err.Number) & ": " & Err.Description
        End If
        Err.Clear
        On Error GoTo 0
        If Len(buttonError) = 0 Then
            On Error Resume Next
            Err.Clear
            Set buttonShape = ws.Shapes(btn.Name)
            If Err.Number <> 0 Then
                buttonError = "フォームボタンの図形情報取得 Err " & _
                              CStr(Err.Number) & ": " & Err.Description
            ElseIf buttonShape Is Nothing Then
                buttonError = "フォームボタンの図形情報を取得できません"
            End If
            Err.Clear
            On Error GoTo 0
        End If
        If Len(buttonError) = 0 Then
            If Not buttonShape Is Nothing Then
                'フォームコントロールはOSテーマが実効背景・文字色を描画する。
                'Shape.Fillを上書きせず、システム既定の可読性へ委ねる。
                SetToolShapeAccessibleLabel buttonShape, caption
                If Not SetToolShapePrintState(ws, btn.Name, False) Then
                    If requirePrintState Then buttonError = "フォームボタンを印刷対象外にできません"
                End If
            End If
        End If
        If Len(buttonError) = 0 Then
            On Error Resume Next
            Err.Clear
            If StrComp(btn.Name, expectedName, vbTextCompare) <> 0 Then
                buttonError = "フォームボタンの名前検証に失敗"
            ElseIf StrComp(CellText(btn.Caption), caption, vbBinaryCompare) <> 0 Then
                buttonError = "フォームボタンの表示検証に失敗"
            ElseIf Not btn.Locked Then
                buttonError = "フォームボタンをロックできません"
            ElseIf btn.Placement <> xlFreeFloating Then
                buttonError = "フォームボタンの配置方式を固定できません"
            ElseIf Not ToolShapeActionMatches(buttonShape, macroName, True) Then
                buttonError = "フォームボタンの実行先検証に失敗"
            End If
            If Err.Number <> 0 Then _
                buttonError = "フォームボタンの必須設定を読み戻せません: " & Err.Description
            Err.Clear
            On Error GoTo 0
        End If
    ElseIf Len(buttonError) = 0 Then
        buttonError = "フォームボタンを作成できませんでした"
    End If
    If Not btn Is Nothing Then
        If Len(buttonError) = 0 Then Exit Sub
    End If

    On Error Resume Next
    If Not btn Is Nothing Then
        Err.Clear
        btn.Delete
        If Err.Number <> 0 Then _
            buttonError = buttonError & " / 失敗したフォームボタンを削除できません Err " & _
                          CStr(Err.Number) & ": " & Err.Description
    End If
    On Error GoTo 0
    Err.Raise vbObjectError + 2401, "AddUIButton", _
              "操作ボタンを作成できません: " & caption & " / " & shapeError & " / " & buttonError
End Sub

Private Sub ApplyUIButtonAppearance(ByVal shp As Shape, ByVal heightValue As Double, _
                                    ByVal fillColor As Long, ByVal lineColor As Long, _
                                    ByVal fontColor As Long)
    '余白・影・線はbest-effortだが、可読性を決めるFillと文字色は必須とし、
    '設定値と4.5:1以上の実効コントラストを読み戻す。
    Dim errorNumber As Long, errorDescription As String
    If shp Is Nothing Then _
        Err.Raise vbObjectError + 2406, "ApplyUIButtonAppearance", _
                  "操作ボタンを取得できません。"
    On Error Resume Next
    With shp
        .TextFrame.HorizontalAlignment = xlHAlignCenter
        .TextFrame.VerticalAlignment = xlVAlignCenter
        .TextFrame.MarginLeft = 2
        .TextFrame.MarginRight = 2
        .TextFrame.MarginTop = 0
        .TextFrame.MarginBottom = 0
        .TextFrame.Characters.Font.Name = "Yu Gothic UI"
        .TextFrame.Characters.Font.Size = IIf(heightValue >= 30, 10.5, 9.5)
        .TextFrame.Characters.Font.Bold = True
        .Line.ForeColor.RGB = lineColor
        .Line.Weight = 0.8
        .Shadow.Visible = msoFalse
    End With
    Err.Clear
    On Error GoTo 0
    On Error GoTo EH
    shp.Fill.Visible = msoTrue
    shp.Fill.Solid
    shp.Fill.ForeColor.RGB = fillColor
    shp.Fill.Transparency = 0
    shp.TextFrame.Characters.Font.Color = fontColor
    If shp.Fill.Visible = msoFalse Then _
        Err.Raise vbObjectError + 2407, "ApplyUIButtonAppearance", _
                  "操作ボタンの背景を表示状態へ設定できません。"
    If CLng(shp.Fill.ForeColor.RGB) <> fillColor Then _
        Err.Raise vbObjectError + 2408, "ApplyUIButtonAppearance", _
                  "操作ボタンの背景色を設定値どおりに読み戻せません。"
    If CLng(shp.Fill.Type) <> msoFillSolid Or _
       Abs(CDbl(shp.Fill.Transparency)) > 0.000001 Then _
        Err.Raise vbObjectError + 2408, "ApplyUIButtonAppearance", _
                  "操作ボタンの背景を不透明な単色として読み戻せません。"
    If CLng(shp.TextFrame.Characters.Font.Color) <> fontColor Then _
        Err.Raise vbObjectError + 2409, "ApplyUIButtonAppearance", _
                  "操作ボタンの文字色を設定値どおりに読み戻せません。"
    EnsureToolShapeTextContrast shp
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    Err.Raise errorNumber, "ApplyUIButtonAppearance", errorDescription
End Sub

Private Sub GetButtonColors(ByVal styleName As String, ByRef fillColor As Long, ByRef lineColor As Long, ByRef fontColor As Long)
    fontColor = RGB(15, 23, 42)
    Select Case LCase$(styleName)
        Case "hero"
            fillColor = RGB(30, 41, 59)
            lineColor = RGB(15, 23, 42)
            fontColor = RGB(255, 255, 255)
        Case "primary"
            fillColor = RGB(15, 118, 110)
            lineColor = RGB(13, 148, 136)
            fontColor = RGB(255, 255, 255)
        Case "accent"
            fillColor = RGB(14, 116, 144)
            lineColor = RGB(21, 94, 117)
            fontColor = RGB(255, 255, 255)
        Case "export"
            fillColor = RGB(51, 65, 85)
            lineColor = RGB(30, 41, 59)
            fontColor = RGB(255, 255, 255)
        Case "danger"
            fillColor = RGB(220, 38, 38)
            lineColor = RGB(220, 38, 38)
            fontColor = RGB(255, 255, 255)
        Case "neutral"
            fillColor = RGB(241, 245, 249)
            lineColor = RGB(203, 213, 225)
            fontColor = RGB(15, 23, 42)
        Case "tool"
            fillColor = RGB(255, 255, 255)
            lineColor = RGB(203, 213, 225)
            fontColor = RGB(51, 65, 85)
        Case "soft"
            fillColor = RGB(248, 250, 252)
            lineColor = RGB(226, 232, 240)
            fontColor = RGB(51, 65, 85)
        Case Else
            fillColor = RGB(248, 250, 252)
            lineColor = RGB(203, 213, 225)
            fontColor = RGB(15, 23, 42)
    End Select
End Sub

Public Sub AddConfigButton(ByVal ws As Worksheet, ByVal cellAddress As String, ByVal caption As String, _
                           ByVal macroName As String, Optional ByVal styleName As String = "tool")
    Dim a As Range
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    Set a = ws.Range(cellAddress)
    On Error GoTo 0
    If a Is Nothing Then Exit Sub
    '設定シートは印刷対象外。PrintObjectの旧APIを使えない環境でも、
    'ボタンの作成・実行先・ロック・シート保護は必須のままセットアップを継続する。
    AddUIButton ws, a.Left, a.Top, 150, 30, caption, macroName, styleName, False
End Sub

Public Sub BuildInputHelpCards(ByVal ws As Worksheet)
    '旧版互換用。右上メニューの下は残高入力欄と共有されるため、セルの結合、
    '内容、書式には一切触れない。画面復旧が入力済み残高を変えないことを優先する。
    If ws Is Nothing Then Exit Sub
End Sub

Public Sub RefreshButtonActions()
    'SaveAs後にブック名が変わっても、図形ボタンの参照先を現在のThisWorkbookへ張り直す。
    Dim ws As Worksheet
    Dim shp As Shape
    Dim macroName As String
    On Error GoTo EH
    For Each ws In ThisWorkbook.Worksheets
        For Each shp In ws.Shapes
            If Left$(shp.Name, Len(UI_PREFIX & "btn_")) = UI_PREFIX & "btn_" Then
                '診断モードではOnActionをShowRecoveryNoticeへ一時退避する。
                '正常復旧時は図形名の__以降に保持した正規動作を優先して戻す。
                macroName = StoredUIButtonActionName(shp)
                If Len(macroName) = 0 Then macroName = ToolShapeActionName(shp)
                If Len(macroName) > 0 Then
                    If Not ToolShapeActionMatches(shp, macroName, True) Then _
                        shp.OnAction = MacroRef(macroName)
                    If Not ToolShapeActionMatches(shp, macroName, True) Then _
                        Err.Raise vbObjectError + 2422, "RefreshButtonActions", _
                                  "操作ボタンの実行先を更新できません: " & _
                                  ws.Name & " / " & shp.Name
                End If
            End If
        Next shp
    Next ws
    Exit Sub
EH:
    Err.Raise Err.Number, "RefreshButtonActions", Err.Description
End Sub

Public Sub RefreshButtonActionsStrict()
    '保存へ確定するOnActionは全ボタンを再設定し、現在のThisWorkbookを
    '参照していることまで読み戻す。1件でも不明なら保存を成功扱いしない。
    Dim ws As Worksheet
    Dim shp As Shape
    Dim macroName As String, storedMacroName As String
    Dim dynamicCaptionText As String
    Dim editModeActive As Boolean
    Dim dynamicActionCount As Long
    Dim errorNumber As Long, errorDescription As String
    Dim targetText As String

    On Error GoTo EH
    editModeActive = IsEditMode()
    For Each ws In ThisWorkbook.Worksheets
        For Each shp In ws.Shapes
            If Left$(shp.Name, Len(UI_PREFIX & "btn_")) = UI_PREFIX & "btn_" Then
                targetText = ws.Name & " / " & shp.Name
                storedMacroName = StoredUIButtonActionName(shp)
                macroName = storedMacroName
                dynamicCaptionText = vbNullString
                If Len(macroName) = 0 Then macroName = ToolShapeActionName(shp)
                If StrComp(storedMacroName, _
                           "SaveCurrentAccountNextBranch", vbBinaryCompare) = 0 Then
                    dynamicActionCount = dynamicActionCount + 1
                    If editModeActive Then
                        macroName = "CancelCorrection"
                        dynamicCaptionText = "訂正を中止"
                    Else
                        macroName = "SaveCurrentAccountNextBranch"
                        dynamicCaptionText = "次枝番で登録"
                    End If
                End If
                If Len(macroName) = 0 Then _
                    Err.Raise vbObjectError + 2410, "RefreshButtonActionsStrict", _
                              "操作ボタンの動作名を取得できません: " & targetText
                shp.OnAction = MacroRef(macroName)
                If Not ToolShapeActionMatches(shp, macroName, True) Then _
                    Err.Raise vbObjectError + 2411, "RefreshButtonActionsStrict", _
                              "操作ボタンの実行先を現在のブックへ設定できません: " & targetText
                If Len(dynamicCaptionText) > 0 Then
                    shp.TextFrame.Characters.Text = dynamicCaptionText
                    If StrComp(CellText(shp.TextFrame.Characters.Text), _
                               dynamicCaptionText, vbBinaryCompare) <> 0 Then _
                        Err.Raise vbObjectError + 2420, "RefreshButtonActionsStrict", _
                                  "訂正中／通常時のボタン表示を設定値どおりに読み戻せません: " & _
                                  targetText
                    SetToolShapeAccessibleLabel shp, dynamicCaptionText
                End If
                '保存前処理の責務は実行先の確定であり、Office描画APIの色読戻しではない。
                '可読色への補正は作成・書式復旧時に行い、取得不能だけで保存を止めない。
                On Error Resume Next
                EnsureToolShapeTextContrast shp, targetText
                Err.Clear
                On Error GoTo EH
            End If
        Next shp
    Next ws
    If dynamicActionCount <> 1 Then _
        Err.Raise vbObjectError + 2419, "RefreshButtonActionsStrict", _
                  "訂正中／通常時の動作を切り替える入力ボタンを一意に取得できません。件数=" & _
                  CStr(dynamicActionCount)
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    Err.Raise errorNumber, "RefreshButtonActionsStrict(" & targetText & ")", _
              errorDescription
End Sub

Private Function StoredUIButtonActionName(ByVal shp As Shape) As String
    Dim markerPos As Long
    If shp Is Nothing Then Exit Function
    markerPos = InStrRev(CellText(shp.Name), "__", -1, vbBinaryCompare)
    If markerPos > 0 Then _
        StoredUIButtonActionName = Trim$(Mid$(CellText(shp.Name), markerPos + 2))
End Function

Public Sub FormatHeader(ByVal rng As Range, Optional ByVal fillColor As Long = 0)
    If rng Is Nothing Then Exit Sub
    If fillColor = 0 Then fillColor = RGB(226, 232, 240)
    With rng
        .Font.Name = "Yu Gothic UI"
        .Font.Bold = True
        .Font.Color = RGB(15, 23, 42)
        .Interior.Color = fillColor
        .Borders.LineStyle = xlContinuous
        .Borders.Color = RGB(203, 213, 225)
        .VerticalAlignment = xlCenter
    End With
End Sub

Public Sub FormatOutputHeader(ByVal rng As Range)
    If rng Is Nothing Then Exit Sub
    With rng
        .Font.Name = "Yu Gothic UI"
        .Font.Bold = True
        .Font.Size = 11
        .Font.Color = RGB(255, 255, 255)
        .Interior.Color = RGB(30, 64, 175)
        .HorizontalAlignment = xlCenter
        .VerticalAlignment = xlCenter
        .WrapText = True
        .ShrinkToFit = False
        .Borders.LineStyle = xlContinuous
        .Borders.Color = RGB(147, 197, 253)
    End With
    '各画面が明示した高い行を縮めず、折返し見出しの最低高さだけを保証する。
    If rng.Rows.Count = 1 Then
        If CDbl(rng.Rows.RowHeight) < 30 Then rng.Rows.RowHeight = 30
    End If
End Sub

﻿Attribute VB_Name = "modCandidates"
Option Explicit

Private mCandidateBatchDepth As Long
Private mCandidateBatchRows As Object
Private mCandidateBatchRelationshipByID As Object
Private mCandidateBatchPersonRowByNameID As Object
Private mCandidateBatchAssignedRowByIdentity As Object
Private mCandidateBatchAssignedIDByIdentity As Object
Private mCandidateBatchRegisteredIDByIdentity As Object
Private mCandidateBatchBlankRowByIdentity As Object
Private mCandidateBatchBlankRowByName As Object
Private mCandidateEditableThrough As Object
Private Const MAX_CANDIDATE_DATA_ROWS As Long = 100000
Private Const CANDIDATE_EDIT_BUFFER_ROWS As Long = 500
Private Const CANDIDATE_LOCK_BUFFER_ROWS As Long = 100
Private Const CANDIDATE_RECOVERY_HARD_BARRIER_ERROR As Long = _
    vbObjectError + 4499
Private Const CANDIDATE_RECOVERY_HARD_BARRIER_SOURCE As String = _
    "CandidateRecoveryFatal/"

Private Function CandidateProtectionMarkerName(ByVal sheetName As String) As String
    Select Case sheetName
        Case SH_BANK_CAND: CandidateProtectionMarkerName = "_cand_edit_bank"
        Case SH_BRANCH_CAND: CandidateProtectionMarkerName = "_cand_edit_branch"
        Case SH_PERSON_CAND: CandidateProtectionMarkerName = "_cand_edit_person"
        Case SH_ACCOUNT_TYPE: CandidateProtectionMarkerName = "_cand_edit_account_type"
        Case SH_TEKIYO: CandidateProtectionMarkerName = "_cand_edit_tekiyo"
    End Select
End Function

Private Function StoredCandidateEditableLastRow(ByVal ws As Worksheet) As Long
    'VBEのReset等でモジュール変数が消えても、以前開放した末尾まで確実に再ロックできるよう
    'ブック内の非表示名から直近の保護範囲を復元する。
    Dim markerName As String, refersText As String
    Dim markerValue As Double
    On Error GoTo MissingMarker
    If ws Is Nothing Then Exit Function
    markerName = CandidateProtectionMarkerName(ws.Name)
    If Len(markerName) = 0 Then Exit Function
    refersText = ThisWorkbook.Names(markerName).RefersTo
    If Left$(refersText, 1) = "=" Then refersText = Mid$(refersText, 2)
    If Not IsNumeric(refersText) Then Exit Function
    markerValue = CDbl(refersText)
    If markerValue <> Fix(markerValue) Then Exit Function
    If markerValue < 2 Or markerValue > MAX_CANDIDATE_DATA_ROWS + 1 Then Exit Function
    StoredCandidateEditableLastRow = CLng(markerValue)
MissingMarker:
End Function

Private Sub StoreCandidateEditableLastRow(ByVal ws As Worksheet, ByVal editableLastRow As Long)
    Dim markerName As String
    Dim marker As Name
    If ws Is Nothing Then Exit Sub
    markerName = CandidateProtectionMarkerName(ws.Name)
    If Len(markerName) = 0 Then Exit Sub
    On Error Resume Next
    Set marker = ThisWorkbook.Names(markerName)
    On Error GoTo 0
    If marker Is Nothing Then
        ThisWorkbook.Names.Add Name:=markerName, RefersTo:="=" & CStr(editableLastRow), Visible:=False
    Else
        marker.RefersTo = "=" & CStr(editableLastRow)
    End If
End Sub

Public Sub BeginCandidateBatchUpdate()
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim eventStateDetail As String
    On Error GoTo EH
    If mCandidateBatchDepth = 0 Then BuildCandidateBatchIndex
    mCandidateBatchDepth = mCandidateBatchDepth + 1
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    If IsCandidateRecoveryHardBarrier(errorNumber, errorSource) Then
        Call TryStopCandidateEventsForBookWrites(eventStateDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    mCandidateBatchDepth = 0
    ClearCandidateBatchIndexes
    If Len(errorSource) = 0 Then errorSource = "BeginCandidateBatchUpdate"
    Err.Raise errorNumber, errorSource, errorDescription
End Sub

Public Sub EndCandidateBatchUpdate()
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim eventStateDetail As String
    If mCandidateBatchDepth > 0 Then mCandidateBatchDepth = mCandidateBatchDepth - 1
    If mCandidateBatchDepth = 0 Then
        On Error GoTo CleanUp
        ConvergeCandidateBatchBlankRelationships
        RefreshAllCandidateNames
CleanUp:
        errorNumber = Err.Number
        errorDescription = Err.Description
        errorSource = Err.Source
        If errorNumber <> 0 Then
            If IsCandidateRecoveryHardBarrier(errorNumber, errorSource) Then
                Call TryStopCandidateEventsForBookWrites(eventStateDetail)
                Err.Raise errorNumber, errorSource, errorDescription
            End If
            ClearCandidateBatchIndexes
            If Len(errorSource) = 0 Then errorSource = "EndCandidateBatchUpdate"
            Err.Raise errorNumber, errorSource, errorDescription
        End If
        ClearCandidateBatchIndexes
    End If
End Sub

Private Sub ClearCandidateBatchIndexes()
    Set mCandidateBatchRows = Nothing
    Set mCandidateBatchRelationshipByID = Nothing
    Set mCandidateBatchPersonRowByNameID = Nothing
    Set mCandidateBatchAssignedRowByIdentity = Nothing
    Set mCandidateBatchAssignedIDByIdentity = Nothing
    Set mCandidateBatchRegisteredIDByIdentity = Nothing
    Set mCandidateBatchBlankRowByIdentity = Nothing
    Set mCandidateBatchBlankRowByName = Nothing
End Sub

Private Sub BuildCandidateBatchIndex()
    Set mCandidateBatchRows = CreateObject("Scripting.Dictionary")
    mCandidateBatchRows.CompareMode = vbTextCompare
    Set mCandidateBatchRelationshipByID = NewCandidateBatchDictionary()
    Set mCandidateBatchPersonRowByNameID = NewCandidateBatchDictionary()
    Set mCandidateBatchAssignedRowByIdentity = NewCandidateBatchDictionary()
    Set mCandidateBatchAssignedIDByIdentity = NewCandidateBatchDictionary()
    Set mCandidateBatchRegisteredIDByIdentity = NewCandidateBatchDictionary()
    Set mCandidateBatchBlankRowByIdentity = NewCandidateBatchDictionary()
    Set mCandidateBatchBlankRowByName = NewCandidateBatchDictionary()
    IndexCandidateSheet SH_BANK_CAND
    IndexCandidateSheet SH_BRANCH_CAND
    IndexCandidateSheet SH_PERSON_CAND
    IndexCandidateSheet SH_ACCOUNT_TYPE
    IndexCandidateSheet SH_TEKIYO
    IndexRegisteredPersonRelationships
End Sub

Private Function NewCandidateBatchDictionary() As Object
    Dim result As Object
    Set result = CreateObject("Scripting.Dictionary")
    result.CompareMode = vbTextCompare
    Set NewCandidateBatchDictionary = result
End Function

Private Sub IndexCandidateSheet(ByVal sheetName As String)
    Dim ws As Worksheet, lastR As Long, r As Long
    Dim valueText As String, keyText As String
    Dim candidateData As Variant
    If Not SheetExists(sheetName) Then Exit Sub
    Set ws = GetSheet(sheetName)
    lastR = LastRow(ws, 1)
    If lastR < 2 Then Exit Sub
    '共通データ取込では最大10万行を索引化するため、セル単位のCOM読取を避ける。
    candidateData = ws.Range(ws.Cells(2, 1), ws.Cells(lastR, 4)).Value2
    For r = 1 To UBound(candidateData, 1)
        valueText = CellText(candidateData(r, 1))
        If Len(valueText) > 0 Then
            If sheetName = SH_PERSON_CAND Then
                keyText = CandidateBatchKey(sheetName, valueText, CellText(candidateData(r, 2)), _
                                            CellText(candidateData(r, 3)))
                IndexCandidateBatchPersonRow r + 1, valueText, CellText(candidateData(r, 2)), _
                                             CellText(candidateData(r, 3)), _
                                             sheetName & " " & CStr(r + 1) & "行"
            Else
                keyText = CandidateBatchKey(sheetName, valueText)
            End If
            If Not mCandidateBatchRows.Exists(keyText) Then mCandidateBatchRows.Add keyText, r + 1
        End If
    Next r
End Sub

Private Sub IndexRegisteredPersonRelationships()
    Dim ws As Worksheet
    Dim lastR As Long, r As Long
    Dim sourceData As Variant
    Dim personID As String, personName As String, relationshipText As String
    If Not SheetExists(SH_WORK_ACCOUNT) Then Exit Sub
    Set ws = GetSheet(SH_WORK_ACCOUNT)
    lastR = LastDataRowInColumns(ws, ACC_COL_ID, ACC_COL_TRANSFER_ID)
    If lastR < 2 Then Exit Sub
    sourceData = ws.Range(ws.Cells(2, ACC_COL_PERSON), _
                          ws.Cells(lastR, ACC_COL_PERSON_ID)).Value2
    For r = 1 To UBound(sourceData, 1)
        personName = CellText(sourceData(r, 1))
        relationshipText = CellText( _
                               sourceData(r, ACC_COL_RELATIONSHIP - ACC_COL_PERSON + 1))
        personID = CellText( _
                       sourceData(r, ACC_COL_PERSON_ID - ACC_COL_PERSON + 1))
        AddCandidateBatchRelationship personID, relationshipText, _
                                      SH_WORK_ACCOUNT & " " & CStr(r + 1) & "行"
        IndexCandidateBatchRegisteredIdentity personName, personID, relationshipText, _
                                              SH_WORK_ACCOUNT & " " & CStr(r + 1) & "行"
    Next r
End Sub

Private Sub IndexCandidateBatchRegisteredIdentity( _
        ByVal personName As String, ByVal personID As String, _
        ByVal relationshipText As String, ByVal sourceText As String)
    Dim identityKey As String, existingID As String
    personID = CellText(personID)
    identityKey = PersonIdentityKey(personName, relationshipText)
    If Len(identityKey) = 0 Or Len(personID) = 0 Then Exit Sub
    If mCandidateBatchRegisteredIDByIdentity Is Nothing Then _
        Err.Raise vbObjectError + 2139, "BuildCandidateBatchIndex", _
                  "登録済み人物の同一性索引を作成できません。"
    If mCandidateBatchAssignedIDByIdentity.Exists(identityKey) Then
        existingID = CStr(mCandidateBatchAssignedIDByIdentity(identityKey))
        If StrComp(existingID, personID, vbTextCompare) <> 0 Then _
            Err.Raise vbObjectError + 2135, "BuildCandidateBatchIndex", _
                      "同じ氏名・続柄に異なる人物IDがあります（" & _
                      sourceText & "）。先に該当する口座・人物の登録内容を確認してください。"
    End If
    If mCandidateBatchRegisteredIDByIdentity.Exists(identityKey) Then
        existingID = CStr(mCandidateBatchRegisteredIDByIdentity(identityKey))
        If StrComp(existingID, personID, vbTextCompare) <> 0 Then _
            Err.Raise vbObjectError + 2135, "BuildCandidateBatchIndex", _
                      "登録済み口座の同じ氏名・続柄に異なる人物IDがあります（" & _
                      sourceText & "）。先に該当する口座・人物の登録内容を確認してください。"
    Else
        mCandidateBatchRegisteredIDByIdentity.Add identityKey, personID
    End If
End Sub

Private Sub AddCandidateBatchRelationship(ByVal personID As String, _
                                          ByVal relationshipText As String, _
                                          ByVal sourceText As String)
    Dim relationshipKey As String, storedRelationship As String
    personID = CellText(personID)
    If Len(personID) = 0 Then Exit Sub
    If Not IsInternalIdValue(personID, "P") Then _
        Err.Raise vbObjectError + 2131, "BuildCandidateBatchIndex", _
                  "人物IDの形式が不正です（" & sourceText & "）: " & personID
    relationshipText = CellText(relationshipText)
    relationshipKey = NormalizeRelationshipKey(relationshipText)
    If Len(relationshipKey) = 0 Then Exit Sub
    If mCandidateBatchRelationshipByID.Exists(personID) Then
        storedRelationship = CStr(mCandidateBatchRelationshipByID(personID))
        If NormalizeRelationshipKey(storedRelationship) <> relationshipKey Then _
            Err.Raise vbObjectError + 2132, "BuildCandidateBatchIndex", _
                      "同一人物IDに異なる続柄があります（" & sourceText & "）: " & personID
    Else
        mCandidateBatchRelationshipByID.Add personID, relationshipText
    End If
End Sub

Private Sub IndexCandidateBatchPersonRow(ByVal rowNo As Long, ByVal personName As String, _
                                         ByVal personID As String, ByVal relationshipText As String, _
                                         ByVal sourceText As String)
    Dim nameKey As String, nameIDKey As String, identityKey As String
    Dim storedRow As Long
    nameKey = NormalizePersonNameKey(personName)
    If Len(nameKey) = 0 Or rowNo < 2 Then Exit Sub
    personID = CellText(personID)
    identityKey = PersonIdentityKey(personName, relationshipText)
    If Len(personID) > 0 Then
        AddCandidateBatchRelationship personID, relationshipText, sourceText
        nameIDKey = nameKey & Chr$(29) & UCase$(personID)
        If mCandidateBatchPersonRowByNameID.Exists(nameIDKey) Then
            storedRow = CLng(mCandidateBatchPersonRowByNameID(nameIDKey))
            If rowNo < storedRow Then mCandidateBatchPersonRowByNameID(nameIDKey) = rowNo
        Else
            mCandidateBatchPersonRowByNameID.Add nameIDKey, rowNo
        End If
        If mCandidateBatchAssignedIDByIdentity.Exists(identityKey) Then
            If StrComp(CStr(mCandidateBatchAssignedIDByIdentity(identityKey)), _
                       personID, vbTextCompare) <> 0 Then _
                Err.Raise vbObjectError + 2135, "BuildCandidateBatchIndex", _
                          "同じ氏名・続柄に異なる人物IDがあります（" & _
                          sourceText & "）。先に該当する口座・人物の登録内容を確認してください。"
            storedRow = CLng(mCandidateBatchAssignedRowByIdentity(identityKey))
            If rowNo < storedRow Then
                mCandidateBatchAssignedIDByIdentity(identityKey) = personID
                mCandidateBatchAssignedRowByIdentity(identityKey) = rowNo
            End If
        Else
            mCandidateBatchAssignedIDByIdentity.Add identityKey, personID
            mCandidateBatchAssignedRowByIdentity.Add identityKey, rowNo
        End If
    Else
        AddCandidateBatchQueuedRow mCandidateBatchBlankRowByIdentity, identityKey, rowNo
        If Len(NormalizeRelationshipKey(relationshipText)) = 0 Then
            AddCandidateBatchQueuedRow mCandidateBatchBlankRowByName, nameKey, rowNo
        End If
    End If
End Sub

Private Sub AddCandidateBatchQueuedRow(ByVal queueIndex As Object, ByVal keyText As String, _
                                       ByVal rowNo As Long)
    Dim queuedRows As Collection
    If queueIndex Is Nothing Or Len(keyText) = 0 Or rowNo < 2 Then Exit Sub
    If queueIndex.Exists(keyText) Then
        Set queuedRows = queueIndex(keyText)
    Else
        Set queuedRows = New Collection
        queueIndex.Add keyText, queuedRows
    End If
    queuedRows.Add rowNo
End Sub

Private Function CandidateBatchFirstQueuedRow(ByVal queueIndex As Object, _
                                              ByVal keyText As String) As Long
    Dim queuedRows As Collection
    If queueIndex Is Nothing Or Len(keyText) = 0 Then Exit Function
    If Not queueIndex.Exists(keyText) Then Exit Function
    Set queuedRows = queueIndex(keyText)
    If queuedRows.Count > 0 Then CandidateBatchFirstQueuedRow = CLng(queuedRows(1))
End Function

Private Sub RemoveCandidateBatchQueuedHead(ByVal queueIndex As Object, ByVal keyText As String, _
                                           ByVal rowNo As Long)
    Dim queuedRows As Collection
    If queueIndex Is Nothing Or Len(keyText) = 0 Or rowNo < 2 Then Exit Sub
    If Not queueIndex.Exists(keyText) Then Exit Sub
    Set queuedRows = queueIndex(keyText)
    If queuedRows.Count > 0 Then
        If CLng(queuedRows(1)) = rowNo Then queuedRows.Remove 1
    End If
    If queuedRows.Count = 0 Then queueIndex.Remove keyText
End Sub

Private Function ValidatedBatchRelationshipForPersonID(ByVal personID As String, _
                                                        ByVal requestedRelationship As String) As String
    Dim storedRelationship As String
    Dim storedKey As String, requestedKey As String
    personID = CellText(personID)
    requestedRelationship = CellText(requestedRelationship)
    If Len(personID) = 0 Then
        ValidatedBatchRelationshipForPersonID = requestedRelationship
        Exit Function
    End If
    If Not IsInternalIdValue(personID, "P") Then _
        Err.Raise vbObjectError + 2133, "ValidatedBatchRelationshipForPersonID", _
                  "人物IDの形式が不正です: " & personID
    requestedKey = NormalizeRelationshipKey(requestedRelationship)
    If mCandidateBatchRelationshipByID.Exists(personID) Then
        storedRelationship = CStr(mCandidateBatchRelationshipByID(personID))
        storedKey = NormalizeRelationshipKey(storedRelationship)
        If Len(requestedKey) > 0 And requestedKey <> storedKey Then _
            Err.Raise vbObjectError + 2134, "ValidatedBatchRelationshipForPersonID", _
                      "同一人物IDの続柄が既存候補または登録済み口座と一致しません: " & personID
        If Len(requestedKey) = 0 Then
            ValidatedBatchRelationshipForPersonID = storedRelationship
        Else
            ValidatedBatchRelationshipForPersonID = requestedRelationship
        End If
    Else
        ValidatedBatchRelationshipForPersonID = requestedRelationship
    End If
End Function

Private Function EarlierCandidateBatchRow(ByVal currentRow As Long, ByVal candidateRow As Long) As Long
    If candidateRow < 2 Then
        EarlierCandidateBatchRow = currentRow
    ElseIf currentRow < 2 Or candidateRow < currentRow Then
        EarlierCandidateBatchRow = candidateRow
    Else
        EarlierCandidateBatchRow = currentRow
    End If
End Function

Private Function CandidateBatchMappedRow(ByVal rowIndex As Object, ByVal keyText As String) As Long
    If rowIndex Is Nothing Or Len(keyText) = 0 Then Exit Function
    If Not rowIndex.Exists(keyText) Then Exit Function
    If IsNumeric(rowIndex(keyText)) Then CandidateBatchMappedRow = CLng(rowIndex(keyText))
End Function

Private Function FindCandidateBatchPersonRow(ByVal ws As Worksheet, ByVal personName As String, _
                                             ByVal personID As String, ByVal relationshipText As String, _
                                             ByRef conflictingPersonID As String) As Long
    Dim rowNo As Long, matchedRow As Long, conflictRow As Long
    Dim nameKey As String, nameIDKey As String, identityKey As String
    Dim storedID As String, storedRelationship As String
    If ws Is Nothing Then Exit Function
    nameKey = NormalizePersonNameKey(personName)
    identityKey = PersonIdentityKey(personName, relationshipText)
    personID = CellText(personID)

    If Len(personID) > 0 Then
        nameIDKey = nameKey & Chr$(29) & UCase$(personID)
        rowNo = CandidateBatchMappedRow(mCandidateBatchPersonRowByNameID, nameIDKey)
        If rowNo >= 2 Then
            If NormalizePersonNameKey(CellText(ws.Cells(rowNo, 1).Value)) = nameKey And _
               StrComp(CellText(ws.Cells(rowNo, 2).Value), personID, vbTextCompare) = 0 Then
                matchedRow = EarlierCandidateBatchRow(matchedRow, rowNo)
            Else
                mCandidateBatchPersonRowByNameID.Remove nameIDKey
            End If
        End If

        rowNo = CandidateBatchFirstQueuedRow(mCandidateBatchBlankRowByIdentity, identityKey)
        If rowNo >= 2 Then
            storedID = CellText(ws.Cells(rowNo, 2).Value)
            storedRelationship = CellText(ws.Cells(rowNo, 3).Value)
            If Len(storedID) = 0 And _
               PersonIdentityKey(CellText(ws.Cells(rowNo, 1).Value), storedRelationship) = identityKey Then
                matchedRow = EarlierCandidateBatchRow(matchedRow, rowNo)
            Else
                RemoveCandidateBatchQueuedHead mCandidateBatchBlankRowByIdentity, identityKey, rowNo
            End If
        End If

        If mCandidateBatchAssignedIDByIdentity.Exists(identityKey) Then
            storedID = CStr(mCandidateBatchAssignedIDByIdentity(identityKey))
            If StrComp(storedID, personID, vbTextCompare) <> 0 Then
                conflictRow = CandidateBatchMappedRow(mCandidateBatchAssignedRowByIdentity, identityKey)
                If matchedRow < 2 Or (conflictRow >= 2 And conflictRow < matchedRow) Then
                    conflictingPersonID = storedID
                    Exit Function
                End If
            End If
        End If
        'バッチ開始時に索引化した登録済み口座とも、候補シートへ触る前に照合する。
        '外側の取込処理が後で全体検査することには依存せず、公開候補API単体で
        '同じ氏名＋続柄を別の人物IDへ分岐させない。
        If Not mCandidateBatchRegisteredIDByIdentity Is Nothing Then
            If mCandidateBatchRegisteredIDByIdentity.Exists(identityKey) Then
                storedID = CStr(mCandidateBatchRegisteredIDByIdentity(identityKey))
                If StrComp(storedID, personID, vbTextCompare) <> 0 Then
                    conflictingPersonID = storedID
                    Exit Function
                End If
            End If
        End If
        FindCandidateBatchPersonRow = matchedRow
    Else
        rowNo = CandidateBatchMappedRow(mCandidateBatchAssignedRowByIdentity, identityKey)
        If rowNo >= 2 Then
            If PersonIdentityKey(CellText(ws.Cells(rowNo, 1).Value), _
                                 CellText(ws.Cells(rowNo, 3).Value)) = identityKey Then
                matchedRow = EarlierCandidateBatchRow(matchedRow, rowNo)
            Else
                mCandidateBatchAssignedRowByIdentity.Remove identityKey
            End If
        End If
        rowNo = CandidateBatchFirstQueuedRow(mCandidateBatchBlankRowByIdentity, identityKey)
        If rowNo >= 2 Then
            If Len(CellText(ws.Cells(rowNo, 2).Value)) = 0 And _
               PersonIdentityKey(CellText(ws.Cells(rowNo, 1).Value), _
                                 CellText(ws.Cells(rowNo, 3).Value)) = identityKey Then
                matchedRow = EarlierCandidateBatchRow(matchedRow, rowNo)
            Else
                RemoveCandidateBatchQueuedHead mCandidateBatchBlankRowByIdentity, identityKey, rowNo
            End If
        End If
        FindCandidateBatchPersonRow = matchedRow
    End If
End Function

Private Sub RemoveCandidateBatchMappedRow(ByVal rowIndex As Object, ByVal keyText As String, _
                                          ByVal rowNo As Long)
    If rowIndex Is Nothing Or Len(keyText) = 0 Or rowNo < 2 Then Exit Sub
    If Not rowIndex.Exists(keyText) Then Exit Sub
    If IsNumeric(rowIndex(keyText)) Then
        If CLng(rowIndex(keyText)) = rowNo Then rowIndex.Remove keyText
    End If
End Sub

Private Sub UnindexCandidateBatchPersonRow(ByVal rowNo As Long, ByVal personName As String, _
                                           ByVal personID As String, ByVal relationshipText As String)
    Dim nameKey As String, nameIDKey As String, identityKey As String
    If rowNo < 2 Then Exit Sub
    nameKey = NormalizePersonNameKey(personName)
    If Len(nameKey) = 0 Then Exit Sub
    personID = CellText(personID)
    identityKey = PersonIdentityKey(personName, relationshipText)
    If Len(personID) > 0 Then
        nameIDKey = nameKey & Chr$(29) & UCase$(personID)
        RemoveCandidateBatchMappedRow mCandidateBatchPersonRowByNameID, nameIDKey, rowNo
        If CandidateBatchMappedRow(mCandidateBatchAssignedRowByIdentity, identityKey) = rowNo Then
            mCandidateBatchAssignedRowByIdentity.Remove identityKey
            If mCandidateBatchAssignedIDByIdentity.Exists(identityKey) Then _
                mCandidateBatchAssignedIDByIdentity.Remove identityKey
        End If
    Else
        RemoveCandidateBatchQueuedHead mCandidateBatchBlankRowByIdentity, identityKey, rowNo
        If Len(NormalizeRelationshipKey(relationshipText)) = 0 Then _
            RemoveCandidateBatchQueuedHead mCandidateBatchBlankRowByName, nameKey, rowNo
    End If
End Sub

Private Sub ConvergeCandidateBatchBlankRelationships()
    Dim ws As Worksheet
    Dim lastR As Long, r As Long
    Dim sourceData As Variant, relationshipData As Variant
    Dim personID As String, personName As String, relationshipText As String
    Dim identityKey As String, conflictingPersonID As String
    Dim stagedIDByIdentity As Object
    Dim changed As Boolean
    If mCandidateBatchRelationshipByID Is Nothing Then Exit Sub
    If Not SheetExists(SH_PERSON_CAND) Then Exit Sub
    Set ws = GetSheet(SH_PERSON_CAND)
    lastR = LastDataRowInColumns(ws, 1, 4)
    If lastR < 2 Then Exit Sub
    '判定用のA:Cは一度だけ配列へ読み、書戻しは変更対象の続柄C列だけに限定する。
    '無関係な氏名・人物ID列を再代入せず、10万行でもセル単位COM更新を避ける。
    sourceData = ws.Range(ws.Cells(2, 1), ws.Cells(lastR, 3)).Value2
    '1行だけのRange.Value2は配列でなくScalarを返すため、常に二次元配列を作る。
    ReDim relationshipData(1 To lastR - 1, 1 To 1)
    For r = 1 To UBound(sourceData, 1)
        relationshipData(r, 1) = sourceData(r, 3)
    Next r
    Set stagedIDByIdentity = NewCandidateBatchDictionary()
    For r = 1 To UBound(sourceData, 1)
        personName = CellText(sourceData(r, 1))
        personID = CellText(sourceData(r, 2))
        If Len(personID) > 0 And _
           Len(NormalizeRelationshipKey(CellText(sourceData(r, 3)))) = 0 Then
            If mCandidateBatchRelationshipByID.Exists(personID) Then
                relationshipText = CStr(mCandidateBatchRelationshipByID(personID))
                If Len(NormalizeRelationshipKey(relationshipText)) > 0 Then
                    identityKey = PersonIdentityKey(personName, relationshipText)
                    conflictingPersonID = CandidateBatchConvergenceConflictID( _
                                              identityKey, personID, stagedIDByIdentity)
                    If Len(conflictingPersonID) > 0 Then _
                        Err.Raise vbObjectError + 2140, _
                                  "ConvergeCandidateBatchBlankRelationships", _
                                  "続柄補完後に同じ氏名・続柄へ異なる人物IDが生じます。" & _
                                  "人物候補を修正してから再実行してください: " & _
                                  personName & "（補完対象=" & personID & _
                                  " / 既存=" & conflictingPersonID & "）"
                    If Not stagedIDByIdentity.Exists(identityKey) Then _
                        stagedIDByIdentity.Add identityKey, personID
                    relationshipData(r, 1) = relationshipText
                    changed = True
                End If
            End If
        End If
    Next r
    If changed Then _
        ws.Range(ws.Cells(2, 3), ws.Cells(lastR, 3)).Value2 = relationshipData
End Sub

Private Function CandidateBatchConvergenceConflictID( _
        ByVal identityKey As String, ByVal allowedPersonID As String, _
        ByVal stagedIDByIdentity As Object) As String
    Dim existingID As String
    If Len(identityKey) = 0 Then Exit Function
    If Not mCandidateBatchAssignedIDByIdentity Is Nothing Then
        If mCandidateBatchAssignedIDByIdentity.Exists(identityKey) Then
            existingID = CStr(mCandidateBatchAssignedIDByIdentity(identityKey))
            If StrComp(existingID, allowedPersonID, vbTextCompare) <> 0 Then
                CandidateBatchConvergenceConflictID = existingID
                Exit Function
            End If
        End If
    End If
    If Not mCandidateBatchRegisteredIDByIdentity Is Nothing Then
        If mCandidateBatchRegisteredIDByIdentity.Exists(identityKey) Then
            existingID = CStr(mCandidateBatchRegisteredIDByIdentity(identityKey))
            If StrComp(existingID, allowedPersonID, vbTextCompare) <> 0 Then
                CandidateBatchConvergenceConflictID = existingID
                Exit Function
            End If
        End If
    End If
    If Not stagedIDByIdentity Is Nothing Then
        If stagedIDByIdentity.Exists(identityKey) Then
            existingID = CStr(stagedIDByIdentity(identityKey))
            If StrComp(existingID, allowedPersonID, vbTextCompare) <> 0 Then _
                CandidateBatchConvergenceConflictID = existingID
        End If
    End If
End Function


Private Function CandidateBatchKey(ByVal sheetName As String, ByVal valueText As String, _
                                   Optional ByVal personID As String = "", _
                                   Optional ByVal relationshipText As String = "") As String
    If sheetName = SH_PERSON_CAND Then
        valueText = NormalizePersonNameKey(valueText) & Chr$(29) & UCase$(Trim$(CellText(personID))) & _
                    Chr$(29) & NormalizeRelationshipKey(relationshipText)
    Else
        valueText = Trim$(CellText(valueText))
    End If
    CandidateBatchKey = sheetName & Chr$(29) & valueText
End Function

Public Sub BuildCandidateSheets(Optional ByVal resetContents As Boolean = False)
    SetupCandidateSheet SH_BANK_CAND, "銀行名候補", NM_LST_BANK_CAND, resetContents
    SetupCandidateSheet SH_BRANCH_CAND, "支店名候補", NM_LST_BRANCH_CAND, resetContents
    SetupCandidateSheet SH_PERSON_CAND, "人物候補", NM_LST_PERSON_CAND, resetContents
End Sub

Public Sub ShowBankCandidates()
    ShowCandidateSheet SH_BANK_CAND
End Sub

Public Sub ShowBranchCandidates()
    ShowCandidateSheet SH_BRANCH_CAND
End Sub

Public Sub ShowPersonCandidates()
    ShowCandidateSheet SH_PERSON_CAND
End Sub

Public Sub ShowAccountTypeCandidates()
    ShowCandidateSheet SH_ACCOUNT_TYPE
End Sub

Public Sub ShowTekiyoCandidates()
    ShowCandidateSheet SH_TEKIYO
End Sub

Public Sub ShowCandidateSheet(ByVal sheetName As String)
    Dim ws As Worksheet
    Dim names As Variant, item As Variant
    Dim previousEvents As Boolean, eventsCaptured As Boolean
    Dim eventsReadyForBookWrites As Boolean
    Dim sheetWritesStarted As Boolean, displayCompleted As Boolean
    Dim recoveryStateConfirmed As Boolean, safeToRestoreEntry As Boolean
    Dim applicationStateSafe As Boolean
    Dim eventRestoreSucceeded As Boolean
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim protectErrorNumber As Long, protectErrorDescription As String
    Dim protectErrorSource As String
    Dim protectReadErrorNumber As Long, protectReadErrorDescription As String
    Dim recoveryErrorNumber As Long, recoveryErrorDescription As String
    Dim recoveryErrorSource As String
    Dim eventStateDetail As String, eventRestoreDetail As String
    Dim postRecoveryStopDetail As String
    Dim recoveryDetail As String
    Dim applicationStateProblems As String
    Dim protectionConfirmed As Boolean
    If Not IsCandidateSheetName(sheetName) Then _
        Err.Raise vbObjectError + 2120, "ShowCandidateSheet", "候補シート名が不正です: " & sheetName
    On Error GoTo EH
    '表示・書式・図形・保護・他候補タブの非表示を一つのイベントリースで包む。
    '内側のProtectCandidateSheetにはFalseを引き渡し、Falseのまま返させる。
    If Not TryGetCandidateEnableEvents(previousEvents, eventStateDetail) Then
        errorNumber = vbObjectError + 2151
        errorDescription = _
            "候補表示の開始時にExcelイベント状態を取得できませんでした。 " & _
            eventStateDetail
        Call StopAfterCandidateEventStateFailure( _
                 "ShowCandidateSheet/開始状態取得", errorDescription)
        GoTo ReportFailureWithoutEntryState
    End If
    eventsCaptured = True
    If Not TryStopCandidateEventsForBookWrites(eventStateDetail) Then
        errorNumber = vbObjectError + 2152
        errorDescription = _
            "候補表示前にExcelイベントを停止して読戻し確認できませんでした。 " & _
            eventStateDetail & _
            " ブックの表示・書式・図形・保護は変更していません。"
        GoTo RestoreEntryEventsAndReport
    End If
    eventsReadyForBookWrites = True
    If Not RequireToolReady() Then GoTo SafeExit
    Set ws = GetSheet(sheetName)
    If Not TryStopCandidateEventsForBookWrites(eventStateDetail) Then _
        Err.Raise vbObjectError + 2154, "ShowCandidateSheet", _
                  "候補シート書込み直前にExcelイベントのFalseを確認できませんでした。 " & _
                  eventStateDetail
    sheetWritesStarted = True
    ws.Visible = xlSheetVisible
    ws.Unprotect Password:=TOOL_PASSWORD
    FormatCandidateSheetForEditing ws
    BuildCandidateNavigationPanel ws
    ProtectCandidateSheet ws, True
    If Not TryStopCandidateEventsForBookWrites(eventStateDetail) Then _
        Err.Raise vbObjectError + 2155, "ShowCandidateSheet", _
                  "候補シート保護後にExcelイベントのFalseを確認できませんでした。 " & _
                  eventStateDetail
    ws.Activate
    ApplyActiveSheetWindowStyle ws
    SafeFreezeSheetAt ws, "A2", 95
    ws.Activate
    If Not ThisWorkbook.ReadOnly And _
       Not (ws.Name = SH_PERSON_CAND And _
            (IsEditMode() Or CurrentAccountInputHasData())) Then ws.Range("A2").Select

    '候補タブを5枚同時に並べない。今見ている種類だけを表示し、切替は右側パネルへ集約する。
    names = CandidateSheetNames()
    For Each item In names
        If CStr(item) <> sheetName Then HideSheetIfExists CStr(item)
    Next item
    displayCompleted = True
SafeExit:
    '開始値の復元を、このルーチンにおける最後のExcel状態操作にする。
    If eventsCaptured Then
        If Not TryRestoreCandidateEnableEvents( _
                   previousEvents, "ShowCandidateSheet/正常終了", _
                   eventRestoreDetail) Then
            eventsCaptured = False
            errorNumber = vbObjectError + 2153
            If displayCompleted Then
                errorDescription = _
                    "入力候補の表示は完了しましたが、Excelイベント状態を開始値へ" & _
                    "復元できませんでした。 " & eventRestoreDetail
            Else
                errorDescription = _
                    "候補表示の事前確認終了後に、Excelイベント状態を開始値へ" & _
                    "復元できませんでした。 " & eventRestoreDetail
            End If
            On Error GoTo 0
            GoTo ReportFailure
        End If
        eventsCaptured = False
    End If
    Exit Sub
EH:
    errorNumber = Err.Number
    errorSource = Err.Source
    errorDescription = Err.Description
    If IsCandidateRecoveryHardBarrier(errorNumber, errorSource) Then
        Call TryStopCandidateEventsForBookWrites(eventStateDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    If errorNumber = 0 Then errorNumber = vbObjectError + 2156
    If Len(errorDescription) = 0 Then _
        errorDescription = "候補シートの表示処理中に原因不明のエラーが発生しました。"
    On Error Resume Next
    Err.Clear
    '異常終了時も、Falseの読戻しが取れない限りシート・Recovery・診断へ触れない。
    eventsReadyForBookWrites = _
        TryStopCandidateEventsForBookWrites(eventStateDetail)
    If Not eventsReadyForBookWrites Then
        AppendCandidateSafetyDetail errorDescription, _
            "異常終了後にExcelイベントをFalseへ停止して読戻し確認できないため、" & _
            "候補シート再保護とブックへの復旧記録を見送りました: " & _
            eventStateDetail
        GoTo RestoreEntryEventsAndReport
    End If
    If sheetWritesStarted And Not ws Is Nothing Then
        ProtectCandidateSheet ws, True
        protectErrorNumber = Err.Number
        protectErrorDescription = Err.Description
        protectErrorSource = Err.Source
        Err.Clear
        If IsCandidateRecoveryHardBarrier( _
               protectErrorNumber, protectErrorSource) Then
            Call TryStopCandidateEventsForBookWrites(eventStateDetail)
            On Error GoTo 0
            Err.Raise protectErrorNumber, protectErrorSource, _
                      protectErrorDescription
        End If
        eventsReadyForBookWrites = _
            TryStopCandidateEventsForBookWrites(eventStateDetail)
        If Not eventsReadyForBookWrites Then
            AppendCandidateSafetyDetail errorDescription, _
                "候補シート再保護後にExcelイベントのFalseを確認できないため、" & _
                "保護読戻しとブックへの復旧記録を見送りました: " & _
                eventStateDetail
            GoTo RestoreEntryEventsAndReport
        End If
        protectionConfirmed = ws.ProtectContents And ws.ProtectDrawingObjects
        protectReadErrorNumber = Err.Number
        protectReadErrorDescription = Err.Description
        Err.Clear
        If protectErrorNumber <> 0 Or protectReadErrorNumber <> 0 Or _
           Not protectionConfirmed Then
            AppendCandidateSafetyDetail errorDescription, _
                "候補シート再保護を一意に確認できません" & _
                IIf(protectErrorNumber <> 0, _
                    ": Err " & CStr(protectErrorNumber) & " " & _
                    protectErrorDescription, vbNullString) & _
                IIf(protectReadErrorNumber <> 0, _
                    " / 保護読戻し Err " & CStr(protectReadErrorNumber) & _
                    " " & protectReadErrorDescription, vbNullString)
        Else
            AppendCandidateSafetyDetail errorDescription, _
                "候補シートは再保護と読戻し確認を完了しました。"
        End If
    End If
    If sheetWritesStarted Then
        recoveryDetail = _
            "候補表示処理が部分的に失敗しました: " & errorDescription
        postRecoveryStopDetail = vbNullString
        recoveryStateConfirmed = _
            TryEnterCandidateRecoveryStateExact( _
                recoveryDetail, postRecoveryStopDetail)
        recoveryErrorNumber = Err.Number
        recoveryErrorSource = Err.Source
        recoveryErrorDescription = Err.Description
        Err.Clear
        If IsCandidateRecoveryHardBarrier( _
               recoveryErrorNumber, recoveryErrorSource) Then
            Call TryStopCandidateEventsForBookWrites(eventStateDetail)
            On Error GoTo 0
            Err.Raise recoveryErrorNumber, recoveryErrorSource, _
                      recoveryErrorDescription
        End If
        eventsReadyForBookWrites = recoveryStateConfirmed
        If recoveryStateConfirmed Then
            On Error Resume Next
            AddCheck "エラー", "候補表示の部分失敗", recoveryDetail
            SetInputStatus _
                "入力候補の表示処理が途中で失敗したため、案件を要復旧として停止しました。" & _
                "現在のブックを上書きしないでください。", True
            Err.Clear
            On Error GoTo 0
            postRecoveryStopDetail = vbNullString
            eventsReadyForBookWrites = _
                TryStopCandidateEventsForBookWrites(postRecoveryStopDetail)
            If eventsReadyForBookWrites Then
                recoveryStateConfirmed = _
                    TryConfirmCandidateRecoveryState(recoveryDetail)
            Else
                recoveryStateConfirmed = False
            End If
        Else
            AppendCandidateSafetyDetail recoveryDetail, _
                "Recoveryを一意に確認できないため、診断・状態表示を行いません: " & _
                postRecoveryStopDetail
            eventStateDetail = vbNullString
            eventsReadyForBookWrites = _
                TryStopCandidateEventsForBookWrites(eventStateDetail)
        End If
        AppendCandidateSafetyDetail errorDescription, recoveryDetail
    End If
RestoreEntryEventsAndReport:
    'このラベル以降はブックへ書き込まない。開始値復元を必ず最後に行う。
    safeToRestoreEntry = Not previousEvents
    If previousEvents Then
        If Not sheetWritesStarted Then
            safeToRestoreEntry = True
        ElseIf eventsReadyForBookWrites And recoveryStateConfirmed Then
            applicationStateProblems = vbNullString
            applicationStateSafe = _
                AppStateIsRestored(applicationStateProblems)
            safeToRestoreEntry = applicationStateSafe
            If Not applicationStateSafe Then _
                AppendCandidateSafetyDetail errorDescription, _
                    "開始値Trueへの復元前にApplication状態を確認できません: " & _
                    applicationStateProblems
        End If
    End If
    If eventsCaptured Then
        If safeToRestoreEntry Then
            eventRestoreSucceeded = _
                TryRestoreCandidateEnableEvents( _
                    previousEvents, "ShowCandidateSheet/異常終了", _
                    eventRestoreDetail)
            recoveryErrorNumber = Err.Number
            recoveryErrorSource = Err.Source
            recoveryErrorDescription = Err.Description
            Err.Clear
            If IsCandidateRecoveryHardBarrier( _
                   recoveryErrorNumber, recoveryErrorSource) Then
                Call TryStopCandidateEventsForBookWrites(eventStateDetail)
                On Error GoTo 0
                Err.Raise recoveryErrorNumber, recoveryErrorSource, _
                          recoveryErrorDescription
            End If
            If Not eventRestoreSucceeded Then _
                AppendCandidateSafetyDetail errorDescription, _
                    "Excelイベント状態の復元エラー: " & eventRestoreDetail
        Else
            eventStateDetail = vbNullString
            If TryStopCandidateEventsForBookWrites(eventStateDetail) Then
                AppendCandidateSafetyDetail errorDescription, _
                    "ロールバック・保護または要復旧の確定条件が揃わないため、" & _
                    "開始値への復元処理を行わずExcelイベントをFalseに保持しました。"
            Else
                AppendCandidateSafetyDetail errorDescription, _
                    "ExcelイベントのFalse収束も確認できず、案件の安全状態は不明です: " & _
                    eventStateDetail
            End If
        End If
        eventsCaptured = False
    End If
    On Error GoTo 0
ReportFailure:
    MsgBox "入力候補を表示できませんでした。" & vbCrLf & _
           "Err " & errorNumber & ": " & errorDescription, vbExclamation
    Exit Sub
ReportFailureWithoutEntryState:
    '開始状態を取得できなかった場合は、StopAfter...がFalseを確認できた時だけ
    'Recovery・診断へ書き込み、確認できなければブックを一切変更しない。
    On Error GoTo 0
    GoTo ReportFailure
End Sub

Public Sub OnCandidateSheetChange(ByVal ws As Worksheet, ByVal Target As Range)
    Dim affected As Range, identityAffected As Range, cell As Range
    Dim snapshotRange As Range
    Dim candidateSnapshot As Variant, candidateMergeSignature As String
    Dim previousEvents As Boolean
    Dim firstStyleRow As Long, lastStyleRow As Long
    Dim snapshotLastRow As Long, currentLastRow As Long
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim restoreErrorNumber As Long, restoreErrorDescription As String
    Dim restoreErrorSource As String, eventStateDetail As String
    Dim eventRestoreDetail As String, postRecoveryStopDetail As String
    Dim recoveryDetail As String, restoreDetail As String
    Dim snapshotCaptured As Boolean, postProcessStarted As Boolean, rollbackFailed As Boolean
    Dim eventsCaptured As Boolean, eventsReadyForRecovery As Boolean
    Dim eventRecoveryEnforced As Boolean
    Dim recoveryStateConfirmed As Boolean, protectionConfirmed As Boolean
    Dim safeToRestoreEntry As Boolean
    Dim applicationStateSafe As Boolean, applicationStateProblems As String
    Dim recoveryErrorNumber As Long, recoveryErrorDescription As String
    Dim recoveryErrorSource As String
    Dim protectionReadErrorNumber As Long, protectionReadErrorDescription As String
    Dim blockIdentityEdit As Boolean, blockMessage As String
    If ws Is Nothing Or Target Is Nothing Then Exit Sub
    If Not IsCandidateSheetName(ws.Name) Then Exit Sub
    Set affected = Intersect(Target, ws.Range("A2:D" & CStr(ws.Rows.Count)))
    If affected Is Nothing Then Exit Sub
    If Not TryGetCandidateEnableEvents(previousEvents, eventStateDetail) Then
        StopAfterCandidateEventStateFailure _
            "OnCandidateSheetChange/開始状態取得", eventStateDetail
        Err.Raise vbObjectError + 2141, "OnCandidateSheetChange", _
                  "Excelイベントの開始状態を取得できませんでした。 " & eventStateDetail
    End If
    eventsCaptured = True
    '訂正画面は読込時点の人物属性を保持している。訂正中に人物候補の氏名・続柄を
    '先に変えると、後の訂正保存が古い値で候補を巻き戻すため変更自体を許可しない。
    If ws.Name = SH_PERSON_CAND Then
        Set identityAffected = Intersect(affected, Union(ws.Columns(1), ws.Columns(3)))
        If Not identityAffected Is Nothing Then
            If IsEditMode() Or CurrentAccountInputHasData() Then
                blockIdentityEdit = True
                blockMessage = "口座情報の入力中は、人物候補の氏名・続柄を変更できません。" & vbCrLf & _
                               "先に入力を登録または消去してから候補を編集してください。"
            ElseIf PersonCandidateIdentityEditTouchesAssignedID(ws, identityAffected) Then
                blockIdentityEdit = True
                blockMessage = "人物IDが付いた候補の氏名・続柄は直接変更できません。" & vbCrLf & _
                               "登録済み口座を訂正すると、同じ人物IDの候補へ安全に反映されます。"
            End If
        End If
        If blockIdentityEdit Then
            If Not TrySetCandidateEnableEventsExact(False, eventStateDetail) Then
                errorNumber = vbObjectError + 2142
                errorDescription = _
                    "人物候補の変更取消前にExcelイベントを停止できませんでした。 " & _
                    eventStateDetail
                rollbackFailed = True
                eventRecoveryEnforced = True
                eventsReadyForRecovery = _
                    StopAfterCandidateEventStateFailure( _
                        "OnCandidateSheetChange/人物候補変更取消前のイベント停止", _
                        eventStateDetail)
                recoveryStateConfirmed = eventsReadyForRecovery
                AppendCandidateSafetyDetail errorDescription, eventStateDetail
                GoTo BlockIdentityFinalize
            End If
            eventsReadyForRecovery = True
            On Error Resume Next
            Err.Clear
            Application.Undo
            errorNumber = Err.Number
            errorDescription = Err.Description
            Err.Clear
            On Error GoTo 0
            If errorNumber <> 0 Then rollbackFailed = True
BlockIdentityFinalize:
            On Error Resume Next
            Err.Clear
            If eventsReadyForRecovery Then
                ProtectCandidateSheet ws, True
                restoreErrorNumber = Err.Number
                restoreErrorDescription = Err.Description
                restoreErrorSource = Err.Source
                Err.Clear
                If IsCandidateRecoveryHardBarrier( _
                       restoreErrorNumber, restoreErrorSource) Then
                    Call TryStopCandidateEventsForBookWrites(eventStateDetail)
                    On Error GoTo 0
                    Err.Raise restoreErrorNumber, restoreErrorSource, _
                              restoreErrorDescription
                End If
                eventStateDetail = vbNullString
                eventsReadyForRecovery = _
                    TryStopCandidateEventsForBookWrites(eventStateDetail)
                If Not eventsReadyForRecovery Then
                    AppendCandidateSafetyDetail errorDescription, _
                        "候補シート再保護後のExcelイベント停止を確認できません: " & _
                        eventStateDetail
                    rollbackFailed = True
                Else
                    protectionConfirmed = ws.ProtectContents And _
                                          ws.ProtectDrawingObjects
                    protectionReadErrorNumber = Err.Number
                    protectionReadErrorDescription = Err.Description
                    Err.Clear
                    If protectionReadErrorNumber <> 0 Or _
                       Not protectionConfirmed Then
                        rollbackFailed = True
                        AppendCandidateSafetyDetail errorDescription, _
                            "候補シート再保護を読み戻せません" & _
                            IIf(protectionReadErrorNumber <> 0, _
                                ": Err " & CStr(protectionReadErrorNumber) & _
                                " " & protectionReadErrorDescription, _
                                vbNullString)
                    End If
                End If
                If restoreErrorNumber <> 0 Then
                    If errorNumber = 0 Then
                        errorNumber = restoreErrorNumber
                        errorDescription = _
                            "人物候補の変更取消後に候補シートを再保護できませんでした。 " & _
                            restoreErrorDescription
                    Else
                        AppendCandidateSafetyDetail errorDescription, _
                            "候補シート再保護: Err " & _
                            CStr(restoreErrorNumber) & " " & restoreErrorDescription
                    End If
                    rollbackFailed = True
                    protectionConfirmed = False
                End If
            End If
            If rollbackFailed And eventsReadyForRecovery And _
               Not eventRecoveryEnforced Then
                recoveryDetail = errorDescription
                postRecoveryStopDetail = vbNullString
                recoveryStateConfirmed = _
                    TryEnterCandidateRecoveryStateExact( _
                        recoveryDetail, postRecoveryStopDetail)
                recoveryErrorNumber = Err.Number
                recoveryErrorSource = Err.Source
                recoveryErrorDescription = Err.Description
                Err.Clear
                If IsCandidateRecoveryHardBarrier( _
                       recoveryErrorNumber, recoveryErrorSource) Then
                    Call TryStopCandidateEventsForBookWrites(eventStateDetail)
                    On Error GoTo 0
                    Err.Raise recoveryErrorNumber, recoveryErrorSource, _
                              recoveryErrorDescription
                End If
                eventsReadyForRecovery = recoveryStateConfirmed
                If Not recoveryStateConfirmed Then
                    AppendCandidateSafetyDetail recoveryDetail, _
                        "Recoveryを一意に確認できないため、診断・状態表示を行いません: " & _
                        postRecoveryStopDetail
                End If
            End If
            If rollbackFailed And Not eventRecoveryEnforced And _
               eventsReadyForRecovery Then
                'Undo不能またはイベント状態不明の変更値を通常登録から参照させない。
                If recoveryStateConfirmed Then
                    On Error Resume Next
                    AddCheck "エラー", "人物候補変更の取消", _
                             "人物候補の変更を安全に取り消せませんでした。案件を要復旧として停止します。Err " & _
                             CStr(errorNumber) & ": " & errorDescription & _
                             IIf(Len(recoveryDetail) > 0, " / " & recoveryDetail, "")
                    SetInputStatus "人物候補の変更を安全に取り消せないため、" & _
                                   "案件を要復旧として停止しました。", True
                    Err.Clear
                    On Error GoTo 0
                    postRecoveryStopDetail = vbNullString
                    eventsReadyForRecovery = _
                        TryStopCandidateEventsForBookWrites( _
                            postRecoveryStopDetail)
                    If eventsReadyForRecovery Then
                        recoveryStateConfirmed = _
                            TryConfirmCandidateRecoveryState(recoveryDetail)
                    Else
                        recoveryStateConfirmed = False
                    End If
                End If
            End If
            On Error GoTo 0
            safeToRestoreEntry = Not previousEvents
            If previousEvents Then
                safeToRestoreEntry = eventsReadyForRecovery And _
                    ((Not rollbackFailed And protectionConfirmed) Or _
                     recoveryStateConfirmed)
                If safeToRestoreEntry Then
                    applicationStateProblems = vbNullString
                    applicationStateSafe = _
                        AppStateIsRestored(applicationStateProblems)
                    safeToRestoreEntry = applicationStateSafe
                    If Not applicationStateSafe Then _
                        AppendCandidateSafetyDetail errorDescription, _
                            "開始値Trueへの復元前にApplication状態を確認できません: " & _
                            applicationStateProblems
                End If
            End If
            If eventsCaptured Then
                If safeToRestoreEntry Then
                    If Not TryRestoreCandidateEnableEvents( _
                               previousEvents, _
                               "OnCandidateSheetChange/人物候補変更取消", _
                               eventStateDetail) Then
                        eventRecoveryEnforced = True
                        If errorNumber = 0 Then
                            errorNumber = vbObjectError + 2143
                            errorDescription = _
                                "人物候補の変更取消後にExcelイベント状態を復元できませんでした。 " & _
                                eventStateDetail
                        Else
                            AppendCandidateSafetyDetail errorDescription, _
                                eventStateDetail
                        End If
                        rollbackFailed = True
                    End If
                Else
                    eventStateDetail = vbNullString
                    If TryStopCandidateEventsForBookWrites( _
                           eventStateDetail) Then
                        AppendCandidateSafetyDetail errorDescription, _
                            "ロールバック・保護または要復旧を一意に確定できないため、" & _
                            "ExcelイベントをFalseに保持しました。"
                    Else
                        AppendCandidateSafetyDetail errorDescription, _
                            "ExcelイベントのFalse収束も確認できず、" & _
                            "案件の安全状態は不明です: " & _
                            eventStateDetail
                    End If
                    eventRecoveryEnforced = True
                    rollbackFailed = True
                    If errorNumber = 0 Then
                        errorNumber = vbObjectError + 2143
                        errorDescription = _
                            "人物候補の変更取消後の安全状態を確定できません。"
                    End If
                End If
                eventsCaptured = False
            End If
            If errorNumber = 0 Then
                MsgBox blockMessage, vbExclamation, "人物候補の変更を取り消しました"
                Exit Sub
            End If
            Err.Raise errorNumber, "OnCandidateSheetChange/訂正中の変更取消", _
                      errorDescription & _
                      IIf(Len(recoveryDetail) > 0, " / " & recoveryDetail, "")
        End If
    End If
    On Error GoTo CleanUp
    'イベント開始時点（利用者の許可済み変更を含む）の候補表を退避する。
    'この後の重複統合・上詰め・定義名・保護更新が途中で失敗しても、
    '後処理だけが半端に反映された表を残さない。
    snapshotLastRow = LastDataRowInColumns(ws, 1, 4)
    If snapshotLastRow < 2 Then snapshotLastRow = 2
    Set snapshotRange = ws.Range(ws.Cells(2, 1), ws.Cells(snapshotLastRow, 4))
    candidateMergeSignature = InputRangeMergeSignature(snapshotRange)
    candidateSnapshot = CaptureInputFormulaSnapshot(snapshotRange)
    snapshotCaptured = True
    If Not TrySetCandidateEnableEventsExact(False, eventStateDetail) Then
        rollbackFailed = True
        Err.Raise vbObjectError + 2144, "OnCandidateSheetChange", _
                  "候補更新前にExcelイベントを停止できませんでした。 " & eventStateDetail
    End If
    eventsReadyForRecovery = True
    postProcessStarted = True

    '銀行・支店・人物を手入力で追加した行は、案件初期化で消えない共通候補として扱う。
    For Each cell In Intersect(affected.EntireRow, ws.Columns(1)).Cells
        If cell.HasFormula Or IsError(cell.Value) Then
        ElseIf Not HasText(cell.Value) Then
            'A列が空欄なら、変更された列にかかわらず人物ID・続柄・区分を孤立させない。
            '人物候補は必ず氏名を先に入力するため、空の行へ続柄だけを残さない。
            ws.Range(ws.Cells(cell.Row, 2), ws.Cells(cell.Row, 4)).ClearContents
        ElseIf ws.Name = SH_BANK_CAND Or ws.Name = SH_BRANCH_CAND Or _
               ws.Name = SH_PERSON_CAND Then
                If Not HasText(ws.Cells(cell.Row, 4).Value) Then _
                    ws.Cells(cell.Row, 4).Value = CAND_SOURCE_COMMON
        End If
    Next cell
    If ws.Name = SH_PERSON_CAND Then MergeBlankPersonCandidateDuplicates ws
    CompactCandidateRows ws
    RefreshCandidateNameForSheet ws.Name
    '利用者が編集できるA/C列では人物IDは変わらない。採番直前の照合へ任せ、全台帳再走査を省く。
    If ws.Name = SH_PERSON_CAND Then InvalidateInternalIdCaches
    firstStyleRow = Application.Max(2, Target.Row)
    lastStyleRow = Application.Min(ws.Rows.Count, _
                   Application.Max(firstStyleRow, Target.Row + Target.Rows.Count))
    FormatCandidateEntryArea ws, lastStyleRow, firstStyleRow
    ws.ScrollArea = "A1:J" & CStr(Application.Min(ws.Rows.Count, _
                    Application.Max(500, LastRow(ws, 1) + 500)))
    EnsureCandidateProtectionCapacity ws
CleanUp:
    errorNumber = Err.Number
    errorSource = Err.Source
    errorDescription = Err.Description
    If IsCandidateRecoveryHardBarrier(errorNumber, errorSource) Then
        Call TryStopCandidateEventsForBookWrites(eventStateDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    eventsReadyForRecovery = False
    If eventsCaptured Then
        If TrySetCandidateEnableEventsExact(False, eventStateDetail) Then
            eventsReadyForRecovery = True
        Else
            rollbackFailed = True
            eventRecoveryEnforced = True
            eventsReadyForRecovery = _
                StopAfterCandidateEventStateFailure( _
                    "OnCandidateSheetChange/後処理前のイベント停止", _
                    eventStateDetail)
            recoveryStateConfirmed = eventsReadyForRecovery
            If errorNumber = 0 Then
                errorNumber = vbObjectError + 2145
                errorDescription = _
                    "候補更新の終了処理前にExcelイベントを停止できませんでした。 " & _
                    eventStateDetail
            Else
                restoreDetail = restoreDetail & _
                    " / 候補表復元前のExcelイベント停止エラー: " & eventStateDetail
            End If
        End If
    End If
    If errorNumber <> 0 And postProcessStarted And snapshotCaptured Then
        If eventsReadyForRecovery Then
            On Error Resume Next
            Err.Clear
            currentLastRow = LastDataRowInColumns(ws, 1, 4)
            If currentLastRow < snapshotLastRow Then currentLastRow = snapshotLastRow
            ws.Unprotect Password:=TOOL_PASSWORD
            ws.Range(ws.Cells(2, 1), ws.Cells(currentLastRow, 4)).ClearContents
            RestoreInputFormulaSnapshot snapshotRange, candidateSnapshot, _
                                        candidateMergeSignature, ws.Name & "候補"
            AssertInputFormulaSnapshot snapshotRange, candidateSnapshot, _
                                       candidateMergeSignature, ws.Name & "候補"
            RefreshCandidateNameForSheet ws.Name
            ProtectCandidateSheet ws, True
            restoreErrorNumber = Err.Number
            restoreErrorDescription = Err.Description
            restoreErrorSource = Err.Source
            If IsCandidateRecoveryHardBarrier( _
                   restoreErrorNumber, restoreErrorSource) Then
                Call TryStopCandidateEventsForBookWrites(eventStateDetail)
                On Error GoTo 0
                Err.Raise restoreErrorNumber, restoreErrorSource, _
                          restoreErrorDescription
            End If
            If restoreErrorNumber <> 0 Then
                rollbackFailed = True
                restoreDetail = restoreDetail & _
                    " / 候補表・定義名・保護の復元エラー: Err " & _
                    CStr(restoreErrorNumber) & " " & restoreErrorDescription
            End If
            Err.Clear
            On Error GoTo 0
        Else
            rollbackFailed = True
            restoreDetail = restoreDetail & _
                " / Excelイベント停止を確認できないため候補表の復元を実行しませんでした。"
        End If
    End If
    On Error Resume Next
    Err.Clear
    If rollbackFailed And Not eventRecoveryEnforced Then
        If eventsReadyForRecovery Then
            If Len(recoveryDetail) = 0 Then _
                recoveryDetail = errorDescription & restoreDetail
            postRecoveryStopDetail = vbNullString
            recoveryStateConfirmed = _
                TryEnterCandidateRecoveryStateExact( _
                    recoveryDetail, postRecoveryStopDetail)
            recoveryErrorNumber = Err.Number
            recoveryErrorSource = Err.Source
            recoveryErrorDescription = Err.Description
            Err.Clear
            If IsCandidateRecoveryHardBarrier( _
                   recoveryErrorNumber, recoveryErrorSource) Then
                Call TryStopCandidateEventsForBookWrites(eventStateDetail)
                On Error GoTo 0
                Err.Raise recoveryErrorNumber, recoveryErrorSource, _
                          recoveryErrorDescription
            End If
            eventsReadyForRecovery = recoveryStateConfirmed
            If Not recoveryStateConfirmed Then
                AppendCandidateSafetyDetail recoveryDetail, _
                    "Recoveryを一意に確認できないため、追加終了記録を行いません: " & _
                    postRecoveryStopDetail
            End If
            If eventsReadyForRecovery And recoveryStateConfirmed Then
                AppendCandidateSafetyDetail restoreDetail, _
                    "案件を要復旧として停止しました。"
            Else
                AppendCandidateSafetyDetail restoreDetail, _
                    "案件の安全状態を確認できません。"
            End If
            If Len(recoveryDetail) > 0 Then _
                AppendCandidateSafetyDetail restoreDetail, recoveryDetail
        Else
            AppendCandidateSafetyDetail restoreDetail, _
                "イベント停止未確認のためRecovery書込みを見送り、案件の安全状態は不明です。"
        End If
    End If
    On Error GoTo 0
    safeToRestoreEntry = Not previousEvents
    If previousEvents Then
        safeToRestoreEntry = eventsReadyForRecovery And _
            ((Not rollbackFailed) Or recoveryStateConfirmed)
        If safeToRestoreEntry Then
            applicationStateProblems = vbNullString
            applicationStateSafe = AppStateIsRestored(applicationStateProblems)
            safeToRestoreEntry = applicationStateSafe
            If Not applicationStateSafe Then _
                AppendCandidateSafetyDetail restoreDetail, _
                    "開始値Trueへの復元前にApplication状態を確認できません: " & _
                    applicationStateProblems
        End If
    End If
    If eventsCaptured Then
        If safeToRestoreEntry Then
            If Not TryRestoreCandidateEnableEvents( _
                       previousEvents, "OnCandidateSheetChange", _
                       eventStateDetail) Then
                eventRecoveryEnforced = True
                eventRestoreDetail = _
                    " / Excelイベント状態の復元エラー: " & eventStateDetail
                If errorNumber = 0 Then
                    errorNumber = vbObjectError + 2146
                    errorDescription = _
                        "候補更新後にExcelイベント状態を復元できません。"
                End If
                rollbackFailed = True
            End If
        Else
            eventStateDetail = vbNullString
            If TryStopCandidateEventsForBookWrites(eventStateDetail) Then
                AppendCandidateSafetyDetail restoreDetail, _
                    "ロールバックまたは要復旧を一意に確定できないため、" & _
                    "ExcelイベントをFalseに保持しました。"
            Else
                AppendCandidateSafetyDetail restoreDetail, _
                    "ExcelイベントのFalse収束も確認できず、" & _
                    "案件の安全状態は不明です: " & eventStateDetail
            End If
            rollbackFailed = True
        End If
        eventsCaptured = False
    End If
    If errorNumber <> 0 Then _
        Err.Raise errorNumber, "OnCandidateSheetChange", _
                  errorDescription & restoreDetail & eventRestoreDetail
End Sub

Private Sub AppendCandidateSafetyDetail(ByRef detailText As String, _
                                        ByVal itemText As String)
    If Len(itemText) = 0 Then Exit Sub
    If Len(detailText) > 0 Then detailText = detailText & " / "
    detailText = detailText & itemText
End Sub

Private Function IsCandidateRecoveryHardBarrier( _
        ByVal errorNumber As Long, _
        ByVal errorSource As String) As Boolean
    IsCandidateRecoveryHardBarrier = _
        (errorNumber = CANDIDATE_RECOVERY_HARD_BARRIER_ERROR)
End Function

Private Function TryGetCandidateEnableEvents( _
        ByRef currentValue As Boolean, _
        ByRef detailText As String) As Boolean
    Dim errorNumber As Long, errorDescription As String
    detailText = vbNullString
    On Error GoTo EH
    currentValue = Application.EnableEvents
    TryGetCandidateEnableEvents = True
    Exit Function
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    detailText = "Err " & CStr(errorNumber) & ": " & errorDescription
    Err.Clear
End Function

Private Function TrySetCandidateEnableEventsExact( _
        ByVal desiredValue As Boolean, _
        ByRef detailText As String) As Boolean
    Dim errorNumber As Long, errorDescription As String
    detailText = vbNullString
    On Error GoTo EH
    Application.EnableEvents = desiredValue
    If Application.EnableEvents <> desiredValue Then _
        Err.Raise vbObjectError + 2147, _
                  "TrySetCandidateEnableEventsExact", _
                  "EnableEventsの書込み後読戻しが一致しません。"
    TrySetCandidateEnableEventsExact = True
    Exit Function
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    detailText = "Err " & CStr(errorNumber) & ": " & errorDescription
    Err.Clear
End Function

Private Function TryStopCandidateEventsForBookWrites( _
        ByRef detailText As String) As Boolean
    Dim firstDetail As String, retryDetail As String
    detailText = vbNullString
    If TrySetCandidateEnableEventsExact(False, firstDetail) Then
        TryStopCandidateEventsForBookWrites = True
        Exit Function
    End If
    If TrySetCandidateEnableEventsExact(False, retryDetail) Then
        TryStopCandidateEventsForBookWrites = True
        Exit Function
    End If
    detailText = "ExcelイベントをFalseへ停止して読戻し確認できませんでした。初回=" & _
                 firstDetail & " / 再試行=" & retryDetail
End Function

Private Function TryConfirmCandidateRecoveryState( _
        ByRef detailText As String) As Boolean
    Dim latchIsSet As Boolean, latchReadSucceeded As Boolean
    Dim healthValue As String, healthReadSucceeded As Boolean
    latchReadSucceeded = TryGetRollbackRecoveryLatch(latchIsSet)
    healthReadSucceeded = TryGetExactStateValue(STATE_DATA_HEALTH, healthValue)
    If Not latchReadSucceeded Or Not latchIsSet Then _
        AppendCandidateSafetyDetail detailText, _
            "独立復旧ラッチを設定済みとして一意に確認できません。"
    If Not healthReadSucceeded Or _
       StrComp(healthValue, DATA_HEALTH_NEEDS_RECOVERY, vbBinaryCompare) <> 0 Then _
        AppendCandidateSafetyDetail detailText, _
            "案件要復旧状態を一意に確認できません。"
    TryConfirmCandidateRecoveryState = _
        latchReadSucceeded And latchIsSet And healthReadSucceeded And _
        (StrComp(healthValue, DATA_HEALTH_NEEDS_RECOVERY, vbBinaryCompare) = 0)
End Function

Private Function TryEnterCandidateRecoveryStateExact( _
        ByRef recoveryDetail As String, _
        ByRef gateDetail As String) As Boolean
    Dim recoveryErrorNumber As Long, recoveryErrorDescription As String
    Dim postRecoveryStopDetail As String, finalStopDetail As String
    Dim confirmationDetail As String, applicationStateProblems As String
    Dim postRecoveryStopped As Boolean
    gateDetail = vbNullString

    If Not TryStopCandidateEventsForBookWrites(gateDetail) Then
        gateDetail = "Recovery書込み前にExcelイベント停止を確認できません: " & _
                     gateDetail
        Exit Function
    End If

    On Error Resume Next
    Err.Clear
    EnforceRollbackRecoveryState recoveryDetail
    recoveryErrorNumber = Err.Number
    recoveryErrorDescription = Err.Description
    Err.Clear
    On Error GoTo 0

    'Enforce内部がイベント値を戻し得るため、結果にかかわらずfresh Falseへ収束する。
    postRecoveryStopDetail = vbNullString
    postRecoveryStopped = _
        TryStopCandidateEventsForBookWrites(postRecoveryStopDetail)
    If Not postRecoveryStopped Then
        gateDetail = "Recovery処理後にExcelイベント停止を確認できません: " & _
                     postRecoveryStopDetail
        If recoveryErrorNumber <> 0 Then _
            AppendCandidateSafetyDetail gateDetail, _
                "Enforce Err " & CStr(recoveryErrorNumber) & " " & _
                recoveryErrorDescription
        gateDetail = recoveryDetail & " / " & gateDetail
    ElseIf recoveryErrorNumber <> 0 Then
        gateDetail = "Enforce Err " & CStr(recoveryErrorNumber) & " " & _
                     recoveryErrorDescription & _
                     "。既存Recovery状態は読み戻さず、ExcelイベントをFalseに維持しました。"
    Else
        gateDetail = recoveryDetail
    End If

    '局所Enforceを一度試行した後は、成功・失敗を問わず外側ownerへterminal markerを渡す。
    'Err時はFalse収束以外を行わず、正常return時だけRecovery/AppState/final Falseを確認する。
    If recoveryErrorNumber <> 0 Then
        Err.Raise CANDIDATE_RECOVERY_HARD_BARRIER_ERROR, _
                  CANDIDATE_RECOVERY_HARD_BARRIER_SOURCE & _
                      "TryEnterCandidateRecoveryStateExact/EnforceError", _
                  gateDetail
    End If
    If Not postRecoveryStopped Then
        Err.Raise CANDIDATE_RECOVERY_HARD_BARRIER_ERROR, _
                  CANDIDATE_RECOVERY_HARD_BARRIER_SOURCE & _
                      "TryEnterCandidateRecoveryStateExact/PostFalseFailed", _
                  gateDetail
    End If

    confirmationDetail = vbNullString
    If Not TryConfirmCandidateRecoveryState(confirmationDetail) Then
        AppendCandidateSafetyDetail gateDetail, _
            "Recoveryの二重状態を確認できません: " & confirmationDetail
        finalStopDetail = vbNullString
        Call TryStopCandidateEventsForBookWrites(finalStopDetail)
        Err.Raise CANDIDATE_RECOVERY_HARD_BARRIER_ERROR, _
                  CANDIDATE_RECOVERY_HARD_BARRIER_SOURCE & _
                      "TryEnterCandidateRecoveryStateExact/RecoveryUnconfirmed", _
                  gateDetail
    End If
    applicationStateProblems = vbNullString
    If Not AppStateIsRestored(applicationStateProblems) Then
        AppendCandidateSafetyDetail gateDetail, _
            "Application状態を安全に確認できません: " & _
            applicationStateProblems
        finalStopDetail = vbNullString
        Call TryStopCandidateEventsForBookWrites(finalStopDetail)
        Err.Raise CANDIDATE_RECOVERY_HARD_BARRIER_ERROR, _
                  CANDIDATE_RECOVERY_HARD_BARRIER_SOURCE & _
                      "TryEnterCandidateRecoveryStateExact/AppStateUnconfirmed", _
                  gateDetail
    End If
    finalStopDetail = vbNullString
    If Not TryStopCandidateEventsForBookWrites(finalStopDetail) Then _
        AppendCandidateSafetyDetail gateDetail, _
            "最終Excelイベント停止を確認できません: " & finalStopDetail
    Err.Raise CANDIDATE_RECOVERY_HARD_BARRIER_ERROR, _
              CANDIDATE_RECOVERY_HARD_BARRIER_SOURCE & _
                  "TryEnterCandidateRecoveryStateExact/EnforceReturned", _
              gateDetail
End Function

Private Function TryRestoreCandidateEnableEvents( _
        ByVal previousValue As Boolean, _
        ByVal operationName As String, _
        ByRef detailText As String) As Boolean
    Dim firstDetail As String, retryDetail As String
    detailText = vbNullString
    If TrySetCandidateEnableEventsExact(previousValue, firstDetail) Then
        TryRestoreCandidateEnableEvents = True
        Exit Function
    End If
    '一時的なCOM失敗なら同じ開始値への再試行で収束させる。
    If TrySetCandidateEnableEventsExact(previousValue, retryDetail) Then
        TryRestoreCandidateEnableEvents = True
        Exit Function
    End If
    detailText = "Excelイベント状態を開始値へ復元できませんでした。初回=" & _
                 firstDetail & " / 再試行=" & retryDetail
    '中央Recoveryを一度でも試行した後は、この入口をterminalとする。
    'StopAfterは試行時にhard barrierをraiseし、試行前停止不能時だけFalseを返す。
    'いずれの場合も開始値Trueへの再試行は行わない。
    Call StopAfterCandidateEventStateFailure(operationName, detailText)
End Function

Private Function StopAfterCandidateEventStateFailure( _
        ByVal operationName As String, _
        ByRef detailText As String) As Boolean
    Dim recoveryDetail As String, stopDetail As String
    Dim postRecoveryStopDetail As String
    Dim recoveryConfirmed As Boolean
    recoveryDetail = operationName & ": " & detailText
    If Not TryStopCandidateEventsForBookWrites(stopDetail) Then
        AppendCandidateSafetyDetail recoveryDetail, _
            "イベント停止未確認のため、ブックへのRecovery・診断・状態表示の書込みを見送りました: " & _
            stopDetail
        AppendCandidateSafetyDetail recoveryDetail, _
            "Excelイベント状態と案件の安全状態は不明です。"
        detailText = recoveryDetail
        Exit Function
    End If
    AppendCandidateSafetyDetail recoveryDetail, _
        "要復旧記録前にExcelイベント停止を読戻し確認しました。"
    postRecoveryStopDetail = vbNullString
    recoveryConfirmed = _
        TryEnterCandidateRecoveryStateExact( _
            recoveryDetail, postRecoveryStopDetail)
    If Not recoveryConfirmed Then
        AppendCandidateSafetyDetail recoveryDetail, _
            "Recoveryを一意に確認できないため、診断・状態表示を行いません: " & _
            postRecoveryStopDetail
        detailText = recoveryDetail
        Exit Function
    End If
    'TryEnterはEnforce attemptの成否を問わずhard barrierをraiseする契約である。
    '将来誤って正常returnしても、診断・状態表示・開始値復元へは進めない。
    detailText = recoveryDetail
End Function

Private Function PersonCandidateIdentityEditTouchesAssignedID(ByVal ws As Worksheet, _
                                                               ByVal identityAffected As Range) As Boolean
    Dim cell As Range
    If ws Is Nothing Or identityAffected Is Nothing Then Exit Function
    For Each cell In identityAffected.Cells
        If cell.Row >= 2 And Len(CellText(ws.Cells(cell.Row, 2).Value)) > 0 Then
            PersonCandidateIdentityEditTouchesAssignedID = True
            Exit Function
        End If
    Next cell
End Function

Private Sub MergeBlankPersonCandidateDuplicates(ByVal ws As Worksheet)
    '手入力で同じ氏名・続柄を末尾へ追加しても、人物IDなしの表示重複を残さない。
    Dim lastR As Long, r As Long, keptRow As Long
    Dim identityKey As String, personID As String, keptID As String
    Dim sourceText As String, keptSource As String
    Dim rowsByIdentity As Object
    If ws Is Nothing Then Exit Sub
    lastR = LastDataRowInColumns(ws, 1, 4)
    If lastR < 2 Then Exit Sub
    Set rowsByIdentity = CreateObject("Scripting.Dictionary")
    rowsByIdentity.CompareMode = vbTextCompare
    For r = 2 To lastR
        If Not ws.Cells(r, 1).HasFormula And Not ws.Cells(r, 3).HasFormula And _
           Not IsError(ws.Cells(r, 1).Value) And Not IsError(ws.Cells(r, 3).Value) Then
            identityKey = PersonIdentityKey(CellText(ws.Cells(r, 1).Value), _
                                            CellText(ws.Cells(r, 3).Value))
            If Len(identityKey) > 0 Then
                personID = CellText(ws.Cells(r, 2).Value)
                If Len(personID) = 0 Or IsInternalIdValue(personID, "P") Then
                    If rowsByIdentity.Exists(identityKey) Then
                        keptRow = CLng(rowsByIdentity(identityKey))
                        keptID = CellText(ws.Cells(keptRow, 2).Value)
                        sourceText = CellText(ws.Cells(r, 4).Value)
                        keptSource = CellText(ws.Cells(keptRow, 4).Value)
                        If Len(keptID) > 0 And Len(personID) > 0 And _
                           StrComp(keptID, personID, vbTextCompare) <> 0 Then
                            '異なる人物IDはここで消さない。
                        ElseIf Len(keptID) = 0 And Len(personID) > 0 Then
                            If sourceText = CAND_SOURCE_COMMON Or keptSource = CAND_SOURCE_COMMON Then _
                                ws.Cells(r, 4).Value = CAND_SOURCE_COMMON
                            ws.Range(ws.Cells(keptRow, 1), ws.Cells(keptRow, 4)).ClearContents
                            rowsByIdentity(identityKey) = r
                        Else
                            If sourceText = CAND_SOURCE_COMMON Or keptSource = CAND_SOURCE_COMMON Then _
                                ws.Cells(keptRow, 4).Value = CAND_SOURCE_COMMON
                            ws.Range(ws.Cells(r, 1), ws.Cells(r, 4)).ClearContents
                        End If
                    Else
                        rowsByIdentity.Add identityKey, r
                    End If
                End If
            End If
        End If
    Next r
End Sub

Private Sub CompactCandidateRows(ByVal ws As Worksheet)
    '途中行を削除・飛び行へ貼り付けても、候補名の定義範囲へ空白を残さない。
    Dim lastR As Long, rowCount As Long
    Dim sourceData As Variant, compactedData() As Variant
    Dim r As Long, c As Long, writeRow As Long
    Dim keepRow As Boolean, compactionNeeded As Boolean
    If ws Is Nothing Then Exit Sub
    lastR = LastDataRowInColumns(ws, 1, 4)
    If lastR < 2 Then Exit Sub
    rowCount = lastR - 1
    sourceData = ws.Range(ws.Cells(2, 1), ws.Cells(lastR, 4)).Formula
    ReDim compactedData(1 To rowCount, 1 To 4)
    For r = 1 To rowCount
        keepRow = IsError(sourceData(r, 1)) Or Len(CellText(sourceData(r, 1))) > 0
        If keepRow Then
            writeRow = writeRow + 1
            If writeRow <> r Then compactionNeeded = True
            For c = 1 To 4
                compactedData(writeRow, c) = sourceData(r, c)
            Next c
        Else
            compactionNeeded = True
        End If
    Next r
    If compactionNeeded Then
        ws.Range(ws.Cells(2, 1), ws.Cells(lastR, 4)).ClearContents
        If writeRow > 0 Then
            ws.Range(ws.Cells(2, 1), ws.Cells(1 + rowCount, 4)).Formula = compactedData
        End If
    End If
End Sub

Private Sub RefreshCandidateNameForSheet(ByVal sheetName As String)
    Select Case sheetName
        Case SH_BANK_CAND
            RefreshSingleCandidateName SH_BANK_CAND, NM_LST_BANK_CAND
        Case SH_BRANCH_CAND
            RefreshSingleCandidateName SH_BRANCH_CAND, NM_LST_BRANCH_CAND
        Case SH_PERSON_CAND
            RefreshSingleCandidateName SH_PERSON_CAND, NM_LST_PERSON_CAND
        Case SH_ACCOUNT_TYPE
            RefreshSingleCandidateName SH_ACCOUNT_TYPE, NM_LST_ACCOUNT_TYPE
        Case SH_TEKIYO
            RefreshSingleCandidateName SH_TEKIYO, NM_LST_TEKIYO
    End Select
End Sub

Private Function CandidateSheetNames() As Variant
    CandidateSheetNames = Array(SH_BANK_CAND, SH_BRANCH_CAND, SH_PERSON_CAND, _
                                SH_ACCOUNT_TYPE, SH_TEKIYO)
End Function

Public Function IsCandidateSheetName(ByVal sheetName As String) As Boolean
    Dim item As Variant
    For Each item In CandidateSheetNames()
        If StrComp(CStr(item), sheetName, vbTextCompare) = 0 Then
            IsCandidateSheetName = True
            Exit Function
        End If
    Next item
End Function

Public Function CandidateEditableLastRow(ByVal ws As Worksheet) As Long
    Dim lastR As Long
    CandidateEditableLastRow = 2
    If ws Is Nothing Then Exit Function
    lastR = LastDataRowInColumns(ws, 1, 4)
    If lastR < 1 Then lastR = 1
    CandidateEditableLastRow = Application.Min(MAX_CANDIDATE_DATA_ROWS + 1, _
        Application.Max(501, lastR + CANDIDATE_EDIT_BUFFER_ROWS))
End Function

Private Sub EnsureCandidateProtectionCapacity(ByVal ws As Worksheet)
    Dim requiredLastRow As Long, protectedLastRow As Long
    If ws Is Nothing Then Exit Sub
    requiredLastRow = CandidateEditableLastRow(ws)
    If mCandidateEditableThrough Is Nothing Then
        ProtectCandidateSheet ws, True
        Exit Sub
    End If
    If Not mCandidateEditableThrough.Exists(ws.Name) Then
        ProtectCandidateSheet ws, True
        Exit Sub
    End If
    protectedLastRow = CLng(mCandidateEditableThrough(ws.Name))
    '増加だけでなく縮小時も旧開放範囲を再ロックし、現在上限の直後を必ず閉じる。
    If protectedLastRow <> requiredLastRow Then ProtectCandidateSheet ws, True
End Sub

Public Sub ProtectCandidateSheet(ByVal ws As Worksheet, _
                                 Optional ByVal raiseOnError As Boolean = False)
    '候補値の入力列だけを開け、右側ナビゲーションとレイアウトは保護する。
    '最大実用件数までを一括設定し、表示のたびに全104万行を走査しない。
    Dim editableLastRow As Long, lockLastRow As Long, cachedEditableLastRow As Long
    Dim protectionModeMatches As Boolean, candidateReadOnly As Boolean
    Dim previousRangeKnown As Boolean
    Dim workbookWasSaved As Boolean
    Dim emergencyProtected As Boolean, savedReadback As Boolean
    Dim previousEvents As Boolean, eventsCaptured As Boolean
    Dim eventsStoppedForRecovery As Boolean, recoveryStateConfirmed As Boolean
    Dim safeToRestoreEntry As Boolean
    Dim eventRestoreSucceeded As Boolean
    Dim applicationStateSafe As Boolean, applicationStateProblems As String
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim emergencyErrorNumber As Long, emergencyErrorDescription As String
    Dim emergencyReadErrorNumber As Long, emergencyReadErrorDescription As String
    Dim savedErrorNumber As Long, savedErrorDescription As String
    Dim savedReadErrorNumber As Long, savedReadErrorDescription As String
    Dim recoveryErrorNumber As Long, recoveryErrorDescription As String
    Dim recoveryErrorSource As String
    Dim recoveryDetail As String, sheetName As String
    Dim eventStateDetail As String, eventRestoreDetail As String
    Dim postRecoveryStopDetail As String
    If ws Is Nothing Then Exit Sub
    If Not IsCandidateSheetName(ws.Name) Then _
        Err.Raise vbObjectError + 2130, "ProtectCandidateSheet", _
                  "候補シートではありません: " & ws.Name
    sheetName = ws.Name
    If Not TryGetCandidateEnableEvents(previousEvents, eventStateDetail) Then
        Call StopAfterCandidateEventStateFailure( _
                 "ProtectCandidateSheet/開始状態取得", eventStateDetail)
        If raiseOnError Then _
            Err.Raise vbObjectError + 2148, _
                      "ProtectCandidateSheet(" & sheetName & ")", _
                      "Excelイベントの開始状態を取得できませんでした。 " & _
                      eventStateDetail
        Exit Sub
    End If
    eventsCaptured = True
    If Not TryStopCandidateEventsForBookWrites(eventStateDetail) Then
        errorDescription = _
            "候補シート保護前にExcelイベントを停止して読戻し確認できませんでした。 " & _
            eventStateDetail
        On Error Resume Next
        MsgBox errorDescription & vbCrLf & _
               "ブックへの保護・状態記録は行わず、案件の安全状態は不明です。" & _
               vbCrLf & "現在のブックを上書きしないでください。", _
               vbCritical, "候補シートを安全に保護できません"
        On Error GoTo 0
        If Not TryRestoreCandidateEnableEvents( _
                   previousEvents, "ProtectCandidateSheet/保護開始前", _
                   eventRestoreDetail) Then _
            AppendCandidateSafetyDetail errorDescription, _
                "Excelイベント状態の復元エラー: " & eventRestoreDetail
        eventsCaptured = False
        If raiseOnError Then _
            Err.Raise vbObjectError + 2149, _
                      "ProtectCandidateSheet(" & sheetName & ")", _
                      errorDescription
        Exit Sub
    End If
    eventsStoppedForRecovery = True
    workbookWasSaved = ThisWorkbook.Saved
    On Error GoTo EH
    candidateReadOnly = ThisWorkbook.ReadOnly Or _
                        (ws.Name = SH_PERSON_CAND And _
                         (IsEditMode() Or CurrentAccountInputHasData()))
    editableLastRow = CandidateEditableLastRow(ws)
    If mCandidateEditableThrough Is Nothing Then
        Set mCandidateEditableThrough = CreateObject("Scripting.Dictionary")
        mCandidateEditableThrough.CompareMode = vbTextCompare
    End If
    If mCandidateEditableThrough.Exists(ws.Name) Then
        cachedEditableLastRow = CLng(mCandidateEditableThrough(ws.Name))
        previousRangeKnown = True
    Else
        cachedEditableLastRow = StoredCandidateEditableLastRow(ws)
        If cachedEditableLastRow > 0 Then
            mCandidateEditableThrough(ws.Name) = cachedEditableLastRow
            previousRangeKnown = True
        End If
    End If
    If previousRangeKnown Then
        If candidateReadOnly Then
            protectionModeMatches = CBool(ws.Range("A2").Locked)
        Else
            protectionModeMatches = Not CBool(ws.Range("A2").Locked)
            If ws.Name = SH_PERSON_CAND Then _
                protectionModeMatches = protectionModeMatches And _
                                        Not CBool(ws.Range("C2").Locked)
        End If
        '同じ表示操作のActivateイベントから直後に再度呼ばれても、
        '編集範囲と読取専用状態が一致する保護済みシートは数万セルを再設定しない。
        If ws.ProtectContents And _
           cachedEditableLastRow = editableLastRow And protectionModeMatches Then
            RestoreToolSheetScrollArea ws
            If candidateReadOnly Then
                ws.EnableSelection = xlNoSelection
            Else
                ws.EnableSelection = xlUnlockedCells
            End If
            VerifyToolShapeSecurity ws, True, False
            If workbookWasSaved Then ThisWorkbook.Saved = True
            GoTo SafeExit
        End If
    End If
    lockLastRow = editableLastRow + CANDIDATE_LOCK_BUFFER_ROWS
    '候補減少時は、以前開けていた範囲も一度ロックし直してから現在範囲だけを開ける。
    If previousRangeKnown Then
        If cachedEditableLastRow > lockLastRow Then lockLastRow = cachedEditableLastRow
    Else
        '旧範囲を示すキャッシュも永続マーカーもない時は、過去の遠方unlockを残さない。
        lockLastRow = MAX_CANDIDATE_DATA_ROWS + 1 + CANDIDATE_LOCK_BUFFER_ROWS
    End If
    If lockLastRow > ws.Rows.Count Then lockLastRow = ws.Rows.Count
    If editableLastRow > lockLastRow Then editableLastRow = lockLastRow
    ws.Unprotect Password:=TOOL_PASSWORD
    RestoreToolSheetScrollArea ws
    ws.Range("A1:D" & CStr(lockLastRow)).Locked = True
    If Not candidateReadOnly Then
        ws.Range("A2:A" & CStr(editableLastRow)).Locked = False
        If ws.Name = SH_PERSON_CAND Then _
            ws.Range("C2:C" & CStr(editableLastRow)).Locked = False
    End If
    LockToolShapes ws, False
    ws.Protect Password:=TOOL_PASSWORD, DrawingObjects:=True, Contents:=True, Scenarios:=False, _
               UserInterfaceOnly:=True, AllowFiltering:=False, AllowSorting:=False, _
               AllowFormattingCells:=False, AllowFormattingColumns:=False, AllowFormattingRows:=False, _
               AllowInsertingColumns:=False, AllowInsertingRows:=False, _
               AllowDeletingColumns:=False, AllowDeletingRows:=False
    If candidateReadOnly Then
        ws.EnableSelection = xlNoSelection
    Else
        ws.EnableSelection = xlUnlockedCells
    End If
    mCandidateEditableThrough(ws.Name) = editableLastRow
    StoreCandidateEditableLastRow ws, editableLastRow
    VerifyToolShapeSecurity ws, True, False
    If workbookWasSaved Then ThisWorkbook.Saved = True
SafeExit:
    If eventsCaptured Then
        If Not TryRestoreCandidateEnableEvents( _
                   previousEvents, "ProtectCandidateSheet/正常終了", _
                   eventRestoreDetail) Then
            eventsCaptured = False
            On Error GoTo 0
            If raiseOnError Then _
                Err.Raise vbObjectError + 2150, _
                          "ProtectCandidateSheet(" & sheetName & ")", _
                          eventRestoreDetail
            Exit Sub
        End If
        eventsCaptured = False
    End If
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    If IsCandidateRecoveryHardBarrier(errorNumber, errorSource) Then
        Call TryStopCandidateEventsForBookWrites(eventStateDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    On Error Resume Next
    Err.Clear
    EmergencyProtectToolSheet ws
    emergencyErrorNumber = Err.Number
    emergencyErrorDescription = Err.Description
    Err.Clear
    emergencyProtected = ws.ProtectContents And ws.ProtectDrawingObjects
    emergencyReadErrorNumber = Err.Number
    emergencyReadErrorDescription = Err.Description
    Err.Clear
    If emergencyErrorNumber <> 0 Then emergencyProtected = False
    If emergencyErrorNumber <> 0 Or emergencyReadErrorNumber <> 0 Or _
       Not emergencyProtected Then
        recoveryDetail = "候補シートの緊急再保護を確認できません。"
        If emergencyErrorNumber <> 0 Then _
            recoveryDetail = recoveryDetail & " Err " & _
                             CStr(emergencyErrorNumber) & " " & _
                             emergencyErrorDescription
        If emergencyReadErrorNumber <> 0 Then _
            recoveryDetail = recoveryDetail & " / 保護読戻し Err " & _
                             CStr(emergencyReadErrorNumber) & " " & _
                             emergencyReadErrorDescription
        eventsStoppedForRecovery = _
            TryStopCandidateEventsForBookWrites(eventStateDetail)
        If eventsStoppedForRecovery Then
            AppendCandidateSafetyDetail recoveryDetail, _
                "要復旧記録前にExcelイベント停止を読戻し確認しました。"
            postRecoveryStopDetail = vbNullString
            recoveryStateConfirmed = _
                TryEnterCandidateRecoveryStateExact( _
                    recoveryDetail, postRecoveryStopDetail)
            recoveryErrorNumber = Err.Number
            recoveryErrorSource = Err.Source
            recoveryErrorDescription = Err.Description
            Err.Clear
            If IsCandidateRecoveryHardBarrier( _
                   recoveryErrorNumber, recoveryErrorSource) Then
                Call TryStopCandidateEventsForBookWrites(eventStateDetail)
                On Error GoTo 0
                Err.Raise recoveryErrorNumber, recoveryErrorSource, _
                          recoveryErrorDescription
            End If
            eventsStoppedForRecovery = recoveryStateConfirmed
            AppendCandidateSafetyDetail errorDescription, recoveryDetail
            If recoveryStateConfirmed Then
                On Error Resume Next
                AddCheck "エラー", "候補シートの緊急再保護", recoveryDetail
                SetInputStatus "候補シートの緊急再保護を確認できないため、" & _
                               "案件を要復旧として停止しました。", True
                Err.Clear
                On Error GoTo 0
                postRecoveryStopDetail = vbNullString
                eventsStoppedForRecovery = _
                    TryStopCandidateEventsForBookWrites( _
                        postRecoveryStopDetail)
                If eventsStoppedForRecovery Then
                    recoveryStateConfirmed = _
                        TryConfirmCandidateRecoveryState(recoveryDetail)
                Else
                    recoveryStateConfirmed = False
                End If
            Else
                AppendCandidateSafetyDetail recoveryDetail, _
                    "Recoveryを一意に確認できないため、診断・状態表示を行いません: " & _
                    postRecoveryStopDetail
                eventStateDetail = vbNullString
                eventsStoppedForRecovery = _
                    TryStopCandidateEventsForBookWrites(eventStateDetail)
            End If
        Else
            AppendCandidateSafetyDetail errorDescription, recoveryDetail
            AppendCandidateSafetyDetail errorDescription, _
                "Excelイベント停止を確認できないためRecovery・診断・状態表示の書込みを見送り、" & _
                "案件の安全状態は不明です: " & eventStateDetail
            Err.Clear
            MsgBox "候補シートの緊急再保護に失敗し、Excelイベントも安全に停止できませんでした。" & _
                   vbCrLf & "ブックへの復旧記録を見送り、案件の安全状態は不明です。" & _
                   vbCrLf & "現在のブックを上書きしないでください。", _
                   vbCritical, "候補シートの安全状態を確認できません"
            Err.Clear
        End If
    End If
    '開始時に保存済みでも、緊急保護とその読戻しが成立した場合だけ
    '保護操作によるSaved変更を戻す。保護不成立を保存済み扱いで隠さない。
    If emergencyProtected Then
        eventStateDetail = vbNullString
        eventsStoppedForRecovery = _
            TryStopCandidateEventsForBookWrites(eventStateDetail)
        If Not eventsStoppedForRecovery Then _
            AppendCandidateSafetyDetail errorDescription, _
                "緊急再保護後のExcelイベント停止を確認できないため、" & _
                "Saved復元と開始値へのイベント復元を見送りました: " & _
                eventStateDetail
    End If
    If emergencyProtected And eventsStoppedForRecovery And workbookWasSaved Then
        ThisWorkbook.Saved = True
        savedErrorNumber = Err.Number
        savedErrorDescription = Err.Description
        Err.Clear
        savedReadback = ThisWorkbook.Saved
        savedReadErrorNumber = Err.Number
        savedReadErrorDescription = Err.Description
        Err.Clear
        If savedErrorNumber <> 0 Or savedReadErrorNumber <> 0 Or _
           Not savedReadback Then
            AppendCandidateSafetyDetail errorDescription, _
                "ブック保存状態の復元を確認できません" & _
                IIf(savedErrorNumber <> 0, _
                    ": Err " & CStr(savedErrorNumber) & " " & _
                    savedErrorDescription, vbNullString) & _
                IIf(savedReadErrorNumber <> 0, _
                    " / 読戻し Err " & CStr(savedReadErrorNumber) & _
                    " " & savedReadErrorDescription, vbNullString)
        End If
    End If
    safeToRestoreEntry = Not previousEvents
    If previousEvents Then
        safeToRestoreEntry = eventsStoppedForRecovery And emergencyProtected
        If Not safeToRestoreEntry And eventsStoppedForRecovery And _
           recoveryStateConfirmed Then
            applicationStateProblems = vbNullString
            applicationStateSafe = _
                AppStateIsRestored(applicationStateProblems)
            safeToRestoreEntry = applicationStateSafe
            If Not applicationStateSafe Then _
                AppendCandidateSafetyDetail errorDescription, _
                    "開始値Trueへの復元前にApplication状態を確認できません: " & _
                    applicationStateProblems
        End If
    End If
    If eventsCaptured Then
        If safeToRestoreEntry Then
            eventRestoreSucceeded = _
                TryRestoreCandidateEnableEvents( _
                    previousEvents, "ProtectCandidateSheet/異常終了", _
                    eventRestoreDetail)
            recoveryErrorNumber = Err.Number
            recoveryErrorSource = Err.Source
            recoveryErrorDescription = Err.Description
            Err.Clear
            If IsCandidateRecoveryHardBarrier( _
                   recoveryErrorNumber, recoveryErrorSource) Then
                Call TryStopCandidateEventsForBookWrites(eventStateDetail)
                On Error GoTo 0
                Err.Raise recoveryErrorNumber, recoveryErrorSource, _
                          recoveryErrorDescription
            End If
            If Not eventRestoreSucceeded Then _
                AppendCandidateSafetyDetail errorDescription, _
                    "Excelイベント状態の復元エラー: " & eventRestoreDetail
        Else
            eventStateDetail = vbNullString
            If TryStopCandidateEventsForBookWrites(eventStateDetail) Then
                AppendCandidateSafetyDetail errorDescription, _
                    "保護または要復旧を一意に確定できないため、" & _
                    "ExcelイベントをFalseに保持しました。"
            Else
                AppendCandidateSafetyDetail errorDescription, _
                    "ExcelイベントのFalse収束も確認できず、" & _
                    "案件の安全状態は不明です: " & eventStateDetail
            End If
        End If
    End If
    eventsCaptured = False
    On Error GoTo 0
    If raiseOnError Then _
        Err.Raise errorNumber, "ProtectCandidateSheet(" & sheetName & ")", _
                  IIf(Len(errorSource) > 0, errorSource & " / ", vbNullString) & _
                  errorDescription
End Sub

Public Sub ProtectAllCandidateSheets(Optional ByVal raiseOnError As Boolean = False)
    Dim item As Variant
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim eventStateDetail As String
    On Error GoTo EH
    For Each item In CandidateSheetNames()
        If SheetExists(CStr(item)) Then ProtectCandidateSheet GetSheet(CStr(item)), True
    Next item
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    If IsCandidateRecoveryHardBarrier(errorNumber, errorSource) Then
        Call TryStopCandidateEventsForBookWrites(eventStateDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    If raiseOnError Then Err.Raise errorNumber, "ProtectAllCandidateSheets", errorDescription
End Sub

Private Sub FormatCandidateSheetForEditing(ByVal ws As Worksheet)
    Dim lastStyleRow As Long
    If ws Is Nothing Then Exit Sub
    lastStyleRow = Application.Min(10000, Application.Max(50, LastRow(ws, 1) + 25))
    With ws
        .Range("A1:J" & CStr(lastStyleRow)).Font.Name = "Yu Gothic UI"
        .Range("A1:J" & CStr(lastStyleRow)).Font.Size = 10.5
        .Columns("A:A").ColumnWidth = IIf(ws.Name = SH_TEKIYO, 48, 30)
        .Columns("B:D").Hidden = True
        If ws.Name = SH_PERSON_CAND Then
            .Columns("C:C").Hidden = False
            .Columns("C:C").ColumnWidth = 18
        End If
        .Columns("F:J").Hidden = False
        .Columns("F:J").ColumnWidth = 13
        .Rows(1).RowHeight = 28
        .ScrollArea = "A1:J" & CStr(Application.Min(.Rows.Count, _
                      Application.Max(500, LastRow(ws, 1) + 500)))
    End With
    FormatOutputHeader ws.Range("A1:D1")
    FormatCandidateEntryArea ws, lastStyleRow
End Sub

Private Sub FormatCandidateEntryArea(ByVal ws As Worksheet, ByVal lastStyleRow As Long, _
                                     Optional ByVal firstStyleRow As Long = 2)
    Dim visibleRange As Range
    If ws Is Nothing Or lastStyleRow < 2 Then Exit Sub
    If firstStyleRow < 2 Then firstStyleRow = 2
    If firstStyleRow > lastStyleRow Then Exit Sub
    If ws.Name = SH_PERSON_CAND Then
        Set visibleRange = Union(ws.Range("A" & CStr(firstStyleRow) & ":A" & CStr(lastStyleRow)), _
                                 ws.Range("C" & CStr(firstStyleRow) & ":C" & CStr(lastStyleRow)))
    Else
        Set visibleRange = ws.Range("A" & CStr(firstStyleRow) & ":A" & CStr(lastStyleRow))
    End If
    With visibleRange
        .Interior.Color = RGB(255, 255, 255)
        .Font.Color = RGB(15, 23, 42)
        .Borders.LineStyle = xlContinuous
        .Borders.Color = RGB(226, 232, 240)
        .VerticalAlignment = xlCenter
    End With
    ws.Rows(CStr(firstStyleRow) & ":" & CStr(lastStyleRow)).RowHeight = 22
End Sub

Public Sub BuildCandidateNavigationPanel(ByVal ws As Worksheet)
    Dim x As Double, y As Double, w As Double, h As Double
    Dim margin As Double, gap As Double, buttonW As Double, buttonH As Double
    Dim rowY As Double
    If ws Is Nothing Then Exit Sub
    DeleteToolShapesVerified ws, False
    x = ws.Range("F2").Left
    y = ws.Range("F2").Top
    w = ws.Range("F2:J10").Width
    h = ws.Range("F2:J10").Height
    margin = 10
    gap = 7
    buttonW = (w - margin * 2 - gap) / 2
    buttonH = 30

    AddCandidateTextShape ws, UI_PREFIX & "candidate_title", _
                          ws.Range("F1").Left, ws.Range("F1").Top, _
                          ws.Range("F1:J1").Width, ws.Range("F1:J1").Height, _
                          "入力候補を整理", True
    AddPanelBack ws, x, y, w, h
    rowY = y + margin
    AddUIButton ws, x + margin, rowY, buttonW, buttonH, "銀行名", "ShowBankCandidates", _
                IIf(ws.Name = SH_BANK_CAND, "primary", "tool")
    AddUIButton ws, x + margin + buttonW + gap, rowY, buttonW, buttonH, "支店名", _
                "ShowBranchCandidates", IIf(ws.Name = SH_BRANCH_CAND, "primary", "tool")
    rowY = rowY + buttonH + gap
    AddUIButton ws, x + margin, rowY, buttonW, buttonH, "人物・続柄", _
                "ShowPersonCandidates", IIf(ws.Name = SH_PERSON_CAND, "primary", "tool")
    AddUIButton ws, x + margin + buttonW + gap, rowY, buttonW, buttonH, "科目", _
                "ShowAccountTypeCandidates", IIf(ws.Name = SH_ACCOUNT_TYPE, "primary", "tool")
    rowY = rowY + buttonH + gap
    AddUIButton ws, x + margin, rowY, buttonW, buttonH, "摘要", "ShowTekiyoCandidates", _
                IIf(ws.Name = SH_TEKIYO, "primary", "tool")
    AddUIButton ws, x + margin + buttonW + gap, rowY, buttonW, buttonH, "入力へ戻る", _
                "ShowInputSheet", "soft"
    AddCandidateTextShape ws, UI_PREFIX & "candidate_note", _
                          ws.Range("F12").Left, ws.Range("F12").Top, _
                          ws.Range("F12:J13").Width, ws.Range("F12:J13").Height, _
                          "A列へ候補を入力します。人物候補だけはC列に続柄を入力できます。変更は入力リストへ自動反映されます。", False
    LockToolShapes ws, False
End Sub

Private Sub AddCandidateTextShape(ByVal ws As Worksheet, ByVal shapeName As String, _
                                  ByVal x As Double, ByVal y As Double, _
                                  ByVal w As Double, ByVal h As Double, _
                                  ByVal textValue As String, ByVal titleStyle As Boolean)
    Dim shp As Shape
    If ws Is Nothing Then Exit Sub
    Set shp = ws.Shapes.AddShape(msoShapeRoundedRectangle, x, y, w, h)
    With shp
        .Name = shapeName
        .TextFrame.Characters.Text = textValue
        .TextFrame.HorizontalAlignment = xlHAlignCenter
        .TextFrame.VerticalAlignment = xlVAlignCenter
        .TextFrame.MarginLeft = 6
        .TextFrame.MarginRight = 6
        .TextFrame.Characters.Font.Name = "Yu Gothic UI"
        .TextFrame.Characters.Font.Bold = titleStyle
        .TextFrame.Characters.Font.Size = IIf(titleStyle, 10.5, 9.5)
        If titleStyle Then
            .Fill.ForeColor.RGB = RGB(239, 246, 255)
            .Line.ForeColor.RGB = RGB(191, 219, 254)
            .TextFrame.Characters.Font.Color = RGB(30, 64, 175)
        Else
            .Fill.ForeColor.RGB = RGB(248, 250, 252)
            .Line.ForeColor.RGB = RGB(226, 232, 240)
            .TextFrame.Characters.Font.Color = RGB(71, 85, 105)
        End If
        .Placement = xlMove
        .Locked = True
    End With
End Sub

Private Sub SetupCandidateSheet(ByVal sheetName As String, ByVal titleText As String, ByVal listName As String, ByVal resetContents As Boolean)
    Dim ws As Worksheet, styleLastRow As Long, lastR As Long, r As Long
    Dim candidateData As Variant, sourceMigrated As Boolean
    Dim needsReset As Boolean
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim eventStateDetail As String
    On Error GoTo EH
    Set ws = GetOrCreateSheet(sheetName, False)
    If ws Is Nothing Then Err.Raise vbObjectError + 2001, "SetupCandidateSheet", "候補シートを作成できません: " & sheetName
    needsReset = resetContents Or Len(CellText(ws.Range("A1").Value)) = 0
    If needsReset Then
        ResetWorksheet ws
        ws.Range("A1").Value = titleText
        ws.Range("A1").Font.Bold = True
        ws.Range("A2:D2").ClearContents
        If sheetName = SH_PERSON_CAND Then
            ws.Range("B1").Value = "人物ID"
            ws.Range("C1").Value = "続柄"
            ws.Range("B1:C1").Font.Bold = True
        End If
        ws.Range("D1").Value = "区分"
        ws.Range("D1").Font.Bold = True
    End If
    '旧版の1列候補を引き継ぐ場合、区分空欄のままだと案件初期化で消える。
    '既存候補は利用者が継続利用してきた共通候補として保護する。
    lastR = LastDataRowInColumns(ws, 1, 4)
    If lastR >= 2 Then
        candidateData = ws.Range(ws.Cells(2, 1), ws.Cells(lastR, 4)).Value2
        For r = 1 To UBound(candidateData, 1)
            If Len(CellText(candidateData(r, 1))) > 0 And Len(CellText(candidateData(r, 4))) = 0 Then
                candidateData(r, 4) = CAND_SOURCE_COMMON
                sourceMigrated = True
            End If
        Next r
        If sourceMigrated Then ws.Range(ws.Cells(2, 1), ws.Cells(lastR, 4)).Value2 = candidateData
    End If
    ws.Visible = xlSheetVisible
    styleLastRow = Application.Max(2, LastRow(ws, 1))
    With ws.Range("A1:D" & CStr(styleLastRow))
        .Font.Name = "Yu Gothic UI"
        .Font.Size = 10
    End With
    ws.Columns("A:A").ColumnWidth = 28
    ws.Columns("A:D").NumberFormatLocal = "@"
    If sheetName = SH_PERSON_CAND Then
        ws.Columns("B:B").ColumnWidth = 18
        ws.Columns("B:B").Hidden = True
        ws.Columns("C:C").ColumnWidth = 18
    End If
    ws.Columns("D:D").Hidden = True
    RefreshSingleCandidateName sheetName, listName
    ProtectCandidateSheet ws, True
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    If IsCandidateRecoveryHardBarrier(errorNumber, errorSource) Then
        Call TryStopCandidateEventsForBookWrites(eventStateDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    Err.Raise errorNumber, "SetupCandidateSheet(" & sheetName & ")", errorDescription
End Sub

Public Sub RefreshAccountCandidateNames()
    RefreshSingleCandidateName SH_BANK_CAND, NM_LST_BANK_CAND
    RefreshSingleCandidateName SH_BRANCH_CAND, NM_LST_BRANCH_CAND
    RefreshSingleCandidateName SH_PERSON_CAND, NM_LST_PERSON_CAND
End Sub

Public Sub RefreshAllCandidateNames()
    RefreshAccountCandidateNames
    RefreshSingleCandidateName SH_ACCOUNT_TYPE, NM_LST_ACCOUNT_TYPE
    RefreshSingleCandidateName SH_TEKIYO, NM_LST_TEKIYO
End Sub

Private Sub RefreshSingleCandidateName(ByVal sheetName As String, ByVal listName As String)
    Dim ws As Worksheet
    Dim lastR As Long
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim eventStateDetail As String
    On Error GoTo EH
    If Not SheetExists(sheetName) Then Exit Sub
    Set ws = GetSheet(sheetName)
    lastR = LastRow(ws, 1)
    If lastR < 2 Then
        lastR = 2
    End If
    ResetName listName, ws.Range("A2:A" & CStr(lastR))
    'イベント停止中の一括追加・初期化でも、候補件数に合わせて開放範囲を増減させる。
    EnsureCandidateProtectionCapacity ws
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    If IsCandidateRecoveryHardBarrier(errorNumber, errorSource) Then
        Call TryStopCandidateEventsForBookWrites(eventStateDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    If Len(errorSource) = 0 Then _
        errorSource = "RefreshSingleCandidateName(" & sheetName & ")"
    Err.Raise errorNumber, errorSource, errorDescription
End Sub

Public Sub UpdateAccountCandidates(ByVal bankName As String, ByVal branchName As String, ByVal personName As String)
    AddCandidateValue SH_BANK_CAND, NM_LST_BANK_CAND, bankName, CAND_SOURCE_CASE
    AddCandidateValue SH_BRANCH_CAND, NM_LST_BRANCH_CAND, branchName, CAND_SOURCE_CASE
    '人物は人物ID・続柄と一体で AddPersonCandidateWithID から登録する。
End Sub

Public Sub ResetCaseCandidates()
    '共通データ由来は残し、案件入力・外部取込で学習した候補だけを消す。
    RemoveCaseCandidateRows SH_BANK_CAND, NM_LST_BANK_CAND
    RemoveCaseCandidateRows SH_BRANCH_CAND, NM_LST_BRANCH_CAND
    RemoveCaseCandidateRows SH_PERSON_CAND, NM_LST_PERSON_CAND
    '利用者が科目・摘要候補へ直接追記した場合も、初期化後の入力規則へ全件を再接続する。
    RefreshAllCandidateNames
End Sub

Public Sub ValidateCaseCandidateResetSources()
    '初期化後も残る共通候補に不正な区分があると、案件データを消した後の
    ValidateCandidateResetSourceSheet SH_BANK_CAND
    ValidateCandidateResetSourceSheet SH_BRANCH_CAND
    ValidateCandidateResetSourceSheet SH_PERSON_CAND
End Sub

Public Sub AddAccountTypeCandidate(ByVal accountType As String)
    AddCandidateValue SH_ACCOUNT_TYPE, NM_LST_ACCOUNT_TYPE, accountType
End Sub

Public Sub AddBankCandidate(ByVal bankName As String, Optional ByVal sourceText As String = CAND_SOURCE_CASE)
    AddCandidateValue SH_BANK_CAND, NM_LST_BANK_CAND, bankName, sourceText
End Sub

Public Sub AddBranchCandidate(ByVal branchName As String, Optional ByVal sourceText As String = CAND_SOURCE_CASE)
    AddCandidateValue SH_BRANCH_CAND, NM_LST_BRANCH_CAND, branchName, sourceText
End Sub

Public Sub AddTekiyoCandidate(ByVal tekiyoText As String)
    AddCandidateValue SH_TEKIYO, NM_LST_TEKIYO, tekiyoText
End Sub

Public Sub AddPersonCandidateWithID(ByVal personName As String, ByVal personID As String, ByVal relationshipText As String, _
                                    Optional ByVal sourceText As String = CAND_SOURCE_CASE)
    Dim ws As Worksheet
    Dim lastR As Long, r As Long
    Dim s As String, batchKey As String
    Dim storedID As String, storedRelationship As String
    Dim requestedIdentityKey As String, storedIdentityKey As String
    Dim conflictingPersonID As String
    Dim conflictingPersonName As String
    Dim previousName As String, previousID As String, previousRelationship As String
    Dim indexedPersonID As String, indexedRelationship As String
    Dim refreshBatchPersonIndex As Boolean
    s = Trim$(CellText(personName))
    If Len(s) = 0 Then Exit Sub
    sourceText = CellText(sourceText)
    If sourceText <> CAND_SOURCE_CASE And sourceText <> CAND_SOURCE_COMMON Then _
        Err.Raise vbObjectError + 2112, "AddPersonCandidateWithID", "候補区分が不正です: " & sourceText
    personID = CellText(personID)
    If Len(personID) > 0 And Not IsInternalIdValue(personID, "P") Then _
        Err.Raise vbObjectError + 2126, "AddPersonCandidateWithID", "人物IDの形式が不正です: " & personID
    If mCandidateBatchDepth > 0 And Not mCandidateBatchRelationshipByID Is Nothing Then
        relationshipText = ValidatedBatchRelationshipForPersonID(personID, relationshipText)
    Else
        relationshipText = ValidatedRelationshipForPersonID(personID, relationshipText)
    End If
    If mCandidateBatchDepth = 0 And Len(personID) > 0 And _
       Len(NormalizeRelationshipKey(relationshipText)) > 0 Then
        If FindConflictingPersonIDForRelationshipChange( _
                personID, s, relationshipText, conflictingPersonName, _
                conflictingPersonID) Then _
            Err.Raise vbObjectError + 2138, "AddPersonCandidateWithID", _
                      "続柄補完後に同じ氏名・続柄へ異なる人物IDが生じます。" & _
                      "人物候補を修正してから再実行してください: " & _
                      conflictingPersonName & "（補完対象=" & personID & _
                      " / 既存=" & conflictingPersonID & "）"
    End If
    If Len(s) > 100 Then Err.Raise vbObjectError + 2101, "AddPersonCandidateWithID", "氏名候補は100文字以内にしてください。"
    If Len(CellText(personID)) > 100 Then Err.Raise vbObjectError + 2102, "AddPersonCandidateWithID", "人物IDは100文字以内にしてください。"
    If Len(CellText(relationshipText)) > 50 Then Err.Raise vbObjectError + 2103, "AddPersonCandidateWithID", "続柄候補は50文字以内にしてください。"
    If Not SheetExists(SH_PERSON_CAND) Then BuildCandidateSheets False
    Set ws = GetSheet(SH_PERSON_CAND)
    lastR = LastRow(ws, 1)
    requestedIdentityKey = PersonIdentityKey(s, relationshipText)
    If mCandidateBatchDepth > 0 And Not mCandidateBatchRows Is Nothing Then
        batchKey = CandidateBatchKey(SH_PERSON_CAND, s, personID, relationshipText)
        r = FindCandidateBatchPersonRow(ws, s, personID, relationshipText, conflictingPersonID)
        If Len(conflictingPersonID) > 0 Then
            Err.Raise vbObjectError + 2136, "AddPersonCandidateWithID", _
                      "同じ氏名・続柄に異なる人物IDがあります。" & _
                      "取込を中止し、人物候補を元に戻します: " & s & _
                      "（" & relationshipText & " / 既存=" & conflictingPersonID & _
                      " / 取込=" & personID & "）"
        End If
        If r >= 2 Then
            previousName = CellText(ws.Cells(r, 1).Value)
            previousID = CellText(ws.Cells(r, 2).Value)
            previousRelationship = CellText(ws.Cells(r, 3).Value)
            UpdateExistingPersonCandidate ws, r, s, personID, relationshipText, sourceText
            If NormalizePersonNameKey(previousName) <> _
               NormalizePersonNameKey(CellText(ws.Cells(r, 1).Value)) Or _
               StrComp(previousID, CellText(ws.Cells(r, 2).Value), vbTextCompare) <> 0 Or _
               NormalizeRelationshipKey(previousRelationship) <> _
               NormalizeRelationshipKey(CellText(ws.Cells(r, 3).Value)) Then
                UnindexCandidateBatchPersonRow r, previousName, previousID, previousRelationship
                refreshBatchPersonIndex = True
            End If
            GoTo Updated
        End If
        GoTo AppendNewPersonCandidate
    End If
    For r = 2 To lastR
        storedID = CellText(ws.Cells(r, 2).Value)
        If Len(personID) > 0 And Len(NormalizeRelationshipKey(relationshipText)) > 0 And _
           StrComp(storedID, personID, vbTextCompare) = 0 And _
           Len(NormalizeRelationshipKey(CellText(ws.Cells(r, 3).Value))) = 0 Then
            '別名義で同じ人物IDの続柄が確定したら、既存の未確定候補も同時に収束させる。
            ws.Cells(r, 3).Value = relationshipText
        End If
        If NormalizePersonNameKey(CellText(ws.Cells(r, 1).Value)) = NormalizePersonNameKey(s) Then
            storedRelationship = CellText(ws.Cells(r, 3).Value)
            storedIdentityKey = PersonIdentityKey(CellText(ws.Cells(r, 1).Value), storedRelationship)
            If Len(personID) > 0 And StrComp(storedID, personID, vbTextCompare) = 0 Then
                UpdateExistingPersonCandidate ws, r, s, personID, relationshipText, sourceText
                GoTo Updated
            ElseIf Len(storedID) = 0 And storedIdentityKey = requestedIdentityKey Then
                UpdateExistingPersonCandidate ws, r, s, personID, relationshipText, sourceText
                GoTo Updated
            ElseIf Len(personID) = 0 And storedIdentityKey = requestedIdentityKey Then
                UpdateExistingPersonCandidate ws, r, s, personID, relationshipText, sourceText
                GoTo Updated
            ElseIf Len(personID) > 0 And Len(storedID) > 0 And storedIdentityKey = requestedIdentityKey Then
                Err.Raise vbObjectError + 2136, "AddPersonCandidateWithID", _
                          "同じ氏名・続柄に異なる人物IDがあります。" & _
                          "人物候補を上書きしません: " & s & _
                          "（" & relationshipText & " / 既存=" & storedID & _
                          " / 指定=" & personID & "）"
            End If
        End If
    Next r
AppendNewPersonCandidate:
    r = lastR + 1
    If r < 2 Then r = 2
    If r - 1 > MAX_CANDIDATE_DATA_ROWS Then _
        Err.Raise vbObjectError + 2106, "AddPersonCandidateWithID", _
                  "人物候補が実用上限（" & Format$(MAX_CANDIDATE_DATA_ROWS, "#,##0") & "件）に達しています。"
    If r > ws.Rows.Count Then _
        Err.Raise vbObjectError + 2109, "AddPersonCandidateWithID", _
                  "人物候補がExcelの行上限に達しています。共通データを分割してください。"
    ws.Cells(r, 1).Value = s
    ws.Cells(r, 2).Value = personID
    ws.Cells(r, 3).Value = relationshipText
    ws.Cells(r, 4).Value = sourceText
    refreshBatchPersonIndex = True
Updated:
    If mCandidateBatchDepth > 0 And Not mCandidateBatchRows Is Nothing Then
        If refreshBatchPersonIndex Then
            IndexCandidateBatchPersonRow r, CellText(ws.Cells(r, 1).Value), _
                                         CellText(ws.Cells(r, 2).Value), _
                                         CellText(ws.Cells(r, 3).Value), _
                                         SH_PERSON_CAND & " " & CStr(r) & "行"
        End If
        indexedPersonID = CellText(ws.Cells(r, 2).Value)
        indexedRelationship = CellText(ws.Cells(r, 3).Value)
        If Len(indexedPersonID) > 0 And _
           Len(NormalizeRelationshipKey(indexedRelationship)) > 0 Then
            mCandidateBatchRelationshipByID(indexedPersonID) = indexedRelationship
        End If
        mCandidateBatchRows(CandidateBatchKey(SH_PERSON_CAND, s, personID, relationshipText)) = r
    End If
    If Len(personID) > 0 Then InvalidateInternalIdCaches
    If mCandidateBatchDepth = 0 Then RefreshSingleCandidateName SH_PERSON_CAND, NM_LST_PERSON_CAND
End Sub

Private Sub UpdateExistingPersonCandidate(ByVal ws As Worksheet, ByVal rowNo As Long, ByVal personName As String, _
                                          ByVal personID As String, ByVal relationshipText As String, _
                                          ByVal sourceText As String)
    If ws Is Nothing Or rowNo < 2 Then Exit Sub
    If Len(personID) > 0 Then
        If Len(CellText(ws.Cells(rowNo, 2).Value)) = 0 Then
            ws.Cells(rowNo, 2).Value = personID
            InvalidateInternalIdCaches
        ElseIf StrComp(CellText(ws.Cells(rowNo, 2).Value), personID, vbTextCompare) <> 0 Then
            Err.Raise vbObjectError + 2137, "UpdateExistingPersonCandidate", _
                      "同じ氏名・続柄に異なる人物IDがあります。" & _
                      "人物候補を更新しません: " & personName & _
                      "（既存=" & CellText(ws.Cells(rowNo, 2).Value) & _
                      " / 指定=" & personID & "）"
        End If
    End If
    If Len(relationshipText) > 0 Then
        If Len(CellText(ws.Cells(rowNo, 3).Value)) > 0 And _
           NormalizeRelationshipKey(CellText(ws.Cells(rowNo, 3).Value)) <> NormalizeRelationshipKey(relationshipText) Then
            Err.Raise vbObjectError + 2107, "UpdateExistingPersonCandidate", _
                      "同じ人物IDの続柄が既存候補と異なります。既存口座の訂正モードで確認してください: " & personName
        End If
        ws.Cells(rowNo, 3).Value = relationshipText
    End If
    If sourceText = CAND_SOURCE_COMMON Then ws.Cells(rowNo, 4).Value = CAND_SOURCE_COMMON
    If mCandidateBatchDepth = 0 Then RefreshSingleCandidateName SH_PERSON_CAND, NM_LST_PERSON_CAND
End Sub

Private Sub AddCandidateValue(ByVal sheetName As String, ByVal listName As String, ByVal valueText As String, _
                              Optional ByVal sourceText As String = CAND_SOURCE_CASE)
    Dim ws As Worksheet
    Dim lastR As Long, r As Long
    Dim s As String, batchKey As String
    s = Trim$(valueText)
    If Len(s) = 0 Then Exit Sub
    sourceText = CellText(sourceText)
    If sourceText <> CAND_SOURCE_CASE And sourceText <> CAND_SOURCE_COMMON Then _
        Err.Raise vbObjectError + 2113, "AddCandidateValue", "候補区分が不正です: " & sourceText
    If sheetName = SH_TEKIYO Then
        If Len(s) > 500 Then Err.Raise vbObjectError + 2104, "AddCandidateValue", "摘要候補は500文字以内にしてください。"
    Else
        If Len(s) > 100 Then Err.Raise vbObjectError + 2105, "AddCandidateValue", "候補値は100文字以内にしてください。"
    End If
    If Not SheetExists(sheetName) Then BuildCandidateSheets False
    If Not SheetExists(sheetName) Then Exit Sub
    Set ws = GetSheet(sheetName)
    lastR = LastRow(ws, 1)
    If lastR < 2 Then lastR = 1
    If mCandidateBatchDepth > 0 And Not mCandidateBatchRows Is Nothing Then
        batchKey = CandidateBatchKey(sheetName, s)
        If mCandidateBatchRows.Exists(batchKey) Then
            r = CLng(mCandidateBatchRows(batchKey))
            If sourceText = CAND_SOURCE_COMMON Then ws.Cells(r, 4).Value = CAND_SOURCE_COMMON
            Exit Sub
        End If
        GoTo AppendNewCandidateValue
    End If
    For r = 2 To lastR
        If (sheetName = SH_PERSON_CAND And NormalizePersonNameKey(CellText(ws.Cells(r, 1).Value)) = NormalizePersonNameKey(s)) Or _
           (sheetName <> SH_PERSON_CAND And StrComp(CellText(ws.Cells(r, 1).Value), s, vbTextCompare) = 0) Then
            If sourceText = CAND_SOURCE_COMMON Then ws.Cells(r, 4).Value = CAND_SOURCE_COMMON
            If mCandidateBatchDepth = 0 Then RefreshSingleCandidateName sheetName, listName
            Exit Sub
        End If
    Next r
AppendNewCandidateValue:
    If lastR > MAX_CANDIDATE_DATA_ROWS Then _
        Err.Raise vbObjectError + 2110, "AddCandidateValue", _
                  "候補一覧が実用上限（" & Format$(MAX_CANDIDATE_DATA_ROWS, "#,##0") & "件）に達しています。"
    If lastR + 1 > ws.Rows.Count Then _
        Err.Raise vbObjectError + 2111, "AddCandidateValue", _
                  "候補一覧がExcelの行上限に達しています。共通データを分割してください。"
    ws.Cells(lastR + 1, 1).Value = s
    ws.Cells(lastR + 1, 4).Value = sourceText
    If mCandidateBatchDepth > 0 And Not mCandidateBatchRows Is Nothing Then mCandidateBatchRows(CandidateBatchKey(sheetName, s)) = lastR + 1
    If mCandidateBatchDepth = 0 Then RefreshSingleCandidateName sheetName, listName
End Sub

Private Sub RemoveCaseCandidateRows(ByVal sheetName As String, ByVal listName As String)
    Dim ws As Worksheet
    If Not SheetExists(sheetName) Then Exit Sub
    Set ws = GetSheet(sheetName)
    '候補シートは利用者が直接A列へ追記できる。区分を入力できない通常操作で
    '追加された行は、次案件でも使う手動共通候補として保護する。
    MigrateBlankCandidateSourcesToCommon ws
    CompactDeleteDataRows ws, 4, 4, CAND_SOURCE_CASE
    RefreshSingleCandidateName sheetName, listName
End Sub

Private Sub ValidateCandidateResetSourceSheet(ByVal sheetName As String)
    Dim ws As Worksheet, lastR As Long, r As Long
    Dim sourceData As Variant
    Dim candidateText As String, personID As String, relationshipText As String, sourceText As String
    Dim duplicateKey As String, identityKey As String, relationshipKey As String
    Dim seen As Object, identityIDs As Object, idRelationships As Object
    Dim formulaCell As Range
    If Not SheetExists(sheetName) Then _
        Err.Raise vbObjectError + 2114, "ValidateCaseCandidateResetSources", _
                  "候補シートがありません: " & sheetName
    Set ws = GetSheet(sheetName)
    lastR = LastDataRowInColumns(ws, 1, 4)
    If lastR < 2 Then Exit Sub
    If Not TryFindFirstFormulaCell(ws.Range(ws.Cells(2, 1), ws.Cells(lastR, 4)), formulaCell) Then _
        Err.Raise vbObjectError + 2125, "ValidateCaseCandidateResetSources", _
                  sheetName & "の数式有無を確認できません。初期化を中止しました。"
    If Not formulaCell Is Nothing Then _
        Err.Raise vbObjectError + 2125, "ValidateCaseCandidateResetSources", _
                  sheetName & " " & formulaCell.Address(False, False) & _
                  "に数式があります。初期化前に値へ置き換えてください。"
    sourceData = ws.Range(ws.Cells(2, 1), ws.Cells(lastR, 4)).Value2
    Set seen = CreateObject("Scripting.Dictionary")
    Set identityIDs = CreateObject("Scripting.Dictionary")
    Set idRelationships = CreateObject("Scripting.Dictionary")
    seen.CompareMode = vbTextCompare
    identityIDs.CompareMode = vbTextCompare
    idRelationships.CompareMode = vbTextCompare
    For r = 1 To UBound(sourceData, 1)
        If IsError(sourceData(r, 1)) Or IsError(sourceData(r, 2)) Or _
           IsError(sourceData(r, 3)) Or IsError(sourceData(r, 4)) Then
            Err.Raise vbObjectError + 2115, "ValidateCaseCandidateResetSources", _
                      sheetName & " " & CStr(r + 1) & "行にExcelエラー値があります。該当する候補を修正してください。"
        End If
        candidateText = CellText(sourceData(r, 1))
        personID = CellText(sourceData(r, 2))
        relationshipText = CellText(sourceData(r, 3))
        sourceText = CellText(sourceData(r, 4))
        If Len(candidateText) = 0 Then
            Err.Raise vbObjectError + 2116, "ValidateCaseCandidateResetSources", _
                      sheetName & " " & CStr(r + 1) & "行は候補値が空欄です。空行を詰めてください。"
        ElseIf Len(sourceText) > 0 And sourceText <> CAND_SOURCE_CASE And sourceText <> CAND_SOURCE_COMMON Then
            Err.Raise vbObjectError + 2117, "ValidateCaseCandidateResetSources", _
                      sheetName & " " & CStr(r + 1) & "行の区分が不正です: " & sourceText
        End If
        '案件候補は初期化で削除される。共通候補と、共通へ移行する手動追記行だけを
        '初期化後の状態として重複・長さ・人物ID整合まで事前検証する。
        If sourceText <> CAND_SOURCE_CASE Then
            If Len(candidateText) > 100 Then _
                Err.Raise vbObjectError + 2119, "ValidateCaseCandidateResetSources", _
                          sheetName & " " & CStr(r + 1) & "行の候補値が100文字を超えています。"
            If sheetName = SH_PERSON_CAND Then
                If Len(personID) > 100 Then _
                    Err.Raise vbObjectError + 2120, "ValidateCaseCandidateResetSources", _
                              sheetName & " " & CStr(r + 1) & "行の人物IDが100文字を超えています。"
                If Len(personID) > 0 And Not IsInternalIdValue(personID, "P") Then _
                    Err.Raise vbObjectError + 2126, "ValidateCaseCandidateResetSources", _
                              sheetName & " " & CStr(r + 1) & "行の人物ID形式が不正です: " & personID
                If Len(relationshipText) > 50 Then _
                    Err.Raise vbObjectError + 2121, "ValidateCaseCandidateResetSources", _
                              sheetName & " " & CStr(r + 1) & "行の続柄が50文字を超えています。"
                identityKey = PersonIdentityKey(candidateText, relationshipText)
                duplicateKey = identityKey & Chr$(29) & UCase$(personID)
                If Len(personID) > 0 Then
                    If identityIDs.Exists(identityKey) Then
                        If StrComp(CStr(identityIDs(identityKey)), personID, vbTextCompare) <> 0 Then _
                            Err.Raise vbObjectError + 2123, "ValidateCaseCandidateResetSources", _
                                      sheetName & " " & CStr(r + 1) & "行は同じ氏名・続柄に異なる人物IDがあります。"
                    Else
                        identityIDs.Add identityKey, personID
                    End If
                    relationshipKey = NormalizeRelationshipKey(relationshipText)
                    If Len(relationshipKey) > 0 Then
                        If idRelationships.Exists(personID) Then
                            If StrComp(CStr(idRelationships(personID)), relationshipKey, vbTextCompare) <> 0 Then _
                                Err.Raise vbObjectError + 2124, "ValidateCaseCandidateResetSources", _
                                          sheetName & " " & CStr(r + 1) & "行は同一人物IDの続柄が一致しません。"
                        Else
                            idRelationships.Add personID, relationshipKey
                        End If
                    End If
                End If
            Else
                duplicateKey = UCase$(Trim$(candidateText))
            End If
            If seen.Exists(duplicateKey) Then _
                Err.Raise vbObjectError + 2122, "ValidateCaseCandidateResetSources", _
                          sheetName & " " & CStr(r + 1) & "行に初期化後も残る重複候補があります。"
            seen.Add duplicateKey, True
        End If
    Next r
End Sub

Private Sub MigrateBlankCandidateSourcesToCommon(ByVal ws As Worksheet)
    Dim lastR As Long, r As Long
    Dim sourceData As Variant, changed As Boolean
    If ws Is Nothing Then Exit Sub
    lastR = LastDataRowInColumns(ws, 1, 4)
    If lastR < 2 Then Exit Sub
    sourceData = ws.Range(ws.Cells(2, 1), ws.Cells(lastR, 4)).Value2
    For r = 1 To UBound(sourceData, 1)
        If Len(CellText(sourceData(r, 1))) > 0 And Len(CellText(sourceData(r, 4))) = 0 Then
            sourceData(r, 4) = CAND_SOURCE_COMMON
            changed = True
        End If
    Next r
    If changed Then ws.Range(ws.Cells(2, 1), ws.Cells(lastR, 4)).Value2 = sourceData
End Sub

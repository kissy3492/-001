﻿Attribute VB_Name = "modConstants"
Option Explicit

Public Const TOOL_PASSWORD As String = "cashop"

Public Const SH_CONFIG As String = "設定"
Public Const SH_INPUT As String = "入力"
Public Const SH_TEKIYO As String = "摘要候補"
Public Const SH_ACCOUNT_TYPE As String = "科目候補"
Public Const SH_INPUT_MODE As String = "入力モード"
Public Const SH_YEAR_MODE As String = "年入力方式候補"
Public Const SH_DISPLAY_OPTION As String = "表示切替候補"
Public Const SH_POST_KEEP As String = "転記後保持候補"
Public Const SH_POST_CLEAR As String = "転記後処理候補"
Public Const SH_BANK_CAND As String = "銀行名候補"
Public Const SH_BRANCH_CAND As String = "支店名候補"
Public Const SH_PERSON_CAND As String = "人物候補"
Public Const SH_WORK_TX As String = "W_取引"
Public Const SH_WORK_BAL As String = "W_残高"
Public Const SH_WORK_ACCOUNT As String = "W_口座"
Public Const SH_WORK_STATE As String = "W_状態"
Public Const SH_CHECK As String = "C_チェック"
Public Const SH_REGISTERED_ACCOUNTS As String = "登録済み口座"
Public Const SH_OUTPUT_TX As String = "資金操作表"
Public Const SH_WORK_CASH As String = "W_資金操作表"
Public Const SH_OUTPUT_BAL As String = "残高推移表"
Public Const SH_SHOP_TARGET As String = "取扱店変換対象"
Public Const SH_OUTPUT_TX_CONVERTED As String = "資金操作表_取扱店変換済"
Public Const SH_ANALYSIS_SHIFT As String = "資金シフト候補"
Public Const SH_ANALYSIS_FLOW As String = "資金フロー追跡"
Public Const SH_ANALYSIS_UNKNOWN As String = "不明入出金"
Public Const SH_ANALYSIS_RESULT As String = "分析結果"
Public Const SH_ANALYSIS_DETAIL As String = "候補詳細"
Public Const SH_WORK_ANALYSIS_GROUP As String = "W_分析グループ"
Public Const SH_WORK_ANALYSIS_REVIEW As String = "W_分析判断台帳"
Public Const SH_WORK_ANALYSIS_HISTORY As String = "W_分析判断履歴"
Public Const SH_WORK_MANUAL_FLOW As String = "W_手動資金候補"
Public Const SH_ANALYSIS_STATUS As String = "分析確認候補"
Public Const SH_BALANCE_RECONCILIATION As String = "残高検算"
Public Const SH_SETUP_LOG As String = "W_セットアップログ"

Public Const NM_LST_TEKIYO As String = "lstTekiyo"
Public Const NM_LST_ACCOUNT_TYPE As String = "lstAccountType"
Public Const NM_LST_INPUT_MODE As String = "lstInputMode"
Public Const NM_LST_YEAR_MODE As String = "lstYearInputMode"
Public Const NM_LST_DISPLAY_OPTION As String = "lstDisplayOption"
Public Const NM_LST_POST_KEEP As String = "lstPostTransferKeep"
Public Const NM_LST_POST_CLEAR As String = "lstPostTransferClear"
Public Const NM_LST_BANK_CAND As String = "lstBankCandidates"
Public Const NM_LST_BRANCH_CAND As String = "lstBranchCandidates"
Public Const NM_LST_PERSON_CAND As String = "lstPersonCandidates"
Public Const NM_LST_ANALYSIS_STATUS As String = "lstAnalysisReviewStatus"
Public Const NM_LST_ANALYSIS_SHIFT_STATUS As String = "lstAnalysisShiftReviewStatus"
Public Const NM_LST_ANALYSIS_SOURCE_STATUS As String = "lstAnalysisSourceReviewStatus"
Public Const NM_LST_ANALYSIS_USE_STATUS As String = "lstAnalysisUseReviewStatus"

Public Const ROW_CFG_INHERITANCE_DATE As Long = 4
Public Const ROW_CFG_BAL_START_YEAR As Long = 5
Public Const ROW_CFG_BAL_END_YEAR As Long = 6
Public Const ROW_CFG_YEAR_ADD As Long = 7
Public Const ROW_CFG_INPUT_MODE As Long = 8
Public Const ROW_CFG_POST_KEEP As Long = 9
Public Const ROW_CFG_POST_TX As Long = 10
Public Const ROW_CFG_POST_BAL As Long = 11
Public Const ROW_CFG_YEAR_MODE As Long = 12
Public Const ROW_CFG_RELATIONSHIP As Long = 13
Public Const ROW_CFG_SHOW_INHERITANCE_ROW As Long = 14
Public Const ROW_CFG_SHOW_OPEN_DATE_ROW As Long = 15
Public Const ROW_CFG_SHOW_CLOSE_DATE_ROW As Long = 16
Public Const ROW_CFG_SHOW_BALANCE_ROWS As Long = 17
Public Const COL_CFG_VALUE As Long = 3

'分析設定は既存の案件・表示設定と同じ行の右側へ独立配置する。
'相続開始日や残高年を初期化しても、分析条件は利用者設定として保持する。
Public Const ROW_CFG_ANALYSIS_MIN_AMOUNT As Long = 4
Public Const ROW_CFG_ANALYSIS_DAY_WINDOW As Long = 5
Public Const ROW_CFG_ANALYSIS_ABS_TOLERANCE As Long = 6
Public Const ROW_CFG_ANALYSIS_RATE_TOLERANCE As Long = 7
Public Const ROW_CFG_ANALYSIS_UNKNOWN_MIN As Long = 8
Public Const COL_CFG_ANALYSIS_LABEL As Long = 6   'F
Public Const COL_CFG_ANALYSIS_VALUE As Long = 7   'G
Public Const COL_CFG_ANALYSIS_NOTE As Long = 8    'H

Public Const ANALYSIS_STATUS_UNREVIEWED As String = "未確認"
Public Const ANALYSIS_STATUS_SHIFT_CONFIRMED As String = "資金移動確認"
Public Const ANALYSIS_STATUS_SOURCE_CONFIRMED As String = "原資確認済"
Public Const ANALYSIS_STATUS_USE_CONFIRMED As String = "使途確認済"
Public Const ANALYSIS_STATUS_EXCLUDED As String = "対象外"
Public Const ANALYSIS_STATUS_FOLLOWUP As String = "要追加調査"

Public Const SHIFT_ANALYSIS_LAST_COL As Long = 34
Public Const SHIFT_ANALYSIS_STATUS_COL As Long = 30
Public Const SHIFT_ANALYSIS_MEMO_COL As Long = 31
Public Const SHIFT_ANALYSIS_KEY_COL As Long = 32
Public Const FLOW_ANALYSIS_LAST_COL As Long = 22
Public Const FLOW_ANALYSIS_STATUS_COL As Long = 17
Public Const FLOW_ANALYSIS_MEMO_COL As Long = 18
Public Const FLOW_ANALYSIS_KEY_COL As Long = 19
Public Const UNKNOWN_ANALYSIS_LAST_COL As Long = 26
Public Const UNKNOWN_ANALYSIS_STATUS_COL As Long = 21
Public Const UNKNOWN_ANALYSIS_MEMO_COL As Long = 22
Public Const UNKNOWN_ANALYSIS_KEY_COL As Long = 26
Public Const ANALYSIS_RESULT_LAST_COL As Long = 15
Public Const ANALYSIS_RESULT_VISIBLE_COL As Long = 9
Public Const ANALYSIS_RESULT_STATUS_COL As Long = 8
Public Const ANALYSIS_RESULT_MEMO_COL As Long = 9
Public Const ANALYSIS_RESULT_SOURCE_SHEET_COL As Long = 10
Public Const ANALYSIS_RESULT_SOURCE_KEY_COL As Long = 11
Public Const ANALYSIS_RESULT_GROUP_ID_COL As Long = 12
Public Const ANALYSIS_RESULT_SOURCE_ROW_COL As Long = 13
Public Const ANALYSIS_RESULT_TX_IDS_COL As Long = 14
Public Const ANALYSIS_RESULT_ALTERNATIVE_COUNT_COL As Long = 15
Public Const ANALYSIS_GROUP_LAST_COL As Long = 10
Public Const MAX_ANALYSIS_OUTPUT_ROWS As Long = 200000
'金額幅だけで候補が広がった場合でも、VBAの二重ループを現実的な時間で止める。
'候補件数上限とは別物で、同一口座・日付範囲外として除外される組合せも数える。
Public Const MAX_SHIFT_PAIR_COMPARISONS As Double = 5000000#
Public Const ANALYSIS_REVIEW_MEMO_MAX As Long = 1000
Public Const ANALYSIS_EVIDENCE_MARKER As String = "|EV|"

'判断台帳は現行候補から消えた判断も保持し、履歴は変更時だけ追記する。
Public Const ANALYSIS_REVIEW_STORE_LAST_COL As Long = 13
Public Const ANALYSIS_HISTORY_STORE_LAST_COL As Long = 13
Public Const MANUAL_FLOW_STORE_LAST_COL As Long = 11
Public Const BALANCE_RECONCILIATION_LAST_COL As Long = 9

Public Const REVIEW_STORE_COL_KEY As Long = 1
Public Const REVIEW_STORE_COL_SOURCE As Long = 2
Public Const REVIEW_STORE_COL_CATEGORY As Long = 3
Public Const REVIEW_STORE_COL_STATUS As Long = 4
Public Const REVIEW_STORE_COL_MEMO As Long = 5
Public Const REVIEW_STORE_COL_EVIDENCE As Long = 6
Public Const REVIEW_STORE_COL_TX_IDS As Long = 7
Public Const REVIEW_STORE_COL_UPDATED_AT As Long = 8
Public Const REVIEW_STORE_COL_PRESENCE As Long = 9
Public Const REVIEW_STORE_COL_PREVIOUS_STATUS As Long = 10
Public Const REVIEW_STORE_COL_PREVIOUS_EVIDENCE As Long = 11
Public Const REVIEW_STORE_COL_REASON As Long = 12
Public Const REVIEW_STORE_COL_USER As Long = 13

Public Const MANUAL_FLOW_COL_ID As Long = 1
Public Const MANUAL_FLOW_COL_TX_IDS As Long = 2
Public Const MANUAL_FLOW_COL_AMOUNT As Long = 3
Public Const MANUAL_FLOW_COL_STATUS As Long = 4
Public Const MANUAL_FLOW_COL_MEMO As Long = 5
Public Const MANUAL_FLOW_COL_ACTIVE As Long = 6
Public Const MANUAL_FLOW_COL_CREATED_AT As Long = 7
Public Const MANUAL_FLOW_COL_CREATED_BY As Long = 8
Public Const MANUAL_FLOW_COL_UPDATED_AT As Long = 9
Public Const MANUAL_FLOW_COL_EVIDENCE As Long = 10
Public Const MANUAL_FLOW_COL_KEY As Long = 11

'元号マスタ（設定シート内）。口座開設日・口座解約日の「1.53.5.6」形式で使用する。
'新元号が発生した場合は、設定シートの元号マスタに行を追加すればよい。
Public Const ERA_MASTER_TITLE_ROW As Long = 43
Public Const ERA_MASTER_HEADER_ROW As Long = 44
Public Const ERA_MASTER_FIRST_ROW As Long = 45
Public Const ERA_MASTER_MAX_ROW As Long = 54
Public Const ERA_COL_CODE As Long = 2      'B
Public Const ERA_COL_NAME As Long = 3      'C
Public Const ERA_COL_ABBR As Long = 4      'D
Public Const ERA_COL_START As Long = 5     'E
Public Const ERA_COL_END As Long = 6       'F
Public Const ERA_COL_ENABLED As Long = 7   'G

Public Const CELL_BANK As String = "C5"
Public Const CELL_BRANCH As String = "F5"
Public Const CELL_PERSON As String = "I5"
Public Const CELL_RELATIONSHIP As String = "I6"
Public Const CELL_ACCOUNT_TYPE As String = "C6"
Public Const CELL_ACCOUNT_NO As String = "F6"
Public Const CELL_OPEN_DATE As String = "C7"
Public Const CELL_CLOSE_DATE As String = "G7"
Public Const CELL_STATUS As String = "B13"

Public Const INPUT_BALANCE_HEADER_ROW As Long = 9
'操作パネルは画面右側に常設せず、入力表と同じB:Kの上部へ収める。
'L:Vは「詳細・残高」を開いた間だけ表示する。
Public Const INPUT_PANEL_FIRST_COL As Long = 2   'B
Public Const INPUT_PANEL_LAST_COL As Long = 11  'K
Public Const INPUT_PANEL_FIRST_ROW As Long = 2
Public Const INPUT_PANEL_LAST_ROW As Long = 3
Public Const INPUT_SCREEN_LAST_COL As Long = 11 'K。通常作業時の表示右端。
Public Const INPUT_BALANCE_MEMO_VISIBLE_COLS As Long = 4
Public Const INPUT_WIDTH_B As Double = 9
Public Const INPUT_WIDTH_C As Double = 9
Public Const INPUT_WIDTH_D As Double = 9
Public Const INPUT_WIDTH_E As Double = 9.5
Public Const INPUT_WIDTH_F_TO_G As Double = 11.5
Public Const INPUT_WIDTH_H As Double = 12
Public Const INPUT_WIDTH_I As Double = 8.5
Public Const INPUT_WIDTH_J As Double = 16
Public Const INPUT_WIDTH_K As Double = 12
Public Const INPUT_WIDTH_L_TO_P As Double = 8
Public Const INPUT_WIDTH_Q_TO_V As Double = 12.5
Public Const INPUT_BALANCE_MIN_WIDTH_POINTS As Double = 50
Public Const INPUT_MEMO_MIN_WIDTH_POINTS As Double = 120
'初回セットアップだけ90%を適用し、以後は利用者の倍率を保持する。
Public Const INPUT_DEFAULT_ZOOM As Long = 90
'旧版から参照する外部マクロとの互換用。自動縮小の下限としては使用しない。
Public Const INPUT_MIN_ZOOM As Long = 80
Public Const INPUT_WINDOW_HORIZONTAL_RESERVE_POINTS As Double = 58
'図形座標は表示倍率・既定フォント・DPIによって小数点以下が丸められる。
'6pt以内はExcel描画エンジン・既定フォント差として許容し、それを超える実移動だけを検出する。
Public Const TOOL_SHAPE_BOUNDS_TOLERANCE_POINTS As Double = 6
Public Const INPUT_STATUS_ROW As Long = 13
Public Const BAL_LABEL_ROW As Long = 10
Public Const BAL_VALUE_ROW As Long = 11
Public Const BAL_DATE_ROW As Long = 12
Public Const BAL_FIRST_COL As Long = 2       'B
Public Const BAL_MAX_COL As Long = 22         'V
Public Const BAL_MAX_LABELS As Long = 20      '通常10時点、最大20時点。最後尾V列を「その他」に使う。

Public Const TX_HEADER_ROW As Long = 15
Public Const TX_FIRST_ROW As Long = 16
'日常利用で5,000件を超える長期・高頻度口座も訂正できるよう、通常明細を
'10,000件まで扱う。上限超過時は一部だけ表示せず、明確に停止する。
Public Const TX_LAST_ROW As Long = 10015

'各モジュールに別々の数値を持たせず、上限変更時の不整合を防ぐ。
Public Const MAX_INTERNAL_STORE_DATA_ROWS As Long = 200000

Public Const COL_TX_YEAR As Long = 2       'B
Public Const COL_TX_MONTH As Long = 3      'C
Public Const COL_TX_DAY As Long = 4        'D
Public Const COL_TX_TIME As Long = 5       'E
Public Const COL_TX_WITHDRAW As Long = 6   'F
Public Const COL_TX_DEPOSIT As Long = 7    'G
Public Const COL_TX_SHOP As Long = 8       'H
Public Const COL_TX_MACHINE As Long = 9    'I
Public Const COL_TX_TEKIYO As Long = 10    'J
Public Const COL_TX_OTHER As Long = 11     'K
Public Const COL_TX_BALANCE As Long = 11   'K。旧名称COL_TX_OTHERとの互換を維持する。

Public Const MODE_NORMAL As String = "通常"
Public Const MODE_NO_TIME As String = "時刻なし"
Public Const MODE_NO_MACHINE As String = "機番なし"
Public Const MODE_NO_TEKIYO As String = "摘要なし"
Public Const MODE_WITH_OTHER As String = "取引後残高あり"
Public Const MODE_SIMPLE As String = "簡易"

Public Const KEEP_NONE As String = "残さない"
Public Const KEEP_PERSON_ONLY As String = "氏名のみ残す"
Public Const KEEP_BANK_BRANCH As String = "銀行名・支店名のみ残す"
Public Const KEEP_BANK_BRANCH_PERSON_TYPE As String = "銀行名・支店名・氏名・科目を残す"
Public Const KEEP_ALL_ACCOUNT As String = "口座情報をすべて残す"

Public Const POST_CLEAR As String = "クリアする"
Public Const POST_KEEP As String = "残す"

Public Const YEAR_MODE_WAREKI As String = "和暦"
Public Const YEAR_MODE_WESTERN2 As String = "西暦2桁"

Public Const DISPLAY_ON As String = "表示する"
Public Const DISPLAY_OFF As String = "表示しない"

Public Const UI_PREFIX As String = "cashop_ui_"

Public Const OUT_COL_BANK As Long = 1
Public Const OUT_COL_BRANCH As Long = 2
Public Const OUT_COL_PERSON As Long = 3
Public Const OUT_COL_ACCOUNT_TYPE As Long = 4
Public Const OUT_COL_ACCOUNT_NO As Long = 5
Public Const OUT_COL_DATE As Long = 6
Public Const OUT_COL_TIME As Long = 7
Public Const OUT_COL_WITHDRAW As Long = 8
Public Const OUT_COL_DEPOSIT As Long = 9
Public Const OUT_COL_SHOP As Long = 10
Public Const OUT_COL_MACHINE As Long = 11
Public Const OUT_COL_TEKIYO As Long = 12
Public Const OUT_COL_OTHER As Long = 13

Public Const WORK_TX_COL_RELATIONSHIP As Long = 14
Public Const WORK_BAL_COL_RELATIONSHIP As Long = 12

'作業データの非表示連携列。利用者には表示しない。
Public Const WORK_TX_COL_ACCOUNT_ID As Long = 15
Public Const WORK_TX_COL_TRANSFER_ID As Long = 16
Public Const WORK_TX_COL_TRANSACTION_ID As Long = 17
Public Const WORK_TX_COL_RECORD_TYPE As Long = 18
Public Const WORK_TX_COL_INPUT_ORDER As Long = 19
Public Const WORK_TX_COL_SOURCE As Long = 20
Public Const WORK_TX_COL_PERSON_ID As Long = 21

Public Const WORK_BAL_COL_ACCOUNT_ID As Long = 13
Public Const WORK_BAL_COL_TRANSFER_ID As Long = 14
Public Const WORK_BAL_COL_BALANCE_ID As Long = 15
Public Const WORK_BAL_COL_SOURCE As Long = 16
Public Const WORK_BAL_COL_PERSON_ID As Long = 17

'内部出力列。最終提出用xlsxでは削除し、13列だけを出力する。
Public Const OUT_COL_ACCOUNT_ID As Long = 14
Public Const OUT_COL_TRANSACTION_ID As Long = 15
Public Const OUT_COL_RECORD_TYPE As Long = 16
Public Const OUT_COL_INPUT_ORDER As Long = 17
Public Const OUT_INTERNAL_LAST_COL As Long = 17

'資金操作表の上部に分析パネルを統合する。元帳票はW_資金操作表の1行目から保持し、
'利用者向け画面では10行目を見出し、11行目以降を取引一覧に固定する。
Public Const CASH_VIEW_HEADER_ROW As Long = 10
Public Const CASH_VIEW_FIRST_DATA_ROW As Long = 11
Public Const CASH_VIEW_COL_DISPLAY As Long = 18   'R: 表示対象
Public Const CASH_VIEW_COL_ROLE As Long = 19      'S: 候補内の出金/入金
Public Const CASH_VIEW_COL_SELECTED As Long = 20  'T: 手動候補選択
Public Const CASH_VIEW_LAST_COL As Long = 20
Public Const CASH_VIEW_INTERNAL_LAST_COL As Long = 26 'Z: 画面状態を含む最終列

'口座マスタ列。
Public Const ACC_COL_ID As Long = 1
Public Const ACC_COL_BANK As Long = 2
Public Const ACC_COL_BRANCH As Long = 3
Public Const ACC_COL_PERSON As Long = 4
Public Const ACC_COL_RELATIONSHIP As Long = 5
Public Const ACC_COL_TYPE As Long = 6
Public Const ACC_COL_NO As Long = 7
Public Const ACC_COL_OPEN_DATE As Long = 8
Public Const ACC_COL_CLOSE_DATE As Long = 9
Public Const ACC_COL_PERSON_ID As Long = 10
Public Const ACC_COL_SOURCE As Long = 11
Public Const ACC_COL_UPDATED_AT As Long = 12
Public Const ACC_COL_TRANSFER_ID As Long = 13

Public Const RECORD_TRANSACTION As String = "取引"
Public Const RECORD_OPEN As String = "口座開設"
Public Const RECORD_CLOSE As String = "口座解約"
Public Const RECORD_BALANCE As String = "残高"
Public Const RECORD_INHERITANCE As String = "相続開始"

Public Const SOURCE_MANUAL As String = "手入力"
Public Const SOURCE_EXTERNAL As String = "外部取込"
Public Const CAND_SOURCE_CASE As String = "案件"
Public Const CAND_SOURCE_COMMON As String = "共通"

Public Const STATE_NEXT_ACCOUNT As String = "次口座番号"
Public Const STATE_NEXT_TRANSFER As String = "次転記番号"
Public Const STATE_NEXT_TRANSACTION As String = "次取引番号"
Public Const STATE_NEXT_BALANCE As String = "次残高番号"
Public Const STATE_NEXT_PERSON As String = "次人物番号"
Public Const STATE_EDIT_ACCOUNT As String = "訂正中口座ID"
Public Const STATE_OUTPUT_DIRTY As String = "出力要更新"
Public Const STATE_ANALYSIS_REVIEW_DIRTY As String = "分析判断要保存"
Public Const STATE_LAST_BUILD As String = "最終帳票更新"
Public Const STATE_DATA_HEALTH As String = "案件データ状態"
Public Const STATE_INPUT_DATE_CONFIG_SAFE As String = "入力日付設定安全"
Public Const STATE_TRUE As String = "1"
Public Const STATE_FALSE As String = "0"
Public Const DATA_HEALTH_NORMAL As String = "正常"
Public Const DATA_HEALTH_INITIALIZING As String = "初期化中"
Public Const DATA_HEALTH_NEEDS_RECOVERY As String = "要復旧"
'保存・終了イベントでは、文字列の読取失敗を「要復旧」と同一視しない。
'状態不明の正常ブックを分析未同期のまま上書きしないための分類値。
Public Const TOOL_HEALTH_NOT_INITIALIZED As Long = 0
Public Const TOOL_HEALTH_NORMAL As Long = 1
Public Const TOOL_HEALTH_RECOVERY As Long = 2
Public Const TOOL_HEALTH_UNKNOWN As Long = 3

Public Const SHOP_TGT_COL_NO As Long = 1
Public Const SHOP_TGT_COL_BANK As Long = 2
Public Const SHOP_TGT_COL_CODE As Long = 3
Public Const SHOP_TGT_COL_COUNT As Long = 4
Public Const SHOP_TGT_COL_ROWS As Long = 5
Public Const SHOP_TGT_COL_RESULT As Long = 6
Public Const SHOP_TGT_COL_STATUS As Long = 7
Public Const SHOP_TGT_COL_CREATED As Long = 8
Public Const SHOP_TGT_LAST_COL As Long = 8
'実データ行数に応じて自動拡張する。空シートで1万行へ入力規則を張る無駄を避ける。
Public Const SHOP_EDIT_LAST_ROW As Long = 1000   '旧版互換用。現行は実データ行だけを編集可能にする。

'Excel/VBAのDoubleで整数精度を保てる実務上限。異常な指数値による集計オーバーフローも防ぐ。
Public Const MAX_ABS_AMOUNT As Double = 999999999999999#

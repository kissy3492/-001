﻿Attribute VB_Name = "modUtilities"
Option Explicit

Private Const MAX_DETAILED_AUTOFIT_ROWS As Long = 2000
Private Const MAX_READABILITY_SCAN_CELLS As Double = 250000#
Private Const MIN_NORMAL_TEXT_CONTRAST As Double = 4.5
'vbObjectError + 4499. Recovery-capable nested helperの例外を外側へ伝える。
Private Const UTILITIES_RECOVERY_HARD_BARRIER_ERROR As Long = vbObjectError + 4499

Public Function SheetExists(ByVal sheetName As String) As Boolean
    Dim ws As Worksheet
    On Error Resume Next
    Set ws = ThisWorkbook.Worksheets(sheetName)
    SheetExists = Not ws Is Nothing
    On Error GoTo 0
End Function

Public Function GetSheet(ByVal sheetName As String) As Worksheet
    Dim ws As Worksheet
    On Error Resume Next
    Set ws = ThisWorkbook.Worksheets(sheetName)
    On Error GoTo 0
    If ws Is Nothing Then
        Err.Raise vbObjectError + 1001, "GetSheet", _
                  "案件ファイルの構成が不足しているため、処理を続けられません。" & _
                  "［設定］の復旧案内を確認してください。診断情報: " & sheetName
    End If
    Set GetSheet = ws
End Function

Public Function GetOrCreateSheet(ByVal sheetName As String, Optional ByVal resetSheet As Boolean = False) As Worksheet
    Dim ws As Worksheet
    On Error GoTo EH
    If SheetExists(sheetName) Then
        Set ws = ThisWorkbook.Worksheets(sheetName)
    Else
        Set ws = ThisWorkbook.Worksheets.Add(After:=ThisWorkbook.Worksheets(ThisWorkbook.Worksheets.Count))
        ws.Name = sheetName
    End If
    If ws Is Nothing Then Err.Raise vbObjectError + 1002, "GetOrCreateSheet", "シート取得に失敗しました: " & sheetName
    '既存シートの表示状態は呼出側の意図として保持する。
    'ここで常にVisibleへ戻すと、W_状態などVeryHiddenの内部保管が通常操作だけで露出する。
    If resetSheet Then ResetWorksheet ws
    Set GetOrCreateSheet = ws
    Exit Function
EH:
    Err.Raise Err.Number, "GetOrCreateSheet(" & sheetName & ")", Err.Description
End Function

Public Sub ResetWorksheet(ByVal ws As Worksheet)
    Dim errorNumber As Long, errorDescription As String
    Dim i As Long
    If ws Is Nothing Then Exit Sub
    On Error GoTo EH
    ws.Unprotect Password:=TOOL_PASSWORD
    ws.ScrollArea = ""
    ws.EnableSelection = xlNoRestrictions
    For i = ws.ListObjects.Count To 1 Step -1
        ws.ListObjects(i).Delete
    Next i
    If ws.AutoFilterMode Then ws.AutoFilterMode = False
    DeleteToolShapes ws, True
    If ws.Shapes.Count > 0 Then
        Err.Raise vbObjectError + 1003, "ResetWorksheet", _
                  "図形を消去できませんでした: " & ws.Name
    End If
    ws.Cells.UnMerge
    'Clearは値・数式・書式・入力規則をまとめて消す。ClearFormatsの全シート二重走査は不要。
    ws.Cells.Clear
    '旧画面の非表示行列を残すと、新しいセルや図形が画面外へ消えたように見える。
    ws.Rows.Hidden = False
    ws.Columns.Hidden = False
    If LastUsedRowInSheet(ws) > 0 Then
        Err.Raise vbObjectError + 1004, "ResetWorksheet", _
                  "値または数式が残っています: " & ws.Name
    End If
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    Err.Raise errorNumber, "ResetWorksheet(" & ws.Name & ")", errorDescription
End Sub

Public Sub ProtectGeneratedOutputSheet(ByVal ws As Worksheet, _
                                       Optional ByVal raiseOnError As Boolean = False)
    '生成表は閲覧・コピー専用。手修正が次回生成で消える誤解と、変更イベントによる全消去を防ぐ。
    Dim workbookWasSaved As Boolean, emergencyProtected As Boolean
    Dim mutationStarted As Boolean, cleanupEventsStopped As Boolean
    Dim entryEvents As Boolean, entryEventsCaptured As Boolean
    Dim eventsRestored As Boolean, finalEventsStopped As Boolean
    Dim protectionConfirmed As Boolean, savedFlagRestored As Boolean
    Dim localConvergenceConfirmed As Boolean, recoveryConfirmed As Boolean
    Dim applicationStateSafe As Boolean, safeToRestoreEntry As Boolean
    Dim recoveryHardBarrierDetected As Boolean
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim emergencyDetail As String
    Dim recoveryErrorNumber As Long, recoveryErrorDescription As String
    Dim eventStateDetail As String, eventRestoreDetail As String
    Dim savedRestoreDetail As String, recoveryDetail As String
    Dim postEnforceEventDetail As String, convergenceDetail As String
    Dim verificationDetail As String, appStateProblems As String
    Dim sheetName As String
    If ws Is Nothing Then Exit Sub
    On Error GoTo EH
    sheetName = ws.Name
    workbookWasSaved = ThisWorkbook.Saved
    If Not TryGetFormattingEnableEvents(entryEvents, eventStateDetail) Then _
        Err.Raise vbObjectError + 1131, "ProtectGeneratedOutputSheet", _
                  "生成表保護前のイベント状態を一意に保存できません。 " & _
                  eventStateDetail
    entryEventsCaptured = True
    If Not TrySetFormattingEnableEventsExact(False, eventStateDetail) Then _
        Err.Raise vbObjectError + 1132, "ProtectGeneratedOutputSheet", _
                  "生成表保護中のイベント停止を一意に確認できません。 " & _
                  eventStateDetail
    mutationStarted = True
    ws.Unprotect Password:=TOOL_PASSWORD
    If LastUsedRowInSheet(ws) > 0 Then ws.UsedRange.Locked = True
    LockToolShapes ws, False
    ApplyGeneratedOutputProtection ws
    ws.EnableSelection = xlNoRestrictions
    If Not ws.ProtectContents Or Not ws.ProtectDrawingObjects Then _
        Err.Raise vbObjectError + 1130, "ProtectGeneratedOutputSheet", _
                  "生成表のセル・図形保護を読み戻せません。"
    If ws.EnableSelection <> xlNoRestrictions Then _
        Err.Raise vbObjectError + 1130, "ProtectGeneratedOutputSheet", _
                  "生成表の閲覧・コピー用の選択状態を確認できません。"
    VerifyToolShapeSecurity ws, True, False
    If workbookWasSaved Then
        savedRestoreDetail = vbNullString
        If Not TryRestoreGeneratedOutputSavedFlag(savedRestoreDetail) Then _
            Err.Raise vbObjectError + 1133, "ProtectGeneratedOutputSheet", _
                      savedRestoreDetail
    End If
    If Not TryRestoreFormattingEntryEvents( _
               entryEventsCaptured, entryEvents, eventRestoreDetail) Then _
        Err.Raise vbObjectError + 1134, "ProtectGeneratedOutputSheet", _
                  "生成表保護前のイベント状態を復元できません。 " & _
                  eventRestoreDetail
    entryEventsCaptured = False
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    '最終防御は必ず読戻しまで実行する。それが成功しても元の失敗は
    '呼出元へ返し、部分失敗を正常終了として扱わない。raiseOnErrorは呼出互換のため残す。
    If UtilitiesNestedRecoveryHardBarrierError( _
           errorNumber, errorSource) Then
        On Error Resume Next
        Call TryHoldFormattingEventsStopped(eventStateDetail)
        On Error GoTo 0
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    On Error Resume Next
    cleanupEventsStopped = TryHoldFormattingEventsStopped(eventStateDetail)
    localConvergenceConfirmed = Not mutationStarted
    If mutationStarted And cleanupEventsStopped Then
        emergencyProtected = TryEmergencyProtectToolSheet(ws, emergencyDetail)
        If Not emergencyProtected Then _
            AppendUtilitiesSafetyDetail recoveryDetail, _
                "緊急再保護処理: " & emergencyDetail
        cleanupEventsStopped = _
            TryHoldFormattingEventsStopped(eventStateDetail)
        If cleanupEventsStopped Then
            verificationDetail = vbNullString
            protectionConfirmed = _
                FormattingSheetProtectionIsConfirmedExact( _
                    sheetName, verificationDetail)
            If Not protectionConfirmed Then _
                AppendUtilitiesSafetyDetail recoveryDetail, _
                    "生成表の保護読戻し: " & verificationDetail
        End If
        savedFlagRestored = Not workbookWasSaved
        If cleanupEventsStopped And protectionConfirmed And workbookWasSaved Then
            savedRestoreDetail = vbNullString
            savedFlagRestored = _
                TryRestoreGeneratedOutputSavedFlag(savedRestoreDetail)
            If Not savedFlagRestored Then _
                AppendUtilitiesSafetyDetail recoveryDetail, _
                    "ブック保存状態の復元未完了: " & savedRestoreDetail
            cleanupEventsStopped = _
                TryHoldFormattingEventsStopped(eventStateDetail)
        End If
        localConvergenceConfirmed = protectionConfirmed And _
                                    savedFlagRestored And _
                                    cleanupEventsStopped
    ElseIf mutationStarted Then
        AppendUtilitiesSafetyDetail recoveryDetail, _
            "イベント停止を確認できないため緊急再保護・保存状態への書込みを実行していません。" & _
            IIf(Len(eventStateDetail) > 0, " " & eventStateDetail, vbNullString)
    End If

    If Not localConvergenceConfirmed And cleanupEventsStopped Then
        Err.Clear
        '一度でも中央Recoveryへ入った時点で、このPublic入口は終端となる。
        '成功時も外側へ戻って二回目のRecoveryやentry=Trueを許可しない。
        recoveryHardBarrierDetected = True
        EnforceRollbackRecoveryState recoveryDetail
        recoveryErrorNumber = Err.Number
        recoveryErrorDescription = Err.Description
        Err.Clear
        Call TryHoldFormattingEventsStopped(postEnforceEventDetail)
        On Error GoTo 0
        Err.Raise UTILITIES_RECOVERY_HARD_BARRIER_ERROR, _
                  "ProtectGeneratedOutputSheet(" & sheetName & ")", _
                  errorDescription
    End If

    applicationStateSafe = Not entryEvents
    If entryEvents And cleanupEventsStopped And recoveryErrorNumber = 0 Then
        appStateProblems = vbNullString
        applicationStateSafe = AppStateIsRestored(appStateProblems)
        If Not applicationStateSafe Then _
            AppendUtilitiesSafetyDetail recoveryDetail, _
                "Excel全体状態を安全に復元済みと確認できません: " & _
                appStateProblems
    End If
    safeToRestoreEntry = cleanupEventsStopped And applicationStateSafe And _
                         (localConvergenceConfirmed Or recoveryConfirmed)
    finalEventsStopped = False
    If entryEventsCaptured Then
        finalEventsStopped = _
            TryHoldFormattingEventsStopped(convergenceDetail)
        If Not entryEvents Then
            eventsRestored = finalEventsStopped
        ElseIf safeToRestoreEntry And finalEventsStopped Then
            eventRestoreDetail = vbNullString
            eventsRestored = TryRestoreFormattingEntryEvents( _
                                 entryEventsCaptured, entryEvents, _
                                 eventRestoreDetail)
            If Not eventsRestored Then _
                AppendUtilitiesSafetyDetail recoveryDetail, _
                    "イベント開始値の復元未完了: " & eventRestoreDetail
        Else
            AppendUtilitiesSafetyDetail recoveryDetail, _
                "再保護またはRecoveryを厳密確認できないため、" & _
                "Excelイベントを開始値へ戻さずFalseで停止しました。" & _
                IIf(finalEventsStopped, vbNullString, " " & convergenceDetail)
        End If
    End If
    On Error GoTo 0
    GoTo PROTECT_GENERATED_RAISE

PROTECT_GENERATED_HARD_BARRIER:
    finalEventsStopped = _
        TryHoldFormattingEventsStopped(convergenceDetail)
    If Not finalEventsStopped Then _
        AppendUtilitiesSafetyDetail recoveryDetail, _
            "Recovery hard barrier後もExcelイベントをFalseへ収束できません: " & _
            convergenceDetail
    errorNumber = UTILITIES_RECOVERY_HARD_BARRIER_ERROR
    On Error GoTo 0

PROTECT_GENERATED_RAISE:
    If recoveryHardBarrierDetected Then
        errorDescription = "元エラー Err " & CStr(errorNumber) & ": " & _
                           errorDescription & _
                           IIf(Len(recoveryDetail) > 0, _
                               " / " & recoveryDetail, vbNullString)
        errorNumber = UTILITIES_RECOVERY_HARD_BARRIER_ERROR
    End If
    Err.Raise errorNumber, "ProtectGeneratedOutputSheet(" & sheetName & ")", _
              errorDescription & _
              IIf(Not recoveryHardBarrierDetected And Len(recoveryDetail) > 0, _
                  " / " & recoveryDetail, vbNullString)
End Sub

Private Function TryRestoreGeneratedOutputSavedFlag( _
        ByRef detailText As String) As Boolean
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    detailText = vbNullString
    On Error GoTo EH
    ThisWorkbook.Saved = True
    If Not ThisWorkbook.Saved Then _
        Err.Raise vbObjectError + 1135, _
                  "TryRestoreGeneratedOutputSavedFlag", _
                  "ブック保存状態の書込み後読戻しが一致しません。"
    TryRestoreGeneratedOutputSavedFlag = True
    Exit Function
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    detailText = "Err " & CStr(errorNumber) & ": " & errorDescription
    Err.Clear
End Function

Public Sub DeleteToolShapes(ByVal ws As Worksheet, Optional ByVal deleteAll As Boolean = False)
    'ツールが作成した図形だけを削除する。
    '図形保護を有効にしているため、再生成前には必ず保護解除してから削除する。
    Dim i As Long
    Dim nm As String
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    ws.Unprotect Password:=TOOL_PASSWORD
    For i = ws.Shapes.Count To 1 Step -1
        nm = ws.Shapes(i).Name
        If deleteAll Or Left$(nm, Len(UI_PREFIX)) = UI_PREFIX Then ws.Shapes(i).Delete
    Next i
    On Error GoTo 0
End Sub

Public Sub DeleteToolShapesVerified(ByVal ws As Worksheet, Optional ByVal deleteAll As Boolean = False)
    Dim shp As Shape
    If ws Is Nothing Then Exit Sub
    DeleteToolShapes ws, deleteAll
    For Each shp In ws.Shapes
        If deleteAll Or Left$(shp.Name, Len(UI_PREFIX)) = UI_PREFIX Then
            Err.Raise vbObjectError + 1005, "DeleteToolShapesVerified", _
                      "既存の操作図形を削除できませんでした: " & ws.Name & " / " & shp.Name
        End If
    Next shp
End Sub

Public Sub LockToolShapes(ByVal ws As Worksheet, _
                          Optional ByVal requirePrintState As Boolean = False)
    '図形ボタンやカード背景を誤って移動・サイズ変更しないようにする。
    'ボタン動作は現在のブック名へ張り直す。非印刷は可能なら設定し、
    'requirePrintState=Trueを明示した印刷直前の経路だけ必須条件として検証する。
    Dim shp As Shape
    Dim macroName As String
    Dim printStateKnown As Boolean
    Dim errorNumber As Long, errorDescription As String

    If ws Is Nothing Then Exit Sub
    On Error GoTo EH
    For Each shp In ws.Shapes
        If Left$(shp.Name, Len(UI_PREFIX)) = UI_PREFIX Then
            shp.Locked = True
            If Not shp.Locked Then _
                Err.Raise vbObjectError + 1112, "LockToolShapes", _
                          "操作図形をロックできません: " & ws.Name & " / " & shp.Name
            'セル幅や行高を直した時にもボタンを追随移動させない。
            'Locked=TrueとDrawingObjects保護でドラッグを防ぎ、OnActionは実行できる。
            shp.Placement = xlFreeFloating
            If shp.Placement <> xlFreeFloating Then _
                Err.Raise vbObjectError + 1113, "LockToolShapes", _
                          "操作図形の配置方式を固定できません: " & ws.Name & " / " & shp.Name
            If Not SetToolShapePrintState(ws, shp.Name, False) Then
                If requirePrintState Then _
                    Err.Raise vbObjectError + 1114, "LockToolShapes", _
                              "操作図形を印刷対象外にできません: " & ws.Name & " / " & shp.Name
            ElseIf ToolShapePrintState(ws, shp.Name, printStateKnown) Or Not printStateKnown Then
                If requirePrintState Then _
                    Err.Raise vbObjectError + 1115, "LockToolShapes", _
                              "操作図形の印刷設定を確認できません: " & ws.Name & " / " & shp.Name
            End If

            If Left$(shp.Name, Len(UI_PREFIX & "btn_")) = UI_PREFIX & "btn_" Then
                macroName = ToolShapeActionName(shp)
                If Len(macroName) = 0 Then _
                    Err.Raise vbObjectError + 1116, "LockToolShapes", _
                              "操作ボタンの動作名がありません: " & ws.Name & " / " & shp.Name
                shp.OnAction = MacroRef(macroName)
                If Not ToolShapeActionMatches(shp, macroName, True) Then _
                    Err.Raise vbObjectError + 1117, "LockToolShapes", _
                              "操作ボタンの動作を現在のブックへ設定できません: " & _
                              ws.Name & " / " & shp.Name
                '色は作成・書式復旧時に補正する。保護処理ではOffice描画APIの
                '色読戻し不能を理由に、セル・図形保護まで失敗扱いにしない。
                On Error Resume Next
                EnsureToolShapeTextContrast shp, ws.Name & " / " & shp.Name
                Err.Clear
                On Error GoTo EH
            End If
        End If
    Next shp
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    Err.Raise errorNumber, "LockToolShapes(" & ws.Name & ")", errorDescription
End Sub

Public Sub VerifyToolShapeSecurity(ByVal ws As Worksheet, _
                                   Optional ByVal requireSheetProtection As Boolean = True, _
                                   Optional ByVal requirePrintState As Boolean = False)
    '「Lockedだけ」「シート保護だけ」の片方では誤移動を防げない。
    'ロック、配置、現在ブックへのOnAction、図形保護をまとめて検査する。
    '非印刷はrequirePrintState=Trueを明示した場合だけ読戻しまで必須にする。
    Dim shp As Shape
    Dim macroName As String
    Dim printStateKnown As Boolean
    Dim errorNumber As Long, errorDescription As String
    If ws Is Nothing Then Exit Sub
    On Error GoTo EH

    If requireSheetProtection Then
        If Not ws.ProtectContents Or Not ws.ProtectDrawingObjects Then _
            Err.Raise vbObjectError + 1118, "VerifyToolShapeSecurity", _
                      "セルまたは図形のシート保護が無効です: " & ws.Name
    End If

    For Each shp In ws.Shapes
        If Left$(shp.Name, Len(UI_PREFIX)) = UI_PREFIX Then
            If Not shp.Locked Then _
                Err.Raise vbObjectError + 1119, "VerifyToolShapeSecurity", _
                          "操作図形がロックされていません: " & ws.Name & " / " & shp.Name
            If shp.Placement <> xlFreeFloating Then _
                Err.Raise vbObjectError + 1120, "VerifyToolShapeSecurity", _
                          "操作図形の配置方式が不正です: " & ws.Name & " / " & shp.Name
            If requirePrintState Then
                If ToolShapePrintState(ws, shp.Name, printStateKnown) Or Not printStateKnown Then _
                    Err.Raise vbObjectError + 1121, "VerifyToolShapeSecurity", _
                              "操作図形の非印刷設定を確認できません: " & ws.Name & " / " & shp.Name
            End If
            If Left$(shp.Name, Len(UI_PREFIX & "btn_")) = UI_PREFIX & "btn_" Then
                macroName = ToolShapeActionName(shp)
                If Len(macroName) = 0 Or _
                   Not ToolShapeActionMatches(shp, macroName, True) Then _
                    Err.Raise vbObjectError + 1122, "VerifyToolShapeSecurity", _
                              "操作ボタンの実行先が不正です: " & ws.Name & " / " & shp.Name
            End If
        End If
    Next shp
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    Err.Raise errorNumber, "VerifyToolShapeSecurity(" & ws.Name & ")", errorDescription
End Sub

Public Sub EmergencyProtectToolSheet(ByVal ws As Worksheet)
    '通常の保護処理が途中で失敗しても、図形を無防備なまま残さない最終防御。
    Dim shp As Shape
    Dim printStateKnown As Boolean
    Dim errorNumber As Long, errorDescription As String, protectionDetail As String
    Dim sheetName As String
    If ws Is Nothing Then Exit Sub
    On Error GoTo EH
    sheetName = ws.Name
    ws.Unprotect Password:=TOOL_PASSWORD
    For Each shp In ws.Shapes
        If Left$(shp.Name, Len(UI_PREFIX)) = UI_PREFIX Then
            shp.Locked = True
            If Not shp.Locked Then _
                Err.Raise vbObjectError + 1130, "EmergencyProtectToolSheet", _
                          "操作図形をロックできません: " & shp.Name
            shp.Placement = xlFreeFloating
            If shp.Placement <> xlFreeFloating Then _
                Err.Raise vbObjectError + 1130, "EmergencyProtectToolSheet", _
                          "操作図形の配置方式を固定できません: " & shp.Name
            If Not SetToolShapePrintState(ws, shp.Name, False) Then _
                Err.Raise vbObjectError + 1130, "EmergencyProtectToolSheet", _
                          "操作図形を印刷対象外にできません: " & shp.Name
            If ToolShapePrintState(ws, shp.Name, printStateKnown) Or _
               Not printStateKnown Then _
                Err.Raise vbObjectError + 1130, "EmergencyProtectToolSheet", _
                          "操作図形の非印刷設定を確認できません: " & shp.Name
        End If
    Next shp
    ApplyGeneratedOutputProtection ws
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    '図形の個別設定に失敗してもセル・図形保護だけは再試行する。
    '再試行の成否にかかわらず元の失敗を呼出元へ返す。
    If Not TryApplyGeneratedOutputProtection(ws, protectionDetail) Then
        errorDescription = errorDescription & " / 最小再保護も確認できません: " & protectionDetail
    End If
    Err.Raise errorNumber, "EmergencyProtectToolSheet(" & sheetName & ")", errorDescription
End Sub

Private Sub ApplyGeneratedOutputProtection(ByVal ws As Worksheet)
    If ws Is Nothing Then _
        Err.Raise vbObjectError + 1130, "ApplyGeneratedOutputProtection", _
                  "再保護するシートを取得できません。"
    ws.Protect Password:=TOOL_PASSWORD, DrawingObjects:=True, Contents:=True, Scenarios:=False, _
               UserInterfaceOnly:=True, AllowFiltering:=True, AllowSorting:=False, _
               AllowFormattingCells:=False, AllowFormattingColumns:=False, AllowFormattingRows:=False
    AssertGeneratedOutputProtection ws
End Sub

Private Sub AssertGeneratedOutputProtection(ByVal ws As Worksheet)
    '保護APIがエラーなしで戻っても、要求した最終状態そのものを確認する。
    If Not ws.ProtectContents Then _
        Err.Raise vbObjectError + 1130, "AssertGeneratedOutputProtection", _
                  "セル保護が有効ではありません: " & ws.Name
    If Not ws.ProtectDrawingObjects Then _
        Err.Raise vbObjectError + 1130, "AssertGeneratedOutputProtection", _
                  "図形保護が有効ではありません: " & ws.Name
    If Not ws.Protection.AllowFiltering Then _
        Err.Raise vbObjectError + 1130, "AssertGeneratedOutputProtection", _
                  "フィルター許可を読み戻せません: " & ws.Name
    If ws.Protection.AllowSorting Then _
        Err.Raise vbObjectError + 1130, "AssertGeneratedOutputProtection", _
                  "禁止した並べ替えが許可されています: " & ws.Name
    If ws.Protection.AllowFormattingCells Or _
       ws.Protection.AllowFormattingColumns Or _
       ws.Protection.AllowFormattingRows Then _
        Err.Raise vbObjectError + 1130, "AssertGeneratedOutputProtection", _
                  "禁止した書式変更が許可されています: " & ws.Name
End Sub

Private Function TryApplyGeneratedOutputProtection(ByVal ws As Worksheet, _
                                                    ByRef failureText As String) As Boolean
    failureText = vbNullString
    On Error GoTo EH
    ApplyGeneratedOutputProtection ws
    TryApplyGeneratedOutputProtection = True
    Exit Function
EH:
    failureText = "Err " & CStr(Err.Number) & " " & Err.Description
    Err.Clear
End Function

Private Function TryEmergencyProtectToolSheet(ByVal ws As Worksheet, _
                                              ByRef failureText As String) As Boolean
    failureText = vbNullString
    On Error GoTo EH
    EmergencyProtectToolSheet ws
    TryEmergencyProtectToolSheet = True
    Exit Function
EH:
    failureText = "Err " & CStr(Err.Number) & " " & Err.Description
    Err.Clear
End Function

Public Sub ResetName(ByVal nm As String, ByVal rng As Range)
    Dim refText As String
    Dim createdName As Name
    Dim verifyRange As Range
    Dim ws As Worksheet, localNameText As String
    Dim i As Long, separatorPos As Long
    Dim errorNumber As Long, errorDescription As String
    If rng Is Nothing Then Exit Sub
    On Error GoTo EH
    refText = "='" & Replace(rng.Worksheet.Name, "'", "''") & "'!" & rng.Address(True, True, xlA1, False)
    '既存のブック定義名は削除せず参照先だけを更新する。Delete→Addの一瞬に
    '入力規則の =定義名 が #REF! 化するOffice環境差を避ける。
    On Error Resume Next
    Set createdName = ThisWorkbook.Names(nm)
    Err.Clear
    On Error GoTo EH
    If createdName Is Nothing Then
        Set createdName = ThisWorkbook.Names.Add(Name:=nm, RefersTo:=refText)
    Else
        createdName.RefersTo = refText
    End If
    If createdName Is Nothing Then _
        Err.Raise vbObjectError + 1018, "ResetName", "定義名を作成できませんでした: " & nm

    '旧ブックに残ったシートローカルの同名定義は、入力規則からブック定義名を隠す。
    'ブック定義名を先に確保してから、「!」を含むローカル名だけを削除する。
    For Each ws In ThisWorkbook.Worksheets
        For i = ws.Names.Count To 1 Step -1
            localNameText = ws.Names(i).Name
            separatorPos = InStrRev(localNameText, "!")
            If separatorPos > 0 Then
                If StrComp(Mid$(localNameText, separatorPos + 1), nm, vbTextCompare) = 0 Then _
                    ws.Names(i).Delete
            End If
        Next i
    Next ws
    Set verifyRange = createdName.RefersToRange
    If verifyRange Is Nothing Then _
        Err.Raise vbObjectError + 1019, "ResetName", "定義名の参照先を確認できません: " & nm
    If StrComp(verifyRange.Worksheet.Name, rng.Worksheet.Name, vbTextCompare) <> 0 Or _
       StrComp(verifyRange.Address(True, True, xlA1, False), _
               rng.Address(True, True, xlA1, False), vbTextCompare) <> 0 Then _
        Err.Raise vbObjectError + 1020, "ResetName", "定義名の参照先が一致しません: " & nm
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    Err.Raise errorNumber, "ResetName(" & nm & ")", errorDescription
End Sub

Public Function MacroRef(ByVal macroName As String) As String
    '図形ボタンが別ブックの同名マクロを拾わないよう、このブックへ明示的に紐づける。
    MacroRef = "'" & Replace(ThisWorkbook.Name, "'", "''") & "'!" & macroName
End Function

Public Function ToolShapeActionName(ByVal shp As Shape) As String
    '実行先はOnActionを正とし、代替テキストは利用者向け説明だけに使う。
    '旧版図形の移行時だけ、従来どおり代替テキスト内のマクロ名を読み取る。
    Dim actionText As String
    Dim separatorPos As Long
    Dim modulePos As Long
    Dim nameMarkerPos As Long
    If shp Is Nothing Then Exit Function
    On Error GoTo LegacyValue
    actionText = Trim$(CellText(shp.OnAction))
    separatorPos = InStrRev(actionText, "!", -1, vbBinaryCompare)
    If separatorPos > 0 Then actionText = Mid$(actionText, separatorPos + 1)
    actionText = Trim$(actionText)
    modulePos = InStrRev(actionText, ".", -1, vbBinaryCompare)
    If modulePos > 0 Then actionText = Trim$(Mid$(actionText, modulePos + 1))
    If Len(actionText) > 0 Then
        ToolShapeActionName = actionText
        Exit Function
    End If
LegacyValue:
    Err.Clear
    On Error Resume Next
    '新しい図形は実行先を図形名の「__」以降にも保持する。
    'OnActionがOffice側で空にされた場合だけ使用し、表示用説明文とは分離する。
    nameMarkerPos = InStrRev(CellText(shp.Name), "__", -1, vbBinaryCompare)
    If nameMarkerPos > 0 Then
        actionText = Trim$(Mid$(CellText(shp.Name), nameMarkerPos + 2))
        If Len(actionText) > 0 Then
            ToolShapeActionName = actionText
            On Error GoTo 0
            Exit Function
        End If
    End If
    actionText = Trim$(CellText(shp.AlternativeText))
    If InStr(1, actionText, " ", vbBinaryCompare) = 0 And _
       InStr(1, actionText, "。", vbBinaryCompare) = 0 Then _
        ToolShapeActionName = actionText
    On Error GoTo 0
End Function

Public Function ToolShapeActionMatches(ByVal shp As Shape, ByVal expectedMacroName As String, _
                                       Optional ByVal requireCurrentWorkbook As Boolean = True) As Boolean
    'ExcelはOnActionのブック修飾を、引用符の有無やフルパス付き表記へ
    '正規化することがある。生文字列ではなくマクロ名と参照ブック名を比較する。
    Dim actionText As String
    Dim qualifier As String
    Dim workbookName As String
    Dim baseName As String
    Dim separatorPos As Long
    Dim modulePos As Long
    Dim pathPos As Long
    Dim bracketOpen As Long, bracketClose As Long
    If shp Is Nothing Then Exit Function
    If StrComp(ToolShapeActionName(shp), Trim$(expectedMacroName), vbTextCompare) <> 0 Then Exit Function
    If Not requireCurrentWorkbook Then
        ToolShapeActionMatches = True
        Exit Function
    End If

    On Error GoTo EH
    actionText = Trim$(CellText(shp.OnAction))
    If Len(actionText) = 0 Then Exit Function
    If Left$(actionText, 1) = "=" Then actionText = Trim$(Mid$(actionText, 2))
    separatorPos = InStrRev(actionText, "!", -1, vbBinaryCompare)
    '一部のExcelビルドは、完全修飾して設定しても読戻し時にブック修飾を省略する。
    'その場合は直前に確認した正規マクロ名を採用する。修飾が返る場合だけ所有ブックを厳格比較する。
    If separatorPos = 0 Then
        modulePos = InStrRev(actionText, ".", -1, vbBinaryCompare)
        If modulePos > 0 Then actionText = Trim$(Mid$(actionText, modulePos + 1))
        ToolShapeActionMatches = _
            (StrComp(actionText, Trim$(expectedMacroName), vbTextCompare) = 0)
        Exit Function
    End If
    If separatorPos <= 1 Then Exit Function
    qualifier = Trim$(Left$(actionText, separatorPos - 1))
    If Len(qualifier) >= 2 Then
        If Left$(qualifier, 1) = "'" And Right$(qualifier, 1) = "'" Then _
            qualifier = Mid$(qualifier, 2, Len(qualifier) - 2)
    End If
    qualifier = Replace(qualifier, "''", "'")
    qualifier = Replace(qualifier, "/", "\")
    pathPos = InStrRev(qualifier, "\", -1, vbBinaryCompare)
    If pathPos > 0 Then
        baseName = Mid$(qualifier, pathPos + 1)
    Else
        baseName = qualifier
    End If
    '通常のフルパス/ファイル名を先に比較し、フォルダ名や合法なファイル名に
    '含まれる[]を外部参照記法と誤認しない。
    If StrComp(baseName, ThisWorkbook.Name, vbTextCompare) = 0 Then
        ToolShapeActionMatches = True
        Exit Function
    End If
    '外部参照形式 [book.xlsm]Module1 はbasename内の最後の[]を使う。
    bracketOpen = InStrRev(baseName, "[", -1, vbBinaryCompare)
    If bracketOpen > 0 Then bracketClose = InStr(bracketOpen + 1, baseName, "]", vbBinaryCompare)
    If bracketOpen > 0 And bracketClose > bracketOpen + 1 Then
        workbookName = Mid$(baseName, bracketOpen + 1, bracketClose - bracketOpen - 1)
    Else
        workbookName = baseName
    End If
    ToolShapeActionMatches = _
        (StrComp(workbookName, ThisWorkbook.Name, vbTextCompare) = 0)
    Exit Function
EH:
    ToolShapeActionMatches = False
    Err.Clear
End Function

Public Sub SetToolShapeAccessibleLabel(ByVal shp As Shape, ByVal caption As String)
    'スクリーンリーダーへ内部マクロ名を読み上げず、画面と同じ操作名を伝える。
    If shp Is Nothing Then Exit Sub
    On Error Resume Next
    Err.Clear
    shp.Title = caption & " ボタン"
    shp.AlternativeText = caption & "。クリックして実行します。"
    Err.Clear
    On Error GoTo 0
End Sub

Public Sub SetRowValues(ByVal firstCell As Range, ByVal values As Variant)
    '1次元ArrayをRangeへ直接代入する環境差を避け、横方向に確実に書き込む。
    Dim i As Long
    If firstCell Is Nothing Then Exit Sub
    For i = LBound(values) To UBound(values)
        firstCell.Offset(0, i - LBound(values)).Value = values(i)
    Next i
End Sub

Public Function StrictVariantValuesMatch(ByVal expectedValue As Variant, _
                                         ByVal actualValue As Variant) As Boolean
    'Excelへの一括書込みを確認する。Value2はByte/Integer/Long/Single/Currency/Dateを
    'Doubleへ正規化して返すため、数値系Variantの細かな型差だけは同値として扱う。
    Dim expectedType As VbVarType, actualType As VbVarType
    On Error GoTo EH
    expectedType = VarType(expectedValue)
    actualType = VarType(actualValue)
    If IsExcelValue2NumericType(expectedType) And _
       IsExcelValue2NumericType(actualType) Then
        StrictVariantValuesMatch = (CDbl(expectedValue) = CDbl(actualValue))
        Exit Function
    End If
    If expectedType <> actualType Then Exit Function
    If IsError(expectedValue) Then
        StrictVariantValuesMatch = _
            (StrComp(CStr(expectedValue), CStr(actualValue), vbBinaryCompare) = 0)
    ElseIf IsNull(expectedValue) Then
        StrictVariantValuesMatch = IsNull(actualValue)
    ElseIf IsEmpty(expectedValue) Then
        StrictVariantValuesMatch = IsEmpty(actualValue)
    ElseIf VarType(expectedValue) = vbString Then
        StrictVariantValuesMatch = _
            (StrComp(CStr(expectedValue), CStr(actualValue), vbBinaryCompare) = 0)
    Else
        StrictVariantValuesMatch = CBool(expectedValue = actualValue)
    End If
    Exit Function
EH:
    StrictVariantValuesMatch = False
    Err.Clear
End Function

Private Function IsExcelValue2NumericType(ByVal valueType As VbVarType) As Boolean
    Select Case valueType
        Case vbByte, vbInteger, vbLong, vbSingle, vbDouble, vbCurrency, vbDecimal, vbDate
            IsExcelValue2NumericType = True
    End Select
End Function

Public Function RangeValue2MatchesMatrixStrict(ByVal target As Range, _
                                                ByRef expectedData As Variant, _
                                                ByVal expectedRows As Long, _
                                                ByVal expectedColumns As Long) As Boolean
    '全セル・行順・Variant型を照合し、同じ表示に見える型違いや数式化も失敗とする。
    Dim actualData As Variant
    Dim formulaCell As Range
    Dim r As Long, c As Long
    On Error GoTo EH
    If target Is Nothing Or expectedRows < 1 Or expectedColumns < 1 Then Exit Function
    If target.Rows.Count <> expectedRows Or target.Columns.Count <> expectedColumns Then Exit Function
    If Not IsArray(expectedData) Then Exit Function
    If LBound(expectedData, 1) <> 1 Or UBound(expectedData, 1) <> expectedRows Then Exit Function
    If LBound(expectedData, 2) <> 1 Or UBound(expectedData, 2) <> expectedColumns Then Exit Function

    If Not TryFindFirstFormulaCell(target, formulaCell) Then Exit Function
    If Not formulaCell Is Nothing Then Exit Function

    actualData = target.Value2
    If expectedRows = 1 And expectedColumns = 1 Then
        RangeValue2MatchesMatrixStrict = _
            StrictVariantValuesMatch(expectedData(1, 1), actualData)
        Exit Function
    End If
    For r = 1 To expectedRows
        For c = 1 To expectedColumns
            If Not StrictVariantValuesMatch(expectedData(r, c), actualData(r, c)) Then Exit Function
        Next c
    Next r
    RangeValue2MatchesMatrixStrict = True
    Exit Function
EH:
    RangeValue2MatchesMatrixStrict = False
    Err.Clear
End Function

Public Function VariantMatrixContainsError(ByRef data As Variant, ByVal rowCount As Long, _
                                           ByVal columnCount As Long) As Boolean
    Dim r As Long, c As Long
    On Error GoTo EH
    If Not IsArray(data) Or rowCount < 1 Or columnCount < 1 Then
        VariantMatrixContainsError = True
        Exit Function
    End If
    If LBound(data, 1) <> 1 Or UBound(data, 1) <> rowCount Or _
       LBound(data, 2) <> 1 Or UBound(data, 2) <> columnCount Then
        VariantMatrixContainsError = True
        Exit Function
    End If
    For r = 1 To rowCount
        For c = 1 To columnCount
            If IsError(data(r, c)) Then
                VariantMatrixContainsError = True
                Exit Function
            End If
        Next c
    Next r
    Exit Function
EH:
    VariantMatrixContainsError = True
    Err.Clear
End Function

Public Sub CaptureAtomicConstantWorksheetData( _
        ByVal ws As Worksheet, ByVal lastColumn As Long, ByVal maximumDataRows As Long, _
        ByRef snapshot As Variant, ByRef snapshotLastRow As Long, _
        ByVal labelText As String)
    Dim dataRange As Range, formulaCell As Range
    Dim rowCount As Long
    snapshot = Empty
    snapshotLastRow = 1
    If ws Is Nothing Or lastColumn < 1 Or maximumDataRows < 0 Then _
        Err.Raise vbObjectError + 1060, "CaptureAtomicConstantWorksheetData", _
                  labelText & "の退避条件が不正です。"
    snapshotLastRow = LastDataRowInColumns(ws, 1, lastColumn)
    If snapshotLastRow < 2 Then
        snapshotLastRow = 1
        Exit Sub
    End If
    rowCount = snapshotLastRow - 1
    If rowCount > maximumDataRows Then _
        Err.Raise vbObjectError + 1061, "CaptureAtomicConstantWorksheetData", _
                  labelText & "が退避上限（" & Format$(maximumDataRows, "#,##0") & _
                  "行）を超えています。"
    Set dataRange = ws.Range(ws.Cells(2, 1), ws.Cells(snapshotLastRow, lastColumn))
    If Not TryFindFirstFormulaCell(dataRange, formulaCell) Then _
        Err.Raise vbObjectError + 1062, "CaptureAtomicConstantWorksheetData", _
                  labelText & "の数式検査に失敗しました。"
    If Not formulaCell Is Nothing Then _
        Err.Raise vbObjectError + 1062, "CaptureAtomicConstantWorksheetData", _
                  labelText & "に数式があります: " & _
                  formulaCell.Cells(1, 1).Address(False, False)
    snapshot = dataRange.Value2
    If VariantMatrixContainsError(snapshot, rowCount, lastColumn) Then _
        Err.Raise vbObjectError + 1063, "CaptureAtomicConstantWorksheetData", _
                  labelText & "にExcelエラー値があるか、全セルを確認できません。"
    If Not RangeValue2MatchesMatrixStrict( _
               dataRange, snapshot, rowCount, lastColumn) Then _
        Err.Raise vbObjectError + 1064, "CaptureAtomicConstantWorksheetData", _
                  labelText & "の退避読戻しが全行・全列・型で一致しません。"
End Sub

Public Sub RestoreAtomicConstantWorksheetData( _
        ByVal ws As Worksheet, ByVal lastColumn As Long, ByVal maximumDataRows As Long, _
        ByRef snapshot As Variant, ByVal snapshotLastRow As Long, _
        ByVal labelText As String)
    Dim currentLastRow As Long, clearLastRow As Long, rowCount As Long
    Dim restoredRange As Range, formulaCell As Range
    If ws Is Nothing Or lastColumn < 1 Or maximumDataRows < 0 Or _
       snapshotLastRow < 1 Then _
        Err.Raise vbObjectError + 1065, "RestoreAtomicConstantWorksheetData", _
                  labelText & "の復元条件が不正です。"
    rowCount = snapshotLastRow - 1
    If rowCount > maximumDataRows Then _
        Err.Raise vbObjectError + 1065, "RestoreAtomicConstantWorksheetData", _
                  labelText & "の復元件数が上限を超えています。"
    currentLastRow = LastDataRowInColumns(ws, 1, lastColumn)
    clearLastRow = CLng(Application.Max(currentLastRow, snapshotLastRow))
    If clearLastRow >= 2 Then _
        ws.Range(ws.Cells(2, 1), ws.Cells(clearLastRow, lastColumn)).ClearContents
    If snapshotLastRow >= 2 Then
        If Not IsArray(snapshot) Then _
            Err.Raise vbObjectError + 1065, "RestoreAtomicConstantWorksheetData", _
                      labelText & "の退避配列がありません。"
        Set restoredRange = ws.Range(ws.Cells(2, 1), _
                                     ws.Cells(snapshotLastRow, lastColumn))
        restoredRange.Value2 = snapshot
        If Not RangeValue2MatchesMatrixStrict( _
                   restoredRange, snapshot, rowCount, lastColumn) Then _
            Err.Raise vbObjectError + 1066, "RestoreAtomicConstantWorksheetData", _
                      labelText & "の復元読戻しが全行・全列・型で一致しません。"
    End If
    If LastDataRowInColumns(ws, 1, lastColumn) <> snapshotLastRow Then _
        Err.Raise vbObjectError + 1067, "RestoreAtomicConstantWorksheetData", _
                  labelText & "の復元行数が一致しません。"
    If clearLastRow >= 2 Then
        If Not TryFindFirstFormulaCell( _
                   ws.Range(ws.Cells(2, 1), ws.Cells(clearLastRow, lastColumn)), _
                   formulaCell) Then _
            Err.Raise vbObjectError + 1068, "RestoreAtomicConstantWorksheetData", _
                      labelText & "の復元後数式検査に失敗しました。"
        If Not formulaCell Is Nothing Then _
            Err.Raise vbObjectError + 1068, "RestoreAtomicConstantWorksheetData", _
                      labelText & "の復元後に数式が残っています。"
    End If
End Sub

Public Sub CaptureConstantDataStoreSnapshot(ByVal ws As Worksheet, ByVal lastColumn As Long, _
                                            ByRef snapshot As Variant, ByRef snapshotLastRow As Long)
    '内部保管の全行を、行順とValue2のVariant型を保ったまま退避する。
    Dim dataRange As Range, formulaCells As Range
    Dim rowCount As Long
    snapshot = Empty
    snapshotLastRow = 1
    If ws Is Nothing Or lastColumn < 1 Then _
        Err.Raise vbObjectError + 1040, "CaptureConstantDataStoreSnapshot", _
                  "内部保管または列数が不正です。"
    snapshotLastRow = LastDataRowInColumns(ws, 1, lastColumn)
    If snapshotLastRow < 2 Then
        snapshotLastRow = 1
        Exit Sub
    End If
    rowCount = snapshotLastRow - 1
    If rowCount > MAX_INTERNAL_STORE_DATA_ROWS Then _
        Err.Raise vbObjectError + 1041, "CaptureConstantDataStoreSnapshot", _
                  "内部保管が退避上限を超えています: " & ws.Name
    Set dataRange = ws.Range(ws.Cells(2, 1), ws.Cells(snapshotLastRow, lastColumn))
    If Not TryFindFirstFormulaCell(dataRange, formulaCells) Then _
        Err.Raise vbObjectError + 1042, "CaptureConstantDataStoreSnapshot", _
                  "内部保管の数式検査に失敗しました: " & ws.Name
    If Not formulaCells Is Nothing Then _
        Err.Raise vbObjectError + 1042, "CaptureConstantDataStoreSnapshot", _
                  "内部保管に数式があります: " & ws.Name & " " & _
                  formulaCells.Cells(1, 1).Address(False, False)
    snapshot = dataRange.Value2
    If VariantMatrixContainsError(snapshot, rowCount, lastColumn) Then _
        Err.Raise vbObjectError + 1043, "CaptureConstantDataStoreSnapshot", _
                  "内部保管にExcelエラー値があるか、全セルを確認できません: " & ws.Name
    If Not RangeValue2MatchesMatrixStrict(dataRange, snapshot, rowCount, lastColumn) Then _
        Err.Raise vbObjectError + 1044, "CaptureConstantDataStoreSnapshot", _
                  "内部保管の退避読戻しが一致しません: " & ws.Name
End Sub

Public Sub RestoreConstantDataStoreSnapshot(ByVal ws As Worksheet, ByVal lastColumn As Long, _
                                            ByVal snapshot As Variant, ByVal snapshotLastRow As Long)
    '現行の部分行も含めて消去後に全体を戻し、全列・行順・型を厳密に読戻す。
    Dim currentLastRow As Long, clearLastRow As Long, rowCount As Long
    Dim restoredRange As Range, remainingFormula As Range
    Dim errorNumber As Long, errorDescription As String, sheetName As String
    On Error GoTo EH
    If ws Is Nothing Or lastColumn < 1 Or snapshotLastRow < 1 Then _
        Err.Raise vbObjectError + 1045, "RestoreConstantDataStoreSnapshot", _
                  "内部保管の復元条件が不正です。"
    currentLastRow = LastDataRowInColumns(ws, 1, lastColumn)
    clearLastRow = CLng(Application.Max(currentLastRow, snapshotLastRow))
    If clearLastRow >= 2 Then _
        ws.Range(ws.Cells(2, 1), ws.Cells(clearLastRow, lastColumn)).ClearContents

    If snapshotLastRow >= 2 Then
        rowCount = snapshotLastRow - 1
        If Not IsArray(snapshot) Then _
            Err.Raise vbObjectError + 1046, "RestoreConstantDataStoreSnapshot", _
                      "内部保管の退避配列がありません: " & ws.Name
        Set restoredRange = ws.Range(ws.Cells(2, 1), ws.Cells(snapshotLastRow, lastColumn))
        restoredRange.Value2 = snapshot
        If Not RangeValue2MatchesMatrixStrict(restoredRange, snapshot, rowCount, lastColumn) Then _
            Err.Raise vbObjectError + 1047, "RestoreConstantDataStoreSnapshot", _
                      "内部保管の復元読戻しが一致しません: " & ws.Name
    End If
    If LastDataRowInColumns(ws, 1, lastColumn) <> snapshotLastRow Then _
        Err.Raise vbObjectError + 1048, "RestoreConstantDataStoreSnapshot", _
                  "内部保管の復元行数が一致しません: " & ws.Name
    If clearLastRow >= 2 Then
        If Not TryFindFirstFormulaCell(ws.Range(ws.Cells(2, 1), _
            ws.Cells(clearLastRow, lastColumn)), remainingFormula) Then _
            Err.Raise vbObjectError + 1049, "RestoreConstantDataStoreSnapshot", _
                      "内部保管の復元後数式検査に失敗しました: " & ws.Name
        If Not remainingFormula Is Nothing Then _
            Err.Raise vbObjectError + 1049, "RestoreConstantDataStoreSnapshot", _
                      "内部保管の復元後に数式が残っています: " & ws.Name
    End If
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    On Error Resume Next
    If Not ws Is Nothing Then sheetName = ws.Name
    On Error GoTo 0
    If Len(sheetName) = 0 Then sheetName = "?"
    Err.Raise errorNumber, "RestoreConstantDataStoreSnapshot(" & sheetName & ")", errorDescription
End Sub

Public Function CompactDeleteDataRows(ByVal ws As Worksheet, ByVal lastColumn As Long, _
                                      ByVal matchColumn As Long, ByVal matchValue As String, _
                                      Optional ByVal secondColumn As Long = 0, _
                                      Optional ByVal secondValue As String = "", _
                                      Optional ByVal deleteWhenSecondEquals As Boolean = True) As Long
    'Rows.Deleteを何万回も繰り返さず、順序を保った配列へ圧縮して一括反映する。
    '書込失敗時は元配列を戻し、関係のない口座行まで巻き込む事故を防ぐ。
    Dim lastR As Long, sourceRows As Long, keepCount As Long, actualCount As Long
    Dim r As Long, c As Long, writeRow As Long
    Dim sourceData As Variant, outputData As Variant
    Dim dataRange As Range, formulaCells As Range, errorCells As Range
    Dim deleteRow As Boolean, writeStarted As Boolean, restoreMatches As Boolean
    Dim errorNumber As Long, errorDescription As String, restoreDetail As String
    If ws Is Nothing Then Exit Function
    If lastColumn < 1 Or matchColumn < 1 Or matchColumn > lastColumn Then _
        Err.Raise vbObjectError + 1006, "CompactDeleteDataRows", "削除条件の列番号が不正です。"
    If secondColumn < 0 Or secondColumn > lastColumn Then _
        Err.Raise vbObjectError + 1007, "CompactDeleteDataRows", "第2削除条件の列番号が不正です。"
    matchValue = CellText(matchValue)
    If Len(matchValue) = 0 Then _
        Err.Raise vbObjectError + 1008, "CompactDeleteDataRows", "削除条件の値が空欄です。"

    'キー列だけが空白の破損行も含める。左端列基準だと、その行を上書きしてしまう。
    lastR = LastDataRowInColumns(ws, 1, lastColumn)
    If lastR < 2 Then Exit Function
    sourceRows = lastR - 1
    If sourceRows > MAX_INTERNAL_STORE_DATA_ROWS Then _
        Err.Raise vbObjectError + 1009, "CompactDeleteDataRows", _
                  "内部データが一括整理の実用上限（" & Format$(MAX_INTERNAL_STORE_DATA_ROWS, "#,##0") & _
                  "行）を超えています。案件を分割してください。"
    Set dataRange = ws.Range(ws.Cells(2, 1), ws.Cells(lastR, lastColumn))
    If Not TryFindFirstFormulaCell(dataRange, formulaCells) Then _
        Err.Raise vbObjectError + 1010, "CompactDeleteDataRows", _
                  "内部保管の数式検査に失敗したため、安全な行整理を中止しました: " & ws.Name
    If Not formulaCells Is Nothing Then _
        Err.Raise vbObjectError + 1010, "CompactDeleteDataRows", _
                  "内部保管に数式があるため、安全な行整理を中止しました: " & _
                  ws.Name & " " & formulaCells.Cells(1, 1).Address(False, False)
    On Error Resume Next
    Err.Clear
    Set errorCells = dataRange.SpecialCells(xlCellTypeConstants, xlErrors)
    Err.Clear
    On Error GoTo 0
    If Not errorCells Is Nothing Then _
        Err.Raise vbObjectError + 1025, "CompactDeleteDataRows", _
                  "内部保管にExcelエラー値があるため、安全な行整理を中止しました: " & _
                  ws.Name & " " & errorCells.Cells(1, 1).Address(False, False)

    sourceData = dataRange.Value2
    If VariantMatrixContainsError(sourceData, sourceRows, lastColumn) Then _
        Err.Raise vbObjectError + 1025, "CompactDeleteDataRows", _
                  "内部保管のExcelエラー値検査を完了できません: " & ws.Name
    For r = 1 To sourceRows
        deleteRow = (StrComp(CellText(sourceData(r, matchColumn)), matchValue, vbTextCompare) = 0)
        If deleteRow And secondColumn > 0 Then
            If deleteWhenSecondEquals Then
                deleteRow = (StrComp(CellText(sourceData(r, secondColumn)), secondValue, vbTextCompare) = 0)
            Else
                deleteRow = (StrComp(CellText(sourceData(r, secondColumn)), secondValue, vbTextCompare) <> 0)
            End If
        End If
        If deleteRow Then
            CompactDeleteDataRows = CompactDeleteDataRows + 1
        Else
            keepCount = keepCount + 1
        End If
    Next r
    If CompactDeleteDataRows = 0 Then Exit Function

    ReDim outputData(1 To sourceRows, 1 To lastColumn)
    For r = 1 To sourceRows
        deleteRow = (StrComp(CellText(sourceData(r, matchColumn)), matchValue, vbTextCompare) = 0)
        If deleteRow And secondColumn > 0 Then
            If deleteWhenSecondEquals Then
                deleteRow = (StrComp(CellText(sourceData(r, secondColumn)), secondValue, vbTextCompare) = 0)
            Else
                deleteRow = (StrComp(CellText(sourceData(r, secondColumn)), secondValue, vbTextCompare) <> 0)
            End If
        End If
        If Not deleteRow Then
            writeRow = writeRow + 1
            For c = 1 To lastColumn
                outputData(writeRow, c) = sourceData(r, c)
            Next c
        End If
    Next r

    On Error GoTo EH
    writeStarted = True
    dataRange.Value2 = outputData
    If Not RangeValue2MatchesMatrixStrict(dataRange, outputData, sourceRows, lastColumn) Then _
        Err.Raise vbObjectError + 1027, "CompactDeleteDataRows", _
                  "行整理後の全行・全列の読戻しが一致しません。"
    lastR = LastDataRowInColumns(ws, 1, lastColumn)
    If lastR >= 2 Then actualCount = lastR - 1 Else actualCount = 0
    If actualCount <> keepCount Then _
        Err.Raise vbObjectError + 1011, "CompactDeleteDataRows", "行整理後の件数が一致しません。"
    If CountCompactDeleteMatches(ws, matchColumn, matchValue, secondColumn, secondValue, _
                                 deleteWhenSecondEquals) <> 0 Then _
        Err.Raise vbObjectError + 1012, "CompactDeleteDataRows", "削除対象行が残っています。"
    Exit Function
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    If writeStarted Then
        On Error Resume Next
        Err.Clear
        dataRange.Value2 = sourceData
        If Err.Number <> 0 Then
            restoreDetail = " / 元データの復元エラー: " & Err.Description
        Else
            restoreMatches = RangeValue2MatchesMatrixStrict(dataRange, sourceData, sourceRows, lastColumn)
            If Not restoreMatches Then _
                restoreDetail = " / 元データの復元読戻しが全行・全列で一致しません。"
        End If
        On Error GoTo 0
    End If
    Err.Raise errorNumber, "CompactDeleteDataRows(" & ws.Name & ")", errorDescription & restoreDetail
End Function

Private Function CountCompactDeleteMatches(ByVal ws As Worksheet, ByVal matchColumn As Long, _
                                           ByVal matchValue As String, ByVal secondColumn As Long, _
                                           ByVal secondValue As String, _
                                           ByVal deleteWhenSecondEquals As Boolean) As Long
    Dim lastR As Long, r As Long, maxColumn As Long, data As Variant, isMatch As Boolean
    If ws Is Nothing Then Exit Function
    maxColumn = CLng(Application.Max(matchColumn, secondColumn))
    lastR = LastDataRowInColumns(ws, 1, maxColumn)
    If lastR < 2 Then Exit Function
    If lastR = 2 And maxColumn = 1 Then
        ReDim data(1 To 1, 1 To 1)
        data(1, 1) = ws.Cells(2, 1).Value2
    Else
        data = ws.Range(ws.Cells(2, 1), ws.Cells(lastR, maxColumn)).Value2
    End If
    For r = 1 To UBound(data, 1)
        isMatch = (StrComp(CellText(data(r, matchColumn)), matchValue, vbTextCompare) = 0)
        If isMatch And secondColumn > 0 Then
            If deleteWhenSecondEquals Then
                isMatch = (StrComp(CellText(data(r, secondColumn)), secondValue, vbTextCompare) = 0)
            Else
                isMatch = (StrComp(CellText(data(r, secondColumn)), secondValue, vbTextCompare) <> 0)
            End If
        End If
        If isMatch Then CountCompactDeleteMatches = CountCompactDeleteMatches + 1
    Next r
End Function

Public Function CompactDeleteDataRowsByDictionary(ByVal ws As Worksheet, ByVal lastColumn As Long, _
                                                  ByVal matchColumn As Long, ByVal matchValues As Object) As Long
    '外部取込のロールバック用。複数の転記回IDを行削除で一件ずつ消さず、一度の配列圧縮で戻す。
    Dim lastR As Long, sourceRows As Long, keepCount As Long, actualCount As Long
    Dim r As Long, c As Long, writeRow As Long
    Dim sourceData As Variant, outputData As Variant, matchData As Variant
    Dim dataRange As Range, formulaCells As Range, errorCells As Range
    Dim writeStarted As Boolean, restoreMatches As Boolean
    Dim errorNumber As Long, errorDescription As String, restoreDetail As String
    If ws Is Nothing Or matchValues Is Nothing Then Exit Function
    If matchValues.Count = 0 Then Exit Function
    If lastColumn < 1 Or matchColumn < 1 Or matchColumn > lastColumn Then _
        Err.Raise vbObjectError + 1013, "CompactDeleteDataRowsByDictionary", "削除条件の列番号が不正です。"
    lastR = LastDataRowInColumns(ws, 1, lastColumn)
    If lastR < 2 Then Exit Function
    sourceRows = lastR - 1
    If sourceRows > MAX_INTERNAL_STORE_DATA_ROWS Then _
        Err.Raise vbObjectError + 1014, "CompactDeleteDataRowsByDictionary", _
                  "内部データが一括整理の実用上限（" & Format$(MAX_INTERNAL_STORE_DATA_ROWS, "#,##0") & _
                  "行）を超えています。案件を分割してください。"
    Set dataRange = ws.Range(ws.Cells(2, 1), ws.Cells(lastR, lastColumn))
    If Not TryFindFirstFormulaCell(dataRange, formulaCells) Then _
        Err.Raise vbObjectError + 1015, "CompactDeleteDataRowsByDictionary", _
                  "内部保管の数式検査に失敗したため、安全な行整理を中止しました: " & ws.Name
    If Not formulaCells Is Nothing Then _
        Err.Raise vbObjectError + 1015, "CompactDeleteDataRowsByDictionary", _
                  "内部保管に数式があるため、安全な行整理を中止しました: " & _
                  ws.Name & " " & formulaCells.Cells(1, 1).Address(False, False)
    On Error Resume Next
    Err.Clear
    Set errorCells = dataRange.SpecialCells(xlCellTypeConstants, xlErrors)
    Err.Clear
    On Error GoTo 0
    If Not errorCells Is Nothing Then _
        Err.Raise vbObjectError + 1026, "CompactDeleteDataRowsByDictionary", _
                  "内部保管にExcelエラー値があるため、安全な行整理を中止しました: " & _
                  ws.Name & " " & errorCells.Cells(1, 1).Address(False, False)
    sourceData = dataRange.Value2
    If VariantMatrixContainsError(sourceData, sourceRows, lastColumn) Then _
        Err.Raise vbObjectError + 1026, "CompactDeleteDataRowsByDictionary", _
                  "内部保管のExcelエラー値検査を完了できません: " & ws.Name
    For r = 1 To sourceRows
        If matchValues.Exists(CellText(sourceData(r, matchColumn))) Then
            CompactDeleteDataRowsByDictionary = CompactDeleteDataRowsByDictionary + 1
        Else
            keepCount = keepCount + 1
        End If
    Next r
    If CompactDeleteDataRowsByDictionary = 0 Then Exit Function
    ReDim outputData(1 To sourceRows, 1 To lastColumn)
    For r = 1 To sourceRows
        If Not matchValues.Exists(CellText(sourceData(r, matchColumn))) Then
            writeRow = writeRow + 1
            For c = 1 To lastColumn
                outputData(writeRow, c) = sourceData(r, c)
            Next c
        End If
    Next r

    On Error GoTo EH
    writeStarted = True
    dataRange.Value2 = outputData
    If Not RangeValue2MatchesMatrixStrict(dataRange, outputData, sourceRows, lastColumn) Then _
        Err.Raise vbObjectError + 1028, "CompactDeleteDataRowsByDictionary", _
                  "行整理後の全行・全列の読戻しが一致しません。"
    lastR = LastDataRowInColumns(ws, 1, lastColumn)
    If lastR >= 2 Then actualCount = lastR - 1 Else actualCount = 0
    If actualCount <> keepCount Then _
        Err.Raise vbObjectError + 1016, "CompactDeleteDataRowsByDictionary", "行整理後の件数が一致しません。"
    If keepCount > 0 Then
        matchData = ws.Range(ws.Cells(2, matchColumn), ws.Cells(lastR, matchColumn)).Value2
        If keepCount = 1 Then
            If matchValues.Exists(CellText(matchData)) Then _
                Err.Raise vbObjectError + 1017, "CompactDeleteDataRowsByDictionary", "削除対象行が残っています。"
        Else
            For r = 1 To UBound(matchData, 1)
                If matchValues.Exists(CellText(matchData(r, 1))) Then _
                    Err.Raise vbObjectError + 1017, "CompactDeleteDataRowsByDictionary", "削除対象行が残っています。"
            Next r
        End If
    End If
    Exit Function
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    If writeStarted Then
        On Error Resume Next
        Err.Clear
        dataRange.Value2 = sourceData
        If Err.Number <> 0 Then
            restoreDetail = " / 元データの復元エラー: " & Err.Description
        Else
            restoreMatches = RangeValue2MatchesMatrixStrict(dataRange, sourceData, sourceRows, lastColumn)
            If Not restoreMatches Then _
                restoreDetail = " / 元データの復元読戻しが全行・全列で一致しません。"
        End If
        On Error GoTo 0
    End If
    Err.Raise errorNumber, "CompactDeleteDataRowsByDictionary(" & ws.Name & ")", _
              errorDescription & restoreDetail
End Function

Public Sub CapBalanceCollections(ByRef labels As Collection, ByRef dates As Collection, ByVal maxItems As Long)
    Dim newLabels As Collection
    Dim newDates As Collection
    Dim selected As Object
    Dim inheritDate As Variant
    Dim inheritIndex As Long
    Dim i As Long
    If labels Is Nothing Or dates Is Nothing Then Exit Sub
    If maxItems <= 0 Then Exit Sub
    If labels.Count <= maxItems Then Exit Sub

    '表示上限を超えた場合は、古い時点から機械的に切るのではなく、
    '相続開始日時点（設定済みの場合）と直近の年末時点を優先して残す。
    Set selected = CreateObject("Scripting.Dictionary")
    inheritDate = GetCfgDateValue(ROW_CFG_INHERITANCE_DATE)
    If IsDate(inheritDate) Then
        For i = 1 To dates.Count
            If IsDate(dates(i)) Then
                If CLng(CDate(dates(i))) = CLng(CDate(inheritDate)) Then
                    inheritIndex = i
                    Exit For
                End If
            End If
        Next i
        If inheritIndex > 0 Then selected(CStr(inheritIndex)) = True
    End If
    For i = dates.Count To 1 Step -1
        If selected.Count >= maxItems Then Exit For
        selected(CStr(i)) = True
    Next i

    Set newLabels = New Collection
    Set newDates = New Collection
    For i = 1 To labels.Count
        If selected.Exists(CStr(i)) Then
            newLabels.Add labels(i)
            newDates.Add dates(i)
        End If
    Next i
    Set labels = newLabels
    Set dates = newDates
End Sub

Public Function BalanceInputLabelDisplay(ByVal labelText As String) As String
    Dim s As String
    s = CellText(labelText)
    s = Replace(s, "相続開始日時点残高（", "相続開始日時点" & vbLf & "残高（")
    s = Replace(s, "年末・相続開始日時点残高（", "年末・相続開始日時点" & vbLf & "残高（")
    BalanceInputLabelDisplay = s
End Function

Public Function BalanceTekiyoLabel(ByVal labelText As String) As String
    '資金操作表の摘要欄用。日付欄に基準日があるため、摘要欄には具体日付を出さない。
    Dim s As String
    Dim p As Long
    s = CellText(labelText)
    s = Replace(s, vbCrLf, "")
    s = Replace(s, vbCr, "")
    s = Replace(s, vbLf, "")
    p = InStr(1, s, "（", vbTextCompare)
    If p > 0 And InStr(1, s, "残高", vbTextCompare) > 0 Then s = Left$(s, p - 1)
    BalanceTekiyoLabel = s
End Function


Public Sub ApplyReadablePrintSettings(ByVal ws As Worksheet, _
                                      Optional ByVal titleRows As String = "", _
                                      Optional ByVal pagesWide As Long = 1, _
                                      Optional ByVal titleColumns As String = "", _
                                      Optional ByVal strictVerification As Boolean = False)
    '主要帳票はA4横。列数が多い残高推移表だけは、文字が潰れない範囲で横2～3枚へ分ける。
    '通常レイアウトではプリンタ未設定環境を止めず、印刷直前だけstrictに読み戻す。
    Dim detailText As String
    Dim errorNumber As Long, errorDescription As String
    If ws Is Nothing Then Exit Sub
    If pagesWide < 1 Then pagesWide = 1
    If pagesWide > 3 Then pagesWide = 3
    On Error GoTo EH
    With ws.PageSetup
        .PaperSize = xlPaperA4
        .Orientation = xlLandscape
        .Zoom = False
        .FitToPagesWide = pagesWide
        .FitToPagesTall = False
        .Order = xlDownThenOver
        '色だけに意味を持たせず、白黒プリンタでも見出し・罫線・列名で判読できる。
        .BlackAndWhite = True
        .Draft = False
        .PrintGridlines = False
        .PrintHeadings = False
        .CenterHorizontally = False
        .CenterVertically = False
        .LeftMargin = Application.InchesToPoints(0.25)
        .RightMargin = Application.InchesToPoints(0.25)
        .TopMargin = Application.InchesToPoints(0.35)
        .BottomMargin = Application.InchesToPoints(0.35)
        If Len(titleRows) > 0 Then
            .PrintTitleRows = titleRows
        Else
            .PrintTitleRows = ""
        End If
        If Len(titleColumns) > 0 Then
            .PrintTitleColumns = titleColumns
        Else
            .PrintTitleColumns = ""
        End If
        .CenterFooter = "&P / &N"
    End With
    If strictVerification Then
        If Not ReadablePrintSettingsMatch(ws, titleRows, pagesWide, titleColumns, detailText) Then _
            Err.Raise vbObjectError + 1110, "ApplyReadablePrintSettings", detailText
    End If
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    If strictVerification Then _
        Err.Raise errorNumber, "ApplyReadablePrintSettings(" & ws.Name & ")", errorDescription
    Err.Clear
End Sub

Public Function ReadablePrintSettingsMatch(ByVal ws As Worksheet, _
                                           Optional ByVal titleRows As String = "", _
                                           Optional ByVal pagesWide As Long = 1, _
                                           Optional ByVal titleColumns As String = "", _
                                           Optional ByRef detailText As String = "") As Boolean
    Dim actualRows As String, actualColumns As String
    On Error GoTo EH
    If ws Is Nothing Then
        detailText = "印刷設定の対象シートがありません。"
        Exit Function
    End If
    With ws.PageSetup
        If .PaperSize <> xlPaperA4 Then detailText = "用紙サイズがA4ではありません。": Exit Function
        If .Orientation <> xlLandscape Then detailText = "印刷方向が横ではありません。": Exit Function
        If .Zoom <> False Then detailText = "印刷倍率が自動調整になっていません。": Exit Function
        If CLng(.FitToPagesWide) <> pagesWide Then detailText = "横方向の印刷ページ数が設計値と異なります。": Exit Function
        If .FitToPagesTall <> False Then detailText = "縦方向が1ページへ圧縮されています。": Exit Function
        If .Order <> xlDownThenOver Then detailText = "印刷順序が縦方向優先ではありません。": Exit Function
        If Not .BlackAndWhite Then detailText = "白黒印刷向けの判読設定が無効です。": Exit Function
        If .Draft Then detailText = "下書き品質で印刷されます。": Exit Function
        If .PrintGridlines Then detailText = "印刷時にグリッド線が表示されます。": Exit Function
        If .PrintHeadings Then detailText = "印刷時に行列番号が表示されます。": Exit Function
        If .CenterHorizontally Then detailText = "横方向の中央配置が有効です。": Exit Function
        If .CenterVertically Then detailText = "縦方向の中央配置が有効です。": Exit Function
        If Abs(CDbl(.LeftMargin) - Application.InchesToPoints(0.25)) > 0.75 Then _
            detailText = "左余白が設計値と異なります。": Exit Function
        If Abs(CDbl(.RightMargin) - Application.InchesToPoints(0.25)) > 0.75 Then _
            detailText = "右余白が設計値と異なります。": Exit Function
        If Abs(CDbl(.TopMargin) - Application.InchesToPoints(0.35)) > 0.75 Then _
            detailText = "上余白が設計値と異なります。": Exit Function
        If Abs(CDbl(.BottomMargin) - Application.InchesToPoints(0.35)) > 0.75 Then _
            detailText = "下余白が設計値と異なります。": Exit Function
        If StrComp(CellText(.CenterFooter), "&P / &N", vbBinaryCompare) <> 0 Then _
            detailText = "ページ番号のフッターが設計値と異なります。": Exit Function
        actualRows = NormalizePrintTitleAddress(CellText(.PrintTitleRows))
        actualColumns = NormalizePrintTitleAddress(CellText(.PrintTitleColumns))
    End With
    If StrComp(actualRows, NormalizePrintTitleAddress(titleRows), vbTextCompare) <> 0 Then
        detailText = "印刷タイトル行が設計値と異なります。"
        Exit Function
    End If
    If StrComp(actualColumns, NormalizePrintTitleAddress(titleColumns), vbTextCompare) <> 0 Then
        detailText = "印刷タイトル列が設計値と異なります。"
        Exit Function
    End If
    ReadablePrintSettingsMatch = True
    Exit Function
EH:
    detailText = "印刷設定を読み取れません: Err " & CStr(Err.Number) & ": " & Err.Description
    Err.Clear
End Function

Private Function NormalizePrintTitleAddress(ByVal valueIn As String) As String
    Dim resultText As String, bangPosition As Long
    resultText = Trim$(valueIn)
    bangPosition = InStrRev(resultText, "!")
    If bangPosition > 0 Then resultText = Mid$(resultText, bangPosition + 1)
    resultText = Replace(resultText, "=", "")
    resultText = Replace(resultText, "'", "")
    resultText = Replace(resultText, " ", "")
    NormalizePrintTitleAddress = UCase$(resultText)
End Function

Public Sub ApplyPrintAreaVerified(ByVal ws As Worksheet, ByVal printRange As Range, _
                                  Optional ByVal strictVerification As Boolean = False)
    Dim expectedAddress As String, actualAddress As String
    Dim errorNumber As Long, errorDescription As String
    On Error GoTo EH
    If ws Is Nothing Or printRange Is Nothing Then Exit Sub
    expectedAddress = printRange.Address(True, True, xlA1, False)
    ws.PageSetup.PrintArea = expectedAddress
    actualAddress = NormalizePrintTitleAddress(CellText(ws.PageSetup.PrintArea))
    If strictVerification Then
        If StrComp(actualAddress, NormalizePrintTitleAddress(expectedAddress), vbTextCompare) <> 0 Then _
            Err.Raise vbObjectError + 1111, "ApplyPrintAreaVerified", _
                      "印刷範囲が設計値と一致しません: " & expectedAddress
    End If
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    If strictVerification Then _
        Err.Raise errorNumber, "ApplyPrintAreaVerified(" & ws.Name & ")", errorDescription
    Err.Clear
End Sub

Public Function PrintAreaMatches(ByVal ws As Worksheet, ByVal expectedRange As Range, _
                                 Optional ByRef detailText As String = "") As Boolean
    Dim actualAddress As String, expectedAddress As String
    On Error GoTo EH
    If ws Is Nothing Or expectedRange Is Nothing Then
        detailText = "印刷範囲の検査対象がありません。"
        Exit Function
    End If
    actualAddress = NormalizePrintTitleAddress(CellText(ws.PageSetup.PrintArea))
    expectedAddress = NormalizePrintTitleAddress(expectedRange.Address(True, True, xlA1, False))
    If StrComp(actualAddress, expectedAddress, vbTextCompare) <> 0 Then
        detailText = "印刷範囲が設計値と異なります: " & CellText(ws.PageSetup.PrintArea)
        Exit Function
    End If
    PrintAreaMatches = True
    Exit Function
EH:
    detailText = "印刷範囲を読み取れません: Err " & CStr(Err.Number) & ": " & Err.Description
    Err.Clear
End Function

Public Function ReadableOutputRowHeight(ByVal textValue As String, _
                                        Optional ByVal minimumHeight As Double = 30, _
                                        Optional ByVal maximumHeight As Double = 120, _
                                        Optional ByVal displayUnitsPerLine As Long = 32) As Double
    '日本語の全角文字を半角文字と同じ1文字で数えると、見かけの行数を過少評価する。
    '表示幅単位で折返し行数を見積もり、摘要欄の長文を固定高で切らない。
    Dim logicalLines As Long
    Dim estimatedHeight As Double
    logicalLines = ReadableTextLineCount(textValue, displayUnitsPerLine)
    If logicalLines < 1 Then logicalLines = 1
    estimatedHeight = 15# * CDbl(logicalLines)
    If estimatedHeight < minimumHeight Then estimatedHeight = minimumHeight
    If estimatedHeight > maximumHeight Then estimatedHeight = maximumHeight
    ReadableOutputRowHeight = estimatedHeight
End Function

Public Function ReadableTextLineCount(ByVal textValue As String, _
                                      Optional ByVal displayUnitsPerLine As Long = 32) As Long
    Dim normalizedText As String, lines As Variant, item As Variant
    Dim units As Long, wrappedLines As Long
    If displayUnitsPerLine < 1 Then displayUnitsPerLine = 1
    normalizedText = Replace(textValue, vbCrLf, vbLf)
    normalizedText = Replace(normalizedText, vbCr, vbLf)
    lines = Split(normalizedText, vbLf)
    For Each item In lines
        units = TextDisplayUnits(CStr(item))
        If units < 1 Then
            wrappedLines = wrappedLines + 1
        Else
            wrappedLines = wrappedLines + _
                           ((units + displayUnitsPerLine - 1) \ displayUnitsPerLine)
        End If
    Next item
    If wrappedLines < 1 Then wrappedLines = 1
    ReadableTextLineCount = wrappedLines
End Function

Public Function TextDisplayUnits(ByVal textValue As String) As Long
    'ASCII・半角カナは1、その他の全角文字は2として概算する。
    Dim i As Long, codePoint As Long
    For i = 1 To Len(textValue)
        codePoint = AscW(Mid$(textValue, i, 1))
        If codePoint < 0 Then codePoint = codePoint + 65536
        If (codePoint >= 32 And codePoint <= 126) Or _
           (codePoint >= 65377 And codePoint <= 65439) Then
            TextDisplayUnits = TextDisplayUnits + 1
        Else
            TextDisplayUnits = TextDisplayUnits + 2
        End If
    Next i
End Function

Public Sub FormatCashOperationOutputLayout(ByVal ws As Worksheet)
    Dim lastR As Long
    Dim rng As Range
    Dim r As Long, recordType As String, tekiyoText As String
    Dim recordTypes As Variant, tekiyoValues As Variant
    Dim errorNumber As Long, errorDescription As String
    If ws Is Nothing Then Exit Sub
    On Error GoTo EH
    lastR = LastUsedRowInSheet(ws)
    If lastR < 1 Then lastR = 1

    Set rng = ws.Range("A1:M" & lastR)
    With rng
        .Font.Name = "Yu Gothic UI"
        .Font.Size = 11.5
        .Font.Color = RGB(15, 23, 42)
        .Font.Bold = False
        .VerticalAlignment = xlCenter
        .Interior.Pattern = xlSolid
        .Interior.Color = RGB(255, 255, 255)
        .Borders.LineStyle = xlContinuous
        .Borders.Color = RGB(226, 232, 240)
    End With

    FormatOutputHeader ws.Range("A1:M1")
    ws.Rows(1).RowHeight = 34

    ws.Columns("A:A").ColumnWidth = 20
    ws.Columns("B:B").ColumnWidth = 20
    ws.Columns("C:C").ColumnWidth = 18
    ws.Columns("D:D").ColumnWidth = 12
    ws.Columns("E:E").ColumnWidth = 17
    ws.Columns("F:F").ColumnWidth = 19
    ws.Columns("G:G").ColumnWidth = 11
    ws.Columns("H:I").ColumnWidth = 14
    ws.Columns("J:J").ColumnWidth = 20
    ws.Columns("K:K").ColumnWidth = 11
    ws.Columns("L:L").ColumnWidth = 26
    ws.Columns("M:M").ColumnWidth = 17

    ws.Range("A1:G" & CStr(lastR)).HorizontalAlignment = xlCenter
    ws.Range("J1:K" & CStr(lastR)).HorizontalAlignment = xlCenter
    ws.Range("H1:I" & CStr(lastR)).HorizontalAlignment = xlRight
    ws.Range("L1:L" & CStr(lastR)).HorizontalAlignment = xlLeft
    ws.Range("M1:M" & CStr(lastR)).HorizontalAlignment = xlRight
    ws.Range("A1:M" & CStr(lastR)).VerticalAlignment = xlCenter
    ws.Range("L1:M" & CStr(lastR)).WrapText = True

    '列単位の配置設定はヘッダーの中央揃えを上書きするため、最後にヘッダーだけ再適用する。
    FormatOutputHeader ws.Range("A1:M1")
    With ws.Range("A1:M1")
        .HorizontalAlignment = xlCenter
        .VerticalAlignment = xlCenter
        .WrapText = False
    End With

    ws.Range("F1:F" & CStr(lastR)).NumberFormatLocal = "yyyy/m/d"
    ws.Range("G1:G" & CStr(lastR)).NumberFormatLocal = "hh:mm"
    ws.Range("H1:I" & CStr(lastR)).NumberFormatLocal = "#,##0.########"
    ws.Range("M1:M" & CStr(lastR)).NumberFormatLocal = "#,##0.########"

    If lastR >= 2 Then
        ws.Rows("2:" & lastR).RowHeight = 30
        If lastR = 2 Then
            ReDim recordTypes(1 To 1, 1 To 1)
            ReDim tekiyoValues(1 To 1, 1 To 1)
            recordTypes(1, 1) = ws.Cells(2, OUT_COL_RECORD_TYPE).Value2
            tekiyoValues(1, 1) = ws.Cells(2, OUT_COL_TEKIYO).Value2
        Else
            recordTypes = ws.Range(ws.Cells(2, OUT_COL_RECORD_TYPE), ws.Cells(lastR, OUT_COL_RECORD_TYPE)).Value2
            tekiyoValues = ws.Range(ws.Cells(2, OUT_COL_TEKIYO), ws.Cells(lastR, OUT_COL_TEKIYO)).Value2
        End If
        '残高行は摘要欄も中央にし、行全体を見やすくする。
        For r = 2 To lastR
            recordType = CellText(recordTypes(r - 1, 1))
            tekiyoText = CellText(tekiyoValues(r - 1, 1))
            If recordType = RECORD_BALANCE Or (Len(recordType) = 0 And InStr(1, tekiyoText, "残高", vbTextCompare) > 0) Then
                ws.Cells(r, OUT_COL_TEKIYO).Value = BalanceTekiyoLabel(tekiyoText)
                ws.Cells(r, OUT_COL_TEKIYO).HorizontalAlignment = xlCenter
                ws.Cells(r, OUT_COL_OTHER).HorizontalAlignment = xlRight
                ws.Rows(r).RowHeight = Application.Max(30, ReadableOutputRowHeight(tekiyoText, 30, 120))
                ws.Range("A" & r & ":M" & r).Interior.Color = RGB(220, 252, 231)
                ws.Range("A" & r & ":M" & r).Font.Color = RGB(22, 101, 52)
            ElseIf recordType = RECORD_INHERITANCE Or tekiyoText = "相続開始日" Then
                ws.Range("A" & r & ":M" & r).Interior.Color = RGB(254, 243, 199)
                ws.Range("A" & r & ":M" & r).Font.Color = RGB(146, 64, 14)
                ws.Range("A" & r & ":M" & r).Font.Bold = True
                '日付欄は太字だと幅不足で ##### になりやすい。行は色で強調し、日付セルだけ通常太さに戻す。
                ws.Cells(r, OUT_COL_DATE).Font.Bold = False
                ws.Cells(r, OUT_COL_DATE).HorizontalAlignment = xlCenter
                ws.Cells(r, OUT_COL_TEKIYO).HorizontalAlignment = xlCenter
                ws.Rows(r).RowHeight = 32
            ElseIf recordType = RECORD_OPEN Or recordType = RECORD_CLOSE Or _
                   tekiyoText = "口座開設日" Or tekiyoText = "口座解約日" Then
                ws.Range("A" & r & ":M" & r).Interior.Color = RGB(219, 234, 254)
                ws.Range("A" & r & ":M" & r).Font.Color = RGB(30, 64, 175)
            ElseIf Len(tekiyoText) > 32 Or InStr(1, tekiyoText, vbLf, vbBinaryCompare) > 0 Or _
                   InStr(1, tekiyoText, vbCr, vbBinaryCompare) > 0 Then
                ws.Rows(r).RowHeight = ReadableOutputRowHeight(tekiyoText, 30, 120)
            End If
        Next r
    End If

    ws.ScrollArea = "A1:M" & CStr(Application.Max(50, lastR + 20))
    ApplyPrintAreaVerified ws, rng
    ApplyReadablePrintSettings ws, "$1:$1"
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    Err.Raise errorNumber, "FormatCashOperationOutputLayout", errorDescription
End Sub


Public Sub FormatBalanceTransitionOutputLayout(ByVal ws As Worksheet)
    Dim lastR As Long, lastC As Long
    Dim r As Long, c As Long
    Dim fullRange As Range, rowRange As Range
    Dim isDataRow As Boolean, firstText As String
    Dim layoutData As Variant, rowKinds() As Byte
    Dim largeLayout As Boolean
    Dim errorNumber As Long, errorDescription As String
    Dim printPagesWide As Long, balancePointCount As Long
    If ws Is Nothing Then Exit Sub
    On Error GoTo EH

    lastR = LastUsedRowInSheet(ws)
    lastC = LastUsedColumnInSheet(ws, lastR)
    If lastR < 1 Then Exit Sub
    If lastC < 7 Then lastC = 7

    Set fullRange = ws.Range(ws.Cells(1, 1), ws.Cells(lastR, lastC))
    layoutData = fullRange.Value2
    ReDim rowKinds(1 To lastR)
    For r = 1 To lastR
        firstText = CellText(layoutData(r, 1))
        If Left$(firstText, 3) = "氏名:" Or Left$(firstText, 3) = "氏名：" Then
            rowKinds(r) = 1
        ElseIf firstText = "銀行名" Then
            rowKinds(r) = 2
        ElseIf firstText = "未確認口座数" Then
            rowKinds(r) = 3
        ElseIf firstText = "合計" Then
            rowKinds(r) = 4
        ElseIf firstText = "前時点比" Then
            rowKinds(r) = 5
        Else
            isDataRow = False
            For c = 1 To lastC
                If HasText(layoutData(r, c)) Then isDataRow = True: Exit For
            Next c
            If isDataRow Then rowKinds(r) = 6
        End If
    Next r
    largeLayout = (lastR > MAX_DETAILED_AUTOFIT_ROWS)
    With fullRange
        .Font.Name = "Yu Gothic UI"
        .Font.Size = 11.5
        .Font.Color = RGB(30, 41, 59)
        .Font.Bold = False
        .VerticalAlignment = xlCenter
        .Interior.Pattern = xlSolid
        .Interior.Color = RGB(255, 255, 255)
        .Borders.LineStyle = xlNone
    End With

    'タイトルは、表本体と混ざらないよう下線だけで区切る。
    With ws.Range(ws.Cells(1, 1), ws.Cells(1, lastC))
        .Interior.Color = RGB(248, 250, 252)
        .Borders(xlEdgeBottom).LineStyle = xlContinuous
        .Borders(xlEdgeBottom).Color = RGB(59, 130, 246)
        .Borders(xlEdgeBottom).Weight = xlMedium
    End With
    With ws.Cells(1, 1)
        .Font.Bold = True
        .Font.Size = 17
        .Font.Color = RGB(30, 64, 175)
        .HorizontalAlignment = xlLeft
    End With
    ws.Rows(1).RowHeight = 34

    If largeLayout Then
        FormatLargeBalanceRows ws, lastR, lastC, rowKinds, layoutData
    Else
        For r = 2 To lastR
            Set rowRange = ws.Range(ws.Cells(r, 1), ws.Cells(r, lastC))

            If rowKinds(r) = 1 Then
                With rowRange
                .Interior.Color = RGB(239, 246, 255)
                .Font.Bold = True
                .Font.Color = RGB(30, 64, 175)
                .Borders(xlEdgeTop).LineStyle = xlContinuous
                .Borders(xlEdgeTop).Color = RGB(147, 197, 253)
                .Borders(xlEdgeTop).Weight = xlMedium
                .Borders(xlEdgeBottom).LineStyle = xlContinuous
                .Borders(xlEdgeBottom).Color = RGB(191, 219, 254)
                .Borders(xlEdgeBottom).Weight = xlMedium
                End With
                ws.Cells(r, 1).HorizontalAlignment = xlLeft
                If ws.Rows(r).RowHeight < 34 Then ws.Rows(r).RowHeight = 34

            ElseIf rowKinds(r) = 2 Then
                With rowRange
                .Interior.Color = RGB(30, 64, 175)
                .Font.Bold = True
                .Font.Color = RGB(255, 255, 255)
                .HorizontalAlignment = xlCenter
                .VerticalAlignment = xlCenter
                .WrapText = True
                .ShrinkToFit = False
                .Borders.LineStyle = xlContinuous
                .Borders.Color = RGB(30, 64, 175)
                .Borders.Weight = xlThin
                .Borders(xlEdgeTop).Weight = xlMedium
                .Borders(xlEdgeBottom).Weight = xlMedium
                End With
                '相続開始日時点残高など2行表示の見出しが隠れないよう高めに固定。
                ws.Rows(r).RowHeight = 72

            ElseIf rowKinds(r) = 3 Then
                With rowRange
                .Interior.Color = RGB(254, 249, 195)
                .Font.Bold = True
                .Font.Color = RGB(133, 77, 14)
                .Borders.LineStyle = xlContinuous
                .Borders.Color = RGB(253, 224, 71)
                .Borders.Weight = xlThin
                End With
                If ws.Rows(r).RowHeight < 30 Then ws.Rows(r).RowHeight = 30

            ElseIf rowKinds(r) = 4 Then
                With rowRange
                .Interior.Color = RGB(220, 252, 231)
                .Font.Bold = True
                .Font.Color = RGB(22, 101, 52)
                .Borders.LineStyle = xlContinuous
                .Borders.Color = RGB(187, 247, 208)
                .Borders.Weight = xlThin
                .Borders(xlEdgeTop).Color = RGB(34, 197, 94)
                .Borders(xlEdgeTop).Weight = xlMedium
                End With
                If ws.Rows(r).RowHeight < 32 Then ws.Rows(r).RowHeight = 32

            ElseIf rowKinds(r) = 5 Then
                With rowRange
                .Interior.Color = RGB(241, 245, 249)
                .Font.Bold = True
                .Font.Color = RGB(51, 65, 85)
                .Borders.LineStyle = xlContinuous
                .Borders.Color = RGB(226, 232, 240)
                .Borders.Weight = xlThin
                .Borders(xlEdgeBottom).Color = RGB(148, 163, 184)
                .Borders(xlEdgeBottom).Weight = xlMedium
                End With
                If ws.Rows(r).RowHeight < 31 Then ws.Rows(r).RowHeight = 31

            Else
                If rowKinds(r) = 6 Then
                    If r Mod 2 = 0 Then
                        rowRange.Interior.Color = RGB(255, 255, 255)
                    Else
                        rowRange.Interior.Color = RGB(248, 250, 252)
                    End If
                    With rowRange.Borders
                        .LineStyle = xlContinuous
                        .Color = RGB(226, 232, 240)
                        .Weight = xlThin
                    End With
                    FormatNonexistentBalanceCells ws, r, layoutData, 7, lastC - 1
                    If ws.Rows(r).RowHeight < 30 Then ws.Rows(r).RowHeight = 30
                Else
                    '人物と人物の間の空白行には罫線を一切残さない。
                    rowRange.Borders.LineStyle = xlNone
                    rowRange.Interior.Color = RGB(255, 255, 255)
                    ws.Rows(r).RowHeight = 12
                End If
            End If
        Next r
    End If

    '列幅・配置。口座情報、残高、メモの3ブロックが分かるようにする。
    ws.Columns("A:A").ColumnWidth = 22
    ws.Columns("B:B").ColumnWidth = 22
    ws.Columns("C:C").ColumnWidth = 14
    ws.Columns("D:D").ColumnWidth = 18
    ws.Columns("E:F").ColumnWidth = 16
    For c = 7 To lastC - 1
        ws.Columns(c).ColumnWidth = 22
        ws.Range(ws.Cells(1, c), ws.Cells(lastR, c)).NumberFormatLocal = "#,##0.########"
        ws.Range(ws.Cells(1, c), ws.Cells(lastR, c)).WrapText = True
    Next c
    ws.Columns(lastC).ColumnWidth = 48

    ws.Range(ws.Cells(1, 1), ws.Cells(lastR, lastC)).VerticalAlignment = xlCenter
    ws.Range(ws.Cells(1, 1), ws.Cells(lastR, 6)).HorizontalAlignment = xlCenter
    If lastC > 7 Then ws.Range(ws.Cells(1, 7), ws.Cells(lastR, lastC - 1)).HorizontalAlignment = xlRight
    ws.Range(ws.Cells(1, lastC), ws.Cells(lastR, lastC)).HorizontalAlignment = xlLeft
    ws.Range(ws.Cells(1, lastC), ws.Cells(lastR, lastC)).WrapText = True
    ws.Range(ws.Cells(1, 1), ws.Cells(lastR, 6)).NumberFormatLocal = "@"
    ws.Range(ws.Cells(1, 5), ws.Cells(lastR, 6)).NumberFormatLocal = "yyyy/m/d"

    '縦区切り線はシート全体には引かない。
    '各人物ブロックのヘッダー行から前時点比行までだけに適用し、空白行には残さない。
    If Not largeLayout Then ApplyBalanceTransitionBlockBorders ws, lastR, lastC, rowKinds

    'その他欄の長文が見切れないよう、列幅確保後にAutoFit。ただし大きくなりすぎないよう上限を設ける。
    If Not largeLayout Then
        ws.Range(ws.Cells(2, 1), ws.Cells(lastR, lastC)).Rows.AutoFit
        For r = 2 To lastR
            If rowKinds(r) = 2 Then
                ws.Rows(r).RowHeight = 72
            ElseIf rowKinds(r) = 1 Then
                If ws.Rows(r).RowHeight < 34 Then ws.Rows(r).RowHeight = 34
            ElseIf rowKinds(r) = 4 Then
                If ws.Rows(r).RowHeight < 32 Then ws.Rows(r).RowHeight = 32
            ElseIf rowKinds(r) = 5 Then
                If ws.Rows(r).RowHeight < 31 Then ws.Rows(r).RowHeight = 31
            ElseIf rowKinds(r) = 0 Then
                ws.Rows(r).RowHeight = 12
                ws.Range(ws.Cells(r, 1), ws.Cells(r, lastC)).Borders.LineStyle = xlNone
            ElseIf ws.Rows(r).RowHeight < 30 Then
                ws.Rows(r).RowHeight = 30
            End If
            If ws.Rows(r).RowHeight > 130 Then ws.Rows(r).RowHeight = 130
        Next r
    End If

    ws.Cells(1, 1).HorizontalAlignment = xlLeft

    'ヘッダー行は列配置・AutoFitの後に再適用。列単位設定に負けないようにする。
    If largeLayout Then
        ReapplyLargeBalanceSpecialAlignment ws, lastR, lastC, rowKinds
    Else
        For r = 2 To lastR
            If rowKinds(r) = 1 Then ws.Cells(r, 1).HorizontalAlignment = xlLeft
            If rowKinds(r) = 2 Then
                With ws.Range(ws.Cells(r, 1), ws.Cells(r, lastC))
                    .HorizontalAlignment = xlCenter
                    .VerticalAlignment = xlCenter
                    .WrapText = True
                    .ShrinkToFit = False
                End With
                ws.Rows(r).RowHeight = 72
            End If
        Next r
    End If

    ws.ScrollArea = "A1:" & ExcelColumnLetter(lastC) & _
                    CStr(Application.Max(50, lastR + 20))

    '残高6～8時点を1枚へ押し込まず、本文11.5ptを保ったまま横分割する。
    'A:Fの口座情報は各横ページへ繰り返し、先頭タイトル行も各縦ページへ反復する。
    balancePointCount = Application.Max(0, lastC - 7)
    If balancePointCount <= 4 Then
        printPagesWide = 1
    ElseIf balancePointCount <= 8 Then
        printPagesWide = 2
    Else
        printPagesWide = 3
    End If
    ApplyPrintAreaVerified ws, fullRange
    ApplyReadablePrintSettings ws, "$1:$1", printPagesWide, "$A:$F"
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    Err.Raise errorNumber, "FormatBalanceTransitionOutputLayout", errorDescription
End Sub

Private Sub FormatLargeBalanceRows(ByVal ws As Worksheet, ByVal lastR As Long, _
                                   ByVal lastC As Long, ByRef rowKinds() As Byte, _
                                   ByRef layoutData As Variant)
    '大量行で行単位のCOM呼出とAutoFitを繰り返すと実用時間を超えるため、
    '同じ行種別を短い複数範囲へ束ねて書式設定する。
    Dim addresses(0 To 9) As String
    Dim counts(0 To 9) As Long
    Dim r As Long, c As Long, styleKind As Long, i As Long
    Dim rowAddress As String, cellAddress As String, lastColumnLetter As String
    Dim styleMissingCells As Boolean
    If ws Is Nothing Or lastR < 2 Or lastC < 1 Then Exit Sub
    lastColumnLetter = ExcelColumnLetter(lastC)
    styleMissingCells = (CDbl(lastR) * CDbl(lastC) <= MAX_READABILITY_SCAN_CELLS)

    For r = 2 To lastR
        styleKind = CLng(rowKinds(r))
        If styleKind = 6 Then
            If r Mod 2 = 0 Then styleKind = 7 Else styleKind = 8
        End If
        rowAddress = "A" & CStr(r) & ":" & lastColumnLetter & CStr(r)
        QueueBalanceStyleAddress ws, addresses, counts, styleKind, rowAddress

        If styleMissingCells And rowKinds(r) = 6 Then
            For c = 7 To lastC - 1
                If CellText(layoutData(r, c)) = "-" Then
                    cellAddress = ExcelColumnLetter(c) & CStr(r)
                    QueueBalanceStyleAddress ws, addresses, counts, 9, cellAddress
                End If
            Next c
        End If
    Next r
    For i = LBound(addresses) To UBound(addresses)
        FlushBalanceStyleAddress ws, addresses, counts, i
    Next i
End Sub

Private Sub QueueBalanceStyleAddress(ByVal ws As Worksheet, ByRef addresses() As String, _
                                     ByRef counts() As Long, ByVal styleKind As Long, _
                                     ByVal rangeAddress As String)
    If styleKind < LBound(addresses) Or styleKind > UBound(addresses) Then Exit Sub
    If Len(addresses(styleKind)) > 0 Then addresses(styleKind) = addresses(styleKind) & ","
    addresses(styleKind) = addresses(styleKind) & rangeAddress
    counts(styleKind) = counts(styleKind) + 1
    'Range文字列の環境差を避け、200文字弱で確実にフラッシュする。
    If counts(styleKind) >= 40 Or Len(addresses(styleKind)) >= 180 Then _
        FlushBalanceStyleAddress ws, addresses, counts, styleKind
End Sub

Private Sub FlushBalanceStyleAddress(ByVal ws As Worksheet, ByRef addresses() As String, _
                                     ByRef counts() As Long, ByVal styleKind As Long)
    Dim target As Range
    If ws Is Nothing Then Exit Sub
    If Len(addresses(styleKind)) = 0 Then Exit Sub
    Set target = ws.Range(addresses(styleKind))
    Select Case styleKind
        Case 0
            target.Interior.Color = RGB(255, 255, 255)
            target.Borders.LineStyle = xlNone
            target.EntireRow.RowHeight = 12
        Case 1
            target.Interior.Color = RGB(239, 246, 255)
            target.Font.Bold = True
            target.Font.Color = RGB(30, 64, 175)
            target.Borders.LineStyle = xlContinuous
            target.Borders.Color = RGB(191, 219, 254)
            target.Borders.Weight = xlThin
            target.EntireRow.RowHeight = 34
        Case 2
            target.Interior.Color = RGB(30, 64, 175)
            target.Font.Bold = True
            target.Font.Color = RGB(255, 255, 255)
            target.HorizontalAlignment = xlCenter
            target.VerticalAlignment = xlCenter
            target.WrapText = True
            target.ShrinkToFit = False
            target.Borders.LineStyle = xlContinuous
            target.Borders.Color = RGB(30, 64, 175)
            target.Borders.Weight = xlThin
            target.EntireRow.RowHeight = 72
        Case 3
            target.Interior.Color = RGB(254, 249, 195)
            target.Font.Bold = True
            target.Font.Color = RGB(133, 77, 14)
            target.Borders.LineStyle = xlContinuous
            target.Borders.Color = RGB(253, 224, 71)
            target.Borders.Weight = xlThin
            target.EntireRow.RowHeight = 30
        Case 4
            target.Interior.Color = RGB(220, 252, 231)
            target.Font.Bold = True
            target.Font.Color = RGB(22, 101, 52)
            target.Borders.LineStyle = xlContinuous
            target.Borders.Color = RGB(187, 247, 208)
            target.Borders.Weight = xlThin
            target.EntireRow.RowHeight = 32
        Case 5
            target.Interior.Color = RGB(241, 245, 249)
            target.Font.Bold = True
            target.Font.Color = RGB(51, 65, 85)
            target.Borders.LineStyle = xlContinuous
            target.Borders.Color = RGB(226, 232, 240)
            target.Borders.Weight = xlThin
            target.EntireRow.RowHeight = 31
        Case 7, 8
            If styleKind = 7 Then
                target.Interior.Color = RGB(255, 255, 255)
            Else
                target.Interior.Color = RGB(248, 250, 252)
            End If
            target.Borders.LineStyle = xlContinuous
            target.Borders.Color = RGB(226, 232, 240)
            target.Borders.Weight = xlThin
            target.EntireRow.RowHeight = 30
        Case 9
            target.Interior.Color = RGB(243, 244, 246)
            target.Font.Color = RGB(71, 85, 105)
            target.HorizontalAlignment = xlCenter
            target.NumberFormatLocal = "@"
            target.Borders.Color = RGB(209, 213, 219)
    End Select
    addresses(styleKind) = ""
    counts(styleKind) = 0
End Sub

Private Sub ReapplyLargeBalanceSpecialAlignment(ByVal ws As Worksheet, ByVal lastR As Long, _
                                                ByVal lastC As Long, ByRef rowKinds() As Byte)
    Dim personAddresses As String, headerAddresses As String
    Dim personCount As Long, headerCount As Long, r As Long
    Dim rowAddress As String, lastColumnLetter As String
    If ws Is Nothing Then Exit Sub
    lastColumnLetter = ExcelColumnLetter(lastC)
    For r = 2 To lastR
        If rowKinds(r) = 1 Then
            If Len(personAddresses) > 0 Then personAddresses = personAddresses & ","
            personAddresses = personAddresses & "A" & CStr(r)
            personCount = personCount + 1
            If personCount >= 40 Or Len(personAddresses) >= 180 Then
                ws.Range(personAddresses).HorizontalAlignment = xlLeft
                personAddresses = "": personCount = 0
            End If
        ElseIf rowKinds(r) = 2 Then
            rowAddress = "A" & CStr(r) & ":" & lastColumnLetter & CStr(r)
            If Len(headerAddresses) > 0 Then headerAddresses = headerAddresses & ","
            headerAddresses = headerAddresses & rowAddress
            headerCount = headerCount + 1
            If headerCount >= 40 Or Len(headerAddresses) >= 180 Then
                With ws.Range(headerAddresses)
                    .HorizontalAlignment = xlCenter
                    .VerticalAlignment = xlCenter
                    .WrapText = True
                    .ShrinkToFit = False
                    .EntireRow.RowHeight = 72
                End With
                headerAddresses = "": headerCount = 0
            End If
        End If
    Next r
    If Len(personAddresses) > 0 Then ws.Range(personAddresses).HorizontalAlignment = xlLeft
    If Len(headerAddresses) > 0 Then
        With ws.Range(headerAddresses)
            .HorizontalAlignment = xlCenter
            .VerticalAlignment = xlCenter
            .WrapText = True
            .ShrinkToFit = False
            .EntireRow.RowHeight = 72
        End With
    End If
End Sub

Private Function ExcelColumnLetter(ByVal columnNumber As Long) As String
    Dim remainder As Long
    If columnNumber < 1 Then Exit Function
    Do While columnNumber > 0
        remainder = (columnNumber - 1) Mod 26
        ExcelColumnLetter = Chr$(65 + remainder) & ExcelColumnLetter
        columnNumber = (columnNumber - remainder - 1) \ 26
    Loop
End Function

Private Sub ApplyBalanceTransitionBlockBorders(ByVal ws As Worksheet, ByVal lastR As Long, _
                                               ByVal lastC As Long, ByRef rowKinds() As Byte)
    Dim headerR As Long, endR As Long, r As Long, scanR As Long
    If ws Is Nothing Or lastR < 2 Or lastC < 7 Then Exit Sub

    r = 2
    Do While r <= lastR
        If rowKinds(r) = 2 Then
            headerR = r
            endR = lastR
            For scanR = headerR + 1 To lastR
                If rowKinds(scanR) = 0 Or rowKinds(scanR) = 1 Then
                    endR = scanR - 1
                    Exit For
                End If
            Next scanR

            If endR >= headerR Then
                With ws.Range(ws.Cells(headerR, 6), ws.Cells(endR, 6)).Borders(xlEdgeRight)
                    .LineStyle = xlContinuous
                    .Color = RGB(59, 130, 246)
                    .Weight = xlMedium
                End With
                If lastC >= 8 Then
                    With ws.Range(ws.Cells(headerR, lastC - 1), ws.Cells(endR, lastC - 1)).Borders(xlEdgeRight)
                        .LineStyle = xlContinuous
                        .Color = RGB(59, 130, 246)
                        .Weight = xlMedium
                    End With
                    With ws.Range(ws.Cells(headerR, 7), ws.Cells(endR, lastC - 1)).Borders(xlInsideVertical)
                        .LineStyle = xlContinuous
                        .Color = RGB(219, 234, 254)
                        .Weight = xlHairline
                    End With
                End If
            End If
            r = endR + 1
        Else
            r = r + 1
        End If
    Loop
End Sub

Private Sub FormatNonexistentBalanceCells(ByVal ws As Worksheet, ByVal rowNo As Long, _
                                          ByRef layoutData As Variant, _
                                          ByVal firstBalanceCol As Long, ByVal lastBalanceCol As Long)
    '残高推移表では、口座開設日前・解約日後の基準日を「-」で表示する。
    'ただの空欄ではなく薄い塗りにして、口座が存在しない期間だと一目で分かるようにする。
    Dim c As Long
    If ws Is Nothing Then Exit Sub
    If lastBalanceCol < firstBalanceCol Then Exit Sub
    For c = firstBalanceCol To lastBalanceCol
        If CellText(layoutData(rowNo, c)) = "-" Then
            With ws.Cells(rowNo, c)
                .Interior.Color = RGB(243, 244, 246)
                .Font.Color = RGB(71, 85, 105)
                .HorizontalAlignment = xlCenter
                .NumberFormatLocal = "@"
                .Borders.Color = RGB(209, 213, 219)
            End With
        End If
    Next c
End Sub

Public Function LastUsedColumnInSheet(ByVal ws As Worksheet, ByVal lastR As Long) As Long
    '行ごとのEnd(xlToLeft)走査を避け、シート全体の最後の値・数式を一度で取得する。
    'lastR引数は既存呼出との互換用に残す。
    Dim lastUsedColumn As Long
    If ws Is Nothing Then
        Err.Raise vbObjectError + 1107, "LastUsedColumnInSheet", _
                  "最終列を確認するシートが指定されていません。"
    End If
    If Not TryGetLastUsedColumnInSheet(ws, lastUsedColumn) Then
        Err.Raise vbObjectError + 1108, "LastUsedColumnInSheet(" & ws.Name & ")", _
                  "シートの最終列を安全に確認できませんでした。処理を中止しました。"
    End If
    LastUsedColumnInSheet = lastUsedColumn
End Function

Public Function TryGetLastUsedColumnInSheet(ByVal ws As Worksheet, _
                                            ByRef lastUsedColumn As Long) As Boolean
    Dim f As Range
    lastUsedColumn = 0
    If ws Is Nothing Then Exit Function
    On Error GoTo EH
    Set f = ws.Cells.Find(What:="*", After:=ws.Cells(1, 1), LookIn:=xlFormulas, LookAt:=xlPart, _
                          SearchOrder:=xlByColumns, SearchDirection:=xlPrevious, MatchCase:=False, _
                          MatchByte:=False, SearchFormat:=False)
    If Not f Is Nothing Then lastUsedColumn = f.Column
    TryGetLastUsedColumnInSheet = True
    Exit Function
EH:
    lastUsedColumn = 0
    Err.Clear
End Function

Public Function LastRow(ByVal ws As Worksheet, Optional ByVal colNo As Long = 1) As Long
    Dim r As Long
    If ws Is Nothing Then Exit Function
    r = ws.Cells(ws.Rows.Count, colNo).End(xlUp).Row
    If r = 1 And Len(CellText(ws.Cells(1, colNo).Value)) = 0 Then r = 0
    LastRow = r
End Function

Public Function LastDataRowInColumns(ByVal ws As Worksheet, ByVal firstColumn As Long, _
                                     ByVal lastColumn As Long) As Long
    'シート全体のFindでは、VBAで書かれた長さ0の文字列や表外の案内セルを
    'データ最終行と誤認することがある。指定列ごとの実最終行だけを返す。
    Dim c As Long, candidateRow As Long
    If ws Is Nothing Then Exit Function
    If firstColumn < 1 Or lastColumn < firstColumn Or lastColumn > ws.Columns.Count Then Exit Function
    For c = firstColumn To lastColumn
        candidateRow = LastRow(ws, c)
        If candidateRow > LastDataRowInColumns Then LastDataRowInColumns = candidateRow
    Next c
End Function

Public Function TryFindFirstFormulaCell(ByVal target As Range, _
                                        ByRef formulaCell As Range) As Boolean
    'SpecialCellsがOffice環境差で取得不能でも、最大500行ずつHasFormulaを読み、
    '「取得不能」を「数式なし」と取り違えない。戻り値Falseは検査自体の失敗。
    Const CHECK_CHUNK_ROWS As Long = 500
    Const CHECK_CHUNK_MAX_CELLS As Long = 8192
    Dim matched As Range, matchedInTarget As Range, area As Range, chunk As Range, cell As Range
    Dim rowOffset As Long, chunkRows As Long, maxRowsByCells As Long
    Dim specialCellsError As Long, intersectionError As Long
    Dim formulaState As Variant, cellFormulaState As Variant
    Set formulaCell = Nothing
    If target Is Nothing Then Exit Function

    On Error Resume Next
    Err.Clear
    Set matched = target.SpecialCells(xlCellTypeFormulas)
    specialCellsError = Err.Number
    Err.Clear
    On Error GoTo 0
    If specialCellsError = 0 Then
        If Not matched Is Nothing Then
            '一部Office APIが1セルRangeのSpecialCellsをシート全体へ拡張して返しても、
            '検査対象外の数式を誤検出しない。交差不能時は直接走査へフォールバックする。
            On Error Resume Next
            Err.Clear
            Set matchedInTarget = Application.Intersect(target, matched)
            intersectionError = Err.Number
            Err.Clear
            On Error GoTo 0
            If intersectionError = 0 And Not matchedInTarget Is Nothing Then
                Set formulaCell = matchedInTarget.Cells(1, 1)
                On Error GoTo EH
                cellFormulaState = formulaCell.HasFormula
                If VarType(cellFormulaState) <> vbBoolean Then GoTo EH
                If CBool(cellFormulaState) Then
                    TryFindFirstFormulaCell = True
                    Exit Function
                End If
                Set formulaCell = Nothing
            End If
        End If
    End If

    On Error GoTo EH
    For Each area In target.Areas
        If area.Columns.Count < 1 Or _
           area.Columns.Count > CHECK_CHUNK_MAX_CELLS Then GoTo EH
        maxRowsByCells = CHECK_CHUNK_MAX_CELLS \ CLng(area.Columns.Count)
        If maxRowsByCells < 1 Then GoTo EH
        rowOffset = 0
        Do While rowOffset < area.Rows.Count
            chunkRows = area.Rows.Count - rowOffset
            If chunkRows > CHECK_CHUNK_ROWS Then chunkRows = CHECK_CHUNK_ROWS
            If chunkRows > maxRowsByCells Then chunkRows = maxRowsByCells
            If chunkRows < 1 Then GoTo EH
            Set chunk = area.Rows(rowOffset + 1).Resize(chunkRows, area.Columns.Count)
            If CDbl(chunk.CountLarge) > CDbl(CHECK_CHUNK_MAX_CELLS) Then GoTo EH
            formulaState = chunk.HasFormula
            If IsNull(formulaState) Then
                For Each cell In chunk.Cells
                    cellFormulaState = cell.HasFormula
                    If VarType(cellFormulaState) <> vbBoolean Then GoTo EH
                    If CBool(cellFormulaState) Then
                        Set formulaCell = cell
                        TryFindFirstFormulaCell = True
                        Exit Function
                    End If
                Next cell
            ElseIf VarType(formulaState) <> vbBoolean Then
                GoTo EH
            ElseIf CBool(formulaState) Then
                Set formulaCell = chunk.Cells(1, 1)
                TryFindFirstFormulaCell = True
                Exit Function
            End If
            rowOffset = rowOffset + chunkRows
        Loop
    Next area
    TryFindFirstFormulaCell = True
    Exit Function
EH:
    Set formulaCell = Nothing
    Err.Clear
End Function

Public Function TryFindFirstErrorConstantCell(ByVal target As Range, _
                                              ByRef errorCell As Range) As Boolean
    'エラー定数のSpecialCells取得不能時は、値を500行単位で配列読込する。
    '数式結果のエラーは数式検査側へ任せ、定数として保存されたエラーだけを返す。
    Const CHECK_CHUNK_ROWS As Long = 500
    Const CHECK_CHUNK_MAX_CELLS As Long = 8192
    Dim matched As Range, matchedInTarget As Range, area As Range, chunk As Range, cell As Range
    Dim rowOffset As Long, chunkRows As Long, maxRowsByCells As Long
    Dim specialCellsError As Long, intersectionError As Long
    Dim values As Variant, r As Long, c As Long
    Dim cellFormulaState As Variant
    Set errorCell = Nothing
    If target Is Nothing Then Exit Function

    On Error Resume Next
    Err.Clear
    Set matched = target.SpecialCells(xlCellTypeConstants, xlErrors)
    specialCellsError = Err.Number
    Err.Clear
    On Error GoTo 0
    If specialCellsError = 0 Then
        If Not matched Is Nothing Then
            On Error Resume Next
            Err.Clear
            Set matchedInTarget = Application.Intersect(target, matched)
            intersectionError = Err.Number
            Err.Clear
            On Error GoTo 0
            If intersectionError = 0 And Not matchedInTarget Is Nothing Then
                Set errorCell = matchedInTarget.Cells(1, 1)
                On Error GoTo EH
                cellFormulaState = errorCell.HasFormula
                If VarType(cellFormulaState) <> vbBoolean Then GoTo EH
                If IsError(errorCell.Value2) Then
                    If Not CBool(cellFormulaState) Then
                        TryFindFirstErrorConstantCell = True
                        Exit Function
                    End If
                End If
                Set errorCell = Nothing
            End If
        End If
    End If

    On Error GoTo EH
    For Each area In target.Areas
        If area.Columns.Count < 1 Or _
           area.Columns.Count > CHECK_CHUNK_MAX_CELLS Then GoTo EH
        maxRowsByCells = CHECK_CHUNK_MAX_CELLS \ CLng(area.Columns.Count)
        If maxRowsByCells < 1 Then GoTo EH
        rowOffset = 0
        Do While rowOffset < area.Rows.Count
            chunkRows = area.Rows.Count - rowOffset
            If chunkRows > CHECK_CHUNK_ROWS Then chunkRows = CHECK_CHUNK_ROWS
            If chunkRows > maxRowsByCells Then chunkRows = maxRowsByCells
            If chunkRows < 1 Then GoTo EH
            Set chunk = area.Rows(rowOffset + 1).Resize(chunkRows, area.Columns.Count)
            If CDbl(chunk.CountLarge) > CDbl(CHECK_CHUNK_MAX_CELLS) Then GoTo EH
            If CDbl(chunk.CountLarge) = 1 Then
                cellFormulaState = chunk.HasFormula
                If VarType(cellFormulaState) <> vbBoolean Then GoTo EH
                If IsError(chunk.Value2) And Not CBool(cellFormulaState) Then
                    Set errorCell = chunk
                    TryFindFirstErrorConstantCell = True
                    Exit Function
                End If
            Else
                values = chunk.Value2
                If Not IsArray(values) Then GoTo EH
                If LBound(values, 1) <> 1 Or _
                   UBound(values, 1) <> chunk.Rows.Count Or _
                   LBound(values, 2) <> 1 Or _
                   UBound(values, 2) <> chunk.Columns.Count Then GoTo EH
                For r = 1 To UBound(values, 1)
                    For c = 1 To UBound(values, 2)
                        If IsError(values(r, c)) Then
                            Set cell = chunk.Cells(r, c)
                            cellFormulaState = cell.HasFormula
                            If VarType(cellFormulaState) <> vbBoolean Then GoTo EH
                            If Not CBool(cellFormulaState) Then
                                Set errorCell = cell
                                TryFindFirstErrorConstantCell = True
                                Exit Function
                            End If
                        End If
                    Next c
                Next r
            End If
            rowOffset = rowOffset + chunkRows
        Loop
    Next area
    TryFindFirstErrorConstantCell = True
    Exit Function
EH:
    Set errorCell = Nothing
    Err.Clear
End Function

Public Sub EnsureInternalAppendCapacity(ByVal ws As Worksheet, ByVal appendRows As Long, _
                                        ByVal labelText As String)
    '配列圧縮は追記後に行うため、訂正でも一時的な追記分を含めて共通上限内である必要がある。
    Dim currentRows As Long, lastR As Long
    If ws Is Nothing Then _
        Err.Raise vbObjectError + 1021, "EnsureInternalAppendCapacity", "内部保管を取得できません: " & labelText
    If appendRows < 0 Then _
        Err.Raise vbObjectError + 1022, "EnsureInternalAppendCapacity", "追記件数が不正です: " & labelText
    lastR = LastUsedRowInSheet(ws)
    If lastR > 1 Then currentRows = lastR - 1
    If CDbl(currentRows) + CDbl(appendRows) > CDbl(MAX_INTERNAL_STORE_DATA_ROWS) Then
        Err.Raise vbObjectError + 1023, "EnsureInternalAppendCapacity", _
                  labelText & "が追記中の一時領域を含めて実用上限（" & _
                  Format$(MAX_INTERNAL_STORE_DATA_ROWS, "#,##0") & "行）を超えます。案件を分割してください。"
    End If
    If CDbl(currentRows) + CDbl(appendRows) > CDbl(ws.Rows.Count - 1) Then
        Err.Raise vbObjectError + 1024, "EnsureInternalAppendCapacity", _
                  labelText & "がExcelの行上限を超えます。案件を分割してください。"
    End If
End Sub

Public Function CellText(ByVal v As Variant) As String
    If IsError(v) Or IsNull(v) Or IsEmpty(v) Then
        CellText = ""
    Else
        CellText = Trim$(CStr(v))
    End If
End Function

Public Function HasText(ByVal v As Variant) As Boolean
    HasText = Len(CellText(v)) > 0
End Function

Public Function ToAmountOrBlank(ByVal v As Variant) As Variant
    Dim ok As Boolean
    ToAmountOrBlank = TryParseAmount(v, ok)
    If Not ok Then ToAmountOrBlank = v
End Function

Public Function TryParseAmount(ByVal v As Variant, ByRef ok As Boolean) As Variant
    Dim s As String
    Dim normalizedText As String
    Dim amountValue As Double
    ok = False
    If IsError(v) Or IsNull(v) Then Exit Function
    s = CellText(v)
    If Len(s) = 0 Then
        TryParseAmount = ""
        ok = True
        Exit Function
    End If
    On Error Resume Next
    s = StrConv(s, vbNarrow)
    On Error GoTo 0
    s = Trim$(s)
    If InStr(1, s, " ", vbBinaryCompare) > 0 Or InStr(1, s, "　", vbBinaryCompare) > 0 Then Exit Function
    If Not TryNormalizeAmountSyntax(s, normalizedText) Then Exit Function
    If Not IsPlainAmountText(normalizedText) Then Exit Function
    On Error GoTo InvalidAmount
    amountValue = CDbl(normalizedText)
    If Abs(amountValue) > MAX_ABS_AMOUNT Then Exit Function
    TryParseAmount = amountValue
    ok = True
    Exit Function
InvalidAmount:
    ok = False
End Function

Private Function TryNormalizeAmountSyntax(ByVal rawText As String, ByRef normalizedText As String) As Boolean
    '補助入力は許容するが、誤った桁区切りや途中に混ざった通貨記号を黙って別金額へ変換しない。
    Dim s As String, signText As String
    Dim parts As Variant, groups As Variant
    Dim integerPart As String, decimalPart As String
    Dim i As Long, hasParentheses As Boolean
    s = Replace(rawText, "，", ",")
    If Len(s) = 0 Then Exit Function

    If Left$(s, 1) = "(" Or Right$(s, 1) = ")" Then
        If Len(s) < 3 Or Left$(s, 1) <> "(" Or Right$(s, 1) <> ")" Then Exit Function
        s = Mid$(s, 2, Len(s) - 2)
        signText = "-"
        hasParentheses = True
    End If
    If InStr(1, s, "(", vbBinaryCompare) > 0 Or InStr(1, s, ")", vbBinaryCompare) > 0 Then Exit Function

    If Left$(s, 1) = "+" Or Left$(s, 1) = "-" Then
        If hasParentheses Then Exit Function
        signText = Left$(s, 1)
        s = Mid$(s, 2)
    End If
    If Left$(s, 1) = ChrW$(&HA5) Or Left$(s, 1) = "￥" Then s = Mid$(s, 2)
    '「￥-1,000」のように通貨記号の直後へ符号を置く表記も、符号が一つだけなら受け付ける。
    If Left$(s, 1) = "+" Or Left$(s, 1) = "-" Then
        If hasParentheses Or Len(signText) > 0 Then Exit Function
        signText = Left$(s, 1)
        s = Mid$(s, 2)
    End If
    If Right$(s, 1) = "円" Then s = Left$(s, Len(s) - 1)
    If Len(s) = 0 Then Exit Function
    If InStr(1, s, ChrW$(&HA5), vbBinaryCompare) > 0 Or _
       InStr(1, s, "￥", vbBinaryCompare) > 0 Or InStr(1, s, "円", vbBinaryCompare) > 0 Then Exit Function

    parts = Split(s, ".")
    If UBound(parts) > 1 Then Exit Function
    integerPart = CStr(parts(0))
    If UBound(parts) = 1 Then decimalPart = CStr(parts(1))
    If InStr(1, decimalPart, ",", vbBinaryCompare) > 0 Then Exit Function
    If InStr(1, integerPart, ",", vbBinaryCompare) > 0 Then
        groups = Split(integerPart, ",")
        If Len(CStr(groups(0))) < 1 Or Len(CStr(groups(0))) > 3 Then Exit Function
        If Not IsUnsignedIntegerText(CStr(groups(0))) Then Exit Function
        For i = 1 To UBound(groups)
            If Len(CStr(groups(i))) <> 3 Then Exit Function
            If Not IsUnsignedIntegerText(CStr(groups(i))) Then Exit Function
        Next i
        integerPart = Replace(integerPart, ",", "")
    End If
    normalizedText = signText & integerPart
    If UBound(parts) = 1 Then normalizedText = normalizedText & "." & decimalPart
    TryNormalizeAmountSyntax = True
End Function

Private Function IsPlainAmountText(ByVal valueText As String) As Boolean
    'Excelの有効精度を超える指数表記・過剰小数を受け付けず、保存時の見えない丸めを防ぐ。
    Dim i As Long, startPos As Long, decimalPos As Long
    Dim digitCount As Long, decimalDigits As Long, significantDigits As Long
    Dim ch As String, significantStarted As Boolean
    If Len(valueText) = 0 Then Exit Function
    startPos = 1
    ch = Left$(valueText, 1)
    If ch = "+" Or ch = "-" Then
        startPos = 2
        If Len(valueText) = 1 Then Exit Function
    End If
    For i = startPos To Len(valueText)
        ch = Mid$(valueText, i, 1)
        If ch = "." Then
            If decimalPos > 0 Then Exit Function
            decimalPos = i
        ElseIf ch >= "0" And ch <= "9" Then
            digitCount = digitCount + 1
            If decimalPos > 0 Then decimalDigits = decimalDigits + 1
            If ch <> "0" Then significantStarted = True
            If significantStarted Then significantDigits = significantDigits + 1
        Else
            Exit Function
        End If
    Next i
    If digitCount = 0 Then Exit Function
    If decimalDigits > 8 Then Exit Function
    If significantDigits > 15 Then Exit Function
    IsPlainAmountText = True
End Function

Public Function GetCfgCell(ByVal rowNo As Long) As Range
    Dim ws As Worksheet
    Set ws = GetSheet(SH_CONFIG)
    Set GetCfgCell = ws.Cells(rowNo, COL_CFG_VALUE)
End Function

Public Function GetCfgLong(ByVal rowNo As Long, ByVal defaultValue As Long) As Long
    On Error GoTo EH
    If IsNumeric(GetCfgCell(rowNo).Value) Then
        GetCfgLong = CLng(GetCfgCell(rowNo).Value)
    Else
        GetCfgLong = defaultValue
    End If
    Exit Function
EH:
    GetCfgLong = defaultValue
End Function

Public Function GetCfgDateValue(ByVal rowNo As Long) As Variant
    Dim normalized As Variant
    Dim ok As Boolean
    On Error GoTo EH
    normalized = NormalizeDateOnlyValue(GetCfgCell(rowNo).Value, ok)
    If ok Then GetCfgDateValue = normalized Else GetCfgDateValue = ""
    Exit Function
EH:
    GetCfgDateValue = ""
End Function

Public Function NormalizeDateOnlyValue(ByVal valueIn As Variant, ByRef ok As Boolean) As Variant
    '日付列に見えない時刻成分や、Excelで安定表示できない1900年未満を持ち込まない。
    Dim dt As Date
    ok = False
    If IsError(valueIn) Or IsNull(valueIn) Or IsEmpty(valueIn) Then Exit Function
    If Len(CellText(valueIn)) = 0 Then Exit Function
    If Not IsDate(valueIn) Then Exit Function
    On Error GoTo InvalidDate
    dt = CDate(valueIn)
    If Year(dt) < 1900 Or Year(dt) > 9999 Then Exit Function
    NormalizeDateOnlyValue = DateSerial(Year(dt), Month(dt), Day(dt))
    ok = True
    Exit Function
InvalidDate:
    NormalizeDateOnlyValue = ""
End Function

Public Function GetInputMode() As String
    On Error GoTo EH
    GetInputMode = CellText(GetCfgCell(ROW_CFG_INPUT_MODE).Value)
    If Len(GetInputMode) = 0 Then GetInputMode = MODE_NORMAL
    Exit Function
EH:
    GetInputMode = MODE_NORMAL
End Function

Public Function GetYearInputMode() As String
    On Error GoTo EH
    GetYearInputMode = CellText(GetCfgCell(ROW_CFG_YEAR_MODE).Value)
    If Len(GetYearInputMode) = 0 Then GetYearInputMode = YEAR_MODE_WAREKI
    Exit Function
EH:
    GetYearInputMode = YEAR_MODE_WAREKI
End Function


Public Function GetPostTransferKeepPolicy() As String
    Dim configuredValue As String
    On Error GoTo EH
    configuredValue = CellText(GetCfgCell(ROW_CFG_POST_KEEP).Value)
    Select Case configuredValue
        Case KEEP_NONE, KEEP_PERSON_ONLY, KEEP_BANK_BRANCH, KEEP_BANK_BRANCH_PERSON_TYPE
            GetPostTransferKeepPolicy = configuredValue
        Case Else
            GetPostTransferKeepPolicy = KEEP_BANK_BRANCH_PERSON_TYPE
    End Select
    Exit Function
EH:
    GetPostTransferKeepPolicy = KEEP_BANK_BRANCH_PERSON_TYPE
End Function

Public Function GetPostTransferClearTransaction() As Boolean
    On Error GoTo EH
    GetPostTransferClearTransaction = (CellText(GetCfgCell(ROW_CFG_POST_TX).Value) <> POST_KEEP)
    Exit Function
EH:
    GetPostTransferClearTransaction = True
End Function

Public Function GetPostTransferClearBalance() As Boolean
    On Error GoTo EH
    GetPostTransferClearBalance = (CellText(GetCfgCell(ROW_CFG_POST_BAL).Value) <> POST_KEEP)
    Exit Function
EH:
    GetPostTransferClearBalance = True
End Function

Public Function GetDisplayOption(ByVal rowNo As Long, Optional ByVal defaultShow As Boolean = True) As Boolean
    '設定シートの「表示する / 表示しない」を安全に読み取る。
    '空欄や想定外の値は、業務で困りにくいよう defaultShow を返す。
    Dim v As String
    On Error GoTo EH
    v = CellText(GetCfgCell(rowNo).Value)
    If v = DISPLAY_ON Then
        GetDisplayOption = True
    ElseIf v = DISPLAY_OFF Then
        GetDisplayOption = False
    Else
        GetDisplayOption = defaultShow
    End If
    Exit Function
EH:
    GetDisplayOption = defaultShow
End Function

Public Function UseRelationshipDisplay() As Boolean
    UseRelationshipDisplay = GetDisplayOption(ROW_CFG_RELATIONSHIP, True)
End Function

Public Function ShowInheritanceStartRow() As Boolean
    ShowInheritanceStartRow = GetDisplayOption(ROW_CFG_SHOW_INHERITANCE_ROW, True)
End Function

Public Function ShowOpenDateRow() As Boolean
    ShowOpenDateRow = GetDisplayOption(ROW_CFG_SHOW_OPEN_DATE_ROW, True)
End Function

Public Function ShowCloseDateRow() As Boolean
    ShowCloseDateRow = GetDisplayOption(ROW_CFG_SHOW_CLOSE_DATE_ROW, True)
End Function

Public Function ShowBalanceRowsInCashOperation() As Boolean
    ShowBalanceRowsInCashOperation = GetDisplayOption(ROW_CFG_SHOW_BALANCE_ROWS, True)
End Function

Public Function DisplayPersonWithRelationship(ByVal personName As String, ByVal relationshipText As String) As String
    '出力では列を増やさず、氏名欄の中で「氏名（続柄）」として表示する。
    '設定で続柄を非表示にした場合は氏名のみを返す。
    Dim p As String, rel As String
    p = CellText(personName)
    rel = CellText(relationshipText)
    If UseRelationshipDisplay() And Len(rel) > 0 Then
        DisplayPersonWithRelationship = p & "（" & rel & "）"
    Else
        DisplayPersonWithRelationship = p
    End If
End Function

Public Function IsLightExcelColor(ByVal colorValue As Long) As Boolean
    '旧呼出との互換用。読みやすさの判定はExcelColorContrastRatioを使用する。
    Dim r As Long, g As Long, b As Long
    Dim brightness As Double
    r = colorValue Mod 256
    g = (colorValue \ 256) Mod 256
    b = (colorValue \ 65536) Mod 256
    brightness = 0.299 * r + 0.587 * g + 0.114 * b
    IsLightExcelColor = (brightness >= 210)
End Function

Public Function IsWebUrlPath(ByVal pathText As String) As Boolean
    pathText = LCase$(Trim$(pathText))
    IsWebUrlPath = _
        (Left$(pathText, 7) = "http://" Or Left$(pathText, 8) = "https://")
End Function

Private Function SRGBChannelLuminance(ByVal channelValue As Long) As Double
    Dim normalized As Double
    normalized = CDbl(channelValue) / 255#
    If normalized <= 0.04045 Then
        SRGBChannelLuminance = normalized / 12.92
    Else
        SRGBChannelLuminance = ((normalized + 0.055) / 1.055) ^ 2.4
    End If
End Function

Public Function ExcelColorContrastRatio(ByVal firstColor As Long, _
                                        ByVal secondColor As Long) As Double
    'WCAGと同じsRGB相対輝度で、背景色と文字色のコントラスト比を返す。
    Dim firstLuminance As Double, secondLuminance As Double
    Dim lighter As Double, darker As Double
    If firstColor < 0 Or secondColor < 0 Then Exit Function
    firstLuminance = _
        0.2126 * SRGBChannelLuminance(firstColor Mod 256) + _
        0.7152 * SRGBChannelLuminance((firstColor \ 256) Mod 256) + _
        0.0722 * SRGBChannelLuminance((firstColor \ 65536) Mod 256)
    secondLuminance = _
        0.2126 * SRGBChannelLuminance(secondColor Mod 256) + _
        0.7152 * SRGBChannelLuminance((secondColor \ 256) Mod 256) + _
        0.0722 * SRGBChannelLuminance((secondColor \ 65536) Mod 256)
    If firstLuminance >= secondLuminance Then
        lighter = firstLuminance
        darker = secondLuminance
    Else
        lighter = secondLuminance
        darker = firstLuminance
    End If
    ExcelColorContrastRatio = (lighter + 0.05) / (darker + 0.05)
End Function

Public Function ReadableFontColor(ByVal fillColor As Long, _
                                  ByVal preferredFontColor As Long) As Long
    Dim darkColor As Long, lightColor As Long
    Dim darkRatio As Double, lightRatio As Double
    '中間輝度の背景では濃紺と白のどちらも4.5:1を下回る狭い帯がある。
    '補正色は純黒／純白から選び、どのsRGB背景でも通常文字の下限を保証する。
    darkColor = RGB(0, 0, 0)
    lightColor = RGB(255, 255, 255)
    If fillColor < 0 Then fillColor = RGB(255, 255, 255)
    If preferredFontColor >= 0 Then
        If ExcelColorContrastRatio(fillColor, preferredFontColor) >= _
           MIN_NORMAL_TEXT_CONTRAST Then
            ReadableFontColor = preferredFontColor
            Exit Function
        End If
    End If
    darkRatio = ExcelColorContrastRatio(fillColor, darkColor)
    lightRatio = ExcelColorContrastRatio(fillColor, lightColor)
    If darkRatio >= lightRatio Then
        ReadableFontColor = darkColor
    Else
        ReadableFontColor = lightColor
    End If
End Function

Public Sub EnsureToolShapeTextContrast(ByVal shp As Shape, _
                                       Optional ByVal labelText As String = "")
    '操作ボタンの実効色を読み戻し、WCAG 4.5:1未満なら黒/白のうち
    '高コントラスト側へ補正する。補正値の再読戻しまで一致しなければ失敗とする。
    'OSテーマで描画されるフォームコントロールだけを対象外とする。AutoShapeの
    '透明・非表示・グラデーションFillは、主色を保った不透明Solidへ収束させる。
    Dim fillValue As Variant, fontValue As Variant, correctedValue As Long
    Dim originalFillColor As Long, fillType As Long, fillVisible As Long
    Dim fillTransparency As Double
    Dim errorNumber As Long, errorDescription As String
    If shp Is Nothing Then _
        Err.Raise vbObjectError + 1123, "EnsureToolShapeTextContrast", _
                  "操作ボタンを取得できません。"
    On Error GoTo EH
    If shp.Type = msoFormControl Then Exit Sub
    fillValue = shp.Fill.ForeColor.RGB
    fontValue = shp.TextFrame.Characters.Font.Color
    If IsNull(fillValue) Or IsNull(fontValue) Or _
       Not IsNumeric(fillValue) Or Not IsNumeric(fontValue) Then _
        Err.Raise vbObjectError + 1124, "EnsureToolShapeTextContrast", _
                  "操作ボタンの背景色または文字色を一意に読み取れません。"
    If CLng(fillValue) < 0 Or CLng(fontValue) < 0 Then _
        Err.Raise vbObjectError + 1124, "EnsureToolShapeTextContrast", _
                  "操作ボタンの実効RGB色を一意に読み取れません。"
    originalFillColor = CLng(fillValue)
    fillVisible = CLng(shp.Fill.Visible)
    fillType = CLng(shp.Fill.Type)
    fillTransparency = CDbl(shp.Fill.Transparency)
    If fillVisible <> msoTrue Or fillType <> msoFillSolid Or _
       Abs(fillTransparency) > 0.000001 Then
        '透明・非表示・グラデーションは背面との合成色を一意に判定できないため、
        'ボタンの主色を保った不透明Solidへ収束させてから可読性を判定する。
        shp.Fill.Visible = msoTrue
        shp.Fill.Solid
        shp.Fill.ForeColor.RGB = originalFillColor
        shp.Fill.Transparency = 0
        fillVisible = CLng(shp.Fill.Visible)
        fillType = CLng(shp.Fill.Type)
        fillTransparency = CDbl(shp.Fill.Transparency)
        fillValue = shp.Fill.ForeColor.RGB
        fontValue = shp.TextFrame.Characters.Font.Color
        If fillVisible <> msoTrue Or fillType <> msoFillSolid Or _
           Abs(fillTransparency) > 0.000001 Then _
            Err.Raise vbObjectError + 1125, "EnsureToolShapeTextContrast", _
                      "操作ボタンの背景を不透明な単色へ収束できません。"
        If IsNull(fillValue) Or IsNull(fontValue) Or _
           Not IsNumeric(fillValue) Or Not IsNumeric(fontValue) Then _
            Err.Raise vbObjectError + 1125, "EnsureToolShapeTextContrast", _
                      "操作ボタンの背景収束後の色を読み戻せません。"
        If CLng(fillValue) <> originalFillColor Then _
            Err.Raise vbObjectError + 1125, "EnsureToolShapeTextContrast", _
                      "操作ボタンの背景収束後の色が設定値と一致しません。"
    End If
    If ExcelColorContrastRatio(CLng(fillValue), CLng(fontValue)) < _
       MIN_NORMAL_TEXT_CONTRAST Then
        correctedValue = ReadableFontColor(CLng(fillValue), CLng(fontValue))
        shp.TextFrame.Characters.Font.Color = correctedValue
        fillVisible = CLng(shp.Fill.Visible)
        fillType = CLng(shp.Fill.Type)
        fillTransparency = CDbl(shp.Fill.Transparency)
        fillValue = shp.Fill.ForeColor.RGB
        fontValue = shp.TextFrame.Characters.Font.Color
        If IsNull(fillValue) Or IsNull(fontValue) Or _
           Not IsNumeric(fillValue) Or Not IsNumeric(fontValue) Then _
            Err.Raise vbObjectError + 1125, "EnsureToolShapeTextContrast", _
                      "操作ボタンの補正後背景色または文字色を読み戻せません。"
        If CLng(fillValue) <> originalFillColor Then _
            Err.Raise vbObjectError + 1125, "EnsureToolShapeTextContrast", _
                      "操作ボタンの文字色補正中に背景色が変化しました。"
        If fillVisible <> msoTrue Or fillType <> msoFillSolid Or _
           Abs(fillTransparency) > 0.000001 Then _
            Err.Raise vbObjectError + 1125, "EnsureToolShapeTextContrast", _
                      "操作ボタンの文字色補正後に背景状態が変化しました。"
        If CLng(fontValue) <> correctedValue Then _
            Err.Raise vbObjectError + 1126, "EnsureToolShapeTextContrast", _
                      "操作ボタンの補正後文字色が設定値と一致しません。"
    End If
    If ExcelColorContrastRatio(CLng(fillValue), CLng(fontValue)) < _
       MIN_NORMAL_TEXT_CONTRAST Then _
        Err.Raise vbObjectError + 1127, "EnsureToolShapeTextContrast", _
                  "操作ボタンの背景色と文字色が4.5:1未満です。"
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    If Len(labelText) > 0 Then errorDescription = labelText & ": " & errorDescription
    Err.Raise errorNumber, "EnsureToolShapeTextContrast", errorDescription
End Sub

Public Function ToolShapeTextContrastIsReadable( _
        ByVal shp As Shape, ByRef resultKnown As Boolean, _
        Optional ByRef isApplicable As Boolean = False) As Boolean
    'フォームコントロールだけを対象外とし、AutoShapeの透明Fillは不合格とする。
    Dim fillValue As Variant, fontValue As Variant
    Dim fillVisible As Long, fillType As Long
    Dim fillTransparency As Double
    resultKnown = False
    isApplicable = False
    If shp Is Nothing Then Exit Function
    On Error GoTo EH
    If shp.Type = msoFormControl Then
        resultKnown = True
        ToolShapeTextContrastIsReadable = True
        Exit Function
    End If
    isApplicable = True
    fillVisible = CLng(shp.Fill.Visible)
    If fillVisible <> msoTrue Then
        resultKnown = True
        Exit Function
    End If
    fillTransparency = CDbl(shp.Fill.Transparency)
    If fillTransparency < 0# Or fillTransparency > 1# Then Exit Function
    If Abs(fillTransparency) > 0.000001 Then
        resultKnown = True
        Exit Function
    End If
    fillType = CLng(shp.Fill.Type)
    If fillType <> msoFillSolid Then
        resultKnown = True
        Exit Function
    End If
    fillValue = shp.Fill.ForeColor.RGB
    fontValue = shp.TextFrame.Characters.Font.Color
    If IsNull(fillValue) Or IsNull(fontValue) Then Exit Function
    If Not IsNumeric(fillValue) Or Not IsNumeric(fontValue) Then Exit Function
    If CLng(fillValue) < 0 Or CLng(fontValue) < 0 Then Exit Function
    resultKnown = True
    ToolShapeTextContrastIsReadable = _
        (ExcelColorContrastRatio(CLng(fillValue), CLng(fontValue)) >= _
         MIN_NORMAL_TEXT_CONTRAST)
    Exit Function
EH:
    resultKnown = False
    isApplicable = False
    ToolShapeTextContrastIsReadable = False
    Err.Clear
End Function

Public Function LastUsedRowInSheet(ByVal ws As Worksheet) As Long
    '日付欄・摘要欄だけの相続開始日行も拾えるよう、特定列ではなくシート全体で最終行を探す。
    Dim lastUsedRow As Long
    If ws Is Nothing Then
        Err.Raise vbObjectError + 1105, "LastUsedRowInSheet", _
                  "最終行を確認するシートが指定されていません。"
    End If
    If Not TryGetLastUsedRowInSheet(ws, lastUsedRow) Then
        '検索失敗を空シート(0行)として扱うと、追記処理が行2から既存データを
        '上書きし得る。読取エラー時は必ず書込み前に停止する。
        Err.Raise vbObjectError + 1106, "LastUsedRowInSheet(" & ws.Name & ")", _
                  "シートの最終行を安全に確認できませんでした。書込みは行っていません。"
    End If
    LastUsedRowInSheet = lastUsedRow
End Function

Public Function TryGetLastUsedRowInSheet(ByVal ws As Worksheet, _
                                         ByRef lastUsedRow As Long) As Boolean
    'Findが使えなかった場合を空シートと誤認させないため、成功可否を別に返す。
    Dim f As Range
    lastUsedRow = 0
    If ws Is Nothing Then Exit Function
    On Error GoTo EH
    Set f = ws.Cells.Find(What:="*", After:=ws.Cells(1, 1), LookIn:=xlFormulas, LookAt:=xlPart, _
                          SearchOrder:=xlByRows, SearchDirection:=xlPrevious, MatchCase:=False, _
                          MatchByte:=False, SearchFormat:=False)
    If Not f Is Nothing Then lastUsedRow = f.Row
    TryGetLastUsedRowInSheet = True
    Exit Function
EH:
    lastUsedRow = 0
    Err.Clear
End Function

Public Function IsTransactionRowBlank(ByVal ws As Worksheet, ByVal r As Long) As Boolean
    Dim c As Long
    If ws Is Nothing Then
        IsTransactionRowBlank = True
        Exit Function
    End If
    For c = COL_TX_YEAR To COL_TX_OTHER
        If HasText(ws.Cells(r, c).Value) Then
            IsTransactionRowBlank = False
            Exit Function
        End If
    Next c
    IsTransactionRowBlank = True
End Function

Public Function NormalizeYearInput(ByVal v As Variant, ByVal yearAdd As Long, ByRef ok As Boolean) As Long
    Dim s As String
    Dim y As Long
    Dim modeText As String
    ok = False
    s = NormalizeNumberText(CellText(v))
    If Len(s) = 0 Then Exit Function

    '3～4桁は、どの入力方式でも西暦として扱う。5桁以上は範囲外として拒否する。
    If IsUnsignedIntegerText(s) Then
        If Len(s) > 4 Then Exit Function
        y = CLng(s)
        If y >= 100 Then
            If y < 1900 Or y > 9999 Then Exit Function
            NormalizeYearInput = y
            ok = True
            Exit Function
        End If
    End If

    modeText = GetYearInputMode()
    If modeText = YEAR_MODE_WESTERN2 Then
        If Not IsUnsignedIntegerText(s) Then Exit Function
        If Len(s) > 2 Then Exit Function
        y = CLng(s)
        If y < 0 Or y > 99 Then Exit Function
        y = yearAdd + y
    Else
        y = ResolveWarekiYearSmart(s)
    End If

    If y < 1900 Or y > 9999 Then Exit Function
    NormalizeYearInput = y
    ok = True
End Function

Public Function NormalizeNumberText(ByVal s As String) As String
    On Error Resume Next
    s = StrConv(s, vbNarrow)
    On Error GoTo 0
    s = Replace(s, " ", "")
    s = Replace(s, "　", "")
    s = Replace(s, "年", "")
    NormalizeNumberText = Trim$(s)
End Function

Public Function IsUnsignedIntegerText(ByVal valueText As String) As Boolean
    Dim i As Long, ch As String
    If Len(valueText) = 0 Then Exit Function
    For i = 1 To Len(valueText)
        ch = Mid$(valueText, i, 1)
        If ch < "0" Or ch > "9" Then Exit Function
    Next i
    IsUnsignedIntegerText = True
End Function

Private Function ResolveWarekiYearSmart(ByVal s As String) As Long
    Dim y As Long
    Dim n As Long

    If ResolveExplicitEraYear(s, y) Then
        ResolveWarekiYearSmart = y
        Exit Function
    End If

    If s = "元" Then s = "1"
    If Not IsUnsignedIntegerText(s) Then Exit Function
    If Len(s) > 2 Then Exit Function
    n = CLng(s)
    If n <= 0 Or n > 99 Then Exit Function

    ResolveWarekiYearSmart = BestJapaneseEraCandidate(n)
End Function

Private Function ResolveExplicitEraYear(ByVal s As String, ByRef westernYear As Long) As Boolean
    Dim era As String
    Dim n As Long
    s = UCase$(s)
    s = Replace(s, ".", "")
    s = Replace(s, "-", "")
    s = Replace(s, "令和", "R")
    s = Replace(s, "平成", "H")
    s = Replace(s, "昭和", "S")
    If Len(s) < 2 Then Exit Function
    era = Left$(s, 1)
    If era <> "R" And era <> "H" And era <> "S" Then Exit Function
    s = Mid$(s, 2)
    If s = "元" Then s = "1"
    If Not IsUnsignedIntegerText(s) Then Exit Function
    If Len(s) > 2 Then Exit Function
    n = CLng(s)
    If n <= 0 Then Exit Function

    Select Case era
        Case "R"
            If n > 99 Then Exit Function
            westernYear = 2018 + n
        Case "H"
            If n > 31 Then Exit Function
            westernYear = 1988 + n
        Case "S"
            If n > 64 Then Exit Function
            westernYear = 1925 + n
    End Select
    ResolveExplicitEraYear = (westernYear >= 1900 And westernYear <= 9999)
End Function

Private Function BestJapaneseEraCandidate(ByVal eraYear As Long) As Long
    Dim candidates(1 To 3) As Long
    Dim count As Long
    Dim i As Long
    Dim refYear As Long
    Dim bestYear As Long
    Dim bestScore As Long
    Dim score As Long

    If eraYear >= 1 And eraYear <= 99 Then
        count = count + 1
        candidates(count) = 2018 + eraYear  '令和
    End If
    If eraYear >= 1 And eraYear <= 31 Then
        count = count + 1
        candidates(count) = 1988 + eraYear  '平成
    End If
    If eraYear >= 1 And eraYear <= 64 Then
        count = count + 1
        candidates(count) = 1925 + eraYear  '昭和
    End If

    refYear = GetYearResolutionReferenceYear()
    bestScore = 999999
    For i = 1 To count
        If candidates(i) >= 1900 And candidates(i) <= 2100 Then
            score = Abs(candidates(i) - refYear) + JapaneseEraWindowPenalty(candidates(i))
            If score < bestScore Or (score = bestScore And candidates(i) > bestYear) Then
                bestScore = score
                bestYear = candidates(i)
            End If
        End If
    Next i
    BestJapaneseEraCandidate = bestYear
End Function

Private Function GetYearResolutionReferenceYear() As Long
    Dim inheritDate As Variant
    Dim startYear As Long
    Dim endYear As Long
    inheritDate = GetCfgDateValue(ROW_CFG_INHERITANCE_DATE)
    If IsDate(inheritDate) Then
        GetYearResolutionReferenceYear = Year(CDate(inheritDate))
        Exit Function
    End If
    startYear = GetCfgLong(ROW_CFG_BAL_START_YEAR, Year(Date) - 4)
    endYear = GetCfgLong(ROW_CFG_BAL_END_YEAR, Year(Date))
    If startYear > 0 And endYear >= startYear Then
        GetYearResolutionReferenceYear = CLng((startYear + endYear) / 2)
    Else
        GetYearResolutionReferenceYear = Year(Date)
    End If
End Function

Private Function JapaneseEraWindowPenalty(ByVal westernYear As Long) As Long
    Dim startYear As Long
    Dim endYear As Long
    startYear = GetCfgLong(ROW_CFG_BAL_START_YEAR, Year(Date) - 4)
    endYear = GetCfgLong(ROW_CFG_BAL_END_YEAR, Year(Date))
    If endYear < startYear Then endYear = startYear
    If westernYear < startYear - 5 Or westernYear > endYear + 5 Then
        JapaneseEraWindowPenalty = 1000
    Else
        JapaneseEraWindowPenalty = 0
    End If
End Function

Public Function ParseMonthDay(ByVal v As Variant, ByRef m As Long, ByRef d As Long) As Boolean
    Dim s As String
    On Error GoTo InvalidMonthDay
    s = NormalizeNumberText(CellText(v))
    ParseMonthDay = False
    If Len(s) < 3 Or Len(s) > 4 Then Exit Function
    If Not IsUnsignedIntegerText(s) Then Exit Function
    If Len(s) = 3 Then
        m = CLng(Left$(s, 1))
        d = CLng(Right$(s, 2))
    Else
        m = CLng(Left$(s, 2))
        d = CLng(Right$(s, 2))
    End If
    If m < 1 Or m > 12 Then Exit Function
    If d < 1 Or d > 31 Then Exit Function
    ParseMonthDay = True
    Exit Function
InvalidMonthDay:
    ParseMonthDay = False
End Function

Public Function ResolveInputDate(ByVal yearVal As Variant, ByVal monthVal As Variant, ByVal dayVal As Variant, _
    ByRef currentYear As Long, ByRef currentMonth As Long, ByRef currentDay As Long, _
    ByVal yearAdd As Long, ByRef ok As Boolean) As Variant

    Dim tmpYear As Long
    Dim tmpMonth As Long
    Dim tmpDay As Long
    Dim yearOK As Boolean
    Dim d As Date
    Dim monthText As String, dayText As String

    ok = False
    ResolveInputDate = ""
    On Error GoTo InvalidDate
    '候補値で完全な実在日付を確認してから補完状態へ反映する。
    '不正な月日が後続行の省略入力へ持ち越されないよう、ByRef値を先に変更しない。
    tmpYear = currentYear
    tmpMonth = currentMonth
    tmpDay = currentDay
    If HasText(yearVal) Then
        tmpYear = NormalizeYearInput(yearVal, yearAdd, yearOK)
        If Not yearOK Then Exit Function
    End If
    If HasText(monthVal) Then
        monthText = NormalizeNumberText(CellText(monthVal))
        If Len(monthText) = 0 Or Len(monthText) > 2 Then Exit Function
        If Not IsUnsignedIntegerText(monthText) Then Exit Function
        tmpMonth = CLng(monthText)
    End If
    If HasText(dayVal) Then
        If Not ParseMonthDay(dayVal, tmpMonth, tmpDay) Then
            dayText = NormalizeNumberText(CellText(dayVal))
            If Len(dayText) = 0 Or Len(dayText) > 2 Then Exit Function
            If Not IsUnsignedIntegerText(dayText) Then Exit Function
            tmpDay = CLng(dayText)
        End If
    End If
    If tmpYear = 0 Or tmpMonth = 0 Or tmpDay = 0 Then Exit Function
    If tmpMonth < 1 Or tmpMonth > 12 Or tmpDay < 1 Or tmpDay > 31 Then Exit Function
    d = DateSerial(tmpYear, tmpMonth, tmpDay)
    If Year(d) <> tmpYear Or Month(d) <> tmpMonth Or Day(d) <> tmpDay Then GoTo InvalidDate
    currentYear = tmpYear
    currentMonth = tmpMonth
    currentDay = tmpDay
    ResolveInputDate = d
    ok = True
    Exit Function
InvalidDate:
    ResolveInputDate = ""
End Function

Public Function NormalizeTimeInput(ByVal v As Variant, ByRef ok As Boolean) As Variant
    Dim s As String
    Dim i As Long, j As Long
    Dim h As Long
    Dim m As Long
    Dim parts As Variant, partText As String, ch As String
    ok = False
    On Error GoTo InvalidTime
    '空セルのEmptyを数値0（00:00）として扱わない。時刻未入力は常に空欄のまま返す。
    If IsError(v) Then GoTo InvalidTime
    If IsNull(v) Or IsEmpty(v) Then
        NormalizeTimeInput = ""
        ok = True
        Exit Function
    End If
    If VarType(v) = vbDate Then
        '日付付き日時を時刻欄へ誤投入しても、時刻部分だけを黙って採用しない。
        If CDbl(CDate(v)) < 0 Or CDbl(CDate(v)) >= 1 Then GoTo InvalidTime
        If Second(CDate(v)) <> 0 Then GoTo InvalidTime
        NormalizeTimeInput = TimeSerial(Hour(CDate(v)), Minute(CDate(v)), 0)
        ok = True
        Exit Function
    End If
    '数値文字列の「0.5」をExcel時刻シリアルとして誤解釈しない。
    '実際の数値セルだけをシリアル値として扱い、文字列はHHMM/HH:MMへ限定する。
    If VarType(v) <> vbString And VarType(v) <> vbBoolean And IsNumeric(v) Then
        If CDbl(v) >= 0 And CDbl(v) < 1 Then
            If Second(CDate(v)) <> 0 Then GoTo InvalidTime
            NormalizeTimeInput = TimeSerial(Hour(CDate(v)), Minute(CDate(v)), 0)
            ok = True
            Exit Function
        End If
    End If
    s = CellText(v)
    If Len(s) = 0 Then
        NormalizeTimeInput = ""
        ok = True
        Exit Function
    End If
    On Error Resume Next
    s = StrConv(s, vbNarrow)
    On Error GoTo InvalidTime
    s = Replace(s, "：", ":")
    s = Trim$(s)
    If InStr(1, s, " ", vbBinaryCompare) > 0 Or InStr(1, s, "　", vbBinaryCompare) > 0 Then _
        GoTo InvalidTime
    If InStr(1, s, ":", vbBinaryCompare) > 0 Then
        'IsDate任せにすると24:00や日付文字列を環境依存で受け付けるため、時・分を明示検査する。
        parts = Split(s, ":")
        If UBound(parts) <> 1 Then GoTo InvalidTime
        For i = LBound(parts) To UBound(parts)
            partText = CStr(parts(i))
            If Len(partText) = 0 Or Len(partText) > 2 Then GoTo InvalidTime
            For j = 1 To Len(partText)
                ch = Mid$(partText, j, 1)
                If ch < "0" Or ch > "9" Then GoTo InvalidTime
            Next j
        Next i
        h = CLng(parts(0))
        m = CLng(parts(1))
        If h < 0 Or h > 23 Or m < 0 Or m > 59 Then _
            GoTo InvalidTime
        NormalizeTimeInput = TimeSerial(h, m, 0)
        ok = True
        Exit Function
    End If
    If Len(s) > 4 Then
        NormalizeTimeInput = v
        Exit Function
    End If
    For i = 1 To Len(s)
        If Mid$(s, i, 1) < "0" Or Mid$(s, i, 1) > "9" Then
            NormalizeTimeInput = v
            Exit Function
        End If
    Next i
    s = Right$("0000" & s, 4)
    h = CLng(Left$(s, 2))
    m = CLng(Right$(s, 2))
    If h < 0 Or h > 23 Or m < 0 Or m > 59 Then
        NormalizeTimeInput = v
        Exit Function
    End If
    NormalizeTimeInput = TimeSerial(h, m, 0)
    ok = True
    Exit Function
InvalidTime:
    ok = False
    NormalizeTimeInput = v
End Function

Public Function NextBranchAccountNo(ByVal accountNo As String) As String
    Dim s As String
    Dim baseNo As String
    Dim suffixText As String
    Dim p As Long
    Dim suffixNo As Long
    Dim suffixWidth As Long
    Dim suffixValue As Double
    s = NormalizeAccountHyphen(CellText(accountNo))
    If Len(s) = 0 Then
        NextBranchAccountNo = ""
        Exit Function
    End If
    p = InStrRev(s, "-")
    If p > 0 Then
        baseNo = Left$(s, p - 1)
        suffixText = Mid$(s, p + 1)
        If Len(baseNo) > 0 And Len(suffixText) <= 10 And IsUnsignedIntegerText(suffixText) Then
            suffixValue = CDbl(suffixText)
            If suffixValue = Fix(suffixValue) And suffixValue >= 0 And suffixValue <= 2147483646# Then
                suffixWidth = Len(suffixText)
                suffixNo = CLng(suffixValue) + 1
                If suffixWidth > 1 Then
                    NextBranchAccountNo = baseNo & "-" & Format$(suffixNo, String$(suffixWidth, "0"))
                Else
                    NextBranchAccountNo = baseNo & "-" & CStr(suffixNo)
                End If
                Exit Function
            End If
        End If
    End If
    NextBranchAccountNo = s & "-1"
End Function

Public Function ResolveAccountDateInput(ByVal v As Variant, ByRef ok As Boolean) As Variant
    '口座開設日・解約日の入力補助用。
    '取引明細の年入力とは別に、昭和・平成・令和を明示できる「元号コード.年.月.日」を優先して解釈する。
    '例：1.53.5.6=昭和53年5月6日、2.31.4.30=平成31年4月30日、3.1.5.1=令和元年5月1日。
    '元号コードは設定シートの元号マスタで管理するため、新元号はマスタに1行追加すれば対応できる。
    Dim s As String
    Dim cleaned As String
    Dim parts As Variant
    Dim y As Long, m As Long, d As Long
    Dim yearOK As Boolean
    Dim yAdd As Long
    Dim normalizedDate As Variant

    ok = False
    If VarType(v) = vbDate Then
        normalizedDate = NormalizeDateOnlyValue(v, ok)
        If ok Then ResolveAccountDateInput = normalizedDate
        Exit Function
    End If
    s = CellText(v)
    If Len(s) = 0 Then
        ResolveAccountDateInput = ""
        ok = True
        Exit Function
    End If

    On Error Resume Next
    s = StrConv(s, vbNarrow)
    On Error GoTo 0
    s = UCase$(s)
    s = Replace(s, " ", "")
    s = Replace(s, "　", "")
    s = Replace(s, "．", ".")
    s = Replace(s, "。", ".")
    s = Replace(s, "・", ".")
    s = Replace(s, "-", "/")
    s = Replace(s, ".", "/")
    s = Replace(s, "年", "/")
    s = Replace(s, "月", "/")
    s = Replace(s, "日", "")
    yAdd = GetCfgLong(ROW_CFG_YEAR_ADD, 2000)

    If InStr(1, s, "/", vbTextCompare) > 0 Then
        parts = Split(s, "/")

        '元号コード付き入力。例：1/53/5/6、2/31/4/30、3/1/5/1。
        If UBound(parts) = 3 Then
            ResolveAccountDateInput = ResolveEraCodeDateInput(parts(0), parts(1), parts(2), parts(3), ok)
            Exit Function
        End If

        '従来互換。例：31/4/30、R1/5/1、2019/5/1。
        '余分な区切りを含む入力を先頭3要素だけで日付化しない。
        If UBound(parts) <> 2 Then Exit Function
        y = NormalizeYearInput(parts(0), yAdd, yearOK)
        If Not yearOK Then Exit Function
        If Not IsUnsignedIntegerText(CStr(parts(1))) Then Exit Function
        If Not IsUnsignedIntegerText(CStr(parts(2))) Then Exit Function
        If Len(CStr(parts(1))) > 2 Or Len(CStr(parts(2))) > 2 Then Exit Function
        m = CLng(parts(1))
        d = CLng(parts(2))
        ResolveAccountDateInput = MakeCheckedDate(y, m, d, ok)
        Exit Function
    End If

    cleaned = Replace(s, "/", "")
    If IsUnsignedIntegerText(cleaned) Then
        Select Case Len(cleaned)
            Case 8
                y = CLng(Left$(cleaned, 4))
                m = CLng(Mid$(cleaned, 5, 2))
                d = CLng(Right$(cleaned, 2))
            Case 6
                y = NormalizeYearInput(Left$(cleaned, 2), yAdd, yearOK)
                If Not yearOK Then Exit Function
                m = CLng(Mid$(cleaned, 3, 2))
                d = CLng(Right$(cleaned, 2))
            Case 5
                'R1年5月1日を 10501 と打つケース用。昭和など古い開設日は元号コード付き入力を推奨。
                y = NormalizeYearInput(Left$(cleaned, 1), yAdd, yearOK)
                If Not yearOK Then Exit Function
                m = CLng(Mid$(cleaned, 2, 2))
                d = CLng(Right$(cleaned, 2))
            Case Else
                If IsDate(s) Then
                    ResolveAccountDateInput = NormalizeDateOnlyValue(s, ok)
                End If
                Exit Function
        End Select
        ResolveAccountDateInput = MakeCheckedDate(y, m, d, ok)
        Exit Function
    End If

    If IsDate(s) Then
        ResolveAccountDateInput = NormalizeDateOnlyValue(s, ok)
    End If
End Function

Private Function ResolveEraCodeDateInput( _
    ByVal eraKey As String, _
    ByVal eraYearText As String, _
    ByVal monthText As String, _
    ByVal dayText As String, _
    ByRef ok As Boolean _
) As Variant
    '元号コード付き日付を西暦日付に変換する。
    '年は「元」も1年として扱う。元号の開始日・終了日から外れる場合は無効にする。
    Dim eraName As String
    Dim eraAbbr As String
    Dim startDate As Date
    Dim endDate As Date
    Dim hasEndDate As Boolean
    Dim eraYear As Long
    Dim m As Long
    Dim d As Long
    Dim westernYear As Long
    Dim dt As Variant

    ok = False
    eraYearText = NormalizeNumberText(eraYearText)
    If eraYearText = "元" Then eraYearText = "1"
    If Not IsUnsignedIntegerText(eraYearText) Then Exit Function
    If Not IsUnsignedIntegerText(CStr(monthText)) Then Exit Function
    If Not IsUnsignedIntegerText(CStr(dayText)) Then Exit Function
    If Len(eraYearText) > 4 Or Len(CStr(monthText)) > 2 Or Len(CStr(dayText)) > 2 Then Exit Function

    eraYear = CLng(eraYearText)
    m = CLng(monthText)
    d = CLng(dayText)
    If eraYear <= 0 Then Exit Function

    If Not TryGetEraInfoByKey(eraKey, eraName, eraAbbr, startDate, endDate, hasEndDate) Then Exit Function

    westernYear = Year(startDate) + eraYear - 1
    dt = MakeCheckedDate(westernYear, m, d, ok)
    If Not ok Or Not IsDate(dt) Then Exit Function

    If CDate(dt) < startDate Then
        ok = False
        ResolveEraCodeDateInput = ""
        Exit Function
    End If
    If hasEndDate Then
        If CDate(dt) > endDate Then
            ok = False
            ResolveEraCodeDateInput = ""
            Exit Function
        End If
    End If

    ResolveEraCodeDateInput = CDate(dt)
    ok = True
End Function

Public Function TryGetEraInfoByKey( _
    ByVal eraKey As String, _
    ByRef eraName As String, _
    ByRef eraAbbr As String, _
    ByRef startDate As Date, _
    ByRef endDate As Date, _
    ByRef hasEndDate As Boolean _
) As Boolean
    '設定シートの元号マスタから元号情報を取得する。
    '一致条件は「元号コード」「元号名」「略称」。設定シートが未整備の場合は昭和・平成・令和の既定値へフォールバックする。
    Dim ws As Worksheet
    Dim r As Long
    Dim key As String
    Dim codeText As String
    Dim nameText As String
    Dim abbrText As String
    Dim enabledText As String

    key = NormalizeEraKey(eraKey)
    If Len(key) = 0 Then Exit Function

    On Error Resume Next
    Set ws = GetSheet(SH_CONFIG)
    On Error GoTo 0

    If Not ws Is Nothing Then
        For r = ERA_MASTER_FIRST_ROW To ERA_MASTER_MAX_ROW
            codeText = NormalizeEraKey(CellText(ws.Cells(r, ERA_COL_CODE).Value))
            nameText = NormalizeEraKey(CellText(ws.Cells(r, ERA_COL_NAME).Value))
            abbrText = NormalizeEraKey(CellText(ws.Cells(r, ERA_COL_ABBR).Value))
            If Len(codeText) = 0 And Len(nameText) = 0 And Len(abbrText) = 0 Then
                '空行は将来元号の追加入力欄なので読み飛ばす。
            ElseIf key = codeText Or key = nameText Or key = abbrText Then
                enabledText = UCase$(CellText(ws.Cells(r, ERA_COL_ENABLED).Value))
                If enabledText = "FALSE" Or enabledText = "0" Or enabledText = "無効" Then Exit Function
                If Not IsDate(ws.Cells(r, ERA_COL_START).Value) Then Exit Function

                eraName = CellText(ws.Cells(r, ERA_COL_NAME).Value)
                eraAbbr = CellText(ws.Cells(r, ERA_COL_ABBR).Value)
                startDate = CDate(ws.Cells(r, ERA_COL_START).Value)
                If IsDate(ws.Cells(r, ERA_COL_END).Value) Then
                    endDate = CDate(ws.Cells(r, ERA_COL_END).Value)
                    hasEndDate = True
                Else
                    endDate = 0
                    hasEndDate = False
                End If
                TryGetEraInfoByKey = True
                Exit Function
            End If
        Next r
    End If

    'フォールバック。設定シートを壊した場合でも、既存3元号は最低限使えるようにする。
    Select Case key
        Case "1", "S", "昭和"
            eraName = "昭和": eraAbbr = "S": startDate = DateSerial(1926, 12, 25): endDate = DateSerial(1989, 1, 7): hasEndDate = True
        Case "2", "H", "平成"
            eraName = "平成": eraAbbr = "H": startDate = DateSerial(1989, 1, 8): endDate = DateSerial(2019, 4, 30): hasEndDate = True
        Case "3", "R", "令和"
            eraName = "令和": eraAbbr = "R": startDate = DateSerial(2019, 5, 1): endDate = 0: hasEndDate = False
        Case Else
            Exit Function
    End Select
    TryGetEraInfoByKey = True
End Function

Private Function NormalizeEraKey(ByVal s As String) As String
    On Error Resume Next
    s = StrConv(s, vbNarrow)
    On Error GoTo 0
    s = UCase$(Trim$(s))
    s = Replace(s, " ", "")
    s = Replace(s, "　", "")
    NormalizeEraKey = s
End Function

Private Function MakeCheckedDate(ByVal y As Long, ByVal m As Long, ByVal d As Long, ByRef ok As Boolean) As Variant
    Dim dt As Date
    ok = False
    If y < 1900 Or y > 9999 Or m < 1 Or m > 12 Or d < 1 Or d > 31 Then Exit Function
    On Error GoTo InvalidDate
    dt = DateSerial(y, m, d)
    If Year(dt) <> y Or Month(dt) <> m Or Day(dt) <> d Then GoTo InvalidDate
    MakeCheckedDate = dt
    ok = True
    Exit Function
InvalidDate:
    MakeCheckedDate = ""
End Function

Public Function NormalizedAccountDateForUse(ByVal v As Variant) As Variant
    '転記処理・残高欄制御用。入力途中の文字列でも日付として読めるものは実日付に寄せる。
    Dim ok As Boolean
    Dim d As Variant
    d = ResolveAccountDateInput(v, ok)
    If ok Then
        If IsDate(d) Then
            NormalizedAccountDateForUse = CDate(d)
            Exit Function
        End If
    End If
    NormalizedAccountDateForUse = ""
End Function

Public Function NormalizeAccountDateEntry(ByVal targetCell As Range) As Boolean
    '開設日・解約日セルの入力直後に、和暦数字入力を見やすい yyyy/m/d 表示へ整える。
    '日付は文字列ではなくExcelの日付値として保持し、後続の残高制御・出力でも安定して扱う。
    Dim ok As Boolean
    Dim d As Variant
    NormalizeAccountDateEntry = False
    If targetCell Is Nothing Then Exit Function
    If targetCell.HasFormula Then Exit Function
    If IsError(targetCell.Value) Then Exit Function
    d = ResolveAccountDateInput(targetCell.Value, ok)
    If Not ok Then Exit Function
    If IsDate(d) Then
        targetCell.NumberFormatLocal = "yyyy/m/d"
        targetCell.Value = CDate(d)
    End If
    NormalizeAccountDateEntry = True
End Function

Public Function AccountExistsAtDate(ByVal targetDate As Variant, ByVal openDate As Variant, ByVal closeDate As Variant) As Boolean
    '指定基準日に口座が存在していたかを判定する。
    '開設日前・解約日後の残高は入力欄ではロックし、残高推移表では「-」表示にする。
    If Not IsDate(targetDate) Then
        AccountExistsAtDate = True
        Exit Function
    End If
    If IsDate(openDate) Then
        If CDate(targetDate) < CDate(openDate) Then Exit Function
    End If
    If IsDate(closeDate) Then
        If CDate(targetDate) > CDate(closeDate) Then Exit Function
    End If
    AccountExistsAtDate = True
End Function

Public Function IsBalancePlaceholder(ByVal valueIn As Variant) As Boolean
    '過去版が入力セルへ書き込んだ表示用ハイフンを、利用者の残高値として扱わない。
    Dim s As String
    s = Trim$(CellText(valueIn))
    'U+2014 EM DASHはVBE標準のCP932で直接保持できないため、ChrWで判定する。
    IsBalancePlaceholder = (s = "-" Or s = "－" Or s = "―" Or s = ChrW$(&H2014))
End Function

Public Sub ApplyBalanceAvailability(ByVal ws As Worksheet)
    '開設日・解約日に応じて残高入力欄を制御する。
    '存在しない期間の残高欄は、入力不可・選択不可・薄色表示にして、Tab移動でも飛ばす。
    Dim memoCol As Long
    Dim c As Long
    Dim openDate As Variant
    Dim closeDate As Variant
    Dim balDate As Variant
    Dim enabled As Boolean

    If ws Is Nothing Then Exit Sub
    If ws.Name <> SH_INPUT Then Exit Sub

    memoCol = BalanceMemoCol(ws)
    openDate = NormalizedAccountDateForUse(ws.Range(CELL_OPEN_DATE).Value)
    closeDate = NormalizedAccountDateForUse(ws.Range(CELL_CLOSE_DATE).Value)

    For c = BAL_FIRST_COL To memoCol - 1
        balDate = ws.Cells(BAL_DATE_ROW, c).Value
        enabled = AccountExistsAtDate(balDate, openDate, closeDate)
        ApplySingleBalanceInputState ws, c, enabled
    Next c
End Sub

Private Sub ApplySingleBalanceInputState(ByVal ws As Worksheet, ByVal c As Long, ByVal enabled As Boolean)
    Dim valueCell As Range
    If ws Is Nothing Then Exit Sub
    Set valueCell = ws.Cells(BAL_VALUE_ROW, c)

    If enabled Then
        If IsBalancePlaceholder(valueCell.Value) Then valueCell.ClearContents
        valueCell.Locked = False
        valueCell.NumberFormatLocal = "#,##0.########"
        valueCell.Interior.Color = RGB(248, 250, 252)
        valueCell.Font.Color = RGB(15, 23, 42)
        ws.Cells(BAL_LABEL_ROW, c).Interior.Color = RGB(219, 234, 254)
        ws.Cells(BAL_LABEL_ROW, c).Font.Color = RGB(30, 64, 175)
        ws.Cells(BAL_DATE_ROW, c).Interior.Color = RGB(241, 245, 249)
        ws.Cells(BAL_DATE_ROW, c).Font.Color = RGB(71, 85, 105)
    Else
        '日付を変更しただけで入力済み残高を失わないよう、値は保持して表示だけを無効化する。
        '旧版の表示用ハイフンは実データではないため消去する。
        If IsBalancePlaceholder(valueCell.Value) Then valueCell.ClearContents
        valueCell.Locked = True
        valueCell.NumberFormatLocal = """-"";""-"";""-"";""-"""
        valueCell.Interior.Color = RGB(241, 245, 249)
        valueCell.Font.Color = RGB(71, 85, 105)
        ws.Cells(BAL_LABEL_ROW, c).Interior.Color = RGB(229, 231, 235)
        ws.Cells(BAL_LABEL_ROW, c).Font.Color = RGB(71, 85, 105)
        ws.Cells(BAL_DATE_ROW, c).Interior.Color = RGB(243, 244, 246)
        ws.Cells(BAL_DATE_ROW, c).Font.Color = RGB(71, 85, 105)
    End If
End Sub

Public Function ValidateBalanceInputStructure(ByVal ws As Worksheet, ByRef detailText As String) As Boolean
    '残高データの構造だけを検査する。折りたたみや表示幅はデータ不整合ではない。
    '表示の事後条件はApplyInputBalancePresentationが確認し、表示差だけで
    'EnsureBalanceInputStructureCurrentから入力済み残高の再生成を要求しない。
    Dim memoCol As Long
    Dim c As Long
    Dim problems As String
    Dim expectedLabels As Collection, expectedDates As Collection
    Dim expectedIndex As Long
    Dim expectedLabel As String
    Dim startYear As Long, endYear As Long
    Dim labelArea As Range, valueArea As Range
    Dim expectedAddress As String
    If ws Is Nothing Then
        detailText = "入力シートを取得できません。"
        Exit Function
    End If
    If Not ValidateBalanceYearSettings(startYear, endYear, detailText) Then Exit Function
    memoCol = BalanceMemoCol(ws)
    If memoCol <= BAL_FIRST_COL Or memoCol > BAL_MAX_COL Then problems = problems & "その他欄の位置が不正です。 "
    BuildBalanceCollections expectedLabels, expectedDates
    CapBalanceCollections expectedLabels, expectedDates, BAL_MAX_LABELS
    If memoCol - BAL_FIRST_COL <> expectedDates.Count Then problems = problems & "設定と残高列数が一致しません。残高欄を再生成してください。 "
    For c = BAL_FIRST_COL To memoCol - 1
        expectedIndex = c - BAL_FIRST_COL + 1
        If Len(CellText(ws.Cells(BAL_LABEL_ROW, c).Value)) = 0 Then problems = problems & ws.Cells(BAL_LABEL_ROW, c).Address(False, False) & "の見出しなし。 "
        If expectedIndex <= expectedLabels.Count Then
            expectedLabel = BalanceInputLabelDisplay(CStr(expectedLabels(expectedIndex)))
            If CellText(ws.Cells(BAL_LABEL_ROW, c).Value) <> CellText(expectedLabel) Then
                problems = problems & ws.Cells(BAL_LABEL_ROW, c).Address(False, False) & "の見出しが設定と不一致。 "
            End If
        End If
        If Not IsDate(ws.Cells(BAL_DATE_ROW, c).Value) Then problems = problems & ws.Cells(BAL_DATE_ROW, c).Address(False, False) & "の基準日不正。 "
        If expectedIndex <= expectedDates.Count And IsDate(ws.Cells(BAL_DATE_ROW, c).Value) Then
            If CLng(CDate(ws.Cells(BAL_DATE_ROW, c).Value)) <> CLng(CDate(expectedDates(expectedIndex))) Then
                problems = problems & ws.Cells(BAL_DATE_ROW, c).Address(False, False) & "が設定上の基準日と不一致。 "
            End If
        End If
        If ws.Cells(BAL_LABEL_ROW, c).MergeCells Then _
            problems = problems & ws.Cells(BAL_LABEL_ROW, c).Address(False, False) & "の残高見出しが他列と結合されています。 "
        If ws.Cells(BAL_VALUE_ROW, c).MergeCells Then _
            problems = problems & ws.Cells(BAL_VALUE_ROW, c).Address(False, False) & "の残高入力欄が他列と結合されています。 "
        If ws.Cells(BAL_DATE_ROW, c).MergeCells Then _
            problems = problems & ws.Cells(BAL_DATE_ROW, c).Address(False, False) & "の基準日が他列と結合されています。 "
    Next c
    If CellText(ws.Cells(BAL_LABEL_ROW, memoCol).Value) <> "その他" Then problems = problems & "その他欄の見出し不正。 "
    If memoCol < BAL_MAX_COL Then
        expectedAddress = ws.Range(ws.Cells(BAL_LABEL_ROW, memoCol), _
                                   ws.Cells(BAL_LABEL_ROW, BAL_MAX_COL)).Address(False, False)
        Set labelArea = EffectiveRange(ws.Cells(BAL_LABEL_ROW, memoCol))
        If labelArea Is Nothing Or Not ws.Cells(BAL_LABEL_ROW, memoCol).MergeCells Then
            problems = problems & "その他欄の見出し結合が解除されています。 "
        ElseIf labelArea.Address(False, False) <> expectedAddress Then
            problems = problems & "その他欄の見出し結合範囲が不正です。 "
        End If

        expectedAddress = ws.Range(ws.Cells(BAL_VALUE_ROW, memoCol), _
                                   ws.Cells(BAL_VALUE_ROW, BAL_MAX_COL)).Address(False, False)
        Set valueArea = EffectiveRange(ws.Cells(BAL_VALUE_ROW, memoCol))
        If valueArea Is Nothing Or Not ws.Cells(BAL_VALUE_ROW, memoCol).MergeCells Then
            problems = problems & "その他欄の入力結合が解除されています。 "
        ElseIf valueArea.Address(False, False) <> expectedAddress Then
            problems = problems & "その他欄の入力結合範囲が不正です。 "
        End If
    Else
        If ws.Cells(BAL_LABEL_ROW, memoCol).MergeCells Or ws.Cells(BAL_VALUE_ROW, memoCol).MergeCells Then _
            problems = problems & "最終列のその他欄に不要な結合があります。 "
    End If
    detailText = Trim$(problems)
    ValidateBalanceInputStructure = (Len(detailText) = 0)
End Function

Public Function RequireWritableWorkbook(ByVal actionName As String) As Boolean
    If Not ThisWorkbook.ReadOnly Then
        RequireWritableWorkbook = True
        Exit Function
    End If
    MsgBox "このブックは読み取り専用です。" & vbCrLf & _
           actionName & "を行う場合は、書き込み可能な場所へ別名保存してください。", _
           vbExclamation, "読み取り専用のため実行できません"
End Function

Public Function HasPendingBalanceInputValues(ByVal ws As Worksheet) As Boolean
    '設定変更時に残高入力を黙って消さないための軽量判定。数式・エラー値も入力ありと扱う。
    If ws Is Nothing Then Exit Function
    On Error GoTo AssumePending
    HasPendingBalanceInputValues = (Application.WorksheetFunction.CountA( _
        ws.Range(ws.Cells(BAL_VALUE_ROW, BAL_FIRST_COL), _
                 ws.Cells(BAL_VALUE_ROW, BAL_MAX_COL))) > 0)
    Exit Function
AssumePending:
    HasPendingBalanceInputValues = True
End Function

Public Function EnsureCaseReadyForOutputs(Optional ByVal showMessage As Boolean = True) As Boolean
    Dim inheritDate As Variant
    inheritDate = GetCfgDateValue(ROW_CFG_INHERITANCE_DATE)
    If Not IsDate(inheritDate) Then
        If showMessage Then
            MsgBox "設定シートの相続開始日を入力してから帳票・分析を更新してください。" & vbCrLf & _
                   "案件ごとに異なる重要な基準日のため、自動補完はしません。", vbExclamation, "相続開始日が未設定です"
        End If
        Exit Function
    End If
    EnsureCaseReadyForOutputs = True
End Function

Public Function FirstAvailableBalanceInputCell(ByVal ws As Worksheet) As Range
    Dim memoCol As Long
    Dim c As Long
    If ws Is Nothing Then Exit Function
    memoCol = BalanceMemoCol(ws)
    For c = BAL_FIRST_COL To memoCol - 1
        If Not ws.Cells(BAL_VALUE_ROW, c).Locked Then
            Set FirstAvailableBalanceInputCell = ws.Cells(BAL_VALUE_ROW, c)
            Exit Function
        End If
    Next c
    Set FirstAvailableBalanceInputCell = ws.Cells(BAL_VALUE_ROW, memoCol)
End Function

Public Function NextAvailableBalanceInputCell(ByVal ws As Worksheet, ByVal currentCol As Long, ByVal backwards As Boolean) As Range
    Dim memoCol As Long
    Dim c As Long
    If ws Is Nothing Then Exit Function
    memoCol = BalanceMemoCol(ws)

    If backwards Then
        For c = currentCol - 1 To BAL_FIRST_COL Step -1
            If Not ws.Cells(BAL_VALUE_ROW, c).Locked Then
                Set NextAvailableBalanceInputCell = ws.Cells(BAL_VALUE_ROW, c)
                Exit Function
            End If
        Next c
        Set NextAvailableBalanceInputCell = ws.Range(CELL_CLOSE_DATE)
    Else
        For c = currentCol + 1 To memoCol - 1
            If Not ws.Cells(BAL_VALUE_ROW, c).Locked Then
                Set NextAvailableBalanceInputCell = ws.Cells(BAL_VALUE_ROW, c)
                Exit Function
            End If
        Next c
        If currentCol < memoCol Then
            Set NextAvailableBalanceInputCell = ws.Cells(BAL_VALUE_ROW, memoCol)
        Else
            Set NextAvailableBalanceInputCell = ws.Cells(TX_FIRST_ROW, COL_TX_YEAR)
        End If
    End If
End Function

Public Function NormalizeAccountHyphen(ByVal accountNo As String) As String
    Dim s As String
    s = Trim$(accountNo)
    s = Replace(s, "－", "-")
    s = Replace(s, "―", "-")
    s = Replace(s, "ー", "-")
    s = Replace(s, "ｰ", "-")
    NormalizeAccountHyphen = s
End Function

Public Function ValidateBalanceYearSettings(ByRef startYear As Long, ByRef endYear As Long, _
                                            ByRef detailText As String) As Boolean
    Dim startValue As Double, endValue As Double
    detailText = ""
    On Error GoTo InvalidValue
    If Not IsNumeric(GetCfgCell(ROW_CFG_BAL_START_YEAR).Value) Or _
       Not IsNumeric(GetCfgCell(ROW_CFG_BAL_END_YEAR).Value) Then
        detailText = "残高表示開始年・終了年は西暦の数値で入力してください。"
        Exit Function
    End If
    startValue = CDbl(GetCfgCell(ROW_CFG_BAL_START_YEAR).Value)
    endValue = CDbl(GetCfgCell(ROW_CFG_BAL_END_YEAR).Value)
    If startValue <> Fix(startValue) Or endValue <> Fix(endValue) Then
        detailText = "残高表示開始年・終了年は整数で入力してください。"
        Exit Function
    End If
    If startValue < 1900 Or startValue > 9999 Or endValue < 1900 Or endValue > 9999 Then
        detailText = "残高表示開始年・終了年は1900～9999の範囲で入力してください。"
        Exit Function
    End If
    startYear = CLng(startValue)
    endYear = CLng(endValue)
    If startYear > endYear Then
        detailText = "残高表示開始年は終了年以前にしてください。"
        Exit Function
    End If
    ValidateBalanceYearSettings = True
    Exit Function
InvalidValue:
    detailText = "残高表示開始年・終了年を解釈できません。"
End Function

Public Sub BuildBalanceCollections(ByRef labels As Collection, ByRef dates As Collection)
    Dim startYear As Long
    Dim endYear As Long
    Dim loopStartYear As Long
    Dim inheritDate As Variant
    Dim y As Long
    Dim dYearEnd As Date
    Dim eventAdded As Boolean
    Dim labelText As String
    Dim yearDetail As String
    Set labels = New Collection
    Set dates = New Collection
    If Not ValidateBalanceYearSettings(startYear, endYear, yearDetail) Then
        Err.Raise vbObjectError + 1825, "BuildBalanceCollections", yearDetail
    End If
    loopStartYear = startYear
    If endYear - startYear + 1 > BAL_MAX_LABELS Then loopStartYear = endYear - BAL_MAX_LABELS + 1
    inheritDate = GetCfgDateValue(ROW_CFG_INHERITANCE_DATE)
    For y = loopStartYear To endYear
        dYearEnd = DateSerial(y, 12, 31)
        If IsDate(inheritDate) Then
            If Not eventAdded And CDate(inheritDate) < dYearEnd Then
                labels.Add "相続開始日時点" & vbLf & "残高（" & Format$(CDate(inheritDate), "yyyy/m/d") & "）"
                dates.Add CDate(inheritDate)
                eventAdded = True
            End If
            If CDate(inheritDate) = dYearEnd Then
                labelText = CStr(y) & "年末・相続開始日時点" & vbLf & "残高（" & Format$(CDate(inheritDate), "yyyy/m/d") & "）"
                eventAdded = True
            Else
                labelText = CStr(y) & "年末残高"
            End If
        Else
            labelText = CStr(y) & "年末残高"
        End If
        labels.Add labelText
        dates.Add dYearEnd
    Next y
    If IsDate(inheritDate) And Not eventAdded Then
        labels.Add "相続開始日時点" & vbLf & "残高（" & Format$(CDate(inheritDate), "yyyy/m/d") & "）"
        dates.Add CDate(inheritDate)
    End If
End Sub

Public Function BalanceMemoCol(ByVal ws As Worksheet) As Long
    Dim c As Long
    If ws Is Nothing Then
        BalanceMemoCol = BAL_MAX_COL
        Exit Function
    End If
    For c = BAL_FIRST_COL To BAL_MAX_COL
        If CellText(ws.Cells(BAL_LABEL_ROW, c).Value) = "その他" Then
            BalanceMemoCol = c
            Exit Function
        End If
    Next c
    BalanceMemoCol = BAL_MAX_COL
End Function

Public Function EffectiveRange(ByVal rng As Range) As Range
    If rng Is Nothing Then Exit Function
    On Error Resume Next
    If rng.MergeCells Then
        Set EffectiveRange = rng.MergeArea
    Else
        Set EffectiveRange = rng
    End If
    On Error GoTo 0
End Function

Public Function BalanceMemoInputRange(ByVal ws As Worksheet) As Range
    '「その他」は表示上1入力欄だが、Excel内部では結合範囲または複数物理セルになり得る。
    'どちらでも右端V列までを同じ入力欄として扱い、規則・ロックの欠落を残さない。
    Dim memoCol As Long
    If ws Is Nothing Then Exit Function
    memoCol = BalanceMemoCol(ws)
    If memoCol < BAL_FIRST_COL Or memoCol > BAL_MAX_COL Then Exit Function
    Set BalanceMemoInputRange = ws.Range(ws.Cells(BAL_VALUE_ROW, memoCol), _
                                         ws.Cells(BAL_VALUE_ROW, BAL_MAX_COL))
End Function

Public Function IsSingleMergeArea(ByVal target As Range) As Boolean
    '結合入力欄は複数の物理セルで構成されても、利用者にとっては1入力欄である。
    'ExcelビルドによってSpecialCellsが左上セルだけを返す場合があるため識別する。
    Dim mergedArea As Range
    If target Is Nothing Then Exit Function
    On Error GoTo EH
    If target.Areas.Count <> 1 Then Exit Function
    If Not target.Cells(1, 1).MergeCells Then Exit Function
    Set mergedArea = target.Cells(1, 1).MergeArea
    If mergedArea Is Nothing Then Exit Function
    IsSingleMergeArea = _
        (StrComp(target.Address(False, False), _
                 mergedArea.Address(False, False), vbTextCompare) = 0)
    Exit Function
EH:
    IsSingleMergeArea = False
End Function

Public Function ValidationRangeHasUniformCriteria(ByVal target As Range, _
                                                  ByRef resultKnown As Boolean) As Boolean
    '同じ種類・数式・演算子の入力規則で範囲全体が統一されているかを、
    '対象Range内のxlCellTypeSameValidationで確認する。単一セルでは呼ばない。
    Dim sameValidationCells As Range, coveredCells As Range
    Dim errorNumber As Long
    resultKnown = False
    If target Is Nothing Then Exit Function
    If CDbl(target.CountLarge) <= 1 Or IsSingleMergeArea(target) Then
        resultKnown = True
        ValidationRangeHasUniformCriteria = True
        Exit Function
    End If
    On Error Resume Next
    Err.Clear
    '比較基準を対象範囲の左上セルへ固定する。単一セル呼出しがシート全体へ
    '広がるビルドでも、直後のIntersectで対象Range内だけを採用する。
    Set sameValidationCells = _
        target.Cells(1, 1).SpecialCells(xlCellTypeSameValidation)
    errorNumber = Err.Number
    Err.Clear
    If errorNumber = 0 And Not sameValidationCells Is Nothing Then _
        Set coveredCells = Intersect(target, sameValidationCells)
    If Err.Number <> 0 Then errorNumber = Err.Number
    Err.Clear
    On Error GoTo 0
    If errorNumber <> 0 Or sameValidationCells Is Nothing Then Exit Function
    If coveredCells Is Nothing Then Exit Function
    If CDbl(coveredCells.CountLarge) = CDbl(target.CountLarge) Then
        resultKnown = True
        ValidationRangeHasUniformCriteria = True
    End If
End Function

Public Sub ApplyValidationInputOnly(ByVal rng As Range, ByVal imeMode As Long, _
                                    Optional ByVal inputTitle As String = "", _
                                    Optional ByVal inputMessage As String = "")
    Dim target As Range, validationCells As Range, coveredCells As Range
    Dim typeValue As Variant, lastTypeValue As Variant
    Dim errorNumber As Long, errorDescription As String
    Dim specialCellsErrorNumber As Long
    Dim targetText As String
    If rng Is Nothing Then _
        Err.Raise vbObjectError + 1027, "ApplyValidationInputOnly", "入力規則の対象範囲がありません。"
    On Error GoTo EH
    Set target = EffectiveRange(rng)
    If target Is Nothing Then Set target = rng
    targetText = target.Worksheet.Name & "!" & target.Address(False, False)
    On Error Resume Next
    target.Validation.Delete
    Err.Clear
    On Error GoTo EH
    target.Validation.Add Type:=xlValidateInputOnly
    target.Validation.IgnoreBlank = True

    '結合入力欄は左上セルのValidationを代表値として扱う。
    If CDbl(target.CountLarge) > 1 And Not IsSingleMergeArea(target) Then
        On Error Resume Next
        Err.Clear
        Set validationCells = target.SpecialCells(xlCellTypeAllValidation)
        specialCellsErrorNumber = Err.Number
        Err.Clear
        If Not validationCells Is Nothing Then Set coveredCells = Intersect(target, validationCells)
        If Err.Number <> 0 Then specialCellsErrorNumber = Err.Number
        Err.Clear
        On Error GoTo EH
        'Validation.Add自体は範囲へ一括適用される。SpecialCellsの読戻しAPIは
        '環境差が大きいため参考情報に留め、APIの件数差を作成失敗へすり替えない。
        If specialCellsErrorNumber = 0 And Not validationCells Is Nothing And _
           Not coveredCells Is Nothing Then
            'SpecialCellsは正常な大量範囲でも部分集合を返すOfficeビルドがある。
            'Validation.Addは範囲へ原子的に適用されるため、この互換APIの件数差だけで
            Err.Clear
        ElseIf specialCellsErrorNumber = 0 And Not validationCells Is Nothing Then
            'Intersect取得不能も同様に、入力規則本体の読戻しへ委ねる。
            Err.Clear
        End If
    End If
    typeValue = target.Cells(1, 1).Validation.Type
    If IsNull(typeValue) Then
        Err.Raise vbObjectError + 1029, "ApplyValidationInputOnly", _
                  "入力規則の種類を確認できませんでした。"
    ElseIf CLng(typeValue) <> xlValidateInputOnly Then
        Err.Raise vbObjectError + 1029, "ApplyValidationInputOnly", _
                  "入力規則の種類を確認できませんでした。"
    End If
    If CDbl(target.CountLarge) > 1 And Not IsSingleMergeArea(target) Then
        lastTypeValue = target.Cells(target.Rows.Count, target.Columns.Count).Validation.Type
        If IsNull(lastTypeValue) Then
            Err.Raise vbObjectError + 1029, "ApplyValidationInputOnly", _
                      "入力規則の右下セルを確認できませんでした。"
        ElseIf CLng(lastTypeValue) <> xlValidateInputOnly Then
            Err.Raise vbObjectError + 1029, "ApplyValidationInputOnly", _
                      "入力規則の右下セルを確認できませんでした。"
        End If
    End If

    'IMEと入力メッセージはExcel言語・Officeビルド差があるため、
    '規則本体の作成確認後にbest-effortで設定する。
    On Error Resume Next
    Err.Clear
    target.Validation.IMEMode = imeMode
    target.Validation.ShowInput = (Len(inputTitle) > 0 Or Len(inputMessage) > 0)
    If Len(inputTitle) > 0 Then target.Validation.InputTitle = inputTitle
    If Len(inputMessage) > 0 Then target.Validation.InputMessage = inputMessage
    Err.Clear
    On Error GoTo 0
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    Err.Raise errorNumber, "ApplyValidationInputOnly(" & targetText & ")", errorDescription
End Sub

Public Function SetToolShapePrintState(ByVal ws As Worksheet, ByVal shapeName As String, _
                                       ByVal printEnabled As Boolean) As Boolean
    '画面操作用の図形を帳票へ印刷しない。DrawingObjectを遅延バインドし、
    'オートシェイプとフォームボタンの双方を同じ方法で扱う。
    Dim drawingObjects As Object
    Dim drawingObject As Object
    Dim controlFormat As Object
    Dim shapeObject As Object
    If ws Is Nothing Or Len(shapeName) = 0 Then Exit Function
    '既定プロパティを介した ws.DrawingObjects(name) はOfficeビルド差の影響を
    '受けることがあるため、コレクションとItemを明示して取得する。
    On Error Resume Next
    Err.Clear
    Set drawingObjects = Nothing
    Set drawingObject = Nothing
    Set drawingObjects = ws.DrawingObjects
    Set drawingObject = drawingObjects.Item(shapeName)
    If Err.Number = 0 And Not drawingObject Is Nothing Then
        drawingObject.PrintObject = printEnabled
        If Err.Number = 0 Then _
            SetToolShapePrintState = (CBool(drawingObject.PrintObject) = printEnabled)
    End If
    If SetToolShapePrintState Then
        On Error GoTo 0
        Exit Function
    End If

    'Shape側が公開するDrawingObjectも遅延バインドで試す。
    Err.Clear
    Set shapeObject = Nothing
    Set drawingObject = Nothing
    Set shapeObject = ws.Shapes(shapeName)
    Set drawingObject = shapeObject.DrawingObject
    If Err.Number = 0 And Not drawingObject Is Nothing Then
        drawingObject.PrintObject = printEnabled
        If Err.Number = 0 Then _
            SetToolShapePrintState = (CBool(drawingObject.PrintObject) = printEnabled)
    End If
    If SetToolShapePrintState Then
        On Error GoTo 0
        Exit Function
    End If

    'フォームコントロールへフォールバックした場合はControlFormatにも
    'PrintObjectがある。オートシェイプでは利用できないため最後に試す。
    Err.Clear
    Set controlFormat = Nothing
    Set controlFormat = shapeObject.ControlFormat
    If Err.Number = 0 And Not controlFormat Is Nothing Then
        controlFormat.PrintObject = printEnabled
        If Err.Number = 0 Then _
            SetToolShapePrintState = (CBool(controlFormat.PrintObject) = printEnabled)
    End If
    Err.Clear
    On Error GoTo 0
End Function

Public Function ToolShapePrintState(ByVal ws As Worksheet, ByVal shapeName As String, _
                                    ByRef stateKnown As Boolean) As Boolean
    Dim drawingObjects As Object
    Dim drawingObject As Object
    Dim controlFormat As Object
    Dim shapeObject As Object
    stateKnown = False
    If ws Is Nothing Or Len(shapeName) = 0 Then Exit Function
    On Error Resume Next
    Err.Clear
    Set drawingObjects = Nothing
    Set drawingObject = Nothing
    Set drawingObjects = ws.DrawingObjects
    Set drawingObject = drawingObjects.Item(shapeName)
    If Err.Number = 0 And Not drawingObject Is Nothing Then
        ToolShapePrintState = CBool(drawingObject.PrintObject)
        stateKnown = (Err.Number = 0)
    End If
    If stateKnown Then
        On Error GoTo 0
        Exit Function
    End If

    Err.Clear
    Set shapeObject = Nothing
    Set drawingObject = Nothing
    Set shapeObject = ws.Shapes(shapeName)
    Set drawingObject = shapeObject.DrawingObject
    If Err.Number = 0 And Not drawingObject Is Nothing Then
        ToolShapePrintState = CBool(drawingObject.PrintObject)
        stateKnown = (Err.Number = 0)
    End If
    If stateKnown Then
        On Error GoTo 0
        Exit Function
    End If

    Err.Clear
    Set controlFormat = Nothing
    Set controlFormat = shapeObject.ControlFormat
    If Err.Number = 0 And Not controlFormat Is Nothing Then
        ToolShapePrintState = CBool(controlFormat.PrintObject)
        stateKnown = (Err.Number = 0)
    End If
    Err.Clear
    On Error GoTo 0
End Function

Public Sub ApplyValidationList(ByVal rng As Range, ByVal listName As String, _
                               ByVal imeMode As Long, _
                               Optional ByVal allowFreeText As Boolean = True, _
                               Optional ByVal inputTitle As String = "", _
                               Optional ByVal inputMessage As String = "")
    Dim target As Range, listRange As Range, validationCells As Range, coveredCells As Range
    Dim typeValue As Variant, formulaValue As Variant, showErrorValue As Variant
    Dim lastTypeValue As Variant, lastFormulaValue As Variant, lastShowErrorValue As Variant
    Dim errorNumber As Long, errorDescription As String
    Dim specialCellsErrorNumber As Long
    Dim targetText As String
    If rng Is Nothing Then _
        Err.Raise vbObjectError + 1030, "ApplyValidationList", "入力規則の対象範囲がありません。"
    On Error GoTo EH
    Set target = EffectiveRange(rng)
    If target Is Nothing Then Set target = rng
    targetText = target.Worksheet.Name & "!" & target.Address(False, False)
    Set listRange = ThisWorkbook.Names(listName).RefersToRange
    If listRange Is Nothing Then _
        Err.Raise vbObjectError + 1031, "ApplyValidationList", _
                  "候補の定義名を参照できません: " & listName
    On Error Resume Next
    target.Validation.Delete
    Err.Clear
    On Error GoTo EH
    target.Validation.Add Type:=xlValidateList, AlertStyle:=xlValidAlertStop, Formula1:="=" & listName
    target.Validation.IgnoreBlank = True
    target.Validation.InCellDropdown = True
    target.Validation.ShowError = Not allowFreeText

    '結合入力欄は物理セル数ではなく、左上の1入力欄として読戻す。
    If CDbl(target.CountLarge) > 1 And Not IsSingleMergeArea(target) Then
        On Error Resume Next
        Err.Clear
        Set validationCells = target.SpecialCells(xlCellTypeAllValidation)
        specialCellsErrorNumber = Err.Number
        Err.Clear
        If Not validationCells Is Nothing Then Set coveredCells = Intersect(target, validationCells)
        If Err.Number <> 0 Then specialCellsErrorNumber = Err.Number
        Err.Clear
        On Error GoTo EH
        If specialCellsErrorNumber = 0 And Not validationCells Is Nothing And _
           Not coveredCells Is Nothing Then
            'SpecialCellsの件数差はOfficeビルド差があるため失敗条件にしない。
            '規則種別・参照先・候補外入力設定は直後に代表セルから厳格に読戻す。
            Err.Clear
        ElseIf specialCellsErrorNumber = 0 And Not validationCells Is Nothing Then
            'Intersect取得不能も規則本体の読戻しへ委ねる。
            Err.Clear
        End If
    End If
    typeValue = target.Cells(1, 1).Validation.Type
    formulaValue = target.Cells(1, 1).Validation.Formula1
    showErrorValue = target.Cells(1, 1).Validation.ShowError
    If IsNull(typeValue) Then
        Err.Raise vbObjectError + 1033, "ApplyValidationList", _
                  "候補入力規則の種類を確認できませんでした。"
    ElseIf CLng(typeValue) <> xlValidateList Then
        Err.Raise vbObjectError + 1033, "ApplyValidationList", _
                  "候補入力規則の種類を確認できませんでした。"
    End If
    If IsNull(formulaValue) Then
        Err.Raise vbObjectError + 1034, "ApplyValidationList", _
                  "候補入力規則の参照先を確認できません: " & listName
    ElseIf Not ValidationListSourceMatches(target.Cells(1, 1), CellText(formulaValue), listName) Then
        Err.Raise vbObjectError + 1034, "ApplyValidationList", _
                  "候補入力規則の参照先を確認できません。期待: =" & listName & _
                  " / 実際: " & ValidationFormulaDiagnostic(CellText(formulaValue))
    End If
    If IsNull(showErrorValue) Then
        Err.Raise vbObjectError + 1035, "ApplyValidationList", _
                  "候補外入力の許可設定を確認できません。"
    ElseIf CBool(showErrorValue) <> (Not allowFreeText) Then
        Err.Raise vbObjectError + 1035, "ApplyValidationList", _
                  "候補外入力の許可設定を確認できません。"
    End If
    If CDbl(target.CountLarge) > 1 And Not IsSingleMergeArea(target) Then
        With target.Cells(target.Rows.Count, target.Columns.Count).Validation
            lastTypeValue = .Type
            lastFormulaValue = .Formula1
            lastShowErrorValue = .ShowError
        End With
        If IsNull(lastTypeValue) Then
            Err.Raise vbObjectError + 1033, "ApplyValidationList", _
                      "候補入力規則の右下セルを確認できませんでした。"
        ElseIf CLng(lastTypeValue) <> xlValidateList Then
            Err.Raise vbObjectError + 1033, "ApplyValidationList", _
                      "候補入力規則の右下セルを確認できませんでした。"
        End If
        If IsNull(lastFormulaValue) Then
            Err.Raise vbObjectError + 1034, "ApplyValidationList", _
                      "候補入力規則の右下セルの参照先を確認できません: " & listName
        ElseIf Not ValidationListSourceMatches( _
                       target.Cells(target.Rows.Count, target.Columns.Count), _
                       CellText(lastFormulaValue), listName) Then
            Err.Raise vbObjectError + 1034, "ApplyValidationList", _
                      "候補入力規則の右下セルの参照先を確認できません: " & listName
        End If
        If IsNull(lastShowErrorValue) Then
            Err.Raise vbObjectError + 1035, "ApplyValidationList", _
                      "候補入力規則の右下セルの候補外入力設定を確認できません。"
        ElseIf CBool(lastShowErrorValue) <> (Not allowFreeText) Then
            Err.Raise vbObjectError + 1035, "ApplyValidationList", _
                      "候補入力規則の右下セルの候補外入力設定を確認できません。"
        End If
    End If

    'IMEと入力メッセージは規則本体の成否から分離する。
    On Error Resume Next
    Err.Clear
    target.Validation.IMEMode = imeMode
    target.Validation.ShowInput = (Len(inputTitle) > 0 Or Len(inputMessage) > 0)
    If Len(inputTitle) > 0 Then target.Validation.InputTitle = inputTitle
    If Len(inputMessage) > 0 Then target.Validation.InputMessage = inputMessage
    Err.Clear
    On Error GoTo 0
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    Err.Raise errorNumber, "ApplyValidationList(" & targetText & ", " & listName & ")", errorDescription
End Sub

Public Function ValidationListSourceMatches(ByVal target As Range, ByVal formulaText As String, _
                                            ByVal expectedListName As String) As Boolean
    'ExcelはValidation.Formula1を、定義名だけ、ブック修飾、引用符付き、
    'または直接Range参照として返すことがある。文字列完全一致ではなく参照先で判定する。
    Dim expectedRange As Range, actualRange As Range
    Dim candidateText As String
    If target Is Nothing Or Len(expectedListName) = 0 Then Exit Function
    On Error Resume Next
    Set expectedRange = ThisWorkbook.Names(expectedListName).RefersToRange
    On Error GoTo 0
    If expectedRange Is Nothing Then Exit Function

    candidateText = Trim$(formulaText)
    If Len(candidateText) > 0 Then
        If Left$(candidateText, 1) = "=" Then candidateText = Trim$(Mid$(candidateText, 2))
    End If
    If Len(candidateText) > 0 Then
        If Left$(candidateText, 1) = "@" Then candidateText = Trim$(Mid$(candidateText, 2))
    End If
    On Error Resume Next
    Err.Clear
    '先頭@はMicrosoft 365が読戻し時に付ける暗黙交差表記であり、
    '候補Range全体の意味比較では除去した式を先に評価する。
    If Len(candidateText) > 0 Then _
        Set actualRange = target.Worksheet.Evaluate("=" & candidateText)
    If actualRange Is Nothing Then Set actualRange = target.Worksheet.Evaluate(formulaText)
    Err.Clear
    On Error GoTo 0
    If actualRange Is Nothing Then Exit Function
    If StrComp(actualRange.Worksheet.Parent.Name, ThisWorkbook.Name, vbTextCompare) <> 0 Then Exit Function
    If StrComp(actualRange.Worksheet.Name, expectedRange.Worksheet.Name, vbTextCompare) <> 0 Then Exit Function
    If StrComp(actualRange.Address(True, True, xlA1, False), _
               expectedRange.Address(True, True, xlA1, False), vbTextCompare) <> 0 Then Exit Function
    ValidationListSourceMatches = True
End Function

Public Function ValidationFormulaDiagnostic(ByVal formulaText As String) As String
    Dim diagnosticText As String
    diagnosticText = Replace(formulaText, vbCr, " ")
    diagnosticText = Replace(diagnosticText, vbLf, " ")
    If Len(diagnosticText) = 0 Then diagnosticText = "（空欄）"
    ValidationFormulaDiagnostic = Left$(diagnosticText, 255)
End Function

Public Sub UnlockRange(ByVal rng As Range)
    Dim target As Range
    If rng Is Nothing Then Exit Sub
    Set target = EffectiveRange(rng)
    If target Is Nothing Then Set target = rng
    On Error Resume Next
    target.Locked = False
    On Error GoTo 0
End Sub

Public Sub MergeAndFormat(ByVal rng As Range, ByVal valueText As String, Optional ByVal mergeCells As Boolean = True)
    If rng Is Nothing Then Exit Sub
    On Error Resume Next
    rng.UnMerge
    If mergeCells Then rng.Merge
    rng.Value = valueText
    rng.WrapText = True
    rng.VerticalAlignment = xlCenter
    On Error GoTo 0
End Sub


Public Sub ClearEffectiveContents(ByVal rng As Range)
    Dim target As Range
    If rng Is Nothing Then Exit Sub
    Set target = EffectiveRange(rng)
    If target Is Nothing Then Set target = rng
    On Error Resume Next
    target.ClearContents
    On Error GoTo 0
End Sub

Public Sub AutoFitSheetSmart(ByVal ws As Worksheet, Optional ByVal columnsAddress As String = "", Optional ByVal minWidth As Double = 6, Optional ByVal maxWidth As Double = 34)
    '列幅・行高の自動調整。UsedRangeが肥大しているブックでも重くならないよう、
    '値・数式が入っている実範囲を基準にする。
    Dim rngCols As Range
    Dim rngRows As Range
    Dim c As Range
    Dim r As Range
    Dim lastR As Long
    Dim lastC As Long
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    lastR = LastUsedRowInSheet(ws)
    If lastR < 1 Then lastR = 1
    lastC = LastUsedColumnInSheet(ws, lastR)
    If lastC < 1 Then lastC = 1

    '列全体のAutoFitは各列104万セルを対象にし得る。実データ先頭2,000行だけを
    '代表範囲として測り、その後に設計上の上下限を適用する。
    If Len(columnsAddress) > 0 Then
        Set rngCols = Application.Intersect( _
            ws.Columns(columnsAddress), _
            ws.Range(ws.Rows(1), ws.Rows(Application.Min(lastR, MAX_DETAILED_AUTOFIT_ROWS))))
    Else
        Set rngCols = ws.Range(ws.Cells(1, 1), _
                              ws.Cells(Application.Min(lastR, MAX_DETAILED_AUTOFIT_ROWS), lastC))
    End If
    If Not rngCols Is Nothing Then
        rngCols.AutoFit
        For Each c In rngCols.Columns
            If c.ColumnWidth < minWidth Then c.ColumnWidth = minWidth
            If c.ColumnWidth > maxWidth Then c.ColumnWidth = maxWidth
        Next c
    End If

    Set rngRows = ws.Range(ws.Rows(1), ws.Rows(lastR))
    If lastR <= MAX_DETAILED_AUTOFIT_ROWS Then
        rngRows.AutoFit
        For Each r In rngRows.Rows
            If r.RowHeight < 18 Then r.RowHeight = 18
            If r.RowHeight > 72 Then r.RowHeight = 72
        Next r
    Else
        '大量行では行ごとのAutoFitと高さ検査を避け、安定した一覧高さへ一括設定する。
        rngRows.RowHeight = 20
        ws.Rows(1).AutoFit
    End If
    On Error GoTo 0
End Sub

Public Sub PolishInputLayout(Optional ByVal ws As Worksheet = Nothing, _
                             Optional ByVal raiseOnError As Boolean = False)
    Dim errorNumber As Long, errorDescription As String
    Dim detailsExpandedBefore As Boolean
    On Error GoTo EH
    If ws Is Nothing Then
        If Not SheetExists(SH_INPUT) Then Exit Sub
        Set ws = GetSheet(SH_INPUT)
    End If
    '行高の設定で非表示行が再表示されても、利用者が選んだ開閉状態を保つ。
    detailsExpandedBefore = InputDetailsExpanded(ws)
    ApplyInputColumnWidths ws
    ApplyInputDetailsRowVisibility ws, detailsExpandedBefore
    ApplyInputBalancePresentation ws
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    If raiseOnError Then _
        Err.Raise errorNumber, "PolishInputLayout", errorDescription
    Err.Clear
End Sub
Private Sub ApplyInputColumnWidths(ByVal ws As Worksheet)
    If ws Is Nothing Then Exit Sub
    '入力内容に合わせて幅を変え、年・月・日へ不要な余白を持たせない。
    '金額、取扱店、摘要は入力中の確認に必要な幅を優先する。
    ws.Columns("A:A").ColumnWidth = 1.5
    ws.Columns("B:B").ColumnWidth = INPUT_WIDTH_B
    ws.Columns("C:C").ColumnWidth = INPUT_WIDTH_C
    ws.Columns("D:D").ColumnWidth = INPUT_WIDTH_D
    ws.Columns("E:E").ColumnWidth = INPUT_WIDTH_E
    ws.Columns("F:G").ColumnWidth = INPUT_WIDTH_F_TO_G
    ws.Columns("H:H").ColumnWidth = INPUT_WIDTH_H
    ws.Columns("I:I").ColumnWidth = INPUT_WIDTH_I
    ws.Columns("J:J").ColumnWidth = INPUT_WIDTH_J
    ws.Columns("K:K").ColumnWidth = INPUT_WIDTH_K
    ws.Columns("L:P").ColumnWidth = INPUT_WIDTH_L_TO_P
    ws.Columns("Q:V").ColumnWidth = INPUT_WIDTH_Q_TO_V
    ws.Columns("W:W").ColumnWidth = 1.5

    ws.Rows("1:1").RowHeight = 3
    ws.Rows("2:" & CStr(TX_HEADER_ROW)).RowHeight = 20
    ws.Rows(2).RowHeight = 29
    ws.Rows(3).RowHeight = 29
    ws.Rows(4).RowHeight = 18
    ws.Rows("5:7").RowHeight = 26
    ws.Rows(8).RowHeight = 4
    ws.Rows(INPUT_BALANCE_HEADER_ROW).RowHeight = 18
    '残高見出しは「相続開始日時点／残高（yyyy/m/d）」等の3～4行を切らない。
    'FormatBalanceInputAreaと同じ値にし、後続のPolishで縮めない。
    ws.Rows(BAL_LABEL_ROW).RowHeight = 48
    ws.Rows(BAL_VALUE_ROW).RowHeight = 25
    ws.Rows(BAL_DATE_ROW).RowHeight = 18
    ws.Rows(INPUT_STATUS_ROW).RowHeight = 30
    ws.Rows(TX_HEADER_ROW - 1).RowHeight = 3
    ws.Rows(TX_HEADER_ROW).RowHeight = 26
    ws.Rows(TX_FIRST_ROW & ":" & TX_LAST_ROW).RowHeight = 24

    ws.Range("B2:K" & CStr(INPUT_STATUS_ROW)).WrapText = True
    With ws.Range(ws.Cells(BAL_LABEL_ROW, BAL_FIRST_COL), ws.Cells(BAL_LABEL_ROW, BAL_MAX_COL))
        .WrapText = True
        .ShrinkToFit = False
        .Font.Size = 10
    End With
    With ws.Range(ws.Cells(BAL_VALUE_ROW, BAL_FIRST_COL), ws.Cells(BAL_VALUE_ROW, BAL_MAX_COL))
        .ShrinkToFit = False
        .Font.Size = 9.5
    End With
    '上部操作バーだけ折返しを切り、残高見出しの長い文字は切らない。
    ws.Range(ws.Cells(INPUT_PANEL_FIRST_ROW, INPUT_PANEL_FIRST_COL), _
             ws.Cells(INPUT_PANEL_LAST_ROW, INPUT_PANEL_LAST_COL)).WrapText = False
    With EffectiveRange(ws.Range(CELL_STATUS))
        .WrapText = True
        .ShrinkToFit = False
        .Font.Size = 10
        .HorizontalAlignment = xlLeft
        .VerticalAlignment = xlCenter
    End With
    ws.Range(ws.Cells(TX_FIRST_ROW, COL_TX_YEAR), _
             ws.Cells(TX_LAST_ROW, COL_TX_BALANCE)).WrapText = False
    ws.ScrollArea = "A1:W" & CStr(TX_LAST_ROW)
End Sub

Public Function InputDetailsExpanded(ByVal ws As Worksheet) As Boolean
    If ws Is Nothing Then Exit Function
    On Error GoTo EH
    InputDetailsExpanded = Not CBool(ws.Rows(INPUT_BALANCE_HEADER_ROW).Hidden)
    Exit Function
EH:
    InputDetailsExpanded = False
End Function

Private Sub ApplyInputDetailsRowVisibility(ByVal ws As Worksheet, ByVal expanded As Boolean)
    '詳細情報と残高は一つの開閉操作として扱う。値・書式・結合は変更しない。
    Dim r As Long
    ws.Rows("7:" & CStr(BAL_DATE_ROW)).Hidden = Not expanded
    For r = 7 To BAL_DATE_ROW
        If CBool(ws.Rows(r).Hidden) = expanded Then _
            Err.Raise vbObjectError + 4451, "ApplyInputDetailsRowVisibility", _
                      "詳細・残高欄の表示を切り替えられませんでした: " & CStr(r) & "行"
    Next r
End Sub

Public Sub SetInputDetailsExpanded(ByVal ws As Worksheet, ByVal expanded As Boolean, _
                                   Optional ByVal protectAfter As Boolean = True)
    Dim originallyExpanded As Boolean
    Dim originalRowHidden(7 To BAL_DATE_ROW) As Boolean
    Dim r As Long
    Dim originalProtectContents As Boolean, originalProtectDrawingObjects As Boolean
    Dim originalStateCaptured As Boolean
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim recoveryStepErrorNumber As Long, recoveryStepErrorDescription As String
    Dim recoveryErrorNumber As Long, recoveryErrorDescription As String
    Dim recoveryDetail As String, recoveryStateMatches As Boolean
    Dim protectionStateMatches As Boolean, recoveryConfirmed As Boolean
    Dim applicationStateSafe As Boolean, safeToRestoreEntry As Boolean
    Dim recoveryHardBarrierDetected As Boolean
    Dim entryEvents As Boolean, entryEventsCaptured As Boolean
    Dim mutationStarted As Boolean, cleanupEventsStopped As Boolean
    Dim eventStateDetail As String, eventRestoreDetail As String
    Dim postEnforceEventDetail As String, convergenceDetail As String
    Dim appStateProblems As String
    Dim eventsRestored As Boolean, finalEventsStopped As Boolean
    If ws Is Nothing Then Exit Sub
    On Error GoTo EH
    '表示・保護・図形キャプションの変更より先に、この呼出し自身が
    'EnableEventsの開始値を捕捉し、Falseの書込みと読戻しを確定する。
    If Not TryGetInputDetailsEnableEvents(entryEvents, eventStateDetail) Then _
        Err.Raise vbObjectError + 4456, "SetInputDetailsExpanded", _
                  "表示切替開始前のイベント状態を一意に保存できません。 " & _
                  eventStateDetail
    entryEventsCaptured = True
    If Not TrySetInputDetailsEnableEventsExact(False, eventStateDetail) Then _
        Err.Raise vbObjectError + 4457, "SetInputDetailsExpanded", _
                  "表示切替中のイベント停止を一意に確認できません。 " & _
                  eventStateDetail
    '範囲全体のHiddenは表示／非表示が混在するとNullになる。行単位で保存する。
    For r = 7 To BAL_DATE_ROW
        originalRowHidden(r) = CBool(ws.Rows(r).Hidden)
    Next r
    originalProtectContents = ws.ProtectContents
    originalProtectDrawingObjects = ws.ProtectDrawingObjects
    originallyExpanded = Not originalRowHidden(INPUT_BALANCE_HEADER_ROW)
    originalStateCaptured = True
    mutationStarted = True
    ws.Unprotect Password:=TOOL_PASSWORD

    '利用者の入力値を変えず、行列と見出し幅だけを切り替える。
    ApplyInputDetailsRowVisibility ws, expanded
    ApplyInputBalancePresentation ws

    '閉じる範囲に選択が残るとキー入力の手応えがなくなるため、明細先頭へ戻す。
    If Not expanded Then
        If ActiveWorkbook Is ThisWorkbook Then
            If TypeName(ActiveSheet) = "Worksheet" Then
                If ActiveSheet.Name = ws.Name Then
                    If (ActiveCell.Row >= 7 And ActiveCell.Row <= BAL_DATE_ROW) Or _
                       ActiveCell.Column > INPUT_SCREEN_LAST_COL Then _
                        Application.Goto ws.Cells(TX_FIRST_ROW, COL_TX_YEAR), False
                    If Not Application.ActiveWindow Is Nothing Then _
                        Application.ActiveWindow.ScrollColumn = 1
                End If
            End If
        End If
    End If

    If protectAfter Then
        If Not TryFormattingCleanupStep( _
                   "INPUT", "入力シートの再保護", recoveryDetail, _
                   recoveryHardBarrierDetected) Then
            If recoveryHardBarrierDetected Then _
                Err.Raise UTILITIES_RECOVERY_HARD_BARRIER_ERROR, _
                          "SetInputDetailsExpanded", recoveryDetail
            Err.Raise vbObjectError + 4461, "SetInputDetailsExpanded", _
                      "入力シートを安全に再保護できません。 " & _
                      recoveryDetail
        End If
        If Not TryHoldInputDetailsEventsStopped(eventStateDetail) Then _
            Err.Raise vbObjectError + 4460, "SetInputDetailsExpanded", _
                      "入力シート再保護後のイベント停止を確認できません。 " & _
                      eventStateDetail
        If Not ws.ProtectContents Or Not ws.ProtectDrawingObjects Then _
            Err.Raise vbObjectError + 4461, "SetInputDetailsExpanded", _
                      "入力シート再保護後のセル・図形保護を読み戻せません。"
    End If
    RefreshMainActionCaption
    If Not TryHoldInputDetailsEventsStopped(eventStateDetail) Then _
        Err.Raise vbObjectError + 4462, "SetInputDetailsExpanded", _
                  "操作表示更新後のイベント停止を確認できません。 " & _
                  eventStateDetail
    If entryEvents Then
        appStateProblems = vbNullString
        If Not AppStateIsRestored(appStateProblems) Then _
            Err.Raise vbObjectError + 4463, "SetInputDetailsExpanded", _
                      "表示切替後のExcel全体状態を確認できません。 " & _
                      appStateProblems
    End If
    If Not TryRestoreInputDetailsEntryEvents( _
               entryEventsCaptured, entryEvents, eventRestoreDetail) Then _
        Err.Raise vbObjectError + 4458, "SetInputDetailsExpanded", _
                  "表示切替開始前のイベント状態を復元できません。 " & _
                  eventRestoreDetail
    entryEventsCaptured = False
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    If UtilitiesNestedRecoveryHardBarrierError( _
           errorNumber, errorSource) Then
        On Error Resume Next
        Call TryHoldInputDetailsEventsStopped(eventStateDetail)
        On Error GoTo 0
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    On Error Resume Next
    cleanupEventsStopped = False
    If entryEventsCaptured Then
        eventStateDetail = vbNullString
        cleanupEventsStopped = TryHoldInputDetailsEventsStopped(eventStateDetail)
    End If
    If recoveryHardBarrierDetected Then GoTo INPUT_DETAILS_HARD_BARRIER
    recoveryStateMatches = Not mutationStarted
    protectionStateMatches = Not mutationStarted
    'Falseをexactに確認できない場合は、ロールバック・再保護・状態表・
    'キャプションを含め、ワークブックへの書込みを一切行わない。
    If mutationStarted And cleanupEventsStopped And originalStateCaptured Then
        Err.Clear
        ws.Unprotect Password:=TOOL_PASSWORD
        If Err.Number <> 0 Then
            AppendUtilitiesSafetyDetail recoveryDetail, _
                "入力シートの保護解除: Err " & CStr(Err.Number) & _
                " " & Err.Description
            Err.Clear
        End If
        For r = 7 To BAL_DATE_ROW
            ws.Rows(r).Hidden = originalRowHidden(r)
        Next r
        If Err.Number <> 0 Then
            AppendUtilitiesSafetyDetail recoveryDetail, _
                "詳細行の表示復旧: Err " & CStr(Err.Number) & _
                " " & Err.Description
            Err.Clear
        End If
        ApplyInputBalancePresentation ws
        If Err.Number <> 0 Then
            AppendUtilitiesSafetyDetail recoveryDetail, _
                "残高欄の表示復旧: Err " & CStr(Err.Number) & _
                " " & Err.Description
            Err.Clear
        End If
        recoveryStateMatches = (InputDetailsExpanded(ws) = originallyExpanded)
        For r = 7 To BAL_DATE_ROW
            If CBool(ws.Rows(r).Hidden) <> originalRowHidden(r) Then _
                recoveryStateMatches = False
        Next r
        recoveryStepErrorNumber = Err.Number
        recoveryStepErrorDescription = Err.Description
        Err.Clear
        If recoveryStepErrorNumber <> 0 Or Not recoveryStateMatches Then
            AppendUtilitiesSafetyDetail recoveryDetail, _
                "詳細・残高欄の復旧状態を一意に確認できません" & _
                IIf(recoveryStepErrorNumber <> 0, "（Err " & _
                    CStr(recoveryStepErrorNumber) & " " & _
                    recoveryStepErrorDescription & "）", vbNullString)
        End If

        '開始時が標準の保護状態なら共通保護を再適用する。開始時が完全な
        '未保護なら未保護へ戻す。混在状態は推測で作らず未確認として扱う。
        protectionStateMatches = False
        If originalProtectContents And originalProtectDrawingObjects Then
            On Error GoTo 0
            protectionStateMatches = TryFormattingCleanupStep( _
                                         "INPUT", _
                                         "入力シートの再保護", _
                                         recoveryDetail, _
                                         recoveryHardBarrierDetected)
            On Error Resume Next
            If recoveryHardBarrierDetected Then
                GoTo INPUT_DETAILS_HARD_BARRIER
            End If
            cleanupEventsStopped = _
                TryHoldInputDetailsEventsStopped(eventStateDetail)
            If cleanupEventsStopped Then
                protectionStateMatches = _
                    protectionStateMatches And ws.ProtectContents And _
                    ws.ProtectDrawingObjects
                If Err.Number <> 0 Then protectionStateMatches = False
                Err.Clear
            End If
        ElseIf Not originalProtectContents And Not originalProtectDrawingObjects Then
            protectionStateMatches = _
                (Not ws.ProtectContents) And (Not ws.ProtectDrawingObjects)
            If Err.Number <> 0 Then protectionStateMatches = False
            Err.Clear
        Else
            AppendUtilitiesSafetyDetail recoveryDetail, _
                "開始時のセル保護と図形保護が混在しており、元の保護状態を再現できません。"
        End If
        If Not protectionStateMatches Then _
            AppendUtilitiesSafetyDetail recoveryDetail, _
                "入力シートの開始時保護状態を一意に読み戻せません。"

        If cleanupEventsStopped And recoveryStateMatches And _
           protectionStateMatches Then
            Err.Clear
            RefreshMainActionCaption
            If Err.Number <> 0 Then _
                AppendUtilitiesSafetyDetail recoveryDetail, _
                    "操作表示の復旧: Err " & CStr(Err.Number) & _
                    " " & Err.Description
            Err.Clear
            cleanupEventsStopped = _
                TryHoldInputDetailsEventsStopped(eventStateDetail)
        End If
        recoveryStateMatches = recoveryStateMatches And _
                               protectionStateMatches And _
                               cleanupEventsStopped
    ElseIf mutationStarted Then
        AppendUtilitiesSafetyDetail recoveryDetail, _
            "イベント停止または開始状態を確認できないため、" & _
            "表示・保護・復旧状態へ追加書込みをしていません。" & _
            IIf(Len(eventStateDetail) > 0, " " & eventStateDetail, vbNullString)
    End If

    '局所ロールバックが揃わない時だけRecoveryを要求する。共通処理の
    '終了時イベントは信用せず、Errを保存した直後にFalseを取り直す。
    If Not recoveryStateMatches And cleanupEventsStopped Then
        Err.Clear
        recoveryHardBarrierDetected = True
        EnforceRollbackRecoveryState recoveryDetail
        recoveryErrorNumber = Err.Number
        recoveryErrorDescription = Err.Description
        Err.Clear
        Call TryHoldInputDetailsEventsStopped(postEnforceEventDetail)
        On Error GoTo 0
        Err.Raise UTILITIES_RECOVERY_HARD_BARRIER_ERROR, _
                  "SetInputDetailsExpanded", errorDescription
    End If

    applicationStateSafe = Not entryEvents
    If entryEvents And cleanupEventsStopped And recoveryErrorNumber = 0 Then
        appStateProblems = vbNullString
        applicationStateSafe = AppStateIsRestored(appStateProblems)
        If Not applicationStateSafe Then _
            AppendUtilitiesSafetyDetail recoveryDetail, _
                "Excel全体状態を安全に復元済みと確認できません: " & _
                appStateProblems
    End If

    safeToRestoreEntry = cleanupEventsStopped And applicationStateSafe And _
                         (recoveryStateMatches Or recoveryConfirmed)
    finalEventsStopped = False
    If entryEventsCaptured Then _
        finalEventsStopped = _
            TryHoldInputDetailsEventsStopped(convergenceDetail)
    If Not finalEventsStopped And entryEventsCaptured Then _
        AppendUtilitiesSafetyDetail recoveryDetail, _
            "開始値復元直前のExcelイベント停止を確認できません: " & _
            convergenceDetail

    '開始値=Trueは安全根拠が揃う場合だけ戻す。開始値=Falseまたは安全未確認時は
    'Falseを維持し、以降はブックへ一切書き込まない。
    If entryEventsCaptured Then
        If Not entryEvents Then
            eventsRestored = finalEventsStopped
        ElseIf safeToRestoreEntry And finalEventsStopped Then
            eventRestoreDetail = vbNullString
            eventsRestored = TryRestoreInputDetailsEntryEvents( _
                                 entryEventsCaptured, entryEvents, _
                                 eventRestoreDetail)
            If Not eventsRestored Then _
                AppendUtilitiesSafetyDetail recoveryDetail, _
                    "イベント開始値の復元未完了: " & eventRestoreDetail
        Else
            AppendUtilitiesSafetyDetail recoveryDetail, _
                "表示・保護の局所復元またはRecoveryの二重確認が成立しないため、" & _
                "Excelイベントを開始値へ戻さずFalseで停止しました。"
        End If
    End If
    On Error GoTo 0
    GoTo INPUT_DETAILS_RAISE

INPUT_DETAILS_HARD_BARRIER:
    'nested helperが例外終了した場合、その内部Enforceが失敗した可能性を
    '外側から否定できない。以後はfresh False収束だけを許可する。
    finalEventsStopped = False
    convergenceDetail = vbNullString
    finalEventsStopped = _
        TryHoldInputDetailsEventsStopped(convergenceDetail)
    If finalEventsStopped Then
        AppendUtilitiesSafetyDetail recoveryDetail, _
            "nested復旧処理のhard barrier後はExcelイベントをFalseへ収束させました。"
    Else
        AppendUtilitiesSafetyDetail recoveryDetail, _
            "nested復旧処理のhard barrier後もExcelイベントをFalseへ収束できません: " & _
            convergenceDetail
    End If
    errorNumber = UTILITIES_RECOVERY_HARD_BARRIER_ERROR
    On Error GoTo 0

INPUT_DETAILS_RAISE:
    If Len(recoveryDetail) > 0 Then
        Err.Raise errorNumber, "SetInputDetailsExpanded", _
                  errorDescription & " / 表示復旧確認: " & Left$(recoveryDetail, 2000)
    End If
    Err.Raise errorNumber, "SetInputDetailsExpanded", errorDescription
End Sub

Private Function TryGetInputDetailsEnableEvents( _
        ByRef currentValue As Boolean, _
        ByRef detailText As String) As Boolean
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    detailText = vbNullString
    On Error GoTo EH
    currentValue = Application.EnableEvents
    TryGetInputDetailsEnableEvents = True
    Exit Function
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    detailText = "Err " & CStr(errorNumber) & ": " & errorDescription
    Err.Clear
End Function

Private Function TrySetInputDetailsEnableEventsExact( _
        ByVal desiredValue As Boolean, _
        ByRef detailText As String) As Boolean
    Dim errorNumber As Long, errorDescription As String
    detailText = vbNullString
    On Error GoTo EH
    Application.EnableEvents = desiredValue
    If Application.EnableEvents <> desiredValue Then _
        Err.Raise vbObjectError + 4459, _
                  "TrySetInputDetailsEnableEventsExact", _
                  "EnableEventsの書込み後読戻しが一致しません。"
    TrySetInputDetailsEnableEventsExact = True
    Exit Function
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    detailText = "Err " & CStr(errorNumber) & ": " & errorDescription
    Err.Clear
End Function

Private Function TryHoldInputDetailsEventsStopped( _
        ByRef detailText As String) As Boolean
    Dim firstDetail As String, retryDetail As String
    detailText = vbNullString
    If TrySetInputDetailsEnableEventsExact(False, firstDetail) Then
        TryHoldInputDetailsEventsStopped = True
        Exit Function
    End If
    If TrySetInputDetailsEnableEventsExact(False, retryDetail) Then
        TryHoldInputDetailsEventsStopped = True
        Exit Function
    End If
    detailText = "初回=" & firstDetail & " / 再試行=" & retryDetail
End Function

Private Function TryRestoreInputDetailsEntryEvents( _
        ByVal entryEventsCaptured As Boolean, _
        ByVal entryEvents As Boolean, _
        ByRef detailText As String) As Boolean
    Dim restoreDetail As String, safeStopDetail As String
    detailText = vbNullString
    If Not entryEventsCaptured Then
        detailText = "イベント開始値を取得できていません。"
        Exit Function
    End If
    If TrySetInputDetailsEnableEventsExact(entryEvents, restoreDetail) Then
        TryRestoreInputDetailsEntryEvents = True
        Exit Function
    End If
    If TrySetInputDetailsEnableEventsExact(entryEvents, restoreDetail) Then
        TryRestoreInputDetailsEntryEvents = True
        Exit Function
    End If
    detailText = "開始値への復元: " & restoreDetail
    If Not TrySetInputDetailsEnableEventsExact(False, safeStopDetail) Then _
        detailText = detailText & " / イベント安全停止: " & safeStopDetail
End Function

Public Function InputVisibleLastColumn(ByVal ws As Worksheet) As Long
    Dim memoCol As Long
    InputVisibleLastColumn = INPUT_SCREEN_LAST_COL
    If ws Is Nothing Then Exit Function
    If Not InputDetailsExpanded(ws) Then Exit Function
    memoCol = BalanceMemoCol(ws)
    If memoCol >= BAL_FIRST_COL Then
        InputVisibleLastColumn = Application.Max(INPUT_SCREEN_LAST_COL, _
            Application.Min(BAL_MAX_COL, memoCol + INPUT_BALANCE_MEMO_VISIBLE_COLS - 1))
    End If
End Function

Private Sub ApplyInputBalancePresentation(ByVal ws As Worksheet)
    '通常時はA:Kだけを表示し、詳細・残高の展開時だけ必要列を段階的に開く。
    Dim lastVisibleCol As Long, c As Long
    Dim headerArea As Range, visibleHeader As Range, effectiveHeader As Range
    Dim previousHeader As Range
    Dim previousHeaderAddress As String, previousHeaderValue As Variant
    Dim previousColumnHidden(BAL_FIRST_COL To BAL_MAX_COL) As Boolean
    Dim snapshotCaptured As Boolean
    Dim errorNumber As Long, errorDescription As String
    If ws Is Nothing Then Exit Sub
    On Error GoTo EH

    Set headerArea = ws.Range(ws.Cells(INPUT_BALANCE_HEADER_ROW, BAL_FIRST_COL), _
                              ws.Cells(INPUT_BALANCE_HEADER_ROW, BAL_MAX_COL))
    Set effectiveHeader = EffectiveRange(ws.Cells(INPUT_BALANCE_HEADER_ROW, BAL_FIRST_COL))
    If effectiveHeader Is Nothing Then
        previousHeaderAddress = ws.Cells(INPUT_BALANCE_HEADER_ROW, BAL_FIRST_COL).Address(False, False)
    Else
        previousHeaderAddress = effectiveHeader.Address(False, False)
    End If
    previousHeaderValue = ws.Cells(INPUT_BALANCE_HEADER_ROW, BAL_FIRST_COL).Formula
    For c = BAL_FIRST_COL To BAL_MAX_COL
        previousColumnHidden(c) = CBool(ws.Columns(c).Hidden)
    Next c
    snapshotCaptured = True

    ws.Range(ws.Columns(BAL_FIRST_COL), ws.Columns(BAL_MAX_COL)).EntireColumn.Hidden = False
    lastVisibleCol = InputVisibleLastColumn(ws)

    headerArea.UnMerge
    headerArea.ClearContents
    Set visibleHeader = ws.Range(ws.Cells(INPUT_BALANCE_HEADER_ROW, BAL_FIRST_COL), _
                                 ws.Cells(INPUT_BALANCE_HEADER_ROW, lastVisibleCol))
    MergeAndFormat visibleHeader, "残高入力"
    FormatHeader visibleHeader
    visibleHeader.HorizontalAlignment = xlLeft
    visibleHeader.VerticalAlignment = xlCenter

    If lastVisibleCol < BAL_MAX_COL Then
        ws.Range(ws.Columns(lastVisibleCol + 1), ws.Columns(BAL_MAX_COL)).EntireColumn.Hidden = True
    End If

    'MergeAndFormatは旧Office互換のため内部でResume Nextを使う。表示切替では
    '結果を必ず読み戻し、失敗を成功扱いにしない。
    Set effectiveHeader = EffectiveRange(ws.Cells(INPUT_BALANCE_HEADER_ROW, BAL_FIRST_COL))
    If effectiveHeader Is Nothing Then
        Err.Raise vbObjectError + 4452, "ApplyInputBalancePresentation", _
                  "残高見出しを確認できませんでした。"
    End If
    If effectiveHeader.Address(False, False) <> visibleHeader.Address(False, False) Or _
       CellText(ws.Cells(INPUT_BALANCE_HEADER_ROW, BAL_FIRST_COL).Value) <> "残高入力" Then _
        Err.Raise vbObjectError + 4453, "ApplyInputBalancePresentation", _
                  "残高見出しの結合または表示文字を確認できませんでした。"
    For c = BAL_FIRST_COL To lastVisibleCol
        If ws.Columns(c).Hidden Then _
            Err.Raise vbObjectError + 4454, "ApplyInputBalancePresentation", _
                      "必要な入力列を表示できませんでした: " & _
                      ws.Cells(BAL_VALUE_ROW, c).Address(False, False)
    Next c
    For c = lastVisibleCol + 1 To BAL_MAX_COL
        If Not ws.Columns(c).Hidden Then _
            Err.Raise vbObjectError + 4455, "ApplyInputBalancePresentation", _
                      "未使用の残高列を非表示にできませんでした: " & _
                      ws.Cells(BAL_VALUE_ROW, c).Address(False, False)
    Next c
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    On Error Resume Next
    If snapshotCaptured Then
        ws.Range(ws.Columns(BAL_FIRST_COL), ws.Columns(BAL_MAX_COL)).EntireColumn.Hidden = False
        headerArea.UnMerge
        headerArea.ClearContents
        Set previousHeader = ws.Range(previousHeaderAddress)
        If previousHeader.Cells.CountLarge > 1 Then previousHeader.Merge
        previousHeader.Cells(1, 1).Formula = previousHeaderValue
        FormatHeader previousHeader
        For c = BAL_FIRST_COL To BAL_MAX_COL
            ws.Columns(c).Hidden = previousColumnHidden(c)
        Next c
    End If
    On Error GoTo 0
    Err.Raise errorNumber, "ApplyInputBalancePresentation", errorDescription
End Sub
Public Sub AutoFitInputSheetSmart(ByVal ws As Worksheet)
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    '入力表は固定設計幅を正本とする。空の1万行をAutoFitしてから同じ幅へ戻す
    '二重処理を廃止し、入力値や明細件数によってボタン位置が変わらないようにする。
    PolishInputLayout ws
    BuildOperationPanel ws
    BuildInputHelpCards ws
    On Error GoTo 0
End Sub
Public Sub AutoFitToolLayout()
    '旧ボタン名・旧マクロ名との互換用。実体は書式復旧へ寄せる。
    RestoreToolFormatting
End Sub

Public Sub RestoreToolFormatting()
    Dim ws As Worksheet
    Dim candidateSheets As Variant, candidateName As Variant
    Dim balanceArea As Range
    Dim balanceSnapshot As Variant
    Dim balanceMemoColBefore As Long
    Dim balanceSignatureBefore As String
    Dim planProblems As String, appStateProblems As String, cleanupDetail As String
    Dim appLeaseOwned As Boolean, balanceSnapshotCaptured As Boolean
    Dim mutationStarted As Boolean, cleanupEventsStopped As Boolean
    Dim finalEventsStopped As Boolean, cleanupStepOK As Boolean
    Dim balanceRestored As Boolean, localConvergenceConfirmed As Boolean
    Dim recoveryConfirmed As Boolean, safeToRestoreEntry As Boolean
    Dim applicationStateRestored As Boolean
    Dim recoveryHardBarrierDetected As Boolean
    Dim entryEvents As Boolean, entryEventsCaptured As Boolean
    Dim eventStateDetail As String, postEnforceEventDetail As String
    Dim convergenceDetail As String
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim recoveryErrorNumber As Long, recoveryErrorDescription As String
    On Error GoTo EH
    'PLAN: 読み取り専用・案件状態・中核構造・入力内容の退避をすべて
    '確定してからApplication leaseを開始する。既存の外側leaseは強制終了しない。
    If Not RequireToolReady() Then Exit Sub
    If ThisWorkbook.ReadOnly Then _
        Err.Raise vbObjectError + 4403, "RestoreToolFormatting", _
                  "読み取り専用ブックの書式は変更できません。書き込み可能な場所へ別名保存してください。"
    If Not ValidateNormalSaveStructure(planProblems) Then _
        Err.Raise vbObjectError + 4404, "RestoreToolFormatting", _
                  "書式復旧の対象構造を事前確認できません。 " & _
                  Left$(Replace(planProblems, vbCrLf, " / "), 3000)
    Set ws = GetSheet(SH_INPUT)
    Set balanceArea = ws.Range(ws.Cells(BAL_LABEL_ROW, BAL_FIRST_COL), _
                               ws.Cells(BAL_DATE_ROW, BAL_MAX_COL))
    balanceSnapshot = balanceArea.Formula
    balanceMemoColBefore = BalanceMemoCol(ws)
    balanceSignatureBefore = BalanceInputStateSignature(ws)
    balanceSnapshotCaptured = True
    If Not TryGetFormattingEnableEvents(entryEvents, eventStateDetail) Then _
        Err.Raise vbObjectError + 4411, "RestoreToolFormatting", _
                  "書式復旧開始前のイベント状態を一意に保存できません。 " & eventStateDetail
    entryEventsCaptured = True

    'APPLY: 事前計画が成立した後だけ、一つのApplication lease内でUIを収束させる。
    AppBegin "書式を復旧しています..."
    '所有権はAppBeginが例外なく完了した後だけ成立する。開始途中の失敗を
    '外側leaseとしてAppEndしない。
    appLeaseOwned = True
    If Not TrySetFormattingEnableEventsExact(False, eventStateDetail) Then _
        Err.Raise vbObjectError + 4412, "RestoreToolFormatting", _
                  "書式復旧中のイベント停止を一意に確認できません。 " & eventStateDetail
    mutationStarted = True

    If SheetExists(SH_INPUT) Then
        ws.Unprotect Password:=TOOL_PASSWORD
        PolishInputLayout ws, True
        RestoreAllTransactionRowStyles ws
        BuildOperationPanel ws
        BuildInputHelpCards ws
        If Not TryFormattingCleanupStep( _
                   "INPUT_SETTINGS", "入力欄設定の再適用", _
                   cleanupDetail, recoveryHardBarrierDetected) Then
            If recoveryHardBarrierDetected Then _
                Err.Raise UTILITIES_RECOVERY_HARD_BARRIER_ERROR, _
                          "RestoreToolFormatting", cleanupDetail
            Err.Raise vbObjectError + 4435, "RestoreToolFormatting", _
                      cleanupDetail
        End If
        If BalanceInputStateSignature(ws) <> balanceSignatureBefore Then
            RestoreBalanceInputSnapshot ws, balanceSnapshot, balanceMemoColBefore
            Err.Raise vbObjectError + 4401, "RestoreToolFormatting", _
                      "表示復旧中に残高欄の内容または結合状態が変化したため、復旧前の状態へ戻しました。"
        End If
    End If

    '設定シートの入力規則は入力シート処理から分離し、
    '必ず保護解除、再設定、読戻し確認、再保護の順で復旧する。
    If SheetExists(SH_CONFIG) Then
        Set ws = GetSheet(SH_CONFIG)
        ws.Unprotect Password:=TOOL_PASSWORD
        RebuildConfigOperationPanel ws
    End If
    If SheetExists(SH_CONFIG) Then ApplyConfigValidations True

    '入力値を保持したまま、セル位置を基準に操作パネルだけを再構築する。
    candidateSheets = Array(SH_BANK_CAND, SH_BRANCH_CAND, SH_PERSON_CAND, SH_ACCOUNT_TYPE, SH_TEKIYO)
    For Each candidateName In candidateSheets
        If SheetExists(CStr(candidateName)) Then
            Set ws = GetSheet(CStr(candidateName))
            ws.Unprotect Password:=TOOL_PASSWORD
            BuildCandidateNavigationPanel ws
        End If
    Next candidateName
    If SheetExists(SH_REGISTERED_ACCOUNTS) Then
        Set ws = GetSheet(SH_REGISTERED_ACCOUNTS)
        ws.Unprotect Password:=TOOL_PASSWORD
        BuildRegisteredAccountsPanel ws
    End If

    '生成済み帳票は通常、閲覧専用で保護されている。書式復旧だけが保護されたまま
    'セル書式へ触れると、復旧ボタン自身が1004エラーになるため、書式変更の直前に
    '明示的に解除し、正常終了・異常終了のどちらでも後段で必ず再保護する。
    If SheetExists(SH_WORK_CASH) Then GetSheet(SH_WORK_CASH).Unprotect Password:=TOOL_PASSWORD
    If SheetExists(SH_OUTPUT_TX) Then GetSheet(SH_OUTPUT_TX).Unprotect Password:=TOOL_PASSWORD
    If SheetExists(SH_OUTPUT_TX_CONVERTED) Then _
        GetSheet(SH_OUTPUT_TX_CONVERTED).Unprotect Password:=TOOL_PASSWORD
    If SheetExists(SH_OUTPUT_BAL) Then GetSheet(SH_OUTPUT_BAL).Unprotect Password:=TOOL_PASSWORD

    If SheetExists(SH_WORK_CASH) Then FormatCashOperationOutputLayout GetSheet(SH_WORK_CASH)
    If SheetExists(SH_OUTPUT_TX) Then
        FormatCashAnalysisViewLayout GetSheet(SH_OUTPUT_TX)
        RestoreCashAnalysisViewControls GetSheet(SH_OUTPUT_TX)
    End If
    If SheetExists(SH_OUTPUT_TX_CONVERTED) Then FormatCashOperationOutputLayout GetSheet(SH_OUTPUT_TX_CONVERTED)
    If SheetExists(SH_SHOP_TARGET) Then FormatShopConversionTargetSheet GetSheet(SH_SHOP_TARGET)
    If SheetExists(SH_OUTPUT_BAL) Then FormatBalanceTransitionOutputLayout GetSheet(SH_OUTPUT_BAL)
    If SheetExists(SH_ANALYSIS_SHIFT) And SheetExists(SH_ANALYSIS_FLOW) And _
       SheetExists(SH_ANALYSIS_UNKNOWN) Then FormatTransactionAnalysisSheets
    If SheetExists(SH_WORK_TX) Then FormatWorkTx
    If SheetExists(SH_WORK_BAL) Then FormatWorkBal

    '各書式関数は対象範囲へ基礎色を一括再適用し、特殊行・条件付き書式を後段で上書きする。
    '同じUsedRangeをセル単位で最大11回・数十万セル再走査する処理は行わない。

    If SheetExists(SH_INPUT) Then LockToolShapes GetSheet(SH_INPUT), False
    If SheetExists(SH_SHOP_TARGET) Then LockToolShapes GetSheet(SH_SHOP_TARGET), False

    If Not TryFormattingCleanupStep("INPUT", "入力シートの再保護", _
                                    cleanupDetail, _
                                    recoveryHardBarrierDetected) Then _
        Err.Raise vbObjectError + 4420, "RestoreToolFormatting", cleanupDetail
    If Not TryFormattingCleanupStep("CONFIG", "設定シートの再保護", _
                                    cleanupDetail, _
                                    recoveryHardBarrierDetected) Then _
        Err.Raise vbObjectError + 4421, "RestoreToolFormatting", cleanupDetail
    If Not TryFormattingCleanupStep("CANDIDATES", "候補シートの再保護", _
                                    cleanupDetail, _
                                    recoveryHardBarrierDetected) Then _
        Err.Raise vbObjectError + 4422, "RestoreToolFormatting", cleanupDetail
    If Not TryFormattingCleanupStep("REGISTERED", "登録済み口座の再保護", _
                                    cleanupDetail, _
                                    recoveryHardBarrierDetected) Then _
        Err.Raise vbObjectError + 4423, "RestoreToolFormatting", cleanupDetail
    If Not TryFormattingCleanupStep("SHOP", "取扱店変換画面の再保護", _
                                    cleanupDetail, _
                                    recoveryHardBarrierDetected) Then _
        Err.Raise vbObjectError + 4424, "RestoreToolFormatting", cleanupDetail
    If Not TryFormattingCleanupStep("WORK_CASH", "資金操作表保管の再保護", _
                                    cleanupDetail, _
                                    recoveryHardBarrierDetected) Then _
        Err.Raise vbObjectError + 4425, "RestoreToolFormatting", cleanupDetail
    If Not TryFormattingCleanupStep("CONVERTED", "変換済み帳票の再保護", _
                                    cleanupDetail, _
                                    recoveryHardBarrierDetected) Then _
        Err.Raise vbObjectError + 4426, "RestoreToolFormatting", cleanupDetail
    If Not TryFormattingCleanupStep("BALANCE", "残高推移表の再保護", _
                                    cleanupDetail, _
                                    recoveryHardBarrierDetected) Then _
        Err.Raise vbObjectError + 4427, "RestoreToolFormatting", cleanupDetail
    If Not TryFormattingCleanupStep("CASH_VIEW", "資金操作表画面の再保護", _
                                    cleanupDetail, _
                                    recoveryHardBarrierDetected) Then _
        Err.Raise vbObjectError + 4428, "RestoreToolFormatting", cleanupDetail
    If Not TryFormattingCleanupStep("ANALYSIS", "分析画面の再保護", _
                                    cleanupDetail, _
                                    recoveryHardBarrierDetected) Then _
        Err.Raise vbObjectError + 4429, "RestoreToolFormatting", cleanupDetail
    If Not TryFormattingCleanupStep("KEYS", "入力キー割当の復旧", _
                                    cleanupDetail, _
                                    recoveryHardBarrierDetected) Then _
        Err.Raise vbObjectError + 4430, "RestoreToolFormatting", cleanupDetail
    If recoveryHardBarrierDetected Then GoTo FORMATTING_HARD_BARRIER
    'READBACK: 配置・OnAction・保護・入力規則を実物から読み戻す。
    '環境依存のDPI/Zoom/PageSetupはこの検査へ混ぜない。
    If BalanceInputStateSignature(GetSheet(SH_INPUT)) <> balanceSignatureBefore Then
        RestoreBalanceInputSnapshot GetSheet(SH_INPUT), balanceSnapshot, balanceMemoColBefore
        Err.Raise vbObjectError + 4405, "RestoreToolFormatting", _
                  "書式復旧後の読戻しで残高入力内容の変化を検出したため、退避内容へ戻しました。"
    End If
    AppEnd
    appLeaseOwned = False
    If Not TryHoldFormattingEventsStopped(eventStateDetail) Then _
        Err.Raise vbObjectError + 4431, "RestoreToolFormatting", _
                  "Excel状態復元後のイベント停止を確認できません。 " & _
                  eventStateDetail
    applicationStateRestored = True
    If entryEvents Then
        appStateProblems = vbNullString
        applicationStateRestored = AppStateIsRestored(appStateProblems)
        If Not applicationStateRestored Then
            Call TrySetFormattingEnableEventsExact(False, eventStateDetail)
            Err.Raise vbObjectError + 4407, "RestoreToolFormatting", _
                      "書式復旧後にExcel全体の状態を戻せません。 " & appStateProblems
        End If
    End If
    If Not TryRestoreFormattingEntryEvents(entryEventsCaptured, entryEvents, _
                                           cleanupDetail) Then _
        Err.Raise vbObjectError + 4413, "RestoreToolFormatting", _
                  "書式復旧開始前のイベント状態を復元できません。 " & cleanupDetail
    MsgBox "表示を整え直しました。入力欄・ボタン・帳票・分析表の配置と保護を再適用し、読戻しを確認しました。" & _
           vbCrLf & "次回起動にも残すにはブックを保存してください。", _
           vbInformation, "表示調整の完了"
    Exit Sub
EH:
    errorNumber = Err.Number: errorDescription = Err.Description
    errorSource = Err.Source
    If UtilitiesNestedRecoveryHardBarrierError( _
           errorNumber, errorSource) Then
        On Error Resume Next
        Call TryHoldFormattingEventsStopped(eventStateDetail)
        On Error GoTo 0
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    '復旧処理の一部が失敗しても後続の再保護とApplication状態復元を続け、
    '最初に発生した表示復旧エラーを利用者へ返す。
    cleanupEventsStopped = False
    If entryEventsCaptured Then _
        cleanupEventsStopped = TryHoldFormattingEventsStopped(eventStateDetail)
    If recoveryHardBarrierDetected Then GoTo FORMATTING_HARD_BARRIER
    localConvergenceConfirmed = Not mutationStarted
    If mutationStarted And cleanupEventsStopped Then
        localConvergenceConfirmed = True
        balanceRestored = TryRestoreFormattingBalanceInput( _
                              balanceSnapshotCaptured, balanceSnapshot, _
                              balanceMemoColBefore, balanceSignatureBefore, _
                              cleanupDetail)
        If Not balanceRestored Then localConvergenceConfirmed = False
        cleanupStepOK = TryFormattingCleanupStep( _
                            "INPUT", "入力シートの再保護", cleanupDetail, _
                            recoveryHardBarrierDetected)
        If recoveryHardBarrierDetected Then GoTo FORMATTING_HARD_BARRIER
        If Not cleanupStepOK Then localConvergenceConfirmed = False
        cleanupStepOK = TryFormattingCleanupStep( _
                            "CONFIG", "設定シートの再保護", cleanupDetail, _
                            recoveryHardBarrierDetected)
        If recoveryHardBarrierDetected Then GoTo FORMATTING_HARD_BARRIER
        If Not cleanupStepOK Then localConvergenceConfirmed = False
        cleanupStepOK = TryFormattingCleanupStep( _
                            "CANDIDATES", "候補シートの再保護", cleanupDetail, _
                            recoveryHardBarrierDetected)
        If recoveryHardBarrierDetected Then GoTo FORMATTING_HARD_BARRIER
        If Not cleanupStepOK Then localConvergenceConfirmed = False
        cleanupStepOK = TryFormattingCleanupStep( _
                            "REGISTERED", "登録済み口座の再保護", cleanupDetail, _
                            recoveryHardBarrierDetected)
        If recoveryHardBarrierDetected Then GoTo FORMATTING_HARD_BARRIER
        If Not cleanupStepOK Then localConvergenceConfirmed = False
        cleanupStepOK = TryFormattingCleanupStep( _
                            "SHOP", "取扱店変換画面の再保護", cleanupDetail, _
                            recoveryHardBarrierDetected)
        If recoveryHardBarrierDetected Then GoTo FORMATTING_HARD_BARRIER
        If Not cleanupStepOK Then localConvergenceConfirmed = False
        cleanupStepOK = TryFormattingCleanupStep( _
                            "WORK_CASH", "資金操作表保管の再保護", cleanupDetail, _
                            recoveryHardBarrierDetected)
        If recoveryHardBarrierDetected Then GoTo FORMATTING_HARD_BARRIER
        If Not cleanupStepOK Then localConvergenceConfirmed = False
        cleanupStepOK = TryFormattingCleanupStep( _
                            "CONVERTED", "変換済み帳票の再保護", cleanupDetail, _
                            recoveryHardBarrierDetected)
        If recoveryHardBarrierDetected Then GoTo FORMATTING_HARD_BARRIER
        If Not cleanupStepOK Then localConvergenceConfirmed = False
        cleanupStepOK = TryFormattingCleanupStep( _
                            "BALANCE", "残高推移表の再保護", cleanupDetail, _
                            recoveryHardBarrierDetected)
        If recoveryHardBarrierDetected Then GoTo FORMATTING_HARD_BARRIER
        If Not cleanupStepOK Then localConvergenceConfirmed = False
        cleanupStepOK = TryFormattingCleanupStep( _
                            "CASH_VIEW", "資金操作表画面の再保護", cleanupDetail, _
                            recoveryHardBarrierDetected)
        If recoveryHardBarrierDetected Then GoTo FORMATTING_HARD_BARRIER
        If Not cleanupStepOK Then localConvergenceConfirmed = False
        cleanupStepOK = TryFormattingCleanupStep( _
                            "ANALYSIS", "分析画面の再保護", cleanupDetail, _
                            recoveryHardBarrierDetected)
        If recoveryHardBarrierDetected Then GoTo FORMATTING_HARD_BARRIER
        If Not cleanupStepOK Then localConvergenceConfirmed = False
        cleanupStepOK = TryFormattingCleanupStep( _
                            "KEYS", "入力キー割当の復旧", cleanupDetail, _
                            recoveryHardBarrierDetected)
        If recoveryHardBarrierDetected Then GoTo FORMATTING_HARD_BARRIER
        If Not cleanupStepOK Then localConvergenceConfirmed = False
        cleanupEventsStopped = _
            TryHoldFormattingEventsStopped(eventStateDetail)
        If Not cleanupEventsStopped Then
            localConvergenceConfirmed = False
            AppendUtilitiesSafetyDetail cleanupDetail, _
                "局所復旧後のExcelイベント停止を確認できません: " & _
                eventStateDetail
        End If
    ElseIf mutationStarted Then
        AppendFormattingCleanupError cleanupDetail, "イベント安全停止", _
                                     vbObjectError + 4414, eventStateDetail
    End If

    If appLeaseOwned Then
        cleanupStepOK = TryFormattingCleanupStep( _
                            "APP_END", "Excel状態leaseの終了", cleanupDetail, _
                            recoveryHardBarrierDetected)
        If cleanupStepOK Then appLeaseOwned = False
        cleanupEventsStopped = _
            TryHoldFormattingEventsStopped(eventStateDetail)
        If Not cleanupEventsStopped Then _
            AppendUtilitiesSafetyDetail cleanupDetail, _
                "AppEnd後のExcelイベント停止を確認できません: " & _
                eventStateDetail
    End If
    'AppEndが失敗してこの処理のleaseが残った場合だけ強制復元を再試行する。
    '正常に閉じた入れ子leaseから外側の呼出元leaseを解消してはならない。
    If appLeaseOwned Then
        cleanupStepOK = TryFormattingCleanupStep( _
                            "APP_RESTORE", "Excel全体状態の復旧", cleanupDetail, _
                            recoveryHardBarrierDetected)
        If cleanupStepOK Then appLeaseOwned = False
        cleanupEventsStopped = _
            TryHoldFormattingEventsStopped(eventStateDetail)
        If Not cleanupEventsStopped Then _
            AppendUtilitiesSafetyDetail cleanupDetail, _
                "強制復元後のExcelイベント停止を確認できません: " & _
                eventStateDetail
    End If

    '入れ子呼出しでは外側leaseが残ること自体は正常である。開始時イベントが
    'Trueだった最外層だけ、全Application状態の解放を追加確認する。
    applicationStateRestored = Not appLeaseOwned
    If applicationStateRestored And entryEvents And cleanupEventsStopped Then
        appStateProblems = vbNullString
        applicationStateRestored = AppStateIsRestored(appStateProblems)
        If Not applicationStateRestored Then _
            AppendFormattingCleanupError cleanupDetail, "Excel全体状態の読戻し", _
                                         vbObjectError + 4410, appStateProblems
    End If

    '局所復元の一項目でも未確認、または自分のApplication leaseを閉じられない時は、
    'False exact下で一度だけRecoveryを要求し、成功後の二重状態だけを採用する。
    If Not (localConvergenceConfirmed And applicationStateRestored) And _
       cleanupEventsStopped Then
        'EHは既にactive handler内であるため、Enforce例外をこの場で捕捉する。
        '例外後はfresh False以外へ進まず、staleなRecovery/App状態を使わない。
        On Error Resume Next
        Err.Clear
        recoveryHardBarrierDetected = True
        EnforceRollbackRecoveryState cleanupDetail
        recoveryErrorNumber = Err.Number
        recoveryErrorDescription = Err.Description
        Err.Clear
        Call TryHoldFormattingEventsStopped(postEnforceEventDetail)
        On Error GoTo 0
        Err.Raise UTILITIES_RECOVERY_HARD_BARRIER_ERROR, _
                  "RestoreToolFormatting", errorDescription
    End If

    safeToRestoreEntry = cleanupEventsStopped And applicationStateRestored And _
                         (localConvergenceConfirmed Or recoveryConfirmed)
    finalEventsStopped = False
    finalEventsStopped = TryHoldFormattingEventsStopped(convergenceDetail)
    If Not finalEventsStopped And entryEventsCaptured Then _
        AppendUtilitiesSafetyDetail cleanupDetail, _
            "開始値復元直前のExcelイベント停止を確認できません: " & _
            convergenceDetail

    '開始値=Trueは、全局所収束＋Application復元、または成功したRecoveryの
    '二重読戻し＋post-Falseが揃う時だけ戻す。安全未確認時はFalseを維持する。
    If entryEventsCaptured Then
        If Not entryEvents Then
            If Not finalEventsStopped Then _
                AppendUtilitiesSafetyDetail cleanupDetail, _
                    "開始時Falseへの収束を確認できません。"
        ElseIf safeToRestoreEntry And finalEventsStopped Then
            If Not TryRestoreFormattingEntryEvents( _
                       entryEventsCaptured, entryEvents, cleanupDetail) Then _
                AppendUtilitiesSafetyDetail cleanupDetail, _
                    "開始時Trueへの復元を確認できません。"
        Else
            AppendUtilitiesSafetyDetail cleanupDetail, _
                "安全な局所収束またはRecoveryを厳密確認できないため、" & _
                "Excelイベントを開始値へ戻さずFalseで停止しました。"
        End If
    End If
    GoTo FORMATTING_REPORT_FAILURE

FORMATTING_HARD_BARRIER:
    'nested helperまたはEnforce本体のhard barrier後は、AppEnd/ForceRestore、
    '二回目のEnforce、診断書込み、開始値=Trueへの復元を一切行わない。
    finalEventsStopped = False
    convergenceDetail = vbNullString
    finalEventsStopped = TryHoldFormattingEventsStopped(convergenceDetail)
    If finalEventsStopped Then
        AppendUtilitiesSafetyDetail cleanupDetail, _
            "Recovery hard barrier後はExcelイベントをFalseへ収束させました。"
    Else
        AppendUtilitiesSafetyDetail cleanupDetail, _
            "Recovery hard barrier後もExcelイベントをFalseへ収束できません: " & _
            convergenceDetail
    End If
    errorNumber = UTILITIES_RECOVERY_HARD_BARRIER_ERROR
    On Error GoTo 0
    Err.Raise UTILITIES_RECOVERY_HARD_BARRIER_ERROR, _
              "RestoreToolFormatting", _
              errorDescription & _
              IIf(Len(cleanupDetail) > 0, _
                  " / " & cleanupDetail, vbNullString)

FORMATTING_REPORT_FAILURE:
    MsgBox "書式復旧中にエラーが発生しました。" & vbCrLf & _
           "Err " & errorNumber & ": " & errorDescription & _
           IIf(Len(cleanupDetail) > 0, vbCrLf & "復旧確認: " & cleanupDetail, ""), _
           vbCritical, "書式復旧を完了できませんでした"
End Sub

Private Function TryGetFormattingEnableEvents( _
        ByRef currentValue As Boolean, _
        ByRef detailText As String) As Boolean
    Dim errorNumber As Long, errorDescription As String
    detailText = vbNullString
    On Error GoTo EH
    currentValue = Application.EnableEvents
    TryGetFormattingEnableEvents = True
    Exit Function
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    detailText = "Err " & CStr(errorNumber) & ": " & errorDescription
    Err.Clear
End Function

Private Function TrySetFormattingEnableEventsExact( _
        ByVal desiredValue As Boolean, _
        ByRef detailText As String) As Boolean
    Dim errorNumber As Long, errorDescription As String
    detailText = vbNullString
    On Error GoTo EH
    Application.EnableEvents = desiredValue
    If Application.EnableEvents <> desiredValue Then _
        Err.Raise vbObjectError + 4415, "TrySetFormattingEnableEventsExact", _
                  "EnableEventsの書込み後読戻しが一致しません。"
    TrySetFormattingEnableEventsExact = True
    Exit Function
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    detailText = "Err " & CStr(errorNumber) & ": " & errorDescription
    Err.Clear
End Function

Private Function TryHoldFormattingEventsStopped( _
        ByRef detailText As String) As Boolean
    Dim firstDetail As String, retryDetail As String
    detailText = vbNullString
    If TrySetFormattingEnableEventsExact(False, firstDetail) Then
        TryHoldFormattingEventsStopped = True
        Exit Function
    End If
    If TrySetFormattingEnableEventsExact(False, retryDetail) Then
        TryHoldFormattingEventsStopped = True
        Exit Function
    End If
    detailText = "初回=" & firstDetail & " / 再試行=" & retryDetail
End Function

Private Function TryRestoreFormattingEntryEvents( _
        ByVal entryEventsCaptured As Boolean, _
        ByVal entryEvents As Boolean, _
        ByRef detailText As String) As Boolean
    Dim restoreDetail As String, safeStopDetail As String
    If Not entryEventsCaptured Then
        AppendFormattingCleanupError detailText, "イベント開始値の復元", _
                                     vbObjectError + 4416, _
                                     "開始値を取得できていません。"
        Exit Function
    End If
    If TrySetFormattingEnableEventsExact(entryEvents, restoreDetail) Then
        TryRestoreFormattingEntryEvents = True
        Exit Function
    End If
    If TrySetFormattingEnableEventsExact(entryEvents, restoreDetail) Then
        TryRestoreFormattingEntryEvents = True
        Exit Function
    End If
    AppendFormattingCleanupError detailText, "イベント開始値の復元", _
                                 vbObjectError + 4417, restoreDetail
    If Not TrySetFormattingEnableEventsExact(False, safeStopDetail) Then _
        AppendFormattingCleanupError detailText, "イベント安全停止", _
                                     vbObjectError + 4418, safeStopDetail
End Function

Private Function TryFormattingCleanupStep( _
        ByVal operationKey As String, ByVal operationLabel As String, _
        ByRef detailText As String, _
        ByRef recoveryHardBarrierDetected As Boolean) As Boolean
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim eventStateDetail As String, verificationDetail As String
    Dim requiresStoppedEvents As Boolean, eventsStoppedAfterFailure As Boolean

    requiresStoppedEvents = _
        (operationKey <> "APP_END" And operationKey <> "APP_RESTORE")
    If requiresStoppedEvents Then
        If Not TryHoldFormattingEventsStopped(eventStateDetail) Then
            AppendUtilitiesSafetyDetail detailText, _
                operationLabel & ": 実行前のExcelイベント停止を確認できません。 " & _
                eventStateDetail
            Exit Function
        End If
    End If

    On Error GoTo EH
    Select Case operationKey
        Case "INPUT_SETTINGS"
            ApplyInputSettings False, True
        Case "INPUT"
            ProtectInputSheet True
        Case "CONFIG"
            If SheetExists(SH_CONFIG) Then ProtectConfigSheet True
        Case "CANDIDATES"
            ProtectAllCandidateSheets True
        Case "REGISTERED"
            If SheetExists(SH_REGISTERED_ACCOUNTS) Then _
                ProtectRegisteredAccountsSheet True
        Case "SHOP"
            If SheetExists(SH_SHOP_TARGET) Then _
                ProtectShopConversionTargetSheet True
        Case "WORK_CASH"
            If SheetExists(SH_WORK_CASH) Then _
                ProtectGeneratedOutputSheet GetSheet(SH_WORK_CASH), True
        Case "CONVERTED"
            If SheetExists(SH_OUTPUT_TX_CONVERTED) Then _
                ProtectGeneratedOutputSheet GetSheet(SH_OUTPUT_TX_CONVERTED), True
        Case "BALANCE"
            If SheetExists(SH_OUTPUT_BAL) Then _
                ProtectGeneratedOutputSheet GetSheet(SH_OUTPUT_BAL), True
        Case "CASH_VIEW"
            If SheetExists(SH_OUTPUT_TX) Then ProtectCashAnalysisViewSheet
        Case "ANALYSIS"
            ProtectTransactionAnalysisSheets True
        Case "KEYS"
            EnableInputKeys
        Case "APP_END"
            AppEnd
        Case "APP_RESTORE"
            AppForceRestore
        Case Else
            Err.Raise vbObjectError + 4408, "TryFormattingCleanupStep", _
                      "未定義の復旧手順です: " & operationKey
    End Select

    '各保護処理は独自のイベントleaseやRecoveryを持つ。戻り値だけを信用せず、
    '外側がFalseを取り直してから対象シートの実保護を読む。
    If requiresStoppedEvents Then
        If Not TryHoldFormattingEventsStopped(eventStateDetail) Then
            AppendUtilitiesSafetyDetail detailText, _
                operationLabel & ": 実行後のExcelイベント停止を確認できません。 " & _
                eventStateDetail
            Exit Function
        End If
        If Not FormattingCleanupStepIsConfirmedExact( _
                   operationKey, verificationDetail) Then
            AppendUtilitiesSafetyDetail detailText, _
                operationLabel & ": " & verificationDetail
            Exit Function
        End If
    End If
    TryFormattingCleanupStep = True
    Exit Function
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    'Recovery-capable helperのterminalはBooleanへ変換せず、fresh Falseの
    '試行後に保存した三要素を完全に保ったまま外側へ返す。
    If UtilitiesNestedRecoveryHardBarrierError( _
           errorNumber, errorSource) Then
        On Error Resume Next
        Call TryHoldFormattingEventsStopped(eventStateDetail)
        On Error GoTo 0
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    On Error Resume Next
    Err.Clear
    If requiresStoppedEvents Then _
        eventsStoppedAfterFailure = _
            TryHoldFormattingEventsStopped(eventStateDetail)
    Err.Clear
    On Error GoTo 0
    AppendFormattingCleanupError detailText, operationLabel, _
                                 errorNumber, errorDescription
    If requiresStoppedEvents And Not eventsStoppedAfterFailure Then _
        AppendUtilitiesSafetyDetail detailText, _
            operationLabel & ": 失敗後のExcelイベント停止を確認できません。 " & _
            eventStateDetail
End Function

Private Function UtilitiesNestedRecoveryHardBarrierError( _
        ByVal errorNumber As Long, ByVal errorSource As String) As Boolean
    Dim expectedSource As String

    If errorNumber = UTILITIES_RECOVERY_HARD_BARRIER_ERROR Or _
       errorNumber = vbObjectError + 3599 Then
        UtilitiesNestedRecoveryHardBarrierError = True
        Exit Function
    End If
    Select Case errorNumber
        Case vbObjectError + 5191
            expectedSource = "AnalysisWorkspaceRecoveryFatal/"
        Case vbObjectError + 5192
            expectedSource = "SetupConvergeRecoveryFatal/"
        Case vbObjectError + 5194
            expectedSource = "CashAnalysisRecoveryFatal/"
        Case vbObjectError + 5195
            expectedSource = "TransactionAnalysisRecoveryFatal/"
        Case vbObjectError + 5196
            expectedSource = "CashManualSelectionRecoveryFatal/"
        Case vbObjectError + 5197
            expectedSource = "ClearRecoveryFatal/"
        Case Else
            Exit Function
    End Select
    UtilitiesNestedRecoveryHardBarrierError = _
        (Len(errorSource) >= Len(expectedSource)) And _
        (StrComp(Left$(errorSource, Len(expectedSource)), expectedSource, _
                 vbBinaryCompare) = 0)
End Function

Private Function TryRestoreFormattingBalanceInput( _
        ByVal snapshotCaptured As Boolean, ByRef balanceSnapshot As Variant, _
        ByVal balanceMemoColBefore As Long, ByVal expectedSignature As String, _
        ByRef detailText As String) As Boolean
    Dim ws As Worksheet
    Dim errorNumber As Long, errorDescription As String
    Dim eventStateDetail As String
    If Not TryHoldFormattingEventsStopped(eventStateDetail) Then
        AppendUtilitiesSafetyDetail detailText, _
            "残高入力内容の復元前にExcelイベント停止を確認できません。 " & _
            eventStateDetail
        Exit Function
    End If
    On Error GoTo EH
    If Not snapshotCaptured Then _
        Err.Raise vbObjectError + 4432, "TryRestoreFormattingBalanceInput", _
                  "退避済みの残高入力内容がありません。"
    If Not SheetExists(SH_INPUT) Then _
        Err.Raise vbObjectError + 4433, "TryRestoreFormattingBalanceInput", _
                  "入力シートがありません。"
    Set ws = GetSheet(SH_INPUT)
    If BalanceInputStateSignature(ws) <> expectedSignature Then
        ws.Unprotect Password:=TOOL_PASSWORD
        RestoreBalanceInputSnapshot ws, balanceSnapshot, balanceMemoColBefore
    End If
    If BalanceInputStateSignature(ws) <> expectedSignature Then _
        Err.Raise vbObjectError + 4409, "TryRestoreFormattingBalanceInput", _
                  "退避時の残高入力内容と署名が一致しません。"
    TryRestoreFormattingBalanceInput = True
    Exit Function
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    On Error Resume Next
    Err.Clear
    Call TryHoldFormattingEventsStopped(eventStateDetail)
    Err.Clear
    On Error GoTo 0
    AppendFormattingCleanupError detailText, "残高入力内容の復元", _
                                 errorNumber, errorDescription
End Function

Private Function FormattingCleanupStepIsConfirmedExact( _
        ByVal operationKey As String, _
        ByRef detailText As String) As Boolean
    Dim sheetNames As Variant, item As Variant
    detailText = vbNullString
    Select Case operationKey
        Case "INPUT"
            sheetNames = Array(SH_INPUT)
        Case "INPUT_SETTINGS"
            sheetNames = Array(SH_INPUT)
        Case "CONFIG"
            sheetNames = Array(SH_CONFIG)
        Case "CANDIDATES"
            sheetNames = Array(SH_BANK_CAND, SH_BRANCH_CAND, _
                               SH_PERSON_CAND, SH_ACCOUNT_TYPE, SH_TEKIYO)
        Case "REGISTERED"
            sheetNames = Array(SH_REGISTERED_ACCOUNTS)
        Case "SHOP"
            sheetNames = Array(SH_SHOP_TARGET)
        Case "WORK_CASH"
            sheetNames = Array(SH_WORK_CASH)
        Case "CONVERTED"
            sheetNames = Array(SH_OUTPUT_TX_CONVERTED)
        Case "BALANCE"
            sheetNames = Array(SH_OUTPUT_BAL)
        Case "CASH_VIEW"
            sheetNames = Array(SH_OUTPUT_TX)
        Case "ANALYSIS"
            sheetNames = Array(SH_ANALYSIS_SHIFT, SH_ANALYSIS_FLOW, _
                               SH_ANALYSIS_UNKNOWN, SH_ANALYSIS_RESULT, _
                               SH_ANALYSIS_DETAIL, SH_BALANCE_RECONCILIATION)
        Case "KEYS"
            'Application.OnKeyにはgetterがない。EnableInputKeys自身が全解除後に
            '全割当を一括適用し、途中失敗なら全解除して例外を返す契約を採用する。
            FormattingCleanupStepIsConfirmedExact = True
            Exit Function
        Case Else
            detailText = "読戻し対象が未定義です: " & operationKey
            Exit Function
    End Select

    For Each item In sheetNames
        If SheetExists(CStr(item)) Then
            If Not FormattingSheetProtectionIsConfirmedExact( _
                       CStr(item), detailText) Then Exit Function
        End If
    Next item
    FormattingCleanupStepIsConfirmedExact = True
End Function

Private Function FormattingSheetProtectionIsConfirmedExact( _
        ByVal sheetName As String, _
        ByRef detailText As String) As Boolean
    Dim ws As Worksheet
    Dim errorNumber As Long, errorDescription As String
    On Error GoTo EH
    Set ws = GetSheet(sheetName)
    If Not ws.ProtectContents Or Not ws.ProtectDrawingObjects Then _
        Err.Raise vbObjectError + 4434, _
                  "FormattingSheetProtectionIsConfirmedExact", _
                  "セル保護または図形保護を読み戻せません: " & sheetName
    FormattingSheetProtectionIsConfirmedExact = True
    Exit Function
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    AppendUtilitiesSafetyDetail detailText, _
        "Err " & CStr(errorNumber) & " " & errorDescription
    Err.Clear
End Function


Private Sub AppendUtilitiesSafetyDetail( _
        ByRef detailText As String, ByVal additionalText As String)
    If Len(additionalText) = 0 Then Exit Sub
    If Len(detailText) > 0 Then detailText = detailText & " / "
    detailText = detailText & additionalText
End Sub


Private Sub AppendFormattingCleanupError( _
        ByRef detailText As String, ByVal operationName As String, _
        ByVal errorNumber As Long, ByVal errorDescription As String)
    If errorNumber = 0 Then Exit Sub
    If Len(detailText) > 0 Then detailText = detailText & " / "
    detailText = detailText & operationName & ": Err " & _
                 CStr(errorNumber) & " " & errorDescription
End Sub

Private Function BalanceInputStateSignature(ByVal ws As Worksheet) As String
    Dim r As Long, c As Long
    Dim cell As Range
    Dim valueIn As Variant
    Dim mergeAddress As String
    Dim token As String
    If ws Is Nothing Then Exit Function
    For r = BAL_LABEL_ROW To BAL_DATE_ROW
        For c = BAL_FIRST_COL To BAL_MAX_COL
            Set cell = ws.Cells(r, c)
            valueIn = cell.Formula
            If r = BAL_VALUE_ROW And IsBalancePlaceholder(valueIn) Then valueIn = Empty
            mergeAddress = "-"
            If cell.MergeCells Then mergeAddress = cell.MergeArea.Address(False, False)
            token = SnapshotValueToken(valueIn)
            BalanceInputStateSignature = BalanceInputStateSignature & _
                                         CStr(r) & ":" & CStr(c) & ":" & _
                                         CStr(Len(token)) & ":" & token & ":" & _
                                         CStr(Len(mergeAddress)) & ":" & mergeAddress & "|"
        Next c
    Next r
End Function

Private Function SnapshotValueToken(ByVal valueIn As Variant) As String
    Dim valueText As String
    If IsError(valueIn) Then
        SnapshotValueToken = "Error"
    ElseIf IsNull(valueIn) Then
        SnapshotValueToken = "Null"
    ElseIf IsEmpty(valueIn) Then
        SnapshotValueToken = "Empty"
    Else
        valueText = CStr(valueIn)
        SnapshotValueToken = CStr(VarType(valueIn)) & ":" & CStr(Len(valueText)) & ":" & valueText
    End If
End Function

Private Sub RestoreBalanceInputSnapshot(ByVal ws As Worksheet, ByVal snapshot As Variant, _
                                        ByVal memoCol As Long)
    Dim target As Range
    If ws Is Nothing Then Exit Sub
    Set target = ws.Range(ws.Cells(BAL_LABEL_ROW, BAL_FIRST_COL), _
                          ws.Cells(BAL_DATE_ROW, BAL_MAX_COL))
    target.UnMerge
    target.Formula = snapshot
    If memoCol >= BAL_FIRST_COL And memoCol < BAL_MAX_COL Then
        ws.Range(ws.Cells(BAL_LABEL_ROW, memoCol), _
                 ws.Cells(BAL_LABEL_ROW, BAL_MAX_COL)).Merge
        ws.Range(ws.Cells(BAL_VALUE_ROW, memoCol), _
                 ws.Cells(BAL_VALUE_ROW, BAL_MAX_COL)).Merge
    End If
End Sub

Public Function LastPopulatedTransactionInputRow(ByVal ws As Worksheet) As Long
    Dim foundCell As Range
    LastPopulatedTransactionInputRow = TX_FIRST_ROW - 1
    If ws Is Nothing Then Exit Function
    On Error GoTo EH
    Set foundCell = ws.Range(ws.Cells(TX_FIRST_ROW, COL_TX_YEAR), _
                             ws.Cells(TX_LAST_ROW, COL_TX_BALANCE)).Find( _
                    What:="*", After:=ws.Cells(TX_FIRST_ROW, COL_TX_YEAR), _
                    LookIn:=xlFormulas, LookAt:=xlPart, SearchOrder:=xlByRows, _
                    SearchDirection:=xlPrevious, MatchCase:=False, MatchByte:=False, _
                    SearchFormat:=False)
    If Not foundCell Is Nothing Then LastPopulatedTransactionInputRow = foundCell.Row
    Exit Function
EH:
    Err.Raise vbObjectError + 1109, "LastPopulatedTransactionInputRow", _
              "入力済み取引の最終行を安全に確認できませんでした。" & _
              "入力内容は変更せず、検査を中止しました。"
End Function

Public Sub RestoreAllTransactionRowStyles(Optional ByVal ws As Worksheet = Nothing, _
                                          Optional ByVal lastRow As Long = 0)
    Const STRIPE_BATCH_ROWS As Long = 200
    Dim r As Long, batchCount As Long, effectiveLastRow As Long
    Dim oddRows As Range, rowRange As Range
    If ws Is Nothing Then
        If Not SheetExists(SH_INPUT) Then Exit Sub
        Set ws = GetSheet(SH_INPUT)
    End If
    If lastRow = 0 Then
        effectiveLastRow = TX_LAST_ROW
    ElseIf lastRow < TX_FIRST_ROW Then
        Exit Sub
    Else
        effectiveLastRow = Application.Min(lastRow, TX_LAST_ROW)
    End If
    With ws.Range(ws.Cells(TX_FIRST_ROW, COL_TX_YEAR), _
                  ws.Cells(effectiveLastRow, COL_TX_BALANCE))
        .Interior.Color = RGB(255, 255, 255)
        .Font.Color = RGB(15, 23, 42)
        .Borders.LineStyle = xlContinuous
        .Borders.Color = RGB(226, 232, 240)
    End With
    For r = TX_FIRST_ROW + 1 To effectiveLastRow Step 2
        Set rowRange = ws.Range(ws.Cells(r, COL_TX_YEAR), ws.Cells(r, COL_TX_BALANCE))
        If oddRows Is Nothing Then
            Set oddRows = rowRange
        Else
            Set oddRows = Union(oddRows, rowRange)
        End If
        batchCount = batchCount + 1
        If batchCount = STRIPE_BATCH_ROWS Then
            oddRows.Interior.Color = RGB(248, 250, 252)
            Set oddRows = Nothing
            batchCount = 0
        End If
    Next r
    If Not oddRows Is Nothing Then oddRows.Interior.Color = RGB(248, 250, 252)
End Sub
Public Sub AddCheck(ByVal levelText As String, ByVal sourceText As String, ByVal messageText As String)
    Dim ws As Worksheet
    Dim r As Long
    On Error Resume Next
    Set ws = GetOrCreateSheet(SH_CHECK, False)
    If ws Is Nothing Then Exit Sub
    If Len(CellText(ws.Range("A1").Value)) = 0 Then SetRowValues ws.Range("A1"), Array("区分", "発生元", "内容", "記録時刻")
    r = ws.Cells(ws.Rows.Count, 1).End(xlUp).Row + 1
    If r < 2 Then r = 2
    ws.Range(ws.Cells(r, 1), ws.Cells(r, 3)).NumberFormatLocal = "@"
    ws.Cells(r, 4).NumberFormatLocal = "yyyy/m/d h:mm:ss"
    ws.Cells(r, 1).Value = levelText
    ws.Cells(r, 2).Value = sourceText
    ws.Cells(r, 3).Value = messageText
    ws.Cells(r, 4).Value = Now
    'セットアップ失敗・Workbookイベント・正常結果フォールバックを含む全経路で、
    '空き行や旧列書式を継承せず、同じ配色・折返し・配置へ収束させる。
    ApplyCheckLogRowAppearance ws, r, levelText, sourceText
    '一覧全体の条件付き書式・集計・AutoFilterは表示時に一度だけ再構成する。
    'AddCheckごとに全履歴を走査すると診断件数に対して二次的に遅くなるため行わない。
    On Error GoTo 0
End Sub

Private Sub ApplyCheckLogRowAppearance(ByVal ws As Worksheet, _
                                       ByVal rowNumber As Long, _
                                       ByVal levelText As String, _
                                       ByVal sourceText As String)
    If ws Is Nothing Then Exit Sub
    If rowNumber < 2 Or rowNumber > ws.Rows.Count Then Exit Sub
    With ws.Range(ws.Cells(rowNumber, 1), ws.Cells(rowNumber, 4))
        .Font.Name = "Yu Gothic UI"
        .Font.Size = 10
        .Font.Bold = False
        .Font.Italic = False
        .Font.Color = RGB(15, 23, 42)
        .Interior.Color = RGB(255, 255, 255)
        .VerticalAlignment = xlTop
        .HorizontalAlignment = xlLeft
        .WrapText = False
    End With
    Select Case levelText
        Case "エラー"
            ws.Cells(rowNumber, 1).Interior.Color = RGB(254, 226, 226)
            ws.Cells(rowNumber, 1).Font.Color = RGB(153, 27, 27)
        Case "警告"
            ws.Cells(rowNumber, 1).Interior.Color = RGB(254, 243, 199)
            ws.Cells(rowNumber, 1).Font.Color = RGB(120, 53, 15)
    End Select
    ws.Cells(rowNumber, 3).WrapText = True
    ws.Cells(rowNumber, 4).NumberFormat = "yyyy/m/d h:mm:ss"
    ws.Rows(rowNumber).AutoFit
    If ws.Rows(rowNumber).RowHeight < 30 Then ws.Rows(rowNumber).RowHeight = 30
    If ws.Rows(rowNumber).RowHeight > 90 Then ws.Rows(rowNumber).RowHeight = 90
End Sub
Private Sub ApplyCheckLogLayout(ByVal ws As Worksheet)
    If ws Is Nothing Then Exit Sub
    FormatOutputHeader ws.Range("A1:D1")
    ws.Columns("A:A").ColumnWidth = 10
    ws.Columns("B:B").ColumnWidth = 22
    ws.Columns("C:C").ColumnWidth = 70
    ws.Columns("D:D").ColumnWidth = 20
End Sub
Public Sub SafeSelectCell(ByVal ws As Worksheet, ByVal addressText As String)
    On Error Resume Next
    If ws Is Nothing Then Exit Sub
    ThisWorkbook.Activate
    ws.Activate
    If ThisWorkbook.ReadOnly Then Exit Sub
    ws.Range(addressText).Select
    On Error GoTo 0
End Sub

Public Sub RestoreWorkbookViewPosition(ByVal ws As Worksheet, _
                                       ByVal restoreWindow As Boolean, _
                                       ByVal freezePanes As Boolean, _
                                       ByVal splitRow As Long, ByVal splitColumn As Long, _
                                       ByVal scrollRow As Long, ByVal scrollColumn As Long, _
                                       ByVal zoomValue As Long, _
                                       ByVal selectionAddress As String, _
                                       ByVal activeCellAddress As String)
    'データ・保護の復元とは独立した表示位置の復元。
    '位置や選択を戻せないだけで、後続の再保護を中断したり案件を要復旧にしない。
    '呼出元が対象シートの存在・表示・切替を確認した後だけ呼ぶ。
    Dim win As Window
    On Error GoTo Done
    If ws Is Nothing Then Exit Sub
    If Not ActiveWorkbook Is ThisWorkbook Then Exit Sub
    If Not ActiveSheet Is ws Then Exit Sub
    Set win = Application.ActiveWindow

    On Error Resume Next
    If restoreWindow Then
        If Not win Is Nothing Then
            win.FreezePanes = False
            win.SplitRow = splitRow
            win.SplitColumn = splitColumn
            win.FreezePanes = freezePanes
            win.Zoom = zoomValue
        End If
    End If
    If Len(selectionAddress) > 0 Then
        Err.Clear
        ws.Range(selectionAddress).Select
        If Err.Number <> 0 And Len(activeCellAddress) > 0 Then
            Err.Clear
            ws.Range(activeCellAddress).Select
        End If
    ElseIf Len(activeCellAddress) > 0 Then
        ws.Range(activeCellAddress).Select
    End If
    If Len(activeCellAddress) > 0 Then ws.Range(activeCellAddress).Activate
    '選択操作で表示位置が動く場合に備え、スクロールは最後に戻す。
    If restoreWindow Then
        If Not win Is Nothing Then
            win.ScrollRow = scrollRow
            win.ScrollColumn = scrollColumn
        End If
    End If
Done:
    Err.Clear
    On Error GoTo 0
End Sub

Public Sub SafeFreezeOutputHeader(ByVal ws As Worksheet)
    SafeFreezeSheetAt ws, "A2"
End Sub

Public Sub ApplyActiveSheetWindowStyle(ByVal ws As Worksheet)
    Dim win As Window
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    RestoreToolSheetScrollArea ws
    If Not ActiveWorkbook Is ThisWorkbook Then Exit Sub
    If ActiveSheet.Name <> ws.Name Then Exit Sub
    Set win = Application.ActiveWindow
    If win Is Nothing Then Exit Sub
    win.DisplayGridlines = False
    win.DisplayHeadings = True
    If ws.Name = SH_INPUT Then FitInputWindowToAvailableWidth ws, False
    On Error GoTo 0
End Sub

Public Function InputAvailableWidthPoints(ByVal win As Window) As Double
    'Range.Width、Window.Width、Application.UsableWidthはすべてポイント単位。
    'px/DPI換算を挟まず、現在のExcelウィンドウそのものへ合わせる。
    Dim availableWidth As Double
    On Error Resume Next
    availableWidth = Application.UsableWidth
    If Not win Is Nothing Then
        If win.Width > 0 Then
            If availableWidth <= 0 Or win.Width < availableWidth Then availableWidth = win.Width
        End If
    End If
    On Error GoTo 0
    If availableWidth > INPUT_WINDOW_HORIZONTAL_RESERVE_POINTS Then _
        availableWidth = availableWidth - INPUT_WINDOW_HORIZONTAL_RESERVE_POINTS
    If availableWidth < 1 Then availableWidth = 0
    InputAvailableWidthPoints = availableWidth
End Function

Public Function InputFitZoomPercent(ByVal ws As Worksheet, ByVal win As Window) As Long
    'ウィンドウ幅に合わせた自動縮小は行わない。
    InputFitZoomPercent = INPUT_DEFAULT_ZOOM
End Function

Public Sub FitInputWindowToAvailableWidth(ByVal ws As Worksheet, _
                                          Optional ByVal resetToDesignZoom As Boolean = False, _
                                          Optional ByVal targetWindow As Window = Nothing)
    Dim win As Window
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    Set win = targetWindow
    If win Is Nothing Then
        If Not ActiveWorkbook Is ThisWorkbook Then Exit Sub
        If ActiveSheet.Name <> ws.Name Then Exit Sub
        Set win = Application.ActiveWindow
    Else
        If Not win.Parent Is ThisWorkbook Then Exit Sub
        If Not win.ActiveSheet Is ws Then Exit Sub
    End If
    If win Is Nothing Then Exit Sub
    '初回セットアップの明示呼出しだけ設計倍率を適用する。
    'シート往復、ウィンドウ再表示、リサイズでは利用者の倍率を変えない。
    If resetToDesignZoom Then win.Zoom = INPUT_DEFAULT_ZOOM
    On Error GoTo 0
End Sub

Public Sub RestoreAllToolSheetScrollAreas()
    'ScrollAreaはブックを閉じると失われるため、起動・再アクティブ化のたびに復元する。
    '画面外へ迷い込む操作と、図形周辺の誤ドラッグ後に戻れなくなるストレスを防ぐ。
    Dim ws As Worksheet
    Dim workbookWasSaved As Boolean
    Dim errorNumber As Long, errorDescription As String
    workbookWasSaved = ThisWorkbook.Saved
    On Error GoTo EH
    For Each ws In ThisWorkbook.Worksheets
        RestoreToolSheetScrollArea ws
    Next ws
    If workbookWasSaved Then ThisWorkbook.Saved = True
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    If workbookWasSaved Then ThisWorkbook.Saved = True
    Err.Raise errorNumber, "RestoreAllToolSheetScrollAreas", errorDescription
End Sub

Public Sub RestoreToolSheetScrollArea(ByVal ws As Worksheet)
    Dim lastR As Long, lastC As Long, bottomRow As Long
    Dim areaText As String
    If ws Is Nothing Then Exit Sub

    Select Case ws.Name
        Case SH_INPUT
            areaText = "A1:W" & CStr(TX_LAST_ROW)
        Case SH_CONFIG
            areaText = "A1:H" & CStr(ERA_MASTER_MAX_ROW + 3)
        Case SH_BANK_CAND, SH_BRANCH_CAND, SH_PERSON_CAND, SH_ACCOUNT_TYPE, SH_TEKIYO
            bottomRow = Application.Min(ws.Rows.Count, CandidateEditableLastRow(ws))
            areaText = "A1:J" & CStr(bottomRow)
        Case SH_INPUT_MODE, SH_YEAR_MODE, SH_DISPLAY_OPTION, SH_POST_KEEP, SH_POST_CLEAR, SH_ANALYSIS_STATUS
            bottomRow = Application.Min(ws.Rows.Count, _
                        Application.Max(50, LastUsedRowInSheet(ws) + 20))
            areaText = "A1:D" & CStr(bottomRow)
        Case SH_REGISTERED_ACCOUNTS, SH_SHOP_TARGET
            bottomRow = Application.Min(ws.Rows.Count, _
                        Application.Max(50, LastUsedRowInSheet(ws) + 20))
            areaText = "A1:M" & CStr(bottomRow)
        Case SH_OUTPUT_TX
            bottomRow = Application.Min(ws.Rows.Count, _
                        Application.Max(60, LastUsedRowInSheet(ws) + 20))
            areaText = "A1:M" & CStr(bottomRow)
        Case SH_OUTPUT_TX_CONVERTED
            bottomRow = Application.Min(ws.Rows.Count, _
                        Application.Max(50, LastUsedRowInSheet(ws) + 20))
            areaText = "A1:M" & CStr(bottomRow)
        Case SH_OUTPUT_BAL
            lastR = Application.Max(1, LastUsedRowInSheet(ws))
            lastC = Application.Max(1, LastUsedColumnInSheet(ws, lastR))
            bottomRow = Application.Min(ws.Rows.Count, Application.Max(50, lastR + 20))
            areaText = "A1:" & ExcelColumnLetter(lastC) & CStr(bottomRow)
        Case SH_ANALYSIS_SHIFT
            bottomRow = Application.Min(ws.Rows.Count, _
                        Application.Max(50, LastUsedRowInSheet(ws) + 20))
            areaText = "A1:" & ExcelColumnLetter(SHIFT_ANALYSIS_LAST_COL) & CStr(bottomRow)
        Case SH_ANALYSIS_FLOW
            bottomRow = Application.Min(ws.Rows.Count, _
                        Application.Max(50, LastUsedRowInSheet(ws) + 20))
            areaText = "A1:" & ExcelColumnLetter(FLOW_ANALYSIS_LAST_COL) & CStr(bottomRow)
        Case SH_ANALYSIS_UNKNOWN
            bottomRow = Application.Min(ws.Rows.Count, _
                        Application.Max(50, LastUsedRowInSheet(ws) + 20))
            areaText = "A1:" & ExcelColumnLetter(UNKNOWN_ANALYSIS_LAST_COL) & CStr(bottomRow)
        Case SH_ANALYSIS_RESULT
            bottomRow = Application.Min(ws.Rows.Count, _
                        Application.Max(50, LastUsedRowInSheet(ws) + 20))
            areaText = "A1:I" & CStr(bottomRow)
        Case SH_ANALYSIS_DETAIL
            bottomRow = Application.Min(ws.Rows.Count, _
                        Application.Max(50, LastUsedRowInSheet(ws) + 20))
            areaText = "A1:G" & CStr(bottomRow)
        Case SH_BALANCE_RECONCILIATION
            bottomRow = Application.Min(ws.Rows.Count, _
                        Application.Max(50, LastUsedRowInSheet(ws) + 20))
            areaText = "A1:" & ExcelColumnLetter(BALANCE_RECONCILIATION_LAST_COL) & CStr(bottomRow)
        Case SH_CHECK
            bottomRow = Application.Min(ws.Rows.Count, _
                        Application.Max(50, LastUsedRowInSheet(ws) + 20))
            'E1/F1は今回結果の要約と入力画面へ戻る導線に使用する。
            'ログ本体A:Dの行契約には触れず、画面外へ迷い込まない範囲へ含める。
            areaText = "A1:F" & CStr(bottomRow)
    End Select

    If Len(areaText) > 0 Then ws.ScrollArea = areaText
End Sub

Public Function ConfirmLargeArrayOperation(ByVal rowCount As Long, _
                                           ByVal operationName As String) As Boolean
    '32bit版Excelでは大きなVariant配列を複数保持すると、行上限より先にメモリ不足へ達しやすい。
    'データを書き換える前に利用者へ止まる選択肢を出し、途中停止を避ける。
    If rowCount < 0 Then _
        Err.Raise vbObjectError + 1089, "ConfirmLargeArrayOperation", _
                  "大容量処理の事前安全規模が負数です。"
#If Win64 Or Mac Then
    If rowCount <= 150000 Then
        ConfirmLargeArrayOperation = True
    Else
        ConfirmLargeArrayOperation = _
            (MsgBox(operationName & "は約" & Format$(rowCount, "#,##0") & _
                    "行を一括処理します。" & vbCrLf & _
                    "64bit版Excelでも、処理内容によっては数分以上かかり、" & _
                    "大きなメモリを使用します。" & vbCrLf & _
                    "ほかのブックを閉じ、案件ファイルを保存してから実行してください。" & _
                    vbCrLf & vbCrLf & "このまま続行しますか？", _
                    vbYesNo + vbExclamation + vbDefaultButton2, _
                    "大容量処理の事前確認") = vbYes)
    End If
#Else
    If rowCount <= 50000 Then
        ConfirmLargeArrayOperation = True
    ElseIf rowCount > 75000 Then
        MsgBox operationName & "は約" & Format$(rowCount, "#,##0") & _
               "行を一括処理するため、32bit版Excelでは安全に完了できません。" & _
               vbCrLf & "データを案件ごとに分けるか、64bit版Excelで実行してください。" & _
               vbCrLf & "データの書換えは開始していません。", _
               vbCritical + vbOKOnly, "大容量処理を停止しました"
        ConfirmLargeArrayOperation = False
    Else
        ConfirmLargeArrayOperation = _
            (MsgBox(operationName & "は約" & Format$(rowCount, "#,##0") & _
                    "行を一括処理します。" & vbCrLf & _
                    "32bit版Excelではメモリ不足になる可能性があります。" & vbCrLf & _
                    "他のブックを閉じ、可能であれば64bit版Excelで実行してください。" & _
                    vbCrLf & vbCrLf & "このまま続行しますか？", _
                    vbYesNo + vbExclamation + vbDefaultButton2, _
                    "大容量処理の事前確認") = vbYes)
    End If
#End If
End Function

Public Sub SafeFreezeSheetAt(ByVal ws As Worksheet, ByVal freezeAddress As String, _
                             Optional ByVal zoomPercent As Long = 0)
    Dim prevSheet As Worksheet
    Dim win As Window
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    Set prevSheet = ActiveSheet
    If ws.Visible <> xlSheetVisible Then ws.Visible = xlSheetVisible
    ThisWorkbook.Activate
    ws.Activate
    Set win = Application.ActiveWindow
    If Not win Is Nothing Then
        win.DisplayGridlines = False
        win.DisplayHeadings = True
        win.FreezePanes = False
        '選択禁止の読み取り専用シートでも固定表示を復元できるよう、
        'ActiveCellへ移動せず固定位置を直接指定する。
        win.SplitColumn = ws.Range(freezeAddress).Column - 1
        win.SplitRow = ws.Range(freezeAddress).Row - 1
        win.FreezePanes = True
        If zoomPercent >= 50 And zoomPercent <= 200 Then win.Zoom = zoomPercent
    End If
    If Not prevSheet Is Nothing Then prevSheet.Activate
    On Error GoTo 0
End Sub

Public Sub SafeFreezeInput()
    Dim ws As Worksheet
    Dim win As Window
    On Error Resume Next
    Set ws = ThisWorkbook.Worksheets(SH_INPUT)
    If ws Is Nothing Then Exit Sub
    ThisWorkbook.Activate
    ws.Activate
    Set win = Application.ActiveWindow
    If win Is Nothing Then Exit Sub
    win.DisplayGridlines = False
    win.DisplayHeadings = True
    win.FreezePanes = False
    win.SplitColumn = COL_TX_YEAR - 1
    win.SplitRow = TX_FIRST_ROW - 1
    win.FreezePanes = True
    '新規作成時だけ設計倍率90%にする。以後の倍率は利用者に委ねる。
    FitInputWindowToAvailableWidth ws, True
    win.ScrollColumn = 1
    On Error GoTo 0
End Sub

Public Function RequireToolReady() As Boolean
    Dim dataHealth As String, recoveryLatchSet As Boolean
    RequireToolReady = False
    If Not SheetExists(SH_INPUT) Then
        MsgBox "案件ファイルの入力画面が見つかりません。" & vbCrLf & _
               "このブックで作業を続けず、診断用コピーを残して復旧してください。", _
               vbCritical, "案件ファイルを使用できません"
        Exit Function
    End If
    If Not SheetExists(SH_WORK_TX) Then
        MsgBox "案件データの保存領域が見つかりません。" & vbCrLf & _
               "このブックで登録を続けず、診断用コピーを残して復旧してください。", _
               vbCritical, "案件ファイルを使用できません"
        Exit Function
    End If
    If Not SheetExists(SH_WORK_BAL) Or Not SheetExists(SH_WORK_ACCOUNT) Or Not SheetExists(SH_WORK_STATE) Then
        MsgBox "案件データの保存領域が不足しています。" & vbCrLf & _
               "このブックで登録を続けず、診断用コピーを残して復旧してください。", _
               vbCritical, "案件ファイルを使用できません"
        Exit Function
    End If
    If Not SheetExists(SH_CONFIG) Then
        MsgBox "設定画面が見つかりません。" & vbCrLf & _
               "このブックで作業を続けず、診断用コピーを残して復旧してください。", _
               vbCritical, "案件ファイルを使用できません"
        Exit Function
    End If
    If Not TryGetRollbackRecoveryLatch(recoveryLatchSet) Then
        MsgBox "独立した復旧停止状態を確認できません。" & vbCrLf & _
               "通常操作や上書き保存を続けず、セットアップログとチェック結果を確認してください。", _
               vbCritical, "復旧停止状態が不明です"
        Exit Function
    End If
    If recoveryLatchSet Then
        MsgBox "このブックには、ロールバック不成立後の復旧停止状態が残っています。" & vbCrLf & _
               "現在のブックを上書きせず、バックアップから復旧するか再セットアップしてください。", _
               vbCritical, "案件データの復旧が必要です"
        Exit Function
    End If
    '状態キーの欠落・重複・数式・Excelエラー・読取失敗を正常扱いしない。
    If Not TryGetExactStateValue(STATE_DATA_HEALTH, dataHealth) Then
        MsgBox "案件データの安全状態を確認できません。" & vbCrLf & _
               "このブックは通常操作や上書き保存を続けず、セットアップログとチェック結果を確認してください。", _
               vbCritical, "案件データの状態が不明です"
        Exit Function
    End If
    If dataHealth <> DATA_HEALTH_NORMAL Then
        MsgBox "案件データは「" & dataHealth & "」状態です。" & vbCrLf & _
               "初期化または再セットアップの中断後は、現在のブックを上書き保存せず、" & _
               "作成されたバックアップから復旧してください。", _
               vbCritical, "案件データの復旧が必要です"
        Exit Function
    End If
    RequireToolReady = True
End Function

Public Sub HideDailySheets(Optional ByVal hideOutputs As Boolean = False)
    '普段触らない作業・候補シートを隠し、入力画面を作業の中心にする。
    Dim detailText As String
    On Error Resume Next
    If Not ConvergeDailySheetVisibility(hideOutputs, detailText) Then _
        AddCheck "警告", "シート表示整理", detailText
    Err.Clear
    On Error GoTo 0
End Sub

Public Function ConvergeDailySheetVisibility( _
        Optional ByVal hideOutputs As Boolean = False, _
        Optional ByRef detailText As String) As Boolean
    '表示整理のset+readbackを一か所へ集約する。通常呼出しはHideDailySheetsが
    'best-effortで使い、帳票確定後は戻り値をfreshnessとは別に判定する。
    Dim hiddenNames As Variant, veryHiddenNames As Variant
    Dim item As Variant
    detailText = vbNullString
    On Error GoTo EH

    SetDailySheetVisibilityExact SH_INPUT, xlSheetVisible
    hiddenNames = Array( _
        SH_CONFIG, SH_TEKIYO, SH_ACCOUNT_TYPE, SH_INPUT_MODE, SH_YEAR_MODE, _
        SH_DISPLAY_OPTION, SH_POST_KEEP, SH_POST_CLEAR, SH_BANK_CAND, _
        SH_BRANCH_CAND, SH_PERSON_CAND, SH_REGISTERED_ACCOUNTS, SH_CHECK)
    For Each item In hiddenNames
        SetDailySheetVisibilityExact CStr(item), xlSheetHidden
    Next item
    veryHiddenNames = Array( _
        SH_ANALYSIS_STATUS, SH_WORK_ANALYSIS_GROUP, SH_WORK_ANALYSIS_REVIEW, _
        SH_WORK_ANALYSIS_HISTORY, SH_WORK_MANUAL_FLOW, SH_ANALYSIS_SHIFT, _
        SH_ANALYSIS_FLOW, SH_ANALYSIS_UNKNOWN, SH_ANALYSIS_RESULT, _
        SH_ANALYSIS_DETAIL, SH_WORK_CASH, SH_WORK_TX, SH_WORK_BAL, _
        SH_WORK_ACCOUNT, SH_WORK_STATE, SH_SETUP_LOG)
    For Each item In veryHiddenNames
        SetDailySheetVisibilityExact CStr(item), xlSheetVeryHidden
    Next item

    If hideOutputs Then
        hiddenNames = Array(SH_OUTPUT_TX, SH_OUTPUT_BAL, SH_SHOP_TARGET, _
                            SH_OUTPUT_TX_CONVERTED, SH_BALANCE_RECONCILIATION)
        For Each item In hiddenNames
            SetDailySheetVisibilityExact CStr(item), xlSheetHidden
        Next item
    ElseIf SheetExists(SH_BALANCE_RECONCILIATION) Then
        If LastUsedRowInSheet(GetSheet(SH_BALANCE_RECONCILIATION)) > 1 Then
            SetDailySheetVisibilityExact SH_BALANCE_RECONCILIATION, xlSheetVisible
        Else
            SetDailySheetVisibilityExact SH_BALANCE_RECONCILIATION, xlSheetHidden
        End If
    End If
    ConvergeDailySheetVisibility = True
    Exit Function
EH:
    detailText = "Err " & CStr(Err.Number) & ": " & Err.Description
    ConvergeDailySheetVisibility = False
    Err.Clear
End Function

Private Sub SetDailySheetVisibilityExact( _
        ByVal sheetName As String, ByVal desiredVisibility As XlSheetVisibility)
    Dim ws As Worksheet
    If Not SheetExists(sheetName) Then Exit Sub
    Set ws = ThisWorkbook.Worksheets(sheetName)
    If ws.Visible = desiredVisibility Then Exit Sub
    If desiredVisibility <> xlSheetVisible Then
        If ActiveWorkbook Is ThisWorkbook Then
            If TypeName(ActiveSheet) = "Worksheet" Then
                If ActiveSheet Is ws Then
                    If Not SheetExists(SH_INPUT) Or ws.Name = SH_INPUT Then _
                        Err.Raise vbObjectError + 4471, _
                                  "SetDailySheetVisibilityExact", _
                                  "非表示化するシートから移動できません: " & sheetName
                    ThisWorkbook.Worksheets(SH_INPUT).Visible = xlSheetVisible
                    ThisWorkbook.Worksheets(SH_INPUT).Activate
                End If
            End If
        End If
    End If
    ws.Visible = desiredVisibility
    If ws.Visible <> desiredVisibility Then _
        Err.Raise vbObjectError + 4472, "SetDailySheetVisibilityExact", _
                  "シート表示の読戻しが一致しません: " & sheetName
End Sub

Public Sub VeryHideSheetIfExists(ByVal sheetName As String)
    On Error Resume Next
    If SheetExists(sheetName) Then
        SetSheetVeryHiddenSafe ThisWorkbook.Worksheets(sheetName)
    End If
    On Error GoTo 0
End Sub

Public Sub SetSheetVeryHiddenSafe(ByVal ws As Worksheet)
    Dim candidate As Worksheet
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    If ActiveSheet.Name = ws.Name Then
        If SheetExists(SH_INPUT) And ws.Name <> SH_INPUT Then
            ThisWorkbook.Worksheets(SH_INPUT).Visible = xlSheetVisible
            ThisWorkbook.Worksheets(SH_INPUT).Activate
        Else
            For Each candidate In ThisWorkbook.Worksheets
                If candidate.Name <> ws.Name And candidate.Visible = xlSheetVisible Then
                    candidate.Activate
                    Exit For
                End If
            Next candidate
        End If
    End If
    If ActiveSheet.Name <> ws.Name Then ws.Visible = xlSheetVeryHidden
    On Error GoTo 0
End Sub

Public Sub HideSheetIfExists(ByVal sheetName As String)
    On Error Resume Next
    If SheetExists(sheetName) Then
        If ThisWorkbook.Worksheets(sheetName).Name <> ActiveSheet.Name Then ThisWorkbook.Worksheets(sheetName).Visible = xlSheetHidden
    End If
    On Error GoTo 0
End Sub

Public Sub ShowCandidateSheets()
    '旧版ボタンとの互換入口。現在は5枚を同時表示せず、候補管理パネルへ集約する。
    ShowBankCandidates
End Sub

Public Sub ShowConfigSheet()
    Dim ws As Worksheet
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim reprotectErrorNumber As Long, reprotectErrorDescription As String
    Dim reprotectErrorSource As String
    Dim eventStateDetail As String
    If Not RequireToolReady() Then Exit Sub
    On Error GoTo EH
    Set ws = ThisWorkbook.Worksheets(SH_CONFIG)
    ProtectConfigSheet True
    ws.Visible = xlSheetVisible
    ws.Activate
    If Not ThisWorkbook.ReadOnly Then ws.Range("C4").Select
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    'ProtectConfigSheetが既にRecovery終端を所有した場合は、再保護・UI表示で
    '元のfatalを洗浄せず、fresh False exactだけを確認してそのまま返す。
    If UtilitiesNestedRecoveryHardBarrierError( _
           errorNumber, errorSource) Then
        On Error Resume Next
        Call TryHoldFormattingEventsStopped(eventStateDetail)
        On Error GoTo 0
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    On Error Resume Next
    If Not ws Is Nothing Then
        Err.Clear
        ProtectConfigSheet True
        reprotectErrorNumber = Err.Number
        reprotectErrorDescription = Err.Description
        reprotectErrorSource = Err.Source
        If UtilitiesNestedRecoveryHardBarrierError( _
               reprotectErrorNumber, reprotectErrorSource) Then
            On Error Resume Next
            Call TryHoldFormattingEventsStopped(eventStateDetail)
            On Error GoTo 0
            Err.Raise reprotectErrorNumber, reprotectErrorSource, _
                      reprotectErrorDescription
        End If
        Err.Clear
        If reprotectErrorNumber <> 0 Then _
            errorDescription = errorDescription & _
                               " / 設定シートの緊急再保護エラー: Err " & _
                               CStr(reprotectErrorNumber) & " " & reprotectErrorDescription
    End If
    On Error GoTo 0
    MsgBox "設定シートを表示できませんでした。" & vbCrLf & _
           "Err " & errorNumber & ": " & errorDescription, vbExclamation
End Sub

Public Sub ShowInputSheet()
    '取扱店変換対象や出力シートから、入力作業の中心画面へ戻るための導線。
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim eventStateDetail As String
    If Not RequireToolReady() Then Exit Sub
    On Error GoTo EH
    ThisWorkbook.Worksheets(SH_INPUT).Visible = xlSheetVisible
    ThisWorkbook.Worksheets(SH_INPUT).Activate
    HideDailySheets False
    ProtectInputSheet True
    EnableInputKeys
    If Not ThisWorkbook.ReadOnly Then _
        ThisWorkbook.Worksheets(SH_INPUT).Range(CELL_BANK).Select
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    'この表示導線はAppBeginを所有しない。外側処理または別の復旧経路が
    '捕捉しているApplication leaseへAppForceRestoreを掛けない。
    If UtilitiesNestedRecoveryHardBarrierError( _
           errorNumber, errorSource) Then
        On Error Resume Next
        Call TryHoldFormattingEventsStopped(eventStateDetail)
        On Error GoTo 0
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    MsgBox "入力シートを表示できませんでした。" & vbCrLf & _
           "Err " & errorNumber & ": " & errorDescription, vbExclamation
End Sub

Public Sub ShowCheckSheet()
    Dim ws As Worksheet, lastR As Long
    If Not SheetExists(SH_CHECK) Then Exit Sub
    Set ws = ThisWorkbook.Worksheets(SH_CHECK)
    ws.Visible = xlSheetVisible
    ApplyCheckLogLayout ws
    ws.Activate
    SafeFreezeOutputHeader ws
    lastR = LastDataRowInColumns(ws, 1, 4)
    If lastR < 2 Then lastR = 2
    Application.Goto ws.Cells(lastR, 1), True
End Sub
Public Sub ShowShopConversionTargetSheet()
    If Not SheetExists(SH_SHOP_TARGET) Then Exit Sub
    On Error Resume Next
    ThisWorkbook.Worksheets(SH_SHOP_TARGET).Visible = xlSheetVisible
    ThisWorkbook.Worksheets(SH_SHOP_TARGET).Activate
    If Not ThisWorkbook.ReadOnly Then _
        ThisWorkbook.Worksheets(SH_SHOP_TARGET).Range("A1").Select
    On Error GoTo 0
End Sub

Public Sub ShowConvertedCashOperationSheet()
    If Not SheetExists(SH_OUTPUT_TX_CONVERTED) Then Exit Sub
    On Error Resume Next
    ThisWorkbook.Worksheets(SH_OUTPUT_TX_CONVERTED).Visible = xlSheetVisible
    ThisWorkbook.Worksheets(SH_OUTPUT_TX_CONVERTED).Activate
    If Not ThisWorkbook.ReadOnly Then _
        ThisWorkbook.Worksheets(SH_OUTPUT_TX_CONVERTED).Range("A1").Select
    On Error GoTo 0
End Sub

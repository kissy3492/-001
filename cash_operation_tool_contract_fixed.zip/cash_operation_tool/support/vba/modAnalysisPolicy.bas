﻿Attribute VB_Name = "modAnalysisPolicy"
Option Explicit

'自動候補の共通ハードゲート。
'画面側の設定値や旧ブック値が残っていても、この上限を広げてはならない。
Private Const AUTO_CANDIDATE_AMOUNT_EPSILON As Double = 0.0000001
Public Const AUTO_CANDIDATE_MIN_DEPOSIT_RATIO As Double = 0.9
Public Const AUTO_CANDIDATE_MAX_DEPOSIT_RATIO As Double = 1.1
Public Const AUTO_CANDIDATE_MAX_AMOUNT_DIFFERENCE As Double = 1000000#
Public Const AUTO_CANDIDATE_MAX_CALENDAR_DAYS As Long = 3
Public Const AUTO_CANDIDATE_MAX_GROUP_TRANSACTIONS As Long = 4

Private Function EffectiveAutoCandidateAbsoluteTolerance( _
        ByVal configuredAbsoluteTolerance As Double) As Double
    If configuredAbsoluteTolerance <= 0# Then Exit Function
    If configuredAbsoluteTolerance > AUTO_CANDIDATE_MAX_AMOUNT_DIFFERENCE Then
        EffectiveAutoCandidateAbsoluteTolerance = AUTO_CANDIDATE_MAX_AMOUNT_DIFFERENCE
    Else
        EffectiveAutoCandidateAbsoluteTolerance = configuredAbsoluteTolerance
    End If
End Function

Private Function EffectiveAutoCandidateRateTolerance( _
        ByVal configuredRateTolerance As Double) As Double
    If configuredRateTolerance <= 0# Then Exit Function
    If configuredRateTolerance > 10# Then
        EffectiveAutoCandidateRateTolerance = 10#
    Else
        EffectiveAutoCandidateRateTolerance = configuredRateTolerance
    End If
End Function

Public Function AutoCandidateEffectiveDayWindow(ByVal configuredDayWindow As Long) As Long
    '負方向は常に禁止し、設定値は0～3暦日の範囲を狭めることだけができる。
    If configuredDayWindow <= 0 Then Exit Function
    If configuredDayWindow > AUTO_CANDIDATE_MAX_CALENDAR_DAYS Then
        AutoCandidateEffectiveDayWindow = AUTO_CANDIDATE_MAX_CALENDAR_DAYS
    Else
        AutoCandidateEffectiveDayWindow = configuredDayWindow
    End If
End Function

Public Function AutoCandidateAmountGatePasses(ByVal withdrawalAmount As Double, _
                                               ByVal depositAmount As Double, _
                                               Optional ByVal configuredAbsoluteTolerance As Double = 1000000#, _
                                               Optional ByVal configuredRateTolerance As Double = 10#) As Boolean
    Dim effectiveAbsoluteTolerance As Double, effectiveRateTolerance As Double
    Dim configuredMinimumRatio As Double, configuredMaximumRatio As Double
    If withdrawalAmount <= 0# Or depositAmount <= 0# Then Exit Function
    effectiveAbsoluteTolerance = _
        EffectiveAutoCandidateAbsoluteTolerance(configuredAbsoluteTolerance)
    effectiveRateTolerance = EffectiveAutoCandidateRateTolerance(configuredRateTolerance)
    configuredMinimumRatio = 1# - effectiveRateTolerance / 100#
    configuredMaximumRatio = 1# + effectiveRateTolerance / 100#
    If configuredMinimumRatio < AUTO_CANDIDATE_MIN_DEPOSIT_RATIO Then _
        configuredMinimumRatio = AUTO_CANDIDATE_MIN_DEPOSIT_RATIO
    If configuredMaximumRatio > AUTO_CANDIDATE_MAX_DEPOSIT_RATIO Then _
        configuredMaximumRatio = AUTO_CANDIDATE_MAX_DEPOSIT_RATIO

    '設定値は決定済みハードゲートを狭めることだけができ、広げることはできない。
    If depositAmount + AUTO_CANDIDATE_AMOUNT_EPSILON < withdrawalAmount * configuredMinimumRatio Then Exit Function
    If depositAmount - AUTO_CANDIDATE_AMOUNT_EPSILON > withdrawalAmount * configuredMaximumRatio Then Exit Function
    If Abs(depositAmount - withdrawalAmount) > effectiveAbsoluteTolerance + AUTO_CANDIDATE_AMOUNT_EPSILON Then _
        Exit Function
    AutoCandidateAmountGatePasses = True
End Function

Public Sub AutoCandidateAmountSearchBounds(ByVal withdrawalAmount As Double, _
                                            ByRef lowerDepositAmount As Double, _
                                            ByRef upperDepositAmount As Double, _
                                            Optional ByVal configuredAbsoluteTolerance As Double = 1000000#, _
                                            Optional ByVal configuredRateTolerance As Double = 10#)
    Dim rateLower As Double, rateUpper As Double
    Dim differenceLower As Double, differenceUpper As Double
    Dim effectiveAbsoluteTolerance As Double, effectiveRateTolerance As Double
    If withdrawalAmount <= 0# Then _
        Err.Raise vbObjectError + 5094, "AutoCandidateAmountSearchBounds", _
                  "出金額は0円より大きい必要があります。"

    effectiveAbsoluteTolerance = _
        EffectiveAutoCandidateAbsoluteTolerance(configuredAbsoluteTolerance)
    effectiveRateTolerance = EffectiveAutoCandidateRateTolerance(configuredRateTolerance)
    rateLower = withdrawalAmount * (1# - effectiveRateTolerance / 100#)
    If rateLower < withdrawalAmount * AUTO_CANDIDATE_MIN_DEPOSIT_RATIO Then _
        rateLower = withdrawalAmount * AUTO_CANDIDATE_MIN_DEPOSIT_RATIO
    rateUpper = withdrawalAmount * (1# + effectiveRateTolerance / 100#)
    If rateUpper > withdrawalAmount * AUTO_CANDIDATE_MAX_DEPOSIT_RATIO Then _
        rateUpper = withdrawalAmount * AUTO_CANDIDATE_MAX_DEPOSIT_RATIO
    differenceLower = withdrawalAmount - effectiveAbsoluteTolerance
    differenceUpper = withdrawalAmount + effectiveAbsoluteTolerance
    If differenceLower < 0# Then differenceLower = 0#

    '採否判定が許容する丸め幅を、候補を探す範囲にも含める。
    rateLower = rateLower - AUTO_CANDIDATE_AMOUNT_EPSILON
    rateUpper = rateUpper + AUTO_CANDIDATE_AMOUNT_EPSILON
    differenceLower = differenceLower - AUTO_CANDIDATE_AMOUNT_EPSILON
    differenceUpper = differenceUpper + AUTO_CANDIDATE_AMOUNT_EPSILON
    lowerDepositAmount = rateLower
    If differenceLower > lowerDepositAmount Then lowerDepositAmount = differenceLower
    upperDepositAmount = rateUpper
    If differenceUpper < upperDepositAmount Then upperDepositAmount = differenceUpper
End Sub

'入金額が既知で、対応する出金束を金額順配列から探索するときの逆向き索引範囲。
'最終判定自体は常に AutoCandidateAmountGatePasses(出金額, 入金額) で行う。
Public Sub AutoCandidateWithdrawalSearchBounds(ByVal depositAmount As Double, _
                                                ByRef lowerWithdrawalAmount As Double, _
                                                ByRef upperWithdrawalAmount As Double, _
                                                Optional ByVal configuredAbsoluteTolerance As Double = 1000000#, _
                                                Optional ByVal configuredRateTolerance As Double = 10#)
    Dim minimumRatio As Double, maximumRatio As Double
    Dim ratioLower As Double, ratioUpper As Double
    Dim differenceLower As Double, differenceUpper As Double
    Dim effectiveAbsoluteTolerance As Double, effectiveRateTolerance As Double
    If depositAmount <= 0# Then _
        Err.Raise vbObjectError + 5095, "AutoCandidateWithdrawalSearchBounds", _
                  "入金額は0円より大きい必要があります。"

    effectiveAbsoluteTolerance = _
        EffectiveAutoCandidateAbsoluteTolerance(configuredAbsoluteTolerance)
    effectiveRateTolerance = EffectiveAutoCandidateRateTolerance(configuredRateTolerance)
    minimumRatio = 1# - effectiveRateTolerance / 100#
    maximumRatio = 1# + effectiveRateTolerance / 100#
    If minimumRatio < AUTO_CANDIDATE_MIN_DEPOSIT_RATIO Then _
        minimumRatio = AUTO_CANDIDATE_MIN_DEPOSIT_RATIO
    If maximumRatio > AUTO_CANDIDATE_MAX_DEPOSIT_RATIO Then _
        maximumRatio = AUTO_CANDIDATE_MAX_DEPOSIT_RATIO
    ratioLower = (depositAmount - AUTO_CANDIDATE_AMOUNT_EPSILON) / maximumRatio
    ratioUpper = (depositAmount + AUTO_CANDIDATE_AMOUNT_EPSILON) / minimumRatio
    differenceLower = depositAmount - effectiveAbsoluteTolerance - AUTO_CANDIDATE_AMOUNT_EPSILON
    differenceUpper = depositAmount + effectiveAbsoluteTolerance + AUTO_CANDIDATE_AMOUNT_EPSILON
    If differenceLower < 0# Then differenceLower = 0#

    lowerWithdrawalAmount = ratioLower
    If differenceLower > lowerWithdrawalAmount Then lowerWithdrawalAmount = differenceLower
    upperWithdrawalAmount = ratioUpper
    If differenceUpper < upperWithdrawalAmount Then upperWithdrawalAmount = differenceUpper
End Sub

'1対1を含む自動候補の形状契約。複数束は1:2、2:1、1:3、3:1、2:2だけとなる。
Public Function AutoCandidateGroupShapePasses(ByVal withdrawalCount As Long, _
                                               ByVal depositCount As Long) As Boolean
    If withdrawalCount < 1 Or depositCount < 1 Then Exit Function
    If withdrawalCount >= AUTO_CANDIDATE_MAX_GROUP_TRANSACTIONS Or _
       depositCount >= AUTO_CANDIDATE_MAX_GROUP_TRANSACTIONS Then Exit Function
    If withdrawalCount + depositCount > AUTO_CANDIDATE_MAX_GROUP_TRANSACTIONS Then _
        Exit Function
    AutoCandidateGroupShapePasses = True
End Function

'1対1候補では、出金日を0日目として入金日が0～3暦日内であること。
'複数束は代表日を推定せず、下のS41全組合せゲートで判定する。
Public Function AutoCandidateDepositDatePasses(ByVal withdrawalDateSerial As Long, _
                                                ByVal depositDateSerial As Long, _
                                                Optional ByVal configuredDayWindow As Long = 3) As Boolean
    Dim dayDifference As Long
    If withdrawalDateSerial <= 0 Or depositDateSerial <= 0 Then Exit Function
    dayDifference = depositDateSerial - withdrawalDateSerial
    AutoCandidateDepositDatePasses = _
        (dayDifference >= 0 And _
         dayDifference <= AutoCandidateEffectiveDayWindow(configuredDayWindow))
End Function

'束内の全出金日と全入金日の直積が、出金日を0日目として0～3暦日内であること。
'端点だけで判定できるが、逆転・不正な端点は推定で補正せずfail closedとする。
Public Function AutoCandidateBundleDatePasses(ByVal withdrawalMinDate As Long, _
                                               ByVal withdrawalMaxDate As Long, _
                                               ByVal depositMinDate As Long, _
                                               ByVal depositMaxDate As Long, _
                                               Optional ByVal configuredDayWindow As Long = 3) As Boolean
    Dim effectiveDayWindow As Long
    If withdrawalMinDate <= 0 Or withdrawalMaxDate <= 0 Or _
       depositMinDate <= 0 Or depositMaxDate <= 0 Then Exit Function
    If withdrawalMinDate > withdrawalMaxDate Or depositMinDate > depositMaxDate Then Exit Function
    effectiveDayWindow = AutoCandidateEffectiveDayWindow(configuredDayWindow)
    If depositMinDate < withdrawalMaxDate Then Exit Function
    If depositMaxDate - withdrawalMinDate > effectiveDayWindow Then Exit Function
    AutoCandidateBundleDatePasses = True
End Function

'日付が同じ場合、両時刻が記録されている組だけは記録上の逆転を確定できる。
'時刻欠落を入力順・行順で補完せず、矛盾がない未確定候補として残す。
Public Function AutoCandidatePairChronologyPasses( _
        ByVal withdrawalDateSerial As Long, ByVal withdrawalHasTime As Boolean, _
        ByVal withdrawalTimeFraction As Double, ByVal depositDateSerial As Long, _
        ByVal depositHasTime As Boolean, ByVal depositTimeFraction As Double) As Boolean
    Const TIME_EPSILON As Double = 0.000000001
    If withdrawalDateSerial <= 0 Or depositDateSerial <= 0 Then Exit Function
    If depositDateSerial < withdrawalDateSerial Then Exit Function
    If depositDateSerial > withdrawalDateSerial Then
        AutoCandidatePairChronologyPasses = True
        Exit Function
    End If
    If withdrawalHasTime And depositHasTime Then
        If withdrawalTimeFraction < 0# Or withdrawalTimeFraction >= 1# Or _
           depositTimeFraction < 0# Or depositTimeFraction >= 1# Then Exit Function
        If depositTimeFraction + TIME_EPSILON < withdrawalTimeFraction Then Exit Function
    End If
    AutoCandidatePairChronologyPasses = True
End Function

'複数束の全件に時刻がある場合は、最後の出金より最初の入金が前なら不採用。
'候補内の全出金×入金に既知の逆時刻がないことを端点で判定する。
Public Function AutoCandidateBundleChronologyPasses( _
        ByVal withdrawalMaxDate As Long, ByVal withdrawalMaxStamp As Double, _
        ByVal withdrawalHasAllTimes As Boolean, ByVal depositMinDate As Long, _
        ByVal depositMinStamp As Double, ByVal depositHasAllTimes As Boolean) As Boolean
    Const TIME_EPSILON As Double = 0.000000001
    If withdrawalMaxDate <= 0 Or depositMinDate <= 0 Then Exit Function
    If depositMinDate < withdrawalMaxDate Then Exit Function
    If depositMinDate > withdrawalMaxDate Then
        AutoCandidateBundleChronologyPasses = True
        Exit Function
    End If
    If withdrawalHasAllTimes And depositHasAllTimes Then
        If depositMinStamp + TIME_EPSILON < withdrawalMaxStamp Then Exit Function
    End If
    AutoCandidateBundleChronologyPasses = True
End Function

Public Function AutoCandidateTimeEvidenceLabel(ByVal withdrawalHasTime As Boolean, _
                                                ByVal depositHasTime As Boolean, _
                                                ByVal sameCalendarDate As Boolean) As String
    If withdrawalHasTime And depositHasTime Then
        AutoCandidateTimeEvidenceLabel = "時刻記載あり"
    ElseIf sameCalendarDate Then
        AutoCandidateTimeEvidenceLabel = "時刻記載なし・同日内順序不明"
    Else
        AutoCandidateTimeEvidenceLabel = "時刻記載なし"
    End If
End Function

'人物IDと名義人は、取引が所属する口座の正本と一致している必要がある。
Public Function AutoCandidatePersonIntegrityPasses(ByVal accountPersonID As String, _
                                                    ByVal transactionPersonID As String, _
                                                    ByVal accountPersonName As String, _
                                                    ByVal transactionPersonName As String) As Boolean
    Dim accountNameKey As String, transactionNameKey As String
    accountPersonID = CellText(accountPersonID)
    transactionPersonID = CellText(transactionPersonID)
    If Len(accountPersonID) = 0 Or Len(transactionPersonID) = 0 Then Exit Function
    If Not IsInternalIdValue(accountPersonID, "P") Or _
       Not IsInternalIdValue(transactionPersonID, "P") Then Exit Function
    If StrComp(accountPersonID, transactionPersonID, vbTextCompare) <> 0 Then Exit Function

    accountNameKey = NormalizePersonNameKey(CellText(accountPersonName))
    transactionNameKey = NormalizePersonNameKey(CellText(transactionPersonName))
    If Len(accountNameKey) = 0 Or Len(transactionNameKey) = 0 Then Exit Function
    If StrComp(accountNameKey, transactionNameKey, vbTextCompare) <> 0 Then Exit Function
    AutoCandidatePersonIntegrityPasses = True
End Function

Public Function AutoCandidateIsDifferentPerson(ByVal withdrawalPersonID As String, _
                                                ByVal depositPersonID As String) As Boolean
    withdrawalPersonID = CellText(withdrawalPersonID)
    depositPersonID = CellText(depositPersonID)
    If Not IsInternalIdValue(withdrawalPersonID, "P") Or _
       Not IsInternalIdValue(depositPersonID, "P") Then Exit Function
    AutoCandidateIsDifferentPerson = _
        (StrComp(withdrawalPersonID, depositPersonID, vbTextCompare) <> 0)
End Function

'シートを書き換えず、決定済み境界だけを固定する。

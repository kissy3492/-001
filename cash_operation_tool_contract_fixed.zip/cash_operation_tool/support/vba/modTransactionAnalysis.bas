﻿Attribute VB_Name = "modTransactionAnalysis"
Option Explicit

Private Const ANALYSIS_BUFFER_ROWS As Long = 1000
Private Const ANALYSIS_CHECK_MAX_DETAIL_CHARS As Long = 700000
Private Const ANALYSIS_CONTEXT_TEXT_MAX As Long = 700
Private Const TRANSACTION_ATOMIC_SHEET_COUNT As Long = 11
Private Const TRANSACTION_ATOMIC_DETAIL_LAST_COL As Long = 12
Private Const TRANSACTION_ATOMIC_SNAPSHOT_COPIES As Long = 3
Private Const TRANSACTION_ATOMIC_CASH_STATE_ROWS As Long = 9
Private Const TRANSACTION_OPERATION_PEAK_SNAPSHOT_SETS As Long = 2
Private Const ALLOCATION_AMBIGUITY_MEMO_MARKER As String = _
    "[自動] 複数取引側の差額帰属"

Private Type TransactionAnalysisSheetSnapshot
    SheetName As String
    LabelText As String
    LastColumn As Long
    MaximumDataRows As Long
    HeaderData As Variant
    Data As Variant
    LastRow As Long
    Visibility As Long
    WasProtected As Boolean
End Type

Private Type TransactionCashViewSnapshot
    Captured As Boolean
    PanelData As Variant
    Data As Variant
    DataLastRow As Long
    Visibility As Long
    WasProtected As Boolean
    WorkCashVisibility As Long
    WorkCashWasProtected As Boolean
    WasActive As Boolean
    SelectionAddress As String
    ActiveCellAddress As String
    WindowStateCaptured As Boolean
    FreezePanes As Boolean
    SplitRow As Long
    SplitColumn As Long
    ScrollRow As Long
    ScrollColumn As Long
    Zoom As Long
    EntryActiveSheetName As String
    EntryActiveCellAddress As String
End Type

Private mAnalysisRowEvidenceCache As Object
Private mAnalysisInheritanceDate As Variant
Private mAnalysisOperationActive As Boolean
Private mAnalysisOperationName As String
Private mAnalysisOperationSheets() As TransactionAnalysisSheetSnapshot
Private mAnalysisOperationCash As TransactionCashViewSnapshot
Private mAnalysisOperationDetailReviewsDirty As Boolean
Private mAnalysisOperationWorkbookWasSaved As Boolean
Private mAnalysisOperationEntryEvents As Boolean
Private mAnalysisOperationEntryInheritanceDate As Variant
Private mAnalysisOperationConfirmedWorkloadRows As Double
Private mAnalysisOperationPeakSnapshotCellWork As Double
Private mAnalysisOperationAllocationSnapshot As Variant
Private mAnalysisOperationAllocationSnapshotLastRow As Long
Private mAnalysisOperationAllocationSnapshotDigest As String
Private mAnalysisOperationAllocationSnapshotCaptured As Boolean

Public Function ShiftAnalysisHeaders() As Variant
    ShiftAnalysisHeaders = Array( _
        "評価", "スコア", "照合形式", "時系列", "時刻精度", "経過", "金額照合", "金額差", _
        "出金日", "出金時刻", "出金氏名", "出金続柄", "出金銀行", "出金支店", "出金科目", _
        "出金口座番号", "出金額", "出金摘要", "入金日", "入金時刻", "入金氏名", "入金続柄", _
        "入金銀行", "入金支店", "入金科目", "入金口座番号", "入金額", "入金摘要", "判定理由", _
        "確認状況", "確認メモ", "候補キー", "出金取引ID", "入金取引ID")
End Function

Public Function UnknownAnalysisHeaders() As Variant
    UnknownAnalysisHeaders = Array( _
        "確認優先度", "スコア", "不明区分", "日付", "時刻", "時刻精度", "氏名", "続柄", _
        "銀行", "支店", "科目", "口座番号", "入金", "出金", "取扱店", "機番", "摘要", _
        "候補件数（全/確認済）", "最高候補評価", "抽出理由", "確認状況", "確認メモ", "登録元", _
        "取引ID", "口座ID", "確認キー")
End Function

Public Sub SetupTransactionAnalysisSheets(Optional ByVal preserveVisibility As Boolean = False)
    Dim shiftVisible As XlSheetVisibility, flowVisible As XlSheetVisibility
    Dim unknownVisible As XlSheetVisibility
    Dim ws As Worksheet
    Dim convergenceDetail As String
    Dim cleanupErrorNumber As Long
    Dim cleanupErrorDescription As String, cleanupErrorSource As String
    Dim errorNumber As Long, errorDescription As String, errorSource As String

    On Error GoTo EH

    If preserveVisibility Then
        shiftVisible = GetSheet(SH_ANALYSIS_SHIFT).Visible
        flowVisible = GetSheet(SH_ANALYSIS_FLOW).Visible
        unknownVisible = GetSheet(SH_ANALYSIS_UNKNOWN).Visible
    End If

    Set ws = GetSheet(SH_ANALYSIS_SHIFT)
    PrepareShiftAnalysisSheet ws
    Set ws = GetSheet(SH_ANALYSIS_FLOW)
    PrepareAdvancedFlowAnalysisSheet ws
    Set ws = GetSheet(SH_ANALYSIS_UNKNOWN)
    PrepareUnknownAnalysisSheet ws
    SetupAnalysisWorkspaceSheets preserveVisibility

    If preserveVisibility Then
        GetSheet(SH_ANALYSIS_SHIFT).Visible = shiftVisible
        GetSheet(SH_ANALYSIS_FLOW).Visible = flowVisible
        GetSheet(SH_ANALYSIS_UNKNOWN).Visible = unknownVisible
    End If
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    If IsTransactionAnalysisRecoveryFatal(errorNumber, errorSource) Then
        Call TryStopTransactionAnalysisEventsForBookWrites(convergenceDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    On Error Resume Next
    Err.Clear
    ProtectTransactionAnalysisSheets False
    cleanupErrorNumber = Err.Number
    cleanupErrorSource = Err.Source
    cleanupErrorDescription = Err.Description
    Err.Clear
    On Error GoTo 0
    If IsTransactionAnalysisRecoveryFatal( _
           cleanupErrorNumber, cleanupErrorSource) Then
        Call TryStopTransactionAnalysisEventsForBookWrites(convergenceDetail)
        Err.Raise cleanupErrorNumber, cleanupErrorSource, _
                  cleanupErrorDescription
    End If
    On Error Resume Next
    If SheetExists(SH_WORK_ANALYSIS_GROUP) Then _
        SetSheetVeryHiddenSafe GetSheet(SH_WORK_ANALYSIS_GROUP)
    If preserveVisibility Then
        GetSheet(SH_ANALYSIS_SHIFT).Visible = shiftVisible
        GetSheet(SH_ANALYSIS_FLOW).Visible = flowVisible
        GetSheet(SH_ANALYSIS_UNKNOWN).Visible = unknownVisible
    End If
    On Error GoTo 0
    Err.Raise errorNumber, "SetupTransactionAnalysisSheets", errorSource & " / " & errorDescription
End Sub

Public Function AnalysisOperationTransactionIsActive() As Boolean
    AnalysisOperationTransactionIsActive = mAnalysisOperationActive
End Function

Public Function AnalysisOperationConfirmedWorkloadRows() As Double
    If Not mAnalysisOperationActive Then _
        Err.Raise vbObjectError + 4686, _
                  "AnalysisOperationConfirmedWorkloadRows", _
                  "分析操作トランザクションが開始されていません。"
    AnalysisOperationConfirmedWorkloadRows = _
        mAnalysisOperationConfirmedWorkloadRows
End Function

Public Sub BeginAnalysisOperationTransaction(ByVal operationName As String)
    '資金操作表など、確認値の変更から台帳確定まで複数moduleへまたがる操作を、
    '利用者が編集する前の1時点へまとめて戻せるよう外側で退避する。
    Dim recoveryLatchSet As Boolean
    Dim confirmedWorkloadRows As Double
    Dim atomicSnapshotCellWork As Double
    Dim eventStateDetail As String
    Dim errorNumber As Long, errorDescription As String, errorSource As String

    On Error GoTo EH
    If mAnalysisOperationActive Then _
        Err.Raise vbObjectError + 4678, "BeginAnalysisOperationTransaction", _
                  "別の分析操作トランザクションが実行中です。"
    If Not TryGetRollbackRecoveryLatch(recoveryLatchSet) Then _
        Err.Raise vbObjectError + 4679, "BeginAnalysisOperationTransaction", _
                  "ロールバック要復旧状態を確認できません。"
    If recoveryLatchSet Then _
        Err.Raise vbObjectError + 4679, "BeginAnalysisOperationTransaction", _
                  "前回のロールバック要復旧状態が残っているため、分析操作を開始できません。"
    If ThisWorkbook.ReadOnly Then _
        Err.Raise vbObjectError + 4680, "BeginAnalysisOperationTransaction", _
                  "読み取り専用のため、分析判断を保存できません。"
    If Not SheetExists(SH_OUTPUT_TX) Or Not SheetExists(SH_WORK_CASH) Then _
        Err.Raise vbObjectError + 4681, "BeginAnalysisOperationTransaction", _
                  "資金操作表または予定資金表がありません。"
    If Len(Trim$(operationName)) = 0 Then operationName = "分析判断の保存"

    '後段のCommit中は外側退避を保持したまま、元3表と手動候補の内側退避も作る。
    '外側退避2組相当を同時保持ピークとして入口で確認し、C3変更後は確認しない。
    If Not RequireManualFlowMutationCapacity(operationName) Then _
        Err.Raise 18, "BeginAnalysisOperationTransaction", _
                  "利用者が手動候補の容量確認を取り消しました。"
    InitializeTransactionAnalysisAtomicSheets mAnalysisOperationSheets
    atomicSnapshotCellWork = _
        TransactionAnalysisAtomicSnapshotCellWork(mAnalysisOperationSheets, True)
    mAnalysisOperationPeakSnapshotCellWork = _
        TransactionAnalysisOperationPeakSnapshotCellWork(atomicSnapshotCellWork)
    If Not ConfirmAnalysisReviewOperationCapacity( _
               operationName, confirmedWorkloadRows, _
               additionalSnapshotCellWork:=mAnalysisOperationPeakSnapshotCellWork) Then _
        Err.Raise 18, "BeginAnalysisOperationTransaction", _
                  "利用者が分析判断の容量確認を取り消しました。"

    mAnalysisOperationName = operationName
    mAnalysisOperationWorkbookWasSaved = ThisWorkbook.Saved
    If Not TryGetTransactionAnalysisEnableEvents( _
               mAnalysisOperationEntryEvents, eventStateDetail) Then _
        Err.Raise vbObjectError + 4701, "BeginAnalysisOperationTransaction", _
                  "Excelイベントの開始状態を取得できませんでした。 " & eventStateDetail
    mAnalysisOperationEntryInheritanceDate = mAnalysisInheritanceDate
    CaptureTransactionAnalysisAtomicSnapshot _
        mAnalysisOperationSheets, True, mAnalysisOperationCash
    CaptureAllocationLedgerTransactionSnapshot _
        mAnalysisOperationAllocationSnapshot, _
        mAnalysisOperationAllocationSnapshotLastRow, _
        mAnalysisOperationAllocationSnapshotDigest
    mAnalysisOperationAllocationSnapshotCaptured = True
    mAnalysisOperationDetailReviewsDirty = AnalysisDetailReviewDirtySnapshot()
    mAnalysisOperationConfirmedWorkloadRows = confirmedWorkloadRows
    mAnalysisOperationActive = True
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    ResetAnalysisOperationTransactionState
    Err.Raise errorNumber, "BeginAnalysisOperationTransaction", errorDescription
End Sub

Public Sub CommitAnalysisOperationPendingReviews( _
        Optional ByVal reasonText As String = "資金操作表から分析判断を保存")
    If Not mAnalysisOperationActive Then _
        Err.Raise vbObjectError + 4682, _
                  "CommitAnalysisOperationPendingReviews", _
                  "分析操作トランザクションが開始されていません。"
    CommitPendingAnalysisReviews _
        False, reasonText, True, mAnalysisOperationConfirmedWorkloadRows, _
        False, mAnalysisOperationPeakSnapshotCellWork
End Sub

Public Sub CommitAnalysisOperationTransaction()
    Dim recoveryLatchSet As Boolean
    Dim currentEvents As Boolean, eventStateDetail As String
    If Not mAnalysisOperationActive Then _
        Err.Raise vbObjectError + 4683, _
                  "CommitAnalysisOperationTransaction", _
                  "分析操作トランザクションが開始されていません。"
    If Not TryGetRollbackRecoveryLatch(recoveryLatchSet) Then _
        Err.Raise vbObjectError + 4684, _
                  "CommitAnalysisOperationTransaction", _
                  "ロールバック要復旧状態を読み返せないため、分析操作を確定できません。"
    If recoveryLatchSet Then _
        Err.Raise vbObjectError + 4684, _
                  "CommitAnalysisOperationTransaction", _
                  "ロールバック要復旧状態があるため、分析操作を確定できません。"
    If Not TryGetTransactionAnalysisEnableEvents( _
               currentEvents, eventStateDetail) Then _
        Err.Raise vbObjectError + 4702, "CommitAnalysisOperationTransaction", _
                  "Excelイベント状態を確認できませんでした。 " & eventStateDetail
    If currentEvents <> mAnalysisOperationEntryEvents Then _
        Err.Raise vbObjectError + 4687, _
                  "CommitAnalysisOperationTransaction", _
                  "Excelイベント状態が操作開始時と一致しないため、分析操作を確定できません。"
    If HasPendingAnalysisReviewChanges() Then _
        Err.Raise vbObjectError + 4688, _
                  "CommitAnalysisOperationTransaction", _
                  "未保存の分析判断が残っているため、分析操作を確定できません。"
    ResetAnalysisOperationTransactionState
End Sub

Public Function RollbackAnalysisOperationTransaction( _
        ByRef detailText As String) As Boolean
    Dim restoreOK As Boolean
    Dim recoveryLatchSet As Boolean, latchReadSucceeded As Boolean
    Dim recoveryConfirmed As Boolean, safeToRestoreEntry As Boolean
    Dim recoveryEnforcementFailed As Boolean
    Dim recoveryAttempted As Boolean
    Dim applicationStateConfirmed As Boolean
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim eventStateDetail As String
    Dim recoveryEventDetail As String
    Dim postEnforceEventDetail As String, convergenceDetail As String
    Dim finalRecoveryEventDetail As String
    Dim eventsReadyForRollback As Boolean

    If Not mAnalysisOperationActive Then
        AppendTransactionRollbackDetail detailText, _
            "分析操作トランザクションの退避がありません。"
        Exit Function
    End If

    restoreOK = True
    eventsReadyForRollback = _
        TrySetTransactionAnalysisEnableEventsExact(False, eventStateDetail)
    If Not eventsReadyForRollback Then
        restoreOK = False
        AppendTransactionRollbackDetail detailText, _
            "Excelイベントを停止して読戻し確認できません: " & eventStateDetail
        AppendTransactionRollbackDetail detailText, _
            "イベント停止未確認のため、退避値をブックへ再書込みしません。"
    End If

    If eventsReadyForRollback Then
        On Error Resume Next
        Err.Clear
        If Not RestoreTransactionAnalysisAtomicSnapshot( _
                   mAnalysisOperationSheets, _
                   mAnalysisOperationDetailReviewsDirty, _
                   mAnalysisOperationCash, detailText) Then _
            restoreOK = False
        errorNumber = Err.Number
        errorSource = Err.Source
        errorDescription = Err.Description
        Err.Clear
        On Error GoTo 0
        If IsTransactionAnalysisRecoveryFatal(errorNumber, errorSource) Then
            Call TryStopTransactionAnalysisEventsForBookWrites( _
                convergenceDetail)
            Err.Raise errorNumber, errorSource, errorDescription
        End If
        On Error Resume Next
        If errorNumber <> 0 Then
            restoreOK = False
            AppendTransactionRollbackDetail detailText, _
                "分析操作の復元エラー: " & errorDescription
        End If
        If mAnalysisOperationAllocationSnapshotCaptured Then
            RestoreAllocationLedgerTransactionSnapshot _
                mAnalysisOperationAllocationSnapshot, _
                mAnalysisOperationAllocationSnapshotLastRow, _
                mAnalysisOperationAllocationSnapshotDigest
            If Err.Number <> 0 Then
                restoreOK = False
                AppendTransactionRollbackDetail detailText, _
                    "配賦元帳の復元エラー: " & Err.Description
            End If
            Err.Clear
        End If

        latchReadSucceeded = TryGetRollbackRecoveryLatch(recoveryLatchSet)
        If Not latchReadSucceeded Then
            restoreOK = False
            AppendTransactionRollbackDetail detailText, _
                "ロールバック要復旧状態を確認できません。"
        ElseIf recoveryLatchSet Then
            restoreOK = False
            AppendTransactionRollbackDetail detailText, _
                "内側の分析処理でロールバック要復旧状態が設定されました。"
        End If
        mAnalysisInheritanceDate = mAnalysisOperationEntryInheritanceDate
        ResetAnalysisEvidenceCache
        If restoreOK And mAnalysisOperationWorkbookWasSaved Then
            ThisWorkbook.Saved = True
            If Err.Number <> 0 Then
                restoreOK = False
                AppendTransactionRollbackDetail detailText, _
                    "ブック保存状態を復元できません: " & Err.Description
            End If
            Err.Clear
        End If
        On Error GoTo 0
    End If

    If Not restoreOK Then
        'Recoveryの記録もブックへの書込みである。初回のイベント停止が
        '失敗した場合はここで再確認し、Falseを読戻せた時だけ実行する。
        If Not eventsReadyForRollback Then
            eventsReadyForRollback = _
                TrySetTransactionAnalysisEnableEventsExact( _
                    False, recoveryEventDetail)
            If eventsReadyForRollback Then
                AppendTransactionRollbackDetail detailText, _
                    "要復旧記録前にExcelイベント停止を再確認しました。"
            Else
                AppendTransactionRollbackDetail detailText, _
                    "Excelイベント停止を再確認できず、" & _
                    "要復旧状態の書込みも安全のため見送りました: " & _
                    recoveryEventDetail
            End If
        End If
        If eventsReadyForRollback Then
            recoveryAttempted = True
            On Error Resume Next
            Err.Clear
            EnforceRollbackRecoveryState detailText
            errorNumber = Err.Number
            errorDescription = Err.Description
            Err.Clear
            On Error GoTo 0
            'Enforceの結果を保存した直後にFalseを再確定する。失敗時は
            '既存Recovery値の読取り・表示書込み・開始値復元へ進まない。
            eventsReadyForRollback = _
                TryStopTransactionAnalysisEventsForBookWrites( _
                    postEnforceEventDetail)
            If errorNumber <> 0 Then
                recoveryEnforcementFailed = True
                AppendTransactionRollbackDetail detailText, _
                    "要復旧状態の記録エラー: Err " & _
                    CStr(errorNumber) & " " & errorDescription
            ElseIf eventsReadyForRollback Then
                recoveryConfirmed = _
                    TransactionAnalysisRecoveryStateIsConfirmedExact(detailText)
                If recoveryConfirmed Then
                    applicationStateConfirmed = _
                        TransactionAnalysisApplicationStateAllowsEntryRestore( _
                            True, detailText)
                End If
                If applicationStateConfirmed Then
                    eventsReadyForRollback = _
                        TryStopTransactionAnalysisEventsForBookWrites( _
                            finalRecoveryEventDetail)
                End If
            Else
                AppendTransactionRollbackDetail detailText, _
                    "Recovery処理後にExcelイベント停止を確認できないため、" & _
                    "復旧状態の読取り・状態表示・開始値復元を行いません: " & _
                    postEnforceEventDetail
            End If
            eventsReadyForRollback = _
                TryStopTransactionAnalysisEventsForBookWrites( _
                    convergenceDetail)
            Err.Raise vbObjectError + 5195, _
                      "TransactionAnalysisRecoveryFatal/RollbackAnalysisOperationTransaction", _
                      detailText
        End If
    End If

    safeToRestoreEntry = Not recoveryEnforcementFailed And _
                         Not recoveryAttempted And _
                         eventsReadyForRollback And _
                         (restoreOK Or recoveryConfirmed)
    If safeToRestoreEntry Then
        eventsReadyForRollback = _
            TryStopTransactionAnalysisEventsForBookWrites(eventStateDetail)
        safeToRestoreEntry = eventsReadyForRollback
    End If
    If safeToRestoreEntry Then
        safeToRestoreEntry = _
            TransactionAnalysisApplicationStateAllowsEntryRestore( _
                mAnalysisOperationEntryEvents, detailText)
    End If
    If safeToRestoreEntry Then
        If Not TryRestoreTransactionAnalysisEnableEvents( _
                   mAnalysisOperationEntryEvents, _
                   "分析操作トランザクションのロールバック", _
                   eventStateDetail) Then
            restoreOK = False
            AppendTransactionRollbackDetail detailText, _
                "Excelイベント状態を復元できません: " & eventStateDetail
        End If
    ElseIf TryStopTransactionAnalysisEventsForBookWrites(convergenceDetail) Then
        restoreOK = False
        AppendTransactionRollbackDetail detailText, _
            "ロールバックまたはRecoveryを厳密確認できないため、" & _
            "開始時イベント値へ戻さずFalseで停止しました。"
    Else
        restoreOK = False
        AppendTransactionRollbackDetail detailText, _
            "安全状態を厳密確認できず、ExcelイベントのFalse収束にも" & _
            "失敗しました。現在状態は不明です: " & convergenceDetail
    End If

    '失敗時は再試行できるよう、退避と開始状態を保持する。
    If restoreOK Then ResetAnalysisOperationTransactionState
    RollbackAnalysisOperationTransaction = restoreOK
End Function

Private Sub ResetAnalysisOperationTransactionState()
    mAnalysisOperationActive = False
    mAnalysisOperationName = vbNullString
    Erase mAnalysisOperationSheets
    mAnalysisOperationCash.Captured = False
    mAnalysisOperationCash.PanelData = Empty
    mAnalysisOperationCash.Data = Empty
    mAnalysisOperationCash.SelectionAddress = vbNullString
    mAnalysisOperationCash.ActiveCellAddress = vbNullString
    mAnalysisOperationCash.EntryActiveSheetName = vbNullString
    mAnalysisOperationCash.EntryActiveCellAddress = vbNullString
    mAnalysisOperationDetailReviewsDirty = False
    mAnalysisOperationWorkbookWasSaved = False
    mAnalysisOperationEntryEvents = False
    mAnalysisOperationEntryInheritanceDate = Empty
    mAnalysisOperationConfirmedWorkloadRows = 0#
    mAnalysisOperationPeakSnapshotCellWork = 0#
    mAnalysisOperationAllocationSnapshot = Empty
    mAnalysisOperationAllocationSnapshotLastRow = 0
    mAnalysisOperationAllocationSnapshotDigest = vbNullString
    mAnalysisOperationAllocationSnapshotCaptured = False
End Sub

Public Sub BuildTransactionAnalysisSheetsCore( _
        ByVal activateAfter As Boolean, _
        Optional ByVal capacityConfirmed As Boolean = False, _
        Optional ByRef confirmedAnalysisWorkloadRows As Double = 0#, _
        Optional ByVal allowLateCapacityPrompt As Boolean = True, _
        Optional ByVal outerSnapshotCellWork As Double = 0#)
    Dim wsSource As Worksheet, wsShift As Worksheet, wsFlow As Worksheet, wsUnknown As Worksheet
    Dim sourceData As Variant
    Dim withdrawalRows() As Long, depositRows() As Long
    Dim unknownWithdrawalRows() As Long, unknownDepositRows() As Long
    Dim componentWithdrawalRows() As Long, componentDepositRows() As Long
    Dim depositAmounts() As Double, depositSortRows() As Long
    Dim withdrawalCount As Long, depositCount As Long, sourceRowCount As Long
    Dim componentWithdrawalCount As Long, componentDepositCount As Long
    Dim shiftCount As Long, writtenShiftCount As Long, flowCount As Long
    Dim unknownCount As Long, writtenUnknownCount As Long
    Dim unknownWithdrawalCount As Long, unknownDepositCount As Long
    Dim minAmount As Double, unknownMinAmount As Double
    Dim absoluteTolerance As Double, rateTolerance As Double
    Dim dayWindow As Long
    Dim shiftReviews As Object, flowReviews As Object, unknownReviews As Object
    Dim storedReviews As Object
    Dim candidateCountByTx As Object, bestScoreByTx As Object, bestRatingByTx As Object
    Dim confirmedCountByTx As Object, unknownContextByTx As Object
    Dim allocationIndex As Object
    Dim lastR As Long, r As Long
    Dim detailText As String, personIntegrityProblems As String
    Dim settingsSignature As String, unknownSettingsSignature As String
    Dim errorNumber As Long, errorSource As String
    Dim errorDescription As String, rollbackDetail As String
    Dim preferCashPanel As Boolean
    Dim plannedUnknownRows As Long
    Dim atomicSheets() As TransactionAnalysisSheetSnapshot
    Dim cashSnapshot As TransactionCashViewSnapshot
    Dim atomicSnapshotCellWork As Double
    Dim operationSnapshotCellWork As Double
    Dim cashSnapshotNeeded As Boolean
    Dim atomicSnapshotsCaptured As Boolean, atomicMutationStarted As Boolean
    Dim detailReviewsDirty As Boolean
    Dim rollbackOK As Boolean, recoveryConfirmed As Boolean
    Dim safeToRestoreEntry As Boolean
    Dim applicationStateConfirmed As Boolean
    Dim recoveryLatchSet As Boolean, latchReadSucceeded As Boolean
    Dim entryEvents As Boolean, entryEventsCaptured As Boolean
    Dim eventsReadyForRollback As Boolean, eventStateDetail As String
    Dim recoveryErrorNumber As Long, recoveryErrorDescription As String
    Dim rollbackErrorNumber As Long, rollbackErrorSource As String
    Dim rollbackErrorDescription As String
    Dim recoveryEnforcementFailed As Boolean
    Dim postEnforceEventDetail As String, convergenceDetail As String
    Dim finalRecoveryEventDetail As String
    Dim workbookWasSaved As Boolean, workbookSavedCaptured As Boolean
    Dim entryInheritanceDate As Variant
    Dim allocationSnapshot As Variant
    Dim allocationSnapshotLastRow As Long
    Dim allocationSnapshotDigest As String
    Dim allocationSnapshotCaptured As Boolean

    If outerSnapshotCellWork < 0# Or _
       outerSnapshotCellWork > 2147483647# * 16# Then _
        Err.Raise vbObjectError + 4685, "BuildTransactionAnalysisSheetsCore", _
                  "取引分析の外側退避容量が不正です。"
    If Not capacityConfirmed Then
        If Not RequireOutputBuildCapacity("帳票・分析の更新", activateAfter, False, False, _
                                          True, False, False) Then _
            Err.Raise 18, "BuildTransactionAnalysisSheetsCore", _
                      "利用者が帳票・分析の容量確認を取り消しました。"
        If Not RequireManualFlowMutationCapacity("取引分析の更新") Then _
            Err.Raise 18, "BuildTransactionAnalysisSheetsCore", _
                      "利用者が手動候補の容量確認を取り消しました。"
        capacityConfirmed = True
    End If

    If Not ActiveSheet Is Nothing Then _
        preferCashPanel = (ActiveSheet.Name = SH_OUTPUT_TX)
    cashSnapshotNeeded = SheetExists(SH_OUTPUT_TX) And SheetExists(SH_WORK_CASH) And _
                         (preferCashPanel Or activateAfter)
    InitializeTransactionAnalysisAtomicSheets atomicSheets
    atomicSnapshotCellWork = _
        TransactionAnalysisAtomicSnapshotCellWork(atomicSheets, cashSnapshotNeeded)
    operationSnapshotCellWork = atomicSnapshotCellWork + outerSnapshotCellWork
    If operationSnapshotCellWork < atomicSnapshotCellWork Or _
       operationSnapshotCellWork > 2147483647# * 16# Then _
        Err.Raise vbObjectError + 4685, "BuildTransactionAnalysisSheetsCore", _
                  "取引分析の同時退避容量が安全範囲を超えています。"
    If Not ConfirmAnalysisReviewOperationCapacity( _
               "取引分析の更新", confirmedAnalysisWorkloadRows, _
               allowUserConfirmation:=allowLateCapacityPrompt, _
               additionalSnapshotCellWork:=operationSnapshotCellWork) Then _
        Err.Raise 18, "BuildTransactionAnalysisSheetsCore", _
                  "利用者が分析判断の容量確認を取り消しました。"

    '取消時に保護・非表示・dirty状態を変更しないよう、全入口容量検査の後でEHを有効にする。
    On Error GoTo EH
    '確認記録の同期・退避や候補生成より前に、口座正本と明細の人物情報を検査する。
    '空の初期セットアップはvalidator側で正当な0件としてTrueになる。
    If Not ValidateCorePersonIntegrity(personIntegrityProblems, False) Then
        If Len(Trim$(personIntegrityProblems)) = 0 Then _
            personIntegrityProblems = "人物整合性検査に失敗しました。"
        Err.Raise vbObjectError + 4627, "BuildTransactionAnalysisSheetsCore", _
                  "人物情報の整合性に問題があるため、取引分析を開始できません。" & _
                  vbCrLf & personIntegrityProblems
    End If

    If Not ValidateTransactionAnalysisSettings(detailText) Then _
        Err.Raise vbObjectError + 4600, "BuildTransactionAnalysisSheetsCore", detailText
    ReadTransactionAnalysisSettings minAmount, dayWindow, absoluteTolerance, rateTolerance, _
                                    unknownMinAmount

    Set wsShift = GetSheet(SH_ANALYSIS_SHIFT)
    Set wsFlow = GetSheet(SH_ANALYSIS_FLOW)
    Set wsUnknown = GetSheet(SH_ANALYSIS_UNKNOWN)
    Set wsSource = GetSheet(SH_WORK_TX)
    EnsureExistingAnalysisReviewBounds wsShift, "資金シフト候補"
    EnsureExistingAnalysisReviewBounds wsFlow, "資金フロー追跡"
    EnsureExistingAnalysisReviewBounds wsUnknown, "不明入出金"

    'ここから先は確認同期・台帳保存・出力置換が複数表へ連鎖する。
    '最初の書込みより前に、変更し得る全表と正式UIを同じ時点で退避する。
    workbookWasSaved = ThisWorkbook.Saved
    workbookSavedCaptured = True
    If Not TryGetTransactionAnalysisEnableEvents(entryEvents, eventStateDetail) Then _
        Err.Raise vbObjectError + 4703, "BuildTransactionAnalysisSheetsCore", _
                  "Excelイベントの開始状態を取得できませんでした。 " & eventStateDetail
    entryEventsCaptured = True
    entryInheritanceDate = mAnalysisInheritanceDate
    CaptureTransactionAnalysisAtomicSnapshot atomicSheets, cashSnapshotNeeded, cashSnapshot
    CaptureAllocationLedgerTransactionSnapshot allocationSnapshot, _
        allocationSnapshotLastRow, allocationSnapshotDigest
    allocationSnapshotCaptured = True
    detailReviewsDirty = AnalysisDetailReviewDirtySnapshot()
    atomicSnapshotsCaptured = True

    ResetAnalysisEvidenceCache
    mAnalysisInheritanceDate = GetCfgDateValue(ROW_CFG_INHERITANCE_DATE)
    settingsSignature = AnalysisSettingsSignature(minAmount, dayWindow, absoluteTolerance, rateTolerance)
    unknownSettingsSignature = AnalysisSettingsSignature(unknownMinAmount, dayWindow, _
                                                         absoluteTolerance, rateTolerance) & _
                               "|SCOPE=UNKNOWN"

    '資金操作表上部で更新した確認記録を内部分析結果へ戻し、根拠表と同期してから再分析する。
    atomicMutationStarted = True
    If preferCashPanel Then SyncCashAnalysisPanelReviewToWorkspace
    SyncAnalysisWorkspaceReviewsToSources
    SyncAnalysisDetailReviewsToSources
    '候補詳細の旧スナップショットより、資金操作表の表示中パネル現値を最後に優先する。
    If preferCashPanel Then SyncCashAnalysisPanelReviewToWorkspace
    SyncManualFlowReviewsFromAnalysisSheet True
    '現行3表の確認内容に既存競合があれば、候補生成・表置換・永続台帳保存より前に停止する。
    ResolveAnalysisReviewConflicts wsShift, wsFlow
    PersistAnalysisReviewsFromCurrentSheets False, "再分析前の確認内容を保存"
    Set shiftReviews = CaptureAnalysisReviews(wsShift, SHIFT_ANALYSIS_STATUS_COL, _
                                               SHIFT_ANALYSIS_MEMO_COL, SHIFT_ANALYSIS_KEY_COL)
    Set flowReviews = CaptureAnalysisReviews(wsFlow, FLOW_ANALYSIS_STATUS_COL, _
                                              FLOW_ANALYSIS_MEMO_COL, FLOW_ANALYSIS_KEY_COL)
    Set unknownReviews = CaptureAnalysisReviews(wsUnknown, UNKNOWN_ANALYSIS_STATUS_COL, _
                                                 UNKNOWN_ANALYSIS_MEMO_COL, UNKNOWN_ANALYSIS_KEY_COL)
    Set storedReviews = CapturePersistentAnalysisReviews()
    Set shiftReviews = MergeStoredAnalysisReviews(shiftReviews, storedReviews)
    Set flowReviews = MergeStoredAnalysisReviews(flowReviews, storedReviews)
    Set unknownReviews = MergeStoredAnalysisReviews(unknownReviews, storedReviews)
    Set candidateCountByTx = CreateObject("Scripting.Dictionary")
    Set bestScoreByTx = CreateObject("Scripting.Dictionary")
    Set bestRatingByTx = CreateObject("Scripting.Dictionary")
    Set confirmedCountByTx = CreateObject("Scripting.Dictionary")
    Set unknownContextByTx = CreateObject("Scripting.Dictionary")
    candidateCountByTx.CompareMode = vbTextCompare
    bestScoreByTx.CompareMode = vbTextCompare
    bestRatingByTx.CompareMode = vbTextCompare
    confirmedCountByTx.CompareMode = vbTextCompare
    unknownContextByTx.CompareMode = vbTextCompare

    lastR = LastDataRowInColumns(wsSource, 1, WORK_TX_COL_PERSON_ID)
    If lastR >= 2 Then
        sourceData = wsSource.Range(wsSource.Cells(2, 1), _
                                    wsSource.Cells(lastR, WORK_TX_COL_PERSON_ID)).Value2
        sourceRowCount = UBound(sourceData, 1)
        ReDim withdrawalRows(1 To sourceRowCount)
        ReDim depositRows(1 To sourceRowCount)
        ReDim componentWithdrawalRows(1 To sourceRowCount)
        ReDim componentDepositRows(1 To sourceRowCount)
        ReDim unknownWithdrawalRows(1 To sourceRowCount)
        ReDim unknownDepositRows(1 To sourceRowCount)
        ValidateAndIndexAnalysisTransactions sourceData, minAmount, withdrawalRows, withdrawalCount, _
                                             depositRows, depositCount, componentWithdrawalRows, _
                                             componentWithdrawalCount, componentDepositRows, _
                                             componentDepositCount
        FilterAnalysisRowsByMinimum sourceData, componentWithdrawalRows, _
                                    componentWithdrawalCount, False, unknownMinAmount, _
                                    unknownWithdrawalRows, unknownWithdrawalCount
        FilterAnalysisRowsByMinimum sourceData, componentDepositRows, _
                                    componentDepositCount, True, unknownMinAmount, _
                                    unknownDepositRows, unknownDepositCount
        Set unknownContextByTx = BuildUnknownContextIndex(sourceData, componentWithdrawalRows, _
                                                           componentWithdrawalCount, componentDepositRows, _
                                                           componentDepositCount)
    End If

    If depositCount > 0 Then
        ReDim depositAmounts(1 To depositCount)
        ReDim depositSortRows(1 To depositCount)
        For r = 1 To depositCount
            depositSortRows(r) = depositRows(r)
            depositAmounts(r) = CDbl(sourceData(depositRows(r), OUT_COL_DEPOSIT))
        Next r
        If depositCount > 1 Then QuickSortAnalysisAmounts depositAmounts, depositSortRows, 1, depositCount
    End If

    If withdrawalCount > 0 And depositCount > 0 Then
        AppProgress "1対1の資金シフト候補を事前確認しています..."
        ProcessShiftCandidates sourceData, withdrawalRows, withdrawalCount, depositAmounts, _
                               depositSortRows, depositCount, dayWindow, absoluteTolerance, rateTolerance, _
                               settingsSignature, False, Nothing, Nothing, candidateCountByTx, _
                               bestScoreByTx, bestRatingByTx, shiftCount
    End If
    If shiftCount > MAX_ANALYSIS_OUTPUT_ROWS Then _
        Err.Raise vbObjectError + 4601, "BuildTransactionAnalysisSheetsCore", _
                  "資金シフト候補が実用上限（" & Format$(MAX_ANALYSIS_OUTPUT_ROWS, "#,##0") & _
                  "件）を超えます。最低金額を上げるか、金額差許容を狭めてください。"

    '不明入出金の確定件数は、確認済み候補を除外できる後段で数える。

    '分割・合算・多段連鎖は、全候補と上限を確定してから資金フロー追跡表を置き換える。
    'ここで候補統計も加算し、後続の不明入出金表へ1対1以外の関連を反映する。
    plannedUnknownRows = AnalysisUnknownCapacityUpperBound( _
                             unknownWithdrawalCount, unknownDepositCount)
    BuildAdvancedFlowAnalysisSheetCore sourceData, sourceRowCount, withdrawalRows, withdrawalCount, _
                                       depositRows, depositCount, componentWithdrawalRows, _
                                       componentWithdrawalCount, componentDepositRows, _
                                       componentDepositCount, minAmount, dayWindow, absoluteTolerance, _
                                       rateTolerance, settingsSignature, wsFlow, flowReviews, _
                                       candidateCountByTx, bestScoreByTx, bestRatingByTx, flowCount, _
                                       shiftCount, plannedUnknownRows, -1, _
                                       confirmedAnalysisWorkloadRows, False, _
                                       operationSnapshotCellWork
    AppendManualFlowAnalysisRecords sourceData, sourceRowCount, wsFlow, flowReviews, _
                                    candidateCountByTx, bestScoreByTx, bestRatingByTx, flowCount, True
    If flowCount > MAX_ANALYSIS_OUTPUT_ROWS Then _
        Err.Raise vbObjectError + 4605, "BuildTransactionAnalysisSheetsCore", _
                  "自動候補と手動候補を合わせた資金フロー追跡が実用上限（" & _
                  Format$(MAX_ANALYSIS_OUTPUT_ROWS, "#,##0") & "件）を超えます。"

    '元データ検証・件数上限確認・確認記録の退避が終わってから既存結果を置き換える。
    PrepareShiftAnalysisSheet wsShift
    PrepareUnknownAnalysisSheet wsUnknown

    If shiftCount > 0 Then
        AppProgress "1対1の資金シフト候補を書き出しています..."
        ProcessShiftCandidates sourceData, withdrawalRows, withdrawalCount, depositAmounts, _
                               depositSortRows, depositCount, dayWindow, absoluteTolerance, rateTolerance, _
                               settingsSignature, True, wsShift, shiftReviews, candidateCountByTx, _
                               bestScoreByTx, bestRatingByTx, writtenShiftCount
    End If
    If writtenShiftCount <> shiftCount Then _
        Err.Raise vbObjectError + 4603, "BuildTransactionAnalysisSheetsCore", _
                  "資金シフト候補の事前件数と出力件数が一致しません。"

    '同じ取引への複数候補は取引ID件数だけでは拒否せず、共通配賦元帳で金額合計を検証する。
    ResolveAnalysisReviewConflicts wsShift, wsFlow
    CommitCurrentAnalysisAllocations sourceData, sourceRowCount, wsShift, wsFlow
    '曖昧な複数束はCommit内で要追加調査へ戻るため、その後の状態から確定件数を作る。
    Set confirmedCountByTx = BuildConfirmedCandidateCountByTransaction(wsShift, wsFlow)
    Set allocationIndex = CaptureAllocationLedgerIndex()

    unknownCount = CountUnresolvedUnknownAnalysisRows( _
                       sourceData, unknownWithdrawalRows, unknownWithdrawalCount, _
                       unknownDepositRows, unknownDepositCount, allocationIndex)
    If unknownCount > MAX_ANALYSIS_OUTPUT_ROWS Then _
        Err.Raise vbObjectError + 4602, "BuildTransactionAnalysisSheetsCore", _
                  "未確認の不明入出金が実用上限（" & Format$(MAX_ANALYSIS_OUTPUT_ROWS, "#,##0") & _
                  "件）を超えます。不明入出金の最低金額を上げてください。"

    If unknownCount > 0 Then
        WriteUnknownAnalysis sourceData, unknownWithdrawalRows, unknownWithdrawalCount, _
                             unknownDepositRows, unknownDepositCount, _
                             unknownReviews, candidateCountByTx, confirmedCountByTx, allocationIndex, _
                             bestRatingByTx, _
                             unknownContextByTx, unknownSettingsSignature, wsUnknown, writtenUnknownCount
    End If
    If writtenUnknownCount <> unknownCount Then _
        Err.Raise vbObjectError + 4604, "BuildTransactionAnalysisSheetsCore", _
                  "不明入出金の事前件数と出力件数が一致しません。"

    FinalizeShiftAnalysisSheet wsShift, shiftCount
    FinalizeUnknownAnalysisSheet wsUnknown, unknownCount
    BuildAnalysisWorkspaceCore "取引分析の再構築", _
                               confirmedAnalysisWorkloadRows, False, _
                               operationSnapshotCellWork
    If Not ConfirmAnalysisReviewOperationCapacity( _
               "再分析結果の判断台帳保存", confirmedAnalysisWorkloadRows, _
               allowUserConfirmation:=False, _
               additionalSnapshotCellWork:=operationSnapshotCellWork) Then _
        Err.Raise 18, "BuildTransactionAnalysisSheetsCore", _
                  "利用者が分析判断台帳の容量確認を取り消しました。"
    PersistAnalysisReviewsFromCurrentSheets True, vbNullString
    SetSheetVeryHiddenSafe wsShift
    SetSheetVeryHiddenSafe wsFlow
    SetSheetVeryHiddenSafe wsUnknown
    SetSheetVeryHiddenSafe GetSheet(SH_ANALYSIS_RESULT)
    If activateAfter Then BuildCashAnalysisViewCore True, False, capacityConfirmed
    ResetAnalysisEvidenceCache
    mAnalysisInheritanceDate = Empty
    Exit Sub
EH:
    errorNumber = Err.Number
    errorSource = Err.Source
    errorDescription = Err.Description
    If IsTransactionAnalysisRecoveryFatal(errorNumber, errorSource) Then
        Call TryStopTransactionAnalysisEventsForBookWrites(convergenceDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    rollbackOK = True
    safeToRestoreEntry = Not atomicMutationStarted
    If atomicMutationStarted And atomicSnapshotsCaptured Then
        If entryEventsCaptured Then
            eventsReadyForRollback = _
                TrySetTransactionAnalysisEnableEventsExact(False, eventStateDetail)
        End If
        If Not eventsReadyForRollback Then
            rollbackOK = False
            If entryEventsCaptured Then
                AppendTransactionRollbackDetail rollbackDetail, _
                    "Excelイベントを停止して読戻し確認できません: " & eventStateDetail
            Else
                AppendTransactionRollbackDetail rollbackDetail, _
                    "Excelイベントの開始状態が未取得です。"
            End If
            AppendTransactionRollbackDetail rollbackDetail, _
                "イベント停止未確認のため、退避値をブックへ再書込みしません。"
        Else
            On Error Resume Next
            Err.Clear
            rollbackOK = RestoreTransactionAnalysisAtomicSnapshot( _
                             atomicSheets, detailReviewsDirty, cashSnapshot, rollbackDetail)
            rollbackErrorNumber = Err.Number
            rollbackErrorSource = Err.Source
            rollbackErrorDescription = Err.Description
            Err.Clear
            On Error GoTo 0
            If IsTransactionAnalysisRecoveryFatal( _
                   rollbackErrorNumber, rollbackErrorSource) Then
                Call TryStopTransactionAnalysisEventsForBookWrites( _
                    convergenceDetail)
                Err.Raise rollbackErrorNumber, rollbackErrorSource, _
                          rollbackErrorDescription
            End If
            On Error Resume Next
            If allocationSnapshotCaptured Then
                RestoreAllocationLedgerTransactionSnapshot allocationSnapshot, _
                    allocationSnapshotLastRow, allocationSnapshotDigest
                If Err.Number <> 0 Then
                    rollbackOK = False
                    AppendTransactionRollbackDetail rollbackDetail, _
                        "配賦元帳の復元エラー: " & Err.Description
                End If
                Err.Clear
            End If
            latchReadSucceeded = TryGetRollbackRecoveryLatch(recoveryLatchSet)
            If Not latchReadSucceeded Or recoveryLatchSet Then
                rollbackOK = False
                If Not latchReadSucceeded Then
                    AppendTransactionRollbackDetail rollbackDetail, _
                        "要復旧ラッチの読戻しに失敗しました。"
                Else
                    AppendTransactionRollbackDetail rollbackDetail, _
                        "内側処理が要復旧ラッチを設定したため、安全上ロールバック成功にはできません。"
                End If
            End If
            Err.Clear
            If workbookSavedCaptured And workbookWasSaved And rollbackOK Then
                ThisWorkbook.Saved = True
                If Err.Number <> 0 Then
                    rollbackOK = False
                    AppendTransactionRollbackDetail rollbackDetail, _
                        "ブック保存状態の復元エラー: " & Err.Description
                End If
            End If
            Err.Clear
            On Error GoTo 0
        End If
        If Not rollbackOK Then
            On Error Resume Next
            Err.Clear
            EnforceRollbackRecoveryState rollbackDetail
            recoveryErrorNumber = Err.Number
            recoveryErrorDescription = Err.Description
            Err.Clear
            On Error GoTo 0
            'Enforceの例外値を保存した直後にFalseを再確定する。
            eventsReadyForRollback = _
                TryStopTransactionAnalysisEventsForBookWrites( _
                    postEnforceEventDetail)
            If recoveryErrorNumber <> 0 Then
                recoveryEnforcementFailed = True
                AppendTransactionRollbackDetail rollbackDetail, _
                    "要復旧状態の強制設定エラー: Err " & _
                    CStr(recoveryErrorNumber) & " " & _
                    recoveryErrorDescription
                Err.Raise vbObjectError + 5195, _
                    "TransactionAnalysisRecoveryFatal/BuildTransactionAnalysisSheetsCore", _
                    errorDescription & " / " & rollbackDetail
            End If
            If Not eventsReadyForRollback Then _
                Err.Raise vbObjectError + 5195, _
                    "TransactionAnalysisRecoveryFatal/BuildTransactionAnalysisSheetsCore", _
                    errorDescription & " / Recovery処理後のExcelイベント" & _
                    "False収束を確認できません: " & postEnforceEventDetail
            recoveryConfirmed = _
                TransactionAnalysisRecoveryStateIsConfirmedExact( _
                    rollbackDetail)
            If Not recoveryConfirmed Then _
                Err.Raise vbObjectError + 5195, _
                    "TransactionAnalysisRecoveryFatal/BuildTransactionAnalysisSheetsCore", _
                    errorDescription & " / 今回のRecovery二重状態を" & _
                    "厳密確認できません: " & rollbackDetail
            applicationStateConfirmed = _
                TransactionAnalysisApplicationStateAllowsEntryRestore( _
                    True, rollbackDetail)
            If Not applicationStateConfirmed Then
                eventsReadyForRollback = _
                    TryStopTransactionAnalysisEventsForBookWrites( _
                        finalRecoveryEventDetail)
                Err.Raise vbObjectError + 5195, _
                    "TransactionAnalysisRecoveryFatal/BuildTransactionAnalysisSheetsCore", _
                    errorDescription & " / Application状態を安全に" & _
                    "確認できません: " & rollbackDetail
            End If
            eventsReadyForRollback = _
                TryStopTransactionAnalysisEventsForBookWrites( _
                    finalRecoveryEventDetail)
            If Not eventsReadyForRollback Then _
                Err.Raise vbObjectError + 5195, _
                    "TransactionAnalysisRecoveryFatal/BuildTransactionAnalysisSheetsCore", _
                    errorDescription & " / Recovery確認後のExcelイベント" & _
                    "False収束を確認できません: " & finalRecoveryEventDetail
            Err.Raise vbObjectError + 5195, _
                "TransactionAnalysisRecoveryFatal/BuildTransactionAnalysisSheetsCore", _
                errorDescription & " / 分析出力を完全に復元できず、" & _
                "今回のRecovery状態へ停止しました: " & rollbackDetail
        End If
        safeToRestoreEntry = eventsReadyForRollback And _
                             Not recoveryEnforcementFailed And _
                             (rollbackOK Or recoveryConfirmed)
    End If

    If entryEventsCaptured Then
        If safeToRestoreEntry Then
            eventsReadyForRollback = _
                TryStopTransactionAnalysisEventsForBookWrites(eventStateDetail)
            safeToRestoreEntry = eventsReadyForRollback
        End If
        If safeToRestoreEntry Then
            safeToRestoreEntry = _
                TransactionAnalysisApplicationStateAllowsEntryRestore( _
                    entryEvents, rollbackDetail)
        End If
        If safeToRestoreEntry Then
            If Not TryRestoreTransactionAnalysisEnableEvents( _
                       entryEvents, "取引分析再構築のエラー終了", _
                       eventStateDetail) Then
                rollbackOK = False
                AppendTransactionRollbackDetail rollbackDetail, _
                    "Excelイベント状態を復元できません: " & _
                    eventStateDetail
            End If
        ElseIf TryStopTransactionAnalysisEventsForBookWrites( _
                       convergenceDetail) Then
            rollbackOK = False
            AppendTransactionRollbackDetail rollbackDetail, _
                "ロールバックまたはRecoveryを厳密確認できないため、" & _
                "開始時イベント値へ戻さずFalseで停止しました。"
        Else
            rollbackOK = False
            AppendTransactionRollbackDetail rollbackDetail, _
                "安全状態を厳密確認できず、ExcelイベントのFalse収束にも" & _
                "失敗しました。現在状態は不明です: " & convergenceDetail
        End If
    End If

    On Error Resume Next
    ResetAnalysisEvidenceCache
    mAnalysisInheritanceDate = entryInheritanceDate
    On Error GoTo 0
    If Len(rollbackDetail) > 0 Then _
        errorDescription = errorDescription & " / 復元確認: " & rollbackDetail
    If Len(errorSource) = 0 Then _
        errorSource = "BuildTransactionAnalysisSheetsCore"
    Err.Raise errorNumber, errorSource, errorDescription
End Sub

Private Sub InitializeTransactionAnalysisAtomicSheets( _
        ByRef snapshots() As TransactionAnalysisSheetSnapshot)
    ReDim snapshots(1 To TRANSACTION_ATOMIC_SHEET_COUNT)
    ConfigureTransactionAnalysisAtomicSheet snapshots(1), SH_ANALYSIS_SHIFT, _
        "資金シフト候補", SHIFT_ANALYSIS_LAST_COL, MAX_ANALYSIS_OUTPUT_ROWS
    ConfigureTransactionAnalysisAtomicSheet snapshots(2), SH_ANALYSIS_FLOW, _
        "資金フロー追跡", FLOW_ANALYSIS_LAST_COL, MAX_ANALYSIS_OUTPUT_ROWS
    ConfigureTransactionAnalysisAtomicSheet snapshots(3), SH_ANALYSIS_UNKNOWN, _
        "不明入出金", UNKNOWN_ANALYSIS_LAST_COL, MAX_ANALYSIS_OUTPUT_ROWS
    ConfigureTransactionAnalysisAtomicSheet snapshots(4), SH_ANALYSIS_RESULT, _
        "分析結果", ANALYSIS_RESULT_LAST_COL, MAX_ANALYSIS_OUTPUT_ROWS
    ConfigureTransactionAnalysisAtomicSheet snapshots(5), SH_WORK_ANALYSIS_GROUP, _
        "分析グループ", ANALYSIS_GROUP_LAST_COL, MAX_ANALYSIS_OUTPUT_ROWS * 2
    ConfigureTransactionAnalysisAtomicSheet snapshots(6), SH_ANALYSIS_DETAIL, _
        "候補詳細", TRANSACTION_ATOMIC_DETAIL_LAST_COL, MAX_ANALYSIS_OUTPUT_ROWS
    ConfigureTransactionAnalysisAtomicSheet snapshots(7), SH_WORK_ANALYSIS_REVIEW, _
        "分析判断台帳", ANALYSIS_REVIEW_STORE_LAST_COL, MAX_INTERNAL_STORE_DATA_ROWS
    ConfigureTransactionAnalysisAtomicSheet snapshots(8), SH_WORK_ANALYSIS_HISTORY, _
        "分析判断履歴", ANALYSIS_HISTORY_STORE_LAST_COL, MAX_INTERNAL_STORE_DATA_ROWS
    ConfigureTransactionAnalysisAtomicSheet snapshots(9), SH_WORK_MANUAL_FLOW, _
        "手動資金候補", MANUAL_FLOW_STORE_LAST_COL, MAX_INTERNAL_STORE_DATA_ROWS
    ConfigureTransactionAnalysisAtomicSheet snapshots(10), SH_WORK_STATE, _
        "内部状態", 2, MAX_INTERNAL_STORE_DATA_ROWS
    ConfigureTransactionAnalysisAtomicSheet snapshots(11), SH_CHECK, _
        "確認事項", 4, MAX_INTERNAL_STORE_DATA_ROWS
End Sub

Private Sub ConfigureTransactionAnalysisAtomicSheet( _
        ByRef snapshot As TransactionAnalysisSheetSnapshot, _
        ByVal sheetName As String, ByVal labelText As String, _
        ByVal lastColumn As Long, ByVal maximumDataRows As Long)
    snapshot.SheetName = sheetName
    snapshot.LabelText = labelText
    snapshot.LastColumn = lastColumn
    snapshot.MaximumDataRows = maximumDataRows
End Sub

Private Function TransactionAnalysisAtomicSnapshotCellWork( _
        ByRef snapshots() As TransactionAnalysisSheetSnapshot, _
        ByVal includeCashView As Boolean) As Double
    Dim i As Long, lastR As Long, cashLastRow As Long
    Dim dataRows() As Long, cashDataRows As Long
    Dim ws As Worksheet
    ReDim dataRows(LBound(snapshots) To UBound(snapshots))
    For i = LBound(snapshots) To UBound(snapshots)
        Set ws = GetSheet(snapshots(i).SheetName)
        lastR = LastDataRowInColumns(ws, 1, snapshots(i).LastColumn)
        If lastR < 1 Then lastR = 1
        dataRows(i) = lastR - 1
    Next i
    If includeCashView Then
        Set ws = GetSheet(SH_OUTPUT_TX)
        cashLastRow = LastDataRowInColumns(ws, 1, CASH_VIEW_INTERNAL_LAST_COL)
        If cashLastRow < CASH_VIEW_HEADER_ROW Then cashLastRow = CASH_VIEW_HEADER_ROW
        cashDataRows = cashLastRow - CASH_VIEW_HEADER_ROW
    End If
    TransactionAnalysisAtomicSnapshotCellWork = _
        TransactionAnalysisAtomicSnapshotCellWorkFromCounts( _
            snapshots, dataRows, cashDataRows, includeCashView)
End Function

Private Function TransactionAnalysisAtomicSnapshotCellWorkFromCounts( _
        ByRef snapshots() As TransactionAnalysisSheetSnapshot, _
        ByRef dataRows() As Long, ByVal cashDataRows As Long, _
        ByVal includeCashView As Boolean) As Double
    Dim i As Long
    Dim cellWork As Double
    If LBound(dataRows) <> LBound(snapshots) Or _
       UBound(dataRows) <> UBound(snapshots) Then _
        Err.Raise vbObjectError + 4653, _
                  "TransactionAnalysisAtomicSnapshotCellWorkFromCounts", _
                  "分析更新ロールバック容量の行数配列が不正です。"
    For i = LBound(snapshots) To UBound(snapshots)
        If dataRows(i) < 0 Or dataRows(i) > snapshots(i).MaximumDataRows Then _
            Err.Raise vbObjectError + 4653, _
                      "TransactionAnalysisAtomicSnapshotCellWorkFromCounts", _
                      snapshots(i).LabelText & "が退避上限（" & _
                      Format$(snapshots(i).MaximumDataRows, "#,##0") & _
                      "行）を超えています。"
        cellWork = cellWork + _
                   CDbl(dataRows(i) + 1) * CDbl(snapshots(i).LastColumn) * _
                   CDbl(TRANSACTION_ATOMIC_SNAPSHOT_COPIES)
    Next i
    If includeCashView Then
        If cashDataRows < 0 Or cashDataRows > MAX_ANALYSIS_OUTPUT_ROWS Then _
            Err.Raise vbObjectError + 4654, _
                      "TransactionAnalysisAtomicSnapshotCellWorkFromCounts", _
                      "資金操作表が退避上限（" & _
                      Format$(MAX_ANALYSIS_OUTPUT_ROWS, "#,##0") & "行）を超えています。"
        cellWork = cellWork + _
                   CDbl(cashDataRows + 1) * _
                   CDbl(CASH_VIEW_INTERNAL_LAST_COL) * _
                   CDbl(TRANSACTION_ATOMIC_SNAPSHOT_COPIES)
        cellWork = cellWork + _
                   CDbl(TRANSACTION_ATOMIC_CASH_STATE_ROWS) * _
                   CDbl(CASH_VIEW_INTERNAL_LAST_COL) * _
                   CDbl(TRANSACTION_ATOMIC_SNAPSHOT_COPIES)
    End If
    cellWork = cellWork + _
               CDbl(AllocationLedgerStoredRowCount() + 1) * 10# * _
               CDbl(TRANSACTION_ATOMIC_SNAPSHOT_COPIES)
    TransactionAnalysisAtomicSnapshotCellWorkFromCounts = cellWork
End Function

Private Function TransactionAnalysisOperationPeakSnapshotCellWork( _
        ByVal atomicSnapshotCellWork As Double) As Double
    Dim peakCellWork As Double
    If atomicSnapshotCellWork < 0# Then _
        Err.Raise vbObjectError + 4685, _
                  "TransactionAnalysisOperationPeakSnapshotCellWork", _
                  "分析操作トランザクションの退避容量が不正です。"
    peakCellWork = atomicSnapshotCellWork * _
                   CDbl(TRANSACTION_OPERATION_PEAK_SNAPSHOT_SETS)
    If peakCellWork < atomicSnapshotCellWork Or _
       peakCellWork > 2147483647# * 16# Then _
        Err.Raise vbObjectError + 4685, _
                  "TransactionAnalysisOperationPeakSnapshotCellWork", _
                  "分析操作トランザクションの同時退避容量が安全範囲を超えています。"
    TransactionAnalysisOperationPeakSnapshotCellWork = peakCellWork
End Function

Private Sub CaptureTransactionAnalysisAtomicSnapshot( _
        ByRef snapshots() As TransactionAnalysisSheetSnapshot, _
        ByVal includeCashView As Boolean, _
        ByRef cashSnapshot As TransactionCashViewSnapshot)
    Dim i As Long
    Dim ws As Worksheet
    For i = LBound(snapshots) To UBound(snapshots)
        Set ws = GetSheet(snapshots(i).SheetName)
        snapshots(i).Visibility = CLng(ws.Visible)
        snapshots(i).WasProtected = ws.ProtectContents
        CaptureTransactionAtomicHeader ws, snapshots(i).LastColumn, _
            snapshots(i).HeaderData, snapshots(i).LabelText
        CaptureAtomicConstantWorksheetData ws, snapshots(i).LastColumn, _
            snapshots(i).MaximumDataRows, snapshots(i).Data, _
            snapshots(i).LastRow, snapshots(i).LabelText
    Next i
    If includeCashView Then CaptureTransactionCashViewSnapshot cashSnapshot
End Sub

Private Sub CaptureTransactionAtomicHeader( _
        ByVal ws As Worksheet, ByVal lastColumn As Long, _
        ByRef headerSnapshot As Variant, ByVal labelText As String)
    Dim headerRange As Range, formulaCell As Range
    Set headerRange = ws.Range(ws.Cells(1, 1), ws.Cells(1, lastColumn))
    If Not TryFindFirstFormulaCell(headerRange, formulaCell) Then _
        Err.Raise vbObjectError + 4655, "CaptureTransactionAtomicHeader", _
                  labelText & "の見出し数式検査に失敗しました。"
    If Not formulaCell Is Nothing Then _
        Err.Raise vbObjectError + 4655, "CaptureTransactionAtomicHeader", _
                  labelText & "の見出しに数式があります。"
    headerSnapshot = headerRange.Value2
    If VariantMatrixContainsError(headerSnapshot, 1, lastColumn) Or _
       Not RangeValue2MatchesMatrixStrict( _
               headerRange, headerSnapshot, 1, lastColumn) Then _
        Err.Raise vbObjectError + 4656, "CaptureTransactionAtomicHeader", _
                  labelText & "の見出しを型まで厳密に退避できません。"
End Sub

Private Sub RestoreTransactionAtomicHeader( _
        ByVal ws As Worksheet, ByVal lastColumn As Long, _
        ByRef headerSnapshot As Variant, ByVal labelText As String)
    Dim headerRange As Range
    Set headerRange = ws.Range(ws.Cells(1, 1), ws.Cells(1, lastColumn))
    headerRange.Value2 = headerSnapshot
    If Not RangeValue2MatchesMatrixStrict( _
               headerRange, headerSnapshot, 1, lastColumn) Then _
        Err.Raise vbObjectError + 4657, "RestoreTransactionAtomicHeader", _
                  labelText & "の見出しを型まで厳密に復元できません。"
End Sub

Private Sub CaptureTransactionCashViewSnapshot( _
        ByRef snapshot As TransactionCashViewSnapshot)
    Dim ws As Worksheet, wsWorkCash As Worksheet
    Dim panelRange As Range, dataRange As Range, formulaCell As Range
    Dim dataRows As Long
    Set ws = GetSheet(SH_OUTPUT_TX)
    Set wsWorkCash = GetSheet(SH_WORK_CASH)
    snapshot.Visibility = CLng(ws.Visible)
    snapshot.WasProtected = ws.ProtectContents
    snapshot.WorkCashVisibility = CLng(wsWorkCash.Visible)
    snapshot.WorkCashWasProtected = wsWorkCash.ProtectContents

    Set panelRange = ws.Range(ws.Cells(1, 1), _
                              ws.Cells(TRANSACTION_ATOMIC_CASH_STATE_ROWS, _
                                       CASH_VIEW_INTERNAL_LAST_COL))
    If Not TryFindFirstFormulaCell(panelRange, formulaCell) Then _
        Err.Raise vbObjectError + 4658, "CaptureTransactionCashViewSnapshot", _
                  "資金操作表のパネル数式検査に失敗しました。"
    If Not formulaCell Is Nothing Then _
        Err.Raise vbObjectError + 4658, "CaptureTransactionCashViewSnapshot", _
                  "資金操作表のパネルまたは画面状態に数式があります。"
    snapshot.PanelData = panelRange.Value2
    If VariantMatrixContainsError( _
            snapshot.PanelData, TRANSACTION_ATOMIC_CASH_STATE_ROWS, _
            CASH_VIEW_INTERNAL_LAST_COL) Or _
       Not RangeValue2MatchesMatrixStrict( _
               panelRange, snapshot.PanelData, _
               TRANSACTION_ATOMIC_CASH_STATE_ROWS, _
               CASH_VIEW_INTERNAL_LAST_COL) Then _
        Err.Raise vbObjectError + 4659, "CaptureTransactionCashViewSnapshot", _
                  "資金操作表のパネルと画面状態を厳密に退避できません。"

    snapshot.DataLastRow = _
        LastDataRowInColumns(ws, 1, CASH_VIEW_INTERNAL_LAST_COL)
    If snapshot.DataLastRow < CASH_VIEW_HEADER_ROW Then _
        snapshot.DataLastRow = CASH_VIEW_HEADER_ROW
    dataRows = snapshot.DataLastRow - CASH_VIEW_HEADER_ROW + 1
    If dataRows - 1 > MAX_ANALYSIS_OUTPUT_ROWS Then _
        Err.Raise vbObjectError + 4660, "CaptureTransactionCashViewSnapshot", _
                  "資金操作表が退避上限を超えています。"
    Set dataRange = ws.Range(ws.Cells(CASH_VIEW_HEADER_ROW, 1), _
                             ws.Cells(snapshot.DataLastRow, _
                                      CASH_VIEW_INTERNAL_LAST_COL))
    If Not TryFindFirstFormulaCell(dataRange, formulaCell) Then _
        Err.Raise vbObjectError + 4661, "CaptureTransactionCashViewSnapshot", _
                  "資金操作表の一覧数式検査に失敗しました。"
    If Not formulaCell Is Nothing Then _
        Err.Raise vbObjectError + 4661, "CaptureTransactionCashViewSnapshot", _
                  "資金操作表の一覧に数式があります。"
    snapshot.Data = dataRange.Value2
    If VariantMatrixContainsError( _
            snapshot.Data, dataRows, CASH_VIEW_INTERNAL_LAST_COL) Or _
       Not RangeValue2MatchesMatrixStrict( _
               dataRange, snapshot.Data, dataRows, _
               CASH_VIEW_INTERNAL_LAST_COL) Then _
        Err.Raise vbObjectError + 4662, "CaptureTransactionCashViewSnapshot", _
                  "資金操作表の一覧を厳密に退避できません。"

    If Not ActiveSheet Is Nothing Then
        If TypeName(ActiveSheet) = "Worksheet" Then
            snapshot.EntryActiveSheetName = ActiveSheet.Name
            If Not ActiveCell Is Nothing Then _
                snapshot.EntryActiveCellAddress = ActiveCell.Address(False, False)
        End If
    End If
    snapshot.WasActive = (snapshot.EntryActiveSheetName = SH_OUTPUT_TX)
    If snapshot.WasActive Then
        If TypeName(Selection) = "Range" Then _
            snapshot.SelectionAddress = Selection.Address(False, False)
        snapshot.ActiveCellAddress = ActiveCell.Address(False, False)
        If Not ActiveWindow Is Nothing Then
            snapshot.FreezePanes = ActiveWindow.FreezePanes
            snapshot.SplitRow = CLng(ActiveWindow.SplitRow)
            snapshot.SplitColumn = CLng(ActiveWindow.SplitColumn)
            snapshot.ScrollRow = ActiveWindow.ScrollRow
            snapshot.ScrollColumn = ActiveWindow.ScrollColumn
            snapshot.Zoom = CLng(ActiveWindow.Zoom)
            snapshot.WindowStateCaptured = True
        End If
    End If
    snapshot.Captured = True
End Sub

Private Function RestoreTransactionAnalysisAtomicSnapshot( _
        ByRef snapshots() As TransactionAnalysisSheetSnapshot, _
        ByVal detailReviewsDirty As Boolean, _
        ByRef cashSnapshot As TransactionCashViewSnapshot, _
        ByRef detailText As String) As Boolean
    Dim i As Long
    Dim restoreOK As Boolean
    Dim fatalErrorNumber As Long
    Dim fatalErrorSource As String, fatalErrorDescription As String
    Dim fatalStopDetail As String
    restoreOK = True
    On Error Resume Next

    For i = 1 To 3
        Err.Clear
        RestoreTransactionAnalysisSourceSnapshot snapshots(i)
        If IsTransactionAnalysisRecoveryFatal(Err.Number, Err.Source) Then _
            GoTo RecoveryFatal
        If Err.Number <> 0 Then
            restoreOK = False
            AppendTransactionRollbackDetail detailText, _
                snapshots(i).LabelText & "の復元エラー: " & Err.Description
        End If
    Next i

    Err.Clear
    RestoreAnalysisWorkspaceTransactionSnapshot _
        snapshots(4).Data, snapshots(4).LastRow, _
        snapshots(4).Visibility, snapshots(4).WasProtected, _
        snapshots(5).Data, snapshots(5).LastRow, _
        snapshots(5).Visibility, snapshots(5).WasProtected, _
        snapshots(6).HeaderData, snapshots(6).Data, snapshots(6).LastRow, _
        snapshots(6).Visibility, snapshots(6).WasProtected, detailReviewsDirty
    If IsTransactionAnalysisRecoveryFatal(Err.Number, Err.Source) Then _
        GoTo RecoveryFatal
    If Err.Number = 0 Then _
        RestoreTransactionWorkspaceHeaders snapshots(4), snapshots(5)
    If IsTransactionAnalysisRecoveryFatal(Err.Number, Err.Source) Then _
        GoTo RecoveryFatal
    If Err.Number <> 0 Then
        restoreOK = False
        AppendTransactionRollbackDetail detailText, _
            "分析workspaceの復元エラー: " & Err.Description
    End If

    For i = 7 To 9
        Err.Clear
        RestoreTransactionConstantStoreSnapshot snapshots(i)
        If IsTransactionAnalysisRecoveryFatal(Err.Number, Err.Source) Then _
            GoTo RecoveryFatal
        If Err.Number <> 0 Then
            restoreOK = False
            AppendTransactionRollbackDetail detailText, _
                snapshots(i).LabelText & "の復元エラー: " & Err.Description
        End If
    Next i

    If cashSnapshot.Captured Then
        Err.Clear
        RestoreTransactionCashViewContent cashSnapshot
        If IsTransactionAnalysisRecoveryFatal(Err.Number, Err.Source) Then _
            GoTo RecoveryFatal
        If Err.Number <> 0 Then
            restoreOK = False
            AppendTransactionRollbackDetail detailText, _
                "資金操作表の復元エラー: " & Err.Description
        End If
    End If

    Err.Clear
    RestoreTransactionConstantStoreSnapshot snapshots(11)
    If IsTransactionAnalysisRecoveryFatal(Err.Number, Err.Source) Then _
        GoTo RecoveryFatal
    If Err.Number <> 0 Then
        restoreOK = False
        AppendTransactionRollbackDetail detailText, _
            snapshots(11).LabelText & "の復元エラー: " & Err.Description
    End If

    'Cashの再構築とChange整形がdirtyフラグへ触れるため、W_状態は必ず最後に戻す。
    Err.Clear
    RestoreTransactionConstantStoreSnapshot snapshots(10)
    If IsTransactionAnalysisRecoveryFatal(Err.Number, Err.Source) Then _
        GoTo RecoveryFatal
    If Err.Number <> 0 Then
        restoreOK = False
        AppendTransactionRollbackDetail detailText, _
            snapshots(10).LabelText & "の復元エラー: " & Err.Description
    End If

    For i = LBound(snapshots) To UBound(snapshots)
        Err.Clear
        RestoreTransactionAnalysisSheetSurfaceState _
            GetSheet(snapshots(i).SheetName), snapshots(i).Visibility, _
            snapshots(i).WasProtected
        If IsTransactionAnalysisRecoveryFatal(Err.Number, Err.Source) Then _
            GoTo RecoveryFatal
        If Err.Number <> 0 Then
            restoreOK = False
            AppendTransactionRollbackDetail detailText, _
                snapshots(i).LabelText & "の表示・保護復元エラー: " & Err.Description
        End If
    Next i

    If cashSnapshot.Captured Then
        Err.Clear
        RestoreTransactionAnalysisSheetSurfaceState _
            GetSheet(SH_WORK_CASH), cashSnapshot.WorkCashVisibility, _
            cashSnapshot.WorkCashWasProtected
        If IsTransactionAnalysisRecoveryFatal(Err.Number, Err.Source) Then _
            GoTo RecoveryFatal
        If Err.Number <> 0 Then
            restoreOK = False
            AppendTransactionRollbackDetail detailText, _
                "予定資金表の表示・保護復元エラー: " & Err.Description
        End If
        Err.Clear
        RestoreTransactionAnalysisSheetSurfaceState _
            GetSheet(SH_OUTPUT_TX), cashSnapshot.Visibility, _
            cashSnapshot.WasProtected
        If IsTransactionAnalysisRecoveryFatal(Err.Number, Err.Source) Then _
            GoTo RecoveryFatal
        If Err.Number <> 0 Then
            restoreOK = False
            AppendTransactionRollbackDetail detailText, _
                "資金操作表の表示・保護復元エラー: " & Err.Description
        End If
        Err.Clear
        RestoreTransactionEntryViewState cashSnapshot
        If Err.Number <> 0 Then
            restoreOK = False
            AppendTransactionRollbackDetail detailText, _
                "操作開始時の選択・画面復元エラー: " & Err.Description
        End If
    End If

    'W_状態と要復旧ラッチを踏まえ、主操作ボタンを最後に決定的再同期する。
    Err.Clear
    RefreshMainActionCaption
    If Err.Number <> 0 Or Not TransactionMainActionCaptionStateMatches() Then
        restoreOK = False
        AppendTransactionRollbackDetail detailText, _
            "主操作ボタン表示を状態表と一致させられません。" & _
            IIf(Err.Number <> 0, " " & Err.Description, vbNullString)
    End If

    Err.Clear
    On Error GoTo 0
    RestoreTransactionAnalysisAtomicSnapshot = restoreOK
    Exit Function
RecoveryFatal:
    fatalErrorNumber = Err.Number
    fatalErrorSource = Err.Source
    fatalErrorDescription = Err.Description
    Err.Clear
    On Error GoTo 0
    Call TryStopTransactionAnalysisEventsForBookWrites(fatalStopDetail)
    Err.Raise fatalErrorNumber, fatalErrorSource, fatalErrorDescription
End Function

Private Sub RestoreTransactionAnalysisSourceSnapshot( _
        ByRef snapshot As TransactionAnalysisSheetSnapshot)
    Dim ws As Worksheet
    Dim dataCount As Long
    Set ws = GetSheet(snapshot.SheetName)
    Select Case snapshot.SheetName
        Case SH_ANALYSIS_SHIFT
            PrepareShiftAnalysisSheet ws
            ws.Unprotect Password:=TOOL_PASSWORD
            RestoreAtomicConstantWorksheetData ws, snapshot.LastColumn, _
                snapshot.MaximumDataRows, snapshot.Data, snapshot.LastRow, _
                snapshot.LabelText
            FinalizeShiftAnalysisSheet ws, snapshot.LastRow - 1
        Case SH_ANALYSIS_FLOW
            PrepareAdvancedFlowAnalysisSheet ws
            ws.Unprotect Password:=TOOL_PASSWORD
            RestoreAtomicConstantWorksheetData ws, snapshot.LastColumn, _
                snapshot.MaximumDataRows, snapshot.Data, snapshot.LastRow, _
                snapshot.LabelText
            FinalizeAdvancedFlowAnalysisSheet ws, snapshot.LastRow - 1
        Case SH_ANALYSIS_UNKNOWN
            PrepareUnknownAnalysisSheet ws
            ws.Unprotect Password:=TOOL_PASSWORD
            RestoreAtomicConstantWorksheetData ws, snapshot.LastColumn, _
                snapshot.MaximumDataRows, snapshot.Data, snapshot.LastRow, _
                snapshot.LabelText
            FinalizeUnknownAnalysisSheet ws, snapshot.LastRow - 1
        Case Else
            Err.Raise vbObjectError + 4663, _
                      "RestoreTransactionAnalysisSourceSnapshot", _
                      "分析元表の退避指定が不正です: " & snapshot.SheetName
    End Select

    dataCount = snapshot.LastRow - 1
    If dataCount > 0 Then
        If Not RangeValue2MatchesMatrixStrict( _
                   ws.Range(ws.Cells(2, 1), _
                            ws.Cells(snapshot.LastRow, snapshot.LastColumn)), _
                   snapshot.Data, dataCount, snapshot.LastColumn) Then
            '同順位Sortの順番が変わっても、開始時の行順を最後に厳密復元する。
            ws.Unprotect Password:=TOOL_PASSWORD
            RestoreAtomicConstantWorksheetData ws, snapshot.LastColumn, _
                snapshot.MaximumDataRows, snapshot.Data, snapshot.LastRow, _
                snapshot.LabelText
        End If
    End If
    ws.Unprotect Password:=TOOL_PASSWORD
    RestoreTransactionAtomicHeader ws, snapshot.LastColumn, _
        snapshot.HeaderData, snapshot.LabelText
    If dataCount > 0 Then
        If Not RangeValue2MatchesMatrixStrict( _
                   ws.Range(ws.Cells(2, 1), _
                            ws.Cells(snapshot.LastRow, snapshot.LastColumn)), _
                   snapshot.Data, dataCount, snapshot.LastColumn) Then _
            Err.Raise vbObjectError + 4664, _
                      "RestoreTransactionAnalysisSourceSnapshot", _
                      snapshot.LabelText & "の開始時行順を復元できません。"
    End If
End Sub

Private Sub RestoreTransactionWorkspaceHeaders( _
        ByRef resultSnapshot As TransactionAnalysisSheetSnapshot, _
        ByRef groupSnapshot As TransactionAnalysisSheetSnapshot)
    Dim ws As Worksheet
    Set ws = GetSheet(resultSnapshot.SheetName)
    ws.Unprotect Password:=TOOL_PASSWORD
    RestoreTransactionAtomicHeader ws, resultSnapshot.LastColumn, _
        resultSnapshot.HeaderData, resultSnapshot.LabelText
    Set ws = GetSheet(groupSnapshot.SheetName)
    ws.Unprotect Password:=TOOL_PASSWORD
    RestoreTransactionAtomicHeader ws, groupSnapshot.LastColumn, _
        groupSnapshot.HeaderData, groupSnapshot.LabelText
End Sub

Private Sub RestoreTransactionConstantStoreSnapshot( _
        ByRef snapshot As TransactionAnalysisSheetSnapshot)
    Dim ws As Worksheet
    Set ws = GetSheet(snapshot.SheetName)
    ws.Unprotect Password:=TOOL_PASSWORD
    RestoreAtomicConstantWorksheetData ws, snapshot.LastColumn, _
        snapshot.MaximumDataRows, snapshot.Data, snapshot.LastRow, snapshot.LabelText
    RestoreTransactionAtomicHeader ws, snapshot.LastColumn, _
        snapshot.HeaderData, snapshot.LabelText
End Sub

Private Sub RestoreTransactionCashViewContent( _
        ByRef snapshot As TransactionCashViewSnapshot)
    Dim ws As Worksheet
    Dim currentLastRow As Long, clearLastRow As Long, dataRows As Long
    Dim restoredRange As Range
    Set ws = GetSheet(SH_OUTPUT_TX)

    'BuildCashが旧候補・旧表示モードを使うよう、V1:V9だけ先に戻す。
    ws.Unprotect Password:=TOOL_PASSWORD
    RestoreTransactionCashStateCells ws, snapshot.PanelData
    BuildCashAnalysisViewCore False, False, True
    ws.Unprotect Password:=TOOL_PASSWORD

    currentLastRow = LastDataRowInColumns(ws, 1, CASH_VIEW_INTERNAL_LAST_COL)
    If currentLastRow < CASH_VIEW_HEADER_ROW Then currentLastRow = CASH_VIEW_HEADER_ROW
    clearLastRow = CLng(Application.Max(currentLastRow, snapshot.DataLastRow))
    ws.Range(ws.Cells(CASH_VIEW_HEADER_ROW, 1), _
             ws.Cells(clearLastRow, CASH_VIEW_INTERNAL_LAST_COL)).ClearContents
    dataRows = snapshot.DataLastRow - CASH_VIEW_HEADER_ROW + 1
    Set restoredRange = ws.Range(ws.Cells(CASH_VIEW_HEADER_ROW, 1), _
                                 ws.Cells(snapshot.DataLastRow, _
                                          CASH_VIEW_INTERNAL_LAST_COL))
    restoredRange.Value2 = snapshot.Data
    If Not RangeValue2MatchesMatrixStrict( _
               restoredRange, snapshot.Data, dataRows, _
               CASH_VIEW_INTERNAL_LAST_COL) Then _
        Err.Raise vbObjectError + 4665, "RestoreTransactionCashViewContent", _
                  "資金操作表の一覧を型まで厳密に復元できません。"
    If LastDataRowInColumns(ws, 1, CASH_VIEW_INTERNAL_LAST_COL) <> _
       snapshot.DataLastRow Then _
        Err.Raise vbObjectError + 4666, "RestoreTransactionCashViewContent", _
                  "資金操作表の復元行数が一致しません。"

    RestoreTransactionCashPanelValues ws, snapshot.PanelData
    FormatCashAnalysisViewLayout ws
    OnCashAnalysisViewChange Union(ws.Range("C3"), ws.Range("C8"))
    If Not RangeValue2MatchesMatrixStrict( _
               ws.Range(ws.Cells(1, 1), _
                        ws.Cells(TRANSACTION_ATOMIC_CASH_STATE_ROWS, _
                                 CASH_VIEW_INTERNAL_LAST_COL)), _
               snapshot.PanelData, TRANSACTION_ATOMIC_CASH_STATE_ROWS, _
               CASH_VIEW_INTERNAL_LAST_COL) Then _
        Err.Raise vbObjectError + 4667, "RestoreTransactionCashViewContent", _
                  "資金操作表のパネルまたは画面状態を厳密に復元できません。"
End Sub

Private Sub RestoreTransactionCashStateCells( _
        ByVal ws As Worksheet, ByRef panelSnapshot As Variant)
    Dim stateData() As Variant, r As Long
    ReDim stateData(1 To TRANSACTION_ATOMIC_CASH_STATE_ROWS, 1 To 1)
    For r = 1 To TRANSACTION_ATOMIC_CASH_STATE_ROWS
        stateData(r, 1) = panelSnapshot(r, 22)
    Next r
    ws.Range("V1:V" & CStr(TRANSACTION_ATOMIC_CASH_STATE_ROWS)).Value2 = stateData
    If Not RangeValue2MatchesMatrixStrict( _
               ws.Range("V1:V" & CStr(TRANSACTION_ATOMIC_CASH_STATE_ROWS)), _
               stateData, TRANSACTION_ATOMIC_CASH_STATE_ROWS, 1) Then _
        Err.Raise vbObjectError + 4668, "RestoreTransactionCashStateCells", _
                  "資金操作表の画面状態を再構築前に復元できません。"
End Sub

Private Sub RestoreTransactionCashPanelValues( _
        ByVal ws As Worksheet, ByRef panelSnapshot As Variant)
    Dim r As Long, c As Long
    Dim target As Range, topLeft As Range
    For r = 1 To TRANSACTION_ATOMIC_CASH_STATE_ROWS
        For c = 1 To CASH_VIEW_INTERNAL_LAST_COL
            Set target = ws.Cells(r, c)
            If target.MergeCells Then
                Set topLeft = target.MergeArea.Cells(1, 1)
                If target.Address = topLeft.Address Then _
                    topLeft.Value2 = panelSnapshot(r, c)
            Else
                target.Value2 = panelSnapshot(r, c)
            End If
        Next c
    Next r
    If Not RangeValue2MatchesMatrixStrict( _
               ws.Range(ws.Cells(1, 1), _
                        ws.Cells(TRANSACTION_ATOMIC_CASH_STATE_ROWS, _
                                 CASH_VIEW_INTERNAL_LAST_COL)), _
               panelSnapshot, TRANSACTION_ATOMIC_CASH_STATE_ROWS, _
               CASH_VIEW_INTERNAL_LAST_COL) Then _
        Err.Raise vbObjectError + 4669, "RestoreTransactionCashPanelValues", _
                  "資金操作表のパネル値を型まで厳密に復元できません。"
End Sub

Private Sub RestoreTransactionAnalysisSheetSurfaceState( _
        ByVal ws As Worksheet, ByVal visibilityState As Long, _
        ByVal protectedState As Boolean)
    If ws Is Nothing Then _
        Err.Raise vbObjectError + 4670, _
                  "RestoreTransactionAnalysisSheetSurfaceState", _
                  "表示・保護を戻すシートがありません。"
    If protectedState Then
        Select Case ws.Name
            Case SH_ANALYSIS_SHIFT, SH_ANALYSIS_FLOW, SH_ANALYSIS_UNKNOWN, _
                 SH_ANALYSIS_RESULT, SH_ANALYSIS_DETAIL
                ProtectSingleAnalysisSheet ws
            Case SH_OUTPUT_TX
                ProtectCashAnalysisViewSheet
            Case Else
                EmergencyProtectToolSheet ws
        End Select
    Else
        ws.Unprotect Password:=TOOL_PASSWORD
    End If
    ws.Visible = visibilityState
    If ws.ProtectContents <> protectedState Or _
       CLng(ws.Visible) <> visibilityState Then _
        Err.Raise vbObjectError + 4671, _
                  "RestoreTransactionAnalysisSheetSurfaceState", _
                  "表示状態または保護状態の読戻しが一致しません: " & ws.Name
End Sub

Private Sub RestoreTransactionEntryViewState( _
        ByRef snapshot As TransactionCashViewSnapshot)
    Dim ws As Worksheet
    If Len(snapshot.EntryActiveSheetName) = 0 Then Exit Sub
    If Not SheetExists(snapshot.EntryActiveSheetName) Then _
        Err.Raise vbObjectError + 4672, "RestoreTransactionEntryViewState", _
                  "操作開始時のシートが見つかりません。"
    Set ws = GetSheet(snapshot.EntryActiveSheetName)
    If ws.Visible <> xlSheetVisible Then _
        Err.Raise vbObjectError + 4673, "RestoreTransactionEntryViewState", _
                  "操作開始時のシートが表示状態へ戻っていません。"
    ws.Activate
    RestoreWorkbookViewPosition ws, snapshot.WasActive And snapshot.WindowStateCaptured, _
        snapshot.FreezePanes, snapshot.SplitRow, snapshot.SplitColumn, _
        snapshot.ScrollRow, snapshot.ScrollColumn, snapshot.Zoom, _
        IIf(snapshot.WasActive, snapshot.SelectionAddress, vbNullString), snapshot.EntryActiveCellAddress
    If Not ActiveWorkbook Is ThisWorkbook Or Not ActiveSheet Is ws Then _
        Err.Raise vbObjectError + 4677, "RestoreTransactionEntryViewState", _
                  "操作開始時のアクティブシートを復元できません。"
End Sub

Private Sub AppendTransactionRollbackDetail( _
        ByRef detailText As String, ByVal addedText As String)
    If Len(Trim$(addedText)) = 0 Then Exit Sub
    If Len(detailText) > 0 Then detailText = detailText & " / "
    detailText = detailText & addedText
    If Len(detailText) > ANALYSIS_CHECK_MAX_DETAIL_CHARS Then _
        detailText = Left$(detailText, ANALYSIS_CHECK_MAX_DETAIL_CHARS)
End Sub

Private Function TryGetTransactionAnalysisEnableEvents( _
        ByRef currentValue As Boolean, _
        ByRef detailText As String) As Boolean
    Dim errorNumber As Long, errorDescription As String
    detailText = vbNullString
    On Error GoTo EH
    currentValue = Application.EnableEvents
    TryGetTransactionAnalysisEnableEvents = True
    Exit Function
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    detailText = "Err " & CStr(errorNumber) & ": " & errorDescription
    Err.Clear
End Function

Private Function TrySetTransactionAnalysisEnableEventsExact( _
        ByVal desiredValue As Boolean, _
        ByRef detailText As String) As Boolean
    Dim errorNumber As Long, errorDescription As String
    detailText = vbNullString
    On Error GoTo EH
    Application.EnableEvents = desiredValue
    If Application.EnableEvents <> desiredValue Then _
        Err.Raise vbObjectError + 4700, _
                  "TrySetTransactionAnalysisEnableEventsExact", _
                  "EnableEventsの書込み後読戻しが一致しません。"
    TrySetTransactionAnalysisEnableEventsExact = True
    Exit Function
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    detailText = "Err " & CStr(errorNumber) & ": " & errorDescription
    Err.Clear
End Function

Private Function TryStopTransactionAnalysisEventsForBookWrites( _
        ByRef detailText As String) As Boolean
    Dim firstDetail As String, retryDetail As String
    detailText = vbNullString
    If TrySetTransactionAnalysisEnableEventsExact(False, firstDetail) Then
        TryStopTransactionAnalysisEventsForBookWrites = True
        Exit Function
    End If
    If TrySetTransactionAnalysisEnableEventsExact(False, retryDetail) Then
        TryStopTransactionAnalysisEventsForBookWrites = True
        Exit Function
    End If
    detailText = "ExcelイベントをFalseへ停止して読戻し確認できませんでした。初回=" & _
                 firstDetail & " / 再試行=" & retryDetail
End Function

Private Function TransactionAnalysisRecoveryStateIsConfirmedExact( _
        ByRef detailText As String) As Boolean
    Dim latchIsSet As Boolean, latchReadSucceeded As Boolean
    Dim healthValue As String, healthReadSucceeded As Boolean
    latchReadSucceeded = TryGetRollbackRecoveryLatch(latchIsSet)
    healthReadSucceeded = _
        TryGetExactStateValue(STATE_DATA_HEALTH, healthValue)
    TransactionAnalysisRecoveryStateIsConfirmedExact = _
        latchReadSucceeded And latchIsSet And healthReadSucceeded And _
        (StrComp(healthValue, DATA_HEALTH_NEEDS_RECOVERY, _
                 vbBinaryCompare) = 0)
    If TransactionAnalysisRecoveryStateIsConfirmedExact Then Exit Function
    If Not latchReadSucceeded Then
        AppendTransactionRollbackDetail detailText, _
            "独立復旧ラッチを一意に読み返せません。"
    ElseIf Not latchIsSet Then
        AppendTransactionRollbackDetail detailText, _
            "独立復旧ラッチが設定されていません。"
    End If
    If Not healthReadSucceeded Then
        AppendTransactionRollbackDetail detailText, _
            "案件healthを一意に読み返せません。"
    ElseIf StrComp(healthValue, DATA_HEALTH_NEEDS_RECOVERY, _
                   vbBinaryCompare) <> 0 Then
        AppendTransactionRollbackDetail detailText, _
            "案件healthが要復旧ではありません（実値=" & healthValue & "）。"
    End If
End Function

Private Function TransactionAnalysisApplicationStateAllowsEntryRestore( _
        ByVal entryEvents As Boolean, _
        ByRef detailText As String) As Boolean
    Dim appStateProblems As String
    If Not entryEvents Then
        TransactionAnalysisApplicationStateAllowsEntryRestore = True
        Exit Function
    End If
    If AppStateIsRestored(appStateProblems) Then
        TransactionAnalysisApplicationStateAllowsEntryRestore = True
    Else
        AppendTransactionRollbackDetail detailText, _
            "Application状態を安全に復元済みと確認できません: " & _
            appStateProblems
    End If
End Function

Private Function IsTransactionAnalysisRecoveryFatal( _
        ByVal errorNumber As Long, ByVal errorSource As String) As Boolean
    Dim expectedSource As String
    Select Case errorNumber
        Case vbObjectError + 3599, vbObjectError + 4499
            IsTransactionAnalysisRecoveryFatal = True
            Exit Function
        Case vbObjectError + 5191
            expectedSource = "AnalysisWorkspaceRecoveryFatal/"
        Case vbObjectError + 5192
            expectedSource = "SetupConvergeRecoveryFatal/"
        Case vbObjectError + 5194
            expectedSource = "CashAnalysisRecoveryFatal/"
        Case vbObjectError + 5195
            expectedSource = "TransactionAnalysisRecoveryFatal/"
        Case vbObjectError + 5196
            expectedSource = "CashManualSelectionRecoveryFatal/"
        Case vbObjectError + 5197
            expectedSource = "ClearRecoveryFatal/"
        Case Else
            Exit Function
    End Select
    If Len(errorSource) < Len(expectedSource) Then Exit Function
    IsTransactionAnalysisRecoveryFatal = _
        (StrComp(Left$(errorSource, Len(expectedSource)), expectedSource, _
                 vbBinaryCompare) = 0)
End Function

Private Function TryRestoreTransactionAnalysisEnableEvents( _
        ByVal previousValue As Boolean, _
        ByVal operationName As String, _
        ByRef detailText As String) As Boolean
    Dim firstDetail As String, retryDetail As String
    Dim stopDetail As String, safeStopDetail As String
    Dim eventsStoppedForRecovery As Boolean
    Dim recoveryEnforcementFailed As Boolean
    Dim recoveryConfirmedThisAttempt As Boolean
    Dim eventsStoppedAfterRecovery As Boolean
    Dim recoveryAttempted As Boolean
    detailText = vbNullString
    If TrySetTransactionAnalysisEnableEventsExact(previousValue, firstDetail) Then
        TryRestoreTransactionAnalysisEnableEvents = True
        Exit Function
    End If
    If TrySetTransactionAnalysisEnableEventsExact(previousValue, retryDetail) Then
        TryRestoreTransactionAnalysisEnableEvents = True
        Exit Function
    End If
    detailText = "Excelイベント状態を開始値へ復元できませんでした。初回=" & _
                 firstDetail & " / 再試行=" & retryDetail
    eventsStoppedForRecovery = _
        TrySetTransactionAnalysisEnableEventsExact(False, stopDetail)
    If eventsStoppedForRecovery Then
        AppendTransactionRollbackDetail detailText, _
            "要復旧記録前にExcelイベント停止を読戻し確認しました。"
        StopAfterTransactionAnalysisEventStateFailure _
            operationName, detailText, recoveryEnforcementFailed, _
            recoveryConfirmedThisAttempt, eventsStoppedAfterRecovery, _
            recoveryAttempted
    Else
        AppendTransactionRollbackDetail detailText, _
            "要復旧記録前にもExcelイベント停止を確認できず、" & _
            "ブックへのRecovery書込みを安全のため見送りました: " & _
            stopDetail
        AppendTransactionRollbackDetail detailText, _
            "Excelイベント状態と案件の安全状態は不明です。"
        On Error Resume Next
        MsgBox "Excelイベントを安全に停止できず、ブックへの復旧記録を見送りました。" & _
               vbCrLf & "Excelイベント状態と案件の安全状態は不明です。" & _
               vbCrLf & "現在のブックを上書きしないでください。", _
               vbCritical, "Excelイベント状態を確認できません"
        On Error GoTo 0
    End If
    If recoveryAttempted Then _
        Err.Raise vbObjectError + 5195, _
                  "TransactionAnalysisRecoveryFatal/TryRestoreTransactionAnalysisEnableEvents", _
                  detailText
    eventsStoppedForRecovery = _
        TryStopTransactionAnalysisEventsForBookWrites(safeStopDetail)
End Function

Private Sub StopAfterTransactionAnalysisEventStateFailure( _
        ByVal operationName As String, _
        ByRef detailText As String, _
        Optional ByRef recoveryEnforcementFailed As Boolean = False, _
        Optional ByRef recoveryConfirmedThisAttempt As Boolean = False, _
        Optional ByRef eventsStoppedAfterRecovery As Boolean = False, _
        Optional ByRef recoveryAttempted As Boolean = False)
    Dim recoveryDetail As String, stopDetail As String
    Dim recoveryErrorNumber As Long, recoveryErrorDescription As String
    Dim recoveryConfirmed As Boolean
    Dim applicationStateConfirmed As Boolean
    If recoveryAttempted Then
        eventsStoppedAfterRecovery = _
            TryStopTransactionAnalysisEventsForBookWrites(stopDetail)
        AppendTransactionRollbackDetail detailText, _
            "この上位処理ではRecovery設定を既に試行済みのため、" & _
            "二重実行を行いません。"
        Err.Raise vbObjectError + 5195, _
                  "TransactionAnalysisRecoveryFatal/StopAfterTransactionAnalysisEventStateFailure", _
                  detailText
    End If
    recoveryEnforcementFailed = False
    recoveryConfirmedThisAttempt = False
    eventsStoppedAfterRecovery = False
    recoveryDetail = operationName & ": " & detailText
    If Not TryStopTransactionAnalysisEventsForBookWrites(stopDetail) Then
        AppendTransactionRollbackDetail recoveryDetail, _
            "イベント停止未確認のため、ブックへのRecovery・診断・状態表示の書込みを見送りました: " & _
            stopDetail
        AppendTransactionRollbackDetail recoveryDetail, _
            "Excelイベント状態と案件の安全状態は不明です。"
        detailText = recoveryDetail
        Err.Raise vbObjectError + 5195, _
                  "TransactionAnalysisRecoveryFatal/StopAfterTransactionAnalysisEventStateFailure", _
                  detailText
    End If
    AppendTransactionRollbackDetail recoveryDetail, _
        "Recovery処理前にExcelイベント停止を読戻し確認しました。"
    recoveryAttempted = True
    On Error Resume Next
    Err.Clear
    EnforceRollbackRecoveryState recoveryDetail
    recoveryErrorNumber = Err.Number
    recoveryErrorDescription = Err.Description
    Err.Clear
    On Error GoTo 0
    'Enforce直後の新しいFalse exactだけを以後の安全条件に使う。
    eventsStoppedAfterRecovery = _
        TryStopTransactionAnalysisEventsForBookWrites(stopDetail)
    If recoveryErrorNumber <> 0 Then
        recoveryEnforcementFailed = True
        AppendTransactionRollbackDetail recoveryDetail, _
            "要復旧状態の強制設定エラー: Err " & _
            CStr(recoveryErrorNumber) & " " & recoveryErrorDescription
        If Not eventsStoppedAfterRecovery Then _
            AppendTransactionRollbackDetail recoveryDetail, _
                "Recovery例外後のExcelイベントFalse収束も確認できません: " & _
                stopDetail
        detailText = recoveryDetail
        Err.Raise vbObjectError + 5195, _
                  "TransactionAnalysisRecoveryFatal/StopAfterTransactionAnalysisEventStateFailure", _
                  detailText
    End If

    'Recovery処理は内部でApplication leaseを閉じ得るため、状態確認前に
    '外側のFalse exactを取り直す。確認処理後もブック書込み直前に取り直す。
    If Not eventsStoppedAfterRecovery Then
        AppendTransactionRollbackDetail recoveryDetail, _
            "Recovery処理後にExcelイベント停止を確認できないため、" & _
            "診断・状態表示の書込みを見送りました: " & stopDetail
        AppendTransactionRollbackDetail recoveryDetail, _
            "Excelイベント状態と案件の安全状態は不明です。"
        detailText = recoveryDetail
        Err.Raise vbObjectError + 5195, _
                  "TransactionAnalysisRecoveryFatal/StopAfterTransactionAnalysisEventStateFailure", _
                  detailText
    End If
    recoveryConfirmed = _
        TransactionAnalysisRecoveryStateIsConfirmedExact(recoveryDetail)
    If Not recoveryConfirmed Then
        AppendTransactionRollbackDetail recoveryDetail, _
            "今回のRecovery二重状態を厳密確認できないため、" & _
            "診断・状態表示・開始値復元を行いません。"
        eventsStoppedAfterRecovery = _
            TryStopTransactionAnalysisEventsForBookWrites(stopDetail)
        detailText = recoveryDetail
        Err.Raise vbObjectError + 5195, _
                  "TransactionAnalysisRecoveryFatal/StopAfterTransactionAnalysisEventStateFailure", _
                  detailText
    End If
    applicationStateConfirmed = _
        TransactionAnalysisApplicationStateAllowsEntryRestore( _
            True, recoveryDetail)
    If Not applicationStateConfirmed Then
        eventsStoppedAfterRecovery = _
            TryStopTransactionAnalysisEventsForBookWrites(stopDetail)
        AppendTransactionRollbackDetail recoveryDetail, _
            "Application状態を確認できません。"
        detailText = recoveryDetail
        Err.Raise vbObjectError + 5195, _
                  "TransactionAnalysisRecoveryFatal/StopAfterTransactionAnalysisEventStateFailure", _
                  detailText
    End If
    If Not TryStopTransactionAnalysisEventsForBookWrites(stopDetail) Then
        AppendTransactionRollbackDetail recoveryDetail, _
            "Recovery状態とApplication状態の確認後にExcelイベントFalse収束を" & _
            "確認できません: " & stopDetail
        detailText = recoveryDetail
        Err.Raise vbObjectError + 5195, _
                  "TransactionAnalysisRecoveryFatal/StopAfterTransactionAnalysisEventStateFailure", _
                  detailText
    End If
    detailText = recoveryDetail
    eventsStoppedAfterRecovery = _
        TryStopTransactionAnalysisEventsForBookWrites(stopDetail)
    recoveryConfirmedThisAttempt = eventsStoppedAfterRecovery
    Err.Raise vbObjectError + 5195, _
              "TransactionAnalysisRecoveryFatal/StopAfterTransactionAnalysisEventStateFailure", _
              detailText
End Sub

Private Function TransactionMainActionCaptionStateMatches() As Boolean
    Dim ws As Worksheet, shp As Shape
    Dim expectedCaption As String
    Dim expectedFill As Long, expectedLine As Long
    Dim actionFound As Boolean
    On Error GoTo Failed
    If Not SheetExists(SH_INPUT) Then Exit Function
    Set ws = GetSheet(SH_INPUT)
    If OutputsAreDirty() Then
        expectedCaption = "帳票・分析を更新"
        expectedFill = RGB(180, 83, 9)
        expectedLine = RGB(146, 64, 14)
    Else
        expectedCaption = "帳票・分析を再更新"
        expectedFill = RGB(15, 118, 110)
        expectedLine = RGB(13, 148, 136)
    End If
    For Each shp In ws.Shapes
        If ToolShapeActionName(shp) = "BuildAllOutputSheets" Then
            actionFound = True
            If StrComp(shp.TextFrame.Characters.Text, expectedCaption, _
                       vbBinaryCompare) <> 0 Then Exit Function
            If shp.Fill.ForeColor.RGB <> expectedFill Or _
               shp.Line.ForeColor.RGB <> expectedLine Then Exit Function
        End If
    Next shp
    TransactionMainActionCaptionStateMatches = actionFound
    Exit Function
Failed:
    Err.Clear
End Function

Public Function ValidateTransactionAnalysisSettings(ByRef detailText As String) As Boolean
    Dim ws As Worksheet
    Dim minAmount As Double, unknownMinAmount As Double
    Dim absoluteTolerance As Double, rateTolerance As Double
    Dim dayValue As Double
    Dim rateOK As Boolean
    Dim problems As String

    If Not SheetExists(SH_CONFIG) Then
        detailText = "設定シートがありません。"
        Exit Function
    End If
    Set ws = GetSheet(SH_CONFIG)
    If ws.Cells(ROW_CFG_ANALYSIS_MIN_AMOUNT, COL_CFG_ANALYSIS_VALUE).HasFormula Or _
       ws.Cells(ROW_CFG_ANALYSIS_DAY_WINDOW, COL_CFG_ANALYSIS_VALUE).HasFormula Or _
       ws.Cells(ROW_CFG_ANALYSIS_ABS_TOLERANCE, COL_CFG_ANALYSIS_VALUE).HasFormula Or _
       ws.Cells(ROW_CFG_ANALYSIS_RATE_TOLERANCE, COL_CFG_ANALYSIS_VALUE).HasFormula Or _
       ws.Cells(ROW_CFG_ANALYSIS_UNKNOWN_MIN, COL_CFG_ANALYSIS_VALUE).HasFormula Then _
        problems = problems & "分析条件には数式を使用できません。 "
    If Not TryReadAnalysisNumber(ws.Cells(ROW_CFG_ANALYSIS_MIN_AMOUNT, COL_CFG_ANALYSIS_VALUE).Value, _
                                 minAmount) Or minAmount < 0 Or minAmount > MAX_ABS_AMOUNT Then _
        problems = problems & "シフト・フローの最低金額は0～" & Format$(MAX_ABS_AMOUNT, "#,##0") & "で指定してください。 "
    If Not TryReadAnalysisNumber(ws.Cells(ROW_CFG_ANALYSIS_UNKNOWN_MIN, COL_CFG_ANALYSIS_VALUE).Value, _
                                 unknownMinAmount) Or unknownMinAmount < 0 Or _
                                 unknownMinAmount > MAX_ABS_AMOUNT Then _
        problems = problems & "不明入出金の最低金額は0～" & _
                   Format$(MAX_ABS_AMOUNT, "#,##0") & "で指定してください。 "
    If Not TryReadAnalysisNumber(ws.Cells(ROW_CFG_ANALYSIS_DAY_WINDOW, COL_CFG_ANALYSIS_VALUE).Value, _
                                 dayValue) Or dayValue <> 3 Then _
        problems = problems & "自動候補の日数幅は3暦日固定です。設定値を3へ戻してください。 "
    If Not TryReadAnalysisNumber(ws.Cells(ROW_CFG_ANALYSIS_ABS_TOLERANCE, COL_CFG_ANALYSIS_VALUE).Value, _
                                 absoluteTolerance) Or absoluteTolerance < 0 Or _
       absoluteTolerance > AUTO_CANDIDATE_MAX_AMOUNT_DIFFERENCE Then _
        problems = problems & "金額差の許容額は0～1,000,000円で指定してください。 "
    rateOK = TryReadAnalysisRatePercent( _
        ws.Cells(ROW_CFG_ANALYSIS_RATE_TOLERANCE, COL_CFG_ANALYSIS_VALUE), rateTolerance)
    If Not rateOK Or rateTolerance < 0 Or rateTolerance > 10 Then _
        problems = problems & "金額差の許容率は0～10%で指定してください。 "

    detailText = Trim$(problems)
    ValidateTransactionAnalysisSettings = (Len(detailText) = 0)
End Function

Public Function IsAnalysisReviewStatus(ByVal statusText As String) As Boolean
    Select Case Trim$(statusText)
        Case ANALYSIS_STATUS_UNREVIEWED, ANALYSIS_STATUS_SHIFT_CONFIRMED, _
             ANALYSIS_STATUS_SOURCE_CONFIRMED, ANALYSIS_STATUS_USE_CONFIRMED, _
             ANALYSIS_STATUS_EXCLUDED, ANALYSIS_STATUS_FOLLOWUP
            IsAnalysisReviewStatus = True
    End Select
End Function

Public Sub ProtectTransactionAnalysisSheets(Optional ByVal raiseOnError As Boolean = False)
    Dim sheetNames As Variant, item As Variant
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim currentErrorNumber As Long
    Dim currentErrorDescription As String, currentErrorSource As String
    Dim convergenceDetail As String
    sheetNames = Array(SH_ANALYSIS_SHIFT, SH_ANALYSIS_FLOW, SH_ANALYSIS_UNKNOWN, _
                       SH_ANALYSIS_RESULT, SH_ANALYSIS_DETAIL, SH_BALANCE_RECONCILIATION)
    '最初のシートで失敗しても残りを必ず再保護する。最初の原因だけを保持し、
    '厳格呼出しでは全シートを試した後に再Raiseする。
    For Each item In sheetNames
        If SheetExists(CStr(item)) Then
            On Error Resume Next
            Err.Clear
            ProtectSingleAnalysisSheet GetSheet(CStr(item))
            currentErrorNumber = Err.Number
            currentErrorDescription = Err.Description
            currentErrorSource = Err.Source
            Err.Clear
            On Error GoTo 0
            If IsTransactionAnalysisRecoveryFatal( _
                   currentErrorNumber, currentErrorSource) Then
                Call TryStopTransactionAnalysisEventsForBookWrites( _
                    convergenceDetail)
                Err.Raise currentErrorNumber, currentErrorSource, _
                          currentErrorDescription
            End If
            If currentErrorNumber <> 0 And errorNumber = 0 Then
                errorNumber = currentErrorNumber
                errorDescription = currentErrorDescription
                errorSource = currentErrorSource
            End If
        End If
    Next item
    If raiseOnError And errorNumber <> 0 Then _
        Err.Raise errorNumber, "ProtectTransactionAnalysisSheets", _
                  errorSource & " / " & errorDescription
End Sub

Public Sub FormatTransactionAnalysisSheets()
    Dim shiftCount As Long, flowCount As Long, unknownCount As Long
    Dim shiftVisible As XlSheetVisibility, flowVisible As XlSheetVisibility
    Dim unknownVisible As XlSheetVisibility
    Dim convergenceDetail As String
    Dim cleanupErrorNumber As Long
    Dim cleanupErrorDescription As String, cleanupErrorSource As String
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    On Error GoTo EH
    If SheetExists(SH_ANALYSIS_SHIFT) Then
        shiftVisible = GetSheet(SH_ANALYSIS_SHIFT).Visible
        shiftCount = Application.Max(0, LastUsedRowInSheet(GetSheet(SH_ANALYSIS_SHIFT)) - 1)
        FinalizeShiftAnalysisSheet GetSheet(SH_ANALYSIS_SHIFT), shiftCount
        GetSheet(SH_ANALYSIS_SHIFT).Visible = shiftVisible
    End If
    If SheetExists(SH_ANALYSIS_FLOW) Then
        flowVisible = GetSheet(SH_ANALYSIS_FLOW).Visible
        flowCount = Application.Max(0, LastUsedRowInSheet(GetSheet(SH_ANALYSIS_FLOW)) - 1)
        FinalizeAdvancedFlowAnalysisSheet GetSheet(SH_ANALYSIS_FLOW), flowCount
        GetSheet(SH_ANALYSIS_FLOW).Visible = flowVisible
    End If
    If SheetExists(SH_ANALYSIS_UNKNOWN) Then
        unknownVisible = GetSheet(SH_ANALYSIS_UNKNOWN).Visible
        unknownCount = Application.Max(0, LastUsedRowInSheet(GetSheet(SH_ANALYSIS_UNKNOWN)) - 1)
        FinalizeUnknownAnalysisSheet GetSheet(SH_ANALYSIS_UNKNOWN), unknownCount
        GetSheet(SH_ANALYSIS_UNKNOWN).Visible = unknownVisible
    End If
    If SheetExists(SH_ANALYSIS_RESULT) Then FormatAnalysisWorkspaceSheets
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    If IsTransactionAnalysisRecoveryFatal(errorNumber, errorSource) Then
        Call TryStopTransactionAnalysisEventsForBookWrites(convergenceDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    On Error Resume Next
    Err.Clear
    ProtectTransactionAnalysisSheets False
    cleanupErrorNumber = Err.Number
    cleanupErrorSource = Err.Source
    cleanupErrorDescription = Err.Description
    Err.Clear
    On Error GoTo 0
    If IsTransactionAnalysisRecoveryFatal( _
           cleanupErrorNumber, cleanupErrorSource) Then
        Call TryStopTransactionAnalysisEventsForBookWrites(convergenceDetail)
        Err.Raise cleanupErrorNumber, cleanupErrorSource, _
                  cleanupErrorDescription
    End If
    Err.Raise errorNumber, "FormatTransactionAnalysisSheets", errorSource & " / " & errorDescription
End Sub


Private Sub ReadTransactionAnalysisSettings(ByRef minAmount As Double, ByRef dayWindow As Long, _
                                            ByRef absoluteTolerance As Double, _
                                            ByRef rateTolerance As Double, _
                                            ByRef unknownMinAmount As Double)
    Dim ws As Worksheet
    Set ws = GetSheet(SH_CONFIG)
    minAmount = CDbl(ws.Cells(ROW_CFG_ANALYSIS_MIN_AMOUNT, COL_CFG_ANALYSIS_VALUE).Value)
    dayWindow = CLng(ws.Cells(ROW_CFG_ANALYSIS_DAY_WINDOW, COL_CFG_ANALYSIS_VALUE).Value)
    dayWindow = AutoCandidateEffectiveDayWindow(dayWindow)
    absoluteTolerance = CDbl(ws.Cells(ROW_CFG_ANALYSIS_ABS_TOLERANCE, COL_CFG_ANALYSIS_VALUE).Value)
    unknownMinAmount = CDbl(ws.Cells(ROW_CFG_ANALYSIS_UNKNOWN_MIN, COL_CFG_ANALYSIS_VALUE).Value)
    If Not TryReadAnalysisRatePercent( _
        ws.Cells(ROW_CFG_ANALYSIS_RATE_TOLERANCE, COL_CFG_ANALYSIS_VALUE), rateTolerance) Then _
        Err.Raise vbObjectError + 4624, "ReadTransactionAnalysisSettings", _
                  "金額差の許容率を読み取れません。"
End Sub

Private Sub FilterAnalysisRowsByMinimum(ByRef sourceData As Variant, ByRef sourceRows() As Long, _
                                        ByVal sourceCount As Long, ByVal isDeposit As Boolean, _
                                        ByVal minimumAmount As Double, ByRef filteredRows() As Long, _
                                        ByRef filteredCount As Long)
    Dim i As Long, sourceRow As Long, amountColumn As Long
    If isDeposit Then amountColumn = OUT_COL_DEPOSIT Else amountColumn = OUT_COL_WITHDRAW
    For i = 1 To sourceCount
        sourceRow = sourceRows(i)
        If CDbl(sourceData(sourceRow, amountColumn)) >= minimumAmount Then
            filteredCount = filteredCount + 1
            filteredRows(filteredCount) = sourceRow
        End If
    Next i
End Sub

Private Function TryReadAnalysisRatePercent(ByVal rateCell As Range, _
                                            ByRef ratePercentOut As Double) As Boolean
    Dim rawRate As Double
    Dim formatText As String, valueText As String
    If rateCell Is Nothing Then Exit Function
    valueText = Replace(CellText(rateCell.Value), "％", "%")
    If Right$(valueText, 1) = "%" Then
        valueText = Trim$(Left$(valueText, Len(valueText) - 1))
        If Not TryReadAnalysisNumber(valueText, rawRate) Then Exit Function
        ratePercentOut = rawRate
        TryReadAnalysisRatePercent = True
        Exit Function
    End If
    If Not TryReadAnalysisNumber(rateCell.Value, rawRate) Then Exit Function
    '「3」とExcel百分率書式の「3%」（内部値0.03）のどちらも3%として扱う。
    formatText = CellText(rateCell.NumberFormat) & CellText(rateCell.NumberFormatLocal)
    If InStr(1, formatText, "%", vbBinaryCompare) > 0 Then rawRate = rawRate * 100#
    ratePercentOut = rawRate
    TryReadAnalysisRatePercent = True
End Function

Public Sub EnsureExistingAnalysisReviewBounds(ByVal ws As Worksheet, ByVal labelText As String)
    Dim lastR As Long
    If ws Is Nothing Then Exit Sub
    lastR = LastUsedRowInSheet(ws)
    If lastR > MAX_ANALYSIS_OUTPUT_ROWS + 1 Then _
        Err.Raise vbObjectError + 4623, "EnsureExistingAnalysisReviewBounds", _
                  labelText & "の既存行が実用上限を超えています。" & _
                  "確認記録を保護するため、再生成前に該当する行の内容を確認してください。"
End Sub

Private Function TryReadAnalysisNumber(ByVal valueIn As Variant, ByRef numberOut As Double) As Boolean
    On Error GoTo EH
    If IsError(valueIn) Then Exit Function
    If VarType(valueIn) = vbBoolean Then Exit Function
    If Not HasText(valueIn) Then Exit Function
    If Not IsNumeric(valueIn) Then Exit Function
    numberOut = CDbl(valueIn)
    If numberOut <> numberOut Then Exit Function
    TryReadAnalysisNumber = True
    Exit Function
EH:
    TryReadAnalysisNumber = False
End Function

Private Function IsValidAnalysisAmountValue(ByVal valueIn As Variant) As Boolean
    If IsError(valueIn) Then Exit Function
    If IsNull(valueIn) Then Exit Function
    If IsEmpty(valueIn) Then Exit Function
    If VarType(valueIn) = vbBoolean Then Exit Function
    If Not IsNumeric(valueIn) Then Exit Function
    IsValidAnalysisAmountValue = True
End Function

Private Sub ValidateAndIndexAnalysisTransactions(ByRef sourceData As Variant, ByVal minAmount As Double, _
                                                 ByRef withdrawalRows() As Long, ByRef withdrawalCount As Long, _
                                                 ByRef depositRows() As Long, ByRef depositCount As Long, _
                                                 ByRef componentWithdrawalRows() As Long, _
                                                 ByRef componentWithdrawalCount As Long, _
                                                 ByRef componentDepositRows() As Long, _
                                                 ByRef componentDepositCount As Long)
    Dim r As Long
    Dim withdrawalAmount As Double, depositAmount As Double
    Dim hasWithdrawal As Boolean, hasDeposit As Boolean
    Dim timeOK As Boolean, normalizedTime As Variant
    Dim dateOK As Boolean, normalizedDate As Variant
    Dim txID As String, accountID As String
    Dim seenTransactionIDs As Object
    Set seenTransactionIDs = CreateObject("Scripting.Dictionary")
    seenTransactionIDs.CompareMode = vbTextCompare

    For r = 1 To UBound(sourceData, 1)
        If CellText(sourceData(r, WORK_TX_COL_RECORD_TYPE)) = RECORD_TRANSACTION Then
            dateOK = False
            normalizedDate = NormalizeDateOnlyValue(sourceData(r, OUT_COL_DATE), dateOK)
            If Not dateOK Then _
                Err.Raise vbObjectError + 4605, "ValidateAndIndexAnalysisTransactions", _
                          "W_取引 " & CStr(r + 1) & "行目の日付が不正です。"
            If Abs(CDbl(CDate(sourceData(r, OUT_COL_DATE))) - CDbl(CDate(normalizedDate))) > 0.0000001 Then _
                Err.Raise vbObjectError + 4620, "ValidateAndIndexAnalysisTransactions", _
                          "W_取引 " & CStr(r + 1) & "行目の日付列に時刻が混入しています。"
            If HasText(sourceData(r, OUT_COL_TIME)) Then
                timeOK = False
                normalizedTime = NormalizeTimeInput(sourceData(r, OUT_COL_TIME), timeOK)
                If Not timeOK Then _
                    Err.Raise vbObjectError + 4606, "ValidateAndIndexAnalysisTransactions", _
                              "W_取引 " & CStr(r + 1) & "行目の時刻が不正です。"
            End If

            hasWithdrawal = HasText(sourceData(r, OUT_COL_WITHDRAW))
            hasDeposit = HasText(sourceData(r, OUT_COL_DEPOSIT))
            If hasWithdrawal And hasDeposit Then _
                Err.Raise vbObjectError + 4607, "ValidateAndIndexAnalysisTransactions", _
                          "W_取引 " & CStr(r + 1) & "行目に出金と入金が同時入力されています。"
            If hasWithdrawal Then
                If Not IsValidAnalysisAmountValue(sourceData(r, OUT_COL_WITHDRAW)) Then _
                    Err.Raise vbObjectError + 4608, "ValidateAndIndexAnalysisTransactions", _
                              "W_取引 " & CStr(r + 1) & "行目の出金額が不正です。"
                withdrawalAmount = CDbl(sourceData(r, OUT_COL_WITHDRAW))
                If withdrawalAmount < 0 Or withdrawalAmount > MAX_ABS_AMOUNT Then _
                    Err.Raise vbObjectError + 4609, "ValidateAndIndexAnalysisTransactions", _
                              "W_取引 " & CStr(r + 1) & "行目の出金額が範囲外です。"
            Else
                withdrawalAmount = 0
            End If
            If hasDeposit Then
                If Not IsValidAnalysisAmountValue(sourceData(r, OUT_COL_DEPOSIT)) Then _
                    Err.Raise vbObjectError + 4610, "ValidateAndIndexAnalysisTransactions", _
                              "W_取引 " & CStr(r + 1) & "行目の入金額が不正です。"
                depositAmount = CDbl(sourceData(r, OUT_COL_DEPOSIT))
                If depositAmount < 0 Or depositAmount > MAX_ABS_AMOUNT Then _
                    Err.Raise vbObjectError + 4611, "ValidateAndIndexAnalysisTransactions", _
                              "W_取引 " & CStr(r + 1) & "行目の入金額が範囲外です。"
            Else
                depositAmount = 0
            End If

            If withdrawalAmount > 0 Or depositAmount > 0 Then
                txID = CellText(sourceData(r, WORK_TX_COL_TRANSACTION_ID))
                accountID = CellText(sourceData(r, WORK_TX_COL_ACCOUNT_ID))
                If Len(txID) = 0 Or Len(accountID) = 0 Then _
                    Err.Raise vbObjectError + 4612, "ValidateAndIndexAnalysisTransactions", _
                              "W_取引 " & CStr(r + 1) & "行目の取引IDまたは口座IDがありません。"
                If seenTransactionIDs.Exists(txID) Then _
                    Err.Raise vbObjectError + 4618, "ValidateAndIndexAnalysisTransactions", _
                              "W_取引の取引IDが重複しています: " & txID
                seenTransactionIDs.Add txID, True
            End If
            If withdrawalAmount > 0 Then
                componentWithdrawalCount = componentWithdrawalCount + 1
                componentWithdrawalRows(componentWithdrawalCount) = r
                If withdrawalAmount >= minAmount Then
                    withdrawalCount = withdrawalCount + 1
                    withdrawalRows(withdrawalCount) = r
                End If
            ElseIf depositAmount > 0 Then
                componentDepositCount = componentDepositCount + 1
                componentDepositRows(componentDepositCount) = r
                If depositAmount >= minAmount Then
                    depositCount = depositCount + 1
                    depositRows(depositCount) = r
                End If
            End If
        End If
    Next r
End Sub

Private Sub ProcessShiftCandidates(ByRef sourceData As Variant, ByRef withdrawalRows() As Long, _
                                   ByVal withdrawalCount As Long, ByRef depositAmounts() As Double, _
                                   ByRef depositSortRows() As Long, ByVal depositCount As Long, _
                                   ByVal dayWindow As Long, ByVal absoluteTolerance As Double, _
                                   ByVal rateTolerance As Double, ByVal settingsSignature As String, _
                                   ByVal writeOutput As Boolean, _
                                   ByVal wsOut As Worksheet, ByVal reviews As Object, _
                                   ByVal candidateCountByTx As Object, ByVal bestScoreByTx As Object, _
                                   ByVal bestRatingByTx As Object, ByRef candidateTotal As Long)
    Dim i As Long, j As Long, firstMatch As Long, lastMatch As Long
    Dim withdrawalRow As Long, depositRow As Long
    Dim withdrawalAmount As Double, depositAmount As Double
    Dim lowerAmount As Double, upperAmount As Double, differenceAmount As Double
    Dim buffer() As Variant, bufferCount As Long, nextOutputRow As Long
    Dim chronology As String, timePrecision As String, elapsedText As String
    Dim amountMatch As String, reasonText As String, ratingText As String
    Dim score As Long, candidateKey As String
    Dim withdrawalTxID As String, depositTxID As String, evidenceDigest As String
    Dim ambiguityCount As Long
    Dim comparisonCount As Double, comparisonRangeCount As Double
    Dim processedComparisons As Long

    candidateTotal = 0
    If writeOutput Then
        If wsOut Is Nothing Then Err.Raise vbObjectError + 4613, "ProcessShiftCandidates", "出力先がありません。"
        ReDim buffer(1 To ANALYSIS_BUFFER_ROWS, 1 To SHIFT_ANALYSIS_LAST_COL)
        nextOutputRow = 2
    End If

    For i = 1 To withdrawalCount
        If i Mod 512 = 0 Then AppProgress "資金シフト候補を照合しています...", i, withdrawalCount
        withdrawalRow = withdrawalRows(i)
        withdrawalAmount = CDbl(sourceData(withdrawalRow, OUT_COL_WITHDRAW))
        AnalysisAmountSearchBounds withdrawalAmount, absoluteTolerance, rateTolerance, lowerAmount, upperAmount
        firstMatch = LowerBoundAnalysisAmount(depositAmounts, depositCount, lowerAmount)
        lastMatch = UpperBoundAnalysisAmount(depositAmounts, depositCount, upperAmount)
        If firstMatch <= lastMatch Then
            '候補になった件数だけでは、同一口座・日付範囲外として後で除外される
            '膨大な組合せを止められない。内側ループへ入る前に比較予定数を数える。
            comparisonRangeCount = CDbl(lastMatch - firstMatch + 1)
            If comparisonCount + comparisonRangeCount > MAX_SHIFT_PAIR_COMPARISONS Then
                Err.Raise vbObjectError + 4619, "ProcessShiftCandidates", _
                          "資金シフト候補の照合範囲が広すぎるため、安全のため停止しました。" & _
                          vbCrLf & "比較予定が" & _
                          Format$(comparisonCount + comparisonRangeCount, "#,##0") & _
                          "件を超えています。" & vbCrLf & _
                          "設定の最低金額を上げるか、金額差許容を狭めてから再実行してください。" & _
                          vbCrLf & "既存の分析結果は完成済みとして更新されません。"
            End If
            comparisonCount = comparisonCount + comparisonRangeCount
            For j = firstMatch To lastMatch
                processedComparisons = processedComparisons + 1
                If processedComparisons Mod 32768 = 0 Then _
                    AppProgress "資金シフト候補を照合しています...", _
                                processedComparisons, CLng(MAX_SHIFT_PAIR_COMPARISONS)
                depositRow = depositSortRows(j)
                depositAmount = CDbl(sourceData(depositRow, OUT_COL_DEPOSIT))
                differenceAmount = Abs(withdrawalAmount - depositAmount)
                If AutoCandidateAmountGatePasses(withdrawalAmount, depositAmount, _
                                                  absoluteTolerance, rateTolerance) Then
                    If IsShiftPairEligible(sourceData, withdrawalRow, depositRow, dayWindow) Then
                        EvaluateShiftPair sourceData, withdrawalRow, depositRow, absoluteTolerance, _
                                          chronology, timePrecision, elapsedText, amountMatch, _
                                          reasonText, score, ratingText
                        candidateTotal = candidateTotal + 1
                        If candidateTotal > MAX_ANALYSIS_OUTPUT_ROWS Then Exit Sub
                        withdrawalTxID = CellText(sourceData(withdrawalRow, WORK_TX_COL_TRANSACTION_ID))
                        depositTxID = CellText(sourceData(depositRow, WORK_TX_COL_TRANSACTION_ID))
                        candidateKey = withdrawalTxID & ">" & depositTxID
                        If writeOutput Then
                            ambiguityCount = AnalysisMaximumCandidateCount(candidateCountByTx, _
                                             withdrawalTxID & ";" & depositTxID)
                            evidenceDigest = AnalysisEvidenceDigest(sourceData, _
                                CStr(withdrawalRow) & ";" & CStr(depositRow), _
                                "SHIFT|" & settingsSignature & "|AMB=" & CStr(ambiguityCount))
                            bufferCount = bufferCount + 1
                            FillShiftAnalysisRow buffer, bufferCount, sourceData, withdrawalRow, depositRow, _
                                                 differenceAmount, chronology, timePrecision, elapsedText, _
                                                 amountMatch, reasonText, score, ratingText, candidateKey, _
                                                 evidenceDigest, reviews, candidateCountByTx
                            If bufferCount = ANALYSIS_BUFFER_ROWS Then
                                FlushAnalysisBuffer wsOut, buffer, bufferCount, nextOutputRow, SHIFT_ANALYSIS_LAST_COL
                                ReDim buffer(1 To ANALYSIS_BUFFER_ROWS, 1 To SHIFT_ANALYSIS_LAST_COL)
                                bufferCount = 0
                            End If
                        Else
                            UpdateShiftCandidateStats candidateCountByTx, bestScoreByTx, bestRatingByTx, _
                                                      withdrawalTxID, score, ratingText
                            UpdateShiftCandidateStats candidateCountByTx, bestScoreByTx, bestRatingByTx, _
                                                      depositTxID, score, ratingText
                        End If
                    End If
                End If
            Next j
        End If
    Next i
    If writeOutput And bufferCount > 0 Then _
        FlushAnalysisBuffer wsOut, buffer, bufferCount, nextOutputRow, SHIFT_ANALYSIS_LAST_COL
End Sub

Private Function IsShiftPairEligible(ByRef sourceData As Variant, ByVal withdrawalRow As Long, _
                                     ByVal depositRow As Long, ByVal dayWindow As Long) As Boolean
    Dim withdrawalAccountID As String, depositAccountID As String
    Dim withdrawalDate As Long, depositDate As Long
    Dim withdrawalTime As Double, depositTime As Double
    Dim withdrawalHasTime As Boolean, depositHasTime As Boolean
    withdrawalAccountID = CellText(sourceData(withdrawalRow, WORK_TX_COL_ACCOUNT_ID))
    depositAccountID = CellText(sourceData(depositRow, WORK_TX_COL_ACCOUNT_ID))
    If Len(withdrawalAccountID) = 0 Or Len(depositAccountID) = 0 Then Exit Function
    '同一口座内の出入金は資金の口座間移動ではないため候補から外す。
    If StrComp(withdrawalAccountID, depositAccountID, vbTextCompare) = 0 Then Exit Function
    withdrawalDate = CLng(VBA.DateValue(CDate(sourceData(withdrawalRow, OUT_COL_DATE))))
    depositDate = CLng(VBA.DateValue(CDate(sourceData(depositRow, OUT_COL_DATE))))
    If Not AutoCandidateDepositDatePasses(withdrawalDate, depositDate, dayWindow) Then _
        Exit Function
    withdrawalHasTime = TryGetAnalysisTime( _
                        sourceData(withdrawalRow, OUT_COL_TIME), withdrawalTime)
    depositHasTime = TryGetAnalysisTime(sourceData(depositRow, OUT_COL_TIME), depositTime)
    If Not AutoCandidatePairChronologyPasses( _
               withdrawalDate, withdrawalHasTime, withdrawalTime, _
               depositDate, depositHasTime, depositTime) Then Exit Function
    IsShiftPairEligible = True
End Function

Private Sub EvaluateShiftPair(ByRef sourceData As Variant, ByVal withdrawalRow As Long, _
                              ByVal depositRow As Long, ByVal absoluteTolerance As Double, _
                              ByRef chronology As String, ByRef timePrecision As String, _
                              ByRef elapsedText As String, ByRef amountMatch As String, _
                              ByRef reasonText As String, ByRef score As Long, ByRef ratingText As String)
    Dim withdrawalDate As Long, depositDate As Long, dayDifference As Long
    Dim withdrawalTime As Double, depositTime As Double
    Dim withdrawalHasTime As Boolean, depositHasTime As Boolean
    Dim signedMinutes As Double, absoluteMinutes As Double
    Dim withdrawalAmount As Double, depositAmount As Double, differenceAmount As Double
    Dim samePerson As Boolean, sameBank As Boolean, timeEvidencePoints As Long
    Dim withdrawalPersonID As String, depositPersonID As String
    Dim personEvidenceText As String
    Dim inheritanceDate As Long
    Dim nearInheritance As Boolean, straddlesInheritance As Boolean

    withdrawalDate = CLng(VBA.DateValue(CDate(sourceData(withdrawalRow, OUT_COL_DATE))))
    depositDate = CLng(VBA.DateValue(CDate(sourceData(depositRow, OUT_COL_DATE))))
    dayDifference = Abs(withdrawalDate - depositDate)
    withdrawalHasTime = TryGetAnalysisTime(sourceData(withdrawalRow, OUT_COL_TIME), withdrawalTime)
    depositHasTime = TryGetAnalysisTime(sourceData(depositRow, OUT_COL_TIME), depositTime)
    If Not AutoCandidatePairChronologyPasses( _
               withdrawalDate, withdrawalHasTime, withdrawalTime, _
               depositDate, depositHasTime, depositTime) Then _
        Err.Raise vbObjectError + 4640, "EvaluateShiftPair", _
                  "記録上、入金が出金より前のため自動候補にできません。"
    If withdrawalHasTime And depositHasTime Then
        timePrecision = "両方時刻記載あり"
    ElseIf withdrawalHasTime Or depositHasTime Then
        timePrecision = "一部時刻記載なし"
    Else
        timePrecision = "時刻記載なし"
    End If

    If withdrawalDate = depositDate Then
        If withdrawalHasTime And depositHasTime Then
            signedMinutes = ((depositDate + depositTime) - (withdrawalDate + withdrawalTime)) * 1440#
            absoluteMinutes = Abs(signedMinutes)
            '採否側のAutoCandidatePairChronologyPassesと同じ1e-9日を使う。
            '境界だけ採否では同時刻、表示では逆順となる不整合を作らない。
            If signedMinutes > 0.00000144 Then
                chronology = "出金→入金"
            ElseIf signedMinutes < -0.00000144 Then
                chronology = "入金→出金"
            Else
                '同じ記録時刻からは先後を復元できない。入力順や取引IDで補完しない。
                chronology = "同日内順序不明"
                elapsedText = "同時刻（順序不明）"
            End If
            If Len(elapsedText) = 0 Then _
                elapsedText = FormatAnalysisElapsedMinutes(absoluteMinutes)
        Else
            '同日でも時刻が片方以上欠けると、記帳順を断定できない。
            '方向は資金経路の候補として扱い、実際の前後関係は根拠資料で確認する。
            chronology = "同日内順序不明"
            elapsedText = "同日（時刻記載なし）"
        End If
    ElseIf withdrawalDate < depositDate Then
        chronology = "出金→入金"
        If withdrawalHasTime And depositHasTime Then
            absoluteMinutes = ((depositDate + depositTime) - (withdrawalDate + withdrawalTime)) * 1440#
            elapsedText = FormatAnalysisElapsedMinutes(Abs(absoluteMinutes))
        Else
            elapsedText = CStr(dayDifference) & "日"
        End If
    Else
        chronology = "入金→出金"
        If withdrawalHasTime And depositHasTime Then
            absoluteMinutes = ((withdrawalDate + withdrawalTime) - (depositDate + depositTime)) * 1440#
            elapsedText = FormatAnalysisElapsedMinutes(Abs(absoluteMinutes))
        Else
            elapsedText = CStr(dayDifference) & "日"
        End If
    End If

    withdrawalAmount = CDbl(sourceData(withdrawalRow, OUT_COL_WITHDRAW))
    depositAmount = CDbl(sourceData(depositRow, OUT_COL_DEPOSIT))
    differenceAmount = Abs(withdrawalAmount - depositAmount)
    If differenceAmount < 0.0000001 Then
        amountMatch = "完全一致"
        score = 45
    ElseIf differenceAmount <= absoluteTolerance + 0.0000001 Then
        amountMatch = "許容額内"
        score = 35
    Else
        amountMatch = "許容率内"
        score = 25
    End If

    '時刻は両取引に記載がある場合だけ根拠点とする。片側でも未記載なら0点で、
    '未記載そのものによる減点や上限も設けない。
    timeEvidencePoints = ShiftTimeEvidencePoints(withdrawalHasTime, depositHasTime, _
                                                 absoluteMinutes, dayDifference)
    score = score + timeEvidencePoints

    withdrawalPersonID = CellText(sourceData(withdrawalRow, WORK_TX_COL_PERSON_ID))
    depositPersonID = CellText(sourceData(depositRow, WORK_TX_COL_PERSON_ID))
    If Len(withdrawalPersonID) = 0 Or Len(depositPersonID) = 0 Then _
        Err.Raise vbObjectError + 4638, "EvaluateShiftPair", _
                  "分析対象取引に人物IDがありません。氏名では代替せず、人物整合性を修正してください。"
    If Not IsInternalIdValue(withdrawalPersonID, "P") Or _
       Not IsInternalIdValue(depositPersonID, "P") Then _
        Err.Raise vbObjectError + 4639, "EvaluateShiftPair", _
                  "分析対象取引の人物ID形式が不正です（出金=" & withdrawalPersonID & _
                  " / 入金=" & depositPersonID & "）。"
    samePerson = (StrComp(withdrawalPersonID, depositPersonID, vbTextCompare) = 0)
    If samePerson Then
        personEvidenceText = "人物ID確認済み（同一人物内）です。"
    Else
        personEvidenceText = "別人物間の候補です（両人物ID確認済み）。"
    End If
    '入口の人物整合性検査を通過した人物IDは、同一人物・別人物の別を問わず
    '同じ基礎点とする。人物の別は調査上の分類であり、確度を下げる理由ではない。
    score = score + 12
    score = score + 8  '異なる口座IDであることはIsShiftPairEligibleで確認済み。
    sameBank = (StrComp(CellText(sourceData(withdrawalRow, OUT_COL_BANK)), _
                         CellText(sourceData(depositRow, OUT_COL_BANK)), vbTextCompare) = 0)
    If sameBank Then score = score + 2 Else score = score + 4
    If IsDate(mAnalysisInheritanceDate) Then
        inheritanceDate = CLng(VBA.DateValue(CDate(mAnalysisInheritanceDate)))
        nearInheritance = (Abs(withdrawalDate - inheritanceDate) <= 30 Or _
                           Abs(depositDate - inheritanceDate) <= 30)
        straddlesInheritance = _
            (withdrawalDate < inheritanceDate And depositDate >= inheritanceDate) Or _
            (depositDate < inheritanceDate And withdrawalDate >= inheritanceDate)
    End If

    '既知の逆順はIsShiftPairEligibleで候補外とする。時刻未記載による
    '同日内順序不明には、減点もスコア上限も適用しない。
    If score < 0 Then score = 0
    If score > 100 Then score = 100

    If score >= 80 Then
        ratingText = "高"
    ElseIf score >= 60 Then
        ratingText = "中"
    Else
        ratingText = "低"
    End If
    Select Case amountMatch
        Case "完全一致"
            reasonText = "出金額と入金額は一致しています。"
        Case "許容額内"
            reasonText = "金額差は設定した許容額内です。"
        Case Else
            reasonText = "金額差は設定した許容率内です。"
    End Select
    If StrComp(chronology, "同日内順序不明", vbTextCompare) = 0 Then
        If withdrawalHasTime And depositHasTime Then
            reasonText = AppendAnalysisReason(reasonText, _
                         "出金と入金の記録時刻が同一のため同日内順序不明です。前後関係は断定していません。")
        Else
            reasonText = AppendAnalysisReason(reasonText, _
                         "同日の取引ですが、時刻記載なしのため同日内順序不明です。前後関係は断定していません。")
        End If
    ElseIf StrComp(chronology, "同時刻", vbTextCompare) = 0 Then
        reasonText = AppendAnalysisReason(reasonText, "記録上は同時刻です。")
    Else
        reasonText = AppendAnalysisReason(reasonText, chronology & "の順で、経過は" & elapsedText & "です。")
    End If
    reasonText = AppendAnalysisReason(reasonText, "両取引の口座は異なります。")
    reasonText = AppendAnalysisReason(reasonText, personEvidenceText)
    If sameBank Then
        reasonText = AppendAnalysisReason(reasonText, "銀行は同じです。")
    Else
        reasonText = AppendAnalysisReason(reasonText, "銀行は異なります。")
    End If
    If nearInheritance Then _
        reasonText = AppendAnalysisReason(reasonText, "相続開始日前後30日以内の取引を含みます。")
    If straddlesInheritance Then _
        reasonText = AppendAnalysisReason(reasonText, _
                     "相続開始日をまたいでいますが、この点は資金移動の確度には加点していません。")
    reasonText = AppendAnalysisReason(reasonText, _
                 "摘要の内容は自動判定に使用していないため、原資料で確認してください。")
End Sub

'S40: 片側でも時刻が未記載なら、時刻根拠は0点。欠落を日付近接点で代替しない。
Private Function ShiftTimeEvidencePoints(ByVal withdrawalHasTime As Boolean, _
                                         ByVal depositHasTime As Boolean, _
                                         ByVal absoluteMinutes As Double, _
                                         ByVal dayDifference As Long) As Long
    If Not withdrawalHasTime Or Not depositHasTime Then Exit Function
    If absoluteMinutes <= 15# Then
        ShiftTimeEvidencePoints = 30
    ElseIf absoluteMinutes <= 60# Then
        ShiftTimeEvidencePoints = 26
    ElseIf absoluteMinutes <= 360# Then
        ShiftTimeEvidencePoints = 22
    ElseIf absoluteMinutes <= 1440# Then
        ShiftTimeEvidencePoints = 18
    ElseIf dayDifference <= 2 Then
        ShiftTimeEvidencePoints = 12
    ElseIf dayDifference <= AUTO_CANDIDATE_MAX_CALENDAR_DAYS Then
        ShiftTimeEvidencePoints = 7
    End If
End Function

Private Function AnalysisSingleTimeEvidenceLabel(ByVal rawTimeEntry As Variant) As String
    If HasText(rawTimeEntry) Then
        AnalysisSingleTimeEvidenceLabel = "時刻記載あり"
    Else
        AnalysisSingleTimeEvidenceLabel = "時刻記載なし"
    End If
End Function

Private Function AnalysisUnknownCapacityUpperBound( _
        ByVal withdrawalRows As Long, ByVal depositRows As Long) As Long
    Dim plannedRows As Double
    If withdrawalRows < 0 Or depositRows < 0 Then _
        Err.Raise vbObjectError + 4631, "AnalysisUnknownCapacityUpperBound", _
                  "不明入出金の予定件数が不正です。"
    plannedRows = CDbl(withdrawalRows) + CDbl(depositRows)
    If plannedRows > 2147483647# Then _
        Err.Raise vbObjectError + 4631, "AnalysisUnknownCapacityUpperBound", _
                  "不明入出金の予定件数をLong範囲で表現できません。"
    If plannedRows > CDbl(MAX_ANALYSIS_OUTPUT_ROWS) Then
        AnalysisUnknownCapacityUpperBound = MAX_ANALYSIS_OUTPUT_ROWS
    Else
        AnalysisUnknownCapacityUpperBound = CLng(plannedRows)
    End If
End Function

'シートを書き換えず、順序・時刻欠落・人物ID必須の評価条件を固定する。


'S45: 共有取引IDの確認済み競合は、既存の確認欄を一切変更せず保存を停止する。


Private Sub FillShiftAnalysisRow(ByRef buffer() As Variant, ByVal bufferRow As Long, _
                                 ByRef sourceData As Variant, ByVal withdrawalRow As Long, _
                                 ByVal depositRow As Long, ByVal differenceAmount As Double, _
                                 ByVal chronology As String, ByVal timePrecision As String, _
                                 ByVal elapsedText As String, ByVal amountMatch As String, _
                                 ByVal reasonText As String, ByVal score As Long, _
                                 ByVal ratingText As String, ByVal candidateKey As String, _
                                 ByVal evidenceDigest As String, ByVal reviews As Object, _
                                 ByVal candidateCountByTx As Object)
    Dim reviewValues As Variant
    Dim withdrawalTxID As String, depositTxID As String, ambiguityCount As Long
    withdrawalTxID = CellText(sourceData(withdrawalRow, WORK_TX_COL_TRANSACTION_ID))
    depositTxID = CellText(sourceData(depositRow, WORK_TX_COL_TRANSACTION_ID))
    ambiguityCount = AnalysisMaximumCandidateCount(candidateCountByTx, _
                                                    withdrawalTxID & ";" & depositTxID)
    If ambiguityCount > 1 Then
        reasonText = AppendAnalysisReason(reasonText, "同一取引を含む候補が最大" & _
                     CStr(ambiguityCount) & "件あり、確定前に重複利用を確認してください。")
    End If
    reasonText = AppendAnalysisReason(reasonText, _
                 "候補は入力済み取引の範囲内での推定です。未収載取引の不存在を意味しません。")
    reviewValues = AnalysisReviewValues(reviews, candidateKey, evidenceDigest)
    If CBool(reviewValues(2)) Then
        reasonText = AppendAnalysisReason(reasonText, _
                     "前回確認後に根拠取引または分析条件が変わったため、再確認へ戻しました。")
        reviewValues(1) = AppendAnalysisMemo(CStr(reviewValues(1)), _
                          "[自動] 根拠取引または分析条件の変更を検知し、再確認へ戻しました。")
    End If
    buffer(bufferRow, 1) = ratingText
    buffer(bufferRow, 2) = score
    buffer(bufferRow, 3) = "1対1"
    buffer(bufferRow, 4) = chronology
    buffer(bufferRow, 5) = timePrecision
    buffer(bufferRow, 6) = elapsedText
    buffer(bufferRow, 7) = amountMatch
    buffer(bufferRow, 8) = differenceAmount
    buffer(bufferRow, 9) = CDate(sourceData(withdrawalRow, OUT_COL_DATE))
    buffer(bufferRow, 10) = AnalysisTimeOutputValue(sourceData(withdrawalRow, OUT_COL_TIME))
    buffer(bufferRow, 11) = sourceData(withdrawalRow, OUT_COL_PERSON)
    buffer(bufferRow, 12) = sourceData(withdrawalRow, WORK_TX_COL_RELATIONSHIP)
    buffer(bufferRow, 13) = sourceData(withdrawalRow, OUT_COL_BANK)
    buffer(bufferRow, 14) = sourceData(withdrawalRow, OUT_COL_BRANCH)
    buffer(bufferRow, 15) = sourceData(withdrawalRow, OUT_COL_ACCOUNT_TYPE)
    buffer(bufferRow, 16) = sourceData(withdrawalRow, OUT_COL_ACCOUNT_NO)
    buffer(bufferRow, 17) = sourceData(withdrawalRow, OUT_COL_WITHDRAW)
    buffer(bufferRow, 18) = sourceData(withdrawalRow, OUT_COL_TEKIYO)
    buffer(bufferRow, 19) = CDate(sourceData(depositRow, OUT_COL_DATE))
    buffer(bufferRow, 20) = AnalysisTimeOutputValue(sourceData(depositRow, OUT_COL_TIME))
    buffer(bufferRow, 21) = sourceData(depositRow, OUT_COL_PERSON)
    buffer(bufferRow, 22) = sourceData(depositRow, WORK_TX_COL_RELATIONSHIP)
    buffer(bufferRow, 23) = sourceData(depositRow, OUT_COL_BANK)
    buffer(bufferRow, 24) = sourceData(depositRow, OUT_COL_BRANCH)
    buffer(bufferRow, 25) = sourceData(depositRow, OUT_COL_ACCOUNT_TYPE)
    buffer(bufferRow, 26) = sourceData(depositRow, OUT_COL_ACCOUNT_NO)
    buffer(bufferRow, 27) = sourceData(depositRow, OUT_COL_DEPOSIT)
    buffer(bufferRow, 28) = sourceData(depositRow, OUT_COL_TEKIYO)
    buffer(bufferRow, 29) = reasonText
    buffer(bufferRow, 30) = reviewValues(0)
    buffer(bufferRow, 31) = reviewValues(1)
    buffer(bufferRow, 32) = AnalysisStoredKey(candidateKey, evidenceDigest)
    buffer(bufferRow, 33) = sourceData(withdrawalRow, WORK_TX_COL_TRANSACTION_ID)
    buffer(bufferRow, 34) = sourceData(depositRow, WORK_TX_COL_TRANSACTION_ID)
End Sub

Public Sub UpdateShiftCandidateStats(ByVal candidateCountByTx As Object, ByVal bestScoreByTx As Object, _
                                      ByVal bestRatingByTx As Object, ByVal transactionID As String, _
                                      ByVal score As Long, ByVal ratingText As String)
    If candidateCountByTx.Exists(transactionID) Then
        candidateCountByTx(transactionID) = CLng(candidateCountByTx(transactionID)) + 1
    Else
        candidateCountByTx.Add transactionID, 1
    End If
    If Not bestScoreByTx.Exists(transactionID) Then
        bestScoreByTx.Add transactionID, score
        bestRatingByTx.Add transactionID, ratingText
    ElseIf score > CLng(bestScoreByTx(transactionID)) Then
        bestScoreByTx(transactionID) = score
        bestRatingByTx(transactionID) = ratingText
    End If
End Sub

Private Sub WriteUnknownAnalysis(ByRef sourceData As Variant, ByRef withdrawalRows() As Long, _
                                 ByVal withdrawalCount As Long, ByRef depositRows() As Long, _
                                 ByVal depositCount As Long, ByVal reviews As Object, _
                                 ByVal candidateCountByTx As Object, ByVal confirmedCountByTx As Object, _
                                 ByVal allocationIndex As Object, _
                                 ByVal bestRatingByTx As Object, ByVal unknownContextByTx As Object, _
                                 ByVal settingsSignature As String, _
                                 ByVal wsOut As Worksheet, ByRef writtenCount As Long)
    Dim buffer() As Variant
    Dim bufferCount As Long, nextOutputRow As Long, i As Long
    Dim allocatedAmount As Double, unresolvedAmount As Double
    Dim allocationCount As Long
    ReDim buffer(1 To ANALYSIS_BUFFER_ROWS, 1 To UNKNOWN_ANALYSIS_LAST_COL)
    nextOutputRow = 2
    For i = 1 To withdrawalCount
        If TryGetUnknownResidual(sourceData, withdrawalRows(i), False, allocationIndex, _
                                 allocatedAmount, unresolvedAmount, allocationCount) Then
            bufferCount = bufferCount + 1
            FillUnknownAnalysisRow buffer, bufferCount, sourceData, withdrawalRows(i), False, reviews, _
                                   candidateCountByTx, confirmedCountByTx, bestRatingByTx, _
                                   unknownContextByTx, settingsSignature, allocatedAmount, _
                                   unresolvedAmount, allocationCount
            writtenCount = writtenCount + 1
            If bufferCount = ANALYSIS_BUFFER_ROWS Then
                FlushAnalysisBuffer wsOut, buffer, bufferCount, nextOutputRow, UNKNOWN_ANALYSIS_LAST_COL
                ReDim buffer(1 To ANALYSIS_BUFFER_ROWS, 1 To UNKNOWN_ANALYSIS_LAST_COL)
                bufferCount = 0
            End If
        End If
    Next i
    For i = 1 To depositCount
        If TryGetUnknownResidual(sourceData, depositRows(i), True, allocationIndex, _
                                 allocatedAmount, unresolvedAmount, allocationCount) Then
            bufferCount = bufferCount + 1
            FillUnknownAnalysisRow buffer, bufferCount, sourceData, depositRows(i), True, reviews, _
                                   candidateCountByTx, confirmedCountByTx, bestRatingByTx, _
                                   unknownContextByTx, settingsSignature, allocatedAmount, _
                                   unresolvedAmount, allocationCount
            writtenCount = writtenCount + 1
            If bufferCount = ANALYSIS_BUFFER_ROWS Then
                FlushAnalysisBuffer wsOut, buffer, bufferCount, nextOutputRow, UNKNOWN_ANALYSIS_LAST_COL
                ReDim buffer(1 To ANALYSIS_BUFFER_ROWS, 1 To UNKNOWN_ANALYSIS_LAST_COL)
                bufferCount = 0
            End If
        End If
    Next i
    If bufferCount > 0 Then _
        FlushAnalysisBuffer wsOut, buffer, bufferCount, nextOutputRow, UNKNOWN_ANALYSIS_LAST_COL
End Sub

Private Function CountUnresolvedUnknownAnalysisRows( _
        ByRef sourceData As Variant, ByRef withdrawalRows() As Long, _
        ByVal withdrawalCount As Long, ByRef depositRows() As Long, _
        ByVal depositCount As Long, ByVal allocationIndex As Object) As Long
    Dim i As Long, allocatedAmount As Double, unresolvedAmount As Double
    Dim allocationCount As Long
    For i = 1 To withdrawalCount
        If TryGetUnknownResidual(sourceData, withdrawalRows(i), False, allocationIndex, _
                                 allocatedAmount, unresolvedAmount, allocationCount) Then _
            CountUnresolvedUnknownAnalysisRows = CountUnresolvedUnknownAnalysisRows + 1
    Next i
    For i = 1 To depositCount
        If TryGetUnknownResidual(sourceData, depositRows(i), True, allocationIndex, _
                                 allocatedAmount, unresolvedAmount, allocationCount) Then _
            CountUnresolvedUnknownAnalysisRows = CountUnresolvedUnknownAnalysisRows + 1
    Next i
End Function

Private Function TryGetUnknownResidual( _
        ByRef sourceData As Variant, ByVal sourceRow As Long, _
        ByVal isDeposit As Boolean, ByVal allocationIndex As Object, _
        ByRef allocatedAmount As Double, ByRef unresolvedAmount As Double, _
        ByRef allocationCount As Long) As Boolean
    Const AMOUNT_EPSILON As Double = 0.0000001
    Dim transactionID As String, directionText As String, sourceAmount As Double
    transactionID = CellText(sourceData(sourceRow, WORK_TX_COL_TRANSACTION_ID))
    If isDeposit Then
        sourceAmount = CDbl(sourceData(sourceRow, OUT_COL_DEPOSIT))
        directionText = ALLOCATION_DIRECTION_DEPOSIT
    Else
        sourceAmount = CDbl(sourceData(sourceRow, OUT_COL_WITHDRAW))
        directionText = ALLOCATION_DIRECTION_WITHDRAW
    End If
    If Not GetTransactionUnresolvedAmountFromIndex( _
            allocationIndex, transactionID, directionText, sourceAmount, _
            allocatedAmount, unresolvedAmount, allocationCount) Then Exit Function
    If Abs((allocatedAmount + unresolvedAmount) - sourceAmount) > _
       Application.Max(AMOUNT_EPSILON, Abs(sourceAmount) * 0.000000001) Then _
        Err.Raise vbObjectError + 4690, "TryGetUnknownResidual", _
                  "配賦額と未追跡残額の合計が元金額と一致しません: " & transactionID
    TryGetUnknownResidual = (unresolvedAmount > AMOUNT_EPSILON)
End Function

Private Sub FillUnknownAnalysisRow(ByRef buffer() As Variant, ByVal bufferRow As Long, _
                                   ByRef sourceData As Variant, ByVal sourceRow As Long, _
                                   ByVal isDeposit As Boolean, ByVal reviews As Object, _
                                   ByVal candidateCountByTx As Object, _
                                   ByVal confirmedCountByTx As Object, ByVal bestRatingByTx As Object, _
                                   ByVal unknownContextByTx As Object, _
                                   ByVal settingsSignature As String, _
                                   ByVal allocatedAmount As Double, _
                                   ByVal unresolvedAmount As Double, _
                                   ByVal allocationCount As Long)
    Dim amountValue As Double, originalAmount As Double
    Dim score As Long, priorityText As String, reasonText As String
    Dim transactionID As String, reviewKey As String, kindText As String
    Dim candidateCount As Long, confirmedCount As Long, bestRating As String
    Dim contextText As String, contextScore As Long, evidenceDigest As String
    Dim reviewValues As Variant
    transactionID = CellText(sourceData(sourceRow, WORK_TX_COL_TRANSACTION_ID))
    If isDeposit Then
        originalAmount = CDbl(sourceData(sourceRow, OUT_COL_DEPOSIT))
        kindText = "原資不明候補"
    Else
        originalAmount = CDbl(sourceData(sourceRow, OUT_COL_WITHDRAW))
        kindText = "使途不明候補"
    End If
    amountValue = unresolvedAmount
    If candidateCountByTx.Exists(transactionID) Then candidateCount = CLng(candidateCountByTx(transactionID))
    If confirmedCountByTx.Exists(transactionID) Then confirmedCount = CLng(confirmedCountByTx(transactionID))
    If bestRatingByTx.Exists(transactionID) Then bestRating = CStr(bestRatingByTx(transactionID))
    contextText = UnknownContextText(unknownContextByTx, transactionID)
    contextScore = UnknownContextScore(unknownContextByTx, transactionID)
    EvaluateUnknownTransaction sourceData, sourceRow, isDeposit, amountValue, candidateCount, _
                               bestRating, contextText, contextScore, score, priorityText, reasonText
    reasonText = AppendAnalysisReason(reasonText, _
                 "元金額 " & Format$(originalAmount, "#,##0.########") & _
                 "、確定配賦 " & Format$(allocatedAmount, "#,##0.########") & _
                 "、未追跡残額 " & Format$(unresolvedAmount, "#,##0.########") & _
                 "（確定配賦+未追跡残額=元金額、配賦記録" & _
                 CStr(allocationCount) & "件）。")
    reviewKey = transactionID & ">" & kindText
    evidenceDigest = AnalysisEvidenceDigest(sourceData, CStr(sourceRow), _
                     "UNKNOWN|" & settingsSignature & "|C=" & CStr(candidateCount) & _
                     "|K=" & CStr(confirmedCount) & "|A=" & _
                     Format$(allocatedAmount, "0.############") & "|U=" & _
                     Format$(unresolvedAmount, "0.############") & _
                     "|R=" & bestRating & "|" & contextText)
    reviewValues = AnalysisReviewValues(reviews, reviewKey, evidenceDigest)
    If CBool(reviewValues(2)) Then
        reasonText = AppendAnalysisReason(reasonText, _
                     "前回確認後に根拠取引または分析条件が変わったため、再確認へ戻しました。")
        reviewValues(1) = AppendAnalysisMemo(CStr(reviewValues(1)), _
                          "[自動] 根拠取引または分析条件の変更を検知し、再確認へ戻しました。")
    End If

    buffer(bufferRow, 1) = priorityText
    buffer(bufferRow, 2) = score
    buffer(bufferRow, 3) = kindText
    buffer(bufferRow, 4) = CDate(sourceData(sourceRow, OUT_COL_DATE))
    buffer(bufferRow, 5) = AnalysisTimeOutputValue(sourceData(sourceRow, OUT_COL_TIME))
    buffer(bufferRow, 6) = AnalysisSingleTimeEvidenceLabel( _
                           sourceData(sourceRow, OUT_COL_TIME))
    buffer(bufferRow, 7) = sourceData(sourceRow, OUT_COL_PERSON)
    buffer(bufferRow, 8) = sourceData(sourceRow, WORK_TX_COL_RELATIONSHIP)
    buffer(bufferRow, 9) = sourceData(sourceRow, OUT_COL_BANK)
    buffer(bufferRow, 10) = sourceData(sourceRow, OUT_COL_BRANCH)
    buffer(bufferRow, 11) = sourceData(sourceRow, OUT_COL_ACCOUNT_TYPE)
    buffer(bufferRow, 12) = sourceData(sourceRow, OUT_COL_ACCOUNT_NO)
    If isDeposit Then buffer(bufferRow, 13) = amountValue Else buffer(bufferRow, 14) = amountValue
    buffer(bufferRow, 15) = sourceData(sourceRow, OUT_COL_SHOP)
    buffer(bufferRow, 16) = sourceData(sourceRow, OUT_COL_MACHINE)
    buffer(bufferRow, 17) = sourceData(sourceRow, OUT_COL_TEKIYO)
    buffer(bufferRow, 18) = CStr(candidateCount) & " / " & CStr(confirmedCount)
    buffer(bufferRow, 19) = bestRating
    buffer(bufferRow, 20) = reasonText
    buffer(bufferRow, 21) = reviewValues(0)
    buffer(bufferRow, 22) = reviewValues(1)
    buffer(bufferRow, 23) = sourceData(sourceRow, WORK_TX_COL_SOURCE)
    buffer(bufferRow, 24) = transactionID
    buffer(bufferRow, 25) = sourceData(sourceRow, WORK_TX_COL_ACCOUNT_ID)
    buffer(bufferRow, 26) = AnalysisStoredKey(reviewKey, evidenceDigest)
End Sub

Private Sub EvaluateUnknownTransaction(ByRef sourceData As Variant, ByVal sourceRow As Long, _
                                       ByVal isDeposit As Boolean, ByVal amountValue As Double, _
                                       ByVal candidateCount As Long, ByVal bestRating As String, _
                                       ByVal contextText As String, ByVal contextScore As Long, _
                                       ByRef score As Long, ByRef priorityText As String, _
                                       ByRef reasonText As String)
    Dim memoText As String, candidateRatingText As String
    Dim transactionDate As Long, inheritanceDate As Long, signedDays As Long
    Dim candidatePriorityCap As Long
    score = 10
    If isDeposit Then
        reasonText = "入金の原資が未確認です。"
    Else
        reasonText = "出金の使途が未確認です。"
    End If

    If amountValue >= 10000000# Then
        score = score + 35
        reasonText = AppendAnalysisReason(reasonText, "金額は1,000万円以上です。")
    ElseIf amountValue >= 1000000# Then
        score = score + 25
        reasonText = AppendAnalysisReason(reasonText, "金額は100万円以上です。")
    ElseIf amountValue >= 100000# Then
        score = score + 15
        reasonText = AppendAnalysisReason(reasonText, "金額は10万円以上です。")
    Else
        score = score + 5
    End If

    memoText = CellText(sourceData(sourceRow, OUT_COL_TEKIYO))
    If Len(memoText) = 0 Then
        score = score + 20
        reasonText = AppendAnalysisReason(reasonText, _
                     "摘要が空欄のため、取引内容を判別できません。")
    Else
        score = score + 5
        reasonText = AppendAnalysisReason(reasonText, _
                     "摘要に記載がありますが、記載だけでは確認済みとして扱いません。")
    End If
    If IsAnalysisRoundAmount(amountValue, 100000#) Then
        score = score + 10
        reasonText = AppendAnalysisReason(reasonText, "10万円単位の金額です。")
    ElseIf IsAnalysisRoundAmount(amountValue, 10000#) Then
        score = score + 5
        reasonText = AppendAnalysisReason(reasonText, "1万円単位の金額です。")
    End If
    If candidateCount > 0 Then
        candidateRatingText = bestRating
        If Len(candidateRatingText) = 0 Then candidateRatingText = "評価未設定"
        If bestRating = "高" Or _
           InStr(1, bestRating, "手動", vbTextCompare) = 1 Then
            score = score - 10
            candidatePriorityCap = 64
        ElseIf bestRating = "中" Then
            score = score - 5
            candidatePriorityCap = 64
        Else
            candidatePriorityCap = 0
        End If
        reasonText = AppendAnalysisReason(reasonText, _
                     "資金シフト・フロー候補が別表に" & CStr(candidateCount) & _
                     "件あります。最高評価は「" & candidateRatingText & "」です。")
        reasonText = AppendAnalysisReason(reasonText, _
                     "候補が未確認のため本表にも残していますが、重複して高優先にはしていません。")
    Else
        reasonText = AppendAnalysisReason(reasonText, _
                     "入力済み取引の中には対応候補がありません。未収載取引がないことを意味するものではありません。")
    End If
    If Len(contextText) > 0 Then
        score = score + contextScore
        reasonText = AppendAnalysisReason(reasonText, contextText & "。")
    End If
    If IsDate(mAnalysisInheritanceDate) Then
        transactionDate = CLng(VBA.DateValue(CDate(sourceData(sourceRow, OUT_COL_DATE))))
        inheritanceDate = CLng(VBA.DateValue(CDate(mAnalysisInheritanceDate)))
        signedDays = transactionDate - inheritanceDate
        If Abs(signedDays) <= 30 Then
            score = score + 15
            reasonText = AppendAnalysisReason(reasonText, "相続開始日前後30日以内の取引です。")
        ElseIf Abs(signedDays) <= 90 Then
            score = score + 8
            reasonText = AppendAnalysisReason(reasonText, "相続開始日前後90日以内の取引です。")
        ElseIf Abs(signedDays) <= 365 Then
            score = score + 3
            reasonText = AppendAnalysisReason(reasonText, "相続開始日前後365日以内の取引です。")
        End If
        If signedDays >= 0 And signedDays <= 365 Then
            score = score + 5
            If isDeposit Then
                reasonText = AppendAnalysisReason(reasonText, _
                             "相続開始後の入金であるため、原資を個別に確認してください。")
            Else
                reasonText = AppendAnalysisReason(reasonText, _
                             "相続開始後の出金であるため、使途を個別に確認してください。")
            End If
        End If
    End If
    If Not HasText(sourceData(sourceRow, OUT_COL_TIME)) Then _
        reasonText = AppendAnalysisReason(reasonText, _
                     "時刻記載なしのため、同日取引との前後関係は判定できません。")
    If candidatePriorityCap > 0 And score > candidatePriorityCap Then score = candidatePriorityCap
    If score < 0 Then score = 0
    If score > 100 Then score = 100
    If score >= 65 Then
        priorityText = "高"
    ElseIf score >= 45 Then
        priorityText = "中"
    Else
        priorityText = "通常"
    End If
End Sub

Private Function IsAnalysisRoundAmount(ByVal amountValue As Double, ByVal unitValue As Double) As Boolean
    Dim quotient As Double
    If unitValue <= 0 Then Exit Function
    quotient = amountValue / unitValue
    IsAnalysisRoundAmount = (Abs(quotient - Fix(quotient)) < 0.0000001)
End Function

Private Function BuildUnknownContextIndex( _
        ByRef sourceData As Variant, ByRef withdrawalRows() As Long, _
        ByVal withdrawalCount As Long, ByRef depositRows() As Long, _
        ByVal depositCount As Long) As Object
    Dim contextIndex As Object, amountCounts As Object, dayAccountCounts As Object
    Dim operationCounts As Object, cashCounts As Object
    Dim allRows() As Long, allCount As Long, i As Long
    Set contextIndex = CreateObject("Scripting.Dictionary")
    Set amountCounts = CreateObject("Scripting.Dictionary")
    Set dayAccountCounts = CreateObject("Scripting.Dictionary")
    Set operationCounts = CreateObject("Scripting.Dictionary")
    Set cashCounts = CreateObject("Scripting.Dictionary")
    contextIndex.CompareMode = vbTextCompare
    amountCounts.CompareMode = vbTextCompare
    dayAccountCounts.CompareMode = vbTextCompare
    operationCounts.CompareMode = vbTextCompare
    cashCounts.CompareMode = vbTextCompare

    allCount = withdrawalCount + depositCount
    If allCount = 0 Then
        Set BuildUnknownContextIndex = contextIndex
        Exit Function
    End If
    ReDim allRows(1 To allCount)
    For i = 1 To withdrawalCount
        allRows(i) = withdrawalRows(i)
        RegisterUnknownContextCount sourceData, withdrawalRows(i), False, amountCounts, _
                                    dayAccountCounts, operationCounts, cashCounts
    Next i
    For i = 1 To depositCount
        allRows(withdrawalCount + i) = depositRows(i)
        RegisterUnknownContextCount sourceData, depositRows(i), True, amountCounts, _
                                    dayAccountCounts, operationCounts, cashCounts
    Next i
    For i = 1 To allCount
        AddUnknownSimpleContext sourceData, allRows(i), contextIndex, amountCounts, _
                                dayAccountCounts, operationCounts, cashCounts
    Next i
    AddUnknownRollingContext sourceData, allRows, allCount, contextIndex
    Set BuildUnknownContextIndex = contextIndex
End Function

Private Sub RegisterUnknownContextCount( _
        ByRef sourceData As Variant, ByVal sourceRow As Long, ByVal isDeposit As Boolean, _
        ByVal amountCounts As Object, ByVal dayAccountCounts As Object, _
        ByVal operationCounts As Object, ByVal cashCounts As Object)
    Dim operationKey As String, cashKey As String
    IncrementAnalysisCount amountCounts, UnknownAmountContextKey(sourceData, sourceRow, isDeposit)
    IncrementAnalysisCount dayAccountCounts, UnknownDayAccountContextKey(sourceData, sourceRow, isDeposit)
    operationKey = UnknownOperationContextKey(sourceData, sourceRow)
    If Len(operationKey) > 0 Then IncrementAnalysisCount operationCounts, operationKey
    cashKey = UnknownCashContextKey(sourceData, sourceRow)
    If Len(cashKey) > 0 Then IncrementAnalysisCount cashCounts, cashKey
End Sub

Private Sub AddUnknownSimpleContext( _
        ByRef sourceData As Variant, ByVal sourceRow As Long, ByVal contextIndex As Object, _
        ByVal amountCounts As Object, ByVal dayAccountCounts As Object, _
        ByVal operationCounts As Object, ByVal cashCounts As Object)
    Dim transactionID As String, keyText As String, itemCount As Long
    Dim isDeposit As Boolean
    transactionID = CellText(sourceData(sourceRow, WORK_TX_COL_TRANSACTION_ID))
    If Len(transactionID) = 0 Then Exit Sub
    isDeposit = HasText(sourceData(sourceRow, OUT_COL_DEPOSIT))

    keyText = UnknownAmountContextKey(sourceData, sourceRow, isDeposit)
    itemCount = CLng(amountCounts(keyText))
    If itemCount >= 2 Then _
        AddUnknownContextTag contextIndex, transactionID, _
            "入力範囲内で同額・同種の取引" & CStr(itemCount) & "件", 4

    keyText = UnknownDayAccountContextKey(sourceData, sourceRow, isDeposit)
    itemCount = CLng(dayAccountCounts(keyText))
    If itemCount >= 2 Then _
        AddUnknownContextTag contextIndex, transactionID, _
            "同日・同口座の同種取引" & CStr(itemCount) & "件", 4

    keyText = UnknownOperationContextKey(sourceData, sourceRow)
    If Len(keyText) > 0 Then
        itemCount = CLng(operationCounts(keyText))
        If itemCount >= 2 Then _
            AddUnknownContextTag contextIndex, transactionID, _
                "同日・同銀行・同取扱店/機番の取引" & CStr(itemCount) & "件", 6
    End If

    keyText = UnknownCashContextKey(sourceData, sourceRow)
    If Len(keyText) > 0 Then
        itemCount = CLng(cashCounts(keyText))
        If itemCount >= 2 Then _
            AddUnknownContextTag contextIndex, transactionID, _
                "同日・同人物・同銀行の窓口型取引" & CStr(itemCount) & "件", 6
    End If
End Sub

Private Sub AddUnknownRollingContext(ByRef sourceData As Variant, ByRef allRows() As Long, _
                                     ByVal allCount As Long, ByVal contextIndex As Object)
    Dim accountKeys() As String, dates() As Long, rows() As Long
    Dim groupStart As Long, groupEnd As Long, groupCount As Long
    Dim groupDates() As Long, depositAmounts() As Double, withdrawalAmounts() As Double
    Dim depositCounts() As Long, withdrawalCounts() As Long
    Dim i As Long, p As Long, sourceRow As Long, currentDate As Long
    Dim lower30 As Long, lower90 As Long, lower365 As Long
    Dim futureStart As Long, upper30 As Long, upper90 As Long, upper365 As Long
    Dim sameCount As Long, oppositeCount As Long, sameAmount As Double, oppositeAmount As Double
    Dim transactionID As String, oppositeLabel As String, isDeposit As Boolean
    ReDim accountKeys(1 To allCount)
    ReDim dates(1 To allCount)
    ReDim rows(1 To allCount)
    For i = 1 To allCount
        rows(i) = allRows(i)
        accountKeys(i) = UCase$(CellText(sourceData(allRows(i), WORK_TX_COL_ACCOUNT_ID)))
        dates(i) = CLng(VBA.DateValue(CDate(sourceData(allRows(i), OUT_COL_DATE))))
    Next i
    If allCount > 1 Then QuickSortUnknownContextRows accountKeys, dates, rows, 1, allCount

    groupStart = 1
    Do While groupStart <= allCount
        groupEnd = groupStart
        Do While groupEnd < allCount
            If StrComp(accountKeys(groupEnd + 1), accountKeys(groupStart), vbTextCompare) <> 0 Then Exit Do
            groupEnd = groupEnd + 1
        Loop
        groupCount = groupEnd - groupStart + 1
        ReDim groupDates(1 To groupCount)
        ReDim depositAmounts(0 To groupCount)
        ReDim withdrawalAmounts(0 To groupCount)
        ReDim depositCounts(0 To groupCount)
        ReDim withdrawalCounts(0 To groupCount)
        For p = 1 To groupCount
            sourceRow = rows(groupStart + p - 1)
            groupDates(p) = dates(groupStart + p - 1)
            depositAmounts(p) = depositAmounts(p - 1)
            withdrawalAmounts(p) = withdrawalAmounts(p - 1)
            depositCounts(p) = depositCounts(p - 1)
            withdrawalCounts(p) = withdrawalCounts(p - 1)
            If HasText(sourceData(sourceRow, OUT_COL_DEPOSIT)) Then
                depositAmounts(p) = depositAmounts(p) + CDbl(sourceData(sourceRow, OUT_COL_DEPOSIT))
                depositCounts(p) = depositCounts(p) + 1
            Else
                withdrawalAmounts(p) = withdrawalAmounts(p) + CDbl(sourceData(sourceRow, OUT_COL_WITHDRAW))
                withdrawalCounts(p) = withdrawalCounts(p) + 1
            End If
        Next p

        For p = 1 To groupCount
            sourceRow = rows(groupStart + p - 1)
            transactionID = CellText(sourceData(sourceRow, WORK_TX_COL_TRANSACTION_ID))
            currentDate = groupDates(p)
            isDeposit = HasText(sourceData(sourceRow, OUT_COL_DEPOSIT))
            lower30 = LowerBoundUnknownContextDate(groupDates, groupCount, currentDate - 29)
            lower90 = LowerBoundUnknownContextDate(groupDates, groupCount, currentDate - 89)
            lower365 = LowerBoundUnknownContextDate(groupDates, groupCount, currentDate - 364)
            If isDeposit Then
                sameCount = depositCounts(p) - depositCounts(lower30 - 1)
                sameAmount = depositAmounts(p) - depositAmounts(lower30 - 1)
            Else
                sameCount = withdrawalCounts(p) - withdrawalCounts(lower30 - 1)
                sameAmount = withdrawalAmounts(p) - withdrawalAmounts(lower30 - 1)
            End If
            If sameCount >= 2 Then
                AddUnknownContextTag contextIndex, transactionID, _
                    "直近30日・同口座の同種取引" & CStr(sameCount) & "件計" & _
                    Format$(sameAmount, "#,##0.########") & "円", 6
            Else
                If isDeposit Then
                    sameCount = depositCounts(p) - depositCounts(lower90 - 1)
                    sameAmount = depositAmounts(p) - depositAmounts(lower90 - 1)
                Else
                    sameCount = withdrawalCounts(p) - withdrawalCounts(lower90 - 1)
                    sameAmount = withdrawalAmounts(p) - withdrawalAmounts(lower90 - 1)
                End If
                If sameCount >= 3 Then
                    AddUnknownContextTag contextIndex, transactionID, _
                        "直近90日・同口座の同種取引" & CStr(sameCount) & "件計" & _
                        Format$(sameAmount, "#,##0.########") & "円", 5
                Else
                    If isDeposit Then
                        sameCount = depositCounts(p) - depositCounts(lower365 - 1)
                        sameAmount = depositAmounts(p) - depositAmounts(lower365 - 1)
                    Else
                        sameCount = withdrawalCounts(p) - withdrawalCounts(lower365 - 1)
                        sameAmount = withdrawalAmounts(p) - withdrawalAmounts(lower365 - 1)
                    End If
                    If sameCount >= 4 Then _
                        AddUnknownContextTag contextIndex, transactionID, _
                            "直近365日・同口座の同種取引" & CStr(sameCount) & "件計" & _
                            Format$(sameAmount, "#,##0.########") & "円", 4
                End If
            End If

            '同日時刻が不明な取引を無理に並べず、翌日以降だけを後続として集計する。
            futureStart = UpperBoundUnknownContextDate(groupDates, groupCount, currentDate) + 1
            If futureStart <= groupCount Then
                upper30 = UpperBoundUnknownContextDate(groupDates, groupCount, currentDate + 30)
                upper90 = UpperBoundUnknownContextDate(groupDates, groupCount, currentDate + 90)
                upper365 = UpperBoundUnknownContextDate(groupDates, groupCount, currentDate + 365)
                If upper30 < futureStart Then upper30 = futureStart - 1
                If upper90 < futureStart Then upper90 = futureStart - 1
                If upper365 < futureStart Then upper365 = futureStart - 1
                If isDeposit Then
                    oppositeLabel = "出金"
                    oppositeCount = withdrawalCounts(upper30) - withdrawalCounts(futureStart - 1)
                    oppositeAmount = withdrawalAmounts(upper30) - withdrawalAmounts(futureStart - 1)
                Else
                    oppositeLabel = "入金"
                    oppositeCount = depositCounts(upper30) - depositCounts(futureStart - 1)
                    oppositeAmount = depositAmounts(upper30) - depositAmounts(futureStart - 1)
                End If
                If oppositeCount > 0 Then
                    AddUnknownContextTag contextIndex, transactionID, _
                        "同口座の翌日以降30日以内に" & oppositeLabel & CStr(oppositeCount) & _
                        "件計" & Format$(oppositeAmount, "#,##0.########") & "円", 6
                Else
                    If isDeposit Then
                        oppositeCount = withdrawalCounts(upper90) - withdrawalCounts(futureStart - 1)
                        oppositeAmount = withdrawalAmounts(upper90) - withdrawalAmounts(futureStart - 1)
                    Else
                        oppositeCount = depositCounts(upper90) - depositCounts(futureStart - 1)
                        oppositeAmount = depositAmounts(upper90) - depositAmounts(futureStart - 1)
                    End If
                    If oppositeCount > 0 Then
                        AddUnknownContextTag contextIndex, transactionID, _
                            "同口座の翌日以降90日以内に" & oppositeLabel & CStr(oppositeCount) & _
                            "件計" & Format$(oppositeAmount, "#,##0.########") & "円", 4
                    Else
                        If isDeposit Then
                            oppositeCount = withdrawalCounts(upper365) - withdrawalCounts(futureStart - 1)
                            oppositeAmount = withdrawalAmounts(upper365) - withdrawalAmounts(futureStart - 1)
                        Else
                            oppositeCount = depositCounts(upper365) - depositCounts(futureStart - 1)
                            oppositeAmount = depositAmounts(upper365) - depositAmounts(futureStart - 1)
                        End If
                        If oppositeCount > 0 Then _
                            AddUnknownContextTag contextIndex, transactionID, _
                                "同口座の翌日以降365日以内に" & oppositeLabel & CStr(oppositeCount) & _
                                "件計" & Format$(oppositeAmount, "#,##0.########") & "円", 3
                    End If
                End If
            End If
        Next p
        groupStart = groupEnd + 1
    Loop
End Sub

Private Function UnknownAmountContextKey(ByRef sourceData As Variant, ByVal sourceRow As Long, _
                                         ByVal isDeposit As Boolean) As String
    Dim amountValue As Double, sideText As String
    If isDeposit Then
        amountValue = CDbl(sourceData(sourceRow, OUT_COL_DEPOSIT))
        sideText = "D"
    Else
        amountValue = CDbl(sourceData(sourceRow, OUT_COL_WITHDRAW))
        sideText = "W"
    End If
    UnknownAmountContextKey = sideText & "|" & Trim$(Str$(amountValue))
End Function

Private Function UnknownDayAccountContextKey(ByRef sourceData As Variant, ByVal sourceRow As Long, _
                                             ByVal isDeposit As Boolean) As String
    UnknownDayAccountContextKey = IIf(isDeposit, "D|", "W|") & _
        UCase$(CellText(sourceData(sourceRow, WORK_TX_COL_ACCOUNT_ID))) & "|" & _
        CStr(CLng(VBA.DateValue(CDate(sourceData(sourceRow, OUT_COL_DATE)))))
End Function

Private Function UnknownOperationContextKey(ByRef sourceData As Variant, _
                                            ByVal sourceRow As Long) As String
    Dim shopText As String, machineText As String
    shopText = UCase$(CellText(sourceData(sourceRow, OUT_COL_SHOP)))
    machineText = UCase$(CellText(sourceData(sourceRow, OUT_COL_MACHINE)))
    If Len(shopText) = 0 And Len(machineText) = 0 Then Exit Function
    UnknownOperationContextKey = UCase$(CellText(sourceData(sourceRow, OUT_COL_BANK))) & "|" & _
        CStr(CLng(VBA.DateValue(CDate(sourceData(sourceRow, OUT_COL_DATE))))) & "|" & _
        shopText & "|" & machineText
End Function

Private Function UnknownCashContextKey(ByRef sourceData As Variant, ByVal sourceRow As Long) As String
    Dim personKey As String
    If HasText(sourceData(sourceRow, OUT_COL_TEKIYO)) Or _
       HasText(sourceData(sourceRow, OUT_COL_SHOP)) Or _
       HasText(sourceData(sourceRow, OUT_COL_MACHINE)) Then Exit Function
    personKey = CellText(sourceData(sourceRow, WORK_TX_COL_PERSON_ID))
    If Len(personKey) = 0 Then _
        Err.Raise vbObjectError + 4638, "UnknownCashContextKey", _
                  "W_取引 " & CStr(sourceRow + 1) & _
                  "行目に人物IDがありません。氏名では代替しません。"
    If Not IsInternalIdValue(personKey, "P") Then _
        Err.Raise vbObjectError + 4639, "UnknownCashContextKey", _
                  "W_取引 " & CStr(sourceRow + 1) & _
                  "行目の人物ID形式が不正です: " & personKey
    UnknownCashContextKey = UCase$(CellText(sourceData(sourceRow, OUT_COL_BANK))) & "|" & _
        UCase$(personKey) & "|" & _
        CStr(CLng(VBA.DateValue(CDate(sourceData(sourceRow, OUT_COL_DATE)))))
End Function

Private Sub IncrementAnalysisCount(ByVal values As Object, ByVal keyText As String)
    If values.Exists(keyText) Then
        values(keyText) = CLng(values(keyText)) + 1
    Else
        values.Add keyText, 1
    End If
End Sub

Private Sub AddUnknownContextTag(ByVal contextIndex As Object, ByVal transactionID As String, _
                                 ByVal tagText As String, ByVal scoreIncrement As Long)
    Dim textKey As String, scoreKey As String, currentText As String, proposedText As String
    textKey = "T|" & transactionID
    scoreKey = "S|" & transactionID
    If contextIndex.Exists(textKey) Then currentText = CStr(contextIndex(textKey))
    If InStr(1, currentText, tagText, vbTextCompare) > 0 Then Exit Sub
    If Len(currentText) = 0 Then proposedText = tagText Else proposedText = currentText & "、" & tagText
    '表示できない根拠だけで優先度が上がると説明不能になるため、
    '理由文の上限を超えるタグはスコアにも反映しない。
    If Len(proposedText) > ANALYSIS_CONTEXT_TEXT_MAX Then Exit Sub
    If contextIndex.Exists(textKey) Then
        contextIndex(textKey) = proposedText
    Else
        contextIndex.Add textKey, proposedText
    End If
    If contextIndex.Exists(scoreKey) Then
        contextIndex(scoreKey) = CLng(contextIndex(scoreKey)) + scoreIncrement
    Else
        contextIndex.Add scoreKey, scoreIncrement
    End If
    If CLng(contextIndex(scoreKey)) > 25 Then contextIndex(scoreKey) = 25
End Sub

Private Function UnknownContextText(ByVal contextIndex As Object, ByVal transactionID As String) As String
    If Not contextIndex Is Nothing Then
        If contextIndex.Exists("T|" & transactionID) Then _
            UnknownContextText = CStr(contextIndex("T|" & transactionID))
    End If
End Function

Private Function UnknownContextScore(ByVal contextIndex As Object, ByVal transactionID As String) As Long
    If Not contextIndex Is Nothing Then
        If contextIndex.Exists("S|" & transactionID) Then _
            UnknownContextScore = CLng(contextIndex("S|" & transactionID))
    End If
End Function

Private Function LowerBoundUnknownContextDate(ByRef dates() As Long, ByVal itemCount As Long, _
                                              ByVal targetDate As Long) As Long
    Dim low As Long, high As Long, mid As Long
    low = 1: high = itemCount + 1
    Do While low < high
        mid = low + (high - low) \ 2
        If mid <= itemCount And dates(mid) < targetDate Then low = mid + 1 Else high = mid
    Loop
    LowerBoundUnknownContextDate = low
End Function

Private Function UpperBoundUnknownContextDate(ByRef dates() As Long, ByVal itemCount As Long, _
                                              ByVal targetDate As Long) As Long
    Dim low As Long, high As Long, mid As Long
    low = 1: high = itemCount + 1
    Do While low < high
        mid = low + (high - low) \ 2
        If mid <= itemCount And dates(mid) <= targetDate Then low = mid + 1 Else high = mid
    Loop
    UpperBoundUnknownContextDate = low - 1
End Function

Private Sub QuickSortUnknownContextRows(ByRef accountKeys() As String, ByRef dates() As Long, _
                                        ByRef rows() As Long, ByVal firstIndex As Long, _
                                        ByVal lastIndex As Long)
    Dim low As Long, high As Long, pivotIndex As Long
    Dim pivotKey As String, pivotDate As Long, pivotRow As Long
    Dim tempKey As String, tempDate As Long, tempRow As Long
    low = firstIndex: high = lastIndex
    pivotIndex = (firstIndex + lastIndex) \ 2
    pivotKey = accountKeys(pivotIndex): pivotDate = dates(pivotIndex): pivotRow = rows(pivotIndex)
    Do While low <= high
        Do While CompareUnknownContextRows(accountKeys(low), dates(low), rows(low), _
                                           pivotKey, pivotDate, pivotRow) < 0
            low = low + 1
        Loop
        Do While CompareUnknownContextRows(accountKeys(high), dates(high), rows(high), _
                                           pivotKey, pivotDate, pivotRow) > 0
            high = high - 1
        Loop
        If low <= high Then
            tempKey = accountKeys(low): accountKeys(low) = accountKeys(high): accountKeys(high) = tempKey
            tempDate = dates(low): dates(low) = dates(high): dates(high) = tempDate
            tempRow = rows(low): rows(low) = rows(high): rows(high) = tempRow
            low = low + 1: high = high - 1
        End If
    Loop
    If firstIndex < high Then QuickSortUnknownContextRows accountKeys, dates, rows, firstIndex, high
    If low < lastIndex Then QuickSortUnknownContextRows accountKeys, dates, rows, low, lastIndex
End Sub

Private Function CompareUnknownContextRows(ByVal firstKey As String, ByVal firstDate As Long, _
                                           ByVal firstRow As Long, ByVal secondKey As String, _
                                           ByVal secondDate As Long, ByVal secondRow As Long) As Long
    CompareUnknownContextRows = StrComp(firstKey, secondKey, vbTextCompare)
    If CompareUnknownContextRows <> 0 Then Exit Function
    If firstDate < secondDate Then
        CompareUnknownContextRows = -1
    ElseIf firstDate > secondDate Then
        CompareUnknownContextRows = 1
    ElseIf firstRow < secondRow Then
        CompareUnknownContextRows = -1
    ElseIf firstRow > secondRow Then
        CompareUnknownContextRows = 1
    End If
End Function

Public Function AnalysisSettingsSignature(ByVal minAmount As Double, ByVal dayWindow As Long, _
                                          ByVal absoluteTolerance As Double, _
                                          ByVal rateTolerance As Double) As String
    AnalysisSettingsSignature = "MIN=" & Trim$(Str$(minAmount)) & "|DAY=" & CStr(dayWindow) & _
                                "|ABS=" & Trim$(Str$(absoluteTolerance)) & _
                                "|RATE=" & Trim$(Str$(rateTolerance))
    If IsDate(mAnalysisInheritanceDate) Then _
        AnalysisSettingsSignature = AnalysisSettingsSignature & "|INH=" & _
                                    Format$(CDate(mAnalysisInheritanceDate), "yyyymmdd")
End Function

Public Function AnalysisEvidenceDigest(ByRef sourceData As Variant, ByVal rowList As String, _
                                       ByVal contextText As String) As String
    Dim rowParts As Variant, rowTexts() As String, item As Variant
    Dim itemCount As Long, i As Long, j As Long, tempText As String, rawText As String
    If Len(rowList) > 0 Then
        rowParts = Split(rowList, ";")
        ReDim rowTexts(1 To UBound(rowParts) - LBound(rowParts) + 1)
        For Each item In rowParts
            If Len(Trim$(CStr(item))) > 0 Then
                itemCount = itemCount + 1
                rowTexts(itemCount) = AnalysisRowEvidenceDigest(sourceData, CLng(item))
            End If
        Next item
    End If
    For i = 2 To itemCount
        tempText = rowTexts(i)
        j = i - 1
        Do While j >= 1
            If StrComp(rowTexts(j), tempText, vbBinaryCompare) <= 0 Then Exit Do
            rowTexts(j + 1) = rowTexts(j)
            j = j - 1
        Loop
        rowTexts(j + 1) = tempText
    Next i
    rawText = CStr(Len(contextText)) & ":" & contextText
    For i = 1 To itemCount
        rawText = rawText & "|" & CStr(Len(rowTexts(i))) & ":" & rowTexts(i)
    Next i
    AnalysisEvidenceDigest = AnalysisHashPart(rawText, 104729#, 131#) & "-" & _
                             AnalysisHashPart(rawText, 130363#, 137#)
End Function

Private Function AnalysisRowEvidenceDigest(ByRef sourceData As Variant, _
                                           ByVal sourceRow As Long) As String
    Dim transactionID As String, rowText As String
    transactionID = CellText(sourceData(sourceRow, WORK_TX_COL_TRANSACTION_ID))
    If mAnalysisRowEvidenceCache Is Nothing Then
        Set mAnalysisRowEvidenceCache = CreateObject("Scripting.Dictionary")
        mAnalysisRowEvidenceCache.CompareMode = vbTextCompare
    End If
    If Len(transactionID) > 0 Then
        If mAnalysisRowEvidenceCache.Exists(transactionID) Then
            AnalysisRowEvidenceDigest = CStr(mAnalysisRowEvidenceCache(transactionID))
            Exit Function
        End If
    End If
    rowText = AnalysisRowEvidenceText(sourceData, sourceRow)
    AnalysisRowEvidenceDigest = AnalysisHashPart(rowText, 15485863#, 139#) & "-" & _
                                AnalysisHashPart(rowText, 32452843#, 149#)
    If Len(transactionID) > 0 Then _
        mAnalysisRowEvidenceCache.Add transactionID, AnalysisRowEvidenceDigest
End Function

Private Sub ResetAnalysisEvidenceCache()
    Set mAnalysisRowEvidenceCache = Nothing
End Sub

Private Function AnalysisRowEvidenceText(ByRef sourceData As Variant, ByVal sourceRow As Long) As String
    Dim c As Long, valueText As String, resultText As String
    For c = 1 To UBound(sourceData, 2)
        valueText = AnalysisEvidenceValue(sourceData(sourceRow, c))
        resultText = resultText & CStr(Len(valueText)) & ":" & valueText & "|"
    Next c
    AnalysisRowEvidenceText = resultText
End Function

Private Function AnalysisEvidenceValue(ByVal valueIn As Variant) As String
    If IsError(valueIn) Then
        AnalysisEvidenceValue = "#ERROR"
    ElseIf IsEmpty(valueIn) Or IsNull(valueIn) Then
        AnalysisEvidenceValue = vbNullString
    ElseIf VarType(valueIn) = vbBoolean Then
        If CBool(valueIn) Then AnalysisEvidenceValue = "TRUE" Else AnalysisEvidenceValue = "FALSE"
    ElseIf IsNumeric(valueIn) Then
        AnalysisEvidenceValue = Trim$(Str$(CDbl(valueIn)))
    Else
        AnalysisEvidenceValue = CStr(valueIn)
    End If
End Function

Private Function AnalysisHashPart(ByVal rawText As String, ByVal seedValue As Double, _
                                  ByVal multiplier As Double) As String
    Const HASH_MODULUS As Double = 2147483629#
    Dim hashValue As Double, i As Long, codeValue As Long, hexText As String
    hashValue = seedValue
    For i = 1 To Len(rawText)
        codeValue = AscW(Mid$(rawText, i, 1))
        If codeValue < 0 Then codeValue = codeValue + 65536
        hashValue = hashValue * multiplier + CDbl(codeValue)
        hashValue = hashValue - Fix(hashValue / HASH_MODULUS) * HASH_MODULUS
    Next i
    hexText = Hex$(CLng(hashValue))
    AnalysisHashPart = Right$("00000000" & hexText, 8)
End Function

Public Function AnalysisStoredKey(ByVal baseKey As String, ByVal evidenceDigest As String) As String
    AnalysisStoredKey = baseKey & ANALYSIS_EVIDENCE_MARKER & evidenceDigest
End Function

Public Function AnalysisBaseKey(ByVal storedKey As String, ByRef evidenceDigest As String) As String
    Dim markerPosition As Long
    markerPosition = InStrRev(storedKey, ANALYSIS_EVIDENCE_MARKER, -1, vbBinaryCompare)
    If markerPosition > 0 Then
        AnalysisBaseKey = Left$(storedKey, markerPosition - 1)
        evidenceDigest = Mid$(storedKey, markerPosition + Len(ANALYSIS_EVIDENCE_MARKER))
    Else
        AnalysisBaseKey = storedKey
        evidenceDigest = vbNullString
    End If
End Function

Public Function AnalysisMaximumCandidateCount(ByVal candidateCountByTx As Object, _
                                              ByVal transactionIDs As String) As Long
    Dim items As Variant, item As Variant, transactionID As String, itemCount As Long
    If candidateCountByTx Is Nothing Or Len(transactionIDs) = 0 Then Exit Function
    items = Split(transactionIDs, ";")
    For Each item In items
        transactionID = Trim$(CStr(item))
        If candidateCountByTx.Exists(transactionID) Then
            itemCount = CLng(candidateCountByTx(transactionID))
            If itemCount > AnalysisMaximumCandidateCount Then _
                AnalysisMaximumCandidateCount = itemCount
        End If
    Next item
End Function

Public Function AppendAnalysisReason(ByVal currentText As String, ByVal additionalText As String) As String
    If Len(additionalText) = 0 Or InStr(1, currentText, additionalText, vbTextCompare) > 0 Then
        AppendAnalysisReason = currentText
    ElseIf Len(currentText) = 0 Then
        AppendAnalysisReason = additionalText
    Else
        AppendAnalysisReason = Trim$(currentText) & " " & additionalText
    End If
End Function

Public Function AppendAnalysisMemo(ByVal currentText As String, ByVal additionalText As String) As String
    Dim separatorText As String, availableChars As Long
    If Len(additionalText) = 0 Or InStr(1, currentText, additionalText, vbTextCompare) > 0 Then
        AppendAnalysisMemo = currentText
        Exit Function
    End If
    If Len(currentText) > 0 Then separatorText = vbLf
    availableChars = ANALYSIS_REVIEW_MEMO_MAX - Len(currentText) - Len(separatorText)
    If availableChars <= 0 Then
        AppendAnalysisMemo = currentText
    Else
        AppendAnalysisMemo = currentText & separatorText & Left$(additionalText, availableChars)
    End If
End Function

'現行の全取引をscope行として同じbatchへ含め、確認済みの自動・手動候補を
'取引別Allocationへ変換する。候補間の過剰配賦は共通元帳のatomic検証へ委ねる。
Public Sub RebuildCurrentAnalysisAllocationPlan()
    Dim wsSource As Worksheet, sourceData As Variant
    Dim lastR As Long, sourceRowCount As Long
    If Not SheetExists(SH_WORK_TX) Or Not SheetExists(SH_ANALYSIS_SHIFT) Or _
       Not SheetExists(SH_ANALYSIS_FLOW) Then _
        Err.Raise vbObjectError + 4691, "RebuildCurrentAnalysisAllocationPlan", _
                  "配賦計画の再構築に必要な既存表がありません。"
    Set wsSource = GetSheet(SH_WORK_TX)
    lastR = LastDataRowInColumns(wsSource, 1, WORK_TX_COL_PERSON_ID)
    If lastR < 2 Then
        ClearAnalysisAllocationPlan
        Exit Sub
    End If
    sourceData = wsSource.Range(wsSource.Cells(2, 1), _
                                wsSource.Cells(lastR, WORK_TX_COL_PERSON_ID)).Value2
    sourceRowCount = UBound(sourceData, 1)
    CommitCurrentAnalysisAllocations sourceData, sourceRowCount, _
        GetSheet(SH_ANALYSIS_SHIFT), GetSheet(SH_ANALYSIS_FLOW)
End Sub

Private Sub CommitCurrentAnalysisAllocations( _
        ByRef sourceData As Variant, ByVal sourceRowCount As Long, _
        ByVal wsShift As Worksheet, ByVal wsFlow As Worksheet)
    Dim allocationRows As New Collection
    Dim transactionIndex As Object, manualIndex As Object
    Dim batchRows() As Variant, rowValues As Variant
    Dim r As Long, c As Long, sourceAmount As Double
    Dim transactionID As String, directionText As String
    If sourceRowCount <= 0 Then
        '全取引削除後の再分析でも旧配賦を残さない。空集合へのfull replacement。
        ClearAnalysisAllocationPlan
        Exit Sub
    End If
    Set transactionIndex = BuildAnalysisAllocationTransactionIndex(sourceData, sourceRowCount)
    Set manualIndex = CaptureManualFlowAllocationIndex()

    'scope行により、対象外へ戻した候補や消えた候補の旧active配賦も現在取引単位で置換する。
    For r = 1 To sourceRowCount
        transactionID = CellText(sourceData(r, WORK_TX_COL_TRANSACTION_ID))
        If CDbl(sourceData(r, OUT_COL_WITHDRAW)) > 0# Then
            sourceAmount = CDbl(sourceData(r, OUT_COL_WITHDRAW))
            directionText = ALLOCATION_DIRECTION_WITHDRAW
        ElseIf CDbl(sourceData(r, OUT_COL_DEPOSIT)) > 0# Then
            sourceAmount = CDbl(sourceData(r, OUT_COL_DEPOSIT))
            directionText = ALLOCATION_DIRECTION_DEPOSIT
        Else
            GoTo NextScopeRow
        End If
        AddAnalysisAllocationRow allocationRows, _
            "__SCOPE__", transactionID, directionText, 0#, _
            ALLOCATION_STATUS_UNREVIEWED, vbNullString, _
            ALLOCATION_SOURCE_SCOPE, sourceAmount
NextScopeRow:
    Next r

    CollectShiftAllocationRows wsShift, sourceData, transactionIndex, allocationRows
    CollectFlowAllocationRows wsFlow, sourceData, transactionIndex, manualIndex, allocationRows
    If allocationRows.Count = 0 Then
        '取引行があっても配賦対象方向が0件なら、空集合へのfull replacementとする。
        ClearAnalysisAllocationPlan
        Exit Sub
    End If
    ReDim batchRows(1 To allocationRows.Count, 1 To 8)
    For r = 1 To allocationRows.Count
        rowValues = allocationRows(r)
        For c = 1 To 8
            batchRows(r, c) = rowValues(c - 1)
        Next c
    Next r
    ReplaceAllocationPlanForTransactions batchRows, "ANALYSIS", _
                                         replaceEntireLedger:=True
    ValidateCurrentAnalysisAllocationCoverage sourceData, sourceRowCount
End Sub

Private Function BuildAnalysisAllocationTransactionIndex( _
        ByRef sourceData As Variant, ByVal sourceRowCount As Long) As Object
    Dim result As Object, r As Long, transactionID As String
    Set result = CreateObject("Scripting.Dictionary")
    result.CompareMode = vbTextCompare
    For r = 1 To sourceRowCount
        transactionID = CellText(sourceData(r, WORK_TX_COL_TRANSACTION_ID))
        If Len(transactionID) = 0 Or result.Exists(transactionID) Then _
            Err.Raise vbObjectError + 4691, "BuildAnalysisAllocationTransactionIndex", _
                      "配賦対象の取引IDが空欄または重複しています: " & transactionID
        result.Add transactionID, r
    Next r
    Set BuildAnalysisAllocationTransactionIndex = result
End Function

Private Sub CollectShiftAllocationRows( _
        ByVal ws As Worksheet, ByRef sourceData As Variant, _
        ByVal transactionIndex As Object, ByVal allocationRows As Collection)
    Dim lastR As Long, data As Variant, r As Long
    Dim storedKey As String, baseKey As String, evidenceDigest As String
    Dim withdrawalID As String, depositID As String
    Dim withdrawalRow As Long, depositRow As Long
    Dim withdrawalAmount As Double, depositAmount As Double, trackingAmount As Double
    If ws Is Nothing Then Exit Sub
    lastR = LastUsedRowInSheet(ws)
    If lastR < 2 Then Exit Sub
    data = ws.Range(ws.Cells(2, 1), ws.Cells(lastR, SHIFT_ANALYSIS_LAST_COL)).Value2
    For r = 1 To UBound(data, 1)
        If StrComp(CellText(data(r, SHIFT_ANALYSIS_STATUS_COL)), _
                   ANALYSIS_STATUS_SHIFT_CONFIRMED, vbTextCompare) = 0 Then
            storedKey = CellText(data(r, SHIFT_ANALYSIS_KEY_COL))
            baseKey = AnalysisBaseKey(storedKey, evidenceDigest)
            withdrawalID = CellText(data(r, 33))
            depositID = CellText(data(r, 34))
            If Len(baseKey) = 0 Or Len(evidenceDigest) = 0 Or _
               Not transactionIndex.Exists(withdrawalID) Or _
               Not transactionIndex.Exists(depositID) Then _
                Err.Raise vbObjectError + 4692, "CollectShiftAllocationRows", _
                          "確認済み1対1候補の根拠または取引IDが不正です。"
            withdrawalRow = CLng(transactionIndex(withdrawalID))
            depositRow = CLng(transactionIndex(depositID))
            withdrawalAmount = CDbl(sourceData(withdrawalRow, OUT_COL_WITHDRAW))
            depositAmount = CDbl(sourceData(depositRow, OUT_COL_DEPOSIT))
            If withdrawalAmount < depositAmount Then
                trackingAmount = withdrawalAmount
            Else
                trackingAmount = depositAmount
            End If
            AddAnalysisAllocationRow allocationRows, "SHIFT>" & baseKey, withdrawalID, _
                ALLOCATION_DIRECTION_WITHDRAW, trackingAmount, ALLOCATION_STATUS_CONFIRMED, _
                evidenceDigest, "SHIFT", withdrawalAmount
            AddAnalysisAllocationRow allocationRows, "SHIFT>" & baseKey, depositID, _
                ALLOCATION_DIRECTION_DEPOSIT, trackingAmount, ALLOCATION_STATUS_CONFIRMED, _
                evidenceDigest, "SHIFT", depositAmount
        End If
    Next r
End Sub

Private Sub CollectFlowAllocationRows( _
        ByVal ws As Worksheet, ByRef sourceData As Variant, _
        ByVal transactionIndex As Object, ByVal manualIndex As Object, _
        ByVal allocationRows As Collection)
    Dim lastR As Long, data As Variant, r As Long
    Dim storedKey As String, baseKey As String, evidenceDigest As String
    Dim transactionIDs As String, parts As Variant, item As Variant
    Dim transactionID As String, sourceType As String
    Dim statusText As String, memoText As String
    Dim seen As Object, withdrawalIDs As Collection, depositIDs As Collection
    Dim sourceRow As Long, withdrawalTotal As Double, depositTotal As Double
    Dim trackingAmount As Double, manualEntry As Variant
    Dim candidateRequiresReview As Boolean
    If ws Is Nothing Then Exit Sub
    lastR = LastUsedRowInSheet(ws)
    If lastR < 2 Then Exit Sub
    data = ws.Range(ws.Cells(2, 1), ws.Cells(lastR, FLOW_ANALYSIS_LAST_COL)).Value2
    For r = 1 To UBound(data, 1)
        statusText = CellText(data(r, FLOW_ANALYSIS_STATUS_COL))
        memoText = CellText(data(r, FLOW_ANALYSIS_MEMO_COL))
        If FlowAllocationReviewNeedsLedger(statusText, memoText) Then
            storedKey = CellText(data(r, FLOW_ANALYSIS_KEY_COL))
            baseKey = AnalysisBaseKey(storedKey, evidenceDigest)
            transactionIDs = CellText(data(r, 20))
            If Len(baseKey) = 0 Or Len(evidenceDigest) = 0 Or Len(transactionIDs) = 0 Then _
                Err.Raise vbObjectError + 4693, "CollectFlowAllocationRows", _
                          "確認済み資金フロー候補の根拠が不正です。"
            Set seen = CreateObject("Scripting.Dictionary")
            seen.CompareMode = vbTextCompare
            Set withdrawalIDs = New Collection
            Set depositIDs = New Collection
            withdrawalTotal = 0#: depositTotal = 0#
            parts = Split(transactionIDs, ";")
            For Each item In parts
                transactionID = Trim$(CStr(item))
                If Len(transactionID) = 0 Or seen.Exists(transactionID) Or _
                   Not transactionIndex.Exists(transactionID) Then _
                    Err.Raise vbObjectError + 4694, "CollectFlowAllocationRows", _
                              "資金フロー候補の構成取引IDが空欄・重複・不存在です: " & _
                              transactionID
                seen.Add transactionID, True
                sourceRow = CLng(transactionIndex(transactionID))
                If CDbl(sourceData(sourceRow, OUT_COL_WITHDRAW)) > 0# Then
                    withdrawalIDs.Add transactionID
                    withdrawalTotal = withdrawalTotal + _
                                      CDbl(sourceData(sourceRow, OUT_COL_WITHDRAW))
                ElseIf CDbl(sourceData(sourceRow, OUT_COL_DEPOSIT)) > 0# Then
                    depositIDs.Add transactionID
                    depositTotal = depositTotal + CDbl(sourceData(sourceRow, OUT_COL_DEPOSIT))
                Else
                    Err.Raise vbObjectError + 4695, "CollectFlowAllocationRows", _
                              "構成取引に配賦可能な出金または入金がありません: " & transactionID
                End If
            Next item
            If withdrawalIDs.Count = 0 Or depositIDs.Count = 0 Then _
                Err.Raise vbObjectError + 4696, "CollectFlowAllocationRows", _
                          "資金フロー候補は出金・入金の両方を必要とします。"
            If Left$(baseKey, 7) = "MANUAL>" Then
                If manualIndex Is Nothing Then _
                    Err.Raise vbObjectError + 4697, "CollectFlowAllocationRows", _
                              "手動候補の追跡指定額索引がありません: " & baseKey
                If Not manualIndex.Exists(baseKey) Then _
                    Err.Raise vbObjectError + 4697, "CollectFlowAllocationRows", _
                              "手動候補の追跡指定額が見つかりません: " & baseKey
                manualEntry = manualIndex(baseKey)
                trackingAmount = CDbl(manualEntry(0))
                sourceType = "MANUAL_FLOW"
            Else
                If withdrawalTotal < depositTotal Then
                    trackingAmount = withdrawalTotal
                Else
                    trackingAmount = depositTotal
                End If
                sourceType = "AUTO_FLOW"
            End If
            If trackingAmount <= 0# Or _
               trackingAmount > Application.Min(withdrawalTotal, depositTotal) + _
                                AnalysisAllocationTolerance(trackingAmount) Then _
                Err.Raise vbObjectError + 4698, "CollectFlowAllocationRows", _
                          "資金フロー候補の追跡額が構成取引合計を超えています: " & baseKey
            'n:nは個別出金→個別入金の対応が一意でなく、片側だけの確定は
            '確定配賦合計も非対称にする。n:n又はどちらかの複数側で差額帰属が
            '一意でなければ候補全体をfail-closedにし、両方向を再確認へ送る。
            candidateRequiresReview = FlowAllocationCandidateRequiresReview( _
                statusText, withdrawalIDs.Count, depositIDs.Count, _
                withdrawalTotal, depositTotal, trackingAmount)
            If candidateRequiresReview Then
                '利用者が資金移動確認を選んでも差額帰属は推測確定しない。
                '候補表も正本元帳と同じ要再確認状態へ戻し、黙った不一致を残さない。
                ws.Cells(r + 1, FLOW_ANALYSIS_STATUS_COL).Value = _
                    ANALYSIS_STATUS_FOLLOWUP
                ws.Cells(r + 1, FLOW_ANALYSIS_MEMO_COL).Value = _
                    AppendAnalysisMemo( _
                        CellText(ws.Cells(r + 1, FLOW_ANALYSIS_MEMO_COL).Value2), _
                        ALLOCATION_AMBIGUITY_MEMO_MARKER & _
                        "を客観データだけで確定できないため、" & _
                        "個別配賦を0円・方向別残差を満額として要追加調査へ戻しました。")
            End If
            AddCandidateSideAllocationRows allocationRows, "FLOW>" & baseKey, _
                sourceData, transactionIndex, withdrawalIDs, False, withdrawalTotal, _
                trackingAmount, evidenceDigest, sourceType, candidateRequiresReview
            AddCandidateSideAllocationRows allocationRows, "FLOW>" & baseKey, _
                sourceData, transactionIndex, depositIDs, True, depositTotal, _
                trackingAmount, evidenceDigest, sourceType, candidateRequiresReview
        End If
    Next r
End Sub

Private Function FlowAllocationReviewNeedsLedger( _
        ByVal statusText As String, ByVal memoText As String) As Boolean
    If StrComp(statusText, ANALYSIS_STATUS_SHIFT_CONFIRMED, vbTextCompare) = 0 Then
        FlowAllocationReviewNeedsLedger = True
    ElseIf StrComp(statusText, ANALYSIS_STATUS_FOLLOWUP, vbTextCompare) = 0 Then
        FlowAllocationReviewNeedsLedger = _
            (InStr(1, memoText, ALLOCATION_AMBIGUITY_MEMO_MARKER, _
                   vbTextCompare) > 0)
    End If
End Function

Private Function FlowAllocationCandidateRequiresReview( _
        ByVal statusText As String, ByVal withdrawalCount As Long, _
        ByVal depositCount As Long, ByVal withdrawalTotal As Double, _
        ByVal depositTotal As Double, ByVal trackingAmount As Double) As Boolean
    FlowAllocationCandidateRequiresReview = _
        (StrComp(statusText, ANALYSIS_STATUS_FOLLOWUP, vbTextCompare) = 0) Or _
        (withdrawalCount > 1 And depositCount > 1) Or _
        (withdrawalCount > 1 And _
         Not AnalysisAllocationAmountsMatch(withdrawalTotal, trackingAmount)) Or _
        (depositCount > 1 And _
         Not AnalysisAllocationAmountsMatch(depositTotal, trackingAmount))
End Function

Private Sub AddCandidateSideAllocationRows( _
        ByVal allocationRows As Collection, ByVal candidateKey As String, _
        ByRef sourceData As Variant, ByVal transactionIndex As Object, _
        ByVal transactionIDs As Collection, ByVal isDeposit As Boolean, _
        ByVal sideTotal As Double, ByVal trackingAmount As Double, _
        ByVal evidenceDigest As String, ByVal sourceType As String, _
        ByVal forceReviewRequired As Boolean)
    Dim item As Variant, transactionID As String, sourceRow As Long
    Dim sourceAmount As Double, directionText As String, componentIDs As String
    Dim isUnambiguous As Boolean
    If isDeposit Then
        directionText = ALLOCATION_DIRECTION_DEPOSIT
    Else
        directionText = ALLOCATION_DIRECTION_WITHDRAW
    End If
    isUnambiguous = Not forceReviewRequired And _
                    (transactionIDs.Count = 1 Or _
                     AnalysisAllocationAmountsMatch(sideTotal, trackingAmount))
    For Each item In transactionIDs
        transactionID = CStr(item)
        sourceRow = CLng(transactionIndex(transactionID))
        If isDeposit Then
            sourceAmount = CDbl(sourceData(sourceRow, OUT_COL_DEPOSIT))
        Else
            sourceAmount = CDbl(sourceData(sourceRow, OUT_COL_WITHDRAW))
        End If
        If isUnambiguous Then
            If transactionIDs.Count = 1 Then
                AddAnalysisAllocationRow allocationRows, candidateKey, transactionID, _
                    directionText, Application.Min(sourceAmount, trackingAmount), _
                    ALLOCATION_STATUS_CONFIRMED, evidenceDigest, sourceType, sourceAmount
            Else
                AddAnalysisAllocationRow allocationRows, candidateKey, transactionID, _
                    directionText, sourceAmount, ALLOCATION_STATUS_CONFIRMED, _
                    evidenceDigest, sourceType, sourceAmount
            End If
        Else
            '複数取引のどれに差額が残るかは客観データだけでは決められない。
            '推測按分せず各取引を0円要再確認とし、共同ResidualLotを残す。
            AddAnalysisAllocationRow allocationRows, candidateKey, transactionID, _
                directionText, 0#, ALLOCATION_STATUS_REVIEW_REQUIRED, _
                evidenceDigest, sourceType, sourceAmount
        End If
        If Len(componentIDs) > 0 Then componentIDs = componentIDs & ";"
        componentIDs = componentIDs & transactionID
    Next item
    'ResidualLotは差額帰属が曖昧な複数取引側だけに作る。候補全体を
    'fail-closedにした結果の単一取引側は、上の0円個別行が満額残差を保持する。
    If Not isUnambiguous And transactionIDs.Count > 1 Then
        AddAnalysisAllocationRow allocationRows, candidateKey, _
            componentIDs, directionText, sideTotal, _
            ALLOCATION_STATUS_REVIEW_REQUIRED, evidenceDigest, _
            ALLOCATION_SOURCE_RESIDUAL_LOT, sideTotal
    End If
End Sub

Private Sub AddAnalysisAllocationRow( _
        ByVal allocationRows As Collection, ByVal candidateKey As String, _
        ByVal transactionID As String, ByVal directionText As String, _
        ByVal allocatedAmount As Double, ByVal statusText As String, _
        ByVal evidenceDigest As String, ByVal sourceType As String, _
        ByVal sourceAmount As Double)
    allocationRows.Add Array(candidateKey, transactionID, directionText, allocatedAmount, _
                             statusText, evidenceDigest, sourceType, sourceAmount)
End Sub

Private Function AnalysisAllocationTolerance(ByVal amountValue As Double) As Double
    '配賦正本の厳密検証と同一許容差に固定する。候補探索用の金額許容とは別物。
    AnalysisAllocationTolerance = _
        Application.Max(0.00000001, Abs(amountValue) * 0.0000000000005)
End Function

Private Function AnalysisAllocationAmountsMatch( _
        ByVal leftAmount As Double, ByVal rightAmount As Double) As Boolean
    AnalysisAllocationAmountsMatch = _
        (Abs(leftAmount - rightAmount) <= _
         Application.Max(AnalysisAllocationTolerance(leftAmount), _
                         AnalysisAllocationTolerance(rightAmount)))
End Function

Private Sub ValidateCurrentAnalysisAllocationCoverage( _
        ByRef sourceData As Variant, ByVal sourceRowCount As Long)
    Dim allocationIndex As Object, r As Long, transactionID As String
    Dim directionText As String, sourceAmount As Double
    Dim allocatedAmount As Double, unresolvedAmount As Double, allocationCount As Long
    Set allocationIndex = CaptureAllocationLedgerIndex()
    For r = 1 To sourceRowCount
        transactionID = CellText(sourceData(r, WORK_TX_COL_TRANSACTION_ID))
        If CDbl(sourceData(r, OUT_COL_WITHDRAW)) > 0# Then
            directionText = ALLOCATION_DIRECTION_WITHDRAW
            sourceAmount = CDbl(sourceData(r, OUT_COL_WITHDRAW))
        ElseIf CDbl(sourceData(r, OUT_COL_DEPOSIT)) > 0# Then
            directionText = ALLOCATION_DIRECTION_DEPOSIT
            sourceAmount = CDbl(sourceData(r, OUT_COL_DEPOSIT))
        Else
            GoTo NextCoverageRow
        End If
        If Not GetTransactionUnresolvedAmountFromIndex( _
                allocationIndex, transactionID, directionText, sourceAmount, _
                allocatedAmount, unresolvedAmount, allocationCount) Then _
            Err.Raise vbObjectError + 4699, "ValidateCurrentAnalysisAllocationCoverage", _
                      "配賦元帳の読戻しに失敗しました: " & transactionID
        If Not AnalysisAllocationAmountsMatch( _
                allocatedAmount + unresolvedAmount, sourceAmount) Then _
            Err.Raise vbObjectError + 4699, "ValidateCurrentAnalysisAllocationCoverage", _
                      "確定配賦+未追跡残額が元金額と一致しません: " & transactionID
NextCoverageRow:
    Next r
End Sub

Public Sub ResolveAnalysisReviewConflicts(ByVal wsShift As Worksheet, ByVal wsFlow As Worksheet)
    Dim problems As String
    '同じ取引を複数候補が部分利用すること自体は競合ではない。
    '件数ではなく、共通配賦元帳の金額不変条件だけを保存前に検証する。
    If Not ValidateAllocationLedgerForSave(problems) Then _
        Err.Raise vbObjectError + 4630, "ResolveAnalysisReviewConflicts", _
                  "配賦元帳が不正なため確認状況を保存できません。" & vbCrLf & problems
End Sub


Public Function BuildConfirmedCandidateCountByTransaction(ByVal wsShift As Worksheet, _
                                                          ByVal wsFlow As Worksheet) As Object
    Dim candidateRows As Object, countByTx As Object
    Set candidateRows = CreateObject("Scripting.Dictionary")
    Set countByTx = CreateObject("Scripting.Dictionary")
    candidateRows.CompareMode = vbTextCompare
    countByTx.CompareMode = vbTextCompare
    CollectConfirmedAnalysisUsage wsShift, wsFlow, candidateRows, countByTx
    Set BuildConfirmedCandidateCountByTransaction = countByTx
End Function

Private Sub CollectConfirmedAnalysisUsage(ByVal wsShift As Worksheet, ByVal wsFlow As Worksheet, _
                                          ByVal candidateRows As Object, ByVal countByTx As Object)
    Dim membership As Object
    Set membership = CreateObject("Scripting.Dictionary")
    membership.CompareMode = vbTextCompare
    CollectConfirmedUsageFromSheet wsShift, 1, SHIFT_ANALYSIS_STATUS_COL, SHIFT_ANALYSIS_KEY_COL, _
                                   33, 34, candidateRows, countByTx, membership
    CollectConfirmedUsageFromSheet wsFlow, 2, FLOW_ANALYSIS_STATUS_COL, FLOW_ANALYSIS_KEY_COL, _
                                   20, 0, candidateRows, countByTx, membership
End Sub

Private Sub CollectConfirmedUsageFromSheet( _
        ByVal ws As Worksheet, ByVal sheetCode As Long, ByVal statusColumn As Long, _
        ByVal keyColumn As Long, ByVal transactionColumn As Long, ByVal secondTransactionColumn As Long, _
        ByVal candidateRows As Object, ByVal countByTx As Object, ByVal membership As Object)
    Dim lastR As Long, dataRows As Long, r As Long
    Dim statusValues As Variant, keyValues As Variant, transactionValues As Variant
    Dim secondTransactionValues As Variant
    Dim storedKey As String, baseKey As String, digestText As String, transactionIDs As String
    Dim candidateID As String
    If ws Is Nothing Then Exit Sub
    lastR = LastUsedRowInSheet(ws)
    If lastR < 2 Then Exit Sub
    dataRows = lastR - 1
    statusValues = ws.Range(ws.Cells(2, statusColumn), ws.Cells(lastR, statusColumn)).Value2
    keyValues = ws.Range(ws.Cells(2, keyColumn), ws.Cells(lastR, keyColumn)).Value2
    transactionValues = ws.Range(ws.Cells(2, transactionColumn), _
                                 ws.Cells(lastR, transactionColumn)).Value2
    If secondTransactionColumn > 0 Then _
        secondTransactionValues = ws.Range(ws.Cells(2, secondTransactionColumn), _
                                           ws.Cells(lastR, secondTransactionColumn)).Value2
    For r = 1 To dataRows
        If StrComp(CellText(AnalysisColumnValue(statusValues, r, dataRows)), _
                   ANALYSIS_STATUS_SHIFT_CONFIRMED, vbTextCompare) = 0 Then
            storedKey = CellText(AnalysisColumnValue(keyValues, r, dataRows))
            baseKey = AnalysisBaseKey(storedKey, digestText)
            If secondTransactionColumn > 0 Then
                transactionIDs = CellText(AnalysisColumnValue(transactionValues, r, dataRows)) & ";" & _
                                 CellText(AnalysisColumnValue(secondTransactionValues, r, dataRows))
            Else
                transactionIDs = CellText(AnalysisColumnValue(transactionValues, r, dataRows))
            End If
            candidateID = CStr(sheetCode) & "|" & baseKey
            RegisterConfirmedAnalysisCandidate candidateRows, countByTx, membership, candidateID, _
                                               sheetCode, r + 1, transactionIDs
        End If
    Next r
End Sub

Private Sub RegisterConfirmedAnalysisCandidate( _
        ByVal candidateRows As Object, ByVal countByTx As Object, ByVal membership As Object, _
        ByVal candidateID As String, ByVal sheetCode As Long, ByVal rowNumber As Long, _
        ByVal transactionIDs As String)
    Dim items As Variant, item As Variant, transactionID As String, membershipKey As String
    If Len(candidateID) = 0 Or candidateRows.Exists(candidateID) Then Exit Sub
    candidateRows.Add candidateID, Array(sheetCode, rowNumber, transactionIDs)
    items = Split(transactionIDs, ";")
    For Each item In items
        transactionID = Trim$(CStr(item))
        If Len(transactionID) > 0 Then
            membershipKey = transactionID & ChrW(30) & candidateID
            If Not membership.Exists(membershipKey) Then
                membership.Add membershipKey, True
                IncrementAnalysisCount countByTx, transactionID
            End If
        End If
    Next item
End Sub


Private Sub PrepareShiftAnalysisSheet(ByVal ws As Worksheet)
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim cleanupErrorNumber As Long
    Dim cleanupErrorDescription As String, cleanupErrorSource As String
    Dim convergenceDetail As String
    If ws Is Nothing Then Exit Sub
    On Error GoTo EH
    ws.Unprotect Password:=TOOL_PASSWORD
    If ws.AutoFilterMode Then ws.AutoFilterMode = False
    ResetWorksheet ws
    SetRowValues ws.Range("A1"), ShiftAnalysisHeaders()
    FormatOutputHeader ws.Range(ws.Cells(1, 1), ws.Cells(1, SHIFT_ANALYSIS_LAST_COL))
    ws.Columns("A:AH").NumberFormatLocal = "@"
    ws.Columns("B:B").NumberFormatLocal = "0"
    ws.Columns("H:H").NumberFormatLocal = "#,##0.########"
    ws.Columns("I:I").NumberFormatLocal = "yyyy/m/d"
    ws.Columns("J:J").NumberFormatLocal = "hh:mm"
    ws.Columns("Q:Q").NumberFormatLocal = "#,##0.########"
    ws.Columns("S:S").NumberFormatLocal = "yyyy/m/d"
    ws.Columns("T:T").NumberFormatLocal = "hh:mm"
    ws.Columns("AA:AA").NumberFormatLocal = "#,##0.########"
    ApplyShiftColumnWidths ws
    ws.Columns("AF:AH").Hidden = True
    ProtectSingleAnalysisSheet ws
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    If IsTransactionAnalysisRecoveryFatal(errorNumber, errorSource) Then
        Call TryStopTransactionAnalysisEventsForBookWrites(convergenceDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    On Error Resume Next
    Err.Clear
    EmergencyProtectToolSheet ws
    cleanupErrorNumber = Err.Number
    cleanupErrorSource = Err.Source
    cleanupErrorDescription = Err.Description
    Err.Clear
    On Error GoTo 0
    If IsTransactionAnalysisRecoveryFatal( _
           cleanupErrorNumber, cleanupErrorSource) Then
        Call TryStopTransactionAnalysisEventsForBookWrites(convergenceDetail)
        Err.Raise cleanupErrorNumber, cleanupErrorSource, _
                  cleanupErrorDescription
    End If
    Err.Raise errorNumber, "PrepareShiftAnalysisSheet", errorSource & " / " & errorDescription
End Sub

Private Sub PrepareUnknownAnalysisSheet(ByVal ws As Worksheet)
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim cleanupErrorNumber As Long
    Dim cleanupErrorDescription As String, cleanupErrorSource As String
    Dim convergenceDetail As String
    If ws Is Nothing Then Exit Sub
    On Error GoTo EH
    ws.Unprotect Password:=TOOL_PASSWORD
    If ws.AutoFilterMode Then ws.AutoFilterMode = False
    ResetWorksheet ws
    SetRowValues ws.Range("A1"), UnknownAnalysisHeaders()
    FormatOutputHeader ws.Range(ws.Cells(1, 1), ws.Cells(1, UNKNOWN_ANALYSIS_LAST_COL))
    ws.Columns("A:Z").NumberFormatLocal = "@"
    ws.Columns("B:B").NumberFormatLocal = "0"
    ws.Columns("D:D").NumberFormatLocal = "yyyy/m/d"
    ws.Columns("E:E").NumberFormatLocal = "hh:mm"
    ws.Columns("M:N").NumberFormatLocal = "#,##0.########"
    ws.Columns("R:R").NumberFormatLocal = "0"
    ApplyUnknownColumnWidths ws
    ws.Columns("X:Z").Hidden = True
    ProtectSingleAnalysisSheet ws
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    If IsTransactionAnalysisRecoveryFatal(errorNumber, errorSource) Then
        Call TryStopTransactionAnalysisEventsForBookWrites(convergenceDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    On Error Resume Next
    Err.Clear
    EmergencyProtectToolSheet ws
    cleanupErrorNumber = Err.Number
    cleanupErrorSource = Err.Source
    cleanupErrorDescription = Err.Description
    Err.Clear
    On Error GoTo 0
    If IsTransactionAnalysisRecoveryFatal( _
           cleanupErrorNumber, cleanupErrorSource) Then
        Call TryStopTransactionAnalysisEventsForBookWrites(convergenceDetail)
        Err.Raise cleanupErrorNumber, cleanupErrorSource, _
                  cleanupErrorDescription
    End If
    Err.Raise errorNumber, "PrepareUnknownAnalysisSheet", errorSource & " / " & errorDescription
End Sub

Private Sub FinalizeShiftAnalysisSheet(ByVal ws As Worksheet, ByVal dataCount As Long)
    Dim lastR As Long
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim cleanupErrorNumber As Long
    Dim cleanupErrorDescription As String, cleanupErrorSource As String
    Dim convergenceDetail As String
    If ws Is Nothing Then Exit Sub
    On Error GoTo EH
    ws.Unprotect Password:=TOOL_PASSWORD
    lastR = dataCount + 1
    FormatOutputHeader ws.Range(ws.Cells(1, 1), ws.Cells(1, SHIFT_ANALYSIS_LAST_COL))
    If dataCount > 1 Then SortShiftAnalysis ws, lastR
    ApplyShiftColumnWidths ws
    ws.Columns("AF:AH").Hidden = True
    If dataCount > 0 Then
        With ws.Range(ws.Cells(2, 1), ws.Cells(lastR, SHIFT_ANALYSIS_LAST_COL))
            .VerticalAlignment = xlTop
            .WrapText = False
        End With
        If dataCount <= 10000 Then
            With ws.Range(ws.Cells(2, 1), ws.Cells(lastR, SHIFT_ANALYSIS_LAST_COL)).Borders
                .Color = RGB(226, 232, 240)
                .LineStyle = xlContinuous
            End With
        End If
        ws.Range(ws.Cells(2, 29), ws.Cells(lastR, 31)).WrapText = True
        ws.Range(ws.Cells(2, SHIFT_ANALYSIS_STATUS_COL), _
                 ws.Cells(lastR, SHIFT_ANALYSIS_MEMO_COL)).Interior.Color = RGB(254, 249, 195)
        ws.Rows("2:" & CStr(lastR)).RowHeight = 32
    End If
    If ws.AutoFilterMode Then ws.AutoFilterMode = False
    ws.Range(ws.Cells(1, 1), ws.Cells(lastR, SHIFT_ANALYSIS_LAST_COL)).AutoFilter
    ApplyAnalysisReviewValidation ws, SHIFT_ANALYSIS_STATUS_COL, SHIFT_ANALYSIS_MEMO_COL, lastR
    SafeFreezeOutputHeader ws
    ProtectSingleAnalysisSheet ws
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    If IsTransactionAnalysisRecoveryFatal(errorNumber, errorSource) Then
        Call TryStopTransactionAnalysisEventsForBookWrites(convergenceDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    On Error Resume Next
    Err.Clear
    EmergencyProtectToolSheet ws
    cleanupErrorNumber = Err.Number
    cleanupErrorSource = Err.Source
    cleanupErrorDescription = Err.Description
    Err.Clear
    On Error GoTo 0
    If IsTransactionAnalysisRecoveryFatal( _
           cleanupErrorNumber, cleanupErrorSource) Then
        Call TryStopTransactionAnalysisEventsForBookWrites(convergenceDetail)
        Err.Raise cleanupErrorNumber, cleanupErrorSource, _
                  cleanupErrorDescription
    End If
    Err.Raise errorNumber, "FinalizeShiftAnalysisSheet", errorSource & " / " & errorDescription
End Sub

Private Sub FinalizeUnknownAnalysisSheet(ByVal ws As Worksheet, ByVal dataCount As Long)
    Dim lastR As Long
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim cleanupErrorNumber As Long
    Dim cleanupErrorDescription As String, cleanupErrorSource As String
    Dim convergenceDetail As String
    If ws Is Nothing Then Exit Sub
    On Error GoTo EH
    ws.Unprotect Password:=TOOL_PASSWORD
    lastR = dataCount + 1
    FormatOutputHeader ws.Range(ws.Cells(1, 1), ws.Cells(1, UNKNOWN_ANALYSIS_LAST_COL))
    If dataCount > 1 Then SortUnknownAnalysis ws, lastR
    ApplyUnknownColumnWidths ws
    ws.Columns("X:Z").Hidden = True
    If dataCount > 0 Then
        With ws.Range(ws.Cells(2, 1), ws.Cells(lastR, UNKNOWN_ANALYSIS_LAST_COL))
            .VerticalAlignment = xlTop
            .WrapText = False
        End With
        If dataCount <= 10000 Then
            With ws.Range(ws.Cells(2, 1), ws.Cells(lastR, UNKNOWN_ANALYSIS_LAST_COL)).Borders
                .Color = RGB(226, 232, 240)
                .LineStyle = xlContinuous
            End With
        End If
        ws.Range(ws.Cells(2, 20), ws.Cells(lastR, 22)).WrapText = True
        ws.Range(ws.Cells(2, UNKNOWN_ANALYSIS_STATUS_COL), _
                 ws.Cells(lastR, UNKNOWN_ANALYSIS_MEMO_COL)).Interior.Color = RGB(254, 249, 195)
        ws.Rows("2:" & CStr(lastR)).RowHeight = 32
    End If
    If ws.AutoFilterMode Then ws.AutoFilterMode = False
    ws.Range(ws.Cells(1, 1), ws.Cells(lastR, UNKNOWN_ANALYSIS_LAST_COL)).AutoFilter
    ApplyAnalysisReviewValidation ws, UNKNOWN_ANALYSIS_STATUS_COL, UNKNOWN_ANALYSIS_MEMO_COL, lastR
    SafeFreezeOutputHeader ws
    ProtectSingleAnalysisSheet ws
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    If IsTransactionAnalysisRecoveryFatal(errorNumber, errorSource) Then
        Call TryStopTransactionAnalysisEventsForBookWrites(convergenceDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    On Error Resume Next
    Err.Clear
    EmergencyProtectToolSheet ws
    cleanupErrorNumber = Err.Number
    cleanupErrorSource = Err.Source
    cleanupErrorDescription = Err.Description
    Err.Clear
    On Error GoTo 0
    If IsTransactionAnalysisRecoveryFatal( _
           cleanupErrorNumber, cleanupErrorSource) Then
        Call TryStopTransactionAnalysisEventsForBookWrites(convergenceDetail)
        Err.Raise cleanupErrorNumber, cleanupErrorSource, _
                  cleanupErrorDescription
    End If
    Err.Raise errorNumber, "FinalizeUnknownAnalysisSheet", errorSource & " / " & errorDescription
End Sub

Private Sub ApplyShiftColumnWidths(ByVal ws As Worksheet)
    ws.Columns("A:A").ColumnWidth = 8
    ws.Columns("B:B").ColumnWidth = 8
    ws.Columns("C:G").ColumnWidth = 16
    ws.Columns("H:H").ColumnWidth = 14
    ws.Columns("I:J").ColumnWidth = 13
    ws.Columns("K:P").ColumnWidth = 16
    ws.Columns("Q:Q").ColumnWidth = 15
    ws.Columns("R:R").ColumnWidth = 24
    ws.Columns("S:T").ColumnWidth = 13
    ws.Columns("U:Z").ColumnWidth = 16
    ws.Columns("AA:AA").ColumnWidth = 15
    ws.Columns("AB:AB").ColumnWidth = 24
    ws.Columns("AC:AC").ColumnWidth = 48
    ws.Columns("AD:AD").ColumnWidth = 16
    ws.Columns("AE:AE").ColumnWidth = 36
End Sub

Private Sub ApplyUnknownColumnWidths(ByVal ws As Worksheet)
    ws.Columns("A:C").ColumnWidth = 14
    ws.Columns("D:E").ColumnWidth = 13
    ws.Columns("F:F").ColumnWidth = 16
    ws.Columns("G:L").ColumnWidth = 16
    ws.Columns("M:N").ColumnWidth = 15
    ws.Columns("O:Q").ColumnWidth = 20
    ws.Columns("R:S").ColumnWidth = 14
    ws.Columns("T:T").ColumnWidth = 52
    ws.Columns("U:U").ColumnWidth = 16
    ws.Columns("V:V").ColumnWidth = 36
    ws.Columns("W:W").ColumnWidth = 14
End Sub

Public Sub ApplyAnalysisReviewValidation(ByVal ws As Worksheet, ByVal statusColumn As Long, _
                                          ByVal memoColumn As Long, ByVal lastR As Long)
    Dim statusRange As Range
    If ws Is Nothing Then Exit Sub
    ws.Cells.Locked = True
    If lastR >= 2 Then
        Set statusRange = ws.Range(ws.Cells(2, statusColumn), ws.Cells(lastR, statusColumn))
        statusRange.Locked = False
        ws.Range(ws.Cells(2, memoColumn), ws.Cells(lastR, memoColumn)).Locked = False
        If StrComp(ws.Name, SH_ANALYSIS_UNKNOWN, vbTextCompare) = 0 Then
            ApplyUnknownAnalysisStatusValidation statusRange
        Else
            ApplyValidationList statusRange, NM_LST_ANALYSIS_SHIFT_STATUS, xlIMEModeOff, False
        End If
        ApplyAnalysisMemoValidation ws.Range(ws.Cells(2, memoColumn), ws.Cells(lastR, memoColumn))
    End If
End Sub

Private Sub ApplyUnknownAnalysisStatusValidation(ByVal target As Range)
    If target Is Nothing Then Exit Sub
    With target.Validation
        .Delete
        .Add Type:=xlValidateList, AlertStyle:=xlValidAlertStop, Operator:=xlBetween, _
             Formula1:=AnalysisReviewValidationFormula(SH_ANALYSIS_UNKNOWN)
        .IgnoreBlank = True
        .InCellDropdown = True
        .ShowError = True
        .ErrorTitle = "確認状況を選択してください"
        .ErrorMessage = "原資不明候補と使途不明候補に対応する確認状況を選択してください。"
    End With
    On Error Resume Next
    target.Validation.IMEMode = xlIMEModeOff
    On Error GoTo 0
End Sub

Private Function AnalysisReviewValidationFormula(ByVal sheetName As String) As String
    If StrComp(sheetName, SH_ANALYSIS_UNKNOWN, vbTextCompare) = 0 Then
        AnalysisReviewValidationFormula = "=INDIRECT(IF($C2=""原資不明候補"",""" & _
            NM_LST_ANALYSIS_SOURCE_STATUS & """,""" & NM_LST_ANALYSIS_USE_STATUS & """))"
    Else
        AnalysisReviewValidationFormula = "=" & NM_LST_ANALYSIS_SHIFT_STATUS
    End If
End Function

Private Sub ApplyAnalysisMemoValidation(ByVal target As Range)
    If target Is Nothing Then Exit Sub
    With target.Validation
        .Delete
        .Add Type:=xlValidateTextLength, AlertStyle:=xlValidAlertStop, _
             Operator:=xlLessEqual, Formula1:=CStr(ANALYSIS_REVIEW_MEMO_MAX)
        .IgnoreBlank = True
        .ShowError = True
        .ErrorTitle = "確認メモの文字数を確認してください"
        .ErrorMessage = "確認メモは" & CStr(ANALYSIS_REVIEW_MEMO_MAX) & "文字以内で入力してください。"
    End With
    'IMEを備えないExcelでも文字数制限そのものは有効にする。
    On Error Resume Next
    target.Validation.IMEMode = xlIMEModeHiragana
    On Error GoTo 0
End Sub

Public Sub ProtectSingleAnalysisSheet(ByVal ws As Worksheet)
    Dim workbookWasSaved As Boolean, emergencyProtected As Boolean
    Dim previousEvents As Boolean, eventsCaptured As Boolean
    Dim recoveryEnforcementFailed As Boolean
    Dim recoveryConfirmedThisAttempt As Boolean
    Dim eventsStoppedAfterRecovery As Boolean
    Dim recoveryAttempted As Boolean
    Dim safeToRestoreEntry As Boolean
    Dim restoreErrorNumber As Long, restoreErrorSource As String
    Dim restoreErrorDescription As String
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim emergencyDetail As String, recoveryDetail As String, sheetName As String
    Dim eventStateDetail As String, eventRestoreDetail As String
    If ws Is Nothing Then Exit Sub
    sheetName = ws.Name
    If Not TryGetTransactionAnalysisEnableEvents( _
               previousEvents, eventStateDetail) Then
        On Error Resume Next
        MsgBox "分析シートの保護前にExcelイベントの開始状態を取得できませんでした。" & _
               vbCrLf & "保護・Recovery・状態表示は行わず、案件の安全状態は不明です。" & _
               vbCrLf & "現在のブックを上書きしないでください。", _
               vbCritical, "Excelイベント状態を確認できません"
        On Error GoTo 0
        Err.Raise vbObjectError + 4703, _
                  "ProtectSingleAnalysisSheet(" & sheetName & ")", _
                  "Excelイベントの開始状態を取得できませんでした。 " & _
                  eventStateDetail
    End If
    eventsCaptured = True
    If Not TryStopTransactionAnalysisEventsForBookWrites(eventStateDetail) Then
        errorDescription = _
            "分析シートの保護前にExcelイベントを停止して読戻し確認できませんでした。 " & _
            eventStateDetail
        On Error Resume Next
        MsgBox errorDescription & vbCrLf & _
               "分析シートの保護は行わず、開始時イベント状態への復元だけを試みます。" & _
               vbCrLf & "案件の安全状態は確定していません。" & _
               vbCrLf & "現在のブックを上書きしないでください。", _
               vbCritical, "分析シートを安全に保護できません"
        On Error GoTo 0
        If Not TryRestoreTransactionAnalysisEnableEvents( _
                   previousEvents, _
                   "ProtectSingleAnalysisSheet/保護開始前", _
                   eventRestoreDetail) Then _
            AppendTransactionRollbackDetail errorDescription, _
                "Excelイベント状態の復元エラー: " & eventRestoreDetail
        eventsCaptured = False
        Err.Raise vbObjectError + 4704, _
                  "ProtectSingleAnalysisSheet(" & sheetName & ")", _
                  errorDescription
    End If
    On Error GoTo EH
    workbookWasSaved = ThisWorkbook.Saved
    ws.Unprotect Password:=TOOL_PASSWORD
    RestoreToolSheetScrollArea ws
    LockToolShapes ws, False
    ws.Protect Password:=TOOL_PASSWORD, DrawingObjects:=True, Contents:=True, Scenarios:=False, _
               UserInterfaceOnly:=True, AllowFiltering:=True, AllowSorting:=False, _
               AllowFormattingCells:=False, AllowFormattingColumns:=False, AllowFormattingRows:=False
    ws.EnableSelection = xlNoRestrictions
    If Not ws.ProtectContents Or Not ws.ProtectDrawingObjects Then _
        Err.Raise vbObjectError + 4614, "ProtectSingleAnalysisSheet", _
                  ws.Name & "を保護できませんでした。"
    VerifyToolShapeSecurity ws, True, False
    If workbookWasSaved Then
        If Not TryStopTransactionAnalysisEventsForBookWrites(eventStateDetail) Then _
            Err.Raise vbObjectError + 4707, "ProtectSingleAnalysisSheet", _
                      "Saved復元前にExcelイベント停止を確認できませんでした。 " & _
                      eventStateDetail
        ThisWorkbook.Saved = True
        If Not ThisWorkbook.Saved Then _
            Err.Raise vbObjectError + 4705, "ProtectSingleAnalysisSheet", _
                      "保護確認後にブック保存状態を復元できませんでした。"
    End If
    On Error GoTo 0
    If eventsCaptured Then
        If Not TryRestoreTransactionAnalysisEnableEvents( _
                   previousEvents, "ProtectSingleAnalysisSheet/正常終了", _
                   eventRestoreDetail) Then
            eventsCaptured = False
            Err.Raise vbObjectError + 4706, _
                      "ProtectSingleAnalysisSheet(" & sheetName & ")", _
                      eventRestoreDetail
        End If
        eventsCaptured = False
    End If
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    If IsTransactionAnalysisRecoveryFatal(errorNumber, errorSource) Then
        Call TryStopTransactionAnalysisEventsForBookWrites(eventStateDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    If TryStopTransactionAnalysisEventsForBookWrites(eventStateDetail) Then
        emergencyProtected = _
            TryEmergencyProtectAnalysisSheet(ws, emergencyDetail)
        If Not emergencyProtected Then
            recoveryDetail = sheetName & "の緊急再保護を確認できません。"
            AppendTransactionRollbackDetail recoveryDetail, emergencyDetail
            StopAfterTransactionAnalysisEventStateFailure _
                "ProtectSingleAnalysisSheet/緊急再保護", recoveryDetail, _
                recoveryEnforcementFailed, recoveryConfirmedThisAttempt, _
                eventsStoppedAfterRecovery, recoveryAttempted
            AppendTransactionRollbackDetail errorDescription, recoveryDetail
            If recoveryAttempted Then
                eventsCaptured = False
                Err.Raise vbObjectError + 5195, _
                    "TransactionAnalysisRecoveryFatal/ProtectSingleAnalysisSheet", _
                    errorDescription
            End If
        End If
    Else
        AppendTransactionRollbackDetail errorDescription, _
            "Excelイベント停止を確認できないため緊急再保護・Recovery・診断・" & _
            "状態表示の書込みを見送り、案件の安全状態は不明です: " & _
            eventStateDetail
        On Error Resume Next
        MsgBox "分析シートの保護に失敗し、Excelイベントも安全に停止できませんでした。" & _
               vbCrLf & "緊急再保護と復旧記録を行わず、案件の安全状態は不明です。" & _
               vbCrLf & "現在のブックを上書きしないでください。", _
               vbCritical, "分析シートの安全状態を確認できません"
        On Error GoTo 0
    End If
    '緊急保護とその読戻しが成立し、イベントもFalse exactの場合だけ
    '保護操作によるSaved変更を開始値へ戻す。
    If emergencyProtected And workbookWasSaved Then
        If TryStopTransactionAnalysisEventsForBookWrites(eventStateDetail) Then
            RestoreSavedFlagAfterAnalysisProtection errorDescription
        Else
            AppendTransactionRollbackDetail errorDescription, _
                "緊急保護後にExcelイベント停止を確認できないため、" & _
                "ブック保存状態の復元を見送りました: " & eventStateDetail
            On Error Resume Next
            MsgBox "緊急保護後のExcelイベント状態を確認できないため、" & _
                   "ブック保存状態の復元を見送りました。" & _
                   vbCrLf & "現在のブックを上書きしないでください。", _
                   vbCritical, "Excelイベント状態を確認できません"
            On Error GoTo 0
        End If
    End If
    If eventsCaptured Then
        On Error Resume Next
        Err.Clear
        safeToRestoreEntry = emergencyProtected Or _
                             (recoveryConfirmedThisAttempt And _
                              eventsStoppedAfterRecovery)
        If safeToRestoreEntry Then _
            safeToRestoreEntry = _
                TransactionAnalysisApplicationStateAllowsEntryRestore( _
                    previousEvents, errorDescription)
        If safeToRestoreEntry Then
            If Not TryRestoreTransactionAnalysisEnableEvents( _
                       previousEvents, "ProtectSingleAnalysisSheet/異常終了", _
                       eventRestoreDetail) Then _
                AppendTransactionRollbackDetail errorDescription, _
                    "Excelイベント状態の復元エラー: " & eventRestoreDetail
            restoreErrorNumber = Err.Number
            restoreErrorSource = Err.Source
            restoreErrorDescription = Err.Description
        Else
            eventsStoppedAfterRecovery = _
                TryStopTransactionAnalysisEventsForBookWrites(eventStateDetail)
        End If
        Err.Clear
        On Error GoTo 0
        If IsTransactionAnalysisRecoveryFatal( _
               restoreErrorNumber, restoreErrorSource) Then
            Call TryStopTransactionAnalysisEventsForBookWrites(eventStateDetail)
            Err.Raise restoreErrorNumber, restoreErrorSource, _
                      restoreErrorDescription
        End If
        eventsCaptured = False
        If restoreErrorNumber <> 0 Then _
            AppendTransactionRollbackDetail errorDescription, _
                "Excelイベント状態の復元処理エラー: Err " & _
                CStr(restoreErrorNumber) & " " & restoreErrorDescription
    End If
    Err.Raise errorNumber, "ProtectSingleAnalysisSheet(" & sheetName & ")", _
              IIf(Len(errorSource) > 0, errorSource & " / ", vbNullString) & _
              errorDescription
End Sub

Private Function TryEmergencyProtectAnalysisSheet(ByVal ws As Worksheet, _
                                                   ByRef failureText As String) As Boolean
    failureText = vbNullString
    If ws Is Nothing Then
        failureText = "緊急再保護する分析シートを取得できません。"
        Exit Function
    End If
    On Error GoTo EH
    EmergencyProtectToolSheet ws
    If Not ws.ProtectContents Or Not ws.ProtectDrawingObjects Then
        failureText = "緊急再保護後のセル・図形保護を読み戻せません。"
        Exit Function
    End If
    TryEmergencyProtectAnalysisSheet = True
    Exit Function
EH:
    failureText = "Err " & CStr(Err.Number) & " [" & Err.Source & "] " & _
                  Err.Description
    Err.Clear
End Function

Private Sub RestoreSavedFlagAfterAnalysisProtection(ByRef detailText As String)
    Dim savedReadback As Boolean
    Dim savedErrorNumber As Long, savedErrorDescription As String
    Dim readErrorNumber As Long, readErrorDescription As String
    On Error Resume Next
    Err.Clear
    ThisWorkbook.Saved = True
    savedErrorNumber = Err.Number
    savedErrorDescription = Err.Description
    Err.Clear
    savedReadback = ThisWorkbook.Saved
    readErrorNumber = Err.Number
    readErrorDescription = Err.Description
    Err.Clear
    On Error GoTo 0
    If savedErrorNumber <> 0 Or readErrorNumber <> 0 Or Not savedReadback Then
        AppendTransactionRollbackDetail detailText, _
            "ブック保存状態の復元を確認できません" & _
            IIf(savedErrorNumber <> 0, _
                ": Err " & CStr(savedErrorNumber) & " " & savedErrorDescription, _
                vbNullString) & _
            IIf(readErrorNumber <> 0, _
                " / 読戻し Err " & CStr(readErrorNumber) & " " & _
                readErrorDescription, vbNullString)
    End If
End Sub

Private Sub SortShiftAnalysis(ByVal ws As Worksheet, ByVal lastR As Long)
    With ws.Sort
        .SortFields.Clear
        .SortFields.Add Key:=ws.Range(ws.Cells(2, 2), ws.Cells(lastR, 2)), _
                        SortOn:=xlSortOnValues, Order:=xlDescending, DataOption:=xlSortNormal
        .SortFields.Add Key:=ws.Range(ws.Cells(2, 9), ws.Cells(lastR, 9)), _
                        SortOn:=xlSortOnValues, Order:=xlAscending, DataOption:=xlSortNormal
        .SortFields.Add Key:=ws.Range(ws.Cells(2, 19), ws.Cells(lastR, 19)), _
                        SortOn:=xlSortOnValues, Order:=xlAscending, DataOption:=xlSortNormal
        .SetRange ws.Range(ws.Cells(1, 1), ws.Cells(lastR, SHIFT_ANALYSIS_LAST_COL))
        .Header = xlYes
        .Apply
    End With
End Sub

Private Sub SortUnknownAnalysis(ByVal ws As Worksheet, ByVal lastR As Long)
    With ws.Sort
        .SortFields.Clear
        '原資不明（入金）と使途不明（出金）を混在させず、同一表内で別群にする。
        .SortFields.Add Key:=ws.Range(ws.Cells(2, 3), ws.Cells(lastR, 3)), _
                        SortOn:=xlSortOnValues, Order:=xlAscending, DataOption:=xlSortNormal
        .SortFields.Add Key:=ws.Range(ws.Cells(2, 2), ws.Cells(lastR, 2)), _
                        SortOn:=xlSortOnValues, Order:=xlDescending, DataOption:=xlSortNormal
        .SortFields.Add Key:=ws.Range(ws.Cells(2, 4), ws.Cells(lastR, 4)), _
                        SortOn:=xlSortOnValues, Order:=xlAscending, DataOption:=xlSortNormal
        .SetRange ws.Range(ws.Cells(1, 1), ws.Cells(lastR, UNKNOWN_ANALYSIS_LAST_COL))
        .Header = xlYes
        .Apply
    End With
End Sub

Public Function CaptureAnalysisReviews(ByVal ws As Worksheet, ByVal statusColumn As Long, _
                                        ByVal memoColumn As Long, ByVal keyColumn As Long) As Object
    Dim reviews As Object
    Dim lastR As Long, r As Long, dataRows As Long
    Dim keyText As String, baseKey As String, evidenceDigest As String
    Dim statusText As String, memoText As String, kindText As String
    Dim firstValues As Variant, statusValues As Variant, memoValues As Variant, keyValues As Variant
    Dim kindValues As Variant
    Dim reviewRange As Range, formulaCells As Range, errorCells As Range
    Dim seenKeys As Object
    Set reviews = CreateObject("Scripting.Dictionary")
    reviews.CompareMode = vbTextCompare
    Set seenKeys = CreateObject("Scripting.Dictionary")
    seenKeys.CompareMode = vbTextCompare
    If ws Is Nothing Then
        Set CaptureAnalysisReviews = reviews
        Exit Function
    End If
    lastR = LastUsedRowInSheet(ws)
    If lastR < 2 Then
        Set CaptureAnalysisReviews = reviews
        Exit Function
    End If
    dataRows = lastR - 1
    Set reviewRange = Union( _
        ws.Range(ws.Cells(2, statusColumn), ws.Cells(lastR, statusColumn)), _
        ws.Range(ws.Cells(2, memoColumn), ws.Cells(lastR, memoColumn)), _
        ws.Range(ws.Cells(2, keyColumn), ws.Cells(lastR, keyColumn)))
    If Not TryFindFirstFormulaCell(reviewRange, formulaCells) Then _
        Err.Raise vbObjectError + 4625, "CaptureAnalysisReviews", _
                  ws.Name & "の確認欄・内部キーを数式検査できませんでした。"
    If Not TryFindFirstErrorConstantCell(reviewRange, errorCells) Then _
        Err.Raise vbObjectError + 4626, "CaptureAnalysisReviews", _
                  ws.Name & "の確認欄・内部キーをExcelエラー検査できませんでした。"
    If Not formulaCells Is Nothing Then _
        Err.Raise vbObjectError + 4621, "CaptureAnalysisReviews", _
                  ws.Name & "の確認欄または内部キーに数式があります。"
    If Not errorCells Is Nothing Then _
        Err.Raise vbObjectError + 4622, "CaptureAnalysisReviews", _
                  ws.Name & "の確認欄または内部キーにExcelエラー値があります。"
    firstValues = ws.Range(ws.Cells(2, 1), ws.Cells(lastR, 1)).Value2
    statusValues = ws.Range(ws.Cells(2, statusColumn), ws.Cells(lastR, statusColumn)).Value2
    memoValues = ws.Range(ws.Cells(2, memoColumn), ws.Cells(lastR, memoColumn)).Value2
    keyValues = ws.Range(ws.Cells(2, keyColumn), ws.Cells(lastR, keyColumn)).Value2
    If StrComp(ws.Name, SH_ANALYSIS_UNKNOWN, vbTextCompare) = 0 Then _
        kindValues = ws.Range(ws.Cells(2, 3), ws.Cells(lastR, 3)).Value2
    For r = 1 To dataRows
        keyText = CellText(AnalysisColumnValue(keyValues, r, dataRows))
        If Len(keyText) > 0 Then
            baseKey = AnalysisBaseKey(keyText, evidenceDigest)
            If Len(baseKey) = 0 Then _
                Err.Raise vbObjectError + 4623, "CaptureAnalysisReviews", _
                          ws.Name & " " & CStr(r + 1) & "行目の確認キー本体がありません。"
            If seenKeys.Exists(baseKey) Then _
                Err.Raise vbObjectError + 4617, "CaptureAnalysisReviews", _
                          ws.Name & "の確認キーが重複しています: " & baseKey
            seenKeys.Add baseKey, True
            statusText = CellText(AnalysisColumnValue(statusValues, r, dataRows))
            If Len(statusText) = 0 Then statusText = ANALYSIS_STATUS_UNREVIEWED
            memoText = CellText(AnalysisColumnValue(memoValues, r, dataRows))
            kindText = vbNullString
            If StrComp(ws.Name, SH_ANALYSIS_UNKNOWN, vbTextCompare) = 0 Then _
                kindText = CellText(AnalysisColumnValue(kindValues, r, dataRows))
            If Not IsAnalysisReviewStatusForSheet(ws.Name, statusText, kindText) Then _
                Err.Raise vbObjectError + 4615, "CaptureAnalysisReviews", _
                          ws.Name & " " & CStr(r + 1) & _
                          "行目の確認状況が行の種類に適合しません: " & statusText
            If Len(memoText) > ANALYSIS_REVIEW_MEMO_MAX Then _
                Err.Raise vbObjectError + 4616, "CaptureAnalysisReviews", _
                          ws.Name & " " & CStr(r + 1) & "行目の確認メモが" & _
                          CStr(ANALYSIS_REVIEW_MEMO_MAX) & "文字を超えています。"
            '既定の未確認・メモなしは再生成時も同じになるため辞書へ保持しない。
            '利用者が実際に確認した行だけを退避し、大規模案件のメモリ使用を抑える。
            If statusText <> ANALYSIS_STATUS_UNREVIEWED Or Len(memoText) > 0 Then
                reviews.Add baseKey, Array(statusText, memoText, evidenceDigest)
            End If
        ElseIf HasText(AnalysisColumnValue(firstValues, r, dataRows)) Or _
               HasText(AnalysisColumnValue(statusValues, r, dataRows)) Or _
               HasText(AnalysisColumnValue(memoValues, r, dataRows)) Then
            Err.Raise vbObjectError + 4619, "CaptureAnalysisReviews", _
                      ws.Name & " " & CStr(r + 1) & "行目に確認キーがありません。"
        End If
    Next r
    Set CaptureAnalysisReviews = reviews
End Function

Public Function AnalysisReviewValues(ByVal reviews As Object, ByVal keyText As String, _
                                     ByVal currentEvidenceDigest As String) As Variant
    Dim storedValues As Variant, storedDigest As String
    If Not reviews Is Nothing Then
        If reviews.Exists(keyText) Then
            storedValues = reviews(keyText)
            If UBound(storedValues) >= 2 Then storedDigest = CStr(storedValues(2))
            If Len(currentEvidenceDigest) > 0 And _
               StrComp(storedDigest, currentEvidenceDigest, vbBinaryCompare) <> 0 Then
                AnalysisReviewValues = Array(ANALYSIS_STATUS_FOLLOWUP, CStr(storedValues(1)), True)
            Else
                AnalysisReviewValues = Array(CStr(storedValues(0)), CStr(storedValues(1)), False)
            End If
            Exit Function
        End If
    End If
    AnalysisReviewValues = Array(ANALYSIS_STATUS_UNREVIEWED, vbNullString, False)
End Function

Private Function IsAnalysisReviewStatusForSheet(ByVal sheetName As String, _
                                                ByVal statusText As String, _
                                                ByVal kindText As String) As Boolean
    statusText = Trim$(statusText)
    If StrComp(sheetName, SH_ANALYSIS_SHIFT, vbTextCompare) = 0 Or _
       StrComp(sheetName, SH_ANALYSIS_FLOW, vbTextCompare) = 0 Then
        Select Case statusText
            Case ANALYSIS_STATUS_UNREVIEWED, ANALYSIS_STATUS_SHIFT_CONFIRMED, _
                 ANALYSIS_STATUS_EXCLUDED, ANALYSIS_STATUS_FOLLOWUP
                IsAnalysisReviewStatusForSheet = True
        End Select
    ElseIf StrComp(sheetName, SH_ANALYSIS_UNKNOWN, vbTextCompare) = 0 Then
        If StrComp(kindText, "原資不明候補", vbTextCompare) = 0 Then
            Select Case statusText
                Case ANALYSIS_STATUS_UNREVIEWED, ANALYSIS_STATUS_SOURCE_CONFIRMED, _
                     ANALYSIS_STATUS_EXCLUDED, ANALYSIS_STATUS_FOLLOWUP
                    IsAnalysisReviewStatusForSheet = True
            End Select
        ElseIf StrComp(kindText, "使途不明候補", vbTextCompare) = 0 Then
            Select Case statusText
                Case ANALYSIS_STATUS_UNREVIEWED, ANALYSIS_STATUS_USE_CONFIRMED, _
                     ANALYSIS_STATUS_EXCLUDED, ANALYSIS_STATUS_FOLLOWUP
                    IsAnalysisReviewStatusForSheet = True
            End Select
        End If
    Else
        IsAnalysisReviewStatusForSheet = IsAnalysisReviewStatus(statusText)
    End If
End Function


Private Function AnalysisColumnValue(ByRef columnData As Variant, ByVal dataIndex As Long, _
                                     ByVal dataRows As Long) As Variant
    If dataRows = 1 Then
        AnalysisColumnValue = columnData
    Else
        AnalysisColumnValue = columnData(dataIndex, 1)
    End If
End Function


Public Sub FlushAnalysisBuffer(ByVal ws As Worksheet, ByRef buffer() As Variant, ByVal bufferCount As Long, _
                                ByRef nextOutputRow As Long, ByVal lastColumn As Long)
    Dim tail() As Variant
    Dim r As Long, c As Long
    If bufferCount <= 0 Then Exit Sub
    If bufferCount = UBound(buffer, 1) Then
        ws.Range(ws.Cells(nextOutputRow, 1), _
                 ws.Cells(nextOutputRow + bufferCount - 1, lastColumn)).Value = buffer
    Else
        ReDim tail(1 To bufferCount, 1 To lastColumn)
        For r = 1 To bufferCount
            For c = 1 To lastColumn
                tail(r, c) = buffer(r, c)
            Next c
        Next r
        ws.Range(ws.Cells(nextOutputRow, 1), _
                 ws.Cells(nextOutputRow + bufferCount - 1, lastColumn)).Value = tail
    End If
    nextOutputRow = nextOutputRow + bufferCount
End Sub

Private Sub AnalysisAmountSearchBounds(ByVal amountValue As Double, ByVal absoluteTolerance As Double, _
                                       ByVal rateTolerance As Double, ByRef lowerAmount As Double, _
                                       ByRef upperAmount As Double)
    AutoCandidateAmountSearchBounds amountValue, lowerAmount, upperAmount, _
                                    absoluteTolerance, rateTolerance
    If upperAmount > MAX_ABS_AMOUNT Then upperAmount = MAX_ABS_AMOUNT
End Sub

Private Function LowerBoundAnalysisAmount(ByRef amounts() As Double, ByVal itemCount As Long, _
                                          ByVal targetValue As Double) As Long
    Dim low As Long, high As Long, mid As Long
    low = 1
    high = itemCount + 1
    Do While low < high
        mid = low + (high - low) \ 2
        If mid <= itemCount And amounts(mid) < targetValue Then low = mid + 1 Else high = mid
    Loop
    LowerBoundAnalysisAmount = low
End Function

Private Function UpperBoundAnalysisAmount(ByRef amounts() As Double, ByVal itemCount As Long, _
                                          ByVal targetValue As Double) As Long
    Dim low As Long, high As Long, mid As Long
    low = 1
    high = itemCount + 1
    Do While low < high
        mid = low + (high - low) \ 2
        If mid <= itemCount And amounts(mid) <= targetValue Then low = mid + 1 Else high = mid
    Loop
    UpperBoundAnalysisAmount = low - 1
End Function

Private Sub QuickSortAnalysisAmounts(ByRef amounts() As Double, ByRef sourceRows() As Long, _
                                     ByVal firstIndex As Long, ByVal lastIndex As Long)
    Dim low As Long, high As Long
    Dim pivot As Double, tempAmount As Double
    Dim tempRow As Long
    low = firstIndex
    high = lastIndex
    pivot = amounts((firstIndex + lastIndex) \ 2)
    Do While low <= high
        Do While amounts(low) < pivot
            low = low + 1
        Loop
        Do While amounts(high) > pivot
            high = high - 1
        Loop
        If low <= high Then
            tempAmount = amounts(low): amounts(low) = amounts(high): amounts(high) = tempAmount
            tempRow = sourceRows(low): sourceRows(low) = sourceRows(high): sourceRows(high) = tempRow
            low = low + 1
            high = high - 1
        End If
    Loop
    If firstIndex < high Then QuickSortAnalysisAmounts amounts, sourceRows, firstIndex, high
    If low < lastIndex Then QuickSortAnalysisAmounts amounts, sourceRows, low, lastIndex
End Sub

Private Function TryGetAnalysisTime(ByVal valueIn As Variant, ByRef timeFraction As Double) As Boolean
    Dim ok As Boolean, normalizedTime As Variant
    If Not HasText(valueIn) Then Exit Function
    normalizedTime = NormalizeTimeInput(valueIn, ok)
    If Not ok Then Exit Function
    timeFraction = CDbl(CDate(normalizedTime)) - Fix(CDbl(CDate(normalizedTime)))
    TryGetAnalysisTime = True
End Function

Private Function AnalysisTimeOutputValue(ByVal valueIn As Variant) As Variant
    Dim timeFraction As Double
    If TryGetAnalysisTime(valueIn, timeFraction) Then
        AnalysisTimeOutputValue = timeFraction
    Else
        AnalysisTimeOutputValue = Empty
    End If
End Function

Private Function FormatAnalysisElapsedMinutes(ByVal minuteValue As Double) As String
    Dim wholeMinutes As Long, days As Long, hours As Long, minutes As Long
    If minuteValue < 0 Then minuteValue = -minuteValue
    If minuteValue > 2147483646# Then
        FormatAnalysisElapsedMinutes = Format$(minuteValue / 1440#, "0.0") & "日"
        Exit Function
    End If
    wholeMinutes = CLng(minuteValue + 0.5)
    days = wholeMinutes \ 1440
    hours = (wholeMinutes Mod 1440) \ 60
    minutes = wholeMinutes Mod 60
    If days > 0 Then
        FormatAnalysisElapsedMinutes = CStr(days) & "日" & CStr(hours) & "時間" & CStr(minutes) & "分"
    ElseIf hours > 0 Then
        FormatAnalysisElapsedMinutes = CStr(hours) & "時間" & CStr(minutes) & "分"
    Else
        FormatAnalysisElapsedMinutes = CStr(minutes) & "分"
    End If
End Function

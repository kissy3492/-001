﻿Attribute VB_Name = "modManualFlow"
Option Explicit

'自動探索から漏れる複雑な束ね方を、資金操作表または互換用候補明細から明示的に登録する。
'削除ではなく有効/無効を保持し、誤操作後も監査可能にする。

Private Const MANUAL_ACTIVE As String = "有効"
Private Const MANUAL_INACTIVE As String = "無効"
Private Const DETAIL_KIND_COL As Long = 8       'H
Private Const DETAIL_REFERENCE_COL As Long = 9  'I
Private Const DETAIL_SOURCE_KEY_COL As Long = 11 'K
Private Const DETAIL_SELECTED_COL As Long = 12  'L
Private Const MANUAL_FLOW_CAPACITY_BASE_COLUMNS As Long = 16
Private Const MANUAL_FLOW_MANUAL_WORK_COLUMNS As Long = 36
Private Const MANUAL_FLOW_OUTPUT_WORK_COLUMNS As Long = 44
Private Const MANUAL_FLOW_CAPACITY_LONG_MAX As Double = 2147483647#
Private Const MANUAL_APPEND_OUTPUT As Long = 1
Private Const MANUAL_APPEND_MISSING_SOURCE As Long = 2
Private Const MANUAL_APPEND_AMOUNT_INVALID As Long = 3
Private Const MANUAL_FLOW_RECOVERY_FATAL_ERROR As Long = vbObjectError + 4499
Private Const MANUAL_FLOW_RECOVERY_FATAL_SOURCE As String = "ManualFlowRecoveryFatal/"

'配賦変換は保存表を1回だけ読み、候補キーから追跡指定額を引ける索引を共有する。
'判断や金額を補完せず、破損・重複は分析出力前にfail closedとする。
Public Function CaptureManualFlowAllocationIndex() As Object
    Dim result As Object, ws As Worksheet, data As Variant
    Dim lastR As Long, r As Long, manualID As String, baseKey As String
    Dim transactionIDs As String, evidenceDigest As String, statusText As String
    Dim amountValue As Double
    Set result = CreateObject("Scripting.Dictionary")
    result.CompareMode = vbBinaryCompare
    Set ws = GetSheet(SH_WORK_MANUAL_FLOW)
    lastR = LastDataRowInColumns(ws, 1, MANUAL_FLOW_STORE_LAST_COL)
    If lastR < 2 Then
        Set CaptureManualFlowAllocationIndex = result
        Exit Function
    End If
    data = ws.Range(ws.Cells(2, 1), _
                    ws.Cells(lastR, MANUAL_FLOW_STORE_LAST_COL)).Value2
    For r = 1 To UBound(data, 1)
        If CellText(data(r, MANUAL_FLOW_COL_ACTIVE)) = MANUAL_ACTIVE Then
            manualID = CellText(data(r, MANUAL_FLOW_COL_ID))
            baseKey = CellText(data(r, MANUAL_FLOW_COL_KEY))
            transactionIDs = CellText(data(r, MANUAL_FLOW_COL_TX_IDS))
            evidenceDigest = CellText(data(r, MANUAL_FLOW_COL_EVIDENCE))
            statusText = CellText(data(r, MANUAL_FLOW_COL_STATUS))
            If Len(manualID) = 0 Or baseKey <> "MANUAL>" & manualID Or _
               Len(transactionIDs) = 0 Or Not IsNumeric(data(r, MANUAL_FLOW_COL_AMOUNT)) Or _
               Not ManualEvidenceDigestIsValid(evidenceDigest) Or _
               Not ManualFlowReviewStatus(statusText) Or result.Exists(baseKey) Then _
                Err.Raise vbObjectError + 5040, "CaptureManualFlowAllocationIndex", _
                          "有効な手動候補の配賦情報が空欄・重複・不正です: " & baseKey
            amountValue = CDbl(data(r, MANUAL_FLOW_COL_AMOUNT))
            If amountValue <= 0# Or amountValue > MAX_ABS_AMOUNT Then _
                Err.Raise vbObjectError + 5041, "CaptureManualFlowAllocationIndex", _
                          "手動候補の追跡指定額が不正です: " & baseKey
            result.Add baseKey, Array(amountValue, transactionIDs, _
                                      evidenceDigest, statusText)
        End If
    Next r
    Set CaptureManualFlowAllocationIndex = result
End Function

Private Sub RequireManualFlowAuthoritativeStructure()
    Dim problems As String
    If Not ValidateAuthoritativeDataStructure(problems, True, False) Then _
        Err.Raise vbObjectError + 5042, "RequireManualFlowAuthoritativeStructure", _
                  "権威データ構造の検証に失敗しました。" & vbCrLf & problems
End Sub

Private Function ManualFlowMutationWorkRows( _
        ByVal transactionRows As Long, ByVal manualStoreRows As Long, _
        ByVal plannedManualRows As Long, _
        ByVal flowRows As Long) As Double
    Dim cellWork As Double
    If transactionRows < 0 Or manualStoreRows < 0 Or plannedManualRows < 0 Or _
       flowRows < 0 Then _
        Err.Raise vbObjectError + 5021, "ManualFlowMutationWorkRows", _
                  "手動候補操作の事前安全検査行数に負数が含まれています。"
    'W_取引21列、手動候補のsnapshot/data/読戻しと計画配列36列、
    '資金フロー追跡のsnapshot/読戻し44列を同時保持する上界とする。
    cellWork = CDbl(transactionRows) * CDbl(WORK_TX_COL_PERSON_ID) + _
               (CDbl(manualStoreRows) + CDbl(plannedManualRows)) * _
               CDbl(MANUAL_FLOW_MANUAL_WORK_COLUMNS) + _
               CDbl(flowRows) * CDbl(MANUAL_FLOW_OUTPUT_WORK_COLUMNS)
    ManualFlowMutationWorkRows = ManualFlowEquivalentWorkRows(cellWork)
End Function

Private Function ManualFlowEquivalentWorkRows(ByVal cellWork As Double) As Double
    Dim workRows As Double
    If cellWork < 0# Or _
       cellWork > MANUAL_FLOW_CAPACITY_LONG_MAX * _
                  CDbl(MANUAL_FLOW_CAPACITY_BASE_COLUMNS) Then _
        Err.Raise vbObjectError + 5024, "ManualFlowEquivalentWorkRows", _
                  "手動候補操作の安全規模を16列相当行へ換算できません。"
    workRows = Int( _
        (cellWork + CDbl(MANUAL_FLOW_CAPACITY_BASE_COLUMNS) - 1#) / _
        CDbl(MANUAL_FLOW_CAPACITY_BASE_COLUMNS))
    If workRows < 0# Or workRows > MANUAL_FLOW_CAPACITY_LONG_MAX Then _
        Err.Raise vbObjectError + 5024, "ManualFlowEquivalentWorkRows", _
                  "手動候補操作の安全規模を16列相当行へ換算できません。"
    ManualFlowEquivalentWorkRows = workRows
End Function

Private Function ManualFlowProspectiveStoreRowsAreSafe( _
        ByVal manualStoreRows As Long, ByVal plannedManualRows As Long, _
        ByRef prospectiveRows As Double) As Boolean
    'Long同士を先に加算すると境界でoverflowするため、必ずDoubleへ拡張してから合算する。
    prospectiveRows = CDbl(manualStoreRows) + CDbl(plannedManualRows)
    If manualStoreRows < 0 Or plannedManualRows < 0 Then Exit Function
    If prospectiveRows < 0# Or _
       prospectiveRows > CDbl(MAX_INTERNAL_STORE_DATA_ROWS) Then Exit Function
    If prospectiveRows > MANUAL_FLOW_CAPACITY_LONG_MAX Then Exit Function
    ManualFlowProspectiveStoreRowsAreSafe = True
End Function

Public Function RequireManualFlowMutationCapacity( _
        ByVal operationName As String, _
        Optional ByVal plannedManualRows As Long = 0) As Boolean
    Dim wsTx As Worksheet, wsManual As Worksheet, wsFlow As Worksheet
    Dim txRows As Long, manualRows As Long, flowRows As Long
    Dim workRows As Double, prospectiveManualRows As Double
    If Not SheetExists(SH_WORK_TX) Or Not SheetExists(SH_WORK_MANUAL_FLOW) Or _
       Not SheetExists(SH_ANALYSIS_FLOW) Then _
        Err.Raise vbObjectError + 5022, "RequireManualFlowMutationCapacity", _
                  "手動候補操作に必要な内部保管を取得できません。"
    Set wsTx = GetSheet(SH_WORK_TX)
    Set wsManual = GetSheet(SH_WORK_MANUAL_FLOW)
    Set wsFlow = GetSheet(SH_ANALYSIS_FLOW)
    txRows = LastDataRowInColumns(wsTx, 1, WORK_TX_COL_PERSON_ID)
    If txRows >= 2 Then txRows = txRows - 1 Else txRows = 0
    manualRows = LastDataRowInColumns(wsManual, 1, MANUAL_FLOW_STORE_LAST_COL)
    If manualRows >= 2 Then manualRows = manualRows - 1 Else manualRows = 0
    flowRows = LastDataRowInColumns(wsFlow, 1, FLOW_ANALYSIS_LAST_COL)
    If flowRows >= 2 Then flowRows = flowRows - 1 Else flowRows = 0
    If txRows > MAX_INTERNAL_STORE_DATA_ROWS Or _
       manualRows > MAX_INTERNAL_STORE_DATA_ROWS Or _
       flowRows > MAX_ANALYSIS_OUTPUT_ROWS Then _
        Err.Raise vbObjectError + 5022, "RequireManualFlowMutationCapacity", _
                  "手動候補操作の内部保管が実用上限を超えています。"
    If Not ManualFlowProspectiveStoreRowsAreSafe( _
               manualRows, plannedManualRows, prospectiveManualRows) Then
        '負数は既存の入力検査(+5021)へ委ね、それ以外の保存上限超過は+5022で停止する。
        If manualRows < 0 Or plannedManualRows < 0 Then _
            workRows = ManualFlowMutationWorkRows( _
                           txRows, manualRows, plannedManualRows, flowRows)
        Err.Raise vbObjectError + 5022, "RequireManualFlowMutationCapacity", _
                  "追加予定を含む手動候補が保存上限（" & _
                  Format$(MAX_INTERNAL_STORE_DATA_ROWS, "#,##0") & _
                  "件）を超えています。"
    End If
    workRows = ManualFlowMutationWorkRows( _
                   txRows, manualRows, plannedManualRows, flowRows)
    If workRows > MANUAL_FLOW_CAPACITY_LONG_MAX Then _
        Err.Raise vbObjectError + 5023, "RequireManualFlowMutationCapacity", _
                  "手動候補操作の事前安全規模を計算できません。"
    If Len(Trim$(operationName)) = 0 Then operationName = "手動候補の操作"
    RequireManualFlowMutationCapacity = ConfirmLargeArrayOperation( _
        CLng(workRows), operationName & _
        "（W_取引・手動候補退避の事前安全検査）")
End Function

Public Function ManualFlowStoreHeaders() As Variant
    ManualFlowStoreHeaders = Array( _
        "手動候補ID", "構成取引ID", "追跡額", "確認状況", "確認メモ", _
        "有効状態", "登録日時", "登録者", "更新日時", "根拠署名", "確認キー")
End Function

Public Sub SetupManualFlowStore(Optional ByVal resetContents As Boolean = False)
    Dim ws As Worksheet
    Set ws = GetOrCreateSheet(SH_WORK_MANUAL_FLOW, False)
    If resetContents Then ResetWorksheet ws
    If Len(CellText(ws.Cells(1, 1).Value)) = 0 Then
        SetRowValues ws.Range("A1"), ManualFlowStoreHeaders()
        FormatOutputHeader ws.Range(ws.Cells(1, 1), ws.Cells(1, MANUAL_FLOW_STORE_LAST_COL))
    End If
    ws.Columns("A:K").NumberFormatLocal = "@"
    ws.Columns("C:C").NumberFormatLocal = "#,##0.########"
    ws.Columns("G:G").NumberFormatLocal = "yyyy/m/d h:mm:ss"
    ws.Columns("I:I").NumberFormatLocal = "yyyy/m/d h:mm:ss"
    SetSheetVeryHiddenSafe ws
    If Not ManualFlowStoreIsVeryHidden(ws) Then _
        Err.Raise vbObjectError + 4971, "SetupManualFlowStore", _
                  "手動資金候補を内部非表示へ戻せません。"
End Sub

Public Sub RegisterManualAnalysisCandidateFromDetail()
    Dim wsDetail As Worksheet, selected As Object
    Dim lastR As Long, r As Long, txID As String
    Dim requestedIDs As String, canonicalIDs As String, savedBaseKey As String
    Dim suggestedAmount As Double, amountInput As Variant, amountValue As Double
    Dim totalWithdrawal As Double, totalDeposit As Double, txCount As Long
    Dim storeSnapshot As Variant, storeSnapshotLastRow As Long, storeChanged As Boolean
    Dim allocationSnapshot As Variant, allocationSnapshotLastRow As Long
    Dim allocationSnapshotDigest As String, allocationSnapshotCaptured As Boolean
    Dim allocationSnapshotCellWork As Double
    Dim analysisBuildStarted As Boolean, rollbackFailed As Boolean
    Dim outputsWereDirty As Boolean, outputDirtyAttempted As Boolean, outputDirtyConfirmed As Boolean
    Dim safetyStopRequired As Boolean
    Dim reviewsWerePending As Boolean
    Dim detailSelectionSnapshot As Object
    Dim detailSelectionVisibility As XlSheetVisibility
    Dim detailSelectionWasActive As Boolean, detailSelectionSnapshotCaptured As Boolean
    Dim detailSelectionAddress As String, detailSelectionRestoreDetail As String
    Dim detailSelectionRestored As Boolean
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim entryEvents As Boolean, entryEventsCaptured As Boolean
    Dim appBeginAttempted As Boolean, applicationLeaseStarted As Boolean
    Dim operationCommitted As Boolean
    Dim mutationStarted As Boolean, cleanupEventsStopped As Boolean
    Dim recoveryStateConfirmed As Boolean, recoveryEnforcementAttempted As Boolean
    Dim recoveryEnforcementFailed As Boolean
    Dim reportingAllowed As Boolean
    Dim appStateRestored As Boolean, entryEventsRestored As Boolean
    Dim eventRestoreRequiredRecovery As Boolean
    Dim eventStateDetail As String, applicationStateDetail As String
    Dim entryRestoreDetail As String, recoveryDetail As String
    Dim confirmedAnalysisWorkloadRows As Double
    On Error GoTo EH
    If Not TryGetManualFlowEnableEvents(entryEvents, eventStateDetail) Then _
        Err.Raise vbObjectError + 5110, _
                  "RegisterManualAnalysisCandidateFromDetail", _
                  "Excelイベントの開始状態を取得できませんでした。 " & _
                  eventStateDetail
    entryEventsCaptured = True
    If Not TrySetManualFlowEnableEventsExact(False, eventStateDetail) Then _
        Err.Raise vbObjectError + 5111, _
                  "RegisterManualAnalysisCandidateFromDetail", _
                  "事前確認より前にExcelイベントを停止できませんでした。 " & _
                  eventStateDetail
    If Not RequireToolReady() Then GoTo CleanExit
    If Not RequireNoPendingAccountInput("手動分析候補の登録") Then GoTo CleanExit
    If Not SheetExists(SH_ANALYSIS_DETAIL) Then GoTo CleanExit
    If Not RequireManualFlowMutationCapacity("手動候補の登録", 1) Then
        SetInputStatus "手動候補の登録を開始せず中止しました。保存内容は変更していません。"
        GoTo CleanExit
    End If
    If Not RequireOutputBuildCapacity("手動候補の登録と分析更新", _
            True, False, False, True, False, False) Then
        SetInputStatus "手動候補の登録を開始せず中止しました。保存内容は変更していません。"
        GoTo CleanExit
    End If
    allocationSnapshotCellWork = _
        CDbl(AllocationLedgerStoredRowCount() + 1) * 10#
    If Not ConfirmAnalysisReviewOperationCapacity( _
            "手動候補の登録と分析更新", confirmedAnalysisWorkloadRows, _
            additionalManualRows:=1, _
            additionalSnapshotCellWork:=allocationSnapshotCellWork * 2#) Then
        SetInputStatus "手動候補の登録を開始せず中止しました。保存内容は変更していません。"
        GoTo CleanExit
    End If
    If Not RequireInternalStoresSafeForWrite(False, False) Then GoTo CleanExit
    Set wsDetail = GetSheet(SH_ANALYSIS_DETAIL)
    reviewsWerePending = HasPendingAnalysisReviewChanges()
    Set selected = CreateObject("Scripting.Dictionary")
    selected.CompareMode = vbTextCompare
    lastR = LastUsedRowInSheet(wsDetail)
    For r = 1 To lastR
        If CellText(wsDetail.Cells(r, DETAIL_KIND_COL).Value) = "取引" And _
           CellText(wsDetail.Cells(r, DETAIL_SELECTED_COL).Value) = "1" Then
            txID = CellText(wsDetail.Cells(r, DETAIL_REFERENCE_COL).Value)
            If Len(txID) > 0 Then selected(txID) = True
        End If
    Next r
    If selected.Count < 2 Then
        MsgBox "候補詳細の取引行を2件以上選択してください。" & vbCrLf & _
               "取引行をダブルクリックすると選択・解除できます。", vbInformation
        GoTo CleanExit
    End If
    requestedIDs = JoinManualDictionaryKeys(selected)
    ValidateManualTransactionIDs requestedIDs, txCount, totalWithdrawal, totalDeposit, _
                                 suggestedAmount, canonicalIDs
    amountInput = Application.InputBox( _
        Prompt:="この候補で追跡する金額を入力してください。" & vbCrLf & _
                "選択取引: " & CStr(txCount) & "件 / 出金計 " & _
                Format$(totalWithdrawal, "#,##0.########") & " / 入金計 " & _
                Format$(totalDeposit, "#,##0.########"), _
        Title:="手動の資金移動候補", Default:=suggestedAmount, Type:=1)
    If VarType(amountInput) = vbBoolean Then
        If CBool(amountInput) = False Then GoTo CleanExit
    End If
    If Not IsNumeric(amountInput) Then
        MsgBox "追跡額は0より大きい有効な金額で入力してください。", vbExclamation
        GoTo CleanExit
    End If
    amountValue = CDbl(amountInput)
    If amountValue <= 0 Or amountValue > MAX_ABS_AMOUNT Or _
       (amountValue > suggestedAmount And _
        Not ManualAmountsMatch(amountValue, suggestedAmount)) Then
        MsgBox "追跡額は0より大きく、出金計と入金計の小さい方（" & _
               Format$(suggestedAmount, "#,##0.########") & _
               "）以下で入力してください。", vbExclamation
        GoTo CleanExit
    End If
    If MsgBox("選択した " & CStr(txCount) & "取引を、追跡額 " & _
              Format$(amountValue, "#,##0.########") & _
              " の手動候補として登録しますか？", _
              vbYesNo + vbQuestion + vbDefaultButton2, "手動候補の確認") <> vbYes Then GoTo CleanExit

    CaptureManualDetailSelectionSnapshot wsDetail, detailSelectionSnapshot, _
                                         detailSelectionVisibility, detailSelectionWasActive, _
                                         detailSelectionAddress
    detailSelectionSnapshotCaptured = True
    CaptureManualFlowStoreSnapshot storeSnapshot, storeSnapshotLastRow
    CaptureAllocationLedgerTransactionSnapshot allocationSnapshot, _
        allocationSnapshotLastRow, allocationSnapshotDigest
    allocationSnapshotCaptured = True
    If Not TryConfirmManualFlowApplicationState(applicationStateDetail) Then _
        RaiseManualFlowRecoveryFatal _
            "RegisterManualAnalysisCandidateFromDetail", 0, _
            "RegisterManualAnalysisCandidateFromDetail", _
            "AppBegin前のApplication状態が安全ではありません。", _
            applicationStateDetail
    AppBegin "手動候補を登録して分析結果を更新しています..."
    appBeginAttempted = True
    applicationLeaseStarted = True
    If Not TrySetManualFlowEnableEventsExact(False, eventStateDetail) Then _
        Err.Raise vbObjectError + 5111, _
                  "RegisterManualAnalysisCandidateFromDetail", _
                  "保存内容の変更前にExcelイベントを停止できませんでした。 " & _
                  eventStateDetail
    outputsWereDirty = OutputsAreDirty()
    outputDirtyAttempted = True
    mutationStarted = True
    MarkOutputsDirty
    outputDirtyConfirmed = True
    storeChanged = True
    SaveManualFlowCandidate canonicalIDs, amountValue, savedBaseKey
    MarkAnalysisReviewsDirty
    analysisBuildStarted = True
    BuildTransactionAnalysisSheetsCore True, True, confirmedAnalysisWorkloadRows, _
                                       False, allocationSnapshotCellWork
    VerifyManualFlowRegistration savedBaseKey, canonicalIDs, amountValue
    MarkAnalysisReviewsClean
    If Not outputsWereDirty Then
        RequireManualFlowAuthoritativeStructure
        MarkOutputsClean
    End If
    operationCommitted = True
    AppEnd
    applicationLeaseStarted = False
CleanExit:
    If Not TrySetManualFlowEnableEventsExact(entryEvents, eventStateDetail) Then _
        Err.Raise vbObjectError + 5112, _
                  "RegisterManualAnalysisCandidateFromDetail", _
                  "処理開始時のExcelイベント状態を復元できませんでした。 " & _
                  eventStateDetail
    entryEventsCaptured = False
    If Not operationCommitted Then Exit Sub
    On Error Resume Next
    MsgBox "手動の資金移動候補を登録し、分析結果へ反映しました。" & vbCrLf & _
           "候補詳細で個別の確認状況とメモを入力できます。", vbInformation
    Err.Clear
    On Error GoTo 0
    Exit Sub
EH:
    errorNumber = Err.Number: errorDescription = Err.Description
    errorSource = Err.Source
    If IsManualFlowUpstreamRecoveryFatal(errorNumber, errorSource) Then
        Call TryStopManualFlowEventsForBookWrites(eventStateDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    If Not appBeginAttempted And _
       StrComp(errorSource, "AppBegin", vbBinaryCompare) = 0 Then
        RaiseManualFlowRecoveryFatal _
            "RegisterManualAnalysisCandidateFromDetail", errorNumber, _
            errorSource, errorDescription, _
            "AppBeginが正常終了せず、Application leaseの所有を取得できませんでした。"
    End If
    If entryEventsCaptured Then
        cleanupEventsStopped = _
            TryStopManualFlowEventsForBookWrites(eventStateDetail)
        If Not cleanupEventsStopped Then _
            AppendManualFlowFailureDetail errorDescription, _
                "失敗復旧の開始前にExcelイベント停止を確認できません: " & _
                eventStateDetail
    Else
        AppendManualFlowFailureDetail errorDescription, _
            "Excelイベントの開始状態を取得していません。"
    End If

    If operationCommitted Then
        safetyStopRequired = True
        AppendManualFlowFailureDetail errorDescription, _
            "手動候補と分析結果は確定済みのため、開始前の退避値へ戻しません。"
    ElseIf mutationStarted And cleanupEventsStopped Then
        On Error Resume Next
        Err.Clear
        If storeChanged Then _
            RestoreManualFlowStoreSnapshot storeSnapshot, storeSnapshotLastRow
        If Err.Number <> 0 Then
            rollbackFailed = True
            AppendManualFlowFailureDetail errorDescription, _
                "手動候補保存のロールバック失敗: " & Err.Description
        End If
        Err.Clear
        If analysisBuildStarted And allocationSnapshotCaptured Then
            RestoreAllocationLedgerTransactionSnapshot allocationSnapshot, _
                allocationSnapshotLastRow, allocationSnapshotDigest
            If Err.Number <> 0 Then
                rollbackFailed = True
                AppendManualFlowFailureDetail errorDescription, _
                    "配賦元帳のロールバック失敗: " & Err.Description
            End If
            Err.Clear
        End If
        If analysisBuildStarted And detailSelectionSnapshotCaptured Then
            detailSelectionRestored = RestoreManualDetailSelectionSnapshot( _
                detailSelectionSnapshot, detailSelectionVisibility, _
                detailSelectionWasActive, detailSelectionAddress, _
                detailSelectionRestoreDetail)
            If Not detailSelectionRestored Then
                rollbackFailed = True
                If Len(detailSelectionRestoreDetail) = 0 Then _
                    detailSelectionRestoreDetail = _
                        "候補詳細の選択状態を復元・照合できません。"
                AppendManualFlowFailureDetail errorDescription, _
                    "選択状態の復元失敗: " & detailSelectionRestoreDetail
            End If
        End If
        Err.Clear
        If outputDirtyAttempted Then
            If Not outputDirtyConfirmed Then safetyStopRequired = True
            If Not EnsureManualFlowFailureOutputsDirty(errorDescription) Then _
                safetyStopRequired = True
        End If
        If rollbackFailed Then safetyStopRequired = True
        If safetyStopRequired Then
            MarkAnalysisReviewsDirty
        ElseIf analysisBuildStarted Or reviewsWerePending Then
            MarkAnalysisReviewsDirty
        Else
            MarkAnalysisReviewsClean
        End If
        If Err.Number <> 0 Then
            safetyStopRequired = True
            AppendManualFlowFailureDetail errorDescription, _
                "分析要更新状態の記録エラー: " & Err.Description
        End If
        Err.Clear
        On Error GoTo 0
    ElseIf mutationStarted Then
        rollbackFailed = True
        safetyStopRequired = True
        AppendManualFlowFailureDetail errorDescription, _
            "Excelイベント停止が未確認のため、保存記録・配賦元帳・選択状態へ退避値を再書込みしませんでした。"
    End If

    If safetyStopRequired And cleanupEventsStopped And _
       Not recoveryEnforcementAttempted Then
        EnforceManualFlowRecoveryStateTerminal _
            "RegisterManualAnalysisCandidateFromDetail", _
            "手動候補登録の失敗復旧", recoveryDetail, _
            recoveryEnforcementAttempted, recoveryEnforcementFailed, _
            errorNumber, errorSource, errorDescription, _
            applicationLeaseStarted
    End If

    appStateRestored = TryEndManualFlowAppLease( _
                           applicationLeaseStarted, appBeginAttempted, _
                           applicationStateDetail)
    If Not appStateRestored Then
        safetyStopRequired = True
        AppendManualFlowFailureDetail errorDescription, applicationStateDetail
        cleanupEventsStopped = False
        If entryEventsCaptured Then _
            cleanupEventsStopped = _
                TryStopManualFlowEventsForBookWrites(eventStateDetail)
        If cleanupEventsStopped And mutationStarted And _
           Not recoveryEnforcementAttempted Then
            EnforceManualFlowRecoveryStateTerminal _
                "RegisterManualAnalysisCandidateFromDetail", _
                "手動候補登録後のExcel状態復元失敗", _
                recoveryDetail, recoveryEnforcementAttempted, _
                recoveryEnforcementFailed, errorNumber, errorSource, _
                errorDescription, applicationLeaseStarted
        ElseIf Not cleanupEventsStopped Then
            AppendManualFlowFailureDetail errorDescription, _
                "Excel状態復元失敗後にイベント停止を確認できず、Recovery書込みを見送りました。"
        End If
        If applicationLeaseStarted And Not recoveryEnforcementFailed Then
            appStateRestored = TryEndManualFlowAppLease( _
                                   applicationLeaseStarted, _
                                   appBeginAttempted, applicationStateDetail)
            If Not appStateRestored Then _
                AppendManualFlowFailureDetail errorDescription, _
                    "Excel状態の通常復元再試行にも失敗しました: " & _
                    applicationStateDetail
        End If
        If Not appStateRestored And appBeginAttempted And _
           Not recoveryEnforcementFailed Then
            appStateRestored = _
                TryForceRestoreManualFlowApplicationState( _
                    applicationLeaseStarted, appBeginAttempted, _
                    applicationStateDetail)
            If Not appStateRestored Then
                AppendManualFlowFailureDetail errorDescription, _
                    "Excel状態の強制復元と全状態読戻しにも失敗しました: " & _
                    applicationStateDetail
                cleanupEventsStopped = _
                    TryStopManualFlowEventsForBookWrites(eventStateDetail)
                If Not cleanupEventsStopped Then _
                    AppendManualFlowFailureDetail errorDescription, _
                        "強制復元失敗後のイベントFalse収束にも失敗し、状態は不明です: " & _
                        eventStateDetail
            End If
        ElseIf recoveryEnforcementFailed And Not appStateRestored Then
            AppendManualFlowFailureDetail errorDescription, _
                "要復旧処理自体が失敗したため、Excel状態の通常再試行と強制復元を見送りました。"
        End If
    End If

    If (mutationStarted Or operationCommitted) And appStateRestored Then
        cleanupEventsStopped = False
        If entryEventsCaptured Then _
            cleanupEventsStopped = _
                TryStopManualFlowEventsForBookWrites(eventStateDetail)
        If safetyStopRequired And cleanupEventsStopped And _
           Not recoveryStateConfirmed And Not recoveryEnforcementAttempted Then
            EnforceManualFlowRecoveryStateTerminal _
                "RegisterManualAnalysisCandidateFromDetail", _
                "手動候補登録の安全停止", recoveryDetail, _
                recoveryEnforcementAttempted, recoveryEnforcementFailed, _
                errorNumber, errorSource, errorDescription, _
                applicationLeaseStarted
        End If
        reportingAllowed = cleanupEventsStopped And _
                           (Not safetyStopRequired Or recoveryStateConfirmed)
        If reportingAllowed Then
            On Error Resume Next
            Err.Clear
            If operationCommitted Then
                AddCheck "エラー", "手動候補登録の確定後処理", _
                    "Err " & CStr(errorNumber) & ": " & errorDescription
                If recoveryStateConfirmed Then
                    SetInputStatus _
                        "手動候補と分析結果は確定済みですが、後処理失敗を要復旧状態として記録しました。", _
                        True
                Else
                    SetInputStatus _
                        "手動候補と分析結果は確定済みですが、後処理後の安全状態を確認できません。上書き保存せずExcelを再起動してください。", _
                        True
                End If
            ElseIf safetyStopRequired Then
                AddCheck "エラー", "手動候補登録ロールバック", _
                    "Err " & CStr(errorNumber) & ": " & errorDescription
                If recoveryStateConfirmed Then
                    SetInputStatus _
                        "手動候補の登録に失敗し、ロールバック不成立を要復旧状態として記録しました。", _
                        True
                Else
                    SetInputStatus _
                        "手動候補の登録に失敗し、安全状態を一意に確認できません。上書き保存せずExcelを再起動してください。", _
                        True
                End If
            ElseIf IsUserCancelError(errorNumber) Then
                SetInputStatus _
                    "手動候補の登録処理を中断し、操作開始前の保存内容へ戻しました。"
            Else
                AddCheck "エラー", "手動候補登録", _
                    "Err " & CStr(errorNumber) & ": " & errorDescription
                SetInputStatus _
                    "手動候補の登録に失敗し、操作開始前の保存内容へ戻しました。C_チェックを確認してください。"
            End If
            Err.Clear
            On Error GoTo 0
        Else
            safetyStopRequired = True
            AppendManualFlowFailureDetail errorDescription, _
                "Excelイベント停止または復旧状態が未確認のため、チェック・状態表示を書き込みませんでした。"
        End If
    End If

    If entryEventsCaptured And appStateRestored Then
        entryEventsRestored = TryRestoreManualFlowEntryEvents( _
            entryEvents, mutationStarted Or operationCommitted, _
            appStateRestored And _
                ((Not mutationStarted And Not operationCommitted) Or _
                 (mutationStarted And Not operationCommitted And _
                  Not safetyStopRequired And Not rollbackFailed)), _
            "手動候補登録のイベント復元失敗: " & errorDescription, _
            recoveryStateConfirmed, recoveryEnforcementAttempted, _
            recoveryEnforcementFailed, _
            eventRestoreRequiredRecovery, _
            entryRestoreDetail)
        If eventRestoreRequiredRecovery Then safetyStopRequired = True
        If Not entryEventsRestored Then safetyStopRequired = True
        AppendManualFlowFailureDetail errorDescription, entryRestoreDetail
    ElseIf Not entryEventsCaptured Then
        safetyStopRequired = True
    Else
        safetyStopRequired = True
        cleanupEventsStopped = _
            TryStopManualFlowEventsForBookWrites(eventStateDetail)
        If cleanupEventsStopped Then
            AppendManualFlowFailureDetail errorDescription, _
                "Application状態が未復元のため開始時イベント値へ戻さず、Falseへ収束させました。"
        Else
            AppendManualFlowFailureDetail errorDescription, _
                "Application状態が未復元で、イベントFalseへの収束も確認できません。"
        End If
    End If

    If IsUserCancelError(errorNumber) And Not safetyStopRequired And _
       Not operationCommitted Then Exit Sub
    On Error Resume Next
    If Not appStateRestored Then
        If operationCommitted Then
            MsgBox "手動候補と分析結果は確定済みですが、Application状態は不明です。" & _
                   vbCrLf & "Excelイベントを開始時の値へ戻していません。" & _
                   vbCrLf & "現在のブックを上書きせず、Excelを再起動してください。" & _
                   vbCrLf & "Err " & CStr(errorNumber) & ": " & _
                   errorDescription, vbCritical
        Else
            MsgBox "手動候補の登録を完了できず、Application状態も確認できません。" & _
                   vbCrLf & "Excelイベントを開始時の値へ戻していません。" & _
                   vbCrLf & "現在のブックを上書きせず、Excelを再起動してください。" & _
                   vbCrLf & "Err " & CStr(errorNumber) & ": " & _
                   errorDescription, vbCritical
        End If
    ElseIf operationCommitted Then
        MsgBox "手動候補と分析結果は確定済みです。" & vbCrLf & _
               IIf(recoveryStateConfirmed, _
                   "後処理の失敗を要復旧状態として記録しました。", _
                   "後処理後の安全状態を確認できません。") & vbCrLf & _
               "現在のブックを上書きせず、Excelを再起動してください。" & _
               vbCrLf & "Err " & CStr(errorNumber) & ": " & _
               errorDescription, vbExclamation
    ElseIf Not mutationStarted Then
        MsgBox "手動候補の登録処理は開始されず、保存内容は変更していません。" & _
               vbCrLf & "Err " & CStr(errorNumber) & ": " & _
               errorDescription, vbExclamation
    Else
        MsgBox "手動候補を登録できませんでした。" & vbCrLf & _
               "Err " & CStr(errorNumber) & ": " & errorDescription, vbExclamation
    End If
    Err.Clear
    On Error GoTo 0
End Sub

Private Sub CaptureManualDetailSelectionSnapshot( _
        ByVal wsDetail As Worksheet, ByRef selectedKeys As Object, _
        ByRef originalVisibility As XlSheetVisibility, ByRef wasActive As Boolean, _
        ByRef activeAddress As String)
    Dim lastR As Long, r As Long
    Dim kindText As String, referenceText As String, selectionKey As String

    If wsDetail Is Nothing Then _
        Err.Raise vbObjectError + 5099, "CaptureManualDetailSelectionSnapshot", _
                  "候補詳細を取得できません。"
    Set selectedKeys = CreateObject("Scripting.Dictionary")
    selectedKeys.CompareMode = vbBinaryCompare
    originalVisibility = wsDetail.Visible
    If Not ActiveSheet Is Nothing Then wasActive = (ActiveSheet.Name = wsDetail.Name)
    If wasActive Then
        If Not ActiveCell Is Nothing Then activeAddress = ActiveCell.Address(False, False)
    End If

    lastR = LastUsedRowInSheet(wsDetail)
    For r = 1 To lastR
        kindText = CellText(wsDetail.Cells(r, DETAIL_KIND_COL).Value)
        If kindText = "取引" And _
           CellText(wsDetail.Cells(r, DETAIL_SELECTED_COL).Value) = "1" Then
            referenceText = CellText(wsDetail.Cells(r, DETAIL_REFERENCE_COL).Value)
            If Len(referenceText) = 0 Then _
                Err.Raise vbObjectError + 5100, "CaptureManualDetailSelectionSnapshot", _
                          "候補詳細 " & CStr(r) & "行目の選択取引に取引IDがありません。"
            selectionKey = ManualDetailSelectionStableKey(kindText, referenceText)
            selectedKeys(selectionKey) = True
        End If
    Next r
    If selectedKeys.Count < 2 Then _
        Err.Raise vbObjectError + 5101, "CaptureManualDetailSelectionSnapshot", _
                  "候補詳細の選択取引を安定キーで退避できません。"
End Sub

Private Function RestoreManualDetailSelectionSnapshot( _
        ByVal selectedKeys As Object, ByVal originalVisibility As XlSheetVisibility, _
        ByVal wasActive As Boolean, ByVal activeAddress As String, _
        ByRef detailText As String) As Boolean
    Dim wsDetail As Worksheet
    Dim foundKeys As Object, verifiedKeys As Object
    Dim lastR As Long, r As Long
    Dim kindText As String, referenceText As String, selectionKey As String
    Dim shouldSelect As Boolean
    Dim item As Variant
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim protectErrorNumber As Long, protectErrorDescription As String
    Dim protectErrorSource As String, eventStateDetail As String

    On Error GoTo EH
    detailText = vbNullString
    If selectedKeys Is Nothing Then
        detailText = "候補詳細の選択退避値がありません。"
        Exit Function
    End If
    If selectedKeys.Count < 2 Then
        detailText = "候補詳細の選択退避値が不足しています。"
        Exit Function
    End If
    If Not SheetExists(SH_ANALYSIS_DETAIL) Then
        detailText = "候補詳細シートがありません。"
        Exit Function
    End If
    Set wsDetail = GetSheet(SH_ANALYSIS_DETAIL)
    Set foundKeys = CreateObject("Scripting.Dictionary")
    foundKeys.CompareMode = vbBinaryCompare
    wsDetail.Visible = xlSheetVisible
    wsDetail.Unprotect Password:=TOOL_PASSWORD
    lastR = LastUsedRowInSheet(wsDetail)
    For r = 1 To lastR
        kindText = CellText(wsDetail.Cells(r, DETAIL_KIND_COL).Value)
        If kindText = "取引" Then
            referenceText = CellText(wsDetail.Cells(r, DETAIL_REFERENCE_COL).Value)
            If Len(referenceText) = 0 Then
                detailText = "候補詳細 " & CStr(r) & "行目の取引IDがありません。"
                GoTo RestoreFailed
            End If
            selectionKey = ManualDetailSelectionStableKey(kindText, referenceText)
            shouldSelect = selectedKeys.Exists(selectionKey)
            wsDetail.Cells(r, DETAIL_SELECTED_COL).Value = IIf(shouldSelect, "1", "0")
            If shouldSelect Then
                foundKeys(selectionKey) = True
                wsDetail.Range(wsDetail.Cells(r, 1), wsDetail.Cells(r, 7)).Interior.Color = _
                    RGB(219, 234, 254)
                wsDetail.Range(wsDetail.Cells(r, 1), wsDetail.Cells(r, 7)).Font.Bold = True
                If CellText(wsDetail.Cells(r, DETAIL_SOURCE_KEY_COL).Value) = "GLOBAL" Then _
                    wsDetail.Cells(r, 1).Value = "選択"
            Else
                wsDetail.Range(wsDetail.Cells(r, 1), wsDetail.Cells(r, 7)).Interior.Color = vbWhite
                wsDetail.Range(wsDetail.Cells(r, 1), wsDetail.Cells(r, 7)).Font.Bold = False
                If CellText(wsDetail.Cells(r, DETAIL_SOURCE_KEY_COL).Value) = "GLOBAL" Then _
                    wsDetail.Cells(r, 1).Value = "未選択"
            End If
        End If
    Next r
    For Each item In selectedKeys.Keys
        If Not foundKeys.Exists(CStr(item)) Then
            detailText = "選択取引を候補詳細から再特定できません: " & CStr(item)
            GoTo RestoreFailed
        End If
    Next item

    ProtectSingleAnalysisSheet wsDetail
    wsDetail.Visible = originalVisibility
    If wasActive Then
        If originalVisibility <> xlSheetVisible Then
            detailText = "選択時に表示中だった候補詳細の表示状態が不正です。"
            GoTo RestoreFailed
        End If
        wsDetail.Activate
        If Len(activeAddress) > 0 Then SafeSelectCell wsDetail, activeAddress
    End If

    Set verifiedKeys = CreateObject("Scripting.Dictionary")
    verifiedKeys.CompareMode = vbBinaryCompare
    lastR = LastUsedRowInSheet(wsDetail)
    For r = 1 To lastR
        If CellText(wsDetail.Cells(r, DETAIL_KIND_COL).Value) = "取引" And _
           CellText(wsDetail.Cells(r, DETAIL_SELECTED_COL).Value) = "1" Then
            referenceText = CellText(wsDetail.Cells(r, DETAIL_REFERENCE_COL).Value)
            selectionKey = ManualDetailSelectionStableKey("取引", referenceText)
            verifiedKeys(selectionKey) = True
        End If
    Next r
    If verifiedKeys.Count <> selectedKeys.Count Then
        detailText = "復元後の選択取引件数が退避値と一致しません。"
        GoTo RestoreFailed
    End If
    For Each item In selectedKeys.Keys
        If Not verifiedKeys.Exists(CStr(item)) Then
            detailText = "復元後の選択取引を照合できません: " & CStr(item)
            GoTo RestoreFailed
        End If
    Next item
    If wsDetail.Visible <> originalVisibility Then
        detailText = "候補詳細の表示状態を復元できません。"
        GoTo RestoreFailed
    End If
    If wasActive Then
        If ActiveSheet Is Nothing Then
            detailText = "候補詳細を元の作業画面へ戻せません。"
            GoTo RestoreFailed
        End If
        If ActiveSheet.Name <> wsDetail.Name Then
            detailText = "候補詳細を元の作業画面へ戻せません。"
            GoTo RestoreFailed
        End If
        If Len(activeAddress) > 0 Then
            If ActiveCell Is Nothing Then
                detailText = "候補詳細の選択セルを復元できません。"
                GoTo RestoreFailed
            End If
            If StrComp(ActiveCell.Address(False, False), activeAddress, vbBinaryCompare) <> 0 Then
                detailText = "候補詳細の選択セルを復元・照合できません。"
                GoTo RestoreFailed
            End If
        End If
    End If
    RestoreManualDetailSelectionSnapshot = True
    Exit Function

RestoreFailed:
    On Error Resume Next
    Err.Clear
    If Not wsDetail Is Nothing Then ProtectSingleAnalysisSheet wsDetail
    protectErrorNumber = Err.Number
    protectErrorDescription = Err.Description
    protectErrorSource = Err.Source
    Err.Clear
    On Error GoTo 0
    If IsManualFlowUpstreamRecoveryFatal( _
           protectErrorNumber, protectErrorSource) Then
        Call TrySetManualFlowEnableEventsExact(False, eventStateDetail)
        Err.Raise protectErrorNumber, protectErrorSource, _
                  protectErrorDescription
    End If
    If protectErrorNumber <> 0 Then _
        AppendManualFlowFailureDetail detailText, _
            "候補詳細の再保護エラー: Err " & _
            CStr(protectErrorNumber) & " " & protectErrorDescription
    Exit Function
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    If IsManualFlowUpstreamRecoveryFatal(errorNumber, errorSource) Then
        Call TrySetManualFlowEnableEventsExact(False, eventStateDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    detailText = "Err " & CStr(errorNumber) & ": " & errorDescription
    Resume RestoreFailed
End Function

Private Function ManualDetailSelectionStableKey(ByVal kindText As String, _
                                                ByVal referenceText As String) As String
    ManualDetailSelectionStableKey = CStr(Len(kindText)) & ":" & kindText & "|" & _
                                     CStr(Len(referenceText)) & ":" & referenceText
End Function

'資金操作表の統合画面から、候補詳細を経由せずに手動候補を登録する。
'出金計と入金計は別々に提示し、同じ金額欄へまとめない。
Public Function RegisterManualAnalysisCandidateByIDs( _
        ByVal idList As String, _
        Optional ByRef outputCapacityConfirmed As Boolean = False) As Boolean
    Dim suggestedAmount As Double, amountInput As Variant, amountValue As Double
    Dim totalWithdrawal As Double, totalDeposit As Double, txCount As Long
    Dim canonicalIDs As String, savedBaseKey As String
    Dim storeSnapshot As Variant, storeSnapshotLastRow As Long, storeChanged As Boolean
    Dim allocationSnapshot As Variant, allocationSnapshotLastRow As Long
    Dim allocationSnapshotDigest As String, allocationSnapshotCaptured As Boolean
    Dim allocationSnapshotCellWork As Double
    Dim analysisBuildStarted As Boolean, reviewsWerePending As Boolean, rollbackFailed As Boolean
    Dim outputsWereDirty As Boolean, outputDirtyAttempted As Boolean, outputDirtyConfirmed As Boolean
    Dim safetyStopRequired As Boolean
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim entryEvents As Boolean, entryEventsCaptured As Boolean
    Dim appBeginAttempted As Boolean, applicationLeaseStarted As Boolean
    Dim operationCommitted As Boolean
    Dim mutationStarted As Boolean, cleanupEventsStopped As Boolean
    Dim recoveryStateConfirmed As Boolean, recoveryEnforcementAttempted As Boolean
    Dim recoveryEnforcementFailed As Boolean
    Dim reportingAllowed As Boolean
    Dim appStateRestored As Boolean, entryEventsRestored As Boolean
    Dim eventRestoreRequiredRecovery As Boolean
    Dim eventStateDetail As String, applicationStateDetail As String
    Dim entryRestoreDetail As String, recoveryDetail As String
    Dim confirmedAnalysisWorkloadRows As Double

    On Error GoTo EH
    outputCapacityConfirmed = False
    If Not TryGetManualFlowEnableEvents(entryEvents, eventStateDetail) Then _
        Err.Raise vbObjectError + 5113, _
                  "RegisterManualAnalysisCandidateByIDs", _
                  "Excelイベントの開始状態を取得できませんでした。 " & _
                  eventStateDetail
    entryEventsCaptured = True
    If Not TrySetManualFlowEnableEventsExact(False, eventStateDetail) Then _
        Err.Raise vbObjectError + 5114, _
                  "RegisterManualAnalysisCandidateByIDs", _
                  "事前確認より前にExcelイベントを停止できませんでした。 " & _
                  eventStateDetail
    If Not RequireToolReady() Then GoTo ByIDsCleanExit
    If Not RequireNoPendingAccountInput("手動分析候補の登録") Then _
        GoTo ByIDsCleanExit
    If Not RequireManualFlowMutationCapacity("手動候補の登録", 1) Then
        SetInputStatus "手動候補の登録を開始せず中止しました。保存内容は変更していません。"
        GoTo ByIDsCleanExit
    End If
    If Not RequireOutputBuildCapacity("手動候補の登録と分析更新", _
            True, False, False, True, False, False) Then
        SetInputStatus "手動候補の登録を開始せず中止しました。保存内容は変更していません。"
        GoTo ByIDsCleanExit
    End If
    outputCapacityConfirmed = True
    allocationSnapshotCellWork = _
        CDbl(AllocationLedgerStoredRowCount() + 1) * 10#
    If Not ConfirmAnalysisReviewOperationCapacity( _
            "手動候補の登録と分析更新", confirmedAnalysisWorkloadRows, _
            additionalManualRows:=1, _
            additionalSnapshotCellWork:=allocationSnapshotCellWork * 2#) Then
        SetInputStatus "手動候補の登録を開始せず中止しました。保存内容は変更していません。"
        GoTo ByIDsCleanExit
    End If
    If Not RequireInternalStoresSafeForWrite(False, False) Then _
        GoTo ByIDsCleanExit
    reviewsWerePending = HasPendingAnalysisReviewChanges()
    ValidateManualTransactionIDs idList, txCount, totalWithdrawal, totalDeposit, _
                                 suggestedAmount, canonicalIDs
    If txCount < 2 Then
        MsgBox "取引を2件以上選択してください。", vbInformation
        GoTo ByIDsCleanExit
    End If
    amountInput = Application.InputBox( _
        Prompt:="この候補で追跡する金額を入力してください。" & vbCrLf & _
                "選択取引: " & CStr(txCount) & "件" & vbCrLf & _
                "出金合計: " & Format$(totalWithdrawal, "#,##0.########") & vbCrLf & _
                "入金合計: " & Format$(totalDeposit, "#,##0.########") & vbCrLf & _
                "差額（入金－出金）: " & _
                Format$(totalDeposit - totalWithdrawal, "+#,##0.########;-#,##0.########;0"), _
        Title:="手動の資金移動候補", Default:=suggestedAmount, Type:=1)
    If VarType(amountInput) = vbBoolean Then
        If CBool(amountInput) = False Then GoTo ByIDsCleanExit
    End If
    If Not IsNumeric(amountInput) Then
        MsgBox "追跡額は0より大きい有効な金額で入力してください。", vbExclamation
        GoTo ByIDsCleanExit
    End If
    amountValue = CDbl(amountInput)
    If amountValue <= 0 Or amountValue > MAX_ABS_AMOUNT Or _
       (amountValue > suggestedAmount And _
        Not ManualAmountsMatch(amountValue, suggestedAmount)) Then
        MsgBox "追跡額は0より大きく、出金計と入金計の小さい方（" & _
               Format$(suggestedAmount, "#,##0.########") & _
               "）以下で入力してください。", vbExclamation
        GoTo ByIDsCleanExit
    End If
    If MsgBox("選択した " & CStr(txCount) & "取引を手動候補として登録しますか？" & vbCrLf & _
              "出金合計: " & Format$(totalWithdrawal, "#,##0.########") & vbCrLf & _
              "入金合計: " & Format$(totalDeposit, "#,##0.########") & vbCrLf & _
              "追跡額: " & Format$(amountValue, "#,##0.########"), _
              vbYesNo + vbQuestion + vbDefaultButton2, _
              "手動候補の確認") <> vbYes Then GoTo ByIDsCleanExit

    CaptureManualFlowStoreSnapshot storeSnapshot, storeSnapshotLastRow
    CaptureAllocationLedgerTransactionSnapshot allocationSnapshot, _
        allocationSnapshotLastRow, allocationSnapshotDigest
    allocationSnapshotCaptured = True
    If Not TryConfirmManualFlowApplicationState(applicationStateDetail) Then _
        RaiseManualFlowRecoveryFatal _
            "RegisterManualAnalysisCandidateByIDs", 0, _
            "RegisterManualAnalysisCandidateByIDs", _
            "AppBegin前のApplication状態が安全ではありません。", _
            applicationStateDetail
    AppBegin "手動候補を登録して資金操作表を更新しています..."
    appBeginAttempted = True
    applicationLeaseStarted = True
    If Not TrySetManualFlowEnableEventsExact(False, eventStateDetail) Then _
        Err.Raise vbObjectError + 5114, _
                  "RegisterManualAnalysisCandidateByIDs", _
                  "保存内容の変更前にExcelイベントを停止できませんでした。 " & _
                  eventStateDetail
    outputsWereDirty = OutputsAreDirty()
    outputDirtyAttempted = True
    mutationStarted = True
    MarkOutputsDirty
    outputDirtyConfirmed = True
    storeChanged = True
    SaveManualFlowCandidate canonicalIDs, amountValue, savedBaseKey
    MarkAnalysisReviewsDirty
    analysisBuildStarted = True
    BuildTransactionAnalysisSheetsCore True, True, confirmedAnalysisWorkloadRows, _
                                       False, allocationSnapshotCellWork
    VerifyManualFlowRegistration savedBaseKey, canonicalIDs, amountValue
    MarkAnalysisReviewsClean
    If Not outputsWereDirty Then
        RequireManualFlowAuthoritativeStructure
        MarkOutputsClean
    End If
    operationCommitted = True
    AppEnd
    applicationLeaseStarted = False
ByIDsCleanExit:
    If entryEventsCaptured Then
        If Not TrySetManualFlowEnableEventsExact(entryEvents, eventStateDetail) Then _
            Err.Raise vbObjectError + 5115, _
                      "RegisterManualAnalysisCandidateByIDs", _
                      "処理開始時のExcelイベント状態を復元できませんでした。 " & _
                      eventStateDetail
        entryEventsCaptured = False
    End If
    If Not operationCommitted Then Exit Function
    RegisterManualAnalysisCandidateByIDs = True
    On Error Resume Next
    MsgBox "手動の資金移動候補を登録しました。" & vbCrLf & _
           "資金操作表の上部で確認状況とメモを記録できます。", vbInformation
    Err.Clear
    On Error GoTo 0
    Exit Function
EH:
    errorNumber = Err.Number: errorDescription = Err.Description
    errorSource = Err.Source
    If IsManualFlowUpstreamRecoveryFatal(errorNumber, errorSource) Then
        Call TryStopManualFlowEventsForBookWrites(eventStateDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    If Not appBeginAttempted And _
       StrComp(errorSource, "AppBegin", vbBinaryCompare) = 0 Then
        RaiseManualFlowRecoveryFatal _
            "RegisterManualAnalysisCandidateByIDs", errorNumber, _
            errorSource, errorDescription, _
            "AppBeginが正常終了せず、Application leaseの所有を取得できませんでした。"
    End If
    If entryEventsCaptured Then
        cleanupEventsStopped = _
            TryStopManualFlowEventsForBookWrites(eventStateDetail)
        If Not cleanupEventsStopped Then _
            AppendManualFlowFailureDetail errorDescription, _
                "失敗復旧の開始前にExcelイベント停止を確認できません: " & _
                eventStateDetail
    Else
        AppendManualFlowFailureDetail errorDescription, _
            "Excelイベントの開始状態を取得していません。"
    End If

    If operationCommitted Then
        safetyStopRequired = True
        AppendManualFlowFailureDetail errorDescription, _
            "手動候補と分析結果は確定済みのため、開始前の退避値へ戻しません。"
    ElseIf mutationStarted And cleanupEventsStopped Then
        On Error Resume Next
        Err.Clear
        If storeChanged Then _
            RestoreManualFlowStoreSnapshot storeSnapshot, storeSnapshotLastRow
        If Err.Number <> 0 Then
            rollbackFailed = True
            AppendManualFlowFailureDetail errorDescription, _
                "手動候補保存のロールバック失敗: " & Err.Description
        End If
        Err.Clear
        If analysisBuildStarted And allocationSnapshotCaptured Then
            RestoreAllocationLedgerTransactionSnapshot allocationSnapshot, _
                allocationSnapshotLastRow, allocationSnapshotDigest
            If Err.Number <> 0 Then
                rollbackFailed = True
                AppendManualFlowFailureDetail errorDescription, _
                    "配賦元帳のロールバック失敗: " & Err.Description
            End If
            Err.Clear
        End If
        If outputDirtyAttempted Then
            If Not outputDirtyConfirmed Then safetyStopRequired = True
            If Not EnsureManualFlowFailureOutputsDirty(errorDescription) Then _
                safetyStopRequired = True
        End If
        If rollbackFailed Then safetyStopRequired = True
        If safetyStopRequired Then
            MarkAnalysisReviewsDirty
        ElseIf analysisBuildStarted Or reviewsWerePending Then
            MarkAnalysisReviewsDirty
        Else
            MarkAnalysisReviewsClean
        End If
        If Err.Number <> 0 Then
            safetyStopRequired = True
            AppendManualFlowFailureDetail errorDescription, _
                "分析要更新状態の記録エラー: " & Err.Description
        End If
        Err.Clear
        On Error GoTo 0
    ElseIf mutationStarted Then
        rollbackFailed = True
        safetyStopRequired = True
        AppendManualFlowFailureDetail errorDescription, _
            "Excelイベント停止が未確認のため、保存記録・配賦元帳へ退避値を再書込みしませんでした。"
    End If

    If safetyStopRequired And cleanupEventsStopped And _
       Not recoveryEnforcementAttempted Then
        EnforceManualFlowRecoveryStateTerminal _
            "RegisterManualAnalysisCandidateByIDs", _
            "資金操作表からの手動候補登録失敗", _
            recoveryDetail, recoveryEnforcementAttempted, _
            recoveryEnforcementFailed, errorNumber, errorSource, _
            errorDescription, applicationLeaseStarted
    End If

    appStateRestored = TryEndManualFlowAppLease( _
                           applicationLeaseStarted, appBeginAttempted, _
                           applicationStateDetail)
    If Not appStateRestored Then
        safetyStopRequired = True
        AppendManualFlowFailureDetail errorDescription, applicationStateDetail
        cleanupEventsStopped = False
        If entryEventsCaptured Then _
            cleanupEventsStopped = _
                TryStopManualFlowEventsForBookWrites(eventStateDetail)
        If cleanupEventsStopped And mutationStarted And _
           Not recoveryEnforcementAttempted Then
            EnforceManualFlowRecoveryStateTerminal _
                "RegisterManualAnalysisCandidateByIDs", _
                "手動候補登録後のExcel状態復元失敗", _
                recoveryDetail, recoveryEnforcementAttempted, _
                recoveryEnforcementFailed, errorNumber, errorSource, _
                errorDescription, applicationLeaseStarted
        ElseIf Not cleanupEventsStopped Then
            AppendManualFlowFailureDetail errorDescription, _
                "Excel状態復元失敗後にイベント停止を確認できず、Recovery書込みを見送りました。"
        End If
        If applicationLeaseStarted And Not recoveryEnforcementFailed Then
            appStateRestored = TryEndManualFlowAppLease( _
                                   applicationLeaseStarted, _
                                   appBeginAttempted, applicationStateDetail)
            If Not appStateRestored Then _
                AppendManualFlowFailureDetail errorDescription, _
                    "Excel状態の通常復元再試行にも失敗しました: " & _
                    applicationStateDetail
        End If
        If Not appStateRestored And appBeginAttempted And _
           Not recoveryEnforcementFailed Then
            appStateRestored = _
                TryForceRestoreManualFlowApplicationState( _
                    applicationLeaseStarted, appBeginAttempted, _
                    applicationStateDetail)
            If Not appStateRestored Then
                AppendManualFlowFailureDetail errorDescription, _
                    "Excel状態の強制復元と全状態読戻しにも失敗しました: " & _
                    applicationStateDetail
                cleanupEventsStopped = _
                    TryStopManualFlowEventsForBookWrites(eventStateDetail)
                If Not cleanupEventsStopped Then _
                    AppendManualFlowFailureDetail errorDescription, _
                        "強制復元失敗後のイベントFalse収束にも失敗し、状態は不明です: " & _
                        eventStateDetail
            End If
        ElseIf recoveryEnforcementFailed And Not appStateRestored Then
            AppendManualFlowFailureDetail errorDescription, _
                "要復旧処理自体が失敗したため、Excel状態の通常再試行と強制復元を見送りました。"
        End If
    End If

    If (mutationStarted Or operationCommitted) And appStateRestored Then
        cleanupEventsStopped = False
        If entryEventsCaptured Then _
            cleanupEventsStopped = _
                TryStopManualFlowEventsForBookWrites(eventStateDetail)
        If safetyStopRequired And cleanupEventsStopped And _
           Not recoveryStateConfirmed And Not recoveryEnforcementAttempted Then
            EnforceManualFlowRecoveryStateTerminal _
                "RegisterManualAnalysisCandidateByIDs", _
                "手動候補登録の安全停止", recoveryDetail, _
                recoveryEnforcementAttempted, recoveryEnforcementFailed, _
                errorNumber, errorSource, errorDescription, _
                applicationLeaseStarted
        End If
        reportingAllowed = cleanupEventsStopped And _
                           (Not safetyStopRequired Or recoveryStateConfirmed)
        If reportingAllowed Then
            On Error Resume Next
            Err.Clear
            If operationCommitted Then
                AddCheck "エラー", "手動候補登録の確定後処理", _
                    "Err " & CStr(errorNumber) & ": " & errorDescription
                If recoveryStateConfirmed Then
                    SetInputStatus _
                        "手動候補と分析結果は確定済みですが、後処理失敗を要復旧状態として記録しました。", _
                        True
                Else
                    SetInputStatus _
                        "手動候補と分析結果は確定済みですが、後処理後の安全状態を確認できません。上書き保存せずExcelを再起動してください。", _
                        True
                End If
            ElseIf safetyStopRequired Then
                AddCheck "エラー", "手動候補登録ロールバック", _
                    "Err " & CStr(errorNumber) & ": " & errorDescription
                If recoveryStateConfirmed Then
                    SetInputStatus _
                        "手動候補の登録に失敗し、ロールバック不成立を要復旧状態として記録しました。", _
                        True
                Else
                    SetInputStatus _
                        "手動候補の登録に失敗し、安全状態を一意に確認できません。上書き保存せずExcelを再起動してください。", _
                        True
                End If
            ElseIf IsUserCancelError(errorNumber) Then
                SetInputStatus _
                    "手動候補の登録処理を中断し、操作開始前の保存内容へ戻しました。"
            Else
                AddCheck "エラー", "資金操作表からの手動候補登録", _
                    "Err " & CStr(errorNumber) & ": " & errorDescription
                SetInputStatus _
                    "手動候補の登録に失敗し、操作開始前の保存内容へ戻しました。C_チェックを確認してください。"
            End If
            Err.Clear
            On Error GoTo 0
        Else
            safetyStopRequired = True
            AppendManualFlowFailureDetail errorDescription, _
                "Excelイベント停止または復旧状態が未確認のため、チェック・状態表示を書き込みませんでした。"
        End If
    End If

    If entryEventsCaptured And appStateRestored Then
        entryEventsRestored = TryRestoreManualFlowEntryEvents( _
            entryEvents, mutationStarted Or operationCommitted, _
            appStateRestored And _
                ((Not mutationStarted And Not operationCommitted) Or _
                 (mutationStarted And Not operationCommitted And _
                  Not safetyStopRequired And Not rollbackFailed)), _
            "手動候補登録のイベント復元失敗: " & errorDescription, _
            recoveryStateConfirmed, recoveryEnforcementAttempted, _
            recoveryEnforcementFailed, _
            eventRestoreRequiredRecovery, _
            entryRestoreDetail)
        If eventRestoreRequiredRecovery Then safetyStopRequired = True
        If Not entryEventsRestored Then safetyStopRequired = True
        AppendManualFlowFailureDetail errorDescription, entryRestoreDetail
    ElseIf Not entryEventsCaptured Then
        safetyStopRequired = True
    Else
        safetyStopRequired = True
        cleanupEventsStopped = _
            TryStopManualFlowEventsForBookWrites(eventStateDetail)
        If cleanupEventsStopped Then
            AppendManualFlowFailureDetail errorDescription, _
                "Application状態が未復元のため開始時イベント値へ戻さず、Falseへ収束させました。"
        Else
            AppendManualFlowFailureDetail errorDescription, _
                "Application状態が未復元で、イベントFalseへの収束も確認できません。"
        End If
    End If

    If IsUserCancelError(errorNumber) And Not safetyStopRequired And _
       Not operationCommitted Then Exit Function
    On Error Resume Next
    If Not appStateRestored Then
        If operationCommitted Then
            MsgBox "手動候補と分析結果は確定済みですが、Application状態は不明です。" & _
                   vbCrLf & "Excelイベントを開始時の値へ戻していません。" & _
                   vbCrLf & "現在のブックを上書きせず、Excelを再起動してください。" & _
                   vbCrLf & "Err " & CStr(errorNumber) & ": " & _
                   errorDescription, vbCritical
        Else
            MsgBox "手動候補の登録を完了できず、Application状態も確認できません。" & _
                   vbCrLf & "Excelイベントを開始時の値へ戻していません。" & _
                   vbCrLf & "現在のブックを上書きせず、Excelを再起動してください。" & _
                   vbCrLf & "Err " & CStr(errorNumber) & ": " & _
                   errorDescription, vbCritical
        End If
    ElseIf operationCommitted Then
        MsgBox "手動候補と分析結果は確定済みです。" & vbCrLf & _
               IIf(recoveryStateConfirmed, _
                   "後処理の失敗を要復旧状態として記録しました。", _
                   "後処理後の安全状態を確認できません。") & vbCrLf & _
               "現在のブックを上書きせず、Excelを再起動してください。" & _
               vbCrLf & "Err " & CStr(errorNumber) & ": " & _
               errorDescription, vbExclamation
    ElseIf Not mutationStarted Then
        MsgBox "手動候補の登録処理は開始されず、保存内容は変更していません。" & _
               vbCrLf & "Err " & CStr(errorNumber) & ": " & _
               errorDescription, vbExclamation
    Else
        MsgBox "手動候補を登録できませんでした。" & vbCrLf & _
               "Err " & CStr(errorNumber) & ": " & errorDescription, vbExclamation
    End If
    Err.Clear
    On Error GoTo 0
End Function

Private Sub SaveManualFlowCandidate(ByVal canonicalTxIDs As String, ByVal trackingAmount As Double, _
                                    ByRef savedBaseKey As String)
    Dim ws As Worksheet, lastR As Long, data As Variant, r As Long, rowNo As Long
    Dim activeText As String, currentIDs As String, idSetKey As String, currentSetKey As String
    Dim manualID As String, baseKey As String
    Dim expectedData As Variant, stamp As Date
    Set ws = GetSheet(SH_WORK_MANUAL_FLOW)
    savedBaseKey = vbNullString
    lastR = LastUsedRowInSheet(ws)
    idSetKey = ManualIDSetSignature(canonicalTxIDs)
    If lastR >= 2 Then
        data = ws.Range(ws.Cells(2, 1), ws.Cells(lastR, MANUAL_FLOW_STORE_LAST_COL)).Value2
        For r = 1 To UBound(data, 1)
            currentIDs = CellText(data(r, MANUAL_FLOW_COL_TX_IDS))
            currentSetKey = ManualIDSetSignature(currentIDs)
            If Len(currentSetKey) > 0 And StrComp(currentSetKey, idSetKey, vbBinaryCompare) = 0 Then
                activeText = CellText(data(r, MANUAL_FLOW_COL_ACTIVE))
                If activeText = MANUAL_ACTIVE Then _
                    Err.Raise vbObjectError + 4950, "SaveManualFlowCandidate", _
                              "同じ構成取引の手動候補は既に登録されています。"
                If MsgBox("同じ構成取引の無効な手動候補があります。再有効化しますか？", _
                          vbYesNo + vbQuestion + vbDefaultButton2) <> vbYes Then _
                    Err.Raise 18, "SaveManualFlowCandidate", "利用者が再有効化を中止しました。"
                rowNo = r + 1
                stamp = Now
                expectedData = ws.Range(ws.Cells(rowNo, 1), _
                                        ws.Cells(rowNo, MANUAL_FLOW_STORE_LAST_COL)).Value2
                expectedData(1, MANUAL_FLOW_COL_TX_IDS) = CStr(canonicalTxIDs)
                expectedData(1, MANUAL_FLOW_COL_AMOUNT) = CDbl(trackingAmount)
                expectedData(1, MANUAL_FLOW_COL_STATUS) = ANALYSIS_STATUS_FOLLOWUP
                expectedData(1, MANUAL_FLOW_COL_MEMO) = ManualFlowExpectedValue2( _
                    AppendAnalysisMemo(CellText(expectedData(1, MANUAL_FLOW_COL_MEMO)), _
                                       "[自動] 無効な手動候補を再有効化しました。"))
                expectedData(1, MANUAL_FLOW_COL_ACTIVE) = MANUAL_ACTIVE
                expectedData(1, MANUAL_FLOW_COL_UPDATED_AT) = CDbl(stamp)
                WriteManualFlowStoreExpectedRow ws, rowNo, expectedData, _
                    "無効な手動候補の再有効化"
                SetSheetVeryHiddenSafe ws
                If Not ManualFlowStoreIsVeryHidden(ws) Then _
                    Err.Raise vbObjectError + 4971, "SaveManualFlowCandidate", _
                              "手動資金候補を内部非表示へ戻せません。"
                savedBaseKey = CellText(expectedData(1, MANUAL_FLOW_COL_KEY))
                Exit Sub
            End If
        Next r
    End If
    rowNo = lastR + 1
    If rowNo < 2 Then rowNo = 2
    If rowNo - 1 > MAX_INTERNAL_STORE_DATA_ROWS Then _
        Err.Raise vbObjectError + 4951, "SaveManualFlowCandidate", _
                  "手動候補が保存上限を超えました。案件ファイルを分けてください。"
    stamp = Now
    manualID = "MF-" & Format$(stamp, "yyyymmddhhnnss") & "-" & Format$(rowNo - 1, "000000")
    baseKey = "MANUAL>" & manualID
    ReDim expectedData(1 To 1, 1 To MANUAL_FLOW_STORE_LAST_COL)
    expectedData(1, MANUAL_FLOW_COL_ID) = manualID
    expectedData(1, MANUAL_FLOW_COL_TX_IDS) = CStr(canonicalTxIDs)
    expectedData(1, MANUAL_FLOW_COL_AMOUNT) = CDbl(trackingAmount)
    expectedData(1, MANUAL_FLOW_COL_STATUS) = ANALYSIS_STATUS_UNREVIEWED
    expectedData(1, MANUAL_FLOW_COL_MEMO) = Empty
    expectedData(1, MANUAL_FLOW_COL_ACTIVE) = MANUAL_ACTIVE
    expectedData(1, MANUAL_FLOW_COL_CREATED_AT) = CDbl(stamp)
    expectedData(1, MANUAL_FLOW_COL_CREATED_BY) = ManualFlowUserName()
    expectedData(1, MANUAL_FLOW_COL_UPDATED_AT) = CDbl(stamp)
    expectedData(1, MANUAL_FLOW_COL_EVIDENCE) = Empty
    expectedData(1, MANUAL_FLOW_COL_KEY) = baseKey
    WriteManualFlowStoreExpectedRow ws, rowNo, expectedData, "手動候補の新規登録"
    SetSheetVeryHiddenSafe ws
    If Not ManualFlowStoreIsVeryHidden(ws) Then _
        Err.Raise vbObjectError + 4971, "SaveManualFlowCandidate", _
                  "手動資金候補を内部非表示へ戻せません。"
    savedBaseKey = baseKey
End Sub

Private Sub VerifyManualFlowRegistration(ByVal savedBaseKey As String, _
                                         ByVal canonicalTxIDs As String, _
                                         ByVal trackingAmount As Double)
    Dim wsStore As Worksheet, wsFlow As Worksheet
    Dim lastR As Long, r As Long, matchCount As Long
    Dim storedKey As String, baseKey As String, evidenceText As String
    Dim expectedSet As String, actualSet As String
    If Len(savedBaseKey) = 0 Then _
        Err.Raise vbObjectError + 5098, "VerifyManualFlowRegistration", _
                  "保存した手動候補の確認キーを取得できません。"
    expectedSet = ManualIDSetSignature(canonicalTxIDs)
    If Len(expectedSet) = 0 Then _
        Err.Raise vbObjectError + 5098, "VerifyManualFlowRegistration", _
                  "保存した手動候補の構成取引IDが空です。"

    Set wsStore = GetSheet(SH_WORK_MANUAL_FLOW)
    lastR = LastUsedRowInSheet(wsStore)
    For r = 2 To lastR
        If StrComp(CellText(wsStore.Cells(r, MANUAL_FLOW_COL_KEY).Value2), _
                   savedBaseKey, vbBinaryCompare) = 0 Then
            matchCount = matchCount + 1
            actualSet = ManualIDSetSignature( _
                            CellText(wsStore.Cells(r, MANUAL_FLOW_COL_TX_IDS).Value2))
            If StrComp(actualSet, expectedSet, vbBinaryCompare) <> 0 Or _
               CellText(wsStore.Cells(r, MANUAL_FLOW_COL_ACTIVE).Value2) <> MANUAL_ACTIVE Then _
                Err.Raise vbObjectError + 5098, "VerifyManualFlowRegistration", _
                          "保存した手動候補のID、追跡額または有効状態が読戻しと一致しません。"
            If Not IsNumeric(wsStore.Cells(r, MANUAL_FLOW_COL_AMOUNT).Value2) Then _
                Err.Raise vbObjectError + 5098, "VerifyManualFlowRegistration", _
                          "保存した手動候補の追跡額を数値として読戻せません。"
            If Not ManualAmountsMatch( _
                       CDbl(wsStore.Cells(r, MANUAL_FLOW_COL_AMOUNT).Value2), _
                       trackingAmount) Then _
                Err.Raise vbObjectError + 5098, "VerifyManualFlowRegistration", _
                          "保存した手動候補の追跡額が読戻しと一致しません。"
        End If
    Next r
    If matchCount <> 1 Then _
        Err.Raise vbObjectError + 5098, "VerifyManualFlowRegistration", _
                  "保存した手動候補を一意に確認できません。"

    Set wsFlow = GetSheet(SH_ANALYSIS_FLOW)
    lastR = LastUsedRowInSheet(wsFlow)
    matchCount = 0
    For r = 2 To lastR
        storedKey = CellText(wsFlow.Cells(r, FLOW_ANALYSIS_KEY_COL).Value2)
        baseKey = AnalysisBaseKey(storedKey, evidenceText)
        If StrComp(baseKey, savedBaseKey, vbBinaryCompare) = 0 Then
            matchCount = matchCount + 1
            actualSet = ManualIDSetSignature(CellText(wsFlow.Cells(r, 20).Value2))
            If CellText(wsFlow.Cells(r, 3).Value2) <> "手動指定" Or _
               StrComp(actualSet, expectedSet, vbBinaryCompare) <> 0 Then _
                Err.Raise vbObjectError + 5098, "VerifyManualFlowRegistration", _
                          "再分析後の手動候補が保存内容と一致しません。"
            If Not IsNumeric(wsFlow.Cells(r, 2).Value2) Then _
                Err.Raise vbObjectError + 5098, "VerifyManualFlowRegistration", _
                          "再分析後の手動候補スコアを数値として確認できません。"
            If CDbl(wsFlow.Cells(r, 2).Value2) >= 100# Then _
                Err.Raise vbObjectError + 5098, "VerifyManualFlowRegistration", _
                          "手動指定を未検証のまま100点として扱っています。"
        End If
    Next r
    If matchCount <> 1 Then _
        Err.Raise vbObjectError + 5098, "VerifyManualFlowRegistration", _
                  "再分析後の手動候補を一意かつ有効な状態で確認できません。"
End Sub

Private Function ManualAmountsMatch(ByVal firstAmount As Double, _
                                    ByVal secondAmount As Double) As Boolean
    Dim scaleValue As Double, toleranceValue As Double
    scaleValue = Abs(firstAmount)
    If Abs(secondAmount) > scaleValue Then scaleValue = Abs(secondAmount)
    toleranceValue = scaleValue * 0.0000000000000005
    If toleranceValue < 0.00000001 Then toleranceValue = 0.00000001
    ManualAmountsMatch = (Abs(firstAmount - secondAmount) <= toleranceValue)
End Function

Private Sub WriteManualFlowStoreExpectedRow(ByVal ws As Worksheet, ByVal rowNo As Long, _
                                            ByRef expectedData As Variant, _
                                            ByVal labelText As String)
    Dim target As Range
    If ws Is Nothing Or rowNo < 2 Then _
        Err.Raise vbObjectError + 5097, "WriteManualFlowStoreExpectedRow", _
                  labelText & "の書込先が不正です。"
    Set target = ws.Range(ws.Cells(rowNo, 1), _
                          ws.Cells(rowNo, MANUAL_FLOW_STORE_LAST_COL))
    target.Value2 = expectedData
    If Not RangeValue2MatchesMatrixStrict( _
               target, expectedData, 1, MANUAL_FLOW_STORE_LAST_COL) Then _
        Err.Raise vbObjectError + 4970, "WriteManualFlowStoreExpectedRow", _
                  labelText & "の書込読戻しが全列・型で一致しません。"
    RequireAnalysisReviewConstantRange target, labelText
End Sub

Private Function WriteManualFlowStoreContentIfChanged( _
        ByVal ws As Worksheet, ByVal rowNo As Long, _
        ByVal statusText As String, ByVal memoText As String, _
        ByVal activeText As String, ByVal evidenceText As String, _
        ByVal stamp As Date) As Boolean
    Dim currentData As Variant, expectedData As Variant
    Dim target As Range, contentChanged As Boolean
    Set target = ws.Range(ws.Cells(rowNo, 1), _
                          ws.Cells(rowNo, MANUAL_FLOW_STORE_LAST_COL))
    currentData = target.Value2
    contentChanged = ( _
        StrComp(CellText(currentData(1, MANUAL_FLOW_COL_STATUS)), _
                statusText, vbBinaryCompare) <> 0 Or _
        StrComp(CellText(currentData(1, MANUAL_FLOW_COL_MEMO)), _
                memoText, vbBinaryCompare) <> 0 Or _
        StrComp(CellText(currentData(1, MANUAL_FLOW_COL_ACTIVE)), _
                activeText, vbBinaryCompare) <> 0 Or _
        StrComp(CellText(currentData(1, MANUAL_FLOW_COL_EVIDENCE)), _
                evidenceText, vbBinaryCompare) <> 0)
    If Not contentChanged Then Exit Function
    expectedData = currentData
    expectedData(1, MANUAL_FLOW_COL_STATUS) = ManualFlowExpectedValue2(statusText)
    expectedData(1, MANUAL_FLOW_COL_MEMO) = ManualFlowExpectedValue2(memoText)
    expectedData(1, MANUAL_FLOW_COL_ACTIVE) = ManualFlowExpectedValue2(activeText)
    expectedData(1, MANUAL_FLOW_COL_EVIDENCE) = ManualFlowExpectedValue2(evidenceText)
    expectedData(1, MANUAL_FLOW_COL_UPDATED_AT) = CDbl(stamp)
    WriteManualFlowStoreExpectedRow ws, rowNo, expectedData, _
        "手動資金候補 " & CStr(rowNo) & "行"
    WriteManualFlowStoreContentIfChanged = True
End Function

Private Function ManualFlowExpectedValue2(ByVal textValue As String) As Variant
    If Len(textValue) = 0 Then
        ManualFlowExpectedValue2 = Empty
    Else
        ManualFlowExpectedValue2 = CStr(textValue)
    End If
End Function

Public Sub AppendManualFlowAnalysisRecords( _
        ByRef sourceData As Variant, ByVal sourceRowCount As Long, ByVal wsOut As Worksheet, _
        ByVal reviews As Object, ByVal candidateCountByTx As Object, _
        ByVal bestScoreByTx As Object, ByVal bestRatingByTx As Object, _
        ByRef flowCount As Long, _
        Optional ByVal capacityConfirmed As Boolean = False)
    Dim wsStore As Worksheet, lastR As Long, data As Variant, r As Long
    Dim txIndex As Object, txIDs As String, baseKey As String, manualID As String
    Dim amountValue As Double, maximumTrackingAmount As Double
    Dim statusText As String, memoText As String, manualScore As Long, validationScore As Long
    Dim rows() As Long, rowCount As Long, rowList As String, canonicalIDs As String
    Dim evidenceText As String, storedEvidence As String, outputRow As Long
    Dim totalWithdrawal As Double, totalDeposit As Double
    Dim storeSnapshot As Variant, storeSnapshotLastRow As Long
    Dim flowSnapshot As Variant, flowSnapshotLastRow As Long
    Dim planAction() As Long, validCanonicalIDs() As String, validScores() As Long
    Dim validCount As Long, validIndex As Long, originalFlowCount As Long
    Dim prospectiveFlowCount As Double
    Dim storeSnapshotCaptured As Boolean, flowSnapshotCaptured As Boolean
    Dim storeWriteStarted As Boolean, outputWriteStarted As Boolean
    Dim storeChangePlanned As Boolean, rollbackFailed As Boolean
    Dim stamp As Date, replacementMemo As String
    Dim missingSourceIDs As Collection, invalidAmountIDs As Collection
    Dim validationSheet As Worksheet, storeTarget As Range
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim rollbackDescription As String
    Dim eventStateDetail As String, recoveryStateDetail As String
    Dim eventsStoppedForRollback As Boolean, recoveryStateConfirmed As Boolean
    Dim recoveryEnforcementAttempted As Boolean, recoveryEnforcementFailed As Boolean
    If Not SheetExists(SH_WORK_MANUAL_FLOW) Then Exit Sub
    If Not capacityConfirmed Then
        If Not RequireManualFlowMutationCapacity("手動候補の分析反映") Then _
            Err.Raise 18, "AppendManualFlowAnalysisRecords", _
                      "利用者が手動候補の分析反映を中止しました。"
    End If
    On Error GoTo EH
    Set wsStore = GetSheet(SH_WORK_MANUAL_FLOW)
    CaptureManualFlowStoreSnapshot storeSnapshot, storeSnapshotLastRow
    storeSnapshotCaptured = True
    lastR = storeSnapshotLastRow
    If lastR < 2 Then Exit Sub
    stamp = Now
    If sourceRowCount <= 0 Then
        Set txIndex = CreateObject("Scripting.Dictionary")
        txIndex.CompareMode = vbTextCompare
    Else
        Set txIndex = BuildManualTransactionIndex(sourceData, sourceRowCount)
    End If
    data = storeSnapshot
    ReDim planAction(1 To UBound(data, 1))
    Set missingSourceIDs = New Collection
    Set invalidAmountIDs = New Collection

    '第1段階は全有効候補の検証と出力行構築検査だけを行う。
    'この走査とauto+manualの上限確認が終わるまで、シートへは書き込まない。
    For r = 1 To UBound(data, 1)
        If CellText(data(r, MANUAL_FLOW_COL_ACTIVE)) = MANUAL_ACTIVE Then
            rowCount = 0: rowList = vbNullString: canonicalIDs = vbNullString
            manualID = CellText(data(r, MANUAL_FLOW_COL_ID))
            txIDs = CellText(data(r, MANUAL_FLOW_COL_TX_IDS))
            baseKey = CellText(data(r, MANUAL_FLOW_COL_KEY))
            If Len(manualID) = 0 Or _
               StrComp(baseKey, "MANUAL>" & manualID, vbBinaryCompare) <> 0 Or _
               Not IsNumeric(data(r, MANUAL_FLOW_COL_AMOUNT)) Then _
                Err.Raise vbObjectError + 4953, "AppendManualFlowAnalysisRecords", _
                          "W_手動資金候補 " & CStr(r + 1) & "行目が不正です。"
            amountValue = CDbl(data(r, MANUAL_FLOW_COL_AMOUNT))
            If amountValue <= 0 Or amountValue > MAX_ABS_AMOUNT Then _
                Err.Raise vbObjectError + 4963, "AppendManualFlowAnalysisRecords", _
                          "W_手動資金候補 " & CStr(r + 1) & "行目の追跡額が不正です。"
            If Not ManualTransactionIDsExist(txIDs, txIndex) Then
                '口座削除・訂正で元取引が消えた候補は、出力全体を止めず理由付きで履歴化する。
                replacementMemo = AppendAnalysisMemo( _
                    CellText(data(r, MANUAL_FLOW_COL_MEMO)), _
                    "[自動] 元取引が存在しないため候補を無効化しました。")
                planAction(r) = MANUAL_APPEND_MISSING_SOURCE
                If PlanManualFlowStoreContentIfChanged(data, r, _
                        CellText(data(r, MANUAL_FLOW_COL_STATUS)), replacementMemo, _
                        MANUAL_INACTIVE, CellText(data(r, MANUAL_FLOW_COL_EVIDENCE)), _
                        stamp) Then storeChangePlanned = True
                missingSourceIDs.Add manualID
                GoTo NextManualValidation
            End If
            ManualRowsForIDs txIDs, txIndex, sourceData, rows, rowCount, rowList, canonicalIDs
            totalWithdrawal = 0: totalDeposit = 0
            ManualTotals sourceData, rows, rowCount, totalWithdrawal, totalDeposit
            If totalWithdrawal <= 0 Or totalDeposit <= 0 Then _
                Err.Raise vbObjectError + 4964, "AppendManualFlowAnalysisRecords", _
                          "W_手動資金候補 " & CStr(r + 1) & _
                          "行目は出金・入金の両方を含んでいません。"
            If totalWithdrawal < totalDeposit Then _
                maximumTrackingAmount = totalWithdrawal Else maximumTrackingAmount = totalDeposit
            If amountValue > maximumTrackingAmount And _
               Not ManualAmountsMatch(amountValue, maximumTrackingAmount) Then
                replacementMemo = AppendAnalysisMemo( _
                    CellText(data(r, MANUAL_FLOW_COL_MEMO)), _
                    "[自動] 追跡額が現在の出金計・入金計の小さい方を超えたため候補を無効化しました。")
                planAction(r) = MANUAL_APPEND_AMOUNT_INVALID
                If PlanManualFlowStoreContentIfChanged(data, r, _
                        ANALYSIS_STATUS_FOLLOWUP, replacementMemo, MANUAL_INACTIVE, _
                        CellText(data(r, MANUAL_FLOW_COL_EVIDENCE)), stamp) Then _
                    storeChangePlanned = True
                invalidAmountIDs.Add manualID
                GoTo NextManualValidation
            End If
            evidenceText = AnalysisEvidenceDigest(sourceData, rowList, _
                           "MANUAL|AMT=" & Trim$(Str$(amountValue)))
            statusText = CellText(data(r, MANUAL_FLOW_COL_STATUS))
            If Len(statusText) = 0 Then statusText = ANALYSIS_STATUS_UNREVIEWED
            If Not ManualFlowReviewStatus(statusText) Then _
                Err.Raise vbObjectError + 4965, "AppendManualFlowAnalysisRecords", _
                          "W_手動資金候補 " & CStr(r + 1) & "行目の確認状況が不正です。"
            memoText = CellText(data(r, MANUAL_FLOW_COL_MEMO))
            storedEvidence = CellText(data(r, MANUAL_FLOW_COL_EVIDENCE))
            If Len(storedEvidence) > 0 And _
               StrComp(storedEvidence, evidenceText, vbBinaryCompare) <> 0 Then
                statusText = ANALYSIS_STATUS_FOLLOWUP
                memoText = AppendAnalysisMemo(memoText, _
                    "[自動] 構成取引または追跡額の変更を検知し、再確認へ戻しました。")
            End If
            '出力文字列・日付時刻・優先度まで第1段階で構築し、後段だけで
            '初めて発覚する候補固有エラーを残さない。
            WriteManualFlowOutputRow validationSheet, 0, sourceData, rows, rowCount, _
                                     canonicalIDs, amountValue, statusText, memoText, _
                                     AnalysisStoredKey(baseKey, evidenceText), _
                                     totalWithdrawal, totalDeposit, validationScore, True
            planAction(r) = MANUAL_APPEND_OUTPUT
            validCount = validCount + 1
            If PlanManualFlowStoreContentIfChanged(data, r, statusText, memoText, _
                    MANUAL_ACTIVE, evidenceText, stamp) Then storeChangePlanned = True
        End If
NextManualValidation:
    Next r

    prospectiveFlowCount = CDbl(flowCount) + CDbl(validCount)
    If Not ManualFlowCombinedOutputCountIsSafe(flowCount, validCount) Then _
        Err.Raise vbObjectError + 5030, "AppendManualFlowAnalysisRecords", _
                  "自動候補と有効な手動候補を合わせた資金フロー追跡が実用上限（" & _
                  Format$(MAX_ANALYSIS_OUTPUT_ROWS, "#,##0") & "件）を超えます。" & _
                  "既存結果と手動候補の保存内容は変更していません。"

    originalFlowCount = flowCount
    If validCount > 0 Then
        ReDim validCanonicalIDs(1 To validCount)
        ReDim validScores(1 To validCount)
        CaptureConstantDataStoreSnapshot wsOut, FLOW_ANALYSIS_LAST_COL, _
                                         flowSnapshot, flowSnapshotLastRow
        flowSnapshotCaptured = True
        If flowSnapshotLastRow <> originalFlowCount + 1 Then _
            Err.Raise vbObjectError + 5031, "AppendManualFlowAnalysisRecords", _
                      "自動資金フロー候補の件数と出力表の行数が一致しません。"
        outputWriteStarted = True
        wsOut.Unprotect Password:=TOOL_PASSWORD
        outputRow = originalFlowCount + 2

        '第2段階でのみ書込む。1行ごとに1×22配列を一括代入し、全列を読戻す。
        For r = 1 To UBound(data, 1)
            If planAction(r) = MANUAL_APPEND_OUTPUT Then
                rowCount = 0: rowList = vbNullString: canonicalIDs = vbNullString
                txIDs = CellText(data(r, MANUAL_FLOW_COL_TX_IDS))
                baseKey = CellText(data(r, MANUAL_FLOW_COL_KEY))
                amountValue = CDbl(data(r, MANUAL_FLOW_COL_AMOUNT))
                ManualRowsForIDs txIDs, txIndex, sourceData, rows, rowCount, _
                                 rowList, canonicalIDs
                totalWithdrawal = 0#: totalDeposit = 0#
                ManualTotals sourceData, rows, rowCount, totalWithdrawal, totalDeposit
                evidenceText = CellText(data(r, MANUAL_FLOW_COL_EVIDENCE))
                statusText = CellText(data(r, MANUAL_FLOW_COL_STATUS))
                memoText = CellText(data(r, MANUAL_FLOW_COL_MEMO))
                WriteManualFlowOutputRow wsOut, outputRow, sourceData, rows, rowCount, _
                                         canonicalIDs, amountValue, statusText, memoText, _
                                         AnalysisStoredKey(baseKey, evidenceText), _
                                         totalWithdrawal, totalDeposit, manualScore
                validIndex = validIndex + 1
                validCanonicalIDs(validIndex) = canonicalIDs
                validScores(validIndex) = manualScore
                outputRow = outputRow + 1
            End If
        Next r
        If validIndex <> validCount Then _
            Err.Raise vbObjectError + 5032, "AppendManualFlowAnalysisRecords", _
                      "手動候補の事前件数と出力件数が一致しません。"
    End If

    If storeChangePlanned Then
        Set storeTarget = wsStore.Range(wsStore.Cells(2, 1), _
                                        wsStore.Cells(lastR, MANUAL_FLOW_STORE_LAST_COL))
        storeWriteStarted = True
        storeTarget.Value2 = data
        If Not RangeValue2MatchesMatrixStrict( _
                   storeTarget, data, UBound(data, 1), _
                   MANUAL_FLOW_STORE_LAST_COL) Then _
            Err.Raise vbObjectError + 5033, "AppendManualFlowAnalysisRecords", _
                      "手動候補の保存内容が事前計画と一致しません。"
        RequireAnalysisReviewConstantRange storeTarget, "手動資金候補の保存記録"
    End If

    If validCount > 0 Then _
        FinalizeAdvancedFlowAnalysisSheet wsOut, CLng(prospectiveFlowCount)
    SetSheetVeryHiddenSafe wsStore
    If Not ManualFlowStoreIsVeryHidden(wsStore) Then _
        Err.Raise vbObjectError + 4971, "AppendManualFlowAnalysisRecords", _
                  "手動資金候補を内部非表示へ戻せません。"

    '全書込と保護・非表示確認が成功してから、呼出元の一時集計へ反映する。
    For validIndex = 1 To validCount
        UpdateManualCandidateStatistics validCanonicalIDs(validIndex), candidateCountByTx, _
                                        bestScoreByTx, bestRatingByTx, validScores(validIndex)
    Next validIndex
    flowCount = CLng(prospectiveFlowCount)
    On Error Resume Next
    For r = 1 To missingSourceIDs.Count
        AddCheck "警告", "手動資金候補", _
                 "元取引が存在しない候補を無効化しました: " & CStr(missingSourceIDs(r))
    Next r
    For r = 1 To invalidAmountIDs.Count
        AddCheck "警告", "手動資金候補", _
                 "追跡額が実在取引の上限を超える候補を無効化しました: " & _
                 CStr(invalidAmountIDs(r))
    Next r
    On Error GoTo 0
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    If IsManualFlowUpstreamRecoveryFatal(errorNumber, errorSource) Then
        Call TryStopManualFlowEventsForBookWrites(eventStateDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    eventsStoppedForRollback = _
        TryStopManualFlowEventsForBookWrites(eventStateDetail)
    If Not eventsStoppedForRollback And _
       (storeWriteStarted Or outputWriteStarted) Then
        rollbackFailed = True
        AppendManualFlowFailureDetail rollbackDescription, _
            "Excelイベント停止が未確認のため退避値を再書込みしませんでした: " & _
            eventStateDetail
    End If
    If eventsStoppedForRollback And storeWriteStarted And _
       storeSnapshotCaptured Then
        If Not TryRestoreManualFlowStoreAfterAppend( _
                   storeSnapshot, storeSnapshotLastRow, rollbackDescription) Then _
            rollbackFailed = True
    End If
    If eventsStoppedForRollback And outputWriteStarted And _
       flowSnapshotCaptured Then
        If Not TryRestoreManualFlowOutputAfterAppend( _
                   wsOut, flowSnapshot, flowSnapshotLastRow, _
                   originalFlowCount, rollbackDescription) Then _
            rollbackFailed = True
    End If
    If rollbackFailed Then
        AppendManualFlowFailureDetail errorDescription, _
            "内側ロールバック失敗（外側トランザクションで復旧）: " & _
            rollbackDescription
    End If
    If Len(errorSource) = 0 Then errorSource = "AppendManualFlowAnalysisRecords"
    Err.Raise errorNumber, errorSource, errorDescription
End Sub

Private Function ManualFlowCombinedOutputCountIsSafe( _
        ByVal automaticCount As Long, ByVal manualCount As Long) As Boolean
    Dim combinedCount As Double
    If automaticCount < 0 Or manualCount < 0 Then Exit Function
    combinedCount = CDbl(automaticCount) + CDbl(manualCount)
    ManualFlowCombinedOutputCountIsSafe = _
        (combinedCount <= CDbl(MAX_ANALYSIS_OUTPUT_ROWS))
End Function

Private Function PlanManualFlowStoreContentIfChanged( _
        ByRef data As Variant, ByVal dataRow As Long, _
        ByVal statusText As String, ByVal memoText As String, _
        ByVal activeText As String, ByVal evidenceText As String, _
        ByVal stamp As Date) As Boolean
    PlanManualFlowStoreContentIfChanged = ( _
        StrComp(CellText(data(dataRow, MANUAL_FLOW_COL_STATUS)), _
                statusText, vbBinaryCompare) <> 0 Or _
        StrComp(CellText(data(dataRow, MANUAL_FLOW_COL_MEMO)), _
                memoText, vbBinaryCompare) <> 0 Or _
        StrComp(CellText(data(dataRow, MANUAL_FLOW_COL_ACTIVE)), _
                activeText, vbBinaryCompare) <> 0 Or _
        StrComp(CellText(data(dataRow, MANUAL_FLOW_COL_EVIDENCE)), _
                evidenceText, vbBinaryCompare) <> 0)
    If Not PlanManualFlowStoreContentIfChanged Then Exit Function
    data(dataRow, MANUAL_FLOW_COL_STATUS) = ManualFlowExpectedValue2(statusText)
    data(dataRow, MANUAL_FLOW_COL_MEMO) = ManualFlowExpectedValue2(memoText)
    data(dataRow, MANUAL_FLOW_COL_ACTIVE) = ManualFlowExpectedValue2(activeText)
    data(dataRow, MANUAL_FLOW_COL_EVIDENCE) = ManualFlowExpectedValue2(evidenceText)
    data(dataRow, MANUAL_FLOW_COL_UPDATED_AT) = CDbl(stamp)
End Function

Private Function TryRestoreManualFlowStoreAfterAppend( _
        ByRef snapshot As Variant, ByVal snapshotLastRow As Long, _
        ByRef rollbackDescription As String) As Boolean
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim eventStateDetail As String
    On Error GoTo EH
    RestoreManualFlowStoreSnapshot snapshot, snapshotLastRow
    TryRestoreManualFlowStoreAfterAppend = True
    Exit Function
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    If IsManualFlowUpstreamRecoveryFatal(errorNumber, errorSource) Then
        Call TrySetManualFlowEnableEventsExact(False, eventStateDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    If Len(rollbackDescription) > 0 Then rollbackDescription = rollbackDescription & " / "
    rollbackDescription = rollbackDescription & "手動候補保存の復元失敗: Err " & _
                          CStr(errorNumber) & " " & errorDescription
End Function

Private Function TryRestoreManualFlowOutputAfterAppend( _
        ByVal ws As Worksheet, ByRef snapshot As Variant, _
        ByVal snapshotLastRow As Long, ByVal snapshotCount As Long, _
        ByRef rollbackDescription As String) As Boolean
    Dim restoredRange As Range
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim eventStateDetail As String
    On Error GoTo EH
    PrepareAdvancedFlowAnalysisSheet ws
    If snapshotLastRow >= 2 Then
        ws.Unprotect Password:=TOOL_PASSWORD
        Set restoredRange = ws.Range(ws.Cells(2, 1), _
                                     ws.Cells(snapshotLastRow, FLOW_ANALYSIS_LAST_COL))
        restoredRange.Value2 = snapshot
        If Not RangeValue2MatchesMatrixStrict( _
                   restoredRange, snapshot, snapshotLastRow - 1, _
                   FLOW_ANALYSIS_LAST_COL) Then _
            Err.Raise vbObjectError + 5034, "TryRestoreManualFlowOutputAfterAppend", _
                      "資金フロー追跡の復元読戻しが一致しません。"
    End If
    FinalizeAdvancedFlowAnalysisSheet ws, snapshotCount
    If LastDataRowInColumns(ws, 1, FLOW_ANALYSIS_LAST_COL) <> snapshotLastRow Then _
        Err.Raise vbObjectError + 5034, "TryRestoreManualFlowOutputAfterAppend", _
                  "資金フロー追跡の復元行数が一致しません。"
    If snapshotLastRow >= 2 Then
        Set restoredRange = ws.Range(ws.Cells(2, 1), _
                                     ws.Cells(snapshotLastRow, FLOW_ANALYSIS_LAST_COL))
        If Not RangeValue2MatchesMatrixStrict( _
                   restoredRange, snapshot, snapshotLastRow - 1, _
                   FLOW_ANALYSIS_LAST_COL) Then
            '同順位行の再Sort順がExcel版で変わっても、退避時の行順を最後に厳密復元する。
            ws.Unprotect Password:=TOOL_PASSWORD
            restoredRange.Value2 = snapshot
            If Not RangeValue2MatchesMatrixStrict( _
                       restoredRange, snapshot, snapshotLastRow - 1, _
                       FLOW_ANALYSIS_LAST_COL) Then _
                Err.Raise vbObjectError + 5034, "TryRestoreManualFlowOutputAfterAppend", _
                          "資金フロー追跡の復元後全列が一致しません。"
            ProtectSingleAnalysisSheet ws
        End If
    End If
    TryRestoreManualFlowOutputAfterAppend = True
    Exit Function
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    If IsManualFlowUpstreamRecoveryFatal(errorNumber, errorSource) Then
        Call TrySetManualFlowEnableEventsExact(False, eventStateDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    If Len(rollbackDescription) > 0 Then rollbackDescription = rollbackDescription & " / "
    rollbackDescription = rollbackDescription & "資金フロー追跡の復元失敗: Err " & _
                          CStr(errorNumber) & " " & errorDescription
End Function

Private Function ManualTransactionIDsExist(ByVal txIDs As String, ByVal txIndex As Object) As Boolean
    Dim parts As Variant, item As Variant, txID As String, seen As Object
    If txIndex Is Nothing Then Exit Function
    Set seen = CreateObject("Scripting.Dictionary")
    seen.CompareMode = vbTextCompare
    parts = Split(txIDs, ";")
    For Each item In parts
        txID = Trim$(CStr(item))
        If Len(txID) > 0 Then
            If Not txIndex.Exists(txID) Then Exit Function
            seen(txID) = True
        End If
    Next item
    ManualTransactionIDsExist = (seen.Count >= 2)
End Function

Public Sub SyncManualFlowReviewsFromAnalysisSheet( _
        Optional ByVal capacityConfirmed As Boolean = False)
    Dim wsFlow As Worksheet, wsStore As Worksheet, storeIndex As Object
    Dim lastR As Long, storeLastR As Long, data As Variant, r As Long
    Dim storedKey As String, baseKey As String, evidenceText As String
    Dim statusText As String, memoText As String, rowNo As Long
    Dim checkRange As Range, seenTargets As Object, targetID As String
    Dim planRows() As Long, planStatuses() As String, planMemos() As String
    Dim planEvidence() As String, planCount As Long, stamp As Date
    Dim storeSnapshot As Variant, storeSnapshotLastRow As Long
    Dim snapshotCaptured As Boolean, writeStarted As Boolean, rollbackFailed As Boolean
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim rollbackDescription As String
    Dim eventStateDetail As String, recoveryStateDetail As String
    Dim eventsStoppedForRollback As Boolean, recoveryStateConfirmed As Boolean
    Dim recoveryEnforcementAttempted As Boolean, recoveryEnforcementFailed As Boolean
    If Not SheetExists(SH_ANALYSIS_FLOW) Or Not SheetExists(SH_WORK_MANUAL_FLOW) Then Exit Sub
    If Not capacityConfirmed Then
        If Not RequireManualFlowMutationCapacity("手動候補の確認内容同期") Then _
            Err.Raise 18, "SyncManualFlowReviewsFromAnalysisSheet", _
                      "利用者が手動候補の確認内容同期を中止しました。"
    End If
    Set wsFlow = GetSheet(SH_ANALYSIS_FLOW)
    Set wsStore = GetSheet(SH_WORK_MANUAL_FLOW)
    If Not TryGetLastUsedRowInSheet(wsFlow, lastR) Then _
        Err.Raise vbObjectError + 4960, "SyncManualFlowReviewsFromAnalysisSheet", _
                  "資金フロー追跡の最終行を確認できません。"
    If lastR < 2 Then Exit Sub
    Set checkRange = Union( _
        wsFlow.Range(wsFlow.Cells(2, 3), wsFlow.Cells(lastR, 3)), _
        wsFlow.Range(wsFlow.Cells(2, FLOW_ANALYSIS_STATUS_COL), _
                     wsFlow.Cells(lastR, FLOW_ANALYSIS_MEMO_COL)), _
        wsFlow.Range(wsFlow.Cells(2, FLOW_ANALYSIS_KEY_COL), _
                     wsFlow.Cells(lastR, FLOW_ANALYSIS_KEY_COL)))
    RequireAnalysisReviewConstantRange checkRange, _
        "資金フロー追跡の確認欄または内部キー"
    CaptureManualFlowStoreSnapshot storeSnapshot, storeSnapshotLastRow
    snapshotCaptured = True
    storeLastR = storeSnapshotLastRow
    Set storeIndex = CreateObject("Scripting.Dictionary")
    storeIndex.CompareMode = vbBinaryCompare
    For r = 2 To storeLastR
        baseKey = CellText(wsStore.Cells(r, MANUAL_FLOW_COL_KEY).Value)
        If Len(baseKey) > 0 Then
            If storeIndex.Exists(baseKey) Then _
                Err.Raise vbObjectError + 4960, _
                          "SyncManualFlowReviewsFromAnalysisSheet", _
                          "手動資金候補の確認キーが重複しています: " & baseKey
            storeIndex.Add baseKey, r
        End If
    Next r
    data = wsFlow.Range(wsFlow.Cells(2, 1), wsFlow.Cells(lastR, FLOW_ANALYSIS_LAST_COL)).Value2
    ReDim planRows(1 To lastR - 1)
    ReDim planStatuses(1 To lastR - 1)
    ReDim planMemos(1 To lastR - 1)
    ReDim planEvidence(1 To lastR - 1)
    Set seenTargets = CreateObject("Scripting.Dictionary")
    seenTargets.CompareMode = vbTextCompare
    On Error GoTo EH
    For r = 1 To UBound(data, 1)
        If CellText(data(r, 3)) = "手動指定" Then
            storedKey = CellText(data(r, FLOW_ANALYSIS_KEY_COL))
            baseKey = AnalysisBaseKey(storedKey, evidenceText)
            If Not storeIndex.Exists(baseKey) Then _
                Err.Raise vbObjectError + 4960, "SyncManualFlowReviewsFromAnalysisSheet", _
                          "資金フロー追跡 " & CStr(r + 1) & "行目の手動候補保存記録がありません。"
            statusText = CellText(data(r, FLOW_ANALYSIS_STATUS_COL))
            If Len(statusText) = 0 Then statusText = ANALYSIS_STATUS_UNREVIEWED
            If Not ManualFlowReviewStatus(statusText) Then _
                Err.Raise vbObjectError + 4961, "SyncManualFlowReviewsFromAnalysisSheet", _
                          "資金フロー追跡 " & CStr(r + 1) & "行目の確認状況が不正です。"
            memoText = CellText(data(r, FLOW_ANALYSIS_MEMO_COL))
            If Len(memoText) > 1000 Then _
                Err.Raise vbObjectError + 4962, "SyncManualFlowReviewsFromAnalysisSheet", _
                          "資金フロー追跡 " & CStr(r + 1) & "行目の確認メモが長すぎます。"
            rowNo = CLng(storeIndex(baseKey))
            targetID = CStr(rowNo)
            If seenTargets.Exists(targetID) Then _
                Err.Raise vbObjectError + 4960, _
                          "SyncManualFlowReviewsFromAnalysisSheet", _
                          "資金フロー追跡に同じ手動候補が重複しています: " & baseKey
            seenTargets.Add targetID, True
            planCount = planCount + 1
            planRows(planCount) = rowNo
            planStatuses(planCount) = statusText
            planMemos(planCount) = memoText
            planEvidence(planCount) = evidenceText
        End If
    Next r
    If planCount > 0 Then
        stamp = Now
        writeStarted = True
        For r = 1 To planCount
            WriteManualFlowStoreContentIfChanged wsStore, planRows(r), _
                planStatuses(r), planMemos(r), _
                CellText(wsStore.Cells(planRows(r), MANUAL_FLOW_COL_ACTIVE).Value2), _
                planEvidence(r), stamp
        Next r
    End If
    SetSheetVeryHiddenSafe wsStore
    If Not ManualFlowStoreIsVeryHidden(wsStore) Then _
        Err.Raise vbObjectError + 4971, "SyncManualFlowReviewsFromAnalysisSheet", _
                  "手動資金候補を内部非表示へ戻せません。"
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    If IsManualFlowUpstreamRecoveryFatal(errorNumber, errorSource) Then
        Call TryStopManualFlowEventsForBookWrites(eventStateDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    If writeStarted And snapshotCaptured Then
        eventsStoppedForRollback = _
            TryStopManualFlowEventsForBookWrites(eventStateDetail)
        If eventsStoppedForRollback Then
            On Error Resume Next
            Err.Clear
            RestoreManualFlowStoreSnapshot storeSnapshot, storeSnapshotLastRow
            If Err.Number <> 0 Then
                rollbackFailed = True
                rollbackDescription = Err.Description
            End If
            Err.Clear
            On Error GoTo 0
        Else
            rollbackFailed = True
            rollbackDescription = _
                "Excelイベント停止が未確認のため退避値を再書込みしませんでした: " & _
                eventStateDetail
        End If
        If rollbackFailed Then
            AppendManualFlowFailureDetail errorDescription, _
                "内側ロールバック失敗（外側トランザクションで復旧）: " & _
                rollbackDescription
        End If
    End If
    If Len(errorSource) = 0 Then _
        errorSource = "SyncManualFlowReviewsFromAnalysisSheet"
    Err.Raise errorNumber, errorSource, errorDescription
End Sub

Private Sub WriteManualFlowOutputRow(ByVal ws As Worksheet, ByVal outputRow As Long, _
                                     ByRef sourceData As Variant, ByRef rows() As Long, _
                                     ByVal rowCount As Long, ByVal txIDs As String, _
                                     ByVal amountValue As Double, ByVal statusText As String, _
                                     ByVal memoText As String, ByVal storedKey As String, _
                                     ByVal totalWithdrawal As Double, _
                                     ByVal totalDeposit As Double, _
                                     ByRef manualScore As Long, _
                                     Optional ByVal validateOnly As Boolean = False)
    Dim i As Long, rowNo As Long, firstRow As Long, lastRow As Long
    Dim pathText As String, orderText As String, withdrawalText As String, depositText As String
    Dim accountText As String, directionText As String, itemText As String
    Dim hasAnyTime As Boolean, hasAllTimes As Boolean, hasSameDayUnknownOrder As Boolean
    Dim pathSeparator As String, orderSeparator As String
    Dim differenceAmount As Double
    Dim untrackedWithdrawal As Double, untrackedDeposit As Double
    Dim reasonText As String
    Dim expectedData As Variant, target As Range
    hasAllTimes = True
    hasSameDayUnknownOrder = ManualHasSameDayUnknownOrder(sourceData, rows, rowCount)
    If hasSameDayUnknownOrder Then
        pathSeparator = " / "
        orderSeparator = " / "
    Else
        pathSeparator = " → "
        orderSeparator = " → "
    End If
    firstRow = rows(1): lastRow = rows(rowCount)
    For i = 1 To rowCount
        rowNo = rows(i)
        If HasText(sourceData(rowNo, OUT_COL_TIME)) Then hasAnyTime = True Else hasAllTimes = False
        accountText = ManualAccountText(sourceData, rowNo)
        If CDbl(ManualNumber(sourceData(rowNo, OUT_COL_WITHDRAW))) > 0 Then
            directionText = "出金"
            itemText = ManualTransactionText(sourceData, rowNo, directionText, _
                                              CDbl(sourceData(rowNo, OUT_COL_WITHDRAW)))
            If Len(withdrawalText) > 0 Then withdrawalText = withdrawalText & " / "
            withdrawalText = withdrawalText & itemText
        Else
            directionText = "入金"
            itemText = ManualTransactionText(sourceData, rowNo, directionText, _
                                              CDbl(sourceData(rowNo, OUT_COL_DEPOSIT)))
            If Len(depositText) > 0 Then depositText = depositText & " / "
            depositText = depositText & itemText
        End If
        If Len(pathText) > 0 Then pathText = pathText & pathSeparator
        pathText = pathText & accountText & "（" & directionText & "）"
        If Len(orderText) > 0 Then orderText = orderText & orderSeparator
        orderText = orderText & ManualDateTimeText(sourceData, rowNo) & " " & directionText
    Next i
    If hasSameDayUnknownOrder Then
        pathText = "役割表示（同日内順序不明）: " & pathText
        orderText = "同日内順序不明: " & orderText
    End If
    differenceAmount = Abs(totalWithdrawal - totalDeposit)
    untrackedWithdrawal = totalWithdrawal - amountValue
    untrackedDeposit = totalDeposit - amountValue
    manualScore = ManualCandidatePriority(totalWithdrawal, totalDeposit, _
                                           amountValue, hasAllTimes)

    reasonText = "利用者が構成取引を選定した未検証候補です。" & _
                 "追跡指定額 " & Format$(amountValue, "#,##0.########") & _
                 "、出金計 " & Format$(totalWithdrawal, "#,##0.########") & _
                 "、入金計 " & Format$(totalDeposit, "#,##0.########") & _
                 "、起終点差 " & Format$(differenceAmount, "#,##0.########") & "。"
    If untrackedWithdrawal > 0 Or untrackedDeposit > 0 Then
        reasonText = reasonText & "追跡指定外は出金側 " & _
                     Format$(Application.Max(0#, untrackedWithdrawal), "#,##0.########") & _
                     "、入金側 " & _
                     Format$(Application.Max(0#, untrackedDeposit), "#,##0.########") & "。"
    End If
    reasonText = reasonText & ManualTimeEvidenceNotice( _
                     Not hasAllTimes, hasSameDayUnknownOrder)

    ReDim expectedData(1 To 1, 1 To FLOW_ANALYSIS_LAST_COL)
    expectedData(1, 1) = CStr("要確認")
    expectedData(1, 2) = CDbl(manualScore)
    expectedData(1, 3) = CStr("手動指定")
    expectedData(1, 4) = CStr("利用者選定・未検証")
    expectedData(1, 5) = ManualFlowExpectedValue2( _
                              ManualTimeCoverageText(hasAnyTime, hasAllTimes))
    expectedData(1, 6) = ManualFlowExpectedValue2( _
                              ManualPeriodText(sourceData, firstRow, lastRow, _
                                               hasAllTimes, hasSameDayUnknownOrder))
    expectedData(1, 7) = CDbl(Application.Max(1, rowCount - 1))
    expectedData(1, 8) = CDbl(rowCount)
    expectedData(1, 9) = totalWithdrawal
    expectedData(1, 10) = totalDeposit
    expectedData(1, 11) = differenceAmount
    expectedData(1, 12) = ManualFlowExpectedValue2(pathText)
    expectedData(1, 13) = ManualFlowExpectedValue2(orderText)
    expectedData(1, 14) = ManualFlowExpectedValue2(withdrawalText)
    expectedData(1, 15) = ManualFlowExpectedValue2(depositText)
    expectedData(1, 16) = ManualFlowExpectedValue2(reasonText)
    expectedData(1, 17) = ManualFlowExpectedValue2(statusText)
    expectedData(1, 18) = ManualFlowExpectedValue2(memoText)
    expectedData(1, 19) = ManualFlowExpectedValue2(storedKey)
    expectedData(1, 20) = ManualFlowExpectedValue2(txIDs)
    expectedData(1, 21) = ManualFlowExpectedValue2( _
                               CellText(sourceData(firstRow, WORK_TX_COL_ACCOUNT_ID)))
    expectedData(1, 22) = ManualFlowExpectedValue2( _
                               CellText(sourceData(lastRow, WORK_TX_COL_ACCOUNT_ID)))
    If validateOnly Then Exit Sub
    If ws Is Nothing Or outputRow < 2 Then _
        Err.Raise vbObjectError + 5035, "WriteManualFlowOutputRow", _
                  "手動候補の出力先が不正です。"
    Set target = ws.Range(ws.Cells(outputRow, 1), _
                          ws.Cells(outputRow, FLOW_ANALYSIS_LAST_COL))
    target.Value2 = expectedData
    If Not RangeValue2MatchesMatrixStrict( _
               target, expectedData, 1, FLOW_ANALYSIS_LAST_COL) Then _
        Err.Raise vbObjectError + 5036, "WriteManualFlowOutputRow", _
                  "手動候補の一括書込読戻しが全22列・型で一致しません。"
    RequireAnalysisReviewConstantRange target, _
                                       "資金フロー追跡の手動候補 " & CStr(outputRow) & "行"
End Sub

Private Function ManualCandidatePriority(ByVal totalWithdrawal As Double, _
                                         ByVal totalDeposit As Double, _
                                         ByVal trackingAmount As Double, _
                                         ByVal hasAllTimes As Boolean) As Long
    Dim scoreValue As Long, differenceAmount As Double, smallerTotal As Double
    differenceAmount = Abs(totalWithdrawal - totalDeposit)
    If totalWithdrawal < totalDeposit Then smallerTotal = totalWithdrawal Else smallerTotal = totalDeposit
    scoreValue = 40
    If differenceAmount <= Application.Max(1#, smallerTotal * 0.001) Then
        scoreValue = scoreValue + 10
    ElseIf smallerTotal > 0 And differenceAmount <= smallerTotal * 0.05 Then
        scoreValue = scoreValue + 5
    End If
    If hasAllTimes Then scoreValue = scoreValue + 5
    If trackingAmount < smallerTotal And _
       Not ManualAmountsMatch(trackingAmount, smallerTotal) Then scoreValue = scoreValue - 5
    If scoreValue < 1 Then scoreValue = 1
    If scoreValue > 55 Then scoreValue = 55
    ManualCandidatePriority = scoreValue
End Function

Public Sub DeactivateManualFlowCandidateByStoredKey(ByVal storedKey As String)
    Dim ws As Worksheet, baseKey As String, evidenceText As String
    Dim lastR As Long, r As Long, targetRow As Long
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim storeSnapshot As Variant, storeSnapshotLastRow As Long, storeChanged As Boolean
    Dim allocationSnapshot As Variant, allocationSnapshotLastRow As Long
    Dim allocationSnapshotDigest As String, allocationSnapshotCaptured As Boolean
    Dim allocationSnapshotCellWork As Double
    Dim analysisBuildStarted As Boolean, rollbackFailed As Boolean
    Dim reviewsWerePending As Boolean
    Dim outputsWereDirty As Boolean, outputDirtyAttempted As Boolean, outputDirtyConfirmed As Boolean
    Dim safetyStopRequired As Boolean
    Dim entryEvents As Boolean, entryEventsCaptured As Boolean
    Dim appBeginAttempted As Boolean, applicationLeaseStarted As Boolean
    Dim operationCommitted As Boolean
    Dim mutationStarted As Boolean, cleanupEventsStopped As Boolean
    Dim recoveryStateConfirmed As Boolean, recoveryEnforcementAttempted As Boolean
    Dim recoveryEnforcementFailed As Boolean
    Dim reportingAllowed As Boolean
    Dim appStateRestored As Boolean, entryEventsRestored As Boolean
    Dim eventRestoreRequiredRecovery As Boolean
    Dim eventStateDetail As String, applicationStateDetail As String
    Dim entryRestoreDetail As String, recoveryDetail As String
    Dim confirmedAnalysisWorkloadRows As Double
    On Error GoTo EH
    If Not TryGetManualFlowEnableEvents(entryEvents, eventStateDetail) Then _
        Err.Raise vbObjectError + 5116, _
                  "DeactivateManualFlowCandidateByStoredKey", _
                  "Excelイベントの開始状態を取得できませんでした。 " & _
                  eventStateDetail
    entryEventsCaptured = True
    If Not TrySetManualFlowEnableEventsExact(False, eventStateDetail) Then _
        Err.Raise vbObjectError + 5117, _
                  "DeactivateManualFlowCandidateByStoredKey", _
                  "事前確認より前にExcelイベントを停止できませんでした。 " & _
                  eventStateDetail
    If Not RequireToolReady() Then GoTo CleanExit
    If Not RequireNoPendingAccountInput("手動分析候補の無効化") Then GoTo CleanExit
    If Not RequireManualFlowMutationCapacity("手動候補の無効化") Then
        SetInputStatus "手動候補の無効化を開始せず中止しました。保存内容は変更していません。"
        GoTo CleanExit
    End If
    If Not RequireOutputBuildCapacity("手動候補の無効化と分析更新", _
            True, False, False, True, False, False) Then
        SetInputStatus "手動候補の無効化を開始せず中止しました。保存内容は変更していません。"
        GoTo CleanExit
    End If
    allocationSnapshotCellWork = _
        CDbl(AllocationLedgerStoredRowCount() + 1) * 10#
    If Not ConfirmAnalysisReviewOperationCapacity( _
            "手動候補の無効化と分析更新", confirmedAnalysisWorkloadRows, _
            additionalSnapshotCellWork:=allocationSnapshotCellWork * 2#) Then
        SetInputStatus "手動候補の無効化を開始せず中止しました。保存内容は変更していません。"
        GoTo CleanExit
    End If
    If Not RequireInternalStoresSafeForWrite(False, False) Then GoTo CleanExit
    If HasSelectedAnalysisDetailTransactions() Then
        MsgBox "候補詳細に、手動候補として未登録の選択取引があります。" & vbCrLf & _
               "既存候補を無効化する前に、選択した候補を登録するか選択を解除してください。" & vbCrLf & _
               "分析再構築で選択内容を黙って破棄することはありません。", _
               vbInformation, "手動候補の選択を完了してください"
        GoTo CleanExit
    End If
    baseKey = AnalysisBaseKey(storedKey, evidenceText)
    If Left$(baseKey, 7) <> "MANUAL>" Then GoTo CleanExit
    reviewsWerePending = HasPendingAnalysisReviewChanges()
    If MsgBox("この手動候補を無効にしますか？" & vbCrLf & _
              "記録は削除せず、後から同じ取引を選ぶと再有効化できます。", _
              vbYesNo + vbQuestion + vbDefaultButton2) <> vbYes Then GoTo CleanExit
    Set ws = GetSheet(SH_WORK_MANUAL_FLOW)
    CaptureManualFlowStoreSnapshot storeSnapshot, storeSnapshotLastRow
    lastR = LastUsedRowInSheet(ws)
    For r = 2 To lastR
        If StrComp(CellText(ws.Cells(r, MANUAL_FLOW_COL_KEY).Value), _
                   baseKey, vbBinaryCompare) = 0 Then
            targetRow = r
            Exit For
        End If
    Next r
    If targetRow = 0 Then _
        Err.Raise vbObjectError + 4954, _
                  "DeactivateManualFlowCandidateByStoredKey", _
                  "手動候補の保存記録が見つかりません。"
    CaptureAllocationLedgerTransactionSnapshot allocationSnapshot, _
        allocationSnapshotLastRow, allocationSnapshotDigest
    allocationSnapshotCaptured = True
    If Not TryConfirmManualFlowApplicationState(applicationStateDetail) Then _
        RaiseManualFlowRecoveryFatal _
            "DeactivateManualFlowCandidateByStoredKey", 0, _
            "DeactivateManualFlowCandidateByStoredKey", _
            "AppBegin前のApplication状態が安全ではありません。", _
            applicationStateDetail
    AppBegin "手動候補を無効にして資金操作表を更新しています..."
    appBeginAttempted = True
    applicationLeaseStarted = True
    If Not TrySetManualFlowEnableEventsExact(False, eventStateDetail) Then _
        Err.Raise vbObjectError + 5117, _
                  "DeactivateManualFlowCandidateByStoredKey", _
                  "保存内容の変更前にExcelイベントを停止できませんでした。 " & _
                  eventStateDetail
    outputsWereDirty = OutputsAreDirty()
    outputDirtyAttempted = True
    mutationStarted = True
    MarkOutputsDirty
    outputDirtyConfirmed = True
    '関数内の書込後読戻しで失敗しても、戻り値代入前の例外で
    'ロールバック対象を見失わないよう、書込開始を先に記録する。
    storeChanged = True
    WriteManualFlowStoreContentIfChanged _
        ws, targetRow, _
        CellText(ws.Cells(targetRow, MANUAL_FLOW_COL_STATUS).Value2), _
        CellText(ws.Cells(targetRow, MANUAL_FLOW_COL_MEMO).Value2), _
        MANUAL_INACTIVE, _
        CellText(ws.Cells(targetRow, MANUAL_FLOW_COL_EVIDENCE).Value2), Now
    MarkAnalysisReviewsDirty
    analysisBuildStarted = True
    BuildTransactionAnalysisSheetsCore True, True, _
                                       confirmedAnalysisWorkloadRows, False, _
                                       allocationSnapshotCellWork
    MarkAnalysisReviewsClean
    If Not outputsWereDirty Then
        RequireManualFlowAuthoritativeStructure
        MarkOutputsClean
    End If
    operationCommitted = True
    AppEnd
    applicationLeaseStarted = False
CleanExit:
    If Not TrySetManualFlowEnableEventsExact(entryEvents, eventStateDetail) Then _
        Err.Raise vbObjectError + 5118, _
                  "DeactivateManualFlowCandidateByStoredKey", _
                  "処理開始時のExcelイベント状態を復元できませんでした。 " & _
                  eventStateDetail
    entryEventsCaptured = False
    If Not operationCommitted Then Exit Sub
    On Error Resume Next
    MsgBox "手動候補を無効にしました。", vbInformation
    Err.Clear
    On Error GoTo 0
    Exit Sub
EH:
    errorNumber = Err.Number: errorDescription = Err.Description
    errorSource = Err.Source
    If IsManualFlowUpstreamRecoveryFatal(errorNumber, errorSource) Then
        Call TryStopManualFlowEventsForBookWrites(eventStateDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    If Not appBeginAttempted And _
       StrComp(errorSource, "AppBegin", vbBinaryCompare) = 0 Then
        RaiseManualFlowRecoveryFatal _
            "DeactivateManualFlowCandidateByStoredKey", errorNumber, _
            errorSource, errorDescription, _
            "AppBeginが正常終了せず、Application leaseの所有を取得できませんでした。"
    End If
    If entryEventsCaptured Then
        cleanupEventsStopped = _
            TryStopManualFlowEventsForBookWrites(eventStateDetail)
        If Not cleanupEventsStopped Then _
            AppendManualFlowFailureDetail errorDescription, _
                "失敗復旧の開始前にExcelイベント停止を確認できません: " & _
                eventStateDetail
    Else
        AppendManualFlowFailureDetail errorDescription, _
            "Excelイベントの開始状態を取得していません。"
    End If

    If operationCommitted Then
        safetyStopRequired = True
        AppendManualFlowFailureDetail errorDescription, _
            "手動候補の無効化と分析結果は確定済みのため、開始前の退避値へ戻しません。"
    ElseIf mutationStarted And cleanupEventsStopped Then
        On Error Resume Next
        Err.Clear
        If storeChanged Then _
            RestoreManualFlowStoreSnapshot storeSnapshot, storeSnapshotLastRow
        If Err.Number <> 0 Then
            rollbackFailed = True
            AppendManualFlowFailureDetail errorDescription, _
                "手動候補保存のロールバック失敗: " & Err.Description
        End If
        Err.Clear
        If analysisBuildStarted And allocationSnapshotCaptured Then
            RestoreAllocationLedgerTransactionSnapshot allocationSnapshot, _
                allocationSnapshotLastRow, allocationSnapshotDigest
            If Err.Number <> 0 Then
                rollbackFailed = True
                AppendManualFlowFailureDetail errorDescription, _
                    "配賦元帳のロールバック失敗: " & Err.Description
            End If
            Err.Clear
        End If
        If outputDirtyAttempted Then
            If Not outputDirtyConfirmed Then safetyStopRequired = True
            If Not EnsureManualFlowFailureOutputsDirty(errorDescription) Then _
                safetyStopRequired = True
        End If
        If rollbackFailed Then safetyStopRequired = True
        If safetyStopRequired Then
            MarkAnalysisReviewsDirty
        ElseIf analysisBuildStarted Or reviewsWerePending Then
            MarkAnalysisReviewsDirty
        Else
            MarkAnalysisReviewsClean
        End If
        If Err.Number <> 0 Then
            safetyStopRequired = True
            AppendManualFlowFailureDetail errorDescription, _
                "分析要更新状態の記録エラー: " & Err.Description
        End If
        Err.Clear
        On Error GoTo 0
    ElseIf mutationStarted Then
        rollbackFailed = True
        safetyStopRequired = True
        AppendManualFlowFailureDetail errorDescription, _
            "Excelイベント停止が未確認のため、保存記録・配賦元帳へ退避値を再書込みしませんでした。"
    End If

    If safetyStopRequired And cleanupEventsStopped And _
       Not recoveryEnforcementAttempted Then
        EnforceManualFlowRecoveryStateTerminal _
            "DeactivateManualFlowCandidateByStoredKey", _
            "手動候補無効化の失敗復旧", recoveryDetail, _
            recoveryEnforcementAttempted, recoveryEnforcementFailed, _
            errorNumber, errorSource, errorDescription, _
            applicationLeaseStarted
    End If

    appStateRestored = TryEndManualFlowAppLease( _
                           applicationLeaseStarted, appBeginAttempted, _
                           applicationStateDetail)
    If Not appStateRestored Then
        safetyStopRequired = True
        AppendManualFlowFailureDetail errorDescription, applicationStateDetail
        cleanupEventsStopped = False
        If entryEventsCaptured Then _
            cleanupEventsStopped = _
                TryStopManualFlowEventsForBookWrites(eventStateDetail)
        If cleanupEventsStopped And mutationStarted And _
           Not recoveryEnforcementAttempted Then
            EnforceManualFlowRecoveryStateTerminal _
                "DeactivateManualFlowCandidateByStoredKey", _
                "手動候補無効化後のExcel状態復元失敗", _
                recoveryDetail, recoveryEnforcementAttempted, _
                recoveryEnforcementFailed, errorNumber, errorSource, _
                errorDescription, applicationLeaseStarted
        ElseIf Not cleanupEventsStopped Then
            AppendManualFlowFailureDetail errorDescription, _
                "Excel状態復元失敗後にイベント停止を確認できず、Recovery書込みを見送りました。"
        End If
        If applicationLeaseStarted And Not recoveryEnforcementFailed Then
            appStateRestored = TryEndManualFlowAppLease( _
                                   applicationLeaseStarted, _
                                   appBeginAttempted, applicationStateDetail)
            If Not appStateRestored Then _
                AppendManualFlowFailureDetail errorDescription, _
                    "Excel状態の通常復元再試行にも失敗しました: " & _
                    applicationStateDetail
        End If
        If Not appStateRestored And appBeginAttempted And _
           Not recoveryEnforcementFailed Then
            appStateRestored = _
                TryForceRestoreManualFlowApplicationState( _
                    applicationLeaseStarted, appBeginAttempted, _
                    applicationStateDetail)
            If Not appStateRestored Then
                AppendManualFlowFailureDetail errorDescription, _
                    "Excel状態の強制復元と全状態読戻しにも失敗しました: " & _
                    applicationStateDetail
                cleanupEventsStopped = _
                    TryStopManualFlowEventsForBookWrites(eventStateDetail)
                If Not cleanupEventsStopped Then _
                    AppendManualFlowFailureDetail errorDescription, _
                        "強制復元失敗後のイベントFalse収束にも失敗し、状態は不明です: " & _
                        eventStateDetail
            End If
        ElseIf recoveryEnforcementFailed And Not appStateRestored Then
            AppendManualFlowFailureDetail errorDescription, _
                "要復旧処理自体が失敗したため、Excel状態の通常再試行と強制復元を見送りました。"
        End If
    End If

    If (mutationStarted Or operationCommitted) And appStateRestored Then
        cleanupEventsStopped = False
        If entryEventsCaptured Then _
            cleanupEventsStopped = _
                TryStopManualFlowEventsForBookWrites(eventStateDetail)
        If safetyStopRequired And cleanupEventsStopped And _
           Not recoveryStateConfirmed And Not recoveryEnforcementAttempted Then
            EnforceManualFlowRecoveryStateTerminal _
                "DeactivateManualFlowCandidateByStoredKey", _
                "手動候補無効化の安全停止", recoveryDetail, _
                recoveryEnforcementAttempted, recoveryEnforcementFailed, _
                errorNumber, errorSource, errorDescription, _
                applicationLeaseStarted
        End If
        reportingAllowed = cleanupEventsStopped And _
                           (Not safetyStopRequired Or recoveryStateConfirmed)
        If reportingAllowed Then
            On Error Resume Next
            Err.Clear
            If operationCommitted Then
                AddCheck "エラー", "手動候補無効化の確定後処理", _
                    "Err " & CStr(errorNumber) & ": " & errorDescription
                If recoveryStateConfirmed Then
                    SetInputStatus _
                        "手動候補の無効化と分析結果は確定済みですが、後処理失敗を要復旧状態として記録しました。", _
                        True
                Else
                    SetInputStatus _
                        "手動候補の無効化と分析結果は確定済みですが、後処理後の安全状態を確認できません。上書き保存せずExcelを再起動してください。", _
                        True
                End If
            ElseIf safetyStopRequired Then
                AddCheck "エラー", "手動候補無効化ロールバック", _
                    "Err " & CStr(errorNumber) & ": " & errorDescription
                If recoveryStateConfirmed Then
                    SetInputStatus _
                        "手動候補の無効化に失敗し、ロールバック不成立を要復旧状態として記録しました。", _
                        True
                Else
                    SetInputStatus _
                        "手動候補の無効化に失敗し、安全状態を一意に確認できません。上書き保存せずExcelを再起動してください。", _
                        True
                End If
            ElseIf IsUserCancelError(errorNumber) Then
                SetInputStatus _
                    "手動候補の無効化を中断し、操作開始前の保存内容へ戻しました。"
            Else
                AddCheck "エラー", "手動候補無効化", _
                    "Err " & CStr(errorNumber) & ": " & errorDescription
                SetInputStatus _
                    "手動候補の無効化に失敗し、操作開始前の保存内容へ戻しました。C_チェックを確認してください。"
            End If
            Err.Clear
            On Error GoTo 0
        Else
            safetyStopRequired = True
            AppendManualFlowFailureDetail errorDescription, _
                "Excelイベント停止または復旧状態が未確認のため、チェック・状態表示を書き込みませんでした。"
        End If
    End If

    If entryEventsCaptured And appStateRestored Then
        entryEventsRestored = TryRestoreManualFlowEntryEvents( _
            entryEvents, mutationStarted Or operationCommitted, _
            appStateRestored And _
                ((Not mutationStarted And Not operationCommitted) Or _
                 (mutationStarted And Not operationCommitted And _
                  Not safetyStopRequired And Not rollbackFailed)), _
            "手動候補無効化のイベント復元失敗: " & _
            errorDescription, recoveryStateConfirmed, _
            recoveryEnforcementAttempted, recoveryEnforcementFailed, _
            eventRestoreRequiredRecovery, _
            entryRestoreDetail)
        If eventRestoreRequiredRecovery Then safetyStopRequired = True
        If Not entryEventsRestored Then safetyStopRequired = True
        AppendManualFlowFailureDetail errorDescription, entryRestoreDetail
    ElseIf Not entryEventsCaptured Then
        safetyStopRequired = True
    Else
        safetyStopRequired = True
        cleanupEventsStopped = _
            TryStopManualFlowEventsForBookWrites(eventStateDetail)
        If cleanupEventsStopped Then
            AppendManualFlowFailureDetail errorDescription, _
                "Application状態が未復元のため開始時イベント値へ戻さず、Falseへ収束させました。"
        Else
            AppendManualFlowFailureDetail errorDescription, _
                "Application状態が未復元で、イベントFalseへの収束も確認できません。"
        End If
    End If

    If IsUserCancelError(errorNumber) And Not safetyStopRequired And _
       Not operationCommitted Then Exit Sub
    On Error Resume Next
    If Not appStateRestored Then
        If operationCommitted Then
            MsgBox "手動候補の無効化と分析結果は確定済みですが、Application状態は不明です。" & _
                   vbCrLf & "Excelイベントを開始時の値へ戻していません。" & _
                   vbCrLf & "現在のブックを上書きせず、Excelを再起動してください。" & _
                   vbCrLf & "Err " & CStr(errorNumber) & ": " & _
                   errorDescription, vbCritical
        Else
            MsgBox "手動候補の無効化を完了できず、Application状態も確認できません。" & _
                   vbCrLf & "Excelイベントを開始時の値へ戻していません。" & _
                   vbCrLf & "現在のブックを上書きせず、Excelを再起動してください。" & _
                   vbCrLf & "Err " & CStr(errorNumber) & ": " & _
                   errorDescription, vbCritical
        End If
    ElseIf operationCommitted Then
        MsgBox "手動候補の無効化と分析結果は確定済みです。" & vbCrLf & _
               IIf(recoveryStateConfirmed, _
                   "後処理の失敗を要復旧状態として記録しました。", _
                   "後処理後の安全状態を確認できません。") & vbCrLf & _
               "現在のブックを上書きせず、Excelを再起動してください。" & _
               vbCrLf & "Err " & CStr(errorNumber) & ": " & _
               errorDescription, vbExclamation
    ElseIf Not mutationStarted Then
        MsgBox "手動候補の無効化処理は開始されず、保存内容は変更していません。" & _
               vbCrLf & "Err " & CStr(errorNumber) & ": " & _
               errorDescription, vbExclamation
    Else
        MsgBox "手動候補を無効にできませんでした。" & vbCrLf & _
               "Err " & CStr(errorNumber) & ": " & errorDescription, vbExclamation
    End If
    Err.Clear
    On Error GoTo 0
End Sub

Private Function EnsureManualFlowFailureOutputsDirty(ByRef detailText As String) As Boolean
    Dim errorNumber As Long, errorDescription As String

    On Error Resume Next
    Err.Clear
    MarkOutputsDirty
    errorNumber = Err.Number
    errorDescription = Err.Description
    Err.Clear
    On Error GoTo 0
    If errorNumber <> 0 Then
        detailText = detailText & " / 帳票要更新状態の記録エラー: Err " & _
                     CStr(errorNumber) & " " & errorDescription
        Exit Function
    End If
    EnsureManualFlowFailureOutputsDirty = True
End Function

Public Sub CaptureManualFlowStoreSnapshot(ByRef snapshot As Variant, ByRef snapshotLastRow As Long)
    Dim ws As Worksheet
    Set ws = GetSheet(SH_WORK_MANUAL_FLOW)
    EnsureManualFlowStoreSafeForSnapshot ws
    CaptureConstantDataStoreSnapshot ws, MANUAL_FLOW_STORE_LAST_COL, _
                                     snapshot, snapshotLastRow
End Sub

Public Sub RestoreManualFlowStoreSnapshot(ByRef snapshot As Variant, ByVal snapshotLastRow As Long)
    Dim ws As Worksheet
    Dim errorNumber As Long, errorDescription As String
    On Error GoTo EH
    Set ws = GetSheet(SH_WORK_MANUAL_FLOW)
    RestoreConstantDataStoreSnapshot ws, MANUAL_FLOW_STORE_LAST_COL, _
                                     snapshot, snapshotLastRow
    If Not ManualFlowStoreMatchesSnapshot(ws, snapshot, snapshotLastRow) Then _
        Err.Raise vbObjectError + 4967, "RestoreManualFlowStoreSnapshot", _
                  "手動候補の保存記録が退避時と一致しません。"
    EnsureManualFlowStoreSafeForSnapshot ws
    SetSheetVeryHiddenSafe ws
    If Not ManualFlowStoreIsVeryHidden(ws) Then _
        Err.Raise vbObjectError + 4971, "RestoreManualFlowStoreSnapshot", _
                  "手動資金候補を内部非表示へ戻せません。"
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    Err.Raise vbObjectError + 4966, "RestoreManualFlowStoreSnapshot", _
              "手動候補の操作を元に戻せませんでした: Err " & _
              CStr(errorNumber) & " " & errorDescription
End Sub

Private Function ManualFlowStoreIsVeryHidden(ByVal ws As Worksheet) As Boolean
    On Error GoTo EH
    If ws Is Nothing Then Exit Function
    ManualFlowStoreIsVeryHidden = (ws.Visible = xlSheetVeryHidden)
    Exit Function
EH:
    ManualFlowStoreIsVeryHidden = False
    Err.Clear
End Function

Private Sub AppendManualFlowFailureDetail( _
        ByRef detailText As String, ByVal addedText As String)
    If Len(Trim$(addedText)) = 0 Then Exit Sub
    If Len(detailText) > 0 Then detailText = detailText & " / "
    detailText = detailText & addedText
End Sub

Private Function IsManualFlowUpstreamRecoveryFatal( _
        ByVal errorNumber As Long, ByVal errorSource As String) As Boolean
    Dim sourcePrefix As String
    Select Case errorNumber
        Case vbObjectError + 3599
            IsManualFlowUpstreamRecoveryFatal = True
            Exit Function
        Case vbObjectError + 5191
            sourcePrefix = "AnalysisWorkspaceRecoveryFatal/"
        Case vbObjectError + 5192
            sourcePrefix = "SetupConvergeRecoveryFatal/"
        Case vbObjectError + 5194
            sourcePrefix = "CashAnalysisRecoveryFatal/"
        Case vbObjectError + 5195
            sourcePrefix = "TransactionAnalysisRecoveryFatal/"
        Case vbObjectError + 5196
            sourcePrefix = "CashManualSelectionRecoveryFatal/"
        Case vbObjectError + 5197
            sourcePrefix = "ClearRecoveryFatal/"
        Case MANUAL_FLOW_RECOVERY_FATAL_ERROR
            IsManualFlowUpstreamRecoveryFatal = True
            Exit Function
        Case Else
            Exit Function
    End Select
    IsManualFlowUpstreamRecoveryFatal = _
        (Len(errorSource) >= Len(sourcePrefix)) And _
        (StrComp(Left$(errorSource, Len(sourcePrefix)), _
                 sourcePrefix, vbBinaryCompare) = 0)
End Function

Private Function TryGetManualFlowEnableEvents( _
        ByRef currentValue As Boolean, _
        ByRef detailText As String) As Boolean
    Dim errorNumber As Long, errorDescription As String
    detailText = vbNullString
    On Error GoTo EH
    currentValue = Application.EnableEvents
    TryGetManualFlowEnableEvents = True
    Exit Function
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    detailText = "Err " & CStr(errorNumber) & ": " & errorDescription
    Err.Clear
End Function

Private Function TrySetManualFlowEnableEventsExact( _
        ByVal desiredValue As Boolean, _
        ByRef detailText As String) As Boolean
    Dim errorNumber As Long, errorDescription As String
    detailText = vbNullString
    On Error GoTo EH
    Application.EnableEvents = desiredValue
    If Application.EnableEvents <> desiredValue Then _
        Err.Raise vbObjectError + 5119, _
                  "TrySetManualFlowEnableEventsExact", _
                  "EnableEventsの書込み後読戻しが一致しません。"
    TrySetManualFlowEnableEventsExact = True
    Exit Function
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    detailText = "Err " & CStr(errorNumber) & ": " & errorDescription
    Err.Clear
End Function

Private Function TryStopManualFlowEventsForBookWrites( _
        ByRef detailText As String) As Boolean
    Dim firstDetail As String, retryDetail As String
    detailText = vbNullString
    If TrySetManualFlowEnableEventsExact(False, firstDetail) Then
        TryStopManualFlowEventsForBookWrites = True
        Exit Function
    End If
    If TrySetManualFlowEnableEventsExact(False, retryDetail) Then
        TryStopManualFlowEventsForBookWrites = True
        Exit Function
    End If
    detailText = "ExcelイベントをFalseへ停止して読戻し確認できませんでした。初回=" & _
                 firstDetail & " / 再試行=" & retryDetail
End Function

Private Function ManualFlowRecoveryStateIsConfirmedExact( _
        ByRef detailText As String) As Boolean
    Dim latchIsSet As Boolean, latchReadSucceeded As Boolean
    Dim healthValue As String, healthReadSucceeded As Boolean

    detailText = vbNullString
    latchReadSucceeded = TryGetRollbackRecoveryLatch(latchIsSet)
    If Not latchReadSucceeded Then
        AppendManualFlowFailureDetail detailText, _
            "独立復旧ラッチを一意に読み返せません。"
        Exit Function
    End If
    If Not latchIsSet Then
        AppendManualFlowFailureDetail detailText, _
            "独立復旧ラッチが設定されていません。"
        Exit Function
    End If
    healthReadSucceeded = _
        TryGetExactStateValue(STATE_DATA_HEALTH, healthValue)
    If Not healthReadSucceeded Then
        AppendManualFlowFailureDetail detailText, _
            "案件healthを一意に読み返せません。"
        Exit Function
    End If
    If StrComp(healthValue, DATA_HEALTH_NEEDS_RECOVERY, _
               vbBinaryCompare) <> 0 Then
        AppendManualFlowFailureDetail detailText, _
            "案件healthが要復旧ではありません（実値=" & _
            healthValue & "）。"
        Exit Function
    End If
    detailText = _
        "独立復旧ラッチと案件health=要復旧を一意に読み返しました。"
    ManualFlowRecoveryStateIsConfirmedExact = True
End Function

Private Sub RaiseManualFlowRecoveryFatal( _
        ByVal operationName As String, _
        ByVal originalErrorNumber As Long, _
        ByVal originalErrorSource As String, _
        ByVal originalErrorDescription As String, _
        ByVal recoveryDetail As String)
    Dim eventStateDetail As String, fatalDescription As String
    If Not TryStopManualFlowEventsForBookWrites(eventStateDetail) Then _
        AppendManualFlowFailureDetail recoveryDetail, _
            "Recovery終端のExcelイベントFalse収束に失敗しました: " & _
            eventStateDetail
    fatalDescription = "元エラー Err " & CStr(originalErrorNumber)
    If Len(originalErrorSource) > 0 Then _
        fatalDescription = fatalDescription & " / " & originalErrorSource
    If Len(originalErrorDescription) > 0 Then _
        fatalDescription = fatalDescription & ": " & originalErrorDescription
    If Len(recoveryDetail) > 0 Then _
        fatalDescription = fatalDescription & " / Recovery: " & recoveryDetail
    Err.Raise MANUAL_FLOW_RECOVERY_FATAL_ERROR, _
              MANUAL_FLOW_RECOVERY_FATAL_SOURCE & operationName, _
              fatalDescription
End Sub

Private Function TryConfirmManualFlowApplicationState( _
        ByRef detailText As String) As Boolean
    Dim stateProblems As String
    Dim errorNumber As Long, errorDescription As String
    detailText = vbNullString
    On Error GoTo EH
    If AppStateIsRestored(stateProblems) Then
        TryConfirmManualFlowApplicationState = True
    Else
        detailText = stateProblems
    End If
    Exit Function
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    detailText = "Application状態確認エラー: Err " & _
                 CStr(errorNumber) & " " & errorDescription
    Err.Clear
End Function

Private Sub EnforceManualFlowRecoveryStateTerminal( _
        ByVal operationName As String, _
        ByVal reasonText As String, _
        ByRef detailText As String, _
        ByRef recoveryEnforcementAttempted As Boolean, _
        ByRef recoveryEnforcementFailed As Boolean, _
        ByVal originalErrorNumber As Long, _
        ByVal originalErrorSource As String, _
        ByVal originalErrorDescription As String, _
        Optional ByRef applicationLeaseStarted As Boolean = False)
    Dim eventStateDetail As String, enforcementDetail As String
    Dim confirmationDetail As String, applicationStateDetail As String
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim eventsStopped As Boolean

    detailText = vbNullString
    If recoveryEnforcementAttempted Then
        recoveryEnforcementFailed = True
        eventsStopped = TryStopManualFlowEventsForBookWrites(eventStateDetail)
        If eventsStopped Then
            detailText = _
                "要復旧処理は既に試行済みのため再試行せず、ExcelイベントをFalseで停止しました。"
        Else
            detailText = _
                "要復旧処理の再試行を抑止しましたが、ExcelイベントFalse収束に失敗しました: " & _
                eventStateDetail
        End If
        RaiseManualFlowRecoveryFatal _
            operationName, originalErrorNumber, originalErrorSource, _
            originalErrorDescription, detailText
    End If
    If Not TryStopManualFlowEventsForBookWrites(eventStateDetail) Then
        detailText = _
            "Recovery書込み前にExcelイベント停止を確認できません: " & _
            eventStateDetail
        RaiseManualFlowRecoveryFatal _
            operationName, originalErrorNumber, originalErrorSource, _
            originalErrorDescription, detailText
    End If

    enforcementDetail = reasonText
    recoveryEnforcementAttempted = True
    On Error Resume Next
    Err.Clear
    EnforceRollbackRecoveryState enforcementDetail
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    Err.Clear
    eventsStopped = TryStopManualFlowEventsForBookWrites(eventStateDetail)
    On Error GoTo 0
    If errorNumber <> 0 Then
        recoveryEnforcementFailed = True
        AppendManualFlowFailureDetail detailText, _
            "要復旧処理エラー: Err " & CStr(errorNumber) & " " & _
            errorDescription
        If Len(errorSource) > 0 Then _
            AppendManualFlowFailureDetail detailText, _
                "要復旧処理エラー発生元: " & errorSource
        If Not eventsStopped Then _
            AppendManualFlowFailureDetail detailText, _
                "要復旧処理エラー後のExcelイベントFalse収束にも失敗しました: " & _
                eventStateDetail
        RaiseManualFlowRecoveryFatal _
            operationName, originalErrorNumber, originalErrorSource, _
            originalErrorDescription, detailText
    End If
    If Not eventsStopped Then
        recoveryEnforcementFailed = True
        AppendManualFlowFailureDetail detailText, _
            "要復旧処理後にExcelイベント停止を確認できません: " & _
            eventStateDetail
        RaiseManualFlowRecoveryFatal _
            operationName, originalErrorNumber, originalErrorSource, _
            originalErrorDescription, detailText
    End If
    If Not ManualFlowRecoveryStateIsConfirmedExact(confirmationDetail) Then
        recoveryEnforcementFailed = True
        AppendManualFlowFailureDetail detailText, confirmationDetail
        RaiseManualFlowRecoveryFatal _
            operationName, originalErrorNumber, originalErrorSource, _
            originalErrorDescription, detailText
    End If
    AppendManualFlowFailureDetail detailText, confirmationDetail
    If applicationLeaseStarted Then
        On Error Resume Next
        Err.Clear
        AppEnd
        errorNumber = Err.Number
        errorDescription = Err.Description
        Err.Clear
        On Error GoTo 0
        If errorNumber <> 0 Then
            recoveryEnforcementFailed = True
            AppendManualFlowFailureDetail detailText, _
                "Recovery確認後の所有Application lease終了エラー: Err " & _
                CStr(errorNumber) & " " & errorDescription
            RaiseManualFlowRecoveryFatal _
                operationName, originalErrorNumber, originalErrorSource, _
                originalErrorDescription, detailText
        End If
        applicationLeaseStarted = False
    End If
    If Not TryConfirmManualFlowApplicationState(applicationStateDetail) Then
        recoveryEnforcementFailed = True
        AppendManualFlowFailureDetail detailText, _
            "Recovery後のApplication状態を確認できません: " & _
            applicationStateDetail
        RaiseManualFlowRecoveryFatal _
            operationName, originalErrorNumber, originalErrorSource, _
            originalErrorDescription, detailText
    End If
    If Not TryStopManualFlowEventsForBookWrites(eventStateDetail) Then
        recoveryEnforcementFailed = True
        AppendManualFlowFailureDetail detailText, _
            "Recovery安全確認後の最終ExcelイベントFalseを確認できません: " & _
            eventStateDetail
        RaiseManualFlowRecoveryFatal _
            operationName, originalErrorNumber, originalErrorSource, _
            originalErrorDescription, detailText
    End If
    AppendManualFlowFailureDetail detailText, _
        "今回のRecovery二重状態、Application状態、最終イベントFalseを確認しました。"
    RaiseManualFlowRecoveryFatal _
        operationName, originalErrorNumber, originalErrorSource, _
        originalErrorDescription, detailText
End Sub

Private Function TryEndManualFlowAppLease( _
        ByRef applicationLeaseStarted As Boolean, _
        ByVal appBeginAttempted As Boolean, _
        ByRef detailText As String) As Boolean
    Dim errorNumber As Long, errorDescription As String
    Dim stateProblems As String
    detailText = vbNullString
    On Error GoTo EH
    If applicationLeaseStarted Then
        AppEnd
        applicationLeaseStarted = False
    End If
    If appBeginAttempted Then
        If Not AppStateIsRestored(stateProblems) Then
            detailText = _
                "Excel動作状態の全状態読戻しが一致しません: " & _
                stateProblems
            Exit Function
        End If
    End If
    TryEndManualFlowAppLease = True
    Exit Function
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    detailText = "Excel動作状態の復元エラー: Err " & _
                 CStr(errorNumber) & " " & errorDescription
    Err.Clear
End Function

Private Function TryForceRestoreManualFlowApplicationState( _
        ByRef applicationLeaseStarted As Boolean, _
        ByVal appBeginAttempted As Boolean, _
        ByRef detailText As String) As Boolean
    Dim forceErrorNumber As Long, forceErrorDescription As String
    Dim readbackErrorNumber As Long, readbackErrorDescription As String
    Dim stateProblems As String, stateReadSucceeded As Boolean

    detailText = vbNullString
    On Error Resume Next
    Err.Clear
    AppForceRestore
    forceErrorNumber = Err.Number
    forceErrorDescription = Err.Description
    Err.Clear
    stateReadSucceeded = AppStateIsRestored(stateProblems)
    readbackErrorNumber = Err.Number
    readbackErrorDescription = Err.Description
    Err.Clear
    On Error GoTo 0

    If forceErrorNumber = 0 And readbackErrorNumber = 0 And _
       stateReadSucceeded Then
        applicationLeaseStarted = False
        TryForceRestoreManualFlowApplicationState = True
        Exit Function
    End If
    If forceErrorNumber <> 0 Then _
        AppendManualFlowFailureDetail detailText, _
            "AppForceRestore: Err " & CStr(forceErrorNumber) & " " & _
            forceErrorDescription
    If readbackErrorNumber <> 0 Then
        AppendManualFlowFailureDetail detailText, _
            "AppStateIsRestored: Err " & CStr(readbackErrorNumber) & " " & _
            readbackErrorDescription
    ElseIf Not stateReadSucceeded Then
        AppendManualFlowFailureDetail detailText, _
            "Application全状態読戻し不成立: " & stateProblems
    End If
End Function

Private Function TryRestoreManualFlowEntryEvents( _
        ByVal entryValue As Boolean, _
        ByVal recoveryWritesAllowed As Boolean, _
        ByVal localStateSafe As Boolean, _
        ByVal recoveryReason As String, _
        ByRef recoveryStateConfirmed As Boolean, _
        ByRef recoveryEnforcementAttempted As Boolean, _
        ByRef recoveryEnforcementFailed As Boolean, _
        ByRef recoveryWasRequired As Boolean, _
        ByRef detailText As String) As Boolean
    Dim firstDetail As String, retryDetail As String
    Dim stopDetail As String, recoveryDetail As String
    Dim finalDetail As String, safeStopDetail As String
    Dim confirmationDetail As String

    detailText = vbNullString
    recoveryWasRequired = False

    'Recoveryを一度でも試行した経路は、外側の開始値にかかわらず
    'Falseへ収束して終端伝播し、通常のイベント復元へ戻さない。
    If recoveryEnforcementAttempted Then
        recoveryWasRequired = True
        If TryStopManualFlowEventsForBookWrites(stopDetail) Then
            detailText = _
                "Recovery試行後のため開始時イベント値へ戻さず、Falseで停止しました。"
        Else
            detailText = _
                "Recovery試行後のExcelイベントFalse収束に失敗しました: " & _
                stopDetail
        End If
        RaiseManualFlowRecoveryFatal _
            "TryRestoreManualFlowEntryEvents", 0, _
            "TryRestoreManualFlowEntryEvents", recoveryReason, detailText
    End If

    '外側がFalseを所有する呼出しは、False exactだけを読み戻して返す。
    If Not entryValue Then
        If TrySetManualFlowEnableEventsExact(False, firstDetail) Then
            TryRestoreManualFlowEntryEvents = True
            Exit Function
        End If
        If TrySetManualFlowEnableEventsExact(False, retryDetail) Then
            TryRestoreManualFlowEntryEvents = True
            Exit Function
        End If
        detailText = "Excelイベントを外側のFalseへ復元できません。初回=" & _
                     firstDetail & " / 再試行=" & retryDetail
        Exit Function
    End If

    If recoveryEnforcementFailed Then
        recoveryWasRequired = True
        If TryStopManualFlowEventsForBookWrites(stopDetail) Then
            detailText = _
                "要復旧処理自体が失敗したため、開始時イベント値へ戻さずFalseで停止しました。"
        Else
            detailText = _
                "要復旧処理エラー後にExcelイベントをFalseへ収束できず、状態は不明です: " & _
                stopDetail
        End If
        Exit Function
    End If

    '局所ロールバックが確実でない経路では、Trueを一度も書く前に
    'Enforce成功・二重Recovery・後続False exactをすべて確認する。
    If Not localStateSafe Then
        recoveryWasRequired = True
        If Not TryStopManualFlowEventsForBookWrites(stopDetail) Then
            detailText = _
                "開始時イベント復元の安全判定前にFalse exactを確認できません: " & _
                stopDetail
            Exit Function
        End If
        If recoveryWritesAllowed And Not recoveryStateConfirmed And _
           Not recoveryEnforcementAttempted Then
            EnforceManualFlowRecoveryStateTerminal _
                "TryRestoreManualFlowEntryEvents", recoveryReason, _
                recoveryDetail, recoveryEnforcementAttempted, _
                recoveryEnforcementFailed, 0, _
                "TryRestoreManualFlowEntryEvents", recoveryReason
        ElseIf Not recoveryWritesAllowed Then
            AppendManualFlowFailureDetail detailText, _
                "データ変更開始前の失敗なのでRecovery書込みは行いません。"
        End If
        If Not TryStopManualFlowEventsForBookWrites(stopDetail) Then
            AppendManualFlowFailureDetail detailText, _
                "Recovery判定後にExcelイベント停止を維持できません: " & _
                stopDetail
            Exit Function
        End If
        If recoveryEnforcementFailed Then
            AppendManualFlowFailureDetail detailText, _
                "要復旧処理自体が失敗したため、Recovery読戻しと開始時イベント復元を見送りました。"
            Exit Function
        End If
        If recoveryStateConfirmed Then
            recoveryStateConfirmed = _
                ManualFlowRecoveryStateIsConfirmedExact(confirmationDetail)
            AppendManualFlowFailureDetail detailText, confirmationDetail
        End If
        If Not recoveryStateConfirmed Then
            AppendManualFlowFailureDetail detailText, _
                "安全な局所ロールバックまたは二重Recoveryを確認できないため、ExcelイベントをFalseのまま維持しました。"
            Exit Function
        End If
    End If

    If TrySetManualFlowEnableEventsExact(entryValue, firstDetail) Then
        TryRestoreManualFlowEntryEvents = True
        Exit Function
    End If
    If TrySetManualFlowEnableEventsExact(entryValue, retryDetail) Then
        TryRestoreManualFlowEntryEvents = True
        Exit Function
    End If

    recoveryWasRequired = True
    detailText = "Excelイベントを開始値へ復元できません。初回=" & _
                 firstDetail & " / 再試行=" & retryDetail
    If Not TryStopManualFlowEventsForBookWrites(stopDetail) Then
        AppendManualFlowFailureDetail detailText, _
            "Recovery記録前のExcelイベント停止にも失敗しました: " & _
            stopDetail
        Exit Function
    End If

    '復元値の書込み失敗後もFalse exactに戻し、開始値を最後に一度だけ再試行する。
    If TrySetManualFlowEnableEventsExact(entryValue, finalDetail) Then
        TryRestoreManualFlowEntryEvents = True
        AppendManualFlowFailureDetail detailText, _
            "安全停止後の開始値復元再試行は成功しました。"
        Exit Function
    End If
    AppendManualFlowFailureDetail detailText, _
        "開始値の最終復元にも失敗しました: " & finalDetail
    If TryStopManualFlowEventsForBookWrites(safeStopDetail) Then
        AppendManualFlowFailureDetail detailText, _
            "安全停止のためExcelイベントをFalseへ収束させました。"
    Else
        AppendManualFlowFailureDetail detailText, _
            "Excelイベントの安全停止にも失敗し、状態は不明です: " & _
            safeStopDetail
    End If
End Function

Private Function ManualFlowStoreMatchesSnapshot(ByVal ws As Worksheet, ByRef snapshot As Variant, _
                                                ByVal snapshotLastRow As Long) As Boolean
    Dim currentLastRow As Long, rowCount As Long, target As Range
    If ws Is Nothing Then Exit Function
    currentLastRow = LastDataRowInColumns(ws, 1, MANUAL_FLOW_STORE_LAST_COL)
    If currentLastRow <> snapshotLastRow Then Exit Function
    If snapshotLastRow < 2 Then
        ManualFlowStoreMatchesSnapshot = True
        Exit Function
    End If
    If Not IsArray(snapshot) Then Exit Function
    rowCount = snapshotLastRow - 1
    Set target = ws.Range(ws.Cells(2, 1), _
                          ws.Cells(snapshotLastRow, MANUAL_FLOW_STORE_LAST_COL))
    ManualFlowStoreMatchesSnapshot = RangeValue2MatchesMatrixStrict( _
                                         target, snapshot, rowCount, _
                                         MANUAL_FLOW_STORE_LAST_COL)
End Function

Private Sub EnsureManualFlowStoreSafeForSnapshot(ByVal ws As Worksheet)
    Dim lastR As Long, target As Range
    If ws Is Nothing Then _
        Err.Raise vbObjectError + 5096, "EnsureManualFlowStoreSafeForSnapshot", _
                  "手動候補の保存先を取得できません。"
    lastR = LastDataRowInColumns(ws, 1, MANUAL_FLOW_STORE_LAST_COL)
    If lastR - 1 > MAX_INTERNAL_STORE_DATA_ROWS Then _
        Err.Raise vbObjectError + 5096, "EnsureManualFlowStoreSafeForSnapshot", _
                  "手動候補が保存上限を超えています。"
    If lastR < 2 Then Exit Sub
    Set target = ws.Range(ws.Cells(2, 1), _
                          ws.Cells(lastR, MANUAL_FLOW_STORE_LAST_COL))
    RequireAnalysisReviewConstantRange target, "手動資金候補の保存記録"
End Sub

Private Sub ValidateManualTransactionIDs(ByVal requestedIDs As String, ByRef txCount As Long, _
                                         ByRef totalWithdrawal As Double, _
                                         ByRef totalDeposit As Double, _
                                         ByRef suggestedAmount As Double, _
                                         ByRef canonicalIDs As String)
    Dim ws As Worksheet, data As Variant, lastR As Long, txIndex As Object
    Dim rows() As Long, rowList As String
    txCount = 0
    totalWithdrawal = 0
    totalDeposit = 0
    suggestedAmount = 0
    canonicalIDs = vbNullString
    Set ws = GetSheet(SH_WORK_TX)
    lastR = LastUsedRowInSheet(ws)
    If lastR < 2 Then Err.Raise vbObjectError + 4955, , "取引が登録されていません。"
    data = ws.Range(ws.Cells(2, 1), ws.Cells(lastR, WORK_TX_COL_PERSON_ID)).Value2
    Set txIndex = BuildManualTransactionIndex(data, UBound(data, 1))
    ManualRowsForIDs requestedIDs, txIndex, data, rows, txCount, rowList, canonicalIDs
    ManualTotals data, rows, txCount, totalWithdrawal, totalDeposit
    If totalWithdrawal <= 0 Or totalDeposit <= 0 Then _
        Err.Raise vbObjectError + 4956, , _
                  "手動の資金移動候補には、出金と入金をそれぞれ1件以上選択してください。"
    If totalWithdrawal < totalDeposit Then suggestedAmount = totalWithdrawal Else suggestedAmount = totalDeposit
End Sub

'Excelシートを書き換えず、入力IDと正規化後IDが混線しないことを検証する。

Private Function BuildManualTransactionIndex(ByRef sourceData As Variant, _
                                             ByVal sourceRowCount As Long) As Object
    Dim result As Object, r As Long, txID As String
    Set result = CreateObject("Scripting.Dictionary")
    result.CompareMode = vbTextCompare
    For r = 1 To sourceRowCount
        If CellText(sourceData(r, WORK_TX_COL_RECORD_TYPE)) = RECORD_TRANSACTION Then
            txID = CellText(sourceData(r, WORK_TX_COL_TRANSACTION_ID))
            If Len(txID) > 0 Then
                If result.Exists(txID) Then Err.Raise vbObjectError + 4957, , _
                    "取引IDが重複しています: " & txID
                result.Add txID, r
            End If
        End If
    Next r
    Set BuildManualTransactionIndex = result
End Function

Private Sub ManualRowsForIDs(ByVal txIDs As String, ByVal txIndex As Object, _
                             ByRef sourceData As Variant, ByRef rows() As Long, _
                             ByRef rowCount As Long, ByRef rowList As String, _
                             ByRef canonicalIDs As String)
    Dim parts As Variant, item As Variant, wanted As Object, txID As String
    Dim dayHasMissing As Object, i As Long, sourceRow As Long, dateKey As String
    rowCount = 0
    rowList = vbNullString
    canonicalIDs = vbNullString
    Set wanted = CreateObject("Scripting.Dictionary")
    Set dayHasMissing = CreateObject("Scripting.Dictionary")
    wanted.CompareMode = vbTextCompare
    dayHasMissing.CompareMode = vbTextCompare
    parts = Split(txIDs, ";")
    For Each item In parts
        txID = Trim$(CStr(item))
        If Len(txID) > 0 Then wanted(txID) = True
    Next item
    If wanted.Count < 2 Then Err.Raise vbObjectError + 4958, , "構成取引IDが2件未満です。"
    ReDim rows(1 To wanted.Count)
    For Each item In wanted.Keys
        txID = CStr(item)
        If Not txIndex.Exists(txID) Then _
            Err.Raise vbObjectError + 4959, , "構成取引が見つかりません: " & txID
        rowCount = rowCount + 1
        sourceRow = CLng(txIndex(txID))
        rows(rowCount) = sourceRow
        dateKey = Format$(CDate(sourceData(sourceRow, OUT_COL_DATE)), "yyyymmdd")
        If Not HasText(sourceData(sourceRow, OUT_COL_TIME)) Then dayHasMissing(dateKey) = True
    Next item
    If rowCount > 1 Then QuickSortManualRows sourceData, rows, 1, rowCount, dayHasMissing
    For i = 1 To rowCount
        If Len(rowList) > 0 Then rowList = rowList & ";": canonicalIDs = canonicalIDs & ";"
        rowList = rowList & CStr(rows(i))
        canonicalIDs = canonicalIDs & CellText(sourceData(rows(i), WORK_TX_COL_TRANSACTION_ID))
    Next i
End Sub

Private Sub QuickSortManualRows(ByRef data As Variant, ByRef rows() As Long, _
                                ByVal firstIndex As Long, ByVal lastIndex As Long, _
                                ByVal dayHasMissing As Object)
    Dim low As Long, high As Long, pivotRow As Long, tempRow As Long
    low = firstIndex: high = lastIndex: pivotRow = rows((firstIndex + lastIndex) \ 2)
    Do While low <= high
        Do While CompareManualRows(data, rows(low), pivotRow, dayHasMissing) < 0
            low = low + 1
        Loop
        Do While CompareManualRows(data, rows(high), pivotRow, dayHasMissing) > 0
            high = high - 1
        Loop
        If low <= high Then
            tempRow = rows(low): rows(low) = rows(high): rows(high) = tempRow
            low = low + 1: high = high - 1
        End If
    Loop
    If firstIndex < high Then QuickSortManualRows data, rows, firstIndex, high, dayHasMissing
    If low < lastIndex Then QuickSortManualRows data, rows, low, lastIndex, dayHasMissing
End Sub

Private Function CompareManualRows(ByRef data As Variant, ByVal firstRow As Long, _
                                   ByVal secondRow As Long, ByVal dayHasMissing As Object) As Long
    Dim firstDate As Long, secondDate As Long, dateKey As String
    Dim firstOrder As Double, secondOrder As Double, firstTime As Double, secondTime As Double
    firstDate = CLng(VBA.DateValue(CDate(data(firstRow, OUT_COL_DATE))))
    secondDate = CLng(VBA.DateValue(CDate(data(secondRow, OUT_COL_DATE))))
    If firstDate < secondDate Then CompareManualRows = -1: Exit Function
    If firstDate > secondDate Then CompareManualRows = 1: Exit Function
    dateKey = Format$(CDate(firstDate), "yyyymmdd")
    '時刻欠落日の入力順・行順は、保存キーを安定させるためだけに使う。
    'WriteManualFlowOutputRowでは同日内順序不明と明示し、時間的順序の根拠にはしない。
    firstOrder = ManualNumber(data(firstRow, WORK_TX_COL_INPUT_ORDER))
    secondOrder = ManualNumber(data(secondRow, WORK_TX_COL_INPUT_ORDER))
    If Not dayHasMissing.Exists(dateKey) Then
        firstTime = ManualTimeNumber(data(firstRow, OUT_COL_TIME))
        secondTime = ManualTimeNumber(data(secondRow, OUT_COL_TIME))
        If firstTime < secondTime Then CompareManualRows = -1: Exit Function
        If firstTime > secondTime Then CompareManualRows = 1: Exit Function
    End If
    If firstOrder < secondOrder Then
        CompareManualRows = -1
    ElseIf firstOrder > secondOrder Then
        CompareManualRows = 1
    ElseIf firstRow < secondRow Then
        CompareManualRows = -1
    ElseIf firstRow > secondRow Then
        CompareManualRows = 1
    End If
End Function

Private Sub ManualTotals(ByRef data As Variant, ByRef rows() As Long, ByVal rowCount As Long, _
                         ByRef totalWithdrawal As Double, ByRef totalDeposit As Double)
    Dim i As Long
    For i = 1 To rowCount
        totalWithdrawal = totalWithdrawal + ManualNumber(data(rows(i), OUT_COL_WITHDRAW))
        totalDeposit = totalDeposit + ManualNumber(data(rows(i), OUT_COL_DEPOSIT))
    Next i
End Sub

Private Sub UpdateManualCandidateStatistics(ByVal txIDs As String, ByVal candidateCounts As Object, _
                                            ByVal bestScores As Object, ByVal bestRatings As Object, _
                                            ByVal manualScore As Long)
    Dim parts As Variant, item As Variant, txID As String
    parts = Split(txIDs, ";")
    For Each item In parts
        txID = Trim$(CStr(item))
        If Len(txID) > 0 Then
            If candidateCounts.Exists(txID) Then candidateCounts(txID) = CLng(candidateCounts(txID)) + 1 Else candidateCounts.Add txID, 1
            If Not bestScores.Exists(txID) Then
                bestScores.Add txID, manualScore: bestRatings.Add txID, "手動・未検証"
            ElseIf CLng(bestScores(txID)) < manualScore Then
                bestScores(txID) = manualScore: bestRatings(txID) = "手動・未検証"
            End If
        End If
    Next item
End Sub

Private Function ManualHasSameDayUnknownOrder(ByRef data As Variant, _
                                              ByRef rows() As Long, _
                                              ByVal rowCount As Long) As Boolean
    Dim dayCounts As Object, daysWithMissingTime As Object
    Dim i As Long, rowNo As Long, dateKey As String, item As Variant
    Set dayCounts = CreateObject("Scripting.Dictionary")
    Set daysWithMissingTime = CreateObject("Scripting.Dictionary")
    dayCounts.CompareMode = vbBinaryCompare
    daysWithMissingTime.CompareMode = vbBinaryCompare
    For i = 1 To rowCount
        rowNo = rows(i)
        dateKey = Format$(CDate(data(rowNo, OUT_COL_DATE)), "yyyymmdd")
        If dayCounts.Exists(dateKey) Then
            dayCounts(dateKey) = CLng(dayCounts(dateKey)) + 1
        Else
            dayCounts.Add dateKey, 1
        End If
        If Not HasText(data(rowNo, OUT_COL_TIME)) Then _
            daysWithMissingTime(dateKey) = True
    Next i
    For Each item In dayCounts.Keys
        dateKey = CStr(item)
        If CLng(dayCounts(dateKey)) >= 2 And _
           daysWithMissingTime.Exists(dateKey) Then
            ManualHasSameDayUnknownOrder = True
            Exit Function
        End If
    Next item
End Function

Private Function ManualTimeCoverageText(ByVal hasAnyTime As Boolean, _
                                        ByVal hasAllTimes As Boolean) As String
    If hasAllTimes Then
        ManualTimeCoverageText = "全件時刻あり"
    ElseIf hasAnyTime Then
        ManualTimeCoverageText = "一部時刻記載なし"
    Else
        ManualTimeCoverageText = "時刻記載なし"
    End If
End Function

Private Function ManualTimeEvidenceNotice(ByVal hasMissingTime As Boolean, _
                                          ByVal hasSameDayUnknownOrder As Boolean) As String
    If hasSameDayUnknownOrder Then
        ManualTimeEvidenceNotice = _
            "同日の構成取引に時刻記載なしがあるため、" & _
            "同日内順序不明です。出金・入金は構成上の役割を示し、" & _
            "時間的順序の根拠ではありません。"
    ElseIf hasMissingTime Then
        ManualTimeEvidenceNotice = _
            "時刻記載なしを含みます。時刻がない取引について、" & _
            "行順や入力順を時間的順序の根拠とはしていません。"
    End If
End Function

Private Function ManualPeriodText(ByRef data As Variant, _
                                  ByVal firstRow As Long, ByVal lastRow As Long, _
                                  ByVal hasAllTimes As Boolean, _
                                  ByVal hasSameDayUnknownOrder As Boolean) As String
    If hasAllTimes Then
        ManualPeriodText = ManualDateTimeText(data, firstRow) & " ～ " & _
                           ManualDateTimeText(data, lastRow)
        Exit Function
    End If
    ManualPeriodText = Format$(CDate(data(firstRow, OUT_COL_DATE)), "yyyy/m/d")
    If CLng(VBA.DateValue(CDate(data(firstRow, OUT_COL_DATE)))) <> _
       CLng(VBA.DateValue(CDate(data(lastRow, OUT_COL_DATE)))) Then _
        ManualPeriodText = ManualPeriodText & " ～ " & _
                           Format$(CDate(data(lastRow, OUT_COL_DATE)), "yyyy/m/d")
    ManualPeriodText = ManualPeriodText & "（時刻記載なしを含む"
    If hasSameDayUnknownOrder Then _
        ManualPeriodText = ManualPeriodText & "・同日内順序不明"
    ManualPeriodText = ManualPeriodText & "）"
End Function

Private Function ManualDateTimeText(ByRef data As Variant, ByVal rowNo As Long) As String
    ManualDateTimeText = Format$(CDate(data(rowNo, OUT_COL_DATE)), "yyyy/m/d") & " "
    If HasText(data(rowNo, OUT_COL_TIME)) Then
        ManualDateTimeText = ManualDateTimeText & Format$(VBA.TimeValue(CDate(data(rowNo, OUT_COL_TIME))), "hh:mm")
    Else
        ManualDateTimeText = ManualDateTimeText & "時刻記載なし"
    End If
End Function

Private Function ManualTransactionText(ByRef data As Variant, ByVal rowNo As Long, _
                                       ByVal directionText As String, ByVal amountValue As Double) As String
    ManualTransactionText = ManualDateTimeText(data, rowNo) & " " & directionText & " " & _
                            Format$(amountValue, "#,##0.########") & " " & ManualAccountText(data, rowNo)
End Function

Private Function ManualAccountText(ByRef data As Variant, ByVal rowNo As Long) As String
    ManualAccountText = CellText(data(rowNo, OUT_COL_BANK)) & " " & _
                        CellText(data(rowNo, OUT_COL_BRANCH)) & " " & _
                        CellText(data(rowNo, OUT_COL_ACCOUNT_TYPE)) & " " & _
                        CellText(data(rowNo, OUT_COL_ACCOUNT_NO))
    ManualAccountText = Trim$(ManualAccountText)
End Function

Private Function ManualNumber(ByVal valueIn As Variant) As Double
    'IsNumeric=Trueでも、桁外れの文字列や特殊なVariantをCDblすると
    'オーバーフローする。分析全体を停止させず、入力検証側で不正値として扱う。
    On Error GoTo InvalidValue
    If IsObject(valueIn) Then Exit Function
    If IsError(valueIn) Then Exit Function
    If IsNull(valueIn) Then Exit Function
    If IsEmpty(valueIn) Then Exit Function
    If VarType(valueIn) = vbBoolean Then Exit Function
    If IsNumeric(valueIn) Then ManualNumber = CDbl(valueIn)
    Exit Function
InvalidValue:
    ManualNumber = 0
    Err.Clear
End Function

Private Function ManualTimeNumber(ByVal valueIn As Variant) As Double
    If HasText(valueIn) Then ManualTimeNumber = CDbl(VBA.TimeValue(CDate(valueIn)))
End Function

Private Function JoinManualDictionaryKeys(ByVal values As Object) As String
    Dim item As Variant
    For Each item In values.Keys
        If Len(JoinManualDictionaryKeys) > 0 Then JoinManualDictionaryKeys = JoinManualDictionaryKeys & ";"
        JoinManualDictionaryKeys = JoinManualDictionaryKeys & CStr(item)
    Next item
End Function

Private Function ManualIDSetSignature(ByVal txIDs As String) As String
    Dim parts As Variant, values() As String, item As Variant
    Dim seen As Object, count As Long, i As Long, j As Long, temp As String
    Set seen = CreateObject("Scripting.Dictionary")
    seen.CompareMode = vbTextCompare
    parts = Split(txIDs, ";")
    For Each item In parts
        temp = Trim$(CStr(item))
        If Len(temp) > 0 Then seen(temp) = True
    Next item
    If seen.Count = 0 Then Exit Function
    ReDim values(1 To seen.Count)
    For Each item In seen.Keys
        count = count + 1
        values(count) = UCase$(CStr(item))
    Next item
    For i = 2 To count
        temp = values(i): j = i - 1
        Do While j >= 1
            If StrComp(values(j), temp, vbBinaryCompare) <= 0 Then Exit Do
            values(j + 1) = values(j): j = j - 1
        Loop
        values(j + 1) = temp
    Next i
    For i = 1 To count
        If Len(ManualIDSetSignature) > 0 Then ManualIDSetSignature = ManualIDSetSignature & ";"
        ManualIDSetSignature = ManualIDSetSignature & values(i)
    Next i
End Function

Private Function ManualFlowUserName() As String
    On Error Resume Next
    ManualFlowUserName = Trim$(Application.UserName)
    If Len(ManualFlowUserName) = 0 Then ManualFlowUserName = Trim$(Environ$("Username"))
    If Len(ManualFlowUserName) = 0 Then ManualFlowUserName = "登録者未設定"
    On Error GoTo 0
End Function

Private Function ManualFlowReviewStatus(ByVal statusText As String) As Boolean
    Select Case Trim$(statusText)
        Case ANALYSIS_STATUS_UNREVIEWED, ANALYSIS_STATUS_SHIFT_CONFIRMED, _
             ANALYSIS_STATUS_EXCLUDED, ANALYSIS_STATUS_FOLLOWUP
            ManualFlowReviewStatus = True
    End Select
End Function


Private Function ManualEvidenceDigestIsValid(ByVal digestText As String) As Boolean
    Dim i As Long, characterText As String
    If Len(digestText) <> 17 Or Mid$(digestText, 9, 1) <> "-" Then Exit Function
    For i = 1 To Len(digestText)
        If i <> 9 Then
            characterText = UCase$(Mid$(digestText, i, 1))
            If InStr(1, "0123456789ABCDEF", characterText, vbBinaryCompare) = 0 Then Exit Function
        End If
    Next i
    ManualEvidenceDigestIsValid = True
End Function

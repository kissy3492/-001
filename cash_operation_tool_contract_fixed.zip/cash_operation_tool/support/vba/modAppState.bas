﻿Attribute VB_Name = "modAppState"
Option Explicit

Private mStateActive As Boolean
Private mStateDepth As Long
Private mPrevEvents As Boolean
Private mPrevScreenUpdating As Boolean
Private mPrevDisplayAlerts As Boolean
Private mPrevCalculation As XlCalculation
Private mPrevStatusBar As Variant
Private mPrevEnableCancelKey As XlEnableCancelKey
Private mPrevInteractive As Boolean
Private mLastRestoreFailure As String
Private mStatusTextByDepth() As String


Public Sub AppBegin(Optional ByVal statusText As String = "処理中...")
    Dim errorNumber As Long, errorDescription As String
    Dim createdSnapshot As Boolean, enteredScope As Boolean
    On Error GoTo EH

    If mStateDepth = 0 And mStateActive Then AppEnd
    If mStateDepth > 0 And Not mStateActive Then _
        Err.Raise vbObjectError + 1824, "AppBegin", _
                  "Excelの処理状態を取得できません。"

    If mStateDepth = 0 Then
        '外側の処理だけが開始値を保存する。全項目を取得するまでは設定を変更しない。
        mPrevEvents = Application.EnableEvents
        mPrevScreenUpdating = Application.ScreenUpdating
        mPrevDisplayAlerts = Application.DisplayAlerts
        mPrevCalculation = Application.Calculation
        mPrevStatusBar = Application.StatusBar
        mPrevEnableCancelKey = Application.EnableCancelKey
        mPrevInteractive = Application.Interactive
        mStateActive = True
        createdSnapshot = True
    End If

    '配列確保に失敗しても、呼出元の処理階層を減らさない。
    If mStateDepth = 0 Then
        ReDim mStatusTextByDepth(1 To 1)
    Else
        ReDim Preserve mStatusTextByDepth(1 To mStateDepth + 1)
    End If
    mStateDepth = mStateDepth + 1
    enteredScope = True
    mStatusTextByDepth(mStateDepth) = statusText

    Application.EnableEvents = False
    Application.ScreenUpdating = False
    Application.DisplayAlerts = False
    Application.Calculation = xlCalculationManual
    Application.Interactive = False
    Application.EnableCancelKey = xlErrorHandler
    If Application.EnableEvents Or Application.DisplayAlerts Or _
       Application.Calculation <> xlCalculationManual Or Application.Interactive Then _
        Err.Raise vbObjectError + 1821, "AppBegin", _
                  "Excelを処理中の状態へ切り替えられませんでした。"
    On Error Resume Next
    Application.StatusBar = statusText
    On Error GoTo 0
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    On Error Resume Next
    'この呼出しが取得した状態だけを戻す。取得前のエラーで外側の状態を解放しない。
    If enteredScope Or createdSnapshot Then AppEnd
    If mStateActive And Len(mLastRestoreFailure) > 0 Then _
        errorDescription = errorDescription & " / 復元できない項目: " & mLastRestoreFailure
    On Error GoTo 0
    Err.Raise errorNumber, "AppBegin", errorDescription
End Sub
Public Sub AppEnd()
    Dim failureText As String, eventStopDetail As String
    Dim eventsStopped As Boolean
    If mStateDepth > 1 Then
        mStateDepth = mStateDepth - 1
        On Error Resume Next
        Application.StatusBar = mStatusTextByDepth(mStateDepth)
        mStatusTextByDepth(mStateDepth + 1) = vbNullString
        On Error GoTo 0
        Exit Sub
    End If
    mStateDepth = 0
    Erase mStatusTextByDepth
    If Not mStateActive Then Exit Sub
    mLastRestoreFailure = vbNullString

    '再計算中のイベントを止め、計算を戻してから表示・操作受付を戻す。
    eventsStopped = TryHoldApplicationEventsStopped(eventStopDetail)
    If eventsStopped Then
        RestoreApplicationProperty "Calculation", "計算方法", mPrevCalculation, failureText
    Else
        AppendForceRestoreDetail failureText, "イベント停止", eventStopDetail
    End If
    RestoreApplicationProperty "DisplayAlerts", "警告表示", mPrevDisplayAlerts, failureText
    RestoreApplicationProperty "Interactive", "操作受付", mPrevInteractive, failureText

    '画面表示・中断キー・ステータスはExcel自身も更新するため、
    '代入成功後の値の厳密一致を処理成功の条件にしない。
    RestoreApplicationProperty "EnableCancelKey", "中断設定", mPrevEnableCancelKey, failureText, False
    RestoreApplicationProperty "ScreenUpdating", "画面更新", mPrevScreenUpdating, failureText, False
    RestoreApplicationProperty "StatusBar", "状態表示", mPrevStatusBar, failureText, False

    If Len(failureText) = 0 Then _
        RestoreApplicationProperty "EnableEvents", "イベント", mPrevEvents, failureText
    If Len(failureText) = 0 Then
        mStateActive = False
        mLastRestoreFailure = vbNullString
        Exit Sub
    End If

    '実際に設定を戻せない場合だけ退避値を保持して、次の操作を止める。
    eventStopDetail = vbNullString
    If Not TryHoldApplicationEventsStopped(eventStopDetail) Then _
        AppendForceRestoreDetail failureText, "イベント停止", eventStopDetail
    mLastRestoreFailure = failureText
    Err.Raise vbObjectError + 1822, "AppEnd", _
              "Excelの操作設定を戻せませんでした。" & vbCrLf & failureText
End Sub

Private Function TryHoldApplicationEventsStopped(ByRef detailText As String) As Boolean
    detailText = vbNullString
    RestoreApplicationProperty "EnableEvents", "イベント", False, detailText
    TryHoldApplicationEventsStopped = (Len(detailText) = 0)
End Function


Public Sub AppForceRestore(Optional ByVal forceSafeDefaults As Boolean = False)
    '捕捉済みの開始値だけを戻す。利用者の計算方法等を既定値へ変更しない。
    If mStateActive Then
        mStateDepth = 0
        AppEnd
    ElseIf mStateDepth <> 0 Then
        Err.Raise vbObjectError + 1826, "AppForceRestore", _
                  "Excelの処理状態の退避値がありません。"
    End If
End Sub
Public Sub AppForceRestoreForRecoveryTerminal()
    'Recovery終端では、入れ子を含む捕捉済みApplication leaseを全て閉じる。
    'ただし通常のAppForceRestoreで開始時EnableEvents=Trueへ一瞬戻すと、
    'callerがFalseへ再収束する前にWorkbook/Calculate等が再入し得る。
    '捕捉値を一時的にFalseへ差し替え、復元中もイベントを停止したままにする。
    Dim stateWasActive As Boolean, capturedEvents As Boolean
    Dim errorNumber As Long, errorSource As String
    Dim errorDescription As String

    stateWasActive = mStateActive
    If stateWasActive Then
        capturedEvents = mPrevEvents
        mPrevEvents = False
    End If

    On Error GoTo EH
    AppForceRestore
    If stateWasActive Then mPrevEvents = capturedEvents
    Exit Sub
EH:
    errorNumber = Err.Number
    errorSource = Err.Source
    errorDescription = Err.Description
    Err.Clear
    '失敗時は後続の明示的な復元再試行に備えて、本来の捕捉値を失わない。
    'Application.EnableEvents自体はFalseのままで、callerが直後に再確認する。
    If stateWasActive Then mPrevEvents = capturedEvents
    Err.Raise errorNumber, _
              "AppForceRestoreForRecoveryTerminal/" & errorSource, _
              errorDescription
End Sub


Private Sub AppendForceRestoreDetail(ByRef failureText As String, _
                                     ByVal stepName As String, ByVal detailText As String)
    If Len(failureText) > 0 Then failureText = failureText & " / "
    failureText = failureText & stepName
    If Len(detailText) > 0 Then failureText = failureText & ": " & detailText
End Sub

Public Function AppStateIsRestored(ByRef problemText As String) As Boolean
    problemText = vbNullString
    If mStateActive Then problemText = "Excelの操作設定が復元待ちです。"
    If mStateDepth <> 0 Then
        If Len(problemText) > 0 Then problemText = problemText & " / "
        problemText = problemText & "処理状態の深さ=" & CStr(mStateDepth)
    End If
    If Len(mLastRestoreFailure) > 0 Then
        If Len(problemText) > 0 Then problemText = problemText & " / "
        problemText = problemText & mLastRestoreFailure
    End If
    AppStateIsRestored = (Len(problemText) = 0)
End Function
Public Sub AppProgress(ByVal statusText As String, Optional ByVal currentValue As Long = 0, _
                       Optional ByVal totalValue As Long = 0)
    Dim displayText As String
    displayText = statusText
    If totalValue > 0 Then
        displayText = displayText & "  " & Format$(currentValue, "#,##0") & " / " & _
                      Format$(totalValue, "#,##0")
    End If
    On Error Resume Next
    Application.StatusBar = displayText
    On Error GoTo 0
    DoEvents
End Sub
Public Function IsUserCancelError(ByVal errorNumber As Long) As Boolean
    IsUserCancelError = (errorNumber = 18)
End Function


Private Sub RestoreApplicationProperty(ByVal propertyName As String, _
                                       ByVal displayName As String, _
                                       ByVal expectedValue As Variant, _
                                       ByRef failureText As String, _
                                       Optional ByVal verifyValue As Boolean = True)
    Dim actualValue As Variant
    Dim setterError As Long, getterError As Long
    Dim setterDescription As String, getterDescription As String
    Dim detailText As String

    On Error Resume Next
    Err.Clear
    actualValue = CallByName(Application, propertyName, VbGet)
    getterError = Err.Number
    Err.Clear
    On Error GoTo 0
    If getterError = 0 Then
        If ApplicationPropertyValuesMatch(expectedValue, actualValue) Then Exit Sub
    End If

    On Error Resume Next
    Err.Clear
    CallByName Application, propertyName, VbLet, expectedValue
    setterError = Err.Number
    setterDescription = Err.Description
    Err.Clear
    On Error GoTo 0
    If setterError = 0 And Not verifyValue Then Exit Sub

    On Error Resume Next
    Err.Clear
    actualValue = CallByName(Application, propertyName, VbGet)
    getterError = Err.Number
    getterDescription = Err.Description
    Err.Clear
    On Error GoTo 0
    '設定が既に戻っているなら、代入時の一時エラーだけでは停止しない。
    If getterError = 0 Then
        If ApplicationPropertyValuesMatch(expectedValue, actualValue) Then Exit Sub
    End If

    detailText = "戻す値=" & ApplicationPropertyValueText(expectedValue)
    If getterError = 0 Then
        detailText = detailText & "、現在値=" & ApplicationPropertyValueText(actualValue)
    Else
        detailText = detailText & "、取得エラー " & CStr(getterError) & ": " & getterDescription
    End If
    If setterError <> 0 Then _
        detailText = detailText & "、設定エラー " & CStr(setterError) & ": " & setterDescription
    AppendForceRestoreDetail failureText, displayName, detailText
End Sub

Private Function ApplicationPropertyValuesMatch(ByVal expectedValue As Variant, _
                                                ByVal actualValue As Variant) As Boolean
    If IsError(expectedValue) Or IsError(actualValue) Then Exit Function
    If IsNull(expectedValue) Or IsNull(actualValue) Then Exit Function
    On Error GoTo NoMatch
    If VarType(expectedValue) = vbString Or VarType(actualValue) = vbString Then
        If VarType(expectedValue) <> VarType(actualValue) Then Exit Function
        ApplicationPropertyValuesMatch = _
            (StrComp(CStr(expectedValue), CStr(actualValue), vbBinaryCompare) = 0)
    Else
        ApplicationPropertyValuesMatch = (expectedValue = actualValue)
    End If
    Exit Function
NoMatch:
    ApplicationPropertyValuesMatch = False
End Function

Private Function ApplicationPropertyValueText(ByVal value As Variant) As String
    On Error GoTo Unavailable
    If IsError(value) Or IsNull(value) Then GoTo Unavailable
    ApplicationPropertyValueText = CStr(value)
    Exit Function
Unavailable:
    ApplicationPropertyValueText = "取得不能"
End Function

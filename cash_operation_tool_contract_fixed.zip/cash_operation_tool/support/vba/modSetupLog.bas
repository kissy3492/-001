﻿Attribute VB_Name = "modSetupLog"
Option Explicit

Public Sub ResetSetupLog()
    Dim ws As Worksheet
    On Error GoTo EH
    Set ws = GetOrCreateSheet(SH_SETUP_LOG, True)
    If ws Is Nothing Then Err.Raise vbObjectError + 1701, "ResetSetupLog", "セットアップログを作成できません。"
    EnsureSetupLogHeader ws
    Exit Sub
EH:
    Err.Raise Err.Number, "ResetSetupLog", Err.Description
End Sub

Public Sub LogStep(ByVal categoryText As String, ByVal stepText As String, Optional ByVal stateText As String = "", Optional ByVal detailText As String = "")
    Dim ws As Worksheet
    Dim r As Long
    On Error Resume Next
    Set ws = GetOrCreateSheet(SH_SETUP_LOG, False)
    If ws Is Nothing Then Exit Sub
    'ResetSetupLogより前の工程で失敗しても、見出しのない診断ログを残さない。
    If CellText(ws.Cells(1, 1).Value2) <> "時刻" Or _
       CellText(ws.Cells(1, 2).Value2) <> "区分" Or _
       CellText(ws.Cells(1, 3).Value2) <> "工程" Or _
       CellText(ws.Cells(1, 4).Value2) <> "状態" Or _
       CellText(ws.Cells(1, 5).Value2) <> "詳細" Then EnsureSetupLogHeader ws
    r = ws.Cells(ws.Rows.Count, 1).End(xlUp).Row + 1
    If r < 2 Then r = 2
    ws.Cells(r, 1).Value = Now
    ws.Cells(r, 2).Value = categoryText
    ws.Cells(r, 3).Value = stepText
    ws.Cells(r, 4).Value = stateText
    ws.Cells(r, 5).Value = detailText
    ws.Rows(r).VerticalAlignment = xlTop
    ws.Cells(r, 5).WrapText = True
    On Error GoTo 0
End Sub


Private Sub EnsureSetupLogHeader(ByVal ws As Worksheet)
    If ws Is Nothing Then Exit Sub
    With ws
        If CellText(.Cells(1, 1).Value2) <> "時刻" Or _
           CellText(.Cells(1, 2).Value2) <> "区分" Or _
           CellText(.Cells(1, 3).Value2) <> "工程" Or _
           CellText(.Cells(1, 4).Value2) <> "状態" Or _
           CellText(.Cells(1, 5).Value2) <> "詳細" Then _
            SetRowValues .Range("A1"), Array("時刻", "区分", "工程", "状態", "詳細")
        .Range("A1:E1").Font.Bold = True
        .Range("A1:E1").Interior.Color = RGB(68, 114, 196)
        .Range("A1:E1").Font.Color = vbWhite
        .Columns("A:A").ColumnWidth = 20
        .Columns("B:B").ColumnWidth = 12
        .Columns("C:C").ColumnWidth = 26
        .Columns("D:D").ColumnWidth = 16
        .Columns("E:E").ColumnWidth = 80
        .Columns("B:E").NumberFormatLocal = "@"
        .Columns("A:A").NumberFormatLocal = "yyyy/m/d h:mm:ss"
        .Columns("E:E").WrapText = True
        .Rows(1).RowHeight = 24
    End With
End Sub

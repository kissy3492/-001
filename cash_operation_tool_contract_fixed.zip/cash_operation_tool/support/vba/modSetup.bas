﻿Attribute VB_Name = "modSetup"
Option Explicit

Private Const MAX_DATA_PROBLEM_DETAIL_CHARS As Long = 750000
Private Const MAX_CANDIDATE_DATA_ROWS As Long = 100000
Private Const VALIDATION_CHECK_CHUNK_ROWS As Long = 500
Private Const VALIDATION_CHECK_DIRECT_ROWS As Long = 64
Private Const CONFIG_TOOLBAR_BUTTON_WIDTH As Double = 150#
Private Const CONFIG_TOOLBAR_BUTTON_HEIGHT As Double = 28#
Private Const CONFIG_TOOLBAR_BUTTON_GAP As Double = 8#
Private Const CONFIG_TOOLBAR_BUTTONS_PER_ROW As Long = 4
Private Const CONFIG_TOOLBAR_BUTTON_COUNT As Long = 7
Private Const SETUP_CONVERGE_RECOVERY_FATAL_ERROR As Long = vbObjectError + 5192
Private Const SETUP_CONVERGE_RECOVERY_FATAL_SOURCE As String = _
    "SetupConvergeRecoveryFatal/"
Private Const ANALYSIS_WORKSPACE_RECOVERY_FATAL_ERROR As Long = vbObjectError + 5191
Private Const ANALYSIS_WORKSPACE_RECOVERY_FATAL_SOURCE As String = _
    "AnalysisWorkspaceRecoveryFatal/"
Private Const CASH_ANALYSIS_RECOVERY_FATAL_ERROR As Long = vbObjectError + 5194
Private Const CASH_ANALYSIS_RECOVERY_FATAL_SOURCE As String = _
    "CashAnalysisRecoveryFatal/"
Private Const TRANSACTION_ANALYSIS_RECOVERY_FATAL_ERROR As Long = vbObjectError + 5195
Private Const TRANSACTION_ANALYSIS_RECOVERY_FATAL_SOURCE As String = _
    "TransactionAnalysisRecoveryFatal/"
Private Const CASH_MANUAL_SELECTION_RECOVERY_FATAL_ERROR As Long = vbObjectError + 5196
Private Const CASH_MANUAL_SELECTION_RECOVERY_FATAL_SOURCE As String = _
    "CashManualSelectionRecoveryFatal/"
Private Const CLEAR_RECOVERY_FATAL_ERROR As Long = vbObjectError + 5197
Private Const CLEAR_RECOVERY_FATAL_SOURCE As String = _
    "ClearRecoveryFatal/"

Private mLastSetupFailure As String
Private mFailureInspectionPrepared As Boolean
Private mFailureDetailLogged As Boolean
Private mLastSetupFailureAt As Date
Private mLastSetupFailureStep As String
Private mLastSetupFailureState As String
Private mOpenRestoreRunCount As Long
Private mWorkbookEventErrorCount As Long
Private mInputReadOnlyLocked As Boolean
Private mCurrentTransactionLockRow As Long

Public Sub SetupWorkbook(Optional ByVal unattended As Boolean = False)
    Dim answer As VbMsgBoxResult
    Dim setupDataProblems As String
    Dim stepName As String
    Dim wsInput As Worksheet, wsSetupState As Worksheet
    Dim backupPath As String, backupNotice As String
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim displayErrorDescription As String
    Dim destructiveStarted As Boolean, setupCoreCommitted As Boolean
    Dim recoveryStateDetail As String, restoreDetail As String
    Dim setupHealthValue As String, priorSetupHealthValue As String
    Dim priorStateSheetExists As Boolean, priorSetupTrace As Boolean
    Dim priorRecoveryLatchSet As Boolean, priorSnapshotCaptured As Boolean
    Dim healthMutationAttempted As Boolean, latchMutationAttempted As Boolean
    Dim setupLogExistedBefore As Boolean, requiresInspection As Boolean
    Dim rollbackOrDestructiveSafe As Boolean
    Dim recoveryDualConfirmed As Boolean, inspectionPrepared As Boolean
    Dim safeToRestoreEntry As Boolean, recoveryEnforceSucceeded As Boolean
    Dim recoveryAttempted As Boolean, terminalRecoveryFailure As Boolean
    Dim finalEventsStopped As Boolean
    Dim appStarted As Boolean, cleanupEventsStopped As Boolean
    Dim applicationStateRestored As Boolean, applicationStateProblems As String
    Dim entryEvents As Boolean, entryEventsCaptured As Boolean
    Dim eventStateDetail As String, recoveryConfirmationDetail As String
    Dim recoveryErrorNumber As Long, recoveryErrorDescription As String
    Dim appEndErrorNumber As Long, appEndErrorDescription As String
    mLastSetupFailure = ""
    mFailureInspectionPrepared = False
    mFailureDetailLogged = False
    mLastSetupFailureAt = 0
    mLastSetupFailureStep = ""
    mLastSetupFailureState = ""
    If ThisWorkbook.ReadOnly Then
        mLastSetupFailure = "The workbook is read-only. Save a writable copy before setup."
        If Not unattended Then
            MsgBox "このブックは読み取り専用です。上書きできる場所へ別名保存してからセットアップしてください。", _
                   vbExclamation, "セットアップできません"
        End If
        Exit Sub
    End If
    If unattended Then
        answer = vbYes
    Else
        answer = MsgBox("空のブック、またはこのツール専用ブックで実行してください。" & vbCrLf & _
                        "同名シートは再作成し、設定値と候補も初期値に戻します。" & vbCrLf & _
                        "既存ツールへ再実行する場合は、消去前に同じフォルダへバックアップを作成します。" & vbCrLf & vbCrLf & _
                        "セットアップを実行しますか？", vbYesNo + vbQuestion, _
                        "資金操作表作成補助ツール セットアップ")
    End If
    If answer <> vbYes Then
        mLastSetupFailure = "Setup was cancelled before any changes were made."
        Exit Sub
    End If
    On Error GoTo EH
    If Not TryGetSetupEnableEvents(entryEvents, eventStateDetail) Then _
        Err.Raise vbObjectError + 1105, "SetupWorkbook", _
                  "セットアップ開始前のイベント状態を一意に保存できません。 " & eventStateDetail
    entryEventsCaptured = True
    '開始前状態を変更するより先に、復元対象を一意に確定する。既存のW_状態が
    '曖昧なまま上書きすると、ラッチ作成失敗時に元の安全状態へ戻せない。
    stepName = "セットアップ前状態確認"
    priorSetupTrace = ToolHasSetupTrace()
    priorStateSheetExists = SheetExists(SH_WORK_STATE)
    setupLogExistedBefore = SheetExists(SH_SETUP_LOG)
    If priorStateSheetExists Then
        If Not TryGetExactStateValue(STATE_DATA_HEALTH, priorSetupHealthValue) Then _
            Err.Raise vbObjectError + 1103, "SetupWorkbook", _
                      "セットアップ前の案件データ状態を一意に保存できません。"
    End If
    If Not TryGetRollbackRecoveryLatch(priorRecoveryLatchSet) Then _
        Err.Raise vbObjectError + 1104, "SetupWorkbook", _
                  "セットアップ前の独立復旧ラッチを一意に保存できません。"
    priorSnapshotCaptured = True
    If WorkbookNeedsSetupBackup() Then
        stepName = "セットアップ前バックアップ"
        backupPath = CreateInitializationBackup()
        backupNotice = vbCrLf & "再セットアップ前バックアップ: " & backupPath
    End If
    AppBegin "セットアップ中..."
    appStarted = True
    If Not SetApplicationEnableEventsExact(False, eventStateDetail) Then _
        Err.Raise vbObjectError + 1106, "SetupWorkbook", _
                  "セットアップ中のイベント停止を一意に確認できません。 " & eventStateDetail
    stepName = "図形表示の準備"
    ThisWorkbook.DisplayDrawingObjects = xlDisplayShapes
    If ThisWorkbook.DisplayDrawingObjects <> xlDisplayShapes Then _
        Err.Raise vbObjectError + 1090, "SetupWorkbook", _
                  "図形を表示するブック設定へ変更できません。"
    DisableInputKeys
    '通常更新は欠落した状態表を作らない。初回セットアップだけは、
    '中断状態を書き込む前に表と見出しを用意する。既存の表は初期化しない。
    stepName = "セットアップ状態表の準備"
    '表の新設途中で失敗した場合も、破壊的工程前の復元対象に含める。
    healthMutationAttempted = True
    If Not priorStateSheetExists Then
        Set wsSetupState = GetOrCreateSheet(SH_WORK_STATE, False)
        wsSetupState.Columns("A:B").NumberFormatLocal = "@"
        SetRowValues wsSetupState.Range("A1"), Array("項目", "値")
    End If
    'VBAを強制停止されても、最初の破壊的工程より前に中断状態を残す。
    stepName = "セットアップ状態記録"
    SetStateValue STATE_DATA_HEALTH, DATA_HEALTH_INITIALIZING
    If Not TryGetExactStateValue(STATE_DATA_HEALTH, setupHealthValue) Or _
       setupHealthValue <> DATA_HEALTH_INITIALIZING Then _
        Err.Raise vbObjectError + 1100, "SetupWorkbook", _
                  "破壊的工程前のセットアップ中断状態を一意に確認できません。"
    'W_状態を最終検査のため一時的に「正常」へ戻す区間でも、VBA強制停止後に
    '未検証ブックを通常扱いしない。状態表とは独立した永続ラッチを破壊開始前に立て、
    stepName = "セットアップ復旧ラッチ記録"
    latchMutationAttempted = True
    SetRollbackRecoveryLatch
    destructiveStarted = True
    stepName = "日付方式の設定"
    ThisWorkbook.Date1904 = False

    stepName = "セットアップログ初期化": ResetSetupLog: LogStep "開始", stepName, "OK", ""
    stepName = "シート準備": LogStep "処理", stepName, "開始", "": PrepareSheets: LogStep "完了", stepName, "OK", ""
    stepName = "設定シート作成": LogStep "処理", stepName, "開始", "": BuildConfigSheetCore: LogStep "完了", stepName, "OK", ""
    stepName = "マスタシート作成": LogStep "処理", stepName, "開始", "": BuildMasterSheets: LogStep "完了", stepName, "OK", ""
    stepName = "設定入力規則": LogStep "処理", stepName, "開始", "": ApplyConfigValidations False: LogStep "完了", stepName, "OK", ""
    stepName = "設定シート確定": LogStep "処理", stepName, "開始", "": FinalizeConfigSheetAfterMasters: LogStep "完了", stepName, "OK", ""
    stepName = "入力シート作成": LogStep "処理", stepName, "開始", "": BuildInputSheet: LogStep "完了", stepName, "OK", ""
    stepName = "作業シート作成": LogStep "処理", stepName, "開始", "": BuildWorkSheets DATA_HEALTH_INITIALIZING: LogStep "完了", stepName, "OK", ""
    stepName = "セットアップ中断状態再確認"
    If Not TryGetExactStateValue(STATE_DATA_HEALTH, setupHealthValue) Or _
       setupHealthValue <> DATA_HEALTH_INITIALIZING Then _
        Err.Raise vbObjectError + 1101, "SetupWorkbook", _
                  "作業シート再作成後のセットアップ中断状態を一意に確認できません。"
    stepName = "出力シート作成": LogStep "処理", stepName, "開始", "": BuildOutputSheets: LogStep "完了", stepName, "OK", ""
    stepName = "残高欄生成": LogStep "処理", stepName, "開始", "": BuildBalanceInputFields False, True: LogStep "完了", stepName, "OK", ""
    stepName = "操作範囲復元": LogStep "処理", stepName, "開始", "": RestoreAllToolSheetScrollAreas: LogStep "完了", stepName, "OK", ""
    stepName = "シート表示整理": LogStep "処理", stepName, "開始", "": HideDailySheets True: LogStep "完了", stepName, "OK", ""

    stepName = "表示調整"
    Set wsInput = GetSheet(SH_INPUT)
    SafeFreezeInput
    SafeSelectCell wsInput, CELL_BANK
    HideDailySheets True
    GetSheet(SH_CONFIG).Visible = xlSheetVisible
    SafeSelectCell GetSheet(SH_CONFIG), "C4"
    RefreshButtonActions
    DisableInputKeys
    stepName = "案件データ状態確定": SetStateValue STATE_DATA_HEALTH, DATA_HEALTH_NORMAL
    If Not TryGetExactStateValue(STATE_DATA_HEALTH, setupHealthValue) Or _
       setupHealthValue <> DATA_HEALTH_NORMAL Then _
        Err.Raise vbObjectError + 1102, "SetupWorkbook", _
                  "セットアップ完了状態を正常として一意に確認できません。"
    stepName = "中核データ最終確認"
    If Not ValidateAuthoritativeDataStructure(setupDataProblems, False, True) Then _
        Err.Raise vbObjectError + 1097, "SetupWorkbook", setupDataProblems
    'ボタン、入力規則、表示差は修復可能であり、案件データの要復旧状態へ混在させない。
    stepName = "独立復旧ラッチ解除"
    ClearRollbackRecoveryLatch
    setupCoreCommitted = True
    destructiveStarted = False
    '全画面を横断する開発者向け診断は通常作成では実行しない。
    'ボタン実行先・保護の設定失敗は各作成処理自身が例外として通知する。
    LogStep "完了", "SetupWorkbook", "セットアップ完了", ""
    AppEnd
    appStarted = False
    If entryEvents Then
        applicationStateProblems = vbNullString
        If Not AppStateIsRestored(applicationStateProblems) Then
            Call SetApplicationEnableEventsExact(False, eventStateDetail)
            Err.Raise vbObjectError + 1108, "SetupWorkbook", _
                      "セットアップ後にExcel全体の状態を復元できません。 " & _
                      applicationStateProblems
        End If
    End If
    If Not SetApplicationEnableEventsExact(entryEvents, eventStateDetail) Then _
        Err.Raise vbObjectError + 1107, "SetupWorkbook", _
                  "セットアップ開始前のイベント状態を復元できません。 " & eventStateDetail
    If Not unattended Then
        MsgBox "セットアップが完了しました。" & vbCrLf & _
               "最初に相続開始日と残高表示年を入力してください。残高欄は自動更新されます。" & _
               backupNotice, vbInformation, "セットアップ完了"
    End If
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    terminalRecoveryFailure = _
        IsSetupRecoveryFatalError(errorNumber, errorSource)
    If terminalRecoveryFailure Then
        On Error Resume Next
        Call SetApplicationEnableEventsExact(False, eventStateDetail)
        Call SetApplicationEnableEventsExact(False, eventStateDetail)
        On Error GoTo 0
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    displayErrorDescription = SetupErrorDisplayDetail(errorDescription)
    mLastSetupFailureAt = Now
    mLastSetupFailureStep = stepName
    mLastSetupFailureState = "Err " & CStr(errorNumber)
    mLastSetupFailure = "Step: " & stepName & " / Source: " & errorSource & _
                        " / Err " & CStr(errorNumber) & ": " & errorDescription
    '復旧処理の二次エラーで、最初に起きた原因を上書きしない。
    On Error Resume Next
    cleanupEventsStopped = False
    recoveryEnforceSucceeded = True
    If entryEventsCaptured Then _
        cleanupEventsStopped = SetApplicationEnableEventsExact(False, eventStateDetail)
    If cleanupEventsStopped And destructiveStarted Then
        requiresInspection = True
        recoveryAttempted = True
        Err.Clear
        EnforceRollbackRecoveryState recoveryStateDetail
        recoveryErrorNumber = Err.Number
        recoveryErrorDescription = Err.Description
        Err.Clear
        '共通復旧は開始値Falseへの復元に失敗して例外終了する可能性もある。
        '以降の緊急保護・ログ書込みより先に、この呼出元がFalseを再確定する。
        cleanupEventsStopped = SetApplicationEnableEventsExact(False, eventStateDetail)
        If Not cleanupEventsStopped Then _
            cleanupEventsStopped = SetApplicationEnableEventsExact(False, eventStateDetail)
        terminalRecoveryFailure = True
        GoTo SETUP_WORKBOOK_RECOVERY_FATAL
    ElseIf cleanupEventsStopped And Not setupCoreCommitted And priorSnapshotCaptured Then
        '中核シートの消去前なら、今回変更を試みたW_状態と独立ラッチだけを
        '開始前の値（または不存在）へ戻す。復元後も必ず双方を読み返す。
        Err.Clear
        If Not RestoreSetupPreDestructiveState( _
                   priorStateSheetExists, priorSetupHealthValue, _
                   priorRecoveryLatchSet, healthMutationAttempted, _
                   latchMutationAttempted, restoreDetail) Then
            requiresInspection = True
            recoveryStateDetail = vbCrLf & "注意: セットアップ開始前状態を復元できませんでした。" & _
                                  IIf(Len(restoreDetail) > 0, " " & restoreDetail, vbNullString)
            Err.Clear
            restoreDetail = vbNullString
            recoveryAttempted = True
            EnforceRollbackRecoveryState restoreDetail
            recoveryErrorNumber = Err.Number
            recoveryErrorDescription = Err.Description
            Err.Clear
            'EnforceRollbackRecoveryState後はイベント値を推測しない。
            cleanupEventsStopped = SetApplicationEnableEventsExact(False, eventStateDetail)
            If Not cleanupEventsStopped Then _
                cleanupEventsStopped = SetApplicationEnableEventsExact(False, eventStateDetail)
            terminalRecoveryFailure = True
            GoTo SETUP_WORKBOOK_RECOVERY_FATAL
        ElseIf priorSetupTrace And _
               (Not priorStateSheetExists Or _
                priorSetupHealthValue <> DATA_HEALTH_NORMAL Or _
                priorRecoveryLatchSet) Then
            '開始前から未初期化・要復旧だったブックは、元へ戻せても通常化しない。
            requiresInspection = True
        Else
            rollbackOrDestructiveSafe = True
        End If
    ElseIf cleanupEventsStopped And Not setupCoreCommitted And priorSetupTrace Then
        '開始前状態を一意に保存できなかった既存ツールは通常扱いしない。
        requiresInspection = True
    ElseIf cleanupEventsStopped And setupCoreCommitted Then
        '中核確定後の表示工程だけの失敗なら、破壊途中の旧状態へ戻す必要はない。
        rollbackOrDestructiveSafe = True
    ElseIf cleanupEventsStopped And Not destructiveStarted And _
           Not healthMutationAttempted And Not latchMutationAttempted Then
        '開始前スナップショット取得中の失敗で、ブック状態をまだ変更していない。
        rollbackOrDestructiveSafe = True
    End If
    '空の新規ブックで破壊開始前に失敗した時は、診断ログ作成そのものが
    '新しいセットアップ痕跡になる。既存ログがある時か要検査時だけ記録する。
    If cleanupEventsStopped And recoveryEnforceSucceeded And _
       (destructiveStarted Or setupCoreCommitted Or setupLogExistedBefore Or requiresInspection) Then
        Err.Clear
        LogStep "エラー", stepName, "Err " & errorNumber, errorSource & " / " & errorDescription
    End If
    '要復旧状態と緊急保護を先に残し、その後でExcel全体のイベント等を戻す。
    If cleanupEventsStopped And recoveryEnforceSucceeded And _
       Not requiresInspection Then EnableInputKeys
    If appStarted Then
        Err.Clear
        AppEnd
        If Err.Number = 0 Then appStarted = False
    End If
    'AppEndが失敗した場合だけ、この処理が開始したleaseの残存を再試行する。
    '正常に閉じた入れ子leaseから、呼出元の外側leaseを強制終了してはならない。
    If appStarted Then
        Err.Clear
        AppForceRestore
        If Err.Number = 0 Then appStarted = False
        Err.Clear
    End If
    If requiresInspection And recoveryEnforceSucceeded Then
        'AppEnd／AppForceRestoreが開始値を戻した後でも、診断シートへ触る直前に
        'イベント停止を再確認する。失敗時はシートへ一切書き込まない。
        eventStateDetail = vbNullString
        cleanupEventsStopped = SetApplicationEnableEventsExact(False, eventStateDetail)
        If cleanupEventsStopped Then
            inspectionPrepared = PrepareFailedSetupForInspection()
            '診断準備も内部でイベント開始値を復元するため、復旧状態の読戻し前に
            '呼出元の安全停止をもう一度書込み・読戻しする。
            cleanupEventsStopped = SetApplicationEnableEventsExact(False, eventStateDetail)
            If Not cleanupEventsStopped Then _
                cleanupEventsStopped = SetApplicationEnableEventsExact(False, eventStateDetail)
            If cleanupEventsStopped And inspectionPrepared Then
                recoveryConfirmationDetail = vbNullString
                recoveryDualConfirmed = _
                    SetupRecoveryStateIsConfirmedExact(recoveryConfirmationDetail)
                If Not recoveryDualConfirmed Then _
                    AppendSetupRestoreDetail recoveryStateDetail, _
                        "要復旧状態の二重確認が未完了です。 " & _
                        recoveryConfirmationDetail
            ElseIf Not cleanupEventsStopped Then
                AppendSetupRestoreDetail recoveryStateDetail, _
                    "診断準備後のイベント停止を一意に確認できません。 " & _
                    eventStateDetail
            Else
                AppendSetupRestoreDetail recoveryStateDetail, _
                    "失敗後の診断隔離状態を一意に確認できません。"
            End If
        Else
            If Len(recoveryStateDetail) > 0 Then recoveryStateDetail = recoveryStateDetail & vbCrLf
            recoveryStateDetail = recoveryStateDetail & _
                "注意: イベント停止を確認できないため失敗後診断の書込みを見送りました。 " & _
                eventStateDetail
        End If
    End If
    '開始値へ戻せるのは、Application leaseの完全復元に加え、破壊工程が
    '未開始／確定済み／完全ロールバックのいずれか、または独立ラッチと
    '要復旧状態の二重確認＋診断隔離を全て確認できた場合だけである。
    applicationStateRestored = False
    If recoveryEnforceSucceeded Then
        applicationStateProblems = vbNullString
        Err.Clear
        applicationStateRestored = AppStateIsRestored(applicationStateProblems)
        If Err.Number <> 0 Then applicationStateRestored = False
        Err.Clear
    Else
        applicationStateProblems = _
            "共通復旧処理がエラー終了したため、Application状態を成功根拠として再利用しません。"
    End If
    finalEventsStopped = False
    If entryEventsCaptured Then
        finalEventsStopped = _
            SetApplicationEnableEventsExact(False, eventStateDetail)
        If Not finalEventsStopped Then _
            finalEventsStopped = _
                SetApplicationEnableEventsExact(False, eventStateDetail)
    End If
    safeToRestoreEntry = recoveryEnforceSucceeded And applicationStateRestored And _
        finalEventsStopped And _
        (rollbackOrDestructiveSafe Or _
         (requiresInspection And recoveryDualConfirmed And inspectionPrepared))
    If entryEventsCaptured And safeToRestoreEntry Then
        If Not SetApplicationEnableEventsExact(entryEvents, eventStateDetail) Then
            If Not SetApplicationEnableEventsExact(entryEvents, eventStateDetail) Then
                safeToRestoreEntry = False
                AppendSetupRestoreDetail recoveryStateDetail, _
                    "イベント開始値を再試行後も復元できません。 " & eventStateDetail
            End If
        End If
    Else
        safeToRestoreEntry = False
    End If
    If Not safeToRestoreEntry Then
        If Not SetApplicationEnableEventsExact(False, eventStateDetail) Then
            If Not SetApplicationEnableEventsExact(False, eventStateDetail) Then
                AppendSetupRestoreDetail recoveryStateDetail, _
                    "ExcelイベントをFalseへも収束できず、状態は不明です。 " & _
                    eventStateDetail
            End If
        End If
        If Not applicationStateRestored Then _
            AppendSetupRestoreDetail recoveryStateDetail, _
                "Excel全体の状態が未復元のためイベントを停止したままにしました。" & _
                IIf(Len(applicationStateProblems) > 0, _
                    " " & applicationStateProblems, vbNullString)
        If Not rollbackOrDestructiveSafe And _
           Not (requiresInspection And recoveryDualConfirmed And inspectionPrepared) Then _
            AppendSetupRestoreDetail recoveryStateDetail, _
                "破壊工程の安全な収束または要復旧隔離を確認できないため、" & _
                "イベント開始値へは戻していません。"
    End If
    On Error GoTo 0
    If Not unattended Then
        MsgBox "セットアップ中にエラーが発生しました。" & vbCrLf & vbCrLf & _
               "工程: " & stepName & vbCrLf & "発生元: " & errorSource & vbCrLf & _
               "Err " & errorNumber & ": " & displayErrorDescription & recoveryStateDetail & _
               IIf(Len(backupPath) > 0, vbCrLf & "再セットアップ前バックアップ: " & backupPath & vbCrLf & _
                   "復旧する場合は、このブックを上書き保存せず閉じてバックアップを開いてください。", "") & _
               vbCrLf & vbCrLf & _
               "C_チェックとW_セットアップログを確認してください。", vbExclamation, "セットアップエラー"
    End If
    Exit Sub

SETUP_WORKBOOK_RECOVERY_FATAL:
    'nestedまたはdirect Enforceのterminal error後は、AppEnd/ForceRestore、
    '診断・保護・状態書込み、開始値=Trueへの復元を一切行わない。
    If IsSetupRecoveryFatalError(errorNumber, errorSource) Then
        On Error Resume Next
        Call SetApplicationEnableEventsExact(False, eventStateDetail)
        Call SetApplicationEnableEventsExact(False, eventStateDetail)
        On Error GoTo 0
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    eventStateDetail = vbNullString
    cleanupEventsStopped = _
        SetApplicationEnableEventsExact(False, eventStateDetail)
    If Not cleanupEventsStopped Then _
        cleanupEventsStopped = _
            SetApplicationEnableEventsExact(False, eventStateDetail)
    If Not cleanupEventsStopped Then _
        AppendSetupRestoreDetail recoveryStateDetail, _
            "terminal Recovery後もExcelイベントをFalseへ収束できません。 " & _
            eventStateDetail
    On Error GoTo 0
    If IsSetupRecoveryFatalError(errorNumber, errorSource) Then _
        Err.Raise errorNumber, errorSource, errorDescription
    Err.Raise SETUP_CONVERGE_RECOVERY_FATAL_ERROR, _
              SETUP_CONVERGE_RECOVERY_FATAL_SOURCE & "SetupWorkbook", _
              "元エラー Err " & CStr(errorNumber) & " / " & _
              errorSource & ": " & errorDescription & _
              IIf(Len(recoveryStateDetail) > 0, _
                  " / " & recoveryStateDetail, vbNullString)
End Sub

Private Function RestoreSetupPreDestructiveState( _
        ByVal priorStateSheetExists As Boolean, _
        ByVal priorHealthValue As String, _
        ByVal priorRecoveryLatchSet As Boolean, _
        ByVal healthMutationAttempted As Boolean, _
        ByVal latchMutationAttempted As Boolean, _
        ByRef detailText As String) As Boolean
    Dim restoredHealthValue As String
    Dim restoredLatchSet As Boolean
    Dim operationErrorNumber As Long, operationErrorDescription As String
    Dim stateSheetDeleteDetail As String
    Dim restoreOK As Boolean

    restoreOK = True
    detailText = vbNullString
    On Error Resume Next

    If healthMutationAttempted Then
        Err.Clear
        If priorStateSheetExists Then
            SetStateValue STATE_DATA_HEALTH, priorHealthValue
        ElseIf SheetExists(SH_WORK_STATE) Then
            '開始前にW_状態が無かった場合、この時点では新設した見出しと
            '中断状態だけがある。シートごと削除して開始前の「不存在」へ戻す。
            If Not DeleteNewSetupStateSheet(stateSheetDeleteDetail) Then
                restoreOK = False
                AppendSetupRestoreDetail detailText, stateSheetDeleteDetail
            End If
        End If
        operationErrorNumber = Err.Number
        operationErrorDescription = Err.Description
        Err.Clear
        If operationErrorNumber <> 0 Then
            restoreOK = False
            AppendSetupRestoreDetail detailText, _
                "案件データ状態の復元 Err " & CStr(operationErrorNumber) & ": " & _
                operationErrorDescription
        End If
    End If

    If priorStateSheetExists Then
        Err.Clear
        If Not TryGetExactStateValue(STATE_DATA_HEALTH, restoredHealthValue) Or _
           StrComp(restoredHealthValue, priorHealthValue, vbBinaryCompare) <> 0 Then
            restoreOK = False
            AppendSetupRestoreDetail detailText, _
                "案件データ状態の復元結果を一意に確認できません。"
        End If
        Err.Clear
    ElseIf SheetExists(SH_WORK_STATE) Then
        restoreOK = False
        AppendSetupRestoreDetail detailText, _
            "開始前には無かったW_状態が残っています。"
    End If

    If latchMutationAttempted Then
        Err.Clear
        If priorRecoveryLatchSet Then
            SetRollbackRecoveryLatch
        Else
            ClearRollbackRecoveryLatch
        End If
        operationErrorNumber = Err.Number
        operationErrorDescription = Err.Description
        Err.Clear
        If operationErrorNumber <> 0 Then
            restoreOK = False
            AppendSetupRestoreDetail detailText, _
                "独立復旧ラッチの復元 Err " & CStr(operationErrorNumber) & ": " & _
                operationErrorDescription
        End If
    End If

    Err.Clear
    If Not TryGetRollbackRecoveryLatch(restoredLatchSet) Then
        restoreOK = False
        AppendSetupRestoreDetail detailText, _
            "独立復旧ラッチの復元結果を読み取れません。"
    ElseIf restoredLatchSet <> priorRecoveryLatchSet Then
        restoreOK = False
        AppendSetupRestoreDetail detailText, _
            "独立復旧ラッチが開始前の状態へ戻っていません。"
    End If
    Err.Clear
    On Error GoTo 0
    RestoreSetupPreDestructiveState = restoreOK
End Function

Private Function DeleteNewSetupStateSheet(ByRef detailText As String) As Boolean
    Dim previousDisplayAlerts As Boolean, displayAlertsChanged As Boolean
    Dim deleteErrorNumber As Long, deleteErrorDescription As String
    Dim alertsRestoreFailed As Boolean, alertsRestoreDetail As String
    detailText = vbNullString
    On Error GoTo EH
    If Not SheetExists(SH_WORK_STATE) Then
        DeleteNewSetupStateSheet = True
        Exit Function
    End If

    previousDisplayAlerts = Application.DisplayAlerts
    displayAlertsChanged = True
    Application.DisplayAlerts = False
    If Application.DisplayAlerts <> False Then _
        Err.Raise vbObjectError + 1105, "DeleteNewSetupStateSheet", _
                  "W_状態削除前に確認表示を安全に停止できませんでした。"
    ThisWorkbook.Worksheets(SH_WORK_STATE).Delete
    Application.DisplayAlerts = previousDisplayAlerts
    If Application.DisplayAlerts <> previousDisplayAlerts Then _
        Err.Raise vbObjectError + 1106, "DeleteNewSetupStateSheet", _
                  "W_状態削除後に確認表示の設定を元へ戻せませんでした。"
    displayAlertsChanged = False
    If SheetExists(SH_WORK_STATE) Then _
        Err.Raise vbObjectError + 1107, "DeleteNewSetupStateSheet", _
                  "開始前には無かったW_状態を削除できませんでした。"
    DeleteNewSetupStateSheet = True
    Exit Function
EH:
    deleteErrorNumber = Err.Number
    deleteErrorDescription = Err.Description
    On Error Resume Next
    If displayAlertsChanged Then
        Err.Clear
        Application.DisplayAlerts = previousDisplayAlerts
        If Err.Number <> 0 Then
            alertsRestoreFailed = True
            alertsRestoreDetail = "Err " & CStr(Err.Number) & ": " & Err.Description
        End If
        Err.Clear
        If Not alertsRestoreFailed Then
            If Application.DisplayAlerts <> previousDisplayAlerts Then
                alertsRestoreFailed = True
                alertsRestoreDetail = "設定値の読戻しが一致しません。"
            End If
        End If
    End If
    On Error GoTo 0
    detailText = "開始前には無かったW_状態の削除 Err " & _
                 CStr(deleteErrorNumber) & ": " & deleteErrorDescription
    If alertsRestoreFailed Then _
        detailText = detailText & " / DisplayAlertsを元へ戻せませんでした: " & _
                     alertsRestoreDetail
    Err.Clear
End Function

Private Sub AppendSetupRestoreDetail(ByRef detailText As String, _
                                     ByVal itemText As String)
    If Len(itemText) = 0 Then Exit Sub
    If Len(detailText) > 0 Then detailText = detailText & " / "
    detailText = detailText & itemText
End Sub

Private Function SetupErrorDisplayDetail(ByVal detailText As String) As String
    '画面では先頭の原因を読める量に絞る。検出全件と工程詳細はブック内で確認し、
    '自動作成時は導入スクリプトがcreate_error.txtにも書き出す。
    Dim lines As Variant, item As Variant
    Dim resultText As String, lineText As String
    Dim shownLines As Long, totalLines As Long
    lines = Split(Replace(detailText, vbCr, vbNullString), vbLf)
    For Each item In lines
        lineText = Trim$(CStr(item))
        If Len(lineText) > 0 Then
            totalLines = totalLines + 1
            If shownLines < 4 And Len(resultText) < 700 Then
                If Len(resultText) > 0 Then resultText = resultText & vbCrLf
                resultText = resultText & lineText
                shownLines = shownLines + 1
            End If
        End If
    Next item
    If Len(resultText) = 0 Then resultText = "原因の詳細を取得できませんでした。"
    If totalLines > shownLines Or Len(detailText) > Len(resultText) + 50 Then _
        resultText = resultText & vbCrLf & _
                     "（確認先: C_チェック／W_セットアップログ。自動作成時は要約を.setup_error.txtにも記録します。）"
    SetupErrorDisplayDetail = resultText
End Function

Public Function GetLastSetupFailureDetail() As String
    '自動作成スクリプトが、SetupWorkbook内で捕捉した実エラーを表示するための読取専用窓口。
    GetLastSetupFailureDetail = mLastSetupFailure
End Function

Public Function GetOpenRestoreRunCount() As Long
    '作成スクリプトが、再オープン時にWorkbook_Open経由の復元処理が
    '実際に完了経路へ入ったことを確認するための読取専用カウンター。
    GetOpenRestoreRunCount = mOpenRestoreRunCount
End Function

Public Sub RecordWorkbookOpenCompleted()
    'Workbook_Openの復元と読取専用制御が両方完了した時だけ記録する。
    mOpenRestoreRunCount = mOpenRestoreRunCount + 1
End Sub

Public Sub RecordWorkbookEventFailure()
    mWorkbookEventErrorCount = mWorkbookEventErrorCount + 1
End Sub

Public Function GetWorkbookEventErrorCount() As Long
    GetWorkbookEventErrorCount = mWorkbookEventErrorCount
End Function

Public Sub RestoreWorkbookAfterOpenCore(Optional ByVal strictBuildVerification As Boolean = False)
    'Workbook_Openと作成スクリプトの再オープン検査で、同じ復元処理を使う。
    '非表示Excelでの作成検査ではMsgBoxを出さず、準備状態の差を例外として返す。
    Dim healthClass As Long
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim terminalEventsStopped As Boolean, terminalEventDetail As String
    On Error GoTo EH
    If strictBuildVerification Then
        If Not ToolHasSetupTrace() Then _
            Err.Raise vbObjectError + 1081, "RestoreWorkbookAfterOpenCore", _
                      "セットアップ済みの構成を確認できません。"
        healthClass = ToolDataHealthClassification()
        If healthClass <> TOOL_HEALTH_NORMAL Then _
            Err.Raise vbObjectError + 1082, "RestoreWorkbookAfterOpenCore", _
                      "案件データ状態が正常ではありません。分類=" & CStr(healthClass)
    ElseIf ToolHasSetupTrace() Then
        If Not RequireToolReady() Then
            DisableInputKeys
            PrepareFailedSetupForInspection
            GoTo CleanExit
        End If
    End If
    RefreshButtonActions
    RefreshMainActionCaption
    If SheetExists(SH_CONFIG) Then ProtectConfigSheet True
    ProtectAllCandidateSheets True
    If SheetExists(SH_INPUT) Then ProtectInputSheet True
    If SheetExists(SH_OUTPUT_BAL) Then ProtectGeneratedOutputSheet GetSheet(SH_OUTPUT_BAL), True
    If SheetExists(SH_OUTPUT_TX_CONVERTED) Then _
        ProtectGeneratedOutputSheet GetSheet(SH_OUTPUT_TX_CONVERTED), True
    If SheetExists(SH_REGISTERED_ACCOUNTS) Then ProtectRegisteredAccountsSheet True
    If SheetExists(SH_INPUT) Then
        HideDailySheets False
        If SheetExists(SH_SHOP_TARGET) Then ProtectShopConversionTargetSheet True
        ProtectTransactionAnalysisSheets True
        If SheetExists(SH_OUTPUT_TX) Then ProtectCashAnalysisViewSheet
        If strictBuildVerification Then
            If ThisWorkbook.ReadOnly Then _
                Err.Raise vbObjectError + 1083, "RestoreWorkbookAfterOpenCore", _
                          "再オープンした作成ブックが読み取り専用です。"
            SetAnalysisReviewEditingEnabled True
            SetCashAnalysisViewEditingEnabled True
        End If
        If TypeName(ActiveSheet) = "Worksheet" And ActiveSheet.Name = SH_INPUT Then
            If strictBuildVerification Then DisableInputKeys Else EnableInputKeys
        End If
    End If
    RestoreAllToolSheetScrollAreas
    If TypeName(ActiveSheet) = "Worksheet" Then ApplyActiveSheetWindowStyle ActiveSheet
CleanExit:
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    If IsSetupRecoveryFatalError(errorNumber, errorSource) Then
        On Error Resume Next
        Call SetApplicationEnableEventsExact(False, terminalEventDetail)
        Call SetApplicationEnableEventsExact(False, terminalEventDetail)
        On Error GoTo 0
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    '永続属性を修復した場合はdirtyを維持し、Open時の変更をSaved=Trueで隠さない。
    '表示倍率・選択位置などのWindow状態はそもそも保存状態へ影響させない。
    Err.Raise errorNumber, "RestoreWorkbookAfterOpenCore", errorDescription
End Sub


Public Function PrepareFailedSetupForInspection() As Boolean
    'セットアップ失敗後も、原因確認・診断保存・手動の別名保存を妨げない。
    '通常操作を許可する処理ではなく、ログを見える状態にするだけの限定復旧である。
    Dim wsTarget As Worksheet
    Dim previousEvents As Boolean, previousScreenUpdating As Boolean
    Dim previousDisplayAlerts As Boolean, previousStatusBar As Variant
    Dim eventsCaptured As Boolean, screenCaptured As Boolean
    Dim alertsCaptured As Boolean, statusCaptured As Boolean
    Dim eventsDisabled As Boolean, eventsReadback As Boolean
    Dim statusReadback As Variant, screenReadback As Boolean, alertsReadback As Boolean
    Dim drawingObjectsReady As Boolean, drawingObjectsReadback As Long
    Dim diagnosticReady As Boolean, evidenceReady As Boolean
    Dim activationReady As Boolean, restoreReady As Boolean
    Dim appRestoreReady As Boolean, appStateRestored As Boolean
    Dim appStateReadErrorNumber As Long, appStateProblems As String
    Dim appRestoreDetail As String, eventStateDetail As String
    Dim activeBook As Workbook, activeSheetObject As Object
    On Error Resume Next
    '呼出元が所有するApplication leaseを強制終了しない。現在のイベント値を
    'この限定診断の開始値として捕捉し、終了時も同じ値へ戻す。
    Err.Clear
    appStateRestored = AppStateIsRestored(appStateProblems)
    appStateReadErrorNumber = Err.Number
    appRestoreReady = (appStateReadErrorNumber = 0)
    If Not appRestoreReady Then
        If appStateReadErrorNumber <> 0 Then _
            AppendSetupRestoreDetail appRestoreDetail, _
                "Application状態の読戻し Err " & CStr(appStateReadErrorNumber)
        If Len(appRestoreDetail) = 0 Then _
            appRestoreDetail = "Application状態の所有関係を確認できません。"
        AppendSetupRestoreDetail mLastSetupFailure, _
                                 "失敗後診断のExcel状態確認: " & appRestoreDetail
    ElseIf Not appStateRestored And Len(appStateProblems) > 0 Then
        AppendSetupRestoreDetail mLastSetupFailure, _
                                 "呼出元Application leaseを維持: " & appStateProblems
    End If
    Err.Clear: previousEvents = Application.EnableEvents: eventsCaptured = (Err.Number = 0)
    Err.Clear: previousScreenUpdating = Application.ScreenUpdating: screenCaptured = (Err.Number = 0)
    Err.Clear: previousDisplayAlerts = Application.DisplayAlerts: alertsCaptured = (Err.Number = 0)
    Err.Clear: previousStatusBar = Application.StatusBar: statusCaptured = (Err.Number = 0)
    Err.Clear
    If eventsCaptured Then
        Err.Clear
        Application.EnableEvents = False
        eventsDisabled = (Err.Number = 0)
        If eventsDisabled Then
            Err.Clear
            eventsReadback = Application.EnableEvents
            If Err.Number <> 0 Or eventsReadback Then eventsDisabled = False
        End If
    End If
    diagnosticReady = appRestoreReady And eventsCaptured And screenCaptured And _
                      alertsCaptured And statusCaptured And eventsDisabled
    If eventsDisabled Then
        Err.Clear
        ThisWorkbook.DisplayDrawingObjects = xlDisplayShapes
        drawingObjectsReady = (Err.Number = 0)
        If drawingObjectsReady Then
            Err.Clear
            drawingObjectsReadback = CLng(ThisWorkbook.DisplayDrawingObjects)
            If Err.Number <> 0 Or drawingObjectsReadback <> xlDisplayShapes Then _
                drawingObjectsReady = False
        End If
        diagnosticReady = diagnosticReady And drawingObjectsReady
        HideDailySheets True

    If SheetExists(SH_CHECK) Then
        GetSheet(SH_CHECK).Visible = xlSheetVisible
        GetSheet(SH_CHECK).Unprotect Password:=TOOL_PASSWORD
        If Len(mLastSetupFailure) > 0 And Not mFailureDetailLogged Then
            mFailureDetailLogged = TryLogSetupFailureToCheck( _
                GetSheet(SH_CHECK), Left$(mLastSetupFailure, 30000))
        End If
        If mFailureDetailLogged Or _
           (Len(mLastSetupFailure) = 0 And LastDataRowInColumns(GetSheet(SH_CHECK), 1, 4) > 1) Then _
            evidenceReady = True
        ProtectFailedSetupDiagnosticSheet GetSheet(SH_CHECK), True
        If Not FailedSetupDiagnosticSheetReady(GetSheet(SH_CHECK), True) Then diagnosticReady = False
        If LastDataRowInColumns(GetSheet(SH_CHECK), 1, 4) > 1 Then Set wsTarget = GetSheet(SH_CHECK)
    End If
    If SheetExists(SH_SETUP_LOG) Then
        GetSheet(SH_SETUP_LOG).Visible = xlSheetVisible
        ProtectFailedSetupDiagnosticSheet GetSheet(SH_SETUP_LOG), True
        If Not FailedSetupDiagnosticSheetReady(GetSheet(SH_SETUP_LOG), True) Then diagnosticReady = False
        If FailedSetupLogHasDiagnosticEvidence(GetSheet(SH_SETUP_LOG), _
                                               Len(mLastSetupFailure) > 0) Then evidenceReady = True
        If wsTarget Is Nothing Then Set wsTarget = GetSheet(SH_SETUP_LOG)
    End If
    If SheetExists(SH_CONFIG) Then
        GetSheet(SH_CONFIG).Visible = xlSheetVisible
        ProtectFailedSetupDiagnosticSheet GetSheet(SH_CONFIG), False
        If Not FailedSetupDiagnosticSheetReady(GetSheet(SH_CONFIG), False) Then diagnosticReady = False
        If wsTarget Is Nothing Then Set wsTarget = GetSheet(SH_CONFIG)
    End If
    If SheetExists(SH_INPUT) Then
        GetSheet(SH_INPUT).Visible = xlSheetVisible
        ProtectFailedSetupDiagnosticSheet GetSheet(SH_INPUT), False
        If Not FailedSetupDiagnosticSheetReady(GetSheet(SH_INPUT), False) Then diagnosticReady = False
        If wsTarget Is Nothing Then Set wsTarget = GetSheet(SH_INPUT)
    End If
    If Not wsTarget Is Nothing Then
        Err.Clear
        ThisWorkbook.Activate
        wsTarget.Activate
        RestoreToolSheetScrollArea wsTarget
        If wsTarget.EnableSelection <> xlNoSelection Then wsTarget.Range("A1").Select
        activationReady = (Err.Number = 0)
        Err.Clear
        If activationReady Then
            Set activeBook = Application.ActiveWorkbook
            If Err.Number <> 0 Then activationReady = False
            Err.Clear
        End If
        If activationReady Then
            Set activeSheetObject = Application.ActiveSheet
            If Err.Number <> 0 Then activationReady = False
            Err.Clear
        End If
        If activationReady Then
            If activeBook Is Nothing Or activeSheetObject Is Nothing Then
                activationReady = False
            ElseIf Not activeBook Is ThisWorkbook Then
                activationReady = False
            ElseIf Not activeSheetObject Is wsTarget Then
                activationReady = False
            End If
        End If
        If activationReady Then
            If Not QuarantineOtherFailedSetupToolSheets() Then diagnosticReady = False
        End If
    Else
        diagnosticReady = False
    End If
    Else
        diagnosticReady = False
        AppendSetupRestoreDetail mLastSetupFailure, _
            "失敗後診断ではイベント停止を一意に確認できないため、シートへの書込みを見送りました。"
    End If
    restoreReady = True
    If statusCaptured Then
        Err.Clear
        Application.StatusBar = previousStatusBar
        If Err.Number <> 0 Then
            restoreReady = False
        Else
            Err.Clear
            statusReadback = Application.StatusBar
            If Err.Number <> 0 Or _
               StrComp(CellText(statusReadback), CellText(previousStatusBar), vbBinaryCompare) <> 0 Then _
                restoreReady = False
        End If
    End If
    If screenCaptured Then
        Err.Clear
        Application.ScreenUpdating = previousScreenUpdating
        If Err.Number <> 0 Then
            restoreReady = False
        Else
            Err.Clear
            screenReadback = Application.ScreenUpdating
            If Err.Number <> 0 Or screenReadback <> previousScreenUpdating Then restoreReady = False
        End If
    End If
    If alertsCaptured Then
        Err.Clear
        Application.DisplayAlerts = previousDisplayAlerts
        If Err.Number <> 0 Then
            restoreReady = False
        Else
            Err.Clear
            alertsReadback = Application.DisplayAlerts
            If Err.Number <> 0 Or alertsReadback <> previousDisplayAlerts Then restoreReady = False
        End If
    End If
    If eventsCaptured Then
        If Not SetApplicationEnableEventsExact(previousEvents, eventStateDetail) Then
            If Not SetApplicationEnableEventsExact(previousEvents, eventStateDetail) Then
                restoreReady = False
                If Not SetApplicationEnableEventsExact(False, eventStateDetail) Then _
                    AppendSetupRestoreDetail mLastSetupFailure, _
                        "失敗後診断のイベント状態を開始値にも安全停止にも収束できませんでした。 " & _
                        eventStateDetail
            End If
        End If
    Else
        restoreReady = False
    End If
    PrepareFailedSetupForInspection = diagnosticReady And evidenceReady And _
                                      activationReady And restoreReady
    mFailureInspectionPrepared = PrepareFailedSetupForInspection
    Err.Clear
    On Error GoTo 0
End Function

Private Function TryLogSetupFailureToCheck(ByVal ws As Worksheet, _
                                           ByVal failureText As String) As Boolean
    'AddCheckは診断を失わないため内部でResume Nextを使う。呼出側では追加予定行の
    '4項目を読み戻し、本文や時刻だけ欠けた部分書込みを成功扱いしない。
    Dim targetRow As Long
    Dim writeStarted As Date, writtenAt As Variant
    If ws Is Nothing Or Len(failureText) = 0 Then Exit Function
    On Error GoTo EH
    targetRow = LastRow(ws, 1) + 1
    If targetRow < 2 Then targetRow = 2
    writeStarted = Now
    AddCheck "エラー", "セットアップ", failureText
    If StrComp(CellText(ws.Cells(targetRow, 1).Value2), "エラー", vbBinaryCompare) <> 0 Then Exit Function
    If StrComp(CellText(ws.Cells(targetRow, 2).Value2), "セットアップ", vbBinaryCompare) <> 0 Then Exit Function
    If StrComp(CellText(ws.Cells(targetRow, 3).Value2), failureText, vbBinaryCompare) <> 0 Then Exit Function
    writtenAt = ws.Cells(targetRow, 4).Value
    If IsError(writtenAt) Then Exit Function
    If Not IsDate(writtenAt) Then Exit Function
    If CDbl(CDate(writtenAt)) < CDbl(writeStarted) - (1# / 86400#) Then Exit Function
    If CDbl(CDate(writtenAt)) > CDbl(Now) + (1# / 86400#) Then Exit Function
    TryLogSetupFailureToCheck = True
    Exit Function
EH:
    Err.Clear
End Function

Private Function FailedSetupDiagnosticSheetReady(ByVal ws As Worksheet, _
                                                  ByVal allowSelection As Boolean) As Boolean
    Dim shp As Shape, lockedState As Variant, actionText As String
    If ws Is Nothing Then Exit Function
    On Error GoTo EH
    If ws.Visible <> xlSheetVisible Then Exit Function
    If Not ws.ProtectContents Or Not ws.ProtectDrawingObjects Then Exit Function
    lockedState = ws.Cells.Locked
    If IsNull(lockedState) Then Exit Function
    If Not CBool(lockedState) Then Exit Function
    If allowSelection Then
        If ws.EnableSelection <> xlNoRestrictions Then Exit Function
    ElseIf ws.EnableSelection <> xlNoSelection Then
        Exit Function
    End If
    For Each shp In ws.Shapes
        If Not shp.Locked Then Exit Function
        actionText = CellText(shp.OnAction)
        If Left$(shp.Name, Len(UI_PREFIX & "btn_")) = UI_PREFIX & "btn_" Then
            If Not ToolShapeActionMatches(shp, "ShowRecoveryNotice", True) Then Exit Function
        ElseIf Len(actionText) > 0 Then
            Exit Function
        End If
    Next shp
    FailedSetupDiagnosticSheetReady = True
    Exit Function
EH:
    Err.Clear
End Function

Private Function FailedSetupLogHasDiagnosticEvidence(ByVal ws As Worksheet, _
                                                     ByVal requireErrorRow As Boolean) As Boolean
    Dim lastR As Long, r As Long
    Dim rowTime As Variant
    If ws Is Nothing Then Exit Function
    On Error GoTo EH
    lastR = LastDataRowInColumns(ws, 1, 5)
    If lastR < 2 Then Exit Function
    If Not requireErrorRow Then
        'VBAが再起動されmLastSetupFailureを失った要復旧ブックでは、少なくとも
        '時刻・区分・工程がそろう処理ログだけを診断根拠として受理する。
        For r = 2 To lastR
            rowTime = ws.Cells(r, 1).Value
            If Not IsError(rowTime) Then
                If IsDate(rowTime) Then
                    If CDbl(CDate(rowTime)) > 0 And _
                       Len(CellText(ws.Cells(r, 2).Value2)) > 0 And _
                       Len(CellText(ws.Cells(r, 3).Value2)) > 0 Then
                        FailedSetupLogHasDiagnosticEvidence = True
                        Exit Function
                    End If
                End If
            End If
        Next r
        Exit Function
    End If
    If mLastSetupFailureAt <= 0 Or Len(mLastSetupFailureStep) = 0 Or _
       Len(mLastSetupFailureState) = 0 Then Exit Function
    For r = 2 To lastR
        rowTime = ws.Cells(r, 1).Value
        If Not IsError(rowTime) Then
            If IsDate(rowTime) Then
                If CDbl(CDate(rowTime)) >= CDbl(mLastSetupFailureAt) - (1# / 86400#) And _
                   StrComp(CellText(ws.Cells(r, 2).Value2), "エラー", vbBinaryCompare) = 0 And _
                   StrComp(CellText(ws.Cells(r, 3).Value2), mLastSetupFailureStep, vbBinaryCompare) = 0 And _
                   StrComp(CellText(ws.Cells(r, 4).Value2), mLastSetupFailureState, vbBinaryCompare) = 0 And _
                   Len(CellText(ws.Cells(r, 5).Value2)) > 0 Then
                    FailedSetupLogHasDiagnosticEvidence = True
                    Exit Function
                End If
            End If
        End If
    Next r
    Exit Function
EH:
    Err.Clear
End Function

Private Function QuarantineOtherFailedSetupToolSheets() As Boolean
    'HideDailySheetsが一部失敗しても、診断用4シート以外のツール画面を
    '通常ボタン付きで残さない。安全画面をActivateした後に非表示化して読戻す。
    Dim ws As Worksheet
    Dim allHidden As Boolean
    Dim hideError As Long, readError As Long
    Dim visibilityReadback As XlSheetVisibility
    allHidden = True
    On Error GoTo EH
    For Each ws In ThisWorkbook.Worksheets
        If IsKnownToolSheetNameForRecovery(ws.Name) And _
           Not IsFailedSetupDiagnosticSheetName(ws.Name) Then
            If ws.Visible <> xlSheetVeryHidden Then
                ProtectFailedSetupDiagnosticSheet ws, False
                On Error Resume Next
                Err.Clear
                ws.Visible = xlSheetVeryHidden
                hideError = Err.Number
                Err.Clear
                visibilityReadback = ws.Visible
                readError = Err.Number
                If hideError <> 0 Then allHidden = False
                If readError <> 0 Then allHidden = False
                If readError = 0 Then
                    If visibilityReadback <> xlSheetVeryHidden Then allHidden = False
                End If
                On Error GoTo EH
                If readError = 0 And visibilityReadback = xlSheetVisible Then
                    If Not FailedSetupDiagnosticSheetReady(ws, False) Then allHidden = False
                End If
            End If
        End If
    Next ws
    QuarantineOtherFailedSetupToolSheets = allHidden
    Exit Function
EH:
    Err.Clear
End Function

Private Function IsFailedSetupDiagnosticSheetName(ByVal sheetName As String) As Boolean
    Select Case sheetName
        Case SH_CHECK, SH_SETUP_LOG, SH_CONFIG, SH_INPUT
            IsFailedSetupDiagnosticSheetName = True
    End Select
End Function

Private Function IsKnownToolSheetNameForRecovery(ByVal sheetName As String) As Boolean
    Select Case sheetName
        Case SH_INPUT, SH_CONFIG, SH_WORK_TX, SH_WORK_BAL, SH_WORK_ACCOUNT, SH_WORK_STATE
            IsKnownToolSheetNameForRecovery = True
        Case SH_REGISTERED_ACCOUNTS, SH_CHECK, SH_TEKIYO, SH_ACCOUNT_TYPE, SH_INPUT_MODE
            IsKnownToolSheetNameForRecovery = True
        Case SH_YEAR_MODE, SH_DISPLAY_OPTION, SH_POST_KEEP, SH_POST_CLEAR, SH_ANALYSIS_STATUS
            IsKnownToolSheetNameForRecovery = True
        Case SH_BANK_CAND, SH_BRANCH_CAND, SH_PERSON_CAND, SH_SHOP_TARGET, SH_WORK_CASH
            IsKnownToolSheetNameForRecovery = True
        Case SH_OUTPUT_TX, SH_OUTPUT_BAL, SH_OUTPUT_TX_CONVERTED, SH_ANALYSIS_SHIFT
            IsKnownToolSheetNameForRecovery = True
        Case SH_ANALYSIS_FLOW, SH_ANALYSIS_UNKNOWN, SH_ANALYSIS_RESULT, SH_ANALYSIS_DETAIL
            IsKnownToolSheetNameForRecovery = True
        Case SH_WORK_ANALYSIS_GROUP, SH_WORK_ANALYSIS_REVIEW, SH_WORK_ANALYSIS_HISTORY
            IsKnownToolSheetNameForRecovery = True
        Case SH_WORK_MANUAL_FLOW, SH_BALANCE_RECONCILIATION, SH_SETUP_LOG
            IsKnownToolSheetNameForRecovery = True
    End Select
End Function

Private Sub ProtectFailedSetupDiagnosticSheet(ByVal ws As Worksheet, _
                                               ByVal allowSelection As Boolean)
    '要復旧画面は閲覧・コピーだけを許可する。通常時に編集可能だったセルもすべて
    '再ロックし、ボタンを含む図形を誤ドラッグできない状態で保護する。
    Dim shp As Shape
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    ws.Unprotect Password:=TOOL_PASSWORD
    ws.Cells.Locked = True
    For Each shp In ws.Shapes
        shp.Locked = True
        Err.Clear
        shp.OnAction = vbNullString
        If Left$(shp.Name, Len(UI_PREFIX & "btn_")) = UI_PREFIX & "btn_" Then _
            shp.OnAction = MacroRef("ShowRecoveryNotice")
    Next shp
    EmergencyProtectToolSheet ws
    If allowSelection Then
        ws.EnableSelection = xlNoRestrictions
    Else
        ws.EnableSelection = xlNoSelection
    End If
    On Error GoTo 0
End Sub

Public Sub ShowRecoveryNotice()
    '診断画面の図形ボタンを押しても通常処理へ入れず、次に取る行動だけを案内する。
    MsgBox "このブックはセットアップまたは案件初期化が完了していないため、通常操作はできません。" & vbCrLf & _
           "C_チェックとW_セットアップログを確認し、内容を残す場合は" & _
           "［名前を付けて保存］で診断用コピーを作成してください。" & vbCrLf & _
           "復旧は再セットアップ前バックアップまたは新しい空ブックから行ってください。", _
           vbExclamation, "診断モード"
End Sub

Private Function WorkbookNeedsSetupBackup() As Boolean
    Dim ws As Worksheet
    '途中まで壊れた旧ツールや、同名シートを含むブックも取りこぼさない。
    '既定の空白シートだけなら保存を要求せず、値・数式・図形が一つでもあれば先に退避する。
    For Each ws In ThisWorkbook.Worksheets
        If LastUsedRowInSheet(ws) > 0 Or ws.Shapes.Count > 0 Then
            WorkbookNeedsSetupBackup = True
            Exit Function
        End If
    Next ws
End Function

Public Sub PrepareSheets()
    '新規ブック既定の空白シートを再利用し、不要な Sheet1 を残さない。
    '各Build手続きが責任を持って完全初期化するため、ここでは作成だけに留める。
    '同じ全シートを二度Clearすると、書式履歴の大きい旧ブックでセットアップが極端に遅くなる。
    ReuseBlankWorksheetForTool SH_CONFIG
    GetOrCreateSheet SH_CONFIG, False
    GetOrCreateSheet SH_INPUT, False
    GetOrCreateSheet SH_TEKIYO, False
    GetOrCreateSheet SH_ACCOUNT_TYPE, False
    GetOrCreateSheet SH_INPUT_MODE, False
    GetOrCreateSheet SH_YEAR_MODE, False
    GetOrCreateSheet SH_DISPLAY_OPTION, False
    GetOrCreateSheet SH_POST_KEEP, False
    GetOrCreateSheet SH_POST_CLEAR, False
    GetOrCreateSheet SH_BANK_CAND, False
    GetOrCreateSheet SH_BRANCH_CAND, False
    GetOrCreateSheet SH_PERSON_CAND, False
    GetOrCreateSheet SH_WORK_TX, False
    GetOrCreateSheet SH_WORK_BAL, False
    GetOrCreateSheet SH_WORK_ACCOUNT, False
    GetOrCreateSheet SH_WORK_STATE, False
    GetOrCreateSheet SH_CHECK, False
    GetOrCreateSheet SH_REGISTERED_ACCOUNTS, False
    GetOrCreateSheet SH_WORK_CASH, False
    GetOrCreateSheet SH_OUTPUT_TX, False
    GetOrCreateSheet SH_OUTPUT_BAL, False
    GetOrCreateSheet SH_SHOP_TARGET, False
    GetOrCreateSheet SH_OUTPUT_TX_CONVERTED, False
    GetOrCreateSheet SH_ANALYSIS_SHIFT, False
    GetOrCreateSheet SH_ANALYSIS_FLOW, False
    GetOrCreateSheet SH_ANALYSIS_UNKNOWN, False
    GetOrCreateSheet SH_ANALYSIS_RESULT, False
    GetOrCreateSheet SH_ANALYSIS_DETAIL, False
    GetOrCreateSheet SH_WORK_ANALYSIS_GROUP, False
    GetOrCreateSheet SH_WORK_ANALYSIS_REVIEW, False
    GetOrCreateSheet SH_WORK_ANALYSIS_HISTORY, False
    GetOrCreateSheet SH_WORK_MANUAL_FLOW, False
    GetOrCreateSheet SH_ANALYSIS_STATUS, False
    GetOrCreateSheet SH_BALANCE_RECONCILIATION, False
End Sub

Private Sub ReuseBlankWorksheetForTool(ByVal targetName As String)
    Dim ws As Worksheet
    If SheetExists(targetName) Then Exit Sub
    For Each ws In ThisWorkbook.Worksheets
        If LastUsedRowInSheet(ws) = 0 And ws.Shapes.Count = 0 Then
            ws.Name = targetName
            Exit Sub
        End If
    Next ws
End Sub

Private Sub BuildConfigSheet()
    '単独実行時は、設定画面を完成させてから必ず保護する。
    'SetupWorkbookはマスタと入力規則を先に作る必要があるためCoreを直接呼ぶ。
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    On Error GoTo EH
    BuildConfigSheetCore
    ApplyConfigValidations False
    FinalizeConfigSheetAfterMasters
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    On Error Resume Next
    If SheetExists(SH_CONFIG) Then EmergencyProtectToolSheet GetSheet(SH_CONFIG)
    On Error GoTo 0
    Err.Raise errorNumber, "BuildConfigSheet", errorSource & " / " & errorDescription
End Sub

Private Sub BuildConfigSheetCore()
    Dim ws As Worksheet
    Dim styleLastRow As Long
    Dim stageName As String
    On Error GoTo EH
    stageName = "設定シート取得"
    Set ws = GetSheet(SH_CONFIG)
    If ws Is Nothing Then Err.Raise vbObjectError + 1101, "BuildConfigSheet", "設定シートを取得できません。"
    If ws.Visible <> xlSheetVisible Then ws.Visible = xlSheetVisible
    stageName = "既存設定の初期化"
    ResetWorksheet ws
    stageName = "基本レイアウト"
    styleLastRow = Application.Max(40, ERA_MASTER_MAX_ROW + 3)
    With ws
        With .Range("A1:H" & CStr(styleLastRow))
            .Font.Name = "Yu Gothic UI"
            .Font.Size = 10
        End With
        .Rows("1:" & CStr(styleLastRow)).RowHeight = 19
        .Columns("A:A").ColumnWidth = 3
        .Columns("B:B").ColumnWidth = 18
        .Columns("C:C").ColumnWidth = 26
        .Columns("D:D").ColumnWidth = 22
        .Columns("E:E").ColumnWidth = 12
        .Columns("F:F").ColumnWidth = 20
        .Columns("G:G").ColumnWidth = 14
        .Columns("H:H").ColumnWidth = 22
        .Range("B4").Value = "相続開始日": .Range("C4").ClearContents: .Range("D4").Value = "案件ごとに必須。残高欄と帳票の基準日です。"
        .Range("B5").Value = "残高表示開始年": .Range("C5").Value = Year(Date) - 4: .Range("D5").Value = "年末残高を表示する最初の年。"
        .Range("B6").Value = "残高表示終了年": .Range("C6").Value = Year(Date): .Range("D6").Value = "年末残高を表示する最後の年。"
        .Range("B7").Value = "西暦2桁加算値": .Range("C7").Value = 2000: .Range("D7").Value = "西暦2桁入力時だけ使用。19→2019なら2000。"
        .Range("B8").Value = "入力モード": .Range("C8").Value = MODE_NORMAL: .Range("D8").Value = "不要な入力欄をTab移動から外します。"
        .Range("B9").Value = "転記後に残す口座情報": .Range("C9").Value = KEEP_BANK_BRANCH_PERSON_TYPE: .Range("D9").Value = "続けて入力する口座情報だけを残します。"
        .Range("B10").Value = "転記後の取引明細": .Range("C10").Value = POST_CLEAR: .Range("D10").Value = "通常はクリアを推奨します。"
        .Range("B11").Value = "転記後の残高欄": .Range("C11").Value = POST_CLEAR: .Range("D11").Value = "通常はクリアを推奨します。"
        .Range("B12").Value = "年入力方式": .Range("C12").Value = YEAR_MODE_WAREKI: .Range("D12").Value = "和暦または西暦2桁を選びます。"
        .Range("B13").Value = "続柄の入力・表示": .Range("C13").Value = DISPLAY_ON: .Range("D13").Value = "非表示時は入力と帳票出力も省略します。"
        .Range("B14").Value = "相続開始日行": .Range("C14").Value = DISPLAY_ON: .Range("D14").Value = "資金操作表へ表示するか選びます。"
        .Range("B15").Value = "口座開設日行": .Range("C15").Value = DISPLAY_ON: .Range("D15").Value = "資金操作表へ表示するか選びます。"
        .Range("B16").Value = "口座解約日行": .Range("C16").Value = DISPLAY_ON: .Range("D16").Value = "資金操作表へ表示するか選びます。"
        .Range("B17").Value = "残高行": .Range("C17").Value = DISPLAY_ON: .Range("D17").Value = "各基準日の残高を資金操作表へ表示します。"
        .Range("B4:B17").Font.Bold = True
        .Range("B4:B17").Font.Size = 10.5
        .Range("B4:C17").Borders.LineStyle = xlContinuous
        .Range("C4:C17").Interior.Color = RGB(239, 246, 255)
        .Range("C4").Interior.Color = RGB(254, 249, 195)
        .Range("D4:D17").WrapText = True
        .Range("D4:D17").Font.Size = 9
        .Range("D4:D17").Font.Color = RGB(71, 85, 105)
        .Range("C4").NumberFormatLocal = "yyyy/m/d"
        .Range("C5:C7").NumberFormatLocal = "0"
        .Range("C8:C17").NumberFormatLocal = "@"
        .Cells(ROW_CFG_ANALYSIS_MIN_AMOUNT, COL_CFG_ANALYSIS_LABEL).Value = "シフト・フローの最低金額"
        .Cells(ROW_CFG_ANALYSIS_MIN_AMOUNT, COL_CFG_ANALYSIS_VALUE).Value = 0
        .Cells(ROW_CFG_ANALYSIS_MIN_AMOUNT, COL_CFG_ANALYSIS_NOTE).Value = "資金シフト・フローを探す下限。0なら全件です。"
        .Cells(ROW_CFG_ANALYSIS_DAY_WINDOW, COL_CFG_ANALYSIS_LABEL).Value = "自動候補の日数幅（3暦日固定）"
        .Cells(ROW_CFG_ANALYSIS_DAY_WINDOW, COL_CFG_ANALYSIS_VALUE).Value = 3
        .Cells(ROW_CFG_ANALYSIS_DAY_WINDOW, COL_CFG_ANALYSIS_NOTE).Value = _
            "出金日を0日目として3日目を含み、4日目は候補外です。土日祝日も数えます。"
        .Cells(ROW_CFG_ANALYSIS_ABS_TOLERANCE, COL_CFG_ANALYSIS_LABEL).Value = "金額差の許容額（上限100万円）"
        .Cells(ROW_CFG_ANALYSIS_ABS_TOLERANCE, COL_CFG_ANALYSIS_VALUE).Value = 1000000
        .Cells(ROW_CFG_ANALYSIS_ABS_TOLERANCE, COL_CFG_ANALYSIS_NOTE).Value = _
            "割合条件と差額条件の双方を使用します。100万円未満へ狭められますが、上限は広がりません。"
        .Cells(ROW_CFG_ANALYSIS_RATE_TOLERANCE, COL_CFG_ANALYSIS_LABEL).Value = "金額差の許容率（%、上限10%）"
        .Cells(ROW_CFG_ANALYSIS_RATE_TOLERANCE, COL_CFG_ANALYSIS_VALUE).Value = 10
        .Cells(ROW_CFG_ANALYSIS_RATE_TOLERANCE, COL_CFG_ANALYSIS_NOTE).Value = _
            "入金額を出金額の90～110%以内に限定します。10%未満へ狭められますが、上限は広がりません。"
        .Cells(ROW_CFG_ANALYSIS_UNKNOWN_MIN, COL_CFG_ANALYSIS_LABEL).Value = "不明入出金の最低金額"
        .Cells(ROW_CFG_ANALYSIS_UNKNOWN_MIN, COL_CFG_ANALYSIS_VALUE).Value = 500000
        .Cells(ROW_CFG_ANALYSIS_UNKNOWN_MIN, COL_CFG_ANALYSIS_NOTE).Value = "不明入出金の確認対象額。シフト探索には影響しません。"
        .Range(.Cells(ROW_CFG_ANALYSIS_MIN_AMOUNT, COL_CFG_ANALYSIS_LABEL), _
               .Cells(ROW_CFG_ANALYSIS_UNKNOWN_MIN, COL_CFG_ANALYSIS_LABEL)).Font.Bold = True
        .Range(.Cells(ROW_CFG_ANALYSIS_MIN_AMOUNT, COL_CFG_ANALYSIS_LABEL), _
               .Cells(ROW_CFG_ANALYSIS_UNKNOWN_MIN, COL_CFG_ANALYSIS_VALUE)).Borders.LineStyle = xlContinuous
        .Range(.Cells(ROW_CFG_ANALYSIS_MIN_AMOUNT, COL_CFG_ANALYSIS_VALUE), _
               .Cells(ROW_CFG_ANALYSIS_UNKNOWN_MIN, COL_CFG_ANALYSIS_VALUE)).Interior.Color = RGB(239, 246, 255)
        .Range(.Cells(ROW_CFG_ANALYSIS_MIN_AMOUNT, COL_CFG_ANALYSIS_NOTE), _
               .Cells(ROW_CFG_ANALYSIS_UNKNOWN_MIN, COL_CFG_ANALYSIS_NOTE)).WrapText = True
        .Range(.Cells(ROW_CFG_ANALYSIS_MIN_AMOUNT, COL_CFG_ANALYSIS_NOTE), _
               .Cells(ROW_CFG_ANALYSIS_UNKNOWN_MIN, COL_CFG_ANALYSIS_NOTE)).Font.Size = 9
        .Range(.Cells(ROW_CFG_ANALYSIS_MIN_AMOUNT, COL_CFG_ANALYSIS_NOTE), _
               .Cells(ROW_CFG_ANALYSIS_UNKNOWN_MIN, COL_CFG_ANALYSIS_NOTE)).Font.Color = RGB(71, 85, 105)
        .Cells(ROW_CFG_ANALYSIS_MIN_AMOUNT, COL_CFG_ANALYSIS_VALUE).NumberFormatLocal = "#,##0.########"
        .Cells(ROW_CFG_ANALYSIS_DAY_WINDOW, COL_CFG_ANALYSIS_VALUE).NumberFormatLocal = "0"
        .Cells(ROW_CFG_ANALYSIS_ABS_TOLERANCE, COL_CFG_ANALYSIS_VALUE).NumberFormatLocal = "#,##0.########"
        .Cells(ROW_CFG_ANALYSIS_UNKNOWN_MIN, COL_CFG_ANALYSIS_VALUE).NumberFormatLocal = "#,##0.########"
        '標準書式なら、利用者が3%と入力した時にExcelの百分率書式が保持され、内部値0.03を判別できる。
        .Cells(ROW_CFG_ANALYSIS_RATE_TOLERANCE, COL_CFG_ANALYSIS_VALUE).NumberFormat = "General"
        .Rows("4:8").RowHeight = 32
        .Rows("9:17").RowHeight = 28
        .Range("B4:H17").VerticalAlignment = xlCenter
    End With
    stageName = "操作ボタン"
    ResetUIButtonSequence
    RebuildConfigOperationPanel ws
    With ws.Range("B32:D36")
        .Interior.Color = RGB(242, 242, 242)
        .Borders.LineStyle = xlContinuous
        .WrapText = True
        .VerticalAlignment = xlTop
    End With
    MergeAndFormat ws.Range("B32:D32"), "運用メモ"
    With ws.Range("B32:D32")
        .Interior.Color = RGB(51, 65, 85)
        .Font.Color = RGB(255, 255, 255)
        .Font.Bold = True
        .HorizontalAlignment = xlCenter
        .VerticalAlignment = xlCenter
    End With
    MergeAndFormat ws.Range("B33:D33"), "1. 案件開始：相続開始日と残高表示年を入力します。残高欄は自動更新されます。"
    MergeAndFormat ws.Range("B34:D34"), "2. 日常入力：一口座ずつ登録し、訂正は［登録済み口座］から開きます。"
    MergeAndFormat ws.Range("B35:D35"), "3. 確認：取扱店コードと分析候補を確認し、必要な判断メモを残します。"
    MergeAndFormat ws.Range("B36:D36"), "4. 完了：［最終出力］は最新データで再作成され、内部IDを含みません。"
    ws.Rows("33:36").RowHeight = 34

    '口座開設日・口座解約日用の元号マスタ。
    '「1.53.5.6」のような数字入力をここで管理する。新元号はこの表へ行を追加すれば対応できる。
    stageName = "元号マスタ"
    BuildEraMasterOnConfig ws

    stageName = "表示寸法"
    ApplyConfigSheetLayout ws
    stageName = "操作範囲"
    RestoreToolSheetScrollArea ws
    stageName = "固定表示"
    SafeFreezeSheetAt ws, "B4", 90
    Exit Sub
EH:
    Err.Raise Err.Number, "BuildConfigSheetCore(" & stageName & ")", _
              Err.Source & " / " & Err.Description

End Sub

Private Sub ApplyConfigHeaderLayout(ByVal ws As Worksheet)
    '操作帯は上2行、設定区分見出しは3行目へ固定する。
    '旧版の2行目見出しを必ず解除し、表示復旧でも同じ配置へ収束させる。
    If ws Is Nothing Then Exit Sub
    With ws
        .Range("B1:H3").UnMerge
        .Range("B1:H3").ClearContents
        .Range("B1:H3").ClearFormats
        With .Range("B1:H3")
            .Font.Name = "Yu Gothic UI"
            .Font.Size = 10
        End With
        MergeAndFormat .Range("B3:D3"), "案件・入力設定"
        .Range("B3:D3").Interior.Color = RGB(239, 246, 255)
        .Range("B3:D3").Font.Color = RGB(30, 64, 175)
        .Range("B3:D3").Font.Bold = True
        .Range("B3:D3").Font.Size = 15
        .Range("B3:D3").HorizontalAlignment = xlCenter
        MergeAndFormat .Range("F3:H3"), "取引分析設定"
        .Range("F3:H3").Interior.Color = RGB(239, 246, 255)
        .Range("F3:H3").Font.Color = RGB(30, 64, 175)
        .Range("F3:H3").Font.Bold = True
        .Range("F3:H3").Font.Size = 13
        .Range("F3:H3").HorizontalAlignment = xlCenter
    End With
End Sub

Private Sub GetConfigOperationButtonBounds( _
        ByVal ws As Worksheet, _
        ByVal buttonIndex As Long, _
        ByRef leftValue As Double, _
        ByRef topValue As Double, _
        ByRef widthValue As Double, _
        ByRef heightValue As Double)
    '作成と検査が同じ計算を共有し、列幅変更やDPI丸めで期待位置を二重管理しない。
    Dim panelArea As Range
    Dim totalWidth As Double
    Dim toolbarRow As Long, toolbarColumn As Long
    If ws Is Nothing Then _
        Err.Raise vbObjectError + 1111, "GetConfigOperationButtonBounds", _
                  "設定パネルを取得できません。"
    If buttonIndex < 1 Or buttonIndex > CONFIG_TOOLBAR_BUTTON_COUNT Then _
        Err.Raise vbObjectError + 1112, "GetConfigOperationButtonBounds", _
                  "設定パネルのボタン番号が範囲外です。"

    Set panelArea = ws.Range("B1:H2")
    widthValue = (CDbl(panelArea.Width) - _
                  (CONFIG_TOOLBAR_BUTTONS_PER_ROW - 1) * CONFIG_TOOLBAR_BUTTON_GAP) / _
                  CONFIG_TOOLBAR_BUTTONS_PER_ROW
    If widthValue > CONFIG_TOOLBAR_BUTTON_WIDTH Then widthValue = CONFIG_TOOLBAR_BUTTON_WIDTH
    totalWidth = CONFIG_TOOLBAR_BUTTONS_PER_ROW * widthValue + _
                 (CONFIG_TOOLBAR_BUTTONS_PER_ROW - 1) * CONFIG_TOOLBAR_BUTTON_GAP

    toolbarRow = 1 + ((buttonIndex - 1) \ CONFIG_TOOLBAR_BUTTONS_PER_ROW)
    toolbarColumn = (buttonIndex - 1) Mod CONFIG_TOOLBAR_BUTTONS_PER_ROW
    heightValue = CONFIG_TOOLBAR_BUTTON_HEIGHT
    leftValue = CDbl(panelArea.Left) + (CDbl(panelArea.Width) - totalWidth) / 2# + _
                toolbarColumn * (widthValue + CONFIG_TOOLBAR_BUTTON_GAP)
    topValue = CDbl(ws.Rows(toolbarRow).Top) + _
               (CDbl(ws.Rows(toolbarRow).Height) - CONFIG_TOOLBAR_BUTTON_HEIGHT) / 2#
End Sub

Private Function ConfigOperationActionNames() As Variant
    '作成・保護・診断で同じ機能集合を使い、ボタン定義の重複管理をなくす。
    ConfigOperationActionNames = Array( _
        "ShowInputSheet", "BuildBalanceInputFields", "RestoreToolFormatting", _
        "ShowCandidateSheets", _
        "ImportExternal13ColumnWorkbook", "ImportCommonDataWorkbook", _
        "InitializeToolData")
End Function

Public Sub RebuildConfigOperationPanel(ByVal ws As Worksheet)
    '設定値には触れず、操作図形だけを上部の固定2行へ再構築する。
    '表示復旧からも呼び出し、DPI変更や旧版の手動移動を残さない。
    Dim captions As Variant, actions As Variant, styles As Variant
    Dim buttonIndex As Long
    Dim leftValue As Double, topValue As Double
    Dim widthValue As Double, heightValue As Double
    Dim panelProblems As String
    If ws Is Nothing Then Exit Sub
    ResetUIButtonSequence
    DeleteToolShapesVerified ws, False
    ApplyConfigSheetLayout ws
    ApplyConfigHeaderLayout ws
    With ws.Range("B19:D19")
        .UnMerge
        .ClearContents
        .ClearFormats
        .Font.Name = "Yu Gothic UI"
        .Font.Size = 10
    End With

    captions = Array( _
        "入力へ戻る", "残高欄を再生成", "表示を整え直す", _
        "入力候補を整理", "資金操作表を取込", "共通候補を取込", "案件データを初期化")
    actions = ConfigOperationActionNames()
    styles = Array("soft", "primary", "neutral", _
                   "tool", "tool", "tool", "danger")

    For buttonIndex = 1 To CONFIG_TOOLBAR_BUTTON_COUNT
        GetConfigOperationButtonBounds ws, buttonIndex, leftValue, topValue, _
                                       widthValue, heightValue
        AddUIButton ws, leftValue, topValue, widthValue, heightValue, _
                    CStr(captions(buttonIndex - 1)), CStr(actions(buttonIndex - 1)), _
                    CStr(styles(buttonIndex - 1)), False
    Next buttonIndex
    LockToolShapes ws, False

End Sub

Private Sub FinalizeConfigSheetAfterMasters()
    Dim ws As Worksheet
    Dim problems As String
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim terminalEventsStopped As Boolean, terminalEventDetail As String
    On Error GoTo EH
    Set ws = GetSheet(SH_CONFIG)

    '入力規則を保護前に検査する。従来は設定シートを先に保護したため、
    '後続のValidation.Addが失敗しても見逃す順序依存があった。
    CheckConfigValidationStructure problems
    CheckPanelActionSet ws, ConfigOperationActionNames(), _
                        "設定パネル", problems
    CheckConfigMerge ws, "B3", "B3:D3", "案件・入力見出し", problems
    CheckConfigMerge ws, "F3", "F3:H3", "分析見出し", problems
    CheckConfigMerge ws, "B32", "B32:D32", "運用メモ見出し", problems
    CheckConfigMerge ws, "B33", "B33:D33", "運用メモ1", problems
    CheckConfigMerge ws, "B34", "B34:D34", "運用メモ2", problems
    CheckConfigMerge ws, "B35", "B35:D35", "運用メモ3", problems
    CheckConfigMerge ws, "B36", "B36:D36", "運用メモ4", problems
    CheckConfigMerge ws, ws.Cells(ERA_MASTER_TITLE_ROW, ERA_COL_CODE).Address(False, False), _
                     ws.Range(ws.Cells(ERA_MASTER_TITLE_ROW, ERA_COL_CODE), _
                              ws.Cells(ERA_MASTER_TITLE_ROW, ERA_COL_ENABLED)).Address(False, False), _
                     "元号マスタ見出し", problems
    CheckConfigMerge ws, ws.Cells(ERA_MASTER_MAX_ROW + 2, ERA_COL_CODE).Address(False, False), _
                     ws.Range(ws.Cells(ERA_MASTER_MAX_ROW + 2, ERA_COL_CODE), _
                              ws.Cells(ERA_MASTER_MAX_ROW + 3, ERA_COL_ENABLED)).Address(False, False), _
                     "元号入力例", problems
    If StrComp(CellText(ws.Range("B3").Value), "案件・入力設定", vbBinaryCompare) <> 0 Then _
        problems = problems & "・設定シートの案件・入力見出しが不正です。" & vbCrLf
    If StrComp(CellText(ws.Range("F3").Value), "取引分析設定", vbBinaryCompare) <> 0 Then _
        problems = problems & "・設定シートの分析見出しが不正です。" & vbCrLf
    If Len(problems) > 0 Then _
        Err.Raise vbObjectError + 1102, "FinalizeConfigSheetAfterMasters", _
                  "設定シートの完成検査に失敗しました。" & vbCrLf & problems

    ProtectConfigSheet True
    If Not ws.ProtectContents Or Not ws.ProtectDrawingObjects Then _
        Err.Raise vbObjectError + 1103, "FinalizeConfigSheetAfterMasters", _
                  "設定シートのセルまたはボタンを保護できません。"
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    If IsSetupRecoveryFatalError(errorNumber, errorSource) Then
        On Error Resume Next
        Call SetApplicationEnableEventsExact(False, terminalEventDetail)
        Call SetApplicationEnableEventsExact(False, terminalEventDetail)
        On Error GoTo 0
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    errorDescription = errorSource & " / " & errorDescription
    Err.Raise errorNumber, "FinalizeConfigSheetAfterMasters", errorDescription
End Sub

Private Sub CheckConfigMerge(ByVal ws As Worksheet, ByVal anchorAddress As String, _
                             ByVal expectedAddress As String, ByVal labelText As String, _
                             ByRef problems As String)
    Dim mergedArea As Range
    On Error GoTo EH
    Set mergedArea = EffectiveRange(ws.Range(anchorAddress))
    If mergedArea Is Nothing Then
        problems = problems & "・設定シートの" & labelText & "の結合範囲が不正です。" & vbCrLf
    ElseIf StrComp(mergedArea.Address(False, False), expectedAddress, vbTextCompare) <> 0 Then
        problems = problems & "・設定シートの" & labelText & "の結合範囲が不正です。" & vbCrLf
    End If
    Exit Sub
EH:
    problems = problems & "・設定シートの" & labelText & "を確認できません。" & vbCrLf
End Sub

Private Sub ApplyConfigSheetLayout(ByVal ws As Worksheet)
    '設定と分析条件を一画面で比較できる幅に固定する。
    '下部の元号マスタも同じ列を使うため、日付列Eだけは判読可能な幅を残す。
    Dim r As Long
    If ws Is Nothing Then Exit Sub
    With ws
        .Columns("A:A").ColumnWidth = 3
        .Columns("B:B").ColumnWidth = 18
        .Columns("C:C").ColumnWidth = 26
        .Columns("D:D").ColumnWidth = 22
        .Columns("E:E").ColumnWidth = 12
        .Columns("F:F").ColumnWidth = 20
        .Columns("G:G").ColumnWidth = 14
        .Columns("H:H").ColumnWidth = 22
        .Rows("1:2").RowHeight = 32
        .Rows(3).RowHeight = 28
        .Range("B4:H17").WrapText = True
        .Rows("4:17").AutoFit
        For r = 4 To 8
            If .Rows(r).RowHeight < 32 Then .Rows(r).RowHeight = 32
        Next r
        For r = 9 To 17
            If .Rows(r).RowHeight < 28 Then .Rows(r).RowHeight = 28
        Next r
        .Rows("21:28").RowHeight = 19
        .Rows(32).RowHeight = 24
        .Rows("33:36").RowHeight = 34
        .Range("B4:H17").VerticalAlignment = xlCenter
    End With
End Sub

Private Sub BuildEraMasterOnConfig(ByVal ws As Worksheet)
    '設定シート内に、開設日・解約日用の元号コード表を作る。
    '利用者はここを編集するだけで、新元号や元号境界日の変更に対応できる。
    If ws Is Nothing Then Exit Sub

    With ws.Range(ws.Cells(ERA_MASTER_TITLE_ROW, ERA_COL_CODE), ws.Cells(ERA_MASTER_TITLE_ROW, ERA_COL_ENABLED))
        .UnMerge
        .Merge
        .Value = "元号マスタ（開設日・解約日用）"
        .Font.Bold = True
        .Font.Size = 12
        .Font.Color = RGB(30, 64, 175)
        .Interior.Color = RGB(239, 246, 255)
        .HorizontalAlignment = xlCenter
        .VerticalAlignment = xlCenter
        .Borders.LineStyle = xlContinuous
        .Borders.Color = RGB(191, 219, 254)
    End With

    SetRowValues ws.Cells(ERA_MASTER_HEADER_ROW, ERA_COL_CODE), _
        Array("元号コード", "元号名", "略称", "開始日", "終了日", "有効")
    With ws.Range(ws.Cells(ERA_MASTER_HEADER_ROW, ERA_COL_CODE), ws.Cells(ERA_MASTER_HEADER_ROW, ERA_COL_ENABLED))
        .Font.Bold = True
        .Font.Color = RGB(255, 255, 255)
        .Interior.Color = RGB(37, 99, 235)
        .HorizontalAlignment = xlCenter
        .VerticalAlignment = xlCenter
        .Borders.LineStyle = xlContinuous
        .Borders.Color = RGB(147, 197, 253)
    End With

    SetRowValues ws.Cells(ERA_MASTER_FIRST_ROW, ERA_COL_CODE), Array(1, "昭和", "S", DateSerial(1926, 12, 25), DateSerial(1989, 1, 7), "TRUE")
    SetRowValues ws.Cells(ERA_MASTER_FIRST_ROW + 1, ERA_COL_CODE), Array(2, "平成", "H", DateSerial(1989, 1, 8), DateSerial(2019, 4, 30), "TRUE")
    SetRowValues ws.Cells(ERA_MASTER_FIRST_ROW + 2, ERA_COL_CODE), Array(3, "令和", "R", DateSerial(2019, 5, 1), "", "TRUE")

    With ws.Range(ws.Cells(ERA_MASTER_FIRST_ROW, ERA_COL_CODE), ws.Cells(ERA_MASTER_MAX_ROW, ERA_COL_ENABLED))
        .Borders.LineStyle = xlContinuous
        .Borders.Color = RGB(226, 232, 240)
        .Interior.Color = RGB(255, 255, 255)
        .VerticalAlignment = xlCenter
    End With
    ws.Range(ws.Cells(ERA_MASTER_FIRST_ROW, ERA_COL_START), ws.Cells(ERA_MASTER_MAX_ROW, ERA_COL_END)).NumberFormatLocal = "yyyy/m/d"
    ws.Range(ws.Cells(ERA_MASTER_FIRST_ROW, ERA_COL_CODE), ws.Cells(ERA_MASTER_MAX_ROW, ERA_COL_CODE)).HorizontalAlignment = xlCenter
    ws.Range(ws.Cells(ERA_MASTER_FIRST_ROW, ERA_COL_ENABLED), ws.Cells(ERA_MASTER_MAX_ROW, ERA_COL_ENABLED)).HorizontalAlignment = xlCenter

    ws.Columns("B:B").ColumnWidth = 24
    ws.Columns("C:C").ColumnWidth = 18
    ws.Columns("D:D").ColumnWidth = 12
    ws.Columns("E:F").ColumnWidth = 14
    ws.Columns("G:G").ColumnWidth = 10
    ws.Rows(ERA_MASTER_TITLE_ROW).RowHeight = 24
    ws.Rows(ERA_MASTER_HEADER_ROW & ":" & ERA_MASTER_MAX_ROW).RowHeight = 22

    With ws.Range(ws.Cells(ERA_MASTER_MAX_ROW + 2, ERA_COL_CODE), ws.Cells(ERA_MASTER_MAX_ROW + 3, ERA_COL_ENABLED))
        .UnMerge
        .Merge
        .Value = "開設日・解約日は 1.53.5.6=昭和53年5月6日、2.31.4.30=平成31年4月30日、3.1.5.1=令和元年5月1日。新元号は元号マスタに行を追加します。"
        .Font.Size = 9
        .Font.Color = RGB(71, 85, 105)
        .Interior.Color = RGB(248, 250, 252)
        .WrapText = True
        .VerticalAlignment = xlTop
        .Borders.LineStyle = xlContinuous
        .Borders.Color = RGB(226, 232, 240)
    End With
    ws.Rows((ERA_MASTER_MAX_ROW + 2) & ":" & (ERA_MASTER_MAX_ROW + 3)).RowHeight = 31
End Sub

Public Sub BuildMasterSheets()
    Dim ws As Worksheet
    On Error GoTo EH
    Set ws = GetSheet(SH_TEKIYO)
    ResetWorksheet ws
    ws.Range("A1").Value = "摘要候補": ws.Range("A1").Font.Bold = True
    ws.Range("D1").Value = "区分": ws.Range("D1").Font.Bold = True
    ws.Range("A2:A16").Value = Application.Transpose(Array("ATM", "振込", "振替", "手数料", "利息", "カード", "公共料金", "年金", "給与", "預入", "払戻", "引落", "口座振替", "同上", "その他"))
    ws.Columns("A:A").ColumnWidth = 20
    ws.Columns("A:D").NumberFormatLocal = "@"
    ws.Columns("D:D").Hidden = True
    ResetName NM_LST_TEKIYO, ws.Range("A2:A16")
    Set ws = GetSheet(SH_ACCOUNT_TYPE)
    ResetWorksheet ws
    ws.Range("A1").Value = "科目候補": ws.Range("A1").Font.Bold = True
    ws.Range("D1").Value = "区分": ws.Range("D1").Font.Bold = True
    ws.Range("A2:A45").Value = Application.Transpose(Array( _
        "普通", "普通預金", "通常", "通常貯金", "当座", "当座預金", _
        "定期", "定期預金", "定額", "定額貯金", "貯蓄", "貯蓄預金", "通常貯蓄", "通常貯蓄貯金", _
        "通知", "通知預金", "納税準備", "納税準備預金", _
        "積立定期", "積立定期預金", "大口定期", "大口定期預金", "期日指定定期", "変動金利定期", "定期積金", _
        "総合", "総合口座", "振替", "振替口座", _
        "担保定額", "担保定期", "自動積立定額", "自動積立定期", _
        "財形", "財形貯蓄", "財産形成", "財産形成定額", "財産形成年金", "財産形成住宅", _
        "外貨普通", "外貨定期", "外貨預金", "債券", "その他"))
    ws.Columns("A:A").ColumnWidth = 22
    ws.Columns("A:D").NumberFormatLocal = "@"
    ws.Columns("D:D").Hidden = True
    ResetName NM_LST_ACCOUNT_TYPE, ws.Range("A2:A45")
    Set ws = GetSheet(SH_INPUT_MODE)
    ResetWorksheet ws
    ws.Range("A1").Value = "入力モード": ws.Range("A1").Font.Bold = True
    ws.Range("A2:A7").Value = Application.Transpose(Array(MODE_NORMAL, MODE_NO_TIME, MODE_NO_MACHINE, MODE_NO_TEKIYO, MODE_WITH_OTHER, MODE_SIMPLE))
    ws.Columns("A:A").ColumnWidth = 18
    ResetName NM_LST_INPUT_MODE, ws.Range("A2:A7")

    Set ws = GetSheet(SH_YEAR_MODE)
    ResetWorksheet ws
    ws.Range("A1").Value = "年入力方式": ws.Range("A1").Font.Bold = True
    ws.Range("A2:A3").Value = Application.Transpose(Array(YEAR_MODE_WAREKI, YEAR_MODE_WESTERN2))
    ws.Columns("A:A").ColumnWidth = 18
    ResetName NM_LST_YEAR_MODE, ws.Range("A2:A3")

    Set ws = GetSheet(SH_DISPLAY_OPTION)
    ResetWorksheet ws
    ws.Range("A1").Value = "表示切替": ws.Range("A1").Font.Bold = True
    ws.Range("A2:A3").Value = Application.Transpose(Array(DISPLAY_ON, DISPLAY_OFF))
    ws.Columns("A:A").ColumnWidth = 16
    ResetName NM_LST_DISPLAY_OPTION, ws.Range("A2:A3")

    Set ws = GetSheet(SH_POST_KEEP)
    ResetWorksheet ws
    ws.Range("A1").Value = "転記後に残す口座情報": ws.Range("A1").Font.Bold = True
    '口座番号まで残す選択肢は、直後の再登録を重複エラーにするため画面から廃止する。
    '定数と処理分岐は旧ブック互換のため残すが、設定値としては採用しない。
    ws.Range("A2:A5").Value = Application.Transpose(Array(KEEP_NONE, KEEP_PERSON_ONLY, KEEP_BANK_BRANCH, KEEP_BANK_BRANCH_PERSON_TYPE))
    ws.Columns("A:A").ColumnWidth = 36
    ResetName NM_LST_POST_KEEP, ws.Range("A2:A5")

    Set ws = GetSheet(SH_POST_CLEAR)
    ResetWorksheet ws
    ws.Range("A1").Value = "転記後処理": ws.Range("A1").Font.Bold = True
    ws.Range("A2:A3").Value = Application.Transpose(Array(POST_CLEAR, POST_KEEP))
    ws.Columns("A:A").ColumnWidth = 16
    ResetName NM_LST_POST_CLEAR, ws.Range("A2:A3")

    Set ws = GetSheet(SH_ANALYSIS_STATUS)
    ResetWorksheet ws
    ws.Range("A1").Value = "分析確認状況": ws.Range("A1").Font.Bold = True
    ws.Range("A2:A7").Value = Application.Transpose(Array( _
        ANALYSIS_STATUS_UNREVIEWED, ANALYSIS_STATUS_SHIFT_CONFIRMED, _
        ANALYSIS_STATUS_SOURCE_CONFIRMED, ANALYSIS_STATUS_USE_CONFIRMED, _
        ANALYSIS_STATUS_EXCLUDED, ANALYSIS_STATUS_FOLLOWUP))
    'A8以下は分析表ごとの意味に合う候補だけを入力規則へ出すための内部一覧。
    ws.Range("A8:A11").Value = Application.Transpose(Array( _
        ANALYSIS_STATUS_UNREVIEWED, ANALYSIS_STATUS_SHIFT_CONFIRMED, _
        ANALYSIS_STATUS_EXCLUDED, ANALYSIS_STATUS_FOLLOWUP))
    ws.Range("A12:A15").Value = Application.Transpose(Array( _
        ANALYSIS_STATUS_UNREVIEWED, ANALYSIS_STATUS_SOURCE_CONFIRMED, _
        ANALYSIS_STATUS_EXCLUDED, ANALYSIS_STATUS_FOLLOWUP))
    ws.Range("A16:A19").Value = Application.Transpose(Array( _
        ANALYSIS_STATUS_UNREVIEWED, ANALYSIS_STATUS_USE_CONFIRMED, _
        ANALYSIS_STATUS_EXCLUDED, ANALYSIS_STATUS_FOLLOWUP))
    ws.Columns("A:A").ColumnWidth = 20
    ws.Columns("A:A").NumberFormatLocal = "@"
    ResetName NM_LST_ANALYSIS_STATUS, ws.Range("A2:A7")
    ResetName NM_LST_ANALYSIS_SHIFT_STATUS, ws.Range("A8:A11")
    ResetName NM_LST_ANALYSIS_SOURCE_STATUS, ws.Range("A12:A15")
    ResetName NM_LST_ANALYSIS_USE_STATUS, ws.Range("A16:A19")

    BuildCandidateSheets True
    ProtectAllCandidateSheets True
    Exit Sub
EH:
    Err.Raise Err.Number, "BuildMasterSheets", Err.Description
End Sub

Public Sub ApplyConfigValidations(ByVal protectAfter As Boolean)
    Dim ws As Worksheet
    Dim problems As String
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim terminalEventsStopped As Boolean, terminalEventDetail As String
    On Error GoTo EH
    Set ws = GetSheet(SH_CONFIG)
    '設定シートの入力規則は、全マスタと定義名が揃ってから保護前に作る。
    '再セットアップや単独再生成後でも、ここで明示的に保護を解除して順序依存をなくす。
    ws.Unprotect Password:=TOOL_PASSWORD
    ApplyValidationInputOnly GetCfgCell(ROW_CFG_INHERITANCE_DATE), xlIMEModeOff, _
                             "相続開始日（必須）", "例：2026/8/23。残高欄と帳票の基準日になります。"
    ApplyValidationInputOnly ws.Range( _
        GetCfgCell(ROW_CFG_BAL_START_YEAR), GetCfgCell(ROW_CFG_YEAR_ADD)), _
        xlIMEModeOff, "年の設定", "西暦の整数で入力します。変更後は残高欄が自動更新されます。"
    ApplyValidationList GetCfgCell(ROW_CFG_INPUT_MODE), NM_LST_INPUT_MODE, xlIMEModeOff, False, _
                        "入力モード", "Tab移動で使用する明細項目を選びます。"
    ApplyValidationList GetCfgCell(ROW_CFG_YEAR_MODE), NM_LST_YEAR_MODE, xlIMEModeOff, False, _
                        "年入力方式", "年2桁を和暦として扱うか、西暦として扱うかを選びます。"
    ApplyValidationList GetCfgCell(ROW_CFG_RELATIONSHIP), NM_LST_DISPLAY_OPTION, xlIMEModeOff, False, _
                        "続柄の表示", "非表示にしても入力済みの続柄は保持されます。"
    ApplyValidationList GetCfgCell(ROW_CFG_SHOW_INHERITANCE_ROW), NM_LST_DISPLAY_OPTION, xlIMEModeOff, False
    ApplyValidationList GetCfgCell(ROW_CFG_SHOW_OPEN_DATE_ROW), NM_LST_DISPLAY_OPTION, xlIMEModeOff, False
    ApplyValidationList GetCfgCell(ROW_CFG_SHOW_CLOSE_DATE_ROW), NM_LST_DISPLAY_OPTION, xlIMEModeOff, False
    ApplyValidationList GetCfgCell(ROW_CFG_SHOW_BALANCE_ROWS), NM_LST_DISPLAY_OPTION, xlIMEModeOff, False
    ApplyValidationList GetCfgCell(ROW_CFG_POST_KEEP), NM_LST_POST_KEEP, xlIMEModeOff, False
    ApplyValidationList GetCfgCell(ROW_CFG_POST_TX), NM_LST_POST_CLEAR, xlIMEModeOff, False
    ApplyValidationList GetCfgCell(ROW_CFG_POST_BAL), NM_LST_POST_CLEAR, xlIMEModeOff, False
    ApplyValidationInputOnly ws.Range( _
        ws.Cells(ROW_CFG_ANALYSIS_MIN_AMOUNT, COL_CFG_ANALYSIS_VALUE), _
        ws.Cells(ROW_CFG_ANALYSIS_UNKNOWN_MIN, COL_CFG_ANALYSIS_VALUE)), _
        xlIMEModeOff, "分析条件", "数字で入力します。条件変更後は帳票・分析を更新してください。"
    CheckConfigValidationStructure problems
    If Len(problems) > 0 Then _
        Err.Raise vbObjectError + 1104, "ApplyConfigValidations", _
                  "設定シートの入力規則を作成後に確認できませんでした。" & vbCrLf & problems
    If protectAfter Then ProtectConfigSheet True
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    If IsSetupRecoveryFatalError(errorNumber, errorSource) Then
        On Error Resume Next
        Call SetApplicationEnableEventsExact(False, terminalEventDetail)
        Call SetApplicationEnableEventsExact(False, terminalEventDetail)
        On Error GoTo 0
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    On Error Resume Next
    If protectAfter And Not ws Is Nothing Then EmergencyProtectToolSheet ws
    On Error GoTo 0
    Err.Raise errorNumber, "ApplyConfigValidations", errorSource & " / " & errorDescription
End Sub
Public Sub BuildInputSheet()
    Dim ws As Worksheet
    On Error GoTo EH
    Set ws = GetSheet(SH_INPUT)
    If ws Is Nothing Then Err.Raise vbObjectError + 1201, "BuildInputSheet", "入力シートを取得できません。"
    ResetWorksheet ws
    With ws
        With .Range("A1:W" & CStr(TX_LAST_ROW))
            .Font.Name = "Yu Gothic UI"
            .Font.Size = 11
            .Font.Color = RGB(15, 23, 42)
            .Interior.Color = RGB(255, 255, 255)
        End With
        .Rows("1:" & CStr(TX_LAST_ROW)).RowHeight = 20
        .Columns("A:A").ColumnWidth = 1.5
        .Columns("B:B").ColumnWidth = INPUT_WIDTH_B
        .Columns("C:C").ColumnWidth = INPUT_WIDTH_C
        .Columns("D:D").ColumnWidth = INPUT_WIDTH_D
        .Columns("E:E").ColumnWidth = INPUT_WIDTH_E
        .Columns("F:G").ColumnWidth = INPUT_WIDTH_F_TO_G
        .Columns("H:H").ColumnWidth = INPUT_WIDTH_H
        .Columns("I:I").ColumnWidth = INPUT_WIDTH_I
        .Columns("J:J").ColumnWidth = INPUT_WIDTH_J
        .Columns("K:K").ColumnWidth = INPUT_WIDTH_K
        'L:Vは詳細・残高専用。通常時は隠し、明細表A:Kだけで作業できるようにする。
        .Columns("L:P").ColumnWidth = INPUT_WIDTH_L_TO_P
        .Columns("Q:V").ColumnWidth = INPUT_WIDTH_Q_TO_V
        .Columns("W:W").ColumnWidth = 1.5

        MergeAndFormat .Range("B2:C2"), "資金操作表｜入力"
        With .Range("B2:C2")
            .Interior.Color = RGB(30, 41, 59)
            .Font.Color = RGB(255, 255, 255)
            .Font.Bold = True
            .Font.Size = 11
            .HorizontalAlignment = xlCenter
            .VerticalAlignment = xlCenter
            .Borders.LineStyle = xlContinuous
            .Borders.Color = RGB(30, 41, 59)
        End With
        .Rows("2:3").RowHeight = 29

        MergeAndFormat .Range("B4:K4"), _
                       "1 口座情報 → 2 取引入力 → 3 登録 → 帳票・分析を更新　｜　* 必須"
        FormatHeader .Range("B4:K4")
        .Range("B5").Value = "銀行名 *": MergeAndFormat .Range("C5:D5"), ""
        .Range("E5").Value = "支店名": MergeAndFormat .Range("F5:G5"), ""
        .Range("H5").Value = "氏名 *": MergeAndFormat .Range("I5:K5"), ""
        .Range("B6").Value = "科目 *": MergeAndFormat .Range("C6:D6"), ""
        .Range("E6").Value = "口座番号 *": MergeAndFormat .Range("F6:G6"), ""
        .Range("H6").Value = "続柄": MergeAndFormat .Range("I6:K6"), ""
        .Range("B7").Value = "開設日": MergeAndFormat .Range("C7:E7"), ""
        .Range("F7").Value = "解約日": MergeAndFormat .Range("G7:I7"), ""
        MergeAndFormat .Range("J7:K7"), "和暦例 3.1.5.1"
        .Range("B5:K7").Borders.LineStyle = xlContinuous
        .Range("B5:K7").Borders.Color = RGB(203, 213, 225)
        .Range("B5,E5,H5,B6,E6,H6,B7,F7").Font.Bold = True
        .Range("B5,E5,H5,B6,E6,H6,B7,F7").Interior.Color = RGB(241, 245, 249)
        .Range("B5,E5,H5,B6,E6,H6,B7,F7").Font.Color = RGB(30, 64, 175)
        .Range("C5:D5,F5:G5,I5:K5,C6:D6,F6:G6,I6:K6,C7:E7,G7:I7").Interior.Color = RGB(255, 255, 255)
        .Range("C5:D5,F5:G5,I5:K5,C6:D6,F6:G6,I6:K6,C7:E7,G7:I7").Font.Color = RGB(15, 23, 42)
        .Range("C5:D5,F5:G5,I5:K5,C6:D6,F6:G6,I6:K6").NumberFormatLocal = "@"
        .Range("C7:E7,G7:I7").NumberFormatLocal = "yyyy/m/d"
        .Range("J7:K7").Font.Size = 9
        .Range("J7:K7").Font.Color = RGB(71, 85, 105)
        .Range("J7:K7").Interior.Color = RGB(248, 250, 252)
        .Range("J7:K7").HorizontalAlignment = xlCenter
        FormatRequiredLabel .Range("B5")
        FormatRequiredLabel .Range("H5")
        FormatRequiredLabel .Range("B6")
        FormatRequiredLabel .Range("E6")

        '詳細・残高を開いた時だけ表示するセクション。
        MergeAndFormat .Range(.Cells(INPUT_BALANCE_HEADER_ROW, BAL_FIRST_COL), _
                              .Cells(INPUT_BALANCE_HEADER_ROW, INPUT_SCREEN_LAST_COL)), "残高入力"
        FormatHeader .Range(.Cells(INPUT_BALANCE_HEADER_ROW, BAL_FIRST_COL), _
                            .Cells(INPUT_BALANCE_HEADER_ROW, INPUT_SCREEN_LAST_COL))

        MergeAndFormat .Range(.Cells(INPUT_STATUS_ROW, BAL_FIRST_COL), _
                              .Cells(INPUT_STATUS_ROW, INPUT_SCREEN_LAST_COL)), _
                       "口座情報から入力。Tab：次項目 ／ Ctrl+Enter：登録 ／ 入力エラーへ：修正箇所に移動。"
        With EffectiveRange(ws.Range(CELL_STATUS))
            .Interior.Color = RGB(240, 253, 250)
            .Font.Color = RGB(15, 118, 110)
            .Borders.LineStyle = xlContinuous
            .Borders.Color = RGB(153, 246, 228)
            .HorizontalAlignment = xlLeft
            .VerticalAlignment = xlCenter
            .Font.Bold = True
            .WrapText = True
            .ShrinkToFit = False
            .Font.Size = 10
        End With
        .Rows(INPUT_STATUS_ROW).RowHeight = 30

        SetRowValues .Cells(TX_HEADER_ROW, COL_TX_YEAR), _
                     Array("年", "月", "日", "時刻", "出金", "入金", "取扱店", "機番", "摘要", "取引後残高")
        FormatOutputHeader .Range(.Cells(TX_HEADER_ROW, COL_TX_YEAR), _
                                  .Cells(TX_HEADER_ROW, COL_TX_BALANCE))
        With .Range(.Cells(TX_HEADER_ROW, COL_TX_YEAR), _
                    .Cells(TX_HEADER_ROW, COL_TX_BALANCE))
            .Interior.Color = RGB(30, 41, 59)
            .Font.Color = RGB(255, 255, 255)
            .Borders.Color = RGB(51, 65, 85)
        End With

        '10,000行をセル行単位で書式設定せず、範囲・小分けバッチで処理する。
        RestoreAllTransactionRowStyles ws
        .Rows(TX_FIRST_ROW & ":" & TX_LAST_ROW).RowHeight = 24
        .Range(.Cells(TX_FIRST_ROW, COL_TX_OTHER), .Cells(TX_LAST_ROW, COL_TX_OTHER)).WrapText = False
        .Range(.Cells(TX_FIRST_ROW, COL_TX_TIME), .Cells(TX_LAST_ROW, COL_TX_TIME)).NumberFormatLocal = "@"
        .Range(.Cells(TX_FIRST_ROW, COL_TX_TIME), .Cells(TX_LAST_ROW, COL_TX_TIME)).HorizontalAlignment = xlRight
        .Range(.Cells(TX_FIRST_ROW, COL_TX_SHOP), .Cells(TX_LAST_ROW, COL_TX_MACHINE)).NumberFormatLocal = "@"
        .Range(.Cells(TX_FIRST_ROW, COL_TX_TEKIYO), .Cells(TX_LAST_ROW, COL_TX_TEKIYO)).NumberFormatLocal = "@"
        .Range(.Cells(TX_FIRST_ROW, COL_TX_WITHDRAW), .Cells(TX_LAST_ROW, COL_TX_DEPOSIT)).NumberFormatLocal = "#,##0.########"
        .Range(.Cells(TX_FIRST_ROW, COL_TX_YEAR), .Cells(TX_LAST_ROW, COL_TX_DAY)).NumberFormatLocal = "0"
    End With
    PolishInputLayout ws
    '最終の列幅・行高が確定してから図形を置き、行高変更によるボタンずれを防ぐ。
    BuildOperationPanel ws
    BuildInputHelpCards ws
    '通常作業で使わない開設日・解約日・残高は、作成時は閉じておく。
    SetInputDetailsExpanded ws, False, False
    InvalidateDateComplementCache
    Exit Sub
EH:
    Err.Raise Err.Number, "BuildInputSheet", Err.Description
End Sub
Public Sub BuildWorkSheets(Optional ByVal initialDataHealth As String = DATA_HEALTH_NORMAL)
    Dim ws As Worksheet
    On Error GoTo EH
    Set ws = GetSheet(SH_WORK_TX)
    ResetWorksheet ws
    SetRowValues ws.Range("A1"), _
        Array("銀行名", "支店名", "氏名", "科目", "口座番号", "日付", "時刻", _
              "出金", "入金", "取扱店", "機番", "摘要欄", "残高", "続柄", _
              "口座ID", "転記回ID", "取引ID", "行種別", "入力順", "登録元", "人物ID")
    FormatOutputHeader ws.Range("A1:U1")
    ws.Columns("A:U").ColumnWidth = 14
    ws.Columns("A:E").NumberFormatLocal = "@"
    ws.Columns("F:F").NumberFormatLocal = "yyyy/m/d"
    ws.Columns("G:G").NumberFormatLocal = "hh:mm"
    ws.Columns("H:I").NumberFormatLocal = "#,##0.########"
    ws.Columns("J:L").NumberFormatLocal = "@"
    ws.Columns("M:M").NumberFormatLocal = "#,##0.########"
    ws.Columns("N:U").NumberFormatLocal = "@"
    ws.Columns("O:U").Hidden = True
    SetSheetVeryHiddenSafe ws
    Set ws = GetSheet(SH_WORK_BAL)
    ResetWorksheet ws
    SetRowValues ws.Range("A1"), Array("氏名", "銀行名", "支店名", "科目", "口座番号", "口座開設日", "口座解約日", "残高基準日", "残高見出し", "残高", "その他", "続柄", "口座ID", "転記回ID", "残高ID", "登録元", "人物ID")
    FormatOutputHeader ws.Range("A1:Q1")
    ws.Columns("A:Q").ColumnWidth = 14
    ws.Columns("A:E").NumberFormatLocal = "@"
    ws.Columns("F:H").NumberFormatLocal = "yyyy/m/d"
    ws.Columns("I:I").NumberFormatLocal = "@"
    ws.Columns("J:J").NumberFormatLocal = "#,##0.########"
    ws.Columns("K:Q").NumberFormatLocal = "@"
    ws.Columns("M:Q").Hidden = True
    SetSheetVeryHiddenSafe ws
    SetupRecordStores True, initialDataHealth
    SetupAnalysisReviewStores True
    SetupManualFlowStore True
    Set ws = GetSheet(SH_CHECK)
    ResetWorksheet ws
    SetRowValues ws.Range("A1"), Array("区分", "発生元", "内容", "記録時刻")
    FormatOutputHeader ws.Range("A1:D1")
    ws.Columns("A:A").ColumnWidth = 10
    ws.Columns("B:B").ColumnWidth = 22
    ws.Columns("C:C").ColumnWidth = 70
    ws.Columns("D:D").ColumnWidth = 20
    ws.Columns("A:C").NumberFormatLocal = "@"
    ws.Columns("D:D").NumberFormatLocal = "yyyy/m/d h:mm:ss"
    ws.Columns("C:C").WrapText = True
    ws.Columns("A:D").VerticalAlignment = xlTop
    Exit Sub
EH:
    Err.Raise Err.Number, "BuildWorkSheets", Err.Description
End Sub

Public Sub BuildOutputSheets()
    Dim ws As Worksheet
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim terminalEventsStopped As Boolean, terminalEventDetail As String
    On Error GoTo EH
    Set ws = GetSheet(SH_WORK_CASH)
    ResetWorksheet ws
    SetRowValues ws.Range("A1"), Array("銀行名", "支店名", "氏名", "科目", "口座番号", "日付", "時刻", "出金", "入金", "取扱店", "機番", "摘要欄", "残高", "口座ID", "取引ID", "行種別", "入力順")
    FormatOutputHeader ws.Range("A1:Q1")
    ws.Columns("A:Q").ColumnWidth = 14
    ws.Columns("F:F").NumberFormatLocal = "yyyy/m/d"
    ws.Columns("G:G").NumberFormatLocal = "hh:mm"
    ws.Columns("H:I").NumberFormatLocal = "#,##0.########"
    ws.Columns("E:E").NumberFormatLocal = "@"
    ws.Columns("J:K").NumberFormatLocal = "@"
    ws.Columns("M:M").NumberFormatLocal = "#,##0.########"
    ws.Columns("N:Q").Hidden = True
    AutoFitSheetSmart ws, "A:M", 8, 34
    SetSheetVeryHiddenSafe ws

    Set ws = GetSheet(SH_OUTPUT_TX)
    SetupCashAnalysisViewSheet ws
    Set ws = GetSheet(SH_OUTPUT_BAL)
    ResetWorksheet ws
    ws.Range("A1").Value = "残高推移表"
    ws.Range("A1").Font.Bold = True
    ws.Range("A1").Font.Size = 14
    ws.Columns("A:AA").ColumnWidth = 14
    AutoFitSheetSmart ws, "A:AA", 8, 34
    ProtectGeneratedOutputSheet ws, True

    Set ws = GetSheet(SH_SHOP_TARGET)
    SetupShopConversionTargetSheet ws
    FormatShopConversionTargetSheet ws

    Set ws = GetSheet(SH_OUTPUT_TX_CONVERTED)
    ResetWorksheet ws
    SetRowValues ws.Range("A1"), Array("銀行名", "支店名", "氏名", "科目", "口座番号", "日付", "時刻", "出金", "入金", "取扱店", "機番", "摘要欄", "残高", "口座ID", "取引ID", "行種別", "入力順")
    FormatOutputHeader ws.Range("A1:Q1")
    ws.Columns("A:Q").ColumnWidth = 14
    ws.Columns("F:F").NumberFormatLocal = "yyyy/m/d"
    ws.Columns("G:G").NumberFormatLocal = "hh:mm"
    ws.Columns("H:I").NumberFormatLocal = "#,##0.########"
    ws.Columns("E:E").NumberFormatLocal = "@"
    ws.Columns("J:K").NumberFormatLocal = "@"
    ws.Columns("M:M").NumberFormatLocal = "#,##0.########"
    ws.Columns("N:Q").Hidden = True
    AutoFitSheetSmart ws, "A:M", 8, 34
    ProtectGeneratedOutputSheet ws, True
    SetupTransactionAnalysisSheets False
    SetupBalanceReconciliationSheet True
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    If IsSetupRecoveryFatalError(errorNumber, errorSource) Then
        On Error Resume Next
        Call SetApplicationEnableEventsExact(False, terminalEventDetail)
        Call SetApplicationEnableEventsExact(False, terminalEventDetail)
        On Error GoTo 0
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    Err.Raise errorNumber, "BuildOutputSheets", errorDescription
End Sub

Private Sub AppendBalanceFieldRestoreIssue(ByRef restoreDetail As String, _
                                           ByVal restoreStep As String, _
                                           ByVal errorNumber As Long, _
                                           ByVal errorDescription As String)
    If errorNumber = 0 Then Exit Sub
    If Len(restoreDetail) > 0 Then restoreDetail = restoreDetail & " / "
    restoreDetail = restoreDetail & restoreStep & ": Err " & CStr(errorNumber) & _
                    " " & errorDescription
End Sub

Private Function BalanceInputAreaMergeSignature(ByVal targetRange As Range) As String
    Dim targetCell As Range, mergedArea As Range
    Dim signatureText As String
    If targetRange Is Nothing Then _
        Err.Raise vbObjectError + 1805, "BalanceInputAreaMergeSignature", _
                  "残高欄の結合確認範囲がありません。"
    signatureText = targetRange.Address(False, False, xlA1, False) & "|"
    For Each targetCell In targetRange.Cells
        If targetCell.MergeCells Then
            Set mergedArea = targetCell.MergeArea
            If targetCell.Row = mergedArea.Cells(1, 1).Row And _
               targetCell.Column = mergedArea.Cells(1, 1).Column Then _
                signatureText = signatureText & _
                                mergedArea.Address(False, False, xlA1, False) & ";"
        End If
    Next targetCell
    BalanceInputAreaMergeSignature = signatureText
End Function

Private Sub CaptureBalanceInputCellIdentity(ByVal targetRange As Range, _
                                            ByRef formulaSnapshot As Variant, _
                                            ByRef valueSnapshot As Variant, _
                                            ByRef hasFormulaSnapshot As Variant, _
                                            ByRef prefixSnapshot As Variant)
    Dim formulaValues() As Variant, cellValues() As Variant
    Dim formulaFlags() As Variant, prefixValues() As Variant
    Dim r As Long, c As Long
    If targetRange Is Nothing Then _
        Err.Raise vbObjectError + 1808, "CaptureBalanceInputCellIdentity", _
                  "残高欄の退避範囲がありません。"
    ReDim formulaValues(1 To targetRange.Rows.Count, 1 To targetRange.Columns.Count)
    ReDim cellValues(1 To targetRange.Rows.Count, 1 To targetRange.Columns.Count)
    ReDim formulaFlags(1 To targetRange.Rows.Count, 1 To targetRange.Columns.Count)
    ReDim prefixValues(1 To targetRange.Rows.Count, 1 To targetRange.Columns.Count)
    For r = 1 To targetRange.Rows.Count
        For c = 1 To targetRange.Columns.Count
            formulaValues(r, c) = targetRange.Cells(r, c).Formula
            cellValues(r, c) = targetRange.Cells(r, c).Value2
            formulaFlags(r, c) = CBool(targetRange.Cells(r, c).HasFormula)
            prefixValues(r, c) = CellText(targetRange.Cells(r, c).PrefixCharacter)
        Next c
    Next r
    formulaSnapshot = formulaValues
    valueSnapshot = cellValues
    hasFormulaSnapshot = formulaFlags
    prefixSnapshot = prefixValues
End Sub

Private Sub RestoreBalanceInputCellIdentity(ByVal targetRange As Range, _
                                            ByVal formulaSnapshot As Variant, _
                                            ByVal valueSnapshot As Variant, _
                                            ByVal hasFormulaSnapshot As Variant, _
                                            ByVal prefixSnapshot As Variant)
    Dim targetCell As Range
    Dim r As Long, c As Long
    If targetRange Is Nothing Or Not IsArray(formulaSnapshot) Or _
       Not IsArray(valueSnapshot) Or Not IsArray(hasFormulaSnapshot) Or _
       Not IsArray(prefixSnapshot) Then _
        Err.Raise vbObjectError + 1809, "RestoreBalanceInputCellIdentity", _
                  "残高欄の完全な退避値がありません。"
    For r = 1 To targetRange.Rows.Count
        For c = 1 To targetRange.Columns.Count
            Set targetCell = targetRange.Cells(r, c)
            If CBool(hasFormulaSnapshot(r, c)) Then
                targetCell.Formula = formulaSnapshot(r, c)
            ElseIf CStr(prefixSnapshot(r, c)) = "'" Then
                targetCell.Value = "'" & CStr(valueSnapshot(r, c))
            Else
                targetCell.Value2 = valueSnapshot(r, c)
            End If
        Next c
    Next r
End Sub

Private Function BalanceFormulaItemMatches(ByVal actualValue As Variant, _
                                           ByVal expectedValue As Variant) As Boolean
    If IsError(actualValue) Or IsError(expectedValue) Then
        If IsError(actualValue) And IsError(expectedValue) Then _
            BalanceFormulaItemMatches = _
                (Application.WorksheetFunction.Error_Type(actualValue) = _
                 Application.WorksheetFunction.Error_Type(expectedValue))
        Exit Function
    End If
    If IsEmpty(actualValue) Or IsEmpty(expectedValue) Then
        BalanceFormulaItemMatches = (IsEmpty(actualValue) And IsEmpty(expectedValue))
        Exit Function
    End If
    If IsNull(actualValue) Or IsNull(expectedValue) Then
        BalanceFormulaItemMatches = (IsNull(actualValue) And IsNull(expectedValue))
        Exit Function
    End If
    If VarType(actualValue) <> VarType(expectedValue) Then Exit Function
    Select Case VarType(actualValue)
        Case vbByte, vbInteger, vbLong, vbSingle, vbDouble, vbCurrency, vbDecimal, vbDate
            BalanceFormulaItemMatches = (CDbl(actualValue) = CDbl(expectedValue))
        Case vbBoolean
            BalanceFormulaItemMatches = (CBool(actualValue) = CBool(expectedValue))
        Case Else
            BalanceFormulaItemMatches = _
                (StrComp(CStr(actualValue), CStr(expectedValue), vbBinaryCompare) = 0)
    End Select
End Function

Private Function BalanceInputAreaMatchesSnapshot(ByVal targetRange As Range, _
                                                 ByVal expectedFormula As Variant, _
                                                 ByVal expectedValue As Variant, _
                                                 ByVal expectedHasFormula As Variant, _
                                                 ByVal expectedPrefix As Variant, _
                                                 ByVal expectedMergeSignature As String, _
                                                 ByRef mismatchDetail As String) As Boolean
    Dim r As Long, c As Long
    On Error GoTo EH
    If targetRange Is Nothing Or Not IsArray(expectedFormula) Or _
       Not IsArray(expectedValue) Or Not IsArray(expectedHasFormula) Or _
       Not IsArray(expectedPrefix) Then
        mismatchDetail = "残高欄の退避値を確認できません。"
        Exit Function
    End If
    If StrComp(BalanceInputAreaMergeSignature(targetRange), _
               expectedMergeSignature, vbBinaryCompare) <> 0 Then
        mismatchDetail = "残高欄の結合構造が再生成前と一致しません。"
        Exit Function
    End If
    If LBound(expectedFormula, 1) <> 1 Or _
       UBound(expectedFormula, 1) <> targetRange.Rows.Count Or _
       LBound(expectedFormula, 2) <> 1 Or _
       UBound(expectedFormula, 2) <> targetRange.Columns.Count Then
        mismatchDetail = "残高欄の復元範囲サイズが一致しません。"
        Exit Function
    End If
    For r = LBound(expectedFormula, 1) To UBound(expectedFormula, 1)
        For c = LBound(expectedFormula, 2) To UBound(expectedFormula, 2)
            If CBool(targetRange.Cells(r, c).HasFormula) <> _
               CBool(expectedHasFormula(r, c)) Then
                mismatchDetail = "残高欄の数式/値の種別が一致しません: " & _
                                 targetRange.Cells(r, c).Address(False, False)
                Exit Function
            End If
            If StrComp(CellText(targetRange.Cells(r, c).PrefixCharacter), _
                       CellText(expectedPrefix(r, c)), vbBinaryCompare) <> 0 Then
                mismatchDetail = "残高欄の文字列接頭辞が一致しません: " & _
                                 targetRange.Cells(r, c).Address(False, False)
                Exit Function
            End If
            If Not BalanceFormulaItemMatches(targetRange.Cells(r, c).Formula, _
                                             expectedFormula(r, c)) Or _
               Not BalanceFormulaItemMatches(targetRange.Cells(r, c).Value2, _
                                             expectedValue(r, c)) Then
                mismatchDetail = "残高欄の復元値が一致しません: " & _
                                 targetRange.Cells(r, c).Address(False, False)
                Exit Function
            End If
        Next c
    Next r
    BalanceInputAreaMatchesSnapshot = True
    Exit Function
EH:
    mismatchDetail = "残高欄の復元確認エラー: Err " & CStr(Err.Number) & _
                     " " & Err.Description
End Function

Private Function BalancePresentationSnapshotIsValid(ByVal columnHiddenSnapshot As Variant, _
                                                    ByVal columnWidthSnapshot As Variant, _
                                                    ByVal rowHeightSnapshot As Variant, _
                                                    ByVal rowHiddenSnapshot As Variant) As Boolean
    On Error GoTo EH
    If Not IsArray(columnHiddenSnapshot) Or Not IsArray(columnWidthSnapshot) Or _
       Not IsArray(rowHeightSnapshot) Or Not IsArray(rowHiddenSnapshot) Then Exit Function
    If LBound(columnHiddenSnapshot) <> 1 Or _
       UBound(columnHiddenSnapshot) <> BAL_MAX_COL - BAL_FIRST_COL + 1 Then Exit Function
    If LBound(columnWidthSnapshot) <> 1 Or _
       UBound(columnWidthSnapshot) <> BAL_MAX_COL - BAL_FIRST_COL + 1 Then Exit Function
    If LBound(rowHeightSnapshot) <> 0 Or UBound(rowHeightSnapshot) <> 3 Then Exit Function
    If LBound(rowHiddenSnapshot) <> 0 Or UBound(rowHiddenSnapshot) <> 3 Then Exit Function
    BalancePresentationSnapshotIsValid = True
    Exit Function
EH:
    Err.Clear
End Function

Private Sub CaptureBalancePresentationState(ByVal ws As Worksheet, _
                                            ByRef columnHiddenSnapshot As Variant, _
                                            ByRef columnWidthSnapshot As Variant, _
                                            ByRef rowHeightSnapshot As Variant, _
                                            ByRef rowHiddenSnapshot As Variant)
    Dim columnHiddenValues() As Variant, columnWidthValues() As Variant
    Dim rowHeightValues() As Variant, rowHiddenValues() As Variant
    Dim rowNumbers As Variant
    Dim c As Long, i As Long, snapshotIndex As Long
    If ws Is Nothing Then _
        Err.Raise vbObjectError + 1811, "CaptureBalancePresentationState", _
                  "残高欄の表示状態を取得できません。"
    ReDim columnHiddenValues(1 To BAL_MAX_COL - BAL_FIRST_COL + 1)
    ReDim columnWidthValues(1 To BAL_MAX_COL - BAL_FIRST_COL + 1)
    For c = BAL_FIRST_COL To BAL_MAX_COL
        snapshotIndex = c - BAL_FIRST_COL + 1
        columnHiddenValues(snapshotIndex) = CBool(ws.Columns(c).Hidden)
        columnWidthValues(snapshotIndex) = CDbl(ws.Columns(c).ColumnWidth)
    Next c
    rowNumbers = Array(INPUT_BALANCE_HEADER_ROW, BAL_LABEL_ROW, BAL_VALUE_ROW, BAL_DATE_ROW)
    ReDim rowHeightValues(0 To UBound(rowNumbers))
    ReDim rowHiddenValues(0 To UBound(rowNumbers))
    For i = 0 To UBound(rowNumbers)
        rowHeightValues(i) = CDbl(ws.Rows(CLng(rowNumbers(i))).RowHeight)
        rowHiddenValues(i) = CBool(ws.Rows(CLng(rowNumbers(i))).Hidden)
    Next i
    columnHiddenSnapshot = columnHiddenValues
    columnWidthSnapshot = columnWidthValues
    rowHeightSnapshot = rowHeightValues
    rowHiddenSnapshot = rowHiddenValues
End Sub

Private Sub RestoreBalanceMergeSignature(ByVal targetRange As Range, _
                                         ByVal expectedSignature As String, _
                                         ByVal rangeLabel As String)
    Dim signaturePrefix As String, remainingText As String, mergeAddress As String
    Dim separatorPos As Long
    Dim mergeRange As Range, overlapRange As Range
    If targetRange Is Nothing Then _
        Err.Raise vbObjectError + 1812, "RestoreBalanceMergeSignature", _
                  rangeLabel & "の復元範囲がありません。"
    signaturePrefix = targetRange.Address(False, False, xlA1, False) & "|"
    If StrComp(Left$(expectedSignature, Len(signaturePrefix)), _
               signaturePrefix, vbBinaryCompare) <> 0 Then _
        Err.Raise vbObjectError + 1813, "RestoreBalanceMergeSignature", _
                  rangeLabel & "の結合退避値が不正です。"
    remainingText = Mid$(expectedSignature, Len(signaturePrefix) + 1)
    targetRange.UnMerge
    Do While Len(remainingText) > 0
        separatorPos = InStr(1, remainingText, ";", vbBinaryCompare)
        If separatorPos <= 1 Then _
            Err.Raise vbObjectError + 1813, "RestoreBalanceMergeSignature", _
                      rangeLabel & "の結合退避値が不正です。"
        mergeAddress = Left$(remainingText, separatorPos - 1)
        remainingText = Mid$(remainingText, separatorPos + 1)
        Set mergeRange = targetRange.Worksheet.Range(mergeAddress)
        Set overlapRange = Application.Intersect(mergeRange, targetRange)
        If overlapRange Is Nothing Then _
            Err.Raise vbObjectError + 1814, "RestoreBalanceMergeSignature", _
                      rangeLabel & "の結合退避値が許可範囲外です。"
        If overlapRange.CountLarge <> mergeRange.CountLarge Then _
            Err.Raise vbObjectError + 1814, "RestoreBalanceMergeSignature", _
                      rangeLabel & "の結合退避値が許可範囲外です。"
        mergeRange.Merge
    Loop
    If StrComp(BalanceInputAreaMergeSignature(targetRange), _
               expectedSignature, vbBinaryCompare) <> 0 Then _
        Err.Raise vbObjectError + 1815, "RestoreBalanceMergeSignature", _
                  rangeLabel & "の結合構造を復元できませんでした。"
End Sub

Private Sub RestoreBalanceHeaderSnapshot(ByVal headerArea As Range, _
                                         ByVal formulaSnapshot As Variant, _
                                         ByVal valueSnapshot As Variant, _
                                         ByVal hasFormulaSnapshot As Variant, _
                                         ByVal prefixSnapshot As Variant, _
                                         ByVal mergeSignature As String)
    If headerArea Is Nothing Then _
        Err.Raise vbObjectError + 1816, "RestoreBalanceHeaderSnapshot", _
                  "残高見出しの復元範囲がありません。"
    headerArea.UnMerge
    headerArea.ClearContents
    RestoreBalanceInputCellIdentity headerArea, formulaSnapshot, valueSnapshot, _
                                    hasFormulaSnapshot, prefixSnapshot
    RestoreBalanceMergeSignature headerArea, mergeSignature, "残高見出し"
End Sub

Private Sub RestoreBalancePresentationState(ByVal ws As Worksheet, _
                                            ByVal columnHiddenSnapshot As Variant, _
                                            ByVal columnWidthSnapshot As Variant, _
                                            ByVal rowHeightSnapshot As Variant, _
                                            ByVal rowHiddenSnapshot As Variant)
    Dim rowNumbers As Variant
    Dim c As Long, i As Long, snapshotIndex As Long
    If ws Is Nothing Or _
       Not BalancePresentationSnapshotIsValid(columnHiddenSnapshot, _
                                              columnWidthSnapshot, _
                                              rowHeightSnapshot, _
                                              rowHiddenSnapshot) Then _
        Err.Raise vbObjectError + 1817, "RestoreBalancePresentationState", _
                  "残高欄の表示退避値が不正です。"
    For c = BAL_FIRST_COL To BAL_MAX_COL
        snapshotIndex = c - BAL_FIRST_COL + 1
        ws.Columns(c).ColumnWidth = CDbl(columnWidthSnapshot(snapshotIndex))
        ws.Columns(c).Hidden = CBool(columnHiddenSnapshot(snapshotIndex))
    Next c
    rowNumbers = Array(INPUT_BALANCE_HEADER_ROW, BAL_LABEL_ROW, BAL_VALUE_ROW, BAL_DATE_ROW)
    For i = 0 To UBound(rowNumbers)
        ws.Rows(CLng(rowNumbers(i))).RowHeight = CDbl(rowHeightSnapshot(i))
        ws.Rows(CLng(rowNumbers(i))).Hidden = CBool(rowHiddenSnapshot(i))
    Next i
End Sub

Private Function BalancePresentationStateMatchesSnapshot( _
                         ByVal ws As Worksheet, _
                         ByVal columnHiddenSnapshot As Variant, _
                         ByVal columnWidthSnapshot As Variant, _
                         ByVal rowHeightSnapshot As Variant, _
                         ByVal rowHiddenSnapshot As Variant, _
                         ByRef mismatchDetail As String) As Boolean
    Dim rowNumbers As Variant
    Dim c As Long, i As Long, snapshotIndex As Long
    On Error GoTo EH
    If ws Is Nothing Or _
       Not BalancePresentationSnapshotIsValid(columnHiddenSnapshot, _
                                              columnWidthSnapshot, _
                                              rowHeightSnapshot, _
                                              rowHiddenSnapshot) Then
        mismatchDetail = "残高欄の表示退避値を確認できません。"
        Exit Function
    End If
    For c = BAL_FIRST_COL To BAL_MAX_COL
        snapshotIndex = c - BAL_FIRST_COL + 1
        If CBool(ws.Columns(c).Hidden) <> _
           CBool(columnHiddenSnapshot(snapshotIndex)) Then
            mismatchDetail = "残高欄の列表示状態が一致しません: " & _
                             ws.Columns(c).Address(False, False)
            Exit Function
        End If
        If Abs(CDbl(ws.Columns(c).ColumnWidth) - _
               CDbl(columnWidthSnapshot(snapshotIndex))) > 0.0001 Then
            mismatchDetail = "残高欄の列幅が一致しません: " & _
                             ws.Columns(c).Address(False, False)
            Exit Function
        End If
    Next c
    rowNumbers = Array(INPUT_BALANCE_HEADER_ROW, BAL_LABEL_ROW, BAL_VALUE_ROW, BAL_DATE_ROW)
    For i = 0 To UBound(rowNumbers)
        If CBool(ws.Rows(CLng(rowNumbers(i))).Hidden) <> _
           CBool(rowHiddenSnapshot(i)) Then
            mismatchDetail = "残高欄の行表示状態が一致しません: " & _
                             CStr(rowNumbers(i)) & "行"
            Exit Function
        End If
        If Abs(CDbl(ws.Rows(CLng(rowNumbers(i))).RowHeight) - _
               CDbl(rowHeightSnapshot(i))) > 0.0001 Then
            mismatchDetail = "残高欄の行高が一致しません: " & _
                             CStr(rowNumbers(i)) & "行"
            Exit Function
        End If
    Next i
    BalancePresentationStateMatchesSnapshot = True
    Exit Function
EH:
    mismatchDetail = "残高欄の表示復元確認エラー: Err " & CStr(Err.Number) & _
                     " " & Err.Description
End Function

Public Sub BuildBalanceInputFields(Optional ByVal showDoneMessage As Boolean = True, _
                                   Optional ByVal raiseOnError As Boolean = False)
    Dim ws As Worksheet
    Dim labels As Collection
    Dim dates As Collection
    Dim i As Long, col As Long, memoCol As Long, maxLabels As Long
    Dim startYear As Long, endYear As Long
    Dim stepName As String
    Dim eNo As Long
    Dim eDesc As String, eSource As String
    Dim balanceArea As Range, balanceHeaderArea As Range
    Dim previousAreaFormula As Variant
    Dim previousAreaValue As Variant
    Dim previousAreaHasFormula As Variant
    Dim previousAreaPrefix As Variant
    Dim previousHeaderFormula As Variant
    Dim previousHeaderValue As Variant
    Dim previousHeaderHasFormula As Variant
    Dim previousHeaderPrefix As Variant
    Dim previousColumnHidden As Variant
    Dim previousColumnWidth As Variant
    Dim previousRowHeight As Variant
    Dim previousRowHidden As Variant
    Dim previousMergeSignature As String
    Dim previousHeaderMergeSignature As String
    Dim previousMemoCol As Long
    Dim snapshotCaptured As Boolean, destructiveStarted As Boolean, appStarted As Boolean
    Dim restoreDetail As String
    Dim restoreMismatchDetail As String
    Dim restoreErrorNumber As Long, restoreErrorDescription As String
    Dim coreRestoreFailed As Boolean
    Dim safetyStateValue As String, recoveryStateValue As String
    Dim safetyStateConfirmed As Boolean, recoveryStateConfirmed As Boolean
    Dim recoveryStateRequired As Boolean, recoveryInspectionRequired As Boolean
    Dim recoveryDualConfirmed As Boolean, eventsUnsafeAfterEnforce As Boolean
    Dim recoveryAttempted As Boolean, terminalRecoveryFailure As Boolean
    Dim postEnforceEventsStopped As Boolean, finalEventsStopped As Boolean
    Dim applicationStateRestored As Boolean, applicationStateProblems As String
    Dim recoveryConfirmationDetail As String, eventStateDetail As String
    Dim enforceErrorNumber As Long, enforceErrorDescription As String
    Dim nestedErrorSource As String
    Dim detailsExpandedBefore As Boolean

    '利用者が直接再生成する時は中断状態での画面・状態変更を防ぐ。
    'セットアップ／初期化内部は showDoneMessage=False を明示し、再構築を継続できる。
    If showDoneMessage Then
        If Not RequireToolReady() Then Exit Sub
        If Not RequireWritableWorkbook("残高欄の再生成") Then Exit Sub
        If IsEditMode() Then
            MsgBox "口座の訂正中は残高欄を再生成できません。" & vbCrLf & _
                   "先に訂正を完了するか中止し、設定変更後に口座を読み込み直してください。", _
                   vbExclamation, "訂正中の残高を保護しました"
            Exit Sub
        End If
    End If
    On Error GoTo EH
    If Not SheetExists(SH_INPUT) Then Exit Sub
    Set ws = GetSheet(SH_INPUT)
    detailsExpandedBefore = InputDetailsExpanded(ws)

    If showDoneMessage Then
        If Application.WorksheetFunction.CountA(ws.Range(ws.Cells(BAL_VALUE_ROW, BAL_FIRST_COL), ws.Cells(BAL_VALUE_ROW, BAL_MAX_COL))) > 0 Then
            If MsgBox("残高欄を再生成すると、現在入力中の残高とメモは消去されます。続けますか？", _
                      vbYesNo + vbExclamation + vbDefaultButton2, "残高欄の再生成") <> vbYes Then Exit Sub
        End If
    End If

    Set balanceArea = ws.Range(ws.Cells(BAL_LABEL_ROW, BAL_FIRST_COL), _
                               ws.Cells(BAL_DATE_ROW, BAL_MAX_COL))
    CaptureBalanceInputCellIdentity balanceArea, previousAreaFormula, previousAreaValue, _
                                    previousAreaHasFormula, previousAreaPrefix
    previousMergeSignature = BalanceInputAreaMergeSignature(balanceArea)
    Set balanceHeaderArea = ws.Range(ws.Cells(INPUT_BALANCE_HEADER_ROW, BAL_FIRST_COL), _
                                     ws.Cells(INPUT_BALANCE_HEADER_ROW, BAL_MAX_COL))
    CaptureBalanceInputCellIdentity balanceHeaderArea, previousHeaderFormula, previousHeaderValue, _
                                    previousHeaderHasFormula, previousHeaderPrefix
    previousHeaderMergeSignature = BalanceInputAreaMergeSignature(balanceHeaderArea)
    CaptureBalancePresentationState ws, previousColumnHidden, previousColumnWidth, _
                                    previousRowHeight, previousRowHidden
    previousMemoCol = BalanceMemoCol(ws)
    snapshotCaptured = True

    AppBegin "残高欄を再構築しています..."
    appStarted = True
    stepName = "入力シート保護解除"
    ws.Visible = xlSheetVisible
    ws.Unprotect Password:=TOOL_PASSWORD

    stepName = "残高ラベル作成"
    If Not ValidateBalanceYearSettings(startYear, endYear, eDesc) Then
        Err.Raise vbObjectError + 1800, "BuildBalanceInputFields", eDesc
    End If
    BuildBalanceCollections labels, dates
    If labels Is Nothing Or dates Is Nothing Then Err.Raise vbObjectError + 1801, "BuildBalanceInputFields", "残高欄の見出しを作成できませんでした。"
    If labels.Count = 0 Then Err.Raise vbObjectError + 1802, "BuildBalanceInputFields", "残高欄の表示範囲が空です。設定シートの残高年表示範囲を確認してください。"

    CapBalanceCollections labels, dates, BAL_MAX_LABELS

    '残高表示期間は帳票内容にも影響する。VBA強制停止やExcel異常終了が
    '既存欄の消去直後に起きても旧帳票を更新済み扱いしないよう、最初の
    '破壊的書込みより前にdirtyを永続化・読戻し確認する。
    stepName = "帳票要更新状態"
    MarkOutputsDirty

    stepName = "既存残高欄の初期化"
    destructiveStarted = True
    'イベントを止めたまま残高欄を再配置するため、成功・ロールバックのどちらでも
    '次の入力表示時に旧列位置のエラー辞書を使わない。
    InvalidatePendingInputErrorCache
    '前回の表示時に不要列を隠していても、新しい年数設定はB:V全体へ安全に再配置する。
    ws.Range(ws.Columns(BAL_FIRST_COL), ws.Columns(BAL_MAX_COL)).EntireColumn.Hidden = False
    ResetBalanceInputArea ws

    stepName = "残高欄の配置"
    maxLabels = labels.Count
    If maxLabels > BAL_MAX_LABELS Then maxLabels = BAL_MAX_LABELS

    For i = 1 To maxLabels
        col = BAL_FIRST_COL + i - 1
        ws.Cells(BAL_LABEL_ROW, col).Value = BalanceInputLabelDisplay(CStr(labels(i)))
        ws.Cells(BAL_VALUE_ROW, col).Value = vbNullString
        ws.Cells(BAL_DATE_ROW, col).Value = dates(i)
        ws.Cells(BAL_DATE_ROW, col).NumberFormatLocal = "yyyy/m/d"
    Next i

    memoCol = BAL_FIRST_COL + maxLabels
    If memoCol > BAL_MAX_COL Then memoCol = BAL_MAX_COL

    stepName = "その他欄の配置"
    If memoCol < BAL_MAX_COL Then
        MergeAndFormat ws.Range(ws.Cells(BAL_LABEL_ROW, memoCol), ws.Cells(BAL_LABEL_ROW, BAL_MAX_COL)), "その他"
        MergeAndFormat ws.Range(ws.Cells(BAL_VALUE_ROW, memoCol), ws.Cells(BAL_VALUE_ROW, BAL_MAX_COL)), vbNullString
        If Not IsSingleMergeArea(ws.Range(ws.Cells(BAL_LABEL_ROW, memoCol), _
                                                ws.Cells(BAL_LABEL_ROW, BAL_MAX_COL))) Or _
           Not IsSingleMergeArea(ws.Range(ws.Cells(BAL_VALUE_ROW, memoCol), _
                                                ws.Cells(BAL_VALUE_ROW, BAL_MAX_COL))) Then
            Err.Raise vbObjectError + 1804, "BuildBalanceInputFields", _
                      "残高メモ欄を所定範囲へ結合できませんでした。"
        End If
    Else
        ws.Cells(BAL_LABEL_ROW, memoCol).Value = "その他"
        ws.Cells(BAL_VALUE_ROW, memoCol).Value = vbNullString
    End If

    stepName = "残高欄の書式設定"
    FormatBalanceInputArea ws, memoCol

    stepName = "入力画面の表示調整"
    PolishInputLayout ws, True
    SetInputDetailsExpanded ws, detailsExpandedBefore, False
    '残高欄の再構築は、利用者が調整した表示倍率を変更しない。
    FitInputWindowToAvailableWidth ws, False

    stepName = "入力規則と保護の再適用"
    ApplyInputSettings False, True
    If Not ValidateBalanceInputStructure(ws, eDesc) Then
        Err.Raise vbObjectError + 1803, "BuildBalanceInputFields", eDesc
    End If
    ProtectInputSheet True
    AppEnd
    appStarted = False

    If showDoneMessage Then MsgBox "残高欄を再生成しました。", vbInformation
    Exit Sub

EH:
    eNo = Err.Number
    eDesc = Err.Description
    eSource = Err.Source
    terminalRecoveryFailure = IsSetupRecoveryFatalError(eNo, eSource)
    If terminalRecoveryFailure Then
        On Error Resume Next
        Call SetApplicationEnableEventsExact(False, eventStateDetail)
        Call SetApplicationEnableEventsExact(False, eventStateDetail)
        On Error GoTo 0
        Err.Raise eNo, eSource, eDesc
    End If
    On Error Resume Next
    If destructiveStarted And snapshotCaptured And Not ws Is Nothing Then
        Err.Clear
        ws.Unprotect Password:=TOOL_PASSWORD
        If Err.Number <> 0 Then
            restoreErrorNumber = Err.Number
            restoreErrorDescription = Err.Description
            Err.Clear
            AppendBalanceFieldRestoreIssue restoreDetail, "入力シート保護解除", _
                                           restoreErrorNumber, restoreErrorDescription
            coreRestoreFailed = True
        End If

        Err.Clear
        ResetBalanceInputArea ws
        If Err.Number <> 0 Then
            restoreErrorNumber = Err.Number
            restoreErrorDescription = Err.Description
            Err.Clear
            AppendBalanceFieldRestoreIssue restoreDetail, "残高欄初期化", _
                                           restoreErrorNumber, restoreErrorDescription
            coreRestoreFailed = True
        End If

        Err.Clear
        RestoreBalanceInputCellIdentity balanceArea, previousAreaFormula, previousAreaValue, _
                                        previousAreaHasFormula, previousAreaPrefix
        If Err.Number <> 0 Then
            restoreErrorNumber = Err.Number
            restoreErrorDescription = Err.Description
            Err.Clear
            AppendBalanceFieldRestoreIssue restoreDetail, "残高欄の値復元", _
                                           restoreErrorNumber, restoreErrorDescription
            coreRestoreFailed = True
        End If
        If previousMemoCol >= BAL_FIRST_COL And previousMemoCol < BAL_MAX_COL Then
            Err.Clear
            ws.Range(ws.Cells(BAL_LABEL_ROW, previousMemoCol), _
                     ws.Cells(BAL_LABEL_ROW, BAL_MAX_COL)).Merge
            If Err.Number <> 0 Then
                restoreErrorNumber = Err.Number
                restoreErrorDescription = Err.Description
                Err.Clear
                AppendBalanceFieldRestoreIssue restoreDetail, "残高ラベル結合の復元", _
                                               restoreErrorNumber, restoreErrorDescription
                coreRestoreFailed = True
            End If
            Err.Clear
            ws.Range(ws.Cells(BAL_VALUE_ROW, previousMemoCol), _
                     ws.Cells(BAL_VALUE_ROW, BAL_MAX_COL)).Merge
            If Err.Number <> 0 Then
                restoreErrorNumber = Err.Number
                restoreErrorDescription = Err.Description
                Err.Clear
                AppendBalanceFieldRestoreIssue restoreDetail, "残高メモ結合の復元", _
                                               restoreErrorNumber, restoreErrorDescription
                coreRestoreFailed = True
            End If
        End If

        Err.Clear
        FormatBalanceInputArea ws, previousMemoCol
        If Err.Number <> 0 Then
            restoreErrorNumber = Err.Number
            restoreErrorDescription = Err.Description
            Err.Clear
            AppendBalanceFieldRestoreIssue restoreDetail, "残高欄書式の復元", _
                                           restoreErrorNumber, restoreErrorDescription
            coreRestoreFailed = True
        End If

        Err.Clear
        RestoreBalanceHeaderSnapshot balanceHeaderArea, previousHeaderFormula, _
                                     previousHeaderValue, previousHeaderHasFormula, _
                                     previousHeaderPrefix, previousHeaderMergeSignature
        If Err.Number <> 0 Then
            restoreErrorNumber = Err.Number
            restoreErrorDescription = Err.Description
            Err.Clear
            AppendBalanceFieldRestoreIssue restoreDetail, "残高見出しの復元", _
                                           restoreErrorNumber, restoreErrorDescription
            coreRestoreFailed = True
        End If

        Err.Clear
        RestoreBalancePresentationState ws, previousColumnHidden, previousColumnWidth, _
                                        previousRowHeight, previousRowHidden
        If Err.Number <> 0 Then
            restoreErrorNumber = Err.Number
            restoreErrorDescription = Err.Description
            Err.Clear
            AppendBalanceFieldRestoreIssue restoreDetail, "残高表示状態の復元", _
                                           restoreErrorNumber, restoreErrorDescription
            coreRestoreFailed = True
        End If

        Err.Clear
        ApplyInputSettings False, True
        If Err.Number <> 0 Then
            restoreErrorNumber = Err.Number
            restoreErrorDescription = Err.Description
            nestedErrorSource = Err.Source
            Err.Clear
            If IsSetupRecoveryFatalError( _
                   restoreErrorNumber, nestedErrorSource) Then
                Call SetApplicationEnableEventsExact(False, eventStateDetail)
                Call SetApplicationEnableEventsExact(False, eventStateDetail)
                On Error GoTo 0
                Err.Raise restoreErrorNumber, nestedErrorSource, _
                          restoreErrorDescription
            End If
            AppendBalanceFieldRestoreIssue restoreDetail, "入力規則の復元", _
                                           restoreErrorNumber, restoreErrorDescription
            coreRestoreFailed = True
        End If

        Err.Clear
        ApplyBalanceAvailability ws
        If Err.Number <> 0 Then
            restoreErrorNumber = Err.Number
            restoreErrorDescription = Err.Description
            Err.Clear
            AppendBalanceFieldRestoreIssue restoreDetail, "残高入力可否の復元", _
                                           restoreErrorNumber, restoreErrorDescription
            coreRestoreFailed = True
        End If

        restoreMismatchDetail = vbNullString
        Err.Clear
        If Not BalanceInputAreaMatchesSnapshot(balanceArea, previousAreaFormula, _
                                               previousAreaValue, previousAreaHasFormula, _
                                               previousAreaPrefix, previousMergeSignature, _
                                               restoreMismatchDetail) Then
            If Len(restoreMismatchDetail) = 0 Then _
                restoreMismatchDetail = "残高欄の復元値または結合構造が一致しません。"
            AppendBalanceFieldRestoreIssue restoreDetail, "残高欄の読戻し確認", _
                                           vbObjectError + 1806, restoreMismatchDetail
            coreRestoreFailed = True
        ElseIf Err.Number <> 0 Then
            restoreErrorNumber = Err.Number
            restoreErrorDescription = Err.Description
            Err.Clear
            AppendBalanceFieldRestoreIssue restoreDetail, "残高欄の読戻し確認", _
                                           restoreErrorNumber, restoreErrorDescription
            coreRestoreFailed = True
        End If

        restoreMismatchDetail = vbNullString
        Err.Clear
        If Not BalanceInputAreaMatchesSnapshot(balanceHeaderArea, previousHeaderFormula, _
                                               previousHeaderValue, previousHeaderHasFormula, _
                                               previousHeaderPrefix, previousHeaderMergeSignature, _
                                               restoreMismatchDetail) Then
            If Len(restoreMismatchDetail) = 0 Then _
                restoreMismatchDetail = "残高見出しの復元値または結合構造が一致しません。"
            AppendBalanceFieldRestoreIssue restoreDetail, "残高見出しの読戻し確認", _
                                           vbObjectError + 1818, restoreMismatchDetail
            coreRestoreFailed = True
        ElseIf Err.Number <> 0 Then
            restoreErrorNumber = Err.Number
            restoreErrorDescription = Err.Description
            Err.Clear
            AppendBalanceFieldRestoreIssue restoreDetail, "残高見出しの読戻し確認", _
                                           restoreErrorNumber, restoreErrorDescription
            coreRestoreFailed = True
        End If

        restoreMismatchDetail = vbNullString
        Err.Clear
        If Not BalancePresentationStateMatchesSnapshot(ws, previousColumnHidden, _
                                                       previousColumnWidth, previousRowHeight, _
                                                       previousRowHidden, _
                                                       restoreMismatchDetail) Then
            If Len(restoreMismatchDetail) = 0 Then _
                restoreMismatchDetail = "残高欄の表示状態が再生成前と一致しません。"
            AppendBalanceFieldRestoreIssue restoreDetail, "残高表示状態の読戻し確認", _
                                           vbObjectError + 1819, restoreMismatchDetail
            coreRestoreFailed = True
        ElseIf Err.Number <> 0 Then
            restoreErrorNumber = Err.Number
            restoreErrorDescription = Err.Description
            Err.Clear
            AppendBalanceFieldRestoreIssue restoreDetail, "残高表示状態の読戻し確認", _
                                           restoreErrorNumber, restoreErrorDescription
            coreRestoreFailed = True
        End If
    ElseIf destructiveStarted Then
        AppendBalanceFieldRestoreIssue restoreDetail, "残高欄の復元", _
                                       vbObjectError + 1807, _
                                       "再生成前の完全な退避値を取得できていません。"
        coreRestoreFailed = True
    End If

    Err.Clear
    ProtectInputSheet True
    If Err.Number <> 0 Then
        restoreErrorNumber = Err.Number
        restoreErrorDescription = Err.Description
        nestedErrorSource = Err.Source
        Err.Clear
        If IsSetupRecoveryFatalError( _
               restoreErrorNumber, nestedErrorSource) Then
            Call SetApplicationEnableEventsExact(False, eventStateDetail)
            Call SetApplicationEnableEventsExact(False, eventStateDetail)
            On Error GoTo 0
            Err.Raise restoreErrorNumber, nestedErrorSource, _
                      restoreErrorDescription
        End If
        AppendBalanceFieldRestoreIssue restoreDetail, "入力シート保護の復元", _
                                       restoreErrorNumber, restoreErrorDescription
        '保護解除後、残高本体を書き換える前に失敗した場合も、再保護不能なら
        '編集可能な入力画面を通常状態へ戻さない。停止状態と要復旧を必須にする。
        coreRestoreFailed = True
        recoveryStateRequired = True
        recoveryInspectionRequired = True
    End If

    If coreRestoreFailed Then
        '部分復元の残高を登録させず、利用者が残高欄を再生成または入力消去するまで停止する。
        Err.Clear
        MarkOutputsDirty
        If Err.Number <> 0 Then
            restoreErrorNumber = Err.Number
            restoreErrorDescription = Err.Description
            Err.Clear
            AppendBalanceFieldRestoreIssue restoreDetail, "帳票要更新状態の記録", _
                                           restoreErrorNumber, restoreErrorDescription
            recoveryStateRequired = True
        End If
        Err.Clear
        SetStateValue STATE_INPUT_DATE_CONFIG_SAFE, STATE_FALSE
        If Err.Number <> 0 Then
            restoreErrorNumber = Err.Number
            restoreErrorDescription = Err.Description
            Err.Clear
            AppendBalanceFieldRestoreIssue restoreDetail, "入力安全停止状態の記録", _
                                           restoreErrorNumber, restoreErrorDescription
            recoveryStateRequired = True
        Else
            Err.Clear
            safetyStateConfirmed = TryGetExactStateValue( _
                                       STATE_INPUT_DATE_CONFIG_SAFE, safetyStateValue)
            If Err.Number <> 0 Then
                restoreErrorNumber = Err.Number
                restoreErrorDescription = Err.Description
                Err.Clear
                AppendBalanceFieldRestoreIssue restoreDetail, "入力安全停止状態の読戻し", _
                                               restoreErrorNumber, restoreErrorDescription
                recoveryStateRequired = True
            ElseIf Not safetyStateConfirmed Or safetyStateValue <> STATE_FALSE Then
                AppendBalanceFieldRestoreIssue restoreDetail, "入力安全停止状態の読戻し", _
                                               vbObjectError + 1810, _
                                               "登録停止状態をFalseとして確認できません。"
                recoveryStateRequired = True
            End If
        End If
        If recoveryStateRequired Then
            '登録停止フラグ自体を保証できない時は通常処理へ戻さず、案件全体を要復旧にする。
            Err.Clear
            MarkOutputsDirty
            If Err.Number <> 0 Then
                restoreErrorNumber = Err.Number
                restoreErrorDescription = Err.Description
                Err.Clear
                AppendBalanceFieldRestoreIssue restoreDetail, "帳票要更新状態の再記録", _
                                               restoreErrorNumber, restoreErrorDescription
            End If
            Err.Clear
            SetStateValue STATE_DATA_HEALTH, DATA_HEALTH_NEEDS_RECOVERY
            If Err.Number <> 0 Then
                restoreErrorNumber = Err.Number
                restoreErrorDescription = Err.Description
                Err.Clear
                AppendBalanceFieldRestoreIssue restoreDetail, "案件要復旧状態の記録", _
                                               restoreErrorNumber, restoreErrorDescription
                recoveryInspectionRequired = True
            Else
                Err.Clear
                recoveryStateConfirmed = TryGetExactStateValue( _
                                             STATE_DATA_HEALTH, recoveryStateValue)
                If Err.Number <> 0 Then
                    restoreErrorNumber = Err.Number
                    restoreErrorDescription = Err.Description
                    Err.Clear
                    AppendBalanceFieldRestoreIssue restoreDetail, "案件要復旧状態の読戻し", _
                                                   restoreErrorNumber, restoreErrorDescription
                    recoveryInspectionRequired = True
                ElseIf Not recoveryStateConfirmed Or _
                       recoveryStateValue <> DATA_HEALTH_NEEDS_RECOVERY Then
                    AppendBalanceFieldRestoreIssue restoreDetail, "案件要復旧状態の読戻し", _
                                                   vbObjectError + 1820, _
                                                   "案件要復旧状態を一意に確認できません。"
                    recoveryInspectionRequired = True
                End If
            End If
            '要復旧をW_状態へ書けた場合も、同一セッションの入力セル・OnKeyを
            '残さない。中央の復旧経路で独立ラッチ、dirty、入力隔離を必ず収束させる。
            Err.Clear
            recoveryAttempted = True
            EnforceRollbackRecoveryState restoreDetail
            enforceErrorNumber = Err.Number
            enforceErrorDescription = Err.Description
            Err.Clear
            '共通復旧は例外終了時にイベントFalseを保証できない。診断書込みと
            'AppEndより前に、この呼出元で書込み・読戻しを再確認する。
            postEnforceEventsStopped = _
                SetApplicationEnableEventsExact(False, eventStateDetail)
            If Not postEnforceEventsStopped Then _
                postEnforceEventsStopped = _
                    SetApplicationEnableEventsExact(False, eventStateDetail)
            terminalRecoveryFailure = True
            GoTo BUILD_BALANCE_RECOVERY_FATAL
        End If
    End If
    If appStarted Then
        Err.Clear
        AppEnd
        If Err.Number <> 0 Then
            restoreErrorNumber = Err.Number
            restoreErrorDescription = Err.Description
            Err.Clear
            AppendBalanceFieldRestoreIssue restoreDetail, "Excel状態の復元", _
                                           restoreErrorNumber, restoreErrorDescription
        Else
            appStarted = False
        End If
    End If
    If eventsUnsafeAfterEnforce Then
        'AppEndが開始値を戻しても、安全状態が未確定なら最後にFalseへ収束させる。
        postEnforceEventsStopped = _
            SetApplicationEnableEventsExact(False, eventStateDetail)
        If Not postEnforceEventsStopped Then _
            postEnforceEventsStopped = _
                SetApplicationEnableEventsExact(False, eventStateDetail)
        If Not postEnforceEventsStopped Then _
            AppendBalanceFieldRestoreIssue restoreDetail, _
                "イベント最終安全停止", vbObjectError + 1842, eventStateDetail
    End If
    On Error GoTo 0
    If raiseOnError Then
        Err.Raise eNo, "BuildBalanceInputFields/" & stepName, eDesc & restoreDetail
    Else
        MsgBox "残高欄生成中にエラーが発生しました。" & vbCrLf & _
               "処理: " & stepName & vbCrLf & _
               "Err " & eNo & ": " & eDesc & restoreDetail, vbExclamation
    End If
    Exit Sub

BUILD_BALANCE_RECOVERY_FATAL:
    '下位またはdirect Recoveryの終端後は、AppEnd、診断・保護・状態書込み、
    'entry=Trueへの復元を行わず、fresh Falseだけを再確認して上位へ伝播する。
    If IsSetupRecoveryFatalError(eNo, eSource) Then
        On Error Resume Next
        Call SetApplicationEnableEventsExact(False, eventStateDetail)
        Call SetApplicationEnableEventsExact(False, eventStateDetail)
        On Error GoTo 0
        Err.Raise eNo, eSource, eDesc
    End If
    eventStateDetail = vbNullString
    postEnforceEventsStopped = _
        SetApplicationEnableEventsExact(False, eventStateDetail)
    If Not postEnforceEventsStopped Then _
        postEnforceEventsStopped = _
            SetApplicationEnableEventsExact(False, eventStateDetail)
    If Not postEnforceEventsStopped Then _
        AppendBalanceFieldRestoreIssue restoreDetail, _
            "イベント最終安全停止", vbObjectError + 1842, eventStateDetail
    On Error GoTo 0
    If IsSetupRecoveryFatalError(eNo, eSource) Then _
        Err.Raise eNo, eSource, eDesc
    Err.Raise SETUP_CONVERGE_RECOVERY_FATAL_ERROR, _
              SETUP_CONVERGE_RECOVERY_FATAL_SOURCE & _
                  "BuildBalanceInputFields", _
              "元エラー Err " & CStr(eNo) & " / " & eSource & _
              ": " & eDesc & restoreDetail
End Sub

Public Function EnsureBalanceInputStructureCurrent(ByVal ws As Worksheet, _
                                                   ByRef detailText As String) As Boolean
    '設定だけ更新され、入力欄が旧構成のまま残る処理順を自動収束させる。
    '入力済み残高がある場合は、値を守るため再生成せず明示的に止める。
    '開閉・表示幅・セクション見出しは再生成の理由にしない。
    detailText = vbNullString
    If ws Is Nothing Then
        detailText = "入力シートを取得できません。"
        Exit Function
    End If
    If ValidateBalanceInputStructure(ws, detailText) Then
        EnsureBalanceInputStructureCurrent = True
        Exit Function
    End If
    'C5/C6の残高表示年は取引日・口座日付を再解釈しない。訂正中であっても、
    '残高値とメモが空なら入力中の口座・取引を保持したまま安全に再生成できる。
    '値が一つでもある場合だけ、表示期間外の残高や未保存メモを守るため停止する。
    If HasPendingBalanceInputValues(ws) Then
        detailText = "残高基準の設定と入力欄が一致していません。入力中の残高を保護するため自動再生成しません。" & _
                     "先に現在の口座を登録するか、残高入力を消去してから設定を変更してください。"
        Exit Function
    End If
    BuildBalanceInputFields False, True
    If Not ValidateBalanceInputStructure(ws, detailText) Then Exit Function
    EnsureBalanceInputStructureCurrent = True
End Function

Private Sub ResetBalanceInputArea(ByVal ws As Worksheet)
    Dim rng As Range
    Dim cell As Range
    Dim ma As Range
    Dim errNo As Long

    If ws Is Nothing Then Exit Sub
    Set rng = ws.Range(ws.Cells(BAL_LABEL_ROW, BAL_FIRST_COL), ws.Cells(BAL_DATE_ROW, BAL_MAX_COL))

    On Error Resume Next
    rng.Validation.Delete
    On Error GoTo 0

    '結合セルが残ったままClearすると1004が出ることがあるため、先にMergeArea単位で解除する。
    On Error Resume Next
    For Each cell In rng.Cells
        If cell.MergeCells Then
            Set ma = cell.MergeArea
            If Not ma Is Nothing Then ma.UnMerge
            Set ma = Nothing
        End If
    Next cell
    Err.Clear
    On Error GoTo 0

    On Error Resume Next
    rng.ClearContents
    errNo = Err.Number
    Err.Clear
    On Error GoTo 0
    If errNo <> 0 Then
        For Each cell In rng.Cells
            On Error Resume Next
            cell.ClearContents
            On Error GoTo 0
        Next cell
    End If

    On Error Resume Next
    rng.ClearFormats
    errNo = Err.Number
    Err.Clear
    On Error GoTo 0
    If errNo <> 0 Then
        For Each cell In rng.Cells
            On Error Resume Next
            cell.ClearFormats
            cell.Borders.LineStyle = xlNone
            On Error GoTo 0
        Next cell
    End If
End Sub

Private Sub FormatBalanceInputArea(ByVal ws As Worksheet, ByVal memoCol As Long)
    Dim labelRange As Range
    Dim valueRange As Range
    Dim dateRange As Range
    Dim memoRange As Range
    If ws Is Nothing Then Exit Sub

    Set labelRange = ws.Range(ws.Cells(BAL_LABEL_ROW, BAL_FIRST_COL), ws.Cells(BAL_LABEL_ROW, BAL_MAX_COL))
    Set valueRange = ws.Range(ws.Cells(BAL_VALUE_ROW, BAL_FIRST_COL), ws.Cells(BAL_VALUE_ROW, BAL_MAX_COL))
    Set dateRange = ws.Range(ws.Cells(BAL_DATE_ROW, BAL_FIRST_COL), ws.Cells(BAL_DATE_ROW, BAL_MAX_COL))

    With labelRange
        .Font.Name = "Yu Gothic UI"
        .Font.Bold = True
        .Font.Size = 10
        .Font.Color = RGB(30, 64, 175)
        .Interior.Color = RGB(219, 234, 254)
        .HorizontalAlignment = xlCenter
        .VerticalAlignment = xlCenter
        .Borders.LineStyle = xlContinuous
        .Borders.Color = RGB(147, 197, 253)
        .WrapText = True
        .ShrinkToFit = False
    End With

    With valueRange
        .Font.Name = "Yu Gothic UI"
        .Font.Size = 9.5
        .Font.Bold = False
        .Interior.Color = RGB(248, 250, 252)
        .Font.Color = RGB(15, 23, 42)
        .Borders.LineStyle = xlContinuous
        .VerticalAlignment = xlCenter
    End With

    With dateRange
        .Font.Name = "Yu Gothic UI"
        .Font.Bold = False
        .Interior.Color = RGB(241, 245, 249)
        .Borders.LineStyle = xlContinuous
        .Font.Size = 9
        .Font.Color = RGB(71, 85, 105)
        .HorizontalAlignment = xlCenter
        .NumberFormatLocal = "yyyy/m/d"
    End With

    If memoCol > BAL_FIRST_COL Then ws.Range(ws.Cells(BAL_VALUE_ROW, BAL_FIRST_COL), ws.Cells(BAL_VALUE_ROW, memoCol - 1)).NumberFormatLocal = "#,##0.########"

    Set memoRange = BalanceMemoInputRange(ws)
    If memoRange Is Nothing Then _
        Err.Raise vbObjectError + 1805, "FormatBalanceInputArea", "残高メモ欄を取得できませんでした。"
    memoRange.NumberFormatLocal = "@"
    memoRange.HorizontalAlignment = xlLeft

    ws.Rows(BAL_LABEL_ROW).RowHeight = 48
    ws.Rows(BAL_VALUE_ROW).RowHeight = 25
    ws.Rows(BAL_DATE_ROW).RowHeight = 18
End Sub

Public Sub ApplyInputSettings(Optional ByVal showDoneMessage As Boolean = True, _
                              Optional ByVal raiseOnError As Boolean = False)
    '内部処理と旧版ボタン互換用。現行の設定パネルでは、書式・Tab操作も含む
    'RestoreToolFormattingへ利用者向け復旧操作を一本化している。
    Dim ws As Worksheet
    Dim memoCol As Long, c As Long
    Dim memoRange As Range
    Dim entryEvents As Boolean, entryEventsCaptured As Boolean
    Dim mutationStarted As Boolean, cleanupEventsStopped As Boolean
    Dim eventsRestored As Boolean, safeToRestoreEntry As Boolean
    Dim protectionRestored As Boolean, keyBindingsRestored As Boolean
    Dim recoveryDualConfirmed As Boolean, applicationStateRestored As Boolean
    Dim eventStateDetail As String, eventRestoreDetail As String
    Dim cleanupDetail As String, recoveryDetail As String
    Dim recoveryConfirmationDetail As String, applicationStateProblems As String
    Dim protectionErrorNumber As Long, protectionErrorDescription As String
    Dim protectionErrorSource As String
    Dim keyErrorNumber As Long, keyErrorDescription As String
    Dim recoveryErrorNumber As Long, recoveryErrorDescription As String
    Dim appEndErrorNumber As Long, appEndErrorDescription As String
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim recoveryAttempted As Boolean, terminalRecoveryFailure As Boolean
    Dim finalEventsStopped As Boolean
    On Error GoTo EH
    If Not SheetExists(SH_INPUT) Then Exit Sub
    If Not TryGetSetupEnableEvents(entryEvents, eventStateDetail) Then _
        Err.Raise vbObjectError + 1840, "ApplyInputSettings", _
                  "入力欄設定前のイベント状態を一意に保存できません。 " & _
                  eventStateDetail
    entryEventsCaptured = True
    If Not SetApplicationEnableEventsExact(False, eventStateDetail) Then _
        Err.Raise vbObjectError + 1841, "ApplyInputSettings", _
                  "入力欄設定中のイベント停止を一意に確認できません。 " & _
                  eventStateDetail
    Set ws = GetSheet(SH_INPUT)
    mutationStarted = True
    ws.Unprotect Password:=TOOL_PASSWORD
    '再整形処理は一度入力欄を開け直す。読取専用ロックのキャッシュを失効させ、
    '正常終了・途中失敗のどちらでもProtectInputSheetが実セルを再ロックするようにする。
    If ThisWorkbook.ReadOnly Then mInputReadOnlyLocked = False
    RefreshAccountCandidateNames
    ApplyValidationList ws.Range(CELL_BANK), NM_LST_BANK_CAND, xlIMEModeHiragana, True, _
                        "銀行名（必須）", "候補から選ぶか、正式名称を直接入力します。"
    ApplyValidationList ws.Range(CELL_BRANCH), NM_LST_BRANCH_CAND, xlIMEModeHiragana, True, _
                        "支店名", "候補から選ぶか、支店名を直接入力します。"
    ApplyValidationList ws.Range(CELL_PERSON), NM_LST_PERSON_CAND, xlIMEModeHiragana, True, _
                        "氏名（必須）", "口座名義人の氏名を入力します。"
    ApplyValidationInputOnly ws.Range(CELL_RELATIONSHIP), xlIMEModeHiragana, _
                             "続柄", "必要な場合だけ入力します。設定で表示を切り替えられます。"
    ApplyValidationList ws.Range(CELL_ACCOUNT_TYPE), NM_LST_ACCOUNT_TYPE, xlIMEModeHiragana, True, _
                        "科目（必須）", "普通・定期などを候補から選ぶか直接入力します。"
    ApplyValidationInputOnly ws.Range(CELL_ACCOUNT_NO), xlIMEModeOff, _
                             "口座番号（必須）", "記号・ハイフンを含めて入力できます。"
    ApplyValidationInputOnly ws.Range(CELL_OPEN_DATE), xlIMEModeOff, _
                             "開設日", "例：2023/5/1。和暦数字（3.1.5.1）も入力できます。"
    ApplyValidationInputOnly ws.Range(CELL_CLOSE_DATE), xlIMEModeOff, _
                             "解約日", "未解約なら空欄。和暦数字（3.1.5.1）も入力できます。"
    memoCol = BalanceMemoCol(ws)
    '横一括設定は、結合・非表示列を含む一部Office環境で右端セルだけ規則が欠落する。
    '最大20セルなので1セルずつ作成・読戻しし、Q:Vを含む全残高欄を確実に整える。
    For c = BAL_FIRST_COL To memoCol - 1
        ApplyValidationInputOnly ws.Cells(BAL_VALUE_ROW, c), xlIMEModeOff, _
                                 "基準日残高", _
                                 "金額を数字で入力します。対象外の期間は自動で入力不可になります。"
    Next c
    Set memoRange = BalanceMemoInputRange(ws)
    If memoRange Is Nothing Then _
        Err.Raise vbObjectError + 1806, "ApplyInputSettings", "残高メモ欄を取得できませんでした。"
    ApplyValidationInputOnly memoRange, xlIMEModeHiragana, _
                             "残高メモ", "残高に関する補足だけを入力します。"
    ApplyValidationInputOnly ws.Range(ws.Cells(TX_FIRST_ROW, COL_TX_YEAR), _
                                      ws.Cells(TX_LAST_ROW, COL_TX_YEAR)), _
                             xlIMEModeOff, "年", "最初の行と年が変わる行に入力します。"
    ApplyValidationInputOnly ws.Range(ws.Cells(TX_FIRST_ROW, COL_TX_MONTH), _
                                      ws.Cells(TX_LAST_ROW, COL_TX_MONTH)), _
                             xlIMEModeOff, "月", "月が変わる行に入力します。前行から自動補完されます。"
    ApplyValidationInputOnly ws.Range(ws.Cells(TX_FIRST_ROW, COL_TX_DAY), _
                                      ws.Cells(TX_LAST_ROW, COL_TX_DAY)), _
                             xlIMEModeOff, "日", "日を数字で入力します。"
    ApplyValidationInputOnly ws.Range(ws.Cells(TX_FIRST_ROW, COL_TX_TIME), _
                                      ws.Cells(TX_LAST_ROW, COL_TX_TIME)), _
                             xlIMEModeOff, "時刻", "930 または 09:30 の形式で入力できます。"
    ApplyValidationInputOnly ws.Range(ws.Cells(TX_FIRST_ROW, COL_TX_WITHDRAW), _
                                      ws.Cells(TX_LAST_ROW, COL_TX_DEPOSIT)), _
                             xlIMEModeOff, "出金・入金", "いずれか片方に金額を数字で入力します。"
    ApplyValidationInputOnly ws.Range(ws.Cells(TX_FIRST_ROW, COL_TX_SHOP), _
                                      ws.Cells(TX_LAST_ROW, COL_TX_MACHINE)), _
                             xlIMEModeOff, "店・機番", "通帳記載どおりに入力します。"
    ApplyValidationList ws.Range(ws.Cells(TX_FIRST_ROW, COL_TX_TEKIYO), _
                                 ws.Cells(TX_LAST_ROW, COL_TX_TEKIYO)), _
                        NM_LST_TEKIYO, xlIMEModeHiragana, True, _
                        "摘要", "候補から選ぶか、通帳記載を直接入力します。"
    ApplyValidationInputOnly ws.Range(ws.Cells(TX_FIRST_ROW, COL_TX_BALANCE), _
                                      ws.Cells(TX_LAST_ROW, COL_TX_BALANCE)), _
                             xlIMEModeOff, "取引後残高", "必要な場合だけ金額を入力します。"
    '設定シートの入力規則はApplyConfigValidationsだけが更新する。
    '入力シート再整形のたびに保護中の設定シートへ触れると、Excel環境によって
    'Validation.Deleteだけが成功してAddが失敗し、設定候補が一括欠落するため分離する。
    ws.Range(CELL_BANK).NumberFormatLocal = "@"
    ws.Range(CELL_BRANCH).NumberFormatLocal = "@"
    ws.Range(CELL_PERSON).NumberFormatLocal = "@"
    ws.Range(CELL_RELATIONSHIP).NumberFormatLocal = "@"
    ws.Range(CELL_ACCOUNT_TYPE).NumberFormatLocal = "@"
    ws.Range(CELL_ACCOUNT_NO).NumberFormatLocal = "@"
    '開設日・解約日は入力補助で実日付に正規化するため、表示は日付形式に固定する。
    '文字列書式に戻すと、書式復旧後に日付シリアル値が見える恐れがある。
    ws.Range(CELL_OPEN_DATE).NumberFormatLocal = "yyyy/m/d"
    ws.Range(CELL_CLOSE_DATE).NumberFormatLocal = "yyyy/m/d"
    ws.Range(ws.Cells(TX_FIRST_ROW, COL_TX_TIME), ws.Cells(TX_LAST_ROW, COL_TX_TIME)).NumberFormatLocal = "@"
    ws.Range(ws.Cells(TX_FIRST_ROW, COL_TX_TIME), ws.Cells(TX_LAST_ROW, COL_TX_TIME)).HorizontalAlignment = xlRight
    ws.Range(ws.Cells(TX_FIRST_ROW, COL_TX_SHOP), ws.Cells(TX_LAST_ROW, COL_TX_MACHINE)).NumberFormatLocal = "@"
    ws.Range(ws.Cells(TX_FIRST_ROW, COL_TX_TEKIYO), ws.Cells(TX_LAST_ROW, COL_TX_TEKIYO)).NumberFormatLocal = "@"
    ws.Range(ws.Cells(TX_FIRST_ROW, COL_TX_WITHDRAW), ws.Cells(TX_LAST_ROW, COL_TX_DEPOSIT)).NumberFormatLocal = "#,##0.########"
    ws.Range(ws.Cells(TX_FIRST_ROW, COL_TX_BALANCE), ws.Cells(TX_LAST_ROW, COL_TX_BALANCE)).NumberFormatLocal = "#,##0.########"
    ws.Cells.Locked = True
    UnlockRange ws.Range(CELL_BANK)
    UnlockRange ws.Range(CELL_BRANCH)
    UnlockRange ws.Range(CELL_PERSON)
    ApplyRelationshipFieldState ws
    UnlockRange ws.Range(CELL_ACCOUNT_TYPE)
    UnlockRange ws.Range(CELL_ACCOUNT_NO)
    UnlockRange ws.Range(CELL_OPEN_DATE)
    UnlockRange ws.Range(CELL_CLOSE_DATE)
    If memoCol > BAL_FIRST_COL Then UnlockRange ws.Range(ws.Cells(BAL_VALUE_ROW, BAL_FIRST_COL), ws.Cells(BAL_VALUE_ROW, memoCol - 1))
    UnlockRange memoRange
    ApplyBalanceAvailability ws
    UnlockTransactionInputCells ws
    ProtectInputSheet True
    EnableInputKeys
    If Not SetApplicationEnableEventsExact(False, eventStateDetail) Then _
        Err.Raise vbObjectError + 1843, "ApplyInputSettings", _
                  "入力欄設定の終了前にイベント停止を再確認できません。 " & _
                  eventStateDetail
    safeToRestoreEntry = True
    If Not TryRestoreSetupProtectionEntryEvents( _
               entryEventsCaptured, entryEvents, eventRestoreDetail) Then _
        Err.Raise vbObjectError + 1842, "ApplyInputSettings", _
                  "入力欄設定前のイベント状態を復元できません。 " & _
                  eventRestoreDetail
    entryEventsCaptured = False
    If showDoneMessage Then MsgBox "入力欄設定を更新しました。", vbInformation
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    terminalRecoveryFailure = _
        IsSetupRecoveryFatalError(errorNumber, errorSource)
    If terminalRecoveryFailure Then
        On Error Resume Next
        Call SetApplicationEnableEventsExact(False, eventStateDetail)
        Call SetApplicationEnableEventsExact(False, eventStateDetail)
        On Error GoTo 0
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    On Error Resume Next
    cleanupEventsStopped = False
    If entryEventsCaptured Then _
        cleanupEventsStopped = _
            SetApplicationEnableEventsExact(False, eventStateDetail)
    safeToRestoreEntry = (Not mutationStarted) And cleanupEventsStopped
    If mutationStarted And cleanupEventsStopped Then
        Err.Clear
        ProtectInputSheet True
        protectionErrorNumber = Err.Number
        protectionErrorDescription = Err.Description
        protectionErrorSource = Err.Source
        protectionRestored = (protectionErrorNumber = 0)
        Err.Clear
        cleanupEventsStopped = _
            SetApplicationEnableEventsExact(False, eventStateDetail)
        If Not cleanupEventsStopped Then _
            cleanupEventsStopped = _
                SetApplicationEnableEventsExact(False, eventStateDetail)
        If IsSetupRecoveryFatalError( _
               protectionErrorNumber, protectionErrorSource) Then
            Call SetApplicationEnableEventsExact(False, eventStateDetail)
            Call SetApplicationEnableEventsExact(False, eventStateDetail)
            On Error GoTo 0
            Err.Raise protectionErrorNumber, protectionErrorSource, _
                      protectionErrorDescription
        End If
        If cleanupEventsStopped Then
            EnableInputKeys
            keyErrorNumber = Err.Number
            keyErrorDescription = Err.Description
            keyBindingsRestored = (keyErrorNumber = 0)
            Err.Clear
            cleanupEventsStopped = _
                SetApplicationEnableEventsExact(False, eventStateDetail)
            If Not cleanupEventsStopped Then _
                cleanupEventsStopped = _
                    SetApplicationEnableEventsExact(False, eventStateDetail)
        End If
        If protectionErrorNumber <> 0 Then
            cleanupDetail = "入力シートの緊急再保護: Err " & _
                            CStr(protectionErrorNumber) & " " & _
                            protectionErrorDescription
        End If
        If keyErrorNumber <> 0 Then
            If Len(cleanupDetail) > 0 Then cleanupDetail = cleanupDetail & " / "
            cleanupDetail = cleanupDetail & "入力キー割当の復旧: Err " & _
                            CStr(keyErrorNumber) & " " & keyErrorDescription
        End If
        safeToRestoreEntry = protectionRestored And keyBindingsRestored And _
                             cleanupEventsStopped
        If Not safeToRestoreEntry And cleanupEventsStopped Then
            recoveryDetail = _
                "入力欄設定の失敗後に再保護または入力キー復旧を確認できません。"
            If Len(cleanupDetail) > 0 Then _
                AppendSetupRestoreDetail recoveryDetail, cleanupDetail
            Err.Clear
            recoveryAttempted = True
            EnforceRollbackRecoveryState recoveryDetail
            recoveryErrorNumber = Err.Number
            recoveryErrorDescription = Err.Description
            Err.Clear
            cleanupEventsStopped = _
                SetApplicationEnableEventsExact(False, eventStateDetail)
            If Not cleanupEventsStopped Then _
                cleanupEventsStopped = _
                    SetApplicationEnableEventsExact(False, eventStateDetail)
            terminalRecoveryFailure = True
            GoTo APPLY_INPUT_RECOVERY_FATAL
        End If
        If Len(cleanupDetail) > 0 Then _
            errorDescription = errorDescription & " / " & cleanupDetail
    ElseIf mutationStarted Then
        errorDescription = errorDescription & _
            " / イベント停止を確認できないため再保護・復旧表示・保存状態への書込みを実行していません。" & _
            IIf(Len(eventStateDetail) > 0, " " & eventStateDetail, vbNullString)
    End If
    eventsRestored = False
    If entryEventsCaptured And safeToRestoreEntry Then
        eventRestoreDetail = vbNullString
        eventsRestored = TryRestoreSetupProtectionEntryEvents( _
                             entryEventsCaptured, entryEvents, eventRestoreDetail)
        If Not eventsRestored Then _
            errorDescription = errorDescription & _
                " / イベント開始値の復元未完了: " & eventRestoreDetail
    ElseIf entryEventsCaptured Then
        eventRestoreDetail = vbNullString
        cleanupEventsStopped = _
            SetApplicationEnableEventsExact(False, eventRestoreDetail)
        If Not cleanupEventsStopped Then _
            cleanupEventsStopped = _
                SetApplicationEnableEventsExact(False, eventRestoreDetail)
        If cleanupEventsStopped Then
            errorDescription = errorDescription & _
                " / 安全条件を確認できないため、イベントをFalseのまま停止しました。"
        Else
            errorDescription = errorDescription & _
                " / イベントをFalseへ収束できず、現在状態は不明です。 " & _
                eventRestoreDetail
        End If
    End If
    On Error GoTo 0
    If raiseOnError Then
        Err.Raise errorNumber, "ApplyInputSettings", errorDescription
    Else
        MsgBox "入力欄設定中にエラーが発生しました。" & vbCrLf & "Err " & errorNumber & ": " & errorDescription, vbExclamation
    End If
    Exit Sub

APPLY_INPUT_RECOVERY_FATAL:
    If IsSetupRecoveryFatalError(errorNumber, errorSource) Then
        On Error Resume Next
        Call SetApplicationEnableEventsExact(False, eventRestoreDetail)
        Call SetApplicationEnableEventsExact(False, eventRestoreDetail)
        On Error GoTo 0
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    eventRestoreDetail = vbNullString
    cleanupEventsStopped = _
        SetApplicationEnableEventsExact(False, eventRestoreDetail)
    If Not cleanupEventsStopped Then _
        cleanupEventsStopped = _
            SetApplicationEnableEventsExact(False, eventRestoreDetail)
    If Not cleanupEventsStopped Then
        If Not IsSetupRecoveryFatalError(errorNumber, errorSource) Then _
            AppendSetupRestoreDetail errorDescription, _
                "terminal Recovery後もExcelイベントをFalseへ収束できません。 " & _
                eventRestoreDetail
    End If
    On Error GoTo 0
    If IsSetupRecoveryFatalError(errorNumber, errorSource) Then _
        Err.Raise errorNumber, errorSource, errorDescription
    Err.Raise SETUP_CONVERGE_RECOVERY_FATAL_ERROR, _
              SETUP_CONVERGE_RECOVERY_FATAL_SOURCE & "ApplyInputSettings", _
              "元エラー Err " & CStr(errorNumber) & " / " & _
              errorSource & ": " & errorDescription
End Sub

Private Sub UnlockTransactionInputCells(ByVal ws As Worksheet)
    If ws Is Nothing Then Exit Sub
    ApplyTransactionInputLockPlan ws
End Sub

Private Function TransactionModeUsesColumn(ByVal modeText As String, _
                                           ByVal columnNo As Long) As Boolean
    Select Case columnNo
        Case COL_TX_DAY, COL_TX_WITHDRAW, COL_TX_DEPOSIT, COL_TX_SHOP
            TransactionModeUsesColumn = True
        Case COL_TX_TIME
            TransactionModeUsesColumn = _
                (modeText <> MODE_SIMPLE And modeText <> MODE_NO_TIME)
        Case COL_TX_MACHINE
            TransactionModeUsesColumn = _
                (modeText <> MODE_SIMPLE And modeText <> MODE_NO_MACHINE)
        Case COL_TX_TEKIYO
            TransactionModeUsesColumn = _
                (modeText <> MODE_SIMPLE And modeText <> MODE_NO_TEKIYO)
        Case COL_TX_BALANCE
            TransactionModeUsesColumn = _
                (modeText = MODE_WITH_OTHER Or modeText = "その他あり")
    End Select
End Function

Private Function TransactionAmountCellIsEmptyForLockPlan( _
        ByVal targetCell As Range) As Boolean
    If targetCell Is Nothing Then Exit Function
    If targetCell.HasFormula Or IsError(targetCell.Value) Then Exit Function
    TransactionAmountCellIsEmptyForLockPlan = Not HasText(targetCell.Value)
End Function

Private Sub ApplyTransactionAmountLockRows(ByVal ws As Worksheet, _
                                           ByVal firstRow As Long, _
                                           ByVal lastRow As Long)
    Dim r As Long
    Dim withdrawHasValue As Boolean, depositHasValue As Boolean
    If ws Is Nothing Then Exit Sub
    firstRow = Application.Max(TX_FIRST_ROW, firstRow)
    lastRow = Application.Min(TX_LAST_ROW, lastRow)
    If lastRow < firstRow Then Exit Sub
    For r = firstRow To lastRow
        If ws.Columns(COL_TX_WITHDRAW).Hidden Or _
           ws.Columns(COL_TX_DEPOSIT).Hidden Then
            ws.Cells(r, COL_TX_WITHDRAW).Locked = True
            ws.Cells(r, COL_TX_DEPOSIT).Locked = True
            GoTo NextAmountLockRow
        End If
        withdrawHasValue = Not TransactionAmountCellIsEmptyForLockPlan( _
                                   ws.Cells(r, COL_TX_WITHDRAW))
        depositHasValue = Not TransactionAmountCellIsEmptyForLockPlan( _
                                  ws.Cells(r, COL_TX_DEPOSIT))
        '片側だけ確定した行は反対側を標準Tab stopから外す。
        '両方空欄は利用者が入出金を選べるよう両側を開け、両方入力・数式・
        'エラーは修正対象なので両側を開けたまま検証へ渡す。
        ws.Cells(r, COL_TX_WITHDRAW).Locked = _
            (depositHasValue And Not withdrawHasValue)
        ws.Cells(r, COL_TX_DEPOSIT).Locked = _
            (withdrawHasValue And Not depositHasValue)
NextAmountLockRow:
    Next r
End Sub

Private Sub ApplyTransactionInputLockPlan(ByVal ws As Worksheet)
    Dim modeText As String
    Dim c As Long, lastDataRow As Long, activeRow As Long
    If ws Is Nothing Then Exit Sub
    modeText = GetInputMode()
    activeRow = TX_FIRST_ROW
    If ActiveWorkbook Is ThisWorkbook Then
        If TypeName(ActiveSheet) = "Worksheet" Then
            If ActiveSheet Is ws Then
                If ActiveCell.Row >= TX_FIRST_ROW And ActiveCell.Row <= TX_LAST_ROW Then _
                    activeRow = ActiveCell.Row
            End If
        End If
    End If
    mCurrentTransactionLockRow = activeRow

    'PLAN→APPLY: 最初に全明細を閉じ、現在モードで使う列だけを範囲単位で開く。
    ws.Range(ws.Cells(TX_FIRST_ROW, COL_TX_YEAR), _
             ws.Cells(TX_LAST_ROW, COL_TX_BALANCE)).Locked = True
    For c = COL_TX_DAY To COL_TX_BALANCE
        If TransactionModeUsesColumn(modeText, c) Then
            If Not ws.Columns(c).Hidden Then _
                ws.Range(ws.Cells(TX_FIRST_ROW, c), _
                         ws.Cells(TX_LAST_ROW, c)).Locked = False
        End If
    Next c

    '年・月は最初の行と現在行だけを開く。次行はD列を入口にし、選択後に
    'その行のB:Cを開くため、通常Tabが空の年・月へ一瞬止まらない。
    For c = COL_TX_YEAR To COL_TX_MONTH
        If Not ws.Columns(c).Hidden Then
            ws.Cells(TX_FIRST_ROW, c).Locked = False
            ws.Cells(activeRow, c).Locked = False
        End If
    Next c

    lastDataRow = LastDataRowInColumns(ws, COL_TX_YEAR, COL_TX_BALANCE)
    If lastDataRow < TX_FIRST_ROW Then lastDataRow = TX_FIRST_ROW
    lastDataRow = Application.Max(lastDataRow, activeRow)
    ApplyTransactionAmountLockRows ws, TX_FIRST_ROW, lastDataRow
    VerifyTransactionInputLockPlan ws, modeText, activeRow, lastDataRow
End Sub

Private Sub VerifyTransactionInputLockPlan( _
        ByVal ws As Worksheet, ByVal modeText As String, _
        ByVal activeRow As Long, ByVal lastDataRow As Long)
    Dim c As Long, r As Long
    Dim withdrawHasValue As Boolean, depositHasValue As Boolean
    Dim expectedLocked As Boolean
    '入出金以外は列全体が同じ計画になる。表示中の必要列が
    '開いていることと、非表示または現在モードで不要な列が閉じていることを両方読み戻す。
    For c = COL_TX_DAY To COL_TX_BALANCE
        If c <> COL_TX_WITHDRAW And c <> COL_TX_DEPOSIT Then
            expectedLocked = Not TransactionModeUsesColumn(modeText, c) Or _
                             CBool(ws.Columns(c).Hidden)
            If Not RangeHasLockedState(ws.Range(ws.Cells(TX_FIRST_ROW, c), _
                                                ws.Cells(TX_LAST_ROW, c)), _
                                       expectedLocked) Then _
                Err.Raise vbObjectError + 1811, "VerifyTransactionInputLockPlan", _
                          "取引列の表示・モード・入力可否が一致しません: " & _
                          ws.Cells(TX_HEADER_ROW, c).Address(False, False)
        End If
    Next c
    For c = COL_TX_YEAR To COL_TX_MONTH
        If Not RangeHasLockedState(ws.Cells(activeRow, c), _
                                   CBool(ws.Columns(c).Hidden)) Then _
            Err.Raise vbObjectError + 1812, "VerifyTransactionInputLockPlan", _
                      "現在行の年・月の表示・入力可否が一致しません。"
    Next c
    If activeRow <> TX_FIRST_ROW Then
        For c = COL_TX_YEAR To COL_TX_MONTH
            If Not RangeHasLockedState(ws.Cells(TX_FIRST_ROW, c), _
                                       CBool(ws.Columns(c).Hidden)) Then _
                Err.Raise vbObjectError + 1822, "VerifyTransactionInputLockPlan", _
                          "最初の取引行の年・月入力可否が一致しません。"
        Next c
    End If
    If activeRow > TX_FIRST_ROW + 1 Then
        If Not RangeHasLockedState(ws.Range( _
                ws.Cells(TX_FIRST_ROW + 1, COL_TX_YEAR), _
                ws.Cells(activeRow - 1, COL_TX_MONTH)), True) Then _
            Err.Raise vbObjectError + 1820, "VerifyTransactionInputLockPlan", _
                      "現在行より前の年・月に不要なTab stopが残っています。"
    End If
    If activeRow < TX_LAST_ROW Then
        If Not RangeHasLockedState(ws.Range( _
                ws.Cells(activeRow + 1, COL_TX_YEAR), _
                ws.Cells(TX_LAST_ROW, COL_TX_MONTH)), True) Then _
            Err.Raise vbObjectError + 1821, "VerifyTransactionInputLockPlan", _
                      "現在行より後の年・月に不要なTab stopが残っています。"
    End If
    For r = TX_FIRST_ROW To lastDataRow
        withdrawHasValue = Not TransactionAmountCellIsEmptyForLockPlan( _
                                   ws.Cells(r, COL_TX_WITHDRAW))
        depositHasValue = Not TransactionAmountCellIsEmptyForLockPlan( _
                                  ws.Cells(r, COL_TX_DEPOSIT))
        If ws.Columns(COL_TX_WITHDRAW).Hidden Or _
           ws.Columns(COL_TX_DEPOSIT).Hidden Then
            If Not RangeHasLockedState(ws.Cells(r, COL_TX_WITHDRAW), True) Or _
               Not RangeHasLockedState(ws.Cells(r, COL_TX_DEPOSIT), True) Then _
                Err.Raise vbObjectError + 1813, "VerifyTransactionInputLockPlan", _
                          CStr(r) & "行目の非表示金額欄が入力可能です。"
        Else
            If Not RangeHasLockedState(ws.Cells(r, COL_TX_WITHDRAW), _
                                       depositHasValue And Not withdrawHasValue) Or _
               Not RangeHasLockedState(ws.Cells(r, COL_TX_DEPOSIT), _
                                       withdrawHasValue And Not depositHasValue) Then _
                Err.Raise vbObjectError + 1814, "VerifyTransactionInputLockPlan", _
                          CStr(r) & "行目の入出金ロック計画が一致しません。"
        End If
    Next r
End Sub


Private Sub ApplyVisibleInputFieldLockPlan(ByVal ws As Worksheet)
    Dim memoRange As Range, memoCol As Long
    Dim openVisible As Boolean, closeVisible As Boolean, balancesVisible As Boolean
    If ws Is Nothing Then Exit Sub
    openVisible = Not CBool(ws.Rows(ws.Range(CELL_OPEN_DATE).Row).Hidden)
    closeVisible = Not CBool(ws.Rows(ws.Range(CELL_CLOSE_DATE).Row).Hidden)
    balancesVisible = Not CBool(ws.Rows(BAL_VALUE_ROW).Hidden)

    EffectiveRange(ws.Range(CELL_OPEN_DATE)).Locked = Not openVisible
    EffectiveRange(ws.Range(CELL_CLOSE_DATE)).Locked = Not closeVisible
    memoCol = BalanceMemoCol(ws)
    Set memoRange = BalanceMemoInputRange(ws)
    If balancesVisible Then
        If memoCol > BAL_FIRST_COL Then _
            ws.Range(ws.Cells(BAL_VALUE_ROW, BAL_FIRST_COL), _
                     ws.Cells(BAL_VALUE_ROW, memoCol - 1)).Locked = False
        If Not memoRange Is Nothing Then memoRange.Locked = False
        ApplyBalanceAvailability ws
    Else
        If memoCol > BAL_FIRST_COL Then _
            ws.Range(ws.Cells(BAL_VALUE_ROW, BAL_FIRST_COL), _
                     ws.Cells(BAL_VALUE_ROW, memoCol - 1)).Locked = True
        If Not memoRange Is Nothing Then memoRange.Locked = True
    End If

    'READBACK: 非表示欄を標準Tab stopへ残さず、表示欄だけを入力可能にする。
    If Not RangeHasLockedState(EffectiveRange(ws.Range(CELL_OPEN_DATE)), _
                               Not openVisible) Then _
        Err.Raise vbObjectError + 1815, "ApplyVisibleInputFieldLockPlan", _
                  "開設日欄の表示・入力可否が一致しません。"
    If Not RangeHasLockedState(EffectiveRange(ws.Range(CELL_CLOSE_DATE)), _
                               Not closeVisible) Then _
        Err.Raise vbObjectError + 1816, "ApplyVisibleInputFieldLockPlan", _
                  "解約日欄の表示・入力可否が一致しません。"
    If Not balancesVisible And Not memoRange Is Nothing Then
        If Not RangeHasLockedState(memoRange, True) Then _
            Err.Raise vbObjectError + 1817, "ApplyVisibleInputFieldLockPlan", _
                      "非表示の残高メモ欄が入力可能なままです。"
    End If
End Sub

Public Sub ConvergeInputTransactionLockPlan(ByVal ws As Worksheet, _
                                             Optional ByVal changedTarget As Range)
    Dim desiredRow As Long, previousRow As Long
    Dim firstChangedRow As Long, lastChangedRow As Long, c As Long, r As Long
    Dim withdrawHasValue As Boolean, depositHasValue As Boolean
    Dim amountTarget As Range, area As Range
    Dim workbookWasSaved As Boolean, emergencyProtected As Boolean
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim recoveryErrorNumber As Long, recoveryErrorDescription As String
    Dim emergencyDetail As String, recoveryDetail As String
    Dim cleanupEventsStopped As Boolean, eventStateDetail As String
    Dim recoveryDualConfirmed As Boolean, applicationStateRestored As Boolean
    Dim recoveryConfirmationDetail As String, applicationStateProblems As String
    If ws Is Nothing Or ThisWorkbook.ReadOnly Then Exit Sub
    If ws.Name <> SH_INPUT Then Exit Sub
    workbookWasSaved = ThisWorkbook.Saved
    On Error GoTo EH
    desiredRow = mCurrentTransactionLockRow
    If Not Application.ActiveCell Is Nothing Then
        If Application.ActiveCell.Worksheet Is ws Then
            If Application.ActiveCell.Row >= TX_FIRST_ROW And _
               Application.ActiveCell.Row <= TX_LAST_ROW Then _
                desiredRow = Application.ActiveCell.Row
        End If
    End If
    If desiredRow < TX_FIRST_ROW Or desiredRow > TX_LAST_ROW Then _
        desiredRow = TX_FIRST_ROW
    If Not changedTarget Is Nothing Then
        Set amountTarget = Intersect(changedTarget, _
            ws.Range(ws.Cells(TX_FIRST_ROW, COL_TX_WITHDRAW), _
                     ws.Cells(TX_LAST_ROW, COL_TX_DEPOSIT)))
        If Not amountTarget Is Nothing Then
            firstChangedRow = TX_LAST_ROW
            For Each area In amountTarget.Areas
                firstChangedRow = Application.Min(firstChangedRow, area.Row)
                lastChangedRow = Application.Max(lastChangedRow, _
                                     area.Row + area.Rows.Count - 1)
            Next area
            firstChangedRow = Application.Max(TX_FIRST_ROW, firstChangedRow)
            lastChangedRow = Application.Min(TX_LAST_ROW, lastChangedRow)
        End If
    End If
    If desiredRow = mCurrentTransactionLockRow And _
       lastChangedRow < firstChangedRow Then Exit Sub

    '選択・変更イベントの後に前行B:Cを閉じ、現在行と変更行の金額対だけを更新する。
    '全1万行の保護計画を毎回再計算しないため、通常行移動は一定時間で収束する。
    ws.Unprotect Password:=TOOL_PASSWORD
    previousRow = mCurrentTransactionLockRow
    If previousRow >= TX_FIRST_ROW And previousRow <= TX_LAST_ROW And _
       previousRow <> TX_FIRST_ROW And previousRow <> desiredRow Then _
        ws.Range(ws.Cells(previousRow, COL_TX_YEAR), _
                 ws.Cells(previousRow, COL_TX_MONTH)).Locked = True
    For c = COL_TX_YEAR To COL_TX_MONTH
        ws.Cells(desiredRow, c).Locked = CBool(ws.Columns(c).Hidden)
    Next c
    mCurrentTransactionLockRow = desiredRow
    If lastChangedRow >= firstChangedRow Then _
        ApplyTransactionAmountLockRows ws, firstChangedRow, lastChangedRow
    ws.Protect Password:=TOOL_PASSWORD, DrawingObjects:=True, Contents:=True, _
               Scenarios:=False, UserInterfaceOnly:=True, AllowFiltering:=True, _
               AllowSorting:=False, AllowFormattingCells:=False, _
               AllowFormattingColumns:=False, AllowFormattingRows:=False
    ws.EnableSelection = xlUnlockedCells
    If Not ws.ProtectContents Or Not ws.ProtectDrawingObjects Or _
       ws.EnableSelection <> xlUnlockedCells Then _
        Err.Raise vbObjectError + 1818, "ConvergeInputTransactionLockPlan", _
                  "入力行の保護を再適用できません。"
    For c = COL_TX_YEAR To COL_TX_MONTH
        If Not RangeHasLockedState(ws.Cells(desiredRow, c), _
                                   CBool(ws.Columns(c).Hidden)) Then _
            Err.Raise vbObjectError + 1819, "ConvergeInputTransactionLockPlan", _
                      "現在行の年・月の表示・入力可否を読み戻せません。"
    Next c
    If previousRow >= TX_FIRST_ROW And previousRow <= TX_LAST_ROW And _
       previousRow <> TX_FIRST_ROW And previousRow <> desiredRow Then
        If Not RangeHasLockedState(ws.Range( _
                ws.Cells(previousRow, COL_TX_YEAR), _
                ws.Cells(previousRow, COL_TX_MONTH)), True) Then _
            Err.Raise vbObjectError + 1823, "ConvergeInputTransactionLockPlan", _
                      "移動前の行に年・月のTab stopが残っています。"
    End If
    If lastChangedRow >= firstChangedRow Then
        For r = firstChangedRow To lastChangedRow
            withdrawHasValue = Not TransactionAmountCellIsEmptyForLockPlan( _
                                       ws.Cells(r, COL_TX_WITHDRAW))
            depositHasValue = Not TransactionAmountCellIsEmptyForLockPlan( _
                                      ws.Cells(r, COL_TX_DEPOSIT))
            If ws.Columns(COL_TX_WITHDRAW).Hidden Or _
               ws.Columns(COL_TX_DEPOSIT).Hidden Then
                If Not RangeHasLockedState(ws.Cells(r, COL_TX_WITHDRAW), True) Or _
                   Not RangeHasLockedState(ws.Cells(r, COL_TX_DEPOSIT), True) Then _
                    Err.Raise vbObjectError + 1824, "ConvergeInputTransactionLockPlan", _
                              CStr(r) & "行目の非表示金額欄をロックできません。"
            ElseIf Not RangeHasLockedState(ws.Cells(r, COL_TX_WITHDRAW), _
                                          depositHasValue And Not withdrawHasValue) Or _
                   Not RangeHasLockedState(ws.Cells(r, COL_TX_DEPOSIT), _
                                          withdrawHasValue And Not depositHasValue) Then
                Err.Raise vbObjectError + 1825, "ConvergeInputTransactionLockPlan", _
                          CStr(r) & "行目の入出金ロックを読み戻せません。"
            End If
        Next r
    End If
    If workbookWasSaved Then ThisWorkbook.Saved = True
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    emergencyProtected = TryEmergencyProtectSetupSheet(ws, emergencyDetail)
    If Not emergencyProtected Then
        recoveryDetail = "入力行ロック計画の緊急再保護を確認できません。"
        AppendSetupRestoreDetail recoveryDetail, emergencyDetail
        On Error Resume Next
        Err.Clear
        EnforceRollbackRecoveryState recoveryDetail
        recoveryErrorNumber = Err.Number
        recoveryErrorDescription = Err.Description
        Err.Clear
        'Recoveryを一度でも試行した経路はterminalとして呼出元へ伝える。
        '失敗時はfresh Falseだけ、成功時もpost-False、二重状態、
        'Application状態、final Falseの順序を確認し、通常cleanupへ戻らない。
        cleanupEventsStopped = _
            SetApplicationEnableEventsExact(False, eventStateDetail)
        If Not cleanupEventsStopped Then _
            cleanupEventsStopped = _
                SetApplicationEnableEventsExact(False, eventStateDetail)
        On Error GoTo 0
        Err.Raise SETUP_CONVERGE_RECOVERY_FATAL_ERROR, _
                  SETUP_CONVERGE_RECOVERY_FATAL_SOURCE & _
                      "ConvergeInputTransactionLockPlan", _
                  errorDescription
        If cleanupEventsStopped And recoveryErrorNumber = 0 Then
            recoveryConfirmationDetail = vbNullString
            recoveryDualConfirmed = _
                SetupRecoveryStateIsConfirmedExact(recoveryConfirmationDetail)
            If recoveryDualConfirmed Then
                applicationStateProblems = vbNullString
                applicationStateRestored = _
                    SetupApplicationStateIsRestoredExact( _
                        applicationStateProblems)
            End If
            cleanupEventsStopped = _
                SetApplicationEnableEventsExact(False, eventStateDetail)
            If Not cleanupEventsStopped Then _
                cleanupEventsStopped = _
                    SetApplicationEnableEventsExact(False, eventStateDetail)

        End If
        If recoveryErrorNumber <> 0 Then _
            AppendSetupRestoreDetail recoveryDetail, _
                "復旧安全停止 Err " & CStr(recoveryErrorNumber) & " " & _
                recoveryErrorDescription
        If recoveryErrorNumber = 0 And Not recoveryDualConfirmed Then _
            AppendSetupRestoreDetail recoveryDetail, _
                "要復旧状態を二重確認できません。 " & _
                recoveryConfirmationDetail
        If recoveryErrorNumber = 0 And recoveryDualConfirmed And _
           Not applicationStateRestored Then _
            AppendSetupRestoreDetail recoveryDetail, _
                "Application状態を安全に復元できません。 " & _
                applicationStateProblems
        If Not cleanupEventsStopped Then _
            AppendSetupRestoreDetail recoveryDetail, _
                "ExcelイベントをFalseへ収束できません。 " & _
                eventStateDetail
        AppendSetupRestoreDetail errorDescription, recoveryDetail
        On Error GoTo 0
        Err.Raise SETUP_CONVERGE_RECOVERY_FATAL_ERROR, _
                  SETUP_CONVERGE_RECOVERY_FATAL_SOURCE & _
                  "ConvergeInputTransactionLockPlan", _
                  "元エラー Err " & CStr(errorNumber) & " / " & _
                  errorSource & ": " & errorDescription
    End If
    If emergencyProtected And workbookWasSaved Then _
        RestoreSavedFlagAfterSetupProtection errorDescription
    Err.Raise errorNumber, "ConvergeInputTransactionLockPlan", _
              IIf(Len(errorSource) > 0, errorSource & " / ", vbNullString) & _
              errorDescription
End Sub

Private Function TryEmergencyProtectSetupSheet(ByVal ws As Worksheet, _
                                                ByRef failureText As String) As Boolean
    failureText = vbNullString
    If ws Is Nothing Then
        failureText = "緊急再保護するシートを取得できません。"
        Exit Function
    End If
    On Error GoTo EH
    EmergencyProtectToolSheet ws
    If Not ws.ProtectContents Or Not ws.ProtectDrawingObjects Then
        failureText = "緊急再保護後のセル・図形保護を読み戻せません。"
        Exit Function
    End If
    TryEmergencyProtectSetupSheet = True
    Exit Function
EH:
    failureText = "Err " & CStr(Err.Number) & " [" & Err.Source & "] " & _
                  Err.Description
    Err.Clear
End Function

Private Sub RestoreSavedFlagAfterSetupProtection(ByRef detailText As String)
    Dim savedReadback As Boolean
    Dim savedErrorNumber As Long, savedErrorDescription As String
    Dim readErrorNumber As Long, readErrorDescription As String
    On Error Resume Next
    Err.Clear
    ThisWorkbook.Saved = True
    savedErrorNumber = Err.Number
    savedErrorDescription = Err.Description
    Err.Clear
    savedReadback = ThisWorkbook.Saved
    readErrorNumber = Err.Number
    readErrorDescription = Err.Description
    Err.Clear
    On Error GoTo 0
    If savedErrorNumber <> 0 Or readErrorNumber <> 0 Or Not savedReadback Then
        AppendSetupRestoreDetail detailText, _
            "ブック保存状態の復元を確認できません" & _
            IIf(savedErrorNumber <> 0, _
                ": Err " & CStr(savedErrorNumber) & " " & savedErrorDescription, _
                vbNullString) & _
            IIf(readErrorNumber <> 0, _
                " / 読戻し Err " & CStr(readErrorNumber) & " " & _
                readErrorDescription, vbNullString)
    End If
End Sub

Private Sub RestoreWritableInputLockState(ByVal ws As Worksheet)
    Dim memoCol As Long
    Dim memoRange As Range
    If ws Is Nothing Then Exit Sub
    UnlockRange ws.Range(CELL_BANK)
    UnlockRange ws.Range(CELL_BRANCH)
    UnlockRange ws.Range(CELL_PERSON)
    ApplyRelationshipFieldState ws
    UnlockRange ws.Range(CELL_ACCOUNT_TYPE)
    UnlockRange ws.Range(CELL_ACCOUNT_NO)
    UnlockRange ws.Range(CELL_OPEN_DATE)
    UnlockRange ws.Range(CELL_CLOSE_DATE)
    memoCol = BalanceMemoCol(ws)
    If memoCol > BAL_FIRST_COL Then _
        UnlockRange ws.Range(ws.Cells(BAL_VALUE_ROW, BAL_FIRST_COL), _
                             ws.Cells(BAL_VALUE_ROW, memoCol - 1))
    Set memoRange = BalanceMemoInputRange(ws)
    If Not memoRange Is Nothing Then UnlockRange memoRange
    ApplyBalanceAvailability ws
    UnlockTransactionInputCells ws
End Sub

Private Function WritableInputLockStateNeedsRestore(ByVal ws As Worksheet) As Boolean
    '読み取り専用からSaveAsしたブックは、全ロック状態が先にディスクへ保存される。
    'モジュール変数は次回起動で消えるため、実セルを見て書込可能状態への復元要否を判定する。
    On Error GoTo NeedsRestore
    If ws Is Nothing Then GoTo NeedsRestore
    If CBool(ws.Range(CELL_BANK).Locked) Then GoTo NeedsRestore
    If CBool(ws.Range(CELL_BRANCH).Locked) Then GoTo NeedsRestore
    If CBool(ws.Range(CELL_PERSON).Locked) Then GoTo NeedsRestore
    If CBool(ws.Range(CELL_ACCOUNT_TYPE).Locked) Then GoTo NeedsRestore
    If CBool(ws.Range(CELL_ACCOUNT_NO).Locked) Then GoTo NeedsRestore
    If Not CBool(ws.Rows(ws.Range(CELL_OPEN_DATE).Row).Hidden) Then
        If CBool(ws.Range(CELL_OPEN_DATE).Locked) Then GoTo NeedsRestore
    End If
    If Not CBool(ws.Rows(ws.Range(CELL_CLOSE_DATE).Row).Hidden) Then
        If CBool(ws.Range(CELL_CLOSE_DATE).Locked) Then GoTo NeedsRestore
    End If
    If CBool(ws.Cells(TX_FIRST_ROW, COL_TX_YEAR).Locked) Then GoTo NeedsRestore
    If CBool(ws.Cells(TX_FIRST_ROW, COL_TX_MONTH).Locked) Then GoTo NeedsRestore
    If CBool(ws.Cells(TX_FIRST_ROW, COL_TX_DAY).Locked) Then GoTo NeedsRestore
    Exit Function
NeedsRestore:
    WritableInputLockStateNeedsRestore = True
End Function

Public Sub ProtectConfigSheet(Optional ByVal raiseOnError As Boolean = False)
    '設定値と元号マスタだけを編集可能にし、操作ボタン・見出し・列幅・行高は固定する。
    Dim ws As Worksheet
    Dim workbookWasSaved As Boolean, emergencyProtected As Boolean
    Dim mutationStarted As Boolean, cleanupEventsStopped As Boolean
    Dim entryEvents As Boolean, entryEventsCaptured As Boolean
    Dim eventsRestored As Boolean, savedFlagRestored As Boolean
    Dim safeToRestoreEntry As Boolean
    Dim recoveryAttempted As Boolean, terminalRecoveryFailure As Boolean
    Dim applicationStateRestored As Boolean, finalEventsStopped As Boolean
    Dim recoveryDualConfirmed As Boolean, recoveryIsolationConfirmed As Boolean
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim recoveryErrorNumber As Long, recoveryErrorDescription As String
    Dim emergencyDetail As String, recoveryDetail As String
    Dim eventStateDetail As String, eventRestoreDetail As String
    Dim recoveryConfirmationDetail As String
    Dim applicationStateProblems As String
    Dim savedRestoreDetail As String
    If Not SheetExists(SH_CONFIG) Then Exit Sub
    On Error GoTo EH
    Set ws = GetSheet(SH_CONFIG)
    workbookWasSaved = ThisWorkbook.Saved
    savedFlagRestored = True
    If Not TryGetSetupEnableEvents(entryEvents, eventStateDetail) Then _
        Err.Raise vbObjectError + 1827, "ProtectConfigSheet", _
                  "設定シート保護前のイベント状態を一意に保存できません。 " & _
                  eventStateDetail
    entryEventsCaptured = True
    If Not SetApplicationEnableEventsExact(False, eventStateDetail) Then _
        Err.Raise vbObjectError + 1828, "ProtectConfigSheet", _
                  "設定シート保護中のイベント停止を一意に確認できません。 " & _
                  eventStateDetail

    mutationStarted = True
    ws.Unprotect Password:=TOOL_PASSWORD
    RestoreToolSheetScrollArea ws
    ws.Range("A1:H" & CStr(ERA_MASTER_MAX_ROW + 3)).Locked = True
    If Not ThisWorkbook.ReadOnly Then
        ws.Range("C4:C17").Locked = False
        ws.Range(ws.Cells(ROW_CFG_ANALYSIS_MIN_AMOUNT, COL_CFG_ANALYSIS_VALUE), _
                 ws.Cells(ROW_CFG_ANALYSIS_UNKNOWN_MIN, COL_CFG_ANALYSIS_VALUE)).Locked = False
        ws.Range(ws.Cells(ERA_MASTER_FIRST_ROW, ERA_COL_CODE), _
                 ws.Cells(ERA_MASTER_MAX_ROW, ERA_COL_ENABLED)).Locked = False
    End If
    '設定シートは印刷対象ではない。PrintObjectの旧APIが利用できない環境でも、
    'Locked・Placement・OnActionとシート図形保護は必須として検証する。
    LockToolShapes ws, False
    ws.Protect Password:=TOOL_PASSWORD, DrawingObjects:=True, Contents:=True, Scenarios:=False, _
               UserInterfaceOnly:=True, AllowFiltering:=False, AllowSorting:=False, _
               AllowFormattingCells:=False, AllowFormattingColumns:=False, AllowFormattingRows:=False, _
               AllowInsertingColumns:=False, AllowInsertingRows:=False, _
               AllowDeletingColumns:=False, AllowDeletingRows:=False
    If ThisWorkbook.ReadOnly Then
        ws.EnableSelection = xlNoSelection
    Else
        ws.EnableSelection = xlUnlockedCells
    End If
    If Not ws.ProtectContents Or Not ws.ProtectDrawingObjects Then _
        Err.Raise vbObjectError + 1829, "ProtectConfigSheet", _
                  "設定シートのセル・図形保護を読み戻せません。"
    If ThisWorkbook.ReadOnly Then
        If ws.EnableSelection <> xlNoSelection Then _
            Err.Raise vbObjectError + 1830, "ProtectConfigSheet", _
                      "読み取り専用時の選択禁止を読み戻せません。"
    ElseIf ws.EnableSelection <> xlUnlockedCells Then
        Err.Raise vbObjectError + 1831, "ProtectConfigSheet", _
                  "設定シートの編集セル選択状態を読み戻せません。"
    End If
    VerifyToolShapeSecurity ws, True, False
    If workbookWasSaved Then
        savedRestoreDetail = vbNullString
        RestoreSavedFlagAfterSetupProtection savedRestoreDetail
        If Len(savedRestoreDetail) > 0 Then _
            Err.Raise vbObjectError + 1832, "ProtectConfigSheet", savedRestoreDetail
    End If
    If Not TryRestoreSetupProtectionEntryEvents( _
               entryEventsCaptured, entryEvents, eventRestoreDetail) Then _
        Err.Raise vbObjectError + 1833, "ProtectConfigSheet", _
                  "設定シート保護前のイベント状態を復元できません。 " & _
                  eventRestoreDetail
    entryEventsCaptured = False
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    terminalRecoveryFailure = _
        IsSetupRecoveryFatalError(errorNumber, errorSource)
    If terminalRecoveryFailure Then
        On Error Resume Next
        Call SetApplicationEnableEventsExact(False, eventStateDetail)
        Call SetApplicationEnableEventsExact(False, eventStateDetail)
        On Error GoTo 0
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    On Error Resume Next
    cleanupEventsStopped = False
    If entryEventsCaptured Then _
        cleanupEventsStopped = _
            SetApplicationEnableEventsExact(False, eventStateDetail)
    If mutationStarted And cleanupEventsStopped Then
        emergencyProtected = TryEmergencyProtectSetupSheet(ws, emergencyDetail)
        If Not emergencyProtected Then
            recoveryDetail = "設定シートの緊急再保護を確認できません。"
            AppendSetupRestoreDetail recoveryDetail, emergencyDetail
            mFailureInspectionPrepared = False
            Err.Clear
            recoveryAttempted = True
            EnforceRollbackRecoveryState recoveryDetail
            recoveryErrorNumber = Err.Number
            recoveryErrorDescription = Err.Description
            Err.Clear
            '共通復旧は例外終了時のイベント状態を保証しない。診断書込みと
            '開始値復元の可否判定より先にFalseを再確定する。
            cleanupEventsStopped = _
                SetApplicationEnableEventsExact(False, eventStateDetail)
            If Not cleanupEventsStopped Then _
                cleanupEventsStopped = _
                    SetApplicationEnableEventsExact(False, eventStateDetail)
            terminalRecoveryFailure = True
            GoTo PROTECT_CONFIG_RECOVERY_FATAL
        End If
        If emergencyProtected And workbookWasSaved Then
            savedRestoreDetail = vbNullString
            RestoreSavedFlagAfterSetupProtection savedRestoreDetail
            If Len(savedRestoreDetail) > 0 Then
                savedFlagRestored = False
                AppendSetupRestoreDetail errorDescription, savedRestoreDetail
            End If
        End If
    ElseIf mutationStarted Then
        emergencyProtected = False
        AppendSetupRestoreDetail errorDescription, _
            "イベント停止を確認できないため緊急再保護・復旧記録・保存状態への書込みを実行していません。 " & _
            eventStateDetail
    End If
    safeToRestoreEntry = emergencyProtected
    eventsRestored = False
    If entryEventsCaptured And safeToRestoreEntry Then
        eventRestoreDetail = vbNullString
        eventsRestored = TryRestoreSetupProtectionEntryEvents( _
                             entryEventsCaptured, entryEvents, eventRestoreDetail)
        If Not eventsRestored Then _
            AppendSetupRestoreDetail errorDescription, _
                "イベント開始値の復元未完了: " & eventRestoreDetail
    Else
        eventRestoreDetail = vbNullString
        cleanupEventsStopped = _
            SetApplicationEnableEventsExact(False, eventRestoreDetail)
        If Not cleanupEventsStopped Then _
            cleanupEventsStopped = _
                SetApplicationEnableEventsExact(False, eventRestoreDetail)
        If cleanupEventsStopped Then
            AppendSetupRestoreDetail errorDescription, _
                "シート保護または要復旧隔離を完全確認できないため、" & _
                "イベントをFalseへ収束させました。"
        Else
            AppendSetupRestoreDetail errorDescription, _
                "イベントをFalseへも収束できず状態は不明です。 " & _
                eventRestoreDetail
        End If
    End If
    On Error GoTo 0
    If raiseOnError Or Not emergencyProtected Or _
       Not savedFlagRestored Or Not eventsRestored Then _
        Err.Raise errorNumber, "ProtectConfigSheet", _
                  IIf(Len(errorSource) > 0, errorSource & " / ", vbNullString) & _
                  errorDescription
    Exit Sub

PROTECT_CONFIG_RECOVERY_FATAL:
    If IsSetupRecoveryFatalError(errorNumber, errorSource) Then
        On Error Resume Next
        Call SetApplicationEnableEventsExact(False, eventRestoreDetail)
        Call SetApplicationEnableEventsExact(False, eventRestoreDetail)
        On Error GoTo 0
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    eventRestoreDetail = vbNullString
    cleanupEventsStopped = _
        SetApplicationEnableEventsExact(False, eventRestoreDetail)
    If Not cleanupEventsStopped Then _
        cleanupEventsStopped = _
            SetApplicationEnableEventsExact(False, eventRestoreDetail)
    If Not cleanupEventsStopped Then
        If Not IsSetupRecoveryFatalError(errorNumber, errorSource) Then _
            AppendSetupRestoreDetail errorDescription, _
                "terminal Recovery後もExcelイベントをFalseへ収束できません。 " & _
                eventRestoreDetail
    End If
    On Error GoTo 0
    If IsSetupRecoveryFatalError(errorNumber, errorSource) Then _
        Err.Raise errorNumber, errorSource, errorDescription
    Err.Raise SETUP_CONVERGE_RECOVERY_FATAL_ERROR, _
              SETUP_CONVERGE_RECOVERY_FATAL_SOURCE & "ProtectConfigSheet", _
              "元エラー Err " & CStr(errorNumber) & " / " & _
              errorSource & ": " & errorDescription
End Sub

Public Sub ProtectInputSheet(Optional ByVal raiseOnError As Boolean = False)
    Dim ws As Worksheet
    Dim workbookWasSaved As Boolean, emergencyProtected As Boolean
    Dim mutationStarted As Boolean, cleanupEventsStopped As Boolean
    Dim entryEvents As Boolean, entryEventsCaptured As Boolean
    Dim eventsRestored As Boolean, savedFlagRestored As Boolean
    Dim safeToRestoreEntry As Boolean
    Dim recoveryAttempted As Boolean, terminalRecoveryFailure As Boolean
    Dim applicationStateRestored As Boolean, finalEventsStopped As Boolean
    Dim recoveryDualConfirmed As Boolean, recoveryIsolationConfirmed As Boolean
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim recoveryErrorNumber As Long, recoveryErrorDescription As String
    Dim emergencyDetail As String, recoveryDetail As String
    Dim eventStateDetail As String, eventRestoreDetail As String
    Dim recoveryConfirmationDetail As String
    Dim applicationStateProblems As String
    Dim savedRestoreDetail As String
    If Not SheetExists(SH_INPUT) Then Exit Sub
    On Error GoTo EH
    Set ws = ThisWorkbook.Worksheets(SH_INPUT)
    workbookWasSaved = ThisWorkbook.Saved
    savedFlagRestored = True
    If Not TryGetSetupEnableEvents(entryEvents, eventStateDetail) Then _
        Err.Raise vbObjectError + 1834, "ProtectInputSheet", _
                  "入力シート保護前のイベント状態を一意に保存できません。 " & _
                  eventStateDetail
    entryEventsCaptured = True
    If Not SetApplicationEnableEventsExact(False, eventStateDetail) Then _
        Err.Raise vbObjectError + 1835, "ProtectInputSheet", _
                  "入力シート保護中のイベント停止を一意に確認できません。 " & _
                  eventStateDetail
    mutationStarted = True
    With ws
        .Unprotect Password:=TOOL_PASSWORD
        RestoreToolSheetScrollArea ws
        If ThisWorkbook.ReadOnly Then
            '選択禁止だけに頼らず、現在選択中のセルからも編集できないよう入力領域自体をロックする。
            If Not mInputReadOnlyLocked Then
                .Range(.Cells(1, 1), .Cells(TX_LAST_ROW, BAL_MAX_COL)).Locked = True
                mInputReadOnlyLocked = True
            End If
        Else
            If mInputReadOnlyLocked Or WritableInputLockStateNeedsRestore(ws) Then
                '読み取り専用からの別名保存直後と、その保存コピーを次回開いた時の双方で入力欄を戻す。
                RestoreWritableInputLockState ws
                mInputReadOnlyLocked = False
            End If
            '表示・モード・現在行・入出金の実値からロック計画を毎回作り直し、
            '旧版で全明細が開いたまま保存されたブックも起動時に収束させる。
            ApplyVisibleInputFieldLockPlan ws
            ApplyTransactionInputLockPlan ws
        End If
        '入力セルは編集可能、図形ボタンはクリック実行のみ可能にし、誤ドラッグや右クリック編集を防ぐ。
        RefreshMainActionCaption
        LockToolShapes ThisWorkbook.Worksheets(SH_INPUT), False
        .Protect Password:=TOOL_PASSWORD, DrawingObjects:=True, Contents:=True, Scenarios:=False, _
                 UserInterfaceOnly:=True, AllowFiltering:=True, AllowSorting:=False, _
                 AllowFormattingCells:=False, _
                 AllowFormattingColumns:=False, AllowFormattingRows:=False
        If ThisWorkbook.ReadOnly Then
            .EnableSelection = xlNoSelection
        Else
            .EnableSelection = xlUnlockedCells
        End If
    End With
    If Not ws.ProtectContents Or Not ws.ProtectDrawingObjects Then _
        Err.Raise vbObjectError + 1804, "ProtectInputSheet", "入力シートを保護できませんでした。"
    If ThisWorkbook.ReadOnly Then
        If ws.EnableSelection <> xlNoSelection Then _
            Err.Raise vbObjectError + 1836, "ProtectInputSheet", _
                      "読み取り専用時の入力選択禁止を読み戻せません。"
    ElseIf ws.EnableSelection <> xlUnlockedCells Then
        Err.Raise vbObjectError + 1837, "ProtectInputSheet", _
                  "入力シートの編集セル選択状態を読み戻せません。"
    End If
    VerifyToolShapeSecurity ws, True, False
    If workbookWasSaved Then
        savedRestoreDetail = vbNullString
        RestoreSavedFlagAfterSetupProtection savedRestoreDetail
        If Len(savedRestoreDetail) > 0 Then _
            Err.Raise vbObjectError + 1838, "ProtectInputSheet", savedRestoreDetail
    End If
    If Not TryRestoreSetupProtectionEntryEvents( _
               entryEventsCaptured, entryEvents, eventRestoreDetail) Then _
        Err.Raise vbObjectError + 1839, "ProtectInputSheet", _
                  "入力シート保護前のイベント状態を復元できません。 " & _
                  eventRestoreDetail
    entryEventsCaptured = False
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    terminalRecoveryFailure = _
        IsSetupRecoveryFatalError(errorNumber, errorSource)
    If terminalRecoveryFailure Then
        On Error Resume Next
        Call SetApplicationEnableEventsExact(False, eventStateDetail)
        Call SetApplicationEnableEventsExact(False, eventStateDetail)
        On Error GoTo 0
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    On Error Resume Next
    cleanupEventsStopped = False
    If entryEventsCaptured Then _
        cleanupEventsStopped = _
            SetApplicationEnableEventsExact(False, eventStateDetail)
    If mutationStarted And cleanupEventsStopped Then
        emergencyProtected = TryEmergencyProtectSetupSheet(ws, emergencyDetail)
        If Not emergencyProtected Then
            recoveryDetail = "入力シートの緊急再保護を確認できません。"
            AppendSetupRestoreDetail recoveryDetail, emergencyDetail
            mFailureInspectionPrepared = False
            Err.Clear
            recoveryAttempted = True
            EnforceRollbackRecoveryState recoveryDetail
            recoveryErrorNumber = Err.Number
            recoveryErrorDescription = Err.Description
            Err.Clear
            '共通復旧は例外終了時のイベント状態を保証しない。診断書込みと
            '開始値復元の可否判定より先にFalseを再確定する。
            cleanupEventsStopped = _
                SetApplicationEnableEventsExact(False, eventStateDetail)
            If Not cleanupEventsStopped Then _
                cleanupEventsStopped = _
                    SetApplicationEnableEventsExact(False, eventStateDetail)
            terminalRecoveryFailure = True
            GoTo PROTECT_INPUT_RECOVERY_FATAL
        End If
        If emergencyProtected And workbookWasSaved Then
            savedRestoreDetail = vbNullString
            RestoreSavedFlagAfterSetupProtection savedRestoreDetail
            If Len(savedRestoreDetail) > 0 Then
                savedFlagRestored = False
                AppendSetupRestoreDetail errorDescription, savedRestoreDetail
            End If
        End If
    ElseIf mutationStarted Then
        emergencyProtected = False
        AppendSetupRestoreDetail errorDescription, _
            "イベント停止を確認できないため緊急再保護・復旧記録・保存状態への書込みを実行していません。 " & _
            eventStateDetail
    End If
    safeToRestoreEntry = emergencyProtected
    eventsRestored = False
    If entryEventsCaptured And safeToRestoreEntry Then
        eventRestoreDetail = vbNullString
        eventsRestored = TryRestoreSetupProtectionEntryEvents( _
                             entryEventsCaptured, entryEvents, eventRestoreDetail)
        If Not eventsRestored Then _
            AppendSetupRestoreDetail errorDescription, _
                "イベント開始値の復元未完了: " & eventRestoreDetail
    Else
        eventRestoreDetail = vbNullString
        cleanupEventsStopped = _
            SetApplicationEnableEventsExact(False, eventRestoreDetail)
        If Not cleanupEventsStopped Then _
            cleanupEventsStopped = _
                SetApplicationEnableEventsExact(False, eventRestoreDetail)
        If cleanupEventsStopped Then
            AppendSetupRestoreDetail errorDescription, _
                "シート保護または要復旧隔離を完全確認できないため、" & _
                "イベントをFalseへ収束させました。"
        Else
            AppendSetupRestoreDetail errorDescription, _
                "イベントをFalseへも収束できず状態は不明です。 " & _
                eventRestoreDetail
        End If
    End If
    On Error GoTo 0
    If raiseOnError Or Not emergencyProtected Or _
       Not savedFlagRestored Or Not eventsRestored Then _
        Err.Raise errorNumber, "ProtectInputSheet", _
                  IIf(Len(errorSource) > 0, errorSource & " / ", vbNullString) & _
                  errorDescription
    Exit Sub

PROTECT_INPUT_RECOVERY_FATAL:
    If IsSetupRecoveryFatalError(errorNumber, errorSource) Then
        On Error Resume Next
        Call SetApplicationEnableEventsExact(False, eventRestoreDetail)
        Call SetApplicationEnableEventsExact(False, eventRestoreDetail)
        On Error GoTo 0
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    eventRestoreDetail = vbNullString
    cleanupEventsStopped = _
        SetApplicationEnableEventsExact(False, eventRestoreDetail)
    If Not cleanupEventsStopped Then _
        cleanupEventsStopped = _
            SetApplicationEnableEventsExact(False, eventRestoreDetail)
    If Not cleanupEventsStopped Then
        If Not IsSetupRecoveryFatalError(errorNumber, errorSource) Then _
            AppendSetupRestoreDetail errorDescription, _
                "terminal Recovery後もExcelイベントをFalseへ収束できません。 " & _
                eventRestoreDetail
    End If
    On Error GoTo 0
    If IsSetupRecoveryFatalError(errorNumber, errorSource) Then _
        Err.Raise errorNumber, errorSource, errorDescription
    Err.Raise SETUP_CONVERGE_RECOVERY_FATAL_ERROR, _
              SETUP_CONVERGE_RECOVERY_FATAL_SOURCE & "ProtectInputSheet", _
              "元エラー Err " & CStr(errorNumber) & " / " & _
              errorSource & ": " & errorDescription
End Sub

Public Sub ValidateInitializationPreservedSettings()
    '案件初期化で残す表示・入力設定、元号、静的選択肢、科目・摘要候補が壊れている場合は、
    Dim requiredSheets As Variant, item As Variant, problems As String
    requiredSheets = Array(SH_CONFIG, SH_ACCOUNT_TYPE, SH_TEKIYO, SH_INPUT_MODE, SH_YEAR_MODE, _
                           SH_DISPLAY_OPTION, SH_POST_KEEP, SH_POST_CLEAR, SH_ANALYSIS_STATUS)
    For Each item In requiredSheets
        If Not SheetExists(CStr(item)) Then problems = problems & "・保持対象シート不足: " & CStr(item) & vbCrLf
    Next item
    If Len(problems) > 0 Then GoTo InvalidPreservedData

    CheckConfigurationValues problems
    CheckStaticChoiceList GetSheet(SH_INPUT_MODE), "入力モード", _
                          Array(MODE_NORMAL, MODE_NO_TIME, MODE_NO_MACHINE, MODE_NO_TEKIYO, MODE_WITH_OTHER, MODE_SIMPLE), problems
    CheckStaticChoiceList GetSheet(SH_YEAR_MODE), "年入力方式", _
                          Array(YEAR_MODE_WAREKI, YEAR_MODE_WESTERN2), problems
    CheckStaticChoiceList GetSheet(SH_DISPLAY_OPTION), "表示切替", _
                          Array(DISPLAY_ON, DISPLAY_OFF), problems
    CheckStaticChoiceList GetSheet(SH_POST_KEEP), "転記後に残す口座情報", _
                          Array(KEEP_NONE, KEEP_PERSON_ONLY, KEEP_BANK_BRANCH, KEEP_BANK_BRANCH_PERSON_TYPE), problems
    CheckStaticChoiceList GetSheet(SH_POST_CLEAR), "転記後処理", _
                          Array(POST_CLEAR, POST_KEEP), problems
    CheckAnalysisStatusMaster GetSheet(SH_ANALYSIS_STATUS), problems
    CheckHeaderRowExact GetSheet(SH_ACCOUNT_TYPE), 1, Array("科目候補", "", "", "区分"), "科目候補", problems
    CheckHeaderRowExact GetSheet(SH_TEKIYO), 1, Array("摘要候補", "", "", "区分"), "摘要候補", problems
    CheckContiguousDataStore GetSheet(SH_ACCOUNT_TYPE), 1, 4, MAX_CANDIDATE_DATA_ROWS, "科目候補", problems
    CheckContiguousDataStore GetSheet(SH_TEKIYO), 1, 4, MAX_CANDIDATE_DATA_ROWS, "摘要候補", problems
    CheckCandidateSheetTextLength GetSheet(SH_ACCOUNT_TYPE), 100, problems
    CheckCandidateSheetTextLength GetSheet(SH_TEKIYO), 500, problems

    CheckNoFormulasInInitializationPreservedConfig problems
    CheckNoFormulasInDataSheet GetSheet(SH_INPUT_MODE), 1, problems
    CheckNoFormulasInDataSheet GetSheet(SH_YEAR_MODE), 1, problems
    CheckNoFormulasInDataSheet GetSheet(SH_DISPLAY_OPTION), 1, problems
    CheckNoFormulasInDataSheet GetSheet(SH_POST_KEEP), 1, problems
    CheckNoFormulasInDataSheet GetSheet(SH_POST_CLEAR), 1, problems
    CheckNoFormulasInDataSheet GetSheet(SH_ANALYSIS_STATUS), 1, problems
    CheckNoFormulasInDataSheet GetSheet(SH_ACCOUNT_TYPE), 4, problems
    CheckNoFormulasInDataSheet GetSheet(SH_TEKIYO), 4, problems
    CheckNoErrorConstantsInDataSheet GetSheet(SH_INPUT_MODE), 1, problems
    CheckNoErrorConstantsInDataSheet GetSheet(SH_YEAR_MODE), 1, problems
    CheckNoErrorConstantsInDataSheet GetSheet(SH_DISPLAY_OPTION), 1, problems
    CheckNoErrorConstantsInDataSheet GetSheet(SH_POST_KEEP), 1, problems
    CheckNoErrorConstantsInDataSheet GetSheet(SH_POST_CLEAR), 1, problems
    CheckNoErrorConstantsInDataSheet GetSheet(SH_ANALYSIS_STATUS), 1, problems
    CheckNoErrorConstantsInDataSheet GetSheet(SH_ACCOUNT_TYPE), 4, problems
    CheckNoErrorConstantsInDataSheet GetSheet(SH_TEKIYO), 4, problems

    CheckListNameRange NM_LST_INPUT_MODE, GetSheet(SH_INPUT_MODE), problems
    CheckListNameRange NM_LST_YEAR_MODE, GetSheet(SH_YEAR_MODE), problems
    CheckListNameRange NM_LST_DISPLAY_OPTION, GetSheet(SH_DISPLAY_OPTION), problems
    CheckListNameRange NM_LST_POST_KEEP, GetSheet(SH_POST_KEEP), problems
    CheckListNameRange NM_LST_POST_CLEAR, GetSheet(SH_POST_CLEAR), problems
    CheckAnalysisStatusNameRanges GetSheet(SH_ANALYSIS_STATUS), problems

InvalidPreservedData:
    If Len(problems) > 0 Then _
        Err.Raise vbObjectError + 1521, "ValidateInitializationPreservedSettings", _
                  "初期化後も保持する設定または候補に問題があります。該当する設定または候補を修正してください: " & _
                  Left$(Replace(problems, vbCrLf, " / "), 3500)
End Sub

Private Sub CheckNoFormulasInInitializationPreservedConfig(ByRef problems As String)
    Dim ws As Worksheet, preservedRange As Range, formulaCell As Range
    Set ws = GetSheet(SH_CONFIG)
    Set preservedRange = Union( _
        ws.Cells(ROW_CFG_YEAR_ADD, COL_CFG_VALUE), _
        ws.Range(ws.Cells(ROW_CFG_INPUT_MODE, COL_CFG_VALUE), _
                 ws.Cells(ROW_CFG_SHOW_BALANCE_ROWS, COL_CFG_VALUE)), _
        ws.Range(ws.Cells(ROW_CFG_ANALYSIS_MIN_AMOUNT, COL_CFG_ANALYSIS_VALUE), _
                 ws.Cells(ROW_CFG_ANALYSIS_UNKNOWN_MIN, COL_CFG_ANALYSIS_VALUE)), _
        ws.Range(ws.Cells(ERA_MASTER_FIRST_ROW, ERA_COL_CODE), _
                 ws.Cells(ERA_MASTER_MAX_ROW, ERA_COL_ENABLED)))
    If Not TryFindFirstFormulaCell(preservedRange, formulaCell) Then
        problems = problems & "・設定: 初期化後も保持するセルの数式有無を確認できません" & vbCrLf
    ElseIf Not formulaCell Is Nothing Then
        problems = problems & "・設定 " & formulaCell.Address(False, False) & _
                   ": 初期化後も保持するセルに数式があります" & vbCrLf
    End If
End Sub

Private Function CheckAuthoritativeStoreStructure(ByRef problems As String, _
                                                   ByVal requireCaseReady As Boolean, _
                                                   ByVal allowInitializingState As Boolean, _
                                                   Optional ByVal includeAllocationLedger As Boolean = True) As Boolean
    Dim requiredSheets As Variant, item As Variant
    requiredSheets = Array(SH_WORK_TX, SH_WORK_BAL, SH_WORK_ACCOUNT, SH_WORK_STATE)
    For Each item In requiredSheets
        If Not SheetExists(CStr(item)) Then _
            problems = problems & "・中核シート不足: " & CStr(item) & vbCrLf
    Next item
    If Len(problems) > 0 Then Exit Function
    CheckContiguousDataStore GetSheet(SH_WORK_TX), WORK_TX_COL_ACCOUNT_ID, _
                             WORK_TX_COL_PERSON_ID, MAX_INTERNAL_STORE_DATA_ROWS, _
                             "W_取引", problems
    CheckContiguousDataStore GetSheet(SH_WORK_BAL), WORK_BAL_COL_ACCOUNT_ID, _
                             WORK_BAL_COL_PERSON_ID, MAX_INTERNAL_STORE_DATA_ROWS, _
                             "W_残高", problems
    CheckContiguousDataStore GetSheet(SH_WORK_ACCOUNT), ACC_COL_ID, ACC_COL_TRANSFER_ID, _
                             MAX_INTERNAL_STORE_DATA_ROWS, "W_口座", problems
    CheckContiguousDataStore GetSheet(SH_WORK_STATE), 1, 2, 100, "W_状態", problems
    If Len(problems) > 0 Then Exit Function
    CheckHeaderRowExact GetSheet(SH_WORK_TX), 1, _
        Array("銀行名", "支店名", "氏名", "科目", "口座番号", "日付", "時刻", "出金", "入金", "取扱店", "機番", _
              "摘要欄", "残高", "続柄", "口座ID", "転記回ID", "取引ID", "行種別", "入力順", "登録元", "人物ID"), _
        "W_取引", problems
    CheckHeaderRowExact GetSheet(SH_WORK_BAL), 1, _
        Array("氏名", "銀行名", "支店名", "科目", "口座番号", "口座開設日", "口座解約日", "残高基準日", "残高見出し", _
              "残高", "その他", "続柄", "口座ID", "転記回ID", "残高ID", "登録元", "人物ID"), _
        "W_残高", problems
    CheckHeaderRowExact GetSheet(SH_WORK_ACCOUNT), 1, _
        Array("口座ID", "銀行名", "支店名", "氏名", "続柄", "科目", "口座番号", "口座開設日", "口座解約日", _
              "人物ID", "登録元", "更新日時", "最新転記回ID"), _
        "W_口座", problems
    CheckHeaderRowExact GetSheet(SH_WORK_STATE), 1, Array("項目", "値"), _
                        "W_状態", problems
    CheckStateTable GetSheet(SH_WORK_STATE), problems, allowInitializingState
    CheckNoFormulasInDataSheet GetSheet(SH_WORK_TX), WORK_TX_COL_PERSON_ID, problems
    CheckNoFormulasInDataSheet GetSheet(SH_WORK_BAL), WORK_BAL_COL_PERSON_ID, problems
    CheckNoFormulasInDataSheet GetSheet(SH_WORK_ACCOUNT), ACC_COL_TRANSFER_ID, problems
    CheckNoFormulasInDataSheet GetSheet(SH_WORK_STATE), 2, problems
    CheckNoErrorConstantsInDataSheet GetSheet(SH_WORK_TX), WORK_TX_COL_PERSON_ID, problems
    CheckNoErrorConstantsInDataSheet GetSheet(SH_WORK_BAL), WORK_BAL_COL_PERSON_ID, problems
    CheckNoErrorConstantsInDataSheet GetSheet(SH_WORK_ACCOUNT), ACC_COL_TRANSFER_ID, problems
    CheckNoErrorConstantsInDataSheet GetSheet(SH_WORK_STATE), 2, problems
    'W_分析判断台帳のO:Xは配賦の正本である。画面診断とは分離したまま、
    '見出し・N列空欄・定数値・配賦不変条件を中核書込み前に必ず検証する。
    If includeAllocationLedger Then
        If Not ValidateAllocationLedgerForSave(problems) Then Exit Function
    End If
    If requireCaseReady Then
        If Not SheetExists(SH_CONFIG) Then
            problems = problems & "・設定シート不足: " & SH_CONFIG & vbCrLf
        ElseIf Not IsDate(GetCfgDateValue(ROW_CFG_INHERITANCE_DATE)) Then
            problems = problems & "・相続開始日が未設定です。" & vbCrLf
        End If
    End If
    CheckAuthoritativeStoreStructure = (Len(problems) = 0)
End Function

Private Function RequiredToolSheetNames() As Variant
    RequiredToolSheetNames = Array( _
        SH_INPUT, SH_CONFIG, SH_WORK_TX, SH_WORK_BAL, SH_WORK_ACCOUNT, SH_WORK_STATE, _
        SH_REGISTERED_ACCOUNTS, SH_CHECK, SH_TEKIYO, SH_ACCOUNT_TYPE, SH_INPUT_MODE, _
        SH_YEAR_MODE, SH_DISPLAY_OPTION, SH_POST_KEEP, SH_POST_CLEAR, _
        SH_ANALYSIS_STATUS, SH_BANK_CAND, SH_BRANCH_CAND, SH_PERSON_CAND, _
        SH_SHOP_TARGET, SH_WORK_CASH, SH_OUTPUT_TX, SH_OUTPUT_BAL, _
        SH_OUTPUT_TX_CONVERTED, SH_ANALYSIS_SHIFT, SH_ANALYSIS_FLOW, _
        SH_ANALYSIS_UNKNOWN, SH_ANALYSIS_RESULT, SH_ANALYSIS_DETAIL, _
        SH_WORK_ANALYSIS_GROUP, SH_WORK_ANALYSIS_REVIEW, _
        SH_WORK_ANALYSIS_HISTORY, SH_WORK_MANUAL_FLOW, _
        SH_BALANCE_RECONCILIATION, SH_SETUP_LOG)
End Function

Public Function ValidateAuthoritativeDataStructure( _
        ByRef problems As String, _
        Optional ByVal requireCaseReady As Boolean = False, _
        Optional ByVal allowInitializingState As Boolean = False, _
        Optional ByVal includeAllocationLedger As Boolean = True) As Boolean
    '保存・登録・帳票更新が依存する中核4表だけを、副作用なしで検査する。
    '画面座標、倍率、固定位置、印刷ドライバー、候補シート、派生帳票は対象外。
    On Error GoTo EH
    problems = vbNullString
    ValidateAuthoritativeDataStructure = _
        CheckAuthoritativeStoreStructure(problems, requireCaseReady, _
                                         allowInitializingState, includeAllocationLedger)
    Exit Function
EH:
    problems = "・中核データ構造を検査できません: Err " & _
               CStr(Err.Number) & ": " & Err.Description
    ValidateAuthoritativeDataStructure = False
    Err.Clear
End Function

Public Function ValidateNormalSaveStructure(ByRef problems As String) As Boolean
    '保存イベントから呼ぶ副作用なしの軽量ゲート。全UI診断やログ書込みは行わず、
    '必須シート、重要見出し、内部正本だけを保存前にfail-closedで確認する。
    Dim item As Variant
    On Error GoTo EH
    problems = vbNullString
    For Each item In RequiredToolSheetNames()
        '補助ログの欠落だけで案件データを保存不能にしない。
        If CStr(item) <> SH_CHECK And CStr(item) <> SH_SETUP_LOG Then
            If Not SheetExists(CStr(item)) Then _
                problems = problems & "・必須シート不足: " & CStr(item) & vbCrLf
        End If
    Next item
    If Len(problems) > 0 Then Exit Function
    If Not ValidateAuthoritativeDataStructure(problems, False, False, False) Then Exit Function
    If Not ValidateAllocationLedgerForSave(problems) Then Exit Function
    CheckCriticalWorkbookHeaders problems
    ValidateNormalSaveStructure = (Len(problems) = 0)
    Exit Function
EH:
    problems = "・保存前構造検査を実行できません: Err " & _
               CStr(Err.Number) & ": " & Err.Description
    ValidateNormalSaveStructure = False
    Err.Clear
End Function

Public Sub RecordSaveStructureFailureForInspection(ByVal detailText As String)
    '管理SaveAsで新しい診断コピーを作成した後、そのコピーだけへ根拠を記録する。
    '元ファイルや、SaveAsダイアログを取り消したブックは変更しない。
    If Len(detailText) = 0 Then Exit Sub
    mLastSetupFailureAt = Now
    mLastSetupFailureStep = "保存前構造検査"
    mLastSetupFailureState = "Err " & CStr(vbObjectError + 1136)
    mLastSetupFailure = "Step: " & mLastSetupFailureStep & _
                        " / Source: Workbook_BeforeSave" & _
                        " / " & mLastSetupFailureState & ": " & detailText
    mFailureDetailLogged = False
    'W_セットアップログ自体の欠落が構造エラー原因でも、ここで停止させない。
    '根拠は先にメモリへ保持し、PrepareFailedSetupForInspectionがC_チェックへの
    '検証付き代替記録と、保存を許可できるだけの証拠有無を判定する。
    On Error Resume Next
    Err.Clear
    LogStep "エラー", mLastSetupFailureStep, mLastSetupFailureState, detailText
    Err.Clear
    On Error GoTo 0
End Sub

Private Sub CheckCriticalWorkbookHeaders(ByRef problems As String)
    '保存の再開に必要な内部表・分析表の見出しだけを共通契約で確認する。
    CheckHeaderRowExact GetSheet(SH_WORK_CASH), 1, _
        Array("銀行名", "支店名", "氏名", "科目", "口座番号", "日付", "時刻", "出金", "入金", "取扱店", "機番", _
              "摘要欄", "残高", "口座ID", "取引ID", "行種別", "入力順"), _
        "W_資金操作表", problems
    CheckHeaderRowExact GetSheet(SH_OUTPUT_TX), CASH_VIEW_HEADER_ROW, _
        Array("銀行名", "支店名", "氏名", "科目", "口座番号", "日付", "時刻", "出金", "入金", "取扱店", "機番", _
              "摘要欄", "残高", "口座ID", "取引ID", "行種別", "入力順", "表示対象", "候補内役割", "手動選択"), _
        "資金操作表", problems
    CheckHeaderRowExact GetSheet(SH_OUTPUT_TX_CONVERTED), 1, _
        Array("銀行名", "支店名", "氏名", "科目", "口座番号", "日付", "時刻", "出金", "入金", "取扱店", "機番", _
              "摘要欄", "残高", "口座ID", "取引ID", "行種別", "入力順"), _
        "資金操作表_取扱店変換済", problems
    CheckHeaderRowExact GetSheet(SH_ANALYSIS_SHIFT), 1, _
        ShiftAnalysisHeaders(), "資金シフト候補", problems
    CheckHeaderRowExact GetSheet(SH_ANALYSIS_FLOW), 1, _
        AdvancedFlowAnalysisHeaders(), "資金フロー追跡", problems
    CheckHeaderRowExact GetSheet(SH_ANALYSIS_UNKNOWN), 1, _
        UnknownAnalysisHeaders(), "不明入出金", problems
    CheckHeaderRowExact GetSheet(SH_ANALYSIS_RESULT), 1, _
        AnalysisResultHeaders(), "分析結果", problems
    CheckHeaderRowExact GetSheet(SH_WORK_ANALYSIS_GROUP), 1, _
        AnalysisGroupHeaders(), "W_分析グループ", problems
    CheckHeaderRowExact GetSheet(SH_WORK_ANALYSIS_REVIEW), 1, _
        AnalysisReviewStoreHeaders(), "W_分析判断台帳", problems
    CheckHeaderRowExact GetSheet(SH_WORK_ANALYSIS_HISTORY), 1, _
        AnalysisReviewHistoryHeaders(), "W_分析判断履歴", problems
    CheckHeaderRowExact GetSheet(SH_WORK_MANUAL_FLOW), 1, _
        ManualFlowStoreHeaders(), "W_手動資金候補", problems
    CheckHeaderRowExact GetSheet(SH_BALANCE_RECONCILIATION), 1, _
        BalanceReconciliationHeaders(), "残高検算", problems
    CheckHeaderRowExact GetSheet(SH_ANALYSIS_STATUS), 1, _
        Array("分析確認状況"), "分析確認候補", problems
End Sub


Private Function TryGetSetupEnableEvents( _
        ByRef currentValue As Boolean, _
        ByRef detailText As String) As Boolean
    Dim errorNumber As Long, errorDescription As String
    detailText = vbNullString
    On Error GoTo EH
    currentValue = Application.EnableEvents
    TryGetSetupEnableEvents = True
    Exit Function
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    detailText = "Err " & CStr(errorNumber) & ": " & errorDescription
    Err.Clear
End Function

Private Function SetApplicationEnableEventsExact( _
        ByVal desiredValue As Boolean, _
        ByRef detailText As String) As Boolean
    Dim errorNumber As Long, errorDescription As String
    detailText = vbNullString
    On Error GoTo EH
    Application.EnableEvents = desiredValue
    If Application.EnableEvents <> desiredValue Then _
        Err.Raise vbObjectError + 1545, "SetApplicationEnableEventsExact", _
                  "EnableEventsの書込み後読戻しが一致しません。"
    SetApplicationEnableEventsExact = True
    Exit Function
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    detailText = "Err " & CStr(errorNumber) & ": " & errorDescription
    Err.Clear
End Function

Private Function SetupRecoveryStateIsConfirmedExact( _
        ByRef detailText As String) As Boolean
    '安全停止は状態表だけ、または独立ラッチだけの片方成功を認めない。
    '二つを別APIで読み戻し、双方が所定値の時だけ確定とする。
    Dim latchIsSet As Boolean, latchReadSucceeded As Boolean
    Dim healthValue As String, healthReadSucceeded As Boolean
    Dim errorNumber As Long, errorDescription As String
    detailText = vbNullString
    On Error GoTo EH
    latchReadSucceeded = TryGetRollbackRecoveryLatch(latchIsSet)
    healthReadSucceeded = _
        TryGetExactStateValue(STATE_DATA_HEALTH, healthValue)
    If Not latchReadSucceeded Or Not latchIsSet Then _
        AppendSetupRestoreDetail detailText, _
            "独立復旧ラッチ=Trueを一意に読み返せません。"
    If Not healthReadSucceeded Or _
       StrComp(healthValue, DATA_HEALTH_NEEDS_RECOVERY, _
               vbBinaryCompare) <> 0 Then _
        AppendSetupRestoreDetail detailText, _
            "案件要復旧状態を一意に読み返せません。"
    SetupRecoveryStateIsConfirmedExact = latchReadSucceeded And latchIsSet And _
        healthReadSucceeded And _
        (StrComp(healthValue, DATA_HEALTH_NEEDS_RECOVERY, _
                 vbBinaryCompare) = 0)
    Exit Function
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    AppendSetupRestoreDetail detailText, _
        "要復旧状態の二重確認 Err " & CStr(errorNumber) & " " & _
        errorDescription
    Err.Clear
End Function

Private Function IsSetupRecoveryFatalError( _
        ByVal errorNumber As Long, ByVal errorSource As String) As Boolean
    Dim expectedSource As String

    If errorNumber = vbObjectError + 3599 Or _
       errorNumber = vbObjectError + 4499 Then
        IsSetupRecoveryFatalError = True
        Exit Function
    End If
    Select Case errorNumber
        Case SETUP_CONVERGE_RECOVERY_FATAL_ERROR
            expectedSource = SETUP_CONVERGE_RECOVERY_FATAL_SOURCE
        Case ANALYSIS_WORKSPACE_RECOVERY_FATAL_ERROR
            expectedSource = ANALYSIS_WORKSPACE_RECOVERY_FATAL_SOURCE
        Case CASH_ANALYSIS_RECOVERY_FATAL_ERROR
            expectedSource = CASH_ANALYSIS_RECOVERY_FATAL_SOURCE
        Case TRANSACTION_ANALYSIS_RECOVERY_FATAL_ERROR
            expectedSource = TRANSACTION_ANALYSIS_RECOVERY_FATAL_SOURCE
        Case CASH_MANUAL_SELECTION_RECOVERY_FATAL_ERROR
            expectedSource = CASH_MANUAL_SELECTION_RECOVERY_FATAL_SOURCE
        Case CLEAR_RECOVERY_FATAL_ERROR
            expectedSource = CLEAR_RECOVERY_FATAL_SOURCE
        Case Else
            Exit Function
    End Select
    IsSetupRecoveryFatalError = _
        (Len(errorSource) >= Len(expectedSource)) And _
        (StrComp(Left$(errorSource, Len(expectedSource)), expectedSource, _
                 vbBinaryCompare) = 0)
End Function

Private Function SetupApplicationStateIsRestoredExact( _
        ByRef detailText As String) As Boolean
    Dim stateProblems As String
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim terminalEventsStopped As Boolean, terminalEventDetail As String
    On Error GoTo EH
    If Not AppStateIsRestored(stateProblems) Then _
        Err.Raise vbObjectError + 1844, _
                  "SetupApplicationStateIsRestoredExact", stateProblems
    SetupApplicationStateIsRestoredExact = True
    Exit Function
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    AppendSetupRestoreDetail detailText, _
        "Application状態の読戻し Err " & CStr(errorNumber) & " " & _
        errorDescription
    Err.Clear
End Function

Private Function TryRestoreSetupProtectionEntryEvents( _
        ByVal entryEventsCaptured As Boolean, _
        ByVal entryEvents As Boolean, _
        ByRef detailText As String) As Boolean
    Dim restoreDetail As String, safeStopDetail As String
    detailText = vbNullString
    If Not entryEventsCaptured Then
        detailText = "イベント開始値を取得できていません。"
        Exit Function
    End If
    If SetApplicationEnableEventsExact(entryEvents, restoreDetail) Then
        TryRestoreSetupProtectionEntryEvents = True
        Exit Function
    End If
    If SetApplicationEnableEventsExact(entryEvents, restoreDetail) Then
        TryRestoreSetupProtectionEntryEvents = True
        Exit Function
    End If
    detailText = "開始値への復元: " & restoreDetail
    If Not SetApplicationEnableEventsExact(False, safeStopDetail) Then _
        detailText = detailText & " / イベント安全停止: " & safeStopDetail
End Function


Public Function ValidateCorePersonStoreSafety(ByRef problems As String, _
                                              Optional ByVal includePersonCandidates As Boolean = True) As Boolean
    '分析前の読取りでも、数式の計算結果やExcelエラーを確定人物データとして扱わない。
    '画面表示や書込みは行わず、W_口座・W_取引・W_残高を検査する。
    '候補を更新する操作だけ、includePersonCandidates=Trueで人物候補も対象にする。
    On Error GoTo Failed
    problems = vbNullString
    If Not SheetExists(SH_WORK_TX) Then problems = problems & "・W_取引がありません" & vbCrLf
    If Not SheetExists(SH_WORK_BAL) Then problems = problems & "・W_残高がありません" & vbCrLf
    If Not SheetExists(SH_WORK_ACCOUNT) Then problems = problems & "・W_口座がありません" & vbCrLf
    If includePersonCandidates Then
        If Not SheetExists(SH_PERSON_CAND) Then _
            problems = problems & "・人物候補がありません" & vbCrLf
    End If
    If Len(problems) > 0 Then Exit Function

    CheckContiguousDataStore GetSheet(SH_WORK_TX), WORK_TX_COL_ACCOUNT_ID, _
                             WORK_TX_COL_PERSON_ID, MAX_INTERNAL_STORE_DATA_ROWS, _
                             "W_取引", problems
    CheckContiguousDataStore GetSheet(SH_WORK_BAL), WORK_BAL_COL_ACCOUNT_ID, _
                             WORK_BAL_COL_PERSON_ID, MAX_INTERNAL_STORE_DATA_ROWS, _
                             "W_残高", problems
    CheckContiguousDataStore GetSheet(SH_WORK_ACCOUNT), ACC_COL_ID, _
                             ACC_COL_TRANSFER_ID, MAX_INTERNAL_STORE_DATA_ROWS, _
                             "W_口座", problems
    If includePersonCandidates Then _
        CheckContiguousDataStore GetSheet(SH_PERSON_CAND), 1, 4, _
                                 MAX_CANDIDATE_DATA_ROWS, "人物候補", problems
    CheckHeaderRowExact GetSheet(SH_WORK_TX), 1, _
        Array("銀行名", "支店名", "氏名", "科目", "口座番号", "日付", "時刻", "出金", "入金", "取扱店", "機番", _
              "摘要欄", "残高", "続柄", "口座ID", "転記回ID", "取引ID", "行種別", "入力順", "登録元", "人物ID"), _
        "W_取引", problems
    CheckHeaderRowExact GetSheet(SH_WORK_BAL), 1, _
        Array("氏名", "銀行名", "支店名", "科目", "口座番号", "口座開設日", "口座解約日", "残高基準日", "残高見出し", _
              "残高", "その他", "続柄", "口座ID", "転記回ID", "残高ID", "登録元", "人物ID"), _
        "W_残高", problems
    CheckHeaderRowExact GetSheet(SH_WORK_ACCOUNT), 1, _
        Array("口座ID", "銀行名", "支店名", "氏名", "続柄", "科目", "口座番号", "口座開設日", "口座解約日", _
              "人物ID", "登録元", "更新日時", "最新転記回ID"), _
        "W_口座", problems
    If includePersonCandidates Then _
        CheckHeaderRowExact GetSheet(SH_PERSON_CAND), 1, _
            Array("人物候補", "人物ID", "続柄", "区分"), "人物候補", problems
    CheckNoFormulasInDataSheet GetSheet(SH_WORK_TX), WORK_TX_COL_PERSON_ID, problems
    CheckNoFormulasInDataSheet GetSheet(SH_WORK_BAL), WORK_BAL_COL_PERSON_ID, problems
    CheckNoFormulasInDataSheet GetSheet(SH_WORK_ACCOUNT), ACC_COL_TRANSFER_ID, problems
    If includePersonCandidates Then _
        CheckNoFormulasInDataSheet GetSheet(SH_PERSON_CAND), 4, problems
    CheckNoErrorConstantsInDataSheet GetSheet(SH_WORK_TX), WORK_TX_COL_PERSON_ID, problems
    CheckNoErrorConstantsInDataSheet GetSheet(SH_WORK_BAL), WORK_BAL_COL_PERSON_ID, problems
    CheckNoErrorConstantsInDataSheet GetSheet(SH_WORK_ACCOUNT), ACC_COL_TRANSFER_ID, problems
    If includePersonCandidates Then _
        CheckNoErrorConstantsInDataSheet GetSheet(SH_PERSON_CAND), 4, problems
    ValidateCorePersonStoreSafety = (Len(problems) = 0)
    Exit Function
Failed:
    problems = problems & "・人物データ保管検査を完了できません（Err " & _
               CStr(Err.Number) & "）: " & Err.Description & vbCrLf
    ValidateCorePersonStoreSafety = False
End Function

Public Function RequireInternalStoresSafeForWrite( _
        Optional ByVal capacityAlreadyConfirmed As Boolean = False, _
        Optional ByVal includePersonCandidates As Boolean = True) As Boolean
    Dim problems As String, personIntegrityProblems As String
    If ThisWorkbook.ReadOnly Then
        MsgBox "このブックは読み取り専用で開かれています。" & vbCrLf & _
               "上書きできる場所へ別名保存してから、登録・訂正・初期化・帳票更新を実行してください。", _
               vbExclamation, "読み取り専用では更新できません"
        Exit Function
    End If
    If Not SheetExists(SH_WORK_TX) Or Not SheetExists(SH_WORK_BAL) Or _
       Not SheetExists(SH_WORK_ACCOUNT) Or Not SheetExists(SH_WORK_STATE) Then
        MsgBox "内部データシートが不足しています。セットアップを確認してください。", vbExclamation
        Exit Function
    End If
    If includePersonCandidates And Not SheetExists(SH_PERSON_CAND) Then
        MsgBox "人物候補シートが不足しています。セットアップを確認してください。", vbExclamation
        Exit Function
    End If
    'この後の人物整合性・主キー関係検査は案件規模のValue2配列を確保する。
    '最初の配列読込みより前に内部4保管の合計容量を判定し、32bit版でも安全停止する。
    If Not RequireCorePersonIntegrityCapacity( _
               "内部データの書込み前安全検査", capacityAlreadyConfirmed, _
               includePersonCandidates) Then Exit Function
    CheckContiguousDataStore GetSheet(SH_WORK_STATE), 1, 2, 100, "W_状態", problems
    CheckHeaderRowExact GetSheet(SH_WORK_STATE), 1, Array("項目", "値"), "W_状態", problems
    CheckNoFormulasInDataSheet GetSheet(SH_WORK_STATE), 2, problems
    CheckNoErrorConstantsInDataSheet GetSheet(SH_WORK_STATE), 2, problems
    CheckStateTable GetSheet(SH_WORK_STATE), problems
    '候補・帳票・登録の前に、人物IDだけでなく口座名義の継承も共通検査する。
    '検査本体は読取り専用であり、異常時の通知だけをこの外側入口が担当する。
    If Not ValidateCorePersonIntegrity(personIntegrityProblems, includePersonCandidates) Then _
        problems = problems & personIntegrityProblems
    If Len(personIntegrityProblems) = 0 Then _
        CheckCoreStoreRelationshipsForWrite problems
    If Len(problems) > 0 Then
        On Error Resume Next
        If SheetExists(SH_CHECK) Then AddCheck "エラー", "内部データ事前確認", Left$(Replace(problems, vbCrLf, " / "), 30000)
        On Error GoTo 0
        MsgBox "内部データに追記前の問題を検出したため、処理を中止しました。" & vbCrLf & _
               "下記の内容を確認してください。" & vbCrLf & vbCrLf & _
               Left$(problems, 3000), vbCritical
        Exit Function
    End If
    RequireInternalStoresSafeForWrite = True
End Function

Private Sub CheckCoreStoreRelationshipsForWrite(ByRef problems As String)
    '追記・訂正・削除前に、主キー・口座参照・最新転記回・人物IDの関係だけを配列で軽量確認する。
    Dim wsAcc As Worksheet, wsTx As Worksheet, wsBal As Worksheet
    Dim accountIDs As Object, personByAccount As Object, transferAccounts As Object
    Dim transactionIDs As Object, balanceIDs As Object
    Dim data As Variant, lastR As Long, r As Long
    Dim accountID As String, transferID As String, recordID As String, personID As String
    Dim labelText As String
    On Error GoTo EH
    If Not ValidateAllocationLedgerForSave(problems) Then Exit Sub
    Set accountIDs = CreateObject("Scripting.Dictionary")
    Set personByAccount = CreateObject("Scripting.Dictionary")
    Set transferAccounts = CreateObject("Scripting.Dictionary")
    Set transactionIDs = CreateObject("Scripting.Dictionary")
    Set balanceIDs = CreateObject("Scripting.Dictionary")
    accountIDs.CompareMode = vbTextCompare
    personByAccount.CompareMode = vbTextCompare
    transferAccounts.CompareMode = vbTextCompare
    transactionIDs.CompareMode = vbTextCompare
    balanceIDs.CompareMode = vbTextCompare

    Set wsAcc = GetSheet(SH_WORK_ACCOUNT)
    lastR = LastDataRowInColumns(wsAcc, 1, ACC_COL_TRANSFER_ID)
    If lastR >= 2 Then
        data = wsAcc.Range(wsAcc.Cells(2, 1), wsAcc.Cells(lastR, ACC_COL_TRANSFER_ID)).Value2
        For r = 1 To UBound(data, 1)
            accountID = CellText(data(r, ACC_COL_ID))
            transferID = CellText(data(r, ACC_COL_TRANSFER_ID))
            personID = CellText(data(r, ACC_COL_PERSON_ID))
            If Len(accountID) = 0 Then
                problems = problems & "・W_口座 " & CStr(r + 1) & "行: 口座IDなし" & vbCrLf
            ElseIf accountIDs.Exists(accountID) Then
                problems = problems & "・W_口座 " & CStr(r + 1) & "行: 口座ID重複 " & accountID & vbCrLf
            Else
                accountIDs.Add accountID, True
                personByAccount.Add accountID, personID
                If Not IsInternalIdValue(accountID, "A") Then _
                    problems = problems & "・W_口座 " & CStr(r + 1) & "行: 口座ID形式不正 " & accountID & vbCrLf
            End If
            If Len(transferID) = 0 Then
                problems = problems & "・W_口座 " & CStr(r + 1) & "行: 最新転記回IDなし" & vbCrLf
            ElseIf Not IsInternalIdValue(transferID, "R") Then
                problems = problems & "・W_口座 " & CStr(r + 1) & "行: 最新転記回ID形式不正 " & transferID & vbCrLf
            End If
            CheckTransferAccountLink transferID, accountID, "W_口座", r + 1, _
                                     transferAccounts, problems
            If Len(personID) = 0 Then
                problems = problems & "・W_口座 " & CStr(r + 1) & "行: 人物IDなし" & vbCrLf
            ElseIf Not IsInternalIdValue(personID, "P") Then
                problems = problems & "・W_口座 " & CStr(r + 1) & "行: 人物ID形式不正 " & personID & vbCrLf
            End If
            If Len(problems) > 30000 Then Exit Sub
        Next r
    End If

    Set wsTx = GetSheet(SH_WORK_TX)
    lastR = LastDataRowInColumns(wsTx, 1, WORK_TX_COL_PERSON_ID)
    If lastR >= 2 Then
        data = wsTx.Range(wsTx.Cells(2, 1), wsTx.Cells(lastR, WORK_TX_COL_PERSON_ID)).Value2
        labelText = "W_取引"
        For r = 1 To UBound(data, 1)
            accountID = CellText(data(r, WORK_TX_COL_ACCOUNT_ID))
            transferID = CellText(data(r, WORK_TX_COL_TRANSFER_ID))
            recordID = CellText(data(r, WORK_TX_COL_TRANSACTION_ID))
            personID = CellText(data(r, WORK_TX_COL_PERSON_ID))
            If Not accountIDs.Exists(accountID) Then
                problems = problems & "・" & labelText & " " & CStr(r + 1) & "行: 孤立口座ID " & accountID & vbCrLf
            Else
                If personID <> CStr(personByAccount(accountID)) Then _
                    problems = problems & "・" & labelText & " " & CStr(r + 1) & "行: 人物IDが口座マスタと不一致" & vbCrLf
            End If
            If Len(transferID) = 0 Then
                problems = problems & "・" & labelText & " " & CStr(r + 1) & "行: 転記回IDなし" & vbCrLf
            Else
                If Not IsInternalIdValue(transferID, "R") Then _
                    problems = problems & "・" & labelText & " " & CStr(r + 1) & "行: 転記回ID形式不正 " & transferID & vbCrLf
                CheckTransferAccountLink transferID, accountID, labelText, r + 1, transferAccounts, problems
            End If
            If Len(recordID) = 0 Then
                problems = problems & "・" & labelText & " " & CStr(r + 1) & "行: 取引IDなし" & vbCrLf
            ElseIf transactionIDs.Exists(recordID) Then
                problems = problems & "・" & labelText & " " & CStr(r + 1) & "行: 取引ID重複 " & recordID & vbCrLf
            Else
                transactionIDs.Add recordID, True
                If Not IsInternalIdValue(recordID, "T") Then _
                    problems = problems & "・" & labelText & " " & CStr(r + 1) & "行: 取引ID形式不正 " & recordID & vbCrLf
            End If
            If Len(problems) > 30000 Then Exit Sub
        Next r
    End If

    Set wsBal = GetSheet(SH_WORK_BAL)
    lastR = LastDataRowInColumns(wsBal, 1, WORK_BAL_COL_PERSON_ID)
    If lastR >= 2 Then
        data = wsBal.Range(wsBal.Cells(2, 1), wsBal.Cells(lastR, WORK_BAL_COL_PERSON_ID)).Value2
        labelText = "W_残高"
        For r = 1 To UBound(data, 1)
            accountID = CellText(data(r, WORK_BAL_COL_ACCOUNT_ID))
            transferID = CellText(data(r, WORK_BAL_COL_TRANSFER_ID))
            recordID = CellText(data(r, WORK_BAL_COL_BALANCE_ID))
            personID = CellText(data(r, WORK_BAL_COL_PERSON_ID))
            If Not accountIDs.Exists(accountID) Then
                problems = problems & "・" & labelText & " " & CStr(r + 1) & "行: 孤立口座ID " & accountID & vbCrLf
            Else
                If personID <> CStr(personByAccount(accountID)) Then _
                    problems = problems & "・" & labelText & " " & CStr(r + 1) & "行: 人物IDが口座マスタと不一致" & vbCrLf
            End If
            If Len(transferID) = 0 Then
                problems = problems & "・" & labelText & " " & CStr(r + 1) & "行: 転記回IDなし" & vbCrLf
            Else
                If Not IsInternalIdValue(transferID, "R") Then _
                    problems = problems & "・" & labelText & " " & CStr(r + 1) & "行: 転記回ID形式不正 " & transferID & vbCrLf
                CheckTransferAccountLink transferID, accountID, labelText, r + 1, transferAccounts, problems
            End If
            If Len(recordID) = 0 Then
                problems = problems & "・" & labelText & " " & CStr(r + 1) & "行: 残高IDなし" & vbCrLf
            ElseIf balanceIDs.Exists(recordID) Then
                problems = problems & "・" & labelText & " " & CStr(r + 1) & "行: 残高ID重複 " & recordID & vbCrLf
            Else
                balanceIDs.Add recordID, True
                If Not IsInternalIdValue(recordID, "B") Then _
                    problems = problems & "・" & labelText & " " & CStr(r + 1) & "行: 残高ID形式不正 " & recordID & vbCrLf
            End If
            If Len(problems) > 30000 Then Exit Sub
        Next r
    End If
    Exit Sub
EH:
    problems = problems & "・内部データの関係を確認できません: " & Err.Description & vbCrLf
    Err.Clear
End Sub

Private Sub CheckContiguousDataStore(ByVal ws As Worksheet, ByVal keyColumn As Long, _
                                     ByVal expectedLastColumn As Long, ByVal maxDataRows As Long, _
                                     ByVal labelText As String, ByRef problems As String)
    Dim lastR As Long, sheetLastR As Long, keyLastR As Long, lastC As Long
    Dim blankCount As Double
    If ws Is Nothing Then Exit Sub
    On Error GoTo EH
    If Not TryGetLastUsedRowInSheet(ws, sheetLastR) Then
        problems = problems & "・" & labelText & "のシート最終行を確認できません" & vbCrLf
        Exit Sub
    End If
    lastR = LastDataRowInColumns(ws, 1, expectedLastColumn)
    If Not TryGetLastUsedColumnInSheet(ws, lastC) Then
        problems = problems & "・" & labelText & "のシート最終列を確認できません" & vbCrLf
        Exit Sub
    End If
    If lastR > maxDataRows + 1 Then
        problems = problems & "・" & labelText & "が実用上限（" & Format$(maxDataRows, "#,##0") & _
                   "行）を超えています" & vbCrLf
        Exit Sub
    End If
    If lastC > expectedLastColumn Then _
        problems = problems & "・" & labelText & "の規定列より右側に残存データがあります" & vbCrLf
    keyLastR = LastRow(ws, keyColumn)
    If lastR <> keyLastR Then
        problems = problems & "・" & labelText & "にキー列が空欄の残存行があります" & vbCrLf
        Exit Sub
    End If
    If lastR >= 2 Then
        blankCount = CDbl(Application.CountBlank(ws.Range(ws.Cells(2, keyColumn), ws.Cells(lastR, keyColumn))))
        If blankCount > 0 Then _
            problems = problems & "・" & labelText & "の途中にキー列が空欄の行があります" & vbCrLf
    End If
    Exit Sub
EH:
    problems = problems & "・" & labelText & "のデータ境界を確認できません: " & Err.Description & vbCrLf
    Err.Clear
End Sub


Private Sub CheckHeaderRowExact(ByVal ws As Worksheet, ByVal rowNo As Long, _
                                ByVal expectedValues As Variant, ByVal labelText As String, _
                                ByRef problems As String)
    Dim i As Long, colNo As Long, expectedText As String, shownExpected As String
    If ws Is Nothing Then Exit Sub
    For i = LBound(expectedValues) To UBound(expectedValues)
        colNo = i - LBound(expectedValues) + 1
        expectedText = CStr(expectedValues(i))
        If ws.Cells(rowNo, colNo).HasFormula Then
            problems = problems & "・" & labelText & " " & ws.Cells(rowNo, colNo).Address(False, False) & _
                       " 見出しに数式があります" & vbCrLf
        ElseIf IsError(ws.Cells(rowNo, colNo).Value) Then
            problems = problems & "・" & labelText & " " & ws.Cells(rowNo, colNo).Address(False, False) & _
                       " 見出しにExcelエラー値があります" & vbCrLf
        ElseIf StrComp(CellText(ws.Cells(rowNo, colNo).Value), expectedText, vbBinaryCompare) <> 0 Then
            If Len(expectedText) > 0 Then shownExpected = expectedText Else shownExpected = "空欄"
            problems = problems & "・" & labelText & " " & ws.Cells(rowNo, colNo).Address(False, False) & _
                       " 見出し不一致（期待: " & shownExpected & "）" & vbCrLf
        End If
    Next i
End Sub

Private Sub CheckListNameRange(ByVal nameText As String, ByVal ws As Worksheet, ByRef problems As String)
    Dim nm As Name
    Dim actualRange As Range, expectedRange As Range
    Dim lastR As Long
    If ws Is Nothing Then Exit Sub
    lastR = LastRow(ws, 1)
    If lastR < 2 Then lastR = 2
    Set expectedRange = ws.Range(ws.Cells(2, 1), ws.Cells(lastR, 1))
    On Error GoTo EH
    Set nm = ThisWorkbook.Names(nameText)
    Set actualRange = nm.RefersToRange
    If actualRange Is Nothing Then GoTo EH
    If StrComp(actualRange.Worksheet.Name, expectedRange.Worksheet.Name, vbTextCompare) <> 0 Or _
       StrComp(actualRange.Address(True, True, xlA1, False), _
               expectedRange.Address(True, True, xlA1, False), vbTextCompare) <> 0 Then
        problems = problems & "・定義名の参照先不一致: " & nameText & vbCrLf
    End If
    Exit Sub
EH:
    problems = problems & "・定義名不足または参照先不正: " & nameText & vbCrLf
    Err.Clear
End Sub

Private Sub CheckAnalysisStatusMaster(ByVal ws As Worksheet, ByRef problems As String)
    Dim expectedValues As Variant, r As Long, expectedCount As Long
    Dim lastUsedR As Long, lastUsedC As Long
    If ws Is Nothing Then Exit Sub
    expectedValues = Array( _
        ANALYSIS_STATUS_UNREVIEWED, ANALYSIS_STATUS_SHIFT_CONFIRMED, _
        ANALYSIS_STATUS_SOURCE_CONFIRMED, ANALYSIS_STATUS_USE_CONFIRMED, _
        ANALYSIS_STATUS_EXCLUDED, ANALYSIS_STATUS_FOLLOWUP, _
        ANALYSIS_STATUS_UNREVIEWED, ANALYSIS_STATUS_SHIFT_CONFIRMED, _
        ANALYSIS_STATUS_EXCLUDED, ANALYSIS_STATUS_FOLLOWUP, _
        ANALYSIS_STATUS_UNREVIEWED, ANALYSIS_STATUS_SOURCE_CONFIRMED, _
        ANALYSIS_STATUS_EXCLUDED, ANALYSIS_STATUS_FOLLOWUP, _
        ANALYSIS_STATUS_UNREVIEWED, ANALYSIS_STATUS_USE_CONFIRMED, _
        ANALYSIS_STATUS_EXCLUDED, ANALYSIS_STATUS_FOLLOWUP)
    expectedCount = UBound(expectedValues) - LBound(expectedValues) + 1
    If ws.Cells(1, 1).HasFormula Or IsError(ws.Cells(1, 1).Value) Or _
       StrComp(CellText(ws.Cells(1, 1).Value), "分析確認状況", vbBinaryCompare) <> 0 Then
        problems = problems & "・分析確認候補の見出しが不正です" & vbCrLf
    End If
    If Not TryGetLastUsedRowInSheet(ws, lastUsedR) Or _
       Not TryGetLastUsedColumnInSheet(ws, lastUsedC) Then
        problems = problems & "・分析確認候補のデータ境界を確認できません" & vbCrLf
        Exit Sub
    End If
    If lastUsedR <> expectedCount + 1 Or lastUsedC <> 1 Then
        problems = problems & "・分析確認候補の選択肢構成が不正です" & vbCrLf
        Exit Sub
    End If
    For r = 1 To expectedCount
        If ws.Cells(r + 1, 1).HasFormula Or IsError(ws.Cells(r + 1, 1).Value) Or _
           StrComp(CellText(ws.Cells(r + 1, 1).Value), _
                   CStr(expectedValues(LBound(expectedValues) + r - 1)), vbBinaryCompare) <> 0 Then
            problems = problems & "・分析確認候補 " & CStr(r + 1) & "行: 選択肢が不正です" & vbCrLf
        End If
    Next r
End Sub

Private Sub CheckAnalysisStatusNameRanges(ByVal ws As Worksheet, ByRef problems As String)
    If ws Is Nothing Then Exit Sub
    CheckNamedRangeExact NM_LST_ANALYSIS_STATUS, ws.Range("A2:A7"), problems
    CheckNamedRangeExact NM_LST_ANALYSIS_SHIFT_STATUS, ws.Range("A8:A11"), problems
    CheckNamedRangeExact NM_LST_ANALYSIS_SOURCE_STATUS, ws.Range("A12:A15"), problems
    CheckNamedRangeExact NM_LST_ANALYSIS_USE_STATUS, ws.Range("A16:A19"), problems
End Sub

Private Sub CheckNamedRangeExact(ByVal nameText As String, ByVal expectedRange As Range, _
                                 ByRef problems As String)
    Dim nm As Name, actualRange As Range
    If expectedRange Is Nothing Then Exit Sub
    On Error GoTo EH
    Set nm = ThisWorkbook.Names(nameText)
    Set actualRange = nm.RefersToRange
    If actualRange Is Nothing Then GoTo EH
    If StrComp(actualRange.Worksheet.Name, expectedRange.Worksheet.Name, vbTextCompare) <> 0 Or _
       StrComp(actualRange.Address(True, True, xlA1, False), _
               expectedRange.Address(True, True, xlA1, False), vbTextCompare) <> 0 Then
        problems = problems & "・定義名の参照先不一致: " & nameText & vbCrLf
    End If
    Exit Sub
EH:
    problems = problems & "・定義名不足または参照先不正: " & nameText & vbCrLf
    Err.Clear
End Sub

Private Sub CheckStaticChoiceList(ByVal ws As Worksheet, ByVal expectedHeader As String, _
                                  ByVal expectedValues As Variant, ByRef problems As String)
    Dim lastR As Long, lastC As Long, expectedCount As Long, r As Long
    Dim sourceData As Variant, seen As Object, valueText As String
    If ws Is Nothing Then Exit Sub
    If ws.Cells(1, 1).HasFormula Then
        problems = problems & "・" & ws.Name & "の見出しに数式があります" & vbCrLf
    ElseIf IsError(ws.Cells(1, 1).Value) Then
        problems = problems & "・" & ws.Name & "の見出しにExcelエラー値があります" & vbCrLf
    ElseIf CellText(ws.Cells(1, 1).Value) <> expectedHeader Then
        problems = problems & "・" & ws.Name & "の見出しが不正です" & vbCrLf
    End If
    If Not TryGetLastUsedRowInSheet(ws, lastR) Or _
       Not TryGetLastUsedColumnInSheet(ws, lastC) Then
        problems = problems & "・" & ws.Name & "のデータ境界を確認できません" & vbCrLf
        Exit Sub
    End If
    expectedCount = UBound(expectedValues) - LBound(expectedValues) + 1
    If lastR <> expectedCount + 1 Or lastC <> 1 Then
        problems = problems & "・" & ws.Name & "の選択肢構成が不正です" & vbCrLf
        Exit Sub
    End If
    sourceData = ws.Range(ws.Cells(2, 1), ws.Cells(lastR, 1)).Value2
    Set seen = CreateObject("Scripting.Dictionary")
    seen.CompareMode = vbTextCompare
    For r = 1 To expectedCount
        valueText = CellText(sourceData(r, 1))
        If StrComp(valueText, CStr(expectedValues(LBound(expectedValues) + r - 1)), vbTextCompare) <> 0 Then _
            problems = problems & "・" & ws.Name & " " & CStr(r + 1) & "行: 選択肢が不正です" & vbCrLf
        If seen.Exists(valueText) Then
            problems = problems & "・" & ws.Name & " " & CStr(r + 1) & "行: 選択肢が重複しています" & vbCrLf
        Else
            seen.Add valueText, True
        End If
    Next r
End Sub


Private Sub CheckConfigValidationStructure(ByRef problems As String)
    CheckValidationRange GetCfgCell(ROW_CFG_INHERITANCE_DATE), xlValidateInputOnly, "", True, "相続開始日設定", problems
    CheckValidationRange GetSheet(SH_CONFIG).Range( _
        GetCfgCell(ROW_CFG_BAL_START_YEAR), GetCfgCell(ROW_CFG_YEAR_ADD)), _
        xlValidateInputOnly, "", True, "残高年設定", problems
    CheckValidationRange GetCfgCell(ROW_CFG_INPUT_MODE), xlValidateList, NM_LST_INPUT_MODE, False, "入力モード設定", problems
    CheckValidationRange GetCfgCell(ROW_CFG_YEAR_MODE), xlValidateList, NM_LST_YEAR_MODE, False, "年入力方式設定", problems
    CheckValidationRange GetCfgCell(ROW_CFG_RELATIONSHIP), xlValidateList, NM_LST_DISPLAY_OPTION, False, "続柄表示設定", problems
    CheckValidationRange GetCfgCell(ROW_CFG_SHOW_INHERITANCE_ROW), xlValidateList, NM_LST_DISPLAY_OPTION, False, "相続開始日行設定", problems
    CheckValidationRange GetCfgCell(ROW_CFG_SHOW_OPEN_DATE_ROW), xlValidateList, NM_LST_DISPLAY_OPTION, False, "口座開設日行設定", problems
    CheckValidationRange GetCfgCell(ROW_CFG_SHOW_CLOSE_DATE_ROW), xlValidateList, NM_LST_DISPLAY_OPTION, False, "口座解約日行設定", problems
    CheckValidationRange GetCfgCell(ROW_CFG_SHOW_BALANCE_ROWS), xlValidateList, NM_LST_DISPLAY_OPTION, False, "残高行設定", problems
    CheckValidationRange GetCfgCell(ROW_CFG_POST_KEEP), xlValidateList, NM_LST_POST_KEEP, False, "口座情報保持設定", problems
    CheckValidationRange GetCfgCell(ROW_CFG_POST_TX), xlValidateList, NM_LST_POST_CLEAR, False, "取引明細後処理設定", problems
    CheckValidationRange GetCfgCell(ROW_CFG_POST_BAL), xlValidateList, NM_LST_POST_CLEAR, False, "残高後処理設定", problems
    CheckValidationRange GetSheet(SH_CONFIG).Range( _
        GetSheet(SH_CONFIG).Cells(ROW_CFG_ANALYSIS_MIN_AMOUNT, COL_CFG_ANALYSIS_VALUE), _
        GetSheet(SH_CONFIG).Cells(ROW_CFG_ANALYSIS_UNKNOWN_MIN, COL_CFG_ANALYSIS_VALUE)), _
        xlValidateInputOnly, "", True, "分析条件設定", problems
End Sub

Private Sub CheckValidationRange(ByVal originalRange As Range, ByVal expectedType As Long, _
                                 ByVal expectedListName As String, ByVal allowFreeText As Boolean, _
                                 ByVal labelText As String, ByRef problems As String)
    Dim target As Range, validationCells As Range, coveredCells As Range, cell As Range
    Dim chunkRange As Range
    Dim typeValue As Variant, formulaValue As Variant, showErrorValue As Variant
    Dim issueText As String, addressText As String
    Dim aggregateReadable As Boolean
    Dim uniformCriteria As Boolean, uniformCriteriaKnown As Boolean
    Dim validationCoverageKnown As Boolean
    Dim specialCellsErrorNumber As Long
    Dim rowOffset As Long, chunkRowCount As Long, splitRowCount As Long
    Dim problemsLengthBefore As Long
    On Error GoTo EH
    Set target = EffectiveRange(originalRange)
    If target Is Nothing Then Set target = originalRange
    If target Is Nothing Then GoTo EH
    addressText = target.Worksheet.Name & "!" & target.Address(False, False)

    'SpecialCellsは対象が1セルだけの時にシート全体を検索するExcel固有の挙動がある。
    '結合欄は左上セルだけを返すビルドがあるため1入力欄として扱い、
    'それ以外の複数セル時もIntersectで対象範囲内だけを数える。
    If CDbl(target.CountLarge) > 1 And Not IsSingleMergeArea(target) Then
        On Error Resume Next
        Err.Clear
        Set validationCells = target.SpecialCells(xlCellTypeAllValidation)
        specialCellsErrorNumber = Err.Number
        Err.Clear
        If Not validationCells Is Nothing Then Set coveredCells = Intersect(target, validationCells)
        If Err.Number <> 0 Then specialCellsErrorNumber = Err.Number
        Err.Clear
        On Error GoTo EH
        validationCoverageKnown = (specialCellsErrorNumber = 0 And Not validationCells Is Nothing)
        If validationCoverageKnown Then
            If coveredCells Is Nothing Then
                validationCoverageKnown = False
            ElseIf CDbl(coveredCells.CountLarge) <> CDbl(target.CountLarge) Then
                'SpecialCellsは異なる入力メッセージを含む複合範囲や大量範囲で、
                '規則が全セルにあっても部分集合だけを返すビルドがある。
                'この結果だけでは欠落と断定せず、下の分割・セル別読戻しへ送る。
                validationCoverageKnown = False
            End If
        End If

        uniformCriteria = ValidationRangeHasUniformCriteria(target, uniformCriteriaKnown)

        '通常はRange.Validationの集約値で高速確認する。混在・取得不能の時だけ
        '下のセル別診断へ進み、大量明細範囲を常時COM読取しない。
        On Error Resume Next
        Err.Clear
        typeValue = target.Validation.Type
        aggregateReadable = (Err.Number = 0 And Not IsNull(typeValue))
        If aggregateReadable And expectedType = xlValidateList Then
            formulaValue = target.Validation.Formula1
            If Err.Number <> 0 Or IsNull(formulaValue) Then aggregateReadable = False
            Err.Clear
            showErrorValue = target.Validation.ShowError
            If Err.Number <> 0 Or IsNull(showErrorValue) Then aggregateReadable = False
        End If
        Err.Clear
        On Error GoTo EH
        If aggregateReadable Then
            If CLng(typeValue) <> expectedType Then _
                issueText = target.Cells(1, 1).Address(False, False) & "の種類が不一致": GoTo InvalidValidation
            If expectedType = xlValidateList Then
                If Not ValidationListSourceMatches(target.Cells(1, 1), CellText(formulaValue), expectedListName) Then _
                    issueText = target.Cells(1, 1).Address(False, False) & _
                                "の候補参照先が不一致（期待: =" & expectedListName & _
                                " / 実際: " & ValidationFormulaDiagnostic(CellText(formulaValue)) & _
                                "）": GoTo InvalidValidation
                If CBool(showErrorValue) <> (Not allowFreeText) Then _
                    issueText = target.Cells(1, 1).Address(False, False) & "の候補外入力設定が不一致": GoTo InvalidValidation
            End If
            'SameValidationが対象全体を返した時は、それ自体が規則の存在と統一を証明する。
            'AllValidation取得不能はOfficeビルド差があるため、欠落と断定せず下の直接確認へ送る。
            If uniformCriteriaKnown And uniformCriteria Then Exit Sub
        End If
    End If

    '結合欄は論理1セルへ正規化する。それ以外の大範囲は、ShowErrorを含む
    '全プロパティの混在を見逃さないよう、集約不能時に行ブロックへ分割する。
    If IsSingleMergeArea(target) Then
        Set target = target.Cells(1, 1)
    ElseIf CDbl(target.Rows.CountLarge) > VALIDATION_CHECK_DIRECT_ROWS Then
            '大範囲の集約値を取得できない時は、まず通常ブロック、次に最大64行へ
            '段階分割する。各子範囲でも集約fast pathを再試行し、最後だけセル別診断する。
            If CDbl(target.Rows.CountLarge) > VALIDATION_CHECK_CHUNK_ROWS Then
                splitRowCount = VALIDATION_CHECK_CHUNK_ROWS
            Else
                splitRowCount = VALIDATION_CHECK_DIRECT_ROWS
            End If
            For rowOffset = 1 To CLng(target.Rows.CountLarge) Step splitRowCount
                chunkRowCount = Application.Min(splitRowCount, _
                                                CLng(target.Rows.CountLarge) - rowOffset + 1)
                Set chunkRange = target.Rows(rowOffset).Resize(chunkRowCount, target.Columns.Count)
                problemsLengthBefore = Len(problems)
                CheckValidationRange chunkRange, expectedType, expectedListName, allowFreeText, _
                                     labelText, problems
                If Len(problems) > problemsLengthBefore Then Exit Sub
            Next rowOffset
            Exit Sub
    End If

    '小範囲で集約値を取得できない時だけセル別診断する。
    For Each cell In target.Cells
        issueText = ValidationCellIssue(cell, expectedType, expectedListName, allowFreeText)
        If Len(issueText) > 0 Then GoTo InvalidValidation
    Next cell
    Exit Sub
InvalidValidation:
    problems = problems & "・入力規則: " & labelText & "（" & addressText & "）: " & issueText & vbCrLf
    Exit Sub
EH:
    problems = problems & "・入力規則: " & labelText & "（" & addressText & "）を確認できません: " & Err.Description & vbCrLf
    Err.Clear
End Sub

Private Function ValidationCellIssue(ByVal originalCell As Range, ByVal expectedType As Long, _
                                     ByVal expectedListName As String, ByVal allowFreeText As Boolean) As String
    Dim cell As Range
    Dim typeValue As Variant, formulaValue As Variant, showErrorValue As Variant
    Dim addressText As String
    On Error GoTo EH
    If originalCell Is Nothing Then
        ValidationCellIssue = "対象セルなし"
        Exit Function
    End If
    Set cell = originalCell
    If cell.MergeCells Then Set cell = cell.MergeArea.Cells(1, 1)
    addressText = cell.Address(False, False)
    typeValue = cell.Validation.Type
    If IsNull(typeValue) Then
        ValidationCellIssue = addressText & "の種類を取得不能"
        Exit Function
    End If
    If CLng(typeValue) <> expectedType Then
        ValidationCellIssue = addressText & "の種類が不一致"
        Exit Function
    End If
    If expectedType <> xlValidateList Then Exit Function
    formulaValue = cell.Validation.Formula1
    showErrorValue = cell.Validation.ShowError
    If IsNull(formulaValue) Then
        ValidationCellIssue = addressText & "の参照先を取得不能"
        Exit Function
    End If
    If Not ValidationListSourceMatches(cell, CellText(formulaValue), expectedListName) Then
        ValidationCellIssue = addressText & "の候補参照先が不一致（期待: =" & _
                              expectedListName & " / 実際: " & _
                              ValidationFormulaDiagnostic(CellText(formulaValue)) & "）"
        Exit Function
    End If
    If IsNull(showErrorValue) Then
        ValidationCellIssue = addressText & "の候補外入力設定を取得不能"
    ElseIf CBool(showErrorValue) <> (Not allowFreeText) Then
        ValidationCellIssue = addressText & "の候補外入力設定が不一致"
    End If
    Exit Function
EH:
    If Len(addressText) = 0 Then addressText = "対象セル"
    ValidationCellIssue = addressText & "を確認できません: " & Err.Description
    Err.Clear
End Function


Private Function RangeHasLockedState(ByVal target As Range, ByVal expectedLocked As Boolean) As Boolean
    Dim stateValue As Variant
    If target Is Nothing Then Exit Function
    stateValue = target.Locked
    If IsNull(stateValue) Then Exit Function
    RangeHasLockedState = (CBool(stateValue) = expectedLocked)
End Function


Private Sub CheckTransferAccountLink(ByVal transferID As String, ByVal accountID As String, _
                                     ByVal sheetName As String, ByVal rowNo As Long, _
                                     ByVal transferAccounts As Object, ByRef problems As String)
    If transferAccounts Is Nothing Then Exit Sub
    If Len(transferID) = 0 Or Len(accountID) = 0 Then Exit Sub
    If transferAccounts.Exists(transferID) Then
        If CStr(transferAccounts(transferID)) <> accountID Then
            problems = problems & "・" & sheetName & " " & rowNo & "行: 転記回IDが別口座でも使用されています " & transferID & vbCrLf
        End If
    Else
        transferAccounts.Add transferID, accountID
    End If
End Sub

Public Function IsInternalIdValue(ByVal idText As String, ByVal prefixText As String) As Boolean
    Dim suffixText As String, i As Long, ch As String, suffixNumber As Double
    On Error GoTo InvalidID
    idText = Trim$(idText)
    If Len(idText) <= Len(prefixText) Then Exit Function
    If StrComp(Left$(idText, Len(prefixText)), prefixText, vbTextCompare) <> 0 Then Exit Function
    suffixText = Mid$(idText, Len(prefixText) + 1)
    For i = 1 To Len(suffixText)
        ch = Mid$(suffixText, i, 1)
        If ch < "0" Or ch > "9" Then Exit Function
    Next i
    suffixNumber = Val(suffixText)
    If suffixNumber < 1 Or suffixNumber > 2147483646# Then Exit Function
    IsInternalIdValue = True
    Exit Function
InvalidID:
    IsInternalIdValue = False
End Function

Private Function IsStoredDateValue(ByVal valueIn As Variant) As Boolean
    Dim normalized As Variant
    Dim ok As Boolean
    If IsError(valueIn) Or IsNull(valueIn) Or IsEmpty(valueIn) Then Exit Function
    If Len(CellText(valueIn)) = 0 Then Exit Function
    normalized = NormalizeDateOnlyValue(valueIn, ok)
    If Not ok Then Exit Function
    '日付列へ時刻成分が混入していないことも確認する。
    IsStoredDateValue = (Abs(CDbl(CDate(valueIn)) - CDbl(CDate(normalized))) < 0.0000001)
End Function


Private Sub CheckConfigurationValues(ByRef problems As String)
    Dim v As Variant, n As Double, analysisDetail As String
    CheckConfigChoice ROW_CFG_INPUT_MODE, Array(MODE_NORMAL, MODE_NO_TIME, MODE_NO_MACHINE, MODE_NO_TEKIYO, MODE_WITH_OTHER, MODE_SIMPLE), "入力モード", problems
    CheckConfigChoice ROW_CFG_POST_KEEP, Array(KEEP_NONE, KEEP_PERSON_ONLY, KEEP_BANK_BRANCH, KEEP_BANK_BRANCH_PERSON_TYPE), "転記後に残す口座情報", problems
    CheckConfigChoice ROW_CFG_POST_TX, Array(POST_CLEAR, POST_KEEP), "転記後の取引明細", problems
    CheckConfigChoice ROW_CFG_POST_BAL, Array(POST_CLEAR, POST_KEEP), "転記後の残高欄", problems
    CheckConfigChoice ROW_CFG_YEAR_MODE, Array(YEAR_MODE_WAREKI, YEAR_MODE_WESTERN2), "年入力方式", problems
    CheckConfigChoice ROW_CFG_RELATIONSHIP, Array(DISPLAY_ON, DISPLAY_OFF), "続柄の入力・表示", problems
    CheckConfigChoice ROW_CFG_SHOW_INHERITANCE_ROW, Array(DISPLAY_ON, DISPLAY_OFF), "相続開始日行", problems
    CheckConfigChoice ROW_CFG_SHOW_OPEN_DATE_ROW, Array(DISPLAY_ON, DISPLAY_OFF), "口座開設日行", problems
    CheckConfigChoice ROW_CFG_SHOW_CLOSE_DATE_ROW, Array(DISPLAY_ON, DISPLAY_OFF), "口座解約日行", problems
    CheckConfigChoice ROW_CFG_SHOW_BALANCE_ROWS, Array(DISPLAY_ON, DISPLAY_OFF), "残高行", problems
    v = GetCfgCell(ROW_CFG_YEAR_ADD).Value
    If IsError(v) Then
        problems = problems & "・設定値不正: 西暦2桁加算値" & vbCrLf
    ElseIf Not IsNumeric(v) Then
        problems = problems & "・設定値不正: 西暦2桁加算値" & vbCrLf
    Else
        n = CDbl(v)
        If n <> Fix(n) Or n < 1800 Or n > 2500 Then _
            problems = problems & "・設定値不正: 西暦2桁加算値は1800～2500の整数にしてください。" & vbCrLf
    End If
    If Not ValidateTransactionAnalysisSettings(analysisDetail) Then _
        problems = problems & "・分析設定値不正: " & analysisDetail & vbCrLf
    CheckEraMaster problems
End Sub

Private Sub CheckEraMaster(ByRef problems As String)
    Dim ws As Worksheet, keys As Object
    Dim r As Long, r2 As Long, c As Long, keyText As String, enabledText As String
    Dim startValue As Variant, endValue As Variant, rowHasData As Boolean
    Dim startValue2 As Variant, endValue2 As Variant
    Set ws = GetSheet(SH_CONFIG)
    Set keys = CreateObject("Scripting.Dictionary")
    keys.CompareMode = vbTextCompare
    For r = ERA_MASTER_FIRST_ROW To ERA_MASTER_MAX_ROW
        rowHasData = False
        For c = ERA_COL_CODE To ERA_COL_ENABLED
            If HasText(ws.Cells(r, c).Value) Then rowHasData = True: Exit For
        Next c
        If rowHasData Then
            For c = ERA_COL_CODE To ERA_COL_ABBR
                keyText = NormalizeEraCheckKey(CellText(ws.Cells(r, c).Value))
                If Len(keyText) = 0 Then
                    problems = problems & "・元号マスタ " & r & "行: コード・名称・略称が不足" & vbCrLf
                ElseIf keys.Exists(keyText) Then
                    problems = problems & "・元号マスタ " & r & "行: キー重複 " & keyText & vbCrLf
                Else
                    keys.Add keyText, True
                End If
            Next c
            startValue = ws.Cells(r, ERA_COL_START).Value
            endValue = ws.Cells(r, ERA_COL_END).Value
            If Not IsStoredDateValue(startValue) Then
                problems = problems & "・元号マスタ " & r & "行: 開始日不正" & vbCrLf
            End If
            If HasText(endValue) Then
                If Not IsStoredDateValue(endValue) Then
                    problems = problems & "・元号マスタ " & r & "行: 終了日不正" & vbCrLf
                ElseIf IsStoredDateValue(startValue) Then
                    If CDate(endValue) < CDate(startValue) Then problems = problems & "・元号マスタ " & r & "行: 終了日が開始日より前" & vbCrLf
                End If
            End If
            enabledText = UCase$(CellText(ws.Cells(r, ERA_COL_ENABLED).Value))
            Select Case enabledText
                Case "TRUE", "1", "有効", "FALSE", "0", "無効"
                Case Else
                    problems = problems & "・元号マスタ " & r & "行: 有効欄は TRUE/FALSE で指定してください。" & vbCrLf
            End Select
        End If
    Next r

    '有効な元号期間が重なると同じ日を複数の元号で解釈できてしまうため、組合せで検査する。
    For r = ERA_MASTER_FIRST_ROW To ERA_MASTER_MAX_ROW - 1
        If EraRowEnabledForOverlapCheck(ws, r) Then
            startValue = ws.Cells(r, ERA_COL_START).Value
            endValue = ws.Cells(r, ERA_COL_END).Value
            If Not HasText(endValue) Then endValue = DateSerial(9999, 12, 31)
            For r2 = r + 1 To ERA_MASTER_MAX_ROW
                If EraRowEnabledForOverlapCheck(ws, r2) Then
                    startValue2 = ws.Cells(r2, ERA_COL_START).Value
                    endValue2 = ws.Cells(r2, ERA_COL_END).Value
                    If Not HasText(endValue2) Then endValue2 = DateSerial(9999, 12, 31)
                    If CDate(startValue) <= CDate(endValue2) And CDate(startValue2) <= CDate(endValue) Then
                        problems = problems & "・元号マスタ " & r & "行と" & r2 & "行: 有効期間が重複" & vbCrLf
                    End If
                End If
            Next r2
        End If
    Next r
End Sub

Private Function EraRowEnabledForOverlapCheck(ByVal ws As Worksheet, ByVal targetRow As Long) As Boolean
    Dim enabledText As String, startValue As Variant, endValue As Variant
    enabledText = UCase$(CellText(ws.Cells(targetRow, ERA_COL_ENABLED).Value))
    If enabledText <> "TRUE" And enabledText <> "1" And enabledText <> "有効" Then Exit Function
    startValue = ws.Cells(targetRow, ERA_COL_START).Value
    endValue = ws.Cells(targetRow, ERA_COL_END).Value
    If Not IsStoredDateValue(startValue) Then Exit Function
    If HasText(endValue) Then
        If Not IsStoredDateValue(endValue) Then Exit Function
        If CDate(endValue) < CDate(startValue) Then Exit Function
    End If
    EraRowEnabledForOverlapCheck = True
End Function

Private Function NormalizeEraCheckKey(ByVal valueText As String) As String
    Dim s As String
    s = valueText
    On Error Resume Next
    s = StrConv(s, vbNarrow)
    On Error GoTo 0
    s = UCase$(Trim$(s))
    s = Replace(s, " ", "")
    s = Replace(s, "　", "")
    NormalizeEraCheckKey = s
End Function

Private Sub CheckConfigChoice(ByVal configRow As Long, ByVal allowedValues As Variant, _
                              ByVal labelText As String, ByRef problems As String)
    Dim valueText As String, item As Variant, found As Boolean
    valueText = CellText(GetCfgCell(configRow).Value)
    For Each item In allowedValues
        If StrComp(valueText, CStr(item), vbTextCompare) = 0 Then found = True: Exit For
    Next item
    If Not found Then problems = problems & "・設定値不正: " & labelText & " = " & valueText & vbCrLf
End Sub

Private Sub CheckNoFormulasInDataSheet(ByVal ws As Worksheet, ByVal lastColumn As Long, ByRef problems As String)
    Dim lastR As Long
    Dim target As Range, formulaCell As Range
    If ws Is Nothing Or lastColumn < 1 Then Exit Sub
    lastR = LastDataRowInColumns(ws, 1, lastColumn)
    If lastR < 2 Then Exit Sub
    Set target = ws.Range(ws.Cells(2, 1), ws.Cells(lastR, lastColumn))
    If CDbl(target.CountLarge) = 1 Then
        If target.HasFormula Then _
            problems = problems & "・" & ws.Name & " " & target.Address(False, False) & _
                       ": 内部保管に数式があります" & vbCrLf
        Exit Sub
    End If
    If Not TryFindFirstFormulaCell(target, formulaCell) Then
        problems = problems & "・" & ws.Name & ": 内部保管の数式有無を確認できません" & vbCrLf
    ElseIf Not formulaCell Is Nothing Then
        problems = problems & "・" & ws.Name & " " & formulaCell.Address(False, False) & _
                   ": 内部保管に数式があります" & vbCrLf
    End If
End Sub

Private Sub CheckNoErrorConstantsInDataSheet(ByVal ws As Worksheet, ByVal lastColumn As Long, _
                                             ByRef problems As String)
    Dim lastR As Long
    Dim target As Range, errorCell As Range
    If ws Is Nothing Or lastColumn < 1 Then Exit Sub
    lastR = LastDataRowInColumns(ws, 1, lastColumn)
    If lastR < 2 Then Exit Sub
    Set target = ws.Range(ws.Cells(2, 1), ws.Cells(lastR, lastColumn))
    If CDbl(target.CountLarge) = 1 Then
        If IsError(target.Value2) And Not target.HasFormula Then _
            problems = problems & "・" & ws.Name & " " & target.Address(False, False) & _
                       ": Excelエラー値があります" & vbCrLf
        Exit Sub
    End If
    If Not TryFindFirstErrorConstantCell(target, errorCell) Then
        problems = problems & "・" & ws.Name & ": 内部保管のExcelエラー値を確認できません" & vbCrLf
    ElseIf Not errorCell Is Nothing Then
        problems = problems & "・" & ws.Name & " " & errorCell.Address(False, False) & _
                   ": Excelエラー値があります" & vbCrLf
    End If
End Sub


Private Sub CheckCandidateSheetTextLength(ByVal ws As Worksheet, ByVal maxLength As Long, ByRef problems As String)
    Dim lastR As Long, r As Long
    Dim sourceData As Variant, candidateText As String, sourceText As String, duplicateKey As String
    Dim seen As Object
    If ws Is Nothing Then Exit Sub
    lastR = LastDataRowInColumns(ws, 1, 4)
    If lastR < 2 Then Exit Sub
    sourceData = ws.Range(ws.Cells(2, 1), ws.Cells(lastR, 4)).Value2
    Set seen = CreateObject("Scripting.Dictionary")
    seen.CompareMode = vbTextCompare
    For r = 1 To UBound(sourceData, 1)
        If DataProblemLimitReached(problems) Then Exit Sub
        candidateText = CellText(sourceData(r, 1))
        sourceText = CellText(sourceData(r, 4))
        If Len(candidateText) = 0 Then
            If Len(CellText(sourceData(r, 2))) > 0 Or Len(CellText(sourceData(r, 3))) > 0 Or _
               Len(sourceText) > 0 Then _
                problems = problems & "・" & ws.Name & " " & CStr(r + 1) & _
                           "行: 候補値が空欄のまま他列に値が残っています" & vbCrLf
        ElseIf Len(candidateText) > maxLength Then
            problems = problems & "・" & ws.Name & " " & CStr(r + 1) & "行: 候補値が" & _
                       CStr(maxLength) & "文字を超えています" & vbCrLf
        End If
        If Len(candidateText) > 0 Then
            If ws.Name = SH_PERSON_CAND Then
                duplicateKey = PersonIdentityKey(candidateText, CellText(sourceData(r, 3))) & Chr$(29) & _
                               UCase$(CellText(sourceData(r, 2)))
            Else
                duplicateKey = UCase$(Trim$(candidateText))
            End If
            If seen.Exists(duplicateKey) Then
                problems = problems & "・" & ws.Name & " " & CStr(r + 1) & "行: 同一候補が重複しています" & vbCrLf
            Else
                seen.Add duplicateKey, True
            End If
        End If
        If ws.Name = SH_BANK_CAND Or ws.Name = SH_BRANCH_CAND Or ws.Name = SH_PERSON_CAND Then
            If sourceText <> CAND_SOURCE_CASE And sourceText <> CAND_SOURCE_COMMON Then _
                problems = problems & "・" & ws.Name & " " & CStr(r + 1) & "行: 区分が不正です: " & sourceText & vbCrLf
        End If
    Next r
End Sub

Private Sub CheckStateTable(ByVal ws As Worksheet, ByRef problems As String, _
                            Optional ByVal allowInitializingState As Boolean = False)
    Dim requiredKeys As Variant, item As Variant
    Dim expected As Object, seen As Object
    Dim lastR As Long, r As Long, keyText As String, valueText As String
    Dim sourceData As Variant
    If ws Is Nothing Then Exit Sub
    If CellText(ws.Cells(1, 1).Value) <> "項目" Or CellText(ws.Cells(1, 2).Value) <> "値" Then _
        problems = problems & "・W_状態の見出しが不正です" & vbCrLf
    requiredKeys = Array(STATE_NEXT_ACCOUNT, STATE_NEXT_TRANSFER, STATE_NEXT_TRANSACTION, _
                         STATE_NEXT_BALANCE, STATE_NEXT_PERSON, STATE_EDIT_ACCOUNT, _
                         STATE_OUTPUT_DIRTY, STATE_ANALYSIS_REVIEW_DIRTY, STATE_LAST_BUILD, _
                         STATE_DATA_HEALTH, STATE_INPUT_DATE_CONFIG_SAFE)
    Set expected = CreateObject("Scripting.Dictionary")
    Set seen = CreateObject("Scripting.Dictionary")
    expected.CompareMode = vbTextCompare
    seen.CompareMode = vbTextCompare
    For Each item In requiredKeys
        expected.Add CStr(item), True
    Next item
    '現行版は安全状態と分析判断の更新状態を通常操作の前提にする。
    lastR = LastDataRowInColumns(ws, 1, 2)
    If lastR >= 2 Then
        sourceData = ws.Range(ws.Cells(2, 1), ws.Cells(lastR, 2)).Value2
        For r = 1 To UBound(sourceData, 1)
            If DataProblemLimitReached(problems) Then Exit Sub
            keyText = CellText(sourceData(r, 1))
            valueText = CellText(sourceData(r, 2))
            If Len(keyText) = 0 Then
                problems = problems & "・W_状態 " & CStr(r + 1) & "行: 項目名が空欄です" & vbCrLf
            ElseIf Not expected.Exists(keyText) Then
                '将来版や連携機能の追加メタデータは、必須キーの検査を妨げない。
                '対象キーの重複・値不正は下で引き続き厳格に検査する。
            ElseIf seen.Exists(keyText) Then
                problems = problems & "・W_状態 " & CStr(r + 1) & "行: 項目が重複しています: " & keyText & vbCrLf
            Else
                seen.Add keyText, True
                If keyText = STATE_NEXT_ACCOUNT Or keyText = STATE_NEXT_TRANSFER Or _
                   keyText = STATE_NEXT_TRANSACTION Or keyText = STATE_NEXT_BALANCE Or _
                   keyText = STATE_NEXT_PERSON Then
                    If Not IsValidStateCounterText(valueText) Then _
                        problems = problems & "・W_状態 " & CStr(r + 1) & "行: 採番値が不正です" & vbCrLf
                ElseIf keyText = STATE_OUTPUT_DIRTY Or _
                       keyText = STATE_ANALYSIS_REVIEW_DIRTY Or _
                       keyText = STATE_INPUT_DATE_CONFIG_SAFE Then
                    If valueText <> STATE_TRUE And valueText <> STATE_FALSE Then _
                        problems = problems & "・W_状態 " & CStr(r + 1) & _
                                   "行: 更新状態の値が不正です" & vbCrLf
                ElseIf keyText = STATE_EDIT_ACCOUNT Then
                    If Len(valueText) > 0 And Not IsInternalIdValue(valueText, "A") Then _
                        problems = problems & "・W_状態 " & CStr(r + 1) & "行: 訂正中口座IDの形式が不正です" & vbCrLf
                ElseIf keyText = STATE_LAST_BUILD Then
                    'W_状態は文字列保管なので、ここだけは日時文字列を許可する。
                    If Len(valueText) > 0 And Not IsDate(valueText) Then _
                        problems = problems & "・W_状態 " & CStr(r + 1) & "行: 最終帳票更新が不正です" & vbCrLf
                ElseIf keyText = STATE_DATA_HEALTH Then
                    If valueText <> DATA_HEALTH_NORMAL And _
                       Not (allowInitializingState And valueText = DATA_HEALTH_INITIALIZING) Then _
                        problems = problems & "・W_状態 " & CStr(r + 1) & _
                                   "行: 案件データが正常状態ではありません: " & valueText & vbCrLf
                End If
            End If
        Next r
    End If
    For Each item In requiredKeys
        If Not seen.Exists(CStr(item)) Then _
            problems = problems & "・W_状態: 必須項目がありません: " & CStr(item) & vbCrLf
    Next item
End Sub

Private Function IsValidStateCounterText(ByVal valueText As String) As Boolean
    Dim valueNumber As Double
    On Error GoTo InvalidCounter
    If Not IsNumeric(valueText) Then Exit Function
    valueNumber = CDbl(valueText)
    If valueNumber <> Fix(valueNumber) Then Exit Function
    '2147483647は採番上限到達を表す終端値。構造上は有効だが、
    'CheckCounterAheadが新規登録不能として明示的に報告する。
    If valueNumber < 1 Or valueNumber > 2147483647# Then Exit Function
    IsValidStateCounterText = True
    Exit Function
InvalidCounter:
    IsValidStateCounterText = False
    Err.Clear
End Function

Private Function DataProblemLimitReached(ByRef problems As String) As Boolean
    If Len(problems) < MAX_DATA_PROBLEM_DETAIL_CHARS Then Exit Function
    problems = Left$(problems, MAX_DATA_PROBLEM_DETAIL_CHARS) & vbCrLf & _
               "・問題件数が多すぎるため検査詳細を打ち切りました。先頭の問題を修正して再実行してください。" & vbCrLf
    DataProblemLimitReached = True
End Function

Private Sub CheckPanelActionSet(ByVal ws As Worksheet, ByVal expectedActions As Variant, _
                                ByVal panelLabel As String, ByRef problems As String)
    Dim expected As Object, seen As Object
    Dim shp As Shape, item As Variant, actionText As String, buttonCount As Long
    If ws Is Nothing Then Exit Sub
    On Error GoTo EH
    Set expected = CreateObject("Scripting.Dictionary")
    Set seen = CreateObject("Scripting.Dictionary")
    expected.CompareMode = vbTextCompare
    seen.CompareMode = vbTextCompare
    For Each item In expectedActions
        expected(CStr(item)) = True
    Next item
    For Each shp In ws.Shapes
        If Left$(shp.Name, Len(UI_PREFIX & "btn_")) = UI_PREFIX & "btn_" Then
            buttonCount = buttonCount + 1
            actionText = ToolShapeActionName(shp)
            If Not expected.Exists(actionText) Then
                problems = problems & "・" & panelLabel & "のボタン動作が不正: " & actionText & vbCrLf
            ElseIf seen.Exists(actionText) Then
                problems = problems & "・" & panelLabel & "の機能が重複: " & actionText & vbCrLf
            Else
                seen.Add actionText, True
            End If
            If Not ToolShapeActionMatches(shp, actionText, True) Then _
                problems = problems & "・" & panelLabel & "のOnActionが表示情報と不一致: " & actionText & vbCrLf
            If Not shp.Locked Then problems = problems & "・" & panelLabel & "のボタンがロックされていません: " & actionText & vbCrLf
        End If
    Next shp
    If buttonCount <> expected.Count Then _
        problems = problems & "・" & panelLabel & "のボタン数が不正: " & buttonCount & vbCrLf
    For Each item In expected.Keys
        If Not seen.Exists(CStr(item)) Then problems = problems & "・" & panelLabel & "の機能不足: " & CStr(item) & vbCrLf
    Next item
    Exit Sub
EH:
    problems = problems & "・" & panelLabel & "を確認できません。" & vbCrLf
End Sub


Public Sub ApplyRelationshipSettingToInput(Optional ByVal raiseOnError As Boolean = False)
    Dim ws As Worksheet
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim eventStateDetail As String
    Dim terminalEventsStopped As Boolean
    Dim cleanupErrorNumber As Long, cleanupErrorDescription As String
    Dim cleanupErrorSource As String
    If Not SheetExists(SH_INPUT) Then Exit Sub
    Set ws = GetSheet(SH_INPUT)
    On Error GoTo EH
    ws.Unprotect Password:=TOOL_PASSWORD
    ApplyRelationshipFieldState ws
    ProtectInputSheet True
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    Err.Clear
    If IsSetupRecoveryFatalError(errorNumber, errorSource) Then
        On Error Resume Next
        Call SetApplicationEnableEventsExact(False, eventStateDetail)
        Call SetApplicationEnableEventsExact(False, eventStateDetail)
        On Error GoTo 0
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    On Error Resume Next
    Err.Clear
    ProtectInputSheet
    cleanupErrorNumber = Err.Number
    cleanupErrorDescription = Err.Description
    cleanupErrorSource = Err.Source
    Err.Clear
    On Error GoTo 0
    If IsSetupRecoveryFatalError( _
           cleanupErrorNumber, cleanupErrorSource) Then
        On Error Resume Next
        Call SetApplicationEnableEventsExact(False, eventStateDetail)
        Call SetApplicationEnableEventsExact(False, eventStateDetail)
        On Error GoTo 0
        Err.Raise cleanupErrorNumber, cleanupErrorSource, _
                  cleanupErrorDescription
    End If
    If raiseOnError Then Err.Raise errorNumber, "ApplyRelationshipSettingToInput", errorDescription
End Sub

Private Sub ApplyRelationshipFieldState(ByVal ws As Worksheet)
    Dim valueRange As Range, labelRange As Range
    If ws Is Nothing Then Exit Sub
    Set valueRange = EffectiveRange(ws.Range(CELL_RELATIONSHIP))
    Set labelRange = ws.Range("H6")
    If UseRelationshipDisplay() Then
        UnlockRange valueRange
        valueRange.Interior.Color = RGB(248, 250, 252)
        valueRange.Font.Color = RGB(15, 23, 42)
        labelRange.Interior.Color = RGB(241, 245, 249)
        labelRange.Font.Color = RGB(71, 85, 105)
    Else
        '非表示設定でも値は消さない。再表示時に既存入力を復元できるよう保持する。
        valueRange.Locked = True
        valueRange.Interior.Color = RGB(241, 245, 249)
        valueRange.Font.Color = RGB(71, 85, 105)
        labelRange.Interior.Color = RGB(241, 245, 249)
        labelRange.Font.Color = RGB(71, 85, 105)
    End If
End Sub

Private Sub FormatRequiredLabel(ByVal target As Range)
    Dim labelText As String
    If target Is Nothing Then Exit Sub
    labelText = CellText(target.Value)
    If Right$(labelText, 1) <> "*" Then Exit Sub
    On Error Resume Next
    target.Characters(Start:=Len(labelText), Length:=1).Font.Color = RGB(185, 28, 28)
    On Error GoTo 0
End Sub


Public Sub GoInputSheet()
    '旧版ボタンとの互換用。画面上の導線はShowInputSheetへ統一する。
    ShowInputSheet
End Sub

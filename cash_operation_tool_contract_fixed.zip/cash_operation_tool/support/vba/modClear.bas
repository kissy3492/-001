﻿Attribute VB_Name = "modClear"
Option Explicit

Public Type InputProtectionSnapshot
    Captured As Boolean
    ProtectContents As Boolean
    ProtectDrawingObjects As Boolean
    ProtectScenarios As Boolean
    ProtectionMode As Boolean
    EnableSelection As Long
    EnableOutlining As Boolean
    EnableAutoFilter As Boolean
    EnablePivotTable As Boolean
    AllowFormattingCells As Boolean
    AllowFormattingColumns As Boolean
    AllowFormattingRows As Boolean
    AllowInsertingColumns As Boolean
    AllowInsertingRows As Boolean
    AllowInsertingHyperlinks As Boolean
    AllowDeletingColumns As Boolean
    AllowDeletingRows As Boolean
    AllowSorting As Boolean
    AllowFiltering As Boolean
    AllowUsingPivotTables As Boolean
End Type

Private Const INPUT_SNAPSHOT_CONSTANTS As Long = 1
Private Const INPUT_SNAPSHOT_FORMULAS As Long = 2
Private Const INPUT_SNAPSHOT_DETAILED As Long = 3

Public Function StrictLastTransactionInputRow(ByVal ws As Worksheet) As Long
    Dim foundCell As Range
    StrictLastTransactionInputRow = TX_FIRST_ROW - 1
    If ws Is Nothing Then _
        Err.Raise vbObjectError + 3259, "StrictLastTransactionInputRow", "入力シートがありません。"
    Set foundCell = ws.Range(ws.Cells(TX_FIRST_ROW, COL_TX_YEAR), _
                             ws.Cells(TX_LAST_ROW, COL_TX_BALANCE)).Find( _
                    What:="*", After:=ws.Cells(TX_FIRST_ROW, COL_TX_YEAR), _
                    LookIn:=xlFormulas, LookAt:=xlPart, SearchOrder:=xlByRows, _
                    SearchDirection:=xlPrevious, MatchCase:=False, MatchByte:=False, _
                    SearchFormat:=False)
    If Not foundCell Is Nothing Then StrictLastTransactionInputRow = foundCell.Row
End Function

Public Sub ClearTransactionInput()
    Dim ws As Worksheet
    Dim transactionRange As Range
    Dim transactionSnapshot As Variant
    Dim transactionMergeSignature As String
    Dim protectionSnapshot As InputProtectionSnapshot
    Dim errorNumber As Long, errorSource As String, errorDescription As String
    Dim stepErrorNumber As Long, stepErrorDescription As String
    Dim snapshotCaptured As Boolean, transactionSnapshotCaptured As Boolean
    Dim appStarted As Boolean
    Dim mutationStarted As Boolean, operationCommitted As Boolean
    Dim entryEventsCaptured As Boolean, entryEvents As Boolean
    Dim finalDateSafeStopped As Boolean
    Dim rollbackConfirmed As Boolean, recoveryConfirmed As Boolean
    Dim eventsReadyForFinalWrites As Boolean, safeToFinalizeLease As Boolean
    Dim recoveryErrorNumber As Long, recoveryErrorDescription As String
    Dim recoveryEnforcementFailed As Boolean
    Dim recoveryAttempted As Boolean
    Dim applicationStateConfirmed As Boolean
    Dim lastInputRow As Long
    Dim previousDateConfigSafe As String, currentDateConfigSafe As String
    Dim restoreDetail As String, eventStateDetail As String
    Dim postEnforceEventDetail As String, convergenceDetail As String
    Dim finalRecoveryEventDetail As String, appStateProblems As String
    If Not RequireToolReady() Then Exit Sub
    If Not RequireWritableWorkbook("取引入力のクリア") Then Exit Sub
    On Error GoTo EH
    If Not SheetExists(SH_INPUT) Then Exit Sub
    Set ws = GetSheet(SH_INPUT)
    If Not TryGetClearEnableEvents(entryEvents, eventStateDetail) Then _
        Err.Raise vbObjectError + 3261, "ClearTransactionInput", _
                  "Excelイベントの開始状態を取得できません: " & eventStateDetail
    entryEventsCaptured = True
    lastInputRow = StrictLastTransactionInputRow(ws)
    If lastInputRow < TX_FIRST_ROW Then
        If Not TryHoldClearEventsStopped(eventStateDetail) Then _
            Err.Raise vbObjectError + 3262, "ClearTransactionInput", _
                      "Excelイベント停止を確認できません: " & eventStateDetail
        SetInputStatus "消去する取引明細はありません。"
        If Not TryFinalizeClearApplicationLease( _
                   appStarted, entryEventsCaptured, entryEvents, _
                   "取引入力クリアの事前確認", restoreDetail, _
                   recoveryAttempted) Then _
            MsgBox "Excelイベント状態を開始時へ戻せませんでした。" & vbCrLf & _
                   restoreDetail, vbCritical, "Excelイベント復元エラー"
        Exit Sub
    End If
    If MsgBox(IIf(IsEditMode(), _
                  "訂正中の口座から、現在の取引明細をすべて消去します。" & vbCrLf & _
                  "口座情報と残高入力は残ります。消去しますか？", _
                  "現在の未登録取引明細をすべて消去します。" & vbCrLf & _
                  "口座情報と残高入力は残ります。消去しますか？"), _
              vbYesNo + vbExclamation + vbDefaultButton2, _
              "取引明細の消去確認") <> vbYes Then Exit Sub
    Set transactionRange = StrictEffectiveInputRange( _
                               ws.Range(ws.Cells(TX_FIRST_ROW, COL_TX_YEAR), _
                                        ws.Cells(lastInputRow, COL_TX_BALANCE)), _
                               "取引入力欄")
    AssertInputRangeWithinBoundary transactionRange, _
                                   ws.Range(ws.Cells(TX_FIRST_ROW, COL_TX_YEAR), _
                                            ws.Cells(TX_LAST_ROW, COL_TX_BALANCE)), _
                                   "取引入力欄"
    transactionSnapshot = CaptureInputFormulaSnapshot(transactionRange)
    transactionMergeSignature = InputRangeMergeSignature(transactionRange)
    transactionSnapshotCaptured = True
    If Not TryGetExactStateValue(STATE_INPUT_DATE_CONFIG_SAFE, previousDateConfigSafe) Then _
        previousDateConfigSafe = STATE_FALSE
    If previousDateConfigSafe <> STATE_TRUE And previousDateConfigSafe <> STATE_FALSE Then _
        previousDateConfigSafe = STATE_FALSE
    CaptureInputProtection ws, protectionSnapshot
    snapshotCaptured = True
    AppBegin "取引入力をクリアしています..."
    appStarted = True
    If Not TrySetClearEnableEventsExact(False, eventStateDetail) Then _
        Err.Raise vbObjectError + 3262, "ClearTransactionInput", _
                  "Excelイベント停止を確認できません: " & eventStateDetail
    mutationStarted = True
    ws.Unprotect Password:=TOOL_PASSWORD
    If transactionSnapshotCaptured Then
        ClearInputRangeStrict transactionRange, "取引入力欄"
        RestoreAllTransactionRowStyles ws, lastInputRow
    End If
    InvalidateDateComplementCache
    ProtectInputSheet True
    If Not TryHoldClearEventsStopped(eventStateDetail) Then _
        Err.Raise vbObjectError + 3270, "ClearTransactionInput", _
                  "完了記録前のExcelイベント停止を確認できません: " & eventStateDetail
    SetInputStatus "取引明細をクリアしました。"
    operationCommitted = True
    If Not TryFinalizeClearApplicationLease( _
               appStarted, entryEventsCaptured, entryEvents, _
               "取引入力クリアの最終処理", restoreDetail, _
               recoveryAttempted) Then
        MsgBox "取引明細はクリア済みですが、Excelの状態を開始時へ完全に戻せませんでした。" & _
               vbCrLf & restoreDetail & vbCrLf & _
               "現在のブックを上書きせず、Excelを再起動してください。", _
               vbCritical, "取引入力クリアの最終処理エラー"
    End If
    Exit Sub
EH:
    errorNumber = Err.Number
    errorSource = Err.Source
    errorDescription = Err.Description
    If IsClearRecoveryFatal(errorNumber, errorSource) Then
        Call TryHoldClearEventsStopped(convergenceDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    If Not entryEventsCaptured Then
        MsgBox "取引明細のクリアを開始できませんでした。" & vbCrLf & _
               "Excelイベントの開始状態を取得できないため、ブックへ診断情報を書き込んでいません。" & _
               vbCrLf & "Err " & errorNumber & ": " & errorDescription, _
               vbCritical, "Excelイベント状態不明"
        Exit Sub
    End If
    If Not TryHoldClearEventsStopped(eventStateDetail) Then
        AppendClearLeaseDetail restoreDetail, _
            "復元前のExcelイベント停止を確認できません: " & eventStateDetail
        If TryHoldClearEventsStopped(convergenceDetail) Then
            AppendClearLeaseDetail restoreDetail, _
                "安全状態を確認できないため開始時イベント値へ戻さず、" & _
                "Falseで停止しました。"
        Else
            AppendClearLeaseDetail restoreDetail, _
                "ExcelイベントのFalse収束にも失敗し、現在状態は不明です: " & _
                convergenceDetail
        End If
        MsgBox "取引明細のクリアに失敗しました。" & vbCrLf & _
               "Excelイベント停止を確認できる前には、復元や診断情報を書き込んでいません。" & _
               vbCrLf & "Err " & errorNumber & ": " & errorDescription & _
               vbCrLf & restoreDetail, vbCritical, "Excelイベント状態不明"
        Exit Sub
    End If
    If operationCommitted Then
        recoveryConfirmed = TryEnterClearRecoveryState( _
            "取引入力クリア完了後の最終処理失敗", restoreDetail, _
            recoveryEnforcementFailed, recoveryAttempted)
        If recoveryAttempted Then
            eventsReadyForFinalWrites = _
                TryHoldClearEventsStopped(convergenceDetail)
            Err.Raise vbObjectError + 5197, _
                "ClearRecoveryFatal/ClearTransactionInput", restoreDetail
        End If
        eventsReadyForFinalWrites = _
            TryHoldClearEventsStopped(eventStateDetail)
        If recoveryConfirmed And eventsReadyForFinalWrites Then
            On Error Resume Next
            Err.Clear
            AddCheck "エラー", "取引入力クリアの最終処理", _
                     "Err " & CStr(errorNumber) & ": " & _
                     errorDescription & restoreDetail
            SetInputStatus "取引明細はクリア済みですが、最終処理を完了できませんでした。現在のブックを上書きしないでください。", True
            Err.Clear
            On Error GoTo 0
            eventsReadyForFinalWrites = _
                TryHoldClearEventsStopped(eventStateDetail)
        Else
            AppendClearLeaseDetail restoreDetail, _
                "今回のRecovery二重状態または診断書込み前の" & _
                "Excelイベント停止を確認できないため、" & _
                "チェックと状態表示を行いませんでした: " & eventStateDetail
        End If
        safeToFinalizeLease = _
            recoveryConfirmed And eventsReadyForFinalWrites
        If safeToFinalizeLease Then
            Call TryFinalizeClearApplicationLease( _
                appStarted, entryEventsCaptured, entryEvents, _
                "取引入力クリアの異常終了", restoreDetail, _
                recoveryAttempted)
        ElseIf TryHoldClearEventsStopped(convergenceDetail) Then
            AppendClearLeaseDetail restoreDetail, _
                "確定済み変更のRecoveryを厳密確認できないため、" & _
                "開始時イベント値へ戻さずFalseで停止しました。"
        Else
            AppendClearLeaseDetail restoreDetail, _
                "確定済み変更のRecoveryを厳密確認できず、" & _
                "ExcelイベントのFalse収束にも失敗しました: " & _
                convergenceDetail
        End If
        MsgBox "取引明細はクリア済みですが、最終処理に失敗しました。" & vbCrLf & _
               "Err " & errorNumber & ": " & errorDescription & vbCrLf & restoreDetail, _
               vbCritical, "取引入力クリアの最終処理エラー"
        Exit Sub
    End If
    On Error Resume Next
    Err.Clear
    SetStateValue STATE_INPUT_DATE_CONFIG_SAFE, STATE_FALSE
    If Err.Number <> 0 Then
        stepErrorNumber = Err.Number
        stepErrorDescription = Err.Description
        Err.Clear
        AppendInputRestoreError restoreDetail, "日付安全状態の停止", _
                                stepErrorNumber, stepErrorDescription
    End If
    If snapshotCaptured And Not ws Is Nothing Then
        If mutationStarted Then
            Err.Clear
            ws.Unprotect Password:=TOOL_PASSWORD
            If Err.Number <> 0 Then
                stepErrorNumber = Err.Number
                stepErrorDescription = Err.Description
                Err.Clear
                AppendInputRestoreError restoreDetail, "入力シート保護解除", _
                                        stepErrorNumber, stepErrorDescription
            End If
            If transactionSnapshotCaptured Then
                Err.Clear
                RestoreInputFormulaSnapshot transactionRange, transactionSnapshot, _
                                            transactionMergeSignature, "取引入力欄"
                If Err.Number <> 0 Then
                    stepErrorNumber = Err.Number
                    stepErrorDescription = Err.Description
                    Err.Clear
                    AppendInputRestoreError restoreDetail, "取引入力欄の復元", _
                                            stepErrorNumber, stepErrorDescription
                End If
                Err.Clear
                RestoreAllTransactionRowStyles ws, lastInputRow
                If Err.Number <> 0 Then
                    stepErrorNumber = Err.Number
                    stepErrorDescription = Err.Description
                    Err.Clear
                    AppendInputRestoreError restoreDetail, "取引行書式の復元", _
                                            stepErrorNumber, stepErrorDescription
                End If
            End If
            Err.Clear
            InvalidateDateComplementCache
            If Err.Number <> 0 Then
                stepErrorNumber = Err.Number
                stepErrorDescription = Err.Description
                Err.Clear
                AppendInputRestoreError restoreDetail, "日付補完キャッシュの破棄", _
                                        stepErrorNumber, stepErrorDescription
            End If
            Err.Clear
            RestoreInputProtection ws, protectionSnapshot
            If Err.Number <> 0 Then
                stepErrorNumber = Err.Number
                stepErrorDescription = Err.Description
                Err.Clear
                AppendInputRestoreError restoreDetail, "入力シート保護の復元", _
                                        stepErrorNumber, stepErrorDescription
            End If
        End If
        If transactionSnapshotCaptured Then
            Err.Clear
            AssertInputFormulaSnapshot transactionRange, transactionSnapshot, _
                                       transactionMergeSignature, "取引入力欄"
            If Err.Number <> 0 Then
                stepErrorNumber = Err.Number
                stepErrorDescription = Err.Description
                Err.Clear
                AppendInputRestoreError restoreDetail, "取引入力欄の照合", _
                                        stepErrorNumber, stepErrorDescription
            End If
        End If
        Err.Clear
        AssertInputProtection ws, protectionSnapshot
        If Err.Number <> 0 Then
            stepErrorNumber = Err.Number
            stepErrorDescription = Err.Description
            Err.Clear
            AppendInputRestoreError restoreDetail, "入力シート保護の照合", _
                                    stepErrorNumber, stepErrorDescription
        End If
        Err.Clear
        If Not TryGetExactStateValue(STATE_INPUT_DATE_CONFIG_SAFE, currentDateConfigSafe) Then _
            Err.Raise vbObjectError + 3239, "ClearTransactionInput", "停止した日付安全状態を読み返せません。"
        If Err.Number = 0 Then
            If currentDateConfigSafe <> STATE_FALSE Then _
                Err.Raise vbObjectError + 3240, "ClearTransactionInput", "復元確認前の日付安全状態が停止になっていません。"
        End If
        If Err.Number <> 0 Then
            stepErrorNumber = Err.Number
            stepErrorDescription = Err.Description
            Err.Clear
            AppendInputRestoreError restoreDetail, "日付安全状態の停止確認", _
                                    stepErrorNumber, stepErrorDescription
        End If
    Else
        AppendInputRestoreError restoreDetail, "クリア前取引の復元", _
                                vbObjectError + 3241, "完全な退避値を取得できていません。"
    End If
    If Len(restoreDetail) = 0 Then
        Err.Clear
        SetStateValue STATE_INPUT_DATE_CONFIG_SAFE, previousDateConfigSafe
        If Err.Number = 0 Then
            If Not TryGetExactStateValue(STATE_INPUT_DATE_CONFIG_SAFE, currentDateConfigSafe) Then _
                Err.Raise vbObjectError + 3242, "ClearTransactionInput", "日付安全状態を読み返せません。"
        End If
        If Err.Number = 0 Then
            If currentDateConfigSafe <> previousDateConfigSafe Then _
                Err.Raise vbObjectError + 3243, "ClearTransactionInput", "日付安全状態の復元値が一致しません。"
        End If
        If Err.Number <> 0 Then
            stepErrorNumber = Err.Number
            stepErrorDescription = Err.Description
            Err.Clear
            AppendInputRestoreError restoreDetail, "日付安全状態の最終復元", _
                                    stepErrorNumber, stepErrorDescription
        End If
    End If
    rollbackConfirmed = (Len(restoreDetail) = 0)
    If Len(restoreDetail) > 0 Then
        Err.Clear
        SetStateValue STATE_INPUT_DATE_CONFIG_SAFE, STATE_FALSE
        If Err.Number = 0 Then
            If Not TryGetExactStateValue(STATE_INPUT_DATE_CONFIG_SAFE, currentDateConfigSafe) Then _
                Err.Raise vbObjectError + 3244, "ClearTransactionInput", "日付安全状態の停止結果を読み返せません。"
        End If
        If Err.Number = 0 Then
            If currentDateConfigSafe <> STATE_FALSE Then _
                Err.Raise vbObjectError + 3245, "ClearTransactionInput", "日付安全状態を停止できていません。"
        End If
        If Err.Number = 0 Then finalDateSafeStopped = True
        If Err.Number <> 0 Then
            stepErrorNumber = Err.Number
            stepErrorDescription = Err.Description
            Err.Clear
            AppendInputRestoreError restoreDetail, "日付安全状態の最終停止", _
                                    stepErrorNumber, stepErrorDescription
        End If
        If Not finalDateSafeStopped Then
            '日付安全フラグ自体をfail-closedにできない場合は、案件全体を要復旧へ倒す。
            Err.Clear
            recoveryAttempted = True
            EnforceRollbackRecoveryState restoreDetail
            recoveryErrorNumber = Err.Number
            recoveryErrorDescription = Err.Description
            Err.Clear
            eventsReadyForFinalWrites = _
                TryHoldClearEventsStopped(postEnforceEventDetail)
            If recoveryErrorNumber <> 0 Then
                recoveryEnforcementFailed = True
                AppendClearLeaseDetail restoreDetail, _
                    "要復旧状態の強制設定エラー: Err " & _
                    CStr(recoveryErrorNumber) & " " & _
                    recoveryErrorDescription
                On Error GoTo 0
                Err.Raise vbObjectError + 5197, _
                    "ClearRecoveryFatal/ClearTransactionInput", restoreDetail
            ElseIf eventsReadyForFinalWrites Then
                recoveryConfirmed = _
                    ClearRecoveryStateIsConfirmedExact(restoreDetail)
                If recoveryConfirmed Then
                    applicationStateConfirmed = _
                        AppStateIsRestored(appStateProblems)
                    If Not applicationStateConfirmed Then _
                        AppendClearLeaseDetail restoreDetail, _
                            "Recovery確認後のApplication状態を安全に" & _
                            "確認できません: " & appStateProblems
                End If
                If applicationStateConfirmed Then _
                    eventsReadyForFinalWrites = _
                        TryHoldClearEventsStopped( _
                            finalRecoveryEventDetail)
            Else
                AppendClearLeaseDetail restoreDetail, _
                    "Recovery処理後にExcelイベント停止を確認できないため、" & _
                    "復旧状態を読み取りませんでした。現在状態は不明です: " & _
                    postEnforceEventDetail
            End If
            eventsReadyForFinalWrites = _
                TryHoldClearEventsStopped(convergenceDetail)
            On Error GoTo 0
            Err.Raise vbObjectError + 5197, _
                "ClearRecoveryFatal/ClearTransactionInput", restoreDetail
        End If
        If Not recoveryConfirmed And Not recoveryAttempted Then
            eventsReadyForFinalWrites = _
                TryHoldClearEventsStopped(eventStateDetail)
            If eventsReadyForFinalWrites Then
                recoveryConfirmed = TryEnterClearRecoveryState( _
                    "取引入力クリアの復元不一致", restoreDetail, _
                    recoveryEnforcementFailed, recoveryAttempted)
            End If
            If recoveryAttempted Then
                On Error GoTo 0
                eventsReadyForFinalWrites = _
                    TryHoldClearEventsStopped(convergenceDetail)
                Err.Raise vbObjectError + 5197, _
                    "ClearRecoveryFatal/ClearTransactionInput", restoreDetail
            End If
        End If
    End If
    '診断と利用者向け状態も、EnableEvents=Falseの読戻しが取れている間に完了する。
    eventsReadyForFinalWrites = _
        TryHoldClearEventsStopped(eventStateDetail)
    If eventsReadyForFinalWrites And _
       (rollbackConfirmed Or recoveryConfirmed) Then
        Err.Clear
        If Len(restoreDetail) > 0 Then _
            AddCheck "エラー", "取引入力クリアの復元", restoreDetail
        If rollbackConfirmed Then
            SetInputStatus "取引明細をクリアできませんでした。クリア前の入力を復元しました。", True
        ElseIf recoveryConfirmed Then
            SetInputStatus "取引明細の復元を確認できないため、案件を要復旧として停止しました。C_チェックを確認し、現在のブックを上書きしないでください。", True
        ElseIf finalDateSafeStopped Then
            SetInputStatus "取引明細の復元を確認できません。日付安全状態を停止しましたが、案件のRecovery状態は確認できません。現在のブックを上書きしないでください。", True
        Else
            SetInputStatus "取引明細の復元と安全停止を確認できないため通常操作へ戻せません。現在のブックを上書きしないでください。", True
        End If
        Err.Clear
        eventsReadyForFinalWrites = _
            TryHoldClearEventsStopped(eventStateDetail)
    Else
        AppendClearLeaseDetail restoreDetail, _
            "診断書込みの安全条件を確認できないため、" & _
            "チェックと状態表示を行いませんでした: " & eventStateDetail
    End If
    On Error GoTo 0
    safeToFinalizeLease = eventsReadyForFinalWrites And _
                          (rollbackConfirmed Or recoveryConfirmed)
    If safeToFinalizeLease Then
        'Application leaseを戻した後、開始時EnableEventsを独立に読戻して最終確定する。
        Call TryFinalizeClearApplicationLease( _
            appStarted, entryEventsCaptured, entryEvents, _
            "取引入力クリアの異常終了", restoreDetail, _
            recoveryAttempted)
    ElseIf TryHoldClearEventsStopped(convergenceDetail) Then
        AppendClearLeaseDetail restoreDetail, _
            "入力復元またはRecoveryを厳密確認できないため、" & _
            "開始時イベント値へ戻さずFalseで停止しました。"
    Else
        AppendClearLeaseDetail restoreDetail, _
            "安全状態を厳密確認できず、ExcelイベントのFalse収束にも" & _
            "失敗しました: " & convergenceDetail
    End If
    MsgBox "取引明細のクリアに失敗しました。" & vbCrLf & _
           "Err " & errorNumber & ": " & errorDescription & _
           IIf(Len(restoreDetail) > 0, vbCrLf & "クリア前取引の復元確認:" & restoreDetail, ""), vbExclamation
End Sub

Public Sub ClearCurrentAccountInput()
    Dim errorNumber As Long, errorSource As String, errorDescription As String
    Dim entryEvents As Boolean, entryEventsCaptured As Boolean
    Dim appStarted As Boolean
    Dim recoveryAttempted As Boolean
    Dim eventStateDetail As String, cleanupDetail As String
    Dim convergenceDetail As String
    If Not RequireToolReady() Then Exit Sub
    If Not RequireWritableWorkbook("入力内容の消去") Then Exit Sub
    If IsEditMode() Then
        '入力欄を全て空欄にした後でも、訂正状態そのものを黙って破棄しない。
        If MsgBox("訂正中の入力内容を破棄し、訂正モードを終了しますか？", _
                  vbYesNo + vbExclamation + vbDefaultButton2, "訂正内容の破棄確認") <> vbYes Then Exit Sub
    ElseIf CurrentAccountInputHasData() Then
        If MsgBox("現在の未登録入力をすべて消去しますか？", _
                  vbYesNo + vbExclamation + vbDefaultButton2, "入力内容の消去確認") <> vbYes Then Exit Sub
    End If
    On Error GoTo EH
    If Not TryGetClearEnableEvents(entryEvents, eventStateDetail) Then _
        Err.Raise vbObjectError + 3263, "ClearCurrentAccountInput", _
                  "Excelイベントの開始状態を取得できません: " & eventStateDetail
    entryEventsCaptured = True
    AppBegin "入力内容を消去しています..."
    appStarted = True
    If Not TrySetClearEnableEventsExact(False, eventStateDetail) Then _
        Err.Raise vbObjectError + 3264, "ClearCurrentAccountInput", _
                  "Excelイベント停止を確認できません: " & eventStateDetail
    ClearInputCore KEEP_NONE, True, True, True
    If Not TryHoldClearEventsStopped(eventStateDetail) Then _
        Err.Raise vbObjectError + 3272, "ClearCurrentAccountInput", _
                  "入力位置の更新前にExcelイベント停止を確認できません: " & eventStateDetail
    If SheetExists(SH_INPUT) Then SafeSelectCell GetSheet(SH_INPUT), CELL_BANK
    If Not TryFinalizeClearApplicationLease( _
               appStarted, entryEventsCaptured, entryEvents, _
               "入力内容消去の最終処理", cleanupDetail, _
               recoveryAttempted) Then _
        MsgBox "入力内容は消去済みですが、Excelの状態を開始時へ完全に戻せませんでした。" & _
               vbCrLf & cleanupDetail & vbCrLf & _
               "現在のブックを上書きせず、Excelを再起動してください。", _
               vbCritical, "入力内容消去の最終処理エラー"
    Exit Sub
EH:
    errorNumber = Err.Number
    errorSource = Err.Source
    errorDescription = Err.Description
    If IsClearRecoveryFatal(errorNumber, errorSource) Then
        Call TryHoldClearEventsStopped(convergenceDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    If entryEventsCaptured Then
        If TryHoldClearEventsStopped(eventStateDetail) Then
            'ClearInputCoreが退避時の保護状態まで復元・照合するため、標準保護へ上書きしない。
            On Error Resume Next
            SetInputStatus "入力内容を消去できませんでした。C_チェックを確認してください。", True
            AddCheck "エラー", "入力クリア", _
                     "Err " & CStr(errorNumber) & ": " & errorDescription
            Err.Clear
            On Error GoTo 0
        Else
            AppendClearLeaseDetail cleanupDetail, _
                "診断書込み前のExcelイベント停止を確認できません: " & eventStateDetail
        End If
    Else
        AppendClearLeaseDetail cleanupDetail, _
            "開始時のExcelイベント状態を取得できないため、診断情報を書き込んでいません。"
    End If
    If entryEventsCaptured Then _
        Call TryFinalizeClearApplicationLease( _
            appStarted, entryEventsCaptured, entryEvents, "入力内容消去の異常終了", _
            cleanupDetail, recoveryAttempted)
    MsgBox "入力内容の消去中にエラーが発生しました。" & vbCrLf & _
           "Err " & errorNumber & ": " & errorDescription & _
           IIf(Len(cleanupDetail) > 0, vbCrLf & cleanupDetail, vbNullString), vbExclamation
End Sub

Public Function CurrentAccountInputHasData() As Boolean
    Dim ws As Worksheet
    Dim accountFields As Variant, fieldAddress As Variant
    Dim inputCell As Range
    On Error GoTo AssumeData
    If Not SheetExists(SH_INPUT) Then Exit Function
    Set ws = GetSheet(SH_INPUT)
    accountFields = Array(CELL_BANK, CELL_BRANCH, CELL_PERSON, CELL_RELATIONSHIP, _
                          CELL_ACCOUNT_TYPE, CELL_ACCOUNT_NO, CELL_OPEN_DATE, CELL_CLOSE_DATE)
    For Each fieldAddress In accountFields
        Set inputCell = ws.Range(CStr(fieldAddress))
        '表示が空でも、数式またはExcelエラーが残れば未登録入力として止める。
        If inputCell.HasFormula Or IsError(inputCell.Value) Or HasText(inputCell.Value) Then
            CurrentAccountInputHasData = True
            Exit Function
        End If
    Next fieldAddress
    If Application.WorksheetFunction.CountA(ws.Range(ws.Cells(BAL_VALUE_ROW, BAL_FIRST_COL), ws.Cells(BAL_VALUE_ROW, BAL_MAX_COL))) > 0 Then
        CurrentAccountInputHasData = True
        Exit Function
    End If
    CurrentAccountInputHasData = (Application.WorksheetFunction.CountA( _
        ws.Range(ws.Cells(TX_FIRST_ROW, COL_TX_YEAR), ws.Cells(TX_LAST_ROW, COL_TX_BALANCE))) > 0)
    Exit Function
AssumeData:
    CurrentAccountInputHasData = True
End Function

Public Function RequireNoPendingAccountInput(ByVal actionName As String) As Boolean
    '帳票は登録済み内部データだけから作る。未登録入力を黙って除外しない。
    '訂正IDが残る限り、入力欄が空に見えても保存済みデータの古い複製を保持している
    '可能性があるため、ほかのデータ更新処理へ進ませない。
    If IsEditMode() Then
        MsgBox "訂正中の内容はまだ内部データへ反映されていません。" & vbCrLf & _
               "先に［訂正内容を更新］を完了してから" & actionName & "を実行してください。", _
               vbExclamation, "未保存の訂正があります"
        ShowInputSheet
        Exit Function
    End If
    If Not CurrentAccountInputHasData() Then
        RequireNoPendingAccountInput = True
        Exit Function
    End If
    MsgBox "入力シートに未登録の内容が残っています。" & vbCrLf & _
           actionName & "から黙って除外しないため、処理を中止しました。" & vbCrLf & _
           "先に口座を登録するか、不要な入力を消去してください。", _
           vbExclamation, "未登録入力があります"
    ShowInputSheet
End Function

Public Sub ClearAllInputFields()
    ClearCurrentAccountInput
End Sub

Public Sub ClearInputKeepPerson()
    RunClearInputSafely KEEP_PERSON_ONLY
End Sub

Public Sub ClearInputKeepBankBranch()
    RunClearInputSafely KEEP_BANK_BRANCH
End Sub

Public Sub ClearInputKeepBankBranchPersonType()
    RunClearInputSafely KEEP_BANK_BRANCH_PERSON_TYPE
End Sub

Private Sub RunClearInputSafely(ByVal keepPolicy As String)
    Dim errorNumber As Long, errorSource As String, errorDescription As String
    Dim entryEvents As Boolean, entryEventsCaptured As Boolean
    Dim appStarted As Boolean
    Dim recoveryAttempted As Boolean
    Dim eventStateDetail As String, cleanupDetail As String
    Dim convergenceDetail As String
    If Not RequireToolReady() Then Exit Sub
    If Not RequireWritableWorkbook("入力欄の整理") Then Exit Sub
    On Error GoTo EH
    If Not TryGetClearEnableEvents(entryEvents, eventStateDetail) Then _
        Err.Raise vbObjectError + 3265, "RunClearInputSafely", _
                  "Excelイベントの開始状態を取得できません: " & eventStateDetail
    entryEventsCaptured = True
    AppBegin "入力欄を整理しています..."
    appStarted = True
    If Not TrySetClearEnableEventsExact(False, eventStateDetail) Then _
        Err.Raise vbObjectError + 3266, "RunClearInputSafely", _
                  "Excelイベント停止を確認できません: " & eventStateDetail
    ClearInputCore keepPolicy, True, True, True
    If Not TryHoldClearEventsStopped(eventStateDetail) Then _
        Err.Raise vbObjectError + 3273, "RunClearInputSafely", _
                  "入力欄整理後のExcelイベント停止を確認できません: " & eventStateDetail
    If Not TryFinalizeClearApplicationLease( _
               appStarted, entryEventsCaptured, entryEvents, _
               "入力欄整理の最終処理", cleanupDetail, _
               recoveryAttempted) Then _
        MsgBox "入力欄は整理済みですが、Excelの状態を開始時へ完全に戻せませんでした。" & _
               vbCrLf & cleanupDetail & vbCrLf & _
               "現在のブックを上書きせず、Excelを再起動してください。", _
               vbCritical, "入力欄整理の最終処理エラー"
    Exit Sub
EH:
    errorNumber = Err.Number
    errorSource = Err.Source
    errorDescription = Err.Description
    If IsClearRecoveryFatal(errorNumber, errorSource) Then
        Call TryHoldClearEventsStopped(convergenceDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    If entryEventsCaptured Then
        If TryHoldClearEventsStopped(eventStateDetail) Then
            'ClearInputCoreが退避時の保護状態まで復元・照合するため、標準保護へ上書きしない。
            On Error Resume Next
            SetInputStatus "入力欄の整理に失敗しました。", True
            AddCheck "エラー", "入力欄整理", _
                     "Err " & CStr(errorNumber) & ": " & errorDescription
            Err.Clear
            On Error GoTo 0
        Else
            AppendClearLeaseDetail cleanupDetail, _
                "診断書込み前のExcelイベント停止を確認できません: " & eventStateDetail
        End If
    Else
        AppendClearLeaseDetail cleanupDetail, _
            "開始時のExcelイベント状態を取得できないため、診断情報を書き込んでいません。"
    End If
    If entryEventsCaptured Then _
        Call TryFinalizeClearApplicationLease( _
            appStarted, entryEventsCaptured, entryEvents, "入力欄整理の異常終了", _
            cleanupDetail, recoveryAttempted)
    MsgBox "入力欄の整理中にエラーが発生しました。" & vbCrLf & _
           "Err " & errorNumber & ": " & errorDescription & _
           IIf(Len(cleanupDetail) > 0, vbCrLf & cleanupDetail, vbNullString), vbExclamation
End Sub

Public Sub ClearInputKeepBankAndPerson()
    '旧版ボタンとの互換用。口座番号は必ず消す。
    ClearInputKeepBankBranchPersonType
End Sub

Public Sub ClearInputForRecordLoad()
    '訂正対象の読込専用。既存の訂正IDを途中で消さない。
    ClearInputCore KEEP_NONE, True, True, False
End Sub

Public Sub IncrementAccountBranchNo()
    Dim ws As Worksheet
    Dim s As String
    If Not SheetExists(SH_INPUT) Then Exit Sub
    Set ws = GetSheet(SH_INPUT)
    s = CellText(ws.Range(CELL_ACCOUNT_NO).Value)
    If Len(s) = 0 Then
        SafeSelectCell ws, CELL_ACCOUNT_NO
        SetInputStatus "口座番号を入力してから枝番を進めてください。", True
        Exit Sub
    End If
    SetNextBranchAccountNumber NextBranchAccountNo(s)
End Sub

Public Sub SetNextBranchAccountNumber(ByVal nextAccNo As String, _
                                      Optional ByVal raiseOnError As Boolean = False)
    Dim ws As Worksheet, accountRange As Range
    Dim previousValueSnapshot As Variant, previousMergeSignature As String
    Dim protectionSnapshot As InputProtectionSnapshot
    Dim snapshotCaptured As Boolean, restoreFailed As Boolean
    Dim errorNumber As Long, errorSource As String
    Dim errorDescription As String, restoreDetail As String
    Dim entryEvents As Boolean, entryEventsCaptured As Boolean
    Dim eventStateDetail As String, leaseDetail As String
    Dim operationCommitted As Boolean, appStarted As Boolean
    Dim leaseRestored As Boolean, rollbackConfirmed As Boolean
    Dim recoveryConfirmed As Boolean, eventsReadyForFinalWrites As Boolean
    Dim safeToFinalizeLease As Boolean
    Dim recoveryErrorNumber As Long, recoveryErrorDescription As String
    Dim recoveryEnforcementFailed As Boolean
    Dim recoveryAttempted As Boolean
    Dim applicationStateConfirmed As Boolean
    Dim postEnforceEventDetail As String, convergenceDetail As String
    Dim finalRecoveryEventDetail As String, appStateProblems As String
    If Len(CellText(nextAccNo)) = 0 Then
        If raiseOnError Then _
            Err.Raise vbObjectError + 3201, "SetNextBranchAccountNumber", "次の口座番号が空です。"
        Exit Sub
    End If
    If Not SheetExists(SH_INPUT) Then
        If raiseOnError Then _
            Err.Raise vbObjectError + 3202, "SetNextBranchAccountNumber", "入力シートがありません。"
        Exit Sub
    End If
    If Not RequireWritableWorkbook("口座枝番の設定") Then
        If raiseOnError Then _
            Err.Raise vbObjectError + 3203, "SetNextBranchAccountNumber", "ブックが書き込み可能ではありません。"
        Exit Sub
    End If
    Set ws = GetSheet(SH_INPUT)
    Set accountRange = EffectiveRange(ws.Range(CELL_ACCOUNT_NO))
    '枝番の書込み後に再保護・選択が失敗しても、口座番号だけが先に進んだ
    '中途半端な入力を残さない。値・数式・型・結合・保護を一体で退避する。
    On Error GoTo EH
    If Not TryGetClearEnableEvents(entryEvents, eventStateDetail) Then _
        Err.Raise vbObjectError + 3274, "SetNextBranchAccountNumber", _
                  "Excelイベントの開始状態を取得できません: " & eventStateDetail
    entryEventsCaptured = True
    If Not TrySetClearEnableEventsExact(False, eventStateDetail) Then _
        Err.Raise vbObjectError + 3275, "SetNextBranchAccountNumber", _
                  "Excelイベント停止を確認できません: " & eventStateDetail
    CaptureInputProtection ws, protectionSnapshot
    previousMergeSignature = InputRangeMergeSignature(accountRange)
    previousValueSnapshot = CaptureInputFormulaSnapshot(accountRange)
    snapshotCaptured = True
    ws.Unprotect Password:=TOOL_PASSWORD
    accountRange.Cells(1, 1).Value = nextAccNo
    ProtectInputSheet True
    SafeSelectCell ws, CELL_ACCOUNT_NO
    If StrComp(CellText(accountRange.Cells(1, 1).Value2), CellText(nextAccNo), _
               vbBinaryCompare) <> 0 Then _
        Err.Raise vbObjectError + 3204, "SetNextBranchAccountNumber", _
                  "設定した口座枝番を読み返せません。"
    operationCommitted = True
    If Not TryFinalizeClearApplicationLease( _
               appStarted, entryEventsCaptured, entryEvents, _
               "次枝番設定の最終処理", leaseDetail, _
               recoveryAttempted) Then _
        Err.Raise vbObjectError + 3276, "SetNextBranchAccountNumber", _
                  "次枝番は設定済みですが、Excelイベント状態の最終復元に失敗しました。" & _
                  leaseDetail
    Exit Sub
EH:
    errorNumber = Err.Number
    errorSource = Err.Source
    errorDescription = Err.Description
    If IsClearRecoveryFatal(errorNumber, errorSource) Then
        Call TryHoldClearEventsStopped(convergenceDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    If Not entryEventsCaptured Then
        If raiseOnError Then _
            Err.Raise errorNumber, "SetNextBranchAccountNumber", errorDescription
        MsgBox "次枝番を設定できませんでした。" & vbCrLf & _
               "Excelイベントの開始状態を取得できないため、ブックへ復元・診断情報を書き込んでいません。" & _
               vbCrLf & "Err " & CStr(errorNumber) & ": " & errorDescription, _
               vbCritical, "Excelイベント状態不明"
        Exit Sub
    End If
    If Not TryHoldClearEventsStopped(eventStateDetail) Then
        AppendClearLeaseDetail restoreDetail, _
            "復元前のExcelイベント停止を確認できません: " & eventStateDetail
        If TryHoldClearEventsStopped(convergenceDetail) Then
            AppendClearLeaseDetail leaseDetail, _
                "安全状態を確認できないため開始時イベント値へ戻さず、" & _
                "Falseで停止しました。"
        Else
            AppendClearLeaseDetail leaseDetail, _
                "ExcelイベントのFalse収束にも失敗し、現在状態は不明です: " & _
                convergenceDetail
        End If
        If raiseOnError Then _
            Err.Raise errorNumber, "SetNextBranchAccountNumber", _
                      errorDescription & restoreDetail & leaseDetail
        MsgBox "次枝番を設定できませんでした。" & vbCrLf & _
               "Excelイベント停止を確認できる前には、ブックへ復元・診断情報を書き込んでいません。" & _
               vbCrLf & "Err " & CStr(errorNumber) & ": " & errorDescription & _
               restoreDetail & leaseDetail, vbCritical, "Excelイベント状態不明"
        Exit Sub
    End If
    If operationCommitted Then
        recoveryConfirmed = TryEnterClearRecoveryState( _
            "次枝番設定完了後のExcelイベント復元失敗", restoreDetail, _
            recoveryEnforcementFailed, recoveryAttempted)
        If recoveryAttempted Then
            eventsReadyForFinalWrites = _
                TryHoldClearEventsStopped(convergenceDetail)
            Err.Raise vbObjectError + 5197, _
                "ClearRecoveryFatal/SetNextBranchAccountNumber", restoreDetail
        End If
        eventsReadyForFinalWrites = _
            TryHoldClearEventsStopped(eventStateDetail)
        If recoveryConfirmed And eventsReadyForFinalWrites Then
            On Error Resume Next
            Err.Clear
            AddCheck "エラー", "次枝番設定の最終処理", _
                     "次枝番は設定済みですが、Excelイベント状態を開始値へ戻せません。" & _
                     restoreDetail
            SetInputStatus "次枝番は設定済みですが、Excelイベント状態の最終復元に失敗しました。現在のブックを上書きしないでください。", True
            Err.Clear
            On Error GoTo 0
            eventsReadyForFinalWrites = _
                TryHoldClearEventsStopped(eventStateDetail)
        Else
            AppendClearLeaseDetail restoreDetail, _
                "今回のRecovery二重状態または診断書込み前の" & _
                "Excelイベント停止を確認できないため、" & _
                "チェックと状態表示を行いませんでした: " & eventStateDetail
        End If
        safeToFinalizeLease = _
            recoveryConfirmed And eventsReadyForFinalWrites
        If safeToFinalizeLease Then
            Call TryFinalizeClearApplicationLease( _
                appStarted, entryEventsCaptured, entryEvents, _
                "次枝番設定の異常終了", leaseDetail, recoveryAttempted)
        ElseIf TryHoldClearEventsStopped(convergenceDetail) Then
            AppendClearLeaseDetail leaseDetail, _
                "確定済み変更のRecoveryを厳密確認できないため、" & _
                "開始時イベント値へ戻さずFalseで停止しました。"
        Else
            AppendClearLeaseDetail leaseDetail, _
                "確定済み変更のRecoveryを厳密確認できず、" & _
                "ExcelイベントのFalse収束にも失敗しました: " & _
                convergenceDetail
        End If
        If raiseOnError Then _
            Err.Raise errorNumber, "SetNextBranchAccountNumber", _
                      errorDescription & restoreDetail & leaseDetail
        MsgBox "次枝番は設定済みですが、最終処理に失敗しました。" & vbCrLf & _
               "Err " & CStr(errorNumber) & ": " & errorDescription & _
               restoreDetail & leaseDetail, vbCritical, "次枝番設定の最終処理エラー"
        Exit Sub
    End If
    On Error Resume Next
    Err.Clear
    If snapshotCaptured Then
        ws.Unprotect Password:=TOOL_PASSWORD
        RestoreInputFormulaSnapshot accountRange, previousValueSnapshot, _
                                    previousMergeSignature, "口座番号"
        RestoreInputProtection ws, protectionSnapshot
        AssertInputFormulaSnapshot accountRange, previousValueSnapshot, _
                                   previousMergeSignature, "口座番号"
        AssertInputProtection ws, protectionSnapshot
        If Err.Number <> 0 Then
            restoreFailed = True
            restoreDetail = " / 元の口座番号または保護を復元できません: Err " & _
                            CStr(Err.Number) & " " & Err.Description
            Err.Clear
        End If
    Else
        '退避完了前はまだ保護解除も値書込みも始めていない。
        '元の保護条件を取得できていない状態で標準保護へ上書きしない。
        Err.Clear
    End If
    rollbackConfirmed = Not restoreFailed
    If restoreFailed Then
        '枝番は登録後の次入力へ渡す値であり、復元不能のまま通常入力を続けると
        '誤った口座番号の再登録や、保護が外れた入力画面での編集を許してしまう。
        '日付安全フラグだけでは口座番号・保護を止められないため、独立ラッチを含む
        '共通の要復旧経路へ必ず収束させる。
        Err.Clear
        recoveryAttempted = True
        EnforceRollbackRecoveryState restoreDetail
        recoveryErrorNumber = Err.Number
        recoveryErrorDescription = Err.Description
        Err.Clear
        eventsReadyForFinalWrites = _
            TryHoldClearEventsStopped(postEnforceEventDetail)
        If recoveryErrorNumber <> 0 Then
            recoveryEnforcementFailed = True
            AppendClearLeaseDetail restoreDetail, _
                "要復旧状態の強制設定エラー: Err " & _
                CStr(recoveryErrorNumber) & " " & recoveryErrorDescription
            On Error GoTo 0
            Err.Raise vbObjectError + 5197, _
                "ClearRecoveryFatal/SetNextBranchAccountNumber", restoreDetail
        ElseIf eventsReadyForFinalWrites Then
            recoveryConfirmed = _
                ClearRecoveryStateIsConfirmedExact(restoreDetail)
            If recoveryConfirmed Then
                applicationStateConfirmed = _
                    AppStateIsRestored(appStateProblems)
                If Not applicationStateConfirmed Then _
                    AppendClearLeaseDetail restoreDetail, _
                        "Recovery確認後のApplication状態を安全に" & _
                        "確認できません: " & appStateProblems
            End If
            If applicationStateConfirmed Then _
                eventsReadyForFinalWrites = _
                    TryHoldClearEventsStopped(finalRecoveryEventDetail)
        Else
            AppendClearLeaseDetail restoreDetail, _
                "Recovery処理後にExcelイベント停止を確認できないため、" & _
                "復旧状態を読み取りませんでした。現在状態は不明です: " & _
                postEnforceEventDetail
        End If
        eventsReadyForFinalWrites = _
            TryHoldClearEventsStopped(convergenceDetail)
        On Error GoTo 0
        Err.Raise vbObjectError + 5197, _
            "ClearRecoveryFatal/SetNextBranchAccountNumber", restoreDetail
        If eventsReadyForFinalWrites And recoveryConfirmed Then
            eventsReadyForFinalWrites = _
                TryHoldClearEventsStopped(eventStateDetail)
        End If
        If eventsReadyForFinalWrites And recoveryConfirmed Then
            AddCheck "エラー", "次枝番設定の復元", _
                     "元の口座番号・入力保護・案件の安全状態を確認できないため、通常操作へ戻せません。" & _
                     restoreDetail
            eventsReadyForFinalWrites = _
                TryHoldClearEventsStopped(eventStateDetail)
        End If
        If eventsReadyForFinalWrites And recoveryConfirmed Then
            SetInputStatus "枝番の設定に失敗し、元の口座番号・入力保護を復元できないため、案件を要復旧として停止しました。C_チェックを確認し、現在のブックを上書きしないでください。", True
        End If
    Else
        eventsReadyForFinalWrites = _
            TryHoldClearEventsStopped(eventStateDetail)
        If eventsReadyForFinalWrites Then _
            SetInputStatus "枝番を設定できなかったため、元の口座番号を保持しました。", True
    End If
    Err.Clear
    On Error GoTo 0
    If eventsReadyForFinalWrites Then _
        eventsReadyForFinalWrites = _
            TryHoldClearEventsStopped(eventStateDetail)
    safeToFinalizeLease = eventsReadyForFinalWrites And _
                          (rollbackConfirmed Or recoveryConfirmed)
    If safeToFinalizeLease Then
        leaseRestored = TryFinalizeClearApplicationLease( _
                            appStarted, entryEventsCaptured, entryEvents, _
                            "次枝番設定の異常終了", leaseDetail, _
                            recoveryAttempted)
    ElseIf TryHoldClearEventsStopped(convergenceDetail) Then
        AppendClearLeaseDetail leaseDetail, _
            "口座番号・保護の復元またはRecoveryを厳密確認できないため、" & _
            "開始時イベント値へ戻さずFalseで停止しました。"
    Else
        AppendClearLeaseDetail leaseDetail, _
            "安全状態を厳密確認できず、ExcelイベントのFalse収束にも" & _
            "失敗しました: " & convergenceDetail
    End If
    If Not leaseRestored Then
        AppendClearLeaseDetail restoreDetail, leaseDetail
        If Not raiseOnError Then _
            MsgBox "次枝番設定の異常終了後、Excelイベント状態を開始値へ完全に戻せませんでした。" & _
                   vbCrLf & leaseDetail & vbCrLf & _
                   "現在のブックを上書きせず、Excelを再起動してください。", _
                   vbCritical, "Excelイベント復元エラー"
    End If
    If raiseOnError Then _
        Err.Raise errorNumber, "SetNextBranchAccountNumber", _
                  errorDescription & restoreDetail
End Sub

Public Sub ApplyPostTransferCleanup(Optional ByVal overrideKeepPolicy As String = "")
    Dim keepPolicy As String
    Dim clearTx As Boolean
    Dim clearBal As Boolean
    keepPolicy = overrideKeepPolicy
    If Len(keepPolicy) = 0 Then keepPolicy = GetPostTransferKeepPolicy()
    clearTx = GetPostTransferClearTransaction()
    clearBal = GetPostTransferClearBalance()
    ClearInputCore keepPolicy, clearTx, clearBal, True
End Sub

Public Sub ApplyPostTransferCleanupKeepBankBranch()
    ApplyPostTransferCleanup KEEP_BANK_BRANCH
End Sub

Public Sub FocusAfterPostTransferCleanup(Optional ByVal keepPolicy As String = "")
    Dim targetAddress As String
    Dim ws As Worksheet
    If Not SheetExists(SH_INPUT) Then Exit Sub
    '登録後処理の復元不能で要復旧へ遷移した場合は、診断シートから入力画面へ
    '再度戻さない。セル保護だけでなく、診断隔離中の表示位置も維持する。
    If ToolHasSetupTrace() Then
        If Not ToolDataHealthIsNormal() Then Exit Sub
    End If
    Set ws = GetSheet(SH_INPUT)
    If Len(keepPolicy) = 0 Then keepPolicy = GetPostTransferKeepPolicy()

    Select Case keepPolicy
        Case KEEP_BANK_BRANCH_PERSON_TYPE
            targetAddress = CELL_ACCOUNT_NO
        Case KEEP_BANK_BRANCH
            targetAddress = CELL_PERSON
        Case KEEP_PERSON_ONLY
            targetAddress = CELL_BANK
        Case KEEP_ALL_ACCOUNT
            targetAddress = ws.Cells(TX_FIRST_ROW, COL_TX_DAY).Address(False, False)
        Case Else
            targetAddress = CELL_BANK
    End Select
    SafeSelectCell ws, targetAddress
End Sub

Public Sub SetInputStatus(ByVal statusText As String, _
                          Optional ByVal isError As Boolean = False)
    Dim ws As Worksheet
    Dim workbookWasSaved As Boolean
    If Not SheetExists(SH_INPUT) Then Exit Sub
    On Error Resume Next
    workbookWasSaved = ThisWorkbook.Saved
    Set ws = GetSheet(SH_INPUT)
    With EffectiveRange(ws.Range(CELL_STATUS))
        If isError Then
            .Interior.Color = RGB(254, 242, 242)
            .Font.Color = RGB(185, 28, 28)
            .Borders.Color = RGB(248, 113, 113)
        Else
            .Interior.Color = RGB(236, 253, 245)
            .Font.Color = RGB(15, 118, 110)
            .Borders.Color = RGB(94, 234, 212)
        End If
        .WrapText = True
        .ShrinkToFit = False
        .Font.Size = 9
        .HorizontalAlignment = xlLeft
        .VerticalAlignment = xlCenter
    End With
    ws.Range(CELL_STATUS).Value = statusText
    '状態欄はセッション内の案内であり、案件データではない。保存済みブックへ
    '表示しただけで終了時の保存確認を出さず、既に未保存ならその状態を維持する。
    If workbookWasSaved Then ThisWorkbook.Saved = True
    On Error GoTo 0
End Sub

Public Function StrictEffectiveInputRange(ByVal sourceRange As Range, _
                                          ByVal rangeLabel As String) As Range
    '結合入力欄の一部だけをClearContentsすると1004になるため、必ず結合全体へ広げる。
    'Union後が複数Areaになる異常レイアウトは、周辺セルを誤消去しないよう変更前に止める。
    Dim expandedRange As Range
    Dim targetCell As Range
    Dim effectiveCellRange As Range
    Dim mergeState As Variant
    Dim containsMergedCells As Boolean

    If sourceRange Is Nothing Then _
        Err.Raise vbObjectError + 3210, "StrictEffectiveInputRange", rangeLabel & "を取得できません。"
    Set expandedRange = sourceRange
    mergeState = sourceRange.MergeCells
    If IsNull(mergeState) Then
        containsMergedCells = True
    Else
        containsMergedCells = CBool(mergeState)
    End If
    If containsMergedCells Then
        For Each targetCell In sourceRange.Cells
            Set effectiveCellRange = EffectiveRange(targetCell)
            If effectiveCellRange Is Nothing Then _
                Err.Raise vbObjectError + 3211, "StrictEffectiveInputRange", _
                          rangeLabel & "の結合範囲を取得できません。"
            Set expandedRange = Application.Union(expandedRange, effectiveCellRange)
        Next targetCell
    End If
    If expandedRange Is Nothing Then _
        Err.Raise vbObjectError + 3212, "StrictEffectiveInputRange", rangeLabel & "の実効範囲がありません。"
    If expandedRange.Areas.Count <> 1 Then _
        Err.Raise vbObjectError + 3213, "StrictEffectiveInputRange", _
                  rangeLabel & "の結合状態が不正です（複数の分離範囲）。"
    Set StrictEffectiveInputRange = expandedRange
End Function

Public Sub AssertInputRangeWithinBoundary(ByVal targetRange As Range, _
                                          ByVal permittedRange As Range, _
                                          ByVal rangeLabel As String)
    Dim overlapRange As Range
    If targetRange Is Nothing Or permittedRange Is Nothing Then _
        Err.Raise vbObjectError + 3253, "AssertInputRangeWithinBoundary", _
                  rangeLabel & "の許可範囲を取得できません。"
    Set overlapRange = Application.Intersect(targetRange, permittedRange)
    If overlapRange Is Nothing Then _
        Err.Raise vbObjectError + 3254, "AssertInputRangeWithinBoundary", _
                  rangeLabel & "が許可された入力範囲外です。"
    If overlapRange.CountLarge <> targetRange.CountLarge Then _
        Err.Raise vbObjectError + 3255, "AssertInputRangeWithinBoundary", _
                  rangeLabel & "の結合範囲が許可された入力範囲外へ広がっています。"
End Sub

Private Function InputRangeContainsMergedCells(ByVal targetRange As Range) As Boolean
    Dim mergeState As Variant
    If targetRange Is Nothing Then Exit Function
    mergeState = targetRange.MergeCells
    If IsNull(mergeState) Then
        InputRangeContainsMergedCells = True
    Else
        InputRangeContainsMergedCells = CBool(mergeState)
    End If
End Function

Public Function InputRangeMergeSignature(ByVal targetRange As Range) As String
    'ClearContentsの前後で、結合範囲そのものが変化していないことも照合する。
    Dim targetCell As Range
    Dim mergedArea As Range
    Dim signatureText As String
    If targetRange Is Nothing Then Exit Function
    signatureText = targetRange.Address(False, False, xlA1, False) & "|"
    If Not InputRangeContainsMergedCells(targetRange) Then
        InputRangeMergeSignature = signatureText & "結合なし"
        Exit Function
    End If
    For Each targetCell In targetRange.Cells
        If targetCell.MergeCells Then
            Set mergedArea = targetCell.MergeArea
            If targetCell.Row = mergedArea.Cells(1, 1).Row And _
               targetCell.Column = mergedArea.Cells(1, 1).Column Then
                signatureText = signatureText & mergedArea.Address(False, False, xlA1, False) & ";"
            End If
        End If
    Next targetCell
    InputRangeMergeSignature = signatureText
End Function

Private Sub AssertSupportedInputFormulaTopology(ByVal targetRange As Range, _
                                                ByVal rangeLabel As String)
    'CSE配列式や動的スピル式は、通常のFormula/Value2代入では構造を同一復元できない。
    '消去開始前に止め、入力を一切書き換えない。
    Dim arrayState As Variant, spillState As Variant
    Dim targetCell As Range
    Dim cellSpillState As Variant
    If targetRange Is Nothing Then _
        Err.Raise vbObjectError + 3256, "AssertSupportedInputFormulaTopology", _
                  rangeLabel & "を取得できません。"
    arrayState = targetRange.HasArray
    If IsNull(arrayState) Then
        For Each targetCell In targetRange.Cells
            If targetCell.HasArray Then _
                Err.Raise vbObjectError + 3257, "AssertSupportedInputFormulaTopology", _
                          rangeLabel & "に配列数式があります。消去前に通常の値へ直してください。"
        Next targetCell
    ElseIf CBool(arrayState) Then
        Err.Raise vbObjectError + 3257, "AssertSupportedInputFormulaTopology", _
                  rangeLabel & "に配列数式があります。消去前に通常の値へ直してください。"
    End If

    On Error Resume Next
    Err.Clear
    spillState = CallByName(targetRange, "HasSpill", VbGet)
    If Err.Number <> 0 Then
        Err.Clear
        On Error GoTo 0
        Exit Sub
    End If
    On Error GoTo 0
    If IsNull(spillState) Then
        For Each targetCell In targetRange.Cells
            On Error Resume Next
            Err.Clear
            cellSpillState = CallByName(targetCell, "HasSpill", VbGet)
            If Err.Number <> 0 Then
                Err.Clear
                On Error GoTo 0
                Exit Sub
            End If
            On Error GoTo 0
            If Not IsNull(cellSpillState) Then
                If CBool(cellSpillState) Then _
                    Err.Raise vbObjectError + 3258, "AssertSupportedInputFormulaTopology", _
                              rangeLabel & "にスピル数式があります。消去前に通常の値へ直してください。"
            End If
        Next targetCell
    ElseIf CBool(spillState) Then
        Err.Raise vbObjectError + 3258, "AssertSupportedInputFormulaTopology", _
                  rangeLabel & "にスピル数式があります。消去前に通常の値へ直してください。"
    End If
End Sub

Public Function CaptureInputFormulaSnapshot(ByVal targetRange As Range) As Variant
    '数式文字列だけでは、先頭アポストロフィ付きの「=...」定数を復元時に数式化し得る。
    'HasFormula・Value2・PrefixCharacterも保持し、通常の未結合範囲だけ一括退避する。
    Dim formulaValues() As Variant
    Dim constantValues() As Variant
    Dim hasFormulaValues() As Variant
    Dim prefixValues() As Variant
    Dim hasFormulaState As Variant
    Dim prefixState As Variant
    Dim targetCell As Range
    Dim mergedArea As Range
    Dim r As Long, c As Long
    If targetRange Is Nothing Then _
        Err.Raise vbObjectError + 3214, "CaptureInputFormulaSnapshot", "退避対象範囲がありません。"
    If targetRange.Areas.Count <> 1 Then _
        Err.Raise vbObjectError + 3215, "CaptureInputFormulaSnapshot", "退避対象が分離範囲です。"
    AssertSupportedInputFormulaTopology targetRange, "入力退避範囲"

    If Not InputRangeContainsMergedCells(targetRange) Then
        hasFormulaState = targetRange.HasFormula
        prefixState = targetRange.PrefixCharacter
        If Not IsNull(hasFormulaState) And Not IsNull(prefixState) Then
            If Len(CStr(prefixState)) = 0 Then
                If CBool(hasFormulaState) Then
                    CaptureInputFormulaSnapshot = _
                        Array(INPUT_SNAPSHOT_FORMULAS, targetRange.Formula, Empty, Empty, vbNullString)
                Else
                    CaptureInputFormulaSnapshot = _
                        Array(INPUT_SNAPSHOT_CONSTANTS, Empty, targetRange.Value2, Empty, vbNullString)
                End If
                Exit Function
            End If
        End If
    End If

    ReDim formulaValues(1 To targetRange.Rows.Count, 1 To targetRange.Columns.Count)
    ReDim constantValues(1 To targetRange.Rows.Count, 1 To targetRange.Columns.Count)
    ReDim hasFormulaValues(1 To targetRange.Rows.Count, 1 To targetRange.Columns.Count)
    ReDim prefixValues(1 To targetRange.Rows.Count, 1 To targetRange.Columns.Count)
    For r = 1 To targetRange.Rows.Count
        For c = 1 To targetRange.Columns.Count
            Set targetCell = targetRange.Cells(r, c)
            If targetCell.MergeCells Then
                Set mergedArea = targetCell.MergeArea
                If targetCell.Row <> mergedArea.Cells(1, 1).Row Or _
                   targetCell.Column <> mergedArea.Cells(1, 1).Column Then
                    formulaValues(r, c) = Empty
                    constantValues(r, c) = Empty
                    hasFormulaValues(r, c) = False
                    prefixValues(r, c) = vbNullString
                    GoTo NextSnapshotCell
                End If
            End If
            hasFormulaValues(r, c) = CBool(targetCell.HasFormula)
            prefixValues(r, c) = CStr(targetCell.PrefixCharacter)
            If CBool(hasFormulaValues(r, c)) Then
                formulaValues(r, c) = targetCell.Formula
                constantValues(r, c) = Empty
            Else
                formulaValues(r, c) = Empty
                constantValues(r, c) = targetCell.Value2
            End If
NextSnapshotCell:
        Next c
    Next r
    CaptureInputFormulaSnapshot = _
        Array(INPUT_SNAPSHOT_DETAILED, formulaValues, constantValues, _
              hasFormulaValues, prefixValues)
End Function

Private Function FormulaSnapshotItemsMatch(ByVal actualValue As Variant, _
                                           ByVal expectedValue As Variant) As Boolean
    If IsError(actualValue) Or IsError(expectedValue) Then
        If IsError(actualValue) And IsError(expectedValue) Then _
            FormulaSnapshotItemsMatch = _
                (Application.WorksheetFunction.Error_Type(actualValue) = _
                 Application.WorksheetFunction.Error_Type(expectedValue))
        Exit Function
    End If
    If IsEmpty(actualValue) Or IsEmpty(expectedValue) Then
        FormulaSnapshotItemsMatch = (IsEmpty(actualValue) And IsEmpty(expectedValue))
        Exit Function
    End If
    If IsNull(actualValue) Or IsNull(expectedValue) Then
        FormulaSnapshotItemsMatch = (IsNull(actualValue) And IsNull(expectedValue))
        Exit Function
    End If
    '数値1と文字列"1"を同一扱いにせず、数式・定数の型も含めて照合する。
    If VarType(actualValue) <> VarType(expectedValue) Then Exit Function
    If VarType(expectedValue) = vbString Then
        FormulaSnapshotItemsMatch = _
            (StrComp(CStr(actualValue), CStr(expectedValue), vbBinaryCompare) = 0)
    Else
        FormulaSnapshotItemsMatch = (actualValue = expectedValue)
    End If
End Function

Private Function SnapshotMatrixMatchesRange(ByVal snapshotMatrix As Variant, _
                                            ByVal targetRange As Range) As Boolean
    On Error GoTo EH
    If targetRange Is Nothing Or Not IsArray(snapshotMatrix) Then Exit Function
    If LBound(snapshotMatrix, 1) <> 1 Or _
       UBound(snapshotMatrix, 1) <> targetRange.Rows.Count Or _
       LBound(snapshotMatrix, 2) <> 1 Or _
       UBound(snapshotMatrix, 2) <> targetRange.Columns.Count Then Exit Function
    SnapshotMatrixMatchesRange = True
EH:
    Err.Clear
End Function

Private Sub AssertBulkInputSnapshot(ByVal targetRange As Range, _
                                    ByVal expectedValues As Variant, _
                                    ByVal useFormula As Boolean, _
                                    ByVal rangeLabel As String)
    Dim currentValues As Variant
    Dim r As Long, c As Long
    If useFormula Then
        currentValues = targetRange.Formula
    Else
        currentValues = targetRange.Value2
    End If
    If targetRange.CountLarge = 1 Then
        If Not FormulaSnapshotItemsMatch(currentValues, expectedValues) Then _
            Err.Raise vbObjectError + 3219, "AssertBulkInputSnapshot", _
                      rangeLabel & "の復元値または型が一致しません: " & _
                      targetRange.Cells(1, 1).Address(False, False)
        Exit Sub
    End If
    If Not SnapshotMatrixMatchesRange(expectedValues, targetRange) Or _
       Not SnapshotMatrixMatchesRange(currentValues, targetRange) Then _
        Err.Raise vbObjectError + 3217, "AssertBulkInputSnapshot", _
                  rangeLabel & "の退避範囲サイズが一致しません。"
    For r = 1 To targetRange.Rows.Count
        For c = 1 To targetRange.Columns.Count
            If Not FormulaSnapshotItemsMatch(currentValues(r, c), expectedValues(r, c)) Then _
                Err.Raise vbObjectError + 3219, "AssertBulkInputSnapshot", _
                          rangeLabel & "の復元値または型が一致しません: " & _
                          targetRange.Cells(r, c).Address(False, False)
        Next c
    Next r
End Sub

Public Sub AssertInputFormulaSnapshot(ByVal targetRange As Range, _
                                      ByVal snapshotValues As Variant, _
                                      ByVal mergeSignature As String, _
                                      ByVal rangeLabel As String)
    Dim snapshotBase As Long
    Dim snapshotMode As Long
    Dim formulaValues As Variant, constantValues As Variant
    Dim hasFormulaValues As Variant, prefixValues As Variant
    Dim targetCell As Range, mergedArea As Range
    Dim actualValue As Variant, expectedValue As Variant
    Dim actualHasFormula As Boolean, expectedHasFormula As Boolean
    Dim actualPrefix As String, expectedPrefix As String
    Dim hasFormulaState As Variant, prefixState As Variant
    Dim r As Long, c As Long
    If targetRange Is Nothing Or Not IsArray(snapshotValues) Then _
        Err.Raise vbObjectError + 3216, "AssertInputFormulaSnapshot", rangeLabel & "の退避値がありません。"
    If StrComp(InputRangeMergeSignature(targetRange), mergeSignature, vbBinaryCompare) <> 0 Then _
        Err.Raise vbObjectError + 3218, "AssertInputFormulaSnapshot", rangeLabel & "の結合範囲を復元できていません。"
    On Error GoTo InvalidSnapshot
    snapshotBase = LBound(snapshotValues)
    If UBound(snapshotValues) - snapshotBase < 4 Then GoTo InvalidSnapshot
    snapshotMode = CLng(snapshotValues(snapshotBase))
    formulaValues = snapshotValues(snapshotBase + 1)
    constantValues = snapshotValues(snapshotBase + 2)
    hasFormulaValues = snapshotValues(snapshotBase + 3)
    prefixValues = snapshotValues(snapshotBase + 4)
    On Error GoTo 0

    Select Case snapshotMode
        Case INPUT_SNAPSHOT_CONSTANTS
            hasFormulaState = targetRange.HasFormula
            prefixState = targetRange.PrefixCharacter
            If IsNull(hasFormulaState) Then _
                Err.Raise vbObjectError + 3246, "AssertInputFormulaSnapshot", _
                          rangeLabel & "に退避前になかった数式が残っています。"
            If CBool(hasFormulaState) Then _
                Err.Raise vbObjectError + 3246, "AssertInputFormulaSnapshot", _
                          rangeLabel & "に退避前になかった数式が残っています。"
            If IsNull(prefixState) Then _
                Err.Raise vbObjectError + 3247, "AssertInputFormulaSnapshot", _
                          rangeLabel & "の先頭文字属性が一致しません。"
            If Len(CStr(prefixState)) > 0 Then _
                Err.Raise vbObjectError + 3247, "AssertInputFormulaSnapshot", _
                          rangeLabel & "の先頭文字属性が一致しません。"
            AssertBulkInputSnapshot targetRange, constantValues, False, rangeLabel
            Exit Sub
        Case INPUT_SNAPSHOT_FORMULAS
            hasFormulaState = targetRange.HasFormula
            prefixState = targetRange.PrefixCharacter
            If IsNull(hasFormulaState) Then _
                Err.Raise vbObjectError + 3248, "AssertInputFormulaSnapshot", _
                          rangeLabel & "の数式を復元できていません。"
            If Not CBool(hasFormulaState) Then _
                Err.Raise vbObjectError + 3248, "AssertInputFormulaSnapshot", _
                          rangeLabel & "の数式を復元できていません。"
            If IsNull(prefixState) Then _
                Err.Raise vbObjectError + 3249, "AssertInputFormulaSnapshot", _
                          rangeLabel & "の先頭文字属性が一致しません。"
            If Len(CStr(prefixState)) > 0 Then _
                Err.Raise vbObjectError + 3249, "AssertInputFormulaSnapshot", _
                          rangeLabel & "の先頭文字属性が一致しません。"
            AssertBulkInputSnapshot targetRange, formulaValues, True, rangeLabel
            Exit Sub
        Case INPUT_SNAPSHOT_DETAILED
            If Not SnapshotMatrixMatchesRange(formulaValues, targetRange) Or _
               Not SnapshotMatrixMatchesRange(constantValues, targetRange) Or _
               Not SnapshotMatrixMatchesRange(hasFormulaValues, targetRange) Or _
               Not SnapshotMatrixMatchesRange(prefixValues, targetRange) Then _
                Err.Raise vbObjectError + 3217, "AssertInputFormulaSnapshot", _
                          rangeLabel & "の詳細退避範囲サイズが一致しません。"
        Case Else
            GoTo InvalidSnapshot
    End Select

    For r = 1 To targetRange.Rows.Count
        For c = 1 To targetRange.Columns.Count
            Set targetCell = targetRange.Cells(r, c)
            expectedHasFormula = CBool(hasFormulaValues(r, c))
            expectedPrefix = CStr(prefixValues(r, c))
            If targetCell.MergeCells Then
                Set mergedArea = targetCell.MergeArea
                If targetCell.Row <> mergedArea.Cells(1, 1).Row Or _
                   targetCell.Column <> mergedArea.Cells(1, 1).Column Then
                    actualHasFormula = False
                    actualPrefix = vbNullString
                    actualValue = Empty
                    GoTo CompareDetailedCell
                End If
            End If
            actualHasFormula = CBool(targetCell.HasFormula)
            actualPrefix = CStr(targetCell.PrefixCharacter)
            If actualHasFormula Then
                actualValue = targetCell.Formula
            Else
                actualValue = targetCell.Value2
            End If
CompareDetailedCell:
            If actualHasFormula <> expectedHasFormula Or _
               StrComp(actualPrefix, expectedPrefix, vbBinaryCompare) <> 0 Then _
                Err.Raise vbObjectError + 3250, "AssertInputFormulaSnapshot", _
                          rangeLabel & "の数式属性または先頭文字属性が一致しません: " & _
                          targetCell.Address(False, False)
            If expectedHasFormula Then
                expectedValue = formulaValues(r, c)
            Else
                expectedValue = constantValues(r, c)
            End If
            If Not FormulaSnapshotItemsMatch(actualValue, expectedValue) Then _
                Err.Raise vbObjectError + 3219, "AssertInputFormulaSnapshot", _
                          rangeLabel & "の復元値または型が一致しません: " & _
                          targetCell.Address(False, False)
        Next c
    Next r
    Exit Sub
InvalidSnapshot:
    Err.Raise vbObjectError + 3216, "AssertInputFormulaSnapshot", _
              rangeLabel & "の退避値形式が不正です。"
End Sub

Public Sub RestoreInputFormulaSnapshot(ByVal targetRange As Range, _
                                       ByVal snapshotValues As Variant, _
                                       ByVal mergeSignature As String, _
                                       ByVal rangeLabel As String)
    Dim snapshotBase As Long
    Dim snapshotMode As Long
    Dim formulaValues As Variant, constantValues As Variant
    Dim hasFormulaValues As Variant, prefixValues As Variant
    Dim r As Long, c As Long
    Dim targetCell As Range
    Dim mergedArea As Range
    Dim expectedHasFormula As Boolean
    Dim expectedPrefix As String
    Dim expectedValue As Variant
    If targetRange Is Nothing Then _
        Err.Raise vbObjectError + 3220, "RestoreInputFormulaSnapshot", rangeLabel & "の復元範囲がありません。"
    If StrComp(InputRangeMergeSignature(targetRange), mergeSignature, vbBinaryCompare) <> 0 Then _
        Err.Raise vbObjectError + 3221, "RestoreInputFormulaSnapshot", rangeLabel & "の結合範囲が退避時と異なります。"

    '退避形式とサイズは、現在値を消すより前に検証する。
    On Error GoTo InvalidSnapshot
    snapshotBase = LBound(snapshotValues)
    If UBound(snapshotValues) - snapshotBase < 4 Then GoTo InvalidSnapshot
    snapshotMode = CLng(snapshotValues(snapshotBase))
    formulaValues = snapshotValues(snapshotBase + 1)
    constantValues = snapshotValues(snapshotBase + 2)
    hasFormulaValues = snapshotValues(snapshotBase + 3)
    prefixValues = snapshotValues(snapshotBase + 4)
    Select Case snapshotMode
        Case INPUT_SNAPSHOT_CONSTANTS
            If InputRangeContainsMergedCells(targetRange) Then GoTo InvalidSnapshot
            If targetRange.CountLarge > 1 Then
                If Not SnapshotMatrixMatchesRange(constantValues, targetRange) Then GoTo InvalidSnapshot
            End If
        Case INPUT_SNAPSHOT_FORMULAS
            If InputRangeContainsMergedCells(targetRange) Then GoTo InvalidSnapshot
            If targetRange.CountLarge > 1 Then
                If Not SnapshotMatrixMatchesRange(formulaValues, targetRange) Then GoTo InvalidSnapshot
            End If
        Case INPUT_SNAPSHOT_DETAILED
            If Not SnapshotMatrixMatchesRange(formulaValues, targetRange) Or _
               Not SnapshotMatrixMatchesRange(constantValues, targetRange) Or _
               Not SnapshotMatrixMatchesRange(hasFormulaValues, targetRange) Or _
               Not SnapshotMatrixMatchesRange(prefixValues, targetRange) Then GoTo InvalidSnapshot
        Case Else
            GoTo InvalidSnapshot
    End Select
    On Error GoTo 0

    targetRange.ClearContents
    Select Case snapshotMode
        Case INPUT_SNAPSHOT_CONSTANTS
            targetRange.Value2 = constantValues
        Case INPUT_SNAPSHOT_FORMULAS
            targetRange.Formula = formulaValues
        Case INPUT_SNAPSHOT_DETAILED
            For r = 1 To targetRange.Rows.Count
                For c = 1 To targetRange.Columns.Count
                    Set targetCell = targetRange.Cells(r, c)
                    If targetCell.MergeCells Then
                        Set mergedArea = targetCell.MergeArea
                        If targetCell.Row <> mergedArea.Cells(1, 1).Row Or _
                           targetCell.Column <> mergedArea.Cells(1, 1).Column Then _
                            GoTo NextRestoreCell
                    End If
                    expectedHasFormula = CBool(hasFormulaValues(r, c))
                    expectedPrefix = CStr(prefixValues(r, c))
                    If expectedHasFormula Then
                        targetCell.Formula = formulaValues(r, c)
                    Else
                        expectedValue = constantValues(r, c)
                        If Len(expectedPrefix) > 0 Then
                            If IsError(expectedValue) Or IsNull(expectedValue) Or IsEmpty(expectedValue) Then _
                                Err.Raise vbObjectError + 3251, "RestoreInputFormulaSnapshot", _
                                          rangeLabel & "の先頭文字属性付き定数が不正です: " & _
                                          targetCell.Address(False, False)
                            targetCell.Formula = expectedPrefix & CStr(expectedValue)
                        Else
                            targetCell.Value2 = expectedValue
                        End If
                    End If
NextRestoreCell:
                Next c
            Next r
    End Select
    AssertInputFormulaSnapshot targetRange, snapshotValues, mergeSignature, rangeLabel
    Exit Sub
InvalidSnapshot:
    Err.Raise vbObjectError + 3252, "RestoreInputFormulaSnapshot", _
              rangeLabel & "の退避値形式またはサイズが不正です。"
End Sub

Public Sub ClearInputRangeStrict(ByVal targetRange As Range, ByVal rangeLabel As String)
    Dim targetCell As Range
    Dim mergedArea As Range
    Dim cellValue As Variant
    Dim hasFormulaState As Variant, prefixState As Variant
    If targetRange Is Nothing Then _
        Err.Raise vbObjectError + 3222, "ClearInputRangeStrict", rangeLabel & "の消去範囲がありません。"
    targetRange.ClearContents
    hasFormulaState = targetRange.HasFormula
    prefixState = targetRange.PrefixCharacter
    If Application.WorksheetFunction.CountA(targetRange) = 0 Then
        If Not IsNull(hasFormulaState) Then
            If Not CBool(hasFormulaState) And Not IsNull(prefixState) Then
                If Len(CStr(prefixState)) = 0 Then Exit Sub
            End If
        End If
    End If
    '通常は範囲単位の値・数式・先頭文字属性確認で完了し、残存時だけ原因セルを特定する。
    For Each targetCell In targetRange.Cells
        If targetCell.MergeCells Then
            Set mergedArea = targetCell.MergeArea
            If targetCell.Row <> mergedArea.Cells(1, 1).Row Or _
               targetCell.Column <> mergedArea.Cells(1, 1).Column Then GoTo NextClearCheckCell
        End If
        cellValue = targetCell.Value2
        If IsError(cellValue) Or Not IsEmpty(cellValue) Or targetCell.HasFormula Or _
           Len(CStr(targetCell.PrefixCharacter)) > 0 Then _
            Err.Raise vbObjectError + 3223, "ClearInputRangeStrict", _
                      rangeLabel & "を完全に消去できません: " & targetCell.Address(False, False)
NextClearCheckCell:
    Next targetCell
End Sub

Public Sub CaptureInputProtection(ByVal ws As Worksheet, _
                                  ByRef snapshot As InputProtectionSnapshot)
    If ws Is Nothing Then _
        Err.Raise vbObjectError + 3224, "CaptureInputProtection", "入力シートがありません。"
    With snapshot
        .ProtectContents = ws.ProtectContents
        .ProtectDrawingObjects = ws.ProtectDrawingObjects
        .ProtectScenarios = ws.ProtectScenarios
        .ProtectionMode = ws.ProtectionMode
        .EnableSelection = ws.EnableSelection
        .EnableOutlining = ws.EnableOutlining
        .EnableAutoFilter = ws.EnableAutoFilter
        .EnablePivotTable = ws.EnablePivotTable
        With ws.Protection
            snapshot.AllowFormattingCells = .AllowFormattingCells
            snapshot.AllowFormattingColumns = .AllowFormattingColumns
            snapshot.AllowFormattingRows = .AllowFormattingRows
            snapshot.AllowInsertingColumns = .AllowInsertingColumns
            snapshot.AllowInsertingRows = .AllowInsertingRows
            snapshot.AllowInsertingHyperlinks = .AllowInsertingHyperlinks
            snapshot.AllowDeletingColumns = .AllowDeletingColumns
            snapshot.AllowDeletingRows = .AllowDeletingRows
            snapshot.AllowSorting = .AllowSorting
            snapshot.AllowFiltering = .AllowFiltering
            snapshot.AllowUsingPivotTables = .AllowUsingPivotTables
        End With
        .Captured = True
    End With
End Sub

Public Sub RestoreInputProtection(ByVal ws As Worksheet, _
                                  ByRef snapshot As InputProtectionSnapshot)
    If ws Is Nothing Or Not snapshot.Captured Then _
        Err.Raise vbObjectError + 3225, "RestoreInputProtection", "入力シート保護の退避値がありません。"
    ws.Unprotect Password:=TOOL_PASSWORD
    If snapshot.ProtectContents Or snapshot.ProtectDrawingObjects Or snapshot.ProtectScenarios Then
        With snapshot
            ws.Protect Password:=TOOL_PASSWORD, _
                       DrawingObjects:=.ProtectDrawingObjects, _
                       Contents:=.ProtectContents, _
                       Scenarios:=.ProtectScenarios, _
                       UserInterfaceOnly:=.ProtectionMode, _
                       AllowFormattingCells:=.AllowFormattingCells, _
                       AllowFormattingColumns:=.AllowFormattingColumns, _
                       AllowFormattingRows:=.AllowFormattingRows, _
                       AllowInsertingColumns:=.AllowInsertingColumns, _
                       AllowInsertingRows:=.AllowInsertingRows, _
                       AllowInsertingHyperlinks:=.AllowInsertingHyperlinks, _
                       AllowDeletingColumns:=.AllowDeletingColumns, _
                       AllowDeletingRows:=.AllowDeletingRows, _
                       AllowSorting:=.AllowSorting, _
                       AllowFiltering:=.AllowFiltering, _
                       AllowUsingPivotTables:=.AllowUsingPivotTables
        End With
    End If
    ws.EnableOutlining = snapshot.EnableOutlining
    ws.EnableAutoFilter = snapshot.EnableAutoFilter
    ws.EnablePivotTable = snapshot.EnablePivotTable
    ws.EnableSelection = snapshot.EnableSelection
End Sub

Public Sub AssertInputProtection(ByVal ws As Worksheet, _
                                 ByRef snapshot As InputProtectionSnapshot)
    If ws Is Nothing Or Not snapshot.Captured Then _
        Err.Raise vbObjectError + 3226, "AssertInputProtection", "入力シート保護の退避値がありません。"
    If ws.ProtectContents <> snapshot.ProtectContents Or _
       ws.ProtectDrawingObjects <> snapshot.ProtectDrawingObjects Or _
       ws.ProtectScenarios <> snapshot.ProtectScenarios Or _
       ws.ProtectionMode <> snapshot.ProtectionMode Or _
       ws.EnableOutlining <> snapshot.EnableOutlining Or _
       ws.EnableAutoFilter <> snapshot.EnableAutoFilter Or _
       ws.EnablePivotTable <> snapshot.EnablePivotTable Or _
       ws.EnableSelection <> snapshot.EnableSelection Then _
        Err.Raise vbObjectError + 3227, "AssertInputProtection", "入力シートの保護状態が一致しません。"
    With ws.Protection
        If .AllowFormattingCells <> snapshot.AllowFormattingCells Or _
           .AllowFormattingColumns <> snapshot.AllowFormattingColumns Or _
           .AllowFormattingRows <> snapshot.AllowFormattingRows Or _
           .AllowInsertingColumns <> snapshot.AllowInsertingColumns Or _
           .AllowInsertingRows <> snapshot.AllowInsertingRows Or _
           .AllowInsertingHyperlinks <> snapshot.AllowInsertingHyperlinks Or _
           .AllowDeletingColumns <> snapshot.AllowDeletingColumns Or _
           .AllowDeletingRows <> snapshot.AllowDeletingRows Or _
           .AllowSorting <> snapshot.AllowSorting Or _
           .AllowFiltering <> snapshot.AllowFiltering Or _
           .AllowUsingPivotTables <> snapshot.AllowUsingPivotTables Then _
            Err.Raise vbObjectError + 3228, "AssertInputProtection", "入力シート保護の許可設定が一致しません。"
    End With
End Sub

Private Sub AppendInputRestoreError(ByRef restoreDetail As String, _
                                    ByVal stepName As String, _
                                    ByVal errorNumber As Long, _
                                    ByVal errorDescription As String)
    If errorNumber = 0 Then Exit Sub
    restoreDetail = restoreDetail & vbCrLf & "・" & stepName & ": Err " & _
                    CStr(errorNumber) & " " & errorDescription
End Sub

Private Sub AppendClearLeaseDetail(ByRef detailText As String, _
                                   ByVal additionalDetail As String)
    If Len(additionalDetail) = 0 Then Exit Sub
    If Len(detailText) > 0 Then detailText = detailText & vbCrLf
    detailText = detailText & "・" & additionalDetail
End Sub

Private Function TryGetClearEnableEvents(ByRef currentValue As Boolean, _
                                         ByRef detailText As String) As Boolean
    Dim errorNumber As Long, errorDescription As String
    detailText = vbNullString
    On Error GoTo EH
    currentValue = Application.EnableEvents
    TryGetClearEnableEvents = True
    Exit Function
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    detailText = "Err " & CStr(errorNumber) & ": " & errorDescription
    Err.Clear
End Function

Private Function TrySetClearEnableEventsExact(ByVal desiredValue As Boolean, _
                                              ByRef detailText As String) As Boolean
    Dim errorNumber As Long, errorDescription As String
    detailText = vbNullString
    On Error GoTo EH
    Application.EnableEvents = desiredValue
    If Application.EnableEvents <> desiredValue Then _
        Err.Raise vbObjectError + 3260, "TrySetClearEnableEventsExact", _
                  "EnableEventsの書込み後読戻しが一致しません。"
    TrySetClearEnableEventsExact = True
    Exit Function
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    detailText = "Err " & CStr(errorNumber) & ": " & errorDescription
    Err.Clear
End Function

Private Function TryHoldClearEventsStopped(ByRef detailText As String) As Boolean
    Dim firstDetail As String, retryDetail As String
    detailText = vbNullString
    If TrySetClearEnableEventsExact(False, firstDetail) Then
        TryHoldClearEventsStopped = True
        Exit Function
    End If
    If TrySetClearEnableEventsExact(False, retryDetail) Then
        TryHoldClearEventsStopped = True
        Exit Function
    End If
    detailText = "初回=" & firstDetail & " / 再試行=" & retryDetail
End Function

Private Function ClearRecoveryStateIsConfirmedExact( _
        ByRef detailText As String) As Boolean
    Dim stateValue As String
    Dim recoveryLatchSet As Boolean, latchReadSucceeded As Boolean
    Dim healthReadSucceeded As Boolean

    healthReadSucceeded = _
        TryGetExactStateValue(STATE_DATA_HEALTH, stateValue)
    latchReadSucceeded = TryGetRollbackRecoveryLatch(recoveryLatchSet)
    ClearRecoveryStateIsConfirmedExact = _
        healthReadSucceeded And _
        (StrComp(stateValue, DATA_HEALTH_NEEDS_RECOVERY, _
                 vbBinaryCompare) = 0) And _
        latchReadSucceeded And recoveryLatchSet
    If ClearRecoveryStateIsConfirmedExact Then Exit Function
    If Not healthReadSucceeded Then
        AppendClearLeaseDetail detailText, _
            "Recovery状態を一意に読み返せません。"
    ElseIf StrComp(stateValue, DATA_HEALTH_NEEDS_RECOVERY, _
                   vbBinaryCompare) <> 0 Then
        AppendClearLeaseDetail detailText, _
            "Recovery状態をNEEDS_RECOVERYとして読み返せません。"
    End If
    If Not latchReadSucceeded Then
        AppendClearLeaseDetail detailText, _
            "Recoveryラッチを一意に読み返せません。"
    ElseIf Not recoveryLatchSet Then
        AppendClearLeaseDetail detailText, _
            "Recoveryラッチを設定済みとして読み返せません。"
    End If
End Function

Private Function IsClearRecoveryFatal( _
        ByVal errorNumber As Long, ByVal errorSource As String) As Boolean
    Dim expectedSource As String
    Select Case errorNumber
        Case vbObjectError + 3599, vbObjectError + 4499
            IsClearRecoveryFatal = True
            Exit Function
        Case vbObjectError + 5191
            expectedSource = "AnalysisWorkspaceRecoveryFatal/"
        Case vbObjectError + 5192
            expectedSource = "SetupConvergeRecoveryFatal/"
        Case vbObjectError + 5194
            expectedSource = "CashAnalysisRecoveryFatal/"
        Case vbObjectError + 5195
            expectedSource = "TransactionAnalysisRecoveryFatal/"
        Case vbObjectError + 5196
            expectedSource = "CashManualSelectionRecoveryFatal/"
        Case vbObjectError + 5197
            expectedSource = "ClearRecoveryFatal/"
        Case Else
            Exit Function
    End Select
    If Len(errorSource) < Len(expectedSource) Then Exit Function
    IsClearRecoveryFatal = _
        (StrComp(Left$(errorSource, Len(expectedSource)), expectedSource, _
                 vbBinaryCompare) = 0)
End Function

Private Function TryEnterClearRecoveryState(ByVal operationName As String, _
                                            ByRef detailText As String, _
                                            Optional ByRef recoveryEnforcementFailed As Boolean = False, _
                                            Optional ByRef recoveryAttempted As Boolean = False) As Boolean
    Dim currentEvents As Boolean, eventsDetail As String
    Dim recoveryDetail As String
    Dim recoveryErrorNumber As Long, recoveryErrorDescription As String
    Dim postRecoveryEventsStopped As Boolean
    Dim recoveryConfirmed As Boolean, applicationStateConfirmed As Boolean
    Dim postRecoveryEventDetail As String, finalRecoveryEventDetail As String
    Dim appStateProblems As String
    recoveryEnforcementFailed = False

    If recoveryAttempted Then
        AppendClearLeaseDetail detailText, _
            "この上位処理ではRecovery設定を既に試行済みのため、" & _
            "二重実行を行いません。"
        postRecoveryEventsStopped = _
            TryHoldClearEventsStopped(postRecoveryEventDetail)
        Err.Raise vbObjectError + 5197, _
                  "ClearRecoveryFatal/TryEnterClearRecoveryState", _
                  detailText
    End If

    If Not TryGetClearEnableEvents(currentEvents, eventsDetail) Then
        AppendClearLeaseDetail detailText, _
            "Recovery記録を中止しました。Excelイベント停止を確認できません: " & eventsDetail
        Exit Function
    End If
    If currentEvents Then
        AppendClearLeaseDetail detailText, _
            "Recovery記録を中止しました。ExcelイベントがFalseではありません。"
        Exit Function
    End If

    recoveryDetail = operationName
    If Len(detailText) > 0 Then recoveryDetail = recoveryDetail & vbCrLf & detailText
    recoveryAttempted = True
    On Error Resume Next
    Err.Clear
    EnforceRollbackRecoveryState recoveryDetail
    recoveryErrorNumber = Err.Number
    recoveryErrorDescription = Err.Description
    Err.Clear
    On Error GoTo 0
    'Enforceの例外値を保存した直後に、外側のFalse exactを取り直す。
    postRecoveryEventsStopped = _
        TryHoldClearEventsStopped(postRecoveryEventDetail)
    If recoveryErrorNumber <> 0 Then
        recoveryEnforcementFailed = True
        AppendClearLeaseDetail detailText, _
            "Recovery状態の設定に失敗: Err " & CStr(recoveryErrorNumber) & _
            " " & recoveryErrorDescription
        If Not postRecoveryEventsStopped Then _
            AppendClearLeaseDetail detailText, _
                "Recovery例外後のExcelイベントFalse収束も確認できません: " & _
                postRecoveryEventDetail
        Err.Raise vbObjectError + 5197, _
                  "ClearRecoveryFatal/TryEnterClearRecoveryState", _
                  detailText
    End If
    '共通Recovery処理は独自のApplication leaseを閉じ得るため、
    '状態表と独立ラッチの読取りより前に外側のFalseを取り直す。
    If Not postRecoveryEventsStopped Then
        AppendClearLeaseDetail detailText, _
            "Recovery処理後にExcelイベント停止を確認できないため、" & _
            "復旧状態を読み取りません。現在状態は不明です: " & _
            postRecoveryEventDetail
        Err.Raise vbObjectError + 5197, _
                  "ClearRecoveryFatal/TryEnterClearRecoveryState", _
                  detailText
    End If
    recoveryConfirmed = _
        ClearRecoveryStateIsConfirmedExact(detailText)
    If Not recoveryConfirmed Then
        postRecoveryEventsStopped = _
            TryHoldClearEventsStopped(finalRecoveryEventDetail)
        Err.Raise vbObjectError + 5197, _
                  "ClearRecoveryFatal/TryEnterClearRecoveryState", _
                  detailText
    End If
    applicationStateConfirmed = AppStateIsRestored(appStateProblems)
    If Not applicationStateConfirmed Then
        AppendClearLeaseDetail detailText, _
            "Recovery確認後のApplication状態を安全に復元済みと" & _
            "確認できません: " & appStateProblems
        postRecoveryEventsStopped = _
            TryHoldClearEventsStopped(finalRecoveryEventDetail)
        Err.Raise vbObjectError + 5197, _
                  "ClearRecoveryFatal/TryEnterClearRecoveryState", _
                  detailText
    End If
    postRecoveryEventsStopped = _
        TryHoldClearEventsStopped(finalRecoveryEventDetail)
    If Not postRecoveryEventsStopped Then
        AppendClearLeaseDetail detailText, _
            "Application状態確認後のExcelイベントFalse収束を" & _
            "確認できません: " & finalRecoveryEventDetail
        Err.Raise vbObjectError + 5197, _
                  "ClearRecoveryFatal/TryEnterClearRecoveryState", _
                  detailText
    End If
    Err.Raise vbObjectError + 5197, _
              "ClearRecoveryFatal/TryEnterClearRecoveryState", _
              detailText
End Function

Private Function TryFinalizeClearApplicationLease( _
        ByRef appStarted As Boolean, _
        ByVal entryEventsCaptured As Boolean, _
        ByVal entryEvents As Boolean, _
        ByVal operationName As String, _
        ByRef detailText As String, _
        Optional ByRef recoveryAttempted As Boolean = False) As Boolean
    Dim firstErrorNumber As Long, firstErrorDescription As String
    Dim retryErrorNumber As Long, retryErrorDescription As String
    Dim forceErrorNumber As Long, forceErrorDescription As String
    Dim eventDetail As String, firstEventDetail As String
    Dim retryEventDetail As String, finalEventDetail As String
    Dim safeStopDetail As String, appStateProblems As String
    Dim applicationRestoreFailed As Boolean
    Dim applicationStateRestored As Boolean, recoveryConfirmed As Boolean
    Dim eventsStopped As Boolean
    Dim recoveryEnforcementFailed As Boolean

    applicationStateRestored = True

    If recoveryAttempted Then
        eventsStopped = TryHoldClearEventsStopped(safeStopDetail)
        AppendClearLeaseDetail detailText, _
            "この上位処理ではRecovery設定を既に試行済みのため、" & _
            "Application leaseの追加復元を行いません。"
        Err.Raise vbObjectError + 5197, _
                  "ClearRecoveryFatal/TryFinalizeClearApplicationLease", _
                  detailText
    End If

    If appStarted Then
        On Error Resume Next
        Err.Clear
        AppEnd
        firstErrorNumber = Err.Number
        firstErrorDescription = Err.Description
        Err.Clear
        On Error GoTo 0
        If firstErrorNumber = 0 Then
            appStarted = False
        Else
            applicationRestoreFailed = True
            applicationStateRestored = False
            AppendClearLeaseDetail detailText, _
                "Excel状態の通常復元に失敗: Err " & CStr(firstErrorNumber) & _
                " " & firstErrorDescription
            eventsStopped = TryHoldClearEventsStopped(eventDetail)
            If eventsStopped Then
                recoveryConfirmed = TryEnterClearRecoveryState( _
                    operationName & " / Excel状態の通常復元失敗", _
                    detailText, recoveryEnforcementFailed, _
                    recoveryAttempted)
                If recoveryEnforcementFailed Then
                    eventsStopped = TryHoldClearEventsStopped(safeStopDetail)
                    Err.Raise vbObjectError + 5197, _
                        "ClearRecoveryFatal/TryFinalizeClearApplicationLease", _
                        detailText
                End If
                If recoveryAttempted Then
                    eventsStopped = _
                        TryHoldClearEventsStopped(safeStopDetail)
                    Err.Raise vbObjectError + 5197, _
                        "ClearRecoveryFatal/TryFinalizeClearApplicationLease", _
                        detailText
                End If
            Else
                AppendClearLeaseDetail detailText, _
                    "Recovery記録前のExcelイベント停止に失敗: " & eventDetail
            End If

            AppendClearLeaseDetail detailText, _
                "Application復元失敗後は追加のAppEnd/AppForceRestoreを" & _
                "行わず、ExcelイベントをFalseで停止します。"
        End If
    End If

    If Not entryEventsCaptured Then
        AppendClearLeaseDetail detailText, _
            "開始時のExcelイベント状態を取得できていないため復元値を断定できません。"
        Exit Function
    End If

    If Not applicationStateRestored Or _
       (applicationRestoreFailed And Not recoveryConfirmed) Then
        If TryHoldClearEventsStopped(safeStopDetail) Then
            AppendClearLeaseDetail detailText, _
                "Excel状態またはRecovery状態を確定できないため、ExcelイベントをFalseで停止しました。"
        Else
            AppendClearLeaseDetail detailText, _
                "Excelイベントを安全停止へ戻せません: " & safeStopDetail
        End If
        Exit Function
    End If

    If applicationRestoreFailed Then
        eventsStopped = TryHoldClearEventsStopped(safeStopDetail)
        If Not eventsStopped Then
            AppendClearLeaseDetail detailText, _
                "Application再復元後のExcelイベントFalse収束を確認できません: " & _
                safeStopDetail
            Exit Function
        End If
    End If

    If entryEvents Then
        If Not AppStateIsRestored(appStateProblems) Then
            AppendClearLeaseDetail detailText, _
                "Application状態を安全に復元済みと確認できません: " & _
                appStateProblems
            eventsStopped = TryHoldClearEventsStopped(safeStopDetail)
            Exit Function
        End If
    End If

    If TrySetClearEnableEventsExact(entryEvents, firstEventDetail) Then
        TryFinalizeClearApplicationLease = Not applicationRestoreFailed
        Exit Function
    End If
    If TrySetClearEnableEventsExact(entryEvents, retryEventDetail) Then
        AppendClearLeaseDetail detailText, _
            "Excelイベント開始値への復元は再試行で成功しました。"
        TryFinalizeClearApplicationLease = Not applicationRestoreFailed
        Exit Function
    End If

    AppendClearLeaseDetail detailText, _
        "Excelイベントを開始値へ復元できません: 初回=" & firstEventDetail & _
        " / 再試行=" & retryEventDetail
    eventsStopped = TryHoldClearEventsStopped(safeStopDetail)
    If eventsStopped Then
        recoveryConfirmed = TryEnterClearRecoveryState( _
            operationName & " / Excelイベント開始値の復元失敗", _
            detailText, recoveryEnforcementFailed, recoveryAttempted)
        If recoveryEnforcementFailed Then
            eventsStopped = TryHoldClearEventsStopped(safeStopDetail)
            Err.Raise vbObjectError + 5197, _
                "ClearRecoveryFatal/TryFinalizeClearApplicationLease", _
                detailText
        End If
        If recoveryAttempted Then
            eventsStopped = TryHoldClearEventsStopped(safeStopDetail)
            Err.Raise vbObjectError + 5197, _
                "ClearRecoveryFatal/TryFinalizeClearApplicationLease", _
                detailText
        End If
        AppendClearLeaseDetail detailText, _
            "Recovery設定を開始できないため開始値への復元を中止しました。"
        If Not TryHoldClearEventsStopped(safeStopDetail) Then _
            AppendClearLeaseDetail detailText, _
                "Excelイベントを安全停止へ戻せません: " & safeStopDetail
    Else
        AppendClearLeaseDetail detailText, _
            "Excelイベント停止を確認できないためRecovery記録を行いません: " & _
            safeStopDetail
    End If
End Function

Private Function InputDateSensitiveContentRemains(ByVal ws As Worksheet) As Boolean
    '以前の暦設定で入力された可能性がある日付を1件でも残す場合は、
    '整理の正常終了だけを理由にDATE_SAFEをTrueへ開かない。
    Dim dateFields As Variant, fieldAddress As Variant
    Dim targetCell As Range
    Dim foundCell As Range
    On Error GoTo AssumeRemaining
    If ws Is Nothing Then GoTo AssumeRemaining
    dateFields = Array(CELL_OPEN_DATE, CELL_CLOSE_DATE)
    For Each fieldAddress In dateFields
        Set targetCell = ws.Range(CStr(fieldAddress))
        If targetCell.HasFormula Or IsError(targetCell.Value2) Or _
           Not IsEmpty(targetCell.Value2) Then
            InputDateSensitiveContentRemains = True
            Exit Function
        End If
    Next fieldAddress
    Set foundCell = ws.Range(ws.Cells(TX_FIRST_ROW, COL_TX_YEAR), _
                             ws.Cells(TX_LAST_ROW, COL_TX_BALANCE)).Find( _
                    What:="*", After:=ws.Cells(TX_FIRST_ROW, COL_TX_YEAR), _
                    LookIn:=xlFormulas, LookAt:=xlPart, SearchOrder:=xlByRows, _
                    SearchDirection:=xlPrevious, MatchCase:=False, MatchByte:=False, _
                    SearchFormat:=False)
    InputDateSensitiveContentRemains = Not foundCell Is Nothing
    Exit Function
AssumeRemaining:
    InputDateSensitiveContentRemains = True
End Function

Public Sub ClearInputCore(ByVal keepPolicy As String, ByVal clearTx As Boolean, ByVal clearBal As Boolean, _
                          Optional ByVal resetEditState As Boolean = True)
    Dim ws As Worksheet
    Dim bankName As String, branchName As String
    Dim personName As String, relationName As String
    Dim accType As String, accNo As String
    Dim openDate As Variant, closeDate As Variant
    Dim accountFields As Variant
    Dim accountRanges(0 To 7) As Range
    Dim accountSnapshots(0 To 7) As Variant
    Dim accountMergeSignatures(0 To 7) As String
    Dim balanceAmountRange As Range, balanceMemoRange As Range
    Dim transactionRange As Range, statusRange As Range
    Dim balanceAmountSnapshot As Variant, balanceMemoSnapshot As Variant
    Dim transactionSnapshot As Variant, statusSnapshot As Variant
    Dim balanceAmountMergeSignature As String, balanceMemoMergeSignature As String
    Dim transactionMergeSignature As String, statusMergeSignature As String
    Dim protectionSnapshot As InputProtectionSnapshot
    Dim memoCol As Long
    Dim i As Long
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim stepErrorNumber As Long, stepErrorDescription As String
    Dim previousEditAccountID As String, restoredEditAccountID As String
    Dim previousDateConfigSafe As String
    Dim snapshotCaptured As Boolean, appStarted As Boolean
    Dim mutationStarted As Boolean, operationCommitted As Boolean
    Dim entryEventsCaptured As Boolean, entryEvents As Boolean
    Dim balanceAmountSnapshotCaptured As Boolean
    Dim balanceMemoSnapshotCaptured As Boolean
    Dim transactionSnapshotCaptured As Boolean, transactionLastRow As Long
    Dim finalDateSafeStopped As Boolean
    Dim rollbackConfirmed As Boolean, recoveryConfirmed As Boolean
    Dim eventsReadyForFinalWrites As Boolean, safeToFinalizeLease As Boolean
    Dim recoveryErrorNumber As Long, recoveryErrorDescription As String
    Dim recoveryEnforcementFailed As Boolean
    Dim recoveryAttempted As Boolean
    Dim applicationStateConfirmed As Boolean
    Dim restoreDetail As String, eventStateDetail As String
    Dim postEnforceEventDetail As String, convergenceDetail As String
    Dim finalRecoveryEventDetail As String, appStateProblems As String
    Dim currentDateConfigSafe As String, finalDateConfigSafe As String

    On Error GoTo EH
    If Not SheetExists(SH_INPUT) Then Exit Sub
    Set ws = GetSheet(SH_INPUT)

    'クリアや後続の書式・保護処理が失敗しても、利用者の未登録入力を失わない。
    accountFields = Array(CELL_BANK, CELL_BRANCH, CELL_PERSON, CELL_RELATIONSHIP, _
                          CELL_ACCOUNT_TYPE, CELL_ACCOUNT_NO, CELL_OPEN_DATE, CELL_CLOSE_DATE)
    For i = 0 To 7
        Set accountRanges(i) = StrictEffectiveInputRange( _
                                   ws.Range(CStr(accountFields(i))), _
                                   "口座入力欄 " & CStr(accountFields(i)))
        accountSnapshots(i) = CaptureInputFormulaSnapshot(accountRanges(i))
        accountMergeSignatures(i) = InputRangeMergeSignature(accountRanges(i))
    Next i

    memoCol = BalanceMemoCol(ws)
    If memoCol < BAL_FIRST_COL Or memoCol > BAL_MAX_COL Then _
        Err.Raise vbObjectError + 3229, "ClearInputCore", "残高メモ欄の列位置が不正です。"
    If memoCol > BAL_FIRST_COL Then
        Set balanceAmountRange = StrictEffectiveInputRange( _
                                     ws.Range(ws.Cells(BAL_VALUE_ROW, BAL_FIRST_COL), _
                                              ws.Cells(BAL_VALUE_ROW, memoCol - 1)), _
                                     "残高金額欄")
        AssertInputRangeWithinBoundary balanceAmountRange, _
                                       ws.Range(ws.Cells(BAL_VALUE_ROW, BAL_FIRST_COL), _
                                                ws.Cells(BAL_VALUE_ROW, memoCol - 1)), _
                                       "残高金額欄"
        balanceAmountSnapshot = CaptureInputFormulaSnapshot(balanceAmountRange)
        balanceAmountMergeSignature = InputRangeMergeSignature(balanceAmountRange)
        balanceAmountSnapshotCaptured = True
    End If
    Set balanceMemoRange = StrictEffectiveInputRange(BalanceMemoInputRange(ws), "残高メモ欄")
    AssertInputRangeWithinBoundary balanceMemoRange, BalanceMemoInputRange(ws), "残高メモ欄"
    balanceMemoSnapshot = CaptureInputFormulaSnapshot(balanceMemoRange)
    balanceMemoMergeSignature = InputRangeMergeSignature(balanceMemoRange)
    balanceMemoSnapshotCaptured = True

    If clearTx Then
        transactionLastRow = StrictLastTransactionInputRow(ws)
        If transactionLastRow >= TX_FIRST_ROW Then
            Set transactionRange = StrictEffectiveInputRange( _
                                       ws.Range(ws.Cells(TX_FIRST_ROW, COL_TX_YEAR), _
                                                ws.Cells(transactionLastRow, COL_TX_BALANCE)), _
                                       "取引入力欄")
            AssertInputRangeWithinBoundary transactionRange, _
                                           ws.Range(ws.Cells(TX_FIRST_ROW, COL_TX_YEAR), _
                                                    ws.Cells(TX_LAST_ROW, COL_TX_BALANCE)), _
                                           "取引入力欄"
            transactionSnapshot = CaptureInputFormulaSnapshot(transactionRange)
            transactionMergeSignature = InputRangeMergeSignature(transactionRange)
            transactionSnapshotCaptured = True
        End If
    End If
    Set statusRange = StrictEffectiveInputRange(ws.Range(CELL_STATUS), "入力ステータス欄")
    statusSnapshot = CaptureInputFormulaSnapshot(statusRange)
    statusMergeSignature = InputRangeMergeSignature(statusRange)
    previousEditAccountID = CurrentEditAccountID()
    '安全状態を読めない場合は、復元後も登録停止を維持する。
    If Not TryGetExactStateValue(STATE_INPUT_DATE_CONFIG_SAFE, previousDateConfigSafe) Then _
        previousDateConfigSafe = STATE_FALSE
    If previousDateConfigSafe <> STATE_TRUE And previousDateConfigSafe <> STATE_FALSE Then _
        previousDateConfigSafe = STATE_FALSE
    CaptureInputProtection ws, protectionSnapshot
    snapshotCaptured = True

    If Not TryGetClearEnableEvents(entryEvents, eventStateDetail) Then _
        Err.Raise vbObjectError + 3267, "ClearInputCore", _
                  "Excelイベントの開始状態を取得できません: " & eventStateDetail
    entryEventsCaptured = True
    AppBegin "入力欄を整理しています..."
    appStarted = True
    If Not TrySetClearEnableEventsExact(False, eventStateDetail) Then _
        Err.Raise vbObjectError + 3268, "ClearInputCore", _
                  "Excelイベント停止を確認できません: " & eventStateDetail

    bankName = CellText(ws.Range(CELL_BANK).Value)
    branchName = CellText(ws.Range(CELL_BRANCH).Value)
    personName = CellText(ws.Range(CELL_PERSON).Value)
    relationName = CellText(ws.Range(CELL_RELATIONSHIP).Value)
    accType = CellText(ws.Range(CELL_ACCOUNT_TYPE).Value)
    accNo = CellText(ws.Range(CELL_ACCOUNT_NO).Value)
    openDate = ws.Range(CELL_OPEN_DATE).Value
    closeDate = ws.Range(CELL_CLOSE_DATE).Value

    mutationStarted = True
    ws.Unprotect Password:=TOOL_PASSWORD
    For i = 0 To 7
        ClearInputRangeStrict accountRanges(i), "口座入力欄 " & CStr(accountFields(i))
    Next i

    If clearBal Then
        If balanceAmountSnapshotCaptured Then _
            ClearInputRangeStrict balanceAmountRange, "残高金額欄"
        ClearInputRangeStrict balanceMemoRange, "残高メモ欄"
    End If
    If clearTx Then
        If transactionSnapshotCaptured Then
            ClearInputRangeStrict transactionRange, "取引入力欄"
            RestoreAllTransactionRowStyles ws, transactionLastRow
        End If
        InvalidateDateComplementCache
    End If

    Select Case keepPolicy
        Case KEEP_PERSON_ONLY
            ws.Range(CELL_PERSON).Value = personName
            If UseRelationshipDisplay() Then ws.Range(CELL_RELATIONSHIP).Value = relationName
        Case KEEP_BANK_BRANCH
            ws.Range(CELL_BANK).Value = bankName
            ws.Range(CELL_BRANCH).Value = branchName
        Case KEEP_BANK_BRANCH_PERSON_TYPE
            ws.Range(CELL_BANK).Value = bankName
            ws.Range(CELL_BRANCH).Value = branchName
            ws.Range(CELL_PERSON).Value = personName
            If UseRelationshipDisplay() Then ws.Range(CELL_RELATIONSHIP).Value = relationName
            ws.Range(CELL_ACCOUNT_TYPE).Value = accType
        Case KEEP_ALL_ACCOUNT
            ws.Range(CELL_BANK).Value = bankName
            ws.Range(CELL_BRANCH).Value = branchName
            ws.Range(CELL_PERSON).Value = personName
            If UseRelationshipDisplay() Then ws.Range(CELL_RELATIONSHIP).Value = relationName
            ws.Range(CELL_ACCOUNT_TYPE).Value = accType
            ws.Range(CELL_ACCOUNT_NO).Value = accNo
            ws.Range(CELL_OPEN_DATE).Value = openDate
            ws.Range(CELL_CLOSE_DATE).Value = closeDate
    End Select

    If resetEditState Then SetEditAccountID ""
    ws.Range(CELL_STATUS).Value = "日付補完　-年　-月　-日　／　入力時刻　--:--"
    ApplyBalanceAvailability ws
    InvalidateDuplicateAccountWarningCache
    ProtectInputSheet True
    RefreshMainActionCaption
    '開設・解約日または取引入力を残す整理では、以前の停止状態を勝手に解除しない。
    If InputDateSensitiveContentRemains(ws) Then
        finalDateConfigSafe = previousDateConfigSafe
    Else
        finalDateConfigSafe = STATE_TRUE
    End If
    SetStateValue STATE_INPUT_DATE_CONFIG_SAFE, finalDateConfigSafe
    If Not TryGetExactStateValue( _
               STATE_INPUT_DATE_CONFIG_SAFE, currentDateConfigSafe) Then _
        Err.Raise vbObjectError + 3239, "ClearInputCore", _
                  "入力整理後の日付安全状態を読み返せません。"
    If currentDateConfigSafe <> finalDateConfigSafe Then _
        Err.Raise vbObjectError + 3239, "ClearInputCore", _
                  "入力整理後の日付安全状態を一意に確定できません。"
    If Not TryHoldClearEventsStopped(eventStateDetail) Then _
        Err.Raise vbObjectError + 3271, "ClearInputCore", _
                  "入力整理の確定前にExcelイベント停止を確認できません: " & eventStateDetail
    operationCommitted = True
    If Not TryFinalizeClearApplicationLease( _
               appStarted, entryEventsCaptured, entryEvents, _
               "入力欄整理の最終処理", restoreDetail, _
               recoveryAttempted) Then _
        Err.Raise vbObjectError + 3269, "ClearInputCore", _
                  "入力欄の整理は完了しましたが、Excel状態の最終復元に失敗しました。" & _
                  restoreDetail
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    If IsClearRecoveryFatal(errorNumber, errorSource) Then
        Call TryHoldClearEventsStopped(convergenceDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    If Not entryEventsCaptured Then
        Err.Raise errorNumber, "ClearInputCore", _
                  IIf(Len(errorSource) > 0, errorSource & " / ", "") & _
                  errorDescription & vbCrLf & _
                  "開始時のExcelイベント状態を取得できていないため、復元処理は行っていません。"
    End If
    If Not TryHoldClearEventsStopped(eventStateDetail) Then
        AppendClearLeaseDetail restoreDetail, _
            "復元前のExcelイベント停止を確認できません: " & eventStateDetail
        If TryHoldClearEventsStopped(convergenceDetail) Then
            AppendClearLeaseDetail restoreDetail, _
                "安全状態を確認できないため開始時イベント値へ戻さず、" & _
                "Falseで停止しました。"
        Else
            AppendClearLeaseDetail restoreDetail, _
                "ExcelイベントのFalse収束にも失敗し、現在状態は不明です: " & _
                convergenceDetail
        End If
        Err.Raise errorNumber, "ClearInputCore", _
                  IIf(Len(errorSource) > 0, errorSource & " / ", "") & _
                  errorDescription & vbCrLf & _
                  "Excelイベント停止を確認できる前には、ブックへ復元・診断情報を書き込んでいません。" & _
                  restoreDetail
    End If
    If operationCommitted Then
        recoveryConfirmed = TryEnterClearRecoveryState( _
            "入力欄整理完了後のExcel状態復元失敗", restoreDetail, _
            recoveryEnforcementFailed, recoveryAttempted)
        If recoveryAttempted Then
            eventsReadyForFinalWrites = _
                TryHoldClearEventsStopped(convergenceDetail)
            Err.Raise vbObjectError + 5197, _
                "ClearRecoveryFatal/ClearInputCore", restoreDetail
        End If
        eventsReadyForFinalWrites = _
            TryHoldClearEventsStopped(eventStateDetail)
        safeToFinalizeLease = _
            recoveryConfirmed And eventsReadyForFinalWrites
        If safeToFinalizeLease Then
            Call TryFinalizeClearApplicationLease( _
                appStarted, entryEventsCaptured, entryEvents, _
                "入力欄整理の異常終了", restoreDetail, recoveryAttempted)
        ElseIf TryHoldClearEventsStopped(convergenceDetail) Then
            AppendClearLeaseDetail restoreDetail, _
                "確定済み変更のRecoveryを厳密確認できないため、" & _
                "開始時イベント値へ戻さずFalseで停止しました。"
        Else
            AppendClearLeaseDetail restoreDetail, _
                "確定済み変更のRecoveryを厳密確認できず、" & _
                "ExcelイベントのFalse収束にも失敗しました: " & _
                convergenceDetail
        End If
        Err.Raise errorNumber, "ClearInputCore", _
                  IIf(Len(errorSource) > 0, errorSource & " / ", "") & _
                  errorDescription & vbCrLf & _
                  "入力欄の変更は確定済みのため、開始前入力へは戻していません。" & _
                  restoreDetail
    End If
    On Error Resume Next
    'どの工程で失敗しても、旧入力の完全復元を確認するまでは日付解釈をfail-closedにする。
    Err.Clear
    SetStateValue STATE_INPUT_DATE_CONFIG_SAFE, STATE_FALSE
    If Err.Number <> 0 Then
        stepErrorNumber = Err.Number
        stepErrorDescription = Err.Description
        Err.Clear
        AppendInputRestoreError restoreDetail, "日付安全状態の停止", _
                                stepErrorNumber, stepErrorDescription
    End If

    If snapshotCaptured And Not ws Is Nothing Then
        If mutationStarted Then
        Err.Clear
        ws.Unprotect Password:=TOOL_PASSWORD
        If Err.Number <> 0 Then
            stepErrorNumber = Err.Number
            stepErrorDescription = Err.Description
            Err.Clear
            AppendInputRestoreError restoreDetail, "入力シート保護解除", _
                                    stepErrorNumber, stepErrorDescription
        End If

        For i = 0 To 7
            Err.Clear
            RestoreInputFormulaSnapshot accountRanges(i), accountSnapshots(i), _
                                        accountMergeSignatures(i), _
                                        "口座入力欄 " & CStr(accountFields(i))
            If Err.Number <> 0 Then
                stepErrorNumber = Err.Number
                stepErrorDescription = Err.Description
                Err.Clear
                AppendInputRestoreError restoreDetail, _
                                        "口座入力欄 " & CStr(accountFields(i)) & " の復元", _
                                        stepErrorNumber, stepErrorDescription
            End If
        Next i

        '元の日付で入力可否・書式を戻してから、残高の数式・値を最後に厳密復元する。
        Err.Clear
        ApplyBalanceAvailability ws
        If Err.Number <> 0 Then
            stepErrorNumber = Err.Number
            stepErrorDescription = Err.Description
            Err.Clear
            AppendInputRestoreError restoreDetail, "残高入力可否の復元", _
                                    stepErrorNumber, stepErrorDescription
        End If
        If balanceAmountSnapshotCaptured Then
            Err.Clear
            RestoreInputFormulaSnapshot balanceAmountRange, balanceAmountSnapshot, _
                                        balanceAmountMergeSignature, "残高金額欄"
            If Err.Number <> 0 Then
                stepErrorNumber = Err.Number
                stepErrorDescription = Err.Description
                Err.Clear
                AppendInputRestoreError restoreDetail, "残高金額欄の復元", _
                                        stepErrorNumber, stepErrorDescription
            End If
        End If
        If balanceMemoSnapshotCaptured Then
            Err.Clear
            RestoreInputFormulaSnapshot balanceMemoRange, balanceMemoSnapshot, _
                                        balanceMemoMergeSignature, "残高メモ欄"
            If Err.Number <> 0 Then
                stepErrorNumber = Err.Number
                stepErrorDescription = Err.Description
                Err.Clear
                AppendInputRestoreError restoreDetail, "残高メモ欄の復元", _
                                        stepErrorNumber, stepErrorDescription
            End If
        End If
        If transactionSnapshotCaptured Then
            Err.Clear
            RestoreInputFormulaSnapshot transactionRange, transactionSnapshot, _
                                        transactionMergeSignature, "取引入力欄"
            If Err.Number <> 0 Then
                stepErrorNumber = Err.Number
                stepErrorDescription = Err.Description
                Err.Clear
                AppendInputRestoreError restoreDetail, "取引入力欄の復元", _
                                        stepErrorNumber, stepErrorDescription
            End If
            Err.Clear
            InvalidateDateComplementCache
            If Err.Number <> 0 Then
                stepErrorNumber = Err.Number
                stepErrorDescription = Err.Description
                Err.Clear
                AppendInputRestoreError restoreDetail, "日付補完キャッシュの破棄", _
                                        stepErrorNumber, stepErrorDescription
            End If
            Err.Clear
            RestoreAllTransactionRowStyles ws, transactionLastRow
            If Err.Number <> 0 Then
                stepErrorNumber = Err.Number
                stepErrorDescription = Err.Description
                Err.Clear
                AppendInputRestoreError restoreDetail, "取引行書式の復元", _
                                        stepErrorNumber, stepErrorDescription
            End If
        End If

        Err.Clear
        RestoreInputFormulaSnapshot statusRange, statusSnapshot, _
                                    statusMergeSignature, "入力ステータス欄"
        If Err.Number <> 0 Then
            stepErrorNumber = Err.Number
            stepErrorDescription = Err.Description
            Err.Clear
            AppendInputRestoreError restoreDetail, "入力ステータス欄の復元", _
                                    stepErrorNumber, stepErrorDescription
        End If

        Err.Clear
        SetEditAccountID previousEditAccountID
        If Err.Number <> 0 Then
            stepErrorNumber = Err.Number
            stepErrorDescription = Err.Description
            Err.Clear
            AppendInputRestoreError restoreDetail, "訂正IDの復元", _
                                    stepErrorNumber, stepErrorDescription
        End If

        Err.Clear
        RestoreInputProtection ws, protectionSnapshot
        If Err.Number <> 0 Then
            stepErrorNumber = Err.Number
            stepErrorDescription = Err.Description
            Err.Clear
            AppendInputRestoreError restoreDetail, "入力シート保護の復元", _
                                    stepErrorNumber, stepErrorDescription
        End If

        End If
        '書込みが例外を出さなくても値が戻っていない場合があるため、全退避項目を読み返す。
        For i = 0 To 7
            Err.Clear
            AssertInputFormulaSnapshot accountRanges(i), accountSnapshots(i), _
                                       accountMergeSignatures(i), _
                                       "口座入力欄 " & CStr(accountFields(i))
            If Err.Number <> 0 Then
                stepErrorNumber = Err.Number
                stepErrorDescription = Err.Description
                Err.Clear
                AppendInputRestoreError restoreDetail, _
                                        "口座入力欄 " & CStr(accountFields(i)) & " の照合", _
                                        stepErrorNumber, stepErrorDescription
            End If
        Next i
        If balanceAmountSnapshotCaptured Then
            Err.Clear
            AssertInputFormulaSnapshot balanceAmountRange, balanceAmountSnapshot, _
                                       balanceAmountMergeSignature, "残高金額欄"
            If Err.Number <> 0 Then
                stepErrorNumber = Err.Number
                stepErrorDescription = Err.Description
                Err.Clear
                AppendInputRestoreError restoreDetail, "残高金額欄の照合", _
                                        stepErrorNumber, stepErrorDescription
            End If
        End If
        If balanceMemoSnapshotCaptured Then
            Err.Clear
            AssertInputFormulaSnapshot balanceMemoRange, balanceMemoSnapshot, _
                                       balanceMemoMergeSignature, "残高メモ欄"
            If Err.Number <> 0 Then
                stepErrorNumber = Err.Number
                stepErrorDescription = Err.Description
                Err.Clear
                AppendInputRestoreError restoreDetail, "残高メモ欄の照合", _
                                        stepErrorNumber, stepErrorDescription
            End If
        End If
        If transactionSnapshotCaptured Then
            Err.Clear
            AssertInputFormulaSnapshot transactionRange, transactionSnapshot, _
                                       transactionMergeSignature, "取引入力欄"
            If Err.Number <> 0 Then
                stepErrorNumber = Err.Number
                stepErrorDescription = Err.Description
                Err.Clear
                AppendInputRestoreError restoreDetail, "取引入力欄の照合", _
                                        stepErrorNumber, stepErrorDescription
            End If
        End If
        Err.Clear
        AssertInputFormulaSnapshot statusRange, statusSnapshot, _
                                   statusMergeSignature, "入力ステータス欄"
        If Err.Number <> 0 Then
            stepErrorNumber = Err.Number
            stepErrorDescription = Err.Description
            Err.Clear
            AppendInputRestoreError restoreDetail, "入力ステータス欄の照合", _
                                    stepErrorNumber, stepErrorDescription
        End If
        Err.Clear
        If Not TryGetExactStateValue(STATE_EDIT_ACCOUNT, restoredEditAccountID) Then _
            Err.Raise vbObjectError + 3230, "ClearInputCore", "訂正IDを読み返せません。"
        If Err.Number = 0 Then
            If StrComp(restoredEditAccountID, previousEditAccountID, vbBinaryCompare) <> 0 Then _
                Err.Raise vbObjectError + 3231, "ClearInputCore", "訂正IDの復元値が一致しません。"
        End If
        If Err.Number <> 0 Then
            stepErrorNumber = Err.Number
            stepErrorDescription = Err.Description
            Err.Clear
            AppendInputRestoreError restoreDetail, "訂正IDの照合", _
                                    stepErrorNumber, stepErrorDescription
        End If
        Err.Clear
        AssertInputProtection ws, protectionSnapshot
        If Err.Number <> 0 Then
            stepErrorNumber = Err.Number
            stepErrorDescription = Err.Description
            Err.Clear
            AppendInputRestoreError restoreDetail, "入力シート保護の照合", _
                                    stepErrorNumber, stepErrorDescription
        End If
        Err.Clear
        If Not TryGetExactStateValue(STATE_INPUT_DATE_CONFIG_SAFE, currentDateConfigSafe) Then _
            Err.Raise vbObjectError + 3232, "ClearInputCore", "停止した日付安全状態を読み返せません。"
        If Err.Number = 0 Then
            If currentDateConfigSafe <> STATE_FALSE Then _
                Err.Raise vbObjectError + 3233, "ClearInputCore", "復元確認前の日付安全状態が停止になっていません。"
        End If
        If Err.Number <> 0 Then
            stepErrorNumber = Err.Number
            stepErrorDescription = Err.Description
            Err.Clear
            AppendInputRestoreError restoreDetail, "日付安全状態の停止確認", _
                                    stepErrorNumber, stepErrorDescription
        End If
    Else
        AppendInputRestoreError restoreDetail, "整理前入力の復元", _
                                vbObjectError + 3234, "完全な退避値を取得できていません。"
    End If

    '全数式・訂正ID・保護・停止状態が一致した場合だけ、退避時の安全状態へ戻す。
    If Len(restoreDetail) = 0 Then
        Err.Clear
        SetStateValue STATE_INPUT_DATE_CONFIG_SAFE, previousDateConfigSafe
        If Err.Number = 0 Then
            If Not TryGetExactStateValue(STATE_INPUT_DATE_CONFIG_SAFE, currentDateConfigSafe) Then _
                Err.Raise vbObjectError + 3235, "ClearInputCore", "日付安全状態を読み返せません。"
        End If
        If Err.Number = 0 Then
            If currentDateConfigSafe <> previousDateConfigSafe Then _
                Err.Raise vbObjectError + 3236, "ClearInputCore", "日付安全状態の復元値が一致しません。"
        End If
        If Err.Number <> 0 Then
            stepErrorNumber = Err.Number
            stepErrorDescription = Err.Description
            Err.Clear
            AppendInputRestoreError restoreDetail, "日付安全状態の最終復元", _
                                    stepErrorNumber, stepErrorDescription
        End If
    End If
    rollbackConfirmed = (Len(restoreDetail) = 0)
    If Len(restoreDetail) > 0 Then
        '最終安全状態の復元自体で失敗した場合も、Trueを残さないよう再度停止を試みる。
        Err.Clear
        SetStateValue STATE_INPUT_DATE_CONFIG_SAFE, STATE_FALSE
        If Err.Number = 0 Then
            If Not TryGetExactStateValue(STATE_INPUT_DATE_CONFIG_SAFE, currentDateConfigSafe) Then _
                Err.Raise vbObjectError + 3237, "ClearInputCore", "日付安全状態の停止結果を読み返せません。"
        End If
        If Err.Number = 0 Then
            If currentDateConfigSafe <> STATE_FALSE Then _
                Err.Raise vbObjectError + 3238, "ClearInputCore", "日付安全状態を停止できていません。"
        End If
        If Err.Number = 0 Then finalDateSafeStopped = True
        If Err.Number <> 0 Then
            stepErrorNumber = Err.Number
            stepErrorDescription = Err.Description
            Err.Clear
            AppendInputRestoreError restoreDetail, "日付安全状態の最終停止", _
                                    stepErrorNumber, stepErrorDescription
        End If
        If Not finalDateSafeStopped Then
            Err.Clear
            recoveryAttempted = True
            EnforceRollbackRecoveryState restoreDetail
            recoveryErrorNumber = Err.Number
            recoveryErrorDescription = Err.Description
            Err.Clear
            eventsReadyForFinalWrites = _
                TryHoldClearEventsStopped(postEnforceEventDetail)
            If recoveryErrorNumber <> 0 Then
                recoveryEnforcementFailed = True
                AppendClearLeaseDetail restoreDetail, _
                    "要復旧状態の強制設定エラー: Err " & _
                    CStr(recoveryErrorNumber) & " " & _
                    recoveryErrorDescription
                On Error GoTo 0
                Err.Raise vbObjectError + 5197, _
                    "ClearRecoveryFatal/ClearInputCore", restoreDetail
            ElseIf eventsReadyForFinalWrites Then
                recoveryConfirmed = _
                    ClearRecoveryStateIsConfirmedExact(restoreDetail)
                If recoveryConfirmed Then
                    applicationStateConfirmed = _
                        AppStateIsRestored(appStateProblems)
                    If Not applicationStateConfirmed Then _
                        AppendClearLeaseDetail restoreDetail, _
                            "Recovery確認後のApplication状態を安全に" & _
                            "確認できません: " & appStateProblems
                End If
                If applicationStateConfirmed Then _
                    eventsReadyForFinalWrites = _
                        TryHoldClearEventsStopped( _
                            finalRecoveryEventDetail)
            Else
                AppendClearLeaseDetail restoreDetail, _
                    "Recovery処理後にExcelイベント停止を確認できないため、" & _
                    "復旧状態を読み取りませんでした。現在状態は不明です: " & _
                    postEnforceEventDetail
            End If
            eventsReadyForFinalWrites = _
                TryHoldClearEventsStopped(convergenceDetail)
            On Error GoTo 0
            Err.Raise vbObjectError + 5197, _
                "ClearRecoveryFatal/ClearInputCore", restoreDetail
        End If
        If Not recoveryConfirmed And Not recoveryAttempted Then
            recoveryConfirmed = TryEnterClearRecoveryState( _
                "入力欄整理の復元不一致", restoreDetail, _
                recoveryEnforcementFailed, recoveryAttempted)
            If recoveryAttempted Then
                On Error GoTo 0
                eventsReadyForFinalWrites = _
                    TryHoldClearEventsStopped(convergenceDetail)
                Err.Raise vbObjectError + 5197, _
                    "ClearRecoveryFatal/ClearInputCore", restoreDetail
            End If
        End If
    End If
    '復元・Recovery記録をイベント停止下で終え、Application lease、開始時イベントの順に戻す。
    eventsReadyForFinalWrites = _
        TryHoldClearEventsStopped(eventStateDetail)
    safeToFinalizeLease = eventsReadyForFinalWrites And _
                          (rollbackConfirmed Or recoveryConfirmed)
    If safeToFinalizeLease Then
        Call TryFinalizeClearApplicationLease( _
            appStarted, entryEventsCaptured, entryEvents, _
            "入力欄整理の異常終了", restoreDetail, recoveryAttempted)
    ElseIf TryHoldClearEventsStopped(convergenceDetail) Then
        AppendClearLeaseDetail restoreDetail, _
            "入力復元またはRecoveryを厳密確認できないため、" & _
            "開始時イベント値へ戻さずFalseで停止しました。"
    Else
        AppendClearLeaseDetail restoreDetail, _
            "安全状態を厳密確認できず、ExcelイベントのFalse収束にも" & _
            "失敗しました: " & convergenceDetail
    End If
    On Error GoTo 0
    Err.Raise errorNumber, "ClearInputCore", _
              IIf(Len(errorSource) > 0, errorSource & " / ", "") & _
              errorDescription & _
              IIf(Len(restoreDetail) > 0, vbCrLf & "整理前入力の復元確認:" & restoreDetail, "")
End Sub

Public Sub InitializeToolData()
    Dim answer As VbMsgBoxResult
    Dim verifyDetail As String
    Dim stepName As String
    Dim backupPath As String
    Dim errorNumber As Long, errorSource As String, errorDescription As String
    Dim destructiveStarted As Boolean, healthStateSet As Boolean
    Dim operationCommitted As Boolean, requiresInspection As Boolean
    Dim recoveryStateDetail As String, currentHealthState As String
    Dim healthClass As Long
    Dim cleanupErrorNumber As Long, cleanupErrorDescription As String
    Dim entryEvents As Boolean, entryEventsCaptured As Boolean
    Dim appStarted As Boolean
    Dim recoveryAttempted As Boolean
    Dim recoveryEnforcementFailed As Boolean
    Dim eventStateDetail As String, leaseDetail As String
    Dim convergenceDetail As String
    Dim latchIsSet As Boolean, inspectionPrepared As Boolean

    If ThisWorkbook.ReadOnly Then
        MsgBox "このブックは読み取り専用です。上書きできる場所へ別名保存してから初期化してください。", _
               vbExclamation, "初期化できません"
        Exit Sub
    End If

    'ボタン以外から直接実行された場合も、要復旧状態や内部シート不足のまま消去へ進めない。
    If Not RequireToolReady() Then Exit Sub

    answer = MsgBox("この案件の入力欄・登録済み口座・取引・残高・チェック・帳票をすべて消去します。" & vbCrLf & _
                    "銀行名・支店名・人物の案件候補も消去します。表示・入力設定、共通データ、摘要候補、科目候補は残ります。" & vbCrLf & _
                    "相続開始日は空欄にし、残高表示年は案件用の初期値へ戻します。" & vbCrLf & vbCrLf & _
                    "実行直前に同じフォルダへバックアップを作成します。ブックが未保存、またはバックアップを作れない場合は消去を開始しません。" & vbCrLf & _
                    "初期化しますか？", _
                    vbYesNo + vbExclamation + vbDefaultButton2, "案件データの初期化")
    If answer <> vbYes Then Exit Sub

    On Error GoTo EH
    If Not TryGetClearEnableEvents(entryEvents, eventStateDetail) Then _
        Err.Raise vbObjectError + 1910, "InitializeToolData", _
                  "Excelイベントの開始状態を取得できません: " & eventStateDetail
    entryEventsCaptured = True
    stepName = "初期化前候補確認"
    ValidateCaseCandidateResetSources
    stepName = "初期化前保持設定確認"
    ValidateInitializationPreservedSettings
    stepName = "初期化前バックアップ"
    backupPath = CreateInitializationBackup()
    AppBegin "案件データを初期化しています..."
    appStarted = True
    If Not TrySetClearEnableEventsExact(False, eventStateDetail) Then _
        Err.Raise vbObjectError + 1911, "InitializeToolData", _
                  "Excelイベント停止を確認できません: " & eventStateDetail
    DisableInputKeys
    stepName = "初期化状態記録"
    SetStateValue STATE_DATA_HEALTH, DATA_HEALTH_INITIALIZING
    healthStateSet = True
    If Not TryGetExactStateValue(STATE_DATA_HEALTH, currentHealthState) Then _
        Err.Raise vbObjectError + 1904, "InitializeToolData", _
                  "初期化中の案件状態を読み返せません。"
    If currentHealthState <> DATA_HEALTH_INITIALIZING Then _
        Err.Raise vbObjectError + 1904, "InitializeToolData", _
                  "初期化中の案件状態を一意に確認できません。"

    stepName = "初期化復旧ラッチ記録"
    '強制停止後に未検証の初期化結果を通常扱いしない。独立ラッチは
    SetRollbackRecoveryLatch
    stepName = "入力欄"
    destructiveStarted = True
    ClearInputCore KEEP_NONE, True, True, True
    stepName = "作業データ"
    BuildWorkSheets DATA_HEALTH_INITIALIZING
    stepName = "出力データ"
    BuildOutputSheets
    stepName = "案件候補"
    ResetCaseCandidates
    ReconcileInternalIdCounters
    stepName = "案件設定"
    ResetCaseSpecificSettings
    stepName = "セットアップログ"
    ResetSetupLog
    stepName = "残高入力欄"
    BuildBalanceInputFields False, True
    stepName = "状態確認"
    SetEditAccountID ""
    '空帳票を「更新済み」と記録せず、次の相続開始日設定後に必ず再構築させる。
    SetStateValue STATE_OUTPUT_DIRTY, STATE_TRUE
    SetStateValue STATE_ANALYSIS_REVIEW_DIRTY, STATE_FALSE
    SetStateValue STATE_LAST_BUILD, ""
    If Not VerifyCaseDataCleared(verifyDetail, True) Then
        Err.Raise vbObjectError + 1901, "InitializeToolData", "消去されていないデータ: " & verifyDetail
    End If

    GetSheet(SH_INPUT).Visible = xlSheetVisible
    HideDailySheets True
    GetSheet(SH_CONFIG).Visible = xlSheetVisible
    SafeSelectCell GetSheet(SH_CONFIG), "C4"
    DisableInputKeys
    stepName = "案件データ状態確定"
    SetStateValue STATE_DATA_HEALTH, DATA_HEALTH_NORMAL
    If Not TryGetExactStateValue(STATE_DATA_HEALTH, currentHealthState) Then _
        Err.Raise vbObjectError + 1905, "InitializeToolData", _
                  "初期化完了後の案件状態を読み返せません。"
    If currentHealthState <> DATA_HEALTH_NORMAL Then _
        Err.Raise vbObjectError + 1905, "InitializeToolData", _
                  "初期化完了後の案件状態を一意に確認できません。"
    stepName = "中核データ最終確認"
    If Not ValidateAuthoritativeDataStructure(verifyDetail, False, True) Then _
        Err.Raise vbObjectError + 1902, "InitializeToolData", verifyDetail
    stepName = "初期化復旧ラッチ解除"
    ClearRollbackRecoveryLatch
    If Not TryGetRollbackRecoveryLatch(latchIsSet) Then _
        Err.Raise vbObjectError + 1912, "InitializeToolData", _
                  "初期化復旧ラッチを読み返せません。"
    If latchIsSet Then _
        Err.Raise vbObjectError + 1912, "InitializeToolData", _
                  "初期化復旧ラッチの解除を一意に確認できません。"
    destructiveStarted = False
    operationCommitted = True
    If Not TryHoldClearEventsStopped(eventStateDetail) Then _
        Err.Raise vbObjectError + 1917, "InitializeToolData", _
                  "完了表示前のExcelイベント停止を確認できません: " & eventStateDetail
    SetInputStatus "初期化済み　相続開始日を設定してください。"
    If Not TryFinalizeClearApplicationLease( _
               appStarted, entryEventsCaptured, entryEvents, _
               "案件初期化の最終処理", leaseDetail, _
               recoveryAttempted) Then
        MsgBox "案件データの初期化は完了しましたが、Excelの状態を開始時へ完全に戻せませんでした。" & _
               vbCrLf & leaseDetail & vbCrLf & _
               "Recovery状態へ停止しました。現在のブックを上書きせず、Excelを再起動してください。", _
               vbCritical, "初期化の最終処理エラー"
        Exit Sub
    End If
    MsgBox "案件データを初期化し、消去結果を確認しました。" & vbCrLf & _
           "初期化前バックアップ: " & backupPath & vbCrLf & _
               "次に相続開始日と残高表示年を入力してください。残高欄は自動更新されます。", vbInformation, "初期化完了"
    Exit Sub
EH:
    errorNumber = Err.Number
    errorSource = Err.Source
    errorDescription = Err.Description
    If IsClearRecoveryFatal(errorNumber, errorSource) Then
        Call TryHoldClearEventsStopped(convergenceDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    If Not entryEventsCaptured Then
        MsgBox "初期化を開始できませんでした。" & vbCrLf & _
               "Excelイベントの開始状態を取得できないため、ブックへ復元・診断情報を書き込んでいません。" & _
               vbCrLf & "工程: " & stepName & vbCrLf & _
               "Err " & errorNumber & ": " & errorDescription, _
               vbCritical, "Excelイベント状態不明"
        Exit Sub
    End If

    If Not TryHoldClearEventsStopped(eventStateDetail) Then
        AppendClearLeaseDetail recoveryStateDetail, _
            "復旧前のExcelイベント停止を確認できません: " & eventStateDetail
        Call TryFinalizeClearApplicationLease( _
            appStarted, entryEventsCaptured, entryEvents, "案件初期化の異常終了", _
            leaseDetail, recoveryAttempted)
        MsgBox "初期化を完了できませんでした。" & vbCrLf & _
               "Excelイベント停止を確認できる前には、ブックへ復元・診断情報を書き込んでいません。" & _
               vbCrLf & "工程: " & stepName & vbCrLf & _
               "Err " & errorNumber & ": " & errorDescription & _
               recoveryStateDetail & leaseDetail, _
               vbCritical, "Excelイベント状態不明"
        Exit Sub
    End If

    '以降のhealth/latch、保護、OnKey、診断シートの変更は、
    'EnableEvents=Falseの読戻しを確認した同一区間内だけで行う。
    If operationCommitted Or destructiveStarted Then
        requiresInspection = True
        If Not TryEnterClearRecoveryState( _
                   "案件初期化の異常終了 / 工程: " & stepName, _
                   recoveryStateDetail, recoveryEnforcementFailed, _
                   recoveryAttempted) Then _
            AppendClearLeaseDetail recoveryStateDetail, _
                "案件初期化のRecovery状態を一意に確定できません。"
        If recoveryAttempted Then
            Call TryHoldClearEventsStopped(convergenceDetail)
            Err.Raise vbObjectError + 5197, _
                "ClearRecoveryFatal/InitializeToolData", _
                recoveryStateDetail
        End If
    ElseIf healthStateSet Then
        On Error Resume Next
        Err.Clear
        SetStateValue STATE_DATA_HEALTH, DATA_HEALTH_NORMAL
        cleanupErrorNumber = Err.Number
        cleanupErrorDescription = Err.Description
        Err.Clear
        If cleanupErrorNumber = 0 Then
            If Not TryGetExactStateValue( _
                       STATE_DATA_HEALTH, currentHealthState) Then
                cleanupErrorNumber = vbObjectError + 1913
            ElseIf currentHealthState <> DATA_HEALTH_NORMAL Then
                cleanupErrorNumber = vbObjectError + 1913
            End If
        End If
        If cleanupErrorNumber <> 0 Then
            AppendClearLeaseDetail recoveryStateDetail, _
                "破壊開始前の案件状態を通常へ戻せません: Err " & _
                CStr(cleanupErrorNumber) & " " & cleanupErrorDescription
            requiresInspection = True
        End If

        Err.Clear
        ClearRollbackRecoveryLatch
        cleanupErrorNumber = Err.Number
        cleanupErrorDescription = Err.Description
        Err.Clear
        If cleanupErrorNumber = 0 Then
            If Not TryGetRollbackRecoveryLatch(latchIsSet) Then
                cleanupErrorNumber = vbObjectError + 1914
            ElseIf latchIsSet Then
                cleanupErrorNumber = vbObjectError + 1914
            End If
        End If
        If cleanupErrorNumber <> 0 Then
            AppendClearLeaseDetail recoveryStateDetail, _
                "破壊開始前のRecoveryラッチを解除できません: Err " & _
                CStr(cleanupErrorNumber) & " " & cleanupErrorDescription
            requiresInspection = True
        End If

        Err.Clear
        healthClass = ToolDataHealthClassification()
        If Err.Number <> 0 Or healthClass <> TOOL_HEALTH_NORMAL Then
            AppendClearLeaseDetail recoveryStateDetail, _
                "破壊開始前状態を通常として再確認できません。"
            requiresInspection = True
        End If
        Err.Clear
        On Error GoTo 0
        If requiresInspection Then _
            Call TryEnterClearRecoveryState( _
                "案件初期化前状態の復元失敗", recoveryStateDetail, _
                recoveryEnforcementFailed, recoveryAttempted)
        If recoveryAttempted Then
            Call TryHoldClearEventsStopped(convergenceDetail)
            Err.Raise vbObjectError + 5197, _
                "ClearRecoveryFatal/InitializeToolData", _
                recoveryStateDetail
        End If
    Else
        On Error Resume Next
        Err.Clear
        healthClass = ToolDataHealthClassification()
        If Err.Number <> 0 Or healthClass <> TOOL_HEALTH_NORMAL Then
            AppendClearLeaseDetail recoveryStateDetail, _
                "初期化開始前の案件状態を通常として確認できません。"
            requiresInspection = True
        End If
        Err.Clear
        On Error GoTo 0
        If requiresInspection Then _
            Call TryEnterClearRecoveryState( _
                "案件初期化開始前状態の確認失敗", recoveryStateDetail, _
                recoveryEnforcementFailed, recoveryAttempted)
        If recoveryAttempted Then
            Call TryHoldClearEventsStopped(convergenceDetail)
            Err.Raise vbObjectError + 5197, _
                "ClearRecoveryFatal/InitializeToolData", _
                recoveryStateDetail
        End If
    End If

    If requiresInspection Then
        On Error Resume Next
        Err.Clear
        DisableInputKeys
        cleanupErrorNumber = Err.Number
        cleanupErrorDescription = Err.Description
        Err.Clear
        If cleanupErrorNumber <> 0 Then _
            AppendClearLeaseDetail recoveryStateDetail, _
                "入力キー停止に失敗: Err " & CStr(cleanupErrorNumber) & _
                " " & cleanupErrorDescription

        LogStep "エラー", "案件初期化/" & stepName, _
                "Err " & CStr(errorNumber), errorDescription
        cleanupErrorNumber = Err.Number
        cleanupErrorDescription = Err.Description
        Err.Clear
        If cleanupErrorNumber <> 0 Then _
            AppendClearLeaseDetail recoveryStateDetail, _
                "初期化ログ記録に失敗: Err " & CStr(cleanupErrorNumber) & _
                " " & cleanupErrorDescription

        AddCheck "エラー", "InitializeToolData", _
                 "工程: " & stepName & " / Err " & CStr(errorNumber) & ": " & _
                 errorDescription & recoveryStateDetail
        cleanupErrorNumber = Err.Number
        cleanupErrorDescription = Err.Description
        Err.Clear
        If cleanupErrorNumber <> 0 Then _
            AppendClearLeaseDetail recoveryStateDetail, _
                "診断記録に失敗: Err " & CStr(cleanupErrorNumber) & _
                " " & cleanupErrorDescription

        inspectionPrepared = PrepareFailedSetupForInspection()
        cleanupErrorNumber = Err.Number
        cleanupErrorDescription = Err.Description
        Err.Clear
        If cleanupErrorNumber <> 0 Or Not inspectionPrepared Then _
            AppendClearLeaseDetail recoveryStateDetail, _
                "診断画面の固定を確認できません" & _
                IIf(cleanupErrorNumber <> 0, ": Err " & CStr(cleanupErrorNumber) & _
                    " " & cleanupErrorDescription, ".")
        On Error GoTo 0
    Else
        On Error Resume Next
        Err.Clear
        ProtectInputSheet
        cleanupErrorNumber = Err.Number
        cleanupErrorDescription = Err.Description
        Err.Clear
        If cleanupErrorNumber <> 0 Then
            AppendClearLeaseDetail recoveryStateDetail, _
                "入力シート再保護に失敗: Err " & CStr(cleanupErrorNumber) & _
                " " & cleanupErrorDescription
            requiresInspection = True
        End If
        If Not requiresInspection Then
            If TypeName(ActiveSheet) = "Worksheet" Then
                If ActiveSheet.Name = SH_INPUT Then EnableInputKeys Else DisableInputKeys
            Else
                DisableInputKeys
            End If
            cleanupErrorNumber = Err.Number
            cleanupErrorDescription = Err.Description
            Err.Clear
            If cleanupErrorNumber <> 0 Then
                AppendClearLeaseDetail recoveryStateDetail, _
                    "入力キー状態の復元に失敗: Err " & CStr(cleanupErrorNumber) & _
                    " " & cleanupErrorDescription
                requiresInspection = True
            End If
        End If
        On Error GoTo 0
        If requiresInspection Then _
            Call TryEnterClearRecoveryState( _
                "案件初期化の後処理失敗", recoveryStateDetail, _
                recoveryEnforcementFailed, recoveryAttempted)
        If recoveryAttempted Then
            Call TryHoldClearEventsStopped(convergenceDetail)
            Err.Raise vbObjectError + 5197, _
                "ClearRecoveryFatal/InitializeToolData", _
                recoveryStateDetail
        End If
    End If

    'Recovery・診断・保護・キーを先に終え、Application leaseと開始時イベントを最後に戻す。
    Call TryFinalizeClearApplicationLease( _
        appStarted, entryEventsCaptured, entryEvents, "案件初期化の異常終了", _
        leaseDetail, recoveryAttempted)
    MsgBox "初期化は完了していません。" & vbCrLf & _
           "工程: " & stepName & vbCrLf & _
           "Err " & errorNumber & ": " & errorDescription & _
           recoveryStateDetail & leaseDetail & _
           IIf(Len(backupPath) > 0, vbCrLf & "初期化前バックアップ: " & backupPath & vbCrLf & _
               "復旧する場合は、このブックを上書き保存せず閉じてバックアップを開いてください。" & vbCrLf & _
               "診断内容を残す場合は［名前を付けて保存］を使用してください。", ""), _
           vbCritical, "初期化エラー"
End Sub

Public Function CreateInitializationBackup() As String
    Dim folderPath As String, fileName As String, baseName As String, extensionText As String
    Dim dotPos As Long, backupPath As String, suffixNo As Long
    folderPath = ThisWorkbook.Path
    If Len(folderPath) = 0 Then
        Err.Raise vbObjectError + 1902, "CreateInitializationBackup", _
                  "初期化前バックアップを作れません。先にこのツールブックを保存してください。"
    End If
    If IsWebUrlPath(folderPath) Then _
        Err.Raise vbObjectError + 1906, "CreateInitializationBackup", _
                  "SharePoint/TeamsのURLへ初期化前バックアップを直接作成できません。" & vbCrLf & _
                  "［名前を付けて保存］で同期済みのローカルフォルダーへ.xlsm形式で保存してから、" & _
                  "初期化を実行してください。"
    fileName = ThisWorkbook.Name
    dotPos = InStrRev(fileName, ".")
    If dotPos > 1 Then
        baseName = Left$(fileName, dotPos - 1)
        extensionText = Mid$(fileName, dotPos)
    Else
        baseName = fileName
        extensionText = ".xlsm"
    End If
    backupPath = folderPath & Application.PathSeparator & baseName & _
                 "_初期化前バックアップ_" & Format$(Now, "yyyymmdd_hhnnss") & extensionText
    If Len(backupPath) > 218 Then
        Err.Raise vbObjectError + 1905, "CreateInitializationBackup", _
                  "初期化前バックアップの完全パスが218文字を超えます。" & vbCrLf & _
                  "このツールブックを、より浅いフォルダーへ移動してから初期化してください。" & _
                  vbCrLf & backupPath
    End If
    Do While Len(Dir$(backupPath)) > 0
        suffixNo = suffixNo + 1
        backupPath = folderPath & Application.PathSeparator & baseName & _
                     "_初期化前バックアップ_" & Format$(Now, "yyyymmdd_hhnnss") & _
                     "_" & CStr(suffixNo) & extensionText
        If Len(backupPath) > 218 Then
            Err.Raise vbObjectError + 1905, "CreateInitializationBackup", _
                      "初期化前バックアップの完全パスが218文字を超えます。" & vbCrLf & _
                      "このツールブックを、より浅いフォルダーへ移動してください。"
        End If
    Loop
    ThisWorkbook.SaveCopyAs backupPath
    If Len(Dir$(backupPath)) = 0 Then
        Err.Raise vbObjectError + 1903, "CreateInitializationBackup", "初期化前バックアップの作成を確認できません。"
    End If
    If FileLen(backupPath) <= 0 Then
        Err.Raise vbObjectError + 1904, "CreateInitializationBackup", "初期化前バックアップのファイルサイズが0です。"
    End If
    CreateInitializationBackup = backupPath
End Function

Public Sub ResetCaseSpecificSettings()
    '相続開始日と残高表示期間は案件固有。前案件の値を新案件へ持ち越さない。
    Dim ws As Worksheet
    Set ws = GetSheet(SH_CONFIG)
    ws.Cells(ROW_CFG_INHERITANCE_DATE, COL_CFG_VALUE).ClearContents
    ws.Cells(ROW_CFG_INHERITANCE_DATE, COL_CFG_VALUE).NumberFormatLocal = "yyyy/m/d"
    ws.Cells(ROW_CFG_INHERITANCE_DATE, COL_CFG_VALUE).Interior.Color = RGB(254, 249, 195)
    ws.Cells(ROW_CFG_BAL_START_YEAR, COL_CFG_VALUE).Value = Year(Date) - 4
    ws.Cells(ROW_CFG_BAL_END_YEAR, COL_CFG_VALUE).Value = Year(Date)
    MarkOutputsDirty
End Sub

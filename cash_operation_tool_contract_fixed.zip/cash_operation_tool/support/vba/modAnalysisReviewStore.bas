﻿Attribute VB_Name = "modAnalysisReviewStore"
Option Explicit

'自動候補表は分析条件により行自体が消える。判断台帳を候補表から独立させ、
'候補が一時的に消えても確認状況・メモ・当時の根拠を失わないようにする。

Private mReviewPersistActive As Boolean
Private mReviewStoreNextRow As Long
Private mReviewHistoryNextRow As Long
Private mReviewCommitStamp As Date
Private mReviewCommitUser As String
Private mReviewActualStoreAdds As Long
Private mReviewActualHistoryAdds As Long
Private mAllocationBatchActive As Boolean

'W_分析判断台帳のA:Mは既存の候補判断台帳として固定する。N列を境界として空け、
'O:Xに配賦1件=1行の独立元帳を置く。新しいシートや既存A:Mの行意味を増やさない。
Private Const ALLOC_LEDGER_FIRST_COL As Long = 15       'O
Private Const ALLOC_LEDGER_COL_AMOUNT As Long = 19
Private Const ALLOC_LEDGER_COL_SOURCE_AMOUNT As Long = 23
Private Const ALLOC_LEDGER_COL_UPDATED_AT As Long = 24  'X
Private Const ALLOC_LEDGER_LAST_COL As Long = ALLOC_LEDGER_COL_UPDATED_AT
Private Const ALLOC_LEDGER_COLUMN_COUNT As Long = 10
Private Const ALLOC_DATA_COL_ID As Long = 1
Private Const ALLOC_DATA_COL_CANDIDATE_KEY As Long = 2
Private Const ALLOC_DATA_COL_TRANSACTION_ID As Long = 3
Private Const ALLOC_DATA_COL_DIRECTION As Long = 4
Private Const ALLOC_DATA_COL_AMOUNT As Long = 5
Private Const ALLOC_DATA_COL_STATUS As Long = 6
Private Const ALLOC_DATA_COL_EVIDENCE As Long = 7
Private Const ALLOC_DATA_COL_SOURCE_TYPE As Long = 8
Private Const ALLOC_DATA_COL_SOURCE_AMOUNT As Long = 9
Private Const ALLOC_DATA_COL_UPDATED_AT As Long = 10

Private Const ALLOC_INPUT_COL_CANDIDATE_KEY As Long = 1
Private Const ALLOC_INPUT_COL_TRANSACTION_ID As Long = 2
Private Const ALLOC_INPUT_COL_DIRECTION As Long = 3
Private Const ALLOC_INPUT_COL_AMOUNT As Long = 4
Private Const ALLOC_INPUT_COL_STATUS As Long = 5
Private Const ALLOC_INPUT_COL_EVIDENCE As Long = 6
Private Const ALLOC_INPUT_COL_SOURCE_TYPE As Long = 7
Private Const ALLOC_INPUT_COL_SOURCE_AMOUNT As Long = 8
Private Const ALLOC_INPUT_COLUMN_COUNT As Long = 8

Public Const ALLOCATION_DIRECTION_WITHDRAW As String = "WITHDRAW"
Public Const ALLOCATION_DIRECTION_DEPOSIT As String = "DEPOSIT"
Public Const ALLOCATION_STATUS_CONFIRMED As String = "CONFIRMED"
Public Const ALLOCATION_STATUS_REVIEW_REQUIRED As String = "REVIEW_REQUIRED"
Public Const ALLOCATION_STATUS_EXCLUDED As String = "EXCLUDED"
Public Const ALLOCATION_STATUS_UNREVIEWED As String = "UNREVIEWED"
Public Const ALLOCATION_STATUS_UNTRACKED As String = "UNTRACKED"
Public Const ALLOCATION_SOURCE_RESIDUAL As String = "RESIDUAL"
Public Const ALLOCATION_SOURCE_RESIDUAL_LOT As String = "RESIDUAL_LOT"
Public Const ALLOCATION_SOURCE_SCOPE As String = "SCOPE"

Public Function AnalysisReviewStoreHeaders() As Variant
    AnalysisReviewStoreHeaders = Array( _
        "候補キー", "元表", "区分", "確認状況", "確認メモ", "根拠署名", _
        "構成取引ID", "更新日時", "現行状態", "前回確認状況", "前回根拠署名", _
        "変更理由", "確認者")
End Function

Public Function AnalysisReviewHistoryHeaders() As Variant
    AnalysisReviewHistoryHeaders = Array( _
        "履歴ID", "候補キー", "変更日時", "確認者", "元表", "区分", _
        "旧確認状況", "新確認状況", "旧確認メモ", "新確認メモ", _
        "旧根拠署名", "新根拠署名", "変更理由")
End Function

Public Function AllocationLedgerHeaders() As Variant
    AllocationLedgerHeaders = Array( _
        "AllocationID", "CandidateKey", "TransactionID", "Direction", _
        "AllocatedAmount", "DecisionStatus", "EvidenceDigest", "SourceType", _
        "SourceAmount", "UpdatedAt")
End Function

Public Sub SetupAnalysisReviewStores(Optional ByVal resetContents As Boolean = False)
    PrepareAnalysisReviewStoreSheet GetOrCreateSheet(SH_WORK_ANALYSIS_REVIEW, False), _
                                    resetContents, AnalysisReviewStoreHeaders(), _
                                    ANALYSIS_REVIEW_STORE_LAST_COL
    PrepareAnalysisReviewStoreSheet GetOrCreateSheet(SH_WORK_ANALYSIS_HISTORY, False), _
                                    resetContents, AnalysisReviewHistoryHeaders(), _
                                    ANALYSIS_HISTORY_STORE_LAST_COL
    SetupAllocationLedger resetContents
End Sub

Public Sub SetupAllocationLedger(Optional ByVal resetContents As Boolean = False)
    Dim ws As Worksheet
    Set ws = GetSheet(SH_WORK_ANALYSIS_REVIEW)
    If resetContents Then _
        ws.Range(ws.Cells(1, ALLOC_LEDGER_FIRST_COL), _
                 ws.Cells(ws.Rows.Count, ALLOC_LEDGER_LAST_COL)).ClearContents
    If Len(CellText(ws.Cells(1, ALLOC_LEDGER_FIRST_COL).Value2)) = 0 Then _
        SetRowValues ws.Cells(1, ALLOC_LEDGER_FIRST_COL), AllocationLedgerHeaders()
    ws.Range(ws.Cells(1, ALLOC_LEDGER_FIRST_COL), _
             ws.Cells(1, ALLOC_LEDGER_LAST_COL)).Font.Bold = True
    ws.Range(ws.Cells(1, ALLOC_LEDGER_FIRST_COL), _
             ws.Cells(1, ALLOC_LEDGER_LAST_COL)).Interior.Color = RGB(68, 114, 196)
    ws.Range(ws.Cells(1, ALLOC_LEDGER_FIRST_COL), _
             ws.Cells(1, ALLOC_LEDGER_LAST_COL)).Font.Color = vbWhite
    ws.Range(ws.Cells(1, ALLOC_LEDGER_FIRST_COL), _
             ws.Cells(ws.Rows.Count, ALLOC_LEDGER_LAST_COL)).NumberFormatLocal = "@"
    ws.Columns(ALLOC_LEDGER_COL_AMOUNT).NumberFormatLocal = "#,##0.########"
    ws.Columns(ALLOC_LEDGER_COL_SOURCE_AMOUNT).NumberFormatLocal = "#,##0.########"
    ws.Columns(ALLOC_LEDGER_COL_UPDATED_AT).NumberFormatLocal = "yyyy/m/d h:mm:ss"
    SetSheetVeryHiddenSafe ws
End Sub

Public Sub CommitAllocationBatch(ByVal rows As Variant, _
                                 Optional ByVal sourceType As String = "", _
                                 Optional ByVal evidenceDigest As String = "")
    '候補単位の増分確定。同じ取引・方向にある別候補は保持する。
    CommitAllocationBatchCore rows, sourceType, evidenceDigest, False, False
End Sub

Public Sub ReplaceAllocationPlanForTransactions( _
        ByVal rows As Variant, Optional ByVal sourceType As String = "", _
        Optional ByVal evidenceDigest As String = "", _
        Optional ByVal replaceEntireLedger As Boolean = False)
    '全分析再構築専用。rowsに含めた取引・方向の旧候補を全て外し、
    '新しいplanと残差へ一括置換する。配賦0件の対象はSourceType=SCOPEの
    '制御行で明示する。SCOPE行自体は元帳へ保存しない。W_取引全体を
    '再構築する場合はreplaceEntireLedger=Trueとし、削除済み旧取引も残さない。
    CommitAllocationBatchCore rows, sourceType, evidenceDigest, True, _
                              replaceEntireLedger
End Sub

Public Sub ClearAnalysisAllocationPlan()
    'W_取引が0件になった全分析再構築専用。旧取引の配賦を残さず、
    'O:Xだけを同一snapshotから消去・読戻し・検証する。
    Dim ws As Worksheet, ledgerProblems As String
    Dim snapshot As Variant, snapshotLastRow As Long
    Dim writeStarted As Boolean, rollbackVerified As Boolean
    Dim errorNumber As Long, errorDescription As String, rollbackDetail As String

    If mAllocationBatchActive Then _
        Err.Raise vbObjectError + 4998, "ClearAnalysisAllocationPlan", _
                  "配賦元帳の更新処理が既に実行中です。"
    On Error GoTo EH
    mAllocationBatchActive = True
    Set ws = GetSheet(SH_WORK_ANALYSIS_REVIEW)
    If Not ValidateAllocationLedgerSheet(ws, ledgerProblems) Then _
        Err.Raise vbObjectError + 4999, "ClearAnalysisAllocationPlan", _
                  "既存の配賦元帳が不正です: " & ledgerProblems
    CaptureAllocationLedgerSnapshot ws, snapshot, snapshotLastRow
    If snapshotLastRow >= 2 Then
        writeStarted = True
        ws.Range(ws.Cells(2, ALLOC_LEDGER_FIRST_COL), _
                 ws.Cells(snapshotLastRow, ALLOC_LEDGER_LAST_COL)).ClearContents
        If AllocationLedgerLastRow(ws) <> 1 Then _
            Err.Raise vbObjectError + 5000, "ClearAnalysisAllocationPlan", _
                      "配賦元帳の消去後行数が一致しません。"
        ledgerProblems = vbNullString
        If Not ValidateAllocationLedgerSheet(ws, ledgerProblems) Then _
            Err.Raise vbObjectError + 5001, "ClearAnalysisAllocationPlan", _
                      "配賦元帳の消去後検証に失敗しました: " & ledgerProblems
        MarkOutputsDirty
    End If
    SetSheetVeryHiddenSafe ws
    If Not AllocationLedgerIsVeryHidden(ws) Then _
        Err.Raise vbObjectError + 5002, "ClearAnalysisAllocationPlan", _
                  "配賦元帳を内部非表示へ戻せません。"
    mAllocationBatchActive = False
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    If writeStarted Then
        rollbackVerified = TryRollbackAllocationLedger( _
                               ws, snapshot, snapshotLastRow, rollbackDetail)
        If Not rollbackVerified Then _
            AppendAnalysisReviewRollbackDetail rollbackDetail, _
                "共通Recoveryの所有権を外側の取引分析transactionへ伝播しました。"
    End If
    mAllocationBatchActive = False
    If Len(rollbackDetail) > 0 Then _
        errorDescription = errorDescription & " / ロールバック確認: " & rollbackDetail
    Err.Raise errorNumber, "ClearAnalysisAllocationPlan", errorDescription
End Sub

Private Sub CommitAllocationBatchCore( _
        ByVal rows As Variant, ByVal sourceType As String, _
        ByVal evidenceDigest As String, ByVal replaceAllGroups As Boolean, _
        ByVal replaceEntireLedger As Boolean)
    'rowsは8列: CandidateKey, TransactionID, Direction, AllocatedAmount,
    'DecisionStatus, EvidenceDigest, SourceType, SourceAmount。
    '一候補または一操作に含まれる全取引を、一つのsnapshotから一括確定する。
    Dim ws As Worksheet
    Dim firstInputRow As Long, lastInputRow As Long, inputRowCount As Long
    Dim firstInputCol As Long, lastInputCol As Long, inputColumnCount As Long
    Dim inputRow As Long, normalizedRow As Long, componentRow As Long, c As Long
    Dim normalized() As Variant
    Dim candidateKey As String, transactionID As String, directionText As String
    Dim statusText As String, rowEvidence As String, rowSourceType As String
    Dim allocatedAmount As Double, sourceAmount As Double
    Dim groupKey As String, candidateGroupKey As String, item As Variant
    Dim componentItem As Variant, componentIDs As Variant
    Dim isResidualLot As Boolean, isScopeRow As Boolean
    Dim affectedGroups As Object, sourceAmounts As Object
    Dim confirmedTotals As Object, proposedTotals As Object, seenCandidates As Object
    Dim affectedCandidates As Object, residualLotRows As Object
    Dim ledgerProblems As String
    Dim snapshot As Variant, snapshotLastRow As Long, oldRows As Long
    Dim oldData As Variant, outputData As Variant
    Dim retainedRows As Long, outputRows As Long, writeRow As Long
    Dim persistedInputRows As Long
    Dim retainRow As Boolean
    Dim allocationID As String, idSet As Object
    Dim residualAmount As Double, commitStamp As Date
    Dim lotSourceTotal As Double, lotResidualAvailable As Double, lotAmount As Double
    Dim writeStarted As Boolean, rollbackVerified As Boolean
    Dim errorNumber As Long, errorDescription As String, rollbackDetail As String

    If mAllocationBatchActive Then _
        Err.Raise vbObjectError + 4931, "CommitAllocationBatch", _
                  "配賦元帳の更新処理が既に実行中です。"
    If Not AllocationBatchShape(rows, firstInputRow, lastInputRow, _
            firstInputCol, lastInputCol) Then _
        Err.Raise vbObjectError + 4932, "CommitAllocationBatch", _
                  "配賦バッチは8列の二次元配列で指定してください。"
    inputRowCount = lastInputRow - firstInputRow + 1
    inputColumnCount = lastInputCol - firstInputCol + 1
    If inputRowCount < 1 Or inputColumnCount <> ALLOC_INPUT_COLUMN_COUNT Then _
        Err.Raise vbObjectError + 4932, "CommitAllocationBatch", _
                  "配賦バッチの行数または列数が不正です。"
    If inputRowCount > MAX_INTERNAL_STORE_DATA_ROWS Then _
        Err.Raise vbObjectError + 4933, "CommitAllocationBatch", _
                  "配賦バッチが保存上限を超えています。"

    Set affectedGroups = CreateObject("Scripting.Dictionary")
    affectedGroups.CompareMode = vbBinaryCompare
    Set sourceAmounts = CreateObject("Scripting.Dictionary")
    sourceAmounts.CompareMode = vbBinaryCompare
    Set confirmedTotals = CreateObject("Scripting.Dictionary")
    confirmedTotals.CompareMode = vbBinaryCompare
    Set proposedTotals = CreateObject("Scripting.Dictionary")
    proposedTotals.CompareMode = vbBinaryCompare
    Set seenCandidates = CreateObject("Scripting.Dictionary")
    seenCandidates.CompareMode = vbBinaryCompare
    Set affectedCandidates = CreateObject("Scripting.Dictionary")
    affectedCandidates.CompareMode = vbBinaryCompare
    Set residualLotRows = CreateObject("Scripting.Dictionary")
    residualLotRows.CompareMode = vbBinaryCompare
    ReDim normalized(1 To inputRowCount, 1 To ALLOC_INPUT_COLUMN_COUNT)

    sourceType = Trim$(sourceType)
    evidenceDigest = Trim$(evidenceDigest)
    For inputRow = firstInputRow To lastInputRow
        normalizedRow = inputRow - firstInputRow + 1
        candidateKey = AllocationRequiredText( _
            rows(inputRow, firstInputCol + ALLOC_INPUT_COL_CANDIDATE_KEY - 1), _
            "CandidateKey")
        transactionID = AllocationRequiredText( _
            rows(inputRow, firstInputCol + ALLOC_INPUT_COL_TRANSACTION_ID - 1), _
            "TransactionID")
        directionText = UCase$(AllocationRequiredText( _
            rows(inputRow, firstInputCol + ALLOC_INPUT_COL_DIRECTION - 1), _
            "Direction"))
        If Not AllocationDirectionIsValid(directionText) Then _
            Err.Raise vbObjectError + 4934, "CommitAllocationBatch", _
                      "DirectionはWITHDRAWまたはDEPOSITで指定してください: " & directionText
        allocatedAmount = AllocationRequiredAmount( _
            rows(inputRow, firstInputCol + ALLOC_INPUT_COL_AMOUNT - 1), _
            "AllocatedAmount")
        statusText = UCase$(AllocationRequiredText( _
            rows(inputRow, firstInputCol + ALLOC_INPUT_COL_STATUS - 1), _
            "DecisionStatus"))
        If Not AllocationInputStatusIsValid(statusText) Then _
            Err.Raise vbObjectError + 4935, "CommitAllocationBatch", _
                      "DecisionStatusが不正です: " & statusText
        rowEvidence = Trim$(CellText(rows(inputRow, _
            firstInputCol + ALLOC_INPUT_COL_EVIDENCE - 1)))
        If Len(rowEvidence) = 0 Then rowEvidence = evidenceDigest
        rowSourceType = Trim$(CellText(rows(inputRow, _
            firstInputCol + ALLOC_INPUT_COL_SOURCE_TYPE - 1)))
        If Len(rowSourceType) = 0 Then rowSourceType = sourceType
        rowSourceType = AllocationRequiredText(rowSourceType, "SourceType")
        If StrComp(rowSourceType, ALLOCATION_SOURCE_RESIDUAL_LOT, vbTextCompare) = 0 Then _
            rowSourceType = ALLOCATION_SOURCE_RESIDUAL_LOT
        If StrComp(rowSourceType, ALLOCATION_SOURCE_SCOPE, vbTextCompare) = 0 Then _
            rowSourceType = ALLOCATION_SOURCE_SCOPE
        If StrComp(rowSourceType, ALLOCATION_SOURCE_RESIDUAL, vbTextCompare) = 0 Then _
            Err.Raise vbObjectError + 4937, "CommitAllocationBatch", _
                      "入力配賦のSourceTypeにRESIDUALは指定できません。"
        sourceAmount = AllocationRequiredAmount( _
            rows(inputRow, firstInputCol + ALLOC_INPUT_COL_SOURCE_AMOUNT - 1), _
            "SourceAmount")
        If allocatedAmount > sourceAmount + AllocationTolerance(sourceAmount) Then _
            Err.Raise vbObjectError + 4938, "CommitAllocationBatch", _
                      "配賦額が元金額を超えています: " & transactionID
        isResidualLot = (StrComp(rowSourceType, ALLOCATION_SOURCE_RESIDUAL_LOT, _
                                 vbBinaryCompare) = 0)
        isScopeRow = (StrComp(rowSourceType, ALLOCATION_SOURCE_SCOPE, _
                             vbBinaryCompare) = 0)
        If Not isScopeRow And Not ReviewEvidenceDigestIsValid(rowEvidence) Then _
            Err.Raise vbObjectError + 4936, "CommitAllocationBatch", _
                      "EvidenceDigestが不正です: " & candidateKey
        If isScopeRow Then
            If Not replaceAllGroups Then _
                Err.Raise vbObjectError + 4937, "CommitAllocationBatch", _
                          "SCOPE制御行は全分析置換APIだけで指定できます。"
            If allocatedAmount <> 0# Or statusText <> ALLOCATION_STATUS_UNREVIEWED Then _
                Err.Raise vbObjectError + 4939, "CommitAllocationBatch", _
                          "SCOPE制御行は0円・UNREVIEWEDで指定してください。"
            rowEvidence = vbNullString
        End If
        If isResidualLot Then
            If statusText <> ALLOCATION_STATUS_REVIEW_REQUIRED Then _
                Err.Raise vbObjectError + 4939, "CommitAllocationBatch", _
                          "RESIDUAL_LOTはREVIEW_REQUIREDでなければなりません。"
            transactionID = CanonicalResidualLotTransactionIDs(transactionID)
            residualLotRows.Add CStr(normalizedRow), transactionID
        ElseIf (statusText = ALLOCATION_STATUS_EXCLUDED Or _
            statusText = ALLOCATION_STATUS_UNREVIEWED) And allocatedAmount <> 0# Then _
            Err.Raise vbObjectError + 4939, "CommitAllocationBatch", _
                      "EXCLUDEDまたはUNREVIEWEDの配賦額は0でなければなりません。"
        End If

        If Not isScopeRow Then
            persistedInputRows = persistedInputRows + 1
            If Not affectedCandidates.Exists(candidateKey) Then _
                affectedCandidates.Add candidateKey, True
        End If
        If Not isResidualLot Then
            groupKey = AllocationGroupKey(transactionID, directionText)
            If Not affectedGroups.Exists(groupKey) Then
                affectedGroups.Add groupKey, True
                sourceAmounts.Add groupKey, sourceAmount
                confirmedTotals.Add groupKey, 0#
                proposedTotals.Add groupKey, 0#
            ElseIf Not AllocationAmountsMatch(CDbl(sourceAmounts(groupKey)), sourceAmount) Then
                Err.Raise vbObjectError + 4940, "CommitAllocationBatch", _
                          "同じ取引・方向のSourceAmountが一致しません: " & transactionID
            End If
            If Not isScopeRow Then
                candidateGroupKey = groupKey & ChrW$(30) & candidateKey
                If seenCandidates.Exists(candidateGroupKey) Then _
                    Err.Raise vbObjectError + 4941, "CommitAllocationBatch", _
                              "同じ取引・方向・候補の配賦が重複しています: " & candidateKey
                seenCandidates.Add candidateGroupKey, normalizedRow
                proposedTotals(groupKey) = CDbl(proposedTotals(groupKey)) + allocatedAmount
                If statusText = ALLOCATION_STATUS_CONFIRMED Then _
                    confirmedTotals(groupKey) = CDbl(confirmedTotals(groupKey)) + allocatedAmount
            End If
        End If

        normalized(normalizedRow, ALLOC_INPUT_COL_CANDIDATE_KEY) = candidateKey
        normalized(normalizedRow, ALLOC_INPUT_COL_TRANSACTION_ID) = transactionID
        normalized(normalizedRow, ALLOC_INPUT_COL_DIRECTION) = directionText
        normalized(normalizedRow, ALLOC_INPUT_COL_AMOUNT) = allocatedAmount
        normalized(normalizedRow, ALLOC_INPUT_COL_STATUS) = statusText
        normalized(normalizedRow, ALLOC_INPUT_COL_EVIDENCE) = rowEvidence
        normalized(normalizedRow, ALLOC_INPUT_COL_SOURCE_TYPE) = rowSourceType
        normalized(normalizedRow, ALLOC_INPUT_COL_SOURCE_AMOUNT) = sourceAmount
    Next inputRow
    '曖昧なn:n候補はResidualLotだけで元額を消さない。同じatomic batch内に、
    '全構成取引の0円REVIEW_REQUIRED行を要求し、各取引の残差を満額生成する。
    For Each item In residualLotRows.Keys
        normalizedRow = CLng(item)
        componentIDs = Split(CStr(residualLotRows(CStr(item))), ";")
        directionText = CStr(normalized(normalizedRow, ALLOC_INPUT_COL_DIRECTION))
        For Each componentItem In componentIDs
            groupKey = AllocationGroupKey(CStr(componentItem), directionText)
            If Not affectedGroups.Exists(groupKey) Then _
                Err.Raise vbObjectError + 4942, "CommitAllocationBatch", _
                          "RESIDUAL_LOTの全構成取引を同じbatchへ含めてください: " & _
                          CStr(componentItem)
            candidateGroupKey = groupKey & ChrW$(30) & _
                                CStr(normalized(normalizedRow, _
                                      ALLOC_INPUT_COL_CANDIDATE_KEY))
            If Not seenCandidates.Exists(candidateGroupKey) Then _
                Err.Raise vbObjectError + 4942, "CommitAllocationBatch", _
                          "RESIDUAL_LOT構成取引の候補別0円行がありません: " & _
                          CStr(componentItem)
            componentRow = CLng(seenCandidates(candidateGroupKey))
            If CDbl(normalized(componentRow, ALLOC_INPUT_COL_AMOUNT)) <> 0# Or _
               CStr(normalized(componentRow, ALLOC_INPUT_COL_STATUS)) <> _
                   ALLOCATION_STATUS_REVIEW_REQUIRED Then _
                Err.Raise vbObjectError + 4942, "CommitAllocationBatch", _
                          "RESIDUAL_LOT構成取引は0円・REVIEW_REQUIREDで指定してください: " & _
                          CStr(componentItem)
            If CDbl(confirmedTotals(groupKey)) <> 0# Or _
               CDbl(proposedTotals(groupKey)) <> 0# Then _
                Err.Raise vbObjectError + 4942, "CommitAllocationBatch", _
                          "RESIDUAL_LOT構成取引のactive配賦は0でなければなりません: " & _
                          CStr(componentItem)
        Next componentItem
    Next item
    For Each item In affectedGroups.Keys
        groupKey = CStr(item)
        sourceAmount = CDbl(sourceAmounts(groupKey))
        If CDbl(confirmedTotals(groupKey)) > _
           sourceAmount + AllocationTolerance(sourceAmount) Then _
            Err.Raise vbObjectError + 4942, "CommitAllocationBatch", _
                      "確定配賦合計が元金額を超えています: " & groupKey
        If CDbl(proposedTotals(groupKey)) > _
           sourceAmount + AllocationTolerance(sourceAmount) Then _
            Err.Raise vbObjectError + 4943, "CommitAllocationBatch", _
                      "提案中を含む配賦合計が元金額を超えています: " & groupKey
    Next item

    On Error GoTo EH
    mAllocationBatchActive = True
    Set ws = GetSheet(SH_WORK_ANALYSIS_REVIEW)
    If Not ValidateAllocationLedgerSheet(ws, ledgerProblems) Then _
        Err.Raise vbObjectError + 4944, "CommitAllocationBatch", _
                  "既存の配賦元帳が不正です: " & ledgerProblems
    CaptureAllocationLedgerSnapshot ws, snapshot, snapshotLastRow
    oldRows = snapshotLastRow - 1
    If oldRows > 0 Then oldData = snapshot
    '同じ取引へ後から別候補を確定しても、既存の別候補配賦を消さない。
    '置換対象は「今回batchに含まれる候補×取引・方向」だけとし、残る候補額を
    '合計へ加えた後で超過と残差を再計算する。
    If Not replaceAllGroups Then
        For inputRow = 1 To oldRows
            rowSourceType = CellText(oldData(inputRow, ALLOC_DATA_COL_SOURCE_TYPE))
            If rowSourceType <> ALLOCATION_SOURCE_RESIDUAL And _
               rowSourceType <> ALLOCATION_SOURCE_RESIDUAL_LOT Then
                groupKey = AllocationGroupKey( _
                    CellText(oldData(inputRow, ALLOC_DATA_COL_TRANSACTION_ID)), _
                    CellText(oldData(inputRow, ALLOC_DATA_COL_DIRECTION)))
                candidateKey = CellText(oldData(inputRow, ALLOC_DATA_COL_CANDIDATE_KEY))
                candidateGroupKey = groupKey & ChrW$(30) & candidateKey
                If affectedGroups.Exists(groupKey) And _
                   Not seenCandidates.Exists(candidateGroupKey) Then
                    sourceAmount = CDbl(oldData(inputRow, ALLOC_DATA_COL_SOURCE_AMOUNT))
                    If Not AllocationAmountsMatch(CDbl(sourceAmounts(groupKey)), sourceAmount) Then _
                        Err.Raise vbObjectError + 4940, "CommitAllocationBatch", _
                                  "既存配賦とbatchのSourceAmountが一致しません: " & groupKey
                    allocatedAmount = CDbl(oldData(inputRow, ALLOC_DATA_COL_AMOUNT))
                    proposedTotals(groupKey) = CDbl(proposedTotals(groupKey)) + allocatedAmount
                    If CellText(oldData(inputRow, ALLOC_DATA_COL_STATUS)) = _
                       ALLOCATION_STATUS_CONFIRMED Then _
                        confirmedTotals(groupKey) = _
                            CDbl(confirmedTotals(groupKey)) + allocatedAmount
                End If
            End If
        Next inputRow
    End If
    For Each item In affectedGroups.Keys
        groupKey = CStr(item)
        sourceAmount = CDbl(sourceAmounts(groupKey))
        If CDbl(confirmedTotals(groupKey)) > _
           sourceAmount + AllocationTolerance(sourceAmount) Then _
            Err.Raise vbObjectError + 4942, "CommitAllocationBatch", _
                      "既存候補を含む確定配賦合計が元金額を超えています: " & groupKey
        If CDbl(proposedTotals(groupKey)) > _
           sourceAmount + AllocationTolerance(sourceAmount) Then _
            Err.Raise vbObjectError + 4943, "CommitAllocationBatch", _
                      "既存候補を含む提案配賦合計が元金額を超えています: " & groupKey
    Next item
    For Each item In residualLotRows.Keys
        normalizedRow = CLng(item)
        componentIDs = Split(CStr(residualLotRows(CStr(item))), ";")
        directionText = CStr(normalized(normalizedRow, ALLOC_INPUT_COL_DIRECTION))
        lotSourceTotal = 0#: lotResidualAvailable = 0#
        For Each componentItem In componentIDs
            groupKey = AllocationGroupKey(CStr(componentItem), directionText)
            lotSourceTotal = lotSourceTotal + CDbl(sourceAmounts(groupKey))
            lotResidualAvailable = lotResidualAvailable + _
                CDbl(sourceAmounts(groupKey)) - CDbl(confirmedTotals(groupKey))
        Next componentItem
        If Not AllocationAmountsMatch( _
                   CDbl(normalized(normalizedRow, ALLOC_INPUT_COL_SOURCE_AMOUNT)), _
                   lotSourceTotal) Then _
            Err.Raise vbObjectError + 4943, "CommitAllocationBatch", _
                      "RESIDUAL_LOTのSourceAmountは構成取引元額合計と一致させてください。"
        lotAmount = CDbl(normalized(normalizedRow, ALLOC_INPUT_COL_AMOUNT))
        If Not AllocationAmountsMatch(lotAmount, lotSourceTotal) Then _
            Err.Raise vbObjectError + 4943, "CommitAllocationBatch", _
                      "RESIDUAL_LOT額は構成取引元額合計の満額で指定してください。"
        If lotAmount > lotResidualAvailable + AllocationTolerance(lotSourceTotal) Then _
            Err.Raise vbObjectError + 4943, "CommitAllocationBatch", _
                      "RESIDUAL_LOT額が構成取引の未追跡残額合計を超えています。"
    Next item
    For inputRow = 1 To oldRows
        If replaceEntireLedger Then
            retainRow = False
        Else
            retainRow = AllocationExistingRowShouldBeRetained( _
                oldData, inputRow, affectedGroups, affectedCandidates, seenCandidates, _
                replaceAllGroups)
        End If
        If retainRow Then retainedRows = retainedRows + 1
    Next inputRow
    outputRows = retainedRows + persistedInputRows + affectedGroups.Count
    If outputRows < 1 Or outputRows > MAX_INTERNAL_STORE_DATA_ROWS Or _
       outputRows + 1 > ws.Rows.Count Then _
        Err.Raise vbObjectError + 4945, "CommitAllocationBatch", _
                  "配賦元帳の確定後行数が保存上限を超えます。"
    ReDim outputData(1 To outputRows, 1 To ALLOC_LEDGER_COLUMN_COUNT)
    Set idSet = CreateObject("Scripting.Dictionary")
    idSet.CompareMode = vbBinaryCompare
    For inputRow = 1 To oldRows
        If replaceEntireLedger Then
            retainRow = False
        Else
            retainRow = AllocationExistingRowShouldBeRetained( _
                oldData, inputRow, affectedGroups, affectedCandidates, seenCandidates, _
                replaceAllGroups)
        End If
        If retainRow Then
            writeRow = writeRow + 1
            For c = 1 To ALLOC_LEDGER_COLUMN_COUNT
                outputData(writeRow, c) = oldData(inputRow, c)
            Next c
            allocationID = CellText(outputData(writeRow, ALLOC_DATA_COL_ID))
            If idSet.Exists(allocationID) Then _
                Err.Raise vbObjectError + 4946, "CommitAllocationBatch", _
                          "既存AllocationIDが重複しています: " & allocationID
            idSet.Add allocationID, True
        End If
    Next inputRow
    commitStamp = Now
    For inputRow = 1 To inputRowCount
        candidateKey = CStr(normalized(inputRow, ALLOC_INPUT_COL_CANDIDATE_KEY))
        transactionID = CStr(normalized(inputRow, ALLOC_INPUT_COL_TRANSACTION_ID))
        directionText = CStr(normalized(inputRow, ALLOC_INPUT_COL_DIRECTION))
        rowSourceType = CStr(normalized(inputRow, ALLOC_INPUT_COL_SOURCE_TYPE))
        If rowSourceType = ALLOCATION_SOURCE_SCOPE Then GoTo NextAllocationInputRow
        writeRow = writeRow + 1
        If rowSourceType = ALLOCATION_SOURCE_RESIDUAL_LOT Then
            allocationID = StableResidualLotID(candidateKey, transactionID, directionText)
        Else
            allocationID = StableAllocationID(candidateKey, transactionID, directionText, False)
        End If
        If idSet.Exists(allocationID) Then _
            Err.Raise vbObjectError + 4947, "CommitAllocationBatch", _
                      "AllocationIDが衝突しています: " & allocationID
        idSet.Add allocationID, True
        outputData(writeRow, ALLOC_DATA_COL_ID) = allocationID
        outputData(writeRow, ALLOC_DATA_COL_CANDIDATE_KEY) = candidateKey
        outputData(writeRow, ALLOC_DATA_COL_TRANSACTION_ID) = transactionID
        outputData(writeRow, ALLOC_DATA_COL_DIRECTION) = directionText
        outputData(writeRow, ALLOC_DATA_COL_AMOUNT) = _
            CDbl(normalized(inputRow, ALLOC_INPUT_COL_AMOUNT))
        outputData(writeRow, ALLOC_DATA_COL_STATUS) = _
            CStr(normalized(inputRow, ALLOC_INPUT_COL_STATUS))
        outputData(writeRow, ALLOC_DATA_COL_EVIDENCE) = _
            CStr(normalized(inputRow, ALLOC_INPUT_COL_EVIDENCE))
        outputData(writeRow, ALLOC_DATA_COL_SOURCE_TYPE) = _
            CStr(normalized(inputRow, ALLOC_INPUT_COL_SOURCE_TYPE))
        outputData(writeRow, ALLOC_DATA_COL_SOURCE_AMOUNT) = _
            CDbl(normalized(inputRow, ALLOC_INPUT_COL_SOURCE_AMOUNT))
        outputData(writeRow, ALLOC_DATA_COL_UPDATED_AT) = CDbl(commitStamp)
NextAllocationInputRow:
    Next inputRow
    For Each item In affectedGroups.Keys
        groupKey = CStr(item)
        AllocationGroupParts groupKey, transactionID, directionText
        sourceAmount = CDbl(sourceAmounts(groupKey))
        residualAmount = sourceAmount - CDbl(confirmedTotals(groupKey))
        If Abs(residualAmount) <= AllocationTolerance(sourceAmount) Then residualAmount = 0#
        writeRow = writeRow + 1
        candidateKey = "UNTRACKED>" & transactionID & ">" & directionText
        allocationID = StableAllocationID(candidateKey, transactionID, directionText, True)
        If idSet.Exists(allocationID) Then _
            Err.Raise vbObjectError + 4947, "CommitAllocationBatch", _
                      "残差AllocationIDが衝突しています: " & allocationID
        idSet.Add allocationID, True
        outputData(writeRow, ALLOC_DATA_COL_ID) = allocationID
        outputData(writeRow, ALLOC_DATA_COL_CANDIDATE_KEY) = candidateKey
        outputData(writeRow, ALLOC_DATA_COL_TRANSACTION_ID) = transactionID
        outputData(writeRow, ALLOC_DATA_COL_DIRECTION) = directionText
        outputData(writeRow, ALLOC_DATA_COL_AMOUNT) = residualAmount
        outputData(writeRow, ALLOC_DATA_COL_STATUS) = ALLOCATION_STATUS_UNTRACKED
        outputData(writeRow, ALLOC_DATA_COL_EVIDENCE) = Empty
        outputData(writeRow, ALLOC_DATA_COL_SOURCE_TYPE) = ALLOCATION_SOURCE_RESIDUAL
        outputData(writeRow, ALLOC_DATA_COL_SOURCE_AMOUNT) = sourceAmount
        outputData(writeRow, ALLOC_DATA_COL_UPDATED_AT) = CDbl(commitStamp)
    Next item
    If writeRow <> outputRows Then _
        Err.Raise vbObjectError + 4948, "CommitAllocationBatch", _
                  "配賦元帳の事前件数と確定件数が一致しません。"
    If Not ValidateAllocationLedgerMatrix(outputData, outputRows, ledgerProblems) Then _
        Err.Raise vbObjectError + 4949, "CommitAllocationBatch", _
                  "配賦元帳の確定計画が不正です: " & ledgerProblems

    writeStarted = True
    WriteAllocationLedgerMatrix ws, outputData, outputRows, snapshotLastRow
    ledgerProblems = vbNullString
    If Not ValidateAllocationLedgerSheet(ws, ledgerProblems) Then _
        Err.Raise vbObjectError + 4950, "CommitAllocationBatch", _
                  "配賦元帳の書込後検証に失敗しました: " & ledgerProblems
    MarkOutputsDirty
    SetSheetVeryHiddenSafe ws
    If Not AllocationLedgerIsVeryHidden(ws) Then _
        Err.Raise vbObjectError + 4951, "CommitAllocationBatch", _
                  "配賦元帳を内部非表示へ戻せません。"
    mAllocationBatchActive = False
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    If writeStarted Then
        rollbackVerified = TryRollbackAllocationLedger( _
                               ws, snapshot, snapshotLastRow, rollbackDetail)
        If Not rollbackVerified Then _
            AppendAnalysisReviewRollbackDetail rollbackDetail, _
                "共通Recoveryの所有権を外側の取引分析transactionへ伝播しました。"
    End If
    mAllocationBatchActive = False
    If Len(rollbackDetail) > 0 Then _
        errorDescription = errorDescription & " / ロールバック確認: " & rollbackDetail
    Err.Raise errorNumber, "CommitAllocationBatch", errorDescription
End Sub

Private Function TryRollbackAllocationLedger( _
        ByVal ws As Worksheet, ByVal snapshot As Variant, _
        ByVal snapshotLastRow As Long, ByRef rollbackDetail As String) As Boolean
    On Error GoTo EH
    RestoreAllocationLedgerSnapshot ws, snapshot, snapshotLastRow
    TryRollbackAllocationLedger = True
    Exit Function
EH:
    rollbackDetail = "配賦元帳の復元エラー: Err " & _
                     CStr(Err.Number) & " " & Err.Description
    Err.Clear
End Function

Private Function AllocationBatchShape(ByVal rows As Variant, _
                                      ByRef firstRow As Long, ByRef lastRow As Long, _
                                      ByRef firstColumn As Long, ByRef lastColumn As Long) As Boolean
    On Error GoTo EH
    If Not IsArray(rows) Then Exit Function
    firstRow = LBound(rows, 1)
    lastRow = UBound(rows, 1)
    firstColumn = LBound(rows, 2)
    lastColumn = UBound(rows, 2)
    AllocationBatchShape = (lastRow >= firstRow And lastColumn >= firstColumn)
    Exit Function
EH:
    firstRow = 0: lastRow = -1
    firstColumn = 0: lastColumn = -1
    Err.Clear
End Function

Private Function AllocationRequiredText(ByVal valueIn As Variant, _
                                        ByVal labelText As String) As String
    Dim valueText As String
    If IsError(valueIn) Or IsNull(valueIn) Then _
        Err.Raise vbObjectError + 4952, "AllocationRequiredText", _
                  labelText & "にExcelエラーまたはNullがあります。"
    valueText = Trim$(CellText(valueIn))
    If Len(valueText) = 0 Or Len(valueText) > 3000 Then _
        Err.Raise vbObjectError + 4952, "AllocationRequiredText", _
                  labelText & "が空欄または長すぎます。"
    If InStr(1, valueText, ChrW$(31), vbBinaryCompare) > 0 Or _
       InStr(1, valueText, ChrW$(30), vbBinaryCompare) > 0 Then _
        Err.Raise vbObjectError + 4952, "AllocationRequiredText", _
                  labelText & "に内部区切り文字があります。"
    AllocationRequiredText = valueText
End Function

Private Function AllocationRequiredAmount(ByVal valueIn As Variant, _
                                          ByVal labelText As String) As Double
    Dim amountValue As Double
    If IsError(valueIn) Or IsNull(valueIn) Or IsEmpty(valueIn) Or _
       Not IsNumeric(valueIn) Then _
        Err.Raise vbObjectError + 4953, "AllocationRequiredAmount", _
                  labelText & "が数値ではありません。"
    amountValue = CDbl(valueIn)
    If amountValue < 0# Or amountValue > 1E+15 Or amountValue <> amountValue Then _
        Err.Raise vbObjectError + 4953, "AllocationRequiredAmount", _
                  labelText & "が許容範囲外です。"
    AllocationRequiredAmount = amountValue
End Function

Private Function AllocationDirectionIsValid(ByVal directionText As String) As Boolean
    AllocationDirectionIsValid = _
        (StrComp(directionText, ALLOCATION_DIRECTION_WITHDRAW, vbBinaryCompare) = 0 Or _
         StrComp(directionText, ALLOCATION_DIRECTION_DEPOSIT, vbBinaryCompare) = 0)
End Function

Private Function AllocationInputStatusIsValid(ByVal statusText As String) As Boolean
    Select Case statusText
        Case ALLOCATION_STATUS_CONFIRMED, ALLOCATION_STATUS_REVIEW_REQUIRED, _
             ALLOCATION_STATUS_EXCLUDED, ALLOCATION_STATUS_UNREVIEWED
            AllocationInputStatusIsValid = True
    End Select
End Function

Private Function AllocationTolerance(ByVal sourceAmount As Double) As Double
    Dim toleranceValue As Double
    toleranceValue = Abs(sourceAmount) * 0.0000000000005
    If toleranceValue < 0.00000001 Then toleranceValue = 0.00000001
    AllocationTolerance = toleranceValue
End Function

Private Function AllocationAmountsMatch(ByVal firstAmount As Double, _
                                        ByVal secondAmount As Double) As Boolean
    Dim scaleValue As Double
    scaleValue = Abs(firstAmount)
    If Abs(secondAmount) > scaleValue Then scaleValue = Abs(secondAmount)
    AllocationAmountsMatch = _
        (Abs(firstAmount - secondAmount) <= AllocationTolerance(scaleValue))
End Function

Private Function AllocationGroupKey(ByVal transactionID As String, _
                                    ByVal directionText As String) As String
    AllocationGroupKey = transactionID & ChrW$(31) & directionText
End Function

Private Sub AllocationGroupParts(ByVal groupKey As String, _
                                 ByRef transactionID As String, _
                                 ByRef directionText As String)
    Dim separatorPos As Long
    separatorPos = InStr(1, groupKey, ChrW$(31), vbBinaryCompare)
    If separatorPos < 2 Or separatorPos >= Len(groupKey) Then _
        Err.Raise vbObjectError + 4954, "AllocationGroupParts", _
                  "配賦グループキーを分解できません。"
    transactionID = Left$(groupKey, separatorPos - 1)
    directionText = Mid$(groupKey, separatorPos + 1)
End Sub

Private Function AllocationExistingRowShouldBeRetained( _
        ByRef oldData As Variant, ByVal dataRow As Long, _
        ByVal affectedGroups As Object, ByVal affectedCandidates As Object, _
        ByVal replacementKeys As Object, ByVal replaceAllGroups As Boolean) As Boolean
    Dim sourceType As String, candidateKey As String
    Dim transactionIDs As String, directionText As String, groupKey As String
    Dim candidateGroupKey As String
    sourceType = CellText(oldData(dataRow, ALLOC_DATA_COL_SOURCE_TYPE))
    candidateKey = CellText(oldData(dataRow, ALLOC_DATA_COL_CANDIDATE_KEY))
    transactionIDs = CellText(oldData(dataRow, ALLOC_DATA_COL_TRANSACTION_ID))
    directionText = CellText(oldData(dataRow, ALLOC_DATA_COL_DIRECTION))
    If sourceType = ALLOCATION_SOURCE_RESIDUAL_LOT Then
        If replaceAllGroups Then
            AllocationExistingRowShouldBeRetained = Not _
                ResidualLotAnyGroupAffected(transactionIDs, directionText, affectedGroups)
        ElseIf Not affectedCandidates.Exists(candidateKey) Then
            AllocationExistingRowShouldBeRetained = True
        Else
            '共同残差は全構成取引を同じbatchで置換する場合だけ旧lotを外す。
            AllocationExistingRowShouldBeRetained = Not _
                ResidualLotAllGroupsAffected(transactionIDs, directionText, affectedGroups)
        End If
        Exit Function
    End If
    groupKey = AllocationGroupKey(transactionIDs, directionText)
    If sourceType = ALLOCATION_SOURCE_RESIDUAL Then
        AllocationExistingRowShouldBeRetained = Not affectedGroups.Exists(groupKey)
    ElseIf replaceAllGroups Then
        AllocationExistingRowShouldBeRetained = Not affectedGroups.Exists(groupKey)
    Else
        candidateGroupKey = groupKey & ChrW$(30) & candidateKey
        AllocationExistingRowShouldBeRetained = _
            Not replacementKeys.Exists(candidateGroupKey)
    End If
End Function

Private Function ResidualLotAnyGroupAffected( _
        ByVal canonicalTransactionIDs As String, ByVal directionText As String, _
        ByVal affectedGroups As Object) As Boolean
    Dim parts As Variant, item As Variant
    parts = Split(CanonicalResidualLotTransactionIDs(canonicalTransactionIDs), ";")
    For Each item In parts
        If affectedGroups.Exists(AllocationGroupKey(CStr(item), directionText)) Then
            ResidualLotAnyGroupAffected = True
            Exit Function
        End If
    Next item
End Function

Private Function ResidualLotAllGroupsAffected( _
        ByVal canonicalTransactionIDs As String, ByVal directionText As String, _
        ByVal affectedGroups As Object) As Boolean
    Dim parts As Variant, item As Variant
    parts = Split(CanonicalResidualLotTransactionIDs(canonicalTransactionIDs), ";")
    For Each item In parts
        If Not affectedGroups.Exists(AllocationGroupKey(CStr(item), directionText)) Then _
            Exit Function
    Next item
    ResidualLotAllGroupsAffected = True
End Function

Private Function StableAllocationID(ByVal candidateKey As String, _
                                    ByVal transactionID As String, _
                                    ByVal directionText As String, _
                                    ByVal isResidual As Boolean) As String
    Dim rawText As String, idPrefix As String
    rawText = CStr(Len(transactionID)) & ":" & transactionID & "|" & _
              CStr(Len(directionText)) & ":" & directionText & "|" & _
              CStr(Len(candidateKey)) & ":" & candidateKey
    If isResidual Then idPrefix = "AR-" Else idPrefix = "AL-"
    StableAllocationID = idPrefix & _
        AllocationHashPart(rawText, 104729#, 257#) & "-" & _
        AllocationHashPart(rawText, 130363#, 263#)
End Function

Private Function StableResidualLotID(ByVal candidateKey As String, _
                                     ByVal canonicalTransactionIDs As String, _
                                     ByVal directionText As String) As String
    Dim rawText As String
    rawText = CStr(Len(candidateKey)) & ":" & candidateKey & "|" & _
              CStr(Len(canonicalTransactionIDs)) & ":" & canonicalTransactionIDs & "|" & _
              CStr(Len(directionText)) & ":" & directionText
    StableResidualLotID = "RL-" & _
        AllocationHashPart(rawText, 15485863#, 269#) & "-" & _
        AllocationHashPart(rawText, 32452843#, 271#)
End Function

Private Function CanonicalResidualLotTransactionIDs(ByVal rawIDs As String) As String
    Dim parts As Variant, ids() As String, seen As Object
    Dim i As Long, j As Long, itemCount As Long
    Dim transactionID As String, swapText As String
    rawIDs = Trim$(rawIDs)
    parts = Split(rawIDs, ";")
    If UBound(parts) - LBound(parts) + 1 < 2 Then _
        Err.Raise vbObjectError + 4992, "CanonicalResidualLotTransactionIDs", _
                  "ResidualLotには2件以上の構成取引IDが必要です。"
    ReDim ids(0 To UBound(parts) - LBound(parts))
    Set seen = CreateObject("Scripting.Dictionary")
    seen.CompareMode = vbBinaryCompare
    For i = LBound(parts) To UBound(parts)
        transactionID = AllocationRequiredText(CStr(parts(i)), "ResidualLot構成取引ID")
        If InStr(1, transactionID, ";", vbBinaryCompare) > 0 Then _
            Err.Raise vbObjectError + 4992, "CanonicalResidualLotTransactionIDs", _
                      "ResidualLot構成取引IDに区切り文字があります。"
        If seen.Exists(transactionID) Then _
            Err.Raise vbObjectError + 4992, "CanonicalResidualLotTransactionIDs", _
                      "ResidualLot構成取引IDが重複しています: " & transactionID
        seen.Add transactionID, True
        ids(itemCount) = transactionID
        itemCount = itemCount + 1
    Next i
    For i = 0 To itemCount - 2
        For j = i + 1 To itemCount - 1
            If StrComp(ids(i), ids(j), vbBinaryCompare) > 0 Then
                swapText = ids(i)
                ids(i) = ids(j)
                ids(j) = swapText
            End If
        Next j
    Next i
    CanonicalResidualLotTransactionIDs = Join(ids, ";")
End Function

Private Function AllocationHashPart(ByVal rawText As String, _
                                    ByVal seedValue As Double, _
                                    ByVal multiplier As Double) As String
    Const HASH_MODULUS As Double = 2147483629#
    Dim hashValue As Double, i As Long, codeValue As Long
    Dim hexText As String
    hashValue = seedValue
    For i = 1 To Len(rawText)
        codeValue = AscW(Mid$(rawText, i, 1))
        If codeValue < 0 Then codeValue = codeValue + 65536
        hashValue = hashValue * multiplier + CDbl(codeValue) + CDbl(i)
        hashValue = hashValue - Fix(hashValue / HASH_MODULUS) * HASH_MODULUS
    Next i
    hexText = Hex$(CLng(hashValue))
    AllocationHashPart = Right$("00000000" & hexText, 8)
End Function

Private Sub CaptureAllocationLedgerSnapshot(ByVal ws As Worksheet, _
                                            ByRef snapshot As Variant, _
                                            ByRef snapshotLastRow As Long)
    Dim rowCount As Long, target As Range
    snapshot = Empty
    snapshotLastRow = AllocationLedgerLastRow(ws)
    If snapshotLastRow < 2 Then
        snapshotLastRow = 1
        Exit Sub
    End If
    rowCount = snapshotLastRow - 1
    If rowCount > MAX_INTERNAL_STORE_DATA_ROWS Then _
        Err.Raise vbObjectError + 4955, "CaptureAllocationLedgerSnapshot", _
                  "配賦元帳が退避上限を超えています。"
    Set target = ws.Range(ws.Cells(2, ALLOC_LEDGER_FIRST_COL), _
                          ws.Cells(snapshotLastRow, ALLOC_LEDGER_LAST_COL))
    RequireAnalysisReviewConstantRange target, "配賦元帳"
    snapshot = target.Value2
    If Not RangeValue2MatchesMatrixStrict(target, snapshot, rowCount, _
                                          ALLOC_LEDGER_COLUMN_COUNT) Then _
        Err.Raise vbObjectError + 4956, "CaptureAllocationLedgerSnapshot", _
                  "配賦元帳の退避読戻しが一致しません。"
End Sub

Private Sub RestoreAllocationLedgerSnapshot(ByVal ws As Worksheet, _
                                            ByVal snapshot As Variant, _
                                            ByVal snapshotLastRow As Long)
    Dim currentLastRow As Long, clearLastRow As Long, rowCount As Long
    Dim target As Range, problems As String
    currentLastRow = AllocationLedgerLastRow(ws)
    clearLastRow = CLng(Application.Max(currentLastRow, snapshotLastRow))
    If clearLastRow >= 2 Then _
        ws.Range(ws.Cells(2, ALLOC_LEDGER_FIRST_COL), _
                 ws.Cells(clearLastRow, ALLOC_LEDGER_LAST_COL)).ClearContents
    If snapshotLastRow >= 2 Then
        rowCount = snapshotLastRow - 1
        Set target = ws.Range(ws.Cells(2, ALLOC_LEDGER_FIRST_COL), _
                              ws.Cells(snapshotLastRow, ALLOC_LEDGER_LAST_COL))
        target.Value2 = snapshot
        If Not RangeValue2MatchesMatrixStrict(target, snapshot, rowCount, _
                                              ALLOC_LEDGER_COLUMN_COUNT) Then _
            Err.Raise vbObjectError + 4957, "RestoreAllocationLedgerSnapshot", _
                      "配賦元帳の復元読戻しが一致しません。"
    End If
    If AllocationLedgerLastRow(ws) <> snapshotLastRow Then _
        Err.Raise vbObjectError + 4958, "RestoreAllocationLedgerSnapshot", _
                  "配賦元帳の復元行数が一致しません。"
    '値だけ戻っても内部正本が表示されたままなら復元成功とはしない。
    SetSheetVeryHiddenSafe ws
    If Not AllocationLedgerIsVeryHidden(ws) Then _
        Err.Raise vbObjectError + 5003, "RestoreAllocationLedgerSnapshot", _
                  "配賦元帳を内部非表示へ復元できません。"
    If Not ValidateAllocationLedgerSheet(ws, problems) Then _
        Err.Raise vbObjectError + 4959, "RestoreAllocationLedgerSnapshot", _
                  "配賦元帳の復元後検証に失敗しました: " & problems
End Sub

Private Sub WriteAllocationLedgerMatrix(ByVal ws As Worksheet, _
                                        ByRef outputData As Variant, _
                                        ByVal outputRows As Long, _
                                        ByVal previousLastRow As Long)
    Dim clearLastRow As Long, target As Range
    clearLastRow = CLng(Application.Max(previousLastRow, outputRows + 1))
    If clearLastRow >= 2 Then _
        ws.Range(ws.Cells(2, ALLOC_LEDGER_FIRST_COL), _
                 ws.Cells(clearLastRow, ALLOC_LEDGER_LAST_COL)).ClearContents
    Set target = ws.Range(ws.Cells(2, ALLOC_LEDGER_FIRST_COL), _
                          ws.Cells(outputRows + 1, ALLOC_LEDGER_LAST_COL))
    target.Value2 = outputData
    If Not RangeValue2MatchesMatrixStrict(target, outputData, outputRows, _
                                          ALLOC_LEDGER_COLUMN_COUNT) Then _
        Err.Raise vbObjectError + 4960, "WriteAllocationLedgerMatrix", _
                  "配賦元帳の一括書込読戻しが一致しません。"
    RequireAnalysisReviewConstantRange target, "配賦元帳の確定内容"
    If AllocationLedgerLastRow(ws) <> outputRows + 1 Then _
        Err.Raise vbObjectError + 4961, "WriteAllocationLedgerMatrix", _
                  "配賦元帳の確定行数が一致しません。"
End Sub

Private Function AllocationLedgerLastRow(ByVal ws As Worksheet) As Long
    If ws Is Nothing Then _
        Err.Raise vbObjectError + 4962, "AllocationLedgerLastRow", _
                  "配賦元帳のシートを取得できません。"
    AllocationLedgerLastRow = LastDataRowInColumns( _
                                  ws, ALLOC_LEDGER_FIRST_COL, ALLOC_LEDGER_LAST_COL)
End Function

Private Function AllocationLedgerIsVeryHidden(ByVal ws As Worksheet) As Boolean
    On Error GoTo EH
    If ws Is Nothing Then Exit Function
    AllocationLedgerIsVeryHidden = (ws.Visible = xlSheetVeryHidden)
    Exit Function
EH:
    AllocationLedgerIsVeryHidden = False
    Err.Clear
End Function

Public Function ValidateAllocationLedgerForSave(ByRef problems As String) As Boolean
    Dim ledgerProblems As String
    On Error GoTo EH
    If Not SheetExists(SH_WORK_ANALYSIS_REVIEW) Then
        ledgerProblems = "配賦元帳の保存先がありません。"
    ElseIf Not ValidateAllocationLedgerSheet( _
                   GetSheet(SH_WORK_ANALYSIS_REVIEW), ledgerProblems) Then
        '検証関数が理由を設定する。
    End If
    If Len(ledgerProblems) > 0 Then
        problems = problems & "・配賦元帳: " & ledgerProblems & vbCrLf
        Exit Function
    End If
    ValidateAllocationLedgerForSave = True
    Exit Function
EH:
    problems = problems & "・配賦元帳を検証できません: Err " & _
               CStr(Err.Number) & " " & Err.Description & vbCrLf
    Err.Clear
End Function

Public Sub CaptureAllocationLedgerTransactionSnapshot( _
        ByRef snapshot As Variant, ByRef snapshotLastRow As Long, _
        ByRef snapshotDigest As String)
    Dim ws As Worksheet, problems As String
    If mAllocationBatchActive Then _
        Err.Raise vbObjectError + 4993, "CaptureAllocationLedgerTransactionSnapshot", _
                  "配賦元帳の更新中は外側snapshotを取得できません。"
    Set ws = GetSheet(SH_WORK_ANALYSIS_REVIEW)
    If Not ValidateAllocationLedgerSheet(ws, problems) Then _
        Err.Raise vbObjectError + 4993, "CaptureAllocationLedgerTransactionSnapshot", _
                  "配賦元帳を退避できません: " & problems
    CaptureAllocationLedgerSnapshot ws, snapshot, snapshotLastRow
    snapshotDigest = AllocationSnapshotDigest(snapshot, snapshotLastRow)
    If Len(snapshotDigest) <> 17 Then _
        Err.Raise vbObjectError + 4993, "CaptureAllocationLedgerTransactionSnapshot", _
                  "配賦元帳snapshotの署名を作成できません。"
End Sub

Public Sub RestoreAllocationLedgerTransactionSnapshot( _
        ByVal snapshot As Variant, ByVal snapshotLastRow As Long, _
        ByVal expectedDigest As String)
    Dim ws As Worksheet, currentSnapshot As Variant, currentLastRow As Long
    Dim currentDigest As String, problems As String
    If mAllocationBatchActive Then _
        Err.Raise vbObjectError + 4994, "RestoreAllocationLedgerTransactionSnapshot", _
                  "配賦元帳の更新中は外側snapshotを復元できません。"
    If StrComp(AllocationSnapshotDigest(snapshot, snapshotLastRow), _
               expectedDigest, vbBinaryCompare) <> 0 Then _
        Err.Raise vbObjectError + 4994, "RestoreAllocationLedgerTransactionSnapshot", _
                  "配賦元帳snapshotの署名が一致しません。"
    Set ws = GetSheet(SH_WORK_ANALYSIS_REVIEW)
    RestoreAllocationLedgerSnapshot ws, snapshot, snapshotLastRow
    CaptureAllocationLedgerSnapshot ws, currentSnapshot, currentLastRow
    currentDigest = AllocationSnapshotDigest(currentSnapshot, currentLastRow)
    If currentLastRow <> snapshotLastRow Or _
       StrComp(currentDigest, expectedDigest, vbBinaryCompare) <> 0 Then _
        Err.Raise vbObjectError + 4995, "RestoreAllocationLedgerTransactionSnapshot", _
                  "配賦元帳の復元後署名が退避時と一致しません。"
    If Not ValidateAllocationLedgerSheet(ws, problems) Then _
        Err.Raise vbObjectError + 4995, "RestoreAllocationLedgerTransactionSnapshot", _
                  "配賦元帳の復元後検証に失敗しました: " & problems
End Sub

Public Function AllocationLedgerStoredRowCount() As Long
    Dim ws As Worksheet, problems As String, lastR As Long
    Set ws = GetSheet(SH_WORK_ANALYSIS_REVIEW)
    If Not ValidateAllocationLedgerSheet(ws, problems) Then _
        Err.Raise vbObjectError + 4996, "AllocationLedgerStoredRowCount", problems
    lastR = AllocationLedgerLastRow(ws)
    If lastR >= 2 Then AllocationLedgerStoredRowCount = lastR - 1
End Function

Private Function AllocationSnapshotDigest(ByVal snapshot As Variant, _
                                          ByVal snapshotLastRow As Long) As String
    Const HASH_MODULUS_ONE As Double = 2147483629#
    Const HASH_MODULUS_TWO As Double = 2147483587#
    Dim firstHash As Double, secondHash As Double, sequenceNo As Double
    Dim rowCount As Long, r As Long, c As Long, i As Long
    Dim pieceText As String, codeValue As Long
    If snapshotLastRow < 1 Then _
        Err.Raise vbObjectError + 4997, "AllocationSnapshotDigest", _
                  "配賦元帳snapshotの最終行が不正です。"
    rowCount = snapshotLastRow - 1
    If rowCount > 0 Then
        If Not IsArray(snapshot) Then _
            Err.Raise vbObjectError + 4997, "AllocationSnapshotDigest", _
                      "配賦元帳snapshot配列がありません。"
        If LBound(snapshot, 1) <> 1 Or UBound(snapshot, 1) <> rowCount Or _
           LBound(snapshot, 2) <> 1 Or _
           UBound(snapshot, 2) <> ALLOC_LEDGER_COLUMN_COUNT Then _
            Err.Raise vbObjectError + 4997, "AllocationSnapshotDigest", _
                      "配賦元帳snapshot配列の形が不正です。"
    End If
    firstHash = 104729#: secondHash = 130363#
    For r = 0 To rowCount
        If r = 0 Then
            pieceText = "ROWS:" & CStr(rowCount) & "|COLS:" & _
                        CStr(ALLOC_LEDGER_COLUMN_COUNT)
            AllocationDigestFeed pieceText, firstHash, secondHash, sequenceNo, _
                                 HASH_MODULUS_ONE, HASH_MODULUS_TWO
        Else
            For c = 1 To ALLOC_LEDGER_COLUMN_COUNT
                pieceText = AllocationSnapshotValue(snapshot(r, c))
                AllocationDigestFeed pieceText, firstHash, secondHash, sequenceNo, _
                                     HASH_MODULUS_ONE, HASH_MODULUS_TWO
            Next c
        End If
    Next r
    AllocationSnapshotDigest = Right$("00000000" & Hex$(CLng(firstHash)), 8) & "-" & _
                               Right$("00000000" & Hex$(CLng(secondHash)), 8)
End Function

Private Sub AllocationDigestFeed(ByVal pieceText As String, _
                                 ByRef firstHash As Double, ByRef secondHash As Double, _
                                 ByRef sequenceNo As Double, ByVal firstModulus As Double, _
                                 ByVal secondModulus As Double)
    Dim i As Long, codeValue As Long
    pieceText = CStr(Len(pieceText)) & ":" & pieceText & "|"
    For i = 1 To Len(pieceText)
        sequenceNo = sequenceNo + 1#
        codeValue = AscW(Mid$(pieceText, i, 1))
        If codeValue < 0 Then codeValue = codeValue + 65536
        firstHash = firstHash * 257# + CDbl(codeValue) + sequenceNo
        firstHash = firstHash - Fix(firstHash / firstModulus) * firstModulus
        secondHash = secondHash * 263# + CDbl(codeValue) + sequenceNo * 3#
        secondHash = secondHash - Fix(secondHash / secondModulus) * secondModulus
    Next i
End Sub

Private Function AllocationSnapshotValue(ByVal valueIn As Variant) As String
    If IsError(valueIn) Then
        AllocationSnapshotValue = "ERR:" & CStr(CLng(valueIn))
    ElseIf IsNull(valueIn) Then
        AllocationSnapshotValue = "NULL"
    ElseIf IsEmpty(valueIn) Then
        AllocationSnapshotValue = "EMPTY"
    ElseIf VarType(valueIn) = vbString Then
        AllocationSnapshotValue = "S:" & CStr(valueIn)
    ElseIf VarType(valueIn) = vbBoolean Then
        AllocationSnapshotValue = "B:" & IIf(CBool(valueIn), "1", "0")
    ElseIf IsNumeric(valueIn) Then
        AllocationSnapshotValue = "N:" & Trim$(Str$(CDbl(valueIn)))
    Else
        AllocationSnapshotValue = "V" & CStr(VarType(valueIn)) & ":" & CStr(valueIn)
    End If
End Function

Private Function ValidateAllocationLedgerSheet(ByVal ws As Worksheet, _
                                                ByRef problems As String) As Boolean
    Dim headers As Variant, c As Long, lastR As Long, rowCount As Long
    Dim target As Range, data As Variant
    problems = vbNullString
    On Error GoTo EH
    If ws Is Nothing Then
        problems = "保存先シートを取得できません。"
        Exit Function
    End If
    If Not AllocationLedgerIsVeryHidden(ws) Then
        problems = "配賦元帳の保存先が内部非表示ではありません。"
        Exit Function
    End If
    headers = AllocationLedgerHeaders()
    For c = 1 To ALLOC_LEDGER_COLUMN_COUNT
        If StrComp(CellText(ws.Cells(1, ALLOC_LEDGER_FIRST_COL + c - 1).Value2), _
                   CStr(headers(c - 1)), vbBinaryCompare) <> 0 Then
            problems = "見出しが一致しません: " & _
                       ws.Cells(1, ALLOC_LEDGER_FIRST_COL + c - 1).Address(False, False)
            Exit Function
        End If
    Next c
    If LastDataRowInColumns(ws, ALLOC_LEDGER_FIRST_COL - 1, _
                            ALLOC_LEDGER_FIRST_COL - 1) > 1 Or _
       Len(CellText(ws.Cells(1, ALLOC_LEDGER_FIRST_COL - 1).Value2)) > 0 Then
        problems = "既存判断台帳との境界列Nが空欄ではありません。"
        Exit Function
    End If
    lastR = AllocationLedgerLastRow(ws)
    If lastR - 1 > MAX_INTERNAL_STORE_DATA_ROWS Then
        problems = "保存上限を超えています。"
        Exit Function
    End If
    If lastR < 2 Then
        ValidateAllocationLedgerSheet = True
        Exit Function
    End If
    rowCount = lastR - 1
    Set target = ws.Range(ws.Cells(2, ALLOC_LEDGER_FIRST_COL), _
                          ws.Cells(lastR, ALLOC_LEDGER_LAST_COL))
    RequireAnalysisReviewConstantRange target, "配賦元帳"
    data = target.Value2
    If Not RangeValue2MatchesMatrixStrict(target, data, rowCount, _
                                          ALLOC_LEDGER_COLUMN_COUNT) Then
        problems = "全列・型の読戻しが一致しません。"
        Exit Function
    End If
    ValidateAllocationLedgerSheet = _
        ValidateAllocationLedgerMatrix(data, rowCount, problems)
    Exit Function
EH:
    problems = "検証エラー: Err " & CStr(Err.Number) & " " & Err.Description
    Err.Clear
End Function

Private Function ValidateAllocationLedgerMatrix(ByRef data As Variant, _
                                                ByVal rowCount As Long, _
                                                ByRef problems As String) As Boolean
    Dim idSet As Object, groupSources As Object, confirmedTotals As Object
    Dim proposedTotals As Object, residualCounts As Object, residualAmounts As Object
    Dim candidateSet As Object, residualLotRows As Object
    Dim candidateEvidence As Object, candidateSourceTypes As Object
    Dim candidateWithdrawTotals As Object, candidateDepositTotals As Object
    Dim r As Long, componentRow As Long
    Dim item As Variant, componentItem As Variant, componentIDs As Variant
    Dim allocationID As String, candidateKey As String, transactionID As String
    Dim directionText As String, statusText As String, evidenceText As String
    Dim sourceType As String, groupKey As String, candidateGroupKey As String
    Dim amountValue As Double, sourceAmount As Double, expectedID As String
    Dim lotSourceTotal As Double, lotResidualAvailable As Double
    Dim isResidual As Boolean, isResidualLot As Boolean
    problems = vbNullString
    On Error GoTo EH
    If rowCount < 0 Or rowCount > MAX_INTERNAL_STORE_DATA_ROWS Then
        problems = "行数が許容範囲外です。"
        Exit Function
    End If
    If rowCount = 0 Then
        ValidateAllocationLedgerMatrix = True
        Exit Function
    End If
    If Not IsArray(data) Then
        problems = "配賦データ配列がありません。"
        Exit Function
    End If
    If LBound(data, 1) <> 1 Or UBound(data, 1) <> rowCount Or _
       LBound(data, 2) <> 1 Or UBound(data, 2) <> ALLOC_LEDGER_COLUMN_COUNT Then
        problems = "配賦データ配列の形が一致しません。"
        Exit Function
    End If
    Set idSet = CreateObject("Scripting.Dictionary")
    idSet.CompareMode = vbBinaryCompare
    Set groupSources = CreateObject("Scripting.Dictionary")
    groupSources.CompareMode = vbBinaryCompare
    Set confirmedTotals = CreateObject("Scripting.Dictionary")
    confirmedTotals.CompareMode = vbBinaryCompare
    Set proposedTotals = CreateObject("Scripting.Dictionary")
    proposedTotals.CompareMode = vbBinaryCompare
    Set residualCounts = CreateObject("Scripting.Dictionary")
    residualCounts.CompareMode = vbBinaryCompare
    Set residualAmounts = CreateObject("Scripting.Dictionary")
    residualAmounts.CompareMode = vbBinaryCompare
    Set candidateSet = CreateObject("Scripting.Dictionary")
    candidateSet.CompareMode = vbBinaryCompare
    Set residualLotRows = CreateObject("Scripting.Dictionary")
    residualLotRows.CompareMode = vbBinaryCompare
    Set candidateEvidence = CreateObject("Scripting.Dictionary")
    candidateEvidence.CompareMode = vbBinaryCompare
    Set candidateSourceTypes = CreateObject("Scripting.Dictionary")
    candidateSourceTypes.CompareMode = vbBinaryCompare
    Set candidateWithdrawTotals = CreateObject("Scripting.Dictionary")
    candidateWithdrawTotals.CompareMode = vbBinaryCompare
    Set candidateDepositTotals = CreateObject("Scripting.Dictionary")
    candidateDepositTotals.CompareMode = vbBinaryCompare

    For r = 1 To rowCount
        allocationID = AllocationRequiredText(data(r, ALLOC_DATA_COL_ID), "AllocationID")
        candidateKey = AllocationRequiredText(data(r, ALLOC_DATA_COL_CANDIDATE_KEY), "CandidateKey")
        transactionID = AllocationRequiredText(data(r, ALLOC_DATA_COL_TRANSACTION_ID), "TransactionID")
        directionText = UCase$(AllocationRequiredText( _
                            data(r, ALLOC_DATA_COL_DIRECTION), "Direction"))
        If Not AllocationDirectionIsValid(directionText) Then _
            Err.Raise vbObjectError + 4963, "ValidateAllocationLedgerMatrix", _
                      CStr(r + 1) & "行目のDirectionが不正です。"
        amountValue = AllocationRequiredAmount(data(r, ALLOC_DATA_COL_AMOUNT), _
                                               "AllocatedAmount")
        statusText = UCase$(AllocationRequiredText( _
                         data(r, ALLOC_DATA_COL_STATUS), "DecisionStatus"))
        evidenceText = Trim$(CellText(data(r, ALLOC_DATA_COL_EVIDENCE)))
        sourceType = AllocationRequiredText(data(r, ALLOC_DATA_COL_SOURCE_TYPE), _
                                            "SourceType")
        If StrComp(sourceType, ALLOCATION_SOURCE_SCOPE, vbBinaryCompare) = 0 Then _
            Err.Raise vbObjectError + 4966, "ValidateAllocationLedgerMatrix", _
                      "SCOPE制御行が配賦元帳へ保存されています。"
        sourceAmount = AllocationRequiredAmount( _
                           data(r, ALLOC_DATA_COL_SOURCE_AMOUNT), "SourceAmount")
        If Not IsDate(data(r, ALLOC_DATA_COL_UPDATED_AT)) Then _
            Err.Raise vbObjectError + 4964, "ValidateAllocationLedgerMatrix", _
                      CStr(r + 1) & "行目のUpdatedAtが不正です。"
        If idSet.Exists(allocationID) Then _
            Err.Raise vbObjectError + 4965, "ValidateAllocationLedgerMatrix", _
                      "AllocationIDが重複しています: " & allocationID
        idSet.Add allocationID, True
        isResidualLot = (StrComp(sourceType, ALLOCATION_SOURCE_RESIDUAL_LOT, _
                                 vbBinaryCompare) = 0)
        If isResidualLot Then
            If statusText <> ALLOCATION_STATUS_REVIEW_REQUIRED Or _
               Not ReviewEvidenceDigestIsValid(evidenceText) Or _
               transactionID <> CanonicalResidualLotTransactionIDs(transactionID) Or _
               allocationID <> StableResidualLotID(candidateKey, transactionID, directionText) Then _
                Err.Raise vbObjectError + 4966, "ValidateAllocationLedgerMatrix", _
                          "ResidualLotの識別情報が不正です: " & allocationID
            If amountValue > sourceAmount + AllocationTolerance(sourceAmount) Then _
                Err.Raise vbObjectError + 4967, "ValidateAllocationLedgerMatrix", _
                          "ResidualLot額が共同残差元額を超えています: " & allocationID
            If candidateEvidence.Exists(candidateKey) Then
                If StrComp(CStr(candidateEvidence(candidateKey)), evidenceText, _
                           vbBinaryCompare) <> 0 Then _
                    Err.Raise vbObjectError + 4966, "ValidateAllocationLedgerMatrix", _
                              "同じ候補のEvidenceDigestが一致しません: " & candidateKey
            Else
                candidateEvidence.Add candidateKey, evidenceText
                candidateWithdrawTotals.Add candidateKey, 0#
                candidateDepositTotals.Add candidateKey, 0#
            End If
            residualLotRows.Add CStr(r), transactionID
            GoTo NextAllocationLedgerRow
        End If
        groupKey = AllocationGroupKey(transactionID, directionText)
        If Not groupSources.Exists(groupKey) Then
            groupSources.Add groupKey, sourceAmount
            confirmedTotals.Add groupKey, 0#
            proposedTotals.Add groupKey, 0#
            residualCounts.Add groupKey, 0&
            residualAmounts.Add groupKey, 0#
        ElseIf Not AllocationAmountsMatch(CDbl(groupSources(groupKey)), sourceAmount) Then
            Err.Raise vbObjectError + 4966, "ValidateAllocationLedgerMatrix", _
                      "同じ取引・方向のSourceAmountが一致しません: " & transactionID
        End If
        If amountValue > sourceAmount + AllocationTolerance(sourceAmount) Then _
            Err.Raise vbObjectError + 4967, "ValidateAllocationLedgerMatrix", _
                      "配賦額が元金額を超えています: " & allocationID

        isResidual = (StrComp(sourceType, ALLOCATION_SOURCE_RESIDUAL, _
                              vbBinaryCompare) = 0)
        If isResidual Then
            expectedID = StableAllocationID(candidateKey, transactionID, directionText, True)
            If statusText <> ALLOCATION_STATUS_UNTRACKED Or Len(evidenceText) > 0 Or _
               StrComp(candidateKey, "UNTRACKED>" & transactionID & ">" & directionText, _
                       vbBinaryCompare) <> 0 Or allocationID <> expectedID Then _
                Err.Raise vbObjectError + 4968, "ValidateAllocationLedgerMatrix", _
                          "残差行の識別情報が不正です: " & allocationID
            residualCounts(groupKey) = CLng(residualCounts(groupKey)) + 1
            residualAmounts(groupKey) = amountValue
        Else
            If Not AllocationInputStatusIsValid(statusText) Then _
                Err.Raise vbObjectError + 4969, "ValidateAllocationLedgerMatrix", _
                          "配賦行のDecisionStatusが不正です: " & allocationID
            If Not ReviewEvidenceDigestIsValid(evidenceText) Then _
                Err.Raise vbObjectError + 4970, "ValidateAllocationLedgerMatrix", _
                          "配賦行のEvidenceDigestが不正です: " & allocationID
            If candidateEvidence.Exists(candidateKey) Then
                If StrComp(CStr(candidateEvidence(candidateKey)), evidenceText, _
                           vbBinaryCompare) <> 0 Then _
                    Err.Raise vbObjectError + 4970, "ValidateAllocationLedgerMatrix", _
                              "同じ候補のEvidenceDigestが一致しません: " & candidateKey
            Else
                candidateEvidence.Add candidateKey, evidenceText
                candidateWithdrawTotals.Add candidateKey, 0#
                candidateDepositTotals.Add candidateKey, 0#
            End If
            If candidateSourceTypes.Exists(candidateKey) Then
                If StrComp(CStr(candidateSourceTypes(candidateKey)), sourceType, _
                           vbBinaryCompare) <> 0 Then _
                    Err.Raise vbObjectError + 4970, "ValidateAllocationLedgerMatrix", _
                              "同じ候補のSourceTypeが一致しません: " & candidateKey
            Else
                candidateSourceTypes.Add candidateKey, sourceType
            End If
            expectedID = StableAllocationID(candidateKey, transactionID, directionText, False)
            If allocationID <> expectedID Then _
                Err.Raise vbObjectError + 4971, "ValidateAllocationLedgerMatrix", _
                          "AllocationIDが安定キーと一致しません: " & allocationID
            candidateGroupKey = groupKey & ChrW$(30) & candidateKey
            If candidateSet.Exists(candidateGroupKey) Then _
                Err.Raise vbObjectError + 4972, "ValidateAllocationLedgerMatrix", _
                          "同じ取引・方向・候補の配賦が重複しています: " & candidateKey
            candidateSet.Add candidateGroupKey, r
            If (statusText = ALLOCATION_STATUS_EXCLUDED Or _
                statusText = ALLOCATION_STATUS_UNREVIEWED) And amountValue <> 0# Then _
                Err.Raise vbObjectError + 4973, "ValidateAllocationLedgerMatrix", _
                          "EXCLUDEDまたはUNREVIEWEDの配賦額が0ではありません。"
            proposedTotals(groupKey) = CDbl(proposedTotals(groupKey)) + amountValue
            If statusText = ALLOCATION_STATUS_CONFIRMED Then
                confirmedTotals(groupKey) = CDbl(confirmedTotals(groupKey)) + amountValue
                If directionText = ALLOCATION_DIRECTION_WITHDRAW Then
                    candidateWithdrawTotals(candidateKey) = _
                        CDbl(candidateWithdrawTotals(candidateKey)) + amountValue
                Else
                    candidateDepositTotals(candidateKey) = _
                        CDbl(candidateDepositTotals(candidateKey)) + amountValue
                End If
            End If
        End If
NextAllocationLedgerRow:
    Next r
    For Each item In groupSources.Keys
        groupKey = CStr(item)
        sourceAmount = CDbl(groupSources(groupKey))
        If CLng(residualCounts(groupKey)) <> 1 Then _
            Err.Raise vbObjectError + 4974, "ValidateAllocationLedgerMatrix", _
                      "取引・方向ごとの残差行が1行ではありません: " & groupKey
        If CDbl(proposedTotals(groupKey)) > _
           sourceAmount + AllocationTolerance(sourceAmount) Then _
            Err.Raise vbObjectError + 4975, "ValidateAllocationLedgerMatrix", _
                      "提案中を含む配賦合計が元金額を超えています: " & groupKey
        If Not AllocationAmountsMatch( _
                   CDbl(confirmedTotals(groupKey)) + CDbl(residualAmounts(groupKey)), _
                   sourceAmount) Then _
            Err.Raise vbObjectError + 4976, "ValidateAllocationLedgerMatrix", _
                      "確定配賦合計+未追跡残額が元金額と一致しません: " & groupKey
    Next item
    '一候補のactive配賦は必ず出金→入金で釣り合う。片側だけを確定した
    '曖昧1:n/n:1/n:nを許すと、不明残額から片側だけが消えるため拒否する。
    For Each item In candidateEvidence.Keys
        candidateKey = CStr(item)
        If Not AllocationAmountsMatch( _
                   CDbl(candidateWithdrawTotals(candidateKey)), _
                   CDbl(candidateDepositTotals(candidateKey))) Then _
            Err.Raise vbObjectError + 4976, "ValidateAllocationLedgerMatrix", _
                      "候補の確定出金配賦と確定入金配賦が一致しません: " & candidateKey
    Next item
    For Each item In residualLotRows.Keys
        r = CLng(item)
        componentIDs = Split(CStr(residualLotRows(CStr(item))), ";")
        directionText = CellText(data(r, ALLOC_DATA_COL_DIRECTION))
        lotSourceTotal = 0#: lotResidualAvailable = 0#
        For Each componentItem In componentIDs
            groupKey = AllocationGroupKey(CStr(componentItem), directionText)
            If Not groupSources.Exists(groupKey) Then _
                Err.Raise vbObjectError + 4976, "ValidateAllocationLedgerMatrix", _
                          "ResidualLot構成取引の個別残差行がありません: " & CStr(componentItem)
            candidateGroupKey = groupKey & ChrW$(30) & _
                                CellText(data(r, ALLOC_DATA_COL_CANDIDATE_KEY))
            If Not candidateSet.Exists(candidateGroupKey) Then _
                Err.Raise vbObjectError + 4976, "ValidateAllocationLedgerMatrix", _
                          "ResidualLot構成取引の候補別0円行がありません: " & CStr(componentItem)
            componentRow = CLng(candidateSet(candidateGroupKey))
            If CDbl(data(componentRow, ALLOC_DATA_COL_AMOUNT)) <> 0# Or _
               CellText(data(componentRow, ALLOC_DATA_COL_STATUS)) <> _
                   ALLOCATION_STATUS_REVIEW_REQUIRED Then _
                Err.Raise vbObjectError + 4976, "ValidateAllocationLedgerMatrix", _
                          "ResidualLot構成取引が0円・REVIEW_REQUIREDではありません: " & _
                          CStr(componentItem)
            lotSourceTotal = lotSourceTotal + CDbl(groupSources(groupKey))
            lotResidualAvailable = lotResidualAvailable + _
                CDbl(groupSources(groupKey)) - CDbl(confirmedTotals(groupKey))
        Next componentItem
        If Not AllocationAmountsMatch( _
                   CDbl(data(r, ALLOC_DATA_COL_SOURCE_AMOUNT)), lotSourceTotal) Then _
            Err.Raise vbObjectError + 4976, "ValidateAllocationLedgerMatrix", _
                      "ResidualLotのSourceAmountが構成取引元額合計と一致しません。"
        If Not AllocationAmountsMatch( _
                   CDbl(data(r, ALLOC_DATA_COL_AMOUNT)), lotSourceTotal) Then _
            Err.Raise vbObjectError + 4976, "ValidateAllocationLedgerMatrix", _
                      "ResidualLot額が構成取引元額合計の満額ではありません。"
        If CDbl(data(r, ALLOC_DATA_COL_AMOUNT)) > _
           lotResidualAvailable + AllocationTolerance(lotSourceTotal) Then _
            Err.Raise vbObjectError + 4976, "ValidateAllocationLedgerMatrix", _
                      "ResidualLot額が構成取引の未追跡残額合計を超えています。"
    Next item
    ValidateAllocationLedgerMatrix = True
    Exit Function
EH:
    problems = "Err " & CStr(Err.Number) & " " & Err.Description
    Err.Clear
End Function

Public Function MarkAllocationEvidenceChanged(ByVal candidateKey As String, _
                                              ByVal transactionID As String, _
                                              ByVal newEvidenceDigest As String) As Boolean
    Dim ws As Worksheet, problems As String
    Dim snapshot As Variant, snapshotLastRow As Long, rowCount As Long
    Dim data As Variant, r As Long, sourceType As String, groupKey As String
    Dim affectedGroups As Object, stamp As Date
    Dim matched As Boolean, evidenceChanged As Boolean
    Dim changed As Boolean, writeStarted As Boolean
    Dim rollbackVerified As Boolean
    Dim errorNumber As Long, errorDescription As String, rollbackDetail As String
    candidateKey = AllocationRequiredText(candidateKey, "CandidateKey")
    transactionID = AllocationRequiredText(transactionID, "TransactionID")
    newEvidenceDigest = Trim$(newEvidenceDigest)
    If Not ReviewEvidenceDigestIsValid(newEvidenceDigest) Then _
        Err.Raise vbObjectError + 4977, "MarkAllocationEvidenceChanged", _
                  "新しいEvidenceDigestが不正です。"
    If mAllocationBatchActive Then _
        Err.Raise vbObjectError + 4978, "MarkAllocationEvidenceChanged", _
                  "配賦元帳の更新処理が既に実行中です。"
    On Error GoTo EH
    mAllocationBatchActive = True
    Set ws = GetSheet(SH_WORK_ANALYSIS_REVIEW)
    If Not ValidateAllocationLedgerSheet(ws, problems) Then _
        Err.Raise vbObjectError + 4979, "MarkAllocationEvidenceChanged", problems
    CaptureAllocationLedgerSnapshot ws, snapshot, snapshotLastRow
    rowCount = snapshotLastRow - 1
    If rowCount < 1 Then GoTo CleanExit
    data = snapshot
    Set affectedGroups = CreateObject("Scripting.Dictionary")
    affectedGroups.CompareMode = vbBinaryCompare
    'requested transactionが候補に属することと、候補単位の根拠変更を先に確認する。
    '同じ候補の一部だけを失効すると、n:1 / 1:n / n:nの残差が不整合になる。
    For r = 1 To rowCount
        sourceType = CellText(data(r, ALLOC_DATA_COL_SOURCE_TYPE))
        If StrComp(sourceType, ALLOCATION_SOURCE_RESIDUAL, vbBinaryCompare) <> 0 And _
           StrComp(CellText(data(r, ALLOC_DATA_COL_CANDIDATE_KEY)), _
                   candidateKey, vbBinaryCompare) = 0 Then
            If AllocationEvidenceTransactionMatches( _
                   CellText(data(r, ALLOC_DATA_COL_TRANSACTION_ID)), _
                   transactionID, sourceType) Then matched = True
            If StrComp(CellText(data(r, ALLOC_DATA_COL_EVIDENCE)), _
                       newEvidenceDigest, vbBinaryCompare) <> 0 Then _
                evidenceChanged = True
        End If
    Next r
    If Not matched Or Not evidenceChanged Then GoTo CleanExit

    stamp = Now
    For r = 1 To rowCount
        sourceType = CellText(data(r, ALLOC_DATA_COL_SOURCE_TYPE))
        If StrComp(sourceType, ALLOCATION_SOURCE_RESIDUAL, vbBinaryCompare) <> 0 And _
           StrComp(CellText(data(r, ALLOC_DATA_COL_CANDIDATE_KEY)), _
                   candidateKey, vbBinaryCompare) = 0 Then
            data(r, ALLOC_DATA_COL_EVIDENCE) = newEvidenceDigest
            data(r, ALLOC_DATA_COL_STATUS) = ALLOCATION_STATUS_REVIEW_REQUIRED
            data(r, ALLOC_DATA_COL_UPDATED_AT) = CDbl(stamp)
            If sourceType <> ALLOCATION_SOURCE_RESIDUAL_LOT Then
                '根拠が変わった旧額を提案予約として残さず、active配賦0へ戻す。
                data(r, ALLOC_DATA_COL_AMOUNT) = 0#
                groupKey = AllocationGroupKey( _
                    CellText(data(r, ALLOC_DATA_COL_TRANSACTION_ID)), _
                    CellText(data(r, ALLOC_DATA_COL_DIRECTION)))
                If Not affectedGroups.Exists(groupKey) Then _
                    affectedGroups.Add groupKey, True
            End If
            changed = True
        End If
    Next r
    If Not changed Then GoTo CleanExit
    RecomputeAllocationResiduals data, rowCount, affectedGroups, stamp
    problems = vbNullString
    If Not ValidateAllocationLedgerMatrix(data, rowCount, problems) Then _
        Err.Raise vbObjectError + 4980, "MarkAllocationEvidenceChanged", _
                  "証拠変更後の配賦計画が不正です: " & problems
    writeStarted = True
    WriteAllocationLedgerMatrix ws, data, rowCount, snapshotLastRow
    problems = vbNullString
    If Not ValidateAllocationLedgerSheet(ws, problems) Then _
        Err.Raise vbObjectError + 4981, "MarkAllocationEvidenceChanged", _
                  "証拠変更後の配賦元帳が不正です: " & problems
    MarkOutputsDirty
    SetSheetVeryHiddenSafe ws
    If Not AllocationLedgerIsVeryHidden(ws) Then _
        Err.Raise vbObjectError + 4982, "MarkAllocationEvidenceChanged", _
                  "配賦元帳を内部非表示へ戻せません。"
    MarkAllocationEvidenceChanged = True
CleanExit:
    mAllocationBatchActive = False
    Exit Function
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    If writeStarted Then
        rollbackVerified = TryRollbackAllocationLedger( _
                               ws, snapshot, snapshotLastRow, rollbackDetail)
        If Not rollbackVerified Then _
            AppendAnalysisReviewRollbackDetail rollbackDetail, _
                "共通Recoveryの所有権を外側の取引分析transactionへ伝播しました。"
    End If
    mAllocationBatchActive = False
    If Len(rollbackDetail) > 0 Then _
        errorDescription = errorDescription & " / ロールバック確認: " & rollbackDetail
    Err.Raise errorNumber, "MarkAllocationEvidenceChanged", errorDescription
End Function

Private Function AllocationEvidenceTransactionMatches( _
        ByVal storedTransactionIDs As String, ByVal requestedTransactionID As String, _
        ByVal sourceType As String) As Boolean
    Dim parts As Variant, item As Variant
    If sourceType <> ALLOCATION_SOURCE_RESIDUAL_LOT Then
        AllocationEvidenceTransactionMatches = _
            (StrComp(storedTransactionIDs, requestedTransactionID, vbBinaryCompare) = 0)
        Exit Function
    End If
    parts = Split(storedTransactionIDs, ";")
    For Each item In parts
        If StrComp(CStr(item), requestedTransactionID, vbBinaryCompare) = 0 Then
            AllocationEvidenceTransactionMatches = True
            Exit Function
        End If
    Next item
End Function

Private Sub RecomputeAllocationResiduals(ByRef data As Variant, ByVal rowCount As Long, _
                                         ByVal affectedGroups As Object, ByVal stamp As Date)
    Dim confirmedTotals As Object, sourceAmounts As Object, residualRows As Object
    Dim r As Long, groupKey As String, statusText As String, sourceType As String
    Dim item As Variant, sourceAmount As Double, residualAmount As Double
    Set confirmedTotals = CreateObject("Scripting.Dictionary")
    confirmedTotals.CompareMode = vbBinaryCompare
    Set sourceAmounts = CreateObject("Scripting.Dictionary")
    sourceAmounts.CompareMode = vbBinaryCompare
    Set residualRows = CreateObject("Scripting.Dictionary")
    residualRows.CompareMode = vbBinaryCompare
    For r = 1 To rowCount
        groupKey = AllocationGroupKey( _
            CellText(data(r, ALLOC_DATA_COL_TRANSACTION_ID)), _
            CellText(data(r, ALLOC_DATA_COL_DIRECTION)))
        If affectedGroups.Exists(groupKey) Then
            sourceAmount = CDbl(data(r, ALLOC_DATA_COL_SOURCE_AMOUNT))
            If Not sourceAmounts.Exists(groupKey) Then
                sourceAmounts.Add groupKey, sourceAmount
                confirmedTotals.Add groupKey, 0#
            End If
            sourceType = CellText(data(r, ALLOC_DATA_COL_SOURCE_TYPE))
            statusText = CellText(data(r, ALLOC_DATA_COL_STATUS))
            If sourceType = ALLOCATION_SOURCE_RESIDUAL Then
                If residualRows.Exists(groupKey) Then _
                    Err.Raise vbObjectError + 4983, "RecomputeAllocationResiduals", _
                              "残差行が重複しています: " & groupKey
                residualRows.Add groupKey, r
            ElseIf statusText = ALLOCATION_STATUS_CONFIRMED Then
                confirmedTotals(groupKey) = CDbl(confirmedTotals(groupKey)) + _
                                            CDbl(data(r, ALLOC_DATA_COL_AMOUNT))
            End If
        End If
    Next r
    For Each item In affectedGroups.Keys
        groupKey = CStr(item)
        If Not sourceAmounts.Exists(groupKey) Or Not residualRows.Exists(groupKey) Then _
            Err.Raise vbObjectError + 4984, "RecomputeAllocationResiduals", _
                      "残差再計算に必要な行がありません: " & groupKey
        sourceAmount = CDbl(sourceAmounts(groupKey))
        residualAmount = sourceAmount - CDbl(confirmedTotals(groupKey))
        If residualAmount < -AllocationTolerance(sourceAmount) Then _
            Err.Raise vbObjectError + 4985, "RecomputeAllocationResiduals", _
                      "証拠変更後の確定配賦が元金額を超えています: " & groupKey
        If Abs(residualAmount) <= AllocationTolerance(sourceAmount) Then residualAmount = 0#
        r = CLng(residualRows(groupKey))
        data(r, ALLOC_DATA_COL_AMOUNT) = residualAmount
        data(r, ALLOC_DATA_COL_UPDATED_AT) = CDbl(stamp)
    Next item
End Sub

Public Function CaptureAllocationLedgerIndex() As Object
    Dim result As Object, ws As Worksheet, problems As String
    Dim lastR As Long, rowCount As Long, data As Variant, r As Long
    Dim groupKey As String, sourceType As String, statusText As String
    Dim summary As Variant
    Set result = CreateObject("Scripting.Dictionary")
    result.CompareMode = vbBinaryCompare
    Set ws = GetSheet(SH_WORK_ANALYSIS_REVIEW)
    If Not ValidateAllocationLedgerSheet(ws, problems) Then _
        Err.Raise vbObjectError + 4986, "CaptureAllocationLedgerIndex", problems
    lastR = AllocationLedgerLastRow(ws)
    If lastR < 2 Then
        Set CaptureAllocationLedgerIndex = result
        Exit Function
    End If
    rowCount = lastR - 1
    data = ws.Range(ws.Cells(2, ALLOC_LEDGER_FIRST_COL), _
                    ws.Cells(lastR, ALLOC_LEDGER_LAST_COL)).Value2
    For r = 1 To rowCount
        sourceType = CellText(data(r, ALLOC_DATA_COL_SOURCE_TYPE))
        If sourceType = ALLOCATION_SOURCE_RESIDUAL_LOT Then GoTo NextAllocationIndexRow
        groupKey = AllocationGroupKey( _
            CellText(data(r, ALLOC_DATA_COL_TRANSACTION_ID)), _
            CellText(data(r, ALLOC_DATA_COL_DIRECTION)))
        If Not result.Exists(groupKey) Then _
            result.Add groupKey, Array(0#, 0#, _
                CDbl(data(r, ALLOC_DATA_COL_SOURCE_AMOUNT)), 0&)
        summary = result(groupKey)
        statusText = CellText(data(r, ALLOC_DATA_COL_STATUS))
        If sourceType = ALLOCATION_SOURCE_RESIDUAL Then
            summary(1) = CDbl(data(r, ALLOC_DATA_COL_AMOUNT))
        ElseIf statusText = ALLOCATION_STATUS_CONFIRMED Then
            summary(0) = CDbl(summary(0)) + CDbl(data(r, ALLOC_DATA_COL_AMOUNT))
            If CDbl(data(r, ALLOC_DATA_COL_AMOUNT)) > _
               AllocationTolerance(CDbl(data(r, ALLOC_DATA_COL_SOURCE_AMOUNT))) Then _
                summary(3) = CLng(summary(3)) + 1
        End If
        result(groupKey) = summary
NextAllocationIndexRow:
    Next r
    Set CaptureAllocationLedgerIndex = result
End Function

Public Function GetTransactionUnresolvedAmount( _
        ByVal transactionID As String, ByVal directionText As String, _
        ByVal sourceAmount As Double, ByRef allocatedAmount As Double, _
        ByRef unresolvedAmount As Double, ByRef allocationCount As Long) As Boolean
    Dim allocationIndex As Object
    Set allocationIndex = CaptureAllocationLedgerIndex()
    GetTransactionUnresolvedAmount = GetTransactionUnresolvedAmountFromIndex( _
        allocationIndex, transactionID, directionText, sourceAmount, _
        allocatedAmount, unresolvedAmount, allocationCount)
End Function

Public Function GetTransactionUnresolvedAmountFromIndex( _
        ByVal allocationIndex As Object, ByVal transactionID As String, _
        ByVal directionText As String, ByVal sourceAmount As Double, _
        ByRef allocatedAmount As Double, ByRef unresolvedAmount As Double, _
        ByRef allocationCount As Long) As Boolean
    Dim groupKey As String, summary As Variant
    allocatedAmount = 0#
    unresolvedAmount = 0#
    allocationCount = 0
    transactionID = AllocationRequiredText(transactionID, "TransactionID")
    directionText = UCase$(AllocationRequiredText(directionText, "Direction"))
    If Not AllocationDirectionIsValid(directionText) Then _
        Err.Raise vbObjectError + 4987, "GetTransactionUnresolvedAmountFromIndex", _
                  "Directionが不正です。"
    sourceAmount = AllocationRequiredAmount(sourceAmount, "SourceAmount")
    If allocationIndex Is Nothing Then _
        Err.Raise vbObjectError + 4988, "GetTransactionUnresolvedAmountFromIndex", _
                  "配賦元帳索引がありません。"
    groupKey = AllocationGroupKey(transactionID, directionText)
    If Not allocationIndex.Exists(groupKey) Then
        unresolvedAmount = sourceAmount
        GetTransactionUnresolvedAmountFromIndex = True
        Exit Function
    End If
    summary = allocationIndex(groupKey)
    If Not AllocationAmountsMatch(CDbl(summary(2)), sourceAmount) Then _
        Err.Raise vbObjectError + 4989, "GetTransactionUnresolvedAmountFromIndex", _
                  "配賦元帳のSourceAmountが現在取引額と一致しません: " & transactionID
    allocatedAmount = CDbl(summary(0))
    unresolvedAmount = CDbl(summary(1))
    allocationCount = CLng(summary(3))
    If Not AllocationAmountsMatch(allocatedAmount + unresolvedAmount, sourceAmount) Then _
        Err.Raise vbObjectError + 4990, "GetTransactionUnresolvedAmountFromIndex", _
                  "確定配賦合計+未追跡残額が元金額と一致しません: " & transactionID
    GetTransactionUnresolvedAmountFromIndex = True
End Function

Public Function CaptureAllocationsForCandidate(ByVal candidateKey As String) As Collection
    Dim result As New Collection
    Dim ws As Worksheet, problems As String, lastR As Long, data As Variant, r As Long
    candidateKey = AllocationRequiredText(candidateKey, "CandidateKey")
    Set ws = GetSheet(SH_WORK_ANALYSIS_REVIEW)
    If Not ValidateAllocationLedgerSheet(ws, problems) Then _
        Err.Raise vbObjectError + 4991, "CaptureAllocationsForCandidate", problems
    lastR = AllocationLedgerLastRow(ws)
    If lastR >= 2 Then
        data = ws.Range(ws.Cells(2, ALLOC_LEDGER_FIRST_COL), _
                        ws.Cells(lastR, ALLOC_LEDGER_LAST_COL)).Value2
        For r = 1 To lastR - 1
            If StrComp(CellText(data(r, ALLOC_DATA_COL_CANDIDATE_KEY)), _
                       candidateKey, vbBinaryCompare) = 0 And _
               StrComp(CellText(data(r, ALLOC_DATA_COL_SOURCE_TYPE)), _
                       ALLOCATION_SOURCE_RESIDUAL, vbBinaryCompare) <> 0 Then _
                result.Add Array( _
                    data(r, ALLOC_DATA_COL_ID), data(r, ALLOC_DATA_COL_CANDIDATE_KEY), _
                    data(r, ALLOC_DATA_COL_TRANSACTION_ID), data(r, ALLOC_DATA_COL_DIRECTION), _
                    data(r, ALLOC_DATA_COL_AMOUNT), data(r, ALLOC_DATA_COL_STATUS), _
                    data(r, ALLOC_DATA_COL_EVIDENCE), data(r, ALLOC_DATA_COL_SOURCE_TYPE), _
                    data(r, ALLOC_DATA_COL_SOURCE_AMOUNT), data(r, ALLOC_DATA_COL_UPDATED_AT))
        Next r
    End If
    Set CaptureAllocationsForCandidate = result
End Function


Private Sub PrepareAnalysisReviewStoreSheet(ByVal ws As Worksheet, ByVal resetContents As Boolean, _
                                            ByVal headers As Variant, ByVal lastColumn As Long)
    If ws Is Nothing Then Err.Raise vbObjectError + 4900, _
        "PrepareAnalysisReviewStoreSheet", "分析判断の内部保存先がありません。"
    If resetContents Then ResetWorksheet ws
    If Len(CellText(ws.Cells(1, 1).Value)) = 0 Then
        SetRowValues ws.Range("A1"), headers
        FormatOutputHeader ws.Range(ws.Cells(1, 1), ws.Cells(1, lastColumn))
    End If
    ws.Columns("A:M").NumberFormatLocal = "@"
    If StrComp(ws.Name, SH_WORK_ANALYSIS_HISTORY, vbTextCompare) = 0 Then
        ws.Columns("C:C").NumberFormatLocal = "yyyy/m/d h:mm:ss"
    Else
        ws.Columns("H:H").NumberFormatLocal = "yyyy/m/d h:mm:ss"
    End If
    SetSheetVeryHiddenSafe ws
End Sub

Public Function CapturePersistentAnalysisReviews() As Object
    Dim reviews As Object, ws As Worksheet
    Dim lastR As Long, data As Variant, r As Long
    Dim keyText As String, statusText As String, memoText As String
    Set reviews = CreateObject("Scripting.Dictionary")
    reviews.CompareMode = vbTextCompare
    If Not SheetExists(SH_WORK_ANALYSIS_REVIEW) Then
        Set CapturePersistentAnalysisReviews = reviews
        Exit Function
    End If
    Set ws = GetSheet(SH_WORK_ANALYSIS_REVIEW)
    lastR = AnalysisReviewLastRowStrict(ws, "分析判断台帳")
    If lastR < 2 Then
        Set CapturePersistentAnalysisReviews = reviews
        Exit Function
    End If
    data = ws.Range(ws.Cells(2, 1), _
                    ws.Cells(lastR, ANALYSIS_REVIEW_STORE_LAST_COL)).Value2
    For r = 1 To UBound(data, 1)
        keyText = CellText(data(r, REVIEW_STORE_COL_KEY))
        statusText = CellText(data(r, REVIEW_STORE_COL_STATUS))
        If Len(statusText) = 0 Then statusText = ANALYSIS_STATUS_UNREVIEWED
        memoText = CellText(data(r, REVIEW_STORE_COL_MEMO))
        If Len(keyText) > 0 And _
           (statusText <> ANALYSIS_STATUS_UNREVIEWED Or Len(memoText) > 0) Then
            If reviews.Exists(keyText) Then _
                Err.Raise vbObjectError + 4901, "CapturePersistentAnalysisReviews", _
                          "分析判断台帳の候補キーが重複しています: " & keyText
            reviews.Add keyText, Array(statusText, memoText, _
                CellText(data(r, REVIEW_STORE_COL_EVIDENCE)))
        End If
    Next r
    Set CapturePersistentAnalysisReviews = reviews
End Function

Public Function MergeStoredAnalysisReviews(ByVal currentReviews As Object, _
                                           ByVal storedReviews As Object) As Object
    Dim result As Object, item As Variant
    Set result = CreateObject("Scripting.Dictionary")
    result.CompareMode = vbTextCompare
    If Not storedReviews Is Nothing Then
        For Each item In storedReviews.Keys
            result.Add CStr(item), storedReviews(item)
        Next item
    End If
    If Not currentReviews Is Nothing Then
        For Each item In currentReviews.Keys
            If result.Exists(CStr(item)) Then
                result(CStr(item)) = currentReviews(item)
            Else
                result.Add CStr(item), currentReviews(item)
            End If
        Next item
    End If
    Set MergeStoredAnalysisReviews = result
End Function

Public Sub PersistAnalysisReviewsFromCurrentSheets(ByVal markMissing As Boolean, _
                                                    Optional ByVal reasonText As String = "")
    Dim wsStore As Worksheet, indexByKey As Object, presentKeys As Object
    Dim plannedPresentKeys As Object
    Dim wsHistory As Worksheet
    Dim storeSnapshot As Variant, historySnapshot As Variant
    Dim storeSnapshotLastRow As Long, historySnapshotLastRow As Long
    Dim plannedStoreAdds As Long, plannedHistoryAdds As Long
    Dim snapshotsCaptured As Boolean, writeStarted As Boolean
    Dim rollbackVerified As Boolean, storeRestored As Boolean, historyRestored As Boolean
    Dim errorNumber As Long, errorDescription As String, rollbackDetail As String
    If mReviewPersistActive Then _
        Err.Raise vbObjectError + 4906, "PersistAnalysisReviewsFromCurrentSheets", _
                  "分析判断台帳の保存処理が既に実行中です。"
    If Not SheetExists(SH_WORK_ANALYSIS_REVIEW) Or _
       Not SheetExists(SH_WORK_ANALYSIS_HISTORY) Then _
        Err.Raise vbObjectError + 4902, "PersistAnalysisReviewsFromCurrentSheets", _
                  "分析判断台帳がありません。再セットアップしてください。"
    On Error GoTo EH
    '台帳・履歴へ1行でも書く前に、3つの分析表を全件検証する。
    'Value2だけを先に読むと、数式結果やExcelエラーを正常な判断として永続化した後で
    '再分析側のCaptureAnalysisReviewsが拒否するため、検証順序を入口へ統一する。
    ValidateAnalysisReviewSourcesBeforePersist
    Set wsStore = GetSheet(SH_WORK_ANALYSIS_REVIEW)
    Set wsHistory = GetSheet(SH_WORK_ANALYSIS_HISTORY)
    EnsureAnalysisPersistenceStoreSafe wsStore, ANALYSIS_REVIEW_STORE_LAST_COL, "分析判断台帳"
    EnsureAnalysisPersistenceStoreSafe wsHistory, ANALYSIS_HISTORY_STORE_LAST_COL, "分析判断履歴"
    CaptureConstantDataStoreSnapshot wsStore, ANALYSIS_REVIEW_STORE_LAST_COL, _
                                     storeSnapshot, storeSnapshotLastRow
    CaptureConstantDataStoreSnapshot wsHistory, ANALYSIS_HISTORY_STORE_LAST_COL, _
                                     historySnapshot, historySnapshotLastRow
    snapshotsCaptured = True
    Set indexByKey = BuildAnalysisReviewStoreIndex(wsStore)
    Set plannedPresentKeys = CreateObject("Scripting.Dictionary")
    plannedPresentKeys.CompareMode = vbTextCompare
    PlanOneAnalysisReviewSheet GetSheet(SH_ANALYSIS_SHIFT), SHIFT_ANALYSIS_STATUS_COL, _
        SHIFT_ANALYSIS_MEMO_COL, SHIFT_ANALYSIS_KEY_COL, SH_ANALYSIS_SHIFT, _
        "資金シフト", 33, 34, indexByKey, plannedPresentKeys, _
        plannedStoreAdds, plannedHistoryAdds
    PlanOneAnalysisReviewSheet GetSheet(SH_ANALYSIS_FLOW), FLOW_ANALYSIS_STATUS_COL, _
        FLOW_ANALYSIS_MEMO_COL, FLOW_ANALYSIS_KEY_COL, SH_ANALYSIS_FLOW, _
        "資金フロー", 20, 0, indexByKey, plannedPresentKeys, _
        plannedStoreAdds, plannedHistoryAdds
    PlanOneAnalysisReviewSheet GetSheet(SH_ANALYSIS_UNKNOWN), UNKNOWN_ANALYSIS_STATUS_COL, _
        UNKNOWN_ANALYSIS_MEMO_COL, UNKNOWN_ANALYSIS_KEY_COL, SH_ANALYSIS_UNKNOWN, _
        "", 24, 0, indexByKey, plannedPresentKeys, _
        plannedStoreAdds, plannedHistoryAdds
    If markMissing Then _
        PlanMissingAnalysisReviewRows wsStore, plannedPresentKeys, plannedHistoryAdds
    EnsureAnalysisReviewBatchCapacity wsStore, wsHistory, storeSnapshotLastRow, _
                                      historySnapshotLastRow, plannedStoreAdds, plannedHistoryAdds

    Set presentKeys = CreateObject("Scripting.Dictionary")
    presentKeys.CompareMode = vbTextCompare
    mReviewPersistActive = True
    mReviewStoreNextRow = storeSnapshotLastRow + 1
    If mReviewStoreNextRow < 2 Then mReviewStoreNextRow = 2
    mReviewHistoryNextRow = historySnapshotLastRow + 1
    If mReviewHistoryNextRow < 2 Then mReviewHistoryNextRow = 2
    mReviewCommitStamp = Now
    mReviewCommitUser = AnalysisReviewUserName()
    mReviewActualStoreAdds = 0
    mReviewActualHistoryAdds = 0
    writeStarted = True

    PersistOneAnalysisReviewSheet GetSheet(SH_ANALYSIS_SHIFT), SHIFT_ANALYSIS_STATUS_COL, _
        SHIFT_ANALYSIS_MEMO_COL, SHIFT_ANALYSIS_KEY_COL, SH_ANALYSIS_SHIFT, _
        "資金シフト", 33, 34, indexByKey, presentKeys, reasonText
    PersistOneAnalysisReviewSheet GetSheet(SH_ANALYSIS_FLOW), FLOW_ANALYSIS_STATUS_COL, _
        FLOW_ANALYSIS_MEMO_COL, FLOW_ANALYSIS_KEY_COL, SH_ANALYSIS_FLOW, _
        "資金フロー", 20, 0, indexByKey, presentKeys, reasonText
    PersistOneAnalysisReviewSheet GetSheet(SH_ANALYSIS_UNKNOWN), UNKNOWN_ANALYSIS_STATUS_COL, _
        UNKNOWN_ANALYSIS_MEMO_COL, UNKNOWN_ANALYSIS_KEY_COL, SH_ANALYSIS_UNKNOWN, _
        "", 24, 0, indexByKey, presentKeys, reasonText
    If markMissing Then MarkMissingAnalysisReviewRows wsStore, presentKeys, reasonText
    If mReviewActualStoreAdds <> plannedStoreAdds Or _
       mReviewActualHistoryAdds <> plannedHistoryAdds Then _
        Err.Raise vbObjectError + 4907, "PersistAnalysisReviewsFromCurrentSheets", _
                  "分析判断台帳の事前件数と実書込件数が一致しません。"
    If LastDataRowInColumns(wsStore, 1, ANALYSIS_REVIEW_STORE_LAST_COL) <> _
       storeSnapshotLastRow + plannedStoreAdds Then _
        Err.Raise vbObjectError + 4908, "PersistAnalysisReviewsFromCurrentSheets", _
                  "分析判断台帳の確定行数が一致しません。"
    If LastDataRowInColumns(wsHistory, 1, ANALYSIS_HISTORY_STORE_LAST_COL) <> _
       historySnapshotLastRow + plannedHistoryAdds Then _
        Err.Raise vbObjectError + 4909, "PersistAnalysisReviewsFromCurrentSheets", _
                  "分析判断履歴の確定行数が一致しません。"
    EnsureAnalysisPersistenceStoreSafe wsStore, ANALYSIS_REVIEW_STORE_LAST_COL, "分析判断台帳"
    EnsureAnalysisPersistenceStoreSafe wsHistory, ANALYSIS_HISTORY_STORE_LAST_COL, "分析判断履歴"
    SetSheetVeryHiddenSafe wsStore
    If Not AnalysisReviewStoreIsVeryHidden(wsStore) Then _
        Err.Raise vbObjectError + 4928, "PersistAnalysisReviewsFromCurrentSheets", _
                  "分析判断台帳を内部非表示へ戻せません。"
    SetSheetVeryHiddenSafe wsHistory
    If Not AnalysisReviewStoreIsVeryHidden(wsHistory) Then _
        Err.Raise vbObjectError + 4929, "PersistAnalysisReviewsFromCurrentSheets", _
                  "分析判断履歴を内部非表示へ戻せません。"
    ResetAnalysisReviewPersistState
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    ResetAnalysisReviewPersistState
    If writeStarted And snapshotsCaptured Then
        On Error Resume Next
        Err.Clear
        RestoreConstantDataStoreSnapshot wsStore, ANALYSIS_REVIEW_STORE_LAST_COL, _
                                         storeSnapshot, storeSnapshotLastRow
        If Err.Number = 0 Then
            storeRestored = True
        Else
            AppendAnalysisReviewRollbackDetail rollbackDetail, _
                "分析判断台帳の復元エラー: " & Err.Description
        End If
        Err.Clear
        RestoreConstantDataStoreSnapshot wsHistory, ANALYSIS_HISTORY_STORE_LAST_COL, _
                                         historySnapshot, historySnapshotLastRow
        If Err.Number = 0 Then
            historyRestored = True
        Else
            AppendAnalysisReviewRollbackDetail rollbackDetail, _
                "分析判断履歴の復元エラー: " & Err.Description
        End If
        Err.Clear
        SetSheetVeryHiddenSafe wsStore
        If Not AnalysisReviewStoreIsVeryHidden(wsStore) Then
            AppendAnalysisReviewRollbackDetail rollbackDetail, _
                "分析判断台帳を内部非表示へ戻せません。"
        End If
        Err.Clear
        SetSheetVeryHiddenSafe wsHistory
        If Not AnalysisReviewStoreIsVeryHidden(wsHistory) Then
            AppendAnalysisReviewRollbackDetail rollbackDetail, _
                "分析判断履歴を内部非表示へ戻せません。"
        End If
        Err.Clear
        On Error GoTo 0
        rollbackVerified = storeRestored And historyRestored And Len(rollbackDetail) = 0
        If Not rollbackVerified Then
            AppendAnalysisReviewRollbackDetail rollbackDetail, _
                "共通Recoveryの所有権を外側の取引分析または" & _
                "分析workspace transactionへ伝播しました。"
        End If
    End If
    If Len(rollbackDetail) > 0 Then _
        errorDescription = errorDescription & " / ロールバック確認: " & rollbackDetail
    Err.Raise errorNumber, "PersistAnalysisReviewsFromCurrentSheets", errorDescription
End Sub

Private Function AnalysisReviewStoreIsVeryHidden(ByVal ws As Worksheet) As Boolean
    'SetSheetVeryHiddenSafeは互換動作のため内部エラーを抑止する。
    '永続化の確定境界では実状態を別途読戻し、取得不能も不一致として扱う。
    On Error GoTo EH
    If ws Is Nothing Then Exit Function
    AnalysisReviewStoreIsVeryHidden = (ws.Visible = xlSheetVeryHidden)
    Exit Function
EH:
    AnalysisReviewStoreIsVeryHidden = False
    Err.Clear
End Function

Private Function AnalysisReviewLastRowStrict(ByVal ws As Worksheet, _
                                             ByVal labelText As String) As Long
    Dim lastR As Long
    If ws Is Nothing Then _
        Err.Raise vbObjectError + 4930, "AnalysisReviewLastRowStrict", _
                  labelText & "を取得できません。"
    On Error GoTo EH
    If StrComp(ws.Name, SH_WORK_ANALYSIS_HISTORY, vbTextCompare) = 0 Then
        lastR = LastDataRowInColumns(ws, 1, ANALYSIS_HISTORY_STORE_LAST_COL)
    Else
        lastR = LastDataRowInColumns(ws, 1, ANALYSIS_REVIEW_STORE_LAST_COL)
    End If
    AnalysisReviewLastRowStrict = lastR
    Exit Function
EH:
    Err.Raise vbObjectError + 4930, "AnalysisReviewLastRowStrict", _
              labelText & "の最終行を確認できません: Err " & _
              CStr(Err.Number) & " " & Err.Description
End Function

Private Sub ResetAnalysisReviewPersistState()
    mReviewPersistActive = False
    mReviewStoreNextRow = 0
    mReviewHistoryNextRow = 0
    mReviewCommitStamp = 0
    mReviewCommitUser = vbNullString
    mReviewActualStoreAdds = 0
    mReviewActualHistoryAdds = 0
End Sub

Private Sub EnsureAnalysisPersistenceStoreSafe(ByVal ws As Worksheet, ByVal lastColumn As Long, _
                                               ByVal labelText As String)
    Dim lastR As Long, dataRange As Range
    Dim formulaCell As Range, errorCell As Range
    If ws Is Nothing Or lastColumn < 1 Then _
        Err.Raise vbObjectError + 4910, "EnsureAnalysisPersistenceStoreSafe", _
                  labelText & "の検査範囲が不正です。"
    lastR = LastDataRowInColumns(ws, 1, lastColumn)
    If lastR - 1 > MAX_INTERNAL_STORE_DATA_ROWS Then _
        Err.Raise vbObjectError + 4911, "EnsureAnalysisPersistenceStoreSafe", _
                  labelText & "が保存上限を超えています。"
    If lastR < 2 Then Exit Sub
    Set dataRange = ws.Range(ws.Cells(2, 1), ws.Cells(lastR, lastColumn))
    If Not TryFindFirstFormulaCell(dataRange, formulaCell) Then _
        Err.Raise vbObjectError + 4912, "EnsureAnalysisPersistenceStoreSafe", _
                  labelText & "の数式検査に失敗しました。"
    If Not formulaCell Is Nothing Then _
        Err.Raise vbObjectError + 4912, "EnsureAnalysisPersistenceStoreSafe", _
                  labelText & "に数式があります: " & formulaCell.Address(False, False)
    If Not TryFindFirstErrorConstantCell(dataRange, errorCell) Then _
        Err.Raise vbObjectError + 4913, "EnsureAnalysisPersistenceStoreSafe", _
                  labelText & "のExcelエラー検査に失敗しました。"
    If Not errorCell Is Nothing Then _
        Err.Raise vbObjectError + 4913, "EnsureAnalysisPersistenceStoreSafe", _
                  labelText & "にExcelエラーがあります: " & errorCell.Address(False, False)
    EnsureAnalysisReviewRangeHasNoPrefix dataRange, labelText
End Sub

Private Sub EnsureAnalysisReviewRangeHasNoPrefix(ByVal target As Range, ByVal labelText As String)
    Const PREFIX_CHECK_ROWS As Long = 500
    Dim rowOffset As Long, chunkRows As Long
    Dim chunk As Range, cell As Range
    Dim prefixState As Variant, scanCells As Boolean
    Dim scanError As Long
    If target Is Nothing Then Exit Sub
    For rowOffset = 1 To target.Rows.Count Step PREFIX_CHECK_ROWS
        chunkRows = CLng(Application.Min(PREFIX_CHECK_ROWS, _
                                         target.Rows.Count - rowOffset + 1))
        Set chunk = target.Rows(rowOffset).Resize(chunkRows, target.Columns.Count)
        scanCells = False
        On Error Resume Next
        Err.Clear
        prefixState = chunk.PrefixCharacter
        scanError = Err.Number
        Err.Clear
        On Error GoTo 0
        If scanError <> 0 Or IsNull(prefixState) Then
            scanCells = True
        ElseIf Len(CStr(prefixState)) > 0 Then
            scanCells = True
        End If
        If scanCells Then
            For Each cell In chunk.Cells
                If Len(CStr(cell.PrefixCharacter)) > 0 Then _
                    Err.Raise vbObjectError + 4914, "EnsureAnalysisReviewRangeHasNoPrefix", _
                              labelText & "に先頭アポストロフィ付きの値があります: " & _
                              cell.Address(False, False)
            Next cell
        End If
    Next rowOffset
End Sub

Private Sub EnsureAnalysisReviewBatchCapacity(ByVal wsStore As Worksheet, _
                                              ByVal wsHistory As Worksheet, _
                                              ByVal storeLastRow As Long, _
                                              ByVal historyLastRow As Long, _
                                              ByVal storeAdds As Long, _
                                              ByVal historyAdds As Long)
    If storeAdds < 0 Or historyAdds < 0 Then _
        Err.Raise vbObjectError + 4915, "EnsureAnalysisReviewBatchCapacity", _
                  "分析判断の追加予定件数が不正です。"
    If storeLastRow - 1 + storeAdds > MAX_INTERNAL_STORE_DATA_ROWS Or _
       storeLastRow + storeAdds > wsStore.Rows.Count Then _
        Err.Raise vbObjectError + 4916, "EnsureAnalysisReviewBatchCapacity", _
                  "分析判断台帳の空き行が不足しています。案件ファイルを分けてください。"
    If historyLastRow - 1 + historyAdds > MAX_INTERNAL_STORE_DATA_ROWS Or _
       historyLastRow + historyAdds > wsHistory.Rows.Count Then _
        Err.Raise vbObjectError + 4917, "EnsureAnalysisReviewBatchCapacity", _
                  "分析判断履歴の空き行が不足しています。案件ファイルを分けてください。"
End Sub

Private Sub AppendAnalysisReviewRollbackDetail(ByRef detailText As String, _
                                               ByVal newDetail As String)
    newDetail = Trim$(newDetail)
    If Len(newDetail) = 0 Then Exit Sub
    If Len(detailText) > 0 Then detailText = detailText & " / "
    detailText = detailText & newDetail
End Sub

Private Sub ValidateAnalysisReviewSourcesBeforePersist()
    Dim ws As Worksheet
    Dim validatedReviews As Object

    Set ws = GetSheet(SH_ANALYSIS_SHIFT)
    EnsureExistingAnalysisReviewBounds ws, "資金シフト候補"
    EnsureAnalysisReviewSourceInputsSafe ws, SHIFT_ANALYSIS_STATUS_COL, _
        SHIFT_ANALYSIS_MEMO_COL, SHIFT_ANALYSIS_KEY_COL, 33, 34, 0, _
        "資金シフト候補"
    Set validatedReviews = CaptureAnalysisReviews( _
                               ws, SHIFT_ANALYSIS_STATUS_COL, _
                               SHIFT_ANALYSIS_MEMO_COL, SHIFT_ANALYSIS_KEY_COL)

    Set ws = GetSheet(SH_ANALYSIS_FLOW)
    EnsureExistingAnalysisReviewBounds ws, "資金フロー追跡"
    EnsureAnalysisReviewSourceInputsSafe ws, FLOW_ANALYSIS_STATUS_COL, _
        FLOW_ANALYSIS_MEMO_COL, FLOW_ANALYSIS_KEY_COL, 20, 0, 0, _
        "資金フロー追跡"
    Set validatedReviews = CaptureAnalysisReviews( _
                               ws, FLOW_ANALYSIS_STATUS_COL, _
                               FLOW_ANALYSIS_MEMO_COL, FLOW_ANALYSIS_KEY_COL)

    Set ws = GetSheet(SH_ANALYSIS_UNKNOWN)
    EnsureExistingAnalysisReviewBounds ws, "不明入出金"
    EnsureAnalysisReviewSourceInputsSafe ws, UNKNOWN_ANALYSIS_STATUS_COL, _
        UNKNOWN_ANALYSIS_MEMO_COL, UNKNOWN_ANALYSIS_KEY_COL, 24, 0, 3, _
        "不明入出金"
    Set validatedReviews = CaptureAnalysisReviews( _
                               ws, UNKNOWN_ANALYSIS_STATUS_COL, _
                               UNKNOWN_ANALYSIS_MEMO_COL, UNKNOWN_ANALYSIS_KEY_COL)
End Sub

Private Function BuildAnalysisReviewStoreIndex(ByVal ws As Worksheet) As Object
    Dim result As Object, lastR As Long, values As Variant, r As Long, keyText As String
    Set result = CreateObject("Scripting.Dictionary")
    result.CompareMode = vbTextCompare
    lastR = AnalysisReviewLastRowStrict(ws, "分析判断台帳")
    If lastR >= 2 Then
        values = ws.Range(ws.Cells(2, REVIEW_STORE_COL_KEY), _
                          ws.Cells(lastR, REVIEW_STORE_COL_KEY)).Value2
        For r = 1 To lastR - 1
            keyText = ReviewStoreColumnValue(values, r, lastR - 1)
            If Len(keyText) > 0 Then
                If result.Exists(keyText) Then _
                    Err.Raise vbObjectError + 4903, "BuildAnalysisReviewStoreIndex", _
                              "分析判断台帳の候補キーが重複しています: " & keyText
                result.Add keyText, r + 1
            End If
        Next r
    End If
    Set BuildAnalysisReviewStoreIndex = result
End Function

Private Sub PlanOneAnalysisReviewSheet( _
        ByVal ws As Worksheet, ByVal statusColumn As Long, ByVal memoColumn As Long, _
        ByVal keyColumn As Long, ByVal sourceName As String, ByVal fixedCategory As String, _
        ByVal firstTxColumn As Long, ByVal secondTxColumn As Long, _
        ByVal indexByKey As Object, ByVal presentKeys As Object, _
        ByRef plannedStoreAdds As Long, ByRef plannedHistoryAdds As Long)
    Dim lastR As Long, lastColumn As Long, data As Variant, r As Long, rowNo As Long
    Dim storedKey As String, baseKey As String, evidenceText As String
    Dim statusText As String, memoText As String
    Dim oldStatus As String, oldMemo As String, oldEvidence As String, oldPresence As String
    Dim changed As Boolean, wsStore As Worksheet
    If ws Is Nothing Then Exit Sub
    Set wsStore = GetSheet(SH_WORK_ANALYSIS_REVIEW)
    lastR = AnalysisReviewLastRowStrict(ws, sourceName)
    If lastR < 2 Then Exit Sub
    lastColumn = CLng(Application.Max(statusColumn, memoColumn, keyColumn, _
                                      firstTxColumn, secondTxColumn, 3))
    data = ws.Range(ws.Cells(2, 1), ws.Cells(lastR, lastColumn)).Value2
    For r = 1 To UBound(data, 1)
        storedKey = CellText(data(r, keyColumn))
        If Len(storedKey) > 0 Then
            baseKey = AnalysisBaseKey(storedKey, evidenceText)
            If Len(baseKey) = 0 Then _
                Err.Raise vbObjectError + 4904, "PlanOneAnalysisReviewSheet", _
                          sourceName & " " & CStr(r + 1) & "行目の候補キーが不正です。"
            If presentKeys.Exists(baseKey) Then _
                Err.Raise vbObjectError + 4918, "PlanOneAnalysisReviewSheet", _
                          "分析表間で候補キーが重複しています: " & baseKey
            presentKeys.Add baseKey, True
            statusText = CellText(data(r, statusColumn))
            If Len(statusText) = 0 Then statusText = ANALYSIS_STATUS_UNREVIEWED
            memoText = CellText(data(r, memoColumn))
            If statusText <> ANALYSIS_STATUS_UNREVIEWED Or Len(memoText) > 0 Or _
               indexByKey.Exists(baseKey) Then
                If indexByKey.Exists(baseKey) Then
                    rowNo = CLng(indexByKey(baseKey))
                    oldStatus = CellText(wsStore.Cells( _
                                             rowNo, REVIEW_STORE_COL_STATUS).Value2)
                    oldMemo = CellText(wsStore.Cells( _
                                           rowNo, REVIEW_STORE_COL_MEMO).Value2)
                    oldEvidence = CellText(wsStore.Cells( _
                                               rowNo, REVIEW_STORE_COL_EVIDENCE).Value2)
                    oldPresence = CellText(wsStore.Cells( _
                                               rowNo, REVIEW_STORE_COL_PRESENCE).Value2)
                Else
                    plannedStoreAdds = plannedStoreAdds + 1
                    oldStatus = vbNullString
                    oldMemo = vbNullString
                    oldEvidence = vbNullString
                    oldPresence = vbNullString
                End If
                changed = (StrComp(oldStatus, statusText, vbBinaryCompare) <> 0 Or _
                           StrComp(oldMemo, memoText, vbBinaryCompare) <> 0 Or _
                           StrComp(oldEvidence, evidenceText, vbBinaryCompare) <> 0 Or _
                           StrComp(oldPresence, "現行", vbBinaryCompare) <> 0)
                If changed Then plannedHistoryAdds = plannedHistoryAdds + 1
            End If
        End If
    Next r
End Sub

Private Sub EnsureAnalysisReviewSourceInputsSafe(ByVal ws As Worksheet, _
                                                 ByVal statusColumn As Long, _
                                                 ByVal memoColumn As Long, _
                                                 ByVal keyColumn As Long, _
                                                 ByVal firstTxColumn As Long, _
                                                 ByVal secondTxColumn As Long, _
                                                 ByVal categoryColumn As Long, _
                                                 ByVal labelText As String)
    Dim lastR As Long, reviewRange As Range
    Dim formulaCell As Range, errorCell As Range
    If ws Is Nothing Then _
        Err.Raise vbObjectError + 4925, "EnsureAnalysisReviewSourceInputsSafe", _
                  labelText & "を取得できません。"
    If Not TryGetLastUsedRowInSheet(ws, lastR) Then _
        Err.Raise vbObjectError + 4925, "EnsureAnalysisReviewSourceInputsSafe", _
                  labelText & "の最終行を確認できません。"
    If lastR < 2 Then Exit Sub
    Set reviewRange = Union( _
        ws.Range(ws.Cells(2, statusColumn), ws.Cells(lastR, statusColumn)), _
        ws.Range(ws.Cells(2, memoColumn), ws.Cells(lastR, memoColumn)), _
        ws.Range(ws.Cells(2, keyColumn), ws.Cells(lastR, keyColumn)), _
        ws.Range(ws.Cells(2, firstTxColumn), ws.Cells(lastR, firstTxColumn)))
    If secondTxColumn > 0 Then _
        Set reviewRange = Union(reviewRange, ws.Range( _
            ws.Cells(2, secondTxColumn), ws.Cells(lastR, secondTxColumn)))
    If categoryColumn > 0 Then _
        Set reviewRange = Union(reviewRange, ws.Range( _
            ws.Cells(2, categoryColumn), ws.Cells(lastR, categoryColumn)))
    If Not TryFindFirstFormulaCell(reviewRange, formulaCell) Then _
        Err.Raise vbObjectError + 4926, "EnsureAnalysisReviewSourceInputsSafe", _
                  labelText & "の数式検査に失敗しました。"
    If Not formulaCell Is Nothing Then _
        Err.Raise vbObjectError + 4926, "EnsureAnalysisReviewSourceInputsSafe", _
                  labelText & "の永続化対象に数式があります: " & _
                  formulaCell.Address(False, False)
    If Not TryFindFirstErrorConstantCell(reviewRange, errorCell) Then _
        Err.Raise vbObjectError + 4927, "EnsureAnalysisReviewSourceInputsSafe", _
                  labelText & "のExcelエラー検査に失敗しました。"
    If Not errorCell Is Nothing Then _
        Err.Raise vbObjectError + 4927, "EnsureAnalysisReviewSourceInputsSafe", _
                  labelText & "の永続化対象にExcelエラーがあります: " & _
                  errorCell.Address(False, False)
    EnsureAnalysisReviewRangeHasNoPrefix reviewRange, labelText
End Sub

Private Sub PlanMissingAnalysisReviewRows(ByVal ws As Worksheet, ByVal presentKeys As Object, _
                                          ByRef plannedHistoryAdds As Long)
    Dim lastR As Long, r As Long, keyText As String
    lastR = AnalysisReviewLastRowStrict(ws, "分析判断台帳")
    If lastR < 2 Then Exit Sub
    For r = 2 To lastR
        keyText = CellText(ws.Cells(r, REVIEW_STORE_COL_KEY).Value2)
        If Len(keyText) > 0 And Not presentKeys.Exists(keyText) Then
            If CellText(ws.Cells(r, REVIEW_STORE_COL_PRESENCE).Value2) <> "消滅" Then _
                plannedHistoryAdds = plannedHistoryAdds + 1
        End If
    Next r
End Sub

Private Sub PersistOneAnalysisReviewSheet( _
        ByVal ws As Worksheet, ByVal statusColumn As Long, ByVal memoColumn As Long, _
        ByVal keyColumn As Long, ByVal sourceName As String, ByVal fixedCategory As String, _
        ByVal firstTxColumn As Long, ByVal secondTxColumn As Long, _
        ByVal indexByKey As Object, ByVal presentKeys As Object, ByVal reasonText As String)
    Dim lastR As Long, lastColumn As Long, data As Variant, r As Long
    Dim storedKey As String, baseKey As String, evidenceText As String
    Dim statusText As String, memoText As String, categoryText As String, txIDs As String
    If ws Is Nothing Then Exit Sub
    lastR = AnalysisReviewLastRowStrict(ws, sourceName)
    If lastR < 2 Then Exit Sub
    lastColumn = CLng(Application.Max(statusColumn, memoColumn, keyColumn, _
                                      firstTxColumn, secondTxColumn, 3))
    data = ws.Range(ws.Cells(2, 1), ws.Cells(lastR, lastColumn)).Value2
    For r = 1 To UBound(data, 1)
        storedKey = CellText(data(r, keyColumn))
        If Len(storedKey) > 0 Then
            baseKey = AnalysisBaseKey(storedKey, evidenceText)
            If Len(baseKey) = 0 Then _
                Err.Raise vbObjectError + 4904, "PersistOneAnalysisReviewSheet", _
                          sourceName & " " & CStr(r + 1) & "行目の候補キーが不正です。"
            If presentKeys.Exists(baseKey) Then _
                Err.Raise vbObjectError + 4918, "PersistOneAnalysisReviewSheet", _
                          "分析表間で候補キーが重複しています: " & baseKey
            presentKeys.Add baseKey, True
            statusText = CellText(data(r, statusColumn))
            If Len(statusText) = 0 Then statusText = ANALYSIS_STATUS_UNREVIEWED
            memoText = CellText(data(r, memoColumn))
            categoryText = fixedCategory
            If Len(categoryText) = 0 Then categoryText = Replace(CellText(data(r, 3)), "候補", "")
            txIDs = CellText(data(r, firstTxColumn))
            If secondTxColumn > 0 Then txIDs = JoinAnalysisReviewIDs(txIDs, _
                                                   CellText(data(r, secondTxColumn)))
            If statusText <> ANALYSIS_STATUS_UNREVIEWED Or Len(memoText) > 0 Or _
               indexByKey.Exists(baseKey) Then
                UpsertAnalysisReviewStore baseKey, sourceName, categoryText, statusText, memoText, _
                    evidenceText, txIDs, "現行", reasonText, indexByKey
            End If
        End If
    Next r
End Sub

Private Sub UpsertAnalysisReviewStore( _
        ByVal baseKey As String, ByVal sourceName As String, ByVal categoryText As String, _
        ByVal statusText As String, ByVal memoText As String, ByVal evidenceText As String, _
        ByVal txIDs As String, ByVal presenceText As String, ByVal reasonText As String, _
        ByVal indexByKey As Object)
    Dim ws As Worksheet, rowNo As Long, c As Long
    Dim oldStatus As String, oldMemo As String, oldEvidence As String, oldPresence As String
    Dim changed As Boolean, effectiveReason As String, isNewRow As Boolean
    Dim currentData As Variant, expectedData As Variant
    Dim writtenRange As Range
    If Not mReviewPersistActive Then _
        Err.Raise vbObjectError + 4919, "UpsertAnalysisReviewStore", _
                  "分析判断台帳の書込トランザクションが開始されていません。"
    Set ws = GetSheet(SH_WORK_ANALYSIS_REVIEW)
    If indexByKey.Exists(baseKey) Then
        rowNo = CLng(indexByKey(baseKey))
        oldStatus = CellText(ws.Cells(rowNo, REVIEW_STORE_COL_STATUS).Value2)
        oldMemo = CellText(ws.Cells(rowNo, REVIEW_STORE_COL_MEMO).Value2)
        oldEvidence = CellText(ws.Cells(rowNo, REVIEW_STORE_COL_EVIDENCE).Value2)
        oldPresence = CellText(ws.Cells(rowNo, REVIEW_STORE_COL_PRESENCE).Value2)
    Else
        isNewRow = True
        rowNo = mReviewStoreNextRow
        mReviewStoreNextRow = mReviewStoreNextRow + 1
        mReviewActualStoreAdds = mReviewActualStoreAdds + 1
        indexByKey.Add baseKey, rowNo
    End If
    changed = (StrComp(oldStatus, statusText, vbBinaryCompare) <> 0 Or _
               StrComp(oldMemo, memoText, vbBinaryCompare) <> 0 Or _
               StrComp(oldEvidence, evidenceText, vbBinaryCompare) <> 0 Or _
               StrComp(oldPresence, presenceText, vbBinaryCompare) <> 0)
    If Not changed And _
       StrComp(CellText(ws.Cells(rowNo, REVIEW_STORE_COL_SOURCE).Value2), _
               sourceName, vbBinaryCompare) = 0 And _
       StrComp(CellText(ws.Cells(rowNo, REVIEW_STORE_COL_CATEGORY).Value2), _
               categoryText, vbBinaryCompare) = 0 And _
       StrComp(CellText(ws.Cells(rowNo, REVIEW_STORE_COL_TX_IDS).Value2), _
               txIDs, vbBinaryCompare) = 0 Then Exit Sub

    effectiveReason = reasonText
    If Len(effectiveReason) = 0 Then
        If Len(oldEvidence) > 0 And StrComp(oldEvidence, evidenceText, vbBinaryCompare) <> 0 Then
            effectiveReason = "根拠または分析条件の変更"
        ElseIf oldPresence = "消滅" And presenceText = "現行" Then
            effectiveReason = "候補が再出現"
        ElseIf Len(oldStatus) = 0 Then
            effectiveReason = "判断台帳へ登録"
        Else
            effectiveReason = "確認内容を更新"
        End If
    End If
    If changed Then AppendAnalysisReviewHistory baseKey, sourceName, categoryText, _
        oldStatus, statusText, oldMemo, memoText, oldEvidence, evidenceText, effectiveReason

    ReDim expectedData(1 To 1, 1 To ANALYSIS_REVIEW_STORE_LAST_COL)
    Set writtenRange = ws.Range(ws.Cells(rowNo, 1), _
                                ws.Cells(rowNo, ANALYSIS_REVIEW_STORE_LAST_COL))
    If Not isNewRow Then
        currentData = writtenRange.Value2
        For c = 1 To ANALYSIS_REVIEW_STORE_LAST_COL
            expectedData(1, c) = currentData(1, c)
        Next c
    End If
    expectedData(1, REVIEW_STORE_COL_KEY) = AnalysisReviewExpectedValue2(baseKey)
    expectedData(1, REVIEW_STORE_COL_SOURCE) = AnalysisReviewExpectedValue2(sourceName)
    expectedData(1, REVIEW_STORE_COL_CATEGORY) = AnalysisReviewExpectedValue2(categoryText)
    expectedData(1, REVIEW_STORE_COL_STATUS) = AnalysisReviewExpectedValue2(statusText)
    expectedData(1, REVIEW_STORE_COL_MEMO) = AnalysisReviewExpectedValue2(memoText)
    expectedData(1, REVIEW_STORE_COL_EVIDENCE) = AnalysisReviewExpectedValue2(evidenceText)
    expectedData(1, REVIEW_STORE_COL_TX_IDS) = AnalysisReviewExpectedValue2(txIDs)
    expectedData(1, REVIEW_STORE_COL_UPDATED_AT) = CDbl(mReviewCommitStamp)
    expectedData(1, REVIEW_STORE_COL_PRESENCE) = AnalysisReviewExpectedValue2(presenceText)
    expectedData(1, REVIEW_STORE_COL_PREVIOUS_STATUS) = AnalysisReviewExpectedValue2(oldStatus)
    expectedData(1, REVIEW_STORE_COL_PREVIOUS_EVIDENCE) = AnalysisReviewExpectedValue2(oldEvidence)
    expectedData(1, REVIEW_STORE_COL_REASON) = AnalysisReviewExpectedValue2(effectiveReason)
    expectedData(1, REVIEW_STORE_COL_USER) = AnalysisReviewExpectedValue2(mReviewCommitUser)
    writtenRange.Value2 = expectedData
    If Not RangeValue2MatchesMatrixStrict(writtenRange, expectedData, 1, _
                                          ANALYSIS_REVIEW_STORE_LAST_COL) Then _
        Err.Raise vbObjectError + 4920, "UpsertAnalysisReviewStore", _
                  "分析判断台帳の書込読戻しが全列・型で一致しません: " & baseKey
End Sub

Private Sub MarkMissingAnalysisReviewRows(ByVal ws As Worksheet, ByVal presentKeys As Object, _
                                          ByVal reasonText As String)
    Dim lastR As Long, r As Long, keyText As String, oldPresence As String
    Dim effectiveReason As String
    lastR = AnalysisReviewLastRowStrict(ws, "分析判断台帳")
    If lastR < 2 Then Exit Sub
    effectiveReason = reasonText
    If Len(effectiveReason) = 0 Then effectiveReason = "現在条件では候補なし"
    For r = 2 To lastR
        keyText = CellText(ws.Cells(r, REVIEW_STORE_COL_KEY).Value)
        If Len(keyText) > 0 And Not presentKeys.Exists(keyText) Then
            oldPresence = CellText(ws.Cells(r, REVIEW_STORE_COL_PRESENCE).Value)
            If oldPresence <> "消滅" Then
                AppendAnalysisReviewHistory keyText, _
                    CellText(ws.Cells(r, REVIEW_STORE_COL_SOURCE).Value), _
                    CellText(ws.Cells(r, REVIEW_STORE_COL_CATEGORY).Value), _
                    CellText(ws.Cells(r, REVIEW_STORE_COL_STATUS).Value), _
                    CellText(ws.Cells(r, REVIEW_STORE_COL_STATUS).Value), _
                    CellText(ws.Cells(r, REVIEW_STORE_COL_MEMO).Value), _
                    CellText(ws.Cells(r, REVIEW_STORE_COL_MEMO).Value), _
                    CellText(ws.Cells(r, REVIEW_STORE_COL_EVIDENCE).Value), _
                    CellText(ws.Cells(r, REVIEW_STORE_COL_EVIDENCE).Value), effectiveReason
                WriteMissingAnalysisReviewRow ws, r, effectiveReason
            End If
        End If
    Next r
End Sub

Private Sub WriteMissingAnalysisReviewRow(ByVal ws As Worksheet, ByVal rowNo As Long, _
                                          ByVal effectiveReason As String)
    Dim expectedData As Variant, writtenRange As Range
    Set writtenRange = ws.Range(ws.Cells(rowNo, 1), _
                                ws.Cells(rowNo, ANALYSIS_REVIEW_STORE_LAST_COL))
    expectedData = writtenRange.Value2
    expectedData(1, REVIEW_STORE_COL_UPDATED_AT) = CDbl(mReviewCommitStamp)
    expectedData(1, REVIEW_STORE_COL_PRESENCE) = AnalysisReviewExpectedValue2("消滅")
    expectedData(1, REVIEW_STORE_COL_REASON) = AnalysisReviewExpectedValue2(effectiveReason)
    expectedData(1, REVIEW_STORE_COL_USER) = AnalysisReviewExpectedValue2(mReviewCommitUser)
    writtenRange.Value2 = expectedData
    If Not RangeValue2MatchesMatrixStrict(writtenRange, expectedData, 1, _
                                          ANALYSIS_REVIEW_STORE_LAST_COL) Then _
        Err.Raise vbObjectError + 4921, "WriteMissingAnalysisReviewRow", _
                  "消滅した分析判断の書込読戻しが全列・型で一致しません。"
End Sub

Private Sub AppendAnalysisReviewHistory( _
        ByVal baseKey As String, ByVal sourceName As String, ByVal categoryText As String, _
        ByVal oldStatus As String, ByVal newStatus As String, ByVal oldMemo As String, _
        ByVal newMemo As String, ByVal oldEvidence As String, ByVal newEvidence As String, _
        ByVal reasonText As String)
    Dim ws As Worksheet, rowNo As Long, historyID As String
    Dim expectedData As Variant
    Dim writtenRange As Range
    If Not mReviewPersistActive Then _
        Err.Raise vbObjectError + 4922, "AppendAnalysisReviewHistory", _
                  "分析判断履歴の書込トランザクションが開始されていません。"
    Set ws = GetSheet(SH_WORK_ANALYSIS_HISTORY)
    ReDim expectedData(1 To 1, 1 To ANALYSIS_HISTORY_STORE_LAST_COL)
    rowNo = mReviewHistoryNextRow
    mReviewHistoryNextRow = mReviewHistoryNextRow + 1
    mReviewActualHistoryAdds = mReviewActualHistoryAdds + 1
    historyID = "RH-" & Format$(mReviewCommitStamp, "yyyymmddhhnnss") & _
                "-" & Format$(rowNo - 1, "000000")
    expectedData(1, 1) = AnalysisReviewExpectedValue2(historyID)
    expectedData(1, 2) = AnalysisReviewExpectedValue2(baseKey)
    expectedData(1, 3) = CDbl(mReviewCommitStamp)
    expectedData(1, 4) = AnalysisReviewExpectedValue2(mReviewCommitUser)
    expectedData(1, 5) = AnalysisReviewExpectedValue2(sourceName)
    expectedData(1, 6) = AnalysisReviewExpectedValue2(categoryText)
    expectedData(1, 7) = AnalysisReviewExpectedValue2(oldStatus)
    expectedData(1, 8) = AnalysisReviewExpectedValue2(newStatus)
    expectedData(1, 9) = AnalysisReviewExpectedValue2(oldMemo)
    expectedData(1, 10) = AnalysisReviewExpectedValue2(newMemo)
    expectedData(1, 11) = AnalysisReviewExpectedValue2(oldEvidence)
    expectedData(1, 12) = AnalysisReviewExpectedValue2(newEvidence)
    expectedData(1, 13) = AnalysisReviewExpectedValue2(reasonText)
    Set writtenRange = ws.Range(ws.Cells(rowNo, 1), _
                                ws.Cells(rowNo, ANALYSIS_HISTORY_STORE_LAST_COL))
    writtenRange.Value2 = expectedData
    If Not RangeValue2MatchesMatrixStrict(writtenRange, expectedData, 1, _
                                          ANALYSIS_HISTORY_STORE_LAST_COL) Then _
        Err.Raise vbObjectError + 4923, "AppendAnalysisReviewHistory", _
                  "分析判断履歴の書込読戻しが全列・型で一致しません。"
End Sub

Private Function AnalysisReviewExpectedValue2(ByVal valueIn As Variant) As Variant
    If IsError(valueIn) Or IsNull(valueIn) Then _
        Err.Raise vbObjectError + 4924, "AnalysisReviewExpectedValue2", _
                  "分析判断台帳へ保存できない値があります。"
    If IsEmpty(valueIn) Then
        AnalysisReviewExpectedValue2 = Empty
    ElseIf VarType(valueIn) = vbString And Len(CStr(valueIn)) = 0 Then
        AnalysisReviewExpectedValue2 = Empty
    ElseIf VarType(valueIn) = vbDate Then
        AnalysisReviewExpectedValue2 = CDbl(valueIn)
    ElseIf VarType(valueIn) <> vbString And VarType(valueIn) <> vbBoolean And _
           IsNumeric(valueIn) Then
        AnalysisReviewExpectedValue2 = CDbl(valueIn)
    Else
        AnalysisReviewExpectedValue2 = valueIn
    End If
End Function

Private Function AnalysisReviewUserName() As String
    On Error Resume Next
    AnalysisReviewUserName = Trim$(Application.UserName)
    If Len(AnalysisReviewUserName) = 0 Then AnalysisReviewUserName = Trim$(Environ$("Username"))
    If Len(AnalysisReviewUserName) = 0 Then AnalysisReviewUserName = "確認者未設定"
    On Error GoTo 0
End Function

Private Function JoinAnalysisReviewIDs(ByVal firstID As String, ByVal secondID As String) As String
    If Len(firstID) = 0 Then
        JoinAnalysisReviewIDs = secondID
    ElseIf Len(secondID) = 0 Or StrComp(firstID, secondID, vbTextCompare) = 0 Then
        JoinAnalysisReviewIDs = firstID
    Else
        JoinAnalysisReviewIDs = firstID & ";" & secondID
    End If
End Function

Private Function ReviewStoreColumnValue(ByVal values As Variant, ByVal itemIndex As Long, _
                                        ByVal itemCount As Long) As String
    If itemCount = 1 Then
        ReviewStoreColumnValue = CellText(values)
    Else
        ReviewStoreColumnValue = CellText(values(itemIndex, 1))
    End If
End Function


Private Function ReviewEvidenceDigestIsValid(ByVal digestText As String) As Boolean
    Dim i As Long, characterText As String
    If Len(digestText) <> 17 Or Mid$(digestText, 9, 1) <> "-" Then Exit Function
    For i = 1 To Len(digestText)
        If i <> 9 Then
            characterText = UCase$(Mid$(digestText, i, 1))
            If InStr(1, "0123456789ABCDEF", characterText, vbBinaryCompare) = 0 Then Exit Function
        End If
    Next i
    ReviewEvidenceDigestIsValid = True
End Function

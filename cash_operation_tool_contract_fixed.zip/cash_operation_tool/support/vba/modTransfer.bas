﻿Attribute VB_Name = "modTransfer"
Option Explicit

Private Const MANUAL_ACCOUNT_CAPACITY_BASE_COLUMNS As Long = 16
Private Const MANUAL_ACCOUNT_PERSON_COLUMNS As Long = 4
Private Const MANUAL_ACCOUNT_CAPACITY_LONG_MAX As Double = 2147483647#

Private Const MAX_ACCOUNT_REBUILD_RECORDS As Long = 100000
Private Const REL_SNAPSHOT_COL_KEY As Long = 1
Private Const REL_SNAPSHOT_COL_HAS_FORMULA As Long = 2
Private Const REL_SNAPSHOT_COL_VALUE2 As Long = 3
Private Const REL_SNAPSHOT_COL_FORMULA As Long = 4
Private Const REL_SNAPSHOT_COL_VALUE_TYPE As Long = 5
Private Const REL_SNAPSHOT_COL_PREFIX As Long = 6
Private Const REL_SNAPSHOT_LAST_COL As Long = REL_SNAPSHOT_COL_PREFIX
Private Const TRANSFER_RECOVERY_HARD_BARRIER_ERROR As Long = _
    vbObjectError + 4499
Private Const TRANSFER_RECOVERY_HARD_BARRIER_SOURCE As String = _
    "TransferRecoveryFatal/"

'旧版マクロ名は残し、既存ボタンや利用者のショートカットを壊さない。
Public Sub TransferCurrentAccount()
    SaveCurrentAccount
End Sub

Public Sub TransferCurrentAccountKeepBankBranch()
    SaveCurrentAccountCore KEEP_BANK_BRANCH, False
End Sub

Public Sub TransferCurrentAccountNextBranch()
    SaveCurrentAccountNextBranch
End Sub

Public Sub SaveCurrentAccount()
    SaveCurrentAccountCore "", False
End Sub

Public Sub SaveCurrentAccountNextBranch()
    If IsEditMode() Then
        ShowNextBranchEditModeStatus
        Exit Sub
    End If
    SaveCurrentAccountCore KEEP_BANK_BRANCH_PERSON_TYPE, True
End Sub

Private Sub ShowNextBranchEditModeStatus()
    Dim entryEvents As Boolean, eventStateDetail As String
    Dim restoreDetail As String
    Dim statusErrorNumber As Long, statusErrorDescription As String
    Dim recoveryEnforcementFailed As Boolean

    If Not TryGetTransferEnableEvents(entryEvents, eventStateDetail) Then
        On Error Resume Next
        MsgBox "次枝番登録の案内前にExcelイベント状態を取得できませんでした。" & _
               vbCrLf & "状態表示は書き込んでいません。 " & eventStateDetail, _
               vbCritical, "Excel状態を確認できません"
        On Error GoTo 0
        Exit Sub
    End If
    If Not TrySetTransferEnableEventsExact(False, eventStateDetail) Then
        On Error Resume Next
        MsgBox "次枝番登録の案内前にExcelイベントを停止して確認できませんでした。" & _
               vbCrLf & "状態表示は書き込まず、イベント状態をFalseへ収束できません。 " & _
               eventStateDetail, vbCritical, "Excel状態を確認できません"
        On Error GoTo 0
        Exit Sub
    End If

    On Error Resume Next
    Err.Clear
    SetInputStatus "訂正中は、先に「訂正を反映」を実行してください。"
    statusErrorNumber = Err.Number
    statusErrorDescription = Err.Description
    Err.Clear
    On Error GoTo 0

    If Not TryRestoreTransferEnableEvents( _
               entryEvents, "次枝番登録の案内", False, False, False, _
               recoveryEnforcementFailed, restoreDetail) Then Exit Sub
    If statusErrorNumber <> 0 Then
        On Error Resume Next
        MsgBox "訂正中の案内を状態欄へ書き込めませんでした。Err " & _
               CStr(statusErrorNumber) & ": " & statusErrorDescription, _
               vbExclamation, "状態表示を更新できません"
        On Error GoTo 0
    End If
End Sub


Private Function ManualAccountSnapshotNeedsRecheck( _
        ByVal previouslyCheckedRows As Double, ByVal finalRows As Double) As Boolean
    If previouslyCheckedRows < 0# Or finalRows < previouslyCheckedRows Then _
        Err.Raise vbObjectError + 4093, "ManualAccountSnapshotNeedsRecheck", _
                  "口座登録の容量再確認範囲が不正です。"
#If Win64 Or Mac Then
    ManualAccountSnapshotNeedsRecheck = _
        (previouslyCheckedRows <= 150000# And finalRows > 150000#)
#Else
    If previouslyCheckedRows <= 50000# Then
        ManualAccountSnapshotNeedsRecheck = (finalRows > 50000#)
    ElseIf previouslyCheckedRows <= 75000# Then
        ManualAccountSnapshotNeedsRecheck = (finalRows > 75000#)
    End If
#End If
End Function

Private Function ManualAccountSnapshotWorkRows( _
        ByVal preparedTxRows As Long, ByVal preparedBalanceRows As Long, _
        ByVal txStoreRows As Long, ByVal balanceStoreRows As Long, _
        ByVal accountStoreRows As Long, ByVal personCandidateRows As Long) As Double
    Dim cellWork As Double
    If preparedTxRows < 0 Or preparedBalanceRows < 0 Or txStoreRows < 0 Or _
       balanceStoreRows < 0 Or accountStoreRows < 0 Or personCandidateRows < 0 Then _
        Err.Raise vbObjectError + 4091, "ManualAccountSnapshotWorkRows", _
                  "口座登録の安全退避行数に負数が含まれています。"
    '既存4表は全体snapshotに加え、照合・圧縮処理の元/出力配列を最大2本保持する。
    '入力準備2配列と合わせた同時保持セル数を16列相当行へ換算する。
    cellWork = CDbl(preparedTxRows) * CDbl(WORK_TX_COL_PERSON_ID) + _
               CDbl(preparedBalanceRows) * CDbl(WORK_BAL_COL_PERSON_ID) + _
               3# * (CDbl(txStoreRows) * CDbl(WORK_TX_COL_PERSON_ID) + _
                     CDbl(balanceStoreRows) * CDbl(WORK_BAL_COL_PERSON_ID) + _
                     CDbl(accountStoreRows) * CDbl(ACC_COL_TRANSFER_ID) + _
                     CDbl(personCandidateRows) * _
                     CDbl(MANUAL_ACCOUNT_PERSON_COLUMNS))
    ManualAccountSnapshotWorkRows = ManualAccountEquivalentWorkRows(cellWork)
End Function

Private Function ManualAccountEquivalentWorkRows(ByVal cellWork As Double) As Double
    Dim workRows As Double
    If cellWork < 0# Or _
       cellWork > MANUAL_ACCOUNT_CAPACITY_LONG_MAX * _
                  CDbl(MANUAL_ACCOUNT_CAPACITY_BASE_COLUMNS) Then _
        Err.Raise vbObjectError + 4094, "ManualAccountEquivalentWorkRows", _
                  "口座登録の安全退避規模を16列相当行へ換算できません。"
    workRows = Int( _
        (cellWork + CDbl(MANUAL_ACCOUNT_CAPACITY_BASE_COLUMNS) - 1#) / _
        CDbl(MANUAL_ACCOUNT_CAPACITY_BASE_COLUMNS))
    If workRows < 0# Or workRows > MANUAL_ACCOUNT_CAPACITY_LONG_MAX Then _
        Err.Raise vbObjectError + 4094, "ManualAccountEquivalentWorkRows", _
                  "口座登録の安全退避規模を16列相当行へ換算できません。"
    ManualAccountEquivalentWorkRows = workRows
End Function

Private Function ShouldReuseEditPersonID(ByVal oldPersonName As String, _
                                         ByVal newPersonName As String) As Boolean
    Dim oldKey As String, newKey As String
    oldKey = NormalizePersonNameKey(oldPersonName)
    newKey = NormalizePersonNameKey(newPersonName)
    If Len(oldKey) = 0 Or Len(newKey) = 0 Then Exit Function
    ShouldReuseEditPersonID = _
        (StrComp(oldKey, newKey, vbBinaryCompare) = 0)
End Function

Private Sub SaveCurrentAccountCore(Optional ByVal keepOverride As String = "", _
                                   Optional ByVal nextBranchAfter As Boolean = False)
    Dim wsIn As Worksheet, wsTx As Worksheet, wsBal As Worksheet, wsAcc As Worksheet
    Dim wsPerson As Worksheet
    Dim bankName As String, branchName As String, personName As String
    Dim oldPersonName As String
    Dim relationshipText As String, accountType As String, accountNo As String
    Dim rawOpen As Variant, rawClose As Variant, openDate As Variant, closeDate As Variant
    Dim dateOK As Boolean, timeOK As Boolean, amountOK As Boolean
    Dim currentYear As Long, currentMonth As Long, currentDay As Long, yearAdd As Long
    Dim txDate As Variant, txTime As Variant, amountValue As Variant
    Dim withdrawValue As Variant, depositValue As Variant, balanceValue As Variant
    Dim tekiyoText As String, previousTekiyo As String
    Dim validationCount As Long, firstMessage As String, firstAddress As String
    Dim r As Long, c As Long, memoCol As Long, lastInputRow As Long
    Dim txCount As Long, balCount As Long, userTxCount As Long
    Dim txCapacity As Long, balCapacity As Long, storedBalanceCount As Long
    Dim preservedHiddenBalanceCount As Long
    Dim txData() As Variant, balData() As Variant
    Dim accountID As String, editAccountID As String, duplicateID As String
    Dim transferID As String, personID As String, nextAccountNo As String
    Dim conflictingPersonID As String, conflictingPersonName As String
    Dim focusPolicy As String
    Dim oldTx As Variant, oldBal As Variant, oldMaster As Variant
    Dim oldPersonCandidateRel As Variant
    Dim txStoreSnapshot As Variant, balanceStoreSnapshot As Variant, accountStoreSnapshot As Variant
    Dim personCandidateSnapshot As Variant
    Dim idCounterSnapshot As Variant
    Dim oldTxCount As Long, oldBalCount As Long, oldMasterRow As Long
    Dim oldPersonCandidateRelCount As Long
    Dim txStoreRows As Long, balanceStoreRows As Long, accountStoreRows As Long
    Dim personCandidateRows As Long
    Dim preflightTxStoreRows As Long, preflightBalanceStoreRows As Long
    Dim preflightAccountStoreRows As Long, preflightPersonCandidateRows As Long
    Dim existingSnapshotWorkRows As Double, snapshotWorkRows As Double
    Dim writeStarted As Boolean, committed As Boolean, idCountersCaptured As Boolean
    Dim rollbackVerified As Boolean, relationshipStateMatches As Boolean
    Dim storeSnapshotsCaptured As Boolean, storeRestoreFailed As Boolean
    Dim personCandidateSnapshotCaptured As Boolean
    Dim counterRestoreFailed As Boolean, recoveryRequired As Boolean
    Dim recoveryConfirmed As Boolean, recoveryEnforcementFailed As Boolean
    Dim cleanupSucceeded As Boolean
    Dim newTxFirst As Long, newBalFirst As Long
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim rollbackDetail As String, rollbackVerifyDetail As String
    Dim balanceStructureDetail As String
    Dim postProcessDetail As String, postProcessSuffix As String, retentionWarning As String
    Dim appRestoreErrorNumber As Long, appRestoreErrorDescription As String
    Dim keyRestoreErrorNumber As Long, keyRestoreErrorDescription As String
    Dim entryEvents As Boolean, entryEventsCaptured As Boolean
    Dim applicationLeaseStarted As Boolean, eventsSafeForWorkbookWrites As Boolean
    Dim eventStateDetail As String, finishDetail As String
    Dim recoveryGateDetail As String

    On Error GoTo EH
    If Not TryGetTransferEnableEvents(entryEvents, eventStateDetail) Then
        On Error Resume Next
        MsgBox "口座登録を開始する前にExcelイベント状態を取得できませんでした。" & vbCrLf & _
               "データは変更していません。現在のブックを上書き保存せず、Excelを再起動して確認してください。" & _
               vbCrLf & eventStateDetail, vbCritical, "Excel状態を確認できません"
        On Error GoTo 0
        Exit Sub
    End If
    entryEventsCaptured = True
    AppBegin "内部データの安全確認中..."
    applicationLeaseStarted = True
    If Not RequireToolReady() Then
        FinishTransferApplicationLease applicationLeaseStarted, entryEvents, _
            entryEventsCaptured, "口座登録・訂正", False, finishDetail
        Exit Sub
    End If
    If Not SheetExists(SH_PERSON_CAND) Then
        SetInputStatus "人物候補の保存領域がないため登録できません。診断を実行してください。", True
        MsgBox "人物候補の保存領域が見つかりません。" & vbCrLf & _
               "このブックで登録を続けず、診断用コピーを残して復旧してください。", _
               vbCritical, "案件ファイルを使用できません"
        FinishTransferApplicationLease applicationLeaseStarted, entryEvents, _
            entryEventsCaptured, "口座登録・訂正", False, finishDetail
        Exit Sub
    End If
    Set wsIn = GetSheet(SH_INPUT)
    Set wsTx = GetSheet(SH_WORK_TX)
    Set wsBal = GetSheet(SH_WORK_BAL)
    Set wsAcc = GetSheet(SH_WORK_ACCOUNT)
    Set wsPerson = GetSheet(SH_PERSON_CAND)
    '人物整合性検査も既存ストアを配列へ読み込む。最初の全表配列確保より前に
    '既存4ストアだけの規模を判定し、32bit版で安全停止を後置しない。
    preflightTxStoreRows = CLng(Application.Max(0, _
        LastDataRowInColumns(wsTx, 1, WORK_TX_COL_PERSON_ID) - 1))
    preflightBalanceStoreRows = CLng(Application.Max(0, _
        LastDataRowInColumns(wsBal, 1, WORK_BAL_COL_PERSON_ID) - 1))
    preflightAccountStoreRows = CLng(Application.Max(0, _
        LastDataRowInColumns(wsAcc, 1, ACC_COL_TRANSFER_ID) - 1))
    preflightPersonCandidateRows = CLng(Application.Max(0, _
        LastDataRowInColumns(wsPerson, 1, 4) - 1))
    existingSnapshotWorkRows = ManualAccountSnapshotWorkRows( _
        0, 0, preflightTxStoreRows, preflightBalanceStoreRows, _
        preflightAccountStoreRows, preflightPersonCandidateRows)
    If existingSnapshotWorkRows > 2147483647# Then _
        Err.Raise vbObjectError + 4092, "SaveCurrentAccountCore", _
                  "口座登録の既存保管規模を計算できません。"
    If Not ConfirmLargeArrayOperation(CLng(existingSnapshotWorkRows), _
            "口座の登録・訂正（既存保管の事前安全検査）") Then
        SetInputStatus "口座登録・訂正を開始せず中止しました。入力内容は保持しています。"
        FinishTransferApplicationLease applicationLeaseStarted, entryEvents, _
            entryEventsCaptured, "口座登録・訂正", False, finishDetail
        Exit Sub
    End If
    If Not RequireInternalStoresSafeForWrite() Then
        FinishTransferApplicationLease applicationLeaseStarted, entryEvents, _
            entryEventsCaptured, "口座登録・訂正", False, finishDetail
        Exit Sub
    End If
    If GetStateValue(STATE_INPUT_DATE_CONFIG_SAFE, STATE_FALSE) <> STATE_TRUE Then
        SetInputStatus "入力後に暦設定が変更された可能性があるため登録できません。入力を消去し、現在の設定で再入力してください。", True
        MsgBox "未登録入力の日付解釈を安全に確認できません。" & vbCrLf & _
               "誤った年で登録しないため処理を中止しました。入力内容を控えたうえで［入力内容を消去］を実行し、現在の暦設定で再入力してください。", _
               vbExclamation, "日付設定を確認できません"
        FinishTransferApplicationLease applicationLeaseStarted, entryEvents, _
            entryEventsCaptured, "口座登録・訂正", False, finishDetail
        Exit Sub
    End If
    AppProgress "入力内容を検証しています..."
    lastInputRow = LastInputTransactionRow(wsIn)
    CheckUnsupportedInputCells wsIn, lastInputRow, validationCount, firstMessage, firstAddress
    If Not EnsureBalanceInputStructureCurrent(wsIn, balanceStructureDetail) Then
        AddValidationError balanceStructureDetail, CELL_OPEN_DATE, _
                           validationCount, firstMessage, firstAddress
    End If

    bankName = CellText(wsIn.Range(CELL_BANK).Value)
    branchName = CellText(wsIn.Range(CELL_BRANCH).Value)
    personName = CellText(wsIn.Range(CELL_PERSON).Value)
    editAccountID = CurrentEditAccountID()
    relationshipText = CellText(wsIn.Range(CELL_RELATIONSHIP).Value)
    '新規登録だけは人物候補から続柄を補完する。訂正で続柄を明示的に空欄へ
    '変更した場合は、旧候補値を勝手に戻さない。
    If Len(relationshipText) = 0 And Len(editAccountID) = 0 Then _
        relationshipText = RelationshipForName(personName)
    accountType = CellText(wsIn.Range(CELL_ACCOUNT_TYPE).Value)
    accountNo = NormalizeAccountHyphen(CellText(wsIn.Range(CELL_ACCOUNT_NO).Value))
    rawOpen = wsIn.Range(CELL_OPEN_DATE).Value
    rawClose = wsIn.Range(CELL_CLOSE_DATE).Value

    AddRequiredError bankName, "銀行名を入力してください。", CELL_BANK, validationCount, firstMessage, firstAddress
    AddRequiredError personName, "氏名を入力してください。", CELL_PERSON, validationCount, firstMessage, firstAddress
    AddRequiredError accountType, "科目を入力してください。候補にない科目も直接入力できます。", CELL_ACCOUNT_TYPE, validationCount, firstMessage, firstAddress
    AddRequiredError accountNo, "口座番号を入力してください。", CELL_ACCOUNT_NO, validationCount, firstMessage, firstAddress
    AddMaxLengthError bankName, 100, "銀行名", CELL_BANK, validationCount, firstMessage, firstAddress
    AddMaxLengthError branchName, 100, "支店名", CELL_BRANCH, validationCount, firstMessage, firstAddress
    AddMaxLengthError personName, 100, "氏名", CELL_PERSON, validationCount, firstMessage, firstAddress
    AddMaxLengthError relationshipText, 50, "続柄", CELL_RELATIONSHIP, validationCount, firstMessage, firstAddress
    AddMaxLengthError accountType, 100, "科目", CELL_ACCOUNT_TYPE, validationCount, firstMessage, firstAddress
    AddMaxLengthError accountNo, 100, "口座番号", CELL_ACCOUNT_NO, validationCount, firstMessage, firstAddress

    If HasText(rawOpen) Then
        openDate = ResolveAccountDateInput(rawOpen, dateOK)
        If Not dateOK Then AddValidationError "口座開設日を日付として解釈できません。", CELL_OPEN_DATE, validationCount, firstMessage, firstAddress
    Else
        openDate = ""
    End If
    If HasText(rawClose) Then
        closeDate = ResolveAccountDateInput(rawClose, dateOK)
        If Not dateOK Then AddValidationError "口座解約日を日付として解釈できません。", CELL_CLOSE_DATE, validationCount, firstMessage, firstAddress
    Else
        closeDate = ""
    End If
    If IsDate(openDate) And IsDate(closeDate) Then
        If CDate(openDate) > CDate(closeDate) Then
            AddValidationError "口座解約日が口座開設日より前です。", CELL_CLOSE_DATE, validationCount, firstMessage, firstAddress
        End If
    End If

    If Len(editAccountID) > 0 And FindAccountRowByID(editAccountID) = 0 Then
        AddValidationError "訂正対象の口座が見つかりません。登録済み口座から選び直してください。", CELL_BANK, validationCount, firstMessage, firstAddress
    End If
    If Len(editAccountID) > 0 Then
        oldMasterRow = FindAccountRowByID(editAccountID)
        If oldMasterRow > 0 Then
            oldPersonName = CellText(wsAcc.Cells(oldMasterRow, ACC_COL_PERSON).Value)
            If ShouldReuseEditPersonID(oldPersonName, personName) Then
                personID = CellText(wsAcc.Cells(oldMasterRow, ACC_COL_PERSON_ID).Value)
            Else
                '氏名が実質的に変わった訂正は旧人物IDを引き継がず、
                '新しい氏名＋続柄で既存人物IDを自動解決する。
                personID = PersonIDForName(personName, relationshipText)
            End If
            If ShouldReuseEditPersonID(oldPersonName, personName) And Len(personID) = 0 Then
                AddValidationError "訂正元の人物IDがありません。口座一覧で登録内容を確認してください。", _
                                   CELL_PERSON, validationCount, firstMessage, firstAddress
            ElseIf Len(personID) > 0 And _
                   FindConflictingPersonIDForRelationshipChange(personID, personName, relationshipText, _
                                                                  conflictingPersonName, conflictingPersonID) Then
                AddValidationError "続柄同期後の氏名「" & conflictingPersonName & _
                                   "」は別の人物ID（" & conflictingPersonID & _
                                   "）と重複します。人物候補または訂正対象を確認してください。", _
                                   CELL_RELATIONSHIP, validationCount, firstMessage, firstAddress
            End If
        End If
    End If
    If Len(bankName) > 0 And Len(accountType) > 0 And Len(accountNo) > 0 Then
        duplicateID = FindAccountIDByLocator(bankName, branchName, accountType, accountNo, editAccountID)
        If Len(duplicateID) > 0 Then
            AddValidationError "同じ銀行・支店・科目・口座番号の口座は既に登録済みです。名義訂正も登録済み口座から行ってください。", _
                               CELL_ACCOUNT_NO, validationCount, firstMessage, firstAddress
        End If
    End If

    If Len(editAccountID) > 0 Then
        storedBalanceCount = CountAccountRecords(wsBal, WORK_BAL_COL_ACCOUNT_ID, editAccountID)
        If storedBalanceCount > MAX_ACCOUNT_REBUILD_RECORDS Then
            SetInputStatus "訂正対象の残高行が実用上限を超えています。案件を分割してください。"
            AddCheck "エラー", "口座訂正", "残高行が" & Format$(storedBalanceCount, "#,##0") & _
                     "件あり、訂正用再構築上限を超えています: " & editAccountID
            FinishTransferApplicationLease applicationLeaseStarted, entryEvents, _
                entryEventsCaptured, "口座登録・訂正", False, finishDetail
            Exit Sub
        End If
    End If

    txCapacity = (TX_LAST_ROW - TX_FIRST_ROW + 1) + BAL_MAX_LABELS + storedBalanceCount + 2
    balCapacity = BAL_MAX_LABELS + storedBalanceCount
    If balCapacity < 1 Then balCapacity = 1

    '実際に確保する入力配列容量を既存4ストアへ加え、初段で確認済みの
    '警告・停止境界を新たに跨ぐ場合だけ再確認する。ReDim、ID採番、退避、書込みの
    'いずれよりも前なので、32bit版の安全停止時も入力と内部データを変更しない。
    snapshotWorkRows = ManualAccountSnapshotWorkRows( _
        txCapacity, balCapacity, preflightTxStoreRows, preflightBalanceStoreRows, _
        preflightAccountStoreRows, preflightPersonCandidateRows)
    If snapshotWorkRows > 2147483647# Then _
        Err.Raise vbObjectError + 4092, "SaveCurrentAccountCore", _
                  "口座登録の安全退避規模を計算できません。"
    If ManualAccountSnapshotNeedsRecheck(existingSnapshotWorkRows, snapshotWorkRows) Then
        If Not ConfirmLargeArrayOperation(CLng(snapshotWorkRows), _
                "口座の登録・訂正（入力配列・既存保管の安全退避）") Then
            SetInputStatus "口座登録・訂正を開始せず中止しました。入力内容は保持しています。"
            FinishTransferApplicationLease applicationLeaseStarted, entryEvents, _
                entryEventsCaptured, "口座登録・訂正", False, finishDetail
            Exit Sub
        End If
    End If

    ReDim txData(1 To txCapacity, 1 To WORK_TX_COL_PERSON_ID)
    ReDim balData(1 To balCapacity, 1 To WORK_BAL_COL_PERSON_ID)

    If IsDate(openDate) Then
        txCount = txCount + 1
        FillPreparedTx txData, txCount, bankName, branchName, personName, relationshipText, accountType, accountNo, _
                       CDate(openDate), "", "", "", "", "", "口座開設日", "", RECORD_OPEN, 0
    End If
    If IsDate(closeDate) Then
        txCount = txCount + 1
        FillPreparedTx txData, txCount, bankName, branchName, personName, relationshipText, accountType, accountNo, _
                       CDate(closeDate), "", "", "", "", "", "口座解約日", "", RECORD_CLOSE, 999999
    End If

    yearAdd = GetCfgLong(ROW_CFG_YEAR_ADD, 2000)
    For r = TX_FIRST_ROW To lastInputRow
        If Not IsTransactionRowBlank(wsIn, r) Then
            txDate = ResolveInputDate(wsIn.Cells(r, COL_TX_YEAR).Value, wsIn.Cells(r, COL_TX_MONTH).Value, _
                                      wsIn.Cells(r, COL_TX_DAY).Value, currentYear, currentMonth, currentDay, yearAdd, dateOK)
            If Not dateOK Then
                AddValidationError CStr(r) & "行目の日付を補完できません。年・月・日を確認してください。", _
                                   wsIn.Cells(r, COL_TX_DAY).Address(False, False), validationCount, firstMessage, firstAddress
            Else
                If IsDate(openDate) Then
                    If CDate(txDate) < CDate(openDate) Then
                        AddValidationError CStr(r) & "行目の取引日は口座開設日より前です。", _
                                           wsIn.Cells(r, COL_TX_DAY).Address(False, False), validationCount, firstMessage, firstAddress
                    End If
                End If
                If IsDate(closeDate) Then
                    If CDate(txDate) > CDate(closeDate) Then
                        AddValidationError CStr(r) & "行目の取引日は口座解約日より後です。", _
                                           wsIn.Cells(r, COL_TX_DAY).Address(False, False), validationCount, firstMessage, firstAddress
                    End If
                End If
            End If

            txTime = NormalizeTimeInput(wsIn.Cells(r, COL_TX_TIME).Value, timeOK)
            If Not timeOK Then
                AddValidationError CStr(r) & "行目の時刻が不正です。1～4桁のHHMMまたはHH:MMで入力してください。", _
                                   wsIn.Cells(r, COL_TX_TIME).Address(False, False), validationCount, firstMessage, firstAddress
            End If

            withdrawValue = ParseAmountOrError(wsIn.Cells(r, COL_TX_WITHDRAW).Value, amountOK)
            If Not amountOK Then
                AddValidationError CStr(r) & "行目の出金額が不正です（有効数字15桁・小数8桁以内）。", _
                                   wsIn.Cells(r, COL_TX_WITHDRAW).Address(False, False), validationCount, firstMessage, firstAddress
            ElseIf HasText(withdrawValue) Then
                If CDbl(withdrawValue) < 0 Then
                    AddValidationError CStr(r) & "行目の出金額は0以上で入力してください。", _
                                       wsIn.Cells(r, COL_TX_WITHDRAW).Address(False, False), validationCount, firstMessage, firstAddress
                End If
            End If
            depositValue = ParseAmountOrError(wsIn.Cells(r, COL_TX_DEPOSIT).Value, amountOK)
            If Not amountOK Then
                AddValidationError CStr(r) & "行目の入金額が不正です（有効数字15桁・小数8桁以内）。", _
                                   wsIn.Cells(r, COL_TX_DEPOSIT).Address(False, False), validationCount, firstMessage, firstAddress
            ElseIf HasText(depositValue) Then
                If CDbl(depositValue) < 0 Then
                    AddValidationError CStr(r) & "行目の入金額は0以上で入力してください。", _
                                       wsIn.Cells(r, COL_TX_DEPOSIT).Address(False, False), validationCount, firstMessage, firstAddress
                End If
            End If
            If HasText(withdrawValue) And HasText(depositValue) Then
                AddValidationError CStr(r) & "行目は出金と入金の両方に金額があります。どちらか一方にしてください。", _
                                   wsIn.Cells(r, COL_TX_WITHDRAW).Address(False, False), validationCount, firstMessage, firstAddress
            End If
            balanceValue = ParseAmountOrError(wsIn.Cells(r, COL_TX_BALANCE).Value, amountOK)
            If Not amountOK Then
                AddValidationError CStr(r) & "行目の取引後残高が不正です（有効数字15桁・小数8桁以内）。", _
                                   wsIn.Cells(r, COL_TX_BALANCE).Address(False, False), validationCount, firstMessage, firstAddress
            End If

            tekiyoText = CellText(wsIn.Cells(r, COL_TX_TEKIYO).Value)
            AddMaxLengthError CellText(wsIn.Cells(r, COL_TX_SHOP).Value), 100, CStr(r) & "行目の取扱店", _
                              wsIn.Cells(r, COL_TX_SHOP).Address(False, False), validationCount, firstMessage, firstAddress
            AddMaxLengthError CellText(wsIn.Cells(r, COL_TX_MACHINE).Value), 100, CStr(r) & "行目の機番", _
                              wsIn.Cells(r, COL_TX_MACHINE).Address(False, False), validationCount, firstMessage, firstAddress
            AddMaxLengthError tekiyoText, 500, CStr(r) & "行目の摘要", _
                              wsIn.Cells(r, COL_TX_TEKIYO).Address(False, False), validationCount, firstMessage, firstAddress
            If tekiyoText = "同上" Then
                If Len(previousTekiyo) = 0 Then
                    AddValidationError CStr(r) & "行目の「同上」より前に摘要がありません。", _
                                       wsIn.Cells(r, COL_TX_TEKIYO).Address(False, False), validationCount, firstMessage, firstAddress
                Else
                    tekiyoText = previousTekiyo
                End If
            End If
            If Len(tekiyoText) > 0 Then previousTekiyo = tekiyoText

            If Not HasText(withdrawValue) And Not HasText(depositValue) And Not HasText(balanceValue) And _
               Len(CellText(wsIn.Cells(r, COL_TX_SHOP).Value)) = 0 And _
               Len(CellText(wsIn.Cells(r, COL_TX_MACHINE).Value)) = 0 And Len(tekiyoText) = 0 Then
                AddValidationError CStr(r) & "行目は日付以外の取引内容がありません。不要な行は日付も消してください。", _
                                   wsIn.Cells(r, COL_TX_DAY).Address(False, False), validationCount, firstMessage, firstAddress
            End If

            If dateOK And timeOK Then
                txCount = txCount + 1
                userTxCount = userTxCount + 1
                FillPreparedTx txData, txCount, bankName, branchName, personName, relationshipText, accountType, accountNo, _
                               txDate, txTime, withdrawValue, depositValue, _
                               CellText(wsIn.Cells(r, COL_TX_SHOP).Value), CellText(wsIn.Cells(r, COL_TX_MACHINE).Value), _
                               tekiyoText, balanceValue, RECORD_TRANSACTION, r - TX_FIRST_ROW + 1
            End If
        End If
    Next r

    memoCol = BalanceMemoCol(wsIn)
    AddMaxLengthError CellText(wsIn.Cells(BAL_VALUE_ROW, memoCol).Value), 1000, "残高欄のその他", _
                      wsIn.Cells(BAL_VALUE_ROW, memoCol).Address(False, False), validationCount, firstMessage, firstAddress
    For c = BAL_FIRST_COL To memoCol - 1
        If Not AccountExistsAtDate(wsIn.Cells(BAL_DATE_ROW, c).Value, openDate, closeDate) Then
            If HasText(wsIn.Cells(BAL_VALUE_ROW, c).Value) And Not IsBalancePlaceholder(wsIn.Cells(BAL_VALUE_ROW, c).Value) Then
                AddValidationError "開設前または解約後の残高は登録できません。日付を戻すか、残高を削除してから変更してください。", _
                                   wsIn.Cells(BAL_VALUE_ROW, c).Address(False, False), validationCount, firstMessage, firstAddress
            End If
        ElseIf HasText(wsIn.Cells(BAL_VALUE_ROW, c).Value) And Not IsBalancePlaceholder(wsIn.Cells(BAL_VALUE_ROW, c).Value) Then
            amountValue = ParseAmountOrError(wsIn.Cells(BAL_VALUE_ROW, c).Value, amountOK)
            If Not amountOK Then
                AddValidationError "残高欄「" & CellText(wsIn.Cells(BAL_LABEL_ROW, c).Value) & _
                                   "」が不正です（有効数字15桁・小数8桁以内）。", _
                                   wsIn.Cells(BAL_VALUE_ROW, c).Address(False, False), validationCount, firstMessage, firstAddress
            Else
                balCount = balCount + 1
                FillPreparedBalance balData, balCount, personName, bankName, branchName, accountType, accountNo, _
                                    openDate, closeDate, wsIn.Cells(BAL_DATE_ROW, c).Value, _
                                    BalanceTekiyoLabel(wsIn.Cells(BAL_LABEL_ROW, c).Value), amountValue, _
                                    CellText(wsIn.Cells(BAL_VALUE_ROW, memoCol).Value), relationshipText
                txCount = txCount + 1
                FillPreparedTx txData, txCount, bankName, branchName, personName, relationshipText, accountType, accountNo, _
                               wsIn.Cells(BAL_DATE_ROW, c).Value, "", "", "", "", "", _
                               BalanceTekiyoLabel(wsIn.Cells(BAL_LABEL_ROW, c).Value), amountValue, RECORD_BALANCE, 500000 + c
            End If
        End If
    Next c

    If Len(editAccountID) > 0 Then
        PreserveHiddenBalancesForEdit wsIn, wsBal, editAccountID, bankName, branchName, personName, _
                                      relationshipText, accountType, accountNo, openDate, closeDate, _
                                      txData, txCount, balData, balCount, preservedHiddenBalanceCount, _
                                      validationCount, firstMessage, firstAddress
    End If

    If validationCount > 0 Then
        If Len(firstAddress) > 0 Then SafeSelectCell wsIn, firstAddress
        '選択変更イベントが日付補完表示を書き戻すため、セル移動後に理由を表示する。
        SetInputStatus "登録できません（" & validationCount & "件）　" & firstMessage, True
        FinishTransferApplicationLease applicationLeaseStarted, entryEvents, _
            entryEventsCaptured, "口座登録・訂正", False, finishDetail
        Exit Sub
    End If

    EnsureInternalAppendCapacity wsTx, txCount, "W_取引"
    EnsureInternalAppendCapacity wsBal, balCount, "W_残高"
    If Len(editAccountID) = 0 Then EnsureInternalAppendCapacity wsAcc, 1, "W_口座"

    idCounterSnapshot = CaptureInternalIdCounters()
    idCountersCaptured = True
    If Len(editAccountID) > 0 Then
        accountID = editAccountID
        '新IDを振る前に旧行を退避する。内容が変わらない取引・残高はIDを維持し、
        '口座名義等だけの訂正で分析確認履歴を不必要に失わない。
        SnapshotAccountRows wsTx, WORK_TX_COL_ACCOUNT_ID, accountID, WORK_TX_COL_PERSON_ID, oldTx, oldTxCount
        SnapshotAccountRows wsBal, WORK_BAL_COL_ACCOUNT_ID, accountID, WORK_BAL_COL_PERSON_ID, oldBal, oldBalCount
        oldMasterRow = FindAccountRowByID(accountID)
        If oldMasterRow > 0 Then _
            oldMaster = wsAcc.Range(wsAcc.Cells(oldMasterRow, 1), _
                                    wsAcc.Cells(oldMasterRow, ACC_COL_TRANSFER_ID)).Value
    Else
        accountID = NextInternalId(STATE_NEXT_ACCOUNT, "A")
    End If
    '表記上だけ同じ氏名なら旧人物IDを維持する。実質的な氏名変更では、
    '上の事前解決結果を使い、旧人物IDへ別人物を誤って結び付けない。
    If Len(editAccountID) > 0 And oldMasterRow > 0 And Len(personID) = 0 Then
        oldPersonName = CellText(wsAcc.Cells(oldMasterRow, ACC_COL_PERSON).Value)
        If ShouldReuseEditPersonID(oldPersonName, personName) Then _
            personID = CellText(wsAcc.Cells(oldMasterRow, ACC_COL_PERSON_ID).Value)
    End If
    If Len(personID) = 0 Then personID = PersonIDForName(personName, relationshipText)
    If Len(personID) = 0 Then personID = NextInternalId(STATE_NEXT_PERSON, "P")
    If Len(NormalizeRelationshipKey(relationshipText)) > 0 Then
        conflictingPersonName = vbNullString
        conflictingPersonID = vbNullString
        If FindConflictingPersonIDForRelationshipChange( _
                personID, personName, relationshipText, conflictingPersonName, _
                conflictingPersonID) Then _
            Err.Raise vbObjectError + 4089, "TransferCurrentAccount", _
                      "人物候補の続柄補完後に氏名「" & conflictingPersonName & _
                      "」が別の人物ID（" & conflictingPersonID & _
                      "）と重複します。人物候補を修正してから再登録してください。"
    End If
    If Len(editAccountID) > 0 Then
        '内部3ストアは後段で全体退避する。候補だけは別シートなので対象人物を厳密退避する。
        If SheetExists(SH_PERSON_CAND) Then _
            SnapshotPersonRelationshipState GetSheet(SH_PERSON_CAND), 2, 3, 0, personID, _
                                            oldPersonCandidateRel, oldPersonCandidateRelCount
    End If
    transferID = NextInternalId(STATE_NEXT_TRANSFER, "R")
    nextAccountNo = NextBranchAccountNo(accountNo)

    AssignPreparedTransactionIDs txData, txCount, oldTx, oldTxCount
    AssignPreparedBalanceIDs balData, balCount, oldBal, oldBalCount

    For r = 1 To txCount
        txData(r, WORK_TX_COL_ACCOUNT_ID) = accountID
        txData(r, WORK_TX_COL_TRANSFER_ID) = transferID
        txData(r, WORK_TX_COL_SOURCE) = SOURCE_MANUAL
        txData(r, WORK_TX_COL_PERSON_ID) = personID
    Next r
    For r = 1 To balCount
        balData(r, WORK_BAL_COL_ACCOUNT_ID) = accountID
        balData(r, WORK_BAL_COL_TRANSFER_ID) = transferID
        balData(r, WORK_BAL_COL_SOURCE) = SOURCE_MANUAL
        balData(r, WORK_BAL_COL_PERSON_ID) = personID
    Next r

    '部分書込みや圧縮削除後の後続失敗でも、対象ID以外と元の行順まで戻せるよう、
    '最初の破壊的書込み前に内部3ストアを全列・Value2型込みで退避する。
    CaptureConstantDataStoreSnapshot wsTx, WORK_TX_COL_PERSON_ID, txStoreSnapshot, txStoreRows
    CaptureConstantDataStoreSnapshot wsBal, WORK_BAL_COL_PERSON_ID, balanceStoreSnapshot, balanceStoreRows
    CaptureConstantDataStoreSnapshot wsAcc, ACC_COL_TRANSFER_ID, accountStoreSnapshot, accountStoreRows
    storeSnapshotsCaptured = True
    '人物候補は人物ID自動判定の正規ストアでもある。中核3表と同じトランザクションで
    '全行・全列を退避し、候補更新だけが失敗した部分確定を許さない。
    CaptureConstantDataStoreSnapshot wsPerson, 4, personCandidateSnapshot, personCandidateRows
    personCandidateSnapshotCaptured = True

    Application.StatusBar = "検証済みデータを一括登録しています..."
    '既存行の訂正ロールバックは行順まで完全には戻らないため、最初の破壊的書込みより前に
    '帳票を要更新へ倒す。後で内容を復元できても旧帳票を再利用しない。
    writeStarted = True
    MarkOutputsDirty
    newTxFirst = AppendPreparedTxRows(wsTx, txData, txCount, newTxFirst)
    newBalFirst = AppendPreparedBalanceRows(wsBal, balData, balCount, newBalFirst)
    If Len(editAccountID) > 0 Then
        DeleteOldRowsExceptTransfer wsTx, WORK_TX_COL_ACCOUNT_ID, WORK_TX_COL_TRANSFER_ID, accountID, transferID
        DeleteOldRowsExceptTransfer wsBal, WORK_BAL_COL_ACCOUNT_ID, WORK_BAL_COL_TRANSFER_ID, accountID, transferID
    End If
    UpsertAccountMaster accountID, transferID, bankName, branchName, personName, relationshipText, _
                        accountType, accountNo, openDate, closeDate, personID, SOURCE_MANUAL
    If Len(editAccountID) > 0 Then SynchronizePersonRelationship personID, relationshipText
    AddPersonCandidateWithID personName, personID, relationshipText
    If Not RequireInternalStoresSafeForWrite() Then _
        Err.Raise vbObjectError + 4090, "SaveCurrentAccountCore", _
                  "口座登録後の人物ID関係を安全に確認できません。"
    committed = True
    InvalidateDuplicateAccountWarningCache
    eventStateDetail = vbNullString
    If Not TrySetTransferEnableEventsExact(False, eventStateDetail) Then _
        Err.Raise vbObjectError + 4096, "SaveCurrentAccountCore", _
                  "登録後処理の前にExcelイベント停止を確認できません: " & _
                  eventStateDetail

    On Error Resume Next
    Err.Clear
    UpdateAccountCandidates bankName, branchName, personName
    If IsTransferRecoveryHardBarrier(Err.Number, Err.Source) Then
        errorNumber = Err.Number
        errorSource = Err.Source
        errorDescription = Err.Description
        Err.Clear
        On Error GoTo EH
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    If Err.Number <> 0 Then AppendTransferDetail postProcessDetail, "口座候補: Err " & Err.Number & " " & Err.Description
    Err.Clear
    AddAccountTypeCandidate accountType
    If IsTransferRecoveryHardBarrier(Err.Number, Err.Source) Then
        errorNumber = Err.Number
        errorSource = Err.Source
        errorDescription = Err.Description
        Err.Clear
        On Error GoTo EH
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    If Err.Number <> 0 Then AppendTransferDetail postProcessDetail, "科目候補: Err " & Err.Number & " " & Err.Description
    Err.Clear
    If IsDate(openDate) Then
        wsIn.Range(CELL_OPEN_DATE).Value = CDate(openDate)
        If Err.Number <> 0 Then AppendTransferDetail postProcessDetail, "開設日の表示更新: Err " & Err.Number & " " & Err.Description
        Err.Clear
    End If
    If IsDate(closeDate) Then
        wsIn.Range(CELL_CLOSE_DATE).Value = CDate(closeDate)
        If Err.Number <> 0 Then AppendTransferDetail postProcessDetail, "解約日の表示更新: Err " & Err.Number & " " & Err.Description
        Err.Clear
    End If
    BuildRegisteredAccountsSheet False, True
    If IsTransferRecoveryHardBarrier(Err.Number, Err.Source) Then
        errorNumber = Err.Number
        errorSource = Err.Source
        errorDescription = Err.Description
        Err.Clear
        On Error GoTo EH
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    If Err.Number <> 0 Then AppendTransferDetail postProcessDetail, "登録済み口座一覧: Err " & Err.Number & " " & Err.Description
    Err.Clear
    focusPolicy = keepOverride
    If Len(focusPolicy) = 0 Then focusPolicy = GetPostTransferKeepPolicy()
    If Err.Number <> 0 Then AppendTransferDetail postProcessDetail, "転記後設定の取得: Err " & Err.Number & " " & Err.Description
    Err.Clear
    If nextBranchAfter Then
        cleanupSucceeded = True
        ApplyPostTransferCleanup KEEP_BANK_BRANCH_PERSON_TYPE
        If IsTransferClearRecoveryFatal(Err.Number, Err.Source) Then
            errorNumber = Err.Number
            errorSource = Err.Source
            errorDescription = Err.Description
            Err.Clear
            On Error GoTo EH
            Err.Raise errorNumber, errorSource, errorDescription
        End If
        If IsTransferRecoveryHardBarrier(Err.Number, Err.Source) Then
            errorNumber = Err.Number
            errorSource = Err.Source
            errorDescription = Err.Description
            Err.Clear
            On Error GoTo EH
            Err.Raise errorNumber, errorSource, errorDescription
        End If
        If Err.Number <> 0 Then
            cleanupSucceeded = False
            AppendTransferDetail postProcessDetail, "入力欄の整理: Err " & Err.Number & " " & Err.Description & _
                                 "（登録前入力を保持し、次枝番は設定していません）"
        End If
        Err.Clear
        If cleanupSucceeded Then
            SetNextBranchAccountNumber nextAccountNo, True
            If IsTransferClearRecoveryFatal(Err.Number, Err.Source) Then
                errorNumber = Err.Number
                errorSource = Err.Source
                errorDescription = Err.Description
                Err.Clear
                On Error GoTo EH
                Err.Raise errorNumber, errorSource, errorDescription
            End If
            If IsTransferRecoveryHardBarrier(Err.Number, Err.Source) Then
                errorNumber = Err.Number
                errorSource = Err.Source
                errorDescription = Err.Description
                Err.Clear
                On Error GoTo EH
                Err.Raise errorNumber, errorSource, errorDescription
            End If
            If Err.Number <> 0 Then AppendTransferDetail postProcessDetail, "次枝番の設定: Err " & Err.Number & " " & Err.Description
            Err.Clear
        End If
        focusPolicy = KEEP_BANK_BRANCH_PERSON_TYPE
    Else
        cleanupSucceeded = True
        ApplyPostTransferCleanup keepOverride
        If IsTransferClearRecoveryFatal(Err.Number, Err.Source) Then
            errorNumber = Err.Number
            errorSource = Err.Source
            errorDescription = Err.Description
            Err.Clear
            On Error GoTo EH
            Err.Raise errorNumber, errorSource, errorDescription
        End If
        If IsTransferRecoveryHardBarrier(Err.Number, Err.Source) Then
            errorNumber = Err.Number
            errorSource = Err.Source
            errorDescription = Err.Description
            Err.Clear
            On Error GoTo EH
            Err.Raise errorNumber, errorSource, errorDescription
        End If
        If Err.Number <> 0 Then
            cleanupSucceeded = False
            AppendTransferDetail postProcessDetail, "入力欄の整理: Err " & Err.Number & " " & Err.Description & _
                                 "（登録前入力を保持しています）"
        End If
        Err.Clear
    End If
    If cleanupSucceeded Then
        FocusAfterPostTransferCleanup focusPolicy
        If Err.Number <> 0 Then
            AppendTransferDetail postProcessDetail, "入力位置の移動: Err " & Err.Number & " " & Err.Description
        End If
    End If
    Err.Clear
    On Error GoTo EH

    eventStateDetail = vbNullString
    If Not TrySetTransferEnableEventsExact(False, eventStateDetail) Then _
        Err.Raise vbObjectError + 4096, "SaveCurrentAccountCore", _
                  "登録後の案内を書き込む前にExcelイベント停止を確認できません: " & _
                  eventStateDetail
    '次枝番設定などの登録後処理が復元不能を検知した場合、データ自体は内部登録済みでも
    '通常の成功案内で安全状態不明を上書きしない。再登録による二重登録も明示的に止める。
    If Not ToolDataHealthIsNormal() Then
        recoveryRequired = True
        AppendTransferDetail postProcessDetail, _
            "口座データの内部登録は完了しましたが、登録後処理の安全状態を一意に確認できません。"
        recoveryGateDetail = vbNullString
        recoveryConfirmed = _
            TryEnterTransferRecoveryStateExact( _
                postProcessDetail, recoveryGateDetail, _
                recoveryEnforcementFailed)
        If recoveryConfirmed Then
            On Error Resume Next
            AddCheck "エラー", "口座登録後処理", postProcessDetail
            SetInputStatus "口座データの内部登録は完了しましたが、安全状態を確認できないため通常操作へ戻せません。再登録せずC_チェックを確認してください。", True
            Err.Clear
            On Error GoTo 0
            eventStateDetail = vbNullString
            eventsSafeForWorkbookWrites = _
                TrySetTransferEnableEventsExact(False, eventStateDetail)
            If eventsSafeForWorkbookWrites Then
                recoveryConfirmed = TransferRecoveryStateConfirmed()
            Else
                recoveryConfirmed = False
                AppendTransferDetail postProcessDetail, _
                    "復旧診断後にExcelイベント停止を再確認できません: " & _
                    eventStateDetail
            End If
        Else
            AppendTransferDetail postProcessDetail, _
                "要復旧状態を一意に確認できないため、診断・状態表示を行いません: " & _
                recoveryGateDetail
        End If
        On Error Resume Next
        MsgBox "口座データの内部登録は完了しましたが、登録後処理を安全に完了できませんでした。" & vbCrLf & _
               "再登録せず、C_チェックを確認し、現在のブックを上書きしないでください。", _
               vbCritical, "登録済み・安全状態要確認"
        On Error GoTo 0
        FinishTransferApplicationLease applicationLeaseStarted, entryEvents, _
            entryEventsCaptured, "口座登録・訂正", True, finishDetail, _
            True, recoveryConfirmed, recoveryEnforcementFailed
        Exit Sub
    End If
    If Len(postProcessDetail) > 0 Then
        AddCheck "警告", "口座登録後処理", postProcessDetail
        postProcessSuffix = "（登録済み・画面整理は要確認）"
    End If
    If Not cleanupSucceeded Then
        retentionWarning = "（登録前入力を保持中。再登録せず登録済み口座を確認）"
    ElseIf Not GetPostTransferClearTransaction() Or Not GetPostTransferClearBalance() Then
        retentionWarning = "（前口座の明細または残高を保持中。次口座へ流用しない場合はクリア）"
    End If
    If Len(editAccountID) > 0 Then
        SetInputStatus "訂正を反映しました。取引 " & userTxCount & "件、残高 " & balCount & "件" & _
                       IIf(preservedHiddenBalanceCount > 0, "（表示期間外 " & preservedHiddenBalanceCount & "件を保持）", "") & _
                       postProcessSuffix & retentionWarning & "。"
    Else
        SetInputStatus "登録しました。取引 " & userTxCount & "件、残高 " & balCount & "件" & _
                       postProcessSuffix & retentionWarning & "。"
    End If
    FinishTransferApplicationLease applicationLeaseStarted, entryEvents, _
        entryEventsCaptured, "口座登録・訂正", True, finishDetail
    Exit Sub

EH:
    errorNumber = Err.Number
    errorSource = Err.Source
    errorDescription = Err.Description
    If IsTransferClearRecoveryFatal(errorNumber, errorSource) Then
        eventsSafeForWorkbookWrites = _
            TrySetTransferEnableEventsExact(False, eventStateDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    If IsTransferRecoveryHardBarrier(errorNumber, errorSource) Then
        eventsSafeForWorkbookWrites = _
            TrySetTransferEnableEventsExact(False, eventStateDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    eventStateDetail = vbNullString
    eventsSafeForWorkbookWrites = _
        TrySetTransferEnableEventsExact(False, eventStateDetail)
    If Not eventsSafeForWorkbookWrites Then
        AppendTransferDetail rollbackDetail, _
            "Excelイベント停止を読戻し確認できないため、" & _
            "エラー終了時のブック書込みを見送りました: " & eventStateDetail
    End If
    If committed Then
        '登録本体確定後の案内・診断でさらにエラーが起きても、元エラーを失わず
        '再登録を促す未処理エラーへ抜けない。旧snapshotは確定後に戻さない。
        If eventsSafeForWorkbookWrites Then
            On Error Resume Next
            recoveryRequired = True
            Err.Clear
            recoveryRequired = Not ToolDataHealthIsNormal()
            If Err.Number <> 0 Then _
                AppendTransferDetail postProcessDetail, _
                    "確定後の案件正常状態を読み取れません: Err " & _
                    CStr(Err.Number) & " " & Err.Description
            Err.Clear
            If recoveryRequired Then
                AppendTransferDetail postProcessDetail, _
                    "確定後に案件の正常状態を一意に確認できません。"
                recoveryGateDetail = vbNullString
                recoveryConfirmed = _
                    TryEnterTransferRecoveryStateExact( _
                        postProcessDetail, recoveryGateDetail, _
                        recoveryEnforcementFailed)
                If IsTransferRecoveryHardBarrier(Err.Number, Err.Source) Then
                    errorNumber = Err.Number
                    errorSource = Err.Source
                    errorDescription = Err.Description
                    Err.Clear
                    Call TrySetTransferEnableEventsExact( _
                             False, eventStateDetail)
                    On Error GoTo 0
                    Err.Raise errorNumber, errorSource, errorDescription
                End If
                If Not recoveryConfirmed Then _
                    AppendTransferDetail postProcessDetail, _
                        "要復旧状態を一意に確認できません: " & _
                        recoveryGateDetail
                eventStateDetail = vbNullString
                eventsSafeForWorkbookWrites = _
                    TrySetTransferEnableEventsExact(False, eventStateDetail)
                If Not eventsSafeForWorkbookWrites Then
                    recoveryConfirmed = False
                    AppendTransferDetail postProcessDetail, _
                        "復旧処理後にExcelイベント停止を再確認できず、" & _
                        "追加の終了記録を見送りました: " & eventStateDetail
                ElseIf recoveryConfirmed Then
                    recoveryConfirmed = TransferRecoveryStateConfirmed()
                End If
            End If
            If eventsSafeForWorkbookWrites And _
               (Not recoveryRequired Or recoveryConfirmed) Then
                On Error Resume Next
                If recoveryRequired Then
                    SetInputStatus "口座データの内部登録は完了しましたが、案件の要復旧状態を確認しました。再登録・上書き保存をせずC_チェックを確認してください。", True
                    AddCheck "エラー", "口座登録後処理", _
                             "口座データの内部登録は完了しています。Err " & _
                             CStr(errorNumber) & ": " & errorDescription & _
                             IIf(Len(postProcessDetail) > 0, " / " & postProcessDetail, "")
                Else
                    SetInputStatus "口座データの内部登録は完了しましたが、画面の後処理でエラーが発生しました。C_チェックを確認してください。"
                    AddCheck "警告", "口座登録後処理", _
                             "Err " & CStr(errorNumber) & ": " & errorDescription & _
                             IIf(Len(postProcessDetail) > 0, " / " & postProcessDetail, "")
                End If
                Err.Clear
                On Error GoTo 0
                If recoveryRequired Then
                    eventStateDetail = vbNullString
                    eventsSafeForWorkbookWrites = _
                        TrySetTransferEnableEventsExact(False, eventStateDetail)
                    If eventsSafeForWorkbookWrites Then
                        recoveryConfirmed = _
                            TransferRecoveryStateConfirmed()
                    Else
                        recoveryConfirmed = False
                        AppendTransferDetail postProcessDetail, _
                            "終了記録後にExcelイベント停止を確認できません: " & _
                            eventStateDetail
                    End If
                End If
            End If
        End If
        On Error Resume Next
        MsgBox "口座データの内部登録は完了していますが、登録後処理でエラーが発生しました。" & vbCrLf & _
               "同じ口座を再登録せず、C_チェックと登録済み口座を確認してください。" & vbCrLf & _
               IIf(Not eventsSafeForWorkbookWrites, _
                   "Excelイベント状態が不明なため、終了記録はブックへ書き込んでいません。" & vbCrLf, "") & _
               "Err " & CStr(errorNumber) & ": " & errorDescription & _
               IIf(Len(postProcessDetail) > 0, vbCrLf & postProcessDetail, ""), _
               IIf(recoveryRequired Or Not eventsSafeForWorkbookWrites, vbCritical, vbExclamation), _
               "登録済み・後処理要確認"
        On Error GoTo 0
        FinishTransferApplicationLease applicationLeaseStarted, entryEvents, _
            entryEventsCaptured, "口座登録・訂正", True, postProcessDetail, _
            recoveryRequired Or Not eventsSafeForWorkbookWrites, _
            recoveryConfirmed, recoveryEnforcementFailed
        Exit Sub
    End If

    If eventsSafeForWorkbookWrites And writeStarted And Not committed Then
        On Error Resume Next
        If storeSnapshotsCaptured Then
            Err.Clear
            RestoreConstantDataStoreSnapshot wsTx, WORK_TX_COL_PERSON_ID, _
                                             txStoreSnapshot, txStoreRows
            If Err.Number <> 0 Then
                storeRestoreFailed = True
                AppendTransferDetail rollbackDetail, "取引保管の全体復元エラー: " & Err.Description
            End If
            Err.Clear
            RestoreConstantDataStoreSnapshot wsBal, WORK_BAL_COL_PERSON_ID, _
                                             balanceStoreSnapshot, balanceStoreRows
            If Err.Number <> 0 Then
                storeRestoreFailed = True
                AppendTransferDetail rollbackDetail, "残高保管の全体復元エラー: " & Err.Description
            End If
            Err.Clear
            RestoreConstantDataStoreSnapshot wsAcc, ACC_COL_TRANSFER_ID, _
                                             accountStoreSnapshot, accountStoreRows
            If Err.Number <> 0 Then
                storeRestoreFailed = True
                AppendTransferDetail rollbackDetail, "口座保管の全体復元エラー: " & Err.Description
            End If
        Else
            storeRestoreFailed = True
            AppendTransferDetail rollbackDetail, "内部3ストアの登録前退避を確認できません。"
        End If
        Err.Clear
        If personCandidateSnapshotCaptured Then
            RestoreConstantDataStoreSnapshot wsPerson, 4, personCandidateSnapshot, personCandidateRows
            If Err.Number <> 0 Then
                storeRestoreFailed = True
                AppendTransferDetail rollbackDetail, "人物候補の全体復元エラー: " & Err.Description
            Else
                Err.Clear
                RefreshAllCandidateNames
                If Err.Number <> 0 Then
                    storeRestoreFailed = True
                    AppendTransferDetail rollbackDetail, "人物候補一覧の復元エラー: " & Err.Description
                End If
            End If
        Else
            storeRestoreFailed = True
            AppendTransferDetail rollbackDetail, "人物候補の登録前退避を確認できません。"
        End If
        Err.Clear
        If Len(editAccountID) > 0 And SheetExists(SH_PERSON_CAND) Then
            RestorePersonRelationshipState GetSheet(SH_PERSON_CAND), 2, 3, 0, personID, _
                                           oldPersonCandidateRel, oldPersonCandidateRelCount
            If Err.Number <> 0 Then _
                AppendTransferDetail rollbackDetail, "人物候補続柄の復元エラー: " & Err.Description
            Err.Clear
            relationshipStateMatches = PersonRelationshipStateMatches(GetSheet(SH_PERSON_CAND), 2, 3, 0, _
                personID, oldPersonCandidateRel, oldPersonCandidateRelCount)
            If Err.Number <> 0 Then
                AppendTransferDetail rollbackDetail, "人物候補続柄の復元確認エラー: " & Err.Description
            ElseIf Not relationshipStateMatches Then
                AppendTransferDetail rollbackDetail, "人物候補続柄が復元前と一致しません。"
            End If
        End If
        If Not storeRestoreFailed And Len(rollbackDetail) = 0 Then rollbackVerified = True
        On Error GoTo 0
    ElseIf writeStarted Then
        storeRestoreFailed = True
        rollbackVerified = False
        AppendTransferDetail rollbackDetail, _
            "Excelイベント停止未確認のため登録前snapshotを再書込みしていません。"
    End If
    If eventsSafeForWorkbookWrites And idCountersCaptured And _
       (Not writeStarted Or rollbackVerified) Then
        On Error Resume Next
        Err.Clear
        RestoreInternalIdCounters idCounterSnapshot
        If Err.Number <> 0 Then
            AppendTransferDetail rollbackDetail, "ID採番状態の復元エラー: " & Err.Description
            counterRestoreFailed = True
            rollbackVerified = False
        End If
        Err.Clear
        On Error GoTo 0
    End If
    recoveryRequired = (writeStarted And Not rollbackVerified) Or counterRestoreFailed
    If recoveryRequired And eventsSafeForWorkbookWrites Then
        '復元不成立の内部データから古い帳票を再利用させない。
        '要復旧の一意読戻しと、代替の登録停止まで共通ヘルパーで確定する。
        recoveryGateDetail = vbNullString
        recoveryConfirmed = _
            TryEnterTransferRecoveryStateExact( _
                rollbackDetail, recoveryGateDetail, _
                recoveryEnforcementFailed)
        If Not recoveryConfirmed Then _
            AppendTransferDetail rollbackDetail, _
                "要復旧状態を一意に確認できません: " & _
                recoveryGateDetail
        eventStateDetail = vbNullString
        eventsSafeForWorkbookWrites = _
            TrySetTransferEnableEventsExact(False, eventStateDetail)
        If Not eventsSafeForWorkbookWrites Then
            recoveryConfirmed = False
            AppendTransferDetail rollbackDetail, _
                "復旧処理後にExcelイベント停止を再確認できず、" & _
                "追加の終了記録を見送りました: " & eventStateDetail
        ElseIf recoveryConfirmed Then
            recoveryConfirmed = TransferRecoveryStateConfirmed()
        End If
    End If
    If eventsSafeForWorkbookWrites And _
       (Not recoveryRequired Or recoveryConfirmed) Then
        On Error Resume Next
        Err.Clear
        If Not recoveryRequired Then
            SetInputStatus "登録に失敗したため、データは反映していません。"
            If Len(rollbackDetail) > 0 Then _
                AddCheck "警告", "口座登録ロールバック", rollbackDetail
        ElseIf recoveryConfirmed Then
            SetInputStatus "登録に失敗し、案件の要復旧状態を確認しました。上書き保存をせずC_チェックを確認してください。", True
            AddCheck "エラー", "口座登録ロールバック", rollbackDetail
        End If
        Err.Clear
        On Error GoTo 0
        If recoveryRequired Then
            eventStateDetail = vbNullString
            eventsSafeForWorkbookWrites = _
                TrySetTransferEnableEventsExact(False, eventStateDetail)
            If eventsSafeForWorkbookWrites Then
                recoveryConfirmed = TransferRecoveryStateConfirmed()
            Else
                recoveryConfirmed = False
                AppendTransferDetail rollbackDetail, _
                    "ロールバック診断後にExcelイベント停止を確認できません: " & _
                    eventStateDetail
            End If
        End If
    End If
    On Error Resume Next
    MsgBox "口座登録中にエラーが発生しました。" & vbCrLf & _
           "Err " & errorNumber & ": " & errorDescription & _
           IIf(Not eventsSafeForWorkbookWrites, _
               vbCrLf & "Excelイベント状態が不明なため、ブックへのロールバックと終了記録を見送りました。", "") & _
           IIf(Len(rollbackDetail) > 0, vbCrLf & "復元確認: " & rollbackDetail, ""), vbCritical
    On Error GoTo 0
    FinishTransferApplicationLease applicationLeaseStarted, entryEvents, _
        entryEventsCaptured, "口座登録・訂正", False, rollbackDetail, _
        recoveryRequired Or Not eventsSafeForWorkbookWrites, _
        recoveryConfirmed, recoveryEnforcementFailed
End Sub

Private Function IsTransferClearRecoveryFatal( _
        ByVal errorNumber As Long, _
        ByVal errorSource As String) As Boolean
    IsTransferClearRecoveryFatal = _
        (errorNumber = vbObjectError + 5197) And _
        (Left$(errorSource, Len("ClearRecoveryFatal/")) = _
            "ClearRecoveryFatal/")
End Function

Private Function IsTransferRecoveryHardBarrier( _
        ByVal errorNumber As Long, _
        ByVal errorSource As String) As Boolean
    Dim sourcePrefix As String

    Select Case errorNumber
        Case vbObjectError + 3599, vbObjectError + 4499
            IsTransferRecoveryHardBarrier = True
            Exit Function
        Case vbObjectError + 5191
            sourcePrefix = "AnalysisWorkspaceRecoveryFatal/"
        Case vbObjectError + 5192
            sourcePrefix = "SetupConvergeRecoveryFatal/"
        Case vbObjectError + 5194
            sourcePrefix = "CashAnalysisRecoveryFatal/"
        Case vbObjectError + 5195
            sourcePrefix = "TransactionAnalysisRecoveryFatal/"
        Case vbObjectError + 5196
            sourcePrefix = "CashManualSelectionRecoveryFatal/"
        Case vbObjectError + 5197
            sourcePrefix = "ClearRecoveryFatal/"
        Case Else
            Exit Function
    End Select

    IsTransferRecoveryHardBarrier = _
        (Len(errorSource) >= Len(sourcePrefix)) And _
        (StrComp(Left$(errorSource, Len(sourcePrefix)), _
                 sourcePrefix, vbBinaryCompare) = 0)
End Function

Private Function TryGetTransferEnableEvents(ByRef currentValue As Boolean, _
                                            ByRef detailText As String) As Boolean
    Dim errorNumber As Long, errorDescription As String
    detailText = vbNullString
    On Error GoTo EH
    currentValue = Application.EnableEvents
    TryGetTransferEnableEvents = True
    Exit Function
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    detailText = "Err " & CStr(errorNumber) & ": " & errorDescription
    Err.Clear
End Function

Private Function TrySetTransferEnableEventsExact(ByVal desiredValue As Boolean, _
                                                  ByRef detailText As String) As Boolean
    Dim errorNumber As Long, errorDescription As String
    detailText = vbNullString
    On Error GoTo EH
    Application.EnableEvents = desiredValue
    If Application.EnableEvents <> desiredValue Then _
        Err.Raise vbObjectError + 4095, "TrySetTransferEnableEventsExact", _
                  "EnableEventsの書込み後読戻しが一致しません。"
    TrySetTransferEnableEventsExact = True
    Exit Function
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    detailText = "Err " & CStr(errorNumber) & ": " & errorDescription
    Err.Clear
End Function

Private Function TransferRecoveryStateConfirmed() As Boolean
    Dim latchIsSet As Boolean, healthValue As String
    On Error GoTo EH
    If Not TryGetRollbackRecoveryLatch(latchIsSet) Then Exit Function
    If Not latchIsSet Then Exit Function
    If Not TryGetExactStateValue(STATE_DATA_HEALTH, healthValue) Then Exit Function
    TransferRecoveryStateConfirmed = _
        (StrComp(healthValue, DATA_HEALTH_NEEDS_RECOVERY, vbBinaryCompare) = 0)
    Exit Function
EH:
    TransferRecoveryStateConfirmed = False
    Err.Clear
End Function

Private Function TryEnterTransferRecoveryStateExact( _
        ByRef recoveryDetail As String, _
        ByRef gateDetail As String, _
        ByRef enforcementFailed As Boolean) As Boolean
    Dim eventDetail As String, convergenceDetail As String
    Dim finalStopDetail As String, applicationStateProblems As String
    Dim enforceErrorNumber As Long, enforceErrorDescription As String

    gateDetail = vbNullString
    If enforcementFailed Then
        If Not TrySetTransferEnableEventsExact(False, eventDetail) Then
            gateDetail = _
                "既存のRecovery強制失敗後にExcelイベントをFalseへ収束できません: " & _
                eventDetail
        Else
            gateDetail = _
                "Recovery強制は失敗済みのため再試行せず、ExcelイベントをFalseに維持しました。"
        End If
        Err.Raise TRANSFER_RECOVERY_HARD_BARRIER_ERROR, _
                  TRANSFER_RECOVERY_HARD_BARRIER_SOURCE & _
                      "TryEnterTransferRecoveryStateExact/RepeatedAttempt", _
                  gateDetail
    End If
    If Not TrySetTransferEnableEventsExact(False, eventDetail) Then
        gateDetail = "Recovery書込み前にExcelイベント停止を確認できません: " & _
                     eventDetail
        Exit Function
    End If

    On Error Resume Next
    Err.Clear
    EnforceRollbackRecoveryState recoveryDetail
    enforceErrorNumber = Err.Number
    enforceErrorDescription = Err.Description
    Err.Clear
    On Error GoTo 0
    'Enforce内の隔離処理がApplication leaseを復元し得るため、ラッチ・healthを
    '読む前に必ずFalseを再取得する。EnforceのErrもここで局所捕捉して失わせない。
    eventDetail = vbNullString
    If Not TrySetTransferEnableEventsExact(False, eventDetail) Then
        gateDetail = "Recovery設定後にExcelイベント停止を再確認できません: " & _
                     eventDetail
        If enforcementFailed Then _
            AppendTransferDetail gateDetail, _
                "Recovery強制エラー: Err " & _
                CStr(enforceErrorNumber) & " " & enforceErrorDescription
        If Not TrySetTransferEnableEventsExact(False, convergenceDetail) Then _
            AppendTransferDetail gateDetail, _
                "ExcelイベントをFalseの安全停止へ収束できません: " & _
                convergenceDetail
        enforcementFailed = True
        If enforceErrorNumber <> 0 Then
            Err.Raise TRANSFER_RECOVERY_HARD_BARRIER_ERROR, _
                      TRANSFER_RECOVERY_HARD_BARRIER_SOURCE & _
                          "TryEnterTransferRecoveryStateExact/EnforceError", _
                      gateDetail
        End If
        Err.Raise TRANSFER_RECOVERY_HARD_BARRIER_ERROR, _
                  TRANSFER_RECOVERY_HARD_BARRIER_SOURCE & _
                      "TryEnterTransferRecoveryStateExact/PostFalseFailed", _
                  gateDetail
    End If
    If enforceErrorNumber <> 0 Then
        gateDetail = "要復旧状態の設定エラー: Err " & _
                     CStr(enforceErrorNumber) & " " & enforceErrorDescription
        enforcementFailed = True
        Err.Raise TRANSFER_RECOVERY_HARD_BARRIER_ERROR, _
                  TRANSFER_RECOVERY_HARD_BARRIER_SOURCE & _
                      "TryEnterTransferRecoveryStateExact/EnforceError", _
                  gateDetail
    End If
    If Not TransferRecoveryStateConfirmed() Then
        gateDetail = "復旧ラッチと案件要復旧状態を一意に読み返せません。"
        Call TrySetTransferEnableEventsExact(False, finalStopDetail)
        enforcementFailed = True
        Err.Raise TRANSFER_RECOVERY_HARD_BARRIER_ERROR, _
                  TRANSFER_RECOVERY_HARD_BARRIER_SOURCE & _
                      "TryEnterTransferRecoveryStateExact/RecoveryUnconfirmed", _
                  gateDetail
    End If
    applicationStateProblems = vbNullString
    If Not AppStateIsRestored(applicationStateProblems) Then
        gateDetail = "Application状態を安全に確認できません: " & _
                     applicationStateProblems
        Call TrySetTransferEnableEventsExact(False, finalStopDetail)
        enforcementFailed = True
        Err.Raise TRANSFER_RECOVERY_HARD_BARRIER_ERROR, _
                  TRANSFER_RECOVERY_HARD_BARRIER_SOURCE & _
                      "TryEnterTransferRecoveryStateExact/AppStateUnconfirmed", _
                  gateDetail
    End If
    finalStopDetail = vbNullString
    If Not TrySetTransferEnableEventsExact(False, finalStopDetail) Then
        gateDetail = "Recovery成功返却直前のExcelイベント停止を確認できません: " & _
                     finalStopDetail
        enforcementFailed = True
        Err.Raise TRANSFER_RECOVERY_HARD_BARRIER_ERROR, _
                  TRANSFER_RECOVERY_HARD_BARRIER_SOURCE & _
                      "TryEnterTransferRecoveryStateExact/FinalFalseFailed", _
                  gateDetail
    End If
    enforcementFailed = True
    Err.Raise TRANSFER_RECOVERY_HARD_BARRIER_ERROR, _
              TRANSFER_RECOVERY_HARD_BARRIER_SOURCE & _
                  "TryEnterTransferRecoveryStateExact/EnforceReturned", _
              recoveryDetail
End Function

Private Function RecordTransferApplicationLeaseFailure( _
        ByVal operationName As String, _
        ByVal dataCommitted As Boolean, _
        ByRef detailText As String, _
        ByRef recoveryEnforcementFailed As Boolean) As Boolean
    Dim recoveryConfirmed As Boolean
    Dim eventStateDetail As String, gateDetail As String
    Dim applicationStateProblems As String

    '呼出元がEnableEvents=Falseを設定・読戻し済みの場合だけ使用する。
    recoveryConfirmed = _
        TryEnterTransferRecoveryStateExact( _
            detailText, gateDetail, recoveryEnforcementFailed)
    If Not recoveryConfirmed Then
        AppendTransferDetail detailText, _
            "要復旧状態を一意に確認できず、チェック・状態表示を見送りました: " & _
            gateDetail
        Exit Function
    End If

    On Error Resume Next
    Err.Clear
    AddCheck "エラー", operationName & "のExcel状態復元", detailText
    Err.Clear
    If dataCommitted Then
        SetInputStatus operationName & _
            "のデータ処理は確定済みですが、Excel状態の復元に失敗しました。" & _
            "案件の要復旧状態を確認しました。再実行・上書き保存をせずC_チェックを確認してください。", _
            True
    Else
        SetInputStatus operationName & _
            "の終了時にExcel状態を復元できませんでした。案件の要復旧状態を確認しました。" & _
            "上書き保存をせずC_チェックを確認してください。", True
    End If
    Err.Clear
    On Error GoTo 0

    '診断書込み後にもFalseとRecovery二重状態を再確認し、安全性を明示返却する。
    If Not TrySetTransferEnableEventsExact(False, eventStateDetail) Then
        AppendTransferDetail detailText, _
            "復旧診断後にExcelイベント停止を再確認できません: " & _
            eventStateDetail
        Exit Function
    End If
    If Not TransferRecoveryStateConfirmed() Then
        AppendTransferDetail detailText, _
            "復旧診断後に復旧ラッチと案件要復旧状態を一意に読み返せません。"
        Exit Function
    End If
    applicationStateProblems = vbNullString
    If Not AppStateIsRestored(applicationStateProblems) Then
        AppendTransferDetail detailText, _
            "復旧診断後にApplication状態の安全を確認できません: " & _
            applicationStateProblems
        Exit Function
    End If
    RecordTransferApplicationLeaseFailure = True
End Function

Private Function TryRestoreTransferEnableEvents(ByVal previousValue As Boolean, _
                                                 ByVal operationName As String, _
                                                 ByVal dataCommitted As Boolean, _
                                                 ByVal recoveryRequiredOnEntry As Boolean, _
                                                 ByVal recoveryConfirmedOnEntry As Boolean, _
                                                 ByRef recoveryEnforcementFailed As Boolean, _
                                                 ByRef detailText As String) As Boolean
    Dim firstDetail As String, retryDetail As String, stopDetail As String
    Dim finalDetail As String, convergenceDetail As String
    Dim eventsStopped As Boolean, recoveryConfirmed As Boolean
    Dim stateProblems As String

    detailText = vbNullString
    If recoveryEnforcementFailed Then
        If Not TrySetTransferEnableEventsExact(False, stopDetail) Then _
            detailText = _
                "Recovery強制エラー後にExcelイベントをFalseへ収束できません: " & _
                stopDetail
        Err.Raise TRANSFER_RECOVERY_HARD_BARRIER_ERROR, _
                  TRANSFER_RECOVERY_HARD_BARRIER_SOURCE & _
                      "TryRestoreTransferEnableEvents/RecoveryTerminal", _
                  detailText
    End If
    If TrySetTransferEnableEventsExact(previousValue, firstDetail) Then
        TryRestoreTransferEnableEvents = True
        Exit Function
    End If
    If TrySetTransferEnableEventsExact(previousValue, retryDetail) Then
        TryRestoreTransferEnableEvents = True
        Exit Function
    End If
    detailText = "Excelイベント状態を開始値へ復元できませんでした。初回=" & _
                 firstDetail & " / 再試行=" & retryDetail
    eventsStopped = TrySetTransferEnableEventsExact(False, stopDetail)
    If eventsStopped Then
        AppendTransferDetail detailText, _
            "要復旧記録前にExcelイベント停止を読戻し確認しました。"
    Else
        AppendTransferDetail detailText, _
            "Excelイベント停止を確認できず、ブックへの復旧記録を見送りました: " & _
            stopDetail
        Exit Function
    End If
    If Not previousValue Then
        '開始値自体がFalseなら三回目のexact停止でleaseは復元済みである。
        TryRestoreTransferEnableEvents = True
        Exit Function
    End If

    recoveryConfirmed = recoveryConfirmedOnEntry
    If recoveryRequiredOnEntry And recoveryConfirmed Then _
        recoveryConfirmed = TransferRecoveryStateConfirmed()
    If Not recoveryConfirmed Then
        recoveryConfirmed = _
            RecordTransferApplicationLeaseFailure( _
                operationName, dataCommitted, detailText, _
                recoveryEnforcementFailed)
    End If
    '開始値Trueへの再試行は、post-Enforce False、Recovery二重読戻し、
    'Application復元の全条件を満たした場合だけ許可する。
    If Not TrySetTransferEnableEventsExact(False, stopDetail) Then
        AppendTransferDetail detailText, _
            "Recovery後にExcelイベント停止を確認できず、開始値復元を見送りました: " & _
            stopDetail
        Exit Function
    End If
    If recoveryEnforcementFailed Then
        AppendTransferDetail detailText, _
            "Recovery強制が失敗したため、Recovery読戻しと開始値復元を行いません。"
        Exit Function
    End If
    If Not recoveryConfirmed Then
        AppendTransferDetail detailText, _
            "要復旧状態を一意に確認できないため、ExcelイベントをFalseに維持しました。"
        Exit Function
    End If
    If Not TransferRecoveryStateConfirmed() Then
        AppendTransferDetail detailText, _
            "要復旧状態を一意に確認できないため、ExcelイベントをFalseに維持しました。"
        Exit Function
    End If
    stateProblems = vbNullString
    If Not AppStateIsRestored(stateProblems) Then
        AppendTransferDetail detailText, _
            "Application状態が安全に復元されていないため、" & _
            "ExcelイベントをFalseに維持しました。 " & stateProblems
        Exit Function
    End If
    On Error Resume Next
    MsgBox operationName & "の終了時にExcelイベント状態を開始値へ戻せませんでした。" & _
           vbCrLf & "ブックへの書込みは停止しました。現在のブックを上書き保存しないでください。" & _
           vbCrLf & detailText, vbCritical, "Excel状態を確認できません"
    On Error GoTo 0

    '外部メッセージの後にも三条件を再確認し、Trueへの最終再試行を一度だけ許可する。
    If Not TrySetTransferEnableEventsExact(False, stopDetail) Then
        AppendTransferDetail detailText, _
            "最終再試行前にExcelイベント停止を再確認できません: " & stopDetail
        Exit Function
    End If
    If Not TransferRecoveryStateConfirmed() Then
        AppendTransferDetail detailText, _
            "最終再試行前に要復旧状態を再確認できず、ExcelイベントをFalseに維持しました。"
        Exit Function
    End If
    stateProblems = vbNullString
    If Not AppStateIsRestored(stateProblems) Then
        AppendTransferDetail detailText, _
            "最終再試行前にApplication状態の安全を確認できず、" & _
            "ExcelイベントをFalseに維持しました。 " & stateProblems
        Exit Function
    End If
    If TrySetTransferEnableEventsExact(previousValue, finalDetail) Then
        TryRestoreTransferEnableEvents = True
        Exit Function
    End If
    AppendTransferDetail detailText, _
        "最終再試行でも開始値へ復元できません: " & finalDetail
    If Not TrySetTransferEnableEventsExact(False, convergenceDetail) Then _
        AppendTransferDetail detailText, _
            "Excelイベントを安全停止へ収束できません: " & convergenceDetail
End Function

Private Function FinishTransferApplicationLease( _
        ByRef leaseStarted As Boolean, _
        ByVal entryEvents As Boolean, _
        ByVal entryEventsCaptured As Boolean, _
        ByVal operationName As String, _
        ByVal dataCommitted As Boolean, _
        ByRef detailText As String, _
        Optional ByVal recoveryRequiredOnEntry As Boolean = False, _
        Optional ByVal recoveryConfirmedOnEntry As Boolean = False, _
        Optional ByVal recoveryEnforcementFailedOnEntry As Boolean = False) As Boolean
    Dim eventsStopped As Boolean, keyRestoreFailed As Boolean
    Dim applicationRestoreFailed As Boolean, finishFailed As Boolean
    Dim applicationStateSafe As Boolean, recoveryGateRequired As Boolean
    Dim recoveryConfirmed As Boolean, recoveryEnforcementFailed As Boolean
    Dim eventDetail As String, keyErrorDescription As String
    Dim appErrorNumber As Long, appErrorDescription As String
    Dim forceErrorNumber As Long, forceErrorDescription As String
    Dim eventRestoreDetail As String, stateProblems As String

    recoveryGateRequired = recoveryRequiredOnEntry
    recoveryConfirmed = recoveryConfirmedOnEntry
    recoveryEnforcementFailed = recoveryEnforcementFailedOnEntry
    If recoveryEnforcementFailed Then
        eventsStopped = TrySetTransferEnableEventsExact(False, eventDetail)
        Err.Raise TRANSFER_RECOVERY_HARD_BARRIER_ERROR, _
                  TRANSFER_RECOVERY_HARD_BARRIER_SOURCE & _
                      "FinishTransferApplicationLease/RecoveryTerminal", _
                  detailText
    End If

    If leaseStarted Then
        eventsStopped = TrySetTransferEnableEventsExact(False, eventDetail)
        If eventsStopped Then
            If recoveryGateRequired Then
                finishFailed = True
                If recoveryEnforcementFailed Then
                    recoveryConfirmed = False
                Else
                    If recoveryConfirmed Then _
                        recoveryConfirmed = TransferRecoveryStateConfirmed()
                    If Not recoveryConfirmed Then _
                        recoveryConfirmed = _
                            RecordTransferApplicationLeaseFailure( _
                                operationName, dataCommitted, detailText, _
                                recoveryEnforcementFailed)
                End If
                eventDetail = vbNullString
                eventsStopped = _
                    TrySetTransferEnableEventsExact(False, eventDetail)
                If Not eventsStopped Then _
                    AppendTransferDetail detailText, _
                        "保留した復旧記録後にExcelイベント停止を再確認できません: " & _
                        eventDetail
                If eventsStopped And Not recoveryConfirmed Then _
                    AppendTransferDetail detailText, _
                        "保留された要復旧状態を一意に確認できません。"
            End If
            If eventsStopped And Not recoveryEnforcementFailed And _
               (Not recoveryGateRequired Or recoveryConfirmed) Then
                On Error Resume Next
                Err.Clear
                EnableInputKeys
                If Err.Number <> 0 Then
                    keyRestoreFailed = True
                    keyErrorDescription = "Err " & CStr(Err.Number) & " " & Err.Description
                End If
                Err.Clear
                On Error GoTo 0
            End If
            If keyRestoreFailed Then
                finishFailed = True
                recoveryGateRequired = True
                AppendTransferDetail detailText, _
                    "入力キー状態の復元エラー: " & keyErrorDescription
                recoveryConfirmed = _
                    RecordTransferApplicationLeaseFailure( _
                        operationName, dataCommitted, detailText, _
                        recoveryEnforcementFailed)
                eventDetail = vbNullString
                eventsStopped = _
                    TrySetTransferEnableEventsExact(False, eventDetail)
                If Not eventsStopped Then _
                    AppendTransferDetail detailText, _
                        "入力キー復元失敗のRecovery後にイベント停止を確認できません: " & _
                        eventDetail
            End If
        Else
            finishFailed = True
            recoveryGateRequired = True
            recoveryConfirmed = False
            AppendTransferDetail detailText, _
                "入力キー復元前にExcelイベント停止を確認できません: " & eventDetail
        End If

        On Error Resume Next
        Err.Clear
        AppEnd
        appErrorNumber = Err.Number
        appErrorDescription = Err.Description
        Err.Clear
        If appErrorNumber = 0 Then leaseStarted = False
        If appErrorNumber <> 0 Then
            If Not recoveryEnforcementFailed Then
                AppForceRestore
                forceErrorNumber = Err.Number
                forceErrorDescription = Err.Description
                Err.Clear
                If forceErrorNumber = 0 Then leaseStarted = False
            End If
        End If
        On Error GoTo 0
        If recoveryEnforcementFailed Then
            finishFailed = True
            recoveryGateRequired = True
            recoveryConfirmed = False
            applicationStateSafe = False
            If appErrorNumber <> 0 Then
                AppendTransferDetail detailText, _
                    "Recovery強制エラー後にAppEndも失敗しました: Err " & _
                    CStr(appErrorNumber) & " " & appErrorDescription
            Else
                AppendTransferDetail detailText, _
                    "Recovery強制が失敗したため、Application状態の強制復元と読戻しを行いませんでした。"
            End If
        Else
            stateProblems = vbNullString
            applicationStateSafe = AppStateIsRestored(stateProblems)
            applicationRestoreFailed = _
                (appErrorNumber <> 0 Or forceErrorNumber <> 0 Or _
                 Not applicationStateSafe)
            If applicationRestoreFailed Then
                finishFailed = True
                recoveryGateRequired = True
                AppendTransferDetail detailText, _
                    "Excel状態の復元エラー: Err " & CStr(appErrorNumber) & _
                    " " & appErrorDescription
                If forceErrorNumber <> 0 Then _
                    AppendTransferDetail detailText, _
                        "強制復元再試行: Err " & CStr(forceErrorNumber) & _
                        " " & forceErrorDescription
                If Len(stateProblems) > 0 Then _
                    AppendTransferDetail detailText, _
                        "Application状態の読戻し不一致: " & stateProblems
                eventDetail = vbNullString
                eventsStopped = TrySetTransferEnableEventsExact(False, eventDetail)
                If eventsStopped Then
                    recoveryConfirmed = _
                        RecordTransferApplicationLeaseFailure( _
                            operationName, dataCommitted, detailText, _
                            recoveryEnforcementFailed)
                Else
                    recoveryConfirmed = False
                    AppendTransferDetail detailText, _
                        "Excelイベント停止を確認できず、復旧記録を見送りました: " & eventDetail
                End If
            End If
        End If
    Else
        If recoveryEnforcementFailed Then
            finishFailed = True
            recoveryGateRequired = True
            recoveryConfirmed = False
            applicationStateSafe = False
        Else
            stateProblems = vbNullString
            applicationStateSafe = AppStateIsRestored(stateProblems)
            If Not applicationStateSafe Then
                finishFailed = True
                recoveryGateRequired = True
                recoveryConfirmed = False
                AppendTransferDetail detailText, _
                    "開始に失敗したApplication状態を安全に確認できません: " & _
                    stateProblems
            End If
        End If
    End If

    '最後のイベント返却前に、False、Recovery二重状態、Application状態を独立に確認する。
    eventDetail = vbNullString
    eventsStopped = TrySetTransferEnableEventsExact(False, eventDetail)
    If Not eventsStopped Then
        finishFailed = True
        recoveryGateRequired = True
        recoveryConfirmed = False
        AppendTransferDetail detailText, _
            "終了時の最終イベント停止を確認できません: " & eventDetail
    End If
    If recoveryEnforcementFailed Then
        recoveryConfirmed = False
        applicationStateSafe = False
    Else
        stateProblems = vbNullString
        applicationStateSafe = AppStateIsRestored(stateProblems)
        If Not applicationStateSafe Then
            finishFailed = True
            recoveryGateRequired = True
            AppendTransferDetail detailText, _
                "終了時にApplication状態の安全を確認できません: " & stateProblems
        End If
        If recoveryGateRequired And recoveryConfirmed Then _
            recoveryConfirmed = TransferRecoveryStateConfirmed()
        If recoveryGateRequired And Not recoveryConfirmed And _
           eventsStopped And applicationStateSafe Then
            recoveryConfirmed = _
                RecordTransferApplicationLeaseFailure( _
                    operationName, dataCommitted, detailText, _
                    recoveryEnforcementFailed)
            eventDetail = vbNullString
            eventsStopped = TrySetTransferEnableEventsExact(False, eventDetail)
            If Not eventsStopped Then _
                AppendTransferDetail detailText, _
                    "最終Recovery後にExcelイベント停止を確認できません: " & _
                    eventDetail
            If recoveryEnforcementFailed Then
                recoveryConfirmed = False
                applicationStateSafe = False
            Else
                If Not eventsStopped Then recoveryConfirmed = False
                If recoveryConfirmed Then _
                    recoveryConfirmed = TransferRecoveryStateConfirmed()
                stateProblems = vbNullString
                applicationStateSafe = AppStateIsRestored(stateProblems)
            End If
        End If
    End If

    If finishFailed Then
        On Error Resume Next
        MsgBox operationName & "の終了処理を安全に完了できませんでした。" & vbCrLf & _
               "再実行・上書き保存をせず、Excelを閉じる前に状態を確認してください。" & _
               IIf(Len(detailText) > 0, vbCrLf & detailText, ""), _
               vbCritical, "終了状態を確認できません"
        On Error GoTo 0
    End If

    'Application leaseの返却後に行う最後の状態操作。以後ブックへ書き込まない。
    If Not entryEventsCaptured Then
        AppendTransferDetail detailText, "Excelイベントの開始状態が未取得です。"
        Exit Function
    End If
    If Not entryEvents Then
        If Not eventsStopped Then _
            AppendTransferDetail detailText, _
                "開始値Falseへイベント状態を復元できません。"
        FinishTransferApplicationLease = _
            (eventsStopped And Not finishFailed)
        Exit Function
    End If
    If recoveryEnforcementFailed Or Not eventsStopped Or Not applicationStateSafe Or _
       (recoveryGateRequired And Not recoveryConfirmed) Then
        AppendTransferDetail detailText, _
            "Recovery・イベント停止・Application状態の安全条件がそろわないため、" & _
            "開始値Trueへの復元を行いませんでした。"
        eventDetail = vbNullString
        eventsStopped = TrySetTransferEnableEventsExact(False, eventDetail)
        If Not eventsStopped Then _
            AppendTransferDetail detailText, _
                "ExcelイベントをFalseへ収束できません: " & eventDetail
        Exit Function
    End If
    If Not TryRestoreTransferEnableEvents(entryEvents, operationName, _
                                          dataCommitted, recoveryGateRequired, _
                                          recoveryConfirmed, _
                                          recoveryEnforcementFailed, _
                                          eventRestoreDetail) Then
        finishFailed = True
        AppendTransferDetail detailText, eventRestoreDetail
    End If
    FinishTransferApplicationLease = Not finishFailed
End Function

Private Sub CheckUnsupportedInputCells(ByVal ws As Worksheet, ByVal lastInputRow As Long, _
                                       ByRef errorCount As Long, _
                                       ByRef firstMessage As String, ByRef firstAddress As String)
    '貼り付けで入力規則を迂回されても、数式・エラー値を値なしとして黙って落とさない。
    '入力値は登録時に定数へ固定する設計なので、数式は計算結果が見えていても明示的に拒否する。
    Dim accountRange As Range
    If ws Is Nothing Then Exit Sub
    Set accountRange = Union(ws.Range(CELL_BANK), ws.Range(CELL_BRANCH), ws.Range(CELL_PERSON), _
                             ws.Range(CELL_RELATIONSHIP), ws.Range(CELL_ACCOUNT_TYPE), _
                             ws.Range(CELL_ACCOUNT_NO), ws.Range(CELL_OPEN_DATE), ws.Range(CELL_CLOSE_DATE))
    CheckUnsupportedInputRange accountRange, "口座情報", errorCount, firstMessage, firstAddress
    CheckUnsupportedInputRange ws.Range(ws.Cells(BAL_VALUE_ROW, BAL_FIRST_COL), _
                                         ws.Cells(BAL_VALUE_ROW, BAL_MAX_COL)), _
                               "残高入力欄", errorCount, firstMessage, firstAddress
    If lastInputRow >= TX_FIRST_ROW Then
        CheckUnsupportedInputRange ws.Range(ws.Cells(TX_FIRST_ROW, COL_TX_YEAR), _
                                             ws.Cells(lastInputRow, COL_TX_BALANCE)), _
                                   "取引入力欄", errorCount, firstMessage, firstAddress
    End If
End Sub

Private Sub CheckUnsupportedInputRange(ByVal target As Range, ByVal labelText As String, _
                                       ByRef errorCount As Long, ByRef firstMessage As String, _
                                       ByRef firstAddress As String)
    Dim badCell As Range
    Dim checkAddress As String
    If target Is Nothing Then Exit Sub
    checkAddress = target.Cells(1, 1).Address(False, False)
    If Not TryFindFirstFormulaCell(target, badCell) Then
        AddValidationError labelText & "の数式検査に失敗しました。登録は行っていません。", _
                           checkAddress, errorCount, firstMessage, firstAddress
        Exit Sub
    End If
    If Not badCell Is Nothing Then
        AddValidationError labelText & "に数式があります。値として貼り付け直してください。", _
                           badCell.Address(False, False), errorCount, firstMessage, firstAddress
    End If

    Set badCell = Nothing
    If Not TryFindFirstErrorConstantCell(target, badCell) Then
        AddValidationError labelText & "のエラー値検査に失敗しました。登録は行っていません。", _
                           checkAddress, errorCount, firstMessage, firstAddress
        Exit Sub
    End If
    If Not badCell Is Nothing Then
        AddValidationError labelText & "にエラー値があります。内容を修正してください。", _
                           badCell.Address(False, False), errorCount, firstMessage, firstAddress
    End If
End Sub

Private Sub AddMaxLengthError(ByVal valueText As String, ByVal maxLength As Long, ByVal labelText As String, _
                              ByVal addressText As String, ByRef errorCount As Long, _
                              ByRef firstMessage As String, ByRef firstAddress As String)
    If Len(valueText) > maxLength Then
        AddValidationError labelText & "は" & CStr(maxLength) & "文字以内にしてください。", _
                           addressText, errorCount, firstMessage, firstAddress
    End If
End Sub

Private Function LastInputTransactionRow(ByVal ws As Worksheet) As Long
    Dim foundCell As Range
    Dim errorNumber As Long, errorDescription As String
    LastInputTransactionRow = TX_FIRST_ROW - 1
    If ws Is Nothing Then _
        Err.Raise vbObjectError + 3513, "LastInputTransactionRow", _
                  "取引入力欄を取得できません。登録は行っていません。"
    On Error GoTo EH
    Set foundCell = ws.Range(ws.Cells(TX_FIRST_ROW, COL_TX_YEAR), ws.Cells(TX_LAST_ROW, COL_TX_BALANCE)).Find( _
                    What:="*", After:=ws.Cells(TX_FIRST_ROW, COL_TX_YEAR), LookIn:=xlFormulas, _
                    LookAt:=xlPart, SearchOrder:=xlByRows, SearchDirection:=xlPrevious, _
                    MatchCase:=False, MatchByte:=False, SearchFormat:=False)
    If Not foundCell Is Nothing Then LastInputTransactionRow = foundCell.Row
    Exit Function
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    Err.Raise errorNumber, "LastInputTransactionRow", _
              "取引入力欄の最終行を安全に確認できません。登録は行っていません。" & _
              IIf(Len(errorDescription) > 0, " " & errorDescription, "")
End Function

Private Sub AddRequiredError(ByVal valueText As String, ByVal messageText As String, ByVal addressText As String, _
                             ByRef errorCount As Long, ByRef firstMessage As String, ByRef firstAddress As String)
    If Len(CellText(valueText)) = 0 Then AddValidationError messageText, addressText, errorCount, firstMessage, firstAddress
End Sub

Private Sub AddValidationError(ByVal messageText As String, ByVal addressText As String, _
                               ByRef errorCount As Long, ByRef firstMessage As String, ByRef firstAddress As String)
    errorCount = errorCount + 1
    If Len(firstMessage) = 0 Then
        firstMessage = messageText
        firstAddress = addressText
    End If
End Sub

Private Function ParseAmountOrError(ByVal valueIn As Variant, ByRef ok As Boolean) As Variant
    ParseAmountOrError = TryParseAmount(valueIn, ok)
End Function

Private Sub PreserveHiddenBalancesForEdit(ByVal wsIn As Worksheet, ByVal wsBal As Worksheet, ByVal accountID As String, _
                                          ByVal bankName As String, ByVal branchName As String, ByVal personName As String, _
                                          ByVal relationshipText As String, ByVal accountType As String, ByVal accountNo As String, _
                                          ByVal openDate As Variant, ByVal closeDate As Variant, _
                                          ByRef txData() As Variant, ByRef txCount As Long, _
                                          ByRef balData() As Variant, ByRef balCount As Long, _
                                          ByRef preservedCount As Long, ByRef validationCount As Long, _
                                          ByRef firstMessage As String, ByRef firstAddress As String)
    Dim lastR As Long, r As Long, gridCol As Long, memoCol As Long
    Dim sourceRow As Long
    Dim balanceDate As Variant, amountValue As Variant
    Dim labelText As String, memoText As String
    Dim amountOK As Boolean
    Dim seenHiddenDates As Object
    Dim balanceData As Variant

    Set seenHiddenDates = CreateObject("Scripting.Dictionary")
    seenHiddenDates.CompareMode = vbTextCompare
    memoCol = BalanceMemoCol(wsIn)
    lastR = LastUsedRowInSheet(wsBal)
    If lastR < 2 Then Exit Sub
    '訂正対象が大規模保管の末尾にあっても、行ごとのExcel読取を行わない。
    balanceData = wsBal.Range(wsBal.Cells(2, 1), wsBal.Cells(lastR, WORK_BAL_COL_PERSON_ID)).Value2
    For r = 1 To UBound(balanceData, 1)
        sourceRow = r + 1
        If CellText(balanceData(r, WORK_BAL_COL_ACCOUNT_ID)) = accountID Then
            balanceDate = balanceData(r, 8)
            gridCol = FindBalanceGridColumn(wsIn, balanceDate)
            If gridCol = 0 Then
                If Not IsDate(balanceDate) Then
                    AddValidationError "表示期間外の既存残高に不正な基準日があります。", CELL_OPEN_DATE, validationCount, firstMessage, firstAddress
                ElseIf seenHiddenDates.Exists(Format$(CDate(balanceDate), "yyyymmdd")) Then
                    AddValidationError "表示期間外の既存残高が同じ日付で重複しています。該当する登録内容を確認してください。", CELL_OPEN_DATE, validationCount, firstMessage, firstAddress
                ElseIf Not AccountExistsAtDate(balanceDate, openDate, closeDate) Then
                    AddValidationError "表示期間外の既存残高（" & Format$(CDate(balanceDate), "yyyy/m/d") & "）が、新しい開設日・解約日の範囲外になります。", _
                                       CELL_OPEN_DATE, validationCount, firstMessage, firstAddress
                Else
                    seenHiddenDates.Add Format$(CDate(balanceDate), "yyyymmdd"), True
                    amountValue = ParseAmountOrError(balanceData(r, 10), amountOK)
                    If Not amountOK Or Not HasText(amountValue) Then
                        AddValidationError "表示期間外の既存残高（" & Format$(CDate(balanceDate), "yyyy/m/d") & "）の金額が不正です。", _
                                           CELL_OPEN_DATE, validationCount, firstMessage, firstAddress
                    Else
                        labelText = CellText(balanceData(r, 9))
                        If Len(labelText) = 0 Then labelText = Format$(CDate(balanceDate), "yyyy/m/d") & "時点残高"
                        memoText = CellText(wsIn.Cells(BAL_VALUE_ROW, memoCol).Value)
                        If Len(memoText) = 0 Then memoText = CellText(balanceData(r, 11))
                        balCount = balCount + 1
                        FillPreparedBalance balData, balCount, personName, bankName, branchName, accountType, accountNo, _
                                            openDate, closeDate, CDate(balanceDate), labelText, amountValue, memoText, relationshipText
                        txCount = txCount + 1
                        FillPreparedTx txData, txCount, bankName, branchName, personName, relationshipText, accountType, accountNo, _
                                       CDate(balanceDate), "", "", "", "", "", BalanceTekiyoLabel(labelText), amountValue, _
                                       RECORD_BALANCE, 600000 + sourceRow
                        preservedCount = preservedCount + 1
                    End If
                End If
            End If
        End If
    Next r
End Sub

Private Function FindBalanceGridColumn(ByVal ws As Worksheet, ByVal targetDate As Variant) As Long
    Dim c As Long, memoCol As Long
    If ws Is Nothing Or Not IsDate(targetDate) Then Exit Function
    memoCol = BalanceMemoCol(ws)
    For c = BAL_FIRST_COL To memoCol - 1
        If IsDate(ws.Cells(BAL_DATE_ROW, c).Value) Then
            If CLng(CDate(ws.Cells(BAL_DATE_ROW, c).Value)) = CLng(CDate(targetDate)) Then
                FindBalanceGridColumn = c
                Exit Function
            End If
        End If
    Next c
End Function

Private Sub AssignPreparedTransactionIDs(ByRef txData() As Variant, ByVal txCount As Long, _
                                         ByRef oldTx As Variant, ByVal oldTxCount As Long)
    Dim oldBySignature As Object, idQueue As Collection
    Dim newPositions() As Long, newIDs As Variant
    Dim signatureText As String, transactionID As String
    Dim r As Long, newCount As Long
    If txCount <= 0 Then Exit Sub
    Set oldBySignature = CreateObject("Scripting.Dictionary")
    oldBySignature.CompareMode = vbBinaryCompare
    If oldTxCount > 0 Then
        For r = 1 To oldTxCount
            signatureText = StoredTransactionIdentitySignature(oldTx, r)
            transactionID = CellText(oldTx(r, WORK_TX_COL_TRANSACTION_ID))
            If Len(transactionID) = 0 Then _
                Err.Raise vbObjectError + 2061, "AssignPreparedTransactionIDs", _
                          "訂正対象の既存取引に取引IDがありません。該当する登録内容を確認してください。"
            If Not oldBySignature.Exists(signatureText) Then
                Set idQueue = New Collection
                oldBySignature.Add signatureText, idQueue
            Else
                Set idQueue = oldBySignature(signatureText)
            End If
            idQueue.Add transactionID
        Next r
    End If
    ReDim newPositions(1 To txCount)
    For r = 1 To txCount
        signatureText = PreparedTransactionIdentitySignature(txData, r)
        If oldBySignature.Exists(signatureText) Then
            Set idQueue = oldBySignature(signatureText)
            If idQueue.Count > 0 Then
                txData(r, WORK_TX_COL_TRANSACTION_ID) = CStr(idQueue(1))
                idQueue.Remove 1
            Else
                newCount = newCount + 1: newPositions(newCount) = r
            End If
        Else
            newCount = newCount + 1: newPositions(newCount) = r
        End If
    Next r
    If newCount > 0 Then
        newIDs = ReserveInternalIds(STATE_NEXT_TRANSACTION, "T", newCount)
        For r = 1 To newCount
            txData(newPositions(r), WORK_TX_COL_TRANSACTION_ID) = CStr(newIDs(r))
        Next r
    End If
End Sub

Private Sub AssignPreparedBalanceIDs(ByRef balData() As Variant, ByVal balCount As Long, _
                                     ByRef oldBal As Variant, ByVal oldBalCount As Long)
    Dim oldBySignature As Object, idQueue As Collection
    Dim newPositions() As Long, newIDs As Variant
    Dim signatureText As String, balanceID As String
    Dim r As Long, newCount As Long
    If balCount <= 0 Then Exit Sub
    Set oldBySignature = CreateObject("Scripting.Dictionary")
    oldBySignature.CompareMode = vbBinaryCompare
    If oldBalCount > 0 Then
        For r = 1 To oldBalCount
            signatureText = StoredBalanceIdentitySignature(oldBal, r)
            balanceID = CellText(oldBal(r, WORK_BAL_COL_BALANCE_ID))
            If Len(balanceID) = 0 Then _
                Err.Raise vbObjectError + 2062, "AssignPreparedBalanceIDs", _
                          "訂正対象の既存残高に残高IDがありません。該当する登録内容を確認してください。"
            If Not oldBySignature.Exists(signatureText) Then
                Set idQueue = New Collection
                oldBySignature.Add signatureText, idQueue
            Else
                Set idQueue = oldBySignature(signatureText)
            End If
            idQueue.Add balanceID
        Next r
    End If
    ReDim newPositions(1 To balCount)
    For r = 1 To balCount
        signatureText = PreparedBalanceIdentitySignature(balData, r)
        If oldBySignature.Exists(signatureText) Then
            Set idQueue = oldBySignature(signatureText)
            If idQueue.Count > 0 Then
                balData(r, WORK_BAL_COL_BALANCE_ID) = CStr(idQueue(1))
                idQueue.Remove 1
            Else
                newCount = newCount + 1: newPositions(newCount) = r
            End If
        Else
            newCount = newCount + 1: newPositions(newCount) = r
        End If
    Next r
    If newCount > 0 Then
        newIDs = ReserveInternalIds(STATE_NEXT_BALANCE, "B", newCount)
        For r = 1 To newCount
            balData(newPositions(r), WORK_BAL_COL_BALANCE_ID) = CStr(newIDs(r))
        Next r
    End If
End Sub

Private Function PreparedTransactionIdentitySignature(ByRef data() As Variant, ByVal rowNo As Long) As String
    PreparedTransactionIdentitySignature = TransactionIdentitySignatureFromValues( _
        data(rowNo, OUT_COL_DATE), data(rowNo, OUT_COL_TIME), data(rowNo, OUT_COL_WITHDRAW), _
        data(rowNo, OUT_COL_DEPOSIT), data(rowNo, OUT_COL_SHOP), data(rowNo, OUT_COL_MACHINE), _
        data(rowNo, OUT_COL_TEKIYO), data(rowNo, OUT_COL_OTHER), _
        data(rowNo, WORK_TX_COL_RECORD_TYPE))
End Function

Private Function StoredTransactionIdentitySignature(ByRef data As Variant, ByVal rowNo As Long) As String
    StoredTransactionIdentitySignature = TransactionIdentitySignatureFromValues( _
        data(rowNo, OUT_COL_DATE), data(rowNo, OUT_COL_TIME), data(rowNo, OUT_COL_WITHDRAW), _
        data(rowNo, OUT_COL_DEPOSIT), data(rowNo, OUT_COL_SHOP), data(rowNo, OUT_COL_MACHINE), _
        data(rowNo, OUT_COL_TEKIYO), data(rowNo, OUT_COL_OTHER), _
        data(rowNo, WORK_TX_COL_RECORD_TYPE))
End Function

Private Function TransactionIdentitySignatureFromValues( _
        ByVal dateInputValue As Variant, ByVal timeInputValue As Variant, ByVal withdrawalValue As Variant, _
        ByVal depositValue As Variant, ByVal shopValue As Variant, ByVal machineValue As Variant, _
        ByVal tekiyoValue As Variant, ByVal balanceValue As Variant, ByVal recordTypeValue As Variant) As String
    TransactionIdentitySignatureFromValues = _
        TransferSignaturePart(TransferDateSignature(dateInputValue)) & _
        TransferSignaturePart(TransferTimeSignature(timeInputValue)) & _
        TransferSignaturePart(TransferAmountSignature(withdrawalValue)) & _
        TransferSignaturePart(TransferAmountSignature(depositValue)) & _
        TransferSignaturePart(CellText(shopValue)) & TransferSignaturePart(CellText(machineValue)) & _
        TransferSignaturePart(CellText(tekiyoValue)) & _
        TransferSignaturePart(TransferAmountSignature(balanceValue)) & _
        TransferSignaturePart(CellText(recordTypeValue))
End Function

Private Function PreparedBalanceIdentitySignature(ByRef data() As Variant, ByVal rowNo As Long) As String
    PreparedBalanceIdentitySignature = BalanceIdentitySignatureFromValues( _
        data(rowNo, 8), data(rowNo, 9), data(rowNo, 10), data(rowNo, 11))
End Function

Private Function StoredBalanceIdentitySignature(ByRef data As Variant, ByVal rowNo As Long) As String
    StoredBalanceIdentitySignature = BalanceIdentitySignatureFromValues( _
        data(rowNo, 8), data(rowNo, 9), data(rowNo, 10), data(rowNo, 11))
End Function

Private Function BalanceIdentitySignatureFromValues(ByVal dateInputValue As Variant, _
                                                    ByVal labelValue As Variant, _
                                                    ByVal amountValue As Variant, _
                                                    ByVal memoValue As Variant) As String
    BalanceIdentitySignatureFromValues = TransferSignaturePart(TransferDateSignature(dateInputValue)) & _
                                         TransferSignaturePart(CellText(labelValue)) & _
                                         TransferSignaturePart(TransferAmountSignature(amountValue)) & _
                                         TransferSignaturePart(CellText(memoValue))
End Function

Private Function TransferDateSignature(ByVal valueIn As Variant) As String
    If IsDate(valueIn) Then
        TransferDateSignature = Format$(CLng(VBA.DateValue(CDate(valueIn))), "0")
    Else
        TransferDateSignature = CellText(valueIn)
    End If
End Function

Private Function TransferTimeSignature(ByVal valueIn As Variant) As String
    If IsError(valueIn) Or IsNull(valueIn) Or IsEmpty(valueIn) Then Exit Function
    If VarType(valueIn) = vbString And Len(Trim$(CStr(valueIn))) = 0 Then Exit Function
    If IsDate(valueIn) Or IsNumeric(valueIn) Then
        On Error GoTo RawValue
        TransferTimeSignature = Format$(CDbl(VBA.TimeValue(CDate(valueIn))), "0.0000000000")
        Exit Function
    End If
RawValue:
    TransferTimeSignature = CellText(valueIn)
End Function

Private Function TransferAmountSignature(ByVal valueIn As Variant) As String
    If IsError(valueIn) Or IsNull(valueIn) Or IsEmpty(valueIn) Then Exit Function
    If VarType(valueIn) = vbString And Len(Trim$(CStr(valueIn))) = 0 Then Exit Function
    If IsNumeric(valueIn) Then
        TransferAmountSignature = Format$(CDbl(valueIn), "0.00000000")
    Else
        TransferAmountSignature = CellText(valueIn)
    End If
End Function

Private Function TransferSignaturePart(ByVal valueText As String) As String
    TransferSignaturePart = CStr(Len(valueText)) & ":" & valueText & "|"
End Function

Private Sub FillPreparedTx(ByRef data() As Variant, ByVal rowNo As Long, _
                           ByVal bankName As String, ByVal branchName As String, ByVal personName As String, _
                           ByVal relationshipText As String, ByVal accountType As String, ByVal accountNo As String, _
                           ByVal txDate As Variant, ByVal txTime As Variant, ByVal withdrawValue As Variant, _
                           ByVal depositValue As Variant, ByVal shopText As String, ByVal machineText As String, _
                           ByVal tekiyoText As String, ByVal afterBalance As Variant, _
                           ByVal recordType As String, ByVal inputOrder As Long)
    data(rowNo, OUT_COL_BANK) = bankName
    data(rowNo, OUT_COL_BRANCH) = branchName
    data(rowNo, OUT_COL_PERSON) = personName
    data(rowNo, OUT_COL_ACCOUNT_TYPE) = accountType
    data(rowNo, OUT_COL_ACCOUNT_NO) = accountNo
    data(rowNo, OUT_COL_DATE) = txDate
    data(rowNo, OUT_COL_TIME) = txTime
    data(rowNo, OUT_COL_WITHDRAW) = withdrawValue
    data(rowNo, OUT_COL_DEPOSIT) = depositValue
    data(rowNo, OUT_COL_SHOP) = shopText
    data(rowNo, OUT_COL_MACHINE) = machineText
    data(rowNo, OUT_COL_TEKIYO) = tekiyoText
    data(rowNo, OUT_COL_OTHER) = afterBalance
    data(rowNo, WORK_TX_COL_RELATIONSHIP) = relationshipText
    data(rowNo, WORK_TX_COL_RECORD_TYPE) = recordType
    data(rowNo, WORK_TX_COL_INPUT_ORDER) = inputOrder
End Sub

Private Sub FillPreparedBalance(ByRef data() As Variant, ByVal rowNo As Long, _
                                ByVal personName As String, ByVal bankName As String, ByVal branchName As String, _
                                ByVal accountType As String, ByVal accountNo As String, _
                                ByVal openDate As Variant, ByVal closeDate As Variant, ByVal balanceDate As Variant, _
                                ByVal labelText As String, ByVal amountValue As Variant, ByVal memoText As String, _
                                ByVal relationshipText As String)
    data(rowNo, 1) = personName
    data(rowNo, 2) = bankName
    data(rowNo, 3) = branchName
    data(rowNo, 4) = accountType
    data(rowNo, 5) = accountNo
    data(rowNo, 6) = openDate
    data(rowNo, 7) = closeDate
    data(rowNo, 8) = balanceDate
    data(rowNo, 9) = labelText
    data(rowNo, 10) = amountValue
    data(rowNo, 11) = memoText
    data(rowNo, WORK_BAL_COL_RELATIONSHIP) = relationshipText
End Sub

Private Function AppendPreparedTxRows(ByVal ws As Worksheet, ByRef data() As Variant, _
                                      ByVal rowCount As Long, ByRef writeFirstRow As Long) As Long
    Dim firstR As Long, r As Long, c As Long
    Dim writeData() As Variant, expectedStoredData As Variant
    Dim writeRange As Range
    writeFirstRow = 0
    If rowCount = 0 Then Exit Function
    ValidatePreparedTxIdentifiers data, rowCount
    firstR = RequireTransferAppendRow(ws, "W_取引")
    If rowCount > ws.Rows.Count - firstR + 1 Then _
        Err.Raise vbObjectError + 3501, "AppendPreparedTxRows", "取引保管がExcelの行上限を超えます。案件を分割してください。"
    ReDim writeData(1 To rowCount, 1 To WORK_TX_COL_PERSON_ID)
    ReDim expectedStoredData(1 To rowCount, 1 To WORK_TX_COL_PERSON_ID)
    For r = 1 To rowCount
        For c = 1 To WORK_TX_COL_PERSON_ID
            expectedStoredData(r, c) = CanonicalExpectedStoredValue2(data(r, c), "取引", r, c)
            writeData(r, c) = expectedStoredData(r, c)
        Next c
    Next r
    writeFirstRow = firstR
    ws.Range(ws.Cells(firstR, 1), ws.Cells(firstR + rowCount - 1, OUT_COL_ACCOUNT_NO)).NumberFormatLocal = "@"
    ws.Range(ws.Cells(firstR, OUT_COL_SHOP), ws.Cells(firstR + rowCount - 1, OUT_COL_TEKIYO)).NumberFormatLocal = "@"
    ws.Range(ws.Cells(firstR, WORK_TX_COL_RELATIONSHIP), ws.Cells(firstR + rowCount - 1, WORK_TX_COL_PERSON_ID)).NumberFormatLocal = "@"
    Set writeRange = ws.Range(ws.Cells(firstR, 1), _
                              ws.Cells(firstR + rowCount - 1, WORK_TX_COL_PERSON_ID))
    writeRange.Value2 = writeData
    FormatNewWorkTxRows ws, firstR, firstR + rowCount - 1
    If Not RangeValue2MatchesMatrixStrict(writeRange, expectedStoredData, _
                                          rowCount, WORK_TX_COL_PERSON_ID) Then _
        Err.Raise vbObjectError + 3503, "AppendPreparedTxRows", _
                  "取引保管の追記読戻しが全行・全列・型で一致しません。"
    AppendPreparedTxRows = firstR
End Function

Private Function AppendPreparedBalanceRows(ByVal ws As Worksheet, ByRef data() As Variant, _
                                           ByVal rowCount As Long, ByRef writeFirstRow As Long) As Long
    Dim firstR As Long, r As Long, c As Long
    Dim writeData() As Variant, expectedStoredData As Variant
    Dim writeRange As Range
    writeFirstRow = 0
    If rowCount = 0 Then Exit Function
    ValidatePreparedBalanceIdentifiers data, rowCount
    firstR = RequireTransferAppendRow(ws, "W_残高")
    If rowCount > ws.Rows.Count - firstR + 1 Then _
        Err.Raise vbObjectError + 3502, "AppendPreparedBalanceRows", "残高保管がExcelの行上限を超えます。案件を分割してください。"
    ReDim writeData(1 To rowCount, 1 To WORK_BAL_COL_PERSON_ID)
    ReDim expectedStoredData(1 To rowCount, 1 To WORK_BAL_COL_PERSON_ID)
    For r = 1 To rowCount
        For c = 1 To WORK_BAL_COL_PERSON_ID
            expectedStoredData(r, c) = CanonicalExpectedStoredValue2(data(r, c), "残高", r, c)
            writeData(r, c) = expectedStoredData(r, c)
        Next c
    Next r
    writeFirstRow = firstR
    ws.Range(ws.Cells(firstR, 1), ws.Cells(firstR + rowCount - 1, 5)).NumberFormatLocal = "@"
    ws.Range(ws.Cells(firstR, 9), ws.Cells(firstR + rowCount - 1, 9)).NumberFormatLocal = "@"
    ws.Range(ws.Cells(firstR, 11), ws.Cells(firstR + rowCount - 1, WORK_BAL_COL_PERSON_ID)).NumberFormatLocal = "@"
    Set writeRange = ws.Range(ws.Cells(firstR, 1), _
                              ws.Cells(firstR + rowCount - 1, WORK_BAL_COL_PERSON_ID))
    writeRange.Value2 = writeData
    FormatNewWorkBalanceRows ws, firstR, firstR + rowCount - 1
    If Not RangeValue2MatchesMatrixStrict(writeRange, expectedStoredData, _
                                          rowCount, WORK_BAL_COL_PERSON_ID) Then _
        Err.Raise vbObjectError + 3504, "AppendPreparedBalanceRows", _
                  "残高保管の追記読戻しが全行・全列・型で一致しません。"
    AppendPreparedBalanceRows = firstR
End Function

Private Function RequireTransferAppendRow(ByVal ws As Worksheet, _
                                          ByVal storeLabel As String) As Long
    '追記位置のFind失敗を空シートとして扱わず、既存行の上書きを防ぐ。
    Dim lastUsedRow As Long
    If ws Is Nothing Then _
        Err.Raise vbObjectError + 3510, "RequireTransferAppendRow", _
                  storeLabel & "を取得できません。"
    If Not TryGetLastUsedRowInSheet(ws, lastUsedRow) Then _
        Err.Raise vbObjectError + 3511, "RequireTransferAppendRow(" & ws.Name & ")", _
                  storeLabel & "の最終行を安全に確認できないため、登録を中止しました。"
    If lastUsedRow < 1 Then lastUsedRow = 1
    If lastUsedRow >= ws.Rows.Count Then _
        Err.Raise vbObjectError + 3512, "RequireTransferAppendRow(" & ws.Name & ")", _
                  storeLabel & "がExcelの行上限に達しています。"
    RequireTransferAppendRow = lastUsedRow + 1
    If RequireTransferAppendRow < 2 Then RequireTransferAppendRow = 2
End Function

Private Sub ValidatePreparedTxIdentifiers(ByRef data() As Variant, ByVal rowCount As Long)
    Dim r As Long
    For r = 1 To rowCount
        RequirePreparedIdentifier data(r, WORK_TX_COL_TRANSACTION_ID), "取引ID", "取引", r
        RequirePreparedIdentifier data(r, WORK_TX_COL_ACCOUNT_ID), "口座ID", "取引", r
        RequirePreparedIdentifier data(r, WORK_TX_COL_TRANSFER_ID), "転記回ID", "取引", r
        RequirePreparedIdentifier data(r, WORK_TX_COL_SOURCE), "登録元", "取引", r
        RequirePreparedIdentifier data(r, WORK_TX_COL_PERSON_ID), "人物ID", "取引", r
    Next r
End Sub

Private Sub ValidatePreparedBalanceIdentifiers(ByRef data() As Variant, ByVal rowCount As Long)
    Dim r As Long
    For r = 1 To rowCount
        RequirePreparedIdentifier data(r, WORK_BAL_COL_BALANCE_ID), "残高ID", "残高", r
        RequirePreparedIdentifier data(r, WORK_BAL_COL_ACCOUNT_ID), "口座ID", "残高", r
        RequirePreparedIdentifier data(r, WORK_BAL_COL_TRANSFER_ID), "転記回ID", "残高", r
        RequirePreparedIdentifier data(r, WORK_BAL_COL_SOURCE), "登録元", "残高", r
        RequirePreparedIdentifier data(r, WORK_BAL_COL_PERSON_ID), "人物ID", "残高", r
    Next r
End Sub

Private Sub RequirePreparedIdentifier(ByVal valueIn As Variant, ByVal fieldName As String, _
                                      ByVal storeName As String, ByVal rowNo As Long)
    If IsError(valueIn) Then _
        Err.Raise vbObjectError + 3505, "RequirePreparedIdentifier", _
                  storeName & "追記予定" & CStr(rowNo) & "行目の" & fieldName & "がExcelエラー値です。"
    If IsNull(valueIn) Or IsEmpty(valueIn) Then _
        Err.Raise vbObjectError + 3505, "RequirePreparedIdentifier", _
                  storeName & "追記予定" & CStr(rowNo) & "行目の" & fieldName & "が空欄です。"
    If Len(CellText(valueIn)) = 0 Then _
        Err.Raise vbObjectError + 3505, "RequirePreparedIdentifier", _
                  storeName & "追記予定" & CStr(rowNo) & "行目の" & fieldName & "が空欄または不正です。"
End Sub

Private Function CanonicalExpectedStoredValue2(ByVal valueIn As Variant, _
                                               ByVal storeName As String, _
                                               ByVal rowNo As Long, ByVal columnNo As Long) As Variant
    'ExcelセルのValue2では整数・日付・通貨もDoubleになるため、その保存後型へ正規化する。
    If IsError(valueIn) Then _
        Err.Raise vbObjectError + 3506, "CanonicalExpectedStoredValue2", _
                  storeName & "追記予定" & CStr(rowNo) & "行" & CStr(columnNo) & "列にExcelエラー値があります。"
    If IsNull(valueIn) Or IsEmpty(valueIn) Then
        CanonicalExpectedStoredValue2 = Empty
    ElseIf VarType(valueIn) = vbString And Len(CStr(valueIn)) = 0 Then
        CanonicalExpectedStoredValue2 = Empty
    ElseIf storeName = "取引" And columnNo = WORK_TX_COL_INPUT_ORDER Then
        'W_取引のN:Uは文字列書式であり、入力順だけが数値になる。
        'Excel側の書式依存変換を避け、意図的に数値文字列として保存する。
        CanonicalExpectedStoredValue2 = CStr(valueIn)
    ElseIf VarType(valueIn) = vbDate Then
        CanonicalExpectedStoredValue2 = CDbl(valueIn)
    ElseIf VarType(valueIn) <> vbString And VarType(valueIn) <> vbBoolean And IsNumeric(valueIn) Then
        CanonicalExpectedStoredValue2 = CDbl(valueIn)
    Else
        CanonicalExpectedStoredValue2 = valueIn
    End If
End Function

Private Sub FormatNewWorkTxRows(ByVal ws As Worksheet, ByVal firstR As Long, ByVal lastR As Long)
    If firstR = 0 Or lastR < firstR Then Exit Sub
    ws.Range(ws.Cells(firstR, 1), ws.Cells(lastR, OUT_COL_ACCOUNT_NO)).NumberFormatLocal = "@"
    ws.Range(ws.Cells(firstR, OUT_COL_SHOP), ws.Cells(lastR, OUT_COL_TEKIYO)).NumberFormatLocal = "@"
    ws.Range(ws.Cells(firstR, WORK_TX_COL_RELATIONSHIP), ws.Cells(lastR, WORK_TX_COL_PERSON_ID)).NumberFormatLocal = "@"
    ws.Range(ws.Cells(firstR, OUT_COL_DATE), ws.Cells(lastR, OUT_COL_DATE)).NumberFormatLocal = "yyyy/m/d"
    ws.Range(ws.Cells(firstR, OUT_COL_TIME), ws.Cells(lastR, OUT_COL_TIME)).NumberFormatLocal = "hh:mm"
    ws.Range(ws.Cells(firstR, OUT_COL_WITHDRAW), ws.Cells(lastR, OUT_COL_DEPOSIT)).NumberFormatLocal = "#,##0.########"
    ws.Range(ws.Cells(firstR, OUT_COL_OTHER), ws.Cells(lastR, OUT_COL_OTHER)).NumberFormatLocal = "#,##0.########"
End Sub

Private Sub FormatNewWorkBalanceRows(ByVal ws As Worksheet, ByVal firstR As Long, ByVal lastR As Long)
    If firstR = 0 Or lastR < firstR Then Exit Sub
    ws.Range(ws.Cells(firstR, 1), ws.Cells(lastR, 5)).NumberFormatLocal = "@"
    ws.Range(ws.Cells(firstR, 9), ws.Cells(lastR, 9)).NumberFormatLocal = "@"
    ws.Range(ws.Cells(firstR, 11), ws.Cells(lastR, WORK_BAL_COL_PERSON_ID)).NumberFormatLocal = "@"
    ws.Range(ws.Cells(firstR, 6), ws.Cells(lastR, 8)).NumberFormatLocal = "yyyy/m/d"
    ws.Range(ws.Cells(firstR, 10), ws.Cells(lastR, 10)).NumberFormatLocal = "#,##0.########"
End Sub

Private Sub SnapshotAccountRows(ByVal ws As Worksheet, ByVal accountIDCol As Long, ByVal accountID As String, _
                                ByVal lastCol As Long, ByRef snapshot As Variant, ByRef snapshotCount As Long)
    Dim lastR As Long, r As Long, c As Long, outR As Long
    Dim sourceData As Variant
    snapshotCount = 0
    lastR = LastUsedRowInSheet(ws)
    If lastR < 2 Then Exit Sub
    sourceData = ws.Range(ws.Cells(2, 1), ws.Cells(lastR, lastCol)).Value
    For r = 1 To UBound(sourceData, 1)
        If CellText(sourceData(r, accountIDCol)) = accountID Then snapshotCount = snapshotCount + 1
    Next r
    If snapshotCount = 0 Then Exit Sub
    ReDim snapshot(1 To snapshotCount, 1 To lastCol)
    For r = 1 To UBound(sourceData, 1)
        If CellText(sourceData(r, accountIDCol)) = accountID Then
            outR = outR + 1
            For c = 1 To lastCol
                snapshot(outR, c) = sourceData(r, c)
            Next c
        End If
    Next r
End Sub

Private Function RelationshipColumnValue(ByRef sourceData As Variant, ByVal rowIndex As Long, _
                                         ByVal rowCount As Long) As Variant
    If rowCount = 1 Then
        If rowIndex <> 1 Then _
            Err.Raise vbObjectError + 4120, "RelationshipColumnValue", "列配列の行番号が不正です。"
        RelationshipColumnValue = sourceData
    Else
        RelationshipColumnValue = sourceData(rowIndex, 1)
    End If
End Function

Private Sub SnapshotPersonRelationshipState(ByVal ws As Worksheet, ByVal personIDCol As Long, _
                                            ByVal relationshipCol As Long, ByVal stableKeyCol As Long, _
                                            ByVal personID As String, ByRef snapshot As Variant, _
                                            ByRef snapshotCount As Long)
    Dim lastR As Long, rowCount As Long, r As Long, outR As Long
    Dim idData As Variant, keyData As Variant
    Dim stableKey As String
    Dim relationshipCell As Range
    Dim hasFormula As Boolean
    snapshotCount = 0
    If ws Is Nothing Or Len(personID) = 0 Then Exit Sub
    lastR = LastUsedRowInSheet(ws)
    If lastR < 2 Then Exit Sub
    rowCount = lastR - 1
    idData = ws.Range(ws.Cells(2, personIDCol), ws.Cells(lastR, personIDCol)).Value2
    If stableKeyCol > 0 Then _
        keyData = ws.Range(ws.Cells(2, stableKeyCol), ws.Cells(lastR, stableKeyCol)).Value2

    For r = 1 To rowCount
        If StrComp(CellText(RelationshipColumnValue(idData, r, rowCount)), _
                   personID, vbTextCompare) = 0 Then snapshotCount = snapshotCount + 1
    Next r
    If snapshotCount = 0 Then Exit Sub
    ReDim snapshot(1 To snapshotCount, 1 To REL_SNAPSHOT_LAST_COL)
    For r = 1 To rowCount
        If StrComp(CellText(RelationshipColumnValue(idData, r, rowCount)), _
                   personID, vbTextCompare) = 0 Then
            outR = outR + 1
            If stableKeyCol > 0 Then
                stableKey = CellText(RelationshipColumnValue(keyData, r, rowCount))
                If Len(stableKey) = 0 Then _
                    Err.Raise vbObjectError + 4121, "SnapshotPersonRelationshipState", _
                              ws.Name & "の続柄復元キーがありません。"
                snapshot(outR, REL_SNAPSHOT_COL_KEY) = stableKey
            Else
                snapshot(outR, REL_SNAPSHOT_COL_KEY) = r + 1
            End If
            Set relationshipCell = ws.Cells(r + 1, relationshipCol)
            hasFormula = CBool(relationshipCell.HasFormula)
            snapshot(outR, REL_SNAPSHOT_COL_HAS_FORMULA) = hasFormula
            If hasFormula Then
                snapshot(outR, REL_SNAPSHOT_COL_FORMULA) = relationshipCell.Formula
                snapshot(outR, REL_SNAPSHOT_COL_VALUE_TYPE) = VarType(relationshipCell.Formula)
            Else
                snapshot(outR, REL_SNAPSHOT_COL_VALUE2) = relationshipCell.Value2
                snapshot(outR, REL_SNAPSHOT_COL_VALUE_TYPE) = VarType(relationshipCell.Value2)
            End If
            snapshot(outR, REL_SNAPSHOT_COL_PREFIX) = CStr(relationshipCell.PrefixCharacter)
        End If
    Next r
End Sub

Private Function BuildPersonRelationshipRowIndex(ByVal ws As Worksheet, ByVal personIDCol As Long, _
                                                 ByVal stableKeyCol As Long, ByVal personID As String) As Object
    Dim rowsByKey As Object
    Dim lastR As Long, rowCount As Long, r As Long
    Dim idData As Variant, keyData As Variant
    Dim stableKey As String
    Set rowsByKey = CreateObject("Scripting.Dictionary")
    rowsByKey.CompareMode = vbTextCompare
    If ws Is Nothing Or Len(personID) = 0 Then
        Set BuildPersonRelationshipRowIndex = rowsByKey
        Exit Function
    End If
    lastR = LastUsedRowInSheet(ws)
    If lastR < 2 Then
        Set BuildPersonRelationshipRowIndex = rowsByKey
        Exit Function
    End If
    rowCount = lastR - 1
    idData = ws.Range(ws.Cells(2, personIDCol), ws.Cells(lastR, personIDCol)).Value2
    If stableKeyCol > 0 Then _
        keyData = ws.Range(ws.Cells(2, stableKeyCol), ws.Cells(lastR, stableKeyCol)).Value2
    For r = 1 To rowCount
        If StrComp(CellText(RelationshipColumnValue(idData, r, rowCount)), _
                   personID, vbTextCompare) = 0 Then
            If stableKeyCol > 0 Then
                stableKey = CellText(RelationshipColumnValue(keyData, r, rowCount))
                If Len(stableKey) = 0 Then _
                    Err.Raise vbObjectError + 4122, "BuildPersonRelationshipRowIndex", _
                              ws.Name & "の続柄復元キーがありません。"
            Else
                stableKey = CStr(r + 1)
            End If
            If rowsByKey.Exists(stableKey) Then _
                Err.Raise vbObjectError + 4123, "BuildPersonRelationshipRowIndex", _
                          ws.Name & "の続柄復元キーが重複しています: " & stableKey
            rowsByKey.Add stableKey, r + 1
        End If
    Next r
    Set BuildPersonRelationshipRowIndex = rowsByKey
End Function

Private Sub RestorePersonRelationshipState(ByVal ws As Worksheet, ByVal personIDCol As Long, _
                                           ByVal relationshipCol As Long, ByVal stableKeyCol As Long, _
                                           ByVal personID As String, ByRef snapshot As Variant, _
                                           ByVal snapshotCount As Long)
    Dim rowsByKey As Object
    Dim i As Long, stableKey As String, targetRow As Long
    Dim targetCell As Range
    Set rowsByKey = BuildPersonRelationshipRowIndex(ws, personIDCol, stableKeyCol, personID)
    If rowsByKey.Count <> snapshotCount Then _
        Err.Raise vbObjectError + 4124, "RestorePersonRelationshipState", _
                  ws.Name & "の人物続柄行数が退避時と一致しません。"
    If snapshotCount = 0 Then Exit Sub
    If Not IsArray(snapshot) Then _
        Err.Raise vbObjectError + 4125, "RestorePersonRelationshipState", _
                  ws.Name & "の人物続柄退避値がありません。"
    If UBound(snapshot, 2) < REL_SNAPSHOT_LAST_COL Then _
        Err.Raise vbObjectError + 4127, "RestorePersonRelationshipState", _
                  ws.Name & "の人物続柄退避値が不足しています。"
    For i = 1 To snapshotCount
        stableKey = CellText(snapshot(i, REL_SNAPSHOT_COL_KEY))
        If Not rowsByKey.Exists(stableKey) Then _
            Err.Raise vbObjectError + 4126, "RestorePersonRelationshipState", _
                      ws.Name & "の続柄復元対象が見つかりません: " & stableKey
        targetRow = CLng(rowsByKey(stableKey))
        Set targetCell = ws.Cells(targetRow, relationshipCol)
        RestoreRelationshipSnapshotCell targetCell, snapshot, i
        If Not RelationshipCellMatchesSnapshot(targetCell, snapshot, i) Then _
            Err.Raise vbObjectError + 4128, "RestorePersonRelationshipState", _
                      ws.Name & "の続柄復元値が退避時と一致しません: " & stableKey
    Next i
End Sub

Private Sub RestoreRelationshipSnapshotCell(ByVal targetCell As Range, _
                                            ByRef snapshot As Variant, ByVal snapshotRow As Long)
    Dim prefixText As String
    Dim constantValue As Variant
    If targetCell Is Nothing Then _
        Err.Raise vbObjectError + 4129, "RestoreRelationshipSnapshotCell", _
                  "続柄復元セルがありません。"
    prefixText = CStr(snapshot(snapshotRow, REL_SNAPSHOT_COL_PREFIX))
    If CBool(snapshot(snapshotRow, REL_SNAPSHOT_COL_HAS_FORMULA)) Then
        targetCell.Formula = snapshot(snapshotRow, REL_SNAPSHOT_COL_FORMULA)
    Else
        constantValue = snapshot(snapshotRow, REL_SNAPSHOT_COL_VALUE2)
        If Len(prefixText) > 0 And VarType(constantValue) = vbString Then
            '先頭アポストロフ等を値に混ぜず、復元後のPrefixCharacterも照合する。
            targetCell.Formula = prefixText & CStr(constantValue)
        Else
            targetCell.Value2 = constantValue
        End If
    End If
End Sub

Private Function RelationshipVariantMatches(ByVal currentValue As Variant, _
                                            ByVal snapshotValue As Variant, _
                                            ByVal expectedVarType As VbVarType) As Boolean
    Dim currentErrorType As Long, snapshotErrorType As Long
    If VarType(currentValue) <> expectedVarType Or _
       VarType(snapshotValue) <> expectedVarType Then Exit Function
    If IsError(currentValue) Or IsError(snapshotValue) Then
        If Not IsError(currentValue) Or Not IsError(snapshotValue) Then Exit Function
        On Error GoTo NoMatch
        currentErrorType = CLng(Application.WorksheetFunction.Error_Type(currentValue))
        snapshotErrorType = CLng(Application.WorksheetFunction.Error_Type(snapshotValue))
        RelationshipVariantMatches = (currentErrorType = snapshotErrorType)
    ElseIf IsNull(currentValue) Or IsNull(snapshotValue) Then
        RelationshipVariantMatches = (IsNull(currentValue) And IsNull(snapshotValue))
    ElseIf IsEmpty(currentValue) Or IsEmpty(snapshotValue) Then
        RelationshipVariantMatches = (IsEmpty(currentValue) And IsEmpty(snapshotValue))
    ElseIf expectedVarType = vbString Then
        RelationshipVariantMatches = _
            (StrComp(CStr(currentValue), CStr(snapshotValue), vbBinaryCompare) = 0)
    Else
        RelationshipVariantMatches = CBool(currentValue = snapshotValue)
    End If
    Exit Function
NoMatch:
    RelationshipVariantMatches = False
    Err.Clear
End Function

Private Function RelationshipCellMatchesSnapshot(ByVal targetCell As Range, _
                                                  ByRef snapshot As Variant, _
                                                  ByVal snapshotRow As Long) As Boolean
    Dim expectedHasFormula As Boolean
    Dim expectedValueType As VbVarType
    Dim currentPrefix As String, expectedPrefix As String
    Dim currentValue As Variant, expectedValue As Variant
    If targetCell Is Nothing Then Exit Function
    On Error GoTo NoMatch
    expectedHasFormula = CBool(snapshot(snapshotRow, REL_SNAPSHOT_COL_HAS_FORMULA))
    If CBool(targetCell.HasFormula) <> expectedHasFormula Then Exit Function
    currentPrefix = CStr(targetCell.PrefixCharacter)
    expectedPrefix = CStr(snapshot(snapshotRow, REL_SNAPSHOT_COL_PREFIX))
    If StrComp(currentPrefix, expectedPrefix, vbBinaryCompare) <> 0 Then Exit Function
    expectedValueType = CLng(snapshot(snapshotRow, REL_SNAPSHOT_COL_VALUE_TYPE))
    If expectedHasFormula Then
        currentValue = targetCell.Formula
        expectedValue = snapshot(snapshotRow, REL_SNAPSHOT_COL_FORMULA)
    Else
        currentValue = targetCell.Value2
        expectedValue = snapshot(snapshotRow, REL_SNAPSHOT_COL_VALUE2)
    End If
    RelationshipCellMatchesSnapshot = _
        RelationshipVariantMatches(currentValue, expectedValue, expectedValueType)
    Exit Function
NoMatch:
    RelationshipCellMatchesSnapshot = False
    Err.Clear
End Function

Private Function PersonRelationshipStateMatches(ByVal ws As Worksheet, ByVal personIDCol As Long, _
                                                ByVal relationshipCol As Long, ByVal stableKeyCol As Long, _
                                                ByVal personID As String, ByRef snapshot As Variant, _
                                                ByVal snapshotCount As Long) As Boolean
    Dim rowsByKey As Object
    Dim i As Long, stableKey As String, targetRow As Long
    Set rowsByKey = BuildPersonRelationshipRowIndex(ws, personIDCol, stableKeyCol, personID)
    If rowsByKey.Count <> snapshotCount Then Exit Function
    If snapshotCount = 0 Then
        PersonRelationshipStateMatches = True
        Exit Function
    End If
    If Not IsArray(snapshot) Then Exit Function
    If UBound(snapshot, 2) < REL_SNAPSHOT_LAST_COL Then Exit Function
    For i = 1 To snapshotCount
        stableKey = CellText(snapshot(i, REL_SNAPSHOT_COL_KEY))
        If Not rowsByKey.Exists(stableKey) Then Exit Function
        targetRow = CLng(rowsByKey(stableKey))
        If Not RelationshipCellMatchesSnapshot(ws.Cells(targetRow, relationshipCol), _
                                               snapshot, i) Then Exit Function
    Next i
    PersonRelationshipStateMatches = True
End Function

Private Sub DeleteOldRowsExceptTransfer(ByVal ws As Worksheet, ByVal accountIDCol As Long, _
                                        ByVal transferIDCol As Long, ByVal accountID As String, ByVal keepTransferID As String)
    Dim lastCol As Long
    If ws Is Nothing Then Exit Sub
    If ws.Name = SH_WORK_TX Then
        lastCol = WORK_TX_COL_PERSON_ID
    ElseIf ws.Name = SH_WORK_BAL Then
        lastCol = WORK_BAL_COL_PERSON_ID
    Else
        Err.Raise vbObjectError + 4114, "DeleteOldRowsExceptTransfer", "対象外の内部シートです: " & ws.Name
    End If
    CompactDeleteDataRows ws, lastCol, accountIDCol, accountID, transferIDCol, keepTransferID, False
End Sub


Private Sub AppendTransferDetail(ByRef detailText As String, ByVal newDetail As String)
    newDetail = Trim$(newDetail)
    If Len(newDetail) = 0 Then Exit Sub
    If Len(detailText) > 0 Then detailText = detailText & " / "
    detailText = detailText & newDetail
End Sub


'旧版で他モジュールから呼ばれる可能性があるため、互換用に残す。
Public Sub FormatWorkTx()
    Dim ws As Worksheet
    Set ws = GetSheet(SH_WORK_TX)
    FormatNewWorkTxRows ws, 2, LastUsedRowInSheet(ws)
End Sub

Public Sub FormatWorkBal()
    Dim ws As Worksheet
    Set ws = GetSheet(SH_WORK_BAL)
    FormatNewWorkBalanceRows ws, 2, LastUsedRowInSheet(ws)
End Sub

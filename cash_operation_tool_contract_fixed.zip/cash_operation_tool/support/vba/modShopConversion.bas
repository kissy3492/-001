﻿Attribute VB_Name = "modShopConversion"
Option Explicit

Private Const SHOP_OUTPUT_SNAPSHOT_LAST_COL As Long = 21
Private Const SHOP_RECOVERY_HARD_BARRIER_ERROR As Long = vbObjectError + 4499
Private Const SHOP_RECOVERY_FATAL_PREFIX As String = "ShopRecoveryFatal/"
Private mShopRollbackRecoveryRequired As Boolean

Public Sub BuildShopConversionTargetSheet()
    '資金操作表に登場した「コード形式の取扱店」だけを一覧化する。
    '変換作業そのものはこのシート上で行い、反映ボタンも同じシートに置く。
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim restoreDetail As String
    Dim outputsWereDirty As Boolean
    Dim appBeginSucceeded As Boolean, applicationLeaseStarted As Boolean
    Dim entryEvents As Boolean, entryEventsCaptured As Boolean
    Dim entryEventsRestored As Boolean, operationSucceeded As Boolean
    Dim recoveryStateConfirmed As Boolean, applicationStateSafe As Boolean
    Dim recoveryAttempted As Boolean, recoveryTerminalFailure As Boolean
    Dim eventStateDetail As String
    Dim applicationStateDetail As String
    Dim confirmedAnalysisWorkloadRows As Double
    Dim structureProblems As String
    On Error GoTo EH
    mShopRollbackRecoveryRequired = False
    'このPublic入口がExcelイベントのleaseを所有する。容量確認や状態表示より前に
    '開始値を捕捉してFalseをexact確定し、早期終了もCLEAN_EXITで同じ値へ戻す。
    If Not TryGetShopEnableEvents(entryEvents, eventStateDetail) Then _
        Err.Raise vbObjectError + 4330, "BuildShopConversionTargetSheet", _
                  "Excelイベントの開始状態を取得できません。 " & eventStateDetail
    entryEventsCaptured = True
    If Not TryKeepShopEventsDisabledExact(eventStateDetail) Then _
        Err.Raise vbObjectError + 4336, "BuildShopConversionTargetSheet", _
                  "Excelイベントを安全に停止できないため、取扱店変換対象の更新を開始していません。 " & _
                  eventStateDetail

    If Not RequireCashAnalysisManualModeFinished("取扱店変換対象の更新") Then GoTo CLEAN_EXIT
    If HasSelectedAnalysisDetailTransactions() Then
        MsgBox "候補詳細に、手動候補として未登録の選択取引があります。" & vbCrLf & _
               "取扱店変換対象の更新前に、候補を登録するか選択を解除してください。" & vbCrLf & _
               "選択内容を黙って破棄することはありません。", _
               vbInformation, "手動候補の選択を完了してください"
        GoTo CLEAN_EXIT
    End If
    If Not RequireToolReady() Then GoTo CLEAN_EXIT
    outputsWereDirty = OutputsAreDirty()
    If Not RequireOutputBuildCapacity("取扱店変換対象の更新", True, _
                                      outputsWereDirty, outputsWereDirty, _
                                      outputsWereDirty, True, False) Then
        If Not TryKeepShopEventsDisabledExact(eventStateDetail) Then _
            Err.Raise vbObjectError + 4336, "BuildShopConversionTargetSheet", _
                      "中止状態の記録前にExcelイベント停止を確認できません。 " & _
                      eventStateDetail
        SetInputStatus "取扱店変換対象の更新を開始せず中止しました。内部データと既存帳票は変更していません。"
        GoTo CLEAN_EXIT
    End If
    If Not ConfirmAnalysisReviewOperationCapacity( _
            "取扱店変換対象の更新", confirmedAnalysisWorkloadRows) Then
        If Not TryKeepShopEventsDisabledExact(eventStateDetail) Then _
            Err.Raise vbObjectError + 4336, "BuildShopConversionTargetSheet", _
                      "中止状態の記録前にExcelイベント停止を確認できません。 " & _
                      eventStateDetail
        SetInputStatus "取扱店変換対象の更新を開始せず中止しました。内部データと既存帳票は変更していません。"
        GoTo CLEAN_EXIT
    End If
    If Not RequireNoPendingAccountInput("取扱店変換対象の更新") Then GoTo CLEAN_EXIT
    If Not RequireInternalStoresSafeForWrite(False, False) Then GoTo CLEAN_EXIT
    If Not EnsureCaseReadyForOutputs(True) Then GoTo CLEAN_EXIT
    AppBegin "取扱店変換対象を整理中..."
    appBeginSucceeded = True
    applicationLeaseStarted = True
    '部分帳票更新でMarkOutputsCleanが分析dirtyも落とす前に、現在の判断と履歴を台帳へ確定する。
    If Not ActiveSheet Is Nothing Then
        If ActiveSheet.Name = SH_OUTPUT_TX Then _
            SyncCashAnalysisPanelReviewToWorkspace
    End If
    CommitPendingAnalysisReviews False, "取扱店変換対象更新前の分析判断を保存"
    MarkOutputsDirty
    '更新フラグが正常でも、派生帳票の直接編集を信用せず内部保管から毎回再生成する。
    '既にdirtyなら原因を取扱店編集だけと決め付けず、全依存帳票を同じ工程で再構築する。
    BuildCashOperationSheetCore False, True
    If outputsWereDirty Then
        BuildBalanceTransitionSheetCore False, True
        BuildBalanceReconciliationCore False, True
    End If
    BuildShopConversionTargetSheetCore True, True
    '一覧を更新しただけで前回の変換済み表を空のまま「最新」にしない。
    '既存の確認結果を引き継いだ一覧から、必ず提出候補も同じ工程内で再作成する。
    ApplyShopConversionCore False, False, True
    If outputsWereDirty Then
        BuildTransactionAnalysisSheetsCore False, True, _
                                           confirmedAnalysisWorkloadRows, False
        BuildCashAnalysisViewCore False, False, True
    Else
        BuildCashAnalysisViewCore False, True, True
    End If
    If Not ValidateAuthoritativeDataStructure(structureProblems, True, False) Then _
        Err.Raise vbObjectError + 5601, "BuildShopConversionTargetSheet", _
                  "取扱店一覧更新後の中核データ構造が不正です: " & _
                  Left$(Replace(structureProblems, vbCrLf, " / "), 3000)
    MarkOutputsClean
    operationSucceeded = True

CLEAN_EXIT:
    If applicationLeaseStarted Then
        AppEnd
        applicationLeaseStarted = False
    End If
    applicationStateSafe = True
    If entryEvents Then _
        applicationStateSafe = _
            TryGetShopApplicationStateSafe(applicationStateDetail)
    entryEventsRestored = TryRestoreShopEntryEvents( _
                              entryEvents, applicationStateSafe, _
                              "取扱店変換対象更新の終了時", _
                              recoveryStateConfirmed, recoveryAttempted, _
                              recoveryTerminalFailure, eventStateDetail)
    If recoveryAttempted Or recoveryTerminalFailure Then _
        Err.Raise SHOP_RECOVERY_HARD_BARRIER_ERROR, _
                  SHOP_RECOVERY_FATAL_PREFIX & _
                      "BuildShopConversionTargetSheet", _
                  "終了時Recovery terminal: " & eventStateDetail
    If Not entryEventsRestored Then _
        Err.Raise vbObjectError + 4338, "BuildShopConversionTargetSheet", _
                  eventStateDetail
    mShopRollbackRecoveryRequired = False
    If operationSucceeded Then _
        MsgBox "取扱店変換対象を作成しました。" & vbCrLf & _
               "変換後取扱店を入力したら、このシート右上の『入力内容を反映』を押してください。", vbInformation
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    If IsShopNestedRecoveryHardBarrier( _
           errorNumber, errorSource, errorDescription) Then
        Call TryKeepShopEventsDisabledExact(eventStateDetail)
        On Error GoTo 0
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    FinalizeShopTopLevelFailure "取扱店変換対象の作成", _
        errorNumber, errorDescription, errorSource, appBeginSucceeded, _
        applicationLeaseStarted, entryEventsCaptured, entryEvents, _
        recoveryStateConfirmed, recoveryAttempted, _
        recoveryTerminalFailure, restoreDetail
    If recoveryAttempted Or recoveryTerminalFailure Then
        If Not TryKeepShopEventsDisabledExact(eventStateDetail) Then _
            AppendShopRollbackDetail restoreDetail, _
                "Shop Recovery terminal後のFalse収束を確認できません: " & _
                eventStateDetail
        On Error GoTo 0
        Err.Raise SHOP_RECOVERY_HARD_BARRIER_ERROR, _
                  SHOP_RECOVERY_FATAL_PREFIX & _
                      "BuildShopConversionTargetSheet", _
                  errorDescription & restoreDetail
    End If
    MsgBox "取扱店変換対象の作成中にエラーが発生しました。" & vbCrLf & _
           "Err " & errorNumber & ": " & errorDescription & restoreDetail, vbExclamation
End Sub

Public Sub BuildShopConversionTargetSheetCore( _
        Optional ByVal activateAfter As Boolean = False, _
        Optional ByVal capacityConfirmed As Boolean = False)
    Dim wsOut As Worksheet, wsTarget As Worksheet
    Dim lastR As Long, r As Long, targetR As Long, targetCount As Long, oldLastR As Long, c As Long
    Dim bankName As String, shopText As String, codeText As String, recordType As String, tekiyoText As String
    Dim oldData As Variant, preservedResult As String, preservedStatus As String
    Dim sourceData As Variant, targetData() As Variant, writeData() As Variant
    Dim targetByKey As Object, oldResultByKey As Object, oldStatusByKey As Object
    Dim lookupKey As String, restoreDetail As String
    Dim isTransaction As Boolean, createdAt As Date, resetStarted As Boolean
    Dim targetPreviouslyExisted As Boolean, oldSnapshotLastRow As Long
    Dim originalVisibility As XlSheetVisibility
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim barrierEventDetail As String

    On Error GoTo EH
    If Not capacityConfirmed Then
        If Not RequireOutputBuildCapacity("取扱店変換対象の更新", False, False, _
                                          False, False, True, False) Then Err.Raise 18
    End If
    If Not SheetExists(SH_WORK_CASH) Then Exit Sub
    Set wsOut = GetSheet(SH_WORK_CASH)
    targetPreviouslyExisted = SheetExists(SH_SHOP_TARGET)
    Set wsTarget = GetOrCreateSheet(SH_SHOP_TARGET, False)
    originalVisibility = wsTarget.Visible

    '再生成しても、既に入力した「変換後取扱店」「確認状況」は銀行名+コード単位で引き継ぐ。
    oldLastR = LastRow(wsTarget, SHOP_TGT_COL_CODE)
    ValidateShopTargetStoredCells wsTarget, oldLastR
    oldSnapshotLastRow = LastDataRowInColumns(wsTarget, 1, SHOP_TGT_LAST_COL)
    If oldSnapshotLastRow < 2 Then oldSnapshotLastRow = 2
    oldData = wsTarget.Range(wsTarget.Cells(1, 1), _
                             wsTarget.Cells(oldSnapshotLastRow, SHOP_TGT_LAST_COL)).Value2
    Set targetByKey = CreateObject("Scripting.Dictionary")
    Set oldResultByKey = CreateObject("Scripting.Dictionary")
    Set oldStatusByKey = CreateObject("Scripting.Dictionary")
    targetByKey.CompareMode = vbTextCompare
    oldResultByKey.CompareMode = vbTextCompare
    oldStatusByKey.CompareMode = vbTextCompare
    LoadPreservedShopValues oldData, oldResultByKey, oldStatusByKey

    lastR = LastRow(wsOut, OUT_COL_BANK)
    createdAt = Now

    If lastR >= 2 Then
        sourceData = wsOut.Range(wsOut.Cells(2, 1), wsOut.Cells(lastR, OUT_COL_INPUT_ORDER)).Value2
        ReDim targetData(1 To UBound(sourceData, 1), 1 To SHOP_TGT_LAST_COL)
        For r = 1 To UBound(sourceData, 1)
        bankName = CellText(sourceData(r, OUT_COL_BANK))
        recordType = CellText(sourceData(r, OUT_COL_RECORD_TYPE))
        tekiyoText = CellText(sourceData(r, OUT_COL_TEKIYO))
        isTransaction = False
        If Len(bankName) > 0 Then
            If recordType = RECORD_TRANSACTION Then
                isTransaction = True
            ElseIf Not IsSpecialCashOperationRow(tekiyoText) Then
                If Len(CellText(sourceData(r, OUT_COL_DATE))) > 0 Then isTransaction = True
            End If
        End If
        If isTransaction Then
            shopText = CellText(sourceData(r, OUT_COL_SHOP))
            If IsCodeLikeShop(shopText) Then
                codeText = NormalizeShopCodeText(shopText)
                lookupKey = ShopConversionKey(bankName, codeText)
                If targetByKey.Exists(lookupKey) Then targetR = CLng(targetByKey(lookupKey)) Else targetR = 0

                If targetR = 0 Then
                    targetCount = targetCount + 1
                    If targetCount > wsTarget.Rows.Count - 1 Then _
                        Err.Raise vbObjectError + 4302, "BuildShopConversionTargetSheetCore", _
                                  "取扱店変換対象がExcelの行上限を超えます。案件を分割してください。"
                    targetR = targetCount

                    targetData(targetR, SHOP_TGT_COL_NO) = targetCount
                    targetData(targetR, SHOP_TGT_COL_BANK) = bankName
                    targetData(targetR, SHOP_TGT_COL_CODE) = codeText
                    targetData(targetR, SHOP_TGT_COL_COUNT) = 1
                    targetData(targetR, SHOP_TGT_COL_ROWS) = CStr(r + 1)
                    targetByKey.Add lookupKey, targetR

                    preservedResult = "": preservedStatus = ""
                    If oldResultByKey.Exists(lookupKey) Then preservedResult = CStr(oldResultByKey(lookupKey))
                    If oldStatusByKey.Exists(lookupKey) Then preservedStatus = CStr(oldStatusByKey(lookupKey))
                    targetData(targetR, SHOP_TGT_COL_RESULT) = preservedResult
                    If Len(preservedStatus) > 0 Then
                        targetData(targetR, SHOP_TGT_COL_STATUS) = preservedStatus
                    ElseIf Len(preservedResult) > 0 Then
                        targetData(targetR, SHOP_TGT_COL_STATUS) = "入力済"
                    Else
                        targetData(targetR, SHOP_TGT_COL_STATUS) = "未入力"
                    End If
                    targetData(targetR, SHOP_TGT_COL_CREATED) = createdAt
                Else
                    targetData(targetR, SHOP_TGT_COL_COUNT) = CLng(targetData(targetR, SHOP_TGT_COL_COUNT)) + 1
                    targetData(targetR, SHOP_TGT_COL_ROWS) = AppendRowNumber( _
                        CellText(targetData(targetR, SHOP_TGT_COL_ROWS)), r + 1)
                End If
            End If
        End If
        Next r
    End If

    'ここまで既存一覧には触れない。新一覧をメモリ上で作り切ってから置き換える。
    resetStarted = True
    SetupShopConversionTargetSheet wsTarget
    If targetCount > 0 Then
        ReDim writeData(1 To targetCount, 1 To SHOP_TGT_LAST_COL)
        For r = 1 To targetCount
            For c = 1 To SHOP_TGT_LAST_COL
                writeData(r, c) = targetData(r, c)
            Next c
        Next r
        wsTarget.Range(wsTarget.Cells(2, SHOP_TGT_COL_BANK), _
                       wsTarget.Cells(targetCount + 1, SHOP_TGT_COL_CODE)).NumberFormatLocal = "@"
        wsTarget.Range(wsTarget.Cells(2, SHOP_TGT_COL_ROWS), _
                       wsTarget.Cells(targetCount + 1, SHOP_TGT_COL_STATUS)).NumberFormatLocal = "@"
        wsTarget.Range(wsTarget.Cells(2, 1), _
                       wsTarget.Cells(targetCount + 1, SHOP_TGT_LAST_COL)).Value2 = writeData
        VerifyGeneratedRangeValue2 wsTarget, writeData, 2, 1, targetCount, _
                                   SHOP_TGT_LAST_COL, "取扱店変換対象", False
    End If

    FormatShopConversionTargetSheet wsTarget
    wsTarget.Visible = xlSheetVisible
    If activateAfter Then
        wsTarget.Activate
        wsTarget.Range("A1").Select
    End If
    Exit Sub

EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    If IsShopNestedRecoveryHardBarrier( _
           errorNumber, errorSource, errorDescription) Then
        Call TryKeepShopEventsDisabledExact(barrierEventDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    restoreDetail = RestoreShopTargetAfterFailure(wsTarget, oldData, _
                                                   targetPreviouslyExisted, _
                                                   resetStarted, originalVisibility)
    If Len(restoreDetail) > 0 Then _
        mShopRollbackRecoveryRequired = True
    Err.Raise errorNumber, "BuildShopConversionTargetSheetCore", errorDescription & restoreDetail
End Sub

Private Function RestoreShopTargetAfterFailure(ByVal ws As Worksheet, ByRef oldData As Variant, _
                                               ByVal targetPreviouslyExisted As Boolean, _
                                               ByVal resetStarted As Boolean, _
                                               ByVal originalVisibility As XlSheetVisibility) As String
    Dim snapshotRows As Long, snapshotColumns As Long
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim barrierEventDetail As String
    On Error GoTo EH
    If ws Is Nothing Then Exit Function

    If resetStarted And targetPreviouslyExisted And IsArray(oldData) Then
        snapshotRows = UBound(oldData, 1) - LBound(oldData, 1) + 1
        snapshotColumns = UBound(oldData, 2) - LBound(oldData, 2) + 1
        SetupShopConversionTargetSheet ws
        ws.Range(ws.Cells(1, SHOP_TGT_COL_BANK), _
                 ws.Cells(snapshotRows, SHOP_TGT_COL_CODE)).NumberFormatLocal = "@"
        ws.Range(ws.Cells(1, SHOP_TGT_COL_ROWS), _
                 ws.Cells(snapshotRows, SHOP_TGT_COL_STATUS)).NumberFormatLocal = "@"
        ws.Range(ws.Cells(1, 1), _
                 ws.Cells(snapshotRows, snapshotColumns)).Value2 = oldData
        VerifyGeneratedRangeValue2 ws, oldData, 1, 1, snapshotRows, _
                                   snapshotColumns, "旧取扱店変換対象の復元", False
        FormatShopConversionTargetSheet ws
        ws.Visible = originalVisibility
    Else
        EmergencyProtectToolSheet ws
        If targetPreviouslyExisted Then
            ws.Visible = originalVisibility
        Else
            SetSheetVeryHiddenSafe ws
        End If
    End If
    Exit Function
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    If IsShopNestedRecoveryHardBarrier( _
           errorNumber, errorSource, errorDescription) Then
        Call TryKeepShopEventsDisabledExact(barrierEventDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    On Error Resume Next
    EmergencyProtectToolSheet ws
    SetSheetVeryHiddenSafe ws
    On Error GoTo 0
    RestoreShopTargetAfterFailure = " / 旧変換一覧の復元エラー: Err " & _
                                    CStr(errorNumber) & ": " & errorDescription
End Function

Public Sub ApplyShopConversionToCashOperation()
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim restoreDetail As String
    Dim outputsWereDirty As Boolean
    Dim appBeginSucceeded As Boolean, applicationLeaseStarted As Boolean
    Dim entryEvents As Boolean, entryEventsCaptured As Boolean
    Dim entryEventsRestored As Boolean, operationSucceeded As Boolean
    Dim recoveryStateConfirmed As Boolean, applicationStateSafe As Boolean
    Dim recoveryAttempted As Boolean, recoveryTerminalFailure As Boolean
    Dim eventStateDetail As String
    Dim applicationStateDetail As String
    Dim confirmedAnalysisWorkloadRows As Double
    Dim structureProblems As String
    On Error GoTo EH
    mShopRollbackRecoveryRequired = False
    '容量判定・状態表示を含む全工程を、この入口が所有するevent lease内で行う。
    If Not TryGetShopEnableEvents(entryEvents, eventStateDetail) Then _
        Err.Raise vbObjectError + 4331, "ApplyShopConversionToCashOperation", _
                  "Excelイベントの開始状態を取得できません。 " & eventStateDetail
    entryEventsCaptured = True
    If Not TryKeepShopEventsDisabledExact(eventStateDetail) Then _
        Err.Raise vbObjectError + 4337, "ApplyShopConversionToCashOperation", _
                  "Excelイベントを安全に停止できないため、取扱店変換の反映を開始していません。 " & _
                  eventStateDetail

    If Not RequireCashAnalysisManualModeFinished("取扱店変換の反映") Then GoTo CLEAN_EXIT
    If HasSelectedAnalysisDetailTransactions() Then
        MsgBox "候補詳細に、手動候補として未登録の選択取引があります。" & vbCrLf & _
               "取扱店変換の反映前に、候補を登録するか選択を解除してください。" & vbCrLf & _
               "選択内容を黙って破棄することはありません。", _
               vbInformation, "手動候補の選択を完了してください"
        GoTo CLEAN_EXIT
    End If
    If Not RequireToolReady() Then GoTo CLEAN_EXIT
    outputsWereDirty = OutputsAreDirty()
    If Not RequireOutputBuildCapacity("取扱店変換の反映", True, _
                                      outputsWereDirty, outputsWereDirty, _
                                      outputsWereDirty, True, False) Then
        If Not TryKeepShopEventsDisabledExact(eventStateDetail) Then _
            Err.Raise vbObjectError + 4337, "ApplyShopConversionToCashOperation", _
                      "中止状態の記録前にExcelイベント停止を確認できません。 " & _
                      eventStateDetail
        SetInputStatus "取扱店変換の反映を開始せず中止しました。内部データと既存帳票は変更していません。"
        GoTo CLEAN_EXIT
    End If
    If Not ConfirmAnalysisReviewOperationCapacity( _
            "取扱店変換の反映", confirmedAnalysisWorkloadRows) Then
        If Not TryKeepShopEventsDisabledExact(eventStateDetail) Then _
            Err.Raise vbObjectError + 4337, "ApplyShopConversionToCashOperation", _
                      "中止状態の記録前にExcelイベント停止を確認できません。 " & _
                      eventStateDetail
        SetInputStatus "取扱店変換の反映を開始せず中止しました。内部データと既存帳票は変更していません。"
        GoTo CLEAN_EXIT
    End If
    If Not RequireNoPendingAccountInput("取扱店変換の反映") Then GoTo CLEAN_EXIT
    If Not RequireInternalStoresSafeForWrite(False, False) Then GoTo CLEAN_EXIT
    If Not EnsureCaseReadyForOutputs(True) Then GoTo CLEAN_EXIT
    AppBegin "取扱店を反映中..."
    appBeginSucceeded = True
    applicationLeaseStarted = True
    '変換済み帳票だけを更新しても、分析判断の監査台帳・履歴を未保存のままclean化しない。
    If Not ActiveSheet Is Nothing Then
        If ActiveSheet.Name = SH_OUTPUT_TX Then _
            SyncCashAnalysisPanelReviewToWorkspace
    End If
    CommitPendingAnalysisReviews False, "取扱店変換反映前の分析判断を保存"
    MarkOutputsDirty
    '反映元は派生帳票の現在値ではなく、内部保管から再生成した値に固定する。
    '既にdirtyなら原因を取扱店編集だけと決め付けず、全依存帳票を同じ工程で再構築する。
    BuildCashOperationSheetCore False, True
    If outputsWereDirty Then
        BuildBalanceTransitionSheetCore False, True
        BuildBalanceReconciliationCore False, True
    End If
    '反映直前には毎回、既存入力を引き継いで対象一覧を再集計する。
    '更新フラグだけに依存せず、基礎表の手動変更や古い一覧によるコード漏れも防ぐ。
    BuildShopConversionTargetSheetCore False, True
    ApplyShopConversionCore True, True, True
    If outputsWereDirty Then
        BuildTransactionAnalysisSheetsCore False, True, _
                                           confirmedAnalysisWorkloadRows, False
        BuildCashAnalysisViewCore False, False, True
    Else
        BuildCashAnalysisViewCore False, True, True
    End If
    If Not ValidateAuthoritativeDataStructure(structureProblems, True, False) Then _
        Err.Raise vbObjectError + 5602, "ApplyShopConversionToCashOperation", _
                  "取扱店反映後の中核データ構造が不正です: " & _
                  Left$(Replace(structureProblems, vbCrLf, " / "), 3000)
    MarkOutputsClean
    operationSucceeded = True

CLEAN_EXIT:
    If applicationLeaseStarted Then
        AppEnd
        applicationLeaseStarted = False
    End If
    applicationStateSafe = True
    If entryEvents Then _
        applicationStateSafe = _
            TryGetShopApplicationStateSafe(applicationStateDetail)
    entryEventsRestored = TryRestoreShopEntryEvents( _
                              entryEvents, applicationStateSafe, _
                              "取扱店変換反映の終了時", _
                              recoveryStateConfirmed, recoveryAttempted, _
                              recoveryTerminalFailure, eventStateDetail)
    If recoveryAttempted Or recoveryTerminalFailure Then _
        Err.Raise SHOP_RECOVERY_HARD_BARRIER_ERROR, _
                  SHOP_RECOVERY_FATAL_PREFIX & _
                      "ApplyShopConversionToCashOperation", _
                  "終了時Recovery terminal: " & eventStateDetail
    If Not entryEventsRestored Then _
        Err.Raise vbObjectError + 4339, "ApplyShopConversionToCashOperation", _
                  eventStateDetail
    mShopRollbackRecoveryRequired = False
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    If IsShopNestedRecoveryHardBarrier( _
           errorNumber, errorSource, errorDescription) Then
        Call TryKeepShopEventsDisabledExact(eventStateDetail)
        On Error GoTo 0
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    FinalizeShopTopLevelFailure "取扱店変換の反映", _
        errorNumber, errorDescription, errorSource, appBeginSucceeded, _
        applicationLeaseStarted, entryEventsCaptured, entryEvents, _
        recoveryStateConfirmed, recoveryAttempted, _
        recoveryTerminalFailure, restoreDetail
    If recoveryAttempted Or recoveryTerminalFailure Then
        If Not TryKeepShopEventsDisabledExact(eventStateDetail) Then _
            AppendShopRollbackDetail restoreDetail, _
                "Shop Recovery terminal後のFalse収束を確認できません: " & _
                eventStateDetail
        On Error GoTo 0
        Err.Raise SHOP_RECOVERY_HARD_BARRIER_ERROR, _
                  SHOP_RECOVERY_FATAL_PREFIX & _
                      "ApplyShopConversionToCashOperation", _
                  errorDescription & restoreDetail
    End If
    MsgBox "取扱店反映中にエラーが発生しました。" & vbCrLf & _
           "Err " & errorNumber & ": " & errorDescription & restoreDetail, vbExclamation
End Sub

Public Sub ApplyShopConversionCore(ByVal activateAfter As Boolean, _
                                   Optional ByVal showDoneMessage As Boolean = True, _
                                   Optional ByVal capacityConfirmed As Boolean = False)
    Dim wsSrc As Worksheet, wsTarget As Worksheet, wsDest As Worksheet
    Dim lastR As Long, r As Long, dataCount As Long
    Dim bankName As String, shopText As String, codeText As String, resultName As String
    Dim recordType As String, tekiyoText As String
    Dim convertedCount As Long, remainedCount As Long
    Dim conversionMap As Object, targetKeys As Object
    Dim targetLastR As Long, targetStatus As String, lookupKey As String
    Dim targetBank As String, targetCode As String
    Dim targetData As Variant, targetRestoreSnapshot As Variant
    Dim outputData As Variant, shopState() As Byte
    Dim destinationSnapshot As Variant
    Dim isTransaction As Boolean
    Dim convertedAddress As String, remainedAddress As String
    Dim convertedBatchCount As Long, remainedBatchCount As Long
    Dim outputMutationStarted As Boolean, targetMutationStarted As Boolean
    Dim destinationSnapshotCaptured As Boolean, targetSnapshotCaptured As Boolean
    Dim destinationPreviouslyExisted As Boolean
    Dim destinationSnapshotLastRow As Long, targetSnapshotLastRow As Long
    Dim rollbackMask As Long
    Dim originalVisibility As XlSheetVisibility, targetOriginalVisibility As XlSheetVisibility
    Dim rollbackSucceeded As Boolean, destinationRestored As Boolean, targetRestored As Boolean
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim cleanupErrorNumber As Long, cleanupErrorDescription As String
    Dim cleanupErrorSource As String, cleanupEventDetail As String
    Dim rollbackDetail As String
    On Error GoTo EH
    If Not capacityConfirmed Then
        If Not RequireOutputBuildCapacity("取扱店変換の反映", False, False, False, _
                                          False, True, False) Then Err.Raise 18
    End If
    Set wsSrc = GetSheet(SH_WORK_CASH)
    Set wsTarget = GetSheet(SH_SHOP_TARGET)
    destinationPreviouslyExisted = SheetExists(SH_OUTPUT_TX_CONVERTED)
    Set wsDest = GetOrCreateSheet(SH_OUTPUT_TX_CONVERTED, False)
    originalVisibility = wsDest.Visible
    targetOriginalVisibility = wsTarget.Visible
    Set conversionMap = CreateObject("Scripting.Dictionary")
    conversionMap.CompareMode = vbTextCompare
    Set targetKeys = CreateObject("Scripting.Dictionary")
    targetKeys.CompareMode = vbTextCompare
    targetLastR = LastRow(wsTarget, SHOP_TGT_COL_CODE)
    ValidateShopTargetStoredCells wsTarget, targetLastR
    targetSnapshotLastRow = LastDataRowInColumns(wsTarget, 1, SHOP_TGT_LAST_COL)
    If targetSnapshotLastRow < 2 Then targetSnapshotLastRow = 2
    targetRestoreSnapshot = wsTarget.Range( _
        wsTarget.Cells(1, 1), _
        wsTarget.Cells(targetSnapshotLastRow, SHOP_TGT_LAST_COL)).Value2
    If Not ShopSnapshotDimensionsMatch(targetRestoreSnapshot, _
                                       targetSnapshotLastRow, _
                                       SHOP_TGT_LAST_COL) Then _
        Err.Raise vbObjectError + 4326, "ApplyShopConversionCore", _
                  "取扱店変換対象の更新前snapshot寸法が不正です。"
    targetSnapshotCaptured = True
    If targetLastR >= 2 Then
        targetData = wsTarget.Range(wsTarget.Cells(2, 1), _
                                    wsTarget.Cells(targetLastR, SHOP_TGT_LAST_COL)).Value2
        For r = 1 To UBound(targetData, 1)
            targetStatus = CellText(targetData(r, SHOP_TGT_COL_STATUS))
            resultName = CellText(targetData(r, SHOP_TGT_COL_RESULT))
            targetBank = CellText(targetData(r, SHOP_TGT_COL_BANK))
            targetCode = CellText(targetData(r, SHOP_TGT_COL_CODE))
            If Len(targetBank) = 0 Or Len(targetCode) = 0 Then _
                Err.Raise vbObjectError + 4309, "ApplyShopConversionCore", _
                          "取扱店変換対象の銀行名またはコードが空欄です（" & CStr(r + 1) & "行）。"
            lookupKey = ShopConversionKey(targetBank, targetCode)
            If targetKeys.Exists(lookupKey) Then _
                Err.Raise vbObjectError + 4310, "ApplyShopConversionCore", _
                          "取扱店変換対象に同じ銀行名・コードが重複しています（" & CStr(r + 1) & "行）。"
            targetKeys.Add lookupKey, True
            If Len(resultName) > 100 Then
                Err.Raise vbObjectError + 4301, "ApplyShopConversionCore", _
                          "変換後取扱店は100文字以内にしてください（" & CStr(r + 1) & "行）。"
            End If
            Select Case targetStatus
                Case "未入力"
                    '変換名を入力した直後は未入力のままでもよい。反映後に入力済へ更新する。
                Case "入力済"
                    If Len(resultName) = 0 Then _
                        Err.Raise vbObjectError + 4311, "ApplyShopConversionCore", _
                                  "確認状況が入力済ですが、変換後取扱店が空欄です（" & CStr(r + 1) & "行）。"
                Case "確認不要"
                    If Len(resultName) > 0 Then _
                        Err.Raise vbObjectError + 4312, "ApplyShopConversionCore", _
                                  "確認不要の行に変換後取扱店が入力されています（" & CStr(r + 1) & "行）。"
                Case "保留"
                Case Else
                    Err.Raise vbObjectError + 4313, "ApplyShopConversionCore", _
                              "確認状況が不正です（" & CStr(r + 1) & "行）: " & targetStatus
            End Select
            If Len(resultName) > 0 And targetStatus <> "保留" And targetStatus <> "確認不要" Then
                conversionMap(lookupKey) = resultName
            End If
        Next r
    End If

    CaptureConvertedShopOutputSnapshot wsDest, destinationSnapshot, _
                                       destinationSnapshotLastRow
    destinationSnapshotCaptured = True

    '変換結果をメモリ上で完成させるまでは、前回の変換済み表を消さない。
    lastR = LastUsedRowInSheet(wsSrc)
    If lastR < 1 Then lastR = 1
    outputData = wsSrc.Range(wsSrc.Cells(1, 1), _
                             wsSrc.Cells(lastR, OUT_COL_INPUT_ORDER)).Value2
    If lastR >= 2 Then
        dataCount = lastR - 1
        ReDim shopState(1 To dataCount)
    End If
    For r = 1 To dataCount
        bankName = CellText(outputData(r + 1, OUT_COL_BANK))
        recordType = CellText(outputData(r + 1, OUT_COL_RECORD_TYPE))
        tekiyoText = CellText(outputData(r + 1, OUT_COL_TEKIYO))
        isTransaction = False
        If Len(bankName) > 0 Then
            If recordType = RECORD_TRANSACTION Then
                isTransaction = True
            ElseIf Not IsSpecialCashOperationRow(tekiyoText) Then
                If Len(CellText(outputData(r + 1, OUT_COL_DATE))) > 0 Then isTransaction = True
            End If
        End If
        If isTransaction Then
            shopText = CellText(outputData(r + 1, OUT_COL_SHOP))
            If IsCodeLikeShop(shopText) Then
                codeText = NormalizeShopCodeText(shopText)
                lookupKey = ShopConversionKey(bankName, codeText)
                If Not targetKeys.Exists(lookupKey) Then _
                    Err.Raise vbObjectError + 4320, "ApplyShopConversionCore", _
                              "資金操作表の取扱店コードが変換対象一覧にありません（" & _
                              CStr(r + 1) & "行）: " & bankName & " / " & codeText
                resultName = ""
                If conversionMap.Exists(lookupKey) Then resultName = CStr(conversionMap(lookupKey))
                If Len(resultName) > 0 Then
                    outputData(r + 1, OUT_COL_SHOP) = resultName
                    shopState(r) = 1
                    convertedCount = convertedCount + 1
                Else
                    shopState(r) = 2
                    remainedCount = remainedCount + 1
                End If
            End If
        End If
    Next r

    outputMutationStarted = True
    ClearGeneratedOutputSheet wsDest, 21
    wsDest.Range("A1:E" & CStr(lastR)).NumberFormatLocal = "@"
    wsDest.Range("J1:L" & CStr(lastR)).NumberFormatLocal = "@"
    wsDest.Range("N1:P" & CStr(lastR)).NumberFormatLocal = "@"
    wsDest.Range(wsDest.Cells(1, 1), _
                 wsDest.Cells(lastR, OUT_COL_INPUT_ORDER)).Value2 = outputData
    VerifyGeneratedRangeValue2 wsDest, outputData, 1, 1, lastR, _
                               OUT_COL_INPUT_ORDER, "取扱店反映済み資金操作表", False
    wsDest.Columns("N:Q").Hidden = True
    For r = 1 To dataCount
        If shopState(r) = 1 Then
            QueueShopCellColor wsDest, r + 1, OUT_COL_SHOP, RGB(204, 251, 241), _
                               convertedAddress, convertedBatchCount
        ElseIf shopState(r) = 2 Then
            QueueShopCellColor wsDest, r + 1, OUT_COL_SHOP, RGB(254, 240, 138), _
                               remainedAddress, remainedBatchCount
        End If
    Next r
    FlushShopCellColor wsDest, convertedAddress, convertedBatchCount, RGB(204, 251, 241)
    FlushShopCellColor wsDest, remainedAddress, remainedBatchCount, RGB(254, 240, 138)

    '元の資金操作表は既に並べ替え済みで、取扱店名の置換は並び順に影響しない。
    '再ソートを省き、大量明細でも反映時間を抑える。
    FormatCashOperationOutputLayout wsDest
    SafeFreezeOutputHeader wsDest
    ProtectGeneratedOutputSheet wsDest, True
    wsTarget.Unprotect Password:=TOOL_PASSWORD
    targetMutationStarted = True
    UpdateShopTargetStatuses wsTarget
    FormatShopConversionTargetSheet wsTarget
    wsDest.Visible = xlSheetVisible

    If activateAfter Then
        wsDest.Activate
        wsDest.Range("A1").Select
    End If
    If showDoneMessage Then
        MsgBox "取扱店反映済み資金操作表を作成しました。" & vbCrLf & _
               "反映済み: " & convertedCount & "件" & vbCrLf & _
               "未入力・未反映: " & remainedCount & "件", vbInformation
    End If
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    If IsShopNestedRecoveryHardBarrier( _
           errorNumber, errorSource, errorDescription) Then
        Call TryKeepShopEventsDisabledExact(cleanupEventDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    rollbackSucceeded = True
    rollbackMask = ShopConversionRollbackMask(outputMutationStarted, targetMutationStarted)
    If (rollbackMask And 1) <> 0 Then
        destinationRestored = RestoreConvertedShopOutputSnapshot( _
            wsDest, destinationSnapshot, destinationSnapshotLastRow, _
            destinationPreviouslyExisted, destinationSnapshotCaptured, _
            originalVisibility, rollbackDetail)
        If Not destinationRestored Then rollbackSucceeded = False
    ElseIf Not wsDest Is Nothing Then
        On Error Resume Next
        Err.Clear
        ProtectGeneratedOutputSheet wsDest, True
        cleanupErrorNumber = Err.Number
        cleanupErrorDescription = Err.Description
        cleanupErrorSource = Err.Source
        Err.Clear
        On Error GoTo 0
        If IsShopNestedRecoveryHardBarrier( _
               cleanupErrorNumber, cleanupErrorSource, _
               cleanupErrorDescription) Then
            Call TryKeepShopEventsDisabledExact(cleanupEventDetail)
            Err.Raise cleanupErrorNumber, cleanupErrorSource, _
                      cleanupErrorDescription
        End If
        If cleanupErrorNumber <> 0 Then
            rollbackSucceeded = False
            AppendShopRollbackDetail rollbackDetail, _
                "変換済み表を再保護できません: " & cleanupErrorDescription
        End If
    End If
    If (rollbackMask And 2) <> 0 Then
        targetRestored = RestoreShopTargetAfterApplySnapshot( _
            wsTarget, targetRestoreSnapshot, targetSnapshotLastRow, _
            targetSnapshotCaptured, _
            targetOriginalVisibility, rollbackDetail)
        If Not targetRestored Then rollbackSucceeded = False
    ElseIf Not wsTarget Is Nothing Then
        On Error Resume Next
        Err.Clear
        ProtectShopConversionTargetSheet True
        cleanupErrorNumber = Err.Number
        cleanupErrorDescription = Err.Description
        cleanupErrorSource = Err.Source
        Err.Clear
        On Error GoTo 0
        If IsShopNestedRecoveryHardBarrier( _
               cleanupErrorNumber, cleanupErrorSource, _
               cleanupErrorDescription) Then
            Call TryKeepShopEventsDisabledExact(cleanupEventDetail)
            Err.Raise cleanupErrorNumber, cleanupErrorSource, _
                      cleanupErrorDescription
        End If
        If cleanupErrorNumber <> 0 Then
            rollbackSucceeded = False
            AppendShopRollbackDetail rollbackDetail, _
                "取扱店変換対象を再保護できません: " & _
                cleanupErrorDescription
        End If
    End If
    If Not rollbackSucceeded Then
        '外側のPublic入口が、局所rollback成功としてentry=Trueを戻さないよう伝播する。
        mShopRollbackRecoveryRequired = True
        AppendShopRollbackDetail rollbackDetail, _
            "取扱店反映のロールバックを一意に確認できません。"
        AppendShopRollbackDetail rollbackDetail, _
            "共通Recoveryの所有権を外側の終了処理へ伝播しました。"
    End If
    If Len(rollbackDetail) > 0 Then _
        errorDescription = errorDescription & " / " & rollbackDetail
    Err.Raise errorNumber, "ApplyShopConversionCore", errorDescription
End Sub

Private Sub FinalizeShopTopLevelFailure( _
        ByVal operationName As String, _
        ByVal originalErrorNumber As Long, _
        ByVal originalErrorDescription As String, _
        ByVal originalErrorSource As String, _
        ByVal appBeginSucceeded As Boolean, _
        ByRef applicationLeaseStarted As Boolean, _
        ByVal entryEventsCaptured As Boolean, _
        ByVal entryEvents As Boolean, _
        ByRef recoveryStateConfirmed As Boolean, _
        ByRef recoveryAttempted As Boolean, _
        ByRef recoveryTerminalFailure As Boolean, _
        ByRef restoreDetail As String)
    Dim recoveryWritesAllowed As Boolean, eventsStopped As Boolean
    Dim recoveryRequired As Boolean
    Dim forceRestoreNeeded As Boolean, fullAppStateConfirmed As Boolean
    Dim localSafetyConfirmed As Boolean
    Dim stepErrorNumber As Long, stepErrorDescription As String
    Dim eventDetail As String, entryRestoreDetail As String
    Dim appStateDetail As String, confirmationDetail As String

    recoveryRequired = mShopRollbackRecoveryRequired
    fullAppStateConfirmed = True
    '下位処理が既にRecovery attemptを所有したhard barrierは、
    'このmoduleでrollback/Enforce/Application cleanupを重ねずFalse-onlyで返す。
    If IsShopNestedRecoveryHardBarrier( _
           originalErrorNumber, originalErrorSource, _
           originalErrorDescription) Then
        Call TryKeepShopEventsDisabledExact(eventDetail)
        Err.Raise originalErrorNumber, originalErrorSource, _
                  originalErrorDescription
    End If

    If recoveryTerminalFailure Then GoTo RECOVERY_TERMINAL

    'AppBeginが正常returnした処理だけが、このEHで帳票状態を書き換える権限を持つ。
    '各sheet書込みの直前にEnableEvents=Falseをsetter/readbackの双方で確認する。
    If appBeginSucceeded And entryEventsCaptured Then
        eventsStopped = TryKeepShopEventsDisabledExact(eventDetail)
        recoveryWritesAllowed = eventsStopped
        If Not eventsStopped Then _
            AppendShopRollbackDetail restoreDetail, _
                "帳票状態の記録前にExcelイベント停止を確認できないため、" & _
                "sheetへの失敗記録を行っていません: " & eventDetail
    Else
        AppendShopRollbackDetail restoreDetail, _
            "AppBeginの正常完了を確認できないため、dirty・Recovery・診断のsheet書込みを行っていません。"
    End If

    '局所rollbackが不成立なら、共通Recoveryの唯一のownerはこの終了処理とする。
    '成功時もEnforce内部でApplication leaseが閉じられるため、後続AppEnd/Forceは行わない。
    If recoveryRequired Then
        If Not recoveryWritesAllowed Then
            recoveryTerminalFailure = True
            AppendShopRollbackDetail restoreDetail, _
                "局所rollback失敗後にExcelイベント停止を確認できず、Recoveryを開始していません。"
            GoTo RECOVERY_TERMINAL
        End If
        EnsureShopRecoveryStateExact _
            operationName & "の局所rollback失敗", _
            recoveryStateConfirmed, recoveryAttempted, _
            recoveryTerminalFailure, restoreDetail
        If recoveryAttempted Then
            recoveryTerminalFailure = True
            GoTo RECOVERY_TERMINAL
        End If
        If recoveryTerminalFailure Then GoTo RECOVERY_TERMINAL
        If Not recoveryStateConfirmed Then GoTo RECOVERY_TERMINAL
        applicationLeaseStarted = False
        fullAppStateConfirmed = True
        recoveryWritesAllowed = True
    Else
        If recoveryWritesAllowed Then
            On Error Resume Next
            Err.Clear
            MarkOutputsDirty
            stepErrorNumber = Err.Number
            stepErrorDescription = Err.Description
            Err.Clear
            On Error GoTo 0
            If stepErrorNumber <> 0 Then
                recoveryRequired = True
                AppendShopRollbackDetail restoreDetail, _
                    "帳票要更新状態の確認エラー: Err " & _
                    CStr(stepErrorNumber) & " " & stepErrorDescription
            End If
        End If

        'この入口が取得したApplication leaseだけを通常手順で閉じる。
        If applicationLeaseStarted Then
            On Error Resume Next
            Err.Clear
            EnableInputKeys
            stepErrorNumber = Err.Number
            stepErrorDescription = Err.Description
            Err.Clear
            On Error GoTo 0
            If stepErrorNumber <> 0 Then
                recoveryRequired = True
                AppendShopRollbackDetail restoreDetail, _
                    "入力キー状態の復元エラー: Err " & _
                    CStr(stepErrorNumber) & " " & stepErrorDescription
            End If

            On Error Resume Next
            Err.Clear
            AppEnd
            stepErrorNumber = Err.Number
            stepErrorDescription = Err.Description
            Err.Clear
            On Error GoTo 0
            applicationLeaseStarted = False
            If stepErrorNumber <> 0 Then
                forceRestoreNeeded = True
                recoveryRequired = True
                AppendShopRollbackDetail restoreDetail, _
                    "Excel状態の通常復元エラー: Err " & _
                    CStr(stepErrorNumber) & " " & stepErrorDescription
            End If
        ElseIf Not appBeginSucceeded Then
            AppendShopRollbackDetail restoreDetail, _
                "正常完了を確認していないApplication leaseへAppEnd/AppForceRestoreを実行していません。"
        End If

        If forceRestoreNeeded Then
            On Error Resume Next
            Err.Clear
            AppForceRestore
            stepErrorNumber = Err.Number
            stepErrorDescription = Err.Description
            Err.Clear
            On Error GoTo 0
            If stepErrorNumber <> 0 Then
                fullAppStateConfirmed = False
                recoveryRequired = True
                AppendShopRollbackDetail restoreDetail, _
                    "Excel状態の強制復元エラー: Err " & _
                    CStr(stepErrorNumber) & " " & stepErrorDescription
            End If
        End If

        If entryEvents Then
            fullAppStateConfirmed = _
                TryGetShopApplicationStateSafe(appStateDetail)
            If Not fullAppStateConfirmed Then
                recoveryRequired = True
                AppendShopRollbackDetail restoreDetail, appStateDetail
            End If
        End If

        eventsStopped = False
        If entryEventsCaptured Then _
            eventsStopped = TryKeepShopEventsDisabledExact(eventDetail)
        If Not eventsStopped Then
            recoveryWritesAllowed = False
            recoveryRequired = True
            AppendShopRollbackDetail restoreDetail, _
                "Application復元後にExcelイベント停止を確認できません: " & _
                eventDetail
        Else
            recoveryWritesAllowed = recoveryWritesAllowed And eventsStopped
        End If

        If recoveryRequired Then
            mShopRollbackRecoveryRequired = True
            EnsureShopRecoveryStateExact _
                operationName & "の失敗終了", _
                recoveryStateConfirmed, recoveryAttempted, _
                recoveryTerminalFailure, restoreDetail
            If recoveryAttempted Then
                recoveryTerminalFailure = True
                GoTo RECOVERY_TERMINAL
            End If
            If recoveryTerminalFailure Then GoTo RECOVERY_TERMINAL
            If Not recoveryStateConfirmed Then GoTo RECOVERY_TERMINAL
            recoveryWritesAllowed = appBeginSucceeded
            fullAppStateConfirmed = True
        End If
    End If

    '診断はFalse exact直下で行い、Recovery中なら同じattemptの二重状態と
    'Application安全性を再確認する。再Enforceはしない。
    If recoveryWritesAllowed Then
        eventsStopped = TryKeepShopEventsDisabledExact(eventDetail)
        If Not eventsStopped Then
            AppendShopRollbackDetail restoreDetail, _
                "診断記録前にExcelイベント停止を確認できません: " & eventDetail
            If recoveryAttempted Then recoveryTerminalFailure = True
        Else
            TryRecordShopFailureCheck operationName, _
                "Err " & CStr(originalErrorNumber) & ": " & _
                originalErrorDescription & restoreDetail, restoreDetail
            eventsStopped = TryKeepShopEventsDisabledExact(eventDetail)
            If Not eventsStopped Then
                AppendShopRollbackDetail restoreDetail, _
                    "診断記録後にExcelイベント停止を確認できません: " & eventDetail
                If recoveryAttempted Then recoveryTerminalFailure = True
            ElseIf recoveryAttempted Then
                EnsureShopRecoveryStateExact operationName, _
                    recoveryStateConfirmed, recoveryAttempted, _
                    recoveryTerminalFailure, restoreDetail
                recoveryTerminalFailure = True
            End If
        End If
        If recoveryTerminalFailure Then GoTo RECOVERY_TERMINAL
    End If

    If entryEventsCaptured Then
        localSafetyConfirmed = _
            (Not recoveryRequired) And fullAppStateConfirmed
        If Not TryRestoreShopEntryEvents( _
                   entryEvents, localSafetyConfirmed, _
                   operationName & "の失敗終了", _
                   recoveryStateConfirmed, recoveryAttempted, _
                   recoveryTerminalFailure, entryRestoreDetail) Then
            AppendShopRollbackDetail restoreDetail, entryRestoreDetail
        End If
        If recoveryAttempted Then recoveryTerminalFailure = True
        If recoveryTerminalFailure Then GoTo RECOVERY_TERMINAL
    Else
        AppendShopRollbackDetail restoreDetail, _
            "Excelイベントの開始値を取得できていないため、開始状態の復元を断定できません。"
    End If
    mShopRollbackRecoveryRequired = False
    Exit Sub

RECOVERY_TERMINAL:
    '最初のEnforce失敗、post-False不成立、二重Recovery未確認以後は
    'Application/sheet/stateへ触れず、False exactへの収束と文字列追記だけを許可する。
    recoveryStateConfirmed = False
    mShopRollbackRecoveryRequired = True
    If TryKeepShopEventsDisabledExact(eventDetail) Then
        AppendShopRollbackDetail restoreDetail, _
            "Recoveryの確認に失敗したため、EnableEvents=Falseを維持しました。"
    Else
        AppendShopRollbackDetail restoreDetail, _
            "Recovery失敗後のEnableEvents=False収束も確認できません: " & eventDetail
    End If
End Sub

Private Function TryGetShopEnableEvents(ByRef currentValue As Boolean, _
                                        ByRef detailText As String) As Boolean
    detailText = vbNullString
    On Error GoTo EH
    currentValue = Application.EnableEvents
    TryGetShopEnableEvents = True
    Exit Function
EH:
    detailText = "Err " & CStr(Err.Number) & " " & Err.Description
    Err.Clear
End Function

Private Function TrySetShopEnableEventsExact(ByVal expectedValue As Boolean, _
                                             ByRef detailText As String) As Boolean
    Dim actualValue As Boolean
    Dim setterErrorNumber As Long, setterErrorDescription As String
    Dim readErrorNumber As Long, readErrorDescription As String
    detailText = vbNullString
    On Error Resume Next
    Err.Clear
    Application.EnableEvents = expectedValue
    setterErrorNumber = Err.Number
    setterErrorDescription = Err.Description
    Err.Clear
    actualValue = Application.EnableEvents
    readErrorNumber = Err.Number
    readErrorDescription = Err.Description
    Err.Clear
    On Error GoTo 0
    If setterErrorNumber = 0 And readErrorNumber = 0 And _
       actualValue = expectedValue Then
        TrySetShopEnableEventsExact = True
        Exit Function
    End If
    If setterErrorNumber <> 0 Then _
        AppendShopRollbackDetail detailText, _
            "setter Err " & CStr(setterErrorNumber) & " " & setterErrorDescription
    If readErrorNumber <> 0 Then
        AppendShopRollbackDetail detailText, _
            "readback Err " & CStr(readErrorNumber) & " " & readErrorDescription
    ElseIf actualValue <> expectedValue Then
        AppendShopRollbackDetail detailText, _
            "readback不一致（期待=" & CStr(expectedValue) & _
            "、実値=" & CStr(actualValue) & "）"
    End If
End Function

Private Function TryKeepShopEventsDisabledExact(ByRef detailText As String) As Boolean
    TryKeepShopEventsDisabledExact = _
        TrySetShopEnableEventsExact(False, detailText)
End Function

Private Sub EnsureShopRecoveryStateExact( _
        ByVal reasonText As String, _
        ByRef recoveryStateConfirmed As Boolean, _
        ByRef recoveryAttempted As Boolean, _
        ByRef recoveryTerminalFailure As Boolean, _
        ByRef detailText As String)
    Dim recoveryDetail As String, eventDetail As String
    Dim appStateDetail As String

    If recoveryTerminalFailure Then
        recoveryStateConfirmed = False
        If Not TryKeepShopEventsDisabledExact(eventDetail) Then _
            AppendShopRollbackDetail detailText, _
                "Recovery terminal後のFalse収束も確認できません: " & eventDetail
        Exit Sub
    End If

    'Enforceは終了処理全体で一度だけ。既に成功している場合は、fresh False、
    '段階的な二重状態、Application安全性だけを再確認する。
    If recoveryAttempted Then
        If Not recoveryStateConfirmed Then
            recoveryTerminalFailure = True
            AppendShopRollbackDetail detailText, _
                "以前のRecovery attemptが未確認のため再実行を禁止しました。"
            If Not TryKeepShopEventsDisabledExact(eventDetail) Then _
                AppendShopRollbackDetail detailText, _
                    "Recovery未確認後のFalse収束にも失敗しました: " & eventDetail
            Exit Sub
        End If
        If Not TryKeepShopEventsDisabledExact(eventDetail) Then
            recoveryStateConfirmed = False
            recoveryTerminalFailure = True
            AppendShopRollbackDetail detailText, _
                "Recovery再確認前にExcelイベント停止を確認できません: " & eventDetail
            Exit Sub
        End If
        recoveryStateConfirmed = _
            TryConfirmShopRecoveryStateExact(recoveryDetail)
        If Not recoveryStateConfirmed Then
            recoveryTerminalFailure = True
            AppendShopRollbackDetail detailText, recoveryDetail
            If Not TryKeepShopEventsDisabledExact(eventDetail) Then _
                AppendShopRollbackDetail detailText, _
                    "Recovery二重状態未確認後のFalse収束にも失敗しました: " & eventDetail
            Exit Sub
        End If
        If Not TryGetShopApplicationStateSafe(appStateDetail) Then
            recoveryStateConfirmed = False
            recoveryTerminalFailure = True
            AppendShopRollbackDetail detailText, appStateDetail
            If Not TryKeepShopEventsDisabledExact(eventDetail) Then _
                AppendShopRollbackDetail detailText, _
                    "Application状態未確認後のFalse収束にも失敗しました: " & eventDetail
            Exit Sub
        End If
        If Not TryKeepShopEventsDisabledExact(eventDetail) Then
            recoveryStateConfirmed = False
            recoveryTerminalFailure = True
            AppendShopRollbackDetail detailText, _
                "Recovery再確認後のExcelイベント停止を確認できません: " & eventDetail
            Exit Sub
        End If
        AppendShopRollbackDetail detailText, _
            "既存Recovery attemptの二重状態とApplication安全性を再確認しました。"
        Exit Sub
    End If

    recoveryStateConfirmed = TryEnterShopRecoveryStateExact( _
                                 reasonText, recoveryAttempted, _
                                 recoveryTerminalFailure, recoveryDetail)
    If recoveryStateConfirmed Then
        AppendShopRollbackDetail detailText, _
            "独立ラッチ、案件health、Application状態の読戻しにより、要復旧停止を確認しました。"
    Else
        AppendShopRollbackDetail detailText, _
            "案件の要復旧停止を一意に確認できません: " & recoveryDetail
    End If
End Sub

Private Function TryEnterShopRecoveryStateExact( _
        ByVal reasonText As String, _
        ByRef recoveryAttempted As Boolean, _
        ByRef recoveryTerminalFailure As Boolean, _
        ByRef detailText As String) As Boolean
    Dim recoveryErrorNumber As Long, recoveryErrorDescription As String
    Dim eventsStopped As Boolean, recoveryConfirmed As Boolean
    Dim eventDetail As String, confirmationDetail As String
    Dim applicationStateDetail As String
    detailText = reasonText

    'Recoveryの最初のbook書込みより前にFalseをexact確認する。
    If Not TryKeepShopEventsDisabledExact(eventDetail) Then
        recoveryTerminalFailure = True
        AppendShopRollbackDetail detailText, _
            "Recovery開始前にExcelイベント停止を確認できません: " & eventDetail
        Exit Function
    End If
    recoveryAttempted = True
    On Error Resume Next
    Err.Clear
    EnforceRollbackRecoveryState detailText
    recoveryErrorNumber = Err.Number
    recoveryErrorDescription = Err.Description
    Err.Clear
    On Error GoTo 0

    'Enforce直後はErr分岐より先に、唯一許可するfresh False収束を行う。
    eventsStopped = TryKeepShopEventsDisabledExact(eventDetail)
    If recoveryErrorNumber <> 0 Then _
        AppendShopRollbackDetail detailText, _
            "Recovery記録 Err " & CStr(recoveryErrorNumber) & " " & _
            recoveryErrorDescription
    If Not eventsStopped Then
        recoveryTerminalFailure = True
        AppendShopRollbackDetail detailText, _
            "Recovery処理直後にExcelイベント停止を確認できません: " & _
            eventDetail
        Exit Function
    End If

    'Enforce Err時のラッチ/healthは以前の成功値かもしれないため読まない。
    'この呼出しはFalse exactだけで終了し、診断・状態表示・Saved・True復元を許可しない。
    If recoveryErrorNumber <> 0 Then
        recoveryTerminalFailure = True
        AppendShopRollbackDetail detailText, _
            "Enforceが正常returnしないため、既存Recovery状態を読み戻していません。"
        Exit Function
    End If

    recoveryConfirmed = _
        TryConfirmShopRecoveryStateExact(confirmationDetail)
    If Len(confirmationDetail) > 0 Then _
        AppendShopRollbackDetail detailText, confirmationDetail
    If Not recoveryConfirmed Then
        recoveryTerminalFailure = True
        If Not TryKeepShopEventsDisabledExact(eventDetail) Then _
            AppendShopRollbackDetail detailText, _
                "Recovery二重状態未確認後のFalse収束にも失敗しました: " & eventDetail
        Exit Function
    End If
    If Not TryGetShopApplicationStateSafe(applicationStateDetail) Then
        recoveryTerminalFailure = True
        AppendShopRollbackDetail detailText, applicationStateDetail
        If Not TryKeepShopEventsDisabledExact(eventDetail) Then _
            AppendShopRollbackDetail detailText, _
                "Application状態未確認後のFalse収束にも失敗しました: " & eventDetail
        Exit Function
    End If
    If Not TryKeepShopEventsDisabledExact(eventDetail) Then
        recoveryTerminalFailure = True
        AppendShopRollbackDetail detailText, _
            "Recovery確認後のExcelイベント停止を確認できません: " & eventDetail
        Exit Function
    End If
    TryEnterShopRecoveryStateExact = True
End Function

Private Function TryConfirmShopRecoveryStateExact( _
        ByRef detailText As String) As Boolean
    Dim latchSet As Boolean, latchReadSucceeded As Boolean
    Dim healthValue As String, healthReadSucceeded As Boolean
    Dim errorNumber As Long, errorDescription As String
    detailText = vbNullString
    On Error GoTo EH
    latchReadSucceeded = TryGetRollbackRecoveryLatch(latchSet)
    If Not latchReadSucceeded Then
        AppendShopRollbackDetail detailText, _
            "独立復旧ラッチを一意に読み返せません。"
        Exit Function
    End If
    If Not latchSet Then
        AppendShopRollbackDetail detailText, _
            "独立復旧ラッチが設定されていません。"
        Exit Function
    End If
    healthReadSucceeded = _
        TryGetExactStateValue(STATE_DATA_HEALTH, healthValue)
    If Not healthReadSucceeded Then
        AppendShopRollbackDetail detailText, _
            "案件healthを一意に読み返せません。"
        Exit Function
    End If
    If StrComp(healthValue, DATA_HEALTH_NEEDS_RECOVERY, _
               vbBinaryCompare) <> 0 Then
        AppendShopRollbackDetail detailText, _
            "案件healthが要復旧ではありません（実値=" & healthValue & "）。"
        Exit Function
    End If
    TryConfirmShopRecoveryStateExact = True
    Exit Function
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    Err.Clear
    AppendShopRollbackDetail detailText, _
        "Recovery状態の確認エラー: Err " & _
        CStr(errorNumber) & " " & errorDescription
End Function

Private Function TryGetShopApplicationStateSafe( _
        ByRef detailText As String) As Boolean
    Dim stateDetail As String
    Dim errorNumber As Long, errorDescription As String
    detailText = vbNullString
    On Error GoTo EH
    TryGetShopApplicationStateSafe = AppStateIsRestored(stateDetail)
    If Not TryGetShopApplicationStateSafe Then _
        detailText = "Application状態の完全復元を確認できません。" & _
                     IIf(Len(stateDetail) > 0, " " & stateDetail, vbNullString)
    Exit Function
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    Err.Clear
    detailText = "Application状態の読戻しエラー: Err " & _
                 CStr(errorNumber) & " " & errorDescription
End Function

Private Function TryRestoreShopEntryEvents( _
        ByVal entryValue As Boolean, _
        ByVal localSafetyConfirmed As Boolean, _
        ByVal operationName As String, _
        ByRef recoveryStateConfirmed As Boolean, _
        ByRef recoveryAttempted As Boolean, _
        ByRef recoveryTerminalFailure As Boolean, _
        ByRef detailText As String) As Boolean
    Dim firstDetail As String, retryDetail As String, stopDetail As String
    Dim recoveryDetail As String
    Dim applicationStateDetail As String, finalDetail As String
    Dim convergenceDetail As String
    detailText = vbNullString

    '開始値Falseは書込み+読戻しで一致した時点でlease復元済みとなる。
    If Not entryValue Then
        If TryKeepShopEventsDisabledExact(firstDetail) Then
            TryRestoreShopEntryEvents = True
            Exit Function
        End If
        If TryKeepShopEventsDisabledExact(retryDetail) Then
            TryRestoreShopEntryEvents = True
            Exit Function
        End If
        detailText = "Excelイベントの開始値Falseをexact復元できません。初回=" & _
                     firstDetail & " / 再試行=" & retryDetail
        recoveryTerminalFailure = True
        Exit Function
    End If

    'entry=Trueへ触れる前に、局所安全性だけでなくfresh Falseと
    'Application状態の完全復元を必ず確認する。
    If recoveryTerminalFailure Then
        detailText = "Recovery terminal後のため開始値Trueを復元しません。"
        If Not TryKeepShopEventsDisabledExact(convergenceDetail) Then _
            AppendShopRollbackDetail detailText, _
                "False収束にも失敗しました: " & convergenceDetail
        Exit Function
    End If
    If Not TryKeepShopEventsDisabledExact(stopDetail) Then
        AppendShopRollbackDetail detailText, _
            "開始値復元前にEnableEvents=Falseをexact確認できません: " & stopDetail
        recoveryTerminalFailure = True
        Exit Function
    End If
    If Not TryGetShopApplicationStateSafe(applicationStateDetail) Then
        AppendShopRollbackDetail detailText, _
            "Application状態が安全ではありません: " & applicationStateDetail
        localSafetyConfirmed = False
    End If

    If localSafetyConfirmed Then
        If TrySetShopEnableEventsExact(True, firstDetail) Then
            TryRestoreShopEntryEvents = True
            Exit Function
        End If
        AppendShopRollbackDetail detailText, _
            "Excelイベントを開始値Trueへexact復元できません: " & firstDetail
        If Not TryKeepShopEventsDisabledExact(stopDetail) Then
            recoveryTerminalFailure = True
            AppendShopRollbackDetail detailText, _
                "開始値復元失敗後のFalse収束にも失敗しました: " & stopDetail
            Exit Function
        End If
    ElseIf Len(detailText) = 0 Then
        detailText = "局所rollbackまたはsheet保護とApplication状態の安全性を確認できないため、" & _
                     "開始値Trueの復元をRecovery確認後まで禁止します。"
    End If

    '既存の成功済みattemptは消さない。未attempt時だけ一度Enforceし、
    '以後はfresh False、段階的二重状態、Application安全性の再読戻しだけを行う。
    mShopRollbackRecoveryRequired = True
    recoveryDetail = operationName & ": " & detailText
    EnsureShopRecoveryStateExact recoveryDetail, recoveryStateConfirmed, _
                                 recoveryAttempted, recoveryTerminalFailure, _
                                 detailText
    If recoveryAttempted Then
        AppendShopRollbackDetail detailText, _
            "Recovery attemptを外側へterminal伝播するため、開始値Trueを復元しません。"
        If Not TryKeepShopEventsDisabledExact(convergenceDetail) Then
            recoveryTerminalFailure = True
            AppendShopRollbackDetail detailText, _
                "Recovery attempt後のFalse収束にも失敗しました: " & _
                convergenceDetail
        End If
        Exit Function
    End If
    If recoveryTerminalFailure Or Not recoveryStateConfirmed Then
        If Not TryKeepShopEventsDisabledExact(convergenceDetail) Then _
            AppendShopRollbackDetail detailText, _
                "Recovery未確認でFalse維持にも失敗しました: " & convergenceDetail
        Exit Function
    End If
    If Not TryKeepShopEventsDisabledExact(stopDetail) Then
        recoveryTerminalFailure = True
        AppendShopRollbackDetail detailText, _
            "Recovery確認後の開始値復元前にFalseを確認できません: " & stopDetail
        Exit Function
    End If
    If Not TryGetShopApplicationStateSafe(applicationStateDetail) Then
        recoveryStateConfirmed = False
        recoveryTerminalFailure = True
        AppendShopRollbackDetail detailText, applicationStateDetail
        If Not TryKeepShopEventsDisabledExact(convergenceDetail) Then _
            AppendShopRollbackDetail detailText, _
                "Application状態未確認後のFalse収束にも失敗しました: " & convergenceDetail
        Exit Function
    End If
    If TrySetShopEnableEventsExact(True, finalDetail) Then
        TryRestoreShopEntryEvents = True
        Exit Function
    End If
    AppendShopRollbackDetail detailText, _
        "Recovery確認後も開始値Trueへ復元できません: " & finalDetail
    recoveryTerminalFailure = True
    If Not TryKeepShopEventsDisabledExact(convergenceDetail) Then
        AppendShopRollbackDetail detailText, _
            "最終試行失敗後のFalse収束も確認できません: " & convergenceDetail
    Else
        AppendShopRollbackDetail detailText, _
            "最終試行失敗後はEnableEvents=Falseへ安全収束しました。"
    End If
End Function

Private Sub TryRecordShopFailureCheck(ByVal operationName As String, _
                                      ByVal checkDetail As String, _
                                      ByRef restoreDetail As String)
    Dim checkErrorNumber As Long, checkErrorDescription As String
    On Error Resume Next
    Err.Clear
    AddCheck "エラー", operationName, checkDetail
    checkErrorNumber = Err.Number
    checkErrorDescription = Err.Description
    Err.Clear
    On Error GoTo 0
    If checkErrorNumber <> 0 Then _
        AppendShopRollbackDetail restoreDetail, _
            "診断記録エラー: Err " & CStr(checkErrorNumber) & " " & _
            checkErrorDescription
End Sub

Private Sub AppendShopRollbackDetail(ByRef detailText As String, _
                                     ByVal newDetail As String)
    If Len(newDetail) = 0 Then Exit Sub
    If Len(detailText) > 0 Then detailText = detailText & " "
    detailText = detailText & newDetail
End Sub

Private Function IsShopNestedRecoveryHardBarrier( _
        ByVal errorNumber As Long, ByVal errorSource As String, _
        ByVal errorDescription As String) As Boolean
    Dim expectedSource As String

    'Recovery-capable nested helperが一度でもEnforceを所有した経路は、
    '元の番号・Sourceを保ったまま外側へ渡し、同じtop-levelで再試行しない。
    '3599/4499だけはproject共通のcode-only hard barrierとする。
    If errorNumber = SHOP_RECOVERY_HARD_BARRIER_ERROR Or _
       errorNumber = vbObjectError + 3599 Then
        IsShopNestedRecoveryHardBarrier = True
        Exit Function
    End If
    '519xは通常エラーとの誤衝突を避けるため、番号とcanonical Source prefixの
    '組合せが完全に一致する場合だけterminalとして扱う。
    Select Case errorNumber
        Case vbObjectError + 5191
            expectedSource = "AnalysisWorkspaceRecoveryFatal/"
        Case vbObjectError + 5192
            expectedSource = "SetupConvergeRecoveryFatal/"
        Case vbObjectError + 5194
            expectedSource = "CashAnalysisRecoveryFatal/"
        Case vbObjectError + 5195
            expectedSource = "TransactionAnalysisRecoveryFatal/"
        Case vbObjectError + 5196
            expectedSource = "CashManualSelectionRecoveryFatal/"
        Case vbObjectError + 5197
            expectedSource = "ClearRecoveryFatal/"
        Case Else
            Exit Function
    End Select
    IsShopNestedRecoveryHardBarrier = _
        (Len(errorSource) >= Len(expectedSource)) And _
        (StrComp(Left$(errorSource, Len(expectedSource)), expectedSource, _
                 vbBinaryCompare) = 0)
End Function

Private Function ShopConversionRollbackMask( _
        ByVal outputMutationStarted As Boolean, _
        ByVal targetMutationStarted As Boolean) As Long
    If outputMutationStarted Then ShopConversionRollbackMask = 1
    If targetMutationStarted Then ShopConversionRollbackMask = _
        ShopConversionRollbackMask Or 2
End Function


Private Sub CaptureConvertedShopOutputSnapshot( _
        ByVal ws As Worksheet, ByRef snapshotData As Variant, _
        ByRef snapshotLastRow As Long)
    Dim snapshotRange As Range, invalidCell As Range
    Dim helperValueCount As Double
    If ws Is Nothing Then _
        Err.Raise vbObjectError + 4321, "CaptureConvertedShopOutputSnapshot", _
                  "変換済み表の更新前snapshotを取得できません。"
    snapshotLastRow = LastDataRowInColumns( _
                          ws, 1, SHOP_OUTPUT_SNAPSHOT_LAST_COL)
    If snapshotLastRow < 1 Then snapshotLastRow = 1
    If snapshotLastRow > MAX_INTERNAL_STORE_DATA_ROWS + 1 Then _
        Err.Raise vbObjectError + 4321, "CaptureConvertedShopOutputSnapshot", _
                  "変換済み表の更新前snapshotが実用上限を超えています。"
    If ws.Shapes.Count > 0 Then _
        Err.Raise vbObjectError + 4321, "CaptureConvertedShopOutputSnapshot", _
                  "変換済み表に予期しない図形があります。更新前に確認してください。"
    helperValueCount = Application.CountA( _
        ws.Range(ws.Cells(1, OUT_COL_INPUT_ORDER + 1), _
                 ws.Cells(snapshotLastRow, SHOP_OUTPUT_SNAPSHOT_LAST_COL)))
    If helperValueCount <> 0# Then _
        Err.Raise vbObjectError + 4321, "CaptureConvertedShopOutputSnapshot", _
                  "変換済み表の一時列に未消去の値があります。更新前に確認してください。"
    Set snapshotRange = ws.Range(ws.Cells(1, 1), _
                                 ws.Cells(snapshotLastRow, _
                                          SHOP_OUTPUT_SNAPSHOT_LAST_COL))
    If Not TryFindFirstFormulaCell(snapshotRange, invalidCell) Then _
        Err.Raise vbObjectError + 4321, "CaptureConvertedShopOutputSnapshot", _
                  "変換済み表の数式有無を検査できません。"
    If Not invalidCell Is Nothing Then _
        Err.Raise vbObjectError + 4321, "CaptureConvertedShopOutputSnapshot", _
                  "変換済み表に数式があります: " & _
                  invalidCell.Address(False, False)
    Set invalidCell = Nothing
    If Not TryFindFirstErrorConstantCell(snapshotRange, invalidCell) Then _
        Err.Raise vbObjectError + 4322, "CaptureConvertedShopOutputSnapshot", _
                  "変換済み表のExcelエラー値有無を検査できません。"
    If Not invalidCell Is Nothing Then _
        Err.Raise vbObjectError + 4322, "CaptureConvertedShopOutputSnapshot", _
                  "変換済み表にExcelエラー値があります: " & _
                  invalidCell.Address(False, False)
    snapshotData = snapshotRange.Value2
    If Not ShopSnapshotDimensionsMatch(snapshotData, snapshotLastRow, _
                                       SHOP_OUTPUT_SNAPSHOT_LAST_COL) Then _
        Err.Raise vbObjectError + 4323, "CaptureConvertedShopOutputSnapshot", _
                  "変換済み表の更新前snapshot寸法が不正です。"
End Sub

Private Function RestoreConvertedShopOutputSnapshot( _
        ByVal ws As Worksheet, ByRef snapshotData As Variant, _
        ByVal snapshotLastRow As Long, _
        ByVal destinationPreviouslyExisted As Boolean, _
        ByVal snapshotCaptured As Boolean, _
        ByVal originalVisibility As XlSheetVisibility, _
        ByRef rollbackDetail As String) As Boolean
    Dim restoredLastRow As Long
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim barrierEventDetail As String
    On Error GoTo Failed
    If ws Is Nothing Or Not snapshotCaptured Or _
       Not ShopSnapshotDimensionsMatch(snapshotData, snapshotLastRow, _
                                       SHOP_OUTPUT_SNAPSHOT_LAST_COL) Then _
        Err.Raise vbObjectError + 4324, "RestoreConvertedShopOutputSnapshot", _
                  "変換済み表の復元snapshotが不正です。"

    ClearGeneratedOutputSheet ws, SHOP_OUTPUT_SNAPSHOT_LAST_COL
    ws.Range("A1:E" & CStr(snapshotLastRow)).NumberFormatLocal = "@"
    ws.Range("J1:L" & CStr(snapshotLastRow)).NumberFormatLocal = "@"
    ws.Range("N1:P" & CStr(snapshotLastRow)).NumberFormatLocal = "@"
    ws.Range(ws.Cells(1, 1), _
             ws.Cells(snapshotLastRow, SHOP_OUTPUT_SNAPSHOT_LAST_COL)).Value2 = _
        snapshotData
    VerifyGeneratedRangeValue2 ws, snapshotData, 1, 1, snapshotLastRow, _
                               SHOP_OUTPUT_SNAPSHOT_LAST_COL, _
                               "旧取扱店反映済み資金操作表の復元", False
    restoredLastRow = LastDataRowInColumns(ws, 1, SHOP_OUTPUT_SNAPSHOT_LAST_COL)
    If restoredLastRow <> LastSnapshotDataRow(snapshotData, _
                                              SHOP_OUTPUT_SNAPSHOT_LAST_COL) Then _
        Err.Raise vbObjectError + 4325, "RestoreConvertedShopOutputSnapshot", _
                  "変換済み表の復元後最終行がsnapshotと一致しません。"
    FormatCashOperationOutputLayout ws
    SafeFreezeOutputHeader ws
    ProtectGeneratedOutputSheet ws, True
    If destinationPreviouslyExisted Then
        ws.Visible = originalVisibility
    Else
        SetSheetVeryHiddenSafe ws
    End If
    VerifyGeneratedRangeValue2 ws, snapshotData, 1, 1, snapshotLastRow, _
                               SHOP_OUTPUT_SNAPSHOT_LAST_COL, _
                               "旧取扱店反映済み資金操作表の復元後照合", False
    RestoreConvertedShopOutputSnapshot = True
    Exit Function
Failed:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    If IsShopNestedRecoveryHardBarrier( _
           errorNumber, errorSource, errorDescription) Then
        Call TryKeepShopEventsDisabledExact(barrierEventDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    AppendShopRollbackDetail rollbackDetail, _
        "変換済み表の復元エラー（Err " & CStr(errorNumber) & ": " & _
        errorDescription & "）。"
    On Error Resume Next
    EmergencyProtectToolSheet ws
    SetSheetVeryHiddenSafe ws
    On Error GoTo 0
End Function

Private Function ShopSnapshotDimensionsMatch( _
        ByRef snapshotData As Variant, ByVal expectedRows As Long, _
        ByVal expectedColumns As Long) As Boolean
    On Error GoTo InvalidSnapshot
    If Not IsArray(snapshotData) Or expectedRows < 1 Or expectedColumns < 1 Then _
        Exit Function
    If UBound(snapshotData, 1) - LBound(snapshotData, 1) + 1 <> expectedRows Then _
        Exit Function
    If UBound(snapshotData, 2) - LBound(snapshotData, 2) + 1 <> expectedColumns Then _
        Exit Function
    ShopSnapshotDimensionsMatch = True
    Exit Function
InvalidSnapshot:
End Function

Private Function LastSnapshotDataRow(ByRef snapshotData As Variant, _
                                     ByVal lastColumn As Long) As Long
    Dim r As Long, c As Long, scanLastColumn As Long
    If Not IsArray(snapshotData) Or lastColumn < 1 Then Exit Function
    scanLastColumn = UBound(snapshotData, 2)
    If scanLastColumn > lastColumn Then scanLastColumn = lastColumn
    For r = UBound(snapshotData, 1) To LBound(snapshotData, 1) Step -1
        For c = LBound(snapshotData, 2) To scanLastColumn
            If HasText(snapshotData(r, c)) Then
                LastSnapshotDataRow = r - LBound(snapshotData, 1) + 1
                Exit Function
            End If
        Next c
    Next r
End Function

Private Function RestoreShopTargetAfterApplySnapshot( _
        ByVal ws As Worksheet, ByRef snapshotData As Variant, _
        ByVal snapshotLastRow As Long, ByVal snapshotCaptured As Boolean, _
        ByVal originalVisibility As XlSheetVisibility, _
        ByRef rollbackDetail As String) As Boolean
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim barrierEventDetail As String
    On Error GoTo Failed
    If ws Is Nothing Or Not snapshotCaptured Or _
       Not ShopSnapshotDimensionsMatch(snapshotData, snapshotLastRow, _
                                       SHOP_TGT_LAST_COL) Then _
        Err.Raise vbObjectError + 4326, "RestoreShopTargetAfterApplySnapshot", _
                  "取扱店変換対象の復元snapshotが不正です。"
    SetupShopConversionTargetSheet ws
    ws.Range(ws.Cells(1, 1), _
             ws.Cells(snapshotLastRow, SHOP_TGT_LAST_COL)).Value2 = snapshotData
    VerifyGeneratedRangeValue2 ws, snapshotData, 1, 1, _
                               snapshotLastRow, SHOP_TGT_LAST_COL, _
                               "取扱店変換対象の確認状態復元", False
    FormatShopConversionTargetSheet ws
    ProtectShopConversionTargetSheet True
    ws.Visible = originalVisibility
    VerifyGeneratedRangeValue2 ws, snapshotData, 1, 1, _
                               snapshotLastRow, SHOP_TGT_LAST_COL, _
                               "取扱店変換対象の復元後照合", False
    RestoreShopTargetAfterApplySnapshot = True
    Exit Function
Failed:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    If IsShopNestedRecoveryHardBarrier( _
           errorNumber, errorSource, errorDescription) Then
        Call TryKeepShopEventsDisabledExact(barrierEventDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    AppendShopRollbackDetail rollbackDetail, _
        "取扱店変換対象の復元エラー（Err " & CStr(errorNumber) & ": " & _
        errorDescription & "）。"
    On Error Resume Next
    EmergencyProtectToolSheet ws
    SetSheetVeryHiddenSafe ws
    On Error GoTo 0
End Function

Private Sub ValidateShopTargetStoredCells(ByVal ws As Worksheet, ByVal numberedLastRow As Long)
    '入力規則は貼り付けで回避できるため、一覧全体の数式・エラー値を拒否する。
    'No列より下に値が残る孤立行も、一覧更新で黙って消さない。
    Dim searchRange As Range, scanRange As Range, foundCell As Range
    Dim formulaCell As Range, errorCell As Range
    Dim lastAnyRow As Long, allowedLastRow As Long
    If ws Is Nothing Then Exit Sub
    Set searchRange = ws.Range(ws.Cells(1, 1), ws.Cells(ws.Rows.Count, SHOP_TGT_LAST_COL))
    Set foundCell = searchRange.Find(What:="*", After:=searchRange.Cells(1, 1), LookIn:=xlFormulas, _
                                     LookAt:=xlPart, SearchOrder:=xlByRows, SearchDirection:=xlPrevious, _
                                     MatchCase:=False, MatchByte:=False, SearchFormat:=False)
    If Not foundCell Is Nothing Then lastAnyRow = foundCell.Row
    allowedLastRow = CLng(Application.Max(2, numberedLastRow))
    If lastAnyRow > MAX_INTERNAL_STORE_DATA_ROWS + 1 Then
        Err.Raise vbObjectError + 4314, "ValidateShopTargetStoredCells", _
                  "取扱店変換対象が実用上限を超えています。不要な残存行を確認してください。"
    End If
    If lastAnyRow > allowedLastRow Then
        Err.Raise vbObjectError + 4315, "ValidateShopTargetStoredCells", _
                  "取扱店変換対象のNo列より下に孤立した入力があります（" & CStr(lastAnyRow) & "行まで）。"
    End If
    '復元snapshotは見出しも含むため、見出し行の数式・エラー値も許可しない。
    Set scanRange = ws.Range(ws.Cells(1, 1), ws.Cells(allowedLastRow, SHOP_TGT_LAST_COL))
    If Not TryFindFirstFormulaCell(scanRange, formulaCell) Then
        Err.Raise vbObjectError + 4318, "ValidateShopTargetStoredCells", _
                  "取扱店変換対象の数式有無を検査できません。"
    End If
    If Not formulaCell Is Nothing Then
        Err.Raise vbObjectError + 4316, "ValidateShopTargetStoredCells", _
                  "取扱店変換対象に数式があります。値として入力し直してください: " & _
                  formulaCell.Address(False, False)
    End If
    If Not TryFindFirstErrorConstantCell(scanRange, errorCell) Then
        Err.Raise vbObjectError + 4319, "ValidateShopTargetStoredCells", _
                  "取扱店変換対象のExcelエラー値有無を検査できません。"
    End If
    If Not errorCell Is Nothing Then
        Err.Raise vbObjectError + 4317, "ValidateShopTargetStoredCells", _
                  "取扱店変換対象にExcelエラー値があります: " & _
                  errorCell.Address(False, False)
    End If
End Sub

Private Sub QueueShopCellColor(ByVal ws As Worksheet, ByVal rowNo As Long, ByVal columnNo As Long, _
                               ByVal fillColor As Long, ByRef addressText As String, ByRef batchCount As Long)
    Dim cellAddress As String
    If ws Is Nothing Then Exit Sub
    cellAddress = ws.Cells(rowNo, columnNo).Address(False, False)
    If Len(addressText) > 0 Then addressText = addressText & ","
    addressText = addressText & cellAddress
    batchCount = batchCount + 1
    'Range参照文字列の環境差を避けるため、約200文字ごとに一括適用する。
    If batchCount >= 40 Or Len(addressText) >= 200 Then _
        FlushShopCellColor ws, addressText, batchCount, fillColor
End Sub

Private Sub FlushShopCellColor(ByVal ws As Worksheet, ByRef addressText As String, _
                               ByRef batchCount As Long, ByVal fillColor As Long)
    If ws Is Nothing Then Exit Sub
    If Len(addressText) = 0 Then Exit Sub
    ws.Range(addressText).Interior.Color = fillColor
    addressText = ""
    batchCount = 0
End Sub

Public Function FillBlankShopWithBranch(ByVal ws As Worksheet) As Long
    Dim lastR As Long, r As Long, dataCount As Long
    Dim branchName As String, bankName As String, recordType As String, tekiyoText As String
    Dim sourceData As Variant, shopValues() As Variant
    Dim isTransaction As Boolean
    If ws Is Nothing Then Exit Function
    lastR = LastRow(ws, OUT_COL_BANK)
    If lastR < 2 Then Exit Function
    sourceData = ws.Range(ws.Cells(2, 1), ws.Cells(lastR, OUT_COL_INPUT_ORDER)).Value2
    dataCount = UBound(sourceData, 1)
    ReDim shopValues(1 To dataCount, 1 To 1)
    For r = 1 To dataCount
        shopValues(r, 1) = sourceData(r, OUT_COL_SHOP)
        bankName = CellText(sourceData(r, OUT_COL_BANK))
        isTransaction = False
        If Len(bankName) > 0 Then
            recordType = CellText(sourceData(r, OUT_COL_RECORD_TYPE))
            tekiyoText = CellText(sourceData(r, OUT_COL_TEKIYO))
            If recordType = RECORD_TRANSACTION Then
                isTransaction = True
            ElseIf Not IsSpecialCashOperationRow(tekiyoText) Then
                If Len(CellText(sourceData(r, OUT_COL_DATE))) > 0 Then isTransaction = True
            End If
        End If
        If isTransaction Then
            If Len(CellText(shopValues(r, 1))) = 0 Then
                branchName = CellText(sourceData(r, OUT_COL_BRANCH))
                If Len(branchName) > 0 Then
                    shopValues(r, 1) = branchName
                    FillBlankShopWithBranch = FillBlankShopWithBranch + 1
                End If
            End If
        End If
    Next r
    ws.Range(ws.Cells(2, OUT_COL_SHOP), ws.Cells(lastR, OUT_COL_SHOP)).NumberFormatLocal = "@"
    ws.Range(ws.Cells(2, OUT_COL_SHOP), ws.Cells(lastR, OUT_COL_SHOP)).Value2 = shopValues
    VerifyGeneratedRangeValue2 ws, shopValues, 2, OUT_COL_SHOP, dataCount, 1, _
                               "資金操作表の取扱店補完", False
End Function

Public Sub SetupShopConversionTargetSheet(ByVal ws As Worksheet)
    Dim styleLastRow As Long
    If ws Is Nothing Then Exit Sub
    ResetWorksheet ws

    styleLastRow = 2
    With ws.Range("A1:N" & CStr(styleLastRow))
        .Font.Name = "Yu Gothic UI"
        .Font.Size = 10
        .Interior.Color = RGB(248, 250, 252)
        .Font.Color = RGB(15, 23, 42)
    End With

    SetRowValues ws.Range("A1"), Array("No", "銀行名", "取扱店コード", "該当件数", "該当行番号", "変換後取扱店", "確認状況", "作成日時")
    FormatOutputHeader ws.Range("A1:H1")
    ws.Range("A1:H1").Interior.Color = RGB(37, 99, 235)
    ws.Range("A1:H1").Font.Color = RGB(255, 255, 255)
    ws.Range("A1:H1").Borders.Color = RGB(147, 197, 253)

    ws.Columns("A:A").ColumnWidth = 6
    ws.Columns("B:B").ColumnWidth = 20
    ws.Columns("C:C").ColumnWidth = 15
    ws.Columns("D:D").ColumnWidth = 10
    ws.Columns("E:E").ColumnWidth = 18
    ws.Columns("F:F").ColumnWidth = 26
    ws.Columns("G:G").ColumnWidth = 13
    ws.Columns("H:H").ColumnWidth = 16
    ws.Columns("J:M").ColumnWidth = 12.5

    ws.Range("B1:C" & CStr(styleLastRow)).NumberFormatLocal = "@"
    ws.Range("E1:G" & CStr(styleLastRow)).NumberFormatLocal = "@"
    ws.Range("F2:G" & CStr(styleLastRow)).Interior.Color = RGB(255, 255, 255)
    ws.Range("H1:H" & CStr(styleLastRow)).NumberFormatLocal = "yyyy/m/d h:mm"
    ws.Rows(1).RowHeight = 28
    ws.Rows(1).Font.Bold = True
    ws.Range("F2:F" & CStr(styleLastRow)).Font.Bold = True

    '入力規則は実データを書き戻した後のFormatShopConversionTargetSheetで一度だけ設定する。
    '空の雛形へ設定して直後に全く同じ規則を再設定する二重処理は行わない。
End Sub

Public Sub FormatShopConversionTargetSheet(ByVal ws As Worksheet)
    Dim lastR As Long, formatLastRow As Long
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    ws.Unprotect Password:=TOOL_PASSWORD
    On Error GoTo 0
    lastR = LastRow(ws, SHOP_TGT_COL_CODE)
    formatLastRow = CLng(Application.Max(2, lastR))
    With ws.Range("A2:H" & CStr(formatLastRow))
        .Font.Name = "Yu Gothic UI"
        .Font.Size = 10
    End With
    ApplyShopEditValidation ws, CLng(Application.Max(2, lastR))
    On Error Resume Next
    ws.AutoFilterMode = False
    On Error GoTo 0

    If lastR < 2 Then
        ws.Range("A2:H2").UnMerge
        ws.Range("A2").Value = "変換対象の取扱店コードはありません。"
        '編集列F:Gを含めて結合すると、保護時に結合セル全体までロック解除される環境がある。
        '案内は保護列A:Eだけで結合し、編集列のロック状態を明確に分離する。
        ws.Range("A2:E2").Merge
        ws.Range("A2:E2").Interior.Color = RGB(220, 252, 231)
        ws.Range("A2:E2").Font.Color = RGB(20, 83, 45)
        ws.Range("A2:E2").Font.Bold = True
        ws.Range("A2:E2").HorizontalAlignment = xlCenter
        ws.Range("F2:H2").ClearContents
        ws.Rows(2).RowHeight = 28
    Else
        '大量対象でも1行ずつ書式設定しない。入力列の色分けを優先し、表全体を一括処理する。
        With ws.Range("A2:H" & CStr(lastR))
            .Borders.LineStyle = xlContinuous
            .Borders.Color = RGB(226, 232, 240)
            .Interior.Color = RGB(255, 255, 255)
            .Font.Color = RGB(15, 23, 42)
        End With
        ws.Range("C2:C" & CStr(lastR)).Interior.Color = RGB(239, 246, 255)
        ws.Range("F2:F" & CStr(lastR)).Interior.Color = RGB(236, 253, 245)
        ws.Range("G2:G" & CStr(lastR)).Interior.Color = RGB(254, 249, 195)
        ws.Range("A1:H" & lastR).AutoFilter
    End If

    ws.Range("A1:H" & CStr(formatLastRow)).VerticalAlignment = xlCenter
    ws.Range("A1:E" & CStr(formatLastRow)).HorizontalAlignment = xlCenter
    ws.Range("F1:F" & CStr(formatLastRow)).HorizontalAlignment = xlLeft
    ws.Range("G1:H" & CStr(formatLastRow)).HorizontalAlignment = xlCenter
    ws.Range("E1:F" & CStr(formatLastRow)).WrapText = True
    ws.Range("A1:H1").HorizontalAlignment = xlCenter
    ws.Range("A1:H1").VerticalAlignment = xlCenter
    ws.Rows(1).RowHeight = 32

    AutoFitSheetSmart ws, "A:H", 6, 34
    If ws.Columns("B:B").ColumnWidth < 18 Then ws.Columns("B:B").ColumnWidth = 18
    If ws.Columns("C:C").ColumnWidth < 14 Then ws.Columns("C:C").ColumnWidth = 14
    If ws.Columns("E:E").ColumnWidth < 18 Then ws.Columns("E:E").ColumnWidth = 18
    If ws.Columns("F:F").ColumnWidth < 24 Then ws.Columns("F:F").ColumnWidth = 24
    If ws.Columns("G:G").ColumnWidth < 12 Then ws.Columns("G:G").ColumnWidth = 12
    If ws.Columns("H:H").ColumnWidth < 16 Then ws.Columns("H:H").ColumnWidth = 16

    BuildShopConversionTargetPanel ws
    ws.ScrollArea = "A1:M" & CStr(Application.Max(50, lastR + 20))
    LockToolShapes ws, False
    SafeFreezeSheetAt ws, "A2", 90
    ProtectShopConversionTargetSheet True
End Sub

Public Sub BuildShopConversionTargetPanel(ByVal ws As Worksheet)
    '取扱店変換対象シートの操作カード。
    '一覧A:Hと干渉しないよう、右側J:Mの2行目以降に固定配置する。
    Dim x As Double, y As Double, w As Double, h As Double
    Dim margin As Double, gap As Double, mainH As Double, btnH As Double, smallW As Double
    Dim lastR As Long, pendingCount As Long, totalCount As Long
    Dim r As Long, values As Variant, statusText As String, resultText As String
    Dim titleShape As Shape, titleText As String
    If ws Is Nothing Then Exit Sub

    DeleteToolShapesVerified ws, False
    On Error Resume Next
    ws.Columns("J:M").ColumnWidth = 12.5
    On Error GoTo 0

    '行高は取扱店一覧の入力行にも影響するため、ここでは変更しない。
    'パネルは図形の高さを固定して、一覧の見やすさを保つ。
    x = ws.Range("J2").Left
    y = ws.Range("J2").Top + 2
    w = ws.Range("J2:M6").Width
    h = 112

    margin = 12
    gap = 8
    mainH = 34
    btnH = 28
    smallW = (w - margin * 2 - gap) / 2

    lastR = LastRow(ws, SHOP_TGT_COL_CODE)
    If lastR >= 2 Then
        totalCount = lastR - 1
        values = ws.Range(ws.Cells(2, SHOP_TGT_COL_RESULT), _
                          ws.Cells(lastR, SHOP_TGT_COL_STATUS)).Value2
        For r = 1 To UBound(values, 1)
            resultText = CellText(values(r, 1))
            statusText = CellText(values(r, 2))
            If statusText <> "確認不要" And _
               (Len(resultText) = 0 Or statusText = "未入力" Or Len(statusText) = 0) Then _
                pendingCount = pendingCount + 1
        Next r
    End If

    AddPanelBack ws, x, y, w, h

    '背景図形はセルより前面に描画されるため、セル文字ではなく透明なテキスト図形で
    '件数を表示する。再表示時に古いセル文字が残らないよう、旧表示域も空にする。
    With ws.Range("J2:M2")
        .UnMerge
        .ClearContents
    End With
    titleText = "確認待ち " & CStr(pendingCount) & "件　／　対象 " & CStr(totalCount) & "件"
    Set titleShape = ws.Shapes.AddTextbox(msoTextOrientationHorizontal, _
                                          x + margin, y + 4, w - margin * 2, 18)
    With titleShape
        .Name = UI_PREFIX & "shop_panel_title"
        .TextFrame.Characters.Text = titleText
        .TextFrame.HorizontalAlignment = xlHAlignCenter
        .TextFrame.VerticalAlignment = xlVAlignCenter
        .TextFrame.MarginLeft = 2
        .TextFrame.MarginRight = 2
        .TextFrame.MarginTop = 0
        .TextFrame.MarginBottom = 0
        .TextFrame.Characters.Font.Name = "Yu Gothic UI"
        .TextFrame.Characters.Font.Size = 10.5
        .TextFrame.Characters.Font.Bold = True
        .TextFrame.Characters.Font.Color = RGB(30, 64, 175)
        .Fill.Visible = msoFalse
        .Line.Visible = msoFalse
        .Placement = xlFreeFloating
        .Locked = True
    End With

    AddUIButton ws, x + margin, y + 26, w - margin * 2, mainH, "入力内容を反映", "ApplyShopConversionToCashOperation", "hero"
    AddUIButton ws, x + margin, y + 26 + mainH + gap, smallW, btnH, "一覧更新", "BuildShopConversionTargetSheet", "tool"
    AddUIButton ws, x + margin + smallW + gap, y + 26 + mainH + gap, smallW, btnH, "入力へ戻る", "ShowInputSheet", "soft"

    LockToolShapes ws, False
End Sub


Private Function TryConfirmShopTargetProtectionExact( _
        ByVal ws As Worksheet, ByRef detailText As String) As Boolean
    Dim errorNumber As Long, errorDescription As String
    detailText = vbNullString
    On Error GoTo EH
    If ws Is Nothing Then _
        Err.Raise vbObjectError + 4306, _
                  "TryConfirmShopTargetProtectionExact", _
                  "取扱店変換対象シートを取得できません。"
    If Not ws.ProtectContents Then _
        Err.Raise vbObjectError + 4306, _
                  "TryConfirmShopTargetProtectionExact", _
                  "セル保護が有効ではありません。"
    If Not ws.ProtectDrawingObjects Then _
        Err.Raise vbObjectError + 4306, _
                  "TryConfirmShopTargetProtectionExact", _
                  "図形保護が有効ではありません。"
    If ws.ProtectScenarios Then _
        Err.Raise vbObjectError + 4306, _
                  "TryConfirmShopTargetProtectionExact", _
                  "シナリオ保護の設定が一致しません。"
    If ws.EnableSelection <> xlNoRestrictions Then _
        Err.Raise vbObjectError + 4306, _
                  "TryConfirmShopTargetProtectionExact", _
                  "選択許可の設定が一致しません。"
    If Not ws.Protection.AllowFiltering Then _
        Err.Raise vbObjectError + 4306, _
                  "TryConfirmShopTargetProtectionExact", _
                  "フィルター許可を読み戻せません。"
    If ws.Protection.AllowSorting Then _
        Err.Raise vbObjectError + 4306, _
                  "TryConfirmShopTargetProtectionExact", _
                  "禁止した並べ替えが許可されています。"
    If ws.Protection.AllowFormattingCells Or _
       ws.Protection.AllowFormattingColumns Or _
       ws.Protection.AllowFormattingRows Then _
        Err.Raise vbObjectError + 4306, _
                  "TryConfirmShopTargetProtectionExact", _
                  "禁止した書式変更が許可されています。"
    VerifyToolShapeSecurity ws, True, False
    TryConfirmShopTargetProtectionExact = True
    Exit Function
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    Err.Clear
    detailText = "保護ポリシーの読戻しエラー: Err " & _
                 CStr(errorNumber) & " " & errorDescription
End Function

Public Sub ProtectShopConversionTargetSheet(Optional ByVal raiseOnError As Boolean = False)
    '取扱店変換対象シートは、変換後取扱店・確認状況だけ入力できればよい。
    'Saved=Trueとentry=Trueは、全保護ポリシーとfresh Falseの確認後だけ復元する。
    Dim ws As Worksheet, editLastRow As Long, dataLastRow As Long
    Dim workbookWasSaved As Boolean, emergencyProtected As Boolean
    Dim savedReadback As Boolean, protectionConfirmed As Boolean
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim emergencyErrorNumber As Long, emergencyErrorDescription As String
    Dim emergencyErrorSource As String
    Dim savedErrorNumber As Long, savedErrorDescription As String
    Dim savedReadErrorNumber As Long, savedReadErrorDescription As String
    Dim statusErrorNumber As Long, statusErrorDescription As String
    Dim entryEvents As Boolean, entryEventsCaptured As Boolean
    Dim eventsStopped As Boolean, entryEventsRestored As Boolean
    Dim recoveryStateConfirmed As Boolean, localSafetyConfirmed As Boolean
    Dim recoveryAttempted As Boolean, recoveryTerminalFailure As Boolean
    Dim recoveryDetail As String, eventStateDetail As String
    Dim policyDetail As String, postWriteDetail As String
    Dim fatalEventDetail As String, fatalDescription As String
    If Not SheetExists(SH_SHOP_TARGET) Then Exit Sub
    Set ws = GetSheet(SH_SHOP_TARGET)
    workbookWasSaved = ThisWorkbook.Saved

    On Error GoTo EH
    If Not TryGetShopEnableEvents(entryEvents, eventStateDetail) Then _
        Err.Raise vbObjectError + 4332, "ProtectShopConversionTargetSheet", _
                  "Excelイベントの開始状態を取得できません。 " & eventStateDetail
    entryEventsCaptured = True
    If Not TryKeepShopEventsDisabledExact(eventStateDetail) Then _
        Err.Raise vbObjectError + 4333, "ProtectShopConversionTargetSheet", _
                  "保護処理前にExcelイベント停止を確認できません。 " & eventStateDetail
    ws.Unprotect Password:=TOOL_PASSWORD
    RestoreToolSheetScrollArea ws
    dataLastRow = LastRow(ws, SHOP_TGT_COL_CODE)
    editLastRow = CLng(Application.Max(2, dataLastRow))
    If editLastRow > ws.Rows.Count Then editLastRow = ws.Rows.Count
    ws.Range("A1:N" & CStr(editLastRow)).Locked = True
    If Not ThisWorkbook.ReadOnly And dataLastRow >= 2 Then _
        ws.Range("F2:G" & CStr(dataLastRow)).Locked = False
    LockToolShapes ws
    ws.Protect Password:=TOOL_PASSWORD, DrawingObjects:=True, Contents:=True, Scenarios:=False, _
               UserInterfaceOnly:=True, AllowFiltering:=True, AllowSorting:=False, _
               AllowFormattingCells:=False, AllowFormattingColumns:=False, AllowFormattingRows:=False
    ws.EnableSelection = xlNoRestrictions
    protectionConfirmed = _
        TryConfirmShopTargetProtectionExact(ws, policyDetail)
    If Not protectionConfirmed Then _
        Err.Raise vbObjectError + 4306, "ProtectShopConversionTargetSheet", _
                  "取扱店変換対象シートの保護ポリシーを確認できません。 " & policyDetail
    If Not TryKeepShopEventsDisabledExact(eventStateDetail) Then _
        Err.Raise vbObjectError + 4333, "ProtectShopConversionTargetSheet", _
                  "保存状態の復元前にExcelイベント停止を確認できません。 " & eventStateDetail
    If workbookWasSaved Then
        ThisWorkbook.Saved = True
        If Not ThisWorkbook.Saved Then _
            Err.Raise vbObjectError + 4340, _
                      "ProtectShopConversionTargetSheet", _
                      "ブック保存状態をTrueへ復元できません。"
    End If
    If Not TryKeepShopEventsDisabledExact(eventStateDetail) Then _
        Err.Raise vbObjectError + 4333, "ProtectShopConversionTargetSheet", _
                  "イベント開始値の復元前にExcelイベント停止を確認できません。 " & eventStateDetail
    entryEventsRestored = TryRestoreShopEntryEvents( _
                              entryEvents, protectionConfirmed, _
                              "取扱店変換対象シート保護の終了時", _
                              recoveryStateConfirmed, recoveryAttempted, _
                              recoveryTerminalFailure, eventStateDetail)
    If recoveryAttempted Or recoveryTerminalFailure Then
        errorDescription = eventStateDetail
        GoTo SHOP_RECOVERY_FATAL
    End If
    If Not entryEventsRestored Then _
        Err.Raise vbObjectError + 4334, "ProtectShopConversionTargetSheet", _
                  eventStateDetail
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source

    If IsShopNestedRecoveryHardBarrier( _
           errorNumber, errorSource, errorDescription) Then
        Call TryKeepShopEventsDisabledExact(fatalEventDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If

    If recoveryAttempted Or recoveryTerminalFailure Then _
        GoTo SHOP_RECOVERY_FATAL

    If entryEventsCaptured Then
        eventsStopped = TryKeepShopEventsDisabledExact(eventStateDetail)
    Else
        eventStateDetail = _
            "Excelイベントの開始値を取得できていないため、緊急再保護を開始していません。"
    End If
    If Not eventsStopped Then
        recoveryTerminalFailure = True
        AppendShopRollbackDetail errorDescription, eventStateDetail
        GoTo RECOVERY_TERMINAL
    End If

    On Error Resume Next
    Err.Clear
    EmergencyProtectToolSheet ws
    emergencyErrorNumber = Err.Number
    emergencyErrorDescription = Err.Description
    emergencyErrorSource = Err.Source
    Err.Clear
    ws.EnableSelection = xlNoRestrictions
    If Err.Number <> 0 Then
        If emergencyErrorNumber = 0 Then emergencyErrorNumber = Err.Number
        If Len(emergencyErrorDescription) = 0 Then _
            emergencyErrorDescription = Err.Description
        If Len(emergencyErrorSource) = 0 Then _
            emergencyErrorSource = Err.Source
    End If
    Err.Clear
    On Error GoTo 0
    If IsShopNestedRecoveryHardBarrier( _
           emergencyErrorNumber, emergencyErrorSource, _
           emergencyErrorDescription) Then
        Call TryKeepShopEventsDisabledExact(fatalEventDetail)
        Err.Raise emergencyErrorNumber, emergencyErrorSource, _
                  emergencyErrorDescription
    End If
    emergencyProtected = _
        TryConfirmShopTargetProtectionExact(ws, policyDetail)
    If emergencyErrorNumber <> 0 Then _
        AppendShopRollbackDetail errorDescription, _
            "緊急再保護 Err " & CStr(emergencyErrorNumber) & " " & _
            emergencyErrorDescription
    If Not emergencyProtected Then
        mShopRollbackRecoveryRequired = True
        recoveryDetail = "取扱店変換対象シートの緊急再保護を確認できません。"
        AppendShopRollbackDetail recoveryDetail, policyDetail
        EnsureShopRecoveryStateExact _
            "取扱店変換対象シートの緊急再保護失敗", _
            recoveryStateConfirmed, recoveryAttempted, _
            recoveryTerminalFailure, recoveryDetail
        If recoveryAttempted Then
            AppendShopRollbackDetail errorDescription, recoveryDetail
            GoTo SHOP_RECOVERY_FATAL
        End If
        If recoveryTerminalFailure Then
            AppendShopRollbackDetail errorDescription, recoveryDetail
            GoTo RECOVERY_TERMINAL
        End If
        If Not recoveryStateConfirmed Then
            recoveryTerminalFailure = True
            AppendShopRollbackDetail errorDescription, recoveryDetail
            GoTo RECOVERY_TERMINAL
        End If

        'Recovery確認後の診断・状態表示も、各書込みの前後を同じattemptで再ゲートする。
        If Not TryKeepShopEventsDisabledExact(postWriteDetail) Then
            recoveryTerminalFailure = True
            AppendShopRollbackDetail errorDescription, postWriteDetail
            GoTo RECOVERY_TERMINAL
        End If
        TryRecordShopFailureCheck _
            "取扱店変換対象の緊急再保護", recoveryDetail, recoveryDetail
        EnsureShopRecoveryStateExact _
            "取扱店変換対象シートの診断記録後", _
            recoveryStateConfirmed, recoveryAttempted, _
            recoveryTerminalFailure, recoveryDetail
        If recoveryAttempted Then
            AppendShopRollbackDetail errorDescription, recoveryDetail
            GoTo SHOP_RECOVERY_FATAL
        End If
        If recoveryTerminalFailure Then
            AppendShopRollbackDetail errorDescription, recoveryDetail
            GoTo RECOVERY_TERMINAL
        End If

        On Error Resume Next
        Err.Clear
        SetInputStatus _
            "取扱店変換対象を再保護できないため、要復旧停止を確認しました。C_チェックを確認してください。", _
            True
        statusErrorNumber = Err.Number
        statusErrorDescription = Err.Description
        Err.Clear
        On Error GoTo 0
        If statusErrorNumber <> 0 Then _
            AppendShopRollbackDetail recoveryDetail, _
                "状態表示エラー: Err " & CStr(statusErrorNumber) & " " & _
                statusErrorDescription
        EnsureShopRecoveryStateExact _
            "取扱店変換対象シートの状態表示後", _
            recoveryStateConfirmed, recoveryAttempted, _
            recoveryTerminalFailure, recoveryDetail
        If recoveryAttempted Then
            AppendShopRollbackDetail errorDescription, recoveryDetail
            GoTo SHOP_RECOVERY_FATAL
        End If
        If recoveryTerminalFailure Then
            AppendShopRollbackDetail errorDescription, recoveryDetail
            GoTo RECOVERY_TERMINAL
        End If
        AppendShopRollbackDetail errorDescription, recoveryDetail
    End If

    'Saved=Trueは緊急再保護の全ポリシー読戻し成功時だけ許可する。
    If emergencyProtected And workbookWasSaved Then
        If Not TryKeepShopEventsDisabledExact(eventStateDetail) Then
            recoveryTerminalFailure = True
            AppendShopRollbackDetail errorDescription, _
                "保存状態の復元前にExcelイベント停止を確認できません: " & _
                eventStateDetail
            If recoveryTerminalFailure Then GoTo RECOVERY_TERMINAL
        Else
            On Error Resume Next
            Err.Clear
            ThisWorkbook.Saved = True
            savedErrorNumber = Err.Number
            savedErrorDescription = Err.Description
            Err.Clear
            savedReadback = ThisWorkbook.Saved
            savedReadErrorNumber = Err.Number
            savedReadErrorDescription = Err.Description
            Err.Clear
            On Error GoTo 0
            eventsStopped = TryKeepShopEventsDisabledExact(postWriteDetail)
            If savedErrorNumber <> 0 Or savedReadErrorNumber <> 0 Or _
               Not savedReadback Or Not eventsStopped Then
                localSafetyConfirmed = False
                mShopRollbackRecoveryRequired = True
                AppendShopRollbackDetail errorDescription, _
                    "ブック保存状態の復元を確認できません" & _
                    IIf(savedErrorNumber <> 0, _
                        ": Err " & CStr(savedErrorNumber) & " " & _
                        savedErrorDescription, vbNullString) & _
                    IIf(savedReadErrorNumber <> 0, _
                        " / 読戻し Err " & CStr(savedReadErrorNumber) & _
                        " " & savedReadErrorDescription, vbNullString) & _
                    IIf(Not eventsStopped, _
                        " / post-False " & postWriteDetail, vbNullString)
                EnsureShopRecoveryStateExact _
                    "取扱店変換対象シートのSaved復元失敗", _
                    recoveryStateConfirmed, recoveryAttempted, _
                    recoveryTerminalFailure, errorDescription
                If recoveryAttempted Then GoTo SHOP_RECOVERY_FATAL
                If recoveryTerminalFailure Then GoTo RECOVERY_TERMINAL
            Else
                localSafetyConfirmed = True
            End If
        End If
    Else
        localSafetyConfirmed = emergencyProtected
    End If

    If entryEventsCaptured Then
        entryEventsRestored = TryRestoreShopEntryEvents( _
                                  entryEvents, localSafetyConfirmed, _
                                  "取扱店変換対象シート保護の失敗終了", _
                                  recoveryStateConfirmed, recoveryAttempted, _
                                  recoveryTerminalFailure, eventStateDetail)
        If recoveryAttempted Then GoTo SHOP_RECOVERY_FATAL
        If Not entryEventsRestored Then _
            AppendShopRollbackDetail errorDescription, eventStateDetail
        If recoveryTerminalFailure Then GoTo RECOVERY_TERMINAL
    End If
    GoTo FINAL_RAISE

RECOVERY_TERMINAL:
    mShopRollbackRecoveryRequired = True
    recoveryStateConfirmed = False
    entryEventsRestored = False
    If TryKeepShopEventsDisabledExact(eventStateDetail) Then
        AppendShopRollbackDetail errorDescription, _
            "Recovery未確認のためEnableEvents=Falseを維持しました。"
    Else
        AppendShopRollbackDetail errorDescription, _
            "Recovery未確認後のFalse収束にも失敗しました: " & eventStateDetail
    End If
    GoTo SHOP_RECOVERY_FATAL

SHOP_RECOVERY_FATAL:
    'このprocedureがRecoveryを一度でも所有した経路は、成功・失敗を問わず
    '外側へterminal markerを返す。以後はFalse exactと文字列生成だけを許可する。
    mShopRollbackRecoveryRequired = True
    entryEventsRestored = False
    If Not TryKeepShopEventsDisabledExact(fatalEventDetail) Then _
        AppendShopRollbackDetail errorDescription, _
            "Shop Recovery terminal後のEnableEvents=False収束を確認できません: " & _
            fatalEventDetail
    fatalDescription = "取扱店変換対象シート保護のRecovery terminalを外側へ伝播します。"
    If errorNumber <> 0 Then _
        fatalDescription = fatalDescription & " 元エラー Err " & _
                           CStr(errorNumber) & ": " & errorDescription
    If Len(errorSource) > 0 Then _
        fatalDescription = fatalDescription & " / 元Source=" & errorSource
    On Error GoTo 0
    Err.Raise SHOP_RECOVERY_HARD_BARRIER_ERROR, _
              SHOP_RECOVERY_FATAL_PREFIX & _
                  "ProtectShopConversionTargetSheet", _
              fatalDescription

FINAL_RAISE:
    If raiseOnError Or Not emergencyProtected Or Not entryEventsRestored Then _
        Err.Raise errorNumber, "ProtectShopConversionTargetSheet", _
                  IIf(Len(errorSource) > 0, errorSource & " / ", vbNullString) & _
                  errorDescription
End Sub

Private Sub ApplyShopEditValidation(ByVal ws As Worksheet, ByVal editLastRow As Long)
    Dim errorNumber As Long
    Dim errorDescription As String

    If ws Is Nothing Then _
        Err.Raise vbObjectError + 4320, "ApplyShopEditValidation", _
                  "取扱店変換対象シートが見つからないため、入力規則を設定できません。"
    If editLastRow < 2 Then editLastRow = 2
    If editLastRow > ws.Rows.Count Then editLastRow = ws.Rows.Count
    On Error GoTo EH
    With ws.Range("F2:F" & CStr(editLastRow)).Validation
        .Delete
        .Add Type:=xlValidateTextLength, AlertStyle:=xlValidAlertStop, Operator:=xlLessEqual, Formula1:="100"
        .IgnoreBlank = True
        .ShowError = True
        .ErrorTitle = "入力文字数を確認してください"
        .ErrorMessage = "変換後取扱店は100文字以内で入力してください。"
    End With
    With ws.Range("G2:G" & CStr(editLastRow)).Validation
        .Delete
        .Add Type:=xlValidateList, AlertStyle:=xlValidAlertStop, Operator:=xlBetween, _
             Formula1:="未入力,入力済,確認不要,保留"
        .IgnoreBlank = True
        .InCellDropdown = True
        '状態列は処理分岐に直結するため、表記ゆれ・末尾空白を自由入力させない。
        .ShowError = True
    End With

    'Validation.Addの失敗を黙殺すると、見た目は正常でも任意文字列を入力でき、
    '後続の変換判定が不定になる。設定直後に代表セルを読み戻して確定させる。
    With ws.Cells(2, 6).Validation
        If .Type <> xlValidateTextLength Or Not .ShowError Then _
            Err.Raise vbObjectError + 4321, "ApplyShopEditValidation", _
                      "変換後取扱店列の入力規則を確認できませんでした。"
    End With
    With ws.Cells(2, 7).Validation
        If .Type <> xlValidateList Or Not .ShowError Or Not .InCellDropdown Then _
            Err.Raise vbObjectError + 4322, "ApplyShopEditValidation", _
                      "確認状況列の入力規則を確認できませんでした。"
        If Len(CStr(.Formula1)) = 0 Then _
            Err.Raise vbObjectError + 4323, "ApplyShopEditValidation", _
                      "確認状況列の選択肢を確認できませんでした。"
    End With
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    Err.Raise errorNumber, "ApplyShopEditValidation", _
              "取扱店変換対象の入力規則を設定できませんでした。" & vbCrLf & errorDescription
End Sub

Private Function IsSpecialCashOperationRow(ByVal tekiyoText As String) As Boolean
    If tekiyoText = "口座開設日" Or tekiyoText = "口座解約日" Then
        IsSpecialCashOperationRow = True
    ElseIf InStr(tekiyoText, "残高") > 0 Then
        IsSpecialCashOperationRow = True
    End If
End Function

Private Function ShopConversionKey(ByVal bankName As String, ByVal codeText As String) As String
    ShopConversionKey = UCase$(Trim$(bankName)) & Chr$(30) & UCase$(NormalizeShopCodeText(codeText))
End Function

Private Sub LoadPreservedShopValues(ByVal oldData As Variant, ByVal resultByKey As Object, ByVal statusByKey As Object)
    Dim i As Long, bankCol As Long, codeCol As Long, resultCol As Long, statusCol As Long
    Dim keyText As String, bankText As String, codeText As String, resultText As String, statusText As String
    Dim errorNumber As Long, errorDescription As String
    If Not IsArray(oldData) Then Exit Sub
    On Error GoTo EH
    bankCol = OldDataHeaderIndex(oldData, "銀行名", 0)
    codeCol = OldDataHeaderIndex(oldData, "取扱店コード", 0)
    resultCol = OldDataHeaderIndex(oldData, "変換後取扱店", 0)
    statusCol = OldDataHeaderIndex(oldData, "確認状況", 0)
    If bankCol = 0 Or codeCol = 0 Or resultCol = 0 Or statusCol = 0 Then _
        Err.Raise vbObjectError + 4303, "LoadPreservedShopValues", _
                  "旧取扱店変換一覧の見出しが不正です。入力済み内容を保護するため一覧更新を中止します。"
    For i = LBound(oldData, 1) + 1 To UBound(oldData, 1)
        bankText = CellText(oldData(i, bankCol))
        codeText = CellText(oldData(i, codeCol))
        If Len(bankText) > 0 Or Len(codeText) > 0 Then
            If Len(bankText) = 0 Or Len(codeText) = 0 Then _
                Err.Raise vbObjectError + 4304, "LoadPreservedShopValues", _
                          "旧取扱店変換一覧の銀行名またはコードが欠けています（" & CStr(i) & "行）。"
            keyText = ShopConversionKey(bankText, codeText)
            If resultByKey.Exists(keyText) Or statusByKey.Exists(keyText) Then _
                Err.Raise vbObjectError + 4305, "LoadPreservedShopValues", _
                          "旧取扱店変換一覧に同じ銀行名・コードが重複しています（" & CStr(i) & "行）。"
            resultText = CellText(oldData(i, resultCol))
            statusText = CellText(oldData(i, statusCol))
            If Len(resultText) > 100 Then _
                Err.Raise vbObjectError + 4307, "LoadPreservedShopValues", _
                          "旧取扱店変換一覧の変換後取扱店が100文字を超えています（" & CStr(i) & "行）。"
            Select Case statusText
                Case "", "未入力", "入力済", "確認不要", "保留"
                Case Else
                    Err.Raise vbObjectError + 4308, "LoadPreservedShopValues", _
                              "旧取扱店変換一覧の確認状況が不正です（" & CStr(i) & "行）: " & statusText
            End Select
            resultByKey(keyText) = resultText
            statusByKey(keyText) = statusText
        End If
    Next i
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    Err.Raise errorNumber, "LoadPreservedShopValues", errorDescription
End Sub

Private Sub UpdateShopTargetStatuses(ByVal ws As Worksheet)
    Dim lastR As Long, r As Long, dataCount As Long
    Dim currentStatus As String
    Dim sourceData As Variant, statusValues() As Variant
    If ws Is Nothing Then Exit Sub
    lastR = LastRow(ws, SHOP_TGT_COL_CODE)
    If lastR < 2 Then Exit Sub
    sourceData = ws.Range(ws.Cells(2, 1), ws.Cells(lastR, SHOP_TGT_LAST_COL)).Value2
    dataCount = UBound(sourceData, 1)
    ReDim statusValues(1 To dataCount, 1 To 1)
    For r = 1 To dataCount
        currentStatus = CellText(sourceData(r, SHOP_TGT_COL_STATUS))
        If currentStatus = "保留" Or currentStatus = "確認不要" Then
            '利用者が明示した判断は自動更新で上書きしない。
        ElseIf Len(CellText(sourceData(r, SHOP_TGT_COL_RESULT))) > 0 Then
            currentStatus = "入力済"
        ElseIf Len(CellText(sourceData(r, SHOP_TGT_COL_CODE))) > 0 Then
            currentStatus = "未入力"
        End If
        statusValues(r, 1) = currentStatus
    Next r
    ws.Range(ws.Cells(2, SHOP_TGT_COL_STATUS), _
             ws.Cells(lastR, SHOP_TGT_COL_STATUS)).NumberFormatLocal = "@"
    ws.Range(ws.Cells(2, SHOP_TGT_COL_STATUS), _
             ws.Cells(lastR, SHOP_TGT_COL_STATUS)).Value2 = statusValues
    VerifyGeneratedRangeValue2 ws, statusValues, 2, SHOP_TGT_COL_STATUS, _
                               dataCount, 1, "取扱店変換対象の確認状況", False
End Sub

Private Function OldDataHeaderIndex(ByVal oldData As Variant, ByVal headerText As String, ByVal fallbackCol As Long) As Long
    Dim j As Long
    On Error GoTo EH
    For j = LBound(oldData, 2) To UBound(oldData, 2)
        If CellText(oldData(LBound(oldData, 1), j)) = headerText Then
            OldDataHeaderIndex = j
            Exit Function
        End If
    Next j
EH:
    If fallbackCol > 0 Then
        OldDataHeaderIndex = fallbackCol
    End If
End Function

Private Function AppendRowNumber(ByVal existingText As String, ByVal rowNo As Long) As String
    Dim candidate As String
    If Len(existingText) = 0 Then
        AppendRowNumber = CStr(rowNo)
    ElseIf InStr(existingText, "以降省略") > 0 Then
        AppendRowNumber = existingText
    Else
        candidate = existingText & "," & CStr(rowNo)
        '行番号一覧は検索補助にすぎない。巨大文字列を毎回連結すると二次的に遅くなるため早めに打ち切る。
        If Len(candidate) > 1000 Then
            AppendRowNumber = existingText & ",…（以降省略）"
        Else
            AppendRowNumber = candidate
        End If
    End If
End Function

Public Function IsCodeLikeShop(ByVal valueText As String) As Boolean
    Dim s As String
    s = NormalizeShopCodeText(valueText)
    If Len(s) = 0 Then Exit Function
    If ContainsJapaneseChar(s) Then Exit Function
    If Not ContainsDigit(s) Then Exit Function
    If InStr(s, "支店") > 0 Or InStr(s, "本店") > 0 Then Exit Function
    IsCodeLikeShop = True
End Function

Public Function NormalizeShopCodeText(ByVal valueText As String) As String
    Dim s As String, i As Long, ch As String, code As Long, outText As String
    s = Trim$(CStr(valueText))
    s = Replace(s, "　", " ")
    s = Trim$(s)
    For i = 1 To Len(s)
        ch = Mid$(s, i, 1)
        code = AscW(ch)
        Select Case code
            Case &HFF10 To &HFF19
                outText = outText & ChrW$(code - &HFEE0)
            Case &HFF21 To &HFF3A
                outText = outText & ChrW$(code - &HFEE0)
            Case &HFF41 To &HFF5A
                outText = outText & UCase$(ChrW$(code - &HFEE0))
            Case &H2010, &H2011, &H2012, &H2013, &H2014, &H2212, &HFF0D
                outText = outText & "-"
            Case 32, 9
                '空白は除外
            Case Else
                outText = outText & UCase$(ch)
        End Select
    Next i
    NormalizeShopCodeText = outText
End Function

Private Function ContainsDigit(ByVal s As String) As Boolean
    Dim i As Long, code As Long
    For i = 1 To Len(s)
        code = AscW(Mid$(s, i, 1))
        If code >= 48 And code <= 57 Then ContainsDigit = True: Exit Function
    Next i
End Function

Private Function ContainsJapaneseChar(ByVal s As String) As Boolean
    Dim i As Long, code As Long
    For i = 1 To Len(s)
        code = AscW(Mid$(s, i, 1))
        If code < 0 Then code = code + 65536
        If (code >= &H3040 And code <= &H30FF) Or _
           (code >= &H3400 And code <= &H9FFF) Or _
           (code >= &HF900 And code <= &HFAFF) Or _
           (code >= &HFF66 And code <= &HFF9D) Then
            ContainsJapaneseChar = True
            Exit Function
        End If
    Next i
End Function

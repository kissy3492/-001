﻿Attribute VB_Name = "modCashAnalysisView"
Option Explicit

'資金操作表と分析結果を同じ画面に置くための利用者向けビュー。
'A:Mは常に提出用と同じ列順を守り、出金(H)と入金(I)を絶対に混在させない。
'N:Zは安定ID、絞り込み、手動選択、画面状態のための非表示列である。

Private Const VIEW_CATEGORY_TRANSFER As String = "資金移動"
Private Const VIEW_CATEGORY_UNKNOWN_WITHDRAW As String = "不明出金"
Private Const VIEW_CATEGORY_UNKNOWN_DEPOSIT As String = "不明入金"

Private Const VIEW_MODE_COMPONENT As String = "構成取引"
Private Const VIEW_MODE_RELATED As String = "関連取引"
Private Const VIEW_MODE_ALL As String = "全取引"

Private Const VIEW_ROLE_WITHDRAW As String = "出金"
Private Const VIEW_ROLE_DEPOSIT As String = "入金"
Private Const VIEW_ROLE_BOTH As String = "出金・入金"
Private Const VIEW_PERSON_DIFFERENT As String = "別人物間"
Private Const VIEW_PERSON_SAME As String = "同一人物間"

Private Const VIEW_STATE_CATEGORY As String = "V1"
Private Const VIEW_STATE_GROUP_ID As String = "V2"
Private Const VIEW_STATE_RESULT_ROW As String = "V3"
Private Const VIEW_STATE_MODE As String = "V4"
Private Const VIEW_STATE_MANUAL As String = "V5"
Private Const VIEW_STATE_SELECTED_IDS As String = "V6"
Private Const VIEW_STATE_VERSION As String = "V7"
Private Const VIEW_STATE_PANEL_EXPANDED As String = "V8"
Private Const VIEW_STATE_CANDIDATE_REF As String = "V9"
Private Const VIEW_VERSION As String = "7"
Private Const VIEW_MEMO_MAX As Long = 1000
Private Const VIEW_SELECTED_IDS_MAX As Long = 32000

'A:Mの横幅だけでなく、固定パネルと最低限の明細行が同時に見える倍率を
'現在のExcelウィンドウのポイント寸法から決める。ポイント単位で計算するため、
'Windowsの100%/125%表示を個別のDPI定数で推測しない。
Private Const VIEW_DESIGN_ZOOM As Long = 88
Private Const VIEW_MIN_ZOOM As Long = 80
Private Const VIEW_MIN_VISIBLE_DATA_ROWS As Long = 2
Private Const VIEW_DATA_ROW_HEIGHT As Double = 30#
Private Const VIEW_VERTICAL_CHROME_RESERVE_POINTS As Double = 135#

Private Type CashAnalysisViewSnapshot
    Captured As Boolean
    PanelData As Variant
    Data As Variant
    DataLastRow As Long
    Visibility As Long
    WasProtected As Boolean
    WorkCashVisibility As Long
    WorkCashWasProtected As Boolean
    ResultCaptured As Boolean
    ResultVisibility As Long
    ResultWasProtected As Boolean
    DetailCaptured As Boolean
    DetailVisibility As Long
    DetailWasProtected As Boolean
    EntryActiveSheetName As String
    EntryActiveCellAddress As String
    SelectionAddress As String
    WindowStateCaptured As Boolean
    FreezePanes As Boolean
    SplitRow As Long
    SplitColumn As Long
    ScrollRow As Long
    ScrollColumn As Long
    Zoom As Long
    WorkbookWasSaved As Boolean
End Type

Public Sub SetupCashAnalysisViewSheet(ByVal ws As Worksheet)
    Dim emptyCounts(1 To 3) As Long
    If ws Is Nothing Then Exit Sub
    ws.Unprotect Password:=TOOL_PASSWORD
    ResetWorksheet ws
    BuildCashAnalysisViewStructure ws
    SetRowValues ws.Cells(CASH_VIEW_HEADER_ROW, 1), CashAnalysisViewHeaders()
    FormatOutputHeader ws.Range(ws.Cells(CASH_VIEW_HEADER_ROW, 1), _
                                    ws.Cells(CASH_VIEW_HEADER_ROW, CASH_VIEW_LAST_COL))
    ws.Range(VIEW_STATE_CATEGORY).Value = VIEW_CATEGORY_TRANSFER
    ws.Range(VIEW_STATE_MODE).Value = VIEW_MODE_COMPONENT
    ws.Range(VIEW_STATE_MANUAL).Value = "0"
    ws.Range(VIEW_STATE_PANEL_EXPANDED).Value = "0"
    ws.Range(VIEW_STATE_CANDIDATE_REF).ClearContents
    ws.Range(VIEW_STATE_VERSION).Value = VIEW_VERSION
    FormatCashAnalysisViewLayout ws
    UpdateCategoryButtonCaptions ws, VIEW_CATEGORY_TRANSFER, emptyCounts
    ClearCashAnalysisCandidatePanel ws, VIEW_CATEGORY_TRANSFER, emptyCounts, 0, 0
    ProtectCashAnalysisViewSheet
End Sub

Public Function CashAnalysisViewHeaders() As Variant
    CashAnalysisViewHeaders = Array( _
        "銀行名", "支店名", "氏名", "科目", "口座番号", "日付", "時刻", _
        "出金", "入金", "取扱店", "機番", "摘要欄", "残高", _
        "口座ID", "取引ID", "行種別", "入力順", _
        "表示対象", "候補内役割", "手動選択")
End Function

Public Function CashAnalysisViewVersion() As String
    CashAnalysisViewVersion = VIEW_VERSION
End Function

Private Sub CaptureCashAnalysisViewSnapshot( _
        ByVal ws As Worksheet, ByRef snapshot As CashAnalysisViewSnapshot)
    Const PANEL_ROWS As Long = 9
    Dim wsWorkCash As Worksheet, wsResult As Worksheet, wsDetail As Worksheet
    Dim panelRange As Range, dataRange As Range, formulaCell As Range
    Dim dataRows As Long
    If ws Is Nothing Then _
        Err.Raise vbObjectError + 5072, "CaptureCashAnalysisViewSnapshot", _
                  "資金操作表の退避先がありません。"

    snapshot.Visibility = CLng(ws.Visible)
    snapshot.WasProtected = ws.ProtectContents
    snapshot.WorkbookWasSaved = ThisWorkbook.Saved
    Set wsWorkCash = GetSheet(SH_WORK_CASH)
    snapshot.WorkCashVisibility = CLng(wsWorkCash.Visible)
    snapshot.WorkCashWasProtected = wsWorkCash.ProtectContents
    If SheetExists(SH_ANALYSIS_RESULT) Then
        Set wsResult = GetSheet(SH_ANALYSIS_RESULT)
        snapshot.ResultVisibility = CLng(wsResult.Visible)
        snapshot.ResultWasProtected = wsResult.ProtectContents
        snapshot.ResultCaptured = True
    End If
    If SheetExists(SH_ANALYSIS_DETAIL) Then
        Set wsDetail = GetSheet(SH_ANALYSIS_DETAIL)
        snapshot.DetailVisibility = CLng(wsDetail.Visible)
        snapshot.DetailWasProtected = wsDetail.ProtectContents
        snapshot.DetailCaptured = True
    End If

    Set panelRange = ws.Range(ws.Cells(1, 1), _
                              ws.Cells(PANEL_ROWS, CASH_VIEW_INTERNAL_LAST_COL))
    If Not TryFindFirstFormulaCell(panelRange, formulaCell) Then _
        Err.Raise vbObjectError + 5073, "CaptureCashAnalysisViewSnapshot", _
                  "資金操作表のパネル数式検査に失敗しました。"
    If Not formulaCell Is Nothing Then _
        Err.Raise vbObjectError + 5073, "CaptureCashAnalysisViewSnapshot", _
                  "資金操作表のパネルまたは画面状態に数式があります。"
    snapshot.PanelData = panelRange.Value2
    If VariantMatrixContainsError( _
            snapshot.PanelData, PANEL_ROWS, CASH_VIEW_INTERNAL_LAST_COL) Or _
       Not RangeValue2MatchesMatrixStrict( _
               panelRange, snapshot.PanelData, PANEL_ROWS, _
               CASH_VIEW_INTERNAL_LAST_COL) Then _
        Err.Raise vbObjectError + 5074, "CaptureCashAnalysisViewSnapshot", _
                  "資金操作表のパネルと画面状態を型まで厳密に退避できません。"

    snapshot.DataLastRow = _
        LastDataRowInColumns(ws, 1, CASH_VIEW_INTERNAL_LAST_COL)
    If snapshot.DataLastRow < CASH_VIEW_HEADER_ROW Then _
        snapshot.DataLastRow = CASH_VIEW_HEADER_ROW
    dataRows = snapshot.DataLastRow - CASH_VIEW_HEADER_ROW + 1
    If dataRows - 1 > MAX_ANALYSIS_OUTPUT_ROWS Then _
        Err.Raise vbObjectError + 5075, "CaptureCashAnalysisViewSnapshot", _
                  "資金操作表が退避上限を超えています。"
    Set dataRange = ws.Range(ws.Cells(CASH_VIEW_HEADER_ROW, 1), _
                             ws.Cells(snapshot.DataLastRow, _
                                      CASH_VIEW_INTERNAL_LAST_COL))
    Set formulaCell = Nothing
    If Not TryFindFirstFormulaCell(dataRange, formulaCell) Then _
        Err.Raise vbObjectError + 5076, "CaptureCashAnalysisViewSnapshot", _
                  "資金操作表の一覧数式検査に失敗しました。"
    If Not formulaCell Is Nothing Then _
        Err.Raise vbObjectError + 5076, "CaptureCashAnalysisViewSnapshot", _
                  "資金操作表の一覧に数式があります。"
    snapshot.Data = dataRange.Value2
    If VariantMatrixContainsError( _
            snapshot.Data, dataRows, CASH_VIEW_INTERNAL_LAST_COL) Or _
       Not RangeValue2MatchesMatrixStrict( _
               dataRange, snapshot.Data, dataRows, _
               CASH_VIEW_INTERNAL_LAST_COL) Then _
        Err.Raise vbObjectError + 5077, "CaptureCashAnalysisViewSnapshot", _
                  "資金操作表の一覧を型まで厳密に退避できません。"

    If Not ActiveSheet Is Nothing Then
        If TypeName(ActiveSheet) = "Worksheet" Then
            snapshot.EntryActiveSheetName = ActiveSheet.Name
            If Not ActiveCell Is Nothing Then _
                snapshot.EntryActiveCellAddress = ActiveCell.Address(False, False)
            If TypeName(Selection) = "Range" Then _
                snapshot.SelectionAddress = Selection.Address(False, False)
            If Not ActiveWindow Is Nothing Then
                snapshot.FreezePanes = ActiveWindow.FreezePanes
                snapshot.SplitRow = CLng(ActiveWindow.SplitRow)
                snapshot.SplitColumn = CLng(ActiveWindow.SplitColumn)
                snapshot.ScrollRow = ActiveWindow.ScrollRow
                snapshot.ScrollColumn = ActiveWindow.ScrollColumn
                snapshot.Zoom = CLng(ActiveWindow.Zoom)
                snapshot.WindowStateCaptured = True
            End If
        End If
    End If
    snapshot.Captured = True
End Sub

Private Sub RestoreCashAnalysisViewSnapshot( _
        ByVal ws As Worksheet, ByRef snapshot As CashAnalysisViewSnapshot)
    Const PANEL_ROWS As Long = 9
    Dim dataRange As Range, panelRange As Range
    Dim dataRows As Long, currentLastRow As Long, clearLastRow As Long
    If ws Is Nothing Or Not snapshot.Captured Then _
        Err.Raise vbObjectError + 5078, "RestoreCashAnalysisViewSnapshot", _
                  "資金操作表の退避情報がありません。"

    ws.Unprotect Password:=TOOL_PASSWORD
    ResetWorksheet ws
    BuildCashAnalysisViewStructure ws
    ws.Range("A" & CStr(CASH_VIEW_HEADER_ROW) & ":E" & _
             CStr(snapshot.DataLastRow)).NumberFormatLocal = "@"
    ws.Range("J" & CStr(CASH_VIEW_HEADER_ROW) & ":L" & _
             CStr(snapshot.DataLastRow)).NumberFormatLocal = "@"
    ws.Range("N" & CStr(CASH_VIEW_HEADER_ROW) & ":Z" & _
             CStr(snapshot.DataLastRow)).NumberFormatLocal = "@"
    Set dataRange = ws.Range(ws.Cells(CASH_VIEW_HEADER_ROW, 1), _
                             ws.Cells(snapshot.DataLastRow, _
                                      CASH_VIEW_INTERNAL_LAST_COL))
    dataRange.Value2 = snapshot.Data
    RestoreCashAnalysisPanelSnapshotValues ws, snapshot.PanelData
    FormatCashAnalysisViewLayout ws

    '画面状態からフィルター・図形キャプション・入力規則を再構成する。
    RefreshCashAnalysisPanel False
    ws.Unprotect Password:=TOOL_PASSWORD
    dataRange.Value2 = snapshot.Data
    RestoreCashAnalysisPanelSnapshotValues ws, snapshot.PanelData
    AdjustCashAnalysisPanelRowHeights ws
    ApplyCashAnalysisPanelValidation ws
    UpdateCashAnalysisStatusStyle ws

    dataRows = snapshot.DataLastRow - CASH_VIEW_HEADER_ROW + 1
    If Not RangeValue2MatchesMatrixStrict( _
               dataRange, snapshot.Data, dataRows, _
               CASH_VIEW_INTERNAL_LAST_COL) Then _
        Err.Raise vbObjectError + 5079, "RestoreCashAnalysisViewSnapshot", _
                  "資金操作表の一覧を型まで厳密に復元できません。"
    Set panelRange = ws.Range(ws.Cells(1, 1), _
                              ws.Cells(PANEL_ROWS, CASH_VIEW_INTERNAL_LAST_COL))
    If Not RangeValue2MatchesMatrixStrict( _
               panelRange, snapshot.PanelData, PANEL_ROWS, _
               CASH_VIEW_INTERNAL_LAST_COL) Then _
        Err.Raise vbObjectError + 5080, "RestoreCashAnalysisViewSnapshot", _
                  "資金操作表のパネルまたは画面状態を厳密に復元できません。"
    currentLastRow = LastDataRowInColumns(ws, 1, CASH_VIEW_INTERNAL_LAST_COL)
    clearLastRow = CLng(Application.Max(currentLastRow, snapshot.DataLastRow))
    If currentLastRow <> snapshot.DataLastRow Then _
        Err.Raise vbObjectError + 5081, "RestoreCashAnalysisViewSnapshot", _
                  "資金操作表の復元行数が一致しません。"
    If clearLastRow > snapshot.DataLastRow Then _
        Err.Raise vbObjectError + 5081, "RestoreCashAnalysisViewSnapshot", _
                  "資金操作表の退避範囲外に値が残っています。"

    RestoreCashAnalysisEntryView snapshot
    RestoreCashAnalysisSnapshotSurfaces ws, snapshot
    If snapshot.WorkbookWasSaved Then ThisWorkbook.Saved = True
End Sub

Private Sub RestoreCashAnalysisPanelSnapshotValues( _
        ByVal ws As Worksheet, ByRef panelSnapshot As Variant)
    Const PANEL_ROWS As Long = 9
    Dim r As Long, c As Long
    Dim target As Range, topLeft As Range
    For r = 1 To PANEL_ROWS
        For c = 1 To CASH_VIEW_INTERNAL_LAST_COL
            Set target = ws.Cells(r, c)
            If target.MergeCells Then
                Set topLeft = target.MergeArea.Cells(1, 1)
                If target.Address = topLeft.Address Then _
                    topLeft.Value2 = panelSnapshot(r, c)
            Else
                target.Value2 = panelSnapshot(r, c)
            End If
        Next c
    Next r
End Sub

Private Sub RestoreCashAnalysisSnapshotSurfaces( _
        ByVal ws As Worksheet, ByRef snapshot As CashAnalysisViewSnapshot)
    Dim wsItem As Worksheet
    If snapshot.WasProtected Then
        ProtectCashAnalysisViewSheet
    Else
        ws.Unprotect Password:=TOOL_PASSWORD
    End If
    ws.Visible = snapshot.Visibility
    If ws.ProtectContents <> snapshot.WasProtected Or _
       CLng(ws.Visible) <> snapshot.Visibility Then _
        Err.Raise vbObjectError + 5082, "RestoreCashAnalysisSnapshotSurfaces", _
                  "資金操作表の保護または表示状態を復元できません。"

    Set wsItem = GetSheet(SH_WORK_CASH)
    RestoreCashAnalysisOneSurface wsItem, snapshot.WorkCashVisibility, _
                                  snapshot.WorkCashWasProtected, False
    If snapshot.ResultCaptured Then
        Set wsItem = GetSheet(SH_ANALYSIS_RESULT)
        RestoreCashAnalysisOneSurface wsItem, snapshot.ResultVisibility, _
                                      snapshot.ResultWasProtected, True
    End If
    If snapshot.DetailCaptured Then
        Set wsItem = GetSheet(SH_ANALYSIS_DETAIL)
        RestoreCashAnalysisOneSurface wsItem, snapshot.DetailVisibility, _
                                      snapshot.DetailWasProtected, True
    End If
End Sub

Private Sub RestoreCashAnalysisOneSurface( _
        ByVal ws As Worksheet, ByVal visibilityState As Long, _
        ByVal protectedState As Boolean, ByVal analysisSheet As Boolean)
    If ws Is Nothing Then _
        Err.Raise vbObjectError + 5083, "RestoreCashAnalysisOneSurface", _
                  "表示・保護を復元するシートがありません。"
    If protectedState Then
        If analysisSheet Then
            ProtectSingleAnalysisSheet ws
        Else
            ProtectGeneratedOutputSheet ws, True
        End If
    Else
        ws.Unprotect Password:=TOOL_PASSWORD
    End If
    ws.Visible = visibilityState
    If ws.ProtectContents <> protectedState Or _
       CLng(ws.Visible) <> visibilityState Then _
        Err.Raise vbObjectError + 5084, "RestoreCashAnalysisOneSurface", _
                  "表示または保護状態を復元できません: " & ws.Name
End Sub

Private Sub RestoreCashAnalysisEntryView( _
        ByRef snapshot As CashAnalysisViewSnapshot)
    Dim ws As Worksheet
    If Len(snapshot.EntryActiveSheetName) = 0 Then Exit Sub
    If Not SheetExists(snapshot.EntryActiveSheetName) Then _
        Err.Raise vbObjectError + 5085, "RestoreCashAnalysisEntryView", _
                  "操作開始時のシートが見つかりません。"
    Set ws = GetSheet(snapshot.EntryActiveSheetName)
    If ws.Visible <> xlSheetVisible Then ws.Visible = xlSheetVisible
    If ws.Visible <> xlSheetVisible Then _
        Err.Raise vbObjectError + 5086, "RestoreCashAnalysisEntryView", _
                  "操作開始時のシートが表示状態ではありません。"
    ws.Activate
    RestoreWorkbookViewPosition ws, snapshot.WindowStateCaptured, _
        snapshot.FreezePanes, snapshot.SplitRow, snapshot.SplitColumn, _
        snapshot.ScrollRow, snapshot.ScrollColumn, snapshot.Zoom, _
        snapshot.SelectionAddress, snapshot.EntryActiveCellAddress
    If Not ActiveWorkbook Is ThisWorkbook Or Not ActiveSheet Is ws Then _
        Err.Raise vbObjectError + 5090, "RestoreCashAnalysisEntryView", _
                  "操作開始時のアクティブシートを復元できません。"
End Sub

Private Sub AppendCashAnalysisRollbackDetail( _
        ByRef detailText As String, ByVal addedText As String)
    If Len(Trim$(addedText)) = 0 Then Exit Sub
    If Len(detailText) > 0 Then detailText = detailText & " / "
    detailText = detailText & addedText
End Sub

Private Function TryGetCashAnalysisEnableEvents( _
        ByRef currentValue As Boolean, _
        ByRef detailText As String) As Boolean
    Dim errorNumber As Long, errorSource As String, errorDescription As String
    detailText = vbNullString
    On Error GoTo EH
    currentValue = Application.EnableEvents
    TryGetCashAnalysisEnableEvents = True
    Exit Function
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    detailText = "Err " & CStr(errorNumber) & ": " & errorDescription
    Err.Clear
End Function

Private Function TrySetCashAnalysisEnableEventsExact( _
        ByVal desiredValue As Boolean, _
        ByRef detailText As String) As Boolean
    Dim errorNumber As Long, errorSource As String, errorDescription As String
    detailText = vbNullString
    On Error GoTo EH
    Application.EnableEvents = desiredValue
    If Application.EnableEvents <> desiredValue Then _
        Err.Raise vbObjectError + 5094, _
                  "TrySetCashAnalysisEnableEventsExact", _
                  "EnableEventsの書込み後読戻しが一致しません。"
    TrySetCashAnalysisEnableEventsExact = True
    Exit Function
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    detailText = "Err " & CStr(errorNumber) & ": " & errorDescription
    Err.Clear
End Function

Private Function TryRestoreCashAnalysisEnableEvents( _
        ByVal previousValue As Boolean, _
        ByVal operationName As String, _
        ByRef detailText As String) As Boolean
    Dim firstDetail As String, retryDetail As String
    Dim stopDetail As String, stopRetryDetail As String
    Dim safeStopDetail As String
    Dim eventsStoppedForRecovery As Boolean
    Dim recoveryEnforcementFailed As Boolean
    Dim recoveryConfirmedThisAttempt As Boolean
    Dim recoveryAttempted As Boolean
    detailText = vbNullString
    If TrySetCashAnalysisEnableEventsExact(previousValue, firstDetail) Then
        TryRestoreCashAnalysisEnableEvents = True
        Exit Function
    End If
    If TrySetCashAnalysisEnableEventsExact(previousValue, retryDetail) Then
        TryRestoreCashAnalysisEnableEvents = True
        Exit Function
    End If
    detailText = "Excelイベント状態を開始値へ復元できませんでした。初回=" & _
                 firstDetail & " / 再試行=" & retryDetail
    eventsStoppedForRecovery = _
        TrySetCashAnalysisEnableEventsExact(False, stopDetail)
    If Not eventsStoppedForRecovery Then _
        eventsStoppedForRecovery = _
            TrySetCashAnalysisEnableEventsExact(False, stopRetryDetail)
    StopAfterCashAnalysisEventStateFailure _
        operationName, detailText, eventsStoppedForRecovery, True, _
        "初回=" & stopDetail & " / 再試行=" & stopRetryDetail, _
        recoveryEnforcementFailed, recoveryConfirmedThisAttempt, _
        recoveryAttempted
    If recoveryAttempted Then _
        Err.Raise vbObjectError + 5194, _
                  "CashAnalysisRecoveryFatal/TryRestoreCashAnalysisEnableEvents", _
                  detailText
    eventsStoppedForRecovery = _
        TryStopCashAnalysisEventsForRecovery(safeStopDetail)
End Function

Private Sub StopAfterCashAnalysisEventStateFailure( _
        ByVal operationName As String, _
        ByRef detailText As String, _
        ByRef eventsStoppedForRecovery As Boolean, _
        ByVal stopGateAlreadyAttempted As Boolean, _
        ByVal attemptedStopDetail As String, _
        Optional ByRef recoveryEnforcementFailed As Boolean = False, _
        Optional ByRef recoveryConfirmedThisAttempt As Boolean = False, _
        Optional ByRef recoveryAttempted As Boolean = False)
    Dim recoveryDetail As String, stopDetail As String
    Dim postEnforceStopDetail As String, finalStopDetail As String
    Dim recoveryErrorNumber As Long, recoveryErrorDescription As String
    Dim recoveryConfirmed As Boolean
    Dim applicationStateConfirmed As Boolean
    If recoveryAttempted Then
        eventsStoppedForRecovery = _
            TryStopCashAnalysisEventsForRecovery(finalStopDetail)
        AppendCashAnalysisRollbackDetail detailText, _
            "この上位処理ではRecovery設定を既に試行済みのため、" & _
            "二重実行を行いません。"
        Err.Raise vbObjectError + 5194, _
                  "CashAnalysisRecoveryFatal/StopAfterCashAnalysisEventStateFailure", _
                  detailText
    End If
    recoveryEnforcementFailed = False
    recoveryConfirmedThisAttempt = False
    recoveryDetail = operationName & ": " & detailText
    If stopGateAlreadyAttempted Then
        stopDetail = attemptedStopDetail
    Else
        eventsStoppedForRecovery = _
            TryStopCashAnalysisEventsForRecovery(stopDetail)
    End If
    If Not eventsStoppedForRecovery Then
        AppendCashAnalysisRollbackDetail recoveryDetail, _
            "要復旧記録前にExcelイベント停止を確認できず、" & _
            "ブックへのRecovery・チェック・状態書込みを" & _
            "安全のため見送りました。現在のイベント状態は不明です: " & _
            stopDetail
        detailText = recoveryDetail
        Exit Sub
    End If
    AppendCashAnalysisRollbackDetail recoveryDetail, _
        "要復旧記録前にExcelイベント停止を読戻し確認しました。"
    recoveryAttempted = True
    On Error Resume Next
    Err.Clear
    EnforceRollbackRecoveryState recoveryDetail
    recoveryErrorNumber = Err.Number
    recoveryErrorDescription = Err.Description
    Err.Clear
    On Error GoTo 0
    eventsStoppedForRecovery = _
        TryStopCashAnalysisEventsForRecovery(postEnforceStopDetail)
    If recoveryErrorNumber <> 0 Then
        recoveryEnforcementFailed = True
        AppendCashAnalysisRollbackDetail recoveryDetail, _
            "要復旧状態の強制設定エラー: Err " & _
            CStr(recoveryErrorNumber) & " " & recoveryErrorDescription
        AppendCashAnalysisRollbackDetail recoveryDetail, _
            "Recovery強制設定でエラーを検出したため、" & _
            "復旧状態の照合・チェック・状態書込みを行いませんでした。"
        If Not eventsStoppedForRecovery Then _
            AppendCashAnalysisRollbackDetail recoveryDetail, _
                "Recovery強制設定後のExcelイベント停止も確認できず、" & _
                "現在状態は不明です: " & postEnforceStopDetail
        eventsStoppedForRecovery = False
        detailText = recoveryDetail
        Err.Raise vbObjectError + 5194, _
                  "CashAnalysisRecoveryFatal/StopAfterCashAnalysisEventStateFailure", _
                  detailText
    End If
    If Not eventsStoppedForRecovery Then
        AppendCashAnalysisRollbackDetail recoveryDetail, _
            "Recovery強制設定後にExcelイベント停止を確認できず、" & _
            "復旧状態の照合・チェック・状態書込みを行いませんでした。" & _
            "現在状態は不明です: " & postEnforceStopDetail
        detailText = recoveryDetail
        Err.Raise vbObjectError + 5194, _
                  "CashAnalysisRecoveryFatal/StopAfterCashAnalysisEventStateFailure", _
                  detailText
    End If
    recoveryConfirmed = _
        CashAnalysisRecoveryStateIsConfirmedExact(recoveryDetail)
    recoveryConfirmedThisAttempt = recoveryConfirmed
    If Not recoveryConfirmed Then
        AppendCashAnalysisRollbackDetail recoveryDetail, _
            "要復旧状態を厳密確認できません。"
        eventsStoppedForRecovery = _
            TryStopCashAnalysisEventsForRecovery(finalStopDetail)
        eventsStoppedForRecovery = False
        detailText = recoveryDetail
        Err.Raise vbObjectError + 5194, _
                  "CashAnalysisRecoveryFatal/StopAfterCashAnalysisEventStateFailure", _
                  detailText
    End If
    applicationStateConfirmed = _
        CashAnalysisApplicationStateAllowsEntryRestore( _
            True, recoveryDetail)
    If Not applicationStateConfirmed Then
        eventsStoppedForRecovery = _
            TryStopCashAnalysisEventsForRecovery(finalStopDetail)
        AppendCashAnalysisRollbackDetail recoveryDetail, _
            "Application状態を確認できません。"
        detailText = recoveryDetail
        Err.Raise vbObjectError + 5194, _
                  "CashAnalysisRecoveryFatal/StopAfterCashAnalysisEventStateFailure", _
                  detailText
    End If
    eventsStoppedForRecovery = _
        TryStopCashAnalysisEventsForRecovery(finalStopDetail)
    If Not eventsStoppedForRecovery Then
        AppendCashAnalysisRollbackDetail recoveryDetail, _
            "Application状態確認後のExcelイベントFalse収束を" & _
            "確認できません。現在状態は不明です: " & finalStopDetail
        detailText = recoveryDetail
        Err.Raise vbObjectError + 5194, _
                  "CashAnalysisRecoveryFatal/StopAfterCashAnalysisEventStateFailure", _
                  detailText
    End If
    detailText = recoveryDetail
    Err.Raise vbObjectError + 5194, _
              "CashAnalysisRecoveryFatal/StopAfterCashAnalysisEventStateFailure", _
              detailText
End Sub

Private Function TryStopCashAnalysisEventsForRecovery( _
        ByRef detailText As String) As Boolean
    Dim firstDetail As String, retryDetail As String
    detailText = vbNullString
    If TrySetCashAnalysisEnableEventsExact(False, firstDetail) Then
        TryStopCashAnalysisEventsForRecovery = True
        Exit Function
    End If
    If TrySetCashAnalysisEnableEventsExact(False, retryDetail) Then
        TryStopCashAnalysisEventsForRecovery = True
        Exit Function
    End If
    detailText = "初回=" & firstDetail & " / 再試行=" & retryDetail
End Function

Private Function CashAnalysisRecoveryStateIsConfirmedExact( _
        ByRef detailText As String) As Boolean
    Dim latchIsSet As Boolean, latchReadSucceeded As Boolean
    Dim healthValue As String, healthReadSucceeded As Boolean
    latchReadSucceeded = TryGetRollbackRecoveryLatch(latchIsSet)
    healthReadSucceeded = _
        TryGetExactStateValue(STATE_DATA_HEALTH, healthValue)
    CashAnalysisRecoveryStateIsConfirmedExact = _
        latchReadSucceeded And latchIsSet And healthReadSucceeded And _
        (StrComp(healthValue, DATA_HEALTH_NEEDS_RECOVERY, _
                 vbBinaryCompare) = 0)
    If CashAnalysisRecoveryStateIsConfirmedExact Then Exit Function
    If Not latchReadSucceeded Or Not latchIsSet Then _
        AppendCashAnalysisRollbackDetail detailText, _
            "独立復旧ラッチを設定済みとして一意に確認できません。"
    If Not healthReadSucceeded Or _
       StrComp(healthValue, DATA_HEALTH_NEEDS_RECOVERY, _
               vbBinaryCompare) <> 0 Then _
        AppendCashAnalysisRollbackDetail detailText, _
            "案件のhealth=要復旧を一意に確認できません。"
End Function

Private Function TryProtectCashAnalysisViewAfterFailure( _
        ByVal ws As Worksheet, _
        ByVal operationName As String, _
        ByVal emergencyOnly As Boolean, _
        ByRef detailText As String, _
        Optional ByRef recoveryAttempted As Boolean = False, _
        Optional ByRef recoveryEnforcementFailed As Boolean = False, _
        Optional ByRef recoveryConfirmedThisAttempt As Boolean = False) As Boolean
    Dim protectErrorNumber As Long, recoveryErrorNumber As Long
    Dim protectErrorSource As String
    Dim protectErrorDescription As String, recoveryErrorDescription As String
    Dim recoveryDetail As String, protectionLabel As String
    Dim entryEvents As Boolean, eventsCaptured As Boolean
    Dim eventsReady As Boolean, protectSucceeded As Boolean
    Dim recoveryConfirmed As Boolean, safeToRestoreEntry As Boolean
    Dim eventDetail As String, restoreDetail As String
    Dim postProtectStopDetail As String, postEnforceStopDetail As String
    Dim convergenceDetail As String, policyDetail As String
    Dim finalRecoveryStopDetail As String

    If recoveryAttempted Then
        eventsReady = _
            TryStopCashAnalysisEventsForRecovery(convergenceDetail)
        AppendCashAnalysisRollbackDetail detailText, _
            operationName & ": この上位処理ではRecovery設定を既に" & _
            "試行済みのため、二重実行を行いません。"
        Err.Raise vbObjectError + 5194, _
                  "CashAnalysisRecoveryFatal/TryProtectCashAnalysisViewAfterFailure", _
                  detailText
    End If
    recoveryEnforcementFailed = False
    recoveryConfirmedThisAttempt = False

    If Not TryGetCashAnalysisEnableEvents(entryEvents, eventDetail) Then
        AppendCashAnalysisRollbackDetail detailText, _
            operationName & ": Excelイベントの開始状態を取得できず、" & _
            "再保護とRecovery書込みを行いませんでした。 " & eventDetail
        Exit Function
    End If
    eventsCaptured = True
    eventsReady = TryStopCashAnalysisEventsForRecovery(eventDetail)
    If Not eventsReady Then
        AppendCashAnalysisRollbackDetail detailText, _
            operationName & ": Excelイベント停止を確認できず、" & _
            "再保護とRecovery書込みを行いませんでした。 " & eventDetail
        GoTo CleanExit
    End If
    If emergencyOnly Then
        protectionLabel = "緊急再保護"
    Else
        protectionLabel = "再保護"
    End If
    If ws Is Nothing Then
        On Error Resume Next
        Err.Clear
        Set ws = GetSheet(SH_OUTPUT_TX)
        protectErrorNumber = Err.Number
        protectErrorSource = Err.Source
        protectErrorDescription = Err.Description
        Err.Clear
        On Error GoTo 0
        If ws Is Nothing And protectErrorNumber = 0 Then
            protectErrorNumber = vbObjectError + 5105
            protectErrorDescription = "資金操作表を取得できません。"
        End If
    End If
    If protectErrorNumber = 0 Then
        On Error Resume Next
        Err.Clear
        If emergencyOnly Then
            EmergencyProtectToolSheet ws
        Else
            ProtectCashAnalysisViewSheet
        End If
        protectErrorNumber = Err.Number
        protectErrorSource = Err.Source
        protectErrorDescription = Err.Description
        Err.Clear
        On Error GoTo 0
    End If
    '入れ子の保護処理がterminalを返した場合、元のErr tripleを変更せず、
    'freshなFalse exactだけを試して直ちに上位へ伝播する。
    If IsCashAnalysisRecoveryFatal( _
           protectErrorNumber, protectErrorSource) Then
        Call TryStopCashAnalysisEventsForRecovery(convergenceDetail)
        Err.Raise protectErrorNumber, protectErrorSource, _
                  protectErrorDescription
    End If
    eventsReady = _
        TryStopCashAnalysisEventsForRecovery(postProtectStopDetail)
    If Not eventsReady Then
        AppendCashAnalysisRollbackDetail detailText, _
            operationName & ": 再保護後のExcelイベント停止を確認できません。" & _
            "現在状態は不明です: " & postProtectStopDetail
        GoTo CleanExit
    End If
    policyDetail = vbNullString
    protectSucceeded = _
        CashAnalysisProtectionPolicyIsConfirmedExact(ws, policyDetail)
    If Not protectSucceeded Then _
        AppendCashAnalysisRollbackDetail detailText, _
            operationName & ": 再保護後の実保護ポリシーを確認できません。 " & _
            policyDetail
    If protectErrorNumber <> 0 Then _
        AppendCashAnalysisRollbackDetail detailText, _
            operationName & "の" & protectionLabel & "エラー: Err " & _
            CStr(protectErrorNumber) & " " & protectErrorDescription
    If protectSucceeded Then
        protectSucceeded = True
        safeToRestoreEntry = _
            CashAnalysisApplicationStateAllowsEntryRestore( _
                entryEvents, detailText)
        TryProtectCashAnalysisViewAfterFailure = True
        GoTo CleanExit
    End If

    recoveryDetail = detailText
    recoveryAttempted = True
    On Error Resume Next
    Err.Clear
    EnforceRollbackRecoveryState recoveryDetail
    recoveryErrorNumber = Err.Number
    recoveryErrorDescription = Err.Description
    Err.Clear
    On Error GoTo 0
    'Enforceの例外値を保存した直後にFalseを再確定する。例外終了なら、
    '以前から残るRecovery値を今回成功の根拠には一切使わない。
    eventsReady = _
        TryStopCashAnalysisEventsForRecovery(postEnforceStopDetail)
    detailText = recoveryDetail
    If recoveryErrorNumber <> 0 Then _
        AppendCashAnalysisRollbackDetail detailText, _
            "要復旧状態の強制設定エラー: Err " & _
            CStr(recoveryErrorNumber) & " " & recoveryErrorDescription
    If recoveryErrorNumber <> 0 Then
        recoveryEnforcementFailed = True
        AppendCashAnalysisRollbackDetail detailText, _
            "Recovery処理が例外終了したため、復旧状態を読み取らず、" & _
            "開始時イベント値へも戻しません。"
        safeToRestoreEntry = False
    ElseIf eventsReady Then
        recoveryConfirmed = _
            CashAnalysisRecoveryStateIsConfirmedExact(detailText)
        recoveryConfirmedThisAttempt = recoveryConfirmed
        If Not recoveryConfirmed Then _
            AppendCashAnalysisRollbackDetail detailText, _
                "要復旧としての停止完了は確認できません。"
    Else
        AppendCashAnalysisRollbackDetail detailText, _
            "Recovery処理後にExcelイベント停止を確認できないため、" & _
            "復旧状態を読み取りませんでした。現在状態は不明です: " & _
            postEnforceStopDetail
    End If
    If recoveryErrorNumber = 0 And eventsReady And recoveryConfirmed Then
        safeToRestoreEntry = _
            CashAnalysisApplicationStateAllowsEntryRestore( _
                True, detailText)
        If safeToRestoreEntry Then
            eventsReady = _
                TryStopCashAnalysisEventsForRecovery( _
                    finalRecoveryStopDetail)
            If Not eventsReady Then _
                AppendCashAnalysisRollbackDetail detailText, _
                    "Application状態確認後のExcelイベントFalse収束を" & _
                    "確認できません: " & finalRecoveryStopDetail
        End If
        safeToRestoreEntry = False
    End If
    eventsReady = _
        TryStopCashAnalysisEventsForRecovery(convergenceDetail)
    Err.Raise vbObjectError + 5194, _
              "CashAnalysisRecoveryFatal/TryProtectCashAnalysisViewAfterFailure", _
              detailText
CleanExit:
    If eventsCaptured Then
        If safeToRestoreEntry Then
            eventsReady = _
                TryStopCashAnalysisEventsForRecovery(convergenceDetail)
            safeToRestoreEntry = eventsReady
            If safeToRestoreEntry Then
                If Not TryRestoreCashAnalysisEnableEvents( _
                           entryEvents, operationName & "/再保護", _
                           restoreDetail) Then
                    protectSucceeded = False
                    safeToRestoreEntry = False
                    AppendCashAnalysisRollbackDetail detailText, restoreDetail
                End If
            End If
        End If
        If Not safeToRestoreEntry Then
            eventsReady = _
                TryStopCashAnalysisEventsForRecovery(convergenceDetail)
        End If
        If Not safeToRestoreEntry And eventsReady Then
            AppendCashAnalysisRollbackDetail detailText, _
                operationName & ": 保護またはRecoveryを厳密確認できないため、" & _
                "開始時イベント値へ戻さずFalseで停止しました。"
        ElseIf Not safeToRestoreEntry Then
            AppendCashAnalysisRollbackDetail detailText, _
                operationName & ": 保護またはRecoveryを厳密確認できず、" & _
                "ExcelイベントのFalse収束にも失敗しました。現在状態は不明です: " & _
                convergenceDetail
        End If
    End If
    TryProtectCashAnalysisViewAfterFailure = protectSucceeded
End Function

Private Function CashAnalysisOuterLeaseMayRestoreAfterProtection( _
        ByVal protectOK As Boolean, _
        ByRef detailText As String) As Boolean
    Dim eventDetail As String, appStateProblems As String
    'TryProtectCashAnalysisViewAfterFailureは内部でRecoveryと独自leaseを扱う。
    '外側callerは古いeventsReadyを再利用せず、False exactを取り直した後に
    '再保護成功またはRecovery二重状態のどちらかを厳密確認する。
    If Not TryStopCashAnalysisEventsForRecovery(eventDetail) Then
        AppendCashAnalysisRollbackDetail detailText, _
            "再保護処理後にExcelイベント停止を確認できず、" & _
            "開始時イベント値へ戻せません。現在状態は不明です: " & _
            eventDetail
        Exit Function
    End If
    If protectOK Then
        If AppStateIsRestored(appStateProblems) Then
            CashAnalysisOuterLeaseMayRestoreAfterProtection = True
        Else
            AppendCashAnalysisRollbackDetail detailText, _
                "再保護後のApplication状態を安全に復元済みと確認できません: " & _
                appStateProblems
        End If
    Else
        'TryProtect内のEnforceが例外終了した可能性を外側から区別できないため、
        '既存のRecovery値を再利用せずFalseのまま返す。
        AppendCashAnalysisRollbackDetail detailText, _
            "今回の再保護成功を確認できないため、既存Recovery値を" & _
            "開始時イベント復元の根拠には使いません。"
    End If
End Function

Private Function CashAnalysisProtectionPolicyIsConfirmedExact( _
        ByVal ws As Worksheet, _
        ByRef detailText As String) As Boolean
    Dim errorNumber As Long, errorSource As String, errorDescription As String
    If ws Is Nothing Then
        detailText = "資金操作表を取得できません。"
        Exit Function
    End If
    On Error GoTo EH
    If Not ws.ProtectContents Or Not ws.ProtectDrawingObjects Then _
        Err.Raise vbObjectError + 5193, _
                  "CashAnalysisProtectionPolicyIsConfirmedExact", _
                  "セル保護または図形保護を読み戻せません。"
    If ws.EnableSelection <> xlNoRestrictions Then _
        Err.Raise vbObjectError + 5193, _
                  "CashAnalysisProtectionPolicyIsConfirmedExact", _
                  "選択ポリシーをxlNoRestrictionsとして読み戻せません。"
    VerifyToolShapeSecurity ws, True, False
    CashAnalysisProtectionPolicyIsConfirmedExact = True
    Exit Function
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    detailText = "Err " & CStr(errorNumber) & " " & errorDescription
    Err.Clear
End Function

Private Function CashAnalysisApplicationStateAllowsEntryRestore( _
        ByVal entryEvents As Boolean, _
        ByRef detailText As String) As Boolean
    Dim appStateProblems As String
    If Not entryEvents Then
        CashAnalysisApplicationStateAllowsEntryRestore = True
        Exit Function
    End If
    If AppStateIsRestored(appStateProblems) Then
        CashAnalysisApplicationStateAllowsEntryRestore = True
    Else
        AppendCashAnalysisRollbackDetail detailText, _
            "Application状態を安全に復元済みと確認できません: " & _
            appStateProblems
    End If
End Function

Private Function IsCashAnalysisRecoveryFatal( _
        ByVal errorNumber As Long, ByVal errorSource As String) As Boolean
    Dim expectedSource As String
    Select Case errorNumber
        Case vbObjectError + 3599, vbObjectError + 4499
            IsCashAnalysisRecoveryFatal = True
            Exit Function
        Case vbObjectError + 5191
            expectedSource = "AnalysisWorkspaceRecoveryFatal/"
        Case vbObjectError + 5192
            expectedSource = "SetupConvergeRecoveryFatal/"
        Case vbObjectError + 5194
            expectedSource = "CashAnalysisRecoveryFatal/"
        Case vbObjectError + 5195
            expectedSource = "TransactionAnalysisRecoveryFatal/"
        Case vbObjectError + 5196
            expectedSource = "CashManualSelectionRecoveryFatal/"
        Case vbObjectError + 5197
            expectedSource = "ClearRecoveryFatal/"
        Case Else
            Exit Function
    End Select
    If Len(errorSource) < Len(expectedSource) Then Exit Function
    IsCashAnalysisRecoveryFatal = _
        (StrComp(Left$(errorSource, Len(expectedSource)), expectedSource, _
                 vbBinaryCompare) = 0)
End Function

Public Sub BuildCashAnalysisViewCore(ByVal activateAfter As Boolean, _
                                     Optional ByVal syncCurrentReview As Boolean = True, _
                                     Optional ByVal capacityConfirmed As Boolean = False)
    Dim ws As Worksheet, wsSource As Worksheet
    Dim sourceLastRow As Long, outputLastRow As Long
    Dim sourceData As Variant
    Dim keepCategory As String, keepGroupID As String, keepMode As String
    Dim keepManual As String, keepSelected As String, keepCandidateRef As String
    Dim workbookWasSaved As Boolean
    Dim viewSnapshot As CashAnalysisViewSnapshot
    Dim viewMutationStarted As Boolean, rollbackOK As Boolean
    Dim eventsReadyForRecovery As Boolean
    Dim recoveryConfirmed As Boolean, applicationStateConfirmed As Boolean
    Dim recoveryErrorNumber As Long, recoveryErrorDescription As String
    Dim rollbackErrorNumber As Long, rollbackErrorSource As String
    Dim rollbackErrorDescription As String
    Dim errorNumber As Long, errorSource As String
    Dim errorDescription As String, rollbackDetail As String
    Dim convergenceDetail As String, postEnforceStopDetail As String
    Dim finalRecoveryStopDetail As String

    On Error GoTo EH
    'CashOperation容量は、W_取引・予定資金表に加えて複数の並べ替え配列を
    '合算しており、ここで行う最大17列の元表→表示表転送（元表＋出力行）を包含する。
    If Not capacityConfirmed Then
        If Not RequireOutputBuildCapacity("資金操作表の表示再構築", True, False, _
                                          False, False, False, False) Then Err.Raise 18
        capacityConfirmed = True
    End If
    If Not SheetExists(SH_OUTPUT_TX) Or Not SheetExists(SH_WORK_CASH) Then Exit Sub
    Set ws = GetSheet(SH_OUTPUT_TX)
    Set wsSource = GetSheet(SH_WORK_CASH)
    CaptureCashAnalysisViewSnapshot ws, viewSnapshot
    '分析結果を今まさに再構築した呼出元は、再分析前に旧候補の判断を同期済み。
    '再構築後に消滅した旧groupIDを新結果へ再同期せず、新しい候補表示へ収束させる。
    If syncCurrentReview Then
        'Cashパネルが現在の編集面である時だけ、その現値を権威として同期する。
        '候補詳細を編集中の直接マクロ実行で、非表示側の旧Cash値を後勝ちさせない。
        If Not ActiveSheet Is Nothing Then
            If ActiveSheet.Name = SH_OUTPUT_TX Then _
                SyncCashAnalysisPanelReviewToWorkspace
        End If
    End If
    '確認同期が正当な永続変更を行った場合、そのdirty状態をビュー復元で消さない。
    viewSnapshot.WorkbookWasSaved = ThisWorkbook.Saved
    workbookWasSaved = ThisWorkbook.Saved

    If Len(CellText(ws.Range(VIEW_STATE_VERSION).Value)) > 0 Then
        keepCategory = CellText(ws.Range(VIEW_STATE_CATEGORY).Value)
        keepGroupID = CellText(ws.Range(VIEW_STATE_GROUP_ID).Value)
        keepMode = CellText(ws.Range(VIEW_STATE_MODE).Value)
        keepManual = CellText(ws.Range(VIEW_STATE_MANUAL).Value)
        keepSelected = CellText(ws.Range(VIEW_STATE_SELECTED_IDS).Value)
        keepCandidateRef = CellText(ws.Range(VIEW_STATE_CANDIDATE_REF).Value)
    End If
    If Not IsCashViewCategory(keepCategory) Then keepCategory = VIEW_CATEGORY_TRANSFER
    If Not IsCashViewMode(keepMode) Then keepMode = VIEW_MODE_COMPONENT
    If keepManual <> "1" Then keepManual = "0"

    viewMutationStarted = True
    ws.Unprotect Password:=TOOL_PASSWORD
    ResetWorksheet ws
    BuildCashAnalysisViewStructure ws
    SetRowValues ws.Cells(CASH_VIEW_HEADER_ROW, 1), CashAnalysisViewHeaders()

    sourceLastRow = LastUsedRowInSheet(wsSource)
    If sourceLastRow >= 2 Then
        outputLastRow = CASH_VIEW_FIRST_DATA_ROW + sourceLastRow - 2
        sourceData = wsSource.Range( _
            wsSource.Cells(2, 1), _
            wsSource.Cells(sourceLastRow, OUT_INTERNAL_LAST_COL)).Value2
        '銀行名・口座番号・摘要・内部ID等を値より先に文字列書式へ固定し、
        '「=」等で始まる銀行帳票文字列を数式として解釈させない。
        ws.Range("A" & CStr(CASH_VIEW_FIRST_DATA_ROW) & ":E" & _
                 CStr(outputLastRow)).NumberFormatLocal = "@"
        ws.Range("J" & CStr(CASH_VIEW_FIRST_DATA_ROW) & ":L" & _
                 CStr(outputLastRow)).NumberFormatLocal = "@"
        ws.Range("N" & CStr(CASH_VIEW_FIRST_DATA_ROW) & ":Q" & _
                 CStr(outputLastRow)).NumberFormatLocal = "@"
        ws.Range(ws.Cells(CASH_VIEW_FIRST_DATA_ROW, 1), _
                 ws.Cells(outputLastRow, OUT_INTERNAL_LAST_COL)).Value2 = sourceData
    End If

    ws.Range(VIEW_STATE_CATEGORY).Value = keepCategory
    ws.Range(VIEW_STATE_GROUP_ID).Value = keepGroupID
    ws.Range(VIEW_STATE_MODE).Value = keepMode
    ws.Range(VIEW_STATE_MANUAL).Value = keepManual
    ws.Range(VIEW_STATE_SELECTED_IDS).Value = keepSelected
    ws.Range(VIEW_STATE_PANEL_EXPANDED).Value = "0"
    ws.Range(VIEW_STATE_CANDIDATE_REF).Value = keepCandidateRef
    ws.Range(VIEW_STATE_VERSION).Value = VIEW_VERSION
    FormatCashAnalysisViewLayout ws
    RefreshCashAnalysisPanel False
    If sourceLastRow >= 2 Then _
        VerifyGeneratedRangeValue2 ws, sourceData, CASH_VIEW_FIRST_DATA_ROW, 1, _
                                   sourceLastRow - 1, OUT_INTERNAL_LAST_COL, _
                                   "資金操作表の正式表示", True
    ProtectCashAnalysisViewSheet
    SetSheetVeryHiddenSafe wsSource
    If SheetExists(SH_ANALYSIS_RESULT) Then SetSheetVeryHiddenSafe GetSheet(SH_ANALYSIS_RESULT)
    If SheetExists(SH_ANALYSIS_DETAIL) Then SetSheetVeryHiddenSafe GetSheet(SH_ANALYSIS_DETAIL)

    'FreezePanes・Zoom等はウィンドウ固有の表示状態で、生成済みデータの成否ではない。
    'ここで失敗して正常な分析結果をrollbackしない。次回表示時にも再適用される。
    If activateAfter Then
        On Error Resume Next
        ApplyCashAnalysisViewWindowStyle True
        Err.Clear
        On Error GoTo EH
    End If
    If workbookWasSaved Then ThisWorkbook.Saved = True
    Exit Sub
EH:
    errorNumber = Err.Number
    errorSource = Err.Source
    errorDescription = Err.Description
    If IsCashAnalysisRecoveryFatal(errorNumber, errorSource) Then
        Call TryStopCashAnalysisEventsForRecovery(convergenceDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    On Error Resume Next
    Err.Clear
    rollbackOK = True
    If viewMutationStarted And viewSnapshot.Captured Then
        RestoreCashAnalysisViewSnapshot ws, viewSnapshot
        rollbackErrorNumber = Err.Number
        rollbackErrorSource = Err.Source
        rollbackErrorDescription = Err.Description
        Err.Clear
        If IsCashAnalysisRecoveryFatal( _
               rollbackErrorNumber, rollbackErrorSource) Then
            On Error GoTo 0
            Call TryStopCashAnalysisEventsForRecovery(convergenceDetail)
            Err.Raise rollbackErrorNumber, rollbackErrorSource, _
                      rollbackErrorDescription
        End If
        If rollbackErrorNumber <> 0 Then
            rollbackOK = False
            AppendCashAnalysisRollbackDetail rollbackDetail, _
                "資金操作表の復元エラー: " & rollbackErrorDescription
        End If
    End If
    Err.Clear
    If Not rollbackOK Then
        Err.Clear
        EnforceRollbackRecoveryState rollbackDetail
        recoveryErrorNumber = Err.Number
        recoveryErrorDescription = Err.Description
        Err.Clear
        On Error GoTo 0
        eventsReadyForRecovery = _
            TryStopCashAnalysisEventsForRecovery(postEnforceStopDetail)
        If recoveryErrorNumber <> 0 Then
            Err.Raise vbObjectError + 5194, _
                "CashAnalysisRecoveryFatal/BuildCashAnalysisViewCore", _
                errorDescription & " / Recovery強制設定エラー: Err " & _
                CStr(recoveryErrorNumber) & " " & recoveryErrorDescription
        End If
        If Not eventsReadyForRecovery Then _
            Err.Raise vbObjectError + 5194, _
                "CashAnalysisRecoveryFatal/BuildCashAnalysisViewCore", _
                errorDescription & " / Recovery処理後のExcelイベント" & _
                "False収束を確認できません: " & postEnforceStopDetail
        recoveryConfirmed = _
            CashAnalysisRecoveryStateIsConfirmedExact(rollbackDetail)
        If Not recoveryConfirmed Then _
            Err.Raise vbObjectError + 5194, _
                "CashAnalysisRecoveryFatal/BuildCashAnalysisViewCore", _
                errorDescription & " / 今回のRecovery二重状態を" & _
                "厳密確認できません: " & rollbackDetail
        applicationStateConfirmed = _
            CashAnalysisApplicationStateAllowsEntryRestore( _
                True, rollbackDetail)
        If Not applicationStateConfirmed Then
            eventsReadyForRecovery = _
                TryStopCashAnalysisEventsForRecovery( _
                    finalRecoveryStopDetail)
            Err.Raise vbObjectError + 5194, _
                "CashAnalysisRecoveryFatal/BuildCashAnalysisViewCore", _
                errorDescription & " / Application状態を安全に" & _
                "確認できません: " & rollbackDetail
        End If
        eventsReadyForRecovery = _
            TryStopCashAnalysisEventsForRecovery(finalRecoveryStopDetail)
        If Not eventsReadyForRecovery Then _
            Err.Raise vbObjectError + 5194, _
                "CashAnalysisRecoveryFatal/BuildCashAnalysisViewCore", _
                errorDescription & " / Recovery確認後のExcelイベント" & _
                "False収束を確認できません: " & finalRecoveryStopDetail
        Err.Raise vbObjectError + 5194, _
            "CashAnalysisRecoveryFatal/BuildCashAnalysisViewCore", _
            errorDescription & " / 資金操作表を完全に復元できず、" & _
            "今回のRecovery状態へ停止しました: " & rollbackDetail
    End If
    On Error GoTo 0
    If Len(rollbackDetail) > 0 Then _
        errorDescription = errorDescription & " / 復元確認: " & rollbackDetail
    Err.Raise errorNumber, "BuildCashAnalysisViewCore", errorDescription
End Sub

Public Sub ApplyCashAnalysisViewWindowStyle(Optional ByVal selectTop As Boolean = True)
    '1366×768・125%相当でも80%未満へ縮小しない列幅で、A:Mと固定パネル＋
    '最低2明細行が同時に見える倍率へ収束させる。
    '同時に見える倍率へ収束させる。Range/Windowはいずれもポイント単位なので、
    'Windows 125%表示でもDPIを推測せず実寸から判断できる。
    Dim ws As Worksheet, win As Window
    Dim requiredWidth As Double, availableWidth As Double
    Dim requiredHeight As Double, availableHeight As Double
    Dim targetZoom As Long, fitAtReturnedZoom As Boolean
    If Not SheetExists(SH_OUTPUT_TX) Then Exit Sub
    Set ws = GetSheet(SH_OUTPUT_TX)
    ws.Visible = xlSheetVisible
    ws.Activate
    Set win = Application.ActiveWindow
    'ウィンドウ倍率と固定位置はデータ・保存状態ではない。複数ウィンドウ、
    '保護ビュー、リモート表示等で取得できない場合も分析結果を失敗扱いにしない。
    If win Is Nothing Then Exit Sub

    requiredWidth = ws.Range("A1:M1").Width
    availableWidth = InputAvailableWidthPoints(win)
    requiredHeight = ws.Range("1:" & CStr(CASH_VIEW_HEADER_ROW)).Height + _
                     VIEW_DATA_ROW_HEIGHT * CDbl(VIEW_MIN_VISIBLE_DATA_ROWS)
    availableHeight = CashAnalysisAvailableHeightPoints(win)
    targetZoom = CashAnalysisFitZoomPercent( _
                     requiredWidth, availableWidth, _
                     requiredHeight, availableHeight, _
                     fitAtReturnedZoom)

    '80%を下回らないと収まらない狭いウィンドウでは、可読性を優先して
    '80%を返し、fitAtReturnedZoom=Falseとする。横スクロールを許容しても、
    '本文が見かけ9pt未満になる縮小は行わない。

    SafeFreezeSheetAt ws, "A" & CStr(CASH_VIEW_FIRST_DATA_ROW), targetZoom
    ws.Activate
    If selectTop Then
        SafeSelectCell ws, "A1"
    End If
End Sub

Private Function CashAnalysisAvailableHeightPoints(ByVal win As Window) As Double
    'Application.UsableHeightとWindow.Heightはポイント単位。リボン、数式バー、
    'シート見出し等の領域を保守的に差し引き、セル表示へ使える高さを返す。
    Dim availableHeight As Double
    On Error Resume Next
    availableHeight = Application.UsableHeight
    If Not win Is Nothing Then
        If win.Height > 0 Then
            If availableHeight <= 0 Then
                availableHeight = win.Height
            ElseIf win.Height < availableHeight Then
                availableHeight = win.Height
            End If
        End If
    End If
    On Error GoTo 0
    If availableHeight > VIEW_VERTICAL_CHROME_RESERVE_POINTS Then
        availableHeight = availableHeight - VIEW_VERTICAL_CHROME_RESERVE_POINTS
    Else
        availableHeight = 0
    End If
    CashAnalysisAvailableHeightPoints = availableHeight
End Function

Public Function CashAnalysisFitZoomPercent( _
        ByVal requiredWidth As Double, ByVal availableWidth As Double, _
        ByVal requiredHeight As Double, ByVal availableHeight As Double, _
        Optional ByRef fitAtReturnedZoom As Boolean = False) As Long
    '実画面を変更しない決定的計算。横幅または高さの厳しい方へ合わせ、
    '設計倍率88%を上限、通常文字を読める80%を下限とする。戻り値は常に
    '実際に設定する倍率。fitAtReturnedZoomは、指定された全必要寸法がその倍率で
    '収まる場合だけTrueとする。必要倍率が80%未満、または利用可能寸法を取得
    'できない場合はFalseなので、80%を「収容済み」と誤認しない。
    Dim targetZoom As Double, widthZoom As Double, heightZoom As Double
    targetZoom = CDbl(VIEW_DESIGN_ZOOM)
    If requiredWidth > 0 Then
        If availableWidth > 0 Then
            widthZoom = 100# * availableWidth / requiredWidth
            If widthZoom < targetZoom Then targetZoom = widthZoom
        End If
    End If
    If requiredHeight > 0 Then
        If availableHeight > 0 Then
            heightZoom = 100# * availableHeight / requiredHeight
            If heightZoom < targetZoom Then targetZoom = heightZoom
        End If
    End If
    If targetZoom < VIEW_MIN_ZOOM Then targetZoom = VIEW_MIN_ZOOM
    If targetZoom > VIEW_DESIGN_ZOOM Then targetZoom = VIEW_DESIGN_ZOOM
    CashAnalysisFitZoomPercent = CLng(Int(targetZoom))
    fitAtReturnedZoom = True
    If requiredWidth > 0 Then
        If availableWidth <= 0 Then
            fitAtReturnedZoom = False
        ElseIf requiredWidth * CDbl(CashAnalysisFitZoomPercent) / 100# > _
               availableWidth + 0.5 Then
            fitAtReturnedZoom = False
        End If
    End If
    If requiredHeight > 0 Then
        If availableHeight <= 0 Then
            fitAtReturnedZoom = False
        ElseIf requiredHeight * CDbl(CashAnalysisFitZoomPercent) / 100# > _
               availableHeight + 0.5 Then
            fitAtReturnedZoom = False
        End If
    End If
End Function

Private Sub BuildCashAnalysisViewStructure(ByVal ws As Worksheet)
    Dim rng As Range
    If ws Is Nothing Then Exit Sub
    ws.Unprotect Password:=TOOL_PASSWORD
    '図形は作成時のセル寸法を保持する。全再構築経路で先に設計寸法へ収束させる。
    ApplyCashAnalysisViewGeometry ws
    ws.Cells.Locked = True
    With ws.Range("A1:M8")
        .Font.Name = "Yu Gothic UI"
        .Font.Size = 10
        .VerticalAlignment = xlCenter
        .Borders.LineStyle = xlContinuous
        .Borders.Color = RGB(226, 232, 240)
        .Interior.Color = RGB(255, 255, 255)
    End With

    MergeViewCell ws.Range("A1:E1"), "資金操作表｜取引と分析を同時確認"
    With ws.Range("A1:E1")
        .Interior.Color = RGB(15, 23, 42)
        .Font.Color = RGB(255, 255, 255)
        .Font.Bold = True
        .Font.Size = 15
        .HorizontalAlignment = xlLeft
        .IndentLevel = 1
    End With
    MergeViewCell ws.Range("F1:M1"), "分析候補を更新すると、ここに件数と現在位置が表示されます。"
    With ws.Range("F1:M1")
        .Interior.Color = RGB(241, 245, 249)
        .Font.Color = RGB(51, 65, 85)
        .Font.Bold = True
        .HorizontalAlignment = xlLeft
        .IndentLevel = 1
        '候補件数が大きい場合も1行の要約を欠けさせない最終防御。
        '詳細情報は5～7行へ表示し、ここには短い状態だけを置く。
        .WrapText = False
        .ShrinkToFit = True
    End With

    '図形は画面専用で印刷しないため、印刷時に必要な現在区分と表示範囲だけをセルへ残す。
    MergeViewCell ws.Range("A2:C2"), "資金移動"
    MergeViewCell ws.Range("D2:F2"), "不明出金"
    MergeViewCell ws.Range("G2:I2"), "不明入金"
    MergeViewCell ws.Range("J2:K2"), ""
    MergeViewCell ws.Range("L2:M2"), ""
    MergeViewCell ws.Range("E3:F3"), ""
    MergeViewCell ws.Range("G3:H3"), "表示: 構成取引"
    MergeViewCell ws.Range("I3:J3"), ""
    MergeViewCell ws.Range("K3:M3"), ""
    StyleViewPrintControl ws.Range("A2:I2")
    StyleViewPrintControl ws.Range("G3:H3")

    MergeViewCell ws.Range("A3:B3"), "確認状況"
    MergeViewCell ws.Range("C3:D3"), ANALYSIS_STATUS_UNREVIEWED
    StyleViewLabel ws.Range("A3:B3")
    StyleViewValue ws.Range("C3:D3")

    ws.Range("A4").Value = "出金合計"
    MergeViewCell ws.Range("B4:D4"), "0"
    ws.Range("E4").Value = "入金合計"
    MergeViewCell ws.Range("F4:H4"), "0"
    ws.Range("I4").Value = "差額（入－出）"
    MergeViewCell ws.Range("J4:M4"), "0"
    StyleViewLabel ws.Range("A4")
    StyleViewLabel ws.Range("E4")
    StyleViewLabel ws.Range("I4")
    StyleViewMoney ws.Range("B4:D4"), RGB(254, 242, 242), RGB(185, 28, 28)
    StyleViewMoney ws.Range("F4:H4"), RGB(239, 246, 255), RGB(29, 78, 216)
    StyleViewMoney ws.Range("J4:M4"), RGB(248, 250, 252), RGB(15, 23, 42)

    MergeViewCell ws.Range("A5:B5"), "日付・期間"
    MergeViewCell ws.Range("C5:E5"), "－"
    MergeViewCell ws.Range("F5:G5"), "人物・資金経路"
    MergeViewCell ws.Range("H5:M5"), "－"
    StyleViewLabel ws.Range("A5:B5")
    StyleViewValue ws.Range("C5:E5")
    StyleViewLabel ws.Range("F5:G5")
    StyleViewValue ws.Range("H5:M5")

    MergeViewCell ws.Range("A6:B6"), "抽出理由・要点" & vbLf & "［ダブルクリックで展開］"
    MergeViewCell ws.Range("C6:M6"), "候補を選択すると、抽出理由が表示されます。"
    MergeViewCell ws.Range("A7:B7"), "反証・制約" & vbLf & "［ダブルクリックで展開］"
    MergeViewCell ws.Range("C7:M7"), "候補が成立しない可能性もここで確認します。"
    MergeViewCell ws.Range("A8:B8"), "確認メモ" & vbLf & "［ダブルクリックで展開］"
    MergeViewCell ws.Range("C8:M8"), ""
    StyleViewLabel ws.Range("A6:B8")
    ws.Range("A6:B8").WrapText = True
    ws.Range("A6:B8").Font.Size = 9
    StyleViewValue ws.Range("C6:M8")
    ws.Range("C6:M8").WrapText = True
    ws.Range("C8:M8").Interior.Color = RGB(254, 249, 195)

    BuildCashAnalysisViewButtons ws

    SetRowValues ws.Cells(CASH_VIEW_HEADER_ROW, 1), CashAnalysisViewHeaders()
    ws.Range("V1:Z12").NumberFormatLocal = "@"
    ws.Columns("N:Z").Hidden = True
    Set rng = ws.Range("A9:M9")
    rng.Interior.Color = RGB(226, 232, 240)
    rng.Borders.LineStyle = xlNone
End Sub

Private Sub StyleViewPrintControl(ByVal target As Range)
    If target Is Nothing Then Exit Sub
    With target
        .Interior.Color = RGB(248, 250, 252)
        .Font.Color = RGB(51, 65, 85)
        .Font.Bold = True
        .HorizontalAlignment = xlCenter
        .VerticalAlignment = xlCenter
        .Borders.LineStyle = xlContinuous
        .Borders.Color = RGB(203, 213, 225)
    End With
End Sub

Private Sub MergeViewCell(ByVal target As Range, ByVal valueText As String)
    If target Is Nothing Then Exit Sub
    target.Merge
    target.Cells(1, 1).Value = valueText
End Sub

Private Sub StyleViewLabel(ByVal target As Range)
    If target Is Nothing Then Exit Sub
    With target
        .Interior.Color = RGB(241, 245, 249)
        .Font.Color = RGB(71, 85, 105)
        .Font.Bold = True
        .HorizontalAlignment = xlCenter
    End With
End Sub

Private Sub StyleViewValue(ByVal target As Range)
    If target Is Nothing Then Exit Sub
    With target
        .Interior.Color = RGB(255, 255, 255)
        .Font.Color = RGB(15, 23, 42)
        .HorizontalAlignment = xlLeft
        .IndentLevel = 1
    End With
End Sub

Private Sub StyleViewMoney(ByVal target As Range, ByVal fillColor As Long, ByVal fontColor As Long)
    If target Is Nothing Then Exit Sub
    With target
        .Interior.Color = fillColor
        .Font.Color = fontColor
        .Font.Bold = True
        .Font.Size = 12
        .HorizontalAlignment = xlRight
        .IndentLevel = 1
    End With
End Sub

Private Sub AddViewButton(ByVal ws As Worksheet, ByVal area As Range, ByVal caption As String, _
                          ByVal macroName As String, ByVal styleName As String)
    AddUIButton ws, area.Left + 2, area.Top + 2, area.Width - 4, area.Height - 4, _
                caption, macroName, styleName, False
End Sub

Private Sub ApplyCashAnalysisViewGeometry(ByVal ws As Worksheet)
    If ws Is Nothing Then Exit Sub
    ws.Rows(1).RowHeight = 34
    ws.Rows(2).RowHeight = 36
    ws.Rows(3).RowHeight = 36
    ws.Rows(4).RowHeight = 31
    ws.Rows(5).RowHeight = 31
    ws.Rows(6).RowHeight = 38
    ws.Rows(7).RowHeight = 38
    ws.Rows(8).RowHeight = 42
    ws.Rows(9).RowHeight = 7
    ws.Rows(CASH_VIEW_HEADER_ROW).RowHeight = 34
    '提出列A:Mを維持したまま、1366px級で80%以上に収める。長文の摘要は
    '折返し・行高調整で読み、通常画面を低倍率へ押し下げる固定幅を持たせない。
    ws.Columns("A:A").ColumnWidth = 15
    ws.Columns("B:B").ColumnWidth = 13.5
    ws.Columns("C:C").ColumnWidth = 15
    ws.Columns("D:D").ColumnWidth = 8.5
    ws.Columns("E:E").ColumnWidth = 13.5
    ws.Columns("F:F").ColumnWidth = 11
    ws.Columns("G:G").ColumnWidth = 7.5
    ws.Columns("H:I").ColumnWidth = 12
    ws.Columns("J:J").ColumnWidth = 14
    ws.Columns("K:K").ColumnWidth = 7.5
    ws.Columns("L:L").ColumnWidth = 20
    ws.Columns("M:M").ColumnWidth = 12.5
    ws.Range("C5:M8").WrapText = True
End Sub

Private Sub BuildCashAnalysisViewButtons(ByVal ws As Worksheet)
    If ws Is Nothing Then Exit Sub
    AddViewButton ws, ws.Range("A2:C2"), "資金移動", "ShowCashAnalysisTransfers", "primary"
    AddViewButton ws, ws.Range("D2:F2"), "不明出金", "ShowCashAnalysisUnknownWithdrawals", "soft"
    AddViewButton ws, ws.Range("G2:I2"), "不明入金", "ShowCashAnalysisUnknownDeposits", "soft"
    AddViewButton ws, ws.Range("J2:K2"), "前の候補", "PreviousCashAnalysisCandidate", "tool"
    AddViewButton ws, ws.Range("L2:M2"), "次の候補", "NextCashAnalysisCandidate", "tool"
    AddViewButton ws, ws.Range("E3:F3"), "未確認へ", "NextUnreviewedCashAnalysisGroup", "tool"
    AddViewButton ws, ws.Range("G3:H3"), "表示: 構成取引", "CycleCashAnalysisViewMode", "soft"
    AddViewButton ws, ws.Range("I3:J3"), "手動候補を選ぶ", "CashAnalysisSecondaryAction", "tool"
    AddViewButton ws, ws.Range("K3:M3"), "確認済みにする", "CashAnalysisPrimaryAction", "primary"
End Sub

Public Sub RestoreCashAnalysisViewControls(ByVal ws As Worksheet)
    '書式復旧時にも、壊れた列幅から作られた図形の位置・寸法を設計値で作り直す。
    Dim workbookWasSaved As Boolean, protectOK As Boolean
    Dim savedErrorNumber As Long, savedErrorDescription As String
    Dim errorNumber As Long, errorSource As String, errorDescription As String
    Dim eventsReady As Boolean, convergenceDetail As String
    If ws Is Nothing Then Exit Sub
    workbookWasSaved = ThisWorkbook.Saved
    On Error GoTo EH
    ws.Unprotect Password:=TOOL_PASSWORD
    ApplyCashAnalysisViewGeometry ws
    DeleteToolShapesVerified ws, False
    BuildCashAnalysisViewButtons ws
    RefreshCashAnalysisPanel False
    If workbookWasSaved Then ThisWorkbook.Saved = True
    Exit Sub
EH:
    errorNumber = Err.Number
    errorSource = Err.Source
    errorDescription = Err.Description
    If IsCashAnalysisRecoveryFatal(errorNumber, errorSource) Then
        Call TryStopCashAnalysisEventsForRecovery(convergenceDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    protectOK = TryProtectCashAnalysisViewAfterFailure( _
                    ws, "RestoreCashAnalysisViewControls", False, errorDescription)
    If workbookWasSaved And protectOK Then
        On Error Resume Next
        Err.Clear
        ThisWorkbook.Saved = True
        savedErrorNumber = Err.Number
        savedErrorDescription = Err.Description
        Err.Clear
        On Error GoTo 0
        If savedErrorNumber <> 0 Then _
            AppendCashAnalysisRollbackDetail errorDescription, _
                "ブック保存状態の復元エラー: Err " & _
                CStr(savedErrorNumber) & " " & savedErrorDescription
    End If
    Err.Raise errorNumber, "RestoreCashAnalysisViewControls", errorDescription
End Sub

Public Sub FormatCashAnalysisViewLayout(ByVal ws As Worksheet)
    Dim lastR As Long, r As Long
    Dim recordTypes As Variant, tekiyoValues As Variant
    Dim recordType As String, tekiyoText As String
    If ws Is Nothing Then Exit Sub
    lastR = LastUsedRowInSheet(ws)
    If lastR < CASH_VIEW_HEADER_ROW Then lastR = CASH_VIEW_HEADER_ROW

    With ws.Range("A1:T" & CStr(lastR))
        '色はタイトル、状態、金額など各部品の意味を持つため、ここでは上書きしない。
        .Font.Name = "Yu Gothic UI"
        .VerticalAlignment = xlCenter
    End With
    ApplyCashAnalysisViewGeometry ws

    FormatOutputHeader ws.Range(ws.Cells(CASH_VIEW_HEADER_ROW, 1), _
                                    ws.Cells(CASH_VIEW_HEADER_ROW, CASH_VIEW_LAST_COL))
    With ws.Range(ws.Cells(CASH_VIEW_HEADER_ROW, 1), ws.Cells(CASH_VIEW_HEADER_ROW, OUT_COL_OTHER))
        .HorizontalAlignment = xlCenter
        .VerticalAlignment = xlCenter
        .WrapText = False
    End With
    With ws.Cells(CASH_VIEW_HEADER_ROW, OUT_COL_WITHDRAW)
        .Interior.Color = RGB(185, 28, 28)
        .Font.Color = RGB(255, 255, 255)
        .Font.Bold = True
    End With
    With ws.Cells(CASH_VIEW_HEADER_ROW, OUT_COL_DEPOSIT)
        .Interior.Color = RGB(29, 78, 216)
        .Font.Color = RGB(255, 255, 255)
        .Font.Bold = True
    End With
    ws.Columns("N:Z").Hidden = True

    If lastR >= CASH_VIEW_FIRST_DATA_ROW Then
        With ws.Range(ws.Cells(CASH_VIEW_FIRST_DATA_ROW, 1), ws.Cells(lastR, OUT_COL_OTHER))
            .Font.Size = 11.5
            .Font.Color = RGB(15, 23, 42)
            .Font.Bold = False
            .Interior.Pattern = xlSolid
            .Interior.Color = RGB(255, 255, 255)
            .Borders.LineStyle = xlContinuous
            .Borders.Color = RGB(226, 232, 240)
            .VerticalAlignment = xlCenter
        End With
        ws.Rows(CStr(CASH_VIEW_FIRST_DATA_ROW) & ":" & CStr(lastR)).RowHeight = 30
        ws.Range(ws.Cells(CASH_VIEW_FIRST_DATA_ROW, 1), ws.Cells(lastR, OUT_COL_TIME)).HorizontalAlignment = xlCenter
        ws.Range(ws.Cells(CASH_VIEW_FIRST_DATA_ROW, OUT_COL_WITHDRAW), _
                 ws.Cells(lastR, OUT_COL_DEPOSIT)).HorizontalAlignment = xlRight
        ws.Range(ws.Cells(CASH_VIEW_FIRST_DATA_ROW, OUT_COL_WITHDRAW), _
                 ws.Cells(lastR, OUT_COL_WITHDRAW)).Font.Color = RGB(153, 27, 27)
        ws.Range(ws.Cells(CASH_VIEW_FIRST_DATA_ROW, OUT_COL_DEPOSIT), _
                 ws.Cells(lastR, OUT_COL_DEPOSIT)).Font.Color = RGB(30, 64, 175)
        ws.Range(ws.Cells(CASH_VIEW_FIRST_DATA_ROW, OUT_COL_SHOP), _
                 ws.Cells(lastR, OUT_COL_MACHINE)).HorizontalAlignment = xlCenter
        ws.Range(ws.Cells(CASH_VIEW_FIRST_DATA_ROW, OUT_COL_TEKIYO), _
                 ws.Cells(lastR, OUT_COL_TEKIYO)).HorizontalAlignment = xlLeft
        ws.Range(ws.Cells(CASH_VIEW_FIRST_DATA_ROW, OUT_COL_OTHER), _
                 ws.Cells(lastR, OUT_COL_OTHER)).HorizontalAlignment = xlRight
        ws.Range(ws.Cells(CASH_VIEW_FIRST_DATA_ROW, OUT_COL_DATE), _
                 ws.Cells(lastR, OUT_COL_DATE)).NumberFormatLocal = "yyyy/m/d"
        ws.Range(ws.Cells(CASH_VIEW_FIRST_DATA_ROW, OUT_COL_TIME), _
                 ws.Cells(lastR, OUT_COL_TIME)).NumberFormatLocal = "hh:mm"
        ws.Range(ws.Cells(CASH_VIEW_FIRST_DATA_ROW, OUT_COL_WITHDRAW), _
                 ws.Cells(lastR, OUT_COL_DEPOSIT)).NumberFormatLocal = "#,##0.########"
        ws.Range(ws.Cells(CASH_VIEW_FIRST_DATA_ROW, OUT_COL_OTHER), _
                 ws.Cells(lastR, OUT_COL_OTHER)).NumberFormatLocal = "#,##0.########"
        ws.Range(ws.Cells(CASH_VIEW_FIRST_DATA_ROW, OUT_COL_TEKIYO), _
                 ws.Cells(lastR, OUT_COL_OTHER)).WrapText = True

        If lastR = CASH_VIEW_FIRST_DATA_ROW Then
            ReDim recordTypes(1 To 1, 1 To 1)
            ReDim tekiyoValues(1 To 1, 1 To 1)
            recordTypes(1, 1) = ws.Cells(CASH_VIEW_FIRST_DATA_ROW, OUT_COL_RECORD_TYPE).Value2
            tekiyoValues(1, 1) = ws.Cells(CASH_VIEW_FIRST_DATA_ROW, OUT_COL_TEKIYO).Value2
        Else
            recordTypes = ws.Range(ws.Cells(CASH_VIEW_FIRST_DATA_ROW, OUT_COL_RECORD_TYPE), _
                                   ws.Cells(lastR, OUT_COL_RECORD_TYPE)).Value2
            tekiyoValues = ws.Range(ws.Cells(CASH_VIEW_FIRST_DATA_ROW, OUT_COL_TEKIYO), _
                                    ws.Cells(lastR, OUT_COL_TEKIYO)).Value2
        End If
        For r = CASH_VIEW_FIRST_DATA_ROW To lastR
            recordType = CellText(recordTypes(r - CASH_VIEW_FIRST_DATA_ROW + 1, 1))
            tekiyoText = CellText(tekiyoValues(r - CASH_VIEW_FIRST_DATA_ROW + 1, 1))
            If Len(tekiyoText) > 32 Or InStr(1, tekiyoText, vbLf, vbBinaryCompare) > 0 Or _
               InStr(1, tekiyoText, vbCr, vbBinaryCompare) > 0 Then _
                ws.Rows(r).RowHeight = ReadableOutputRowHeight(tekiyoText, 30, 120)
            '特殊行の色分けは下の条件付き書式で一括適用する。
            '行ごとの13セル書式設定を避け、VBA/Excel間のCOM往復を長期明細でも抑える。
        Next r
    End If

    ApplyCashAnalysisConditionalFormatting ws, lastR
    ws.ScrollArea = "A1:M" & CStr(Application.Max(60, lastR + 20))
    ApplyPrintAreaVerified ws, ws.Range("A1:M" & CStr(lastR))
    '分析パネルは先頭ページだけに置き、2ページ目以降は取引見出しだけを反復する。
    ApplyReadablePrintSettings ws, "$10:$10"
End Sub

Private Sub ApplyCashAnalysisConditionalFormatting(ByVal ws As Worksheet, ByVal lastR As Long)
    Dim body As Range, fc As FormatCondition
    If ws Is Nothing Or lastR < CASH_VIEW_FIRST_DATA_ROW Then Exit Sub
    Set body = ws.Range(ws.Cells(CASH_VIEW_FIRST_DATA_ROW, 1), ws.Cells(lastR, OUT_COL_OTHER))
    body.FormatConditions.Delete

    Set fc = body.FormatConditions.Add(Type:=xlExpression, _
        Formula1:="=OR($P" & CStr(CASH_VIEW_FIRST_DATA_ROW) & "=" & Chr$(34) & _
                  RECORD_BALANCE & Chr$(34) & ",AND($P" & _
                  CStr(CASH_VIEW_FIRST_DATA_ROW) & "=" & Chr$(34) & Chr$(34) & _
                  ",ISNUMBER(SEARCH(" & Chr$(34) & "残高" & Chr$(34) & ",$L" & _
                  CStr(CASH_VIEW_FIRST_DATA_ROW) & "))))")
    fc.Interior.Color = RGB(220, 252, 231)
    fc.Font.Color = RGB(22, 101, 52)

    Set fc = body.FormatConditions.Add(Type:=xlExpression, _
        Formula1:="=OR($P" & CStr(CASH_VIEW_FIRST_DATA_ROW) & "=" & Chr$(34) & _
                  RECORD_INHERITANCE & Chr$(34) & ",$L" & _
                  CStr(CASH_VIEW_FIRST_DATA_ROW) & "=" & Chr$(34) & _
                  "相続開始日" & Chr$(34) & ")")
    fc.Interior.Color = RGB(254, 243, 199)
    fc.Font.Color = RGB(146, 64, 14)
    fc.Font.Bold = True

    Set fc = body.FormatConditions.Add(Type:=xlExpression, _
        Formula1:="=OR($P" & CStr(CASH_VIEW_FIRST_DATA_ROW) & "=" & Chr$(34) & _
                  RECORD_OPEN & Chr$(34) & ",$P" & _
                  CStr(CASH_VIEW_FIRST_DATA_ROW) & "=" & Chr$(34) & _
                  RECORD_CLOSE & Chr$(34) & ",$L" & _
                  CStr(CASH_VIEW_FIRST_DATA_ROW) & "=" & Chr$(34) & _
                  "口座開設日" & Chr$(34) & ",$L" & _
                  CStr(CASH_VIEW_FIRST_DATA_ROW) & "=" & Chr$(34) & _
                  "口座解約日" & Chr$(34) & ")")
    fc.Interior.Color = RGB(219, 234, 254)
    fc.Font.Color = RGB(30, 64, 175)

    Set fc = body.FormatConditions.Add(Type:=xlExpression, _
        Formula1:="=$S" & CStr(CASH_VIEW_FIRST_DATA_ROW) & "=" & Chr$(34) & _
                  VIEW_ROLE_WITHDRAW & Chr$(34))
    fc.Interior.Color = RGB(254, 242, 242)
    fc.Font.Color = RGB(127, 29, 29)

    Set fc = body.FormatConditions.Add(Type:=xlExpression, _
        Formula1:="=$S" & CStr(CASH_VIEW_FIRST_DATA_ROW) & "=" & Chr$(34) & _
                  VIEW_ROLE_DEPOSIT & Chr$(34))
    fc.Interior.Color = RGB(239, 246, 255)
    fc.Font.Color = RGB(30, 64, 175)

    Set fc = body.FormatConditions.Add(Type:=xlExpression, _
        Formula1:="=OR($S" & CStr(CASH_VIEW_FIRST_DATA_ROW) & "=" & Chr$(34) & _
                  VIEW_ROLE_BOTH & Chr$(34) & ",$T" & CStr(CASH_VIEW_FIRST_DATA_ROW) & _
                  "=" & Chr$(34) & "1" & Chr$(34) & ")")
    fc.Interior.Color = RGB(254, 249, 195)
    fc.Font.Color = RGB(133, 77, 14)
    On Error Resume Next
    fc.SetFirstPriority
    fc.StopIfTrue = True
    On Error GoTo 0
End Sub

Public Sub RefreshCashAnalysisPanel(Optional ByVal selectFirstVisible As Boolean = False)
    Dim ws As Worksheet, wsResult As Worksheet, wsGroup As Worksheet
    Dim categoryText As String, groupID As String, modeText As String
    Dim candidateRef As String, txIDList As String
    Dim manualMode As Boolean, resultRow As Long, groupRow As Long
    Dim currentIndex As Long, categoryCount As Long
    Dim counts(1 To 3) As Long, followupCount As Long, unreviewedCount As Long
    Dim lastResultRow As Long, r As Long, itemCategory As String, statusText As String
    Dim categoryValues As Variant, statusValues As Variant, groupValues As Variant
    Dim workbookWasSaved As Boolean, previousEvents As Boolean, eventsCaptured As Boolean
    Dim eventsReadyForRecovery As Boolean, protectOK As Boolean
    Dim recoveryConfirmed As Boolean, safeToRestoreEntry As Boolean
    Dim applicationStateConfirmed As Boolean
    Dim protectionRecoveryAttempted As Boolean
    Dim protectionRecoveryFailed As Boolean
    Dim protectionRecoveryConfirmed As Boolean
    Dim recoveryFatal As Boolean
    Dim eventStateDetail As String, recoveryDetail As String
    Dim stopDetail As String, stopRetryDetail As String
    Dim postProtectStopDetail As String, postEnforceStopDetail As String
    Dim convergenceDetail As String, finalRecoveryStopDetail As String
    Dim recoveryErrorNumber As Long, recoveryErrorDescription As String
    Dim errorNumber As Long, errorSource As String, errorDescription As String

    On Error GoTo EH
    If Not SheetExists(SH_OUTPUT_TX) Then Exit Sub
    Set ws = GetSheet(SH_OUTPUT_TX)
    workbookWasSaved = ThisWorkbook.Saved
    If Not TryGetCashAnalysisEnableEvents(previousEvents, eventStateDetail) Then
        StopAfterCashAnalysisEventStateFailure _
            "RefreshCashAnalysisPanel/開始状態取得", eventStateDetail, _
            eventsReadyForRecovery, False, vbNullString
        Err.Raise vbObjectError + 5102, "RefreshCashAnalysisPanel", _
                  "Excelイベントの開始状態を取得できませんでした。 " & eventStateDetail
    End If
    eventsCaptured = True
    If Not TrySetCashAnalysisEnableEventsExact(False, eventStateDetail) Then _
        Err.Raise vbObjectError + 5103, "RefreshCashAnalysisPanel", _
                  "分析パネル更新前にExcelイベントを停止できませんでした。 " & _
                  eventStateDetail
    ws.Unprotect Password:=TOOL_PASSWORD

    categoryText = CellText(ws.Range(VIEW_STATE_CATEGORY).Value)
    If Not IsCashViewCategory(categoryText) Then categoryText = VIEW_CATEGORY_TRANSFER
    modeText = CellText(ws.Range(VIEW_STATE_MODE).Value)
    If Not IsCashViewMode(modeText) Then modeText = VIEW_MODE_COMPONENT
    manualMode = (CellText(ws.Range(VIEW_STATE_MANUAL).Value) = "1")

    If SheetExists(SH_ANALYSIS_RESULT) Then
        Set wsResult = GetSheet(SH_ANALYSIS_RESULT)
        lastResultRow = LastUsedRowInSheet(wsResult)
        If lastResultRow >= 2 Then
            categoryValues = CashResultColumnValues(wsResult, 2, lastResultRow, 2)
            statusValues = CashResultColumnValues(wsResult, 2, lastResultRow, ANALYSIS_RESULT_STATUS_COL)
            groupValues = CashResultColumnValues(wsResult, 2, lastResultRow, ANALYSIS_RESULT_GROUP_ID_COL)
        End If
        For r = 1 To Application.Max(0, lastResultRow - 1)
            itemCategory = CashViewCategoryForResult(CellText(categoryValues(r, 1)))
            Select Case itemCategory
                Case VIEW_CATEGORY_TRANSFER: counts(1) = counts(1) + 1
                Case VIEW_CATEGORY_UNKNOWN_WITHDRAW: counts(2) = counts(2) + 1
                Case VIEW_CATEGORY_UNKNOWN_DEPOSIT: counts(3) = counts(3) + 1
            End Select
            statusText = CellText(statusValues(r, 1))
            If statusText = ANALYSIS_STATUS_FOLLOWUP Then followupCount = followupCount + 1
            If Len(statusText) = 0 Or statusText = ANALYSIS_STATUS_UNREVIEWED Then _
                unreviewedCount = unreviewedCount + 1
        Next r
    End If

    UpdateCategoryButtonCaptions ws, categoryText, counts
    If manualMode Then
        RefreshCashManualSelectionPanel ws
    ElseIf wsResult Is Nothing Or lastResultRow < 2 Then
        ClearCashAnalysisCandidatePanel ws, categoryText, counts, unreviewedCount, followupCount
        ShowAllCashViewRows ws
    Else
        groupID = CellText(ws.Range(VIEW_STATE_GROUP_ID).Value)
        resultRow = FindCashAnalysisResultRow(categoryValues, groupValues, categoryText, groupID, _
                                               currentIndex, categoryCount)
        If resultRow = 0 Then
            ClearCashAnalysisCandidatePanel ws, categoryText, counts, unreviewedCount, followupCount
            ShowAllCashViewRows ws
        Else
            ws.Range(VIEW_STATE_GROUP_ID).Value = CellText(wsResult.Cells(resultRow, ANALYSIS_RESULT_GROUP_ID_COL).Value)
            ws.Range(VIEW_STATE_RESULT_ROW).Value = CStr(resultRow)
            ws.Range(VIEW_STATE_MODE).Value = modeText
            candidateRef = CellText(ws.Range(VIEW_STATE_CANDIDATE_REF).Value)
            If Len(candidateRef) > 0 And SheetExists(SH_WORK_ANALYSIS_GROUP) Then
                Set wsGroup = GetSheet(SH_WORK_ANALYSIS_GROUP)
                groupRow = FindCashAnalysisAlternativeRow( _
                               wsGroup, _
                               CellText(wsResult.Cells(resultRow, ANALYSIS_RESULT_GROUP_ID_COL).Value), _
                               candidateRef)
            End If
            If groupRow > 0 Then
                RenderCashAnalysisAlternativeCandidate ws, wsResult, resultRow, _
                    wsGroup, groupRow, currentIndex, categoryCount, counts, _
                    unreviewedCount, followupCount, modeText
                txIDList = CellText(wsGroup.Cells(groupRow, 5).Value)
            Else
                '再分析で代替候補が消えた場合は、同じグループの代表へ安全に戻す。
                ws.Range(VIEW_STATE_CANDIDATE_REF).ClearContents
                RenderCashAnalysisCandidate ws, wsResult, resultRow, currentIndex, categoryCount, _
                                            counts, unreviewedCount, followupCount, modeText
                txIDList = CellText(wsResult.Cells(resultRow, ANALYSIS_RESULT_TX_IDS_COL).Value)
            End If
            ApplyCashAnalysisRowFilter ws, txIDList, modeText
        End If
    End If
    AdjustCashAnalysisPanelRowHeights ws
    ApplyCashAnalysisPanelValidation ws
    UpdateCashAnalysisStatusStyle ws
    ProtectCashAnalysisViewSheet
    If workbookWasSaved Then ThisWorkbook.Saved = True
    If selectFirstVisible Then SelectFirstVisibleCashAnalysisRow ws
    If Not TryRestoreCashAnalysisEnableEvents( _
               previousEvents, "RefreshCashAnalysisPanel", eventStateDetail) Then _
        Err.Raise vbObjectError + 5104, "RefreshCashAnalysisPanel", eventStateDetail
    eventsCaptured = False
    Exit Sub
EH:
    errorNumber = Err.Number
    errorSource = Err.Source
    errorDescription = Err.Description
    If IsCashAnalysisRecoveryFatal(errorNumber, errorSource) Then
        Call TryStopCashAnalysisEventsForRecovery(convergenceDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    If eventsCaptured Then
        eventsReadyForRecovery = _
            TrySetCashAnalysisEnableEventsExact(False, stopDetail)
        If Not eventsReadyForRecovery Then _
            eventsReadyForRecovery = _
                TrySetCashAnalysisEnableEventsExact(False, stopRetryDetail)
        If Not eventsReadyForRecovery Then _
            stopDetail = "初回=" & stopDetail & " / 再試行=" & stopRetryDetail
    End If
    If Not eventsReadyForRecovery Then
        If eventsCaptured Then
            AppendCashAnalysisRollbackDetail recoveryDetail, _
                "再保護前にExcelイベントを停止して読戻し確認できません: " & _
                stopDetail
        ElseIf Len(stopDetail) > 0 Then
            AppendCashAnalysisRollbackDetail recoveryDetail, _
                "Excelイベントの開始状態を取得できず、" & _
                "停止の読戻し確認にも失敗したため現在状態は不明です: " & _
                stopDetail
        Else
            AppendCashAnalysisRollbackDetail recoveryDetail, _
                "Excelイベントの開始状態と現在状態を確認できませんでした。"
        End If
        AppendCashAnalysisRollbackDetail recoveryDetail, _
            "イベント停止未確認のため、ブックの再保護と" & _
            "Recovery状態の書込みを行いませんでした。"
    End If

    If eventsReadyForRecovery Then
        protectOK = TryProtectCashAnalysisViewAfterFailure( _
                        ws, "RefreshCashAnalysisPanel", False, recoveryDetail, _
                        protectionRecoveryAttempted, _
                        protectionRecoveryFailed, _
                        protectionRecoveryConfirmed)
        '再保護の内部Recovery/leaseがイベント値を変更し得るため、
        '次のRecovery判断より前に外側のFalseを取り直す。
        eventsReadyForRecovery = _
            TryStopCashAnalysisEventsForRecovery(postProtectStopDetail)
        If Not eventsReadyForRecovery Then _
            AppendCashAnalysisRollbackDetail recoveryDetail, _
                "再保護処理後にExcelイベント停止を確認できません。" & _
                "現在状態は不明です: " & postProtectStopDetail
    End If

    If protectionRecoveryFailed Then
        recoveryFatal = True
        errorNumber = vbObjectError + 5194
        errorSource = "CashAnalysisRecoveryFatal/RefreshCashAnalysisPanel"
        AppendCashAnalysisRollbackDetail errorDescription, _
            "再保護中のRecovery強制設定が例外終了しました。"
    ElseIf protectionRecoveryAttempted Then
        recoveryConfirmed = protectionRecoveryConfirmed
    ElseIf eventsReadyForRecovery And Not protectOK Then
        On Error Resume Next
        Err.Clear
        EnforceRollbackRecoveryState recoveryDetail
        recoveryErrorNumber = Err.Number
        recoveryErrorDescription = Err.Description
        Err.Clear
        On Error GoTo 0
        '例外値を保存した直後にFalseを取り直す。Enforce失敗時は、
        '古いRecovery値の読取り、ブック書込み、開始値復元を行わない。
        eventsReadyForRecovery = _
            TryStopCashAnalysisEventsForRecovery(postEnforceStopDetail)
        If recoveryErrorNumber <> 0 Then
            recoveryFatal = True
            errorNumber = vbObjectError + 5194
            errorSource = "CashAnalysisRecoveryFatal/RefreshCashAnalysisPanel"
            AppendCashAnalysisRollbackDetail recoveryDetail, _
                "要復旧状態の強制設定エラー: Err " & _
                CStr(recoveryErrorNumber) & " " & recoveryErrorDescription
        ElseIf eventsReadyForRecovery Then
            recoveryConfirmed = _
                CashAnalysisRecoveryStateIsConfirmedExact(recoveryDetail)
            If recoveryConfirmed Then _
                applicationStateConfirmed = _
                    CashAnalysisApplicationStateAllowsEntryRestore( _
                        True, recoveryDetail)
            If applicationStateConfirmed Then _
                eventsReadyForRecovery = _
                    TryStopCashAnalysisEventsForRecovery( _
                        finalRecoveryStopDetail)
        Else
            AppendCashAnalysisRollbackDetail recoveryDetail, _
                "Recovery処理後にExcelイベント停止を確認できないため、" & _
                "復旧状態を読み取らず開始値へも戻しません。現在状態は不明です: " & _
                postEnforceStopDetail
        End If
        recoveryFatal = True
        errorNumber = vbObjectError + 5194
        errorSource = "CashAnalysisRecoveryFatal/RefreshCashAnalysisPanel"
        If Not recoveryConfirmed Then _
            AppendCashAnalysisRollbackDetail recoveryDetail, _
                "今回のRecovery二重状態を厳密確認できません。"
        If recoveryConfirmed And Not applicationStateConfirmed Then _
            AppendCashAnalysisRollbackDetail recoveryDetail, _
                "Recovery確認後のApplication状態を厳密確認できません。"
        If applicationStateConfirmed And Not eventsReadyForRecovery Then _
            AppendCashAnalysisRollbackDetail recoveryDetail, _
                "Application状態確認後のExcelイベントFalse収束を" & _
                "確認できません: " & finalRecoveryStopDetail
        eventsReadyForRecovery = _
            TryStopCashAnalysisEventsForRecovery(convergenceDetail)
        eventsCaptured = False
        Err.Raise vbObjectError + 5194, _
                  "CashAnalysisRecoveryFatal/RefreshCashAnalysisPanel", _
                  errorDescription & " / " & recoveryDetail
    End If

    If eventsCaptured Then
        safeToRestoreEntry = eventsReadyForRecovery And _
                             Not recoveryFatal And _
                             (protectOK Or recoveryConfirmed)
        If safeToRestoreEntry Then _
            safeToRestoreEntry = _
                CashAnalysisApplicationStateAllowsEntryRestore( _
                    previousEvents, recoveryDetail)
        If safeToRestoreEntry Then
            eventsReadyForRecovery = _
                TryStopCashAnalysisEventsForRecovery(eventStateDetail)
            safeToRestoreEntry = eventsReadyForRecovery
        End If
        If safeToRestoreEntry Then
            If Not TryRestoreCashAnalysisEnableEvents( _
                       previousEvents, "RefreshCashAnalysisPanel", _
                       eventStateDetail) Then _
                AppendCashAnalysisRollbackDetail recoveryDetail, eventStateDetail
        ElseIf TryStopCashAnalysisEventsForRecovery(convergenceDetail) Then
            AppendCashAnalysisRollbackDetail recoveryDetail, _
                "再保護またはRecoveryを厳密確認できないため、" & _
                "開始時イベント値へ戻さずFalseで停止しました。"
        Else
            AppendCashAnalysisRollbackDetail recoveryDetail, _
                "再保護またはRecoveryを厳密確認できず、" & _
                "ExcelイベントのFalse収束にも失敗しました。現在状態は不明です: " & _
                convergenceDetail
        End If
    End If
    eventsCaptured = False
    If Len(recoveryDetail) > 0 Then _
        errorDescription = errorDescription & " / 復元確認: " & recoveryDetail
    If Len(errorSource) = 0 Then errorSource = "RefreshCashAnalysisPanel"
    Err.Raise errorNumber, errorSource, errorDescription
End Sub

Private Sub AdjustCashAnalysisPanelRowHeights(ByVal ws As Worksheet)
    Dim expanded As Boolean
    Dim routeMaximum As Double, textMaximum As Double, memoMaximum As Double
    Dim actionText As String
    If ws Is Nothing Then Exit Sub
    expanded = (CellText(ws.Range(VIEW_STATE_PANEL_EXPANDED).Value) = "1")
    If expanded Then
        routeMaximum = 360
        textMaximum = 240
        memoMaximum = 240
        actionText = "［ダブルクリックで折りたたむ］"
    Else
        '折りたたみ時は内容量で固定パネルが縦へ膨らまないよう、
        '各行を設計最小高へ固定する。全文はダブルクリックまたは展開で確認できる。
        routeMaximum = 31
        textMaximum = 38
        memoMaximum = 42
        actionText = "［ダブルクリックで展開］"
    End If
    ws.Range("A6").Value = "抽出理由・要点" & vbLf & actionText
    ws.Range("A7").Value = "反証・制約" & vbLf & actionText
    ws.Range("A8").Value = "確認メモ" & vbLf & actionText
    ws.Rows(5).RowHeight = CashPanelTextRowHeight(CellText(ws.Range("H5").Value), 90, 31, routeMaximum)
    ws.Rows(6).RowHeight = CashPanelTextRowHeight(CellText(ws.Range("C6").Value), 150, 38, textMaximum)
    ws.Rows(7).RowHeight = CashPanelTextRowHeight(CellText(ws.Range("C7").Value), 150, 38, textMaximum)
    ws.Rows(8).RowHeight = CashPanelTextRowHeight(CellText(ws.Range("C8").Value), 150, 42, memoMaximum)
End Sub

Private Function CashPanelTextRowHeight(ByVal valueText As String, ByVal charactersPerLine As Long, _
                                        ByVal minimumHeight As Double, ByVal maximumHeight As Double) As Double
    Dim lineCount As Long
    Dim estimatedHeight As Double
    If charactersPerLine < 1 Then charactersPerLine = 1
    lineCount = ReadableTextLineCount(valueText, charactersPerLine)
    If lineCount < 1 Then lineCount = 1
    estimatedHeight = 18# * CDbl(lineCount) + 4#
    If estimatedHeight < minimumHeight Then estimatedHeight = minimumHeight
    If estimatedHeight > maximumHeight Then estimatedHeight = maximumHeight
    CashPanelTextRowHeight = estimatedHeight
End Function

Public Sub ToggleCashAnalysisPanelExpansion()
    Dim ws As Worksheet
    Dim workbookWasSaved As Boolean
    Dim previousEvents As Boolean, eventsCaptured As Boolean
    Dim eventsRestoreAttempted As Boolean, eventsReadyForRecovery As Boolean
    Dim actionMutationStarted As Boolean, protectOK As Boolean
    Dim safeToRestoreEntry As Boolean
    Dim eventStateDetail As String, stopDetail As String
    Dim convergenceDetail As String
    Dim errorNumber As Long, errorSource As String, errorDescription As String
    If Not SheetExists(SH_OUTPUT_TX) Then Exit Sub
    On Error GoTo EH
    Set ws = GetSheet(SH_OUTPUT_TX)
    workbookWasSaved = ThisWorkbook.Saved
    If Not TryGetCashAnalysisEnableEvents(previousEvents, eventStateDetail) Then _
        Err.Raise vbObjectError + 5119, "ToggleCashAnalysisPanelExpansion", _
                  "Excelイベントの開始状態を取得できませんでした。 " & eventStateDetail
    eventsCaptured = True
    If Not TrySetCashAnalysisEnableEventsExact(False, eventStateDetail) Then _
        Err.Raise vbObjectError + 5120, "ToggleCashAnalysisPanelExpansion", _
                  "表示切替前にExcelイベントを停止できませんでした。 " & eventStateDetail
    actionMutationStarted = True
    ws.Unprotect Password:=TOOL_PASSWORD
    If CellText(ws.Range(VIEW_STATE_PANEL_EXPANDED).Value) = "1" Then
        ws.Range(VIEW_STATE_PANEL_EXPANDED).Value = "0"
    Else
        ws.Range(VIEW_STATE_PANEL_EXPANDED).Value = "1"
    End If
    AdjustCashAnalysisPanelRowHeights ws
    ProtectCashAnalysisViewSheet
    If workbookWasSaved Then ThisWorkbook.Saved = True
    eventsRestoreAttempted = True
    If Not TryRestoreCashAnalysisEnableEvents( _
               previousEvents, "ToggleCashAnalysisPanelExpansion", _
               eventStateDetail) Then _
        Err.Raise vbObjectError + 5121, _
                  "ToggleCashAnalysisPanelExpansion", eventStateDetail
    eventsCaptured = False
    Exit Sub
EH:
    errorNumber = Err.Number
    errorSource = Err.Source
    errorDescription = Err.Description
    If IsCashAnalysisRecoveryFatal(errorNumber, errorSource) Then
        Call TryStopCashAnalysisEventsForRecovery(convergenceDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    If eventsCaptured Then
        If Not eventsRestoreAttempted Then _
            eventsReadyForRecovery = _
                TryStopCashAnalysisEventsForRecovery(stopDetail)
    End If
    If actionMutationStarted And Not eventsRestoreAttempted Then
        If eventsReadyForRecovery Then
            protectOK = TryProtectCashAnalysisViewAfterFailure( _
                            ws, "ToggleCashAnalysisPanelExpansion", _
                            False, errorDescription)
            safeToRestoreEntry = _
                CashAnalysisOuterLeaseMayRestoreAfterProtection( _
                    protectOK, errorDescription)
        Else
            AppendCashAnalysisRollbackDetail errorDescription, _
                "Excelイベント停止を読戻し確認できないため、" & _
                "ブックの再保護とRecovery書込みを行いませんでした。 " & _
                stopDetail
        End If
    End If
    If eventsCaptured And Not eventsRestoreAttempted Then
        eventsRestoreAttempted = True
        If Not actionMutationStarted Or safeToRestoreEntry Then
            If Not TryRestoreCashAnalysisEnableEvents( _
                       previousEvents, _
                       "ToggleCashAnalysisPanelExpansion/エラー終了", _
                       eventStateDetail) Then _
                AppendCashAnalysisRollbackDetail errorDescription, _
                    eventStateDetail
        ElseIf TryStopCashAnalysisEventsForRecovery(convergenceDetail) Then
            AppendCashAnalysisRollbackDetail errorDescription, _
                "再保護またはRecoveryを厳密確認できないため、" & _
                "開始時イベント値へ戻さずFalseで停止しました。"
        Else
            AppendCashAnalysisRollbackDetail errorDescription, _
                "安全状態を厳密確認できず、ExcelイベントのFalse収束にも" & _
                "失敗しました。現在状態は不明です: " & convergenceDetail
        End If
    End If
    eventsCaptured = False
    MsgBox "分析説明欄の表示を切り替えられませんでした。" & vbCrLf & _
           "Err " & CStr(errorNumber) & ": " & errorDescription, vbExclamation
End Sub

Private Sub RenderCashAnalysisCandidate(ByVal ws As Worksheet, ByVal wsResult As Worksheet, _
                                        ByVal resultRow As Long, ByVal currentIndex As Long, _
                                        ByVal categoryCount As Long, ByRef counts() As Long, _
                                        ByVal unreviewedCount As Long, ByVal followupCount As Long, _
                                        ByVal modeText As String)
    Dim categoryText As String, statusText As String, alternativeCount As Long
    Dim priorityText As String, manualStoredKey As String
    Dim dateText As String, routeText As String, pointText As String
    Dim constraintText As String, personClassText As String
    Dim isManualCandidate As Boolean
    categoryText = CashViewCategoryForResult(CellText(wsResult.Cells(resultRow, 2).Value))
    statusText = CellText(wsResult.Cells(resultRow, ANALYSIS_RESULT_STATUS_COL).Value)
    If Len(statusText) = 0 Then statusText = ANALYSIS_STATUS_UNREVIEWED
    If IsNumeric(wsResult.Cells(resultRow, ANALYSIS_RESULT_ALTERNATIVE_COUNT_COL).Value) Then _
        alternativeCount = CLng(wsResult.Cells(resultRow, ANALYSIS_RESULT_ALTERNATIVE_COUNT_COL).Value)
    If alternativeCount < 1 Then alternativeCount = 1

    priorityText = CellText(wsResult.Cells(resultRow, 1).Value)
    dateText = CashAnalysisNormalizeTimeEvidenceText( _
                   CellText(wsResult.Cells(resultRow, 3).Value))
    routeText = CashAnalysisNormalizeTimeEvidenceText( _
                    CellText(wsResult.Cells(resultRow, 5).Value))
    pointText = CashAnalysisNormalizeTimeEvidenceText( _
                    CellText(wsResult.Cells(resultRow, 6).Value))
    constraintText = CashAnalysisNormalizeTimeEvidenceText( _
                         CellText(wsResult.Cells(resultRow, 7).Value))
    personClassText = CashAnalysisTransferPersonClass(categoryText, routeText)
    isManualCandidate = CashAnalysisResultIsManual(wsResult, resultRow, manualStoredKey)
    If Len(personClassText) > 0 Then
        If Len(routeText) = 0 Then
            routeText = personClassText
        ElseIf InStr(1, routeText, personClassText, vbBinaryCompare) = 0 Then
            routeText = personClassText & "｜" & routeText
        End If
    End If
    If isManualCandidate Then
        If InStr(1, constraintText, "手動選定・未検証", vbBinaryCompare) = 0 Then _
            constraintText = CashAnalysisAppendText( _
                                 constraintText, "手動選定・未検証", " / ")
    End If
    If alternativeCount > 1 Then _
        constraintText = CashAnalysisAppendText( _
                             constraintText, _
                             "候補グループ" & CStr(alternativeCount) & _
                             "件中の代表候補", " / ")
    pointText = CashAnalysisAppendText( _
                    pointText, _
                    CashAnalysisReviewProgressText(unreviewedCount, followupCount), _
                    vbLf)
    ws.Range("F1").Value = CashAnalysisCompactHeader( _
                               categoryText, currentIndex, categoryCount, _
                               priorityText, 0, 0, isManualCandidate)
    ws.Range("C3").Value = statusText
    ws.Range("C5").Value = dateText
    ws.Range("H5").Value = routeText
    ws.Range("C6").Value = pointText
    ws.Range("C7").Value = constraintText
    ws.Range("C8").Value = CellText(wsResult.Cells(resultRow, ANALYSIS_RESULT_MEMO_COL).Value)
    SetShapeCaption ws, "CycleCashAnalysisViewMode", "表示: " & modeText
    If isManualCandidate Then
        SetShapeCaption ws, "CashAnalysisSecondaryAction", "手動候補を無効化"
        SetViewButtonColors ws, "CashAnalysisSecondaryAction", _
                            RGB(254, 242, 242), RGB(220, 38, 38), RGB(153, 27, 27)
    Else
        SetShapeCaption ws, "CashAnalysisSecondaryAction", "手動候補を選ぶ"
        SetViewButtonColors ws, "CashAnalysisSecondaryAction", _
                            RGB(255, 255, 255), RGB(203, 213, 225), RGB(30, 64, 175)
    End If
    ws.Range("C3:D3").Locked = ThisWorkbook.ReadOnly
    ws.Range("C8:M8").Locked = ThisWorkbook.ReadOnly
End Sub

Private Sub RenderCashAnalysisAlternativeCandidate( _
        ByVal ws As Worksheet, ByVal wsResult As Worksheet, _
        ByVal resultRow As Long, ByVal wsGroup As Worksheet, _
        ByVal groupRow As Long, ByVal currentIndex As Long, _
        ByVal categoryCount As Long, ByRef counts() As Long, _
        ByVal unreviewedCount As Long, ByVal followupCount As Long, _
        ByVal modeText As String)
    Dim categoryText As String, groupID As String, sourceSheet As String
    Dim sourceKey As String, txIDList As String, statusText As String, memoText As String
    Dim dateText As String, routeText As String, pointText As String, constraintText As String
    Dim priorityText As String, personClassText As String
    Dim sourceRow As Long, candidatePosition As Long, candidateCount As Long
    Dim isManualCandidate As Boolean
    Dim txPersonMap As Object

    If ws Is Nothing Or wsResult Is Nothing Or wsGroup Is Nothing Then _
        Err.Raise vbObjectError + 4992, "RenderCashAnalysisAlternativeCandidate", _
                  "代替候補の表示元を取得できません。"
    categoryText = CashViewCategoryForResult(CellText(wsResult.Cells(resultRow, 2).Value))
    If categoryText <> VIEW_CATEGORY_TRANSFER Then _
        Err.Raise vbObjectError + 4993, "RenderCashAnalysisAlternativeCandidate", _
                  "資金移動以外に代替候補が指定されています。"
    groupID = CellText(wsResult.Cells(resultRow, ANALYSIS_RESULT_GROUP_ID_COL).Value)
    ReadCashAnalysisAlternativeSource wsGroup, groupRow, groupID, _
        sourceSheet, sourceRow, sourceKey, txIDList, priorityText, statusText, memoText, _
        dateText, routeText, pointText, constraintText, isManualCandidate

    Set txPersonMap = CashAnalysisTransactionPersonMap()
    personClassText = CashAlternativePersonClass(txIDList, txPersonMap)
    routeText = personClassText & "｜" & routeText
    CashAnalysisGroupCandidatePosition wsGroup, groupID, groupRow, txPersonMap, _
                                       candidatePosition, candidateCount
    If candidatePosition < 2 Or candidateCount < candidatePosition Then _
        Err.Raise vbObjectError + 4994, "RenderCashAnalysisAlternativeCandidate", _
                  "代替候補の循環位置を確定できません。"
    If Not IsNumeric(wsResult.Cells(resultRow, _
                                    ANALYSIS_RESULT_ALTERNATIVE_COUNT_COL).Value) Then _
        Err.Raise vbObjectError + 4994, "RenderCashAnalysisAlternativeCandidate", _
                  "代替候補の表示件数が数値ではありません。"
    If CLng(wsResult.Cells(resultRow, _
                           ANALYSIS_RESULT_ALTERNATIVE_COUNT_COL).Value) <> candidateCount Then _
        Err.Raise vbObjectError + 4994, "RenderCashAnalysisAlternativeCandidate", _
                  "代替候補の表示件数と内部グループ件数が一致しません。"
    constraintText = CashAnalysisAppendText(constraintText, _
        "同じ取引を共有する代替仮説 " & CStr(candidateCount) & _
        "件。現在は代表とは別の仮説を表示しています。", " / ")
    If isManualCandidate Then
        If InStr(1, constraintText, "手動選定・未検証", vbBinaryCompare) = 0 Then _
            constraintText = CashAnalysisAppendText( _
                                 constraintText, "手動選定・未検証", " / ")
    End If
    pointText = CashAnalysisAppendText( _
                    CashAnalysisNormalizeTimeEvidenceText(pointText), _
                    CashAnalysisReviewProgressText(unreviewedCount, followupCount), _
                    vbLf)
    ws.Range("F1").Value = CashAnalysisCompactHeader( _
                               categoryText, currentIndex, categoryCount, _
                               priorityText, candidatePosition, candidateCount, _
                               isManualCandidate)
    ws.Range("C3").Value = statusText
    ws.Range("C5").Value = CashAnalysisNormalizeTimeEvidenceText(dateText)
    ws.Range("H5").Value = CashAnalysisNormalizeTimeEvidenceText(routeText)
    ws.Range("C6").Value = pointText
    ws.Range("C7").Value = CashAnalysisNormalizeTimeEvidenceText(constraintText)
    ws.Range("C8").Value = memoText
    SetShapeCaption ws, "CycleCashAnalysisViewMode", "表示: " & modeText
    If isManualCandidate Then
        SetShapeCaption ws, "CashAnalysisSecondaryAction", "手動候補を無効化"
        SetViewButtonColors ws, "CashAnalysisSecondaryAction", _
                            RGB(254, 242, 242), RGB(220, 38, 38), RGB(153, 27, 27)
    Else
        SetShapeCaption ws, "CashAnalysisSecondaryAction", "手動候補を選ぶ"
        SetViewButtonColors ws, "CashAnalysisSecondaryAction", _
                            RGB(255, 255, 255), RGB(203, 213, 225), RGB(30, 64, 175)
    End If
    ws.Range("C3:D3").Locked = ThisWorkbook.ReadOnly
    ws.Range("C8:M8").Locked = ThisWorkbook.ReadOnly
End Sub

Private Sub ReadCashAnalysisAlternativeSource( _
        ByVal wsGroup As Worksheet, ByVal groupRow As Long, ByVal expectedGroupID As String, _
        ByRef sourceSheet As String, ByRef sourceRow As Long, ByRef sourceKey As String, _
        ByRef txIDList As String, ByRef priorityText As String, ByRef statusText As String, _
        ByRef memoText As String, ByRef dateText As String, ByRef routeText As String, _
        ByRef pointText As String, ByRef constraintText As String, _
        ByRef isManualCandidate As Boolean)
    Dim wsSource As Worksheet, sourceLastRow As Long
    If wsGroup Is Nothing Then _
        Err.Raise vbObjectError + 4995, "ReadCashAnalysisAlternativeSource", _
                  "代替候補の内部表を取得できません。"
    If groupRow < 2 Or groupRow > LastUsedRowInSheet(wsGroup) Then _
        Err.Raise vbObjectError + 4995, "ReadCashAnalysisAlternativeSource", _
                  "代替候補の内部行が見つかりません。"
    RequireAnalysisReviewConstantRange _
        wsGroup.Range(wsGroup.Cells(groupRow, 1), _
                      wsGroup.Cells(groupRow, ANALYSIS_GROUP_LAST_COL)), _
        "代替候補の内部参照"
    If StrComp(CellText(wsGroup.Cells(groupRow, 1).Value), _
               expectedGroupID, vbBinaryCompare) <> 0 Or _
       StrComp(CellText(wsGroup.Cells(groupRow, 7).Value), _
               "代替", vbBinaryCompare) <> 0 Then _
        Err.Raise vbObjectError + 4996, "ReadCashAnalysisAlternativeSource", _
                  "表示中グループと代替候補の内部参照が一致しません。"

    sourceSheet = CellText(wsGroup.Cells(groupRow, 2).Value)
    sourceRow = CLng(Val(CellText(wsGroup.Cells(groupRow, 3).Value)))
    sourceKey = CellText(wsGroup.Cells(groupRow, 4).Value)
    txIDList = CellText(wsGroup.Cells(groupRow, 5).Value)
    priorityText = CellText(wsGroup.Cells(groupRow, 6).Value)
    If Len(sourceKey) = 0 Or Len(txIDList) = 0 Then _
        Err.Raise vbObjectError + 4997, "ReadCashAnalysisAlternativeSource", _
                  "代替候補の確認キーまたは構成取引IDがありません。"
    If Not SheetExists(sourceSheet) Then _
        Err.Raise vbObjectError + 4998, "ReadCashAnalysisAlternativeSource", _
                  "代替候補の内部元表がありません。"
    Set wsSource = GetSheet(sourceSheet)
    sourceLastRow = LastUsedRowInSheet(wsSource)
    If sourceRow < 2 Or sourceRow > sourceLastRow Then _
        Err.Raise vbObjectError + 4999, "ReadCashAnalysisAlternativeSource", _
                  "代替候補の内部元行がありません。"

    Select Case sourceSheet
        Case SH_ANALYSIS_SHIFT
            RequireAnalysisReviewConstantRange _
                wsSource.Range(wsSource.Cells(sourceRow, 1), _
                               wsSource.Cells(sourceRow, SHIFT_ANALYSIS_LAST_COL)), _
                "資金シフト代替候補"
            If StrComp(CellText(wsSource.Cells(sourceRow, SHIFT_ANALYSIS_KEY_COL).Value), _
                       sourceKey, vbBinaryCompare) <> 0 Then _
                Err.Raise vbObjectError + 5000, "ReadCashAnalysisAlternativeSource", _
                          "資金シフト代替候補の確認キーが一致しません。"
            statusText = CashAnalysisStatusOrDefault( _
                             wsSource.Cells(sourceRow, SHIFT_ANALYSIS_STATUS_COL).Value)
            memoText = CellText(wsSource.Cells(sourceRow, SHIFT_ANALYSIS_MEMO_COL).Value)
            dateText = CashAnalysisPeriodText(wsSource.Cells(sourceRow, 9).Value, _
                                              wsSource.Cells(sourceRow, 19).Value)
            routeText = CashAnalysisPartyAccount( _
                            wsSource.Cells(sourceRow, 11).Value, _
                            wsSource.Cells(sourceRow, 12).Value, _
                            wsSource.Cells(sourceRow, 13).Value, _
                            wsSource.Cells(sourceRow, 14).Value, _
                            wsSource.Cells(sourceRow, 15).Value, _
                            wsSource.Cells(sourceRow, 16).Value) & " ⇒ " & _
                        CashAnalysisPartyAccount( _
                            wsSource.Cells(sourceRow, 21).Value, _
                            wsSource.Cells(sourceRow, 22).Value, _
                            wsSource.Cells(sourceRow, 23).Value, _
                            wsSource.Cells(sourceRow, 24).Value, _
                            wsSource.Cells(sourceRow, 25).Value, _
                            wsSource.Cells(sourceRow, 26).Value)
            pointText = CellText(wsSource.Cells(sourceRow, 1).Value) & "・" & _
                        CellText(wsSource.Cells(sourceRow, 3).Value) & "・" & _
                        CellText(wsSource.Cells(sourceRow, 4).Value) & "。" & _
                        CellText(wsSource.Cells(sourceRow, 29).Value)
            constraintText = "時刻精度: " & CellText(wsSource.Cells(sourceRow, 5).Value) & _
                             " / 経過: " & CellText(wsSource.Cells(sourceRow, 6).Value) & _
                             " / 金額差: " & _
                             CashAnalysisAmountText(wsSource.Cells(sourceRow, 8).Value)
        Case SH_ANALYSIS_FLOW
            RequireAnalysisReviewConstantRange _
                wsSource.Range(wsSource.Cells(sourceRow, 1), _
                               wsSource.Cells(sourceRow, FLOW_ANALYSIS_LAST_COL)), _
                "資金フロー代替候補"
            If StrComp(CellText(wsSource.Cells(sourceRow, FLOW_ANALYSIS_KEY_COL).Value), _
                       sourceKey, vbBinaryCompare) <> 0 Then _
                Err.Raise vbObjectError + 5001, "ReadCashAnalysisAlternativeSource", _
                          "資金フロー代替候補の確認キーが一致しません。"
            statusText = CashAnalysisStatusOrDefault( _
                             wsSource.Cells(sourceRow, FLOW_ANALYSIS_STATUS_COL).Value)
            memoText = CellText(wsSource.Cells(sourceRow, FLOW_ANALYSIS_MEMO_COL).Value)
            dateText = CellText(wsSource.Cells(sourceRow, 6).Value)
            routeText = CellText(wsSource.Cells(sourceRow, 12).Value)
            pointText = CellText(wsSource.Cells(sourceRow, 3).Value) & "・" & _
                        CellText(wsSource.Cells(sourceRow, 4).Value) & "。" & _
                        CellText(wsSource.Cells(sourceRow, 16).Value)
            constraintText = "時刻精度: " & CellText(wsSource.Cells(sourceRow, 5).Value) & _
                             " / 起終点差: " & _
                             CashAnalysisAmountText(wsSource.Cells(sourceRow, 11).Value) & _
                             " / " & CellText(wsSource.Cells(sourceRow, 7).Value) & _
                             "段・" & CellText(wsSource.Cells(sourceRow, 8).Value) & "取引"
        Case Else
            Err.Raise vbObjectError + 5002, "ReadCashAnalysisAlternativeSource", _
                      "代替候補の内部元表が資金移動ではありません。"
    End Select
    isManualCandidate = CashAnalysisSourceIsManual(sourceSheet, sourceRow, sourceKey)
End Sub

Private Function CashAnalysisStatusOrDefault(ByVal valueIn As Variant) As String
    CashAnalysisStatusOrDefault = CellText(valueIn)
    If Len(CashAnalysisStatusOrDefault) = 0 Then _
        CashAnalysisStatusOrDefault = ANALYSIS_STATUS_UNREVIEWED
End Function

Private Function CashAnalysisPartyAccount( _
        ByVal personValue As Variant, ByVal relationshipValue As Variant, _
        ByVal bankValue As Variant, ByVal branchValue As Variant, _
        ByVal typeValue As Variant, ByVal numberValue As Variant) As String
    Dim personText As String, accountText As String
    personText = CellText(personValue)
    If Len(personText) > 0 And Len(CellText(relationshipValue)) > 0 Then _
        personText = personText & "（" & CellText(relationshipValue) & "）"
    If Len(personText) > 0 Then personText = personText & " "
    accountText = Trim$(CellText(bankValue) & " " & CellText(branchValue) & " " & _
                        CellText(typeValue) & " " & CellText(numberValue))
    CashAnalysisPartyAccount = Trim$(personText & accountText)
End Function

Private Function CashAnalysisPeriodText(ByVal firstDate As Variant, _
                                        ByVal secondDate As Variant) As String
    Dim firstValue As Date, secondValue As Date
    If Not IsDate(firstDate) Or Not IsDate(secondDate) Then
        CashAnalysisPeriodText = CashAlternativeDateText(firstDate) & " ～ " & _
                                 CashAlternativeDateText(secondDate)
        Exit Function
    End If
    firstValue = DateSerial(Year(CDate(firstDate)), Month(CDate(firstDate)), Day(CDate(firstDate)))
    secondValue = DateSerial(Year(CDate(secondDate)), Month(CDate(secondDate)), Day(CDate(secondDate)))
    If firstValue = secondValue Then
        CashAnalysisPeriodText = Format$(firstValue, "yyyy/m/d") & "（同日）"
    ElseIf firstValue < secondValue Then
        CashAnalysisPeriodText = Format$(firstValue, "yyyy/m/d") & " ～ " & _
                                 Format$(secondValue, "yyyy/m/d")
    Else
        CashAnalysisPeriodText = Format$(secondValue, "yyyy/m/d") & " ～ " & _
                                 Format$(firstValue, "yyyy/m/d")
    End If
End Function

Private Function CashAnalysisAmountText(ByVal valueIn As Variant) As String
    If IsError(valueIn) Or IsNull(valueIn) Or IsEmpty(valueIn) Then
        CashAnalysisAmountText = "要確認"
    ElseIf IsNumeric(valueIn) Then
        CashAnalysisAmountText = Format$(CDbl(valueIn), "#,##0.########")
    Else
        CashAnalysisAmountText = "要確認"
    End If
End Function

Private Function CashAnalysisAppendText(ByVal currentText As String, _
                                        ByVal newText As String, _
                                        ByVal separatorText As String) As String
    If Len(newText) = 0 Then
        CashAnalysisAppendText = currentText
    ElseIf Len(currentText) = 0 Then
        CashAnalysisAppendText = newText
    Else
        CashAnalysisAppendText = currentText & separatorText & newText
    End If
End Function

Private Function CashAnalysisReviewProgressText(ByVal unreviewedCount As Long, _
                                                ByVal followupCount As Long) As String
    If unreviewedCount < 0 Then unreviewedCount = 0
    If followupCount < 0 Then followupCount = 0
    CashAnalysisReviewProgressText = _
        "全区分: 未確認 " & CStr(unreviewedCount) & _
        "件 / 要追加調査 " & CStr(followupCount) & "件"
End Function

Private Function CashAnalysisCompactHeader( _
        ByVal categoryText As String, ByVal currentIndex As Long, _
        ByVal categoryCount As Long, ByVal priorityText As String, _
        Optional ByVal candidatePosition As Long = 0, _
        Optional ByVal candidateCount As Long = 0, _
        Optional ByVal isManualCandidate As Boolean = False) As String
    'F1は固定34ptの1行だけに収める。人物区分・根拠・全区分の確認進捗等は
    '既存のH5/C6/C7へ表示し、ここには現在位置と短い状態だけを残す。
    '呼出元の区分は4字以内。全ての件数がLong最大値でも、優先度8字を含め
    '最大66字なので、ShrinkToFitが極小文字へ縮小する長文を生成しない。
    Dim resultText As String, shortPriority As String
    If currentIndex < 0 Then currentIndex = 0
    If categoryCount < 0 Then categoryCount = 0
    resultText = Trim$(categoryText) & " " & CStr(currentIndex) & "/" & _
                 CStr(categoryCount)
    If candidatePosition > 0 Then
        If candidateCount >= candidatePosition Then _
            resultText = resultText & "｜代替 " & CStr(candidatePosition) & "/" & _
                         CStr(candidateCount)
    End If
    shortPriority = Trim$(Replace(Replace(priorityText, vbCr, " "), vbLf, " "))
    If Len(shortPriority) > 8 Then shortPriority = Left$(shortPriority, 8)
    If Len(shortPriority) > 0 Then resultText = resultText & "｜優先 " & shortPriority
    If isManualCandidate Then resultText = resultText & "｜手動"
    CashAnalysisCompactHeader = resultText
End Function

Private Function CashAnalysisTransferPersonClass(ByVal categoryText As String, _
                                                 ByVal routeText As String) As String
    If categoryText <> VIEW_CATEGORY_TRANSFER Then Exit Function
    If Left$(routeText, Len(VIEW_PERSON_DIFFERENT) + 1) = _
       VIEW_PERSON_DIFFERENT & "｜" Then
        CashAnalysisTransferPersonClass = VIEW_PERSON_DIFFERENT
    ElseIf Left$(routeText, Len(VIEW_PERSON_SAME) + 1) = VIEW_PERSON_SAME & "｜" Then
        CashAnalysisTransferPersonClass = VIEW_PERSON_SAME
    Else
        Err.Raise vbObjectError + 4975, "CashAnalysisTransferPersonClass", _
                  "資金移動候補に人物IDによる区分がありません。" & _
                  "氏名では代替できません。再分析してください。"
    End If
End Function

Private Function CashAnalysisNormalizeTimeEvidenceText(ByVal valueText As String) As String
    valueText = Replace(valueText, String$(2, "-") & ":" & String$(2, "-"), _
                        "時刻記載なし", 1, -1, vbBinaryCompare)
    valueText = Replace(valueText, "同日" & "・順序" & "未確定" & _
                        "（シフト" & "推定）", _
                        "同日内順序不明", 1, -1, vbBinaryCompare)
    valueText = Replace(valueText, "同日" & "・順序" & "未確定", _
                        "同日内順序不明", 1, -1, vbBinaryCompare)
    valueText = Replace(valueText, "同日" & "・順序不明", _
                        "同日内順序不明", 1, -1, vbBinaryCompare)
    valueText = Replace(valueText, "入力" & "順で" & "推定", _
                        "同日内順序不明", 1, -1, vbBinaryCompare)
    valueText = Replace(valueText, "入力" & "順" & "推定", _
                        "同日内順序不明", 1, -1, vbBinaryCompare)
    valueText = Replace(valueText, "一部時刻" & "不明", _
                        "一部時刻記載なし", 1, -1, vbBinaryCompare)
    valueText = Replace(valueText, "時刻" & "不明", _
                        "時刻記載なし", 1, -1, vbBinaryCompare)
    CashAnalysisNormalizeTimeEvidenceText = valueText
End Function


'シートを変更せず、S45の順序と前後循環が完全に対称であることを確認する。

Private Sub ClearCashAnalysisCandidatePanel(ByVal ws As Worksheet, ByVal categoryText As String, _
                                            ByRef counts() As Long, ByVal unreviewedCount As Long, _
                                            ByVal followupCount As Long)
    Dim countValue As Long
    Select Case categoryText
        Case VIEW_CATEGORY_TRANSFER: countValue = counts(1)
        Case VIEW_CATEGORY_UNKNOWN_WITHDRAW: countValue = counts(2)
        Case VIEW_CATEGORY_UNKNOWN_DEPOSIT: countValue = counts(3)
    End Select
    ws.Range("F1").Value = CashAnalysisCompactHeader( _
                               categoryText, 0, countValue, "")
    ws.Range(VIEW_STATE_GROUP_ID).ClearContents
    ws.Range(VIEW_STATE_RESULT_ROW).ClearContents
    ws.Range(VIEW_STATE_CANDIDATE_REF).ClearContents
    ws.Range("C3").Value = "候補なし"
    SetCashAnalysisTotals ws, 0, 0
    ws.Range("C5").Value = "－"
    ws.Range("H5").Value = "この区分には現在候補がありません。"
    ws.Range("C6").Value = CashAnalysisAppendText( _
                               "分析条件を変更した場合は、帳票・分析を再作成してください。", _
                               CashAnalysisReviewProgressText( _
                                   unreviewedCount, followupCount), _
                               vbLf)
    ws.Range("C7").Value = "候補なしは、取引なしを保証するものではありません。原資料も確認してください。"
    ws.Range("C8").Value = ""
    ws.Range("C3:D3").Locked = True
    ws.Range("C8:M8").Locked = True
    SetShapeCaption ws, "CycleCashAnalysisViewMode", "表示: 全取引"
    SetShapeCaption ws, "CashAnalysisSecondaryAction", "手動候補を選ぶ"
    SetViewButtonColors ws, "CashAnalysisSecondaryAction", _
                        RGB(255, 255, 255), RGB(203, 213, 225), RGB(30, 64, 175)
    SetShapeCaption ws, "CashAnalysisPrimaryAction", "候補なし"
End Sub

Private Sub ApplyCashAnalysisRowFilter(ByVal ws As Worksheet, ByVal txIDList As String, _
                                       ByVal modeText As String)
    Dim lastR As Long, data As Variant, displayData() As Variant, roleData() As Variant
    Dim wanted As Object, accounts As Object, personIDs As Object, txPersonMap As Object
    Dim txID As String, accountID As String, personID As String
    Dim r As Long, rowCount As Long, minDate As Double, maxDate As Double, transactionDateSerial As Double
    Dim relatedDays As Long, showRow As Boolean, withdrawal As Double, deposit As Double
    Dim candidateRow As Boolean
    Dim totalWithdrawal As Double, totalDeposit As Double

    lastR = CashAnalysisLastDataRow(ws)
    If lastR < CASH_VIEW_FIRST_DATA_ROW Then Exit Sub
    rowCount = lastR - CASH_VIEW_FIRST_DATA_ROW + 1
    data = ws.Range(ws.Cells(CASH_VIEW_FIRST_DATA_ROW, 1), _
                    ws.Cells(lastR, OUT_COL_RECORD_TYPE)).Value2
    ReDim displayData(1 To rowCount, 1 To 1)
    ReDim roleData(1 To rowCount, 1 To 1)
    Set wanted = IDsToDictionary(txIDList)
    Set accounts = CreateObject("Scripting.Dictionary")
    Set personIDs = CreateObject("Scripting.Dictionary")
    Set txPersonMap = CashAnalysisTransactionPersonMap()
    accounts.CompareMode = vbTextCompare
    personIDs.CompareMode = vbTextCompare

    For r = 1 To rowCount
        txID = CellText(data(r, OUT_COL_TRANSACTION_ID))
        If Len(txID) > 0 And wanted.Exists(txID) Then
            accountID = CellText(data(r, OUT_COL_ACCOUNT_ID))
            If Len(accountID) = 0 Then _
                Err.Raise vbObjectError + 4972, "ApplyCashAnalysisRowFilter", _
                          "候補取引 " & txID & " に口座IDがありません。"
            If Not txPersonMap.Exists(txID) Then _
                Err.Raise vbObjectError + 4973, "ApplyCashAnalysisRowFilter", _
                          "候補取引の人物IDをW_取引で確認できません: " & txID
            personID = CellText(txPersonMap(txID))
            accounts(accountID) = True
            personIDs(personID) = True
            If IsDate(data(r, OUT_COL_DATE)) Then
                transactionDateSerial = CDbl(CDate(data(r, OUT_COL_DATE)))
                If minDate = 0 Or transactionDateSerial < minDate Then minDate = transactionDateSerial
                If maxDate = 0 Or transactionDateSerial > maxDate Then maxDate = transactionDateSerial
            End If
        End If
    Next r

    If CellText(ws.Range(VIEW_STATE_CATEGORY).Value) = VIEW_CATEGORY_TRANSFER Then
        relatedDays = 30
        If IsNumeric(GetSheet(SH_CONFIG).Cells(ROW_CFG_ANALYSIS_DAY_WINDOW, COL_CFG_ANALYSIS_VALUE).Value) Then _
            relatedDays = Application.Max(relatedDays, _
                CLng(GetSheet(SH_CONFIG).Cells(ROW_CFG_ANALYSIS_DAY_WINDOW, COL_CFG_ANALYSIS_VALUE).Value))
    Else
        relatedDays = 365
    End If

    For r = 1 To rowCount
        txID = CellText(data(r, OUT_COL_TRANSACTION_ID))
        candidateRow = (Len(txID) > 0 And wanted.Exists(txID))
        showRow = False
        If modeText = VIEW_MODE_ALL Then
            showRow = True
        ElseIf modeText = VIEW_MODE_COMPONENT Then
            showRow = candidateRow
        ElseIf candidateRow Then
            showRow = True
        ElseIf IsDate(data(r, OUT_COL_DATE)) And minDate > 0 Then
                transactionDateSerial = CDbl(CDate(data(r, OUT_COL_DATE)))
                If transactionDateSerial >= minDate - relatedDays And _
                   transactionDateSerial <= maxDate + relatedDays Then
                    accountID = CellText(data(r, OUT_COL_ACCOUNT_ID))
                    personID = ""
                    If Len(txID) > 0 Then
                        If Not txPersonMap.Exists(txID) Then _
                            Err.Raise vbObjectError + 4974, "ApplyCashAnalysisRowFilter", _
                                      "関連取引の人物IDをW_取引で確認できません: " & txID
                        personID = CellText(txPersonMap(txID))
                    End If
                    If (Len(accountID) > 0 And accounts.Exists(accountID)) Or _
                       (Len(personID) > 0 And personIDs.Exists(personID)) Then showRow = True
                End If
            End If
        If showRow Then displayData(r, 1) = "1" Else displayData(r, 1) = "0"
        If candidateRow Then
            withdrawal = CashViewDouble(data(r, OUT_COL_WITHDRAW))
            deposit = CashViewDouble(data(r, OUT_COL_DEPOSIT))
            totalWithdrawal = totalWithdrawal + withdrawal
            totalDeposit = totalDeposit + deposit
            roleData(r, 1) = CashViewRole(withdrawal, deposit)
        End If
    Next r

    ws.Range(ws.Cells(CASH_VIEW_FIRST_DATA_ROW, CASH_VIEW_COL_DISPLAY), _
             ws.Cells(lastR, CASH_VIEW_COL_DISPLAY)).Value = displayData
    ws.Range(ws.Cells(CASH_VIEW_FIRST_DATA_ROW, CASH_VIEW_COL_ROLE), _
             ws.Cells(lastR, CASH_VIEW_COL_ROLE)).Value = roleData
    ws.Range(ws.Cells(CASH_VIEW_FIRST_DATA_ROW, CASH_VIEW_COL_SELECTED), _
             ws.Cells(lastR, CASH_VIEW_COL_SELECTED)).ClearContents
    ApplyCashViewAutoFilter ws, lastR, (modeText <> VIEW_MODE_ALL)
    '絞込み用に取得済みの配列を使い、合計のための全件再読込を省く。
    SetCashAnalysisTotals ws, totalWithdrawal, totalDeposit
End Sub

Private Function CashAnalysisTransactionPersonMap() As Object
    '候補・関連取引はW_取引の人物IDで束ね、氏名や口座名義で代替しない。
    Dim result As Object
    Dim ws As Worksheet
    Dim lastR As Long, r As Long
    Dim txValues As Variant, personValues As Variant, dataCount As Long
    Dim txID As String, personID As String
    Set result = CreateObject("Scripting.Dictionary")
    result.CompareMode = vbTextCompare
    If Not SheetExists(SH_WORK_TX) Then _
        Err.Raise vbObjectError + 4968, "CashAnalysisTransactionPersonMap", _
                  "W_取引がありません。人物ID索引を作成できません。"
    Set ws = GetSheet(SH_WORK_TX)
    lastR = LastUsedRowInSheet(ws)
    If lastR >= 2 Then
        dataCount = lastR - 1
        txValues = CashResultColumnValues( _
                       ws, 2, lastR, WORK_TX_COL_TRANSACTION_ID)
        personValues = CashResultColumnValues( _
                           ws, 2, lastR, WORK_TX_COL_PERSON_ID)
        For r = 1 To dataCount
            txID = CellText(txValues(r, 1))
            If Len(txID) > 0 Then
                If Not IsInternalIdValue(txID, "T") Then _
                    Err.Raise vbObjectError + 4968, "CashAnalysisTransactionPersonMap", _
                              "W_取引 " & CStr(r + 1) & "行目の取引ID形式が不正です: " & txID
                personID = CellText(personValues(r, 1))
                If Len(personID) = 0 Then _
                    Err.Raise vbObjectError + 4968, "CashAnalysisTransactionPersonMap", _
                              "W_取引 " & CStr(r + 1) & _
                              "行目に人物IDがありません。氏名では代替しません。"
                If Not IsInternalIdValue(personID, "P") Then _
                    Err.Raise vbObjectError + 4968, "CashAnalysisTransactionPersonMap", _
                              "W_取引 " & CStr(r + 1) & "行目の人物ID形式が不正です: " & personID
                If result.Exists(txID) Then
                    If StrComp(CellText(result(txID)), personID, vbTextCompare) <> 0 Then _
                        Err.Raise vbObjectError + 4968, "CashAnalysisTransactionPersonMap", _
                                  "同じ取引IDに異なる人物IDがあります: " & txID
                Else
                    result.Add txID, personID
                End If
            End If
        Next r
    End If
    Set CashAnalysisTransactionPersonMap = result
End Function


Private Sub SetCashAnalysisTotals(ByVal ws As Worksheet, ByVal totalWithdrawal As Double, _
                                  ByVal totalDeposit As Double)
    ws.Range("B4").Value = totalWithdrawal
    ws.Range("F4").Value = totalDeposit
    ws.Range("J4").Value = totalDeposit - totalWithdrawal
    ws.Range("B4:D4").NumberFormatLocal = "#,##0.########"
    ws.Range("F4:H4").NumberFormatLocal = "#,##0.########"
    ws.Range("J4:M4").NumberFormatLocal = "+#,##0.########;-#,##0.########;0"
End Sub

Private Sub ShowAllCashViewRows(ByVal ws As Worksheet)
    Dim lastR As Long
    lastR = CashAnalysisLastDataRow(ws)
    If lastR < CASH_VIEW_FIRST_DATA_ROW Then Exit Sub
    ws.Range(ws.Cells(CASH_VIEW_FIRST_DATA_ROW, CASH_VIEW_COL_DISPLAY), _
             ws.Cells(lastR, CASH_VIEW_COL_DISPLAY)).Value = "1"
    ws.Range(ws.Cells(CASH_VIEW_FIRST_DATA_ROW, CASH_VIEW_COL_ROLE), _
             ws.Cells(lastR, CASH_VIEW_COL_SELECTED)).ClearContents
    ApplyCashViewAutoFilter ws, lastR, False
End Sub

Private Sub ApplyCashViewAutoFilter(ByVal ws As Worksheet, ByVal lastR As Long, _
                                    ByVal filterComponents As Boolean)
    If ws.AutoFilterMode Then ws.AutoFilterMode = False
    ws.Range(ws.Cells(CASH_VIEW_HEADER_ROW, 1), _
             ws.Cells(lastR, CASH_VIEW_COL_SELECTED)).AutoFilter
    If filterComponents Then
        ws.Range(ws.Cells(CASH_VIEW_HEADER_ROW, 1), _
                 ws.Cells(lastR, CASH_VIEW_COL_SELECTED)).AutoFilter _
                 Field:=CASH_VIEW_COL_DISPLAY, Criteria1:="1"
    End If
End Sub

Private Function FindCashAnalysisResultRow(ByRef categoryValues As Variant, _
                                           ByRef groupValues As Variant, _
                                           ByVal categoryText As String, ByVal groupID As String, _
                                           ByRef currentIndex As Long, ByRef categoryCount As Long) As Long
    Dim itemCount As Long, r As Long, firstRow As Long, resultRow As Long
    Dim itemCategory As String, itemGroupID As String
    If Not IsArray(categoryValues) Or Not IsArray(groupValues) Then Exit Function
    itemCount = UBound(categoryValues, 1)
    For r = 1 To itemCount
        resultRow = r + 1
        itemCategory = CashViewCategoryForResult(CellText(categoryValues(r, 1)))
        If itemCategory = categoryText Then
            categoryCount = categoryCount + 1
            If firstRow = 0 Then firstRow = resultRow
            itemGroupID = CellText(groupValues(r, 1))
            If Len(groupID) > 0 And StrComp(itemGroupID, groupID, vbTextCompare) = 0 Then
                FindCashAnalysisResultRow = resultRow
                currentIndex = categoryCount
            End If
        End If
    Next r
    If FindCashAnalysisResultRow = 0 Then
        FindCashAnalysisResultRow = firstRow
        If firstRow > 0 Then currentIndex = 1
    End If
End Function

Private Sub UpdateCategoryButtonCaptions(ByVal ws As Worksheet, ByVal activeCategory As String, _
                                         ByRef counts() As Long)
    SetShapeCaption ws, "ShowCashAnalysisTransfers", _
        IIf(activeCategory = VIEW_CATEGORY_TRANSFER, "● ", "") & "資金移動 " & CStr(counts(1))
    SetShapeCaption ws, "ShowCashAnalysisUnknownWithdrawals", _
        IIf(activeCategory = VIEW_CATEGORY_UNKNOWN_WITHDRAW, "● ", "") & "不明出金 " & CStr(counts(2))
    SetShapeCaption ws, "ShowCashAnalysisUnknownDeposits", _
        IIf(activeCategory = VIEW_CATEGORY_UNKNOWN_DEPOSIT, "● ", "") & "不明入金 " & CStr(counts(3))
    SetCategoryButtonState ws, "ShowCashAnalysisTransfers", _
                           (activeCategory = VIEW_CATEGORY_TRANSFER), RGB(15, 118, 110), RGB(13, 148, 136)
    SetCategoryButtonState ws, "ShowCashAnalysisUnknownWithdrawals", _
                           (activeCategory = VIEW_CATEGORY_UNKNOWN_WITHDRAW), RGB(185, 28, 28), RGB(153, 27, 27)
    SetCategoryButtonState ws, "ShowCashAnalysisUnknownDeposits", _
                           (activeCategory = VIEW_CATEGORY_UNKNOWN_DEPOSIT), RGB(29, 78, 216), RGB(30, 64, 175)
End Sub

Private Sub SetCategoryButtonState(ByVal ws As Worksheet, ByVal macroName As String, _
                                   ByVal isActive As Boolean, ByVal activeFill As Long, _
                                   ByVal activeLine As Long)
    Dim shp As Shape
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    For Each shp In ws.Shapes
        If StrComp(ToolShapeActionName(shp), macroName, vbTextCompare) = 0 Then
            If isActive Then
                shp.Fill.ForeColor.RGB = activeFill
                shp.Line.ForeColor.RGB = activeLine
                shp.TextFrame.Characters.Font.Color = RGB(255, 255, 255)
                shp.Line.Weight = 1.2
            Else
                shp.Fill.ForeColor.RGB = RGB(248, 250, 252)
                shp.Line.ForeColor.RGB = RGB(203, 213, 225)
                shp.TextFrame.Characters.Font.Color = RGB(51, 65, 85)
                shp.Line.Weight = 0.8
            End If
            Exit For
        End If
    Next shp
    On Error GoTo 0
    SetCashViewPrintControlState ws, macroName, isActive, activeFill, activeLine
End Sub

Private Sub SetShapeCaption(ByVal ws As Worksheet, ByVal macroName As String, ByVal caption As String)
    Dim shp As Shape
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    For Each shp In ws.Shapes
        If StrComp(ToolShapeActionName(shp), macroName, vbTextCompare) = 0 Then
            shp.TextFrame.Characters.Text = caption
            shp.TextFrame.Characters.Font.Name = "Yu Gothic UI"
            shp.TextFrame.Characters.Font.Bold = True
            SetToolShapeAccessibleLabel shp, caption
            Exit For
        End If
    Next shp
    On Error GoTo 0
    SetCashViewPrintCaption ws, macroName, caption
End Sub

Private Sub SetViewButtonColors(ByVal ws As Worksheet, ByVal macroName As String, _
                                ByVal fillColor As Long, ByVal lineColor As Long, _
                                ByVal fontColor As Long)
    Dim shp As Shape
    If ws Is Nothing Then Exit Sub
    fontColor = ReadableFontColor(fillColor, fontColor)
    On Error Resume Next
    For Each shp In ws.Shapes
        If StrComp(ToolShapeActionName(shp), macroName, vbTextCompare) = 0 Then
            shp.Fill.ForeColor.RGB = fillColor
            shp.Line.ForeColor.RGB = lineColor
            shp.TextFrame.Characters.Font.Color = fontColor
            Exit For
        End If
    Next shp
    On Error GoTo 0
    If StrComp(macroName, "CycleCashAnalysisViewMode", vbTextCompare) = 0 Then _
        SetCashViewPrintControlColors ws.Range("G3:H3"), fillColor, lineColor, fontColor
End Sub

Private Sub SetCashViewPrintCaption(ByVal ws As Worksheet, ByVal macroName As String, _
                                    ByVal caption As String)
    Dim target As Range
    If ws Is Nothing Then Exit Sub
    Select Case macroName
        Case "ShowCashAnalysisTransfers": Set target = ws.Range("A2:C2")
        Case "ShowCashAnalysisUnknownWithdrawals": Set target = ws.Range("D2:F2")
        Case "ShowCashAnalysisUnknownDeposits": Set target = ws.Range("G2:I2")
        Case "CycleCashAnalysisViewMode": Set target = ws.Range("G3:H3")
    End Select
    If Not target Is Nothing Then target.Cells(1, 1).Value = caption
End Sub

Private Sub SetCashViewPrintControlState(ByVal ws As Worksheet, ByVal macroName As String, _
                                         ByVal isActive As Boolean, ByVal activeFill As Long, _
                                         ByVal activeLine As Long)
    Dim target As Range
    If ws Is Nothing Then Exit Sub
    Select Case macroName
        Case "ShowCashAnalysisTransfers": Set target = ws.Range("A2:C2")
        Case "ShowCashAnalysisUnknownWithdrawals": Set target = ws.Range("D2:F2")
        Case "ShowCashAnalysisUnknownDeposits": Set target = ws.Range("G2:I2")
    End Select
    If target Is Nothing Then Exit Sub
    If isActive Then
        SetCashViewPrintControlColors target, activeFill, activeLine, RGB(255, 255, 255)
    Else
        SetCashViewPrintControlColors target, RGB(248, 250, 252), RGB(203, 213, 225), RGB(51, 65, 85)
    End If
End Sub

Private Sub SetCashViewPrintControlColors(ByVal target As Range, ByVal fillColor As Long, _
                                          ByVal lineColor As Long, ByVal fontColor As Long)
    If target Is Nothing Then Exit Sub
    With target
        .Interior.Color = fillColor
        .Font.Color = fontColor
        .Font.Bold = True
        .Borders.LineStyle = xlContinuous
        .Borders.Color = lineColor
    End With
End Sub

Private Function CashAnalysisResultIsManual(ByVal wsResult As Worksheet, ByVal resultRow As Long, _
                                            ByRef storedKey As String) As Boolean
    Dim sourceSheet As String, sourceKey As String, sourceRow As Long
    If wsResult Is Nothing Then Exit Function
    If resultRow < 2 Or resultRow > LastUsedRowInSheet(wsResult) Then Exit Function
    sourceSheet = CellText( _
                      wsResult.Cells(resultRow, ANALYSIS_RESULT_SOURCE_SHEET_COL).Value)
    sourceRow = CLng(Val(CellText(wsResult.Cells(resultRow, ANALYSIS_RESULT_SOURCE_ROW_COL).Value)))
    sourceKey = CellText(wsResult.Cells(resultRow, ANALYSIS_RESULT_SOURCE_KEY_COL).Value)
    If CashAnalysisSourceIsManual(sourceSheet, sourceRow, sourceKey) Then
        storedKey = sourceKey
        CashAnalysisResultIsManual = True
    End If
End Function

Private Function CashAnalysisSourceIsManual( _
        ByVal sourceSheet As String, ByVal sourceRow As Long, _
        ByVal sourceKey As String) As Boolean
    Dim wsFlow As Worksheet
    If StrComp(sourceSheet, SH_ANALYSIS_FLOW, vbTextCompare) <> 0 Or _
       Not SheetExists(SH_ANALYSIS_FLOW) Then Exit Function
    Set wsFlow = GetSheet(SH_ANALYSIS_FLOW)
    If sourceRow < 2 Or sourceRow > LastUsedRowInSheet(wsFlow) Then Exit Function
    If StrComp(CellText(wsFlow.Cells(sourceRow, 3).Value), "手動指定", vbTextCompare) <> 0 Then Exit Function
    If Len(sourceKey) = 0 Or _
       StrComp(CellText(wsFlow.Cells(sourceRow, FLOW_ANALYSIS_KEY_COL).Value), _
               sourceKey, vbBinaryCompare) <> 0 Then Exit Function
    CashAnalysisSourceIsManual = True
End Function

Private Function CashAnalysisCurrentSourceReference( _
        ByVal ws As Worksheet, ByVal wsResult As Worksheet, _
        ByVal resultRow As Long, ByRef sourceSheet As String, _
        ByRef sourceRow As Long, ByRef sourceKey As String, _
        ByRef sourceCategory As String, ByRef isAlternative As Boolean) As Boolean
    Dim wsGroup As Worksheet, groupRow As Long
    Dim groupID As String, candidateRef As String
    If ws Is Nothing Or wsResult Is Nothing Then Exit Function
    If resultRow < 2 Or resultRow > LastUsedRowInSheet(wsResult) Then Exit Function
    groupID = CellText(ws.Range(VIEW_STATE_GROUP_ID).Value)
    If Len(groupID) = 0 Or _
       StrComp(CellText(wsResult.Cells(resultRow, ANALYSIS_RESULT_GROUP_ID_COL).Value), _
               groupID, vbTextCompare) <> 0 Then Exit Function
    candidateRef = CellText(ws.Range(VIEW_STATE_CANDIDATE_REF).Value)
    If Len(candidateRef) > 0 Then
        If Not SheetExists(SH_WORK_ANALYSIS_GROUP) Then Exit Function
        Set wsGroup = GetSheet(SH_WORK_ANALYSIS_GROUP)
        groupRow = FindCashAnalysisAlternativeRow(wsGroup, groupID, candidateRef)
        If groupRow = 0 Then Exit Function
        RequireAnalysisReviewConstantRange _
            wsGroup.Range(wsGroup.Cells(groupRow, 1), _
                          wsGroup.Cells(groupRow, ANALYSIS_GROUP_LAST_COL)), _
            "表示中の代替候補参照"
        sourceSheet = CellText(wsGroup.Cells(groupRow, 2).Value)
        sourceRow = CLng(Val(CellText(wsGroup.Cells(groupRow, 3).Value)))
        sourceKey = CellText(wsGroup.Cells(groupRow, 4).Value)
        sourceCategory = CellText(wsGroup.Cells(groupRow, 8).Value)
        isAlternative = True
    Else
        sourceSheet = CellText( _
            wsResult.Cells(resultRow, ANALYSIS_RESULT_SOURCE_SHEET_COL).Value)
        sourceRow = CLng(Val(CellText( _
            wsResult.Cells(resultRow, ANALYSIS_RESULT_SOURCE_ROW_COL).Value)))
        sourceKey = CellText( _
            wsResult.Cells(resultRow, ANALYSIS_RESULT_SOURCE_KEY_COL).Value)
        sourceCategory = CellText(wsResult.Cells(resultRow, 2).Value)
    End If
    CashAnalysisCurrentSourceReference = _
        (Len(sourceSheet) > 0 And sourceRow >= 2 And Len(sourceKey) > 0)
End Function

Private Sub RequireCashAnalysisGroupConfirmationAvailable( _
        ByVal groupID As String, ByVal currentCandidateRef As String, _
        ByVal proposedStatus As String)
    Dim wsGroup As Worksheet
    Dim lastR As Long, r As Long, sourceRow As Long
    Dim groupIDs As Variant, sourceSheets As Variant, sourceRows As Variant
    Dim sourceKeys As Variant, representativeFlags As Variant
    Dim otherRef As String, otherStatus As String, representativeText As String
    If proposedStatus <> ANALYSIS_STATUS_SHIFT_CONFIRMED Then Exit Sub
    If Len(groupID) = 0 Or Len(currentCandidateRef) = 0 Or _
       Not SheetExists(SH_WORK_ANALYSIS_GROUP) Then _
        Err.Raise vbObjectError + 5012, _
                  "RequireCashAnalysisGroupConfirmationAvailable", _
                  "確認対象グループまたは候補参照を取得できません。"
    Set wsGroup = GetSheet(SH_WORK_ANALYSIS_GROUP)
    lastR = LastUsedRowInSheet(wsGroup)
    If lastR < 2 Then _
        Err.Raise vbObjectError + 5013, _
                  "RequireCashAnalysisGroupConfirmationAvailable", _
                  "確認対象グループの内部一覧がありません。"
    groupIDs = CashResultColumnValues(wsGroup, 2, lastR, 1)
    sourceSheets = CashResultColumnValues(wsGroup, 2, lastR, 2)
    sourceRows = CashResultColumnValues(wsGroup, 2, lastR, 3)
    sourceKeys = CashResultColumnValues(wsGroup, 2, lastR, 4)
    representativeFlags = CashResultColumnValues(wsGroup, 2, lastR, 7)
    For r = 1 To lastR - 1
        If StrComp(CellText(groupIDs(r, 1)), groupID, vbBinaryCompare) = 0 Then
            representativeText = CellText(representativeFlags(r, 1))
            If StrComp(representativeText, "代表", vbBinaryCompare) <> 0 And _
               StrComp(representativeText, "代替", vbBinaryCompare) <> 0 Then _
                Err.Raise vbObjectError + 5014, _
                          "RequireCashAnalysisGroupConfirmationAvailable", _
                          "分析グループの代表区分が不正です。"
            sourceRow = CLng(Val(CellText(sourceRows(r, 1))))
            otherRef = CashAnalysisCandidateReference( _
                           CellText(sourceSheets(r, 1)), sourceRow, _
                           CellText(sourceKeys(r, 1)))
            If Len(otherRef) = 0 Then _
                Err.Raise vbObjectError + 5015, _
                          "RequireCashAnalysisGroupConfirmationAvailable", _
                          "分析グループの候補参照が不足しています。"
            If StrComp(otherRef, currentCandidateRef, vbBinaryCompare) <> 0 Then
                otherStatus = CashAnalysisSourceReviewStatus( _
                                  CellText(sourceSheets(r, 1)), sourceRow, _
                                  CellText(sourceKeys(r, 1)))
                If CashAnalysisConfirmationPairConflicts( _
                       proposedStatus, currentCandidateRef, otherRef, otherStatus) Then _
                    Err.Raise vbObjectError + 5016, _
                              "RequireCashAnalysisGroupConfirmationAvailable", _
                              "同じ調査グループの別候補が既に資金移動確認です。" & _
                              "先にその候補を要追加調査または対象外へ変更してください。"
            End If
        End If
    Next r
End Sub

Private Function CashAnalysisSourceReviewStatus( _
        ByVal sourceSheet As String, ByVal sourceRow As Long, _
        ByVal sourceKey As String) As String
    Dim wsSource As Worksheet, statusCol As Long, keyCol As Long
    If Not SheetExists(sourceSheet) Then _
        Err.Raise vbObjectError + 5017, "CashAnalysisSourceReviewStatus", _
                  "候補の内部元表がありません。"
    Select Case sourceSheet
        Case SH_ANALYSIS_SHIFT
            statusCol = SHIFT_ANALYSIS_STATUS_COL
            keyCol = SHIFT_ANALYSIS_KEY_COL
        Case SH_ANALYSIS_FLOW
            statusCol = FLOW_ANALYSIS_STATUS_COL
            keyCol = FLOW_ANALYSIS_KEY_COL
        Case Else
            Err.Raise vbObjectError + 5018, "CashAnalysisSourceReviewStatus", _
                      "資金移動候補以外が同じ調査グループに含まれています。"
    End Select
    Set wsSource = GetSheet(sourceSheet)
    If sourceRow < 2 Or sourceRow > LastUsedRowInSheet(wsSource) Then _
        Err.Raise vbObjectError + 5019, "CashAnalysisSourceReviewStatus", _
                  "候補の内部元行がありません。"
    RequireAnalysisReviewConstantRange Union( _
        wsSource.Cells(sourceRow, statusCol), wsSource.Cells(sourceRow, keyCol)), _
        "同一グループ候補の確認状態"
    If Len(sourceKey) = 0 Or _
       StrComp(CellText(wsSource.Cells(sourceRow, keyCol).Value), _
               sourceKey, vbBinaryCompare) <> 0 Then _
        Err.Raise vbObjectError + 5020, "CashAnalysisSourceReviewStatus", _
                  "候補の内部確認キーが一致しません。"
    CashAnalysisSourceReviewStatus = _
        CashAnalysisStatusOrDefault(wsSource.Cells(sourceRow, statusCol).Value)
End Function

Private Function CashAnalysisConfirmationPairConflicts( _
        ByVal proposedStatus As String, ByVal currentCandidateRef As String, _
        ByVal otherCandidateRef As String, ByVal otherStatus As String) As Boolean
    CashAnalysisConfirmationPairConflicts = _
        (proposedStatus = ANALYSIS_STATUS_SHIFT_CONFIRMED And _
         Len(currentCandidateRef) > 0 And Len(otherCandidateRef) > 0 And _
         StrComp(currentCandidateRef, otherCandidateRef, vbBinaryCompare) <> 0 And _
         otherStatus = ANALYSIS_STATUS_SHIFT_CONFIRMED)
End Function

Public Sub ShowCashAnalysisTransfers()
    SelectCashAnalysisCategory VIEW_CATEGORY_TRANSFER
End Sub

Public Sub ShowCashAnalysisUnknownWithdrawals()
    SelectCashAnalysisCategory VIEW_CATEGORY_UNKNOWN_WITHDRAW
End Sub

Public Sub ShowCashAnalysisUnknownDeposits()
    SelectCashAnalysisCategory VIEW_CATEGORY_UNKNOWN_DEPOSIT
End Sub

Private Sub SelectCashAnalysisCategory(ByVal categoryText As String)
    Dim ws As Worksheet
    Dim workbookWasSaved As Boolean
    Dim previousEvents As Boolean, eventsCaptured As Boolean
    Dim eventsRestoreAttempted As Boolean, eventsReadyForRecovery As Boolean
    Dim actionMutationStarted As Boolean, protectOK As Boolean
    Dim safeToRestoreEntry As Boolean
    Dim eventStateDetail As String, stopDetail As String
    Dim convergenceDetail As String
    Dim errorNumber As Long, errorSource As String, errorDescription As String
    If Not SheetExists(SH_OUTPUT_TX) Then Exit Sub
    If Not RequireCashAnalysisManualModeFinished("分析区分の切替") Then Exit Sub
    On Error GoTo EH
    Set ws = GetSheet(SH_OUTPUT_TX)
    workbookWasSaved = ThisWorkbook.Saved
    If Not TryGetCashAnalysisEnableEvents(previousEvents, eventStateDetail) Then _
        Err.Raise vbObjectError + 5122, "SelectCashAnalysisCategory", _
                  "Excelイベントの開始状態を取得できませんでした。 " & eventStateDetail
    eventsCaptured = True
    If Not TrySetCashAnalysisEnableEventsExact(False, eventStateDetail) Then _
        Err.Raise vbObjectError + 5123, "SelectCashAnalysisCategory", _
                  "分析区分切替前にExcelイベントを停止できませんでした。 " & eventStateDetail
    actionMutationStarted = True
    SyncCashAnalysisPanelReviewToWorkspace
    ws.Unprotect Password:=TOOL_PASSWORD
    ws.Range(VIEW_STATE_CATEGORY).Value = categoryText
    ws.Range(VIEW_STATE_GROUP_ID).ClearContents
    ws.Range(VIEW_STATE_CANDIDATE_REF).ClearContents
    ws.Range(VIEW_STATE_MODE).Value = VIEW_MODE_COMPONENT
    ws.Range(VIEW_STATE_MANUAL).Value = "0"
    ws.Range(VIEW_STATE_SELECTED_IDS).ClearContents
    ws.Range(VIEW_STATE_PANEL_EXPANDED).Value = "0"
    RefreshCashAnalysisPanel True
    If workbookWasSaved Then ThisWorkbook.Saved = True
    eventsRestoreAttempted = True
    If Not TryRestoreCashAnalysisEnableEvents( _
               previousEvents, "SelectCashAnalysisCategory", _
               eventStateDetail) Then _
        Err.Raise vbObjectError + 5124, _
                  "SelectCashAnalysisCategory", eventStateDetail
    eventsCaptured = False
    Exit Sub
EH:
    errorNumber = Err.Number
    errorSource = Err.Source
    errorDescription = Err.Description
    If IsCashAnalysisRecoveryFatal(errorNumber, errorSource) Then
        Call TryStopCashAnalysisEventsForRecovery(convergenceDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    If eventsCaptured Then
        If Not eventsRestoreAttempted Then _
            eventsReadyForRecovery = _
                TryStopCashAnalysisEventsForRecovery(stopDetail)
    End If
    If actionMutationStarted And Not eventsRestoreAttempted Then
        If eventsReadyForRecovery Then
            protectOK = TryProtectCashAnalysisViewAfterFailure( _
                            ws, "SelectCashAnalysisCategory", _
                            False, errorDescription)
            safeToRestoreEntry = _
                CashAnalysisOuterLeaseMayRestoreAfterProtection( _
                    protectOK, errorDescription)
        Else
            AppendCashAnalysisRollbackDetail errorDescription, _
                "Excelイベント停止を読戻し確認できないため、" & _
                "ブックの再保護とRecovery書込みを行いませんでした。 " & _
                stopDetail
        End If
    End If
    If eventsCaptured And Not eventsRestoreAttempted Then
        eventsRestoreAttempted = True
        If Not actionMutationStarted Or safeToRestoreEntry Then
            If Not TryRestoreCashAnalysisEnableEvents( _
                       previousEvents, _
                       "SelectCashAnalysisCategory/エラー終了", _
                       eventStateDetail) Then _
                AppendCashAnalysisRollbackDetail errorDescription, _
                    eventStateDetail
        ElseIf TryStopCashAnalysisEventsForRecovery(convergenceDetail) Then
            AppendCashAnalysisRollbackDetail errorDescription, _
                "再保護またはRecoveryを厳密確認できないため、" & _
                "開始時イベント値へ戻さずFalseで停止しました。"
        Else
            AppendCashAnalysisRollbackDetail errorDescription, _
                "安全状態を厳密確認できず、ExcelイベントのFalse収束にも" & _
                "失敗しました。現在状態は不明です: " & convergenceDetail
        End If
    End If
    eventsCaptured = False
    MsgBox "分析区分を切り替えられませんでした。" & vbCrLf & _
           "Err " & CStr(errorNumber) & ": " & errorDescription, vbExclamation
End Sub

Public Sub PreviousCashAnalysisCandidate()
    NavigateCashAnalysisCandidate -1
End Sub

Public Sub NextCashAnalysisCandidate()
    NavigateCashAnalysisCandidate 1
End Sub

Public Sub NextUnreviewedCashAnalysisGroup()
    NavigateCashAnalysisCandidate 1, True
End Sub

Private Sub NavigateCashAnalysisCandidate(ByVal direction As Long, _
                                          Optional ByVal unreviewedOnly As Boolean = False)
    Dim ws As Worksheet, wsResult As Worksheet, wsGroup As Worksheet
    Dim categoryText As String, groupID As String, candidateRef As String
    Dim entry As Variant, entries As Collection
    Dim i As Long, currentIndex As Long, nextIndex As Long
    Dim workbookWasSaved As Boolean
    Dim previousEvents As Boolean, eventsCaptured As Boolean
    Dim eventsRestoreAttempted As Boolean, eventsReadyForRecovery As Boolean
    Dim actionMutationStarted As Boolean, protectOK As Boolean
    Dim safeToRestoreEntry As Boolean
    Dim eventStateDetail As String, stopDetail As String
    Dim convergenceDetail As String
    Dim errorNumber As Long, errorSource As String, errorDescription As String
    Dim noUnreviewedGroups As Boolean
    If Not SheetExists(SH_OUTPUT_TX) Or Not SheetExists(SH_ANALYSIS_RESULT) Then Exit Sub
    If Not RequireCashAnalysisManualModeFinished("候補の切替") Then Exit Sub
    On Error GoTo EH
    Set ws = GetSheet(SH_OUTPUT_TX)
    Set wsResult = GetSheet(SH_ANALYSIS_RESULT)
    workbookWasSaved = ThisWorkbook.Saved
    If Not TryGetCashAnalysisEnableEvents(previousEvents, eventStateDetail) Then _
        Err.Raise vbObjectError + 5125, "NavigateCashAnalysisCandidate", _
                  "Excelイベントの開始状態を取得できませんでした。 " & eventStateDetail
    eventsCaptured = True
    If Not TrySetCashAnalysisEnableEventsExact(False, eventStateDetail) Then _
        Err.Raise vbObjectError + 5126, "NavigateCashAnalysisCandidate", _
                  "候補切替前にExcelイベントを停止できませんでした。 " & eventStateDetail
    actionMutationStarted = True
    SyncCashAnalysisPanelReviewToWorkspace
    If Not SheetExists(SH_WORK_ANALYSIS_GROUP) Then _
        Err.Raise vbObjectError + 5003, "NavigateCashAnalysisCandidate", _
                  "代替候補の内部一覧がありません。"
    Set wsGroup = GetSheet(SH_WORK_ANALYSIS_GROUP)
    ws.Unprotect Password:=TOOL_PASSWORD
    ws.Range(VIEW_STATE_MANUAL).Value = "0"
    categoryText = CellText(ws.Range(VIEW_STATE_CATEGORY).Value)
    groupID = CellText(ws.Range(VIEW_STATE_GROUP_ID).Value)
    candidateRef = CellText(ws.Range(VIEW_STATE_CANDIDATE_REF).Value)
    Set entries = BuildCashAnalysisNavigationEntries( _
                      wsResult, wsGroup, categoryText, _
                      CashAnalysisTransactionPersonMap())
    If entries.Count = 0 Then
        RefreshCashAnalysisPanel False
        GoTo CompleteAction
    End If
    For i = 1 To entries.Count
        entry = entries(i)
        If StrComp(CStr(entry(0)), groupID, vbTextCompare) = 0 And _
           StrComp(CStr(entry(1)), candidateRef, vbBinaryCompare) = 0 Then
            currentIndex = i
            Exit For
        End If
    Next i
    If currentIndex = 0 Then
        '再分析で代替だけが消えた場合は、同じグループの代表を現在位置とする。
        For i = 1 To entries.Count
            entry = entries(i)
            If StrComp(CStr(entry(0)), groupID, vbTextCompare) = 0 And _
               Len(CStr(entry(1))) = 0 Then
                currentIndex = i
                Exit For
            End If
        Next i
    End If
    If currentIndex = 0 Then currentIndex = 1
    nextIndex = CashAnalysisWrappedNavigationIndex(currentIndex, entries.Count, direction)
    If unreviewedOnly Then
        nextIndex = NextUnreviewedGroupIndex(wsResult, entries, currentIndex)
        If nextIndex = 0 Then
            noUnreviewedGroups = True
            RefreshCashAnalysisPanel False
            GoTo CompleteAction
        End If
    End If
    entry = entries(nextIndex)
    ws.Range(VIEW_STATE_GROUP_ID).Value = CStr(entry(0))
    If Len(CStr(entry(1))) = 0 Then
        ws.Range(VIEW_STATE_CANDIDATE_REF).ClearContents
    Else
        ws.Range(VIEW_STATE_CANDIDATE_REF).Value = CStr(entry(1))
    End If
    ws.Range(VIEW_STATE_PANEL_EXPANDED).Value = "0"
    RefreshCashAnalysisPanel True
CompleteAction:
    If workbookWasSaved Then ThisWorkbook.Saved = True
    eventsRestoreAttempted = True
    If Not TryRestoreCashAnalysisEnableEvents( _
               previousEvents, "NavigateCashAnalysisCandidate", _
               eventStateDetail) Then _
        Err.Raise vbObjectError + 5127, _
                  "NavigateCashAnalysisCandidate", eventStateDetail
    eventsCaptured = False
    If noUnreviewedGroups Then _
        MsgBox "この分析区分に未確認のグループはありません。" & vbCrLf & _
               "代替候補・要追加調査は「次へ」で確認できます。", vbInformation
    Exit Sub
EH:
    errorNumber = Err.Number
    errorSource = Err.Source
    errorDescription = Err.Description
    If IsCashAnalysisRecoveryFatal(errorNumber, errorSource) Then
        Call TryStopCashAnalysisEventsForRecovery(convergenceDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    If eventsCaptured Then
        If Not eventsRestoreAttempted Then _
            eventsReadyForRecovery = _
                TryStopCashAnalysisEventsForRecovery(stopDetail)
    End If
    If actionMutationStarted And Not eventsRestoreAttempted Then
        If eventsReadyForRecovery Then
            protectOK = TryProtectCashAnalysisViewAfterFailure( _
                            ws, "NavigateCashAnalysisCandidate", _
                            False, errorDescription)
            safeToRestoreEntry = _
                CashAnalysisOuterLeaseMayRestoreAfterProtection( _
                    protectOK, errorDescription)
        Else
            AppendCashAnalysisRollbackDetail errorDescription, _
                "Excelイベント停止を読戻し確認できないため、" & _
                "ブックの再保護とRecovery書込みを行いませんでした。 " & _
                stopDetail
        End If
    End If
    If eventsCaptured And Not eventsRestoreAttempted Then
        eventsRestoreAttempted = True
        If Not actionMutationStarted Or safeToRestoreEntry Then
            If Not TryRestoreCashAnalysisEnableEvents( _
                       previousEvents, _
                       "NavigateCashAnalysisCandidate/エラー終了", _
                       eventStateDetail) Then _
                AppendCashAnalysisRollbackDetail errorDescription, _
                    eventStateDetail
        ElseIf TryStopCashAnalysisEventsForRecovery(convergenceDetail) Then
            AppendCashAnalysisRollbackDetail errorDescription, _
                "再保護またはRecoveryを厳密確認できないため、" & _
                "開始時イベント値へ戻さずFalseで停止しました。"
        Else
            AppendCashAnalysisRollbackDetail errorDescription, _
                "安全状態を厳密確認できず、ExcelイベントのFalse収束にも" & _
                "失敗しました。現在状態は不明です: " & convergenceDetail
        End If
    End If
    eventsCaptured = False
    MsgBox "候補を切り替えられませんでした。" & vbCrLf & _
           "Err " & CStr(errorNumber) & ": " & errorDescription, vbExclamation
End Sub

Public Sub CycleCashAnalysisViewMode()
    Dim ws As Worksheet, modeText As String
    Dim workbookWasSaved As Boolean
    Dim previousEvents As Boolean, eventsCaptured As Boolean
    Dim eventsRestoreAttempted As Boolean, eventsReadyForRecovery As Boolean
    Dim actionMutationStarted As Boolean, protectOK As Boolean
    Dim safeToRestoreEntry As Boolean
    Dim eventStateDetail As String, stopDetail As String
    Dim convergenceDetail As String
    Dim errorNumber As Long, errorSource As String, errorDescription As String
    If Not SheetExists(SH_OUTPUT_TX) Then Exit Sub
    If Not RequireCashAnalysisManualModeFinished("表示範囲の切替") Then Exit Sub
    On Error GoTo EH
    Set ws = GetSheet(SH_OUTPUT_TX)
    If Len(CellText(ws.Range(VIEW_STATE_GROUP_ID).Value)) = 0 Then Exit Sub
    workbookWasSaved = ThisWorkbook.Saved
    If Not TryGetCashAnalysisEnableEvents(previousEvents, eventStateDetail) Then _
        Err.Raise vbObjectError + 5128, "CycleCashAnalysisViewMode", _
                  "Excelイベントの開始状態を取得できませんでした。 " & eventStateDetail
    eventsCaptured = True
    If Not TrySetCashAnalysisEnableEventsExact(False, eventStateDetail) Then _
        Err.Raise vbObjectError + 5129, "CycleCashAnalysisViewMode", _
                  "表示範囲切替前にExcelイベントを停止できませんでした。 " & eventStateDetail
    actionMutationStarted = True
    SyncCashAnalysisPanelReviewToWorkspace
    ws.Unprotect Password:=TOOL_PASSWORD
    modeText = CellText(ws.Range(VIEW_STATE_MODE).Value)
    Select Case modeText
        Case VIEW_MODE_COMPONENT: modeText = VIEW_MODE_RELATED
        Case VIEW_MODE_RELATED: modeText = VIEW_MODE_ALL
        Case Else: modeText = VIEW_MODE_COMPONENT
    End Select
    ws.Range(VIEW_STATE_MODE).Value = modeText
    RefreshCashAnalysisPanel True
    If workbookWasSaved Then ThisWorkbook.Saved = True
    eventsRestoreAttempted = True
    If Not TryRestoreCashAnalysisEnableEvents( _
               previousEvents, "CycleCashAnalysisViewMode", _
               eventStateDetail) Then _
        Err.Raise vbObjectError + 5130, _
                  "CycleCashAnalysisViewMode", eventStateDetail
    eventsCaptured = False
    Exit Sub
EH:
    errorNumber = Err.Number
    errorSource = Err.Source
    errorDescription = Err.Description
    If IsCashAnalysisRecoveryFatal(errorNumber, errorSource) Then
        Call TryStopCashAnalysisEventsForRecovery(convergenceDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    If eventsCaptured Then
        If Not eventsRestoreAttempted Then _
            eventsReadyForRecovery = _
                TryStopCashAnalysisEventsForRecovery(stopDetail)
    End If
    If actionMutationStarted And Not eventsRestoreAttempted Then
        If eventsReadyForRecovery Then
            protectOK = TryProtectCashAnalysisViewAfterFailure( _
                            ws, "CycleCashAnalysisViewMode", _
                            False, errorDescription)
            safeToRestoreEntry = _
                CashAnalysisOuterLeaseMayRestoreAfterProtection( _
                    protectOK, errorDescription)
        Else
            AppendCashAnalysisRollbackDetail errorDescription, _
                "Excelイベント停止を読戻し確認できないため、" & _
                "ブックの再保護とRecovery書込みを行いませんでした。 " & _
                stopDetail
        End If
    End If
    If eventsCaptured And Not eventsRestoreAttempted Then
        eventsRestoreAttempted = True
        If Not actionMutationStarted Or safeToRestoreEntry Then
            If Not TryRestoreCashAnalysisEnableEvents( _
                       previousEvents, _
                       "CycleCashAnalysisViewMode/エラー終了", _
                       eventStateDetail) Then _
                AppendCashAnalysisRollbackDetail errorDescription, _
                    eventStateDetail
        ElseIf TryStopCashAnalysisEventsForRecovery(convergenceDetail) Then
            AppendCashAnalysisRollbackDetail errorDescription, _
                "再保護またはRecoveryを厳密確認できないため、" & _
                "開始時イベント値へ戻さずFalseで停止しました。"
        Else
            AppendCashAnalysisRollbackDetail errorDescription, _
                "安全状態を厳密確認できず、ExcelイベントのFalse収束にも" & _
                "失敗しました。現在状態は不明です: " & convergenceDetail
        End If
    End If
    eventsCaptured = False
    MsgBox "表示範囲を切り替えられませんでした。" & vbCrLf & _
           "確認状況・確認メモも確認してください。" & vbCrLf & _
           "Err " & CStr(errorNumber) & ": " & errorDescription, vbExclamation
End Sub

Public Sub CashAnalysisSecondaryAction()
    Dim ws As Worksheet, wsResult As Worksheet
    Dim resultRow As Long, storedKey As String, sourceSheet As String
    Dim sourceRow As Long, sourceCategory As String, isAlternative As Boolean
    Dim entryEvents As Boolean, entryEventsCaptured As Boolean
    Dim eventsReady As Boolean, actionCompleted As Boolean
    Dim protectOK As Boolean, safeToRestoreEntry As Boolean
    Dim mutationDispatchStarted As Boolean, recoveryConfirmed As Boolean
    Dim protectionRecoveryAttempted As Boolean
    Dim protectionRecoveryFailed As Boolean
    Dim protectionRecoveryConfirmed As Boolean
    Dim rethrowRecoveryFatal As Boolean
    Dim protectRecoveryFatal As Boolean
    Dim sourceReferenceConfirmed As Boolean, sourceIsManual As Boolean
    Dim eventDetail As String, restoreDetail As String
    Dim protectErrorNumber As Long, protectErrorDescription As String
    Dim protectErrorSource As String
    Dim errorNumber As Long, errorSource As String, errorDescription As String
    If Not SheetExists(SH_OUTPUT_TX) Then Exit Sub
    On Error GoTo EH
    Set ws = GetSheet(SH_OUTPUT_TX)
    If Not TryGetCashAnalysisEnableEvents(entryEvents, eventDetail) Then
        StopAfterCashAnalysisEventStateFailure _
            "CashAnalysisSecondaryAction/開始状態取得", eventDetail, _
            eventsReady, False, vbNullString
        MsgBox "手動候補の操作を開始できませんでした。" & vbCrLf & _
               "Excelイベントの開始状態を取得できません。 " & eventDetail, _
               vbExclamation, "手動候補の操作は安全停止"
        Exit Sub
    End If
    entryEventsCaptured = True
    eventsReady = TryStopCashAnalysisEventsForRecovery(eventDetail)
    If Not eventsReady Then _
        Err.Raise vbObjectError + 5143, "CashAnalysisSecondaryAction", _
                  "手動候補の操作前にExcelイベント停止を確認できませんでした。 " & _
                  eventDetail
    mutationDispatchStarted = True
    If CellText(ws.Range(VIEW_STATE_MANUAL).Value) = "1" Then
        ClearCashAnalysisManualSelection True
    Else
        If SheetExists(SH_ANALYSIS_RESULT) Then
            Set wsResult = GetSheet(SH_ANALYSIS_RESULT)
            resultRow = CLng(Val(CellText(ws.Range(VIEW_STATE_RESULT_ROW).Value)))
        End If
        sourceReferenceConfirmed = _
            CashAnalysisCurrentSourceReference( _
                ws, wsResult, resultRow, sourceSheet, sourceRow, storedKey, _
                sourceCategory, isAlternative)
        If sourceReferenceConfirmed Then _
            sourceIsManual = _
                CashAnalysisSourceIsManual( _
                    sourceSheet, sourceRow, storedKey)
        If sourceIsManual Then
            SyncCashAnalysisPanelReviewToWorkspace
            DeactivateManualFlowCandidateByStoredKey storedKey
        Else
            EnterCashAnalysisManualMode
        End If
    End If
    actionCompleted = True
    safeToRestoreEntry = True
    GoTo CleanExit
EH:
    errorNumber = Err.Number
    errorSource = Err.Source
    errorDescription = Err.Description
    On Error GoTo 0
    If IsCashAnalysisRecoveryFatal(errorNumber, errorSource) Then
        Call TryStopCashAnalysisEventsForRecovery(eventDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    eventsReady = TryStopCashAnalysisEventsForRecovery(eventDetail)
    If Not mutationDispatchStarted Then
        safeToRestoreEntry = True
    ElseIf eventsReady Then
        On Error Resume Next
        Err.Clear
        protectOK = TryProtectCashAnalysisViewAfterFailure( _
                        ws, "CashAnalysisSecondaryAction", _
                        False, errorDescription, _
                        protectionRecoveryAttempted, _
                        protectionRecoveryFailed, _
                        protectionRecoveryConfirmed)
        protectErrorNumber = Err.Number
        protectErrorSource = Err.Source
        protectErrorDescription = Err.Description
        Err.Clear
        On Error GoTo 0
        protectRecoveryFatal = _
            IsCashAnalysisRecoveryFatal( _
                protectErrorNumber, protectErrorSource)
        If protectRecoveryFatal Then
            Call TryStopCashAnalysisEventsForRecovery(eventDetail)
            Err.Raise protectErrorNumber, protectErrorSource, _
                      protectErrorDescription
        End If
        If protectErrorNumber <> 0 Then _
            AppendCashAnalysisRollbackDetail errorDescription, _
                "再保護処理の予期しないエラー: Err " & _
                CStr(protectErrorNumber) & " " & protectErrorDescription
        If protectionRecoveryFailed Then
            rethrowRecoveryFatal = True
            errorNumber = vbObjectError + 5194
            errorSource = _
                "CashAnalysisRecoveryFatal/CashAnalysisSecondaryAction"
            safeToRestoreEntry = False
            GoTo CleanExit
        End If
        If Not protectOK And protectErrorNumber = 0 And _
           Len(Trim$(errorDescription)) = 0 Then _
            errorDescription = "資金操作表の再保護完了を確認できませんでした。"
        eventsReady = TryStopCashAnalysisEventsForRecovery(eventDetail)
        If Not eventsReady Then
            AppendCashAnalysisRollbackDetail errorDescription, _
                "再保護処理後にExcelイベント停止を確認できず、" & _
                "開始状態へ戻せる安全条件を確認できませんでした。 " & _
                eventDetail
        ElseIf protectOK Then
            safeToRestoreEntry = True
        ElseIf protectionRecoveryAttempted Then
            recoveryConfirmed = protectionRecoveryConfirmed
            safeToRestoreEntry = recoveryConfirmed
        End If
    Else
        AppendCashAnalysisRollbackDetail errorDescription, _
            "Excelイベント停止を確認できないため、再保護と" & _
            "Recovery状態の書込みを行いませんでした。 " & eventDetail
    End If
CleanExit:
    If entryEventsCaptured Then
        entryEventsCaptured = False
        If safeToRestoreEntry Then _
            safeToRestoreEntry = _
                CashAnalysisApplicationStateAllowsEntryRestore( _
                    entryEvents, errorDescription)
        If safeToRestoreEntry Then
            If Not TryRestoreCashAnalysisEnableEvents( _
                       entryEvents, "CashAnalysisSecondaryAction/終了処理", _
                       restoreDetail) Then
                If errorNumber = 0 Then errorNumber = vbObjectError + 5144
                AppendCashAnalysisRollbackDetail errorDescription, restoreDetail
                actionCompleted = False
            End If
        Else
            eventsReady = TryStopCashAnalysisEventsForRecovery(restoreDetail)
            If eventsReady Then
                If entryEvents Then
                    AppendCashAnalysisRollbackDetail errorDescription, _
                        "安全状態を確認できないため、開始値(True)へ戻さず" & _
                        "ExcelイベントをFalseで停止しました。"
                Else
                    AppendCashAnalysisRollbackDetail errorDescription, _
                        "安全状態を確認できないため、開始値(False)のまま" & _
                        "Excelイベントを停止しました。"
                End If
            Else
                AppendCashAnalysisRollbackDetail errorDescription, _
                    "安全状態を確認できず、ExcelイベントをFalseへ" & _
                    "収束させることもできませんでした。現在状態は不明です。 " & _
                    restoreDetail
            End If
            actionCompleted = False
        End If
    End If
    If actionCompleted Then Exit Sub
    If rethrowRecoveryFatal Then _
        Err.Raise errorNumber, errorSource, errorDescription
    MsgBox "手動候補の操作を完了できませんでした。" & vbCrLf & _
           "Err " & CStr(errorNumber) & ": " & errorDescription, vbExclamation
End Sub

Public Sub CashAnalysisPrimaryAction()
    Dim ws As Worksheet, statusText As String, proposedStatus As String
    Dim errorNumber As Long, errorSource As String, errorDescription As String
    Dim analysisTransactionStarted As Boolean, rollbackOK As Boolean
    Dim actionCompleted As Boolean, coreCompleted As Boolean
    Dim operationCommitted As Boolean
    Dim entryEvents As Boolean, entryEventsCaptured As Boolean
    Dim mutationDispatchStarted As Boolean, safeToRestoreEntry As Boolean
    Dim protectOK As Boolean
    Dim eventsReadyForRecovery As Boolean, recoveryConfirmed As Boolean
    Dim recoveryEnforcementFailed As Boolean
    Dim recoveryConfirmedThisAttempt As Boolean
    Dim protectionRecoveryAttempted As Boolean
    Dim protectionRecoveryFailed As Boolean
    Dim protectionRecoveryConfirmed As Boolean
    Dim rethrowRecoveryFatal As Boolean
    Dim protectRecoveryFatal As Boolean
    Dim rollbackDetail As String, eventDetail As String, restoreDetail As String
    Dim rollbackErrorNumber As Long, rollbackErrorDescription As String
    Dim rollbackErrorSource As String
    Dim protectErrorNumber As Long, protectErrorDescription As String
    Dim protectErrorSource As String
    If Not SheetExists(SH_OUTPUT_TX) Then Exit Sub
    On Error GoTo EH
    Set ws = GetSheet(SH_OUTPUT_TX)
    If Not TryGetCashAnalysisEnableEvents(entryEvents, eventDetail) Then
        StopAfterCashAnalysisEventStateFailure _
            "CashAnalysisPrimaryAction/開始状態取得", eventDetail, _
            eventsReadyForRecovery, False, vbNullString
        MsgBox "確認内容の保存を開始できませんでした。" & vbCrLf & _
               "Excelイベントの開始状態を取得できません。 " & eventDetail, _
               vbExclamation, "分析判断の保存は安全停止"
        Exit Sub
    End If
    entryEventsCaptured = True
    eventsReadyForRecovery = _
        TryStopCashAnalysisEventsForRecovery(eventDetail)
    If Not eventsReadyForRecovery Then _
        Err.Raise vbObjectError + 5145, "CashAnalysisPrimaryAction", _
                  "分析判断の保存前にExcelイベント停止を確認できませんでした。 " & _
                  eventDetail
    If CellText(ws.Range(VIEW_STATE_MANUAL).Value) = "1" Then
        mutationDispatchStarted = True
        RegisterCashAnalysisManualSelection
        coreCompleted = True
        actionCompleted = True
        GoTo CleanExit
    End If
    If Len(CellText(ws.Range(VIEW_STATE_GROUP_ID).Value)) = 0 Then
        coreCompleted = True
        actionCompleted = True
        GoTo CleanExit
    End If
    statusText = CellText(ws.Range("C3").Value)
    If Len(statusText) = 0 Or statusText = ANALYSIS_STATUS_UNREVIEWED Then
        proposedStatus = ConfirmedStatusForCashCategory(CellText(ws.Range(VIEW_STATE_CATEGORY).Value))
        If Len(proposedStatus) = 0 Then _
            Err.Raise vbObjectError + 4969, "CashAnalysisPrimaryAction", _
                      "現在の分析区分に対応する確認済み状態がありません。"
        If MsgBox("この候補を「" & proposedStatus & "」として保存しますか？" & vbCrLf & _
                  "元取引、出金・入金、確認メモをもう一度確認してください。", _
                  vbYesNo + vbQuestion + vbDefaultButton2, _
                  "確認状況の確定") <> vbYes Then
            coreCompleted = True
            actionCompleted = True
            GoTo CleanExit
        End If
        statusText = proposedStatus
        BeginAnalysisOperationTransaction "資金操作表から分析判断を保存"
        analysisTransactionStarted = True
        mutationDispatchStarted = True
        ws.Unprotect Password:=TOOL_PASSWORD
        ws.Range("C3").Value = statusText
    Else
        BeginAnalysisOperationTransaction "資金操作表から分析判断を保存"
        analysisTransactionStarted = True
        mutationDispatchStarted = True
        ws.Unprotect Password:=TOOL_PASSWORD
    End If
    SyncCashAnalysisPanelReviewToWorkspace
    CommitAnalysisOperationPendingReviews "資金操作表から分析判断を保存"
    RefreshCashAnalysisPanel False
    CommitAnalysisOperationTransaction
    analysisTransactionStarted = False
    operationCommitted = True
    coreCompleted = True
    actionCompleted = True
    safeToRestoreEntry = True
    GoTo CleanExit
EH:
    errorNumber = Err.Number
    errorSource = Err.Source
    errorDescription = Err.Description
    On Error GoTo 0
    If IsCashAnalysisRecoveryFatal(errorNumber, errorSource) Then
        Call TryStopCashAnalysisEventsForRecovery(eventDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    rollbackOK = True
    eventsReadyForRecovery = _
        TryStopCashAnalysisEventsForRecovery(eventDetail)
    If Not mutationDispatchStarted Then
        safeToRestoreEntry = True
        If Not eventsReadyForRecovery Then _
            AppendCashAnalysisRollbackDetail rollbackDetail, _
                "ブックへの変更開始前に失敗したため書込みはありません。" & _
                "終了時のイベント状態だけを開始値へ戻します。 " & eventDetail
    ElseIf Not eventsReadyForRecovery Then
        AppendCashAnalysisRollbackDetail rollbackDetail, _
            "Excelイベント停止を確認できないため、ロールバックと" & _
            "Recovery・チェック・状態の書込みを行いませんでした。 " & _
            eventDetail
        If analysisTransactionStarted Then rollbackOK = False
    ElseIf analysisTransactionStarted Then
        On Error Resume Next
        Err.Clear
        rollbackOK = RollbackAnalysisOperationTransaction(rollbackDetail)
        rollbackErrorNumber = Err.Number
        rollbackErrorSource = Err.Source
        rollbackErrorDescription = Err.Description
        Err.Clear
        On Error GoTo 0
        If IsCashAnalysisRecoveryFatal( _
               rollbackErrorNumber, rollbackErrorSource) Then
            Call TryStopCashAnalysisEventsForRecovery(eventDetail)
            Err.Raise rollbackErrorNumber, rollbackErrorSource, _
                      rollbackErrorDescription
        End If
        If rollbackErrorNumber <> 0 Then
            rollbackOK = False
            AppendCashAnalysisRollbackDetail rollbackDetail, _
                "分析操作トランザクションの復元エラー: Err " & _
                CStr(rollbackErrorNumber) & " " & rollbackErrorDescription
        End If

        '内側のロールバックは開始値(False)へ戻す設計だが、外側の
        'Recovery・チェック・状態書込みより前にもう一度読戻し確認する。
        eventsReadyForRecovery = _
            TryStopCashAnalysisEventsForRecovery(eventDetail)
        If Not eventsReadyForRecovery Then
            AppendCashAnalysisRollbackDetail rollbackDetail, _
                "ロールバック後にExcelイベント停止を確認できないため、" & _
                "外側のRecovery・チェック・状態書込みを行いませんでした。 " & _
                eventDetail
        ElseIf Not rollbackOK Then
            StopAfterCashAnalysisEventStateFailure _
                "CashAnalysisPrimaryAction/ロールバック", rollbackDetail, _
                eventsReadyForRecovery, True, _
                "外側イベント停止を読戻し確認済み", _
                recoveryEnforcementFailed, recoveryConfirmedThisAttempt
            recoveryConfirmed = recoveryConfirmedThisAttempt
            If recoveryEnforcementFailed Then
                rethrowRecoveryFatal = True
                errorNumber = vbObjectError + 5194
                errorSource = _
                    "CashAnalysisRecoveryFatal/CashAnalysisPrimaryAction"
                AppendCashAnalysisRollbackDetail errorDescription, rollbackDetail
                safeToRestoreEntry = False
                GoTo CleanExit
            End If
        End If
        If rollbackOK Then
            analysisTransactionStarted = False
            safeToRestoreEntry = True
        Else
            safeToRestoreEntry = _
                recoveryConfirmed And eventsReadyForRecovery
            If recoveryConfirmed Then
                AppendCashAnalysisRollbackDetail rollbackDetail, _
                    "分析操作トランザクションを完全には復元できず、" & _
                    "要復旧状態としての停止を確認しました。"
            Else
                AppendCashAnalysisRollbackDetail rollbackDetail, _
                    "分析操作トランザクションを完全には復元できず、" & _
                    "安全状態を一意に確認できません。"
            End If
        End If
    Else
        '手動候補側の入れ子処理が失敗した場合も、外側で再保護または
        'Recovery状態を厳密確認できた場合だけ開始時イベントへ戻す。
        On Error Resume Next
        Err.Clear
        protectOK = TryProtectCashAnalysisViewAfterFailure( _
                        ws, "CashAnalysisPrimaryAction", _
                        False, rollbackDetail, _
                        protectionRecoveryAttempted, _
                        protectionRecoveryFailed, _
                        protectionRecoveryConfirmed)
        protectErrorNumber = Err.Number
        protectErrorSource = Err.Source
        protectErrorDescription = Err.Description
        Err.Clear
        On Error GoTo 0
        protectRecoveryFatal = _
            IsCashAnalysisRecoveryFatal( _
                protectErrorNumber, protectErrorSource)
        If protectRecoveryFatal Then
            Call TryStopCashAnalysisEventsForRecovery(eventDetail)
            Err.Raise protectErrorNumber, protectErrorSource, _
                      protectErrorDescription
        End If
        If protectErrorNumber <> 0 Then _
            AppendCashAnalysisRollbackDetail rollbackDetail, _
                "再保護処理の予期しないエラー: Err " & _
                CStr(protectErrorNumber) & " " & protectErrorDescription
        eventsReadyForRecovery = _
            TryStopCashAnalysisEventsForRecovery(eventDetail)
        If Not eventsReadyForRecovery Then
            AppendCashAnalysisRollbackDetail rollbackDetail, _
                "再保護処理後にExcelイベント停止を確認できず、" & _
                "開始状態へ戻せる安全条件を確認できませんでした。 " & _
                eventDetail
        ElseIf protectionRecoveryAttempted Then
            rethrowRecoveryFatal = True
            errorNumber = vbObjectError + 5194
            errorSource = _
                "CashAnalysisRecoveryFatal/CashAnalysisPrimaryAction"
            AppendCashAnalysisRollbackDetail errorDescription, rollbackDetail
            safeToRestoreEntry = False
            GoTo CleanExit
        ElseIf protectOK Then
            safeToRestoreEntry = True
        ElseIf protectionRecoveryAttempted Then
            recoveryConfirmed = protectionRecoveryConfirmed
            safeToRestoreEntry = recoveryConfirmed
        End If
    End If
    If Len(rollbackDetail) > 0 Then _
        errorDescription = errorDescription & " / 復元確認: " & rollbackDetail
    actionCompleted = False
CleanExit:
    'ここより後はブックへ書き込まない。外側イベント状態の復元を
    '全処理の最後に行い、その後に許すUI処理はMsgBoxだけとする。
    If entryEventsCaptured Then
        entryEventsCaptured = False
        If actionCompleted And Not rethrowRecoveryFatal Then _
            safeToRestoreEntry = True
        If safeToRestoreEntry Then _
            safeToRestoreEntry = _
                CashAnalysisApplicationStateAllowsEntryRestore( _
                    entryEvents, errorDescription)
        If safeToRestoreEntry Then
            If Not TryRestoreCashAnalysisEnableEvents( _
                       entryEvents, "CashAnalysisPrimaryAction/終了処理", _
                       restoreDetail) Then
                If errorNumber = 0 Then errorNumber = vbObjectError + 5146
                If actionCompleted Then
                    errorDescription = _
                        "操作本体の終了後にExcelイベント状態を開始時へ" & _
                        "戻せませんでした。"
                End If
                AppendCashAnalysisRollbackDetail errorDescription, restoreDetail
                actionCompleted = False
            End If
        Else
            eventsReadyForRecovery = _
                TryStopCashAnalysisEventsForRecovery(restoreDetail)
            If eventsReadyForRecovery Then
                If entryEvents Then
                    AppendCashAnalysisRollbackDetail errorDescription, _
                        "安全状態を確認できないため、開始値(True)へ戻さず" & _
                        "ExcelイベントをFalseで停止しました。"
                Else
                    AppendCashAnalysisRollbackDetail errorDescription, _
                        "安全状態を確認できないため、開始値(False)のまま" & _
                        "Excelイベントを停止しました。"
                End If
            Else
                AppendCashAnalysisRollbackDetail errorDescription, _
                    "安全状態を確認できず、ExcelイベントをFalseへ" & _
                    "収束させることもできませんでした。現在状態は不明です。 " & _
                    restoreDetail
            End If
            actionCompleted = False
        End If
    End If
    If actionCompleted Then Exit Sub
    If rethrowRecoveryFatal Then
        If Len(errorSource) = 0 Then _
            errorSource = "CashAnalysisRecoveryFatal/CashAnalysisPrimaryAction"
        Err.Raise errorNumber, errorSource, errorDescription
    End If

    If operationCommitted Then
        MsgBox "確認内容の保存は完了しましたが、終了時のExcelイベント状態を" & _
               "開始時へ戻せませんでした。" & vbCrLf & _
               "現在のブックを上書きせず、表示された復旧情報を確認してください。" & _
               vbCrLf & "Err " & CStr(errorNumber) & ": " & errorDescription, _
               vbExclamation, "分析判断の保存後に要確認"
    ElseIf coreCompleted Then
        MsgBox "操作本体は終了しましたが、終了時のExcelイベント状態を" & _
               "開始時へ戻せませんでした。" & vbCrLf & _
               "Err " & CStr(errorNumber) & ": " & errorDescription, _
               vbExclamation, "資金操作表の終了状態を要確認"
    ElseIf analysisTransactionStarted And Not rollbackOK Then
        If recoveryConfirmed Then
            MsgBox "確認内容を保存できず、操作開始前の状態へ完全には戻せませんでした。" & _
                   vbCrLf & "案件を要復旧として停止しました。現在のブックを上書きしないでください。" & vbCrLf & _
                   "Err " & CStr(errorNumber) & ": " & errorDescription, _
                   vbExclamation, "分析判断の保存は要復旧"
        Else
            MsgBox "確認内容を保存できず、操作開始前の状態へ完全には戻せませんでした。" & _
                   vbCrLf & "安全状態を一意に確認できず、通常操作へ戻せません。" & _
                   "現在のブックを上書きしないでください。" & vbCrLf & _
                   "Err " & CStr(errorNumber) & ": " & errorDescription, _
                   vbExclamation, "分析判断の保存は安全状態未確認"
        End If
    Else
        MsgBox "確認内容を保存できませんでした。" & vbCrLf & _
               "確認状況・確認メモを見直してください。" & vbCrLf & _
               "Err " & CStr(errorNumber) & ": " & errorDescription, vbExclamation
    End If
End Sub

Private Sub EnterCashAnalysisManualMode()
    Dim ws As Worksheet
    Dim workbookWasSaved As Boolean
    Dim previousEvents As Boolean, eventsCaptured As Boolean
    Dim eventsRestoreAttempted As Boolean, eventsReadyForRecovery As Boolean
    Dim actionMutationStarted As Boolean, protectOK As Boolean
    Dim safeToRestoreEntry As Boolean
    Dim eventStateDetail As String, stopDetail As String
    Dim convergenceDetail As String
    Dim errorNumber As Long, errorSource As String, errorDescription As String
    If ThisWorkbook.ReadOnly Then
        MsgBox "読み取り専用では手動候補を登録できません。", vbExclamation
        Exit Sub
    End If
    On Error GoTo EH
    Set ws = GetSheet(SH_OUTPUT_TX)
    workbookWasSaved = ThisWorkbook.Saved
    If Not TryGetCashAnalysisEnableEvents(previousEvents, eventStateDetail) Then _
        Err.Raise vbObjectError + 5134, "EnterCashAnalysisManualMode", _
                  "Excelイベントの開始状態を取得できませんでした。 " & eventStateDetail
    eventsCaptured = True
    If Not TrySetCashAnalysisEnableEventsExact(False, eventStateDetail) Then _
        Err.Raise vbObjectError + 5135, "EnterCashAnalysisManualMode", _
                  "手動選択モード開始前にExcelイベントを停止できませんでした。 " & eventStateDetail
    actionMutationStarted = True
    SyncCashAnalysisPanelReviewToWorkspace
    ws.Unprotect Password:=TOOL_PASSWORD
    ws.Range(VIEW_STATE_MANUAL).Value = "1"
    ws.Range(VIEW_STATE_SELECTED_IDS).ClearContents
    ws.Range(VIEW_STATE_PANEL_EXPANDED).Value = "0"
    RefreshCashAnalysisPanel False
    If workbookWasSaved Then ThisWorkbook.Saved = True
    eventsRestoreAttempted = True
    If Not TryRestoreCashAnalysisEnableEvents( _
               previousEvents, "EnterCashAnalysisManualMode", _
               eventStateDetail) Then _
        Err.Raise vbObjectError + 5136, _
                  "EnterCashAnalysisManualMode", eventStateDetail
    eventsCaptured = False
    MsgBox "手動候補の選択モードに切り替えました。" & vbCrLf & _
           "資金操作表の取引行をダブルクリックして選択してください。" & vbCrLf & _
           "摘要L列をダブルクリックすると、選択を変えずに全文を確認できます。" & vbCrLf & _
           "出金と入金は別々に集計され、上部で差額も確認できます。", _
           vbInformation, "手動候補の選択"
    Exit Sub
EH:
    errorNumber = Err.Number
    errorSource = Err.Source
    errorDescription = Err.Description
    If IsCashAnalysisRecoveryFatal(errorNumber, errorSource) Then
        Call TryStopCashAnalysisEventsForRecovery(convergenceDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    If eventsCaptured Then
        If Not eventsRestoreAttempted Then _
            eventsReadyForRecovery = _
                TryStopCashAnalysisEventsForRecovery(stopDetail)
    End If
    If actionMutationStarted And Not eventsRestoreAttempted Then
        If eventsReadyForRecovery Then
            protectOK = TryProtectCashAnalysisViewAfterFailure( _
                            ws, "EnterCashAnalysisManualMode", _
                            False, errorDescription)
            safeToRestoreEntry = _
                CashAnalysisOuterLeaseMayRestoreAfterProtection( _
                    protectOK, errorDescription)
        Else
            AppendCashAnalysisRollbackDetail errorDescription, _
                "Excelイベント停止を読戻し確認できないため、" & _
                "ブックの再保護とRecovery書込みを行いませんでした。 " & _
                stopDetail
        End If
    End If
    If eventsCaptured And Not eventsRestoreAttempted Then
        eventsRestoreAttempted = True
        If Not actionMutationStarted Or safeToRestoreEntry Then
            If Not TryRestoreCashAnalysisEnableEvents( _
                       previousEvents, _
                       "EnterCashAnalysisManualMode/エラー終了", _
                       eventStateDetail) Then _
                AppendCashAnalysisRollbackDetail errorDescription, _
                    eventStateDetail
        ElseIf TryStopCashAnalysisEventsForRecovery(convergenceDetail) Then
            AppendCashAnalysisRollbackDetail errorDescription, _
                "再保護またはRecoveryを厳密確認できないため、" & _
                "開始時イベント値へ戻さずFalseで停止しました。"
        Else
            AppendCashAnalysisRollbackDetail errorDescription, _
                "安全状態を厳密確認できず、ExcelイベントのFalse収束にも" & _
                "失敗しました。現在状態は不明です: " & convergenceDetail
        End If
    End If
    eventsCaptured = False
    If Len(errorSource) = 0 Then errorSource = "EnterCashAnalysisManualMode"
    Err.Raise errorNumber, errorSource, errorDescription
End Sub

Private Sub RefreshCashManualSelectionPanel(ByVal ws As Worksheet)
    Dim selected As Object, validSelected As Object, lastR As Long, data As Variant
    Dim displayData() As Variant, roleData() As Variant, selectionData() As Variant
    Dim r As Long, rowCount As Long, txID As String, roleText As String
    Dim withdrawal As Double, deposit As Double, totalWithdrawal As Double, totalDeposit As Double
    Dim outCount As Long, inCount As Long
    Set selected = IDsToDictionary(CellText(ws.Range(VIEW_STATE_SELECTED_IDS).Value))
    Set validSelected = CreateObject("Scripting.Dictionary")
    validSelected.CompareMode = vbTextCompare
    lastR = CashAnalysisLastDataRow(ws)
    If lastR >= CASH_VIEW_FIRST_DATA_ROW Then
        data = ws.Range(ws.Cells(CASH_VIEW_FIRST_DATA_ROW, 1), _
                        ws.Cells(lastR, OUT_COL_RECORD_TYPE)).Value2
        rowCount = UBound(data, 1)
        ReDim displayData(1 To rowCount, 1 To 1)
        ReDim roleData(1 To rowCount, 1 To 1)
        ReDim selectionData(1 To rowCount, 1 To 1)
        For r = 1 To rowCount
            displayData(r, 1) = "1"
            txID = CellText(data(r, OUT_COL_TRANSACTION_ID))
            If Len(txID) > 0 And selected.Exists(txID) And _
               StrComp(CellText(data(r, OUT_COL_RECORD_TYPE)), RECORD_TRANSACTION, vbTextCompare) = 0 Then
                validSelected(txID) = True
                withdrawal = CashViewDouble(data(r, OUT_COL_WITHDRAW))
                deposit = CashViewDouble(data(r, OUT_COL_DEPOSIT))
                roleText = CashViewRole(withdrawal, deposit)
                roleData(r, 1) = roleText
                selectionData(r, 1) = "1"
                AccumulateCashManualTotals withdrawal, deposit, totalWithdrawal, _
                                           totalDeposit, outCount, inCount
            End If
        Next r
        ws.Range(ws.Cells(CASH_VIEW_FIRST_DATA_ROW, CASH_VIEW_COL_DISPLAY), _
                 ws.Cells(lastR, CASH_VIEW_COL_DISPLAY)).Value = displayData
        ws.Range(ws.Cells(CASH_VIEW_FIRST_DATA_ROW, CASH_VIEW_COL_ROLE), _
                 ws.Cells(lastR, CASH_VIEW_COL_ROLE)).Value = roleData
        ws.Range(ws.Cells(CASH_VIEW_FIRST_DATA_ROW, CASH_VIEW_COL_SELECTED), _
                 ws.Cells(lastR, CASH_VIEW_COL_SELECTED)).Value = selectionData
        ApplyCashViewAutoFilter ws, lastR, False
    End If
    Set selected = validSelected
    ws.Range(VIEW_STATE_SELECTED_IDS).Value = JoinCashDictionaryKeys(selected)

    ws.Range("F1").Value = "手動候補を選択中　選択 " & CStr(selected.Count) & _
                           "件（出金 " & CStr(outCount) & "件 / 入金 " & CStr(inCount) & "件）"
    ws.Range("C3").Value = "選択中"
    SetCashAnalysisTotals ws, totalWithdrawal, totalDeposit
    ws.Range("C5").Value = "行をダブルクリック（摘要L列は全文表示）"
    ws.Range("H5").Value = "出金と入金をそれぞれ1件以上選択してください。"
    ws.Range("C6").Value = "摘要L列以外をダブルクリックすると選択／解除します。選択行は淡い黄色で表示し、出金額と入金額は別欄のまま集計します。"
    ws.Range("C7").Value = "登録前に、日付・口座・摘要と差額を元取引上で確認してください。"
    ws.Range("C8").Value = ""
    ws.Range("C3:D3").Locked = True
    ws.Range("C8:M8").Locked = True
    SetShapeCaption ws, "CycleCashAnalysisViewMode", "表示: 全取引"
    SetShapeCaption ws, "CashAnalysisSecondaryAction", "選択を取り消す"
    SetViewButtonColors ws, "CashAnalysisSecondaryAction", _
                        RGB(254, 242, 242), RGB(220, 38, 38), RGB(153, 27, 27)
    SetShapeCaption ws, "CashAnalysisPrimaryAction", "選択した候補を登録"
    '直前候補の確認済み・対象外・候補なし色を引き継がない。
    '手動選択では登録という同じ操作を常に同じ青色で示す。
    SetViewButtonColors ws, "CashAnalysisPrimaryAction", _
                        RGB(37, 99, 235), RGB(29, 78, 216), RGB(255, 255, 255)
End Sub

Public Sub OnCashAnalysisViewDoubleClick(ByVal targetRow As Long, _
                                         Optional ByVal targetColumn As Long = 0)
    Dim ws As Worksheet, txID As String
    If Not SheetExists(SH_OUTPUT_TX) Then Exit Sub
    Set ws = GetSheet(SH_OUTPUT_TX)
    If targetRow < CASH_VIEW_FIRST_DATA_ROW Or targetRow > CashAnalysisLastDataRow(ws) Then Exit Sub
    If StrComp(CellText(ws.Cells(targetRow, OUT_COL_RECORD_TYPE).Value), _
               RECORD_TRANSACTION, vbTextCompare) <> 0 Then Exit Sub
    txID = CellText(ws.Cells(targetRow, OUT_COL_TRANSACTION_ID).Value)
    If Len(txID) = 0 Then Exit Sub
    If targetColumn = OUT_COL_TEKIYO Then
        ShowCashAnalysisTransactionText ws, targetRow
    ElseIf CellText(ws.Range(VIEW_STATE_MANUAL).Value) = "1" Then
        ToggleCashManualTransaction ws, txID
    Else
        FocusCashAnalysisCandidateByTransaction ws, txID
    End If
End Sub

Private Sub ShowCashAnalysisTransactionText(ByVal ws As Worksheet, ByVal targetRow As Long)
    Dim dateText As String, timeText As String, amountText As String, promptText As String
    If ws Is Nothing Then Exit Sub
    If IsDate(ws.Cells(targetRow, OUT_COL_DATE).Value) Then _
        dateText = Format$(CDate(ws.Cells(targetRow, OUT_COL_DATE).Value), "yyyy/m/d")
    If IsDate(ws.Cells(targetRow, OUT_COL_TIME).Value) Then _
        timeText = Format$(CDate(ws.Cells(targetRow, OUT_COL_TIME).Value), "hh:mm")
    If Len(timeText) = 0 Then timeText = "時刻記載なし"
    If CashViewDouble(ws.Cells(targetRow, OUT_COL_WITHDRAW).Value) <> 0 Then
        amountText = "出金 " & Format$(CashViewDouble(ws.Cells(targetRow, OUT_COL_WITHDRAW).Value), "#,##0.########")
    ElseIf CashViewDouble(ws.Cells(targetRow, OUT_COL_DEPOSIT).Value) <> 0 Then
        amountText = "入金 " & Format$(CashViewDouble(ws.Cells(targetRow, OUT_COL_DEPOSIT).Value), "#,##0.########")
    Else
        amountText = "金額 0"
    End If
    promptText = "日付・時刻: " & dateText & " " & timeText & vbCrLf & _
                 "口座: " & CellText(ws.Cells(targetRow, OUT_COL_BANK).Value) & " " & _
                 CellText(ws.Cells(targetRow, OUT_COL_BRANCH).Value) & " / " & _
                 CellText(ws.Cells(targetRow, OUT_COL_PERSON).Value) & vbCrLf & _
                 "金額: " & amountText & vbCrLf & _
                 "取扱店・機番: " & CellText(ws.Cells(targetRow, OUT_COL_SHOP).Value) & " " & _
                 CellText(ws.Cells(targetRow, OUT_COL_MACHINE).Value) & vbCrLf & vbCrLf & _
                 "摘要欄" & vbCrLf & CellText(ws.Cells(targetRow, OUT_COL_TEKIYO).Value)
    ShowCashAnalysisLongMessage promptText, "取引の摘要を全文表示"
End Sub

Public Sub ShowCashAnalysisPanelText(ByVal targetRow As Long)
    Dim ws As Worksheet, titleText As String, promptText As String, alternativeText As String
    If Not SheetExists(SH_OUTPUT_TX) Then Exit Sub
    Set ws = GetSheet(SH_OUTPUT_TX)
    Select Case targetRow
        Case 5
            titleText = "日付・人物・資金経路を全文表示"
            promptText = "日付・期間" & vbCrLf & CellText(ws.Range("C5").Value) & _
                         vbCrLf & vbCrLf & "人物・資金経路" & vbCrLf & _
                         CellText(ws.Range("H5").Value)
        Case 6
            titleText = "抽出理由・要点を全文表示"
            promptText = CellText(ws.Range("C6").Value)
        Case 7
            titleText = "反証・制約を全文表示"
            promptText = CellText(ws.Range("C7").Value)
            alternativeText = CashAnalysisAlternativePanelText(ws)
            If Len(alternativeText) > 0 Then _
                promptText = promptText & vbCrLf & vbCrLf & alternativeText
        Case Else
            Exit Sub
    End Select
    If Len(promptText) = 0 Then promptText = "（表示する内容はありません）"
    ShowCashAnalysisLongMessage promptText, titleText
End Sub

Private Function NextUnreviewedGroupIndex(ByVal wsResult As Worksheet, _
                                          ByVal entries As Collection, _
                                          ByVal currentIndex As Long) As Long
    '未確認数と同じ単位（代表グループ）で移動。代替候補は通常の前後移動で確認する。
    '確認状況を一括取得し、候補数に比例したセルアクセスを避ける。
    Dim pending As Object, groupValues As Variant, statusValues As Variant
    Dim lastR As Long, r As Long, offset As Long, index As Long
    Dim groupID As String, statusText As String, entry As Variant
    Set pending = CreateObject("Scripting.Dictionary")
    pending.CompareMode = vbTextCompare
    lastR = LastUsedRowInSheet(wsResult)
    If lastR < 2 Or entries.Count = 0 Then Exit Function
    groupValues = CashResultColumnValues(wsResult, 2, lastR, ANALYSIS_RESULT_GROUP_ID_COL)
    statusValues = CashResultColumnValues(wsResult, 2, lastR, ANALYSIS_RESULT_STATUS_COL)
    For r = 1 To lastR - 1
        groupID = CellText(groupValues(r, 1))
        statusText = CellText(statusValues(r, 1))
        If Len(groupID) > 0 Then
            If Len(statusText) = 0 Or statusText = ANALYSIS_STATUS_UNREVIEWED Then _
                pending(groupID) = True
        End If
    Next r
    For offset = 1 To entries.Count
        index = ((currentIndex - 1 + offset) Mod entries.Count) + 1
        entry = entries(index)
        If Len(CStr(entry(1))) = 0 And pending.Exists(CStr(entry(0))) Then
            NextUnreviewedGroupIndex = index
            Exit Function
        End If
    Next offset
End Function

Private Function BuildCashAnalysisNavigationEntries( _
        ByVal wsResult As Worksheet, ByVal wsGroup As Worksheet, _
        ByVal categoryText As String, ByVal txPersonMap As Object) As Collection
    Dim entries As New Collection
    Dim groupRowsByID As Object, groupRows As Collection
    Dim lastResultRow As Long, lastGroupRow As Long
    Dim resultCategories As Variant, resultGroups As Variant
    Dim groupIDs As Variant, sourceSheets As Variant, sourceRows As Variant
    Dim sourceKeys As Variant, txIDs As Variant, representativeFlags As Variant
    Dim seenRefs As Object, seenResultGroups As Object
    Dim groupID As String, personClass As String, candidateRef As String
    Dim r As Long, passNo As Long, rowItem As Variant, groupRow As Long
    Dim representativeCount As Long

    Set groupRowsByID = CreateObject("Scripting.Dictionary")
    groupRowsByID.CompareMode = vbTextCompare
    lastGroupRow = LastUsedRowInSheet(wsGroup)
    If lastGroupRow >= 2 Then
        groupIDs = CashResultColumnValues(wsGroup, 2, lastGroupRow, 1)
        sourceSheets = CashResultColumnValues(wsGroup, 2, lastGroupRow, 2)
        sourceRows = CashResultColumnValues(wsGroup, 2, lastGroupRow, 3)
        sourceKeys = CashResultColumnValues(wsGroup, 2, lastGroupRow, 4)
        txIDs = CashResultColumnValues(wsGroup, 2, lastGroupRow, 5)
        representativeFlags = CashResultColumnValues(wsGroup, 2, lastGroupRow, 7)
        For r = 1 To lastGroupRow - 1
            groupID = CellText(groupIDs(r, 1))
            If Len(groupID) > 0 Then
                If Not groupRowsByID.Exists(groupID) Then
                    Set groupRows = New Collection
                    groupRowsByID.Add groupID, groupRows
                End If
                Set groupRows = groupRowsByID(groupID)
                groupRows.Add r
            End If
        Next r
    End If

    lastResultRow = LastUsedRowInSheet(wsResult)
    If lastResultRow < 2 Then
        Set BuildCashAnalysisNavigationEntries = entries
        Exit Function
    End If
    resultCategories = CashResultColumnValues(wsResult, 2, lastResultRow, 2)
    resultGroups = CashResultColumnValues( _
                       wsResult, 2, lastResultRow, ANALYSIS_RESULT_GROUP_ID_COL)
    Set seenResultGroups = CreateObject("Scripting.Dictionary")
    seenResultGroups.CompareMode = vbTextCompare
    For r = 1 To lastResultRow - 1
        If CashViewCategoryForResult(CellText(resultCategories(r, 1))) = categoryText Then
            groupID = CellText(resultGroups(r, 1))
            If Len(groupID) = 0 Then _
                Err.Raise vbObjectError + 5004, "BuildCashAnalysisNavigationEntries", _
                          "分析結果にグループIDがありません。"
            If seenResultGroups.Exists(groupID) Then _
                Err.Raise vbObjectError + 5004, "BuildCashAnalysisNavigationEntries", _
                          "分析結果に同じグループIDが重複しています。"
            seenResultGroups.Add groupID, True
            entries.Add Array(groupID, vbNullString)
            Set seenRefs = CreateObject("Scripting.Dictionary")
            seenRefs.CompareMode = vbBinaryCompare
            If Not groupRowsByID.Exists(groupID) Then _
                Err.Raise vbObjectError + 5005, _
                          "BuildCashAnalysisNavigationEntries", _
                          "分析結果に対応する内部グループがありません。"
            Set groupRows = groupRowsByID(groupID)
            representativeCount = 0
            For Each rowItem In groupRows
                groupRow = CLng(rowItem)
                If StrComp(CellText(representativeFlags(groupRow, 1)), _
                           "代表", vbBinaryCompare) = 0 Then
                    representativeCount = representativeCount + 1
                ElseIf StrComp(CellText(representativeFlags(groupRow, 1)), _
                              "代替", vbBinaryCompare) <> 0 Then
                    Err.Raise vbObjectError + 5006, _
                              "BuildCashAnalysisNavigationEntries", _
                              "分析グループの代表区分が不正です。"
                End If
            Next rowItem
            If representativeCount <> 1 Then _
                Err.Raise vbObjectError + 5006, _
                          "BuildCashAnalysisNavigationEntries", _
                          "分析グループの代表候補が一意ではありません。"
            For passNo = 1 To 2
                For Each rowItem In groupRows
                    groupRow = CLng(rowItem)
                    If StrComp(CellText(representativeFlags(groupRow, 1)), _
                               "代替", vbBinaryCompare) = 0 Then
                        personClass = CashAlternativePersonClass( _
                                          CellText(txIDs(groupRow, 1)), txPersonMap)
                        If CashAnalysisNavigationRank("代替", personClass) = passNo Then
                            candidateRef = CashAnalysisCandidateReference( _
                                               CellText(sourceSheets(groupRow, 1)), _
                                               CLng(Val(CellText(sourceRows(groupRow, 1)))), _
                                               CellText(sourceKeys(groupRow, 1)))
                            If Len(candidateRef) = 0 Or seenRefs.Exists(candidateRef) Then _
                                Err.Raise vbObjectError + 5005, _
                                          "BuildCashAnalysisNavigationEntries", _
                                          "同じグループの代替候補参照が不足または重複しています。"
                            seenRefs.Add candidateRef, True
                            entries.Add Array(groupID, candidateRef)
                        End If
                    End If
                Next rowItem
            Next passNo
        End If
    Next r
    Set BuildCashAnalysisNavigationEntries = entries
End Function

Private Function CashAnalysisNavigationRank(ByVal representativeText As String, _
                                            ByVal personClass As String) As Long
    If StrComp(representativeText, "代表", vbBinaryCompare) = 0 Then
        CashAnalysisNavigationRank = 0
    ElseIf StrComp(representativeText, "代替", vbBinaryCompare) <> 0 Then
        Err.Raise vbObjectError + 5007, "CashAnalysisNavigationRank", _
                  "候補の代表区分が不正です。"
    ElseIf personClass = VIEW_PERSON_DIFFERENT Then
        CashAnalysisNavigationRank = 1
    ElseIf personClass = VIEW_PERSON_SAME Then
        CashAnalysisNavigationRank = 2
    Else
        Err.Raise vbObjectError + 5008, "CashAnalysisNavigationRank", _
                  "候補の人物区分が不正です。"
    End If
End Function

Private Function CashAnalysisWrappedNavigationIndex( _
        ByVal currentIndex As Long, ByVal entryCount As Long, _
        ByVal direction As Long) As Long
    If entryCount < 1 Or currentIndex < 1 Or currentIndex > entryCount Or _
       (direction <> -1 And direction <> 1) Then _
        Err.Raise vbObjectError + 5009, "CashAnalysisWrappedNavigationIndex", _
                  "候補循環の位置または方向が不正です。"
    CashAnalysisWrappedNavigationIndex = currentIndex + direction
    If CashAnalysisWrappedNavigationIndex < 1 Then _
        CashAnalysisWrappedNavigationIndex = entryCount
    If CashAnalysisWrappedNavigationIndex > entryCount Then _
        CashAnalysisWrappedNavigationIndex = 1
End Function

Private Function CashAnalysisCandidateReference( _
        ByVal sourceSheet As String, ByVal sourceRow As Long, _
        ByVal sourceKey As String) As String
    If Len(sourceSheet) = 0 Or sourceRow < 2 Or Len(sourceKey) = 0 Then Exit Function
    'XMLへ保存できない制御文字を状態セルへ入れず、長さ付きの安定参照にする。
    CashAnalysisCandidateReference = CStr(Len(sourceSheet)) & ":" & sourceSheet & ":" & _
                                     CStr(sourceRow) & ":" & sourceKey
End Function

Private Function FindCashAnalysisAlternativeRow( _
        ByVal wsGroup As Worksheet, ByVal groupID As String, _
        ByVal candidateRef As String) As Long
    Dim lastR As Long, r As Long
    Dim groupIDs As Variant, sourceSheets As Variant, sourceRows As Variant
    Dim sourceKeys As Variant, representativeFlags As Variant
    Dim rowRef As String
    If wsGroup Is Nothing Or Len(groupID) = 0 Or Len(candidateRef) = 0 Then Exit Function
    lastR = LastUsedRowInSheet(wsGroup)
    If lastR < 2 Then Exit Function
    groupIDs = CashResultColumnValues(wsGroup, 2, lastR, 1)
    sourceSheets = CashResultColumnValues(wsGroup, 2, lastR, 2)
    sourceRows = CashResultColumnValues(wsGroup, 2, lastR, 3)
    sourceKeys = CashResultColumnValues(wsGroup, 2, lastR, 4)
    representativeFlags = CashResultColumnValues(wsGroup, 2, lastR, 7)
    For r = 1 To lastR - 1
        If StrComp(CellText(groupIDs(r, 1)), groupID, vbBinaryCompare) = 0 And _
           StrComp(CellText(representativeFlags(r, 1)), "代替", vbBinaryCompare) = 0 Then
            rowRef = CashAnalysisCandidateReference( _
                         CellText(sourceSheets(r, 1)), _
                         CLng(Val(CellText(sourceRows(r, 1)))), _
                         CellText(sourceKeys(r, 1)))
            If StrComp(rowRef, candidateRef, vbBinaryCompare) = 0 Then
                If FindCashAnalysisAlternativeRow <> 0 Then _
                    Err.Raise vbObjectError + 5010, _
                              "FindCashAnalysisAlternativeRow", _
                              "代替候補の内部参照が重複しています。"
                FindCashAnalysisAlternativeRow = r + 1
            End If
        End If
    Next r
End Function

Private Sub CashAnalysisGroupCandidatePosition( _
        ByVal wsGroup As Worksheet, ByVal groupID As String, _
        ByVal targetGroupRow As Long, ByVal txPersonMap As Object, _
        ByRef candidatePosition As Long, ByRef candidateCount As Long)
    Dim lastR As Long, r As Long, passNo As Long
    Dim groupIDs As Variant, txIDs As Variant, representativeFlags As Variant
    Dim personClass As String
    candidateCount = 1
    If wsGroup Is Nothing Or Len(groupID) = 0 Then Exit Sub
    lastR = LastUsedRowInSheet(wsGroup)
    If lastR < 2 Then Exit Sub
    groupIDs = CashResultColumnValues(wsGroup, 2, lastR, 1)
    txIDs = CashResultColumnValues(wsGroup, 2, lastR, 5)
    representativeFlags = CashResultColumnValues(wsGroup, 2, lastR, 7)
    For passNo = 1 To 2
        For r = 1 To lastR - 1
            If StrComp(CellText(groupIDs(r, 1)), groupID, vbBinaryCompare) = 0 And _
               StrComp(CellText(representativeFlags(r, 1)), "代替", vbBinaryCompare) = 0 Then
                personClass = CashAlternativePersonClass( _
                                  CellText(txIDs(r, 1)), txPersonMap)
                If CashAnalysisNavigationRank("代替", personClass) = passNo Then
                    candidateCount = candidateCount + 1
                    If r + 1 = targetGroupRow Then candidatePosition = candidateCount
                End If
            End If
        Next r
    Next passNo
End Sub

Private Sub AccumulateCashManualTotals(ByVal withdrawal As Double, ByVal deposit As Double, _
                                       ByRef totalWithdrawal As Double, _
                                       ByRef totalDeposit As Double, _
                                       ByRef withdrawalCount As Long, _
                                       ByRef depositCount As Long)
    totalWithdrawal = totalWithdrawal + withdrawal
    totalDeposit = totalDeposit + deposit
    If withdrawal > 0 Then withdrawalCount = withdrawalCount + 1
    If deposit > 0 Then depositCount = depositCount + 1
End Sub

Private Function CashAnalysisAlternativePanelText(ByVal wsView As Worksheet) As String
    Const MAX_VISIBLE_ALTERNATIVES As Long = 12
    Dim wsGroup As Worksheet, lastR As Long, r As Long, matchCount As Long, shownCount As Long
    Dim data As Variant, groupID As String, lineText As String, sourceSheet As String
    Dim sourceRow As Long, personClass As String, txIDList As String
    Dim txPersonMap As Object
    If wsView Is Nothing Or Not SheetExists(SH_WORK_ANALYSIS_GROUP) Then Exit Function
    groupID = CellText(wsView.Range(VIEW_STATE_GROUP_ID).Value)
    If Len(groupID) = 0 Then Exit Function
    Set wsGroup = GetSheet(SH_WORK_ANALYSIS_GROUP)
    lastR = LastUsedRowInSheet(wsGroup)
    If lastR < 2 Then Exit Function
    data = wsGroup.Range(wsGroup.Cells(2, 1), _
                         wsGroup.Cells(lastR, ANALYSIS_GROUP_LAST_COL)).Value2
    For r = 1 To UBound(data, 1)
        If StrComp(CellText(data(r, 1)), groupID, vbBinaryCompare) = 0 Then _
            matchCount = matchCount + 1
    Next r
    If matchCount <= 1 Then Exit Function
    Set txPersonMap = CashAnalysisTransactionPersonMap()
    CashAnalysisAlternativePanelText = _
        "代替仮説一覧（別人物間を先に表示）"
    For r = 1 To UBound(data, 1)
        If StrComp(CellText(data(r, 1)), groupID, vbBinaryCompare) = 0 Then
            shownCount = shownCount + 1
            If shownCount <= MAX_VISIBLE_ALTERNATIVES Then
                sourceSheet = CellText(data(r, 2))
                sourceRow = CLng(Val(CellText(data(r, 3))))
                txIDList = CellText(data(r, 5))
                personClass = CashAlternativePersonClass(txIDList, txPersonMap)
                lineText = CStr(shownCount) & ". ［" & personClass & " / " & _
                           CellText(data(r, 7)) & "］ " & CellText(data(r, 8)) & _
                           "　評価 " & CellText(data(r, 6)) & _
                           "　確認状況 " & CellText(data(r, 9))
                lineText = lineText & vbCrLf & _
                           CashAlternativeSourceSummary(sourceSheet, sourceRow)
                CashAnalysisAlternativePanelText = CashAnalysisAlternativePanelText & _
                    vbCrLf & vbCrLf & lineText
            End If
        End If
    Next r
    If matchCount > MAX_VISIBLE_ALTERNATIVES Then _
        CashAnalysisAlternativePanelText = CashAnalysisAlternativePanelText & _
            vbCrLf & vbCrLf & "ほか " & CStr(matchCount - MAX_VISIBLE_ALTERNATIVES) & _
            "件。構成取引の重複を確認し、候補を絞り込んでください。"
End Function

Private Function CashAlternativePersonClass(ByVal txIDList As String, _
                                            ByVal txPersonMap As Object) As String
    Dim wanted As Object, persons As Object, item As Variant, txID As String, personID As String
    Set wanted = IDsToDictionary(txIDList)
    Set persons = CreateObject("Scripting.Dictionary")
    persons.CompareMode = vbTextCompare
    If wanted.Count < 2 Or txPersonMap Is Nothing Then _
        Err.Raise vbObjectError + 4976, "CashAlternativePersonClass", _
                  "代替候補の構成取引を確認できません。"
    For Each item In wanted.Keys
        txID = CStr(item)
        If Not txPersonMap.Exists(txID) Then _
            Err.Raise vbObjectError + 4977, "CashAlternativePersonClass", _
                      "代替候補の人物IDをW_取引で確認できません: " & txID
        personID = CellText(txPersonMap(txID))
        If Len(personID) = 0 Then _
            Err.Raise vbObjectError + 4978, "CashAlternativePersonClass", _
                      "代替候補の人物IDがありません: " & txID
        persons(personID) = True
    Next item
    If persons.Count > 1 Then
        CashAlternativePersonClass = VIEW_PERSON_DIFFERENT
    Else
        CashAlternativePersonClass = VIEW_PERSON_SAME
    End If
End Function

Private Function CashAlternativeSourceSummary(ByVal sourceSheet As String, _
                                              ByVal sourceRow As Long) As String
    Dim ws As Worksheet, routeText As String, dateText As String, amountText As String
    If sourceSheet <> SH_ANALYSIS_SHIFT And sourceSheet <> SH_ANALYSIS_FLOW Then _
        Err.Raise vbObjectError + 4981, "CashAlternativeSourceSummary", _
                  "代替候補の内部根拠表が資金移動ではありません。"
    If Not SheetExists(sourceSheet) Then _
        Err.Raise vbObjectError + 4979, "CashAlternativeSourceSummary", _
                  "代替候補の内部根拠表がありません。"
    Set ws = GetSheet(sourceSheet)
    If sourceRow < 2 Or sourceRow > LastUsedRowInSheet(ws) Then _
        Err.Raise vbObjectError + 4980, "CashAlternativeSourceSummary", _
                  "代替候補の内部根拠行がありません。"
    If sourceSheet = SH_ANALYSIS_SHIFT Then
        dateText = CashAlternativeDateText(ws.Cells(sourceRow, 9).Value) & " → " & _
                   CashAlternativeDateText(ws.Cells(sourceRow, 19).Value)
        amountText = Format$(CashViewDouble(ws.Cells(sourceRow, 17).Value), "#,##0.########") & _
                     " → " & Format$(CashViewDouble(ws.Cells(sourceRow, 27).Value), "#,##0.########")
        routeText = CellText(ws.Cells(sourceRow, 11).Value) & " / " & _
                    CellText(ws.Cells(sourceRow, 13).Value) & " " & _
                    CellText(ws.Cells(sourceRow, 14).Value) & " ⇒ " & _
                    CellText(ws.Cells(sourceRow, 21).Value) & " / " & _
                    CellText(ws.Cells(sourceRow, 23).Value) & " " & _
                    CellText(ws.Cells(sourceRow, 24).Value)
    ElseIf sourceSheet = SH_ANALYSIS_FLOW Then
        dateText = CellText(ws.Cells(sourceRow, 6).Value)
        amountText = Format$(CashViewDouble(ws.Cells(sourceRow, 9).Value), "#,##0.########") & _
                     " → " & Format$(CashViewDouble(ws.Cells(sourceRow, 10).Value), "#,##0.########")
        routeText = CellText(ws.Cells(sourceRow, 12).Value)
    End If
    CashAlternativeSourceSummary = _
        CashAnalysisNormalizeTimeEvidenceText(dateText & " / " & amountText & vbCrLf & routeText)
End Function

Private Function CashAlternativeDateText(ByVal valueIn As Variant) As String
    If IsDate(valueIn) Then
        CashAlternativeDateText = Format$(CDate(valueIn), "yyyy/m/d")
    Else
        CashAlternativeDateText = "日付要確認"
    End If
End Function

Private Sub ShowCashAnalysisLongMessage(ByVal valueText As String, ByVal titleText As String)
    'MsgBoxの表示上限で長文が末尾欠落しないよう、安全な長さでページ分割する。
    Const MESSAGE_CHUNK As Long = 900
    Dim pageCount As Long, pageNumber As Long
    Dim pageTitle As String, startAt As Long
    If Len(valueText) = 0 Then valueText = "（表示する内容はありません）"
    pageCount = (Len(valueText) + MESSAGE_CHUNK - 1) \ MESSAGE_CHUNK
    If pageCount < 1 Then pageCount = 1
    For pageNumber = 1 To pageCount
        startAt = (pageNumber - 1) * MESSAGE_CHUNK + 1
        pageTitle = titleText
        If pageCount > 1 Then _
            pageTitle = pageTitle & "（" & CStr(pageNumber) & "/" & CStr(pageCount) & "）"
        MsgBox Mid$(valueText, startAt, MESSAGE_CHUNK), vbInformation, pageTitle
    Next pageNumber
End Sub

Public Function CashAnalysisManualModeActive() As Boolean
    If Not SheetExists(SH_OUTPUT_TX) Then Exit Function
    CashAnalysisManualModeActive = _
        (CellText(GetSheet(SH_OUTPUT_TX).Range(VIEW_STATE_MANUAL).Value) = "1")
End Function

Public Function HasCashAnalysisManualSelection() As Boolean
    If Not CashAnalysisManualModeActive() Then Exit Function
    HasCashAnalysisManualSelection = _
        (IDsToDictionary(CellText(GetSheet(SH_OUTPUT_TX).Range(VIEW_STATE_SELECTED_IDS).Value)).Count > 0)
End Function

Public Sub ClearCashAnalysisManualSelection(Optional ByVal refreshView As Boolean = True)
    Dim ws As Worksheet
    Dim workbookWasSaved As Boolean
    Dim previousEvents As Boolean, eventsCaptured As Boolean
    Dim eventsRestoreAttempted As Boolean, eventsReadyForRecovery As Boolean
    Dim actionMutationStarted As Boolean, protectOK As Boolean
    Dim safeToRestoreEntry As Boolean
    Dim eventStateDetail As String, stopDetail As String
    Dim convergenceDetail As String
    Dim errorNumber As Long, errorSource As String, errorDescription As String
    On Error GoTo EH
    If Not SheetExists(SH_OUTPUT_TX) Then Exit Sub
    Set ws = GetSheet(SH_OUTPUT_TX)
    workbookWasSaved = ThisWorkbook.Saved
    If Not TryGetCashAnalysisEnableEvents(previousEvents, eventStateDetail) Then _
        Err.Raise vbObjectError + 5131, "ClearCashAnalysisManualSelection", _
                  "Excelイベントの開始状態を取得できませんでした。 " & eventStateDetail
    eventsCaptured = True
    If Not TrySetCashAnalysisEnableEventsExact(False, eventStateDetail) Then _
        Err.Raise vbObjectError + 5132, "ClearCashAnalysisManualSelection", _
                  "手動選択解除前にExcelイベントを停止できませんでした。 " & eventStateDetail
    actionMutationStarted = True
    ws.Unprotect Password:=TOOL_PASSWORD
    ws.Range(VIEW_STATE_MANUAL).Value = "0"
    ws.Range(VIEW_STATE_SELECTED_IDS).ClearContents
    If refreshView Then
        RefreshCashAnalysisPanel False
    Else
        ProtectCashAnalysisViewSheet
    End If
    If workbookWasSaved Then ThisWorkbook.Saved = True
    eventsRestoreAttempted = True
    If Not TryRestoreCashAnalysisEnableEvents( _
               previousEvents, "ClearCashAnalysisManualSelection", _
               eventStateDetail) Then _
        Err.Raise vbObjectError + 5133, _
                  "ClearCashAnalysisManualSelection", eventStateDetail
    eventsCaptured = False
    Exit Sub
EH:
    errorNumber = Err.Number
    errorSource = Err.Source
    errorDescription = Err.Description
    If IsCashAnalysisRecoveryFatal(errorNumber, errorSource) Then
        Call TryStopCashAnalysisEventsForRecovery(convergenceDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    If eventsCaptured Then
        If Not eventsRestoreAttempted Then _
            eventsReadyForRecovery = _
                TryStopCashAnalysisEventsForRecovery(stopDetail)
    End If
    If actionMutationStarted And Not eventsRestoreAttempted Then
        If eventsReadyForRecovery Then
            protectOK = TryProtectCashAnalysisViewAfterFailure( _
                            ws, "ClearCashAnalysisManualSelection", _
                            False, errorDescription)
            safeToRestoreEntry = _
                CashAnalysisOuterLeaseMayRestoreAfterProtection( _
                    protectOK, errorDescription)
        Else
            AppendCashAnalysisRollbackDetail errorDescription, _
                "Excelイベント停止を読戻し確認できないため、" & _
                "ブックの再保護とRecovery書込みを行いませんでした。 " & _
                stopDetail
        End If
    End If
    If eventsCaptured And Not eventsRestoreAttempted Then
        eventsRestoreAttempted = True
        If Not actionMutationStarted Or safeToRestoreEntry Then
            If Not TryRestoreCashAnalysisEnableEvents( _
                       previousEvents, _
                       "ClearCashAnalysisManualSelection/エラー終了", _
                       eventStateDetail) Then _
                AppendCashAnalysisRollbackDetail errorDescription, _
                    eventStateDetail
        ElseIf TryStopCashAnalysisEventsForRecovery(convergenceDetail) Then
            AppendCashAnalysisRollbackDetail errorDescription, _
                "再保護またはRecoveryを厳密確認できないため、" & _
                "開始時イベント値へ戻さずFalseで停止しました。"
        Else
            AppendCashAnalysisRollbackDetail errorDescription, _
                "安全状態を厳密確認できず、ExcelイベントのFalse収束にも" & _
                "失敗しました。現在状態は不明です: " & convergenceDetail
        End If
    End If
    eventsCaptured = False
    Err.Raise errorNumber, "ClearCashAnalysisManualSelection", errorDescription
End Sub

Private Sub ToggleCashManualTransaction(ByVal ws As Worksheet, ByVal txID As String)
    Dim selected As Object
    Dim workbookWasSaved As Boolean
    Dim selectedText As String
    Dim previousEvents As Boolean, eventsCaptured As Boolean
    Dim eventsRestoreAttempted As Boolean, eventsReadyForRecovery As Boolean
    Dim actionMutationStarted As Boolean, protectOK As Boolean
    Dim safeToRestoreEntry As Boolean
    Dim eventStateDetail As String, stopDetail As String
    Dim convergenceDetail As String
    Dim errorNumber As Long, errorSource As String, errorDescription As String
    On Error GoTo EH
    workbookWasSaved = ThisWorkbook.Saved
    Set selected = IDsToDictionary(CellText(ws.Range(VIEW_STATE_SELECTED_IDS).Value))
    If selected.Exists(txID) Then
        selected.Remove txID
    Else
        selected(txID) = True
    End If
    selectedText = JoinCashDictionaryKeys(selected)
    If Len(selectedText) > VIEW_SELECTED_IDS_MAX Then
        MsgBox "一度に選択できる取引件数の上限に達しました。" & vbCrLf & _
               "手動候補を複数に分けて登録してください。", _
               vbInformation, "手動候補の選択上限"
        Exit Sub
    End If
    If Not TryGetCashAnalysisEnableEvents(previousEvents, eventStateDetail) Then _
        Err.Raise vbObjectError + 5137, "ToggleCashManualTransaction", _
                  "Excelイベントの開始状態を取得できませんでした。 " & eventStateDetail
    eventsCaptured = True
    If Not TrySetCashAnalysisEnableEventsExact(False, eventStateDetail) Then _
        Err.Raise vbObjectError + 5138, "ToggleCashManualTransaction", _
                  "手動候補選択更新前にExcelイベントを停止できませんでした。 " & eventStateDetail
    actionMutationStarted = True
    ws.Unprotect Password:=TOOL_PASSWORD
    ws.Range(VIEW_STATE_SELECTED_IDS).Value = selectedText
    RefreshCashAnalysisPanel False
    If workbookWasSaved Then ThisWorkbook.Saved = True
    eventsRestoreAttempted = True
    If Not TryRestoreCashAnalysisEnableEvents( _
               previousEvents, "ToggleCashManualTransaction", _
               eventStateDetail) Then _
        Err.Raise vbObjectError + 5139, _
                  "ToggleCashManualTransaction", eventStateDetail
    eventsCaptured = False
    Exit Sub
EH:
    errorNumber = Err.Number
    errorSource = Err.Source
    errorDescription = Err.Description
    If IsCashAnalysisRecoveryFatal(errorNumber, errorSource) Then
        Call TryStopCashAnalysisEventsForRecovery(convergenceDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    If eventsCaptured Then
        If Not eventsRestoreAttempted Then _
            eventsReadyForRecovery = _
                TryStopCashAnalysisEventsForRecovery(stopDetail)
    End If
    If actionMutationStarted And Not eventsRestoreAttempted Then
        If eventsReadyForRecovery Then
            protectOK = TryProtectCashAnalysisViewAfterFailure( _
                            ws, "ToggleCashManualTransaction", _
                            False, errorDescription)
            safeToRestoreEntry = _
                CashAnalysisOuterLeaseMayRestoreAfterProtection( _
                    protectOK, errorDescription)
        Else
            AppendCashAnalysisRollbackDetail errorDescription, _
                "Excelイベント停止を読戻し確認できないため、" & _
                "ブックの再保護とRecovery書込みを行いませんでした。 " & _
                stopDetail
        End If
    End If
    If eventsCaptured And Not eventsRestoreAttempted Then
        eventsRestoreAttempted = True
        If Not actionMutationStarted Or safeToRestoreEntry Then
            If Not TryRestoreCashAnalysisEnableEvents( _
                       previousEvents, _
                       "ToggleCashManualTransaction/エラー終了", _
                       eventStateDetail) Then _
                AppendCashAnalysisRollbackDetail errorDescription, _
                    eventStateDetail
        ElseIf TryStopCashAnalysisEventsForRecovery(convergenceDetail) Then
            AppendCashAnalysisRollbackDetail errorDescription, _
                "再保護またはRecoveryを厳密確認できないため、" & _
                "開始時イベント値へ戻さずFalseで停止しました。"
        Else
            AppendCashAnalysisRollbackDetail errorDescription, _
                "安全状態を厳密確認できず、ExcelイベントのFalse収束にも" & _
                "失敗しました。現在状態は不明です: " & convergenceDetail
        End If
    End If
    eventsCaptured = False
    MsgBox "手動候補の選択を更新できませんでした。" & vbCrLf & _
           "Err " & CStr(errorNumber) & ": " & errorDescription, vbExclamation
End Sub

Private Sub FocusCashAnalysisCandidateByTransaction(ByVal ws As Worksheet, ByVal txID As String)
    Dim wsResult As Worksheet, lastR As Long, r As Long
    Dim categoryText As String, firstMatch As Long, preferredMatch As Long
    Dim categoryValues As Variant, txIDValues As Variant
    Dim workbookWasSaved As Boolean
    Dim previousEvents As Boolean, eventsCaptured As Boolean
    Dim eventsRestoreAttempted As Boolean, eventsReadyForRecovery As Boolean
    Dim actionMutationStarted As Boolean, protectOK As Boolean
    Dim safeToRestoreEntry As Boolean
    Dim eventStateDetail As String, stopDetail As String
    Dim convergenceDetail As String
    Dim errorNumber As Long, errorSource As String, errorDescription As String
    If Not SheetExists(SH_ANALYSIS_RESULT) Then Exit Sub
    On Error GoTo EH
    '現在表示中の代表・代替の構成取引を再指定しただけなら、表示位置を変えない。
    If CashAnalysisCurrentCandidateContainsTransaction(ws, txID) Then Exit Sub
    Set wsResult = GetSheet(SH_ANALYSIS_RESULT)
    categoryText = CellText(ws.Range(VIEW_STATE_CATEGORY).Value)
    lastR = LastUsedRowInSheet(wsResult)
    If lastR >= 2 Then
        categoryValues = CashResultColumnValues(wsResult, 2, lastR, 2)
        txIDValues = CashResultColumnValues(wsResult, 2, lastR, ANALYSIS_RESULT_TX_IDS_COL)
    End If
    For r = 1 To Application.Max(0, lastR - 1)
        If IDListContains(CellText(txIDValues(r, 1)), txID) Then
            If firstMatch = 0 Then firstMatch = r + 1
            If CashViewCategoryForResult(CellText(categoryValues(r, 1))) = categoryText Then
                preferredMatch = r + 1
                Exit For
            End If
        End If
    Next r
    If preferredMatch = 0 Then preferredMatch = firstMatch
    If preferredMatch = 0 Then
        MsgBox "この取引を構成取引に含む分析候補はありません。" & vbCrLf & _
               "不明入出金の最低金額など、分析条件も確認してください。", vbInformation
        Exit Sub
    End If
    workbookWasSaved = ThisWorkbook.Saved
    If Not TryGetCashAnalysisEnableEvents(previousEvents, eventStateDetail) Then _
        Err.Raise vbObjectError + 5140, _
                  "FocusCashAnalysisCandidateByTransaction", _
                  "Excelイベントの開始状態を取得できませんでした。 " & eventStateDetail
    eventsCaptured = True
    If Not TrySetCashAnalysisEnableEventsExact(False, eventStateDetail) Then _
        Err.Raise vbObjectError + 5141, _
                  "FocusCashAnalysisCandidateByTransaction", _
                  "候補表示切替前にExcelイベントを停止できませんでした。 " & eventStateDetail
    actionMutationStarted = True
    SyncCashAnalysisPanelReviewToWorkspace
    ws.Unprotect Password:=TOOL_PASSWORD
    ws.Range(VIEW_STATE_CATEGORY).Value = _
        CashViewCategoryForResult(CellText(wsResult.Cells(preferredMatch, 2).Value))
    ws.Range(VIEW_STATE_GROUP_ID).Value = _
        CellText(wsResult.Cells(preferredMatch, ANALYSIS_RESULT_GROUP_ID_COL).Value)
    ws.Range(VIEW_STATE_CANDIDATE_REF).ClearContents
    ws.Range(VIEW_STATE_MODE).Value = VIEW_MODE_COMPONENT
    ws.Range(VIEW_STATE_PANEL_EXPANDED).Value = "0"
    RefreshCashAnalysisPanel True
    If workbookWasSaved Then ThisWorkbook.Saved = True
    eventsRestoreAttempted = True
    If Not TryRestoreCashAnalysisEnableEvents( _
               previousEvents, _
               "FocusCashAnalysisCandidateByTransaction", _
               eventStateDetail) Then _
        Err.Raise vbObjectError + 5142, _
                  "FocusCashAnalysisCandidateByTransaction", _
                  eventStateDetail
    eventsCaptured = False
    Exit Sub
EH:
    errorNumber = Err.Number
    errorSource = Err.Source
    errorDescription = Err.Description
    If IsCashAnalysisRecoveryFatal(errorNumber, errorSource) Then
        Call TryStopCashAnalysisEventsForRecovery(convergenceDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    If eventsCaptured Then
        If Not eventsRestoreAttempted Then _
            eventsReadyForRecovery = _
                TryStopCashAnalysisEventsForRecovery(stopDetail)
    End If
    If actionMutationStarted And Not eventsRestoreAttempted Then
        If eventsReadyForRecovery Then
            protectOK = TryProtectCashAnalysisViewAfterFailure( _
                            ws, "FocusCashAnalysisCandidateByTransaction", _
                            False, errorDescription)
            safeToRestoreEntry = _
                CashAnalysisOuterLeaseMayRestoreAfterProtection( _
                    protectOK, errorDescription)
        Else
            AppendCashAnalysisRollbackDetail errorDescription, _
                "Excelイベント停止を読戻し確認できないため、" & _
                "ブックの再保護とRecovery書込みを行いませんでした。 " & _
                stopDetail
        End If
    End If
    If eventsCaptured And Not eventsRestoreAttempted Then
        eventsRestoreAttempted = True
        If Not actionMutationStarted Or safeToRestoreEntry Then
            If Not TryRestoreCashAnalysisEnableEvents( _
                       previousEvents, _
                       "FocusCashAnalysisCandidateByTransaction/エラー終了", _
                       eventStateDetail) Then _
                AppendCashAnalysisRollbackDetail errorDescription, _
                    eventStateDetail
        ElseIf TryStopCashAnalysisEventsForRecovery(convergenceDetail) Then
            AppendCashAnalysisRollbackDetail errorDescription, _
                "再保護またはRecoveryを厳密確認できないため、" & _
                "開始時イベント値へ戻さずFalseで停止しました。"
        Else
            AppendCashAnalysisRollbackDetail errorDescription, _
                "安全状態を厳密確認できず、ExcelイベントのFalse収束にも" & _
                "失敗しました。現在状態は不明です: " & convergenceDetail
        End If
    End If
    eventsCaptured = False
    MsgBox "取引に対応する分析候補を表示できませんでした。" & vbCrLf & _
           "Err " & CStr(errorNumber) & ": " & errorDescription, vbExclamation
End Sub

Private Function CashAnalysisCurrentCandidateContainsTransaction( _
        ByVal ws As Worksheet, ByVal txID As String) As Boolean
    Dim wsResult As Worksheet, wsGroup As Worksheet
    Dim resultRow As Long, groupRow As Long, txIDList As String
    Dim groupID As String, candidateRef As String
    If ws Is Nothing Or Len(txID) = 0 Or Not SheetExists(SH_ANALYSIS_RESULT) Then Exit Function
    Set wsResult = GetSheet(SH_ANALYSIS_RESULT)
    resultRow = CLng(Val(CellText(ws.Range(VIEW_STATE_RESULT_ROW).Value)))
    groupID = CellText(ws.Range(VIEW_STATE_GROUP_ID).Value)
    If resultRow < 2 Or resultRow > LastUsedRowInSheet(wsResult) Or Len(groupID) = 0 Then Exit Function
    If StrComp(CellText(wsResult.Cells(resultRow, ANALYSIS_RESULT_GROUP_ID_COL).Value), _
               groupID, vbTextCompare) <> 0 Then Exit Function
    candidateRef = CellText(ws.Range(VIEW_STATE_CANDIDATE_REF).Value)
    If Len(candidateRef) > 0 Then
        If Not SheetExists(SH_WORK_ANALYSIS_GROUP) Then Exit Function
        Set wsGroup = GetSheet(SH_WORK_ANALYSIS_GROUP)
        groupRow = FindCashAnalysisAlternativeRow(wsGroup, groupID, candidateRef)
        If groupRow = 0 Then Exit Function
        txIDList = CellText(wsGroup.Cells(groupRow, 5).Value)
    Else
        txIDList = CellText(wsResult.Cells(resultRow, ANALYSIS_RESULT_TX_IDS_COL).Value)
    End If
    CashAnalysisCurrentCandidateContainsTransaction = IDListContains(txIDList, txID)
End Function

Private Sub RegisterCashAnalysisManualSelection()
    Dim ws As Worksheet, idList As String, restoreDetail As String
    Dim outputCapacityConfirmed As Boolean
    Dim entryEvents As Boolean, eventsCaptured As Boolean, eventsReady As Boolean
    Dim eventsRestoreAttempted As Boolean
    Dim eventDetail As String
    Dim errorNumber As Long, errorSource As String, errorDescription As String
    If Not SheetExists(SH_OUTPUT_TX) Then Exit Sub
    On Error GoTo EH
    Set ws = GetSheet(SH_OUTPUT_TX)
    idList = CellText(ws.Range(VIEW_STATE_SELECTED_IDS).Value)
    If IDsToDictionary(idList).Count < 2 Then
        MsgBox "取引を2件以上選択してください。出金と入金をそれぞれ含める必要があります。", vbInformation
        Exit Sub
    End If
    If Not TryGetCashAnalysisEnableEvents(entryEvents, eventDetail) Then _
        Err.Raise vbObjectError + 5109, "RegisterCashAnalysisManualSelection", _
                  "Excelイベントの開始状態を取得できませんでした。 " & eventDetail
    eventsCaptured = True
    eventsReady = TryStopCashAnalysisEventsForRecovery(eventDetail)
    If Not eventsReady Then _
        Err.Raise vbObjectError + 5110, "RegisterCashAnalysisManualSelection", _
                  "手動候補登録前にExcelイベント停止を確認できませんでした。 " & eventDetail
    ws.Unprotect Password:=TOOL_PASSWORD
    ws.Range(VIEW_STATE_MANUAL).Value = "0"
    If RegisterManualAnalysisCandidateByIDs(idList, outputCapacityConfirmed) Then
        eventsReady = TryStopCashAnalysisEventsForRecovery(eventDetail)
        If Not eventsReady Then _
            Err.Raise vbObjectError + 5111, "RegisterCashAnalysisManualSelection", _
                      "手動候補登録後のExcelイベント停止を確認できませんでした。 " & eventDetail
        If SheetExists(SH_OUTPUT_TX) Then
            Set ws = GetSheet(SH_OUTPUT_TX)
            ws.Unprotect Password:=TOOL_PASSWORD
            ws.Range(VIEW_STATE_CATEGORY).Value = VIEW_CATEGORY_TRANSFER
            ws.Range(VIEW_STATE_MODE).Value = VIEW_MODE_COMPONENT
            ws.Range(VIEW_STATE_SELECTED_IDS).ClearContents
            RefreshCashAnalysisPanel True
        End If
    Else
        '分析再構築がビューReset後に失敗している可能性がある。部分ビューへ単純Refreshすると、
        '存在しない行として選択IDを空へ収束させるため、内部資金表から作り直して厳密照合する。
        eventsReady = TryStopCashAnalysisEventsForRecovery(eventDetail)
        If Not eventsReady Then _
            Err.Raise vbObjectError + 5112, "RegisterCashAnalysisManualSelection", _
                      "手動候補の失敗復元前にExcelイベント停止を確認できませんでした。 " & eventDetail
        If Not RestoreCashManualSelectionAfterFailure( _
                   idList, outputCapacityConfirmed, restoreDetail) Then _
            StopAfterCashManualSelectionRestoreFailure restoreDetail
    End If
    If eventsCaptured Then
        eventsRestoreAttempted = True
        If Not TryRestoreCashAnalysisEnableEvents( _
                   entryEvents, "RegisterCashAnalysisManualSelection", _
                   eventDetail) Then _
            Err.Raise vbObjectError + 5113, _
                      "RegisterCashAnalysisManualSelection", eventDetail
        eventsCaptured = False
    End If
    Exit Sub
EH:
    errorNumber = Err.Number
    errorSource = Err.Source
    errorDescription = Err.Description
    If IsCashAnalysisRecoveryFatal(errorNumber, errorSource) Then
        Call TryStopCashAnalysisEventsForRecovery(eventDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    If eventsCaptured And Not eventsRestoreAttempted Then
        If Not TryRestoreCashAnalysisEnableEvents( _
                   entryEvents, "RegisterCashAnalysisManualSelection/エラー終了", _
                   eventDetail) Then _
            AppendCashAnalysisRollbackDetail errorDescription, eventDetail
    End If
    Err.Raise errorNumber, "RegisterCashAnalysisManualSelection", errorDescription
End Sub

Private Function RestoreCashManualSelectionAfterFailure( _
        ByVal idList As String, ByVal outputCapacityConfirmed As Boolean, _
        ByRef detailText As String) As Boolean
    Dim ws As Worksheet
    Dim expected As Object, actual As Object, found As Object
    Dim lastR As Long, r As Long
    Dim rowData As Variant, txID As String
    Dim item As Variant
    Dim workbookWasSaved As Boolean
    Dim entryEvents As Boolean, eventsCaptured As Boolean, eventsReady As Boolean
    Dim restoreSucceeded As Boolean, mutationStarted As Boolean
    Dim protectOK As Boolean, safeToRestoreEntry As Boolean
    Dim eventDetail As String, convergenceDetail As String
    Dim errorNumber As Long, errorSource As String, errorDescription As String

    On Error GoTo EH
    detailText = vbNullString
    Set expected = IDsToDictionary(idList)
    If expected.Count < 2 Then
        detailText = "退避した手動候補の選択IDが2件未満です。"
        Exit Function
    End If
    If Not SheetExists(SH_OUTPUT_TX) Or Not SheetExists(SH_WORK_CASH) Then
        detailText = "資金操作表または内部資金表がありません。"
        Exit Function
    End If
    If Not TryGetCashAnalysisEnableEvents(entryEvents, eventDetail) Then
        detailText = "Excelイベントの開始状態を取得できませんでした。 " & eventDetail
        Exit Function
    End If
    eventsCaptured = True
    eventsReady = TryStopCashAnalysisEventsForRecovery(eventDetail)
    If Not eventsReady Then
        detailText = "Excelイベント停止を確認できず、選択内容を再書込みしませんでした。 " & eventDetail
        GoTo CleanExit
    End If

    If Not CashManualFailureRecoveryMayRebuild(outputCapacityConfirmed) Then
        '容量確認前の失敗では、更新後の追加promptや大規模Resetを行わない。
        '既に変更した表示状態だけを戻し、帳票は要更新のまま安全側へ固定する。
        mutationStarted = True
        Set ws = GetSheet(SH_OUTPUT_TX)
        MarkOutputsDirty
        ws.Unprotect Password:=TOOL_PASSWORD
        ws.Range(VIEW_STATE_MANUAL).Value = "1"
        ws.Range(VIEW_STATE_SELECTED_IDS).Value = JoinCashDictionaryKeys(expected)
        Set actual = IDsToDictionary(CellText(ws.Range(VIEW_STATE_SELECTED_IDS).Value))
        If CellText(ws.Range(VIEW_STATE_MANUAL).Value) <> "1" Or _
           actual.Count <> expected.Count Then
            detailText = "容量未確認時の最小選択復元を照合できません。"
            GoTo RestoreFailed
        End If
        For Each item In expected.Keys
            If Not actual.Exists(CStr(item)) Then
                detailText = "容量未確認時の選択取引IDを復元できません: " & CStr(item)
                GoTo RestoreFailed
            End If
        Next item
        ProtectCashAnalysisViewSheet
        restoreSucceeded = True
        GoTo CleanExit
    End If

    workbookWasSaved = ThisWorkbook.Saved
    '壊れかけた表示表の行を信用せず、内部資金表を唯一の復元元にする。
    mutationStarted = True
    BuildCashAnalysisViewCore False, False, outputCapacityConfirmed
    eventsReady = TryStopCashAnalysisEventsForRecovery(eventDetail)
    If Not eventsReady Then
        detailText = "表示再構築後のExcelイベント停止を確認できず、選択内容を再書込みしませんでした。 " & eventDetail
        GoTo CleanExit
    End If
    Set ws = GetSheet(SH_OUTPUT_TX)
    ws.Unprotect Password:=TOOL_PASSWORD
    ws.Range(VIEW_STATE_MANUAL).Value = "1"
    ws.Range(VIEW_STATE_SELECTED_IDS).Value = JoinCashDictionaryKeys(expected)
    RefreshCashAnalysisPanel False

    Set actual = IDsToDictionary(CellText(ws.Range(VIEW_STATE_SELECTED_IDS).Value))
    If CellText(ws.Range(VIEW_STATE_MANUAL).Value) <> "1" Then
        detailText = "手動候補の選択モードを復元できません。"
        GoTo RestoreFailed
    End If
    If actual.Count <> expected.Count Then
        detailText = "復元後の選択取引件数が退避値と一致しません。"
        GoTo RestoreFailed
    End If
    For Each item In expected.Keys
        If Not actual.Exists(CStr(item)) Then
            detailText = "復元後の選択取引IDが退避値と一致しません: " & CStr(item)
            GoTo RestoreFailed
        End If
    Next item

    '非表示状態セルだけでなく、再構築した資金操作表の取引行にも全IDが存在することを確認する。
    Set found = CreateObject("Scripting.Dictionary")
    found.CompareMode = vbTextCompare
    lastR = CashAnalysisLastDataRow(ws)
    If lastR >= CASH_VIEW_FIRST_DATA_ROW Then
        rowData = ws.Range(ws.Cells(CASH_VIEW_FIRST_DATA_ROW, OUT_COL_TRANSACTION_ID), _
                           ws.Cells(lastR, OUT_COL_RECORD_TYPE)).Value2
        For r = 1 To UBound(rowData, 1)
            If StrComp(CellText(rowData(r, 2)), RECORD_TRANSACTION, vbTextCompare) = 0 Then
                txID = CellText(rowData(r, 1))
                If Len(txID) > 0 Then found(txID) = True
            End If
        Next r
    End If
    For Each item In expected.Keys
        If Not found.Exists(CStr(item)) Then
            detailText = "内部資金表から選択取引を再特定できません: " & CStr(item)
            GoTo RestoreFailed
        End If
    Next item

    eventsReady = TryStopCashAnalysisEventsForRecovery(eventDetail)
    If Not eventsReady Then
        detailText = "復元後のExcelイベント停止を確認できず、保存状態を再書込みしませんでした。 " & eventDetail
        GoTo CleanExit
    End If
    If workbookWasSaved Then ThisWorkbook.Saved = True
    restoreSucceeded = True
    GoTo CleanExit

RestoreFailed:
    eventsReady = TryStopCashAnalysisEventsForRecovery(eventDetail)
    If Not eventsReady Then _
        AppendCashAnalysisRollbackDetail detailText, _
            "再保護前のExcelイベント停止を確認できませんでした。 " & eventDetail
    If eventsReady Then
        protectOK = TryProtectCashAnalysisViewAfterFailure( _
                        ws, "RestoreCashManualSelectionAfterFailure", _
                        False, detailText)
        safeToRestoreEntry = _
            CashAnalysisOuterLeaseMayRestoreAfterProtection( _
                protectOK, detailText)
    End If
    GoTo CleanExit
EH:
    errorNumber = Err.Number
    errorSource = Err.Source
    errorDescription = Err.Description
    If IsCashAnalysisRecoveryFatal(errorNumber, errorSource) Then
        Call TryStopCashAnalysisEventsForRecovery(convergenceDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    detailText = "Err " & CStr(errorNumber) & ": " & errorDescription
    If eventsCaptured Then _
        eventsReady = TryStopCashAnalysisEventsForRecovery(eventDetail)
    If eventsReady Then
        Resume RestoreFailed
    Else
        AppendCashAnalysisRollbackDetail detailText, _
            "Excelイベント停止未確認のため、再保護も行いませんでした。 " & eventDetail
        Resume CleanExit
    End If
CleanExit:
    If eventsCaptured Then
        If Not mutationStarted Or restoreSucceeded Then
            eventsReady = TryStopCashAnalysisEventsForRecovery(eventDetail)
            safeToRestoreEntry = eventsReady
        End If
        If safeToRestoreEntry Then
            If Not TryRestoreCashAnalysisEnableEvents( _
                       entryEvents, "RestoreCashManualSelectionAfterFailure", _
                       eventDetail) Then
                restoreSucceeded = False
                AppendCashAnalysisRollbackDetail detailText, eventDetail
            End If
        ElseIf TryStopCashAnalysisEventsForRecovery(convergenceDetail) Then
            restoreSucceeded = False
            AppendCashAnalysisRollbackDetail detailText, _
                "選択復元・再保護またはRecoveryを厳密確認できないため、" & _
                "開始時イベント値へ戻さずFalseで停止しました。"
        Else
            restoreSucceeded = False
            AppendCashAnalysisRollbackDetail detailText, _
                "安全状態を厳密確認できず、ExcelイベントのFalse収束にも" & _
                "失敗しました。現在状態は不明です: " & convergenceDetail
        End If
    End If
    RestoreCashManualSelectionAfterFailure = restoreSucceeded
End Function

Private Function CashManualFailureRecoveryMayRebuild( _
        ByVal outputCapacityConfirmed As Boolean) As Boolean
    CashManualFailureRecoveryMayRebuild = outputCapacityConfirmed
End Function

Private Sub StopAfterCashManualSelectionRestoreFailure(ByVal restoreDetail As String)
    Dim detailText As String
    Dim stateErrorNumber As Long, stateErrorDescription As String
    Dim entryEvents As Boolean, eventsCaptured As Boolean, eventsReady As Boolean
    Dim recoveryConfirmed As Boolean, recoveryAttempted As Boolean
    Dim applicationStateConfirmed As Boolean
    Dim recoveryErrorNumber As Long, recoveryErrorDescription As String
    Dim eventDetail As String, preEnforceStopDetail As String
    Dim postEnforceStopDetail As String, finalStopDetail As String

    detailText = "資金操作表の手動候補選択を復元・照合できません。"
    If Len(restoreDetail) > 0 Then detailText = detailText & " / " & restoreDetail
    If Not TryGetCashAnalysisEnableEvents(entryEvents, eventDetail) Then
        AppendCashAnalysisRollbackDetail detailText, _
            "Excelイベントの開始状態を取得できず、復旧・チェック・状態書込みを行いませんでした。 " & eventDetail
        GoTo ShowFailure
    End If
    eventsCaptured = True
    eventsReady = TryStopCashAnalysisEventsForRecovery(eventDetail)
    If Not eventsReady Then
        AppendCashAnalysisRollbackDetail detailText, _
            "Excelイベント停止を確認できず、復旧・チェック・状態書込みを行いませんでした。 " & eventDetail
        GoTo RestoreEvents
    End If
    recoveryAttempted = True
    On Error Resume Next
    Err.Clear
    MarkOutputsDirty
    stateErrorNumber = Err.Number
    stateErrorDescription = Err.Description
    Err.Clear
    On Error GoTo 0
    If stateErrorNumber <> 0 Then _
        detailText = detailText & " / 帳票要更新状態の記録エラー: Err " & _
                     CStr(stateErrorNumber) & " " & stateErrorDescription
    eventsReady = TryStopCashAnalysisEventsForRecovery(preEnforceStopDetail)
    If Not eventsReady Then
        AppendCashAnalysisRollbackDetail detailText, _
            "Recovery強制設定直前のExcelイベント停止を確認できず、" & _
            "以後の復旧・チェック・状態書込みを行いませんでした。" & _
            "現在状態は不明です: " & preEnforceStopDetail
        GoTo RestoreEvents
    End If
    On Error Resume Next
    Err.Clear
    EnforceRollbackRecoveryState detailText
    recoveryErrorNumber = Err.Number
    recoveryErrorDescription = Err.Description
    Err.Clear
    On Error GoTo 0
    eventsReady = TryStopCashAnalysisEventsForRecovery(postEnforceStopDetail)
    If recoveryErrorNumber <> 0 Then
        AppendCashAnalysisRollbackDetail detailText, _
            "要復旧状態の強制設定エラー: Err " & _
            CStr(recoveryErrorNumber) & " " & recoveryErrorDescription
        AppendCashAnalysisRollbackDetail detailText, _
            "Recovery強制設定でエラーを検出したため、" & _
            "復旧状態の照合・チェック・状態書込みを行いませんでした。"
        If Not eventsReady Then _
            AppendCashAnalysisRollbackDetail detailText, _
                "Recovery強制設定後のExcelイベント停止も確認できず、" & _
                "現在状態は不明です: " & postEnforceStopDetail
        GoTo TerminalFailure
    End If
    If Not eventsReady Then
        AppendCashAnalysisRollbackDetail detailText, _
            "Recovery強制設定後にExcelイベント停止を確認できず、" & _
            "復旧状態の照合・チェック・状態書込みを行いませんでした。" & _
            "現在状態は不明です: " & postEnforceStopDetail
        GoTo TerminalFailure
    End If
    recoveryConfirmed = _
        CashAnalysisRecoveryStateIsConfirmedExact(detailText)
    If Not recoveryConfirmed Then
        AppendCashAnalysisRollbackDetail detailText, _
            "要復旧状態を厳密確認できません。"
        eventsReady = TryStopCashAnalysisEventsForRecovery(finalStopDetail)
        GoTo TerminalFailure
    End If
    applicationStateConfirmed = _
        CashAnalysisApplicationStateAllowsEntryRestore( _
            True, detailText)
    If Not applicationStateConfirmed Then
        eventsReady = _
            TryStopCashAnalysisEventsForRecovery(finalStopDetail)
        AppendCashAnalysisRollbackDetail detailText, _
            "Application状態を確認できません。"
        GoTo TerminalFailure
    End If
    eventsReady = TryStopCashAnalysisEventsForRecovery(finalStopDetail)
    If Not eventsReady Then
        AppendCashAnalysisRollbackDetail detailText, _
            "Application状態確認後のExcelイベントFalse収束を" & _
            "確認できません。現在状態は不明です: " & finalStopDetail
    End If
    GoTo TerminalFailure
RestoreEvents:
    If eventsCaptured Then
        eventsReady = TryStopCashAnalysisEventsForRecovery(eventDetail)
        If eventsReady Then
            AppendCashAnalysisRollbackDetail detailText, _
                "手動候補の失敗復元を完了できないため、開始時イベント値へ" & _
                "戻さずExcelイベントをFalseで停止しました。"
        Else
            AppendCashAnalysisRollbackDetail detailText, _
                "安全状態を厳密確認できず、ExcelイベントをFalseへ" & _
                "収束させることもできませんでした。現在状態は不明です: " & _
                eventDetail
        End If
    End If
ShowFailure:
    eventsReady = TryStopCashAnalysisEventsForRecovery(finalStopDetail)
    If Not eventsReady Then _
        AppendCashAnalysisRollbackDetail detailText, _
            "最終的なExcelイベントFalse収束を確認できませんでした: " & _
            finalStopDetail
    If Not recoveryAttempted Then
        If recoveryConfirmed Then
            eventDetail = "案件を要復旧として停止しました。"
        Else
            eventDetail = "要復旧状態の設定結果は確認できません。"
        End If
        MsgBox "手動候補の登録に失敗し、選択していた取引を安全に復元できませんでした。" & vbCrLf & _
               eventDetail & "現在のブックを上書きしないでください。" & vbCrLf & _
               detailText, vbCritical, "手動候補の選択復元に失敗しました"
    End If
TerminalFailure:
    eventsReady = TryStopCashAnalysisEventsForRecovery(finalStopDetail)
    Err.Raise vbObjectError + 5196, _
              "CashManualSelectionRecoveryFatal/StopAfterCashManualSelectionRestoreFailure", _
              detailText
End Sub

Public Sub OnCashAnalysisViewChange(ByVal Target As Range)
    Dim ws As Worksheet
    Dim previousEvents As Boolean, eventsCaptured As Boolean
    Dim eventsRestoreAttempted As Boolean
    Dim eventsReadyForRecovery As Boolean, viewRestoreConfirmed As Boolean
    Dim protectOK As Boolean, recoveryConfirmed As Boolean
    Dim applicationStateConfirmed As Boolean
    Dim safeToRestoreEntry As Boolean
    Dim refreshError As Long, recoveryErrorNumber As Long
    Dim refreshErrorSource As String, refreshErrorDescription As String
    Dim recoveryErrorDescription As String
    Dim protectionRecoveryAttempted As Boolean
    Dim protectionRecoveryFailed As Boolean
    Dim protectionRecoveryConfirmed As Boolean
    Dim recoveryDetail As String, eventStateDetail As String, stopDetail As String
    Dim postRefreshStopDetail As String, postProtectStopDetail As String
    Dim postEnforceStopDetail As String, convergenceDetail As String
    Dim finalRecoveryStopDetail As String
    Dim userMessage As String
    Dim errorNumber As Long, errorSource As String, errorDescription As String
    If Target Is Nothing Then Exit Sub
    On Error GoTo EH
    '例外時の画面復元がWorksheet_Changeへ再入しないよう、
    'シート取得や交差判定より先にイベント状態を退避して停止する。
    If Not TryGetCashAnalysisEnableEvents(previousEvents, eventStateDetail) Then
        StopAfterCashAnalysisEventStateFailure _
            "OnCashAnalysisViewChange/開始状態取得", eventStateDetail, _
            eventsReadyForRecovery, False, vbNullString
        Err.Raise vbObjectError + 5095, "OnCashAnalysisViewChange", _
                  "Excelイベントの開始状態を取得できませんでした。 " & eventStateDetail
    End If
    eventsCaptured = True
    If Not TrySetCashAnalysisEnableEventsExact(False, eventStateDetail) Then _
        Err.Raise vbObjectError + 5096, "OnCashAnalysisViewChange", _
                  "分析判断の検証前にExcelイベントを停止できませんでした。 " & _
                  eventStateDetail
    If Not SheetExists(SH_OUTPUT_TX) Then GoTo SafeExit
    Set ws = GetSheet(SH_OUTPUT_TX)
    If Intersect(Target, ws.Range("C3")) Is Nothing And _
       Intersect(Target, ws.Range("C8")) Is Nothing Then GoTo SafeExit
    If CellText(ws.Range(VIEW_STATE_MANUAL).Value) = "1" Then GoTo SafeExit
    If Len(CellText(ws.Range(VIEW_STATE_GROUP_ID).Value)) = 0 Then GoTo SafeExit
    ws.Unprotect Password:=TOOL_PASSWORD
    ValidateCashAnalysisPanelReview ws
    MarkAnalysisReviewsDirty
    UpdateCashAnalysisStatusStyle ws
    AdjustCashAnalysisPanelRowHeights ws
    ProtectCashAnalysisViewSheet
SafeExit:
    If eventsCaptured Then
        eventsRestoreAttempted = True
        If Not TryRestoreCashAnalysisEnableEvents( _
                   previousEvents, "OnCashAnalysisViewChange", eventStateDetail) Then _
            Err.Raise vbObjectError + 5097, _
                      "OnCashAnalysisViewChange", eventStateDetail
        eventsCaptured = False
    End If
    Exit Sub
EH:
    errorNumber = Err.Number
    errorSource = Err.Source
    errorDescription = Err.Description
    If IsCashAnalysisRecoveryFatal(errorNumber, errorSource) Then
        Call TryStopCashAnalysisEventsForRecovery(convergenceDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    If eventsCaptured Then _
        eventsReadyForRecovery = _
            TryStopCashAnalysisEventsForRecovery(stopDetail)
    If Not eventsReadyForRecovery Then
        If eventsCaptured Then
            AppendCashAnalysisRollbackDetail recoveryDetail, _
                "画面復元前にExcelイベントを停止して読戻し確認できませんでした: " & _
                stopDetail
        ElseIf Len(stopDetail) > 0 Then
            AppendCashAnalysisRollbackDetail recoveryDetail, _
                "Excelイベントの開始状態を取得できず、" & _
                "停止の読戻し確認にも失敗したため現在状態は不明です: " & _
                stopDetail
        Else
            AppendCashAnalysisRollbackDetail recoveryDetail, _
                "Excelイベントの開始状態と現在状態を確認できませんでした。"
        End If
    End If
    On Error Resume Next
    Err.Clear
    If eventsReadyForRecovery And eventsCaptured Then
        RefreshCashAnalysisPanel False
        refreshError = Err.Number
        refreshErrorSource = Err.Source
        refreshErrorDescription = Err.Description
        viewRestoreConfirmed = (refreshError = 0)
        If refreshError <> 0 Then _
            AppendCashAnalysisRollbackDetail recoveryDetail, _
                "分析パネルの復元エラー: " & refreshErrorDescription
    ElseIf Not eventsReadyForRecovery Then
        refreshError = vbObjectError + 5098
        AppendCashAnalysisRollbackDetail recoveryDetail, _
            "Excelイベント停止を確認できないため分析パネルの再書込みを行いませんでした。"
    Else
        refreshError = vbObjectError + 5098
        AppendCashAnalysisRollbackDetail recoveryDetail, _
            "Excelイベントの開始状態が未取得のため、" & _
            "分析パネルの再書込みを行いませんでした。"
    End If
    On Error GoTo 0
    If IsCashAnalysisRecoveryFatal( _
           refreshError, refreshErrorSource) Then
        Call TryStopCashAnalysisEventsForRecovery(convergenceDetail)
        Err.Raise refreshError, refreshErrorSource, refreshErrorDescription
    End If
    If eventsReadyForRecovery Then
        eventsReadyForRecovery = _
            TryStopCashAnalysisEventsForRecovery(postRefreshStopDetail)
        If Not eventsReadyForRecovery Then _
            AppendCashAnalysisRollbackDetail recoveryDetail, _
                "分析パネル復元後にExcelイベント停止を確認できません。" & _
                "現在状態は不明です: " & postRefreshStopDetail
    End If
    If eventsReadyForRecovery Then
        protectOK = TryProtectCashAnalysisViewAfterFailure( _
                        ws, "OnCashAnalysisViewChange", False, recoveryDetail, _
                        protectionRecoveryAttempted, _
                        protectionRecoveryFailed, _
                        protectionRecoveryConfirmed)
        eventsReadyForRecovery = _
            TryStopCashAnalysisEventsForRecovery(postProtectStopDetail)
        If Not eventsReadyForRecovery Then
            AppendCashAnalysisRollbackDetail recoveryDetail, _
                "再保護処理後にExcelイベント停止を確認できません。" & _
                "現在状態は不明です: " & postProtectStopDetail
        ElseIf protectionRecoveryAttempted Then
            recoveryConfirmed = protectionRecoveryConfirmed
        End If
    End If
    If protectionRecoveryFailed Then
        eventsReadyForRecovery = _
            TryStopCashAnalysisEventsForRecovery(convergenceDetail)
        eventsCaptured = False
        Err.Raise vbObjectError + 5194, _
                  "CashAnalysisRecoveryFatal/OnCashAnalysisViewChange", _
                  errorDescription & " / " & recoveryDetail
    End If
    If eventsReadyForRecovery And refreshError <> 0 And _
       Not protectionRecoveryAttempted Then
        On Error Resume Next
        Err.Clear
        EnforceRollbackRecoveryState recoveryDetail
        recoveryErrorNumber = Err.Number
        recoveryErrorDescription = Err.Description
        Err.Clear
        On Error GoTo 0
        eventsReadyForRecovery = _
            TryStopCashAnalysisEventsForRecovery(postEnforceStopDetail)
        If recoveryErrorNumber <> 0 Then
            AppendCashAnalysisRollbackDetail recoveryDetail, _
                "要復旧状態の強制設定エラー: Err " & _
                CStr(recoveryErrorNumber) & " " & recoveryErrorDescription
            eventsCaptured = False
            Err.Raise vbObjectError + 5194, _
                      "CashAnalysisRecoveryFatal/OnCashAnalysisViewChange", _
                      errorDescription & " / " & recoveryDetail
        ElseIf eventsReadyForRecovery Then
            recoveryConfirmed = _
                CashAnalysisRecoveryStateIsConfirmedExact(recoveryDetail)
            If recoveryConfirmed Then _
                applicationStateConfirmed = _
                    CashAnalysisApplicationStateAllowsEntryRestore( _
                        True, recoveryDetail)
            If applicationStateConfirmed Then _
                eventsReadyForRecovery = _
                    TryStopCashAnalysisEventsForRecovery( _
                        finalRecoveryStopDetail)
        Else
            AppendCashAnalysisRollbackDetail recoveryDetail, _
                "Recovery処理後にExcelイベント停止を確認できないため、" & _
                "復旧状態を読み取らず開始値へも戻しません。現在状態は不明です: " & _
                postEnforceStopDetail
        End If
        If Not recoveryConfirmed Then _
            AppendCashAnalysisRollbackDetail recoveryDetail, _
                "今回のRecovery二重状態を厳密確認できません。"
        If recoveryConfirmed And Not applicationStateConfirmed Then _
            AppendCashAnalysisRollbackDetail recoveryDetail, _
                "Recovery確認後のApplication状態を厳密確認できません。"
        If applicationStateConfirmed And Not eventsReadyForRecovery Then _
            AppendCashAnalysisRollbackDetail recoveryDetail, _
                "Application状態確認後のExcelイベントFalse収束を" & _
                "確認できません: " & finalRecoveryStopDetail
        eventsReadyForRecovery = _
            TryStopCashAnalysisEventsForRecovery(convergenceDetail)
        eventsCaptured = False
        Err.Raise vbObjectError + 5194, _
                  "CashAnalysisRecoveryFatal/OnCashAnalysisViewChange", _
                  errorDescription & " / " & recoveryDetail
    End If
    If eventsCaptured Then
        safeToRestoreEntry = eventsReadyForRecovery And _
                             ((viewRestoreConfirmed And protectOK) Or _
                              recoveryConfirmed)
        If safeToRestoreEntry Then _
            safeToRestoreEntry = _
                CashAnalysisApplicationStateAllowsEntryRestore( _
                    previousEvents, recoveryDetail)
        If safeToRestoreEntry Then
            eventsReadyForRecovery = _
                TryStopCashAnalysisEventsForRecovery(eventStateDetail)
            safeToRestoreEntry = eventsReadyForRecovery
        End If
        If Not eventsRestoreAttempted And safeToRestoreEntry Then
            If Not TryRestoreCashAnalysisEnableEvents( _
                       previousEvents, "OnCashAnalysisViewChange", _
                       eventStateDetail) Then _
                AppendCashAnalysisRollbackDetail recoveryDetail, eventStateDetail
        ElseIf TryStopCashAnalysisEventsForRecovery(convergenceDetail) Then
            AppendCashAnalysisRollbackDetail recoveryDetail, _
                "画面復元・再保護またはRecoveryを厳密確認できないため、" & _
                "開始時イベント値へ戻さずFalseで停止しました。"
        Else
            AppendCashAnalysisRollbackDetail recoveryDetail, _
                "安全状態を厳密確認できず、ExcelイベントのFalse収束にも" & _
                "失敗しました。現在状態は不明です: " & convergenceDetail
        End If
    End If
    eventsCaptured = False
    If Len(recoveryDetail) > 0 Then _
        errorDescription = errorDescription & " / 復元確認: " & recoveryDetail
    userMessage = "確認状況または確認メモを更新できませんでした。" & vbCrLf
    If viewRestoreConfirmed Then
        userMessage = userMessage & "入力前の内容へ戻しました。"
    Else
        userMessage = userMessage & _
            "入力前の内容への復元は確認できません。" & _
            "現在のブックを上書きしないでください。"
    End If
    MsgBox userMessage & vbCrLf & _
           "候補区分に合う確認状況と、" & _
           CStr(VIEW_MEMO_MAX) & "文字以内のメモを入力してください。" & vbCrLf & _
           "Err " & CStr(errorNumber) & ": " & errorDescription, _
           vbExclamation, "分析判断の入力を確認してください"
End Sub

Public Sub SyncCashAnalysisPanelReviewToWorkspace()
    Dim ws As Worksheet, wsResult As Worksheet
    Dim groupID As String, statusText As String, memoText As String
    Dim sourceSheet As String, sourceKey As String, categoryText As String
    Dim resultRow As Long, sourceRow As Long, lastR As Long, r As Long
    Dim groupValues As Variant
    Dim resultStatusSnapshot As Variant, resultMemoSnapshot As Variant
    Dim previousEvents As Boolean, changed As Boolean, eventsCaptured As Boolean
    Dim eventsRestoreAttempted As Boolean
    Dim snapshotsCaptured As Boolean, writeStarted As Boolean
    Dim isAlternative As Boolean
    Dim workspaceSyncCompleted As Boolean, rollbackOK As Boolean, protectOK As Boolean
    Dim eventsReadyForRollback As Boolean, recoveryConfirmed As Boolean
    Dim applicationStateConfirmed As Boolean
    Dim safeToRestoreEntry As Boolean
    Dim recoveryDetail As String, eventStateDetail As String, stopDetail As String
    Dim dirtyErrorNumber As Long, dirtyErrorDescription As String
    Dim recoveryErrorNumber As Long, recoveryErrorDescription As String
    Dim postEnforceStopDetail As String, convergenceDetail As String
    Dim finalRecoveryStopDetail As String
    Dim errorNumber As Long, errorSource As String, errorDescription As String
    If ThisWorkbook.ReadOnly Then Exit Sub
    On Error GoTo EH
    '復元・再保護・dirty記録を含む全経路でイベント再入を防ぐ。
    If Not TryGetCashAnalysisEnableEvents(previousEvents, eventStateDetail) Then
        StopAfterCashAnalysisEventStateFailure _
            "SyncCashAnalysisPanelReviewToWorkspace/開始状態取得", _
            eventStateDetail, eventsReadyForRollback, False, vbNullString
        Err.Raise vbObjectError + 5099, _
                  "SyncCashAnalysisPanelReviewToWorkspace", _
                  "Excelイベントの開始状態を取得できませんでした。 " & eventStateDetail
    End If
    eventsCaptured = True
    If Not TrySetCashAnalysisEnableEventsExact(False, eventStateDetail) Then _
        Err.Raise vbObjectError + 5100, _
                  "SyncCashAnalysisPanelReviewToWorkspace", _
                  "分析判断の同期前にExcelイベントを停止できませんでした。 " & _
                  eventStateDetail
    If Not SheetExists(SH_OUTPUT_TX) Or Not SheetExists(SH_ANALYSIS_RESULT) Then GoTo SafeExit
    Set ws = GetSheet(SH_OUTPUT_TX)
    If CellText(ws.Range(VIEW_STATE_MANUAL).Value) = "1" Then GoTo SafeExit
    groupID = CellText(ws.Range(VIEW_STATE_GROUP_ID).Value)
    If Len(groupID) = 0 Then GoTo SafeExit
    ValidateCashAnalysisPanelReview ws
    statusText = CellText(ws.Range("C3").Value)
    memoText = CellText(ws.Range("C8").Value)
    Set wsResult = GetSheet(SH_ANALYSIS_RESULT)
    If Not TryGetLastUsedRowInSheet(wsResult, lastR) Then _
        Err.Raise vbObjectError + 4982, "SyncCashAnalysisPanelReviewToWorkspace", _
                  "分析結果の最終行を確認できません。"
    If lastR >= 2 Then _
        RequireAnalysisReviewConstantRange wsResult.Range( _
            wsResult.Cells(2, ANALYSIS_RESULT_GROUP_ID_COL), _
            wsResult.Cells(lastR, ANALYSIS_RESULT_GROUP_ID_COL)), _
            "分析結果の内部グループID"
    resultRow = CLng(Val(CellText(ws.Range(VIEW_STATE_RESULT_ROW).Value)))
    'VBAのOrは短絡評価されないため、範囲外行でCellsを読まず段階的に再検索へ落とす。
    If resultRow < 2 Or resultRow > lastR Then
        resultRow = 0
    ElseIf StrComp( _
               CellText(wsResult.Cells(resultRow, ANALYSIS_RESULT_GROUP_ID_COL).Value), _
               groupID, vbTextCompare) <> 0 Then
        resultRow = 0
    End If
    If resultRow = 0 Then
        If lastR >= 2 Then _
            groupValues = CashResultColumnValues(wsResult, 2, lastR, ANALYSIS_RESULT_GROUP_ID_COL)
        For r = 1 To Application.Max(0, lastR - 1)
            If StrComp(CellText(groupValues(r, 1)), groupID, vbTextCompare) = 0 Then
                resultRow = r + 1
                Exit For
            End If
        Next r
    End If
    If resultRow = 0 Then _
        Err.Raise vbObjectError + 4982, "SyncCashAnalysisPanelReviewToWorkspace", _
                  "資金操作表に表示中の分析候補が、分析結果から見つかりません。再分析前の同期を中止しました。"
    If Not CashAnalysisCurrentSourceReference( _
               ws, wsResult, resultRow, sourceSheet, sourceRow, sourceKey, _
               categoryText, isAlternative) Then _
        Err.Raise vbObjectError + 5011, "SyncCashAnalysisPanelReviewToWorkspace", _
                  "資金操作表に表示中の候補と内部根拠を一意に対応付けられません。"
    RequireCashAnalysisGroupConfirmationAvailable groupID, _
        CashAnalysisCandidateReference(sourceSheet, sourceRow, sourceKey), statusText
    If isAlternative Then
        '代替候補の判断は、その代替の元表・候補詳細だけへ保存する。
        'グループ代表の分析結果を誤って上書きしない。
        MarkAnalysisReviewsDirty
        If SyncCashAnalysisReviewToSourceAndDetailSnapshot( _
                sourceSheet, sourceRow, sourceKey, categoryText, statusText, memoText) Then _
            changed = True
        workspaceSyncCompleted = True
        GoTo SafeExit
    End If
    RequireAnalysisReviewConstantRange Union( _
        wsResult.Cells(resultRow, 2), _
        wsResult.Range(wsResult.Cells(resultRow, ANALYSIS_RESULT_STATUS_COL), _
                       wsResult.Cells(resultRow, ANALYSIS_RESULT_MEMO_COL)), _
        wsResult.Range(wsResult.Cells(resultRow, ANALYSIS_RESULT_SOURCE_SHEET_COL), _
                       wsResult.Cells(resultRow, ANALYSIS_RESULT_ALTERNATIVE_COUNT_COL))), _
        "分析結果の確認欄または内部参照"
    wsResult.Unprotect Password:=TOOL_PASSWORD
    resultStatusSnapshot = wsResult.Cells(resultRow, ANALYSIS_RESULT_STATUS_COL).Value2
    resultMemoSnapshot = wsResult.Cells(resultRow, ANALYSIS_RESULT_MEMO_COL).Value2
    If Not StrictVariantValuesMatch( _
               resultStatusSnapshot, _
               wsResult.Cells(resultRow, ANALYSIS_RESULT_STATUS_COL).Value2) Or _
       Not StrictVariantValuesMatch( _
               resultMemoSnapshot, _
               wsResult.Cells(resultRow, ANALYSIS_RESULT_MEMO_COL).Value2) Then _
        Err.Raise vbObjectError + 4983, "SyncCashAnalysisPanelReviewToWorkspace", _
                  "分析結果の確認欄を型まで厳密に退避できません。"
    snapshotsCaptured = True
    writeStarted = True
    changed = WriteCashAnalysisReviewTextCellIfChanged( _
                  wsResult.Cells(resultRow, ANALYSIS_RESULT_STATUS_COL), _
                  statusText, "分析結果の確認状況")
    If WriteCashAnalysisReviewTextCellIfChanged( _
           wsResult.Cells(resultRow, ANALYSIS_RESULT_MEMO_COL), _
           memoText, "分析結果の確認メモ") Then changed = True
    ProtectSingleAnalysisSheet wsResult
    MarkAnalysisReviewsDirty
    '候補詳細に同じ候補の旧スナップショットが残っていても、後続Commitで現在値を
    '上書きしないよう、元表と対応する詳細行を同じ値へ厳密同期する。
    If SyncCashAnalysisReviewToSourceAndDetailSnapshot( _
            sourceSheet, sourceRow, sourceKey, categoryText, statusText, memoText) Then _
        changed = True
    workspaceSyncCompleted = True
SafeExit:
    If eventsCaptured Then
        eventsRestoreAttempted = True
        If Not TryRestoreCashAnalysisEnableEvents( _
                   previousEvents, _
                   "SyncCashAnalysisPanelReviewToWorkspace", _
                   eventStateDetail) Then _
            Err.Raise vbObjectError + 5101, _
                      "SyncCashAnalysisPanelReviewToWorkspace", eventStateDetail
        eventsCaptured = False
    End If
    Exit Sub
EH:
    errorNumber = Err.Number
    errorSource = Err.Source
    errorDescription = Err.Description
    If IsCashAnalysisRecoveryFatal(errorNumber, errorSource) Then
        Call TryStopCashAnalysisEventsForRecovery(convergenceDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    If eventsCaptured Then _
        eventsReadyForRollback = _
            TryStopCashAnalysisEventsForRecovery(stopDetail)
    If Not eventsReadyForRollback Then
        If eventsCaptured Then
            AppendCashAnalysisRollbackDetail recoveryDetail, _
                "ロールバック前にExcelイベントを停止して読戻し確認できませんでした: " & _
                stopDetail
        ElseIf Len(stopDetail) > 0 Then
            AppendCashAnalysisRollbackDetail recoveryDetail, _
                "Excelイベントの開始状態を取得できず、" & _
                "停止の読戻し確認にも失敗したため現在状態は不明です: " & _
                stopDetail
        Else
            AppendCashAnalysisRollbackDetail recoveryDetail, _
                "Excelイベントの開始状態と現在状態を確認できませんでした。"
        End If
    End If
    On Error Resume Next
    Err.Clear
    rollbackOK = True
    If writeStarted And snapshotsCaptured And Not workspaceSyncCompleted Then
        If eventsReadyForRollback Then
            rollbackOK = RestoreCashAnalysisResultReviewSnapshot( _
                             wsResult, resultRow, resultStatusSnapshot, _
                             resultMemoSnapshot, recoveryDetail)
        Else
            rollbackOK = False
            AppendCashAnalysisRollbackDetail recoveryDetail, _
                "Excelイベント停止を確認できないため分析結果の退避値を再書込みしませんでした。"
        End If
    End If
    protectOK = True
    If Not wsResult Is Nothing Then
        If eventsReadyForRollback Then
            Err.Clear
            ProtectSingleAnalysisSheet wsResult
        Else
            protectOK = False
            AppendCashAnalysisRollbackDetail recoveryDetail, _
                "イベント停止未確認のため分析結果を再保護しませんでした。"
        End If
        If eventsReadyForRollback And Err.Number <> 0 Then
            protectOK = False
            AppendCashAnalysisRollbackDetail recoveryDetail, _
                "分析結果の再保護エラー: " & Err.Description
        End If
    End If
    Err.Clear
    If eventsReadyForRollback Then
        MarkAnalysisReviewsDirty
        dirtyErrorNumber = Err.Number
        dirtyErrorDescription = Err.Description
    Else
        AppendCashAnalysisRollbackDetail recoveryDetail, _
            "イベント停止未確認のため分析判断要同期状態を記録しませんでした。"
    End If
    Err.Clear
    If dirtyErrorNumber <> 0 Then _
        AppendCashAnalysisRollbackDetail recoveryDetail, _
            "分析判断要同期状態の記録エラー: Err " & _
            CStr(dirtyErrorNumber) & " " & dirtyErrorDescription
    If Not eventsReadyForRollback Or Not rollbackOK Or Not protectOK Or _
        dirtyErrorNumber <> 0 Then
        If eventsReadyForRollback Then
            Err.Clear
            EnforceRollbackRecoveryState recoveryDetail
            recoveryErrorNumber = Err.Number
            recoveryErrorDescription = Err.Description
            Err.Clear
            'Enforceの結果を保存した直後にFalseを取り直す。失敗時は、
            '古いRecovery値の読取り・追加書込み・開始値復元へ進まない。
            eventsReadyForRollback = _
                TryStopCashAnalysisEventsForRecovery(postEnforceStopDetail)
            If recoveryErrorNumber <> 0 Then
                AppendCashAnalysisRollbackDetail recoveryDetail, _
                    "要復旧状態の強制設定エラー: Err " & _
                    CStr(recoveryErrorNumber) & " " & recoveryErrorDescription
                On Error GoTo 0
                eventsCaptured = False
                Err.Raise vbObjectError + 5194, _
                    "CashAnalysisRecoveryFatal/SyncCashAnalysisPanelReviewToWorkspace", _
                    errorDescription & " / " & recoveryDetail
            ElseIf eventsReadyForRollback Then
                recoveryConfirmed = _
                    CashAnalysisRecoveryStateIsConfirmedExact(recoveryDetail)
                If recoveryConfirmed Then _
                    applicationStateConfirmed = _
                        CashAnalysisApplicationStateAllowsEntryRestore( _
                            True, recoveryDetail)
                If applicationStateConfirmed Then _
                    eventsReadyForRollback = _
                        TryStopCashAnalysisEventsForRecovery( _
                            finalRecoveryStopDetail)
            Else
                AppendCashAnalysisRollbackDetail recoveryDetail, _
                    "Recovery処理後にExcelイベント停止を確認できないため、" & _
                    "復旧状態を読み取らず開始値へも戻しません。現在状態は不明です: " & _
                    postEnforceStopDetail
            End If
            If Not recoveryConfirmed Then _
                AppendCashAnalysisRollbackDetail recoveryDetail, _
                    "今回のRecovery二重状態を厳密確認できません。"
            If recoveryConfirmed And Not applicationStateConfirmed Then _
                AppendCashAnalysisRollbackDetail recoveryDetail, _
                    "Recovery確認後のApplication状態を厳密確認できません。"
            If applicationStateConfirmed And Not eventsReadyForRollback Then _
                AppendCashAnalysisRollbackDetail recoveryDetail, _
                    "Application状態確認後のExcelイベントFalse収束を" & _
                    "確認できません: " & finalRecoveryStopDetail
            eventsReadyForRollback = _
                TryStopCashAnalysisEventsForRecovery(convergenceDetail)
            On Error GoTo 0
            eventsCaptured = False
            Err.Raise vbObjectError + 5194, _
                "CashAnalysisRecoveryFatal/SyncCashAnalysisPanelReviewToWorkspace", _
                errorDescription & " / " & recoveryDetail
        Else
            AppendCashAnalysisRollbackDetail recoveryDetail, _
                "イベント停止未確認のためRecovery状態を記録しませんでした。"
        End If
    End If
    On Error GoTo 0
    If eventsCaptured Then
        safeToRestoreEntry = eventsReadyForRollback And _
                             ((rollbackOK And protectOK And _
                               dirtyErrorNumber = 0) Or recoveryConfirmed)
        If safeToRestoreEntry Then _
            safeToRestoreEntry = _
                CashAnalysisApplicationStateAllowsEntryRestore( _
                    previousEvents, recoveryDetail)
        If safeToRestoreEntry Then
            eventsReadyForRollback = _
                TryStopCashAnalysisEventsForRecovery(eventStateDetail)
            safeToRestoreEntry = eventsReadyForRollback
        End If
        If Not eventsRestoreAttempted And safeToRestoreEntry Then
            If Not TryRestoreCashAnalysisEnableEvents( _
                       previousEvents, _
                       "SyncCashAnalysisPanelReviewToWorkspace", _
                       eventStateDetail) Then _
                AppendCashAnalysisRollbackDetail recoveryDetail, eventStateDetail
        ElseIf TryStopCashAnalysisEventsForRecovery(convergenceDetail) Then
            AppendCashAnalysisRollbackDetail recoveryDetail, _
                "ロールバック・再保護またはRecoveryを厳密確認できないため、" & _
                "開始時イベント値へ戻さずFalseで停止しました。"
        Else
            AppendCashAnalysisRollbackDetail recoveryDetail, _
                "安全状態を厳密確認できず、ExcelイベントのFalse収束にも" & _
                "失敗しました。現在状態は不明です: " & convergenceDetail
        End If
    End If
    eventsCaptured = False
    If Len(recoveryDetail) > 0 Then _
        errorDescription = errorDescription & " / 復元確認: " & recoveryDetail
    If Len(errorSource) = 0 Then _
        errorSource = "SyncCashAnalysisPanelReviewToWorkspace"
    Err.Raise errorNumber, errorSource, errorDescription
End Sub

Private Function WriteCashAnalysisReviewTextCellIfChanged( _
        ByVal target As Range, ByVal textValue As String, _
        ByVal labelText As String) As Boolean
    Dim expectedData As Variant
    ReDim expectedData(1 To 1, 1 To 1)
    If target Is Nothing Then _
        Err.Raise vbObjectError + 4984, _
                  "WriteCashAnalysisReviewTextCellIfChanged", _
                  labelText & "の書込先を取得できません。"
    If target.Cells.CountLarge <> 1 Then _
        Err.Raise vbObjectError + 4984, _
                  "WriteCashAnalysisReviewTextCellIfChanged", _
                  labelText & "の書込先が単一セルではありません。"
    If Len(textValue) = 0 Then
        expectedData(1, 1) = Empty
    Else
        expectedData(1, 1) = CStr(textValue)
    End If
    If StrictVariantValuesMatch(expectedData(1, 1), target.Value2) And _
       Not target.HasFormula And Len(CStr(target.PrefixCharacter)) = 0 Then Exit Function
    target.NumberFormatLocal = "@"
    target.Value2 = expectedData(1, 1)
    If Not RangeValue2MatchesMatrixStrict(target, expectedData, 1, 1) Then _
        Err.Raise vbObjectError + 4985, _
                  "WriteCashAnalysisReviewTextCellIfChanged", _
                  labelText & "の書込読戻しが型まで一致しません。"
    RequireAnalysisReviewConstantRange target, labelText
    WriteCashAnalysisReviewTextCellIfChanged = True
End Function

Private Function RestoreCashAnalysisResultReviewSnapshot( _
        ByVal ws As Worksheet, ByVal resultRow As Long, _
        ByVal statusSnapshot As Variant, ByVal memoSnapshot As Variant, _
        ByRef detailText As String) As Boolean
    Dim expectedData As Variant
    ReDim expectedData(1 To 1, 1 To 1)
    On Error GoTo EH
    If ws Is Nothing Or resultRow < 2 Then _
        Err.Raise vbObjectError + 4986, _
                  "RestoreCashAnalysisResultReviewSnapshot", _
                  "分析結果の復元先が不正です。"
    ws.Unprotect Password:=TOOL_PASSWORD
    expectedData(1, 1) = statusSnapshot
    ws.Cells(resultRow, ANALYSIS_RESULT_STATUS_COL).Value2 = expectedData(1, 1)
    If Not RangeValue2MatchesMatrixStrict( _
               ws.Cells(resultRow, ANALYSIS_RESULT_STATUS_COL), _
               expectedData, 1, 1) Then _
        Err.Raise vbObjectError + 4987, _
                  "RestoreCashAnalysisResultReviewSnapshot", _
                  "分析結果の確認状況を厳密に復元できません。"
    expectedData(1, 1) = memoSnapshot
    ws.Cells(resultRow, ANALYSIS_RESULT_MEMO_COL).Value2 = expectedData(1, 1)
    If Not RangeValue2MatchesMatrixStrict( _
               ws.Cells(resultRow, ANALYSIS_RESULT_MEMO_COL), _
               expectedData, 1, 1) Then _
        Err.Raise vbObjectError + 4988, _
                  "RestoreCashAnalysisResultReviewSnapshot", _
                  "分析結果の確認メモを厳密に復元できません。"
    RestoreCashAnalysisResultReviewSnapshot = True
    Exit Function
EH:
    detailText = "分析結果の復元エラー: " & Err.Description
    Err.Clear
End Function

Private Sub ValidateCashAnalysisPanelReview(ByVal ws As Worksheet)
    Dim categoryText As String, statusText As String, memoText As String
    RequireAnalysisReviewConstantRange Union(ws.Range("C3"), ws.Range("C8")), _
        "資金操作表の分析確認欄"
    categoryText = CellText(ws.Range(VIEW_STATE_CATEGORY).Value)
    statusText = CellText(ws.Range("C3").Value)
    memoText = CellText(ws.Range("C8").Value)
    If Len(statusText) = 0 Then
        statusText = ANALYSIS_STATUS_UNREVIEWED
        WriteCashAnalysisReviewTextCellIfChanged ws.Range("C3"), statusText, _
            "資金操作表の確認状況"
    End If
    If Not IsStatusAllowedForCashCategory(categoryText, statusText) Then _
        Err.Raise vbObjectError + 4980, "ValidateCashAnalysisPanelReview", _
                  "確認状況「" & statusText & "」は" & categoryText & "では選択できません。"
    If Len(memoText) > VIEW_MEMO_MAX Then _
        Err.Raise vbObjectError + 4981, "ValidateCashAnalysisPanelReview", _
                  "確認メモは" & CStr(VIEW_MEMO_MAX) & "文字以内で入力してください。"
End Sub

Private Sub ApplyCashAnalysisPanelValidation(ByVal ws As Worksheet)
    Dim listName As String
    On Error Resume Next
    ws.Range("C3").Validation.Delete
    ws.Range("C8").Validation.Delete
    On Error GoTo 0
    If CellText(ws.Range(VIEW_STATE_MANUAL).Value) = "1" Or _
       Len(CellText(ws.Range(VIEW_STATE_GROUP_ID).Value)) = 0 Then Exit Sub
    Select Case CellText(ws.Range(VIEW_STATE_CATEGORY).Value)
        Case VIEW_CATEGORY_UNKNOWN_DEPOSIT: listName = NM_LST_ANALYSIS_SOURCE_STATUS
        Case VIEW_CATEGORY_UNKNOWN_WITHDRAW: listName = NM_LST_ANALYSIS_USE_STATUS
        Case Else: listName = NM_LST_ANALYSIS_SHIFT_STATUS
    End Select
    With ws.Range("C3").Validation
        .Add Type:=xlValidateList, AlertStyle:=xlValidAlertStop, _
             Operator:=xlBetween, Formula1:="=" & listName
        .IgnoreBlank = False
        .InCellDropdown = True
        .ShowError = True
        .ErrorTitle = "確認状況を選択してください"
        .ErrorMessage = "候補区分に合う確認状況を一覧から選択してください。"
    End With
    With ws.Range("C8").Validation
        .Add Type:=xlValidateTextLength, AlertStyle:=xlValidAlertStop, _
             Operator:=xlLessEqual, Formula1:=CStr(VIEW_MEMO_MAX)
        .IgnoreBlank = True
        .ShowError = True
        .ErrorTitle = "確認メモが長すぎます"
        .ErrorMessage = "確認メモは" & CStr(VIEW_MEMO_MAX) & "文字以内で入力してください。"
    End With
End Sub

Private Sub UpdateCashAnalysisStatusStyle(ByVal ws As Worksheet)
    Dim statusText As String
    statusText = CellText(ws.Range("C3").Value)
    With ws.Range("C3:D3")
        .Font.Bold = True
        .HorizontalAlignment = xlCenter
        Select Case statusText
            Case ANALYSIS_STATUS_SHIFT_CONFIRMED, ANALYSIS_STATUS_SOURCE_CONFIRMED, ANALYSIS_STATUS_USE_CONFIRMED
                .Interior.Color = RGB(220, 252, 231)
                .Font.Color = RGB(22, 101, 52)
            Case ANALYSIS_STATUS_FOLLOWUP
                .Interior.Color = RGB(254, 243, 199)
                .Font.Color = RGB(146, 64, 14)
            Case ANALYSIS_STATUS_EXCLUDED
                .Interior.Color = RGB(226, 232, 240)
                .Font.Color = RGB(71, 85, 105)
            Case Else
                .Interior.Color = RGB(254, 249, 195)
                .Font.Color = RGB(133, 77, 14)
        End Select
    End With
    UpdateCashAnalysisPrimaryActionState ws, statusText
End Sub

Private Sub UpdateCashAnalysisPrimaryActionState(ByVal ws As Worksheet, ByVal statusText As String)
    Dim confirmedStatus As String
    If ws Is Nothing Then Exit Sub
    If CellText(ws.Range(VIEW_STATE_MANUAL).Value) = "1" Then Exit Sub
    If Len(CellText(ws.Range(VIEW_STATE_GROUP_ID).Value)) = 0 Then
        SetShapeCaption ws, "CashAnalysisPrimaryAction", "候補なし"
        SetViewButtonColors ws, "CashAnalysisPrimaryAction", _
                            RGB(241, 245, 249), RGB(203, 213, 225), RGB(100, 116, 139)
        Exit Sub
    End If
    confirmedStatus = ConfirmedStatusForCashCategory(CellText(ws.Range(VIEW_STATE_CATEGORY).Value))
    Select Case statusText
        Case confirmedStatus
            SetShapeCaption ws, "CashAnalysisPrimaryAction", "確認内容を保存"
            SetViewButtonColors ws, "CashAnalysisPrimaryAction", _
                                RGB(220, 252, 231), RGB(34, 197, 94), RGB(22, 101, 52)
        Case ANALYSIS_STATUS_FOLLOWUP
            SetShapeCaption ws, "CashAnalysisPrimaryAction", "要追加調査で保存"
            SetViewButtonColors ws, "CashAnalysisPrimaryAction", _
                                RGB(254, 243, 199), RGB(245, 158, 11), RGB(146, 64, 14)
        Case ANALYSIS_STATUS_EXCLUDED
            SetShapeCaption ws, "CashAnalysisPrimaryAction", "対象外で保存"
            SetViewButtonColors ws, "CashAnalysisPrimaryAction", _
                                RGB(226, 232, 240), RGB(148, 163, 184), RGB(71, 85, 105)
        Case Else
            SetShapeCaption ws, "CashAnalysisPrimaryAction", "確認済みにする"
            SetViewButtonColors ws, "CashAnalysisPrimaryAction", _
                                RGB(37, 99, 235), RGB(29, 78, 216), RGB(255, 255, 255)
    End Select
End Sub

Public Function RequireCashAnalysisManualModeFinished(ByVal intendedAction As String) As Boolean
    Dim selectionText As String
    If Not CashAnalysisManualModeActive() Then
        RequireCashAnalysisManualModeFinished = True
        Exit Function
    End If
    If HasCashAnalysisManualSelection() Then
        selectionText = "選択中の取引があります。"
    Else
        selectionText = "現在、手動候補の選択モードです。"
    End If
    MsgBox selectionText & vbCrLf & _
           intendedAction & "の前に、［選択した候補を登録］または［選択を取り消す］を押してください。" & _
           vbCrLf & "選択内容を黙って破棄することはありません。", _
           vbInformation, "手動候補の選択を完了してください"
End Function

Public Sub PrepareCashAnalysisViewForPrint()
    '印刷時も分析根拠を省略しない。説明欄を全表示してから、図形の非印刷、
    '印刷範囲、A4横・横1ページ幅を直前に再検証する。
    Dim ws As Worksheet
    Dim lastR As Long
    Dim eventsReady As Boolean
    Dim convergenceDetail As String
    Dim errorNumber As Long, errorSource As String, errorDescription As String
    If Not SheetExists(SH_OUTPUT_TX) Then Exit Sub
    On Error GoTo EH
    Set ws = GetSheet(SH_OUTPUT_TX)
    ws.Unprotect Password:=TOOL_PASSWORD
    ws.Range(VIEW_STATE_PANEL_EXPANDED).Value = "1"
    AdjustCashAnalysisPanelRowHeights ws
    ApplyCashAnalysisPrintPanelHeights ws
    lastR = CashAnalysisLastDataRow(ws)
    If lastR < CASH_VIEW_HEADER_ROW Then lastR = CASH_VIEW_HEADER_ROW
    ApplyPrintAreaVerified ws, ws.Range("A1:M" & CStr(lastR)), True
    ApplyReadablePrintSettings ws, "$10:$10", 1, "", True
    '印刷直前は「設定APIが成功したらよい」ではなく、全操作図形について
    '非印刷を読戻せたことまで必須にする。未知状態のまま紙面へ進ませない。
    LockToolShapes ws, True
    ProtectCashAnalysisViewSheet
    Exit Sub
EH:
    errorNumber = Err.Number
    errorSource = Err.Source
    errorDescription = Err.Description
    If IsCashAnalysisRecoveryFatal(errorNumber, errorSource) Then
        Call TryStopCashAnalysisEventsForRecovery(convergenceDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    Call TryProtectCashAnalysisViewAfterFailure( _
        ws, "PrepareCashAnalysisViewForPrint", False, errorDescription)
    Err.Raise errorNumber, "PrepareCashAnalysisViewForPrint", errorDescription
End Sub

Private Sub ApplyCashAnalysisPrintPanelHeights(ByVal ws As Worksheet)
    'Excelの1行上限内で、1,000文字の確認メモと長い分析理由を紙面へ残す。
    If ws Is Nothing Then Exit Sub
    ws.Rows(5).RowHeight = CashPanelTextRowHeight(CellText(ws.Range("H5").Value), 90, 31, 409.5)
    ws.Rows(6).RowHeight = CashPanelTextRowHeight(CellText(ws.Range("C6").Value), 150, 38, 409.5)
    ws.Rows(7).RowHeight = CashPanelTextRowHeight(CellText(ws.Range("C7").Value), 150, 38, 409.5)
    ws.Rows(8).RowHeight = CashPanelTextRowHeight(CellText(ws.Range("C8").Value), 150, 42, 409.5)
End Sub

Public Sub ProtectCashAnalysisViewSheet()
    Dim ws As Worksheet, canEdit As Boolean
    Dim lockLastRow As Long
    Dim workbookWasSaved As Boolean, protectOK As Boolean
    Dim entryEvents As Boolean, eventsCaptured As Boolean, eventsReady As Boolean
    Dim protectionMutationStarted As Boolean, safeToRestoreEntry As Boolean
    Dim protectionRecoveryAttempted As Boolean
    Dim protectionRecoveryFailed As Boolean
    Dim protectionRecoveryConfirmed As Boolean
    Dim policyConfirmed As Boolean
    Dim eventDetail As String, convergenceDetail As String
    Dim finalRecoveryStopDetail As String
    Dim policyDetail As String
    Dim savedErrorNumber As Long, savedErrorDescription As String
    Dim errorNumber As Long, errorSource As String, errorDescription As String
    If Not SheetExists(SH_OUTPUT_TX) Then Exit Sub
    On Error GoTo EH
    Set ws = GetSheet(SH_OUTPUT_TX)
    workbookWasSaved = ThisWorkbook.Saved
    If Not TryGetCashAnalysisEnableEvents(entryEvents, eventDetail) Then _
        Err.Raise vbObjectError + 5106, "ProtectCashAnalysisViewSheet", _
                  "Excelイベントの開始状態を取得できませんでした。 " & eventDetail
    eventsCaptured = True
    eventsReady = TryStopCashAnalysisEventsForRecovery(eventDetail)
    If Not eventsReady Then _
        Err.Raise vbObjectError + 5107, "ProtectCashAnalysisViewSheet", _
                  "保護前にExcelイベント停止を確認できませんでした。 " & eventDetail
    protectionMutationStarted = True
    ws.Unprotect Password:=TOOL_PASSWORD
    lockLastRow = Application.Min(ws.Rows.Count, _
                  Application.Max(60, LastUsedRowInSheet(ws) + 20))
    ws.Range("A1:Z" & CStr(lockLastRow)).Locked = True
    RestoreToolSheetScrollArea ws
    canEdit = Not ThisWorkbook.ReadOnly And _
              CellText(ws.Range(VIEW_STATE_MANUAL).Value) <> "1" And _
              Len(CellText(ws.Range(VIEW_STATE_GROUP_ID).Value)) > 0
    If canEdit Then
        ws.Range("C3:D3").Locked = False
        ws.Range("C8:M8").Locked = False
    End If
    '通常表示・セットアップ時は、Officeビルド差のあるPrintObjectだけを
    'best-effortにする。印刷時はPrepareCashAnalysisViewForPrintで厳格検証する。
    LockToolShapes ws, False
    ws.Protect Password:=TOOL_PASSWORD, DrawingObjects:=True, Contents:=True, Scenarios:=False, _
               UserInterfaceOnly:=True, AllowFiltering:=True, AllowSorting:=False, _
               AllowFormattingCells:=False, AllowFormattingColumns:=False, AllowFormattingRows:=False
    ws.EnableSelection = xlNoRestrictions
    VerifyToolShapeSecurity ws, True, False
    policyConfirmed = _
        CashAnalysisProtectionPolicyIsConfirmedExact(ws, policyDetail)
    If Not policyConfirmed Then _
        Err.Raise vbObjectError + 5114, "ProtectCashAnalysisViewSheet", _
                  "資金操作表の全保護ポリシーを読戻し確認できませんでした。 " & _
                  policyDetail
    If workbookWasSaved Then ThisWorkbook.Saved = True
    If Not TryRestoreCashAnalysisEnableEvents( _
               entryEvents, "ProtectCashAnalysisViewSheet", eventDetail) Then _
        Err.Raise vbObjectError + 5108, "ProtectCashAnalysisViewSheet", eventDetail
    eventsCaptured = False
    Exit Sub
EH:
    errorNumber = Err.Number
    errorSource = Err.Source
    errorDescription = Err.Description
    If IsCashAnalysisRecoveryFatal(errorNumber, errorSource) Then
        Call TryStopCashAnalysisEventsForRecovery(convergenceDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    eventsReady = False
    If eventsCaptured Then _
        eventsReady = TryStopCashAnalysisEventsForRecovery(eventDetail)
    safeToRestoreEntry = Not protectionMutationStarted
    If eventsReady Then
        protectOK = TryProtectCashAnalysisViewAfterFailure( _
                        ws, "ProtectCashAnalysisViewSheet", True, _
                        errorDescription, protectionRecoveryAttempted, _
                        protectionRecoveryFailed, _
                        protectionRecoveryConfirmed)
        eventsReady = TryStopCashAnalysisEventsForRecovery(eventDetail)
        If Not protectionRecoveryFailed And eventsReady And protectOK Then
            policyDetail = vbNullString
            policyConfirmed = _
                CashAnalysisProtectionPolicyIsConfirmedExact(ws, policyDetail)
            If Not policyConfirmed Then _
                AppendCashAnalysisRollbackDetail errorDescription, policyDetail
        Else
            policyConfirmed = False
        End If
        safeToRestoreEntry = eventsReady And _
            Not protectionRecoveryFailed And _
            (policyConfirmed Or protectionRecoveryConfirmed)
    End If
    If safeToRestoreEntry Then _
        safeToRestoreEntry = _
            CashAnalysisApplicationStateAllowsEntryRestore( _
                entryEvents, errorDescription)
    If safeToRestoreEntry Then
        eventsReady = _
            TryStopCashAnalysisEventsForRecovery(finalRecoveryStopDetail)
        safeToRestoreEntry = eventsReady
    End If
    If eventsReady And Not protectionRecoveryFailed Then
        If workbookWasSaved And policyConfirmed Then
            On Error Resume Next
            Err.Clear
            ThisWorkbook.Saved = True
            savedErrorNumber = Err.Number
            savedErrorDescription = Err.Description
            Err.Clear
            On Error GoTo 0
            If savedErrorNumber <> 0 Then _
                AppendCashAnalysisRollbackDetail errorDescription, _
                    "ブック保存状態の復元エラー: Err " & _
                    CStr(savedErrorNumber) & " " & savedErrorDescription
        End If
    End If
    If Not eventsReady Then _
        AppendCashAnalysisRollbackDetail errorDescription, _
            "Excelイベント停止未確認のため、緊急再保護と保存状態の書込みを行いませんでした。"
    If eventsCaptured Then
        If safeToRestoreEntry Then
            eventsReady = TryStopCashAnalysisEventsForRecovery(eventDetail)
            safeToRestoreEntry = eventsReady
        End If
        If safeToRestoreEntry Then
            If Not TryRestoreCashAnalysisEnableEvents( _
                       entryEvents, "ProtectCashAnalysisViewSheet/エラー終了", _
                       eventDetail) Then
                AppendCashAnalysisRollbackDetail errorDescription, eventDetail
                safeToRestoreEntry = False
                eventsReady = _
                    TryStopCashAnalysisEventsForRecovery(convergenceDetail)
            End If
        ElseIf TryStopCashAnalysisEventsForRecovery(convergenceDetail) Then
            AppendCashAnalysisRollbackDetail errorDescription, _
                "再保護またはRecoveryを厳密確認できないため、" & _
                "開始時イベント値へ戻さずFalseで停止しました。"
        Else
            AppendCashAnalysisRollbackDetail errorDescription, _
                "安全状態を厳密確認できず、ExcelイベントのFalse収束にも" & _
                "失敗しました。現在状態は不明です: " & convergenceDetail
        End If
    End If
    eventsCaptured = False
    If protectionRecoveryFailed Then _
        Err.Raise vbObjectError + 5194, _
                  "CashAnalysisRecoveryFatal/ProtectCashAnalysisViewSheet", _
                  errorDescription
    Err.Raise errorNumber, "ProtectCashAnalysisViewSheet", errorDescription
End Sub

Public Sub SetCashAnalysisViewEditingEnabled(ByVal enabled As Boolean)
    Dim ws As Worksheet
    Dim workbookWasSaved As Boolean, protectOK As Boolean
    Dim entryEvents As Boolean, eventsCaptured As Boolean
    Dim eventsReady As Boolean
    Dim protectionMutationStarted As Boolean, safeToRestoreEntry As Boolean
    Dim protectionRecoveryAttempted As Boolean
    Dim protectionRecoveryFailed As Boolean
    Dim protectionRecoveryConfirmed As Boolean
    Dim policyConfirmed As Boolean
    Dim eventDetail As String, recoveryDetail As String
    Dim convergenceDetail As String, policyDetail As String
    Dim finalRecoveryStopDetail As String
    Dim savedErrorNumber As Long, savedErrorDescription As String
    Dim errorNumber As Long, errorSource As String, errorDescription As String
    If Not SheetExists(SH_OUTPUT_TX) Then Exit Sub
    On Error GoTo EH
    Set ws = GetSheet(SH_OUTPUT_TX)
    workbookWasSaved = ThisWorkbook.Saved
    If Not TryGetCashAnalysisEnableEvents(entryEvents, eventDetail) Then _
        Err.Raise vbObjectError + 5115, "SetCashAnalysisViewEditingEnabled", _
                  "Excelイベントの開始状態を取得できませんでした。 " & eventDetail
    eventsCaptured = True
    eventsReady = TryStopCashAnalysisEventsForRecovery(eventDetail)
    If Not eventsReady Then _
        Err.Raise vbObjectError + 5116, "SetCashAnalysisViewEditingEnabled", _
                  "編集可否の変更前にExcelイベント停止を確認できませんでした。 " & _
                  eventDetail
    protectionMutationStarted = True
    ws.Unprotect Password:=TOOL_PASSWORD
    ws.Range("C3:D3").Locked = Not enabled
    ws.Range("C8:M8").Locked = Not enabled
    ProtectCashAnalysisViewSheet
    eventsReady = TryStopCashAnalysisEventsForRecovery(eventDetail)
    If Not eventsReady Then _
        Err.Raise vbObjectError + 5117, "SetCashAnalysisViewEditingEnabled", _
                  "入れ子の保護処理後にExcelイベント停止を確認できませんでした。 " & _
                  eventDetail
    policyConfirmed = _
        CashAnalysisProtectionPolicyIsConfirmedExact(ws, policyDetail)
    If Not policyConfirmed Then _
        Err.Raise vbObjectError + 5117, "SetCashAnalysisViewEditingEnabled", _
                  "編集可否の変更後に全保護ポリシーを読戻し確認できませんでした。 " & _
                  policyDetail
    If workbookWasSaved Then ThisWorkbook.Saved = True
    If Not TryRestoreCashAnalysisEnableEvents( _
               entryEvents, "SetCashAnalysisViewEditingEnabled", eventDetail) Then _
        Err.Raise vbObjectError + 5118, "SetCashAnalysisViewEditingEnabled", eventDetail
    eventsCaptured = False
    Exit Sub
EH:
    errorNumber = Err.Number
    errorSource = Err.Source
    errorDescription = Err.Description
    If IsCashAnalysisRecoveryFatal(errorNumber, errorSource) Then
        Call TryStopCashAnalysisEventsForRecovery(convergenceDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    eventsReady = False
    If eventsCaptured Then _
        eventsReady = TryStopCashAnalysisEventsForRecovery(eventDetail)
    safeToRestoreEntry = Not protectionMutationStarted
    If eventsReady Then
        protectOK = TryProtectCashAnalysisViewAfterFailure( _
                        ws, "SetCashAnalysisViewEditingEnabled", True, _
                        recoveryDetail, protectionRecoveryAttempted, _
                        protectionRecoveryFailed, _
                        protectionRecoveryConfirmed)
        eventsReady = TryStopCashAnalysisEventsForRecovery(eventDetail)
        If Not protectionRecoveryFailed And eventsReady And protectOK Then
            policyConfirmed = _
                CashAnalysisProtectionPolicyIsConfirmedExact(ws, policyDetail)
            If Not policyConfirmed Then _
                AppendCashAnalysisRollbackDetail recoveryDetail, policyDetail
        Else
            policyConfirmed = False
        End If
        safeToRestoreEntry = eventsReady And _
            Not protectionRecoveryFailed And _
            (policyConfirmed Or protectionRecoveryConfirmed)
    End If
    If safeToRestoreEntry Then _
        safeToRestoreEntry = _
            CashAnalysisApplicationStateAllowsEntryRestore( _
                entryEvents, recoveryDetail)
    If safeToRestoreEntry Then
        eventsReady = _
            TryStopCashAnalysisEventsForRecovery(finalRecoveryStopDetail)
        safeToRestoreEntry = eventsReady
    End If
    If eventsReady And Not protectionRecoveryFailed Then
        On Error Resume Next
        Err.Clear
        If workbookWasSaved And policyConfirmed Then
            ThisWorkbook.Saved = True
            savedErrorNumber = Err.Number
            savedErrorDescription = Err.Description
            Err.Clear
        End If
        On Error GoTo 0
    Else
        AppendCashAnalysisRollbackDetail recoveryDetail, _
            "Excelイベント停止未確認のため、緊急再保護と保存状態の書込みを行いませんでした。"
    End If
    If savedErrorNumber <> 0 Then _
        AppendCashAnalysisRollbackDetail recoveryDetail, _
            "ブック保存状態の復元エラー: Err " & CStr(savedErrorNumber) & _
            " " & savedErrorDescription
    If eventsCaptured Then
        If safeToRestoreEntry Then
            eventsReady = TryStopCashAnalysisEventsForRecovery(eventDetail)
            safeToRestoreEntry = eventsReady
        End If
        If safeToRestoreEntry Then
            If Not TryRestoreCashAnalysisEnableEvents( _
                       entryEvents, _
                       "SetCashAnalysisViewEditingEnabled/エラー終了", _
                       eventDetail) Then
                AppendCashAnalysisRollbackDetail recoveryDetail, eventDetail
                safeToRestoreEntry = False
                eventsReady = _
                    TryStopCashAnalysisEventsForRecovery(convergenceDetail)
            End If
        ElseIf TryStopCashAnalysisEventsForRecovery(convergenceDetail) Then
            AppendCashAnalysisRollbackDetail recoveryDetail, _
                "再保護またはRecoveryを厳密確認できないため、" & _
                "開始時イベント値へ戻さずFalseで停止しました。"
        Else
            AppendCashAnalysisRollbackDetail recoveryDetail, _
                "安全状態を厳密確認できず、ExcelイベントのFalse収束にも" & _
                "失敗しました。現在状態は不明です: " & convergenceDetail
        End If
    End If
    eventsCaptured = False
    If Len(recoveryDetail) > 0 Then _
        errorDescription = errorDescription & " / 復元確認: " & recoveryDetail
    If protectionRecoveryFailed Then _
        Err.Raise vbObjectError + 5194, _
                  "CashAnalysisRecoveryFatal/SetCashAnalysisViewEditingEnabled", _
                  errorDescription
    Err.Raise errorNumber, "SetCashAnalysisViewEditingEnabled", errorDescription
End Sub

Private Sub SelectFirstVisibleCashAnalysisRow(ByVal ws As Worksheet)
    Dim lastR As Long
    Dim visibleCells As Range
    lastR = CashAnalysisLastDataRow(ws)
    If lastR < CASH_VIEW_FIRST_DATA_ROW Then Exit Sub
    On Error Resume Next
    Set visibleCells = ws.Range(ws.Cells(CASH_VIEW_FIRST_DATA_ROW, 1), _
                                ws.Cells(lastR, 1)).SpecialCells(xlCellTypeVisible)
    On Error GoTo 0
    If Not visibleCells Is Nothing Then _
        SafeSelectCell ws, visibleCells.Cells(1, 1).Address(False, False)
End Sub

Private Function CashAnalysisLastDataRow(ByVal ws As Worksheet) As Long
    Dim lastByTx As Long, lastByDate As Long, lastByTekiyo As Long
    If ws Is Nothing Then Exit Function
    lastByTx = LastRow(ws, OUT_COL_TRANSACTION_ID)
    lastByDate = LastRow(ws, OUT_COL_DATE)
    lastByTekiyo = LastRow(ws, OUT_COL_TEKIYO)
    CashAnalysisLastDataRow = Application.Max(lastByTx, lastByDate, lastByTekiyo)
    If CashAnalysisLastDataRow < CASH_VIEW_FIRST_DATA_ROW Then CashAnalysisLastDataRow = 0
End Function

Private Function CashViewCategoryForResult(ByVal resultCategory As String) As String
    Select Case Trim$(resultCategory)
        Case "使途不明": CashViewCategoryForResult = VIEW_CATEGORY_UNKNOWN_WITHDRAW
        Case "原資不明": CashViewCategoryForResult = VIEW_CATEGORY_UNKNOWN_DEPOSIT
        Case Else: CashViewCategoryForResult = VIEW_CATEGORY_TRANSFER
    End Select
End Function

Private Function IsCashViewCategory(ByVal categoryText As String) As Boolean
    IsCashViewCategory = (categoryText = VIEW_CATEGORY_TRANSFER Or _
                          categoryText = VIEW_CATEGORY_UNKNOWN_WITHDRAW Or _
                          categoryText = VIEW_CATEGORY_UNKNOWN_DEPOSIT)
End Function

Private Function IsCashViewMode(ByVal modeText As String) As Boolean
    IsCashViewMode = (modeText = VIEW_MODE_COMPONENT Or modeText = VIEW_MODE_RELATED Or _
                      modeText = VIEW_MODE_ALL)
End Function

Private Function ConfirmedStatusForCashCategory(ByVal categoryText As String) As String
    Select Case categoryText
        Case VIEW_CATEGORY_UNKNOWN_WITHDRAW
            ConfirmedStatusForCashCategory = ANALYSIS_STATUS_USE_CONFIRMED
        Case VIEW_CATEGORY_UNKNOWN_DEPOSIT
            ConfirmedStatusForCashCategory = ANALYSIS_STATUS_SOURCE_CONFIRMED
        Case Else
            ConfirmedStatusForCashCategory = ANALYSIS_STATUS_SHIFT_CONFIRMED
    End Select
End Function

Private Function IsStatusAllowedForCashCategory(ByVal categoryText As String, _
                                                ByVal statusText As String) As Boolean
    If statusText = ANALYSIS_STATUS_UNREVIEWED Or statusText = ANALYSIS_STATUS_EXCLUDED Or _
       statusText = ANALYSIS_STATUS_FOLLOWUP Then
        IsStatusAllowedForCashCategory = True
        Exit Function
    End If
    IsStatusAllowedForCashCategory = (statusText = ConfirmedStatusForCashCategory(categoryText))
End Function

Private Function CashViewRole(ByVal withdrawal As Double, ByVal deposit As Double) As String
    If withdrawal > 0 And deposit > 0 Then
        CashViewRole = VIEW_ROLE_BOTH
    ElseIf withdrawal > 0 Then
        CashViewRole = VIEW_ROLE_WITHDRAW
    ElseIf deposit > 0 Then
        CashViewRole = VIEW_ROLE_DEPOSIT
    End If
End Function

Private Function CashViewDouble(ByVal value As Variant) As Double
    If IsError(value) Or IsEmpty(value) Or Len(CellText(value)) = 0 Then Exit Function
    If IsNumeric(value) Then CashViewDouble = CDbl(value)
End Function

Private Function CashResultColumnValues(ByVal ws As Worksheet, ByVal firstRow As Long, _
                                        ByVal lastRow As Long, ByVal columnNumber As Long) As Variant
    Dim values As Variant
    If ws Is Nothing Or lastRow < firstRow Then Exit Function
    If lastRow = firstRow Then
        ReDim values(1 To 1, 1 To 1)
        values(1, 1) = ws.Cells(firstRow, columnNumber).Value2
    Else
        values = ws.Range(ws.Cells(firstRow, columnNumber), _
                          ws.Cells(lastRow, columnNumber)).Value2
    End If
    CashResultColumnValues = values
End Function

Private Function IDsToDictionary(ByVal idList As String) As Object
    Dim result As Object, parts As Variant, item As Variant, txID As String
    Set result = CreateObject("Scripting.Dictionary")
    result.CompareMode = vbTextCompare
    idList = Replace(Replace(idList, vbCrLf, ";"), vbLf, ";")
    idList = Replace(idList, ",", ";")
    If Len(Trim$(idList)) > 0 Then
        parts = Split(idList, ";")
        For Each item In parts
            txID = Trim$(CStr(item))
            If Len(txID) > 0 Then result(txID) = True
        Next item
    End If
    Set IDsToDictionary = result
End Function

Private Function JoinCashDictionaryKeys(ByVal values As Object) As String
    Dim item As Variant
    If values Is Nothing Then Exit Function
    For Each item In values.Keys
        If Len(JoinCashDictionaryKeys) > 0 Then JoinCashDictionaryKeys = JoinCashDictionaryKeys & ";"
        JoinCashDictionaryKeys = JoinCashDictionaryKeys & CStr(item)
    Next item
End Function

Private Function IDListContains(ByVal idList As String, ByVal wantedID As String) As Boolean
    Dim normalizedList As String, normalizedID As String
    normalizedID = Trim$(wantedID)
    If Len(normalizedID) = 0 Then Exit Function
    normalizedList = Replace(idList, vbCrLf, ";")
    normalizedList = Replace(normalizedList, vbCr, ";")
    normalizedList = Replace(normalizedList, vbLf, ";")
    normalizedList = Replace(normalizedList, ",", ";")
    normalizedList = Replace(normalizedList, " ", "")
    normalizedList = Replace(normalizedList, vbTab, "")
    normalizedID = Replace(normalizedID, " ", "")
    normalizedID = Replace(normalizedID, vbTab, "")
    normalizedList = ";" & normalizedList & ";"
    IDListContains = (InStr(1, normalizedList, ";" & normalizedID & ";", vbTextCompare) > 0)
End Function

﻿Attribute VB_Name = "modBalanceReconciliation"
Option Explicit

'通帳に記載された取引後残高を、直前の既知残高とその間の入出金から再計算する。
'同一口座・同日に時刻欠落が1件でもあれば、その日は日計純額だけを累積する。
'欠落日の取引後残高を行順や入力順へ結び付けず、後日の確定可能な残高まで繰り越す。

Private Const RECON_EPSILON As Double = 0.00000001
Private Const RECON_DAY_ONLY_RESULT As String = _
    "日計のみ / 同日内順序不明 / 取引後残高は未照合"
Private Const RECON_EXACT_ORDER_RESULT As String = "日付・実時刻順"
Private Const RECON_CARRIED_DAY_RESULT As String = _
    "日計のみを含む / 同日内順序不明 / 欠落日の取引後残高は未照合"
Private Const RECON_SAME_TIME_PREFIX As String = "同一時刻グループ"
Private Const RECON_SAME_TIME_UNVERIFIED_RESULT As String = _
    "同一時刻グループ / 同一時刻内順序不明 / 終端残高は未照合"
Private Const RECON_CARRIED_SAME_TIME_RESULT As String = _
    "同一時刻グループを含む / 同一時刻内順序不明 / 終端残高は未照合"
Private Const RECON_COVERAGE_PREFIX As String = "カバレッジ / "
Private Const RECON_UNCLOSED_TAIL_RESULT As String = _
    "未閉鎖末尾 / 最後の既知残高後に取引後残高または独立残高基準なし"
Private Const RECON_NO_BASELINE_RESULT As String = _
    "未検算期間 / 開始基準残高なし"
Private Const RECON_INDEPENDENT_ANCHOR_RESULT As String = _
    "独立残高基準との不一致 / W_残高は日末基準・時刻なし"
Private Const RECON_WORK_EQUIVALENT_COLUMNS As Long = 16
Private Const RECON_WORK_SNAPSHOT_COPIES As Long = 3
Private Const RECON_WORK_WRITE_CHUNK_ROWS As Long = 2000
Private Const RECON_RECOVERY_HARD_BARRIER_ERROR As Long = vbObjectError + 4499
Private Const RECON_RECOVERY_FATAL_PREFIX As String = _
    "BalanceReconciliationRecoveryFatal/"

Private Type ReconciliationOutputSnapshot
    Captured As Boolean
    HeaderData As Variant
    Data As Variant
    LastRow As Long
    Visibility As Long
    WasProtected As Boolean
    EntryActiveSheetName As String
    EntryActiveCellAddress As String
    SelectionAddress As String
    WindowStateCaptured As Boolean
    FreezePanes As Boolean
    SplitRow As Long
    SplitColumn As Long
    ScrollRow As Long
    ScrollColumn As Long
    Zoom As Long
    WorkbookWasSaved As Boolean
End Type

Private mOperationSnapshot As ReconciliationOutputSnapshot
Private mOperationSnapshotActive As Boolean

Public Function BalanceReconciliationHeaders() As Variant
    BalanceReconciliationHeaders = Array( _
        "口座", "前回既知残高日時", "今回残高日時", "対象取引数", _
        "前回残高", "入出金純額", "計算残高", "記載残高", "検算結果・順序精度")
End Function

'取引/独立残高/口座グループに加え、不一致・無基準・未閉鎖・coverageを
'同時に保持し得る最大シート行（ヘッダー込み）。実出力を数え始めてから
'容量不足に気付かないよう、各行が別口座である最悪ケースを採る。
Public Function EstimateBalanceReconciliationOutputRows( _
        ByVal accountRows As Double, ByVal transactionRows As Double, _
        ByVal balanceRows As Double) As Double
    Dim accountGroupUpper As Double, stagedDataUpper As Double
    RequireValidReconciliationCapacityCount accountRows, "口座"
    RequireValidReconciliationCapacityCount transactionRows, "取引"
    RequireValidReconciliationCapacityCount balanceRows, "独立残高"
    'W_口座、W_取引、W_残高の識別子が完全に重ならない破損入力でも過小評価しない。
    accountGroupUpper = accountRows + transactionRows + balanceRows
    '原明細/基準点、群診断、口座ごとの末尾又は無基準診断、coverageを全て含む。
    stagedDataUpper = 2# * (transactionRows + balanceRows) + _
                      2# * accountGroupUpper + 4#
    EstimateBalanceReconciliationOutputRows = 1# + stagedDataUpper
End Function

'BuildBalanceReconciliationCoreが同時保持する配列・索引・辞書・診断buffer、
'chunk書込/読戻し、旧出力snapshotの16列Variant行相当上界。
Public Function EstimateBalanceReconciliationWorkRows( _
        ByVal accountRows As Double, ByVal transactionRows As Double, _
        ByVal balanceRows As Double, ByVal existingOutputRows As Double) As Double
    Dim accountGroupUpper As Double, plannedOutputRows As Double
    Dim plannedDataRows As Double, writeChunkRows As Double, snapshotRows As Double
    RequireValidReconciliationCapacityCount accountRows, "口座"
    RequireValidReconciliationCapacityCount transactionRows, "取引"
    RequireValidReconciliationCapacityCount balanceRows, "独立残高"
    RequireValidReconciliationCapacityCount existingOutputRows, "既存検算表"
    accountGroupUpper = accountRows + transactionRows + balanceRows
    plannedOutputRows = EstimateBalanceReconciliationOutputRows( _
                            accountRows, transactionRows, balanceRows)
    plannedDataRows = plannedOutputRows - 1#
    writeChunkRows = plannedDataRows
    If writeChunkRows > CDbl(RECON_WORK_WRITE_CHUNK_ROWS) Then _
        writeChunkRows = CDbl(RECON_WORK_WRITE_CHUNK_ROWS)
    snapshotRows = existingOutputRows
    If snapshotRows < 1# Then snapshotRows = 1#

    EstimateBalanceReconciliationWorkRows = _
        ReconciliationArrayWorkRows(transactionRows, WORK_TX_COL_PERSON_ID) + _
        ReconciliationArrayWorkRows(balanceRows, WORK_BAL_COL_PERSON_ID) + _
        transactionRows + _
        transactionRows + _
        2# * balanceRows + _
        3# * accountGroupUpper + _
        ReconciliationArrayWorkRows(plannedDataRows, _
                                    BALANCE_RECONCILIATION_LAST_COL) + _
        2# * ReconciliationArrayWorkRows(writeChunkRows, _
                                         BALANCE_RECONCILIATION_LAST_COL) + _
        CDbl(RECON_WORK_SNAPSHOT_COPIES) * _
            ReconciliationArrayWorkRows(snapshotRows, _
                                        BALANCE_RECONCILIATION_LAST_COL)
End Function

Private Sub RequireValidReconciliationCapacityCount( _
        ByVal rowCount As Double, ByVal labelText As String)
    If rowCount < 0# Or rowCount <> Fix(rowCount) Then _
        Err.Raise vbObjectError + 5076, _
                  "EstimateBalanceReconciliationWorkRows", _
                  "残高検算の" & labelText & "行数が不正です。"
End Sub

Private Function ReconciliationArrayWorkRows( _
        ByVal rowCount As Double, ByVal columnCount As Long) As Double
    Dim widthUnits As Long
    If rowCount < 0# Or columnCount < 1 Then _
        Err.Raise vbObjectError + 5076, _
                  "ReconciliationArrayWorkRows", _
                  "残高検算の配列容量が不正です。"
    widthUnits = (columnCount + RECON_WORK_EQUIVALENT_COLUMNS - 1) \ _
                 RECON_WORK_EQUIVALENT_COLUMNS
    ReconciliationArrayWorkRows = rowCount * CDbl(widthUnits)
End Function

Public Sub SetupBalanceReconciliationSheet(Optional ByVal resetContents As Boolean = False)
    Dim ws As Worksheet
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim eventStateDetail As String
    On Error GoTo EH
    Set ws = GetOrCreateSheet(SH_BALANCE_RECONCILIATION, False)
    ws.Unprotect Password:=TOOL_PASSWORD
    If resetContents Then ResetWorksheet ws
    If Len(CellText(ws.Cells(1, 1).Value)) = 0 Then _
        SetRowValues ws.Range("A1"), BalanceReconciliationHeaders()
    FormatOutputHeader ws.Range(ws.Cells(1, 1), _
                                ws.Cells(1, BALANCE_RECONCILIATION_LAST_COL))
    ws.Columns("A:A").ColumnWidth = 42
    ws.Columns("B:C").ColumnWidth = 24
    ws.Columns("D:D").ColumnWidth = 12
    ws.Columns("E:H").ColumnWidth = 17
    ws.Columns("I:I").ColumnWidth = 40
    ws.Columns("B:C").NumberFormatLocal = "@"
    ws.Columns("D:D").NumberFormatLocal = "0"
    ws.Columns("E:H").NumberFormatLocal = "#,##0.########"
    ProtectSingleAnalysisSheet ws
    If LastUsedRowInSheet(ws) < 2 Then SetSheetVeryHiddenSafe ws
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    If IsReconciliationNestedRecoveryHardBarrier( _
           errorNumber, errorSource, errorDescription) Then
        Call TryKeepReconciliationEventsDisabledExact(eventStateDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    On Error Resume Next
    EmergencyProtectToolSheet ws
    If resetContents Then SetSheetVeryHiddenSafe ws
    On Error GoTo 0
    Err.Raise errorNumber, "SetupBalanceReconciliationSheet", errorDescription
End Sub

Private Sub CaptureReconciliationOutputSnapshot( _
        ByVal ws As Worksheet, ByRef snapshot As ReconciliationOutputSnapshot)
    Dim headerRange As Range, formulaCell As Range
    If ws Is Nothing Then _
        Err.Raise vbObjectError + 5054, "CaptureReconciliationOutputSnapshot", _
                  "残高検算の退避先がありません。"
    snapshot.Visibility = CLng(ws.Visible)
    snapshot.WasProtected = ws.ProtectContents
    snapshot.WorkbookWasSaved = ThisWorkbook.Saved
    Set headerRange = ws.Range(ws.Cells(1, 1), _
                               ws.Cells(1, BALANCE_RECONCILIATION_LAST_COL))
    If Not TryFindFirstFormulaCell(headerRange, formulaCell) Then _
        Err.Raise vbObjectError + 5055, "CaptureReconciliationOutputSnapshot", _
                  "残高検算の見出し数式検査に失敗しました。"
    If Not formulaCell Is Nothing Then _
        Err.Raise vbObjectError + 5055, "CaptureReconciliationOutputSnapshot", _
                  "残高検算の見出しに数式があります。"
    snapshot.HeaderData = headerRange.Value2
    If VariantMatrixContainsError( _
            snapshot.HeaderData, 1, BALANCE_RECONCILIATION_LAST_COL) Or _
       Not RangeValue2MatchesMatrixStrict( _
               headerRange, snapshot.HeaderData, 1, _
               BALANCE_RECONCILIATION_LAST_COL) Then _
        Err.Raise vbObjectError + 5056, "CaptureReconciliationOutputSnapshot", _
                  "残高検算の見出しを型まで厳密に退避できません。"
    CaptureAtomicConstantWorksheetData ws, BALANCE_RECONCILIATION_LAST_COL, _
        MAX_ANALYSIS_OUTPUT_ROWS, snapshot.Data, snapshot.LastRow, "残高検算"

    If Not ActiveSheet Is Nothing Then
        If TypeName(ActiveSheet) = "Worksheet" Then
            snapshot.EntryActiveSheetName = ActiveSheet.Name
            If Not ActiveCell Is Nothing Then _
                snapshot.EntryActiveCellAddress = ActiveCell.Address(False, False)
            If TypeName(Selection) = "Range" Then _
                snapshot.SelectionAddress = Selection.Address(False, False)
            If Not ActiveWindow Is Nothing Then
                snapshot.FreezePanes = ActiveWindow.FreezePanes
                snapshot.SplitRow = CLng(ActiveWindow.SplitRow)
                snapshot.SplitColumn = CLng(ActiveWindow.SplitColumn)
                snapshot.ScrollRow = ActiveWindow.ScrollRow
                snapshot.ScrollColumn = ActiveWindow.ScrollColumn
                snapshot.Zoom = CLng(ActiveWindow.Zoom)
                snapshot.WindowStateCaptured = True
            End If
        End If
    End If
    snapshot.Captured = True
End Sub

Private Sub RestoreReconciliationOutputSnapshot( _
        ByVal ws As Worksheet, ByRef snapshot As ReconciliationOutputSnapshot)
    Dim headerRange As Range
    Dim dataRows As Long
    If ws Is Nothing Or Not snapshot.Captured Then _
        Err.Raise vbObjectError + 5057, "RestoreReconciliationOutputSnapshot", _
                  "残高検算の退避情報がありません。"

    SetupBalanceReconciliationSheet True
    Set ws = GetSheet(SH_BALANCE_RECONCILIATION)
    ws.Unprotect Password:=TOOL_PASSWORD
    Set headerRange = ws.Range(ws.Cells(1, 1), _
                               ws.Cells(1, BALANCE_RECONCILIATION_LAST_COL))
    headerRange.Value2 = snapshot.HeaderData
    If Not RangeValue2MatchesMatrixStrict( _
               headerRange, snapshot.HeaderData, 1, _
               BALANCE_RECONCILIATION_LAST_COL) Then _
        Err.Raise vbObjectError + 5058, "RestoreReconciliationOutputSnapshot", _
                  "残高検算の見出しを厳密に復元できません。"
    RestoreAtomicConstantWorksheetData ws, BALANCE_RECONCILIATION_LAST_COL, _
        MAX_ANALYSIS_OUTPUT_ROWS, snapshot.Data, snapshot.LastRow, "残高検算"
    FinalizeBalanceReconciliation ws, snapshot.LastRow - 1

    If Not RangeValue2MatchesMatrixStrict( _
               headerRange, snapshot.HeaderData, 1, _
               BALANCE_RECONCILIATION_LAST_COL) Then _
        Err.Raise vbObjectError + 5059, "RestoreReconciliationOutputSnapshot", _
                  "残高検算の書式再構成後に見出し値が変化しました。"
    dataRows = snapshot.LastRow - 1
    If dataRows > 0 Then
        If Not RangeValue2MatchesMatrixStrict( _
                   ws.Range(ws.Cells(2, 1), _
                            ws.Cells(snapshot.LastRow, _
                                     BALANCE_RECONCILIATION_LAST_COL)), _
                   snapshot.Data, dataRows, _
                   BALANCE_RECONCILIATION_LAST_COL) Then _
            Err.Raise vbObjectError + 5060, "RestoreReconciliationOutputSnapshot", _
                      "残高検算の書式再構成後の値が退避値と一致しません。"
    End If
    If LastDataRowInColumns(ws, 1, BALANCE_RECONCILIATION_LAST_COL) <> _
       snapshot.LastRow Then _
        Err.Raise vbObjectError + 5061, "RestoreReconciliationOutputSnapshot", _
                  "残高検算の復元行数が一致しません。"

    RestoreReconciliationEntryView snapshot
    If snapshot.WasProtected Then
        ProtectSingleAnalysisSheet ws
    Else
        ws.Unprotect Password:=TOOL_PASSWORD
    End If
    ws.Visible = snapshot.Visibility
    If ws.ProtectContents <> snapshot.WasProtected Or _
       CLng(ws.Visible) <> snapshot.Visibility Then _
        Err.Raise vbObjectError + 5062, "RestoreReconciliationOutputSnapshot", _
                  "残高検算の保護または表示状態を復元できません。"
    If snapshot.WorkbookWasSaved Then ThisWorkbook.Saved = True
End Sub

Private Sub RestoreReconciliationEntryView( _
        ByRef snapshot As ReconciliationOutputSnapshot)
    Dim ws As Worksheet
    If Len(snapshot.EntryActiveSheetName) = 0 Then Exit Sub
    If Not SheetExists(snapshot.EntryActiveSheetName) Then _
        Err.Raise vbObjectError + 5063, "RestoreReconciliationEntryView", _
                  "操作開始時のシートが見つかりません。"
    Set ws = GetSheet(snapshot.EntryActiveSheetName)
    If ws.Visible <> xlSheetVisible Then ws.Visible = xlSheetVisible
    If ws.Visible <> xlSheetVisible Then _
        Err.Raise vbObjectError + 5064, "RestoreReconciliationEntryView", _
                  "操作開始時のシートが表示状態ではありません。"
    ws.Activate
    RestoreWorkbookViewPosition ws, snapshot.WindowStateCaptured, _
        snapshot.FreezePanes, snapshot.SplitRow, snapshot.SplitColumn, _
        snapshot.ScrollRow, snapshot.ScrollColumn, snapshot.Zoom, _
        snapshot.SelectionAddress, snapshot.EntryActiveCellAddress
    If Not ActiveWorkbook Is ThisWorkbook Or Not ActiveSheet Is ws Then _
        Err.Raise vbObjectError + 5068, "RestoreReconciliationEntryView", _
                  "操作開始時のアクティブシートを復元できません。"
End Sub

Private Function TryRollbackReconciliationCoreOutput( _
        ByVal ws As Worksheet, _
        ByRef snapshot As ReconciliationOutputSnapshot, _
        ByVal outputMutationStarted As Boolean, _
        ByRef detailText As String) As Boolean
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim eventStateDetail As String
    detailText = vbNullString
    On Error GoTo EH
    If Not snapshot.Captured Then
        TryRollbackReconciliationCoreOutput = True
        Exit Function
    End If
    If outputMutationStarted Then
        RestoreReconciliationOutputSnapshot ws, snapshot
    Else
        If snapshot.WasProtected Then
            ProtectSingleAnalysisSheet ws
        Else
            ws.Unprotect Password:=TOOL_PASSWORD
        End If
        ws.Visible = snapshot.Visibility
        If ws.ProtectContents <> snapshot.WasProtected Then _
            Err.Raise vbObjectError + 5071, _
                      "TryRollbackReconciliationCoreOutput", _
                      "残高検算の保護状態を復元できません。"
        If CLng(ws.Visible) <> snapshot.Visibility Then _
            Err.Raise vbObjectError + 5071, _
                      "TryRollbackReconciliationCoreOutput", _
                      "残高検算の表示状態を復元できません。"
        If snapshot.WorkbookWasSaved Then
            ThisWorkbook.Saved = True
            If Not ThisWorkbook.Saved Then _
                Err.Raise vbObjectError + 5071, _
                          "TryRollbackReconciliationCoreOutput", _
                          "ブック保存状態を復元できません。"
        End If
    End If
    TryRollbackReconciliationCoreOutput = True
    Exit Function
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    If IsReconciliationNestedRecoveryHardBarrier( _
           errorNumber, errorSource, errorDescription) Then
        Call TryKeepReconciliationEventsDisabledExact(eventStateDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    detailText = "残高検算の復元エラー: Err " & CStr(errorNumber) & _
                 " [" & errorSource & "] " & errorDescription
    Err.Clear
End Function

Private Sub AppendReconciliationRollbackDetail( _
        ByRef detailText As String, ByVal addedText As String)
    If Len(Trim$(addedText)) = 0 Then Exit Sub
    If Len(detailText) > 0 Then detailText = detailText & " / "
    detailText = detailText & addedText
End Sub

Private Function IsReconciliationNestedRecoveryHardBarrier( _
        ByVal errorNumber As Long, ByVal errorSource As String, _
        ByVal errorDescription As String) As Boolean
    Select Case errorNumber
        Case RECON_RECOVERY_HARD_BARRIER_ERROR, vbObjectError + 3599
            IsReconciliationNestedRecoveryHardBarrier = True
            Exit Function
        Case vbObjectError + 5191
            If Left$(errorSource, Len("AnalysisWorkspaceRecoveryFatal/")) = _
               "AnalysisWorkspaceRecoveryFatal/" Then GoTo Detected
        Case vbObjectError + 5192
            If Left$(errorSource, Len("SetupConvergeRecoveryFatal/")) = _
               "SetupConvergeRecoveryFatal/" Then GoTo Detected
        Case vbObjectError + 5194
            If Left$(errorSource, Len("CashAnalysisRecoveryFatal/")) = _
               "CashAnalysisRecoveryFatal/" Then GoTo Detected
        Case vbObjectError + 5195
            If Left$(errorSource, Len("TransactionAnalysisRecoveryFatal/")) = _
               "TransactionAnalysisRecoveryFatal/" Then GoTo Detected
        Case vbObjectError + 5196
            If Left$(errorSource, Len("CashManualSelectionRecoveryFatal/")) = _
               "CashManualSelectionRecoveryFatal/" Then GoTo Detected
        Case vbObjectError + 5197
            If Left$(errorSource, Len("ClearRecoveryFatal/")) = _
               "ClearRecoveryFatal/" Then GoTo Detected
    End Select
    Exit Function
Detected:
    IsReconciliationNestedRecoveryHardBarrier = True
End Function

Private Function TryKeepReconciliationEventsDisabledExact( _
        ByRef detailText As String) As Boolean
    Dim actualValue As Boolean
    Dim setterErrorNumber As Long, setterErrorDescription As String
    Dim readErrorNumber As Long, readErrorDescription As String
    detailText = vbNullString
    On Error Resume Next
    Err.Clear
    Application.EnableEvents = False
    setterErrorNumber = Err.Number
    setterErrorDescription = Err.Description
    Err.Clear
    actualValue = Application.EnableEvents
    readErrorNumber = Err.Number
    readErrorDescription = Err.Description
    Err.Clear
    On Error GoTo 0
    If setterErrorNumber = 0 And readErrorNumber = 0 Then
        If Not actualValue Then
            TryKeepReconciliationEventsDisabledExact = True
            Exit Function
        End If
    End If
    If setterErrorNumber <> 0 Then _
        AppendReconciliationRollbackDetail detailText, _
            "setter Err " & CStr(setterErrorNumber) & " " & _
            setterErrorDescription
    If readErrorNumber <> 0 Then
        AppendReconciliationRollbackDetail detailText, _
            "readback Err " & CStr(readErrorNumber) & " " & _
            readErrorDescription
    ElseIf actualValue Then
        AppendReconciliationRollbackDetail detailText, _
            "EnableEventsのreadbackがTrueです。"
    End If
End Function

Private Function TryConfirmReconciliationRecoveryStateExact( _
        ByRef detailText As String) As Boolean
    Dim latchIsSet As Boolean, healthValue As String
    detailText = vbNullString
    On Error GoTo EH
    If Not TryGetRollbackRecoveryLatch(latchIsSet) Then
        AppendReconciliationRollbackDetail detailText, _
            "独立Recoveryラッチを読み戻せません。"
        Exit Function
    End If
    If Not latchIsSet Then
        AppendReconciliationRollbackDetail detailText, _
            "独立Recoveryラッチが設定されていません。"
        Exit Function
    End If
    If Not TryGetExactStateValue(STATE_DATA_HEALTH, healthValue) Then
        AppendReconciliationRollbackDetail detailText, _
            "案件healthを読み戻せません。"
        Exit Function
    End If
    If StrComp(healthValue, DATA_HEALTH_NEEDS_RECOVERY, _
               vbBinaryCompare) <> 0 Then
        AppendReconciliationRollbackDetail detailText, _
            "案件healthがRecoveryではありません。"
        Exit Function
    End If
    TryConfirmReconciliationRecoveryStateExact = True
    Exit Function
EH:
    detailText = "Recovery二重状態の読戻しエラー: Err " & _
                 CStr(Err.Number) & " " & Err.Description
    Err.Clear
End Function

Private Function TryGetReconciliationApplicationStateSafe( _
        ByRef detailText As String) As Boolean
    Dim stateProblems As String
    detailText = vbNullString
    On Error GoTo EH
    TryGetReconciliationApplicationStateSafe = _
        AppStateIsRestored(stateProblems)
    If Not TryGetReconciliationApplicationStateSafe Then _
        detailText = "Application状態の完全復元を確認できません。 " & _
                     stateProblems
    Exit Function
EH:
    detailText = "Application状態の読戻しエラー: Err " & _
                 CStr(Err.Number) & " " & Err.Description
    Err.Clear
End Function

Public Sub CaptureBalanceReconciliationOperationSnapshot( _
        ByRef snapshotCaptured As Boolean)
    snapshotCaptured = False
    If mOperationSnapshotActive Then _
        Err.Raise vbObjectError + 5069, _
                  "CaptureBalanceReconciliationOperationSnapshot", _
                  "残高検算の操作単位退避が既に開始されています。"
    ClearBalanceReconciliationOperationSnapshot
    CaptureReconciliationOutputSnapshot _
        GetSheet(SH_BALANCE_RECONCILIATION), mOperationSnapshot
    mOperationSnapshotActive = True
    snapshotCaptured = True
End Sub

Public Sub RestoreBalanceReconciliationOperationSnapshot( _
        ByRef snapshotCaptured As Boolean)
    If Not snapshotCaptured Or Not mOperationSnapshotActive Then _
        Err.Raise vbObjectError + 5070, _
                  "RestoreBalanceReconciliationOperationSnapshot", _
                  "残高検算の操作単位退避情報がありません。"
    RestoreReconciliationOutputSnapshot _
        GetSheet(SH_BALANCE_RECONCILIATION), mOperationSnapshot
    ClearBalanceReconciliationOperationSnapshot
    snapshotCaptured = False
End Sub

Public Sub ReleaseBalanceReconciliationOperationSnapshot( _
        ByRef snapshotCaptured As Boolean)
    ClearBalanceReconciliationOperationSnapshot
    snapshotCaptured = False
End Sub

Private Sub ClearBalanceReconciliationOperationSnapshot()
    With mOperationSnapshot
        .Captured = False
        .HeaderData = Empty
        .Data = Empty
        .LastRow = 0
        .Visibility = 0
        .WasProtected = False
        .EntryActiveSheetName = vbNullString
        .EntryActiveCellAddress = vbNullString
        .SelectionAddress = vbNullString
        .WindowStateCaptured = False
        .FreezePanes = False
        .SplitRow = 0
        .SplitColumn = 0
        .ScrollRow = 0
        .ScrollColumn = 0
        .Zoom = 0
        .WorkbookWasSaved = False
    End With
    mOperationSnapshotActive = False
End Sub

Public Sub BuildBalanceReconciliationCore(Optional ByVal activateAfter As Boolean = False, _
                                          Optional ByVal capacityConfirmed As Boolean = False)
    Dim wsTx As Worksheet, wsBal As Worksheet, wsOut As Worksheet
    Dim data As Variant, balanceData As Variant
    Dim lastR As Long, balanceLastR As Long, sourceCount As Long, balanceCount As Long
    Dim sourceRange As Range, invalidCell As Range
    Dim rows() As Long, rowCount As Long, r As Long, sourceRow As Long
    Dim groupFirst As Long, groupLast As Long, groupIndex As Long
    Dim stampFirst As Long, stampLast As Long, timestampCount As Long
    Dim dayHasMissing As Object, dayKey As String
    Dim transactionAccounts As Object, balanceRowsByAccount As Object
    Dim balanceAccountText As Object, processedAccounts As Object
    Dim currentBalanceRows() As Long, currentBalanceCount As Long, balancePosition As Long
    Dim balanceItem As Variant, currentDaySerial As Long
    Dim currentAccount As String, previousAccount As String
    Dim baselineSet As Boolean, baselineBalance As Double, runningDelta As Double
    Dim runningCompensation As Double, stableDelta As Double
    Dim dayDelta As Double, groupHasMissingTime As Boolean
    Dim timestampDelta As Double, matchingBalanceRow As Long
    Dim actualBalance As Double, expectedBalance As Double, difference As Double
    Dim tolerance As Double
    Dim intervalCount As Long, intervalHasDayOnly As Boolean
    Dim intervalHasSameTimeUnknown As Boolean
    Dim accountTransactionCount As Long, accountCheckedCount As Long
    Dim accountDayOnlyCount As Long, accountSameTimeCount As Long
    Dim unanchoredCount As Long
    Dim accountText As String, firstAccountStamp As String, lastAccountStamp As String
    Dim previousStamp As String, currentStamp As String, orderText As String
    Dim stagedRows() As Variant, outputCount As Long
    Dim stagedCapacity As Double
    Dim outputMutationStarted As Boolean
    Dim originalVisibility As XlSheetVisibility
    Dim outputSnapshot As ReconciliationOutputSnapshot
    Dim rollbackOK As Boolean
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim rollbackDetail As String
    Dim recoveryErrorNumber As Long, recoveryErrorDescription As String
    Dim recoveryStateConfirmed As Boolean, applicationStateSafe As Boolean
    Dim eventsStopped As Boolean
    Dim eventStateDetail As String, confirmationDetail As String
    Dim applicationStateDetail As String, fatalDescription As String
    On Error GoTo EH
    If Not capacityConfirmed Then
        If Not RequireOutputBuildCapacity("残高検算の作成", False, False, True, _
                                          False, False, False) Then Err.Raise 18
    End If
    Set wsTx = GetSheet(SH_WORK_TX)
    Set wsBal = GetSheet(SH_WORK_BAL)
    Set wsOut = GetSheet(SH_BALANCE_RECONCILIATION)
    originalVisibility = wsOut.Visible
    CaptureReconciliationOutputSnapshot wsOut, outputSnapshot
    lastR = LastUsedRowInSheet(wsTx)
    Set dayHasMissing = CreateObject("Scripting.Dictionary")
    dayHasMissing.CompareMode = vbTextCompare
    Set transactionAccounts = CreateObject("Scripting.Dictionary")
    Set balanceRowsByAccount = CreateObject("Scripting.Dictionary")
    Set balanceAccountText = CreateObject("Scripting.Dictionary")
    Set processedAccounts = CreateObject("Scripting.Dictionary")
    transactionAccounts.CompareMode = vbBinaryCompare
    balanceRowsByAccount.CompareMode = vbBinaryCompare
    balanceAccountText.CompareMode = vbBinaryCompare
    processedAccounts.CompareMode = vbBinaryCompare
    If lastR >= 2 Then
        Set sourceRange = wsTx.Range(wsTx.Cells(2, 1), _
                                     wsTx.Cells(lastR, WORK_TX_COL_PERSON_ID))
        If Not TryFindFirstFormulaCell(sourceRange, invalidCell) Then _
            Err.Raise vbObjectError + 5050, "BuildBalanceReconciliationCore", _
                      "W_取引の数式有無を検査できません。"
        If Not invalidCell Is Nothing Then _
            Err.Raise vbObjectError + 5051, "BuildBalanceReconciliationCore", _
                      "W_取引に数式があります: " & invalidCell.Address(False, False)
        Set invalidCell = Nothing
        If Not TryFindFirstErrorConstantCell(sourceRange, invalidCell) Then _
            Err.Raise vbObjectError + 5052, "BuildBalanceReconciliationCore", _
                      "W_取引のExcelエラー値有無を検査できません。"
        If Not invalidCell Is Nothing Then _
            Err.Raise vbObjectError + 5053, "BuildBalanceReconciliationCore", _
                      "W_取引にExcelエラー値があります: " & invalidCell.Address(False, False)
        data = sourceRange.Value2
        sourceCount = UBound(data, 1)
        ReDim rows(1 To sourceCount)
        For r = 1 To sourceCount
            If CellText(data(r, WORK_TX_COL_RECORD_TYPE)) = RECORD_TRANSACTION Then
                ValidateReconciliationSourceRow data, r
                rowCount = rowCount + 1
                rows(rowCount) = r
                transactionAccounts(CellText(data(r, WORK_TX_COL_ACCOUNT_ID))) = True
                dayKey = ReconciliationDayKey(data, r)
                If Not HasText(data(r, OUT_COL_TIME)) Then dayHasMissing(dayKey) = True
            End If
        Next r
    End If

    balanceLastR = LastUsedRowInSheet(wsBal)
    If balanceLastR >= 2 Then
        LoadReconciliationBalanceIndex wsBal, balanceLastR, balanceData, _
                                       balanceRowsByAccount, balanceAccountText, balanceCount
    End If

    stagedCapacity = CDbl(rowCount) + CDbl(balanceCount) + _
                     2# * CDbl(transactionAccounts.Count + balanceRowsByAccount.Count) + 4#
    If stagedCapacity > CDbl(MAX_ANALYSIS_OUTPUT_ROWS) Then _
        Err.Raise vbObjectError + 5072, "BuildBalanceReconciliationCore", _
                  "残高検算の明細・基準点・カバレッジ上界が実用上限を超えます。"
    If stagedCapacity > 0# Then _
        ReDim stagedRows(1 To CLng(stagedCapacity), _
                         1 To BALANCE_RECONCILIATION_LAST_COL)

    '原本検証と不一致行の計算が完了するまで、前回の正常な検算表には触れない。
    If rowCount > 0 Then
        'rowsはsourceCount上界で既に確保済み。ここでPreserve縮小すると容量確認後に
        '旧配列+新配列を一時二重保持するため、rowCountだけを有効範囲として使う。
        If rowCount > 1 Then QuickSortReconciliationRows data, rows, 1, rowCount, dayHasMissing
        r = 1
        Do While r <= rowCount
            groupFirst = r
            sourceRow = rows(groupFirst)
            currentAccount = CellText(data(sourceRow, WORK_TX_COL_ACCOUNT_ID))
            dayKey = ReconciliationDayKey(data, sourceRow)
            groupLast = groupFirst
            Do While groupLast < rowCount
                If StrComp(CellText(data(rows(groupLast + 1), WORK_TX_COL_ACCOUNT_ID)), _
                           currentAccount, vbBinaryCompare) <> 0 Then Exit Do
                If StrComp(ReconciliationDayKey(data, rows(groupLast + 1)), _
                           dayKey, vbBinaryCompare) <> 0 Then Exit Do
                groupLast = groupLast + 1
            Loop
            If StrComp(currentAccount, previousAccount, vbBinaryCompare) <> 0 Then
                If Len(previousAccount) > 0 Then
                    ProcessRemainingReconciliationBalances balanceData, currentBalanceRows, _
                        currentBalanceCount, balancePosition, accountText, baselineSet, _
                        baselineBalance, runningDelta, runningCompensation, intervalCount, _
                        previousStamp, accountCheckedCount, unanchoredCount, _
                        stagedRows, outputCount
                    FinalizeReconciliationAccountCoverage accountText, previousStamp, _
                        lastAccountStamp, baselineSet, baselineBalance, runningDelta, _
                        runningCompensation, intervalCount, unanchoredCount, _
                        accountTransactionCount, accountCheckedCount, accountDayOnlyCount, _
                        accountSameTimeCount, firstAccountStamp, stagedRows, outputCount
                End If
                previousAccount = currentAccount
                baselineSet = False: runningDelta = 0: runningCompensation = 0
                intervalCount = 0
                intervalHasDayOnly = False
                intervalHasSameTimeUnknown = False
                previousStamp = vbNullString
                accountTransactionCount = 0: accountCheckedCount = 0
                accountDayOnlyCount = 0: accountSameTimeCount = 0
                unanchoredCount = 0
                firstAccountStamp = vbNullString: lastAccountStamp = vbNullString
                accountText = ReconciliationAccountText(data, sourceRow)
                PrepareReconciliationBalanceRows balanceRowsByAccount, balanceData, _
                    currentAccount, currentBalanceRows, currentBalanceCount
                balancePosition = 1
                processedAccounts(currentAccount) = True
            End If
            currentDaySerial = CLng(VBA.DateValue(CDate(data(sourceRow, OUT_COL_DATE))))
            ProcessReconciliationBalancesBeforeDate balanceData, currentBalanceRows, _
                currentBalanceCount, balancePosition, currentDaySerial, accountText, _
                baselineSet, baselineBalance, runningDelta, runningCompensation, _
                intervalCount, previousStamp, accountCheckedCount, unanchoredCount, _
                stagedRows, outputCount
            If intervalCount = 0 Then
                intervalHasDayOnly = False
                intervalHasSameTimeUnknown = False
            End If
            accountTransactionCount = accountTransactionCount + groupLast - groupFirst + 1
            If Len(firstAccountStamp) = 0 Then _
                firstAccountStamp = Format$(CDate(data(sourceRow, OUT_COL_DATE)), "yyyy/m/d")
            lastAccountStamp = Format$(CDate(data(sourceRow, OUT_COL_DATE)), "yyyy/m/d")
            groupHasMissingTime = ReconciliationDayRequiresDailyNet( _
                                      dayHasMissing, dayKey)
            If groupHasMissingTime Then
                accountDayOnlyCount = accountDayOnlyCount + groupLast - groupFirst + 1
                dayDelta = ReconciliationDayNet(data, rows, groupFirst, groupLast)
                If baselineSet Then
                    AddReconciliationDelta runningDelta, runningCompensation, dayDelta
                    intervalCount = intervalCount + groupLast - groupFirst + 1
                    intervalHasDayOnly = True
                Else
                    unanchoredCount = unanchoredCount + groupLast - groupFirst + 1
                End If
                outputCount = outputCount + 1
                RequireReconciliationOutputSlot outputCount
                FillReconciliationDayOnlyBuffer stagedRows, outputCount, data, _
                                                rows(groupFirst), _
                                                groupLast - groupFirst + 1, dayDelta
            Else
                groupIndex = groupFirst
                Do While groupIndex <= groupLast
                    stampFirst = groupIndex
                    stampLast = stampFirst
                    Do While stampLast < groupLast
                        If Abs(ReconciliationTimeNumber( _
                                   data(rows(stampLast + 1), OUT_COL_TIME)) - _
                               ReconciliationTimeNumber( _
                                   data(rows(stampFirst), OUT_COL_TIME))) > _
                           RECON_EPSILON Then Exit Do
                        stampLast = stampLast + 1
                    Loop
                    timestampCount = stampLast - stampFirst + 1
                    If timestampCount > 1 Then _
                        accountSameTimeCount = accountSameTimeCount + timestampCount
                    sourceRow = rows(stampFirst)
                    currentStamp = ReconciliationDateTimeText(data, sourceRow)
                    If timestampCount = 1 Then
                        If baselineSet Then
                            AddReconciliationDelta runningDelta, runningCompensation, _
                                                   ReconciliationDelta(data, sourceRow)
                            intervalCount = intervalCount + 1
                        Else
                            unanchoredCount = unanchoredCount + 1
                        End If
                        If ReconciliationMayUseTransactionBalance( _
                               False, data(sourceRow, OUT_COL_OTHER)) Then
                            If Not IsNumeric(data(sourceRow, OUT_COL_OTHER)) Then _
                                Err.Raise vbObjectError + 5042, "BuildBalanceReconciliationCore", _
                                          "W_取引 " & CStr(sourceRow + 1) & _
                                          "行目の取引後残高が不正です。"
                            actualBalance = CDbl(data(sourceRow, OUT_COL_OTHER))
                            If baselineSet Then
                                stableDelta = runningDelta + runningCompensation
                                expectedBalance = ReconciliationExpectedBalance( _
                                                      baselineBalance, stableDelta)
                                difference = actualBalance - expectedBalance
                                tolerance = ReconciliationTolerance( _
                                                baselineBalance, stableDelta, actualBalance)
                                If Abs(difference) > tolerance Then
                                    outputCount = outputCount + 1
                                    RequireReconciliationOutputSlot outputCount
                                    If intervalHasDayOnly Then
                                        orderText = RECON_CARRIED_DAY_RESULT
                                    ElseIf intervalHasSameTimeUnknown Then
                                        orderText = RECON_CARRIED_SAME_TIME_RESULT
                                    Else
                                        orderText = RECON_EXACT_ORDER_RESULT
                                    End If
                                    FillReconciliationBuffer stagedRows, outputCount, _
                                        data, sourceRow, previousStamp, currentStamp, _
                                        intervalCount, baselineBalance, stableDelta, _
                                        expectedBalance, actualBalance, difference, orderText
                                End If
                                accountCheckedCount = accountCheckedCount + intervalCount
                            ElseIf unanchoredCount > 0 Then
                                '終点残高だけでは開始残高がなく、区間純額を検算できない。
                                outputCount = outputCount + 1
                                RequireReconciliationOutputSlot outputCount
                                FillReconciliationNoBaselineBuffer stagedRows, outputCount, _
                                    accountText, vbNullString, currentStamp, unanchoredCount
                                unanchoredCount = 0
                            End If
                            baselineSet = True
                            baselineBalance = actualBalance
                            previousStamp = currentStamp
                            runningDelta = 0: runningCompensation = 0: intervalCount = 0
                            intervalHasDayOnly = False
                            intervalHasSameTimeUnknown = False
                        End If
                    Else
                        timestampDelta = ReconciliationDayNet( _
                                             data, rows, stampFirst, stampLast)
                        currentStamp = currentStamp & "（同一時刻" & _
                                       CStr(timestampCount) & "件）"
                        If baselineSet Then
                            AddReconciliationDelta runningDelta, runningCompensation, _
                                                   timestampDelta
                            intervalCount = intervalCount + timestampCount
                            stableDelta = runningDelta + runningCompensation
                            expectedBalance = ReconciliationExpectedBalance( _
                                                  baselineBalance, stableDelta)
                            matchingBalanceRow = ReconciliationMatchingTimestampBalanceRow( _
                                data, rows, stampFirst, stampLast, baselineBalance, _
                                stableDelta, expectedBalance)
                            If matchingBalanceRow > 0 Then
                                actualBalance = CDbl(data(matchingBalanceRow, OUT_COL_OTHER))
                                accountCheckedCount = accountCheckedCount + intervalCount
                                baselineBalance = actualBalance
                                previousStamp = currentStamp & _
                                                "（終端残高一致・同日内順序不明）"
                                runningDelta = 0: runningCompensation = 0: intervalCount = 0
                                intervalHasDayOnly = False
                                intervalHasSameTimeUnknown = False
                            Else
                                outputCount = outputCount + 1
                                RequireReconciliationOutputSlot outputCount
                                FillReconciliationSameTimeBuffer stagedRows, outputCount, _
                                    data, sourceRow, previousStamp, currentStamp, intervalCount, _
                                    True, baselineBalance, stableDelta, expectedBalance
                                intervalHasSameTimeUnknown = True
                            End If
                        Else
                            unanchoredCount = unanchoredCount + timestampCount
                            outputCount = outputCount + 1
                            RequireReconciliationOutputSlot outputCount
                            FillReconciliationSameTimeBuffer stagedRows, outputCount, _
                                data, sourceRow, vbNullString, currentStamp, timestampCount, _
                                False, 0#, timestampDelta, 0#
                        End If
                    End If
                    groupIndex = stampLast + 1
                Loop
            End If
            ProcessReconciliationBalanceOnDate balanceData, currentBalanceRows, _
                currentBalanceCount, balancePosition, currentDaySerial, accountText, _
                baselineSet, baselineBalance, runningDelta, runningCompensation, _
                intervalCount, previousStamp, accountCheckedCount, unanchoredCount, _
                stagedRows, outputCount
            If intervalCount = 0 Then
                intervalHasDayOnly = False
                intervalHasSameTimeUnknown = False
            End If
            r = groupLast + 1
        Loop
        If Len(previousAccount) > 0 Then
            ProcessRemainingReconciliationBalances balanceData, currentBalanceRows, _
                currentBalanceCount, balancePosition, accountText, baselineSet, _
                baselineBalance, runningDelta, runningCompensation, intervalCount, _
                previousStamp, accountCheckedCount, unanchoredCount, _
                stagedRows, outputCount
            FinalizeReconciliationAccountCoverage accountText, previousStamp, _
                lastAccountStamp, baselineSet, baselineBalance, runningDelta, _
                runningCompensation, intervalCount, unanchoredCount, _
                accountTransactionCount, accountCheckedCount, accountDayOnlyCount, _
                accountSameTimeCount, firstAccountStamp, stagedRows, outputCount
        End If
    End If

    '取引がなく独立残高基準だけがある口座も、検算対象外として黙って消さない。
    For Each balanceItem In balanceRowsByAccount.Keys
        currentAccount = CStr(balanceItem)
        If Not processedAccounts.Exists(currentAccount) Then
            accountText = CStr(balanceAccountText(currentAccount))
            PrepareReconciliationBalanceRows balanceRowsByAccount, balanceData, _
                currentAccount, currentBalanceRows, currentBalanceCount
            balancePosition = 1
            baselineSet = False: baselineBalance = 0#
            runningDelta = 0#: runningCompensation = 0#: intervalCount = 0
            previousStamp = vbNullString: accountCheckedCount = 0: unanchoredCount = 0
            ProcessRemainingReconciliationBalances balanceData, currentBalanceRows, _
                currentBalanceCount, balancePosition, accountText, baselineSet, _
                baselineBalance, runningDelta, runningCompensation, intervalCount, _
                previousStamp, accountCheckedCount, unanchoredCount, _
                stagedRows, outputCount
            FinalizeReconciliationAccountCoverage accountText, previousStamp, _
                previousStamp, baselineSet, baselineBalance, runningDelta, _
                runningCompensation, intervalCount, unanchoredCount, 0, 0, 0, 0, _
                vbNullString, stagedRows, outputCount
        End If
    Next balanceItem

    outputMutationStarted = True
    SetupBalanceReconciliationSheet True
    Set wsOut = GetSheet(SH_BALANCE_RECONCILIATION)
    wsOut.Unprotect Password:=TOOL_PASSWORD
    If outputCount > 0 Then
        '識別文字列と日時表示列は、値より先に文字列書式を確定する。
        wsOut.Range(wsOut.Cells(2, 1), wsOut.Cells(outputCount + 1, 3)).NumberFormatLocal = "@"
        wsOut.Range(wsOut.Cells(2, 9), wsOut.Cells(outputCount + 1, 9)).NumberFormatLocal = "@"
        WriteReconciliationStagedRows wsOut, stagedRows, outputCount
    End If
    FinalizeBalanceReconciliation wsOut, outputCount
    If outputCount > 0 Then
        wsOut.Visible = xlSheetVisible
        If activateAfter Then wsOut.Activate
    Else
        SetSheetVeryHiddenSafe wsOut
    End If
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    If IsReconciliationNestedRecoveryHardBarrier( _
           errorNumber, errorSource, errorDescription) Then
        Call TryKeepReconciliationEventsDisabledExact(eventStateDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    rollbackOK = TryRollbackReconciliationCoreOutput( _
                     wsOut, outputSnapshot, outputMutationStarted, _
                     rollbackDetail)

    If Not rollbackOK Then
        'このCoreがRecovery ownerとなるのは局所snapshot復元失敗時だけ。
        'attemptの成否を問わずterminal markerで外側へ返し、再Enforceを禁止する。
        If Not TryKeepReconciliationEventsDisabledExact(eventStateDetail) Then
            AppendReconciliationRollbackDetail rollbackDetail, _
                "Recovery開始前のEnableEvents=Falseを確認できません: " & _
                eventStateDetail
            GoTo RECOVERY_FATAL
        End If

        On Error Resume Next
        Err.Clear
        EnforceRollbackRecoveryState rollbackDetail
        recoveryErrorNumber = Err.Number
        recoveryErrorDescription = Err.Description
        Err.Clear
        On Error GoTo 0

        'EnforceのErrを保存した直後は、分岐より先にfresh Falseだけを実行する。
        eventsStopped = _
            TryKeepReconciliationEventsDisabledExact(eventStateDetail)
        If recoveryErrorNumber <> 0 Then
            AppendReconciliationRollbackDetail rollbackDetail, _
                "要復旧状態の記録エラー: Err " & _
                CStr(recoveryErrorNumber) & " " & recoveryErrorDescription
            If Not eventsStopped Then _
                AppendReconciliationRollbackDetail rollbackDetail, _
                    "Enforce例外後のFalse収束も確認できません: " & _
                    eventStateDetail
            GoTo RECOVERY_FATAL
        End If
        If Not eventsStopped Then
            AppendReconciliationRollbackDetail rollbackDetail, _
                "Enforce直後のEnableEvents=Falseを確認できません: " & _
                eventStateDetail
            GoTo RECOVERY_FATAL
        End If

        recoveryStateConfirmed = _
            TryConfirmReconciliationRecoveryStateExact(confirmationDetail)
        If Not recoveryStateConfirmed Then
            AppendReconciliationRollbackDetail rollbackDetail, confirmationDetail
            If Not TryKeepReconciliationEventsDisabledExact(eventStateDetail) Then _
                AppendReconciliationRollbackDetail rollbackDetail, _
                    "Recovery二重状態未確認後のFalse収束にも失敗しました: " & _
                    eventStateDetail
            GoTo RECOVERY_FATAL
        End If
        applicationStateSafe = _
            TryGetReconciliationApplicationStateSafe(applicationStateDetail)
        If Not applicationStateSafe Then
            AppendReconciliationRollbackDetail rollbackDetail, applicationStateDetail
            If Not TryKeepReconciliationEventsDisabledExact(eventStateDetail) Then _
                AppendReconciliationRollbackDetail rollbackDetail, _
                    "Application状態未確認後のFalse収束にも失敗しました: " & _
                    eventStateDetail
            GoTo RECOVERY_FATAL
        End If
        If Not TryKeepReconciliationEventsDisabledExact(eventStateDetail) Then
            AppendReconciliationRollbackDetail rollbackDetail, _
                "Recovery確認後の最終EnableEvents=Falseを確認できません: " & _
                eventStateDetail
            GoTo RECOVERY_FATAL
        End If
        AppendReconciliationRollbackDetail rollbackDetail, _
            "独立ラッチ、案件health、Application状態を確認しRecoveryへ停止しました。"
        GoTo RECOVERY_FATAL
    End If
    If Len(rollbackDetail) > 0 Then _
        errorDescription = errorDescription & " / 復元確認: " & rollbackDetail
    Err.Raise errorNumber, "BuildBalanceReconciliationCore", errorDescription

RECOVERY_FATAL:
    'terminal後はFalse exactと文字列生成だけを許可する。
    If Not TryKeepReconciliationEventsDisabledExact(eventStateDetail) Then _
        AppendReconciliationRollbackDetail rollbackDetail, _
            "Recovery terminal後のFalse収束を確認できません: " & _
            eventStateDetail
    fatalDescription = "元エラー Err " & CStr(errorNumber) & ": " & _
                       errorDescription
    If Len(errorSource) > 0 Then _
        fatalDescription = fatalDescription & " / 元Source=" & errorSource
    If Len(rollbackDetail) > 0 Then _
        fatalDescription = fatalDescription & " / 復元確認: " & rollbackDetail
    On Error GoTo 0
    Err.Raise RECON_RECOVERY_HARD_BARRIER_ERROR, _
              RECON_RECOVERY_FATAL_PREFIX & _
                  "BuildBalanceReconciliationCore", _
              fatalDescription
End Sub

Private Sub LoadReconciliationBalanceIndex( _
        ByVal ws As Worksheet, ByVal lastR As Long, ByRef balanceData As Variant, _
        ByVal rowsByAccount As Object, ByVal accountTextByID As Object, _
        ByRef balanceCount As Long)
    Dim sourceRange As Range, invalidCell As Range
    Dim r As Long, accountID As String, accountText As String
    Dim accountRows As Collection
    Set sourceRange = ws.Range(ws.Cells(2, 1), _
                               ws.Cells(lastR, WORK_BAL_COL_PERSON_ID))
    If Not TryFindFirstFormulaCell(sourceRange, invalidCell) Then _
        Err.Raise vbObjectError + 5073, "LoadReconciliationBalanceIndex", _
                  "W_残高の数式有無を検査できません。"
    If Not invalidCell Is Nothing Then _
        Err.Raise vbObjectError + 5073, "LoadReconciliationBalanceIndex", _
                  "W_残高に数式があります: " & invalidCell.Address(False, False)
    Set invalidCell = Nothing
    If Not TryFindFirstErrorConstantCell(sourceRange, invalidCell) Then _
        Err.Raise vbObjectError + 5074, "LoadReconciliationBalanceIndex", _
                  "W_残高のExcelエラー値有無を検査できません。"
    If Not invalidCell Is Nothing Then _
        Err.Raise vbObjectError + 5074, "LoadReconciliationBalanceIndex", _
                  "W_残高にExcelエラー値があります: " & invalidCell.Address(False, False)
    balanceData = sourceRange.Value2
    For r = 1 To UBound(balanceData, 1)
        ValidateReconciliationBalanceRow balanceData, r
        accountID = CellText(balanceData(r, WORK_BAL_COL_ACCOUNT_ID))
        accountText = ReconciliationBalanceAccountText(balanceData, r)
        If rowsByAccount.Exists(accountID) Then
            Set accountRows = rowsByAccount(accountID)
            If StrComp(CStr(accountTextByID(accountID)), accountText, _
                       vbBinaryCompare) <> 0 Then _
                Err.Raise vbObjectError + 5075, "LoadReconciliationBalanceIndex", _
                          "W_残高の同一口座表示が一致しません: " & accountID
        Else
            Set accountRows = New Collection
            rowsByAccount.Add accountID, accountRows
            accountTextByID.Add accountID, accountText
        End If
        accountRows.Add r
        balanceCount = balanceCount + 1
    Next r
End Sub

Private Sub ValidateReconciliationBalanceRow( _
        ByRef balanceData As Variant, ByVal sourceRow As Long)
    Dim dateOK As Boolean, normalizedDate As Variant, balanceAmount As Double
    If Len(CellText(balanceData(sourceRow, WORK_BAL_COL_ACCOUNT_ID))) = 0 Or _
       Len(CellText(balanceData(sourceRow, WORK_BAL_COL_BALANCE_ID))) = 0 Then _
        Err.Raise vbObjectError + 5076, "ValidateReconciliationBalanceRow", _
                  "W_残高 " & CStr(sourceRow + 1) & "行目の識別子がありません。"
    normalizedDate = NormalizeDateOnlyValue(balanceData(sourceRow, 8), dateOK)
    If Not dateOK Or _
       Abs(CDbl(CDate(balanceData(sourceRow, 8))) - _
           CDbl(CDate(normalizedDate))) > RECON_EPSILON Then _
        Err.Raise vbObjectError + 5077, "ValidateReconciliationBalanceRow", _
                  "W_残高 " & CStr(sourceRow + 1) & "行目の基準日が不正です。"
    If IsError(balanceData(sourceRow, 10)) Or _
       IsNull(balanceData(sourceRow, 10)) Or _
       Not IsNumeric(balanceData(sourceRow, 10)) Then _
        Err.Raise vbObjectError + 5078, "ValidateReconciliationBalanceRow", _
                  "W_残高 " & CStr(sourceRow + 1) & "行目の残高が数値ではありません。"
    balanceAmount = CDbl(balanceData(sourceRow, 10))
    If Abs(balanceAmount) > MAX_ABS_AMOUNT Then _
        Err.Raise vbObjectError + 5078, "ValidateReconciliationBalanceRow", _
                  "W_残高 " & CStr(sourceRow + 1) & "行目の残高が範囲外です。"
End Sub

Private Sub PrepareReconciliationBalanceRows( _
        ByVal rowsByAccount As Object, ByRef balanceData As Variant, _
        ByVal accountID As String, ByRef rows() As Long, ByRef rowCount As Long)
    Dim accountRows As Collection, i As Long
    Erase rows
    rowCount = 0
    If rowsByAccount Is Nothing Then Exit Sub
    If Not rowsByAccount.Exists(accountID) Then Exit Sub
    Set accountRows = rowsByAccount(accountID)
    rowCount = accountRows.Count
    If rowCount = 0 Then Exit Sub
    ReDim rows(1 To rowCount)
    For i = 1 To rowCount
        rows(i) = CLng(accountRows(i))
    Next i
    If rowCount > 1 Then _
        QuickSortReconciliationBalanceRows balanceData, rows, 1, rowCount
    For i = 2 To rowCount
        If CLng(VBA.DateValue(CDate(balanceData(rows(i - 1), 8)))) = _
           CLng(VBA.DateValue(CDate(balanceData(rows(i), 8)))) Then _
            Err.Raise vbObjectError + 5079, "PrepareReconciliationBalanceRows", _
                      "W_残高に同一口座・同一基準日の重複があります: " & accountID
    Next i
End Sub

Private Sub QuickSortReconciliationBalanceRows( _
        ByRef balanceData As Variant, ByRef rows() As Long, _
        ByVal firstIndex As Long, ByVal lastIndex As Long)
    Dim low As Long, high As Long, pivotRow As Long, tempRow As Long
    low = firstIndex: high = lastIndex
    pivotRow = rows((firstIndex + lastIndex) \ 2)
    Do While low <= high
        Do While CompareReconciliationBalanceRows( _
                         balanceData, rows(low), pivotRow) < 0
            low = low + 1
        Loop
        Do While CompareReconciliationBalanceRows( _
                         balanceData, rows(high), pivotRow) > 0
            high = high - 1
        Loop
        If low <= high Then
            tempRow = rows(low): rows(low) = rows(high): rows(high) = tempRow
            low = low + 1: high = high - 1
        End If
    Loop
    If firstIndex < high Then _
        QuickSortReconciliationBalanceRows balanceData, rows, firstIndex, high
    If low < lastIndex Then _
        QuickSortReconciliationBalanceRows balanceData, rows, low, lastIndex
End Sub

Private Function CompareReconciliationBalanceRows( _
        ByRef balanceData As Variant, ByVal firstRow As Long, _
        ByVal secondRow As Long) As Long
    Dim firstDate As Long, secondDate As Long, compareValue As Long
    firstDate = CLng(VBA.DateValue(CDate(balanceData(firstRow, 8))))
    secondDate = CLng(VBA.DateValue(CDate(balanceData(secondRow, 8))))
    If firstDate < secondDate Then CompareReconciliationBalanceRows = -1: Exit Function
    If firstDate > secondDate Then CompareReconciliationBalanceRows = 1: Exit Function
    compareValue = StrComp( _
        CellText(balanceData(firstRow, WORK_BAL_COL_BALANCE_ID)), _
        CellText(balanceData(secondRow, WORK_BAL_COL_BALANCE_ID)), vbBinaryCompare)
    If compareValue <> 0 Then
        CompareReconciliationBalanceRows = compareValue
    ElseIf firstRow < secondRow Then
        CompareReconciliationBalanceRows = -1
    ElseIf firstRow > secondRow Then
        CompareReconciliationBalanceRows = 1
    End If
End Function

Private Sub ProcessReconciliationBalancesBeforeDate( _
        ByRef balanceData As Variant, ByRef balanceRows() As Long, _
        ByVal balanceCount As Long, ByRef balancePosition As Long, _
        ByVal transactionDate As Long, ByVal accountText As String, _
        ByRef baselineSet As Boolean, ByRef baselineBalance As Double, _
        ByRef runningDelta As Double, ByRef runningCompensation As Double, _
        ByRef intervalCount As Long, ByRef previousStamp As String, _
        ByRef checkedCount As Long, ByRef unanchoredCount As Long, _
        ByRef stagedRows() As Variant, ByRef outputCount As Long)
    Do While balancePosition <= balanceCount
        If CLng(VBA.DateValue(CDate( _
               balanceData(balanceRows(balancePosition), 8)))) >= transactionDate Then Exit Do
        ApplyReconciliationBalanceAnchor balanceData, balanceRows(balancePosition), _
            accountText, baselineSet, baselineBalance, runningDelta, _
            runningCompensation, intervalCount, previousStamp, checkedCount, _
            unanchoredCount, stagedRows, outputCount
        balancePosition = balancePosition + 1
    Loop
End Sub

Private Sub ProcessReconciliationBalanceOnDate( _
        ByRef balanceData As Variant, ByRef balanceRows() As Long, _
        ByVal balanceCount As Long, ByRef balancePosition As Long, _
        ByVal transactionDate As Long, ByVal accountText As String, _
        ByRef baselineSet As Boolean, ByRef baselineBalance As Double, _
        ByRef runningDelta As Double, ByRef runningCompensation As Double, _
        ByRef intervalCount As Long, ByRef previousStamp As String, _
        ByRef checkedCount As Long, ByRef unanchoredCount As Long, _
        ByRef stagedRows() As Variant, ByRef outputCount As Long)
    If balancePosition > balanceCount Then Exit Sub
    If CLng(VBA.DateValue(CDate( _
           balanceData(balanceRows(balancePosition), 8)))) <> transactionDate Then Exit Sub
    ApplyReconciliationBalanceAnchor balanceData, balanceRows(balancePosition), _
        accountText, baselineSet, baselineBalance, runningDelta, _
        runningCompensation, intervalCount, previousStamp, checkedCount, _
        unanchoredCount, stagedRows, outputCount
    balancePosition = balancePosition + 1
End Sub

Private Sub ProcessRemainingReconciliationBalances( _
        ByRef balanceData As Variant, ByRef balanceRows() As Long, _
        ByVal balanceCount As Long, ByRef balancePosition As Long, _
        ByVal accountText As String, ByRef baselineSet As Boolean, _
        ByRef baselineBalance As Double, ByRef runningDelta As Double, _
        ByRef runningCompensation As Double, ByRef intervalCount As Long, _
        ByRef previousStamp As String, ByRef checkedCount As Long, _
        ByRef unanchoredCount As Long, ByRef stagedRows() As Variant, _
        ByRef outputCount As Long)
    Do While balancePosition <= balanceCount
        ApplyReconciliationBalanceAnchor balanceData, balanceRows(balancePosition), _
            accountText, baselineSet, baselineBalance, runningDelta, _
            runningCompensation, intervalCount, previousStamp, checkedCount, _
            unanchoredCount, stagedRows, outputCount
        balancePosition = balancePosition + 1
    Loop
End Sub

Private Sub ApplyReconciliationBalanceAnchor( _
        ByRef balanceData As Variant, ByVal balanceRow As Long, _
        ByVal accountText As String, ByRef baselineSet As Boolean, _
        ByRef baselineBalance As Double, ByRef runningDelta As Double, _
        ByRef runningCompensation As Double, ByRef intervalCount As Long, _
        ByRef previousStamp As String, ByRef checkedCount As Long, _
        ByRef unanchoredCount As Long, ByRef stagedRows() As Variant, _
        ByRef outputCount As Long)
    Dim actualBalance As Double, expectedBalance As Double
    Dim stableDelta As Double, difference As Double, tolerance As Double
    Dim currentStamp As String
    actualBalance = CDbl(balanceData(balanceRow, 10))
    currentStamp = Format$(CDate(balanceData(balanceRow, 8)), "yyyy/m/d") & _
                   " 独立残高基準（日末・時刻なし）"
    If baselineSet Then
        stableDelta = runningDelta + runningCompensation
        expectedBalance = ReconciliationExpectedBalance(baselineBalance, stableDelta)
        difference = actualBalance - expectedBalance
        tolerance = ReconciliationTolerance(baselineBalance, stableDelta, actualBalance)
        If Abs(difference) > tolerance Then
            outputCount = outputCount + 1
            RequireReconciliationOutputSlot outputCount
            FillReconciliationIndependentAnchorBuffer stagedRows, outputCount, _
                accountText, previousStamp, currentStamp, intervalCount, _
                baselineBalance, stableDelta, expectedBalance, actualBalance, difference
        End If
        checkedCount = checkedCount + intervalCount
    ElseIf unanchoredCount > 0 Then
        outputCount = outputCount + 1
        RequireReconciliationOutputSlot outputCount
        FillReconciliationNoBaselineBuffer stagedRows, outputCount, accountText, _
            previousStamp, currentStamp, unanchoredCount
        unanchoredCount = 0
    End If
    baselineSet = True
    baselineBalance = actualBalance
    previousStamp = currentStamp
    runningDelta = 0#: runningCompensation = 0#: intervalCount = 0
End Sub

Private Sub FinalizeReconciliationAccountCoverage( _
        ByVal accountText As String, ByVal previousStamp As String, _
        ByVal lastAccountStamp As String, ByVal baselineSet As Boolean, _
        ByVal baselineBalance As Double, ByVal runningDelta As Double, _
        ByVal runningCompensation As Double, ByVal intervalCount As Long, _
        ByVal unanchoredCount As Long, ByVal transactionCount As Long, _
        ByVal checkedCount As Long, ByVal dayOnlyCount As Long, _
        ByVal sameTimeCount As Long, ByVal firstAccountStamp As String, _
        ByRef stagedRows() As Variant, ByRef outputCount As Long)
    Dim stableDelta As Double, unverifiedCount As Long
    If intervalCount > 0 Then
        stableDelta = runningDelta + runningCompensation
        outputCount = outputCount + 1
        RequireReconciliationOutputSlot outputCount
        FillReconciliationUnclosedTailBuffer stagedRows, outputCount, accountText, _
            previousStamp, lastAccountStamp, intervalCount, baselineSet, _
            baselineBalance, stableDelta
    End If
    If unanchoredCount > 0 Then
        outputCount = outputCount + 1
        RequireReconciliationOutputSlot outputCount
        FillReconciliationNoBaselineBuffer stagedRows, outputCount, accountText, _
            vbNullString, lastAccountStamp, unanchoredCount
    End If
    unverifiedCount = transactionCount - checkedCount
    If unverifiedCount < 0 Then unverifiedCount = 0
    outputCount = outputCount + 1
    RequireReconciliationOutputSlot outputCount
    FillReconciliationCoverageBuffer stagedRows, outputCount, accountText, _
        firstAccountStamp, lastAccountStamp, transactionCount, checkedCount, _
        dayOnlyCount, sameTimeCount, unverifiedCount, baselineSet, previousStamp
End Sub

Private Sub FillReconciliationIndependentAnchorBuffer( _
        ByRef buffer() As Variant, ByVal bufferRow As Long, _
        ByVal accountText As String, ByVal previousStamp As String, _
        ByVal currentStamp As String, ByVal transactionCount As Long, _
        ByVal baseline As Double, ByVal netAmount As Double, _
        ByVal expected As Double, ByVal actual As Double, ByVal difference As Double)
    buffer(bufferRow, 1) = accountText
    buffer(bufferRow, 2) = previousStamp
    buffer(bufferRow, 3) = currentStamp
    buffer(bufferRow, 4) = transactionCount
    buffer(bufferRow, 5) = baseline
    buffer(bufferRow, 6) = netAmount
    buffer(bufferRow, 7) = expected
    buffer(bufferRow, 8) = actual
    buffer(bufferRow, 9) = "差額 " & Format$(difference, "#,##0.########") & _
                           " / " & RECON_INDEPENDENT_ANCHOR_RESULT
End Sub

Private Sub FillReconciliationNoBaselineBuffer( _
        ByRef buffer() As Variant, ByVal bufferRow As Long, _
        ByVal accountText As String, ByVal previousStamp As String, _
        ByVal currentStamp As String, ByVal transactionCount As Long)
    buffer(bufferRow, 1) = accountText
    buffer(bufferRow, 2) = previousStamp
    buffer(bufferRow, 3) = currentStamp
    buffer(bufferRow, 4) = transactionCount
    buffer(bufferRow, 5) = Empty
    buffer(bufferRow, 6) = Empty
    buffer(bufferRow, 7) = Empty
    buffer(bufferRow, 8) = Empty
    buffer(bufferRow, 9) = RECON_NO_BASELINE_RESULT
End Sub

Private Sub FillReconciliationUnclosedTailBuffer( _
        ByRef buffer() As Variant, ByVal bufferRow As Long, _
        ByVal accountText As String, ByVal previousStamp As String, _
        ByVal currentStamp As String, ByVal transactionCount As Long, _
        ByVal hasBaseline As Boolean, ByVal baseline As Double, _
        ByVal netAmount As Double)
    buffer(bufferRow, 1) = accountText
    buffer(bufferRow, 2) = previousStamp
    buffer(bufferRow, 3) = currentStamp
    buffer(bufferRow, 4) = transactionCount
    If hasBaseline Then
        buffer(bufferRow, 5) = baseline
        buffer(bufferRow, 6) = netAmount
        buffer(bufferRow, 7) = ReconciliationExpectedBalance(baseline, netAmount)
    Else
        buffer(bufferRow, 5) = Empty
        buffer(bufferRow, 6) = Empty
        buffer(bufferRow, 7) = Empty
    End If
    buffer(bufferRow, 8) = Empty
    buffer(bufferRow, 9) = RECON_UNCLOSED_TAIL_RESULT
End Sub

Private Sub FillReconciliationCoverageBuffer( _
        ByRef buffer() As Variant, ByVal bufferRow As Long, _
        ByVal accountText As String, ByVal firstStamp As String, _
        ByVal lastStamp As String, ByVal transactionCount As Long, _
        ByVal checkedCount As Long, ByVal dayOnlyCount As Long, _
        ByVal sameTimeCount As Long, ByVal unverifiedCount As Long, _
        ByVal hasBaseline As Boolean, ByVal baselineStamp As String)
    buffer(bufferRow, 1) = accountText
    buffer(bufferRow, 2) = firstStamp
    buffer(bufferRow, 3) = lastStamp
    buffer(bufferRow, 4) = transactionCount
    buffer(bufferRow, 5) = checkedCount
    buffer(bufferRow, 6) = dayOnlyCount
    buffer(bufferRow, 7) = sameTimeCount
    buffer(bufferRow, 8) = unverifiedCount
    If transactionCount = 0 Then
        buffer(bufferRow, 9) = RECON_COVERAGE_PREFIX & _
                               "基準点のみ / 対象取引なし / " & baselineStamp
    Else
        buffer(bufferRow, 9) = RECON_COVERAGE_PREFIX & _
            "検算済 " & CStr(checkedCount) & "/" & CStr(transactionCount) & _
            " / 日計のみ " & CStr(dayOnlyCount) & _
            " / 同一時刻群 " & CStr(sameTimeCount) & _
            " / 未検算 " & CStr(unverifiedCount) & _
            IIf(hasBaseline, " / 最終基準 " & baselineStamp, " / 基準残高なし")
    End If
End Sub

Private Function ReconciliationBalanceAccountText( _
        ByRef balanceData As Variant, ByVal rowNo As Long) As String
    ReconciliationBalanceAccountText = CellText(balanceData(rowNo, 1)) & " / " & _
        CellText(balanceData(rowNo, 2)) & " " & CellText(balanceData(rowNo, 3)) & _
        " " & CellText(balanceData(rowNo, 4)) & " " & CellText(balanceData(rowNo, 5))
End Function

Private Sub ValidateReconciliationSourceRow(ByRef data As Variant, ByVal sourceRow As Long)
    Dim normalizedDate As Variant, normalizedTime As Variant
    Dim dateOK As Boolean, timeOK As Boolean
    Dim inputOrder As Double

    If IsError(data(sourceRow, OUT_COL_DATE)) Or _
       IsNull(data(sourceRow, OUT_COL_DATE)) Then _
        Err.Raise vbObjectError + 5040, "ValidateReconciliationSourceRow", _
                  "W_取引 " & CStr(sourceRow + 1) & "行目の日付が不正です。"
    normalizedDate = NormalizeDateOnlyValue(data(sourceRow, OUT_COL_DATE), dateOK)
    If Not dateOK Then _
        Err.Raise vbObjectError + 5040, "ValidateReconciliationSourceRow", _
                  "W_取引 " & CStr(sourceRow + 1) & "行目の日付が不正です。"
    If Abs(CDbl(CDate(data(sourceRow, OUT_COL_DATE))) - _
           CDbl(CDate(normalizedDate))) > RECON_EPSILON Then _
        Err.Raise vbObjectError + 5044, "ValidateReconciliationSourceRow", _
                  "W_取引 " & CStr(sourceRow + 1) & "行目の日付列に時刻が混入しています。"

    If IsError(data(sourceRow, OUT_COL_TIME)) Or _
       IsNull(data(sourceRow, OUT_COL_TIME)) Then _
        Err.Raise vbObjectError + 5045, "ValidateReconciliationSourceRow", _
                  "W_取引 " & CStr(sourceRow + 1) & "行目の時刻が不正です。"
    If HasText(data(sourceRow, OUT_COL_TIME)) Then
        normalizedTime = NormalizeTimeInput(data(sourceRow, OUT_COL_TIME), timeOK)
        If Not timeOK Then _
            Err.Raise vbObjectError + 5045, "ValidateReconciliationSourceRow", _
                      "W_取引 " & CStr(sourceRow + 1) & "行目の時刻が不正です。"
    End If

    If Len(CellText(data(sourceRow, WORK_TX_COL_ACCOUNT_ID))) = 0 Then _
        Err.Raise vbObjectError + 5041, "ValidateReconciliationSourceRow", _
                  "W_取引 " & CStr(sourceRow + 1) & "行目の口座IDがありません。"
    If Len(CellText(data(sourceRow, WORK_TX_COL_TRANSACTION_ID))) = 0 Then _
        Err.Raise vbObjectError + 5046, "ValidateReconciliationSourceRow", _
                  "W_取引 " & CStr(sourceRow + 1) & "行目の取引IDがありません。"

    If IsError(data(sourceRow, WORK_TX_COL_INPUT_ORDER)) Or _
       IsNull(data(sourceRow, WORK_TX_COL_INPUT_ORDER)) Or _
       Not IsNumeric(data(sourceRow, WORK_TX_COL_INPUT_ORDER)) Then _
        Err.Raise vbObjectError + 5047, "ValidateReconciliationSourceRow", _
                  "W_取引 " & CStr(sourceRow + 1) & "行目の入力順が不正です。"
    inputOrder = CDbl(data(sourceRow, WORK_TX_COL_INPUT_ORDER))
    If inputOrder < 0 Or inputOrder <> Fix(inputOrder) Then _
        Err.Raise vbObjectError + 5047, "ValidateReconciliationSourceRow", _
                  "W_取引 " & CStr(sourceRow + 1) & "行目の入力順が不正です。"

    ValidateReconciliationAmountValue data(sourceRow, OUT_COL_WITHDRAW), _
                                      "出金額", sourceRow, False
    ValidateReconciliationAmountValue data(sourceRow, OUT_COL_DEPOSIT), _
                                      "入金額", sourceRow, False
    ValidateReconciliationAmountValue data(sourceRow, OUT_COL_OTHER), _
                                      "取引後残高", sourceRow, True
    If HasText(data(sourceRow, OUT_COL_WITHDRAW)) And _
       HasText(data(sourceRow, OUT_COL_DEPOSIT)) Then _
        Err.Raise vbObjectError + 5048, "ValidateReconciliationSourceRow", _
                  "W_取引 " & CStr(sourceRow + 1) & _
                  "行目に出金と入金が同時入力されています。"
End Sub

Private Sub ValidateReconciliationAmountValue(ByVal valueIn As Variant, _
                                               ByVal labelText As String, _
                                               ByVal sourceRow As Long, _
                                               ByVal allowNegative As Boolean)
    Dim amountValue As Double
    If IsError(valueIn) Or IsNull(valueIn) Then GoTo InvalidAmount
    If Not HasText(valueIn) Then Exit Sub
    If Not IsNumeric(valueIn) Then GoTo InvalidAmount
    On Error GoTo InvalidAmount
    amountValue = CDbl(valueIn)
    On Error GoTo 0
    If Abs(amountValue) > MAX_ABS_AMOUNT Then GoTo InvalidAmount
    If Not allowNegative And amountValue < 0 Then GoTo InvalidAmount
    Exit Sub
InvalidAmount:
    Err.Raise vbObjectError + 5049, "ValidateReconciliationAmountValue", _
              "W_取引 " & CStr(sourceRow + 1) & "行目の" & labelText & _
              "が不正または範囲外です。"
End Sub

Private Sub WriteReconciliationStagedRows(ByVal ws As Worksheet, ByRef stagedRows() As Variant, _
                                          ByVal outputCount As Long)
    Const WRITE_CHUNK_ROWS As Long = 2000
    Dim writeData() As Variant
    Dim chunkFirst As Long, chunkCount As Long
    Dim r As Long, c As Long
    For chunkFirst = 1 To outputCount Step WRITE_CHUNK_ROWS
        chunkCount = CLng(Application.Min(WRITE_CHUNK_ROWS, outputCount - chunkFirst + 1))
        ReDim writeData(1 To chunkCount, 1 To BALANCE_RECONCILIATION_LAST_COL)
        For r = 1 To chunkCount
            For c = 1 To BALANCE_RECONCILIATION_LAST_COL
                writeData(r, c) = stagedRows(chunkFirst + r - 1, c)
            Next c
        Next r
        ws.Range(ws.Cells(chunkFirst + 1, 1), _
                 ws.Cells(chunkFirst + chunkCount, BALANCE_RECONCILIATION_LAST_COL)).Value2 = writeData
        VerifyGeneratedRangeValue2 ws, writeData, chunkFirst + 1, 1, chunkCount, _
                                   BALANCE_RECONCILIATION_LAST_COL, "残高検算", False
    Next chunkFirst
End Sub

Private Sub RequireReconciliationOutputSlot(ByVal outputCount As Long)
    If outputCount > MAX_ANALYSIS_OUTPUT_ROWS Then _
        Err.Raise vbObjectError + 5043, "BuildBalanceReconciliationCore", _
                  "残高検算の出力件数が実用上限を超えました。"
End Sub

Private Sub FillReconciliationBuffer(ByRef buffer() As Variant, ByVal bufferRow As Long, _
                                     ByRef data As Variant, ByVal sourceRow As Long, _
                                     ByVal previousStamp As String, ByVal currentStamp As String, _
                                     ByVal intervalCount As Long, ByVal baseline As Double, _
                                     ByVal netAmount As Double, ByVal expected As Double, _
                                     ByVal actual As Double, ByVal difference As Double, _
                                     ByVal orderText As String)
    buffer(bufferRow, 1) = ReconciliationAccountText(data, sourceRow)
    buffer(bufferRow, 2) = previousStamp
    buffer(bufferRow, 3) = currentStamp
    buffer(bufferRow, 4) = intervalCount
    buffer(bufferRow, 5) = baseline
    buffer(bufferRow, 6) = netAmount
    buffer(bufferRow, 7) = expected
    buffer(bufferRow, 8) = actual
    buffer(bufferRow, 9) = "差額 " & Format$(difference, "#,##0.########") & " / " & orderText
End Sub

Private Sub FillReconciliationDayOnlyBuffer( _
        ByRef buffer() As Variant, ByVal bufferRow As Long, _
        ByRef data As Variant, ByVal sourceRow As Long, _
        ByVal transactionCount As Long, _
        ByVal dayNetAmount As Double)
    buffer(bufferRow, 1) = ReconciliationAccountText(data, sourceRow)
    buffer(bufferRow, 2) = Empty
    buffer(bufferRow, 3) = Format$(CDate(data(sourceRow, OUT_COL_DATE)), "yyyy/m/d") & _
                           " 日計のみ"
    buffer(bufferRow, 4) = transactionCount
    buffer(bufferRow, 5) = Empty
    buffer(bufferRow, 6) = dayNetAmount
    '日内のどの取引後残高か確定できないため、計算残高・記載残高を作らない。
    buffer(bufferRow, 7) = Empty
    buffer(bufferRow, 8) = Empty
    buffer(bufferRow, 9) = RECON_DAY_ONLY_RESULT
End Sub

Private Sub FillReconciliationSameTimeBuffer( _
        ByRef buffer() As Variant, ByVal bufferRow As Long, _
        ByRef data As Variant, ByVal sourceRow As Long, _
        ByVal previousStamp As String, ByVal currentStamp As String, _
        ByVal transactionCount As Long, ByVal hasBaseline As Boolean, _
        ByVal baseline As Double, ByVal netAmount As Double, _
        ByVal expected As Double)
    buffer(bufferRow, 1) = ReconciliationAccountText(data, sourceRow)
    buffer(bufferRow, 2) = previousStamp
    buffer(bufferRow, 3) = currentStamp
    buffer(bufferRow, 4) = transactionCount
    If hasBaseline Then
        buffer(bufferRow, 5) = baseline
        buffer(bufferRow, 7) = expected
    Else
        buffer(bufferRow, 5) = Empty
        buffer(bufferRow, 7) = Empty
    End If
    buffer(bufferRow, 6) = netAmount
    '同一時刻内のどの行が終端か確定できないため、任意の取引ID順の残高を採用しない。
    buffer(bufferRow, 8) = Empty
    buffer(bufferRow, 9) = RECON_SAME_TIME_UNVERIFIED_RESULT
End Sub

'同一時刻群は個別順序で逐次検算せず、群純額から求めた終端残高と
'一致する記載残高が群内にあるかを一度だけ検査する。
Private Function ReconciliationMatchingTimestampBalanceRow( _
        ByRef data As Variant, ByRef rows() As Long, _
        ByVal firstIndex As Long, ByVal lastIndex As Long, _
        ByVal baseline As Double, ByVal netAmount As Double, _
        ByVal expected As Double) As Long
    Dim i As Long, sourceRow As Long
    Dim actual As Double, tolerance As Double
    If firstIndex < 1 Or lastIndex < firstIndex Then Exit Function
    For i = firstIndex To lastIndex
        sourceRow = rows(i)
        If HasText(data(sourceRow, OUT_COL_OTHER)) Then
            If Not IsNumeric(data(sourceRow, OUT_COL_OTHER)) Then Exit Function
            actual = CDbl(data(sourceRow, OUT_COL_OTHER))
            tolerance = ReconciliationTolerance(baseline, netAmount, actual)
            If Abs(actual - expected) <= tolerance Then
                ReconciliationMatchingTimestampBalanceRow = sourceRow
                Exit Function
            End If
        End If
    Next i
End Function

Private Sub FinalizeBalanceReconciliation(ByVal ws As Worksheet, ByVal dataCount As Long)
    Dim lastR As Long
    lastR = dataCount + 1
    ws.Unprotect Password:=TOOL_PASSWORD
    FormatOutputHeader ws.Range(ws.Cells(1, 1), ws.Cells(1, BALANCE_RECONCILIATION_LAST_COL))
    If dataCount > 0 Then
        With ws.Range(ws.Cells(2, 1), ws.Cells(lastR, BALANCE_RECONCILIATION_LAST_COL))
            .Borders.LineStyle = xlContinuous
            .Borders.Color = RGB(226, 232, 240)
            .VerticalAlignment = xlTop
            .WrapText = True
        End With
        With ws.Range(ws.Cells(2, 9), ws.Cells(lastR, 9))
            .Interior.Color = RGB(254, 226, 226)
            .FormatConditions.Delete
            With .FormatConditions.Add(Type:=xlTextString, _
                    String:=RECON_DAY_ONLY_RESULT, TextOperator:=xlContains)
                .Interior.Color = RGB(254, 243, 199)
                .Font.Color = RGB(146, 64, 14)
            End With
            With .FormatConditions.Add(Type:=xlTextString, _
                    String:=RECON_SAME_TIME_PREFIX, TextOperator:=xlContains)
                .Interior.Color = RGB(254, 243, 199)
                .Font.Color = RGB(146, 64, 14)
            End With
            With .FormatConditions.Add(Type:=xlTextString, _
                    String:=RECON_COVERAGE_PREFIX, TextOperator:=xlContains)
                .Interior.Color = RGB(219, 234, 254)
                .Font.Color = RGB(30, 64, 175)
            End With
            With .FormatConditions.Add(Type:=xlTextString, _
                    String:=RECON_UNCLOSED_TAIL_RESULT, TextOperator:=xlContains)
                .Interior.Color = RGB(254, 243, 199)
                .Font.Color = RGB(146, 64, 14)
            End With
        End With
        ws.Rows("2:" & CStr(lastR)).RowHeight = 40
    End If
    If ws.AutoFilterMode Then ws.AutoFilterMode = False
    ws.Range(ws.Cells(1, 1), ws.Cells(lastR, BALANCE_RECONCILIATION_LAST_COL)).AutoFilter
    SafeFreezeOutputHeader ws
    ProtectSingleAnalysisSheet ws
End Sub

Private Sub QuickSortReconciliationRows(ByRef data As Variant, ByRef rows() As Long, _
                                        ByVal firstIndex As Long, ByVal lastIndex As Long, _
                                        ByVal dayHasMissing As Object)
    Dim low As Long, high As Long, pivotRow As Long, tempRow As Long
    low = firstIndex: high = lastIndex: pivotRow = rows((firstIndex + lastIndex) \ 2)
    Do While low <= high
        Do While CompareReconciliationRows(data, rows(low), pivotRow, dayHasMissing) < 0
            low = low + 1
        Loop
        Do While CompareReconciliationRows(data, rows(high), pivotRow, dayHasMissing) > 0
            high = high - 1
        Loop
        If low <= high Then
            tempRow = rows(low): rows(low) = rows(high): rows(high) = tempRow
            low = low + 1: high = high - 1
        End If
    Loop
    If firstIndex < high Then QuickSortReconciliationRows data, rows, firstIndex, high, dayHasMissing
    If low < lastIndex Then QuickSortReconciliationRows data, rows, low, lastIndex, dayHasMissing
End Sub

Private Function CompareReconciliationRows(ByRef data As Variant, ByVal firstRow As Long, _
                                           ByVal secondRow As Long, _
                                           ByVal dayHasMissing As Object) As Long
    Dim compareValue As Long, firstDate As Long, secondDate As Long
    Dim firstTime As Double, secondTime As Double
    Dim dayKey As String, firstTransactionID As String, secondTransactionID As String
    compareValue = StrComp(CellText(data(firstRow, WORK_TX_COL_ACCOUNT_ID)), _
                           CellText(data(secondRow, WORK_TX_COL_ACCOUNT_ID)), vbBinaryCompare)
    If compareValue <> 0 Then CompareReconciliationRows = compareValue: Exit Function
    firstDate = CLng(VBA.DateValue(CDate(data(firstRow, OUT_COL_DATE))))
    secondDate = CLng(VBA.DateValue(CDate(data(secondRow, OUT_COL_DATE))))
    If firstDate < secondDate Then CompareReconciliationRows = -1: Exit Function
    If firstDate > secondDate Then CompareReconciliationRows = 1: Exit Function
    dayKey = ReconciliationDayKey(data, firstRow)
    If Not dayHasMissing.Exists(dayKey) Then
        firstTime = ReconciliationTimeNumber(data(firstRow, OUT_COL_TIME))
        secondTime = ReconciliationTimeNumber(data(secondRow, OUT_COL_TIME))
        If firstTime < secondTime Then CompareReconciliationRows = -1: Exit Function
        If firstTime > secondTime Then CompareReconciliationRows = 1: Exit Function
    End If
    '時刻欠落日の日内並びは計算に使わない。取引IDは日グループを安定化するだけで、
    '時間的順序を表さない。全件時刻ありで同時刻の場合も同様に安定化だけを行う。
    firstTransactionID = CellText(data(firstRow, WORK_TX_COL_TRANSACTION_ID))
    secondTransactionID = CellText(data(secondRow, WORK_TX_COL_TRANSACTION_ID))
    compareValue = StrComp(firstTransactionID, secondTransactionID, vbBinaryCompare)
    If compareValue <> 0 Then
        CompareReconciliationRows = compareValue
    ElseIf firstRow < secondRow Then
        CompareReconciliationRows = -1
    ElseIf firstRow > secondRow Then
        CompareReconciliationRows = 1
    End If
End Function

Private Function ReconciliationDayKey(ByRef data As Variant, ByVal rowNo As Long) As String
    ReconciliationDayKey = CellText(data(rowNo, WORK_TX_COL_ACCOUNT_ID)) & "|" & _
                           Format$(CDate(data(rowNo, OUT_COL_DATE)), "yyyymmdd")
End Function

Private Function ReconciliationDayRequiresDailyNet( _
        ByVal dayHasMissing As Object, ByVal dayKey As String) As Boolean
    ReconciliationDayRequiresDailyNet = dayHasMissing.Exists(dayKey)
End Function

Private Function ReconciliationMayUseTransactionBalance( _
        ByVal dayRequiresDailyNet As Boolean, ByVal balanceValue As Variant) As Boolean
    If dayRequiresDailyNet Then Exit Function
    ReconciliationMayUseTransactionBalance = HasText(balanceValue)
End Function

Private Function ReconciliationDelta(ByRef data As Variant, ByVal rowNo As Long) As Double
    ReconciliationDelta = ReconciliationNumber(data(rowNo, OUT_COL_DEPOSIT)) - _
                          ReconciliationNumber(data(rowNo, OUT_COL_WITHDRAW))
End Function

Private Function ReconciliationDayNet(ByRef data As Variant, _
                                      ByRef rows() As Long, _
                                      ByVal firstIndex As Long, _
                                      ByVal lastIndex As Long) As Double
    Dim runningTotal As Double, compensation As Double, i As Long
    For i = firstIndex To lastIndex
        AddReconciliationDelta runningTotal, compensation, _
                               ReconciliationDelta(data, rows(i))
    Next i
    ReconciliationDayNet = runningTotal + compensation
End Function

'Neumaier補償和で、多数の小額取引や大きな基準残高に対する丸め誤差の蓄積を抑える。
Private Sub AddReconciliationDelta(ByRef runningTotal As Double, _
                                   ByRef compensation As Double, _
                                   ByVal valueToAdd As Double)
    Dim newTotal As Double
    newTotal = runningTotal + valueToAdd
    If Abs(runningTotal) >= Abs(valueToAdd) Then
        compensation = compensation + ((runningTotal - newTotal) + valueToAdd)
    Else
        compensation = compensation + ((valueToAdd - newTotal) + runningTotal)
    End If
    runningTotal = newTotal
End Sub

'固定許容差に加え、Excelの倍精度数で表現可能な約4 ULPを上限尺度に応じて許容する。
'これにより計算機丸めだけの偽不一致を除きつつ、表現可能な実額差は残す。
Private Function ReconciliationTolerance(ByVal baseline As Double, _
                                         ByVal netAmount As Double, _
                                         ByVal actual As Double) As Double
    Const DOUBLE_EPSILON As Double = 2.22044604925031E-16
    Dim scaleValue As Double, floatingAllowance As Double
    scaleValue = Abs(baseline)
    If Abs(netAmount) > scaleValue Then scaleValue = Abs(netAmount)
    If Abs(actual) > scaleValue Then scaleValue = Abs(actual)
    floatingAllowance = scaleValue * DOUBLE_EPSILON * 4#
    If floatingAllowance > RECON_EPSILON Then
        ReconciliationTolerance = floatingAllowance
    Else
        ReconciliationTolerance = RECON_EPSILON
    End If
End Function

Private Function ReconciliationExpectedBalance(ByVal baseline As Double, _
                                               ByVal netAmount As Double) As Double
    ReconciliationExpectedBalance = baseline + netAmount
End Function

Private Function ReconciliationNumber(ByVal valueIn As Variant) As Double
    If IsError(valueIn) Or IsNull(valueIn) Or IsEmpty(valueIn) Then Exit Function
    If IsNumeric(valueIn) Then ReconciliationNumber = CDbl(valueIn)
End Function

Private Function ReconciliationTimeNumber(ByVal valueIn As Variant) As Double
    If HasText(valueIn) Then ReconciliationTimeNumber = CDbl(VBA.TimeValue(CDate(valueIn)))
End Function

Private Function ReconciliationDateTimeText(ByRef data As Variant, ByVal rowNo As Long) As String
    ReconciliationDateTimeText = Format$(CDate(data(rowNo, OUT_COL_DATE)), "yyyy/m/d") & " "
    If HasText(data(rowNo, OUT_COL_TIME)) Then
        ReconciliationDateTimeText = ReconciliationDateTimeText & _
                                     Format$(VBA.TimeValue(CDate(data(rowNo, OUT_COL_TIME))), "hh:mm")
    Else
        ReconciliationDateTimeText = ReconciliationDateTimeText & "時刻記載なし"
    End If
End Function

Private Function ReconciliationAccountText(ByRef data As Variant, ByVal rowNo As Long) As String
    ReconciliationAccountText = CellText(data(rowNo, OUT_COL_PERSON)) & " / " & _
        CellText(data(rowNo, OUT_COL_BANK)) & " " & CellText(data(rowNo, OUT_COL_BRANCH)) & _
        " " & CellText(data(rowNo, OUT_COL_ACCOUNT_TYPE)) & " " & _
        CellText(data(rowNo, OUT_COL_ACCOUNT_NO))
End Function

'シートを書き換えず、全時刻あり・一部欠落・全件欠落の3経路を検証する。



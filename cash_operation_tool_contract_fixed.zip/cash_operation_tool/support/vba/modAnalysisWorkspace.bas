﻿Attribute VB_Name = "modAnalysisWorkspace"
Option Explicit

'資金操作表へ表示する候補を、内部で9列の調査単位へ集約する。
'元の3分析表と候補詳細は、確認記録と監査根拠を保持する内部表として残す。
Private Const WORKSPACE_BUFFER_ROWS As Long = 1000
Private Const WORKSPACE_MEMO_MAX As Long = 1000
Private Const WORKSPACE_TEXT_LIMIT As Long = 1000
Private Const MANUAL_BUILDER_MAX_ROWS As Long = 50000
Private Const MANUAL_BUILDER_HEADER_ROW As Long = 5
Private Const DETAIL_COL_KIND As Long = 8
Private Const DETAIL_COL_REFERENCE As Long = 9
Private Const DETAIL_COL_SOURCE_ROW As Long = 10
Private Const DETAIL_COL_SOURCE_KEY As Long = 11
Private Const DETAIL_COL_SELECTED As Long = 12
Private Const ANALYSIS_CAPACITY_BASE_COLUMNS As Long = 16
Private Const ANALYSIS_CAPACITY_LONG_MAX As Double = 2147483647#
Private Const ANALYSIS_CAPACITY_64_PROMPT_ROWS As Double = 150000#
Private Const ANALYSIS_CAPACITY_32_PROMPT_ROWS As Double = 50000#
Private Const ANALYSIS_CAPACITY_32_MAX_ROWS As Double = 75000#
Private Const WORKSPACE_PERSON_DIFFERENT As String = "別人物間"
Private Const WORKSPACE_PERSON_SAME As String = "同一人物間"
Private Const ANALYSIS_WORKSPACE_RECOVERY_FATAL_ERROR As Long = vbObjectError + 5191
Private Const ANALYSIS_WORKSPACE_RECOVERY_FATAL_SOURCE As String = _
    "AnalysisWorkspaceRecoveryFatal/"

Private Type AnalysisDetailSelectionSnapshot
    ItemCount As Long
    Rows() As Long
    SelectedValues() As Variant
    SelectedHasFormula() As Boolean
    SelectedFormulas() As String
    DisplayValues() As Variant
    DisplayHasFormula() As Boolean
    DisplayFormulas() As String
    FillColors() As Long
    FillPatterns() As Long
    FillTints() As Double
    FontBolds() As Boolean
    SummaryValue As Variant
    SummaryHasFormula As Boolean
    SummaryFormula As String
End Type

Private mAnalysisDetailReviewsDirty As Boolean

Private Function AnalysisCapacitySheetRows(ByVal sheetName As String, _
                                           ByVal lastColumn As Long) As Long
    Dim lastR As Long
    If lastColumn < 1 Then _
        Err.Raise vbObjectError + 4865, "AnalysisCapacitySheetRows", _
                  "分析容量の検査列が不正です: " & sheetName
    If Not SheetExists(sheetName) Then _
        Err.Raise vbObjectError + 4866, "AnalysisCapacitySheetRows", _
                  "分析容量を検査するシートがありません: " & sheetName
    lastR = LastDataRowInColumns(GetSheet(sheetName), 1, lastColumn)
    If lastR >= 2 Then AnalysisCapacitySheetRows = lastR - 1
End Function

Private Function AnalysisReviewCellWork( _
        ByVal reviewRows As Long, ByVal historyRows As Long, _
        ByVal shiftRows As Long, ByVal flowRows As Long, ByVal unknownRows As Long, _
        ByVal resultRows As Long, ByVal groupRows As Long, ByVal detailRows As Long, _
        ByVal manualRows As Long, ByVal transactionRows As Long) As Double
    If reviewRows < 0 Or historyRows < 0 Or shiftRows < 0 Or flowRows < 0 Or _
       unknownRows < 0 Or resultRows < 0 Or groupRows < 0 Or detailRows < 0 Or _
       manualRows < 0 Or transactionRows < 0 Then _
        Err.Raise vbObjectError + 4867, "AnalysisReviewCellWork", _
                  "分析容量の行数に負数があります。"
    AnalysisReviewCellWork = _
        CDbl(reviewRows) * CDbl(ANALYSIS_REVIEW_STORE_LAST_COL) + _
        CDbl(historyRows) * CDbl(ANALYSIS_HISTORY_STORE_LAST_COL) + _
        CDbl(shiftRows) * CDbl(SHIFT_ANALYSIS_LAST_COL) + _
        CDbl(flowRows) * CDbl(FLOW_ANALYSIS_LAST_COL) + _
        CDbl(unknownRows) * CDbl(UNKNOWN_ANALYSIS_LAST_COL) + _
        CDbl(resultRows) * CDbl(ANALYSIS_RESULT_LAST_COL) + _
        CDbl(groupRows) * CDbl(ANALYSIS_GROUP_LAST_COL) + _
        CDbl(detailRows) * CDbl(DETAIL_COL_SELECTED) + _
        CDbl(manualRows) * CDbl(MANUAL_FLOW_STORE_LAST_COL) + _
        CDbl(transactionRows) * CDbl(WORK_TX_COL_PERSON_ID)
End Function

Private Function AnalysisCapacityEquivalentRows(ByVal cellWork As Double) As Double
    Dim equivalentRows As Double
    If cellWork < 0# Then _
        Err.Raise vbObjectError + 4867, "AnalysisCapacityEquivalentRows", _
                  "分析容量のセル数が不正です。"
    equivalentRows = Int(cellWork / CDbl(ANALYSIS_CAPACITY_BASE_COLUMNS))
    If cellWork > equivalentRows * CDbl(ANALYSIS_CAPACITY_BASE_COLUMNS) Then _
        equivalentRows = equivalentRows + 1#
    AnalysisCapacityEquivalentRows = equivalentRows
End Function

Private Function AnalysisWorkspaceCandidateWorkloadRows( _
        ByVal shiftRows As Long, ByVal flowRows As Long) As Double
    If shiftRows < 0 Or flowRows < 0 Then _
        Err.Raise vbObjectError + 4867, "AnalysisWorkspaceCandidateWorkloadRows", _
                  "分析候補の行数が不正です。"
    AnalysisWorkspaceCandidateWorkloadRows = CDbl(shiftRows) + CDbl(flowRows)
End Function

Private Function AnalysisCapacityNeedsConfirmation( _
        ByVal requiredWorkloadRows As Double, _
        ByVal confirmedWorkloadRows As Double) As Boolean
#If Win64 Or Mac Then
    AnalysisCapacityNeedsConfirmation = _
        (requiredWorkloadRows > ANALYSIS_CAPACITY_64_PROMPT_ROWS And _
         confirmedWorkloadRows <= ANALYSIS_CAPACITY_64_PROMPT_ROWS)
#Else
    If requiredWorkloadRows > ANALYSIS_CAPACITY_32_MAX_ROWS Then
        AnalysisCapacityNeedsConfirmation = True
    Else
        AnalysisCapacityNeedsConfirmation = _
            (requiredWorkloadRows > ANALYSIS_CAPACITY_32_PROMPT_ROWS And _
             confirmedWorkloadRows <= ANALYSIS_CAPACITY_32_PROMPT_ROWS)
    End If
#End If
End Function

Public Function ConfirmAnalysisReviewOperationCapacity( _
        ByVal operationName As String, ByRef confirmedWorkloadRows As Double, _
        Optional ByVal plannedShiftRows As Long = -1, _
        Optional ByVal plannedFlowRows As Long = -1, _
        Optional ByVal plannedUnknownRows As Long = -1, _
        Optional ByVal plannedResultRows As Long = -1, _
        Optional ByVal plannedGroupRows As Long = -1, _
        Optional ByVal allowUserConfirmation As Boolean = True, _
        Optional ByVal additionalManualRows As Long = 0, _
        Optional ByVal additionalSnapshotCellWork As Double = 0#) As Boolean
    Dim reviewRows As Long, historyRows As Long
    Dim shiftRows As Long, flowRows As Long, unknownRows As Long
    Dim resultRows As Long, groupRows As Long, detailRows As Long
    Dim manualRows As Long, transactionRows As Long
    Dim sourceRows As Double, plannedManualRows As Double
    Dim cellWork As Double, requiredWorkloadRows As Double

    If confirmedWorkloadRows < 0# Or confirmedWorkloadRows > ANALYSIS_CAPACITY_LONG_MAX Then _
        Err.Raise vbObjectError + 4869, "ConfirmAnalysisReviewOperationCapacity", _
                  "確認済みの分析容量が不正です。"
#If Win64 Or Mac Then
#Else
    If confirmedWorkloadRows > ANALYSIS_CAPACITY_32_MAX_ROWS Then _
        Err.Raise vbObjectError + 4869, "ConfirmAnalysisReviewOperationCapacity", _
                  "32bit版Excelの安全上限を超える確認済み分析容量は使用できません。"
#End If
    If plannedShiftRows < -1 Or plannedFlowRows < -1 Or plannedUnknownRows < -1 Or _
       plannedResultRows < -1 Or plannedGroupRows < -1 Then _
        Err.Raise vbObjectError + 4867, "ConfirmAnalysisReviewOperationCapacity", _
                  "分析の予定行数が不正です。"
    If additionalManualRows < 0 Then _
        Err.Raise vbObjectError + 4867, "ConfirmAnalysisReviewOperationCapacity", _
                  "手動候補の追加予定行数が不正です。"
    If additionalSnapshotCellWork < 0# Or _
       additionalSnapshotCellWork > ANALYSIS_CAPACITY_LONG_MAX * _
                                            CDbl(ANALYSIS_CAPACITY_BASE_COLUMNS) Then _
        Err.Raise vbObjectError + 4867, "ConfirmAnalysisReviewOperationCapacity", _
                  "分析更新ロールバック用の退避容量が不正です。"

    reviewRows = AnalysisCapacitySheetRows( _
                     SH_WORK_ANALYSIS_REVIEW, ANALYSIS_REVIEW_STORE_LAST_COL)
    historyRows = AnalysisCapacitySheetRows( _
                      SH_WORK_ANALYSIS_HISTORY, ANALYSIS_HISTORY_STORE_LAST_COL)
    shiftRows = AnalysisCapacitySheetRows(SH_ANALYSIS_SHIFT, SHIFT_ANALYSIS_LAST_COL)
    flowRows = AnalysisCapacitySheetRows(SH_ANALYSIS_FLOW, FLOW_ANALYSIS_LAST_COL)
    unknownRows = AnalysisCapacitySheetRows(SH_ANALYSIS_UNKNOWN, UNKNOWN_ANALYSIS_LAST_COL)
    resultRows = AnalysisCapacitySheetRows(SH_ANALYSIS_RESULT, ANALYSIS_RESULT_LAST_COL)
    groupRows = AnalysisCapacitySheetRows(SH_WORK_ANALYSIS_GROUP, ANALYSIS_GROUP_LAST_COL)
    detailRows = AnalysisCapacitySheetRows(SH_ANALYSIS_DETAIL, DETAIL_COL_SELECTED)
    manualRows = AnalysisCapacitySheetRows(SH_WORK_MANUAL_FLOW, MANUAL_FLOW_STORE_LAST_COL)
    transactionRows = AnalysisCapacitySheetRows(SH_WORK_TX, WORK_TX_COL_PERSON_ID)
    plannedManualRows = CDbl(manualRows) + CDbl(additionalManualRows)
    If plannedManualRows > ANALYSIS_CAPACITY_LONG_MAX Then _
        Err.Raise vbObjectError + 4873, "ConfirmAnalysisReviewOperationCapacity", _
                  "手動候補の予定件数をLong範囲で表現できません。"
    manualRows = CLng(plannedManualRows)

    '予定件数は旧表と同時保持する追加量ではなく、これから構築する配列寸法へ置き換える。
    '旧表全体は配列化せず、確認欄等の必要部分だけを上の台帳増分で別途保守的に見積もる。
    If plannedShiftRows >= 0 Then shiftRows = plannedShiftRows
    If plannedFlowRows >= 0 Then flowRows = plannedFlowRows
    If plannedUnknownRows >= 0 Then unknownRows = plannedUnknownRows
    If plannedResultRows >= 0 Then resultRows = plannedResultRows
    If plannedGroupRows >= 0 Then groupRows = plannedGroupRows

    cellWork = AnalysisReviewCellWork( _
                   reviewRows, historyRows, shiftRows, flowRows, unknownRows, _
                   resultRows, groupRows, detailRows, manualRows, transactionRows)
    cellWork = cellWork + additionalSnapshotCellWork
    '台帳には各元表の全件、履歴には全件と既存台帳の未掲載分が増える上界を加える。
    'Persist内部で計画件数が判明した後に初めて容量超過しないよう、入口で先取りする。
    sourceRows = CDbl(shiftRows) + CDbl(flowRows) + CDbl(unknownRows)
    cellWork = cellWork + _
               (2# * sourceRows + CDbl(reviewRows)) * _
               CDbl(ANALYSIS_HISTORY_STORE_LAST_COL)

    requiredWorkloadRows = AnalysisCapacityEquivalentRows(cellWork)
    If requiredWorkloadRows > ANALYSIS_CAPACITY_LONG_MAX Then _
        Err.Raise vbObjectError + 4868, "ConfirmAnalysisReviewOperationCapacity", _
                  "分析処理の安全容量をLong範囲で表現できません。"
    If Len(Trim$(operationName)) = 0 Then operationName = "分析処理"
    If requiredWorkloadRows <= confirmedWorkloadRows Then
        ConfirmAnalysisReviewOperationCapacity = True
        Exit Function
    End If
    If AnalysisCapacityNeedsConfirmation(requiredWorkloadRows, confirmedWorkloadRows) Then
        If Not allowUserConfirmation Then _
            Err.Raise vbObjectError + 4872, "ConfirmAnalysisReviewOperationCapacity", _
                      operationName & _
                      "は入口で確認済みの安全容量を超えました。途中確認は行わず処理を停止します。"
        If Not ConfirmLargeArrayOperation( _
                   CLng(requiredWorkloadRows), _
                   operationName & "（判断台帳・履歴・関連配列の事前安全検査）") Then _
            Exit Function
    End If
    confirmedWorkloadRows = requiredWorkloadRows
    ConfirmAnalysisReviewOperationCapacity = True
End Function

Private Function ConfirmCurrentAnalysisWorkspaceCapacity( _
        ByVal operationName As String, ByRef confirmedWorkloadRows As Double, _
        ByRef shiftCount As Long, ByRef flowCount As Long, ByRef unknownCount As Long, _
        ByRef candidateCount As Long, ByRef prospectiveResultCount As Long, _
        Optional ByVal allowUserConfirmation As Boolean = True, _
        Optional ByVal additionalSnapshotCellWork As Double = 0#) As Boolean
    Dim candidateWorkloadRows As Double, prospectiveResultRows As Double
    shiftCount = AnalysisCapacitySheetRows(SH_ANALYSIS_SHIFT, SHIFT_ANALYSIS_LAST_COL)
    flowCount = AnalysisCapacitySheetRows(SH_ANALYSIS_FLOW, FLOW_ANALYSIS_LAST_COL)
    unknownCount = AnalysisCapacitySheetRows(SH_ANALYSIS_UNKNOWN, UNKNOWN_ANALYSIS_LAST_COL)
    candidateWorkloadRows = AnalysisWorkspaceCandidateWorkloadRows(shiftCount, flowCount)
    If candidateWorkloadRows > 2# * CDbl(MAX_ANALYSIS_OUTPUT_ROWS) Then _
        Err.Raise vbObjectError + 4800, "ConfirmCurrentAnalysisWorkspaceCapacity", _
                  "分析候補の内部整理件数が実用上限を超えています。"
    If candidateWorkloadRows > ANALYSIS_CAPACITY_LONG_MAX Then _
        Err.Raise vbObjectError + 4870, "ConfirmCurrentAnalysisWorkspaceCapacity", _
                  "分析候補の内部整理件数をLong範囲で表現できません。"
    candidateCount = CLng(candidateWorkloadRows)
    prospectiveResultRows = candidateWorkloadRows + CDbl(unknownCount)
    If prospectiveResultRows > ANALYSIS_CAPACITY_LONG_MAX Then _
        Err.Raise vbObjectError + 4871, "ConfirmCurrentAnalysisWorkspaceCapacity", _
                  "分析結果の予定件数をLong範囲で表現できません。"
    prospectiveResultCount = CLng(prospectiveResultRows)
    ConfirmCurrentAnalysisWorkspaceCapacity = _
        ConfirmAnalysisReviewOperationCapacity( _
            operationName, confirmedWorkloadRows, shiftCount, flowCount, unknownCount, _
            prospectiveResultCount, candidateCount, allowUserConfirmation, _
            additionalSnapshotCellWork:=additionalSnapshotCellWork)
End Function

Public Function AnalysisResultHeaders() As Variant
    AnalysisResultHeaders = Array( _
        "優先度", _
        "区分", "日付・期間", "金額", "人物・資金経路", "要点", "反証・制約", _
        "確認状況", "確認メモ", "内部元表", "内部確認キー", "内部グループID", _
        "内部元行", "構成取引ID", "代替候補数")
End Function

Public Function AnalysisGroupHeaders() As Variant
    AnalysisGroupHeaders = Array( _
        "グループID", "元表", "元行", "確認キー", "構成取引ID", "スコア", _
        "代表", "区分", "確認状況", "確認メモ")
End Function

Public Sub SetupAnalysisWorkspaceSheets(Optional ByVal preserveVisibility As Boolean = False)
    Dim resultVisibility As XlSheetVisibility, detailVisibility As XlSheetVisibility
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim cleanupErrorNumber As Long, cleanupErrorDescription As String
    Dim cleanupErrorSource As String
    On Error GoTo EH
    If preserveVisibility Then
        resultVisibility = GetSheet(SH_ANALYSIS_RESULT).Visible
        detailVisibility = GetSheet(SH_ANALYSIS_DETAIL).Visible
    End If
    PrepareAnalysisResultSheet GetSheet(SH_ANALYSIS_RESULT)
    PrepareAnalysisDetailSheet GetSheet(SH_ANALYSIS_DETAIL)
    PrepareAnalysisGroupSheet GetSheet(SH_WORK_ANALYSIS_GROUP)
    If preserveVisibility Then
        GetSheet(SH_ANALYSIS_RESULT).Visible = resultVisibility
        GetSheet(SH_ANALYSIS_DETAIL).Visible = detailVisibility
    Else
        SetSheetVeryHiddenSafe GetSheet(SH_ANALYSIS_DETAIL)
    End If
    SetSheetVeryHiddenSafe GetSheet(SH_WORK_ANALYSIS_GROUP)
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    If IsAnalysisWorkspaceRecoveryFatalError(errorNumber, errorSource) Then _
        RethrowAnalysisWorkspaceUpstreamRecoveryFatal _
            errorNumber, errorSource, errorDescription, _
            "SetupAnalysisWorkspaceSheets"
    On Error Resume Next
    Err.Clear
    ProtectTransactionAnalysisSheets False
    cleanupErrorNumber = Err.Number
    cleanupErrorDescription = Err.Description
    cleanupErrorSource = Err.Source
    Err.Clear
    On Error GoTo 0
    If IsAnalysisWorkspaceRecoveryFatalError( _
           cleanupErrorNumber, cleanupErrorSource) Then _
        RethrowAnalysisWorkspaceUpstreamRecoveryFatal _
            cleanupErrorNumber, cleanupErrorSource, _
            cleanupErrorDescription, "SetupAnalysisWorkspaceSheets/異常終了再保護"
    On Error Resume Next
    If SheetExists(SH_WORK_ANALYSIS_GROUP) Then _
        SetSheetVeryHiddenSafe GetSheet(SH_WORK_ANALYSIS_GROUP)
    On Error GoTo 0
    Err.Raise errorNumber, "SetupAnalysisWorkspaceSheets", errorSource & " / " & errorDescription
End Sub

Private Sub PrepareAnalysisResultSheet(ByVal ws As Worksheet)
    If ws Is Nothing Then Exit Sub
    ws.Unprotect Password:=TOOL_PASSWORD
    If ws.AutoFilterMode Then ws.AutoFilterMode = False
    ResetWorksheet ws
    SetRowValues ws.Range("A1"), AnalysisResultHeaders()
    FormatOutputHeader ws.Range(ws.Cells(1, 1), ws.Cells(1, ANALYSIS_RESULT_LAST_COL))
    ws.Columns("A:O").NumberFormatLocal = "@"
    ws.Columns("A:A").NumberFormatLocal = "0"
    ws.Columns("D:D").NumberFormatLocal = "#,##0.########"
    ApplyAnalysisResultColumnWidths ws
    ws.Rows(1).RowHeight = 52
    ws.Columns("J:O").Hidden = True
    AddManualBuilderHint ws
    ProtectSingleAnalysisSheet ws
End Sub

Private Sub PrepareAnalysisDetailSheet(ByVal ws As Worksheet)
    If ws Is Nothing Then Exit Sub
    ws.Unprotect Password:=TOOL_PASSWORD
    If ws.AutoFilterMode Then ws.AutoFilterMode = False
    ResetWorksheet ws
    With ws.Range("A1:L" & CStr(MANUAL_BUILDER_MAX_ROWS + MANUAL_BUILDER_HEADER_ROW + 5))
        .Font.Name = "Yu Gothic UI"
        .Font.Size = 10
    End With
    ws.Columns("A:A").ColumnWidth = 13
    ws.Columns("B:B").ColumnWidth = 14
    ws.Columns("C:C").ColumnWidth = 18
    ws.Columns("D:D").ColumnWidth = 28
    ws.Columns("E:E").ColumnWidth = 36
    ws.Columns("F:F").ColumnWidth = 18
    ws.Columns("G:G").ColumnWidth = 30
    ws.Columns("H:L").Hidden = True
    ws.Cells.Locked = True
    ProtectSingleAnalysisSheet ws
    mAnalysisDetailReviewsDirty = False
End Sub

Private Sub PrepareAnalysisGroupSheet(ByVal ws As Worksheet)
    If ws Is Nothing Then Exit Sub
    ws.Unprotect Password:=TOOL_PASSWORD
    ResetWorksheet ws
    SetRowValues ws.Range("A1"), AnalysisGroupHeaders()
    FormatOutputHeader ws.Range(ws.Cells(1, 1), ws.Cells(1, ANALYSIS_GROUP_LAST_COL))
    ws.Columns("A:J").NumberFormatLocal = "@"
    SetSheetVeryHiddenSafe ws
End Sub

Public Function AnalysisDetailReviewDirtySnapshot() As Boolean
    AnalysisDetailReviewDirtySnapshot = mAnalysisDetailReviewsDirty
End Function

Public Sub RestoreAnalysisWorkspaceTransactionSnapshot( _
        ByRef resultSnapshot As Variant, ByVal resultLastRow As Long, _
        ByVal resultVisibility As Long, ByVal resultProtected As Boolean, _
        ByRef groupSnapshot As Variant, ByVal groupLastRow As Long, _
        ByVal groupVisibility As Long, ByVal groupProtected As Boolean, _
        ByRef detailHeaderSnapshot As Variant, ByRef detailSnapshot As Variant, _
        ByVal detailLastRow As Long, ByVal detailVisibility As Long, _
        ByVal detailProtected As Boolean, ByVal detailReviewsDirty As Boolean)
    Dim wsResult As Worksheet, wsGroup As Worksheet, wsDetail As Worksheet
    Dim detailHeader As Range, resultRange As Range
    Dim resultCount As Long
    Set wsResult = GetSheet(SH_ANALYSIS_RESULT)
    Set wsGroup = GetSheet(SH_WORK_ANALYSIS_GROUP)
    Set wsDetail = GetSheet(SH_ANALYSIS_DETAIL)

    PrepareAnalysisResultSheet wsResult
    PrepareAnalysisGroupSheet wsGroup
    PrepareAnalysisDetailSheet wsDetail
    wsResult.Unprotect Password:=TOOL_PASSWORD
    wsDetail.Unprotect Password:=TOOL_PASSWORD
    RestoreAtomicConstantWorksheetData wsResult, ANALYSIS_RESULT_LAST_COL, _
        MAX_ANALYSIS_OUTPUT_ROWS, resultSnapshot, resultLastRow, "分析結果"
    RestoreAtomicConstantWorksheetData wsGroup, ANALYSIS_GROUP_LAST_COL, _
        MAX_ANALYSIS_OUTPUT_ROWS * 2, groupSnapshot, groupLastRow, "分析グループ"
    Set detailHeader = wsDetail.Range(wsDetail.Cells(1, 1), _
                                      wsDetail.Cells(1, DETAIL_COL_SELECTED))
    detailHeader.Value2 = detailHeaderSnapshot
    If Not RangeValue2MatchesMatrixStrict( _
               detailHeader, detailHeaderSnapshot, 1, DETAIL_COL_SELECTED) Then _
        Err.Raise vbObjectError + 4874, "RestoreAnalysisWorkspaceTransactionSnapshot", _
                  "候補詳細の見出しを厳密に復元できません。"
    RestoreAtomicConstantWorksheetData wsDetail, DETAIL_COL_SELECTED, _
        MAX_ANALYSIS_OUTPUT_ROWS, detailSnapshot, detailLastRow, "候補詳細"
    RebuildAnalysisDetailSnapshotLayout wsDetail, detailLastRow
    If detailLastRow >= 2 Then
        If Not RangeValue2MatchesMatrixStrict( _
                   wsDetail.Range(wsDetail.Cells(2, 1), _
                                  wsDetail.Cells(detailLastRow, DETAIL_COL_SELECTED)), _
                   detailSnapshot, detailLastRow - 1, DETAIL_COL_SELECTED) Then _
            Err.Raise vbObjectError + 4877, _
                      "RestoreAnalysisWorkspaceTransactionSnapshot", _
                      "候補詳細の再構築後データが開始時と一致しません。"
    End If
    If Not RangeValue2MatchesMatrixStrict( _
               detailHeader, detailHeaderSnapshot, 1, DETAIL_COL_SELECTED) Then _
        Err.Raise vbObjectError + 4878, _
                  "RestoreAnalysisWorkspaceTransactionSnapshot", _
                  "候補詳細の再構築後見出しが開始時と一致しません。"

    resultCount = resultLastRow - 1
    If resultCount < 0 Then resultCount = 0
    FinalizeAnalysisResultSheet wsResult, resultCount
    If resultLastRow >= 2 Then
        Set resultRange = wsResult.Range(wsResult.Cells(2, 1), _
                                         wsResult.Cells(resultLastRow, _
                                                        ANALYSIS_RESULT_LAST_COL))
        If Not RangeValue2MatchesMatrixStrict( _
                   resultRange, resultSnapshot, resultCount, _
                   ANALYSIS_RESULT_LAST_COL) Then
            '同順位行の再Sort順が変わっても、操作開始時の行順を最後に戻す。
            wsResult.Unprotect Password:=TOOL_PASSWORD
            RestoreAtomicConstantWorksheetData wsResult, ANALYSIS_RESULT_LAST_COL, _
                MAX_ANALYSIS_OUTPUT_ROWS, resultSnapshot, resultLastRow, "分析結果"
            ProtectSingleAnalysisSheet wsResult
        End If
    End If
    ProtectSingleAnalysisSheet wsDetail
    If groupProtected Then
        EmergencyProtectToolSheet wsGroup
    Else
        wsGroup.Unprotect Password:=TOOL_PASSWORD
    End If
    If Not resultProtected Then wsResult.Unprotect Password:=TOOL_PASSWORD
    If Not detailProtected Then wsDetail.Unprotect Password:=TOOL_PASSWORD
    wsResult.Visible = resultVisibility
    wsGroup.Visible = groupVisibility
    wsDetail.Visible = detailVisibility
    If CLng(wsResult.Visible) <> resultVisibility Or _
       CLng(wsGroup.Visible) <> groupVisibility Or _
       CLng(wsDetail.Visible) <> detailVisibility Then _
        Err.Raise vbObjectError + 4875, "RestoreAnalysisWorkspaceTransactionSnapshot", _
                  "分析workspaceの表示状態を復元できません。"
    If wsResult.ProtectContents <> resultProtected Or _
       wsGroup.ProtectContents <> groupProtected Or _
       wsDetail.ProtectContents <> detailProtected Then _
        Err.Raise vbObjectError + 4876, "RestoreAnalysisWorkspaceTransactionSnapshot", _
                  "分析workspaceの保護状態を復元できません。"
    mAnalysisDetailReviewsDirty = detailReviewsDirty
End Sub

Private Sub RebuildAnalysisDetailSnapshotLayout( _
        ByVal ws As Worksheet, ByVal snapshotLastRow As Long)
    Dim r As Long, firstDataRow As Long
    Dim manualBuilder As Boolean, legacyDetail As Boolean
    Dim sourceSheet As String, categoryText As String
    If ws Is Nothing Then Exit Sub
    ws.Unprotect Password:=TOOL_PASSWORD
    ws.Columns("H:L").Hidden = True
    ws.Cells.Locked = True
    If snapshotLastRow < 2 Then
        ws.ScrollArea = "A1:G50"
        Exit Sub
    End If

    legacyDetail = (CellText(ws.Cells(2, DETAIL_COL_KIND).Value) = "手動登録")
    manualBuilder = legacyDetail And snapshotLastRow >= MANUAL_BUILDER_HEADER_ROW And _
                    CellText(ws.Cells(MANUAL_BUILDER_HEADER_ROW, 1).Value) = "選択" And _
                    CellText(ws.Cells(MANUAL_BUILDER_HEADER_ROW, 2).Value) = "日付"
    If manualBuilder Then
        ws.Range("A1:G1").Merge
        ws.Range("A2:G2").Merge
        ws.Range("A3:G3").Merge
        With ws.Range("A1:G1")
            .Interior.Color = RGB(239, 246, 255)
            .Font.Color = RGB(30, 64, 175)
            .Font.Bold = True
            .Font.Size = 15
            .HorizontalAlignment = xlCenter
        End With
        With ws.Range("A2:G2")
            .Interior.Color = RGB(254, 249, 195)
            .Font.Color = RGB(133, 77, 14)
            .Font.Bold = True
            .HorizontalAlignment = xlCenter
        End With
        FormatOutputHeader ws.Range(ws.Cells(MANUAL_BUILDER_HEADER_ROW, 1), _
                                     ws.Cells(MANUAL_BUILDER_HEADER_ROW, 7))
        ws.Columns("A:A").ColumnWidth = 10
        ws.Columns("B:B").ColumnWidth = 13
        ws.Columns("C:C").ColumnWidth = 9
        ws.Columns("D:E").ColumnWidth = 15.5
        ws.Columns("F:F").ColumnWidth = 38
        ws.Columns("G:G").ColumnWidth = 42
        ws.Columns("D:E").NumberFormatLocal = "#,##0.########"
        firstDataRow = MANUAL_BUILDER_HEADER_ROW + 1
        If snapshotLastRow >= firstDataRow Then
            With ws.Range(ws.Cells(firstDataRow, 1), ws.Cells(snapshotLastRow, 7))
                .Borders.LineStyle = xlContinuous
                .Borders.Color = RGB(226, 232, 240)
                .VerticalAlignment = xlTop
                .WrapText = True
            End With
            ws.Rows(CStr(firstDataRow) & ":" & CStr(snapshotLastRow)).RowHeight = 32
            For r = firstDataRow To snapshotLastRow
                If CellText(ws.Cells(r, DETAIL_COL_SELECTED).Value) = "1" Then
                    ws.Range(ws.Cells(r, 1), ws.Cells(r, 7)).Interior.Color = RGB(219, 234, 254)
                    ws.Range(ws.Cells(r, 1), ws.Cells(r, 7)).Font.Bold = True
                End If
            Next r
        End If
        ws.Rows(1).RowHeight = 30
        ws.Rows(2).RowHeight = 32
        ws.Rows(3).RowHeight = 30
        ws.Rows(MANUAL_BUILDER_HEADER_ROW).RowHeight = 30
        If ws.AutoFilterMode Then ws.AutoFilterMode = False
        ws.Range(ws.Cells(MANUAL_BUILDER_HEADER_ROW, 1), _
                 ws.Cells(Application.Max(MANUAL_BUILDER_HEADER_ROW, snapshotLastRow), 7)).AutoFilter
        ws.ScrollArea = "A1:G" & CStr(snapshotLastRow + 20)
        Exit Sub
    End If

    If legacyDetail Then
        ws.Range("A1:G1").Merge
        ws.Range("A2:G2").Merge
        ws.Range("F3:G3").Merge
        ws.Range("B4:D4").Merge
        ws.Range("F4:G4").Merge
        ws.Range("B5:G5").Merge
        ws.Range("B7:G8").Merge
        ws.Range("B10:G11").Merge
        ws.Range("B13:G13").Merge
        ws.Range("B14:G14").Merge
        ws.Range("B15:G15").Merge
        With ws.Range("A1:G1")
            .Interior.Color = RGB(239, 246, 255)
            .Font.Color = RGB(30, 64, 175)
            .Font.Bold = True
            .Font.Size = 15
            .HorizontalAlignment = xlCenter
        End With
        With ws.Range("A2:G2")
            .Interior.Color = RGB(254, 249, 195)
            .Font.Color = RGB(133, 77, 14)
            .Font.Bold = True
            .HorizontalAlignment = xlCenter
            .WrapText = True
        End With
        With ws.Range("A3:G15")
            .Borders.LineStyle = xlContinuous
            .Borders.Color = RGB(203, 213, 225)
            .WrapText = True
        End With
        ws.Rows(1).RowHeight = 30
        ws.Rows(2).RowHeight = 36
        ws.Rows("3:4").RowHeight = 24
        ws.Rows(5).RowHeight = 30
        ws.Rows(6).RowHeight = 8
        ws.Rows("7:8").RowHeight = 30
        ws.Rows(9).RowHeight = 8
        ws.Rows("10:11").RowHeight = 30
        ws.Rows(12).RowHeight = 8
        ws.Rows(13).RowHeight = 32
        ws.Rows("14:15").RowHeight = 30
        ws.Range("A6:G6,A9:G9,A12:G12").Borders.LineStyle = xlNone
        For r = 2 To snapshotLastRow
            Select Case CellText(ws.Cells(r, DETAIL_COL_KIND).Value)
                Case "候補"
                    sourceSheet = CellText(ws.Cells(r, DETAIL_COL_REFERENCE).Value)
                    categoryText = CellText(ws.Cells(r, 1).Value)
                    ws.Cells(r, 6).Locked = False
                    ApplyAnalysisDetailStatusValidation ws.Cells(r, 6), _
                                                        sourceSheet, categoryText
                    With ws.Range(ws.Cells(r, 1), ws.Cells(r, 7))
                        .Borders.LineStyle = xlContinuous
                        .Borders.Color = RGB(226, 232, 240)
                        .WrapText = True
                        .VerticalAlignment = xlTop
                    End With
                    ws.Rows(r).RowHeight = 48
                Case "候補メモ"
                    ws.Range(ws.Cells(r, 2), ws.Cells(r, 7)).Merge
                    ws.Range(ws.Cells(r, 2), ws.Cells(r, 7)).Locked = False
                    ApplyAnalysisDetailMemoValidation ws.Cells(r, 2)
                    With ws.Range(ws.Cells(r, 1), ws.Cells(r, 7))
                        .Borders.LineStyle = xlContinuous
                        .Borders.Color = RGB(226, 232, 240)
                        .Interior.Color = RGB(255, 251, 235)
                        .WrapText = True
                    End With
                    ws.Rows(r).RowHeight = 38
                Case "取引"
                    With ws.Range(ws.Cells(r, 1), ws.Cells(r, 7))
                        .Borders.LineStyle = xlContinuous
                        .Borders.Color = RGB(226, 232, 240)
                        .WrapText = True
                        .VerticalAlignment = xlTop
                    End With
                    If CellText(ws.Cells(r, DETAIL_COL_SELECTED).Value) = "1" Then
                        ws.Range(ws.Cells(r, 1), ws.Cells(r, 7)).Interior.Color = RGB(219, 234, 254)
                        ws.Range(ws.Cells(r, 1), ws.Cells(r, 7)).Font.Bold = True
                    End If
            End Select
        Next r
        ws.ScrollArea = "A1:G" & CStr(Application.Max(50, snapshotLastRow + 20))
    Else
        ws.ScrollArea = "A1:G" & CStr(Application.Max(50, snapshotLastRow + 20))
    End If
End Sub

Public Sub BuildAnalysisWorkspaceCore( _
        ByVal callerContext As String, _
        Optional ByRef confirmedWorkloadRows As Double = 0#, _
        Optional ByVal allowCapacityPrompt As Boolean = True, _
        Optional ByVal additionalSnapshotCellWork As Double = 0#)
    Dim wsShift As Worksheet, wsFlow As Worksheet, wsUnknown As Worksheet
    Dim wsResult As Worksheet, wsGroup As Worksheet
    Dim shiftCount As Long, flowCount As Long, unknownCount As Long
    Dim candidateCount As Long, resultCount As Long
    Dim parent() As Long, sourceRows() As Long, scores() As Long
    Dim sourceSheets() As String, sourceKeys() As String, txIDs() As String
    Dim categories() As String, datesText() As String, routes() As String
    Dim points() As String, constraints() As String, statuses() As String, memos() As String
    Dim amounts() As Double
    Dim personClasses() As String, oneToOneFlags() As Boolean
    Dim owners As Object, txPersonByID As Object, txDirectionByID As Object
    Dim groupCounts() As Long, representatives() As Long
    Dim groupHasDifferent() As Boolean, groupHasSame() As Boolean
    Dim groupSeedParts() As Collection, groupIDs() As String
    Dim i As Long, rootIndex As Long, groupTotal As Long, outputTotal As Long
    Dim resultBuffer() As Variant, resultBufferCount As Long, nextResultRow As Long
    Dim prospectiveResultCount As Long
    Dim errorNumber As Long, errorDescription As String, errorSource As String

    If Len(Trim$(callerContext)) = 0 Then _
        Err.Raise vbObjectError + 4799, "BuildAnalysisWorkspaceCore", _
                  "呼出元コンテキストがありません。外側の分析更新処理から実行してください。"
    Set wsShift = GetSheet(SH_ANALYSIS_SHIFT)
    Set wsFlow = GetSheet(SH_ANALYSIS_FLOW)
    Set wsUnknown = GetSheet(SH_ANALYSIS_UNKNOWN)
    Set wsResult = GetSheet(SH_ANALYSIS_RESULT)
    Set wsGroup = GetSheet(SH_WORK_ANALYSIS_GROUP)
    '元表の読込み配列と結果・グループの最大予定寸法を、旧workspaceの初期化前に確認する。
    If Not ConfirmCurrentAnalysisWorkspaceCapacity( _
               callerContext, confirmedWorkloadRows, shiftCount, flowCount, unknownCount, _
               candidateCount, prospectiveResultCount, allowCapacityPrompt, _
               additionalSnapshotCellWork) Then _
        Err.Raise 18, "BuildAnalysisWorkspaceCore", _
                  "分析workspaceの容量確認が取り消されました。"

    On Error GoTo EH
    '人物整合性エラーで旧分析結果を消さないよう、シート初期化より先に読取検査する。
    If candidateCount > 0 Then _
        LoadWorkspaceTransactionIdentity txPersonByID, txDirectionByID

    If candidateCount > 0 Then
        ReDim parent(1 To candidateCount)
        ReDim sourceRows(1 To candidateCount)
        ReDim scores(1 To candidateCount)
        ReDim sourceSheets(1 To candidateCount)
        ReDim sourceKeys(1 To candidateCount)
        ReDim txIDs(1 To candidateCount)
        ReDim categories(1 To candidateCount)
        ReDim datesText(1 To candidateCount)
        ReDim routes(1 To candidateCount)
        ReDim points(1 To candidateCount)
        ReDim constraints(1 To candidateCount)
        ReDim statuses(1 To candidateCount)
        ReDim memos(1 To candidateCount)
        ReDim amounts(1 To candidateCount)
        ReDim personClasses(1 To candidateCount)
        ReDim oneToOneFlags(1 To candidateCount)
        Set owners = CreateObject("Scripting.Dictionary")
        owners.CompareMode = vbTextCompare
        i = 0
        LoadWorkspaceShiftCandidates wsShift, shiftCount, i, parent, sourceRows, scores, _
                                     sourceSheets, sourceKeys, txIDs, categories, datesText, _
                                     routes, points, constraints, statuses, memos, amounts, _
                                     personClasses, oneToOneFlags, txPersonByID, txDirectionByID, owners
        LoadWorkspaceFlowCandidates wsFlow, flowCount, i, parent, sourceRows, scores, _
                                    sourceSheets, sourceKeys, txIDs, categories, datesText, _
                                    routes, points, constraints, statuses, memos, amounts, _
                                    personClasses, oneToOneFlags, txPersonByID, txDirectionByID, owners

        ReDim groupCounts(1 To candidateCount)
        ReDim representatives(1 To candidateCount)
        ReDim groupSeedParts(1 To candidateCount)
        ReDim groupIDs(1 To candidateCount)
        ReDim groupHasDifferent(1 To candidateCount)
        ReDim groupHasSame(1 To candidateCount)
        For i = 1 To candidateCount
            rootIndex = WorkspaceFindRoot(parent, i)
            groupCounts(rootIndex) = groupCounts(rootIndex) + 1
            If personClasses(i) = WORKSPACE_PERSON_DIFFERENT Then
                groupHasDifferent(rootIndex) = True
            ElseIf personClasses(i) = WORKSPACE_PERSON_SAME Then
                groupHasSame(rootIndex) = True
            Else
                Err.Raise vbObjectError + 4850, "BuildAnalysisWorkspaceCore", _
                          "候補の人物区分が不正です。"
            End If
            If groupSeedParts(rootIndex) Is Nothing Then _
                Set groupSeedParts(rootIndex) = New Collection
            groupSeedParts(rootIndex).Add sourceSheets(i) & ":" & sourceKeys(i) & "|"
            If representatives(rootIndex) = 0 Then
                representatives(rootIndex) = i
            ElseIf WorkspaceCandidateIsBetterRepresentative( _
                       i, representatives(rootIndex), statuses, oneToOneFlags, _
                       personClasses, scores) Then
                representatives(rootIndex) = i
            End If
        Next i
        For i = 1 To candidateCount
            If groupCounts(i) > 0 Then
                groupTotal = groupTotal + 1
                groupIDs(i) = "G-" & WorkspaceDigest( _
                    JoinWorkspaceGroupSeedParts(groupSeedParts(i)))
            End If
        Next i
    End If

    resultCount = groupTotal + unknownCount
    If resultCount > MAX_ANALYSIS_OUTPUT_ROWS Then _
        Err.Raise vbObjectError + 4801, "BuildAnalysisWorkspaceCore", _
                  "整理後の分析結果が実用上限（" & Format$(MAX_ANALYSIS_OUTPUT_ROWS, "#,##0") & _
                  "件）を超えています。分析条件を絞ってください。"

    '読取検査・候補整理・最終件数検査が全て成功してから旧workspaceを置き換える。
    PrepareAnalysisResultSheet wsResult
    PrepareAnalysisGroupSheet wsGroup
    PrepareAnalysisDetailSheet GetSheet(SH_ANALYSIS_DETAIL)
    SetSheetVeryHiddenSafe GetSheet(SH_ANALYSIS_DETAIL)

    If candidateCount > 0 Then
        WriteWorkspaceGroupTable wsGroup, candidateCount, parent, sourceRows, scores, _
                                 sourceSheets, sourceKeys, txIDs, categories, statuses, memos, _
                                 personClasses, groupCounts, representatives, groupIDs
        ReDim resultBuffer(1 To WORKSPACE_BUFFER_ROWS, 1 To ANALYSIS_RESULT_LAST_COL)
        nextResultRow = 2
        For i = 1 To candidateCount
            If representatives(i) > 0 Then
                outputTotal = outputTotal + 1
                resultBufferCount = resultBufferCount + 1
                FillWorkspaceCandidateResult resultBuffer, resultBufferCount, representatives(i), _
                                              groupCounts(i), groupIDs(i), sourceRows, scores, _
                                              sourceSheets, sourceKeys, txIDs, categories, datesText, _
                                              routes, points, constraints, statuses, memos, amounts
                If groupHasDifferent(i) And personClasses(representatives(i)) <> _
                   WORKSPACE_PERSON_DIFFERENT Then
                    resultBuffer(resultBufferCount, 7) = WorkspaceTrimText( _
                        WorkspaceAppend(CellText(resultBuffer(resultBufferCount, 7)), _
                        "別人物間の代替候補あり。反証・制約欄をダブルクリックして確認できます。", " / "), _
                        WORKSPACE_TEXT_LIMIT)
                ElseIf groupHasSame(i) And personClasses(representatives(i)) <> _
                       WORKSPACE_PERSON_SAME Then
                    resultBuffer(resultBufferCount, 7) = WorkspaceTrimText( _
                        WorkspaceAppend(CellText(resultBuffer(resultBufferCount, 7)), _
                        "同一人物間の代替候補あり。", " / "), _
                        WORKSPACE_TEXT_LIMIT)
                End If
                If resultBufferCount = WORKSPACE_BUFFER_ROWS Then
                    FlushWorkspaceBuffer wsResult, resultBuffer, resultBufferCount, nextResultRow, _
                                         ANALYSIS_RESULT_LAST_COL
                    ReDim resultBuffer(1 To WORKSPACE_BUFFER_ROWS, 1 To ANALYSIS_RESULT_LAST_COL)
                    resultBufferCount = 0
                End If
            End If
        Next i
        If resultBufferCount > 0 Then _
            FlushWorkspaceBuffer wsResult, resultBuffer, resultBufferCount, nextResultRow, _
                                 ANALYSIS_RESULT_LAST_COL
    End If
    If unknownCount > 0 Then _
        WriteWorkspaceUnknownResults wsUnknown, wsResult, outputTotal, unknownCount, wsGroup
    If outputTotal <> resultCount Then _
        Err.Raise vbObjectError + 4802, "BuildAnalysisWorkspaceCore", _
                  "分析結果の事前件数と出力件数が一致しません。"

    FinalizeAnalysisResultSheet wsResult, resultCount
    SetSheetVeryHiddenSafe wsResult
    SetSheetVeryHiddenSafe wsGroup
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    If IsAnalysisWorkspaceRecoveryFatalError(errorNumber, errorSource) Then _
        RethrowAnalysisWorkspaceUpstreamRecoveryFatal _
            errorNumber, errorSource, errorDescription, _
            "BuildAnalysisWorkspaceCore"
    On Error Resume Next
    If Not wsResult Is Nothing Then EmergencyProtectToolSheet wsResult
    If SheetExists(SH_ANALYSIS_DETAIL) Then _
        EmergencyProtectToolSheet GetSheet(SH_ANALYSIS_DETAIL)
    If SheetExists(SH_WORK_ANALYSIS_GROUP) Then _
        SetSheetVeryHiddenSafe GetSheet(SH_WORK_ANALYSIS_GROUP)
    On Error GoTo 0
    Err.Raise errorNumber, "BuildAnalysisWorkspaceCore", errorDescription
End Sub

Private Function JoinWorkspaceGroupSeedParts(ByVal seedParts As Collection) As String
    Dim values() As String, i As Long
    If seedParts Is Nothing Then Exit Function
    If seedParts.Count < 1 Then Exit Function
    ReDim values(0 To seedParts.Count - 1)
    For i = 1 To seedParts.Count
        values(i - 1) = CStr(seedParts(i))
    Next i
    JoinWorkspaceGroupSeedParts = Join(values, vbNullString)
End Function

Private Sub LoadWorkspaceShiftCandidates( _
        ByVal ws As Worksheet, ByVal itemCount As Long, ByRef outputIndex As Long, _
        ByRef parent() As Long, ByRef sourceRows() As Long, ByRef scores() As Long, _
        ByRef sourceSheets() As String, ByRef sourceKeys() As String, ByRef txIDs() As String, _
        ByRef categories() As String, ByRef datesText() As String, ByRef routes() As String, _
        ByRef points() As String, ByRef constraints() As String, ByRef statuses() As String, _
        ByRef memos() As String, ByRef amounts() As Double, _
        ByRef personClasses() As String, ByRef oneToOneFlags() As Boolean, _
        ByVal txPersonByID As Object, ByVal txDirectionByID As Object, ByVal owners As Object)
    Dim data As Variant, r As Long, itemIndex As Long
    If itemCount <= 0 Then Exit Sub
    data = ws.Range(ws.Cells(2, 1), ws.Cells(itemCount + 1, SHIFT_ANALYSIS_LAST_COL)).Value2
    For r = 1 To itemCount
        If r Mod 2048 = 0 Then AppProgress "資金シフト候補を調査単位へ整理しています...", r, itemCount
        outputIndex = outputIndex + 1: itemIndex = outputIndex
        parent(itemIndex) = itemIndex
        sourceRows(itemIndex) = r + 1
        sourceSheets(itemIndex) = SH_ANALYSIS_SHIFT
        sourceKeys(itemIndex) = CellText(data(r, SHIFT_ANALYSIS_KEY_COL))
        txIDs(itemIndex) = WorkspaceJoinIDs(CellText(data(r, 33)), CellText(data(r, 34)))
        scores(itemIndex) = WorkspaceLong(data(r, 2))
        categories(itemIndex) = "資金シフト"
        datesText(itemIndex) = WorkspacePeriodText(data(r, 9), data(r, 19))
        amounts(itemIndex) = WorkspaceDouble(data(r, 17))
        routes(itemIndex) = WorkspacePartyAccount(data(r, 11), data(r, 12), data(r, 13), _
                            data(r, 14), data(r, 15), data(r, 16)) & " ⇒ " & _
                            WorkspacePartyAccount(data(r, 21), data(r, 22), data(r, 23), _
                            data(r, 24), data(r, 25), data(r, 26))
        points(itemIndex) = WorkspaceTrimText(CellText(data(r, 1)) & "・" & _
                            CellText(data(r, 3)) & "・" & CellText(data(r, 4)) & "。" & _
                            CellText(data(r, 29)), WORKSPACE_TEXT_LIMIT)
        constraints(itemIndex) = WorkspaceTrimText("時刻精度: " & CellText(data(r, 5)) & _
                                 " / 経過: " & CellText(data(r, 6)) & _
                                 " / 金額差: " & WorkspaceAmountText(data(r, 8)), WORKSPACE_TEXT_LIMIT)
        statuses(itemIndex) = WorkspaceStatusOrDefault(data(r, SHIFT_ANALYSIS_STATUS_COL))
        memos(itemIndex) = CellText(data(r, SHIFT_ANALYSIS_MEMO_COL))
        personClasses(itemIndex) = WorkspaceCandidatePersonClass( _
            txIDs(itemIndex), txPersonByID, txDirectionByID, oneToOneFlags(itemIndex))
        routes(itemIndex) = personClasses(itemIndex) & "｜" & routes(itemIndex)
        RegisterWorkspaceOwners txIDs(itemIndex), itemIndex, parent, owners
    Next r
End Sub

Private Sub LoadWorkspaceFlowCandidates( _
        ByVal ws As Worksheet, ByVal itemCount As Long, ByRef outputIndex As Long, _
        ByRef parent() As Long, ByRef sourceRows() As Long, ByRef scores() As Long, _
        ByRef sourceSheets() As String, ByRef sourceKeys() As String, ByRef txIDs() As String, _
        ByRef categories() As String, ByRef datesText() As String, ByRef routes() As String, _
        ByRef points() As String, ByRef constraints() As String, ByRef statuses() As String, _
        ByRef memos() As String, ByRef amounts() As Double, _
        ByRef personClasses() As String, ByRef oneToOneFlags() As Boolean, _
        ByVal txPersonByID As Object, ByVal txDirectionByID As Object, ByVal owners As Object)
    Dim data As Variant, r As Long, itemIndex As Long
    If itemCount <= 0 Then Exit Sub
    data = ws.Range(ws.Cells(2, 1), ws.Cells(itemCount + 1, FLOW_ANALYSIS_LAST_COL)).Value2
    For r = 1 To itemCount
        If r Mod 2048 = 0 Then AppProgress "資金フロー候補を調査単位へ整理しています...", r, itemCount
        outputIndex = outputIndex + 1: itemIndex = outputIndex
        parent(itemIndex) = itemIndex
        sourceRows(itemIndex) = r + 1
        sourceSheets(itemIndex) = SH_ANALYSIS_FLOW
        sourceKeys(itemIndex) = CellText(data(r, FLOW_ANALYSIS_KEY_COL))
        txIDs(itemIndex) = CellText(data(r, 20))
        scores(itemIndex) = WorkspaceLong(data(r, 2))
        categories(itemIndex) = "資金フロー"
        datesText(itemIndex) = CellText(data(r, 6))
        amounts(itemIndex) = WorkspaceDouble(data(r, 9))
        routes(itemIndex) = WorkspaceTrimText(CellText(data(r, 12)), WORKSPACE_TEXT_LIMIT)
        points(itemIndex) = WorkspaceTrimText(CellText(data(r, 3)) & "・" & _
                            CellText(data(r, 4)) & "。" & CellText(data(r, 16)), WORKSPACE_TEXT_LIMIT)
        constraints(itemIndex) = WorkspaceTrimText("時刻精度: " & CellText(data(r, 5)) & _
                                 " / 起終点差: " & WorkspaceAmountText(data(r, 11)) & _
                                 " / " & CStr(WorkspaceLong(data(r, 7))) & "段・" & _
                                 CStr(WorkspaceLong(data(r, 8))) & "取引", WORKSPACE_TEXT_LIMIT)
        statuses(itemIndex) = WorkspaceStatusOrDefault(data(r, FLOW_ANALYSIS_STATUS_COL))
        memos(itemIndex) = CellText(data(r, FLOW_ANALYSIS_MEMO_COL))
        personClasses(itemIndex) = WorkspaceCandidatePersonClass( _
            txIDs(itemIndex), txPersonByID, txDirectionByID, oneToOneFlags(itemIndex))
        routes(itemIndex) = personClasses(itemIndex) & "｜" & routes(itemIndex)
        RegisterWorkspaceOwners txIDs(itemIndex), itemIndex, parent, owners
    Next r
End Sub

Private Sub LoadWorkspaceTransactionIdentity(ByRef txPersonByID As Object, _
                                             ByRef txDirectionByID As Object)
    Dim ws As Worksheet, lastR As Long, r As Long
    Dim txValues As Variant, personValues As Variant
    Dim withdrawalValues As Variant, depositValues As Variant
    Dim dataCount As Long, txID As String, personID As String, directionText As String
    Dim withdrawal As Double, deposit As Double
    If Not SheetExists(SH_WORK_TX) Then _
        Err.Raise vbObjectError + 4851, "LoadWorkspaceTransactionIdentity", _
                  "W_取引がありません。人物区分を作成できません。"
    Set txPersonByID = CreateObject("Scripting.Dictionary")
    Set txDirectionByID = CreateObject("Scripting.Dictionary")
    txPersonByID.CompareMode = vbTextCompare
    txDirectionByID.CompareMode = vbTextCompare
    Set ws = GetSheet(SH_WORK_TX)
    lastR = LastUsedRowInSheet(ws)
    If lastR < 2 Then Exit Sub
    dataCount = lastR - 1
    txValues = ws.Range(ws.Cells(2, WORK_TX_COL_TRANSACTION_ID), _
                        ws.Cells(lastR, WORK_TX_COL_TRANSACTION_ID)).Value2
    personValues = ws.Range(ws.Cells(2, WORK_TX_COL_PERSON_ID), _
                            ws.Cells(lastR, WORK_TX_COL_PERSON_ID)).Value2
    withdrawalValues = ws.Range(ws.Cells(2, OUT_COL_WITHDRAW), _
                                ws.Cells(lastR, OUT_COL_WITHDRAW)).Value2
    depositValues = ws.Range(ws.Cells(2, OUT_COL_DEPOSIT), _
                             ws.Cells(lastR, OUT_COL_DEPOSIT)).Value2
    For r = 1 To dataCount
        txID = CellText(WorkspaceColumnArrayValue(txValues, r, dataCount))
        If Len(txID) > 0 Then
            If Not IsInternalIdValue(txID, "T") Then _
                Err.Raise vbObjectError + 4852, "LoadWorkspaceTransactionIdentity", _
                          "W_取引 " & CStr(r + 1) & "行目の取引ID形式が不正です: " & txID
            personID = CellText(WorkspaceColumnArrayValue(personValues, r, dataCount))
            If Len(personID) = 0 Then _
                Err.Raise vbObjectError + 4853, "LoadWorkspaceTransactionIdentity", _
                          "W_取引 " & CStr(r + 1) & _
                          "行目に人物IDがありません。氏名では代替しません。"
            If Not IsInternalIdValue(personID, "P") Then _
                Err.Raise vbObjectError + 4854, "LoadWorkspaceTransactionIdentity", _
                          "W_取引 " & CStr(r + 1) & "行目の人物ID形式が不正です: " & personID
            withdrawal = WorkspaceDouble( _
                WorkspaceColumnArrayValue(withdrawalValues, r, dataCount))
            deposit = WorkspaceDouble( _
                WorkspaceColumnArrayValue(depositValues, r, dataCount))
            If withdrawal > 0 And deposit <= 0 Then
                directionText = "W"
            ElseIf deposit > 0 And withdrawal <= 0 Then
                directionText = "D"
            Else
                Err.Raise vbObjectError + 4855, "LoadWorkspaceTransactionIdentity", _
                          "W_取引 " & CStr(r + 1) & _
                          "行目の出入金区分を1つに確定できません: " & txID
            End If
            If txPersonByID.Exists(txID) Then
                If StrComp(CellText(txPersonByID(txID)), personID, vbTextCompare) <> 0 Or _
                   StrComp(CellText(txDirectionByID(txID)), directionText, vbBinaryCompare) <> 0 Then _
                    Err.Raise vbObjectError + 4856, "LoadWorkspaceTransactionIdentity", _
                              "同じ取引IDに異なる人物または出入金区分があります: " & txID
            Else
                txPersonByID.Add txID, personID
                txDirectionByID.Add txID, directionText
            End If
        End If
    Next r
End Sub

Private Function WorkspaceCandidatePersonClass(ByVal txIDList As String, _
                                               ByVal txPersonByID As Object, _
                                               ByVal txDirectionByID As Object, _
                                               ByRef oneToOne As Boolean) As String
    Dim parts As Variant, item As Variant, txID As String, personID As String
    Dim directionText As String, seenTx() As String, seenPersons() As String
    Dim withdrawalCount As Long, depositCount As Long
    Dim uniqueCount As Long, personCount As Long, i As Long, alreadySeen As Boolean
    oneToOne = False
    If txPersonByID Is Nothing Or txDirectionByID Is Nothing Then _
        Err.Raise vbObjectError + 4857, "WorkspaceCandidatePersonClass", _
                  "取引の人物ID索引がありません。"
    parts = Split(txIDList, ";")
    ReDim seenTx(1 To UBound(parts) - LBound(parts) + 1)
    ReDim seenPersons(1 To UBound(parts) - LBound(parts) + 1)
    For Each item In parts
        txID = Trim$(CStr(item))
        alreadySeen = False
        If Len(txID) > 0 Then
            For i = 1 To uniqueCount
                If StrComp(seenTx(i), txID, vbTextCompare) = 0 Then
                    alreadySeen = True
                    Exit For
                End If
            Next i
        End If
        If Len(txID) > 0 And Not alreadySeen Then
            If Not txPersonByID.Exists(txID) Or Not txDirectionByID.Exists(txID) Then _
                Err.Raise vbObjectError + 4858, "WorkspaceCandidatePersonClass", _
                          "候補の構成取引がW_取引にありません: " & txID
            If Len(CellText(txPersonByID(txID))) = 0 Then _
                Err.Raise vbObjectError + 4859, "WorkspaceCandidatePersonClass", _
                          "候補の構成取引に人物IDがありません: " & txID
            uniqueCount = uniqueCount + 1
            seenTx(uniqueCount) = txID
            personID = CellText(txPersonByID(txID))
            alreadySeen = False
            For i = 1 To personCount
                If StrComp(seenPersons(i), personID, vbTextCompare) = 0 Then
                    alreadySeen = True
                    Exit For
                End If
            Next i
            If Not alreadySeen Then
                personCount = personCount + 1
                seenPersons(personCount) = personID
            End If
            directionText = CellText(txDirectionByID(txID))
            If directionText = "W" Then
                withdrawalCount = withdrawalCount + 1
            ElseIf directionText = "D" Then
                depositCount = depositCount + 1
            Else
                Err.Raise vbObjectError + 4860, "WorkspaceCandidatePersonClass", _
                          "候補の出入金区分が不正です: " & txID
            End If
        End If
    Next item
    If uniqueCount < 2 Or withdrawalCount < 1 Or depositCount < 1 Then _
        Err.Raise vbObjectError + 4861, "WorkspaceCandidatePersonClass", _
                  "候補の構成取引が出金・入金の組合せになっていません。"
    oneToOne = (withdrawalCount = 1 And depositCount = 1)
    If personCount > 1 Then
        WorkspaceCandidatePersonClass = WORKSPACE_PERSON_DIFFERENT
    ElseIf personCount = 1 Then
        WorkspaceCandidatePersonClass = WORKSPACE_PERSON_SAME
    Else
        Err.Raise vbObjectError + 4862, "WorkspaceCandidatePersonClass", _
                  "候補の人物IDを確定できません。"
    End If
End Function

Private Sub RegisterWorkspaceOwners(ByVal idList As String, ByVal itemIndex As Long, _
                                    ByRef parent() As Long, ByVal owners As Object)
    Dim parts As Variant, item As Variant, txID As String
    If Len(idList) = 0 Then Exit Sub
    parts = Split(idList, ";")
    For Each item In parts
        txID = Trim$(CStr(item))
        If Len(txID) > 0 Then
            If owners.Exists(txID) Then
                WorkspaceUnion parent, itemIndex, CLng(owners(txID))
            Else
                owners.Add txID, itemIndex
            End If
        End If
    Next item
End Sub

Private Function WorkspaceFindRoot(ByRef parent() As Long, ByVal itemIndex As Long) As Long
    Dim rootIndex As Long, nextIndex As Long
    rootIndex = itemIndex
    Do While parent(rootIndex) <> rootIndex
        rootIndex = parent(rootIndex)
    Loop
    Do While parent(itemIndex) <> itemIndex
        nextIndex = parent(itemIndex)
        parent(itemIndex) = rootIndex
        itemIndex = nextIndex
    Loop
    WorkspaceFindRoot = rootIndex
End Function

Private Sub WorkspaceUnion(ByRef parent() As Long, ByVal firstIndex As Long, ByVal secondIndex As Long)
    Dim firstRoot As Long, secondRoot As Long
    firstRoot = WorkspaceFindRoot(parent, firstIndex)
    secondRoot = WorkspaceFindRoot(parent, secondIndex)
    If firstRoot = secondRoot Then Exit Sub
    If firstRoot < secondRoot Then
        parent(secondRoot) = firstRoot
    Else
        parent(firstRoot) = secondRoot
    End If
End Sub

Private Function WorkspaceReviewStateRank(ByVal statusText As String) As Long
    Select Case Trim$(statusText)
        Case ANALYSIS_STATUS_SHIFT_CONFIRMED
            WorkspaceReviewStateRank = 4
        Case ANALYSIS_STATUS_FOLLOWUP
            WorkspaceReviewStateRank = 3
        Case ANALYSIS_STATUS_EXCLUDED
            WorkspaceReviewStateRank = 1
        Case Else
            WorkspaceReviewStateRank = 2
    End Select
End Function

Private Function WorkspaceCandidateIsBetterRepresentative( _
        ByVal candidateIndex As Long, ByVal currentIndex As Long, _
        ByRef statuses() As String, ByRef oneToOneFlags() As Boolean, _
        ByRef personClasses() As String, ByRef scores() As Long) As Boolean
    Dim candidateRank As Long, currentRank As Long
    candidateRank = WorkspaceReviewStateRank(statuses(candidateIndex))
    currentRank = WorkspaceReviewStateRank(statuses(currentIndex))
    If candidateRank <> currentRank Then
        WorkspaceCandidateIsBetterRepresentative = (candidateRank > currentRank)
        Exit Function
    End If
    If oneToOneFlags(candidateIndex) <> oneToOneFlags(currentIndex) Then
        WorkspaceCandidateIsBetterRepresentative = oneToOneFlags(candidateIndex)
        Exit Function
    End If
    If personClasses(candidateIndex) <> personClasses(currentIndex) Then
        WorkspaceCandidateIsBetterRepresentative = _
            (personClasses(candidateIndex) = WORKSPACE_PERSON_DIFFERENT)
        Exit Function
    End If
    If scores(candidateIndex) <> scores(currentIndex) Then
        WorkspaceCandidateIsBetterRepresentative = (scores(candidateIndex) > scores(currentIndex))
        Exit Function
    End If
    WorkspaceCandidateIsBetterRepresentative = (candidateIndex < currentIndex)
End Function


Private Sub WriteWorkspaceGroupTable( _
        ByVal ws As Worksheet, ByVal candidateCount As Long, ByRef parent() As Long, _
        ByRef sourceRows() As Long, ByRef scores() As Long, ByRef sourceSheets() As String, _
        ByRef sourceKeys() As String, ByRef txIDs() As String, ByRef categories() As String, _
        ByRef statuses() As String, ByRef memos() As String, ByRef personClasses() As String, _
        ByRef groupCounts() As Long, ByRef representatives() As Long, _
        ByRef groupIDs() As String)
    Dim buffer() As Variant, bufferCount As Long, nextRow As Long
    Dim i As Long, rootIndex As Long, personPass As Long
    ReDim buffer(1 To WORKSPACE_BUFFER_ROWS, 1 To ANALYSIS_GROUP_LAST_COL)
    nextRow = 2
    '代替候補を読むときは別人物間を先にする。スコアと代表フラグは変更しない。
    For personPass = 2 To 1 Step -1
        For i = 1 To candidateCount
            If WorkspaceAlternativePersonOrder(personClasses(i)) = personPass Then
                rootIndex = WorkspaceFindRoot(parent, i)
                bufferCount = bufferCount + 1
                buffer(bufferCount, 1) = groupIDs(rootIndex)
                buffer(bufferCount, 2) = sourceSheets(i)
                buffer(bufferCount, 3) = sourceRows(i)
                buffer(bufferCount, 4) = sourceKeys(i)
                buffer(bufferCount, 5) = txIDs(i)
                buffer(bufferCount, 6) = scores(i)
                If representatives(rootIndex) = i Then buffer(bufferCount, 7) = "代表" Else buffer(bufferCount, 7) = "代替"
                buffer(bufferCount, 8) = categories(i)
                buffer(bufferCount, 9) = statuses(i)
                buffer(bufferCount, 10) = memos(i)
                If bufferCount = WORKSPACE_BUFFER_ROWS Then
                    FlushWorkspaceBuffer ws, buffer, bufferCount, nextRow, ANALYSIS_GROUP_LAST_COL
                    ReDim buffer(1 To WORKSPACE_BUFFER_ROWS, 1 To ANALYSIS_GROUP_LAST_COL)
                    bufferCount = 0
                End If
            End If
        Next i
    Next personPass
    If bufferCount > 0 Then FlushWorkspaceBuffer ws, buffer, bufferCount, nextRow, ANALYSIS_GROUP_LAST_COL
End Sub

Private Function WorkspaceAlternativePersonOrder(ByVal personClass As String) As Long
    If personClass = WORKSPACE_PERSON_DIFFERENT Then
        WorkspaceAlternativePersonOrder = 2
    ElseIf personClass = WORKSPACE_PERSON_SAME Then
        WorkspaceAlternativePersonOrder = 1
    Else
        Err.Raise vbObjectError + 4864, "WorkspaceAlternativePersonOrder", _
                  "代替候補の人物区分が不正です。"
    End If
End Function

Private Sub FillWorkspaceCandidateResult( _
        ByRef buffer() As Variant, ByVal bufferRow As Long, ByVal itemIndex As Long, _
        ByVal alternativeCount As Long, ByVal groupID As String, _
        ByRef sourceRows() As Long, ByRef scores() As Long, ByRef sourceSheets() As String, _
        ByRef sourceKeys() As String, ByRef txIDs() As String, ByRef categories() As String, _
        ByRef datesText() As String, ByRef routes() As String, ByRef points() As String, _
        ByRef constraints() As String, ByRef statuses() As String, ByRef memos() As String, _
        ByRef amounts() As Double)
    Dim constraintText As String
    constraintText = constraints(itemIndex)
    If alternativeCount > 1 Then
        constraintText = WorkspaceAppend(constraintText, "同じ取引を共有する代替仮説 " & _
                         CStr(alternativeCount) & _
                         "件。資金操作表で構成取引と関連取引を切り替えて確認してください。", " / ")
    End If
    buffer(bufferRow, 1) = scores(itemIndex)
    buffer(bufferRow, 2) = categories(itemIndex)
    buffer(bufferRow, 3) = datesText(itemIndex)
    buffer(bufferRow, 4) = amounts(itemIndex)
    buffer(bufferRow, 5) = routes(itemIndex)
    buffer(bufferRow, 6) = points(itemIndex)
    buffer(bufferRow, 7) = WorkspaceTrimText(constraintText, WORKSPACE_TEXT_LIMIT)
    buffer(bufferRow, 8) = statuses(itemIndex)
    buffer(bufferRow, 9) = memos(itemIndex)
    buffer(bufferRow, 10) = sourceSheets(itemIndex)
    buffer(bufferRow, 11) = sourceKeys(itemIndex)
    buffer(bufferRow, 12) = groupID
    buffer(bufferRow, 13) = sourceRows(itemIndex)
    buffer(bufferRow, 14) = txIDs(itemIndex)
    buffer(bufferRow, 15) = alternativeCount
End Sub

Private Sub WriteWorkspaceUnknownResults(ByVal wsUnknown As Worksheet, ByVal wsResult As Worksheet, _
                                         ByRef outputTotal As Long, ByVal unknownCount As Long, _
                                         ByVal wsGroup As Worksheet)
    Dim data As Variant, resultBuffer() As Variant, groupBuffer() As Variant
    Dim resultBufferCount As Long, groupBufferCount As Long
    Dim nextResultRow As Long, nextGroupRow As Long
    Dim r As Long, categoryText As String, txID As String, groupID As String
    Dim amountValue As Double, timeText As String, routeText As String
    nextResultRow = outputTotal + 2
    nextGroupRow = LastUsedRowInSheet(wsGroup) + 1
    If nextGroupRow < 2 Then nextGroupRow = 2
    ReDim resultBuffer(1 To WORKSPACE_BUFFER_ROWS, 1 To ANALYSIS_RESULT_LAST_COL)
    ReDim groupBuffer(1 To WORKSPACE_BUFFER_ROWS, 1 To ANALYSIS_GROUP_LAST_COL)
    data = wsUnknown.Range(wsUnknown.Cells(2, 1), _
                           wsUnknown.Cells(unknownCount + 1, UNKNOWN_ANALYSIS_LAST_COL)).Value2
    For r = 1 To unknownCount
        txID = CellText(data(r, 24))
        groupID = "U-" & WorkspaceDigest(txID & "|" & CellText(data(r, 26)))
        If StrComp(CellText(data(r, 3)), "原資不明候補", vbTextCompare) = 0 Then
            categoryText = "原資不明"
            amountValue = WorkspaceDouble(data(r, 13))
        Else
            categoryText = "使途不明"
            amountValue = WorkspaceDouble(data(r, 14))
        End If
        timeText = WorkspaceTimeText(data(r, 5))
        routeText = WorkspacePartyAccount(data(r, 7), data(r, 8), data(r, 9), _
                    data(r, 10), data(r, 11), data(r, 12))
        resultBufferCount = resultBufferCount + 1
        resultBuffer(resultBufferCount, 1) = WorkspaceLong(data(r, 2))
        resultBuffer(resultBufferCount, 2) = categoryText
        resultBuffer(resultBufferCount, 3) = WorkspaceDateText(data(r, 4)) & " " & timeText
        resultBuffer(resultBufferCount, 4) = amountValue
        resultBuffer(resultBufferCount, 5) = routeText
        resultBuffer(resultBufferCount, 6) = WorkspaceTrimText(CellText(data(r, 20)), WORKSPACE_TEXT_LIMIT)
        resultBuffer(resultBufferCount, 7) = WorkspaceTrimText( _
            "時刻精度: " & CellText(data(r, 6)) & " / 候補: " & CellText(data(r, 18)) & _
            " / 最高評価: " & CellText(data(r, 19)) & " / 摘要: " & _
            WorkspaceBlankLabel(data(r, 17)), WORKSPACE_TEXT_LIMIT)
        resultBuffer(resultBufferCount, 8) = WorkspaceStatusOrDefault(data(r, 21))
        resultBuffer(resultBufferCount, 9) = CellText(data(r, 22))
        resultBuffer(resultBufferCount, 10) = SH_ANALYSIS_UNKNOWN
        resultBuffer(resultBufferCount, 11) = CellText(data(r, 26))
        resultBuffer(resultBufferCount, 12) = groupID
        resultBuffer(resultBufferCount, 13) = r + 1
        resultBuffer(resultBufferCount, 14) = txID
        resultBuffer(resultBufferCount, 15) = 1

        groupBufferCount = groupBufferCount + 1
        groupBuffer(groupBufferCount, 1) = groupID
        groupBuffer(groupBufferCount, 2) = SH_ANALYSIS_UNKNOWN
        groupBuffer(groupBufferCount, 3) = r + 1
        groupBuffer(groupBufferCount, 4) = CellText(data(r, 26))
        groupBuffer(groupBufferCount, 5) = txID
        groupBuffer(groupBufferCount, 6) = WorkspaceLong(data(r, 2))
        groupBuffer(groupBufferCount, 7) = "代表"
        groupBuffer(groupBufferCount, 8) = categoryText
        groupBuffer(groupBufferCount, 9) = WorkspaceStatusOrDefault(data(r, 21))
        groupBuffer(groupBufferCount, 10) = CellText(data(r, 22))
        outputTotal = outputTotal + 1

        If resultBufferCount = WORKSPACE_BUFFER_ROWS Then
            FlushWorkspaceBuffer wsResult, resultBuffer, resultBufferCount, nextResultRow, ANALYSIS_RESULT_LAST_COL
            ReDim resultBuffer(1 To WORKSPACE_BUFFER_ROWS, 1 To ANALYSIS_RESULT_LAST_COL)
            resultBufferCount = 0
        End If
        If groupBufferCount = WORKSPACE_BUFFER_ROWS Then
            FlushWorkspaceBuffer wsGroup, groupBuffer, groupBufferCount, nextGroupRow, ANALYSIS_GROUP_LAST_COL
            ReDim groupBuffer(1 To WORKSPACE_BUFFER_ROWS, 1 To ANALYSIS_GROUP_LAST_COL)
            groupBufferCount = 0
        End If
    Next r
    If resultBufferCount > 0 Then _
        FlushWorkspaceBuffer wsResult, resultBuffer, resultBufferCount, nextResultRow, ANALYSIS_RESULT_LAST_COL
    If groupBufferCount > 0 Then _
        FlushWorkspaceBuffer wsGroup, groupBuffer, groupBufferCount, nextGroupRow, ANALYSIS_GROUP_LAST_COL
End Sub

Private Sub FlushWorkspaceBuffer(ByVal ws As Worksheet, ByRef buffer() As Variant, _
                                 ByVal bufferCount As Long, ByRef nextRow As Long, _
                                 ByVal columnCount As Long)
    Dim outputData() As Variant, r As Long, c As Long
    If bufferCount <= 0 Then Exit Sub
    ReDim outputData(1 To bufferCount, 1 To columnCount)
    For r = 1 To bufferCount
        For c = 1 To columnCount
            outputData(r, c) = buffer(r, c)
        Next c
    Next r
    ws.Range(ws.Cells(nextRow, 1), ws.Cells(nextRow + bufferCount - 1, columnCount)).Value = outputData
    nextRow = nextRow + bufferCount
End Sub

Private Sub FinalizeAnalysisResultSheet(ByVal ws As Worksheet, ByVal dataCount As Long)
    Dim lastR As Long
    lastR = dataCount + 1
    ws.Unprotect Password:=TOOL_PASSWORD
    FormatOutputHeader ws.Range(ws.Cells(1, 1), ws.Cells(1, ANALYSIS_RESULT_LAST_COL))
    ApplyAnalysisResultColumnWidths ws
    ws.Rows(1).RowHeight = 52
    ws.Columns("J:O").Hidden = True
    If dataCount > 0 Then
        With ws.Range(ws.Cells(2, 1), ws.Cells(lastR, ANALYSIS_RESULT_VISIBLE_COL))
            .VerticalAlignment = xlTop
            .WrapText = True
        End With
        With ws.Range(ws.Cells(2, 1), ws.Cells(lastR, 4))
            .VerticalAlignment = xlCenter
        End With
        ws.Range(ws.Cells(2, 1), ws.Cells(lastR, 3)).HorizontalAlignment = xlCenter
        ws.Range(ws.Cells(2, 4), ws.Cells(lastR, 4)).HorizontalAlignment = xlRight
        ws.Range(ws.Cells(2, ANALYSIS_RESULT_STATUS_COL), _
                 ws.Cells(lastR, ANALYSIS_RESULT_STATUS_COL)).HorizontalAlignment = xlCenter
        ws.Range(ws.Cells(2, 1), ws.Cells(lastR, 1)).Font.Bold = True
        ws.Range(ws.Cells(2, ANALYSIS_RESULT_STATUS_COL), _
                 ws.Cells(lastR, ANALYSIS_RESULT_MEMO_COL)).Interior.Color = RGB(254, 249, 195)
        With ws.Range(ws.Cells(2, 1), ws.Cells(lastR, 7)).FormatConditions
            .Delete
            .Add Type:=xlExpression, Formula1:="=MOD(ROW(),2)=0"
            .Item(.Count).Interior.Color = RGB(248, 250, 252)
        End With
        ws.Rows("2:" & CStr(lastR)).RowHeight = 62
        SortAnalysisResult ws, lastR
    End If
    If ws.AutoFilterMode Then ws.AutoFilterMode = False
    ws.Range(ws.Cells(1, 1), ws.Cells(lastR, ANALYSIS_RESULT_LAST_COL)).AutoFilter
    ws.ScrollArea = "A1:I" & CStr(Application.Max(50, lastR + 20))
    ApplyWorkspaceReviewValidation ws, lastR
    AddManualBuilderHint ws
    SafeFreezeSheetAt ws, "A2", 85
    ProtectSingleAnalysisSheet ws
End Sub

Private Sub AddManualBuilderHint(ByVal ws As Worksheet)
    Dim i As Long
    Dim x As Double, y As Double, w As Double
    Dim errorNumber As Long, errorDescription As String
    If ws Is Nothing Then Exit Sub
    On Error GoTo EH
    For i = ws.Shapes.Count To 1 Step -1
        If ToolShapeActionName(ws.Shapes(i)) = "OpenManualAnalysisCandidateBuilder" Then _
            ws.Shapes(i).Delete
    Next i
    If Not ws.Cells(1, 1).Comment Is Nothing Then ws.Cells(1, 1).Comment.Delete
    ws.Cells(1, 1).AddComment _
        "自動候補にない資金移動は、見出し上のボタンまたは見出し行のダブルクリックから作成できます。" & _
        vbCrLf & "全取引から出金・入金を複数選択できます。"
    ws.Cells(1, 1).Comment.Visible = False
    '見出しの上半分を小さなツールバーとして使い、隠し操作だった手動候補作成を明示する。
    ws.Range("A1:I1").VerticalAlignment = xlBottom
    x = ws.Range("F1").Left + 3
    y = ws.Range("F1").Top + 2
    w = ws.Range("F1:I1").Width - 6
    AddUIButton ws, x, y, w, 20, "＋ 手動候補を作成", _
                "OpenManualAnalysisCandidateBuilder", "tool"
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    Err.Raise errorNumber, "AddManualBuilderHint", errorDescription
End Sub

Private Sub ApplyAnalysisResultColumnWidths(ByVal ws As Worksheet)
    ws.Columns("A:A").ColumnWidth = 9
    ws.Columns("B:B").ColumnWidth = 12
    ws.Columns("C:C").ColumnWidth = 16
    ws.Columns("D:D").ColumnWidth = 13
    ws.Columns("E:E").ColumnWidth = 23
    ws.Columns("F:F").ColumnWidth = 28
    ws.Columns("G:G").ColumnWidth = 24
    ws.Columns("H:H").ColumnWidth = 14
    ws.Columns("I:I").ColumnWidth = 22
End Sub

Private Sub SortAnalysisResult(ByVal ws As Worksheet, ByVal lastR As Long)
    Dim sourceData As Variant, familyData() As Variant, personPriorityData() As Variant
    Dim r As Long, categoryText As String, routeText As String, constraintText As String
    Dim errorNumber As Long, errorDescription As String
    If lastR < 2 Then Exit Sub
    On Error GoTo EH
    sourceData = ws.Range(ws.Cells(2, 2), ws.Cells(lastR, 7)).Value2
    ReDim familyData(1 To lastR - 1, 1 To 1)
    ReDim personPriorityData(1 To lastR - 1, 1 To 1)
    For r = 1 To lastR - 1
        categoryText = CellText(sourceData(r, 1))
        routeText = CellText(sourceData(r, 4))
        constraintText = CellText(sourceData(r, 6))
        familyData(r, 1) = WorkspaceResultCategoryRank(categoryText)
        If categoryText = "資金シフト" Or categoryText = "資金フロー" Then
            personPriorityData(r, 1) = WorkspaceResultPersonPriority(routeText, constraintText)
        Else
            personPriorityData(r, 1) = 0
        End If
    Next r
    ws.Range("P1").Value2 = "内部区分順"
    ws.Range("Q1").Value2 = "内部人物順"
    ws.Range(ws.Cells(2, 16), ws.Cells(lastR, 16)).Value2 = familyData
    ws.Range(ws.Cells(2, 17), ws.Cells(lastR, 17)).Value2 = personPriorityData
    With ws.Sort
        .SortFields.Clear
        .SortFields.Add Key:=ws.Range(ws.Cells(2, 16), ws.Cells(lastR, 16)), _
                        SortOn:=xlSortOnValues, Order:=xlAscending, DataOption:=xlSortNormal
        .SortFields.Add Key:=ws.Range(ws.Cells(2, 17), ws.Cells(lastR, 17)), _
                        SortOn:=xlSortOnValues, Order:=xlDescending, DataOption:=xlSortNormal
        .SortFields.Add Key:=ws.Range(ws.Cells(2, 1), ws.Cells(lastR, 1)), _
                        SortOn:=xlSortOnValues, Order:=xlDescending, DataOption:=xlSortNormal
        .SortFields.Add Key:=ws.Range(ws.Cells(2, 2), ws.Cells(lastR, 2)), _
                        SortOn:=xlSortOnValues, Order:=xlAscending, DataOption:=xlSortNormal
        .SortFields.Add Key:=ws.Range(ws.Cells(2, 3), ws.Cells(lastR, 3)), _
                        SortOn:=xlSortOnValues, Order:=xlAscending, DataOption:=xlSortNormal
        .SetRange ws.Range(ws.Cells(1, 1), ws.Cells(lastR, 17))
        .Header = xlYes
        .Apply
    End With
    ws.Range(ws.Cells(1, 16), ws.Cells(lastR, 17)).ClearContents
    ws.Columns("P:Q").Hidden = True
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    On Error Resume Next
    ws.Range(ws.Cells(1, 16), ws.Cells(Application.Max(1, lastR), 17)).ClearContents
    ws.Columns("P:Q").Hidden = True
    On Error GoTo 0
    Err.Raise errorNumber, "SortAnalysisResult", errorDescription
End Sub

Private Function WorkspaceResultCategoryRank(ByVal categoryText As String) As Long
    Select Case categoryText
        Case "資金シフト", "資金フロー"
            WorkspaceResultCategoryRank = 1
        Case "原資不明"
            WorkspaceResultCategoryRank = 2
        Case "使途不明"
            WorkspaceResultCategoryRank = 3
        Case Else
            WorkspaceResultCategoryRank = 9
    End Select
End Function

Private Function WorkspaceResultPersonPriority(ByVal routeText As String, _
                                               ByVal constraintText As String) As Long
    WorkspaceResultPersonPriority = WorkspaceRoutePersonPriority(routeText)
    If WorkspaceResultPersonPriority < 2 And _
       InStr(1, constraintText, "別人物間の代替候補あり", vbBinaryCompare) > 0 Then _
        WorkspaceResultPersonPriority = 2
End Function

Private Function WorkspaceRoutePersonPriority(ByVal routeText As String) As Long
    If Left$(routeText, Len(WORKSPACE_PERSON_DIFFERENT) + 1) = _
       WORKSPACE_PERSON_DIFFERENT & "｜" Then
        WorkspaceRoutePersonPriority = 2
    ElseIf Left$(routeText, Len(WORKSPACE_PERSON_SAME) + 1) = _
           WORKSPACE_PERSON_SAME & "｜" Then
        WorkspaceRoutePersonPriority = 1
    Else
        Err.Raise vbObjectError + 4863, "WorkspaceRoutePersonPriority", _
                  "資金移動候補に人物区分がありません。再分析してください。"
    End If
End Function

Private Sub ApplyWorkspaceReviewValidation(ByVal ws As Worksheet, ByVal lastR As Long)
    Dim statusRange As Range, memoRange As Range
    ws.Cells.Locked = True
    If lastR < 2 Then Exit Sub
    Set statusRange = ws.Range(ws.Cells(2, ANALYSIS_RESULT_STATUS_COL), _
                               ws.Cells(lastR, ANALYSIS_RESULT_STATUS_COL))
    Set memoRange = ws.Range(ws.Cells(2, ANALYSIS_RESULT_MEMO_COL), _
                             ws.Cells(lastR, ANALYSIS_RESULT_MEMO_COL))
    statusRange.Locked = False
    memoRange.Locked = False
    With statusRange.Validation
        .Delete
        .Add Type:=xlValidateList, AlertStyle:=xlValidAlertStop, Operator:=xlBetween, _
             Formula1:="=INDIRECT(IF(OR($B2=""資金シフト"",$B2=""資金フロー""),""" & _
                      NM_LST_ANALYSIS_SHIFT_STATUS & """,IF($B2=""原資不明"",""" & _
                      NM_LST_ANALYSIS_SOURCE_STATUS & """,""" & NM_LST_ANALYSIS_USE_STATUS & """)))"
        .IgnoreBlank = True
        .InCellDropdown = True
        .ShowError = True
        .ErrorTitle = "確認状況を選択してください"
        .ErrorMessage = "行の区分に対応する確認状況を選択してください。"
    End With
    With memoRange.Validation
        .Delete
        .Add Type:=xlValidateTextLength, AlertStyle:=xlValidAlertStop, _
             Operator:=xlLessEqual, Formula1:=CStr(WORKSPACE_MEMO_MAX)
        .IgnoreBlank = True
        .ShowError = True
        .ErrorTitle = "確認メモの文字数を確認してください"
        .ErrorMessage = "確認メモは" & CStr(WORKSPACE_MEMO_MAX) & "文字以内で入力してください。"
    End With
End Sub

Public Sub SetAnalysisReviewEditingEnabled(ByVal enabled As Boolean)
    Dim ws As Worksheet, lastR As Long, r As Long
    Dim workbookWasSaved As Boolean, emergencyProtected As Boolean
    Dim previousEvents As Boolean, eventsCaptured As Boolean
    Dim eventsStopped As Boolean
    Dim normalProtectionConfirmed As Boolean
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim emergencyErrorNumber As Long, emergencyErrorDescription As String
    Dim emergencyReadErrorNumber As Long, emergencyReadErrorDescription As String
    Dim savedErrorNumber As Long, savedErrorDescription As String
    Dim recoveryStateConfirmed As Boolean
    Dim recoveryAttempted As Boolean, recoveryTerminalFailure As Boolean
    Dim eventStateDetail As String, convergenceDetail As String
    Dim recoveryDetail As String
    workbookWasSaved = ThisWorkbook.Saved
    On Error GoTo EH
    If Not TryGetAnalysisWorkspaceEnableEvents( _
               previousEvents, eventStateDetail) Then _
        Err.Raise vbObjectError + 4897, "SetAnalysisReviewEditingEnabled", _
                  "Excelイベントの開始状態を取得できません。 " & eventStateDetail
    eventsCaptured = True
    If Not TrySetAnalysisWorkspaceEnableEventsExact(False, eventStateDetail) Then _
        Err.Raise vbObjectError + 4898, "SetAnalysisReviewEditingEnabled", _
                  "編集可否の変更前にExcelイベントを停止できませんでした。 " & _
                  eventStateDetail
    eventsStopped = True
    normalProtectionConfirmed = True
    If SheetExists(SH_ANALYSIS_RESULT) Then
        Set ws = GetSheet(SH_ANALYSIS_RESULT)
        ws.Unprotect Password:=TOOL_PASSWORD
        lastR = LastUsedRowInSheet(ws)
        If enabled Then
            ApplyWorkspaceReviewValidation ws, lastR
        Else
            ws.Range(ws.Cells(1, 1), _
                     ws.Cells(Application.Max(50, lastR + 20), ANALYSIS_RESULT_LAST_COL)).Locked = True
        End If
        ProtectSingleAnalysisSheet ws
        normalProtectionConfirmed = _
            ws.ProtectContents And ws.ProtectDrawingObjects
        If Not normalProtectionConfirmed Then _
            Err.Raise vbObjectError + 4899, "SetAnalysisReviewEditingEnabled", _
                      ws.Name & "のセル・図形保護を読戻し確認できません。"
    End If
    If SheetExists(SH_ANALYSIS_DETAIL) Then
        Set ws = GetSheet(SH_ANALYSIS_DETAIL)
        ws.Unprotect Password:=TOOL_PASSWORD
        lastR = LastUsedRowInSheet(ws)
        ws.Range(ws.Cells(1, 1), _
                 ws.Cells(Application.Max(50, lastR + 20), DETAIL_COL_KIND)).Locked = True
        If enabled Then
            For r = 2 To lastR
                If CellText(ws.Cells(r, DETAIL_COL_KIND).Value) = "候補" Then
                    ws.Cells(r, 6).Locked = False
                ElseIf CellText(ws.Cells(r, DETAIL_COL_KIND).Value) = "候補メモ" Then
                    ws.Range(ws.Cells(r, 2), ws.Cells(r, 7)).Locked = False
                End If
            Next r
        End If
        ProtectSingleAnalysisSheet ws
        normalProtectionConfirmed = _
            normalProtectionConfirmed And _
            ws.ProtectContents And ws.ProtectDrawingObjects
        If Not normalProtectionConfirmed Then _
            Err.Raise vbObjectError + 4899, "SetAnalysisReviewEditingEnabled", _
                      ws.Name & "のセル・図形保護を読戻し確認できません。"
    End If
    If workbookWasSaved And normalProtectionConfirmed Then _
        ThisWorkbook.Saved = True
    If Not TryRestoreAnalysisWorkspaceEnableEvents( _
               previousEvents, _
               "SetAnalysisReviewEditingEnabled/正常終了", _
               recoveryAttempted, recoveryTerminalFailure, _
               eventStateDetail) Then
        eventsCaptured = False
        If Not TryStopAnalysisWorkspaceEventsForBookWrites(convergenceDetail) Then
            AppendAnalysisWorkspaceRollbackDetail eventStateDetail, _
                "イベント状態をFalseへ安全収束できません: " & convergenceDetail
        Else
            AppendAnalysisWorkspaceRollbackDetail eventStateDetail, _
                "開始状態の復元失敗後、イベント状態をFalseへ安全収束しました。"
        End If
        On Error GoTo 0
        If recoveryAttempted Or recoveryTerminalFailure Then _
            RaiseAnalysisWorkspaceLocalRecoveryFatal _
                "SetAnalysisReviewEditingEnabled", _
                vbObjectError + 4900, _
                "SetAnalysisReviewEditingEnabled", eventStateDetail, _
                eventStateDetail
        Err.Raise vbObjectError + 4900, "SetAnalysisReviewEditingEnabled", _
                  eventStateDetail
    End If
    eventsCaptured = False
    If recoveryAttempted Or recoveryTerminalFailure Then _
        RaiseAnalysisWorkspaceLocalRecoveryFatal _
            "SetAnalysisReviewEditingEnabled", _
            vbObjectError + 4900, "SetAnalysisReviewEditingEnabled", _
            "開始値の復元時にlocal Recoveryを実行しました。", _
            eventStateDetail
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    If IsAnalysisWorkspaceRecoveryFatalError(errorNumber, errorSource) Then _
        RethrowAnalysisWorkspaceUpstreamRecoveryFatal _
            errorNumber, errorSource, errorDescription, _
            "SetAnalysisReviewEditingEnabled"
    If eventsCaptured Then
        eventsStopped = _
            TryStopAnalysisWorkspaceEventsForBookWrites(eventStateDetail)
    Else
        eventsStopped = False
        eventStateDetail = _
            "Excelイベントの開始値を取得できていないため、緊急再保護を開始していません。"
    End If
    If eventsStopped And Not ws Is Nothing Then
        On Error Resume Next
        Err.Clear
        EmergencyProtectToolSheet ws
        emergencyErrorNumber = Err.Number
        emergencyErrorDescription = Err.Description
        Err.Clear
        emergencyProtected = ws.ProtectContents And ws.ProtectDrawingObjects
        emergencyReadErrorNumber = Err.Number
        emergencyReadErrorDescription = Err.Description
        Err.Clear
        On Error GoTo 0
        emergencyProtected = emergencyProtected And _
                             (emergencyErrorNumber = 0) And _
                             (emergencyReadErrorNumber = 0)
    ElseIf Not eventsStopped Then
        emergencyProtected = False
        AppendAnalysisWorkspaceRollbackDetail errorDescription, _
            "Excelイベント停止をexact確認できないため、緊急再保護を実行していません: " & _
            eventStateDetail
    Else
        emergencyProtected = False
        AppendAnalysisWorkspaceRollbackDetail errorDescription, _
            "緊急再保護する分析シートを取得できません。"
    End If
    If Not emergencyProtected Then
        If emergencyErrorNumber <> 0 Then _
            AppendAnalysisWorkspaceRollbackDetail errorDescription, _
                "緊急再保護 Err " & CStr(emergencyErrorNumber) & " " & _
                emergencyErrorDescription
        If emergencyReadErrorNumber <> 0 Then _
            AppendAnalysisWorkspaceRollbackDetail errorDescription, _
                "保護読戻し Err " & CStr(emergencyReadErrorNumber) & " " & _
                emergencyReadErrorDescription
        If emergencyErrorNumber = 0 And emergencyReadErrorNumber = 0 And _
           eventsStopped And Not ws Is Nothing Then _
            AppendAnalysisWorkspaceRollbackDetail errorDescription, _
                "緊急再保護後のセル・図形保護を両方Trueとして確認できません。"
    End If
    If Not emergencyProtected Then
        '保護を厳密確認できない場合は、False exact下でRecoveryを確定する。
        'Recoveryが確定してもこの経路では開始値Trueへ戻さず、イベントを停止したままにする。
        If eventsStopped Then
            recoveryDetail = errorDescription
            recoveryStateConfirmed = _
                StopAfterAnalysisWorkspaceEventStateFailure( _
                    "SetAnalysisReviewEditingEnabled/緊急再保護", _
                    recoveryDetail, recoveryAttempted, _
                    recoveryTerminalFailure, errorNumber, errorSource, _
                    errorDescription)
            If recoveryStateConfirmed Then
                AppendAnalysisWorkspaceRollbackDetail recoveryDetail, _
                    "緊急再保護未確認のため、Recovery確定後もイベントを再開しません。"
            Else
                AppendAnalysisWorkspaceRollbackDetail recoveryDetail, _
                    "緊急再保護もRecoveryも厳密確認できないため、イベントを再開しません。"
            End If
            AppendAnalysisWorkspaceRollbackDetail errorDescription, recoveryDetail
            If Not TryStopAnalysisWorkspaceEventsForBookWrites( _
                       convergenceDetail) Then
                AppendAnalysisWorkspaceRollbackDetail errorDescription, _
                    "イベント状態をFalseへ安全収束できません: " & _
                    convergenceDetail
            Else
                AppendAnalysisWorkspaceRollbackDetail errorDescription, _
                    "緊急再保護未確認のためExcelイベントをFalseのまま停止しました。"
            End If
        End If
        eventsCaptured = False
    Else
        If workbookWasSaved Then
            On Error Resume Next
            Err.Clear
            ThisWorkbook.Saved = True
            savedErrorNumber = Err.Number
            savedErrorDescription = Err.Description
            Err.Clear
            On Error GoTo 0
            If savedErrorNumber <> 0 Then _
                AppendAnalysisWorkspaceRollbackDetail errorDescription, _
                    "保護成立後の保存状態復元 Err " & CStr(savedErrorNumber) & _
                    " " & savedErrorDescription
        End If
        If eventsCaptured Then
            If Not TryRestoreAnalysisWorkspaceEnableEvents( _
                       previousEvents, _
                       "SetAnalysisReviewEditingEnabled/緊急再保護", _
                       recoveryAttempted, recoveryTerminalFailure, _
                       eventStateDetail) Then
                AppendAnalysisWorkspaceRollbackDetail errorDescription, _
                    eventStateDetail
                If Not TryStopAnalysisWorkspaceEventsForBookWrites( _
                           convergenceDetail) Then
                    AppendAnalysisWorkspaceRollbackDetail errorDescription, _
                        "イベント状態をFalseへ安全収束できません: " & _
                        convergenceDetail
                Else
                    AppendAnalysisWorkspaceRollbackDetail errorDescription, _
                        "開始状態の復元失敗後、イベント状態をFalseへ安全収束しました。"
                End If
            End If
            eventsCaptured = False
        End If
    End If
    If recoveryAttempted Or recoveryTerminalFailure Then _
        RaiseAnalysisWorkspaceLocalRecoveryFatal _
            "SetAnalysisReviewEditingEnabled", errorNumber, errorSource, _
            errorDescription, recoveryDetail & " / " & eventStateDetail
    Err.Raise errorNumber, "SetAnalysisReviewEditingEnabled", _
              IIf(Len(errorSource) > 0, _
                  errorSource & " / ", vbNullString) & errorDescription
End Sub

Public Sub RequireAnalysisReviewConstantRange(ByVal target As Range, ByVal labelText As String)
    Dim formulaCell As Range, errorCell As Range
    Dim area As Range, chunk As Range, cell As Range
    Dim rowOffset As Long, chunkRows As Long
    Dim prefixState As Variant, prefixError As Long, scanCells As Boolean
    Const PREFIX_CHECK_ROWS As Long = 500
    If target Is Nothing Then _
        Err.Raise vbObjectError + 4830, "RequireAnalysisReviewConstantRange", _
                  labelText & "を取得できません。"
    If Not TryFindFirstFormulaCell(target, formulaCell) Then _
        Err.Raise vbObjectError + 4831, "RequireAnalysisReviewConstantRange", _
                  labelText & "の数式検査に失敗しました。"
    If Not formulaCell Is Nothing Then _
        Err.Raise vbObjectError + 4831, "RequireAnalysisReviewConstantRange", _
                  labelText & "に数式があります: " & formulaCell.Address(False, False)
    If Not TryFindFirstErrorConstantCell(target, errorCell) Then _
        Err.Raise vbObjectError + 4832, "RequireAnalysisReviewConstantRange", _
                  labelText & "のExcelエラー検査に失敗しました。"
    If Not errorCell Is Nothing Then _
        Err.Raise vbObjectError + 4832, "RequireAnalysisReviewConstantRange", _
                  labelText & "にExcelエラーがあります: " & errorCell.Address(False, False)

    For Each area In target.Areas
        rowOffset = 0
        Do While rowOffset < area.Rows.Count
            chunkRows = CLng(Application.Min(PREFIX_CHECK_ROWS, _
                                             area.Rows.Count - rowOffset))
            Set chunk = area.Rows(rowOffset + 1).Resize(chunkRows, area.Columns.Count)
            scanCells = False
            On Error Resume Next
            Err.Clear
            prefixState = chunk.PrefixCharacter
            prefixError = Err.Number
            Err.Clear
            On Error GoTo 0
            If prefixError <> 0 Or IsNull(prefixState) Then
                scanCells = True
            ElseIf Len(CStr(prefixState)) > 0 Then
                scanCells = True
            End If
            If scanCells Then
                On Error GoTo PrefixInspectionError
                For Each cell In chunk.Cells
                    If Len(CStr(cell.PrefixCharacter)) > 0 Then _
                        Err.Raise vbObjectError + 4833, _
                                  "RequireAnalysisReviewConstantRange", _
                                  labelText & "に先頭アポストロフィ付きの値があります: " & _
                                  cell.Address(False, False)
                Next cell
                On Error GoTo 0
            End If
            rowOffset = rowOffset + chunkRows
        Loop
    Next area
    Exit Sub
PrefixInspectionError:
    If Err.Number = vbObjectError + 4833 Then
        Err.Raise Err.Number, "RequireAnalysisReviewConstantRange", Err.Description
    Else
        Err.Raise vbObjectError + 4833, "RequireAnalysisReviewConstantRange", _
                  labelText & "の先頭アポストロフィ検査に失敗しました。"
    End If
End Sub

Private Sub CaptureAnalysisSourceReviewSnapshots(ByRef snapshots() As Variant, _
                                                 ByRef lastRows() As Long)
    Dim i As Long, sourceName As String
    Dim ws As Worksheet, lastR As Long
    Dim statusCol As Long, memoCol As Long, keyCol As Long
    Dim reviewRange As Range, validationRange As Range
    For i = 1 To 3
        sourceName = AnalysisSourceNameByIndex(i)
        If Not WorkspaceSourceColumns(sourceName, statusCol, memoCol, keyCol) Then _
            Err.Raise vbObjectError + 4834, "CaptureAnalysisSourceReviewSnapshots", _
                      "分析元表の列定義が不正です: " & sourceName
        Set ws = GetSheet(sourceName)
        If Not TryGetLastUsedRowInSheet(ws, lastR) Then _
            Err.Raise vbObjectError + 4834, "CaptureAnalysisSourceReviewSnapshots", _
                      sourceName & "の最終行を確認できません。"
        If lastR - 1 > MAX_ANALYSIS_OUTPUT_ROWS Then _
            Err.Raise vbObjectError + 4835, "CaptureAnalysisSourceReviewSnapshots", _
                      sourceName & "の確認記録が実用上限を超えています。"
        lastRows(i) = lastR
        snapshots(i) = Empty
        If lastR >= 2 Then
            Set reviewRange = ws.Range(ws.Cells(2, statusCol), _
                                       ws.Cells(lastR, memoCol))
            Set validationRange = Union(reviewRange, _
                ws.Range(ws.Cells(2, keyCol), ws.Cells(lastR, keyCol)))
            RequireAnalysisReviewConstantRange validationRange, _
                sourceName & "の確認欄または内部キー"
            snapshots(i) = reviewRange.Value2
            If Not RangeValue2MatchesMatrixStrict( _
                       reviewRange, snapshots(i), lastR - 1, 2) Then _
                Err.Raise vbObjectError + 4836, _
                          "CaptureAnalysisSourceReviewSnapshots", _
                          sourceName & "の確認記録を型まで厳密に退避できません。"
        End If
    Next i
End Sub

Private Function RestoreAnalysisSourceReviewSnapshots( _
        ByRef snapshots() As Variant, ByRef lastRows() As Long, _
        ByRef detailText As String) As Boolean
    Dim i As Long, sourceName As String, oneDetail As String
    Dim allOK As Boolean
    allOK = True
    For i = 1 To 3
        sourceName = AnalysisSourceNameByIndex(i)
        oneDetail = vbNullString
        If Not RestoreOneAnalysisSourceReviewSnapshot( _
                   sourceName, snapshots(i), lastRows(i), oneDetail) Then
            allOK = False
            AppendAnalysisWorkspaceRollbackDetail detailText, oneDetail
        End If
    Next i
    RestoreAnalysisSourceReviewSnapshots = allOK
End Function

Private Function RestoreOneAnalysisSourceReviewSnapshot( _
        ByVal sourceName As String, ByVal snapshot As Variant, _
        ByVal snapshotLastRow As Long, ByRef detailText As String) As Boolean
    Dim ws As Worksheet, currentLastRow As Long
    Dim statusCol As Long, memoCol As Long, keyCol As Long
    Dim target As Range
    On Error GoTo EH
    If Not WorkspaceSourceColumns(sourceName, statusCol, memoCol, keyCol) Then _
        Err.Raise vbObjectError + 4837, "RestoreOneAnalysisSourceReviewSnapshot", _
                  "分析元表の列定義が不正です。"
    Set ws = GetSheet(sourceName)
    If Not TryGetLastUsedRowInSheet(ws, currentLastRow) Then _
        Err.Raise vbObjectError + 4837, "RestoreOneAnalysisSourceReviewSnapshot", _
                  "最終行を確認できません。"
    If currentLastRow <> snapshotLastRow Then _
        Err.Raise vbObjectError + 4838, "RestoreOneAnalysisSourceReviewSnapshot", _
                  "退避後に行数が変化しています。"
    If snapshotLastRow >= 2 Then
        If Not IsArray(snapshot) Then _
            Err.Raise vbObjectError + 4839, "RestoreOneAnalysisSourceReviewSnapshot", _
                      "退避配列がありません。"
        Set target = ws.Range(ws.Cells(2, statusCol), _
                              ws.Cells(snapshotLastRow, memoCol))
        target.Value2 = snapshot
        If Not RangeValue2MatchesMatrixStrict( _
                   target, snapshot, snapshotLastRow - 1, 2) Then _
            Err.Raise vbObjectError + 4840, "RestoreOneAnalysisSourceReviewSnapshot", _
                      "復元読戻しが全セル・型で一致しません。"
        RequireAnalysisReviewConstantRange target, sourceName & "の復元確認欄"
    End If
    RestoreOneAnalysisSourceReviewSnapshot = True
    Exit Function
EH:
    detailText = sourceName & "の復元エラー: " & Err.Description
    Err.Clear
End Function

Private Function AnalysisSourceNameByIndex(ByVal itemIndex As Long) As String
    Select Case itemIndex
        Case 1: AnalysisSourceNameByIndex = SH_ANALYSIS_SHIFT
        Case 2: AnalysisSourceNameByIndex = SH_ANALYSIS_FLOW
        Case 3: AnalysisSourceNameByIndex = SH_ANALYSIS_UNKNOWN
    End Select
End Function

Private Function WriteAnalysisReviewTextCellIfChanged( _
        ByVal target As Range, ByVal textValue As String, _
        ByVal labelText As String) As Boolean
    Dim expectedData As Variant
    ReDim expectedData(1 To 1, 1 To 1)
    If target Is Nothing Then _
        Err.Raise vbObjectError + 4841, "WriteAnalysisReviewTextCellIfChanged", _
                  labelText & "の書込先を取得できません。"
    If target.Cells.CountLarge <> 1 Then _
        Err.Raise vbObjectError + 4841, "WriteAnalysisReviewTextCellIfChanged", _
                  labelText & "の書込先が単一セルではありません。"
    If Len(textValue) = 0 Then
        expectedData(1, 1) = Empty
    Else
        expectedData(1, 1) = CStr(textValue)
    End If
    If StrictVariantValuesMatch(expectedData(1, 1), target.Value2) And _
       Not target.HasFormula And Len(CStr(target.PrefixCharacter)) = 0 Then Exit Function
    target.NumberFormatLocal = "@"
    target.Value2 = expectedData(1, 1)
    If Not RangeValue2MatchesMatrixStrict(target, expectedData, 1, 1) Then _
        Err.Raise vbObjectError + 4842, "WriteAnalysisReviewTextCellIfChanged", _
                  labelText & "の書込読戻しが型まで一致しません。"
    RequireAnalysisReviewConstantRange target, labelText
    WriteAnalysisReviewTextCellIfChanged = True
End Function

Private Sub CaptureAnalysisDetailReviewCellSnapshots( _
        ByVal ws As Worksheet, ByRef statusRows() As Long, ByRef memoRows() As Long, _
        ByVal itemCount As Long, ByRef statusSnapshots() As Variant, _
        ByRef memoSnapshots() As Variant)
    Dim i As Long
    If ws Is Nothing Or itemCount < 1 Then _
        Err.Raise vbObjectError + 4843, "CaptureAnalysisDetailReviewCellSnapshots", _
                  "候補詳細の退避条件が不正です。"
    For i = 1 To itemCount
        statusSnapshots(i) = ws.Cells(statusRows(i), 6).Value2
        memoSnapshots(i) = ws.Cells(memoRows(i), 2).Value2
        If Not StrictVariantValuesMatch( _
                   statusSnapshots(i), ws.Cells(statusRows(i), 6).Value2) Or _
           Not StrictVariantValuesMatch( _
                   memoSnapshots(i), ws.Cells(memoRows(i), 2).Value2) Then _
            Err.Raise vbObjectError + 4844, _
                      "CaptureAnalysisDetailReviewCellSnapshots", _
                      "候補詳細の確認記録を型まで厳密に退避できません。"
    Next i
End Sub

Private Function RestoreAnalysisDetailReviewCellSnapshots( _
        ByVal ws As Worksheet, ByRef statusRows() As Long, ByRef memoRows() As Long, _
        ByVal itemCount As Long, ByRef statusSnapshots() As Variant, _
        ByRef memoSnapshots() As Variant, ByRef detailText As String) As Boolean
    Dim i As Long, expectedData As Variant
    ReDim expectedData(1 To 1, 1 To 1)
    On Error GoTo EH
    If ws Is Nothing Or itemCount < 1 Then _
        Err.Raise vbObjectError + 4845, "RestoreAnalysisDetailReviewCellSnapshots", _
                  "候補詳細の復元条件が不正です。"
    ws.Unprotect Password:=TOOL_PASSWORD
    For i = 1 To itemCount
        expectedData(1, 1) = statusSnapshots(i)
        ws.Cells(statusRows(i), 6).Value2 = expectedData(1, 1)
        If Not RangeValue2MatchesMatrixStrict( _
                   ws.Cells(statusRows(i), 6), expectedData, 1, 1) Then _
            Err.Raise vbObjectError + 4846, _
                      "RestoreAnalysisDetailReviewCellSnapshots", _
                      "候補詳細の確認状況を厳密に復元できません。"
        expectedData(1, 1) = memoSnapshots(i)
        ws.Cells(memoRows(i), 2).Value2 = expectedData(1, 1)
        If Not RangeValue2MatchesMatrixStrict( _
                   ws.Cells(memoRows(i), 2), expectedData, 1, 1) Then _
            Err.Raise vbObjectError + 4847, _
                      "RestoreAnalysisDetailReviewCellSnapshots", _
                      "候補詳細の確認メモを厳密に復元できません。"
    Next i
    RestoreAnalysisDetailReviewCellSnapshots = True
    Exit Function
EH:
    AppendAnalysisWorkspaceRollbackDetail detailText, _
        "候補詳細の復元エラー: " & Err.Description
    Err.Clear
End Function

Private Sub AppendAnalysisWorkspaceRollbackDetail(ByRef detailText As String, _
                                                  ByVal newDetail As String)
    newDetail = Trim$(newDetail)
    If Len(newDetail) = 0 Then Exit Sub
    If Len(detailText) > 0 Then detailText = detailText & " / "
    detailText = detailText & newDetail
End Sub

Private Function TryGetAnalysisWorkspaceEnableEvents( _
        ByRef currentValue As Boolean, _
        ByRef detailText As String) As Boolean
    Dim errorNumber As Long, errorDescription As String
    detailText = vbNullString
    On Error GoTo EH
    currentValue = Application.EnableEvents
    TryGetAnalysisWorkspaceEnableEvents = True
    Exit Function
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    detailText = "Err " & CStr(errorNumber) & ": " & errorDescription
    Err.Clear
End Function

Private Function TrySetAnalysisWorkspaceEnableEventsExact( _
        ByVal desiredValue As Boolean, _
        ByRef detailText As String) As Boolean
    Dim errorNumber As Long, errorDescription As String
    detailText = vbNullString
    On Error GoTo EH
    Application.EnableEvents = desiredValue
    If Application.EnableEvents <> desiredValue Then
        detailText = "EnableEventsの書込み後読戻しが一致しません。"
        Exit Function
    End If
    TrySetAnalysisWorkspaceEnableEventsExact = True
    Exit Function
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    detailText = "Err " & CStr(errorNumber) & ": " & errorDescription
    Err.Clear
End Function

Private Function TryStopAnalysisWorkspaceEventsForBookWrites( _
        ByRef detailText As String) As Boolean
    Dim firstDetail As String, retryDetail As String
    detailText = vbNullString
    If TrySetAnalysisWorkspaceEnableEventsExact(False, firstDetail) Then
        TryStopAnalysisWorkspaceEventsForBookWrites = True
        Exit Function
    End If
    If TrySetAnalysisWorkspaceEnableEventsExact(False, retryDetail) Then
        TryStopAnalysisWorkspaceEventsForBookWrites = True
        Exit Function
    End If
    detailText = "ExcelイベントをFalseへ停止して読戻し確認できませんでした。初回=" & _
                 firstDetail & " / 再試行=" & retryDetail
End Function

Private Function TryConfirmAnalysisWorkspaceRecoveryState( _
        ByRef detailText As String) As Boolean
    Dim latchIsSet As Boolean, latchReadSucceeded As Boolean
    Dim healthValue As String, healthReadSucceeded As Boolean
    latchReadSucceeded = TryGetRollbackRecoveryLatch(latchIsSet)
    If Not latchReadSucceeded Or Not latchIsSet Then
        AppendAnalysisWorkspaceRollbackDetail detailText, _
            "独立復旧ラッチを設定済みとして一意に確認できません。"
        Exit Function
    End If
    healthReadSucceeded = TryGetExactStateValue(STATE_DATA_HEALTH, healthValue)
    If Not healthReadSucceeded Then
        AppendAnalysisWorkspaceRollbackDetail detailText, _
            "案件要復旧状態を一意に確認できません。"
        Exit Function
    End If
    If StrComp(healthValue, DATA_HEALTH_NEEDS_RECOVERY, _
               vbBinaryCompare) <> 0 Then
        AppendAnalysisWorkspaceRollbackDetail detailText, _
            "案件要復旧状態を一意に確認できません。"
        Exit Function
    End If
    TryConfirmAnalysisWorkspaceRecoveryState = True
End Function

Private Function TryConfirmAnalysisWorkspaceApplicationState( _
        ByRef detailText As String) As Boolean
    Dim stateProblems As String
    Dim errorNumber As Long, errorDescription As String
    detailText = vbNullString
    On Error GoTo EH
    If AppStateIsRestored(stateProblems) Then
        TryConfirmAnalysisWorkspaceApplicationState = True
    Else
        detailText = stateProblems
    End If
    Exit Function
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    detailText = "Application状態確認エラー: Err " & _
                 CStr(errorNumber) & " " & errorDescription
    Err.Clear
End Function

Private Sub EnforceAnalysisWorkspaceRecoveryStateTerminal( _
        ByVal operationName As String, ByRef detailText As String, _
        ByRef recoveryAttempted As Boolean, _
        ByRef recoveryTerminalFailure As Boolean, _
        ByVal originalErrorNumber As Long, _
        ByVal originalErrorSource As String, _
        ByVal originalErrorDescription As String)
    Dim recoveryErrorNumber As Long, recoveryErrorDescription As String
    Dim recoveryErrorSource As String
    Dim eventsStopped As Boolean, eventStateDetail As String
    Dim recoveryConfirmed As Boolean, applicationStateConfirmed As Boolean
    Dim applicationStateDetail As String
    If recoveryAttempted Or recoveryTerminalFailure Then
        recoveryTerminalFailure = True
        eventsStopped = _
            TryStopAnalysisWorkspaceEventsForBookWrites(eventStateDetail)
        AppendAnalysisWorkspaceRollbackDetail detailText, _
            "Recovery強制設定はこの操作で既に試行済みのため、再試行しません。"
        If Not eventsStopped Then _
            AppendAnalysisWorkspaceRollbackDetail detailText, _
                "再試行抑止後のExcelイベントFalse収束にも失敗しました: " & _
                eventStateDetail
        RaiseAnalysisWorkspaceLocalRecoveryFatal _
            operationName, originalErrorNumber, originalErrorSource, _
            originalErrorDescription, detailText
    End If
    If Not TryStopAnalysisWorkspaceEventsForBookWrites(eventStateDetail) Then
        recoveryTerminalFailure = True
        AppendAnalysisWorkspaceRollbackDetail detailText, _
            "Recovery強制設定前にExcelイベントをFalseへ収束できません: " & _
            eventStateDetail
        RaiseAnalysisWorkspaceLocalRecoveryFatal _
            operationName, originalErrorNumber, originalErrorSource, _
            originalErrorDescription, detailText
    End If
    recoveryAttempted = True
    On Error Resume Next
    Err.Clear
    EnforceRollbackRecoveryState detailText
    recoveryErrorNumber = Err.Number
    recoveryErrorDescription = Err.Description
    recoveryErrorSource = Err.Source
    Err.Clear
    eventsStopped = _
        TryStopAnalysisWorkspaceEventsForBookWrites(eventStateDetail)
    On Error GoTo 0
    If recoveryErrorNumber <> 0 Then
        recoveryTerminalFailure = True
        AppendAnalysisWorkspaceRollbackDetail detailText, _
            "要復旧状態の強制設定エラー: Err " & _
            CStr(recoveryErrorNumber) & " " & recoveryErrorDescription
        If Not eventsStopped Then _
            AppendAnalysisWorkspaceRollbackDetail detailText, _
                "Recovery例外後のイベントFalse収束にも失敗しました: " & _
                eventStateDetail
        RaiseAnalysisWorkspaceLocalRecoveryFatal _
            operationName, originalErrorNumber, originalErrorSource, _
            originalErrorDescription, detailText
    End If
    If Not eventsStopped Then
        recoveryTerminalFailure = True
        AppendAnalysisWorkspaceRollbackDetail detailText, _
            "Recovery処理後にExcelイベントをFalseへ収束できません: " & _
            eventStateDetail
        RaiseAnalysisWorkspaceLocalRecoveryFatal _
            operationName, originalErrorNumber, originalErrorSource, _
            originalErrorDescription, detailText
    End If
    recoveryConfirmed = _
        TryConfirmAnalysisWorkspaceRecoveryState(detailText)
    If Not recoveryConfirmed Then
        recoveryTerminalFailure = True
        RaiseAnalysisWorkspaceLocalRecoveryFatal _
            operationName, originalErrorNumber, originalErrorSource, _
            originalErrorDescription, detailText
    End If
    applicationStateConfirmed = _
        TryConfirmAnalysisWorkspaceApplicationState(applicationStateDetail)
    If Not applicationStateConfirmed Then
        recoveryTerminalFailure = True
        AppendAnalysisWorkspaceRollbackDetail detailText, _
            "Recovery後のApplication状態を確認できません: " & _
            applicationStateDetail
        RaiseAnalysisWorkspaceLocalRecoveryFatal _
            operationName, originalErrorNumber, originalErrorSource, _
            originalErrorDescription, detailText
    End If
    If Not TryStopAnalysisWorkspaceEventsForBookWrites(eventStateDetail) Then
        recoveryTerminalFailure = True
        AppendAnalysisWorkspaceRollbackDetail detailText, _
            "Recovery安全確認後の最終イベントFalseを確認できません: " & _
            eventStateDetail
        RaiseAnalysisWorkspaceLocalRecoveryFatal _
            operationName, originalErrorNumber, originalErrorSource, _
            originalErrorDescription, detailText
    End If
    AppendAnalysisWorkspaceRollbackDetail detailText, _
        "今回のRecovery二重状態、Application状態、最終イベントFalseを確認しました。"
    RaiseAnalysisWorkspaceLocalRecoveryFatal _
        operationName, originalErrorNumber, originalErrorSource, _
        originalErrorDescription, detailText
End Sub

Private Function IsAnalysisWorkspaceRecoveryFatalError( _
        ByVal errorNumber As Long, ByVal errorSource As String) As Boolean
    Dim sourcePrefix As String
    Select Case errorNumber
        Case vbObjectError + 3599, vbObjectError + 4499
            IsAnalysisWorkspaceRecoveryFatalError = True
            Exit Function
        Case ANALYSIS_WORKSPACE_RECOVERY_FATAL_ERROR
            sourcePrefix = ANALYSIS_WORKSPACE_RECOVERY_FATAL_SOURCE
        Case vbObjectError + 5192
            sourcePrefix = "SetupConvergeRecoveryFatal/"
        Case vbObjectError + 5194
            sourcePrefix = "CashAnalysisRecoveryFatal/"
        Case vbObjectError + 5195
            sourcePrefix = "TransactionAnalysisRecoveryFatal/"
        Case vbObjectError + 5196
            sourcePrefix = "CashManualSelectionRecoveryFatal/"
        Case vbObjectError + 5197
            sourcePrefix = "ClearRecoveryFatal/"
        Case Else
            Exit Function
    End Select
    IsAnalysisWorkspaceRecoveryFatalError = _
        (Len(errorSource) >= Len(sourcePrefix)) And _
        (StrComp(Left$(errorSource, Len(sourcePrefix)), _
                 sourcePrefix, vbBinaryCompare) = 0)
End Function

Private Sub RethrowAnalysisWorkspaceUpstreamRecoveryFatal( _
        ByVal errorNumber As Long, ByVal errorSource As String, _
        ByVal errorDescription As String, ByVal operationName As String)
    Dim eventStateDetail As String
    Call TryStopAnalysisWorkspaceEventsForBookWrites(eventStateDetail)
    Err.Raise errorNumber, errorSource, errorDescription
End Sub

Private Sub RaiseAnalysisWorkspaceLocalRecoveryFatal( _
        ByVal operationName As String, ByVal originalErrorNumber As Long, _
        ByVal originalErrorSource As String, _
        ByVal originalErrorDescription As String, _
        ByVal recoveryDetail As String)
    Dim eventStateDetail As String, fatalDescription As String
    If Not TryStopAnalysisWorkspaceEventsForBookWrites(eventStateDetail) Then _
        AppendAnalysisWorkspaceRollbackDetail recoveryDetail, _
            "local Recovery後のExcelイベントFalse収束を確認できません: " & _
            eventStateDetail
    fatalDescription = "元エラー Err " & CStr(originalErrorNumber)
    If Len(originalErrorSource) > 0 Then _
        fatalDescription = fatalDescription & " / " & originalErrorSource
    If Len(originalErrorDescription) > 0 Then _
        fatalDescription = fatalDescription & ": " & originalErrorDescription
    If Len(recoveryDetail) > 0 Then _
        fatalDescription = fatalDescription & " / Recovery: " & recoveryDetail
    Err.Raise ANALYSIS_WORKSPACE_RECOVERY_FATAL_ERROR, _
              ANALYSIS_WORKSPACE_RECOVERY_FATAL_SOURCE & operationName, _
              fatalDescription
End Sub

Private Function TryRestoreAnalysisWorkspaceEnableEvents( _
        ByVal previousValue As Boolean, _
        ByVal operationName As String, _
        ByRef recoveryAttempted As Boolean, _
        ByRef recoveryTerminalFailure As Boolean, _
        ByRef detailText As String) As Boolean
    Dim firstDetail As String, retryDetail As String
    Dim safeStopDetail As String
    Dim recoveryStateConfirmed As Boolean, applicationStateConfirmed As Boolean
    Dim applicationStateDetail As String
    detailText = vbNullString
    If recoveryAttempted Or recoveryTerminalFailure Then
        recoveryTerminalFailure = True
        If TryStopAnalysisWorkspaceEventsForBookWrites(safeStopDetail) Then
            detailText = "Recovery終端後のため開始値へ戻さず、" & _
                         "ExcelイベントをFalseで停止しました。"
        Else
            detailText = "Recovery終端後のExcelイベントFalse収束にも失敗しました: " & _
                         safeStopDetail
        End If
        RaiseAnalysisWorkspaceLocalRecoveryFatal _
            operationName, ANALYSIS_WORKSPACE_RECOVERY_FATAL_ERROR, _
            ANALYSIS_WORKSPACE_RECOVERY_FATAL_SOURCE & operationName, _
            "Recovery終端後にイベント開始値復元へ再進入しました。", _
            detailText
    End If
    If previousValue Then
        If Not TryStopAnalysisWorkspaceEventsForBookWrites(safeStopDetail) Then
            detailText = "開始値Trueの復元前にExcelイベントFalseを確認できません: " & _
                         safeStopDetail
            Exit Function
        End If
        applicationStateConfirmed = _
            TryConfirmAnalysisWorkspaceApplicationState(applicationStateDetail)
        If Not applicationStateConfirmed Then
            detailText = _
                "Application状態を安全に確認できないため開始値Trueへ戻しません: " & _
                applicationStateDetail
            recoveryStateConfirmed = _
                StopAfterAnalysisWorkspaceEventStateFailure( _
                    operationName & "/Application状態未復元", detailText, _
                    recoveryAttempted, recoveryTerminalFailure, 0, _
                    operationName, detailText)
            If recoveryStateConfirmed Then _
                AppendAnalysisWorkspaceRollbackDetail detailText, _
                    "local Recoveryを安全確認しましたが、開始値へ戻さず" & _
                    "Recovery fatalとして伝播します。"
            Exit Function
        End If
        If Not TryStopAnalysisWorkspaceEventsForBookWrites(safeStopDetail) Then
            detailText = _
                "Application状態確認後、開始値Trueの復元直前に" & _
                "ExcelイベントFalseを確認できません: " & safeStopDetail
            Exit Function
        End If
    End If
    If TrySetAnalysisWorkspaceEnableEventsExact(previousValue, firstDetail) Then
        TryRestoreAnalysisWorkspaceEnableEvents = True
        Exit Function
    End If
    '一時的なCOM失敗だけを同じ開始値への再試行で吸収し、各試行で読戻しまで確認する。
    If TrySetAnalysisWorkspaceEnableEventsExact(previousValue, retryDetail) Then
        TryRestoreAnalysisWorkspaceEnableEvents = True
        Exit Function
    End If
    detailText = "Excelイベント状態を開始値へ復元できませんでした。初回=" & _
                 firstDetail & " / 再試行=" & retryDetail
    recoveryStateConfirmed = _
        StopAfterAnalysisWorkspaceEventStateFailure( _
            operationName, detailText, recoveryAttempted, _
            recoveryTerminalFailure, 0, operationName, detailText)
End Function

Private Function StopAfterAnalysisWorkspaceEventStateFailure( _
        ByVal operationName As String, _
        ByRef detailText As String, _
        ByRef recoveryAttempted As Boolean, _
        ByRef recoveryTerminalFailure As Boolean, _
        ByVal originalErrorNumber As Long, _
        ByVal originalErrorSource As String, _
        ByVal originalErrorDescription As String) As Boolean
    Dim recoveryDetail As String, stopDetail As String
    recoveryDetail = operationName & ": " & detailText
    If Not TryStopAnalysisWorkspaceEventsForBookWrites(stopDetail) Then
        AppendAnalysisWorkspaceRollbackDetail recoveryDetail, _
            "イベント停止未確認のため、ブックへのRecovery・診断・状態表示の書込みを見送りました: " & _
            stopDetail
        AppendAnalysisWorkspaceRollbackDetail recoveryDetail, _
            "Excelイベント状態と案件の安全状態は不明です。"
        detailText = recoveryDetail
        On Error Resume Next
        MsgBox "Excelイベントを安全に停止できず、ブックへの復旧記録を見送りました。" & _
               vbCrLf & "Excelイベント状態と案件の安全状態は不明です。" & _
               vbCrLf & "現在のブックを上書きしないでください。", _
               vbCritical, "Excelイベント状態を確認できません"
        On Error GoTo 0
        Exit Function
    End If
    If recoveryAttempted Or recoveryTerminalFailure Then
        recoveryTerminalFailure = True
        AppendAnalysisWorkspaceRollbackDetail recoveryDetail, _
            "Recovery強制設定はこの操作で既に試行済みのため、再試行せずイベントを停止します。"
        detailText = recoveryDetail
        RaiseAnalysisWorkspaceLocalRecoveryFatal _
            operationName, originalErrorNumber, originalErrorSource, _
            originalErrorDescription, recoveryDetail
    End If
    AppendAnalysisWorkspaceRollbackDetail recoveryDetail, _
        "要復旧記録前にExcelイベント停止を読戻し確認しました。"
    EnforceAnalysisWorkspaceRecoveryStateTerminal _
        operationName, recoveryDetail, recoveryAttempted, _
        recoveryTerminalFailure, originalErrorNumber, _
        originalErrorSource, originalErrorDescription
End Function

Public Sub SyncAnalysisWorkspaceReviewsToSources()
    Dim wsResult As Worksheet, lastR As Long, resultData As Variant
    Dim checkRange As Range
    Dim r As Long, statusCol As Long, memoCol As Long, keyCol As Long
    Dim sourceSheet As String
    Dim sourceSnapshots() As Variant, sourceLastRows() As Long
    Dim snapshotsCaptured As Boolean, writeStarted As Boolean, rollbackOK As Boolean
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim rollbackDetail As String
    Dim recoveryAttempted As Boolean, recoveryTerminalFailure As Boolean
    If Not SheetExists(SH_ANALYSIS_RESULT) Then Exit Sub
    Set wsResult = GetSheet(SH_ANALYSIS_RESULT)
    If Not TryGetLastUsedRowInSheet(wsResult, lastR) Then _
        Err.Raise vbObjectError + 4803, "SyncAnalysisWorkspaceReviewsToSources", _
                  "分析結果の最終行を確認できません。"
    If lastR < 2 Then Exit Sub
    Set checkRange = Union( _
        wsResult.Range(wsResult.Cells(2, 2), wsResult.Cells(lastR, 2)), _
        wsResult.Range(wsResult.Cells(2, ANALYSIS_RESULT_STATUS_COL), _
                       wsResult.Cells(lastR, ANALYSIS_RESULT_MEMO_COL)), _
        wsResult.Range(wsResult.Cells(2, ANALYSIS_RESULT_SOURCE_SHEET_COL), _
                       wsResult.Cells(lastR, ANALYSIS_RESULT_ALTERNATIVE_COUNT_COL)))
    RequireAnalysisReviewConstantRange checkRange, "分析結果の確認欄または内部参照"
    resultData = wsResult.Range(wsResult.Cells(2, 1), _
                                wsResult.Cells(lastR, ANALYSIS_RESULT_LAST_COL)).Value2
    For r = 1 To lastR - 1
        sourceSheet = CellText(resultData(r, ANALYSIS_RESULT_SOURCE_SHEET_COL))
        If Not WorkspaceSourceColumns(sourceSheet, statusCol, memoCol, keyCol) Then _
            Err.Raise vbObjectError + 4805, "SyncAnalysisWorkspaceReviewsToSources", _
                      "分析結果 " & CStr(r + 1) & "行目の内部元表が不正です。"
    Next r
    ReDim sourceSnapshots(1 To 3)
    ReDim sourceLastRows(1 To 3)
    CaptureAnalysisSourceReviewSnapshots sourceSnapshots, sourceLastRows
    snapshotsCaptured = True
    On Error GoTo EH
    writeStarted = True
    SyncWorkspaceSourceReviews resultData, lastR - 1, SH_ANALYSIS_SHIFT
    SyncWorkspaceSourceReviews resultData, lastR - 1, SH_ANALYSIS_FLOW
    SyncWorkspaceSourceReviews resultData, lastR - 1, SH_ANALYSIS_UNKNOWN
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    If IsAnalysisWorkspaceRecoveryFatalError(errorNumber, errorSource) Then _
        RethrowAnalysisWorkspaceUpstreamRecoveryFatal _
            errorNumber, errorSource, errorDescription, _
            "SyncAnalysisWorkspaceReviewsToSources"
    If writeStarted And snapshotsCaptured Then
        rollbackOK = RestoreAnalysisSourceReviewSnapshots( _
                         sourceSnapshots, sourceLastRows, rollbackDetail)
        If Not rollbackOK Then
            EnforceAnalysisWorkspaceRecoveryStateTerminal _
                "SyncAnalysisWorkspaceReviewsToSources", _
                rollbackDetail, recoveryAttempted, _
                recoveryTerminalFailure, errorNumber, errorSource, _
                errorDescription
        End If
    End If
    If Len(rollbackDetail) > 0 Then _
        errorDescription = errorDescription & " / ロールバック確認: " & rollbackDetail
    Err.Raise errorNumber, "SyncAnalysisWorkspaceReviewsToSources", errorDescription
End Sub

Public Sub SyncAnalysisDetailReviewsToSources()
    Dim wsDetail As Worksheet, wsSource As Worksheet
    Dim lastR As Long, sourceLastR As Long, r As Long, sourceRow As Long
    Dim sourceSheet As String, sourceKey As String, actualKey As String
    Dim statusText As String, memoText As String, categoryText As String
    Dim statusCol As Long, memoCol As Long, keyCol As Long
    Dim checkRange As Range, seenTargets As Object, targetID As String
    Dim planSheets() As String, planRows() As Long
    Dim planStatuses() As String, planMemos() As String, planCount As Long
    Dim sourceSnapshots() As Variant, sourceLastRows() As Long
    Dim snapshotsCaptured As Boolean, writeStarted As Boolean, rollbackOK As Boolean
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim rollbackDetail As String
    Dim recoveryAttempted As Boolean, recoveryTerminalFailure As Boolean
    If Not SheetExists(SH_ANALYSIS_DETAIL) Then Exit Sub
    Set wsDetail = GetSheet(SH_ANALYSIS_DETAIL)
    If Not TryGetLastUsedRowInSheet(wsDetail, lastR) Then _
        Err.Raise vbObjectError + 4810, "SyncAnalysisDetailReviewsToSources", _
                  "候補詳細の最終行を確認できません。"
    If lastR < 2 Then Exit Sub
    Set checkRange = Union( _
        wsDetail.Range(wsDetail.Cells(2, 1), wsDetail.Cells(lastR, 2)), _
        wsDetail.Range(wsDetail.Cells(2, 6), wsDetail.Cells(lastR, 6)), _
        wsDetail.Range(wsDetail.Cells(2, DETAIL_COL_KIND), _
                       wsDetail.Cells(lastR, DETAIL_COL_SOURCE_KEY)))
    RequireAnalysisReviewConstantRange checkRange, "候補詳細の確認欄または内部参照"
    ReDim sourceSnapshots(1 To 3)
    ReDim sourceLastRows(1 To 3)
    CaptureAnalysisSourceReviewSnapshots sourceSnapshots, sourceLastRows
    snapshotsCaptured = True
    ReDim planSheets(1 To lastR - 1)
    ReDim planRows(1 To lastR - 1)
    ReDim planStatuses(1 To lastR - 1)
    ReDim planMemos(1 To lastR - 1)
    Set seenTargets = CreateObject("Scripting.Dictionary")
    seenTargets.CompareMode = vbTextCompare
    On Error GoTo EH
    For r = 2 To lastR
        If CellText(wsDetail.Cells(r, DETAIL_COL_KIND).Value) = "候補" Then
            sourceSheet = CellText(wsDetail.Cells(r, DETAIL_COL_REFERENCE).Value)
            sourceRow = WorkspaceLong(wsDetail.Cells(r, DETAIL_COL_SOURCE_ROW).Value)
            sourceKey = CellText(wsDetail.Cells(r, DETAIL_COL_SOURCE_KEY).Value)
            If Not WorkspaceSourceColumns(sourceSheet, statusCol, memoCol, keyCol) Then _
                Err.Raise vbObjectError + 4812, "SyncAnalysisDetailReviewsToSources", _
                          "候補詳細 " & CStr(r) & "行目の内部元表が不正です。"
            Set wsSource = GetSheet(sourceSheet)
            If Not TryGetLastUsedRowInSheet(wsSource, sourceLastR) Then _
                Err.Raise vbObjectError + 4813, "SyncAnalysisDetailReviewsToSources", _
                          "候補詳細 " & CStr(r) & "行目の内部元表を確認できません。"
            If sourceRow < 2 Or sourceRow > sourceLastR Then _
                Err.Raise vbObjectError + 4813, "SyncAnalysisDetailReviewsToSources", _
                          "候補詳細 " & CStr(r) & "行目の内部元行が見つかりません。"
            actualKey = CellText(wsSource.Cells(sourceRow, keyCol).Value)
            If Len(sourceKey) = 0 Or StrComp(actualKey, sourceKey, vbBinaryCompare) <> 0 Then _
                Err.Raise vbObjectError + 4814, "SyncAnalysisDetailReviewsToSources", _
                          "候補詳細 " & CStr(r) & "行目と内部根拠の確認キーが一致しません。"
            statusText = WorkspaceStatusOrDefault(wsDetail.Cells(r, 6).Value)
            categoryText = CellText(wsDetail.Cells(r, 1).Value)
            If Not WorkspaceStatusFitsSource(sourceSheet, categoryText, statusText) Then _
                Err.Raise vbObjectError + 4815, "SyncAnalysisDetailReviewsToSources", _
                          "候補詳細 " & CStr(r) & "行目の確認状況が区分に適合しません。"
            If r + 1 > lastR Or _
               CellText(wsDetail.Cells(r + 1, DETAIL_COL_KIND).Value) <> "候補メモ" Then _
                Err.Raise vbObjectError + 4816, "SyncAnalysisDetailReviewsToSources", _
                          "候補詳細 " & CStr(r) & "行目の個別メモ欄がありません。"
            If StrComp(CellText(wsDetail.Cells(r + 1, DETAIL_COL_REFERENCE).Value2), _
                       sourceSheet, vbBinaryCompare) <> 0 Or _
               WorkspaceLong(wsDetail.Cells(r + 1, DETAIL_COL_SOURCE_ROW).Value2) <> _
                   sourceRow Or _
               StrComp(CellText(wsDetail.Cells(r + 1, DETAIL_COL_SOURCE_KEY).Value2), _
                       sourceKey, vbBinaryCompare) <> 0 Then _
                Err.Raise vbObjectError + 4816, "SyncAnalysisDetailReviewsToSources", _
                          "候補詳細 " & CStr(r) & "行目の個別メモ参照が一致しません。"
            memoText = CellText(wsDetail.Cells(r + 1, 2).Value)
            If Len(memoText) > WORKSPACE_MEMO_MAX Then _
                Err.Raise vbObjectError + 4817, "SyncAnalysisDetailReviewsToSources", _
                          "候補詳細 " & CStr(r + 1) & "行目の確認メモが長すぎます。"
            targetID = sourceSheet & "|" & CStr(sourceRow)
            If seenTargets.Exists(targetID) Then _
                Err.Raise vbObjectError + 4818, "SyncAnalysisDetailReviewsToSources", _
                          "候補詳細に同じ内部候補が重複しています: " & targetID
            seenTargets.Add targetID, True
            planCount = planCount + 1
            planSheets(planCount) = sourceSheet
            planRows(planCount) = sourceRow
            planStatuses(planCount) = statusText
            planMemos(planCount) = memoText
        End If
    Next r
    If planCount > 0 Then
        writeStarted = True
        For r = 1 To planCount
            If Not WorkspaceSourceColumns(planSheets(r), statusCol, memoCol, keyCol) Then _
                Err.Raise vbObjectError + 4812, "SyncAnalysisDetailReviewsToSources", _
                          "候補詳細の内部元表が書込直前に不正になりました。"
            Set wsSource = GetSheet(planSheets(r))
            WriteAnalysisReviewTextCellIfChanged wsSource.Cells(planRows(r), statusCol), _
                planStatuses(r), "候補詳細の確認状況"
            WriteAnalysisReviewTextCellIfChanged wsSource.Cells(planRows(r), memoCol), _
                planMemos(r), "候補詳細の確認メモ"
        Next r
    End If
    mAnalysisDetailReviewsDirty = False
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    If IsAnalysisWorkspaceRecoveryFatalError(errorNumber, errorSource) Then _
        RethrowAnalysisWorkspaceUpstreamRecoveryFatal _
            errorNumber, errorSource, errorDescription, _
            "SyncAnalysisDetailReviewsToSources"
    If writeStarted And snapshotsCaptured Then
        rollbackOK = RestoreAnalysisSourceReviewSnapshots( _
                         sourceSnapshots, sourceLastRows, rollbackDetail)
        If Not rollbackOK Then
            EnforceAnalysisWorkspaceRecoveryStateTerminal _
                "SyncAnalysisDetailReviewsToSources", _
                rollbackDetail, recoveryAttempted, _
                recoveryTerminalFailure, errorNumber, errorSource, _
                errorDescription
        End If
    End If
    If Len(rollbackDetail) > 0 Then _
        errorDescription = errorDescription & " / ロールバック確認: " & rollbackDetail
    Err.Raise errorNumber, "SyncAnalysisDetailReviewsToSources", errorDescription
End Sub

Public Function SyncCashAnalysisReviewToSourceAndDetailSnapshot( _
        ByVal sourceSheet As String, ByVal sourceRow As Long, _
        ByVal sourceKey As String, ByVal categoryText As String, _
        ByVal statusText As String, ByVal memoText As String) As Boolean
    '資金操作表の分析パネルを最終入力面として扱う。元表だけでなく、再Commit時に
    '後勝ちし得る候補詳細の表示スナップショットも同時に同じ値へそろえる。
    Dim wsSource As Worksheet, wsDetail As Worksheet
    Dim statusCol As Long, memoCol As Long, keyCol As Long
    Dim lastR As Long, sourceLastR As Long, r As Long
    Dim detailData As Variant
    Dim detailChanged As Boolean, detailUnprotected As Boolean
    Dim changed As Boolean
    Dim detailStatusRows() As Long, detailMemoRows() As Long, detailCount As Long
    Dim detailStatusSnapshots() As Variant, detailMemoSnapshots() As Variant
    Dim sourceSnapshots() As Variant, sourceLastRows() As Long
    Dim sourceSnapshotsCaptured As Boolean, detailSnapshotsCaptured As Boolean
    Dim writeStarted As Boolean, sourceRollbackOK As Boolean, detailRollbackOK As Boolean
    Dim protectRollbackOK As Boolean, checkRange As Range
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim protectErrorNumber As Long, protectErrorDescription As String
    Dim protectErrorSource As String
    Dim rollbackDetail As String
    Dim recoveryAttempted As Boolean, recoveryTerminalFailure As Boolean

    On Error GoTo EH
    statusText = WorkspaceStatusOrDefault(statusText)
    If Not WorkspaceSourceColumns(sourceSheet, statusCol, memoCol, keyCol) Then _
        Err.Raise vbObjectError + 4824, "SyncCashAnalysisReviewToSourceAndDetailSnapshot", _
                  "資金操作表の候補が参照する内部元表が不正です。"
    Set wsSource = GetSheet(sourceSheet)
    If Not TryGetLastUsedRowInSheet(wsSource, sourceLastR) Then _
        Err.Raise vbObjectError + 4825, "SyncCashAnalysisReviewToSourceAndDetailSnapshot", _
                  "資金操作表の候補が参照する内部元表を確認できません。"
    If sourceRow < 2 Or sourceRow > sourceLastR Then _
        Err.Raise vbObjectError + 4825, "SyncCashAnalysisReviewToSourceAndDetailSnapshot", _
                  "資金操作表の候補が参照する内部元行が見つかりません。"
    If Len(sourceKey) = 0 Or _
       StrComp(CellText(wsSource.Cells(sourceRow, keyCol).Value), _
               sourceKey, vbBinaryCompare) <> 0 Then _
        Err.Raise vbObjectError + 4826, "SyncCashAnalysisReviewToSourceAndDetailSnapshot", _
                  "資金操作表の候補と内部根拠の確認キーが一致しません。"
    If Not WorkspaceStatusFitsSource(sourceSheet, categoryText, statusText) Then _
        Err.Raise vbObjectError + 4827, "SyncCashAnalysisReviewToSourceAndDetailSnapshot", _
                  "資金操作表の確認状況が候補区分に適合しません。"
    If Len(memoText) > WORKSPACE_MEMO_MAX Then _
        Err.Raise vbObjectError + 4828, "SyncCashAnalysisReviewToSourceAndDetailSnapshot", _
                  "資金操作表の確認メモが長すぎます。"

    If SheetExists(SH_ANALYSIS_DETAIL) Then
        Set wsDetail = GetSheet(SH_ANALYSIS_DETAIL)
        If Not TryGetLastUsedRowInSheet(wsDetail, lastR) Then _
            Err.Raise vbObjectError + 4829, _
                      "SyncCashAnalysisReviewToSourceAndDetailSnapshot", _
                      "候補詳細の最終行を確認できません。"
        If lastR >= 2 Then
            Set checkRange = Union( _
                wsDetail.Range(wsDetail.Cells(2, 2), wsDetail.Cells(lastR, 2)), _
                wsDetail.Range(wsDetail.Cells(2, 6), wsDetail.Cells(lastR, 6)), _
                wsDetail.Range(wsDetail.Cells(2, DETAIL_COL_KIND), _
                               wsDetail.Cells(lastR, DETAIL_COL_SOURCE_KEY)))
            RequireAnalysisReviewConstantRange checkRange, _
                "候補詳細の確認欄または内部参照"
            detailData = wsDetail.Range(wsDetail.Cells(2, DETAIL_COL_KIND), _
                                        wsDetail.Cells(lastR, DETAIL_COL_SOURCE_KEY)).Value2
            ReDim detailStatusRows(1 To UBound(detailData, 1))
            ReDim detailMemoRows(1 To UBound(detailData, 1))
            For r = 1 To UBound(detailData, 1)
                If CellText(detailData(r, 1)) = "候補" And _
                   StrComp(CellText(detailData(r, DETAIL_COL_REFERENCE - DETAIL_COL_KIND + 1)), _
                           sourceSheet, vbBinaryCompare) = 0 And _
                   WorkspaceLong(detailData(r, DETAIL_COL_SOURCE_ROW - DETAIL_COL_KIND + 1)) = sourceRow And _
                   StrComp(CellText(detailData(r, DETAIL_COL_SOURCE_KEY - DETAIL_COL_KIND + 1)), _
                           sourceKey, vbBinaryCompare) = 0 Then
                    If r + 1 > UBound(detailData, 1) Then _
                        Err.Raise vbObjectError + 4829, _
                                  "SyncCashAnalysisReviewToSourceAndDetailSnapshot", _
                                  "資金操作表の候補に対応する候補詳細メモ欄がありません。"
                    If CellText(detailData(r + 1, 1)) <> "候補メモ" Or _
                       StrComp(CellText(detailData(r + 1, DETAIL_COL_REFERENCE - DETAIL_COL_KIND + 1)), _
                               sourceSheet, vbBinaryCompare) <> 0 Or _
                       WorkspaceLong(detailData(r + 1, DETAIL_COL_SOURCE_ROW - DETAIL_COL_KIND + 1)) <> sourceRow Or _
                       StrComp(CellText(detailData(r + 1, DETAIL_COL_SOURCE_KEY - DETAIL_COL_KIND + 1)), _
                               sourceKey, vbBinaryCompare) <> 0 Then _
                        Err.Raise vbObjectError + 4829, _
                                  "SyncCashAnalysisReviewToSourceAndDetailSnapshot", _
                                  "資金操作表の候補に対応する候補詳細メモ欄が不正です。"
                    detailCount = detailCount + 1
                    detailStatusRows(detailCount) = r + 1
                    detailMemoRows(detailCount) = r + 2
                End If
            Next r
        End If
    End If

    ReDim sourceSnapshots(1 To 3)
    ReDim sourceLastRows(1 To 3)
    CaptureAnalysisSourceReviewSnapshots sourceSnapshots, sourceLastRows
    sourceSnapshotsCaptured = True
    If detailCount > 0 Then
        ReDim detailStatusSnapshots(1 To detailCount)
        ReDim detailMemoSnapshots(1 To detailCount)
        CaptureAnalysisDetailReviewCellSnapshots wsDetail, detailStatusRows, _
            detailMemoRows, detailCount, detailStatusSnapshots, detailMemoSnapshots
        detailSnapshotsCaptured = True
    End If

    writeStarted = True
    changed = WriteAnalysisReviewTextCellIfChanged( _
                  wsSource.Cells(sourceRow, statusCol), statusText, _
                  "資金操作表の確認状況")
    If WriteAnalysisReviewTextCellIfChanged( _
           wsSource.Cells(sourceRow, memoCol), memoText, _
           "資金操作表の確認メモ") Then changed = True
    If detailCount > 0 Then
        wsDetail.Unprotect Password:=TOOL_PASSWORD
        detailUnprotected = True
        For r = 1 To detailCount
            If WriteAnalysisReviewTextCellIfChanged( _
                   wsDetail.Cells(detailStatusRows(r), 6), statusText, _
                   "候補詳細の確認状況") Then detailChanged = True
            If WriteAnalysisReviewTextCellIfChanged( _
                   wsDetail.Cells(detailMemoRows(r), 2), memoText, _
                   "候補詳細の確認メモ") Then detailChanged = True
        Next r
        ProtectSingleAnalysisSheet wsDetail
        detailUnprotected = False
    End If
    SyncCashAnalysisReviewToSourceAndDetailSnapshot = (changed Or detailChanged)
    Exit Function
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    If IsAnalysisWorkspaceRecoveryFatalError(errorNumber, errorSource) Then _
        RethrowAnalysisWorkspaceUpstreamRecoveryFatal _
            errorNumber, errorSource, errorDescription, _
            "SyncCashAnalysisReviewToSourceAndDetailSnapshot"
    If writeStarted Then
        If sourceSnapshotsCaptured Then
            sourceRollbackOK = RestoreAnalysisSourceReviewSnapshots( _
                                   sourceSnapshots, sourceLastRows, rollbackDetail)
        Else
            sourceRollbackOK = False
            AppendAnalysisWorkspaceRollbackDetail rollbackDetail, _
                "分析元表の退避がありません。"
        End If
        detailRollbackOK = True
        If detailSnapshotsCaptured Then _
            detailRollbackOK = RestoreAnalysisDetailReviewCellSnapshots( _
                                   wsDetail, detailStatusRows, detailMemoRows, detailCount, _
                                   detailStatusSnapshots, detailMemoSnapshots, rollbackDetail)
        protectRollbackOK = True
        If Not wsDetail Is Nothing Then
            On Error Resume Next
            Err.Clear
            ProtectSingleAnalysisSheet wsDetail
            protectErrorNumber = Err.Number
            protectErrorDescription = Err.Description
            protectErrorSource = Err.Source
            Err.Clear
            On Error GoTo 0
            If IsAnalysisWorkspaceRecoveryFatalError( _
                   protectErrorNumber, protectErrorSource) Then _
                RethrowAnalysisWorkspaceUpstreamRecoveryFatal _
                    protectErrorNumber, protectErrorSource, _
                    protectErrorDescription, _
                    "SyncCashAnalysisReviewToSourceAndDetailSnapshot/異常終了再保護"
            If protectErrorNumber <> 0 Then
                protectRollbackOK = False
                AppendAnalysisWorkspaceRollbackDetail rollbackDetail, _
                    "候補詳細の再保護エラー: " & protectErrorDescription
            End If
        End If
        If Not sourceRollbackOK Or Not detailRollbackOK Or Not protectRollbackOK Then
            EnforceAnalysisWorkspaceRecoveryStateTerminal _
                "SyncCashAnalysisReviewToSourceAndDetailSnapshot", _
                rollbackDetail, recoveryAttempted, _
                recoveryTerminalFailure, errorNumber, errorSource, _
                errorDescription
        End If
    ElseIf detailUnprotected And Not wsDetail Is Nothing Then
        On Error Resume Next
        Err.Clear
        ProtectSingleAnalysisSheet wsDetail
        protectErrorNumber = Err.Number
        protectErrorDescription = Err.Description
        protectErrorSource = Err.Source
        Err.Clear
        On Error GoTo 0
        If IsAnalysisWorkspaceRecoveryFatalError( _
               protectErrorNumber, protectErrorSource) Then _
            RethrowAnalysisWorkspaceUpstreamRecoveryFatal _
                protectErrorNumber, protectErrorSource, _
                protectErrorDescription, _
                "SyncCashAnalysisReviewToSourceAndDetailSnapshot/異常終了再保護"
    End If
    If Len(rollbackDetail) > 0 Then _
        errorDescription = errorDescription & " / ロールバック確認: " & rollbackDetail
    Err.Raise errorNumber, "SyncCashAnalysisReviewToSourceAndDetailSnapshot", errorDescription
End Function

Public Sub CommitAnalysisDetailReviews()
    CommitPendingAnalysisReviews False, "候補詳細の個別確認を保存"
End Sub

Public Function HasPendingAnalysisReviewChanges() As Boolean
    If AnalysisReviewsAreDirty() Or mAnalysisDetailReviewsDirty Then
        HasPendingAnalysisReviewChanges = True
    ElseIf AnalysisWorkspaceReviewsDifferFromSources() Then
        HasPendingAnalysisReviewChanges = True
    ElseIf AnalysisDetailReviewsDifferFromSources() Then
        HasPendingAnalysisReviewChanges = True
    End If
End Function

Public Sub CommitPendingAnalysisReviews( _
        Optional ByVal rebuildWorkspace As Boolean = False, _
        Optional ByVal reasonText As String = "分析判断を保存", _
        Optional ByVal capacityConfirmed As Boolean = False, _
        Optional ByRef confirmedAnalysisWorkloadRows As Double = 0#, _
        Optional ByVal allowLateCapacityPrompt As Boolean = True, _
        Optional ByVal additionalSnapshotCellWork As Double = 0#)
    Dim previousEvents As Boolean, eventsCaptured As Boolean
    Dim eventsReadyForRecovery As Boolean
    Dim eventStateDetail As String
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim dirtyErrorNumber As Long, dirtyErrorDescription As String
    Dim sourceSnapshots() As Variant, sourceLastRows() As Long
    Dim manualSnapshot As Variant, manualSnapshotLastRow As Long
    Dim allocationSnapshot As Variant, allocationSnapshotLastRow As Long
    Dim allocationSnapshotDigest As String
    Dim sourceSnapshotsCaptured As Boolean, manualSnapshotCaptured As Boolean
    Dim allocationSnapshotCaptured As Boolean
    Dim writeStarted As Boolean, persistenceCommitted As Boolean
    Dim sourceRollbackOK As Boolean, manualRollbackOK As Boolean
    Dim allocationRollbackOK As Boolean
    Dim rollbackSafe As Boolean, safeToRestoreEntry As Boolean
    Dim rollbackDetail As String, rollbackErrorNumber As Long
    Dim rollbackErrorDescription As String
    Dim recoveryAttempted As Boolean, recoveryTerminalFailure As Boolean
    Dim fatalContainmentRequired As Boolean
    Dim capacityShiftCount As Long, capacityFlowCount As Long, capacityUnknownCount As Long
    Dim capacityCandidateCount As Long, capacityResultCount As Long
    Dim allocationSnapshotCellWork As Double
    Dim effectiveAdditionalSnapshotCellWork As Double
    '保存イベントのたびに大規模な比較・容量確認を行わない。編集イベントは必ず
    '永続dirty状態を立て、読取不能時もAnalysisReviewsAreDirtyが安全側のTrueを返す。
    If Not AnalysisReviewsAreDirty() And Not mAnalysisDetailReviewsDirty Then Exit Sub
    'dirtyが立っていても、再構築などで表示と正本が既に一致していれば書込み不要。
    If Not HasPendingAnalysisReviewChanges() Then Exit Sub
    If ThisWorkbook.ReadOnly Then _
        Err.Raise vbObjectError + 4820, "CommitPendingAnalysisReviews", _
                  "読み取り専用のため、分析の確認状況とメモを保存できません。"
    '外側snapshot、配賦commit内snapshot、書込検証配列の同時保持上界。
    allocationSnapshotCellWork = _
        CDbl(AllocationLedgerStoredRowCount() + 1) * 10# * 3#
    If AnalysisOperationTransactionIsActive() Then
        '外側transactionのpeak値は、内側を含む二組のO:X退避を既に含む。
        effectiveAdditionalSnapshotCellWork = additionalSnapshotCellWork
    Else
        effectiveAdditionalSnapshotCellWork = _
            additionalSnapshotCellWork + allocationSnapshotCellWork
    End If
    If Not capacityConfirmed Then
        If Not RequireManualFlowMutationCapacity("分析判断の保存") Then _
            Err.Raise 18, "CommitPendingAnalysisReviews", _
                      "利用者が手動候補の容量確認を取り消しました。"
    End If
    If rebuildWorkspace Then
        If Not ConfirmCurrentAnalysisWorkspaceCapacity( _
                   reasonText, confirmedAnalysisWorkloadRows, _
                   capacityShiftCount, capacityFlowCount, capacityUnknownCount, _
                   capacityCandidateCount, capacityResultCount, _
                   allowLateCapacityPrompt, effectiveAdditionalSnapshotCellWork) Then _
            Err.Raise 18, "CommitPendingAnalysisReviews", _
                      "利用者が分析workspaceの容量確認を取り消しました。"
    Else
        If Not ConfirmAnalysisReviewOperationCapacity( _
                   reasonText, confirmedAnalysisWorkloadRows, _
                   allowUserConfirmation:=allowLateCapacityPrompt, _
                   additionalSnapshotCellWork:=effectiveAdditionalSnapshotCellWork) Then _
            Err.Raise 18, "CommitPendingAnalysisReviews", _
                      "利用者が分析判断の容量確認を取り消しました。"
    End If
    On Error GoTo EH
    'イベント停止、退避、書込みより前に全容量確認を完了する。
    If Not TryGetAnalysisWorkspaceEnableEvents(previousEvents, eventStateDetail) Then
        eventsReadyForRecovery = _
            StopAfterAnalysisWorkspaceEventStateFailure( _
                "CommitPendingAnalysisReviews/開始状態取得", eventStateDetail, _
                recoveryAttempted, recoveryTerminalFailure, _
                vbObjectError + 4879, "CommitPendingAnalysisReviews", _
                "Excelイベントの開始状態を取得できませんでした。")
        If recoveryAttempted Or recoveryTerminalFailure Then _
            RaiseAnalysisWorkspaceLocalRecoveryFatal _
                "CommitPendingAnalysisReviews", _
                vbObjectError + 4879, "CommitPendingAnalysisReviews", _
                "Excelイベントの開始状態を取得できませんでした。", _
                eventStateDetail
        Err.Raise vbObjectError + 4879, "CommitPendingAnalysisReviews", _
                  "Excelイベントの開始状態を取得できませんでした。 " & eventStateDetail
    End If
    eventsCaptured = True
    If Not TrySetAnalysisWorkspaceEnableEventsExact(False, eventStateDetail) Then _
        Err.Raise vbObjectError + 4880, "CommitPendingAnalysisReviews", _
                  "分析判断の保存前にExcelイベントを停止できませんでした。 " & _
                  eventStateDetail
    ReDim sourceSnapshots(1 To 3)
    ReDim sourceLastRows(1 To 3)
    CaptureAnalysisSourceReviewSnapshots sourceSnapshots, sourceLastRows
    sourceSnapshotsCaptured = True
    CaptureManualFlowStoreSnapshot manualSnapshot, manualSnapshotLastRow
    manualSnapshotCaptured = True
    CaptureAllocationLedgerTransactionSnapshot allocationSnapshot, _
        allocationSnapshotLastRow, allocationSnapshotDigest
    allocationSnapshotCaptured = True
    writeStarted = True
    '一覧と詳細の両方を同期し、詳細側の個別判断を最後に優先する。
    SyncAnalysisWorkspaceReviewsToSources
    SyncAnalysisDetailReviewsToSources
    '共有取引IDの重複確定は、既存の判断・理由・メモを自動変更せず、
    '手動候補ストアを含む後続保存より前に停止する。元表はEHで退避時点へ戻す。
    ResolveAnalysisReviewConflicts GetSheet(SH_ANALYSIS_SHIFT), GetSheet(SH_ANALYSIS_FLOW)
    SyncManualFlowReviewsFromAnalysisSheet True
    '確認状況の保存と同じtransactionで、現行候補から配賦・残差を再確定する。
    'これを省くと、未確認→確認済みの変更後も不明残額だけが旧値のまま残る。
    RebuildCurrentAnalysisAllocationPlan
    '曖昧配賦を要追加確認へ戻した場合、その最終状態を手動候補正本にも反映する。
    SyncManualFlowReviewsFromAnalysisSheet True
    If rebuildWorkspace Then
        BuildAnalysisWorkspaceCore "分析判断の保存", _
                                   confirmedAnalysisWorkloadRows, False
    Else
        RefreshAnalysisReviewDisplaysFromSources
    End If
    '候補詳細から保存した場合も、次回の出力時に旧パネル値が再適用されないよう
    '統合パネルを確定済みの元表へ戻す。
    RefreshCashAnalysisPanel False
    '元表・手動候補・画面再構築が全て成功してから台帳と履歴を同一バッチで確定する。
    If Not ConfirmAnalysisReviewOperationCapacity( _
               "分析判断台帳の保存", confirmedAnalysisWorkloadRows, _
               allowUserConfirmation:=False, _
               additionalSnapshotCellWork:=effectiveAdditionalSnapshotCellWork) Then _
        Err.Raise 18, "CommitPendingAnalysisReviews", _
                  "分析判断台帳の確認済み容量が不足しています。"
    PersistAnalysisReviewsFromCurrentSheets False, reasonText
    persistenceCommitted = True
    MarkAnalysisReviewsClean
    mAnalysisDetailReviewsDirty = False
    If Not TryRestoreAnalysisWorkspaceEnableEvents( _
               previousEvents, "CommitPendingAnalysisReviews/正常終了", _
               recoveryAttempted, recoveryTerminalFailure, _
               eventStateDetail) Then
        eventsCaptured = False
        If recoveryAttempted Or recoveryTerminalFailure Then _
            RaiseAnalysisWorkspaceLocalRecoveryFatal _
                "CommitPendingAnalysisReviews", _
                vbObjectError + 4881, "CommitPendingAnalysisReviews", _
                "正常終了時のExcelイベント開始値復元に失敗しました。", _
                eventStateDetail
        Err.Raise vbObjectError + 4881, "CommitPendingAnalysisReviews", eventStateDetail
    End If
    eventsCaptured = False
    If recoveryAttempted Or recoveryTerminalFailure Then _
        RaiseAnalysisWorkspaceLocalRecoveryFatal _
            "CommitPendingAnalysisReviews", _
            vbObjectError + 4881, "CommitPendingAnalysisReviews", _
            "正常終了時のExcelイベント開始値復元でlocal Recoveryを実行しました。", _
            eventStateDetail
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    fatalContainmentRequired = _
        IsAnalysisWorkspaceRecoveryFatalError(errorNumber, errorSource)
    If fatalContainmentRequired Then
        Call TryStopAnalysisWorkspaceEventsForBookWrites(eventStateDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    eventsReadyForRecovery = False
    safeToRestoreEntry = (Not writeStarted) And Not fatalContainmentRequired
    If eventsCaptured Then
        eventsReadyForRecovery = _
            TryStopAnalysisWorkspaceEventsForBookWrites(eventStateDetail)
        If writeStarted And Not eventsReadyForRecovery Then _
            AppendAnalysisWorkspaceRollbackDetail rollbackDetail, _
                "Excelイベント停止を確認できないため、ブックへの復元・Recovery・dirty書込みを見送ります: " & _
                eventStateDetail
    End If
    '台帳確定前の失敗は、分析元表と手動候補を両方とも退避時点へ戻す。
    '台帳確定後は元表だけを巻き戻すと台帳との不一致を作るため、再ロールバックしない。
    If Not fatalContainmentRequired And writeStarted And _
       Not persistenceCommitted Then
        If Not eventsReadyForRecovery Then
            AppendAnalysisWorkspaceRollbackDetail rollbackDetail, _
                "イベント停止未確認のため、分析元表・手動候補・配賦元帳を再書込みしません。"
        ElseIf sourceSnapshotsCaptured Then
            sourceRollbackOK = RestoreAnalysisSourceReviewSnapshots( _
                                   sourceSnapshots, sourceLastRows, rollbackDetail)
        Else
            AppendAnalysisWorkspaceRollbackDetail rollbackDetail, _
                "分析元表の退避がありません。"
        End If
        If eventsReadyForRecovery And manualSnapshotCaptured Then
            On Error Resume Next
            Err.Clear
            RestoreManualFlowStoreSnapshot manualSnapshot, manualSnapshotLastRow
            rollbackErrorNumber = Err.Number
            rollbackErrorDescription = Err.Description
            Err.Clear
            On Error GoTo 0
            If rollbackErrorNumber = 0 Then
                manualRollbackOK = True
            Else
                AppendAnalysisWorkspaceRollbackDetail rollbackDetail, _
                    "手動資金候補の復元エラー: " & rollbackErrorDescription
            End If
        ElseIf eventsReadyForRecovery Then
            AppendAnalysisWorkspaceRollbackDetail rollbackDetail, _
                "手動資金候補の退避がありません。"
        End If
        If eventsReadyForRecovery And allocationSnapshotCaptured Then
            On Error Resume Next
            Err.Clear
            RestoreAllocationLedgerTransactionSnapshot allocationSnapshot, _
                allocationSnapshotLastRow, allocationSnapshotDigest
            rollbackErrorNumber = Err.Number
            rollbackErrorDescription = Err.Description
            Err.Clear
            On Error GoTo 0
            If rollbackErrorNumber = 0 Then
                allocationRollbackOK = True
            Else
                AppendAnalysisWorkspaceRollbackDetail rollbackDetail, _
                    "配賦元帳の復元エラー: " & rollbackErrorDescription
            End If
        ElseIf eventsReadyForRecovery Then
            AppendAnalysisWorkspaceRollbackDetail rollbackDetail, _
                "配賦元帳の退避がありません。"
        End If
        rollbackSafe = sourceRollbackOK And manualRollbackOK And _
                       allocationRollbackOK
        If rollbackSafe Then
            safeToRestoreEntry = True
            AppendAnalysisWorkspaceRollbackDetail rollbackDetail, _
                "分析元表・手動候補・配賦元帳を退避時点へ厳密に復元しました。"
        End If
    ElseIf Not fatalContainmentRequired And writeStarted And _
           persistenceCommitted Then
        AppendAnalysisWorkspaceRollbackDetail rollbackDetail, _
            "判断台帳の確定後に失敗したため、確定済みデータを旧退避へ巻き戻しません。"
    End If

    'ロールバックで安全を確定できない経路は、False exact下でRecoveryを強制する。
    'Recoveryを一度でも試行した場合は、このprivate境界内で安全確認後に必ず
    '5191終端を送出し、dirty・診断・イベント開始値復元へ戻らない。
    If Not fatalContainmentRequired And writeStarted And Not rollbackSafe Then
        If eventsReadyForRecovery Then
            EnforceAnalysisWorkspaceRecoveryStateTerminal _
                "CommitPendingAnalysisReviews", rollbackDetail, _
                recoveryAttempted, recoveryTerminalFailure, _
                errorNumber, errorSource, errorDescription
        Else
            AppendAnalysisWorkspaceRollbackDetail rollbackDetail, _
                "Recovery書込みを見送り、案件の安全状態は不明です。"
        End If
    End If

    'dirtyはロールバック安全またはRecovery exactの確定後に限り、
    '書込み直前のFalse exactを確認してから記録する。
    If Not fatalContainmentRequired And writeStarted And safeToRestoreEntry Then
        eventsReadyForRecovery = _
            TryStopAnalysisWorkspaceEventsForBookWrites(eventStateDetail)
        If eventsReadyForRecovery Then
            On Error Resume Next
            Err.Clear
            MarkAnalysisReviewsDirty
            dirtyErrorNumber = Err.Number
            dirtyErrorDescription = Err.Description
            Err.Clear
            On Error GoTo 0
            If Not TryStopAnalysisWorkspaceEventsForBookWrites(eventStateDetail) Then
                safeToRestoreEntry = False
                AppendAnalysisWorkspaceRollbackDetail rollbackDetail, _
                    "dirty記録後にExcelイベント停止を確認できないため、" & _
                    "開始値へ戻しません: " & eventStateDetail
            End If
        Else
            safeToRestoreEntry = False
            AppendAnalysisWorkspaceRollbackDetail errorDescription, _
                "Excelイベント停止未確認のため、分析要更新状態の書込みを見送りました。"
        End If
    ElseIf writeStarted Then
        AppendAnalysisWorkspaceRollbackDetail errorDescription, _
            "ロールバック安全またはRecovery exactを確認できないため、" & _
            "分析要更新状態の書込みを見送りました。"
    End If

    '開始値へ戻すのは、変更前（未書込み）、完全ロールバック、Recovery exactのいずれかだけ。
    If eventsCaptured And safeToRestoreEntry Then
        If Not TryRestoreAnalysisWorkspaceEnableEvents( _
                   previousEvents, "CommitPendingAnalysisReviews/異常終了", _
                   recoveryAttempted, recoveryTerminalFailure, _
                   eventStateDetail) Then _
            AppendAnalysisWorkspaceRollbackDetail errorDescription, _
                "Excelイベント状態の復元エラー: " & eventStateDetail
        eventsCaptured = False
    ElseIf eventsCaptured Then
        If TryStopAnalysisWorkspaceEventsForBookWrites(eventStateDetail) Then
            AppendAnalysisWorkspaceRollbackDetail errorDescription, _
                "案件の安全状態を確認できないため、ExcelイベントをFalseのまま停止しました。"
        Else
            AppendAnalysisWorkspaceRollbackDetail errorDescription, _
                "案件の安全状態を確認できず、ExcelイベントのFalse収束にも失敗しました: " & _
                eventStateDetail
        End If
        eventsCaptured = False
    End If
    If Len(rollbackDetail) > 0 Then _
        errorDescription = errorDescription & " / ロールバック確認: " & rollbackDetail
    If dirtyErrorNumber <> 0 Then _
        errorDescription = errorDescription & " / 分析要更新状態の記録エラー: Err " & _
                           CStr(dirtyErrorNumber) & " " & dirtyErrorDescription
    If recoveryAttempted Or recoveryTerminalFailure Then _
        RaiseAnalysisWorkspaceLocalRecoveryFatal _
            "CommitPendingAnalysisReviews", errorNumber, errorSource, _
            errorDescription, rollbackDetail
    Err.Raise errorNumber, "CommitPendingAnalysisReviews", errorDescription
End Sub

Public Sub MarkAnalysisDetailReviewDirty()
    mAnalysisDetailReviewsDirty = True
    MarkAnalysisReviewsDirty
End Sub

Private Function AnalysisWorkspaceReviewsDifferFromSources() As Boolean
    Dim wsResult As Worksheet, wsSource As Worksheet
    Dim lastR As Long, r As Long, sourceRow As Long
    Dim sourceSheet As String, sourceKey As String
    Dim statusCol As Long, memoCol As Long, keyCol As Long
    Dim resultStatus As String, sourceStatus As String
    If Not SheetExists(SH_ANALYSIS_RESULT) Then Exit Function
    Set wsResult = GetSheet(SH_ANALYSIS_RESULT)
    lastR = LastUsedRowInSheet(wsResult)
    For r = 2 To lastR
        sourceSheet = CellText(wsResult.Cells(r, ANALYSIS_RESULT_SOURCE_SHEET_COL).Value)
        sourceRow = WorkspaceLong(wsResult.Cells(r, ANALYSIS_RESULT_SOURCE_ROW_COL).Value)
        sourceKey = CellText(wsResult.Cells(r, ANALYSIS_RESULT_SOURCE_KEY_COL).Value)
        If Not WorkspaceSourceColumns(sourceSheet, statusCol, memoCol, keyCol) Then
            AnalysisWorkspaceReviewsDifferFromSources = True
            Exit Function
        End If
        Set wsSource = GetSheet(sourceSheet)
        If sourceRow < 2 Or sourceRow > LastUsedRowInSheet(wsSource) Then
            AnalysisWorkspaceReviewsDifferFromSources = True
            Exit Function
        End If
        If StrComp(CellText(wsSource.Cells(sourceRow, keyCol).Value), _
                   sourceKey, vbBinaryCompare) <> 0 Then
            AnalysisWorkspaceReviewsDifferFromSources = True
            Exit Function
        End If
        resultStatus = WorkspaceStatusOrDefault( _
            wsResult.Cells(r, ANALYSIS_RESULT_STATUS_COL).Value)
        sourceStatus = WorkspaceStatusOrDefault(wsSource.Cells(sourceRow, statusCol).Value)
        If StrComp(resultStatus, sourceStatus, vbBinaryCompare) <> 0 Or _
           StrComp(CellText(wsResult.Cells(r, ANALYSIS_RESULT_MEMO_COL).Value), _
                   CellText(wsSource.Cells(sourceRow, memoCol).Value), _
                   vbBinaryCompare) <> 0 Then
            AnalysisWorkspaceReviewsDifferFromSources = True
            Exit Function
        End If
    Next r
End Function

Private Function AnalysisDetailReviewsDifferFromSources() As Boolean
    Dim wsDetail As Worksheet, wsSource As Worksheet
    Dim lastR As Long, r As Long, sourceRow As Long
    Dim sourceSheet As String, sourceKey As String
    Dim statusCol As Long, memoCol As Long, keyCol As Long
    Dim detailStatus As String, sourceStatus As String
    Dim detailMemo As String, sourceMemo As String
    If Not SheetExists(SH_ANALYSIS_DETAIL) Then Exit Function
    Set wsDetail = GetSheet(SH_ANALYSIS_DETAIL)
    lastR = LastUsedRowInSheet(wsDetail)
    For r = 2 To lastR
        If CellText(wsDetail.Cells(r, DETAIL_COL_KIND).Value) = "候補" Then
            sourceSheet = CellText(wsDetail.Cells(r, DETAIL_COL_REFERENCE).Value)
            sourceRow = WorkspaceLong(wsDetail.Cells(r, DETAIL_COL_SOURCE_ROW).Value)
            sourceKey = CellText(wsDetail.Cells(r, DETAIL_COL_SOURCE_KEY).Value)
            If Not WorkspaceSourceColumns(sourceSheet, statusCol, memoCol, keyCol) Then
                AnalysisDetailReviewsDifferFromSources = True
                Exit Function
            End If
            Set wsSource = GetSheet(sourceSheet)
            If sourceRow < 2 Or sourceRow > LastUsedRowInSheet(wsSource) Then
                AnalysisDetailReviewsDifferFromSources = True
                Exit Function
            End If
            If StrComp(CellText(wsSource.Cells(sourceRow, keyCol).Value), _
                       sourceKey, vbBinaryCompare) <> 0 Then
                AnalysisDetailReviewsDifferFromSources = True
                Exit Function
            End If
            If r + 1 > lastR Or _
               CellText(wsDetail.Cells(r + 1, DETAIL_COL_KIND).Value) <> "候補メモ" Then
                AnalysisDetailReviewsDifferFromSources = True
                Exit Function
            End If
            detailStatus = WorkspaceStatusOrDefault(wsDetail.Cells(r, 6).Value)
            sourceStatus = WorkspaceStatusOrDefault(wsSource.Cells(sourceRow, statusCol).Value)
            detailMemo = CellText(wsDetail.Cells(r + 1, 2).Value)
            sourceMemo = CellText(wsSource.Cells(sourceRow, memoCol).Value)
            If StrComp(detailStatus, sourceStatus, vbBinaryCompare) <> 0 Or _
               StrComp(detailMemo, sourceMemo, vbBinaryCompare) <> 0 Then
                AnalysisDetailReviewsDifferFromSources = True
                Exit Function
            End If
        End If
    Next r
End Function

Private Sub RefreshAnalysisReviewDisplaysFromSources()
    RefreshAnalysisResultReviewsFromSources
    RefreshAnalysisGroupReviewsFromSources
    RefreshAnalysisDetailReviewsFromSources
End Sub

Private Sub RefreshAnalysisResultReviewsFromSources()
    Dim wsResult As Worksheet, wsSource As Worksheet
    Dim lastR As Long, r As Long, sourceRow As Long
    Dim sourceSheet As String, sourceKey As String
    Dim statusCol As Long, memoCol As Long, keyCol As Long
    If Not SheetExists(SH_ANALYSIS_RESULT) Then Exit Sub
    Set wsResult = GetSheet(SH_ANALYSIS_RESULT)
    lastR = LastUsedRowInSheet(wsResult)
    If lastR < 2 Then Exit Sub
    wsResult.Unprotect Password:=TOOL_PASSWORD
    For r = 2 To lastR
        sourceSheet = CellText(wsResult.Cells(r, ANALYSIS_RESULT_SOURCE_SHEET_COL).Value)
        sourceRow = WorkspaceLong(wsResult.Cells(r, ANALYSIS_RESULT_SOURCE_ROW_COL).Value)
        sourceKey = CellText(wsResult.Cells(r, ANALYSIS_RESULT_SOURCE_KEY_COL).Value)
        ValidateAnalysisReviewReference sourceSheet, sourceRow, sourceKey, _
                                        statusCol, memoCol, keyCol, "分析結果", r
        Set wsSource = GetSheet(sourceSheet)
        wsResult.Cells(r, ANALYSIS_RESULT_STATUS_COL).Value = _
            WorkspaceStatusOrDefault(wsSource.Cells(sourceRow, statusCol).Value)
        wsResult.Cells(r, ANALYSIS_RESULT_MEMO_COL).Value = _
            CellText(wsSource.Cells(sourceRow, memoCol).Value)
    Next r
    ProtectSingleAnalysisSheet wsResult
End Sub

Private Sub RefreshAnalysisGroupReviewsFromSources()
    Dim wsGroup As Worksheet, wsSource As Worksheet
    Dim lastR As Long, r As Long, sourceRow As Long
    Dim sourceSheet As String, sourceKey As String
    Dim statusCol As Long, memoCol As Long, keyCol As Long
    If Not SheetExists(SH_WORK_ANALYSIS_GROUP) Then Exit Sub
    Set wsGroup = GetSheet(SH_WORK_ANALYSIS_GROUP)
    lastR = LastUsedRowInSheet(wsGroup)
    If lastR < 2 Then Exit Sub
    For r = 2 To lastR
        sourceSheet = CellText(wsGroup.Cells(r, 2).Value)
        sourceRow = WorkspaceLong(wsGroup.Cells(r, 3).Value)
        sourceKey = CellText(wsGroup.Cells(r, 4).Value)
        ValidateAnalysisReviewReference sourceSheet, sourceRow, sourceKey, _
                                        statusCol, memoCol, keyCol, "W_分析グループ", r
        Set wsSource = GetSheet(sourceSheet)
        wsGroup.Cells(r, 9).Value = _
            WorkspaceStatusOrDefault(wsSource.Cells(sourceRow, statusCol).Value)
        wsGroup.Cells(r, 10).Value = CellText(wsSource.Cells(sourceRow, memoCol).Value)
    Next r
    SetSheetVeryHiddenSafe wsGroup
End Sub

Private Sub RefreshAnalysisDetailReviewsFromSources()
    Dim wsDetail As Worksheet, wsSource As Worksheet
    Dim lastR As Long, r As Long, sourceRow As Long
    Dim sourceSheet As String, sourceKey As String
    Dim statusCol As Long, memoCol As Long, keyCol As Long
    If Not SheetExists(SH_ANALYSIS_DETAIL) Then Exit Sub
    Set wsDetail = GetSheet(SH_ANALYSIS_DETAIL)
    lastR = LastUsedRowInSheet(wsDetail)
    If lastR < 2 Then Exit Sub
    wsDetail.Unprotect Password:=TOOL_PASSWORD
    For r = 2 To lastR
        If CellText(wsDetail.Cells(r, DETAIL_COL_KIND).Value) = "候補" Then
            sourceSheet = CellText(wsDetail.Cells(r, DETAIL_COL_REFERENCE).Value)
            sourceRow = WorkspaceLong(wsDetail.Cells(r, DETAIL_COL_SOURCE_ROW).Value)
            sourceKey = CellText(wsDetail.Cells(r, DETAIL_COL_SOURCE_KEY).Value)
            ValidateAnalysisReviewReference sourceSheet, sourceRow, sourceKey, _
                                            statusCol, memoCol, keyCol, "候補詳細", r
            Set wsSource = GetSheet(sourceSheet)
            wsDetail.Cells(r, 6).Value = _
                WorkspaceStatusOrDefault(wsSource.Cells(sourceRow, statusCol).Value)
            If r + 1 <= lastR And _
               CellText(wsDetail.Cells(r + 1, DETAIL_COL_KIND).Value) = "候補メモ" Then _
                wsDetail.Cells(r + 1, 2).Value = CellText(wsSource.Cells(sourceRow, memoCol).Value)
        End If
    Next r
    ProtectSingleAnalysisSheet wsDetail
End Sub

Private Sub ValidateAnalysisReviewReference( _
        ByVal sourceSheet As String, ByVal sourceRow As Long, ByVal sourceKey As String, _
        ByRef statusCol As Long, ByRef memoCol As Long, ByRef keyCol As Long, _
        ByVal labelText As String, ByVal displayRow As Long)
    Dim wsSource As Worksheet
    If Not WorkspaceSourceColumns(sourceSheet, statusCol, memoCol, keyCol) Then _
        Err.Raise vbObjectError + 4821, "ValidateAnalysisReviewReference", _
                  labelText & " " & CStr(displayRow) & "行目の内部元表が不正です。"
    Set wsSource = GetSheet(sourceSheet)
    If sourceRow < 2 Or sourceRow > LastUsedRowInSheet(wsSource) Then _
        Err.Raise vbObjectError + 4822, "ValidateAnalysisReviewReference", _
                  labelText & " " & CStr(displayRow) & "行目の内部元行が見つかりません。"
    If Len(sourceKey) = 0 Or _
       StrComp(CellText(wsSource.Cells(sourceRow, keyCol).Value), _
               sourceKey, vbBinaryCompare) <> 0 Then _
        Err.Raise vbObjectError + 4823, "ValidateAnalysisReviewReference", _
                  labelText & " " & CStr(displayRow) & "行目の確認キーが一致しません。"
End Sub

Public Sub ToggleAnalysisDetailTransactionSelection(ByVal targetRow As Long)
    Dim ws As Worksheet, isSelected As Boolean, workbookWasSaved As Boolean
    Dim targetRows() As Long, snapshot As AnalysisDetailSelectionSnapshot
    Dim previousEvents As Boolean, eventsCaptured As Boolean
    Dim mutationStarted As Boolean, snapshotCaptured As Boolean
    Dim protectionConfirmed As Boolean, eventsRestored As Boolean
    Dim recoverySafeForEventRestore As Boolean
    Dim recoveryAttempted As Boolean, recoveryTerminalFailure As Boolean
    Dim workbookSavedCaptured As Boolean
    Dim c As Long, expectedColor As Long, expectedBold As Boolean
    Dim errorNumber As Long, errorDescription As String
    Dim errorSource As String, eventStateDetail As String
    Dim eventRestoreDetail As String, cleanupDetail As String
    If Not SheetExists(SH_ANALYSIS_DETAIL) Then Exit Sub
    Set ws = GetSheet(SH_ANALYSIS_DETAIL)
    If targetRow < 1 Or targetRow > LastUsedRowInSheet(ws) Then Exit Sub
    If CellText(ws.Cells(targetRow, DETAIL_COL_KIND).Value) <> "取引" Then Exit Sub
    If Not TryGetAnalysisWorkspaceEnableEvents( _
               previousEvents, eventStateDetail) Then
        On Error Resume Next
        MsgBox "取引選択の変更前にExcelイベントの開始状態を取得できませんでした。" & _
               vbCrLf & "ブックへの変更は行っていません。", _
               vbCritical, "Excelイベント状態を確認できません"
        On Error GoTo 0
        Err.Raise vbObjectError + 4901, _
                  "ToggleAnalysisDetailTransactionSelection", _
                  "Excelイベントの開始状態を取得できませんでした。 " & _
                  eventStateDetail
    End If
    eventsCaptured = True
    If Not TrySetAnalysisWorkspaceEnableEventsExact(False, eventStateDetail) Then
        errorDescription = _
            "取引選択の変更前にExcelイベントをFalseへ停止して" & _
            "読戻し確認できませんでした。ブックへの変更は行っていません。 " & _
            eventStateDetail
        eventsRestored = TryRestoreAnalysisWorkspaceEnableEvents( _
                             previousEvents, _
                             "ToggleAnalysisDetailTransactionSelection/変更開始前", _
                             recoveryAttempted, recoveryTerminalFailure, _
                             eventRestoreDetail)
        eventsCaptured = False
        If Not eventsRestored Then _
            AppendAnalysisWorkspaceRollbackDetail errorDescription, _
                "Excelイベント開始値の復元未完了: " & eventRestoreDetail
        If recoveryAttempted Or recoveryTerminalFailure Then _
            RaiseAnalysisWorkspaceLocalRecoveryFatal _
                "ToggleAnalysisDetailTransactionSelection", _
                vbObjectError + 4902, _
                "ToggleAnalysisDetailTransactionSelection", _
                errorDescription, eventRestoreDetail
        Err.Raise vbObjectError + 4902, _
                  "ToggleAnalysisDetailTransactionSelection", errorDescription
    End If
    On Error GoTo EH
    workbookWasSaved = ThisWorkbook.Saved
    workbookSavedCaptured = True
    ReDim targetRows(1 To 1)
    targetRows(1) = targetRow
    CaptureAnalysisDetailSelectionSnapshot ws, targetRows, 1, snapshot
    snapshotCaptured = True
    mutationStarted = True
    ws.Unprotect Password:=TOOL_PASSWORD
    isSelected = (CellText(ws.Cells(targetRow, DETAIL_COL_SELECTED).Value) = "1")
    If isSelected Then
        ws.Cells(targetRow, DETAIL_COL_SELECTED).Value = "0"
        ws.Range(ws.Cells(targetRow, 1), ws.Cells(targetRow, 7)).Interior.Color = vbWhite
        ws.Range(ws.Cells(targetRow, 1), ws.Cells(targetRow, 7)).Font.Bold = False
        expectedColor = vbWhite
        expectedBold = False
        If CellText(ws.Cells(targetRow, DETAIL_COL_SOURCE_KEY).Value) = "GLOBAL" Then _
            ws.Cells(targetRow, 1).Value = "未選択"
    Else
        ws.Cells(targetRow, DETAIL_COL_SELECTED).Value = "1"
        ws.Range(ws.Cells(targetRow, 1), ws.Cells(targetRow, 7)).Interior.Color = RGB(219, 234, 254)
        ws.Range(ws.Cells(targetRow, 1), ws.Cells(targetRow, 7)).Font.Bold = True
        expectedColor = RGB(219, 234, 254)
        expectedBold = True
        If CellText(ws.Cells(targetRow, DETAIL_COL_SOURCE_KEY).Value) = "GLOBAL" Then _
            ws.Cells(targetRow, 1).Value = "選択"
    End If
    If ws.Cells(targetRow, DETAIL_COL_SELECTED).HasFormula Or _
       Not StrictVariantValuesMatch( _
               IIf(isSelected, "0", "1"), _
               ws.Cells(targetRow, DETAIL_COL_SELECTED).Value2) Then _
        Err.Raise vbObjectError + 4903, _
                  "ToggleAnalysisDetailTransactionSelection", _
                  "取引選択フラグの書込読戻しが型まで一致しません。"
    If CellText(ws.Cells(targetRow, DETAIL_COL_SOURCE_KEY).Value) = "GLOBAL" Then
        If ws.Cells(targetRow, 1).HasFormula Or _
           Not StrictVariantValuesMatch( _
                   IIf(isSelected, "未選択", "選択"), _
                   ws.Cells(targetRow, 1).Value2) Then _
            Err.Raise vbObjectError + 4904, _
                      "ToggleAnalysisDetailTransactionSelection", _
                      "取引選択表示の書込読戻しが型まで一致しません。"
    End If
    For c = 1 To 7
        If CLng(ws.Cells(targetRow, c).Interior.Color) <> expectedColor Or _
           CBool(ws.Cells(targetRow, c).Font.Bold) <> expectedBold Then _
            Err.Raise vbObjectError + 4905, _
                      "ToggleAnalysisDetailTransactionSelection", _
                      "取引選択書式の書込読戻しが一致しません。"
    Next c
    RefreshManualSelectionSummary ws
    ProtectSingleAnalysisSheet ws
    protectionConfirmed = ws.ProtectContents And ws.ProtectDrawingObjects
    If Not protectionConfirmed Then _
        Err.Raise vbObjectError + 4906, _
                  "ToggleAnalysisDetailTransactionSelection", _
                  "取引選択変更後のセル・図形保護を両方Trueとして確認できません。"
    '選択色・内部フラグは一時的な画面状態なので、これだけで保存確認を発生させない。
    If workbookWasSaved Then
        ThisWorkbook.Saved = True
        If Not ThisWorkbook.Saved Then _
            Err.Raise vbObjectError + 4907, _
                      "ToggleAnalysisDetailTransactionSelection", _
                      "再保護後にブック保存状態を開始値へ復元できませんでした。"
    End If
    On Error GoTo 0
    eventsRestored = TryRestoreAnalysisWorkspaceEnableEvents( _
                         previousEvents, _
                         "ToggleAnalysisDetailTransactionSelection/正常終了", _
                         recoveryAttempted, recoveryTerminalFailure, _
                         eventRestoreDetail)
    eventsCaptured = False
    If recoveryAttempted Or recoveryTerminalFailure Then _
        RaiseAnalysisWorkspaceLocalRecoveryFatal _
            "ToggleAnalysisDetailTransactionSelection", _
            vbObjectError + 4908, _
            "ToggleAnalysisDetailTransactionSelection", _
            "正常終了時のExcelイベント開始値復元でlocal Recoveryを実行しました。", _
            eventRestoreDetail
    If Not eventsRestored Then _
        Err.Raise vbObjectError + 4908, _
                  "ToggleAnalysisDetailTransactionSelection", eventRestoreDetail
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    If IsAnalysisWorkspaceRecoveryFatalError(errorNumber, errorSource) Then _
        RethrowAnalysisWorkspaceUpstreamRecoveryFatal _
            errorNumber, errorSource, errorDescription, _
            "ToggleAnalysisDetailTransactionSelection"
    If eventsCaptured Then
        recoverySafeForEventRestore = False
        If TryStopAnalysisWorkspaceEventsForBookWrites(eventStateDetail) Then
            recoverySafeForEventRestore = _
                RecoverAnalysisDetailSelectionMutation( _
                    ws, snapshot, snapshotCaptured, mutationStarted, _
                    workbookSavedCaptured, workbookWasSaved, _
                    "ToggleAnalysisDetailTransactionSelection", _
                    errorNumber, errorSource, errorDescription, _
                    recoveryAttempted, recoveryTerminalFailure, cleanupDetail)
            AppendAnalysisWorkspaceRollbackDetail errorDescription, cleanupDetail
        Else
            AppendAnalysisWorkspaceRollbackDetail errorDescription, _
                "ExcelイベントをFalseへ停止して読戻し確認できないため、" & _
                "ロールバック・再保護・Recovery・診断・状態表示・" & _
                "保存状態への書込みを見送りました。案件の安全状態は不明です: " & _
                eventStateDetail
            On Error Resume Next
            MsgBox "取引選択の変更に失敗し、Excelイベントも安全に停止できませんでした。" & _
                   vbCrLf & "ブックへの復旧書込みは行っていません。" & _
                   vbCrLf & "現在のブックを上書きしないでください。", _
                   vbCritical, "取引選択の安全状態を確認できません"
            On Error GoTo 0
        End If
        If recoverySafeForEventRestore Then
            eventsRestored = TryRestoreAnalysisWorkspaceEnableEvents( _
                                 previousEvents, _
                                 "ToggleAnalysisDetailTransactionSelection/異常終了", _
                                 recoveryAttempted, recoveryTerminalFailure, _
                                 eventRestoreDetail)
        Else
            eventsRestored = False
            If TryStopAnalysisWorkspaceEventsForBookWrites(eventRestoreDetail) Then
                AppendAnalysisWorkspaceRollbackDetail errorDescription, _
                    "ロールバック安全またはRecovery exactを確認できないため、" & _
                    "ExcelイベントをFalseのまま停止しました。"
                eventRestoreDetail = _
                    "安全状態未確認のため開始値への復元を実行していません。"
            Else
                AppendAnalysisWorkspaceRollbackDetail errorDescription, _
                    "安全状態を確認できず、ExcelイベントのFalse収束にも失敗しました: " & _
                    eventRestoreDetail
            End If
        End If
        eventsCaptured = False
        If Not eventsRestored Then _
            AppendAnalysisWorkspaceRollbackDetail errorDescription, _
                "Excelイベント復元処理を正常完了として扱えません: " & eventRestoreDetail
    End If
    If recoveryAttempted Or recoveryTerminalFailure Then _
        RaiseAnalysisWorkspaceLocalRecoveryFatal _
            "ToggleAnalysisDetailTransactionSelection", _
            errorNumber, errorSource, errorDescription, _
            cleanupDetail & " / " & eventRestoreDetail
    Err.Raise errorNumber, "ToggleAnalysisDetailTransactionSelection", _
              IIf(Len(errorSource) > 0, _
                  errorSource & " / ", vbNullString) & errorDescription
End Sub

Public Function HasSelectedAnalysisDetailTransactions() As Boolean
    Dim ws As Worksheet, lastR As Long, r As Long
    Dim selectionData As Variant
    If Not SheetExists(SH_ANALYSIS_DETAIL) Then Exit Function
    Set ws = GetSheet(SH_ANALYSIS_DETAIL)
    '保存・再オープン後は候補詳細を非表示へ戻すが、未登録の選択フラグまで
    '無かったものとして扱わない。表示状態にかかわらず内部列を走査する。
    lastR = LastUsedRowInSheet(ws)
    If lastR < 1 Then Exit Function
    selectionData = ws.Range(ws.Cells(1, DETAIL_COL_KIND), _
                             ws.Cells(lastR, DETAIL_COL_SELECTED)).Value2
    For r = 1 To UBound(selectionData, 1)
        If CellText(selectionData(r, 1)) = "取引" And _
           CellText(selectionData(r, DETAIL_COL_SELECTED - DETAIL_COL_KIND + 1)) = "1" Then
            HasSelectedAnalysisDetailTransactions = True
            Exit Function
        End If
    Next r
End Function

Public Sub ClearAnalysisDetailTransactionSelections()
    Dim ws As Worksheet, lastR As Long, r As Long, workbookWasSaved As Boolean
    Dim selectionData As Variant
    Dim selectedRows() As Long, selectedCount As Long, selectedIndex As Long
    Dim snapshot As AnalysisDetailSelectionSnapshot
    Dim previousEvents As Boolean, eventsCaptured As Boolean
    Dim mutationStarted As Boolean, snapshotCaptured As Boolean
    Dim protectionConfirmed As Boolean, eventsRestored As Boolean
    Dim recoverySafeForEventRestore As Boolean
    Dim recoveryAttempted As Boolean, recoveryTerminalFailure As Boolean
    Dim workbookSavedCaptured As Boolean, c As Long
    Dim errorNumber As Long, errorDescription As String
    Dim errorSource As String, eventStateDetail As String
    Dim eventRestoreDetail As String, cleanupDetail As String
    If Not SheetExists(SH_ANALYSIS_DETAIL) Then Exit Sub
    Set ws = GetSheet(SH_ANALYSIS_DETAIL)
    lastR = LastUsedRowInSheet(ws)
    If lastR >= 1 Then
        selectionData = ws.Range(ws.Cells(1, DETAIL_COL_KIND), _
                                 ws.Cells(lastR, DETAIL_COL_SELECTED)).Value2
        For r = 1 To UBound(selectionData, 1)
            If CellText(selectionData(r, 1)) = "取引" And _
               CellText(selectionData( _
                            r, DETAIL_COL_SELECTED - DETAIL_COL_KIND + 1)) = "1" Then _
                selectedCount = selectedCount + 1
        Next r
        If selectedCount > 0 Then
            ReDim selectedRows(1 To selectedCount)
            For r = 1 To UBound(selectionData, 1)
                If CellText(selectionData(r, 1)) = "取引" And _
                   CellText(selectionData( _
                                r, DETAIL_COL_SELECTED - DETAIL_COL_KIND + 1)) = "1" Then
                    selectedIndex = selectedIndex + 1
                    selectedRows(selectedIndex) = r
                End If
            Next r
        End If
    End If
    If Not TryGetAnalysisWorkspaceEnableEvents( _
               previousEvents, eventStateDetail) Then
        On Error Resume Next
        MsgBox "取引選択の解除前にExcelイベントの開始状態を取得できませんでした。" & _
               vbCrLf & "ブックへの変更は行っていません。", _
               vbCritical, "Excelイベント状態を確認できません"
        On Error GoTo 0
        Err.Raise vbObjectError + 4909, _
                  "ClearAnalysisDetailTransactionSelections", _
                  "Excelイベントの開始状態を取得できませんでした。 " & _
                  eventStateDetail
    End If
    eventsCaptured = True
    If Not TrySetAnalysisWorkspaceEnableEventsExact(False, eventStateDetail) Then
        errorDescription = _
            "取引選択の解除前にExcelイベントをFalseへ停止して" & _
            "読戻し確認できませんでした。ブックへの変更は行っていません。 " & _
            eventStateDetail
        eventsRestored = TryRestoreAnalysisWorkspaceEnableEvents( _
                             previousEvents, _
                             "ClearAnalysisDetailTransactionSelections/変更開始前", _
                             recoveryAttempted, recoveryTerminalFailure, _
                             eventRestoreDetail)
        eventsCaptured = False
        If Not eventsRestored Then _
            AppendAnalysisWorkspaceRollbackDetail errorDescription, _
                "Excelイベント開始値の復元未完了: " & eventRestoreDetail
        If recoveryAttempted Or recoveryTerminalFailure Then _
            RaiseAnalysisWorkspaceLocalRecoveryFatal _
                "ClearAnalysisDetailTransactionSelections", _
                vbObjectError + 4910, _
                "ClearAnalysisDetailTransactionSelections", _
                errorDescription, eventRestoreDetail
        Err.Raise vbObjectError + 4910, _
                  "ClearAnalysisDetailTransactionSelections", errorDescription
    End If
    On Error GoTo EH
    workbookWasSaved = ThisWorkbook.Saved
    workbookSavedCaptured = True
    CaptureAnalysisDetailSelectionSnapshot _
        ws, selectedRows, selectedCount, snapshot
    snapshotCaptured = True
    mutationStarted = True
    ws.Unprotect Password:=TOOL_PASSWORD
    For selectedIndex = 1 To selectedCount
        r = selectedRows(selectedIndex)
        ws.Cells(r, DETAIL_COL_SELECTED).Value2 = "0"
        If CellText(selectionData( _
                        r, DETAIL_COL_SOURCE_KEY - DETAIL_COL_KIND + 1)) = "GLOBAL" Then _
            ws.Cells(r, 1).Value2 = "未選択"
        '書式更新は選択されていた少数行だけに限定する。
        ws.Range(ws.Cells(r, 1), ws.Cells(r, 7)).Interior.Color = vbWhite
        ws.Range(ws.Cells(r, 1), ws.Cells(r, 7)).Font.Bold = False
        If ws.Cells(r, DETAIL_COL_SELECTED).HasFormula Or _
           Not StrictVariantValuesMatch( _
                   "0", ws.Cells(r, DETAIL_COL_SELECTED).Value2) Then _
            Err.Raise vbObjectError + 4911, _
                      "ClearAnalysisDetailTransactionSelections", _
                      CStr(r) & "行目の取引選択フラグを厳密に解除できません。"
        If CellText(selectionData( _
                        r, DETAIL_COL_SOURCE_KEY - DETAIL_COL_KIND + 1)) = "GLOBAL" Then
            If ws.Cells(r, 1).HasFormula Or _
               Not StrictVariantValuesMatch("未選択", ws.Cells(r, 1).Value2) Then _
                Err.Raise vbObjectError + 4912, _
                          "ClearAnalysisDetailTransactionSelections", _
                          CStr(r) & "行目の取引選択表示を厳密に解除できません。"
        End If
        For c = 1 To 7
            If CLng(ws.Cells(r, c).Interior.Color) <> vbWhite Or _
               CBool(ws.Cells(r, c).Font.Bold) Then _
                Err.Raise vbObjectError + 4913, _
                          "ClearAnalysisDetailTransactionSelections", _
                          CStr(r) & "行目の取引選択書式を厳密に解除できません。"
        Next c
    Next selectedIndex
    RefreshManualSelectionSummary ws
    ProtectSingleAnalysisSheet ws
    protectionConfirmed = ws.ProtectContents And ws.ProtectDrawingObjects
    If Not protectionConfirmed Then _
        Err.Raise vbObjectError + 4914, _
                  "ClearAnalysisDetailTransactionSelections", _
                  "取引選択解除後のセル・図形保護を両方Trueとして確認できません。"
    If workbookWasSaved Then
        ThisWorkbook.Saved = True
        If Not ThisWorkbook.Saved Then _
            Err.Raise vbObjectError + 4915, _
                      "ClearAnalysisDetailTransactionSelections", _
                      "再保護後にブック保存状態を開始値へ復元できませんでした。"
    End If
    On Error GoTo 0
    eventsRestored = TryRestoreAnalysisWorkspaceEnableEvents( _
                         previousEvents, _
                         "ClearAnalysisDetailTransactionSelections/正常終了", _
                         recoveryAttempted, recoveryTerminalFailure, _
                         eventRestoreDetail)
    eventsCaptured = False
    If recoveryAttempted Or recoveryTerminalFailure Then _
        RaiseAnalysisWorkspaceLocalRecoveryFatal _
            "ClearAnalysisDetailTransactionSelections", _
            vbObjectError + 4916, _
            "ClearAnalysisDetailTransactionSelections", _
            "正常終了時のExcelイベント開始値復元でlocal Recoveryを実行しました。", _
            eventRestoreDetail
    If Not eventsRestored Then _
        Err.Raise vbObjectError + 4916, _
                  "ClearAnalysisDetailTransactionSelections", eventRestoreDetail
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    If IsAnalysisWorkspaceRecoveryFatalError(errorNumber, errorSource) Then _
        RethrowAnalysisWorkspaceUpstreamRecoveryFatal _
            errorNumber, errorSource, errorDescription, _
            "ClearAnalysisDetailTransactionSelections"
    If eventsCaptured Then
        recoverySafeForEventRestore = False
        If TryStopAnalysisWorkspaceEventsForBookWrites(eventStateDetail) Then
            recoverySafeForEventRestore = _
                RecoverAnalysisDetailSelectionMutation( _
                    ws, snapshot, snapshotCaptured, mutationStarted, _
                    workbookSavedCaptured, workbookWasSaved, _
                    "ClearAnalysisDetailTransactionSelections", _
                    errorNumber, errorSource, errorDescription, _
                    recoveryAttempted, recoveryTerminalFailure, cleanupDetail)
            AppendAnalysisWorkspaceRollbackDetail errorDescription, cleanupDetail
        Else
            AppendAnalysisWorkspaceRollbackDetail errorDescription, _
                "ExcelイベントをFalseへ停止して読戻し確認できないため、" & _
                "ロールバック・再保護・Recovery・診断・状態表示・" & _
                "保存状態への書込みを見送りました。案件の安全状態は不明です: " & _
                eventStateDetail
            On Error Resume Next
            MsgBox "取引選択の解除に失敗し、Excelイベントも安全に停止できませんでした。" & _
                   vbCrLf & "ブックへの復旧書込みは行っていません。" & _
                   vbCrLf & "現在のブックを上書きしないでください。", _
                   vbCritical, "取引選択の安全状態を確認できません"
            On Error GoTo 0
        End If
        If recoverySafeForEventRestore Then
            eventsRestored = TryRestoreAnalysisWorkspaceEnableEvents( _
                                 previousEvents, _
                                 "ClearAnalysisDetailTransactionSelections/異常終了", _
                                 recoveryAttempted, recoveryTerminalFailure, _
                                 eventRestoreDetail)
        Else
            eventsRestored = False
            If TryStopAnalysisWorkspaceEventsForBookWrites(eventRestoreDetail) Then
                AppendAnalysisWorkspaceRollbackDetail errorDescription, _
                    "ロールバック安全またはRecovery exactを確認できないため、" & _
                    "ExcelイベントをFalseのまま停止しました。"
                eventRestoreDetail = _
                    "安全状態未確認のため開始値への復元を実行していません。"
            Else
                AppendAnalysisWorkspaceRollbackDetail errorDescription, _
                    "安全状態を確認できず、ExcelイベントのFalse収束にも失敗しました: " & _
                    eventRestoreDetail
            End If
        End If
        eventsCaptured = False
        If Not eventsRestored Then _
            AppendAnalysisWorkspaceRollbackDetail errorDescription, _
                "Excelイベント復元処理を正常完了として扱えません: " & eventRestoreDetail
    End If
    If recoveryAttempted Or recoveryTerminalFailure Then _
        RaiseAnalysisWorkspaceLocalRecoveryFatal _
            "ClearAnalysisDetailTransactionSelections", _
            errorNumber, errorSource, errorDescription, _
            cleanupDetail & " / " & eventRestoreDetail
    Err.Raise errorNumber, "ClearAnalysisDetailTransactionSelections", _
              IIf(Len(errorSource) > 0, _
                  errorSource & " / ", vbNullString) & errorDescription
End Sub

Private Sub CaptureAnalysisDetailSelectionSnapshot( _
        ByVal ws As Worksheet, ByRef targetRows() As Long, _
        ByVal itemCount As Long, _
        ByRef snapshot As AnalysisDetailSelectionSnapshot)
    Dim i As Long, c As Long, formatIndex As Long, targetRow As Long
    Dim targetCell As Range
    If ws Is Nothing Or itemCount < 0 Then _
        Err.Raise vbObjectError + 4917, _
                  "CaptureAnalysisDetailSelectionSnapshot", _
                  "取引選択状態の退避条件が不正です。"
    snapshot.ItemCount = itemCount
    If itemCount > 0 Then
        ReDim snapshot.Rows(1 To itemCount)
        ReDim snapshot.SelectedValues(1 To itemCount)
        ReDim snapshot.SelectedHasFormula(1 To itemCount)
        ReDim snapshot.SelectedFormulas(1 To itemCount)
        ReDim snapshot.DisplayValues(1 To itemCount)
        ReDim snapshot.DisplayHasFormula(1 To itemCount)
        ReDim snapshot.DisplayFormulas(1 To itemCount)
        ReDim snapshot.FillColors(1 To itemCount * 7)
        ReDim snapshot.FillPatterns(1 To itemCount * 7)
        ReDim snapshot.FillTints(1 To itemCount * 7)
        ReDim snapshot.FontBolds(1 To itemCount * 7)
    End If
    For i = 1 To itemCount
        targetRow = targetRows(i)
        If targetRow < 1 Or targetRow > LastUsedRowInSheet(ws) Then _
            Err.Raise vbObjectError + 4918, _
                      "CaptureAnalysisDetailSelectionSnapshot", _
                      "取引選択状態を退避する行が不正です: " & CStr(targetRow)
        snapshot.Rows(i) = targetRow
        Set targetCell = ws.Cells(targetRow, DETAIL_COL_SELECTED)
        snapshot.SelectedValues(i) = targetCell.Value2
        snapshot.SelectedHasFormula(i) = targetCell.HasFormula
        If snapshot.SelectedHasFormula(i) Then _
            snapshot.SelectedFormulas(i) = CStr(targetCell.Formula)
        Set targetCell = ws.Cells(targetRow, 1)
        snapshot.DisplayValues(i) = targetCell.Value2
        snapshot.DisplayHasFormula(i) = targetCell.HasFormula
        If snapshot.DisplayHasFormula(i) Then _
            snapshot.DisplayFormulas(i) = CStr(targetCell.Formula)
        For c = 1 To 7
            formatIndex = (i - 1) * 7 + c
            Set targetCell = ws.Cells(targetRow, c)
            snapshot.FillColors(formatIndex) = CLng(targetCell.Interior.Color)
            snapshot.FillPatterns(formatIndex) = CLng(targetCell.Interior.Pattern)
            snapshot.FillTints(formatIndex) = CDbl(targetCell.Interior.TintAndShade)
            snapshot.FontBolds(formatIndex) = CBool(targetCell.Font.Bold)
        Next c
    Next i
    Set targetCell = ws.Range("A2")
    snapshot.SummaryValue = targetCell.Value2
    snapshot.SummaryHasFormula = targetCell.HasFormula
    If snapshot.SummaryHasFormula Then _
        snapshot.SummaryFormula = CStr(targetCell.Formula)
End Sub

Private Function TryRestoreAnalysisDetailSelectionSnapshot( _
        ByVal ws As Worksheet, _
        ByRef snapshot As AnalysisDetailSelectionSnapshot, _
        ByRef detailText As String) As Boolean
    Dim i As Long, c As Long, formatIndex As Long, targetRow As Long
    Dim targetCell As Range
    detailText = vbNullString
    On Error GoTo EH
    If ws Is Nothing Or snapshot.ItemCount < 0 Then _
        Err.Raise vbObjectError + 4919, _
                  "TryRestoreAnalysisDetailSelectionSnapshot", _
                  "取引選択状態の復元条件が不正です。"
    ws.Unprotect Password:=TOOL_PASSWORD
    For i = 1 To snapshot.ItemCount
        targetRow = snapshot.Rows(i)
        Set targetCell = ws.Cells(targetRow, DETAIL_COL_SELECTED)
        RestoreAnalysisDetailSelectionCell targetCell, _
            snapshot.SelectedValues(i), snapshot.SelectedHasFormula(i), _
            snapshot.SelectedFormulas(i), _
            CStr(targetRow) & "行目の選択フラグ"
        Set targetCell = ws.Cells(targetRow, 1)
        RestoreAnalysisDetailSelectionCell targetCell, _
            snapshot.DisplayValues(i), snapshot.DisplayHasFormula(i), _
            snapshot.DisplayFormulas(i), _
            CStr(targetRow) & "行目の選択表示"
        For c = 1 To 7
            formatIndex = (i - 1) * 7 + c
            Set targetCell = ws.Cells(targetRow, c)
            With targetCell.Interior
                .Color = snapshot.FillColors(formatIndex)
                .TintAndShade = snapshot.FillTints(formatIndex)
                .Pattern = snapshot.FillPatterns(formatIndex)
            End With
            targetCell.Font.Bold = snapshot.FontBolds(formatIndex)
            If CLng(targetCell.Interior.Pattern) <> _
                   snapshot.FillPatterns(formatIndex) Then _
                Err.Raise vbObjectError + 4920, _
                          "TryRestoreAnalysisDetailSelectionSnapshot", _
                          CStr(targetRow) & "行目の塗りパターンを復元できません。"
            If snapshot.FillPatterns(formatIndex) <> xlNone Then
                If CLng(targetCell.Interior.Color) <> _
                       snapshot.FillColors(formatIndex) Or _
                   CDbl(targetCell.Interior.TintAndShade) <> _
                       snapshot.FillTints(formatIndex) Then _
                    Err.Raise vbObjectError + 4921, _
                              "TryRestoreAnalysisDetailSelectionSnapshot", _
                              CStr(targetRow) & "行目の塗り色を復元できません。"
            End If
            If CBool(targetCell.Font.Bold) <> _
                   snapshot.FontBolds(formatIndex) Then _
                Err.Raise vbObjectError + 4922, _
                          "TryRestoreAnalysisDetailSelectionSnapshot", _
                          CStr(targetRow) & "行目の太字状態を復元できません。"
        Next c
    Next i
    RestoreAnalysisDetailSelectionCell ws.Range("A2"), _
        snapshot.SummaryValue, snapshot.SummaryHasFormula, _
        snapshot.SummaryFormula, "手動登録の選択集計"
    TryRestoreAnalysisDetailSelectionSnapshot = True
    Exit Function
EH:
    detailText = "取引選択状態の復元エラー: Err " & _
                 CStr(Err.Number) & " " & Err.Description
    Err.Clear
End Function

Private Sub RestoreAnalysisDetailSelectionCell( _
        ByVal targetCell As Range, ByVal expectedValue As Variant, _
        ByVal expectedHasFormula As Boolean, ByVal expectedFormula As String, _
        ByVal labelText As String)
    If targetCell Is Nothing Then _
        Err.Raise vbObjectError + 4923, "RestoreAnalysisDetailSelectionCell", _
                  labelText & "の復元先を取得できません。"
    If targetCell.Cells.CountLarge <> 1 Then _
        Err.Raise vbObjectError + 4923, _
                  "RestoreAnalysisDetailSelectionCell", _
                  labelText & "の復元先が単一セルではありません。"
    If expectedHasFormula Then
        targetCell.Formula = expectedFormula
        If Not targetCell.HasFormula Or _
           StrComp(CStr(targetCell.Formula), _
                   expectedFormula, vbBinaryCompare) <> 0 Then _
            Err.Raise vbObjectError + 4924, _
                      "RestoreAnalysisDetailSelectionCell", _
                      labelText & "の数式を厳密に復元できません。"
    Else
        targetCell.Value2 = expectedValue
        If targetCell.HasFormula Or _
           Not StrictVariantValuesMatch(expectedValue, targetCell.Value2) Then _
            Err.Raise vbObjectError + 4925, _
                      "RestoreAnalysisDetailSelectionCell", _
                      labelText & "の値を型まで厳密に復元できません。"
    End If
End Sub

Private Function TryEmergencyProtectAnalysisDetailSelectionSheet( _
        ByVal ws As Worksheet, ByRef detailText As String) As Boolean
    detailText = vbNullString
    On Error GoTo EH
    If ws Is Nothing Then _
        Err.Raise vbObjectError + 4926, _
                  "TryEmergencyProtectAnalysisDetailSelectionSheet", _
                  "緊急再保護する候補詳細シートを取得できません。"
    EmergencyProtectToolSheet ws
    If Not ws.ProtectContents Or Not ws.ProtectDrawingObjects Then _
        Err.Raise vbObjectError + 4927, _
                  "TryEmergencyProtectAnalysisDetailSelectionSheet", _
                  "緊急再保護後のセル・図形保護を両方Trueとして確認できません。"
    TryEmergencyProtectAnalysisDetailSelectionSheet = True
    Exit Function
EH:
    detailText = "候補詳細の緊急再保護エラー: Err " & _
                 CStr(Err.Number) & " " & Err.Description
    Err.Clear
End Function

Private Function RecoverAnalysisDetailSelectionMutation( _
        ByVal ws As Worksheet, _
        ByRef snapshot As AnalysisDetailSelectionSnapshot, _
        ByVal snapshotCaptured As Boolean, ByVal mutationStarted As Boolean, _
        ByVal workbookSavedCaptured As Boolean, ByVal workbookWasSaved As Boolean, _
        ByVal operationName As String, _
        ByVal originalErrorNumber As Long, _
        ByVal originalErrorSource As String, _
        ByVal originalErrorDescription As String, _
        ByRef recoveryAttempted As Boolean, _
        ByRef recoveryTerminalFailure As Boolean, _
        ByRef detailText As String) As Boolean
    Dim rollbackOK As Boolean, protectionOK As Boolean
    Dim savedRestored As Boolean, recoveryCallOK As Boolean
    Dim rollbackDetail As String, protectionDetail As String
    Dim recoveryDetail As String, savedDetail As String
    Dim savedErrorNumber As Long, savedErrorDescription As String
    detailText = vbNullString
    If Not mutationStarted Then
        RecoverAnalysisDetailSelectionMutation = True
        Exit Function
    End If
    If snapshotCaptured Then
        rollbackOK = TryRestoreAnalysisDetailSelectionSnapshot( _
                         ws, snapshot, rollbackDetail)
    Else
        rollbackDetail = "取引選択状態の退避がないため復元できません。"
    End If
    protectionOK = _
        TryEmergencyProtectAnalysisDetailSelectionSheet(ws, protectionDetail)
    If rollbackOK And protectionOK Then
        AppendAnalysisWorkspaceRollbackDetail detailText, _
            "取引選択状態を開始値へ復元し、セル・図形の再保護を確認しました。"
        If workbookSavedCaptured And workbookWasSaved Then
            On Error Resume Next
            Err.Clear
            ThisWorkbook.Saved = True
            savedErrorNumber = Err.Number
            savedErrorDescription = Err.Description
            Err.Clear
            If savedErrorNumber = 0 Then
                savedRestored = ThisWorkbook.Saved
                savedErrorNumber = Err.Number
                savedErrorDescription = Err.Description
                Err.Clear
            End If
            On Error GoTo 0
            If Not savedRestored Then
                savedDetail = "再保護後の保存状態を開始値へ復元できません。"
                If savedErrorNumber <> 0 Then _
                    savedDetail = savedDetail & " Err " & _
                                  CStr(savedErrorNumber) & " " & savedErrorDescription
                AppendAnalysisWorkspaceRollbackDetail detailText, savedDetail
            End If
        End If
        RecoverAnalysisDetailSelectionMutation = True
        Exit Function
    End If
    AppendAnalysisWorkspaceRollbackDetail recoveryDetail, rollbackDetail
    AppendAnalysisWorkspaceRollbackDetail recoveryDetail, protectionDetail
    If Not rollbackOK Then _
        AppendAnalysisWorkspaceRollbackDetail recoveryDetail, _
            "取引選択状態を開始値へ厳密に復元できません。"
    If Not protectionOK Then _
        AppendAnalysisWorkspaceRollbackDetail recoveryDetail, _
            "候補詳細のセル・図形保護を両方Trueとして確認できません。"
    recoveryCallOK = StopAfterAnalysisWorkspaceEventStateFailure( _
                         operationName & "/ロールバックまたは再保護", _
                         recoveryDetail, recoveryAttempted, _
                         recoveryTerminalFailure, originalErrorNumber, _
                         originalErrorSource, originalErrorDescription)
    If Not recoveryCallOK Then _
        AppendAnalysisWorkspaceRollbackDetail recoveryDetail, _
            "独立ラッチと案件healthのRecovery状態を厳密確認できませんでした。"
    AppendAnalysisWorkspaceRollbackDetail detailText, recoveryDetail
    RecoverAnalysisDetailSelectionMutation = recoveryCallOK
End Function

Private Sub RefreshManualSelectionSummary(ByVal ws As Worksheet)
    Dim lastR As Long, r As Long
    Dim withdrawalIndex As Long, depositIndex As Long
    Dim withdrawalValue As Double, depositValue As Double
    Dim withdrawCount As Long, depositCount As Long
    Dim withdrawTotal As Double, depositTotal As Double
    Dim summaryData As Variant
    If ws Is Nothing Then Exit Sub
    If CellText(ws.Cells(2, DETAIL_COL_KIND).Value) <> "手動登録" Then Exit Sub
    lastR = LastUsedRowInSheet(ws)
    If lastR >= MANUAL_BUILDER_HEADER_ROW + 1 Then
        'ダブルクリックのたびに最大5万行をセル単位で読むと操作が止まるため、
        '表示列D～Gと内部列H～Lを一度だけ配列へ読み込んで集計する。
        summaryData = ws.Range( _
            ws.Cells(MANUAL_BUILDER_HEADER_ROW + 1, 4), _
            ws.Cells(lastR, DETAIL_COL_SELECTED)).Value2
        For r = 1 To UBound(summaryData, 1)
            If CellText(summaryData(r, DETAIL_COL_KIND - 4 + 1)) = "取引" And _
               CellText(summaryData(r, DETAIL_COL_SELECTED - 4 + 1)) = "1" Then
                If CellText(summaryData(r, DETAIL_COL_SOURCE_KEY - 4 + 1)) = "GLOBAL" Then
                    withdrawalIndex = 1
                    depositIndex = 2
                Else
                    withdrawalIndex = 2
                    depositIndex = 3
                End If
                withdrawalValue = WorkspaceDouble(summaryData(r, withdrawalIndex))
                depositValue = WorkspaceDouble(summaryData(r, depositIndex))
                If withdrawalValue > 0 Then
                    withdrawCount = withdrawCount + 1
                    withdrawTotal = withdrawTotal + withdrawalValue
                End If
                If depositValue > 0 Then
                    depositCount = depositCount + 1
                    depositTotal = depositTotal + depositValue
                End If
            End If
        Next r
    End If
    If withdrawCount + depositCount = 0 Then
        ws.Range("A2").Value = _
            "取引をダブルクリックして選択 → この案内行をダブルクリックして登録"
    Else
        ws.Range("A2").Value = "選択中：出金 " & CStr(withdrawCount) & "件 " & _
            Format$(withdrawTotal, "#,##0.########") & "円　／　入金 " & _
            CStr(depositCount) & "件 " & Format$(depositTotal, "#,##0.########") & _
            "円　／　差額 " & Format$(depositTotal - withdrawTotal, "+#,##0.########;-#,##0.########;0") & _
            "円　｜　この行をダブルクリックして登録"
    End If
End Sub

Public Function IsManualAnalysisDetailAlternative(ByVal targetRow As Long) As Boolean
    Dim wsDetail As Worksheet, wsFlow As Worksheet, sourceRow As Long
    If Not SheetExists(SH_ANALYSIS_DETAIL) Or Not SheetExists(SH_ANALYSIS_FLOW) Then Exit Function
    Set wsDetail = GetSheet(SH_ANALYSIS_DETAIL)
    If targetRow < 1 Or targetRow > LastUsedRowInSheet(wsDetail) Then Exit Function
    If CellText(wsDetail.Cells(targetRow, DETAIL_COL_KIND).Value) <> "候補" Or _
       CellText(wsDetail.Cells(targetRow, DETAIL_COL_REFERENCE).Value) <> SH_ANALYSIS_FLOW Then Exit Function
    sourceRow = WorkspaceLong(wsDetail.Cells(targetRow, DETAIL_COL_SOURCE_ROW).Value)
    Set wsFlow = GetSheet(SH_ANALYSIS_FLOW)
    If sourceRow >= 2 And sourceRow <= LastUsedRowInSheet(wsFlow) Then _
        IsManualAnalysisDetailAlternative = _
            (CellText(wsFlow.Cells(sourceRow, 3).Value) = "手動指定")
End Function

Public Function AnalysisDetailStoredKey(ByVal targetRow As Long) As String
    If SheetExists(SH_ANALYSIS_DETAIL) Then _
        AnalysisDetailStoredKey = CellText(GetSheet(SH_ANALYSIS_DETAIL).Cells( _
                                                   targetRow, DETAIL_COL_SOURCE_KEY).Value)
End Function

Private Sub SyncWorkspaceSourceReviews(ByRef resultData As Variant, ByVal resultCount As Long, _
                                       ByVal targetSheetName As String)
    Dim wsSource As Worksheet, lastR As Long, sourceDataRows As Long
    Dim statusCol As Long, memoCol As Long, keyCol As Long
    Dim keyValues As Variant, seenTargets As Object
    Dim planRows() As Long, planStatuses() As String, planMemos() As String
    Dim planCount As Long, targetID As String
    Dim r As Long, sourceRow As Long, sourceIndex As Long
    Dim sourceKey As String, statusText As String, memoText As String, categoryText As String
    If Not WorkspaceSourceColumns(targetSheetName, statusCol, memoCol, keyCol) Then Exit Sub
    If resultCount < 1 Then Exit Sub
    Set wsSource = GetSheet(targetSheetName)
    If Not TryGetLastUsedRowInSheet(wsSource, lastR) Then _
        Err.Raise vbObjectError + 4806, "SyncWorkspaceSourceReviews", _
                  targetSheetName & "の最終行を確認できません。"
    If lastR < 2 Then
        For r = 1 To resultCount
            If StrComp(CellText(resultData(r, ANALYSIS_RESULT_SOURCE_SHEET_COL)), _
                       targetSheetName, vbTextCompare) = 0 Then _
                Err.Raise vbObjectError + 4806, "SyncWorkspaceSourceReviews", _
                          "分析結果 " & CStr(r + 1) & "行目の内部元表に候補がありません。"
        Next r
        Exit Sub
    End If
    sourceDataRows = lastR - 1
    keyValues = wsSource.Range(wsSource.Cells(2, keyCol), wsSource.Cells(lastR, keyCol)).Value2
    ReDim planRows(1 To resultCount)
    ReDim planStatuses(1 To resultCount)
    ReDim planMemos(1 To resultCount)
    Set seenTargets = CreateObject("Scripting.Dictionary")
    seenTargets.CompareMode = vbTextCompare
    For r = 1 To resultCount
        If StrComp(CellText(resultData(r, ANALYSIS_RESULT_SOURCE_SHEET_COL)), _
                   targetSheetName, vbTextCompare) = 0 Then
            sourceRow = WorkspaceLong(resultData(r, ANALYSIS_RESULT_SOURCE_ROW_COL))
            sourceIndex = sourceRow - 1
            If sourceIndex < 1 Or sourceIndex > sourceDataRows Then _
                Err.Raise vbObjectError + 4806, "SyncWorkspaceSourceReviews", _
                          "分析結果 " & CStr(r + 1) & "行目の内部元行が見つかりません。"
            sourceKey = CellText(resultData(r, ANALYSIS_RESULT_SOURCE_KEY_COL))
            If StrComp(CellText(WorkspaceColumnArrayValue(keyValues, sourceIndex, sourceDataRows)), _
                       sourceKey, vbBinaryCompare) <> 0 Then _
                Err.Raise vbObjectError + 4807, "SyncWorkspaceSourceReviews", _
                          "分析結果 " & CStr(r + 1) & "行目と内部根拠表の確認キーが一致しません。"
            statusText = WorkspaceStatusOrDefault(resultData(r, ANALYSIS_RESULT_STATUS_COL))
            memoText = CellText(resultData(r, ANALYSIS_RESULT_MEMO_COL))
            categoryText = CellText(resultData(r, 2))
            If Len(memoText) > WORKSPACE_MEMO_MAX Then _
                Err.Raise vbObjectError + 4808, "SyncWorkspaceSourceReviews", _
                          "分析結果 " & CStr(r + 1) & "行目の確認メモが長すぎます。"
            If Not WorkspaceStatusFitsSource(targetSheetName, categoryText, statusText) Then _
                Err.Raise vbObjectError + 4809, "SyncWorkspaceSourceReviews", _
                          "分析結果 " & CStr(r + 1) & "行目の確認状況が区分に適合しません。"
            targetID = CStr(sourceRow)
            If seenTargets.Exists(targetID) Then _
                Err.Raise vbObjectError + 4811, "SyncWorkspaceSourceReviews", _
                          "分析結果に同じ内部候補が重複しています: " & _
                          targetSheetName & " " & targetID & "行"
            seenTargets.Add targetID, True
            planCount = planCount + 1
            planRows(planCount) = sourceRow
            planStatuses(planCount) = statusText
            planMemos(planCount) = memoText
        End If
    Next r
    For r = 1 To planCount
        WriteAnalysisReviewTextCellIfChanged wsSource.Cells(planRows(r), statusCol), _
            planStatuses(r), "分析結果の確認状況"
        WriteAnalysisReviewTextCellIfChanged wsSource.Cells(planRows(r), memoCol), _
            planMemos(r), "分析結果の確認メモ"
    Next r
End Sub

Private Function WorkspaceColumnArrayValue(ByRef values As Variant, ByVal itemIndex As Long, _
                                           ByVal itemCount As Long) As Variant
    If itemCount = 1 Then
        WorkspaceColumnArrayValue = values
    Else
        WorkspaceColumnArrayValue = values(itemIndex, 1)
    End If
End Function

Private Function WorkspaceSourceColumns(ByVal sheetName As String, ByRef statusCol As Long, _
                                        ByRef memoCol As Long, ByRef keyCol As Long) As Boolean
    Select Case sheetName
        Case SH_ANALYSIS_SHIFT
            statusCol = SHIFT_ANALYSIS_STATUS_COL: memoCol = SHIFT_ANALYSIS_MEMO_COL
            keyCol = SHIFT_ANALYSIS_KEY_COL
        Case SH_ANALYSIS_FLOW
            statusCol = FLOW_ANALYSIS_STATUS_COL: memoCol = FLOW_ANALYSIS_MEMO_COL
            keyCol = FLOW_ANALYSIS_KEY_COL
        Case SH_ANALYSIS_UNKNOWN
            statusCol = UNKNOWN_ANALYSIS_STATUS_COL: memoCol = UNKNOWN_ANALYSIS_MEMO_COL
            keyCol = UNKNOWN_ANALYSIS_KEY_COL
        Case Else
            Exit Function
    End Select
    WorkspaceSourceColumns = True
End Function

Private Function WorkspaceStatusFitsSource(ByVal sourceSheet As String, ByVal categoryText As String, _
                                           ByVal statusText As String) As Boolean
    Select Case sourceSheet
        Case SH_ANALYSIS_SHIFT, SH_ANALYSIS_FLOW
            Select Case statusText
                Case ANALYSIS_STATUS_UNREVIEWED, ANALYSIS_STATUS_SHIFT_CONFIRMED, _
                     ANALYSIS_STATUS_EXCLUDED, ANALYSIS_STATUS_FOLLOWUP
                    WorkspaceStatusFitsSource = True
            End Select
        Case SH_ANALYSIS_UNKNOWN
            If StrComp(categoryText, "原資不明", vbTextCompare) = 0 Then
                Select Case statusText
                    Case ANALYSIS_STATUS_UNREVIEWED, ANALYSIS_STATUS_SOURCE_CONFIRMED, _
                         ANALYSIS_STATUS_EXCLUDED, ANALYSIS_STATUS_FOLLOWUP
                        WorkspaceStatusFitsSource = True
                End Select
            ElseIf StrComp(categoryText, "使途不明", vbTextCompare) = 0 Then
                Select Case statusText
                    Case ANALYSIS_STATUS_UNREVIEWED, ANALYSIS_STATUS_USE_CONFIRMED, _
                         ANALYSIS_STATUS_EXCLUDED, ANALYSIS_STATUS_FOLLOWUP
                        WorkspaceStatusFitsSource = True
                End Select
            End If
    End Select
End Function

Public Sub FormatAnalysisWorkspaceSheets()
    Dim ws As Worksheet, dataCount As Long, lastDetailRow As Long
    If SheetExists(SH_ANALYSIS_RESULT) Then
        Set ws = GetSheet(SH_ANALYSIS_RESULT)
        dataCount = Application.Max(0, LastUsedRowInSheet(ws) - 1)
        FinalizeAnalysisResultSheet ws, dataCount
    End If
    If SheetExists(SH_ANALYSIS_DETAIL) Then
        Set ws = GetSheet(SH_ANALYSIS_DETAIL)
        ws.Unprotect Password:=TOOL_PASSWORD
        lastDetailRow = Application.Max(1, LastUsedRowInSheet(ws))
        With ws.Range("A1:L" & CStr(lastDetailRow))
            .Font.Name = "Yu Gothic UI"
            .Font.Size = 10
        End With
        ProtectSingleAnalysisSheet ws
    End If
End Sub


Public Sub OpenManualAnalysisCandidateBuilder()
    If Not SheetExists(SH_OUTPUT_TX) Then Exit Sub
    If ActiveSheet Is Nothing Then Exit Sub
    If ActiveSheet.Name <> SH_OUTPUT_TX Then
        MsgBox "手動候補は、資金操作表の上部パネルから作成してください。", _
               vbInformation, "資金操作表内で作成します"
        Exit Sub
    End If
    CashAnalysisSecondaryAction
End Sub


Public Sub OpenAnalysisResultDetail(ByVal resultRow As Long)
    If Not SheetExists(SH_OUTPUT_TX) Then Exit Sub
    If ActiveSheet Is Nothing Then Exit Sub
    If ActiveSheet.Name <> SH_OUTPUT_TX Then
        MsgBox "候補の根拠は、資金操作表の上部パネルで確認してください。", _
               vbInformation, "資金操作表内に表示します"
        Exit Sub
    End If
    ShowCashAnalysisPanelText 7
End Sub


Private Sub ApplyAnalysisDetailStatusValidation(ByVal target As Range, _
                                                ByVal sourceSheet As String, _
                                                ByVal categoryText As String)
    Dim listName As String
    If sourceSheet = SH_ANALYSIS_SHIFT Or sourceSheet = SH_ANALYSIS_FLOW Then
        listName = NM_LST_ANALYSIS_SHIFT_STATUS
    ElseIf categoryText = "原資不明" Then
        listName = NM_LST_ANALYSIS_SOURCE_STATUS
    Else
        listName = NM_LST_ANALYSIS_USE_STATUS
    End If
    With target.Validation
        .Delete
        .Add Type:=xlValidateList, AlertStyle:=xlValidAlertStop, _
             Operator:=xlBetween, Formula1:="=" & listName
        .IgnoreBlank = True
        .InCellDropdown = True
        .ShowError = True
        .ErrorTitle = "確認状況を選択してください"
        .ErrorMessage = "候補の区分に対応する確認状況を選択してください。"
    End With
End Sub

Private Sub ApplyAnalysisDetailMemoValidation(ByVal target As Range)
    With target.Validation
        .Delete
        .Add Type:=xlValidateTextLength, AlertStyle:=xlValidAlertStop, _
             Operator:=xlLessEqual, Formula1:=CStr(WORKSPACE_MEMO_MAX)
        .IgnoreBlank = True
        .ShowError = True
        .ErrorTitle = "確認メモの文字数を確認してください"
        .ErrorMessage = "確認メモは" & CStr(WORKSPACE_MEMO_MAX) & "文字以内で入力してください。"
    End With
End Sub


Private Function WorkspaceJoinIDs(ByVal firstID As String, ByVal secondID As String) As String
    If Len(firstID) = 0 Then
        WorkspaceJoinIDs = secondID
    ElseIf Len(secondID) = 0 Then
        WorkspaceJoinIDs = firstID
    ElseIf StrComp(firstID, secondID, vbTextCompare) <= 0 Then
        WorkspaceJoinIDs = firstID & ";" & secondID
    Else
        WorkspaceJoinIDs = secondID & ";" & firstID
    End If
End Function

Private Function WorkspacePartyAccount(ByVal personValue As Variant, ByVal relationshipValue As Variant, _
                                       ByVal bankValue As Variant, ByVal branchValue As Variant, _
                                       ByVal typeValue As Variant, ByVal numberValue As Variant) As String
    Dim personText As String, accountText As String
    personText = CellText(personValue)
    If Len(personText) > 0 Then personText = personText & WorkspaceRelationshipSuffix(relationshipValue) & " "
    accountText = Trim$(CellText(bankValue) & " " & CellText(branchValue) & " " & _
                        CellText(typeValue) & " " & CellText(numberValue))
    WorkspacePartyAccount = Trim$(personText & accountText)
End Function

Private Function WorkspaceRelationshipSuffix(ByVal relationshipValue As Variant) As String
    If Len(CellText(relationshipValue)) > 0 Then _
        WorkspaceRelationshipSuffix = "（" & CellText(relationshipValue) & "）"
End Function

Private Function WorkspacePeriodText(ByVal firstDate As Variant, ByVal secondDate As Variant) As String
    Dim firstValue As Date, secondValue As Date
    If Not IsDate(firstDate) Or Not IsDate(secondDate) Then
        WorkspacePeriodText = WorkspaceDateText(firstDate) & " ～ " & WorkspaceDateText(secondDate)
        Exit Function
    End If
    firstValue = DateSerial(Year(CDate(firstDate)), Month(CDate(firstDate)), Day(CDate(firstDate)))
    secondValue = DateSerial(Year(CDate(secondDate)), Month(CDate(secondDate)), Day(CDate(secondDate)))
    If firstValue = secondValue Then
        WorkspacePeriodText = Format$(firstValue, "yyyy/m/d") & "（同日）"
    ElseIf firstValue < secondValue Then
        WorkspacePeriodText = Format$(firstValue, "yyyy/m/d") & " ～ " & _
                              Format$(secondValue, "yyyy/m/d")
    Else
        WorkspacePeriodText = Format$(secondValue, "yyyy/m/d") & " ～ " & _
                              Format$(firstValue, "yyyy/m/d")
    End If
End Function

Private Function WorkspaceDateText(ByVal valueIn As Variant) As String
    If IsDate(valueIn) Then WorkspaceDateText = Format$(CDate(valueIn), "yyyy/m/d") Else WorkspaceDateText = "日付要確認"
End Function

Private Function WorkspaceTimeText(ByVal valueIn As Variant) As String
    Dim parsedTimeFraction As Double
    If WorkspaceTryTime(valueIn, parsedTimeFraction) Then
        WorkspaceTimeText = Format$(parsedTimeFraction, "hh:mm")
    Else
        WorkspaceTimeText = "時刻記載なし"
    End If
End Function

Private Function WorkspaceTryTime(ByVal valueIn As Variant, ByRef parsedTimeFraction As Double) As Boolean
    If IsError(valueIn) Or IsNull(valueIn) Or IsEmpty(valueIn) Then Exit Function
    If VarType(valueIn) = vbString And Len(Trim$(CStr(valueIn))) = 0 Then Exit Function
    If Not IsDate(valueIn) And Not IsNumeric(valueIn) Then Exit Function
    On Error GoTo InvalidTime
    parsedTimeFraction = CDbl(VBA.TimeValue(CDate(valueIn)))
    WorkspaceTryTime = (parsedTimeFraction >= 0 And parsedTimeFraction < 1)
    Exit Function
InvalidTime:
    WorkspaceTryTime = False
End Function

Private Function WorkspaceAmountText(ByVal valueIn As Variant) As String
    If IsNumeric(valueIn) Then WorkspaceAmountText = Format$(CDbl(valueIn), "#,##0.########") Else WorkspaceAmountText = "要確認"
End Function

Private Function WorkspaceDouble(ByVal valueIn As Variant) As Double
    If IsError(valueIn) Or IsNull(valueIn) Or IsEmpty(valueIn) Then Exit Function
    If IsNumeric(valueIn) Then WorkspaceDouble = CDbl(valueIn)
End Function

Private Function WorkspaceLong(ByVal valueIn As Variant) As Long
    If IsError(valueIn) Or IsNull(valueIn) Or IsEmpty(valueIn) Then Exit Function
    If IsNumeric(valueIn) Then
        If CDbl(valueIn) >= -2147483648# And CDbl(valueIn) <= 2147483647# Then _
            WorkspaceLong = CLng(valueIn)
    End If
End Function

Private Function WorkspaceStatusOrDefault(ByVal valueIn As Variant) As String
    WorkspaceStatusOrDefault = CellText(valueIn)
    If Len(WorkspaceStatusOrDefault) = 0 Then WorkspaceStatusOrDefault = ANALYSIS_STATUS_UNREVIEWED
End Function

Private Function WorkspaceBlankLabel(ByVal valueIn As Variant) As String
    WorkspaceBlankLabel = CellText(valueIn)
    If Len(WorkspaceBlankLabel) = 0 Then WorkspaceBlankLabel = "（空欄・窓口型の可能性）"
End Function

Private Function WorkspaceAppend(ByVal currentText As String, ByVal newText As String, _
                                 ByVal separatorText As String) As String
    If Len(newText) = 0 Then
        WorkspaceAppend = currentText
    ElseIf Len(currentText) = 0 Then
        WorkspaceAppend = newText
    Else
        WorkspaceAppend = currentText & separatorText & newText
    End If
End Function

Private Function WorkspaceTrimText(ByVal valueIn As String, ByVal maxLength As Long) As String
    If Len(valueIn) <= maxLength Then
        WorkspaceTrimText = valueIn
    Else
        WorkspaceTrimText = Left$(valueIn, maxLength - 14) & "…（長文のため一部表示）"
    End If
End Function


Private Function WorkspaceDigest(ByVal rawText As String) As String
    Dim firstHash As Double, secondHash As Double, i As Long, codeValue As Long
    firstHash = 104729#: secondHash = 130363#
    For i = 1 To Len(rawText)
        codeValue = AscW(Mid$(rawText, i, 1))
        If codeValue < 0 Then codeValue = codeValue + 65536
        firstHash = firstHash * 257# + codeValue + i
        firstHash = firstHash - Fix(firstHash / 2147483629#) * 2147483629#
        secondHash = secondHash * 263# + codeValue + i * 3#
        secondHash = secondHash - Fix(secondHash / 2147483587#) * 2147483587#
    Next i
    WorkspaceDigest = Right$("00000000" & Hex$(CLng(firstHash)), 8) & "-" & _
                      Right$("00000000" & Hex$(CLng(secondHash)), 8)
End Function

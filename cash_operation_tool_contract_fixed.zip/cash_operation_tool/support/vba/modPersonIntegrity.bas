﻿Attribute VB_Name = "modPersonIntegrity"
Option Explicit

Private Const PERSON_INTEGRITY_DETAIL_LIMIT As Long = 30000
Private Const BALANCE_PERSON_NAME_COLUMN As Long = 1
Private Const PERSON_CANDIDATE_DATA_ROW_LIMIT As Long = 100000
Private Const PERSON_INTEGRITY_CAPACITY_BASE_COLUMNS As Long = 16
Private Const PERSON_INTEGRITY_CAPACITY_SNAPSHOT_COPIES As Double = 3#
Private Const PERSON_INTEGRITY_CAPACITY_LONG_MAX As Double = 2147483647#


Public Function RequireCorePersonIntegrityCapacity( _
        ByVal operationName As String, _
        Optional ByVal capacityAlreadyConfirmed As Boolean = False, _
        Optional ByVal includePersonCandidates As Boolean = True) As Boolean
    Dim accountRows As Long, transactionRows As Long
    Dim balanceRows As Long, personRows As Long
    Dim workRows As Double

    If capacityAlreadyConfirmed Then
        RequireCorePersonIntegrityCapacity = True
        Exit Function
    End If
    If Len(Trim$(operationName)) = 0 Then operationName = "内部データの人物整合性検査"
    If Not SheetExists(SH_WORK_ACCOUNT) Or Not SheetExists(SH_WORK_TX) Or _
       Not SheetExists(SH_WORK_BAL) Then _
        Err.Raise vbObjectError + 6307, "RequireCorePersonIntegrityCapacity", _
                  "人物整合性検査に必要な内部データシートが不足しています。"
    If includePersonCandidates And Not SheetExists(SH_PERSON_CAND) Then _
        Err.Raise vbObjectError + 6307, "RequireCorePersonIntegrityCapacity", _
                  "人物候補を含む整合性検査に必要なシートが不足しています。"

    accountRows = CorePersonIntegrityDataRows( _
                      GetSheet(SH_WORK_ACCOUNT), ACC_COL_TRANSFER_ID)
    transactionRows = CorePersonIntegrityDataRows( _
                          GetSheet(SH_WORK_TX), WORK_TX_COL_PERSON_ID)
    balanceRows = CorePersonIntegrityDataRows( _
                      GetSheet(SH_WORK_BAL), WORK_BAL_COL_PERSON_ID)
    If includePersonCandidates Then _
        personRows = CorePersonIntegrityDataRows(GetSheet(SH_PERSON_CAND), 4)
    workRows = CorePersonIntegrityCapacityWorkRows( _
                   accountRows, transactionRows, balanceRows, personRows)
    If workRows > PERSON_INTEGRITY_CAPACITY_LONG_MAX Then _
        Err.Raise vbObjectError + 6308, "RequireCorePersonIntegrityCapacity", _
                  "人物整合性検査の安全容量をLong型へ変換できません。"
    RequireCorePersonIntegrityCapacity = ConfirmLargeArrayOperation( _
        CLng(workRows), operationName & "（内部4保管の配列検査）")
End Function

Private Function CorePersonIntegrityDataRows(ByVal ws As Worksheet, _
                                             ByVal lastColumn As Long) As Long
    Dim lastDataRow As Long
    If ws Is Nothing Or lastColumn < 1 Then _
        Err.Raise vbObjectError + 6307, "CorePersonIntegrityDataRows", _
                  "人物整合性検査の行数を取得できません。"
    lastDataRow = LastDataRowInColumns(ws, 1, lastColumn)
    If lastDataRow > 1 Then CorePersonIntegrityDataRows = lastDataRow - 1
End Function

Private Function CorePersonIntegrityCapacityWorkRows( _
        ByVal accountRows As Long, ByVal transactionRows As Long, _
        ByVal balanceRows As Long, ByVal personRows As Long) As Double
    Dim cellWork As Double
    If accountRows < 0 Or transactionRows < 0 Or _
       balanceRows < 0 Or personRows < 0 Then _
        Err.Raise vbObjectError + 6308, "CorePersonIntegrityCapacityWorkRows", _
                  "人物整合性検査の容量計画に負数が含まれています。"
    cellWork = PERSON_INTEGRITY_CAPACITY_SNAPSHOT_COPIES * _
               (CDbl(accountRows) * CDbl(ACC_COL_TRANSFER_ID) + _
                CDbl(transactionRows) * CDbl(WORK_TX_COL_PERSON_ID) + _
                CDbl(balanceRows) * CDbl(WORK_BAL_COL_PERSON_ID) + _
                CDbl(personRows) * 4#)
    CorePersonIntegrityCapacityWorkRows = _
        CorePersonIntegrityEquivalentWorkRows(cellWork)
End Function

Private Function CorePersonIntegrityEquivalentWorkRows( _
        ByVal cellWork As Double) As Double
    Dim workRows As Double
    If cellWork < 0# Or _
       cellWork > PERSON_INTEGRITY_CAPACITY_LONG_MAX * _
                  CDbl(PERSON_INTEGRITY_CAPACITY_BASE_COLUMNS) Then _
        Err.Raise vbObjectError + 6308, _
                  "CorePersonIntegrityEquivalentWorkRows", _
                  "人物整合性検査の安全容量を16列相当に換算できません。"
    workRows = Int((cellWork + _
                    CDbl(PERSON_INTEGRITY_CAPACITY_BASE_COLUMNS) - 1#) / _
                   CDbl(PERSON_INTEGRITY_CAPACITY_BASE_COLUMNS))
    If workRows < 0# Or workRows > PERSON_INTEGRITY_CAPACITY_LONG_MAX Then _
        Err.Raise vbObjectError + 6308, _
                  "CorePersonIntegrityEquivalentWorkRows", _
                  "人物整合性検査の安全容量がLong型の上限を超えています。"
    CorePersonIntegrityEquivalentWorkRows = workRows
End Function


'W_口座を唯一の正本として、W_取引・W_残高に複製された人物情報を検査する。
'この関数はシートを読み取るだけで、選択、表示、書込み、メッセージ表示を行わない。
Public Function ValidateCorePersonIntegrity(ByRef problems As String, _
                                            Optional ByVal includePersonCandidates As Boolean = True) As Boolean
    Dim storeProblems As String
    On Error GoTo Failed
    problems = vbNullString

    If Not SheetExists(SH_WORK_ACCOUNT) Then _
        AppendPersonIntegrityProblem problems, "W_口座がありません。"
    If Not SheetExists(SH_WORK_TX) Then _
        AppendPersonIntegrityProblem problems, "W_取引がありません。"
    If Not SheetExists(SH_WORK_BAL) Then _
        AppendPersonIntegrityProblem problems, "W_残高がありません。"
    If includePersonCandidates And Not SheetExists(SH_PERSON_CAND) Then _
        AppendPersonIntegrityProblem problems, "人物候補がありません。"
    If Len(problems) > 0 Then Exit Function

    If Not ValidateCorePersonStoreSafety(storeProblems, includePersonCandidates) Then
        AppendPersonIntegrityProblem problems, storeProblems
        Exit Function
    End If

    ValidateCorePersonIntegrity = _
        ValidatePersonIntegritySheetsSequentially(problems, includePersonCandidates)
    Exit Function
Failed:
    problems = vbNullString
    AppendPersonIntegrityProblem problems, _
        "人物整合性検査を完了できません（Err " & CStr(Err.Number) & "）: " & Err.Description
    ValidateCorePersonIntegrity = False
End Function

'各配列は本番シートと同じ1始まり・同じ列番号であることを契約とする。
'取引・残高の続柄複製は人物完全性ゲートの判定対象に含めない。
'ただし人物IDの自動割当契約に合わせ、W_口座で正規化後の氏名＋続柄が同じなら
'同じ人物IDでなければならない。別人物は異なる氏名で登録する運用とする。


Private Function ValidatePersonIntegritySheetsSequentially( _
        ByRef problems As String, _
        Optional ByVal includePersonCandidates As Boolean = True) As Boolean
    Dim accountData As Variant, transactionData As Variant, balanceData As Variant
    Dim candidateData As Variant
    Dim firstRow As Long, lastRow As Long, hasRows As Boolean
    Dim personIDByAccount As Object, personNameByAccount As Object
    Dim accountSourceRowByID As Object
    Dim personIDByIdentity As Object, identitySourceRow As Object
    Dim relationshipByPersonID As Object, relationshipSourceByPersonID As Object

    Set personIDByAccount = NewPersonIntegrityDictionary()
    Set personNameByAccount = NewPersonIntegrityDictionary()
    Set accountSourceRowByID = NewPersonIntegrityDictionary()
    Set personIDByIdentity = NewPersonIntegrityDictionary()
    Set identitySourceRow = NewPersonIntegrityDictionary()
    Set relationshipByPersonID = NewPersonIntegrityDictionary()
    Set relationshipSourceByPersonID = NewPersonIntegrityDictionary()

    '32bit Excelでも3保管表を同時保持しない。正本索引を作った後は配列を順次解放する。
    accountData = LoadPersonIntegrityMatrix(SH_WORK_ACCOUNT, ACC_COL_TRANSFER_ID)
    If Not TryPersonIntegrityMatrixBounds(accountData, ACC_COL_TRANSFER_ID, "W_口座", _
                                           firstRow, lastRow, hasRows, problems) Then Exit Function
    If hasRows Then
        ValidatePersonIntegrityAccounts accountData, firstRow, lastRow, _
                                        personIDByAccount, personNameByAccount, _
                                        accountSourceRowByID, personIDByIdentity, _
                                        identitySourceRow, relationshipByPersonID, _
                                        relationshipSourceByPersonID, problems
    End If
    If IsArray(accountData) Then Erase accountData

    transactionData = LoadPersonIntegrityMatrix(SH_WORK_TX, WORK_TX_COL_PERSON_ID)
    If Not TryPersonIntegrityMatrixBounds(transactionData, WORK_TX_COL_PERSON_ID, "W_取引", _
                                           firstRow, lastRow, hasRows, problems) Then Exit Function
    If hasRows Then
        ValidatePersonIntegrityLinkedRows transactionData, firstRow, lastRow, "W_取引", _
                                          WORK_TX_COL_ACCOUNT_ID, WORK_TX_COL_PERSON_ID, _
                                          OUT_COL_PERSON, personIDByAccount, _
                                          personNameByAccount, accountSourceRowByID, problems
    End If
    If IsArray(transactionData) Then Erase transactionData

    balanceData = LoadPersonIntegrityMatrix(SH_WORK_BAL, WORK_BAL_COL_PERSON_ID)
    If Not TryPersonIntegrityMatrixBounds(balanceData, WORK_BAL_COL_PERSON_ID, "W_残高", _
                                           firstRow, lastRow, hasRows, problems) Then Exit Function
    If hasRows Then
        ValidatePersonIntegrityLinkedRows balanceData, firstRow, lastRow, "W_残高", _
                                          WORK_BAL_COL_ACCOUNT_ID, WORK_BAL_COL_PERSON_ID, _
                                          BALANCE_PERSON_NAME_COLUMN, personIDByAccount, _
                                          personNameByAccount, accountSourceRowByID, problems
    End If
    If IsArray(balanceData) Then Erase balanceData

    If includePersonCandidates Then
        candidateData = LoadPersonIntegrityMatrix( _
                            SH_PERSON_CAND, 3, PERSON_CANDIDATE_DATA_ROW_LIMIT)
        If Not TryPersonIntegrityMatrixBounds(candidateData, 3, "人物候補", _
                                               firstRow, lastRow, hasRows, problems) Then Exit Function
        If hasRows Then
            ValidatePersonIntegrityCandidates candidateData, firstRow, lastRow, _
                                              personIDByIdentity, identitySourceRow, _
                                              relationshipByPersonID, _
                                              relationshipSourceByPersonID, problems
        End If
        If IsArray(candidateData) Then Erase candidateData
    End If
    ValidatePersonIntegritySheetsSequentially = (Len(problems) = 0)
End Function

Private Function LoadPersonIntegrityMatrix(ByVal sheetName As String, _
                                           ByVal lastColumn As Long, _
                                           Optional ByVal maxDataRows As Long = _
                                               MAX_INTERNAL_STORE_DATA_ROWS) As Variant
    Dim ws As Worksheet, lastDataRow As Long
    Set ws = GetSheet(sheetName)
    lastDataRow = LastDataRowInColumns(ws, 1, lastColumn)
    If maxDataRows < 1 Then _
        Err.Raise vbObjectError + 6301, "LoadPersonIntegrityMatrix", _
                  "人物整合性検査の行上限が不正です: " & CStr(maxDataRows)
    If lastDataRow > maxDataRows + 1 Then _
        Err.Raise vbObjectError + 6300, "LoadPersonIntegrityMatrix", _
                  sheetName & "が人物整合性検査の実用上限（" & _
                  Format$(maxDataRows, "#,##0") & "行）を超えています。"
    If lastDataRow >= 2 Then
        LoadPersonIntegrityMatrix = ws.Range(ws.Cells(2, 1), _
                                             ws.Cells(lastDataRow, lastColumn)).Value2
    End If
End Function

Private Function NewPersonIntegrityDictionary() As Object
    Dim result As Object
    Set result = CreateObject("Scripting.Dictionary")
    result.CompareMode = vbTextCompare
    Set NewPersonIntegrityDictionary = result
End Function

Private Function TryPersonIntegrityMatrixBounds(ByRef sourceData As Variant, _
                                                ByVal expectedLastColumn As Long, _
                                                ByVal storeLabel As String, _
                                                ByRef firstRow As Long, _
                                                ByRef lastRow As Long, _
                                                ByRef hasRows As Boolean, _
                                                ByRef problems As String) As Boolean
    Dim firstColumn As Long, lastColumn As Long
    firstRow = 0
    lastRow = 0
    hasRows = False
    If IsEmpty(sourceData) Then
        TryPersonIntegrityMatrixBounds = True
        Exit Function
    End If
    If Not IsArray(sourceData) Then
        AppendPersonIntegrityProblem problems, storeLabel & "の内部データを読み取れません。"
        Exit Function
    End If

    On Error GoTo InvalidMatrix
    firstRow = LBound(sourceData, 1)
    lastRow = UBound(sourceData, 1)
    firstColumn = LBound(sourceData, 2)
    lastColumn = UBound(sourceData, 2)
    If firstRow <> 1 Or firstColumn <> 1 Or lastRow < firstRow Or _
       lastColumn < expectedLastColumn Then
        AppendPersonIntegrityProblem problems, _
            storeLabel & "のデータ範囲が不正です（必要列=" & _
            CStr(expectedLastColumn) & "）。"
        Exit Function
    End If
    hasRows = True
    TryPersonIntegrityMatrixBounds = True
    Exit Function
InvalidMatrix:
    AppendPersonIntegrityProblem problems, storeLabel & "の内部データの構造を確認できません。"
    Err.Clear
End Function

Private Sub ValidatePersonIntegrityAccounts(ByRef accountData As Variant, _
                                             ByVal firstRow As Long, _
                                             ByVal lastRow As Long, _
                                             ByVal personIDByAccount As Object, _
                                             ByVal personNameByAccount As Object, _
                                             ByVal accountSourceRowByID As Object, _
                                             ByVal personIDByIdentity As Object, _
                                             ByVal identitySourceRow As Object, _
                                             ByVal relationshipByPersonID As Object, _
                                             ByVal relationshipSourceByPersonID As Object, _
                                             ByRef problems As String)
    Dim sourceIndex As Long, worksheetRow As Long
    Dim accountID As String, personID As String
    Dim personName As String, relationshipText As String, identityKey As String
    For sourceIndex = firstRow To lastRow
        worksheetRow = sourceIndex - firstRow + 2
        accountID = CellText(accountData(sourceIndex, ACC_COL_ID))
        personName = CellText(accountData(sourceIndex, ACC_COL_PERSON))
        relationshipText = CellText(accountData(sourceIndex, ACC_COL_RELATIONSHIP))
        personID = CellText(accountData(sourceIndex, ACC_COL_PERSON_ID))

        If Len(accountID) = 0 Then
            AppendPersonIntegrityProblem problems, _
                "W_口座 " & CStr(worksheetRow) & "行: 口座IDなし"
        Else
            If Not IsInternalIdValue(accountID, "A") Then _
                AppendPersonIntegrityProblem problems, _
                    "W_口座 " & CStr(worksheetRow) & "行: 口座ID形式不正 " & accountID
            If personIDByAccount.Exists(accountID) Then
                AppendPersonIntegrityProblem problems, _
                    "W_口座 " & CStr(worksheetRow) & "行: 口座ID重複 " & accountID & _
                    "（先行=" & CStr(accountSourceRowByID(accountID)) & "行）"
            Else
                personIDByAccount.Add accountID, personID
                personNameByAccount.Add accountID, personName
                accountSourceRowByID.Add accountID, worksheetRow
            End If
        End If

        If Not HasPersonIntegrityName(personName) Then _
            AppendPersonIntegrityProblem problems, _
                "W_口座 " & CStr(worksheetRow) & "行: 口座名義人なし"
        If Len(personID) = 0 Then
            AppendPersonIntegrityProblem problems, _
                "W_口座 " & CStr(worksheetRow) & "行: 人物IDなし"
        ElseIf Not IsInternalIdValue(personID, "P") Then
            AppendPersonIntegrityProblem problems, _
                "W_口座 " & CStr(worksheetRow) & "行: 人物ID形式不正 " & personID
        ElseIf HasPersonIntegrityName(personName) Then
            ValidatePersonIDRelationship personID, relationshipText, _
                                         "W_口座 " & CStr(worksheetRow) & "行", _
                                         relationshipByPersonID, _
                                         relationshipSourceByPersonID, problems
            identityKey = PersonIdentityKey(personName, relationshipText)
            If personIDByIdentity.Exists(identityKey) Then
                If StrComp(CStr(personIDByIdentity(identityKey)), personID, _
                           vbTextCompare) <> 0 Then _
                    AppendPersonIntegrityProblem problems, _
                        "W_口座 " & CStr(worksheetRow) & _
                        "行: 同じ氏名・続柄に異なる人物ID" & _
                        "（先行=" & CStr(identitySourceRow(identityKey)) & _
                        "行 / 期待=" & CStr(personIDByIdentity(identityKey)) & _
                        " / 実際=" & personID & "）"
            Else
                personIDByIdentity.Add identityKey, personID
                identitySourceRow.Add identityKey, worksheetRow
            End If
        End If
    Next sourceIndex
End Sub

Private Sub ValidatePersonIntegrityCandidates(ByRef candidateData As Variant, _
                                              ByVal firstRow As Long, _
                                              ByVal lastRow As Long, _
                                              ByVal personIDByIdentity As Object, _
                                              ByVal identitySourceRow As Object, _
                                              ByVal relationshipByPersonID As Object, _
                                              ByVal relationshipSourceByPersonID As Object, _
                                              ByRef problems As String)
    Dim sourceIndex As Long, worksheetRow As Long
    Dim personName As String, relationshipText As String
    Dim personID As String, identityKey As String
    Dim blankIdentityRows As Object
    Set blankIdentityRows = NewPersonIntegrityDictionary()
    For sourceIndex = firstRow To lastRow
        worksheetRow = sourceIndex - firstRow + 2
        personName = CellText(candidateData(sourceIndex, 1))
        personID = CellText(candidateData(sourceIndex, 2))
        relationshipText = CellText(candidateData(sourceIndex, 3))

        '人物IDなしの別人物候補は入力候補として許容する。同じ氏名＋続柄に
        'ID付き行が既にある場合は重複として止め、異なるIDへの分岐を全入口で防ぐ。
        If Len(personID) > 0 Then
            If Not IsInternalIdValue(personID, "P") Then
                AppendPersonIntegrityProblem problems, _
                    "人物候補 " & CStr(worksheetRow) & "行: 人物ID形式不正 " & personID
            ElseIf Not HasPersonIntegrityName(personName) Then
                AppendPersonIntegrityProblem problems, _
                    "人物候補 " & CStr(worksheetRow) & "行: 氏名なしの人物ID " & personID
            Else
                ValidatePersonIDRelationship personID, relationshipText, _
                                             "人物候補 " & CStr(worksheetRow) & "行", _
                                             relationshipByPersonID, _
                                             relationshipSourceByPersonID, problems
                identityKey = PersonIdentityKey(personName, relationshipText)
                If personIDByIdentity.Exists(identityKey) Then
                    If StrComp(CStr(personIDByIdentity(identityKey)), personID, _
                               vbTextCompare) <> 0 Then _
                        AppendPersonIntegrityProblem problems, _
                            "人物候補 " & CStr(worksheetRow) & _
                            "行: 同じ氏名・続柄に異なる人物ID" & _
                            "（先行=" & CStr(identitySourceRow(identityKey)) & _
                            " / 期待=" & CStr(personIDByIdentity(identityKey)) & _
                            " / 実際=" & personID & "）"
                Else
                    personIDByIdentity.Add identityKey, personID
                    identitySourceRow.Add identityKey, _
                                          "人物候補 " & CStr(worksheetRow) & "行"
                End If
                If blankIdentityRows.Exists(identityKey) Then _
                    AppendPersonIntegrityProblem problems, _
                        "人物候補 " & CStr(worksheetRow) & _
                        "行: 同じ氏名・続柄に人物IDなしの重複行があります（" & _
                        CStr(blankIdentityRows(identityKey)) & "行）"
            End If
        ElseIf HasPersonIntegrityName(personName) Then
            identityKey = PersonIdentityKey(personName, relationshipText)
            If personIDByIdentity.Exists(identityKey) Then
                AppendPersonIntegrityProblem problems, _
                    "人物候補 " & CStr(worksheetRow) & _
                    "行: 同じ氏名・続柄の人物ID付き候補と重複しています"
            ElseIf blankIdentityRows.Exists(identityKey) Then
                AppendPersonIntegrityProblem problems, _
                    "人物候補 " & CStr(worksheetRow) & _
                    "行: 同じ氏名・続柄の人物IDなし候補が重複しています（先行=" & _
                    CStr(blankIdentityRows(identityKey)) & "行）"
            Else
                blankIdentityRows.Add identityKey, worksheetRow
            End If
        End If
    Next sourceIndex
End Sub

Private Sub ValidatePersonIDRelationship(ByVal personID As String, _
                                         ByVal relationshipText As String, _
                                         ByVal sourceText As String, _
                                         ByVal relationshipByPersonID As Object, _
                                         ByVal relationshipSourceByPersonID As Object, _
                                         ByRef problems As String)
    Dim relationshipKey As String, expectedRelationship As String
    personID = CellText(personID)
    relationshipText = CellText(relationshipText)
    If Len(personID) = 0 Then Exit Sub
    relationshipKey = NormalizeRelationshipKey(relationshipText)
    '空欄は未確定として許容する。確定済みの非空欄同士だけを比較し、
    '一つの人物IDへ複数の続柄が割り当てられる状態を保存前ゲートで止める。
    If Len(relationshipKey) = 0 Then Exit Sub
    If relationshipByPersonID.Exists(personID) Then
        expectedRelationship = CellText(relationshipByPersonID(personID))
        If StrComp(NormalizeRelationshipKey(expectedRelationship), _
                   relationshipKey, vbBinaryCompare) <> 0 Then _
            AppendPersonIntegrityProblem problems, sourceText & _
                ": 同一人物IDに異なる続柄" & _
                "（人物ID=" & personID & _
                " / 先行=" & CStr(relationshipSourceByPersonID(personID)) & _
                " / 期待=" & expectedRelationship & _
                " / 実際=" & relationshipText & "）"
    Else
        relationshipByPersonID.Add personID, relationshipText
        relationshipSourceByPersonID.Add personID, sourceText
    End If
End Sub

Private Sub ValidatePersonIntegrityLinkedRows(ByRef sourceData As Variant, _
                                              ByVal firstRow As Long, _
                                              ByVal lastRow As Long, _
                                              ByVal storeLabel As String, _
                                              ByVal accountIDColumn As Long, _
                                              ByVal personIDColumn As Long, _
                                              ByVal personNameColumn As Long, _
                                              ByVal personIDByAccount As Object, _
                                              ByVal personNameByAccount As Object, _
                                              ByVal accountSourceRowByID As Object, _
                                              ByRef problems As String)
    Dim sourceIndex As Long, worksheetRow As Long
    Dim accountID As String, personID As String, personName As String
    Dim expectedPersonID As String, expectedPersonName As String
    Dim accountExists As Boolean, personIDIsValid As Boolean

    For sourceIndex = firstRow To lastRow
        worksheetRow = sourceIndex - firstRow + 2
        accountID = CellText(sourceData(sourceIndex, accountIDColumn))
        personID = CellText(sourceData(sourceIndex, personIDColumn))
        personName = CellText(sourceData(sourceIndex, personNameColumn))
        accountExists = False

        If Len(accountID) = 0 Then
            AppendPersonIntegrityProblem problems, _
                storeLabel & " " & CStr(worksheetRow) & "行: 口座IDなし"
        Else
            If Not IsInternalIdValue(accountID, "A") Then _
                AppendPersonIntegrityProblem problems, _
                    storeLabel & " " & CStr(worksheetRow) & "行: 口座ID形式不正 " & accountID
            accountExists = personIDByAccount.Exists(accountID)
            If Not accountExists Then _
                AppendPersonIntegrityProblem problems, _
                    storeLabel & " " & CStr(worksheetRow) & "行: 孤立口座ID " & accountID
        End If

        personIDIsValid = False
        If Len(personID) = 0 Then
            AppendPersonIntegrityProblem problems, _
                storeLabel & " " & CStr(worksheetRow) & "行: 人物IDなし"
        ElseIf Not IsInternalIdValue(personID, "P") Then
            AppendPersonIntegrityProblem problems, _
                storeLabel & " " & CStr(worksheetRow) & "行: 人物ID形式不正 " & personID
        Else
            personIDIsValid = True
        End If
        If Not HasPersonIntegrityName(personName) Then _
            AppendPersonIntegrityProblem problems, _
                storeLabel & " " & CStr(worksheetRow) & "行: 口座名義人なし"

        If accountExists Then
            expectedPersonID = CellText(personIDByAccount(accountID))
            expectedPersonName = CellText(personNameByAccount(accountID))
            If personIDIsValid And IsInternalIdValue(expectedPersonID, "P") Then
                If StrComp(personID, expectedPersonID, vbTextCompare) <> 0 Then _
                    AppendPersonIntegrityProblem problems, _
                        storeLabel & " " & CStr(worksheetRow) & _
                        "行: 人物IDが口座マスタと不一致（口座=" & accountID & _
                        " / 期待=" & expectedPersonID & " / 実際=" & personID & _
                        " / W_口座=" & CStr(accountSourceRowByID(accountID)) & "行）"
            End If

            If HasPersonIntegrityName(personName) And _
               HasPersonIntegrityName(expectedPersonName) Then
                If StrComp(personName, expectedPersonName, vbBinaryCompare) <> 0 Then _
                    AppendPersonIntegrityProblem problems, _
                        storeLabel & " " & CStr(worksheetRow) & _
                        "行: 口座名義人が口座マスタと不一致（口座=" & accountID & _
                        " / 期待=" & expectedPersonName & " / 実際=" & personName & _
                        " / W_口座=" & CStr(accountSourceRowByID(accountID)) & "行）"
            End If
        End If
    Next sourceIndex
End Sub

Private Function HasPersonIntegrityName(ByVal personName As String) As Boolean
    HasPersonIntegrityName = (Len(NormalizePersonNameKey(personName)) > 0)
End Function

Private Sub AppendPersonIntegrityProblem(ByRef problems As String, _
                                         ByVal problemText As String)
    Const TRUNCATED_TEXT As String = "・以降の人物整合性エラーは省略しました。"
    Dim appendedText As String, retainedLength As Long
    If InStr(1, problems, TRUNCATED_TEXT, vbBinaryCompare) > 0 Then Exit Sub
    If Len(problems) >= PERSON_INTEGRITY_DETAIL_LIMIT Then Exit Sub
    appendedText = "・" & problemText & vbCrLf
    If Len(problems) + Len(appendedText) <= PERSON_INTEGRITY_DETAIL_LIMIT Then
        problems = problems & appendedText
    Else
        retainedLength = PERSON_INTEGRITY_DETAIL_LIMIT - Len(TRUNCATED_TEXT) - Len(vbCrLf)
        If retainedLength < 0 Then retainedLength = 0
        problems = Left$(problems, retainedLength) & TRUNCATED_TEXT & vbCrLf
    End If
End Sub


Attribute VB_Name = "modAnalysisWorkspace"
Option Explicit

'��������\�֕\����������A������9��̒����P�ʂ֏W�񂷂�B
'����3���͕\�ƌ��ڍׂ́A�m�F�L�^�Ɗč�������ێ���������\�Ƃ��Ďc���B
Private Const WORKSPACE_BUFFER_ROWS As Long = 1000
Private Const WORKSPACE_MEMO_MAX As Long = 1000
Private Const WORKSPACE_DETAIL_LIMIT As Long = 500
Private Const WORKSPACE_TEXT_LIMIT As Long = 1000
Private Const MANUAL_BUILDER_MAX_ROWS As Long = 50000
Private Const MANUAL_BUILDER_HEADER_ROW As Long = 5
Private Const DETAIL_COL_KIND As Long = 8
Private Const DETAIL_COL_REFERENCE As Long = 9
Private Const DETAIL_COL_SOURCE_ROW As Long = 10
Private Const DETAIL_COL_SOURCE_KEY As Long = 11
Private Const DETAIL_COL_SELECTED As Long = 12
Private mAnalysisDetailReviewsDirty As Boolean

Public Function AnalysisResultHeaders() As Variant
    AnalysisResultHeaders = Array( _
        "�D��x", _
        "�敪", "���t�E����", "���z", "�l���E�����o�H", "�v�_", "���؁E����", _
        "�m�F��", "�m�F����", "�������\", "�����m�F�L�[", "�����O���[�vID", _
        "�������s", "�\�����ID", "��֌�␔")
End Function

Public Function AnalysisGroupHeaders() As Variant
    AnalysisGroupHeaders = Array( _
        "�O���[�vID", "���\", "���s", "�m�F�L�[", "�\�����ID", "�X�R�A", _
        "��\", "�敪", "�m�F��", "�m�F����")
End Function

Public Sub SetupAnalysisWorkspaceSheets(Optional ByVal preserveVisibility As Boolean = False)
    Dim resultVisibility As XlSheetVisibility, detailVisibility As XlSheetVisibility
    If preserveVisibility Then
        resultVisibility = GetSheet(SH_ANALYSIS_RESULT).Visible
        detailVisibility = GetSheet(SH_ANALYSIS_DETAIL).Visible
    End If
    PrepareAnalysisResultSheet GetSheet(SH_ANALYSIS_RESULT)
    PrepareAnalysisDetailSheet GetSheet(SH_ANALYSIS_DETAIL)
    PrepareAnalysisGroupSheet GetSheet(SH_WORK_ANALYSIS_GROUP)
    If preserveVisibility Then
        GetSheet(SH_ANALYSIS_RESULT).Visible = resultVisibility
        GetSheet(SH_ANALYSIS_DETAIL).Visible = detailVisibility
    Else
        SetSheetVeryHiddenSafe GetSheet(SH_ANALYSIS_DETAIL)
    End If
    SetSheetVeryHiddenSafe GetSheet(SH_WORK_ANALYSIS_GROUP)
End Sub

Private Sub PrepareAnalysisResultSheet(ByVal ws As Worksheet)
    If ws Is Nothing Then Exit Sub
    ws.Unprotect Password:=TOOL_PASSWORD
    If ws.AutoFilterMode Then ws.AutoFilterMode = False
    ResetWorksheet ws
    SetRowValues ws.Range("A1"), AnalysisResultHeaders()
    FormatOutputHeader ws.Range(ws.Cells(1, 1), ws.Cells(1, ANALYSIS_RESULT_LAST_COL))
    ws.Columns("A:O").NumberFormatLocal = "@"
    ws.Columns("A:A").NumberFormatLocal = "0"
    ws.Columns("D:D").NumberFormatLocal = "#,##0.########"
    ApplyAnalysisResultColumnWidths ws
    ws.Rows(1).RowHeight = 52
    ws.Columns("J:O").Hidden = True
    AddManualBuilderHint ws
    ProtectSingleAnalysisSheet ws
End Sub

Private Sub PrepareAnalysisDetailSheet(ByVal ws As Worksheet)
    If ws Is Nothing Then Exit Sub
    ws.Unprotect Password:=TOOL_PASSWORD
    If ws.AutoFilterMode Then ws.AutoFilterMode = False
    ResetWorksheet ws
    With ws.Range("A1:L" & CStr(MANUAL_BUILDER_MAX_ROWS + MANUAL_BUILDER_HEADER_ROW + 5))
        .Font.Name = "Yu Gothic UI"
        .Font.Size = 10
    End With
    ws.Columns("A:A").ColumnWidth = 13
    ws.Columns("B:B").ColumnWidth = 14
    ws.Columns("C:C").ColumnWidth = 18
    ws.Columns("D:D").ColumnWidth = 28
    ws.Columns("E:E").ColumnWidth = 36
    ws.Columns("F:F").ColumnWidth = 18
    ws.Columns("G:G").ColumnWidth = 30
    ws.Columns("H:L").Hidden = True
    ws.Cells.Locked = True
    ProtectSingleAnalysisSheet ws
    mAnalysisDetailReviewsDirty = False
End Sub

Private Sub PrepareAnalysisGroupSheet(ByVal ws As Worksheet)
    If ws Is Nothing Then Exit Sub
    ws.Unprotect Password:=TOOL_PASSWORD
    ResetWorksheet ws
    SetRowValues ws.Range("A1"), AnalysisGroupHeaders()
    FormatOutputHeader ws.Range(ws.Cells(1, 1), ws.Cells(1, ANALYSIS_GROUP_LAST_COL))
    ws.Columns("A:J").NumberFormatLocal = "@"
    SetSheetVeryHiddenSafe ws
End Sub

Public Sub BuildAnalysisWorkspaceCore()
    Dim wsShift As Worksheet, wsFlow As Worksheet, wsUnknown As Worksheet
    Dim wsResult As Worksheet, wsGroup As Worksheet
    Dim shiftCount As Long, flowCount As Long, unknownCount As Long
    Dim candidateCount As Long, resultCount As Long
    Dim parent() As Long, sourceRows() As Long, scores() As Long
    Dim sourceSheets() As String, sourceKeys() As String, txIDs() As String
    Dim categories() As String, datesText() As String, routes() As String
    Dim points() As String, constraints() As String, statuses() As String, memos() As String
    Dim amounts() As Double
    Dim owners As Object
    Dim groupCounts() As Long, representatives() As Long
    Dim groupSeeds() As String, groupIDs() As String
    Dim i As Long, rootIndex As Long, groupTotal As Long, outputTotal As Long
    Dim resultBuffer() As Variant, resultBufferCount As Long, nextResultRow As Long
    Dim errorNumber As Long, errorDescription As String

    On Error GoTo EH
    Set wsShift = GetSheet(SH_ANALYSIS_SHIFT)
    Set wsFlow = GetSheet(SH_ANALYSIS_FLOW)
    Set wsUnknown = GetSheet(SH_ANALYSIS_UNKNOWN)
    Set wsResult = GetSheet(SH_ANALYSIS_RESULT)
    Set wsGroup = GetSheet(SH_WORK_ANALYSIS_GROUP)
    shiftCount = Application.Max(0, LastUsedRowInSheet(wsShift) - 1)
    flowCount = Application.Max(0, LastUsedRowInSheet(wsFlow) - 1)
    unknownCount = Application.Max(0, LastUsedRowInSheet(wsUnknown) - 1)
    candidateCount = shiftCount + flowCount
    If candidateCount > MAX_ANALYSIS_OUTPUT_ROWS * 2 Then _
        Err.Raise vbObjectError + 4800, "BuildAnalysisWorkspaceCore", _
                  "���͌��̓����������������p����𒴂��Ă��܂��B"

    PrepareAnalysisResultSheet wsResult
    PrepareAnalysisGroupSheet wsGroup
    PrepareAnalysisDetailSheet GetSheet(SH_ANALYSIS_DETAIL)
    SetSheetVeryHiddenSafe GetSheet(SH_ANALYSIS_DETAIL)

    If candidateCount > 0 Then
        ReDim parent(1 To candidateCount)
        ReDim sourceRows(1 To candidateCount)
        ReDim scores(1 To candidateCount)
        ReDim sourceSheets(1 To candidateCount)
        ReDim sourceKeys(1 To candidateCount)
        ReDim txIDs(1 To candidateCount)
        ReDim categories(1 To candidateCount)
        ReDim datesText(1 To candidateCount)
        ReDim routes(1 To candidateCount)
        ReDim points(1 To candidateCount)
        ReDim constraints(1 To candidateCount)
        ReDim statuses(1 To candidateCount)
        ReDim memos(1 To candidateCount)
        ReDim amounts(1 To candidateCount)
        Set owners = CreateObject("Scripting.Dictionary")
        owners.CompareMode = vbTextCompare
        i = 0
        LoadWorkspaceShiftCandidates wsShift, shiftCount, i, parent, sourceRows, scores, _
                                     sourceSheets, sourceKeys, txIDs, categories, datesText, _
                                     routes, points, constraints, statuses, memos, amounts, owners
        LoadWorkspaceFlowCandidates wsFlow, flowCount, i, parent, sourceRows, scores, _
                                    sourceSheets, sourceKeys, txIDs, categories, datesText, _
                                    routes, points, constraints, statuses, memos, amounts, owners

        ReDim groupCounts(1 To candidateCount)
        ReDim representatives(1 To candidateCount)
        ReDim groupSeeds(1 To candidateCount)
        ReDim groupIDs(1 To candidateCount)
        For i = 1 To candidateCount
            rootIndex = WorkspaceFindRoot(parent, i)
            groupCounts(rootIndex) = groupCounts(rootIndex) + 1
            groupSeeds(rootIndex) = groupSeeds(rootIndex) & sourceSheets(i) & ":" & sourceKeys(i) & "|"
            If representatives(rootIndex) = 0 Then
                representatives(rootIndex) = i
            ElseIf WorkspaceRepresentativeRank(statuses(i), scores(i)) > _
                   WorkspaceRepresentativeRank(statuses(representatives(rootIndex)), _
                                               scores(representatives(rootIndex))) Then
                representatives(rootIndex) = i
            End If
        Next i
        For i = 1 To candidateCount
            If groupCounts(i) > 0 Then
                groupTotal = groupTotal + 1
                groupIDs(i) = "G-" & WorkspaceDigest(groupSeeds(i))
            End If
        Next i
    End If

    resultCount = groupTotal + unknownCount
    If resultCount > MAX_ANALYSIS_OUTPUT_ROWS Then _
        Err.Raise vbObjectError + 4801, "BuildAnalysisWorkspaceCore", _
                  "������̕��͌��ʂ����p����i" & Format$(MAX_ANALYSIS_OUTPUT_ROWS, "#,##0") & _
                  "���j�𒴂��Ă��܂��B���͏������i���Ă��������B"

    If candidateCount > 0 Then
        WriteWorkspaceGroupTable wsGroup, candidateCount, parent, sourceRows, scores, _
                                 sourceSheets, sourceKeys, txIDs, categories, statuses, memos, _
                                 groupCounts, representatives, groupIDs
        ReDim resultBuffer(1 To WORKSPACE_BUFFER_ROWS, 1 To ANALYSIS_RESULT_LAST_COL)
        nextResultRow = 2
        For i = 1 To candidateCount
            If representatives(i) > 0 Then
                outputTotal = outputTotal + 1
                resultBufferCount = resultBufferCount + 1
                FillWorkspaceCandidateResult resultBuffer, resultBufferCount, representatives(i), _
                                              groupCounts(i), groupIDs(i), sourceRows, scores, _
                                              sourceSheets, sourceKeys, txIDs, categories, datesText, _
                                              routes, points, constraints, statuses, memos, amounts
                If resultBufferCount = WORKSPACE_BUFFER_ROWS Then
                    FlushWorkspaceBuffer wsResult, resultBuffer, resultBufferCount, nextResultRow, _
                                         ANALYSIS_RESULT_LAST_COL
                    ReDim resultBuffer(1 To WORKSPACE_BUFFER_ROWS, 1 To ANALYSIS_RESULT_LAST_COL)
                    resultBufferCount = 0
                End If
            End If
        Next i
        If resultBufferCount > 0 Then _
            FlushWorkspaceBuffer wsResult, resultBuffer, resultBufferCount, nextResultRow, _
                                 ANALYSIS_RESULT_LAST_COL
    End If
    If unknownCount > 0 Then _
        WriteWorkspaceUnknownResults wsUnknown, wsResult, outputTotal, unknownCount, wsGroup
    If outputTotal <> resultCount Then _
        Err.Raise vbObjectError + 4802, "BuildAnalysisWorkspaceCore", _
                  "���͌��ʂ̎��O�����Əo�͌�������v���܂���B"

    FinalizeAnalysisResultSheet wsResult, resultCount
    SetSheetVeryHiddenSafe wsResult
    SetSheetVeryHiddenSafe wsGroup
    Exit Sub
EH:
    errorNumber = Err.Number: errorDescription = Err.Description
    Err.Raise errorNumber, "BuildAnalysisWorkspaceCore", errorDescription
End Sub

Private Sub LoadWorkspaceShiftCandidates( _
        ByVal ws As Worksheet, ByVal itemCount As Long, ByRef outputIndex As Long, _
        ByRef parent() As Long, ByRef sourceRows() As Long, ByRef scores() As Long, _
        ByRef sourceSheets() As String, ByRef sourceKeys() As String, ByRef txIDs() As String, _
        ByRef categories() As String, ByRef datesText() As String, ByRef routes() As String, _
        ByRef points() As String, ByRef constraints() As String, ByRef statuses() As String, _
        ByRef memos() As String, ByRef amounts() As Double, ByVal owners As Object)
    Dim data As Variant, r As Long, itemIndex As Long
    If itemCount <= 0 Then Exit Sub
    data = ws.Range(ws.Cells(2, 1), ws.Cells(itemCount + 1, SHIFT_ANALYSIS_LAST_COL)).Value2
    For r = 1 To itemCount
        If r Mod 2048 = 0 Then AppProgress "�����V�t�g���𒲍��P�ʂ֐������Ă��܂�...", r, itemCount
        outputIndex = outputIndex + 1: itemIndex = outputIndex
        parent(itemIndex) = itemIndex
        sourceRows(itemIndex) = r + 1
        sourceSheets(itemIndex) = SH_ANALYSIS_SHIFT
        sourceKeys(itemIndex) = CellText(data(r, SHIFT_ANALYSIS_KEY_COL))
        txIDs(itemIndex) = WorkspaceJoinIDs(CellText(data(r, 33)), CellText(data(r, 34)))
        scores(itemIndex) = WorkspaceLong(data(r, 2))
        categories(itemIndex) = "�����V�t�g"
        datesText(itemIndex) = WorkspacePeriodText(data(r, 9), data(r, 19))
        amounts(itemIndex) = WorkspaceDouble(data(r, 17))
        routes(itemIndex) = WorkspacePartyAccount(data(r, 11), data(r, 12), data(r, 13), _
                            data(r, 14), data(r, 15), data(r, 16)) & " �� " & _
                            WorkspacePartyAccount(data(r, 21), data(r, 22), data(r, 23), _
                            data(r, 24), data(r, 25), data(r, 26))
        points(itemIndex) = WorkspaceTrimText(CellText(data(r, 1)) & "�E" & _
                            CellText(data(r, 3)) & "�E" & CellText(data(r, 4)) & "�B" & _
                            CellText(data(r, 29)), WORKSPACE_TEXT_LIMIT)
        constraints(itemIndex) = WorkspaceTrimText("�������x: " & CellText(data(r, 5)) & _
                                 " / �o��: " & CellText(data(r, 6)) & _
                                 " / ���z��: " & WorkspaceAmountText(data(r, 8)), WORKSPACE_TEXT_LIMIT)
        statuses(itemIndex) = WorkspaceStatusOrDefault(data(r, SHIFT_ANALYSIS_STATUS_COL))
        memos(itemIndex) = CellText(data(r, SHIFT_ANALYSIS_MEMO_COL))
        RegisterWorkspaceOwners txIDs(itemIndex), itemIndex, parent, owners
    Next r
End Sub

Private Sub LoadWorkspaceFlowCandidates( _
        ByVal ws As Worksheet, ByVal itemCount As Long, ByRef outputIndex As Long, _
        ByRef parent() As Long, ByRef sourceRows() As Long, ByRef scores() As Long, _
        ByRef sourceSheets() As String, ByRef sourceKeys() As String, ByRef txIDs() As String, _
        ByRef categories() As String, ByRef datesText() As String, ByRef routes() As String, _
        ByRef points() As String, ByRef constraints() As String, ByRef statuses() As String, _
        ByRef memos() As String, ByRef amounts() As Double, ByVal owners As Object)
    Dim data As Variant, r As Long, itemIndex As Long
    If itemCount <= 0 Then Exit Sub
    data = ws.Range(ws.Cells(2, 1), ws.Cells(itemCount + 1, FLOW_ANALYSIS_LAST_COL)).Value2
    For r = 1 To itemCount
        If r Mod 2048 = 0 Then AppProgress "�����t���[���𒲍��P�ʂ֐������Ă��܂�...", r, itemCount
        outputIndex = outputIndex + 1: itemIndex = outputIndex
        parent(itemIndex) = itemIndex
        sourceRows(itemIndex) = r + 1
        sourceSheets(itemIndex) = SH_ANALYSIS_FLOW
        sourceKeys(itemIndex) = CellText(data(r, FLOW_ANALYSIS_KEY_COL))
        txIDs(itemIndex) = CellText(data(r, 20))
        scores(itemIndex) = WorkspaceLong(data(r, 2))
        categories(itemIndex) = "�����t���["
        datesText(itemIndex) = CellText(data(r, 6))
        amounts(itemIndex) = WorkspaceDouble(data(r, 9))
        routes(itemIndex) = WorkspaceTrimText(CellText(data(r, 12)), WORKSPACE_TEXT_LIMIT)
        points(itemIndex) = WorkspaceTrimText(CellText(data(r, 3)) & "�E" & _
                            CellText(data(r, 4)) & "�B" & CellText(data(r, 16)), WORKSPACE_TEXT_LIMIT)
        constraints(itemIndex) = WorkspaceTrimText("�������x: " & CellText(data(r, 5)) & _
                                 " / �N�I�_��: " & WorkspaceAmountText(data(r, 11)) & _
                                 " / " & CStr(WorkspaceLong(data(r, 7))) & "�i�E" & _
                                 CStr(WorkspaceLong(data(r, 8))) & "���", WORKSPACE_TEXT_LIMIT)
        statuses(itemIndex) = WorkspaceStatusOrDefault(data(r, FLOW_ANALYSIS_STATUS_COL))
        memos(itemIndex) = CellText(data(r, FLOW_ANALYSIS_MEMO_COL))
        RegisterWorkspaceOwners txIDs(itemIndex), itemIndex, parent, owners
    Next r
End Sub

Private Sub RegisterWorkspaceOwners(ByVal idList As String, ByVal itemIndex As Long, _
                                    ByRef parent() As Long, ByVal owners As Object)
    Dim parts As Variant, item As Variant, txID As String
    If Len(idList) = 0 Then Exit Sub
    parts = Split(idList, ";")
    For Each item In parts
        txID = Trim$(CStr(item))
        If Len(txID) > 0 Then
            If owners.Exists(txID) Then
                WorkspaceUnion parent, itemIndex, CLng(owners(txID))
            Else
                owners.Add txID, itemIndex
            End If
        End If
    Next item
End Sub

Private Function WorkspaceFindRoot(ByRef parent() As Long, ByVal itemIndex As Long) As Long
    Dim rootIndex As Long, nextIndex As Long
    rootIndex = itemIndex
    Do While parent(rootIndex) <> rootIndex
        rootIndex = parent(rootIndex)
    Loop
    Do While parent(itemIndex) <> itemIndex
        nextIndex = parent(itemIndex)
        parent(itemIndex) = rootIndex
        itemIndex = nextIndex
    Loop
    WorkspaceFindRoot = rootIndex
End Function

Private Sub WorkspaceUnion(ByRef parent() As Long, ByVal firstIndex As Long, ByVal secondIndex As Long)
    Dim firstRoot As Long, secondRoot As Long
    firstRoot = WorkspaceFindRoot(parent, firstIndex)
    secondRoot = WorkspaceFindRoot(parent, secondIndex)
    If firstRoot = secondRoot Then Exit Sub
    If firstRoot < secondRoot Then
        parent(secondRoot) = firstRoot
    Else
        parent(firstRoot) = secondRoot
    End If
End Sub

Private Function WorkspaceRepresentativeRank(ByVal statusText As String, ByVal score As Long) As Long
    Select Case Trim$(statusText)
        Case ANALYSIS_STATUS_SHIFT_CONFIRMED
            WorkspaceRepresentativeRank = 300000 + score
        Case ANALYSIS_STATUS_FOLLOWUP
            WorkspaceRepresentativeRank = 200000 + score
        Case ANALYSIS_STATUS_EXCLUDED
            WorkspaceRepresentativeRank = 50000 + score
        Case Else
            WorkspaceRepresentativeRank = 100000 + score
    End Select
End Function

Private Sub WriteWorkspaceGroupTable( _
        ByVal ws As Worksheet, ByVal candidateCount As Long, ByRef parent() As Long, _
        ByRef sourceRows() As Long, ByRef scores() As Long, ByRef sourceSheets() As String, _
        ByRef sourceKeys() As String, ByRef txIDs() As String, ByRef categories() As String, _
        ByRef statuses() As String, ByRef memos() As String, ByRef groupCounts() As Long, _
        ByRef representatives() As Long, ByRef groupIDs() As String)
    Dim buffer() As Variant, bufferCount As Long, nextRow As Long
    Dim i As Long, rootIndex As Long
    ReDim buffer(1 To WORKSPACE_BUFFER_ROWS, 1 To ANALYSIS_GROUP_LAST_COL)
    nextRow = 2
    For i = 1 To candidateCount
        rootIndex = WorkspaceFindRoot(parent, i)
        bufferCount = bufferCount + 1
        buffer(bufferCount, 1) = groupIDs(rootIndex)
        buffer(bufferCount, 2) = sourceSheets(i)
        buffer(bufferCount, 3) = sourceRows(i)
        buffer(bufferCount, 4) = sourceKeys(i)
        buffer(bufferCount, 5) = txIDs(i)
        buffer(bufferCount, 6) = scores(i)
        If representatives(rootIndex) = i Then buffer(bufferCount, 7) = "��\" Else buffer(bufferCount, 7) = "���"
        buffer(bufferCount, 8) = categories(i)
        buffer(bufferCount, 9) = statuses(i)
        buffer(bufferCount, 10) = memos(i)
        If bufferCount = WORKSPACE_BUFFER_ROWS Then
            FlushWorkspaceBuffer ws, buffer, bufferCount, nextRow, ANALYSIS_GROUP_LAST_COL
            ReDim buffer(1 To WORKSPACE_BUFFER_ROWS, 1 To ANALYSIS_GROUP_LAST_COL)
            bufferCount = 0
        End If
    Next i
    If bufferCount > 0 Then FlushWorkspaceBuffer ws, buffer, bufferCount, nextRow, ANALYSIS_GROUP_LAST_COL
End Sub

Private Sub FillWorkspaceCandidateResult( _
        ByRef buffer As Variant, ByVal bufferRow As Long, ByVal itemIndex As Long, _
        ByVal alternativeCount As Long, ByVal groupID As String, _
        ByRef sourceRows() As Long, ByRef scores() As Long, ByRef sourceSheets() As String, _
        ByRef sourceKeys() As String, ByRef txIDs() As String, ByRef categories() As String, _
        ByRef datesText() As String, ByRef routes() As String, ByRef points() As String, _
        ByRef constraints() As String, ByRef statuses() As String, ByRef memos() As String, _
        ByRef amounts() As Double)
    Dim constraintText As String
    constraintText = constraints(itemIndex)
    If alternativeCount > 1 Then
        constraintText = WorkspaceAppend(constraintText, "������������L�����։��� " & _
                         CStr(alternativeCount) & _
                         "���B��������\�ō\������Ɗ֘A�����؂�ւ��Ċm�F���Ă��������B", " / ")
    End If
    buffer(bufferRow, 1) = scores(itemIndex)
    buffer(bufferRow, 2) = categories(itemIndex)
    buffer(bufferRow, 3) = datesText(itemIndex)
    buffer(bufferRow, 4) = amounts(itemIndex)
    buffer(bufferRow, 5) = routes(itemIndex)
    buffer(bufferRow, 6) = points(itemIndex)
    buffer(bufferRow, 7) = WorkspaceTrimText(constraintText, WORKSPACE_TEXT_LIMIT)
    buffer(bufferRow, 8) = statuses(itemIndex)
    buffer(bufferRow, 9) = memos(itemIndex)
    buffer(bufferRow, 10) = sourceSheets(itemIndex)
    buffer(bufferRow, 11) = sourceKeys(itemIndex)
    buffer(bufferRow, 12) = groupID
    buffer(bufferRow, 13) = sourceRows(itemIndex)
    buffer(bufferRow, 14) = txIDs(itemIndex)
    buffer(bufferRow, 15) = alternativeCount
End Sub

Private Sub WriteWorkspaceUnknownResults(ByVal wsUnknown As Worksheet, ByVal wsResult As Worksheet, _
                                         ByRef outputTotal As Long, ByVal unknownCount As Long, _
                                         ByVal wsGroup As Worksheet)
    Dim data As Variant, resultBuffer() As Variant, groupBuffer() As Variant
    Dim resultBufferCount As Long, groupBufferCount As Long
    Dim nextResultRow As Long, nextGroupRow As Long
    Dim r As Long, categoryText As String, txID As String, groupID As String
    Dim amountValue As Double, timeText As String, routeText As String
    nextResultRow = outputTotal + 2
    nextGroupRow = LastUsedRowInSheet(wsGroup) + 1
    If nextGroupRow < 2 Then nextGroupRow = 2
    ReDim resultBuffer(1 To WORKSPACE_BUFFER_ROWS, 1 To ANALYSIS_RESULT_LAST_COL)
    ReDim groupBuffer(1 To WORKSPACE_BUFFER_ROWS, 1 To ANALYSIS_GROUP_LAST_COL)
    data = wsUnknown.Range(wsUnknown.Cells(2, 1), _
                           wsUnknown.Cells(unknownCount + 1, UNKNOWN_ANALYSIS_LAST_COL)).Value2
    For r = 1 To unknownCount
        txID = CellText(data(r, 24))
        groupID = "U-" & WorkspaceDigest(txID & "|" & CellText(data(r, 26)))
        If StrComp(CellText(data(r, 3)), "�����s�����", vbTextCompare) = 0 Then
            categoryText = "�����s��"
            amountValue = WorkspaceDouble(data(r, 13))
        Else
            categoryText = "�g�r�s��"
            amountValue = WorkspaceDouble(data(r, 14))
        End If
        timeText = WorkspaceTimeText(data(r, 5))
        routeText = WorkspacePartyAccount(data(r, 7), data(r, 8), data(r, 9), _
                    data(r, 10), data(r, 11), data(r, 12))
        resultBufferCount = resultBufferCount + 1
        resultBuffer(resultBufferCount, 1) = WorkspaceLong(data(r, 2))
        resultBuffer(resultBufferCount, 2) = categoryText
        resultBuffer(resultBufferCount, 3) = WorkspaceDateText(data(r, 4)) & " " & timeText
        resultBuffer(resultBufferCount, 4) = amountValue
        resultBuffer(resultBufferCount, 5) = routeText
        resultBuffer(resultBufferCount, 6) = WorkspaceTrimText(CellText(data(r, 20)), WORKSPACE_TEXT_LIMIT)
        resultBuffer(resultBufferCount, 7) = WorkspaceTrimText( _
            "�������x: " & CellText(data(r, 6)) & " / ���: " & CellText(data(r, 18)) & _
            " / �ō��]��: " & CellText(data(r, 19)) & " / �E�v: " & _
            WorkspaceBlankLabel(data(r, 17)), WORKSPACE_TEXT_LIMIT)
        resultBuffer(resultBufferCount, 8) = WorkspaceStatusOrDefault(data(r, 21))
        resultBuffer(resultBufferCount, 9) = CellText(data(r, 22))
        resultBuffer(resultBufferCount, 10) = SH_ANALYSIS_UNKNOWN
        resultBuffer(resultBufferCount, 11) = CellText(data(r, 26))
        resultBuffer(resultBufferCount, 12) = groupID
        resultBuffer(resultBufferCount, 13) = r + 1
        resultBuffer(resultBufferCount, 14) = txID
        resultBuffer(resultBufferCount, 15) = 1

        groupBufferCount = groupBufferCount + 1
        groupBuffer(groupBufferCount, 1) = groupID
        groupBuffer(groupBufferCount, 2) = SH_ANALYSIS_UNKNOWN
        groupBuffer(groupBufferCount, 3) = r + 1
        groupBuffer(groupBufferCount, 4) = CellText(data(r, 26))
        groupBuffer(groupBufferCount, 5) = txID
        groupBuffer(groupBufferCount, 6) = WorkspaceLong(data(r, 2))
        groupBuffer(groupBufferCount, 7) = "��\"
        groupBuffer(groupBufferCount, 8) = categoryText
        groupBuffer(groupBufferCount, 9) = WorkspaceStatusOrDefault(data(r, 21))
        groupBuffer(groupBufferCount, 10) = CellText(data(r, 22))
        outputTotal = outputTotal + 1

        If resultBufferCount = WORKSPACE_BUFFER_ROWS Then
            FlushWorkspaceBuffer wsResult, resultBuffer, resultBufferCount, nextResultRow, ANALYSIS_RESULT_LAST_COL
            ReDim resultBuffer(1 To WORKSPACE_BUFFER_ROWS, 1 To ANALYSIS_RESULT_LAST_COL)
            resultBufferCount = 0
        End If
        If groupBufferCount = WORKSPACE_BUFFER_ROWS Then
            FlushWorkspaceBuffer wsGroup, groupBuffer, groupBufferCount, nextGroupRow, ANALYSIS_GROUP_LAST_COL
            ReDim groupBuffer(1 To WORKSPACE_BUFFER_ROWS, 1 To ANALYSIS_GROUP_LAST_COL)
            groupBufferCount = 0
        End If
    Next r
    If resultBufferCount > 0 Then _
        FlushWorkspaceBuffer wsResult, resultBuffer, resultBufferCount, nextResultRow, ANALYSIS_RESULT_LAST_COL
    If groupBufferCount > 0 Then _
        FlushWorkspaceBuffer wsGroup, groupBuffer, groupBufferCount, nextGroupRow, ANALYSIS_GROUP_LAST_COL
End Sub

Private Sub FlushWorkspaceBuffer(ByVal ws As Worksheet, ByRef buffer As Variant, _
                                 ByVal bufferCount As Long, ByRef nextRow As Long, _
                                 ByVal columnCount As Long)
    Dim outputData() As Variant, r As Long, c As Long
    If bufferCount <= 0 Then Exit Sub
    ReDim outputData(1 To bufferCount, 1 To columnCount)
    For r = 1 To bufferCount
        For c = 1 To columnCount
            outputData(r, c) = buffer(r, c)
        Next c
    Next r
    ws.Range(ws.Cells(nextRow, 1), ws.Cells(nextRow + bufferCount - 1, columnCount)).Value = outputData
    nextRow = nextRow + bufferCount
End Sub

Private Sub FinalizeAnalysisResultSheet(ByVal ws As Worksheet, ByVal dataCount As Long)
    Dim lastR As Long
    lastR = dataCount + 1
    ws.Unprotect Password:=TOOL_PASSWORD
    FormatOutputHeader ws.Range(ws.Cells(1, 1), ws.Cells(1, ANALYSIS_RESULT_LAST_COL))
    ApplyAnalysisResultColumnWidths ws
    ws.Rows(1).RowHeight = 52
    ws.Columns("J:O").Hidden = True
    If dataCount > 0 Then
        With ws.Range(ws.Cells(2, 1), ws.Cells(lastR, ANALYSIS_RESULT_VISIBLE_COL))
            .VerticalAlignment = xlTop
            .WrapText = True
        End With
        With ws.Range(ws.Cells(2, 1), ws.Cells(lastR, 4))
            .VerticalAlignment = xlCenter
        End With
        ws.Range(ws.Cells(2, 1), ws.Cells(lastR, 3)).HorizontalAlignment = xlCenter
        ws.Range(ws.Cells(2, 4), ws.Cells(lastR, 4)).HorizontalAlignment = xlRight
        ws.Range(ws.Cells(2, ANALYSIS_RESULT_STATUS_COL), _
                 ws.Cells(lastR, ANALYSIS_RESULT_STATUS_COL)).HorizontalAlignment = xlCenter
        ws.Range(ws.Cells(2, 1), ws.Cells(lastR, 1)).Font.Bold = True
        ws.Range(ws.Cells(2, ANALYSIS_RESULT_STATUS_COL), _
                 ws.Cells(lastR, ANALYSIS_RESULT_MEMO_COL)).Interior.Color = RGB(254, 249, 195)
        With ws.Range(ws.Cells(2, 1), ws.Cells(lastR, 7)).FormatConditions
            .Delete
            .Add Type:=xlExpression, Formula1:="=MOD(ROW(),2)=0"
            .Item(.Count).Interior.Color = RGB(248, 250, 252)
        End With
        ws.Rows("2:" & CStr(lastR)).RowHeight = 62
        SortAnalysisResult ws, lastR
    End If
    If ws.AutoFilterMode Then ws.AutoFilterMode = False
    ws.Range(ws.Cells(1, 1), ws.Cells(lastR, ANALYSIS_RESULT_LAST_COL)).AutoFilter
    ws.ScrollArea = "A1:I" & CStr(Application.Max(50, lastR + 20))
    ApplyWorkspaceReviewValidation ws, lastR
    AddManualBuilderHint ws
    SafeFreezeSheetAt ws, "A2", 85
    ProtectSingleAnalysisSheet ws
End Sub

Private Sub AddManualBuilderHint(ByVal ws As Worksheet)
    Dim i As Long
    Dim x As Double, y As Double, w As Double
    Dim errorNumber As Long, errorDescription As String
    If ws Is Nothing Then Exit Sub
    On Error GoTo EH
    For i = ws.Shapes.Count To 1 Step -1
        If ToolShapeActionName(ws.Shapes(i)) = "OpenManualAnalysisCandidateBuilder" Then _
            ws.Shapes(i).Delete
    Next i
    If Not ws.Cells(1, 1).Comment Is Nothing Then ws.Cells(1, 1).Comment.Delete
    ws.Cells(1, 1).AddComment _
        "�������ɂȂ������ړ��́A���o����̃{�^���܂��͌��o���s�̃_�u���N���b�N����쐬�ł��܂��B" & _
        vbCrLf & "�S�������o���E�����𕡐��I���ł��܂��B"
    ws.Cells(1, 1).Comment.Visible = False
    '���o���̏㔼���������ȃc�[���o�[�Ƃ��Ďg���A�B�����삾�����蓮���쐬�𖾎�����B
    ws.Range("A1:I1").VerticalAlignment = xlBottom
    x = ws.Range("F1").Left + 3
    y = ws.Range("F1").Top + 2
    w = ws.Range("F1:I1").Width - 6
    AddUIButton ws, x, y, w, 20, "�{ �蓮�����쐬", _
                "OpenManualAnalysisCandidateBuilder", "tool"
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    Err.Raise errorNumber, "AddManualBuilderHint", errorDescription
End Sub

Private Sub ApplyAnalysisResultColumnWidths(ByVal ws As Worksheet)
    ws.Columns("A:A").ColumnWidth = 9
    ws.Columns("B:B").ColumnWidth = 12
    ws.Columns("C:C").ColumnWidth = 16
    ws.Columns("D:D").ColumnWidth = 13
    ws.Columns("E:E").ColumnWidth = 23
    ws.Columns("F:F").ColumnWidth = 28
    ws.Columns("G:G").ColumnWidth = 24
    ws.Columns("H:H").ColumnWidth = 14
    ws.Columns("I:I").ColumnWidth = 22
End Sub

Private Sub SortAnalysisResult(ByVal ws As Worksheet, ByVal lastR As Long)
    With ws.Sort
        .SortFields.Clear
        .SortFields.Add Key:=ws.Range(ws.Cells(2, 1), ws.Cells(lastR, 1)), _
                        SortOn:=xlSortOnValues, Order:=xlDescending, DataOption:=xlSortNormal
        .SortFields.Add Key:=ws.Range(ws.Cells(2, 2), ws.Cells(lastR, 2)), _
                        SortOn:=xlSortOnValues, Order:=xlAscending, DataOption:=xlSortNormal
        .SortFields.Add Key:=ws.Range(ws.Cells(2, 3), ws.Cells(lastR, 3)), _
                        SortOn:=xlSortOnValues, Order:=xlAscending, DataOption:=xlSortNormal
        .SetRange ws.Range(ws.Cells(1, 1), ws.Cells(lastR, ANALYSIS_RESULT_LAST_COL))
        .Header = xlYes
        .Apply
    End With
End Sub

Private Sub ApplyWorkspaceReviewValidation(ByVal ws As Worksheet, ByVal lastR As Long)
    Dim statusRange As Range, memoRange As Range
    ws.Cells.Locked = True
    If lastR < 2 Then Exit Sub
    Set statusRange = ws.Range(ws.Cells(2, ANALYSIS_RESULT_STATUS_COL), _
                               ws.Cells(lastR, ANALYSIS_RESULT_STATUS_COL))
    Set memoRange = ws.Range(ws.Cells(2, ANALYSIS_RESULT_MEMO_COL), _
                             ws.Cells(lastR, ANALYSIS_RESULT_MEMO_COL))
    statusRange.Locked = False
    memoRange.Locked = False
    With statusRange.Validation
        .Delete
        .Add Type:=xlValidateList, AlertStyle:=xlValidAlertStop, Operator:=xlBetween, _
             Formula1:="=INDIRECT(IF(OR($B2=""�����V�t�g"",$B2=""�����t���[""),""" & _
                      NM_LST_ANALYSIS_SHIFT_STATUS & """,IF($B2=""�����s��"",""" & _
                      NM_LST_ANALYSIS_SOURCE_STATUS & """,""" & NM_LST_ANALYSIS_USE_STATUS & """)))"
        .IgnoreBlank = True
        .InCellDropdown = True
        .ShowError = True
        .ErrorTitle = "�m�F�󋵂�I�����Ă�������"
        .ErrorMessage = "�s�̋敪�ɑΉ�����m�F�󋵂�I�����Ă��������B"
    End With
    With memoRange.Validation
        .Delete
        .Add Type:=xlValidateTextLength, AlertStyle:=xlValidAlertStop, _
             Operator:=xlLessEqual, Formula1:=CStr(WORKSPACE_MEMO_MAX)
        .IgnoreBlank = True
        .ShowError = True
        .ErrorTitle = "�m�F�����̕��������m�F���Ă�������"
        .ErrorMessage = "�m�F������" & CStr(WORKSPACE_MEMO_MAX) & "�����ȓ��œ��͂��Ă��������B"
    End With
End Sub

Public Sub SetAnalysisReviewEditingEnabled(ByVal enabled As Boolean)
    Dim ws As Worksheet, lastR As Long, r As Long
    Dim workbookWasSaved As Boolean
    Dim errorNumber As Long, errorDescription As String
    workbookWasSaved = ThisWorkbook.Saved
    On Error GoTo EH
    If SheetExists(SH_ANALYSIS_RESULT) Then
        Set ws = GetSheet(SH_ANALYSIS_RESULT)
        ws.Unprotect Password:=TOOL_PASSWORD
        lastR = LastUsedRowInSheet(ws)
        If enabled Then
            ApplyWorkspaceReviewValidation ws, lastR
        Else
            ws.Range(ws.Cells(1, 1), _
                     ws.Cells(Application.Max(50, lastR + 20), ANALYSIS_RESULT_LAST_COL)).Locked = True
        End If
        ProtectSingleAnalysisSheet ws
    End If
    If SheetExists(SH_ANALYSIS_DETAIL) Then
        Set ws = GetSheet(SH_ANALYSIS_DETAIL)
        ws.Unprotect Password:=TOOL_PASSWORD
        lastR = LastUsedRowInSheet(ws)
        ws.Range(ws.Cells(1, 1), _
                 ws.Cells(Application.Max(50, lastR + 20), DETAIL_COL_KIND)).Locked = True
        If enabled Then
            For r = 2 To lastR
                If CellText(ws.Cells(r, DETAIL_COL_KIND).Value) = "���" Then
                    ws.Cells(r, 6).Locked = False
                ElseIf CellText(ws.Cells(r, DETAIL_COL_KIND).Value) = "��⃁��" Then
                    ws.Range(ws.Cells(r, 2), ws.Cells(r, 7)).Locked = False
                End If
            Next r
        End If
        ProtectSingleAnalysisSheet ws
    End If
    If workbookWasSaved Then ThisWorkbook.Saved = True
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    On Error Resume Next
    If Not ws Is Nothing Then EmergencyProtectToolSheet ws
    If workbookWasSaved Then ThisWorkbook.Saved = True
    On Error GoTo 0
    Err.Raise errorNumber, "SetAnalysisReviewEditingEnabled", errorDescription
End Sub

Public Sub SyncAnalysisWorkspaceReviewsToSources()
    Dim wsResult As Worksheet, lastR As Long, resultData As Variant
    Dim checkRange As Range, formulaCells As Range, errorCells As Range
    Dim r As Long, statusCol As Long, memoCol As Long, keyCol As Long
    Dim sourceSheet As String
    If Not SheetExists(SH_ANALYSIS_RESULT) Then Exit Sub
    Set wsResult = GetSheet(SH_ANALYSIS_RESULT)
    lastR = LastUsedRowInSheet(wsResult)
    If lastR < 2 Then Exit Sub
    Set checkRange = Union( _
        wsResult.Range(wsResult.Cells(2, ANALYSIS_RESULT_STATUS_COL), _
                       wsResult.Cells(lastR, ANALYSIS_RESULT_MEMO_COL)), _
        wsResult.Range(wsResult.Cells(2, ANALYSIS_RESULT_SOURCE_SHEET_COL), _
                       wsResult.Cells(lastR, ANALYSIS_RESULT_ALTERNATIVE_COUNT_COL)))
    On Error Resume Next
    Set formulaCells = checkRange.SpecialCells(xlCellTypeFormulas)
    Set errorCells = checkRange.SpecialCells(xlCellTypeConstants, xlErrors)
    On Error GoTo 0
    If Not formulaCells Is Nothing Then _
        Err.Raise vbObjectError + 4803, "SyncAnalysisWorkspaceReviewsToSources", _
                  "���͌��ʂ̊m�F���܂��͓����Q�Ƃɐ���������܂��B"
    If Not errorCells Is Nothing Then _
        Err.Raise vbObjectError + 4804, "SyncAnalysisWorkspaceReviewsToSources", _
                  "���͌��ʂ̊m�F���܂��͓����Q�Ƃ�Excel�G���[������܂��B"
    resultData = wsResult.Range(wsResult.Cells(2, 1), _
                                wsResult.Cells(lastR, ANALYSIS_RESULT_LAST_COL)).Value2
    For r = 1 To lastR - 1
        sourceSheet = CellText(resultData(r, ANALYSIS_RESULT_SOURCE_SHEET_COL))
        If Not WorkspaceSourceColumns(sourceSheet, statusCol, memoCol, keyCol) Then _
            Err.Raise vbObjectError + 4805, "SyncAnalysisWorkspaceReviewsToSources", _
                      "���͌��� " & CStr(r + 1) & "�s�ڂ̓������\���s���ł��B"
    Next r
    SyncWorkspaceSourceReviews resultData, lastR - 1, SH_ANALYSIS_SHIFT
    SyncWorkspaceSourceReviews resultData, lastR - 1, SH_ANALYSIS_FLOW
    SyncWorkspaceSourceReviews resultData, lastR - 1, SH_ANALYSIS_UNKNOWN
End Sub

Public Sub SyncAnalysisDetailReviewsToSources()
    Dim wsDetail As Worksheet, wsSource As Worksheet
    Dim lastR As Long, r As Long, sourceRow As Long
    Dim sourceSheet As String, sourceKey As String, actualKey As String
    Dim statusText As String, memoText As String, categoryText As String
    Dim statusCol As Long, memoCol As Long, keyCol As Long
    If Not SheetExists(SH_ANALYSIS_DETAIL) Then Exit Sub
    Set wsDetail = GetSheet(SH_ANALYSIS_DETAIL)
    lastR = LastUsedRowInSheet(wsDetail)
    If lastR < 2 Then Exit Sub
    For r = 2 To lastR
        If CellText(wsDetail.Cells(r, DETAIL_COL_KIND).Value) = "���" Then
            sourceSheet = CellText(wsDetail.Cells(r, DETAIL_COL_REFERENCE).Value)
            sourceRow = WorkspaceLong(wsDetail.Cells(r, DETAIL_COL_SOURCE_ROW).Value)
            sourceKey = CellText(wsDetail.Cells(r, DETAIL_COL_SOURCE_KEY).Value)
            If Not WorkspaceSourceColumns(sourceSheet, statusCol, memoCol, keyCol) Then _
                Err.Raise vbObjectError + 4812, "SyncAnalysisDetailReviewsToSources", _
                          "���ڍ� " & CStr(r) & "�s�ڂ̓������\���s���ł��B"
            Set wsSource = GetSheet(sourceSheet)
            If sourceRow < 2 Or sourceRow > LastUsedRowInSheet(wsSource) Then _
                Err.Raise vbObjectError + 4813, "SyncAnalysisDetailReviewsToSources", _
                          "���ڍ� " & CStr(r) & "�s�ڂ̓������s��������܂���B"
            actualKey = CellText(wsSource.Cells(sourceRow, keyCol).Value)
            If Len(sourceKey) = 0 Or StrComp(actualKey, sourceKey, vbBinaryCompare) <> 0 Then _
                Err.Raise vbObjectError + 4814, "SyncAnalysisDetailReviewsToSources", _
                          "���ڍ� " & CStr(r) & "�s�ڂƓ��������̊m�F�L�[����v���܂���B"
            statusText = WorkspaceStatusOrDefault(wsDetail.Cells(r, 6).Value)
            categoryText = CellText(wsDetail.Cells(r, 1).Value)
            If Not WorkspaceStatusFitsSource(sourceSheet, categoryText, statusText) Then _
                Err.Raise vbObjectError + 4815, "SyncAnalysisDetailReviewsToSources", _
                          "���ڍ� " & CStr(r) & "�s�ڂ̊m�F�󋵂��敪�ɓK�����܂���B"
            If r + 1 > lastR Or _
               CellText(wsDetail.Cells(r + 1, DETAIL_COL_KIND).Value) <> "��⃁��" Then _
                Err.Raise vbObjectError + 4816, "SyncAnalysisDetailReviewsToSources", _
                          "���ڍ� " & CStr(r) & "�s�ڂ̌ʃ�����������܂���B"
            memoText = CellText(wsDetail.Cells(r + 1, 2).Value)
            If Len(memoText) > WORKSPACE_MEMO_MAX Then _
                Err.Raise vbObjectError + 4817, "SyncAnalysisDetailReviewsToSources", _
                          "���ڍ� " & CStr(r + 1) & "�s�ڂ̊m�F�������������܂��B"
            wsSource.Cells(sourceRow, statusCol).Value = statusText
            wsSource.Cells(sourceRow, memoCol).Value = memoText
        End If
    Next r
    mAnalysisDetailReviewsDirty = False
End Sub

Public Sub CommitAnalysisDetailReviews()
    CommitPendingAnalysisReviews False, "���ڍׂ̌ʊm�F��ۑ�"
End Sub

Public Function HasPendingAnalysisReviewChanges() As Boolean
    If AnalysisReviewsAreDirty() Or mAnalysisDetailReviewsDirty Then
        HasPendingAnalysisReviewChanges = True
    ElseIf AnalysisWorkspaceReviewsDifferFromSources() Then
        HasPendingAnalysisReviewChanges = True
    ElseIf AnalysisDetailReviewsDifferFromSources() Then
        HasPendingAnalysisReviewChanges = True
    End If
End Function

Public Sub CommitPendingAnalysisReviews( _
        Optional ByVal rebuildWorkspace As Boolean = False, _
        Optional ByVal reasonText As String = "���͔��f��ۑ�")
    Dim previousEvents As Boolean, errorNumber As Long, errorDescription As String
    If Not HasPendingAnalysisReviewChanges() Then Exit Sub
    If ThisWorkbook.ReadOnly Then _
        Err.Raise vbObjectError + 4820, "CommitPendingAnalysisReviews", _
                  "�ǂݎ���p�̂��߁A���͂̊m�F�󋵂ƃ�����ۑ��ł��܂���B"
    previousEvents = Application.EnableEvents
    On Error GoTo EH
    Application.EnableEvents = False
    '�ꗗ�Əڍׂ̗����𓯊����A�ڍב��̌ʔ��f���Ō�ɗD�悷��B
    SyncAnalysisWorkspaceReviewsToSources
    SyncAnalysisDetailReviewsToSources
    SyncManualFlowReviewsFromAnalysisSheet
    ResolveAnalysisReviewConflicts GetSheet(SH_ANALYSIS_SHIFT), GetSheet(SH_ANALYSIS_FLOW)
    SyncManualFlowReviewsFromAnalysisSheet
    PersistAnalysisReviewsFromCurrentSheets False, reasonText
    If rebuildWorkspace Then
        BuildAnalysisWorkspaceCore
    Else
        RefreshAnalysisReviewDisplaysFromSources
    End If
    MarkAnalysisReviewsClean
    mAnalysisDetailReviewsDirty = False
    Application.EnableEvents = previousEvents
    Exit Sub
EH:
    errorNumber = Err.Number: errorDescription = Err.Description
    MarkAnalysisReviewsDirty
    Application.EnableEvents = previousEvents
    Err.Raise errorNumber, "CommitPendingAnalysisReviews", errorDescription
End Sub

Public Sub MarkAnalysisDetailReviewDirty()
    mAnalysisDetailReviewsDirty = True
    MarkAnalysisReviewsDirty
End Sub

Private Function AnalysisWorkspaceReviewsDifferFromSources() As Boolean
    Dim wsResult As Worksheet, wsSource As Worksheet
    Dim lastR As Long, r As Long, sourceRow As Long
    Dim sourceSheet As String, sourceKey As String
    Dim statusCol As Long, memoCol As Long, keyCol As Long
    Dim resultStatus As String, sourceStatus As String
    If Not SheetExists(SH_ANALYSIS_RESULT) Then Exit Function
    Set wsResult = GetSheet(SH_ANALYSIS_RESULT)
    lastR = LastUsedRowInSheet(wsResult)
    For r = 2 To lastR
        sourceSheet = CellText(wsResult.Cells(r, ANALYSIS_RESULT_SOURCE_SHEET_COL).Value)
        sourceRow = WorkspaceLong(wsResult.Cells(r, ANALYSIS_RESULT_SOURCE_ROW_COL).Value)
        sourceKey = CellText(wsResult.Cells(r, ANALYSIS_RESULT_SOURCE_KEY_COL).Value)
        If Not WorkspaceSourceColumns(sourceSheet, statusCol, memoCol, keyCol) Then
            AnalysisWorkspaceReviewsDifferFromSources = True
            Exit Function
        End If
        Set wsSource = GetSheet(sourceSheet)
        If sourceRow < 2 Or sourceRow > LastUsedRowInSheet(wsSource) Then
            AnalysisWorkspaceReviewsDifferFromSources = True
            Exit Function
        End If
        If StrComp(CellText(wsSource.Cells(sourceRow, keyCol).Value), _
                   sourceKey, vbBinaryCompare) <> 0 Then
            AnalysisWorkspaceReviewsDifferFromSources = True
            Exit Function
        End If
        resultStatus = WorkspaceStatusOrDefault( _
            wsResult.Cells(r, ANALYSIS_RESULT_STATUS_COL).Value)
        sourceStatus = WorkspaceStatusOrDefault(wsSource.Cells(sourceRow, statusCol).Value)
        If StrComp(resultStatus, sourceStatus, vbBinaryCompare) <> 0 Or _
           StrComp(CellText(wsResult.Cells(r, ANALYSIS_RESULT_MEMO_COL).Value), _
                   CellText(wsSource.Cells(sourceRow, memoCol).Value), _
                   vbBinaryCompare) <> 0 Then
            AnalysisWorkspaceReviewsDifferFromSources = True
            Exit Function
        End If
    Next r
End Function

Private Function AnalysisDetailReviewsDifferFromSources() As Boolean
    Dim wsDetail As Worksheet, wsSource As Worksheet
    Dim lastR As Long, r As Long, sourceRow As Long
    Dim sourceSheet As String, sourceKey As String
    Dim statusCol As Long, memoCol As Long, keyCol As Long
    Dim detailStatus As String, sourceStatus As String
    Dim detailMemo As String, sourceMemo As String
    If Not SheetExists(SH_ANALYSIS_DETAIL) Then Exit Function
    Set wsDetail = GetSheet(SH_ANALYSIS_DETAIL)
    lastR = LastUsedRowInSheet(wsDetail)
    For r = 2 To lastR
        If CellText(wsDetail.Cells(r, DETAIL_COL_KIND).Value) = "���" Then
            sourceSheet = CellText(wsDetail.Cells(r, DETAIL_COL_REFERENCE).Value)
            sourceRow = WorkspaceLong(wsDetail.Cells(r, DETAIL_COL_SOURCE_ROW).Value)
            sourceKey = CellText(wsDetail.Cells(r, DETAIL_COL_SOURCE_KEY).Value)
            If Not WorkspaceSourceColumns(sourceSheet, statusCol, memoCol, keyCol) Then
                AnalysisDetailReviewsDifferFromSources = True
                Exit Function
            End If
            Set wsSource = GetSheet(sourceSheet)
            If sourceRow < 2 Or sourceRow > LastUsedRowInSheet(wsSource) Then
                AnalysisDetailReviewsDifferFromSources = True
                Exit Function
            End If
            If StrComp(CellText(wsSource.Cells(sourceRow, keyCol).Value), _
                       sourceKey, vbBinaryCompare) <> 0 Then
                AnalysisDetailReviewsDifferFromSources = True
                Exit Function
            End If
            If r + 1 > lastR Or _
               CellText(wsDetail.Cells(r + 1, DETAIL_COL_KIND).Value) <> "��⃁��" Then
                AnalysisDetailReviewsDifferFromSources = True
                Exit Function
            End If
            detailStatus = WorkspaceStatusOrDefault(wsDetail.Cells(r, 6).Value)
            sourceStatus = WorkspaceStatusOrDefault(wsSource.Cells(sourceRow, statusCol).Value)
            detailMemo = CellText(wsDetail.Cells(r + 1, 2).Value)
            sourceMemo = CellText(wsSource.Cells(sourceRow, memoCol).Value)
            If StrComp(detailStatus, sourceStatus, vbBinaryCompare) <> 0 Or _
               StrComp(detailMemo, sourceMemo, vbBinaryCompare) <> 0 Then
                AnalysisDetailReviewsDifferFromSources = True
                Exit Function
            End If
        End If
    Next r
End Function

Private Sub RefreshAnalysisReviewDisplaysFromSources()
    RefreshAnalysisResultReviewsFromSources
    RefreshAnalysisGroupReviewsFromSources
    RefreshAnalysisDetailReviewsFromSources
End Sub

Private Sub RefreshAnalysisResultReviewsFromSources()
    Dim wsResult As Worksheet, wsSource As Worksheet
    Dim lastR As Long, r As Long, sourceRow As Long
    Dim sourceSheet As String, sourceKey As String
    Dim statusCol As Long, memoCol As Long, keyCol As Long
    If Not SheetExists(SH_ANALYSIS_RESULT) Then Exit Sub
    Set wsResult = GetSheet(SH_ANALYSIS_RESULT)
    lastR = LastUsedRowInSheet(wsResult)
    If lastR < 2 Then Exit Sub
    wsResult.Unprotect Password:=TOOL_PASSWORD
    For r = 2 To lastR
        sourceSheet = CellText(wsResult.Cells(r, ANALYSIS_RESULT_SOURCE_SHEET_COL).Value)
        sourceRow = WorkspaceLong(wsResult.Cells(r, ANALYSIS_RESULT_SOURCE_ROW_COL).Value)
        sourceKey = CellText(wsResult.Cells(r, ANALYSIS_RESULT_SOURCE_KEY_COL).Value)
        ValidateAnalysisReviewReference sourceSheet, sourceRow, sourceKey, _
                                        statusCol, memoCol, keyCol, "���͌���", r
        Set wsSource = GetSheet(sourceSheet)
        wsResult.Cells(r, ANALYSIS_RESULT_STATUS_COL).Value = _
            WorkspaceStatusOrDefault(wsSource.Cells(sourceRow, statusCol).Value)
        wsResult.Cells(r, ANALYSIS_RESULT_MEMO_COL).Value = _
            CellText(wsSource.Cells(sourceRow, memoCol).Value)
    Next r
    ProtectSingleAnalysisSheet wsResult
End Sub

Private Sub RefreshAnalysisGroupReviewsFromSources()
    Dim wsGroup As Worksheet, wsSource As Worksheet
    Dim lastR As Long, r As Long, sourceRow As Long
    Dim sourceSheet As String, sourceKey As String
    Dim statusCol As Long, memoCol As Long, keyCol As Long
    If Not SheetExists(SH_WORK_ANALYSIS_GROUP) Then Exit Sub
    Set wsGroup = GetSheet(SH_WORK_ANALYSIS_GROUP)
    lastR = LastUsedRowInSheet(wsGroup)
    If lastR < 2 Then Exit Sub
    For r = 2 To lastR
        sourceSheet = CellText(wsGroup.Cells(r, 2).Value)
        sourceRow = WorkspaceLong(wsGroup.Cells(r, 3).Value)
        sourceKey = CellText(wsGroup.Cells(r, 4).Value)
        ValidateAnalysisReviewReference sourceSheet, sourceRow, sourceKey, _
                                        statusCol, memoCol, keyCol, "W_���̓O���[�v", r
        Set wsSource = GetSheet(sourceSheet)
        wsGroup.Cells(r, 9).Value = _
            WorkspaceStatusOrDefault(wsSource.Cells(sourceRow, statusCol).Value)
        wsGroup.Cells(r, 10).Value = CellText(wsSource.Cells(sourceRow, memoCol).Value)
    Next r
    SetSheetVeryHiddenSafe wsGroup
End Sub

Private Sub RefreshAnalysisDetailReviewsFromSources()
    Dim wsDetail As Worksheet, wsSource As Worksheet
    Dim lastR As Long, r As Long, sourceRow As Long
    Dim sourceSheet As String, sourceKey As String
    Dim statusCol As Long, memoCol As Long, keyCol As Long
    If Not SheetExists(SH_ANALYSIS_DETAIL) Then Exit Sub
    Set wsDetail = GetSheet(SH_ANALYSIS_DETAIL)
    lastR = LastUsedRowInSheet(wsDetail)
    If lastR < 2 Then Exit Sub
    wsDetail.Unprotect Password:=TOOL_PASSWORD
    For r = 2 To lastR
        If CellText(wsDetail.Cells(r, DETAIL_COL_KIND).Value) = "���" Then
            sourceSheet = CellText(wsDetail.Cells(r, DETAIL_COL_REFERENCE).Value)
            sourceRow = WorkspaceLong(wsDetail.Cells(r, DETAIL_COL_SOURCE_ROW).Value)
            sourceKey = CellText(wsDetail.Cells(r, DETAIL_COL_SOURCE_KEY).Value)
            ValidateAnalysisReviewReference sourceSheet, sourceRow, sourceKey, _
                                            statusCol, memoCol, keyCol, "���ڍ�", r
            Set wsSource = GetSheet(sourceSheet)
            wsDetail.Cells(r, 6).Value = _
                WorkspaceStatusOrDefault(wsSource.Cells(sourceRow, statusCol).Value)
            If r + 1 <= lastR And _
               CellText(wsDetail.Cells(r + 1, DETAIL_COL_KIND).Value) = "��⃁��" Then _
                wsDetail.Cells(r + 1, 2).Value = CellText(wsSource.Cells(sourceRow, memoCol).Value)
        End If
    Next r
    ProtectSingleAnalysisSheet wsDetail
End Sub

Private Sub ValidateAnalysisReviewReference( _
        ByVal sourceSheet As String, ByVal sourceRow As Long, ByVal sourceKey As String, _
        ByRef statusCol As Long, ByRef memoCol As Long, ByRef keyCol As Long, _
        ByVal labelText As String, ByVal displayRow As Long)
    Dim wsSource As Worksheet
    If Not WorkspaceSourceColumns(sourceSheet, statusCol, memoCol, keyCol) Then _
        Err.Raise vbObjectError + 4821, "ValidateAnalysisReviewReference", _
                  labelText & " " & CStr(displayRow) & "�s�ڂ̓������\���s���ł��B"
    Set wsSource = GetSheet(sourceSheet)
    If sourceRow < 2 Or sourceRow > LastUsedRowInSheet(wsSource) Then _
        Err.Raise vbObjectError + 4822, "ValidateAnalysisReviewReference", _
                  labelText & " " & CStr(displayRow) & "�s�ڂ̓������s��������܂���B"
    If Len(sourceKey) = 0 Or _
       StrComp(CellText(wsSource.Cells(sourceRow, keyCol).Value), _
               sourceKey, vbBinaryCompare) <> 0 Then _
        Err.Raise vbObjectError + 4823, "ValidateAnalysisReviewReference", _
                  labelText & " " & CStr(displayRow) & "�s�ڂ̊m�F�L�[����v���܂���B"
End Sub

Public Sub ToggleAnalysisDetailTransactionSelection(ByVal targetRow As Long)
    Dim ws As Worksheet, isSelected As Boolean, workbookWasSaved As Boolean
    If Not SheetExists(SH_ANALYSIS_DETAIL) Then Exit Sub
    Set ws = GetSheet(SH_ANALYSIS_DETAIL)
    If targetRow < 1 Or targetRow > LastUsedRowInSheet(ws) Then Exit Sub
    If CellText(ws.Cells(targetRow, DETAIL_COL_KIND).Value) <> "���" Then Exit Sub
    workbookWasSaved = ThisWorkbook.Saved
    ws.Unprotect Password:=TOOL_PASSWORD
    isSelected = (CellText(ws.Cells(targetRow, DETAIL_COL_SELECTED).Value) = "1")
    If isSelected Then
        ws.Cells(targetRow, DETAIL_COL_SELECTED).Value = "0"
        ws.Range(ws.Cells(targetRow, 1), ws.Cells(targetRow, 7)).Interior.Color = vbWhite
        ws.Range(ws.Cells(targetRow, 1), ws.Cells(targetRow, 7)).Font.Bold = False
        If CellText(ws.Cells(targetRow, DETAIL_COL_SOURCE_KEY).Value) = "GLOBAL" Then _
            ws.Cells(targetRow, 1).Value = "���I��"
    Else
        ws.Cells(targetRow, DETAIL_COL_SELECTED).Value = "1"
        ws.Range(ws.Cells(targetRow, 1), ws.Cells(targetRow, 7)).Interior.Color = RGB(219, 234, 254)
        ws.Range(ws.Cells(targetRow, 1), ws.Cells(targetRow, 7)).Font.Bold = True
        If CellText(ws.Cells(targetRow, DETAIL_COL_SOURCE_KEY).Value) = "GLOBAL" Then _
            ws.Cells(targetRow, 1).Value = "�I��"
    End If
    RefreshManualSelectionSummary ws
    ProtectSingleAnalysisSheet ws
    '�I��F�E�����t���O�͈ꎞ�I�ȉ�ʏ�ԂȂ̂ŁA���ꂾ���ŕۑ��m�F�𔭐������Ȃ��B
    If workbookWasSaved Then ThisWorkbook.Saved = True
End Sub

Public Function HasSelectedAnalysisDetailTransactions() As Boolean
    Dim ws As Worksheet, lastR As Long, r As Long
    Dim selectionData As Variant
    If Not SheetExists(SH_ANALYSIS_DETAIL) Then Exit Function
    Set ws = GetSheet(SH_ANALYSIS_DETAIL)
    If ws.Visible <> xlSheetVisible Then Exit Function
    lastR = LastUsedRowInSheet(ws)
    If lastR < 1 Then Exit Function
    selectionData = ws.Range(ws.Cells(1, DETAIL_COL_KIND), _
                             ws.Cells(lastR, DETAIL_COL_SELECTED)).Value2
    For r = 1 To UBound(selectionData, 1)
        If CellText(selectionData(r, 1)) = "���" And _
           CellText(selectionData(r, DETAIL_COL_SELECTED - DETAIL_COL_KIND + 1)) = "1" Then
            HasSelectedAnalysisDetailTransactions = True
            Exit Function
        End If
    Next r
End Function

Public Sub ClearAnalysisDetailTransactionSelections()
    Dim ws As Worksheet, lastR As Long, r As Long, workbookWasSaved As Boolean
    Dim selectionData As Variant
    If Not SheetExists(SH_ANALYSIS_DETAIL) Then Exit Sub
    Set ws = GetSheet(SH_ANALYSIS_DETAIL)
    workbookWasSaved = ThisWorkbook.Saved
    lastR = LastUsedRowInSheet(ws)
    ws.Unprotect Password:=TOOL_PASSWORD
    If lastR >= 1 Then
        selectionData = ws.Range(ws.Cells(1, DETAIL_COL_KIND), _
                                 ws.Cells(lastR, DETAIL_COL_SELECTED)).Value2
        For r = 1 To UBound(selectionData, 1)
            If CellText(selectionData(r, 1)) = "���" And _
               CellText(selectionData(r, DETAIL_COL_SELECTED - DETAIL_COL_KIND + 1)) = "1" Then
                selectionData(r, DETAIL_COL_SELECTED - DETAIL_COL_KIND + 1) = "0"
                If CellText(selectionData(r, DETAIL_COL_SOURCE_KEY - DETAIL_COL_KIND + 1)) = "GLOBAL" Then _
                    ws.Cells(r, 1).Value = "���I��"
                '�����X�V�͑I������Ă��������s�����Ɍ��肷��B
                ws.Range(ws.Cells(r, 1), ws.Cells(r, 7)).Interior.Color = vbWhite
                ws.Range(ws.Cells(r, 1), ws.Cells(r, 7)).Font.Bold = False
            End If
        Next r
        ws.Range(ws.Cells(1, DETAIL_COL_KIND), _
                 ws.Cells(lastR, DETAIL_COL_SELECTED)).Value2 = selectionData
    End If
    RefreshManualSelectionSummary ws
    ProtectSingleAnalysisSheet ws
    If workbookWasSaved Then ThisWorkbook.Saved = True
End Sub

Private Sub RefreshManualSelectionSummary(ByVal ws As Worksheet)
    Dim lastR As Long, r As Long
    Dim withdrawalIndex As Long, depositIndex As Long
    Dim withdrawalValue As Double, depositValue As Double
    Dim withdrawCount As Long, depositCount As Long
    Dim withdrawTotal As Double, depositTotal As Double
    Dim summaryData As Variant
    If ws Is Nothing Then Exit Sub
    If CellText(ws.Cells(2, DETAIL_COL_KIND).Value) <> "�蓮�o�^" Then Exit Sub
    lastR = LastUsedRowInSheet(ws)
    If lastR >= MANUAL_BUILDER_HEADER_ROW + 1 Then
        '�_�u���N���b�N�̂��тɍő�5���s���Z���P�ʂœǂނƑ��삪�~�܂邽�߁A
        '�\����D�`G�Ɠ�����H�`L����x�����z��֓ǂݍ���ŏW�v����B
        summaryData = ws.Range( _
            ws.Cells(MANUAL_BUILDER_HEADER_ROW + 1, 4), _
            ws.Cells(lastR, DETAIL_COL_SELECTED)).Value2
        For r = 1 To UBound(summaryData, 1)
            If CellText(summaryData(r, DETAIL_COL_KIND - 4 + 1)) = "���" And _
               CellText(summaryData(r, DETAIL_COL_SELECTED - 4 + 1)) = "1" Then
                If CellText(summaryData(r, DETAIL_COL_SOURCE_KEY - 4 + 1)) = "GLOBAL" Then
                    withdrawalIndex = 1
                    depositIndex = 2
                Else
                    withdrawalIndex = 2
                    depositIndex = 3
                End If
                withdrawalValue = WorkspaceDouble(summaryData(r, withdrawalIndex))
                depositValue = WorkspaceDouble(summaryData(r, depositIndex))
                If withdrawalValue > 0 Then
                    withdrawCount = withdrawCount + 1
                    withdrawTotal = withdrawTotal + withdrawalValue
                End If
                If depositValue > 0 Then
                    depositCount = depositCount + 1
                    depositTotal = depositTotal + depositValue
                End If
            End If
        Next r
    End If
    If withdrawCount + depositCount = 0 Then
        ws.Range("A2").Value = _
            "������_�u���N���b�N���đI�� �� ���̈ē��s���_�u���N���b�N���ēo�^"
    Else
        ws.Range("A2").Value = "�I�𒆁F�o�� " & CStr(withdrawCount) & "�� " & _
            Format$(withdrawTotal, "#,##0.########") & "�~�@�^�@���� " & _
            CStr(depositCount) & "�� " & Format$(depositTotal, "#,##0.########") & _
            "�~�@�^�@���z " & Format$(depositTotal - withdrawTotal, "+#,##0.########;-#,##0.########;0") & _
            "�~�@�b�@���̍s���_�u���N���b�N���ēo�^"
    End If
End Sub

Public Function IsManualAnalysisDetailAlternative(ByVal targetRow As Long) As Boolean
    Dim wsDetail As Worksheet, wsFlow As Worksheet, sourceRow As Long
    If Not SheetExists(SH_ANALYSIS_DETAIL) Or Not SheetExists(SH_ANALYSIS_FLOW) Then Exit Function
    Set wsDetail = GetSheet(SH_ANALYSIS_DETAIL)
    If targetRow < 1 Or targetRow > LastUsedRowInSheet(wsDetail) Then Exit Function
    If CellText(wsDetail.Cells(targetRow, DETAIL_COL_KIND).Value) <> "���" Or _
       CellText(wsDetail.Cells(targetRow, DETAIL_COL_REFERENCE).Value) <> SH_ANALYSIS_FLOW Then Exit Function
    sourceRow = WorkspaceLong(wsDetail.Cells(targetRow, DETAIL_COL_SOURCE_ROW).Value)
    Set wsFlow = GetSheet(SH_ANALYSIS_FLOW)
    If sourceRow >= 2 And sourceRow <= LastUsedRowInSheet(wsFlow) Then _
        IsManualAnalysisDetailAlternative = _
            (CellText(wsFlow.Cells(sourceRow, 3).Value) = "�蓮�w��")
End Function

Public Function AnalysisDetailStoredKey(ByVal targetRow As Long) As String
    If SheetExists(SH_ANALYSIS_DETAIL) Then _
        AnalysisDetailStoredKey = CellText(GetSheet(SH_ANALYSIS_DETAIL).Cells( _
                                                   targetRow, DETAIL_COL_SOURCE_KEY).Value)
End Function

Private Sub SyncWorkspaceSourceReviews(ByRef resultData As Variant, ByVal resultCount As Long, _
                                       ByVal targetSheetName As String)
    Dim wsSource As Worksheet, lastR As Long, sourceDataRows As Long
    Dim statusCol As Long, memoCol As Long, keyCol As Long
    Dim reviewValues As Variant, keyValues As Variant
    Dim r As Long, sourceRow As Long, sourceIndex As Long
    Dim sourceKey As String, statusText As String, memoText As String, categoryText As String
    If Not WorkspaceSourceColumns(targetSheetName, statusCol, memoCol, keyCol) Then Exit Sub
    Set wsSource = GetSheet(targetSheetName)
    lastR = LastUsedRowInSheet(wsSource)
    If lastR < 2 Then
        For r = 1 To resultCount
            If StrComp(CellText(resultData(r, ANALYSIS_RESULT_SOURCE_SHEET_COL)), _
                       targetSheetName, vbTextCompare) = 0 Then _
                Err.Raise vbObjectError + 4806, "SyncWorkspaceSourceReviews", _
                          "���͌��� " & CStr(r + 1) & "�s�ڂ̓������\�Ɍ�₪����܂���B"
        Next r
        Exit Sub
    End If
    sourceDataRows = lastR - 1
    reviewValues = wsSource.Range(wsSource.Cells(2, statusCol), _
                                  wsSource.Cells(lastR, memoCol)).Value2
    keyValues = wsSource.Range(wsSource.Cells(2, keyCol), wsSource.Cells(lastR, keyCol)).Value2
    For r = 1 To resultCount
        If StrComp(CellText(resultData(r, ANALYSIS_RESULT_SOURCE_SHEET_COL)), _
                   targetSheetName, vbTextCompare) = 0 Then
            sourceRow = WorkspaceLong(resultData(r, ANALYSIS_RESULT_SOURCE_ROW_COL))
            sourceIndex = sourceRow - 1
            If sourceIndex < 1 Or sourceIndex > sourceDataRows Then _
                Err.Raise vbObjectError + 4806, "SyncWorkspaceSourceReviews", _
                          "���͌��� " & CStr(r + 1) & "�s�ڂ̓������s��������܂���B"
            sourceKey = CellText(resultData(r, ANALYSIS_RESULT_SOURCE_KEY_COL))
            If StrComp(CellText(WorkspaceColumnArrayValue(keyValues, sourceIndex, sourceDataRows)), _
                       sourceKey, vbBinaryCompare) <> 0 Then _
                Err.Raise vbObjectError + 4807, "SyncWorkspaceSourceReviews", _
                          "���͌��� " & CStr(r + 1) & "�s�ڂƓ��������\�̊m�F�L�[����v���܂���B"
            statusText = WorkspaceStatusOrDefault(resultData(r, ANALYSIS_RESULT_STATUS_COL))
            memoText = CellText(resultData(r, ANALYSIS_RESULT_MEMO_COL))
            categoryText = CellText(resultData(r, 2))
            If Len(memoText) > WORKSPACE_MEMO_MAX Then _
                Err.Raise vbObjectError + 4808, "SyncWorkspaceSourceReviews", _
                          "���͌��� " & CStr(r + 1) & "�s�ڂ̊m�F�������������܂��B"
            If Not WorkspaceStatusFitsSource(targetSheetName, categoryText, statusText) Then _
                Err.Raise vbObjectError + 4809, "SyncWorkspaceSourceReviews", _
                          "���͌��� " & CStr(r + 1) & "�s�ڂ̊m�F�󋵂��敪�ɓK�����܂���B"
            reviewValues(sourceIndex, 1) = statusText
            reviewValues(sourceIndex, 2) = memoText
        End If
    Next r
    wsSource.Range(wsSource.Cells(2, statusCol), wsSource.Cells(lastR, memoCol)).Value = reviewValues
End Sub

Private Function WorkspaceColumnArrayValue(ByRef values As Variant, ByVal itemIndex As Long, _
                                           ByVal itemCount As Long) As Variant
    If itemCount = 1 Then
        WorkspaceColumnArrayValue = values
    Else
        WorkspaceColumnArrayValue = values(itemIndex, 1)
    End If
End Function

Private Function WorkspaceSourceColumns(ByVal sheetName As String, ByRef statusCol As Long, _
                                        ByRef memoCol As Long, ByRef keyCol As Long) As Boolean
    Select Case sheetName
        Case SH_ANALYSIS_SHIFT
            statusCol = SHIFT_ANALYSIS_STATUS_COL: memoCol = SHIFT_ANALYSIS_MEMO_COL
            keyCol = SHIFT_ANALYSIS_KEY_COL
        Case SH_ANALYSIS_FLOW
            statusCol = FLOW_ANALYSIS_STATUS_COL: memoCol = FLOW_ANALYSIS_MEMO_COL
            keyCol = FLOW_ANALYSIS_KEY_COL
        Case SH_ANALYSIS_UNKNOWN
            statusCol = UNKNOWN_ANALYSIS_STATUS_COL: memoCol = UNKNOWN_ANALYSIS_MEMO_COL
            keyCol = UNKNOWN_ANALYSIS_KEY_COL
        Case Else
            Exit Function
    End Select
    WorkspaceSourceColumns = True
End Function

Private Function WorkspaceStatusFitsSource(ByVal sourceSheet As String, ByVal categoryText As String, _
                                           ByVal statusText As String) As Boolean
    Select Case sourceSheet
        Case SH_ANALYSIS_SHIFT, SH_ANALYSIS_FLOW
            Select Case statusText
                Case ANALYSIS_STATUS_UNREVIEWED, ANALYSIS_STATUS_SHIFT_CONFIRMED, _
                     ANALYSIS_STATUS_EXCLUDED, ANALYSIS_STATUS_FOLLOWUP
                    WorkspaceStatusFitsSource = True
            End Select
        Case SH_ANALYSIS_UNKNOWN
            If StrComp(categoryText, "�����s��", vbTextCompare) = 0 Then
                Select Case statusText
                    Case ANALYSIS_STATUS_UNREVIEWED, ANALYSIS_STATUS_SOURCE_CONFIRMED, _
                         ANALYSIS_STATUS_EXCLUDED, ANALYSIS_STATUS_FOLLOWUP
                        WorkspaceStatusFitsSource = True
                End Select
            ElseIf StrComp(categoryText, "�g�r�s��", vbTextCompare) = 0 Then
                Select Case statusText
                    Case ANALYSIS_STATUS_UNREVIEWED, ANALYSIS_STATUS_USE_CONFIRMED, _
                         ANALYSIS_STATUS_EXCLUDED, ANALYSIS_STATUS_FOLLOWUP
                        WorkspaceStatusFitsSource = True
                End Select
            End If
    End Select
End Function

Public Sub FormatAnalysisWorkspaceSheets()
    Dim ws As Worksheet, dataCount As Long, lastDetailRow As Long
    If SheetExists(SH_ANALYSIS_RESULT) Then
        Set ws = GetSheet(SH_ANALYSIS_RESULT)
        dataCount = Application.Max(0, LastUsedRowInSheet(ws) - 1)
        FinalizeAnalysisResultSheet ws, dataCount
    End If
    If SheetExists(SH_ANALYSIS_DETAIL) Then
        Set ws = GetSheet(SH_ANALYSIS_DETAIL)
        ws.Unprotect Password:=TOOL_PASSWORD
        lastDetailRow = Application.Max(1, LastUsedRowInSheet(ws))
        With ws.Range("A1:L" & CStr(lastDetailRow))
            .Font.Name = "Yu Gothic UI"
            .Font.Size = 10
        End With
        ProtectSingleAnalysisSheet ws
    End If
End Sub

Public Sub CheckAnalysisWorkspace(ByRef problems As String)
    Dim ws As Worksheet, wsGroup As Worksheet
    Dim lastR As Long, groupLastR As Long, r As Long
    Dim sourceStatusCol As Long, sourceMemoCol As Long, sourceKeyCol As Long
    Dim sourceSheet As String, sourceKey As String, categoryText As String, statusText As String
    Dim groupID As String, referenceKey As String, representativeText As String
    Dim resultData As Variant, groupData As Variant
    Dim groupCounts As Object, representativeRefs As Object, resultGroups As Object
    Dim validSourceRefs As Object
    Dim item As Variant, expectedCount As Long
    If Not SheetExists(SH_ANALYSIS_RESULT) Or Not SheetExists(SH_WORK_ANALYSIS_GROUP) Then Exit Sub
    Set ws = GetSheet(SH_ANALYSIS_RESULT)
    Set wsGroup = GetSheet(SH_WORK_ANALYSIS_GROUP)
    If ws.Protection.AllowSorting Then _
        problems = problems & "�E���͌��ʂŕی쉺�̕��בւ����L���ł��B���ƍ����̑Ή�����邽�ߖ����ɂ��Ă�������" & vbCrLf
    Set groupCounts = CreateObject("Scripting.Dictionary")
    Set representativeRefs = CreateObject("Scripting.Dictionary")
    Set resultGroups = CreateObject("Scripting.Dictionary")
    Set validSourceRefs = CreateObject("Scripting.Dictionary")
    groupCounts.CompareMode = vbBinaryCompare
    representativeRefs.CompareMode = vbBinaryCompare
    resultGroups.CompareMode = vbBinaryCompare
    validSourceRefs.CompareMode = vbBinaryCompare
    AddWorkspaceSourceReferences SH_ANALYSIS_SHIFT, SHIFT_ANALYSIS_KEY_COL, validSourceRefs
    AddWorkspaceSourceReferences SH_ANALYSIS_FLOW, FLOW_ANALYSIS_KEY_COL, validSourceRefs
    AddWorkspaceSourceReferences SH_ANALYSIS_UNKNOWN, UNKNOWN_ANALYSIS_KEY_COL, validSourceRefs
    groupLastR = LastUsedRowInSheet(wsGroup)
    If groupLastR >= 2 Then
        groupData = wsGroup.Range(wsGroup.Cells(2, 1), _
                                  wsGroup.Cells(groupLastR, ANALYSIS_GROUP_LAST_COL)).Value2
        For r = 1 To UBound(groupData, 1)
            groupID = CellText(groupData(r, 1))
            sourceSheet = CellText(groupData(r, 2))
            sourceKey = CellText(groupData(r, 4))
            representativeText = CellText(groupData(r, 7))
            If Len(groupID) = 0 Then
                problems = problems & "�EW_���̓O���[�v " & CStr(r + 1) & "�s: �O���[�vID������܂���" & vbCrLf
            Else
                If groupCounts.Exists(groupID) Then
                    groupCounts(groupID) = CLng(groupCounts(groupID)) + 1
                Else
                    groupCounts.Add groupID, 1
                End If
            End If
            If Not WorkspaceSourceColumns(sourceSheet, sourceStatusCol, sourceMemoCol, sourceKeyCol) Then
                problems = problems & "�EW_���̓O���[�v " & CStr(r + 1) & "�s: ���\���s���ł�" & vbCrLf
            ElseIf WorkspaceLong(groupData(r, 3)) < 2 Then
                problems = problems & "�EW_���̓O���[�v " & CStr(r + 1) & "�s: ���s���s���ł�" & vbCrLf
            Else
                referenceKey = WorkspaceReferenceKey(sourceSheet, WorkspaceLong(groupData(r, 3)), sourceKey)
                If Not validSourceRefs.Exists(referenceKey) Then _
                    problems = problems & "�EW_���̓O���[�v " & CStr(r + 1) & "�s: ���\�̊m�F�L�[�ƈ�v���܂���" & vbCrLf
            End If
            If Len(sourceKey) = 0 Or Len(CellText(groupData(r, 5))) = 0 Then _
                problems = problems & "�EW_���̓O���[�v " & CStr(r + 1) & "�s: �m�F�L�[�܂��͎��ID������܂���" & vbCrLf
            If StrComp(representativeText, "��\", vbTextCompare) = 0 Then
                referenceKey = WorkspaceReferenceKey(sourceSheet, WorkspaceLong(groupData(r, 3)), sourceKey)
                If representativeRefs.Exists(groupID) Then
                    problems = problems & "�EW_���̓O���[�v " & CStr(r + 1) & "�s: ��\��₪�d�����Ă��܂�" & vbCrLf
                Else
                    representativeRefs.Add groupID, referenceKey
                End If
            ElseIf StrComp(representativeText, "���", vbTextCompare) <> 0 Then
                problems = problems & "�EW_���̓O���[�v " & CStr(r + 1) & "�s: �ʒu�t�����s���ł�" & vbCrLf
            End If
            If Len(problems) > 700000 Then Exit Sub
        Next r
    End If
    lastR = LastUsedRowInSheet(ws)
    If lastR >= 2 Then
        resultData = ws.Range(ws.Cells(2, 1), ws.Cells(lastR, ANALYSIS_RESULT_LAST_COL)).Value2
        For r = 1 To UBound(resultData, 1)
            sourceSheet = CellText(resultData(r, ANALYSIS_RESULT_SOURCE_SHEET_COL))
            sourceKey = CellText(resultData(r, ANALYSIS_RESULT_SOURCE_KEY_COL))
            categoryText = CellText(resultData(r, 2))
            statusText = WorkspaceStatusOrDefault(resultData(r, ANALYSIS_RESULT_STATUS_COL))
            groupID = CellText(resultData(r, ANALYSIS_RESULT_GROUP_ID_COL))
            If Len(sourceSheet) = 0 Or Len(sourceKey) = 0 Then
                problems = problems & "�E���͌��� " & CStr(r + 1) & "�s: �����Q�Ƃ�����܂���" & vbCrLf
            ElseIf Not WorkspaceSourceColumns(sourceSheet, sourceStatusCol, sourceMemoCol, sourceKeyCol) Then
                problems = problems & "�E���͌��� " & CStr(r + 1) & "�s: �������\���s���ł�" & vbCrLf
            ElseIf Not WorkspaceStatusFitsSource(sourceSheet, categoryText, statusText) Then
                problems = problems & "�E���͌��� " & CStr(r + 1) & "�s: �m�F�󋵂��敪�ɓK�����܂���" & vbCrLf
            End If
            If Len(CellText(resultData(r, ANALYSIS_RESULT_MEMO_COL))) > WORKSPACE_MEMO_MAX Then _
                problems = problems & "�E���͌��� " & CStr(r + 1) & "�s: �m�F�������������܂�" & vbCrLf
            If Len(groupID) = 0 Or Not groupCounts.Exists(groupID) Then
                problems = problems & "�E���͌��� " & CStr(r + 1) & "�s: �����O���[�v��������܂���" & vbCrLf
            Else
                expectedCount = WorkspaceLong(resultData(r, ANALYSIS_RESULT_ALTERNATIVE_COUNT_COL))
                If expectedCount <> CLng(groupCounts(groupID)) Then _
                    problems = problems & "�E���͌��� " & CStr(r + 1) & "�s: ��֌�␔�������\�ƈ�v���܂���" & vbCrLf
                If resultGroups.Exists(groupID) Then
                    problems = problems & "�E���͌��� " & CStr(r + 1) & "�s: �O���[�vID���d�����Ă��܂�" & vbCrLf
                Else
                    resultGroups.Add groupID, True
                End If
                referenceKey = WorkspaceReferenceKey(sourceSheet, _
                               WorkspaceLong(resultData(r, ANALYSIS_RESULT_SOURCE_ROW_COL)), sourceKey)
                If Not representativeRefs.Exists(groupID) Then
                    problems = problems & "�E���͌��� " & CStr(r + 1) & "�s: ��\��₪����܂���" & vbCrLf
                ElseIf StrComp(CStr(representativeRefs(groupID)), referenceKey, vbBinaryCompare) <> 0 Then
                    problems = problems & "�E���͌��� " & CStr(r + 1) & "�s: ��\���Q�Ƃ���v���܂���" & vbCrLf
                End If
            End If
            If Len(problems) > 700000 Then Exit Sub
        Next r
    End If
    If resultGroups.Count <> groupCounts.Count Then _
        problems = problems & "�E���͌��ʂ�W_���̓O���[�v�̃O���[�v��������v���܂���" & vbCrLf
    For Each item In groupCounts.Keys
        If Not representativeRefs.Exists(CStr(item)) Then _
            problems = problems & "�EW_���̓O���[�v: ��\��₪�Ȃ��O���[�v������܂�: " & CStr(item) & vbCrLf
        If Not resultGroups.Exists(CStr(item)) Then _
            problems = problems & "�EW_���̓O���[�v: ���͌��ʂɂȂ��O���[�v������܂�: " & CStr(item) & vbCrLf
        If Len(problems) > 700000 Then Exit For
    Next item
    If Not ws.ProtectContents Then problems = problems & "�E���͌��ʂ��ی삳��Ă��܂���" & vbCrLf
    If ws.Columns("J:O").Hidden = False Then _
        problems = problems & "�E���͌��ʂ̓����񂪕\������Ă��܂�" & vbCrLf
    If Not GetSheet(SH_ANALYSIS_DETAIL).ProtectContents Then _
        problems = problems & "�E���ڍׂ��ی삳��Ă��܂���" & vbCrLf
    If GetSheet(SH_ANALYSIS_DETAIL).Columns("H:L").Hidden = False Then _
        problems = problems & "�E���ڍׂ̓����񂪕\������Ă��܂�" & vbCrLf
    If wsGroup.Visible <> xlSheetVeryHidden Then _
        problems = problems & "�EW_���̓O���[�v��VeryHidden�ł͂���܂���" & vbCrLf
End Sub

Private Function WorkspaceReferenceKey(ByVal sourceSheet As String, ByVal sourceRow As Long, _
                                       ByVal sourceKey As String) As String
    WorkspaceReferenceKey = TransferLikeLengthPart(sourceSheet) & CStr(sourceRow) & "|" & _
                            TransferLikeLengthPart(sourceKey)
End Function

Private Sub AddWorkspaceSourceReferences(ByVal sourceSheet As String, ByVal keyColumn As Long, _
                                         ByVal target As Object)
    Dim ws As Worksheet, lastR As Long, dataCount As Long, r As Long
    Dim keyValues As Variant, sourceKey As String
    Set ws = GetSheet(sourceSheet)
    lastR = LastUsedRowInSheet(ws)
    If lastR < 2 Then Exit Sub
    dataCount = lastR - 1
    keyValues = ws.Range(ws.Cells(2, keyColumn), ws.Cells(lastR, keyColumn)).Value2
    For r = 1 To dataCount
        sourceKey = CellText(WorkspaceColumnArrayValue(keyValues, r, dataCount))
        If Len(sourceKey) > 0 Then _
            target(WorkspaceReferenceKey(sourceSheet, r + 1, sourceKey)) = True
    Next r
End Sub

Private Function TransferLikeLengthPart(ByVal valueText As String) As String
    TransferLikeLengthPart = CStr(Len(valueText)) & ":" & valueText & "|"
End Function

Public Sub OpenManualAnalysisCandidateBuilder()
    Dim wsTx As Worksheet, wsDetail As Worksheet
    Dim lastR As Long, r As Long, transactionCount As Long, matchCount As Long
    Dim data As Variant, outputData() As Variant, outputRow As Long
    Dim queryInput As Variant, queryText As String
    Dim directionText As String, amountValue As Double
    Dim errorNumber As Long, errorDescription As String
    Dim workbookWasSaved As Boolean, reviewsWerePending As Boolean
    If Not RequireToolReady() Then Exit Sub
    If Not RequireInternalStoresSafeForWrite() Then Exit Sub
    On Error GoTo EH
    workbookWasSaved = ThisWorkbook.Saved
    reviewsWerePending = HasPendingAnalysisReviewChanges()
    CommitPendingAnalysisReviews False, "�蓮���쐬�O�̕��͔��f��ۑ�"
    Set wsTx = GetSheet(SH_WORK_TX)
    lastR = LastUsedRowInSheet(wsTx)
    If lastR < 2 Then
        MsgBox "�蓮���Ɏg�p�ł�����������܂���B", vbInformation
        Exit Sub
    End If
    data = wsTx.Range(wsTx.Cells(2, 1), _
                      wsTx.Cells(lastR, WORK_TX_COL_PERSON_ID)).Value2
    For r = 1 To UBound(data, 1)
        If CellText(data(r, WORK_TX_COL_RECORD_TYPE)) = RECORD_TRANSACTION Then _
            transactionCount = transactionCount + 1
    Next r
    If transactionCount = 0 Then
        MsgBox "�蓮���Ɏg�p�ł�����������܂���B", vbInformation
        Exit Sub
    End If
    If transactionCount > MANUAL_BUILDER_MAX_ROWS Then
        queryInput = Application.InputBox( _
            Prompt:="����� " & Format$(transactionCount, "#,##0") & _
                    "�����邽�߁A�\���Ώۂ�������ōi���Ă��������B" & vbCrLf & _
                    "��s�E�x�X�E�����E�����ԍ��E���t�E���z�E�E�v�����������܂��B" & vbCrLf & _
                    "�󔒋�؂��AND�A|�i�c���j��؂��OR�ł��B", _
            Title:="�蓮���Ɏg��������i�荞��", Type:=2)
        If VarType(queryInput) = vbBoolean Then
            If CBool(queryInput) = False Then Exit Sub
        End If
        queryText = Trim$(CStr(queryInput))
        If Len(queryText) = 0 Then
            MsgBox "��ʎ������x�ɕ\�����Ȃ����߁A���������͂��Ă��������B", vbInformation
            Exit Sub
        End If
    End If
    For r = 1 To UBound(data, 1)
        If CellText(data(r, WORK_TX_COL_RECORD_TYPE)) = RECORD_TRANSACTION Then
            If ManualBuilderRowMatches(data, r, queryText) Then matchCount = matchCount + 1
        End If
    Next r
    If matchCount = 0 Then
        MsgBox "���������Ɉ�v������������܂���B", vbInformation
        Exit Sub
    End If
    If matchCount > MANUAL_BUILDER_MAX_ROWS Then
        MsgBox "�������ʂ� " & Format$(matchCount, "#,##0") & _
               "������܂��B�������ǉ����� " & _
               Format$(MANUAL_BUILDER_MAX_ROWS, "#,##0") & _
               "���ȉ��֍i���Ă��������B", vbExclamation
        Exit Sub
    End If

    AppBegin "�蓮���p�̎���ꗗ���쐬���Ă��܂�..."
    ReDim outputData(1 To matchCount, 1 To DETAIL_COL_SELECTED)
    For r = 1 To UBound(data, 1)
        If CellText(data(r, WORK_TX_COL_RECORD_TYPE)) = RECORD_TRANSACTION And _
           ManualBuilderRowMatches(data, r, queryText) Then
            outputRow = outputRow + 1
            ManualBuilderDirectionAmount data, r, directionText, amountValue
            outputData(outputRow, 1) = "���I��"
            outputData(outputRow, 2) = Format$(CDate(data(r, OUT_COL_DATE)), "yyyy/m/d")
            If HasText(data(r, OUT_COL_TIME)) Then
                outputData(outputRow, 3) = Format$(CDate(data(r, OUT_COL_TIME)), "hh:mm")
            Else
                outputData(outputRow, 3) = "--:--"
            End If
            If directionText = "�o��" Then
                outputData(outputRow, 4) = amountValue
            Else
                outputData(outputRow, 5) = amountValue
            End If
            outputData(outputRow, 6) = ManualBuilderAccountText(data, r)
            outputData(outputRow, 7) = ManualBuilderSummaryText(data, r)
            outputData(outputRow, DETAIL_COL_KIND) = "���"
            outputData(outputRow, DETAIL_COL_REFERENCE) = _
                CellText(data(r, WORK_TX_COL_TRANSACTION_ID))
            outputData(outputRow, DETAIL_COL_SOURCE_ROW) = r + 1
            outputData(outputRow, DETAIL_COL_SOURCE_KEY) = "GLOBAL"
            outputData(outputRow, DETAIL_COL_SELECTED) = "0"
        End If
    Next r

    Set wsDetail = GetSheet(SH_ANALYSIS_DETAIL)
    PrepareAnalysisDetailSheet wsDetail
    wsDetail.Visible = xlSheetVisible
    wsDetail.Unprotect Password:=TOOL_PASSWORD
    MergeAndFormat wsDetail.Range("A1:G1"), "�蓮�̎����ړ������쐬"
    With wsDetail.Range("A1:G1")
        .Interior.Color = RGB(239, 246, 255)
        .Font.Color = RGB(30, 64, 175)
        .Font.Bold = True
        .Font.Size = 15
        .HorizontalAlignment = xlCenter
    End With
    MergeAndFormat wsDetail.Range("A2:G2"), _
        "������_�u���N���b�N���đI�� �� ���̈ē��s���_�u���N���b�N���ēo�^"
    With wsDetail.Range("A2:G2")
        .Interior.Color = RGB(254, 249, 195)
        .Font.Color = RGB(133, 77, 14)
        .Font.Bold = True
        .HorizontalAlignment = xlCenter
    End With
    wsDetail.Cells(2, DETAIL_COL_KIND).Value = "�蓮�o�^"
    MergeAndFormat wsDetail.Range("A3:G3"), _
        "�o���Ɠ������e1���ȏ�I�����Ă��������B�����s���̎���� --:-- �̂܂܁A���͏��Ő��肵�܂��B"
    SetRowValues wsDetail.Cells(MANUAL_BUILDER_HEADER_ROW, 1), _
        Array("�I��", "���t", "����", "�o��", "����", "�����E���`", "�E�v�E�戵�X")
    FormatOutputHeader wsDetail.Range(wsDetail.Cells(MANUAL_BUILDER_HEADER_ROW, 1), _
                                      wsDetail.Cells(MANUAL_BUILDER_HEADER_ROW, 7))
    wsDetail.Range(wsDetail.Cells(MANUAL_BUILDER_HEADER_ROW + 1, 1), _
                   wsDetail.Cells(MANUAL_BUILDER_HEADER_ROW + matchCount, _
                                  DETAIL_COL_SELECTED)).Value = outputData
    wsDetail.Columns("A:A").ColumnWidth = 10
    wsDetail.Columns("B:B").ColumnWidth = 13
    wsDetail.Columns("C:C").ColumnWidth = 9
    wsDetail.Columns("D:E").ColumnWidth = 15.5
    wsDetail.Columns("F:F").ColumnWidth = 38
    wsDetail.Columns("G:G").ColumnWidth = 42
    wsDetail.Columns("D:E").NumberFormatLocal = "#,##0.########"
    wsDetail.Cells(MANUAL_BUILDER_HEADER_ROW, 4).Interior.Color = RGB(185, 28, 28)
    wsDetail.Cells(MANUAL_BUILDER_HEADER_ROW, 5).Interior.Color = RGB(29, 78, 216)
    wsDetail.Range(wsDetail.Cells(MANUAL_BUILDER_HEADER_ROW + 1, 4), _
                   wsDetail.Cells(MANUAL_BUILDER_HEADER_ROW + matchCount, 4)).Font.Color = RGB(153, 27, 27)
    wsDetail.Range(wsDetail.Cells(MANUAL_BUILDER_HEADER_ROW + 1, 5), _
                   wsDetail.Cells(MANUAL_BUILDER_HEADER_ROW + matchCount, 5)).Font.Color = RGB(30, 64, 175)
    With wsDetail.Range(wsDetail.Cells(MANUAL_BUILDER_HEADER_ROW + 1, 1), _
                        wsDetail.Cells(MANUAL_BUILDER_HEADER_ROW + matchCount, 7))
        .Borders.LineStyle = xlContinuous
        .Borders.Color = RGB(226, 232, 240)
        .VerticalAlignment = xlTop
        .WrapText = True
    End With
    wsDetail.Rows(CStr(MANUAL_BUILDER_HEADER_ROW + 1) & ":" & _
                  CStr(MANUAL_BUILDER_HEADER_ROW + matchCount)).RowHeight = 32
    wsDetail.Rows(1).RowHeight = 30
    wsDetail.Rows(2).RowHeight = 32
    wsDetail.Rows(3).RowHeight = 30
    wsDetail.Rows(MANUAL_BUILDER_HEADER_ROW).RowHeight = 30
    If wsDetail.AutoFilterMode Then wsDetail.AutoFilterMode = False
    wsDetail.Range(wsDetail.Cells(MANUAL_BUILDER_HEADER_ROW, 1), _
                   wsDetail.Cells(MANUAL_BUILDER_HEADER_ROW + matchCount, 7)).AutoFilter
    wsDetail.Columns("H:L").Hidden = True
    wsDetail.ScrollArea = "A1:G" & CStr(MANUAL_BUILDER_HEADER_ROW + matchCount + 20)
    RefreshManualSelectionSummary wsDetail
    ProtectSingleAnalysisSheet wsDetail
    SafeFreezeSheetAt wsDetail, "A6", 90
    mAnalysisDetailReviewsDirty = False
    wsDetail.Activate
    SafeSelectCell wsDetail, "A1"
    AppEnd
    If workbookWasSaved And Not reviewsWerePending Then ThisWorkbook.Saved = True
    Exit Sub
EH:
    errorNumber = Err.Number: errorDescription = Err.Description
    ProtectSingleAnalysisSheet wsDetail
    SetSheetVeryHiddenSafe wsDetail
    AppEnd
    If IsUserCancelError(errorNumber) Then Exit Sub
    MsgBox "�蓮���p�̎���ꗗ���쐬�ł��܂���ł����B" & vbCrLf & _
           "Err " & CStr(errorNumber) & ": " & errorDescription, vbExclamation
End Sub

Private Function ManualBuilderRowMatches(ByRef data As Variant, ByVal rowNo As Long, _
                                         ByVal queryText As String) As Boolean
    Dim searchText As String, groups As Variant, terms As Variant
    Dim groupItem As Variant, termItem As Variant, groupOK As Boolean
    If Len(Trim$(queryText)) = 0 Then
        ManualBuilderRowMatches = True
        Exit Function
    End If
    searchText = ManualBuilderSearchText(data, rowNo)
    groups = Split(Replace(queryText, "�@", " "), "|")
    For Each groupItem In groups
        terms = Split(Application.Trim(CStr(groupItem)), " ")
        groupOK = True
        For Each termItem In terms
            If Len(Trim$(CStr(termItem))) > 0 Then
                If InStr(1, searchText, Trim$(CStr(termItem)), vbTextCompare) = 0 Then
                    groupOK = False
                    Exit For
                End If
            End If
        Next termItem
        If groupOK Then
            ManualBuilderRowMatches = True
            Exit Function
        End If
    Next groupItem
End Function

Private Function ManualBuilderSearchText(ByRef data As Variant, ByVal rowNo As Long) As String
    ManualBuilderSearchText = CellText(data(rowNo, OUT_COL_BANK)) & " " & _
        CellText(data(rowNo, OUT_COL_BRANCH)) & " " & CellText(data(rowNo, OUT_COL_PERSON)) & " " & _
        CellText(data(rowNo, OUT_COL_ACCOUNT_TYPE)) & " " & _
        CellText(data(rowNo, OUT_COL_ACCOUNT_NO)) & " " & _
        Format$(CDate(data(rowNo, OUT_COL_DATE)), "yyyy/m/d") & " " & _
        CellText(data(rowNo, OUT_COL_WITHDRAW)) & " " & _
        CellText(data(rowNo, OUT_COL_DEPOSIT)) & " " & _
        CellText(data(rowNo, OUT_COL_SHOP)) & " " & _
        CellText(data(rowNo, OUT_COL_MACHINE)) & " " & _
        CellText(data(rowNo, OUT_COL_TEKIYO))
End Function

Private Sub ManualBuilderDirectionAmount(ByRef data As Variant, ByVal rowNo As Long, _
                                         ByRef directionText As String, _
                                         ByRef amountValue As Double)
    If WorkspaceDouble(data(rowNo, OUT_COL_WITHDRAW)) > 0 Then
        directionText = "�o��"
        amountValue = WorkspaceDouble(data(rowNo, OUT_COL_WITHDRAW))
    Else
        directionText = "����"
        amountValue = WorkspaceDouble(data(rowNo, OUT_COL_DEPOSIT))
    End If
End Sub

Private Function ManualBuilderAccountText(ByRef data As Variant, ByVal rowNo As Long) As String
    ManualBuilderAccountText = CellText(data(rowNo, OUT_COL_PERSON)) & " / " & _
        CellText(data(rowNo, OUT_COL_BANK)) & " " & CellText(data(rowNo, OUT_COL_BRANCH)) & _
        " / " & CellText(data(rowNo, OUT_COL_ACCOUNT_TYPE)) & " " & _
        CellText(data(rowNo, OUT_COL_ACCOUNT_NO))
End Function

Private Function ManualBuilderSummaryText(ByRef data As Variant, ByVal rowNo As Long) As String
    ManualBuilderSummaryText = "�戵�X: " & WorkspaceBlankLabel(data(rowNo, OUT_COL_SHOP)) & _
        " / �@��: " & WorkspaceBlankLabel(data(rowNo, OUT_COL_MACHINE)) & _
        " / �E�v: " & WorkspaceBlankLabel(data(rowNo, OUT_COL_TEKIYO))
End Function

Public Sub OpenAnalysisResultDetail(ByVal resultRow As Long)
    Dim wsResult As Worksheet, wsDetail As Worksheet, wsGroup As Worksheet
    Dim groupID As String, txIDList As String, focusTxID As String
    Dim nextRow As Long, errorNumber As Long, errorDescription As String
    Dim workbookWasSaved As Boolean, reviewsWerePending As Boolean
    If Not RequireToolReady() Then Exit Sub
    Set wsResult = GetSheet(SH_ANALYSIS_RESULT)
    If resultRow < 2 Or resultRow > LastUsedRowInSheet(wsResult) Then Exit Sub
    groupID = CellText(wsResult.Cells(resultRow, ANALYSIS_RESULT_GROUP_ID_COL).Value)
    If Len(groupID) = 0 Then Exit Sub
    On Error GoTo EH
    workbookWasSaved = ThisWorkbook.Saved
    reviewsWerePending = HasPendingAnalysisReviewChanges()
    '�ڍׂɕ\������m�F�󋵂��ꗗ�̍ŐV���͂ւ��낦��B
    SyncAnalysisWorkspaceReviewsToSources
    AppBegin "���ڍׂ�365���֘A����𐮗����Ă��܂�..."
    Set wsDetail = GetSheet(SH_ANALYSIS_DETAIL)
    Set wsGroup = GetSheet(SH_WORK_ANALYSIS_GROUP)
    PrepareAnalysisDetailSheet wsDetail
    wsDetail.Visible = xlSheetVisible
    wsDetail.Unprotect Password:=TOOL_PASSWORD
    WriteAnalysisDetailSummary wsResult, resultRow, wsDetail
    nextRow = 17
    txIDList = WriteAnalysisAlternativeDetails(wsGroup, groupID, wsDetail, nextRow)
    WriteAnalysisComponentTransactions txIDList, wsDetail, nextRow
    focusTxID = WorkspaceFirstTransactionID( _
        CellText(wsResult.Cells(resultRow, ANALYSIS_RESULT_TX_IDS_COL).Value))
    WriteUnknownLongTrace focusTxID, wsDetail, nextRow
    wsDetail.Columns("A:G").VerticalAlignment = xlTop
    wsDetail.Columns("A:G").WrapText = True
    wsDetail.Columns("H:L").Hidden = True
    wsDetail.ScrollArea = "A1:G" & CStr(Application.Max(50, nextRow + 20))
    ProtectSingleAnalysisSheet wsDetail
    SafeFreezeSheetAt wsDetail, "A3", 90
    mAnalysisDetailReviewsDirty = False
    wsDetail.Activate
    SafeSelectCell wsDetail, "A1"
    AppEnd
    If workbookWasSaved And Not reviewsWerePending Then ThisWorkbook.Saved = True
    Exit Sub
EH:
    errorNumber = Err.Number: errorDescription = Err.Description
    ProtectSingleAnalysisSheet wsDetail
    SetSheetVeryHiddenSafe wsDetail
    AppEnd
    If IsUserCancelError(errorNumber) Then
        MsgBox "���ڍׂ̍쐬�𒆒f���܂����B���͌��ʂƊm�F�L�^�͕ύX���Ă��܂���B", _
               vbInformation
        Exit Sub
    End If
    MsgBox "���ڍׂ̍쐬���ɃG���[���������܂����B" & vbCrLf & _
           "Err " & CStr(errorNumber) & ": " & errorDescription, vbExclamation
End Sub

Private Function WorkspaceFirstTransactionID(ByVal txIDList As String) As String
    Dim parts As Variant, item As Variant
    parts = Split(txIDList, ";")
    For Each item In parts
        WorkspaceFirstTransactionID = Trim$(CStr(item))
        If Len(WorkspaceFirstTransactionID) > 0 Then Exit Function
    Next item
End Function

Private Sub WriteAnalysisDetailSummary(ByVal wsResult As Worksheet, ByVal resultRow As Long, _
                                       ByVal wsDetail As Worksheet)
    MergeAndFormat wsDetail.Range("A1:G1"), "���͌��̏ڍ�"
    With wsDetail.Range("A1:G1")
        .Interior.Color = RGB(239, 246, 255)
        .Font.Color = RGB(30, 64, 175)
        .Font.Bold = True
        .Font.Size = 15
        .HorizontalAlignment = xlCenter
    End With
    MergeAndFormat wsDetail.Range("A2:G2"), _
        "����s���_�u���N���b�N����2���ȏ�I�� �� ���̈ē��s���_�u���N���b�N����Ǝ蓮����o�^�ł��܂��B"
    With wsDetail.Range("A2:G2")
        .Interior.Color = RGB(254, 249, 195)
        .Font.Color = RGB(133, 77, 14)
        .Font.Bold = True
        .HorizontalAlignment = xlCenter
        .WrapText = True
    End With
    wsDetail.Rows(1).RowHeight = 30
    wsDetail.Rows(2).RowHeight = 36
    wsDetail.Cells(2, DETAIL_COL_KIND).Value = "�蓮�o�^"
    wsDetail.Range("A3").Value = "�D��x": wsDetail.Range("B3").Value = wsResult.Cells(resultRow, 1).Value
    wsDetail.Range("C3").Value = "�敪": wsDetail.Range("D3").Value = wsResult.Cells(resultRow, 2).Value
    wsDetail.Range("E3").Value = "�m�F��": wsDetail.Range("F3:G3").Merge
    wsDetail.Range("F3").Value = wsResult.Cells(resultRow, 8).Value
    wsDetail.Range("A4").Value = "���t�E����": wsDetail.Range("B4:D4").Merge
    wsDetail.Range("B4").Value = wsResult.Cells(resultRow, 3).Value
    wsDetail.Range("E4").Value = "���z": wsDetail.Range("F4:G4").Merge
    wsDetail.Range("F4").Value = wsResult.Cells(resultRow, 4).Value
    wsDetail.Range("F4").NumberFormatLocal = "#,##0.########"
    wsDetail.Range("A5").Value = "�l���E�o�H": wsDetail.Range("B5:G5").Merge
    wsDetail.Range("B5").Value = wsResult.Cells(resultRow, 5).Value
    wsDetail.Range("A7").Value = "�v�_": wsDetail.Range("B7:G8").Merge
    wsDetail.Range("B7").Value = wsResult.Cells(resultRow, 6).Value
    wsDetail.Range("A10").Value = "���؁E����": wsDetail.Range("B10:G11").Merge
    wsDetail.Range("B10").Value = wsResult.Cells(resultRow, 7).Value
    wsDetail.Range("A13").Value = "�m�F����": wsDetail.Range("B13:G13").Merge
    wsDetail.Range("B13").Value = wsResult.Cells(resultRow, 9).Value
    wsDetail.Range("A14").Value = "���͎����͈�": wsDetail.Range("B14:G14").Merge
    wsDetail.Range("B14").Value = WorkspaceCoverageText( _
        CellText(wsResult.Cells(resultRow, ANALYSIS_RESULT_TX_IDS_COL).Value))
    wsDetail.Range("A15").Value = "�����m�F": wsDetail.Range("B15:G15").Merge
    wsDetail.Range("B15").Value = WorkspaceRecommendedCheck( _
        CellText(wsResult.Cells(resultRow, 2).Value), _
        WorkspaceLong(wsResult.Cells(resultRow, ANALYSIS_RESULT_ALTERNATIVE_COUNT_COL).Value))
    With wsDetail.Range("A3:G15")
        .Borders.LineStyle = xlContinuous
        .Borders.Color = RGB(203, 213, 225)
        .WrapText = True
    End With
    wsDetail.Range("A3:A15,C3:C3,E3:E4").Font.Bold = True
    wsDetail.Rows("3:4").RowHeight = 24
    wsDetail.Rows(5).RowHeight = 30
    wsDetail.Rows(6).RowHeight = 8
    wsDetail.Rows("7:8").RowHeight = 30
    wsDetail.Rows(9).RowHeight = 8
    wsDetail.Rows("10:11").RowHeight = 30
    wsDetail.Rows(12).RowHeight = 8
    wsDetail.Rows(13).RowHeight = 32
    wsDetail.Rows("14:15").RowHeight = 30
    wsDetail.Range("A6:G6,A9:G9,A12:G12").Borders.LineStyle = xlNone
    wsDetail.Range("A6:G6,A9:G9,A12:G12").Interior.Color = vbWhite
End Sub

Private Function WorkspaceRecommendedCheck(ByVal categoryText As String, _
                                           ByVal alternativeCount As Long) As String
    Select Case categoryText
        Case "�����V�t�g", "�����t���["
            WorkspaceRecommendedCheck = _
                "�ʒ����{�A���o���E�U���`�[�A������������œ��t�E�������E���`�E���z�E�o�H���ƍ����Ă��������B"
            If alternativeCount > 1 Then _
                WorkspaceRecommendedCheck = WorkspaceRecommendedCheck & _
                    " ��\�s�����Ŋm�肹���A���̑�։������r���Ă��������B"
        Case "�����s��"
            WorkspaceRecommendedCheck = _
                "�����`�[�E�U���˗��l�A���������߁A�����E���p�E���^�E�ؓ��E���������A�]�O�̎苖�������m�F���Ă��������B�E�v�����Ō����m�F�ς݂ɂ��Ȃ��ł��������B"
        Case "�g�r�s��"
            WorkspaceRecommendedCheck = _
                "���߁E�U���`�[�A����掑���A���������������A�擾���Y�E���ԍρE���^�E������E�苖�����c���m�F���Ă��������B�E�v�����Ŏg�r�m�F�ς݂ɂ��Ȃ��ł��������B"
        Case Else
            WorkspaceRecommendedCheck = "�������ƍ\��������ƍ����A���������m�莖���Ƃ��Ĉ���Ȃ��ł��������B"
    End Select
End Function

Private Function WorkspaceCoverageText(ByVal txIDList As String) As String
    Dim wsTx As Worksheet, data As Variant, lastR As Long, r As Long
    Dim wanted As Object, personIDs As Object, accounts As Object
    Dim txID As String, personID As String, accountID As String
    Dim transactionCount As Long, minDate As Long, maxDate As Long, dateValue As Long
    Set wanted = CreateObject("Scripting.Dictionary")
    Set personIDs = CreateObject("Scripting.Dictionary")
    Set accounts = CreateObject("Scripting.Dictionary")
    wanted.CompareMode = vbTextCompare
    personIDs.CompareMode = vbTextCompare
    accounts.CompareMode = vbTextCompare
    AddWorkspaceIDsToSet txIDList, wanted
    Set wsTx = GetSheet(SH_WORK_TX)
    lastR = LastUsedRowInSheet(wsTx)
    If lastR < 2 Then
        WorkspaceCoverageText = "���͍ςݎ��������܂���B"
        Exit Function
    End If
    data = wsTx.Range(wsTx.Cells(2, 1), wsTx.Cells(lastR, WORK_TX_COL_PERSON_ID)).Value2
    For r = 1 To UBound(data, 1)
        txID = CellText(data(r, WORK_TX_COL_TRANSACTION_ID))
        If wanted.Exists(txID) Then
            personID = WorkspacePersonIdentity(data, r)
            If Len(personID) > 0 Then personIDs(personID) = True
        End If
    Next r
    For r = 1 To UBound(data, 1)
        personID = WorkspacePersonIdentity(data, r)
        If personIDs.Exists(personID) Then
            If WorkspaceDouble(data(r, OUT_COL_WITHDRAW)) > 0 Or _
               WorkspaceDouble(data(r, OUT_COL_DEPOSIT)) > 0 Then
                transactionCount = transactionCount + 1
                accountID = CellText(data(r, WORK_TX_COL_ACCOUNT_ID))
                If Len(accountID) > 0 Then accounts(accountID) = True
                If IsDate(data(r, OUT_COL_DATE)) Then
                    dateValue = CLng(DateValue(CDate(data(r, OUT_COL_DATE))))
                    If minDate = 0 Or dateValue < minDate Then minDate = dateValue
                    If dateValue > maxDate Then maxDate = dateValue
                End If
            End If
        End If
    Next r
    WorkspaceCoverageText = "�\������Ɠ���l���ɂ��āA���͍ς� " & _
        Format$(accounts.Count, "#,##0") & "�����E" & Format$(transactionCount, "#,##0") & "���"
    If minDate > 0 Then
        WorkspaceCoverageText = WorkspaceCoverageText & "�i" & _
            Format$(CDate(minDate), "yyyy/m/d") & "�`" & Format$(CDate(maxDate), "yyyy/m/d") & "�j"
    End If
    WorkspaceCoverageText = WorkspaceCoverageText & _
        "���ϑ��B�����͎����E�����ۗL���͊܂܂ꂸ�A���Ȃ��͕s���݂̏ؖ��ł͂���܂���B"
End Function

Private Function WriteAnalysisAlternativeDetails(ByVal wsGroup As Worksheet, ByVal groupID As String, _
                                                 ByVal wsDetail As Worksheet, ByRef nextRow As Long) As String
    Dim lastR As Long, data As Variant, r As Long, sourceRow As Long
    Dim sourceSheet As String, txIDs As String, memberCount As Long
    Dim txSet As Object
    Set txSet = CreateObject("Scripting.Dictionary")
    txSet.CompareMode = vbTextCompare
    lastR = LastUsedRowInSheet(wsGroup)
    wsDetail.Cells(nextRow, 1).Value = "��։����i������������L������j"
    wsDetail.Cells(nextRow, 1).Font.Bold = True
    nextRow = nextRow + 1
    SetRowValues wsDetail.Cells(nextRow, 1), Array("���", "�]���E�_", "���t�E����", "�����o�H�E�Ώ�", "���藝�R", "�m�F��", "�ʒu�t��")
    FormatOutputHeader wsDetail.Range(wsDetail.Cells(nextRow, 1), wsDetail.Cells(nextRow, 7))
    nextRow = nextRow + 1
    If lastR >= 2 Then
        data = wsGroup.Range(wsGroup.Cells(2, 1), wsGroup.Cells(lastR, ANALYSIS_GROUP_LAST_COL)).Value2
        For r = 1 To UBound(data, 1)
            If StrComp(CellText(data(r, 1)), groupID, vbBinaryCompare) = 0 Then
                sourceSheet = CellText(data(r, 2))
                sourceRow = WorkspaceLong(data(r, 3))
                txIDs = CellText(data(r, 5))
                AddWorkspaceIDsToSet txIDs, txSet
                WriteOneAlternativeDetail GetSheet(sourceSheet), sourceRow, sourceSheet, _
                                          CellText(data(r, 7)), wsDetail, nextRow
                nextRow = nextRow + 2
                memberCount = memberCount + 1
            End If
        Next r
    End If
    If memberCount = 0 Then
        wsDetail.Cells(nextRow, 1).Value = "�����O���[�v��񂪂���܂���B�ĕ��͂��Ă��������B"
        nextRow = nextRow + 1
    End If
    nextRow = nextRow + 1
    WriteAnalysisAlternativeDetails = WorkspaceJoinDictionaryKeys(txSet)
End Function

Private Sub WriteOneAlternativeDetail(ByVal wsSource As Worksheet, ByVal sourceRow As Long, _
                                      ByVal sourceSheet As String, ByVal positionText As String, _
                                      ByVal wsDetail As Worksheet, ByVal outputRow As Long)
    If sourceRow < 2 Or sourceRow > LastUsedRowInSheet(wsSource) Then _
        Err.Raise vbObjectError + 4810, "WriteOneAlternativeDetail", "�������s��������܂���B"
    Select Case sourceSheet
        Case SH_ANALYSIS_SHIFT
            wsDetail.Cells(outputRow, 1).Value = "�����V�t�g"
            wsDetail.Cells(outputRow, 2).Value = CellText(wsSource.Cells(sourceRow, 1).Value) & _
                                                        " / " & CellText(wsSource.Cells(sourceRow, 2).Value)
            wsDetail.Cells(outputRow, 3).Value = WorkspacePeriodText(wsSource.Cells(sourceRow, 9).Value, _
                                                                     wsSource.Cells(sourceRow, 19).Value)
            wsDetail.Cells(outputRow, 4).Value = WorkspacePartyAccount( _
                wsSource.Cells(sourceRow, 11).Value, wsSource.Cells(sourceRow, 12).Value, _
                wsSource.Cells(sourceRow, 13).Value, wsSource.Cells(sourceRow, 14).Value, _
                wsSource.Cells(sourceRow, 15).Value, wsSource.Cells(sourceRow, 16).Value) & " �� " & _
                WorkspacePartyAccount(wsSource.Cells(sourceRow, 21).Value, wsSource.Cells(sourceRow, 22).Value, _
                wsSource.Cells(sourceRow, 23).Value, wsSource.Cells(sourceRow, 24).Value, _
                wsSource.Cells(sourceRow, 25).Value, wsSource.Cells(sourceRow, 26).Value)
            wsDetail.Cells(outputRow, 5).Value = WorkspaceTrimText(CellText(wsSource.Cells(sourceRow, 29).Value), WORKSPACE_TEXT_LIMIT)
            wsDetail.Cells(outputRow, 6).Value = wsSource.Cells(sourceRow, SHIFT_ANALYSIS_STATUS_COL).Value
        Case SH_ANALYSIS_FLOW
            wsDetail.Cells(outputRow, 1).Value = "�����t���["
            wsDetail.Cells(outputRow, 2).Value = CellText(wsSource.Cells(sourceRow, 1).Value) & _
                                                        " / " & CellText(wsSource.Cells(sourceRow, 2).Value)
            wsDetail.Cells(outputRow, 3).Value = wsSource.Cells(sourceRow, 6).Value
            wsDetail.Cells(outputRow, 4).Value = wsSource.Cells(sourceRow, 12).Value
            wsDetail.Cells(outputRow, 5).Value = WorkspaceTrimText(CellText(wsSource.Cells(sourceRow, 16).Value), WORKSPACE_TEXT_LIMIT)
            wsDetail.Cells(outputRow, 6).Value = wsSource.Cells(sourceRow, FLOW_ANALYSIS_STATUS_COL).Value
        Case SH_ANALYSIS_UNKNOWN
            wsDetail.Cells(outputRow, 1).Value = Replace(CellText(wsSource.Cells(sourceRow, 3).Value), "���", "")
            wsDetail.Cells(outputRow, 2).Value = CellText(wsSource.Cells(sourceRow, 1).Value) & _
                                                        " / " & CellText(wsSource.Cells(sourceRow, 2).Value)
            wsDetail.Cells(outputRow, 3).Value = WorkspaceDateText(wsSource.Cells(sourceRow, 4).Value) & _
                                                " " & WorkspaceTimeText(wsSource.Cells(sourceRow, 5).Value)
            wsDetail.Cells(outputRow, 4).Value = WorkspacePartyAccount( _
                wsSource.Cells(sourceRow, 7).Value, wsSource.Cells(sourceRow, 8).Value, _
                wsSource.Cells(sourceRow, 9).Value, wsSource.Cells(sourceRow, 10).Value, _
                wsSource.Cells(sourceRow, 11).Value, wsSource.Cells(sourceRow, 12).Value)
            wsDetail.Cells(outputRow, 5).Value = WorkspaceTrimText(CellText(wsSource.Cells(sourceRow, 20).Value), WORKSPACE_TEXT_LIMIT)
            wsDetail.Cells(outputRow, 6).Value = wsSource.Cells(sourceRow, UNKNOWN_ANALYSIS_STATUS_COL).Value
    End Select
    If sourceSheet = SH_ANALYSIS_FLOW And _
       CellText(wsSource.Cells(sourceRow, 3).Value) = "�蓮�w��" Then
        wsDetail.Cells(outputRow, 7).Value = positionText & " / �_�u���N���b�N�Ŗ�����"
    Else
        wsDetail.Cells(outputRow, 7).Value = positionText
    End If
    wsDetail.Cells(outputRow, DETAIL_COL_KIND).Value = "���"
    wsDetail.Cells(outputRow, DETAIL_COL_REFERENCE).Value = sourceSheet
    wsDetail.Cells(outputRow, DETAIL_COL_SOURCE_ROW).Value = sourceRow
    wsDetail.Cells(outputRow, DETAIL_COL_SOURCE_KEY).Value = _
        wsSource.Cells(sourceRow, WorkspaceDetailKeyColumn(sourceSheet)).Value
    wsDetail.Cells(outputRow, 6).Locked = False
    ApplyAnalysisDetailStatusValidation wsDetail.Cells(outputRow, 6), sourceSheet, _
                                        CellText(wsDetail.Cells(outputRow, 1).Value)
    With wsDetail.Range(wsDetail.Cells(outputRow, 1), wsDetail.Cells(outputRow, 7))
        .Borders.LineStyle = xlContinuous
        .Borders.Color = RGB(226, 232, 240)
        .WrapText = True
        .VerticalAlignment = xlTop
    End With
    wsDetail.Rows(outputRow).RowHeight = 48
    wsDetail.Cells(outputRow + 1, 1).Value = "�ʊm�F����"
    wsDetail.Range(wsDetail.Cells(outputRow + 1, 2), wsDetail.Cells(outputRow + 1, 7)).Merge
    Select Case sourceSheet
        Case SH_ANALYSIS_SHIFT
            wsDetail.Cells(outputRow + 1, 2).Value = wsSource.Cells(sourceRow, SHIFT_ANALYSIS_MEMO_COL).Value
        Case SH_ANALYSIS_FLOW
            wsDetail.Cells(outputRow + 1, 2).Value = wsSource.Cells(sourceRow, FLOW_ANALYSIS_MEMO_COL).Value
        Case SH_ANALYSIS_UNKNOWN
            wsDetail.Cells(outputRow + 1, 2).Value = wsSource.Cells(sourceRow, UNKNOWN_ANALYSIS_MEMO_COL).Value
    End Select
    wsDetail.Cells(outputRow + 1, DETAIL_COL_KIND).Value = "��⃁��"
    wsDetail.Cells(outputRow + 1, DETAIL_COL_REFERENCE).Value = sourceSheet
    wsDetail.Cells(outputRow + 1, DETAIL_COL_SOURCE_ROW).Value = sourceRow
    wsDetail.Cells(outputRow + 1, DETAIL_COL_SOURCE_KEY).Value = _
        wsDetail.Cells(outputRow, DETAIL_COL_SOURCE_KEY).Value
    wsDetail.Range(wsDetail.Cells(outputRow + 1, 2), _
                   wsDetail.Cells(outputRow + 1, 7)).Locked = False
    ApplyAnalysisDetailMemoValidation wsDetail.Cells(outputRow + 1, 2)
    With wsDetail.Range(wsDetail.Cells(outputRow + 1, 1), wsDetail.Cells(outputRow + 1, 7))
        .Borders.LineStyle = xlContinuous
        .Borders.Color = RGB(226, 232, 240)
        .Interior.Color = RGB(255, 251, 235)
        .WrapText = True
        .VerticalAlignment = xlTop
    End With
    wsDetail.Rows(outputRow + 1).RowHeight = 38
End Sub

Private Sub WriteAnalysisComponentTransactions(ByVal txIDList As String, ByVal wsDetail As Worksheet, _
                                               ByRef nextRow As Long)
    Dim wsTx As Worksheet, data As Variant, lastR As Long, r As Long, outputCount As Long
    Dim wanted As Object, txID As String, amountValue As Double, kindText As String
    Set wanted = CreateObject("Scripting.Dictionary")
    wanted.CompareMode = vbTextCompare
    AddWorkspaceIDsToSet txIDList, wanted
    wsDetail.Cells(nextRow, 1).Value = "�\������i�����󗓂� --:--�B���莞���͍쐬���܂���j"
    wsDetail.Cells(nextRow, 1).Font.Bold = True
    nextRow = nextRow + 1
    SetRowValues wsDetail.Cells(nextRow, 1), Array("���t", "����", "�l��", "����", "�o��", "����", "�E�v")
    FormatOutputHeader wsDetail.Range(wsDetail.Cells(nextRow, 1), wsDetail.Cells(nextRow, 7))
    wsDetail.Cells(nextRow, 5).Interior.Color = RGB(185, 28, 28)
    wsDetail.Cells(nextRow, 6).Interior.Color = RGB(29, 78, 216)
    nextRow = nextRow + 1
    Set wsTx = GetSheet(SH_WORK_TX)
    lastR = LastUsedRowInSheet(wsTx)
    If lastR >= 2 And wanted.Count > 0 Then
        data = wsTx.Range(wsTx.Cells(2, 1), wsTx.Cells(lastR, WORK_TX_COL_PERSON_ID)).Value2
        For r = 1 To UBound(data, 1)
            txID = CellText(data(r, WORK_TX_COL_TRANSACTION_ID))
            If wanted.Exists(txID) Then
                WorkspaceTransactionDirection data, r, kindText, amountValue
                WriteWorkspaceTransactionRow wsDetail, nextRow, data, r, kindText, amountValue, vbNullString
                nextRow = nextRow + 1
                outputCount = outputCount + 1
            End If
        Next r
    End If
    If outputCount < wanted.Count Then
        wsDetail.Cells(nextRow, 1).Value = "����: �\�����ID " & CStr(wanted.Count - outputCount) & _
                                             "�������s�f�[�^�Ŋm�F�ł��܂���B�ĕ��͂��Ă��������B"
        nextRow = nextRow + 1
    End If
    nextRow = nextRow + 1
End Sub

Private Sub WriteUnknownLongTrace(ByVal selectedTxID As String, ByVal wsDetail As Worksheet, _
                                  ByRef nextRow As Long)
    Dim wsTx As Worksheet, data As Variant, lastR As Long, selectedRow As Long
    Dim candidateRows() As Long, candidateScores() As Long, candidateDayDiffs() As Long
    Dim candidateCount As Long, r As Long, dayDifference As Long, relevance As Long
    Dim selectedDate As Long, selectedAmount As Double, selectedKind As String
    Dim selectedAccount As String, selectedPerson As String, currentAccount As String, currentPerson As String
    Dim currentAmount As Double, currentKind As String, relationText As String
    Dim displayCount As Long, omittedCount As Long
    Dim totals(1 To 3, 1 To 4) As Double, counts(1 To 3, 1 To 4) As Long
    Dim absoluteTolerance As Double, rateTolerance As Double
    Set wsTx = GetSheet(SH_WORK_TX)
    lastR = LastUsedRowInSheet(wsTx)
    If lastR < 2 Or Len(selectedTxID) = 0 Then Exit Sub
    data = wsTx.Range(wsTx.Cells(2, 1), wsTx.Cells(lastR, WORK_TX_COL_PERSON_ID)).Value2
    For r = 1 To UBound(data, 1)
        If StrComp(CellText(data(r, WORK_TX_COL_TRANSACTION_ID)), selectedTxID, vbTextCompare) = 0 Then
            selectedRow = r
            Exit For
        End If
    Next r
    If selectedRow = 0 Then Exit Sub
    selectedDate = CLng(DateValue(CDate(data(selectedRow, OUT_COL_DATE))))
    selectedAccount = CellText(data(selectedRow, WORK_TX_COL_ACCOUNT_ID))
    selectedPerson = WorkspacePersonIdentity(data, selectedRow)
    WorkspaceTransactionDirection data, selectedRow, selectedKind, selectedAmount
    absoluteTolerance = WorkspaceDouble(GetSheet(SH_CONFIG).Cells(ROW_CFG_ANALYSIS_ABS_TOLERANCE, _
                                                                  COL_CFG_ANALYSIS_VALUE).Value)
    rateTolerance = WorkspaceRateTolerance(GetSheet(SH_CONFIG).Cells(ROW_CFG_ANALYSIS_RATE_TOLERANCE, _
                                                                     COL_CFG_ANALYSIS_VALUE))
    ReDim candidateRows(1 To UBound(data, 1))
    ReDim candidateScores(1 To UBound(data, 1))
    ReDim candidateDayDiffs(1 To UBound(data, 1))
    For r = 1 To UBound(data, 1)
        If r Mod 4096 = 0 Then AppProgress "365���֘A������ƍ����Ă��܂�...", r, UBound(data, 1)
        If r <> selectedRow And IsDate(data(r, OUT_COL_DATE)) Then
            WorkspaceTransactionDirection data, r, currentKind, currentAmount
            If currentAmount > 0 Then
                dayDifference = Abs(CLng(DateValue(CDate(data(r, OUT_COL_DATE)))) - selectedDate)
                If dayDifference <= 365 Then
                    currentAccount = CellText(data(r, WORK_TX_COL_ACCOUNT_ID))
                    currentPerson = WorkspacePersonIdentity(data, r)
                    If StrComp(currentAccount, selectedAccount, vbTextCompare) = 0 Or _
                       (Len(selectedPerson) > 0 And StrComp(currentPerson, selectedPerson, vbTextCompare) = 0) Then
                        relevance = WorkspaceTraceRelevance(data, selectedRow, r, selectedKind, currentKind, _
                                                           selectedAmount, currentAmount, dayDifference, _
                                                           absoluteTolerance, rateTolerance)
                        candidateCount = candidateCount + 1
                        candidateRows(candidateCount) = r
                        candidateScores(candidateCount) = relevance
                        candidateDayDiffs(candidateCount) = dayDifference
                        AccumulateWorkspaceTrace totals, counts, dayDifference, _
                            (StrComp(currentAccount, selectedAccount, vbTextCompare) = 0), _
                            (StrComp(currentKind, selectedKind, vbTextCompare) = 0), currentAmount
                    End If
                End If
            End If
        End If
    Next r
    If candidateCount > 1 Then _
        QuickSortWorkspaceTrace candidateRows, candidateScores, candidateDayDiffs, 1, candidateCount

    wsDetail.Cells(nextRow, 1).Value = "�I������𒆐S�Ƃ���365���֘A���"
    wsDetail.Cells(nextRow, 1).Font.Bold = True
    nextRow = nextRow + 1
    wsDetail.Range(wsDetail.Cells(nextRow, 1), wsDetail.Cells(nextRow, 7)).Merge
    wsDetail.Cells(nextRow, 1).Value = _
        "��������܂��͓���l���̎�����֘A�x���ɕ\�����܂��B���͉����ł���A�����������̑O��֌W�͒f�肵�܂���B"
    wsDetail.Cells(nextRow, 1).Interior.Color = RGB(255, 251, 235)
    nextRow = nextRow + 1
    SetRowValues wsDetail.Cells(nextRow, 1), Array("���t", "����", "�l��", "����", "�o��", "����", "�֌W�E�E�v")
    FormatOutputHeader wsDetail.Range(wsDetail.Cells(nextRow, 1), wsDetail.Cells(nextRow, 7))
    wsDetail.Cells(nextRow, 5).Interior.Color = RGB(185, 28, 28)
    wsDetail.Cells(nextRow, 6).Interior.Color = RGB(29, 78, 216)
    nextRow = nextRow + 1
    displayCount = candidateCount
    If displayCount > WORKSPACE_DETAIL_LIMIT Then displayCount = WORKSPACE_DETAIL_LIMIT
    For r = 1 To displayCount
        relationText = WorkspaceTraceRelation(data, selectedRow, candidateRows(r), selectedKind)
        WorkspaceTransactionDirection data, candidateRows(r), currentKind, currentAmount
        relationText = relationText & "�E�֘A�x" & CStr(candidateScores(r))
        WriteWorkspaceTransactionRow wsDetail, nextRow, data, candidateRows(r), _
                                     currentKind, currentAmount, relationText
        nextRow = nextRow + 1
    Next r
    omittedCount = candidateCount - displayCount
    If omittedCount > 0 Then
        wsDetail.Cells(nextRow, 1).Value = "�\������̂��ߊ֘A�x�̒Ⴂ " & _
                                             Format$(omittedCount, "#,##0") & "�����ȗ����܂����B"
        nextRow = nextRow + 1
    End If
    nextRow = nextRow + 1
    WriteWorkspaceAggregateSummary wsDetail, nextRow, totals, counts
End Sub

Private Sub AccumulateWorkspaceTrace(ByRef totals() As Double, ByRef counts() As Long, _
                                     ByVal dayDifference As Long, ByVal sameAccount As Boolean, _
                                     ByVal sameDirection As Boolean, ByVal amountValue As Double)
    Dim windowIndex As Long, categoryIndex As Long, limitDays As Long
    If sameAccount Then
        If sameDirection Then categoryIndex = 1 Else categoryIndex = 2
    Else
        If sameDirection Then categoryIndex = 3 Else categoryIndex = 4
    End If
    For windowIndex = 1 To 3
        Select Case windowIndex
            Case 1: limitDays = 30
            Case 2: limitDays = 90
            Case Else: limitDays = 365
        End Select
        If dayDifference <= limitDays Then
            totals(windowIndex, categoryIndex) = totals(windowIndex, categoryIndex) + amountValue
            counts(windowIndex, categoryIndex) = counts(windowIndex, categoryIndex) + 1
        End If
    Next windowIndex
End Sub

Private Sub WriteWorkspaceAggregateSummary(ByVal ws As Worksheet, ByRef nextRow As Long, _
                                           ByRef totals() As Double, ByRef counts() As Long)
    Dim windowIndex As Long, categoryIndex As Long, limitDays As Long
    Dim labels As Variant
    labels = Array("�������E����", "�������E����", "���������l���E����", "���������l���E����")
    ws.Cells(nextRow, 1).Value = "30�E90�E365���ݐρi�ʂ̎����ړ��m��ł͂Ȃ��A�����E�����̊m�F�⏕�j"
    ws.Cells(nextRow, 1).Font.Bold = True
    nextRow = nextRow + 1
    SetRowValues ws.Cells(nextRow, 1), Array("����", "�֌W", "����", "�݌v�z", "���ߏ�̒���", "", "")
    FormatOutputHeader ws.Range(ws.Cells(nextRow, 1), ws.Cells(nextRow, 7))
    nextRow = nextRow + 1
    For windowIndex = 1 To 3
        Select Case windowIndex
            Case 1: limitDays = 30
            Case 2: limitDays = 90
            Case Else: limitDays = 365
        End Select
        For categoryIndex = 1 To 4
            ws.Cells(nextRow, 1).Value = "�O��" & CStr(limitDays) & "��"
            ws.Cells(nextRow, 2).Value = labels(categoryIndex - 1)
            ws.Cells(nextRow, 3).Value = counts(windowIndex, categoryIndex)
            ws.Cells(nextRow, 4).Value = totals(windowIndex, categoryIndex)
            ws.Cells(nextRow, 4).NumberFormatLocal = "#,##0.########"
            ws.Range(ws.Cells(nextRow, 5), ws.Cells(nextRow, 7)).Merge
            ws.Cells(nextRow, 5).Value = "�݌v�͊֘A�͈͂̏���l�ŁA���ꎑ���̏d���v����������m��z�ł͂���܂���B"
            With ws.Range(ws.Cells(nextRow, 1), ws.Cells(nextRow, 7)).Borders
                .LineStyle = xlContinuous
                .Color = RGB(226, 232, 240)
            End With
            nextRow = nextRow + 1
        Next categoryIndex
    Next windowIndex
    nextRow = nextRow + 1
End Sub

Private Function WorkspaceTraceRelevance(ByRef data As Variant, ByVal selectedRow As Long, _
                                         ByVal currentRow As Long, ByVal selectedKind As String, _
                                         ByVal currentKind As String, ByVal selectedAmount As Double, _
                                         ByVal currentAmount As Double, ByVal dayDifference As Long, _
                                         ByVal absoluteTolerance As Double, ByVal rateTolerance As Double) As Long
    Dim allowedDifference As Double
    If StrComp(CellText(data(selectedRow, WORK_TX_COL_ACCOUNT_ID)), _
               CellText(data(currentRow, WORK_TX_COL_ACCOUNT_ID)), vbTextCompare) = 0 Then
        WorkspaceTraceRelevance = WorkspaceTraceRelevance + 24
    Else
        WorkspaceTraceRelevance = WorkspaceTraceRelevance + 12
    End If
    If StrComp(selectedKind, currentKind, vbTextCompare) <> 0 Then _
        WorkspaceTraceRelevance = WorkspaceTraceRelevance + 20
    allowedDifference = absoluteTolerance
    If selectedAmount * rateTolerance > allowedDifference Then allowedDifference = selectedAmount * rateTolerance
    If currentAmount * rateTolerance > allowedDifference Then allowedDifference = currentAmount * rateTolerance
    If Abs(selectedAmount - currentAmount) <= allowedDifference + 0.0000001 Then _
        WorkspaceTraceRelevance = WorkspaceTraceRelevance + 30
    If dayDifference = 0 Then
        WorkspaceTraceRelevance = WorkspaceTraceRelevance + 16
    ElseIf dayDifference <= 7 Then
        WorkspaceTraceRelevance = WorkspaceTraceRelevance + 12
    ElseIf dayDifference <= 30 Then
        WorkspaceTraceRelevance = WorkspaceTraceRelevance + 8
    ElseIf dayDifference <= 90 Then
        WorkspaceTraceRelevance = WorkspaceTraceRelevance + 4
    End If
End Function

Private Function WorkspaceTraceRelation(ByRef data As Variant, ByVal selectedRow As Long, _
                                        ByVal currentRow As Long, ByVal selectedKind As String) As String
    Dim selectedDate As Long, currentDate As Long
    Dim selectedTime As Double, currentTime As Double
    Dim selectedHasTime As Boolean, currentHasTime As Boolean
    Dim accountText As String
    If StrComp(CellText(data(selectedRow, WORK_TX_COL_ACCOUNT_ID)), _
               CellText(data(currentRow, WORK_TX_COL_ACCOUNT_ID)), vbTextCompare) = 0 Then
        accountText = "������"
    Else
        accountText = "���l���E������"
    End If
    selectedDate = CLng(DateValue(CDate(data(selectedRow, OUT_COL_DATE))))
    currentDate = CLng(DateValue(CDate(data(currentRow, OUT_COL_DATE))))
    If currentDate < selectedDate Then
        WorkspaceTraceRelation = accountText & "�E�I��������O"
    ElseIf currentDate > selectedDate Then
        WorkspaceTraceRelation = accountText & "�E�I���������"
    Else
        selectedHasTime = WorkspaceTryTime(data(selectedRow, OUT_COL_TIME), selectedTime)
        currentHasTime = WorkspaceTryTime(data(currentRow, OUT_COL_TIME), currentTime)
        If selectedHasTime And currentHasTime Then
            If currentTime < selectedTime - 0.000000001 Then
                WorkspaceTraceRelation = accountText & "�E�����őO"
            ElseIf currentTime > selectedTime + 0.000000001 Then
                WorkspaceTraceRelation = accountText & "�E�����Ō�"
            Else
                WorkspaceTraceRelation = accountText & "�E������"
            End If
        Else
            WorkspaceTraceRelation = accountText & "�E�����E�������m��"
        End If
    End If
End Function

Private Sub QuickSortWorkspaceTrace(ByRef rows() As Long, ByRef scores() As Long, _
                                    ByRef dayDiffs() As Long, ByVal firstIndex As Long, _
                                    ByVal lastIndex As Long)
    Dim low As Long, high As Long, pivotScore As Long, pivotDays As Long
    Dim tempLong As Long
    low = firstIndex: high = lastIndex
    pivotScore = scores((firstIndex + lastIndex) \ 2)
    pivotDays = dayDiffs((firstIndex + lastIndex) \ 2)
    Do While low <= high
        Do While WorkspaceTraceBefore(scores(low), dayDiffs(low), pivotScore, pivotDays)
            low = low + 1
        Loop
        Do While WorkspaceTraceBefore(pivotScore, pivotDays, scores(high), dayDiffs(high))
            high = high - 1
        Loop
        If low <= high Then
            tempLong = rows(low): rows(low) = rows(high): rows(high) = tempLong
            tempLong = scores(low): scores(low) = scores(high): scores(high) = tempLong
            tempLong = dayDiffs(low): dayDiffs(low) = dayDiffs(high): dayDiffs(high) = tempLong
            low = low + 1: high = high - 1
        End If
    Loop
    If firstIndex < high Then QuickSortWorkspaceTrace rows, scores, dayDiffs, firstIndex, high
    If low < lastIndex Then QuickSortWorkspaceTrace rows, scores, dayDiffs, low, lastIndex
End Sub

Private Function WorkspaceTraceBefore(ByVal firstScore As Long, ByVal firstDays As Long, _
                                      ByVal secondScore As Long, ByVal secondDays As Long) As Boolean
    If firstScore > secondScore Then
        WorkspaceTraceBefore = True
    ElseIf firstScore = secondScore Then
        WorkspaceTraceBefore = (firstDays < secondDays)
    End If
End Function

Private Sub WriteWorkspaceTransactionRow(ByVal ws As Worksheet, ByVal outputRow As Long, _
                                         ByRef data As Variant, ByVal sourceRow As Long, _
                                         ByVal kindText As String, ByVal amountValue As Double, _
                                         ByVal extraText As String)
    ws.Cells(outputRow, 1).Value = CDate(data(sourceRow, OUT_COL_DATE))
    ws.Cells(outputRow, 1).NumberFormatLocal = "yyyy/m/d"
    ws.Cells(outputRow, 2).Value = WorkspaceTimeText(data(sourceRow, OUT_COL_TIME))
    ws.Cells(outputRow, 3).Value = CellText(data(sourceRow, OUT_COL_PERSON)) & _
                                          WorkspaceRelationshipSuffix(data(sourceRow, WORK_TX_COL_RELATIONSHIP))
    ws.Cells(outputRow, 4).Value = WorkspacePartyAccount(vbNullString, vbNullString, _
        data(sourceRow, OUT_COL_BANK), data(sourceRow, OUT_COL_BRANCH), _
        data(sourceRow, OUT_COL_ACCOUNT_TYPE), data(sourceRow, OUT_COL_ACCOUNT_NO))
    If InStr(1, kindText, "�o��", vbTextCompare) > 0 Then
        ws.Cells(outputRow, 5).Value = amountValue
    ElseIf InStr(1, kindText, "����", vbTextCompare) > 0 Then
        ws.Cells(outputRow, 6).Value = amountValue
    End If
    ws.Range(ws.Cells(outputRow, 5), ws.Cells(outputRow, 6)).NumberFormatLocal = "#,##0.########"
    ws.Cells(outputRow, 5).Font.Color = RGB(153, 27, 27)
    ws.Cells(outputRow, 6).Font.Color = RGB(30, 64, 175)
    If Len(extraText) > 0 Then
        ws.Cells(outputRow, 7).Value = extraText & " / �E�v: " & _
                                       WorkspaceBlankLabel(data(sourceRow, OUT_COL_TEKIYO))
    Else
        ws.Cells(outputRow, 7).Value = WorkspaceBlankLabel(data(sourceRow, OUT_COL_TEKIYO))
    End If
    ws.Cells(outputRow, DETAIL_COL_KIND).Value = "���"
    ws.Cells(outputRow, DETAIL_COL_REFERENCE).Value = _
        CellText(data(sourceRow, WORK_TX_COL_TRANSACTION_ID))
    ws.Cells(outputRow, DETAIL_COL_SOURCE_ROW).Value = sourceRow
    ws.Cells(outputRow, DETAIL_COL_SELECTED).Value = "0"
    With ws.Range(ws.Cells(outputRow, 1), ws.Cells(outputRow, 7))
        .Borders.LineStyle = xlContinuous
        .Borders.Color = RGB(226, 232, 240)
        .WrapText = True
        .VerticalAlignment = xlTop
    End With
End Sub

Private Function WorkspaceDetailKeyColumn(ByVal sourceSheet As String) As Long
    Select Case sourceSheet
        Case SH_ANALYSIS_SHIFT: WorkspaceDetailKeyColumn = SHIFT_ANALYSIS_KEY_COL
        Case SH_ANALYSIS_FLOW: WorkspaceDetailKeyColumn = FLOW_ANALYSIS_KEY_COL
        Case SH_ANALYSIS_UNKNOWN: WorkspaceDetailKeyColumn = UNKNOWN_ANALYSIS_KEY_COL
        Case Else
            Err.Raise vbObjectError + 4811, "WorkspaceDetailKeyColumn", _
                      "���ڍׂ̓������\���s���ł��B"
    End Select
End Function

Private Sub ApplyAnalysisDetailStatusValidation(ByVal target As Range, _
                                                ByVal sourceSheet As String, _
                                                ByVal categoryText As String)
    Dim listName As String
    If sourceSheet = SH_ANALYSIS_SHIFT Or sourceSheet = SH_ANALYSIS_FLOW Then
        listName = NM_LST_ANALYSIS_SHIFT_STATUS
    ElseIf categoryText = "�����s��" Then
        listName = NM_LST_ANALYSIS_SOURCE_STATUS
    Else
        listName = NM_LST_ANALYSIS_USE_STATUS
    End If
    With target.Validation
        .Delete
        .Add Type:=xlValidateList, AlertStyle:=xlValidAlertStop, _
             Operator:=xlBetween, Formula1:="=" & listName
        .IgnoreBlank = True
        .InCellDropdown = True
        .ShowError = True
        .ErrorTitle = "�m�F�󋵂�I�����Ă�������"
        .ErrorMessage = "���̋敪�ɑΉ�����m�F�󋵂�I�����Ă��������B"
    End With
End Sub

Private Sub ApplyAnalysisDetailMemoValidation(ByVal target As Range)
    With target.Validation
        .Delete
        .Add Type:=xlValidateTextLength, AlertStyle:=xlValidAlertStop, _
             Operator:=xlLessEqual, Formula1:=CStr(WORKSPACE_MEMO_MAX)
        .IgnoreBlank = True
        .ShowError = True
        .ErrorTitle = "�m�F�����̕��������m�F���Ă�������"
        .ErrorMessage = "�m�F������" & CStr(WORKSPACE_MEMO_MAX) & "�����ȓ��œ��͂��Ă��������B"
    End With
End Sub

Private Sub WorkspaceTransactionDirection(ByRef data As Variant, ByVal sourceRow As Long, _
                                          ByRef kindText As String, ByRef amountValue As Double)
    If WorkspaceDouble(data(sourceRow, OUT_COL_WITHDRAW)) > 0 Then
        kindText = "�o��"
        amountValue = WorkspaceDouble(data(sourceRow, OUT_COL_WITHDRAW))
    ElseIf WorkspaceDouble(data(sourceRow, OUT_COL_DEPOSIT)) > 0 Then
        kindText = "����"
        amountValue = WorkspaceDouble(data(sourceRow, OUT_COL_DEPOSIT))
    Else
        kindText = "�ΏۊO"
        amountValue = 0
    End If
End Sub

Private Function WorkspacePersonIdentity(ByRef data As Variant, ByVal sourceRow As Long) As String
    WorkspacePersonIdentity = CellText(data(sourceRow, WORK_TX_COL_PERSON_ID))
    If Len(WorkspacePersonIdentity) = 0 Then _
        WorkspacePersonIdentity = NormalizePersonNameKey(CellText(data(sourceRow, OUT_COL_PERSON)))
End Function

Private Sub AddWorkspaceIDsToSet(ByVal idList As String, ByVal target As Object)
    Dim parts As Variant, item As Variant, txID As String
    If Len(idList) = 0 Then Exit Sub
    parts = Split(idList, ";")
    For Each item In parts
        txID = Trim$(CStr(item))
        If Len(txID) > 0 Then target(txID) = True
    Next item
End Sub

Private Function WorkspaceJoinDictionaryKeys(ByVal values As Object) As String
    Dim keys As Variant, i As Long, j As Long, tempText As String
    If values Is Nothing Then Exit Function
    If values.Count = 0 Then Exit Function
    keys = values.Keys
    For i = LBound(keys) + 1 To UBound(keys)
        tempText = CStr(keys(i)): j = i - 1
        Do While j >= LBound(keys)
            If StrComp(CStr(keys(j)), tempText, vbTextCompare) <= 0 Then Exit Do
            keys(j + 1) = keys(j): j = j - 1
        Loop
        keys(j + 1) = tempText
    Next i
    For i = LBound(keys) To UBound(keys)
        If Len(WorkspaceJoinDictionaryKeys) > 0 Then WorkspaceJoinDictionaryKeys = WorkspaceJoinDictionaryKeys & ";"
        WorkspaceJoinDictionaryKeys = WorkspaceJoinDictionaryKeys & CStr(keys(i))
    Next i
End Function

Private Function WorkspaceJoinIDs(ByVal firstID As String, ByVal secondID As String) As String
    If Len(firstID) = 0 Then
        WorkspaceJoinIDs = secondID
    ElseIf Len(secondID) = 0 Then
        WorkspaceJoinIDs = firstID
    ElseIf StrComp(firstID, secondID, vbTextCompare) <= 0 Then
        WorkspaceJoinIDs = firstID & ";" & secondID
    Else
        WorkspaceJoinIDs = secondID & ";" & firstID
    End If
End Function

Private Function WorkspacePartyAccount(ByVal personValue As Variant, ByVal relationshipValue As Variant, _
                                       ByVal bankValue As Variant, ByVal branchValue As Variant, _
                                       ByVal typeValue As Variant, ByVal numberValue As Variant) As String
    Dim personText As String, accountText As String
    personText = CellText(personValue)
    If Len(personText) > 0 Then personText = personText & WorkspaceRelationshipSuffix(relationshipValue) & " "
    accountText = Trim$(CellText(bankValue) & " " & CellText(branchValue) & " " & _
                        CellText(typeValue) & " " & CellText(numberValue))
    WorkspacePartyAccount = Trim$(personText & accountText)
End Function

Private Function WorkspaceRelationshipSuffix(ByVal relationshipValue As Variant) As String
    If Len(CellText(relationshipValue)) > 0 Then _
        WorkspaceRelationshipSuffix = "�i" & CellText(relationshipValue) & "�j"
End Function

Private Function WorkspacePeriodText(ByVal firstDate As Variant, ByVal secondDate As Variant) As String
    Dim firstValue As Date, secondValue As Date
    If Not IsDate(firstDate) Or Not IsDate(secondDate) Then
        WorkspacePeriodText = WorkspaceDateText(firstDate) & " �` " & WorkspaceDateText(secondDate)
        Exit Function
    End If
    firstValue = DateSerial(Year(CDate(firstDate)), Month(CDate(firstDate)), Day(CDate(firstDate)))
    secondValue = DateSerial(Year(CDate(secondDate)), Month(CDate(secondDate)), Day(CDate(secondDate)))
    If firstValue = secondValue Then
        WorkspacePeriodText = Format$(firstValue, "yyyy/m/d") & "�i�����j"
    ElseIf firstValue < secondValue Then
        WorkspacePeriodText = Format$(firstValue, "yyyy/m/d") & " �` " & _
                              Format$(secondValue, "yyyy/m/d")
    Else
        WorkspacePeriodText = Format$(secondValue, "yyyy/m/d") & " �` " & _
                              Format$(firstValue, "yyyy/m/d")
    End If
End Function

Private Function WorkspaceDateText(ByVal valueIn As Variant) As String
    If IsDate(valueIn) Then WorkspaceDateText = Format$(CDate(valueIn), "yyyy/m/d") Else WorkspaceDateText = "���t�v�m�F"
End Function

Private Function WorkspaceTimeText(ByVal valueIn As Variant) As String
    Dim timeValue As Double
    If WorkspaceTryTime(valueIn, timeValue) Then
        WorkspaceTimeText = Format$(timeValue, "hh:mm")
    Else
        WorkspaceTimeText = "--:--"
    End If
End Function

Private Function WorkspaceTryTime(ByVal valueIn As Variant, ByRef timeValue As Double) As Boolean
    If IsError(valueIn) Or IsNull(valueIn) Or IsEmpty(valueIn) Then Exit Function
    If VarType(valueIn) = vbString And Len(Trim$(CStr(valueIn))) = 0 Then Exit Function
    If Not IsDate(valueIn) And Not IsNumeric(valueIn) Then Exit Function
    On Error GoTo InvalidTime
    timeValue = CDbl(TimeValue(CDate(valueIn)))
    WorkspaceTryTime = (timeValue >= 0 And timeValue < 1)
    Exit Function
InvalidTime:
    WorkspaceTryTime = False
End Function

Private Function WorkspaceAmountText(ByVal valueIn As Variant) As String
    If IsNumeric(valueIn) Then WorkspaceAmountText = Format$(CDbl(valueIn), "#,##0.########") Else WorkspaceAmountText = "�v�m�F"
End Function

Private Function WorkspaceDouble(ByVal valueIn As Variant) As Double
    If IsError(valueIn) Or IsNull(valueIn) Or IsEmpty(valueIn) Then Exit Function
    If IsNumeric(valueIn) Then WorkspaceDouble = CDbl(valueIn)
End Function

Private Function WorkspaceLong(ByVal valueIn As Variant) As Long
    If IsError(valueIn) Or IsNull(valueIn) Or IsEmpty(valueIn) Then Exit Function
    If IsNumeric(valueIn) Then
        If CDbl(valueIn) >= -2147483648# And CDbl(valueIn) <= 2147483647# Then _
            WorkspaceLong = CLng(valueIn)
    End If
End Function

Private Function WorkspaceStatusOrDefault(ByVal valueIn As Variant) As String
    WorkspaceStatusOrDefault = CellText(valueIn)
    If Len(WorkspaceStatusOrDefault) = 0 Then WorkspaceStatusOrDefault = ANALYSIS_STATUS_UNREVIEWED
End Function

Private Function WorkspaceBlankLabel(ByVal valueIn As Variant) As String
    WorkspaceBlankLabel = CellText(valueIn)
    If Len(WorkspaceBlankLabel) = 0 Then WorkspaceBlankLabel = "�i�󗓁E�����^�̉\���j"
End Function

Private Function WorkspaceAppend(ByVal currentText As String, ByVal newText As String, _
                                 ByVal separatorText As String) As String
    If Len(newText) = 0 Then
        WorkspaceAppend = currentText
    ElseIf Len(currentText) = 0 Then
        WorkspaceAppend = newText
    Else
        WorkspaceAppend = currentText & separatorText & newText
    End If
End Function

Private Function WorkspaceTrimText(ByVal valueIn As String, ByVal maxLength As Long) As String
    If Len(valueIn) <= maxLength Then
        WorkspaceTrimText = valueIn
    Else
        WorkspaceTrimText = Left$(valueIn, maxLength - 14) & "�c�i�����̂��߈ꕔ�\���j"
    End If
End Function

Private Function WorkspaceRateTolerance(ByVal rateCell As Range) As Double
    Dim numericValue As Double
    If rateCell Is Nothing Then Exit Function
    If Not IsNumeric(rateCell.Value) Then Exit Function
    numericValue = CDbl(rateCell.Value)
    If InStr(1, rateCell.NumberFormat, "%", vbBinaryCompare) > 0 Or _
       InStr(1, rateCell.NumberFormatLocal, "%", vbBinaryCompare) > 0 Then
        WorkspaceRateTolerance = numericValue
    Else
        WorkspaceRateTolerance = numericValue / 100#
    End If
End Function

Private Function WorkspaceDigest(ByVal rawText As String) As String
    Dim firstHash As Double, secondHash As Double, i As Long, codeValue As Long
    firstHash = 104729#: secondHash = 130363#
    For i = 1 To Len(rawText)
        codeValue = AscW(Mid$(rawText, i, 1))
        If codeValue < 0 Then codeValue = codeValue + 65536
        firstHash = firstHash * 257# + codeValue + i
        firstHash = firstHash - Fix(firstHash / 2147483629#) * 2147483629#
        secondHash = secondHash * 263# + codeValue + i * 3#
        secondHash = secondHash - Fix(secondHash / 2147483587#) * 2147483587#
    Next i
    WorkspaceDigest = Right$("00000000" & Hex$(CLng(firstHash)), 8) & "-" & _
                      Right$("00000000" & Hex$(CLng(secondHash)), 8)
End Function

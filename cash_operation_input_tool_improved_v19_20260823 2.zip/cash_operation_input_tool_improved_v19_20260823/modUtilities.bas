Attribute VB_Name = "modUtilities"
Option Explicit

Private Const MAX_DETAILED_AUTOFIT_ROWS As Long = 10000
Private Const MAX_READABILITY_SCAN_CELLS As Double = 250000#

Public Function SheetExists(ByVal sheetName As String) As Boolean
    Dim ws As Worksheet
    On Error Resume Next
    Set ws = ThisWorkbook.Worksheets(sheetName)
    SheetExists = Not ws Is Nothing
    On Error GoTo 0
End Function

Public Function GetSheet(ByVal sheetName As String) As Worksheet
    Dim ws As Worksheet
    On Error Resume Next
    Set ws = ThisWorkbook.Worksheets(sheetName)
    On Error GoTo 0
    If ws Is Nothing Then
        Err.Raise vbObjectError + 1001, "GetSheet", "�V�[�g�u" & sheetName & "�v��������܂���BSetupWorkbook�����s���Ă��������B"
    End If
    Set GetSheet = ws
End Function

Public Function GetOrCreateSheet(ByVal sheetName As String, Optional ByVal resetSheet As Boolean = False) As Worksheet
    Dim ws As Worksheet
    On Error GoTo EH
    If SheetExists(sheetName) Then
        Set ws = ThisWorkbook.Worksheets(sheetName)
    Else
        Set ws = ThisWorkbook.Worksheets.Add(After:=ThisWorkbook.Worksheets(ThisWorkbook.Worksheets.Count))
        ws.Name = sheetName
    End If
    If ws Is Nothing Then Err.Raise vbObjectError + 1002, "GetOrCreateSheet", "�V�[�g�擾�Ɏ��s���܂���: " & sheetName
    '�����V�[�g�̕\����Ԃ͌ďo���̈Ӑ}�Ƃ��ĕێ�����B
    '�����ŏ��Visible�֖߂��ƁAW_��ԂȂ�VeryHidden�̓����ۊǂ��ʏ푀�삾���ŘI�o����B
    If resetSheet Then ResetWorksheet ws
    Set GetOrCreateSheet = ws
    Exit Function
EH:
    Err.Raise Err.Number, "GetOrCreateSheet(" & sheetName & ")", Err.Description
End Function

Public Sub ResetWorksheet(ByVal ws As Worksheet)
    Dim errorNumber As Long, errorDescription As String
    If ws Is Nothing Then Exit Sub
    On Error GoTo EH
    ws.Unprotect Password:=TOOL_PASSWORD
    DeleteToolShapes ws, True
    If ws.Shapes.Count > 0 Then
        Err.Raise vbObjectError + 1003, "ResetWorksheet", _
                  "�}�`�������ł��܂���ł���: " & ws.Name
    End If
    ws.Cells.UnMerge
    'Clear�͒l�E�����E�����E���͋K�����܂Ƃ߂ď����BClearFormats�̑S�V�[�g��d�����͕s�v�B
    ws.Cells.Clear
    If LastUsedRowInSheet(ws) > 0 Then
        Err.Raise vbObjectError + 1004, "ResetWorksheet", _
                  "�l�܂��͐������c���Ă��܂�: " & ws.Name
    End If
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    Err.Raise errorNumber, "ResetWorksheet(" & ws.Name & ")", errorDescription
End Sub

Public Sub DeleteToolShapes(ByVal ws As Worksheet, Optional ByVal deleteAll As Boolean = False)
    '�c�[�����쐬�����}�`�������폜����B
    '�}�`�ی��L���ɂ��Ă��邽�߁A�Đ����O�ɂ͕K���ی�������Ă���폜����B
    Dim i As Long
    Dim nm As String
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    ws.Unprotect Password:=TOOL_PASSWORD
    For i = ws.Shapes.Count To 1 Step -1
        nm = ws.Shapes(i).Name
        If deleteAll Or Left$(nm, Len(UI_PREFIX)) = UI_PREFIX Then ws.Shapes(i).Delete
    Next i
    On Error GoTo 0
End Sub

Public Sub DeleteToolShapesVerified(ByVal ws As Worksheet, Optional ByVal deleteAll As Boolean = False)
    Dim shp As Shape
    If ws Is Nothing Then Exit Sub
    DeleteToolShapes ws, deleteAll
    For Each shp In ws.Shapes
        If deleteAll Or Left$(shp.Name, Len(UI_PREFIX)) = UI_PREFIX Then
            Err.Raise vbObjectError + 1005, "DeleteToolShapesVerified", _
                      "�����̑���}�`���폜�ł��܂���ł���: " & ws.Name & " / " & shp.Name
        End If
    Next shp
End Sub

Public Sub LockToolShapes(ByVal ws As Worksheet)
    '�}�`�{�^����J�[�h�w�i������Ĉړ��E�T�C�Y�ύX���Ȃ��悤�ɂ���B
    '�{�^������͌��݂̃u�b�N���֒��蒼���A�����܂ł�K�{�����Ƃ��Č��؂���B
    '�����F�␳�����͐}�`��ʂɂ�藘�p�ł��Ȃ��ꍇ�����邽�߁A���S�ɓǂݔ�΂��B
    Dim shp As Shape
    Dim fillColor As Long
    Dim fontColor As Long
    Dim macroName As String
    Dim printStateKnown As Boolean
    Dim errorNumber As Long, errorDescription As String

    If ws Is Nothing Then Exit Sub
    On Error GoTo EH
    For Each shp In ws.Shapes
        If Left$(shp.Name, Len(UI_PREFIX)) = UI_PREFIX Then
            shp.Locked = True
            If Not shp.Locked Then _
                Err.Raise vbObjectError + 1093, "LockToolShapes", _
                          "����}�`�����b�N�ł��܂���: " & ws.Name & " / " & shp.Name
            shp.Placement = xlMove
            If shp.Placement <> xlMove Then _
                Err.Raise vbObjectError + 1094, "LockToolShapes", _
                          "����}�`�̔z�u�������Œ�ł��܂���: " & ws.Name & " / " & shp.Name
            If Not SetToolShapePrintState(ws, shp.Name, False) Then _
                Err.Raise vbObjectError + 1095, "LockToolShapes", _
                          "����}�`������ΏۊO�ɂł��܂���: " & ws.Name & " / " & shp.Name
            If ToolShapePrintState(ws, shp.Name, printStateKnown) Or Not printStateKnown Then _
                Err.Raise vbObjectError + 1096, "LockToolShapes", _
                          "����}�`�̈���ݒ���m�F�ł��܂���: " & ws.Name & " / " & shp.Name

            If Left$(shp.Name, Len(UI_PREFIX & "btn_")) = UI_PREFIX & "btn_" Then
                macroName = ToolShapeActionName(shp)
                If Len(macroName) = 0 Then _
                    Err.Raise vbObjectError + 1097, "LockToolShapes", _
                              "����{�^���̓��얼������܂���: " & ws.Name & " / " & shp.Name
                shp.OnAction = MacroRef(macroName)
                If StrComp(CellText(shp.OnAction), MacroRef(macroName), vbTextCompare) <> 0 Then _
                    Err.Raise vbObjectError + 1098, "LockToolShapes", _
                              "����{�^���̓�������݂̃u�b�N�֐ݒ�ł��܂���: " & _
                              ws.Name & " / " & shp.Name
            End If

            Err.Clear
            On Error Resume Next
            fillColor = shp.Fill.ForeColor.RGB
            fontColor = shp.TextFrame.Characters.Font.Color
            If IsLightExcelColor(fillColor) And IsLightExcelColor(fontColor) Then
                shp.TextFrame.Characters.Font.Color = RGB(15, 23, 42)
            End If
            Err.Clear
            On Error GoTo EH
        End If
    Next shp
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    Err.Raise errorNumber, "LockToolShapes(" & ws.Name & ")", errorDescription
End Sub

Public Sub VerifyToolShapeSecurity(ByVal ws As Worksheet, _
                                   Optional ByVal requireSheetProtection As Boolean = True)
    '�uLocked�����v�u�V�[�g�ی삾���v�̕Е��ł͌�ړ���h���Ȃ��B
    '���b�N�A�z�u�A�����A���݃u�b�N�ւ�OnAction�A�}�`�ی���܂Ƃ߂Č�������B
    Dim shp As Shape
    Dim macroName As String
    Dim printStateKnown As Boolean
    Dim errorNumber As Long, errorDescription As String
    If ws Is Nothing Then Exit Sub
    On Error GoTo EH

    If requireSheetProtection Then
        If Not ws.ProtectContents Or Not ws.ProtectDrawingObjects Then _
            Err.Raise vbObjectError + 1099, "VerifyToolShapeSecurity", _
                      "�Z���܂��͐}�`�̃V�[�g�ی삪�����ł�: " & ws.Name
    End If

    For Each shp In ws.Shapes
        If Left$(shp.Name, Len(UI_PREFIX)) = UI_PREFIX Then
            If Not shp.Locked Then _
                Err.Raise vbObjectError + 1100, "VerifyToolShapeSecurity", _
                          "����}�`�����b�N����Ă��܂���: " & ws.Name & " / " & shp.Name
            If shp.Placement <> xlMove Then _
                Err.Raise vbObjectError + 1101, "VerifyToolShapeSecurity", _
                          "����}�`�̔z�u�������s���ł�: " & ws.Name & " / " & shp.Name
            If ToolShapePrintState(ws, shp.Name, printStateKnown) Or Not printStateKnown Then _
                Err.Raise vbObjectError + 1102, "VerifyToolShapeSecurity", _
                          "����}�`�̔����ݒ���m�F�ł��܂���: " & ws.Name & " / " & shp.Name
            If Left$(shp.Name, Len(UI_PREFIX & "btn_")) = UI_PREFIX & "btn_" Then
                macroName = ToolShapeActionName(shp)
                If Len(macroName) = 0 Or _
                   StrComp(CellText(shp.OnAction), MacroRef(macroName), vbTextCompare) <> 0 Then _
                    Err.Raise vbObjectError + 1103, "VerifyToolShapeSecurity", _
                              "����{�^���̎��s�悪�s���ł�: " & ws.Name & " / " & shp.Name
            End If
        End If
    Next shp
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    Err.Raise errorNumber, "VerifyToolShapeSecurity(" & ws.Name & ")", errorDescription
End Sub

Public Sub EmergencyProtectToolSheet(ByVal ws As Worksheet)
    '�ʏ�̕ی쏈�����r���Ŏ��s���Ă��A�}�`�𖳖h���Ȃ܂܎c���Ȃ��ŏI�h��B
    Dim shp As Shape
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    ws.Unprotect Password:=TOOL_PASSWORD
    For Each shp In ws.Shapes
        If Left$(shp.Name, Len(UI_PREFIX)) = UI_PREFIX Then
            shp.Locked = True
            shp.Placement = xlMove
            SetToolShapePrintState ws, shp.Name, False
        End If
    Next shp
    ws.Protect Password:=TOOL_PASSWORD, DrawingObjects:=True, Contents:=True, Scenarios:=False, _
               UserInterfaceOnly:=True, AllowFiltering:=True, AllowSorting:=False
    On Error GoTo 0
End Sub

Public Sub ResetName(ByVal nm As String, ByVal rng As Range)
    Dim refText As String
    Dim createdName As Name
    Dim verifyRange As Range
    Dim errorNumber As Long, errorDescription As String
    If rng Is Nothing Then Exit Sub
    On Error Resume Next
    ThisWorkbook.Names(nm).Delete
    Err.Clear
    On Error GoTo EH
    refText = "='" & Replace(rng.Worksheet.Name, "'", "''") & "'!" & rng.Address(True, True, xlA1, False)
    Set createdName = ThisWorkbook.Names.Add(Name:=nm, RefersTo:=refText)
    If createdName Is Nothing Then _
        Err.Raise vbObjectError + 1018, "ResetName", "��`�����쐬�ł��܂���ł���: " & nm
    Set verifyRange = createdName.RefersToRange
    If verifyRange Is Nothing Then _
        Err.Raise vbObjectError + 1019, "ResetName", "��`���̎Q�Ɛ���m�F�ł��܂���: " & nm
    If StrComp(verifyRange.Worksheet.Name, rng.Worksheet.Name, vbTextCompare) <> 0 Or _
       StrComp(verifyRange.Address(True, True, xlA1, False), _
               rng.Address(True, True, xlA1, False), vbTextCompare) <> 0 Then _
        Err.Raise vbObjectError + 1020, "ResetName", "��`���̎Q�Ɛ悪��v���܂���: " & nm
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    Err.Raise errorNumber, "ResetName(" & nm & ")", errorDescription
End Sub

Public Function MacroRef(ByVal macroName As String) As String
    '�}�`�{�^�����ʃu�b�N�̓����}�N�����E��Ȃ��悤�A���̃u�b�N�֖����I�ɕR�Â���B
    MacroRef = "'" & Replace(ThisWorkbook.Name, "'", "''") & "'!" & macroName
End Function

Public Function ToolShapeActionName(ByVal shp As Shape) As String
    '���s���OnAction�𐳂Ƃ��A��փe�L�X�g�͗��p�Ҍ������������Ɏg���B
    '���Ő}�`�̈ڍs�������A�]���ǂ����փe�L�X�g���̃}�N������ǂݎ��B
    Dim actionText As String
    Dim separatorPos As Long
    If shp Is Nothing Then Exit Function
    On Error GoTo LegacyValue
    actionText = Trim$(CellText(shp.OnAction))
    separatorPos = InStrRev(actionText, "!", -1, vbBinaryCompare)
    If separatorPos > 0 Then actionText = Mid$(actionText, separatorPos + 1)
    actionText = Trim$(actionText)
    If Len(actionText) > 0 Then
        ToolShapeActionName = actionText
        Exit Function
    End If
LegacyValue:
    Err.Clear
    On Error Resume Next
    actionText = Trim$(CellText(shp.AlternativeText))
    If InStr(1, actionText, " ", vbBinaryCompare) = 0 And _
       InStr(1, actionText, "�B", vbBinaryCompare) = 0 Then _
        ToolShapeActionName = actionText
    On Error GoTo 0
End Function

Public Sub SetToolShapeAccessibleLabel(ByVal shp As Shape, ByVal caption As String)
    '�X�N���[�����[�_�[�֓����}�N������ǂݏグ���A��ʂƓ������얼��`����B
    If shp Is Nothing Then Exit Sub
    On Error Resume Next
    Err.Clear
    shp.Title = caption & " �{�^��"
    shp.AlternativeText = caption & "�B�N���b�N���Ď��s���܂��B"
    Err.Clear
    On Error GoTo 0
End Sub

Public Sub SetRowValues(ByVal firstCell As Range, ByVal values As Variant)
    '1����Array��Range�֒��ڑ���������������A�������Ɋm���ɏ������ށB
    Dim i As Long
    If firstCell Is Nothing Then Exit Sub
    For i = LBound(values) To UBound(values)
        firstCell.Offset(0, i - LBound(values)).Value = values(i)
    Next i
End Sub

Public Function CompactDeleteDataRows(ByVal ws As Worksheet, ByVal lastColumn As Long, _
                                      ByVal matchColumn As Long, ByVal matchValue As String, _
                                      Optional ByVal secondColumn As Long = 0, _
                                      Optional ByVal secondValue As String = "", _
                                      Optional ByVal deleteWhenSecondEquals As Boolean = True) As Long
    'Rows.Delete����������J��Ԃ����A������ۂ����z��ֈ��k���Ĉꊇ���f����B
    '�������s���͌��z���߂��A�֌W�̂Ȃ������s�܂Ŋ������ގ��̂�h���B
    Dim lastR As Long, sourceRows As Long, keepCount As Long, actualCount As Long
    Dim r As Long, c As Long, writeRow As Long
    Dim sourceData As Variant, outputData() As Variant
    Dim dataRange As Range, formulaCells As Range, errorCells As Range
    Dim deleteRow As Boolean, writeStarted As Boolean
    Dim errorNumber As Long, errorDescription As String, restoreDetail As String
    If ws Is Nothing Then Exit Function
    If lastColumn < 1 Or matchColumn < 1 Or matchColumn > lastColumn Then _
        Err.Raise vbObjectError + 1006, "CompactDeleteDataRows", "�폜�����̗�ԍ����s���ł��B"
    If secondColumn < 0 Or secondColumn > lastColumn Then _
        Err.Raise vbObjectError + 1007, "CompactDeleteDataRows", "��2�폜�����̗�ԍ����s���ł��B"
    matchValue = CellText(matchValue)
    If Len(matchValue) = 0 Then _
        Err.Raise vbObjectError + 1008, "CompactDeleteDataRows", "�폜�����̒l���󗓂ł��B"

    '�L�[�񂾂����󔒂̔j���s���܂߂�B���[�����ƁA���̍s���㏑�����Ă��܂��B
    lastR = LastUsedRowInSheet(ws)
    If lastR < 2 Then Exit Function
    sourceRows = lastR - 1
    If sourceRows > MAX_INTERNAL_STORE_DATA_ROWS Then _
        Err.Raise vbObjectError + 1009, "CompactDeleteDataRows", _
                  "�����f�[�^���ꊇ�����̎��p����i" & Format$(MAX_INTERNAL_STORE_DATA_ROWS, "#,##0") & _
                  "�s�j�𒴂��Ă��܂��B�Č��𕪊����Ă��������B"
    Set dataRange = ws.Range(ws.Cells(2, 1), ws.Cells(lastR, lastColumn))
    On Error Resume Next
    Err.Clear
    Set formulaCells = dataRange.SpecialCells(xlCellTypeFormulas)
    Err.Clear
    On Error GoTo 0
    If Not formulaCells Is Nothing Then _
        Err.Raise vbObjectError + 1010, "CompactDeleteDataRows", _
                  "�����ۊǂɐ��������邽�߁A���S�ȍs�����𒆎~���܂���: " & _
                  ws.Name & " " & formulaCells.Cells(1, 1).Address(False, False)
    On Error Resume Next
    Err.Clear
    Set errorCells = dataRange.SpecialCells(xlCellTypeConstants, xlErrors)
    Err.Clear
    On Error GoTo 0
    If Not errorCells Is Nothing Then _
        Err.Raise vbObjectError + 1025, "CompactDeleteDataRows", _
                  "�����ۊǂ�Excel�G���[�l�����邽�߁A���S�ȍs�����𒆎~���܂���: " & _
                  ws.Name & " " & errorCells.Cells(1, 1).Address(False, False)

    sourceData = dataRange.Value2
    For r = 1 To sourceRows
        deleteRow = (StrComp(CellText(sourceData(r, matchColumn)), matchValue, vbTextCompare) = 0)
        If deleteRow And secondColumn > 0 Then
            If deleteWhenSecondEquals Then
                deleteRow = (StrComp(CellText(sourceData(r, secondColumn)), secondValue, vbTextCompare) = 0)
            Else
                deleteRow = (StrComp(CellText(sourceData(r, secondColumn)), secondValue, vbTextCompare) <> 0)
            End If
        End If
        If deleteRow Then
            CompactDeleteDataRows = CompactDeleteDataRows + 1
        Else
            keepCount = keepCount + 1
        End If
    Next r
    If CompactDeleteDataRows = 0 Then Exit Function

    ReDim outputData(1 To sourceRows, 1 To lastColumn)
    For r = 1 To sourceRows
        deleteRow = (StrComp(CellText(sourceData(r, matchColumn)), matchValue, vbTextCompare) = 0)
        If deleteRow And secondColumn > 0 Then
            If deleteWhenSecondEquals Then
                deleteRow = (StrComp(CellText(sourceData(r, secondColumn)), secondValue, vbTextCompare) = 0)
            Else
                deleteRow = (StrComp(CellText(sourceData(r, secondColumn)), secondValue, vbTextCompare) <> 0)
            End If
        End If
        If Not deleteRow Then
            writeRow = writeRow + 1
            For c = 1 To lastColumn
                outputData(writeRow, c) = sourceData(r, c)
            Next c
        End If
    Next r

    On Error GoTo EH
    writeStarted = True
    dataRange.Value2 = outputData
    lastR = LastUsedRowInSheet(ws)
    If lastR >= 2 Then actualCount = lastR - 1 Else actualCount = 0
    If actualCount <> keepCount Then _
        Err.Raise vbObjectError + 1011, "CompactDeleteDataRows", "�s������̌�������v���܂���B"
    If CountCompactDeleteMatches(ws, matchColumn, matchValue, secondColumn, secondValue, _
                                 deleteWhenSecondEquals) <> 0 Then _
        Err.Raise vbObjectError + 1012, "CompactDeleteDataRows", "�폜�Ώۍs���c���Ă��܂��B"
    Exit Function
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    If writeStarted Then
        On Error Resume Next
        dataRange.Value2 = sourceData
        If Err.Number <> 0 Then restoreDetail = " / ���f�[�^�̕����G���[: " & Err.Description
        On Error GoTo 0
    End If
    Err.Raise errorNumber, "CompactDeleteDataRows(" & ws.Name & ")", errorDescription & restoreDetail
End Function

Private Function CountCompactDeleteMatches(ByVal ws As Worksheet, ByVal matchColumn As Long, _
                                           ByVal matchValue As String, ByVal secondColumn As Long, _
                                           ByVal secondValue As String, _
                                           ByVal deleteWhenSecondEquals As Boolean) As Long
    Dim lastR As Long, r As Long, maxColumn As Long, data As Variant, isMatch As Boolean
    If ws Is Nothing Then Exit Function
    lastR = LastUsedRowInSheet(ws)
    If lastR < 2 Then Exit Function
    maxColumn = CLng(Application.Max(matchColumn, secondColumn))
    If lastR = 2 And maxColumn = 1 Then
        ReDim data(1 To 1, 1 To 1)
        data(1, 1) = ws.Cells(2, 1).Value2
    Else
        data = ws.Range(ws.Cells(2, 1), ws.Cells(lastR, maxColumn)).Value2
    End If
    For r = 1 To UBound(data, 1)
        isMatch = (StrComp(CellText(data(r, matchColumn)), matchValue, vbTextCompare) = 0)
        If isMatch And secondColumn > 0 Then
            If deleteWhenSecondEquals Then
                isMatch = (StrComp(CellText(data(r, secondColumn)), secondValue, vbTextCompare) = 0)
            Else
                isMatch = (StrComp(CellText(data(r, secondColumn)), secondValue, vbTextCompare) <> 0)
            End If
        End If
        If isMatch Then CountCompactDeleteMatches = CountCompactDeleteMatches + 1
    Next r
End Function

Public Function CompactDeleteDataRowsByDictionary(ByVal ws As Worksheet, ByVal lastColumn As Long, _
                                                  ByVal matchColumn As Long, ByVal matchValues As Object) As Long
    '�O���捞�̃��[���o�b�N�p�B�����̓]�L��ID���s�폜�ňꌏ���������A��x�̔z�񈳏k�Ŗ߂��B
    Dim lastR As Long, sourceRows As Long, keepCount As Long, actualCount As Long
    Dim r As Long, c As Long, writeRow As Long
    Dim sourceData As Variant, outputData() As Variant, matchData As Variant
    Dim dataRange As Range, formulaCells As Range, errorCells As Range
    Dim writeStarted As Boolean
    Dim errorNumber As Long, errorDescription As String, restoreDetail As String
    If ws Is Nothing Or matchValues Is Nothing Then Exit Function
    If matchValues.Count = 0 Then Exit Function
    If lastColumn < 1 Or matchColumn < 1 Or matchColumn > lastColumn Then _
        Err.Raise vbObjectError + 1013, "CompactDeleteDataRowsByDictionary", "�폜�����̗�ԍ����s���ł��B"
    lastR = LastUsedRowInSheet(ws)
    If lastR < 2 Then Exit Function
    sourceRows = lastR - 1
    If sourceRows > MAX_INTERNAL_STORE_DATA_ROWS Then _
        Err.Raise vbObjectError + 1014, "CompactDeleteDataRowsByDictionary", _
                  "�����f�[�^���ꊇ�����̎��p����i" & Format$(MAX_INTERNAL_STORE_DATA_ROWS, "#,##0") & _
                  "�s�j�𒴂��Ă��܂��B�Č��𕪊����Ă��������B"
    Set dataRange = ws.Range(ws.Cells(2, 1), ws.Cells(lastR, lastColumn))
    On Error Resume Next
    Err.Clear
    Set formulaCells = dataRange.SpecialCells(xlCellTypeFormulas)
    Err.Clear
    On Error GoTo 0
    If Not formulaCells Is Nothing Then _
        Err.Raise vbObjectError + 1015, "CompactDeleteDataRowsByDictionary", _
                  "�����ۊǂɐ��������邽�߁A���S�ȍs�����𒆎~���܂���: " & _
                  ws.Name & " " & formulaCells.Cells(1, 1).Address(False, False)
    On Error Resume Next
    Err.Clear
    Set errorCells = dataRange.SpecialCells(xlCellTypeConstants, xlErrors)
    Err.Clear
    On Error GoTo 0
    If Not errorCells Is Nothing Then _
        Err.Raise vbObjectError + 1026, "CompactDeleteDataRowsByDictionary", _
                  "�����ۊǂ�Excel�G���[�l�����邽�߁A���S�ȍs�����𒆎~���܂���: " & _
                  ws.Name & " " & errorCells.Cells(1, 1).Address(False, False)
    sourceData = dataRange.Value2
    For r = 1 To sourceRows
        If matchValues.Exists(CellText(sourceData(r, matchColumn))) Then
            CompactDeleteDataRowsByDictionary = CompactDeleteDataRowsByDictionary + 1
        Else
            keepCount = keepCount + 1
        End If
    Next r
    If CompactDeleteDataRowsByDictionary = 0 Then Exit Function
    ReDim outputData(1 To sourceRows, 1 To lastColumn)
    For r = 1 To sourceRows
        If Not matchValues.Exists(CellText(sourceData(r, matchColumn))) Then
            writeRow = writeRow + 1
            For c = 1 To lastColumn
                outputData(writeRow, c) = sourceData(r, c)
            Next c
        End If
    Next r

    On Error GoTo EH
    writeStarted = True
    dataRange.Value2 = outputData
    lastR = LastUsedRowInSheet(ws)
    If lastR >= 2 Then actualCount = lastR - 1 Else actualCount = 0
    If actualCount <> keepCount Then _
        Err.Raise vbObjectError + 1016, "CompactDeleteDataRowsByDictionary", "�s������̌�������v���܂���B"
    If keepCount > 0 Then
        matchData = ws.Range(ws.Cells(2, matchColumn), ws.Cells(lastR, matchColumn)).Value2
        If keepCount = 1 Then
            If matchValues.Exists(CellText(matchData)) Then _
                Err.Raise vbObjectError + 1017, "CompactDeleteDataRowsByDictionary", "�폜�Ώۍs���c���Ă��܂��B"
        Else
            For r = 1 To UBound(matchData, 1)
                If matchValues.Exists(CellText(matchData(r, 1))) Then _
                    Err.Raise vbObjectError + 1017, "CompactDeleteDataRowsByDictionary", "�폜�Ώۍs���c���Ă��܂��B"
            Next r
        End If
    End If
    Exit Function
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    If writeStarted Then
        On Error Resume Next
        dataRange.Value2 = sourceData
        If Err.Number <> 0 Then restoreDetail = " / ���f�[�^�̕����G���[: " & Err.Description
        On Error GoTo 0
    End If
    Err.Raise errorNumber, "CompactDeleteDataRowsByDictionary(" & ws.Name & ")", _
              errorDescription & restoreDetail
End Function

Public Sub CapBalanceCollections(ByRef labels As Collection, ByRef dates As Collection, ByVal maxItems As Long)
    Dim newLabels As Collection
    Dim newDates As Collection
    Dim selected As Object
    Dim inheritDate As Variant
    Dim inheritIndex As Long
    Dim i As Long
    If labels Is Nothing Or dates Is Nothing Then Exit Sub
    If maxItems <= 0 Then Exit Sub
    If labels.Count <= maxItems Then Exit Sub

    '�\������𒴂����ꍇ�́A�Â����_����@�B�I�ɐ؂�̂ł͂Ȃ��A
    '�����J�n�����_�i�ݒ�ς݂̏ꍇ�j�ƒ��߂̔N�����_��D�悵�Ďc���B
    Set selected = CreateObject("Scripting.Dictionary")
    inheritDate = GetCfgDateValue(ROW_CFG_INHERITANCE_DATE)
    If IsDate(inheritDate) Then
        For i = 1 To dates.Count
            If IsDate(dates(i)) Then
                If CLng(CDate(dates(i))) = CLng(CDate(inheritDate)) Then
                    inheritIndex = i
                    Exit For
                End If
            End If
        Next i
        If inheritIndex > 0 Then selected(CStr(inheritIndex)) = True
    End If
    For i = dates.Count To 1 Step -1
        If selected.Count >= maxItems Then Exit For
        selected(CStr(i)) = True
    Next i

    Set newLabels = New Collection
    Set newDates = New Collection
    For i = 1 To labels.Count
        If selected.Exists(CStr(i)) Then
            newLabels.Add labels(i)
            newDates.Add dates(i)
        End If
    Next i
    Set labels = newLabels
    Set dates = newDates
End Sub

Public Function BalanceInputLabelDisplay(ByVal labelText As String) As String
    Dim s As String
    s = CellText(labelText)
    s = Replace(s, "�����J�n�����_�c���i", "�����J�n�����_" & vbLf & "�c���i")
    s = Replace(s, "�N���E�����J�n�����_�c���i", "�N���E�����J�n�����_" & vbLf & "�c���i")
    BalanceInputLabelDisplay = s
End Function

Public Function BalanceTekiyoLabel(ByVal labelText As String) As String
    '��������\�̓E�v���p�B���t���Ɋ�������邽�߁A�E�v���ɂ͋�̓��t���o���Ȃ��B
    Dim s As String
    Dim p As Long
    s = CellText(labelText)
    s = Replace(s, vbCrLf, "")
    s = Replace(s, vbCr, "")
    s = Replace(s, vbLf, "")
    p = InStr(1, s, "�i", vbTextCompare)
    If p > 0 And InStr(1, s, "�c��", vbTextCompare) > 0 Then s = Left$(s, p - 1)
    BalanceTekiyoLabel = s
End Function


Public Sub ApplyReadablePrintSettings(ByVal ws As Worksheet, _
                                      Optional ByVal titleRows As String = "", _
                                      Optional ByVal pagesWide As Long = 1, _
                                      Optional ByVal titleColumns As String = "")
    '��v���[��A4���B�񐔂������c�����ڕ\�����́A�������ׂ�Ȃ��͈͂ŉ�2�`3���֕�����B
    '�ݒ蒼��ɓǂݖ߂��Č��؂��A�v�����^�ˑ��G���[��ق��Č������Ȃ��B
    Dim detailText As String
    Dim errorNumber As Long, errorDescription As String
    If ws Is Nothing Then Exit Sub
    If pagesWide < 1 Then pagesWide = 1
    If pagesWide > 3 Then pagesWide = 3
    On Error GoTo EH
    With ws.PageSetup
        .PaperSize = xlPaperA4
        .Orientation = xlLandscape
        .Zoom = False
        .FitToPagesWide = pagesWide
        .FitToPagesTall = False
        .Order = xlDownThenOver
        .BlackAndWhite = False
        .Draft = False
        .PrintGridlines = False
        .PrintHeadings = False
        .CenterHorizontally = False
        .CenterVertically = False
        .LeftMargin = Application.InchesToPoints(0.25)
        .RightMargin = Application.InchesToPoints(0.25)
        .TopMargin = Application.InchesToPoints(0.35)
        .BottomMargin = Application.InchesToPoints(0.35)
        If Len(titleRows) > 0 Then
            .PrintTitleRows = titleRows
        Else
            .PrintTitleRows = ""
        End If
        If Len(titleColumns) > 0 Then
            .PrintTitleColumns = titleColumns
        Else
            .PrintTitleColumns = ""
        End If
        .CenterFooter = "&P / &N"
    End With
    If Not ReadablePrintSettingsMatch(ws, titleRows, pagesWide, titleColumns, detailText) Then _
        Err.Raise vbObjectError + 1091, "ApplyReadablePrintSettings", detailText
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    Err.Raise errorNumber, "ApplyReadablePrintSettings(" & ws.Name & ")", errorDescription
End Sub

Public Function ReadablePrintSettingsMatch(ByVal ws As Worksheet, _
                                           Optional ByVal titleRows As String = "", _
                                           Optional ByVal pagesWide As Long = 1, _
                                           Optional ByVal titleColumns As String = "", _
                                           Optional ByRef detailText As String = "") As Boolean
    Dim actualRows As String, actualColumns As String
    On Error GoTo EH
    If ws Is Nothing Then
        detailText = "����ݒ�̑ΏۃV�[�g������܂���B"
        Exit Function
    End If
    With ws.PageSetup
        If .PaperSize <> xlPaperA4 Then detailText = "�p���T�C�Y��A4�ł͂���܂���B": Exit Function
        If .Orientation <> xlLandscape Then detailText = "������������ł͂���܂���B": Exit Function
        If .Zoom <> False Then detailText = "����{�������������ɂȂ��Ă��܂���B": Exit Function
        If CLng(.FitToPagesWide) <> pagesWide Then detailText = "�������̈���y�[�W�����݌v�l�ƈقȂ�܂��B": Exit Function
        If .FitToPagesTall <> False Then detailText = "�c������1�y�[�W�ֈ��k����Ă��܂��B": Exit Function
        If .Order <> xlDownThenOver Then detailText = "����������c�����D��ł͂���܂���B": Exit Function
        If .BlackAndWhite Then detailText = "�����������������Ă��܂��B": Exit Function
        If .Draft Then detailText = "�������i���ň������܂��B": Exit Function
        If .PrintGridlines Then detailText = "������ɃO���b�h�����\������܂��B": Exit Function
        If .PrintHeadings Then detailText = "������ɍs��ԍ����\������܂��B": Exit Function
        If .CenterHorizontally Then detailText = "�������̒����z�u���L���ł��B": Exit Function
        If .CenterVertically Then detailText = "�c�����̒����z�u���L���ł��B": Exit Function
        If Abs(CDbl(.LeftMargin) - Application.InchesToPoints(0.25)) > 0.75 Then _
            detailText = "���]�����݌v�l�ƈقȂ�܂��B": Exit Function
        If Abs(CDbl(.RightMargin) - Application.InchesToPoints(0.25)) > 0.75 Then _
            detailText = "�E�]�����݌v�l�ƈقȂ�܂��B": Exit Function
        If Abs(CDbl(.TopMargin) - Application.InchesToPoints(0.35)) > 0.75 Then _
            detailText = "��]�����݌v�l�ƈقȂ�܂��B": Exit Function
        If Abs(CDbl(.BottomMargin) - Application.InchesToPoints(0.35)) > 0.75 Then _
            detailText = "���]�����݌v�l�ƈقȂ�܂��B": Exit Function
        If StrComp(CellText(.CenterFooter), "&P / &N", vbBinaryCompare) <> 0 Then _
            detailText = "�y�[�W�ԍ��̃t�b�^�[���݌v�l�ƈقȂ�܂��B": Exit Function
        actualRows = NormalizePrintTitleAddress(CellText(.PrintTitleRows))
        actualColumns = NormalizePrintTitleAddress(CellText(.PrintTitleColumns))
    End With
    If StrComp(actualRows, NormalizePrintTitleAddress(titleRows), vbTextCompare) <> 0 Then
        detailText = "����^�C�g���s���݌v�l�ƈقȂ�܂��B"
        Exit Function
    End If
    If StrComp(actualColumns, NormalizePrintTitleAddress(titleColumns), vbTextCompare) <> 0 Then
        detailText = "����^�C�g���񂪐݌v�l�ƈقȂ�܂��B"
        Exit Function
    End If
    ReadablePrintSettingsMatch = True
    Exit Function
EH:
    detailText = "����ݒ��ǂݎ��܂���: Err " & CStr(Err.Number) & ": " & Err.Description
    Err.Clear
End Function

Private Function NormalizePrintTitleAddress(ByVal valueIn As String) As String
    Dim resultText As String, bangPosition As Long
    resultText = Trim$(valueIn)
    bangPosition = InStrRev(resultText, "!")
    If bangPosition > 0 Then resultText = Mid$(resultText, bangPosition + 1)
    resultText = Replace(resultText, "=", "")
    resultText = Replace(resultText, "'", "")
    resultText = Replace(resultText, " ", "")
    NormalizePrintTitleAddress = UCase$(resultText)
End Function

Public Sub ApplyPrintAreaVerified(ByVal ws As Worksheet, ByVal printRange As Range)
    Dim expectedAddress As String, actualAddress As String
    Dim errorNumber As Long, errorDescription As String
    On Error GoTo EH
    If ws Is Nothing Or printRange Is Nothing Then Exit Sub
    expectedAddress = printRange.Address(True, True, xlA1, False)
    ws.PageSetup.PrintArea = expectedAddress
    actualAddress = NormalizePrintTitleAddress(CellText(ws.PageSetup.PrintArea))
    If StrComp(actualAddress, NormalizePrintTitleAddress(expectedAddress), vbTextCompare) <> 0 Then _
        Err.Raise vbObjectError + 1092, "ApplyPrintAreaVerified", _
                  "����͈͂��݌v�l�ƈ�v���܂���: " & expectedAddress
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    Err.Raise errorNumber, "ApplyPrintAreaVerified(" & ws.Name & ")", errorDescription
End Sub

Public Function PrintAreaMatches(ByVal ws As Worksheet, ByVal expectedRange As Range, _
                                 Optional ByRef detailText As String = "") As Boolean
    Dim actualAddress As String, expectedAddress As String
    On Error GoTo EH
    If ws Is Nothing Or expectedRange Is Nothing Then
        detailText = "����͈͂̌����Ώۂ�����܂���B"
        Exit Function
    End If
    actualAddress = NormalizePrintTitleAddress(CellText(ws.PageSetup.PrintArea))
    expectedAddress = NormalizePrintTitleAddress(expectedRange.Address(True, True, xlA1, False))
    If StrComp(actualAddress, expectedAddress, vbTextCompare) <> 0 Then
        detailText = "����͈͂��݌v�l�ƈقȂ�܂�: " & CellText(ws.PageSetup.PrintArea)
        Exit Function
    End If
    PrintAreaMatches = True
    Exit Function
EH:
    detailText = "����͈͂�ǂݎ��܂���: Err " & CStr(Err.Number) & ": " & Err.Description
    Err.Clear
End Function

Public Function ReadableOutputRowHeight(ByVal textValue As String, _
                                        Optional ByVal minimumHeight As Double = 30, _
                                        Optional ByVal maximumHeight As Double = 120, _
                                        Optional ByVal displayUnitsPerLine As Long = 32) As Double
    '���{��̑S�p�����𔼊p�����Ɠ���1�����Ő�����ƁA�������̍s�����ߏ��]������B
    '�\�����P�ʂŐܕԂ��s�������ς���A�E�v���̒������Œ荂�Ő؂�Ȃ��B
    Dim logicalLines As Long
    Dim estimatedHeight As Double
    logicalLines = ReadableTextLineCount(textValue, displayUnitsPerLine)
    If logicalLines < 1 Then logicalLines = 1
    estimatedHeight = 15# * CDbl(logicalLines)
    If estimatedHeight < minimumHeight Then estimatedHeight = minimumHeight
    If estimatedHeight > maximumHeight Then estimatedHeight = maximumHeight
    ReadableOutputRowHeight = estimatedHeight
End Function

Public Function ReadableTextLineCount(ByVal textValue As String, _
                                      Optional ByVal displayUnitsPerLine As Long = 32) As Long
    Dim normalizedText As String, lines As Variant, item As Variant
    Dim units As Long, wrappedLines As Long
    If displayUnitsPerLine < 1 Then displayUnitsPerLine = 1
    normalizedText = Replace(textValue, vbCrLf, vbLf)
    normalizedText = Replace(normalizedText, vbCr, vbLf)
    lines = Split(normalizedText, vbLf)
    For Each item In lines
        units = TextDisplayUnits(CStr(item))
        If units < 1 Then
            wrappedLines = wrappedLines + 1
        Else
            wrappedLines = wrappedLines + _
                           ((units + displayUnitsPerLine - 1) \ displayUnitsPerLine)
        End If
    Next item
    If wrappedLines < 1 Then wrappedLines = 1
    ReadableTextLineCount = wrappedLines
End Function

Public Function TextDisplayUnits(ByVal textValue As String) As Long
    'ASCII�E���p�J�i��1�A���̑��̑S�p������2�Ƃ��ĊT�Z����B
    Dim i As Long, codePoint As Long
    For i = 1 To Len(textValue)
        codePoint = AscW(Mid$(textValue, i, 1))
        If codePoint < 0 Then codePoint = codePoint + 65536
        If (codePoint >= 32 And codePoint <= 126) Or _
           (codePoint >= 65377 And codePoint <= 65439) Then
            TextDisplayUnits = TextDisplayUnits + 1
        Else
            TextDisplayUnits = TextDisplayUnits + 2
        End If
    Next i
End Function

Public Sub FormatCashOperationOutputLayout(ByVal ws As Worksheet)
    Dim lastR As Long
    Dim rng As Range
    Dim r As Long, recordType As String, tekiyoText As String
    Dim recordTypes As Variant, tekiyoValues As Variant
    Dim errorNumber As Long, errorDescription As String
    If ws Is Nothing Then Exit Sub
    On Error GoTo EH
    lastR = LastUsedRowInSheet(ws)
    If lastR < 1 Then lastR = 1

    Set rng = ws.Range("A1:M" & lastR)
    With rng
        .Font.Name = "Meiryo UI"
        .Font.Size = 11.5
        .Font.Color = RGB(15, 23, 42)
        .Font.Bold = False
        .VerticalAlignment = xlCenter
        .Borders.LineStyle = xlContinuous
        .Borders.Color = RGB(226, 232, 240)
    End With

    FormatOutputHeader ws.Range("A1:M1")
    ws.Rows(1).RowHeight = 34

    ws.Columns("A:A").ColumnWidth = 20
    ws.Columns("B:B").ColumnWidth = 20
    ws.Columns("C:C").ColumnWidth = 18
    ws.Columns("D:D").ColumnWidth = 12
    ws.Columns("E:E").ColumnWidth = 17
    ws.Columns("F:F").ColumnWidth = 19
    ws.Columns("G:G").ColumnWidth = 11
    ws.Columns("H:I").ColumnWidth = 14
    ws.Columns("J:J").ColumnWidth = 20
    ws.Columns("K:K").ColumnWidth = 11
    ws.Columns("L:L").ColumnWidth = 26
    ws.Columns("M:M").ColumnWidth = 17

    ws.Range("A1:G" & CStr(lastR)).HorizontalAlignment = xlCenter
    ws.Range("J1:K" & CStr(lastR)).HorizontalAlignment = xlCenter
    ws.Range("H1:I" & CStr(lastR)).HorizontalAlignment = xlRight
    ws.Range("L1:L" & CStr(lastR)).HorizontalAlignment = xlLeft
    ws.Range("M1:M" & CStr(lastR)).HorizontalAlignment = xlRight
    ws.Range("A1:M" & CStr(lastR)).VerticalAlignment = xlCenter
    ws.Range("L1:M" & CStr(lastR)).WrapText = True

    '��P�ʂ̔z�u�ݒ�̓w�b�_�[�̒����������㏑�����邽�߁A�Ō�Ƀw�b�_�[�����ēK�p����B
    FormatOutputHeader ws.Range("A1:M1")
    With ws.Range("A1:M1")
        .HorizontalAlignment = xlCenter
        .VerticalAlignment = xlCenter
        .WrapText = False
    End With

    ws.Range("F1:F" & CStr(lastR)).NumberFormatLocal = "yyyy/m/d"
    ws.Range("G1:G" & CStr(lastR)).NumberFormatLocal = "hh:mm"
    ws.Range("H1:I" & CStr(lastR)).NumberFormatLocal = "#,##0.########"
    ws.Range("M1:M" & CStr(lastR)).NumberFormatLocal = "#,##0.########"

    If lastR >= 2 Then
        ws.Rows("2:" & lastR).RowHeight = 30
        If lastR = 2 Then
            ReDim recordTypes(1 To 1, 1 To 1)
            ReDim tekiyoValues(1 To 1, 1 To 1)
            recordTypes(1, 1) = ws.Cells(2, OUT_COL_RECORD_TYPE).Value2
            tekiyoValues(1, 1) = ws.Cells(2, OUT_COL_TEKIYO).Value2
        Else
            recordTypes = ws.Range(ws.Cells(2, OUT_COL_RECORD_TYPE), ws.Cells(lastR, OUT_COL_RECORD_TYPE)).Value2
            tekiyoValues = ws.Range(ws.Cells(2, OUT_COL_TEKIYO), ws.Cells(lastR, OUT_COL_TEKIYO)).Value2
        End If
        '�c���s�͓E�v���������ɂ��A�s�S�̂����₷������B
        For r = 2 To lastR
            recordType = CellText(recordTypes(r - 1, 1))
            tekiyoText = CellText(tekiyoValues(r - 1, 1))
            If recordType = RECORD_BALANCE Or (Len(recordType) = 0 And InStr(1, tekiyoText, "�c��", vbTextCompare) > 0) Then
                ws.Cells(r, OUT_COL_TEKIYO).Value = BalanceTekiyoLabel(tekiyoText)
                ws.Cells(r, OUT_COL_TEKIYO).HorizontalAlignment = xlCenter
                ws.Cells(r, OUT_COL_OTHER).HorizontalAlignment = xlRight
                ws.Rows(r).RowHeight = Application.Max(30, ReadableOutputRowHeight(tekiyoText, 30, 120))
                ws.Range("A" & r & ":M" & r).Interior.Color = RGB(220, 252, 231)
                ws.Range("A" & r & ":M" & r).Font.Color = RGB(22, 101, 52)
            ElseIf recordType = RECORD_INHERITANCE Or tekiyoText = "�����J�n��" Then
                ws.Range("A" & r & ":M" & r).Interior.Color = RGB(254, 243, 199)
                ws.Range("A" & r & ":M" & r).Font.Color = RGB(146, 64, 14)
                ws.Range("A" & r & ":M" & r).Font.Bold = True
                '���t���͑������ƕ��s���� ##### �ɂȂ�₷���B�s�͐F�ŋ������A���t�Z�������ʏ푾���ɖ߂��B
                ws.Cells(r, OUT_COL_DATE).Font.Bold = False
                ws.Cells(r, OUT_COL_DATE).HorizontalAlignment = xlCenter
                ws.Cells(r, OUT_COL_TEKIYO).HorizontalAlignment = xlCenter
                ws.Rows(r).RowHeight = 32
            ElseIf recordType = RECORD_OPEN Or recordType = RECORD_CLOSE Or _
                   tekiyoText = "�����J�ݓ�" Or tekiyoText = "��������" Then
                ws.Range("A" & r & ":M" & r).Interior.Color = RGB(219, 234, 254)
                ws.Range("A" & r & ":M" & r).Font.Color = RGB(30, 64, 175)
            ElseIf Len(tekiyoText) > 32 Or InStr(1, tekiyoText, vbLf, vbBinaryCompare) > 0 Or _
                   InStr(1, tekiyoText, vbCr, vbBinaryCompare) > 0 Then
                ws.Rows(r).RowHeight = ReadableOutputRowHeight(tekiyoText, 30, 120)
            End If
        Next r
    End If

    ws.ScrollArea = "A1:M" & CStr(Application.Max(50, lastR + 20))
    ApplyPrintAreaVerified ws, rng
    ApplyReadablePrintSettings ws, "$1:$1"
    FixUnreadableWhiteTextOnSheet ws
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    Err.Raise errorNumber, "FormatCashOperationOutputLayout", errorDescription
End Sub


Public Sub FormatBalanceTransitionOutputLayout(ByVal ws As Worksheet)
    Dim lastR As Long, lastC As Long
    Dim r As Long, c As Long
    Dim fullRange As Range, rowRange As Range
    Dim isDataRow As Boolean, firstText As String
    Dim layoutData As Variant, rowKinds() As Byte
    Dim largeLayout As Boolean
    Dim errorNumber As Long, errorDescription As String
    Dim printPagesWide As Long
    If ws Is Nothing Then Exit Sub
    On Error GoTo EH

    lastR = LastUsedRowInSheet(ws)
    lastC = LastUsedColumnInSheet(ws, lastR)
    If lastR < 1 Then Exit Sub
    If lastC < 7 Then lastC = 7

    Set fullRange = ws.Range(ws.Cells(1, 1), ws.Cells(lastR, lastC))
    layoutData = fullRange.Value2
    ReDim rowKinds(1 To lastR)
    For r = 1 To lastR
        firstText = CellText(layoutData(r, 1))
        If Left$(firstText, 3) = "����:" Or Left$(firstText, 3) = "�����F" Then
            rowKinds(r) = 1
        ElseIf firstText = "��s��" Then
            rowKinds(r) = 2
        ElseIf firstText = "���m�F������" Then
            rowKinds(r) = 3
        ElseIf firstText = "���v" Then
            rowKinds(r) = 4
        ElseIf firstText = "�O���_��" Then
            rowKinds(r) = 5
        Else
            isDataRow = False
            For c = 1 To lastC
                If HasText(layoutData(r, c)) Then isDataRow = True: Exit For
            Next c
            If isDataRow Then rowKinds(r) = 6
        End If
    Next r
    largeLayout = (lastR > MAX_DETAILED_AUTOFIT_ROWS)
    With fullRange
        .Font.Name = "Meiryo UI"
        .Font.Size = 11.5
        .Font.Color = RGB(30, 41, 59)
        .Font.Bold = False
        .VerticalAlignment = xlCenter
        .Interior.Pattern = xlSolid
        .Interior.Color = RGB(255, 255, 255)
        .Borders.LineStyle = xlNone
    End With

    '�^�C�g���́A�\�{�̂ƍ�����Ȃ��悤���������ŋ�؂�B
    With ws.Range(ws.Cells(1, 1), ws.Cells(1, lastC))
        .Interior.Color = RGB(248, 250, 252)
        .Borders(xlEdgeBottom).LineStyle = xlContinuous
        .Borders(xlEdgeBottom).Color = RGB(59, 130, 246)
        .Borders(xlEdgeBottom).Weight = xlMedium
    End With
    With ws.Cells(1, 1)
        .Font.Bold = True
        .Font.Size = 17
        .Font.Color = RGB(30, 64, 175)
        .HorizontalAlignment = xlLeft
    End With
    ws.Rows(1).RowHeight = 34

    If largeLayout Then
        FormatLargeBalanceRows ws, lastR, lastC, rowKinds, layoutData
    Else
        For r = 2 To lastR
            Set rowRange = ws.Range(ws.Cells(r, 1), ws.Cells(r, lastC))

            If rowKinds(r) = 1 Then
                With rowRange
                .Interior.Color = RGB(239, 246, 255)
                .Font.Bold = True
                .Font.Color = RGB(30, 64, 175)
                .Borders(xlEdgeTop).LineStyle = xlContinuous
                .Borders(xlEdgeTop).Color = RGB(147, 197, 253)
                .Borders(xlEdgeTop).Weight = xlMedium
                .Borders(xlEdgeBottom).LineStyle = xlContinuous
                .Borders(xlEdgeBottom).Color = RGB(191, 219, 254)
                .Borders(xlEdgeBottom).Weight = xlMedium
                End With
                ws.Cells(r, 1).HorizontalAlignment = xlLeft
                If ws.Rows(r).RowHeight < 34 Then ws.Rows(r).RowHeight = 34

            ElseIf rowKinds(r) = 2 Then
                With rowRange
                .Interior.Color = RGB(30, 64, 175)
                .Font.Bold = True
                .Font.Color = RGB(255, 255, 255)
                .HorizontalAlignment = xlCenter
                .VerticalAlignment = xlCenter
                .WrapText = True
                .ShrinkToFit = False
                .Borders.LineStyle = xlContinuous
                .Borders.Color = RGB(30, 64, 175)
                .Borders.Weight = xlThin
                .Borders(xlEdgeTop).Weight = xlMedium
                .Borders(xlEdgeBottom).Weight = xlMedium
                End With
                '�����J�n�����_�c���Ȃ�2�s�\���̌��o�����B��Ȃ��悤���߂ɌŒ�B
                ws.Rows(r).RowHeight = 72

            ElseIf rowKinds(r) = 3 Then
                With rowRange
                .Interior.Color = RGB(254, 249, 195)
                .Font.Bold = True
                .Font.Color = RGB(133, 77, 14)
                .Borders.LineStyle = xlContinuous
                .Borders.Color = RGB(253, 224, 71)
                .Borders.Weight = xlThin
                End With
                If ws.Rows(r).RowHeight < 30 Then ws.Rows(r).RowHeight = 30

            ElseIf rowKinds(r) = 4 Then
                With rowRange
                .Interior.Color = RGB(220, 252, 231)
                .Font.Bold = True
                .Font.Color = RGB(22, 101, 52)
                .Borders.LineStyle = xlContinuous
                .Borders.Color = RGB(187, 247, 208)
                .Borders.Weight = xlThin
                .Borders(xlEdgeTop).Color = RGB(34, 197, 94)
                .Borders(xlEdgeTop).Weight = xlMedium
                End With
                If ws.Rows(r).RowHeight < 32 Then ws.Rows(r).RowHeight = 32

            ElseIf rowKinds(r) = 5 Then
                With rowRange
                .Interior.Color = RGB(241, 245, 249)
                .Font.Bold = True
                .Font.Color = RGB(51, 65, 85)
                .Borders.LineStyle = xlContinuous
                .Borders.Color = RGB(226, 232, 240)
                .Borders.Weight = xlThin
                .Borders(xlEdgeBottom).Color = RGB(148, 163, 184)
                .Borders(xlEdgeBottom).Weight = xlMedium
                End With
                If ws.Rows(r).RowHeight < 31 Then ws.Rows(r).RowHeight = 31

            Else
                If rowKinds(r) = 6 Then
                    If r Mod 2 = 0 Then
                        rowRange.Interior.Color = RGB(255, 255, 255)
                    Else
                        rowRange.Interior.Color = RGB(248, 250, 252)
                    End If
                    With rowRange.Borders
                        .LineStyle = xlContinuous
                        .Color = RGB(226, 232, 240)
                        .Weight = xlThin
                    End With
                    FormatNonexistentBalanceCells ws, r, layoutData, 7, lastC - 1
                    If ws.Rows(r).RowHeight < 30 Then ws.Rows(r).RowHeight = 30
                Else
                    '�l���Ɛl���̊Ԃ̋󔒍s�ɂ͌r������؎c���Ȃ��B
                    rowRange.Borders.LineStyle = xlNone
                    rowRange.Interior.Color = RGB(255, 255, 255)
                    ws.Rows(r).RowHeight = 12
                End If
            End If
        Next r
    End If

    '�񕝁E�z�u�B�������A�c���A������3�u���b�N��������悤�ɂ���B
    ws.Columns("A:A").ColumnWidth = 22
    ws.Columns("B:B").ColumnWidth = 22
    ws.Columns("C:C").ColumnWidth = 14
    ws.Columns("D:D").ColumnWidth = 18
    ws.Columns("E:F").ColumnWidth = 16
    For c = 7 To lastC - 1
        ws.Columns(c).ColumnWidth = 22
        ws.Range(ws.Cells(1, c), ws.Cells(lastR, c)).NumberFormatLocal = "#,##0.########"
        ws.Range(ws.Cells(1, c), ws.Cells(lastR, c)).WrapText = True
    Next c
    ws.Columns(lastC).ColumnWidth = 48

    ws.Range(ws.Cells(1, 1), ws.Cells(lastR, lastC)).VerticalAlignment = xlCenter
    ws.Range(ws.Cells(1, 1), ws.Cells(lastR, 6)).HorizontalAlignment = xlCenter
    If lastC > 7 Then ws.Range(ws.Cells(1, 7), ws.Cells(lastR, lastC - 1)).HorizontalAlignment = xlRight
    ws.Range(ws.Cells(1, lastC), ws.Cells(lastR, lastC)).HorizontalAlignment = xlLeft
    ws.Range(ws.Cells(1, lastC), ws.Cells(lastR, lastC)).WrapText = True
    ws.Range(ws.Cells(1, 1), ws.Cells(lastR, 6)).NumberFormatLocal = "@"
    ws.Range(ws.Cells(1, 5), ws.Cells(lastR, 6)).NumberFormatLocal = "yyyy/m/d"

    '�c��؂���̓V�[�g�S�̂ɂ͈����Ȃ��B
    '�e�l���u���b�N�̃w�b�_�[�s����O���_��s�܂ł����ɓK�p���A�󔒍s�ɂ͎c���Ȃ��B
    If Not largeLayout Then ApplyBalanceTransitionBlockBorders ws, lastR, lastC, rowKinds

    '���̑����̒��������؂�Ȃ��悤�A�񕝊m�ی��AutoFit�B�������傫���Ȃ肷���Ȃ��悤�����݂���B
    If Not largeLayout Then
        ws.Range(ws.Cells(2, 1), ws.Cells(lastR, lastC)).Rows.AutoFit
        For r = 2 To lastR
            If rowKinds(r) = 2 Then
                ws.Rows(r).RowHeight = 72
            ElseIf rowKinds(r) = 1 Then
                If ws.Rows(r).RowHeight < 34 Then ws.Rows(r).RowHeight = 34
            ElseIf rowKinds(r) = 4 Then
                If ws.Rows(r).RowHeight < 32 Then ws.Rows(r).RowHeight = 32
            ElseIf rowKinds(r) = 5 Then
                If ws.Rows(r).RowHeight < 31 Then ws.Rows(r).RowHeight = 31
            ElseIf rowKinds(r) = 0 Then
                ws.Rows(r).RowHeight = 12
                ws.Range(ws.Cells(r, 1), ws.Cells(r, lastC)).Borders.LineStyle = xlNone
            ElseIf ws.Rows(r).RowHeight < 30 Then
                ws.Rows(r).RowHeight = 30
            End If
            If ws.Rows(r).RowHeight > 130 Then ws.Rows(r).RowHeight = 130
        Next r
    End If

    ws.Cells(1, 1).HorizontalAlignment = xlLeft

    '�w�b�_�[�s�͗�z�u�EAutoFit�̌�ɍēK�p�B��P�ʐݒ�ɕ����Ȃ��悤�ɂ���B
    If largeLayout Then
        ReapplyLargeBalanceSpecialAlignment ws, lastR, lastC, rowKinds
    Else
        For r = 2 To lastR
            If rowKinds(r) = 1 Then ws.Cells(r, 1).HorizontalAlignment = xlLeft
            If rowKinds(r) = 2 Then
                With ws.Range(ws.Cells(r, 1), ws.Cells(r, lastC))
                    .HorizontalAlignment = xlCenter
                    .VerticalAlignment = xlCenter
                    .WrapText = True
                    .ShrinkToFit = False
                End With
                ws.Rows(r).RowHeight = 72
            End If
        Next r
    End If

    FixUnreadableWhiteTextOnSheet ws
    ws.ScrollArea = "A1:" & ExcelColumnLetter(lastC) & _
                    CStr(Application.Max(50, lastR + 20))

    '���t�񂪑�������1���։������ނƔ��Ǖs�\�ɂȂ邽�߁A����������e�y�[�W�֌J��Ԃ��B
    If lastC <= 14 Then
        printPagesWide = 1
    ElseIf lastC <= 21 Then
        printPagesWide = 2
    Else
        printPagesWide = 3
    End If
    ApplyPrintAreaVerified ws, fullRange
    ApplyReadablePrintSettings ws, "", printPagesWide, "$A:$F"
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    Err.Raise errorNumber, "FormatBalanceTransitionOutputLayout", errorDescription
End Sub

Private Sub FormatLargeBalanceRows(ByVal ws As Worksheet, ByVal lastR As Long, _
                                   ByVal lastC As Long, ByRef rowKinds() As Byte, _
                                   ByRef layoutData As Variant)
    '��ʍs�ōs�P�ʂ�COM�ďo��AutoFit���J��Ԃ��Ǝ��p���Ԃ𒴂��邽�߁A
    '�����s��ʂ�Z�������͈֑͂��˂ď����ݒ肷��B
    Dim addresses(0 To 9) As String
    Dim counts(0 To 9) As Long
    Dim r As Long, c As Long, styleKind As Long, i As Long
    Dim rowAddress As String, cellAddress As String, lastColumnLetter As String
    Dim styleMissingCells As Boolean
    If ws Is Nothing Or lastR < 2 Or lastC < 1 Then Exit Sub
    lastColumnLetter = ExcelColumnLetter(lastC)
    styleMissingCells = (CDbl(lastR) * CDbl(lastC) <= MAX_READABILITY_SCAN_CELLS)

    For r = 2 To lastR
        styleKind = CLng(rowKinds(r))
        If styleKind = 6 Then
            If r Mod 2 = 0 Then styleKind = 7 Else styleKind = 8
        End If
        rowAddress = "A" & CStr(r) & ":" & lastColumnLetter & CStr(r)
        QueueBalanceStyleAddress ws, addresses, counts, styleKind, rowAddress

        If styleMissingCells And rowKinds(r) = 6 Then
            For c = 7 To lastC - 1
                If CellText(layoutData(r, c)) = "-" Then
                    cellAddress = ExcelColumnLetter(c) & CStr(r)
                    QueueBalanceStyleAddress ws, addresses, counts, 9, cellAddress
                End If
            Next c
        End If
    Next r
    For i = LBound(addresses) To UBound(addresses)
        FlushBalanceStyleAddress ws, addresses, counts, i
    Next i
End Sub

Private Sub QueueBalanceStyleAddress(ByVal ws As Worksheet, ByRef addresses() As String, _
                                     ByRef counts() As Long, ByVal styleKind As Long, _
                                     ByVal rangeAddress As String)
    If styleKind < LBound(addresses) Or styleKind > UBound(addresses) Then Exit Sub
    If Len(addresses(styleKind)) > 0 Then addresses(styleKind) = addresses(styleKind) & ","
    addresses(styleKind) = addresses(styleKind) & rangeAddress
    counts(styleKind) = counts(styleKind) + 1
    'Range������̊���������A200������Ŋm���Ƀt���b�V������B
    If counts(styleKind) >= 40 Or Len(addresses(styleKind)) >= 180 Then _
        FlushBalanceStyleAddress ws, addresses, counts, styleKind
End Sub

Private Sub FlushBalanceStyleAddress(ByVal ws As Worksheet, ByRef addresses() As String, _
                                     ByRef counts() As Long, ByVal styleKind As Long)
    Dim target As Range
    If ws Is Nothing Then Exit Sub
    If Len(addresses(styleKind)) = 0 Then Exit Sub
    Set target = ws.Range(addresses(styleKind))
    Select Case styleKind
        Case 0
            target.Interior.Color = RGB(255, 255, 255)
            target.Borders.LineStyle = xlNone
            target.EntireRow.RowHeight = 12
        Case 1
            target.Interior.Color = RGB(239, 246, 255)
            target.Font.Bold = True
            target.Font.Color = RGB(30, 64, 175)
            target.Borders.LineStyle = xlContinuous
            target.Borders.Color = RGB(191, 219, 254)
            target.Borders.Weight = xlThin
            target.EntireRow.RowHeight = 34
        Case 2
            target.Interior.Color = RGB(30, 64, 175)
            target.Font.Bold = True
            target.Font.Color = RGB(255, 255, 255)
            target.HorizontalAlignment = xlCenter
            target.VerticalAlignment = xlCenter
            target.WrapText = True
            target.ShrinkToFit = False
            target.Borders.LineStyle = xlContinuous
            target.Borders.Color = RGB(30, 64, 175)
            target.Borders.Weight = xlThin
            target.EntireRow.RowHeight = 72
        Case 3
            target.Interior.Color = RGB(254, 249, 195)
            target.Font.Bold = True
            target.Font.Color = RGB(133, 77, 14)
            target.Borders.LineStyle = xlContinuous
            target.Borders.Color = RGB(253, 224, 71)
            target.Borders.Weight = xlThin
            target.EntireRow.RowHeight = 30
        Case 4
            target.Interior.Color = RGB(220, 252, 231)
            target.Font.Bold = True
            target.Font.Color = RGB(22, 101, 52)
            target.Borders.LineStyle = xlContinuous
            target.Borders.Color = RGB(187, 247, 208)
            target.Borders.Weight = xlThin
            target.EntireRow.RowHeight = 32
        Case 5
            target.Interior.Color = RGB(241, 245, 249)
            target.Font.Bold = True
            target.Font.Color = RGB(51, 65, 85)
            target.Borders.LineStyle = xlContinuous
            target.Borders.Color = RGB(226, 232, 240)
            target.Borders.Weight = xlThin
            target.EntireRow.RowHeight = 31
        Case 7, 8
            If styleKind = 7 Then
                target.Interior.Color = RGB(255, 255, 255)
            Else
                target.Interior.Color = RGB(248, 250, 252)
            End If
            target.Borders.LineStyle = xlContinuous
            target.Borders.Color = RGB(226, 232, 240)
            target.Borders.Weight = xlThin
            target.EntireRow.RowHeight = 30
        Case 9
            target.Interior.Color = RGB(243, 244, 246)
            target.Font.Color = RGB(100, 116, 139)
            target.HorizontalAlignment = xlCenter
            target.NumberFormatLocal = "@"
            target.Borders.Color = RGB(209, 213, 219)
    End Select
    addresses(styleKind) = ""
    counts(styleKind) = 0
End Sub

Private Sub ReapplyLargeBalanceSpecialAlignment(ByVal ws As Worksheet, ByVal lastR As Long, _
                                                ByVal lastC As Long, ByRef rowKinds() As Byte)
    Dim personAddresses As String, headerAddresses As String
    Dim personCount As Long, headerCount As Long, r As Long
    Dim rowAddress As String, lastColumnLetter As String
    If ws Is Nothing Then Exit Sub
    lastColumnLetter = ExcelColumnLetter(lastC)
    For r = 2 To lastR
        If rowKinds(r) = 1 Then
            If Len(personAddresses) > 0 Then personAddresses = personAddresses & ","
            personAddresses = personAddresses & "A" & CStr(r)
            personCount = personCount + 1
            If personCount >= 40 Or Len(personAddresses) >= 180 Then
                ws.Range(personAddresses).HorizontalAlignment = xlLeft
                personAddresses = "": personCount = 0
            End If
        ElseIf rowKinds(r) = 2 Then
            rowAddress = "A" & CStr(r) & ":" & lastColumnLetter & CStr(r)
            If Len(headerAddresses) > 0 Then headerAddresses = headerAddresses & ","
            headerAddresses = headerAddresses & rowAddress
            headerCount = headerCount + 1
            If headerCount >= 40 Or Len(headerAddresses) >= 180 Then
                With ws.Range(headerAddresses)
                    .HorizontalAlignment = xlCenter
                    .VerticalAlignment = xlCenter
                    .WrapText = True
                    .ShrinkToFit = False
                    .EntireRow.RowHeight = 72
                End With
                headerAddresses = "": headerCount = 0
            End If
        End If
    Next r
    If Len(personAddresses) > 0 Then ws.Range(personAddresses).HorizontalAlignment = xlLeft
    If Len(headerAddresses) > 0 Then
        With ws.Range(headerAddresses)
            .HorizontalAlignment = xlCenter
            .VerticalAlignment = xlCenter
            .WrapText = True
            .ShrinkToFit = False
            .EntireRow.RowHeight = 72
        End With
    End If
End Sub

Private Function ExcelColumnLetter(ByVal columnNumber As Long) As String
    Dim remainder As Long
    If columnNumber < 1 Then Exit Function
    Do While columnNumber > 0
        remainder = (columnNumber - 1) Mod 26
        ExcelColumnLetter = Chr$(65 + remainder) & ExcelColumnLetter
        columnNumber = (columnNumber - remainder - 1) \ 26
    Loop
End Function

Private Sub ApplyBalanceTransitionBlockBorders(ByVal ws As Worksheet, ByVal lastR As Long, _
                                               ByVal lastC As Long, ByRef rowKinds() As Byte)
    Dim headerR As Long, endR As Long, r As Long, scanR As Long
    If ws Is Nothing Or lastR < 2 Or lastC < 7 Then Exit Sub

    r = 2
    Do While r <= lastR
        If rowKinds(r) = 2 Then
            headerR = r
            endR = lastR
            For scanR = headerR + 1 To lastR
                If rowKinds(scanR) = 0 Or rowKinds(scanR) = 1 Then
                    endR = scanR - 1
                    Exit For
                End If
            Next scanR

            If endR >= headerR Then
                With ws.Range(ws.Cells(headerR, 6), ws.Cells(endR, 6)).Borders(xlEdgeRight)
                    .LineStyle = xlContinuous
                    .Color = RGB(59, 130, 246)
                    .Weight = xlMedium
                End With
                If lastC >= 8 Then
                    With ws.Range(ws.Cells(headerR, lastC - 1), ws.Cells(endR, lastC - 1)).Borders(xlEdgeRight)
                        .LineStyle = xlContinuous
                        .Color = RGB(59, 130, 246)
                        .Weight = xlMedium
                    End With
                    With ws.Range(ws.Cells(headerR, 7), ws.Cells(endR, lastC - 1)).Borders(xlInsideVertical)
                        .LineStyle = xlContinuous
                        .Color = RGB(219, 234, 254)
                        .Weight = xlHairline
                    End With
                End If
            End If
            r = endR + 1
        Else
            r = r + 1
        End If
    Loop
End Sub

Private Sub FormatNonexistentBalanceCells(ByVal ws As Worksheet, ByVal rowNo As Long, _
                                          ByRef layoutData As Variant, _
                                          ByVal firstBalanceCol As Long, ByVal lastBalanceCol As Long)
    '�c�����ڕ\�ł́A�����J�ݓ��O�E������̊�����u-�v�ŕ\������B
    '�����̋󗓂ł͂Ȃ������h��ɂ��āA���������݂��Ȃ����Ԃ��ƈ�ڂŕ�����悤�ɂ���B
    Dim c As Long
    If ws Is Nothing Then Exit Sub
    If lastBalanceCol < firstBalanceCol Then Exit Sub
    For c = firstBalanceCol To lastBalanceCol
        If CellText(layoutData(rowNo, c)) = "-" Then
            With ws.Cells(rowNo, c)
                .Interior.Color = RGB(243, 244, 246)
                .Font.Color = RGB(100, 116, 139)
                .HorizontalAlignment = xlCenter
                .NumberFormatLocal = "@"
                .Borders.Color = RGB(209, 213, 219)
            End With
        End If
    Next c
End Sub

Public Function LastUsedColumnInSheet(ByVal ws As Worksheet, ByVal lastR As Long) As Long
    '�s���Ƃ�End(xlToLeft)����������A�V�[�g�S�̂̍Ō�̒l�E��������x�Ŏ擾����B
    'lastR�����͊����ďo�Ƃ̌݊��p�Ɏc���B
    Dim f As Range
    If ws Is Nothing Then Exit Function
    On Error Resume Next
    Set f = ws.Cells.Find(What:="*", After:=ws.Cells(1, 1), LookIn:=xlFormulas, LookAt:=xlPart, _
                          SearchOrder:=xlByColumns, SearchDirection:=xlPrevious, MatchCase:=False, _
                          MatchByte:=False, SearchFormat:=False)
    If Not f Is Nothing Then LastUsedColumnInSheet = f.Column
    On Error GoTo 0
End Function

Public Function LastRow(ByVal ws As Worksheet, Optional ByVal colNo As Long = 1) As Long
    Dim r As Long
    If ws Is Nothing Then Exit Function
    r = ws.Cells(ws.Rows.Count, colNo).End(xlUp).Row
    If r = 1 And Len(CellText(ws.Cells(1, colNo).Value)) = 0 Then r = 0
    LastRow = r
End Function

Public Sub EnsureInternalAppendCapacity(ByVal ws As Worksheet, ByVal appendRows As Long, _
                                        ByVal labelText As String)
    '�z�񈳏k�͒ǋL��ɍs�����߁A�����ł��ꎞ�I�ȒǋL�����܂߂ċ��ʏ�����ł���K�v������B
    Dim currentRows As Long, lastR As Long
    If ws Is Nothing Then _
        Err.Raise vbObjectError + 1021, "EnsureInternalAppendCapacity", "�����ۊǂ��擾�ł��܂���: " & labelText
    If appendRows < 0 Then _
        Err.Raise vbObjectError + 1022, "EnsureInternalAppendCapacity", "�ǋL�������s���ł�: " & labelText
    lastR = LastUsedRowInSheet(ws)
    If lastR > 1 Then currentRows = lastR - 1
    If CDbl(currentRows) + CDbl(appendRows) > CDbl(MAX_INTERNAL_STORE_DATA_ROWS) Then
        Err.Raise vbObjectError + 1023, "EnsureInternalAppendCapacity", _
                  labelText & "���ǋL���̈ꎞ�̈���܂߂Ď��p����i" & _
                  Format$(MAX_INTERNAL_STORE_DATA_ROWS, "#,##0") & "�s�j�𒴂��܂��B�Č��𕪊����Ă��������B"
    End If
    If CDbl(currentRows) + CDbl(appendRows) > CDbl(ws.Rows.Count - 1) Then
        Err.Raise vbObjectError + 1024, "EnsureInternalAppendCapacity", _
                  labelText & "��Excel�̍s����𒴂��܂��B�Č��𕪊����Ă��������B"
    End If
End Sub

Public Function CellText(ByVal v As Variant) As String
    If IsError(v) Or IsNull(v) Or IsEmpty(v) Then
        CellText = ""
    Else
        CellText = Trim$(CStr(v))
    End If
End Function

Public Function HasText(ByVal v As Variant) As Boolean
    HasText = Len(CellText(v)) > 0
End Function

Public Function ToAmountOrBlank(ByVal v As Variant) As Variant
    Dim ok As Boolean
    ToAmountOrBlank = TryParseAmount(v, ok)
    If Not ok Then ToAmountOrBlank = v
End Function

Public Function TryParseAmount(ByVal v As Variant, ByRef ok As Boolean) As Variant
    Dim s As String
    Dim normalizedText As String
    Dim amountValue As Double
    ok = False
    If IsError(v) Or IsNull(v) Then Exit Function
    s = CellText(v)
    If Len(s) = 0 Then
        TryParseAmount = ""
        ok = True
        Exit Function
    End If
    On Error Resume Next
    s = StrConv(s, vbNarrow)
    On Error GoTo 0
    s = Trim$(s)
    If InStr(1, s, " ", vbBinaryCompare) > 0 Or InStr(1, s, "�@", vbBinaryCompare) > 0 Then Exit Function
    If Not TryNormalizeAmountSyntax(s, normalizedText) Then Exit Function
    If Not IsPlainAmountText(normalizedText) Then Exit Function
    On Error GoTo InvalidAmount
    amountValue = CDbl(normalizedText)
    If Abs(amountValue) > MAX_ABS_AMOUNT Then Exit Function
    TryParseAmount = amountValue
    ok = True
    Exit Function
InvalidAmount:
    ok = False
End Function

Private Function TryNormalizeAmountSyntax(ByVal rawText As String, ByRef normalizedText As String) As Boolean
    '�⏕���͂͋��e���邪�A���������؂��r���ɍ��������ʉ݋L����ق��ĕʋ��z�֕ϊ����Ȃ��B
    Dim s As String, signText As String
    Dim parts As Variant, groups As Variant
    Dim integerPart As String, decimalPart As String
    Dim i As Long, hasParentheses As Boolean
    s = Replace(rawText, "�C", ",")
    If Len(s) = 0 Then Exit Function

    If Left$(s, 1) = "(" Or Right$(s, 1) = ")" Then
        If Len(s) < 3 Or Left$(s, 1) <> "(" Or Right$(s, 1) <> ")" Then Exit Function
        s = Mid$(s, 2, Len(s) - 2)
        signText = "-"
        hasParentheses = True
    End If
    If InStr(1, s, "(", vbBinaryCompare) > 0 Or InStr(1, s, ")", vbBinaryCompare) > 0 Then Exit Function

    If Left$(s, 1) = "+" Or Left$(s, 1) = "-" Then
        If hasParentheses Then Exit Function
        signText = Left$(s, 1)
        s = Mid$(s, 2)
    End If
    If Left$(s, 1) = ChrW$(&HA5) Or Left$(s, 1) = "��" Then s = Mid$(s, 2)
    '�u��-1,000�v�̂悤�ɒʉ݋L���̒���֕�����u���\�L���A������������Ȃ�󂯕t����B
    If Left$(s, 1) = "+" Or Left$(s, 1) = "-" Then
        If hasParentheses Or Len(signText) > 0 Then Exit Function
        signText = Left$(s, 1)
        s = Mid$(s, 2)
    End If
    If Right$(s, 1) = "�~" Then s = Left$(s, Len(s) - 1)
    If Len(s) = 0 Then Exit Function
    If InStr(1, s, ChrW$(&HA5), vbBinaryCompare) > 0 Or _
       InStr(1, s, "��", vbBinaryCompare) > 0 Or InStr(1, s, "�~", vbBinaryCompare) > 0 Then Exit Function

    parts = Split(s, ".")
    If UBound(parts) > 1 Then Exit Function
    integerPart = CStr(parts(0))
    If UBound(parts) = 1 Then decimalPart = CStr(parts(1))
    If InStr(1, decimalPart, ",", vbBinaryCompare) > 0 Then Exit Function
    If InStr(1, integerPart, ",", vbBinaryCompare) > 0 Then
        groups = Split(integerPart, ",")
        If Len(CStr(groups(0))) < 1 Or Len(CStr(groups(0))) > 3 Then Exit Function
        If Not IsUnsignedIntegerText(CStr(groups(0))) Then Exit Function
        For i = 1 To UBound(groups)
            If Len(CStr(groups(i))) <> 3 Then Exit Function
            If Not IsUnsignedIntegerText(CStr(groups(i))) Then Exit Function
        Next i
        integerPart = Replace(integerPart, ",", "")
    End If
    normalizedText = signText & integerPart
    If UBound(parts) = 1 Then normalizedText = normalizedText & "." & decimalPart
    TryNormalizeAmountSyntax = True
End Function

Private Function IsPlainAmountText(ByVal valueText As String) As Boolean
    'Excel�̗L�����x�𒴂���w���\�L�E�ߏ菬�����󂯕t�����A�ۑ����̌����Ȃ��ۂ߂�h���B
    Dim i As Long, startPos As Long, decimalPos As Long
    Dim digitCount As Long, decimalDigits As Long, significantDigits As Long
    Dim ch As String, significantStarted As Boolean
    If Len(valueText) = 0 Then Exit Function
    startPos = 1
    ch = Left$(valueText, 1)
    If ch = "+" Or ch = "-" Then
        startPos = 2
        If Len(valueText) = 1 Then Exit Function
    End If
    For i = startPos To Len(valueText)
        ch = Mid$(valueText, i, 1)
        If ch = "." Then
            If decimalPos > 0 Then Exit Function
            decimalPos = i
        ElseIf ch >= "0" And ch <= "9" Then
            digitCount = digitCount + 1
            If decimalPos > 0 Then decimalDigits = decimalDigits + 1
            If ch <> "0" Then significantStarted = True
            If significantStarted Then significantDigits = significantDigits + 1
        Else
            Exit Function
        End If
    Next i
    If digitCount = 0 Then Exit Function
    If decimalDigits > 8 Then Exit Function
    If significantDigits > 15 Then Exit Function
    IsPlainAmountText = True
End Function

Public Function GetCfgCell(ByVal rowNo As Long) As Range
    Dim ws As Worksheet
    Set ws = GetSheet(SH_CONFIG)
    Set GetCfgCell = ws.Cells(rowNo, COL_CFG_VALUE)
End Function

Public Function GetCfgLong(ByVal rowNo As Long, ByVal defaultValue As Long) As Long
    On Error GoTo EH
    If IsNumeric(GetCfgCell(rowNo).Value) Then
        GetCfgLong = CLng(GetCfgCell(rowNo).Value)
    Else
        GetCfgLong = defaultValue
    End If
    Exit Function
EH:
    GetCfgLong = defaultValue
End Function

Public Function GetCfgDateValue(ByVal rowNo As Long) As Variant
    Dim normalized As Variant
    Dim ok As Boolean
    On Error GoTo EH
    normalized = NormalizeDateOnlyValue(GetCfgCell(rowNo).Value, ok)
    If ok Then GetCfgDateValue = normalized Else GetCfgDateValue = ""
    Exit Function
EH:
    GetCfgDateValue = ""
End Function

Public Function NormalizeDateOnlyValue(ByVal valueIn As Variant, ByRef ok As Boolean) As Variant
    '���t��Ɍ����Ȃ�����������AExcel�ň���\���ł��Ȃ�1900�N�������������܂Ȃ��B
    Dim dt As Date
    ok = False
    If IsError(valueIn) Or IsNull(valueIn) Or IsEmpty(valueIn) Then Exit Function
    If Len(CellText(valueIn)) = 0 Then Exit Function
    If Not IsDate(valueIn) Then Exit Function
    On Error GoTo InvalidDate
    dt = CDate(valueIn)
    If Year(dt) < 1900 Or Year(dt) > 9999 Then Exit Function
    NormalizeDateOnlyValue = DateSerial(Year(dt), Month(dt), Day(dt))
    ok = True
    Exit Function
InvalidDate:
    NormalizeDateOnlyValue = ""
End Function

Public Function GetInputMode() As String
    On Error GoTo EH
    GetInputMode = CellText(GetCfgCell(ROW_CFG_INPUT_MODE).Value)
    If Len(GetInputMode) = 0 Then GetInputMode = MODE_NORMAL
    Exit Function
EH:
    GetInputMode = MODE_NORMAL
End Function

Public Function GetYearInputMode() As String
    On Error GoTo EH
    GetYearInputMode = CellText(GetCfgCell(ROW_CFG_YEAR_MODE).Value)
    If Len(GetYearInputMode) = 0 Then GetYearInputMode = YEAR_MODE_WAREKI
    Exit Function
EH:
    GetYearInputMode = YEAR_MODE_WAREKI
End Function


Public Function GetPostTransferKeepPolicy() As String
    Dim configuredValue As String
    On Error GoTo EH
    configuredValue = CellText(GetCfgCell(ROW_CFG_POST_KEEP).Value)
    Select Case configuredValue
        Case KEEP_NONE, KEEP_PERSON_ONLY, KEEP_BANK_BRANCH, KEEP_BANK_BRANCH_PERSON_TYPE
            GetPostTransferKeepPolicy = configuredValue
        Case Else
            GetPostTransferKeepPolicy = KEEP_BANK_BRANCH_PERSON_TYPE
    End Select
    Exit Function
EH:
    GetPostTransferKeepPolicy = KEEP_BANK_BRANCH_PERSON_TYPE
End Function

Public Function GetPostTransferClearTransaction() As Boolean
    On Error GoTo EH
    GetPostTransferClearTransaction = (CellText(GetCfgCell(ROW_CFG_POST_TX).Value) <> POST_KEEP)
    Exit Function
EH:
    GetPostTransferClearTransaction = True
End Function

Public Function GetPostTransferClearBalance() As Boolean
    On Error GoTo EH
    GetPostTransferClearBalance = (CellText(GetCfgCell(ROW_CFG_POST_BAL).Value) <> POST_KEEP)
    Exit Function
EH:
    GetPostTransferClearBalance = True
End Function

Public Function GetDisplayOption(ByVal rowNo As Long, Optional ByVal defaultShow As Boolean = True) As Boolean
    '�ݒ�V�[�g�́u�\������ / �\�����Ȃ��v�����S�ɓǂݎ��B
    '�󗓂�z��O�̒l�́A�Ɩ��ō���ɂ����悤 defaultShow ��Ԃ��B
    Dim v As String
    On Error GoTo EH
    v = CellText(GetCfgCell(rowNo).Value)
    If v = DISPLAY_ON Then
        GetDisplayOption = True
    ElseIf v = DISPLAY_OFF Then
        GetDisplayOption = False
    Else
        GetDisplayOption = defaultShow
    End If
    Exit Function
EH:
    GetDisplayOption = defaultShow
End Function

Public Function UseRelationshipDisplay() As Boolean
    UseRelationshipDisplay = GetDisplayOption(ROW_CFG_RELATIONSHIP, True)
End Function

Public Function ShowInheritanceStartRow() As Boolean
    ShowInheritanceStartRow = GetDisplayOption(ROW_CFG_SHOW_INHERITANCE_ROW, True)
End Function

Public Function ShowOpenDateRow() As Boolean
    ShowOpenDateRow = GetDisplayOption(ROW_CFG_SHOW_OPEN_DATE_ROW, True)
End Function

Public Function ShowCloseDateRow() As Boolean
    ShowCloseDateRow = GetDisplayOption(ROW_CFG_SHOW_CLOSE_DATE_ROW, True)
End Function

Public Function ShowBalanceRowsInCashOperation() As Boolean
    ShowBalanceRowsInCashOperation = GetDisplayOption(ROW_CFG_SHOW_BALANCE_ROWS, True)
End Function

Public Function DisplayPersonWithRelationship(ByVal personName As String, ByVal relationshipText As String) As String
    '�o�͂ł͗�𑝂₳���A�������̒��Łu�����i�����j�v�Ƃ��ĕ\������B
    '�ݒ�ő������\���ɂ����ꍇ�͎����݂̂�Ԃ��B
    Dim p As String, rel As String
    p = CellText(personName)
    rel = CellText(relationshipText)
    If UseRelationshipDisplay() And Len(rel) > 0 Then
        DisplayPersonWithRelationship = p & "�i" & rel & "�j"
    Else
        DisplayPersonWithRelationship = p
    End If
End Function

Public Function IsLightExcelColor(ByVal colorValue As Long) As Boolean
    '���w�i�ɔ���������鎖�̂�h�����߂̖��x����B
    Dim r As Long, g As Long, b As Long
    Dim brightness As Double
    r = colorValue Mod 256
    g = (colorValue \ 256) Mod 256
    b = (colorValue \ 65536) Mod 256
    brightness = 0.299 * r + 0.587 * g + 0.114 * b
    IsLightExcelColor = (brightness >= 210)
End Function

Public Sub FixUnreadableWhiteTextOnSheet(ByVal ws As Worksheet)
    '�W�F�w�i�{�W�F�����ɂȂ����Z�����A�ǂ݂₷���Z�F�֖߂����ʕ␳�B
    'UsedRange���ߋ��̏�������ŉߑ�ɂȂ��Ă���Əd���Ȃ邽�߁A
    '���ۂɒl�E�����������Ă���͈͂�����Ώۂɂ���B
    Dim rng As Range, c As Range
    Dim lastR As Long, lastC As Long
    If ws Is Nothing Then Exit Sub

    lastR = LastUsedRowInSheet(ws)
    If lastR < 1 Then Exit Sub
    lastC = LastUsedColumnInSheet(ws, lastR)
    If lastC < 1 Then Exit Sub
    '��K�͕\�͊e�Z���̐F�擾�����Œ������x���Ȃ�B�������̈ꊇ�����𐳂Ƃ��A�␳�����͏ȗ�����B
    If CDbl(lastR) * CDbl(lastC) > MAX_READABILITY_SCAN_CELLS Then Exit Sub

    On Error Resume Next
    Set rng = ws.Range(ws.Cells(1, 1), ws.Cells(lastR, lastC))
    If rng Is Nothing Then Exit Sub
    For Each c In rng.Cells
        If IsLightExcelColor(c.Interior.Color) And IsLightExcelColor(c.Font.Color) Then
            c.Font.Color = RGB(15, 23, 42)
        End If
    Next c
    On Error GoTo 0
End Sub

Public Function LastUsedRowInSheet(ByVal ws As Worksheet) As Long
    '���t���E�E�v�������̑����J�n���s���E����悤�A�����ł͂Ȃ��V�[�g�S�̂ōŏI�s��T���B
    Dim f As Range
    If ws Is Nothing Then Exit Function
    On Error Resume Next
    Set f = ws.Cells.Find(What:="*", After:=ws.Cells(1, 1), LookIn:=xlFormulas, LookAt:=xlPart, _
                          SearchOrder:=xlByRows, SearchDirection:=xlPrevious, MatchCase:=False, _
                          MatchByte:=False, SearchFormat:=False)
    If Not f Is Nothing Then LastUsedRowInSheet = f.Row
    On Error GoTo 0
End Function

Public Function IsTransactionRowBlank(ByVal ws As Worksheet, ByVal r As Long) As Boolean
    Dim c As Long
    If ws Is Nothing Then
        IsTransactionRowBlank = True
        Exit Function
    End If
    For c = COL_TX_YEAR To COL_TX_OTHER
        If HasText(ws.Cells(r, c).Value) Then
            IsTransactionRowBlank = False
            Exit Function
        End If
    Next c
    IsTransactionRowBlank = True
End Function

Public Function NormalizeYearInput(ByVal v As Variant, ByVal yearAdd As Long, ByRef ok As Boolean) As Long
    Dim s As String
    Dim y As Long
    Dim modeText As String
    ok = False
    s = NormalizeNumberText(CellText(v))
    If Len(s) = 0 Then Exit Function

    '3�`4���́A�ǂ̓��͕����ł�����Ƃ��Ĉ����B5���ȏ�͔͈͊O�Ƃ��ċ��ۂ���B
    If IsUnsignedIntegerText(s) Then
        If Len(s) > 4 Then Exit Function
        y = CLng(s)
        If y >= 100 Then
            If y < 1900 Or y > 9999 Then Exit Function
            NormalizeYearInput = y
            ok = True
            Exit Function
        End If
    End If

    modeText = GetYearInputMode()
    If modeText = YEAR_MODE_WESTERN2 Then
        If Not IsUnsignedIntegerText(s) Then Exit Function
        If Len(s) > 2 Then Exit Function
        y = CLng(s)
        If y < 0 Or y > 99 Then Exit Function
        y = yearAdd + y
    Else
        y = ResolveWarekiYearSmart(s)
    End If

    If y < 1900 Or y > 9999 Then Exit Function
    NormalizeYearInput = y
    ok = True
End Function

Private Function NormalizeNumberText(ByVal s As String) As String
    On Error Resume Next
    s = StrConv(s, vbNarrow)
    On Error GoTo 0
    s = Replace(s, " ", "")
    s = Replace(s, "�@", "")
    s = Replace(s, "�N", "")
    NormalizeNumberText = Trim$(s)
End Function

Private Function IsUnsignedIntegerText(ByVal valueText As String) As Boolean
    Dim i As Long, ch As String
    If Len(valueText) = 0 Then Exit Function
    For i = 1 To Len(valueText)
        ch = Mid$(valueText, i, 1)
        If ch < "0" Or ch > "9" Then Exit Function
    Next i
    IsUnsignedIntegerText = True
End Function

Private Function ResolveWarekiYearSmart(ByVal s As String) As Long
    Dim y As Long
    Dim n As Long

    If ResolveExplicitEraYear(s, y) Then
        ResolveWarekiYearSmart = y
        Exit Function
    End If

    If s = "��" Then s = "1"
    If Not IsUnsignedIntegerText(s) Then Exit Function
    If Len(s) > 2 Then Exit Function
    n = CLng(s)
    If n <= 0 Or n > 99 Then Exit Function

    ResolveWarekiYearSmart = BestJapaneseEraCandidate(n)
End Function

Private Function ResolveExplicitEraYear(ByVal s As String, ByRef westernYear As Long) As Boolean
    Dim era As String
    Dim n As Long
    s = UCase$(s)
    s = Replace(s, ".", "")
    s = Replace(s, "-", "")
    s = Replace(s, "�ߘa", "R")
    s = Replace(s, "����", "H")
    s = Replace(s, "���a", "S")
    If Len(s) < 2 Then Exit Function
    era = Left$(s, 1)
    If era <> "R" And era <> "H" And era <> "S" Then Exit Function
    s = Mid$(s, 2)
    If s = "��" Then s = "1"
    If Not IsUnsignedIntegerText(s) Then Exit Function
    If Len(s) > 2 Then Exit Function
    n = CLng(s)
    If n <= 0 Then Exit Function

    Select Case era
        Case "R"
            If n > 99 Then Exit Function
            westernYear = 2018 + n
        Case "H"
            If n > 31 Then Exit Function
            westernYear = 1988 + n
        Case "S"
            If n > 64 Then Exit Function
            westernYear = 1925 + n
    End Select
    ResolveExplicitEraYear = (westernYear >= 1900 And westernYear <= 9999)
End Function

Private Function BestJapaneseEraCandidate(ByVal eraYear As Long) As Long
    Dim candidates(1 To 3) As Long
    Dim count As Long
    Dim i As Long
    Dim refYear As Long
    Dim bestYear As Long
    Dim bestScore As Long
    Dim score As Long

    If eraYear >= 1 And eraYear <= 99 Then
        count = count + 1
        candidates(count) = 2018 + eraYear  '�ߘa
    End If
    If eraYear >= 1 And eraYear <= 31 Then
        count = count + 1
        candidates(count) = 1988 + eraYear  '����
    End If
    If eraYear >= 1 And eraYear <= 64 Then
        count = count + 1
        candidates(count) = 1925 + eraYear  '���a
    End If

    refYear = GetYearResolutionReferenceYear()
    bestScore = 999999
    For i = 1 To count
        If candidates(i) >= 1900 And candidates(i) <= 2100 Then
            score = Abs(candidates(i) - refYear) + JapaneseEraWindowPenalty(candidates(i))
            If score < bestScore Or (score = bestScore And candidates(i) > bestYear) Then
                bestScore = score
                bestYear = candidates(i)
            End If
        End If
    Next i
    BestJapaneseEraCandidate = bestYear
End Function

Private Function GetYearResolutionReferenceYear() As Long
    Dim inheritDate As Variant
    Dim startYear As Long
    Dim endYear As Long
    inheritDate = GetCfgDateValue(ROW_CFG_INHERITANCE_DATE)
    If IsDate(inheritDate) Then
        GetYearResolutionReferenceYear = Year(CDate(inheritDate))
        Exit Function
    End If
    startYear = GetCfgLong(ROW_CFG_BAL_START_YEAR, Year(Date) - 4)
    endYear = GetCfgLong(ROW_CFG_BAL_END_YEAR, Year(Date))
    If startYear > 0 And endYear >= startYear Then
        GetYearResolutionReferenceYear = CLng((startYear + endYear) / 2)
    Else
        GetYearResolutionReferenceYear = Year(Date)
    End If
End Function

Private Function JapaneseEraWindowPenalty(ByVal westernYear As Long) As Long
    Dim startYear As Long
    Dim endYear As Long
    startYear = GetCfgLong(ROW_CFG_BAL_START_YEAR, Year(Date) - 4)
    endYear = GetCfgLong(ROW_CFG_BAL_END_YEAR, Year(Date))
    If endYear < startYear Then endYear = startYear
    If westernYear < startYear - 5 Or westernYear > endYear + 5 Then
        JapaneseEraWindowPenalty = 1000
    Else
        JapaneseEraWindowPenalty = 0
    End If
End Function

Public Function ParseMonthDay(ByVal v As Variant, ByRef m As Long, ByRef d As Long) As Boolean
    Dim s As String
    On Error GoTo InvalidMonthDay
    s = NormalizeNumberText(CellText(v))
    ParseMonthDay = False
    If Len(s) < 3 Or Len(s) > 4 Then Exit Function
    If Not IsUnsignedIntegerText(s) Then Exit Function
    If Len(s) = 3 Then
        m = CLng(Left$(s, 1))
        d = CLng(Right$(s, 2))
    Else
        m = CLng(Left$(s, 2))
        d = CLng(Right$(s, 2))
    End If
    If m < 1 Or m > 12 Then Exit Function
    If d < 1 Or d > 31 Then Exit Function
    ParseMonthDay = True
    Exit Function
InvalidMonthDay:
    ParseMonthDay = False
End Function

Public Function ResolveInputDate(ByVal yearVal As Variant, ByVal monthVal As Variant, ByVal dayVal As Variant, _
    ByRef currentYear As Long, ByRef currentMonth As Long, ByRef currentDay As Long, _
    ByVal yearAdd As Long, ByRef ok As Boolean) As Variant

    Dim tmpYear As Long
    Dim tmpMonth As Long
    Dim tmpDay As Long
    Dim yearOK As Boolean
    Dim d As Date
    Dim monthText As String, dayText As String

    ok = False
    On Error GoTo InvalidDate
    If HasText(yearVal) Then
        tmpYear = NormalizeYearInput(yearVal, yearAdd, yearOK)
        If Not yearOK Then Exit Function
        currentYear = tmpYear
    End If
    If HasText(monthVal) Then
        monthText = NormalizeNumberText(CellText(monthVal))
        If Len(monthText) = 0 Or Len(monthText) > 2 Then Exit Function
        If Not IsUnsignedIntegerText(monthText) Then Exit Function
        currentMonth = CLng(monthText)
    End If
    If HasText(dayVal) Then
        If ParseMonthDay(dayVal, tmpMonth, tmpDay) Then
            currentMonth = tmpMonth
            currentDay = tmpDay
        Else
            dayText = NormalizeNumberText(CellText(dayVal))
            If Len(dayText) = 0 Or Len(dayText) > 2 Then Exit Function
            If Not IsUnsignedIntegerText(dayText) Then Exit Function
            currentDay = CLng(dayText)
        End If
    End If
    If currentYear = 0 Or currentMonth = 0 Or currentDay = 0 Then Exit Function
    If currentMonth < 1 Or currentMonth > 12 Or currentDay < 1 Or currentDay > 31 Then Exit Function
    d = DateSerial(currentYear, currentMonth, currentDay)
    If Year(d) <> currentYear Or Month(d) <> currentMonth Or Day(d) <> currentDay Then GoTo InvalidDate
    ResolveInputDate = d
    ok = True
    Exit Function
InvalidDate:
    ResolveInputDate = ""
End Function

Public Function NormalizeTimeInput(ByVal v As Variant, ByRef ok As Boolean) As Variant
    Dim s As String
    Dim i As Long, j As Long
    Dim h As Long
    Dim m As Long
    Dim parts As Variant, partText As String, ch As String
    ok = False
    On Error GoTo InvalidTime
    '��Z����Empty�𐔒l0�i00:00�j�Ƃ��Ĉ���Ȃ��B���������͂͏�ɋ󗓂̂܂ܕԂ��B
    If IsError(v) Then GoTo InvalidTime
    If IsNull(v) Or IsEmpty(v) Then
        NormalizeTimeInput = ""
        ok = True
        Exit Function
    End If
    If VarType(v) = vbDate Then
        '���t�t���������������֌듊�����Ă��A��������������ق��č̗p���Ȃ��B
        If CDbl(CDate(v)) < 0 Or CDbl(CDate(v)) >= 1 Then GoTo InvalidTime
        If Second(CDate(v)) <> 0 Then GoTo InvalidTime
        NormalizeTimeInput = TimeSerial(Hour(CDate(v)), Minute(CDate(v)), 0)
        ok = True
        Exit Function
    End If
    '���l������́u0.5�v��Excel�����V���A���Ƃ��Č���߂��Ȃ��B
    '���ۂ̐��l�Z���������V���A���l�Ƃ��Ĉ����A�������HHMM/HH:MM�֌��肷��B
    If VarType(v) <> vbString And VarType(v) <> vbBoolean And IsNumeric(v) Then
        If CDbl(v) >= 0 And CDbl(v) < 1 Then
            If Second(CDate(v)) <> 0 Then GoTo InvalidTime
            NormalizeTimeInput = TimeSerial(Hour(CDate(v)), Minute(CDate(v)), 0)
            ok = True
            Exit Function
        End If
    End If
    s = CellText(v)
    If Len(s) = 0 Then
        NormalizeTimeInput = ""
        ok = True
        Exit Function
    End If
    On Error Resume Next
    s = StrConv(s, vbNarrow)
    On Error GoTo InvalidTime
    s = Replace(s, "�F", ":")
    s = Trim$(s)
    If InStr(1, s, " ", vbBinaryCompare) > 0 Or InStr(1, s, "�@", vbBinaryCompare) > 0 Then _
        GoTo InvalidTime
    If InStr(1, s, ":", vbBinaryCompare) > 0 Then
        'IsDate�C���ɂ����24:00����t����������ˑ��Ŏ󂯕t���邽�߁A���E���𖾎���������B
        parts = Split(s, ":")
        If UBound(parts) <> 1 Then GoTo InvalidTime
        For i = LBound(parts) To UBound(parts)
            partText = CStr(parts(i))
            If Len(partText) = 0 Or Len(partText) > 2 Then GoTo InvalidTime
            For j = 1 To Len(partText)
                ch = Mid$(partText, j, 1)
                If ch < "0" Or ch > "9" Then GoTo InvalidTime
            Next j
        Next i
        h = CLng(parts(0))
        m = CLng(parts(1))
        If h < 0 Or h > 23 Or m < 0 Or m > 59 Then _
            GoTo InvalidTime
        NormalizeTimeInput = TimeSerial(h, m, 0)
        ok = True
        Exit Function
    End If
    If Len(s) > 4 Then
        NormalizeTimeInput = v
        Exit Function
    End If
    For i = 1 To Len(s)
        If Mid$(s, i, 1) < "0" Or Mid$(s, i, 1) > "9" Then
            NormalizeTimeInput = v
            Exit Function
        End If
    Next i
    s = Right$("0000" & s, 4)
    h = CLng(Left$(s, 2))
    m = CLng(Right$(s, 2))
    If h < 0 Or h > 23 Or m < 0 Or m > 59 Then
        NormalizeTimeInput = v
        Exit Function
    End If
    NormalizeTimeInput = TimeSerial(h, m, 0)
    ok = True
    Exit Function
InvalidTime:
    ok = False
    NormalizeTimeInput = v
End Function

Public Function NextBranchAccountNo(ByVal accountNo As String) As String
    Dim s As String
    Dim baseNo As String
    Dim suffixText As String
    Dim p As Long
    Dim suffixNo As Long
    Dim suffixWidth As Long
    Dim suffixValue As Double
    s = NormalizeAccountHyphen(CellText(accountNo))
    If Len(s) = 0 Then
        NextBranchAccountNo = ""
        Exit Function
    End If
    p = InStrRev(s, "-")
    If p > 0 Then
        baseNo = Left$(s, p - 1)
        suffixText = Mid$(s, p + 1)
        If Len(baseNo) > 0 And Len(suffixText) <= 10 And IsUnsignedIntegerText(suffixText) Then
            suffixValue = CDbl(suffixText)
            If suffixValue = Fix(suffixValue) And suffixValue >= 0 And suffixValue <= 2147483646# Then
                suffixWidth = Len(suffixText)
                suffixNo = CLng(suffixValue) + 1
                If suffixWidth > 1 Then
                    NextBranchAccountNo = baseNo & "-" & Format$(suffixNo, String$(suffixWidth, "0"))
                Else
                    NextBranchAccountNo = baseNo & "-" & CStr(suffixNo)
                End If
                Exit Function
            End If
        End If
    End If
    NextBranchAccountNo = s & "-1"
End Function

Public Function ResolveAccountDateInput(ByVal v As Variant, ByRef ok As Boolean) As Variant
    '�����J�ݓ��E�����̓��͕⏕�p�B
    '������ׂ̔N���͂Ƃ͕ʂɁA���a�E�����E�ߘa�𖾎��ł���u�����R�[�h.�N.��.���v��D�悵�ĉ��߂���B
    '��F1.53.5.6=���a53�N5��6���A2.31.4.30=����31�N4��30���A3.1.5.1=�ߘa���N5��1���B
    '�����R�[�h�͐ݒ�V�[�g�̌����}�X�^�ŊǗ����邽�߁A�V�����̓}�X�^��1�s�ǉ�����ΑΉ��ł���B
    Dim s As String
    Dim cleaned As String
    Dim parts As Variant
    Dim y As Long, m As Long, d As Long
    Dim yearOK As Boolean
    Dim yAdd As Long
    Dim normalizedDate As Variant

    ok = False
    If VarType(v) = vbDate Then
        normalizedDate = NormalizeDateOnlyValue(v, ok)
        If ok Then ResolveAccountDateInput = normalizedDate
        Exit Function
    End If
    s = CellText(v)
    If Len(s) = 0 Then
        ResolveAccountDateInput = ""
        ok = True
        Exit Function
    End If

    On Error Resume Next
    s = StrConv(s, vbNarrow)
    On Error GoTo 0
    s = UCase$(s)
    s = Replace(s, " ", "")
    s = Replace(s, "�@", "")
    s = Replace(s, "�D", ".")
    s = Replace(s, "�B", ".")
    s = Replace(s, "�E", ".")
    s = Replace(s, "-", "/")
    s = Replace(s, ".", "/")
    s = Replace(s, "�N", "/")
    s = Replace(s, "��", "/")
    s = Replace(s, "��", "")
    yAdd = GetCfgLong(ROW_CFG_YEAR_ADD, 2000)

    If InStr(1, s, "/", vbTextCompare) > 0 Then
        parts = Split(s, "/")

        '�����R�[�h�t�����́B��F1/53/5/6�A2/31/4/30�A3/1/5/1�B
        If UBound(parts) = 3 Then
            ResolveAccountDateInput = ResolveEraCodeDateInput(parts(0), parts(1), parts(2), parts(3), ok)
            Exit Function
        End If

        '�]���݊��B��F31/4/30�AR1/5/1�A2019/5/1�B
        '�]���ȋ�؂���܂ޓ��͂�擪3�v�f�����œ��t�����Ȃ��B
        If UBound(parts) <> 2 Then Exit Function
        y = NormalizeYearInput(parts(0), yAdd, yearOK)
        If Not yearOK Then Exit Function
        If Not IsUnsignedIntegerText(CStr(parts(1))) Then Exit Function
        If Not IsUnsignedIntegerText(CStr(parts(2))) Then Exit Function
        If Len(CStr(parts(1))) > 2 Or Len(CStr(parts(2))) > 2 Then Exit Function
        m = CLng(parts(1))
        d = CLng(parts(2))
        ResolveAccountDateInput = MakeCheckedDate(y, m, d, ok)
        Exit Function
    End If

    cleaned = Replace(s, "/", "")
    If IsUnsignedIntegerText(cleaned) Then
        Select Case Len(cleaned)
            Case 8
                y = CLng(Left$(cleaned, 4))
                m = CLng(Mid$(cleaned, 5, 2))
                d = CLng(Right$(cleaned, 2))
            Case 6
                y = NormalizeYearInput(Left$(cleaned, 2), yAdd, yearOK)
                If Not yearOK Then Exit Function
                m = CLng(Mid$(cleaned, 3, 2))
                d = CLng(Right$(cleaned, 2))
            Case 5
                'R1�N5��1���� 10501 �ƑłP�[�X�p�B���a�ȂǌÂ��J�ݓ��͌����R�[�h�t�����͂𐄏��B
                y = NormalizeYearInput(Left$(cleaned, 1), yAdd, yearOK)
                If Not yearOK Then Exit Function
                m = CLng(Mid$(cleaned, 2, 2))
                d = CLng(Right$(cleaned, 2))
            Case Else
                If IsDate(s) Then
                    ResolveAccountDateInput = NormalizeDateOnlyValue(s, ok)
                End If
                Exit Function
        End Select
        ResolveAccountDateInput = MakeCheckedDate(y, m, d, ok)
        Exit Function
    End If

    If IsDate(s) Then
        ResolveAccountDateInput = NormalizeDateOnlyValue(s, ok)
    End If
End Function

Private Function ResolveEraCodeDateInput( _
    ByVal eraKey As String, _
    ByVal eraYearText As String, _
    ByVal monthText As String, _
    ByVal dayText As String, _
    ByRef ok As Boolean _
) As Variant
    '�����R�[�h�t�����t�𐼗���t�ɕϊ�����B
    '�N�́u���v��1�N�Ƃ��Ĉ����B�����̊J�n���E�I��������O���ꍇ�͖����ɂ���B
    Dim eraName As String
    Dim eraAbbr As String
    Dim startDate As Date
    Dim endDate As Date
    Dim hasEndDate As Boolean
    Dim eraYear As Long
    Dim m As Long
    Dim d As Long
    Dim westernYear As Long
    Dim dt As Variant

    ok = False
    eraYearText = NormalizeNumberText(eraYearText)
    If eraYearText = "��" Then eraYearText = "1"
    If Not IsUnsignedIntegerText(eraYearText) Then Exit Function
    If Not IsUnsignedIntegerText(CStr(monthText)) Then Exit Function
    If Not IsUnsignedIntegerText(CStr(dayText)) Then Exit Function
    If Len(eraYearText) > 4 Or Len(CStr(monthText)) > 2 Or Len(CStr(dayText)) > 2 Then Exit Function

    eraYear = CLng(eraYearText)
    m = CLng(monthText)
    d = CLng(dayText)
    If eraYear <= 0 Then Exit Function

    If Not TryGetEraInfoByKey(eraKey, eraName, eraAbbr, startDate, endDate, hasEndDate) Then Exit Function

    westernYear = Year(startDate) + eraYear - 1
    dt = MakeCheckedDate(westernYear, m, d, ok)
    If Not ok Or Not IsDate(dt) Then Exit Function

    If CDate(dt) < startDate Then
        ok = False
        ResolveEraCodeDateInput = ""
        Exit Function
    End If
    If hasEndDate Then
        If CDate(dt) > endDate Then
            ok = False
            ResolveEraCodeDateInput = ""
            Exit Function
        End If
    End If

    ResolveEraCodeDateInput = CDate(dt)
    ok = True
End Function

Public Function TryGetEraInfoByKey( _
    ByVal eraKey As String, _
    ByRef eraName As String, _
    ByRef eraAbbr As String, _
    ByRef startDate As Date, _
    ByRef endDate As Date, _
    ByRef hasEndDate As Boolean _
) As Boolean
    '�ݒ�V�[�g�̌����}�X�^���猳�������擾����B
    '��v�����́u�����R�[�h�v�u�������v�u���́v�B�ݒ�V�[�g���������̏ꍇ�͏��a�E�����E�ߘa�̊���l�փt�H�[���o�b�N����B
    Dim ws As Worksheet
    Dim r As Long
    Dim key As String
    Dim codeText As String
    Dim nameText As String
    Dim abbrText As String
    Dim enabledText As String

    key = NormalizeEraKey(eraKey)
    If Len(key) = 0 Then Exit Function

    On Error Resume Next
    Set ws = GetSheet(SH_CONFIG)
    On Error GoTo 0

    If Not ws Is Nothing Then
        For r = ERA_MASTER_FIRST_ROW To ERA_MASTER_MAX_ROW
            codeText = NormalizeEraKey(CellText(ws.Cells(r, ERA_COL_CODE).Value))
            nameText = NormalizeEraKey(CellText(ws.Cells(r, ERA_COL_NAME).Value))
            abbrText = NormalizeEraKey(CellText(ws.Cells(r, ERA_COL_ABBR).Value))
            If Len(codeText) = 0 And Len(nameText) = 0 And Len(abbrText) = 0 Then
                '��s�͏��������̒ǉ����͗��Ȃ̂œǂݔ�΂��B
            ElseIf key = codeText Or key = nameText Or key = abbrText Then
                enabledText = UCase$(CellText(ws.Cells(r, ERA_COL_ENABLED).Value))
                If enabledText = "FALSE" Or enabledText = "0" Or enabledText = "����" Then Exit Function
                If Not IsDate(ws.Cells(r, ERA_COL_START).Value) Then Exit Function

                eraName = CellText(ws.Cells(r, ERA_COL_NAME).Value)
                eraAbbr = CellText(ws.Cells(r, ERA_COL_ABBR).Value)
                startDate = CDate(ws.Cells(r, ERA_COL_START).Value)
                If IsDate(ws.Cells(r, ERA_COL_END).Value) Then
                    endDate = CDate(ws.Cells(r, ERA_COL_END).Value)
                    hasEndDate = True
                Else
                    endDate = 0
                    hasEndDate = False
                End If
                TryGetEraInfoByKey = True
                Exit Function
            End If
        Next r
    End If

    '�t�H�[���o�b�N�B�ݒ�V�[�g���󂵂��ꍇ�ł��A����3�����͍Œ���g����悤�ɂ���B
    Select Case key
        Case "1", "S", "���a"
            eraName = "���a": eraAbbr = "S": startDate = DateSerial(1926, 12, 25): endDate = DateSerial(1989, 1, 7): hasEndDate = True
        Case "2", "H", "����"
            eraName = "����": eraAbbr = "H": startDate = DateSerial(1989, 1, 8): endDate = DateSerial(2019, 4, 30): hasEndDate = True
        Case "3", "R", "�ߘa"
            eraName = "�ߘa": eraAbbr = "R": startDate = DateSerial(2019, 5, 1): endDate = 0: hasEndDate = False
        Case Else
            Exit Function
    End Select
    TryGetEraInfoByKey = True
End Function

Private Function NormalizeEraKey(ByVal s As String) As String
    On Error Resume Next
    s = StrConv(s, vbNarrow)
    On Error GoTo 0
    s = UCase$(Trim$(s))
    s = Replace(s, " ", "")
    s = Replace(s, "�@", "")
    NormalizeEraKey = s
End Function

Private Function MakeCheckedDate(ByVal y As Long, ByVal m As Long, ByVal d As Long, ByRef ok As Boolean) As Variant
    Dim dt As Date
    ok = False
    If y < 1900 Or y > 9999 Or m < 1 Or m > 12 Or d < 1 Or d > 31 Then Exit Function
    On Error GoTo InvalidDate
    dt = DateSerial(y, m, d)
    If Year(dt) <> y Or Month(dt) <> m Or Day(dt) <> d Then GoTo InvalidDate
    MakeCheckedDate = dt
    ok = True
    Exit Function
InvalidDate:
    MakeCheckedDate = ""
End Function

Public Function NormalizedAccountDateForUse(ByVal v As Variant) As Variant
    '�]�L�����E�c��������p�B���͓r���̕�����ł����t�Ƃ��ēǂ߂���͎̂����t�Ɋ񂹂�B
    Dim ok As Boolean
    Dim d As Variant
    d = ResolveAccountDateInput(v, ok)
    If ok Then
        If IsDate(d) Then
            NormalizedAccountDateForUse = CDate(d)
            Exit Function
        End If
    End If
    NormalizedAccountDateForUse = ""
End Function

Public Sub NormalizeAccountDateEntry(ByVal targetCell As Range)
    '�J�ݓ��E�����Z���̓��͒���ɁA�a������͂����₷�� yyyy/m/d �\���֐�����B
    '���t�͕�����ł͂Ȃ�Excel�̓��t�l�Ƃ��ĕێ����A�㑱�̎c������E�o�͂ł����肵�Ĉ����B
    Dim ok As Boolean
    Dim d As Variant
    If targetCell Is Nothing Then Exit Sub
    d = ResolveAccountDateInput(targetCell.Value, ok)
    If ok Then
        If IsDate(d) Then
            targetCell.NumberFormatLocal = "yyyy/m/d"
            targetCell.Value = CDate(d)
        End If
    End If
End Sub

Public Function AccountExistsAtDate(ByVal targetDate As Variant, ByVal openDate As Variant, ByVal closeDate As Variant) As Boolean
    '�w�����Ɍ��������݂��Ă������𔻒肷��B
    '�J�ݓ��O�E������̎c���͓��͗��ł̓��b�N���A�c�����ڕ\�ł́u-�v�\���ɂ���B
    If Not IsDate(targetDate) Then
        AccountExistsAtDate = True
        Exit Function
    End If
    If IsDate(openDate) Then
        If CDate(targetDate) < CDate(openDate) Then Exit Function
    End If
    If IsDate(closeDate) Then
        If CDate(targetDate) > CDate(closeDate) Then Exit Function
    End If
    AccountExistsAtDate = True
End Function

Public Function IsBalancePlaceholder(ByVal valueIn As Variant) As Boolean
    '�ߋ��ł����̓Z���֏������񂾕\���p�n�C�t�����A���p�҂̎c���l�Ƃ��Ĉ���Ȃ��B
    Dim s As String
    s = Trim$(CellText(valueIn))
    'U+2014 EM DASH��VBE�W����CP932�Œ��ڕێ��ł��Ȃ����߁AChrW�Ŕ��肷��B
    IsBalancePlaceholder = (s = "-" Or s = "�|" Or s = "�\" Or s = ChrW$(&H2014))
End Function

Public Sub ApplyBalanceAvailability(ByVal ws As Worksheet)
    '�J�ݓ��E�����ɉ����Ďc�����͗��𐧌䂷��B
    '���݂��Ȃ����Ԃ̎c�����́A���͕s�E�I��s�E���F�\���ɂ��āATab�ړ��ł���΂��B
    Dim memoCol As Long
    Dim c As Long
    Dim openDate As Variant
    Dim closeDate As Variant
    Dim balDate As Variant
    Dim enabled As Boolean

    If ws Is Nothing Then Exit Sub
    If ws.Name <> SH_INPUT Then Exit Sub

    memoCol = BalanceMemoCol(ws)
    openDate = NormalizedAccountDateForUse(ws.Range(CELL_OPEN_DATE).Value)
    closeDate = NormalizedAccountDateForUse(ws.Range(CELL_CLOSE_DATE).Value)

    For c = BAL_FIRST_COL To memoCol - 1
        balDate = ws.Cells(BAL_DATE_ROW, c).Value
        enabled = AccountExistsAtDate(balDate, openDate, closeDate)
        ApplySingleBalanceInputState ws, c, enabled
    Next c
End Sub

Private Sub ApplySingleBalanceInputState(ByVal ws As Worksheet, ByVal c As Long, ByVal enabled As Boolean)
    Dim valueCell As Range
    If ws Is Nothing Then Exit Sub
    Set valueCell = ws.Cells(BAL_VALUE_ROW, c)

    If enabled Then
        If IsBalancePlaceholder(valueCell.Value) Then valueCell.ClearContents
        valueCell.Locked = False
        valueCell.NumberFormatLocal = "#,##0.########"
        valueCell.Interior.Color = RGB(248, 250, 252)
        valueCell.Font.Color = RGB(15, 23, 42)
        ws.Cells(BAL_LABEL_ROW, c).Interior.Color = RGB(219, 234, 254)
        ws.Cells(BAL_LABEL_ROW, c).Font.Color = RGB(30, 64, 175)
        ws.Cells(BAL_DATE_ROW, c).Interior.Color = RGB(241, 245, 249)
        ws.Cells(BAL_DATE_ROW, c).Font.Color = RGB(71, 85, 105)
    Else
        '���t��ύX���������œ��͍ςݎc��������Ȃ��悤�A�l�͕ێ����ĕ\�������𖳌�������B
        '���ł̕\���p�n�C�t���͎��f�[�^�ł͂Ȃ����ߏ�������B
        If IsBalancePlaceholder(valueCell.Value) Then valueCell.ClearContents
        valueCell.Locked = True
        valueCell.NumberFormatLocal = """-"";""-"";""-"";""-"""
        valueCell.Interior.Color = RGB(241, 245, 249)
        valueCell.Font.Color = RGB(148, 163, 184)
        ws.Cells(BAL_LABEL_ROW, c).Interior.Color = RGB(229, 231, 235)
        ws.Cells(BAL_LABEL_ROW, c).Font.Color = RGB(100, 116, 139)
        ws.Cells(BAL_DATE_ROW, c).Interior.Color = RGB(243, 244, 246)
        ws.Cells(BAL_DATE_ROW, c).Font.Color = RGB(148, 163, 184)
    End If
End Sub

Public Function ValidateBalanceInputStructure(ByVal ws As Worksheet, ByRef detailText As String) As Boolean
    '�c�����Đ�����̎�������B���o���E����E���̑���������Ȃ���Ԃ𐬌������ɂ��Ȃ��B
    Dim memoCol As Long
    Dim c As Long
    Dim problems As String
    Dim expectedLabels As Collection, expectedDates As Collection
    Dim expectedIndex As Long
    Dim expectedLabel As String
    Dim startYear As Long, endYear As Long
    Dim labelArea As Range, valueArea As Range
    Dim expectedAddress As String
    If ws Is Nothing Then
        detailText = "���̓V�[�g���擾�ł��܂���B"
        Exit Function
    End If
    If Not ValidateBalanceYearSettings(startYear, endYear, detailText) Then Exit Function
    memoCol = BalanceMemoCol(ws)
    If memoCol <= BAL_FIRST_COL Or memoCol > BAL_MAX_COL Then problems = problems & "���̑����̈ʒu���s���ł��B "
    BuildBalanceCollections expectedLabels, expectedDates
    CapBalanceCollections expectedLabels, expectedDates, BAL_MAX_LABELS
    If memoCol - BAL_FIRST_COL <> expectedDates.Count Then problems = problems & "�ݒ�Ǝc���񐔂���v���܂���B�c�������Đ������Ă��������B "
    For c = BAL_FIRST_COL To memoCol - 1
        expectedIndex = c - BAL_FIRST_COL + 1
        If Len(CellText(ws.Cells(BAL_LABEL_ROW, c).Value)) = 0 Then problems = problems & ws.Cells(BAL_LABEL_ROW, c).Address(False, False) & "�̌��o���Ȃ��B "
        If expectedIndex <= expectedLabels.Count Then
            expectedLabel = BalanceInputLabelDisplay(CStr(expectedLabels(expectedIndex)))
            If CellText(ws.Cells(BAL_LABEL_ROW, c).Value) <> CellText(expectedLabel) Then
                problems = problems & ws.Cells(BAL_LABEL_ROW, c).Address(False, False) & "�̌��o�����ݒ�ƕs��v�B "
            End If
        End If
        If Not IsDate(ws.Cells(BAL_DATE_ROW, c).Value) Then problems = problems & ws.Cells(BAL_DATE_ROW, c).Address(False, False) & "�̊���s���B "
        If expectedIndex <= expectedDates.Count And IsDate(ws.Cells(BAL_DATE_ROW, c).Value) Then
            If CLng(CDate(ws.Cells(BAL_DATE_ROW, c).Value)) <> CLng(CDate(expectedDates(expectedIndex))) Then
                problems = problems & ws.Cells(BAL_DATE_ROW, c).Address(False, False) & "���ݒ��̊���ƕs��v�B "
            End If
        End If
        If ws.Cells(BAL_LABEL_ROW, c).MergeCells Then _
            problems = problems & ws.Cells(BAL_LABEL_ROW, c).Address(False, False) & "�̎c�����o��������ƌ�������Ă��܂��B "
        If ws.Cells(BAL_VALUE_ROW, c).MergeCells Then _
            problems = problems & ws.Cells(BAL_VALUE_ROW, c).Address(False, False) & "�̎c�����͗�������ƌ�������Ă��܂��B "
    Next c
    If CellText(ws.Cells(BAL_LABEL_ROW, memoCol).Value) <> "���̑�" Then problems = problems & "���̑����̌��o���s���B "
    If memoCol < BAL_MAX_COL Then
        expectedAddress = ws.Range(ws.Cells(BAL_LABEL_ROW, memoCol), _
                                   ws.Cells(BAL_LABEL_ROW, BAL_MAX_COL)).Address(False, False)
        Set labelArea = EffectiveRange(ws.Cells(BAL_LABEL_ROW, memoCol))
        If labelArea Is Nothing Or Not ws.Cells(BAL_LABEL_ROW, memoCol).MergeCells Then
            problems = problems & "���̑����̌��o����������������Ă��܂��B "
        ElseIf labelArea.Address(False, False) <> expectedAddress Then
            problems = problems & "���̑����̌��o�������͈͂��s���ł��B "
        End If

        expectedAddress = ws.Range(ws.Cells(BAL_VALUE_ROW, memoCol), _
                                   ws.Cells(BAL_VALUE_ROW, BAL_MAX_COL)).Address(False, False)
        Set valueArea = EffectiveRange(ws.Cells(BAL_VALUE_ROW, memoCol))
        If valueArea Is Nothing Or Not ws.Cells(BAL_VALUE_ROW, memoCol).MergeCells Then
            problems = problems & "���̑����̓��͌�������������Ă��܂��B "
        ElseIf valueArea.Address(False, False) <> expectedAddress Then
            problems = problems & "���̑����̓��͌����͈͂��s���ł��B "
        End If
    Else
        If ws.Cells(BAL_LABEL_ROW, memoCol).MergeCells Or ws.Cells(BAL_VALUE_ROW, memoCol).MergeCells Then _
            problems = problems & "�ŏI��̂��̑����ɕs�v�Ȍ���������܂��B "
    End If
    detailText = Trim$(problems)
    ValidateBalanceInputStructure = (Len(detailText) = 0)
End Function

Public Function EnsureCaseReadyForOutputs(Optional ByVal showMessage As Boolean = True) As Boolean
    Dim inheritDate As Variant
    inheritDate = GetCfgDateValue(ROW_CFG_INHERITANCE_DATE)
    If Not IsDate(inheritDate) Then
        If showMessage Then
            MsgBox "�ݒ�V�[�g�̑����J�n������͂��Ă��璠�[�E���͂��X�V���Ă��������B" & vbCrLf & _
                   "�Č����ƂɈقȂ�d�v�Ȋ���̂��߁A�����⊮�͂��܂���B", vbExclamation, "�����J�n�������ݒ�ł�"
        End If
        Exit Function
    End If
    EnsureCaseReadyForOutputs = True
End Function

Public Function FirstAvailableBalanceInputCell(ByVal ws As Worksheet) As Range
    Dim memoCol As Long
    Dim c As Long
    If ws Is Nothing Then Exit Function
    memoCol = BalanceMemoCol(ws)
    For c = BAL_FIRST_COL To memoCol - 1
        If Not ws.Cells(BAL_VALUE_ROW, c).Locked Then
            Set FirstAvailableBalanceInputCell = ws.Cells(BAL_VALUE_ROW, c)
            Exit Function
        End If
    Next c
    Set FirstAvailableBalanceInputCell = ws.Cells(BAL_VALUE_ROW, memoCol)
End Function

Public Function NextAvailableBalanceInputCell(ByVal ws As Worksheet, ByVal currentCol As Long, ByVal backwards As Boolean) As Range
    Dim memoCol As Long
    Dim c As Long
    If ws Is Nothing Then Exit Function
    memoCol = BalanceMemoCol(ws)

    If backwards Then
        For c = currentCol - 1 To BAL_FIRST_COL Step -1
            If Not ws.Cells(BAL_VALUE_ROW, c).Locked Then
                Set NextAvailableBalanceInputCell = ws.Cells(BAL_VALUE_ROW, c)
                Exit Function
            End If
        Next c
        Set NextAvailableBalanceInputCell = ws.Range(CELL_CLOSE_DATE)
    Else
        For c = currentCol + 1 To memoCol - 1
            If Not ws.Cells(BAL_VALUE_ROW, c).Locked Then
                Set NextAvailableBalanceInputCell = ws.Cells(BAL_VALUE_ROW, c)
                Exit Function
            End If
        Next c
        If currentCol < memoCol Then
            Set NextAvailableBalanceInputCell = ws.Cells(BAL_VALUE_ROW, memoCol)
        Else
            Set NextAvailableBalanceInputCell = ws.Cells(TX_FIRST_ROW, COL_TX_YEAR)
        End If
    End If
End Function

Public Function NormalizeAccountHyphen(ByVal accountNo As String) As String
    Dim s As String
    s = Trim$(accountNo)
    s = Replace(s, "�|", "-")
    s = Replace(s, "�\", "-")
    s = Replace(s, "�[", "-")
    s = Replace(s, "�", "-")
    NormalizeAccountHyphen = s
End Function

Public Function ValidateBalanceYearSettings(ByRef startYear As Long, ByRef endYear As Long, _
                                            ByRef detailText As String) As Boolean
    Dim startValue As Double, endValue As Double
    detailText = ""
    On Error GoTo InvalidValue
    If Not IsNumeric(GetCfgCell(ROW_CFG_BAL_START_YEAR).Value) Or _
       Not IsNumeric(GetCfgCell(ROW_CFG_BAL_END_YEAR).Value) Then
        detailText = "�c���\���J�n�N�E�I���N�͐���̐��l�œ��͂��Ă��������B"
        Exit Function
    End If
    startValue = CDbl(GetCfgCell(ROW_CFG_BAL_START_YEAR).Value)
    endValue = CDbl(GetCfgCell(ROW_CFG_BAL_END_YEAR).Value)
    If startValue <> Fix(startValue) Or endValue <> Fix(endValue) Then
        detailText = "�c���\���J�n�N�E�I���N�͐����œ��͂��Ă��������B"
        Exit Function
    End If
    If startValue < 1900 Or startValue > 9999 Or endValue < 1900 Or endValue > 9999 Then
        detailText = "�c���\���J�n�N�E�I���N��1900�`9999�͈̔͂œ��͂��Ă��������B"
        Exit Function
    End If
    startYear = CLng(startValue)
    endYear = CLng(endValue)
    If startYear > endYear Then
        detailText = "�c���\���J�n�N�͏I���N�ȑO�ɂ��Ă��������B"
        Exit Function
    End If
    ValidateBalanceYearSettings = True
    Exit Function
InvalidValue:
    detailText = "�c���\���J�n�N�E�I���N�����߂ł��܂���B"
End Function

Public Sub BuildBalanceCollections(ByRef labels As Collection, ByRef dates As Collection)
    Dim startYear As Long
    Dim endYear As Long
    Dim loopStartYear As Long
    Dim inheritDate As Variant
    Dim y As Long
    Dim dYearEnd As Date
    Dim eventAdded As Boolean
    Dim labelText As String
    Dim yearDetail As String
    Set labels = New Collection
    Set dates = New Collection
    If Not ValidateBalanceYearSettings(startYear, endYear, yearDetail) Then
        Err.Raise vbObjectError + 1810, "BuildBalanceCollections", yearDetail
    End If
    loopStartYear = startYear
    If endYear - startYear + 1 > BAL_MAX_LABELS Then loopStartYear = endYear - BAL_MAX_LABELS + 1
    inheritDate = GetCfgDateValue(ROW_CFG_INHERITANCE_DATE)
    For y = loopStartYear To endYear
        dYearEnd = DateSerial(y, 12, 31)
        If IsDate(inheritDate) Then
            If Not eventAdded And CDate(inheritDate) < dYearEnd Then
                labels.Add "�����J�n�����_" & vbLf & "�c���i" & Format$(CDate(inheritDate), "yyyy/m/d") & "�j"
                dates.Add CDate(inheritDate)
                eventAdded = True
            End If
            If CDate(inheritDate) = dYearEnd Then
                labelText = CStr(y) & "�N���E�����J�n�����_" & vbLf & "�c���i" & Format$(CDate(inheritDate), "yyyy/m/d") & "�j"
                eventAdded = True
            Else
                labelText = CStr(y) & "�N���c��"
            End If
        Else
            labelText = CStr(y) & "�N���c��"
        End If
        labels.Add labelText
        dates.Add dYearEnd
    Next y
    If IsDate(inheritDate) And Not eventAdded Then
        labels.Add "�����J�n�����_" & vbLf & "�c���i" & Format$(CDate(inheritDate), "yyyy/m/d") & "�j"
        dates.Add CDate(inheritDate)
    End If
End Sub

Public Function BalanceMemoCol(ByVal ws As Worksheet) As Long
    Dim c As Long
    If ws Is Nothing Then
        BalanceMemoCol = BAL_MAX_COL
        Exit Function
    End If
    For c = BAL_FIRST_COL To BAL_MAX_COL
        If CellText(ws.Cells(BAL_LABEL_ROW, c).Value) = "���̑�" Then
            BalanceMemoCol = c
            Exit Function
        End If
    Next c
    BalanceMemoCol = BAL_MAX_COL
End Function

Public Function EffectiveRange(ByVal rng As Range) As Range
    If rng Is Nothing Then Exit Function
    On Error Resume Next
    If rng.MergeCells Then
        Set EffectiveRange = rng.MergeArea
    Else
        Set EffectiveRange = rng
    End If
    On Error GoTo 0
End Function

Public Sub ApplyValidationInputOnly(ByVal rng As Range, ByVal imeMode As Long, _
                                    Optional ByVal inputTitle As String = "", _
                                    Optional ByVal inputMessage As String = "")
    Dim target As Range
    If rng Is Nothing Then Exit Sub
    Set target = EffectiveRange(rng)
    If target Is Nothing Then Set target = rng
    On Error Resume Next
    target.Validation.Delete
    target.Validation.Add Type:=xlValidateInputOnly
    target.Validation.IgnoreBlank = True
    target.Validation.IMEMode = imeMode
    target.Validation.ShowInput = (Len(inputTitle) > 0 Or Len(inputMessage) > 0)
    If Len(inputTitle) > 0 Then target.Validation.InputTitle = inputTitle
    If Len(inputMessage) > 0 Then target.Validation.InputMessage = inputMessage
    On Error GoTo 0
End Sub

Public Function SetToolShapePrintState(ByVal ws As Worksheet, ByVal shapeName As String, _
                                       ByVal printEnabled As Boolean) As Boolean
    '��ʑ���p�̐}�`�𒠕[�ֈ�����Ȃ��BDrawingObject��x���o�C���h���A
    '�I�[�g�V�F�C�v�ƃt�H�[���{�^���̑o���𓯂����@�ň����B
    Dim drawingObject As Object
    On Error GoTo EH
    If ws Is Nothing Or Len(shapeName) = 0 Then Exit Function
    Set drawingObject = ws.DrawingObjects(shapeName)
    drawingObject.PrintObject = printEnabled
    SetToolShapePrintState = (CBool(drawingObject.PrintObject) = printEnabled)
    Exit Function
EH:
    SetToolShapePrintState = False
    Err.Clear
End Function

Public Function ToolShapePrintState(ByVal ws As Worksheet, ByVal shapeName As String, _
                                    ByRef stateKnown As Boolean) As Boolean
    Dim drawingObject As Object
    On Error GoTo EH
    stateKnown = False
    If ws Is Nothing Or Len(shapeName) = 0 Then Exit Function
    Set drawingObject = ws.DrawingObjects(shapeName)
    ToolShapePrintState = CBool(drawingObject.PrintObject)
    stateKnown = True
    Exit Function
EH:
    stateKnown = False
    Err.Clear
End Function

Public Sub ApplyValidationList(ByVal rng As Range, ByVal listName As String, _
                               ByVal imeMode As Long, _
                               Optional ByVal allowFreeText As Boolean = True, _
                               Optional ByVal inputTitle As String = "", _
                               Optional ByVal inputMessage As String = "")
    Dim target As Range
    If rng Is Nothing Then Exit Sub
    Set target = EffectiveRange(rng)
    If target Is Nothing Then Set target = rng
    On Error Resume Next
    target.Validation.Delete
    target.Validation.Add Type:=xlValidateList, AlertStyle:=xlValidAlertStop, Operator:=xlBetween, Formula1:="=" & listName
    target.Validation.IgnoreBlank = True
    target.Validation.InCellDropdown = True
    target.Validation.ShowError = Not allowFreeText
    target.Validation.IMEMode = imeMode
    target.Validation.ShowInput = (Len(inputTitle) > 0 Or Len(inputMessage) > 0)
    If Len(inputTitle) > 0 Then target.Validation.InputTitle = inputTitle
    If Len(inputMessage) > 0 Then target.Validation.InputMessage = inputMessage
    On Error GoTo 0
End Sub

Public Sub UnlockRange(ByVal rng As Range)
    Dim target As Range
    If rng Is Nothing Then Exit Sub
    Set target = EffectiveRange(rng)
    If target Is Nothing Then Set target = rng
    On Error Resume Next
    target.Locked = False
    On Error GoTo 0
End Sub

Public Sub MergeAndFormat(ByVal rng As Range, ByVal valueText As String, Optional ByVal mergeCells As Boolean = True)
    If rng Is Nothing Then Exit Sub
    On Error Resume Next
    rng.UnMerge
    If mergeCells Then rng.Merge
    rng.Value = valueText
    rng.WrapText = True
    rng.VerticalAlignment = xlCenter
    On Error GoTo 0
End Sub


Public Sub ClearEffectiveContents(ByVal rng As Range)
    Dim target As Range
    If rng Is Nothing Then Exit Sub
    Set target = EffectiveRange(rng)
    If target Is Nothing Then Set target = rng
    On Error Resume Next
    target.ClearContents
    On Error GoTo 0
End Sub

Public Sub AutoFitSheetSmart(ByVal ws As Worksheet, Optional ByVal columnsAddress As String = "", Optional ByVal minWidth As Double = 6, Optional ByVal maxWidth As Double = 34)
    '�񕝁E�s���̎��������BUsedRange����債�Ă���u�b�N�ł��d���Ȃ�Ȃ��悤�A
    '�l�E�����������Ă�����͈͂���ɂ���B
    Dim rngCols As Range
    Dim rngRows As Range
    Dim c As Range
    Dim r As Range
    Dim lastR As Long
    Dim lastC As Long
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    lastR = LastUsedRowInSheet(ws)
    If lastR < 1 Then lastR = 1
    lastC = LastUsedColumnInSheet(ws, lastR)
    If lastC < 1 Then lastC = 1

    If Len(columnsAddress) > 0 Then
        Set rngCols = ws.Columns(columnsAddress)
    Else
        Set rngCols = ws.Range(ws.Cells(1, 1), ws.Cells(1, lastC)).EntireColumn
    End If
    If Not rngCols Is Nothing Then
        rngCols.AutoFit
        For Each c In rngCols.Columns
            If c.ColumnWidth < minWidth Then c.ColumnWidth = minWidth
            If c.ColumnWidth > maxWidth Then c.ColumnWidth = maxWidth
        Next c
    End If

    Set rngRows = ws.Range(ws.Rows(1), ws.Rows(lastR))
    If lastR <= MAX_DETAILED_AUTOFIT_ROWS Then
        rngRows.AutoFit
        For Each r In rngRows.Rows
            If r.RowHeight < 18 Then r.RowHeight = 18
            If r.RowHeight > 72 Then r.RowHeight = 72
        Next r
    Else
        '��ʍs�ł͍s���Ƃ�AutoFit�ƍ�������������A���肵���ꗗ�����ֈꊇ�ݒ肷��B
        rngRows.RowHeight = 20
        ws.Rows(1).AutoFit
    End If
    On Error GoTo 0
End Sub

Public Sub PolishInputLayout(Optional ByVal ws As Worksheet = Nothing)
    If ws Is Nothing Then
        If Not SheetExists(SH_INPUT) Then Exit Sub
        Set ws = GetSheet(SH_INPUT)
    End If
    ApplyInputColumnWidths ws
    ApplyInputBalancePresentation ws
End Sub
Private Sub ApplyInputColumnWidths(ByVal ws As Worksheet)
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    '���͓��e�ɍ��킹�ĕ���ς��A�N�E���E���֕s�v�ȗ]�����������Ȃ��B
    '���z�A�戵�X�A�E�v�͓��͒��̊m�F�ɕK�v�ȕ���D�悷��B
    ws.Columns("A:A").ColumnWidth = 1.5
    ws.Columns("B:E").ColumnWidth = 10
    ws.Columns("F:G").ColumnWidth = 14.5
    ws.Columns("H:H").ColumnWidth = 16.5
    ws.Columns("I:I").ColumnWidth = 10.5
    ws.Columns("J:J").ColumnWidth = 22
    ws.Columns("K:K").ColumnWidth = 16.5
    ws.Columns("L:V").ColumnWidth = 10
    ws.Columns("W:W").ColumnWidth = 1.5

    ws.Rows("1:1").RowHeight = 6
    ws.Rows("2:" & CStr(TX_HEADER_ROW)).RowHeight = 20
    ws.Rows(2).RowHeight = 28
    ws.Rows(3).RowHeight = 6
    ws.Rows(4).RowHeight = 22
    ws.Rows("5:7").RowHeight = 22
    ws.Rows(8).RowHeight = 20
    ws.Rows(INPUT_BALANCE_HEADER_ROW).RowHeight = 22
    ws.Rows(BAL_LABEL_ROW).RowHeight = 36
    ws.Rows(BAL_VALUE_ROW).RowHeight = 26
    ws.Rows(BAL_DATE_ROW).RowHeight = 17
    ws.Rows(INPUT_STATUS_ROW).RowHeight = 25
    ws.Rows(TX_HEADER_ROW - 1).RowHeight = 6
    ws.Rows(TX_HEADER_ROW).RowHeight = 28
    ws.Rows(TX_FIRST_ROW & ":" & TX_LAST_ROW).RowHeight = 22

    ws.Range("B2:K" & CStr(INPUT_STATUS_ROW)).WrapText = True
    With ws.Range(ws.Cells(BAL_LABEL_ROW, BAL_FIRST_COL), ws.Cells(BAL_LABEL_ROW, BAL_MAX_COL))
        .WrapText = True
        .ShrinkToFit = False
        .Font.Size = 9
    End With
    With ws.Range(ws.Cells(BAL_VALUE_ROW, BAL_FIRST_COL), ws.Cells(BAL_VALUE_ROW, BAL_MAX_COL))
        .ShrinkToFit = True
        .Font.Size = 9.5
    End With
    '����p�l���̃Z���͈͂����ܕԂ���؂�B10�`12�s�ڂ͎c�����o���E���́E����Ȃ̂ŁA
    'M��ȍ~���ꊇ�w�肷��ƒ����c�����o�����ǂ߂Ȃ��Ȃ�B
    ws.Range(ws.Cells(2, INPUT_PANEL_FIRST_COL), _
             ws.Cells(8, INPUT_PANEL_LAST_COL)).WrapText = False
    With EffectiveRange(ws.Range(CELL_STATUS))
        .WrapText = True
        .ShrinkToFit = True
        .VerticalAlignment = xlCenter
    End With
    ws.Range(ws.Cells(TX_FIRST_ROW, COL_TX_YEAR), _
             ws.Cells(TX_LAST_ROW, COL_TX_BALANCE)).WrapText = False
    ws.ScrollArea = "A1:W" & CStr(TX_LAST_ROW)
    On Error GoTo 0
End Sub

Private Sub ApplyInputBalancePresentation(ByVal ws As Worksheet)
    '�ʏ�͑���p�l���E�[Q��܂ł�\�����A�c�����_�������Č������K�v���i�K�I�ɊJ���B
    '�u���̑��v��V��܂ŋ���\�������܂܂ɂ����A���͕\�E����E�c���̉E�[�𑵂���B
    Dim c As Long
    Dim memoCol As Long, lastVisibleCol As Long
    Dim headerArea As Range, visibleHeader As Range
    If ws Is Nothing Then Exit Sub
    On Error GoTo EH

    ws.Range(ws.Columns(BAL_FIRST_COL), ws.Columns(BAL_MAX_COL)).EntireColumn.Hidden = False
    memoCol = 0
    For c = BAL_FIRST_COL To BAL_MAX_COL
        If CellText(ws.Cells(BAL_LABEL_ROW, c).Value) = "���̑�" Then
            memoCol = c
            Exit For
        End If
    Next c

    lastVisibleCol = INPUT_SCREEN_LAST_COL
    If memoCol >= BAL_FIRST_COL Then
        lastVisibleCol = Application.Max(INPUT_SCREEN_LAST_COL, _
            Application.Min(BAL_MAX_COL, memoCol + INPUT_BALANCE_MEMO_VISIBLE_COLS - 1))
    End If

    Set headerArea = ws.Range(ws.Cells(INPUT_BALANCE_HEADER_ROW, BAL_FIRST_COL), _
                              ws.Cells(INPUT_BALANCE_HEADER_ROW, BAL_MAX_COL))
    headerArea.UnMerge
    headerArea.ClearContents
    Set visibleHeader = ws.Range(ws.Cells(INPUT_BALANCE_HEADER_ROW, BAL_FIRST_COL), _
                                 ws.Cells(INPUT_BALANCE_HEADER_ROW, lastVisibleCol))
    MergeAndFormat visibleHeader, "�c������"
    FormatHeader visibleHeader
    visibleHeader.HorizontalAlignment = xlLeft
    visibleHeader.VerticalAlignment = xlCenter

    If lastVisibleCol < BAL_MAX_COL Then
        ws.Range(ws.Columns(lastVisibleCol + 1), ws.Columns(BAL_MAX_COL)).EntireColumn.Hidden = True
    End If
    Exit Sub
EH:
    '�\�������̎��s����̓f�[�^�j���֔g�y�����Ȃ��B�ďo���̃Z���t�`�F�b�N�Ō��m����B
End Sub
Public Sub AutoFitInputSheetSmart(ByVal ws As Worksheet)
    Dim c As Long
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    '���o���Ɩ��ׂ���xAutoFit���A���̌�Ŏ�����K�v�ȍŒᕝ��ۏ؂���B
    ws.Range(ws.Cells(TX_HEADER_ROW, COL_TX_YEAR), _
             ws.Cells(TX_LAST_ROW, COL_TX_BALANCE)).Columns.AutoFit
    For c = 2 To 11
        If ws.Columns(c).ColumnWidth < 13.2 Then ws.Columns(c).ColumnWidth = 13.2
        If c = COL_TX_TEKIYO And ws.Columns(c).ColumnWidth < 17 Then ws.Columns(c).ColumnWidth = 17
        If c = COL_TX_BALANCE And ws.Columns(c).ColumnWidth < 16 Then ws.Columns(c).ColumnWidth = 16
        If ws.Columns(c).ColumnWidth > 32 Then ws.Columns(c).ColumnWidth = 32
    Next c
    ws.Rows("1:" & TX_LAST_ROW).AutoFit
    PolishInputLayout ws
    BuildOperationPanel ws
    BuildInputHelpCards ws
    On Error GoTo 0
End Sub
Public Sub AutoFitToolLayout()
    '���{�^�����E���}�N�����Ƃ̌݊��p�B���̂͏��������֊񂹂�B
    RestoreToolFormatting
End Sub

Public Sub RestoreToolFormatting()
    Dim ws As Worksheet
    Dim balanceArea As Range
    Dim balanceSnapshot As Variant
    Dim balanceMemoColBefore As Long
    Dim balanceSignatureBefore As String
    Dim errorNumber As Long, errorDescription As String
    '���̑����VBA������~��̕������ړI�Ƃ��邽�߁A�ޔ���Ԃ������Ă��Ă����S����l�֖߂��B
    AppForceRestore True
    'Excel�S�̂̃C�x���g�E�v�Z���ɖ߂��B�Č��f�[�^�����������^�v�����Ȃ�A�����č\�z�͍s��Ȃ��B
    If Not RequireToolReady() Then Exit Sub
    On Error GoTo EH
    AppBegin "�����𕜋����Ă��܂�..."

    If SheetExists(SH_INPUT) Then
        Set ws = GetSheet(SH_INPUT)
        ws.Unprotect Password:=TOOL_PASSWORD
        Set balanceArea = ws.Range(ws.Cells(BAL_LABEL_ROW, BAL_FIRST_COL), _
                                   ws.Cells(BAL_DATE_ROW, BAL_MAX_COL))
        balanceSnapshot = balanceArea.Formula
        balanceMemoColBefore = BalanceMemoCol(ws)
        balanceSignatureBefore = BalanceInputStateSignature(ws)
        PolishInputLayout ws
        RestoreAllTransactionRowStyles ws
        BuildOperationPanel ws
        BuildInputHelpCards ws
        ApplyInputSettings False, True
        If BalanceInputStateSignature(ws) <> balanceSignatureBefore Then
            RestoreBalanceInputSnapshot ws, balanceSnapshot, balanceMemoColBefore
            Err.Raise vbObjectError + 4401, "RestoreToolFormatting", _
                      "�\���������Ɏc�����̓��e�܂��͌�����Ԃ��ω��������߁A�����O�̏�Ԃ֖߂��܂����B"
        End If
    End If

    If SheetExists(SH_WORK_CASH) Then FormatCashOperationOutputLayout GetSheet(SH_WORK_CASH)
    If SheetExists(SH_OUTPUT_TX) Then FormatCashAnalysisViewLayout GetSheet(SH_OUTPUT_TX)
    If SheetExists(SH_OUTPUT_TX_CONVERTED) Then FormatCashOperationOutputLayout GetSheet(SH_OUTPUT_TX_CONVERTED)
    If SheetExists(SH_SHOP_TARGET) Then FormatShopConversionTargetSheet GetSheet(SH_SHOP_TARGET)
    If SheetExists(SH_OUTPUT_BAL) Then FormatBalanceTransitionOutputLayout GetSheet(SH_OUTPUT_BAL)
    If SheetExists(SH_ANALYSIS_SHIFT) And SheetExists(SH_ANALYSIS_FLOW) And _
       SheetExists(SH_ANALYSIS_UNKNOWN) Then FormatTransactionAnalysisSheets
    If SheetExists(SH_WORK_TX) Then FormatWorkTx
    If SheetExists(SH_WORK_BAL) Then FormatWorkBal

    If SheetExists(SH_INPUT) Then FixUnreadableWhiteTextOnSheet GetSheet(SH_INPUT)
    If SheetExists(SH_WORK_CASH) Then FixUnreadableWhiteTextOnSheet GetSheet(SH_WORK_CASH)
    If SheetExists(SH_OUTPUT_TX) Then FixUnreadableWhiteTextOnSheet GetSheet(SH_OUTPUT_TX)
    If SheetExists(SH_OUTPUT_TX_CONVERTED) Then FixUnreadableWhiteTextOnSheet GetSheet(SH_OUTPUT_TX_CONVERTED)
    If SheetExists(SH_SHOP_TARGET) Then FixUnreadableWhiteTextOnSheet GetSheet(SH_SHOP_TARGET)
    If SheetExists(SH_OUTPUT_BAL) Then FixUnreadableWhiteTextOnSheet GetSheet(SH_OUTPUT_BAL)
    If SheetExists(SH_ANALYSIS_SHIFT) Then FixUnreadableWhiteTextOnSheet GetSheet(SH_ANALYSIS_SHIFT)
    If SheetExists(SH_ANALYSIS_FLOW) Then FixUnreadableWhiteTextOnSheet GetSheet(SH_ANALYSIS_FLOW)
    If SheetExists(SH_ANALYSIS_UNKNOWN) Then FixUnreadableWhiteTextOnSheet GetSheet(SH_ANALYSIS_UNKNOWN)
    If SheetExists(SH_ANALYSIS_RESULT) Then FixUnreadableWhiteTextOnSheet GetSheet(SH_ANALYSIS_RESULT)
    If SheetExists(SH_ANALYSIS_DETAIL) Then FixUnreadableWhiteTextOnSheet GetSheet(SH_ANALYSIS_DETAIL)

    If SheetExists(SH_INPUT) Then LockToolShapes GetSheet(SH_INPUT)
    If SheetExists(SH_SHOP_TARGET) Then LockToolShapes GetSheet(SH_SHOP_TARGET)

    ProtectInputSheet True
    If SheetExists(SH_CONFIG) Then ProtectConfigSheet True
    ProtectAllCandidateSheets True
    If SheetExists(SH_REGISTERED_ACCOUNTS) Then ProtectRegisteredAccountsSheet True
    If SheetExists(SH_SHOP_TARGET) Then ProtectShopConversionTargetSheet True
    If SheetExists(SH_OUTPUT_TX) Then ProtectCashAnalysisViewSheet
    ProtectTransactionAnalysisSheets True
    EnableInputKeys
    AppEnd
    MsgBox "�\���𐮂������܂����B���͗��E�{�^���E���[�E���͕\�̔z�u�ƕی���ēK�p���܂����B", _
           vbInformation, "�\�������̊���"
    Exit Sub
EH:
    errorNumber = Err.Number: errorDescription = Err.Description
    ProtectInputSheet
    If SheetExists(SH_CONFIG) Then ProtectConfigSheet
    ProtectAllCandidateSheets
    If SheetExists(SH_REGISTERED_ACCOUNTS) Then ProtectRegisteredAccountsSheet
    If SheetExists(SH_SHOP_TARGET) Then ProtectShopConversionTargetSheet
    If SheetExists(SH_OUTPUT_TX) Then ProtectCashAnalysisViewSheet
    ProtectTransactionAnalysisSheets
    EnableInputKeys
    AppEnd
    MsgBox "�����������ɃG���[���������܂����B" & vbCrLf & "Err " & errorNumber & ": " & errorDescription, vbExclamation
End Sub

Private Function BalanceInputStateSignature(ByVal ws As Worksheet) As String
    Dim r As Long, c As Long
    Dim cell As Range
    Dim valueIn As Variant
    Dim mergeAddress As String
    Dim token As String
    If ws Is Nothing Then Exit Function
    For r = BAL_LABEL_ROW To BAL_DATE_ROW
        For c = BAL_FIRST_COL To BAL_MAX_COL
            Set cell = ws.Cells(r, c)
            valueIn = cell.Formula
            If r = BAL_VALUE_ROW And IsBalancePlaceholder(valueIn) Then valueIn = Empty
            mergeAddress = "-"
            If cell.MergeCells Then mergeAddress = cell.MergeArea.Address(False, False)
            token = SnapshotValueToken(valueIn)
            BalanceInputStateSignature = BalanceInputStateSignature & _
                                         CStr(r) & ":" & CStr(c) & ":" & _
                                         CStr(Len(token)) & ":" & token & ":" & _
                                         CStr(Len(mergeAddress)) & ":" & mergeAddress & "|"
        Next c
    Next r
End Function

Private Function SnapshotValueToken(ByVal valueIn As Variant) As String
    Dim valueText As String
    If IsError(valueIn) Then
        SnapshotValueToken = "Error"
    ElseIf IsNull(valueIn) Then
        SnapshotValueToken = "Null"
    ElseIf IsEmpty(valueIn) Then
        SnapshotValueToken = "Empty"
    Else
        valueText = CStr(valueIn)
        SnapshotValueToken = CStr(VarType(valueIn)) & ":" & CStr(Len(valueText)) & ":" & valueText
    End If
End Function

Private Sub RestoreBalanceInputSnapshot(ByVal ws As Worksheet, ByVal snapshot As Variant, _
                                        ByVal memoCol As Long)
    Dim target As Range
    If ws Is Nothing Then Exit Sub
    Set target = ws.Range(ws.Cells(BAL_LABEL_ROW, BAL_FIRST_COL), _
                          ws.Cells(BAL_DATE_ROW, BAL_MAX_COL))
    target.UnMerge
    target.Formula = snapshot
    If memoCol >= BAL_FIRST_COL And memoCol < BAL_MAX_COL Then
        ws.Range(ws.Cells(BAL_LABEL_ROW, memoCol), _
                 ws.Cells(BAL_LABEL_ROW, BAL_MAX_COL)).Merge
        ws.Range(ws.Cells(BAL_VALUE_ROW, memoCol), _
                 ws.Cells(BAL_VALUE_ROW, BAL_MAX_COL)).Merge
    End If
End Sub

Public Sub RestoreAllTransactionRowStyles(Optional ByVal ws As Worksheet = Nothing)
    Const STRIPE_BATCH_ROWS As Long = 200
    Dim r As Long, batchCount As Long
    Dim oddRows As Range, rowRange As Range
    If ws Is Nothing Then
        If Not SheetExists(SH_INPUT) Then Exit Sub
        Set ws = GetSheet(SH_INPUT)
    End If
    With ws.Range(ws.Cells(TX_FIRST_ROW, COL_TX_YEAR), _
                  ws.Cells(TX_LAST_ROW, COL_TX_BALANCE))
        .Interior.Color = RGB(255, 255, 255)
        .Font.Color = RGB(15, 23, 42)
        .Borders.LineStyle = xlContinuous
        .Borders.Color = RGB(226, 232, 240)
    End With
    For r = TX_FIRST_ROW + 1 To TX_LAST_ROW Step 2
        Set rowRange = ws.Range(ws.Cells(r, COL_TX_YEAR), ws.Cells(r, COL_TX_BALANCE))
        If oddRows Is Nothing Then
            Set oddRows = rowRange
        Else
            Set oddRows = Union(oddRows, rowRange)
        End If
        batchCount = batchCount + 1
        If batchCount = STRIPE_BATCH_ROWS Then
            oddRows.Interior.Color = RGB(248, 250, 252)
            Set oddRows = Nothing
            batchCount = 0
        End If
    Next r
    If Not oddRows Is Nothing Then oddRows.Interior.Color = RGB(248, 250, 252)
End Sub
Public Sub AddCheck(ByVal levelText As String, ByVal sourceText As String, ByVal messageText As String)
    Dim ws As Worksheet
    Dim r As Long
    On Error Resume Next
    Set ws = GetOrCreateSheet(SH_CHECK, False)
    If ws Is Nothing Then Exit Sub
    If Len(CellText(ws.Range("A1").Value)) = 0 Then SetRowValues ws.Range("A1"), Array("�敪", "������", "���e", "�L�^����")
    r = ws.Cells(ws.Rows.Count, 1).End(xlUp).Row + 1
    If r < 2 Then r = 2
    ws.Range(ws.Cells(r, 1), ws.Cells(r, 3)).NumberFormatLocal = "@"
    ws.Cells(r, 4).NumberFormatLocal = "yyyy/m/d h:mm:ss"
    ws.Cells(r, 1).Value = levelText
    ws.Cells(r, 2).Value = sourceText
    ws.Cells(r, 3).Value = messageText
    ws.Cells(r, 4).Value = Now
    On Error GoTo 0
End Sub

Public Sub SafeSelectCell(ByVal ws As Worksheet, ByVal addressText As String)
    On Error Resume Next
    If ws Is Nothing Then Exit Sub
    ThisWorkbook.Activate
    ws.Activate
    ws.Range(addressText).Select
    On Error GoTo 0
End Sub

Public Sub SafeFreezeOutputHeader(ByVal ws As Worksheet)
    SafeFreezeSheetAt ws, "A2"
End Sub

Public Sub ApplyActiveSheetWindowStyle(ByVal ws As Worksheet)
    Dim win As Window
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    RestoreToolSheetScrollArea ws
    If Not ActiveWorkbook Is ThisWorkbook Then Exit Sub
    If ActiveSheet.Name <> ws.Name Then Exit Sub
    Set win = Application.ActiveWindow
    If win Is Nothing Then Exit Sub
    win.DisplayGridlines = False
    win.DisplayHeadings = True
    On Error GoTo 0
End Sub

Public Sub RestoreAllToolSheetScrollAreas()
    'ScrollArea�̓u�b�N�����Ǝ����邽�߁A�N���E�ăA�N�e�B�u���̂��тɕ�������B
    '��ʊO�֖������ޑ���ƁA�}�`���ӂ̌�h���b�O��ɖ߂�Ȃ��Ȃ�X�g���X��h���B
    Dim ws As Worksheet
    Dim workbookWasSaved As Boolean
    Dim errorNumber As Long, errorDescription As String
    workbookWasSaved = ThisWorkbook.Saved
    On Error GoTo EH
    For Each ws In ThisWorkbook.Worksheets
        RestoreToolSheetScrollArea ws
    Next ws
    If workbookWasSaved Then ThisWorkbook.Saved = True
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    If workbookWasSaved Then ThisWorkbook.Saved = True
    Err.Raise errorNumber, "RestoreAllToolSheetScrollAreas", errorDescription
End Sub

Public Sub RestoreToolSheetScrollArea(ByVal ws As Worksheet)
    Dim lastR As Long, lastC As Long, bottomRow As Long
    Dim areaText As String
    If ws Is Nothing Then Exit Sub

    Select Case ws.Name
        Case SH_INPUT
            areaText = "A1:W" & CStr(TX_LAST_ROW)
        Case SH_CONFIG
            areaText = "A1:H" & CStr(ERA_MASTER_MAX_ROW + 3)
        Case SH_BANK_CAND, SH_BRANCH_CAND, SH_PERSON_CAND, SH_ACCOUNT_TYPE, SH_TEKIYO
            bottomRow = Application.Min(ws.Rows.Count, _
                        Application.Max(500, LastRow(ws, 1) + 500))
            areaText = "A1:J" & CStr(bottomRow)
        Case SH_INPUT_MODE, SH_YEAR_MODE, SH_DISPLAY_OPTION, SH_POST_KEEP, SH_POST_CLEAR, SH_ANALYSIS_STATUS
            bottomRow = Application.Min(ws.Rows.Count, _
                        Application.Max(50, LastUsedRowInSheet(ws) + 20))
            areaText = "A1:D" & CStr(bottomRow)
        Case SH_REGISTERED_ACCOUNTS, SH_SHOP_TARGET
            bottomRow = Application.Min(ws.Rows.Count, _
                        Application.Max(50, LastUsedRowInSheet(ws) + 20))
            areaText = "A1:M" & CStr(bottomRow)
        Case SH_OUTPUT_TX
            bottomRow = Application.Min(ws.Rows.Count, _
                        Application.Max(60, LastUsedRowInSheet(ws) + 20))
            areaText = "A1:M" & CStr(bottomRow)
        Case SH_OUTPUT_TX_CONVERTED
            bottomRow = Application.Min(ws.Rows.Count, _
                        Application.Max(50, LastUsedRowInSheet(ws) + 20))
            areaText = "A1:M" & CStr(bottomRow)
        Case SH_OUTPUT_BAL
            lastR = Application.Max(1, LastUsedRowInSheet(ws))
            lastC = Application.Max(1, LastUsedColumnInSheet(ws, lastR))
            bottomRow = Application.Min(ws.Rows.Count, Application.Max(50, lastR + 20))
            areaText = "A1:" & ExcelColumnLetter(lastC) & CStr(bottomRow)
        Case SH_ANALYSIS_SHIFT
            bottomRow = Application.Min(ws.Rows.Count, _
                        Application.Max(50, LastUsedRowInSheet(ws) + 20))
            areaText = "A1:" & ExcelColumnLetter(SHIFT_ANALYSIS_LAST_COL) & CStr(bottomRow)
        Case SH_ANALYSIS_FLOW
            bottomRow = Application.Min(ws.Rows.Count, _
                        Application.Max(50, LastUsedRowInSheet(ws) + 20))
            areaText = "A1:" & ExcelColumnLetter(FLOW_ANALYSIS_LAST_COL) & CStr(bottomRow)
        Case SH_ANALYSIS_UNKNOWN
            bottomRow = Application.Min(ws.Rows.Count, _
                        Application.Max(50, LastUsedRowInSheet(ws) + 20))
            areaText = "A1:" & ExcelColumnLetter(UNKNOWN_ANALYSIS_LAST_COL) & CStr(bottomRow)
        Case SH_ANALYSIS_RESULT
            bottomRow = Application.Min(ws.Rows.Count, _
                        Application.Max(50, LastUsedRowInSheet(ws) + 20))
            areaText = "A1:I" & CStr(bottomRow)
        Case SH_ANALYSIS_DETAIL
            bottomRow = Application.Min(ws.Rows.Count, _
                        Application.Max(50, LastUsedRowInSheet(ws) + 20))
            areaText = "A1:G" & CStr(bottomRow)
        Case SH_BALANCE_RECONCILIATION
            bottomRow = Application.Min(ws.Rows.Count, _
                        Application.Max(50, LastUsedRowInSheet(ws) + 20))
            areaText = "A1:" & ExcelColumnLetter(BALANCE_RECONCILIATION_LAST_COL) & CStr(bottomRow)
        Case SH_CHECK
            bottomRow = Application.Min(ws.Rows.Count, _
                        Application.Max(50, LastUsedRowInSheet(ws) + 20))
            areaText = "A1:D" & CStr(bottomRow)
    End Select

    If Len(areaText) > 0 Then ws.ScrollArea = areaText
End Sub

Public Function ConfirmLargeArrayOperation(ByVal rowCount As Long, _
                                           ByVal operationName As String) As Boolean
    '32bit��Excel�ł͑傫��Variant�z��𕡐��ێ�����ƁA�s�������Ƀ������s���֒B���₷���B
    '�f�[�^������������O�ɗ��p�҂֎~�܂�I�������o���A�r����~�������B
#If Win64 Then
    ConfirmLargeArrayOperation = True
#ElseIf Mac Then
    '���sMac��Office��64bit�BWindows������32bit�x���͏o���Ȃ��B
    ConfirmLargeArrayOperation = True
#Else
    If rowCount <= 75000 Then
        ConfirmLargeArrayOperation = True
    Else
        ConfirmLargeArrayOperation = _
            (MsgBox(operationName & "�͖�" & Format$(rowCount, "#,##0") & _
                    "�s���ꊇ�������܂��B" & vbCrLf & _
                    "32bit��Excel�ł̓������s���ɂȂ�\��������܂��B" & vbCrLf & _
                    "���̃u�b�N����A�\�ł����64bit��Excel�Ŏ��s���Ă��������B" & _
                    vbCrLf & vbCrLf & "���̂܂ܑ��s���܂����H", _
                    vbYesNo + vbExclamation + vbDefaultButton2, _
                    "��e�ʏ����̎��O�m�F") = vbYes)
    End If
#End If
End Function

Public Sub SafeFreezeSheetAt(ByVal ws As Worksheet, ByVal freezeAddress As String, _
                             Optional ByVal zoomPercent As Long = 0)
    Dim prevSheet As Worksheet
    Dim win As Window
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    Set prevSheet = ActiveSheet
    If ws.Visible <> xlSheetVisible Then ws.Visible = xlSheetVisible
    ThisWorkbook.Activate
    ws.Activate
    Set win = Application.ActiveWindow
    If Not win Is Nothing Then
        win.DisplayGridlines = False
        win.DisplayHeadings = True
        win.FreezePanes = False
        win.SplitColumn = 0
        win.SplitRow = 0
        ws.Range(freezeAddress).Select
        win.FreezePanes = True
        If zoomPercent >= 50 And zoomPercent <= 200 Then win.Zoom = zoomPercent
    End If
    If Not prevSheet Is Nothing Then prevSheet.Activate
    On Error GoTo 0
End Sub

Public Sub SafeFreezeInput()
    Dim ws As Worksheet
    Dim win As Window
    On Error Resume Next
    Set ws = ThisWorkbook.Worksheets(SH_INPUT)
    If ws Is Nothing Then Exit Sub
    ThisWorkbook.Activate
    ws.Activate
    Set win = Application.ActiveWindow
    If win Is Nothing Then Exit Sub
    win.DisplayGridlines = False
    win.DisplayHeadings = True
    win.FreezePanes = False
    ws.Cells(TX_FIRST_ROW, COL_TX_YEAR).Select
    win.FreezePanes = True
    '�W����Ԃł͓��͕\��2��̑���p�l����������ʂɎ��܂�₷���{���ɂ���B
    '���p�҂��ォ��ύX�����{���́A�ʏ�̃V�[�g�ړ��ł͏㏑�����Ȃ��B
    win.Zoom = 90
    win.ScrollColumn = 1
    On Error GoTo 0
End Sub

Public Function RequireToolReady() As Boolean
    Dim dataHealth As String
    RequireToolReady = False
    If Not SheetExists(SH_INPUT) Then
        MsgBox "���̓V�[�g������܂���BSetupWorkbook �����s���Ă��������B", vbExclamation
        Exit Function
    End If
    If Not SheetExists(SH_WORK_TX) Then
        MsgBox "��ƃV�[�g������܂���BSetupWorkbook �����s���Ă��������B", vbExclamation
        Exit Function
    End If
    If Not SheetExists(SH_WORK_BAL) Or Not SheetExists(SH_WORK_ACCOUNT) Or Not SheetExists(SH_WORK_STATE) Then
        MsgBox "�����f�[�^�V�[�g���s�����Ă��܂��BSetupWorkbook �����s���Ă��������B", vbExclamation
        Exit Function
    End If
    If Not SheetExists(SH_CONFIG) Then
        MsgBox "�ݒ�V�[�g������܂���BSetupWorkbook �����s���Ă��������B", vbExclamation
        Exit Function
    End If
    dataHealth = GetStateValue(STATE_DATA_HEALTH, DATA_HEALTH_NORMAL)
    If dataHealth <> DATA_HEALTH_NORMAL Then
        MsgBox "�Č��f�[�^�́u" & dataHealth & "�v��Ԃł��B" & vbCrLf & _
               "�������܂��͍ăZ�b�g�A�b�v�̒��f��́A���݂̃u�b�N���㏑���ۑ������A" & _
               "�쐬���ꂽ�o�b�N�A�b�v���畜�����Ă��������B", _
               vbCritical, "�Č��f�[�^�̕������K�v�ł�"
        Exit Function
    End If
    RequireToolReady = True
End Function

Public Sub HideDailySheets(Optional ByVal hideOutputs As Boolean = False)
    '���i�G��Ȃ���ƁE���V�[�g���B���A���͉�ʂ���Ƃ̒��S�ɂ���B
    On Error Resume Next
    If SheetExists(SH_INPUT) Then ThisWorkbook.Worksheets(SH_INPUT).Visible = xlSheetVisible
    HideSheetIfExists SH_CONFIG
    HideSheetIfExists SH_TEKIYO
    HideSheetIfExists SH_ACCOUNT_TYPE
    HideSheetIfExists SH_INPUT_MODE
    HideSheetIfExists SH_YEAR_MODE
    HideSheetIfExists SH_DISPLAY_OPTION
    HideSheetIfExists SH_POST_KEEP
    HideSheetIfExists SH_POST_CLEAR
    HideSheetIfExists SH_BANK_CAND
    HideSheetIfExists SH_BRANCH_CAND
    HideSheetIfExists SH_PERSON_CAND
    VeryHideSheetIfExists SH_ANALYSIS_STATUS
    VeryHideSheetIfExists SH_WORK_ANALYSIS_GROUP
    VeryHideSheetIfExists SH_WORK_ANALYSIS_REVIEW
    VeryHideSheetIfExists SH_WORK_ANALYSIS_HISTORY
    VeryHideSheetIfExists SH_WORK_MANUAL_FLOW
    VeryHideSheetIfExists SH_ANALYSIS_SHIFT
    VeryHideSheetIfExists SH_ANALYSIS_FLOW
    VeryHideSheetIfExists SH_ANALYSIS_UNKNOWN
    VeryHideSheetIfExists SH_ANALYSIS_RESULT
    VeryHideSheetIfExists SH_ANALYSIS_DETAIL
    VeryHideSheetIfExists SH_WORK_CASH
    VeryHideSheetIfExists SH_WORK_TX
    VeryHideSheetIfExists SH_WORK_BAL
    VeryHideSheetIfExists SH_WORK_ACCOUNT
    VeryHideSheetIfExists SH_WORK_STATE
    HideSheetIfExists SH_REGISTERED_ACCOUNTS
    HideSheetIfExists SH_CHECK
    VeryHideSheetIfExists SH_SETUP_LOG
    If hideOutputs Then
        HideSheetIfExists SH_OUTPUT_TX
        HideSheetIfExists SH_OUTPUT_BAL
        HideSheetIfExists SH_SHOP_TARGET
        HideSheetIfExists SH_OUTPUT_TX_CONVERTED
        HideSheetIfExists SH_BALANCE_RECONCILIATION
    ElseIf SheetExists(SH_BALANCE_RECONCILIATION) Then
        If LastUsedRowInSheet(GetSheet(SH_BALANCE_RECONCILIATION)) > 1 Then
            GetSheet(SH_BALANCE_RECONCILIATION).Visible = xlSheetVisible
        Else
            HideSheetIfExists SH_BALANCE_RECONCILIATION
        End If
    End If
    On Error GoTo 0
End Sub

Public Sub VeryHideSheetIfExists(ByVal sheetName As String)
    On Error Resume Next
    If SheetExists(sheetName) Then
        SetSheetVeryHiddenSafe ThisWorkbook.Worksheets(sheetName)
    End If
    On Error GoTo 0
End Sub

Public Sub SetSheetVeryHiddenSafe(ByVal ws As Worksheet)
    Dim candidate As Worksheet
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    If ActiveSheet.Name = ws.Name Then
        If SheetExists(SH_INPUT) And ws.Name <> SH_INPUT Then
            ThisWorkbook.Worksheets(SH_INPUT).Visible = xlSheetVisible
            ThisWorkbook.Worksheets(SH_INPUT).Activate
        Else
            For Each candidate In ThisWorkbook.Worksheets
                If candidate.Name <> ws.Name And candidate.Visible = xlSheetVisible Then
                    candidate.Activate
                    Exit For
                End If
            Next candidate
        End If
    End If
    If ActiveSheet.Name <> ws.Name Then ws.Visible = xlSheetVeryHidden
    On Error GoTo 0
End Sub

Public Sub HideSheetIfExists(ByVal sheetName As String)
    On Error Resume Next
    If SheetExists(sheetName) Then
        If ThisWorkbook.Worksheets(sheetName).Name <> ActiveSheet.Name Then ThisWorkbook.Worksheets(sheetName).Visible = xlSheetHidden
    End If
    On Error GoTo 0
End Sub

Public Sub ShowCandidateSheets()
    '���Ń{�^���Ƃ̌݊������B���݂�5���𓯎��\�������A���Ǘ��p�l���֏W�񂷂�B
    ShowBankCandidates
End Sub

Public Sub ShowConfigSheet()
    Dim ws As Worksheet
    Dim errorNumber As Long, errorDescription As String
    If Not RequireToolReady() Then Exit Sub
    On Error GoTo EH
    Set ws = ThisWorkbook.Worksheets(SH_CONFIG)
    ProtectConfigSheet True
    ws.Visible = xlSheetVisible
    ws.Activate
    ws.Range("C4").Select
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    On Error Resume Next
    If Not ws Is Nothing Then ProtectConfigSheet False
    On Error GoTo 0
    MsgBox "�ݒ�V�[�g��\���ł��܂���ł����B" & vbCrLf & _
           "Err " & errorNumber & ": " & errorDescription, vbExclamation
End Sub

Public Sub ShowInputSheet()
    '�戵�X�ϊ��Ώۂ�o�̓V�[�g����A���͍�Ƃ̒��S��ʂ֖߂邽�߂̓����B
    Dim errorNumber As Long, errorDescription As String
    If Not RequireToolReady() Then Exit Sub
    On Error GoTo EH
    ThisWorkbook.Worksheets(SH_INPUT).Visible = xlSheetVisible
    ThisWorkbook.Worksheets(SH_INPUT).Activate
    HideDailySheets False
    ProtectInputSheet True
    EnableInputKeys
    ThisWorkbook.Worksheets(SH_INPUT).Range(CELL_BANK).Select
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    AppForceRestore
    MsgBox "���̓V�[�g��\���ł��܂���ł����B" & vbCrLf & _
           "Err " & errorNumber & ": " & errorDescription, vbExclamation
End Sub

Public Sub ShowCheckSheet()
    If Not SheetExists(SH_CHECK) Then Exit Sub
    On Error Resume Next
    ThisWorkbook.Worksheets(SH_CHECK).Visible = xlSheetVisible
    ThisWorkbook.Worksheets(SH_CHECK).Activate
    On Error GoTo 0
End Sub


Public Sub ShowShopConversionTargetSheet()
    If Not SheetExists(SH_SHOP_TARGET) Then Exit Sub
    On Error Resume Next
    ThisWorkbook.Worksheets(SH_SHOP_TARGET).Visible = xlSheetVisible
    ThisWorkbook.Worksheets(SH_SHOP_TARGET).Activate
    ThisWorkbook.Worksheets(SH_SHOP_TARGET).Range("A1").Select
    On Error GoTo 0
End Sub

Public Sub ShowConvertedCashOperationSheet()
    If Not SheetExists(SH_OUTPUT_TX_CONVERTED) Then Exit Sub
    On Error Resume Next
    ThisWorkbook.Worksheets(SH_OUTPUT_TX_CONVERTED).Visible = xlSheetVisible
    ThisWorkbook.Worksheets(SH_OUTPUT_TX_CONVERTED).Activate
    ThisWorkbook.Worksheets(SH_OUTPUT_TX_CONVERTED).Range("A1").Select
    On Error GoTo 0
End Sub

Attribute VB_Name = "modRecords"
Option Explicit

Private mInternalIdCaches As Object

'�����E����E�c�����A�\��������ł͂Ȃ���\��ID�Ō��ѕt����B
'���p�҂�ID����͂����A�o�^�ς݌�����ʂ���Ώۂ�I�Ԃ����Œ����ł���B

Public Sub SetupRecordStores(Optional ByVal resetContents As Boolean = False, _
                             Optional ByVal initialDataHealth As String = DATA_HEALTH_NORMAL)
    Dim ws As Worksheet

    If initialDataHealth <> DATA_HEALTH_NORMAL And _
       initialDataHealth <> DATA_HEALTH_INITIALIZING And _
       initialDataHealth <> DATA_HEALTH_NEEDS_RECOVERY Then
        Err.Raise vbObjectError + 3406, "SetupRecordStores", _
                  "�Č��f�[�^��Ԃ̏����l���s���ł�: " & initialDataHealth
    End If

    If resetContents Then InvalidateInternalIdCaches

    Set ws = GetOrCreateSheet(SH_WORK_ACCOUNT, False)
    If resetContents Then ResetWorksheet ws
    If Len(CellText(ws.Cells(1, 1).Value)) = 0 Then
        SetRowValues ws.Range("A1"), Array("����ID", "��s��", "�x�X��", "����", "����", "�Ȗ�", "�����ԍ�", "�����J�ݓ�", "��������", "�l��ID", "�o�^��", "�X�V����", "�ŐV�]�L��ID")
        FormatOutputHeader ws.Range("A1:M1")
        ws.Columns("A:M").ColumnWidth = 16
    End If
    ws.Columns("A:G").NumberFormatLocal = "@"
    ws.Columns("H:I").NumberFormatLocal = "yyyy/m/d"
    ws.Columns("J:K").NumberFormatLocal = "@"
    ws.Columns("L:L").NumberFormatLocal = "yyyy/m/d h:mm:ss"
    ws.Columns("M:M").NumberFormatLocal = "@"
    SetSheetVeryHiddenSafe ws

    Set ws = GetOrCreateSheet(SH_WORK_STATE, False)
    If resetContents Then ResetWorksheet ws
    If Len(CellText(ws.Cells(1, 1).Value)) = 0 Then
        SetRowValues ws.Range("A1"), Array("����", "�l")
        FormatOutputHeader ws.Range("A1:B1")
        SetStateValue STATE_NEXT_ACCOUNT, "1"
        SetStateValue STATE_NEXT_TRANSFER, "1"
        SetStateValue STATE_NEXT_TRANSACTION, "1"
        SetStateValue STATE_NEXT_BALANCE, "1"
        SetStateValue STATE_NEXT_PERSON, "1"
        SetStateValue STATE_EDIT_ACCOUNT, ""
        SetStateValue STATE_OUTPUT_DIRTY, STATE_TRUE
        SetStateValue STATE_ANALYSIS_REVIEW_DIRTY, STATE_FALSE
        SetStateValue STATE_LAST_BUILD, ""
        SetStateValue STATE_DATA_HEALTH, initialDataHealth
    End If
    EnsureStateDefault STATE_NEXT_ACCOUNT, "1"
    EnsureStateDefault STATE_NEXT_TRANSFER, "1"
    EnsureStateDefault STATE_NEXT_TRANSACTION, "1"
    EnsureStateDefault STATE_NEXT_BALANCE, "1"
    EnsureStateDefault STATE_NEXT_PERSON, "1"
    EnsureStateDefault STATE_EDIT_ACCOUNT, ""
    EnsureStateDefault STATE_OUTPUT_DIRTY, STATE_TRUE
    EnsureStateDefault STATE_ANALYSIS_REVIEW_DIRTY, STATE_FALSE
    EnsureStateDefault STATE_LAST_BUILD, ""
    EnsureStateDefault STATE_DATA_HEALTH, initialDataHealth
    ws.Columns("A:B").NumberFormatLocal = "@"
    SetSheetVeryHiddenSafe ws

    Set ws = GetOrCreateSheet(SH_REGISTERED_ACCOUNTS, False)
    If resetContents Then ResetWorksheet ws
    If Len(CellText(ws.Cells(1, 1).Value)) = 0 Then BuildRegisteredAccountsSheet False
    ws.Visible = xlSheetHidden
End Sub

Public Function GetStateValue(ByVal keyText As String, Optional ByVal defaultValue As String = "") As String
    Dim ws As Worksheet
    Dim lastR As Long, r As Long
    On Error GoTo EH
    Set ws = GetSheet(SH_WORK_STATE)
    lastR = LastUsedRowInSheet(ws)
    For r = 2 To lastR
        If CellText(ws.Cells(r, 1).Value) = keyText Then
            GetStateValue = CellText(ws.Cells(r, 2).Value)
            Exit Function
        End If
    Next r
EH:
    If Len(GetStateValue) = 0 Then GetStateValue = defaultValue
End Function

Public Function TryGetExactStateValue(ByVal keyText As String, ByRef valueText As String) As Boolean
    '���S����p�BGetStateValue�̊���l�⊮�͕\���E�݊��p�r�ɂ͕֗������A
    '�Č��f�[�^��Ԃ̂悤�Ȉ��S�t���O�Ŏg���ƁA������ǎ掸�s�𐳏�l�Ƃ��Ĉ�������B
    Dim ws As Worksheet
    Dim lastR As Long, r As Long
    Dim found As Boolean
    valueText = vbNullString
    If Len(keyText) = 0 Then Exit Function
    If Not SheetExists(SH_WORK_STATE) Then Exit Function
    On Error GoTo EH
    Set ws = GetSheet(SH_WORK_STATE)
    lastR = LastUsedRowInSheet(ws)
    For r = 2 To lastR
        If ws.Cells(r, 1).HasFormula Or IsError(ws.Cells(r, 1).Value2) Then GoTo EH
        If StrComp(CellText(ws.Cells(r, 1).Value2), keyText, vbBinaryCompare) = 0 Then
            '���S�t���O�͏d���A�����AExcel�G���[�̂ǂ���󗝂��Ȃ��B
            If found Or ws.Cells(r, 2).HasFormula Or IsError(ws.Cells(r, 2).Value2) Then GoTo EH
            valueText = CellText(ws.Cells(r, 2).Value2)
            found = True
        End If
    Next r
    TryGetExactStateValue = found
    Exit Function
EH:
    valueText = vbNullString
    TryGetExactStateValue = False
    Err.Clear
End Function

Public Function ToolHasSetupTrace() As Boolean
    '�Z�b�g�A�b�v�r���Œ��j�V�[�g�̈ꕔ�����쐬����Ȃ������ꍇ�����m����B
    '�ʏ�̋�u�b�N�ł�False�A�����E�r�������c�[���ł͂ǂꂩ���True�ƂȂ�B
    ToolHasSetupTrace = _
        SheetExists(SH_INPUT) Or SheetExists(SH_CONFIG) Or _
        SheetExists(SH_WORK_STATE) Or SheetExists(SH_CHECK) Or _
        SheetExists(SH_SETUP_LOG) Or SheetExists(SH_WORK_ACCOUNT) Or _
        SheetExists(SH_OUTPUT_TX) Or SheetExists(SH_ANALYSIS_RESULT)
End Function

Public Function ToolDataHealthClassification() As Long
    '���S��Ԃ�4���ނ���B�ǎ�s�\�E���m�l�𖾎��I�ȕ�����ԂƋ�ʂ��A
    '��ꂩ���̐���u�b�N�𕪐͖������̂܂܏㏑�����Ȃ��B
    Dim dataHealth As String
    If Not ToolHasSetupTrace() Then
        ToolDataHealthClassification = TOOL_HEALTH_NOT_INITIALIZED
        Exit Function
    End If
    If Not TryGetExactStateValue(STATE_DATA_HEALTH, dataHealth) Then
        ToolDataHealthClassification = TOOL_HEALTH_UNKNOWN
        Exit Function
    End If
    Select Case dataHealth
        Case DATA_HEALTH_NORMAL
            ToolDataHealthClassification = TOOL_HEALTH_NORMAL
        Case DATA_HEALTH_INITIALIZING, DATA_HEALTH_NEEDS_RECOVERY
            ToolDataHealthClassification = TOOL_HEALTH_RECOVERY
        Case Else
            ToolDataHealthClassification = TOOL_HEALTH_UNKNOWN
    End Select
End Function

Public Function ToolDataHealthIsNormal() As Boolean
    '�ۑ��O�C�x���g�����烁�b�Z�[�W�Ȃ��Ŏg��fail-closed����B
    ToolDataHealthIsNormal = _
        (ToolDataHealthClassification() = TOOL_HEALTH_NORMAL)
End Function

Public Sub SetStateValue(ByVal keyText As String, ByVal valueText As String)
    Dim ws As Worksheet
    Dim lastR As Long, r As Long
    On Error GoTo EH
    Set ws = GetOrCreateSheet(SH_WORK_STATE, False)
    If Len(CellText(ws.Cells(1, 1).Value)) = 0 Then SetRowValues ws.Range("A1"), Array("����", "�l")
    lastR = LastUsedRowInSheet(ws)
    For r = 2 To lastR
        If CellText(ws.Cells(r, 1).Value) = keyText Then
            ws.Cells(r, 2).Value = valueText
            Exit Sub
        End If
    Next r
    r = lastR + 1
    If r < 2 Then r = 2
    ws.Cells(r, 1).Value = keyText
    ws.Cells(r, 2).Value = valueText
    Exit Sub
EH:
    Err.Raise Err.Number, "SetStateValue(" & keyText & ")", Err.Description
End Sub

Public Function CaptureInternalIdCounters() As Variant
    '�o�^�E�捞����̏����P�ʂƂ��Ĉ����A�����O�G���[�ł��̔Ԃ������i�܂Ȃ��悤�ɂ���B
    CaptureInternalIdCounters = Array( _
        GetStateValue(STATE_NEXT_ACCOUNT, "1"), _
        GetStateValue(STATE_NEXT_TRANSFER, "1"), _
        GetStateValue(STATE_NEXT_TRANSACTION, "1"), _
        GetStateValue(STATE_NEXT_BALANCE, "1"), _
        GetStateValue(STATE_NEXT_PERSON, "1"))
End Function

Public Sub RestoreInternalIdCounters(ByVal counterSnapshot As Variant)
    Dim firstIndex As Long
    On Error GoTo EH
    If Not IsArray(counterSnapshot) Then
        Err.Raise vbObjectError + 3404, "RestoreInternalIdCounters", "����ID�J�E���^�[�̑ޔ�l������܂���B"
    End If
    firstIndex = LBound(counterSnapshot)
    If UBound(counterSnapshot) - firstIndex < 4 Then
        Err.Raise vbObjectError + 3405, "RestoreInternalIdCounters", "����ID�J�E���^�[�̑ޔ�l���s�����Ă��܂��B"
    End If
    SetStateValue STATE_NEXT_ACCOUNT, CStr(counterSnapshot(firstIndex))
    SetStateValue STATE_NEXT_TRANSFER, CStr(counterSnapshot(firstIndex + 1))
    SetStateValue STATE_NEXT_TRANSACTION, CStr(counterSnapshot(firstIndex + 2))
    SetStateValue STATE_NEXT_BALANCE, CStr(counterSnapshot(firstIndex + 3))
    SetStateValue STATE_NEXT_PERSON, CStr(counterSnapshot(firstIndex + 4))
    InvalidateInternalIdCaches
    Exit Sub
EH:
    Err.Raise Err.Number, "RestoreInternalIdCounters", Err.Description
End Sub

Private Sub EnsureStateDefault(ByVal keyText As String, ByVal defaultValue As String)
    Dim ws As Worksheet, lastR As Long, r As Long
    Set ws = GetSheet(SH_WORK_STATE)
    lastR = LastUsedRowInSheet(ws)
    For r = 2 To lastR
        If CellText(ws.Cells(r, 1).Value) = keyText Then Exit Sub
    Next r
    SetStateValue keyText, defaultValue
End Sub

Public Function NextInternalId(ByVal stateKey As String, ByVal prefixText As String) As String
    Dim reserved As Variant
    reserved = ReserveInternalIds(stateKey, prefixText, 1)
    NextInternalId = CStr(reserved(1))
End Function

Public Function ReserveInternalIds(ByVal stateKey As String, ByVal prefixText As String, _
                                   ByVal reserveCount As Long) As Variant
    '��ʖ��ׂł�W_��Ԃ�1�s���X�V���Ȃ��B�ꊇ�ŏՓ˂�����č̔Ԃ��A
    '���ԍ��͑S���m�ۂł�����Ɉ�x�����i�߂�B
    Dim n As Long, allocated As Long, i As Long
    Dim stateText As String, stateNumber As Double, nextStateNumber As Double
    Dim candidateID As String
    Dim ids As Object
    Dim reserved() As String
    If reserveCount < 1 Then _
        Err.Raise vbObjectError + 3407, "ReserveInternalIds", "����ID�̗\�񌏐����s���ł�: " & reserveCount
    If Len(prefixText) = 0 Then _
        Err.Raise vbObjectError + 3408, "ReserveInternalIds", "����ID�̐ړ������󗓂ł��B"

    Set ids = GetInternalIdCache(stateKey)
    stateText = GetStateValue(stateKey, "1")
    If Not IsNumeric(stateText) Then _
        Err.Raise vbObjectError + 3401, "ReserveInternalIds", "����ID�J�E���^�[�����l�ł͂���܂���: " & stateKey
    stateNumber = CDbl(stateText)
    If stateNumber <> Fix(stateNumber) Or stateNumber < 1 Or stateNumber > 2147483647# Then
        Err.Raise vbObjectError + 3402, "ReserveInternalIds", "����ID�J�E���^�[���͈͊O�ł�: " & stateKey
    End If
    If stateNumber = 2147483647# Then _
        Err.Raise vbObjectError + 3403, "ReserveInternalIds", "����ID������ȏ�̔Ԃł��܂���: " & stateKey

    n = CLng(stateNumber)
    ReDim reserved(1 To reserveCount)
    Do While allocated < reserveCount
        candidateID = prefixText & Format$(n, "000000")
        If Not ids.Exists(candidateID) Then
            allocated = allocated + 1
            reserved(allocated) = candidateID
        End If
        If n >= 2147483646 Then
            If allocated < reserveCount Then _
                Err.Raise vbObjectError + 3403, "ReserveInternalIds", "����ID������ȏ�̔Ԃł��܂���: " & stateKey
            nextStateNumber = 2147483647#
            Exit Do
        End If
        n = n + 1
    Loop
    If nextStateNumber = 0 Then nextStateNumber = n

    '��ԕ\���i�񂾌�ɂ��������������֗\��ID�𔽉f����B�ďo���̎��s����
    '�����̃J�E���^�[�ޔ��E������������ԕ\�ƍ����𓯎��ɖ߂��B
    SetStateValue stateKey, Format$(nextStateNumber, "0")
    For i = 1 To reserveCount
        ids(reserved(i)) = True
    Next i
    ReserveInternalIds = reserved
End Function

Public Sub InvalidateInternalIdCaches()
    Set mInternalIdCaches = Nothing
End Sub

Public Sub ReconcileInternalIdCounters()
    '���ʐl�������c�����܂܈Č����������Ă��A�̔Ԃ�����ID�֖߂�Ȃ��悤����������B
    SetCounterAtLeast STATE_NEXT_ACCOUNT, MaxInternalSuffix(GetSheet(SH_WORK_ACCOUNT), ACC_COL_ID, "A") + 1
    SetCounterAtLeast STATE_NEXT_TRANSFER, Application.Max(MaxInternalSuffix(GetSheet(SH_WORK_TX), WORK_TX_COL_TRANSFER_ID, "R"), _
                                                           MaxInternalSuffix(GetSheet(SH_WORK_BAL), WORK_BAL_COL_TRANSFER_ID, "R")) + 1
    SetCounterAtLeast STATE_NEXT_TRANSACTION, MaxInternalSuffix(GetSheet(SH_WORK_TX), WORK_TX_COL_TRANSACTION_ID, "T") + 1
    SetCounterAtLeast STATE_NEXT_BALANCE, MaxInternalSuffix(GetSheet(SH_WORK_BAL), WORK_BAL_COL_BALANCE_ID, "B") + 1
    SetCounterAtLeast STATE_NEXT_PERSON, Application.Max(MaxInternalSuffix(GetSheet(SH_PERSON_CAND), 2, "P"), _
                                                         MaxInternalSuffix(GetSheet(SH_WORK_ACCOUNT), ACC_COL_PERSON_ID, "P")) + 1
    InvalidateInternalIdCaches
End Sub

Private Sub SetCounterAtLeast(ByVal stateKey As String, ByVal minimumValue As Long)
    Dim currentValue As Long
    Dim currentText As String, currentNumber As Double
    If minimumValue < 1 Then minimumValue = 1
    currentText = GetStateValue(stateKey, "1")
    If IsNumeric(currentText) Then
        currentNumber = CDbl(currentText)
        If currentNumber = Fix(currentNumber) And currentNumber >= 1 And currentNumber <= 2147483647# Then currentValue = CLng(currentNumber)
    End If
    If currentValue < minimumValue Then SetStateValue stateKey, CStr(minimumValue)
End Sub

Private Function MaxInternalSuffix(ByVal ws As Worksheet, ByVal colNo As Long, ByVal prefixText As String) As Long
    Dim r As Long, lastR As Long, idText As String, n As Long, rawNumber As Double
    Dim idValues As Variant, valueAtRow As Variant
    If ws Is Nothing Then Exit Function
    lastR = LastUsedRowInSheet(ws)
    If lastR < 2 Then Exit Function
    idValues = ws.Range(ws.Cells(2, colNo), ws.Cells(lastR, colNo)).Value2
    For r = 1 To lastR - 1
        If lastR = 2 Then valueAtRow = idValues Else valueAtRow = idValues(r, 1)
        idText = CellText(valueAtRow)
        If Len(idText) > Len(prefixText) And StrComp(Left$(idText, Len(prefixText)), prefixText, vbTextCompare) = 0 Then
            rawNumber = Val(Mid$(idText, Len(prefixText) + 1))
            If rawNumber > 2147483646# Then n = 2147483646 Else n = CLng(rawNumber)
            If n > MaxInternalSuffix Then MaxInternalSuffix = n
        End If
    Next r
End Function

Private Function GetInternalIdCache(ByVal stateKey As String) As Object
    Dim ids As Object
    If mInternalIdCaches Is Nothing Then
        Set mInternalIdCaches = CreateObject("Scripting.Dictionary")
        mInternalIdCaches.CompareMode = vbTextCompare
    End If
    If mInternalIdCaches.Exists(stateKey) Then
        Set ids = mInternalIdCaches(stateKey)
    Else
        Set ids = CreateObject("Scripting.Dictionary")
        ids.CompareMode = vbTextCompare
        LoadInternalIds stateKey, ids
        mInternalIdCaches.Add stateKey, ids
    End If
    Set GetInternalIdCache = ids
End Function

Private Sub LoadInternalIds(ByVal stateKey As String, ByVal ids As Object)
    Select Case stateKey
        Case STATE_NEXT_ACCOUNT
            AddColumnIds GetSheet(SH_WORK_ACCOUNT), ACC_COL_ID, ids
        Case STATE_NEXT_TRANSFER
            AddColumnIds GetSheet(SH_WORK_TX), WORK_TX_COL_TRANSFER_ID, ids
            AddColumnIds GetSheet(SH_WORK_BAL), WORK_BAL_COL_TRANSFER_ID, ids
        Case STATE_NEXT_TRANSACTION
            AddColumnIds GetSheet(SH_WORK_TX), WORK_TX_COL_TRANSACTION_ID, ids
        Case STATE_NEXT_BALANCE
            AddColumnIds GetSheet(SH_WORK_BAL), WORK_BAL_COL_BALANCE_ID, ids
        Case STATE_NEXT_PERSON
            AddColumnIds GetSheet(SH_PERSON_CAND), 2, ids
            AddColumnIds GetSheet(SH_WORK_ACCOUNT), ACC_COL_PERSON_ID, ids
    End Select
End Sub

Private Sub AddColumnIds(ByVal ws As Worksheet, ByVal colNo As Long, ByVal ids As Object)
    Dim lastR As Long, r As Long, idText As String
    Dim idValues As Variant, valueAtRow As Variant
    If ws Is Nothing Or ids Is Nothing Then Exit Sub
    lastR = LastUsedRowInSheet(ws)
    If lastR < 2 Then Exit Sub
    idValues = ws.Range(ws.Cells(2, colNo), ws.Cells(lastR, colNo)).Value2
    For r = 1 To lastR - 1
        If lastR = 2 Then valueAtRow = idValues Else valueAtRow = idValues(r, 1)
        idText = CellText(valueAtRow)
        If Len(idText) > 0 Then ids(idText) = True
    Next r
End Sub

Public Function CurrentEditAccountID() As String
    CurrentEditAccountID = GetStateValue(STATE_EDIT_ACCOUNT, "")
End Function

Public Function IsEditMode() As Boolean
    IsEditMode = (Len(CurrentEditAccountID()) > 0)
End Function

Public Sub SetEditAccountID(ByVal accountID As String)
    SetStateValue STATE_EDIT_ACCOUNT, CellText(accountID)
    RefreshMainActionCaption
End Sub

Public Function OutputsAreDirty() As Boolean
    OutputsAreDirty = (GetStateValue(STATE_OUTPUT_DIRTY, STATE_TRUE) <> STATE_FALSE)
End Function

Public Function AnalysisReviewsAreDirty() As Boolean
    AnalysisReviewsAreDirty = _
        (GetStateValue(STATE_ANALYSIS_REVIEW_DIRTY, STATE_FALSE) <> STATE_FALSE)
End Function

Public Sub MarkAnalysisReviewsDirty()
    SetStateValue STATE_ANALYSIS_REVIEW_DIRTY, STATE_TRUE
End Sub

Public Sub MarkAnalysisReviewsClean()
    SetStateValue STATE_ANALYSIS_REVIEW_DIRTY, STATE_FALSE
End Sub

Public Sub MarkOutputsDirty()
    Dim ws As Worksheet
    Dim lastR As Long
    SetStateValue STATE_OUTPUT_DIRTY, STATE_TRUE

    '�戵�X���f�ςݕ\�����͌Â��܂ܗD�悳���Ɗ댯�Ȃ̂ŁA���ׂ𑦎�����������B
    On Error Resume Next
    If SheetExists(SH_OUTPUT_TX_CONVERTED) Then
        Set ws = GetSheet(SH_OUTPUT_TX_CONVERTED)
        lastR = LastUsedRowInSheet(ws)
        If lastR >= 2 Then ws.Range(ws.Cells(2, 1), ws.Cells(lastR, OUT_INTERNAL_LAST_COL)).ClearContents
    End If
    On Error GoTo 0
    RefreshMainActionCaption
End Sub

Public Sub MarkOutputsClean()
    SetStateValue STATE_OUTPUT_DIRTY, STATE_FALSE
    MarkAnalysisReviewsClean
    SetStateValue STATE_LAST_BUILD, Format$(Now, "yyyy/m/d h:mm:ss")
    RefreshMainActionCaption
End Sub

Public Function CanonicalAccountKey(ByVal bankName As String, ByVal branchName As String, _
                                    ByVal personName As String, ByVal accountType As String, _
                                    ByVal accountNo As String) As String
    CanonicalAccountKey = NormalizeIdentityPart(bankName) & Chr$(30) & _
                          NormalizeIdentityPart(branchName) & Chr$(30) & _
                          NormalizeIdentityPart(personName) & Chr$(30) & _
                          NormalizeIdentityPart(accountType) & Chr$(30) & _
                          NormalizeAccountNumberForKey(accountNo)
End Function

Public Function CanonicalAccountLocatorKey(ByVal bankName As String, ByVal branchName As String, _
                                           ByVal accountType As String, ByVal accountNo As String) As String
    '���`�̌�L�E���������œ�����������ʌ����Ƃ��ēo�^���Ȃ����߁A���`�����������ݒn�L�[�����B
    CanonicalAccountLocatorKey = NormalizeIdentityPart(bankName) & Chr$(30) & _
                                 NormalizeIdentityPart(branchName) & Chr$(30) & _
                                 NormalizeIdentityPart(accountType) & Chr$(30) & _
                                 NormalizeAccountNumberForKey(accountNo)
End Function

Private Function NormalizeIdentityPart(ByVal valueText As String) As String
    Dim s As String
    s = Trim$(CellText(valueText))
    s = Replace(s, " ", "")
    s = Replace(s, "�@", "")
    NormalizeIdentityPart = UCase$(s)
End Function

Private Function NormalizeAccountNumberForKey(ByVal valueText As String) As String
    Dim s As String
    s = NormalizeAccountHyphen(CellText(valueText))
    On Error Resume Next
    s = StrConv(s, vbNarrow)
    On Error GoTo 0
    s = Replace(s, " ", "")
    s = Replace(s, "�@", "")
    NormalizeAccountNumberForKey = UCase$(s)
End Function

Public Function FindAccountRowByID(ByVal accountID As String) As Long
    Dim ws As Worksheet
    Dim lastR As Long, r As Long, rowCount As Long
    Dim idData As Variant
    If Len(CellText(accountID)) = 0 Then Exit Function
    If Not SheetExists(SH_WORK_ACCOUNT) Then Exit Function
    Set ws = GetSheet(SH_WORK_ACCOUNT)
    lastR = LastUsedRowInSheet(ws)
    If lastR < 2 Then Exit Function
    rowCount = lastR - 1
    idData = ws.Range(ws.Cells(2, ACC_COL_ID), ws.Cells(lastR, ACC_COL_ID)).Value2
    For r = 1 To rowCount
        If CellText(RecordsColumnValue(idData, r, rowCount)) = accountID Then
            FindAccountRowByID = r + 1
            Exit Function
        End If
    Next r
End Function

Public Function FindAccountIDByComposite(ByVal bankName As String, ByVal branchName As String, _
                                         ByVal personName As String, ByVal accountType As String, _
                                         ByVal accountNo As String, _
                                         Optional ByVal excludeAccountID As String = "") As String
    Dim ws As Worksheet
    Dim lastR As Long, r As Long
    Dim targetKey As String, rowKey As String, rowID As String
    Dim accountData As Variant
    If Not SheetExists(SH_WORK_ACCOUNT) Then Exit Function
    targetKey = CanonicalAccountKey(bankName, branchName, personName, accountType, accountNo)
    Set ws = GetSheet(SH_WORK_ACCOUNT)
    lastR = LastUsedRowInSheet(ws)
    If lastR < 2 Then Exit Function
    accountData = ws.Range(ws.Cells(2, ACC_COL_ID), ws.Cells(lastR, ACC_COL_NO)).Value2
    For r = 1 To UBound(accountData, 1)
        rowID = CellText(accountData(r, ACC_COL_ID))
        If rowID <> excludeAccountID Then
            rowKey = CanonicalAccountKey(CellText(accountData(r, ACC_COL_BANK)), _
                                         CellText(accountData(r, ACC_COL_BRANCH)), _
                                         CellText(accountData(r, ACC_COL_PERSON)), _
                                         CellText(accountData(r, ACC_COL_TYPE)), _
                                         CellText(accountData(r, ACC_COL_NO)))
            If rowKey = targetKey Then
                FindAccountIDByComposite = rowID
                Exit Function
            End If
        End If
    Next r
End Function

Public Function FindAccountIDByLocator(ByVal bankName As String, ByVal branchName As String, _
                                       ByVal accountType As String, ByVal accountNo As String, _
                                       Optional ByVal excludeAccountID As String = "") As String
    Dim ws As Worksheet
    Dim lastR As Long, r As Long
    Dim targetKey As String, rowKey As String, rowID As String
    Dim accountData As Variant
    If Not SheetExists(SH_WORK_ACCOUNT) Then Exit Function
    targetKey = CanonicalAccountLocatorKey(bankName, branchName, accountType, accountNo)
    Set ws = GetSheet(SH_WORK_ACCOUNT)
    lastR = LastUsedRowInSheet(ws)
    If lastR < 2 Then Exit Function
    accountData = ws.Range(ws.Cells(2, ACC_COL_ID), ws.Cells(lastR, ACC_COL_NO)).Value2
    For r = 1 To UBound(accountData, 1)
        rowID = CellText(accountData(r, ACC_COL_ID))
        If rowID <> excludeAccountID Then
            rowKey = CanonicalAccountLocatorKey(CellText(accountData(r, ACC_COL_BANK)), _
                                                CellText(accountData(r, ACC_COL_BRANCH)), _
                                                CellText(accountData(r, ACC_COL_TYPE)), _
                                                CellText(accountData(r, ACC_COL_NO)))
            If rowKey = targetKey Then
                FindAccountIDByLocator = rowID
                Exit Function
            End If
        End If
    Next r
End Function

Public Sub UpsertAccountMaster(ByVal accountID As String, ByVal transferID As String, _
                               ByVal bankName As String, ByVal branchName As String, _
                               ByVal personName As String, ByVal relationshipText As String, _
                               ByVal accountType As String, ByVal accountNo As String, _
                               ByVal openDate As Variant, ByVal closeDate As Variant, _
                               ByVal personID As String, ByVal sourceText As String, _
                               Optional ByVal knownRow As Long = 0)
    Dim ws As Worksheet
    Dim r As Long
    Dim existingID As String
    Set ws = GetSheet(SH_WORK_ACCOUNT)
    If knownRow > 0 Then
        If knownRow < 2 Or knownRow > ws.Rows.Count Then _
            Err.Raise vbObjectError + 3426, "UpsertAccountMaster", "�����}�X�^�̏����ʒu���s���ł��B"
        existingID = CellText(ws.Cells(knownRow, ACC_COL_ID).Value)
        If Len(existingID) > 0 And StrComp(existingID, accountID, vbTextCompare) <> 0 Then _
            Err.Raise vbObjectError + 3427, "UpsertAccountMaster", "�����}�X�^�̏����ʒu�ɕʂ̌���ID������܂��B"
        r = knownRow
    Else
        r = FindAccountRowByID(accountID)
    End If
    If r = 0 Then
        r = LastUsedRowInSheet(ws) + 1
        If r < 2 Then r = 2
        If r > ws.Rows.Count Then _
            Err.Raise vbObjectError + 3421, "UpsertAccountMaster", "�����}�X�^��Excel�̍s����ɒB���Ă��܂��B"
    End If
    ws.Range(ws.Cells(r, ACC_COL_ID), ws.Cells(r, ACC_COL_NO)).NumberFormatLocal = "@"
    ws.Range(ws.Cells(r, ACC_COL_PERSON_ID), ws.Cells(r, ACC_COL_SOURCE)).NumberFormatLocal = "@"
    ws.Cells(r, ACC_COL_UPDATED_AT).NumberFormatLocal = "yyyy/m/d h:mm:ss"
    ws.Cells(r, ACC_COL_TRANSFER_ID).NumberFormatLocal = "@"
    SetRowValues ws.Cells(r, 1), Array(accountID, bankName, branchName, personName, relationshipText, _
                                       accountType, accountNo, openDate, closeDate, personID, sourceText, Now, transferID)
End Sub

Public Sub DeleteAccountRecords(ByVal accountID As String, Optional ByVal deleteMaster As Boolean = False)
    Dim r As Long
    DeleteRowsForAccount GetSheet(SH_WORK_TX), WORK_TX_COL_ACCOUNT_ID, accountID
    DeleteRowsForAccount GetSheet(SH_WORK_BAL), WORK_BAL_COL_ACCOUNT_ID, accountID
    If deleteMaster Then
        r = FindAccountRowByID(accountID)
        If r > 0 Then GetSheet(SH_WORK_ACCOUNT).Rows(r).Delete
    End If
End Sub

Private Sub DeleteRowsForAccount(ByVal ws As Worksheet, ByVal idCol As Long, ByVal accountID As String)
    If ws Is Nothing Or Len(accountID) = 0 Then Exit Sub
    If ws.Name = SH_WORK_TX Then
        CompactDeleteDataRows ws, WORK_TX_COL_PERSON_ID, idCol, accountID
    ElseIf ws.Name = SH_WORK_BAL Then
        CompactDeleteDataRows ws, WORK_BAL_COL_PERSON_ID, idCol, accountID
    Else
        Err.Raise vbObjectError + 3424, "DeleteRowsForAccount", "�ΏۊO�̓����V�[�g�ł�: " & ws.Name
    End If
End Sub

Public Function CountAccountRecords(ByVal ws As Worksheet, ByVal idCol As Long, ByVal accountID As String, _
                                    Optional ByVal recordType As String = "") As Long
    Dim lastR As Long, lastCol As Long, r As Long
    Dim sourceData As Variant
    If ws Is Nothing Then Exit Function
    lastR = LastUsedRowInSheet(ws)
    If lastR < 2 Then Exit Function
    lastCol = idCol
    If Len(recordType) > 0 And ws.Name = SH_WORK_TX Then lastCol = Application.Max(lastCol, WORK_TX_COL_RECORD_TYPE)
    sourceData = ws.Range(ws.Cells(2, 1), ws.Cells(lastR, lastCol)).Value2
    For r = 1 To UBound(sourceData, 1)
        If CellText(sourceData(r, idCol)) = accountID Then
            If Len(recordType) = 0 Then
                CountAccountRecords = CountAccountRecords + 1
            ElseIf ws.Name = SH_WORK_TX And CellText(sourceData(r, WORK_TX_COL_RECORD_TYPE)) = recordType Then
                CountAccountRecords = CountAccountRecords + 1
            End If
        End If
    Next r
End Function

Public Sub OpenRegisteredAccounts()
    Dim errorNumber As Long, errorDescription As String
    If Not RequireToolReady() Then Exit Sub
    If Not RequireInternalStoresSafeForWrite() Then Exit Sub
    On Error GoTo EH
    AppBegin "�o�^�ς݌�����\�����Ă��܂�..."
    BuildRegisteredAccountsSheet True
    DisableInputKeys
    AppEnd
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    AppForceRestore
    DisableInputKeys
    MsgBox "�o�^�ς݌�����\���ł��܂���ł����B" & vbCrLf & _
           "Err " & errorNumber & ": " & errorDescription, vbExclamation
End Sub

Public Sub BuildRegisteredAccountsSheet(Optional ByVal activateAfter As Boolean = False)
    Dim ws As Worksheet, wsAcc As Worksheet, wsTx As Worksheet, wsBal As Worksheet
    Dim lastR As Long, r As Long, outR As Long, lastTx As Long, lastBal As Long, clearLastR As Long
    Dim accountCount As Long
    Dim accountID As String
    Dim txCounts As Object, balCounts As Object
    Dim txData As Variant, balData As Variant, accountData As Variant, outputData() As Variant

    Set ws = GetOrCreateSheet(SH_REGISTERED_ACCOUNTS, False)
    ws.Visible = xlSheetVisible
    ws.Unprotect Password:=TOOL_PASSWORD
    DeleteToolShapesVerified ws, False
    clearLastR = Application.Max(4, LastUsedRowInSheet(ws))
    ws.Range("A1:Q" & CStr(clearLastR)).UnMerge
    ws.Range("A1:Q" & CStr(clearLastR)).Clear
    If ws.AutoFilterMode Then ws.AutoFilterMode = False

    MergeAndFormat ws.Range("A1:L1"), "�o�^�ς݌����@�b�@�s���_�u���N���b�N����ƒ�����ʂ��J���܂�"
    ws.Range("A1:L1").Font.Size = 16
    ws.Range("A1:L1").Font.Bold = True
    ws.Range("A1:L1").Font.Color = RGB(30, 64, 175)
    ws.Range("A1:L1").Interior.Color = RGB(239, 246, 255)
    SetRowValues ws.Range("A3"), Array("No", "����", "����", "��s��", "�x�X��", "�Ȗ�", "�����ԍ�", "�J�ݓ�", "����", "�������", "�c������", "�X�V����", "����ID")
    FormatOutputHeader ws.Range("A3:M3")

    Set wsAcc = GetSheet(SH_WORK_ACCOUNT)
    Set wsTx = GetSheet(SH_WORK_TX)
    Set wsBal = GetSheet(SH_WORK_BAL)
    Set txCounts = CreateObject("Scripting.Dictionary")
    Set balCounts = CreateObject("Scripting.Dictionary")
    txCounts.CompareMode = vbTextCompare
    balCounts.CompareMode = vbTextCompare
    lastTx = LastUsedRowInSheet(wsTx)
    If lastTx >= 2 Then
        txData = wsTx.Range(wsTx.Cells(2, WORK_TX_COL_ACCOUNT_ID), _
                            wsTx.Cells(lastTx, WORK_TX_COL_RECORD_TYPE)).Value2
        For r = 1 To UBound(txData, 1)
            If CellText(txData(r, WORK_TX_COL_RECORD_TYPE - WORK_TX_COL_ACCOUNT_ID + 1)) = RECORD_TRANSACTION Then
                accountID = CellText(txData(r, 1))
                If Len(accountID) > 0 Then txCounts(accountID) = CLng(DictionaryLong(txCounts, accountID)) + 1
            End If
        Next r
    End If
    lastBal = LastUsedRowInSheet(wsBal)
    If lastBal >= 2 Then
        balData = wsBal.Range(wsBal.Cells(2, WORK_BAL_COL_ACCOUNT_ID), _
                              wsBal.Cells(lastBal, WORK_BAL_COL_PERSON_ID)).Value2
        For r = 1 To UBound(balData, 1)
            accountID = CellText(balData(r, 1))
            If Len(accountID) > 0 Then balCounts(accountID) = CLng(DictionaryLong(balCounts, accountID)) + 1
        Next r
    End If
    lastR = LastUsedRowInSheet(wsAcc)
    outR = 4
    If lastR >= 2 Then
        accountCount = lastR - 1
        If accountCount > ws.Rows.Count - 3 Then _
            Err.Raise vbObjectError + 3422, "BuildRegisteredAccountsSheet", _
                      "�o�^�ς݌����ꗗ��Excel�̍s����𒴂��܂��B�Č��𕪊����Ă��������B"
        accountData = wsAcc.Range(wsAcc.Cells(2, 1), wsAcc.Cells(lastR, ACC_COL_TRANSFER_ID)).Value2
        ReDim outputData(1 To accountCount, 1 To 13)
        For r = 1 To accountCount
            accountID = CellText(accountData(r, ACC_COL_ID))
            If Len(accountID) = 0 Then _
                Err.Raise vbObjectError + 3423, "BuildRegisteredAccountsSheet", _
                          "�����}�X�^�̌���ID���󗓂ł��iW_���� " & CStr(r + 1) & "�s�j�B"
            outputData(r, 1) = r
            outputData(r, 2) = accountData(r, ACC_COL_PERSON)
            outputData(r, 3) = accountData(r, ACC_COL_RELATIONSHIP)
            outputData(r, 4) = accountData(r, ACC_COL_BANK)
            outputData(r, 5) = accountData(r, ACC_COL_BRANCH)
            outputData(r, 6) = accountData(r, ACC_COL_TYPE)
            outputData(r, 7) = accountData(r, ACC_COL_NO)
            outputData(r, 8) = accountData(r, ACC_COL_OPEN_DATE)
            outputData(r, 9) = accountData(r, ACC_COL_CLOSE_DATE)
            outputData(r, 10) = DictionaryLong(txCounts, accountID)
            outputData(r, 11) = DictionaryLong(balCounts, accountID)
            outputData(r, 12) = accountData(r, ACC_COL_UPDATED_AT)
            outputData(r, 13) = accountID
        Next r
        ws.Range(ws.Cells(4, 1), ws.Cells(3 + accountCount, 13)).Value = outputData
        outR = 4 + accountCount
    End If

    With ws.Range("A1:M" & CStr(Application.Max(4, outR - 1)))
        .Font.Name = "Yu Gothic UI"
        .Font.Size = 10
    End With

    ws.Columns("A:A").ColumnWidth = 6
    ws.Columns("B:B").ColumnWidth = 15
    ws.Columns("C:C").ColumnWidth = 10
    ws.Columns("D:D").ColumnWidth = 18
    ws.Columns("E:E").ColumnWidth = 15
    ws.Columns("F:F").ColumnWidth = 13
    ws.Columns("G:G").ColumnWidth = 16
    ws.Columns("H:I").ColumnWidth = 11
    ws.Columns("J:K").ColumnWidth = 9
    ws.Columns("L:L").ColumnWidth = 16
    ws.Columns("M:M").Hidden = True
    ws.Rows(1).RowHeight = 30
    ws.Rows(2).RowHeight = 38
    ws.Rows(3).RowHeight = 30
    ws.Range("B4:G" & CStr(Application.Max(4, outR - 1))).NumberFormatLocal = "@"
    ws.Range("M4:M" & CStr(Application.Max(4, outR - 1))).NumberFormatLocal = "@"
    ws.Range("H4:I" & CStr(Application.Max(4, outR - 1))).NumberFormatLocal = "yyyy/m/d"
    ws.Range("L4:L" & CStr(Application.Max(4, outR - 1))).NumberFormatLocal = "yyyy/m/d h:mm"
    If outR > 4 Then
        With ws.Range("A4:L" & CStr(outR - 1))
            .Borders.LineStyle = xlContinuous
            .Borders.Color = RGB(226, 232, 240)
            .VerticalAlignment = xlCenter
            .RowHeight = 23
        End With
        With ws.Range("A4:L" & CStr(outR - 1)).FormatConditions
            .Delete
            .Add Type:=xlExpression, Formula1:="=MOD(ROW(),2)=0"
            .Item(.Count).Interior.Color = RGB(248, 250, 252)
        End With
        ws.Range("A3:M" & CStr(outR - 1)).AutoFilter
    Else
        MergeAndFormat ws.Range("A4:L4"), "�o�^�ς݌����͂���܂���B"
        ws.Range("A4:L4").HorizontalAlignment = xlCenter
        ws.Range("A4:L4").Interior.Color = RGB(248, 250, 252)
    End If

    BuildRegisteredAccountsPanel ws
    ws.ScrollArea = "A1:M" & CStr(Application.Max(50, outR + 20))
    ProtectRegisteredAccountsSheet True
    SafeFreezeSheetAt ws, "A4", 90
    If activateAfter Then
        ws.Activate
        If outR > 4 Then ws.Range("A4").Select Else ws.Range("A3").Select
    Else
        ws.Visible = xlSheetHidden
    End If
End Sub

Public Sub ProtectRegisteredAccountsSheet(Optional ByVal raiseOnError As Boolean = False)
    Dim ws As Worksheet
    Dim lastR As Long
    Dim workbookWasSaved As Boolean
    Dim errorNumber As Long, errorDescription As String
    If Not SheetExists(SH_REGISTERED_ACCOUNTS) Then Exit Sub
    Set ws = GetSheet(SH_REGISTERED_ACCOUNTS)
    workbookWasSaved = ThisWorkbook.Saved
    On Error GoTo EH
    ws.Unprotect Password:=TOOL_PASSWORD
    RestoreToolSheetScrollArea ws
    lastR = Application.Max(4, LastUsedRowInSheet(ws))
    ws.Range("A1:M" & CStr(lastR)).Locked = True
    LockToolShapes ws, False
    ws.Protect Password:=TOOL_PASSWORD, DrawingObjects:=True, Contents:=True, Scenarios:=False, _
               UserInterfaceOnly:=True, AllowFiltering:=True, AllowSorting:=False, _
               AllowFormattingCells:=False, AllowFormattingColumns:=False, AllowFormattingRows:=False
    ws.EnableSelection = xlNoRestrictions
    If Not ws.ProtectContents Or Not ws.ProtectDrawingObjects Then _
        Err.Raise vbObjectError + 3425, "ProtectRegisteredAccountsSheet", _
                  "�o�^�ς݌����ꗗ��ی�ł��܂���ł����B"
    VerifyToolShapeSecurity ws, True, False
    If workbookWasSaved Then ThisWorkbook.Saved = True
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    EmergencyProtectToolSheet ws
    If workbookWasSaved Then ThisWorkbook.Saved = True
    If raiseOnError Then Err.Raise errorNumber, "ProtectRegisteredAccountsSheet", errorDescription
End Sub

Private Function DictionaryLong(ByVal dict As Object, ByVal keyText As String) As Long
    If Not dict Is Nothing Then
        If dict.Exists(keyText) Then DictionaryLong = CLng(dict(keyText))
    End If
End Function

Private Sub BuildRegisteredAccountsPanel(ByVal ws As Worksheet)
    Dim x As Double, y As Double, w As Double, availableW As Double
    Dim gap As Double, margin As Double, wideW As Double, smallW As Double, leftX As Double
    x = ws.Range("A2").Left
    y = ws.Range("A2").Top + 1
    w = ws.Range("A2:L2").Width
    margin = 10
    gap = 8
    availableW = w - margin * 2 - gap * 3
    wideW = availableW * 0.29
    smallW = (availableW - wideW * 2) / 2
    AddPanelBack ws, x, y, w, 36
    leftX = x + margin
    AddUIButton ws, leftX, y + 4, wideW, 28, "�I�����������", "LoadSelectedAccountForEdit", "primary"
    leftX = leftX + wideW + gap
    AddUIButton ws, leftX, y + 4, wideW, 28, "�I���������폜", "DeleteSelectedAccount", "danger"
    leftX = leftX + wideW + gap
    AddUIButton ws, leftX, y + 4, smallW, 28, "�ĕ\��", "OpenRegisteredAccounts", "tool"
    leftX = leftX + smallW + gap
    AddUIButton ws, leftX, y + 4, smallW, 28, "���֖͂߂�", "ShowInputSheet", "soft"
    LockToolShapes ws, False
End Sub

Public Sub DeleteSelectedAccount()
    Dim wsList As Worksheet, wsTx As Worksheet, wsBal As Worksheet, wsAcc As Worksheet
    Dim selectedRow As Long, masterRow As Long, accountID As String
    Dim bankName As String, branchName As String, personName As String, accountType As String, accountNo As String
    Dim txSnapshot As Variant, balSnapshot As Variant, masterSnapshot As Variant
    Dim txCount As Long, balCount As Long
    Dim deleteStarted As Boolean, committed As Boolean, rollbackVerified As Boolean
    Dim deletedEditAccount As Boolean
    Dim errorNumber As Long, errorDescription As String, rollbackDetail As String, rollbackVerifyDetail As String, postDeleteDetail As String

    If Not RequireToolReady() Then Exit Sub
    If ActiveSheet Is Nothing Then Exit Sub
    If ActiveSheet.Name <> SH_REGISTERED_ACCOUNTS Then Exit Sub
    If Not RequireInternalStoresSafeForWrite() Then Exit Sub
    Set wsList = ActiveSheet
    selectedRow = ActiveCell.Row
    If selectedRow < 4 Then
        MsgBox "�폜��������̍s��I�����Ă��������B", vbInformation
        Exit Sub
    End If
    accountID = CellText(wsList.Cells(selectedRow, 13).Value)
    If Len(accountID) = 0 Then
        MsgBox "�I���s�������ID���擾�ł��܂���B�ĕ\�����đI�ђ����Ă��������B", vbExclamation
        Exit Sub
    End If
    masterRow = FindAccountRowByID(accountID)
    If masterRow = 0 Then
        MsgBox "�Ώی��������ɑ��݂��܂���B�ĕ\�����Ă��������B", vbExclamation
        Exit Sub
    End If
    Set wsTx = GetSheet(SH_WORK_TX)
    Set wsBal = GetSheet(SH_WORK_BAL)
    Set wsAcc = GetSheet(SH_WORK_ACCOUNT)
    bankName = CellText(wsAcc.Cells(masterRow, ACC_COL_BANK).Value)
    branchName = CellText(wsAcc.Cells(masterRow, ACC_COL_BRANCH).Value)
    personName = CellText(wsAcc.Cells(masterRow, ACC_COL_PERSON).Value)
    accountType = CellText(wsAcc.Cells(masterRow, ACC_COL_TYPE).Value)
    accountNo = CellText(wsAcc.Cells(masterRow, ACC_COL_NO).Value)
    txCount = CountAccountRecords(wsTx, WORK_TX_COL_ACCOUNT_ID, accountID)
    balCount = CountAccountRecords(wsBal, WORK_BAL_COL_ACCOUNT_ID, accountID)

    If MsgBox("���̌����ƁA���̎���E�c�����폜���܂��B" & vbCrLf & vbCrLf & _
              bankName & IIf(Len(branchName) > 0, " " & branchName, "") & vbCrLf & _
              personName & " / " & accountType & " / " & accountNo & vbCrLf & _
              "����� " & txCount & "�s�A�c�� " & balCount & "�s" & vbCrLf & vbCrLf & _
              "���̑�������s���܂����H", _
              vbYesNo + vbCritical + vbDefaultButton2, "�����폜�̍ŏI�m�F") <> vbYes Then Exit Sub

    On Error GoTo EH
    AppBegin "�I���������폜���Ă��܂�..."
    deletedEditAccount = (CurrentEditAccountID() = accountID)
    SnapshotRowsForAccount wsTx, WORK_TX_COL_ACCOUNT_ID, accountID, WORK_TX_COL_PERSON_ID, txSnapshot, txCount
    SnapshotRowsForAccount wsBal, WORK_BAL_COL_ACCOUNT_ID, accountID, WORK_BAL_COL_PERSON_ID, balSnapshot, balCount
    masterSnapshot = wsAcc.Range(wsAcc.Cells(masterRow, 1), wsAcc.Cells(masterRow, ACC_COL_TRANSFER_ID)).Value
    deleteStarted = True
    DeleteAccountRecords accountID, True
    If FindAccountRowByID(accountID) > 0 Or _
       CountAccountRecords(wsTx, WORK_TX_COL_ACCOUNT_ID, accountID) > 0 Or _
       CountAccountRecords(wsBal, WORK_BAL_COL_ACCOUNT_ID, accountID) > 0 Then
        Err.Raise vbObjectError + 3420, "DeleteSelectedAccount", "�폜��̊m�F�őΏۃf�[�^���c���Ă��܂��B"
    End If
    If deletedEditAccount Then SetEditAccountID ""
    MarkOutputsDirty
    InvalidateInternalIdCaches
    committed = True

    On Error Resume Next
    If deletedEditAccount Then
        ClearInputCore KEEP_NONE, True, True, True
        If Err.Number <> 0 Then
            postDeleteDetail = "�������͂̃N���A�Ɏ��s: Err " & Err.Number & " " & Err.Description
            Err.Clear
        End If
    End If
    BuildRegisteredAccountsSheet True
    If Err.Number <> 0 Then
        If Len(postDeleteDetail) > 0 Then postDeleteDetail = postDeleteDetail & " / "
        postDeleteDetail = postDeleteDetail & "�ꗗ�̍ĕ\���Ɏ��s: Err " & Err.Number & " " & Err.Description
        Err.Clear
    End If
    On Error GoTo 0
    If Len(postDeleteDetail) > 0 Then AddCheck "�x��", "�����폜�㏈��", postDeleteDetail
    AppEnd
    SetInputStatus "�������폜���܂���: " & bankName & " " & accountNo
    MsgBox "�������폜���܂����B���[�͗v�X�V��Ԃł��B", vbInformation
    Exit Sub

EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    If deleteStarted And Not committed Then
        On Error Resume Next
        Err.Clear
        RestoreDeletedAccount accountID, txSnapshot, txCount, balSnapshot, balCount, masterSnapshot
        If Err.Number <> 0 Then AppendRecordsDetail rollbackDetail, "���������G���[: " & Err.Description
        Err.Clear
        rollbackVerifyDetail = VerifyDeletedAccountRestore(accountID, txSnapshot, txCount, balSnapshot, balCount, masterSnapshot)
        If Err.Number <> 0 Then
            AppendRecordsDetail rollbackDetail, "�����m�F�G���[: " & Err.Description
        ElseIf Len(rollbackVerifyDetail) > 0 Then
            AppendRecordsDetail rollbackDetail, rollbackVerifyDetail
        Else
            rollbackVerified = True
        End If
        Err.Clear
        If deletedEditAccount And rollbackVerified Then
            SetEditAccountID accountID
            If Err.Number <> 0 Then AppendRecordsDetail rollbackDetail, "������Ԃ̕����G���[: " & Err.Description
        End If
        Err.Clear
        On Error GoTo 0
    End If
    AppForceRestore
    If deleteStarted And Not rollbackVerified Then
        AddCheck "�G���[", "�����폜���[���o�b�N", rollbackDetail
        SetInputStatus "�����폜�Ɏ��s���A�������ʂ��v�m�F�ł��BC_�`�F�b�N���m�F���Ă��������B"
    Else
        SetInputStatus "�����폜�Ɏ��s�������߁A�f�[�^�͍폜���Ă��܂���B"
        If Len(rollbackDetail) > 0 Then AddCheck "�x��", "�����폜���[���o�b�N", rollbackDetail
    End If
    MsgBox "�����폜���ɃG���[���������܂����B" & vbCrLf & _
           "Err " & errorNumber & ": " & errorDescription & _
           IIf(Len(rollbackDetail) > 0, vbCrLf & "�����m�F: " & rollbackDetail, ""), vbCritical
End Sub

Private Sub SnapshotRowsForAccount(ByVal ws As Worksheet, ByVal accountIDCol As Long, ByVal accountID As String, _
                                   ByVal lastCol As Long, ByRef snapshot As Variant, ByRef snapshotCount As Long)
    Dim r As Long, c As Long, outR As Long, lastR As Long
    Dim sourceData As Variant
    snapshotCount = 0
    lastR = LastUsedRowInSheet(ws)
    If lastR < 2 Then Exit Sub
    sourceData = ws.Range(ws.Cells(2, 1), ws.Cells(lastR, lastCol)).Value
    For r = 1 To UBound(sourceData, 1)
        If CellText(sourceData(r, accountIDCol)) = accountID Then snapshotCount = snapshotCount + 1
    Next r
    If snapshotCount = 0 Then Exit Sub
    ReDim snapshot(1 To snapshotCount, 1 To lastCol)
    For r = 1 To UBound(sourceData, 1)
        If CellText(sourceData(r, accountIDCol)) = accountID Then
            outR = outR + 1
            For c = 1 To lastCol
                snapshot(outR, c) = sourceData(r, c)
            Next c
        End If
    Next r
End Sub

Private Sub RestoreDeletedAccount(ByVal accountID As String, ByRef txSnapshot As Variant, ByVal txCount As Long, _
                                  ByRef balSnapshot As Variant, ByVal balCount As Long, ByRef masterSnapshot As Variant)
    Dim wsTx As Worksheet, wsBal As Worksheet, wsAcc As Worksheet
    Dim firstR As Long, masterRow As Long
    Dim restoreProblems As String
    Dim txCleared As Boolean, balCleared As Boolean
    Set wsTx = GetSheet(SH_WORK_TX)
    Set wsBal = GetSheet(SH_WORK_BAL)
    Set wsAcc = GetSheet(SH_WORK_ACCOUNT)

    On Error Resume Next
    Err.Clear
    CompactDeleteDataRows wsTx, WORK_TX_COL_PERSON_ID, WORK_TX_COL_ACCOUNT_ID, accountID
    If Err.Number <> 0 Then
        AppendRecordsDetail restoreProblems, "�Ώێ���̐���: " & Err.Description
    Else
        txCleared = True
    End If
    Err.Clear
    CompactDeleteDataRows wsBal, WORK_BAL_COL_PERSON_ID, WORK_BAL_COL_ACCOUNT_ID, accountID
    If Err.Number <> 0 Then
        AppendRecordsDetail restoreProblems, "�Ώێc���̐���: " & Err.Description
    Else
        balCleared = True
    End If

    If txCleared And txCount > 0 Then
        Err.Clear
        firstR = LastUsedRowInSheet(wsTx) + 1
        If firstR < 2 Then firstR = 2
        wsTx.Range(wsTx.Cells(firstR, 1), wsTx.Cells(firstR + txCount - 1, OUT_COL_ACCOUNT_NO)).NumberFormatLocal = "@"
        wsTx.Range(wsTx.Cells(firstR, OUT_COL_SHOP), wsTx.Cells(firstR + txCount - 1, OUT_COL_TEKIYO)).NumberFormatLocal = "@"
        wsTx.Range(wsTx.Cells(firstR, WORK_TX_COL_RELATIONSHIP), wsTx.Cells(firstR + txCount - 1, WORK_TX_COL_PERSON_ID)).NumberFormatLocal = "@"
        wsTx.Range(wsTx.Cells(firstR, 1), wsTx.Cells(firstR + txCount - 1, WORK_TX_COL_PERSON_ID)).Value = txSnapshot
        If Err.Number <> 0 Then AppendRecordsDetail restoreProblems, "����̏��߂�: " & Err.Description
    End If
    If balCleared And balCount > 0 Then
        Err.Clear
        firstR = LastUsedRowInSheet(wsBal) + 1
        If firstR < 2 Then firstR = 2
        wsBal.Range(wsBal.Cells(firstR, 1), wsBal.Cells(firstR + balCount - 1, 5)).NumberFormatLocal = "@"
        wsBal.Range(wsBal.Cells(firstR, 9), wsBal.Cells(firstR + balCount - 1, 9)).NumberFormatLocal = "@"
        wsBal.Range(wsBal.Cells(firstR, 11), wsBal.Cells(firstR + balCount - 1, WORK_BAL_COL_PERSON_ID)).NumberFormatLocal = "@"
        wsBal.Range(wsBal.Cells(firstR, 1), wsBal.Cells(firstR + balCount - 1, WORK_BAL_COL_PERSON_ID)).Value = balSnapshot
        If Err.Number <> 0 Then AppendRecordsDetail restoreProblems, "�c���̏��߂�: " & Err.Description
    End If

    Err.Clear
    masterRow = FindAccountRowByID(accountID)
    If Err.Number <> 0 Then
        AppendRecordsDetail restoreProblems, "�����}�X�^�̌���: " & Err.Description
    Else
        If masterRow = 0 Then
            masterRow = LastUsedRowInSheet(wsAcc) + 1
            If masterRow < 2 Then masterRow = 2
        End If
        Err.Clear
        wsAcc.Range(wsAcc.Cells(masterRow, ACC_COL_ID), wsAcc.Cells(masterRow, ACC_COL_NO)).NumberFormatLocal = "@"
        wsAcc.Range(wsAcc.Cells(masterRow, ACC_COL_PERSON_ID), wsAcc.Cells(masterRow, ACC_COL_SOURCE)).NumberFormatLocal = "@"
        wsAcc.Cells(masterRow, ACC_COL_TRANSFER_ID).NumberFormatLocal = "@"
        wsAcc.Range(wsAcc.Cells(masterRow, 1), wsAcc.Cells(masterRow, ACC_COL_TRANSFER_ID)).Value = masterSnapshot
        If Err.Number <> 0 Then AppendRecordsDetail restoreProblems, "�����}�X�^�̏��߂�: " & Err.Description
    End If
    Err.Clear
    FormatWorkTx
    If Err.Number <> 0 Then AppendRecordsDetail restoreProblems, "��������̕���: " & Err.Description
    Err.Clear
    FormatWorkBal
    If Err.Number <> 0 Then AppendRecordsDetail restoreProblems, "�c�������̕���: " & Err.Description
    Err.Clear
    InvalidateInternalIdCaches
    If Err.Number <> 0 Then AppendRecordsDetail restoreProblems, "����ID�����̍X�V: " & Err.Description
    On Error GoTo 0
    If Len(restoreProblems) > 0 Then _
        Err.Raise vbObjectError + 3428, "RestoreDeletedAccount", restoreProblems
End Sub

Private Sub AppendRecordsDetail(ByRef detailText As String, ByVal newDetail As String)
    newDetail = Trim$(newDetail)
    If Len(newDetail) = 0 Then Exit Sub
    If Len(detailText) > 0 Then detailText = detailText & " / "
    detailText = detailText & newDetail
End Sub

Private Function VerifyDeletedAccountRestore(ByVal accountID As String, ByRef txSnapshot As Variant, _
                                             ByVal expectedTxCount As Long, ByRef balSnapshot As Variant, _
                                             ByVal expectedBalCount As Long, ByRef masterSnapshot As Variant) As String
    Dim problems As String
    If FindAccountRowByID(accountID) = 0 Then problems = problems & "�����}�X�^�𕜌��ł��܂���B "
    If CountAccountRecords(GetSheet(SH_WORK_TX), WORK_TX_COL_ACCOUNT_ID, accountID) <> expectedTxCount Then _
        problems = problems & "����s���������O�ƈ�v���܂���B "
    If CountAccountRecords(GetSheet(SH_WORK_BAL), WORK_BAL_COL_ACCOUNT_ID, accountID) <> expectedBalCount Then _
        problems = problems & "�c���s���������O�ƈ�v���܂���B "
    If Not DeletedRowsMatchSnapshot(GetSheet(SH_WORK_TX), WORK_TX_COL_ACCOUNT_ID, accountID, _
                                    txSnapshot, expectedTxCount, WORK_TX_COL_PERSON_ID) Then _
        problems = problems & "������e�������O�ƈ�v���܂���B "
    If Not DeletedRowsMatchSnapshot(GetSheet(SH_WORK_BAL), WORK_BAL_COL_ACCOUNT_ID, accountID, _
                                    balSnapshot, expectedBalCount, WORK_BAL_COL_PERSON_ID) Then _
        problems = problems & "�c�����e�������O�ƈ�v���܂���B "
    If Not DeletedMasterMatchesSnapshot(accountID, masterSnapshot) Then _
        problems = problems & "�����}�X�^���e�������O�ƈ�v���܂���B "
    VerifyDeletedAccountRestore = Trim$(problems)
End Function

Private Function DeletedRowsMatchSnapshot(ByVal ws As Worksheet, ByVal accountIDCol As Long, _
                                          ByVal accountID As String, ByRef snapshot As Variant, _
                                          ByVal expectedCount As Long, ByVal lastCol As Long) As Boolean
    Dim r As Long, c As Long, snapshotRow As Long
    Dim lastR As Long, sourceData As Variant
    If ws Is Nothing Then Exit Function
    If expectedCount = 0 Then
        DeletedRowsMatchSnapshot = (CountAccountRecords(ws, accountIDCol, accountID) = 0)
        Exit Function
    End If
    If Not IsArray(snapshot) Then Exit Function
    lastR = LastUsedRowInSheet(ws)
    If lastR < 2 Then Exit Function
    sourceData = ws.Range(ws.Cells(2, 1), ws.Cells(lastR, lastCol)).Value
    For r = 1 To UBound(sourceData, 1)
        If CellText(sourceData(r, accountIDCol)) = accountID Then
            snapshotRow = snapshotRow + 1
            If snapshotRow > expectedCount Then Exit Function
            For c = 1 To lastCol
                If CellText(sourceData(r, c)) <> CellText(snapshot(snapshotRow, c)) Then Exit Function
            Next c
        End If
    Next r
    DeletedRowsMatchSnapshot = (snapshotRow = expectedCount)
End Function

Private Function DeletedMasterMatchesSnapshot(ByVal accountID As String, ByRef snapshot As Variant) As Boolean
    Dim ws As Worksheet, r As Long, c As Long
    If Not IsArray(snapshot) Then Exit Function
    Set ws = GetSheet(SH_WORK_ACCOUNT)
    r = FindAccountRowByID(accountID)
    If r = 0 Then Exit Function
    For c = 1 To ACC_COL_TRANSFER_ID
        If CellText(ws.Cells(r, c).Value) <> CellText(snapshot(1, c)) Then Exit Function
    Next c
    DeletedMasterMatchesSnapshot = True
End Function

Public Sub LoadSelectedAccountForEdit()
    Dim ws As Worksheet
    Dim r As Long, accountID As String
    If Not RequireToolReady() Then Exit Sub
    If ActiveSheet Is Nothing Then Exit Sub
    If ActiveSheet.Name <> SH_REGISTERED_ACCOUNTS Then Exit Sub
    Set ws = ActiveSheet
    r = ActiveCell.Row
    If r < 4 Then
        SetInputStatus "������������̍s��I�����Ă��������B"
        Exit Sub
    End If
    accountID = CellText(ws.Cells(r, 13).Value)
    If Len(accountID) = 0 Then Exit Sub
    If IsEditMode() Then
        If MsgBox("���݂̒������͂�j�����A�I������������ǂݍ��݂܂����H", _
                  vbYesNo + vbExclamation + vbDefaultButton2, "�����Ώۂ̐ؑ֊m�F") <> vbYes Then Exit Sub
    ElseIf CurrentAccountInputHasData() Then
        If MsgBox("���݂̖��o�^���͂�j�����A�I�����������������ʂ֓ǂݍ��݂܂����H", _
                  vbYesNo + vbExclamation + vbDefaultButton2, "���o�^���͂̔j���m�F") <> vbYes Then Exit Sub
    End If
    LoadAccountForEdit accountID
End Sub

Public Sub LoadAccountForEdit(ByVal accountID As String)
    Dim wsIn As Worksheet, wsAcc As Worksheet
    Dim accR As Long
    Dim txCount As Long
    Dim previousEditAccountID As String
    Dim inputSnapshot As Variant
    Dim loadStarted As Boolean, snapshotCaptured As Boolean
    Dim errorNumber As Long, errorDescription As String, rollbackDetail As String

    If Not RequireToolReady() Then Exit Sub
    On Error GoTo EH
    previousEditAccountID = CurrentEditAccountID()
    '��ꂽ�����s���󗓂Ƃ��ēǂݍ��݁A�����ۑ��ŏ����Ă��܂�Ȃ��悤�A���͔j�����O�ɐ��������m�F����B
    SelfCheckTool False, False
    accR = FindAccountRowByID(accountID)
    If accR = 0 Then Exit Sub
    txCount = CountAccountRecords(GetSheet(SH_WORK_TX), WORK_TX_COL_ACCOUNT_ID, accountID, RECORD_TRANSACTION)
    If txCount > TX_LAST_ROW - TX_FIRST_ROW + 1 Then
        SetInputStatus "����s�����͗��̏���𒴂��邽�ߒ�����ʂ֓ǂݍ��߂܂���B"
        Exit Sub
    End If

    inputSnapshot = CaptureInputForEditLoad(GetSheet(SH_INPUT))
    snapshotCaptured = True
    AppBegin "�o�^�ς݌�����ǂݍ���ł��܂�..."
    loadStarted = True
    ClearInputForRecordLoad
    Set wsIn = GetSheet(SH_INPUT)
    Set wsAcc = GetSheet(SH_WORK_ACCOUNT)
    wsIn.Unprotect Password:=TOOL_PASSWORD
    wsIn.Range(CELL_BANK).Value = wsAcc.Cells(accR, ACC_COL_BANK).Value
    wsIn.Range(CELL_BRANCH).Value = wsAcc.Cells(accR, ACC_COL_BRANCH).Value
    wsIn.Range(CELL_PERSON).Value = wsAcc.Cells(accR, ACC_COL_PERSON).Value
    wsIn.Range(CELL_RELATIONSHIP).Value = wsAcc.Cells(accR, ACC_COL_RELATIONSHIP).Value
    wsIn.Range(CELL_ACCOUNT_TYPE).Value = wsAcc.Cells(accR, ACC_COL_TYPE).Value
    wsIn.Range(CELL_ACCOUNT_NO).Value = wsAcc.Cells(accR, ACC_COL_NO).Value
    wsIn.Range(CELL_OPEN_DATE).Value = wsAcc.Cells(accR, ACC_COL_OPEN_DATE).Value
    wsIn.Range(CELL_CLOSE_DATE).Value = wsAcc.Cells(accR, ACC_COL_CLOSE_DATE).Value

    LoadBalancesForEdit wsIn, accountID
    LoadTransactionsForEdit wsIn, accountID
    SetEditAccountID accountID
    ApplyBalanceAvailability wsIn
    ProtectInputSheet True
    wsIn.Visible = xlSheetVisible
    wsIn.Activate
    SafeSelectCell wsIn, CELL_BANK
    AppEnd
    SetInputStatus "�������@���e�𒼂��āu�����𔽉f�v�������Ă��������B"
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    If loadStarted And snapshotCaptured Then
        On Error Resume Next
        RestoreInputAfterEditLoad GetSheet(SH_INPUT), inputSnapshot, previousEditAccountID
        If Err.Number <> 0 Then rollbackDetail = " / �Ǎ��O���͂̕����G���[: " & Err.Description
        On Error GoTo 0
    Else
        On Error Resume Next
        SetEditAccountID previousEditAccountID
        On Error GoTo 0
    End If
    ProtectInputSheet
    AppForceRestore
    EnableInputKeys
    If Len(rollbackDetail) = 0 Then
        SetInputStatus "�o�^�ς݌�����ǂݍ��߂܂���ł����B�Ǎ��O�̓��͂𕜌����܂����B"
    Else
        SetInputStatus "�o�^�ς݌����̓Ǎ��Ɠ��͕����Ɏ��s���܂����BC_�`�F�b�N���m�F���Ă��������B"
        AddCheck "�G���[", "�����Ǎ����[���o�b�N", rollbackDetail
    End If
    MsgBox "�����f�[�^�̓Ǎ����ɃG���[���������܂����B" & vbCrLf & _
           "Err " & errorNumber & ": " & errorDescription & rollbackDetail, vbExclamation
End Sub

Private Function CaptureInputForEditLoad(ByVal ws As Worksheet) As Variant
    '�����Ώۂ̓Ǎ��r���Ŏ��s���Ă��A���O�̖��o�^���́E�������͂�����Ȃ��B
    Dim accountValues As Variant, balanceValues As Variant, transactionValues As Variant
    If ws Is Nothing Then Err.Raise vbObjectError + 3302, "CaptureInputForEditLoad", "���̓V�[�g���擾�ł��܂���B"
    accountValues = Array(ws.Range(CELL_BANK).Value, ws.Range(CELL_BRANCH).Value, _
                          ws.Range(CELL_PERSON).Value, ws.Range(CELL_RELATIONSHIP).Value, _
                          ws.Range(CELL_ACCOUNT_TYPE).Value, ws.Range(CELL_ACCOUNT_NO).Value, _
                          ws.Range(CELL_OPEN_DATE).Value, ws.Range(CELL_CLOSE_DATE).Value)
    balanceValues = ws.Range(ws.Cells(BAL_VALUE_ROW, BAL_FIRST_COL), _
                             ws.Cells(BAL_VALUE_ROW, BAL_MAX_COL)).Value
    transactionValues = ws.Range(ws.Cells(TX_FIRST_ROW, COL_TX_YEAR), _
                                 ws.Cells(TX_LAST_ROW, COL_TX_BALANCE)).Value
    CaptureInputForEditLoad = Array(accountValues, balanceValues, transactionValues)
End Function

Private Sub RestoreInputAfterEditLoad(ByVal ws As Worksheet, ByVal snapshot As Variant, _
                                      ByVal previousEditAccountID As String)
    Dim accountValues As Variant
    If ws Is Nothing Then Err.Raise vbObjectError + 3303, "RestoreInputAfterEditLoad", "���̓V�[�g���擾�ł��܂���B"
    If Not IsArray(snapshot) Then Err.Raise vbObjectError + 3304, "RestoreInputAfterEditLoad", "���͑ޔ�l������܂���B"
    accountValues = snapshot(LBound(snapshot))
    ws.Unprotect Password:=TOOL_PASSWORD
    ws.Range(CELL_BANK).Value = accountValues(0)
    ws.Range(CELL_BRANCH).Value = accountValues(1)
    ws.Range(CELL_PERSON).Value = accountValues(2)
    ws.Range(CELL_RELATIONSHIP).Value = accountValues(3)
    ws.Range(CELL_ACCOUNT_TYPE).Value = accountValues(4)
    ws.Range(CELL_ACCOUNT_NO).Value = accountValues(5)
    ws.Range(CELL_OPEN_DATE).Value = accountValues(6)
    ws.Range(CELL_CLOSE_DATE).Value = accountValues(7)
    ws.Range(ws.Cells(BAL_VALUE_ROW, BAL_FIRST_COL), _
             ws.Cells(BAL_VALUE_ROW, BAL_MAX_COL)).Value = snapshot(LBound(snapshot) + 1)
    ws.Range(ws.Cells(TX_FIRST_ROW, COL_TX_YEAR), _
             ws.Cells(TX_LAST_ROW, COL_TX_BALANCE)).Value = snapshot(LBound(snapshot) + 2)
    InvalidateDateComplementCache
    SetEditAccountID previousEditAccountID
    ApplyBalanceAvailability ws
    ProtectInputSheet True
End Sub

Private Sub LoadBalancesForEdit(ByVal wsIn As Worksheet, ByVal accountID As String)
    Dim wsBal As Worksheet
    Dim lastR As Long, r As Long, c As Long, memoCol As Long
    Dim targetDate As Variant
    Dim seenDates As Object, gridColumnByDate As Object, dateKey As String
    Dim memoText As String, selectedMemo As String
    Dim balanceData As Variant
    Set seenDates = CreateObject("Scripting.Dictionary")
    seenDates.CompareMode = vbTextCompare
    Set gridColumnByDate = CreateObject("Scripting.Dictionary")
    gridColumnByDate.CompareMode = vbTextCompare
    Set wsBal = GetSheet(SH_WORK_BAL)
    lastR = LastUsedRowInSheet(wsBal)
    memoCol = BalanceMemoCol(wsIn)
    For c = BAL_FIRST_COL To memoCol - 1
        If IsDate(wsIn.Cells(BAL_DATE_ROW, c).Value) Then _
            gridColumnByDate(Format$(CDate(wsIn.Cells(BAL_DATE_ROW, c).Value), "yyyymmdd")) = c
    Next c
    If lastR < 2 Then Exit Sub
    balanceData = wsBal.Range(wsBal.Cells(2, 1), wsBal.Cells(lastR, WORK_BAL_COL_PERSON_ID)).Value2
    For r = 1 To UBound(balanceData, 1)
        If CellText(balanceData(r, WORK_BAL_COL_ACCOUNT_ID)) = accountID Then
            targetDate = balanceData(r, 8)
            If Not IsDate(targetDate) Then _
                Err.Raise vbObjectError + 3306, "LoadBalancesForEdit", _
                          "�c��������s���ł��B�Z���t�`�F�b�N��W_�c�����m�F���Ă��������i" & CStr(r + 1) & "�s�j�B"
            dateKey = Format$(CDate(targetDate), "yyyymmdd")
            If seenDates.Exists(dateKey) Then
                Err.Raise vbObjectError + 3301, "LoadBalancesForEdit", _
                          "��������̎c�����d�����Ă��܂��B�Z���t�`�F�b�N��W_�c�����m�F���Ă�������: " & Format$(CDate(targetDate), "yyyy/m/d")
            End If
            seenDates.Add dateKey, True
            If gridColumnByDate.Exists(dateKey) Then _
                wsIn.Cells(BAL_VALUE_ROW, CLng(gridColumnByDate(dateKey))).Value = balanceData(r, 10)
            memoText = CellText(balanceData(r, 11))
            If Len(memoText) > 0 Then
                If Len(selectedMemo) > 0 And StrComp(selectedMemo, memoText, vbBinaryCompare) <> 0 Then
                    Err.Raise vbObjectError + 3305, "LoadBalancesForEdit", _
                              "��������̎c�������ɈقȂ���e������܂��B�Z���t�`�F�b�N��W_�c�����m�F���Ă��������B"
                End If
                selectedMemo = memoText
            End If
        End If
    Next r
    If Len(selectedMemo) > 0 Then wsIn.Cells(BAL_VALUE_ROW, memoCol).Value = selectedMemo
End Sub

Private Sub LoadTransactionsForEdit(ByVal wsIn As Worksheet, ByVal accountID As String)
    Dim wsTx As Worksheet
    Dim lastR As Long, r As Long, outCount As Long, outputColumns As Long
    Dim txDate As Variant, txTime As Variant
    Dim txData As Variant, inputData() As Variant
    Set wsTx = GetSheet(SH_WORK_TX)
    lastR = LastUsedRowInSheet(wsTx)
    If lastR < 2 Then Exit Sub
    outputColumns = COL_TX_BALANCE - COL_TX_YEAR + 1
    ReDim inputData(1 To TX_LAST_ROW - TX_FIRST_ROW + 1, 1 To outputColumns)
    txData = wsTx.Range(wsTx.Cells(2, 1), wsTx.Cells(lastR, WORK_TX_COL_PERSON_ID)).Value2
    For r = 1 To UBound(txData, 1)
        If CellText(txData(r, WORK_TX_COL_ACCOUNT_ID)) = accountID And _
           CellText(txData(r, WORK_TX_COL_RECORD_TYPE)) = RECORD_TRANSACTION Then
            outCount = outCount + 1
            If outCount > UBound(inputData, 1) Then _
                Err.Raise vbObjectError + 3307, "LoadTransactionsForEdit", _
                          "�����Ώۂ̎���s�����͗��̏���𒴂��Ă��܂��B"
            txDate = txData(r, OUT_COL_DATE)
            If Not IsDate(txDate) Then _
                Err.Raise vbObjectError + 3308, "LoadTransactionsForEdit", _
                          "������t���s���ł��B�Z���t�`�F�b�N��W_������m�F���Ă��������i" & CStr(r + 1) & "�s�j�B"
            '�������͊e�s�����Ȋ��������A�㑱�s���O���E�O�N������Ĉ����p���Ȃ��悤�ɂ���B
            inputData(outCount, COL_TX_YEAR - COL_TX_YEAR + 1) = Year(CDate(txDate))
            inputData(outCount, COL_TX_MONTH - COL_TX_YEAR + 1) = Month(CDate(txDate))
            inputData(outCount, COL_TX_DAY - COL_TX_YEAR + 1) = Day(CDate(txDate))
            txTime = txData(r, OUT_COL_TIME)
            If HasText(txTime) Then
                If Not IsDate(txTime) Then _
                    Err.Raise vbObjectError + 3309, "LoadTransactionsForEdit", _
                              "����������s���ł��B�Z���t�`�F�b�N��W_������m�F���Ă��������i" & CStr(r + 1) & "�s�j�B"
                inputData(outCount, COL_TX_TIME - COL_TX_YEAR + 1) = Format$(CDate(txTime), "hhmm")
            End If
            inputData(outCount, COL_TX_WITHDRAW - COL_TX_YEAR + 1) = txData(r, OUT_COL_WITHDRAW)
            inputData(outCount, COL_TX_DEPOSIT - COL_TX_YEAR + 1) = txData(r, OUT_COL_DEPOSIT)
            inputData(outCount, COL_TX_SHOP - COL_TX_YEAR + 1) = txData(r, OUT_COL_SHOP)
            inputData(outCount, COL_TX_MACHINE - COL_TX_YEAR + 1) = txData(r, OUT_COL_MACHINE)
            inputData(outCount, COL_TX_TEKIYO - COL_TX_YEAR + 1) = txData(r, OUT_COL_TEKIYO)
            inputData(outCount, COL_TX_BALANCE - COL_TX_YEAR + 1) = txData(r, OUT_COL_OTHER)
        End If
    Next r
    wsIn.Range(wsIn.Cells(TX_FIRST_ROW, COL_TX_YEAR), _
               wsIn.Cells(TX_LAST_ROW, COL_TX_BALANCE)).Value = inputData
    InvalidateDateComplementCache
End Sub

Public Sub CancelCorrection()
    If Not RequireToolReady() Then Exit Sub
    If IsEditMode() Then
        If MsgBox("���͒��̒������e��j�����āA�����𒆎~���܂����H", _
                  vbYesNo + vbExclamation + vbDefaultButton2, "�����̒��~�m�F") <> vbYes Then Exit Sub
    End If
    SetEditAccountID ""
    ClearInputCore KEEP_NONE, True, True, True
    If SheetExists(SH_INPUT) Then SafeSelectCell GetSheet(SH_INPUT), CELL_BANK
    SetInputStatus "�������I�����܂����B"
End Sub

Public Sub SynchronizePersonRelationship(ByVal personID As String, ByVal relationshipText As String)
    '�����͌����ł͂Ȃ��l���ɑ����鑮���Ƃ��Ĉ����B�������͓���l��ID�̑S�L�^�𓯎��ɂ��낦��B
    Dim wsAcc As Worksheet, wsTx As Worksheet, wsBal As Worksheet, wsPerson As Worksheet
    Dim lastAcc As Long, lastTx As Long, lastBal As Long, lastPerson As Long
    Dim snapAcc As Variant, snapTx As Variant, snapBal As Variant, snapPerson As Variant
    Dim errorNumber As Long, errorDescription As String, restoreDescription As String
    If Len(Trim$(CellText(personID))) = 0 Then _
        Err.Raise vbObjectError + 3412, "SynchronizePersonRelationship", "�l��ID������܂���B"

    On Error GoTo EH
    Set wsAcc = GetSheet(SH_WORK_ACCOUNT)
    Set wsTx = GetSheet(SH_WORK_TX)
    Set wsBal = GetSheet(SH_WORK_BAL)
    lastAcc = LastUsedRowInSheet(wsAcc)
    lastTx = LastUsedRowInSheet(wsTx)
    lastBal = LastUsedRowInSheet(wsBal)
    If SheetExists(SH_PERSON_CAND) Then
        Set wsPerson = GetSheet(SH_PERSON_CAND)
        lastPerson = LastUsedRowInSheet(wsPerson)
    End If

    If lastAcc >= 2 Then snapAcc = wsAcc.Range(wsAcc.Cells(2, ACC_COL_RELATIONSHIP), wsAcc.Cells(lastAcc, ACC_COL_RELATIONSHIP)).Value2
    If lastTx >= 2 Then snapTx = wsTx.Range(wsTx.Cells(2, WORK_TX_COL_RELATIONSHIP), wsTx.Cells(lastTx, WORK_TX_COL_RELATIONSHIP)).Value2
    If lastBal >= 2 Then snapBal = wsBal.Range(wsBal.Cells(2, WORK_BAL_COL_RELATIONSHIP), wsBal.Cells(lastBal, WORK_BAL_COL_RELATIONSHIP)).Value2
    If lastPerson >= 2 Then snapPerson = wsPerson.Range(wsPerson.Cells(2, 3), wsPerson.Cells(lastPerson, 3)).Value2

    SynchronizeRelationshipColumn wsAcc, lastAcc, ACC_COL_PERSON_ID, ACC_COL_RELATIONSHIP, _
                                  personID, relationshipText, 3413, "�����}�X�^"
    SynchronizeRelationshipColumn wsTx, lastTx, WORK_TX_COL_PERSON_ID, WORK_TX_COL_RELATIONSHIP, _
                                  personID, relationshipText, 3414, "����L�^"
    SynchronizeRelationshipColumn wsBal, lastBal, WORK_BAL_COL_PERSON_ID, WORK_BAL_COL_RELATIONSHIP, _
                                  personID, relationshipText, 3415, "�c���L�^"
    If Not wsPerson Is Nothing Then _
        SynchronizeRelationshipColumn wsPerson, lastPerson, 2, 3, personID, relationshipText, 3416, "�l�����"
    Exit Sub

EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    On Error Resume Next
    If lastAcc >= 2 Then wsAcc.Range(wsAcc.Cells(2, ACC_COL_RELATIONSHIP), wsAcc.Cells(lastAcc, ACC_COL_RELATIONSHIP)).Value2 = snapAcc
    If lastTx >= 2 Then wsTx.Range(wsTx.Cells(2, WORK_TX_COL_RELATIONSHIP), wsTx.Cells(lastTx, WORK_TX_COL_RELATIONSHIP)).Value2 = snapTx
    If lastBal >= 2 Then wsBal.Range(wsBal.Cells(2, WORK_BAL_COL_RELATIONSHIP), wsBal.Cells(lastBal, WORK_BAL_COL_RELATIONSHIP)).Value2 = snapBal
    If lastPerson >= 2 Then wsPerson.Range(wsPerson.Cells(2, 3), wsPerson.Cells(lastPerson, 3)).Value2 = snapPerson
    If Err.Number <> 0 Then restoreDescription = " / �����̕����G���[: " & Err.Description
    On Error GoTo 0
    Err.Raise errorNumber, "SynchronizePersonRelationship", errorDescription & restoreDescription
End Sub

Private Sub SynchronizeRelationshipColumn(ByVal ws As Worksheet, ByVal lastR As Long, _
                                          ByVal personIDCol As Long, ByVal relationshipCol As Long, _
                                          ByVal personID As String, ByVal relationshipText As String, _
                                          ByVal verifyErrorOffset As Long, ByVal labelText As String)
    Dim rowCount As Long, r As Long
    Dim idData As Variant, relationshipData As Variant, verifyData As Variant
    Dim expectedKey As String, changed As Boolean
    If ws Is Nothing Or lastR < 2 Then Exit Sub
    rowCount = lastR - 1
    idData = ws.Range(ws.Cells(2, personIDCol), ws.Cells(lastR, personIDCol)).Value2
    relationshipData = ws.Range(ws.Cells(2, relationshipCol), ws.Cells(lastR, relationshipCol)).Value2
    For r = 1 To rowCount
        If StrComp(CellText(RecordsColumnValue(idData, r, rowCount)), personID, vbTextCompare) = 0 Then
            SetRecordsColumnValue relationshipData, r, rowCount, relationshipText
            changed = True
        End If
    Next r
    If Not changed Then Exit Sub
    ws.Range(ws.Cells(2, relationshipCol), ws.Cells(lastR, relationshipCol)).Value2 = relationshipData
    verifyData = ws.Range(ws.Cells(2, relationshipCol), ws.Cells(lastR, relationshipCol)).Value2
    expectedKey = NormalizeRelationshipKey(relationshipText)
    For r = 1 To rowCount
        If StrComp(CellText(RecordsColumnValue(idData, r, rowCount)), personID, vbTextCompare) = 0 Then
            If NormalizeRelationshipKey(CellText(RecordsColumnValue(verifyData, r, rowCount))) <> expectedKey Then _
                Err.Raise vbObjectError + verifyErrorOffset, "SynchronizeRelationshipColumn", _
                          labelText & "�̑����X�V���m�F�ł��܂���B"
        End If
    Next r
End Sub

Private Function RecordsColumnValue(ByRef sourceData As Variant, ByVal rowIndex As Long, _
                                    ByVal rowCount As Long) As Variant
    If rowCount = 1 Then
        If rowIndex <> 1 Then Err.Raise vbObjectError + 3417, "RecordsColumnValue", "��z��̍s�ԍ����s���ł��B"
        RecordsColumnValue = sourceData
    Else
        RecordsColumnValue = sourceData(rowIndex, 1)
    End If
End Function

Private Sub SetRecordsColumnValue(ByRef targetData As Variant, ByVal rowIndex As Long, _
                                  ByVal rowCount As Long, ByVal newValue As Variant)
    If rowCount = 1 Then
        If rowIndex <> 1 Then Err.Raise vbObjectError + 3418, "SetRecordsColumnValue", "��z��̍s�ԍ����s���ł��B"
        targetData = newValue
    Else
        targetData(rowIndex, 1) = newValue
    End If
End Sub

Public Function PersonIDForName(ByVal personName As String, Optional ByVal relationshipText As String = "") As String
    Dim ws As Worksheet
    Dim lastR As Long, r As Long
    Dim personKey As String, candidateID As String, relationshipKey As String
    Dim allIDs As Object, matchingRelationshipIDs As Object
    Dim personData As Variant, accountData As Variant
    personKey = NormalizePersonNameKey(personName)
    If Len(personKey) = 0 Then Exit Function
    relationshipKey = NormalizeRelationshipKey(relationshipText)
    Set allIDs = CreateObject("Scripting.Dictionary")
    Set matchingRelationshipIDs = CreateObject("Scripting.Dictionary")
    allIDs.CompareMode = vbTextCompare
    matchingRelationshipIDs.CompareMode = vbTextCompare

    '���\���ɎQ�Ƃ��邪�A���X�V�Ɏ��s�E��C�����ꂽ�ꍇ�ł��A
    '���������̐l��ID�𐳂Ƃ��ē���l���֕�ID�𔭍s���Ȃ��B
    If SheetExists(SH_PERSON_CAND) Then
        Set ws = GetSheet(SH_PERSON_CAND)
        lastR = LastUsedRowInSheet(ws)
        If lastR >= 2 Then
            personData = ws.Range(ws.Cells(2, 1), ws.Cells(lastR, 3)).Value2
        End If
        For r = 1 To lastR - 1
            If NormalizePersonNameKey(CellText(personData(r, 1))) = personKey Then
                candidateID = CellText(personData(r, 2))
                If Len(candidateID) > 0 Then
                    AddPersonIDMatch allIDs, matchingRelationshipIDs, candidateID, _
                                     CellText(personData(r, 3)), relationshipKey
                End If
            End If
        Next r
    End If

    If SheetExists(SH_WORK_ACCOUNT) Then
        Set ws = GetSheet(SH_WORK_ACCOUNT)
        lastR = LastUsedRowInSheet(ws)
        If lastR >= 2 Then
            accountData = ws.Range(ws.Cells(2, ACC_COL_PERSON), _
                                   ws.Cells(lastR, ACC_COL_PERSON_ID)).Value2
        End If
        For r = 1 To lastR - 1
            If NormalizePersonNameKey(CellText(accountData(r, 1))) = personKey Then
                candidateID = CellText(accountData(r, ACC_COL_PERSON_ID - ACC_COL_PERSON + 1))
                If Len(candidateID) > 0 Then
                    AddPersonIDMatch allIDs, matchingRelationshipIDs, candidateID, _
                                     CellText(accountData(r, ACC_COL_RELATIONSHIP - ACC_COL_PERSON + 1)), relationshipKey
                End If
            End If
        Next r
    End If
    If Len(relationshipKey) > 0 Then
        If matchingRelationshipIDs.Count = 1 Then
            PersonIDForName = OnlyDictionaryKey(matchingRelationshipIDs)
        ElseIf matchingRelationshipIDs.Count > 1 Then
            Err.Raise vbObjectError + 3410, "PersonIDForName", _
                      "���������E�����ɕ����̐l��ID������܂��B�Z���t�`�F�b�N�����s���Ă�������: " & personName
        End If
    ElseIf allIDs.Count = 1 Then
        PersonIDForName = OnlyDictionaryKey(allIDs)
    ElseIf allIDs.Count > 1 Then
        Err.Raise vbObjectError + 3411, "PersonIDForName", _
                  "���������̐l�����������܂��B��������͂��Đl������肵�Ă�������: " & personName
    End If
End Function

Private Function OnlyDictionaryKey(ByVal dict As Object) As String
    Dim keys As Variant
    If dict Is Nothing Then Exit Function
    If dict.Count <> 1 Then Exit Function
    keys = dict.Keys
    OnlyDictionaryKey = CStr(keys(0))
End Function

Private Sub AddPersonIDMatch(ByVal allIDs As Object, ByVal relationshipIDs As Object, _
                             ByVal personID As String, ByVal storedRelationship As String, _
                             ByVal requestedRelationshipKey As String)
    Dim storedKey As String
    If Len(personID) = 0 Then Exit Sub
    allIDs(personID) = True
    If Len(requestedRelationshipKey) = 0 Then Exit Sub
    storedKey = NormalizeRelationshipKey(storedRelationship)
    If storedKey = requestedRelationshipKey Then relationshipIDs(personID) = True
End Sub

Public Function NormalizeRelationshipKey(ByVal relationshipText As String) As String
    Dim s As String
    s = UCase$(Trim$(CellText(relationshipText)))
    s = Replace(s, " ", "")
    s = Replace(s, "�@", "")
    NormalizeRelationshipKey = s
End Function

Public Function PersonIdentityKey(ByVal personName As String, ByVal relationshipText As String) As String
    Dim personKey As String
    personKey = NormalizePersonNameKey(personName)
    If Len(personKey) = 0 Then Exit Function
    PersonIdentityKey = personKey & Chr$(29) & NormalizeRelationshipKey(relationshipText)
End Function

Public Function RelationshipForName(ByVal personName As String) As String
    Dim ws As Worksheet
    Dim lastR As Long, r As Long
    Dim personKey As String, relationshipKey As String, relationshipText As String
    Dim relationships As Object
    personKey = NormalizePersonNameKey(personName)
    If Len(personKey) = 0 Then Exit Function
    Set relationships = CreateObject("Scripting.Dictionary")
    relationships.CompareMode = vbTextCompare
    If SheetExists(SH_PERSON_CAND) Then
        Set ws = GetSheet(SH_PERSON_CAND)
        lastR = LastUsedRowInSheet(ws)
        For r = 2 To lastR
            If NormalizePersonNameKey(CellText(ws.Cells(r, 1).Value)) = personKey Then
                relationshipText = CellText(ws.Cells(r, 3).Value)
                relationshipKey = NormalizeRelationshipKey(relationshipText)
                If Len(relationshipKey) > 0 Then relationships(relationshipKey) = relationshipText
            End If
        Next r
    End If
    If SheetExists(SH_WORK_ACCOUNT) Then
        Set ws = GetSheet(SH_WORK_ACCOUNT)
        lastR = LastUsedRowInSheet(ws)
        For r = 2 To lastR
            If NormalizePersonNameKey(CellText(ws.Cells(r, ACC_COL_PERSON).Value)) = personKey Then
                relationshipText = CellText(ws.Cells(r, ACC_COL_RELATIONSHIP).Value)
                relationshipKey = NormalizeRelationshipKey(relationshipText)
                If Len(relationshipKey) > 0 Then relationships(relationshipKey) = relationshipText
            End If
        Next r
    End If
    '���������ő�������������Ƃ��́A������l���������I���������p�҂̓��͂�҂B
    If relationships.Count = 1 Then RelationshipForName = OnlyDictionaryValue(relationships)
End Function

Private Function OnlyDictionaryValue(ByVal dict As Object) As String
    Dim values As Variant
    If dict Is Nothing Then Exit Function
    If dict.Count <> 1 Then Exit Function
    values = dict.Items
    OnlyDictionaryValue = CStr(values(0))
End Function

Public Function NormalizePersonNameKey(ByVal personName As String) As String
    Dim s As String
    s = Trim$(CellText(personName))
    s = Replace(s, " ", "")
    s = Replace(s, "�@", "")
    NormalizePersonNameKey = UCase$(s)
End Function

Public Function VerifyCaseDataCleared(ByRef detailText As String, _
                                      Optional ByVal allowInitializingState As Boolean = False) As Boolean
    Dim problems As String
    Dim dataHealth As String
    Dim ws As Worksheet, memoCol As Long, c As Long
    If LastUsedRowInSheet(GetSheet(SH_WORK_ACCOUNT)) > 1 Then problems = problems & "���� "
    If LastUsedRowInSheet(GetSheet(SH_WORK_TX)) > 1 Then problems = problems & "��� "
    If LastUsedRowInSheet(GetSheet(SH_WORK_BAL)) > 1 Then problems = problems & "�c�� "
    If LastUsedRowInSheet(GetSheet(SH_CHECK)) > 1 Then problems = problems & "�m�F���� "
    If LastUsedRowInSheet(GetSheet(SH_WORK_CASH)) > 1 Then problems = problems & "��������\ "
    If LastUsedRowInSheet(GetSheet(SH_OUTPUT_TX_CONVERTED)) > 1 Then problems = problems & "�ϊ��ϕ\ "
    If LastUsedRowInSheet(GetSheet(SH_OUTPUT_BAL)) > 1 Then problems = problems & "�c�����ڕ\ "
    If LastUsedRowInSheet(GetSheet(SH_ANALYSIS_SHIFT)) > 1 Then problems = problems & "�����V�t�g��� "
    If LastUsedRowInSheet(GetSheet(SH_ANALYSIS_FLOW)) > 1 Then problems = problems & "�����t���[�ǐ� "
    If LastUsedRowInSheet(GetSheet(SH_ANALYSIS_UNKNOWN)) > 1 Then problems = problems & "�s�����o�� "
    If LastUsedRowInSheet(GetSheet(SH_ANALYSIS_RESULT)) > 1 Then problems = problems & "���͌��� "
    If LastUsedRowInSheet(GetSheet(SH_WORK_ANALYSIS_GROUP)) > 1 Then problems = problems & "���̓O���[�v "
    If LastUsedRowInSheet(GetSheet(SH_WORK_ANALYSIS_REVIEW)) > 1 Then problems = problems & "���͔��f�䒠 "
    If LastUsedRowInSheet(GetSheet(SH_WORK_ANALYSIS_HISTORY)) > 1 Then problems = problems & "���͔��f���� "
    If LastUsedRowInSheet(GetSheet(SH_WORK_MANUAL_FLOW)) > 1 Then problems = problems & "�蓮������� "
    If LastUsedRowInSheet(GetSheet(SH_BALANCE_RECONCILIATION)) > 1 Then problems = problems & "�c�����Z "
    '��ꗗ�̈ē�����A4�ɂ��邽�߁A���f�[�^���ʎq��M��Ŕ��肷��B
    If LastRow(GetSheet(SH_REGISTERED_ACCOUNTS), 13) > 3 Then problems = problems & "�o�^�ς݈ꗗ "
    If LastRow(GetSheet(SH_SHOP_TARGET), SHOP_TGT_COL_CODE) > 1 Then problems = problems & "�戵�X�ϊ��ꗗ "
    If CandidateHasCaseValues(SH_BANK_CAND) Then problems = problems & "��s��� "
    If CandidateHasCaseValues(SH_BRANCH_CAND) Then problems = problems & "�x�X��� "
    If CandidateHasCaseValues(SH_PERSON_CAND) Then problems = problems & "�l����� "
    If Len(CurrentEditAccountID()) > 0 Then problems = problems & "������� "
    If Not TryGetExactStateValue(STATE_DATA_HEALTH, dataHealth) Then
        problems = problems & "�Č��f�[�^��� "
    ElseIf dataHealth <> DATA_HEALTH_NORMAL Then
        If Not (allowInitializingState And dataHealth = DATA_HEALTH_INITIALIZING) Then _
            problems = problems & "�Č��f�[�^��� "
    End If
    If GetStateValue(STATE_NEXT_ACCOUNT, "") <> "1" Or GetStateValue(STATE_NEXT_TRANSFER, "") <> "1" Or _
       GetStateValue(STATE_NEXT_TRANSACTION, "") <> "1" Or GetStateValue(STATE_NEXT_BALANCE, "") <> "1" Then
        problems = problems & "ID�̔ԏ�� "
    End If
    If Not IsNumeric(GetStateValue(STATE_NEXT_PERSON, "")) Or Val(GetStateValue(STATE_NEXT_PERSON, "")) < 1 Then problems = problems & "�l��ID�̔ԏ�� "
    If GetStateValue(STATE_OUTPUT_DIRTY, "") <> STATE_TRUE Or _
       GetStateValue(STATE_ANALYSIS_REVIEW_DIRTY, "") <> STATE_FALSE Or _
       Len(GetStateValue(STATE_LAST_BUILD, "")) > 0 Then problems = problems & "���[�X�V��� "
    If HasText(GetSheet(SH_CONFIG).Cells(ROW_CFG_INHERITANCE_DATE, COL_CFG_VALUE).Value) Then problems = problems & "�����J�n���ݒ� "
    If Not IsNumeric(GetSheet(SH_CONFIG).Cells(ROW_CFG_BAL_START_YEAR, COL_CFG_VALUE).Value) Or _
       Not IsNumeric(GetSheet(SH_CONFIG).Cells(ROW_CFG_BAL_END_YEAR, COL_CFG_VALUE).Value) Then
        problems = problems & "�c���\���N�ݒ� "
    ElseIf CLng(GetSheet(SH_CONFIG).Cells(ROW_CFG_BAL_START_YEAR, COL_CFG_VALUE).Value) <> Year(Date) - 4 Or _
           CLng(GetSheet(SH_CONFIG).Cells(ROW_CFG_BAL_END_YEAR, COL_CFG_VALUE).Value) <> Year(Date) Then
        problems = problems & "�c���\���N�ݒ� "
    End If

    Set ws = GetSheet(SH_INPUT)
    If HasText(ws.Range(CELL_BANK).Value) Or HasText(ws.Range(CELL_BRANCH).Value) Or _
       HasText(ws.Range(CELL_PERSON).Value) Or HasText(ws.Range(CELL_RELATIONSHIP).Value) Or _
       HasText(ws.Range(CELL_ACCOUNT_TYPE).Value) Or _
       HasText(ws.Range(CELL_ACCOUNT_NO).Value) Or HasText(ws.Range(CELL_OPEN_DATE).Value) Or _
       HasText(ws.Range(CELL_CLOSE_DATE).Value) Then problems = problems & "�������͗� "
    If Application.WorksheetFunction.CountA(ws.Range(ws.Cells(TX_FIRST_ROW, COL_TX_YEAR), ws.Cells(TX_LAST_ROW, COL_TX_BALANCE))) > 0 Then problems = problems & "������͗� "
    memoCol = BalanceMemoCol(ws)
    For c = BAL_FIRST_COL To memoCol
        If HasText(ws.Cells(BAL_VALUE_ROW, c).Value) And Not IsBalancePlaceholder(ws.Cells(BAL_VALUE_ROW, c).Value) Then problems = problems & "�c�����͗� ": Exit For
    Next c
    detailText = Trim$(problems)
    VerifyCaseDataCleared = (Len(detailText) = 0)
End Function

Private Function CandidateHasCaseValues(ByVal sheetName As String) As Boolean
    Dim ws As Worksheet, lastR As Long, r As Long
    Set ws = GetSheet(sheetName)
    lastR = LastUsedRowInSheet(ws)
    For r = 2 To lastR
        If HasText(ws.Cells(r, 1).Value) And CellText(ws.Cells(r, 4).Value) <> CAND_SOURCE_COMMON Then CandidateHasCaseValues = True: Exit Function
    Next r
End Function

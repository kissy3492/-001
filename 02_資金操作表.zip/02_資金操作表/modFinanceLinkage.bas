Attribute VB_Name = "modFinanceLinkage"
Option Explicit

Public Function CommonDataPath() As String
    Dim folderPath As String, fileName As String
    On Error Resume Next
    fileName = CellText(GetCfgCell(ROW_CFG_COMMON_DATA).Value)
    On Error GoTo 0
    If Len(fileName) = 0 Then fileName = COMMON_DATA_FILE
    folderPath = ThisWorkbook.Path
    If Len(folderPath) = 0 Then folderPath = CurDir$
    CommonDataPath = LinkCombinePath(folderPath, fileName)
End Function

Private Function LinkCombinePath(ByVal folderPath As String, ByVal fileName As String) As String
    If Right$(folderPath, 1) = "\" Or Right$(folderPath, 1) = "/" Then
        LinkCombinePath = folderPath & fileName
    Else
        LinkCombinePath = folderPath & Application.PathSeparator & fileName
    End If
End Function

Public Function IsCommonLinkEnabled() As Boolean
    On Error Resume Next
    IsCommonLinkEnabled = (CellText(GetCfgCell(ROW_CFG_LINK_MODE).Value) <> DISPLAY_OFF)
    On Error GoTo 0
End Function

Public Sub LoadPersonMasterFromCommonData(Optional ByVal showMessage As Boolean = True)
    Dim p As String, wb As Workbook, wsSrc As Worksheet, wsRef As Worksheet, wsCand As Worksheet
    Dim lastR As Long, r As Long, outR As Long, candR As Long
    Dim colId As Long, colName As Long, colSurname As Long, colGiven As Long, colRel As Long, colDispRel As Long
    Dim colType As Long, colBirth As Long, colDeath As Long, colOld As Long
    Dim personId As String, personName As String, relText As String, typeText As String, oldSurname As String
    Dim rawName As String, currentSurname As String, givenName As String, currentFullName As String, oldFullName As String
    Dim inhDate As Variant, aliasSet As Object

    If Not IsCommonLinkEnabled() Then Exit Sub
    If Len(ThisWorkbook.Path) = 0 Then
        AppendLinkLog "�l�����Ǎ�", "���~", "���̃c�[�����Č��t�H���_�֕ۑ�����Ă��܂���B"
        If showMessage Then QuietWarn "��ɂ��̃c�[�����Č��t�H���_�֕ۑ����Ă��������B�����t�H���_���� 00_���ʃf�[�^.xlsx ��ǂ݂ɍs���܂��B", True, "�l�����Ǎ�"
        Exit Sub
    End If
    AppBegin "�l������ǂݍ��ݒ�..."
    EnsureFinanceLinkSheets
    p = CommonDataPath()
    If Dir$(p) = "" Then
        AppendLinkLog "�l�����Ǎ�", "�����s", "���ʃf�[�^��������܂���: " & p
        AppEnd
        If showMessage Then MsgBox "00_���ʃf�[�^.xlsx ��������܂���B" & vbCrLf & p, vbExclamation
        Exit Sub
    End If

    On Error GoTo EH
    Set wb = Workbooks.Open(Filename:=p, ReadOnly:=True, UpdateLinks:=False, IgnoreReadOnlyRecommended:=True, Notify:=False, AddToMru:=False)
    Set wsSrc = LinkWorksheet(wb, "T_�l��")
    If wsSrc Is Nothing Then Err.Raise vbObjectError + 8301, "LoadPersonMasterFromCommonData", "T_�l�� �V�[�g������܂���B"

    colId = HeaderColumn(wsSrc, "�l��ID", 1)
    colName = FirstHeaderColumn(wsSrc, Array("�����\��", "����", "�\����"), 0)
    colSurname = FirstHeaderColumn(wsSrc, Array("���ݐ�", "��"), 0)
    colGiven = FirstHeaderColumn(wsSrc, Array("��", "���O"), 0)
    colRel = FirstHeaderColumn(wsSrc, Array("�푊���l���猩������", "����"), 0)
    colDispRel = FirstHeaderColumn(wsSrc, Array("�\���p����"), 0)
    colType = FirstHeaderColumn(wsSrc, Array("�l���敪", "�敪"), 0)
    colBirth = FirstHeaderColumn(wsSrc, Array("���N����"), 0)
    colDeath = FirstHeaderColumn(wsSrc, Array("���S��"), 0)
    colOld = FirstHeaderColumn(wsSrc, Array("����"), 0)

    Set wsRef = GetSheet(SH_WORK_PERSON_REF)
    wsRef.Cells.Clear
    SetRowValues wsRef.Range("A1"), Array("�l��ID", "�����\��", "����", "�l���敪", "���N����", "���S��", "����", "���ݐ�", "��", "���ݎ���", "������", "�����L�[", "���f�[�^�s")
    FormatOutputHeader wsRef.Range("A1:M1")
    Set wsCand = GetOrCreateSheet(SH_PERSON_CAND, False)
    wsCand.Cells.Clear
    SetRowValues wsCand.Range("A1"), Array("�l�����", "�l��ID", "����", "�l���敪")
    FormatOutputHeader wsCand.Range("A1:D1")
    Set aliasSet = CreateObject("Scripting.Dictionary")

    lastR = LastRow(wsSrc, colId)
    outR = 2
    candR = 2
    For r = 2 To lastR
        personId = CellText(wsSrc.Cells(r, colId).Value)
        If Len(personId) > 0 Then
            rawName = ""
            currentSurname = ""
            givenName = ""
            oldSurname = ""
            If colName > 0 Then rawName = CellText(wsSrc.Cells(r, colName).Value)
            If colSurname > 0 Then currentSurname = CellText(wsSrc.Cells(r, colSurname).Value)
            If colGiven > 0 Then givenName = CellText(wsSrc.Cells(r, colGiven).Value)
            If colOld > 0 Then oldSurname = CellText(wsSrc.Cells(r, colOld).Value)

            currentFullName = Trim$(currentSurname & givenName)
            If Len(rawName) = 0 Then rawName = currentFullName
            oldFullName = ""
            If Len(oldSurname) > 0 And Len(givenName) > 0 Then oldFullName = oldSurname & givenName
            personName = FinancePersonDisplayName(rawName, currentFullName, oldSurname)

            relText = ""
            If colDispRel > 0 Then relText = CellText(wsSrc.Cells(r, colDispRel).Value)
            If Len(relText) = 0 And colRel > 0 Then relText = CellText(wsSrc.Cells(r, colRel).Value)
            typeText = ""
            If colType > 0 Then typeText = CellText(wsSrc.Cells(r, colType).Value)

            wsRef.Cells(outR, 1).Value = personId
            wsRef.Cells(outR, 2).Value = personName
            wsRef.Cells(outR, 3).Value = relText
            wsRef.Cells(outR, 4).Value = typeText
            If colBirth > 0 Then wsRef.Cells(outR, 5).Value = wsSrc.Cells(r, colBirth).Value
            If colDeath > 0 Then wsRef.Cells(outR, 6).Value = wsSrc.Cells(r, colDeath).Value
            wsRef.Cells(outR, 7).Value = oldSurname
            wsRef.Cells(outR, 8).Value = currentSurname
            wsRef.Cells(outR, 9).Value = givenName
            wsRef.Cells(outR, 10).Value = currentFullName
            wsRef.Cells(outR, 11).Value = oldFullName
            wsRef.Cells(outR, 12).Value = JoinPersonAliasKeys(personName, rawName, currentFullName, oldFullName)
            wsRef.Cells(outR, 13).Value = r

            '���͌��E�O���捞���ɓ���l���𕡐��\�����Ȃ��B
            '�����L�[�� W_�l���Q�� �̌����L�[��ɕێ����A���\���͐l��ID���Ƃ�1���֏W�񂷂�B
            AddPersonCandidateAlias wsCand, candR, aliasSet, personName, personId, relText, typeText
            outR = outR + 1
        End If
    Next r

    inhDate = ReadInheritanceDateFromCommon(wb)
    If IsDate(inhDate) Then GetCfgCell(ROW_CFG_INHERITANCE_DATE).Value = CDate(inhDate)
    wb.Close SaveChanges:=False
    AutoFitSheetSmart wsRef, "A:M", 6, 34
    AutoFitSheetSmart wsCand, "A:D", 6, 34
    RefreshLinkedPersonCandidates
    ApplyInputSettings False
    SyncSelectedPersonFromInput GetSheet(SH_INPUT)
    AppendLinkLog "�l�����Ǎ�", "����", CStr(outR - 2) & "�� / ���" & CStr(candR - 2) & "����ǂݍ��݂܂����B"
    AppEnd
    If showMessage Then NotifyInfo "�l������ǂݍ��݂܂����B" & vbCrLf & _
                           "�l��: " & CStr(outR - 2) & "��" & vbCrLf & _
                           "�������: " & CStr(candR - 2) & "���i���ݎ����E�����������R�t�����Ɋ܂ށj"
    Exit Sub
EH:
    On Error Resume Next
    If Not wb Is Nothing Then wb.Close SaveChanges:=False
    AppendLinkLog "�l�����Ǎ�", "�G���[", Err.Description
    AppEnd
    If showMessage Then RuntimeShowError "LoadPersonCommonData", "�l�����Ǎ�", "00_���ʃf�[�^.xlsx �����Ă��邩�AT_�l���ET_�֌W�ET_�Z�����������݂��邩�m�F���Ă��������B"
End Sub


Private Sub AddPersonCandidateAlias(ByVal ws As Worksheet, ByRef outR As Long, ByVal aliasSet As Object, _
                                    ByVal aliasText As String, ByVal personId As String, ByVal relText As String, ByVal typeText As String)
    Dim s As String, k As String
    s = CellText(aliasText)
    If Len(s) = 0 Or Len(personId) = 0 Then Exit Sub
    k = personId
    If aliasSet.Exists(k) Then Exit Sub
    aliasSet.Add k, True
    ws.Cells(outR, 1).Value = s
    ws.Cells(outR, 2).Value = personId
    ws.Cells(outR, 3).Value = relText
    ws.Cells(outR, 4).Value = typeText
    outR = outR + 1
End Sub

Public Function FinancePersonDisplayName(ByVal rawName As String, ByVal currentFullName As String, ByVal oldSurname As String) As String
    Dim baseName As String, oldText As String
    baseName = CellText(rawName)
    If Len(baseName) = 0 Then baseName = CellText(currentFullName)
    oldText = CellText(oldSurname)
    If Len(baseName) > 0 And Len(oldText) > 0 Then
        If InStr(1, baseName, "����", vbTextCompare) = 0 Then
            FinancePersonDisplayName = baseName & "�i����:" & oldText & "�j"
        Else
            FinancePersonDisplayName = baseName
        End If
    Else
        FinancePersonDisplayName = baseName
    End If
End Function

Public Function PersonDisplayNameById(ByVal personId As String) As String
    Dim ws As Worksheet, lastR As Long, r As Long
    If Len(CellText(personId)) = 0 Then Exit Function
    If Not SheetExists(SH_WORK_PERSON_REF) Then Exit Function
    Set ws = GetSheet(SH_WORK_PERSON_REF)
    lastR = LastRow(ws, 1)
    For r = 2 To lastR
        If CellText(ws.Cells(r, 1).Value) = CellText(personId) Then
            PersonDisplayNameById = CellText(ws.Cells(r, 2).Value)
            Exit Function
        End If
    Next r
End Function

Private Function JoinPersonAliasKeys(ByVal displayName As String, ByVal rawName As String, ByVal currentFullName As String, ByVal oldFullName As String) As String
    Dim d As Object
    Set d = CreateObject("Scripting.Dictionary")
    AddPersonAliasKey d, displayName
    AddPersonAliasKey d, rawName
    AddPersonAliasKey d, BasePersonLookupName(displayName)
    AddPersonAliasKey d, currentFullName
    AddPersonAliasKey d, oldFullName
    If d.Count > 0 Then JoinPersonAliasKeys = Join(d.Keys, "|")
End Function

Private Sub AddPersonAliasKey(ByVal d As Object, ByVal v As Variant)
    Dim k As String
    k = NormalizePersonLookupText(BasePersonLookupName(v))
    If Len(k) = 0 Then Exit Sub
    If Not d.Exists(k) Then d.Add k, k
End Sub

Public Sub RefreshLinkedPersonCandidates()
    Dim ws As Worksheet, lastR As Long
    On Error Resume Next
    If SheetExists(SH_PERSON_CAND) Then
        Set ws = GetSheet(SH_PERSON_CAND)
        lastR = LastRow(ws, 1)
        If lastR < 2 Then lastR = 2
        ResetName NM_LST_PERSON_CAND, ws.Range("A2:A" & CStr(lastR))
        ResetName NM_LST_LINKED_PERSON_CAND, ws.Range("A2:A" & CStr(lastR))
    End If
    On Error GoTo 0
End Sub

Public Sub SyncSelectedPersonFromInput(ByVal ws As Worksheet)
    Dim displayName As String, personId As String, relText As String
    If ws Is Nothing Then Exit Sub
    If ws.Name <> SH_INPUT Then Exit Sub
    displayName = CellText(ws.Range(CELL_PERSON).Value)
    personId = PersonIdByDisplayName(displayName)
    relText = PersonRelationById(personId)
    On Error Resume Next
    ws.Unprotect Password:=TOOL_PASSWORD
    ws.Range(CELL_PERSON_ID).Value = personId
    If Len(relText) > 0 And UseRelationshipDisplay() Then ws.Range(CELL_RELATIONSHIP).Value = relText
    If Len(displayName) = 0 Then
        ws.Range(CELL_LINK_STATUS).Value = ""
    ElseIf Len(personId) > 0 Then
        ws.Range(CELL_LINK_STATUS).Value = "�l��ID�A�g��: " & personId
    Else
        ws.Range(CELL_LINK_STATUS).Value = "�l��ID���A�g"
    End If
    ProtectInputSheet
    On Error GoTo 0
End Sub

Public Function ResolveInputPersonId(ByVal ws As Worksheet, ByVal personName As String) As String
    If Not ws Is Nothing Then ResolveInputPersonId = CellText(ws.Range(CELL_PERSON_ID).Value)
    If Len(ResolveInputPersonId) = 0 Then ResolveInputPersonId = PersonIdByDisplayName(personName)
End Function

Public Function PersonIdByDisplayName(ByVal displayName As String) As String
    PersonIdByDisplayName = FindUniqueCandidatePersonId(displayName, False)
    If Len(PersonIdByDisplayName) > 0 Then Exit Function
    PersonIdByDisplayName = FindUniqueCandidatePersonId(displayName, True)
    If Len(PersonIdByDisplayName) > 0 Then Exit Function
    PersonIdByDisplayName = FindUniquePersonRefIdByLookup(displayName)
End Function

Public Function PersonCandidateOptionsText(ByVal displayName As String, Optional ByVal maxCount As Long = 8) As String
    Dim ws As Worksheet, lastR As Long, r As Long, d As Object
    Dim targetNorm As String, idText As String, itemText As String
    Dim relText As String, typeText As String, displayText As String
    Dim k As Variant, outText As String, n As Long

    targetNorm = NormalizePersonLookupText(BasePersonLookupName(displayName))
    If Len(targetNorm) = 0 Then Exit Function
    Set d = CreateObject("Scripting.Dictionary")

    '���\���͐l��ID�P�ʂ�1�������B���ݎ����E�������E�\�����̕����G�C���A�X�͌����ɂ����g���B
    If SheetExists(SH_WORK_PERSON_REF) Then
        Set ws = GetSheet(SH_WORK_PERSON_REF)
        lastR = LastRow(ws, 1)
        For r = 2 To lastR
            If PersonRefRowMatchesLookup(ws, r, targetNorm) Then
                idText = CellText(ws.Cells(r, 1).Value)
                If Len(idText) > 0 Then
                    displayText = CanonicalPersonNameById(idText, CellText(ws.Cells(r, 2).Value))
                    relText = CellText(ws.Cells(r, 3).Value)
                    typeText = CellText(ws.Cells(r, 4).Value)
                    itemText = idText & " / " & displayText
                    If Len(relText) > 0 Then itemText = itemText & " / " & relText
                    If Len(typeText) > 0 Then itemText = itemText & " / " & typeText
                    itemText = itemText & PersonRefSummaryById(idText)
                    If Not d.Exists(idText) Then d.Add idText, itemText
                End If
            End If
        Next r
    End If

    'W_�l���Q�Ƃ����Ǎ��̌Â���Ԃł��A�l�����V�[�g����Œ���E���B
    If d.Count = 0 And SheetExists(SH_PERSON_CAND) Then
        Set ws = GetSheet(SH_PERSON_CAND)
        lastR = LastRow(ws, 1)
        For r = 2 To lastR
            If NormalizePersonLookupText(BasePersonLookupName(ws.Cells(r, 1).Value)) = targetNorm Then
                idText = CellText(ws.Cells(r, 2).Value)
                If Len(idText) > 0 And Not d.Exists(idText) Then
                    itemText = idText & " / " & CanonicalPersonNameById(idText, CellText(ws.Cells(r, 1).Value))
                    If Len(CellText(ws.Cells(r, 3).Value)) > 0 Then itemText = itemText & " / " & CellText(ws.Cells(r, 3).Value)
                    If Len(CellText(ws.Cells(r, 4).Value)) > 0 Then itemText = itemText & " / " & CellText(ws.Cells(r, 4).Value)
                    d.Add idText, itemText
                End If
            End If
        Next r
    End If

    For Each k In d.Keys
        n = n + 1
        If n > maxCount Then Exit For
        If Len(outText) > 0 Then outText = outText & vbCrLf
        outText = outText & "�E" & CStr(d(k))
    Next k
    If d.Count > maxCount Then outText = outText & vbCrLf & "�E�ق� " & CStr(d.Count - maxCount) & " ��"
    PersonCandidateOptionsText = outText
End Function

Private Function FindUniqueCandidatePersonId(ByVal displayName As String, ByVal normalizedBaseMatch As Boolean) As String
    Dim ws As Worksheet, lastR As Long, r As Long
    Dim target As String, cand As String, hit As String, idText As String
    If Len(CellText(displayName)) = 0 Then Exit Function
    If Not SheetExists(SH_PERSON_CAND) Then Exit Function
    Set ws = GetSheet(SH_PERSON_CAND)
    lastR = LastRow(ws, 1)
    If normalizedBaseMatch Then
        target = NormalizePersonLookupText(BasePersonLookupName(displayName))
    Else
        target = CellText(displayName)
    End If
    If Len(target) = 0 Then Exit Function
    For r = 2 To lastR
        If normalizedBaseMatch Then
            cand = NormalizePersonLookupText(BasePersonLookupName(ws.Cells(r, 1).Value))
        Else
            cand = CellText(ws.Cells(r, 1).Value)
        End If
        If cand = target Then
            idText = CellText(ws.Cells(r, 2).Value)
            If Len(idText) > 0 Then
                If Len(hit) > 0 And hit <> idText Then
                    FindUniqueCandidatePersonId = ""
                    Exit Function
                End If
                hit = idText
            End If
        End If
    Next r
    FindUniqueCandidatePersonId = hit
End Function

Private Function FindUniquePersonRefIdByLookup(ByVal displayName As String) As String
    Dim ws As Worksheet, lastR As Long, r As Long
    Dim target As String, keys As String, idText As String, hit As String
    target = NormalizePersonLookupText(BasePersonLookupName(displayName))
    If Len(target) = 0 Then Exit Function
    If Not SheetExists(SH_WORK_PERSON_REF) Then Exit Function
    Set ws = GetSheet(SH_WORK_PERSON_REF)
    lastR = LastRow(ws, 1)
    For r = 2 To lastR
        keys = "|" & CellText(ws.Cells(r, 12).Value) & "|"
        If InStr(1, keys, "|" & target & "|", vbTextCompare) > 0 Then
            idText = CellText(ws.Cells(r, 1).Value)
            If Len(idText) > 0 Then
                If Len(hit) > 0 And hit <> idText Then
                    FindUniquePersonRefIdByLookup = ""
                    Exit Function
                End If
                hit = idText
            End If
        End If
    Next r
    FindUniquePersonRefIdByLookup = hit
End Function

Public Function CanonicalPersonNameById(ByVal personId As String, Optional ByVal fallbackName As String = "") As String
    Dim ws As Worksheet, lastR As Long, r As Long
    If Len(CellText(personId)) = 0 Then CanonicalPersonNameById = CellText(fallbackName): Exit Function
    If SheetExists(SH_WORK_PERSON_REF) Then
        Set ws = GetSheet(SH_WORK_PERSON_REF)
        lastR = LastRow(ws, 1)
        For r = 2 To lastR
            If CellText(ws.Cells(r, 1).Value) = CellText(personId) Then
                CanonicalPersonNameById = CellText(ws.Cells(r, 2).Value)
                If Len(CanonicalPersonNameById) = 0 Then CanonicalPersonNameById = CellText(fallbackName)
                Exit Function
            End If
        Next r
    End If
    CanonicalPersonNameById = CellText(fallbackName)
End Function

Private Function PersonRefRowMatchesLookup(ByVal ws As Worksheet, ByVal rowNo As Long, ByVal targetNorm As String) As Boolean
    Dim keys As Variant, i As Long, keyText As String
    If ws Is Nothing Or rowNo <= 0 Or Len(targetNorm) = 0 Then Exit Function
    If NormalizePersonLookupText(BasePersonLookupName(ws.Cells(rowNo, 2).Value)) = targetNorm Then PersonRefRowMatchesLookup = True: Exit Function
    If NormalizePersonLookupText(BasePersonLookupName(ws.Cells(rowNo, 10).Value)) = targetNorm Then PersonRefRowMatchesLookup = True: Exit Function
    If NormalizePersonLookupText(BasePersonLookupName(ws.Cells(rowNo, 11).Value)) = targetNorm Then PersonRefRowMatchesLookup = True: Exit Function
    keys = Split(CellText(ws.Cells(rowNo, 12).Value), "|")
    For i = LBound(keys) To UBound(keys)
        keyText = NormalizePersonLookupText(BasePersonLookupName(CStr(keys(i))))
        If Len(keyText) > 0 And keyText = targetNorm Then PersonRefRowMatchesLookup = True: Exit Function
    Next i
End Function

Private Function PersonRefSummaryById(ByVal personId As String) As String
    Dim ws As Worksheet, lastR As Long, r As Long, s As String
    If Len(personId) = 0 Then Exit Function
    If Not SheetExists(SH_WORK_PERSON_REF) Then Exit Function
    Set ws = GetSheet(SH_WORK_PERSON_REF)
    lastR = LastRow(ws, 1)
    For r = 2 To lastR
        If CellText(ws.Cells(r, 1).Value) = personId Then
            If IsDate(ws.Cells(r, 5).Value) Then s = s & " / ��" & Format$(CDate(ws.Cells(r, 5).Value), "yyyy/m/d")
            If IsDate(ws.Cells(r, 6).Value) Then s = s & " / �v" & Format$(CDate(ws.Cells(r, 6).Value), "yyyy/m/d")
            PersonRefSummaryById = s
            Exit Function
        End If
    Next r
End Function

Private Function BasePersonLookupName(ByVal v As Variant) As String
    Dim s As String, p As Long
    s = CellText(v)
    p = InStr(1, s, "�i", vbTextCompare)
    If p = 0 Then p = InStr(1, s, "(", vbTextCompare)
    If p > 1 Then s = Left$(s, p - 1)
    BasePersonLookupName = s
End Function

Private Function NormalizePersonLookupText(ByVal v As Variant) As String
    Dim s As String
    s = CellText(v)
    On Error Resume Next
    s = StrConv(s, vbNarrow)
    On Error GoTo 0
    s = Replace$(s, vbCr, "")
    s = Replace$(s, vbLf, "")
    s = Replace$(s, vbTab, "")
    s = Replace$(s, " ", "")
    s = Replace$(s, "�@", "")
    s = Replace$(s, "�E", "")
    s = Replace$(s, "�", "")
    s = Replace$(s, "��", "��")
    s = Replace$(s, "�", "��")
    s = Replace$(s, "�", "��")
    If Right$(s, 1) = "�l" Then s = Left$(s, Len(s) - 1)
    If Right$(s, 1) = "�a" Then s = Left$(s, Len(s) - 1)
    If Right$(s, 1) = "��" Then s = Left$(s, Len(s) - 1)
    If Right$(s, 2) = "����" Then s = Left$(s, Len(s) - 2)
    NormalizePersonLookupText = s
End Function

Public Function PersonRelationById(ByVal personId As String) As String
    Dim ws As Worksheet, lastR As Long, r As Long
    If Len(personId) = 0 Then Exit Function
    If Not SheetExists(SH_WORK_PERSON_REF) Then Exit Function
    Set ws = GetSheet(SH_WORK_PERSON_REF)
    lastR = LastRow(ws, 1)
    For r = 2 To lastR
        If CellText(ws.Cells(r, 1).Value) = personId Then
            PersonRelationById = CellText(ws.Cells(r, 3).Value)
            Exit Function
        End If
    Next r
End Function

Public Sub ValidateFinanceLinkage()
    Dim wsCheck As Worksheet, wsTx As Worksheet, lastR As Long, r As Long
    Dim errCount As Long, warnCount As Long
    If Not RequireToolReady() Then Exit Sub
    On Error GoTo EH
    AppBegin "�A�g�`�F�b�N��..."
    Set wsCheck = GetSheet(SH_CHECK)
    wsCheck.Visible = xlSheetVisible
    wsCheck.Cells.Clear
    SetRowValues wsCheck.Range("A1"), Array("�敪", "�ꏊ", "���e")
    FormatOutputHeader wsCheck.Range("A1:C1")

    If Dir$(CommonDataPath()) = "" Then
        AddCheck "�x��", "00_���ʃf�[�^", "���ʃf�[�^������܂���B�l�����n�c�[���ō쐬��A�l������Ǎ���ł��������B"
        warnCount = warnCount + 1
    End If
    If SheetExists(SH_WORK_PERSON_REF) Then
        If LastRow(GetSheet(SH_WORK_PERSON_REF), 1) < 2 Then
            AddCheck "�x��", SH_WORK_PERSON_REF, "�l����񂪓ǂݍ��܂�Ă��܂���B"
            warnCount = warnCount + 1
        End If
    End If
    Set wsTx = GetSheet(SH_WORK_TX)
    lastR = LastRow(wsTx, 1)
    For r = 2 To lastR
        If CellText(wsTx.Cells(r, WORK_TX_COL_ROW_KIND).Value) = ROW_KIND_TRANSACTION Then
            If Len(CellText(wsTx.Cells(r, WORK_TX_COL_PERSON_ID).Value)) = 0 Then AddCheck "�x��", SH_WORK_TX & "!" & r & "�s", "�l��ID������܂���B": warnCount = warnCount + 1
            If Len(CellText(wsTx.Cells(r, WORK_TX_COL_ACCOUNT_ID).Value)) = 0 Then AddCheck "�G���[", SH_WORK_TX & "!" & r & "�s", "����ID������܂���B": errCount = errCount + 1
            If Len(CellText(wsTx.Cells(r, WORK_TX_COL_TRANSACTION_ID).Value)) = 0 Then AddCheck "�G���[", SH_WORK_TX & "!" & r & "�s", "���ID������܂���B": errCount = errCount + 1
        End If
    Next r
    AutoFitSheetSmart wsCheck, "A:C", 6, 34
    HideDailySheets False
    ShowCheckSheet
    AppEnd
    If errCount > 0 Then
        QuietWarn "�A�g�`�F�b�N�ŃG���[������܂��B�G���[: " & errCount & "�� / �x��: " & warnCount & "���BC_�`�F�b�N���m�F���Ă��������B", False, "�A�g�`�F�b�N"
    Else
        NotifyInfo "�A�g�`�F�b�N���� / �x��: " & warnCount & "���B�K�v�ɉ�����C_�`�F�b�N���m�F���Ă��������B"
    End If
    Exit Sub
EH:
    AppEnd
    RuntimeShowError "RunLinkageCheck", "�A�g�`�F�b�N", "���ʃf�[�^�ƍ�ƃV�[�g�̏�Ԃ��m�F���Ă��������B"
End Sub

Public Sub SaveFinanceCommonData(Optional ByVal showMessage As Boolean = True)
    Dim p As String, wb As Workbook
    If Not IsCommonLinkEnabled() Then Exit Sub
    If Len(ThisWorkbook.Path) = 0 Then
        AppendLinkLog "���ʃf�[�^�ۑ�", "���~", "���̃c�[�����Č��t�H���_�֕ۑ�����Ă��܂���B"
        If showMessage Then QuietWarn "��ɂ��̃c�[�����Č��t�H���_�֕ۑ����Ă��������B���ۑ��̂܂܂ł́A00_���ʃf�[�^.xlsx �̕ۑ��ꏊ���s����ɂȂ�܂��B", True, "���ʃf�[�^�ۑ�"
        If Not showMessage Then Err.Raise vbObjectError + 8401, "SaveFinanceCommonData", "���̃c�[�����Č��t�H���_�֕ۑ�����Ă��܂���B"
        Exit Sub
    End If

    On Error GoTo EH
    AppBegin "���ʃf�[�^�֕ۑ���..."
    EnsureFinanceLinkSheets
    p = CommonDataPath()
    If Dir$(p) = "" Then
        AppendLinkLog "���ʃf�[�^�ۑ�", "���~", "00_���ʃf�[�^.xlsx ��������܂���B�l�����n�c�[���Ő�ɋ��ʃf�[�^���쐬���Ă�������: " & p
        AppEnd
        If showMessage Then
            QuietWarn "00_���ʃf�[�^.xlsx ��������܂���B�A�g�^�p�ł́A�l�����n�c�[���Ő�ɋ��ʃf�[�^���쐬���Ă��玑���f�[�^��ۑ����Ă��������B" & p, True, "���ʃf�[�^�ۑ�"
        Else
            Err.Raise vbObjectError + 8402, "SaveFinanceCommonData", "00_���ʃf�[�^.xlsx ��������܂���B�l�����n�c�[���Ő�ɋ��ʃf�[�^���쐬���Ă��������B"
        End If
        Exit Sub
    Else
        BackupCommonDataBeforeUpdate p, "02�����ۑ�"
        Set wb = Workbooks.Open(Filename:=p, ReadOnly:=False, UpdateLinks:=False, IgnoreReadOnlyRecommended:=True, Notify:=False, AddToMru:=False)
        If wb.ReadOnly Then Err.Raise vbObjectError + 8403, "SaveFinanceCommonData", "00_���ʃf�[�^.xlsx ���ǂݎ���p�ŊJ����Ă��܂��B�ʂ�Excel�ŊJ���Ă���ꍇ�͕��Ă�������: " & p
    End If
    WriteFinanceSettings wb
    WriteAccountsTable wb
    WriteTransactionsTable wb
    WriteBalancesTable wb
    WriteShopConversionTable wb
    wb.Save
    wb.Close SaveChanges:=False
    AppendLinkLog "���ʃf�[�^�ۑ�", "����", p
    AppEnd
    If showMessage Then NotifyInfo "���ʃf�[�^�֕ۑ����܂����B" & vbCrLf & p
    Exit Sub
EH:
    Dim errNum As Long, errDesc As String, errSrc As String
    errNum = Err.Number: errDesc = Err.Description: errSrc = Err.Source
    On Error Resume Next
    If Not wb Is Nothing Then wb.Close SaveChanges:=False
    AppendLinkLog "���ʃf�[�^�ۑ�", "�G���[", errDesc
    AppEnd
    On Error GoTo 0
    If showMessage Then
        RuntimeShowErrorValues "SaveFinanceCommonData", "02���ʃf�[�^�ۑ�", "00_���ʃf�[�^.xlsx���ʃu�b�N�ŊJ����Ă��Ȃ����m�F���Ă��������B", p, errNum, errDesc, errSrc
    Else
        If Len(errDesc) = 0 Then errDesc = "���ʃf�[�^�ۑ��Ɏ��s���܂����B"
        Err.Raise errNum, "SaveFinanceCommonData", errDesc & vbCrLf & "�Ώ�: " & p
    End If
End Sub

Public Sub NormalizeOutputShopFinal(ByVal ws As Worksheet)
    Dim lastR As Long, r As Long, shopText As String
    If ws Is Nothing Then Exit Sub
    lastR = LastRow(ws, OUT_COL_BANK)
    If lastR < 2 Then Exit Sub
    For r = 2 To lastR
        shopText = CellText(ws.Cells(r, OUT_COL_SHOP).Value)
        If Len(shopText) = 0 Then shopText = CellText(ws.Cells(r, OUT_COL_BRANCH).Value)
        ws.Cells(r, OUT_COL_SHOP_FINAL).Value = shopText
        If Len(CellText(ws.Cells(r, OUT_COL_DATA_STATUS).Value)) = 0 Then ws.Cells(r, OUT_COL_DATA_STATUS).Value = DATA_STATUS_ACTIVE
    Next r
End Sub

Private Sub WriteFinanceSettings(ByVal wb As Workbook)
    Dim ws As Worksheet
    Set ws = LinkResetSheet(wb, "T_�����A�g�ݒ�")
    SetRowValues ws.Range("A1"), Array("����", "�l")
    SetRowValues ws.Range("A2"), Array("�X�L�[�}�o�[�W����", COMMON_SCHEMA_VERSION)
    SetRowValues ws.Range("A3"), Array("���ʃX�L�[�}�o�[�W����", "common-data-v1.1")
    SetRowValues ws.Range("A4"), Array("�����J�n��", GetCfgCell(ROW_CFG_INHERITANCE_DATE).Value)
    SetRowValues ws.Range("A5"), Array("�쐬����", Now)
    SetRowValues ws.Range("A6"), Array("�쐬�c�[��", ThisWorkbook.Name)
    AutoFitSheetSmart ws, "A:B", 6, 34

    UpdateCommonLinkControlSheet wb, "�����X�L�[�}�o�[�W����", COMMON_SCHEMA_VERSION, "02���̏o�͎d�l"
    UpdateCommonLinkControlSheet wb, "�ۑ�����", Now, "���ʃf�[�^���Ō�ɍX�V��������"
End Sub

Private Sub UpdateCommonLinkControlSheet(ByVal wb As Workbook, ByVal keyText As String, ByVal valueText As Variant, ByVal descText As String)
    Dim ws As Worksheet, r As Long, lastR As Long
    On Error Resume Next
    Set ws = wb.Worksheets("T_�A�g�ݒ�")
    On Error GoTo 0
    If ws Is Nothing Then
        Set ws = wb.Worksheets.Add(Before:=wb.Worksheets(1))
        ws.Name = "T_�A�g�ݒ�"
        ws.Range("A1:C1").Value = Array("�L�[", "�l", "����")
    End If
    If Len(CellText(ws.Cells(1, 1).Value)) = 0 Then ws.Range("A1:C1").Value = Array("�L�[", "�l", "����")

    lastR = LastRow(ws, 1)
    If lastR < 1 Then lastR = 1
    For r = 2 To lastR
        If CellText(ws.Cells(r, 1).Value) = keyText Then
            ws.Cells(r, 2).Value = valueText
            ws.Cells(r, 3).Value = descText
            ws.Columns("A:C").AutoFit
            Exit Sub
        End If
    Next r

    ws.Cells(lastR + 1, 1).Value = keyText
    ws.Cells(lastR + 1, 2).Value = valueText
    ws.Cells(lastR + 1, 3).Value = descText
    ws.Columns("A:C").AutoFit
End Sub

Private Sub WriteAccountsTable(ByVal wb As Workbook)
    Dim src As Worksheet, dst As Worksheet, lastR As Long
    Set dst = LinkResetSheet(wb, "T_����")
    SetRowValues dst.Range("A1"), Array("����ID", "�l��ID", "����", "����", "��s��", "�x�X��", "�Ȗ�", "�����ԍ�", "�����ԍ����K��", "�����J�ݓ�", "��������", "�f�[�^���", "�쐬����", "�X�V����")
    Set src = GetSheet(SH_WORK_ACCOUNT)
    lastR = LastRow(src, 1)
    If lastR >= 2 Then dst.Range("A2").Resize(lastR - 1, 14).Value = src.Range("A2:N" & CStr(lastR)).Value
    AutoFitSheetSmart dst, "A:N", 6, 34
End Sub

Private Sub WriteTransactionsTable(ByVal wb As Workbook)
    Dim src As Worksheet, dst As Worksheet, lastR As Long, r As Long, outR As Long
    Dim converted As Object, txId As String
    Dim shopRaw As String, shopFilled As String, shopConverted As String, shopFinal As String, convertedValue As String
    Dim otherValue As Variant, otherAmount As Variant, afterAmount As Variant
    Set dst = LinkResetSheet(wb, "T_���")
    SetRowValues dst.Range("A1"), Array("���ID", "����ID", "�l��ID", "����", "����", "��s��", "�x�X��", "�Ȗ�", "�����ԍ�", "���t", "����", "�o��", "����", "�戵�X����", "�戵�X�⊮�l", "�戵�X�ϊ���", "�戵�X�m��l", "�@��", "�E�v", "���̑�", "�����c��", "�����c������", "�c�����", "���s���", "�f�[�^���")
    Set converted = BuildConvertedShopDictionary()
    Set src = GetSheet(SH_WORK_TX)
    lastR = LastRow(src, 1)
    outR = 2
    For r = 2 To lastR
        If CellText(src.Cells(r, WORK_TX_COL_ROW_KIND).Value) = ROW_KIND_TRANSACTION And _
           CellText(src.Cells(r, WORK_TX_COL_DATA_STATUS).Value) <> DATA_STATUS_CANCELLED Then
            txId = CellText(src.Cells(r, WORK_TX_COL_TRANSACTION_ID).Value)
            shopRaw = CellText(src.Cells(r, OUT_COL_SHOP).Value)
            shopFilled = ""
            If Len(shopRaw) = 0 Then shopFilled = CellText(src.Cells(r, OUT_COL_BRANCH).Value)
            convertedValue = ""
            If converted.Exists(txId) Then convertedValue = CellText(converted(txId))
            shopConverted = ""
            If Len(convertedValue) > 0 Then shopConverted = convertedValue

            shopFinal = shopConverted
            If Len(shopFinal) = 0 Then shopFinal = CellText(src.Cells(r, WORK_TX_COL_SHOP_FINAL).Value)
            If Len(shopFinal) = 0 Then shopFinal = shopFilled
            If Len(shopFinal) = 0 Then shopFinal = shopRaw
            If Len(shopFinal) = 0 Then shopFinal = CellText(src.Cells(r, OUT_COL_BRANCH).Value)
            dst.Cells(outR, 1).Value = txId
            dst.Cells(outR, 2).Value = src.Cells(r, WORK_TX_COL_ACCOUNT_ID).Value
            dst.Cells(outR, 3).Value = src.Cells(r, WORK_TX_COL_PERSON_ID).Value
            dst.Cells(outR, 4).Value = src.Cells(r, OUT_COL_PERSON).Value
            dst.Cells(outR, 5).Value = src.Cells(r, WORK_TX_COL_RELATIONSHIP).Value
            dst.Cells(outR, 6).Value = src.Cells(r, OUT_COL_BANK).Value
            dst.Cells(outR, 7).Value = src.Cells(r, OUT_COL_BRANCH).Value
            dst.Cells(outR, 8).Value = src.Cells(r, OUT_COL_ACCOUNT_TYPE).Value
            dst.Cells(outR, 9).Value = src.Cells(r, OUT_COL_ACCOUNT_NO).Value
            dst.Cells(outR, 10).Value = src.Cells(r, OUT_COL_DATE).Value
            dst.Cells(outR, 11).Value = src.Cells(r, OUT_COL_TIME).Value
            dst.Cells(outR, 12).Value = src.Cells(r, OUT_COL_WITHDRAW).Value
            dst.Cells(outR, 13).Value = src.Cells(r, OUT_COL_DEPOSIT).Value
            dst.Cells(outR, 14).Value = shopRaw
            dst.Cells(outR, 15).Value = shopFilled
            dst.Cells(outR, 16).Value = shopConverted
            dst.Cells(outR, 17).Value = shopFinal
            dst.Cells(outR, 18).Value = src.Cells(r, OUT_COL_MACHINE).Value
            dst.Cells(outR, 19).Value = src.Cells(r, OUT_COL_TEKIYO).Value
            otherValue = src.Cells(r, OUT_COL_OTHER).Value
            If Len(CellText(src.Cells(r, WORK_TX_COL_BALANCE_SOURCE).Value)) > 0 Then
                otherAmount = ToAmountOrBlank(otherValue)
                afterAmount = ToAmountOrBlank(src.Cells(r, WORK_TX_COL_AFTER_BALANCE).Value)
                If IsNumeric(otherAmount) And IsNumeric(afterAmount) Then
                    If CDbl(otherAmount) = CDbl(afterAmount) Then otherValue = ""
                ElseIf CellText(otherValue) = CellText(src.Cells(r, WORK_TX_COL_AFTER_BALANCE_RAW).Value) Then
                    otherValue = ""
                End If
            End If
            dst.Cells(outR, 20).Value = otherValue
            dst.Cells(outR, 21).Value = src.Cells(r, WORK_TX_COL_AFTER_BALANCE).Value
            dst.Cells(outR, 22).Value = src.Cells(r, WORK_TX_COL_AFTER_BALANCE_RAW).Value
            dst.Cells(outR, 23).Value = src.Cells(r, WORK_TX_COL_BALANCE_SOURCE).Value
            dst.Cells(outR, 24).Value = ROW_KIND_TRANSACTION
            dst.Cells(outR, 25).Value = DATA_STATUS_ACTIVE
            outR = outR + 1
        End If
    Next r
    If outR > 2 Then
        dst.Range("J2:J" & CStr(outR - 1)).NumberFormatLocal = "yyyy/m/d"
        dst.Range("L2:M" & CStr(outR - 1)).NumberFormatLocal = "#,##0"
        dst.Range("U2:U" & CStr(outR - 1)).NumberFormatLocal = "#,##0"
    End If
    AutoFitSheetSmart dst, "A:Y", 6, 34
End Sub

Private Sub WriteBalancesTable(ByVal wb As Workbook)
    Dim src As Worksheet, dst As Worksheet, lastR As Long, r As Long, outR As Long
    Set dst = LinkResetSheet(wb, "T_�c��")
    SetRowValues dst.Range("A1"), Array("�c��ID", "����ID", "�l��ID", "����", "����", "��s��", "�x�X��", "�Ȗ�", "�����ԍ�", "�c�����", "�c�����o��", "�c��", "�����J�ݓ�", "��������", "���̑�", "�]�L��ID", "�f�[�^���")
    Set src = GetSheet(SH_WORK_BAL)
    lastR = LastRow(src, 1)
    outR = 2
    For r = 2 To lastR
        If Len(CellText(src.Cells(r, WORK_BAL_COL_BALANCE_ID).Value)) > 0 And _
           CellText(src.Cells(r, WORK_BAL_COL_DATA_STATUS).Value) <> DATA_STATUS_CANCELLED Then
            dst.Cells(outR, 1).Value = src.Cells(r, WORK_BAL_COL_BALANCE_ID).Value
            dst.Cells(outR, 2).Value = src.Cells(r, WORK_BAL_COL_ACCOUNT_ID).Value
            dst.Cells(outR, 3).Value = src.Cells(r, WORK_BAL_COL_PERSON_ID).Value
            dst.Cells(outR, 4).Value = src.Cells(r, OUT_COL_PERSON).Value
            dst.Cells(outR, 5).Value = src.Cells(r, WORK_BAL_COL_RELATIONSHIP).Value
            dst.Cells(outR, 6).Value = src.Cells(r, OUT_COL_BANK).Value
            dst.Cells(outR, 7).Value = src.Cells(r, OUT_COL_BRANCH).Value
            dst.Cells(outR, 8).Value = src.Cells(r, OUT_COL_ACCOUNT_TYPE).Value
            dst.Cells(outR, 9).Value = src.Cells(r, OUT_COL_ACCOUNT_NO).Value
            dst.Cells(outR, 10).Value = src.Cells(r, 8).Value
            dst.Cells(outR, 11).Value = src.Cells(r, 9).Value
            dst.Cells(outR, 12).Value = src.Cells(r, 10).Value
            dst.Cells(outR, 13).Value = src.Cells(r, 6).Value
            dst.Cells(outR, 14).Value = src.Cells(r, 7).Value
            dst.Cells(outR, 15).Value = src.Cells(r, 11).Value
            dst.Cells(outR, 16).Value = src.Cells(r, WORK_BAL_COL_TRANSFER_ID).Value
            dst.Cells(outR, 17).Value = src.Cells(r, WORK_BAL_COL_DATA_STATUS).Value
            If Len(CellText(dst.Cells(outR, 17).Value)) = 0 Then dst.Cells(outR, 17).Value = DATA_STATUS_ACTIVE
            outR = outR + 1
        End If
    Next r
    If outR > 2 Then
        dst.Range("J2:J" & CStr(outR - 1)).NumberFormatLocal = "yyyy/m/d"
        dst.Range("L2:L" & CStr(outR - 1)).NumberFormatLocal = "#,##0"
        dst.Range("M2:N" & CStr(outR - 1)).NumberFormatLocal = "yyyy/m/d"
    End If
    AutoFitSheetSmart dst, "A:Q", 6, 34
End Sub

Private Sub WriteShopConversionTable(ByVal wb As Workbook)
    Dim src As Worksheet, dst As Worksheet, lastR As Long
    Set dst = LinkResetSheet(wb, "T_�戵�X�ϊ�")
    SetRowValues dst.Range("A1"), Array("No", "��s��", "�戵�X�R�[�h", "�Y������", "�Y���s�ԍ�", "�ϊ���戵�X", "�m�F��", "�쐬����")
    If SheetExists(SH_SHOP_TARGET) Then
        Set src = GetSheet(SH_SHOP_TARGET)
        lastR = LastRow(src, SHOP_TGT_COL_NO)
        If lastR >= 2 Then dst.Range("A2").Resize(lastR - 1, 8).Value = src.Range("A2:H" & CStr(lastR)).Value
    End If
    AutoFitSheetSmart dst, "A:H", 6, 34
End Sub

Private Function BuildConvertedShopDictionary() As Object
    Dim d As Object, ws As Worksheet, lastR As Long, r As Long, txId As String, shopText As String
    Set d = CreateObject("Scripting.Dictionary")
    If SheetExists(SH_OUTPUT_TX_CONVERTED) Then
        Set ws = GetSheet(SH_OUTPUT_TX_CONVERTED)
        lastR = LastRow(ws, OUT_COL_BANK)
        For r = 2 To lastR
            txId = CellText(ws.Cells(r, OUT_COL_TRANSACTION_ID).Value)
            If Len(txId) > 0 Then
                shopText = CellText(ws.Cells(r, OUT_COL_SHOP_FINAL).Value)
                If Len(shopText) = 0 Then shopText = CellText(ws.Cells(r, OUT_COL_SHOP).Value)
                If Len(shopText) > 0 Then d(txId) = shopText
            End If
        Next r
    End If
    Set BuildConvertedShopDictionary = d
End Function

Private Function ReadInheritanceDateFromCommon(ByVal wb As Workbook) As Variant
    Dim ws As Worksheet
    For Each ws In wb.Worksheets
        If ws.Name = "T_�A�g�ݒ�" Or ws.Name = "T_�ݒ�" Or ws.Name = "T_�����A�g�ݒ�" Then
            ReadInheritanceDateFromCommon = FindSettingDate(ws, "�����J�n��")
            If IsDate(ReadInheritanceDateFromCommon) Then Exit Function
        End If
    Next ws
End Function

Private Function FindSettingDate(ByVal ws As Worksheet, ByVal keyText As String) As Variant
    Dim lastR As Long, lastC As Long, r As Long, c As Long
    lastR = LastUsedRowInSheet(ws)
    lastC = LastUsedColumnPublic(ws)
    For r = 1 To lastR
        For c = 1 To lastC
            If CellText(ws.Cells(r, c).Value) = keyText Then
                If c < lastC Then FindSettingDate = ws.Cells(r, c + 1).Value
                If IsDate(FindSettingDate) Then Exit Function
            End If
        Next c
    Next r
End Function

Private Function LinkWorksheet(ByVal wb As Workbook, ByVal sheetName As String) As Worksheet
    On Error Resume Next
    Set LinkWorksheet = wb.Worksheets(sheetName)
    On Error GoTo 0
End Function

Private Function LinkResetSheet(ByVal wb As Workbook, ByVal sheetName As String) As Worksheet
    Dim ws As Worksheet
    On Error Resume Next
    Set ws = wb.Worksheets(sheetName)
    On Error GoTo 0
    If ws Is Nothing Then
        Set ws = wb.Worksheets.Add(After:=wb.Worksheets(wb.Worksheets.Count))
        ws.Name = sheetName
    Else
        On Error Resume Next
        ws.Visible = xlSheetVisible
        ws.Unprotect Password:=TOOL_PASSWORD
        If ws.FilterMode Then ws.ShowAllData
        ws.AutoFilterMode = False
        Do While ws.ListObjects.Count > 0
            ws.ListObjects(1).Delete
        Loop
        ws.Cells.Clear
        On Error GoTo 0
    End If
    Set LinkResetSheet = ws
End Function

Private Function HeaderColumn(ByVal ws As Worksheet, ByVal headerText As String, Optional ByVal defaultCol As Long = 0) As Long
    Dim c As Long, lastC As Long
    lastC = LastUsedColumnPublic(ws)
    For c = 1 To lastC
        If CellText(ws.Cells(1, c).Value) = headerText Then HeaderColumn = c: Exit Function
    Next c
    HeaderColumn = defaultCol
End Function

Private Function FirstHeaderColumn(ByVal ws As Worksheet, ByVal names As Variant, Optional ByVal defaultCol As Long = 0) As Long
    Dim i As Long, c As Long
    For i = LBound(names) To UBound(names)
        c = HeaderColumn(ws, CStr(names(i)), 0)
        If c > 0 Then FirstHeaderColumn = c: Exit Function
    Next i
    FirstHeaderColumn = defaultCol
End Function

Private Sub BackupCommonDataBeforeUpdate(ByVal filePath As String, ByVal processName As String)
    Dim backupPath As String
    If Len(filePath) = 0 Then Exit Sub
    If Len(Dir$(filePath)) = 0 Then Exit Sub
    backupPath = RuntimeUniqueBackupPath(filePath)
    FileCopy filePath, backupPath
    AppendLinkLog processName, "�X�V�O�o�b�N�A�b�v", backupPath
End Sub

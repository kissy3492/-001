Attribute VB_Name = "modTransfer"
Option Explicit

Public Sub TransferCurrentAccount()
    TransferCurrentAccountCore ""
End Sub

Public Sub TransferCurrentAccountKeepBankBranch()
    TransferCurrentAccountCore KEEP_BANK_BRANCH
End Sub

Public Sub TransferCurrentAccountNextBranch()
    TransferCurrentAccountCore KEEP_BANK_BRANCH_PERSON_TYPE, True
End Sub

Private Sub TransferCurrentAccountCore(Optional ByVal keepOverride As String = "", Optional ByVal nextBranchAfter As Boolean = False)
    Dim wsIn As Worksheet, wsTx As Worksheet, wsBal As Worksheet
    Dim bankName As String, branchName As String, personName As String, relationName As String, accType As String, accNo As String
    Dim personId As String, accountId As String, transferId As String, txId As String
    Dim openDate As Variant, closeDate As Variant
    Dim yAdd As Long, currentYear As Long, currentMonth As Long, currentDay As Long
    Dim r As Long, outRow As Long, txCount As Long, warnCount As Long, inputOrder As Long
    Dim txDate As Variant, txTime As Variant, dateOK As Boolean, timeOK As Boolean
    Dim tekiyo As String, prevTekiyo As String, shopFinal As String
    Dim focusKeepPolicy As String, nextAccNo As String
    Dim duplicateReport As String, firstTxOutRow As Long, firstBalOutRow As Long
    Dim duplicateSkipCount As Long, balanceAddCount As Long, eventAddCount As Long, fp As String
    Dim existingFingerprints As Object

    If Not RequireToolReady() Then Exit Sub
    On Error GoTo EH
    AppBegin "�����]�L��..."
    Set wsIn = GetSheet(SH_INPUT)
    Set wsTx = GetSheet(SH_WORK_TX)
    Set wsBal = GetSheet(SH_WORK_BAL)
    ResetTransferCheckSheet

    SyncSelectedPersonFromInput wsIn
    bankName = CellText(wsIn.Range(CELL_BANK).Value)
    branchName = CellText(wsIn.Range(CELL_BRANCH).Value)
    personName = CellText(wsIn.Range(CELL_PERSON).Value)
    relationName = CellText(wsIn.Range(CELL_RELATIONSHIP).Value)
    accType = CellText(wsIn.Range(CELL_ACCOUNT_TYPE).Value)
    accNo = CellText(wsIn.Range(CELL_ACCOUNT_NO).Value)
    personId = ResolveInputPersonId(wsIn, personName)
    If Len(relationName) = 0 Then relationName = PersonRelationById(personId)
    openDate = NormalizedAccountDateForUse(wsIn.Range(CELL_OPEN_DATE).Value)
    closeDate = NormalizedAccountDateForUse(wsIn.Range(CELL_CLOSE_DATE).Value)
    nextAccNo = NextBranchAccountNo(accNo)
    focusKeepPolicy = keepOverride
    If Len(focusKeepPolicy) = 0 Then focusKeepPolicy = GetPostTransferKeepPolicy()
    yAdd = GetCfgLong(ROW_CFG_YEAR_ADD, 2000)

    If Len(bankName & branchName & personName & accType & accNo) = 0 Then
        AppEnd
        QuietWarn "������񂪋�ł��B", False, "�����]�L"
        Exit Sub
    End If

    If IsCommonLinkEnabled() And Len(personId) = 0 Then
        AddCheck "�x��", "����!" & CELL_PERSON, _
                 "�l��ID�����A�g�ł��B�l������Ǎ���ł��玁������I�ԂƁA�㑱���͂܂Ŏ����A�g�ł��܂��B"
        warnCount = warnCount + 1
    End If

    duplicateReport = CurrentInputDuplicateReport(wsIn, wsTx, wsBal, personId, personName, bankName, branchName, accType, accNo, openDate, closeDate, yAdd)
    If Len(duplicateReport) > 0 Then
        '�d���\��̓G���[�ł͂Ȃ��BC_�`�F�b�N�ɂ͋L�^���邪�A�ʏ푀����~�߂Ȃ��B
        AddCheck "���", "����", "�d���ς݃f�[�^�͓]�L���ɃX�L�b�v���A�V�K�f�[�^������ǉ����͂��܂��B" & vbCrLf & duplicateReport
    End If

    Set existingFingerprints = CreateObject("Scripting.Dictionary")
    LoadExistingTransferFingerprints existingFingerprints, wsTx, wsBal

    UpdateAccountCandidates bankName, branchName, personName
    transferId = NextTransferId()
    accountId = GetOrCreateWorkAccountId(personId, personName, relationName, bankName, branchName, accType, accNo, openDate, closeDate)
    wsIn.Range(CELL_ACCOUNT_ID).Value = accountId
    firstTxOutRow = LastRow(wsTx, 1) + 1
    If firstTxOutRow < 2 Then firstTxOutRow = 2
    firstBalOutRow = LastRow(wsBal, 1) + 1
    If firstBalOutRow < 2 Then firstBalOutRow = 2

    If AppendAccountEvent(wsTx, bankName, branchName, personName, relationName, accType, accNo, openDate, ROW_KIND_OPEN, personId, accountId, transferId, existingFingerprints) Then eventAddCount = eventAddCount + 1
    If AppendAccountEvent(wsTx, bankName, branchName, personName, relationName, accType, accNo, closeDate, ROW_KIND_CLOSE, personId, accountId, transferId, existingFingerprints) Then eventAddCount = eventAddCount + 1
    AppendBalances wsIn, wsTx, wsBal, bankName, branchName, personName, relationName, accType, accNo, openDate, closeDate, personId, accountId, transferId, existingFingerprints, duplicateSkipCount, balanceAddCount

    For r = TX_FIRST_ROW To TX_LAST_ROW
        If Not IsTransactionRowBlank(wsIn, r) Then
            txDate = ResolveInputDate(wsIn.Cells(r, COL_TX_YEAR).Value, wsIn.Cells(r, COL_TX_MONTH).Value, wsIn.Cells(r, COL_TX_DAY).Value, currentYear, currentMonth, currentDay, yAdd, dateOK)
            If Not dateOK Then AddCheck "�m�F", "����!" & CStr(r) & "�s", "���t�ɕϊ��ł��܂���B": warnCount = warnCount + 1
            txTime = NormalizeTimeInput(wsIn.Cells(r, COL_TX_TIME).Value, timeOK)
            If HasText(wsIn.Cells(r, COL_TX_TIME).Value) And Not timeOK Then AddCheck "�m�F", "����!" & CStr(r) & "�s", "�����ɕϊ��ł��܂���B": warnCount = warnCount + 1
            If HasText(wsIn.Cells(r, COL_TX_WITHDRAW).Value) And HasText(wsIn.Cells(r, COL_TX_DEPOSIT).Value) Then AddCheck "�m�F", "����!" & CStr(r) & "�s", "�o���Ɠ����̗����ɓ��͂�����܂��B": warnCount = warnCount + 1
            If IsDate(txDate) And Not AccountExistsAtDate(txDate, openDate, closeDate) Then AddCheck "�m�F", "����!" & CStr(r) & "�s", "�����J�ݓ��O�܂��͉�����̎���ł��B": warnCount = warnCount + 1

            tekiyo = CellText(wsIn.Cells(r, COL_TX_TEKIYO).Value)
            If tekiyo = "����" Then tekiyo = prevTekiyo
            If Len(tekiyo) = 0 And Len(prevTekiyo) > 0 And HasText(wsIn.Cells(r, COL_TX_OTHER).Value) Then tekiyo = prevTekiyo
            If Len(tekiyo) > 0 Then
                prevTekiyo = tekiyo
                UpdateTekiyoCandidate tekiyo
            End If

            fp = BuildTransactionFingerprint(InputAccountKey(personId, personName, bankName, branchName, accType, accNo), txDate, txTime, _
                ToAmountOrBlank(wsIn.Cells(r, COL_TX_WITHDRAW).Value), ToAmountOrBlank(wsIn.Cells(r, COL_TX_DEPOSIT).Value), _
                CellText(wsIn.Cells(r, COL_TX_SHOP).Value), CellText(wsIn.Cells(r, COL_TX_MACHINE).Value), tekiyo, ToAmountOrBlank(wsIn.Cells(r, COL_TX_OTHER).Value))
            If existingFingerprints.Exists(fp) Then
                duplicateSkipCount = duplicateSkipCount + 1
                AddCheck "�m�F", "����!" & CStr(r) & "�s", "�d���ςݎ���̂��߃X�L�b�v���܂����B�V�K�s�����ǉ����͂��܂��B"
                GoTo NextTransactionInputRow
            End If
            existingFingerprints(fp) = True

            outRow = LastRow(wsTx, 1) + 1
            If outRow < 2 Then outRow = 2
            wsTx.Cells(outRow, OUT_COL_BANK).Value = bankName
            wsTx.Cells(outRow, OUT_COL_BRANCH).Value = branchName
            wsTx.Cells(outRow, OUT_COL_PERSON).Value = personName
            wsTx.Cells(outRow, OUT_COL_ACCOUNT_TYPE).Value = accType
            wsTx.Cells(outRow, OUT_COL_ACCOUNT_NO).Value = accNo
            If IsDate(txDate) Then
                wsTx.Cells(outRow, OUT_COL_DATE).Value = CDate(txDate)
            Else
                wsTx.Cells(outRow, OUT_COL_DATE).Value = wsIn.Cells(r, COL_TX_YEAR).Value & "/" & _
                    wsIn.Cells(r, COL_TX_MONTH).Value & "/" & wsIn.Cells(r, COL_TX_DAY).Value
            End If
            If IsDate(txTime) Then
                wsTx.Cells(outRow, OUT_COL_TIME).Value = CDate(txTime)
            Else
                wsTx.Cells(outRow, OUT_COL_TIME).Value = CellText(wsIn.Cells(r, COL_TX_TIME).Value)
            End If
            wsTx.Cells(outRow, OUT_COL_WITHDRAW).Value = ToAmountOrBlank(wsIn.Cells(r, COL_TX_WITHDRAW).Value)
            wsTx.Cells(outRow, OUT_COL_DEPOSIT).Value = ToAmountOrBlank(wsIn.Cells(r, COL_TX_DEPOSIT).Value)
            wsTx.Cells(outRow, OUT_COL_SHOP).Value = CellText(wsIn.Cells(r, COL_TX_SHOP).Value)
            wsTx.Cells(outRow, OUT_COL_MACHINE).Value = CellText(wsIn.Cells(r, COL_TX_MACHINE).Value)
            wsTx.Cells(outRow, OUT_COL_TEKIYO).Value = tekiyo
            wsTx.Cells(outRow, OUT_COL_OTHER).Value = ToAmountOrBlank(wsIn.Cells(r, COL_TX_OTHER).Value)
            wsTx.Cells(outRow, WORK_TX_COL_RELATIONSHIP).Value = relationName
            txId = NextTransactionId()
            inputOrder = inputOrder + 1
            shopFinal = CellText(wsIn.Cells(r, COL_TX_SHOP).Value)
            If Len(shopFinal) = 0 Then shopFinal = branchName
            RegisterWorkTxMeta wsTx, outRow, personId, accountId, txId, ROW_KIND_TRANSACTION, transferId, r, inputOrder, shopFinal
            wsTx.Cells(outRow, WORK_TX_COL_SOURCE_FINGERPRINT).Value = fp
            txCount = txCount + 1
        End If
NextTransactionInputRow:
    Next r

    If txCount = 0 And balanceAddCount = 0 And eventAddCount = 0 Then
        AppEnd
        If duplicateSkipCount > 0 Then
            SetInputStatus "�V�K�f�[�^�͂���܂���B�d���ς� " & CStr(duplicateSkipCount) & "���͓]�L�����X�L�b�v���܂����B"
        Else
            SetInputStatus "�]�L�Ώۂ̐V�K�f�[�^������܂���B"
        End If
        Exit Sub
    End If

    If duplicateSkipCount > 0 Then
        '�d���X�L�b�v�����Ȃ��ʑJ�ڂ��Ȃ��B���ۂ̓��͕s������C_�`�F�b�N�ֈړ�����B
        AddCheck "���", "����", "�d���ς� " & CStr(duplicateSkipCount) & "�����X�L�b�v���A�V�K�f�[�^������]�L���܂����B"
    End If

    FormatWorkTxRows wsTx, firstTxOutRow, LastRow(wsTx, 1)
    FormatWorkBalRows wsBal, firstBalOutRow, LastRow(wsBal, 1)
    InvalidateDuplicateAccountWarningCache
    AppendLinkLog "�����]�L", "����", personName & " / " & bankName & " " & branchName & " / ���" & txCount & "��"

    If warnCount = 0 Then
        If nextBranchAfter Then
            ApplyPostTransferCleanup KEEP_BANK_BRANCH_PERSON_TYPE
            SetNextBranchAccountNumber nextAccNo
            focusKeepPolicy = KEEP_BANK_BRANCH_PERSON_TYPE
        Else
            ApplyPostTransferCleanup keepOverride
        End If
    Else
        ShowCheckSheet
    End If

    AppEnd
    If warnCount = 0 Then
        FocusAfterPostTransferCleanup focusKeepPolicy
        If duplicateSkipCount > 0 Then
            SetInputStatus "�]�L�ς݁@�V�K��� " & txCount & "���E�c�� " & balanceAddCount & "���B�d�� " & duplicateSkipCount & "���̓X�L�b�v���܂����B"
        Else
            SetInputStatus "�]�L�ς݁@�V�K��� " & txCount & "���E�c�� " & balanceAddCount & "���B���̓��͗��ֈړ����܂����B"
        End If
    Else
        SetInputStatus "�m�F���� " & warnCount & "���BC_�`�F�b�N���m�F���Ă��������B"
    End If
    Exit Sub
EH:
    AppEnd
    RuntimeShowError "TransferCurrentAccount", "�����]�L", "���͗��A��ƃV�[�g�A���V�[�g�A�ی��Ԃ��m�F���Ă��������B"
End Sub

Private Sub ResetTransferCheckSheet()
    Dim ws As Worksheet
    On Error Resume Next
    Set ws = GetOrCreateSheet(SH_CHECK, False)
    If ws Is Nothing Then Exit Sub
    ws.Cells.ClearContents
    SetRowValues ws.Range("A1"), Array("�敪", "������", "���e", "�L�^����")
    FormatOutputHeader ws.Range("A1:D1")
    ws.Columns("A:B").ColumnWidth = 16
    ws.Columns("C:C").ColumnWidth = 80
    ws.Columns("D:D").ColumnWidth = 18
    On Error GoTo 0
End Sub

Private Function AppendAccountEvent(ByVal wsTx As Worksheet, ByVal bankName As String, ByVal branchName As String, ByVal personName As String, _
                               ByVal relationName As String, ByVal accType As String, ByVal accNo As String, _
                               ByVal eventDate As Variant, ByVal rowKind As String, ByVal personId As String, ByVal accountId As String, ByVal transferId As String, _
                               Optional ByVal existingFingerprints As Object = Nothing) As Boolean
    Dim outRow As Long, fp As String
    If Not IsDate(eventDate) Then Exit Function
    fp = BuildAccountEventFingerprint(InputAccountKey(personId, personName, bankName, branchName, accType, accNo), eventDate, rowKind)
    If Not existingFingerprints Is Nothing Then
        If existingFingerprints.Exists(fp) Then Exit Function
        existingFingerprints(fp) = True
    End If
    outRow = LastRow(wsTx, 1) + 1
    If outRow < 2 Then outRow = 2
    wsTx.Cells(outRow, OUT_COL_BANK).Value = bankName
    wsTx.Cells(outRow, OUT_COL_BRANCH).Value = branchName
    wsTx.Cells(outRow, OUT_COL_PERSON).Value = personName
    wsTx.Cells(outRow, OUT_COL_ACCOUNT_TYPE).Value = accType
    wsTx.Cells(outRow, OUT_COL_ACCOUNT_NO).Value = accNo
    wsTx.Cells(outRow, OUT_COL_DATE).Value = CDate(eventDate)
    If rowKind = ROW_KIND_OPEN Then
        wsTx.Cells(outRow, OUT_COL_TEKIYO).Value = "�����J�ݓ�"
    Else
        wsTx.Cells(outRow, OUT_COL_TEKIYO).Value = "��������"
    End If
    wsTx.Cells(outRow, WORK_TX_COL_RELATIONSHIP).Value = relationName
    RegisterWorkTxMeta wsTx, outRow, personId, accountId, "", rowKind, transferId, 0, 0, branchName
    wsTx.Cells(outRow, WORK_TX_COL_SOURCE_FINGERPRINT).Value = fp
    AppendAccountEvent = True
End Function

Private Sub AppendBalances(ByVal wsIn As Worksheet, ByVal wsTx As Worksheet, ByVal wsBal As Worksheet, _
                           ByVal bankName As String, ByVal branchName As String, ByVal personName As String, ByVal relationName As String, _
                           ByVal accType As String, ByVal accNo As String, ByVal openDate As Variant, ByVal closeDate As Variant, _
                           ByVal personId As String, ByVal accountId As String, ByVal transferId As String, _
                           Optional ByVal existingFingerprints As Object = Nothing, _
                           Optional ByRef duplicateSkipCount As Long = 0, _
                           Optional ByRef addedCount As Long = 0)
    Dim memoCol As Long, c As Long, balVal As Variant, labelText As String, balDate As Variant, fp As String
    Dim rTx As Long, rBal As Long, memoText As String, balanceId As String
    If wsIn Is Nothing Or wsTx Is Nothing Or wsBal Is Nothing Then Exit Sub
    memoCol = BalanceMemoCol(wsIn)
    memoText = CellText(wsIn.Cells(BAL_VALUE_ROW, memoCol).Value)
    For c = BAL_FIRST_COL To memoCol - 1
        balVal = ToAmountOrBlank(wsIn.Cells(BAL_VALUE_ROW, c).Value)
        If HasText(balVal) Then
            labelText = BalanceTekiyoLabel(wsIn.Cells(BAL_LABEL_ROW, c).Value)
            balDate = wsIn.Cells(BAL_DATE_ROW, c).Value
            If Not AccountExistsAtDate(balDate, openDate, closeDate) Then GoTo NextBalanceCol
            fp = BuildBalanceFingerprint(InputAccountKey(personId, personName, bankName, branchName, accType, accNo), balDate, labelText, balVal)
            If Not existingFingerprints Is Nothing Then
                If existingFingerprints.Exists(fp) Then
                    duplicateSkipCount = duplicateSkipCount + 1
                    AddCheck "�m�F", "����!�c��" & CStr(c) & "��", "�d���ςݎc���̂��߃X�L�b�v���܂����B"
                    GoTo NextBalanceCol
                End If
                existingFingerprints(fp) = True
            End If
            rTx = LastRow(wsTx, 1) + 1
            If rTx < 2 Then rTx = 2
            wsTx.Cells(rTx, OUT_COL_BANK).Value = bankName
            wsTx.Cells(rTx, OUT_COL_BRANCH).Value = branchName
            wsTx.Cells(rTx, OUT_COL_PERSON).Value = personName
            wsTx.Cells(rTx, OUT_COL_ACCOUNT_TYPE).Value = accType
            wsTx.Cells(rTx, OUT_COL_ACCOUNT_NO).Value = accNo
            wsTx.Cells(rTx, OUT_COL_DATE).Value = balDate
            wsTx.Cells(rTx, OUT_COL_TEKIYO).Value = labelText
            wsTx.Cells(rTx, OUT_COL_OTHER).Value = balVal
            wsTx.Cells(rTx, WORK_TX_COL_RELATIONSHIP).Value = relationName
            RegisterWorkTxMeta wsTx, rTx, personId, accountId, "", ROW_KIND_BALANCE, transferId, 0, 0, branchName
            wsTx.Cells(rTx, WORK_TX_COL_SOURCE_FINGERPRINT).Value = fp

            rBal = LastRow(wsBal, 1) + 1
            If rBal < 2 Then rBal = 2
            balanceId = NextBalanceId()
            wsBal.Cells(rBal, 1).Value = personName
            wsBal.Cells(rBal, 2).Value = bankName
            wsBal.Cells(rBal, 3).Value = branchName
            wsBal.Cells(rBal, 4).Value = accType
            wsBal.Cells(rBal, 5).Value = accNo
            wsBal.Cells(rBal, 6).Value = openDate
            wsBal.Cells(rBal, 7).Value = closeDate
            wsBal.Cells(rBal, 8).Value = balDate
            wsBal.Cells(rBal, 9).Value = labelText
            wsBal.Cells(rBal, 10).Value = balVal
            wsBal.Cells(rBal, 11).Value = memoText
            wsBal.Cells(rBal, WORK_BAL_COL_RELATIONSHIP).Value = relationName
            RegisterWorkBalMeta wsBal, rBal, personId, accountId, balanceId, transferId
            wsBal.Cells(rBal, WORK_BAL_COL_SOURCE_FINGERPRINT).Value = fp
            addedCount = addedCount + 1
        End If
NextBalanceCol:
    Next c
End Sub

Public Sub FormatWorkTx(Optional ByVal ws As Worksheet = Nothing)
    If ws Is Nothing Then Set ws = GetSheet(SH_WORK_TX)
    If ws Is Nothing Then Exit Sub
    ws.Columns("F:F").NumberFormatLocal = "yyyy/m/d"
    ws.Columns("G:G").NumberFormatLocal = "hh:mm"
    ws.Columns("H:I").NumberFormatLocal = "#,##0"
    ws.Columns("E:E").NumberFormatLocal = "@"
    ws.Columns("J:K").NumberFormatLocal = "@"
    ws.Columns("M:M").NumberFormatLocal = "#,##0"
    ws.Columns("N:X").NumberFormatLocal = "@"
    ws.Columns("Y:Y").NumberFormatLocal = "#,##0"
    ws.Columns("Z:AB").NumberFormatLocal = "@"
End Sub

Public Sub FormatWorkTxRows(ByVal ws As Worksheet, ByVal firstRow As Long, ByVal lastRow As Long)
    If ws Is Nothing Then Exit Sub
    If firstRow < 2 Then firstRow = 2
    If lastRow < firstRow Then Exit Sub
    ws.Range(ws.Cells(firstRow, OUT_COL_DATE), ws.Cells(lastRow, OUT_COL_DATE)).NumberFormatLocal = "yyyy/m/d"
    ws.Range(ws.Cells(firstRow, OUT_COL_TIME), ws.Cells(lastRow, OUT_COL_TIME)).NumberFormatLocal = "hh:mm"
    ws.Range(ws.Cells(firstRow, OUT_COL_WITHDRAW), ws.Cells(lastRow, OUT_COL_DEPOSIT)).NumberFormatLocal = "#,##0"
    ws.Range(ws.Cells(firstRow, OUT_COL_ACCOUNT_NO), ws.Cells(lastRow, OUT_COL_ACCOUNT_NO)).NumberFormatLocal = "@"
    ws.Range(ws.Cells(firstRow, OUT_COL_SHOP), ws.Cells(lastRow, OUT_COL_MACHINE)).NumberFormatLocal = "@"
    ws.Range(ws.Cells(firstRow, OUT_COL_OTHER), ws.Cells(lastRow, OUT_COL_OTHER)).NumberFormatLocal = "#,##0"
    ws.Range(ws.Cells(firstRow, WORK_TX_COL_RELATIONSHIP), ws.Cells(lastRow, WORK_TX_COL_TRANSFERRED_AT)).NumberFormatLocal = "@"
    ws.Range(ws.Cells(firstRow, WORK_TX_COL_AFTER_BALANCE), ws.Cells(lastRow, WORK_TX_COL_AFTER_BALANCE)).NumberFormatLocal = "#,##0"
    ws.Range(ws.Cells(firstRow, WORK_TX_COL_AFTER_BALANCE_RAW), ws.Cells(lastRow, WORK_TX_COL_SOURCE_FINGERPRINT)).NumberFormatLocal = "@"
End Sub

Public Sub FormatWorkBal(Optional ByVal ws As Worksheet = Nothing)
    If ws Is Nothing Then Set ws = GetSheet(SH_WORK_BAL)
    If ws Is Nothing Then Exit Sub
    ws.Columns("F:H").NumberFormatLocal = "yyyy/m/d"
    ws.Columns("J:J").NumberFormatLocal = "#,##0"
    ws.Columns("L:S").NumberFormatLocal = "@"
End Sub

Public Sub FormatWorkBalRows(ByVal ws As Worksheet, ByVal firstRow As Long, ByVal lastRow As Long)
    If ws Is Nothing Then Exit Sub
    If firstRow < 2 Then firstRow = 2
    If lastRow < firstRow Then Exit Sub
    ws.Range(ws.Cells(firstRow, 6), ws.Cells(lastRow, 8)).NumberFormatLocal = "yyyy/m/d"
    ws.Range(ws.Cells(firstRow, 10), ws.Cells(lastRow, 10)).NumberFormatLocal = "#,##0"
    ws.Range(ws.Cells(firstRow, WORK_BAL_COL_RELATIONSHIP), ws.Cells(lastRow, WORK_BAL_COL_SOURCE_FINGERPRINT)).NumberFormatLocal = "@"
End Sub

Private Function CurrentInputDuplicateReport(ByVal wsIn As Worksheet, ByVal wsTx As Worksheet, ByVal wsBal As Worksheet, _
        ByVal personId As String, ByVal personName As String, ByVal bankName As String, ByVal branchName As String, _
        ByVal accType As String, ByVal accNo As String, ByVal openDate As Variant, ByVal closeDate As Variant, ByVal yAdd As Long) As String
    Dim existing As Object, accountKey As String, report As String
    Dim r As Long, c As Long, memoCol As Long, labelText As String, balVal As Variant, balDate As Variant
    Dim txDate As Variant, txTime As Variant, dateOK As Boolean, timeOK As Boolean
    Dim currentYear As Long, currentMonth As Long, currentDay As Long
    Dim tekiyo As String, prevTekiyo As String, fp As String, checkedDataCount As Long, eventHit As Boolean
    Set existing = CreateObject("Scripting.Dictionary")
    LoadExistingTransferFingerprints existing, wsTx, wsBal
    accountKey = InputAccountKey(personId, personName, bankName, branchName, accType, accNo)

    memoCol = BalanceMemoCol(wsIn)
    For c = BAL_FIRST_COL To memoCol - 1
        balVal = ToAmountOrBlank(wsIn.Cells(BAL_VALUE_ROW, c).Value)
        If HasText(balVal) Then
            labelText = BalanceTekiyoLabel(wsIn.Cells(BAL_LABEL_ROW, c).Value)
            balDate = wsIn.Cells(BAL_DATE_ROW, c).Value
            If AccountExistsAtDate(balDate, openDate, closeDate) Then
                fp = BuildBalanceFingerprint(accountKey, balDate, labelText, balVal)
                checkedDataCount = checkedDataCount + 1
                If existing.Exists(fp) Then
                    AppendDuplicateLine report, "�c�� " & labelText & " " & FingerprintDateKey(balDate) & " " & AmountFingerprint(balVal)
                Else
                    existing(fp) = True
                End If
            End If
        End If
    Next c

    For r = TX_FIRST_ROW To TX_LAST_ROW
        If Not IsTransactionRowBlank(wsIn, r) Then
            txDate = ResolveInputDate(wsIn.Cells(r, COL_TX_YEAR).Value, wsIn.Cells(r, COL_TX_MONTH).Value, wsIn.Cells(r, COL_TX_DAY).Value, currentYear, currentMonth, currentDay, yAdd, dateOK)
            txTime = NormalizeTimeInput(wsIn.Cells(r, COL_TX_TIME).Value, timeOK)
            tekiyo = CellText(wsIn.Cells(r, COL_TX_TEKIYO).Value)
            If tekiyo = "����" Then tekiyo = prevTekiyo
            If Len(tekiyo) = 0 And Len(prevTekiyo) > 0 And HasText(wsIn.Cells(r, COL_TX_OTHER).Value) Then tekiyo = prevTekiyo
            If Len(tekiyo) > 0 Then prevTekiyo = tekiyo
            fp = BuildTransactionFingerprint(accountKey, txDate, txTime, _
                ToAmountOrBlank(wsIn.Cells(r, COL_TX_WITHDRAW).Value), ToAmountOrBlank(wsIn.Cells(r, COL_TX_DEPOSIT).Value), _
                CellText(wsIn.Cells(r, COL_TX_SHOP).Value), CellText(wsIn.Cells(r, COL_TX_MACHINE).Value), tekiyo, ToAmountOrBlank(wsIn.Cells(r, COL_TX_OTHER).Value))
            checkedDataCount = checkedDataCount + 1
            If existing.Exists(fp) Then
                AppendDuplicateLine report, "��� ����" & CStr(r) & "�s�� " & FingerprintDateKey(txDate) & " �o" & AmountFingerprint(wsIn.Cells(r, COL_TX_WITHDRAW).Value) & " ��" & AmountFingerprint(wsIn.Cells(r, COL_TX_DEPOSIT).Value)
            Else
                existing(fp) = True
            End If
        End If
    Next r

    If checkedDataCount = 0 Then
        If IsDate(openDate) Then eventHit = existing.Exists(BuildAccountEventFingerprint(accountKey, openDate, ROW_KIND_OPEN))
        If IsDate(closeDate) Then eventHit = eventHit Or existing.Exists(BuildAccountEventFingerprint(accountKey, closeDate, ROW_KIND_CLOSE))
        If eventHit Then AppendDuplicateLine report, "�����C�x���g�݂̂̏d���i��������̊J�ݓ�/�����j"
    End If
    CurrentInputDuplicateReport = report
End Function

Private Sub LoadExistingTransferFingerprints(ByVal dict As Object, ByVal wsTx As Worksheet, ByVal wsBal As Worksheet)
    Dim r As Long, lastR As Long, fp As String
    If dict Is Nothing Then Exit Sub
    If Not wsTx Is Nothing Then
        lastR = LastRow(wsTx, 1)
        For r = 2 To lastR
            If CellText(wsTx.Cells(r, WORK_TX_COL_DATA_STATUS).Value) <> "���" Then
                fp = ExistingWorkTxFingerprint(wsTx, r)
                If Len(fp) > 0 Then dict(fp) = True
            End If
        Next r
    End If
    If Not wsBal Is Nothing Then
        lastR = LastRow(wsBal, 1)
        For r = 2 To lastR
            If CellText(wsBal.Cells(r, WORK_BAL_COL_DATA_STATUS).Value) <> "���" Then
                fp = ExistingWorkBalFingerprint(wsBal, r)
                If Len(fp) > 0 Then dict(fp) = True
            End If
        Next r
    End If
End Sub

Private Function ExistingWorkTxFingerprint(ByVal ws As Worksheet, ByVal r As Long) As String
    Dim stored As String, accountKey As String, rowKind As String
    stored = CellText(ws.Cells(r, WORK_TX_COL_SOURCE_FINGERPRINT).Value)
    If Len(stored) > 0 Then ExistingWorkTxFingerprint = stored: Exit Function
    accountKey = InputAccountKey(CellText(ws.Cells(r, WORK_TX_COL_PERSON_ID).Value), CellText(ws.Cells(r, OUT_COL_PERSON).Value), _
        CellText(ws.Cells(r, OUT_COL_BANK).Value), CellText(ws.Cells(r, OUT_COL_BRANCH).Value), _
        CellText(ws.Cells(r, OUT_COL_ACCOUNT_TYPE).Value), CellText(ws.Cells(r, OUT_COL_ACCOUNT_NO).Value))
    rowKind = CellText(ws.Cells(r, WORK_TX_COL_ROW_KIND).Value)
    Select Case rowKind
        Case ROW_KIND_TRANSACTION, ""
            ExistingWorkTxFingerprint = BuildTransactionFingerprint(accountKey, ws.Cells(r, OUT_COL_DATE).Value, ws.Cells(r, OUT_COL_TIME).Value, _
                ws.Cells(r, OUT_COL_WITHDRAW).Value, ws.Cells(r, OUT_COL_DEPOSIT).Value, ws.Cells(r, OUT_COL_SHOP).Value, _
                ws.Cells(r, OUT_COL_MACHINE).Value, ws.Cells(r, OUT_COL_TEKIYO).Value, ws.Cells(r, OUT_COL_OTHER).Value)
        Case ROW_KIND_BALANCE
            ExistingWorkTxFingerprint = BuildBalanceFingerprint(accountKey, ws.Cells(r, OUT_COL_DATE).Value, ws.Cells(r, OUT_COL_TEKIYO).Value, ws.Cells(r, OUT_COL_OTHER).Value)
        Case ROW_KIND_OPEN, ROW_KIND_CLOSE
            ExistingWorkTxFingerprint = BuildAccountEventFingerprint(accountKey, ws.Cells(r, OUT_COL_DATE).Value, rowKind)
    End Select
End Function

Private Function ExistingWorkBalFingerprint(ByVal ws As Worksheet, ByVal r As Long) As String
    Dim stored As String, accountKey As String
    stored = CellText(ws.Cells(r, WORK_BAL_COL_SOURCE_FINGERPRINT).Value)
    If Len(stored) > 0 Then ExistingWorkBalFingerprint = stored: Exit Function
    accountKey = InputAccountKey(CellText(ws.Cells(r, WORK_BAL_COL_PERSON_ID).Value), CellText(ws.Cells(r, 1).Value), _
        CellText(ws.Cells(r, 2).Value), CellText(ws.Cells(r, 3).Value), CellText(ws.Cells(r, 4).Value), CellText(ws.Cells(r, 5).Value))
    ExistingWorkBalFingerprint = BuildBalanceFingerprint(accountKey, ws.Cells(r, 8).Value, ws.Cells(r, 9).Value, ws.Cells(r, 10).Value)
End Function

Private Sub AppendDuplicateLine(ByRef report As String, ByVal lineText As String)
    If Len(report) > 1200 Then Exit Sub
    If Len(report) > 0 Then report = report & vbCrLf
    report = report & "�E" & lineText
End Sub

Private Function InputAccountKey(ByVal personId As String, ByVal personName As String, ByVal bankName As String, ByVal branchName As String, ByVal accType As String, ByVal accNo As String) As String
    Dim personKey As String
    '�d������́u����̓��͌������v�����邽�߁AID�A�g�O��ŕω����Ȃ�������D�悷��B
    '��������̏ꍇ�����l��ID�փt�H�[���o�b�N����B
    personKey = TextFingerprint(personName)
    If Len(personKey) = 0 Then personKey = TextFingerprint(personId)
    InputAccountKey = personKey & "|" & TextFingerprint(bankName) & "|" & TextFingerprint(branchName) & "|" & TextFingerprint(accType) & "|" & TextFingerprint(NormalizeAccountHyphen(accNo))
End Function

Private Function BuildTransactionFingerprint(ByVal accountKey As String, ByVal txDate As Variant, ByVal txTime As Variant, ByVal withdrawValue As Variant, ByVal depositValue As Variant, _
        ByVal shopText As Variant, ByVal machineText As Variant, ByVal tekiyoText As Variant, ByVal otherValue As Variant) As String
    BuildTransactionFingerprint = "TX|" & accountKey & "|" & FingerprintDateKey(txDate) & "|" & FingerprintTimeKey(txTime) & "|" & _
        AmountFingerprint(withdrawValue) & "|" & AmountFingerprint(depositValue) & "|" & TextFingerprint(shopText) & "|" & _
        TextFingerprint(machineText) & "|" & TextFingerprint(tekiyoText) & "|" & AmountFingerprint(otherValue)
End Function

Private Function BuildBalanceFingerprint(ByVal accountKey As String, ByVal balDate As Variant, ByVal labelText As Variant, ByVal balanceValue As Variant) As String
    BuildBalanceFingerprint = "BAL|" & accountKey & "|" & FingerprintDateKey(balDate) & "|" & TextFingerprint(labelText) & "|" & AmountFingerprint(balanceValue)
End Function

Private Function BuildAccountEventFingerprint(ByVal accountKey As String, ByVal eventDate As Variant, ByVal rowKind As String) As String
    BuildAccountEventFingerprint = "EV|" & accountKey & "|" & TextFingerprint(rowKind) & "|" & FingerprintDateKey(eventDate)
End Function

Private Function FingerprintDateKey(ByVal v As Variant) As String
    If IsDate(v) Then
        FingerprintDateKey = CStr(CLng(DateValue(CDate(v))))
    Else
        FingerprintDateKey = TextFingerprint(v)
    End If
End Function

Private Function FingerprintTimeKey(ByVal v As Variant) As String
    If IsDate(v) Then
        FingerprintTimeKey = Format$(CDate(v), "hh:nn:ss")
    Else
        FingerprintTimeKey = TextFingerprint(v)
    End If
End Function

Private Function AmountFingerprint(ByVal v As Variant) As String
    Dim n As Variant
    n = ToAmountOrBlank(v)
    If HasText(n) And IsNumeric(n) Then
        AmountFingerprint = Format$(CDbl(n), "0.00########")
    Else
        AmountFingerprint = TextFingerprint(v)
    End If
End Function

Private Function TextFingerprint(ByVal v As Variant) As String
    Dim s As String
    s = CellText(v)
    s = Replace(s, "�@", " ")
    s = Trim$(s)
    Do While InStr(s, "  ") > 0
        s = Replace(s, "  ", " ")
    Loop
    TextFingerprint = UCase$(s)
End Function


Attribute VB_Name = "modUI"
Option Explicit

Private mButtonSeq As Long

Public Sub BuildOperationPanel(ByVal ws As Worksheet)
    Dim x As Double, y As Double, w As Double, h As Double
    Dim margin As Double, gap As Double, btnH As Double, primaryH As Double
    Dim colW2 As Double, colW3 As Double, left1 As Double, left2 As Double, left3 As Double
    Dim topY As Double, contentH As Double
    If ws Is Nothing Then Exit Sub

    mButtonSeq = 0
    On Error Resume Next
    DeleteToolShapes ws, False
    On Error GoTo 0

    '���͗����ז����Ȃ��E���������g���B�s��������Ń{�^�����p�l���O�֏o�Ȃ��悤�A�K�v�������Ɋm�ۂ���B
    x = ws.Range("M2").Left
    y = ws.Range("M2").Top + 4
    w = ws.Range("M2:T15").Width
    h = ws.Range("M2:T15").Height

    margin = 12
    gap = 6
    btnH = 23
    primaryH = 34
    colW2 = (w - margin * 2 - gap) / 2
    colW3 = (w - margin * 2 - gap * 2) / 3
    left1 = x + margin
    left2 = left1 + colW3 + gap
    left3 = left2 + colW3 + gap

    AddPanelBack ws, x, y, w, h

    contentH = primaryH + btnH * 5 + gap * 5
    If h < contentH + margin * 2 Then h = contentH + margin * 2
    topY = y + (h - contentH) / 2
    If topY < y + 12 Then topY = y + 12

    AddUIButton ws, left1, topY, colW3, primaryH, "���̌�����]�L", "TransferCurrentAccount", "primary"
    AddUIButton ws, left2, topY, colW3, primaryH, "�ꊇ�쐬", "BuildAllOutputSheets", "hero"
    AddUIButton ws, left3, topY, colW3, primaryH, "�ŏI�o��", "ExportFinalWorkbooks", "export"

    topY = topY + primaryH + gap
    '�呀��̎��́A��Ə������R�ɗ����悤�u���}�ԁv�u�Ώۈꗗ�v�u�ϊ��ϕ\�v�̏��ɕ��ׂ�B
    AddUIButton ws, left1, topY, colW3, btnH, "���}�ԓ]�L", "TransferCurrentAccountNextBranch", "accent"
    AddUIButton ws, left2, topY, colW3, btnH, "�Ώۈꗗ", "BuildShopConversionTargetSheet", "tool"
    AddUIButton ws, left3, topY, colW3, btnH, "�ϊ��ϕ\", "ShowConvertedCashOperationSheet", "soft"

    topY = topY + btnH + gap
    AddUIButton ws, left1, topY, colW3, btnH, "��s�x�X�]�L", "TransferCurrentAccountKeepBankBranch", "tool"
    AddUIButton ws, left2, topY, colW3, btnH, "�}��+1", "IncrementAccountBranchNo", "tool"
    AddUIButton ws, left3, topY, colW3, btnH, "��������", "RestoreToolFormatting", "tool"

    topY = topY + btnH + gap
    AddUIButton ws, left1, topY, colW3, btnH, "���͗��X�V", "ApplyInputSettings", "tool"
    AddUIButton ws, left2, topY, colW3, btnH, "�ݒ�", "ShowConfigSheet", "tool"
    AddUIButton ws, left3, topY, colW3, btnH, "���Ǘ�", "ShowCandidateSheets", "tool"

    topY = topY + btnH + gap
    AddUIButton ws, left1, topY, colW3, btnH, "���׃N���A", "ClearTransactionInput", "neutral"
    AddUIButton ws, left2, topY, colW3, btnH, "��s�x�X�c��", "ClearInputKeepBankBranch", "soft"
    AddUIButton ws, left3, topY, colW3, btnH, "���������c��", "ClearInputKeepPerson", "soft"

    topY = topY + btnH + gap
    AddUIButton ws, left1, topY, colW3, btnH, "�S�N���A", "ClearAllInputFields", "danger"
    AddUIButton ws, left2, topY, colW3, btnH, "������", "InitializeToolData", "danger"
    AddUIButton ws, left3, topY, colW3, btnH, "Tab����", "RestoreInputNavigation", "soft"

    '�s���E�t�H���g���Ń{�^�����͂ݏo�����ꍇ�ł��A�w�i�p�l�����{�^���S�̂ɍ��킹�Ċg������B
    FitOperationPanelBackToButtons ws, margin

    '�쐬����Ƀ{�^���E�J�[�h�����b�N���A�W�F�{�^���̕����F���ŏI�␳����B
    LockToolShapes ws
End Sub


Private Sub FitOperationPanelBackToButtons(ByVal ws As Worksheet, ByVal pad As Double)
    Dim shp As Shape
    Dim back As Shape
    Dim minL As Double, minT As Double, maxR As Double, maxB As Double
    Dim hasButton As Boolean
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    Set back = ws.Shapes(UI_PREFIX & "panel_back")
    If back Is Nothing Then Exit Sub
    For Each shp In ws.Shapes
        If Left$(shp.Name, Len(UI_PREFIX & "btn_")) = UI_PREFIX & "btn_" Then
            If Len(CellText(shp.OnAction)) > 0 Or Len(CellText(shp.AlternativeText)) > 0 Then
                If Not hasButton Then
                    minL = shp.Left: minT = shp.Top: maxR = shp.Left + shp.Width: maxB = shp.Top + shp.Height
                    hasButton = True
                Else
                    If shp.Left < minL Then minL = shp.Left
                    If shp.Top < minT Then minT = shp.Top
                    If shp.Left + shp.Width > maxR Then maxR = shp.Left + shp.Width
                    If shp.Top + shp.Height > maxB Then maxB = shp.Top + shp.Height
                End If
            End If
        End If
    Next shp
    If hasButton Then
        back.Left = minL - pad
        back.Top = minT - pad
        back.Width = maxR - minL + pad * 2
        back.Height = maxB - minT + pad * 2
        back.ZOrder msoSendToBack
    End If
    On Error GoTo 0
End Sub

Public Sub AddPanelBack(ByVal ws As Worksheet, ByVal x As Double, ByVal y As Double, ByVal w As Double, ByVal h As Double)
    Dim shp As Shape
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    Set shp = ws.Shapes.AddShape(msoShapeRoundedRectangle, x, y, w, h)
    If Not shp Is Nothing Then
        With shp
            .Name = UI_PREFIX & "panel_back"
            .Fill.ForeColor.RGB = RGB(255, 255, 255)
            .Line.ForeColor.RGB = RGB(203, 213, 225)
            .Line.Weight = 1
            '�p�l���w�i�͌�h���b�O�œ����Ȃ��悤���b�N����B
            'xlMove�ɂ��āA�񕝒������ɃJ�[�h���s�p�ӂɐL�k���Ȃ��悤�ɂ���B
            .Placement = xlMove
            .Locked = True
            .ZOrder msoSendToBack
            .Shadow.Visible = msoTrue
            .Shadow.Transparency = 0.88
            .Shadow.Blur = 7
            .Shadow.OffsetX = 0
            .Shadow.OffsetY = 2
        End With
    End If
    On Error GoTo 0
End Sub

Public Sub AddUIButton(ByVal ws As Worksheet, ByVal x As Double, ByVal y As Double, ByVal w As Double, ByVal h As Double, ByVal caption As String, ByVal macroName As String, ByVal styleName As String)
    Dim shp As Shape
    Dim btn As Object
    Dim fillColor As Long, lineColor As Long, fontColor As Long
    If ws Is Nothing Then Exit Sub
    GetButtonColors styleName, fillColor, lineColor, fontColor
    If IsLightExcelColor(fillColor) And IsLightExcelColor(fontColor) Then fontColor = RGB(15, 23, 42)
    On Error Resume Next
    Set shp = ws.Shapes.AddShape(msoShapeRoundedRectangle, x, y, w, h)
    If Not shp Is Nothing Then
        mButtonSeq = mButtonSeq + 1
        With shp
            .Name = UI_PREFIX & "btn_" & CStr(mButtonSeq)
            .TextFrame.Characters.Text = caption
            .TextFrame.HorizontalAlignment = xlHAlignCenter
            .TextFrame.VerticalAlignment = xlVAlignCenter
            .TextFrame.MarginLeft = 2
            .TextFrame.MarginRight = 2
            .TextFrame.MarginTop = 0
            .TextFrame.MarginBottom = 0
            .TextFrame.Characters.Font.Name = "Yu Gothic UI"
            If h >= 30 Then
                .TextFrame.Characters.Font.Size = 10.5
            Else
                .TextFrame.Characters.Font.Size = 9.5
            End If
            .TextFrame.Characters.Font.Bold = True
            .TextFrame.Characters.Font.Color = fontColor
            .Fill.ForeColor.RGB = fillColor
            .Line.ForeColor.RGB = lineColor
            .Line.Weight = 0.8
            '�p�l���w�i�͌�h���b�O�œ����Ȃ��悤���b�N����B
            'xlMove�ɂ��āA�񕝒������ɃJ�[�h���s�p�ӂɐL�k���Ȃ��悤�ɂ���B
            .Placement = xlMove
            .Locked = True
            .OnAction = MacroRef(macroName)
            .AlternativeText = macroName
            .Shadow.Visible = msoFalse
        End With
        Exit Sub
    End If
    Err.Clear
    Set btn = ws.Buttons.Add(x, y, w, h)
    If Not btn Is Nothing Then
        btn.Caption = caption
        btn.OnAction = MacroRef(macroName)
        On Error Resume Next
        btn.Locked = True
        btn.Placement = xlMove
        On Error GoTo 0
    End If
    On Error GoTo 0
End Sub

Private Sub GetButtonColors(ByVal styleName As String, ByRef fillColor As Long, ByRef lineColor As Long, ByRef fontColor As Long)
    fontColor = RGB(15, 23, 42)
    Select Case LCase$(styleName)
        Case "hero"
            fillColor = RGB(20, 184, 166)
            lineColor = RGB(13, 148, 136)
            fontColor = RGB(255, 255, 255)
        Case "primary"
            fillColor = RGB(37, 99, 235)
            lineColor = RGB(29, 78, 216)
            fontColor = RGB(255, 255, 255)
        Case "accent"
            fillColor = RGB(14, 165, 233)
            lineColor = RGB(2, 132, 199)
            fontColor = RGB(255, 255, 255)
        Case "export"
            fillColor = RGB(124, 58, 237)
            lineColor = RGB(109, 40, 217)
            fontColor = RGB(255, 255, 255)
        Case "danger"
            fillColor = RGB(239, 68, 68)
            lineColor = RGB(220, 38, 38)
            fontColor = RGB(255, 255, 255)
        Case "neutral"
            fillColor = RGB(241, 245, 249)
            lineColor = RGB(203, 213, 225)
            fontColor = RGB(15, 23, 42)
        Case "tool"
            fillColor = RGB(255, 255, 255)
            lineColor = RGB(203, 213, 225)
            fontColor = RGB(30, 64, 175)
        Case "soft"
            fillColor = RGB(248, 250, 252)
            lineColor = RGB(226, 232, 240)
            fontColor = RGB(51, 65, 85)
        Case Else
            fillColor = RGB(248, 250, 252)
            lineColor = RGB(203, 213, 225)
            fontColor = RGB(15, 23, 42)
    End Select
End Sub

Public Sub AddConfigButton(ByVal ws As Worksheet, ByVal cellAddress As String, ByVal caption As String, ByVal macroName As String)
    Dim a As Range
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    Set a = ws.Range(cellAddress)
    On Error GoTo 0
    If a Is Nothing Then Exit Sub
    AddUIButton ws, a.Left, a.Top, Application.Max(150, a.Width - 4), 28, caption, macroName, "tool"
End Sub

Public Sub BuildInputHelpCards(ByVal ws As Worksheet)
    '�E�チ�j���[�̉��ɑ����Ⓑ����u���Ȃ��B���͗��֎��R�Ɏ�����������]���ɂ���B
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    ws.Range("M14:T14").UnMerge
    ws.Range("M14:T14").ClearContents
    ws.Range("M14:T14").Interior.Color = RGB(248, 250, 252)
    ws.Range("M14:T14").Borders.LineStyle = xlNone
    ws.Rows(14).RowHeight = 22
    On Error GoTo 0
End Sub

Public Sub RefreshButtonActions()
    'SaveAs��Ƀu�b�N�����ς���Ă��A�}�`�{�^���̎Q�Ɛ�����݂�ThisWorkbook�֒��蒼���B
    '�ߋ��ł� AlternativeText ��������{�^�����A�V�[�g���{�\������������m�̐������}�N���֕␳����B
    Dim ws As Worksheet
    Dim shp As Shape
    Dim macroName As String
    Dim captionText As String
    On Error Resume Next
    For Each ws In ThisWorkbook.Worksheets
        For Each shp In ws.Shapes
            If Left$(shp.Name, Len(UI_PREFIX & "btn_")) = UI_PREFIX & "btn_" _
                    Or Left$(shp.Name, 21) = "btn_import_person_res" _
                    Or Left$(shp.Name, 21) = "btn_import_person_can" Then
                captionText = ButtonCaptionText(shp)
                macroName = KnownButtonMacro(ws.Name, captionText)
                If Len(macroName) = 0 Then macroName = CellText(shp.AlternativeText)
                If Len(macroName) > 0 Then
                    shp.AlternativeText = macroName
                    shp.OnAction = MacroRef(macroName)
                    shp.PrintObject = False
                End If
            End If
        Next shp
    Next ws
    On Error GoTo 0
End Sub

Private Function ButtonCaptionText(ByVal shp As Shape) As String
    On Error Resume Next
    ButtonCaptionText = CellText(shp.TextFrame.Characters.Text)
    If Len(ButtonCaptionText) = 0 Then ButtonCaptionText = CellText(shp.TextFrame2.TextRange.Text)
    On Error GoTo 0
End Function

Private Function KnownButtonMacro(ByVal sheetName As String, ByVal captionText As String) As String
    captionText = Replace$(CellText(captionText), vbLf, "")
    Select Case sheetName
        Case SH_CONFIG
            Select Case captionText
                Case "�c�������Đ���": KnownButtonMacro = "BuildBalanceInputFields"
                Case "���͗��ݒ���X�V": KnownButtonMacro = "ApplyInputSettings"
                Case "�l�����Ǎ�": KnownButtonMacro = "LoadPersonMasterFromCommonData"
                Case "���ʃf�[�^�ۑ�": KnownButtonMacro = "SaveFinanceCommonData"
                Case "�O���\�捞": KnownButtonMacro = "ImportExternalCashOperationTable"
                Case "�c���⊮": KnownButtonMacro = "RebuildBalancesFromTransactionAfterBalanceButton"
                Case "�����𕜋�": KnownButtonMacro = "RestoreToolFormatting"
                Case "���̓V�[�g��", "���͂�": KnownButtonMacro = "ShowInputSheet"
                Case "�A�g�`�F�b�N": KnownButtonMacro = "ValidateFinanceLinkage"
                Case "�c�[��������": KnownButtonMacro = "InitializeToolData"
            End Select
        Case SH_INPUT
            Select Case captionText
                Case "���̌�����]�L": KnownButtonMacro = "TransferCurrentAccount"
                Case "�ꊇ�쐬": KnownButtonMacro = "BuildAllOutputSheets"
                Case "�ŏI�o��": KnownButtonMacro = "ExportFinalWorkbooks"
                Case "���}�ԓ]�L": KnownButtonMacro = "TransferCurrentAccountNextBranch"
                Case "�Ώۈꗗ": KnownButtonMacro = "BuildShopConversionTargetSheet"
                Case "�ϊ��ϕ\": KnownButtonMacro = "ShowConvertedCashOperationSheet"
                Case "��s�x�X�]�L": KnownButtonMacro = "TransferCurrentAccountKeepBankBranch"
                Case "�}��+1": KnownButtonMacro = "IncrementAccountBranchNo"
                Case "��������": KnownButtonMacro = "RestoreToolFormatting"
                Case "���͗��X�V": KnownButtonMacro = "ApplyInputSettings"
                Case "�ݒ�": KnownButtonMacro = "ShowConfigSheet"
                Case "���Ǘ�": KnownButtonMacro = "ShowCandidateSheets"
                Case "���׃N���A": KnownButtonMacro = "ClearTransactionInput"
                Case "��s�x�X�c��": KnownButtonMacro = "ClearInputKeepBankBranch"
                Case "���������c��": KnownButtonMacro = "ClearInputKeepPerson"
                Case "�S�N���A": KnownButtonMacro = "ClearAllInputFields"
                Case "������": KnownButtonMacro = "InitializeToolData"
                Case "Tab����": KnownButtonMacro = "RestoreInputNavigation"
            End Select
        Case SH_IMPORT_PERSON_RESOLUTION
            Select Case captionText
                Case "���I��": KnownButtonMacro = "ChooseImportPersonResolutionForActiveRow"
                Case "���ꗗ": KnownButtonMacro = "ShowImportPersonCandidatePanelForActiveRow"
                Case "�I�𔽉f": KnownButtonMacro = "ApplyImportPersonResolutionSelections"
                Case "�I�𔽉f���Ď捞": KnownButtonMacro = "ReimportAfterImportPersonResolutionSelection"
                Case "���͂�", "���̓V�[�g��": KnownButtonMacro = "ShowInputSheet"
            End Select
        Case SH_IMPORT_PERSON_CAND_PANEL
            Select Case captionText
                Case "���̌���I��": KnownButtonMacro = "ApplyImportPersonCandidatePanelSelection"
                Case "�ƍ��\�֖߂�": KnownButtonMacro = "ShowImportPersonResolutionSheet"
            End Select
    End Select
End Function

Public Sub FormatHeader(ByVal rng As Range, Optional ByVal fillColor As Long = 0)
    If rng Is Nothing Then Exit Sub
    If fillColor = 0 Then fillColor = RGB(226, 232, 240)
    With rng
        .Font.Bold = True
        .Font.Color = RGB(15, 23, 42)
        .Interior.Color = fillColor
        .Borders.LineStyle = xlContinuous
        .Borders.Color = RGB(203, 213, 225)
        .VerticalAlignment = xlCenter
    End With
End Sub

Public Sub FormatOutputHeader(ByVal rng As Range)
    If rng Is Nothing Then Exit Sub
    With rng
        .Font.Bold = True
        .Font.Size = 14
        .Font.Color = RGB(255, 255, 255)
        .Interior.Color = RGB(30, 64, 175)
        .HorizontalAlignment = xlCenter
        .VerticalAlignment = xlCenter
        .Borders.LineStyle = xlContinuous
        .Borders.Color = RGB(147, 197, 253)
    End With
End Sub

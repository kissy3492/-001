Attribute VB_Name = "modImportPersonResolutionUi"
Option Explicit

'�O���\�捞���̐l���ƍ����uO��֎���́v�����ɂ��Ȃ����߂̔���UI�w�B
'��◓�̃_�u���N���b�N�܂��͌��I���{�^���ŁA���ID��I��l��ID�֓]�L����B

Public Sub HandleImportPersonResolutionDoubleClick(ByVal Sh As Object, ByVal Target As Range, ByRef Cancel As Boolean)
    If Sh Is Nothing Then Exit Sub
    If Sh.Name <> SH_IMPORT_PERSON_RESOLUTION Then Exit Sub
    If Target Is Nothing Then Exit Sub
    If Target.Row < 3 Then Exit Sub
    If Target.Column <> 7 And Target.Column <> 15 And Target.Column <> 16 Then Exit Sub
    Cancel = True
    ChooseImportPersonResolutionRow Sh, Target.Row
End Sub

Public Sub HandleImportPersonResolutionChange(ByVal Sh As Object, ByVal Target As Range)
    If Sh Is Nothing Then Exit Sub
    If Sh.Name <> SH_IMPORT_PERSON_RESOLUTION Then Exit Sub
    If Target Is Nothing Then Exit Sub
    If Intersect(Target, Sh.Range("O3:O" & Sh.Rows.Count)) Is Nothing Then Exit Sub
    ValidateChangedImportPersonResolutionSelection Sh, Intersect(Target, Sh.Range("O3:O" & Sh.Rows.Count))
End Sub

Public Sub ChooseImportPersonResolutionForActiveRowUi()
    If ActiveSheet Is Nothing Then Exit Sub
    If ActiveSheet.Name <> SH_IMPORT_PERSON_RESOLUTION Then
        NotifyInfo "W_�捞�l���ƍ���\�����A���s��I�����Ă�����s���Ă��������B"
        Exit Sub
    End If
    If ActiveCell.Row < 3 Then
        NotifyInfo "���s��I�����Ă��������B"
        Exit Sub
    End If
    ChooseImportPersonResolutionRow ActiveSheet, ActiveCell.Row
End Sub

Public Sub ChooseImportPersonResolutionRow(ByVal ws As Worksheet, ByVal rowNo As Long)
    Dim ids As Collection, names As Object, candidateText As String
    Dim prompt As String, selectedId As Variant, firstId As String
    If ws Is Nothing Then Exit Sub
    If rowNo < 3 Then Exit Sub
    candidateText = CellText(ws.Cells(rowNo, 7).Value)
    Set ids = ParseImportPersonCandidateIds(candidateText, names)
    If ids.Count = 0 Then
        QuietWarn "���̍s�ɂ͌��ID������܂���B01�l�����Ől���o�^�E���ʕۑ����m�F���邩�AO��ɐl��ID�𒼐ړ��͂��Ă��������B", False, "�l�����I��"
        Exit Sub
    ElseIf ids.Count = 1 Then
        firstId = CStr(ids(1))
        ApplyImportPersonResolutionChoice ws, rowNo, firstId, "���1����I��"
        Exit Sub
    End If
    ShowImportPersonCandidatePanel ws, rowNo, candidateText
    prompt = "���ID����͂��Ă��������B" & vbCrLf & vbCrLf & candidateText
    selectedId = Application.InputBox(prompt, "�l�����I��", CStr(ids(1)), Type:=2)
    If VarType(selectedId) = vbBoolean Then Exit Sub
    selectedId = Trim$(CStr(selectedId))
    If Len(CStr(selectedId)) = 0 Then Exit Sub
    ApplyImportPersonResolutionChoice ws, rowNo, CStr(selectedId), "���I��"
End Sub

Private Sub ValidateChangedImportPersonResolutionSelection(ByVal ws As Worksheet, ByVal rng As Range)
    Dim c As Range, idText As String
    On Error GoTo CleanExit
    Application.EnableEvents = False
    For Each c In rng.Cells
        idText = CellText(c.Value)
        If Len(idText) = 0 Then
            ws.Cells(c.Row, 16).Value = ""
            ws.Cells(c.Row, 17).Value = ""
        ElseIf ImportedPersonIdExists(idText) Then
            ws.Cells(c.Row, 1).Value = "�蓮�I����/�Ď捞��"
            ws.Cells(c.Row, 16).Value = ImportedPersonNameById(idText)
            If Len(CellText(ws.Cells(c.Row, 17).Value)) = 0 Then ws.Cells(c.Row, 17).Value = "O�񒼐ړ���"
            ws.Cells(c.Row, 18).Value = AppendImportResolutionMemo(ws.Cells(c.Row, 18).Value, "�I��ID�m�F��: " & idText & " / " & Format$(Now, "yyyy/m/d h:nn"))
        Else
            ws.Cells(c.Row, 1).Value = "�I��l��ID����/�Ċm�F"
            ws.Cells(c.Row, 16).Value = ""
            ws.Cells(c.Row, 18).Value = AppendImportResolutionMemo(ws.Cells(c.Row, 18).Value, "�I��l��ID�����ʃf�[�^��Ɍ�����܂���: " & idText)
        End If
    Next c
CleanExit:
    Application.EnableEvents = True
End Sub

Private Sub ApplyImportPersonResolutionChoice(ByVal ws As Worksheet, ByVal rowNo As Long, ByVal selectedId As String, ByVal reasonText As String)
    selectedId = CellText(selectedId)
    If Len(selectedId) = 0 Then Exit Sub
    If Not ImportedPersonIdExists(selectedId) Then
        QuietWarn "�l��ID�����ʃf�[�^��Ɍ�����܂���: " & selectedId, True, "�l�����I��"
        Exit Sub
    End If
    On Error Resume Next
    ws.Unprotect Password:=TOOL_PASSWORD
    On Error GoTo 0
    Application.EnableEvents = False
    ws.Cells(rowNo, 15).Value = selectedId
    ws.Cells(rowNo, 16).Value = ImportedPersonNameById(selectedId)
    ws.Cells(rowNo, 17).Value = reasonText
    ws.Cells(rowNo, 18).Value = AppendImportResolutionMemo(ws.Cells(rowNo, 18).Value, reasonText & ": " & selectedId & " / " & Format$(Now, "yyyy/m/d h:nn"))
    ws.Cells(rowNo, 1).Value = "�蓮�I����/�Ď捞��"
    Application.EnableEvents = True
    AddImportPersonResolutionButtons ws
End Sub


Public Sub ShowImportPersonCandidatePanelForActiveRow()
    If ActiveSheet Is Nothing Then Exit Sub
    If ActiveSheet.Name <> SH_IMPORT_PERSON_RESOLUTION Then
        NotifyInfo "W_�捞�l���ƍ��őΏۍs��I�����Ă�����s���Ă��������B"
        Exit Sub
    End If
    If ActiveCell.Row < 3 Then
        NotifyInfo "���s��I�����Ă��������B"
        Exit Sub
    End If
    ShowImportPersonCandidatePanel ActiveSheet, ActiveCell.Row, CellText(ActiveSheet.Cells(ActiveCell.Row, 7).Value)
End Sub

Public Sub ApplyImportPersonCandidatePanelSelection()
    Dim panel As Worksheet, sourceWs As Worksheet
    Dim sourceRow As Long, selectedId As String
    If ActiveSheet Is Nothing Then Exit Sub
    If ActiveSheet.Name <> SH_IMPORT_PERSON_CAND_PANEL Then
        NotifyInfo "W_�捞�l�����őI������l���s��I��ł��������B"
        Exit Sub
    End If
    Set panel = ActiveSheet
    If ActiveCell.Row < 4 Then
        NotifyInfo "���l���̍s��I�����Ă��������B"
        Exit Sub
    End If
    selectedId = CellText(panel.Cells(ActiveCell.Row, 1).Value)
    sourceRow = CLng(Val(CellText(panel.Range("J1").Value)))
    If sourceRow < 3 Or Len(selectedId) = 0 Then
        QuietWarn "���p�l���̎Q�ƍs���s���ł��BW_�捞�l���ƍ�����ēx�J���Ă��������B", True, "�l�����p�l��"
        Exit Sub
    End If
    Set sourceWs = ThisWorkbook.Worksheets(SH_IMPORT_PERSON_RESOLUTION)
    ApplyImportPersonResolutionChoice sourceWs, sourceRow, selectedId, "���p�l���I��"
    sourceWs.Visible = xlSheetVisible
    sourceWs.Activate
    sourceWs.Cells(sourceRow, 15).Select
    panel.Visible = xlSheetVeryHidden
End Sub

Private Sub ShowImportPersonCandidatePanel(ByVal sourceWs As Worksheet, ByVal sourceRow As Long, ByVal candidateText As String)
    Dim panel As Worksheet, ids As Collection, names As Object
    Dim i As Long, outR As Long, idText As String
    If sourceWs Is Nothing Then Exit Sub
    If sourceRow < 3 Then Exit Sub
    Set ids = ParseImportPersonCandidateIds(candidateText, names)
    If ids.Count = 0 Then Exit Sub
    Set panel = GetOrCreateSheet(SH_IMPORT_PERSON_CAND_PANEL, True)
    panel.Visible = xlSheetVisible
    DeleteImportPersonCandidatePanelButtons panel
    panel.Range("A1:H1").Merge
    panel.Range("A1").Value = "�O���\�l���ƍ� ���I��"
    panel.Range("A1").Font.Bold = True
    panel.Range("A1").Font.Size = 14
    panel.Range("A2").Value = "���s"
    panel.Range("B2").Value = sourceRow
    panel.Range("C2").Value = "�O���\����"
    panel.Range("D2").Value = sourceWs.Cells(sourceRow, 5).Value
    panel.Range("J1").Value = sourceRow
    panel.Range("A3:H3").Value = Array("�l��ID", "�����\��", "����", "�敪", "���N����", "���ݎ���", "������", "�m�F����")
    FormatHeader panel.Range("A3:H3"), ThemeColor("teal")
    outR = 4
    For i = 1 To ids.Count
        idText = CStr(ids(i))
        panel.Cells(outR, 1).Value = idText
        panel.Cells(outR, 2).Value = ImportedPersonNameById(idText)
        panel.Cells(outR, 3).Value = ImportPersonPanelValueById(idText, 3)
        panel.Cells(outR, 4).Value = ImportPersonPanelValueById(idText, 4)
        panel.Cells(outR, 5).Value = ImportPersonPanelValueById(idText, 5)
        panel.Cells(outR, 6).Value = ImportPersonPanelValueById(idText, 10)
        panel.Cells(outR, 7).Value = ImportPersonPanelValueById(idText, 11)
        panel.Cells(outR, 8).Value = "���̍s��I�����Ă���E�̃{�^���B��R�Â��h�~�̂��ߑ����E���ݎ����E���������m�F�B"
        outR = outR + 1
    Next i
    panel.Columns("A:A").ColumnWidth = 14
    panel.Columns("B:B").ColumnWidth = 26
    panel.Columns("C:D").ColumnWidth = 14
    panel.Columns("E:E").ColumnWidth = 13
    panel.Columns("F:G").ColumnWidth = 22
    panel.Columns("H:H").ColumnWidth = 38
    panel.Columns("J:M").ColumnWidth = 15
    panel.Range("A3:H" & CStr(outR - 1)).WrapText = True
    panel.Range("J2:M6").ClearContents
    panel.Range("J2").Value = "����"
    panel.Range("J2").Font.Bold = True
    AddUIButton panel, panel.Range("J3").Left, panel.Range("J3").Top, 154, 28, "���̌���I��", "ApplyImportPersonCandidatePanelSelection", "primary"
    AddUIButton panel, panel.Range("J5").Left, panel.Range("J5").Top, 154, 28, "�ƍ��\�֖߂�", "ShowImportPersonResolutionSheet", "neutral"
    MarkImportPersonCandidatePanelButtons panel
    panel.Activate
    panel.Range("A4").Select
End Sub



Private Function ImportPersonPanelValueById(ByVal personId As String, ByVal colNo As Long) As String
    Dim ws As Worksheet, lastR As Long, r As Long
    personId = CellText(personId)
    If Len(personId) = 0 Then Exit Function
    If Not SheetExists(SH_WORK_PERSON_REF) Then Exit Function
    Set ws = GetSheet(SH_WORK_PERSON_REF)
    lastR = LastRow(ws, 1)
    For r = 2 To lastR
        If CellText(ws.Cells(r, 1).Value) = personId Then
            If colNo = 5 Or colNo = 6 Then
                If IsDate(ws.Cells(r, colNo).Value) Then ImportPersonPanelValueById = Format$(CDate(ws.Cells(r, colNo).Value), "yyyy/m/d") Else ImportPersonPanelValueById = CellText(ws.Cells(r, colNo).Value)
            Else
                ImportPersonPanelValueById = CellText(ws.Cells(r, colNo).Value)
            End If
            Exit Function
        End If
    Next r
End Function

Private Sub DeleteImportPersonCandidatePanelButtons(ByVal ws As Worksheet)
    Dim i As Long
    Dim shp As Shape
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    For i = ws.Shapes.Count To 1 Step -1
        Set shp = ws.Shapes(i)
        If IsImportPersonCandidatePanelButton(shp) Then shp.Delete
    Next i
    On Error GoTo 0
End Sub

Private Function IsImportPersonCandidatePanelButton(ByVal shp As Shape) As Boolean
    Dim macroName As String
    If shp Is Nothing Then Exit Function
    On Error Resume Next
    macroName = CellText(shp.AlternativeText)
    If Len(macroName) = 0 Then macroName = CellText(shp.OnAction)
    On Error GoTo 0
    If Left$(shp.Name, 21) = "btn_import_person_can" Then
        IsImportPersonCandidatePanelButton = True
    ElseIf InStr(1, macroName, "ApplyImportPersonCandidatePanelSelection", vbTextCompare) > 0 _
        Or InStr(1, macroName, "ShowImportPersonResolutionSheet", vbTextCompare) > 0 Then
        IsImportPersonCandidatePanelButton = True
    End If
End Function

Private Sub MarkImportPersonCandidatePanelButtons(ByVal ws As Worksheet)
    Dim shp As Shape
    Dim idx As Long
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    idx = 0
    For Each shp In ws.Shapes
        If IsImportPersonCandidatePanelButton(shp) Then
            idx = idx + 1
            shp.Name = "btn_import_person_candidate_" & CStr(idx)
            shp.PrintObject = False
            shp.Placement = xlMove
            shp.Locked = True
        End If
    Next shp
    On Error GoTo 0
End Sub

Private Function ParseImportPersonCandidateIds(ByVal candidateText As String, ByRef names As Object) As Collection
    Dim ids As Collection, lines As Variant, i As Long, lineText As String, idText As String, nameText As String
    Set ids = New Collection
    Set names = CreateObject("Scripting.Dictionary")
    candidateText = Replace$(candidateText, vbCr, vbLf)
    lines = Split(candidateText, vbLf)
    For i = LBound(lines) To UBound(lines)
        lineText = Trim$(CStr(lines(i)))
        If Left$(lineText, 1) = "�E" Then lineText = Mid$(lineText, 2)
        idText = Trim$(Split(lineText & "/", "/")(0))
        nameText = ""
        If InStr(1, lineText, "/", vbTextCompare) > 0 Then nameText = Trim$(Split(lineText, "/")(1))
        If Len(idText) > 0 And ImportedPersonIdExists(idText) Then
            ids.Add idText
            If Len(nameText) > 0 Then names(idText) = nameText
        End If
    Next i
    Set ParseImportPersonCandidateIds = ids
End Function

Private Function AppendImportResolutionMemo(ByVal oldMemo As Variant, ByVal addMemo As String) As String
    AppendImportResolutionMemo = CellText(oldMemo)
    If Len(AppendImportResolutionMemo) > 0 Then AppendImportResolutionMemo = AppendImportResolutionMemo & vbCrLf
    AppendImportResolutionMemo = AppendImportResolutionMemo & addMemo
End Function

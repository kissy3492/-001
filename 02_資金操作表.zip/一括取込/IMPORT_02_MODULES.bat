@echo off
setlocal
if "%~1"=="" (
  cscript //nologo "%~dp0IMPORT_02_MODULES.vbs"
) else (
  cscript //nologo "%~dp0IMPORT_02_MODULES.vbs" "%~1"
)
echo.
echo Done. Press any key to close.
pause >nul

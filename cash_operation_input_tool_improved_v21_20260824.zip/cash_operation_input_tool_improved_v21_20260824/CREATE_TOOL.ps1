param(
    [string]$OutputPath = ""
)

$ErrorActionPreference = "Stop"
$sourceDir = Split-Path -Parent $MyInvocation.MyCommand.Path
if ([string]::IsNullOrWhiteSpace($OutputPath)) {
    $OutputPath = Join-Path $sourceDir "cash_operation_input_tool.xlsm"
}
$OutputPath = [System.IO.Path]::GetFullPath($OutputPath)
if ([System.IO.File]::Exists($OutputPath)) {
    throw "Output already exists. Move or rename it first: $OutputPath"
}
$setupErrorPath = [System.IO.Path]::ChangeExtension($OutputPath, ".setup_error.txt")
if ([System.IO.File]::Exists($setupErrorPath)) {
    [System.IO.File]::Delete($setupErrorPath)
}

$excel = $null
$workbook = $null
$createdFile = $false
$leaveExcelOpen = $false

try {
    $excel = New-Object -ComObject Excel.Application
    $excel.Visible = $false
    $excel.DisplayAlerts = $false
    # Do not let the injected workbook events run before setup has created its sheets.
    $excel.EnableEvents = $false
    $xlWBATWorksheet = -4167
    $workbook = $excel.Workbooks.Add($xlWBATWorksheet)

    try {
        $vbProject = $workbook.VBProject
        $null = $vbProject.VBComponents.Count
    }
    catch {
        throw "Excel blocked VBA project access. Enable 'Trust access to the VBA project object model', then run CREATE_TOOL.cmd again."
    }

    $moduleFiles = Get-ChildItem -LiteralPath $sourceDir -Filter "*.bas" -File | Sort-Object Name
    if ($moduleFiles.Count -eq 0) {
        throw "No VBA module files were found."
    }
    foreach ($moduleFile in $moduleFiles) {
        $null = $vbProject.VBComponents.Import($moduleFile.FullName)
    }

    $thisWorkbookPath = Join-Path $sourceDir "ThisWorkbook_code.txt"
    if (-not [System.IO.File]::Exists($thisWorkbookPath)) {
        throw "ThisWorkbook_code.txt was not found."
    }
    $thisWorkbookComponent = $vbProject.VBComponents.Item("ThisWorkbook")
    $codeModule = $thisWorkbookComponent.CodeModule
    if ($codeModule.CountOfLines -gt 0) {
        $codeModule.DeleteLines(1, $codeModule.CountOfLines)
    }
    $cp932 = [System.Text.Encoding]::GetEncoding(932)
    $thisWorkbookCode = [System.IO.File]::ReadAllText($thisWorkbookPath, $cp932)
    $codeModule.AddFromString($thisWorkbookCode)

    $xlOpenXmlWorkbookMacroEnabled = 52
    $workbook.SaveAs($OutputPath, $xlOpenXmlWorkbookMacroEnabled)
    $createdFile = $true

    $excel.DisplayAlerts = $true
    $excel.Visible = $true
    $excel.EnableEvents = $true
    $escapedName = $workbook.Name.Replace("'", "''")
    $excel.Run("'$escapedName'!SetupWorkbook")

    $toolReady = $excel.Run("'$escapedName'!RequireToolReady")
    if (-not [System.Convert]::ToBoolean($toolReady)) {
        $setupDetail = $excel.Run("'$escapedName'!GetLastSetupFailureDetail")
        if ([string]::IsNullOrWhiteSpace([string]$setupDetail)) {
            $setupDetail = "Setup did not leave the tool in a ready state."
        }
        throw "Setup failed: $setupDetail"
    }
    $workbook.Save()
    $leaveExcelOpen = $true
    Write-Host "Tool created successfully: $OutputPath"
    Write-Host "Excel remains open. Run the VBA compile command and SelfCheckTool before first use."
    Write-Host "After creation, restore the VBA project access setting according to your organization policy."
}
catch {
    $failureMessage = $_.Exception.Message
    try {
        $utf8WithBom = New-Object System.Text.UTF8Encoding($true)
        [System.IO.File]::WriteAllText($setupErrorPath, $failureMessage, $utf8WithBom)
    }
    catch {}
    if ($null -ne $excel) {
        try { $excel.EnableEvents = $false } catch {}
    }
    if ($null -ne $workbook) {
        try { $workbook.Close($false) } catch {}
    }
    if ($null -ne $excel) {
        try { $excel.Quit() } catch {}
    }
    if ($createdFile -and [System.IO.File]::Exists($OutputPath)) {
        try { [System.IO.File]::Delete($OutputPath) } catch {}
    }
    Write-Error $failureMessage
    exit 1
}
finally {
    if (-not $leaveExcelOpen -and $null -ne $excel) {
        try { $excel.Quit() } catch {}
    }
    if ($null -ne $workbook) {
        try { [void][System.Runtime.InteropServices.Marshal]::ReleaseComObject($workbook) } catch {}
    }
    if ($null -ne $excel) {
        try { [void][System.Runtime.InteropServices.Marshal]::ReleaseComObject($excel) } catch {}
    }
    [GC]::Collect()
    [GC]::WaitForPendingFinalizers()
}

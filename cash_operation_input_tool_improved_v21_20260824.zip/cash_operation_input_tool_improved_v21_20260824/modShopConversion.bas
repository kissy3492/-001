Attribute VB_Name = "modShopConversion"
Option Explicit

Public Sub BuildShopConversionTargetSheet()
    '��������\�ɓo�ꂵ���u�R�[�h�`���̎戵�X�v�������ꗗ������B
    '�ϊ���Ƃ��̂��̂͂��̃V�[�g��ōs���A���f�{�^���������V�[�g�ɒu���B
    Dim errorNumber As Long, errorDescription As String
    Dim outputsWereDirty As Boolean
    If Not RequireToolReady() Then Exit Sub
    If Not RequireInternalStoresSafeForWrite() Then Exit Sub
    If Not EnsureCaseReadyForOutputs(True) Then Exit Sub
    On Error GoTo EH
    outputsWereDirty = OutputsAreDirty()
    AppBegin "�戵�X�ϊ��Ώۂ𐮗���..."
    MarkOutputsDirty
    '�X�V�t���O������ł��A�h�����[�̒��ڕҏW��M�p���������ۊǂ��疈��Đ�������B
    BuildCashOperationSheetCore False
    BuildCashAnalysisViewCore False
    BuildShopConversionTargetSheetCore True
    If Not outputsWereDirty Then MarkOutputsClean
    AppEnd
    MsgBox "�戵�X�ϊ��Ώۂ��쐬���܂����B" & vbCrLf & _
           "�ϊ���戵�X����͂�����A���̃V�[�g�E��́w���͓��e�𔽉f�x�������Ă��������B", vbInformation
    Exit Sub
EH:
    errorNumber = Err.Number: errorDescription = Err.Description
    AppEnd
    MsgBox "�戵�X�ϊ��Ώۂ̍쐬���ɃG���[���������܂����B" & vbCrLf & "Err " & errorNumber & ": " & errorDescription, vbExclamation
End Sub

Public Sub BuildShopConversionTargetSheetCore(Optional ByVal activateAfter As Boolean = False)
    Dim wsOut As Worksheet, wsTarget As Worksheet
    Dim lastR As Long, r As Long, targetR As Long, targetCount As Long, oldLastR As Long, c As Long
    Dim bankName As String, shopText As String, codeText As String, recordType As String, tekiyoText As String
    Dim oldData As Variant, preservedResult As String, preservedStatus As String
    Dim sourceData As Variant, targetData() As Variant, writeData() As Variant
    Dim targetByKey As Object, oldResultByKey As Object, oldStatusByKey As Object
    Dim lookupKey As String, restoreDetail As String
    Dim isTransaction As Boolean, createdAt As Date, resetStarted As Boolean, oldHadConversionRows As Boolean
    Dim errorNumber As Long, errorDescription As String

    On Error GoTo EH
    If Not SheetExists(SH_WORK_CASH) Then Exit Sub
    Set wsOut = GetSheet(SH_WORK_CASH)
    Set wsTarget = GetOrCreateSheet(SH_SHOP_TARGET, False)

    '�Đ������Ă��A���ɓ��͂����u�ϊ���戵�X�v�u�m�F�󋵁v�͋�s��+�R�[�h�P�ʂň����p���B
    oldLastR = LastRow(wsTarget, SHOP_TGT_COL_CODE)
    ValidateShopTargetStoredCells wsTarget, oldLastR
    If oldLastR >= 2 Then
        oldData = wsTarget.Range(wsTarget.Cells(1, 1), _
                                 wsTarget.Cells(oldLastR, SHOP_TGT_LAST_COL)).Value
    End If
    oldHadConversionRows = (LastRow(wsTarget, SHOP_TGT_COL_CODE) >= 2)
    Set targetByKey = CreateObject("Scripting.Dictionary")
    Set oldResultByKey = CreateObject("Scripting.Dictionary")
    Set oldStatusByKey = CreateObject("Scripting.Dictionary")
    targetByKey.CompareMode = vbTextCompare
    oldResultByKey.CompareMode = vbTextCompare
    oldStatusByKey.CompareMode = vbTextCompare
    LoadPreservedShopValues oldData, oldResultByKey, oldStatusByKey

    lastR = LastRow(wsOut, OUT_COL_BANK)
    createdAt = Now

    If lastR >= 2 Then
        sourceData = wsOut.Range(wsOut.Cells(2, 1), wsOut.Cells(lastR, OUT_COL_INPUT_ORDER)).Value2
        ReDim targetData(1 To UBound(sourceData, 1), 1 To SHOP_TGT_LAST_COL)
        For r = 1 To UBound(sourceData, 1)
        bankName = CellText(sourceData(r, OUT_COL_BANK))
        recordType = CellText(sourceData(r, OUT_COL_RECORD_TYPE))
        tekiyoText = CellText(sourceData(r, OUT_COL_TEKIYO))
        isTransaction = False
        If Len(bankName) > 0 Then
            If recordType = RECORD_TRANSACTION Then
                isTransaction = True
            ElseIf Not IsSpecialCashOperationRow(tekiyoText) Then
                If Len(CellText(sourceData(r, OUT_COL_DATE))) > 0 Then isTransaction = True
            End If
        End If
        If isTransaction Then
            shopText = CellText(sourceData(r, OUT_COL_SHOP))
            If IsCodeLikeShop(shopText) Then
                codeText = NormalizeShopCodeText(shopText)
                lookupKey = ShopConversionKey(bankName, codeText)
                If targetByKey.Exists(lookupKey) Then targetR = CLng(targetByKey(lookupKey)) Else targetR = 0

                If targetR = 0 Then
                    targetCount = targetCount + 1
                    If targetCount > wsTarget.Rows.Count - 1 Then _
                        Err.Raise vbObjectError + 4302, "BuildShopConversionTargetSheetCore", _
                                  "�戵�X�ϊ��Ώۂ�Excel�̍s����𒴂��܂��B�Č��𕪊����Ă��������B"
                    targetR = targetCount

                    targetData(targetR, SHOP_TGT_COL_NO) = targetCount
                    targetData(targetR, SHOP_TGT_COL_BANK) = bankName
                    targetData(targetR, SHOP_TGT_COL_CODE) = codeText
                    targetData(targetR, SHOP_TGT_COL_COUNT) = 1
                    targetData(targetR, SHOP_TGT_COL_ROWS) = CStr(r + 1)
                    targetByKey.Add lookupKey, targetR

                    preservedResult = "": preservedStatus = ""
                    If oldResultByKey.Exists(lookupKey) Then preservedResult = CStr(oldResultByKey(lookupKey))
                    If oldStatusByKey.Exists(lookupKey) Then preservedStatus = CStr(oldStatusByKey(lookupKey))
                    targetData(targetR, SHOP_TGT_COL_RESULT) = preservedResult
                    If Len(preservedStatus) > 0 Then
                        targetData(targetR, SHOP_TGT_COL_STATUS) = preservedStatus
                    ElseIf Len(preservedResult) > 0 Then
                        targetData(targetR, SHOP_TGT_COL_STATUS) = "���͍�"
                    Else
                        targetData(targetR, SHOP_TGT_COL_STATUS) = "������"
                    End If
                    targetData(targetR, SHOP_TGT_COL_CREATED) = createdAt
                Else
                    targetData(targetR, SHOP_TGT_COL_COUNT) = CLng(targetData(targetR, SHOP_TGT_COL_COUNT)) + 1
                    targetData(targetR, SHOP_TGT_COL_ROWS) = AppendRowNumber( _
                        CellText(targetData(targetR, SHOP_TGT_COL_ROWS)), r + 1)
                End If
            End If
        End If
        Next r
    End If

    '�����܂Ŋ����ꗗ�ɂ͐G��Ȃ��B�V�ꗗ����������ō��؂��Ă���u��������B
    resetStarted = True
    SetupShopConversionTargetSheet wsTarget
    If targetCount > 0 Then
        ReDim writeData(1 To targetCount, 1 To SHOP_TGT_LAST_COL)
        For r = 1 To targetCount
            For c = 1 To SHOP_TGT_LAST_COL
                writeData(r, c) = targetData(r, c)
            Next c
        Next r
        wsTarget.Range(wsTarget.Cells(2, SHOP_TGT_COL_BANK), _
                       wsTarget.Cells(targetCount + 1, SHOP_TGT_COL_CODE)).NumberFormatLocal = "@"
        wsTarget.Range(wsTarget.Cells(2, SHOP_TGT_COL_ROWS), _
                       wsTarget.Cells(targetCount + 1, SHOP_TGT_COL_STATUS)).NumberFormatLocal = "@"
        wsTarget.Range(wsTarget.Cells(2, 1), _
                       wsTarget.Cells(targetCount + 1, SHOP_TGT_LAST_COL)).Value = writeData
    End If

    FormatShopConversionTargetSheet wsTarget
    wsTarget.Visible = xlSheetVisible
    If activateAfter Then
        wsTarget.Activate
        wsTarget.Range("A1").Select
    End If
    Exit Sub

EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    If resetStarted Then
        On Error Resume Next
        Err.Clear
        SetupShopConversionTargetSheet wsTarget
        If oldHadConversionRows And IsArray(oldData) Then
            wsTarget.Range(wsTarget.Cells(1, 1), _
                           wsTarget.Cells(UBound(oldData, 1), UBound(oldData, 2))).Value = oldData
        End If
        FormatShopConversionTargetSheet wsTarget
        If Err.Number <> 0 Then restoreDetail = " / ���ϊ��ꗗ�̕����G���[: " & Err.Description
        On Error GoTo 0
    End If
    Err.Raise errorNumber, "BuildShopConversionTargetSheetCore", errorDescription & restoreDetail
End Sub

Public Sub ApplyShopConversionToCashOperation()
    Dim errorNumber As Long, errorDescription As String
    Dim outputsWereDirty As Boolean
    If Not RequireToolReady() Then Exit Sub
    If Not RequireInternalStoresSafeForWrite() Then Exit Sub
    If Not EnsureCaseReadyForOutputs(True) Then Exit Sub
    On Error GoTo EH
    outputsWereDirty = OutputsAreDirty()
    AppBegin "�戵�X�𔽉f��..."
    MarkOutputsDirty
    '���f���͔h�����[�̌��ݒl�ł͂Ȃ��A�����ۊǂ���Đ��������l�ɌŒ肷��B
    BuildCashOperationSheetCore False
    '���f���O�ɂ͖���A�������͂������p���őΏۈꗗ���ďW�v����B
    '�X�V�t���O�����Ɉˑ������A��b�\�̎蓮�ύX��Â��ꗗ�ɂ��R�[�h�R����h���B
    BuildShopConversionTargetSheetCore False
    ApplyShopConversionCore True, True
    BuildCashAnalysisViewCore False
    If Not outputsWereDirty Then MarkOutputsClean
    AppEnd
    Exit Sub
EH:
    errorNumber = Err.Number: errorDescription = Err.Description
    AppEnd
    MsgBox "�戵�X���f���ɃG���[���������܂����B" & vbCrLf & "Err " & errorNumber & ": " & errorDescription, vbExclamation
End Sub

Public Sub ApplyShopConversionCore(ByVal activateAfter As Boolean, Optional ByVal showDoneMessage As Boolean = True)
    Dim wsSrc As Worksheet, wsTarget As Worksheet, wsDest As Worksheet
    Dim lastR As Long, r As Long, dataCount As Long
    Dim bankName As String, shopText As String, codeText As String, resultName As String
    Dim recordType As String, tekiyoText As String
    Dim convertedCount As Long, remainedCount As Long
    Dim conversionMap As Object, targetKeys As Object
    Dim targetLastR As Long, targetStatus As String, lookupKey As String
    Dim targetBank As String, targetCode As String
    Dim targetData As Variant, destData As Variant, shopValues() As Variant
    Dim isTransaction As Boolean
    Dim convertedAddress As String, remainedAddress As String
    Dim convertedBatchCount As Long, remainedBatchCount As Long
    Dim errorNumber As Long, errorDescription As String, protectDetail As String
    On Error GoTo EH
    Set wsSrc = GetSheet(SH_WORK_CASH)
    Set wsTarget = GetSheet(SH_SHOP_TARGET)
    Set wsDest = GetOrCreateSheet(SH_OUTPUT_TX_CONVERTED, False)
    Set conversionMap = CreateObject("Scripting.Dictionary")
    conversionMap.CompareMode = vbTextCompare
    Set targetKeys = CreateObject("Scripting.Dictionary")
    targetKeys.CompareMode = vbTextCompare
    targetLastR = LastRow(wsTarget, SHOP_TGT_COL_CODE)
    ValidateShopTargetStoredCells wsTarget, targetLastR
    If targetLastR >= 2 Then
        targetData = wsTarget.Range(wsTarget.Cells(2, 1), _
                                    wsTarget.Cells(targetLastR, SHOP_TGT_LAST_COL)).Value2
        For r = 1 To UBound(targetData, 1)
            targetStatus = CellText(targetData(r, SHOP_TGT_COL_STATUS))
            resultName = CellText(targetData(r, SHOP_TGT_COL_RESULT))
            targetBank = CellText(targetData(r, SHOP_TGT_COL_BANK))
            targetCode = CellText(targetData(r, SHOP_TGT_COL_CODE))
            If Len(targetBank) = 0 Or Len(targetCode) = 0 Then _
                Err.Raise vbObjectError + 4309, "ApplyShopConversionCore", _
                          "�戵�X�ϊ��Ώۂ̋�s���܂��̓R�[�h���󗓂ł��i" & CStr(r + 1) & "�s�j�B"
            lookupKey = ShopConversionKey(targetBank, targetCode)
            If targetKeys.Exists(lookupKey) Then _
                Err.Raise vbObjectError + 4310, "ApplyShopConversionCore", _
                          "�戵�X�ϊ��Ώۂɓ�����s���E�R�[�h���d�����Ă��܂��i" & CStr(r + 1) & "�s�j�B"
            targetKeys.Add lookupKey, True
            If Len(resultName) > 100 Then
                Err.Raise vbObjectError + 4301, "ApplyShopConversionCore", _
                          "�ϊ���戵�X��100�����ȓ��ɂ��Ă��������i" & CStr(r + 1) & "�s�j�B"
            End If
            Select Case targetStatus
                Case "������"
                    '�ϊ�������͂�������͖����͂̂܂܂ł��悢�B���f��ɓ��͍ς֍X�V����B
                Case "���͍�"
                    If Len(resultName) = 0 Then _
                        Err.Raise vbObjectError + 4311, "ApplyShopConversionCore", _
                                  "�m�F�󋵂����͍ςł����A�ϊ���戵�X���󗓂ł��i" & CStr(r + 1) & "�s�j�B"
                Case "�m�F�s�v"
                    If Len(resultName) > 0 Then _
                        Err.Raise vbObjectError + 4312, "ApplyShopConversionCore", _
                                  "�m�F�s�v�̍s�ɕϊ���戵�X�����͂���Ă��܂��i" & CStr(r + 1) & "�s�j�B"
                Case "�ۗ�"
                Case Else
                    Err.Raise vbObjectError + 4313, "ApplyShopConversionCore", _
                              "�m�F�󋵂��s���ł��i" & CStr(r + 1) & "�s�j: " & targetStatus
            End Select
            If Len(resultName) > 0 And targetStatus <> "�ۗ�" And targetStatus <> "�m�F�s�v" Then
                conversionMap(lookupKey) = resultName
            End If
        Next r
    End If

    '�Ώۈꗗ�̌��؂��I����܂ł́A�O��̕ϊ��ςݕ\�������Ȃ��B
    ClearGeneratedOutputSheet wsDest, 21

    lastR = LastUsedRowInSheet(wsSrc)
    If lastR < 1 Then lastR = 1
    wsSrc.Range("A1:Q" & CStr(lastR)).Copy Destination:=wsDest.Range("A1")
    wsDest.Visible = xlSheetVisible
    wsDest.Columns("N:Q").Hidden = True

    lastR = LastUsedRowInSheet(wsDest)
    If lastR >= 2 Then
        destData = wsDest.Range(wsDest.Cells(2, 1), wsDest.Cells(lastR, OUT_COL_INPUT_ORDER)).Value2
        dataCount = UBound(destData, 1)
        ReDim shopValues(1 To dataCount, 1 To 1)
    End If
    For r = 1 To dataCount
        shopValues(r, 1) = destData(r, OUT_COL_SHOP)
        bankName = CellText(destData(r, OUT_COL_BANK))
        recordType = CellText(destData(r, OUT_COL_RECORD_TYPE))
        tekiyoText = CellText(destData(r, OUT_COL_TEKIYO))
        isTransaction = False
        If Len(bankName) > 0 Then
            If recordType = RECORD_TRANSACTION Then
                isTransaction = True
            ElseIf Not IsSpecialCashOperationRow(tekiyoText) Then
                If Len(CellText(destData(r, OUT_COL_DATE))) > 0 Then isTransaction = True
            End If
        End If
        If isTransaction Then
            shopText = CellText(shopValues(r, 1))
            If IsCodeLikeShop(shopText) Then
                codeText = NormalizeShopCodeText(shopText)
                lookupKey = ShopConversionKey(bankName, codeText)
                resultName = ""
                If conversionMap.Exists(lookupKey) Then resultName = CStr(conversionMap(lookupKey))
                If Len(resultName) > 0 Then
                    shopValues(r, 1) = resultName
                    QueueShopCellColor wsDest, r + 1, OUT_COL_SHOP, RGB(204, 251, 241), _
                                       convertedAddress, convertedBatchCount
                    convertedCount = convertedCount + 1
                Else
                    QueueShopCellColor wsDest, r + 1, OUT_COL_SHOP, RGB(254, 240, 138), _
                                       remainedAddress, remainedBatchCount
                    remainedCount = remainedCount + 1
                End If
            End If
        End If
    Next r
    If dataCount > 0 Then
        wsDest.Range(wsDest.Cells(2, OUT_COL_SHOP), wsDest.Cells(lastR, OUT_COL_SHOP)).NumberFormatLocal = "@"
        wsDest.Range(wsDest.Cells(2, OUT_COL_SHOP), wsDest.Cells(lastR, OUT_COL_SHOP)).Value = shopValues
    End If
    FlushShopCellColor wsDest, convertedAddress, convertedBatchCount, RGB(204, 251, 241)
    FlushShopCellColor wsDest, remainedAddress, remainedBatchCount, RGB(254, 240, 138)

    '���̎�������\�͊��ɕ��בւ��ς݂ŁA�戵�X���̒u���͕��я��ɉe�����Ȃ��B
    '�ă\�[�g���Ȃ��A��ʖ��ׂł����f���Ԃ�}����B
    FormatCashOperationOutputLayout wsDest
    SafeFreezeOutputHeader wsDest
    wsDest.Range("E1:E" & CStr(lastR)).NumberFormatLocal = "@"
    wsDest.Range("J1:K" & CStr(lastR)).NumberFormatLocal = "@"
    wsTarget.Unprotect Password:=TOOL_PASSWORD
    UpdateShopTargetStatuses wsTarget
    FormatShopConversionTargetSheet wsTarget

    If activateAfter Then
        wsDest.Activate
        wsDest.Range("A1").Select
    End If
    If showDoneMessage Then
        MsgBox "�戵�X���f�ςݎ�������\���쐬���܂����B" & vbCrLf & _
               "���f�ς�: " & convertedCount & "��" & vbCrLf & _
               "�����́E�����f: " & remainedCount & "��", vbInformation
    End If
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    On Error Resume Next
    If Not wsTarget Is Nothing Then ProtectShopConversionTargetSheet True
    If Err.Number <> 0 Then protectDetail = " / �戵�X�ϊ��Ώۂ̍ĕی�G���[: " & Err.Description
    On Error GoTo 0
    Err.Raise errorNumber, "ApplyShopConversionCore", errorDescription & protectDetail
End Sub

Private Sub ValidateShopTargetStoredCells(ByVal ws As Worksheet, ByVal numberedLastRow As Long)
    '���͋K���͓\��t���ŉ���ł��邽�߁A�ꗗ�S�̂̐����E�G���[�l�����ۂ���B
    'No���艺�ɒl���c��Ǘ��s���A�ꗗ�X�V�Ŗق��ď����Ȃ��B
    Dim searchRange As Range, scanRange As Range, foundCell As Range
    Dim formulaCells As Range, errorCells As Range
    Dim lastAnyRow As Long, allowedLastRow As Long
    If ws Is Nothing Then Exit Sub
    Set searchRange = ws.Range(ws.Cells(1, 1), ws.Cells(ws.Rows.Count, SHOP_TGT_LAST_COL))
    Set foundCell = searchRange.Find(What:="*", After:=searchRange.Cells(1, 1), LookIn:=xlFormulas, _
                                     LookAt:=xlPart, SearchOrder:=xlByRows, SearchDirection:=xlPrevious, _
                                     MatchCase:=False, MatchByte:=False, SearchFormat:=False)
    If Not foundCell Is Nothing Then lastAnyRow = foundCell.Row
    allowedLastRow = CLng(Application.Max(2, numberedLastRow))
    If lastAnyRow > MAX_INTERNAL_STORE_DATA_ROWS + 1 Then
        Err.Raise vbObjectError + 4314, "ValidateShopTargetStoredCells", _
                  "�戵�X�ϊ��Ώۂ����p����𒴂��Ă��܂��B�s�v�Ȏc���s���m�F���Ă��������B"
    End If
    If lastAnyRow > allowedLastRow Then
        Err.Raise vbObjectError + 4315, "ValidateShopTargetStoredCells", _
                  "�戵�X�ϊ��Ώۂ�No���艺�ɌǗ��������͂�����܂��i" & CStr(lastAnyRow) & "�s�܂Łj�B"
    End If
    Set scanRange = ws.Range(ws.Cells(2, 1), ws.Cells(allowedLastRow, SHOP_TGT_LAST_COL))
    On Error Resume Next
    Err.Clear
    Set formulaCells = scanRange.SpecialCells(xlCellTypeFormulas)
    Err.Clear
    Set errorCells = scanRange.SpecialCells(xlCellTypeConstants, xlErrors)
    Err.Clear
    On Error GoTo 0
    If Not formulaCells Is Nothing Then
        Err.Raise vbObjectError + 4316, "ValidateShopTargetStoredCells", _
                  "�戵�X�ϊ��Ώۂɐ���������܂��B�l�Ƃ��ē��͂������Ă�������: " & _
                  formulaCells.Cells(1, 1).Address(False, False)
    End If
    If Not errorCells Is Nothing Then
        Err.Raise vbObjectError + 4317, "ValidateShopTargetStoredCells", _
                  "�戵�X�ϊ��Ώۂ�Excel�G���[�l������܂�: " & _
                  errorCells.Cells(1, 1).Address(False, False)
    End If
End Sub

Private Sub QueueShopCellColor(ByVal ws As Worksheet, ByVal rowNo As Long, ByVal columnNo As Long, _
                               ByVal fillColor As Long, ByRef addressText As String, ByRef batchCount As Long)
    Dim cellAddress As String
    If ws Is Nothing Then Exit Sub
    cellAddress = ws.Cells(rowNo, columnNo).Address(False, False)
    If Len(addressText) > 0 Then addressText = addressText & ","
    addressText = addressText & cellAddress
    batchCount = batchCount + 1
    'Range�Q�ƕ�����̊���������邽�߁A��200�������ƂɈꊇ�K�p����B
    If batchCount >= 40 Or Len(addressText) >= 200 Then _
        FlushShopCellColor ws, addressText, batchCount, fillColor
End Sub

Private Sub FlushShopCellColor(ByVal ws As Worksheet, ByRef addressText As String, _
                               ByRef batchCount As Long, ByVal fillColor As Long)
    If ws Is Nothing Then Exit Sub
    If Len(addressText) = 0 Then Exit Sub
    ws.Range(addressText).Interior.Color = fillColor
    addressText = ""
    batchCount = 0
End Sub

Public Function FillBlankShopWithBranch(ByVal ws As Worksheet) As Long
    Dim lastR As Long, r As Long, dataCount As Long
    Dim branchName As String, bankName As String, recordType As String, tekiyoText As String
    Dim sourceData As Variant, shopValues() As Variant
    Dim isTransaction As Boolean
    If ws Is Nothing Then Exit Function
    lastR = LastRow(ws, OUT_COL_BANK)
    If lastR < 2 Then Exit Function
    sourceData = ws.Range(ws.Cells(2, 1), ws.Cells(lastR, OUT_COL_INPUT_ORDER)).Value2
    dataCount = UBound(sourceData, 1)
    ReDim shopValues(1 To dataCount, 1 To 1)
    For r = 1 To dataCount
        shopValues(r, 1) = sourceData(r, OUT_COL_SHOP)
        bankName = CellText(sourceData(r, OUT_COL_BANK))
        isTransaction = False
        If Len(bankName) > 0 Then
            recordType = CellText(sourceData(r, OUT_COL_RECORD_TYPE))
            tekiyoText = CellText(sourceData(r, OUT_COL_TEKIYO))
            If recordType = RECORD_TRANSACTION Then
                isTransaction = True
            ElseIf Not IsSpecialCashOperationRow(tekiyoText) Then
                If Len(CellText(sourceData(r, OUT_COL_DATE))) > 0 Then isTransaction = True
            End If
        End If
        If isTransaction Then
            If Len(CellText(shopValues(r, 1))) = 0 Then
                branchName = CellText(sourceData(r, OUT_COL_BRANCH))
                If Len(branchName) > 0 Then
                    shopValues(r, 1) = branchName
                    FillBlankShopWithBranch = FillBlankShopWithBranch + 1
                End If
            End If
        End If
    Next r
    ws.Range(ws.Cells(2, OUT_COL_SHOP), ws.Cells(lastR, OUT_COL_SHOP)).NumberFormatLocal = "@"
    ws.Range(ws.Cells(2, OUT_COL_SHOP), ws.Cells(lastR, OUT_COL_SHOP)).Value = shopValues
End Function

Public Sub SetupShopConversionTargetSheet(ByVal ws As Worksheet)
    Dim styleLastRow As Long
    If ws Is Nothing Then Exit Sub
    ResetWorksheet ws

    styleLastRow = 2
    With ws.Range("A1:N" & CStr(styleLastRow))
        .Font.Name = "Yu Gothic UI"
        .Font.Size = 10
        .Interior.Color = RGB(248, 250, 252)
        .Font.Color = RGB(15, 23, 42)
    End With

    SetRowValues ws.Range("A1"), Array("No", "��s��", "�戵�X�R�[�h", "�Y������", "�Y���s�ԍ�", "�ϊ���戵�X", "�m�F��", "�쐬����")
    FormatOutputHeader ws.Range("A1:H1")
    ws.Range("A1:H1").Interior.Color = RGB(37, 99, 235)
    ws.Range("A1:H1").Font.Color = RGB(255, 255, 255)
    ws.Range("A1:H1").Borders.Color = RGB(147, 197, 253)

    ws.Columns("A:A").ColumnWidth = 6
    ws.Columns("B:B").ColumnWidth = 20
    ws.Columns("C:C").ColumnWidth = 15
    ws.Columns("D:D").ColumnWidth = 10
    ws.Columns("E:E").ColumnWidth = 18
    ws.Columns("F:F").ColumnWidth = 26
    ws.Columns("G:G").ColumnWidth = 13
    ws.Columns("H:H").ColumnWidth = 16
    ws.Columns("J:M").ColumnWidth = 12.5

    ws.Range("B1:C" & CStr(styleLastRow)).NumberFormatLocal = "@"
    ws.Range("E1:G" & CStr(styleLastRow)).NumberFormatLocal = "@"
    ws.Range("F2:G" & CStr(styleLastRow)).Interior.Color = RGB(255, 255, 255)
    ws.Range("H1:H" & CStr(styleLastRow)).NumberFormatLocal = "yyyy/m/d h:mm"
    ws.Rows(1).RowHeight = 28
    ws.Rows(1).Font.Bold = True
    ws.Range("F2:F" & CStr(styleLastRow)).Font.Bold = True

    ApplyShopEditValidation ws, styleLastRow
End Sub

Public Sub FormatShopConversionTargetSheet(ByVal ws As Worksheet)
    Dim lastR As Long, formatLastRow As Long
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    ws.Unprotect Password:=TOOL_PASSWORD
    On Error GoTo 0
    lastR = LastRow(ws, SHOP_TGT_COL_CODE)
    formatLastRow = CLng(Application.Max(2, lastR))
    ApplyShopEditValidation ws, CLng(Application.Max(2, lastR))
    On Error Resume Next
    ws.AutoFilterMode = False
    On Error GoTo 0

    If lastR < 2 Then
        ws.Range("A2:H2").UnMerge
        ws.Range("A2").Value = "�ϊ��Ώۂ̎戵�X�R�[�h�͂���܂���B"
        '�ҏW��F:G���܂߂Č�������ƁA�ی쎞�Ɍ����Z���S�̂܂Ń��b�N����������������B
        '�ē��͕ی��A:E�����Ō������A�ҏW��̃��b�N��Ԃ𖾊m�ɕ�������B
        ws.Range("A2:E2").Merge
        ws.Range("A2:E2").Interior.Color = RGB(220, 252, 231)
        ws.Range("A2:E2").Font.Color = RGB(20, 83, 45)
        ws.Range("A2:E2").Font.Bold = True
        ws.Range("A2:E2").HorizontalAlignment = xlCenter
        ws.Range("F2:H2").ClearContents
        ws.Rows(2).RowHeight = 28
    Else
        '��ʑΏۂł�1�s�������ݒ肵�Ȃ��B���͗�̐F������D�悵�A�\�S�̂��ꊇ��������B
        With ws.Range("A2:H" & CStr(lastR))
            .Borders.LineStyle = xlContinuous
            .Borders.Color = RGB(226, 232, 240)
            .Interior.Color = RGB(255, 255, 255)
            .Font.Color = RGB(15, 23, 42)
        End With
        ws.Range("C2:C" & CStr(lastR)).Interior.Color = RGB(239, 246, 255)
        ws.Range("F2:F" & CStr(lastR)).Interior.Color = RGB(236, 253, 245)
        ws.Range("G2:G" & CStr(lastR)).Interior.Color = RGB(254, 249, 195)
        ws.Range("A1:H" & lastR).AutoFilter
    End If

    ws.Range("A1:H" & CStr(formatLastRow)).VerticalAlignment = xlCenter
    ws.Range("A1:E" & CStr(formatLastRow)).HorizontalAlignment = xlCenter
    ws.Range("F1:F" & CStr(formatLastRow)).HorizontalAlignment = xlLeft
    ws.Range("G1:H" & CStr(formatLastRow)).HorizontalAlignment = xlCenter
    ws.Range("E1:F" & CStr(formatLastRow)).WrapText = True
    ws.Range("A1:H1").HorizontalAlignment = xlCenter
    ws.Range("A1:H1").VerticalAlignment = xlCenter
    ws.Rows(1).RowHeight = 32

    AutoFitSheetSmart ws, "A:H", 6, 34
    If ws.Columns("B:B").ColumnWidth < 18 Then ws.Columns("B:B").ColumnWidth = 18
    If ws.Columns("C:C").ColumnWidth < 14 Then ws.Columns("C:C").ColumnWidth = 14
    If ws.Columns("E:E").ColumnWidth < 18 Then ws.Columns("E:E").ColumnWidth = 18
    If ws.Columns("F:F").ColumnWidth < 24 Then ws.Columns("F:F").ColumnWidth = 24
    If ws.Columns("G:G").ColumnWidth < 12 Then ws.Columns("G:G").ColumnWidth = 12
    If ws.Columns("H:H").ColumnWidth < 16 Then ws.Columns("H:H").ColumnWidth = 16

    BuildShopConversionTargetPanel ws
    ws.ScrollArea = "A1:M" & CStr(Application.Max(50, lastR + 20))
    LockToolShapes ws, False
    SafeFreezeSheetAt ws, "A2", 90
    ProtectShopConversionTargetSheet True
End Sub

Public Sub BuildShopConversionTargetPanel(ByVal ws As Worksheet)
    '�戵�X�ϊ��ΏۃV�[�g�̑���J�[�h�B
    '�ꗗA:H�Ɗ����Ȃ��悤�A�E��J:M��2�s�ڈȍ~�ɌŒ�z�u����B
    Dim x As Double, y As Double, w As Double, h As Double
    Dim margin As Double, gap As Double, mainH As Double, btnH As Double, smallW As Double
    Dim lastR As Long, pendingCount As Long, totalCount As Long
    Dim r As Long, values As Variant, statusText As String, resultText As String
    Dim titleShape As Shape, titleText As String
    If ws Is Nothing Then Exit Sub

    DeleteToolShapesVerified ws, False
    On Error Resume Next
    ws.Columns("J:M").ColumnWidth = 12.5
    On Error GoTo 0

    '�s���͎戵�X�ꗗ�̓��͍s�ɂ��e�����邽�߁A�����ł͕ύX���Ȃ��B
    '�p�l���͐}�`�̍������Œ肵�āA�ꗗ�̌��₷����ۂB
    x = ws.Range("J2").Left
    y = ws.Range("J2").Top + 2
    w = ws.Range("J2:M6").Width
    h = 112

    margin = 12
    gap = 8
    mainH = 34
    btnH = 28
    smallW = (w - margin * 2 - gap) / 2

    lastR = LastRow(ws, SHOP_TGT_COL_CODE)
    If lastR >= 2 Then
        totalCount = lastR - 1
        values = ws.Range(ws.Cells(2, SHOP_TGT_COL_RESULT), _
                          ws.Cells(lastR, SHOP_TGT_COL_STATUS)).Value2
        For r = 1 To UBound(values, 1)
            resultText = CellText(values(r, 1))
            statusText = CellText(values(r, 2))
            If statusText <> "�m�F�s�v" And _
               (Len(resultText) = 0 Or statusText = "������" Or Len(statusText) = 0) Then _
                pendingCount = pendingCount + 1
        Next r
    End If

    AddPanelBack ws, x, y, w, h

    '�w�i�}�`�̓Z�����O�ʂɕ`�悳��邽�߁A�Z�������ł͂Ȃ������ȃe�L�X�g�}�`��
    '������\������B�ĕ\�����ɌÂ��Z���������c��Ȃ��悤�A���\�������ɂ���B
    With ws.Range("J2:M2")
        .UnMerge
        .ClearContents
    End With
    titleText = "�m�F�҂� " & CStr(pendingCount) & "���@�^�@�Ώ� " & CStr(totalCount) & "��"
    Set titleShape = ws.Shapes.AddTextbox(msoTextOrientationHorizontal, _
                                          x + margin, y + 4, w - margin * 2, 18)
    With titleShape
        .Name = UI_PREFIX & "shop_panel_title"
        .TextFrame.Characters.Text = titleText
        .TextFrame.HorizontalAlignment = xlHAlignCenter
        .TextFrame.VerticalAlignment = xlVAlignCenter
        .TextFrame.MarginLeft = 2
        .TextFrame.MarginRight = 2
        .TextFrame.MarginTop = 0
        .TextFrame.MarginBottom = 0
        .TextFrame.Characters.Font.Name = "Yu Gothic UI"
        .TextFrame.Characters.Font.Size = 10.5
        .TextFrame.Characters.Font.Bold = True
        .TextFrame.Characters.Font.Color = RGB(30, 64, 175)
        .Fill.Visible = msoFalse
        .Line.Visible = msoFalse
        .Placement = xlMove
        .Locked = True
    End With

    AddUIButton ws, x + margin, y + 26, w - margin * 2, mainH, "���͓��e�𔽉f", "ApplyShopConversionToCashOperation", "hero"
    AddUIButton ws, x + margin, y + 26 + mainH + gap, smallW, btnH, "�ꗗ�X�V", "BuildShopConversionTargetSheet", "tool"
    AddUIButton ws, x + margin + smallW + gap, y + 26 + mainH + gap, smallW, btnH, "���֖͂߂�", "ShowInputSheet", "soft"

    LockToolShapes ws, False
End Sub


Public Sub ProtectShopConversionTargetSheet(Optional ByVal raiseOnError As Boolean = False)
    '�戵�X�ϊ��ΏۃV�[�g�́A�ϊ���戵�X�E�m�F�󋵂������͂ł���΂悢�B
    '�{�^����J�[�h�͕ی삵�āA����Ĉړ��E�T�C�Y�ύX����Ȃ��悤�ɂ���B
    Dim ws As Worksheet, editLastRow As Long, dataLastRow As Long
    Dim workbookWasSaved As Boolean
    Dim errorNumber As Long, errorDescription As String
    If Not SheetExists(SH_SHOP_TARGET) Then Exit Sub
    Set ws = GetSheet(SH_SHOP_TARGET)
    workbookWasSaved = ThisWorkbook.Saved

    On Error GoTo EH
    ws.Unprotect Password:=TOOL_PASSWORD
    RestoreToolSheetScrollArea ws
    dataLastRow = LastRow(ws, SHOP_TGT_COL_CODE)
    editLastRow = CLng(Application.Max(2, dataLastRow))
    If editLastRow > ws.Rows.Count Then editLastRow = ws.Rows.Count
    '�u�b�N�ؑցE�V�[�g�ĕ\���̂��тɑS1,048,576�s�𑖍����Ȃ��B�c�[�����p�͈͂������ă��b�N����B
    ws.Range("A1:N" & CStr(editLastRow)).Locked = True
    If dataLastRow >= 2 Then ws.Range("F2:G" & CStr(dataLastRow)).Locked = False
    LockToolShapes ws
    ws.Protect Password:=TOOL_PASSWORD, DrawingObjects:=True, Contents:=True, Scenarios:=False, _
               UserInterfaceOnly:=True, AllowFiltering:=True, AllowSorting:=False, _
               AllowFormattingCells:=False, AllowFormattingColumns:=False, AllowFormattingRows:=False
    ws.EnableSelection = xlNoRestrictions
    If Not ws.ProtectContents Or Not ws.ProtectDrawingObjects Then _
        Err.Raise vbObjectError + 4306, "ProtectShopConversionTargetSheet", _
                  "�戵�X�ϊ��ΏۃV�[�g��ی�ł��܂���ł����B"
    VerifyToolShapeSecurity ws, True, False
    If workbookWasSaved Then ThisWorkbook.Saved = True
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    EmergencyProtectToolSheet ws
    If workbookWasSaved Then ThisWorkbook.Saved = True
    If raiseOnError Then Err.Raise errorNumber, "ProtectShopConversionTargetSheet", errorDescription
End Sub

Private Sub ApplyShopEditValidation(ByVal ws As Worksheet, ByVal editLastRow As Long)
    If ws Is Nothing Then Exit Sub
    If editLastRow < 2 Then editLastRow = 2
    If editLastRow > ws.Rows.Count Then editLastRow = ws.Rows.Count
    On Error Resume Next
    With ws.Range("F2:F" & CStr(editLastRow)).Validation
        .Delete
        .Add Type:=xlValidateTextLength, AlertStyle:=xlValidAlertStop, Operator:=xlLessEqual, Formula1:="100"
        .IgnoreBlank = True
        .ShowError = True
        .ErrorTitle = "���͕��������m�F���Ă�������"
        .ErrorMessage = "�ϊ���戵�X��100�����ȓ��œ��͂��Ă��������B"
    End With
    With ws.Range("G2:G" & CStr(editLastRow)).Validation
        .Delete
        .Add Type:=xlValidateList, AlertStyle:=xlValidAlertStop, Operator:=xlBetween, _
             Formula1:="������,���͍�,�m�F�s�v,�ۗ�"
        .IgnoreBlank = True
        .InCellDropdown = True
        '��ԗ�͏�������ɒ������邽�߁A�\�L���E�����󔒂����R���͂����Ȃ��B
        .ShowError = True
    End With
    On Error GoTo 0
End Sub

Private Function IsSpecialCashOperationRow(ByVal tekiyoText As String) As Boolean
    If tekiyoText = "�����J�ݓ�" Or tekiyoText = "��������" Then
        IsSpecialCashOperationRow = True
    ElseIf InStr(tekiyoText, "�c��") > 0 Then
        IsSpecialCashOperationRow = True
    End If
End Function

Private Function ShopConversionKey(ByVal bankName As String, ByVal codeText As String) As String
    ShopConversionKey = UCase$(Trim$(bankName)) & Chr$(30) & UCase$(NormalizeShopCodeText(codeText))
End Function

Private Sub LoadPreservedShopValues(ByVal oldData As Variant, ByVal resultByKey As Object, ByVal statusByKey As Object)
    Dim i As Long, bankCol As Long, codeCol As Long, resultCol As Long, statusCol As Long
    Dim keyText As String, bankText As String, codeText As String, resultText As String, statusText As String
    Dim errorNumber As Long, errorDescription As String
    If Not IsArray(oldData) Then Exit Sub
    On Error GoTo EH
    bankCol = OldDataHeaderIndex(oldData, "��s��", 0)
    codeCol = OldDataHeaderIndex(oldData, "�戵�X�R�[�h", 0)
    resultCol = OldDataHeaderIndex(oldData, "�ϊ���戵�X", 0)
    statusCol = OldDataHeaderIndex(oldData, "�m�F��", 0)
    If bankCol = 0 Or codeCol = 0 Or resultCol = 0 Or statusCol = 0 Then _
        Err.Raise vbObjectError + 4303, "LoadPreservedShopValues", _
                  "���戵�X�ϊ��ꗗ�̌��o�����s���ł��B���͍ςݓ��e��ی삷�邽�߈ꗗ�X�V�𒆎~���܂��B"
    For i = LBound(oldData, 1) + 1 To UBound(oldData, 1)
        bankText = CellText(oldData(i, bankCol))
        codeText = CellText(oldData(i, codeCol))
        If Len(bankText) > 0 Or Len(codeText) > 0 Then
            If Len(bankText) = 0 Or Len(codeText) = 0 Then _
                Err.Raise vbObjectError + 4304, "LoadPreservedShopValues", _
                          "���戵�X�ϊ��ꗗ�̋�s���܂��̓R�[�h�������Ă��܂��i" & CStr(i) & "�s�j�B"
            keyText = ShopConversionKey(bankText, codeText)
            If resultByKey.Exists(keyText) Or statusByKey.Exists(keyText) Then _
                Err.Raise vbObjectError + 4305, "LoadPreservedShopValues", _
                          "���戵�X�ϊ��ꗗ�ɓ�����s���E�R�[�h���d�����Ă��܂��i" & CStr(i) & "�s�j�B"
            resultText = CellText(oldData(i, resultCol))
            statusText = CellText(oldData(i, statusCol))
            If Len(resultText) > 100 Then _
                Err.Raise vbObjectError + 4307, "LoadPreservedShopValues", _
                          "���戵�X�ϊ��ꗗ�̕ϊ���戵�X��100�����𒴂��Ă��܂��i" & CStr(i) & "�s�j�B"
            Select Case statusText
                Case "", "������", "���͍�", "�m�F�s�v", "�ۗ�"
                Case Else
                    Err.Raise vbObjectError + 4308, "LoadPreservedShopValues", _
                              "���戵�X�ϊ��ꗗ�̊m�F�󋵂��s���ł��i" & CStr(i) & "�s�j: " & statusText
            End Select
            resultByKey(keyText) = resultText
            statusByKey(keyText) = statusText
        End If
    Next i
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    Err.Raise errorNumber, "LoadPreservedShopValues", errorDescription
End Sub

Private Sub UpdateShopTargetStatuses(ByVal ws As Worksheet)
    Dim lastR As Long, r As Long, dataCount As Long
    Dim currentStatus As String
    Dim sourceData As Variant, statusValues() As Variant
    If ws Is Nothing Then Exit Sub
    lastR = LastRow(ws, SHOP_TGT_COL_CODE)
    If lastR < 2 Then Exit Sub
    sourceData = ws.Range(ws.Cells(2, 1), ws.Cells(lastR, SHOP_TGT_LAST_COL)).Value2
    dataCount = UBound(sourceData, 1)
    ReDim statusValues(1 To dataCount, 1 To 1)
    For r = 1 To dataCount
        currentStatus = CellText(sourceData(r, SHOP_TGT_COL_STATUS))
        If currentStatus = "�ۗ�" Or currentStatus = "�m�F�s�v" Then
            '���p�҂������������f�͎����X�V�ŏ㏑�����Ȃ��B
        ElseIf Len(CellText(sourceData(r, SHOP_TGT_COL_RESULT))) > 0 Then
            currentStatus = "���͍�"
        ElseIf Len(CellText(sourceData(r, SHOP_TGT_COL_CODE))) > 0 Then
            currentStatus = "������"
        End If
        statusValues(r, 1) = currentStatus
    Next r
    ws.Range(ws.Cells(2, SHOP_TGT_COL_STATUS), _
             ws.Cells(lastR, SHOP_TGT_COL_STATUS)).NumberFormatLocal = "@"
    ws.Range(ws.Cells(2, SHOP_TGT_COL_STATUS), _
             ws.Cells(lastR, SHOP_TGT_COL_STATUS)).Value = statusValues
End Sub

Private Function OldDataHeaderIndex(ByVal oldData As Variant, ByVal headerText As String, ByVal fallbackCol As Long) As Long
    Dim j As Long
    On Error GoTo EH
    For j = LBound(oldData, 2) To UBound(oldData, 2)
        If CellText(oldData(LBound(oldData, 1), j)) = headerText Then
            OldDataHeaderIndex = j
            Exit Function
        End If
    Next j
EH:
    If fallbackCol > 0 Then
        OldDataHeaderIndex = fallbackCol
    End If
End Function

Private Function AppendRowNumber(ByVal existingText As String, ByVal rowNo As Long) As String
    Dim candidate As String
    If Len(existingText) = 0 Then
        AppendRowNumber = CStr(rowNo)
    ElseIf InStr(existingText, "�ȍ~�ȗ�") > 0 Then
        AppendRowNumber = existingText
    Else
        candidate = existingText & "," & CStr(rowNo)
        '�s�ԍ��ꗗ�͌����⏕�ɂ����Ȃ��B���啶����𖈉�A������Ɠ񎟓I�ɒx���Ȃ邽�ߑ��߂ɑł��؂�B
        If Len(candidate) > 1000 Then
            AppendRowNumber = existingText & ",�c�i�ȍ~�ȗ��j"
        Else
            AppendRowNumber = candidate
        End If
    End If
End Function

Public Function IsCodeLikeShop(ByVal valueText As String) As Boolean
    Dim s As String
    s = NormalizeShopCodeText(valueText)
    If Len(s) = 0 Then Exit Function
    If ContainsJapaneseChar(s) Then Exit Function
    If Not ContainsDigit(s) Then Exit Function
    If InStr(s, "�x�X") > 0 Or InStr(s, "�{�X") > 0 Then Exit Function
    IsCodeLikeShop = True
End Function

Public Function NormalizeShopCodeText(ByVal valueText As String) As String
    Dim s As String, i As Long, ch As String, code As Long, outText As String
    s = Trim$(CStr(valueText))
    s = Replace(s, "�@", " ")
    s = Trim$(s)
    For i = 1 To Len(s)
        ch = Mid$(s, i, 1)
        code = AscW(ch)
        Select Case code
            Case &HFF10 To &HFF19
                outText = outText & ChrW$(code - &HFEE0)
            Case &HFF21 To &HFF3A
                outText = outText & ChrW$(code - &HFEE0)
            Case &HFF41 To &HFF5A
                outText = outText & UCase$(ChrW$(code - &HFEE0))
            Case &H2010, &H2011, &H2012, &H2013, &H2014, &H2212, &HFF0D
                outText = outText & "-"
            Case 32, 9
                '�󔒂͏��O
            Case Else
                outText = outText & UCase$(ch)
        End Select
    Next i
    NormalizeShopCodeText = outText
End Function

Private Function ContainsDigit(ByVal s As String) As Boolean
    Dim i As Long, code As Long
    For i = 1 To Len(s)
        code = AscW(Mid$(s, i, 1))
        If code >= 48 And code <= 57 Then ContainsDigit = True: Exit Function
    Next i
End Function

Private Function ContainsJapaneseChar(ByVal s As String) As Boolean
    Dim i As Long, code As Long
    For i = 1 To Len(s)
        code = AscW(Mid$(s, i, 1))
        If code < 0 Then code = code + 65536
        If (code >= &H3040 And code <= &H30FF) Or _
           (code >= &H3400 And code <= &H9FFF) Or _
           (code >= &HF900 And code <= &HFAFF) Or _
           (code >= &HFF66 And code <= &HFF9D) Then
            ContainsJapaneseChar = True
            Exit Function
        End If
    Next i
End Function

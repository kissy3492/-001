Attribute VB_Name = "modTransactionAnalysis"
Option Explicit

Private Const ANALYSIS_BUFFER_ROWS As Long = 1000
Private Const ANALYSIS_CHECK_MAX_DETAIL_CHARS As Long = 700000
Private Const ANALYSIS_CONTEXT_TEXT_MAX As Long = 700
Private Const VALIDATION_CHECK_CHUNK_ROWS As Long = 2000
Private mAnalysisRowEvidenceCache As Object
Private mAnalysisInheritanceDate As Variant

Public Function ShiftAnalysisHeaders() As Variant
    ShiftAnalysisHeaders = Array( _
        "�]��", "�X�R�A", "�ƍ��`��", "���n��", "�������x", "�o��", "���z�ƍ�", "���z��", _
        "�o����", "�o������", "�o������", "�o������", "�o����s", "�o���x�X", "�o���Ȗ�", _
        "�o�������ԍ�", "�o���z", "�o���E�v", "������", "��������", "��������", "��������", _
        "������s", "�����x�X", "�����Ȗ�", "���������ԍ�", "�����z", "�����E�v", "���藝�R", _
        "�m�F��", "�m�F����", "���L�[", "�o�����ID", "�������ID")
End Function

Public Function UnknownAnalysisHeaders() As Variant
    UnknownAnalysisHeaders = Array( _
        "�m�F�D��x", "�X�R�A", "�s���敪", "���t", "����", "�������x", "����", "����", _
        "��s", "�x�X", "�Ȗ�", "�����ԍ�", "����", "�o��", "�戵�X", "�@��", "�E�v", _
        "��⌏���i�S/�m�F�ρj", "�ō����]��", "���o���R", "�m�F��", "�m�F����", "�o�^��", _
        "���ID", "����ID", "�m�F�L�[")
End Function

Public Sub SetupTransactionAnalysisSheets(Optional ByVal preserveVisibility As Boolean = False)
    Dim shiftVisible As XlSheetVisibility, flowVisible As XlSheetVisibility
    Dim unknownVisible As XlSheetVisibility
    Dim ws As Worksheet
    Dim errorNumber As Long, errorDescription As String, errorSource As String

    On Error GoTo EH

    If preserveVisibility Then
        shiftVisible = GetSheet(SH_ANALYSIS_SHIFT).Visible
        flowVisible = GetSheet(SH_ANALYSIS_FLOW).Visible
        unknownVisible = GetSheet(SH_ANALYSIS_UNKNOWN).Visible
    End If

    Set ws = GetSheet(SH_ANALYSIS_SHIFT)
    PrepareShiftAnalysisSheet ws
    Set ws = GetSheet(SH_ANALYSIS_FLOW)
    PrepareAdvancedFlowAnalysisSheet ws
    Set ws = GetSheet(SH_ANALYSIS_UNKNOWN)
    PrepareUnknownAnalysisSheet ws
    SetupAnalysisWorkspaceSheets preserveVisibility

    If preserveVisibility Then
        GetSheet(SH_ANALYSIS_SHIFT).Visible = shiftVisible
        GetSheet(SH_ANALYSIS_FLOW).Visible = flowVisible
        GetSheet(SH_ANALYSIS_UNKNOWN).Visible = unknownVisible
    End If
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    On Error Resume Next
    ProtectTransactionAnalysisSheets False
    If SheetExists(SH_WORK_ANALYSIS_GROUP) Then _
        SetSheetVeryHiddenSafe GetSheet(SH_WORK_ANALYSIS_GROUP)
    If preserveVisibility Then
        GetSheet(SH_ANALYSIS_SHIFT).Visible = shiftVisible
        GetSheet(SH_ANALYSIS_FLOW).Visible = flowVisible
        GetSheet(SH_ANALYSIS_UNKNOWN).Visible = unknownVisible
    End If
    On Error GoTo 0
    Err.Raise errorNumber, "SetupTransactionAnalysisSheets", errorSource & " / " & errorDescription
End Sub

Public Sub BuildTransactionAnalysisSheetsCore(ByVal activateAfter As Boolean)
    Dim wsSource As Worksheet, wsShift As Worksheet, wsFlow As Worksheet, wsUnknown As Worksheet
    Dim sourceData As Variant
    Dim withdrawalRows() As Long, depositRows() As Long
    Dim unknownWithdrawalRows() As Long, unknownDepositRows() As Long
    Dim componentWithdrawalRows() As Long, componentDepositRows() As Long
    Dim depositAmounts() As Double, depositSortRows() As Long
    Dim withdrawalCount As Long, depositCount As Long, sourceRowCount As Long
    Dim componentWithdrawalCount As Long, componentDepositCount As Long
    Dim shiftCount As Long, writtenShiftCount As Long, flowCount As Long
    Dim unknownCount As Long, writtenUnknownCount As Long
    Dim unknownWithdrawalCount As Long, unknownDepositCount As Long
    Dim minAmount As Double, unknownMinAmount As Double
    Dim absoluteTolerance As Double, rateTolerance As Double
    Dim dayWindow As Long
    Dim shiftReviews As Object, flowReviews As Object, unknownReviews As Object
    Dim storedReviews As Object
    Dim candidateCountByTx As Object, bestScoreByTx As Object, bestRatingByTx As Object
    Dim confirmedCountByTx As Object, unknownContextByTx As Object
    Dim lastR As Long, r As Long
    Dim detailText As String, settingsSignature As String, unknownSettingsSignature As String
    Dim errorNumber As Long, errorDescription As String

    On Error GoTo EH
    ResetAnalysisEvidenceCache

    '��������\�㕔�ōX�V�����m�F�L�^��������͌��ʂ֖߂��A�����\�Ɠ������Ă���ĕ��͂���B
    SyncCashAnalysisPanelReviewToWorkspace
    SyncAnalysisWorkspaceReviewsToSources
    SyncAnalysisDetailReviewsToSources
    SyncManualFlowReviewsFromAnalysisSheet
    PersistAnalysisReviewsFromCurrentSheets False, "�ĕ��͑O�̊m�F���e��ۑ�"

    If Not ValidateTransactionAnalysisSettings(detailText) Then _
        Err.Raise vbObjectError + 4600, "BuildTransactionAnalysisSheetsCore", detailText

    ReadTransactionAnalysisSettings minAmount, dayWindow, absoluteTolerance, rateTolerance, _
                                    unknownMinAmount
    mAnalysisInheritanceDate = GetCfgDateValue(ROW_CFG_INHERITANCE_DATE)
    settingsSignature = AnalysisSettingsSignature(minAmount, dayWindow, absoluteTolerance, rateTolerance)
    unknownSettingsSignature = AnalysisSettingsSignature(unknownMinAmount, dayWindow, _
                                                         absoluteTolerance, rateTolerance) & _
                               "|SCOPE=UNKNOWN"
    Set wsSource = GetSheet(SH_WORK_TX)
    Set wsShift = GetSheet(SH_ANALYSIS_SHIFT)
    Set wsFlow = GetSheet(SH_ANALYSIS_FLOW)
    Set wsUnknown = GetSheet(SH_ANALYSIS_UNKNOWN)
    EnsureExistingAnalysisReviewBounds wsShift, "�����V�t�g���"
    EnsureExistingAnalysisReviewBounds wsFlow, "�����t���[�ǐ�"
    EnsureExistingAnalysisReviewBounds wsUnknown, "�s�����o��"
    Set shiftReviews = CaptureAnalysisReviews(wsShift, SHIFT_ANALYSIS_STATUS_COL, _
                                               SHIFT_ANALYSIS_MEMO_COL, SHIFT_ANALYSIS_KEY_COL)
    Set flowReviews = CaptureAnalysisReviews(wsFlow, FLOW_ANALYSIS_STATUS_COL, _
                                              FLOW_ANALYSIS_MEMO_COL, FLOW_ANALYSIS_KEY_COL)
    Set unknownReviews = CaptureAnalysisReviews(wsUnknown, UNKNOWN_ANALYSIS_STATUS_COL, _
                                                 UNKNOWN_ANALYSIS_MEMO_COL, UNKNOWN_ANALYSIS_KEY_COL)
    Set storedReviews = CapturePersistentAnalysisReviews()
    Set shiftReviews = MergeStoredAnalysisReviews(shiftReviews, storedReviews)
    Set flowReviews = MergeStoredAnalysisReviews(flowReviews, storedReviews)
    Set unknownReviews = MergeStoredAnalysisReviews(unknownReviews, storedReviews)
    Set candidateCountByTx = CreateObject("Scripting.Dictionary")
    Set bestScoreByTx = CreateObject("Scripting.Dictionary")
    Set bestRatingByTx = CreateObject("Scripting.Dictionary")
    Set confirmedCountByTx = CreateObject("Scripting.Dictionary")
    Set unknownContextByTx = CreateObject("Scripting.Dictionary")
    candidateCountByTx.CompareMode = vbTextCompare
    bestScoreByTx.CompareMode = vbTextCompare
    bestRatingByTx.CompareMode = vbTextCompare
    confirmedCountByTx.CompareMode = vbTextCompare
    unknownContextByTx.CompareMode = vbTextCompare

    lastR = LastUsedRowInSheet(wsSource)
    If lastR >= 2 Then
        If Not ConfirmLargeArrayOperation(lastR - 1, "���[�E���͂̍X�V") Then Err.Raise 18
        sourceData = wsSource.Range(wsSource.Cells(2, 1), _
                                    wsSource.Cells(lastR, WORK_TX_COL_PERSON_ID)).Value2
        sourceRowCount = UBound(sourceData, 1)
        ReDim withdrawalRows(1 To sourceRowCount)
        ReDim depositRows(1 To sourceRowCount)
        ReDim componentWithdrawalRows(1 To sourceRowCount)
        ReDim componentDepositRows(1 To sourceRowCount)
        ReDim unknownWithdrawalRows(1 To sourceRowCount)
        ReDim unknownDepositRows(1 To sourceRowCount)
        ValidateAndIndexAnalysisTransactions sourceData, minAmount, withdrawalRows, withdrawalCount, _
                                             depositRows, depositCount, componentWithdrawalRows, _
                                             componentWithdrawalCount, componentDepositRows, _
                                             componentDepositCount
        FilterAnalysisRowsByMinimum sourceData, componentWithdrawalRows, _
                                    componentWithdrawalCount, False, unknownMinAmount, _
                                    unknownWithdrawalRows, unknownWithdrawalCount
        FilterAnalysisRowsByMinimum sourceData, componentDepositRows, _
                                    componentDepositCount, True, unknownMinAmount, _
                                    unknownDepositRows, unknownDepositCount
        Set unknownContextByTx = BuildUnknownContextIndex(sourceData, componentWithdrawalRows, _
                                                           componentWithdrawalCount, componentDepositRows, _
                                                           componentDepositCount)
    End If

    If depositCount > 0 Then
        ReDim depositAmounts(1 To depositCount)
        ReDim depositSortRows(1 To depositCount)
        For r = 1 To depositCount
            depositSortRows(r) = depositRows(r)
            depositAmounts(r) = CDbl(sourceData(depositRows(r), OUT_COL_DEPOSIT))
        Next r
        If depositCount > 1 Then QuickSortAnalysisAmounts depositAmounts, depositSortRows, 1, depositCount
    End If

    If withdrawalCount > 0 And depositCount > 0 Then
        AppProgress "1��1�̎����V�t�g�������O�m�F���Ă��܂�..."
        ProcessShiftCandidates sourceData, withdrawalRows, withdrawalCount, depositAmounts, _
                               depositSortRows, depositCount, dayWindow, absoluteTolerance, rateTolerance, _
                               settingsSignature, False, Nothing, Nothing, candidateCountByTx, _
                               bestScoreByTx, bestRatingByTx, shiftCount
    End If
    If shiftCount > MAX_ANALYSIS_OUTPUT_ROWS Then _
        Err.Raise vbObjectError + 4601, "BuildTransactionAnalysisSheetsCore", _
                  "�����V�t�g��₪���p����i" & Format$(MAX_ANALYSIS_OUTPUT_ROWS, "#,##0") & _
                  "���j�𒴂��܂��B�Œ���z���グ�邩�A�������E���z�����e�����߂Ă��������B"

    unknownCount = unknownWithdrawalCount + unknownDepositCount
    If unknownCount > MAX_ANALYSIS_OUTPUT_ROWS Then _
        Err.Raise vbObjectError + 4602, "BuildTransactionAnalysisSheetsCore", _
                  "�s�����o���̊m�F�Ώۂ����p����i" & Format$(MAX_ANALYSIS_OUTPUT_ROWS, "#,##0") & _
                  "���j�𒴂��܂��B�s�����o���̍Œ���z���グ�Ă��������B"

    '�����E���Z�E���i�A���́A�S���Ə�����m�肵�Ă��玑���t���[�ǐՕ\��u��������B
    '�����Ō�ⓝ�v�����Z���A�㑱�̕s�����o���\��1��1�ȊO�̊֘A�𔽉f����B
    BuildAdvancedFlowAnalysisSheetCore sourceData, sourceRowCount, withdrawalRows, withdrawalCount, _
                                       depositRows, depositCount, componentWithdrawalRows, _
                                       componentWithdrawalCount, componentDepositRows, _
                                       componentDepositCount, dayWindow, absoluteTolerance, _
                                       rateTolerance, settingsSignature, wsFlow, flowReviews, _
                                       candidateCountByTx, bestScoreByTx, bestRatingByTx, flowCount
    AppendManualFlowAnalysisRecords sourceData, sourceRowCount, wsFlow, flowReviews, _
                                    candidateCountByTx, bestScoreByTx, bestRatingByTx, flowCount
    If flowCount > MAX_ANALYSIS_OUTPUT_ROWS Then _
        Err.Raise vbObjectError + 4605, "BuildTransactionAnalysisSheetsCore", _
                  "�������Ǝ蓮�������킹�������t���[�ǐՂ����p����i" & _
                  Format$(MAX_ANALYSIS_OUTPUT_ROWS, "#,##0") & "���j�𒴂��܂��B"

    '���f�[�^���؁E��������m�F�E�m�F�L�^�̑ޔ����I����Ă���������ʂ�u��������B
    PrepareShiftAnalysisSheet wsShift
    PrepareUnknownAnalysisSheet wsUnknown

    If shiftCount > 0 Then
        AppProgress "1��1�̎����V�t�g���������o���Ă��܂�..."
        ProcessShiftCandidates sourceData, withdrawalRows, withdrawalCount, depositAmounts, _
                               depositSortRows, depositCount, dayWindow, absoluteTolerance, rateTolerance, _
                               settingsSignature, True, wsShift, shiftReviews, candidateCountByTx, _
                               bestScoreByTx, bestRatingByTx, writtenShiftCount
    End If
    If writtenShiftCount <> shiftCount Then _
        Err.Raise vbObjectError + 4603, "BuildTransactionAnalysisSheetsCore", _
                  "�����V�t�g���̎��O�����Əo�͌�������v���܂���B"

    ResolveAnalysisReviewConflicts wsShift, wsFlow
    '�d���m��̎����~�i���蓮���ɂ��y�񂾏ꍇ�A�����ۑ��𓯂���Ԃ֑�����������B
    SyncManualFlowReviewsFromAnalysisSheet
    Set confirmedCountByTx = BuildConfirmedCandidateCountByTransaction(wsShift, wsFlow)

    If unknownCount > 0 Then
        WriteUnknownAnalysis sourceData, unknownWithdrawalRows, unknownWithdrawalCount, _
                             unknownDepositRows, unknownDepositCount, _
                             unknownReviews, candidateCountByTx, confirmedCountByTx, bestRatingByTx, _
                             unknownContextByTx, unknownSettingsSignature, wsUnknown, writtenUnknownCount
    End If
    If writtenUnknownCount <> unknownCount Then _
        Err.Raise vbObjectError + 4604, "BuildTransactionAnalysisSheetsCore", _
                  "�s�����o���̎��O�����Əo�͌�������v���܂���B"

    FinalizeShiftAnalysisSheet wsShift, shiftCount
    FinalizeUnknownAnalysisSheet wsUnknown, unknownCount
    BuildAnalysisWorkspaceCore
    PersistAnalysisReviewsFromCurrentSheets True, vbNullString
    SetSheetVeryHiddenSafe wsShift
    SetSheetVeryHiddenSafe wsFlow
    SetSheetVeryHiddenSafe wsUnknown
    SetSheetVeryHiddenSafe GetSheet(SH_ANALYSIS_RESULT)
    If activateAfter Then BuildCashAnalysisViewCore True
    ResetAnalysisEvidenceCache
    mAnalysisInheritanceDate = Empty
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    On Error Resume Next
    ResetAnalysisEvidenceCache
    mAnalysisInheritanceDate = Empty
    ProtectTransactionAnalysisSheets False
    If SheetExists(SH_WORK_ANALYSIS_GROUP) Then _
        SetSheetVeryHiddenSafe GetSheet(SH_WORK_ANALYSIS_GROUP)
    On Error GoTo 0
    Err.Raise errorNumber, "BuildTransactionAnalysisSheetsCore", errorDescription
End Sub

Public Function ValidateTransactionAnalysisSettings(ByRef detailText As String) As Boolean
    Dim ws As Worksheet
    Dim minAmount As Double, unknownMinAmount As Double
    Dim absoluteTolerance As Double, rateTolerance As Double
    Dim dayValue As Double
    Dim rateOK As Boolean
    Dim problems As String

    If Not SheetExists(SH_CONFIG) Then
        detailText = "�ݒ�V�[�g������܂���B"
        Exit Function
    End If
    Set ws = GetSheet(SH_CONFIG)
    If ws.Cells(ROW_CFG_ANALYSIS_MIN_AMOUNT, COL_CFG_ANALYSIS_VALUE).HasFormula Or _
       ws.Cells(ROW_CFG_ANALYSIS_DAY_WINDOW, COL_CFG_ANALYSIS_VALUE).HasFormula Or _
       ws.Cells(ROW_CFG_ANALYSIS_ABS_TOLERANCE, COL_CFG_ANALYSIS_VALUE).HasFormula Or _
       ws.Cells(ROW_CFG_ANALYSIS_RATE_TOLERANCE, COL_CFG_ANALYSIS_VALUE).HasFormula Or _
       ws.Cells(ROW_CFG_ANALYSIS_UNKNOWN_MIN, COL_CFG_ANALYSIS_VALUE).HasFormula Then _
        problems = problems & "���͏����ɂ͐������g�p�ł��܂���B "
    If Not TryReadAnalysisNumber(ws.Cells(ROW_CFG_ANALYSIS_MIN_AMOUNT, COL_CFG_ANALYSIS_VALUE).Value, _
                                 minAmount) Or minAmount < 0 Or minAmount > MAX_ABS_AMOUNT Then _
        problems = problems & "�V�t�g�E�t���[�̍Œ���z��0�`" & Format$(MAX_ABS_AMOUNT, "#,##0") & "�Ŏw�肵�Ă��������B "
    If Not TryReadAnalysisNumber(ws.Cells(ROW_CFG_ANALYSIS_UNKNOWN_MIN, COL_CFG_ANALYSIS_VALUE).Value, _
                                 unknownMinAmount) Or unknownMinAmount < 0 Or _
                                 unknownMinAmount > MAX_ABS_AMOUNT Then _
        problems = problems & "�s�����o���̍Œ���z��0�`" & _
                   Format$(MAX_ABS_AMOUNT, "#,##0") & "�Ŏw�肵�Ă��������B "
    If Not TryReadAnalysisNumber(ws.Cells(ROW_CFG_ANALYSIS_DAY_WINDOW, COL_CFG_ANALYSIS_VALUE).Value, _
                                 dayValue) Or dayValue <> Fix(dayValue) Or dayValue < 0 Or dayValue > 365 Then _
        problems = problems & "�V�t�g���̓�������0�`365�̐����Ŏw�肵�Ă��������B "
    If Not TryReadAnalysisNumber(ws.Cells(ROW_CFG_ANALYSIS_ABS_TOLERANCE, COL_CFG_ANALYSIS_VALUE).Value, _
                                 absoluteTolerance) Or absoluteTolerance < 0 Or absoluteTolerance > MAX_ABS_AMOUNT Then _
        problems = problems & "���z���̋��e�z��0�`" & Format$(MAX_ABS_AMOUNT, "#,##0") & "�Ŏw�肵�Ă��������B "
    rateOK = TryReadAnalysisRatePercent( _
        ws.Cells(ROW_CFG_ANALYSIS_RATE_TOLERANCE, COL_CFG_ANALYSIS_VALUE), rateTolerance)
    If Not rateOK Or rateTolerance < 0 Or rateTolerance > 100 Then _
        problems = problems & "���z���̋��e����0�`100%�Ŏw�肵�Ă��������B "

    detailText = Trim$(problems)
    ValidateTransactionAnalysisSettings = (Len(detailText) = 0)
End Function

Public Function IsAnalysisReviewStatus(ByVal statusText As String) As Boolean
    Select Case Trim$(statusText)
        Case ANALYSIS_STATUS_UNREVIEWED, ANALYSIS_STATUS_SHIFT_CONFIRMED, _
             ANALYSIS_STATUS_SOURCE_CONFIRMED, ANALYSIS_STATUS_USE_CONFIRMED, _
             ANALYSIS_STATUS_EXCLUDED, ANALYSIS_STATUS_FOLLOWUP
            IsAnalysisReviewStatus = True
    End Select
End Function

Public Sub ProtectTransactionAnalysisSheets(Optional ByVal raiseOnError As Boolean = False)
    Dim sheetNames As Variant, item As Variant
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    sheetNames = Array(SH_ANALYSIS_SHIFT, SH_ANALYSIS_FLOW, SH_ANALYSIS_UNKNOWN, _
                       SH_ANALYSIS_RESULT, SH_ANALYSIS_DETAIL, SH_BALANCE_RECONCILIATION)
    '�ŏ��̃V�[�g�Ŏ��s���Ă��c���K���ĕی삷��B�ŏ��̌���������ێ����A
    '���i�ďo���ł͑S�V�[�g����������ɍ�Raise����B
    For Each item In sheetNames
        If SheetExists(CStr(item)) Then
            On Error Resume Next
            Err.Clear
            ProtectSingleAnalysisSheet GetSheet(CStr(item))
            If Err.Number <> 0 And errorNumber = 0 Then
                errorNumber = Err.Number
                errorDescription = Err.Description
                errorSource = Err.Source
            End If
            Err.Clear
            On Error GoTo 0
        End If
    Next item
    If raiseOnError And errorNumber <> 0 Then _
        Err.Raise errorNumber, "ProtectTransactionAnalysisSheets", _
                  errorSource & " / " & errorDescription
End Sub

Public Sub FormatTransactionAnalysisSheets()
    Dim shiftCount As Long, flowCount As Long, unknownCount As Long
    Dim shiftVisible As XlSheetVisibility, flowVisible As XlSheetVisibility
    Dim unknownVisible As XlSheetVisibility
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    On Error GoTo EH
    If SheetExists(SH_ANALYSIS_SHIFT) Then
        shiftVisible = GetSheet(SH_ANALYSIS_SHIFT).Visible
        shiftCount = Application.Max(0, LastUsedRowInSheet(GetSheet(SH_ANALYSIS_SHIFT)) - 1)
        FinalizeShiftAnalysisSheet GetSheet(SH_ANALYSIS_SHIFT), shiftCount
        GetSheet(SH_ANALYSIS_SHIFT).Visible = shiftVisible
    End If
    If SheetExists(SH_ANALYSIS_FLOW) Then
        flowVisible = GetSheet(SH_ANALYSIS_FLOW).Visible
        flowCount = Application.Max(0, LastUsedRowInSheet(GetSheet(SH_ANALYSIS_FLOW)) - 1)
        FinalizeAdvancedFlowAnalysisSheet GetSheet(SH_ANALYSIS_FLOW), flowCount
        GetSheet(SH_ANALYSIS_FLOW).Visible = flowVisible
    End If
    If SheetExists(SH_ANALYSIS_UNKNOWN) Then
        unknownVisible = GetSheet(SH_ANALYSIS_UNKNOWN).Visible
        unknownCount = Application.Max(0, LastUsedRowInSheet(GetSheet(SH_ANALYSIS_UNKNOWN)) - 1)
        FinalizeUnknownAnalysisSheet GetSheet(SH_ANALYSIS_UNKNOWN), unknownCount
        GetSheet(SH_ANALYSIS_UNKNOWN).Visible = unknownVisible
    End If
    If SheetExists(SH_ANALYSIS_RESULT) Then FormatAnalysisWorkspaceSheets
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    On Error Resume Next
    ProtectTransactionAnalysisSheets False
    On Error GoTo 0
    Err.Raise errorNumber, "FormatTransactionAnalysisSheets", errorSource & " / " & errorDescription
End Sub

Public Sub CheckTransactionAnalysisSheets(ByRef problems As String)
    CheckSingleAnalysisSheet GetSheet(SH_ANALYSIS_SHIFT), SHIFT_ANALYSIS_STATUS_COL, _
                             SHIFT_ANALYSIS_MEMO_COL, SHIFT_ANALYSIS_KEY_COL, "�����V�t�g���", problems
    CheckSingleAnalysisSheet GetSheet(SH_ANALYSIS_FLOW), FLOW_ANALYSIS_STATUS_COL, _
                             FLOW_ANALYSIS_MEMO_COL, FLOW_ANALYSIS_KEY_COL, "�����t���[�ǐ�", problems
    CheckSingleAnalysisSheet GetSheet(SH_ANALYSIS_UNKNOWN), UNKNOWN_ANALYSIS_STATUS_COL, _
                             UNKNOWN_ANALYSIS_MEMO_COL, UNKNOWN_ANALYSIS_KEY_COL, "�s�����o��", problems
    CheckAnalysisReviewConflicts GetSheet(SH_ANALYSIS_SHIFT), GetSheet(SH_ANALYSIS_FLOW), problems
    CheckAnalysisWorkspace problems
End Sub

Private Sub ReadTransactionAnalysisSettings(ByRef minAmount As Double, ByRef dayWindow As Long, _
                                            ByRef absoluteTolerance As Double, _
                                            ByRef rateTolerance As Double, _
                                            ByRef unknownMinAmount As Double)
    Dim ws As Worksheet
    Set ws = GetSheet(SH_CONFIG)
    minAmount = CDbl(ws.Cells(ROW_CFG_ANALYSIS_MIN_AMOUNT, COL_CFG_ANALYSIS_VALUE).Value)
    dayWindow = CLng(ws.Cells(ROW_CFG_ANALYSIS_DAY_WINDOW, COL_CFG_ANALYSIS_VALUE).Value)
    absoluteTolerance = CDbl(ws.Cells(ROW_CFG_ANALYSIS_ABS_TOLERANCE, COL_CFG_ANALYSIS_VALUE).Value)
    unknownMinAmount = CDbl(ws.Cells(ROW_CFG_ANALYSIS_UNKNOWN_MIN, COL_CFG_ANALYSIS_VALUE).Value)
    If Not TryReadAnalysisRatePercent( _
        ws.Cells(ROW_CFG_ANALYSIS_RATE_TOLERANCE, COL_CFG_ANALYSIS_VALUE), rateTolerance) Then _
        Err.Raise vbObjectError + 4624, "ReadTransactionAnalysisSettings", _
                  "���z���̋��e����ǂݎ��܂���B"
End Sub

Private Sub FilterAnalysisRowsByMinimum(ByRef sourceData As Variant, ByRef sourceRows() As Long, _
                                        ByVal sourceCount As Long, ByVal isDeposit As Boolean, _
                                        ByVal minimumAmount As Double, ByRef filteredRows() As Long, _
                                        ByRef filteredCount As Long)
    Dim i As Long, sourceRow As Long, amountColumn As Long
    If isDeposit Then amountColumn = OUT_COL_DEPOSIT Else amountColumn = OUT_COL_WITHDRAW
    For i = 1 To sourceCount
        sourceRow = sourceRows(i)
        If CDbl(sourceData(sourceRow, amountColumn)) >= minimumAmount Then
            filteredCount = filteredCount + 1
            filteredRows(filteredCount) = sourceRow
        End If
    Next i
End Sub

Private Function TryReadAnalysisRatePercent(ByVal rateCell As Range, _
                                            ByRef ratePercentOut As Double) As Boolean
    Dim rawRate As Double
    Dim formatText As String, valueText As String
    If rateCell Is Nothing Then Exit Function
    valueText = Replace(CellText(rateCell.Value), "��", "%")
    If Right$(valueText, 1) = "%" Then
        valueText = Trim$(Left$(valueText, Len(valueText) - 1))
        If Not TryReadAnalysisNumber(valueText, rawRate) Then Exit Function
        ratePercentOut = rawRate
        TryReadAnalysisRatePercent = True
        Exit Function
    End If
    If Not TryReadAnalysisNumber(rateCell.Value, rawRate) Then Exit Function
    '�u3�v��Excel�S���������́u3%�v�i�����l0.03�j�̂ǂ����3%�Ƃ��Ĉ����B
    formatText = CellText(rateCell.NumberFormat) & CellText(rateCell.NumberFormatLocal)
    If InStr(1, formatText, "%", vbBinaryCompare) > 0 Then rawRate = rawRate * 100#
    ratePercentOut = rawRate
    TryReadAnalysisRatePercent = True
End Function

Public Sub EnsureExistingAnalysisReviewBounds(ByVal ws As Worksheet, ByVal labelText As String)
    Dim lastR As Long
    If ws Is Nothing Then Exit Sub
    lastR = LastUsedRowInSheet(ws)
    If lastR > MAX_ANALYSIS_OUTPUT_ROWS + 1 Then _
        Err.Raise vbObjectError + 4623, "EnsureExistingAnalysisReviewBounds", _
                  labelText & "�̊����s�����p����𒴂��Ă��܂��B" & _
                  "�m�F�L�^��ی삷�邽�߁A�Đ����O�ɃZ���t�`�F�b�N�ŕs�v�s���m�F���Ă��������B"
End Sub

Private Function TryReadAnalysisNumber(ByVal valueIn As Variant, ByRef numberOut As Double) As Boolean
    On Error GoTo EH
    If IsError(valueIn) Then Exit Function
    If VarType(valueIn) = vbBoolean Then Exit Function
    If Not HasText(valueIn) Then Exit Function
    If Not IsNumeric(valueIn) Then Exit Function
    numberOut = CDbl(valueIn)
    If numberOut <> numberOut Then Exit Function
    TryReadAnalysisNumber = True
    Exit Function
EH:
    TryReadAnalysisNumber = False
End Function

Private Function IsValidAnalysisAmountValue(ByVal valueIn As Variant) As Boolean
    If IsError(valueIn) Then Exit Function
    If IsNull(valueIn) Then Exit Function
    If IsEmpty(valueIn) Then Exit Function
    If VarType(valueIn) = vbBoolean Then Exit Function
    If Not IsNumeric(valueIn) Then Exit Function
    IsValidAnalysisAmountValue = True
End Function

Private Sub ValidateAndIndexAnalysisTransactions(ByRef sourceData As Variant, ByVal minAmount As Double, _
                                                 ByRef withdrawalRows() As Long, ByRef withdrawalCount As Long, _
                                                 ByRef depositRows() As Long, ByRef depositCount As Long, _
                                                 ByRef componentWithdrawalRows() As Long, _
                                                 ByRef componentWithdrawalCount As Long, _
                                                 ByRef componentDepositRows() As Long, _
                                                 ByRef componentDepositCount As Long)
    Dim r As Long
    Dim withdrawalAmount As Double, depositAmount As Double
    Dim hasWithdrawal As Boolean, hasDeposit As Boolean
    Dim timeOK As Boolean, normalizedTime As Variant
    Dim dateOK As Boolean, normalizedDate As Variant
    Dim txID As String, accountID As String
    Dim seenTransactionIDs As Object
    Set seenTransactionIDs = CreateObject("Scripting.Dictionary")
    seenTransactionIDs.CompareMode = vbTextCompare

    For r = 1 To UBound(sourceData, 1)
        If CellText(sourceData(r, WORK_TX_COL_RECORD_TYPE)) = RECORD_TRANSACTION Then
            dateOK = False
            normalizedDate = NormalizeDateOnlyValue(sourceData(r, OUT_COL_DATE), dateOK)
            If Not dateOK Then _
                Err.Raise vbObjectError + 4605, "ValidateAndIndexAnalysisTransactions", _
                          "W_��� " & CStr(r + 1) & "�s�ڂ̓��t���s���ł��B"
            If Abs(CDbl(CDate(sourceData(r, OUT_COL_DATE))) - CDbl(CDate(normalizedDate))) > 0.0000001 Then _
                Err.Raise vbObjectError + 4620, "ValidateAndIndexAnalysisTransactions", _
                          "W_��� " & CStr(r + 1) & "�s�ڂ̓��t��Ɏ������������Ă��܂��B"
            If HasText(sourceData(r, OUT_COL_TIME)) Then
                timeOK = False
                normalizedTime = NormalizeTimeInput(sourceData(r, OUT_COL_TIME), timeOK)
                If Not timeOK Then _
                    Err.Raise vbObjectError + 4606, "ValidateAndIndexAnalysisTransactions", _
                              "W_��� " & CStr(r + 1) & "�s�ڂ̎������s���ł��B"
            End If

            hasWithdrawal = HasText(sourceData(r, OUT_COL_WITHDRAW))
            hasDeposit = HasText(sourceData(r, OUT_COL_DEPOSIT))
            If hasWithdrawal And hasDeposit Then _
                Err.Raise vbObjectError + 4607, "ValidateAndIndexAnalysisTransactions", _
                          "W_��� " & CStr(r + 1) & "�s�ڂɏo���Ɠ������������͂���Ă��܂��B"
            If hasWithdrawal Then
                If Not IsValidAnalysisAmountValue(sourceData(r, OUT_COL_WITHDRAW)) Then _
                    Err.Raise vbObjectError + 4608, "ValidateAndIndexAnalysisTransactions", _
                              "W_��� " & CStr(r + 1) & "�s�ڂ̏o���z���s���ł��B"
                withdrawalAmount = CDbl(sourceData(r, OUT_COL_WITHDRAW))
                If withdrawalAmount < 0 Or withdrawalAmount > MAX_ABS_AMOUNT Then _
                    Err.Raise vbObjectError + 4609, "ValidateAndIndexAnalysisTransactions", _
                              "W_��� " & CStr(r + 1) & "�s�ڂ̏o���z���͈͊O�ł��B"
            Else
                withdrawalAmount = 0
            End If
            If hasDeposit Then
                If Not IsValidAnalysisAmountValue(sourceData(r, OUT_COL_DEPOSIT)) Then _
                    Err.Raise vbObjectError + 4610, "ValidateAndIndexAnalysisTransactions", _
                              "W_��� " & CStr(r + 1) & "�s�ڂ̓����z���s���ł��B"
                depositAmount = CDbl(sourceData(r, OUT_COL_DEPOSIT))
                If depositAmount < 0 Or depositAmount > MAX_ABS_AMOUNT Then _
                    Err.Raise vbObjectError + 4611, "ValidateAndIndexAnalysisTransactions", _
                              "W_��� " & CStr(r + 1) & "�s�ڂ̓����z���͈͊O�ł��B"
            Else
                depositAmount = 0
            End If

            If withdrawalAmount > 0 Or depositAmount > 0 Then
                txID = CellText(sourceData(r, WORK_TX_COL_TRANSACTION_ID))
                accountID = CellText(sourceData(r, WORK_TX_COL_ACCOUNT_ID))
                If Len(txID) = 0 Or Len(accountID) = 0 Then _
                    Err.Raise vbObjectError + 4612, "ValidateAndIndexAnalysisTransactions", _
                              "W_��� " & CStr(r + 1) & "�s�ڂ̎��ID�܂��͌���ID������܂���B"
                If seenTransactionIDs.Exists(txID) Then _
                    Err.Raise vbObjectError + 4618, "ValidateAndIndexAnalysisTransactions", _
                              "W_����̎��ID���d�����Ă��܂�: " & txID
                seenTransactionIDs.Add txID, True
            End If
            If withdrawalAmount > 0 Then
                componentWithdrawalCount = componentWithdrawalCount + 1
                componentWithdrawalRows(componentWithdrawalCount) = r
                If withdrawalAmount >= minAmount Then
                    withdrawalCount = withdrawalCount + 1
                    withdrawalRows(withdrawalCount) = r
                End If
            ElseIf depositAmount > 0 Then
                componentDepositCount = componentDepositCount + 1
                componentDepositRows(componentDepositCount) = r
                If depositAmount >= minAmount Then
                    depositCount = depositCount + 1
                    depositRows(depositCount) = r
                End If
            End If
        End If
    Next r
End Sub

Private Sub ProcessShiftCandidates(ByRef sourceData As Variant, ByRef withdrawalRows() As Long, _
                                   ByVal withdrawalCount As Long, ByRef depositAmounts() As Double, _
                                   ByRef depositSortRows() As Long, ByVal depositCount As Long, _
                                   ByVal dayWindow As Long, ByVal absoluteTolerance As Double, _
                                   ByVal rateTolerance As Double, ByVal settingsSignature As String, _
                                   ByVal writeOutput As Boolean, _
                                   ByVal wsOut As Worksheet, ByVal reviews As Object, _
                                   ByVal candidateCountByTx As Object, ByVal bestScoreByTx As Object, _
                                   ByVal bestRatingByTx As Object, ByRef candidateTotal As Long)
    Dim i As Long, j As Long, firstMatch As Long, lastMatch As Long
    Dim withdrawalRow As Long, depositRow As Long
    Dim withdrawalAmount As Double, depositAmount As Double
    Dim lowerAmount As Double, upperAmount As Double, differenceAmount As Double
    Dim allowedDifference As Double
    Dim buffer() As Variant, bufferCount As Long, nextOutputRow As Long
    Dim chronology As String, timePrecision As String, elapsedText As String
    Dim amountMatch As String, reasonText As String, ratingText As String
    Dim score As Long, candidateKey As String
    Dim withdrawalTxID As String, depositTxID As String, evidenceDigest As String
    Dim ambiguityCount As Long

    candidateTotal = 0
    If writeOutput Then
        If wsOut Is Nothing Then Err.Raise vbObjectError + 4613, "ProcessShiftCandidates", "�o�͐悪����܂���B"
        ReDim buffer(1 To ANALYSIS_BUFFER_ROWS, 1 To SHIFT_ANALYSIS_LAST_COL)
        nextOutputRow = 2
    End If

    For i = 1 To withdrawalCount
        If i Mod 512 = 0 Then AppProgress "�����V�t�g�����ƍ����Ă��܂�...", i, withdrawalCount
        withdrawalRow = withdrawalRows(i)
        withdrawalAmount = CDbl(sourceData(withdrawalRow, OUT_COL_WITHDRAW))
        AnalysisAmountSearchBounds withdrawalAmount, absoluteTolerance, rateTolerance, lowerAmount, upperAmount
        firstMatch = LowerBoundAnalysisAmount(depositAmounts, depositCount, lowerAmount)
        lastMatch = UpperBoundAnalysisAmount(depositAmounts, depositCount, upperAmount)
        If firstMatch <= lastMatch Then
            For j = firstMatch To lastMatch
                depositRow = depositSortRows(j)
                depositAmount = CDbl(sourceData(depositRow, OUT_COL_DEPOSIT))
                differenceAmount = Abs(withdrawalAmount - depositAmount)
                allowedDifference = AnalysisAllowedDifference(withdrawalAmount, depositAmount, _
                                                               absoluteTolerance, rateTolerance)
                If differenceAmount <= allowedDifference + 0.0000001 Then
                    If IsShiftPairEligible(sourceData, withdrawalRow, depositRow, dayWindow) Then
                        EvaluateShiftPair sourceData, withdrawalRow, depositRow, absoluteTolerance, _
                                          chronology, timePrecision, elapsedText, amountMatch, _
                                          reasonText, score, ratingText
                        candidateTotal = candidateTotal + 1
                        If candidateTotal > MAX_ANALYSIS_OUTPUT_ROWS Then Exit Sub
                        withdrawalTxID = CellText(sourceData(withdrawalRow, WORK_TX_COL_TRANSACTION_ID))
                        depositTxID = CellText(sourceData(depositRow, WORK_TX_COL_TRANSACTION_ID))
                        candidateKey = withdrawalTxID & ">" & depositTxID
                        If writeOutput Then
                            ambiguityCount = AnalysisMaximumCandidateCount(candidateCountByTx, _
                                             withdrawalTxID & ";" & depositTxID)
                            evidenceDigest = AnalysisEvidenceDigest(sourceData, _
                                CStr(withdrawalRow) & ";" & CStr(depositRow), _
                                "SHIFT|" & settingsSignature & "|AMB=" & CStr(ambiguityCount))
                            bufferCount = bufferCount + 1
                            FillShiftAnalysisRow buffer, bufferCount, sourceData, withdrawalRow, depositRow, _
                                                 differenceAmount, chronology, timePrecision, elapsedText, _
                                                 amountMatch, reasonText, score, ratingText, candidateKey, _
                                                 evidenceDigest, reviews, candidateCountByTx
                            If bufferCount = ANALYSIS_BUFFER_ROWS Then
                                FlushAnalysisBuffer wsOut, buffer, bufferCount, nextOutputRow, SHIFT_ANALYSIS_LAST_COL
                                ReDim buffer(1 To ANALYSIS_BUFFER_ROWS, 1 To SHIFT_ANALYSIS_LAST_COL)
                                bufferCount = 0
                            End If
                        Else
                            UpdateShiftCandidateStats candidateCountByTx, bestScoreByTx, bestRatingByTx, _
                                                      withdrawalTxID, score, ratingText
                            UpdateShiftCandidateStats candidateCountByTx, bestScoreByTx, bestRatingByTx, _
                                                      depositTxID, score, ratingText
                        End If
                    End If
                End If
            Next j
        End If
    Next i
    If writeOutput And bufferCount > 0 Then _
        FlushAnalysisBuffer wsOut, buffer, bufferCount, nextOutputRow, SHIFT_ANALYSIS_LAST_COL
End Sub

Private Function IsShiftPairEligible(ByRef sourceData As Variant, ByVal withdrawalRow As Long, _
                                     ByVal depositRow As Long, ByVal dayWindow As Long) As Boolean
    Dim withdrawalAccountID As String, depositAccountID As String
    Dim withdrawalDate As Long, depositDate As Long
    withdrawalAccountID = CellText(sourceData(withdrawalRow, WORK_TX_COL_ACCOUNT_ID))
    depositAccountID = CellText(sourceData(depositRow, WORK_TX_COL_ACCOUNT_ID))
    If Len(withdrawalAccountID) = 0 Or Len(depositAccountID) = 0 Then Exit Function
    '����������̏o�����͎����̌����Ԉړ��ł͂Ȃ����ߌ�₩��O���B
    If StrComp(withdrawalAccountID, depositAccountID, vbTextCompare) = 0 Then Exit Function
    withdrawalDate = CLng(DateValue(CDate(sourceData(withdrawalRow, OUT_COL_DATE))))
    depositDate = CLng(DateValue(CDate(sourceData(depositRow, OUT_COL_DATE))))
    If Abs(withdrawalDate - depositDate) > dayWindow Then Exit Function
    IsShiftPairEligible = True
End Function

Private Sub EvaluateShiftPair(ByRef sourceData As Variant, ByVal withdrawalRow As Long, _
                              ByVal depositRow As Long, ByVal absoluteTolerance As Double, _
                              ByRef chronology As String, ByRef timePrecision As String, _
                              ByRef elapsedText As String, ByRef amountMatch As String, _
                              ByRef reasonText As String, ByRef score As Long, ByRef ratingText As String)
    Dim withdrawalDate As Long, depositDate As Long, dayDifference As Long
    Dim withdrawalTime As Double, depositTime As Double
    Dim withdrawalHasTime As Boolean, depositHasTime As Boolean
    Dim signedMinutes As Double, absoluteMinutes As Double
    Dim withdrawalAmount As Double, depositAmount As Double, differenceAmount As Double
    Dim samePerson As Boolean, sameBank As Boolean
    Dim withdrawalPersonID As String, depositPersonID As String
    Dim inheritanceDate As Long
    Dim nearInheritance As Boolean, straddlesInheritance As Boolean

    withdrawalDate = CLng(DateValue(CDate(sourceData(withdrawalRow, OUT_COL_DATE))))
    depositDate = CLng(DateValue(CDate(sourceData(depositRow, OUT_COL_DATE))))
    dayDifference = Abs(withdrawalDate - depositDate)
    withdrawalHasTime = TryGetAnalysisTime(sourceData(withdrawalRow, OUT_COL_TIME), withdrawalTime)
    depositHasTime = TryGetAnalysisTime(sourceData(depositRow, OUT_COL_TIME), depositTime)
    If withdrawalHasTime And depositHasTime Then
        timePrecision = "������������"
    ElseIf withdrawalHasTime Or depositHasTime Then
        timePrecision = "�Е��̂ݎ�������"
    Else
        timePrecision = "�����Ȃ�"
    End If

    If withdrawalDate = depositDate Then
        If withdrawalHasTime And depositHasTime Then
            signedMinutes = ((depositDate + depositTime) - (withdrawalDate + withdrawalTime)) * 1440#
            absoluteMinutes = Abs(signedMinutes)
            If signedMinutes > 0.000001 Then
                chronology = "�o��������"
            ElseIf signedMinutes < -0.000001 Then
                chronology = "�������o��"
            Else
                chronology = "������"
            End If
            elapsedText = FormatAnalysisElapsedMinutes(absoluteMinutes)
        Else
            '�����ł��������Е��ȏ㌇����ƁA�L������f��ł��Ȃ��B
            '�����͎����o�H�̌��Ƃ��Ĉ����A���ۂ̑O��֌W�͍��������Ŋm�F����B
            chronology = "�����E�������m��i�V�t�g����j"
            elapsedText = "�����i�����s���j"
        End If
    ElseIf withdrawalDate < depositDate Then
        chronology = "�o��������"
        If withdrawalHasTime And depositHasTime Then
            absoluteMinutes = ((depositDate + depositTime) - (withdrawalDate + withdrawalTime)) * 1440#
            elapsedText = FormatAnalysisElapsedMinutes(Abs(absoluteMinutes))
        Else
            elapsedText = CStr(dayDifference) & "��"
        End If
    Else
        chronology = "�������o��"
        If withdrawalHasTime And depositHasTime Then
            absoluteMinutes = ((withdrawalDate + withdrawalTime) - (depositDate + depositTime)) * 1440#
            elapsedText = FormatAnalysisElapsedMinutes(Abs(absoluteMinutes))
        Else
            elapsedText = CStr(dayDifference) & "��"
        End If
    End If

    withdrawalAmount = CDbl(sourceData(withdrawalRow, OUT_COL_WITHDRAW))
    depositAmount = CDbl(sourceData(depositRow, OUT_COL_DEPOSIT))
    differenceAmount = Abs(withdrawalAmount - depositAmount)
    If differenceAmount < 0.0000001 Then
        amountMatch = "���S��v"
        score = 45
    ElseIf differenceAmount <= absoluteTolerance + 0.0000001 Then
        amountMatch = "���e�z��"
        score = 35
    Else
        amountMatch = "���e����"
        score = 25
    End If

    If withdrawalHasTime And depositHasTime Then
        If absoluteMinutes <= 15# Then
            score = score + 30
        ElseIf absoluteMinutes <= 60# Then
            score = score + 26
        ElseIf absoluteMinutes <= 360# Then
            score = score + 22
        ElseIf absoluteMinutes <= 1440# Then
            score = score + 18
        ElseIf dayDifference <= 2 Then
            score = score + 12
        ElseIf dayDifference <= 7 Then
            score = score + 7
        Else
            score = score + 3
        End If
    ElseIf dayDifference = 0 Then
        score = score + 15
    ElseIf dayDifference = 1 Then
        score = score + 13
    ElseIf dayDifference <= 3 Then
        score = score + 10
    ElseIf dayDifference <= 7 Then
        score = score + 6
    Else
        score = score + 3
    End If

    withdrawalPersonID = CellText(sourceData(withdrawalRow, WORK_TX_COL_PERSON_ID))
    depositPersonID = CellText(sourceData(depositRow, WORK_TX_COL_PERSON_ID))
    If Len(withdrawalPersonID) > 0 And Len(depositPersonID) > 0 Then
        samePerson = (StrComp(withdrawalPersonID, depositPersonID, vbTextCompare) = 0)
    Else
        samePerson = (NormalizePersonNameKey(CellText(sourceData(withdrawalRow, OUT_COL_PERSON))) = _
                      NormalizePersonNameKey(CellText(sourceData(depositRow, OUT_COL_PERSON))))
    End If
    If samePerson Then score = score + 12 Else score = score + 5
    score = score + 8  '�قȂ����ID�ł��邱�Ƃ�IsShiftPairEligible�Ŋm�F�ς݁B
    sameBank = (StrComp(CellText(sourceData(withdrawalRow, OUT_COL_BANK)), _
                         CellText(sourceData(depositRow, OUT_COL_BANK)), vbTextCompare) = 0)
    If sameBank Then score = score + 2 Else score = score + 4
    If IsDate(mAnalysisInheritanceDate) Then
        inheritanceDate = CLng(DateValue(CDate(mAnalysisInheritanceDate)))
        nearInheritance = (Abs(withdrawalDate - inheritanceDate) <= 30 Or _
                           Abs(depositDate - inheritanceDate) <= 30)
        straddlesInheritance = _
            (withdrawalDate < inheritanceDate And depositDate >= inheritanceDate) Or _
            (depositDate < inheritanceDate And withdrawalDate >= inheritanceDate)
        If nearInheritance Then score = score + 6
        If straddlesInheritance Then score = score + 6
    End If
    If score > 100 Then score = 100

    If score >= 80 Then
        ratingText = "��"
    ElseIf score >= 60 Then
        ratingText = "��"
    Else
        ratingText = "��"
    End If
    reasonText = amountMatch & "�A" & chronology & "�A" & timePrecision & "�A�قȂ����"
    If samePerson Then reasonText = reasonText & "�A����l��" Else reasonText = reasonText & "�A�l������"
    If sameBank Then reasonText = reasonText & "�A�����s" Else reasonText = reasonText & "�A��s����"
    If nearInheritance Then reasonText = reasonText & "�A�����J�n���O��30���ȓ�"
    If straddlesInheritance Then reasonText = reasonText & "�A�����J�n�����܂����L��"
    reasonText = reasonText & "�B�E�v�͌�⏜�O�����Ɏg�p���Ă��܂���B"
End Sub

Private Sub FillShiftAnalysisRow(ByRef buffer As Variant, ByVal bufferRow As Long, _
                                 ByRef sourceData As Variant, ByVal withdrawalRow As Long, _
                                 ByVal depositRow As Long, ByVal differenceAmount As Double, _
                                 ByVal chronology As String, ByVal timePrecision As String, _
                                 ByVal elapsedText As String, ByVal amountMatch As String, _
                                 ByVal reasonText As String, ByVal score As Long, _
                                 ByVal ratingText As String, ByVal candidateKey As String, _
                                 ByVal evidenceDigest As String, ByVal reviews As Object, _
                                 ByVal candidateCountByTx As Object)
    Dim reviewValues As Variant
    Dim withdrawalTxID As String, depositTxID As String, ambiguityCount As Long
    withdrawalTxID = CellText(sourceData(withdrawalRow, WORK_TX_COL_TRANSACTION_ID))
    depositTxID = CellText(sourceData(depositRow, WORK_TX_COL_TRANSACTION_ID))
    ambiguityCount = AnalysisMaximumCandidateCount(candidateCountByTx, _
                                                    withdrawalTxID & ";" & depositTxID)
    If ambiguityCount > 1 Then
        reasonText = AppendAnalysisReason(reasonText, "���������܂ތ�₪�ő�" & _
                     CStr(ambiguityCount) & "������A�m��O�ɏd�����p���m�F���Ă��������B")
    End If
    reasonText = AppendAnalysisReason(reasonText, _
                 "���͓��͍ςݎ���͈͓̔��ł̐���ł��B�����ڎ���̕s���݂��Ӗ����܂���B")
    reviewValues = AnalysisReviewValues(reviews, candidateKey, evidenceDigest)
    If CBool(reviewValues(2)) Then
        reasonText = AppendAnalysisReason(reasonText, _
                     "�O��m�F��ɍ�������܂��͕��͏������ς�������߁A�Ċm�F�֖߂��܂����B")
        reviewValues(1) = AppendAnalysisMemo(CStr(reviewValues(1)), _
                          "[����] ��������܂��͕��͏����̕ύX�����m���A�Ċm�F�֖߂��܂����B")
    End If
    buffer(bufferRow, 1) = ratingText
    buffer(bufferRow, 2) = score
    buffer(bufferRow, 3) = "1��1"
    buffer(bufferRow, 4) = chronology
    buffer(bufferRow, 5) = timePrecision
    buffer(bufferRow, 6) = elapsedText
    buffer(bufferRow, 7) = amountMatch
    buffer(bufferRow, 8) = differenceAmount
    buffer(bufferRow, 9) = CDate(sourceData(withdrawalRow, OUT_COL_DATE))
    buffer(bufferRow, 10) = AnalysisTimeOutputValue(sourceData(withdrawalRow, OUT_COL_TIME))
    buffer(bufferRow, 11) = sourceData(withdrawalRow, OUT_COL_PERSON)
    buffer(bufferRow, 12) = sourceData(withdrawalRow, WORK_TX_COL_RELATIONSHIP)
    buffer(bufferRow, 13) = sourceData(withdrawalRow, OUT_COL_BANK)
    buffer(bufferRow, 14) = sourceData(withdrawalRow, OUT_COL_BRANCH)
    buffer(bufferRow, 15) = sourceData(withdrawalRow, OUT_COL_ACCOUNT_TYPE)
    buffer(bufferRow, 16) = sourceData(withdrawalRow, OUT_COL_ACCOUNT_NO)
    buffer(bufferRow, 17) = sourceData(withdrawalRow, OUT_COL_WITHDRAW)
    buffer(bufferRow, 18) = sourceData(withdrawalRow, OUT_COL_TEKIYO)
    buffer(bufferRow, 19) = CDate(sourceData(depositRow, OUT_COL_DATE))
    buffer(bufferRow, 20) = AnalysisTimeOutputValue(sourceData(depositRow, OUT_COL_TIME))
    buffer(bufferRow, 21) = sourceData(depositRow, OUT_COL_PERSON)
    buffer(bufferRow, 22) = sourceData(depositRow, WORK_TX_COL_RELATIONSHIP)
    buffer(bufferRow, 23) = sourceData(depositRow, OUT_COL_BANK)
    buffer(bufferRow, 24) = sourceData(depositRow, OUT_COL_BRANCH)
    buffer(bufferRow, 25) = sourceData(depositRow, OUT_COL_ACCOUNT_TYPE)
    buffer(bufferRow, 26) = sourceData(depositRow, OUT_COL_ACCOUNT_NO)
    buffer(bufferRow, 27) = sourceData(depositRow, OUT_COL_DEPOSIT)
    buffer(bufferRow, 28) = sourceData(depositRow, OUT_COL_TEKIYO)
    buffer(bufferRow, 29) = reasonText
    buffer(bufferRow, 30) = reviewValues(0)
    buffer(bufferRow, 31) = reviewValues(1)
    buffer(bufferRow, 32) = AnalysisStoredKey(candidateKey, evidenceDigest)
    buffer(bufferRow, 33) = sourceData(withdrawalRow, WORK_TX_COL_TRANSACTION_ID)
    buffer(bufferRow, 34) = sourceData(depositRow, WORK_TX_COL_TRANSACTION_ID)
End Sub

Public Sub UpdateShiftCandidateStats(ByVal candidateCountByTx As Object, ByVal bestScoreByTx As Object, _
                                      ByVal bestRatingByTx As Object, ByVal transactionID As String, _
                                      ByVal score As Long, ByVal ratingText As String)
    If candidateCountByTx.Exists(transactionID) Then
        candidateCountByTx(transactionID) = CLng(candidateCountByTx(transactionID)) + 1
    Else
        candidateCountByTx.Add transactionID, 1
    End If
    If Not bestScoreByTx.Exists(transactionID) Then
        bestScoreByTx.Add transactionID, score
        bestRatingByTx.Add transactionID, ratingText
    ElseIf score > CLng(bestScoreByTx(transactionID)) Then
        bestScoreByTx(transactionID) = score
        bestRatingByTx(transactionID) = ratingText
    End If
End Sub

Private Sub WriteUnknownAnalysis(ByRef sourceData As Variant, ByRef withdrawalRows() As Long, _
                                 ByVal withdrawalCount As Long, ByRef depositRows() As Long, _
                                 ByVal depositCount As Long, ByVal reviews As Object, _
                                 ByVal candidateCountByTx As Object, ByVal confirmedCountByTx As Object, _
                                 ByVal bestRatingByTx As Object, ByVal unknownContextByTx As Object, _
                                 ByVal settingsSignature As String, _
                                 ByVal wsOut As Worksheet, ByRef writtenCount As Long)
    Dim buffer() As Variant
    Dim bufferCount As Long, nextOutputRow As Long, i As Long
    ReDim buffer(1 To ANALYSIS_BUFFER_ROWS, 1 To UNKNOWN_ANALYSIS_LAST_COL)
    nextOutputRow = 2
    For i = 1 To withdrawalCount
        bufferCount = bufferCount + 1
        FillUnknownAnalysisRow buffer, bufferCount, sourceData, withdrawalRows(i), False, reviews, _
                               candidateCountByTx, confirmedCountByTx, bestRatingByTx, _
                               unknownContextByTx, settingsSignature
        writtenCount = writtenCount + 1
        If bufferCount = ANALYSIS_BUFFER_ROWS Then
            FlushAnalysisBuffer wsOut, buffer, bufferCount, nextOutputRow, UNKNOWN_ANALYSIS_LAST_COL
            ReDim buffer(1 To ANALYSIS_BUFFER_ROWS, 1 To UNKNOWN_ANALYSIS_LAST_COL)
            bufferCount = 0
        End If
    Next i
    For i = 1 To depositCount
        bufferCount = bufferCount + 1
        FillUnknownAnalysisRow buffer, bufferCount, sourceData, depositRows(i), True, reviews, _
                               candidateCountByTx, confirmedCountByTx, bestRatingByTx, _
                               unknownContextByTx, settingsSignature
        writtenCount = writtenCount + 1
        If bufferCount = ANALYSIS_BUFFER_ROWS Then
            FlushAnalysisBuffer wsOut, buffer, bufferCount, nextOutputRow, UNKNOWN_ANALYSIS_LAST_COL
            ReDim buffer(1 To ANALYSIS_BUFFER_ROWS, 1 To UNKNOWN_ANALYSIS_LAST_COL)
            bufferCount = 0
        End If
    Next i
    If bufferCount > 0 Then _
        FlushAnalysisBuffer wsOut, buffer, bufferCount, nextOutputRow, UNKNOWN_ANALYSIS_LAST_COL
End Sub

Private Sub FillUnknownAnalysisRow(ByRef buffer As Variant, ByVal bufferRow As Long, _
                                   ByRef sourceData As Variant, ByVal sourceRow As Long, _
                                   ByVal isDeposit As Boolean, ByVal reviews As Object, _
                                   ByVal candidateCountByTx As Object, _
                                   ByVal confirmedCountByTx As Object, ByVal bestRatingByTx As Object, _
                                   ByVal unknownContextByTx As Object, _
                                   ByVal settingsSignature As String)
    Dim amountValue As Double, score As Long, priorityText As String, reasonText As String
    Dim transactionID As String, reviewKey As String, kindText As String
    Dim candidateCount As Long, confirmedCount As Long, bestRating As String
    Dim contextText As String, contextScore As Long, evidenceDigest As String
    Dim reviewValues As Variant
    transactionID = CellText(sourceData(sourceRow, WORK_TX_COL_TRANSACTION_ID))
    If isDeposit Then
        amountValue = CDbl(sourceData(sourceRow, OUT_COL_DEPOSIT))
        kindText = "�����s�����"
    Else
        amountValue = CDbl(sourceData(sourceRow, OUT_COL_WITHDRAW))
        kindText = "�g�r�s�����"
    End If
    If candidateCountByTx.Exists(transactionID) Then candidateCount = CLng(candidateCountByTx(transactionID))
    If confirmedCountByTx.Exists(transactionID) Then confirmedCount = CLng(confirmedCountByTx(transactionID))
    If bestRatingByTx.Exists(transactionID) Then bestRating = CStr(bestRatingByTx(transactionID))
    contextText = UnknownContextText(unknownContextByTx, transactionID)
    contextScore = UnknownContextScore(unknownContextByTx, transactionID)
    EvaluateUnknownTransaction sourceData, sourceRow, isDeposit, amountValue, candidateCount, _
                               bestRating, contextText, contextScore, score, priorityText, reasonText
    reviewKey = transactionID & ">" & kindText
    evidenceDigest = AnalysisEvidenceDigest(sourceData, CStr(sourceRow), _
                     "UNKNOWN|" & settingsSignature & "|C=" & CStr(candidateCount) & _
                     "|K=" & CStr(confirmedCount) & "|R=" & bestRating & "|" & contextText)
    reviewValues = AnalysisReviewValues(reviews, reviewKey, evidenceDigest)
    If CBool(reviewValues(2)) Then
        reasonText = AppendAnalysisReason(reasonText, _
                     "�O��m�F��ɍ�������܂��͕��͏������ς�������߁A�Ċm�F�֖߂��܂����B")
        reviewValues(1) = AppendAnalysisMemo(CStr(reviewValues(1)), _
                          "[����] ��������܂��͕��͏����̕ύX�����m���A�Ċm�F�֖߂��܂����B")
    End If

    buffer(bufferRow, 1) = priorityText
    buffer(bufferRow, 2) = score
    buffer(bufferRow, 3) = kindText
    buffer(bufferRow, 4) = CDate(sourceData(sourceRow, OUT_COL_DATE))
    buffer(bufferRow, 5) = AnalysisTimeOutputValue(sourceData(sourceRow, OUT_COL_TIME))
    If HasText(sourceData(sourceRow, OUT_COL_TIME)) Then buffer(bufferRow, 6) = "��������" Else buffer(bufferRow, 6) = "�����Ȃ�"
    buffer(bufferRow, 7) = sourceData(sourceRow, OUT_COL_PERSON)
    buffer(bufferRow, 8) = sourceData(sourceRow, WORK_TX_COL_RELATIONSHIP)
    buffer(bufferRow, 9) = sourceData(sourceRow, OUT_COL_BANK)
    buffer(bufferRow, 10) = sourceData(sourceRow, OUT_COL_BRANCH)
    buffer(bufferRow, 11) = sourceData(sourceRow, OUT_COL_ACCOUNT_TYPE)
    buffer(bufferRow, 12) = sourceData(sourceRow, OUT_COL_ACCOUNT_NO)
    If isDeposit Then buffer(bufferRow, 13) = amountValue Else buffer(bufferRow, 14) = amountValue
    buffer(bufferRow, 15) = sourceData(sourceRow, OUT_COL_SHOP)
    buffer(bufferRow, 16) = sourceData(sourceRow, OUT_COL_MACHINE)
    buffer(bufferRow, 17) = sourceData(sourceRow, OUT_COL_TEKIYO)
    buffer(bufferRow, 18) = CStr(candidateCount) & " / " & CStr(confirmedCount)
    buffer(bufferRow, 19) = bestRating
    buffer(bufferRow, 20) = reasonText
    buffer(bufferRow, 21) = reviewValues(0)
    buffer(bufferRow, 22) = reviewValues(1)
    buffer(bufferRow, 23) = sourceData(sourceRow, WORK_TX_COL_SOURCE)
    buffer(bufferRow, 24) = transactionID
    buffer(bufferRow, 25) = sourceData(sourceRow, WORK_TX_COL_ACCOUNT_ID)
    buffer(bufferRow, 26) = AnalysisStoredKey(reviewKey, evidenceDigest)
End Sub

Private Sub EvaluateUnknownTransaction(ByRef sourceData As Variant, ByVal sourceRow As Long, _
                                       ByVal isDeposit As Boolean, ByVal amountValue As Double, _
                                       ByVal candidateCount As Long, ByVal bestRating As String, _
                                       ByVal contextText As String, ByVal contextScore As Long, _
                                       ByRef score As Long, ByRef priorityText As String, _
                                       ByRef reasonText As String)
    Dim memoText As String
    Dim transactionDate As Long, inheritanceDate As Long, signedDays As Long
    score = 10
    If isDeposit Then reasonText = "�����m�F���K�v" Else reasonText = "�g�r�m�F���K�v"

    If amountValue >= 10000000# Then
        score = score + 35
        reasonText = reasonText & "�A1�疜�~�ȏ�"
    ElseIf amountValue >= 1000000# Then
        score = score + 25
        reasonText = reasonText & "�A�S���~�ȏ�"
    ElseIf amountValue >= 100000# Then
        score = score + 15
        reasonText = reasonText & "�A10���~�ȏ�"
    Else
        score = score + 5
    End If

    memoText = CellText(sourceData(sourceRow, OUT_COL_TEKIYO))
    If Len(memoText) = 0 Then
        score = score + 20
        reasonText = reasonText & "�A�E�v�󗓁i�������o���Ƃ��ėv�m�F�j"
    Else
        score = score + 5
        reasonText = reasonText & "�A�E�v�L�ڂ���i�L�ڂ����ł͊m�F�ς݂ɂ��Ȃ��j"
    End If
    If IsAnalysisRoundAmount(amountValue, 100000#) Then
        score = score + 10
        reasonText = reasonText & "�A10���~�P��"
    ElseIf IsAnalysisRoundAmount(amountValue, 10000#) Then
        score = score + 5
        reasonText = reasonText & "�A1���~�P��"
    End If
    If candidateCount > 0 Then
        If bestRating = "��" Then
            score = score + 15
        ElseIf bestRating = "��" Then
            score = score + 10
        Else
            score = score + 5
        End If
        reasonText = reasonText & "�A���͍ςݎ���͈͓̔��Ŏ����V�t�g�E�t���[���" & _
                     CStr(candidateCount) & "���i�ō�" & bestRating & "�j"
    Else
        reasonText = reasonText & _
                     "�A���͍ςݎ���͈͓̔��őΉ����Ȃ��i�����ڎ���̕s���݂��Ӗ����Ȃ��j"
    End If
    If Len(contextText) > 0 Then
        score = score + contextScore
        reasonText = reasonText & "�A" & contextText
    End If
    If IsDate(mAnalysisInheritanceDate) Then
        transactionDate = CLng(DateValue(CDate(sourceData(sourceRow, OUT_COL_DATE))))
        inheritanceDate = CLng(DateValue(CDate(mAnalysisInheritanceDate)))
        signedDays = transactionDate - inheritanceDate
        If Abs(signedDays) <= 30 Then
            score = score + 15
            reasonText = reasonText & "�A�����J�n���O��30���ȓ�"
        ElseIf Abs(signedDays) <= 90 Then
            score = score + 8
            reasonText = reasonText & "�A�����J�n���O��90���ȓ�"
        ElseIf Abs(signedDays) <= 365 Then
            score = score + 3
            reasonText = reasonText & "�A�����J�n���O��365���ȓ�"
        End If
        If signedDays >= 0 And signedDays <= 365 Then
            score = score + 5
            If isDeposit Then
                reasonText = reasonText & "�A�����J�n������i�������ʊm�F�j"
            Else
                reasonText = reasonText & "�A�����J�n��o���i�g�r���ʊm�F�j"
            End If
        End If
    End If
    If Not HasText(sourceData(sourceRow, OUT_COL_TIME)) Then _
        reasonText = reasonText & "�A�����Ȃ��i�������͓��t�E���z�E�����֌W���琄���≻�j"
    If score > 100 Then score = 100
    If score >= 65 Then
        priorityText = "��"
    ElseIf score >= 45 Then
        priorityText = "��"
    Else
        priorityText = "�ʏ�"
    End If
End Sub

Private Function IsAnalysisRoundAmount(ByVal amountValue As Double, ByVal unitValue As Double) As Boolean
    Dim quotient As Double
    If unitValue <= 0 Then Exit Function
    quotient = amountValue / unitValue
    IsAnalysisRoundAmount = (Abs(quotient - Fix(quotient)) < 0.0000001)
End Function

Private Function BuildUnknownContextIndex( _
        ByRef sourceData As Variant, ByRef withdrawalRows() As Long, _
        ByVal withdrawalCount As Long, ByRef depositRows() As Long, _
        ByVal depositCount As Long) As Object
    Dim contextIndex As Object, amountCounts As Object, dayAccountCounts As Object
    Dim operationCounts As Object, cashCounts As Object
    Dim allRows() As Long, allCount As Long, i As Long
    Set contextIndex = CreateObject("Scripting.Dictionary")
    Set amountCounts = CreateObject("Scripting.Dictionary")
    Set dayAccountCounts = CreateObject("Scripting.Dictionary")
    Set operationCounts = CreateObject("Scripting.Dictionary")
    Set cashCounts = CreateObject("Scripting.Dictionary")
    contextIndex.CompareMode = vbTextCompare
    amountCounts.CompareMode = vbTextCompare
    dayAccountCounts.CompareMode = vbTextCompare
    operationCounts.CompareMode = vbTextCompare
    cashCounts.CompareMode = vbTextCompare

    allCount = withdrawalCount + depositCount
    If allCount = 0 Then
        Set BuildUnknownContextIndex = contextIndex
        Exit Function
    End If
    ReDim allRows(1 To allCount)
    For i = 1 To withdrawalCount
        allRows(i) = withdrawalRows(i)
        RegisterUnknownContextCount sourceData, withdrawalRows(i), False, amountCounts, _
                                    dayAccountCounts, operationCounts, cashCounts
    Next i
    For i = 1 To depositCount
        allRows(withdrawalCount + i) = depositRows(i)
        RegisterUnknownContextCount sourceData, depositRows(i), True, amountCounts, _
                                    dayAccountCounts, operationCounts, cashCounts
    Next i
    For i = 1 To allCount
        AddUnknownSimpleContext sourceData, allRows(i), contextIndex, amountCounts, _
                                dayAccountCounts, operationCounts, cashCounts
    Next i
    AddUnknownRollingContext sourceData, allRows, allCount, contextIndex
    Set BuildUnknownContextIndex = contextIndex
End Function

Private Sub RegisterUnknownContextCount( _
        ByRef sourceData As Variant, ByVal sourceRow As Long, ByVal isDeposit As Boolean, _
        ByVal amountCounts As Object, ByVal dayAccountCounts As Object, _
        ByVal operationCounts As Object, ByVal cashCounts As Object)
    Dim operationKey As String, cashKey As String
    IncrementAnalysisCount amountCounts, UnknownAmountContextKey(sourceData, sourceRow, isDeposit)
    IncrementAnalysisCount dayAccountCounts, UnknownDayAccountContextKey(sourceData, sourceRow, isDeposit)
    operationKey = UnknownOperationContextKey(sourceData, sourceRow)
    If Len(operationKey) > 0 Then IncrementAnalysisCount operationCounts, operationKey
    cashKey = UnknownCashContextKey(sourceData, sourceRow)
    If Len(cashKey) > 0 Then IncrementAnalysisCount cashCounts, cashKey
End Sub

Private Sub AddUnknownSimpleContext( _
        ByRef sourceData As Variant, ByVal sourceRow As Long, ByVal contextIndex As Object, _
        ByVal amountCounts As Object, ByVal dayAccountCounts As Object, _
        ByVal operationCounts As Object, ByVal cashCounts As Object)
    Dim transactionID As String, keyText As String, itemCount As Long
    Dim isDeposit As Boolean
    transactionID = CellText(sourceData(sourceRow, WORK_TX_COL_TRANSACTION_ID))
    If Len(transactionID) = 0 Then Exit Sub
    isDeposit = HasText(sourceData(sourceRow, OUT_COL_DEPOSIT))

    keyText = UnknownAmountContextKey(sourceData, sourceRow, isDeposit)
    itemCount = CLng(amountCounts(keyText))
    If itemCount >= 2 Then _
        AddUnknownContextTag contextIndex, transactionID, _
            "���͔͈͓��œ��z�E����̎��" & CStr(itemCount) & "��", 4

    keyText = UnknownDayAccountContextKey(sourceData, sourceRow, isDeposit)
    itemCount = CLng(dayAccountCounts(keyText))
    If itemCount >= 2 Then _
        AddUnknownContextTag contextIndex, transactionID, _
            "�����E�������̓�����" & CStr(itemCount) & "��", 4

    keyText = UnknownOperationContextKey(sourceData, sourceRow)
    If Len(keyText) > 0 Then
        itemCount = CLng(operationCounts(keyText))
        If itemCount >= 2 Then _
            AddUnknownContextTag contextIndex, transactionID, _
                "�����E����s�E���戵�X/�@�Ԃ̎��" & CStr(itemCount) & "��", 6
    End If

    keyText = UnknownCashContextKey(sourceData, sourceRow)
    If Len(keyText) > 0 Then
        itemCount = CLng(cashCounts(keyText))
        If itemCount >= 2 Then _
            AddUnknownContextTag contextIndex, transactionID, _
                "�����E���l���E����s�̑����^���" & CStr(itemCount) & "��", 6
    End If
End Sub

Private Sub AddUnknownRollingContext(ByRef sourceData As Variant, ByRef allRows() As Long, _
                                     ByVal allCount As Long, ByVal contextIndex As Object)
    Dim accountKeys() As String, dates() As Long, rows() As Long
    Dim groupStart As Long, groupEnd As Long, groupCount As Long
    Dim groupDates() As Long, depositAmounts() As Double, withdrawalAmounts() As Double
    Dim depositCounts() As Long, withdrawalCounts() As Long
    Dim i As Long, p As Long, sourceRow As Long, currentDate As Long
    Dim lower30 As Long, lower90 As Long, lower365 As Long
    Dim futureStart As Long, upper30 As Long, upper90 As Long, upper365 As Long
    Dim sameCount As Long, oppositeCount As Long, sameAmount As Double, oppositeAmount As Double
    Dim transactionID As String, oppositeLabel As String, isDeposit As Boolean
    ReDim accountKeys(1 To allCount)
    ReDim dates(1 To allCount)
    ReDim rows(1 To allCount)
    For i = 1 To allCount
        rows(i) = allRows(i)
        accountKeys(i) = UCase$(CellText(sourceData(allRows(i), WORK_TX_COL_ACCOUNT_ID)))
        dates(i) = CLng(DateValue(CDate(sourceData(allRows(i), OUT_COL_DATE))))
    Next i
    If allCount > 1 Then QuickSortUnknownContextRows accountKeys, dates, rows, 1, allCount

    groupStart = 1
    Do While groupStart <= allCount
        groupEnd = groupStart
        Do While groupEnd < allCount
            If StrComp(accountKeys(groupEnd + 1), accountKeys(groupStart), vbTextCompare) <> 0 Then Exit Do
            groupEnd = groupEnd + 1
        Loop
        groupCount = groupEnd - groupStart + 1
        ReDim groupDates(1 To groupCount)
        ReDim depositAmounts(0 To groupCount)
        ReDim withdrawalAmounts(0 To groupCount)
        ReDim depositCounts(0 To groupCount)
        ReDim withdrawalCounts(0 To groupCount)
        For p = 1 To groupCount
            sourceRow = rows(groupStart + p - 1)
            groupDates(p) = dates(groupStart + p - 1)
            depositAmounts(p) = depositAmounts(p - 1)
            withdrawalAmounts(p) = withdrawalAmounts(p - 1)
            depositCounts(p) = depositCounts(p - 1)
            withdrawalCounts(p) = withdrawalCounts(p - 1)
            If HasText(sourceData(sourceRow, OUT_COL_DEPOSIT)) Then
                depositAmounts(p) = depositAmounts(p) + CDbl(sourceData(sourceRow, OUT_COL_DEPOSIT))
                depositCounts(p) = depositCounts(p) + 1
            Else
                withdrawalAmounts(p) = withdrawalAmounts(p) + CDbl(sourceData(sourceRow, OUT_COL_WITHDRAW))
                withdrawalCounts(p) = withdrawalCounts(p) + 1
            End If
        Next p

        For p = 1 To groupCount
            sourceRow = rows(groupStart + p - 1)
            transactionID = CellText(sourceData(sourceRow, WORK_TX_COL_TRANSACTION_ID))
            currentDate = groupDates(p)
            isDeposit = HasText(sourceData(sourceRow, OUT_COL_DEPOSIT))
            lower30 = LowerBoundUnknownContextDate(groupDates, groupCount, currentDate - 29)
            lower90 = LowerBoundUnknownContextDate(groupDates, groupCount, currentDate - 89)
            lower365 = LowerBoundUnknownContextDate(groupDates, groupCount, currentDate - 364)
            If isDeposit Then
                sameCount = depositCounts(p) - depositCounts(lower30 - 1)
                sameAmount = depositAmounts(p) - depositAmounts(lower30 - 1)
            Else
                sameCount = withdrawalCounts(p) - withdrawalCounts(lower30 - 1)
                sameAmount = withdrawalAmounts(p) - withdrawalAmounts(lower30 - 1)
            End If
            If sameCount >= 2 Then
                AddUnknownContextTag contextIndex, transactionID, _
                    "����30���E�������̓�����" & CStr(sameCount) & "���v" & _
                    Format$(sameAmount, "#,##0.########") & "�~", 6
            Else
                If isDeposit Then
                    sameCount = depositCounts(p) - depositCounts(lower90 - 1)
                    sameAmount = depositAmounts(p) - depositAmounts(lower90 - 1)
                Else
                    sameCount = withdrawalCounts(p) - withdrawalCounts(lower90 - 1)
                    sameAmount = withdrawalAmounts(p) - withdrawalAmounts(lower90 - 1)
                End If
                If sameCount >= 3 Then
                    AddUnknownContextTag contextIndex, transactionID, _
                        "����90���E�������̓�����" & CStr(sameCount) & "���v" & _
                        Format$(sameAmount, "#,##0.########") & "�~", 5
                Else
                    If isDeposit Then
                        sameCount = depositCounts(p) - depositCounts(lower365 - 1)
                        sameAmount = depositAmounts(p) - depositAmounts(lower365 - 1)
                    Else
                        sameCount = withdrawalCounts(p) - withdrawalCounts(lower365 - 1)
                        sameAmount = withdrawalAmounts(p) - withdrawalAmounts(lower365 - 1)
                    End If
                    If sameCount >= 4 Then _
                        AddUnknownContextTag contextIndex, transactionID, _
                            "����365���E�������̓�����" & CStr(sameCount) & "���v" & _
                            Format$(sameAmount, "#,##0.########") & "�~", 4
                End If
            End If

            '�����������s���Ȏ���𖳗��ɕ��ׂ��A�����ȍ~�������㑱�Ƃ��ďW�v����B
            futureStart = UpperBoundUnknownContextDate(groupDates, groupCount, currentDate) + 1
            If futureStart <= groupCount Then
                upper30 = UpperBoundUnknownContextDate(groupDates, groupCount, currentDate + 30)
                upper90 = UpperBoundUnknownContextDate(groupDates, groupCount, currentDate + 90)
                upper365 = UpperBoundUnknownContextDate(groupDates, groupCount, currentDate + 365)
                If upper30 < futureStart Then upper30 = futureStart - 1
                If upper90 < futureStart Then upper90 = futureStart - 1
                If upper365 < futureStart Then upper365 = futureStart - 1
                If isDeposit Then
                    oppositeLabel = "�o��"
                    oppositeCount = withdrawalCounts(upper30) - withdrawalCounts(futureStart - 1)
                    oppositeAmount = withdrawalAmounts(upper30) - withdrawalAmounts(futureStart - 1)
                Else
                    oppositeLabel = "����"
                    oppositeCount = depositCounts(upper30) - depositCounts(futureStart - 1)
                    oppositeAmount = depositAmounts(upper30) - depositAmounts(futureStart - 1)
                End If
                If oppositeCount > 0 Then
                    AddUnknownContextTag contextIndex, transactionID, _
                        "�������̗����ȍ~30���ȓ���" & oppositeLabel & CStr(oppositeCount) & _
                        "���v" & Format$(oppositeAmount, "#,##0.########") & "�~", 6
                Else
                    If isDeposit Then
                        oppositeCount = withdrawalCounts(upper90) - withdrawalCounts(futureStart - 1)
                        oppositeAmount = withdrawalAmounts(upper90) - withdrawalAmounts(futureStart - 1)
                    Else
                        oppositeCount = depositCounts(upper90) - depositCounts(futureStart - 1)
                        oppositeAmount = depositAmounts(upper90) - depositAmounts(futureStart - 1)
                    End If
                    If oppositeCount > 0 Then
                        AddUnknownContextTag contextIndex, transactionID, _
                            "�������̗����ȍ~90���ȓ���" & oppositeLabel & CStr(oppositeCount) & _
                            "���v" & Format$(oppositeAmount, "#,##0.########") & "�~", 4
                    Else
                        If isDeposit Then
                            oppositeCount = withdrawalCounts(upper365) - withdrawalCounts(futureStart - 1)
                            oppositeAmount = withdrawalAmounts(upper365) - withdrawalAmounts(futureStart - 1)
                        Else
                            oppositeCount = depositCounts(upper365) - depositCounts(futureStart - 1)
                            oppositeAmount = depositAmounts(upper365) - depositAmounts(futureStart - 1)
                        End If
                        If oppositeCount > 0 Then _
                            AddUnknownContextTag contextIndex, transactionID, _
                                "�������̗����ȍ~365���ȓ���" & oppositeLabel & CStr(oppositeCount) & _
                                "���v" & Format$(oppositeAmount, "#,##0.########") & "�~", 3
                    End If
                End If
            End If
        Next p
        groupStart = groupEnd + 1
    Loop
End Sub

Private Function UnknownAmountContextKey(ByRef sourceData As Variant, ByVal sourceRow As Long, _
                                         ByVal isDeposit As Boolean) As String
    Dim amountValue As Double, sideText As String
    If isDeposit Then
        amountValue = CDbl(sourceData(sourceRow, OUT_COL_DEPOSIT))
        sideText = "D"
    Else
        amountValue = CDbl(sourceData(sourceRow, OUT_COL_WITHDRAW))
        sideText = "W"
    End If
    UnknownAmountContextKey = sideText & "|" & Trim$(Str$(amountValue))
End Function

Private Function UnknownDayAccountContextKey(ByRef sourceData As Variant, ByVal sourceRow As Long, _
                                             ByVal isDeposit As Boolean) As String
    UnknownDayAccountContextKey = IIf(isDeposit, "D|", "W|") & _
        UCase$(CellText(sourceData(sourceRow, WORK_TX_COL_ACCOUNT_ID))) & "|" & _
        CStr(CLng(DateValue(CDate(sourceData(sourceRow, OUT_COL_DATE)))))
End Function

Private Function UnknownOperationContextKey(ByRef sourceData As Variant, _
                                            ByVal sourceRow As Long) As String
    Dim shopText As String, machineText As String
    shopText = UCase$(CellText(sourceData(sourceRow, OUT_COL_SHOP)))
    machineText = UCase$(CellText(sourceData(sourceRow, OUT_COL_MACHINE)))
    If Len(shopText) = 0 And Len(machineText) = 0 Then Exit Function
    UnknownOperationContextKey = UCase$(CellText(sourceData(sourceRow, OUT_COL_BANK))) & "|" & _
        CStr(CLng(DateValue(CDate(sourceData(sourceRow, OUT_COL_DATE))))) & "|" & _
        shopText & "|" & machineText
End Function

Private Function UnknownCashContextKey(ByRef sourceData As Variant, ByVal sourceRow As Long) As String
    Dim personKey As String
    If HasText(sourceData(sourceRow, OUT_COL_TEKIYO)) Or _
       HasText(sourceData(sourceRow, OUT_COL_SHOP)) Or _
       HasText(sourceData(sourceRow, OUT_COL_MACHINE)) Then Exit Function
    personKey = CellText(sourceData(sourceRow, WORK_TX_COL_PERSON_ID))
    If Len(personKey) = 0 Then _
        personKey = NormalizePersonNameKey(CellText(sourceData(sourceRow, OUT_COL_PERSON)))
    If Len(personKey) = 0 Then Exit Function
    UnknownCashContextKey = UCase$(CellText(sourceData(sourceRow, OUT_COL_BANK))) & "|" & _
        UCase$(personKey) & "|" & _
        CStr(CLng(DateValue(CDate(sourceData(sourceRow, OUT_COL_DATE)))))
End Function

Private Sub IncrementAnalysisCount(ByVal values As Object, ByVal keyText As String)
    If values.Exists(keyText) Then
        values(keyText) = CLng(values(keyText)) + 1
    Else
        values.Add keyText, 1
    End If
End Sub

Private Sub AddUnknownContextTag(ByVal contextIndex As Object, ByVal transactionID As String, _
                                 ByVal tagText As String, ByVal scoreIncrement As Long)
    Dim textKey As String, scoreKey As String, currentText As String, proposedText As String
    textKey = "T|" & transactionID
    scoreKey = "S|" & transactionID
    If contextIndex.Exists(textKey) Then currentText = CStr(contextIndex(textKey))
    If InStr(1, currentText, tagText, vbTextCompare) > 0 Then Exit Sub
    If Len(currentText) = 0 Then proposedText = tagText Else proposedText = currentText & "�A" & tagText
    '�\���ł��Ȃ����������ŗD��x���オ��Ɛ����s�\�ɂȂ邽�߁A
    '���R���̏���𒴂���^�O�̓X�R�A�ɂ����f���Ȃ��B
    If Len(proposedText) > ANALYSIS_CONTEXT_TEXT_MAX Then Exit Sub
    If contextIndex.Exists(textKey) Then
        contextIndex(textKey) = proposedText
    Else
        contextIndex.Add textKey, proposedText
    End If
    If contextIndex.Exists(scoreKey) Then
        contextIndex(scoreKey) = CLng(contextIndex(scoreKey)) + scoreIncrement
    Else
        contextIndex.Add scoreKey, scoreIncrement
    End If
    If CLng(contextIndex(scoreKey)) > 25 Then contextIndex(scoreKey) = 25
End Sub

Private Function UnknownContextText(ByVal contextIndex As Object, ByVal transactionID As String) As String
    If Not contextIndex Is Nothing Then
        If contextIndex.Exists("T|" & transactionID) Then _
            UnknownContextText = CStr(contextIndex("T|" & transactionID))
    End If
End Function

Private Function UnknownContextScore(ByVal contextIndex As Object, ByVal transactionID As String) As Long
    If Not contextIndex Is Nothing Then
        If contextIndex.Exists("S|" & transactionID) Then _
            UnknownContextScore = CLng(contextIndex("S|" & transactionID))
    End If
End Function

Private Function LowerBoundUnknownContextDate(ByRef dates() As Long, ByVal itemCount As Long, _
                                              ByVal targetDate As Long) As Long
    Dim low As Long, high As Long, mid As Long
    low = 1: high = itemCount + 1
    Do While low < high
        mid = low + (high - low) \ 2
        If mid <= itemCount And dates(mid) < targetDate Then low = mid + 1 Else high = mid
    Loop
    LowerBoundUnknownContextDate = low
End Function

Private Function UpperBoundUnknownContextDate(ByRef dates() As Long, ByVal itemCount As Long, _
                                              ByVal targetDate As Long) As Long
    Dim low As Long, high As Long, mid As Long
    low = 1: high = itemCount + 1
    Do While low < high
        mid = low + (high - low) \ 2
        If mid <= itemCount And dates(mid) <= targetDate Then low = mid + 1 Else high = mid
    Loop
    UpperBoundUnknownContextDate = low - 1
End Function

Private Sub QuickSortUnknownContextRows(ByRef accountKeys() As String, ByRef dates() As Long, _
                                        ByRef rows() As Long, ByVal firstIndex As Long, _
                                        ByVal lastIndex As Long)
    Dim low As Long, high As Long, pivotIndex As Long
    Dim pivotKey As String, pivotDate As Long, pivotRow As Long
    Dim tempKey As String, tempDate As Long, tempRow As Long
    low = firstIndex: high = lastIndex
    pivotIndex = (firstIndex + lastIndex) \ 2
    pivotKey = accountKeys(pivotIndex): pivotDate = dates(pivotIndex): pivotRow = rows(pivotIndex)
    Do While low <= high
        Do While CompareUnknownContextRows(accountKeys(low), dates(low), rows(low), _
                                           pivotKey, pivotDate, pivotRow) < 0
            low = low + 1
        Loop
        Do While CompareUnknownContextRows(accountKeys(high), dates(high), rows(high), _
                                           pivotKey, pivotDate, pivotRow) > 0
            high = high - 1
        Loop
        If low <= high Then
            tempKey = accountKeys(low): accountKeys(low) = accountKeys(high): accountKeys(high) = tempKey
            tempDate = dates(low): dates(low) = dates(high): dates(high) = tempDate
            tempRow = rows(low): rows(low) = rows(high): rows(high) = tempRow
            low = low + 1: high = high - 1
        End If
    Loop
    If firstIndex < high Then QuickSortUnknownContextRows accountKeys, dates, rows, firstIndex, high
    If low < lastIndex Then QuickSortUnknownContextRows accountKeys, dates, rows, low, lastIndex
End Sub

Private Function CompareUnknownContextRows(ByVal firstKey As String, ByVal firstDate As Long, _
                                           ByVal firstRow As Long, ByVal secondKey As String, _
                                           ByVal secondDate As Long, ByVal secondRow As Long) As Long
    CompareUnknownContextRows = StrComp(firstKey, secondKey, vbTextCompare)
    If CompareUnknownContextRows <> 0 Then Exit Function
    If firstDate < secondDate Then
        CompareUnknownContextRows = -1
    ElseIf firstDate > secondDate Then
        CompareUnknownContextRows = 1
    ElseIf firstRow < secondRow Then
        CompareUnknownContextRows = -1
    ElseIf firstRow > secondRow Then
        CompareUnknownContextRows = 1
    End If
End Function

Public Function AnalysisSettingsSignature(ByVal minAmount As Double, ByVal dayWindow As Long, _
                                          ByVal absoluteTolerance As Double, _
                                          ByVal rateTolerance As Double) As String
    AnalysisSettingsSignature = "MIN=" & Trim$(Str$(minAmount)) & "|DAY=" & CStr(dayWindow) & _
                                "|ABS=" & Trim$(Str$(absoluteTolerance)) & _
                                "|RATE=" & Trim$(Str$(rateTolerance))
    If IsDate(mAnalysisInheritanceDate) Then _
        AnalysisSettingsSignature = AnalysisSettingsSignature & "|INH=" & _
                                    Format$(CDate(mAnalysisInheritanceDate), "yyyymmdd")
End Function

Public Function AnalysisEvidenceDigest(ByRef sourceData As Variant, ByVal rowList As String, _
                                       ByVal contextText As String) As String
    Dim rowParts As Variant, rowTexts() As String, item As Variant
    Dim itemCount As Long, i As Long, j As Long, tempText As String, rawText As String
    If Len(rowList) > 0 Then
        rowParts = Split(rowList, ";")
        ReDim rowTexts(1 To UBound(rowParts) - LBound(rowParts) + 1)
        For Each item In rowParts
            If Len(Trim$(CStr(item))) > 0 Then
                itemCount = itemCount + 1
                rowTexts(itemCount) = AnalysisRowEvidenceDigest(sourceData, CLng(item))
            End If
        Next item
    End If
    For i = 2 To itemCount
        tempText = rowTexts(i)
        j = i - 1
        Do While j >= 1
            If StrComp(rowTexts(j), tempText, vbBinaryCompare) <= 0 Then Exit Do
            rowTexts(j + 1) = rowTexts(j)
            j = j - 1
        Loop
        rowTexts(j + 1) = tempText
    Next i
    rawText = CStr(Len(contextText)) & ":" & contextText
    For i = 1 To itemCount
        rawText = rawText & "|" & CStr(Len(rowTexts(i))) & ":" & rowTexts(i)
    Next i
    AnalysisEvidenceDigest = AnalysisHashPart(rawText, 104729#, 131#) & "-" & _
                             AnalysisHashPart(rawText, 130363#, 137#)
End Function

Private Function AnalysisRowEvidenceDigest(ByRef sourceData As Variant, _
                                           ByVal sourceRow As Long) As String
    Dim transactionID As String, rowText As String
    transactionID = CellText(sourceData(sourceRow, WORK_TX_COL_TRANSACTION_ID))
    If mAnalysisRowEvidenceCache Is Nothing Then
        Set mAnalysisRowEvidenceCache = CreateObject("Scripting.Dictionary")
        mAnalysisRowEvidenceCache.CompareMode = vbTextCompare
    End If
    If Len(transactionID) > 0 Then
        If mAnalysisRowEvidenceCache.Exists(transactionID) Then
            AnalysisRowEvidenceDigest = CStr(mAnalysisRowEvidenceCache(transactionID))
            Exit Function
        End If
    End If
    rowText = AnalysisRowEvidenceText(sourceData, sourceRow)
    AnalysisRowEvidenceDigest = AnalysisHashPart(rowText, 15485863#, 139#) & "-" & _
                                AnalysisHashPart(rowText, 32452843#, 149#)
    If Len(transactionID) > 0 Then _
        mAnalysisRowEvidenceCache.Add transactionID, AnalysisRowEvidenceDigest
End Function

Private Sub ResetAnalysisEvidenceCache()
    Set mAnalysisRowEvidenceCache = Nothing
End Sub

Private Function AnalysisRowEvidenceText(ByRef sourceData As Variant, ByVal sourceRow As Long) As String
    Dim c As Long, valueText As String, resultText As String
    For c = 1 To UBound(sourceData, 2)
        valueText = AnalysisEvidenceValue(sourceData(sourceRow, c))
        resultText = resultText & CStr(Len(valueText)) & ":" & valueText & "|"
    Next c
    AnalysisRowEvidenceText = resultText
End Function

Private Function AnalysisEvidenceValue(ByVal valueIn As Variant) As String
    If IsError(valueIn) Then
        AnalysisEvidenceValue = "#ERROR"
    ElseIf IsEmpty(valueIn) Or IsNull(valueIn) Then
        AnalysisEvidenceValue = vbNullString
    ElseIf VarType(valueIn) = vbBoolean Then
        If CBool(valueIn) Then AnalysisEvidenceValue = "TRUE" Else AnalysisEvidenceValue = "FALSE"
    ElseIf IsNumeric(valueIn) Then
        AnalysisEvidenceValue = Trim$(Str$(CDbl(valueIn)))
    Else
        AnalysisEvidenceValue = CStr(valueIn)
    End If
End Function

Private Function AnalysisHashPart(ByVal rawText As String, ByVal seedValue As Double, _
                                  ByVal multiplier As Double) As String
    Const HASH_MODULUS As Double = 2147483629#
    Dim hashValue As Double, i As Long, codeValue As Long, hexText As String
    hashValue = seedValue
    For i = 1 To Len(rawText)
        codeValue = AscW(Mid$(rawText, i, 1))
        If codeValue < 0 Then codeValue = codeValue + 65536
        hashValue = hashValue * multiplier + CDbl(codeValue)
        hashValue = hashValue - Fix(hashValue / HASH_MODULUS) * HASH_MODULUS
    Next i
    hexText = Hex$(CLng(hashValue))
    AnalysisHashPart = Right$("00000000" & hexText, 8)
End Function

Public Function AnalysisStoredKey(ByVal baseKey As String, ByVal evidenceDigest As String) As String
    AnalysisStoredKey = baseKey & ANALYSIS_EVIDENCE_MARKER & evidenceDigest
End Function

Public Function AnalysisBaseKey(ByVal storedKey As String, ByRef evidenceDigest As String) As String
    Dim markerPosition As Long
    markerPosition = InStrRev(storedKey, ANALYSIS_EVIDENCE_MARKER, -1, vbBinaryCompare)
    If markerPosition > 0 Then
        AnalysisBaseKey = Left$(storedKey, markerPosition - 1)
        evidenceDigest = Mid$(storedKey, markerPosition + Len(ANALYSIS_EVIDENCE_MARKER))
    Else
        AnalysisBaseKey = storedKey
        evidenceDigest = vbNullString
    End If
End Function

Public Function AnalysisMaximumCandidateCount(ByVal candidateCountByTx As Object, _
                                              ByVal transactionIDs As String) As Long
    Dim items As Variant, item As Variant, transactionID As String, itemCount As Long
    If candidateCountByTx Is Nothing Or Len(transactionIDs) = 0 Then Exit Function
    items = Split(transactionIDs, ";")
    For Each item In items
        transactionID = Trim$(CStr(item))
        If candidateCountByTx.Exists(transactionID) Then
            itemCount = CLng(candidateCountByTx(transactionID))
            If itemCount > AnalysisMaximumCandidateCount Then _
                AnalysisMaximumCandidateCount = itemCount
        End If
    Next item
End Function

Public Function AppendAnalysisReason(ByVal currentText As String, ByVal additionalText As String) As String
    If Len(additionalText) = 0 Or InStr(1, currentText, additionalText, vbTextCompare) > 0 Then
        AppendAnalysisReason = currentText
    ElseIf Len(currentText) = 0 Then
        AppendAnalysisReason = additionalText
    Else
        AppendAnalysisReason = Trim$(currentText) & " " & additionalText
    End If
End Function

Public Function AppendAnalysisMemo(ByVal currentText As String, ByVal additionalText As String) As String
    Dim separatorText As String, availableChars As Long
    If Len(additionalText) = 0 Or InStr(1, currentText, additionalText, vbTextCompare) > 0 Then
        AppendAnalysisMemo = currentText
        Exit Function
    End If
    If Len(currentText) > 0 Then separatorText = vbLf
    availableChars = ANALYSIS_REVIEW_MEMO_MAX - Len(currentText) - Len(separatorText)
    If availableChars <= 0 Then
        AppendAnalysisMemo = currentText
    Else
        AppendAnalysisMemo = currentText & separatorText & Left$(additionalText, availableChars)
    End If
End Function

Public Sub ResolveAnalysisReviewConflicts(ByVal wsShift As Worksheet, ByVal wsFlow As Worksheet)
    Dim candidateRows As Object, countByTx As Object
    Dim candidateItem As Variant, candidateData As Variant, transactionItems As Variant, item As Variant
    Dim hasConflict As Boolean, reasonColumn As Long
    Set candidateRows = CreateObject("Scripting.Dictionary")
    Set countByTx = CreateObject("Scripting.Dictionary")
    candidateRows.CompareMode = vbTextCompare
    countByTx.CompareMode = vbTextCompare
    CollectConfirmedAnalysisUsage wsShift, wsFlow, candidateRows, countByTx
    For Each candidateItem In candidateRows.Keys
        candidateData = candidateRows(candidateItem)
        transactionItems = Split(CStr(candidateData(2)), ";")
        hasConflict = False
        For Each item In transactionItems
            If countByTx.Exists(Trim$(CStr(item))) Then
                If CLng(countByTx(Trim$(CStr(item)))) > 1 Then
                    hasConflict = True
                    Exit For
                End If
            End If
        Next item
        If hasConflict Then
            If CLng(candidateData(0)) = 1 Then
                reasonColumn = 29
                wsShift.Cells(CLng(candidateData(1)), SHIFT_ANALYSIS_STATUS_COL).Value = _
                    ANALYSIS_STATUS_FOLLOWUP
                wsShift.Cells(CLng(candidateData(1)), reasonColumn).Value = AppendAnalysisReason( _
                    CellText(wsShift.Cells(CLng(candidateData(1)), reasonColumn).Value), _
                    "��������������̊m�F�ς݌��Ɏg��ꂽ���߁A�d���m����������čĊm�F�֖߂��܂����B")
                wsShift.Cells(CLng(candidateData(1)), SHIFT_ANALYSIS_MEMO_COL).Value = AppendAnalysisMemo( _
                    CellText(wsShift.Cells(CLng(candidateData(1)), SHIFT_ANALYSIS_MEMO_COL).Value), _
                    "[����] �������̏d���m������m���A�Ċm�F�֖߂��܂����B")
            Else
                reasonColumn = 16
                wsFlow.Cells(CLng(candidateData(1)), FLOW_ANALYSIS_STATUS_COL).Value = _
                    ANALYSIS_STATUS_FOLLOWUP
                wsFlow.Cells(CLng(candidateData(1)), reasonColumn).Value = AppendAnalysisReason( _
                    CellText(wsFlow.Cells(CLng(candidateData(1)), reasonColumn).Value), _
                    "��������������̊m�F�ς݌��Ɏg��ꂽ���߁A�d���m����������čĊm�F�֖߂��܂����B")
                wsFlow.Cells(CLng(candidateData(1)), FLOW_ANALYSIS_MEMO_COL).Value = AppendAnalysisMemo( _
                    CellText(wsFlow.Cells(CLng(candidateData(1)), FLOW_ANALYSIS_MEMO_COL).Value), _
                    "[����] �������̏d���m������m���A�Ċm�F�֖߂��܂����B")
            End If
        End If
    Next candidateItem
End Sub

Public Function BuildConfirmedCandidateCountByTransaction(ByVal wsShift As Worksheet, _
                                                          ByVal wsFlow As Worksheet) As Object
    Dim candidateRows As Object, countByTx As Object
    Set candidateRows = CreateObject("Scripting.Dictionary")
    Set countByTx = CreateObject("Scripting.Dictionary")
    candidateRows.CompareMode = vbTextCompare
    countByTx.CompareMode = vbTextCompare
    CollectConfirmedAnalysisUsage wsShift, wsFlow, candidateRows, countByTx
    Set BuildConfirmedCandidateCountByTransaction = countByTx
End Function

Private Sub CollectConfirmedAnalysisUsage(ByVal wsShift As Worksheet, ByVal wsFlow As Worksheet, _
                                          ByVal candidateRows As Object, ByVal countByTx As Object)
    Dim membership As Object
    Set membership = CreateObject("Scripting.Dictionary")
    membership.CompareMode = vbTextCompare
    CollectConfirmedUsageFromSheet wsShift, 1, SHIFT_ANALYSIS_STATUS_COL, SHIFT_ANALYSIS_KEY_COL, _
                                   33, 34, candidateRows, countByTx, membership
    CollectConfirmedUsageFromSheet wsFlow, 2, FLOW_ANALYSIS_STATUS_COL, FLOW_ANALYSIS_KEY_COL, _
                                   20, 0, candidateRows, countByTx, membership
End Sub

Private Sub CollectConfirmedUsageFromSheet( _
        ByVal ws As Worksheet, ByVal sheetCode As Long, ByVal statusColumn As Long, _
        ByVal keyColumn As Long, ByVal transactionColumn As Long, ByVal secondTransactionColumn As Long, _
        ByVal candidateRows As Object, ByVal countByTx As Object, ByVal membership As Object)
    Dim lastR As Long, dataRows As Long, r As Long
    Dim statusValues As Variant, keyValues As Variant, transactionValues As Variant
    Dim secondTransactionValues As Variant
    Dim storedKey As String, baseKey As String, digestText As String, transactionIDs As String
    Dim candidateID As String
    If ws Is Nothing Then Exit Sub
    lastR = LastUsedRowInSheet(ws)
    If lastR < 2 Then Exit Sub
    dataRows = lastR - 1
    statusValues = ws.Range(ws.Cells(2, statusColumn), ws.Cells(lastR, statusColumn)).Value2
    keyValues = ws.Range(ws.Cells(2, keyColumn), ws.Cells(lastR, keyColumn)).Value2
    transactionValues = ws.Range(ws.Cells(2, transactionColumn), _
                                 ws.Cells(lastR, transactionColumn)).Value2
    If secondTransactionColumn > 0 Then _
        secondTransactionValues = ws.Range(ws.Cells(2, secondTransactionColumn), _
                                           ws.Cells(lastR, secondTransactionColumn)).Value2
    For r = 1 To dataRows
        If StrComp(CellText(AnalysisColumnValue(statusValues, r, dataRows)), _
                   ANALYSIS_STATUS_SHIFT_CONFIRMED, vbTextCompare) = 0 Then
            storedKey = CellText(AnalysisColumnValue(keyValues, r, dataRows))
            baseKey = AnalysisBaseKey(storedKey, digestText)
            If secondTransactionColumn > 0 Then
                transactionIDs = CellText(AnalysisColumnValue(transactionValues, r, dataRows)) & ";" & _
                                 CellText(AnalysisColumnValue(secondTransactionValues, r, dataRows))
            Else
                transactionIDs = CellText(AnalysisColumnValue(transactionValues, r, dataRows))
            End If
            candidateID = CStr(sheetCode) & "|" & baseKey
            RegisterConfirmedAnalysisCandidate candidateRows, countByTx, membership, candidateID, _
                                               sheetCode, r + 1, transactionIDs
        End If
    Next r
End Sub

Private Sub RegisterConfirmedAnalysisCandidate( _
        ByVal candidateRows As Object, ByVal countByTx As Object, ByVal membership As Object, _
        ByVal candidateID As String, ByVal sheetCode As Long, ByVal rowNumber As Long, _
        ByVal transactionIDs As String)
    Dim items As Variant, item As Variant, transactionID As String, membershipKey As String
    If Len(candidateID) = 0 Or candidateRows.Exists(candidateID) Then Exit Sub
    candidateRows.Add candidateID, Array(sheetCode, rowNumber, transactionIDs)
    items = Split(transactionIDs, ";")
    For Each item In items
        transactionID = Trim$(CStr(item))
        If Len(transactionID) > 0 Then
            membershipKey = transactionID & ChrW(30) & candidateID
            If Not membership.Exists(membershipKey) Then
                membership.Add membershipKey, True
                IncrementAnalysisCount countByTx, transactionID
            End If
        End If
    Next item
End Sub

Private Sub CheckAnalysisReviewConflicts(ByVal wsShift As Worksheet, ByVal wsFlow As Worksheet, _
                                         ByRef problems As String)
    Dim candidateRows As Object, countByTx As Object, item As Variant, conflictCount As Long
    Set candidateRows = CreateObject("Scripting.Dictionary")
    Set countByTx = CreateObject("Scripting.Dictionary")
    candidateRows.CompareMode = vbTextCompare
    countByTx.CompareMode = vbTextCompare
    CollectConfirmedAnalysisUsage wsShift, wsFlow, candidateRows, countByTx
    For Each item In countByTx.Keys
        If CLng(countByTx(item)) > 1 Then
            conflictCount = conflictCount + 1
            If conflictCount <= 20 Then
                problems = problems & "�E���͊m�F: ���ID " & CStr(item) & _
                           " ���m�F�ς݌��" & CStr(countByTx(item)) & "���ŏd�����Ă��܂�" & vbCrLf
            End If
        End If
    Next item
    If conflictCount > 20 Then _
        problems = problems & "�E���͊m�F: �d���m�������ق���" & _
                   CStr(conflictCount - 20) & "������܂�" & vbCrLf
End Sub

Private Sub PrepareShiftAnalysisSheet(ByVal ws As Worksheet)
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    If ws Is Nothing Then Exit Sub
    On Error GoTo EH
    ws.Unprotect Password:=TOOL_PASSWORD
    If ws.AutoFilterMode Then ws.AutoFilterMode = False
    ResetWorksheet ws
    SetRowValues ws.Range("A1"), ShiftAnalysisHeaders()
    FormatOutputHeader ws.Range(ws.Cells(1, 1), ws.Cells(1, SHIFT_ANALYSIS_LAST_COL))
    ws.Columns("A:AH").NumberFormatLocal = "@"
    ws.Columns("B:B").NumberFormatLocal = "0"
    ws.Columns("H:H").NumberFormatLocal = "#,##0.########"
    ws.Columns("I:I").NumberFormatLocal = "yyyy/m/d"
    ws.Columns("J:J").NumberFormatLocal = "hh:mm"
    ws.Columns("Q:Q").NumberFormatLocal = "#,##0.########"
    ws.Columns("S:S").NumberFormatLocal = "yyyy/m/d"
    ws.Columns("T:T").NumberFormatLocal = "hh:mm"
    ws.Columns("AA:AA").NumberFormatLocal = "#,##0.########"
    ApplyShiftColumnWidths ws
    ws.Columns("AF:AH").Hidden = True
    ProtectSingleAnalysisSheet ws
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    On Error Resume Next
    EmergencyProtectToolSheet ws
    On Error GoTo 0
    Err.Raise errorNumber, "PrepareShiftAnalysisSheet", errorSource & " / " & errorDescription
End Sub

Private Sub PrepareUnknownAnalysisSheet(ByVal ws As Worksheet)
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    If ws Is Nothing Then Exit Sub
    On Error GoTo EH
    ws.Unprotect Password:=TOOL_PASSWORD
    If ws.AutoFilterMode Then ws.AutoFilterMode = False
    ResetWorksheet ws
    SetRowValues ws.Range("A1"), UnknownAnalysisHeaders()
    FormatOutputHeader ws.Range(ws.Cells(1, 1), ws.Cells(1, UNKNOWN_ANALYSIS_LAST_COL))
    ws.Columns("A:Z").NumberFormatLocal = "@"
    ws.Columns("B:B").NumberFormatLocal = "0"
    ws.Columns("D:D").NumberFormatLocal = "yyyy/m/d"
    ws.Columns("E:E").NumberFormatLocal = "hh:mm"
    ws.Columns("M:N").NumberFormatLocal = "#,##0.########"
    ws.Columns("R:R").NumberFormatLocal = "0"
    ApplyUnknownColumnWidths ws
    ws.Columns("X:Z").Hidden = True
    ProtectSingleAnalysisSheet ws
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    On Error Resume Next
    EmergencyProtectToolSheet ws
    On Error GoTo 0
    Err.Raise errorNumber, "PrepareUnknownAnalysisSheet", errorSource & " / " & errorDescription
End Sub

Private Sub FinalizeShiftAnalysisSheet(ByVal ws As Worksheet, ByVal dataCount As Long)
    Dim lastR As Long
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    If ws Is Nothing Then Exit Sub
    On Error GoTo EH
    ws.Unprotect Password:=TOOL_PASSWORD
    lastR = dataCount + 1
    FormatOutputHeader ws.Range(ws.Cells(1, 1), ws.Cells(1, SHIFT_ANALYSIS_LAST_COL))
    If dataCount > 1 Then SortShiftAnalysis ws, lastR
    ApplyShiftColumnWidths ws
    ws.Columns("AF:AH").Hidden = True
    If dataCount > 0 Then
        With ws.Range(ws.Cells(2, 1), ws.Cells(lastR, SHIFT_ANALYSIS_LAST_COL))
            .VerticalAlignment = xlTop
            .WrapText = False
        End With
        If dataCount <= 10000 Then
            With ws.Range(ws.Cells(2, 1), ws.Cells(lastR, SHIFT_ANALYSIS_LAST_COL)).Borders
                .Color = RGB(226, 232, 240)
                .LineStyle = xlContinuous
            End With
        End If
        ws.Range(ws.Cells(2, 29), ws.Cells(lastR, 31)).WrapText = True
        ws.Range(ws.Cells(2, SHIFT_ANALYSIS_STATUS_COL), _
                 ws.Cells(lastR, SHIFT_ANALYSIS_MEMO_COL)).Interior.Color = RGB(254, 249, 195)
        ws.Rows("2:" & CStr(lastR)).RowHeight = 32
    End If
    If ws.AutoFilterMode Then ws.AutoFilterMode = False
    ws.Range(ws.Cells(1, 1), ws.Cells(lastR, SHIFT_ANALYSIS_LAST_COL)).AutoFilter
    ApplyAnalysisReviewValidation ws, SHIFT_ANALYSIS_STATUS_COL, SHIFT_ANALYSIS_MEMO_COL, lastR
    SafeFreezeOutputHeader ws
    ProtectSingleAnalysisSheet ws
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    On Error Resume Next
    EmergencyProtectToolSheet ws
    On Error GoTo 0
    Err.Raise errorNumber, "FinalizeShiftAnalysisSheet", errorSource & " / " & errorDescription
End Sub

Private Sub FinalizeUnknownAnalysisSheet(ByVal ws As Worksheet, ByVal dataCount As Long)
    Dim lastR As Long
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    If ws Is Nothing Then Exit Sub
    On Error GoTo EH
    ws.Unprotect Password:=TOOL_PASSWORD
    lastR = dataCount + 1
    FormatOutputHeader ws.Range(ws.Cells(1, 1), ws.Cells(1, UNKNOWN_ANALYSIS_LAST_COL))
    If dataCount > 1 Then SortUnknownAnalysis ws, lastR
    ApplyUnknownColumnWidths ws
    ws.Columns("X:Z").Hidden = True
    If dataCount > 0 Then
        With ws.Range(ws.Cells(2, 1), ws.Cells(lastR, UNKNOWN_ANALYSIS_LAST_COL))
            .VerticalAlignment = xlTop
            .WrapText = False
        End With
        If dataCount <= 10000 Then
            With ws.Range(ws.Cells(2, 1), ws.Cells(lastR, UNKNOWN_ANALYSIS_LAST_COL)).Borders
                .Color = RGB(226, 232, 240)
                .LineStyle = xlContinuous
            End With
        End If
        ws.Range(ws.Cells(2, 20), ws.Cells(lastR, 22)).WrapText = True
        ws.Range(ws.Cells(2, UNKNOWN_ANALYSIS_STATUS_COL), _
                 ws.Cells(lastR, UNKNOWN_ANALYSIS_MEMO_COL)).Interior.Color = RGB(254, 249, 195)
        ws.Rows("2:" & CStr(lastR)).RowHeight = 32
    End If
    If ws.AutoFilterMode Then ws.AutoFilterMode = False
    ws.Range(ws.Cells(1, 1), ws.Cells(lastR, UNKNOWN_ANALYSIS_LAST_COL)).AutoFilter
    ApplyAnalysisReviewValidation ws, UNKNOWN_ANALYSIS_STATUS_COL, UNKNOWN_ANALYSIS_MEMO_COL, lastR
    SafeFreezeOutputHeader ws
    ProtectSingleAnalysisSheet ws
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    On Error Resume Next
    EmergencyProtectToolSheet ws
    On Error GoTo 0
    Err.Raise errorNumber, "FinalizeUnknownAnalysisSheet", errorSource & " / " & errorDescription
End Sub

Private Sub ApplyShiftColumnWidths(ByVal ws As Worksheet)
    ws.Columns("A:A").ColumnWidth = 8
    ws.Columns("B:B").ColumnWidth = 8
    ws.Columns("C:G").ColumnWidth = 16
    ws.Columns("H:H").ColumnWidth = 14
    ws.Columns("I:J").ColumnWidth = 13
    ws.Columns("K:P").ColumnWidth = 16
    ws.Columns("Q:Q").ColumnWidth = 15
    ws.Columns("R:R").ColumnWidth = 24
    ws.Columns("S:T").ColumnWidth = 13
    ws.Columns("U:Z").ColumnWidth = 16
    ws.Columns("AA:AA").ColumnWidth = 15
    ws.Columns("AB:AB").ColumnWidth = 24
    ws.Columns("AC:AC").ColumnWidth = 48
    ws.Columns("AD:AD").ColumnWidth = 16
    ws.Columns("AE:AE").ColumnWidth = 36
End Sub

Private Sub ApplyUnknownColumnWidths(ByVal ws As Worksheet)
    ws.Columns("A:C").ColumnWidth = 14
    ws.Columns("D:E").ColumnWidth = 13
    ws.Columns("F:F").ColumnWidth = 16
    ws.Columns("G:L").ColumnWidth = 16
    ws.Columns("M:N").ColumnWidth = 15
    ws.Columns("O:Q").ColumnWidth = 20
    ws.Columns("R:S").ColumnWidth = 14
    ws.Columns("T:T").ColumnWidth = 52
    ws.Columns("U:U").ColumnWidth = 16
    ws.Columns("V:V").ColumnWidth = 36
    ws.Columns("W:W").ColumnWidth = 14
End Sub

Public Sub ApplyAnalysisReviewValidation(ByVal ws As Worksheet, ByVal statusColumn As Long, _
                                          ByVal memoColumn As Long, ByVal lastR As Long)
    Dim statusRange As Range
    If ws Is Nothing Then Exit Sub
    ws.Cells.Locked = True
    If lastR >= 2 Then
        Set statusRange = ws.Range(ws.Cells(2, statusColumn), ws.Cells(lastR, statusColumn))
        statusRange.Locked = False
        ws.Range(ws.Cells(2, memoColumn), ws.Cells(lastR, memoColumn)).Locked = False
        If StrComp(ws.Name, SH_ANALYSIS_UNKNOWN, vbTextCompare) = 0 Then
            ApplyUnknownAnalysisStatusValidation statusRange
        Else
            ApplyValidationList statusRange, NM_LST_ANALYSIS_SHIFT_STATUS, xlIMEModeOff, False
        End If
        ApplyAnalysisMemoValidation ws.Range(ws.Cells(2, memoColumn), ws.Cells(lastR, memoColumn))
    End If
End Sub

Private Sub ApplyUnknownAnalysisStatusValidation(ByVal target As Range)
    If target Is Nothing Then Exit Sub
    With target.Validation
        .Delete
        .Add Type:=xlValidateList, AlertStyle:=xlValidAlertStop, Operator:=xlBetween, _
             Formula1:=AnalysisReviewValidationFormula(SH_ANALYSIS_UNKNOWN)
        .IgnoreBlank = True
        .InCellDropdown = True
        .ShowError = True
        .ErrorTitle = "�m�F�󋵂�I�����Ă�������"
        .ErrorMessage = "�����s�����Ǝg�r�s�����ɑΉ�����m�F�󋵂�I�����Ă��������B"
    End With
    On Error Resume Next
    target.Validation.IMEMode = xlIMEModeOff
    On Error GoTo 0
End Sub

Private Function AnalysisReviewValidationFormula(ByVal sheetName As String) As String
    If StrComp(sheetName, SH_ANALYSIS_UNKNOWN, vbTextCompare) = 0 Then
        AnalysisReviewValidationFormula = "=INDIRECT(IF($C2=""�����s�����"",""" & _
            NM_LST_ANALYSIS_SOURCE_STATUS & """,""" & NM_LST_ANALYSIS_USE_STATUS & """))"
    Else
        AnalysisReviewValidationFormula = "=" & NM_LST_ANALYSIS_SHIFT_STATUS
    End If
End Function

Private Sub ApplyAnalysisMemoValidation(ByVal target As Range)
    If target Is Nothing Then Exit Sub
    With target.Validation
        .Delete
        .Add Type:=xlValidateTextLength, AlertStyle:=xlValidAlertStop, _
             Operator:=xlLessEqual, Formula1:=CStr(ANALYSIS_REVIEW_MEMO_MAX)
        .IgnoreBlank = True
        .ShowError = True
        .ErrorTitle = "�m�F�����̕��������m�F���Ă�������"
        .ErrorMessage = "�m�F������" & CStr(ANALYSIS_REVIEW_MEMO_MAX) & "�����ȓ��œ��͂��Ă��������B"
    End With
    'IME������Ȃ�Excel�ł��������������̂��̂͗L���ɂ���B
    On Error Resume Next
    target.Validation.IMEMode = xlIMEModeHiragana
    On Error GoTo 0
End Sub

Public Sub ProtectSingleAnalysisSheet(ByVal ws As Worksheet)
    Dim workbookWasSaved As Boolean
    Dim errorNumber As Long, errorDescription As String
    If ws Is Nothing Then Exit Sub
    workbookWasSaved = ThisWorkbook.Saved
    On Error GoTo EH
    ws.Unprotect Password:=TOOL_PASSWORD
    RestoreToolSheetScrollArea ws
    LockToolShapes ws, False
    ws.Protect Password:=TOOL_PASSWORD, DrawingObjects:=True, Contents:=True, Scenarios:=False, _
               UserInterfaceOnly:=True, AllowFiltering:=True, AllowSorting:=False, _
               AllowFormattingCells:=False, AllowFormattingColumns:=False, AllowFormattingRows:=False
    ws.EnableSelection = xlNoRestrictions
    If Not ws.ProtectContents Or Not ws.ProtectDrawingObjects Then _
        Err.Raise vbObjectError + 4614, "ProtectSingleAnalysisSheet", _
                  ws.Name & "��ی�ł��܂���ł����B"
    VerifyToolShapeSecurity ws, True, False
    If workbookWasSaved Then ThisWorkbook.Saved = True
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    EmergencyProtectToolSheet ws
    If workbookWasSaved Then ThisWorkbook.Saved = True
    Err.Raise errorNumber, "ProtectSingleAnalysisSheet(" & ws.Name & ")", errorDescription
End Sub

Private Sub SortShiftAnalysis(ByVal ws As Worksheet, ByVal lastR As Long)
    With ws.Sort
        .SortFields.Clear
        .SortFields.Add Key:=ws.Range(ws.Cells(2, 2), ws.Cells(lastR, 2)), _
                        SortOn:=xlSortOnValues, Order:=xlDescending, DataOption:=xlSortNormal
        .SortFields.Add Key:=ws.Range(ws.Cells(2, 9), ws.Cells(lastR, 9)), _
                        SortOn:=xlSortOnValues, Order:=xlAscending, DataOption:=xlSortNormal
        .SortFields.Add Key:=ws.Range(ws.Cells(2, 19), ws.Cells(lastR, 19)), _
                        SortOn:=xlSortOnValues, Order:=xlAscending, DataOption:=xlSortNormal
        .SetRange ws.Range(ws.Cells(1, 1), ws.Cells(lastR, SHIFT_ANALYSIS_LAST_COL))
        .Header = xlYes
        .Apply
    End With
End Sub

Private Sub SortUnknownAnalysis(ByVal ws As Worksheet, ByVal lastR As Long)
    With ws.Sort
        .SortFields.Clear
        .SortFields.Add Key:=ws.Range(ws.Cells(2, 2), ws.Cells(lastR, 2)), _
                        SortOn:=xlSortOnValues, Order:=xlDescending, DataOption:=xlSortNormal
        .SortFields.Add Key:=ws.Range(ws.Cells(2, 4), ws.Cells(lastR, 4)), _
                        SortOn:=xlSortOnValues, Order:=xlAscending, DataOption:=xlSortNormal
        .SetRange ws.Range(ws.Cells(1, 1), ws.Cells(lastR, UNKNOWN_ANALYSIS_LAST_COL))
        .Header = xlYes
        .Apply
    End With
End Sub

Public Function CaptureAnalysisReviews(ByVal ws As Worksheet, ByVal statusColumn As Long, _
                                        ByVal memoColumn As Long, ByVal keyColumn As Long) As Object
    Dim reviews As Object
    Dim lastR As Long, r As Long, dataRows As Long
    Dim keyText As String, baseKey As String, evidenceDigest As String
    Dim statusText As String, memoText As String, kindText As String
    Dim firstValues As Variant, statusValues As Variant, memoValues As Variant, keyValues As Variant
    Dim kindValues As Variant
    Dim reviewRange As Range, formulaCells As Range, errorCells As Range
    Dim seenKeys As Object
    Set reviews = CreateObject("Scripting.Dictionary")
    reviews.CompareMode = vbTextCompare
    Set seenKeys = CreateObject("Scripting.Dictionary")
    seenKeys.CompareMode = vbTextCompare
    If ws Is Nothing Then
        Set CaptureAnalysisReviews = reviews
        Exit Function
    End If
    lastR = LastUsedRowInSheet(ws)
    If lastR < 2 Then
        Set CaptureAnalysisReviews = reviews
        Exit Function
    End If
    dataRows = lastR - 1
    Set reviewRange = Union( _
        ws.Range(ws.Cells(2, statusColumn), ws.Cells(lastR, statusColumn)), _
        ws.Range(ws.Cells(2, memoColumn), ws.Cells(lastR, memoColumn)), _
        ws.Range(ws.Cells(2, keyColumn), ws.Cells(lastR, keyColumn)))
    On Error Resume Next
    Err.Clear
    Set formulaCells = reviewRange.SpecialCells(xlCellTypeFormulas)
    Err.Clear
    Set errorCells = reviewRange.SpecialCells(xlCellTypeConstants, xlErrors)
    Err.Clear
    On Error GoTo 0
    If Not formulaCells Is Nothing Then _
        Err.Raise vbObjectError + 4621, "CaptureAnalysisReviews", _
                  ws.Name & "�̊m�F���܂��͓����L�[�ɐ���������܂��B"
    If Not errorCells Is Nothing Then _
        Err.Raise vbObjectError + 4622, "CaptureAnalysisReviews", _
                  ws.Name & "�̊m�F���܂��͓����L�[��Excel�G���[�l������܂��B"
    firstValues = ws.Range(ws.Cells(2, 1), ws.Cells(lastR, 1)).Value2
    statusValues = ws.Range(ws.Cells(2, statusColumn), ws.Cells(lastR, statusColumn)).Value2
    memoValues = ws.Range(ws.Cells(2, memoColumn), ws.Cells(lastR, memoColumn)).Value2
    keyValues = ws.Range(ws.Cells(2, keyColumn), ws.Cells(lastR, keyColumn)).Value2
    If StrComp(ws.Name, SH_ANALYSIS_UNKNOWN, vbTextCompare) = 0 Then _
        kindValues = ws.Range(ws.Cells(2, 3), ws.Cells(lastR, 3)).Value2
    For r = 1 To dataRows
        keyText = CellText(AnalysisColumnValue(keyValues, r, dataRows))
        If Len(keyText) > 0 Then
            baseKey = AnalysisBaseKey(keyText, evidenceDigest)
            If Len(baseKey) = 0 Then _
                Err.Raise vbObjectError + 4623, "CaptureAnalysisReviews", _
                          ws.Name & " " & CStr(r + 1) & "�s�ڂ̊m�F�L�[�{�̂�����܂���B"
            If seenKeys.Exists(baseKey) Then _
                Err.Raise vbObjectError + 4617, "CaptureAnalysisReviews", _
                          ws.Name & "�̊m�F�L�[���d�����Ă��܂�: " & baseKey
            seenKeys.Add baseKey, True
            statusText = CellText(AnalysisColumnValue(statusValues, r, dataRows))
            If Len(statusText) = 0 Then statusText = ANALYSIS_STATUS_UNREVIEWED
            memoText = CellText(AnalysisColumnValue(memoValues, r, dataRows))
            kindText = vbNullString
            If StrComp(ws.Name, SH_ANALYSIS_UNKNOWN, vbTextCompare) = 0 Then _
                kindText = CellText(AnalysisColumnValue(kindValues, r, dataRows))
            If Not IsAnalysisReviewStatusForSheet(ws.Name, statusText, kindText) Then _
                Err.Raise vbObjectError + 4615, "CaptureAnalysisReviews", _
                          ws.Name & " " & CStr(r + 1) & _
                          "�s�ڂ̊m�F�󋵂��s�̎�ނɓK�����܂���: " & statusText
            If Len(memoText) > ANALYSIS_REVIEW_MEMO_MAX Then _
                Err.Raise vbObjectError + 4616, "CaptureAnalysisReviews", _
                          ws.Name & " " & CStr(r + 1) & "�s�ڂ̊m�F������" & _
                          CStr(ANALYSIS_REVIEW_MEMO_MAX) & "�����𒴂��Ă��܂��B"
            '����̖��m�F�E�����Ȃ��͍Đ������������ɂȂ邽�ߎ����֕ێ����Ȃ��B
            '���p�҂����ۂɊm�F�����s������ޔ����A��K�͈Č��̃������g�p��}����B
            If statusText <> ANALYSIS_STATUS_UNREVIEWED Or Len(memoText) > 0 Then
                reviews.Add baseKey, Array(statusText, memoText, evidenceDigest)
            End If
        ElseIf HasText(AnalysisColumnValue(firstValues, r, dataRows)) Or _
               HasText(AnalysisColumnValue(statusValues, r, dataRows)) Or _
               HasText(AnalysisColumnValue(memoValues, r, dataRows)) Then
            Err.Raise vbObjectError + 4619, "CaptureAnalysisReviews", _
                      ws.Name & " " & CStr(r + 1) & "�s�ڂɊm�F�L�[������܂���B"
        End If
    Next r
    Set CaptureAnalysisReviews = reviews
End Function

Public Function AnalysisReviewValues(ByVal reviews As Object, ByVal keyText As String, _
                                     ByVal currentEvidenceDigest As String) As Variant
    Dim storedValues As Variant, storedDigest As String
    If Not reviews Is Nothing Then
        If reviews.Exists(keyText) Then
            storedValues = reviews(keyText)
            If UBound(storedValues) >= 2 Then storedDigest = CStr(storedValues(2))
            If Len(currentEvidenceDigest) > 0 And _
               StrComp(storedDigest, currentEvidenceDigest, vbBinaryCompare) <> 0 Then
                AnalysisReviewValues = Array(ANALYSIS_STATUS_FOLLOWUP, CStr(storedValues(1)), True)
            Else
                AnalysisReviewValues = Array(CStr(storedValues(0)), CStr(storedValues(1)), False)
            End If
            Exit Function
        End If
    End If
    AnalysisReviewValues = Array(ANALYSIS_STATUS_UNREVIEWED, vbNullString, False)
End Function

Private Function IsAnalysisReviewStatusForSheet(ByVal sheetName As String, _
                                                ByVal statusText As String, _
                                                ByVal kindText As String) As Boolean
    statusText = Trim$(statusText)
    If StrComp(sheetName, SH_ANALYSIS_SHIFT, vbTextCompare) = 0 Or _
       StrComp(sheetName, SH_ANALYSIS_FLOW, vbTextCompare) = 0 Then
        Select Case statusText
            Case ANALYSIS_STATUS_UNREVIEWED, ANALYSIS_STATUS_SHIFT_CONFIRMED, _
                 ANALYSIS_STATUS_EXCLUDED, ANALYSIS_STATUS_FOLLOWUP
                IsAnalysisReviewStatusForSheet = True
        End Select
    ElseIf StrComp(sheetName, SH_ANALYSIS_UNKNOWN, vbTextCompare) = 0 Then
        If StrComp(kindText, "�����s�����", vbTextCompare) = 0 Then
            Select Case statusText
                Case ANALYSIS_STATUS_UNREVIEWED, ANALYSIS_STATUS_SOURCE_CONFIRMED, _
                     ANALYSIS_STATUS_EXCLUDED, ANALYSIS_STATUS_FOLLOWUP
                    IsAnalysisReviewStatusForSheet = True
            End Select
        ElseIf StrComp(kindText, "�g�r�s�����", vbTextCompare) = 0 Then
            Select Case statusText
                Case ANALYSIS_STATUS_UNREVIEWED, ANALYSIS_STATUS_USE_CONFIRMED, _
                     ANALYSIS_STATUS_EXCLUDED, ANALYSIS_STATUS_FOLLOWUP
                    IsAnalysisReviewStatusForSheet = True
            End Select
        End If
    Else
        IsAnalysisReviewStatusForSheet = IsAnalysisReviewStatus(statusText)
    End If
End Function

Public Sub CheckSingleAnalysisSheet(ByVal ws As Worksheet, ByVal statusColumn As Long, _
                                     ByVal memoColumn As Long, ByVal keyColumn As Long, _
                                     ByVal labelText As String, ByRef problems As String)
    Dim lastR As Long, r As Long, dataRows As Long
    Dim keyText As String, baseKey As String, evidenceDigest As String
    Dim statusText As String, memoText As String, kindText As String
    Dim keys As Object
    Dim statusValues As Variant, memoValues As Variant, keyValues As Variant, kindValues As Variant
    Dim validationFormula As String
    Dim lockedValue As Variant
    If ws Is Nothing Then Exit Sub
    Set keys = CreateObject("Scripting.Dictionary")
    keys.CompareMode = vbTextCompare
    If Not ws.ProtectContents Then problems = problems & "�E" & labelText & "���ی삳��Ă��܂���" & vbCrLf
    If ws.Protection.AllowSorting Then _
        problems = problems & "�E" & labelText & "�ŕی쉺�̕��בւ����L���ł��B���̍����s����邽�ߖ����ɂ��Ă�������" & vbCrLf
    lastR = LastUsedRowInSheet(ws)
    If lastR >= 2 Then
        dataRows = lastR - 1
        validationFormula = AnalysisReviewValidationFormula(ws.Name)
        CheckAnalysisValidationRange ws.Range(ws.Cells(2, statusColumn), ws.Cells(lastR, statusColumn)), _
                                     xlValidateList, validationFormula, _
                                     labelText & "�̊m�F��", problems
        CheckAnalysisValidationRange ws.Range(ws.Cells(2, memoColumn), ws.Cells(lastR, memoColumn)), _
                                     xlValidateTextLength, CStr(ANALYSIS_REVIEW_MEMO_MAX), _
                                     labelText & "�̊m�F����", problems, xlLessEqual
        lockedValue = ws.Range(ws.Cells(2, statusColumn), ws.Cells(lastR, statusColumn)).Locked
        If IsNull(lockedValue) Then
            problems = problems & "�E" & labelText & "�̊m�F�󋵗�Ƀ��b�N��Ԃ����݂��Ă��܂�" & vbCrLf
        ElseIf CBool(lockedValue) Then
            problems = problems & "�E" & labelText & "�̊m�F�󋵗�ɕҏW�s�Z��������܂�" & vbCrLf
        End If
        lockedValue = ws.Range(ws.Cells(2, memoColumn), ws.Cells(lastR, memoColumn)).Locked
        If IsNull(lockedValue) Then
            problems = problems & "�E" & labelText & "�̊m�F������Ƀ��b�N��Ԃ����݂��Ă��܂�" & vbCrLf
        ElseIf CBool(lockedValue) Then
            problems = problems & "�E" & labelText & "�̊m�F������ɕҏW�s�Z��������܂�" & vbCrLf
        End If
        lockedValue = ws.Range(ws.Cells(2, keyColumn), ws.Cells(lastR, keyColumn)).Locked
        If IsNull(lockedValue) Then
            problems = problems & "�E" & labelText & "�̊m�F�L�[��Ƀ��b�N��Ԃ����݂��Ă��܂�" & vbCrLf
        ElseIf Not CBool(lockedValue) Then
            problems = problems & "�E" & labelText & "�̊m�F�L�[��ɕҏW�\�Z��������܂�" & vbCrLf
        End If
        statusValues = ws.Range(ws.Cells(2, statusColumn), ws.Cells(lastR, statusColumn)).Value2
        memoValues = ws.Range(ws.Cells(2, memoColumn), ws.Cells(lastR, memoColumn)).Value2
        keyValues = ws.Range(ws.Cells(2, keyColumn), ws.Cells(lastR, keyColumn)).Value2
        If StrComp(ws.Name, SH_ANALYSIS_UNKNOWN, vbTextCompare) = 0 Then _
            kindValues = ws.Range(ws.Cells(2, 3), ws.Cells(lastR, 3)).Value2
    End If
    For r = 1 To dataRows
        If Len(problems) >= ANALYSIS_CHECK_MAX_DETAIL_CHARS Then Exit For
        baseKey = vbNullString
        evidenceDigest = vbNullString
        keyText = CellText(AnalysisColumnValue(keyValues, r, dataRows))
        statusText = CellText(AnalysisColumnValue(statusValues, r, dataRows))
        memoText = CellText(AnalysisColumnValue(memoValues, r, dataRows))
        kindText = vbNullString
        If StrComp(ws.Name, SH_ANALYSIS_UNKNOWN, vbTextCompare) = 0 Then _
            kindText = CellText(AnalysisColumnValue(kindValues, r, dataRows))
        If Len(keyText) = 0 Then
            problems = problems & "�E" & labelText & " " & CStr(r + 1) & "�s: �m�F�L�[�Ȃ�" & vbCrLf
        Else
            baseKey = AnalysisBaseKey(keyText, evidenceDigest)
        End If
        If Len(keyText) > 0 And Len(baseKey) = 0 Then
            problems = problems & "�E" & labelText & " " & CStr(r + 1) & "�s: �m�F�L�[�{�̂Ȃ�" & vbCrLf
        ElseIf Len(keyText) > 0 And Not IsAnalysisEvidenceDigest(evidenceDigest) Then
            problems = problems & "�E" & labelText & " " & CStr(r + 1) & "�s: ���������s��" & vbCrLf
        ElseIf Len(keyText) > 0 And keys.Exists(baseKey) Then
            problems = problems & "�E" & labelText & " " & CStr(r + 1) & "�s: �m�F�L�[�d��" & vbCrLf
        ElseIf Len(keyText) > 0 Then
            keys.Add baseKey, True
        End If
        If Not IsAnalysisReviewStatusForSheet(ws.Name, statusText, kindText) Then _
            problems = problems & "�E" & labelText & " " & CStr(r + 1) & _
                       "�s: �m�F�󋵂��s�̎�ނɕs�K��" & vbCrLf
        If Len(memoText) > ANALYSIS_REVIEW_MEMO_MAX Then _
            problems = problems & "�E" & labelText & " " & CStr(r + 1) & "�s: �m�F�������������܂�" & vbCrLf
    Next r
End Sub

Private Function IsAnalysisEvidenceDigest(ByVal evidenceDigest As String) As Boolean
    Dim i As Long, characterText As String
    If Len(evidenceDigest) <> 17 Or Mid$(evidenceDigest, 9, 1) <> "-" Then Exit Function
    For i = 1 To Len(evidenceDigest)
        If i <> 9 Then
            characterText = UCase$(Mid$(evidenceDigest, i, 1))
            If InStr(1, "0123456789ABCDEF", characterText, vbBinaryCompare) = 0 Then Exit Function
        End If
    Next i
    IsAnalysisEvidenceDigest = True
End Function

Private Function AnalysisColumnValue(ByRef columnData As Variant, ByVal dataIndex As Long, _
                                     ByVal dataRows As Long) As Variant
    If dataRows = 1 Then
        AnalysisColumnValue = columnData
    Else
        AnalysisColumnValue = columnData(dataIndex, 1)
    End If
End Function

Private Sub CheckAnalysisValidationRange(ByVal target As Range, ByVal expectedType As Long, _
                                         ByVal expectedFormula As String, ByVal labelText As String, _
                                         ByRef problems As String, _
                                         Optional ByVal expectedOperator As Long = 0)
    Dim validationCells As Range, coveredCells As Range, cell As Range
    Dim chunkRange As Range
    Dim typeValue As Variant, formulaValue As Variant, showErrorValue As Variant
    Dim operatorValue As Variant
    Dim issueText As String
    Dim aggregateReadable As Boolean
    Dim uniformCriteria As Boolean, uniformCriteriaKnown As Boolean
    Dim rowOffset As Long, chunkRowCount As Long, problemsLengthBefore As Long
    On Error GoTo EH
    If target Is Nothing Then issueText = "�Ώ۔͈͂Ȃ�": GoTo InvalidValidation
    '1�Z��Range��SpecialCells�̓V�[�g�S�̂�Ԃ����Ƃ����邽�߁A�����Z�������Ŏg���B
    If CDbl(target.CountLarge) > 1 Then
        On Error Resume Next
        Err.Clear
        Set validationCells = target.SpecialCells(xlCellTypeAllValidation)
        If Not validationCells Is Nothing Then Set coveredCells = Intersect(target, validationCells)
        Err.Clear
        On Error GoTo EH
        If coveredCells Is Nothing Then issueText = "���ݒ�": GoTo InvalidValidation
        If CDbl(coveredCells.CountLarge) <> CDbl(target.CountLarge) Then _
            issueText = "�ꕔ�Z���ɖ��ݒ�": GoTo InvalidValidation

        uniformCriteria = ValidationRangeHasUniformCriteria(target, uniformCriteriaKnown)

        On Error Resume Next
        Err.Clear
        typeValue = target.Validation.Type
        aggregateReadable = (Err.Number = 0 And Not IsNull(typeValue))
        If aggregateReadable Then
            formulaValue = target.Validation.Formula1
            If Err.Number <> 0 Or IsNull(formulaValue) Then aggregateReadable = False
            Err.Clear
            showErrorValue = target.Validation.ShowError
            If Err.Number <> 0 Or IsNull(showErrorValue) Then aggregateReadable = False
            If expectedOperator <> 0 Then
                Err.Clear
                operatorValue = target.Validation.Operator
                If Err.Number <> 0 Or IsNull(operatorValue) Then aggregateReadable = False
            End If
        End If
        Err.Clear
        On Error GoTo EH
        If aggregateReadable Then
            If CLng(typeValue) <> expectedType Then _
                issueText = target.Cells(1, 1).Address(False, False) & "�̎�ނ��s��v": GoTo InvalidValidation
            If Not AnalysisValidationFormulaMatches(target.Cells(1, 1), _
                                                     CellText(formulaValue), expectedType, expectedFormula) Then _
                issueText = target.Cells(1, 1).Address(False, False) & "�̐������s��v": GoTo InvalidValidation
            If Not CBool(showErrorValue) Then _
                issueText = target.Cells(1, 1).Address(False, False) & "�̃G���[�\��������": GoTo InvalidValidation
            If expectedOperator <> 0 Then
                If CLng(operatorValue) <> expectedOperator Then _
                    issueText = target.Cells(1, 1).Address(False, False) & "�̉��Z�q���s��v": GoTo InvalidValidation
            End If
            If uniformCriteriaKnown And uniformCriteria Then Exit Sub
        End If
    End If

    If CDbl(target.Rows.CountLarge) > VALIDATION_CHECK_CHUNK_ROWS Then
            '�ő�20���s��2,000�s�P�ʂɕ������A����u���b�N�͈ꊇ�m�F����B
            '���݁E�擾�s�\�u���b�N�����Z���ʂ֗��Ƃ��A�r��1�Z���̔j�����������Ȃ��B
            For rowOffset = 1 To CLng(target.Rows.CountLarge) Step VALIDATION_CHECK_CHUNK_ROWS
                chunkRowCount = Application.Min(VALIDATION_CHECK_CHUNK_ROWS, _
                                                CLng(target.Rows.CountLarge) - rowOffset + 1)
                Set chunkRange = target.Rows(rowOffset).Resize(chunkRowCount, target.Columns.Count)
                problemsLengthBefore = Len(problems)
                CheckAnalysisValidationRange chunkRange, expectedType, expectedFormula, _
                                             labelText, problems, expectedOperator
                If Len(problems) > problemsLengthBefore Then Exit Sub
            Next rowOffset
            Exit Sub
    End If

    For Each cell In target.Cells
        issueText = AnalysisValidationCellIssue(cell, expectedType, expectedFormula, expectedOperator)
        If Len(issueText) > 0 Then GoTo InvalidValidation
    Next cell
    Exit Sub
InvalidValidation:
    problems = problems & "�E" & labelText & "�̓��͋K��: " & issueText & vbCrLf
    Exit Sub
EH:
    problems = problems & "�E" & labelText & "�̓��͋K�����m�F�ł��܂���: " & Err.Description & vbCrLf
    Err.Clear
End Sub

Private Function AnalysisValidationCellIssue(ByVal cell As Range, ByVal expectedType As Long, _
                                             ByVal expectedFormula As String, _
                                             Optional ByVal expectedOperator As Long = 0) As String
    Dim typeValue As Variant, formulaValue As Variant, showErrorValue As Variant
    Dim operatorValue As Variant
    Dim addressText As String
    On Error GoTo EH
    If cell Is Nothing Then
        AnalysisValidationCellIssue = "�ΏۃZ���Ȃ�"
        Exit Function
    End If
    addressText = cell.Address(False, False)
    typeValue = cell.Validation.Type
    If IsNull(typeValue) Then
        AnalysisValidationCellIssue = addressText & "�̎�ނ��擾�s�\"
        Exit Function
    End If
    If CLng(typeValue) <> expectedType Then
        AnalysisValidationCellIssue = addressText & "�̎�ނ��s��v"
        Exit Function
    End If
    If expectedType <> xlValidateList And expectedType <> xlValidateTextLength Then Exit Function
    formulaValue = cell.Validation.Formula1
    showErrorValue = cell.Validation.ShowError
    If IsNull(formulaValue) Then
        AnalysisValidationCellIssue = addressText & "�̐������擾�s�\"
        Exit Function
    End If
    If Not AnalysisValidationFormulaMatches(cell, CellText(formulaValue), _
                                            expectedType, expectedFormula) Then
        AnalysisValidationCellIssue = addressText & "�̐������s��v�i����: " & _
                                      ValidationFormulaDiagnostic(expectedFormula) & _
                                      " / ����: " & _
                                      ValidationFormulaDiagnostic(CellText(formulaValue)) & "�j"
        Exit Function
    End If
    If IsNull(showErrorValue) Then
        AnalysisValidationCellIssue = addressText & "�̃G���[�\���ݒ���擾�s�\"
    ElseIf Not CBool(showErrorValue) Then
        AnalysisValidationCellIssue = addressText & "�̃G���[�\��������"
    End If
    If Len(AnalysisValidationCellIssue) > 0 Then Exit Function
    If expectedOperator <> 0 Then
        operatorValue = cell.Validation.Operator
        If IsNull(operatorValue) Then
            AnalysisValidationCellIssue = addressText & "�̉��Z�q���擾�s�\"
        ElseIf CLng(operatorValue) <> expectedOperator Then
            AnalysisValidationCellIssue = addressText & "�̉��Z�q���s��v"
        End If
    End If
    Exit Function
EH:
    If Len(addressText) = 0 Then addressText = "�ΏۃZ��"
    AnalysisValidationCellIssue = addressText & "���m�F�ł��܂���: " & Err.Description
    Err.Clear
End Function

Private Function AnalysisValidationFormulaMatches(ByVal targetCell As Range, _
                                                  ByVal actualFormulaText As String, _
                                                  ByVal expectedType As Long, _
                                                  ByVal expectedFormulaText As String) As Boolean
    Dim actualFormula As String, expectedFormula As String
    If targetCell Is Nothing Then Exit Function
    actualFormula = NormalizedValidationFormulaText(actualFormulaText)
    expectedFormula = NormalizedValidationFormulaText(expectedFormulaText)
    If expectedType = xlValidateList And _
       StrComp(expectedFormula, UCase$(NM_LST_ANALYSIS_SHIFT_STATUS), vbBinaryCompare) = 0 Then
        AnalysisValidationFormulaMatches = _
            ValidationListSourceMatches(targetCell, actualFormulaText, NM_LST_ANALYSIS_SHIFT_STATUS)
        Exit Function
    End If
    If StrComp(actualFormula, expectedFormula, vbBinaryCompare) = 0 Then
        AnalysisValidationFormulaMatches = True
        Exit Function
    End If
    '�s�����o���̎��͍s���ΎQ�ƂȂ̂ŁAExcel���e�s�֓W�J���ĕԂ��\�L�����e����B
    expectedFormula = Replace(expectedFormula, "$C2", "$C" & CStr(targetCell.Row), 1, -1, vbTextCompare)
    AnalysisValidationFormulaMatches = _
        (StrComp(actualFormula, expectedFormula, vbBinaryCompare) = 0)
End Function

Private Function NormalizedValidationFormulaText(ByVal formulaText As String) As String
    Dim normalizedText As String
    normalizedText = Trim$(formulaText)
    If Len(normalizedText) > 0 Then
        If Left$(normalizedText, 1) = "=" Then normalizedText = Mid$(normalizedText, 2)
    End If
    If Len(normalizedText) > 0 Then
        'Microsoft 365�n���Öق̌������Z�q��t����Formula1��Ԃ��\�L�����z������B
        If Left$(normalizedText, 1) = "@" Then normalizedText = Mid$(normalizedText, 2)
    End If
    normalizedText = Replace(normalizedText, " ", "")
    normalizedText = Replace(normalizedText, "�@", "")
    NormalizedValidationFormulaText = UCase$(normalizedText)
End Function

Public Sub FlushAnalysisBuffer(ByVal ws As Worksheet, ByRef buffer As Variant, ByVal bufferCount As Long, _
                                ByRef nextOutputRow As Long, ByVal lastColumn As Long)
    Dim tail() As Variant
    Dim r As Long, c As Long
    If bufferCount <= 0 Then Exit Sub
    If bufferCount = UBound(buffer, 1) Then
        ws.Range(ws.Cells(nextOutputRow, 1), _
                 ws.Cells(nextOutputRow + bufferCount - 1, lastColumn)).Value = buffer
    Else
        ReDim tail(1 To bufferCount, 1 To lastColumn)
        For r = 1 To bufferCount
            For c = 1 To lastColumn
                tail(r, c) = buffer(r, c)
            Next c
        Next r
        ws.Range(ws.Cells(nextOutputRow, 1), _
                 ws.Cells(nextOutputRow + bufferCount - 1, lastColumn)).Value = tail
    End If
    nextOutputRow = nextOutputRow + bufferCount
End Sub

Private Sub AnalysisAmountSearchBounds(ByVal amountValue As Double, ByVal absoluteTolerance As Double, _
                                       ByVal rateTolerance As Double, ByRef lowerAmount As Double, _
                                       ByRef upperAmount As Double)
    Dim rateValue As Double
    rateValue = rateTolerance / 100#
    lowerAmount = amountValue - absoluteTolerance
    If lowerAmount > amountValue * (1# - rateValue) Then lowerAmount = amountValue * (1# - rateValue)
    If lowerAmount < 0 Then lowerAmount = 0
    upperAmount = amountValue + absoluteTolerance
    If rateValue >= 1# Then
        upperAmount = MAX_ABS_AMOUNT
    ElseIf upperAmount < amountValue / (1# - rateValue) Then
        upperAmount = amountValue / (1# - rateValue)
    End If
    If upperAmount > MAX_ABS_AMOUNT Then upperAmount = MAX_ABS_AMOUNT
End Sub

Private Function AnalysisAllowedDifference(ByVal firstAmount As Double, ByVal secondAmount As Double, _
                                           ByVal absoluteTolerance As Double, _
                                           ByVal rateTolerance As Double) As Double
    Dim rateDifference As Double
    rateDifference = Application.Max(firstAmount, secondAmount) * rateTolerance / 100#
    AnalysisAllowedDifference = Application.Max(absoluteTolerance, rateDifference)
End Function

Private Function LowerBoundAnalysisAmount(ByRef amounts() As Double, ByVal itemCount As Long, _
                                          ByVal targetValue As Double) As Long
    Dim low As Long, high As Long, mid As Long
    low = 1
    high = itemCount + 1
    Do While low < high
        mid = low + (high - low) \ 2
        If mid <= itemCount And amounts(mid) < targetValue Then low = mid + 1 Else high = mid
    Loop
    LowerBoundAnalysisAmount = low
End Function

Private Function UpperBoundAnalysisAmount(ByRef amounts() As Double, ByVal itemCount As Long, _
                                          ByVal targetValue As Double) As Long
    Dim low As Long, high As Long, mid As Long
    low = 1
    high = itemCount + 1
    Do While low < high
        mid = low + (high - low) \ 2
        If mid <= itemCount And amounts(mid) <= targetValue Then low = mid + 1 Else high = mid
    Loop
    UpperBoundAnalysisAmount = low - 1
End Function

Private Sub QuickSortAnalysisAmounts(ByRef amounts() As Double, ByRef sourceRows() As Long, _
                                     ByVal firstIndex As Long, ByVal lastIndex As Long)
    Dim low As Long, high As Long
    Dim pivot As Double, tempAmount As Double
    Dim tempRow As Long
    low = firstIndex
    high = lastIndex
    pivot = amounts((firstIndex + lastIndex) \ 2)
    Do While low <= high
        Do While amounts(low) < pivot
            low = low + 1
        Loop
        Do While amounts(high) > pivot
            high = high - 1
        Loop
        If low <= high Then
            tempAmount = amounts(low): amounts(low) = amounts(high): amounts(high) = tempAmount
            tempRow = sourceRows(low): sourceRows(low) = sourceRows(high): sourceRows(high) = tempRow
            low = low + 1
            high = high - 1
        End If
    Loop
    If firstIndex < high Then QuickSortAnalysisAmounts amounts, sourceRows, firstIndex, high
    If low < lastIndex Then QuickSortAnalysisAmounts amounts, sourceRows, low, lastIndex
End Sub

Private Function TryGetAnalysisTime(ByVal valueIn As Variant, ByRef timeFraction As Double) As Boolean
    Dim ok As Boolean, normalizedTime As Variant
    If Not HasText(valueIn) Then Exit Function
    normalizedTime = NormalizeTimeInput(valueIn, ok)
    If Not ok Then Exit Function
    timeFraction = CDbl(CDate(normalizedTime)) - Fix(CDbl(CDate(normalizedTime)))
    TryGetAnalysisTime = True
End Function

Private Function AnalysisTimeOutputValue(ByVal valueIn As Variant) As Variant
    Dim timeFraction As Double
    If TryGetAnalysisTime(valueIn, timeFraction) Then
        AnalysisTimeOutputValue = timeFraction
    Else
        AnalysisTimeOutputValue = Empty
    End If
End Function

Private Function FormatAnalysisElapsedMinutes(ByVal minuteValue As Double) As String
    Dim wholeMinutes As Long, days As Long, hours As Long, minutes As Long
    If minuteValue < 0 Then minuteValue = -minuteValue
    If minuteValue > 2147483646# Then
        FormatAnalysisElapsedMinutes = Format$(minuteValue / 1440#, "0.0") & "��"
        Exit Function
    End If
    wholeMinutes = CLng(minuteValue + 0.5)
    days = wholeMinutes \ 1440
    hours = (wholeMinutes Mod 1440) \ 60
    minutes = wholeMinutes Mod 60
    If days > 0 Then
        FormatAnalysisElapsedMinutes = CStr(days) & "��" & CStr(hours) & "����" & CStr(minutes) & "��"
    ElseIf hours > 0 Then
        FormatAnalysisElapsedMinutes = CStr(hours) & "����" & CStr(minutes) & "��"
    Else
        FormatAnalysisElapsedMinutes = CStr(minutes) & "��"
    End If
End Function

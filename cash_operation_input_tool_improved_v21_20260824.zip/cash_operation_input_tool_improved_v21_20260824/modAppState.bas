Attribute VB_Name = "modAppState"
Option Explicit

Private mStateActive As Boolean
Private mStateDepth As Long
Private mPrevEvents As Boolean
Private mPrevScreenUpdating As Boolean
Private mPrevDisplayAlerts As Boolean
Private mPrevCalculation As XlCalculation
Private mPrevStatusBar As Variant
Private mPrevEnableCancelKey As XlEnableCancelKey

Public Sub AppBegin(Optional ByVal statusText As String = "������...")
    On Error Resume Next
    If mStateDepth = 0 Then
        mPrevEvents = Application.EnableEvents
        mPrevScreenUpdating = Application.ScreenUpdating
        mPrevDisplayAlerts = Application.DisplayAlerts
        mPrevCalculation = Application.Calculation
        mPrevStatusBar = Application.StatusBar
        mPrevEnableCancelKey = Application.EnableCancelKey
        mStateActive = True
    End If
    mStateDepth = mStateDepth + 1
    Application.EnableEvents = False
    Application.ScreenUpdating = False
    Application.DisplayAlerts = False
    Application.Calculation = xlCalculationManual
    '�����ԏ�����Esc�Œ��f�ł���BDoEvents���s��AppProgress��Err 18�Ƃ��Čďo���֕Ԃ��B
    Application.EnableCancelKey = xlErrorHandler
    Application.StatusBar = statusText
    On Error GoTo 0
End Sub

Public Sub AppEnd()
    On Error Resume Next
    If mStateDepth > 1 Then
        mStateDepth = mStateDepth - 1
        Exit Sub
    End If
    mStateDepth = 0
    If mStateActive Then
        Application.EnableEvents = mPrevEvents
        Application.ScreenUpdating = mPrevScreenUpdating
        Application.DisplayAlerts = mPrevDisplayAlerts
        Application.Calculation = mPrevCalculation
        Application.EnableCancelKey = mPrevEnableCancelKey
        Application.StatusBar = mPrevStatusBar
    End If
    mStateActive = False
    On Error GoTo 0
End Sub

Public Sub AppForceRestore(Optional ByVal forceSafeDefaults As Boolean = False)
    '�ʏ�̃G���[�����ł́A���̃c�[�����ޔ�������Ԃ����鎞�����߂��B
    '�񏈗����Ɍv�Z���@�Ȃǂ�����ɕύX�����A���u�b�N�̗��p�Ґݒ�����B
    'VBA���Z�b�g��ȂǑޔ���Ԃ��̂��̂�����ꂽ�������A�ďo����True���w�肷��B
    On Error Resume Next
    mStateDepth = 0
    If mStateActive Then
        AppEnd
        Exit Sub
    End If
    If forceSafeDefaults Then
        Application.EnableEvents = True
        Application.ScreenUpdating = True
        Application.DisplayAlerts = True
        Application.Calculation = xlCalculationAutomatic
        Application.EnableCancelKey = xlInterrupt
        Application.StatusBar = False
    End If
    On Error GoTo 0
End Sub

Public Sub AppProgress(ByVal statusText As String, Optional ByVal currentValue As Long = 0, _
                       Optional ByVal totalValue As Long = 0)
    Dim displayText As String
    displayText = statusText
    If totalValue > 0 Then
        displayText = displayText & "  " & Format$(currentValue, "#,##0") & " / " & _
                      Format$(totalValue, "#,##0")
    End If
    Application.StatusBar = displayText
    DoEvents
End Sub

Public Function IsUserCancelError(ByVal errorNumber As Long) As Boolean
    IsUserCancelError = (errorNumber = 18)
End Function

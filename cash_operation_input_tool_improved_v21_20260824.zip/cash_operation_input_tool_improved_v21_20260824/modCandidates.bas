Attribute VB_Name = "modCandidates"
Option Explicit

Private mCandidateBatchDepth As Long
Private mCandidateBatchRows As Object
Private Const MAX_CANDIDATE_DATA_ROWS As Long = 100000

Public Sub BeginCandidateBatchUpdate()
    If mCandidateBatchDepth = 0 Then BuildCandidateBatchIndex
    mCandidateBatchDepth = mCandidateBatchDepth + 1
End Sub

Public Sub EndCandidateBatchUpdate()
    If mCandidateBatchDepth > 0 Then mCandidateBatchDepth = mCandidateBatchDepth - 1
    If mCandidateBatchDepth = 0 Then
        RefreshAllCandidateNames
        Set mCandidateBatchRows = Nothing
    End If
End Sub

Private Sub BuildCandidateBatchIndex()
    Set mCandidateBatchRows = CreateObject("Scripting.Dictionary")
    mCandidateBatchRows.CompareMode = vbTextCompare
    IndexCandidateSheet SH_BANK_CAND
    IndexCandidateSheet SH_BRANCH_CAND
    IndexCandidateSheet SH_PERSON_CAND
    IndexCandidateSheet SH_ACCOUNT_TYPE
    IndexCandidateSheet SH_TEKIYO
End Sub

Private Sub IndexCandidateSheet(ByVal sheetName As String)
    Dim ws As Worksheet, lastR As Long, r As Long
    Dim valueText As String, keyText As String
    Dim candidateData As Variant
    If Not SheetExists(sheetName) Then Exit Sub
    Set ws = GetSheet(sheetName)
    lastR = LastUsedRowInSheet(ws)
    If lastR < 2 Then Exit Sub
    '���ʃf�[�^�捞�ł͍ő�10���s�����������邽�߁A�Z���P�ʂ�COM�ǎ�������B
    candidateData = ws.Range(ws.Cells(2, 1), ws.Cells(lastR, 4)).Value2
    For r = 1 To UBound(candidateData, 1)
        valueText = CellText(candidateData(r, 1))
        If Len(valueText) > 0 Then
            If sheetName = SH_PERSON_CAND Then
                keyText = CandidateBatchKey(sheetName, valueText, CellText(candidateData(r, 2)), _
                                            CellText(candidateData(r, 3)))
            Else
                keyText = CandidateBatchKey(sheetName, valueText)
            End If
            If Not mCandidateBatchRows.Exists(keyText) Then mCandidateBatchRows.Add keyText, r + 1
        End If
    Next r
End Sub

Private Function CandidateBatchKey(ByVal sheetName As String, ByVal valueText As String, _
                                   Optional ByVal personID As String = "", _
                                   Optional ByVal relationshipText As String = "") As String
    If sheetName = SH_PERSON_CAND Then
        valueText = NormalizePersonNameKey(valueText) & Chr$(29) & UCase$(Trim$(CellText(personID))) & _
                    Chr$(29) & NormalizeRelationshipKey(relationshipText)
    Else
        valueText = Trim$(CellText(valueText))
    End If
    CandidateBatchKey = sheetName & Chr$(29) & valueText
End Function

Public Sub BuildCandidateSheets(Optional ByVal resetContents As Boolean = False)
    SetupCandidateSheet SH_BANK_CAND, "��s�����", NM_LST_BANK_CAND, resetContents
    SetupCandidateSheet SH_BRANCH_CAND, "�x�X�����", NM_LST_BRANCH_CAND, resetContents
    SetupCandidateSheet SH_PERSON_CAND, "�l�����", NM_LST_PERSON_CAND, resetContents
End Sub

Public Sub ShowBankCandidates()
    ShowCandidateSheet SH_BANK_CAND
End Sub

Public Sub ShowBranchCandidates()
    ShowCandidateSheet SH_BRANCH_CAND
End Sub

Public Sub ShowPersonCandidates()
    ShowCandidateSheet SH_PERSON_CAND
End Sub

Public Sub ShowAccountTypeCandidates()
    ShowCandidateSheet SH_ACCOUNT_TYPE
End Sub

Public Sub ShowTekiyoCandidates()
    ShowCandidateSheet SH_TEKIYO
End Sub

Public Sub ShowCandidateSheet(ByVal sheetName As String)
    Dim ws As Worksheet
    Dim names As Variant, item As Variant
    Dim errorNumber As Long, errorDescription As String
    If Not RequireToolReady() Then Exit Sub
    If Not IsCandidateSheetName(sheetName) Then _
        Err.Raise vbObjectError + 2120, "ShowCandidateSheet", "���V�[�g�����s���ł�: " & sheetName
    On Error GoTo EH
    Set ws = GetSheet(sheetName)
    ws.Visible = xlSheetVisible
    ws.Unprotect Password:=TOOL_PASSWORD
    FormatCandidateSheetForEditing ws
    BuildCandidateNavigationPanel ws
    ProtectCandidateSheet ws, True
    ws.Activate
    ApplyActiveSheetWindowStyle ws
    SafeFreezeSheetAt ws, "A2", 95
    ws.Activate
    ws.Range("A2").Select

    '���^�u��5�������ɕ��ׂȂ��B�����Ă����ނ�����\�����A�ؑւ͉E���p�l���֏W�񂷂�B
    names = CandidateSheetNames()
    For Each item In names
        If CStr(item) <> sheetName Then HideSheetIfExists CStr(item)
    Next item
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    On Error Resume Next
    If Not ws Is Nothing Then ProtectCandidateSheet ws, False
    On Error GoTo 0
    MsgBox "���͌���\���ł��܂���ł����B" & vbCrLf & _
           "Err " & errorNumber & ": " & errorDescription, vbExclamation
End Sub

Public Sub OnCandidateSheetChange(ByVal ws As Worksheet, ByVal Target As Range)
    Dim affected As Range, cell As Range
    Dim previousEvents As Boolean
    Dim lastStyleRow As Long
    Dim errorNumber As Long, errorDescription As String
    If ws Is Nothing Or Target Is Nothing Then Exit Sub
    If Not IsCandidateSheetName(ws.Name) Then Exit Sub
    Set affected = Intersect(Target, ws.Range("A2:D" & CStr(ws.Rows.Count)))
    If affected Is Nothing Then Exit Sub
    previousEvents = Application.EnableEvents
    On Error GoTo CleanUp
    Application.EnableEvents = False

    '��s�E�x�X�E�l��������͂Œǉ������s�́A�Č��������ŏ����Ȃ����ʌ��Ƃ��Ĉ����B
    For Each cell In Intersect(affected.EntireRow, ws.Columns(1)).Cells
        If Not HasText(ws.Cells(cell.Row, 1).Value) Then
            If Not Intersect(Target, ws.Cells(cell.Row, 1)) Is Nothing Then
                '��▼���폜�������́A��\���̐l��ID�E�����E�敪���Ǘ������Ȃ��B
                ws.Range(ws.Cells(cell.Row, 2), ws.Cells(cell.Row, 4)).ClearContents
            End If
        ElseIf ws.Name = SH_BANK_CAND Or ws.Name = SH_BRANCH_CAND Or _
               ws.Name = SH_PERSON_CAND Then
                If Not HasText(ws.Cells(cell.Row, 4).Value) Then _
                    ws.Cells(cell.Row, 4).Value = CAND_SOURCE_COMMON
        End If
    Next cell
    RefreshCandidateNameForSheet ws.Name
    If ws.Name = SH_PERSON_CAND Then
        InvalidateInternalIdCaches
        ReconcileInternalIdCounters
    End If
    lastStyleRow = Application.Min(10000, Application.Max(50, LastUsedRowInSheet(ws) + 25))
    FormatCandidateEntryArea ws, lastStyleRow
    ws.ScrollArea = "A1:J" & CStr(Application.Min(ws.Rows.Count, _
                    Application.Max(500, LastRow(ws, 1) + 500)))
CleanUp:
    errorNumber = Err.Number
    errorDescription = Err.Description
    Application.EnableEvents = previousEvents
    If errorNumber <> 0 Then _
        Err.Raise errorNumber, "OnCandidateSheetChange", errorDescription
End Sub

Private Sub RefreshCandidateNameForSheet(ByVal sheetName As String)
    Select Case sheetName
        Case SH_BANK_CAND
            RefreshSingleCandidateName SH_BANK_CAND, NM_LST_BANK_CAND
        Case SH_BRANCH_CAND
            RefreshSingleCandidateName SH_BRANCH_CAND, NM_LST_BRANCH_CAND
        Case SH_PERSON_CAND
            RefreshSingleCandidateName SH_PERSON_CAND, NM_LST_PERSON_CAND
        Case SH_ACCOUNT_TYPE
            RefreshSingleCandidateName SH_ACCOUNT_TYPE, NM_LST_ACCOUNT_TYPE
        Case SH_TEKIYO
            RefreshSingleCandidateName SH_TEKIYO, NM_LST_TEKIYO
    End Select
End Sub

Private Function CandidateSheetNames() As Variant
    CandidateSheetNames = Array(SH_BANK_CAND, SH_BRANCH_CAND, SH_PERSON_CAND, _
                                SH_ACCOUNT_TYPE, SH_TEKIYO)
End Function

Public Function IsCandidateSheetName(ByVal sheetName As String) As Boolean
    Dim item As Variant
    For Each item In CandidateSheetNames()
        If StrComp(CStr(item), sheetName, vbTextCompare) = 0 Then
            IsCandidateSheetName = True
            Exit Function
        End If
    Next item
End Function

Public Sub ProtectCandidateSheet(ByVal ws As Worksheet, _
                                 Optional ByVal raiseOnError As Boolean = False)
    '���l�̓��͗񂾂����J���A�E���i�r�Q�[�V�����ƃ��C�A�E�g�͕ی삷��B
    '�ő���p�����܂ł��ꊇ�ݒ肵�A�\���̂��тɑS104���s�𑖍����Ȃ��B
    Dim editableLastRow As Long, lockLastRow As Long
    Dim workbookWasSaved As Boolean
    Dim errorNumber As Long, errorDescription As String
    If ws Is Nothing Then Exit Sub
    If Not IsCandidateSheetName(ws.Name) Then _
        Err.Raise vbObjectError + 2130, "ProtectCandidateSheet", _
                  "���V�[�g�ł͂���܂���: " & ws.Name
    workbookWasSaved = ThisWorkbook.Saved
    editableLastRow = MAX_CANDIDATE_DATA_ROWS + 1
    lockLastRow = editableLastRow + 500
    If lockLastRow > ws.Rows.Count Then lockLastRow = ws.Rows.Count
    If editableLastRow > lockLastRow Then editableLastRow = lockLastRow
    On Error GoTo EH

    ws.Unprotect Password:=TOOL_PASSWORD
    RestoreToolSheetScrollArea ws
    ws.Range("A1:D" & CStr(lockLastRow)).Locked = True
    If Not ThisWorkbook.ReadOnly Then
        ws.Range("A2:A" & CStr(editableLastRow)).Locked = False
        If ws.Name = SH_PERSON_CAND Then _
            ws.Range("C2:C" & CStr(editableLastRow)).Locked = False
    End If
    LockToolShapes ws, False
    ws.Protect Password:=TOOL_PASSWORD, DrawingObjects:=True, Contents:=True, Scenarios:=False, _
               UserInterfaceOnly:=True, AllowFiltering:=False, AllowSorting:=False, _
               AllowFormattingCells:=False, AllowFormattingColumns:=False, AllowFormattingRows:=False, _
               AllowInsertingColumns:=False, AllowInsertingRows:=False, _
               AllowDeletingColumns:=False, AllowDeletingRows:=False
    If ThisWorkbook.ReadOnly Then
        ws.EnableSelection = xlNoSelection
    Else
        ws.EnableSelection = xlUnlockedCells
    End If
    VerifyToolShapeSecurity ws, True, False
    If workbookWasSaved Then ThisWorkbook.Saved = True
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    EmergencyProtectToolSheet ws
    If workbookWasSaved Then ThisWorkbook.Saved = True
    If raiseOnError Then Err.Raise errorNumber, "ProtectCandidateSheet(" & ws.Name & ")", errorDescription
End Sub

Public Sub ProtectAllCandidateSheets(Optional ByVal raiseOnError As Boolean = False)
    Dim item As Variant
    Dim errorNumber As Long, errorDescription As String
    On Error GoTo EH
    For Each item In CandidateSheetNames()
        If SheetExists(CStr(item)) Then ProtectCandidateSheet GetSheet(CStr(item)), True
    Next item
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    If raiseOnError Then Err.Raise errorNumber, "ProtectAllCandidateSheets", errorDescription
End Sub

Private Sub FormatCandidateSheetForEditing(ByVal ws As Worksheet)
    Dim lastStyleRow As Long
    If ws Is Nothing Then Exit Sub
    lastStyleRow = Application.Min(10000, Application.Max(50, LastUsedRowInSheet(ws) + 25))
    With ws
        .Range("A1:J" & CStr(lastStyleRow)).Font.Name = "Meiryo UI"
        .Range("A1:J" & CStr(lastStyleRow)).Font.Size = 10.5
        .Columns("A:A").ColumnWidth = IIf(ws.Name = SH_TEKIYO, 48, 30)
        .Columns("B:D").Hidden = True
        If ws.Name = SH_PERSON_CAND Then
            .Columns("C:C").Hidden = False
            .Columns("C:C").ColumnWidth = 18
        End If
        .Columns("F:J").Hidden = False
        .Columns("F:J").ColumnWidth = 13
        .Rows(1).RowHeight = 28
        .ScrollArea = "A1:J" & CStr(Application.Min(.Rows.Count, _
                      Application.Max(500, LastRow(ws, 1) + 500)))
    End With
    FormatOutputHeader ws.Range("A1:D1")
    FormatCandidateEntryArea ws, lastStyleRow
End Sub

Private Sub FormatCandidateEntryArea(ByVal ws As Worksheet, ByVal lastStyleRow As Long)
    Dim visibleRange As Range
    If ws Is Nothing Or lastStyleRow < 2 Then Exit Sub
    If ws.Name = SH_PERSON_CAND Then
        Set visibleRange = Union(ws.Range("A2:A" & CStr(lastStyleRow)), _
                                 ws.Range("C2:C" & CStr(lastStyleRow)))
    Else
        Set visibleRange = ws.Range("A2:A" & CStr(lastStyleRow))
    End If
    With visibleRange
        .Interior.Color = RGB(255, 255, 255)
        .Font.Color = RGB(15, 23, 42)
        .Borders.LineStyle = xlContinuous
        .Borders.Color = RGB(226, 232, 240)
        .VerticalAlignment = xlCenter
    End With
    ws.Rows("2:" & CStr(lastStyleRow)).RowHeight = 22
End Sub

Private Sub BuildCandidateNavigationPanel(ByVal ws As Worksheet)
    Dim x As Double, y As Double, w As Double, h As Double
    Dim margin As Double, gap As Double, buttonW As Double, buttonH As Double
    Dim rowY As Double
    If ws Is Nothing Then Exit Sub
    DeleteToolShapesVerified ws, False
    x = ws.Range("F2").Left
    y = ws.Range("F2").Top
    w = ws.Range("F2:J10").Width
    h = ws.Range("F2:J10").Height
    margin = 10
    gap = 7
    buttonW = (w - margin * 2 - gap) / 2
    buttonH = 30

    AddCandidateTextShape ws, UI_PREFIX & "candidate_title", _
                          ws.Range("F1").Left, ws.Range("F1").Top, _
                          ws.Range("F1:J1").Width, ws.Range("F1:J1").Height, _
                          "���͌��𐮗�", True
    AddPanelBack ws, x, y, w, h
    rowY = y + margin
    AddUIButton ws, x + margin, rowY, buttonW, buttonH, "��s��", "ShowBankCandidates", _
                IIf(ws.Name = SH_BANK_CAND, "primary", "tool")
    AddUIButton ws, x + margin + buttonW + gap, rowY, buttonW, buttonH, "�x�X��", _
                "ShowBranchCandidates", IIf(ws.Name = SH_BRANCH_CAND, "primary", "tool")
    rowY = rowY + buttonH + gap
    AddUIButton ws, x + margin, rowY, buttonW, buttonH, "�l���E����", _
                "ShowPersonCandidates", IIf(ws.Name = SH_PERSON_CAND, "primary", "tool")
    AddUIButton ws, x + margin + buttonW + gap, rowY, buttonW, buttonH, "�Ȗ�", _
                "ShowAccountTypeCandidates", IIf(ws.Name = SH_ACCOUNT_TYPE, "primary", "tool")
    rowY = rowY + buttonH + gap
    AddUIButton ws, x + margin, rowY, buttonW, buttonH, "�E�v", "ShowTekiyoCandidates", _
                IIf(ws.Name = SH_TEKIYO, "primary", "tool")
    AddUIButton ws, x + margin + buttonW + gap, rowY, buttonW, buttonH, "���֖͂߂�", _
                "ShowInputSheet", "soft"
    AddCandidateTextShape ws, UI_PREFIX & "candidate_note", _
                          ws.Range("F12").Left, ws.Range("F12").Top, _
                          ws.Range("F12:J13").Width, ws.Range("F12:J13").Height, _
                          "A��֌�����͂��܂��B�l����₾����C��ɑ�������͂ł��܂��B�ύX�͓��̓��X�g�֎������f����܂��B", False
    LockToolShapes ws, False
End Sub

Private Sub AddCandidateTextShape(ByVal ws As Worksheet, ByVal shapeName As String, _
                                  ByVal x As Double, ByVal y As Double, _
                                  ByVal w As Double, ByVal h As Double, _
                                  ByVal textValue As String, ByVal titleStyle As Boolean)
    Dim shp As Shape
    If ws Is Nothing Then Exit Sub
    Set shp = ws.Shapes.AddShape(msoShapeRoundedRectangle, x, y, w, h)
    With shp
        .Name = shapeName
        .TextFrame.Characters.Text = textValue
        .TextFrame.HorizontalAlignment = xlHAlignCenter
        .TextFrame.VerticalAlignment = xlVAlignCenter
        .TextFrame.MarginLeft = 6
        .TextFrame.MarginRight = 6
        .TextFrame.Characters.Font.Name = "Meiryo UI"
        .TextFrame.Characters.Font.Bold = titleStyle
        .TextFrame.Characters.Font.Size = IIf(titleStyle, 10.5, 9.5)
        If titleStyle Then
            .Fill.ForeColor.RGB = RGB(239, 246, 255)
            .Line.ForeColor.RGB = RGB(191, 219, 254)
            .TextFrame.Characters.Font.Color = RGB(30, 64, 175)
        Else
            .Fill.ForeColor.RGB = RGB(248, 250, 252)
            .Line.ForeColor.RGB = RGB(226, 232, 240)
            .TextFrame.Characters.Font.Color = RGB(71, 85, 105)
        End If
        .Placement = xlMove
        .Locked = True
    End With
End Sub

Private Sub SetupCandidateSheet(ByVal sheetName As String, ByVal titleText As String, ByVal listName As String, ByVal resetContents As Boolean)
    Dim ws As Worksheet, styleLastRow As Long, lastR As Long, r As Long
    Dim candidateData As Variant, sourceMigrated As Boolean
    Dim needsReset As Boolean
    On Error GoTo EH
    Set ws = GetOrCreateSheet(sheetName, False)
    If ws Is Nothing Then Err.Raise vbObjectError + 2001, "SetupCandidateSheet", "���V�[�g���쐬�ł��܂���: " & sheetName
    needsReset = resetContents Or Len(CellText(ws.Range("A1").Value)) = 0
    If needsReset Then
        ResetWorksheet ws
        ws.Range("A1").Value = titleText
        ws.Range("A1").Font.Bold = True
        ws.Range("A2").Value = ""
        If sheetName = SH_PERSON_CAND Then
            ws.Range("B1").Value = "�l��ID"
            ws.Range("C1").Value = "����"
            ws.Range("B1:C1").Font.Bold = True
        End If
        ws.Range("D1").Value = "�敪"
        ws.Range("D1").Font.Bold = True
    End If
    '���ł�1����������p���ꍇ�A�敪�󗓂̂܂܂��ƈČ��������ŏ�����B
    '�������͗��p�҂��p�����p���Ă������ʌ��Ƃ��ĕی삷��B
    lastR = LastUsedRowInSheet(ws)
    If lastR >= 2 Then
        candidateData = ws.Range(ws.Cells(2, 1), ws.Cells(lastR, 4)).Value2
        For r = 1 To UBound(candidateData, 1)
            If Len(CellText(candidateData(r, 1))) > 0 And Len(CellText(candidateData(r, 4))) = 0 Then
                candidateData(r, 4) = CAND_SOURCE_COMMON
                sourceMigrated = True
            End If
        Next r
        If sourceMigrated Then ws.Range(ws.Cells(2, 1), ws.Cells(lastR, 4)).Value2 = candidateData
    End If
    ws.Visible = xlSheetVisible
    styleLastRow = Application.Max(2, LastUsedRowInSheet(ws))
    With ws.Range("A1:D" & CStr(styleLastRow))
        .Font.Name = "Meiryo UI"
        .Font.Size = 10
    End With
    ws.Columns("A:A").ColumnWidth = 28
    ws.Columns("A:D").NumberFormatLocal = "@"
    If sheetName = SH_PERSON_CAND Then
        ws.Columns("B:B").ColumnWidth = 18
        ws.Columns("B:B").Hidden = True
        ws.Columns("C:C").ColumnWidth = 18
    End If
    ws.Columns("D:D").Hidden = True
    RefreshSingleCandidateName sheetName, listName
    ProtectCandidateSheet ws, True
    Exit Sub
EH:
    Err.Raise Err.Number, "SetupCandidateSheet(" & sheetName & ")", Err.Description
End Sub

Public Sub RefreshAccountCandidateNames()
    RefreshSingleCandidateName SH_BANK_CAND, NM_LST_BANK_CAND
    RefreshSingleCandidateName SH_BRANCH_CAND, NM_LST_BRANCH_CAND
    RefreshSingleCandidateName SH_PERSON_CAND, NM_LST_PERSON_CAND
End Sub

Public Sub RefreshAllCandidateNames()
    RefreshAccountCandidateNames
    RefreshSingleCandidateName SH_ACCOUNT_TYPE, NM_LST_ACCOUNT_TYPE
    RefreshSingleCandidateName SH_TEKIYO, NM_LST_TEKIYO
End Sub

Private Sub RefreshSingleCandidateName(ByVal sheetName As String, ByVal listName As String)
    Dim ws As Worksheet
    Dim lastR As Long
    Dim errorNumber As Long, errorDescription As String
    On Error GoTo EH
    If Not SheetExists(sheetName) Then Exit Sub
    Set ws = GetSheet(sheetName)
    lastR = LastUsedRowInSheet(ws)
    If lastR < 2 Then
        ws.Range("A2").Value = ""
        lastR = 2
    End If
    ResetName listName, ws.Range("A2:A" & CStr(lastR))
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    Err.Raise errorNumber, "RefreshSingleCandidateName(" & sheetName & ")", errorDescription
End Sub

Public Sub UpdateAccountCandidates(ByVal bankName As String, ByVal branchName As String, ByVal personName As String)
    AddCandidateValue SH_BANK_CAND, NM_LST_BANK_CAND, bankName, CAND_SOURCE_CASE
    AddCandidateValue SH_BRANCH_CAND, NM_LST_BRANCH_CAND, branchName, CAND_SOURCE_CASE
    '�l���͐l��ID�E�����ƈ�̂� AddPersonCandidateWithID ����o�^����B
End Sub

Public Sub ResetCaseCandidates()
    '���ʃf�[�^�R���͎c���A�Č����́E�O���捞�Ŋw�K������₾���������B
    RemoveCaseCandidateRows SH_BANK_CAND, NM_LST_BANK_CAND
    RemoveCaseCandidateRows SH_BRANCH_CAND, NM_LST_BRANCH_CAND
    RemoveCaseCandidateRows SH_PERSON_CAND, NM_LST_PERSON_CAND
    '���p�҂��ȖځE�E�v���֒��ڒǋL�����ꍇ���A��������̓��͋K���֑S�����Đڑ�����B
    RefreshAllCandidateNames
End Sub

Public Sub ValidateCaseCandidateResetSources()
    '����������c�鋤�ʌ��ɕs���ȋ敪������ƁA�Č��f�[�^�����������
    '�Z���t�`�F�b�N�ŏ������S�̂����s����B�j��I�������O�Ɍ��o����B
    ValidateCandidateResetSourceSheet SH_BANK_CAND
    ValidateCandidateResetSourceSheet SH_BRANCH_CAND
    ValidateCandidateResetSourceSheet SH_PERSON_CAND
End Sub

Public Sub AddAccountTypeCandidate(ByVal accountType As String)
    AddCandidateValue SH_ACCOUNT_TYPE, NM_LST_ACCOUNT_TYPE, accountType
End Sub

Public Sub AddBankCandidate(ByVal bankName As String, Optional ByVal sourceText As String = CAND_SOURCE_CASE)
    AddCandidateValue SH_BANK_CAND, NM_LST_BANK_CAND, bankName, sourceText
End Sub

Public Sub AddBranchCandidate(ByVal branchName As String, Optional ByVal sourceText As String = CAND_SOURCE_CASE)
    AddCandidateValue SH_BRANCH_CAND, NM_LST_BRANCH_CAND, branchName, sourceText
End Sub

Public Sub AddTekiyoCandidate(ByVal tekiyoText As String)
    AddCandidateValue SH_TEKIYO, NM_LST_TEKIYO, tekiyoText
End Sub

Public Sub AddPersonCandidateWithID(ByVal personName As String, ByVal personID As String, ByVal relationshipText As String, _
                                    Optional ByVal sourceText As String = CAND_SOURCE_CASE)
    Dim ws As Worksheet
    Dim lastR As Long, r As Long
    Dim s As String, batchKey As String
    Dim storedID As String, storedRelationship As String
    Dim requestedIdentityKey As String, storedIdentityKey As String
    s = Trim$(CellText(personName))
    If Len(s) = 0 Then Exit Sub
    sourceText = CellText(sourceText)
    If sourceText <> CAND_SOURCE_CASE And sourceText <> CAND_SOURCE_COMMON Then _
        Err.Raise vbObjectError + 2112, "AddPersonCandidateWithID", "���敪���s���ł�: " & sourceText
    If Len(s) > 100 Then Err.Raise vbObjectError + 2101, "AddPersonCandidateWithID", "��������100�����ȓ��ɂ��Ă��������B"
    If Len(CellText(personID)) > 100 Then Err.Raise vbObjectError + 2102, "AddPersonCandidateWithID", "�l��ID��100�����ȓ��ɂ��Ă��������B"
    If Len(CellText(relationshipText)) > 50 Then Err.Raise vbObjectError + 2103, "AddPersonCandidateWithID", "��������50�����ȓ��ɂ��Ă��������B"
    If Not SheetExists(SH_PERSON_CAND) Then BuildCandidateSheets False
    Set ws = GetSheet(SH_PERSON_CAND)
    lastR = LastUsedRowInSheet(ws)
    requestedIdentityKey = PersonIdentityKey(s, relationshipText)
    If mCandidateBatchDepth > 0 And Not mCandidateBatchRows Is Nothing Then
        batchKey = CandidateBatchKey(SH_PERSON_CAND, s, personID, relationshipText)
        If mCandidateBatchRows.Exists(batchKey) Then
            r = CLng(mCandidateBatchRows(batchKey))
            storedID = CellText(ws.Cells(r, 2).Value)
            '���������s����ʂɑ������ʃf�[�^�ł��A�S��⑖���Ɠ���x���̔������s��Ȃ��B
            If Len(personID) > 0 And Len(storedID) > 0 Then
                If StrComp(storedID, personID, vbTextCompare) <> 0 Then Exit Sub
            End If
            UpdateExistingPersonCandidate ws, r, s, personID, relationshipText, sourceText
            Exit Sub
        End If
    End If
    For r = 2 To lastR
        If NormalizePersonNameKey(CellText(ws.Cells(r, 1).Value)) = NormalizePersonNameKey(s) Then
            storedID = CellText(ws.Cells(r, 2).Value)
            storedRelationship = CellText(ws.Cells(r, 3).Value)
            storedIdentityKey = PersonIdentityKey(CellText(ws.Cells(r, 1).Value), storedRelationship)
            If Len(personID) > 0 And StrComp(storedID, personID, vbTextCompare) = 0 Then
                UpdateExistingPersonCandidate ws, r, s, personID, relationshipText, sourceText
                GoTo Updated
            ElseIf Len(storedID) = 0 And _
                   (Len(NormalizeRelationshipKey(storedRelationship)) = 0 Or storedIdentityKey = requestedIdentityKey) Then
                UpdateExistingPersonCandidate ws, r, s, personID, relationshipText, sourceText
                GoTo Updated
            ElseIf Len(personID) = 0 And storedIdentityKey = requestedIdentityKey Then
                UpdateExistingPersonCandidate ws, r, s, personID, relationshipText, sourceText
                GoTo Updated
            ElseIf Len(personID) > 0 And Len(storedID) > 0 And storedIdentityKey = requestedIdentityKey Then
                AddCheck "�x��", "�l�����", s & "�i" & relationshipText & _
                         "�j�ɂ͕ʂ̐l��ID�����ɂ��邽�߁A���\���㏑�����܂���ł����B"
                If mCandidateBatchDepth > 0 And Not mCandidateBatchRows Is Nothing Then _
                    mCandidateBatchRows(batchKey) = r
                Exit Sub
            End If
        End If
    Next r
    r = lastR + 1
    If r < 2 Then r = 2
    If r - 1 > MAX_CANDIDATE_DATA_ROWS Then _
        Err.Raise vbObjectError + 2106, "AddPersonCandidateWithID", _
                  "�l����₪���p����i" & Format$(MAX_CANDIDATE_DATA_ROWS, "#,##0") & "���j�ɒB���Ă��܂��B"
    If r > ws.Rows.Count Then _
        Err.Raise vbObjectError + 2109, "AddPersonCandidateWithID", _
                  "�l����₪Excel�̍s����ɒB���Ă��܂��B���ʃf�[�^�𕪊����Ă��������B"
    ws.Cells(r, 1).Value = s
    ws.Cells(r, 2).Value = personID
    ws.Cells(r, 3).Value = relationshipText
    ws.Cells(r, 4).Value = sourceText
Updated:
    If mCandidateBatchDepth > 0 And Not mCandidateBatchRows Is Nothing Then _
        mCandidateBatchRows(CandidateBatchKey(SH_PERSON_CAND, s, personID, relationshipText)) = r
    If Len(personID) > 0 Then InvalidateInternalIdCaches
    If mCandidateBatchDepth = 0 Then RefreshSingleCandidateName SH_PERSON_CAND, NM_LST_PERSON_CAND
End Sub

Private Sub UpdateExistingPersonCandidate(ByVal ws As Worksheet, ByVal rowNo As Long, ByVal personName As String, _
                                          ByVal personID As String, ByVal relationshipText As String, _
                                          ByVal sourceText As String)
    If ws Is Nothing Or rowNo < 2 Then Exit Sub
    If Len(personID) > 0 Then
        If Len(CellText(ws.Cells(rowNo, 2).Value)) = 0 Then
            ws.Cells(rowNo, 2).Value = personID
            InvalidateInternalIdCaches
        ElseIf StrComp(CellText(ws.Cells(rowNo, 2).Value), personID, vbTextCompare) <> 0 Then
            AddCheck "�x��", "�l�����", personName & " �̐l��ID�������l�ƈقȂ邽�߁A����ID " & _
                     CellText(ws.Cells(rowNo, 2).Value) & " ��ێ����܂����B"
            Exit Sub
        End If
    End If
    If Len(relationshipText) > 0 Then
        If Len(CellText(ws.Cells(rowNo, 3).Value)) > 0 And _
           NormalizeRelationshipKey(CellText(ws.Cells(rowNo, 3).Value)) <> NormalizeRelationshipKey(relationshipText) Then
            Err.Raise vbObjectError + 2107, "UpdateExistingPersonCandidate", _
                      "�����l��ID�̑������������ƈقȂ�܂��B���������̒������[�h�Ŋm�F���Ă�������: " & personName
        End If
        ws.Cells(rowNo, 3).Value = relationshipText
    End If
    If sourceText = CAND_SOURCE_COMMON Then ws.Cells(rowNo, 4).Value = CAND_SOURCE_COMMON
    If mCandidateBatchDepth = 0 Then RefreshSingleCandidateName SH_PERSON_CAND, NM_LST_PERSON_CAND
End Sub

Private Sub AddCandidateValue(ByVal sheetName As String, ByVal listName As String, ByVal valueText As String, _
                              Optional ByVal sourceText As String = CAND_SOURCE_CASE)
    Dim ws As Worksheet
    Dim lastR As Long, r As Long
    Dim s As String, batchKey As String
    s = Trim$(valueText)
    If Len(s) = 0 Then Exit Sub
    sourceText = CellText(sourceText)
    If sourceText <> CAND_SOURCE_CASE And sourceText <> CAND_SOURCE_COMMON Then _
        Err.Raise vbObjectError + 2113, "AddCandidateValue", "���敪���s���ł�: " & sourceText
    If sheetName = SH_TEKIYO Then
        If Len(s) > 500 Then Err.Raise vbObjectError + 2104, "AddCandidateValue", "�E�v����500�����ȓ��ɂ��Ă��������B"
    Else
        If Len(s) > 100 Then Err.Raise vbObjectError + 2105, "AddCandidateValue", "���l��100�����ȓ��ɂ��Ă��������B"
    End If
    If Not SheetExists(sheetName) Then BuildCandidateSheets False
    If Not SheetExists(sheetName) Then Exit Sub
    Set ws = GetSheet(sheetName)
    lastR = LastUsedRowInSheet(ws)
    If lastR < 2 Then lastR = 1
    If mCandidateBatchDepth > 0 And Not mCandidateBatchRows Is Nothing Then
        batchKey = CandidateBatchKey(sheetName, s)
        If mCandidateBatchRows.Exists(batchKey) Then
            r = CLng(mCandidateBatchRows(batchKey))
            If sourceText = CAND_SOURCE_COMMON Then ws.Cells(r, 4).Value = CAND_SOURCE_COMMON
            Exit Sub
        End If
    End If
    For r = 2 To lastR
        If (sheetName = SH_PERSON_CAND And NormalizePersonNameKey(CellText(ws.Cells(r, 1).Value)) = NormalizePersonNameKey(s)) Or _
           (sheetName <> SH_PERSON_CAND And StrComp(CellText(ws.Cells(r, 1).Value), s, vbTextCompare) = 0) Then
            If sourceText = CAND_SOURCE_COMMON Then ws.Cells(r, 4).Value = CAND_SOURCE_COMMON
            If mCandidateBatchDepth = 0 Then RefreshSingleCandidateName sheetName, listName
            Exit Sub
        End If
    Next r
    If lastR > MAX_CANDIDATE_DATA_ROWS Then _
        Err.Raise vbObjectError + 2110, "AddCandidateValue", _
                  "���ꗗ�����p����i" & Format$(MAX_CANDIDATE_DATA_ROWS, "#,##0") & "���j�ɒB���Ă��܂��B"
    If lastR + 1 > ws.Rows.Count Then _
        Err.Raise vbObjectError + 2111, "AddCandidateValue", _
                  "���ꗗ��Excel�̍s����ɒB���Ă��܂��B���ʃf�[�^�𕪊����Ă��������B"
    ws.Cells(lastR + 1, 1).Value = s
    ws.Cells(lastR + 1, 4).Value = sourceText
    If mCandidateBatchDepth > 0 And Not mCandidateBatchRows Is Nothing Then mCandidateBatchRows(CandidateBatchKey(sheetName, s)) = lastR + 1
    If mCandidateBatchDepth = 0 Then RefreshSingleCandidateName sheetName, listName
End Sub

Private Sub RemoveCaseCandidateRows(ByVal sheetName As String, ByVal listName As String)
    Dim ws As Worksheet
    If Not SheetExists(sheetName) Then Exit Sub
    Set ws = GetSheet(sheetName)
    '���V�[�g�͗��p�҂�����A��֒ǋL�ł���B�敪����͂ł��Ȃ��ʏ푀���
    '�ǉ����ꂽ�s�́A���Č��ł��g���蓮���ʌ��Ƃ��ĕی삷��B
    MigrateBlankCandidateSourcesToCommon ws
    '���m�̈Č���₾����z�񈳏k�ō폜����B�s���ȋ敪�͖ق��ď������Z���t�`�F�b�N�֎c���B
    CompactDeleteDataRows ws, 4, 4, CAND_SOURCE_CASE
    RefreshSingleCandidateName sheetName, listName
End Sub

Private Sub ValidateCandidateResetSourceSheet(ByVal sheetName As String)
    Dim ws As Worksheet, lastR As Long, r As Long
    Dim sourceData As Variant
    Dim candidateText As String, personID As String, relationshipText As String, sourceText As String
    Dim duplicateKey As String, identityKey As String, relationshipKey As String
    Dim seen As Object, identityIDs As Object, idRelationships As Object
    Dim formulaCells As Range
    If Not SheetExists(sheetName) Then _
        Err.Raise vbObjectError + 2114, "ValidateCaseCandidateResetSources", _
                  "���V�[�g������܂���: " & sheetName
    Set ws = GetSheet(sheetName)
    lastR = LastUsedRowInSheet(ws)
    If lastR < 2 Then Exit Sub
    On Error Resume Next
    Err.Clear
    Set formulaCells = ws.Range(ws.Cells(2, 1), ws.Cells(lastR, 4)).SpecialCells(xlCellTypeFormulas)
    Err.Clear
    On Error GoTo 0
    If Not formulaCells Is Nothing Then _
        Err.Raise vbObjectError + 2125, "ValidateCaseCandidateResetSources", _
                  sheetName & " " & formulaCells.Cells(1, 1).Address(False, False) & _
                  "�ɐ���������܂��B�������O�ɒl�֒u�������Ă��������B"
    sourceData = ws.Range(ws.Cells(2, 1), ws.Cells(lastR, 4)).Value2
    Set seen = CreateObject("Scripting.Dictionary")
    Set identityIDs = CreateObject("Scripting.Dictionary")
    Set idRelationships = CreateObject("Scripting.Dictionary")
    seen.CompareMode = vbTextCompare
    identityIDs.CompareMode = vbTextCompare
    idRelationships.CompareMode = vbTextCompare
    For r = 1 To UBound(sourceData, 1)
        If IsError(sourceData(r, 1)) Or IsError(sourceData(r, 2)) Or _
           IsError(sourceData(r, 3)) Or IsError(sourceData(r, 4)) Then
            Err.Raise vbObjectError + 2115, "ValidateCaseCandidateResetSources", _
                      sheetName & " " & CStr(r + 1) & "�s��Excel�G���[�l������܂��B�Z���t�`�F�b�N�ŏC�����Ă��������B"
        End If
        candidateText = CellText(sourceData(r, 1))
        personID = CellText(sourceData(r, 2))
        relationshipText = CellText(sourceData(r, 3))
        sourceText = CellText(sourceData(r, 4))
        If Len(candidateText) = 0 Then
            Err.Raise vbObjectError + 2116, "ValidateCaseCandidateResetSources", _
                      sheetName & " " & CStr(r + 1) & "�s�͌��l���󗓂ł��B��s���l�߂Ă��������B"
        ElseIf Len(sourceText) > 0 And sourceText <> CAND_SOURCE_CASE And sourceText <> CAND_SOURCE_COMMON Then
            Err.Raise vbObjectError + 2117, "ValidateCaseCandidateResetSources", _
                      sheetName & " " & CStr(r + 1) & "�s�̋敪���s���ł�: " & sourceText
        End If
        '�Č����͏������ō폜�����B���ʌ��ƁA���ʂֈڍs����蓮�ǋL�s������
        '��������̏�ԂƂ��ďd���E�����E�l��ID�����܂Ŏ��O���؂���B
        If sourceText <> CAND_SOURCE_CASE Then
            If Len(candidateText) > 100 Then _
                Err.Raise vbObjectError + 2119, "ValidateCaseCandidateResetSources", _
                          sheetName & " " & CStr(r + 1) & "�s�̌��l��100�����𒴂��Ă��܂��B"
            If sheetName = SH_PERSON_CAND Then
                If Len(personID) > 100 Then _
                    Err.Raise vbObjectError + 2120, "ValidateCaseCandidateResetSources", _
                              sheetName & " " & CStr(r + 1) & "�s�̐l��ID��100�����𒴂��Ă��܂��B"
                If Len(relationshipText) > 50 Then _
                    Err.Raise vbObjectError + 2121, "ValidateCaseCandidateResetSources", _
                              sheetName & " " & CStr(r + 1) & "�s�̑�����50�����𒴂��Ă��܂��B"
                identityKey = PersonIdentityKey(candidateText, relationshipText)
                duplicateKey = identityKey & Chr$(29) & UCase$(personID)
                If Len(personID) > 0 Then
                    If identityIDs.Exists(identityKey) Then
                        If StrComp(CStr(identityIDs(identityKey)), personID, vbTextCompare) <> 0 Then _
                            Err.Raise vbObjectError + 2123, "ValidateCaseCandidateResetSources", _
                                      sheetName & " " & CStr(r + 1) & "�s�͓��������E�����ɈقȂ�l��ID������܂��B"
                    Else
                        identityIDs.Add identityKey, personID
                    End If
                    relationshipKey = NormalizeRelationshipKey(relationshipText)
                    If Len(relationshipKey) > 0 Then
                        If idRelationships.Exists(personID) Then
                            If StrComp(CStr(idRelationships(personID)), relationshipKey, vbTextCompare) <> 0 Then _
                                Err.Raise vbObjectError + 2124, "ValidateCaseCandidateResetSources", _
                                          sheetName & " " & CStr(r + 1) & "�s�͓���l��ID�̑�������v���܂���B"
                        Else
                            idRelationships.Add personID, relationshipKey
                        End If
                    End If
                End If
            Else
                duplicateKey = UCase$(Trim$(candidateText))
            End If
            If seen.Exists(duplicateKey) Then _
                Err.Raise vbObjectError + 2122, "ValidateCaseCandidateResetSources", _
                          sheetName & " " & CStr(r + 1) & "�s�ɏ���������c��d����₪����܂��B"
            seen.Add duplicateKey, True
        End If
    Next r
End Sub

Private Sub MigrateBlankCandidateSourcesToCommon(ByVal ws As Worksheet)
    Dim lastR As Long, r As Long
    Dim sourceData As Variant, changed As Boolean
    If ws Is Nothing Then Exit Sub
    lastR = LastUsedRowInSheet(ws)
    If lastR < 2 Then Exit Sub
    sourceData = ws.Range(ws.Cells(2, 1), ws.Cells(lastR, 4)).Value2
    For r = 1 To UBound(sourceData, 1)
        If Len(CellText(sourceData(r, 1))) > 0 And Len(CellText(sourceData(r, 4))) = 0 Then
            sourceData(r, 4) = CAND_SOURCE_COMMON
            changed = True
        End If
    Next r
    If changed Then ws.Range(ws.Cells(2, 1), ws.Cells(lastR, 4)).Value2 = sourceData
End Sub

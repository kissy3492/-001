@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0CREATE_TOOL.ps1"
if errorlevel 1 (
  echo.
  echo Tool creation did not complete. See README.md for the manual setup steps.
  pause
  exit /b 1
)
exit /b 0

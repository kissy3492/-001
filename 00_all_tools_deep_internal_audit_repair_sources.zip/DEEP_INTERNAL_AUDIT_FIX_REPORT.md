# Deep internal audit repair report

重点修正:

- 01人物入力の登録後ホットパスから、列幅・罫線の全面復旧と全セルロックを除去。`ApplyInputUsability` は軽量な保護/入力候補復旧だけに変更。
- 住所追加後に `EnsurePersonInputValidationOnly` だけで終わり、シートが未保護になる導線を修正。軽量 `ApplyInputUsability` で保護状態へ戻す。
- 01人物情報整理資料出力で、非表示の出力シートをコピーした後に既定表示シートを削除して失敗し得る導線を修正。コピー対象を一時表示し、出力ブック側も可視化してから保存し、元の表示状態を復元。
- 02最終出力で、出力元シートを表示したままにする副作用を修正。コピー後に元の表示状態へ戻す。
- 03分析結果出力後、通常表示へ戻す。
- ボタン文言が見切れにくいよう、共通ボタンフォントサイズと余白を幅・高さ・文字数から調整。
- 01出力フォルダ作成を `RuntimeEnsureFolderExists` に統一。


## 再チェック結果

- VBA構造チェック: ISSUE_COUNT 0
- OnAction先未定義: 0
- 実未定義候補: 0（SafeExit はラベル）
- 240文字超のVBA行: 0
- `Set wbNew = ActiveWorkbook`: なし
- `MsgBox Err.Description` 単独表示: なし
- `ExternalImportMapQuality`: 残存なし
- `cDate` 系危険名: 残存なし

## 重点確認済みの内部状態

- `ApplyInputUsability` は登録後のホットパスで列幅・罫線の全面復旧を呼ばない。
- `ApplyInputUsability` は全シートではなく入力画面範囲だけを制御する。
- 人物情報整理資料出力では、非表示シートを一時表示し、コピー先シートも表示状態にしてから保存する。
- 02/03の出力で、出力用に表示したシートを通常表示へ戻す。
- ボタン文言は幅・高さ・文字数からフォントサイズを落とし、余白を縮める。

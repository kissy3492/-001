Attribute VB_Name = "modAnalysisEngine"

Option Explicit



Private mTxById As Object

Private mMatched As Object

Private mDedupe As Object

Private mManualExcludedTxIds As Object

Private mManualVoucherOverrides As Object

Private mManualDecisionOverrides As Object

Private mManualMemoOverrides As Object

Private mCohabPairs As Object

Private mRelationPairs As Object

Private mMarriageByPerson As Object

Private mPersonInfo As Object

Private mAddressByPerson As Object

Private mTimeCluster As Object

Private mAccountOperationPatternCount As Object

Private mNextResultRow As Long

Private mNextDetailRow As Long

Private mDecedentId As String

Private mInheritanceDate As Variant

Private mMinShift As Double

Private mDateWindow As Long

Private mAmountTol As Double

Private mAmountRate As Double

Private mMaxCombo As Long

Private mMaxSideCandidates As Long

Private mUnknownThreshold As Double

Private mVoucherThreshold As Double

Private mEnableOneToOne As Boolean

Private mEnableOneToMany As Boolean

Private mEnableManyToOne As Boolean

Private mEnableManyToMany As Boolean

Private mEnableUnknowns As Boolean

Private mSuppressDuplicateShift As Boolean

Private mMaxResults As Long

Private mMaxCombosPerBase As Long

Private mMaxMtmPairTests As Long

Private mVoucherInheritanceAlways As Boolean

Private mVoucherUnknowns As Boolean

Private mExcludeSummaryKeywords As String

Private mStopIfTooBroad As Boolean

Private mFocusYears As Long

Private mMinScore As Long

Private mContextScore As Boolean

Private mStopRequested As Boolean

Private mResultCount As Long

Private mExcludedKeywordList As Variant



Public Sub RunAnalysis()

    If Not RequireSavedWorkbook() Then Exit Sub

    If LastRow(GetSheet(SH_WORK_TX), 1) < 2 Then

        If MsgBox("取引データが読み込まれていません。共通データ読込を実行しますか。", vbQuestion + vbYesNo) = vbYes Then

            LoadCommonData

        End If

    End If

    If LastRow(GetSheet(SH_WORK_TX), 1) < 2 Then

        MsgBox "分析対象の取引がありません。", vbExclamation

        Exit Sub

    End If



    On Error GoTo EH

    AppBegin "資金移動分析を実行中..."

    ResetAnalysisIds

    InitResultHeaders GetSheet(SH_WORK_RESULT)

    InitDetailHeaders GetSheet(SH_WORK_DETAIL)

    mNextResultRow = 2

    mNextDetailRow = 2

    Set mTxById = CreateObject("Scripting.Dictionary")

    Set mMatched = CreateObject("Scripting.Dictionary")

    Set mDedupe = CreateObject("Scripting.Dictionary")

    Set mManualExcludedTxIds = CreateObject("Scripting.Dictionary")

    Set mManualVoucherOverrides = CreateObject("Scripting.Dictionary")

    Set mManualDecisionOverrides = CreateObject("Scripting.Dictionary")

    Set mManualMemoOverrides = CreateObject("Scripting.Dictionary")

    LoadManualExcludedTxIds mManualExcludedTxIds

    LoadManualStateOverrides mManualVoucherOverrides, mManualDecisionOverrides, mManualMemoOverrides

    ReadAnalysisSettings

    Set mPersonInfo = BuildPersonInfoIndex()

    Set mAddressByPerson = BuildAddressByPersonIndex()

    Set mRelationPairs = BuildRelationPairIndex()

    Set mMarriageByPerson = BuildMarriageDateIndex()

    Set mCohabPairs = BuildCohabPairIndex()

    Set mTimeCluster = CreateObject("Scripting.Dictionary")

    Set mAccountOperationPatternCount = CreateObject("Scripting.Dictionary")



    Dim outs As Collection, ins As Collection, insByDate As Object, outByDate As Object

    Set outs = New Collection

    Set ins = New Collection

    Set insByDate = CreateObject("Scripting.Dictionary")

    Set outByDate = CreateObject("Scripting.Dictionary")



    LoadTransactionRecords outs, ins, outByDate, insByDate

    EnrichTransactionAfterBalanceContext

    If Not ValidateComplexityBeforeRun(outs.Count, ins.Count) Then GoTo SafeExit

    If mEnableOneToOne Then FindOneToOne outs, insByDate

    If mEnableOneToMany Then FindOneToMany outs, insByDate

    If mEnableManyToOne Then FindManyToOne ins, outByDate

    If mEnableManyToMany Then FindManyToMany outs, ins, outByDate, insByDate

    If mEnableUnknowns Then FindUnknowns outs, ins



SafeExit:

    BuildAnalysisResultSheet

    BuildInvestigationIssueSheet True

    BuildFlaggedTransactionSheet

    If SettingYes(ROW_AUTO_SAVE_COMMON, True) Then SaveAnalysisToCommonData True

    If SettingYes(ROW_KEEP_OUTPUT_VISIBLE, True) Then ShowOutputSheets Else HideDailySheets False



    AppEnd

    AppendLog "分析実行", "成功", "候補件数: " & CStr(Application.Max(0, LastRow(GetSheet(SH_WORK_RESULT), 1) - 1))

    MsgBox "分析が完了しました。" & vbCrLf & _
           "候補件数: " & CStr(Application.Max(0, LastRow(GetSheet(SH_WORK_RESULT), 1) - 1)), vbInformation

    Exit Sub

EH:

    AppEnd

    AppendLog "分析実行", "失敗", Err.Description

    MsgBox "分析実行中にエラーが発生しました。" & vbCrLf & Err.Description, vbExclamation

End Sub



Private Sub ReadAnalysisSettings()

    mDecedentId = CellText(GetSheet(SH_MAIN).Cells(ROW_DECEDENT_ID, COL_VALUE).Value)

    If IsDate(GetSheet(SH_MAIN).Cells(ROW_INHERITANCE_DATE, COL_VALUE).Value) Then

        mInheritanceDate = CDate(GetSheet(SH_MAIN).Cells(ROW_INHERITANCE_DATE, COL_VALUE).Value)

    Else

        mInheritanceDate = Empty

    End If

    mMinShift = GetSettingDouble(ROW_MIN_SHIFT_AMOUNT, DEFAULT_MIN_SHIFT_AMOUNT)

    mDateWindow = GetSettingLong(ROW_DATE_WINDOW, DEFAULT_DATE_WINDOW)

    mAmountTol = GetSettingDouble(ROW_AMOUNT_TOLERANCE, DEFAULT_AMOUNT_TOLERANCE)

    mAmountRate = NzDbl(GetSheet(SH_MAIN).Cells(ROW_AMOUNT_TOLERANCE_RATE, COL_VALUE).Value, DEFAULT_AMOUNT_TOLERANCE_RATE)

    mMaxCombo = GetSettingLong(ROW_MAX_COMBO, DEFAULT_MAX_COMBO)

    If mMaxCombo < 1 Then mMaxCombo = 1

    If mMaxCombo > MAX_ALLOWED_COMBO Then mMaxCombo = MAX_ALLOWED_COMBO

    mMaxSideCandidates = GetSettingLong(ROW_MAX_SIDE_CANDIDATES, DEFAULT_MAX_SIDE_CANDIDATES)

    If mMaxSideCandidates < 3 Then mMaxSideCandidates = 3

    If mMaxSideCandidates > 18 Then mMaxSideCandidates = 18

    mUnknownThreshold = GetSettingDouble(ROW_UNKNOWN_THRESHOLD, DEFAULT_UNKNOWN_THRESHOLD)

    mVoucherThreshold = GetSettingDouble(ROW_VOUCHER_THRESHOLD, DEFAULT_VOUCHER_THRESHOLD)

    mEnableOneToOne = SettingYes(ROW_ENABLE_ONE_TO_ONE, True)

    mEnableOneToMany = SettingYes(ROW_ENABLE_ONE_TO_MANY, True)

    mEnableManyToOne = SettingYes(ROW_ENABLE_MANY_TO_ONE, True)

    mEnableManyToMany = SettingYes(ROW_ENABLE_MANY_TO_MANY, True)

    mEnableUnknowns = SettingYes(ROW_ENABLE_UNKNOWNS, True)

    mSuppressDuplicateShift = SettingYes(ROW_SUPPRESS_DUPLICATE_SHIFT, True)

    mMaxResults = GetSettingLong(ROW_MAX_RESULTS, DEFAULT_MAX_RESULTS)

    If mMaxResults < 100 Then mMaxResults = 100

    If mMaxResults > 50000 Then mMaxResults = 50000

    mMaxCombosPerBase = GetSettingLong(ROW_MAX_COMBOS_PER_BASE, DEFAULT_MAX_COMBOS_PER_BASE)

    If mMaxCombosPerBase < 50 Then mMaxCombosPerBase = 50

    If mMaxCombosPerBase > 5000 Then mMaxCombosPerBase = 5000

    mMaxMtmPairTests = GetSettingLong(ROW_MAX_MTM_PAIR_TESTS, DEFAULT_MAX_MTM_PAIR_TESTS)

    If mMaxMtmPairTests < 1000 Then mMaxMtmPairTests = 1000

    If mMaxMtmPairTests > 300000 Then mMaxMtmPairTests = 300000

    mVoucherInheritanceAlways = SettingYes(ROW_VOUCHER_INHERITANCE_ALWAYS, True)

    mVoucherUnknowns = SettingYes(ROW_VOUCHER_UNKNOWNS, True)

    mExcludeSummaryKeywords = CellText(GetSheet(SH_MAIN).Cells(ROW_EXCLUDE_SUMMARY_KEYWORDS, COL_VALUE).Value)

    mStopIfTooBroad = SettingYes(ROW_STOP_IF_TOO_BROAD, True)

    mFocusYears = GetSettingLong(ROW_INHERITANCE_FOCUS_YEARS, DEFAULT_INHERITANCE_FOCUS_YEARS)

    If mFocusYears < 1 Then mFocusYears = DEFAULT_INHERITANCE_FOCUS_YEARS

    If mFocusYears > 20 Then mFocusYears = 20

    mMinScore = GetSettingLong(ROW_MIN_SCORE, DEFAULT_MIN_SCORE)

    If mMinScore < 0 Then mMinScore = 0

    If mMinScore > 100 Then mMinScore = 100

    mContextScore = SettingYes(ROW_CONTEXT_SCORE, True)

    mExcludedKeywordList = SplitExcludeKeywords(mExcludeSummaryKeywords)

    mStopRequested = False

    mResultCount = 0

End Sub



Public Sub LoadManualExcludedTxIds(ByVal dict As Object)

    Dim ws As Worksheet, lastR As Long, r As Long, txId As String

    If dict Is Nothing Then Exit Sub

    If Not SheetExists(SH_MANUAL_EXCLUDE) Then Exit Sub

    Set ws = GetSheet(SH_MANUAL_EXCLUDE)

    lastR = LastRow(ws, 1)

    For r = 2 To lastR

        txId = CellText(ws.Cells(r, 1).Value)

        If Len(txId) > 0 Then

            If Not dict.Exists(txId) Then dict.Add txId, True

        End If

    Next r

End Sub





Private Sub LoadManualStateOverrides(ByVal voucherDict As Object, ByVal decisionDict As Object, ByVal memoDict As Object)

    Dim ws As Worksheet, lastR As Long, r As Long, k As String

    If voucherDict Is Nothing Or decisionDict Is Nothing Or memoDict Is Nothing Then Exit Sub

    If Not SheetExists(SH_MANUAL_STATE) Then Exit Sub

    Set ws = GetSheet(SH_MANUAL_STATE)

    lastR = LastRow(ws, 1)

    For r = 2 To lastR

        k = CellText(ws.Cells(r, 1).Value)

        If Len(k) > 0 Then

            If Len(CellText(ws.Cells(r, 3).Value)) > 0 Then voucherDict(k) = CellText(ws.Cells(r, 3).Value)

            If Len(CellText(ws.Cells(r, 4).Value)) > 0 Then decisionDict(k) = CellText(ws.Cells(r, 4).Value)

            If Len(CellText(ws.Cells(r, 5).Value)) > 0 Then memoDict(k) = CellText(ws.Cells(r, 5).Value)

        End If

    Next r

End Sub



Private Sub LoadTransactionRecords(ByRef outs As Collection, ByRef ins As Collection, ByRef outByDate As Object, ByRef insByDate As Object)

    Dim ws As Worksheet, lastR As Long, r As Long, data As Variant

    Dim colTx As Long, colAcc As Long, colPerson As Long, colName As Long, colRel As Long

    Dim colBank As Long, colBranch As Long, colType As Long, colNo As Long, colDate As Long, colTime As Long

    Dim colOut As Long, colIn As Long, colShop As Long, colShopFilled As Long, colShopConverted As Long, colShopFinal As Long

    Dim colSummary As Long, colOther As Long, colAfterBalance As Long, colAfterBalanceRaw As Long

    Dim colRowKind As Long, colStatus As Long

    Dim d As Object, txDate As Variant, outAmt As Double, inAmt As Double, dateKey As String, afterBalanceValue As Variant
    Dim duplicateTxCount As Long, bothAmountCount As Long



    Set ws = GetSheet(SH_WORK_TX)

    colTx = FirstHeaderColumn(ws, Array("取引ID"), 1)

    colAcc = FirstHeaderColumn(ws, Array("口座ID"), 1)

    colPerson = FirstHeaderColumn(ws, Array("人物ID"), 1)

    colName = FirstHeaderColumn(ws, Array("氏名", "氏名表示"), 1)

    colRel = FirstHeaderColumn(ws, Array("続柄"), 1)

    colBank = FirstHeaderColumn(ws, Array("銀行名"), 1)

    colBranch = FirstHeaderColumn(ws, Array("支店名"), 1)

    colType = FirstHeaderColumn(ws, Array("科目"), 1)

    colNo = FirstHeaderColumn(ws, Array("口座番号"), 1)

    colDate = FirstHeaderColumn(ws, Array("日付", "取引日"), 1)

    colTime = FirstHeaderColumn(ws, Array("時刻", "取引時刻", "時間"), 1)

    colOut = FirstHeaderColumn(ws, Array("出金"), 1)

    colIn = FirstHeaderColumn(ws, Array("入金"), 1)

    colShop = FirstHeaderColumn(ws, Array("取扱店原文", "取扱店"), 1)

    colShopFilled = FirstHeaderColumn(ws, Array("取扱店補完値"), 1)

    colShopConverted = FirstHeaderColumn(ws, Array("取扱店変換後"), 1)

    colShopFinal = FirstHeaderColumn(ws, Array("取扱店確定値"), 1)

    colSummary = FirstHeaderColumn(ws, Array("摘要", "摘要欄"), 1)

    colOther = FirstHeaderColumn(ws, Array("その他"), 1)
    colAfterBalance = FirstHeaderColumn(ws, Array("取引後残高"), 1)
    colAfterBalanceRaw = FirstHeaderColumn(ws, Array("取引後残高原文"), 1)

    colRowKind = FirstHeaderColumn(ws, Array("元行種別", "行種別"), 1)

    colStatus = FirstHeaderColumn(ws, Array("データ状態"), 1)



    If colTx = 0 Or colDate = 0 Or colOut = 0 Or colIn = 0 Then Err.Raise vbObjectError + 9501, "LoadTransactionRecords", "T_取引の必須列が不足しています。"



    lastR = LastRow(ws, colTx)

    If lastR < 2 Then Exit Sub

    data = ws.Range(ws.Cells(1, 1), ws.Cells(lastR, LastUsedColumnFast(ws))).Value



    For r = 2 To UBound(data, 1)

        If colRowKind > 0 Then

            If Len(CellText(ArrayCell(data, r, colRowKind))) > 0 And CellText(ArrayCell(data, r, colRowKind)) <> "取引" Then GoTo NextTransactionRecord

        End If

        If colStatus > 0 Then

            If CellText(ArrayCell(data, r, colStatus)) = "取消" Then GoTo NextTransactionRecord

        End If

        txDate = ToDateOrEmpty(ArrayCell(data, r, colDate))

        outAmt = NzDbl(ArrayCell(data, r, colOut), 0)

        inAmt = NzDbl(ArrayCell(data, r, colIn), 0)

        If Len(CellText(ArrayCell(data, r, colTx))) > 0 And IsDate(txDate) Then

            Set d = CreateObject("Scripting.Dictionary")

            d("Row") = r

            d("TxId") = CellText(ArrayCell(data, r, colTx))

            d("AccountId") = ArrayText(data, r, colAcc)

            d("PersonId") = ArrayText(data, r, colPerson)

            d("Name") = ArrayText(data, r, colName)

            d("Relation") = ArrayText(data, r, colRel)

            d("Bank") = ArrayText(data, r, colBank)

            d("Branch") = ArrayText(data, r, colBranch)

            d("AccountType") = ArrayText(data, r, colType)

            d("AccountNo") = ArrayText(data, r, colNo)

            d("Date") = DateValue(CDate(txDate))

            d("DateKey") = CStr(DateOnlySerial(CDate(txDate)))

            ApplyRecordTimeFields d, ArrayCell(data, r, colTime), r

            EnrichTransactionContext d

            d("Out") = outAmt

            d("In") = inAmt

            d("Shop") = GetFinalShopFromArray(data, r, colShopFinal, colShopConverted, colShopFilled, colShop, colBranch)

            d("Summary") = ArrayText(data, r, colSummary)

            d("Other") = ArrayText(data, r, colOther)
            d("BalanceAfterRaw") = ArrayText(data, r, colAfterBalanceRaw)
            afterBalanceValue = TransactionAfterBalanceValue(ArrayCell(data, r, colAfterBalance))
            If Len(CellText(afterBalanceValue)) > 0 Then
                d("BalanceAfter") = CDbl(afterBalanceValue)
                d("BalanceAfterSource") = "取引後残高"
            ElseIf colAfterBalance = 0 And Len(CellText(TransactionAfterBalanceValue(d("Other")))) > 0 Then
                '後方互換用。旧22列の共通データだけ、その他欄を取引後残高として読む。
                d("BalanceAfter") = CDbl(TransactionAfterBalanceValue(d("Other")))
                d("BalanceAfterSource") = "旧形式その他欄"
            End If

            If IsExcludedTransaction(d) Then GoTo NextTransactionRecord

            If outAmt > 0 And inAmt > 0 Then
                bothAmountCount = bothAmountCount + 1
                GoTo NextTransactionRecord
            End If

            If mTxById.Exists(d("TxId")) Then
                duplicateTxCount = duplicateTxCount + 1
            Else
                mTxById.Add d("TxId"), d
            End If

            If outAmt > 0 Or inAmt > 0 Then AddTimeClusterRecord d

            dateKey = d("DateKey")

            If outAmt > 0 Then

                outs.Add d

                AddToDateIndex outByDate, dateKey, d

            End If

            If inAmt > 0 Then

                ins.Add d

                AddToDateIndex insByDate, dateKey, d

            End If

        End If

NextTransactionRecord:

    Next r

    If duplicateTxCount > 0 Then AppendLog "取引読込", "警告", "取引ID重複 " & CStr(duplicateTxCount) & "件。分析は継続しましたが、02側で共通データ保存を再実行してください。"
    If bothAmountCount > 0 Then AppendLog "取引読込", "確認", "出金・入金が両方プラスの行 " & CStr(bothAmountCount) & "件を自動分析から隔離しました。"

End Sub



Private Function ArrayCell(ByRef data As Variant, ByVal r As Long, ByVal c As Long) As Variant

    If c <= 0 Then

        ArrayCell = Empty

    ElseIf c > UBound(data, 2) Then

        ArrayCell = Empty

    Else

        ArrayCell = data(r, c)

    End If

End Function



Private Function ArrayText(ByRef data As Variant, ByVal r As Long, ByVal c As Long) As String

    ArrayText = CellText(ArrayCell(data, r, c))

End Function




Private Function GetCellByCol(ByVal ws As Worksheet, ByVal r As Long, ByVal c As Long) As String
    If c <= 0 Then
        GetCellByCol = ""
    Else
        GetCellByCol = CellText(ws.Cells(r, c).Value)
    End If
End Function

Private Function LastUsedColumnFast(ByVal ws As Worksheet) As Long

    Dim f As Range

    On Error Resume Next

    Set f = ws.Cells.Find(What:="*", After:=ws.Cells(1, 1), LookIn:=xlFormulas, LookAt:=xlPart, SearchOrder:=xlByColumns, SearchDirection:=xlPrevious)

    On Error GoTo 0

    If f Is Nothing Then

        LastUsedColumnFast = 1

    Else

        LastUsedColumnFast = f.Column

    End If

End Function



Private Sub ApplyRecordTimeFields(ByVal rec As Object, ByVal timeValue As Variant, ByVal inputOrder As Long)

    Dim t As Variant

    t = TimeFractionOrEmpty(timeValue)

    If IsEmpty(t) Then

        rec("HasTime") = False

        rec("TimeQuality") = "時刻なし"

        rec("TimeFraction") = 0#

        '時刻なしは 0:00 / 日末に寄せない。日付＋明細内順序でだけ並べ、同日方向は断定しない。
        rec("DateTimeSort") = CDbl(DateOnlySerial(rec("Date"))) + InputOrderFraction(inputOrder)

    Else

        rec("HasTime") = True

        rec("TimeQuality") = "時刻あり"

        rec("TimeFraction") = CDbl(t)

        rec("DateTimeSort") = CDbl(DateOnlySerial(rec("Date"))) + CDbl(t)

    End If

    rec("InputOrder") = inputOrder

End Sub

Private Function InputOrderFraction(ByVal inputOrder As Long) As Double

    If inputOrder <= 0 Then Exit Function

    InputOrderFraction = CDbl(inputOrder Mod 100000) / 100000000#

End Function




Private Sub EnrichTransactionContext(ByVal rec As Object)

    Dim personId As String, txDate As Date, ageYears As Long

    If rec Is Nothing Then Exit Sub

    rec("AgeAtTx") = ""

    rec("AgeYearsAtTx") = -1

    rec("AddressAtTx") = ""

    rec("AddressKeyAtTx") = ""

    rec("AddressChangeNearTx") = ""
    rec("RelatedMoveNearTx") = ""

    personId = CStr(rec("PersonId"))

    If Len(personId) = 0 Or Not IsDate(rec("Date")) Then Exit Sub

    txDate = CDate(rec("Date"))

    rec("AgeAtTx") = PersonAgeAtDate(personId, txDate)

    ageYears = PersonAgeYearsAtDate(personId, txDate)

    rec("AgeYearsAtTx") = ageYears

    rec("AddressAtTx") = PersonAddressAtDate(personId, txDate, False)

    rec("AddressKeyAtTx") = PersonAddressAtDate(personId, txDate, True)

    rec("AddressChangeNearTx") = AddressChangeNearDate(personId, txDate, DEFAULT_MOVE_NEAR_WINDOW_DAYS)

    rec("RelatedMoveNearTx") = RelatedMoveNearTransaction(personId, txDate, DEFAULT_MOVE_NEAR_WINDOW_DAYS)

End Sub

Private Sub AddTimeClusterRecord(ByVal rec As Object)

    Dim k As String, col As Collection

    If rec Is Nothing Then Exit Sub

    If mTimeCluster Is Nothing Then Set mTimeCluster = CreateObject("Scripting.Dictionary")

    k = TimeClusterKey(rec)

    If Len(k) = 0 Then Exit Sub

    If mTimeCluster.Exists(k) Then

        Set col = mTimeCluster(k)

    Else

        Set col = New Collection

        mTimeCluster.Add k, col

    End If

    UpdateAccountOperationPatternCount col, rec

    col.Add rec

End Sub

Private Sub UpdateAccountOperationPatternCount(ByVal existingRecords As Collection, ByVal rec As Object)

    Dim other As Object, acc As String, otherAcc As String, personId As String, otherPersonId As String

    If existingRecords Is Nothing Then Exit Sub

    If rec Is Nothing Then Exit Sub

    acc = CStr(rec("AccountId"))

    personId = CStr(rec("PersonId"))

    If Len(acc) = 0 Then Exit Sub

    If mAccountOperationPatternCount Is Nothing Then Set mAccountOperationPatternCount = CreateObject("Scripting.Dictionary")

    For Each other In existingRecords

        otherAcc = CStr(other("AccountId"))

        otherPersonId = CStr(other("PersonId"))

        If Len(otherAcc) > 0 Then

            If otherAcc <> acc Or otherPersonId <> personId Then

                IncrementAccountOperationPattern acc

                IncrementAccountOperationPattern otherAcc

            End If

        End If

    Next other

End Sub

Private Sub IncrementAccountOperationPattern(ByVal accountId As String)

    If Len(accountId) = 0 Then Exit Sub

    If mAccountOperationPatternCount Is Nothing Then Set mAccountOperationPatternCount = CreateObject("Scripting.Dictionary")

    If mAccountOperationPatternCount.Exists(accountId) Then

        mAccountOperationPatternCount(accountId) = CLng(mAccountOperationPatternCount(accountId)) + 1

    Else

        mAccountOperationPatternCount.Add accountId, 1

    End If

End Sub

Private Function NearbyTimeClusterRecords(ByVal rec As Object) As Collection

    Dim result As New Collection, dayKey As Long, bucket As Long, offset As Long, k As String, src As Collection, item As Object

    Set NearbyTimeClusterRecords = result

    If rec Is Nothing Then Exit Function

    If mTimeCluster Is Nothing Then Exit Function

    If Not KeyExists(rec, "HasTime") Then Exit Function

    If Not CBool(rec("HasTime")) Then Exit Function

    dayKey = DateOnlySerial(rec("Date"))

    If dayKey = 0 Then Exit Function

    bucket = CLng(Fix(CDbl(rec("TimeFraction")) * 1440# / 15#))

    For offset = -1 To 1

        k = CStr(dayKey) & "|" & CStr(bucket + offset)

        If mTimeCluster.Exists(k) Then

            Set src = mTimeCluster(k)

            For Each item In src

                result.Add item

            Next item

        End If

    Next offset

End Function

Private Function TimeClusterKey(ByVal rec As Object) As String

    Dim dayKey As Long, bucket As Long

    If rec Is Nothing Then Exit Function

    If Not KeyExists(rec, "HasTime") Then Exit Function

    If Not CBool(rec("HasTime")) Then Exit Function

    dayKey = DateOnlySerial(rec("Date"))

    If dayKey = 0 Then Exit Function

    bucket = CLng(Fix(CDbl(rec("TimeFraction")) * 1440# / 15#))

    TimeClusterKey = CStr(dayKey) & "|" & CStr(bucket)

End Function

Private Function TimeBucketMinutes(ByVal rec As Object) As Long

    If rec Is Nothing Then Exit Function

    If KeyExists(rec, "HasTime") And CBool(rec("HasTime")) Then TimeBucketMinutes = CLng(Fix(CDbl(rec("TimeFraction")) * 1440# / 15#)) * 15

End Function

Private Function TimeFractionOrEmpty(ByVal v As Variant) As Variant

    Dim s As String, x As Double, hh As Long, mm As Long

    On Error GoTo EH

    If IsError(v) Or IsNull(v) Or IsEmpty(v) Then Exit Function

    s = CellText(v)

    On Error Resume Next
    s = StrConv(s, vbNarrow)
    On Error GoTo EH

    If Len(s) = 0 Then Exit Function

    s = Replace$(s, "：", ":")
    s = Replace$(s, "時", ":")
    s = Replace$(s, "分", "")
    s = Replace$(s, " ", "")
    s = Replace$(s, "　", "")



    ' 数値入力は先に時刻として解釈する。1200 を日付シリアル扱いして 0:00 にしないため。

    If IsNumeric(s) Then

        x = CDbl(s)

        If x >= 0 And x < 1 Then

            TimeFractionOrEmpty = x

            Exit Function

        End If

        If x >= 100 And x <= 2359 Then

            hh = CLng(Fix(x / 100#))

            mm = CLng(x - hh * 100)

            If hh >= 0 And hh < 24 And mm >= 0 And mm < 60 Then

                TimeFractionOrEmpty = (hh * 60# + mm) / 1440#

                Exit Function

            End If

        End If

        If x >= 0 And x < 24 Then

            TimeFractionOrEmpty = x / 24#

            Exit Function

        End If

    End If



    If InStr(1, s, ":", vbTextCompare) > 0 Then

        x = CDbl(CDate(s)) - Int(CDbl(CDate(s)))

        TimeFractionOrEmpty = x

        Exit Function

    End If



    If IsDate(v) Then

        x = CDbl(CDate(v)) - Int(CDbl(CDate(v)))

        If x < 0 Then x = 0

        TimeFractionOrEmpty = x

        Exit Function

    End If

    Exit Function

EH:

    TimeFractionOrEmpty = Empty

End Function



Private Function DateOnlySerial(ByVal v As Variant) As Long

    If IsDate(v) Then DateOnlySerial = CLng(DateValue(CDate(v)))

End Function



Private Function GetFinalShopFromArray(ByRef data As Variant, ByVal r As Long, ByVal colShopFinal As Long, ByVal colShopConverted As Long, ByVal colShopFilled As Long, ByVal colShopRaw As Long, ByVal colBranch As Long) As String

    GetFinalShopFromArray = ArrayText(data, r, colShopFinal)

    If Len(GetFinalShopFromArray) = 0 Then GetFinalShopFromArray = ArrayText(data, r, colShopConverted)

    If Len(GetFinalShopFromArray) = 0 Then GetFinalShopFromArray = ArrayText(data, r, colShopFilled)

    If Len(GetFinalShopFromArray) = 0 Then GetFinalShopFromArray = ArrayText(data, r, colShopRaw)

    If Len(GetFinalShopFromArray) = 0 Then GetFinalShopFromArray = ArrayText(data, r, colBranch)

End Function



Private Sub AddToDateIndex(ByVal idx As Object, ByVal dateKey As String, ByVal rec As Object)

    Dim col As Collection

    If idx.Exists(dateKey) Then

        Set col = idx(dateKey)

    Else

        Set col = New Collection

        idx.Add dateKey, col

    End If

    col.Add rec

End Sub



Private Sub FindOneToOne(ByVal outs As Collection, ByVal insByDate As Object)

    Dim o As Object, candidates As Collection, i As Long, recIn As Object

    For Each o In outs

        If ResultLimitReached() Then Exit Sub

        If Not ShouldSkipShiftRecord(o) And CDbl(o("Out")) >= mMinShift Then

            Set candidates = CandidateRecordsByFlow(insByDate, o, mDateWindow, mMaxSideCandidates * 3, True)

            For i = 1 To candidates.Count

                If ResultLimitReached() Then Exit Sub

                Set recIn = candidates(i)

                If Not ShouldSkipShiftRecord(recIn) And CDbl(recIn("In")) >= mMinShift Then

                    If AmountClose(CDbl(o("Out")), CDbl(recIn("In"))) Then

                        AddAnalysisCandidate "1対1", CollectionFromOne(o), CollectionFromOne(recIn)

                    End If

                End If

            Next i

        End If

    Next o

End Sub



Private Sub FindOneToMany(ByVal outs As Collection, ByVal insByDate As Object)

    Dim o As Object, candidates As Collection, combos As Collection, c As Object, i As Long

    If mMaxCombo < 2 Then Exit Sub

    For Each o In outs

        If ResultLimitReached() Then Exit Sub

        If Not ShouldSkipShiftRecord(o) And CDbl(o("Out")) >= mMinShift Then

            Set candidates = CandidateRecordsByFlow(insByDate, o, mDateWindow, mMaxSideCandidates, True)

            Set candidates = FilterCandidatesForShift(candidates)

            Set combos = BuildCombosNearAmount(candidates, 2, mMaxCombo, CDbl(o("Out")))

            For i = 1 To combos.Count

                If ResultLimitReached() Then Exit Sub

                Set c = combos(i)

                AddAnalysisCandidate "1対複数", CollectionFromOne(o), c("Records")

            Next i

        End If

    Next o

End Sub



Private Sub FindManyToOne(ByVal ins As Collection, ByVal outByDate As Object)

    Dim recIn As Object, candidates As Collection, combos As Collection, c As Object, i As Long

    If mMaxCombo < 2 Then Exit Sub

    For Each recIn In ins

        If ResultLimitReached() Then Exit Sub

        If Not ShouldSkipShiftRecord(recIn) And CDbl(recIn("In")) >= mMinShift Then

            Set candidates = CandidateRecordsByFlow(outByDate, recIn, mDateWindow, mMaxSideCandidates, False)

            Set candidates = FilterCandidatesForShift(candidates)

            Set combos = BuildCombosNearAmount(candidates, 2, mMaxCombo, CDbl(recIn("In")), True)

            For i = 1 To combos.Count

                If ResultLimitReached() Then Exit Sub

                Set c = combos(i)

                AddAnalysisCandidate "複数対1", c("Records"), CollectionFromOne(recIn)

            Next i

        End If

    Next recIn

End Sub



Private Sub FindManyToMany(ByVal outs As Collection, ByVal ins As Collection, ByVal outByDate As Object, ByVal insByDate As Object)

    Dim base As Object, outCandidates As Collection, inCandidates As Collection

    Dim outCombos As Collection, inCombos As Collection, inComboIndex As Object, matches As Collection

    Dim co As Object, ci As Object, i As Long, j As Long, pairTests As Long

    If mMaxCombo < 2 Then Exit Sub



    For Each base In outs

        If ResultLimitReached() Then Exit Sub

        If Not ShouldSkipShiftRecord(base) And CDbl(base("Out")) >= mMinShift Then

            Set outCandidates = CandidateRecordsByDate(outByDate, CDate(base("Date")), mDateWindow, mMaxSideCandidates)

            Set inCandidates = CandidateRecordsByFlow(insByDate, base, mDateWindow, mMaxSideCandidates, True)

            Set outCandidates = FilterCandidatesForShift(outCandidates)

            Set inCandidates = FilterCandidatesForShift(inCandidates)

            Set outCombos = BuildCombos(outCandidates, 2, mMaxCombo, True)

            Set inCombos = BuildCombos(inCandidates, 2, mMaxCombo)

            Set inComboIndex = BuildComboAmountIndex(inCombos)

            pairTests = 0

            For i = 1 To outCombos.Count

                If ResultLimitReached() Then Exit Sub

                Set co = outCombos(i)

                If CDbl(co("Sum")) >= mMinShift Then

                    Set matches = CandidateCombosByAmountIndexed(inComboIndex, CDbl(co("Sum")))

                    For j = 1 To matches.Count

                        pairTests = pairTests + 1

                        If pairTests > mMaxMtmPairTests Then Exit For

                        Set ci = matches(j)

                        AddAnalysisCandidate "複数対複数", co("Records"), ci("Records")

                        If ResultLimitReached() Then Exit Sub

                    Next j

                End If

                If pairTests > mMaxMtmPairTests Then Exit For

            Next i

        End If

    Next base

End Sub



Private Sub FindUnknowns(ByVal outs As Collection, ByVal ins As Collection)

    Dim o As Object, i As Object

    For Each o In outs

        If ResultLimitReached() Then Exit Sub

        If CDbl(o("Out")) >= mUnknownThreshold Then

            If Not mSuppressDuplicateShift Or Not mMatched.Exists(CStr(o("TxId"))) Then

                AddUnknownCandidate KIND_UNKNOWN_OUT, o

            End If

        End If

    Next o

    For Each i In ins

        If ResultLimitReached() Then Exit Sub

        If CDbl(i("In")) >= mUnknownThreshold Then

            If Not mSuppressDuplicateShift Or Not mMatched.Exists(CStr(i("TxId"))) Then

                AddUnknownCandidate KIND_UNKNOWN_IN, i

            End If

        End If

    Next i

End Sub



Private Function ValidateComplexityBeforeRun(ByVal outCount As Long, ByVal inCount As Long) As Boolean

    ValidateComplexityBeforeRun = True

    If Not mStopIfTooBroad Then Exit Function

    If mMaxCombo > 10 Then

        MsgBox "最大組合せ件数は10件までです。設定を見直してください。", vbExclamation

        ValidateComplexityBeforeRun = False

        Exit Function

    End If

    If mEnableManyToMany And mMaxCombo >= 6 Then

        ValidateComplexityBeforeRun = (MsgBox("最大組合せ件数が大きめです。" & vbCrLf & _
                                              "このツールは候補生成上限・照合上限で止めるため無制限なO(n^k)処理にはしませんが、候補漏れや処理時間増加は起こり得ます。続行しますか。", vbQuestion + vbYesNo) = vbYes)

        If Not ValidateComplexityBeforeRun Then Exit Function

    End If

    If mEnableManyToMany And mMaxCombo >= 3 And mDateWindow > 7 And mMaxSideCandidates > 12 Then

        ValidateComplexityBeforeRun = (MsgBox("複数対複数の条件が広めです。処理が重くなる可能性があります。" & vbCrLf & _
                                              "日付許容日数・候補上限・最大組合せ件数を絞ることを推奨します。続行しますか。", vbQuestion + vbYesNo) = vbYes)

        Exit Function

    End If

    If outCount * inCount > 5000000# And mEnableManyToMany Then

        ValidateComplexityBeforeRun = (MsgBox("取引件数が多く、複数対複数を含めると重くなる可能性があります。" & vbCrLf & _
                                              "先に1対1・1対複数・複数対1だけで分析することを推奨します。続行しますか。", vbQuestion + vbYesNo) = vbYes)

    End If

End Function



Private Function ResultLimitReached() As Boolean

    If mStopRequested Then

        ResultLimitReached = True

        Exit Function

    End If

    If mMaxResults > 0 Then

        If mResultCount >= mMaxResults Then

            mStopRequested = True

            AppendLog "分析上限", "停止", "最大候補件数に達しました: " & CStr(mMaxResults)

            ResultLimitReached = True

        End If

    End If

End Function



Private Function ShouldSkipShiftRecord(ByVal rec As Object) As Boolean

    ' 取引単位の手動除外だけをここで除外する。

    ' 一度候補化した取引を即座に外すと、より妥当な別候補を拾えない危険があるため、

    ' 候補生成中は先着候補で取引を潰さない。

    Dim txId As String

    txId = CStr(rec("TxId"))

    ShouldSkipShiftRecord = False

    If Not mManualExcludedTxIds Is Nothing Then

        If mManualExcludedTxIds.Exists(txId) Then ShouldSkipShiftRecord = True

    End If

End Function



Private Function FilterCandidatesForShift(ByVal records As Collection) As Collection

    Dim out As New Collection, rec As Object

    For Each rec In records

        If Not ShouldSkipShiftRecord(rec) Then out.Add rec

    Next rec

    Set FilterCandidatesForShift = out

End Function



Private Function IsExcludedTransaction(ByVal rec As Object) As Boolean

    Dim i As Long, s As String, w As String

    IsExcludedTransaction = False

    If IsEmpty(mExcludedKeywordList) Then Exit Function

    s = CStr(rec("Summary")) & " " & CStr(rec("Other"))

    For i = LBound(mExcludedKeywordList) To UBound(mExcludedKeywordList)

        w = CStr(mExcludedKeywordList(i))

        If Len(w) > 0 Then

            If InStr(1, s, w, vbTextCompare) > 0 Then

                IsExcludedTransaction = True

                Exit Function

            End If

        End If

    Next i

End Function



Private Function SplitExcludeKeywords(ByVal keywordsText As String) As Variant

    Dim raw As Variant, out() As String, i As Long, n As Long, w As String

    If Len(Trim$(keywordsText)) = 0 Then

        SplitExcludeKeywords = Empty

        Exit Function

    End If

    raw = Split(keywordsText, ",")

    ReDim out(0 To UBound(raw))

    For i = LBound(raw) To UBound(raw)

        w = Trim$(CStr(raw(i)))

        If Len(w) > 0 Then

            out(n) = w

            n = n + 1

        End If

    Next i

    If n = 0 Then

        SplitExcludeKeywords = Empty

    Else

        ReDim Preserve out(0 To n - 1)

        SplitExcludeKeywords = out

    End If

End Function



Private Function VoucherFlagForCandidate(ByVal kindText As String, ByVal amountValue As Double) As String

    If kindText = KIND_INHERITANCE_SHIFT And mVoucherInheritanceAlways Then

        VoucherFlagForCandidate = VOUCHER_YES

    ElseIf amountValue >= mVoucherThreshold Then

        VoucherFlagForCandidate = VOUCHER_YES

    Else

        VoucherFlagForCandidate = VOUCHER_NO

    End If

End Function



Private Function VoucherFlagForUnknown(ByVal amountValue As Double) As String

    If mVoucherUnknowns And amountValue >= mVoucherThreshold Then

        VoucherFlagForUnknown = VOUCHER_YES

    Else

        VoucherFlagForUnknown = VOUCHER_NO

    End If

End Function



Private Function CandidateRecordsByDate(ByVal idx As Object, ByVal baseDate As Date, ByVal windowDays As Long, ByVal limitCount As Long) As Collection

    ' 基準日に近い順で候補化する。日付は DateValue で丸め、時刻の端数で日付キーがずれないようにする。

    Dim out As New Collection, offset As Long, k As String, col As Collection, ordered As Collection, i As Long

    Dim offsets As Collection, v As Variant

    Set offsets = New Collection

    offsets.Add 0

    For offset = 1 To windowDays

        offsets.Add -offset

        offsets.Add offset

    Next offset

    For Each v In offsets

        k = CStr(DateOnlySerial(baseDate) + CLng(v))

        If idx.Exists(k) Then

            Set col = idx(k)

            Set ordered = SortCandidateCollection(col, Nothing, True)

            For i = 1 To ordered.Count

                out.Add ordered(i)

                If out.Count >= limitCount Then

                    Set CandidateRecordsByDate = out

                    Exit Function

                End If

            Next i

        End If

    Next v

    Set CandidateRecordsByDate = out

End Function



Private Function CandidateRecordsByFlow(ByVal idx As Object, ByVal baseRec As Object, ByVal windowDays As Long, ByVal limitCount As Long, ByVal wantInSide As Boolean) As Collection

    ' wantInSide=True  : baseRec は出金。候補入金は同日以後だけ。時刻が双方にあれば base 出金時刻以後だけ。

    ' wantInSide=False : baseRec は入金。候補出金は同日以前だけ。時刻が双方にあれば base 入金時刻以前だけ。

    Dim out As New Collection, offset As Long, k As String, col As Collection, ordered As Collection, i As Long, rec As Object

    If baseRec Is Nothing Then

        Set CandidateRecordsByFlow = out

        Exit Function

    End If



    For offset = 0 To windowDays

        If wantInSide Then

            k = CStr(DateOnlySerial(baseRec("Date")) + offset)

        Else

            k = CStr(DateOnlySerial(baseRec("Date")) - offset)

        End If

        If idx.Exists(k) Then

            Set col = idx(k)

            Set ordered = SortCandidateCollection(col, baseRec, wantInSide)

            For i = 1 To ordered.Count

                Set rec = ordered(i)

                If IsDirectionalRecordPairPossible(baseRec, rec, wantInSide) Then

                    out.Add rec

                    If out.Count >= limitCount Then

                        Set CandidateRecordsByFlow = out

                        Exit Function

                    End If

                End If

            Next i

        End If

    Next offset

    Set CandidateRecordsByFlow = out

End Function



Private Function IsDirectionalRecordPairPossible(ByVal baseRec As Object, ByVal candidateRec As Object, ByVal wantInSide As Boolean) As Boolean

    Dim baseDay As Long, candDay As Long

    IsDirectionalRecordPairPossible = True

    If baseRec Is Nothing Or candidateRec Is Nothing Then Exit Function

    baseDay = DateOnlySerial(baseRec("Date"))

    candDay = DateOnlySerial(candidateRec("Date"))

    If baseDay = 0 Or candDay = 0 Then Exit Function



    If wantInSide Then

        ' base 出金 → candidate 入金

        If candDay < baseDay Then IsDirectionalRecordPairPossible = False: Exit Function

        If candDay = baseDay And CBool(baseRec("HasTime")) And CBool(candidateRec("HasTime")) Then

            If CDbl(candidateRec("TimeFraction")) + 0.00000001 < CDbl(baseRec("TimeFraction")) Then IsDirectionalRecordPairPossible = False

        End If

    Else

        ' candidate 出金 → base 入金

        If candDay > baseDay Then IsDirectionalRecordPairPossible = False: Exit Function

        If candDay = baseDay And CBool(baseRec("HasTime")) And CBool(candidateRec("HasTime")) Then

            If CDbl(candidateRec("TimeFraction")) > CDbl(baseRec("TimeFraction")) + 0.00000001 Then IsDirectionalRecordPairPossible = False

        End If

    End If

End Function



Private Function SortCandidateCollection(ByVal records As Collection, ByVal baseRec As Object, ByVal wantInSide As Boolean) As Collection

    Dim out As New Collection, rec As Object, i As Long, inserted As Boolean

    For Each rec In records

        inserted = False

        For i = 1 To out.Count

            If CandidateSortKey(rec, baseRec, wantInSide) < CandidateSortKey(out(i), baseRec, wantInSide) Then

                out.Add rec, , i

                inserted = True

                Exit For

            End If

        Next i

        If Not inserted Then out.Add rec

    Next rec

    Set SortCandidateCollection = out

End Function



Private Function CandidateSortKey(ByVal rec As Object, ByVal baseRec As Object, ByVal wantInSide As Boolean) As Double

    Dim keyValue As Double, baseDay As Long, recDay As Long, recTimePenalty As Double

    If rec Is Nothing Then CandidateSortKey = 999999999#: Exit Function

    recDay = DateOnlySerial(rec("Date"))

    If Not baseRec Is Nothing Then

        baseDay = DateOnlySerial(baseRec("Date"))

        keyValue = Abs(recDay - baseDay) * 1000000#

        If recDay = baseDay Then

            If CBool(rec("HasTime")) And CBool(baseRec("HasTime")) Then

                keyValue = keyValue + Abs(CDbl(rec("TimeFraction")) - CDbl(baseRec("TimeFraction"))) * 100000#

            ElseIf CBool(rec("HasTime")) Then

                keyValue = keyValue + CDbl(rec("TimeFraction")) * 1000#

            Else

                keyValue = keyValue + 5000#

            End If

        Else

            If CBool(rec("HasTime")) Then keyValue = keyValue + CDbl(rec("TimeFraction")) * 1000#

        End If

    Else

        keyValue = recDay * 1000000#

        If CBool(rec("HasTime")) Then

            keyValue = keyValue + CDbl(rec("TimeFraction")) * 100000#

        Else

            keyValue = keyValue + 5000#

        End If

    End If

    If KeyExists(rec, "InputOrder") Then keyValue = keyValue + CDbl(rec("InputOrder")) / 1000000#

    CandidateSortKey = keyValue

End Function



Private Function CollectionFromOne(ByVal rec As Object) As Collection

    Dim c As New Collection

    c.Add rec

    Set CollectionFromOne = c

End Function



Private Function BuildCombos(ByVal records As Collection, ByVal minDepth As Long, ByVal maxDepth As Long, Optional ByVal useOut As Boolean = False) As Collection

    Dim result As New Collection, tmp As New Collection

    Dim target As Long, maxOutCombos As Long

    maxOutCombos = mMaxCombosPerBase

    If records.Count = 0 Then

        Set BuildCombos = result

        Exit Function

    End If

    For target = minDepth To Application.Min(maxDepth, records.Count)

        BuildCombosRec records, 1, target, tmp, result, useOut, maxOutCombos

        If result.Count >= maxOutCombos Then Exit For

    Next target

    Set BuildCombos = result

End Function



Private Function BuildCombosNearAmount(ByVal records As Collection, ByVal minDepth As Long, ByVal maxDepth As Long, ByVal targetAmount As Double, Optional ByVal useOut As Boolean = False) As Collection

    ' 1対複数・複数対1では、全組合せを作ってから金額判定するのではなく、

    ' 目標額＋許容差を超えた時点で枝刈りする。精度は落とさず、組合せ爆発を抑える。

    Dim result As New Collection, tmp As New Collection

    Dim targetDepth As Long, maxOutCombos As Long, tol As Double

    maxOutCombos = mMaxCombosPerBase

    If records Is Nothing Then

        Set BuildCombosNearAmount = result

        Exit Function

    End If

    If records.Count = 0 Or targetAmount <= 0 Then

        Set BuildCombosNearAmount = result

        Exit Function

    End If

    tol = EffectiveTolerance(targetAmount, targetAmount)

    For targetDepth = minDepth To Application.Min(maxDepth, records.Count)

        BuildCombosNearAmountRec records, 1, targetDepth, tmp, result, useOut, maxOutCombos, targetAmount, tol, 0#

        If result.Count >= maxOutCombos Then Exit For

    Next targetDepth

    Set BuildCombosNearAmount = result

End Function



Private Sub BuildCombosNearAmountRec(ByVal records As Collection, ByVal startIdx As Long, ByVal targetDepth As Long, ByVal tmp As Collection, ByVal result As Collection, ByVal useOut As Boolean, ByVal maxOutCombos As Long, ByVal targetAmount As Double, ByVal tol As Double, ByVal currentSum As Double)

    Dim i As Long, amountValue As Double

    If result.Count >= maxOutCombos Then Exit Sub

    If currentSum > targetAmount + tol Then Exit Sub

    If tmp.Count = targetDepth Then

        If Abs(currentSum - targetAmount) <= EffectiveTolerance(currentSum, targetAmount) Then result.Add ComboObject(tmp, useOut)

        Exit Sub

    End If

    For i = startIdx To records.Count

        If useOut Then

            amountValue = CDbl(records(i)("Out"))

        Else

            amountValue = CDbl(records(i)("In"))

        End If

        If amountValue > 0 Then

            tmp.Add records(i)

            BuildCombosNearAmountRec records, i + 1, targetDepth, tmp, result, useOut, maxOutCombos, targetAmount, tol, currentSum + amountValue

            tmp.Remove tmp.Count

            If result.Count >= maxOutCombos Then Exit For

        End If

    Next i

End Sub



Private Sub BuildCombosRec(ByVal records As Collection, ByVal startIdx As Long, ByVal targetDepth As Long, ByVal tmp As Collection, ByVal result As Collection, ByVal useOut As Boolean, ByVal maxOutCombos As Long)

    Dim i As Long

    If result.Count >= maxOutCombos Then Exit Sub

    If tmp.Count = targetDepth Then

        result.Add ComboObject(tmp, useOut)

        Exit Sub

    End If

    For i = startIdx To records.Count

        tmp.Add records(i)

        BuildCombosRec records, i + 1, targetDepth, tmp, result, useOut, maxOutCombos

        tmp.Remove tmp.Count

        If result.Count >= maxOutCombos Then Exit For

    Next i

End Sub



Private Function ComboObject(ByVal recs As Collection, ByVal useOut As Boolean) As Object

    Dim d As Object, r As Object, sumAmt As Double, copy As New Collection, ids As String

    Set d = CreateObject("Scripting.Dictionary")

    For Each r In recs

        copy.Add r

        If useOut Then

            sumAmt = sumAmt + CDbl(r("Out"))

        Else

            sumAmt = sumAmt + CDbl(r("In"))

        End If

        If Len(ids) > 0 Then ids = ids & ","

        ids = ids & CStr(r("TxId"))

    Next r

    d.Add "Records", copy

    d.Add "Sum", sumAmt

    d.Add "Ids", ids

    Set ComboObject = d

End Function



Private Function AmountClose(ByVal outAmt As Double, ByVal inAmt As Double) As Boolean

    AmountClose = (Abs(outAmt - inAmt) <= EffectiveTolerance(outAmt, inAmt))

End Function



Private Function EffectiveTolerance(ByVal outAmt As Double, ByVal inAmt As Double) As Double

    EffectiveTolerance = mAmountTol

    If mAmountRate > 0 Then

        EffectiveTolerance = Application.Max(EffectiveTolerance, Application.Max(outAmt, inAmt) * mAmountRate)

    End If

End Function



Private Function AmountBucketUnit() As Double

    AmountBucketUnit = mAmountTol

    If AmountBucketUnit < 1 Then AmountBucketUnit = 1

End Function



Private Function AmountBucketKey(ByVal amountValue As Double) As Long

    AmountBucketKey = CLng(Fix(amountValue / AmountBucketUnit()))

End Function



Private Function BuildComboAmountIndex(ByVal combos As Collection) As Object

    Dim idx As Object, i As Long, c As Object, k As String, col As Collection

    Set idx = CreateObject("Scripting.Dictionary")

    For i = 1 To combos.Count

        Set c = combos(i)

        k = CStr(AmountBucketKey(CDbl(c("Sum"))))

        If idx.Exists(k) Then

            Set col = idx(k)

        Else

            Set col = New Collection

            idx.Add k, col

        End If

        col.Add c

    Next i

    Set BuildComboAmountIndex = idx

End Function



Private Function CandidateCombosByAmountIndexed(ByVal idx As Object, ByVal amountValue As Double) As Collection

    Dim out As New Collection, tol As Double, unit As Double

    Dim kMin As Long, kMax As Long, k As Long, col As Collection, i As Long, c As Object

    unit = AmountBucketUnit()

    tol = EffectiveTolerance(amountValue, amountValue)

    kMin = CLng(Fix((amountValue - tol) / unit)) - 1

    kMax = CLng(Fix((amountValue + tol) / unit)) + 1

    For k = kMin To kMax

        If idx.Exists(CStr(k)) Then

            Set col = idx(CStr(k))

            For i = 1 To col.Count

                Set c = col(i)

                If AmountClose(amountValue, CDbl(c("Sum"))) Then out.Add c

            Next i

        End If

    Next k

    Set CandidateCombosByAmountIndexed = out

End Function



Private Sub AddAnalysisCandidate(ByVal patternText As String, ByVal outRecords As Collection, ByVal inRecords As Collection)

    If ResultLimitReached() Then Exit Sub

    If Not IsTemporalFlowValid(outRecords, inRecords) Then Exit Sub

    If CollectionsShareValue(outRecords, inRecords, "TxId") Then Exit Sub

    Dim outIds As String, inIds As String, key As String

    outIds = SortedIds(outRecords)

    inIds = SortedIds(inRecords)

    key = patternText & "|O:" & outIds & "|I:" & inIds

    If mDedupe.Exists(key) Then Exit Sub

    mDedupe.Add key, True



    Dim kindText As String, analysisId As String, score As Long

    Dim outSum As Double, inSum As Double, diff As Double

    Dim outPerson As String, inPerson As String, nameRel As String, inhTiming As String, cohab As String

    Dim outDateMin As Variant, outDateMax As Variant, inDateMin As Variant, inDateMax As Variant

    Dim shops As String, summaryText As String, memo As String, voucher As String

    Dim stateKey As String, decisionText As String, operationMemoText As String

    Dim ageHint As String, addressHint As String, temporalHint As String

    analysisId = NextId("分析候補")

    outSum = SumRecords(outRecords, True)

    inSum = SumRecords(inRecords, False)

    diff = outSum - inSum

    kindText = ShiftKindFromOutRecords(outRecords)

    score = ScoreCandidate(outRecords, inRecords, diff)

    stateKey = BuildAnalysisStateKey(patternText, outIds, inIds)

    If score < mMinScore Then

        If mManualDecisionOverrides Is Nothing Then Exit Sub

        If Not mManualDecisionOverrides.Exists(stateKey) Then Exit Sub

    End If

    voucher = VoucherFlagForCandidate(kindText, Application.Max(outSum, inSum))

    decisionText = DECISION_USE

    operationMemoText = "C/D列はダブルクリックで切替。M列は自由メモ。"

    If Not mManualVoucherOverrides Is Nothing Then

        If mManualVoucherOverrides.Exists(stateKey) Then voucher = CStr(mManualVoucherOverrides(stateKey))

        If mManualDecisionOverrides.Exists(stateKey) Then decisionText = CStr(mManualDecisionOverrides(stateKey))

        If mManualMemoOverrides.Exists(stateKey) Then operationMemoText = CStr(mManualMemoOverrides(stateKey))

    End If

    decisionText = NormalizeDecisionText(decisionText)

    If IsExcludeDecision(decisionText) Then voucher = VOUCHER_NO

    outPerson = PersonList(outRecords)

    inPerson = PersonList(inRecords)

    nameRel = NameRelation(outRecords, inRecords)

    inhTiming = InheritanceTiming(outRecords)

    cohab = CohabitationText(outRecords, inRecords)

    cohab = JoinNonBlank(cohab, RiskSignalText(outRecords, inRecords), " / ")

    DateMinMax outRecords, outDateMin, outDateMax

    DateMinMax inRecords, inDateMin, inDateMax

    shops = ShopList(outRecords, inRecords)

    summaryText = SummaryList(outRecords, inRecords)

    summaryText = JoinNonBlank(SummaryKeywordFlowHint(outRecords, inRecords), summaryText, " / ")

    temporalHint = TemporalFlowHintText(outRecords, inRecords)

    If Len(temporalHint) > 0 Then summaryText = JoinNonBlank(temporalHint, summaryText, " / ")

    ageHint = AgeHintForRecords(outRecords, inRecords)

    addressHint = AddressHintForRecords(outRecords, inRecords)

    memo = CandidateReasonText(outRecords, inRecords, diff, score, temporalHint)



    WriteResultRow analysisId, kindText, patternText, score, voucher, RecordsDateTimeRangeText(outRecords), RecordsDateTimeRangeText(inRecords), outSum, inSum, diff, outPerson, inPerson, nameRel, inhTiming, cohab, outIds, inIds, shops, summaryText, memo, decisionText, operationMemoText, ageHint, addressHint

    If Not IsExcludeDecision(decisionText) Then

        WriteDetailRows analysisId, kindText, voucher, "出金", outRecords, True

        WriteDetailRows analysisId, kindText, voucher, "入金", inRecords, False

        MarkMatched outRecords, analysisId

        MarkMatched inRecords, analysisId

    End If

End Sub



Private Sub AddUnknownCandidate(ByVal kindText As String, ByVal rec As Object)

    If ResultLimitReached() Then Exit Sub

    Dim analysisId As String, voucher As String, amountValue As Double, idsOut As String, idsIn As String

    Dim outSum As Double, inSum As Double, outDateText As String, inDateText As String

    Dim stateKey As String, decisionText As String, operationMemoText As String

    Dim ageHint As String, addressHint As String, riskHint As String

    analysisId = NextId("分析候補")

    If kindText = KIND_UNKNOWN_OUT Then

        amountValue = CDbl(rec("Out"))

        outSum = amountValue

        idsOut = CStr(rec("TxId"))

        outDateText = RecordDateTimeText(rec)

    Else

        amountValue = CDbl(rec("In"))

        inSum = amountValue

        idsIn = CStr(rec("TxId"))

        inDateText = RecordDateTimeText(rec)

    End If

    voucher = VoucherFlagForUnknown(amountValue)

    decisionText = DECISION_USE

    operationMemoText = "C/D列はダブルクリックで切替。M列は自由メモ。"

    stateKey = BuildAnalysisStateKey("単独", idsOut, idsIn)

    If Not mManualVoucherOverrides Is Nothing Then

        If mManualVoucherOverrides.Exists(stateKey) Then voucher = CStr(mManualVoucherOverrides(stateKey))

        If mManualDecisionOverrides.Exists(stateKey) Then decisionText = CStr(mManualDecisionOverrides(stateKey))

        If mManualMemoOverrides.Exists(stateKey) Then operationMemoText = CStr(mManualMemoOverrides(stateKey))

    End If

    decisionText = NormalizeDecisionText(decisionText)

    If IsExcludeDecision(decisionText) Then voucher = VOUCHER_NO

    ageHint = AgeHintForRecord(rec)

    addressHint = AddressHintForRecord(rec)

    riskHint = RiskSignalForSingle(rec)

    WriteResultRow analysisId, kindText, "単独", 40, voucher, outDateText, inDateText, outSum, inSum, outSum - inSum, _
                   IIf(kindText = KIND_UNKNOWN_OUT, CStr(rec("Name")), ""), _
                   IIf(kindText = KIND_UNKNOWN_IN, CStr(rec("Name")), ""), _
                   "", IIf(IsAfterInheritanceRecord(rec), "相続開始後", "相続開始前/不明"), riskHint, _
                   idsOut, idsIn, CStr(rec("Bank")) & " " & CStr(rec("Shop")), CStr(rec("Summary")), "対応取引なし", decisionText, operationMemoText, ageHint, addressHint

    If Not IsExcludeDecision(decisionText) Then

        If kindText = KIND_UNKNOWN_OUT Then

            WriteDetailRows analysisId, kindText, voucher, "出金", CollectionFromOne(rec), True

        Else

            WriteDetailRows analysisId, kindText, voucher, "入金", CollectionFromOne(rec), False

        End If

    End If

End Sub



Private Sub WriteResultRow(ByVal analysisId As String, ByVal kindText As String, ByVal patternText As String, ByVal score As Long, ByVal voucher As String, _
                           ByVal outDateText As String, ByVal inDateText As String, ByVal outSum As Double, ByVal inSum As Double, ByVal diff As Double, _
                           ByVal outPerson As String, ByVal inPerson As String, ByVal nameRel As String, ByVal inhTiming As String, ByVal cohab As String, _
                           ByVal outIds As String, ByVal inIds As String, ByVal shops As String, ByVal summaryText As String, ByVal memo As String, _
                           Optional ByVal decisionText As String = "", Optional ByVal operationMemoText As String = "", _
                           Optional ByVal ageHint As String = "", Optional ByVal addressHint As String = "")

    Dim ws As Worksheet, r As Long

    Set ws = GetSheet(SH_WORK_RESULT)

    If Len(decisionText) = 0 Then decisionText = DECISION_USE

    If Len(operationMemoText) = 0 Then operationMemoText = "C/D列はダブルクリックで切替。M列は自由メモ。"

    If mNextResultRow < 2 Then mNextResultRow = LastRow(ws, 1) + 1

    r = mNextResultRow

    mNextResultRow = mNextResultRow + 1

    ws.Cells(r, RES_COL_ID).Value = analysisId

    ws.Cells(r, RES_COL_KIND).Value = kindText

    ws.Cells(r, RES_COL_PATTERN).Value = patternText

    ws.Cells(r, RES_COL_SCORE).Value = score

    ws.Cells(r, RES_COL_VOUCHER).Value = voucher

    ws.Cells(r, RES_COL_OUT_DATE).Value = outDateText

    ws.Cells(r, RES_COL_IN_DATE).Value = inDateText

    ws.Cells(r, RES_COL_OUT_AMOUNT).Value = outSum

    ws.Cells(r, RES_COL_IN_AMOUNT).Value = inSum

    ws.Cells(r, RES_COL_DIFF).Value = diff

    ws.Cells(r, RES_COL_OUT_PERSON).Value = outPerson

    ws.Cells(r, RES_COL_IN_PERSON).Value = inPerson

    ws.Cells(r, RES_COL_NAME_REL).Value = nameRel

    ws.Cells(r, RES_COL_INH_TIMING).Value = inhTiming

    ws.Cells(r, RES_COL_COHAB).Value = cohab

    ws.Cells(r, RES_COL_OUT_IDS).Value = outIds

    ws.Cells(r, RES_COL_IN_IDS).Value = inIds

    ws.Cells(r, RES_COL_SHOPS).Value = shops

    ws.Cells(r, RES_COL_SUMMARY).Value = summaryText

    ws.Cells(r, RES_COL_MEMO).Value = memo

    ws.Cells(r, RES_COL_SHIFT_DECISION).Value = decisionText

    ws.Cells(r, RES_COL_OPERATION_MEMO).Value = operationMemoText

    ws.Cells(r, RES_COL_AGE_HINT).Value = ageHint

    ws.Cells(r, RES_COL_ADDRESS_HINT).Value = addressHint

    mResultCount = mResultCount + 1

End Sub



Private Sub WriteDetailRows(ByVal analysisId As String, ByVal kindText As String, ByVal voucher As String, ByVal sideText As String, ByVal recs As Collection, ByVal useOut As Boolean)

    Dim ws As Worksheet, outR As Long, rec As Object

    Set ws = GetSheet(SH_WORK_DETAIL)

    For Each rec In recs

        If mNextDetailRow < 2 Then mNextDetailRow = LastRow(ws, 1) + 1

        outR = mNextDetailRow

        mNextDetailRow = mNextDetailRow + 1

        ws.Cells(outR, DET_COL_ID).Value = NextId("分析明細")

        ws.Cells(outR, DET_COL_ANALYSIS_ID).Value = analysisId

        ws.Cells(outR, DET_COL_SIDE).Value = sideText

        ws.Cells(outR, DET_COL_TX_ID).Value = rec("TxId")

        ws.Cells(outR, DET_COL_DATE).Value = rec("Date")

        ws.Cells(outR, DET_COL_AMOUNT).Value = IIf(useOut, rec("Out"), rec("In"))

        ws.Cells(outR, DET_COL_PERSON_ID).Value = rec("PersonId")

        ws.Cells(outR, DET_COL_PERSON_NAME).Value = rec("Name")

        ws.Cells(outR, DET_COL_ACCOUNT_ID).Value = rec("AccountId")

        ws.Cells(outR, DET_COL_BANK).Value = rec("Bank")

        ws.Cells(outR, DET_COL_BRANCH).Value = rec("Branch")

        ws.Cells(outR, DET_COL_ACCOUNT_TYPE).Value = rec("AccountType")

        ws.Cells(outR, DET_COL_ACCOUNT_NO).Value = rec("AccountNo")

        ws.Cells(outR, DET_COL_SHOP).Value = rec("Shop")

        ws.Cells(outR, DET_COL_SUMMARY).Value = rec("Summary")

        ws.Cells(outR, DET_COL_KIND).Value = kindText

        ws.Cells(outR, DET_COL_VOUCHER).Value = voucher

    Next rec

End Sub



Private Function SortedIds(ByVal recs As Collection) As String

    Dim arr() As String, i As Long, j As Long, tmp As String, rec As Object

    If recs.Count = 0 Then Exit Function

    ReDim arr(1 To recs.Count)

    i = 1

    For Each rec In recs

        arr(i) = CStr(rec("TxId"))

        i = i + 1

    Next rec

    For i = LBound(arr) To UBound(arr) - 1

        For j = i + 1 To UBound(arr)

            If arr(j) < arr(i) Then tmp = arr(i): arr(i) = arr(j): arr(j) = tmp

        Next j

    Next i

    For i = LBound(arr) To UBound(arr)

        If Len(SortedIds) > 0 Then SortedIds = SortedIds & ","

        SortedIds = SortedIds & arr(i)

    Next i

End Function



Private Function SumRecords(ByVal recs As Collection, ByVal useOut As Boolean) As Double

    Dim rec As Object

    For Each rec In recs

        If useOut Then

            SumRecords = SumRecords + CDbl(rec("Out"))

        Else

            SumRecords = SumRecords + CDbl(rec("In"))

        End If

    Next rec

End Function



Private Function IsTemporalFlowValid(ByVal outRecords As Collection, ByVal inRecords As Collection) As Boolean

    Dim outLatestDay As Long, inEarliestDay As Long

    Dim outLatestKnown As Double, inEarliestKnown As Double

    Dim hasOutKnown As Boolean, hasInKnown As Boolean

    IsTemporalFlowValid = True

    If outRecords Is Nothing Or inRecords Is Nothing Then Exit Function

    If outRecords.Count = 0 Or inRecords.Count = 0 Then Exit Function



    outLatestDay = LatestDateSerialInRecords(outRecords)

    inEarliestDay = EarliestDateSerialInRecords(inRecords)

    If outLatestDay = 0 Or inEarliestDay = 0 Then Exit Function



    ' 「出金→入金」を守る。入金日が出金日より前の候補は作らない。

    If outLatestDay > inEarliestDay Then

        IsTemporalFlowValid = False

        Exit Function

    End If



    ' 同日で双方に時刻がある場合は、最新出金時刻 <= 最早入金時刻 を必須にする。

    If outLatestDay = inEarliestDay Then

        hasOutKnown = LatestKnownDateTimeOnDay(outRecords, outLatestDay, outLatestKnown)

        hasInKnown = EarliestKnownDateTimeOnDay(inRecords, inEarliestDay, inEarliestKnown)

        If hasOutKnown And hasInKnown Then

            If outLatestKnown > inEarliestKnown + 0.00000001 Then IsTemporalFlowValid = False

        End If

    End If

End Function



Private Function EarliestDateSerialInRecords(ByVal recs As Collection) As Long

    Dim rec As Object, d As Long

    For Each rec In recs

        d = DateOnlySerial(rec("Date"))

        If d > 0 Then

            If EarliestDateSerialInRecords = 0 Or d < EarliestDateSerialInRecords Then EarliestDateSerialInRecords = d

        End If

    Next rec

End Function



Private Function LatestDateSerialInRecords(ByVal recs As Collection) As Long

    Dim rec As Object, d As Long

    For Each rec In recs

        d = DateOnlySerial(rec("Date"))

        If d > 0 Then

            If LatestDateSerialInRecords = 0 Or d > LatestDateSerialInRecords Then LatestDateSerialInRecords = d

        End If

    Next rec

End Function



Private Function EarliestKnownDateTimeOnDay(ByVal recs As Collection, ByVal daySerial As Long, ByRef outValue As Double) As Boolean

    Dim rec As Object, v As Double

    For Each rec In recs

        If DateOnlySerial(rec("Date")) = daySerial And CBool(rec("HasTime")) Then

            v = CDbl(daySerial) + CDbl(rec("TimeFraction"))

            If Not EarliestKnownDateTimeOnDay Or v < outValue Then outValue = v

            EarliestKnownDateTimeOnDay = True

        End If

    Next rec

End Function



Private Function LatestKnownDateTimeOnDay(ByVal recs As Collection, ByVal daySerial As Long, ByRef outValue As Double) As Boolean

    Dim rec As Object, v As Double

    For Each rec In recs

        If DateOnlySerial(rec("Date")) = daySerial And CBool(rec("HasTime")) Then

            v = CDbl(daySerial) + CDbl(rec("TimeFraction"))

            If Not LatestKnownDateTimeOnDay Or v > outValue Then outValue = v

            LatestKnownDateTimeOnDay = True

        End If

    Next rec

End Function



Private Function TemporalFlowHintText(ByVal outRecords As Collection, ByVal inRecords As Collection) As String

    Dim outLatestDay As Long, inEarliestDay As Long

    Dim outKnown As Double, inKnown As Double, gapMinutes As Long

    If outRecords Is Nothing Or inRecords Is Nothing Then Exit Function

    If outRecords.Count = 0 Or inRecords.Count = 0 Then Exit Function

    outLatestDay = LatestDateSerialInRecords(outRecords)

    inEarliestDay = EarliestDateSerialInRecords(inRecords)

    If outLatestDay = 0 Or inEarliestDay = 0 Then Exit Function

    If outLatestDay < inEarliestDay Then

        TemporalFlowHintText = "日付順OK"

    ElseIf outLatestDay = inEarliestDay Then

        If LatestKnownDateTimeOnDay(outRecords, outLatestDay, outKnown) And EarliestKnownDateTimeOnDay(inRecords, inEarliestDay, inKnown) Then

            gapMinutes = CLng(Application.Max(0, Round((inKnown - outKnown) * 1440#, 0)))

            TemporalFlowHintText = "同日時刻順OK（" & CStr(gapMinutes) & "分後）"

        ElseIf HasAnyTime(outRecords) Or HasAnyTime(inRecords) Then

            TemporalFlowHintText = "同日・時刻一部不明"

        Else

            TemporalFlowHintText = "同日・時刻不明"

        End If

    End If

End Function



Private Function SameDayKnownTimeGapMinutes(ByVal outRecords As Collection, ByVal inRecords As Collection) As Long

    Dim outLatestDay As Long, inEarliestDay As Long

    Dim outKnown As Double, inKnown As Double

    SameDayKnownTimeGapMinutes = -1

    If outRecords Is Nothing Or inRecords Is Nothing Then Exit Function

    If outRecords.Count = 0 Or inRecords.Count = 0 Then Exit Function

    outLatestDay = LatestDateSerialInRecords(outRecords)

    inEarliestDay = EarliestDateSerialInRecords(inRecords)

    If outLatestDay = 0 Or outLatestDay <> inEarliestDay Then Exit Function

    If LatestKnownDateTimeOnDay(outRecords, outLatestDay, outKnown) And EarliestKnownDateTimeOnDay(inRecords, inEarliestDay, inKnown) Then

        If inKnown >= outKnown Then SameDayKnownTimeGapMinutes = CLng(Application.Max(0, Round((inKnown - outKnown) * 1440#, 0)))

    End If

End Function



Private Function HasAnyTime(ByVal recs As Collection) As Boolean

    Dim rec As Object

    For Each rec In recs

        If CBool(rec("HasTime")) Then HasAnyTime = True: Exit Function

    Next rec

End Function



Private Function RecordsDateTimeRangeText(ByVal recs As Collection) As String

    Dim rec As Object, minKey As Double, maxKey As Double, minText As String, maxText As String, k As Double

    If recs Is Nothing Then Exit Function

    If recs.Count = 0 Then Exit Function

    For Each rec In recs

        k = RecordDateTimeSortValue(rec)

        If minKey = 0 Or k < minKey Then

            minKey = k

            minText = RecordDateTimeText(rec)

        End If

        If maxKey = 0 Or k > maxKey Then

            maxKey = k

            maxText = RecordDateTimeText(rec)

        End If

    Next rec

    If minText = maxText Then

        RecordsDateTimeRangeText = minText

    Else

        RecordsDateTimeRangeText = minText & "～" & maxText

    End If

End Function



Private Function RecordDateTimeSortValue(ByVal rec As Object) As Double

    If rec Is Nothing Then Exit Function

    If KeyExists(rec, "DateTimeSort") Then

        RecordDateTimeSortValue = CDbl(rec("DateTimeSort"))

    ElseIf IsDate(rec("Date")) Then

        RecordDateTimeSortValue = CDbl(DateOnlySerial(rec("Date")))

    End If

End Function



Private Function RecordDateTimeText(ByVal rec As Object) As String

    If rec Is Nothing Then Exit Function

    If IsDate(rec("Date")) Then

        If KeyExists(rec, "HasTime") And CBool(rec("HasTime")) Then

            RecordDateTimeText = Format$(CDate(rec("Date")) + CDbl(rec("TimeFraction")), "yyyy/m/d h:mm")

        Else

            RecordDateTimeText = Format$(CDate(rec("Date")), "yyyy/m/d")

        End If

    End If

End Function



Private Function KeyExists(ByVal dict As Object, ByVal keyText As String) As Boolean

    On Error GoTo EH

    If dict Is Nothing Then Exit Function

    KeyExists = dict.Exists(keyText)

    Exit Function

EH:

    KeyExists = False

End Function



Private Sub MarkMatched(ByVal recs As Collection, ByVal analysisId As String)

    Dim rec As Object, txId As String

    For Each rec In recs

        txId = CStr(rec("TxId"))

        If mMatched.Exists(txId) Then

            mMatched(txId) = mMatched(txId) & "," & analysisId

        Else

            mMatched.Add txId, analysisId

        End If

    Next rec

End Sub



Private Function ShiftKindFromOutRecords(ByVal outRecords As Collection) As String

    Dim rec As Object

    ShiftKindFromOutRecords = KIND_SHIFT

    For Each rec In outRecords

        If CStr(rec("PersonId")) = mDecedentId And IsDate(mInheritanceDate) And CDate(rec("Date")) >= CDate(mInheritanceDate) Then

            ShiftKindFromOutRecords = KIND_INHERITANCE_SHIFT

            Exit Function

        End If

    Next rec

End Function



Private Function CandidateReasonText(ByVal outRecords As Collection, ByVal inRecords As Collection, ByVal diff As Double, ByVal score As Long, ByVal temporalHint As String) As String

    Dim s As String, amountHint As String, rel As String, comboText As String

    If diff = 0 Then
        amountHint = "金額一致"
    ElseIf Abs(diff) <= mAmountTol Then
        amountHint = "許容差内"
    Else
        amountHint = "差額 " & Format$(diff, "#,##0")
    End If

    comboText = CStr(outRecords.Count) & "出金×" & CStr(inRecords.Count) & "入金"
    s = "信頼度" & CStr(score) & " / " & amountHint & " / " & comboText
    s = JoinNonBlank(s, temporalHint, " / ")

    rel = NameRelation(outRecords, inRecords)
    If Len(rel) > 0 Then s = JoinNonBlank(s, rel, " / ")
    If CollectionsShareValue(outRecords, inRecords, "AccountId") Then s = JoinNonBlank(s, "同一口座含む", " / ")
    If InStr(temporalHint, "時刻不明") > 0 Or InStr(temporalHint, "時刻一部不明") > 0 Then s = JoinNonBlank(s, "順序は日付ベース", " / ")

    CandidateReasonText = ClipText(s, 240)

End Function

Private Function ScoreCandidate(ByVal outRecords As Collection, ByVal inRecords As Collection, ByVal diff As Double) As Long

    Dim outDateMin As Variant, outDateMax As Variant, inDateMin As Variant, inDateMax As Variant

    Dim daysDiff As Long, score As Long, comboCount As Long, flowHint As String, gapMinutes As Long

    score = 55

    If diff = 0 Then

        score = score + 22

    ElseIf Abs(diff) <= mAmountTol Then

        score = score + 14

    ElseIf EffectiveTolerance(SumRecords(outRecords, True), SumRecords(inRecords, False)) > 0 And Abs(diff) <= EffectiveTolerance(SumRecords(outRecords, True), SumRecords(inRecords, False)) Then

        score = score + 10

    End If

    DateMinMax outRecords, outDateMin, outDateMax

    DateMinMax inRecords, inDateMin, inDateMax

    If IsDate(outDateMin) And IsDate(inDateMin) Then

        daysDiff = DateOnlySerial(inDateMin) - DateOnlySerial(outDateMin)

        If daysDiff = 0 Then

            score = score + 16

            flowHint = TemporalFlowHintText(outRecords, inRecords)

            gapMinutes = SameDayKnownTimeGapMinutes(outRecords, inRecords)

            If gapMinutes >= 0 Then

                If gapMinutes <= 30 Then

                    score = score + 8

                ElseIf gapMinutes <= 120 Then

                    score = score + 6

                Else

                    score = score + 4

                End If

            ElseIf InStr(flowHint, "同日時刻順OK") > 0 Then

                score = score + 4

            ElseIf InStr(flowHint, "時刻一部不明") > 0 Then

                score = score - 3

            End If

        ElseIf daysDiff = 1 Then

            score = score + 12

        ElseIf daysDiff > 1 And daysDiff <= mDateWindow Then

            score = score + 6

        End If

    End If

    comboCount = outRecords.Count + inRecords.Count

    If comboCount > 2 Then score = score - Application.Min(12, (comboCount - 2) * 2)

    If CollectionsShareValue(outRecords, inRecords, "AccountId") Then score = score - 10

    If mContextScore Then

        If NameRelation(outRecords, inRecords) = "同一名義" Then score = score + 4

        If Len(CohabitationText(outRecords, inRecords)) > 0 Then score = score + 4

        If HasSameAddressAtTransaction(outRecords, inRecords) Then score = score + 4

        If ShiftKindFromOutRecords(outRecords) = KIND_INHERITANCE_SHIFT Then score = score + 6

        If SameShopOrBankHint(outRecords, inRecords) Then score = score + 3

        If Len(SummaryKeywordFlowHint(outRecords, inRecords)) > 0 Then score = score + 2

        If Len(TimeClusterSignal(outRecords, inRecords)) > 0 Then score = score + 4

        If Len(YoungHighAmountSignal(outRecords, inRecords)) > 0 Then score = score + 3

        If Len(MoveAroundHighAmountSignal(outRecords, inRecords)) > 0 Then score = score + 4

        If Len(LifeEventAroundHighAmountSignal(outRecords, inRecords)) > 0 Then score = score + 3

        If Len(AccountOperationPatternSignal(outRecords, inRecords)) > 0 Then score = score + 3

        If Len(CentralizedManagementSignal(outRecords, inRecords)) > 0 Then score = score + 4

        If Len(GiftAddBackSignal(outRecords, inRecords)) > 0 Then score = score + 5

        If Len(PreInheritanceWithdrawalSignal(outRecords)) > 0 Then score = score + 4

        If Len(TransactionAfterBalanceSignal(outRecords, inRecords)) > 0 Then score = score + 3

    End If

    If score > 100 Then score = 100

    If score < 0 Then score = 0

    ScoreCandidate = score

End Function



Private Function HasSameAddressAtTransaction(ByVal outs As Collection, ByVal ins As Collection) As Boolean

    Dim outAddr As Object, inAddr As Object, k As Variant

    Set outAddr = AddressDictForSide(outs)

    Set inAddr = AddressDictForSide(ins)

    For Each k In outAddr.Keys

        If Len(CStr(k)) > 0 And inAddr.Exists(k) Then

            HasSameAddressAtTransaction = True

            Exit Function

        End If

    Next k

End Function



Private Function CollectionsShareValue(ByVal leftRecords As Collection, ByVal rightRecords As Collection, ByVal fieldName As String) As Boolean

    Dim seen As Object, rec As Object, keyText As String

    Set seen = CreateObject("Scripting.Dictionary")

    If leftRecords Is Nothing Or rightRecords Is Nothing Then Exit Function

    For Each rec In leftRecords

        If KeyExists(rec, fieldName) Then

            keyText = CStr(rec(fieldName))

            If Len(keyText) > 0 Then seen(keyText) = True

        End If

    Next rec

    For Each rec In rightRecords

        If KeyExists(rec, fieldName) Then

            keyText = CStr(rec(fieldName))

            If Len(keyText) > 0 And seen.Exists(keyText) Then

                CollectionsShareValue = True

                Exit Function

            End If

        End If

    Next rec

End Function



Private Function SameShopOrBankHint(ByVal outs As Collection, ByVal ins As Collection) As Boolean

    Dim d As Object, rec As Object, keyText As String

    Set d = CreateObject("Scripting.Dictionary")

    For Each rec In outs

        keyText = CStr(rec("Bank")) & "|" & CStr(rec("Shop"))

        If Len(Replace$(keyText, "|", "")) > 0 Then d(keyText) = True

    Next rec

    For Each rec In ins

        keyText = CStr(rec("Bank")) & "|" & CStr(rec("Shop"))

        If d.Exists(keyText) Then

            SameShopOrBankHint = True

            Exit Function

        End If

    Next rec

End Function



Private Sub DateMinMax(ByVal recs As Collection, ByRef dMin As Variant, ByRef dMax As Variant)

    Dim rec As Object, d As Date

    dMin = Empty: dMax = Empty

    For Each rec In recs

        If IsDate(rec("Date")) Then

            d = DateValue(CDate(rec("Date")))

            If Not IsDate(dMin) Or d < CDate(dMin) Then dMin = d

            If Not IsDate(dMax) Or d > CDate(dMax) Then dMax = d

        End If

    Next rec

End Sub



Private Function PersonList(ByVal recs As Collection) As String

    Dim d As Object, rec As Object, key As String

    Set d = CreateObject("Scripting.Dictionary")

    For Each rec In recs

        key = CStr(rec("Name"))

        If Len(key) = 0 Then key = CStr(rec("PersonId"))

        If Len(key) > 0 Then d(key) = True

    Next rec

    PersonList = JoinDictionaryKeys(d, " / ")

End Function



Private Function JoinDictionaryKeys(ByVal d As Object, ByVal sep As String) As String

    Dim k As Variant

    For Each k In d.Keys

        If Len(JoinDictionaryKeys) > 0 Then JoinDictionaryKeys = JoinDictionaryKeys & sep

        JoinDictionaryKeys = JoinDictionaryKeys & CStr(k)

    Next k

End Function



Private Function NameRelation(ByVal outs As Collection, ByVal ins As Collection) As String

    Dim dOut As Object, dIn As Object, rec As Object, k As Variant

    Set dOut = CreateObject("Scripting.Dictionary")

    Set dIn = CreateObject("Scripting.Dictionary")

    For Each rec In outs

        If Len(CStr(rec("PersonId"))) > 0 Then dOut(CStr(rec("PersonId"))) = True

    Next rec

    For Each rec In ins

        If Len(CStr(rec("PersonId"))) > 0 Then dIn(CStr(rec("PersonId"))) = True

    Next rec

    If dOut.Count = 1 And dIn.Count = 1 Then

        For Each k In dOut.Keys

            If dIn.Exists(k) Then NameRelation = "同一名義" Else NameRelation = "別名義"

            Exit Function

        Next k

    End If

    If dOut.Count = 0 Or dIn.Count = 0 Then

        NameRelation = ""

    Else

        NameRelation = "複数名義"

    End If

End Function



Private Function InheritanceTiming(ByVal outs As Collection) As String

    Dim rec As Object, hasAfter As Boolean, hasBefore As Boolean

    If Not IsDate(mInheritanceDate) Then

        InheritanceTiming = "不明"

        Exit Function

    End If

    For Each rec In outs

        If IsDate(rec("Date")) Then

            If CDate(rec("Date")) >= CDate(mInheritanceDate) Then hasAfter = True Else hasBefore = True

        End If

    Next rec

    If hasAfter And hasBefore Then

        InheritanceTiming = "前後混在"

    ElseIf hasAfter Then

        InheritanceTiming = "相続開始後"

    Else

        InheritanceTiming = "相続開始前"

    End If

End Function



Private Function IsAfterInheritanceRecord(ByVal rec As Object) As Boolean

    IsAfterInheritanceRecord = False

    If IsDate(mInheritanceDate) And IsDate(rec("Date")) Then

        IsAfterInheritanceRecord = (CDate(rec("Date")) >= CDate(mInheritanceDate))

    End If

End Function



Private Function CohabitationText(ByVal outs As Collection, ByVal ins As Collection) As String

    Dim recO As Object, recI As Object

    For Each recO In outs

        For Each recI In ins

            If AreCohabited(CStr(recO("PersonId")), CStr(recI("PersonId"))) Then

                CohabitationText = "あり"

                Exit Function

            End If

        Next recI

    Next recO

    CohabitationText = ""

End Function



Private Function BuildCohabPairIndex() As Object

    Dim dict As Object, ws As Worksheet, lastR As Long, r As Long, headerRow As Long

    Dim c1 As Long, c2 As Long, p1 As String, p2 As String

    Set dict = CreateObject("Scripting.Dictionary")

    If Not SheetExists(SH_WORK_COHAB) Then

        Set BuildCohabPairIndex = dict

        Exit Function

    End If

    Set ws = GetSheet(SH_WORK_COHAB)

    headerRow = DetectCohabHeaderRow(ws)

    If headerRow = 0 Then

        Set BuildCohabPairIndex = dict

        Exit Function

    End If

    c1 = FirstHeaderColumn(ws, Array("人物ID_A", "人物AID", "人物A人物ID", "人物A"), headerRow)

    c2 = FirstHeaderColumn(ws, Array("人物ID_B", "人物BID", "人物B人物ID", "人物B"), headerRow)

    If c1 = 0 Or c2 = 0 Then

        Set BuildCohabPairIndex = dict

        Exit Function

    End If

    lastR = LastRow(ws, 1)

    For r = headerRow + 1 To lastR

        p1 = CoercePersonId(CellText(ws.Cells(r, c1).Value))

        p2 = CoercePersonId(CellText(ws.Cells(r, c2).Value))

        If Len(p1) > 0 And Len(p2) > 0 And p1 <> p2 Then dict(BuildPairKey(p1, p2)) = True

    Next r

    Set BuildCohabPairIndex = dict

End Function



Private Function DetectCohabHeaderRow(ByVal ws As Worksheet) As Long

    Dim rr As Long

    For rr = 1 To Application.Min(5, LastUsedRowInSheet(ws))

        If FirstHeaderColumn(ws, Array("人物ID_A", "人物AID", "人物A人物ID", "人物A"), rr) > 0 And _
           FirstHeaderColumn(ws, Array("人物ID_B", "人物BID", "人物B人物ID", "人物B"), rr) > 0 Then

            DetectCohabHeaderRow = rr

            Exit Function

        End If

    Next rr

End Function



Private Function CoercePersonId(ByVal valueText As String) As String

    Dim k As Variant, info As Object, cleanValue As String, cleanName As String

    cleanValue = CellText(valueText)

    If Len(cleanValue) = 0 Then Exit Function

    If Not mPersonInfo Is Nothing Then

        If mPersonInfo.Exists(cleanValue) Then

            CoercePersonId = cleanValue

            Exit Function

        End If

        For Each k In mPersonInfo.Keys

            Set info = mPersonInfo(k)

            cleanName = CellText(info("Name"))

            If cleanName = cleanValue Then

                CoercePersonId = CStr(k)

                Exit Function

            End If

        Next k

    End If

    CoercePersonId = cleanValue

End Function



Private Function AreCohabited(ByVal p1 As String, ByVal p2 As String) As Boolean

    If Len(p1) = 0 Or Len(p2) = 0 Or p1 = p2 Then Exit Function

    If mCohabPairs Is Nothing Then Set mCohabPairs = BuildCohabPairIndex()

    AreCohabited = mCohabPairs.Exists(BuildPairKey(p1, p2))

End Function



Private Function ShopList(ByVal outs As Collection, ByVal ins As Collection) As String

    Dim d As Object, rec As Object

    Set d = CreateObject("Scripting.Dictionary")

    For Each rec In outs

        If Len(CStr(rec("Bank")) & CStr(rec("Shop"))) > 0 Then d(CStr(rec("Bank")) & " " & CStr(rec("Shop"))) = True

    Next rec

    For Each rec In ins

        If Len(CStr(rec("Bank")) & CStr(rec("Shop"))) > 0 Then d(CStr(rec("Bank")) & " " & CStr(rec("Shop"))) = True

    Next rec

    ShopList = JoinDictionaryKeys(d, " / ")

End Function



Private Function SummaryList(ByVal outs As Collection, ByVal ins As Collection) As String

    Dim d As Object, rec As Object, s As String

    Set d = CreateObject("Scripting.Dictionary")

    For Each rec In outs

        s = CStr(rec("Summary"))

        If Len(s) > 0 Then d("出:" & s) = True

    Next rec

    For Each rec In ins

        s = CStr(rec("Summary"))

        If Len(s) > 0 Then d("入:" & s) = True

    Next rec

    SummaryList = JoinDictionaryKeys(d, " / ")

End Function



Private Function SummaryKeywordFlowHint(ByVal outs As Collection, ByVal ins As Collection) As String

    ' 摘要の文字は金融機関ごとに揺れるため、分類名には使わず、補助ヒントとして軽く扱う。

    Dim outText As String, inText As String

    outText = CombinedSummaryText(outs)

    inText = CombinedSummaryText(ins)

    If HasAnyKeyword(outText, Array("振込", "振替", "送金", "資金移動")) And HasAnyKeyword(inText, Array("振込", "振替", "入金", "受入", "資金移動")) Then

        SummaryKeywordFlowHint = "摘要: 振込・振替系"

    ElseIf HasAnyKeyword(outText, Array("ATM", "ＡＴＭ", "現金", "窓口", "払戻")) And HasAnyKeyword(inText, Array("ATM", "ＡＴＭ", "現金", "窓口", "預入")) Then

        SummaryKeywordFlowHint = "摘要: 現金・ATM系"

    End If

End Function



Private Function CombinedSummaryText(ByVal recs As Collection) As String

    Dim rec As Object

    If recs Is Nothing Then Exit Function

    For Each rec In recs

        CombinedSummaryText = CombinedSummaryText & " " & CStr(rec("Summary")) & " " & CStr(rec("Other"))

    Next rec

End Function



Private Function HasAnyKeyword(ByVal textValue As String, ByVal keywords As Variant) As Boolean

    Dim i As Long

    For i = LBound(keywords) To UBound(keywords)

        If InStr(1, textValue, CStr(keywords(i)), vbTextCompare) > 0 Then

            HasAnyKeyword = True

            Exit Function

        End If

    Next i

End Function





Private Function BuildPersonInfoIndex() As Object

    Dim dict As Object, ws As Worksheet, lastR As Long, r As Long

    Dim colId As Long, colName As Long, colRel As Long, colBirth As Long, colDeath As Long

    Dim pid As String, info As Object

    Set dict = CreateObject("Scripting.Dictionary")

    If Not SheetExists(SH_WORK_PERSON) Then Set BuildPersonInfoIndex = dict: Exit Function

    Set ws = GetSheet(SH_WORK_PERSON)

    colId = FirstHeaderColumn(ws, Array("人物ID"), 1)

    colName = FirstHeaderColumn(ws, Array("氏名表示", "氏名"), 1)

    colRel = FirstHeaderColumn(ws, Array("被相続人から見た続柄", "続柄", "表示用続柄"), 1)

    colBirth = FirstHeaderColumn(ws, Array("生年月日"), 1)

    colDeath = FirstHeaderColumn(ws, Array("死亡日"), 1)

    If colId = 0 Then Set BuildPersonInfoIndex = dict: Exit Function

    lastR = LastRow(ws, colId)

    For r = 2 To lastR

        pid = CellText(ws.Cells(r, colId).Value)

        If Len(pid) > 0 Then

            Set info = CreateObject("Scripting.Dictionary")

            info("Name") = GetCellByCol(ws, r, colName)

            info("Relation") = GetCellByCol(ws, r, colRel)

            If colBirth > 0 Then info("Birth") = ToDateOrEmpty(ws.Cells(r, colBirth).Value) Else info("Birth") = Empty

            If colDeath > 0 Then info("Death") = ToDateOrEmpty(ws.Cells(r, colDeath).Value) Else info("Death") = Empty

            If dict.Exists(pid) Then dict.Remove pid

            dict.Add pid, info

        End If

    Next r

    Set BuildPersonInfoIndex = dict

End Function




Private Function BuildMarriageDateIndex() As Object

    Dim dict As Object, ws As Worksheet, lastR As Long, r As Long
    Dim colBase As Long, colOther As Long, colMarriage As Long, colStatus As Long
    Dim baseId As String, otherId As String, statusText As String, marriageDate As Variant

    Set dict = CreateObject("Scripting.Dictionary")
    If Not SheetExists(SH_WORK_REL) Then Set BuildMarriageDateIndex = dict: Exit Function

    Set ws = GetSheet(SH_WORK_REL)
    colBase = FirstHeaderColumn(ws, Array("基準人物ID", "人物ID_A", "人物A", "人物ID1"), 1)
    colOther = FirstHeaderColumn(ws, Array("相手人物ID", "人物ID_B", "人物B", "人物ID2"), 1)
    colMarriage = FirstHeaderColumn(ws, Array("婚姻日", "婚姻年月日"), 1)
    colStatus = FirstHeaderColumn(ws, Array("データ状態"), 1)
    If colBase = 0 Or colOther = 0 Or colMarriage = 0 Then Set BuildMarriageDateIndex = dict: Exit Function

    lastR = LastRow(ws, colBase)
    For r = 2 To lastR
        statusText = GetCellByCol(ws, r, colStatus)
        If statusText <> "取消" Then
            marriageDate = ToDateOrEmpty(ws.Cells(r, colMarriage).Value)
            If IsDate(marriageDate) Then
                baseId = GetCellByCol(ws, r, colBase)
                otherId = GetCellByCol(ws, r, colOther)
                If Len(baseId) > 0 Then AddLifeEventToIndex dict, baseId, CDate(marriageDate), "婚姻:" & PersonDisplayNameSafe(otherId)
                If Len(otherId) > 0 Then AddLifeEventToIndex dict, otherId, CDate(marriageDate), "婚姻:" & PersonDisplayNameSafe(baseId)
            End If
        End If
    Next r

    Set BuildMarriageDateIndex = dict

End Function

Private Sub AddLifeEventToIndex(ByVal dict As Object, ByVal personId As String, ByVal eventDate As Date, ByVal eventText As String)

    Dim col As Collection, item As Object
    If dict Is Nothing Or Len(personId) = 0 Then Exit Sub
    If dict.Exists(personId) Then
        Set col = dict(personId)
    Else
        Set col = New Collection
        dict.Add personId, col
    End If
    Set item = CreateObject("Scripting.Dictionary")
    item("Date") = DateValue(eventDate)
    item("Text") = eventText
    col.Add item

End Sub

Private Function BuildRelationPairIndex() As Object

    Dim dict As Object, ws As Worksheet, lastR As Long, r As Long
    Dim colBase As Long, colOther As Long, colStatus As Long
    Dim baseId As String, otherId As String, statusText As String

    Set dict = CreateObject("Scripting.Dictionary")
    If Not SheetExists(SH_WORK_REL) Then Set BuildRelationPairIndex = dict: Exit Function

    Set ws = GetSheet(SH_WORK_REL)
    colBase = FirstHeaderColumn(ws, Array("基準人物ID", "人物ID_A", "人物A", "人物ID1"), 1)
    colOther = FirstHeaderColumn(ws, Array("相手人物ID", "人物ID_B", "人物B", "人物ID2"), 1)
    colStatus = FirstHeaderColumn(ws, Array("データ状態"), 1)
    If colBase = 0 Or colOther = 0 Then Set BuildRelationPairIndex = dict: Exit Function

    lastR = LastRow(ws, colBase)
    For r = 2 To lastR
        statusText = GetCellByCol(ws, r, colStatus)
        If statusText <> "取消" Then
            baseId = GetCellByCol(ws, r, colBase)
            otherId = GetCellByCol(ws, r, colOther)
            If Len(baseId) > 0 And Len(otherId) > 0 Then
                dict(RelationPairKey(baseId, otherId)) = True
                dict(RelationPairKey(otherId, baseId)) = True
            End If
        End If
    Next r

    Set BuildRelationPairIndex = dict

End Function

Private Function RelationPairKey(ByVal personId1 As String, ByVal personId2 As String) As String
    RelationPairKey = personId1 & "|" & personId2
End Function

Private Function IsMovePaymentRelevantPerson(ByVal txPersonId As String, ByVal moverPersonId As String) As Boolean

    If Len(txPersonId) = 0 Or Len(moverPersonId) = 0 Then Exit Function
    If txPersonId = moverPersonId Then IsMovePaymentRelevantPerson = True: Exit Function
    If Len(mDecedentId) > 0 And txPersonId = mDecedentId Then IsMovePaymentRelevantPerson = True: Exit Function

    If Not mRelationPairs Is Nothing Then
        If mRelationPairs.Exists(RelationPairKey(txPersonId, moverPersonId)) Then
            IsMovePaymentRelevantPerson = True
            Exit Function
        End If
    End If

    If IsKinshipPerson(txPersonId) And IsKinshipPerson(moverPersonId) Then
        IsMovePaymentRelevantPerson = True
        Exit Function
    End If

End Function

Private Function IsKinshipPerson(ByVal personId As String) As Boolean

    Dim info As Object, relText As String

    If Len(personId) = 0 Then Exit Function
    If Len(mDecedentId) > 0 And personId = mDecedentId Then IsKinshipPerson = True: Exit Function
    If mPersonInfo Is Nothing Then Exit Function
    If Not mPersonInfo.Exists(personId) Then Exit Function

    Set info = mPersonInfo(personId)
    If info.Exists("Relation") Then relText = CStr(info("Relation"))
    IsKinshipPerson = RelationTextLooksKinship(relText)

End Function

Private Function RelationTextLooksKinship(ByVal relText As String) As Boolean

    relText = Trim$(relText)
    If Len(relText) = 0 Then Exit Function
    If InStr(1, relText, "関係者", vbTextCompare) > 0 Then Exit Function
    If InStr(1, relText, "その他", vbTextCompare) > 0 Then Exit Function
    If InStr(1, relText, "知人", vbTextCompare) > 0 Then Exit Function
    If InStr(1, relText, "不明", vbTextCompare) > 0 Then Exit Function
    RelationTextLooksKinship = True

End Function

Private Function PersonDisplayNameSafe(ByVal personId As String) As String

    Dim info As Object
    If Len(personId) = 0 Then Exit Function
    If mPersonInfo Is Nothing Then Exit Function
    If Not mPersonInfo.Exists(personId) Then Exit Function
    Set info = mPersonInfo(personId)
    If info.Exists("Name") Then PersonDisplayNameSafe = CStr(info("Name"))

End Function

Private Function BuildAddressByPersonIndex() As Object

    Dim dict As Object, ws As Worksheet, lastR As Long, r As Long

    Dim colPerson As Long, colStart As Long, colEnd As Long, colAddr As Long, colKey As Long

    Dim pid As String, rec As Object, col As Collection

    Set dict = CreateObject("Scripting.Dictionary")

    If Not SheetExists(SH_WORK_ADDRESS) Then Set BuildAddressByPersonIndex = dict: Exit Function

    Set ws = GetSheet(SH_WORK_ADDRESS)

    colPerson = FirstHeaderColumn(ws, Array("人物ID"), 1)

    colStart = FirstHeaderColumn(ws, Array("開始日", "居住開始日"), 1)

    colEnd = FirstHeaderColumn(ws, Array("終了日", "居住終了日"), 1)

    colAddr = FirstHeaderColumn(ws, Array("住所原文", "住所", "住所原文代表"), 1)

    colKey = FirstHeaderColumn(ws, Array("住所キー"), 1)

    If colPerson = 0 Then Set BuildAddressByPersonIndex = dict: Exit Function

    lastR = LastRow(ws, colPerson)

    For r = 2 To lastR

        pid = CellText(ws.Cells(r, colPerson).Value)

        If Len(pid) > 0 Then

            Set rec = CreateObject("Scripting.Dictionary")

            If colStart > 0 Then rec("Start") = ToDateOrEmpty(ws.Cells(r, colStart).Value) Else rec("Start") = Empty

            If colEnd > 0 Then rec("End") = ToDateOrEmpty(ws.Cells(r, colEnd).Value) Else rec("End") = Empty

            rec("Address") = GetCellByCol(ws, r, colAddr)

            rec("Key") = GetCellByCol(ws, r, colKey)

            If Len(CStr(rec("Key"))) = 0 Then rec("Key") = CStr(rec("Address"))

            If dict.Exists(pid) Then

                Set col = dict(pid)

            Else

                Set col = New Collection

                dict.Add pid, col

            End If

            col.Add rec

        End If

    Next r

    Set BuildAddressByPersonIndex = dict

End Function



Private Function PersonAgeAtDate(ByVal personId As String, ByVal atDate As Date) As String

    Dim info As Object, b As Variant, d As Variant, age As Long

    If mPersonInfo Is Nothing Then Exit Function

    If Not mPersonInfo.Exists(personId) Then Exit Function

    Set info = mPersonInfo(personId)

    b = info("Birth")

    d = info("Death")

    If Not IsDate(b) Then Exit Function

    If atDate < CDate(b) Then PersonAgeAtDate = "出生前": Exit Function

    If IsDate(d) And atDate > CDate(d) Then

        age = AgeYears(CDate(b), CDate(d))

        PersonAgeAtDate = "死亡後/死亡時" & CStr(age) & "歳"

    Else

        age = AgeYears(CDate(b), atDate)

        PersonAgeAtDate = CStr(age) & "歳"

    End If

End Function




Private Function PersonAgeYearsAtDate(ByVal personId As String, ByVal atDate As Date) As Long

    Dim info As Object, b As Variant, d As Variant

    PersonAgeYearsAtDate = -1

    If mPersonInfo Is Nothing Then Exit Function

    If Not mPersonInfo.Exists(personId) Then Exit Function

    Set info = mPersonInfo(personId)

    b = info("Birth")

    d = info("Death")

    If Not IsDate(b) Then Exit Function

    If atDate < CDate(b) Then Exit Function

    If IsDate(d) And atDate > CDate(d) Then

        PersonAgeYearsAtDate = AgeYears(CDate(b), CDate(d))

    Else

        PersonAgeYearsAtDate = AgeYears(CDate(b), atDate)

    End If

End Function

Private Function AddressChangeNearDate(ByVal personId As String, ByVal atDate As Date, ByVal windowDays As Long) As String

    Dim col As Collection, rec As Object, s As Variant, e As Variant, diffDays As Long

    If mAddressByPerson Is Nothing Then Exit Function

    If Not mAddressByPerson.Exists(personId) Then Exit Function

    Set col = mAddressByPerson(personId)

    For Each rec In col

        s = rec("Start")

        e = rec("End")

        If IsDate(s) Then

            diffDays = Abs(DateDiff("d", CDate(s), atDate))

            If diffDays <= windowDays Then

                AddressChangeNearDate = "転居開始" & CStr(diffDays) & "日内"

                Exit Function

            End If

        End If

        If IsDate(e) Then

            diffDays = Abs(DateDiff("d", CDate(e), atDate))

            If diffDays <= windowDays Then

                AddressChangeNearDate = "転居終了" & CStr(diffDays) & "日内"

                Exit Function

            End If

        End If

    Next rec

End Function


Private Function RelatedMoveNearTransaction(ByVal txPersonId As String, ByVal atDate As Date, ByVal windowDays As Long) As String

    Dim moverId As Variant, moveText As String, moverName As String

    If Len(txPersonId) = 0 Then Exit Function
    If mAddressByPerson Is Nothing Then Exit Function

    For Each moverId In mAddressByPerson.Keys
        If IsMovePaymentRelevantPerson(txPersonId, CStr(moverId)) Then
            moveText = AddressChangeNearDate(CStr(moverId), atDate, windowDays)
            If Len(moveText) > 0 Then
                moverName = PersonDisplayNameSafe(CStr(moverId))
                If Len(moverName) = 0 Then moverName = CStr(moverId)
                RelatedMoveNearTransaction = "転居者:" & ClipText(moverName, 8) & " " & moveText
                Exit Function
            End If
        End If
    Next moverId

End Function

Private Function PersonAgeAtInheritance(ByVal personId As String) As String

    If IsDate(mInheritanceDate) Then PersonAgeAtInheritance = PersonAgeAtDate(personId, CDate(mInheritanceDate))

End Function



Private Function AgeYears(ByVal birthDate As Date, ByVal atDate As Date) As Long

    AgeYears = Year(atDate) - Year(birthDate)

    If Month(atDate) < Month(birthDate) Or (Month(atDate) = Month(birthDate) And Day(atDate) < Day(birthDate)) Then AgeYears = AgeYears - 1

End Function



Private Function PersonAddressAtDate(ByVal personId As String, ByVal atDate As Date, ByVal returnKey As Boolean) As String

    Dim col As Collection, rec As Object, s As Variant, e As Variant

    If mAddressByPerson Is Nothing Then Exit Function

    If Not mAddressByPerson.Exists(personId) Then Exit Function

    Set col = mAddressByPerson(personId)

    For Each rec In col

        s = rec("Start"): e = rec("End")

        If (Not IsDate(s) Or CDate(s) <= atDate) And (Not IsDate(e) Or CDate(e) >= atDate) Then

            If returnKey Then PersonAddressAtDate = CStr(rec("Key")) Else PersonAddressAtDate = CStr(rec("Address"))

            Exit Function

        End If

    Next rec

End Function



Private Function AgeHintForRecords(ByVal outs As Collection, ByVal ins As Collection) As String

    AgeHintForRecords = JoinNonBlank(AgeHintForSide(outs), AgeHintForSide(ins), " / ")

    If Len(AgeHintForRecords) > 0 Then AgeHintForRecords = "年齢: " & AgeHintForRecords

End Function



Private Function AgeHintForSide(ByVal recs As Collection) As String

    Dim d As Object, rec As Object, displayAge As String, nameText As String

    Set d = CreateObject("Scripting.Dictionary")

    For Each rec In recs

        displayAge = CStr(rec("AgeAtTx"))

        If Len(displayAge) > 0 Then

            nameText = CStr(rec("Name"))

            If Len(nameText) = 0 Then nameText = CStr(rec("PersonId"))

            d(ClipText(nameText, 8) & " " & displayAge) = True

        End If

    Next rec

    AgeHintForSide = ClipText(JoinDictionaryKeys(d, " / "), 48)

End Function



Private Function AgeHintForRecord(ByVal rec As Object) As String

    If rec Is Nothing Then Exit Function

    If Not KeyExists(rec, "AgeAtTx") Then Exit Function

    If Len(CStr(rec("AgeAtTx"))) > 0 Then AgeHintForRecord = "年齢: " & CStr(rec("AgeAtTx"))

End Function



Private Function AddressHintForRecords(ByVal outs As Collection, ByVal ins As Collection) As String

    Dim outAddr As Object, inAddr As Object, k As Variant, outText As String, inText As String, body As String

    Set outAddr = AddressDictForSide(outs)

    Set inAddr = AddressDictForSide(ins)

    For Each k In outAddr.Keys

        If inAddr.Exists(k) And Len(CStr(k)) > 0 Then

            AddressHintForRecords = "住所: 同一 " & ClipText(CStr(outAddr(k)), 20)

            Exit Function

        End If

    Next k

    outText = ClipText(DictionaryItemsText(outAddr, " / "), 20)

    inText = ClipText(DictionaryItemsText(inAddr, " / "), 20)

    If Len(outText) > 0 Then body = "出 " & outText

    If Len(inText) > 0 Then body = JoinNonBlank(body, "入 " & inText, " / ")

    If Len(body) > 0 Then AddressHintForRecords = "住所: " & body

End Function



Private Function AddressDictForSide(ByVal recs As Collection) As Object

    Dim d As Object, rec As Object, keyText As String, addrText As String

    Set d = CreateObject("Scripting.Dictionary")

    For Each rec In recs

        keyText = CStr(rec("AddressKeyAtTx"))

        addrText = CStr(rec("AddressAtTx"))

        If Len(keyText) > 0 Then

            If Len(addrText) = 0 Then addrText = keyText

            d(keyText) = addrText

        End If

    Next rec

    Set AddressDictForSide = d

End Function



Private Function DictionaryItemsText(ByVal d As Object, ByVal sep As String) As String

    Dim k As Variant

    For Each k In d.Keys

        DictionaryItemsText = JoinNonBlank(DictionaryItemsText, CStr(d(k)), sep)

    Next k

End Function



Private Function AddressHintForRecord(ByVal rec As Object) As String

    If rec Is Nothing Then Exit Function

    If Not KeyExists(rec, "AddressAtTx") Then Exit Function

    If Len(CStr(rec("AddressAtTx"))) > 0 Then AddressHintForRecord = "住所: " & ClipText(CStr(rec("AddressAtTx")), 30)

End Function




Private Function RiskSignalText(ByVal outs As Collection, ByVal ins As Collection) As String

    Dim d As Object, rec As Object
    Set d = CreateObject("Scripting.Dictionary")

    If Not outs Is Nothing Then
        For Each rec In outs
            If CStr(rec("PersonId")) = mDecedentId And IsDate(mInheritanceDate) Then
                If IsDate(rec("Date")) And CDate(rec("Date")) >= CDate(mInheritanceDate) Then d("被相続人の相続後出金") = True
            End If
            If KeyExists(rec, "AgeAtTx") Then
                If InStr(1, CStr(rec("AgeAtTx")), "死亡後", vbTextCompare) > 0 Then d("死亡後取引") = True
            End If
        Next rec
    End If

    If Not ins Is Nothing Then
        For Each rec In ins
            If KeyExists(rec, "AgeAtTx") Then
                If InStr(1, CStr(rec("AgeAtTx")), "死亡後", vbTextCompare) > 0 Then d("死亡後取引") = True
            End If
        Next rec
    End If

    AppendRiskSignal d, YoungHighAmountSignal(outs, ins)
    AppendRiskSignal d, MoveAroundHighAmountSignal(outs, ins)
    AppendRiskSignal d, LifeEventAroundHighAmountSignal(outs, ins)
    AppendRiskSignal d, TimeClusterSignal(outs, ins)
    AppendRiskSignal d, AccountOperationPatternSignal(outs, ins)
    AppendRiskSignal d, CentralizedManagementSignal(outs, ins)
    AppendRiskSignal d, GiftAddBackSignal(outs, ins)
    AppendRiskSignal d, PreInheritanceWithdrawalSignal(outs)
    AppendRiskSignal d, TransactionAfterBalanceSignal(outs, ins)

    RiskSignalText = JoinDictionaryKeys(d, " / ")

End Function


Private Function RiskSignalForSingle(ByVal rec As Object) As String

    Dim outs As New Collection, ins As New Collection

    If rec Is Nothing Then Exit Function

    If KeyExists(rec, "Out") Then

        If CDbl(rec("Out")) > 0 Then outs.Add rec

    End If

    If KeyExists(rec, "In") Then

        If CDbl(rec("In")) > 0 Then ins.Add rec

    End If

    RiskSignalForSingle = RiskSignalText(outs, ins)

End Function


Private Sub EnrichTransactionAfterBalanceContext()

    Dim k As Variant, rec As Object
    Dim afterValue As Double, beforeValue As Double, outAmt As Double, inAmt As Double

    If mTxById Is Nothing Then Exit Sub
    For Each k In mTxById.Keys
        Set rec = mTxById(k)
        If Not rec Is Nothing Then
            If KeyExists(rec, "BalanceAfter") Then
                afterValue = CDbl(rec("BalanceAfter"))
                outAmt = 0#: inAmt = 0#
                If KeyExists(rec, "Out") Then outAmt = CDbl(rec("Out"))
                If KeyExists(rec, "In") Then inAmt = CDbl(rec("In"))
                beforeValue = afterValue + outAmt - inAmt
                rec("BalanceBefore") = beforeValue
                rec("BalanceAfterKnown") = True
                If beforeValue > 0 Then rec("BalanceChangeRate") = Application.Max(outAmt, inAmt) / beforeValue
            End If
        End If
    Next k

End Sub

Private Function TransactionAfterBalanceValue(ByVal v As Variant) As Variant

    Dim s As String
    If IsNumeric(v) Then TransactionAfterBalanceValue = CDbl(v): Exit Function
    s = CellText(v)
    If Len(s) = 0 Then TransactionAfterBalanceValue = "": Exit Function
    s = Replace$(s, ",", "")
    s = Replace$(s, "円", "")
    s = Replace$(s, "￥", "")
    s = Replace$(s, "残高", "")
    s = Replace$(s, "取引後", "")
    s = Replace$(s, "差引", "")
    s = Replace$(s, "：", "")
    s = Replace$(s, ":", "")
    s = Replace$(s, " ", "")
    s = Replace$(s, "　", "")
    s = Replace$(s, "△", "-")
    s = Replace$(s, "▲", "-")
    If IsNumeric(s) Then TransactionAfterBalanceValue = CDbl(s) Else TransactionAfterBalanceValue = ""

End Function

Private Function TransactionAfterBalanceSignal(ByVal outs As Collection, ByVal ins As Collection) As String

    TransactionAfterBalanceSignal = TransactionAfterBalanceSignalForSide(outs, True)
    TransactionAfterBalanceSignal = JoinNonBlank(TransactionAfterBalanceSignal, TransactionAfterBalanceSignalForSide(ins, False), " / ")

End Function

Private Function TransactionAfterBalanceSignalForSide(ByVal recs As Collection, ByVal useOut As Boolean) As String

    Dim rec As Object, amountValue As Double, beforeValue As Double, afterValue As Double, ratio As Double
    Dim whoText As String
    If recs Is Nothing Then Exit Function

    For Each rec In recs
        If KeyExists(rec, "BalanceAfter") And KeyExists(rec, "BalanceBefore") Then
            amountValue = 0#
            If useOut Then
                If KeyExists(rec, "Out") Then amountValue = CDbl(rec("Out"))
            Else
                If KeyExists(rec, "In") Then amountValue = CDbl(rec("In"))
            End If
            If amountValue >= mMinShift Then
                beforeValue = CDbl(rec("BalanceBefore"))
                afterValue = CDbl(rec("BalanceAfter"))
                ratio = 0#
                If beforeValue > 0 Then ratio = amountValue / beforeValue
                whoText = ""
                If KeyExists(rec, "Name") Then whoText = CStr(rec("Name"))
                If Len(whoText) = 0 And KeyExists(rec, "PersonId") Then whoText = CStr(rec("PersonId"))
                If useOut Then
                    If ratio >= 0.5 Or (beforeValue > 0 And afterValue <= beforeValue * 0.1) Then
                        TransactionAfterBalanceSignalForSide = "取引明細残高急減（" & ClipText(whoText, 8) & " 出金後残高" & Format$(afterValue, "#,##0") & "円 / 直前推定" & Format$(beforeValue, "#,##0") & "円）"
                        Exit Function
                    End If
                Else
                    If ratio >= 0.5 Then
                        TransactionAfterBalanceSignalForSide = "取引明細残高急増（" & ClipText(whoText, 8) & " 入金後残高" & Format$(afterValue, "#,##0") & "円 / 直前推定" & Format$(beforeValue, "#,##0") & "円）"
                        Exit Function
                    End If
                End If
            End If
        End If
    Next rec

End Function

Private Sub AppendRiskSignal(ByVal d As Object, ByVal signalText As String)

    If d Is Nothing Then Exit Sub

    If Len(signalText) > 0 Then d(signalText) = True

End Sub

Private Function YoungHighAmountSignal(ByVal outs As Collection, ByVal ins As Collection) As String

    YoungHighAmountSignal = YoungHighAmountSignalForSide(outs, True)

    YoungHighAmountSignal = JoinNonBlank(YoungHighAmountSignal, YoungHighAmountSignalForSide(ins, False), " / ")

End Function

Private Function YoungHighAmountSignalForSide(ByVal recs As Collection, ByVal useOut As Boolean) As String

    Dim rec As Object, ageYears As Long, amountValue As Double, whoText As String

    If recs Is Nothing Then Exit Function

    For Each rec In recs

        ageYears = -1

        amountValue = 0

        If KeyExists(rec, "AgeYearsAtTx") Then ageYears = CLng(rec("AgeYearsAtTx"))

        If useOut Then

            If KeyExists(rec, "Out") Then amountValue = CDbl(rec("Out"))

        Else

            If KeyExists(rec, "In") Then amountValue = CDbl(rec("In"))

        End If

        If ageYears >= 0 And ageYears < YOUNG_ATTENTION_AGE_YEARS And amountValue >= mMinShift Then

            whoText = ""

            If KeyExists(rec, "Name") Then whoText = CStr(rec("Name"))

            If Len(whoText) = 0 And KeyExists(rec, "PersonId") Then whoText = CStr(rec("PersonId"))

            YoungHighAmountSignalForSide = "若年注意高額取引（20歳未満: " & ClipText(whoText, 8) & " " & CStr(ageYears) & "歳）"

            Exit Function

        End If

    Next rec

End Function


Private Function LifeEventAroundHighAmountSignal(ByVal outs As Collection, ByVal ins As Collection) As String

    LifeEventAroundHighAmountSignal = LifeEventAroundHighAmountSignalForSide(outs, True)
    LifeEventAroundHighAmountSignal = JoinNonBlank(LifeEventAroundHighAmountSignal, LifeEventAroundHighAmountSignalForSide(ins, False), " / ")

End Function

Private Function LifeEventAroundHighAmountSignalForSide(ByVal recs As Collection, ByVal useOut As Boolean) As String

    Dim rec As Object, amountValue As Double, personId As String, txDate As Date
    Dim eventText As String, sideText As String
    If recs Is Nothing Then Exit Function
    If useOut Then sideText = "出金" Else sideText = "入金"

    For Each rec In recs
        If KeyExists(rec, "PersonId") And KeyExists(rec, "Date") Then
            If IsDate(rec("Date")) Then
                personId = CStr(rec("PersonId"))
                txDate = CDate(rec("Date"))
                amountValue = 0#
                If useOut Then
                    If KeyExists(rec, "Out") Then amountValue = CDbl(rec("Out"))
                Else
                    If KeyExists(rec, "In") Then amountValue = CDbl(rec("In"))
                End If
                If amountValue >= mMinShift Then
                    eventText = MarriageEventNearText(personId, txDate, DEFAULT_MOVE_NEAR_WINDOW_DAYS)
                    If Len(eventText) > 0 Then
                        LifeEventAroundHighAmountSignalForSide = "婚姻前後の高額" & sideText & "（" & ClipText(PersonDisplayNameSafe(personId), 8) & " / " & ClipText(eventText, 18) & "）"
                        Exit Function
                    End If
                    eventText = RelatedBirthNearText(personId, txDate, DEFAULT_MOVE_NEAR_WINDOW_DAYS)
                    If Len(eventText) > 0 Then
                        LifeEventAroundHighAmountSignalForSide = "出生前後の高額" & sideText & "（" & ClipText(PersonDisplayNameSafe(personId), 8) & " / " & ClipText(eventText, 18) & "）"
                        Exit Function
                    End If
                End If
            End If
        End If
    Next rec

End Function

Private Function MarriageEventNearText(ByVal personId As String, ByVal txDate As Date, ByVal windowDays As Long) As String

    Dim col As Collection, item As Object, daysDiff As Long, bestDays As Long, bestText As String
    If mMarriageByPerson Is Nothing Then Exit Function
    If Len(personId) = 0 Then Exit Function
    If Not mMarriageByPerson.Exists(personId) Then Exit Function
    bestDays = 999999
    Set col = mMarriageByPerson(personId)
    For Each item In col
        If KeyExists(item, "Date") Then
            If IsDate(item("Date")) Then
                daysDiff = Abs(DateDiff("d", DateValue(CDate(item("Date"))), DateValue(txDate)))
                If daysDiff <= windowDays And daysDiff < bestDays Then
                    bestDays = daysDiff
                    bestText = CStr(item("Text")) & " " & CStr(daysDiff) & "日差"
                End If
            End If
        End If
    Next item
    MarriageEventNearText = bestText

End Function

Private Function RelatedBirthNearText(ByVal personId As String, ByVal txDate As Date, ByVal windowDays As Long) As String

    Dim pid As Variant, info As Object, birthDate As Variant, daysDiff As Long, bestDays As Long, bestText As String
    Dim related As Boolean
    If mPersonInfo Is Nothing Then Exit Function
    If Len(personId) = 0 Then Exit Function
    bestDays = 999999
    For Each pid In mPersonInfo.Keys
        related = (CStr(pid) = personId)
        If Not related Then
            If Not mRelationPairs Is Nothing Then
                related = mRelationPairs.Exists(RelationPairKey(personId, CStr(pid)))
            End If
        End If
        If related Then
            Set info = mPersonInfo(pid)
            If Not info Is Nothing Then
                If KeyExists(info, "Birth") Then
                    birthDate = info("Birth")
                    If IsDate(birthDate) Then
                        daysDiff = Abs(DateDiff("d", DateValue(CDate(birthDate)), DateValue(txDate)))
                        If daysDiff <= windowDays And daysDiff < bestDays Then
                            bestDays = daysDiff
                            bestText = "出生:" & PersonDisplayNameSafe(CStr(pid)) & " " & CStr(daysDiff) & "日差"
                        End If
                    End If
                End If
            End If
        End If
    Next pid
    RelatedBirthNearText = bestText

End Function

Private Function MoveAroundHighAmountSignal(ByVal outs As Collection, ByVal ins As Collection) As String

    MoveAroundHighAmountSignal = MoveAroundHighAmountSignalForSide(outs, True)
    MoveAroundHighAmountSignal = JoinNonBlank(MoveAroundHighAmountSignal, MoveAroundHighAmountSignalForSide(ins, False), " / ")

End Function

Private Function MoveAroundHighAmountSignalForSide(ByVal recs As Collection, ByVal useOut As Boolean) As String

    Dim rec As Object, amountValue As Double, whoText As String, moveText As String

    If recs Is Nothing Then Exit Function

    For Each rec In recs

        amountValue = 0
        If useOut Then
            If KeyExists(rec, "Out") Then amountValue = CDbl(rec("Out"))
            If amountValue >= mMinShift And KeyExists(rec, "RelatedMoveNearTx") Then
                moveText = CStr(rec("RelatedMoveNearTx"))
                If Len(moveText) > 0 Then
                    whoText = PersonDisplayNameSafe(CStr(rec("PersonId")))
                    If Len(whoText) = 0 And KeyExists(rec, "Name") Then whoText = CStr(rec("Name"))
                    If Len(whoText) = 0 Then whoText = CStr(rec("PersonId"))
                    MoveAroundHighAmountSignalForSide = "転居前後の高額出金（" & ClipText(whoText, 8) & " / " & ClipText(moveText, 24) & "）"
                    Exit Function
                End If
            End If
        Else
            If KeyExists(rec, "In") Then amountValue = CDbl(rec("In"))
            If amountValue >= mMinShift And KeyExists(rec, "AddressChangeNearTx") Then
                moveText = CStr(rec("AddressChangeNearTx"))
                If Len(moveText) > 0 Then
                    whoText = PersonDisplayNameSafe(CStr(rec("PersonId")))
                    If Len(whoText) = 0 And KeyExists(rec, "Name") Then whoText = CStr(rec("Name"))
                    If Len(whoText) = 0 Then whoText = CStr(rec("PersonId"))
                    MoveAroundHighAmountSignalForSide = "転居前後の高額入金（" & ClipText(whoText, 8) & " " & ClipText(moveText, 12) & "）"
                    Exit Function
                End If
            End If
        End If

    Next rec

End Function

Private Function TimeClusterSignal(ByVal outs As Collection, ByVal ins As Collection) As String

    TimeClusterSignal = TimeClusterSignalForSide(outs)

    If Len(TimeClusterSignal) = 0 Then TimeClusterSignal = TimeClusterSignalForSide(ins)

End Function

Private Function TimeClusterSignalForSide(ByVal recs As Collection) As String

    Dim rec As Object, col As Collection, accountCount As Long, personCount As Long

    If recs Is Nothing Then Exit Function

    If mTimeCluster Is Nothing Then Exit Function

    For Each rec In recs

        Set col = NearbyTimeClusterRecords(rec)

        accountCount = DistinctCountInCluster(col, "AccountId")

        personCount = DistinctCountInCluster(col, "PersonId")

        If col.Count >= 3 And (accountCount >= 2 Or personCount >= 2) Then

            TimeClusterSignalForSide = "同日時刻付近に複数名義取引集中（" & CStr(col.Count) & "件）"

            Exit Function

        End If

    Next rec

End Function

Private Function AccountOperationPatternSignal(ByVal outs As Collection, ByVal ins As Collection) As String

    AccountOperationPatternSignal = AccountOperationPatternSignalForSide(outs)

    If Len(AccountOperationPatternSignal) = 0 Then AccountOperationPatternSignal = AccountOperationPatternSignalForSide(ins)

End Function

Private Function AccountOperationPatternSignalForSide(ByVal recs As Collection) As String

    Dim rec As Object, acc As String, cnt As Long, whoText As String

    If recs Is Nothing Then Exit Function

    If mAccountOperationPatternCount Is Nothing Then Exit Function

    For Each rec In recs

        acc = CStr(rec("AccountId"))

        If Len(acc) > 0 And mAccountOperationPatternCount.Exists(acc) Then

            cnt = CLng(mAccountOperationPatternCount(acc))

            If cnt >= 3 Then

                whoText = CStr(rec("Name"))

                If Len(whoText) = 0 Then whoText = acc

                AccountOperationPatternSignalForSide = "類似時刻帯に反復する複数口座操作（" & ClipText(whoText, 8) & " " & CStr(cnt) & "回）"

                Exit Function

            End If

        End If

    Next rec

End Function

Private Function CentralizedManagementSignal(ByVal outs As Collection, ByVal ins As Collection) As String

    If Len(TimeClusterSignal(outs, ins)) > 0 Then
        CentralizedManagementSignal = "名義外管理確認（同時刻帯・複数名義）"
    ElseIf Len(AccountOperationPatternSignal(outs, ins)) > 0 Then
        CentralizedManagementSignal = "名義外管理確認（類似時刻帯反復）"
    End If

End Function

Private Function GiftAddBackSignal(ByVal outs As Collection, ByVal ins As Collection) As String

    Dim rec As Object
    Dim hasDecedentOutInPeriod As Boolean
    Dim hasRelatedInInPeriod As Boolean

    If Not outs Is Nothing Then
        For Each rec In outs
            If IsDecedentRecord(rec) And IsDate(rec("Date")) Then
                If IsGiftAddBackPeriodDate(CDate(rec("Date"))) Then
                    hasDecedentOutInPeriod = True
                    Exit For
                End If
            End If
        Next rec
    End If

    If Not ins Is Nothing Then
        For Each rec In ins
            If IsDate(rec("Date")) Then
                If IsGiftAddBackPeriodDate(CDate(rec("Date"))) And IsRelatedOrKinNonDecedentRecord(rec) Then
                    hasRelatedInInPeriod = True
                    Exit For
                End If
            End If
        Next rec
    End If

    If hasDecedentOutInPeriod And hasRelatedInInPeriod Then
        GiftAddBackSignal = "暦年贈与加算期間内シフト確認"
    ElseIf hasRelatedInInPeriod Then
        If outs Is Nothing Then
            GiftAddBackSignal = "暦年贈与加算期間内の高額不明入金確認"
        ElseIf outs.Count = 0 Then
            GiftAddBackSignal = "暦年贈与加算期間内の高額不明入金確認"
        End If
    End If

End Function

Private Function PreInheritanceWithdrawalSignal(ByVal outs As Collection) As String

    Dim rec As Object, daysBefore As Long, amountValue As Double, bestDays As Long

    If outs Is Nothing Then Exit Function
    bestDays = 999999

    For Each rec In outs
        If IsDecedentRecord(rec) And IsDate(rec("Date")) Then
            daysBefore = DaysBeforeInheritance(CDate(rec("Date")))
            If daysBefore >= 0 And daysBefore <= 365 Then
                amountValue = 0
                If KeyExists(rec, "Out") Then amountValue = CDbl(rec("Out"))
                If amountValue >= mUnknownThreshold Then
                    If daysBefore < bestDays Then bestDays = daysBefore
                End If
            End If
        End If
    Next rec

    If bestDays <= 7 Then
        PreInheritanceWithdrawalSignal = "死亡直前大口出金確認（7日内）"
    ElseIf bestDays <= 30 Then
        PreInheritanceWithdrawalSignal = "相続直前大口出金確認（30日内）"
    ElseIf bestDays <= 90 Then
        PreInheritanceWithdrawalSignal = "相続直前大口出金確認（90日内）"
    ElseIf bestDays <= 365 Then
        PreInheritanceWithdrawalSignal = "相続前1年内大口出金確認"
    End If

End Function

Private Function IsDecedentRecord(ByVal rec As Object) As Boolean

    If rec Is Nothing Then Exit Function
    If Len(mDecedentId) = 0 Then Exit Function
    If KeyExists(rec, "PersonId") Then IsDecedentRecord = (CStr(rec("PersonId")) = mDecedentId)

End Function

Private Function IsRelatedOrKinNonDecedentRecord(ByVal rec As Object) As Boolean

    Dim pid As String
    If rec Is Nothing Then Exit Function
    If Not KeyExists(rec, "PersonId") Then Exit Function
    pid = CStr(rec("PersonId"))
    If Len(pid) = 0 Then Exit Function
    If Len(mDecedentId) > 0 And pid = mDecedentId Then Exit Function
    If IsKinshipPerson(pid) Then IsRelatedOrKinNonDecedentRecord = True: Exit Function
    If Not mRelationPairs Is Nothing And Len(mDecedentId) > 0 Then
        If mRelationPairs.Exists(RelationPairKey(mDecedentId, pid)) Then IsRelatedOrKinNonDecedentRecord = True
    End If

End Function

Private Function IsGiftAddBackPeriodDate(ByVal atDate As Date) As Boolean

    Dim startDate As Variant, inhDate As Date
    If Not IsDate(mInheritanceDate) Then Exit Function
    inhDate = DateValue(CDate(mInheritanceDate))
    If DateValue(atDate) > inhDate Then Exit Function
    startDate = GiftAddBackPeriodStartDate(inhDate)
    If Not IsDate(startDate) Then Exit Function
    IsGiftAddBackPeriodDate = (DateValue(atDate) >= DateValue(CDate(startDate)) And DateValue(atDate) <= inhDate)

End Function

Private Function GiftAddBackPeriodStartDate(ByVal inheritanceDate As Date) As Variant

    Dim d As Date
    d = DateValue(inheritanceDate)
    If d <= DateSerial(2026, 12, 31) Then
        GiftAddBackPeriodStartDate = DateAdd("yyyy", -3, d)
    ElseIf d <= DateSerial(2030, 12, 31) Then
        GiftAddBackPeriodStartDate = DateSerial(2024, 1, 1)
    Else
        GiftAddBackPeriodStartDate = DateAdd("yyyy", -7, d)
    End If

End Function

Private Function DaysBeforeInheritance(ByVal atDate As Date) As Long

    DaysBeforeInheritance = -1
    If Not IsDate(mInheritanceDate) Then Exit Function
    If DateValue(atDate) > DateValue(CDate(mInheritanceDate)) Then Exit Function
    DaysBeforeInheritance = DateDiff("d", DateValue(atDate), DateValue(CDate(mInheritanceDate)))

End Function

Private Function DistinctCountInCluster(ByVal col As Collection, ByVal fieldName As String) As Long

    Dim d As Object, rec As Object, k As String

    Set d = CreateObject("Scripting.Dictionary")

    If col Is Nothing Then Exit Function

    For Each rec In col

        If KeyExists(rec, fieldName) Then

            k = CStr(rec(fieldName))

            If Len(k) > 0 Then d(k) = True

        End If

    Next rec

    DistinctCountInCluster = d.Count

End Function



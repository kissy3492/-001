Attribute VB_Name = "modSetup"
Option Explicit

Public Sub SetupWorkbook()
    Dim ans As VbMsgBoxResult
    ans = MsgBox("資金移動分析ツールをセットアップします。" & vbCrLf & _
                 "既存の同名シートは再整形されます。実行しますか。", vbQuestion + vbYesNo, _
                 "03_資金移動分析ツール セットアップ")
    If ans <> vbYes Then Exit Sub
    On Error GoTo EH
    AppBegin "セットアップ中..."
    PrepareSheets
    BuildMainSheet
    InitWorkSheets
    HideWorkSheets
    HideDailySheets False
    ProtectMainSheet
    AppEnd
    MsgBox "セットアップが完了しました。" & vbCrLf & _
           "まず「共通データ読込」を押し、次に「分析実行」を押してください。", vbInformation
    Exit Sub
EH:
    AppEnd
    MsgBox "セットアップ中にエラーが発生しました。" & vbCrLf & Err.Description, vbExclamation
End Sub

Private Sub PrepareSheets()
    Dim names As Variant, i As Long, ws As Worksheet
    names = Array(SH_MAIN, SH_RESULT, SH_DETAIL, SH_FLAGGED, SH_ISSUE, SH_CHECK, SH_LOG, SH_WORK_PERSON, SH_WORK_REL, SH_WORK_ACCOUNT, SH_WORK_TX, SH_WORK_COHAB, SH_WORK_ADDRESS, SH_WORK_RESULT, SH_WORK_DETAIL, SH_WORK_ID, SH_MANUAL_EXCLUDE, SH_MANUAL_STATE)
    For i = LBound(names) To UBound(names)
        Set ws = GetOrCreateSheet(CStr(names(i)), True)
        ws.Cells.Font.Name = "Meiryo UI"
        ws.Cells.Font.Size = 9
    Next i
End Sub

Private Sub BuildMainSheet()
    Dim ws As Worksheet
    Set ws = GetSheet(SH_MAIN)
    ws.Cells.Clear
    DeleteAllShapes ws
    ThemeApplyCanvas ws
    ws.Cells.Font.Name = THEME_FONT
    ws.Cells.Font.Size = 10
    ws.Range("A1:J1").Merge
    ThemeApplyTitle ws.Range("A1:J1"), "03_資金移動分析ツール"
    ws.Rows(1).RowHeight = 40

    ws.Range("A3:J3").Merge
    ws.Range("A3").Value = "人物情報系・資金操作表作成補助ツールが作成した 00_共通データ.xlsx を読み込み、シフト・相続関連シフト・不明入出金を抽出します。"
    ThemeApplyHintRange ws.Range("A3:J3"), "info-very-soft"
    ws.Rows(3).RowHeight = 32

    SetRowValues ws.Range("B5"), Array("連携・条件", "値", "説明")
    FormatHeader ws.Range("B5:D5"), ThemeColor("blue")
    ws.Range("B6").Value = "共通データファイル"
    ws.Range("E6").Value = COMMON_DATA_FILE
    ws.Range("B7").Value = "相続開始日"
    ws.Range("E7").Value = ""
    ws.Range("B8").Value = "被相続人人物ID"
    ws.Range("E8").Value = ""
    ws.Range("B10").Value = "シフト抽出金額下限"
    ws.Range("E10").Value = DEFAULT_MIN_SHIFT_AMOUNT
    ws.Range("B11").Value = "日付許容日数"
    ws.Range("E11").Value = DEFAULT_DATE_WINDOW
    ws.Range("B12").Value = "金額許容差"
    ws.Range("E12").Value = DEFAULT_AMOUNT_TOLERANCE
    ws.Range("B13").Value = "金額許容率"
    ws.Range("E13").Value = DEFAULT_AMOUNT_TOLERANCE_RATE
    ws.Range("B14").Value = "最大組合せ件数"
    ws.Range("E14").Value = DEFAULT_MAX_COMBO
    ws.Range("B15").Value = "片側候補上限"
    ws.Range("E15").Value = DEFAULT_MAX_SIDE_CANDIDATES
    ws.Range("B16").Value = "不明入出金下限"
    ws.Range("E16").Value = DEFAULT_UNKNOWN_THRESHOLD
    ws.Range("B17").Value = "伝票依頼フラグ下限"
    ws.Range("E17").Value = DEFAULT_VOUCHER_THRESHOLD
    ws.Range("B18").Value = "分析後に共通データ保存"
    ws.Range("E18").Value = "する"
    ws.Range("B19").Value = "分析後に出力シート表示"
    ws.Range("E19").Value = "する"

    ws.Range("B21").Value = "1対1を抽出"
    ws.Range("E21").Value = DEFAULT_ENABLE_ONE_TO_ONE
    ws.Range("B22").Value = "1対複数を抽出"
    ws.Range("E22").Value = DEFAULT_ENABLE_ONE_TO_MANY
    ws.Range("B23").Value = "複数対1を抽出"
    ws.Range("E23").Value = DEFAULT_ENABLE_MANY_TO_ONE
    ws.Range("B24").Value = "複数対複数を抽出"
    ws.Range("E24").Value = DEFAULT_ENABLE_MANY_TO_MANY
    ws.Range("B25").Value = "不明入出金を抽出"
    ws.Range("E25").Value = DEFAULT_ENABLE_UNKNOWNS
    ws.Range("B26").Value = "候補済み取引を不明入出金から除外"
    ws.Range("E26").Value = DEFAULT_SUPPRESS_DUPLICATE_SHIFT
    ws.Range("B27").Value = "分析候補の最大出力件数"
    ws.Range("E27").Value = DEFAULT_MAX_RESULTS
    ws.Range("B28").Value = "組合せ生成上限/基準取引"
    ws.Range("E28").Value = DEFAULT_MAX_COMBOS_PER_BASE
    ws.Range("B29").Value = "複数対複数の照合上限/基準取引"
    ws.Range("E29").Value = DEFAULT_MAX_MTM_PAIR_TESTS
    ws.Range("B30").Value = "相続関連シフトは常に伝票依頼"
    ws.Range("E30").Value = DEFAULT_VOUCHER_INHERITANCE_ALWAYS
    ws.Range("B31").Value = "不明入出金も伝票依頼対象"
    ws.Range("E31").Value = DEFAULT_VOUCHER_UNKNOWNS
    ws.Range("B32").Value = "除外摘要キーワード"
    ws.Range("E32").Value = DEFAULT_EXCLUDE_SUMMARY_KEYWORDS
    ws.Range("B33").Value = "条件が広すぎる場合は停止"
    ws.Range("E33").Value = DEFAULT_STOP_IF_TOO_BROAD
    ws.Range("B34").Value = "相続開始前重点年数"
    ws.Range("E34").Value = DEFAULT_INHERITANCE_FOCUS_YEARS
    ws.Range("B35").Value = "シフト候補の最低信頼度"
    ws.Range("E35").Value = DEFAULT_MIN_SCORE
    ws.Range("B36").Value = "住所・年齢補助を信頼度に反映"
    ws.Range("E36").Value = DEFAULT_CONTEXT_SCORE

    ws.Range("D6").Value = "同じ案件フォルダ内のファイル名。通常は変更不要。"
    ws.Range("D7").Value = "共通データ読込時に自動反映。相続関連シフト判定に使用。"
    ws.Range("D8").Value = "共通データ読込時に自動反映。"
    ws.Range("D10").Value = "この金額以上をシフト候補の中心にします。"
    ws.Range("D11").Value = "出金日と入金日の許容日数。"
    ws.Range("D12").Value = "出金合計と入金合計の絶対差許容。"
    ws.Range("D13").Value = "率で許容する場合。0.01で1%。"
    ws.Range("D14").Value = "1対複数・複数対1・複数対複数の片側最大件数。標準3、最大10。大きくするほど候補数制限を厳守します。"
    ws.Range("D15").Value = "組合せ爆発防止。大きくしすぎない。"
    ws.Range("D16").Value = "対応が見つからない入出金の抽出下限。"
    ws.Range("D17").Value = "この金額以上の候補は伝票依頼「要」。"
    ws.Range("D18").Value = "する/しない。"
    ws.Range("D19").Value = "する/しない。"
    ws.Range("D21").Value = "同額・近似額の1出金対1入金。最も軽い分析です。"
    ws.Range("D22").Value = "1件の出金が複数入金に分かれた候補。上限設定で重さを抑えます。"
    ws.Range("D23").Value = "複数出金が1件入金にまとまった候補。上限設定で重さを抑えます。"
    ws.Range("D24").Value = "最も重い分析です。広げすぎないよう候補数・照合回数で止めます。"
    ws.Range("D25").Value = "対応が見つからない指定額以上の入金・出金を抽出します。"
    ws.Range("D26").Value = "する場合、シフト候補に含まれた取引は不明入出金として重複表示しません。候補生成自体は妨げません。"
    ws.Range("D27").Value = "この件数に達したら分析を止めます。大量出力による操作不能を防ぎます。"
    ws.Range("D28").Value = "組合せ候補の生成数上限。O(n^k)化を避ける安全弁です。"
    ws.Range("D29").Value = "複数対複数の照合回数上限。O(n^2)的な総当たりをここで止めます。"
    ws.Range("D30").Value = "相続開始後の被相続人名義口座からのシフトは金額に関係なく伝票依頼を要にできます。"
    ws.Range("D31").Value = "不明入金・不明出金も金額下限以上なら伝票依頼要にするか。"
    ws.Range("D32").Value = "カンマ区切り。摘要に含まれる取引を分析対象から外します。例：利息,手数料"
    ws.Range("D33").Value = "日付幅や候補上限が広すぎるとき、処理前に止めて確認します。"
    ws.Range("D34").Value = "相続開始日前の何年内かを補助表示します。標準は5年。"
    ws.Range("D35").Value = "低信頼のシフト候補を出しすぎないための下限。手動判断済み候補は復元します。標準55点。"
    ws.Range("D36").Value = "同居推定、同一住所、相続後出金、取扱店一致などを信頼度に軽く反映します。"

    ThemeApplyFormCard ws.Range("B5:E19"), "accent"
    ws.Range("B6:B19").Interior.Color = ThemeColor("locked")
    ThemeApplyFormCard ws.Range("B21:E36"), "teal"
    ws.Range("B21:B36").Interior.Color = ThemeColor("locked")
    ws.Range("E6:E19").Interior.Color = vbWhite
    ws.Range("E21:E36").Interior.Color = vbWhite
    ws.Range("D6:D19").Interior.Color = ThemeColor("canvas")
    ws.Range("D21:D36").Interior.Color = ThemeColor("canvas")
    ws.Range("B6:E19").Borders.LineStyle = xlContinuous
    ws.Range("B21:E36").Borders.LineStyle = xlContinuous
    ws.Range("B6:E19").Borders.Color = ThemeColor("border")
    ws.Range("B21:E36").Borders.Color = ThemeColor("border")
    ws.Range("E10:E17").NumberFormatLocal = "#,##0"
    ws.Range("E27:E29").NumberFormatLocal = "#,##0"
    ws.Range("E34:E35").NumberFormatLocal = "0"
    ws.Range("E13").NumberFormatLocal = "0.00%"
    ws.Range("E7").NumberFormatLocal = "yyyy/m/d"
    ws.Range("B38:J38").Merge
    ws.Range("B38").Value = "操作順：1 共通データ読込 → 2 整合チェック → 3 分析実行 → 4 結果確認 → 5 共通データ保存"
    ThemeApplyStepBar ws.Range("B38:J38")
    ws.Range("B38").Font.Bold = True

    ws.Range("B40:D47").Merge
    ws.Range("B40").Value = "分類ルール" & vbCrLf & _
                            "・対応する出金と入金があるもの：シフト" & vbCrLf & _
                            "・相続開始後の被相続人名義口座からの出金を含むもの：相続関連シフト" & vbCrLf & _
                            "・対応出金がない指定額以上の入金：不明入金" & vbCrLf & _
                            "・対応入金がない指定額以上の出金：不明出金" & vbCrLf & _
                            "・補助フラグ：20歳未満高額取引、転居前後高額取引、同日時刻帯集中"
    ThemeApplyHintRange ws.Range("B40:D47"), "info-soft"
    ws.Range("B40").WrapText = True
    ws.Range("B40").VerticalAlignment = xlTop

    ws.Range("F40:J47").Merge
    ws.Range("F40").Value = "無駄入力を避けるため、人物名・続柄・口座情報・取扱店確定値は前工程の共通データから読み込みます。" & vbCrLf & _
                            "このツールで手入力するのは分析条件だけです。分析後は「調査論点サマリ」で、税務調査上見るべき候補を論点別に確認できます。成人年齢は18歳、調査上の若年注意は20歳未満で区別します。" & vbCrLf & _
                            "転居前後の高額出金は、被相続人・転居者本人・親族関係者に限定して補助表示します。"
    ThemeApplyHintRange ws.Range("F40:J47"), "success-bg"
    ws.Range("F40").WrapText = True
    ws.Range("F40").VerticalAlignment = xlTop

    AddMainButton ws, "共通データ読込", "LoadCommonData", ws.Range("L5"), ThemeColor("blue")
    AddMainButton ws, "整合チェック", "CheckAnalysisReadiness", ws.Range("L8"), ThemeColor("orange")
    AddMainButton ws, "分析実行", "RunAnalysis", ws.Range("L11"), ThemeColor("green")
    AddMainButton ws, "再分析", "ReAnalyzeFromResultSheet", ws.Range("L14"), ThemeColor("orange")
    AddMainButton ws, "手動変更反映", "ApplyManualEditsFromResultSheet", ws.Range("L17"), ThemeColor("red")
    AddMainButton ws, "共通データ保存", "SaveAnalysisToCommonData", ws.Range("L20"), ThemeColor("teal")
    AddMainButton ws, "結果表示", "ShowOutputSheets", ws.Range("L23"), ThemeColor("purple")
    AddMainButton ws, "通常表示", "HideDailySheets", ws.Range("L26"), ThemeColor("muted")
    AddMainButton ws, "最終出力", "ExportAnalysisWorkbook", ws.Range("L29"), ThemeColor("purple")
    AddMainButton ws, "設定初期化", "ResetAnalysisSettings", ws.Range("L32"), ThemeColor("muted")
    AddMainButton ws, "論点サマリ", "BuildInvestigationIssueSheet", ws.Range("L35"), ThemeColor("purple")

    ws.Columns("A:A").ColumnWidth = 2
    ws.Columns("B:B").ColumnWidth = 22
    ws.Columns("C:C").ColumnWidth = 2
    ws.Columns("D:D").ColumnWidth = 54
    ws.Columns("E:E").ColumnWidth = 18
    ws.Columns("F:J").ColumnWidth = 12
    ws.Columns("L:O").ColumnWidth = 14
    ThemeApplyCommandBar ws.Range("L5:O37")
    ws.Rows("1:50").RowHeight = 22
    ws.Range("E6:E19").Locked = False
    ws.Range("E21:E36").Locked = False
    ws.Range("E7").Locked = False
    ApplyYesNoValidation ws.Range("E18:E19")
    ApplyYesNoValidation ws.Range("E21:E26")
    ApplyYesNoValidation ws.Range("E30:E31")
    ApplyYesNoValidation ws.Range("E33:E33")
    ApplyYesNoValidation ws.Range("E36:E36")
    ApplyNumericValidation ws.Range("E10:E17"), 0, 999999999999#
    ApplyNumericValidation ws.Range("E27:E29"), 1, 500000
    ApplyNumericValidation ws.Range("E14"), 1, MAX_ALLOWED_COMBO
    ApplyNumericValidation ws.Range("E34"), 1, 20
    ApplyNumericValidation ws.Range("E35"), 0, 100
End Sub

Private Sub ApplyNumericValidation(ByVal rng As Range, ByVal minValue As Double, ByVal maxValue As Double)
    On Error Resume Next
    rng.Validation.Delete
    rng.Validation.Add Type:=xlValidateDecimal, AlertStyle:=xlValidAlertStop, Operator:=xlBetween, Formula1:=CStr(minValue), Formula2:=CStr(maxValue)
    rng.Validation.IgnoreBlank = True
    rng.Validation.InCellDropdown = False
    On Error GoTo 0
End Sub

Private Sub ApplyYesNoValidation(ByVal rng As Range)
    On Error Resume Next
    rng.Validation.Delete
    rng.Validation.Add Type:=xlValidateList, AlertStyle:=xlValidAlertStop, Operator:=xlBetween, Formula1:="する,しない"
    rng.Validation.IgnoreBlank = True
    rng.Validation.InCellDropdown = True
    On Error GoTo 0
End Sub

Private Sub AddMainButton(ByVal ws As Worksheet, ByVal caption As String, ByVal macroName As String, ByVal anchor As Range, ByVal fillColor As Long)
    Dim shp As Shape
    Set shp = ws.Shapes.AddShape(msoShapeRoundedRectangle, anchor.Left, anchor.Top, ws.Range(anchor, anchor.Offset(1, 3)).Width, 38)
    shp.Name = "btn_" & macroName
    ThemeStyleButtonShapeWithColor shp, caption, fillColor, fillColor, ThemeReadableFontColor(fillColor), macroName
End Sub

Private Sub InitWorkSheets()
    Dim ws As Worksheet
    Set ws = GetSheet(SH_WORK_ID)
    SetRowValues ws.Range("A1"), Array("種別", "接頭辞", "次番号", "桁数", "最終採番日時")
    FormatHeader ws.Range("A1:E1")
    SetRowValues ws.Range("A2"), Array("分析候補", "AN", 1, 6, "")
    SetRowValues ws.Range("A3"), Array("分析明細", "AD", 1, 6, "")
    SetRowValues ws.Range("A4"), Array("伝票候補", "VR", 1, 6, "")

    InitResultHeaders GetSheet(SH_WORK_RESULT)
    InitDetailHeaders GetSheet(SH_WORK_DETAIL)
    InitResultHeaders GetSheet(SH_RESULT)
    InitDetailHeaders GetSheet(SH_DETAIL)
    InitInvestigationIssueSheet GetSheet(SH_ISSUE)
    InitManualExcludeHeaders GetSheet(SH_MANUAL_EXCLUDE)
    InitManualStateHeaders GetSheet(SH_MANUAL_STATE)
    InitCheckSheet
End Sub

Public Sub InitResultHeaders(ByVal ws As Worksheet)
    ws.Cells.Clear
    SetRowValues ws.Range("A1"), Array("分析候補ID", "区分", "組合せ", "スコア", "伝票依頼", "出金日範囲", "入金日範囲", "出金合計", "入金合計", "差額", "出金側人物", "入金側人物", "名義関係", "相続開始前後", "同居推定", "出金取引ID", "入金取引ID", "銀行・取扱店", "摘要", "メモ", "シフト採用", "操作メモ", "年齢補助", "住所補助")
    FormatHeader ws.Range("A1:X1")
End Sub

Public Sub InitManualExcludeHeaders(ByVal ws As Worksheet)
    ws.Cells.Clear
    SetRowValues ws.Range("A1"), Array("取引ID", "除外元分析候補ID", "除外日時", "メモ")
    FormatHeader ws.Range("A1:D1"), ThemeColor("muted")
End Sub


Public Sub InitManualStateHeaders(ByVal ws As Worksheet)
    ws.Cells.Clear
    SetRowValues ws.Range("A1"), Array("候補キー", "分析候補ID", "伝票依頼", "採用", "操作メモ", "更新日時")
    FormatHeader ws.Range("A1:F1"), ThemeColor("purple")
End Sub

Public Sub InitDetailHeaders(ByVal ws As Worksheet)
    ws.Cells.Clear
    SetRowValues ws.Range("A1"), Array("分析明細ID", "分析候補ID", "側", "取引ID", "日付", "金額", "人物ID", "氏名", "口座ID", "銀行名", "支店名", "科目", "口座番号", "取扱店確定値", "摘要", "区分", "伝票依頼")
    FormatHeader ws.Range("A1:Q1")
End Sub

Private Sub InitCheckSheet()
    Dim ws As Worksheet
    Set ws = GetSheet(SH_CHECK)
    ws.Cells.Clear
    SetRowValues ws.Range("A1"), Array("区分", "内容", "対応")
    FormatHeader ws.Range("A1:C1"), ThemeColor("red")
    ws.Columns("A:A").ColumnWidth = 14
    ws.Columns("B:B").ColumnWidth = 70
    ws.Columns("C:C").ColumnWidth = 48
End Sub

Public Sub ResetAnalysisSettings()
    Dim ws As Worksheet
    Set ws = GetSheet(SH_MAIN)
    On Error Resume Next
    ws.Unprotect Password:=TOOL_PASSWORD
    ws.Cells(ROW_COMMON_FILE, COL_VALUE).Value = COMMON_DATA_FILE
    ws.Cells(ROW_MIN_SHIFT_AMOUNT, COL_VALUE).Value = DEFAULT_MIN_SHIFT_AMOUNT
    ws.Cells(ROW_DATE_WINDOW, COL_VALUE).Value = DEFAULT_DATE_WINDOW
    ws.Cells(ROW_AMOUNT_TOLERANCE, COL_VALUE).Value = DEFAULT_AMOUNT_TOLERANCE
    ws.Cells(ROW_AMOUNT_TOLERANCE_RATE, COL_VALUE).Value = DEFAULT_AMOUNT_TOLERANCE_RATE
    ws.Cells(ROW_MAX_COMBO, COL_VALUE).Value = DEFAULT_MAX_COMBO
    ws.Cells(ROW_MAX_SIDE_CANDIDATES, COL_VALUE).Value = DEFAULT_MAX_SIDE_CANDIDATES
    ws.Cells(ROW_UNKNOWN_THRESHOLD, COL_VALUE).Value = DEFAULT_UNKNOWN_THRESHOLD
    ws.Cells(ROW_VOUCHER_THRESHOLD, COL_VALUE).Value = DEFAULT_VOUCHER_THRESHOLD
    ws.Cells(ROW_AUTO_SAVE_COMMON, COL_VALUE).Value = "する"
    ws.Cells(ROW_KEEP_OUTPUT_VISIBLE, COL_VALUE).Value = "する"
    ws.Cells(ROW_ENABLE_ONE_TO_ONE, COL_VALUE).Value = DEFAULT_ENABLE_ONE_TO_ONE
    ws.Cells(ROW_ENABLE_ONE_TO_MANY, COL_VALUE).Value = DEFAULT_ENABLE_ONE_TO_MANY
    ws.Cells(ROW_ENABLE_MANY_TO_ONE, COL_VALUE).Value = DEFAULT_ENABLE_MANY_TO_ONE
    ws.Cells(ROW_ENABLE_MANY_TO_MANY, COL_VALUE).Value = DEFAULT_ENABLE_MANY_TO_MANY
    ws.Cells(ROW_ENABLE_UNKNOWNS, COL_VALUE).Value = DEFAULT_ENABLE_UNKNOWNS
    ws.Cells(ROW_SUPPRESS_DUPLICATE_SHIFT, COL_VALUE).Value = DEFAULT_SUPPRESS_DUPLICATE_SHIFT
    ws.Cells(ROW_MAX_RESULTS, COL_VALUE).Value = DEFAULT_MAX_RESULTS
    ws.Cells(ROW_MAX_COMBOS_PER_BASE, COL_VALUE).Value = DEFAULT_MAX_COMBOS_PER_BASE
    ws.Cells(ROW_MAX_MTM_PAIR_TESTS, COL_VALUE).Value = DEFAULT_MAX_MTM_PAIR_TESTS
    ws.Cells(ROW_VOUCHER_INHERITANCE_ALWAYS, COL_VALUE).Value = DEFAULT_VOUCHER_INHERITANCE_ALWAYS
    ws.Cells(ROW_VOUCHER_UNKNOWNS, COL_VALUE).Value = DEFAULT_VOUCHER_UNKNOWNS
    ws.Cells(ROW_EXCLUDE_SUMMARY_KEYWORDS, COL_VALUE).Value = DEFAULT_EXCLUDE_SUMMARY_KEYWORDS
    ws.Cells(ROW_STOP_IF_TOO_BROAD, COL_VALUE).Value = DEFAULT_STOP_IF_TOO_BROAD
    ws.Cells(ROW_INHERITANCE_FOCUS_YEARS, COL_VALUE).Value = DEFAULT_INHERITANCE_FOCUS_YEARS
    ws.Cells(ROW_MIN_SCORE, COL_VALUE).Value = DEFAULT_MIN_SCORE
    ws.Cells(ROW_CONTEXT_SCORE, COL_VALUE).Value = DEFAULT_CONTEXT_SCORE
    ProtectMainSheet
    On Error GoTo 0
End Sub

Public Sub ProtectMainSheet()
    Dim ws As Worksheet
    Set ws = GetSheet(SH_MAIN)
    On Error Resume Next
    ws.Unprotect Password:=TOOL_PASSWORD
    ws.Cells.Locked = True
    ws.Range("E6:E19").Locked = False
    ws.Range("E21:E36").Locked = False
    ProtectSheetLight ws
    ApplyAnalysisMainViewport ws
    On Error GoTo 0
End Sub

Public Sub ApplyAnalysisMainViewport(Optional ByVal ws As Worksheet = Nothing)
    Dim win As Window
    If ws Is Nothing Then Set ws = GetSheet(SH_MAIN)
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    ws.ScrollArea = "A1:O50"
    If ActiveWorkbook Is Nothing Then Exit Sub
    If ActiveWorkbook.Name <> ThisWorkbook.Name Then Exit Sub
    If ActiveSheet Is Nothing Then Exit Sub
    If ActiveSheet.Name <> ws.Name Then Exit Sub
    Set win = ActiveWindow
    If win Is Nothing Then Exit Sub
    win.DisplayGridlines = False
    If win.Zoom <> 94 Then win.Zoom = 94
    On Error GoTo 0
End Sub

Public Sub HideDailySheets(Optional ByVal showMessage As Boolean = True)
    Dim arr As Variant, i As Long
    arr = Array(SH_RESULT, SH_DETAIL, SH_FLAGGED, SH_ISSUE, SH_CHECK)
    On Error Resume Next
    For i = LBound(arr) To UBound(arr)
        If SheetExists(CStr(arr(i))) Then ThisWorkbook.Worksheets(CStr(arr(i))).Visible = xlSheetHidden
    Next i
    If SheetExists(SH_MAIN) Then GetSheet(SH_MAIN).Visible = xlSheetVisible: GetSheet(SH_MAIN).Activate
    If showMessage Then MsgBox "通常表示に戻しました。分析入力のみ表示します。", vbInformation
    On Error GoTo 0
End Sub

Public Sub ShowOutputSheets()
    Dim arr As Variant, i As Long
    arr = Array(SH_RESULT, SH_DETAIL, SH_FLAGGED, SH_ISSUE, SH_CHECK)
    On Error Resume Next
    For i = LBound(arr) To UBound(arr)
        If SheetExists(CStr(arr(i))) Then ThisWorkbook.Worksheets(CStr(arr(i))).Visible = xlSheetVisible
    Next i
    If SheetExists(SH_RESULT) Then GetSheet(SH_RESULT).Activate
    On Error GoTo 0
End Sub

Public Sub HideWorkSheets()
    Dim arr As Variant, i As Long
    arr = Array(SH_LOG, SH_WORK_PERSON, SH_WORK_REL, SH_WORK_ACCOUNT, SH_WORK_TX, SH_WORK_COHAB, SH_WORK_ADDRESS, SH_WORK_RESULT, SH_WORK_DETAIL, SH_WORK_ID, SH_MANUAL_EXCLUDE, SH_MANUAL_STATE)
    On Error Resume Next
    For i = LBound(arr) To UBound(arr)
        If SheetExists(CStr(arr(i))) Then ThisWorkbook.Worksheets(CStr(arr(i))).Visible = xlSheetVeryHidden
    Next i
    On Error GoTo 0
End Sub

Attribute VB_Name = "modDataLoad"
Option Explicit

Public Sub LoadCommonData()
    Dim p As String, wb As Workbook
    If Not RequireSavedWorkbook() Then Exit Sub
    p = CommonDataPath()
    If Dir$(p) = "" Then
        MsgBox "00_共通データ.xlsx が見つかりません。" & vbCrLf & p, vbExclamation
        AppendLog "共通データ読込", "失敗", "ファイルなし: " & p
        Exit Sub
    End If

    On Error GoTo EH
    AppBegin "共通データを読み込み中..."
    Set wb = Workbooks.Open(Filename:=p, ReadOnly:=True, UpdateLinks:=False, IgnoreReadOnlyRecommended:=True, Notify:=False, AddToMru:=False)

    CopySheetData wb, "T_人物", GetSheet(SH_WORK_PERSON)
    CopySheetData wb, "T_関係", GetSheet(SH_WORK_REL), True
    CopySheetData wb, "T_口座", GetSheet(SH_WORK_ACCOUNT)
    CopySheetData wb, "T_取引", GetSheet(SH_WORK_TX)
    CopySheetData wb, "T_同居推定", GetSheet(SH_WORK_COHAB), True
    CopySheetData wb, "T_住所履歴", GetSheet(SH_WORK_ADDRESS), True

    ReadCommonSettings wb
    wb.Close SaveChanges:=False
    UpdateMainStatus
    AppEnd
    AppendLog "共通データ読込", "成功", p
    MsgBox "共通データを読み込みました。" & vbCrLf & _
           "取引件数: " & CStr(Application.Max(0, LastRow(GetSheet(SH_WORK_TX), 1) - 1)), vbInformation
    Exit Sub
EH:
    On Error Resume Next
    If Not wb Is Nothing Then wb.Close SaveChanges:=False
    AppEnd
    AppendLog "共通データ読込", "失敗", Err.Description
    MsgBox "共通データ読込でエラーが発生しました。" & vbCrLf & Err.Description, vbExclamation
End Sub

Private Sub CopySheetData(ByVal wb As Workbook, ByVal srcName As String, ByVal dst As Worksheet, Optional ByVal allowMissing As Boolean = False)
    Dim src As Worksheet, lastR As Long, lastC As Long
    On Error Resume Next
    Set src = wb.Worksheets(srcName)
    On Error GoTo 0
    dst.Cells.Clear
    If src Is Nothing Then
        If allowMissing Then
            dst.Range("A1").Value = srcName & "なし"
            Exit Sub
        Else
            Err.Raise vbObjectError + 9101, "CopySheetData", srcName & " シートが共通データにありません。"
        End If
    End If
    lastR = LastUsedRowInSheet(src)
    lastC = LastUsedColumn(src)
    If lastR < 1 Or lastC < 1 Then Exit Sub
    dst.Range(dst.Cells(1, 1), dst.Cells(lastR, lastC)).Value = src.Range(src.Cells(1, 1), src.Cells(lastR, lastC)).Value
    FormatHeader dst.Range(dst.Cells(1, 1), dst.Cells(1, lastC))
    AutoFitSheetSmart dst, "A:" & ColumnLetter(lastC), 6, 34
End Sub

Private Sub ReadCommonSettings(ByVal wb As Workbook)
    Dim inhDate As Variant, decedentId As String
    inhDate = FindSettingValue(wb, Array("T_連携設定", "T_設定", "T_資金連携設定"), "相続開始日")
    decedentId = CellText(FindSettingValue(wb, Array("T_連携設定", "T_設定"), "被相続人人物ID"))
    If Len(decedentId) = 0 Then decedentId = FindDecedentIdFromPersons()

    With GetSheet(SH_MAIN)
        On Error Resume Next
        .Unprotect Password:=TOOL_PASSWORD
        If IsDate(inhDate) Then .Cells(ROW_INHERITANCE_DATE, COL_VALUE).Value = CDate(inhDate)
        If Len(decedentId) > 0 Then .Cells(ROW_DECEDENT_ID, COL_VALUE).Value = decedentId
        ProtectMainSheet
        On Error GoTo 0
    End With
End Sub

Private Function FindSettingValue(ByVal wb As Workbook, ByVal sheetNames As Variant, ByVal keyText As String) As Variant
    Dim i As Long, ws As Worksheet, r As Long, c As Long, lastR As Long, lastC As Long
    For i = LBound(sheetNames) To UBound(sheetNames)
        Set ws = Nothing
        On Error Resume Next
        Set ws = wb.Worksheets(CStr(sheetNames(i)))
        On Error GoTo 0
        If Not ws Is Nothing Then
            lastR = LastUsedRowInSheet(ws)
            lastC = LastUsedColumn(ws)
            For r = 1 To lastR
                For c = 1 To lastC
                    If CellText(ws.Cells(r, c).Value) = keyText Then
                        If c < lastC Then
                            FindSettingValue = ws.Cells(r, c + 1).Value
                            Exit Function
                        End If
                    End If
                Next c
            Next r
        End If
    Next i
End Function

Private Function FindDecedentIdFromPersons() As String
    Dim ws As Worksheet, lastR As Long, r As Long
    Dim colId As Long, colType As Long, colRel As Long
    If Not SheetExists(SH_WORK_PERSON) Then Exit Function
    Set ws = GetSheet(SH_WORK_PERSON)
    colId = FirstHeaderColumn(ws, Array("人物ID"), 1)
    colType = FirstHeaderColumn(ws, Array("人物区分", "区分"), 1)
    colRel = FirstHeaderColumn(ws, Array("被相続人から見た続柄", "続柄", "表示用続柄"), 1)
    If colId = 0 Then Exit Function
    lastR = LastRow(ws, colId)
    For r = 2 To lastR
        If (colType > 0 And InStr(CellText(ws.Cells(r, colType).Value), "被相続人") > 0) Or _
           (colRel > 0 And InStr(CellText(ws.Cells(r, colRel).Value), "被相続人") > 0) Then
            FindDecedentIdFromPersons = CellText(ws.Cells(r, colId).Value)
            Exit Function
        End If
    Next r
End Function

Private Sub UpdateMainStatus()
    Dim ws As Worksheet, txCount As Long, personCount As Long, accCount As Long
    Set ws = GetSheet(SH_MAIN)
    txCount = Application.Max(0, LastRow(GetSheet(SH_WORK_TX), 1) - 1)
    personCount = Application.Max(0, LastRow(GetSheet(SH_WORK_PERSON), 1) - 1)
    accCount = Application.Max(0, LastRow(GetSheet(SH_WORK_ACCOUNT), 1) - 1)
    On Error Resume Next
    ws.Unprotect Password:=TOOL_PASSWORD
    ws.Range("B46:J49").ClearContents
    ws.Range("B46:J46").Merge
    ws.Range("B46").Value = "読込状況"
    ws.Range("B46").Interior.Color = ThemeColor("title")
    ws.Range("B46").Font.Color = vbWhite
    ws.Range("B46").Font.Bold = True
    SetRowValues ws.Range("B47"), Array("人物", personCount, "口座", accCount, "取引", txCount, "最終読込", Now)
    ws.Range("B47:I47").Interior.Color = ThemeColor("canvas")
    ws.Range("I47").NumberFormatLocal = "yyyy/m/d h:mm"
    ProtectMainSheet
    On Error GoTo 0
End Sub

Public Sub CheckAnalysisReadiness()
    Dim wsC As Worksheet, outR As Long
    Dim wsT As Worksheet, lastR As Long
    Set wsC = GetSheet(SH_CHECK)
    wsC.Cells.Clear
    SetRowValues wsC.Range("A1"), Array("区分", "内容", "対応")
    FormatHeader wsC.Range("A1:C1"), ThemeColor("red")
    outR = 2

    If Len(ThisWorkbook.Path) = 0 Then AddCheck wsC, outR, "エラー", "分析ツールが案件フォルダに保存されていません。", "先に xlsm として案件フォルダへ保存してください。"
    If Dir$(CommonDataPath()) = "" Then AddCheck wsC, outR, "エラー", "00_共通データ.xlsx が見つかりません。", "人物情報系・資金操作表系の共通保存を先に実行してください。"

    If Not SheetExists(SH_WORK_TX) Then
        AddCheck wsC, outR, "エラー", "取引データが読み込まれていません。", "共通データ読込を実行してください。"
    Else
        Set wsT = GetSheet(SH_WORK_TX)
        lastR = LastRow(wsT, 1)
        If lastR < 2 Then AddCheck wsC, outR, "エラー", "T_取引 が空です。", "資金操作表作成補助ツールで共通データ保存を実行してください。"
        If HeaderColumn(wsT, "取引ID") = 0 Then AddCheck wsC, outR, "エラー", "T_取引 に取引ID列がありません。", "資金操作表ツールの連携版で保存してください。"
        If HeaderColumn(wsT, "日付") = 0 Then AddCheck wsC, outR, "エラー", "T_取引 に日付列がありません。", "共通データの形式を確認してください。"
        If HeaderColumn(wsT, "出金") = 0 Then AddCheck wsC, outR, "エラー", "T_取引 に出金列がありません。", "共通データの形式を確認してください。"
        If HeaderColumn(wsT, "入金") = 0 Then AddCheck wsC, outR, "エラー", "T_取引 に入金列がありません。", "共通データの形式を確認してください。"
        If HeaderColumn(wsT, "時刻") = 0 Then AddCheck wsC, outR, "警告", "T_取引 に時刻列がありません。", "同日内の出金→入金順序を時刻で判定できません。02ツールで共通データ保存を再実行してください。"
        If HeaderColumn(wsT, "取扱店確定値") = 0 Then AddCheck wsC, outR, "警告", "T_取引 に取扱店確定値列がありません。", "旧形式の共通データです。02ツールで共通データ保存を再実行してください。"
        If HeaderColumn(wsT, "取引後残高") = 0 Then AddCheck wsC, outR, "情報", "T_取引 に取引後残高列がありません。", "外部資金操作表13列目残高を使った残高急変分析は、その他欄からの後方互換判定になります。"
    End If

    If Not IsDate(GetSheet(SH_MAIN).Cells(ROW_INHERITANCE_DATE, COL_VALUE).Value) Then AddCheck wsC, outR, "警告", "相続開始日が未設定です。", "相続関連シフト判定ができません。人物情報系ツールから相続開始日を連携してください。"
    If Len(CellText(GetSheet(SH_MAIN).Cells(ROW_DECEDENT_ID, COL_VALUE).Value)) = 0 Then AddCheck wsC, outR, "警告", "被相続人人物IDが未設定です。", "相続関連シフト判定ができません。人物情報系ツールから被相続人IDを連携してください。"

    If outR = 2 Then
        AddCheck wsC, outR, "OK", "分析実行可能です。", "分析実行を押してください。"
    End If
    FormatBody wsC.Range("A2:C" & CStr(Application.Max(2, outR - 1)))
    AutoFitSheetSmart wsC, "A:C", 8, 60
    wsC.Visible = xlSheetVisible
    wsC.Activate
End Sub

Private Sub AddCheck(ByVal ws As Worksheet, ByRef outR As Long, ByVal kindText As String, ByVal contentText As String, ByVal actionText As String)
    ws.Cells(outR, 1).Value = kindText
    ws.Cells(outR, 2).Value = contentText
    ws.Cells(outR, 3).Value = actionText
    Select Case kindText
        Case "エラー": ws.Range(ws.Cells(outR, 1), ws.Cells(outR, 3)).Interior.Color = ThemeColor("danger-soft")
        Case "警告": ws.Range(ws.Cells(outR, 1), ws.Cells(outR, 3)).Interior.Color = ThemeColor("warning-soft")
        Case Else: ws.Range(ws.Cells(outR, 1), ws.Cells(outR, 3)).Interior.Color = ThemeColor("success-bg")
    End Select
    outR = outR + 1
End Sub

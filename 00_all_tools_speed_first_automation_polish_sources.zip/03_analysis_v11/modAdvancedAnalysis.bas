Attribute VB_Name = "modAdvancedAnalysis"
Option Explicit

Private Const ADV_VIEW_FIRST_DATA_ROW As Long = 8
Private Const ADV_VIEW_COL_ID As Long = 1
Private Const ADV_VIEW_COL_KIND As Long = 2
Private Const ADV_PATTERN As String = "不明出金追跡"
Private Const ADV_MAX_DAYS As Long = 365
Private Const ADV_MAX_CANDIDATES As Long = 80
Private Const ADV_MAX_COMBO As Long = 8
Private Const ADV_MAX_OUTPUT As Long = 100

Public Sub TraceSelectedUnknownOutToLaterUnknownIns()
    Dim wsView As Worksheet, activeRow As Long, sourceAnalysisId As String, sourceKind As String
    Dim source As Object, ins As Collection, combos As Collection, i As Long, added As Long, skipped As Long
    Dim tol As Double

    If Not SheetExists(SH_RESULT) Or Not SheetExists(SH_WORK_RESULT) Or Not SheetExists(SH_WORK_DETAIL) Then
        MsgBox "先に通常の分析を実行してください。", vbExclamation
        Exit Sub
    End If
    If ActiveSheet.Name <> SH_RESULT Then
        MsgBox "分析結果シートで、不明出金の行を選択してから実行してください。", vbExclamation
        Exit Sub
    End If

    Set wsView = GetSheet(SH_RESULT)
    activeRow = ActiveCell.Row
    If activeRow < ADV_VIEW_FIRST_DATA_ROW Then
        MsgBox "不明出金の明細行を選択してください。", vbExclamation
        Exit Sub
    End If

    sourceAnalysisId = CellText(wsView.Cells(activeRow, ADV_VIEW_COL_ID).Value)
    sourceKind = CellText(wsView.Cells(activeRow, ADV_VIEW_COL_KIND).Value)
    If Len(sourceAnalysisId) = 0 Or sourceKind <> KIND_UNKNOWN_OUT Then
        MsgBox "この追跡分析は、不明出金の行を選択して実行します。", vbExclamation
        Exit Sub
    End If

    On Error GoTo EH
    AppBegin "不明出金追跡分析中..."
    PersistManualStateFromResultSheet True

    Set source = DetailRecordForAnalysis(sourceAnalysisId, "出金")
    If source Is Nothing Then Err.Raise vbObjectError + 9701, "TraceSelectedUnknownOutToLaterUnknownIns", "選択した不明出金の明細を取得できません。"

    Set ins = LaterUnknownInRecords(CDate(source("Date")), CStr(source("TxId")), ADV_MAX_DAYS, ADV_MAX_CANDIDATES)
    If ins.Count = 0 Then
        AppEnd
        MsgBox "選択した不明出金以降に照合できる不明入金がありません。", vbInformation
        Exit Sub
    End If

    tol = AdvancedEffectiveTolerance(CDbl(source("Amount")))
    Set combos = BuildAdvancedCombosNearAmount(ins, CDbl(source("Amount")), tol, Application.Min(ADV_MAX_COMBO, ins.Count), ADV_MAX_OUTPUT)

    For i = 1 To combos.Count
        If AppendAdvancedFollowupCandidate(source, combos(i), tol) Then
            added = added + 1
        Else
            skipped = skipped + 1
        End If
    Next i

    BuildAnalysisResultSheet
    BuildDetailOutputSheet
    BuildInvestigationIssueSheet True
    BuildFlaggedTransactionSheet
    If SettingYes(ROW_AUTO_SAVE_COMMON, True) Then SaveAnalysisToCommonData True
    AppEnd

    If added = 0 Then
        MsgBox "金額合計が一致する後日不明入金候補は見つかりましたが、既存候補と重複していたため追加しませんでした。", vbInformation
    Else
        MsgBox "不明出金追跡候補を " & CStr(added) & " 件追加しました。" & IIf(skipped > 0, vbCrLf & "重複除外: " & CStr(skipped) & " 件", ""), vbInformation
    End If
    Exit Sub
EH:
    AppEnd
    MsgBox "不明出金追跡分析中にエラーが発生しました。" & vbCrLf & Err.Description, vbExclamation
End Sub

Private Function DetailRecordForAnalysis(ByVal analysisId As String, ByVal sideText As String) As Object
    Dim ws As Worksheet, lastR As Long, r As Long
    Set ws = GetSheet(SH_WORK_DETAIL)
    lastR = LastRow(ws, DET_COL_ID)
    For r = 2 To lastR
        If CellText(ws.Cells(r, DET_COL_ANALYSIS_ID).Value) = analysisId And CellText(ws.Cells(r, DET_COL_SIDE).Value) = sideText Then
            Set DetailRecordForAnalysis = DetailRecordFromRow(ws, r)
            Exit Function
        End If
    Next r
End Function

Private Function DetailRecordFromRow(ByVal ws As Worksheet, ByVal r As Long) As Object
    Dim d As Object
    Set d = CreateObject("Scripting.Dictionary")
    d("Row") = r
    d("AnalysisId") = CellText(ws.Cells(r, DET_COL_ANALYSIS_ID).Value)
    d("TxId") = CellText(ws.Cells(r, DET_COL_TX_ID).Value)
    d("Date") = ws.Cells(r, DET_COL_DATE).Value
    d("Amount") = NzDbl(ws.Cells(r, DET_COL_AMOUNT).Value, 0)
    d("PersonId") = CellText(ws.Cells(r, DET_COL_PERSON_ID).Value)
    d("Person") = CellText(ws.Cells(r, DET_COL_PERSON_NAME).Value)
    d("AccountId") = CellText(ws.Cells(r, DET_COL_ACCOUNT_ID).Value)
    d("Bank") = CellText(ws.Cells(r, DET_COL_BANK).Value)
    d("Branch") = CellText(ws.Cells(r, DET_COL_BRANCH).Value)
    d("AccountType") = CellText(ws.Cells(r, DET_COL_ACCOUNT_TYPE).Value)
    d("AccountNo") = CellText(ws.Cells(r, DET_COL_ACCOUNT_NO).Value)
    d("Shop") = CellText(ws.Cells(r, DET_COL_SHOP).Value)
    d("Summary") = CellText(ws.Cells(r, DET_COL_SUMMARY).Value)
    Set DetailRecordFromRow = d
End Function

Private Function LaterUnknownInRecords(ByVal baseDate As Date, ByVal sourceTxId As String, ByVal maxDays As Long, ByVal limitCount As Long) As Collection
    Dim result As New Collection, wsRes As Worksheet, wsDet As Worksheet
    Dim lastR As Long, r As Long, analysisId As String, rec As Object, d As Long
    Set wsRes = GetSheet(SH_WORK_RESULT)
    Set wsDet = GetSheet(SH_WORK_DETAIL)
    lastR = LastRow(wsRes, RES_COL_ID)
    For r = 2 To lastR
        If CellText(wsRes.Cells(r, RES_COL_KIND).Value) = KIND_UNKNOWN_IN And Not IsExcludeDecision(CellText(wsRes.Cells(r, RES_COL_SHIFT_DECISION).Value)) Then
            analysisId = CellText(wsRes.Cells(r, RES_COL_ID).Value)
            Set rec = DetailRecordForAnalysis(analysisId, "入金")
            If Not rec Is Nothing Then
                If CStr(rec("TxId")) <> sourceTxId And IsDate(rec("Date")) Then
                    d = DateDiff("d", baseDate, CDate(rec("Date")))
                    If d >= 0 And d <= maxDays Then
                        result.Add rec
                        If result.Count >= limitCount Then Exit For
                    End If
                End If
            End If
        End If
    Next r
    Set LaterUnknownInRecords = SortAdvancedRecordsByDate(result)
End Function

Private Function SortAdvancedRecordsByDate(ByVal records As Collection) As Collection
    Dim out As New Collection, rec As Object, i As Long, inserted As Boolean
    For Each rec In records
        inserted = False
        For i = 1 To out.Count
            If AdvancedRecordSortKey(rec) < AdvancedRecordSortKey(out(i)) Then
                out.Add rec, , i
                inserted = True
                Exit For
            End If
        Next i
        If Not inserted Then out.Add rec
    Next rec
    Set SortAdvancedRecordsByDate = out
End Function

Private Function AdvancedRecordSortKey(ByVal rec As Object) As Double
    If rec Is Nothing Then Exit Function
    If IsDate(rec("Date")) Then AdvancedRecordSortKey = CDbl(CDate(rec("Date"))) * 1000000#
    AdvancedRecordSortKey = AdvancedRecordSortKey + CDbl(rec("Amount")) / 1000000000000#
End Function

Private Function AdvancedEffectiveTolerance(ByVal targetAmount As Double) As Double
    Dim amountTol As Double, rateTol As Double
    amountTol = GetSettingDouble(ROW_AMOUNT_TOLERANCE, DEFAULT_AMOUNT_TOLERANCE)
    rateTol = NzDbl(GetSheet(SH_MAIN).Cells(ROW_AMOUNT_TOLERANCE_RATE, COL_VALUE).Value, DEFAULT_AMOUNT_TOLERANCE_RATE)
    AdvancedEffectiveTolerance = amountTol
    If rateTol > 0 Then AdvancedEffectiveTolerance = Application.Max(AdvancedEffectiveTolerance, targetAmount * rateTol)
End Function

Private Function BuildAdvancedCombosNearAmount(ByVal records As Collection, ByVal targetAmount As Double, ByVal tol As Double, ByVal maxDepth As Long, ByVal maxOutput As Long) As Collection
    Dim result As New Collection, tmp As New Collection, depth As Long
    If records Is Nothing Then Set BuildAdvancedCombosNearAmount = result: Exit Function
    If records.Count = 0 Then Set BuildAdvancedCombosNearAmount = result: Exit Function
    For depth = 1 To Application.Min(maxDepth, records.Count)
        BuildAdvancedCombosRec records, 1, depth, tmp, result, targetAmount, tol, maxOutput, 0#
        If result.Count >= maxOutput Then Exit For
    Next depth
    Set BuildAdvancedCombosNearAmount = result
End Function

Private Sub BuildAdvancedCombosRec(ByVal records As Collection, ByVal startIdx As Long, ByVal targetDepth As Long, ByVal tmp As Collection, ByVal result As Collection, ByVal targetAmount As Double, ByVal tol As Double, ByVal maxOutput As Long, ByVal currentSum As Double)
    Dim i As Long, amt As Double
    If result.Count >= maxOutput Then Exit Sub
    If currentSum > targetAmount + tol Then Exit Sub
    If tmp.Count = targetDepth Then
        If Abs(currentSum - targetAmount) <= tol Then result.Add AdvancedComboObject(tmp, currentSum)
        Exit Sub
    End If
    For i = startIdx To records.Count
        amt = CDbl(records(i)("Amount"))
        If amt > 0 Then
            tmp.Add records(i)
            BuildAdvancedCombosRec records, i + 1, targetDepth, tmp, result, targetAmount, tol, maxOutput, currentSum + amt
            tmp.Remove tmp.Count
            If result.Count >= maxOutput Then Exit For
        End If
    Next i
End Sub

Private Function AdvancedComboObject(ByVal recs As Collection, ByVal sumAmount As Double) As Object
    Dim d As Object, copy As New Collection, rec As Object
    Set d = CreateObject("Scripting.Dictionary")
    For Each rec In recs
        copy.Add rec
    Next rec
    d("Records") = copy
    d("Sum") = sumAmount
    d("Ids") = SortedAdvancedIds(copy)
    Set AdvancedComboObject = d
End Function

Private Function AppendAdvancedFollowupCandidate(ByVal source As Object, ByVal combo As Object, ByVal tol As Double) As Boolean
    Dim wsRes As Worksheet, analysisId As String, outIds As String, inIds As String, stateKey As String
    Dim r As Long, inRecords As Collection, score As Long, diff As Double
    Set wsRes = GetSheet(SH_WORK_RESULT)
    Set inRecords = combo("Records")
    outIds = CStr(source("TxId"))
    inIds = CStr(combo("Ids"))
    stateKey = BuildAnalysisStateKey(ADV_PATTERN, outIds, inIds)
    If AdvancedResultExists(stateKey, ADV_PATTERN, outIds, inIds) Then Exit Function

    analysisId = NextId("分析候補")
    diff = CDbl(source("Amount")) - CDbl(combo("Sum"))
    score = AdvancedFollowupScore(source, inRecords, diff, tol)
    r = LastRow(wsRes, RES_COL_ID) + 1
    If r < 2 Then r = 2
    wsRes.Cells(r, RES_COL_ID).Value = analysisId
    wsRes.Cells(r, RES_COL_KIND).Value = KIND_SHIFT
    wsRes.Cells(r, RES_COL_PATTERN).Value = ADV_PATTERN
    wsRes.Cells(r, RES_COL_SCORE).Value = score
    wsRes.Cells(r, RES_COL_VOUCHER).Value = VOUCHER_YES
    wsRes.Cells(r, RES_COL_OUT_DATE).Value = FormatAdvancedDate(source("Date"))
    wsRes.Cells(r, RES_COL_IN_DATE).Value = AdvancedDateRangeText(inRecords)
    wsRes.Cells(r, RES_COL_OUT_AMOUNT).Value = CDbl(source("Amount"))
    wsRes.Cells(r, RES_COL_IN_AMOUNT).Value = CDbl(combo("Sum"))
    wsRes.Cells(r, RES_COL_DIFF).Value = diff
    wsRes.Cells(r, RES_COL_OUT_PERSON).Value = CStr(source("Person"))
    wsRes.Cells(r, RES_COL_IN_PERSON).Value = AdvancedPersonList(inRecords)
    wsRes.Cells(r, RES_COL_NAME_REL).Value = "後日分割入金候補"
    wsRes.Cells(r, RES_COL_INH_TIMING).Value = "不明出金追跡"
    wsRes.Cells(r, RES_COL_COHAB).Value = "通常分析後の選択実行"
    wsRes.Cells(r, RES_COL_OUT_IDS).Value = outIds
    wsRes.Cells(r, RES_COL_IN_IDS).Value = inIds
    wsRes.Cells(r, RES_COL_SHOPS).Value = AdvancedShopList(source, inRecords)
    wsRes.Cells(r, RES_COL_SUMMARY).Value = "不明出金後の不明入金合計が一致。手渡し後に時期をずらして入金した可能性を確認。"
    wsRes.Cells(r, RES_COL_MEMO).Value = "差額 " & Format$(diff, "#,##0")
    wsRes.Cells(r, RES_COL_SHIFT_DECISION).Value = DECISION_USE
    wsRes.Cells(r, RES_COL_OPERATION_MEMO).Value = "選択不明出金から後日不明入金を追跡。伝票依頼・採否は確認してください。"
    wsRes.Cells(r, RES_COL_AGE_HINT).Value = ""
    wsRes.Cells(r, RES_COL_ADDRESS_HINT).Value = ""

    AppendAdvancedDetailRow analysisId, "出金", source, KIND_SHIFT, VOUCHER_YES
    AppendAdvancedInputDetails analysisId, inRecords
    AppendLog "不明出金追跡", "候補追加", outIds & " -> " & inIds
    AppendAdvancedFollowupCandidate = True
End Function

Private Function AdvancedResultExists(ByVal stateKey As String, ByVal patternText As String, ByVal outIds As String, ByVal inIds As String) As Boolean
    Dim ws As Worksheet, lastR As Long, r As Long, k As String
    Set ws = GetSheet(SH_WORK_RESULT)
    lastR = LastRow(ws, RES_COL_ID)
    For r = 2 To lastR
        k = BuildAnalysisStateKey(CellText(ws.Cells(r, RES_COL_PATTERN).Value), CellText(ws.Cells(r, RES_COL_OUT_IDS).Value), CellText(ws.Cells(r, RES_COL_IN_IDS).Value))
        If k = stateKey Then AdvancedResultExists = True: Exit Function
    Next r
End Function

Private Sub AppendAdvancedInputDetails(ByVal analysisId As String, ByVal recs As Collection)
    Dim rec As Object
    For Each rec In recs
        AppendAdvancedDetailRow analysisId, "入金", rec, KIND_SHIFT, VOUCHER_YES
    Next rec
End Sub

Private Sub AppendAdvancedDetailRow(ByVal analysisId As String, ByVal sideText As String, ByVal rec As Object, ByVal kindText As String, ByVal voucherText As String)
    Dim ws As Worksheet, outR As Long
    Set ws = GetSheet(SH_WORK_DETAIL)
    outR = LastRow(ws, DET_COL_ID) + 1
    If outR < 2 Then outR = 2
    ws.Cells(outR, DET_COL_ID).Value = NextId("分析明細")
    ws.Cells(outR, DET_COL_ANALYSIS_ID).Value = analysisId
    ws.Cells(outR, DET_COL_SIDE).Value = sideText
    ws.Cells(outR, DET_COL_TX_ID).Value = rec("TxId")
    ws.Cells(outR, DET_COL_DATE).Value = rec("Date")
    ws.Cells(outR, DET_COL_AMOUNT).Value = rec("Amount")
    ws.Cells(outR, DET_COL_PERSON_ID).Value = rec("PersonId")
    ws.Cells(outR, DET_COL_PERSON_NAME).Value = rec("Person")
    ws.Cells(outR, DET_COL_ACCOUNT_ID).Value = rec("AccountId")
    ws.Cells(outR, DET_COL_BANK).Value = rec("Bank")
    ws.Cells(outR, DET_COL_BRANCH).Value = rec("Branch")
    ws.Cells(outR, DET_COL_ACCOUNT_TYPE).Value = rec("AccountType")
    ws.Cells(outR, DET_COL_ACCOUNT_NO).Value = rec("AccountNo")
    ws.Cells(outR, DET_COL_SHOP).Value = rec("Shop")
    ws.Cells(outR, DET_COL_SUMMARY).Value = rec("Summary")
    ws.Cells(outR, DET_COL_KIND).Value = kindText
    ws.Cells(outR, DET_COL_VOUCHER).Value = voucherText
End Sub

Private Function AdvancedFollowupScore(ByVal source As Object, ByVal ins As Collection, ByVal diff As Double, ByVal tol As Double) As Long
    Dim minDate As Date, daysGap As Long
    AdvancedFollowupScore = 68
    If Abs(diff) = 0 Then
        AdvancedFollowupScore = AdvancedFollowupScore + 18
    ElseIf Abs(diff) <= tol Then
        AdvancedFollowupScore = AdvancedFollowupScore + 10
    End If
    minDate = EarliestAdvancedDate(ins)
    If IsDate(source("Date")) And minDate <> 0 Then
        daysGap = DateDiff("d", CDate(source("Date")), minDate)
        If daysGap <= 7 Then
            AdvancedFollowupScore = AdvancedFollowupScore + 8
        ElseIf daysGap <= 30 Then
            AdvancedFollowupScore = AdvancedFollowupScore + 5
        ElseIf daysGap <= 90 Then
            AdvancedFollowupScore = AdvancedFollowupScore + 2
        End If
    End If
    If ins.Count > 3 Then AdvancedFollowupScore = AdvancedFollowupScore - Application.Min(10, (ins.Count - 3) * 2)
    If AdvancedFollowupScore > 100 Then AdvancedFollowupScore = 100
    If AdvancedFollowupScore < 0 Then AdvancedFollowupScore = 0
End Function

Private Function EarliestAdvancedDate(ByVal recs As Collection) As Date
    Dim rec As Object
    For Each rec In recs
        If IsDate(rec("Date")) Then
            If EarliestAdvancedDate = 0 Or CDate(rec("Date")) < EarliestAdvancedDate Then EarliestAdvancedDate = CDate(rec("Date"))
        End If
    Next rec
End Function

Private Function AdvancedDateRangeText(ByVal recs As Collection) As String
    Dim minD As Date, maxD As Date, rec As Object
    For Each rec In recs
        If IsDate(rec("Date")) Then
            If minD = 0 Or CDate(rec("Date")) < minD Then minD = CDate(rec("Date"))
            If maxD = 0 Or CDate(rec("Date")) > maxD Then maxD = CDate(rec("Date"))
        End If
    Next rec
    If minD = 0 Then Exit Function
    If minD = maxD Then AdvancedDateRangeText = Format$(minD, "yyyy/m/d") Else AdvancedDateRangeText = Format$(minD, "yyyy/m/d") & "～" & Format$(maxD, "yyyy/m/d")
End Function

Private Function FormatAdvancedDate(ByVal v As Variant) As String
    If IsDate(v) Then FormatAdvancedDate = Format$(CDate(v), "yyyy/m/d") Else FormatAdvancedDate = CellText(v)
End Function

Private Function AdvancedPersonList(ByVal recs As Collection) As String
    Dim d As Object, rec As Object, k As Variant
    Set d = CreateObject("Scripting.Dictionary")
    For Each rec In recs
        If Len(CStr(rec("Person"))) > 0 Then d(CStr(rec("Person"))) = True
    Next rec
    For Each k In d.Keys
        AdvancedPersonList = JoinNonBlank(AdvancedPersonList, CStr(k), " / ")
    Next k
End Function

Private Function AdvancedShopList(ByVal source As Object, ByVal recs As Collection) As String
    Dim d As Object, rec As Object, k As Variant, s As String
    Set d = CreateObject("Scripting.Dictionary")
    s = CStr(source("Bank")) & " " & CStr(source("Shop"))
    If Len(Trim$(s)) > 0 Then d(s) = True
    For Each rec In recs
        s = CStr(rec("Bank")) & " " & CStr(rec("Shop"))
        If Len(Trim$(s)) > 0 Then d(s) = True
    Next rec
    For Each k In d.Keys
        AdvancedShopList = JoinNonBlank(AdvancedShopList, CStr(k), " / ")
    Next k
End Function

Private Function SortedAdvancedIds(ByVal recs As Collection) As String
    Dim arr() As String, i As Long, j As Long, tmp As String, rec As Object
    If recs Is Nothing Then Exit Function
    If recs.Count = 0 Then Exit Function
    ReDim arr(1 To recs.Count)
    i = 1
    For Each rec In recs
        arr(i) = CStr(rec("TxId"))
        i = i + 1
    Next rec
    For i = LBound(arr) To UBound(arr) - 1
        For j = i + 1 To UBound(arr)
            If arr(j) < arr(i) Then tmp = arr(i): arr(i) = arr(j): arr(j) = tmp
        Next j
    Next i
    For i = LBound(arr) To UBound(arr)
        SortedAdvancedIds = JoinNonBlank(SortedAdvancedIds, arr(i), ",")
    Next i
End Function

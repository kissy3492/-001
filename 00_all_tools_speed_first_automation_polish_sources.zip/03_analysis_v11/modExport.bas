Attribute VB_Name = "modExport"
Option Explicit

Public Sub ExportAnalysisWorkbook()
    Dim outFolder As String, outPath As String, wbNew As Workbook
    If Len(ThisWorkbook.Path) = 0 Then
        MsgBox "先にこのツールを案件フォルダへ保存してください。", vbExclamation
        Exit Sub
    End If
    If LastRow(GetSheet(SH_RESULT), 1) < 2 Then
        If MsgBox("分析結果シートが空です。先に分析実行しますか。", vbQuestion + vbYesNo) = vbYes Then RunAnalysis
    End If
    On Error GoTo EH
    AppBegin "分析結果を出力中..."
    outFolder = CombinePath(ThisWorkbook.Path, "出力")
    If Dir$(outFolder, vbDirectory) = "" Then MkDir outFolder
    outPath = CombinePath(outFolder, OUTPUT_FILE_ANALYSIS)
    If Len(Dir$(outPath)) > 0 Then
        If MsgBox("分析結果ファイルが既に存在します。バックアップを作成して上書きしますか？" & vbCrLf & outPath, vbQuestion + vbYesNo, "上書き確認") <> vbYes Then
            AppEnd
            Exit Sub
        End If
        PrepareOutputPathWithBackup outPath
    End If

    BuildAllVisibleOutputs
    ThisWorkbook.Worksheets(Array(SH_RESULT, SH_ISSUE, SH_DETAIL, SH_FLAGGED, SH_CHECK)).Copy
    Set wbNew = ActiveWorkbook
    On Error Resume Next
    wbNew.Worksheets(1).Activate
    On Error GoTo EH
    Application.DisplayAlerts = False
    wbNew.SaveAs Filename:=outPath, FileFormat:=xlOpenXMLWorkbook
    Application.DisplayAlerts = True
    wbNew.Close SaveChanges:=False
    AppEnd
    MsgBox "分析結果を出力しました。" & vbCrLf & outPath, vbInformation
    Exit Sub
EH:
    On Error Resume Next
    Application.DisplayAlerts = True
    If Not wbNew Is Nothing Then wbNew.Close SaveChanges:=False
    AppEnd
    MsgBox "出力中にエラーが発生しました。" & vbCrLf & Err.Description, vbExclamation
End Sub

Private Sub PrepareOutputPathWithBackup(ByVal filePath As String)
    Dim backupPath As String
    If Len(filePath) = 0 Then Exit Sub
    If Len(Dir$(filePath)) = 0 Then Exit Sub
    backupPath = filePath & ".bak_" & Format$(Now, "yyyymmdd_hhnnss")
    FileCopy filePath, backupPath
    Kill filePath
End Sub

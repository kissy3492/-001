Attribute VB_Name = "modAnalysisOutput"
Option Explicit

' v8: 人間が誤操作しない分析結果画面。ダブルクリック切替・メモ編集・再分析を安全化する。
' 表示列は A:M に集約し、連携・再分析に必要な生データは AA:AV に非表示保持する。
Private Const VIEW_HEADER_ROW As Long = 7
Private Const VIEW_FIRST_DATA_ROW As Long = 8
Private Const VIEW_COL_ID As Long = 1
Private Const VIEW_COL_KIND As Long = 2
Private Const VIEW_COL_VOUCHER As Long = 3
Private Const VIEW_COL_DECISION As Long = 4
Private Const VIEW_COL_PATTERN As Long = 5
Private Const VIEW_COL_AMOUNT As Long = 6
Private Const VIEW_COL_DIFF As Long = 7
Private Const VIEW_COL_DATES As Long = 8
Private Const VIEW_COL_OUT_PERSON As Long = 9
Private Const VIEW_COL_IN_PERSON As Long = 10
Private Const VIEW_COL_RELATION As Long = 11
Private Const VIEW_COL_SUMMARY As Long = 12
Private Const VIEW_COL_MEMO As Long = 13
Private Const VIEW_LAST_COL As Long = 13
Private Const RAW_START_COL As Long = 27 ' AA

Public Sub BuildAnalysisResultSheet()
    Dim src As Worksheet, dst As Worksheet
    Dim lastR As Long, viewLastR As Long, r As Long, outR As Long
    Set src = GetSheet(SH_WORK_RESULT)
    Set dst = GetSheet(SH_RESULT)

    On Error Resume Next
    dst.Unprotect Password:=TOOL_PASSWORD
    dst.ScrollArea = ""
    dst.Cells.EntireColumn.Hidden = False
    dst.Cells.UnMerge
    dst.Cells.Clear
    DeleteAllShapes dst
    On Error GoTo 0

    lastR = LastRow(src, 1)
    If lastR < 1 Then lastR = 1
    viewLastR = VIEW_HEADER_ROW + lastR - 1

    BuildResultTopArea dst
    BuildCompactHeaders dst

    ' 生データは非表示列に保持。連携保存・手動除外・再分析で使う。
    dst.Range(dst.Cells(VIEW_HEADER_ROW, RAW_START_COL), dst.Cells(viewLastR, RAW_START_COL + RES_LAST_COL - 1)).Value = _
        src.Range(src.Cells(1, 1), src.Cells(lastR, RES_LAST_COL)).Value

    If lastR >= 2 Then
        For r = 2 To lastR
            outR = VIEW_HEADER_ROW + r - 1
            WriteCompactResultRow dst, src, r, outR
        Next r
        FormatBody dst.Range(dst.Cells(VIEW_FIRST_DATA_ROW, 1), dst.Cells(viewLastR, VIEW_LAST_COL))
        dst.Range(dst.Cells(VIEW_FIRST_DATA_ROW, VIEW_COL_DIFF), dst.Cells(viewLastR, VIEW_COL_DIFF)).NumberFormatLocal = "#,##0"
        ColorResultRows dst, viewLastR
        PrepareManualEditing dst, viewLastR
        BuildResultSummaryCards dst, viewLastR
    Else
        BuildResultSummaryCards dst, VIEW_HEADER_ROW
    End If

    dst.Range(dst.Cells(VIEW_HEADER_ROW, 1), dst.Cells(viewLastR, VIEW_LAST_COL)).AutoFilter
    ApplyCompactResultLayout dst, viewLastR
    ThemeApplyPrintTable dst.Range(dst.Cells(VIEW_HEADER_ROW, 1), dst.Cells(viewLastR, VIEW_LAST_COL)), 1
    ThemeCapRowHeights dst.Range(dst.Cells(VIEW_FIRST_DATA_ROW, 1), dst.Cells(viewLastR, VIEW_LAST_COL)), 24, 84
    ThemeApplyMonochromePrint dst, dst.Range(dst.Cells(1, 1), dst.Cells(viewLastR, VIEW_LAST_COL)).Address, True, "$7:$7", 1, 0
    AddResultSheetControls dst
    ThemeMarkMacroButtonsNonPrintable dst

    dst.Activate
    ActiveWindow.FreezePanes = False
    dst.Range("A" & CStr(VIEW_FIRST_DATA_ROW)).Select
    ActiveWindow.FreezePanes = True
    ActiveWindow.Zoom = 90

    ProtectOutputSheet dst
End Sub

Private Sub BuildResultTopArea(ByVal ws As Worksheet)
    ws.Range("A1:O1").Merge
    ws.Range("A1").Value = "03_資金移動分析ツール｜分析結果"
    With ws.Range("A1")
        .Interior.Color = ThemeColor("title")
        .Font.Color = vbWhite
        .Font.Bold = True
        .Font.Size = 17
        .HorizontalAlignment = xlCenter
        .VerticalAlignment = xlCenter
    End With
    ws.Rows(1).RowHeight = 34

    ws.Range("A2:G4").Merge
    ws.Range("A2").Value = "分析結果は判断に必要な項目だけを左側に集約しています。" & vbCrLf & _
                           "C列はダブルクリックで伝票要否を切替。D列は採用→候補除外→取引除外を循環、またはドロップダウンで変更できます。M列メモは直接入力可。再分析後も同じ候補キーなら手動判断を維持します。"
    With ws.Range("A2")
        .Interior.Color = ThemeColor("section")
        .Font.Color = ThemeColor("header")
        .Font.Bold = True
        .WrapText = True
        .VerticalAlignment = xlCenter
    End With

    ws.Range("H2:I4").Merge
    ws.Range("J2:K4").Merge
    ws.Range("L2:M4").Merge
    FormatMiniCard ws.Range("H2"), "伝票依頼 要", ThemeColor("red")
    FormatMiniCard ws.Range("J2"), "除外指定", ThemeColor("muted")
    FormatMiniCard ws.Range("L2"), "候補数", ThemeColor("header")
    ws.Rows("2:4").RowHeight = 22
End Sub

Private Sub FormatMiniCard(ByVal cell As Range, ByVal titleText As String, ByVal fillColor As Long)
    cell.Value = titleText & vbCrLf & "-"
    With cell
        .Interior.Color = fillColor
        .Font.Color = vbWhite
        .Font.Bold = True
        .Font.Size = 11
        .HorizontalAlignment = xlCenter
        .VerticalAlignment = xlCenter
        .WrapText = True
    End With
End Sub

Private Sub BuildResultSummaryCards(ByVal ws As Worksheet, ByVal viewLastR As Long)
    Dim nTotal As Long, nVoucher As Long, nExclude As Long
    If viewLastR >= VIEW_FIRST_DATA_ROW Then
        nTotal = Application.WorksheetFunction.CountA(ws.Range(ws.Cells(VIEW_FIRST_DATA_ROW, VIEW_COL_ID), ws.Cells(viewLastR, VIEW_COL_ID)))
        nVoucher = Application.WorksheetFunction.CountIf(ws.Range(ws.Cells(VIEW_FIRST_DATA_ROW, VIEW_COL_VOUCHER), ws.Cells(viewLastR, VIEW_COL_VOUCHER)), VOUCHER_YES)
        Dim rr As Long
        For rr = VIEW_FIRST_DATA_ROW To viewLastR
            If IsExcludeDecision(CellText(ws.Cells(rr, VIEW_COL_DECISION).Value)) Then nExclude = nExclude + 1
        Next rr
    End If
    ws.Range("H2").Value = "伝票依頼 要" & vbCrLf & CStr(nVoucher)
    ws.Range("J2").Value = "除外指定" & vbCrLf & CStr(nExclude)
    ws.Range("L2").Value = "候補数" & vbCrLf & CStr(nTotal)
End Sub

Private Sub BuildCompactHeaders(ByVal ws As Worksheet)
    SetRowValues ws.Cells(VIEW_HEADER_ROW, 1), Array("候補ID", "区分", "伝票", "判断", "組合せ/信頼度", "金額", "差額", "日付", "出金側", "入金側", "関係/年齢", "要点/住所", "メモ")
    FormatHeader ws.Range(ws.Cells(VIEW_HEADER_ROW, 1), ws.Cells(VIEW_HEADER_ROW, VIEW_LAST_COL)), ThemeColor("header")
    ws.Rows(VIEW_HEADER_ROW).RowHeight = 27
End Sub

Private Sub WriteCompactResultRow(ByVal dst As Worksheet, ByVal src As Worksheet, ByVal srcRow As Long, ByVal outR As Long)
    Dim outAmt As Variant, inAmt As Variant, diffVal As Variant, relationText As String
    outAmt = src.Cells(srcRow, RES_COL_OUT_AMOUNT).Value
    inAmt = src.Cells(srcRow, RES_COL_IN_AMOUNT).Value
    diffVal = src.Cells(srcRow, RES_COL_DIFF).Value
    relationText = JoinNonBlank(CellText(src.Cells(srcRow, RES_COL_NAME_REL).Value), CellText(src.Cells(srcRow, RES_COL_INH_TIMING).Value), vbLf)
    If Len(CellText(src.Cells(srcRow, RES_COL_COHAB).Value)) > 0 Then relationText = JoinNonBlank(relationText, CellText(src.Cells(srcRow, RES_COL_COHAB).Value), vbLf)
    If Len(CellText(src.Cells(srcRow, RES_COL_AGE_HINT).Value)) > 0 Then relationText = JoinNonBlank(relationText, CellText(src.Cells(srcRow, RES_COL_AGE_HINT).Value), vbLf)

    dst.Cells(outR, VIEW_COL_ID).Value = src.Cells(srcRow, RES_COL_ID).Value
    dst.Cells(outR, VIEW_COL_KIND).Value = src.Cells(srcRow, RES_COL_KIND).Value
    dst.Cells(outR, VIEW_COL_VOUCHER).Value = src.Cells(srcRow, RES_COL_VOUCHER).Value
    dst.Cells(outR, VIEW_COL_DECISION).Value = src.Cells(srcRow, RES_COL_SHIFT_DECISION).Value
    dst.Cells(outR, VIEW_COL_PATTERN).Value = CellText(src.Cells(srcRow, RES_COL_PATTERN).Value) & vbLf & "信頼度 " & CellText(src.Cells(srcRow, RES_COL_SCORE).Value) & "点"
    dst.Cells(outR, VIEW_COL_AMOUNT).Value = "出 " & FormatNumberText(outAmt) & vbCrLf & "入 " & FormatNumberText(inAmt)
    dst.Cells(outR, VIEW_COL_DIFF).Value = diffVal
    dst.Cells(outR, VIEW_COL_DATES).Value = "出 " & CellText(src.Cells(srcRow, RES_COL_OUT_DATE).Value) & vbCrLf & "入 " & CellText(src.Cells(srcRow, RES_COL_IN_DATE).Value)
    dst.Cells(outR, VIEW_COL_OUT_PERSON).Value = CellText(src.Cells(srcRow, RES_COL_OUT_PERSON).Value)
    dst.Cells(outR, VIEW_COL_IN_PERSON).Value = CellText(src.Cells(srcRow, RES_COL_IN_PERSON).Value)
    dst.Cells(outR, VIEW_COL_RELATION).Value = relationText
    dst.Cells(outR, VIEW_COL_SUMMARY).Value = JoinNonBlank(CellText(src.Cells(srcRow, RES_COL_SHOPS).Value), CellText(src.Cells(srcRow, RES_COL_SUMMARY).Value), vbLf)
    If Len(CellText(src.Cells(srcRow, RES_COL_ADDRESS_HINT).Value)) > 0 Then dst.Cells(outR, VIEW_COL_SUMMARY).Value = JoinNonBlank(CellText(dst.Cells(outR, VIEW_COL_SUMMARY).Value), CellText(src.Cells(srcRow, RES_COL_ADDRESS_HINT).Value), vbLf)
    dst.Cells(outR, VIEW_COL_MEMO).Value = src.Cells(srcRow, RES_COL_OPERATION_MEMO).Value
End Sub

Private Function FormatNumberText(ByVal v As Variant) As String
    If IsNumeric(v) Then
        FormatNumberText = Format$(CDbl(v), "#,##0")
    Else
        FormatNumberText = CellText(v)
    End If
End Function

Private Sub ApplyCompactResultLayout(ByVal ws As Worksheet, ByVal viewLastR As Long)
    ws.Columns("A:A").ColumnWidth = 10
    ws.Columns("B:B").ColumnWidth = 13
    ws.Columns("C:D").ColumnWidth = 8
    ws.Columns("E:E").ColumnWidth = 9
    ws.Columns("F:F").ColumnWidth = 14
    ws.Columns("G:G").ColumnWidth = 10
    ws.Columns("H:H").ColumnWidth = 15
    ws.Columns("I:J").ColumnWidth = 15
    ws.Columns("K:K").ColumnWidth = 15
    ws.Columns("L:L").ColumnWidth = 29
    ws.Columns("M:M").ColumnWidth = 17
    ws.Range(ws.Cells(1, 1), ws.Cells(Application.Max(viewLastR, VIEW_FIRST_DATA_ROW), VIEW_LAST_COL)).WrapText = True
    ws.Range(ws.Cells(1, 1), ws.Cells(Application.Max(viewLastR, VIEW_FIRST_DATA_ROW), VIEW_LAST_COL)).VerticalAlignment = xlCenter
    If viewLastR >= VIEW_FIRST_DATA_ROW Then ws.Rows(CStr(VIEW_FIRST_DATA_ROW) & ":" & CStr(viewLastR)).RowHeight = 46
    ws.Columns("N:XFD").Hidden = True
    ws.ScrollArea = "A1:M" & CStr(Application.Max(200, viewLastR + 20))
End Sub

Private Sub AddResultSheetControls(ByVal ws As Worksheet)
    AddResultButton ws, "再分析", "ReAnalyzeFromResultSheet", ws.Range("A5"), ThemeColor("orange")
    AddResultButton ws, "変更反映", "ApplyManualEditsFromResultSheet", ws.Range("C5"), ThemeColor("red")
    AddResultButton ws, "共通保存", "SaveAnalysisToCommonData", ws.Range("E5"), ThemeColor("teal")
    AddResultButton ws, "除外解除", "ClearManualExclusions", ws.Range("G5"), ThemeColor("muted")
    AddResultButton ws, "条件へ", "ShowMainSheet", ws.Range("I5"), ThemeColor("header")
    AddResultButton ws, "最終出力", "ExportAnalysisWorkbook", ws.Range("K5"), ThemeColor("purple")
    AddResultButton ws, "不明出金追跡", "TraceSelectedUnknownOutToLaterUnknownIns", ws.Range("M5"), ThemeColor("purple")
End Sub

Private Sub AddResultButton(ByVal ws As Worksheet, ByVal caption As String, ByVal macroName As String, ByVal anchor As Range, ByVal fillColor As Long)
    Dim shp As Shape
    Set shp = ws.Shapes.AddShape(msoShapeRoundedRectangle, anchor.Left, anchor.Top + 2, ws.Range(anchor, anchor.Offset(0, 1)).Width, 28)
    shp.Name = "btn_result_" & macroName
    ThemeStyleButtonShapeWithColor shp, caption, fillColor, fillColor, ThemeReadableFontColor(fillColor), macroName
End Sub

Private Sub PrepareManualEditing(ByVal ws As Worksheet, ByVal viewLastR As Long)
    On Error Resume Next
    ws.Cells.Locked = True
    With ws.Range(ws.Cells(VIEW_FIRST_DATA_ROW, VIEW_COL_VOUCHER), ws.Cells(viewLastR, VIEW_COL_VOUCHER))
        .Locked = False
        .Interior.Color = ThemeColor("warning-soft")
        .Validation.Delete
        .Validation.Add Type:=xlValidateList, AlertStyle:=xlValidAlertStop, Operator:=xlBetween, Formula1:=VOUCHER_YES & "," & VOUCHER_NO
        .Validation.IgnoreBlank = True
        .Validation.InCellDropdown = True
    End With
    With ws.Range(ws.Cells(VIEW_FIRST_DATA_ROW, VIEW_COL_DECISION), ws.Cells(viewLastR, VIEW_COL_DECISION))
        .Locked = False
        .Interior.Color = ThemeColor("success-bg")
        .Validation.Delete
        .Validation.Add Type:=xlValidateList, AlertStyle:=xlValidAlertStop, Operator:=xlBetween, Formula1:=DECISION_USE & "," & DECISION_EXCLUDE & "," & DECISION_TX_EXCLUDE
        .Validation.IgnoreBlank = True
        .Validation.InCellDropdown = True
    End With
    ws.Cells(VIEW_HEADER_ROW, VIEW_COL_VOUCHER).Interior.Color = ThemeColor("red")
    ws.Cells(VIEW_HEADER_ROW, VIEW_COL_VOUCHER).Font.Color = vbWhite
    With ws.Range(ws.Cells(VIEW_FIRST_DATA_ROW, VIEW_COL_MEMO), ws.Cells(viewLastR, VIEW_COL_MEMO))
        .Locked = False
        .Interior.Color = vbWhite
        .Validation.Delete
    End With
    ws.Cells(VIEW_HEADER_ROW, VIEW_COL_DECISION).Interior.Color = ThemeColor("green")
    ws.Cells(VIEW_HEADER_ROW, VIEW_COL_DECISION).Font.Color = vbWhite
    ws.Cells(VIEW_HEADER_ROW, VIEW_COL_MEMO).Interior.Color = ThemeColor("muted-strong")
    ws.Cells(VIEW_HEADER_ROW, VIEW_COL_MEMO).Font.Color = vbWhite
    On Error GoTo 0
End Sub

Public Sub HandleAnalysisResultSelectionChange(ByVal Target As Range)
    Dim ws As Worksheet, msg As String, r As Long
    If Target Is Nothing Then Exit Sub
    If Target.Worksheet.Name <> SH_RESULT Then Exit Sub
    If Target.Cells.CountLarge > 1 Then Exit Sub
    Set ws = Target.Worksheet
    r = Target.Row
    If r < VIEW_FIRST_DATA_ROW Then
        Application.StatusBar = "分析結果です。C列=伝票、D列=採用判断、M列=メモを編集できます。判断は即時保存されます。"
        Exit Sub
    End If
    If Len(CellText(ws.Cells(r, VIEW_COL_ID).Value)) = 0 Then Exit Sub
    Select Case Target.Column
        Case VIEW_COL_VOUCHER
            msg = "伝票要否です。要/不要を選ぶと、伝票依頼候補へ即時反映します。"
        Case VIEW_COL_DECISION
            msg = "採用判断です。通常は候補除外を使い、取引除外は再分析から外す時だけ慎重に使います。"
        Case VIEW_COL_MEMO
            msg = "メモ欄です。判断理由・確認済事項を書くと、再分析後も保持されます。"
        Case VIEW_COL_KIND
            msg = "分類です。不明出金行を選んで不明出金追跡を実行できます。"
        Case VIEW_COL_SUMMARY
            msg = "根拠要約です。取扱店、時刻順、住所・年齢・残高急変などの判断材料を確認します。"
        Case VIEW_COL_DATES
            msg = "出金日・入金日です。同日で双方に時刻がある場合は出金→入金の順序を守ります。"
        Case Else
            msg = "分析候補行です。C列・D列・M列だけを編集し、詳細は分析明細や論点サマリで確認します。"
    End Select
    Application.StatusBar = msg
End Sub

Public Sub HandleAnalysisResultChange(ByVal Target As Range)
    'ドロップダウンやメモの手入力を、その場で内部状態へ反映する。
    '「変更反映」ボタンを押し忘れても、再分析・共通保存で判断が戻らないようにする。
    Static handling As Boolean
    Dim ws As Worksheet, watch As Range, hit As Range, cell As Range
    Dim lastR As Long, r As Long, voucherText As String, decisionText As String
    Dim prevEvents As Boolean
    If handling Then Exit Sub
    If Target Is Nothing Then Exit Sub
    If Target.Worksheet.Name <> SH_RESULT Then Exit Sub
    Set ws = Target.Worksheet
    lastR = LastRow(ws, VIEW_COL_ID)
    If lastR < VIEW_FIRST_DATA_ROW Then Exit Sub
    Set watch = Union(ws.Range(ws.Cells(VIEW_FIRST_DATA_ROW, VIEW_COL_VOUCHER), ws.Cells(lastR, VIEW_COL_VOUCHER)), _
                      ws.Range(ws.Cells(VIEW_FIRST_DATA_ROW, VIEW_COL_DECISION), ws.Cells(lastR, VIEW_COL_DECISION)), _
                      ws.Range(ws.Cells(VIEW_FIRST_DATA_ROW, VIEW_COL_MEMO), ws.Cells(lastR, VIEW_COL_MEMO)))
    Set hit = Intersect(Target, watch)
    If hit Is Nothing Then Exit Sub

    handling = True
    prevEvents = Application.EnableEvents
    On Error GoTo SafeExit
    Application.EnableEvents = False
    ws.Unprotect Password:=TOOL_PASSWORD

    For Each cell In hit.Cells
        r = cell.Row
        If Len(CellText(ws.Cells(r, VIEW_COL_ID).Value)) > 0 Then
            If cell.Column = VIEW_COL_VOUCHER Then
                voucherText = CellText(cell.Value)
                If voucherText <> VOUCHER_YES Then voucherText = VOUCHER_NO
                cell.Value = voucherText
                ws.Cells(r, RAW_START_COL + RES_COL_VOUCHER - 1).Value = voucherText
            ElseIf cell.Column = VIEW_COL_DECISION Then
                decisionText = NormalizeDecisionText(CellText(cell.Value))
                If Len(decisionText) = 0 Then decisionText = DECISION_USE
                cell.Value = decisionText
                If IsExcludeDecision(decisionText) Then
                    ws.Cells(r, VIEW_COL_VOUCHER).Value = VOUCHER_NO
                    ws.Cells(r, RAW_START_COL + RES_COL_VOUCHER - 1).Value = VOUCHER_NO
                End If
                ws.Cells(r, RAW_START_COL + RES_COL_SHIFT_DECISION - 1).Value = decisionText
                ws.Cells(r, RAW_START_COL + RES_COL_OPERATION_MEMO - 1).Value = ws.Cells(r, VIEW_COL_MEMO).Value
            ElseIf cell.Column = VIEW_COL_MEMO Then
                ws.Cells(r, RAW_START_COL + RES_COL_OPERATION_MEMO - 1).Value = cell.Value
            End If
        End If
    Next cell

    ColorResultRows ws, lastR
    PersistManualStateFromResultSheet True
    SyncVoucherFlagsFromResultSheet True
    BuildResultSummaryCards ws, lastR
SafeExit:
    ProtectOutputSheet ws
    Application.EnableEvents = prevEvents
    handling = False
End Sub

Public Sub ApplyVoucherFlagsFromResultSheet()
    ApplyManualEditsFromResultSheet
End Sub

Public Sub ApplyManualEditsFromResultSheet()
    If Not SheetExists(SH_RESULT) Then Exit Sub
    On Error GoTo EH
    AppBegin "手動変更を反映中..."
    PersistManualStateFromResultSheet True
    SyncVoucherFlagsFromResultSheet False
    ApplyManualExclusionsFromResultSheet True
    BuildDetailOutputSheet
    BuildFlaggedTransactionSheet
    AppEnd
    MsgBox "分析結果シートの手動変更を明細・分析済表へ反映しました。", vbInformation
    Exit Sub
EH:
    AppEnd
    MsgBox "手動変更反映中にエラーが発生しました。" & vbCrLf & Err.Description, vbExclamation
End Sub

Public Sub ReAnalyzeFromResultSheet()
    If SheetExists(SH_RESULT) Then
        PersistManualStateFromResultSheet True
        ApplyManualExclusionsFromResultSheet False
    End If
    RunAnalysis
End Sub

Public Sub ShowMainSheet()
    If SheetExists(SH_MAIN) Then
        GetSheet(SH_MAIN).Visible = xlSheetVisible
        GetSheet(SH_MAIN).Activate
    End If
End Sub

Public Sub ClearManualExclusions()
    If MsgBox("手動除外した取引IDと、候補の除外判断を解除します。" & vbCrLf & _
              "伝票依頼の手動変更やメモはできるだけ維持します。よろしいですか。", vbQuestion + vbYesNo) <> vbYes Then Exit Sub
    InitManualExcludeHeaders GetSheet(SH_MANUAL_EXCLUDE)
    ClearExcludeDecisionsInManualState
    AppendLog "手動除外解除", "成功", "W_手動除外を初期化し、W_手動調整の除外判断を採用へ戻しました"
    MsgBox "手動除外を解除しました。再分析すると除外候補を再度含めて確認できます。", vbInformation
End Sub

Private Sub ClearExcludeDecisionsInManualState()
    Dim ws As Worksheet, lastR As Long, r As Long
    If Not SheetExists(SH_MANUAL_STATE) Then Exit Sub
    Set ws = GetSheet(SH_MANUAL_STATE)
    lastR = LastRow(ws, 1)
    For r = 2 To lastR
        If IsExcludeDecision(CellText(ws.Cells(r, 4).Value)) Then
            ws.Cells(r, 4).Value = DECISION_USE
            If Len(CellText(ws.Cells(r, 5).Value)) = 0 Or InStr(CellText(ws.Cells(r, 5).Value), "除外") > 0 Then
                ws.Cells(r, 5).Value = "除外解除済み"
            End If
            ws.Cells(r, 6).Value = Now
        End If
    Next r
End Sub


Public Sub PersistManualStateFromResultSheet(Optional ByVal silent As Boolean = True)
    Dim ws As Worksheet, st As Worksheet, lastR As Long, r As Long, outR As Long
    Dim keyText As String, outIds As String, inIds As String, patternText As String
    If Not SheetExists(SH_RESULT) Then Exit Sub
    Set ws = GetSheet(SH_RESULT)
    Set st = GetSheet(SH_MANUAL_STATE)
    InitManualStateHeaders st
    lastR = LastRow(ws, VIEW_COL_ID)
    outR = 2
    For r = VIEW_FIRST_DATA_ROW To lastR
        If Len(CellText(ws.Cells(r, VIEW_COL_ID).Value)) > 0 Then
            patternText = CellText(ws.Cells(r, RAW_START_COL + RES_COL_PATTERN - 1).Value)
            outIds = CellText(ws.Cells(r, RAW_START_COL + RES_COL_OUT_IDS - 1).Value)
            inIds = CellText(ws.Cells(r, RAW_START_COL + RES_COL_IN_IDS - 1).Value)
            keyText = BuildAnalysisStateKey(patternText, outIds, inIds)
            st.Cells(outR, 1).Value = keyText
            st.Cells(outR, 2).Value = ws.Cells(r, VIEW_COL_ID).Value
            st.Cells(outR, 3).Value = ws.Cells(r, VIEW_COL_VOUCHER).Value
            st.Cells(outR, 4).Value = ws.Cells(r, VIEW_COL_DECISION).Value
            st.Cells(outR, 5).Value = ws.Cells(r, VIEW_COL_MEMO).Value
            st.Cells(outR, 6).Value = Now
            outR = outR + 1
        End If
    Next r
    If Not silent Then AppendLog "手動調整保存", "成功", "W_手動調整へ保存"
End Sub

Public Sub SyncVoucherFlagsFromResultSheet(Optional ByVal silent As Boolean = True)
    Dim wsResult As Worksheet, wsWork As Worksheet, wsDetail As Worksheet
    Dim lastR As Long, r As Long, idText As String, voucherText As String, decisionText As String, found As Range
    If Not SheetExists(SH_RESULT) Then Exit Sub
    Set wsResult = GetSheet(SH_RESULT)
    Set wsWork = GetSheet(SH_WORK_RESULT)
    Set wsDetail = GetSheet(SH_WORK_DETAIL)
    lastR = LastRow(wsResult, VIEW_COL_ID)
    For r = VIEW_FIRST_DATA_ROW To lastR
        idText = CellText(wsResult.Cells(r, VIEW_COL_ID).Value)
        voucherText = CellText(wsResult.Cells(r, VIEW_COL_VOUCHER).Value)
        decisionText = CellText(wsResult.Cells(r, VIEW_COL_DECISION).Value)
        If IsExcludeDecision(decisionText) Then voucherText = VOUCHER_NO
        If voucherText <> VOUCHER_YES Then voucherText = VOUCHER_NO
        If Len(idText) > 0 Then
            Set found = wsWork.Columns(RES_COL_ID).Find(What:=idText, LookIn:=xlValues, LookAt:=xlWhole)
            If Not found Is Nothing Then
                wsWork.Cells(found.Row, RES_COL_VOUCHER).Value = voucherText
                wsWork.Cells(found.Row, RES_COL_SHIFT_DECISION).Value = decisionText
                wsWork.Cells(found.Row, RES_COL_OPERATION_MEMO).Value = CellText(wsResult.Cells(r, VIEW_COL_MEMO).Value)
            End If
            ApplyVoucherToDetail wsDetail, idText, voucherText
        End If
    Next r
    If Not silent Then AppendLog "伝票依頼フラグ反映", "成功", "分析結果シートから反映"
End Sub

Private Sub ApplyVoucherToDetail(ByVal wsDetail As Worksheet, ByVal analysisId As String, ByVal voucherText As String)
    Dim lastR As Long, r As Long
    lastR = LastRow(wsDetail, DET_COL_ID)
    For r = 2 To lastR
        If CellText(wsDetail.Cells(r, DET_COL_ANALYSIS_ID).Value) = analysisId Then wsDetail.Cells(r, DET_COL_VOUCHER).Value = voucherText
    Next r
End Sub

Private Sub ColorResultRows(ByVal ws As Worksheet, ByVal viewLastR As Long)
    Dim r As Long, kindText As String, colorValue As Long
    For r = VIEW_FIRST_DATA_ROW To viewLastR
        kindText = CellText(ws.Cells(r, VIEW_COL_KIND).Value)
        Select Case kindText
            Case KIND_SHIFT
                colorValue = ThemeColor("info-soft")
            Case KIND_INHERITANCE_SHIFT
                colorValue = ThemeColor("purple-soft")
            Case KIND_UNKNOWN_IN
                colorValue = ThemeColor("warning-soft")
            Case KIND_UNKNOWN_OUT
                colorValue = ThemeColor("orange-soft")
            Case Else
                colorValue = ThemeColor("locked")
        End Select
        ws.Range(ws.Cells(r, 1), ws.Cells(r, VIEW_LAST_COL)).Interior.Color = colorValue
        If IsTxExcludeDecision(CellText(ws.Cells(r, VIEW_COL_DECISION).Value)) Then
            ws.Range(ws.Cells(r, 1), ws.Cells(r, VIEW_LAST_COL)).Interior.Color = ThemeColor("locked")
            ws.Cells(r, VIEW_COL_DECISION).Interior.Color = ThemeColor("warning-text")
            ws.Cells(r, VIEW_COL_DECISION).Font.Color = vbWhite
            ws.Cells(r, VIEW_COL_DECISION).Font.Bold = True
        ElseIf IsExcludeDecision(CellText(ws.Cells(r, VIEW_COL_DECISION).Value)) Then
            ws.Range(ws.Cells(r, 1), ws.Cells(r, VIEW_LAST_COL)).Interior.Color = ThemeColor("locked")
            ws.Cells(r, VIEW_COL_DECISION).Interior.Color = ThemeColor("muted")
            ws.Cells(r, VIEW_COL_DECISION).Font.Color = vbWhite
            ws.Cells(r, VIEW_COL_DECISION).Font.Bold = True
        Else
            ws.Cells(r, VIEW_COL_DECISION).Interior.Color = ThemeColor("success-bg")
            ws.Cells(r, VIEW_COL_DECISION).Font.Color = ThemeColor("success-text")
        End If
        If CellText(ws.Cells(r, VIEW_COL_VOUCHER).Value) = VOUCHER_YES Then
            ws.Cells(r, VIEW_COL_VOUCHER).Interior.Color = ThemeColor("red")
            ws.Cells(r, VIEW_COL_VOUCHER).Font.Color = vbWhite
            ws.Cells(r, VIEW_COL_VOUCHER).Font.Bold = True
        Else
            ws.Cells(r, VIEW_COL_VOUCHER).Interior.Color = ThemeColor("warning-soft")
            ws.Cells(r, VIEW_COL_VOUCHER).Font.Color = ThemeColor("muted")
            ws.Cells(r, VIEW_COL_VOUCHER).Font.Bold = False
        End If
    Next r
End Sub

Public Sub HandleAnalysisResultDoubleClick(ByVal Target As Range, ByRef Cancel As Boolean)
    If Target Is Nothing Then Exit Sub
    If Target.CountLarge <> 1 Then Exit Sub
    If Target.Row < VIEW_FIRST_DATA_ROW Then Exit Sub
    If Target.Column <> VIEW_COL_VOUCHER And Target.Column <> VIEW_COL_DECISION Then Exit Sub
    If CellText(GetSheet(SH_RESULT).Cells(Target.Row, VIEW_COL_ID).Value) = "" Then Exit Sub
    Cancel = True
    Dim prevEvents As Boolean
    prevEvents = Application.EnableEvents
    On Error GoTo SafeExit
    Application.EnableEvents = False
    GetSheet(SH_RESULT).Unprotect Password:=TOOL_PASSWORD
    If Target.Column = VIEW_COL_VOUCHER Then
        If CellText(Target.Value) = VOUCHER_YES Then
            Target.Value = VOUCHER_NO
            Target.Interior.Color = ThemeColor("warning-soft")
            Target.Font.Color = ThemeColor("muted")
            Target.Font.Bold = False
        Else
            Target.Value = VOUCHER_YES
            Target.Interior.Color = ThemeColor("red")
            Target.Font.Color = vbWhite
            Target.Font.Bold = True
        End If
        GetSheet(SH_RESULT).Cells(Target.Row, RAW_START_COL + RES_COL_VOUCHER - 1).Value = Target.Value
    ElseIf Target.Column = VIEW_COL_DECISION Then
        Select Case NormalizeDecisionText(CellText(Target.Value))
            Case DECISION_USE
                Target.Value = DECISION_EXCLUDE
                Target.Interior.Color = ThemeColor("muted")
                Target.Font.Color = vbWhite
                Target.Font.Bold = True
                GetSheet(SH_RESULT).Cells(Target.Row, VIEW_COL_MEMO).Value = "候補除外。再分析後もこの組合せだけを除外し、取引自体は他候補に使えます。"
                With GetSheet(SH_RESULT).Cells(Target.Row, VIEW_COL_VOUCHER)
                    .Value = VOUCHER_NO
                    .Interior.Color = ThemeColor("warning-soft")
                    .Font.Color = ThemeColor("muted")
                    .Font.Bold = False
                End With
                GetSheet(SH_RESULT).Cells(Target.Row, RAW_START_COL + RES_COL_VOUCHER - 1).Value = VOUCHER_NO
            Case DECISION_EXCLUDE
                Target.Value = DECISION_TX_EXCLUDE
                Target.Interior.Color = ThemeColor("warning-text")
                Target.Font.Color = vbWhite
                Target.Font.Bold = True
                GetSheet(SH_RESULT).Cells(Target.Row, VIEW_COL_MEMO).Value = "取引除外。再分析でこの候補に含まれる取引IDをシフト候補から外します。"
                With GetSheet(SH_RESULT).Cells(Target.Row, VIEW_COL_VOUCHER)
                    .Value = VOUCHER_NO
                    .Interior.Color = ThemeColor("warning-soft")
                    .Font.Color = ThemeColor("muted")
                    .Font.Bold = False
                End With
                GetSheet(SH_RESULT).Cells(Target.Row, RAW_START_COL + RES_COL_VOUCHER - 1).Value = VOUCHER_NO
            Case Else
                Target.Value = DECISION_USE
                Target.Interior.Color = ThemeColor("success-bg")
                Target.Font.Color = ThemeColor("success-text")
                Target.Font.Bold = False
                GetSheet(SH_RESULT).Cells(Target.Row, VIEW_COL_MEMO).Value = "採用に戻しました。取引除外を戻す場合は除外解除も確認してください。"
        End Select
        GetSheet(SH_RESULT).Cells(Target.Row, RAW_START_COL + RES_COL_SHIFT_DECISION - 1).Value = Target.Value
        GetSheet(SH_RESULT).Cells(Target.Row, RAW_START_COL + RES_COL_OPERATION_MEMO - 1).Value = GetSheet(SH_RESULT).Cells(Target.Row, VIEW_COL_MEMO).Value
    End If
    PersistManualStateFromResultSheet True
SafeExit:
    On Error Resume Next
    BuildResultSummaryCards GetSheet(SH_RESULT), LastRow(GetSheet(SH_RESULT), VIEW_COL_ID)
    On Error GoTo 0
    ProtectOutputSheet GetSheet(SH_RESULT)
    Application.EnableEvents = prevEvents
End Sub

Public Sub ApplyManualExclusionsFromResultSheet(Optional ByVal silent As Boolean = True)
    Dim ws As Worksheet, ex As Worksheet, lastR As Long, r As Long
    Dim idsText As String, idText As String, arr As Variant, i As Long, txId As String, outR As Long
    If Not SheetExists(SH_RESULT) Then Exit Sub
    Set ws = GetSheet(SH_RESULT)
    Set ex = GetSheet(SH_MANUAL_EXCLUDE)
    If LastRow(ex, 1) < 1 Then InitManualExcludeHeaders ex
    lastR = LastRow(ws, VIEW_COL_ID)
    outR = LastRow(ex, 1) + 1
    For r = VIEW_FIRST_DATA_ROW To lastR
        If IsTxExcludeDecision(CellText(ws.Cells(r, VIEW_COL_DECISION).Value)) Then
            idText = CellText(ws.Cells(r, VIEW_COL_ID).Value)
            idsText = JoinNonBlank(CellText(ws.Cells(r, RAW_START_COL + RES_COL_OUT_IDS - 1).Value), CellText(ws.Cells(r, RAW_START_COL + RES_COL_IN_IDS - 1).Value), ",")
            If Len(idsText) > 0 Then
                arr = Split(idsText, ",")
                For i = LBound(arr) To UBound(arr)
                    txId = Trim$(CStr(arr(i)))
                    If Len(txId) > 0 And Not ManualExcludeExists(ex, txId) Then
                        ex.Cells(outR, 1).Value = txId
                        ex.Cells(outR, 2).Value = idText
                        ex.Cells(outR, 3).Value = Now
                        ex.Cells(outR, 4).Value = "分析結果シートで取引除外指定"
                        outR = outR + 1
                    End If
                Next i
            End If
        End If
    Next r
    If Not silent Then AppendLog "手動除外反映", "成功", "分析結果シートからW_手動除外へ反映"
End Sub

Private Function ManualExcludeExists(ByVal ws As Worksheet, ByVal txId As String) As Boolean
    Dim found As Range
    Set found = ws.Columns(1).Find(What:=txId, LookIn:=xlValues, LookAt:=xlWhole)
    ManualExcludeExists = Not found Is Nothing
End Function

Public Sub BuildFlaggedTransactionSheet()
    Dim src As Worksheet, dst As Worksheet, detail As Worksheet
    Dim lastR As Long, lastC As Long, r As Long
    Dim txId As String, flags As Object, ids As Object, vouchers As Object, memos As Object
    Set src = GetSheet(SH_WORK_TX)
    Set detail = GetSheet(SH_WORK_DETAIL)
    Set dst = GetSheet(SH_FLAGGED)
    On Error Resume Next
    dst.Unprotect Password:=TOOL_PASSWORD
    dst.Cells.UnMerge
    dst.Cells.Clear
    DeleteAllShapes dst
    On Error GoTo 0

    Set flags = CreateObject("Scripting.Dictionary")
    Set ids = CreateObject("Scripting.Dictionary")
    Set vouchers = CreateObject("Scripting.Dictionary")
    Set memos = CreateObject("Scripting.Dictionary")
    BuildFlagDictionaries detail, flags, ids, vouchers, memos

    lastR = LastRow(src, 1)
    lastC = LastUsedColumn(src)
    If lastR < 1 Then Exit Sub
    dst.Range(dst.Cells(1, 1), dst.Cells(lastR, lastC)).Value = src.Range(src.Cells(1, 1), src.Cells(lastR, lastC)).Value

    dst.Cells(1, lastC + 1).Value = "分析フラグ"
    dst.Cells(1, lastC + 2).Value = "分析候補ID"
    dst.Cells(1, lastC + 3).Value = "伝票依頼"
    dst.Cells(1, lastC + 4).Value = "分析メモ"
    FormatHeader dst.Range(dst.Cells(1, 1), dst.Cells(1, lastC + 4)), ThemeColor("header")

    Dim colTx As Long, lastColLetter As String
    colTx = HeaderColumn(dst, "取引ID", 1)
    For r = 2 To lastR
        txId = CellText(dst.Cells(r, colTx).Value)
        If flags.Exists(txId) Then
            dst.Cells(r, lastC + 1).Value = flags(txId)
            dst.Cells(r, lastC + 2).Value = ids(txId)
            dst.Cells(r, lastC + 3).Value = vouchers(txId)
            dst.Cells(r, lastC + 4).Value = memos(txId)
            ApplyFlagColor dst.Range(dst.Cells(r, 1), dst.Cells(r, lastC + 4)), CStr(flags(txId))
        End If
    Next r

    FormatBody dst.Range(dst.Cells(2, 1), dst.Cells(Application.Max(2, lastR), lastC + 4))
    dst.Range(dst.Cells(1, 1), dst.Cells(lastR, lastC + 4)).AutoFilter
    dst.Activate
    ActiveWindow.FreezePanes = False
    dst.Range("A2").Select
    ActiveWindow.FreezePanes = True
    lastColLetter = ColumnLetter(lastC + 4)
    AutoFitSheetSmart dst, "A:" & lastColLetter, 6, 34
    ThemeApplyPrintTable dst.Range(dst.Cells(1, 1), dst.Cells(lastR, lastC + 4)), 1
    ThemeCapRowHeights dst.Range(dst.Cells(2, 1), dst.Cells(lastR, lastC + 4)), 20, 72
    ThemeApplyMonochromePrint dst, dst.Range(dst.Cells(1, 1), dst.Cells(lastR, lastC + 4)).Address, True, "$1:$1", 1, 0
    ProtectOutputSheet dst
End Sub

Private Sub BuildFlagDictionaries(ByVal detail As Worksheet, ByVal flags As Object, ByVal ids As Object, ByVal vouchers As Object, ByVal memos As Object)
    Dim lastR As Long, r As Long, txId As String, kindText As String, analysisId As String
    lastR = LastRow(detail, DET_COL_ID)
    For r = 2 To lastR
        txId = CellText(detail.Cells(r, DET_COL_TX_ID).Value)
        kindText = CellText(detail.Cells(r, DET_COL_KIND).Value)
        analysisId = CellText(detail.Cells(r, DET_COL_ANALYSIS_ID).Value)
        If Len(txId) > 0 Then
            If flags.Exists(txId) Then
                If InStr(flags(txId), kindText) = 0 Then flags(txId) = flags(txId) & "," & kindText
                If InStr(ids(txId), analysisId) = 0 Then ids(txId) = ids(txId) & "," & analysisId
                If CellText(detail.Cells(r, DET_COL_VOUCHER).Value) = VOUCHER_YES Then vouchers(txId) = VOUCHER_YES
            Else
                flags(txId) = kindText
                ids(txId) = analysisId
                vouchers(txId) = CellText(detail.Cells(r, DET_COL_VOUCHER).Value)
            End If
            memos(txId) = "分析対象"
        End If
    Next r
End Sub

Private Sub ApplyFlagColor(ByVal rng As Range, ByVal flagText As String)
    If InStr(flagText, KIND_INHERITANCE_SHIFT) > 0 Then
        rng.Interior.Color = ThemeColor("purple-soft")
    ElseIf InStr(flagText, KIND_SHIFT) > 0 Then
        rng.Interior.Color = ThemeColor("info-soft")
    ElseIf InStr(flagText, KIND_UNKNOWN_IN) > 0 Then
        rng.Interior.Color = ThemeColor("warning-soft")
    ElseIf InStr(flagText, KIND_UNKNOWN_OUT) > 0 Then
        rng.Interior.Color = ThemeColor("orange-soft")
    Else
        rng.Interior.Color = ThemeColor("locked")
    End If
End Sub

Public Sub BuildDetailOutputSheet()
    Dim src As Worksheet, dst As Worksheet, lastR As Long
    Set src = GetSheet(SH_WORK_DETAIL)
    Set dst = GetSheet(SH_DETAIL)
    On Error Resume Next
    dst.Unprotect Password:=TOOL_PASSWORD
    dst.Cells.UnMerge
    dst.Cells.Clear
    DeleteAllShapes dst
    On Error GoTo 0

    lastR = LastRow(src, 1)
    dst.Range("A1:Q" & CStr(Application.Max(1, lastR))).Value = src.Range("A1:Q" & CStr(Application.Max(1, lastR))).Value
    FormatHeader dst.Range("A1:Q1"), ThemeColor("header")
    If lastR >= 2 Then
        FormatBody dst.Range("A2:Q" & CStr(lastR))
        dst.Range("E2:E" & CStr(lastR)).NumberFormatLocal = "yyyy/m/d"
        dst.Range("F2:F" & CStr(lastR)).NumberFormatLocal = "#,##0"
    End If
    dst.Range("A1:Q1").AutoFilter
    AutoFitSheetSmart dst, "A:Q", 6, 34
    ThemeApplyPrintTable dst.Range("A1:Q" & CStr(Application.Max(1, lastR))), 1
    ThemeCapRowHeights dst.Range("A2:Q" & CStr(Application.Max(2, lastR))), 20, 72
    ThemeApplyMonochromePrint dst, dst.Range("A1:Q" & CStr(Application.Max(1, lastR))).Address, True, "$1:$1", 1, 0
    ProtectOutputSheet dst
End Sub

Public Sub BuildAllVisibleOutputs()
    BuildAnalysisResultSheet
    BuildDetailOutputSheet
    BuildFlaggedTransactionSheet
    BuildInvestigationIssueSheet True
End Sub

Private Sub ProtectOutputSheet(ByVal ws As Worksheet)
    On Error Resume Next
    ThemePrepareSheetForProtection ws
    ws.Protect Password:=TOOL_PASSWORD, UserInterfaceOnly:=True, DrawingObjects:=True, Contents:=True, Scenarios:=True, AllowFiltering:=True, AllowSorting:=True
    ws.EnableSelection = xlNoRestrictions
    On Error GoTo 0
End Sub

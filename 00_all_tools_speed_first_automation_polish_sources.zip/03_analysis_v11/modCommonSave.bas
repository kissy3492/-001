Attribute VB_Name = "modCommonSave"
Option Explicit

Public Sub SaveAnalysisToCommonData(Optional ByVal silent As Boolean = False)
    Dim p As String, wb As Workbook
    If Not RequireSavedWorkbook() Then Exit Sub
    p = CommonDataPath()
    If Dir$(p) = "" Then
        MsgBox "00_共通データ.xlsx が見つかりません。" & vbCrLf & p, vbExclamation
        Exit Sub
    End If
    If LastRow(GetSheet(SH_WORK_RESULT), 1) < 2 Then
        If MsgBox("分析結果がありません。空の分析テーブルを共通データへ保存しますか。", vbQuestion + vbYesNo) <> vbYes Then Exit Sub
    End If

    On Error GoTo EH
    AppBegin "分析結果を共通データへ保存中..."
    PersistManualStateFromResultSheet True
    SyncVoucherFlagsFromResultSheet True
    BackupCommonDataBeforeUpdate p
    Set wb = Workbooks.Open(Filename:=p, ReadOnly:=False, UpdateLinks:=False, IgnoreReadOnlyRecommended:=True, Notify:=False, AddToMru:=False)
    WriteAnalysisSettings wb
    WriteAnalysisResultTable wb
    WriteAnalysisDetailTable wb
    WriteVoucherCandidateTable wb
    wb.Save
    wb.Close SaveChanges:=False
    AppEnd
    AppendLog "共通データ保存", "成功", p
    If Not silent Then MsgBox "分析結果を共通データへ保存しました。" & vbCrLf & _
           "T_分析結果 / T_分析明細 / T_伝票依頼候補 を作成しました。", vbInformation
    Exit Sub
EH:
    On Error Resume Next
    If Not wb Is Nothing Then wb.Close SaveChanges:=False
    AppEnd
    AppendLog "共通データ保存", "失敗", Err.Description
    MsgBox "共通データ保存でエラーが発生しました。" & vbCrLf & Err.Description, vbExclamation
End Sub

Private Sub WriteAnalysisSettings(ByVal wb As Workbook)
    Dim ws As Worksheet
    Set ws = ResetCommonSheet(wb, "T_分析連携設定")
    SetRowValues ws.Range("A1"), Array("項目", "値")
    FormatHeader ws.Range("A1:B1")
    SetRowValues ws.Range("A2"), Array("スキーマバージョン", ANALYSIS_SCHEMA_VERSION)
    SetRowValues ws.Range("A3"), Array("作成日時", Now)
    SetRowValues ws.Range("A4"), Array("相続開始日", GetSheet(SH_MAIN).Cells(ROW_INHERITANCE_DATE, COL_VALUE).Value)
    SetRowValues ws.Range("A5"), Array("被相続人人物ID", GetSheet(SH_MAIN).Cells(ROW_DECEDENT_ID, COL_VALUE).Value)
    SetRowValues ws.Range("A6"), Array("シフト抽出金額下限", GetSheet(SH_MAIN).Cells(ROW_MIN_SHIFT_AMOUNT, COL_VALUE).Value)
    SetRowValues ws.Range("A7"), Array("不明入出金下限", GetSheet(SH_MAIN).Cells(ROW_UNKNOWN_THRESHOLD, COL_VALUE).Value)
    SetRowValues ws.Range("A8"), Array("伝票依頼フラグ下限", GetSheet(SH_MAIN).Cells(ROW_VOUCHER_THRESHOLD, COL_VALUE).Value)
    SetRowValues ws.Range("A9"), Array("1対1を抽出", GetSheet(SH_MAIN).Cells(ROW_ENABLE_ONE_TO_ONE, COL_VALUE).Value)
    SetRowValues ws.Range("A10"), Array("1対複数を抽出", GetSheet(SH_MAIN).Cells(ROW_ENABLE_ONE_TO_MANY, COL_VALUE).Value)
    SetRowValues ws.Range("A11"), Array("複数対1を抽出", GetSheet(SH_MAIN).Cells(ROW_ENABLE_MANY_TO_ONE, COL_VALUE).Value)
    SetRowValues ws.Range("A12"), Array("複数対複数を抽出", GetSheet(SH_MAIN).Cells(ROW_ENABLE_MANY_TO_MANY, COL_VALUE).Value)
    SetRowValues ws.Range("A13"), Array("不明入出金を抽出", GetSheet(SH_MAIN).Cells(ROW_ENABLE_UNKNOWNS, COL_VALUE).Value)
    SetRowValues ws.Range("A14"), Array("最大候補件数", GetSheet(SH_MAIN).Cells(ROW_MAX_RESULTS, COL_VALUE).Value)
    SetRowValues ws.Range("A15"), Array("組合せ生成上限/基準取引", GetSheet(SH_MAIN).Cells(ROW_MAX_COMBOS_PER_BASE, COL_VALUE).Value)
    SetRowValues ws.Range("A16"), Array("複数対複数照合上限/基準取引", GetSheet(SH_MAIN).Cells(ROW_MAX_MTM_PAIR_TESTS, COL_VALUE).Value)
    SetRowValues ws.Range("A17"), Array("相続関連シフト常時伝票依頼", GetSheet(SH_MAIN).Cells(ROW_VOUCHER_INHERITANCE_ALWAYS, COL_VALUE).Value)
    SetRowValues ws.Range("A18"), Array("不明入出金伝票依頼対象", GetSheet(SH_MAIN).Cells(ROW_VOUCHER_UNKNOWNS, COL_VALUE).Value)
    SetRowValues ws.Range("A19"), Array("除外摘要キーワード", GetSheet(SH_MAIN).Cells(ROW_EXCLUDE_SUMMARY_KEYWORDS, COL_VALUE).Value)
    SetRowValues ws.Range("A20"), Array("最大組合せ件数", GetSheet(SH_MAIN).Cells(ROW_MAX_COMBO, COL_VALUE).Value)
    SetRowValues ws.Range("A21"), Array("相続開始前重点年数", GetSheet(SH_MAIN).Cells(ROW_INHERITANCE_FOCUS_YEARS, COL_VALUE).Value)
    SetRowValues ws.Range("A22"), Array("シフト候補の最低信頼度", GetSheet(SH_MAIN).Cells(ROW_MIN_SCORE, COL_VALUE).Value)
    SetRowValues ws.Range("A23"), Array("住所・年齢補助を信頼度に反映", GetSheet(SH_MAIN).Cells(ROW_CONTEXT_SCORE, COL_VALUE).Value)
    SetRowValues ws.Range("A24"), Array("シフト日付方向", "出金日から入金日へ")
    SetRowValues ws.Range("A25"), Array("同日時刻順序判定", "双方に時刻がある同日取引だけ厳密判定。時刻なしは0:00/日末に寄せず、日付ベース候補として理由表示する。")
    AutoFitSheetSmart ws, "A:B", 10, 32

    UpdateCommonLinkControlSheet wb, "分析スキーマバージョン", ANALYSIS_SCHEMA_VERSION, "03側の出力仕様"
    UpdateCommonLinkControlSheet wb, "保存日時", Now, "共通データを最後に更新した日時"
End Sub

Private Sub UpdateCommonLinkControlSheet(ByVal wb As Workbook, ByVal keyText As String, ByVal valueText As Variant, ByVal descText As String)
    Dim ws As Worksheet, r As Long, lastR As Long
    On Error Resume Next
    Set ws = wb.Worksheets("T_連携設定")
    On Error GoTo 0
    If ws Is Nothing Then
        Set ws = wb.Worksheets.Add(Before:=wb.Worksheets(1))
        ws.Name = "T_連携設定"
        ws.Range("A1:C1").Value = Array("キー", "値", "説明")
    End If
    If Len(CellText(ws.Cells(1, 1).Value)) = 0 Then ws.Range("A1:C1").Value = Array("キー", "値", "説明")

    lastR = LastRow(ws, 1)
    If lastR < 1 Then lastR = 1
    For r = 2 To lastR
        If CellText(ws.Cells(r, 1).Value) = keyText Then
            ws.Cells(r, 2).Value = valueText
            ws.Cells(r, 3).Value = descText
            ws.Columns("A:C").AutoFit
            Exit Sub
        End If
    Next r

    ws.Cells(lastR + 1, 1).Value = keyText
    ws.Cells(lastR + 1, 2).Value = valueText
    ws.Cells(lastR + 1, 3).Value = descText
    ws.Columns("A:C").AutoFit
End Sub

Private Sub WriteAnalysisResultTable(ByVal wb As Workbook)
    Dim src As Worksheet, dst As Worksheet, lastR As Long
    Set src = GetSheet(SH_WORK_RESULT)
    Set dst = ResetCommonSheet(wb, "T_分析結果")
    lastR = LastRow(src, 1)
    dst.Range("A1:X" & CStr(Application.Max(1, lastR))).Value = src.Range("A1:X" & CStr(Application.Max(1, lastR))).Value
    FormatHeader dst.Range("A1:X1")
    If lastR >= 2 Then
        FormatBody dst.Range("A2:X" & CStr(lastR))
        dst.Range("H2:J" & CStr(lastR)).NumberFormatLocal = "#,##0"
    End If
    AutoFitSheetSmart dst, "A:X", 6, 34
End Sub

Private Sub WriteAnalysisDetailTable(ByVal wb As Workbook)
    Dim src As Worksheet, dst As Worksheet, lastR As Long
    Set src = GetSheet(SH_WORK_DETAIL)
    Set dst = ResetCommonSheet(wb, "T_分析明細")
    lastR = LastRow(src, 1)
    dst.Range("A1:Q" & CStr(Application.Max(1, lastR))).Value = src.Range("A1:Q" & CStr(Application.Max(1, lastR))).Value
    FormatHeader dst.Range("A1:Q1")
    If lastR >= 2 Then
        FormatBody dst.Range("A2:Q" & CStr(lastR))
        dst.Range("E2:E" & CStr(lastR)).NumberFormatLocal = "yyyy/m/d"
        dst.Range("F2:F" & CStr(lastR)).NumberFormatLocal = "#,##0"
    End If
    AutoFitSheetSmart dst, "A:Q", 6, 34
End Sub

Private Function VoucherCandidateMemoText(ByVal res As Worksheet, ByVal resultRows As Object, ByVal analysisId As String) As String
    Dim autoMemo As String, opMemo As String
    autoMemo = AnalysisResultText(res, resultRows, analysisId, RES_COL_MEMO, "")
    opMemo = AnalysisResultText(res, resultRows, analysisId, RES_COL_OPERATION_MEMO, "")
    If IsDefaultOperationHint(opMemo) Then opMemo = ""
    VoucherCandidateMemoText = JoinNonBlank(autoMemo, opMemo, " / ")
End Function

Private Function IsDefaultOperationHint(ByVal memoText As String) As Boolean
    memoText = CellText(memoText)
    If Len(memoText) = 0 Then IsDefaultOperationHint = True: Exit Function
    IsDefaultOperationHint = (InStr(1, memoText, "ダブルクリックで切替", vbTextCompare) > 0)
End Function

Private Sub WriteVoucherCandidateTable(ByVal wb As Workbook)
    Dim src As Worksheet, dst As Worksheet, res As Worksheet
    Dim lastR As Long, r As Long, outR As Long
    Dim resultRows As Object, analysisId As String, decisionText As String, memoText As String
    Set src = GetSheet(SH_WORK_DETAIL)
    Set res = GetSheet(SH_WORK_RESULT)
    Set resultRows = BuildAnalysisResultRowMap(res)
    Set dst = ResetCommonSheet(wb, "T_伝票依頼候補")
    SetRowValues dst.Range("A1"), Array("伝票候補ID", "分析候補ID", "分析明細ID", "取引ID", "依頼対象日", "銀行名", "支店名", "取扱店確定値", "人物ID", "氏名", "続柄", "口座ID", "出金", "入金", "摘要", "区分", "伝票依頼", "採用", "メモ")
    FormatHeader dst.Range("A1:S1")
    lastR = LastRow(src, 1)
    outR = 2
    For r = 2 To lastR
        If CellText(src.Cells(r, DET_COL_VOUCHER).Value) = VOUCHER_YES Then
            analysisId = CellText(src.Cells(r, DET_COL_ANALYSIS_ID).Value)
            decisionText = AnalysisResultText(res, resultRows, analysisId, RES_COL_SHIFT_DECISION, DECISION_USE)
            If IsExcludeDecision(decisionText) Then GoTo NextVoucherDetail
            memoText = VoucherCandidateMemoText(res, resultRows, analysisId)
            dst.Cells(outR, 1).Value = NextId("伝票候補")
            dst.Cells(outR, 2).Value = analysisId
            dst.Cells(outR, 3).Value = src.Cells(r, DET_COL_ID).Value
            dst.Cells(outR, 4).Value = src.Cells(r, DET_COL_TX_ID).Value
            dst.Cells(outR, 5).Value = src.Cells(r, DET_COL_DATE).Value
            dst.Cells(outR, 6).Value = src.Cells(r, DET_COL_BANK).Value
            dst.Cells(outR, 7).Value = src.Cells(r, DET_COL_BRANCH).Value
            dst.Cells(outR, 8).Value = src.Cells(r, DET_COL_SHOP).Value
            dst.Cells(outR, 9).Value = src.Cells(r, DET_COL_PERSON_ID).Value
            dst.Cells(outR, 10).Value = src.Cells(r, DET_COL_PERSON_NAME).Value
            dst.Cells(outR, 11).Value = PersonRelationForCommon(src.Cells(r, DET_COL_PERSON_ID).Value)
            dst.Cells(outR, 12).Value = src.Cells(r, DET_COL_ACCOUNT_ID).Value
            If CellText(src.Cells(r, DET_COL_SIDE).Value) = "出金" Then
                dst.Cells(outR, 13).Value = src.Cells(r, DET_COL_AMOUNT).Value
            Else
                dst.Cells(outR, 14).Value = src.Cells(r, DET_COL_AMOUNT).Value
            End If
            dst.Cells(outR, 15).Value = src.Cells(r, DET_COL_SUMMARY).Value
            dst.Cells(outR, 16).Value = src.Cells(r, DET_COL_KIND).Value
            dst.Cells(outR, 17).Value = src.Cells(r, DET_COL_VOUCHER).Value
            dst.Cells(outR, 18).Value = decisionText
            dst.Cells(outR, 19).Value = memoText
            outR = outR + 1
        End If
NextVoucherDetail:
    Next r
    If outR > 2 Then
        FormatBody dst.Range("A2:S" & CStr(outR - 1))
        dst.Range("E2:E" & CStr(outR - 1)).NumberFormatLocal = "yyyy/m/d"
        dst.Range("M2:N" & CStr(outR - 1)).NumberFormatLocal = "#,##0"
    End If
    AutoFitSheetSmart dst, "A:S", 6, 34
End Sub

Private Function BuildAnalysisResultRowMap(ByVal ws As Worksheet) As Object
    Dim d As Object, lastR As Long, r As Long, idText As String
    Set d = CreateObject("Scripting.Dictionary")
    If ws Is Nothing Then Set BuildAnalysisResultRowMap = d: Exit Function
    lastR = LastRow(ws, RES_COL_ID)
    For r = 2 To lastR
        idText = CellText(ws.Cells(r, RES_COL_ID).Value)
        If Len(idText) > 0 Then d(idText) = r
    Next r
    Set BuildAnalysisResultRowMap = d
End Function

Private Function AnalysisResultText(ByVal ws As Worksheet, ByVal rowMap As Object, ByVal analysisId As String, ByVal colNo As Long, Optional ByVal defaultValue As String = "") As String
    If ws Is Nothing Or rowMap Is Nothing Then AnalysisResultText = defaultValue: Exit Function
    If Not rowMap.Exists(analysisId) Then AnalysisResultText = defaultValue: Exit Function
    AnalysisResultText = CellText(ws.Cells(CLng(rowMap(analysisId)), colNo).Value)
    If Len(AnalysisResultText) = 0 Then AnalysisResultText = defaultValue
End Function

Private Function PersonRelationForCommon(ByVal personId As Variant) As String
    Dim ws As Worksheet, lastR As Long, r As Long
    Dim colId As Long, colRel As Long
    If Not SheetExists(SH_WORK_PERSON) Then Exit Function
    Set ws = GetSheet(SH_WORK_PERSON)
    colId = FirstHeaderColumn(ws, Array("人物ID"), 1)
    colRel = FirstHeaderColumn(ws, Array("被相続人から見た続柄", "表示用続柄", "続柄"), 1)
    If colId = 0 Or colRel = 0 Then Exit Function
    lastR = LastRow(ws, colId)
    For r = 2 To lastR
        If CellText(ws.Cells(r, colId).Value) = CellText(personId) Then
            PersonRelationForCommon = CellText(ws.Cells(r, colRel).Value)
            Exit Function
        End If
    Next r
End Function

Private Function ResetCommonSheet(ByVal wb As Workbook, ByVal sheetName As String) As Worksheet
    Dim ws As Worksheet, lo As ListObject
    On Error Resume Next
    Set ws = wb.Worksheets(sheetName)
    On Error GoTo 0
    If ws Is Nothing Then
        Set ws = wb.Worksheets.Add(After:=wb.Worksheets(wb.Worksheets.Count))
        ws.Name = sheetName
    Else
        On Error Resume Next
        ws.Unprotect
        If ws.AutoFilterMode Then ws.AutoFilterMode = False
        For Each lo In ws.ListObjects
            lo.Delete
        Next lo
        ws.Cells.Clear
        On Error GoTo 0
    End If
    ws.Cells.Font.Name = "Meiryo UI"
    ws.Cells.Font.Size = 9
    Set ResetCommonSheet = ws
End Function

Private Sub BackupCommonDataBeforeUpdate(ByVal filePath As String)
    Dim backupPath As String
    If Len(filePath) = 0 Then Exit Sub
    If Len(Dir$(filePath)) = 0 Then Exit Sub
    backupPath = filePath & ".bak_" & Format$(Now, "yyyymmdd_hhnnss")
    FileCopy filePath, backupPath
End Sub

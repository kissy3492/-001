Attribute VB_Name = "modInvestigationIssues"
Option Explicit

Private Const ISSUE_FIRST_ROW As Long = 6
Private Const ISSUE_LAST_COL As Long = 10

Public Sub InitInvestigationIssueSheet(ByVal ws As Worksheet)
    ws.Cells.Clear
    SetRowValues ws.Range("A1"), Array("調査論点", "重要度", "件数", "最大金額", "代表候補ID", "関係人物", "根拠", "推奨確認", "反証・除外確認", "補足")
    FormatHeader ws.Range("A1:J1"), ThemeColor("purple")
End Sub

Public Sub BuildInvestigationIssueSheet(Optional ByVal silent As Boolean = False)
    Dim wsSrc As Worksheet, wsOut As Worksheet, issues As Object
    Dim lastR As Long, r As Long, outR As Long, k As Variant, item As Object

    If Not SheetExists(SH_ISSUE) Then GetOrCreateSheet SH_ISSUE, True
    Set wsOut = GetSheet(SH_ISSUE)

    On Error Resume Next
    wsOut.Unprotect Password:=TOOL_PASSWORD
    wsOut.Cells.UnMerge
    wsOut.Cells.Clear
    DeleteAllShapes wsOut
    On Error GoTo 0

    ThemeApplyCanvas wsOut
    wsOut.Cells.Font.Name = "Meiryo UI"
    wsOut.Cells.Font.Size = 10

    wsOut.Range("A1:J1").Merge
    wsOut.Range("A1").Value = "03_資金移動分析ツール・調査論点サマリ"
    ThemeApplyTitle wsOut.Range("A1"), "03_資金移動分析ツール・調査論点サマリ"
    wsOut.Rows(1).RowHeight = 34

    wsOut.Range("A3:J4").Merge
    wsOut.Range("A3").Value = "分析結果を税務調査上の論点別に集約します。ここは判定結果ではなく、伝票依頼・事実確認の優先順位を決めるための確認リストです。"
    With wsOut.Range("A3")
        .Interior.Color = ThemeColor("section")
        .Font.Color = ThemeColor("header")
        .Font.Bold = True
        .WrapText = True
        .VerticalAlignment = xlCenter
    End With

    SetRowValues wsOut.Cells(ISSUE_FIRST_ROW, 1), Array("調査論点", "重要度", "件数", "最大金額", "代表候補ID", "関係人物", "根拠", "推奨確認", "反証・除外確認", "補足")
    FormatHeader wsOut.Range(wsOut.Cells(ISSUE_FIRST_ROW, 1), wsOut.Cells(ISSUE_FIRST_ROW, ISSUE_LAST_COL)), ThemeColor("purple")

    Set issues = CreateObject("Scripting.Dictionary")

    If SheetExists(SH_WORK_RESULT) Then
        Set wsSrc = GetSheet(SH_WORK_RESULT)
        lastR = LastRow(wsSrc, RES_COL_ID)
        For r = 2 To lastR
            AddIssuesFromResultRow wsSrc, r, issues
        Next r
    End If

    outR = ISSUE_FIRST_ROW + 1
    For Each k In issues.Keys
        Set item = issues(k)
        wsOut.Cells(outR, 1).Value = CStr(k)
        wsOut.Cells(outR, 2).Value = SeverityLabel(CLng(item("Severity")))
        wsOut.Cells(outR, 3).Value = CLng(item("Count"))
        wsOut.Cells(outR, 4).Value = CDbl(item("MaxAmount"))
        wsOut.Cells(outR, 5).Value = CStr(item("Ids"))
        wsOut.Cells(outR, 6).Value = CStr(item("People"))
        wsOut.Cells(outR, 7).Value = CStr(item("Evidence"))
        wsOut.Cells(outR, 8).Value = CStr(item("Action"))
        wsOut.Cells(outR, 9).Value = CStr(item("Refute"))
        wsOut.Cells(outR, 10).Value = CStr(item("Note"))
        outR = outR + 1
    Next k

    If outR = ISSUE_FIRST_ROW + 1 Then
        wsOut.Cells(outR, 1).Value = "現時点で強い調査論点は検出されていません。"
        wsOut.Cells(outR, 8).Value = "金額下限・日付許容・不明入出金下限を見直すか、入力データ範囲を確認してください。"
        outR = outR + 1
    End If

    If outR > ISSUE_FIRST_ROW + 2 Then
        With wsOut.Sort
            .SortFields.Clear
            .SortFields.Add Key:=wsOut.Range("B" & CStr(ISSUE_FIRST_ROW + 1) & ":B" & CStr(outR - 1)), SortOn:=xlSortOnValues, Order:=xlAscending, DataOption:=xlSortNormal
            .SortFields.Add Key:=wsOut.Range("D" & CStr(ISSUE_FIRST_ROW + 1) & ":D" & CStr(outR - 1)), SortOn:=xlSortOnValues, Order:=xlDescending, DataOption:=xlSortNormal
            .SetRange wsOut.Range("A" & CStr(ISSUE_FIRST_ROW) & ":J" & CStr(outR - 1))
            .Header = xlYes
            .Apply
        End With
    End If

    FormatIssueSheet wsOut, outR - 1
    wsOut.Visible = xlSheetVisible
    If Not silent Then
        wsOut.Activate
        MsgBox "調査論点サマリを作成しました。", vbInformation
    End If
End Sub

Private Sub AddIssuesFromResultRow(ByVal ws As Worksheet, ByVal r As Long, ByVal issues As Object)
    Dim combined As String, kindText As String, voucherText As String
    Dim amountValue As Double, candidateId As String, peopleText As String, scoreValue As Long, evidenceText As String

    candidateId = CellText(ws.Cells(r, RES_COL_ID).Value)
    kindText = CellText(ws.Cells(r, RES_COL_KIND).Value)
    voucherText = CellText(ws.Cells(r, RES_COL_VOUCHER).Value)
    scoreValue = NzLong(ws.Cells(r, RES_COL_SCORE).Value, 0)
    amountValue = Application.Max(NzDbl(ws.Cells(r, RES_COL_OUT_AMOUNT).Value, 0), NzDbl(ws.Cells(r, RES_COL_IN_AMOUNT).Value, 0))
    peopleText = JoinNonBlank(CellText(ws.Cells(r, RES_COL_OUT_PERSON).Value), CellText(ws.Cells(r, RES_COL_IN_PERSON).Value), " → ")
    combined = JoinNonBlank(CellText(ws.Cells(r, RES_COL_KIND).Value), CellText(ws.Cells(r, RES_COL_PATTERN).Value), " / ")
    combined = JoinNonBlank(combined, CellText(ws.Cells(r, RES_COL_NAME_REL).Value), " / ")
    combined = JoinNonBlank(combined, CellText(ws.Cells(r, RES_COL_INH_TIMING).Value), " / ")
    combined = JoinNonBlank(combined, CellText(ws.Cells(r, RES_COL_COHAB).Value), " / ")
    combined = JoinNonBlank(combined, CellText(ws.Cells(r, RES_COL_SUMMARY).Value), " / ")
    combined = JoinNonBlank(combined, CellText(ws.Cells(r, RES_COL_AGE_HINT).Value), " / ")
    combined = JoinNonBlank(combined, CellText(ws.Cells(r, RES_COL_ADDRESS_HINT).Value), " / ")
    evidenceText = IssueEvidenceText(ws, r, candidateId, peopleText, amountValue, scoreValue)

    If InStr(combined, "死亡後取引") > 0 Or InStr(combined, "被相続人の相続後出金") > 0 Or InStr(combined, "相続関連シフト") > 0 Then
        AddIssue issues, "死亡後・相続開始後の資金移動", 1, amountValue, candidateId, peopleText, evidenceText, "伝票依頼を優先。相続開始後の払戻・出金の使途、受領者、申告反映を確認。", "葬儀費・医療費・公共料金精算など正当使途、遺産分割前後の管理者、申告済財産との照合。", "相続開始後の被相続人口座出金や死亡後取引は、事実確認の優先度が高い。"
    End If
    If InStr(combined, "暦年贈与加算") > 0 Then
        AddIssue issues, "暦年贈与加算期間内の資金移動", 1, amountValue, candidateId, peopleText, evidenceText, "贈与税申告、相続税申告への加算、受贈者、資金原資を確認。", "貸付返済・生活費通常範囲・教育費等の非課税性、申告書・契約書・領収書との突合。", "税制改正の経過措置を踏まえ、相続開始日に応じた対象期間で機械判定。"
    End If
    If InStr(combined, "死亡直前大口出金") > 0 Or InStr(combined, "相続直前大口出金") > 0 Or InStr(combined, "相続前1年内大口出金") > 0 Then
        AddIssue issues, "相続直前・相続前1年内の大口出金", 1, amountValue, candidateId, peopleText, evidenceText, "現金残、葬儀費用、医療・介護費、贈与・移動先を確認。", "領収書・請求書・葬儀費明細・医療介護支払・死亡時手許現金への反映。", "対応入金がなくても、現金手渡し・現金保有・使途不明の論点になりやすい。"
    End If
    If InStr(combined, "20歳未満") > 0 Or InStr(combined, "若年注意") > 0 Or InStr(combined, "若年者高額") > 0 Then
        AddIssue issues, "20歳未満名義の高額取引", 2, amountValue, candidateId, peopleText, evidenceText, "本人管理能力、親権者・同居者による管理、贈与契約・資金原資を確認。", "本人の収入・通帳保管者・入出金手続者・親族による代理操作の有無。", "成人年齢18歳とは別に、20歳未満を調査上の注意区切りとして表示。"
    End If
    If InStr(combined, "転居前後") > 0 Then
        AddIssue issues, "転居前後の高額入出金", 2, amountValue, candidateId, peopleText, evidenceText, "引越し費用、住宅関連費、生活支援、誰が負担した資金かを確認。", "賃貸初期費用・住宅関連領収書・本人負担額・被相続人からの援助性を確認。", "転居者本人・被相続人・親族関係者に限定してノイズを抑制。"
    End If
    If InStr(combined, "婚姻前後") > 0 Or InStr(combined, "出生前後") > 0 Then
        AddIssue issues, "婚姻・出生前後の資金移動", 2, amountValue, candidateId, peopleText, evidenceText, "婚姻費用、出産・育児費、生活支援、贈与性の有無を確認。", "社会通念上相当な生活費・扶養義務範囲・実際の支払先を確認。", "01で既に入力されている婚姻日・生年月日を使い、追加入力なしで抽出。"
    End If
    If InStr(combined, "名義外管理") > 0 Or InStr(combined, "同日時刻付近") > 0 Or InStr(combined, "類似時刻帯") > 0 Then
        AddIssue issues, "名義外管理・一括管理の疑い", 2, amountValue, candidateId, peopleText, evidenceText, "同時刻帯の複数名義口座操作、取扱店、通帳・印鑑・カード管理者を確認。", "本人来店・ATM利用者・取扱店・機番・カード保管者が別々に説明できるか確認。", "金額一致がなくても、同時刻付近に複数名義口座が動く場合は管理実態の確認価値が高い。"
    End If
    If InStr(combined, "取引明細残高急減") > 0 Or InStr(combined, "取引明細残高急増") > 0 Then
        AddIssue issues, "取引明細残高による残高急変", 2, amountValue, candidateId, peopleText, evidenceText, "取引後残高、直前残高、出金・入金の実質負担者、現金残を確認。", "外部資金操作表13列目が取引後残高であること、残高欄欠落・貸越・訂正明細の有無を確認。", "明示列『取引後残高』を優先し、旧形式はその他欄から後方互換判定。"
    End If
    If kindText = KIND_UNKNOWN_OUT Then
        AddIssue issues, "対応入金がない不明出金", 3, amountValue, candidateId, peopleText, evidenceText, "使途、現金残、後日分割入金の有無を確認。必要に応じて不明出金追跡を実行。", "生活費・医療費・ATM小口反復・現金保管・後日親族口座入金の有無を確認。", "通常分析では拾えない現金手渡し後の時期ずれ入金を、選択実行で追跡可能。"
    ElseIf kindText = KIND_UNKNOWN_IN Then
        AddIssue issues, "対応出金がない不明入金", 3, amountValue, candidateId, peopleText, evidenceText, "入金原資、贈与・返済・給与・保険等の性質を確認。", "給与・年金・保険・借入・返済・本人資金など、課税関係のない原資で説明できるか確認。", "被相続人側出金と直接一致しない入金も、資金原資確認の対象。"
    End If
    If voucherText = VOUCHER_YES And scoreValue >= 70 Then
        AddIssue issues, "高信頼・伝票依頼優先候補", 3, amountValue, candidateId, peopleText, evidenceText, "伝票依頼候補として採用状態と依頼先を確認。", "候補除外・取引除外メモ、取扱店確定値、依頼先混在がないか確認。", "スコア高めかつ伝票要のため、依頼表作成前の最終確認対象。"
    End If
End Sub


Private Function IssueEvidenceText(ByVal ws As Worksheet, ByVal r As Long, ByVal candidateId As String, ByVal peopleText As String, ByVal amountValue As Double, ByVal scoreValue As Long) As String
    Dim core As String
    core = candidateId & " / " & peopleText & " / 金額" & Format$(amountValue, "#,##0") & "円 / 信頼度" & CStr(scoreValue)
    core = JoinNonBlank(core, ClipText(CellText(ws.Cells(r, RES_COL_PATTERN).Value), 45), " / ")
    core = JoinNonBlank(core, ClipText(CellText(ws.Cells(r, RES_COL_SUMMARY).Value), 70), " / ")
    IssueEvidenceText = core
End Function

Private Sub AddIssue(ByVal issues As Object, ByVal issueKey As String, ByVal severity As Long, ByVal amountValue As Double, ByVal candidateId As String, ByVal peopleText As String, ByVal evidenceText As String, ByVal actionText As String, ByVal refuteText As String, ByVal noteText As String)
    Dim item As Object
    If issues.Exists(issueKey) Then
        Set item = issues(issueKey)
    Else
        Set item = CreateObject("Scripting.Dictionary")
        item("Severity") = severity
        item("Count") = 0
        item("MaxAmount") = 0#
        item("Ids") = ""
        item("People") = ""
        item("Evidence") = evidenceText
        item("Action") = actionText
        item("Refute") = refuteText
        item("Note") = noteText
        issues.Add issueKey, item
    End If
    item("Count") = CLng(item("Count")) + 1
    If amountValue > CDbl(item("MaxAmount")) Then item("MaxAmount") = amountValue
    item("Ids") = AppendLimitedToken(CStr(item("Ids")), candidateId, 12)
    item("People") = AppendLimitedToken(CStr(item("People")), ClipText(peopleText, 30), 8)
    item("Evidence") = AppendLimitedToken(CStr(item("Evidence")), ClipText(evidenceText, 80), 6)
    If severity < CLng(item("Severity")) Then item("Severity") = severity
End Sub

Private Function AppendLimitedToken(ByVal existingText As String, ByVal tokenText As String, ByVal maxTokens As Long) As String
    If Len(tokenText) = 0 Then AppendLimitedToken = existingText: Exit Function
    If InStr(1, "|" & existingText & "|", "|" & tokenText & "|", vbTextCompare) > 0 Then AppendLimitedToken = existingText: Exit Function
    If Len(existingText) = 0 Then
        AppendLimitedToken = tokenText
    ElseIf UBound(Split(existingText, " / ")) + 1 < maxTokens Then
        AppendLimitedToken = existingText & " / " & tokenText
    ElseIf Right$(existingText, 3) <> "..." Then
        AppendLimitedToken = existingText & " / ..."
    Else
        AppendLimitedToken = existingText
    End If
End Function

Private Function SeverityLabel(ByVal severity As Long) As String
    Select Case severity
        Case 1: SeverityLabel = "A_最優先"
        Case 2: SeverityLabel = "B_重点"
        Case 3: SeverityLabel = "C_確認"
        Case Else: SeverityLabel = "D_参考"
    End Select
End Function

Private Sub FormatIssueSheet(ByVal ws As Worksheet, ByVal lastR As Long)
    If lastR < ISSUE_FIRST_ROW Then lastR = ISSUE_FIRST_ROW
    ws.Columns("A:A").ColumnWidth = 24
    ws.Columns("B:B").ColumnWidth = 12
    ws.Columns("C:C").ColumnWidth = 8
    ws.Columns("D:D").ColumnWidth = 14
    ws.Columns("E:E").ColumnWidth = 22
    ws.Columns("F:F").ColumnWidth = 28
    ws.Columns("G:G").ColumnWidth = 44
    ws.Columns("H:H").ColumnWidth = 40
    ws.Columns("I:I").ColumnWidth = 42
    ws.Columns("J:J").ColumnWidth = 38
    ws.Range(ws.Cells(ISSUE_FIRST_ROW, 1), ws.Cells(lastR, ISSUE_LAST_COL)).Borders.LineStyle = xlContinuous
    ws.Range(ws.Cells(ISSUE_FIRST_ROW, 1), ws.Cells(lastR, ISSUE_LAST_COL)).Borders.Color = ThemeColor("border")
    ws.Range(ws.Cells(ISSUE_FIRST_ROW + 1, 1), ws.Cells(lastR, ISSUE_LAST_COL)).WrapText = True
    ws.Range(ws.Cells(ISSUE_FIRST_ROW + 1, 1), ws.Cells(lastR, ISSUE_LAST_COL)).VerticalAlignment = xlTop
    ws.Range(ws.Cells(ISSUE_FIRST_ROW + 1, 4), ws.Cells(lastR, 4)).NumberFormatLocal = "#,##0"
    If lastR >= ISSUE_FIRST_ROW + 1 Then ws.Rows(CStr(ISSUE_FIRST_ROW + 1) & ":" & CStr(lastR)).RowHeight = 52
    ThemeApplyPrintTable ws.Range("A" & CStr(ISSUE_FIRST_ROW) & ":J" & CStr(lastR)), 1
    ThemeCapRowHeights ws.Range("A" & CStr(ISSUE_FIRST_ROW + 1) & ":J" & CStr(lastR)), 26, 96
    ThemeApplyMonochromePrint ws, ws.Range("A1:J" & CStr(lastR)).Address, True, "$" & CStr(ISSUE_FIRST_ROW) & ":$" & CStr(ISSUE_FIRST_ROW), 1, 0
    ws.Range("A" & CStr(ISSUE_FIRST_ROW) & ":J" & CStr(lastR)).AutoFilter
    ws.Activate
    ActiveWindow.FreezePanes = False
    ws.Range("A" & CStr(ISSUE_FIRST_ROW + 1)).Select
    ActiveWindow.FreezePanes = True
    On Error Resume Next
    ThemePrepareSheetForProtection ws
    ws.Protect Password:=TOOL_PASSWORD, UserInterfaceOnly:=True, DrawingObjects:=True, Contents:=True, Scenarios:=True, AllowFiltering:=True, AllowSorting:=True
    ws.EnableSelection = xlNoRestrictions
    On Error GoTo 0
End Sub

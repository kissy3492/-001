Attribute VB_Name = "modAppState"
Option Explicit

Private mStateActive As Boolean
Private mStateDepth As Long
Private mPrevEvents As Boolean
Private mPrevScreenUpdating As Boolean
Private mPrevDisplayAlerts As Boolean
Private mPrevCalculation As XlCalculation
Private mPrevStatusBar As Variant

Public Sub AppBegin(Optional ByVal statusText As String = "処理中...")
    '重い処理の前後でExcel状態を安全に制御する。
    'v9: 入れ子呼出しに対応。内側のAppEndで外側処理中に設定が復旧しないようにする。
    On Error Resume Next
    If mStateDepth = 0 Then
        mPrevEvents = Application.EnableEvents
        mPrevScreenUpdating = Application.ScreenUpdating
        mPrevDisplayAlerts = Application.DisplayAlerts
        mPrevCalculation = Application.Calculation
        mPrevStatusBar = Application.StatusBar
        mStateActive = True
    End If
    mStateDepth = mStateDepth + 1
    Application.EnableEvents = False
    Application.ScreenUpdating = False
    Application.DisplayAlerts = False
    Application.Calculation = xlCalculationManual
    Application.StatusBar = statusText
    On Error GoTo 0
End Sub

Public Sub AppEnd()
    On Error Resume Next
    If mStateDepth > 1 Then
        mStateDepth = mStateDepth - 1
        Exit Sub
    End If
    mStateDepth = 0

    If mStateActive Then
        Application.EnableEvents = mPrevEvents
        Application.ScreenUpdating = mPrevScreenUpdating
        Application.DisplayAlerts = mPrevDisplayAlerts
        Application.Calculation = mPrevCalculation
        Application.StatusBar = mPrevStatusBar
    Else
        Application.EnableEvents = True
        Application.ScreenUpdating = True
        Application.DisplayAlerts = True
        Application.StatusBar = False
    End If
    mStateActive = False
    On Error GoTo 0
End Sub

Public Sub AppForceRestore()
    'エラー・中断時の緊急復旧。Tab制御とExcel状態を必ず通常に戻す。
    On Error Resume Next
    DisableInputKeys
    mStateDepth = 0
    mStateActive = False
    Application.EnableEvents = True
    Application.ScreenUpdating = True
    Application.DisplayAlerts = True
    Application.Calculation = xlCalculationAutomatic
    Application.StatusBar = False
    On Error GoTo 0
End Sub

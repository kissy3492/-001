Attribute VB_Name = "modUtilities"
Option Explicit

Public Function SheetExists(ByVal sheetName As String) As Boolean
    Dim ws As Worksheet
    On Error Resume Next
    Set ws = ThisWorkbook.Worksheets(sheetName)
    SheetExists = Not ws Is Nothing
    On Error GoTo 0
End Function

Public Function GetSheet(ByVal sheetName As String) As Worksheet
    Dim ws As Worksheet
    On Error Resume Next
    Set ws = ThisWorkbook.Worksheets(sheetName)
    On Error GoTo 0
    If ws Is Nothing Then
        Err.Raise vbObjectError + 1001, "GetSheet", "シート「" & sheetName & "」が見つかりません。SetupWorkbookを実行してください。"
    End If
    Set GetSheet = ws
End Function

Public Function GetOrCreateSheet(ByVal sheetName As String, Optional ByVal resetSheet As Boolean = False) As Worksheet
    Dim ws As Worksheet
    On Error GoTo EH
    If SheetExists(sheetName) Then
        Set ws = ThisWorkbook.Worksheets(sheetName)
    Else
        Set ws = ThisWorkbook.Worksheets.Add(After:=ThisWorkbook.Worksheets(ThisWorkbook.Worksheets.Count))
        ws.Name = sheetName
    End If
    If ws Is Nothing Then Err.Raise vbObjectError + 1002, "GetOrCreateSheet", "シート取得に失敗しました: " & sheetName
    On Error Resume Next
    ws.Visible = xlSheetVisible
    On Error GoTo EH
    If resetSheet Then ResetWorksheet ws
    Set GetOrCreateSheet = ws
    Exit Function
EH:
    Err.Raise Err.Number, "GetOrCreateSheet(" & sheetName & ")", Err.Description
End Function

Public Sub ResetWorksheet(ByVal ws As Worksheet)
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    ws.Unprotect Password:=TOOL_PASSWORD
    DeleteToolShapes ws, True
    ws.Cells.UnMerge
    ws.Cells.Clear
    ws.Cells.ClearFormats
    ws.Cells.Validation.Delete
    ws.Cells.Locked = False
    On Error GoTo 0
End Sub

Public Sub DeleteToolShapes(ByVal ws As Worksheet, Optional ByVal deleteAll As Boolean = False)
    'ツールが作成した図形だけを削除する。
    '図形保護を有効にしているため、再生成前には必ず保護解除してから削除する。
    Dim i As Long
    Dim nm As String
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    ws.Unprotect Password:=TOOL_PASSWORD
    For i = ws.Shapes.Count To 1 Step -1
        nm = ws.Shapes(i).Name
        If deleteAll Or Left$(nm, Len(UI_PREFIX)) = UI_PREFIX Then ws.Shapes(i).Delete
    Next i
    On Error GoTo 0
End Sub

Public Sub LockToolShapes(ByVal ws As Worksheet)
    '図形ボタンやカード背景を誤って移動・サイズ変更しないようにする。
    '白背景＋白文字のような読みにくい図形文字色もここで補正する。
    Dim shp As Shape
    Dim fillColor As Long
    Dim fontColor As Long

    If ws Is Nothing Then Exit Sub
    ThemeLockShapeLayer ws
    On Error Resume Next
    For Each shp In ws.Shapes
        If Left$(shp.Name, Len(UI_PREFIX)) = UI_PREFIX Then
            shp.Locked = True
            shp.Placement = xlFreeFloating
            fillColor = shp.Fill.ForeColor.RGB
            fontColor = shp.TextFrame.Characters.Font.Color
            If IsLightExcelColor(fillColor) And IsLightExcelColor(fontColor) Then
                shp.TextFrame.Characters.Font.Color = ThemeColor("text")
            End If
        End If
    Next shp
    On Error GoTo 0
End Sub

Public Sub ResetName(ByVal nm As String, ByVal rng As Range)
    Dim refText As String
    If rng Is Nothing Then Exit Sub
    On Error Resume Next
    ThisWorkbook.Names(nm).Delete
    Err.Clear
    refText = "='" & Replace(rng.Worksheet.Name, "'", "''") & "'!" & rng.Address(True, True, xlA1, False)
    ThisWorkbook.Names.Add Name:=nm, RefersTo:=refText
    On Error GoTo 0
End Sub

Public Function MacroRef(ByVal macroName As String) As String
    '図形ボタンが別ブックの同名マクロを拾わないよう、このブックへ明示的に紐づける。
    MacroRef = "'" & Replace(ThisWorkbook.Name, "'", "''") & "'!" & macroName
End Function

Public Sub SetRowValues(ByVal firstCell As Range, ByVal values As Variant)
    '1次元ArrayをRangeへ直接代入する環境差を避け、横方向に確実に書き込む。
    Dim i As Long
    If firstCell Is Nothing Then Exit Sub
    For i = LBound(values) To UBound(values)
        firstCell.Offset(0, i - LBound(values)).Value = values(i)
    Next i
End Sub

Public Sub CapBalanceCollections(ByRef labels As Collection, ByRef dates As Collection, ByVal maxItems As Long)
    Dim newLabels As Collection
    Dim newDates As Collection
    Dim i As Long
    If labels Is Nothing Or dates Is Nothing Then Exit Sub
    If maxItems <= 0 Then Exit Sub
    If labels.Count <= maxItems Then Exit Sub
    Set newLabels = New Collection
    Set newDates = New Collection
    For i = 1 To maxItems
        newLabels.Add labels(i)
        newDates.Add dates(i)
    Next i
    Set labels = newLabels
    Set dates = newDates
End Sub

Public Function BalanceInputLabelDisplay(ByVal labelText As String) As String
    Dim s As String
    s = CellText(labelText)
    s = Replace(s, "相続開始日時点残高（", "相続開始日時点" & vbLf & "残高（")
    s = Replace(s, "年末・相続開始日時点残高（", "年末・相続開始日時点" & vbLf & "残高（")
    BalanceInputLabelDisplay = s
End Function

Public Function BalanceTekiyoLabel(ByVal labelText As String) As String
    '資金操作表の摘要欄用。日付欄に基準日があるため、摘要欄には具体日付を出さない。
    Dim s As String
    Dim p As Long
    s = CellText(labelText)
    s = Replace(s, vbCrLf, "")
    s = Replace(s, vbCr, "")
    s = Replace(s, vbLf, "")
    p = InStr(1, s, "（", vbTextCompare)
    If p > 0 And InStr(1, s, "残高", vbTextCompare) > 0 Then s = Left$(s, p - 1)
    BalanceTekiyoLabel = s
End Function


Public Sub ApplyReadablePrintSettings(ByVal ws As Worksheet, Optional ByVal titleRows As String = "")
    '印刷時は横1ページ固定。ボタンを印刷せず、白黒でも読める帳票設定にする。
    Dim lastR As Long, lastC As Long
    If ws Is Nothing Then Exit Sub
    lastR = LastUsedRowInSheet(ws)
    If lastR < 1 Then lastR = 1
    lastC = LastUsedColumnInSheet(ws, lastR)
    If lastC < 1 Then lastC = 1
    ThemeApplyMonochromePrint ws, ws.Range(ws.Cells(1, 1), ws.Cells(lastR, lastC)).Address, True, titleRows, 1, 0
End Sub

Public Sub FormatCashOperationOutputLayout(ByVal ws As Worksheet)
    Dim lastR As Long
    Dim rng As Range
    Dim r As Long
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    lastR = LastUsedRowInSheet(ws)
    If lastR < 1 Then lastR = 1

    Set rng = ws.Range("A1:M" & lastR)
    With rng
        .Font.Name = "Meiryo UI"
        .Font.Size = 14
        .VerticalAlignment = xlCenter
        .Borders.LineStyle = xlContinuous
        .Borders.Color = ThemeColor("border-soft")
    End With

    FormatOutputHeader ws.Range("A1:M1")
    ws.Rows(1).RowHeight = 34

    ws.Columns("A:A").ColumnWidth = 20
    ws.Columns("B:B").ColumnWidth = 20
    ws.Columns("C:C").ColumnWidth = 18
    ws.Columns("D:D").ColumnWidth = 12
    ws.Columns("E:E").ColumnWidth = 17
    ws.Columns("F:F").ColumnWidth = 19
    ws.Columns("G:G").ColumnWidth = 11
    ws.Columns("H:I").ColumnWidth = 14
    ws.Columns("J:J").ColumnWidth = 20
    ws.Columns("K:K").ColumnWidth = 11
    ws.Columns("L:L").ColumnWidth = 26
    ws.Columns("M:M").ColumnWidth = 17

    ws.Columns("A:G").HorizontalAlignment = xlCenter
    ws.Columns("J:K").HorizontalAlignment = xlCenter
    ws.Columns("H:I").HorizontalAlignment = xlRight
    ws.Columns("L:L").HorizontalAlignment = xlLeft
    ws.Columns("M:M").HorizontalAlignment = xlRight
    ws.Columns("A:M").VerticalAlignment = xlCenter
    ws.Columns("L:M").WrapText = True

    '列単位の配置設定はヘッダーの中央揃えを上書きするため、最後にヘッダーだけ再適用する。
    FormatOutputHeader ws.Range("A1:M1")
    With ws.Range("A1:M1")
        .HorizontalAlignment = xlCenter
        .VerticalAlignment = xlCenter
        .WrapText = False
    End With

    ws.Columns("F:F").NumberFormatLocal = "yyyy/m/d"
    ws.Columns("G:G").NumberFormatLocal = "hh:mm"
    ws.Columns("H:I").NumberFormatLocal = "#,##0"
    ws.Columns("M:M").NumberFormatLocal = "#,##0"

    If lastR >= 2 Then
        ws.Rows("2:" & lastR).RowHeight = 30
        '残高行は摘要欄も中央にし、行全体を見やすくする。
        For r = 2 To lastR
            If InStr(1, CellText(ws.Cells(r, OUT_COL_TEKIYO).Value), "残高", vbTextCompare) > 0 Then
                ws.Cells(r, OUT_COL_TEKIYO).Value = BalanceTekiyoLabel(ws.Cells(r, OUT_COL_TEKIYO).Value)
                ws.Cells(r, OUT_COL_TEKIYO).HorizontalAlignment = xlCenter
                ws.Cells(r, OUT_COL_OTHER).HorizontalAlignment = xlRight
                ws.Rows(r).RowHeight = 30
            ElseIf CellText(ws.Cells(r, OUT_COL_TEKIYO).Value) = "相続開始日" Then
                ws.Range("A" & r & ":M" & r).Interior.Color = ThemeColor("warning-soft")
                ws.Range("A" & r & ":M" & r).Font.Color = ThemeColor("warning-text")
                ws.Range("A" & r & ":M" & r).Font.Bold = True
                '日付欄は太字だと幅不足で ##### になりやすい。行は色で強調し、日付セルだけ通常太さに戻す。
                ws.Cells(r, OUT_COL_DATE).Font.Bold = False
                ws.Cells(r, OUT_COL_DATE).HorizontalAlignment = xlCenter
                ws.Cells(r, OUT_COL_TEKIYO).HorizontalAlignment = xlCenter
                ws.Rows(r).RowHeight = 32
            End If
        Next r
    End If

    ThemeApplyPrintTable ws.Range("A1:M" & CStr(lastR)), 1
    ThemeCapRowHeights ws.Range("A2:M" & CStr(lastR)), 22, 64
    ApplyReadablePrintSettings ws, "$1:$1"
    FixUnreadableWhiteTextOnSheet ws
    On Error GoTo 0
End Sub


Public Sub FormatBalanceTransitionOutputLayout(ByVal ws As Worksheet)
    Dim lastR As Long, lastC As Long
    Dim r As Long, c As Long
    Dim fullRange As Range, rowRange As Range
    Dim isDataRow As Boolean
    Dim headerRows As Collection, headerRow As Variant
    If ws Is Nothing Then Exit Sub
    On Error GoTo SafeExit

    lastR = LastRow(ws, 1)
    lastC = LastUsedColumnInSheet(ws, lastR)
    If lastR < 1 Then Exit Sub
    If lastC < 7 Then lastC = 7
    Set headerRows = New Collection

    Set fullRange = ws.Range(ws.Cells(1, 1), ws.Cells(lastR, lastC))
    With fullRange
        .Font.Name = "Meiryo UI"
        .Font.Size = 14
        .Font.Color = ThemeColor("text")
        .VerticalAlignment = xlCenter
        .Interior.Pattern = xlSolid
        .Interior.Color = vbWhite
        .Borders.LineStyle = xlNone
    End With

    'タイトルは、表本体と混ざらないよう下線だけで区切る。
    With ws.Range(ws.Cells(1, 1), ws.Cells(1, lastC))
        .Interior.Color = ThemeColor("canvas")
        .Borders(xlEdgeBottom).LineStyle = xlContinuous
        .Borders(xlEdgeBottom).Color = ThemeColor("blue")
        .Borders(xlEdgeBottom).Weight = xlMedium
    End With
    With ws.Cells(1, 1)
        .Font.Bold = True
        .Font.Size = 18
        .Font.Color = ThemeColor("blue")
        .HorizontalAlignment = xlLeft
    End With
    ws.Rows(1).RowHeight = 34

    For r = 2 To lastR
        Set rowRange = ws.Range(ws.Cells(r, 1), ws.Cells(r, lastC))

        If IsBalanceTransitionPersonRow(ws, r) Then
            With rowRange
                .Interior.Color = ThemeColor("section")
                .Font.Bold = True
                .Font.Color = ThemeColor("blue")
                .Borders(xlEdgeTop).LineStyle = xlContinuous
                .Borders(xlEdgeTop).Color = ThemeColor("info-border-strong")
                .Borders(xlEdgeTop).Weight = xlMedium
                .Borders(xlEdgeBottom).LineStyle = xlContinuous
                .Borders(xlEdgeBottom).Color = ThemeColor("info-border")
                .Borders(xlEdgeBottom).Weight = xlMedium
            End With
            ws.Cells(r, 1).HorizontalAlignment = xlLeft
            If ws.Rows(r).RowHeight < 34 Then ws.Rows(r).RowHeight = 34

        ElseIf CellText(ws.Cells(r, 1).Value) = "銀行名" Then
            headerRows.Add r
            With rowRange
                .Interior.Color = ThemeColor("blue")
                .Font.Bold = True
                .Font.Color = vbWhite
                .HorizontalAlignment = xlCenter
                .VerticalAlignment = xlCenter
                .WrapText = True
                .ShrinkToFit = False
                .Borders.LineStyle = xlContinuous
                .Borders.Color = ThemeColor("blue")
                .Borders.Weight = xlThin
                .Borders(xlEdgeTop).Weight = xlMedium
                .Borders(xlEdgeBottom).Weight = xlMedium
            End With
            '相続開始日時点残高など2行表示の見出しが隠れないよう高めに固定。
            ws.Rows(r).RowHeight = 72

        ElseIf CellText(ws.Cells(r, 1).Value) = "合計" Then
            With rowRange
                .Interior.Color = ThemeColor("success-soft")
                .Font.Bold = True
                .Font.Color = ThemeColor("success-text")
                .Borders.LineStyle = xlContinuous
                .Borders.Color = ThemeColor("success-border")
                .Borders.Weight = xlThin
                .Borders(xlEdgeTop).Color = ThemeColor("green")
                .Borders(xlEdgeTop).Weight = xlMedium
            End With
            If ws.Rows(r).RowHeight < 32 Then ws.Rows(r).RowHeight = 32

        ElseIf CellText(ws.Cells(r, 1).Value) = "前年比" Then
            With rowRange
                .Interior.Color = ThemeColor("locked")
                .Font.Bold = True
                .Font.Color = ThemeColor("muted-strong")
                .Borders.LineStyle = xlContinuous
                .Borders.Color = ThemeColor("border-soft")
                .Borders.Weight = xlThin
                .Borders(xlEdgeBottom).Color = ThemeColor("line-muted")
                .Borders(xlEdgeBottom).Weight = xlMedium
            End With
            If ws.Rows(r).RowHeight < 31 Then ws.Rows(r).RowHeight = 31

        Else
            isDataRow = False
            For c = 1 To lastC
                If HasText(ws.Cells(r, c).Value) Then isDataRow = True: Exit For
            Next c
            If isDataRow Then
                If r Mod 2 = 0 Then
                    rowRange.Interior.Color = vbWhite
                Else
                    rowRange.Interior.Color = ThemeColor("canvas")
                End If
                With rowRange.Borders
                    .LineStyle = xlContinuous
                    .Color = ThemeColor("border-soft")
                    .Weight = xlThin
                End With
                FormatNonexistentBalanceCells ws, r, 7, lastC - 1
                If ws.Rows(r).RowHeight < 30 Then ws.Rows(r).RowHeight = 30
            Else
                '人物と人物の間の空白行には罫線を一切残さない。
                rowRange.Borders.LineStyle = xlNone
                rowRange.Interior.Color = vbWhite
                ws.Rows(r).RowHeight = 12
            End If
        End If
    Next r

    '列幅・配置。口座情報、残高、メモの3ブロックが分かるようにする。
    ws.Columns("A:A").ColumnWidth = 22
    ws.Columns("B:B").ColumnWidth = 22
    ws.Columns("C:C").ColumnWidth = 14
    ws.Columns("D:D").ColumnWidth = 18
    ws.Columns("E:F").ColumnWidth = 16
    For c = 7 To lastC - 1
        ws.Columns(c).ColumnWidth = 22
        ws.Columns(c).NumberFormatLocal = "#,##0"
        ws.Columns(c).WrapText = True
    Next c
    ws.Columns(lastC).ColumnWidth = 48

    ws.Range(ws.Cells(1, 1), ws.Cells(lastR, lastC)).VerticalAlignment = xlCenter
    ws.Range(ws.Cells(1, 1), ws.Cells(lastR, 6)).HorizontalAlignment = xlCenter
    If lastC > 7 Then ws.Range(ws.Cells(1, 7), ws.Cells(lastR, lastC - 1)).HorizontalAlignment = xlRight
    ws.Columns(lastC).HorizontalAlignment = xlLeft
    ws.Columns(lastC).WrapText = True
    ws.Columns("A:F").NumberFormatLocal = "@"
    ws.Columns("E:F").NumberFormatLocal = "yyyy/m/d"

    '縦区切り線はシート全体には引かない。
    '各人物ブロックのヘッダー行から前年比行までだけに適用し、空白行には残さない。
    ApplyBalanceTransitionBlockBorders ws, lastR, lastC

    'その他欄の長文が見切れないよう、列幅確保後にAutoFit。ただし大きくなりすぎないよう上限を設ける。
    ws.Range(ws.Cells(2, 1), ws.Cells(lastR, lastC)).Rows.AutoFit
    For r = 2 To lastR
        If CellText(ws.Cells(r, 1).Value) = "銀行名" Then
            ws.Rows(r).RowHeight = 72
        ElseIf IsBalanceTransitionPersonRow(ws, r) Then
            If ws.Rows(r).RowHeight < 34 Then ws.Rows(r).RowHeight = 34
        ElseIf CellText(ws.Cells(r, 1).Value) = "合計" Then
            If ws.Rows(r).RowHeight < 32 Then ws.Rows(r).RowHeight = 32
        ElseIf CellText(ws.Cells(r, 1).Value) = "前年比" Then
            If ws.Rows(r).RowHeight < 31 Then ws.Rows(r).RowHeight = 31
        ElseIf IsBalanceTransitionBlankRow(ws, r, lastC) Then
            ws.Rows(r).RowHeight = 12
            ws.Range(ws.Cells(r, 1), ws.Cells(r, lastC)).Borders.LineStyle = xlNone
        ElseIf ws.Rows(r).RowHeight < 30 Then
            ws.Rows(r).RowHeight = 30
        End If
        If ws.Rows(r).RowHeight > 130 Then ws.Rows(r).RowHeight = 130
    Next r

    ws.Cells(1, 1).HorizontalAlignment = xlLeft

    'ヘッダー行は列配置・AutoFitの後に再適用。列単位設定に負けないようにする。
    For Each headerRow In headerRows
        With ws.Range(ws.Cells(CLng(headerRow), 1), ws.Cells(CLng(headerRow), lastC))
            .HorizontalAlignment = xlCenter
            .VerticalAlignment = xlCenter
            .WrapText = True
            .ShrinkToFit = False
        End With
        ws.Rows(CLng(headerRow)).RowHeight = 72
    Next headerRow

    ThemeApplyPrintTable ws.Range(ws.Cells(1, 1), ws.Cells(lastR, lastC)), 1
    ThemeCapRowHeights ws.Range(ws.Cells(2, 1), ws.Cells(lastR, lastC)), 22, 96
    FixUnreadableWhiteTextOnSheet ws

    '残高推移表も印刷時は横1ページ固定。
    ApplyReadablePrintSettings ws, ""

SafeExit:
    On Error GoTo 0
End Sub

Private Sub ApplyBalanceTransitionBlockBorders(ByVal ws As Worksheet, ByVal lastR As Long, ByVal lastC As Long)
    Dim headerR As Long, endR As Long, r As Long
    If ws Is Nothing Or lastR < 2 Or lastC < 7 Then Exit Sub

    r = 2
    Do While r <= lastR
        If CellText(ws.Cells(r, 1).Value) = "銀行名" Then
            headerR = r
            endR = lastR
            Do While endR > headerR And IsBalanceTransitionBlankRow(ws, endR, lastC)
                endR = endR - 1
            Loop
            For endR = headerR + 1 To lastR
                If endR > headerR And (IsBalanceTransitionBlankRow(ws, endR, lastC) Or IsBalanceTransitionPersonRow(ws, endR)) Then
                    endR = endR - 1
                    Exit For
                End If
            Next endR
            If endR > lastR Then endR = lastR
            Do While endR > headerR And IsBalanceTransitionBlankRow(ws, endR, lastC)
                endR = endR - 1
            Loop

            If endR >= headerR Then
                With ws.Range(ws.Cells(headerR, 6), ws.Cells(endR, 6)).Borders(xlEdgeRight)
                    .LineStyle = xlContinuous
                    .Color = ThemeColor("blue")
                    .Weight = xlMedium
                End With
                If lastC >= 8 Then
                    With ws.Range(ws.Cells(headerR, lastC - 1), ws.Cells(endR, lastC - 1)).Borders(xlEdgeRight)
                        .LineStyle = xlContinuous
                        .Color = ThemeColor("blue")
                        .Weight = xlMedium
                    End With
                    With ws.Range(ws.Cells(headerR, 7), ws.Cells(endR, lastC - 1)).Borders(xlInsideVertical)
                        .LineStyle = xlContinuous
                        .Color = ThemeColor("info-soft")
                        .Weight = xlHairline
                    End With
                End If
            End If
            r = endR + 1
        Else
            r = r + 1
        End If
    Loop
End Sub

Private Sub FormatNonexistentBalanceCells(ByVal ws As Worksheet, ByVal rowNo As Long, ByVal firstBalanceCol As Long, ByVal lastBalanceCol As Long)
    '残高推移表では、口座開設日前・解約日後の基準日を「-」で表示する。
    'ただの空欄ではなく薄い塗りにして、口座が存在しない期間だと一目で分かるようにする。
    Dim c As Long
    If ws Is Nothing Then Exit Sub
    If lastBalanceCol < firstBalanceCol Then Exit Sub
    For c = firstBalanceCol To lastBalanceCol
        If CellText(ws.Cells(rowNo, c).Value) = "-" Then
            With ws.Cells(rowNo, c)
                .Interior.Color = ThemeColor("locked")
                .Font.Color = ThemeColor("muted")
                .HorizontalAlignment = xlCenter
                .NumberFormatLocal = "@"
                .Borders.Color = ThemeColor("border")
            End With
        End If
    Next c
End Sub

Private Function IsBalanceTransitionPersonRow(ByVal ws As Worksheet, ByVal r As Long) As Boolean
    Dim s As String
    s = CellText(ws.Cells(r, 1).Value)
    IsBalanceTransitionPersonRow = (Left$(s, 3) = "氏名:" Or Left$(s, 3) = "氏名：")
End Function

Private Function IsBalanceTransitionBlankRow(ByVal ws As Worksheet, ByVal r As Long, ByVal lastC As Long) As Boolean
    Dim c As Long
    For c = 1 To lastC
        If HasText(ws.Cells(r, c).Value) Then Exit Function
    Next c
    IsBalanceTransitionBlankRow = True
End Function

Private Function LastUsedColumnInSheet(ByVal ws As Worksheet, ByVal lastR As Long) As Long
    Dim r As Long, c As Long, maxC As Long
    If ws Is Nothing Then Exit Function
    If lastR < 1 Then lastR = LastUsedRowInSheet(ws)
    maxC = 1
    For r = 1 To lastR
        c = ws.Cells(r, ws.Columns.Count).End(xlToLeft).Column
        If c > maxC Then maxC = c
    Next r
    LastUsedColumnInSheet = maxC
End Function


Public Function LastUsedColumnPublic(ByVal ws As Worksheet) As Long
    Dim r As Long, c As Long, maxC As Long, lastR As Long
    If ws Is Nothing Then Exit Function
    lastR = LastUsedRowInSheet(ws)
    If lastR < 1 Then lastR = 1
    maxC = 1
    For r = 1 To lastR
        c = ws.Cells(r, ws.Columns.Count).End(xlToLeft).Column
        If c > maxC Then maxC = c
    Next r
    LastUsedColumnPublic = maxC
End Function

Public Function LastRow(ByVal ws As Worksheet, Optional ByVal colNo As Long = 1) As Long
    Dim r As Long
    If ws Is Nothing Then Exit Function
    r = ws.Cells(ws.Rows.Count, colNo).End(xlUp).Row
    If r = 1 And Len(Trim$(CStr(ws.Cells(1, colNo).Value))) = 0 Then r = 0
    LastRow = r
End Function

Public Function CellText(ByVal v As Variant) As String
    If IsError(v) Or IsNull(v) Or IsEmpty(v) Then
        CellText = ""
    Else
        CellText = Trim$(CStr(v))
    End If
End Function

Public Function HasText(ByVal v As Variant) As Boolean
    HasText = Len(CellText(v)) > 0
End Function

Public Function ToAmountOrBlank(ByVal v As Variant) As Variant
    Dim s As String
    s = Replace(CellText(v), ",", "")
    If Len(s) = 0 Then
        ToAmountOrBlank = ""
    ElseIf IsNumeric(s) Then
        ToAmountOrBlank = CDbl(s)
    Else
        ToAmountOrBlank = v
    End If
End Function

Public Function GetCfgCell(ByVal rowNo As Long) As Range
    Dim ws As Worksheet
    Set ws = GetSheet(SH_CONFIG)
    Set GetCfgCell = ws.Cells(rowNo, COL_CFG_VALUE)
End Function

Public Function GetCfgLong(ByVal rowNo As Long, ByVal defaultValue As Long) As Long
    On Error GoTo EH
    If IsNumeric(GetCfgCell(rowNo).Value) Then
        GetCfgLong = CLng(GetCfgCell(rowNo).Value)
    Else
        GetCfgLong = defaultValue
    End If
    Exit Function
EH:
    GetCfgLong = defaultValue
End Function

Public Function GetCfgDateValue(ByVal rowNo As Long) As Variant
    On Error GoTo EH
    If IsDate(GetCfgCell(rowNo).Value) Then
        GetCfgDateValue = CDate(GetCfgCell(rowNo).Value)
    Else
        GetCfgDateValue = ""
    End If
    Exit Function
EH:
    GetCfgDateValue = ""
End Function

Public Function GetInputMode() As String
    On Error GoTo EH
    GetInputMode = CellText(GetCfgCell(ROW_CFG_INPUT_MODE).Value)
    If Len(GetInputMode) = 0 Then GetInputMode = MODE_NORMAL
    Exit Function
EH:
    GetInputMode = MODE_NORMAL
End Function

Public Function GetYearInputMode() As String
    On Error GoTo EH
    GetYearInputMode = CellText(GetCfgCell(ROW_CFG_YEAR_MODE).Value)
    If Len(GetYearInputMode) = 0 Then GetYearInputMode = YEAR_MODE_WAREKI
    Exit Function
EH:
    GetYearInputMode = YEAR_MODE_WAREKI
End Function


Public Function GetPostTransferKeepPolicy() As String
    On Error GoTo EH
    GetPostTransferKeepPolicy = CellText(GetCfgCell(ROW_CFG_POST_KEEP).Value)
    If Len(GetPostTransferKeepPolicy) = 0 Then GetPostTransferKeepPolicy = KEEP_BANK_BRANCH_PERSON_TYPE
    Exit Function
EH:
    GetPostTransferKeepPolicy = KEEP_BANK_BRANCH_PERSON_TYPE
End Function

Public Function GetPostTransferClearTransaction() As Boolean
    On Error GoTo EH
    GetPostTransferClearTransaction = (CellText(GetCfgCell(ROW_CFG_POST_TX).Value) <> POST_KEEP)
    Exit Function
EH:
    GetPostTransferClearTransaction = True
End Function

Public Function GetPostTransferClearBalance() As Boolean
    On Error GoTo EH
    GetPostTransferClearBalance = (CellText(GetCfgCell(ROW_CFG_POST_BAL).Value) <> POST_KEEP)
    Exit Function
EH:
    GetPostTransferClearBalance = True
End Function

Public Function GetDisplayOption(ByVal rowNo As Long, Optional ByVal defaultShow As Boolean = True) As Boolean
    '設定シートの「表示する / 表示しない」を安全に読み取る。
    '空欄や想定外の値は、業務で困りにくいよう defaultShow を返す。
    Dim v As String
    On Error GoTo EH
    v = CellText(GetCfgCell(rowNo).Value)
    If v = DISPLAY_ON Then
        GetDisplayOption = True
    ElseIf v = DISPLAY_OFF Then
        GetDisplayOption = False
    Else
        GetDisplayOption = defaultShow
    End If
    Exit Function
EH:
    GetDisplayOption = defaultShow
End Function

Public Function UseRelationshipDisplay() As Boolean
    UseRelationshipDisplay = GetDisplayOption(ROW_CFG_RELATIONSHIP, True)
End Function

Public Function ShowInheritanceStartRow() As Boolean
    ShowInheritanceStartRow = GetDisplayOption(ROW_CFG_SHOW_INHERITANCE_ROW, True)
End Function

Public Function ShowOpenDateRow() As Boolean
    ShowOpenDateRow = GetDisplayOption(ROW_CFG_SHOW_OPEN_DATE_ROW, True)
End Function

Public Function ShowCloseDateRow() As Boolean
    ShowCloseDateRow = GetDisplayOption(ROW_CFG_SHOW_CLOSE_DATE_ROW, True)
End Function

Public Function ShowBalanceRowsInCashOperation() As Boolean
    ShowBalanceRowsInCashOperation = GetDisplayOption(ROW_CFG_SHOW_BALANCE_ROWS, True)
End Function

Public Function DisplayPersonWithRelationship(ByVal personName As String, ByVal relationshipText As String) As String
    '出力では列を増やさず、氏名欄の中で「氏名（続柄）」として表示する。
    '設定で続柄を非表示にした場合は氏名のみを返す。
    Dim p As String, rel As String
    p = CellText(personName)
    rel = CellText(relationshipText)
    If UseRelationshipDisplay() And Len(rel) > 0 Then
        DisplayPersonWithRelationship = p & "（" & rel & "）"
    Else
        DisplayPersonWithRelationship = p
    End If
End Function

Public Function IsLightExcelColor(ByVal colorValue As Long) As Boolean
    '白背景に白文字が乗る事故を防ぐための明度判定。
    Dim r As Long, g As Long, b As Long
    Dim brightness As Double
    r = colorValue Mod 256
    g = (colorValue \ 256) Mod 256
    b = (colorValue \ 65536) Mod 256
    brightness = 0.299 * r + 0.587 * g + 0.114 * b
    IsLightExcelColor = (brightness >= 210)
End Function

Public Sub FixUnreadableWhiteTextOnSheet(ByVal ws As Worksheet)
    '淡色背景＋淡色文字になったセルを、読みやすい濃色へ戻す共通補正。
    'UsedRangeが過去の書式操作で過大になっていると重くなるため、
    '実際に値・数式が入っている範囲だけを対象にする。
    Dim rng As Range, c As Range
    Dim lastR As Long, lastC As Long
    If ws Is Nothing Then Exit Sub

    lastR = LastUsedRowInSheet(ws)
    If lastR < 1 Then Exit Sub
    lastC = LastUsedColumnInSheet(ws, lastR)
    If lastC < 1 Then Exit Sub

    On Error Resume Next
    Set rng = ws.Range(ws.Cells(1, 1), ws.Cells(lastR, lastC))
    If rng Is Nothing Then Exit Sub
    For Each c In rng.Cells
        If IsLightExcelColor(c.Interior.Color) And IsLightExcelColor(c.Font.Color) Then
            c.Font.Color = ThemeColor("text")
        End If
    Next c
    On Error GoTo 0
End Sub

Public Function LastUsedRowInSheet(ByVal ws As Worksheet) As Long
    '日付欄・摘要欄だけの相続開始日行も拾えるよう、特定列ではなくシート全体で最終行を探す。
    Dim f As Range
    If ws Is Nothing Then Exit Function
    On Error Resume Next
    Set f = ws.Cells.Find(What:="*", LookIn:=xlFormulas, SearchOrder:=xlByRows, SearchDirection:=xlPrevious)
    If Not f Is Nothing Then LastUsedRowInSheet = f.Row
    On Error GoTo 0
End Function

Public Function IsTransactionRowBlank(ByVal ws As Worksheet, ByVal r As Long) As Boolean
    Dim c As Long
    If ws Is Nothing Then
        IsTransactionRowBlank = True
        Exit Function
    End If
    For c = COL_TX_YEAR To COL_TX_OTHER
        If HasText(ws.Cells(r, c).Value) Then
            IsTransactionRowBlank = False
            Exit Function
        End If
    Next c
    IsTransactionRowBlank = True
End Function

Public Function NormalizeYearInput(ByVal v As Variant, ByVal yearAdd As Long, ByRef ok As Boolean) As Long
    Dim s As String
    Dim y As Long
    Dim modeText As String
    ok = False
    s = NormalizeNumberText(CellText(v))
    If Len(s) = 0 Then Exit Function

    '4桁以上は、どの入力方式でも西暦として扱う。
    If IsNumeric(s) Then
        y = CLng(s)
        If y >= 100 Then
            If y < 1900 Or y > 9999 Then Exit Function
            NormalizeYearInput = y
            ok = True
            Exit Function
        End If
    End If

    modeText = GetYearInputMode()
    If modeText = YEAR_MODE_WESTERN2 Then
        If Not IsNumeric(s) Then Exit Function
        y = CLng(s)
        If y < 0 Or y > 99 Then Exit Function
        y = yearAdd + y
    Else
        y = ResolveWarekiYearSmart(s)
    End If

    If y < 1900 Or y > 9999 Then Exit Function
    NormalizeYearInput = y
    ok = True
End Function

Private Function NormalizeNumberText(ByVal s As String) As String
    On Error Resume Next
    s = StrConv(s, vbNarrow)
    On Error GoTo 0
    s = Replace(s, " ", "")
    s = Replace(s, "　", "")
    s = Replace(s, "年", "")
    NormalizeNumberText = Trim$(s)
End Function

Private Function ResolveWarekiYearSmart(ByVal s As String) As Long
    Dim y As Long
    Dim n As Long

    If ResolveExplicitEraYear(s, y) Then
        ResolveWarekiYearSmart = y
        Exit Function
    End If

    If s = "元" Then s = "1"
    If Not IsNumeric(s) Then Exit Function
    n = CLng(s)
    If n <= 0 Or n > 99 Then Exit Function

    ResolveWarekiYearSmart = BestJapaneseEraCandidate(n)
End Function

Private Function ResolveExplicitEraYear(ByVal s As String, ByRef westernYear As Long) As Boolean
    Dim era As String
    Dim n As Long
    s = UCase$(s)
    s = Replace(s, ".", "")
    s = Replace(s, "-", "")
    s = Replace(s, "令和", "R")
    s = Replace(s, "平成", "H")
    s = Replace(s, "昭和", "S")
    If Len(s) < 2 Then Exit Function
    era = Left$(s, 1)
    If era <> "R" And era <> "H" And era <> "S" Then Exit Function
    s = Mid$(s, 2)
    If s = "元" Then s = "1"
    If Not IsNumeric(s) Then Exit Function
    n = CLng(s)
    If n <= 0 Then Exit Function

    Select Case era
        Case "R"
            If n > 99 Then Exit Function
            westernYear = 2018 + n
        Case "H"
            If n > 31 Then Exit Function
            westernYear = 1988 + n
        Case "S"
            If n > 64 Then Exit Function
            westernYear = 1925 + n
    End Select
    ResolveExplicitEraYear = (westernYear >= 1900 And westernYear <= 9999)
End Function

Private Function BestJapaneseEraCandidate(ByVal eraYear As Long) As Long
    Dim candidates(1 To 3) As Long
    Dim count As Long
    Dim i As Long
    Dim refYear As Long
    Dim bestYear As Long
    Dim bestScore As Long
    Dim score As Long

    If eraYear >= 1 And eraYear <= 99 Then
        count = count + 1
        candidates(count) = 2018 + eraYear  '令和
    End If
    If eraYear >= 1 And eraYear <= 31 Then
        count = count + 1
        candidates(count) = 1988 + eraYear  '平成
    End If
    If eraYear >= 1 And eraYear <= 64 Then
        count = count + 1
        candidates(count) = 1925 + eraYear  '昭和
    End If

    refYear = GetYearResolutionReferenceYear()
    bestScore = 999999
    For i = 1 To count
        If candidates(i) >= 1900 And candidates(i) <= 2100 Then
            score = Abs(candidates(i) - refYear) + JapaneseEraWindowPenalty(candidates(i))
            If score < bestScore Or (score = bestScore And candidates(i) > bestYear) Then
                bestScore = score
                bestYear = candidates(i)
            End If
        End If
    Next i
    BestJapaneseEraCandidate = bestYear
End Function

Private Function GetYearResolutionReferenceYear() As Long
    Dim inheritDate As Variant
    Dim startYear As Long
    Dim endYear As Long
    inheritDate = GetCfgDateValue(ROW_CFG_INHERITANCE_DATE)
    If IsDate(inheritDate) Then
        GetYearResolutionReferenceYear = Year(CDate(inheritDate))
        Exit Function
    End If
    startYear = GetCfgLong(ROW_CFG_BAL_START_YEAR, Year(Date) - 4)
    endYear = GetCfgLong(ROW_CFG_BAL_END_YEAR, Year(Date))
    If startYear > 0 And endYear >= startYear Then
        GetYearResolutionReferenceYear = CLng((startYear + endYear) / 2)
    Else
        GetYearResolutionReferenceYear = Year(Date)
    End If
End Function

Private Function JapaneseEraWindowPenalty(ByVal westernYear As Long) As Long
    Dim startYear As Long
    Dim endYear As Long
    startYear = GetCfgLong(ROW_CFG_BAL_START_YEAR, Year(Date) - 4)
    endYear = GetCfgLong(ROW_CFG_BAL_END_YEAR, Year(Date))
    If endYear < startYear Then endYear = startYear
    If westernYear < startYear - 5 Or westernYear > endYear + 5 Then
        JapaneseEraWindowPenalty = 1000
    Else
        JapaneseEraWindowPenalty = 0
    End If
End Function

Public Function ParseMonthDay(ByVal v As Variant, ByRef m As Long, ByRef d As Long) As Boolean
    Dim s As String
    s = CellText(v)
    ParseMonthDay = False
    If Len(s) < 3 Or Len(s) > 4 Then Exit Function
    If Not IsNumeric(s) Then Exit Function
    If Len(s) = 3 Then
        m = CLng(Left$(s, 1))
        d = CLng(Right$(s, 2))
    Else
        m = CLng(Left$(s, 2))
        d = CLng(Right$(s, 2))
    End If
    If m < 1 Or m > 12 Then Exit Function
    If d < 1 Or d > 31 Then Exit Function
    ParseMonthDay = True
End Function

Public Function ResolveInputDate(ByVal yearVal As Variant, ByVal monthVal As Variant, ByVal dayVal As Variant, _
    ByRef currentYear As Long, ByRef currentMonth As Long, ByRef currentDay As Long, _
    ByVal yearAdd As Long, ByRef ok As Boolean) As Variant

    Dim tmpYear As Long
    Dim tmpMonth As Long
    Dim tmpDay As Long
    Dim yearOK As Boolean
    Dim d As Date

    ok = False
    If HasText(yearVal) Then
        tmpYear = NormalizeYearInput(yearVal, yearAdd, yearOK)
        If Not yearOK Then Exit Function
        currentYear = tmpYear
    End If
    If HasText(monthVal) Then
        If Not IsNumeric(CellText(monthVal)) Then Exit Function
        currentMonth = CLng(CellText(monthVal))
    End If
    If HasText(dayVal) Then
        If ParseMonthDay(dayVal, tmpMonth, tmpDay) Then
            currentMonth = tmpMonth
            currentDay = tmpDay
        Else
            If Not IsNumeric(CellText(dayVal)) Then Exit Function
            currentDay = CLng(CellText(dayVal))
        End If
    End If
    If currentYear = 0 Or currentMonth = 0 Or currentDay = 0 Then Exit Function
    If currentMonth < 1 Or currentMonth > 12 Or currentDay < 1 Or currentDay > 31 Then Exit Function
    On Error GoTo InvalidDate
    d = DateSerial(currentYear, currentMonth, currentDay)
    If Year(d) <> currentYear Or Month(d) <> currentMonth Or Day(d) <> currentDay Then GoTo InvalidDate
    ResolveInputDate = d
    ok = True
    Exit Function
InvalidDate:
    ResolveInputDate = ""
End Function

Public Function NormalizeTimeInput(ByVal v As Variant, ByRef ok As Boolean) As Variant
    Dim s As String, parts() As String
    Dim x As Double, h As Long, m As Long

    ok = False
    If IsError(v) Or IsNull(v) Or IsEmpty(v) Then
        NormalizeTimeInput = ""
        ok = True
        Exit Function
    End If

    s = Trim$(CellText(v))
    On Error Resume Next
    s = StrConv(s, vbNarrow)
    On Error GoTo 0
    s = Replace$(s, "：", ":")
    s = Replace$(s, "時", ":")
    s = Replace$(s, "分", "")
    s = Replace$(s, " ", "")

    If Len(s) = 0 Then
        NormalizeTimeInput = ""
        ok = True
        Exit Function
    End If

    If InStr(1, s, ":", vbTextCompare) > 0 Then
        parts = Split(s, ":")
        If UBound(parts) = 1 Then
            If IsNumeric(parts(0)) And IsNumeric(parts(1)) Then
                h = CLng(parts(0))
                m = CLng(parts(1))
                If h >= 0 And h < 24 And m >= 0 And m < 60 Then
                    NormalizeTimeInput = TimeSerial(h, m, 0)
                    ok = True
                    Exit Function
                End If
            End If
        End If
        NormalizeTimeInput = v
        Exit Function
    End If

    If IsNumeric(s) Then
        x = CDbl(s)
        If x >= 0 And x < 1 Then
            NormalizeTimeInput = x
            ok = True
            Exit Function
        End If
        If x >= 100 And x <= 2359 Then
            s = Right$("0000" & CStr(CLng(x)), 4)
            h = CLng(Left$(s, 2))
            m = CLng(Right$(s, 2))
            If h >= 0 And h < 24 And m >= 0 And m < 60 Then
                NormalizeTimeInput = TimeSerial(h, m, 0)
                ok = True
                Exit Function
            End If
        End If
        If x >= 0 And x < 24 Then
            NormalizeTimeInput = TimeSerial(CLng(Fix(x)), 0, 0)
            ok = True
            Exit Function
        End If
    End If

    NormalizeTimeInput = v
End Function

Public Sub NormalizeTransactionTimeEntry(ByVal targetCell As Range)
    Dim ok As Boolean, v As Variant
    If targetCell Is Nothing Then Exit Sub
    v = NormalizeTimeInput(targetCell.Value, ok)
    If Not ok Then Exit Sub
    If Len(CellText(v)) = 0 Then
        targetCell.ClearContents
    Else
        targetCell.Value = v
        targetCell.NumberFormatLocal = "hh:mm"
    End If
End Sub

Public Function NextBranchAccountNo(ByVal accountNo As String) As String
    Dim s As String
    Dim baseNo As String
    Dim suffixText As String
    Dim p As Long
    Dim suffixNo As Long
    s = NormalizeAccountHyphen(CellText(accountNo))
    If Len(s) = 0 Then
        NextBranchAccountNo = ""
        Exit Function
    End If
    p = InStrRev(s, "-")
    If p > 0 Then
        baseNo = Left$(s, p - 1)
        suffixText = Mid$(s, p + 1)
        If Len(baseNo) > 0 And IsNumeric(suffixText) Then
            suffixNo = CLng(suffixText) + 1
            NextBranchAccountNo = baseNo & "-" & CStr(suffixNo)
            Exit Function
        End If
    End If
    NextBranchAccountNo = s & "-1"
End Function

Public Function ResolveAccountDateInput(ByVal v As Variant, ByRef ok As Boolean) As Variant
    '口座開設日・解約日の入力補助用。
    '取引明細の年入力とは別に、昭和・平成・令和を明示できる「元号コード.年.月.日」を優先して解釈する。
    '例：1.53.5.6=昭和53年5月6日、2.31.4.30=平成31年4月30日、3.1.5.1=令和元年5月1日。
    '元号コードは設定シートの元号マスタで管理するため、新元号はマスタに1行追加すれば対応できる。
    Dim s As String
    Dim cleaned As String
    Dim parts As Variant
    Dim y As Long, m As Long, d As Long
    Dim yearOK As Boolean
    Dim yAdd As Long

    ok = False
    s = CellText(v)
    If Len(s) = 0 Then
        ResolveAccountDateInput = ""
        ok = True
        Exit Function
    End If

    On Error Resume Next
    s = StrConv(s, vbNarrow)
    On Error GoTo 0
    s = UCase$(s)
    s = Replace(s, " ", "")
    s = Replace(s, "　", "")
    s = Replace(s, "．", ".")
    s = Replace(s, "。", ".")
    s = Replace(s, "・", ".")
    s = Replace(s, "-", "/")
    s = Replace(s, ".", "/")
    s = Replace(s, "年", "/")
    s = Replace(s, "月", "/")
    s = Replace(s, "日", "")
    yAdd = GetCfgLong(ROW_CFG_YEAR_ADD, 2000)

    If InStr(1, s, "/", vbTextCompare) > 0 Then
        parts = Split(s, "/")

        '元号コード付き入力。例：1/53/5/6、2/31/4/30、3/1/5/1。
        If UBound(parts) = 3 Then
            ResolveAccountDateInput = ResolveEraCodeDateInput(parts(0), parts(1), parts(2), parts(3), ok)
            Exit Function
        End If

        '従来互換。例：31/4/30、R1/5/1、2019/5/1。
        If UBound(parts) < 2 Then Exit Function
        y = NormalizeYearInput(parts(0), yAdd, yearOK)
        If Not yearOK Then Exit Function
        If Not IsNumeric(parts(1)) Or Not IsNumeric(parts(2)) Then Exit Function
        m = CLng(parts(1))
        d = CLng(parts(2))
        ResolveAccountDateInput = MakeCheckedDate(y, m, d, ok)
        Exit Function
    End If

    cleaned = Replace(s, "/", "")
    If IsNumeric(cleaned) Then
        Select Case Len(cleaned)
            Case 8
                y = CLng(Left$(cleaned, 4))
                m = CLng(Mid$(cleaned, 5, 2))
                d = CLng(Right$(cleaned, 2))
            Case 6
                y = NormalizeYearInput(Left$(cleaned, 2), yAdd, yearOK)
                If Not yearOK Then Exit Function
                m = CLng(Mid$(cleaned, 3, 2))
                d = CLng(Right$(cleaned, 2))
            Case 5
                'R1年5月1日を 10501 と打つケース用。昭和など古い開設日は元号コード付き入力を推奨。
                y = NormalizeYearInput(Left$(cleaned, 1), yAdd, yearOK)
                If Not yearOK Then Exit Function
                m = CLng(Mid$(cleaned, 2, 2))
                d = CLng(Right$(cleaned, 2))
            Case Else
                If IsDate(s) Then
                    ResolveAccountDateInput = CDate(s)
                    ok = True
                End If
                Exit Function
        End Select
        ResolveAccountDateInput = MakeCheckedDate(y, m, d, ok)
        Exit Function
    End If

    If IsDate(s) Then
        ResolveAccountDateInput = CDate(s)
        ok = True
    End If
End Function

Private Function ResolveEraCodeDateInput( _
    ByVal eraKey As String, _
    ByVal eraYearText As String, _
    ByVal monthText As String, _
    ByVal dayText As String, _
    ByRef ok As Boolean _
) As Variant
    '元号コード付き日付を西暦日付に変換する。
    '年は「元」も1年として扱う。元号の開始日・終了日から外れる場合は無効にする。
    Dim eraName As String
    Dim eraAbbr As String
    Dim startDate As Date
    Dim endDate As Date
    Dim hasEndDate As Boolean
    Dim eraYear As Long
    Dim m As Long
    Dim d As Long
    Dim westernYear As Long
    Dim dt As Variant

    ok = False
    eraYearText = NormalizeNumberText(eraYearText)
    If eraYearText = "元" Then eraYearText = "1"
    If Not IsNumeric(eraYearText) Then Exit Function
    If Not IsNumeric(monthText) Or Not IsNumeric(dayText) Then Exit Function

    eraYear = CLng(eraYearText)
    m = CLng(monthText)
    d = CLng(dayText)
    If eraYear <= 0 Then Exit Function

    If Not TryGetEraInfoByKey(eraKey, eraName, eraAbbr, startDate, endDate, hasEndDate) Then Exit Function

    westernYear = Year(startDate) + eraYear - 1
    dt = MakeCheckedDate(westernYear, m, d, ok)
    If Not ok Or Not IsDate(dt) Then Exit Function

    If CDate(dt) < startDate Then
        ok = False
        ResolveEraCodeDateInput = ""
        Exit Function
    End If
    If hasEndDate Then
        If CDate(dt) > endDate Then
            ok = False
            ResolveEraCodeDateInput = ""
            Exit Function
        End If
    End If

    ResolveEraCodeDateInput = CDate(dt)
    ok = True
End Function

Public Function TryGetEraInfoByKey( _
    ByVal eraKey As String, _
    ByRef eraName As String, _
    ByRef eraAbbr As String, _
    ByRef startDate As Date, _
    ByRef endDate As Date, _
    ByRef hasEndDate As Boolean _
) As Boolean
    '設定シートの元号マスタから元号情報を取得する。
    '一致条件は「元号コード」「元号名」「略称」。設定シートが未整備の場合は昭和・平成・令和の既定値へフォールバックする。
    Dim ws As Worksheet
    Dim r As Long
    Dim key As String
    Dim codeText As String
    Dim nameText As String
    Dim abbrText As String
    Dim enabledText As String

    key = NormalizeEraKey(eraKey)
    If Len(key) = 0 Then Exit Function

    On Error Resume Next
    Set ws = GetSheet(SH_CONFIG)
    On Error GoTo 0

    If Not ws Is Nothing Then
        For r = ERA_MASTER_FIRST_ROW To ERA_MASTER_MAX_ROW
            codeText = NormalizeEraKey(CellText(ws.Cells(r, ERA_COL_CODE).Value))
            nameText = NormalizeEraKey(CellText(ws.Cells(r, ERA_COL_NAME).Value))
            abbrText = NormalizeEraKey(CellText(ws.Cells(r, ERA_COL_ABBR).Value))
            If Len(codeText) = 0 And Len(nameText) = 0 And Len(abbrText) = 0 Then
                '空行は将来元号の追加入力欄なので読み飛ばす。
            ElseIf key = codeText Or key = nameText Or key = abbrText Then
                enabledText = UCase$(CellText(ws.Cells(r, ERA_COL_ENABLED).Value))
                If enabledText = "FALSE" Or enabledText = "0" Or enabledText = "無効" Then Exit Function
                If Not IsDate(ws.Cells(r, ERA_COL_START).Value) Then Exit Function

                eraName = CellText(ws.Cells(r, ERA_COL_NAME).Value)
                eraAbbr = CellText(ws.Cells(r, ERA_COL_ABBR).Value)
                startDate = CDate(ws.Cells(r, ERA_COL_START).Value)
                If IsDate(ws.Cells(r, ERA_COL_END).Value) Then
                    endDate = CDate(ws.Cells(r, ERA_COL_END).Value)
                    hasEndDate = True
                Else
                    endDate = 0
                    hasEndDate = False
                End If
                TryGetEraInfoByKey = True
                Exit Function
            End If
        Next r
    End If

    'フォールバック。設定シートを壊した場合でも、既存3元号は最低限使えるようにする。
    Select Case key
        Case "1", "S", "昭和"
            eraName = "昭和": eraAbbr = "S": startDate = DateSerial(1926, 12, 25): endDate = DateSerial(1989, 1, 7): hasEndDate = True
        Case "2", "H", "平成"
            eraName = "平成": eraAbbr = "H": startDate = DateSerial(1989, 1, 8): endDate = DateSerial(2019, 4, 30): hasEndDate = True
        Case "3", "R", "令和"
            eraName = "令和": eraAbbr = "R": startDate = DateSerial(2019, 5, 1): endDate = 0: hasEndDate = False
        Case Else
            Exit Function
    End Select
    TryGetEraInfoByKey = True
End Function

Private Function NormalizeEraKey(ByVal s As String) As String
    On Error Resume Next
    s = StrConv(s, vbNarrow)
    On Error GoTo 0
    s = UCase$(Trim$(s))
    s = Replace(s, " ", "")
    s = Replace(s, "　", "")
    NormalizeEraKey = s
End Function

Private Function MakeCheckedDate(ByVal y As Long, ByVal m As Long, ByVal d As Long, ByRef ok As Boolean) As Variant
    Dim dt As Date
    ok = False
    If y < 1900 Or y > 9999 Or m < 1 Or m > 12 Or d < 1 Or d > 31 Then Exit Function
    On Error GoTo InvalidDate
    dt = DateSerial(y, m, d)
    If Year(dt) <> y Or Month(dt) <> m Or Day(dt) <> d Then GoTo InvalidDate
    MakeCheckedDate = dt
    ok = True
    Exit Function
InvalidDate:
    MakeCheckedDate = ""
End Function

Public Function NormalizedAccountDateForUse(ByVal v As Variant) As Variant
    '転記処理・残高欄制御用。入力途中の文字列でも日付として読めるものは実日付に寄せる。
    Dim ok As Boolean
    Dim d As Variant
    d = ResolveAccountDateInput(v, ok)
    If ok And IsDate(d) Then
        NormalizedAccountDateForUse = CDate(d)
    Else
        NormalizedAccountDateForUse = ""
    End If
End Function

Public Sub NormalizeAccountDateEntry(ByVal targetCell As Range)
    '開設日・解約日セルの入力直後に、和暦数字入力を見やすい yyyy/m/d 表示へ整える。
    '日付は文字列ではなくExcelの日付値として保持し、後続の残高制御・出力でも安定して扱う。
    Dim ok As Boolean
    Dim d As Variant
    If targetCell Is Nothing Then Exit Sub
    d = ResolveAccountDateInput(targetCell.Value, ok)
    If ok And IsDate(d) Then
        targetCell.NumberFormatLocal = "yyyy/m/d"
        targetCell.Value = CDate(d)
    End If
End Sub

Public Function AccountExistsAtDate(ByVal targetDate As Variant, ByVal openDate As Variant, ByVal closeDate As Variant) As Boolean
    '指定基準日に口座が存在していたかを判定する。
    '開設日前・解約日後の残高は入力欄ではロックし、残高推移表では「-」表示にする。
    If Not IsDate(targetDate) Then
        AccountExistsAtDate = True
        Exit Function
    End If
    If IsDate(openDate) Then
        If CDate(targetDate) < CDate(openDate) Then Exit Function
    End If
    If IsDate(closeDate) Then
        If CDate(targetDate) > CDate(closeDate) Then Exit Function
    End If
    AccountExistsAtDate = True
End Function

Public Sub ApplyBalanceAvailability(ByVal ws As Worksheet)
    '開設日・解約日に応じて残高入力欄を制御する。
    '存在しない期間の残高欄は、入力不可・選択不可・薄色表示にして、Tab移動でも飛ばす。
    Dim memoCol As Long
    Dim c As Long
    Dim openDate As Variant
    Dim closeDate As Variant
    Dim balDate As Variant
    Dim enabled As Boolean

    If ws Is Nothing Then Exit Sub
    If ws.Name <> SH_INPUT Then Exit Sub

    memoCol = BalanceMemoCol(ws)
    openDate = NormalizedAccountDateForUse(ws.Range(CELL_OPEN_DATE).Value)
    closeDate = NormalizedAccountDateForUse(ws.Range(CELL_CLOSE_DATE).Value)

    For c = BAL_FIRST_COL To memoCol - 1
        balDate = ws.Cells(BAL_DATE_ROW, c).Value
        enabled = AccountExistsAtDate(balDate, openDate, closeDate)
        ApplySingleBalanceInputState ws, c, enabled
    Next c
End Sub

Private Sub ApplySingleBalanceInputState(ByVal ws As Worksheet, ByVal c As Long, ByVal enabled As Boolean)
    Dim valueCell As Range
    If ws Is Nothing Then Exit Sub
    Set valueCell = ws.Cells(BAL_VALUE_ROW, c)

    If enabled Then
        If CellText(valueCell.Value) = "-" Then valueCell.ClearContents
        valueCell.Locked = False
        valueCell.NumberFormatLocal = "#,##0"
        valueCell.Interior.Color = ThemeColor("canvas")
        valueCell.Font.Color = ThemeColor("text")
        ws.Cells(BAL_LABEL_ROW, c).Interior.Color = ThemeColor("info-soft")
        ws.Cells(BAL_LABEL_ROW, c).Font.Color = ThemeColor("blue")
        ws.Cells(BAL_DATE_ROW, c).Interior.Color = ThemeColor("locked")
        ws.Cells(BAL_DATE_ROW, c).Font.Color = ThemeColor("muted")
    Else
        valueCell.ClearContents
        valueCell.Value = "-"
        valueCell.Locked = True
        valueCell.NumberFormatLocal = "@"
        valueCell.Interior.Color = ThemeColor("locked")
        valueCell.Font.Color = ThemeColor("line-muted")
        ws.Cells(BAL_LABEL_ROW, c).Interior.Color = ThemeColor("locked")
        ws.Cells(BAL_LABEL_ROW, c).Font.Color = ThemeColor("muted")
        ws.Cells(BAL_DATE_ROW, c).Interior.Color = ThemeColor("locked")
        ws.Cells(BAL_DATE_ROW, c).Font.Color = ThemeColor("line-muted")
    End If
End Sub

Public Function FirstAvailableBalanceInputCell(ByVal ws As Worksheet) As Range
    Dim memoCol As Long
    Dim c As Long
    If ws Is Nothing Then Exit Function
    memoCol = BalanceMemoCol(ws)
    For c = BAL_FIRST_COL To memoCol - 1
        If Not ws.Cells(BAL_VALUE_ROW, c).Locked Then
            Set FirstAvailableBalanceInputCell = ws.Cells(BAL_VALUE_ROW, c)
            Exit Function
        End If
    Next c
    Set FirstAvailableBalanceInputCell = ws.Cells(BAL_VALUE_ROW, memoCol)
End Function

Public Function NextAvailableBalanceInputCell(ByVal ws As Worksheet, ByVal currentCol As Long, ByVal backwards As Boolean) As Range
    Dim memoCol As Long
    Dim c As Long
    If ws Is Nothing Then Exit Function
    memoCol = BalanceMemoCol(ws)

    If backwards Then
        For c = currentCol - 1 To BAL_FIRST_COL Step -1
            If Not ws.Cells(BAL_VALUE_ROW, c).Locked Then
                Set NextAvailableBalanceInputCell = ws.Cells(BAL_VALUE_ROW, c)
                Exit Function
            End If
        Next c
        Set NextAvailableBalanceInputCell = ws.Range(CELL_CLOSE_DATE)
    Else
        For c = currentCol + 1 To memoCol - 1
            If Not ws.Cells(BAL_VALUE_ROW, c).Locked Then
                Set NextAvailableBalanceInputCell = ws.Cells(BAL_VALUE_ROW, c)
                Exit Function
            End If
        Next c
        If currentCol < memoCol Then
            Set NextAvailableBalanceInputCell = ws.Cells(BAL_VALUE_ROW, memoCol)
        Else
            Set NextAvailableBalanceInputCell = ws.Cells(TX_FIRST_ROW, COL_TX_YEAR)
        End If
    End If
End Function

Public Function NormalizeAccountHyphen(ByVal accountNo As String) As String
    Dim s As String
    s = Trim$(accountNo)
    s = Replace(s, "－", "-")
    s = Replace(s, "―", "-")
    s = Replace(s, "ー", "-")
    s = Replace(s, "ｰ", "-")
    s = Replace(s, "－", "-")
    NormalizeAccountHyphen = s
End Function

Public Sub BuildBalanceCollections(ByRef labels As Collection, ByRef dates As Collection)
    Dim startYear As Long
    Dim endYear As Long
    Dim inheritDate As Variant
    Dim y As Long
    Dim dYearEnd As Date
    Dim eventAdded As Boolean
    Dim labelText As String
    Set labels = New Collection
    Set dates = New Collection
    startYear = GetCfgLong(ROW_CFG_BAL_START_YEAR, Year(Date) - 4)
    endYear = GetCfgLong(ROW_CFG_BAL_END_YEAR, Year(Date))
    If endYear < startYear Then endYear = startYear
    inheritDate = GetCfgDateValue(ROW_CFG_INHERITANCE_DATE)
    For y = startYear To endYear
        dYearEnd = DateSerial(y, 12, 31)
        If IsDate(inheritDate) Then
            If Not eventAdded And CDate(inheritDate) < dYearEnd Then
                labels.Add "相続開始日時点" & vbLf & "残高（" & Format$(CDate(inheritDate), "yyyy/m/d") & "）"
                dates.Add CDate(inheritDate)
                eventAdded = True
            End If
            If CDate(inheritDate) = dYearEnd Then
                labelText = CStr(y) & "年末・相続開始日時点" & vbLf & "残高（" & Format$(CDate(inheritDate), "yyyy/m/d") & "）"
                eventAdded = True
            Else
                labelText = CStr(y) & "年末残高"
            End If
        Else
            labelText = CStr(y) & "年末残高"
        End If
        labels.Add labelText
        dates.Add dYearEnd
    Next y
    If IsDate(inheritDate) And Not eventAdded Then
        labels.Add "相続開始日時点" & vbLf & "残高（" & Format$(CDate(inheritDate), "yyyy/m/d") & "）"
        dates.Add CDate(inheritDate)
    End If
End Sub

Public Function BalanceMemoCol(ByVal ws As Worksheet) As Long
    Dim c As Long
    If ws Is Nothing Then
        BalanceMemoCol = BAL_MAX_COL
        Exit Function
    End If
    For c = BAL_FIRST_COL To BAL_MAX_COL
        If CellText(ws.Cells(BAL_LABEL_ROW, c).Value) = "その他" Then
            BalanceMemoCol = c
            Exit Function
        End If
    Next c
    BalanceMemoCol = BAL_MAX_COL
End Function

Public Function EffectiveRange(ByVal rng As Range) As Range
    If rng Is Nothing Then Exit Function
    On Error Resume Next
    If rng.MergeCells Then
        Set EffectiveRange = rng.MergeArea
    Else
        Set EffectiveRange = rng
    End If
    On Error GoTo 0
End Function

Public Sub ApplyValidationInputOnly(ByVal rng As Range, ByVal imeMode As Long)
    Dim target As Range
    If rng Is Nothing Then Exit Sub
    Set target = EffectiveRange(rng)
    If target Is Nothing Then Set target = rng
    On Error Resume Next
    target.Validation.Delete
    target.Validation.Add Type:=xlValidateInputOnly
    target.Validation.IgnoreBlank = True
    target.Validation.IMEMode = imeMode
    On Error GoTo 0
End Sub

Public Sub ApplyValidationList(ByVal rng As Range, ByVal listName As String, ByVal imeMode As Long, Optional ByVal allowFreeText As Boolean = True)
    Dim target As Range
    If rng Is Nothing Then Exit Sub
    Set target = EffectiveRange(rng)
    If target Is Nothing Then Set target = rng
    On Error Resume Next
    target.Validation.Delete
    target.Validation.Add Type:=xlValidateList, AlertStyle:=xlValidAlertStop, Operator:=xlBetween, Formula1:="=" & listName
    target.Validation.IgnoreBlank = True
    target.Validation.InCellDropdown = True
    target.Validation.ShowError = Not allowFreeText
    target.Validation.IMEMode = imeMode
    On Error GoTo 0
End Sub

Public Sub UnlockRange(ByVal rng As Range)
    Dim target As Range
    If rng Is Nothing Then Exit Sub
    Set target = EffectiveRange(rng)
    If target Is Nothing Then Set target = rng
    On Error Resume Next
    target.Locked = False
    On Error GoTo 0
End Sub

Public Sub MergeAndFormat(ByVal rng As Range, ByVal valueText As String, Optional ByVal mergeCells As Boolean = True)
    If rng Is Nothing Then Exit Sub
    On Error Resume Next
    rng.UnMerge
    If mergeCells Then rng.Merge
    rng.Value = valueText
    rng.WrapText = True
    rng.VerticalAlignment = xlCenter
    On Error GoTo 0
End Sub


Public Sub ClearEffectiveContents(ByVal rng As Range)
    Dim target As Range
    If rng Is Nothing Then Exit Sub
    Set target = EffectiveRange(rng)
    If target Is Nothing Then Set target = rng
    On Error Resume Next
    target.ClearContents
    On Error GoTo 0
End Sub

Public Sub AutoFitSheetSmart(ByVal ws As Worksheet, Optional ByVal columnsAddress As String = "", Optional ByVal minWidth As Double = 6, Optional ByVal maxWidth As Double = 34)
    '列幅・行高の自動調整。UsedRangeが肥大しているブックでも重くならないよう、
    '値・数式が入っている実範囲を基準にする。
    Dim rngCols As Range
    Dim rngRows As Range
    Dim c As Range
    Dim r As Range
    Dim lastR As Long
    Dim lastC As Long
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    lastR = LastUsedRowInSheet(ws)
    If lastR < 1 Then lastR = 1
    lastC = LastUsedColumnInSheet(ws, lastR)
    If lastC < 1 Then lastC = 1

    If Len(columnsAddress) > 0 Then
        Set rngCols = ws.Columns(columnsAddress)
    Else
        Set rngCols = ws.Range(ws.Cells(1, 1), ws.Cells(1, lastC)).EntireColumn
    End If
    If Not rngCols Is Nothing Then
        rngCols.AutoFit
        For Each c In rngCols.Columns
            If c.ColumnWidth < minWidth Then c.ColumnWidth = minWidth
            If c.ColumnWidth > maxWidth Then c.ColumnWidth = maxWidth
        Next c
    End If

    Set rngRows = ws.Range(ws.Rows(1), ws.Rows(lastR))
    rngRows.AutoFit
    For Each r In rngRows.Rows
        If r.RowHeight < 18 Then r.RowHeight = 18
        If r.RowHeight > 72 Then r.RowHeight = 72
    Next r
    On Error GoTo 0
End Sub

Public Sub PolishInputLayout(Optional ByVal ws As Worksheet = Nothing)
    If ws Is Nothing Then
        If Not SheetExists(SH_INPUT) Then Exit Sub
        Set ws = GetSheet(SH_INPUT)
    End If
    ApplyInputColumnWidths ws
    ApplyFinanceInputViewport ws
End Sub

Public Sub ApplyFinanceInputViewport(Optional ByVal ws As Worksheet = Nothing)
    '最も作業時間が長い入力画面の視線を固定する。
    '口座・残高・取引見出しを残したまま、明細入力だけを高速に進める。
    Dim win As Window
    Dim keepCell As Range
    If ws Is Nothing Then
        If Not SheetExists(SH_INPUT) Then Exit Sub
        Set ws = GetSheet(SH_INPUT)
    End If
    On Error Resume Next
    ws.ScrollArea = "A1:U" & CStr(TX_LAST_ROW)
    If ActiveWorkbook Is Nothing Then Exit Sub
    If ActiveWorkbook.Name <> ThisWorkbook.Name Then Exit Sub
    If ActiveSheet Is Nothing Then Exit Sub
    If ActiveSheet.Name <> ws.Name Then Exit Sub
    Set keepCell = ActiveCell
    Set win = ActiveWindow
    If win Is Nothing Then Exit Sub
    win.DisplayGridlines = False
    If win.Zoom <> 90 Then win.Zoom = 90
    win.FreezePanes = False
    ws.Range("B15").Select
    win.FreezePanes = True
    If Not keepCell Is Nothing Then keepCell.Select
    On Error GoTo 0
End Sub
Private Sub ApplyInputColumnWidths(ByVal ws As Worksheet)
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    '視認性優先。入力列は最低13以上、残高見出しは2行表示で読ませる。
    ws.Columns("A:A").ColumnWidth = 2
    ws.Columns("B:I").ColumnWidth = 14.5
    ws.Columns("J:J").ColumnWidth = 18.5
    ws.Columns("K:K").ColumnWidth = 28
    ws.Columns("L:L").ColumnWidth = 2
    ws.Columns("M:T").ColumnWidth = 12.6
    ws.Columns("U:U").ColumnWidth = 2

    ws.Rows("1:1").RowHeight = 8
    ws.Rows("2:14").RowHeight = 22
    ws.Rows(2).RowHeight = 30
    ws.Rows(4).RowHeight = 23
    ws.Rows(5).RowHeight = 24
    ws.Rows(6).RowHeight = 24
    ws.Rows(8).RowHeight = 23
    ws.Rows(BAL_LABEL_ROW).RowHeight = 42
    ws.Rows(BAL_VALUE_ROW).RowHeight = 25
    ws.Rows(BAL_DATE_ROW).RowHeight = 18
    ws.Rows(12).RowHeight = 25
    ws.Rows(TX_HEADER_ROW).RowHeight = 28
    ws.Rows(TX_FIRST_ROW & ":" & TX_LAST_ROW).RowHeight = 21

    ws.Range("B2:K12").WrapText = True
    With ws.Range(ws.Cells(BAL_LABEL_ROW, BAL_FIRST_COL), ws.Cells(BAL_LABEL_ROW, BAL_MAX_COL))
        .WrapText = True
        .ShrinkToFit = False
        .Font.Size = 9
    End With
    ws.Range("M2:T14").WrapText = False
    ws.Range("B15:K" & TX_LAST_ROW).WrapText = False
    On Error GoTo 0
End Sub
Public Sub AutoFitInputSheetSmart(ByVal ws As Worksheet)
    Dim c As Long
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    '見出しと明細を一度AutoFitし、その後で実務上必要な最低幅を保証する。
    ws.Range("B14:K" & TX_LAST_ROW).Columns.AutoFit
    For c = 2 To 11
        If ws.Columns(c).ColumnWidth < 13.2 Then ws.Columns(c).ColumnWidth = 13.2
        If c = COL_TX_TEKIYO And ws.Columns(c).ColumnWidth < 17 Then ws.Columns(c).ColumnWidth = 17
        If c = COL_TX_OTHER And ws.Columns(c).ColumnWidth < 28 Then ws.Columns(c).ColumnWidth = 28
        If ws.Columns(c).ColumnWidth > 32 Then ws.Columns(c).ColumnWidth = 32
    Next c
    ws.Rows("1:" & TX_LAST_ROW).AutoFit
    ApplyInputColumnWidths ws
    BuildOperationPanel ws
    BuildInputHelpCards ws
    On Error GoTo 0
End Sub
Public Sub AutoFitToolLayout()
    '旧ボタン名・旧マクロ名との互換用。実体は書式復旧へ寄せる。
    RestoreToolFormatting
End Sub

Public Sub RestoreToolFormatting()
    Dim ws As Worksheet
    If Not RequireToolReady() Then Exit Sub
    On Error GoTo EH
    AppBegin "書式を復旧しています..."

    If SheetExists(SH_INPUT) Then
        Set ws = GetSheet(SH_INPUT)
        ws.Unprotect Password:=TOOL_PASSWORD
        PolishInputLayout ws
        RestoreAllTransactionRowStyles ws
        BuildOperationPanel ws
        BuildInputHelpCards ws
        ApplyInputSettings False
    End If

    If SheetExists(SH_OUTPUT_TX) Then FormatCashOperationOutputLayout GetSheet(SH_OUTPUT_TX)
    If SheetExists(SH_OUTPUT_TX_CONVERTED) Then FormatCashOperationOutputLayout GetSheet(SH_OUTPUT_TX_CONVERTED)
    If SheetExists(SH_SHOP_TARGET) Then FormatShopConversionTargetSheet GetSheet(SH_SHOP_TARGET)
    If SheetExists(SH_OUTPUT_BAL) Then FormatBalanceTransitionOutputLayout GetSheet(SH_OUTPUT_BAL)
    If SheetExists(SH_WORK_TX) Then FormatWorkTx
    If SheetExists(SH_WORK_BAL) Then FormatWorkBal

    If SheetExists(SH_INPUT) Then FixUnreadableWhiteTextOnSheet GetSheet(SH_INPUT)
    If SheetExists(SH_OUTPUT_TX) Then FixUnreadableWhiteTextOnSheet GetSheet(SH_OUTPUT_TX)
    If SheetExists(SH_OUTPUT_TX_CONVERTED) Then FixUnreadableWhiteTextOnSheet GetSheet(SH_OUTPUT_TX_CONVERTED)
    If SheetExists(SH_SHOP_TARGET) Then FixUnreadableWhiteTextOnSheet GetSheet(SH_SHOP_TARGET)
    If SheetExists(SH_OUTPUT_BAL) Then FixUnreadableWhiteTextOnSheet GetSheet(SH_OUTPUT_BAL)

    If SheetExists(SH_INPUT) Then LockToolShapes GetSheet(SH_INPUT)
    If SheetExists(SH_SHOP_TARGET) Then LockToolShapes GetSheet(SH_SHOP_TARGET)

    ProtectInputSheet
    If SheetExists(SH_SHOP_TARGET) Then ProtectShopConversionTargetSheet
    EnableInputKeys
    AppEnd
    MsgBox "書式を復旧しました。入力欄、ボタン、資金操作表、取扱店変換対象の見た目を整え直しています。", vbInformation
    Exit Sub
EH:
    ProtectInputSheet
    EnableInputKeys
    AppEnd
    MsgBox "書式復旧中にエラーが発生しました。" & vbCrLf & "Err " & Err.Number & ": " & Err.Description, vbExclamation
End Sub

Public Sub RestoreAllTransactionRowStyles(Optional ByVal ws As Worksheet = Nothing)
    Dim r As Long
    If ws Is Nothing Then
        If Not SheetExists(SH_INPUT) Then Exit Sub
        Set ws = GetSheet(SH_INPUT)
    End If
    On Error Resume Next
    For r = TX_FIRST_ROW To TX_LAST_ROW
        With ws.Range(ws.Cells(r, COL_TX_YEAR), ws.Cells(r, COL_TX_OTHER))
            If (r - TX_FIRST_ROW) Mod 2 = 0 Then
                .Interior.Color = vbWhite
            Else
                .Interior.Color = ThemeColor("canvas")
            End If
            .Font.Color = ThemeColor("text")
            .Borders.LineStyle = xlContinuous
            .Borders.Color = ThemeColor("border-soft")
        End With
    Next r
    On Error GoTo 0
End Sub
Public Sub AddCheck(ByVal levelText As String, ByVal sourceText As String, ByVal messageText As String)
    Dim ws As Worksheet
    Dim r As Long
    On Error Resume Next
    Set ws = GetOrCreateSheet(SH_CHECK, False)
    If ws Is Nothing Then Exit Sub
    If Len(CellText(ws.Range("A1").Value)) = 0 Then SetRowValues ws.Range("A1"), Array("区分", "発生元", "内容", "記録時刻")
    r = ws.Cells(ws.Rows.Count, 1).End(xlUp).Row + 1
    If r < 2 Then r = 2
    ws.Cells(r, 1).Value = levelText
    ws.Cells(r, 2).Value = sourceText
    ws.Cells(r, 3).Value = messageText
    ws.Cells(r, 4).Value = Now
    On Error GoTo 0
End Sub

Public Sub SafeSelectCell(ByVal ws As Worksheet, ByVal addressText As String)
    On Error Resume Next
    If ws Is Nothing Then Exit Sub
    ThisWorkbook.Activate
    ws.Activate
    ws.Range(addressText).Select
    On Error GoTo 0
End Sub

Public Sub SafeFreezeOutputHeader(ByVal ws As Worksheet)
    Dim prevSheet As Worksheet
    Dim win As Window
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    Set prevSheet = ActiveSheet
    If ws.Visible <> xlSheetVisible Then ws.Visible = xlSheetVisible
    ThisWorkbook.Activate
    ws.Activate
    Set win = Application.ActiveWindow
    If Not win Is Nothing Then
        win.FreezePanes = False
        win.SplitColumn = 0
        win.SplitRow = 0
        ws.Range("A2").Select
        win.FreezePanes = True
    End If
    If Not prevSheet Is Nothing Then prevSheet.Activate
    On Error GoTo 0
End Sub

Public Sub SafeFreezeInput()
    Dim ws As Worksheet
    Dim win As Window
    On Error Resume Next
    Set ws = ThisWorkbook.Worksheets(SH_INPUT)
    If ws Is Nothing Then Exit Sub
    ThisWorkbook.Activate
    ws.Activate
    Set win = Application.ActiveWindow
    If win Is Nothing Then Exit Sub
    win.FreezePanes = False
    ws.Range("B15").Select
    win.FreezePanes = True
    On Error GoTo 0
End Sub

Public Function RequireToolReady() As Boolean
    RequireToolReady = False
    If Not SheetExists(SH_INPUT) Then
        MsgBox "入力シートがありません。SetupWorkbook を実行してください。", vbExclamation
        Exit Function
    End If
    If Not SheetExists(SH_WORK_TX) Then
        MsgBox "作業シートがありません。SetupWorkbook を実行してください。", vbExclamation
        Exit Function
    End If
    If Not SheetExists(SH_CONFIG) Then
        MsgBox "設定シートがありません。SetupWorkbook を実行してください。", vbExclamation
        Exit Function
    End If
    RequireToolReady = True
End Function

Public Sub HideDailySheets(Optional ByVal hideOutputs As Boolean = False)
    '普段触らない作業・候補シートを隠し、入力画面を作業の中心にする。
    On Error Resume Next
    If SheetExists(SH_INPUT) Then ThisWorkbook.Worksheets(SH_INPUT).Visible = xlSheetVisible
    HideSheetIfExists SH_CONFIG
    HideSheetIfExists SH_TEKIYO
    HideSheetIfExists SH_ACCOUNT_TYPE
    HideSheetIfExists SH_INPUT_MODE
    HideSheetIfExists SH_YEAR_MODE
    HideSheetIfExists SH_DISPLAY_OPTION
    HideSheetIfExists SH_POST_KEEP
    HideSheetIfExists SH_POST_CLEAR
    HideSheetIfExists SH_BANK_CAND
    HideSheetIfExists SH_BRANCH_CAND
    HideSheetIfExists SH_PERSON_CAND
    HideSheetIfExists SH_WORK_TX
    HideSheetIfExists SH_WORK_BAL
    HideSheetIfExists SH_CHECK
    HideSheetIfExists SH_SETUP_LOG
    If hideOutputs Then
        HideSheetIfExists SH_OUTPUT_TX
        HideSheetIfExists SH_OUTPUT_BAL
        HideSheetIfExists SH_SHOP_TARGET
        HideSheetIfExists SH_OUTPUT_TX_CONVERTED
    End If
    On Error GoTo 0
End Sub

Public Sub HideSheetIfExists(ByVal sheetName As String)
    On Error Resume Next
    If SheetExists(sheetName) Then
        If ThisWorkbook.Worksheets(sheetName).Name <> ActiveSheet.Name Then ThisWorkbook.Worksheets(sheetName).Visible = xlSheetHidden
    End If
    On Error GoTo 0
End Sub

Public Sub ShowCandidateSheets()
    If Not RequireToolReady() Then Exit Sub
    On Error Resume Next
    ThisWorkbook.Worksheets(SH_BANK_CAND).Visible = xlSheetVisible
    ThisWorkbook.Worksheets(SH_BRANCH_CAND).Visible = xlSheetVisible
    ThisWorkbook.Worksheets(SH_PERSON_CAND).Visible = xlSheetVisible
    If SheetExists(SH_WORK_PERSON_REF) Then ThisWorkbook.Worksheets(SH_WORK_PERSON_REF).Visible = xlSheetVisible
    If SheetExists(SH_WORK_ACCOUNT) Then ThisWorkbook.Worksheets(SH_WORK_ACCOUNT).Visible = xlSheetVisible
    ThisWorkbook.Worksheets(SH_BANK_CAND).Activate
    ThisWorkbook.Worksheets(SH_BANK_CAND).Range("A2").Select
    On Error GoTo 0
End Sub

Public Sub ShowConfigSheet()
    If Not RequireToolReady() Then Exit Sub
    On Error Resume Next
    ThisWorkbook.Worksheets(SH_CONFIG).Visible = xlSheetVisible
    ThisWorkbook.Worksheets(SH_CONFIG).Activate
    ThisWorkbook.Worksheets(SH_CONFIG).Range("C4").Select
    On Error GoTo 0
End Sub

Public Sub ShowInputSheet()
    '取扱店変換対象や出力シートから、入力作業の中心画面へ戻るための導線。
    If Not SheetExists(SH_INPUT) Then Exit Sub
    On Error Resume Next
    ThisWorkbook.Worksheets(SH_INPUT).Visible = xlSheetVisible
    ThisWorkbook.Worksheets(SH_INPUT).Activate
    ProtectInputSheet
    EnableInputKeys
    ThisWorkbook.Worksheets(SH_INPUT).Range("C5").Select
    On Error GoTo 0
End Sub

Public Sub ShowCheckSheet()
    If Not SheetExists(SH_CHECK) Then Exit Sub
    On Error Resume Next
    ThisWorkbook.Worksheets(SH_CHECK).Visible = xlSheetVisible
    ThisWorkbook.Worksheets(SH_CHECK).Activate
    On Error GoTo 0
End Sub


Public Sub ShowShopConversionTargetSheet()
    If Not SheetExists(SH_SHOP_TARGET) Then Exit Sub
    On Error Resume Next
    ThisWorkbook.Worksheets(SH_SHOP_TARGET).Visible = xlSheetVisible
    ThisWorkbook.Worksheets(SH_SHOP_TARGET).Activate
    ThisWorkbook.Worksheets(SH_SHOP_TARGET).Range("A1").Select
    On Error GoTo 0
End Sub

Public Sub ShowConvertedCashOperationSheet()
    If Not SheetExists(SH_OUTPUT_TX_CONVERTED) Then Exit Sub
    On Error Resume Next
    ThisWorkbook.Worksheets(SH_OUTPUT_TX_CONVERTED).Visible = xlSheetVisible
    ThisWorkbook.Worksheets(SH_OUTPUT_TX_CONVERTED).Activate
    ThisWorkbook.Worksheets(SH_OUTPUT_TX_CONVERTED).Range("A1").Select
    On Error GoTo 0
End Sub

Public Sub ProtectReadOnlyOutputSheet(ByVal ws As Worksheet)
    '出力帳票は確認・印刷・コピー用に限定し、直接編集による連携ID破損を防ぐ。
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    ws.Unprotect Password:=TOOL_PASSWORD
    ws.Cells.Locked = True
    LockToolShapes ws
    ws.Protect Password:=TOOL_PASSWORD, DrawingObjects:=True, Contents:=True, Scenarios:=False, _
               UserInterfaceOnly:=True, AllowFiltering:=True, AllowSorting:=True, _
               AllowFormattingCells:=False, AllowFormattingColumns:=False, AllowFormattingRows:=False
    ws.EnableSelection = xlNoRestrictions
    On Error GoTo 0
End Sub


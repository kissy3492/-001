Attribute VB_Name = "modTransfer"
Option Explicit

Public Sub TransferCurrentAccount()
    TransferCurrentAccountCore ""
End Sub

Public Sub TransferCurrentAccountKeepBankBranch()
    TransferCurrentAccountCore KEEP_BANK_BRANCH
End Sub

Public Sub TransferCurrentAccountNextBranch()
    TransferCurrentAccountCore KEEP_BANK_BRANCH_PERSON_TYPE, True
End Sub

Private Sub TransferCurrentAccountCore(Optional ByVal keepOverride As String = "", Optional ByVal nextBranchAfter As Boolean = False)
    Dim wsIn As Worksheet, wsTx As Worksheet, wsBal As Worksheet
    Dim bankName As String, branchName As String, personName As String, relationName As String, accType As String, accNo As String
    Dim personId As String, accountId As String, transferId As String, txId As String
    Dim openDate As Variant, closeDate As Variant
    Dim yAdd As Long, currentYear As Long, currentMonth As Long, currentDay As Long
    Dim r As Long, outRow As Long, txCount As Long, warnCount As Long, inputOrder As Long
    Dim txDate As Variant, txTime As Variant, dateOK As Boolean, timeOK As Boolean
    Dim tekiyo As String, prevTekiyo As String
    Dim focusKeepPolicy As String, nextAccNo As String, shopFinal As String
    If Not RequireToolReady() Then Exit Sub
    On Error GoTo EH
    AppBegin "口座転記中..."
    Set wsIn = GetSheet(SH_INPUT)
    Set wsTx = GetSheet(SH_WORK_TX)
    Set wsBal = GetSheet(SH_WORK_BAL)

    SyncSelectedPersonFromInput wsIn
    bankName = CellText(wsIn.Range(CELL_BANK).Value)
    branchName = CellText(wsIn.Range(CELL_BRANCH).Value)
    personName = CellText(wsIn.Range(CELL_PERSON).Value)
    relationName = CellText(wsIn.Range(CELL_RELATIONSHIP).Value)
    accType = CellText(wsIn.Range(CELL_ACCOUNT_TYPE).Value)
    accNo = CellText(wsIn.Range(CELL_ACCOUNT_NO).Value)
    personId = ResolveInputPersonId(wsIn, personName)
    If Len(relationName) = 0 Then relationName = PersonRelationById(personId)
    openDate = NormalizedAccountDateForUse(wsIn.Range(CELL_OPEN_DATE).Value)
    closeDate = NormalizedAccountDateForUse(wsIn.Range(CELL_CLOSE_DATE).Value)
    nextAccNo = NextBranchAccountNo(accNo)
    focusKeepPolicy = keepOverride
    If Len(focusKeepPolicy) = 0 Then focusKeepPolicy = GetPostTransferKeepPolicy()
    yAdd = GetCfgLong(ROW_CFG_YEAR_ADD, 2000)

    If Len(bankName & branchName & personName & accType & accNo) = 0 Then
        AppEnd
        MsgBox "口座情報が空です。", vbExclamation
        Exit Sub
    End If
    If IsCommonLinkEnabled() And Len(personId) = 0 Then
        AddCheck "警告", "入力!" & CELL_PERSON, "人物IDが未連携です。人物情報を読込んでから氏名候補を選ぶと、後続分析まで自動連携できます。"
        warnCount = warnCount + 1
    End If

    UpdateAccountCandidates bankName, branchName, personName
    transferId = NextTransferId()
    accountId = GetOrCreateWorkAccountId(personId, personName, relationName, bankName, branchName, accType, accNo, openDate, closeDate)
    wsIn.Range(CELL_ACCOUNT_ID).Value = accountId

    AppendAccountEvent wsTx, bankName, branchName, personName, relationName, accType, accNo, openDate, ROW_KIND_OPEN, personId, accountId, transferId
    AppendAccountEvent wsTx, bankName, branchName, personName, relationName, accType, accNo, closeDate, ROW_KIND_CLOSE, personId, accountId, transferId
    AppendBalances wsIn, wsTx, wsBal, bankName, branchName, personName, relationName, accType, accNo, openDate, closeDate, personId, accountId, transferId

    For r = TX_FIRST_ROW To TX_LAST_ROW
        If Not IsTransactionRowBlank(wsIn, r) Then
            txDate = ResolveInputDate(wsIn.Cells(r, COL_TX_YEAR).Value, wsIn.Cells(r, COL_TX_MONTH).Value, wsIn.Cells(r, COL_TX_DAY).Value, currentYear, currentMonth, currentDay, yAdd, dateOK)
            If Not dateOK Then AddCheck "確認", "入力!" & CStr(r) & "行", "日付に変換できません。": warnCount = warnCount + 1
            txTime = NormalizeTimeInput(wsIn.Cells(r, COL_TX_TIME).Value, timeOK)
            If HasText(wsIn.Cells(r, COL_TX_TIME).Value) And Not timeOK Then AddCheck "確認", "入力!" & CStr(r) & "行", "時刻に変換できません。": warnCount = warnCount + 1
            If HasText(wsIn.Cells(r, COL_TX_WITHDRAW).Value) And HasText(wsIn.Cells(r, COL_TX_DEPOSIT).Value) Then AddCheck "確認", "入力!" & CStr(r) & "行", "出金と入金の両方に入力があります。": warnCount = warnCount + 1
            If IsDate(txDate) And Not AccountExistsAtDate(txDate, openDate, closeDate) Then AddCheck "確認", "入力!" & CStr(r) & "行", "口座開設日前または解約日後の取引です。": warnCount = warnCount + 1

            tekiyo = CellText(wsIn.Cells(r, COL_TX_TEKIYO).Value)
            If Len(tekiyo) = 0 And Len(prevTekiyo) > 0 And HasText(wsIn.Cells(r, COL_TX_OTHER).Value) Then tekiyo = prevTekiyo
            If Len(tekiyo) > 0 Then
                prevTekiyo = tekiyo
                UpdateTekiyoCandidate tekiyo
            End If

            outRow = LastRow(wsTx, 1) + 1
            If outRow < 2 Then outRow = 2
            wsTx.Cells(outRow, 1).Value = bankName
            wsTx.Cells(outRow, 2).Value = branchName
            wsTx.Cells(outRow, 3).Value = personName
            wsTx.Cells(outRow, 4).Value = accType
            wsTx.Cells(outRow, 5).Value = accNo
            If IsDate(txDate) Then wsTx.Cells(outRow, 6).Value = CDate(txDate) Else wsTx.Cells(outRow, 6).Value = wsIn.Cells(r, COL_TX_YEAR).Value & "/" & wsIn.Cells(r, COL_TX_MONTH).Value & "/" & wsIn.Cells(r, COL_TX_DAY).Value
            If IsDate(txTime) Then wsTx.Cells(outRow, 7).Value = CDate(txTime) Else wsTx.Cells(outRow, 7).Value = CellText(wsIn.Cells(r, COL_TX_TIME).Value)
            wsTx.Cells(outRow, 8).Value = ToAmountOrBlank(wsIn.Cells(r, COL_TX_WITHDRAW).Value)
            wsTx.Cells(outRow, 9).Value = ToAmountOrBlank(wsIn.Cells(r, COL_TX_DEPOSIT).Value)
            wsTx.Cells(outRow, 10).Value = CellText(wsIn.Cells(r, COL_TX_SHOP).Value)
            wsTx.Cells(outRow, 11).Value = CellText(wsIn.Cells(r, COL_TX_MACHINE).Value)
            wsTx.Cells(outRow, 12).Value = tekiyo
            wsTx.Cells(outRow, 13).Value = ToAmountOrBlank(wsIn.Cells(r, COL_TX_OTHER).Value)
            wsTx.Cells(outRow, 14).Value = relationName
            txId = NextTransactionId()
            inputOrder = inputOrder + 1
            shopFinal = CellText(wsIn.Cells(r, COL_TX_SHOP).Value)
            If Len(shopFinal) = 0 Then shopFinal = branchName
            RegisterWorkTxMeta wsTx, outRow, personId, accountId, txId, ROW_KIND_TRANSACTION, transferId, r, inputOrder, shopFinal
            txCount = txCount + 1
        End If
    Next r

    FormatWorkTx wsTx
    FormatWorkBal wsBal
    RefreshAccountCandidateNames
    AppendLinkLog "口座転記", "完了", personName & " / " & bankName & " " & branchName & " / 取引" & txCount & "件"
    AppEnd
    If warnCount > 0 Then
        MsgBox "転記しました。取引 " & txCount & " 件。" & vbCrLf & "確認事項が " & warnCount & " 件あります。C_チェックを確認してください。", vbExclamation
        ShowCheckSheet
    Else
        MsgBox "転記しました。取引 " & txCount & " 件。", vbInformation
    End If
    If nextBranchAfter Then SetNextBranchAccountNumber nextAccNo
    ApplyPostTransferCleanup focusKeepPolicy
    FocusAfterPostTransferCleanup focusKeepPolicy
    Exit Sub
EH:
    AppEnd
    MsgBox "転記中にエラーが発生しました。" & vbCrLf & "Err " & Err.Number & ": " & Err.Description, vbExclamation
End Sub

Private Sub AppendAccountEvent(ByVal wsTx As Worksheet, ByVal bankName As String, ByVal branchName As String, ByVal personName As String, _
                               ByVal relationName As String, ByVal accType As String, ByVal accNo As String, _
                               ByVal eventDate As Variant, ByVal rowKind As String, ByVal personId As String, ByVal accountId As String, ByVal transferId As String)
    Dim outRow As Long
    If Not IsDate(eventDate) Then Exit Sub
    outRow = LastRow(wsTx, 1) + 1
    If outRow < 2 Then outRow = 2
    wsTx.Cells(outRow, 1).Value = bankName
    wsTx.Cells(outRow, 2).Value = branchName
    wsTx.Cells(outRow, 3).Value = personName
    wsTx.Cells(outRow, 4).Value = accType
    wsTx.Cells(outRow, 5).Value = accNo
    wsTx.Cells(outRow, 6).Value = CDate(eventDate)
    wsTx.Cells(outRow, 12).Value = IIf(rowKind = ROW_KIND_OPEN, "口座開設日", "口座解約日")
    wsTx.Cells(outRow, 14).Value = relationName
    RegisterWorkTxMeta wsTx, outRow, personId, accountId, "", rowKind, transferId, 0, 0, branchName
End Sub

Private Sub AppendBalances(ByVal wsIn As Worksheet, ByVal wsTx As Worksheet, ByVal wsBal As Worksheet, _
                           ByVal bankName As String, ByVal branchName As String, ByVal personName As String, ByVal relationName As String, _
                           ByVal accType As String, ByVal accNo As String, ByVal openDate As Variant, ByVal closeDate As Variant, _
                           ByVal personId As String, ByVal accountId As String, ByVal transferId As String)
    Dim c As Long, labelText As String, balValue As Variant, balDate As Variant, otherValue As Variant
    Dim outTx As Long, outBal As Long, balanceId As String
    otherValue = ToAmountOrBlank(wsIn.Cells(BAL_VALUE_ROW, BAL_FIRST_COL + BAL_MAX_LABELS).Value)
    For c = BAL_FIRST_COL To BAL_FIRST_COL + BAL_MAX_LABELS - 1
        labelText = CellText(wsIn.Cells(BAL_LABEL_ROW, c).Value)
        If Len(labelText) = 0 Then GoTo ContinueC
        balValue = ToAmountOrBlank(wsIn.Cells(BAL_VALUE_ROW, c).Value)
        balDate = wsIn.Cells(BAL_DATE_ROW, c).Value
        If Len(CellText(balValue)) = 0 And Len(CellText(balDate)) = 0 Then GoTo ContinueC
        outTx = LastRow(wsTx, 1) + 1
        If outTx < 2 Then outTx = 2
        wsTx.Cells(outTx, 1).Value = bankName
        wsTx.Cells(outTx, 2).Value = branchName
        wsTx.Cells(outTx, 3).Value = personName
        wsTx.Cells(outTx, 4).Value = accType
        wsTx.Cells(outTx, 5).Value = accNo
        If IsDate(balDate) Then wsTx.Cells(outTx, 6).Value = CDate(balDate)
        wsTx.Cells(outTx, 12).Value = labelText & " 残高"
        wsTx.Cells(outTx, 13).Value = balValue
        wsTx.Cells(outTx, 14).Value = relationName
        RegisterWorkTxMeta wsTx, outTx, personId, accountId, "", ROW_KIND_BALANCE, transferId, 0, 0, branchName

        outBal = LastRow(wsBal, 1) + 1
        If outBal < 2 Then outBal = 2
        balanceId = NextBalanceId()
        wsBal.Cells(outBal, 1).Value = personName
        wsBal.Cells(outBal, 2).Value = bankName
        wsBal.Cells(outBal, 3).Value = branchName
        wsBal.Cells(outBal, 4).Value = accType
        wsBal.Cells(outBal, 5).Value = accNo
        If IsDate(openDate) Then wsBal.Cells(outBal, 6).Value = CDate(openDate)
        If IsDate(closeDate) Then wsBal.Cells(outBal, 7).Value = CDate(closeDate)
        If IsDate(balDate) Then wsBal.Cells(outBal, 8).Value = CDate(balDate)
        wsBal.Cells(outBal, 9).Value = labelText
        wsBal.Cells(outBal, 10).Value = balValue
        wsBal.Cells(outBal, 11).Value = otherValue
        wsBal.Cells(outBal, 12).Value = relationName
        RegisterWorkBalMeta wsBal, outBal, personId, accountId, balanceId, transferId
ContinueC:
    Next c
End Sub

Public Sub FormatWorkTx(Optional ByVal ws As Worksheet)
    If ws Is Nothing Then Set ws = GetSheet(SH_WORK_TX)
    If ws Is Nothing Then Exit Sub
    ws.Columns("A:X").ColumnWidth = 14
    ws.Columns("F:F").NumberFormatLocal = "yyyy/m/d"
    ws.Columns("G:G").NumberFormatLocal = "hh:mm"
    ws.Columns("H:I").NumberFormatLocal = "#,##0"
    ws.Columns("M:M").NumberFormatLocal = "#,##0"
    ws.Columns("O:X").NumberFormatLocal = "@"
End Sub

Public Sub FormatWorkBal(Optional ByVal ws As Worksheet)
    If ws Is Nothing Then Set ws = GetSheet(SH_WORK_BAL)
    If ws Is Nothing Then Exit Sub
    ws.Columns("A:R").ColumnWidth = 14
    ws.Columns("F:H").NumberFormatLocal = "yyyy/m/d"
    ws.Columns("J:J").NumberFormatLocal = "#,##0"
    ws.Columns("M:R").NumberFormatLocal = "@"
End Sub

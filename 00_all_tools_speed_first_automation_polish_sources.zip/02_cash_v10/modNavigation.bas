Attribute VB_Name = "modNavigation"
Option Explicit

Private mLastHighlightRow As Long
Private mLastEditedRow As Long
Private mLastEditedCol As Long
Private mRedirecting As Boolean

'同一口座番号警告は、入力行を移動するたびに作業シート全体を走査すると重くなる。
'現在の口座情報＋作業シート件数をキーにキャッシュし、同じ状態では再走査しない。
Private mDuplicateCacheKey As String
Private mDuplicateCacheMessage As String

Public Sub EnableInputKeys()
    '入力シートが有効な間だけTab/Shift+Tabを制御する。
    'v9: Excel全体のOnKeyを使うため、必ずこのブック＋入力シートがアクティブな時だけ有効化する。
    On Error Resume Next
    If ActiveWorkbook Is Nothing Then Exit Sub
    If ActiveWorkbook.Name <> ThisWorkbook.Name Then Exit Sub
    If ActiveSheet Is Nothing Then Exit Sub
    If ActiveSheet.Name <> SH_INPUT Then Exit Sub
    Application.EnableEvents = True
    Application.OnKey "{TAB}", MacroRef("InputTabNext")
    Application.OnKey "+{TAB}", MacroRef("InputTabPrev")
    Application.OnKey "~", MacroRef("InputTabNext")
    On Error GoTo 0
End Sub

Public Sub DisableInputKeys()
    On Error Resume Next
    Application.OnKey "{TAB}"
    Application.OnKey "+{TAB}"
    Application.OnKey "~"
    Application.StatusBar = False
    On Error GoTo 0
End Sub

Public Sub InvalidateDuplicateAccountWarningCache()
    '転記・初期化・手動編集などで作業シートの内容が変わった時に呼ぶ。
    '古い「重複なし」判定が残ると警告を見落とすため、明示的に破棄する。
    mDuplicateCacheKey = vbNullString
    mDuplicateCacheMessage = vbNullString
End Sub

Public Sub RestoreInputNavigation()
    On Error Resume Next
    AppForceRestore
    Application.EnableEvents = True
    If SheetExists(SH_INPUT) Then
        ThisWorkbook.Worksheets(SH_INPUT).Visible = xlSheetVisible
        ThisWorkbook.Worksheets(SH_INPUT).Activate
        ProtectInputSheet
        EnableInputKeys
        ThisWorkbook.Worksheets(SH_INPUT).Cells(TX_FIRST_ROW, COL_TX_DAY).Select
    End If
    On Error GoTo 0
    MsgBox "Tab移動を復旧しました。通常モードでは、摘要の次に次行の日へ移動します。", vbInformation
End Sub

Public Sub InputTabNext()
    MoveInputCell False
End Sub

Public Sub InputTabPrev()
    MoveInputCell True
End Sub

Public Sub MoveInputCell(ByVal backwards As Boolean)
    Dim ws As Worksheet
    Dim nextCell As Range
    On Error GoTo SafeExit
    If ActiveWorkbook Is Nothing Then GoTo SafeExit
    If ActiveWorkbook.Name <> ThisWorkbook.Name Then GoTo SafeExit
    If ActiveSheet Is Nothing Then GoTo SafeExit
    If ActiveSheet.Name <> SH_INPUT Then GoTo SafeExit
    Set ws = ActiveSheet
    Set nextCell = GetNextInputCell(ws, ActiveCell, backwards)
    If Not nextCell Is Nothing Then Application.Goto nextCell, False
SafeExit:
    On Error GoTo 0
End Sub

Public Function GetNextInputCell(ByVal ws As Worksheet, ByVal cur As Range, ByVal backwards As Boolean) As Range
    Dim r As Long, c As Long, memoCol As Long
    If ws Is Nothing Or cur Is Nothing Then Exit Function
    r = cur.Row: c = cur.Column
    memoCol = BalanceMemoCol(ws)
    If IsAccountCell(cur) Then
        Set GetNextInputCell = NextAccountCell(ws, cur, backwards)
        Exit Function
    End If
    If r = BAL_VALUE_ROW And c >= BAL_FIRST_COL And c <= memoCol Then
        Set GetNextInputCell = NextBalanceCell(ws, cur, backwards, memoCol)
        Exit Function
    End If
    If r >= TX_FIRST_ROW And r <= TX_LAST_ROW And c >= COL_TX_YEAR And c <= COL_TX_OTHER Then
        Set GetNextInputCell = NextTransactionCell(ws, cur, backwards)
        Exit Function
    End If
    Set GetNextInputCell = ws.Range(CELL_BANK)
End Function

Private Function IsAccountCell(ByVal cur As Range) As Boolean
    Dim a As String
    If cur Is Nothing Then Exit Function
    a = cur.Address(False, False)
    IsAccountCell = (a = CELL_BANK Or a = CELL_BRANCH Or a = CELL_PERSON Or _
                     (UseRelationshipDisplay() And a = CELL_RELATIONSHIP) Or _
                     a = CELL_ACCOUNT_TYPE Or a = CELL_ACCOUNT_NO Or a = CELL_OPEN_DATE Or a = CELL_CLOSE_DATE)
End Function

Private Function NextAccountCell(ByVal ws As Worksheet, ByVal cur As Range, ByVal backwards As Boolean) As Range
    Dim arr As Variant, i As Long
    If UseRelationshipDisplay() Then
        arr = Array(CELL_BANK, CELL_BRANCH, CELL_PERSON, CELL_RELATIONSHIP, CELL_ACCOUNT_TYPE, CELL_ACCOUNT_NO, CELL_OPEN_DATE, CELL_CLOSE_DATE)
    Else
        arr = Array(CELL_BANK, CELL_BRANCH, CELL_PERSON, CELL_ACCOUNT_TYPE, CELL_ACCOUNT_NO, CELL_OPEN_DATE, CELL_CLOSE_DATE)
    End If
    For i = LBound(arr) To UBound(arr)
        If cur.Address(False, False) = CStr(arr(i)) Then
            If backwards Then
                If i = LBound(arr) Then Set NextAccountCell = ws.Range(CELL_BANK) Else Set NextAccountCell = ws.Range(CStr(arr(i - 1)))
            Else
                If i = UBound(arr) Then
                    Set NextAccountCell = FirstAvailableBalanceInputCell(ws)
                Else
                    Set NextAccountCell = ws.Range(CStr(arr(i + 1)))
                End If
            End If
            Exit Function
        End If
    Next i
    Set NextAccountCell = ws.Range(CELL_BANK)
End Function

Private Function NextBalanceCell(ByVal ws As Worksheet, ByVal cur As Range, ByVal backwards As Boolean, ByVal memoCol As Long) As Range
    '開設日前・解約日後でロックされた残高欄は、Tab移動でも飛ばす。
    'その他欄は常に入力可能なので、残高欄がすべて対象外でも最後に到達できる。
    If cur Is Nothing Then Exit Function
    If backwards Then
        Set NextBalanceCell = NextAvailableBalanceInputCell(ws, cur.Column, True)
    Else
        Set NextBalanceCell = NextAvailableBalanceInputCell(ws, cur.Column, False)
    End If
End Function

Private Function NextTransactionCell(ByVal ws As Worksheet, ByVal cur As Range, ByVal backwards As Boolean) As Range
    Dim cols As Variant, idx As Long, i As Long, targetCol As Long
    cols = TransactionRoute(GetInputMode())

    '【年・月の考え方】
    '2行目以降の連続入力では「日」から流す。一方、年替わりだけは素早く直せるよう、
    '日セルで Shift+Tab した場合は月ではなく年へ直接戻す。月セルはクリック・矢印キーでは編集可能。
    If cur.Column = COL_TX_YEAR And Not backwards Then Set NextTransactionCell = ws.Cells(cur.Row, COL_TX_MONTH): Exit Function
    If cur.Column = COL_TX_MONTH And Not backwards Then Set NextTransactionCell = ws.Cells(cur.Row, COL_TX_DAY): Exit Function
    If cur.Column = COL_TX_DAY And backwards Then Set NextTransactionCell = ws.Cells(cur.Row, COL_TX_YEAR): Exit Function
    If cur.Column = COL_TX_MONTH And backwards Then Set NextTransactionCell = ws.Cells(cur.Row, COL_TX_YEAR): Exit Function
    If cur.Column = COL_TX_YEAR And backwards Then
        If cur.Row <= TX_FIRST_ROW Then
            Set NextTransactionCell = ws.Cells(cur.Row, COL_TX_YEAR)
        Else
            Set NextTransactionCell = ws.Cells(cur.Row - 1, CLng(cols(UBound(cols))))
        End If
        Exit Function
    End If

    '通常モードではその他列をTabルートから外している。
    'ただしクリック・矢印キーで入った後にTabを押した場合は、同じ行の日ではなく次行の日へ送る。
    If cur.Column = COL_TX_OTHER Then
        If backwards Then
            Set NextTransactionCell = ws.Cells(cur.Row, COL_TX_TEKIYO)
        ElseIf cur.Row < TX_LAST_ROW Then
            Set NextTransactionCell = ws.Cells(cur.Row + 1, COL_TX_DAY)
        Else
            Set NextTransactionCell = ws.Cells(TX_LAST_ROW, COL_TX_OTHER)
        End If
        Exit Function
    End If

    idx = -1
    For i = LBound(cols) To UBound(cols)
        If CLng(cols(i)) = cur.Column Then idx = i: Exit For
    Next i
    If idx = -1 Then Set NextTransactionCell = ws.Cells(cur.Row, COL_TX_DAY): Exit Function
    If backwards Then
        If idx = LBound(cols) Then
            If cur.Row <= TX_FIRST_ROW Then Set NextTransactionCell = ws.Cells(TX_FIRST_ROW, COL_TX_DAY) Else Set NextTransactionCell = ws.Cells(cur.Row - 1, CLng(cols(UBound(cols))))
        Else
            Set NextTransactionCell = ws.Cells(cur.Row, CLng(cols(idx - 1)))
        End If
    Else
        If cur.Column = COL_TX_WITHDRAW And HasText(cur.Value) Then
            targetCol = RouteColumnAfter(cols, COL_TX_DEPOSIT)
            Set NextTransactionCell = ws.Cells(cur.Row, targetCol)
            Exit Function
        End If
        If idx = UBound(cols) Then
            If cur.Row >= TX_LAST_ROW Then Set NextTransactionCell = ws.Cells(TX_LAST_ROW, CLng(cols(idx))) Else Set NextTransactionCell = ws.Cells(cur.Row + 1, COL_TX_DAY)
        Else
            Set NextTransactionCell = ws.Cells(cur.Row, CLng(cols(idx + 1)))
        End If
    End If
End Function

Private Function TransactionRoute(ByVal modeText As String) As Variant
    If modeText = MODE_SIMPLE Then
        TransactionRoute = Array(COL_TX_DAY, COL_TX_WITHDRAW, COL_TX_DEPOSIT, COL_TX_SHOP)
    ElseIf modeText = MODE_NO_TIME Then
        TransactionRoute = Array(COL_TX_DAY, COL_TX_WITHDRAW, COL_TX_DEPOSIT, COL_TX_SHOP, COL_TX_MACHINE, COL_TX_TEKIYO)
    ElseIf modeText = MODE_NO_MACHINE Then
        TransactionRoute = Array(COL_TX_DAY, COL_TX_TIME, COL_TX_WITHDRAW, COL_TX_DEPOSIT, COL_TX_SHOP, COL_TX_TEKIYO)
    ElseIf modeText = MODE_NO_TEKIYO Then
        TransactionRoute = Array(COL_TX_DAY, COL_TX_TIME, COL_TX_WITHDRAW, COL_TX_DEPOSIT, COL_TX_SHOP, COL_TX_MACHINE)
    ElseIf modeText = MODE_WITH_OTHER Then
        TransactionRoute = Array(COL_TX_DAY, COL_TX_TIME, COL_TX_WITHDRAW, COL_TX_DEPOSIT, COL_TX_SHOP, COL_TX_MACHINE, COL_TX_TEKIYO, COL_TX_OTHER)
    Else
        TransactionRoute = Array(COL_TX_DAY, COL_TX_TIME, COL_TX_WITHDRAW, COL_TX_DEPOSIT, COL_TX_SHOP, COL_TX_MACHINE, COL_TX_TEKIYO)
    End If
End Function

Private Function RouteColumnAfter(ByVal cols As Variant, ByVal afterCol As Long) As Long
    Dim i As Long
    For i = LBound(cols) To UBound(cols) - 1
        If CLng(cols(i)) = afterCol Then RouteColumnAfter = CLng(cols(i + 1)): Exit Function
    Next i
    RouteColumnAfter = COL_TX_SHOP
End Function

Public Sub OnInputSelectionChange(ByVal Target As Range)
    Dim t As Range
    On Error Resume Next
    If Target Is Nothing Then Exit Sub
    Set t = Target
    If t.Cells.CountLarge > 1 Then
        If t.MergeCells Then
            Set t = t.MergeArea.Cells(1, 1)
        Else
            Exit Sub
        End If
    End If
    If mRedirecting Then Exit Sub
    'その他列は通常Tabルートからは外すが、クリック・矢印キーで入った場合はそのまま編集させる。
    'ここで自動退避させると、入力中のメモが書けなくなる。
    SmartRedirectAfterDefaultMove t
    UpdateCurrentRowHighlight t
    UpdateComplementStatus t
    ShowCashInputMicroHint t
    On Error GoTo 0
End Sub

Public Sub OnInputChange(ByVal Target As Range)
    Dim nextCol As Long
    Dim t As Range
    If Target Is Nothing Then Exit Sub
    Set t = Target
    If t.Cells.CountLarge > 1 Then
        If t.MergeCells Then
            Set t = t.MergeArea.Cells(1, 1)
        Else
            HandleBulkInputChange t
            Exit Sub
        End If
    End If
    If t.Worksheet.Name <> SH_INPUT Then Exit Sub

    '銀行名・支店名・人物名は、入力したものを次回以降の候補にする。
    'あわせて口座番号の重複警告も再判定する。銀行名や人物名を直した時に警告が消えるようにするため。
    If t.Address(False, False) = CELL_BANK Or t.Address(False, False) = CELL_BRANCH Or t.Address(False, False) = CELL_PERSON Or t.Address(False, False) = CELL_RELATIONSHIP Then
        UpdateCandidateFromTarget t
        If t.Address(False, False) = CELL_PERSON Then SyncSelectedPersonFromInput t.Worksheet
        If Not UpdateDuplicateAccountStatus(t.Worksheet) Then UpdateComplementStatus t
        Exit Sub
    End If

    If t.Address(False, False) = CELL_ACCOUNT_TYPE Or t.Address(False, False) = CELL_ACCOUNT_NO Then
        If Not UpdateDuplicateAccountStatus(t.Worksheet) Then UpdateComplementStatus t
        Exit Sub
    End If

    If t.Address(False, False) = CELL_OPEN_DATE Or t.Address(False, False) = CELL_CLOSE_DATE Then
        '開設日・解約日は、和暦数字入力をその場で yyyy/m/d 表示へ整え、残高欄の入力可否を更新する。
        On Error Resume Next
        Application.EnableEvents = False
        NormalizeAccountDateEntry t
        Application.EnableEvents = True
        t.Worksheet.Unprotect Password:=TOOL_PASSWORD
        ApplyBalanceAvailability t.Worksheet
        ProtectInputSheet
        If Not UpdateDuplicateAccountStatus(t.Worksheet) Then UpdateComplementStatus t
        On Error GoTo 0
        Exit Sub
    End If

    If t.Row < TX_FIRST_ROW Or t.Row > TX_LAST_ROW Then Exit Sub

    If t.Column = COL_TX_TIME Then
        On Error Resume Next
        Application.EnableEvents = False
        NormalizeTransactionTimeEntry t
        Application.EnableEvents = True
        On Error GoTo 0
        If Not UpdateDuplicateAccountStatus(t.Worksheet) Then UpdateComplementStatus t
    End If

    If t.Column = COL_TX_TEKIYO Then UpdateTekiyoCandidate CellText(t.Value)

    mLastEditedRow = t.Row
    mLastEditedCol = t.Column

    If t.Column = COL_TX_WITHDRAW And HasText(t.Value) Then
        nextCol = RouteColumnAfter(TransactionRoute(GetInputMode()), COL_TX_DEPOSIT)
        SafeGoto t.Worksheet.Cells(t.Row, nextCol)
    ElseIf t.Column = COL_TX_DEPOSIT And HasText(t.Value) Then
        nextCol = RouteColumnAfter(TransactionRoute(GetInputMode()), COL_TX_DEPOSIT)
        SafeGoto t.Worksheet.Cells(t.Row, nextCol)
    ElseIf t.Column = COL_TX_TEKIYO And GetInputMode() <> MODE_WITH_OTHER Then
        If t.Row < TX_LAST_ROW Then SafeGoto t.Worksheet.Cells(t.Row + 1, COL_TX_DAY)
    End If
End Sub

Private Sub HandleBulkInputChange(ByVal Target As Range)
    '複数行貼り付けは止めずに受ける。ただし自動移動はしない。
    '時刻欄・摘要候補など、後続分析に効く軽い整形だけ行う。
    Dim ws As Worksheet, rng As Range, cell As Range
    Dim prevEvents As Boolean
    If Target Is Nothing Then Exit Sub
    If Target.Worksheet.Name <> SH_INPUT Then Exit Sub
    Set ws = Target.Worksheet
    Set rng = Intersect(Target, ws.Range(ws.Cells(TX_FIRST_ROW, COL_TX_YEAR), ws.Cells(TX_LAST_ROW, COL_TX_OTHER)))
    If rng Is Nothing Then Exit Sub
    prevEvents = Application.EnableEvents
    On Error GoTo SafeExit
    Application.EnableEvents = False
    For Each cell In rng.Cells
        If cell.Column = COL_TX_TIME And HasText(cell.Value) Then NormalizeTransactionTimeEntry cell
        If cell.Column = COL_TX_TEKIYO And HasText(cell.Value) Then UpdateTekiyoCandidate CellText(cell.Value)
    Next cell
    InvalidateDuplicateAccountWarningCache
    UpdateComplementStatus rng.Cells(1, 1)
    Application.StatusBar = "貼り付け内容を受け付けました。時刻欄は整形済みです。必要なら C_チェック / 転記前確認を実行してください。"
SafeExit:
    Application.EnableEvents = prevEvents
End Sub

Private Sub ShowCashInputMicroHint(ByVal Target As Range)
    Dim a As String, msg As String
    If Target Is Nothing Then Exit Sub
    a = Target.Address(False, False)
    If IsAccountCell(Target) Then
        Select Case a
            Case CELL_BANK
                msg = "銀行名です。入力済み銀行は候補化され、次回以降は選ぶだけで使えます。"
            Case CELL_BRANCH
                msg = "支店名です。銀行名と組み合わせて口座候補・帳票表示に使います。"
            Case CELL_PERSON
                msg = "名義人です。人物情報から選ぶと人物ID・続柄が連携されます。"
            Case CELL_RELATIONSHIP
                msg = "続柄は人物情報から自動反映されます。原則として直接入力せず確認用です。"
            Case CELL_ACCOUNT_TYPE
                msg = "科目です。普通・定期など、候補から選べます。"
            Case CELL_ACCOUNT_NO
                msg = "口座番号です。同じ口座番号が既にある場合は画面内で警告します。"
            Case CELL_OPEN_DATE
                msg = "口座開設日です。残高欄の入力可否と資金操作表の補助行に使います。"
            Case CELL_CLOSE_DATE
                msg = "口座解約日です。解約後の残高欄は自動的に入力対象外にします。"
            Case Else
                msg = "口座情報を入力します。人物・銀行・支店・科目は候補から再利用できます。"
        End Select
    ElseIf Target.Row = BAL_VALUE_ROW Then
        msg = "残高欄です。空欄でも、外部表13列目の取引後残高から年末・相続開始日時点残高を補完できます。"
    ElseIf Target.Row >= TX_FIRST_ROW And Target.Row <= TX_LAST_ROW Then
        Select Case Target.Column
            Case COL_TX_YEAR
                msg = "年欄です。通常の連続入力は日から始め、年替わりだけここを直します。"
            Case COL_TX_MONTH
                msg = "月欄です。同じ月が続く場合は補完されます。"
            Case COL_TX_DAY
                msg = "日欄です。Enter / Tab で時刻または出金欄へ進みます。"
            Case COL_TX_TIME
                msg = "時刻欄です。12:00、1200、12時などを整形し、同日内の出金→入金判定に使います。"
            Case COL_TX_WITHDRAW
                msg = "出金欄です。入力すると入金欄を飛ばして次の必要欄へ進みます。"
            Case COL_TX_DEPOSIT
                msg = "入金欄です。出金と入金を同じ行に入れない運用です。"
            Case COL_TX_SHOP
                msg = "取扱店欄です。伝票依頼先キーに使うため、確定値へ変換・確認します。"
            Case COL_TX_MACHINE
                msg = "機番欄です。同日時刻帯・同一操作傾向の補助分析に役立ちます。"
            Case COL_TX_TEKIYO
                msg = "摘要欄です。一度入力した摘要は候補化されます。Enterで次行へ進みます。"
            Case COL_TX_OTHER
                msg = "その他欄です。自由補足用です。外部表13列目残高は専用の取引後残高列で扱います。"
            Case Else
                msg = "取引入力欄です。Enter / Tab で必要欄だけを流れるように移動します。"
        End Select
    Else
        msg = "入力画面です。白い欄だけ入力できます。候補は再利用し、ID列は触らない設計です。"
    End If
    Application.StatusBar = msg
End Sub

Private Sub SmartRedirectAfterDefaultMove(ByVal Target As Range)
    Dim nextCol As Long
    If Target.Worksheet.Name <> SH_INPUT Then Exit Sub
    If Target.Row < TX_FIRST_ROW Or Target.Row > TX_LAST_ROW Then Exit Sub

    If Target.Column = COL_TX_DEPOSIT Then
        If HasText(Target.Worksheet.Cells(Target.Row, COL_TX_WITHDRAW).Value) Then
            nextCol = RouteColumnAfter(TransactionRoute(GetInputMode()), COL_TX_DEPOSIT)
            SafeGoto Target.Worksheet.Cells(Target.Row, nextCol)
            Exit Sub
        End If
    End If

    'その他列は通常Tabでは通らないが、矢印キー・クリックでは入力可能にする。
End Sub

Private Sub SafeGoto(ByVal targetCell As Range)
    If targetCell Is Nothing Then Exit Sub
    On Error GoTo SafeExit
    mRedirecting = True
    Application.Goto targetCell, False
SafeExit:
    mRedirecting = False
    On Error GoTo 0
End Sub

Private Sub UpdateCurrentRowHighlight(ByVal Target As Range)
    Dim ws As Worksheet
    Set ws = Target.Worksheet
    If mLastHighlightRow >= TX_FIRST_ROW And mLastHighlightRow <= TX_LAST_ROW Then
        RestoreTransactionRowStyle ws, mLastHighlightRow
    End If
    If Target.Row >= TX_FIRST_ROW And Target.Row <= TX_LAST_ROW Then
        With ws.Range(ws.Cells(Target.Row, COL_TX_YEAR), ws.Cells(Target.Row, COL_TX_OTHER))
            .Interior.Color = ThemeColor("info-soft")
            .Font.Color = ThemeColor("text")
            .Borders.Color = ThemeColor("blue")
        End With
        mLastHighlightRow = Target.Row
    Else
        mLastHighlightRow = 0
    End If
End Sub

Private Sub RestoreTransactionRowStyle(ByVal ws As Worksheet, ByVal rowNo As Long)
    If ws Is Nothing Then Exit Sub
    With ws.Range(ws.Cells(rowNo, COL_TX_YEAR), ws.Cells(rowNo, COL_TX_OTHER))
        If (rowNo - TX_FIRST_ROW) Mod 2 = 0 Then
            .Interior.Color = vbWhite
        Else
            .Interior.Color = ThemeColor("canvas")
        End If
        .Font.Color = ThemeColor("text")
        .Borders.Color = ThemeColor("border-soft")
    End With
End Sub
Private Sub UpdateComplementStatus(ByVal Target As Range)
    Dim ws As Worksheet, r As Long, cy As Long, cm As Long, cd As Long
    Dim ok As Boolean, timeOK As Boolean, yAdd As Long, d As Variant, tVal As Variant
    Dim textY As String, textM As String, textD As String, textTime As String
    Set ws = Target.Worksheet

    '同じ口座番号が既に転記済みなら、補完値欄を警告カードとして使う。
    'メッセージボックスを出すと入力の手が止まるため、画面内の色と文言だけで知らせる。
    If UpdateDuplicateAccountStatus(ws) Then Exit Sub

    ApplyStatusStyle ws, False
    If Target.Row < TX_FIRST_ROW Then
        ws.Range(CELL_STATUS).Value = "補完値　-年　-月　-日　--:--"
        Exit Sub
    End If
    yAdd = GetCfgLong(ROW_CFG_YEAR_ADD, 2000)
    textTime = "--:--"
    For r = TX_FIRST_ROW To Target.Row
        If Not IsTransactionRowBlank(ws, r) Then
            d = ResolveInputDate(ws.Cells(r, COL_TX_YEAR).Value, ws.Cells(r, COL_TX_MONTH).Value, ws.Cells(r, COL_TX_DAY).Value, cy, cm, cd, yAdd, ok)
            If HasText(ws.Cells(r, COL_TX_TIME).Value) Then
                tVal = NormalizeTimeInput(ws.Cells(r, COL_TX_TIME).Value, timeOK)
                If timeOK And IsDate(tVal) Then textTime = Format$(CDate(tVal), "hh:mm")
            End If
        End If
    Next r
    If cy = 0 Then textY = "-" Else textY = CStr(cy)
    If cm = 0 Then textM = "-" Else textM = CStr(cm)
    If cd = 0 Then textD = "-" Else textD = CStr(cd)
    ws.Range(CELL_STATUS).Value = "補完値　" & textY & "年　" & textM & "月　" & textD & "日　" & textTime
End Sub



Public Function UpdateDuplicateAccountStatus(ByVal ws As Worksheet) As Boolean
    Dim msg As String
    If ws Is Nothing Then Exit Function
    msg = DuplicateAccountWarningMessage(ws)
    If Len(msg) > 0 Then
        ApplyStatusStyle ws, True
        ws.Range(CELL_STATUS).Value = msg
        UpdateDuplicateAccountStatus = True
    Else
        ApplyStatusStyle ws, False
    End If
End Function

Private Function DuplicateAccountWarningMessage(ByVal ws As Worksheet) As String
    Dim bankName As String, branchName As String, personName As String, accType As String, accNo As String
    Dim hitInfo As String
    Dim cacheKey As String
    If ws Is Nothing Then Exit Function

    accNo = NormalizeAccountHyphen(CellText(ws.Range(CELL_ACCOUNT_NO).Value))
    If Len(accNo) = 0 Then
        InvalidateDuplicateAccountWarningCache
        Exit Function
    End If

    bankName = CellText(ws.Range(CELL_BANK).Value)
    branchName = CellText(ws.Range(CELL_BRANCH).Value)
    personName = CellText(ws.Range(CELL_PERSON).Value)
    accType = CellText(ws.Range(CELL_ACCOUNT_TYPE).Value)

    cacheKey = DuplicateAccountCacheKey(bankName, branchName, personName, accType, accNo)
    If cacheKey = mDuplicateCacheKey Then
        DuplicateAccountWarningMessage = mDuplicateCacheMessage
        Exit Function
    End If

    '既に転記済みの作業シートから、同じ口座番号の候補を探す。
    '作業シートが大きくなっても、同じ入力状態ではキャッシュを使うため移動時の負荷を抑えられる。
    hitInfo = FindDuplicateAccountInWorkSheets(bankName, branchName, personName, accType, accNo)
    If Len(hitInfo) > 0 Then
        DuplicateAccountWarningMessage = "確認　同じ口座番号の転記済み候補があります：" & accNo & "　" & hitInfo
    End If

    mDuplicateCacheKey = cacheKey
    mDuplicateCacheMessage = DuplicateAccountWarningMessage
End Function

Private Function DuplicateAccountCacheKey(ByVal bankName As String, ByVal branchName As String, ByVal personName As String, ByVal accType As String, ByVal accNo As String) As String
    '口座情報だけでなく、作業シートの最終行もキーに含める。
    '転記後に行数が増えた場合は同じ口座番号でも再判定される。
    Dim txLast As Long
    Dim balLast As Long

    If SheetExists(SH_WORK_TX) Then txLast = LastRow(GetSheet(SH_WORK_TX), OUT_COL_BANK)
    If SheetExists(SH_WORK_BAL) Then balLast = LastRow(GetSheet(SH_WORK_BAL), 1)

    DuplicateAccountCacheKey = bankName & Chr$(30) & branchName & Chr$(30) & personName & Chr$(30) & _
                               accType & Chr$(30) & accNo & Chr$(30) & CStr(txLast) & Chr$(30) & CStr(balLast)
End Function

Private Function FindDuplicateAccountInWorkSheets(ByVal bankName As String, ByVal branchName As String, ByVal personName As String, ByVal accType As String, ByVal accNo As String) As String
    Dim ws As Worksheet, r As Long, lastR As Long
    Dim hitCount As Long, firstHit As String
    If Len(accNo) = 0 Then Exit Function

    If SheetExists(SH_WORK_TX) Then
        Set ws = GetSheet(SH_WORK_TX)
        lastR = LastRow(ws, OUT_COL_BANK)
        For r = 2 To lastR
            If WorkAccountMatches(ws, r, bankName, branchName, personName, accType, accNo) Then
                hitCount = hitCount + 1
                If Len(firstHit) = 0 Then firstHit = "W_取引 " & CStr(r) & "行"
            End If
        Next r
    End If

    If hitCount = 0 And SheetExists(SH_WORK_BAL) Then
        Set ws = GetSheet(SH_WORK_BAL)
        lastR = LastRow(ws, 1)
        For r = 2 To lastR
            If WorkBalanceAccountMatches(ws, r, bankName, branchName, personName, accType, accNo) Then
                hitCount = hitCount + 1
                If Len(firstHit) = 0 Then firstHit = "W_残高 " & CStr(r) & "行"
            End If
        Next r
    End If

    If hitCount = 1 Then
        FindDuplicateAccountInWorkSheets = firstHit
    ElseIf hitCount > 1 Then
        FindDuplicateAccountInWorkSheets = firstHit & " ほか " & CStr(hitCount - 1) & "件"
    End If
End Function

Private Function WorkAccountMatches(ByVal ws As Worksheet, ByVal r As Long, ByVal bankName As String, ByVal branchName As String, ByVal personName As String, ByVal accType As String, ByVal accNo As String) As Boolean
    If NormalizeAccountHyphen(CellText(ws.Cells(r, OUT_COL_ACCOUNT_NO).Value)) <> accNo Then Exit Function
    If Len(bankName) > 0 And CellText(ws.Cells(r, OUT_COL_BANK).Value) <> bankName Then Exit Function
    If Len(branchName) > 0 And CellText(ws.Cells(r, OUT_COL_BRANCH).Value) <> branchName Then Exit Function
    If Len(personName) > 0 And CellText(ws.Cells(r, OUT_COL_PERSON).Value) <> personName Then Exit Function
    If Len(accType) > 0 And CellText(ws.Cells(r, OUT_COL_ACCOUNT_TYPE).Value) <> accType Then Exit Function
    WorkAccountMatches = True
End Function

Private Function WorkBalanceAccountMatches(ByVal ws As Worksheet, ByVal r As Long, ByVal bankName As String, ByVal branchName As String, ByVal personName As String, ByVal accType As String, ByVal accNo As String) As Boolean
    'W_残高は、1:氏名 2:銀行名 3:支店名 4:科目 5:口座番号 の構成。
    If NormalizeAccountHyphen(CellText(ws.Cells(r, 5).Value)) <> accNo Then Exit Function
    If Len(personName) > 0 And CellText(ws.Cells(r, 1).Value) <> personName Then Exit Function
    If Len(bankName) > 0 And CellText(ws.Cells(r, 2).Value) <> bankName Then Exit Function
    If Len(branchName) > 0 And CellText(ws.Cells(r, 3).Value) <> branchName Then Exit Function
    If Len(accType) > 0 And CellText(ws.Cells(r, 4).Value) <> accType Then Exit Function
    WorkBalanceAccountMatches = True
End Function

Private Sub ApplyStatusStyle(ByVal ws As Worksheet, ByVal warningMode As Boolean)
    Dim rng As Range
    If ws Is Nothing Then Exit Sub
    Set rng = ws.Range(CELL_STATUS & ":K12")
    If warningMode Then
        rng.Interior.Color = ThemeColor("danger-soft")
        rng.Font.Color = ThemeColor("danger-text")
        rng.Borders.Color = ThemeColor("danger-border")
    Else
        rng.Interior.Color = ThemeColor("success-bg")
        rng.Font.Color = ThemeColor("teal-text")
        rng.Borders.Color = ThemeColor("teal-border")
    End If
    rng.Font.Bold = True
    rng.HorizontalAlignment = xlCenter
    rng.VerticalAlignment = xlCenter
End Sub

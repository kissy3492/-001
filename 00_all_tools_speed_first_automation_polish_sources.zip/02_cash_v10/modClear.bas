Attribute VB_Name = "modClear"
Option Explicit

Public Sub ClearTransactionInput()
    Dim ws As Worksheet
    If Not SheetExists(SH_INPUT) Then Exit Sub
    Set ws = GetSheet(SH_INPUT)
    On Error Resume Next
    ws.Unprotect Password:=TOOL_PASSWORD
    ws.Range(ws.Cells(TX_FIRST_ROW, COL_TX_YEAR), ws.Cells(TX_LAST_ROW, COL_TX_OTHER)).ClearContents
    RestoreAllTransactionRowStyles ws
    ProtectInputSheet
    On Error GoTo 0
End Sub

Public Sub ClearAllInputFields()
    ClearInputCore KEEP_NONE, True, True
End Sub

Public Sub ClearInputKeepPerson()
    ClearInputCore KEEP_PERSON_ONLY, True, True
End Sub

Public Sub ClearInputKeepBankBranch()
    ClearInputCore KEEP_BANK_BRANCH, True, True
End Sub

Public Sub ClearInputKeepBankBranchPersonType()
    ClearInputCore KEEP_BANK_BRANCH_PERSON_TYPE, True, True
End Sub

Public Sub ClearInputKeepBankAndPerson()
    '旧ボタン名との互換用。口座番号は必ず消す。
    ClearInputCore KEEP_BANK_BRANCH_PERSON_TYPE, True, True
End Sub

Public Sub IncrementAccountBranchNo()
    Dim ws As Worksheet
    Dim s As String
    If Not SheetExists(SH_INPUT) Then Exit Sub
    Set ws = GetSheet(SH_INPUT)
    s = CellText(ws.Range(CELL_ACCOUNT_NO).Value)
    If Len(s) = 0 Then
        MsgBox "口座番号を入力してから枝番+1を実行してください。" & vbCrLf & "例: 1234567 → 1234567-1 / 1234567-1 → 1234567-2", vbInformation
        Exit Sub
    End If
    SetNextBranchAccountNumber NextBranchAccountNo(s)
End Sub

Public Sub SetNextBranchAccountNumber(ByVal nextAccNo As String)
    Dim ws As Worksheet
    If Len(CellText(nextAccNo)) = 0 Then Exit Sub
    If Not SheetExists(SH_INPUT) Then Exit Sub
    Set ws = GetSheet(SH_INPUT)
    On Error Resume Next
    ws.Unprotect Password:=TOOL_PASSWORD
    ws.Range(CELL_ACCOUNT_NO).Value = nextAccNo
    ProtectInputSheet
    SafeSelectCell ws, CELL_ACCOUNT_NO
    On Error GoTo 0
End Sub

Public Sub ApplyPostTransferCleanup(Optional ByVal overrideKeepPolicy As String = "")
    Dim keepPolicy As String
    Dim clearTx As Boolean
    Dim clearBal As Boolean
    keepPolicy = overrideKeepPolicy
    If Len(keepPolicy) = 0 Then keepPolicy = GetPostTransferKeepPolicy()
    clearTx = GetPostTransferClearTransaction()
    clearBal = GetPostTransferClearBalance()
    ClearInputCore keepPolicy, clearTx, clearBal
End Sub

Public Sub ApplyPostTransferCleanupKeepBankBranch()
    ApplyPostTransferCleanup KEEP_BANK_BRANCH
End Sub

Public Sub FocusAfterPostTransferCleanup(Optional ByVal keepPolicy As String = "")
    Dim targetAddress As String
    Dim ws As Worksheet
    If Not SheetExists(SH_INPUT) Then Exit Sub
    If Len(keepPolicy) = 0 Then keepPolicy = GetPostTransferKeepPolicy()

    '転記後に残す項目に合わせて、次に自然に入力するセルへ移動する。
    Select Case keepPolicy
        Case KEEP_BANK_BRANCH_PERSON_TYPE
            targetAddress = CELL_ACCOUNT_NO          '既定：銀行名・支店名・氏名・科目を残し、次の口座番号へ
        Case KEEP_BANK_BRANCH
            targetAddress = CELL_PERSON              '銀行名・支店名だけ残るので、次は氏名
        Case KEEP_PERSON_ONLY
            targetAddress = CELL_BANK                '氏名だけ残るので、次は銀行名
        Case KEEP_ALL_ACCOUNT
            targetAddress = wsCellAddress(TX_FIRST_ROW, COL_TX_DAY) '口座情報が残るなら、次は明細入力
        Case Else
            targetAddress = CELL_BANK                '何も残さない場合は先頭から
    End Select

    Set ws = GetSheet(SH_INPUT)
    If Not ws Is Nothing Then SafeSelectCell ws, targetAddress
End Sub

Public Sub SetInputStatus(ByVal statusText As String)
    Dim ws As Worksheet
    If Not SheetExists(SH_INPUT) Then Exit Sub
    On Error Resume Next
    Set ws = GetSheet(SH_INPUT)
    ws.Range(CELL_STATUS & ":K12").Interior.Color = ThemeColor("success-bg")
    ws.Range(CELL_STATUS & ":K12").Font.Color = ThemeColor("teal-text")
    ws.Range(CELL_STATUS & ":K12").Borders.Color = ThemeColor("teal-border")
    ws.Range(CELL_STATUS).Value = statusText
    On Error GoTo 0
End Sub

Private Function wsCellAddress(ByVal rowNo As Long, ByVal colNo As Long) As String
    wsCellAddress = GetSheet(SH_INPUT).Cells(rowNo, colNo).Address(False, False)
End Function

Private Sub ClearInputCore(ByVal keepPolicy As String, ByVal clearTx As Boolean, ByVal clearBal As Boolean)
    Dim ws As Worksheet
    Dim bankName As String, branchName As String, personName As String, relationName As String, accType As String
    Dim accNo As String, openDate As Variant, closeDate As Variant
    Dim memoCol As Long
    Dim rr As Long
    If Not SheetExists(SH_INPUT) Then Exit Sub
    Set ws = GetSheet(SH_INPUT)

    bankName = CellText(ws.Range(CELL_BANK).Value)
    branchName = CellText(ws.Range(CELL_BRANCH).Value)
    personName = CellText(ws.Range(CELL_PERSON).Value)
    relationName = CellText(ws.Range(CELL_RELATIONSHIP).Value)
    accType = CellText(ws.Range(CELL_ACCOUNT_TYPE).Value)
    accNo = CellText(ws.Range(CELL_ACCOUNT_NO).Value)
    openDate = ws.Range(CELL_OPEN_DATE).Value
    closeDate = ws.Range(CELL_CLOSE_DATE).Value

    On Error Resume Next
    ws.Unprotect Password:=TOOL_PASSWORD

    ClearEffectiveContents ws.Range(CELL_BANK)
    ClearEffectiveContents ws.Range(CELL_BRANCH)
    ClearEffectiveContents ws.Range(CELL_PERSON)
    ClearEffectiveContents ws.Range(CELL_RELATIONSHIP)
    ClearEffectiveContents ws.Range(CELL_ACCOUNT_TYPE)
    ClearEffectiveContents ws.Range(CELL_ACCOUNT_NO)
    ClearEffectiveContents ws.Range(CELL_OPEN_DATE)
    ClearEffectiveContents ws.Range(CELL_CLOSE_DATE)
    ws.Range(CELL_PERSON_ID).ClearContents
    ws.Range(CELL_ACCOUNT_ID).ClearContents
    ws.Range(CELL_LINK_STATUS).ClearContents

    memoCol = BalanceMemoCol(ws)
    If clearBal Then
        If memoCol > BAL_FIRST_COL Then ws.Range(ws.Cells(BAL_VALUE_ROW, BAL_FIRST_COL), ws.Cells(BAL_VALUE_ROW, memoCol - 1)).ClearContents
        ClearEffectiveContents ws.Cells(BAL_VALUE_ROW, memoCol)
    End If

    If clearTx Then
        ws.Range(ws.Cells(TX_FIRST_ROW, COL_TX_YEAR), ws.Cells(TX_LAST_ROW, COL_TX_OTHER)).ClearContents
        RestoreAllTransactionRowStyles ws
    End If

    Select Case keepPolicy
        Case KEEP_PERSON_ONLY
            ws.Range(CELL_PERSON).Value = personName
            If UseRelationshipDisplay() Then ws.Range(CELL_RELATIONSHIP).Value = relationName
        Case KEEP_BANK_BRANCH
            ws.Range(CELL_BANK).Value = bankName
            ws.Range(CELL_BRANCH).Value = branchName
        Case KEEP_BANK_BRANCH_PERSON_TYPE
            ws.Range(CELL_BANK).Value = bankName
            ws.Range(CELL_BRANCH).Value = branchName
            ws.Range(CELL_PERSON).Value = personName
            If UseRelationshipDisplay() Then ws.Range(CELL_RELATIONSHIP).Value = relationName
            ws.Range(CELL_ACCOUNT_TYPE).Value = accType
        Case KEEP_ALL_ACCOUNT
            ws.Range(CELL_BANK).Value = bankName
            ws.Range(CELL_BRANCH).Value = branchName
            ws.Range(CELL_PERSON).Value = personName
            If UseRelationshipDisplay() Then ws.Range(CELL_RELATIONSHIP).Value = relationName
            ws.Range(CELL_ACCOUNT_TYPE).Value = accType
            ws.Range(CELL_ACCOUNT_NO).Value = accNo
            ws.Range(CELL_OPEN_DATE).Value = openDate
            ws.Range(CELL_CLOSE_DATE).Value = closeDate
        Case Else
            '残さない
    End Select

    ws.Range(CELL_STATUS).Value = "補完値　-年　-月　-日　--:--"
    InvalidateDuplicateAccountWarningCache
    PolishInputLayout ws
    '開設日・解約日を消した後は、残高欄のロック状態も初期状態へ戻す。
    ApplyInputSettings False
    On Error GoTo 0
End Sub

Public Sub InitializeToolData()
    Dim answer As VbMsgBoxResult
    answer = MsgBox("入力欄、作業データ、出力シート、チェック結果を初期化します。" & vbCrLf & _
                    "設定と候補マスタは残します。よろしいですか？", vbYesNo + vbQuestion, "ツール初期化")
    If answer <> vbYes Then Exit Sub
    On Error GoTo EH
    AppBegin "初期化中..."
    ClearInputCore KEEP_NONE, True, True
    BuildWorkSheets
    ResetFinanceLinkData
    BuildOutputSheets
    BuildBalanceInputFields False
    ApplyInputSettings False
    HideDailySheets True
    If SheetExists(SH_INPUT) Then ThisWorkbook.Worksheets(SH_INPUT).Visible = xlSheetVisible
    AppEnd
    MsgBox "初期化しました。", vbInformation
    Exit Sub
EH:
    AppEnd
    MsgBox "初期化中にエラーが発生しました。" & vbCrLf & "Err " & Err.Number & ": " & Err.Description, vbExclamation
End Sub

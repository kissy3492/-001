Attribute VB_Name = "modSetup"
Option Explicit

Public Sub SetupWorkbook()
    Dim answer As VbMsgBoxResult
    Dim stepName As String
    Dim wsInput As Worksheet
    answer = MsgBox("空のブック、またはこのツール専用ブックで実行してください。" & vbCrLf & _
                    "同名シートは再作成し、設定値と候補も初期値に戻します。" & vbCrLf & vbCrLf & _
                    "セットアップを実行しますか？", vbYesNo + vbQuestion, _
                    "資金操作表作成補助ツール セットアップ")
    If answer <> vbYes Then Exit Sub
    On Error GoTo EH
    AppBegin "セットアップ中..."
    DisableInputKeys

    stepName = "セットアップログ初期化": ResetSetupLog: LogStep "開始", stepName, "OK", ""
    stepName = "シート準備": LogStep "処理", stepName, "開始", "": PrepareSheets: LogStep "完了", stepName, "OK", ""
    stepName = "設定シート作成": LogStep "処理", stepName, "開始", "": BuildConfigSheet: LogStep "完了", stepName, "OK", ""
    stepName = "マスタシート作成": LogStep "処理", stepName, "開始", "": BuildMasterSheets: LogStep "完了", stepName, "OK", ""
    stepName = "入力シート作成": LogStep "処理", stepName, "開始", "": BuildInputSheet: LogStep "完了", stepName, "OK", ""
    stepName = "作業シート作成": LogStep "処理", stepName, "開始", "": BuildWorkSheets: LogStep "完了", stepName, "OK", ""
    stepName = "出力シート作成": LogStep "処理", stepName, "開始", "": BuildOutputSheets: LogStep "完了", stepName, "OK", ""
    stepName = "残高欄生成": LogStep "処理", stepName, "開始", "": BuildBalanceInputFields False: LogStep "完了", stepName, "OK", ""
    stepName = "入力欄設定": LogStep "処理", stepName, "開始", "": ApplyInputSettings False: LogStep "完了", stepName, "OK", ""
    stepName = "セルフチェック": LogStep "処理", stepName, "開始", "": SelfCheckTool: LogStep "完了", stepName, "OK", ""
    stepName = "共通人物情報読込": LogStep "処理", stepName, "開始", "": LoadPersonMasterFromCommonData False: LogStep "完了", stepName, "OK", ""
    stepName = "シート表示整理": LogStep "処理", stepName, "開始", "": HideDailySheets True: LogStep "完了", stepName, "OK", ""

    stepName = "表示調整"
    Set wsInput = GetSheet(SH_INPUT)
    SafeFreezeInput
    SafeSelectCell wsInput, CELL_BANK
    HideDailySheets True
    RefreshButtonActions
    EnableInputKeys
    LogStep "完了", "SetupWorkbook", "セットアップ完了", ""
    AppEnd
    MsgBox "セットアップが完了しました。" & vbCrLf & "入力シート右上のメニューから実行できます。", vbInformation, "セットアップ完了"
    Exit Sub
EH:
    LogStep "エラー", stepName, "Err " & Err.Number, Err.Source & " / " & Err.Description
    AppEnd
    AppForceRestore
    MsgBox "セットアップ中にエラーが発生しました。" & vbCrLf & vbCrLf & _
           "工程: " & stepName & vbCrLf & "発生元: " & Err.Source & vbCrLf & _
           "Err " & Err.Number & ": " & Err.Description & vbCrLf & vbCrLf & _
           "W_セットアップログも確認してください。", vbExclamation, "セットアップエラー"
End Sub

Public Sub PrepareSheets()
    GetOrCreateSheet SH_CONFIG, True
    GetOrCreateSheet SH_INPUT, True
    GetOrCreateSheet SH_TEKIYO, True
    GetOrCreateSheet SH_ACCOUNT_TYPE, True
    GetOrCreateSheet SH_INPUT_MODE, True
    GetOrCreateSheet SH_YEAR_MODE, True
    GetOrCreateSheet SH_DISPLAY_OPTION, True
    GetOrCreateSheet SH_POST_KEEP, True
    GetOrCreateSheet SH_POST_CLEAR, True
    GetOrCreateSheet SH_BANK_CAND, True
    GetOrCreateSheet SH_BRANCH_CAND, True
    GetOrCreateSheet SH_PERSON_CAND, True
    GetOrCreateSheet SH_WORK_TX, True
    GetOrCreateSheet SH_WORK_BAL, True
    GetOrCreateSheet SH_CHECK, True
    GetOrCreateSheet SH_OUTPUT_TX, True
    GetOrCreateSheet SH_OUTPUT_BAL, True
    GetOrCreateSheet SH_SHOP_TARGET, True
    GetOrCreateSheet SH_OUTPUT_TX_CONVERTED, True
End Sub

Public Sub BuildConfigSheet()
    Dim ws As Worksheet
    On Error GoTo EH
    Set ws = GetSheet(SH_CONFIG)
    If ws Is Nothing Then Err.Raise vbObjectError + 1101, "BuildConfigSheet", "設定シートを取得できません。"
    With ws
        ThemeApplyCanvas ws
        .Cells.Font.Name = THEME_FONT
        .Cells.Font.Size = 10
        .Rows.RowHeight = 19
        .Columns("A:A").ColumnWidth = 3
        .Columns("B:B").ColumnWidth = 24
        .Columns("C:C").ColumnWidth = 18
        .Columns("D:D").ColumnWidth = 55
        .Columns("E:E").ColumnWidth = 2
        MergeAndFormat .Range("B2:D2"), "資金操作表作成補助ツール 設定"
        ThemeApplyTitle .Range("B2:D2")
        .Rows(2).RowHeight = 28
        .Range("B4").Value = "相続開始日": .Range("C4").Value = DateSerial(Year(Date), 1, 1): .Range("D4").Value = "残高欄・残高推移表・資金操作表の残高行に使います。"
        .Range("B5").Value = "残高表示開始年": .Range("C5").Value = Year(Date) - 4: .Range("D5").Value = "年末残高の表示開始年。"
        .Range("B6").Value = "残高表示終了年": .Range("C6").Value = Year(Date): .Range("D6").Value = "年末残高の表示終了年。"
        .Range("B7").Value = "西暦2桁加算値": .Range("C7").Value = 2000: .Range("D7").Value = "年入力方式が西暦2桁の時だけ使用。19→2019なら2000。"
        .Range("B8").Value = "入力モード": .Range("C8").Value = MODE_NORMAL: .Range("D8").Value = "通常、時刻なし、機番なし、摘要なし、その他あり、簡易。"
        .Range("B9").Value = "転記後に残す口座情報": .Range("C9").Value = KEEP_BANK_BRANCH_PERSON_TYPE: .Range("D9").Value = "既定値は銀行名・支店名・氏名・科目を残し、口座番号は消します。"
        .Range("B10").Value = "転記後の取引明細": .Range("C10").Value = POST_CLEAR: .Range("D10").Value = "転記後に取引明細欄を残すか選びます。通常はクリア。"
        .Range("B11").Value = "転記後の残高欄": .Range("C11").Value = POST_CLEAR: .Range("D11").Value = "転記後に残高欄を残すか選びます。通常はクリア。"
        .Range("B12").Value = "年入力方式": .Range("C12").Value = YEAR_MODE_WAREKI: .Range("D12").Value = "既定は和暦。01→令和元年=2019、31→平成31年=2019。西暦2桁へ切替可。"
        .Range("B13").Value = "続柄の入力・表示": .Range("C13").Value = DISPLAY_ON: .Range("D13").Value = "表示しない場合、入力シートの続柄欄は入力不可になり、各出力にも表示しません。"
        .Range("B14").Value = "相続開始日行": .Range("C14").Value = DISPLAY_ON: .Range("D14").Value = "資金操作表に相続開始日を示す行を入れるか選びます。"
        .Range("B15").Value = "口座開設日行": .Range("C15").Value = DISPLAY_ON: .Range("D15").Value = "資金操作表に口座開設日行を入れるか選びます。"
        .Range("B16").Value = "口座解約日行": .Range("C16").Value = DISPLAY_ON: .Range("D16").Value = "資金操作表に口座解約日行を入れるか選びます。"
        .Range("B17").Value = "残高行": .Range("C17").Value = DISPLAY_ON: .Range("D17").Value = "各年末残高・相続開始日時点残高を資金操作表に出すか選びます。"
        .Range("B18").Value = "共通データ連携": .Range("C18").Value = DISPLAY_ON: .Range("D18").Value = "人物情報系ツールの00_共通データ.xlsxを読み、口座・取引・残高を書き戻します。"
        .Range("B19").Value = "共通データファイル": .Range("C19").Value = COMMON_DATA_FILE: .Range("D19").Value = "案件フォルダ内の共通データブック名。"
        .Range("B20").Value = "最終出力時の共通保存": .Range("C20").Value = DISPLAY_ON: .Range("D20").Value = "最終出力時に共通データへ保存します。"
        .Range("B4:B20").Font.Bold = True
        .Range("B4:C20").Borders.LineStyle = xlContinuous
        .Range("C4:C20").Interior.Color = vbWhite
        .Range("D4:D20").WrapText = True
        .Range("C4").NumberFormatLocal = "yyyy/m/d"
        .Range("C5:C7").NumberFormatLocal = "0"
        .Range("C8:C20").NumberFormatLocal = "@"
        .Range("B19:D19").Interior.Color = ThemeColor("border-soft")
        .Range("B19").Value = "操作": .Range("B19").Font.Bold = True
    End With
    AddConfigButton ws, "B23", "人物情報を読込", "LoadPersonMasterFromCommonData"
    AddConfigButton ws, "D23", "共通データへ保存", "SaveFinanceCommonData"
    AddConfigButton ws, "B25", "連携チェック", "ValidateFinanceLinkage"
    AddConfigButton ws, "D25", "残高欄を再生成", "BuildBalanceInputFields"
    AddConfigButton ws, "B27", "外部資金操作表取込", "ImportExternalCashOperationTable"
    AddConfigButton ws, "D27", "取引明細残高から補完", "RebuildBalancesFromTransactionAfterBalanceButton"
    AddConfigButton ws, "B29", "入力欄設定を更新", "ApplyInputSettings"
    AddConfigButton ws, "D29", "入力シートへ", "GoInputSheet"
    AddConfigButton ws, "B31", "書式を復旧", "RestoreToolFormatting"
    AddConfigButton ws, "D31", "ツール初期化", "InitializeToolData"
    With ws.Range("B33:D40")
        .Interior.Color = ThemeColor("locked")
        .Borders.LineStyle = xlContinuous
        .WrapText = True
        .VerticalAlignment = xlTop
    End With
    MergeAndFormat ws.Range("B33:D33"), "運用メモ"
    ws.Range("B33:D33").Font.Bold = True
    MergeAndFormat ws.Range("B34:D34"), "・入力は一口座一画面です。人物・住所は01で登録済みの候補から選び、二度打ちしません。"
    MergeAndFormat ws.Range("B35:D35"), "・続柄欄、相続開始日行、開設日・解約日・残高行は設定で表示を切り替えられます。"
    MergeAndFormat ws.Range("B36:D36"), "・外部資金操作表は13列目を取引後残高として取り込み、基準日時点残高へ自動補完します。"
    MergeAndFormat ws.Range("B37:D37"), "・同年中の取引がない年は、基準日以前で最後に確認できる取引後残高を繰り越して使います。"
    MergeAndFormat ws.Range("B38:D38"), "・資金操作表作成時、取扱店が空欄の取引行は支店名で補完します。"
    MergeAndFormat ws.Range("B39:D39"), "・コード形式の取扱店は、取扱店変換対象シートに銀行名とコード単位で整理します。"
    MergeAndFormat ws.Range("B40:D40"), "・変換後取扱店を入力し、対象シート右上の取扱店反映ボタンで最終版を作成します。"
    ws.Rows("33:40").RowHeight = 32

    '口座開設日・口座解約日用の元号マスタ。
    '「1.53.5.6」のような数字入力をここで管理する。新元号はこの表へ行を追加すれば対応できる。
    BuildEraMasterOnConfig ws

    AutoFitSheetSmart ws, "B:G", 10, 58
    Exit Sub
EH:
    Err.Raise Err.Number, "BuildConfigSheet", Err.Description

End Sub

Private Sub BuildEraMasterOnConfig(ByVal ws As Worksheet)
    '設定シート内に、開設日・解約日用の元号コード表を作る。
    '利用者はここを編集するだけで、新元号や元号境界日の変更に対応できる。
    If ws Is Nothing Then Exit Sub

    With ws.Range(ws.Cells(ERA_MASTER_TITLE_ROW, ERA_COL_CODE), ws.Cells(ERA_MASTER_TITLE_ROW, ERA_COL_ENABLED))
        .UnMerge
        .Merge
        .Value = "元号マスタ（開設日・解約日用）"
        .Font.Bold = True
        .Font.Size = 12
        .Font.Color = ThemeColor("blue")
        .Interior.Color = ThemeColor("section")
        .HorizontalAlignment = xlCenter
        .VerticalAlignment = xlCenter
        .Borders.LineStyle = xlContinuous
        .Borders.Color = ThemeColor("info-border")
    End With

    SetRowValues ws.Cells(ERA_MASTER_HEADER_ROW, ERA_COL_CODE), _
        Array("元号コード", "元号名", "略称", "開始日", "終了日", "有効")
    With ws.Range(ws.Cells(ERA_MASTER_HEADER_ROW, ERA_COL_CODE), ws.Cells(ERA_MASTER_HEADER_ROW, ERA_COL_ENABLED))
        .Font.Bold = True
        .Font.Color = vbWhite
        .Interior.Color = ThemeColor("blue")
        .HorizontalAlignment = xlCenter
        .VerticalAlignment = xlCenter
        .Borders.LineStyle = xlContinuous
        .Borders.Color = ThemeColor("info-border-strong")
    End With

    SetRowValues ws.Cells(ERA_MASTER_FIRST_ROW, ERA_COL_CODE), Array(1, "昭和", "S", DateSerial(1926, 12, 25), DateSerial(1989, 1, 7), "TRUE")
    SetRowValues ws.Cells(ERA_MASTER_FIRST_ROW + 1, ERA_COL_CODE), Array(2, "平成", "H", DateSerial(1989, 1, 8), DateSerial(2019, 4, 30), "TRUE")
    SetRowValues ws.Cells(ERA_MASTER_FIRST_ROW + 2, ERA_COL_CODE), Array(3, "令和", "R", DateSerial(2019, 5, 1), "", "TRUE")

    With ws.Range(ws.Cells(ERA_MASTER_FIRST_ROW, ERA_COL_CODE), ws.Cells(ERA_MASTER_MAX_ROW, ERA_COL_ENABLED))
        .Borders.LineStyle = xlContinuous
        .Borders.Color = ThemeColor("border-soft")
        .Interior.Color = vbWhite
        .VerticalAlignment = xlCenter
    End With
    ws.Range(ws.Cells(ERA_MASTER_FIRST_ROW, ERA_COL_START), ws.Cells(ERA_MASTER_MAX_ROW, ERA_COL_END)).NumberFormatLocal = "yyyy/m/d"
    ws.Range(ws.Cells(ERA_MASTER_FIRST_ROW, ERA_COL_CODE), ws.Cells(ERA_MASTER_MAX_ROW, ERA_COL_CODE)).HorizontalAlignment = xlCenter
    ws.Range(ws.Cells(ERA_MASTER_FIRST_ROW, ERA_COL_ENABLED), ws.Cells(ERA_MASTER_MAX_ROW, ERA_COL_ENABLED)).HorizontalAlignment = xlCenter

    ws.Columns("B:B").ColumnWidth = 24
    ws.Columns("C:C").ColumnWidth = 18
    ws.Columns("D:D").ColumnWidth = 12
    ws.Columns("E:F").ColumnWidth = 14
    ws.Columns("G:G").ColumnWidth = 10
    ws.Rows(ERA_MASTER_TITLE_ROW).RowHeight = 24
    ws.Rows(ERA_MASTER_HEADER_ROW & ":" & ERA_MASTER_MAX_ROW).RowHeight = 22

    With ws.Range(ws.Cells(ERA_MASTER_MAX_ROW + 2, ERA_COL_CODE), ws.Cells(ERA_MASTER_MAX_ROW + 3, ERA_COL_ENABLED))
        .UnMerge
        .Merge
        .Value = "開設日・解約日は 1.53.5.6=昭和53年5月6日、2.31.4.30=平成31年4月30日、3.1.5.1=令和元年5月1日。新元号は元号マスタに行を追加します。"
        .Font.Size = 9
        .Font.Color = ThemeColor("muted")
        .Interior.Color = ThemeColor("canvas")
        .WrapText = True
        .VerticalAlignment = xlTop
        .Borders.LineStyle = xlContinuous
        .Borders.Color = ThemeColor("border-soft")
    End With
    ws.Rows((ERA_MASTER_MAX_ROW + 2) & ":" & (ERA_MASTER_MAX_ROW + 3)).RowHeight = 31
End Sub

Public Sub BuildMasterSheets()
    Dim ws As Worksheet
    On Error GoTo EH
    Set ws = GetSheet(SH_TEKIYO)
    ws.Cells.Clear
    ws.Range("A1").Value = "摘要候補": ws.Range("A1").Font.Bold = True
    ws.Range("A2:A16").Value = Application.Transpose(Array("ATM", "振込", "振替", "手数料", "利息", "カード", "公共料金", "年金", "給与", "預入", "払戻", "引落", "口座振替", "同上", "その他"))
    ws.Columns("A:A").ColumnWidth = 20
    ResetName NM_LST_TEKIYO, ws.Range("A2:A16")
    Set ws = GetSheet(SH_ACCOUNT_TYPE)
    ws.Cells.Clear
    ws.Range("A1").Value = "科目候補": ws.Range("A1").Font.Bold = True
    ws.Range("A2:A45").Value = Application.Transpose(Array( _
        "普通", "普通預金", "通常", "通常貯金", "当座", "当座預金", _
        "定期", "定期預金", "定額", "定額貯金", "貯蓄", "貯蓄預金", "通常貯蓄", "通常貯蓄貯金", _
        "通知", "通知預金", "納税準備", "納税準備預金", _
        "積立定期", "積立定期預金", "大口定期", "大口定期預金", "期日指定定期", "変動金利定期", "定期積金", _
        "総合", "総合口座", "振替", "振替口座", _
        "担保定額", "担保定期", "自動積立定額", "自動積立定期", _
        "財形", "財形貯蓄", "財産形成", "財産形成定額", "財産形成年金", "財産形成住宅", _
        "外貨普通", "外貨定期", "外貨預金", "債券", "その他"))
    ws.Columns("A:A").ColumnWidth = 22
    ResetName NM_LST_ACCOUNT_TYPE, ws.Range("A2:A45")
    Set ws = GetSheet(SH_INPUT_MODE)
    ws.Cells.Clear
    ws.Range("A1").Value = "入力モード": ws.Range("A1").Font.Bold = True
    ws.Range("A2:A7").Value = Application.Transpose(Array(MODE_NORMAL, MODE_NO_TIME, MODE_NO_MACHINE, MODE_NO_TEKIYO, MODE_WITH_OTHER, MODE_SIMPLE))
    ws.Columns("A:A").ColumnWidth = 18
    ResetName NM_LST_INPUT_MODE, ws.Range("A2:A7")

    Set ws = GetSheet(SH_YEAR_MODE)
    ws.Cells.Clear
    ws.Range("A1").Value = "年入力方式": ws.Range("A1").Font.Bold = True
    ws.Range("A2:A3").Value = Application.Transpose(Array(YEAR_MODE_WAREKI, YEAR_MODE_WESTERN2))
    ws.Columns("A:A").ColumnWidth = 18
    ResetName NM_LST_YEAR_MODE, ws.Range("A2:A3")

    Set ws = GetSheet(SH_DISPLAY_OPTION)
    ws.Cells.Clear
    ws.Range("A1").Value = "表示切替": ws.Range("A1").Font.Bold = True
    ws.Range("A2:A3").Value = Application.Transpose(Array(DISPLAY_ON, DISPLAY_OFF))
    ws.Columns("A:A").ColumnWidth = 16
    ResetName NM_LST_DISPLAY_OPTION, ws.Range("A2:A3")

    Set ws = GetSheet(SH_POST_KEEP)
    ws.Cells.Clear
    ws.Range("A1").Value = "転記後に残す口座情報": ws.Range("A1").Font.Bold = True
    ws.Range("A2:A6").Value = Application.Transpose(Array(KEEP_NONE, KEEP_PERSON_ONLY, KEEP_BANK_BRANCH, KEEP_BANK_BRANCH_PERSON_TYPE, KEEP_ALL_ACCOUNT))
    ws.Columns("A:A").ColumnWidth = 36
    ResetName NM_LST_POST_KEEP, ws.Range("A2:A6")

    Set ws = GetSheet(SH_POST_CLEAR)
    ws.Cells.Clear
    ws.Range("A1").Value = "転記後処理": ws.Range("A1").Font.Bold = True
    ws.Range("A2:A3").Value = Application.Transpose(Array(POST_CLEAR, POST_KEEP))
    ws.Columns("A:A").ColumnWidth = 16
    ResetName NM_LST_POST_CLEAR, ws.Range("A2:A3")

    BuildCandidateSheets True
    ApplyValidationList GetCfgCell(ROW_CFG_INPUT_MODE), NM_LST_INPUT_MODE, xlIMEModeOff, False
    ApplyValidationList GetCfgCell(ROW_CFG_YEAR_MODE), NM_LST_YEAR_MODE, xlIMEModeOff, False
    ApplyValidationList GetCfgCell(ROW_CFG_RELATIONSHIP), NM_LST_DISPLAY_OPTION, xlIMEModeOff, False
    ApplyValidationList GetCfgCell(ROW_CFG_SHOW_INHERITANCE_ROW), NM_LST_DISPLAY_OPTION, xlIMEModeOff, False
    ApplyValidationList GetCfgCell(ROW_CFG_SHOW_OPEN_DATE_ROW), NM_LST_DISPLAY_OPTION, xlIMEModeOff, False
    ApplyValidationList GetCfgCell(ROW_CFG_SHOW_CLOSE_DATE_ROW), NM_LST_DISPLAY_OPTION, xlIMEModeOff, False
    ApplyValidationList GetCfgCell(ROW_CFG_SHOW_BALANCE_ROWS), NM_LST_DISPLAY_OPTION, xlIMEModeOff, False
    ApplyValidationList GetCfgCell(ROW_CFG_LINK_MODE), NM_LST_DISPLAY_OPTION, xlIMEModeOff, False
    ApplyValidationList GetCfgCell(ROW_CFG_AUTO_SAVE_COMMON), NM_LST_DISPLAY_OPTION, xlIMEModeOff, False
    ApplyValidationList GetCfgCell(ROW_CFG_POST_KEEP), NM_LST_POST_KEEP, xlIMEModeOff, False
    ApplyValidationList GetCfgCell(ROW_CFG_POST_TX), NM_LST_POST_CLEAR, xlIMEModeOff, False
    ApplyValidationList GetCfgCell(ROW_CFG_POST_BAL), NM_LST_POST_CLEAR, xlIMEModeOff, False
    Exit Sub
EH:
    Err.Raise Err.Number, "BuildMasterSheets", Err.Description
End Sub
Public Sub BuildInputSheet()
    Dim ws As Worksheet
    Dim r As Long
    On Error GoTo EH
    Set ws = GetSheet(SH_INPUT)
    If ws Is Nothing Then Err.Raise vbObjectError + 1201, "BuildInputSheet", "入力シートを取得できません。"
    With ws
        .Unprotect Password:=TOOL_PASSWORD
        .Cells.Clear
        ThemeApplyCanvas ws
        .Cells.Font.Name = THEME_FONT
        .Cells.Font.Size = 10
        .Cells.Font.Color = ThemeColor("text")
        .Rows.RowHeight = 20
        .Columns("A:A").ColumnWidth = 2
        .Columns("B:I").ColumnWidth = 14.5
        .Columns("J:J").ColumnWidth = 18
        .Columns("K:K").ColumnWidth = 24
        .Columns("L:L").ColumnWidth = 2
        .Columns("M:T").ColumnWidth = 12.8
        .Columns("U:U").ColumnWidth = 2
        .Columns("AA:AZ").Hidden = True

        MergeAndFormat .Range("B2:K2"), "資金操作表・残高推移表作成補助　入力（連携版）"
        ThemeApplyTitle .Range("B2:K2")
        .Rows(2).RowHeight = 30

        MergeAndFormat .Range("B4:K4"), "口座情報"
        FormatHeader .Range("B4:K4")
        ThemeApplyFormCard .Range("B4:K6"), "accent"
        .Range("B5").Value = "銀行名": MergeAndFormat .Range("C5:D5"), ""
        .Range("E5").Value = "支店名": MergeAndFormat .Range("F5:G5"), ""
        .Range("H5").Value = "氏名": .Range("I5").Value = ""
        .Range("J5").Value = "続柄": .Range("K5").Value = ""
        .Range("B6").Value = "科目": MergeAndFormat .Range("C6:D6"), ""
        .Range("E6").Value = "口座番号": MergeAndFormat .Range("F6:G6"), ""
        .Range("H6").Value = "開設日": .Range("I6").Value = ""
        .Range("J6").Value = "解約日": .Range("K6").Value = ""
        .Range("B5:K6").Borders.LineStyle = xlContinuous
        .Range("B5:K6").Borders.Color = ThemeColor("border")
        .Range("B5,E5,H5,J5,B6,E6,H6,J6").Font.Bold = True
        .Range("B5,E5,H5,J5,B6,E6,H6,J6").Interior.Color = ThemeColor("locked")
        .Range("B5,E5,H5,J5,B6,E6,H6,J6").Font.Color = ThemeColor("blue")
        .Range("C5:D5,F5:G5,I5,K5,C6:D6,F6:G6,I6,K6").Interior.Color = ThemeColor("input")
        .Range("C5:D5,F5:G5,I5,K5,C6:D6,F6:G6,I6,K6").Font.Color = ThemeColor("text")

        MergeAndFormat .Range("B8:K8"), "残高入力"
        FormatHeader .Range("B8:K8")
        ThemeApplyFormCard .Range("B8:K12"), "teal"

        MergeAndFormat .Range(CELL_STATUS & ":K12"), "補完値　-年　-月　-日　--:--"
        With .Range(CELL_STATUS & ":K12")
            .Interior.Color = ThemeColor("success-bg")
            .Font.Color = ThemeColor("teal-text")
            .Borders.LineStyle = xlContinuous
            .Borders.Color = ThemeColor("teal-border")
            .HorizontalAlignment = xlCenter
            .VerticalAlignment = xlCenter
            .Font.Bold = True
        End With
        .Rows(12).RowHeight = 25

        SetRowValues .Range("B14"), Array("年", "月", "日", "時刻", "出金", "入金", "取扱店", "機番", "摘要", "その他")
        FormatOutputHeader .Range("B14:K14")
        ThemeApplyTableHeader .Range("B14:K14"), True

        For r = TX_FIRST_ROW To TX_LAST_ROW
            With .Range(.Cells(r, COL_TX_YEAR), .Cells(r, COL_TX_OTHER))
                .Borders.LineStyle = xlContinuous
                .Borders.Color = ThemeColor("border-soft")
                If (r - TX_FIRST_ROW) Mod 2 = 0 Then
                    .Interior.Color = vbWhite
                Else
                    .Interior.Color = ThemeColor("canvas")
                End If
                .Font.Color = ThemeColor("text")
            End With
        Next r
        .Rows(TX_FIRST_ROW & ":" & TX_LAST_ROW).RowHeight = 21
        .Range(.Cells(TX_FIRST_ROW, COL_TX_OTHER), .Cells(TX_LAST_ROW, COL_TX_OTHER)).WrapText = False
        .Range(.Cells(TX_FIRST_ROW, COL_TX_TIME), .Cells(TX_LAST_ROW, COL_TX_TIME)).NumberFormatLocal = "@"
        .Range(.Cells(TX_FIRST_ROW, COL_TX_SHOP), .Cells(TX_LAST_ROW, COL_TX_MACHINE)).NumberFormatLocal = "@"
        .Range(.Cells(TX_FIRST_ROW, COL_TX_WITHDRAW), .Cells(TX_LAST_ROW, COL_TX_DEPOSIT)).NumberFormatLocal = "#,##0"
        .Range(.Cells(TX_FIRST_ROW, COL_TX_YEAR), .Cells(TX_LAST_ROW, COL_TX_DAY)).NumberFormatLocal = "0"
        ThemeApplyCommandBar .Range("M2:T13")
        BuildOperationPanel ws
        BuildInputHelpCards ws
    End With
    PolishInputLayout ws
    Exit Sub
EH:
    Err.Raise Err.Number, "BuildInputSheet", Err.Description
End Sub
Public Sub BuildWorkSheets()
    Dim ws As Worksheet
    On Error GoTo EH
    Set ws = GetSheet(SH_WORK_TX)
    ws.Cells.Clear
    SetRowValues ws.Range("A1"), Array("銀行名", "支店名", "氏名", "科目", "口座番号", "日付", "時刻", "出金", "入金", "取扱店", "機番", "摘要欄", "その他", "続柄", "人物ID", "口座ID", "取引ID", "行種別", "転記回ID", "入力元行", "入力順", "取扱店確定値", "データ状態", "転記日時", "取引後残高", "取引後残高原文", "残高情報元")
    FormatOutputHeader ws.Range(ws.Cells(1, 1), ws.Cells(1, WORK_TX_LAST_COL))
    ws.Columns("A:AA").ColumnWidth = 14
    ws.Columns("F:F").NumberFormatLocal = "yyyy/m/d"
    ws.Columns("G:G").NumberFormatLocal = "hh:mm"
    ws.Columns("H:I").NumberFormatLocal = "#,##0"
    ws.Columns("E:E").NumberFormatLocal = "@"
    ws.Columns("J:K").NumberFormatLocal = "@"
    ws.Columns("M:M").NumberFormatLocal = "#,##0"
    ws.Columns("O:X").NumberFormatLocal = "@"
    ws.Columns("Y:Y").NumberFormatLocal = "#,##0"
    ws.Columns("Z:AA").NumberFormatLocal = "@"
    Set ws = GetSheet(SH_WORK_BAL)
    ws.Cells.Clear
    SetRowValues ws.Range("A1"), Array("氏名", "銀行名", "支店名", "科目", "口座番号", "口座開設日", "口座解約日", "残高基準日", "残高見出し", "残高", "その他", "続柄", "人物ID", "口座ID", "残高ID", "転記回ID", "データ状態", "転記日時")
    FormatOutputHeader ws.Range(ws.Cells(1, 1), ws.Cells(1, WORK_BAL_LAST_COL))
    ws.Columns("A:R").ColumnWidth = 14
    ws.Columns("F:H").NumberFormatLocal = "yyyy/m/d"
    ws.Columns("J:J").NumberFormatLocal = "#,##0"
    ws.Columns("M:R").NumberFormatLocal = "@"
    EnsureFinanceLinkSheets
    Set ws = GetSheet(SH_CHECK)
    ws.Cells.Clear
    SetRowValues ws.Range("A1"), Array("区分", "発生元", "内容", "記録時刻")
    FormatOutputHeader ws.Range("A1:D1")
    ws.Columns("A:D").ColumnWidth = 22
    Exit Sub
EH:
    Err.Raise Err.Number, "BuildWorkSheets", Err.Description
End Sub

Public Sub BuildOutputSheets()
    Dim ws As Worksheet
    On Error GoTo EH
    Set ws = GetSheet(SH_OUTPUT_TX)
    ws.Cells.Clear
    SetRowValues ws.Range("A1"), Array("銀行名", "支店名", "氏名", "科目", "口座番号", "日付", "時刻", "出金", "入金", "取扱店", "機番", "摘要欄", "その他")
    FormatOutputHeader ws.Range("A1:M1")
    ws.Columns("A:M").ColumnWidth = 14
    ws.Columns("F:F").NumberFormatLocal = "yyyy/m/d"
    ws.Columns("G:G").NumberFormatLocal = "hh:mm"
    ws.Columns("H:I").NumberFormatLocal = "#,##0"
    ws.Columns("E:E").NumberFormatLocal = "@"
    ws.Columns("J:K").NumberFormatLocal = "@"
    ws.Columns("M:M").NumberFormatLocal = "#,##0"
    AutoFitSheetSmart ws, "A:M", 8, 34
    Set ws = GetSheet(SH_OUTPUT_BAL)
    ws.Cells.Clear
    ws.Range("A1").Value = "残高推移表"
    ws.Range("A1").Font.Bold = True
    ws.Range("A1").Font.Size = 14
    ws.Columns("A:Z").ColumnWidth = 14
    AutoFitSheetSmart ws, "A:Z", 8, 34

    Set ws = GetSheet(SH_SHOP_TARGET)
    SetupShopConversionTargetSheet ws
    FormatShopConversionTargetSheet ws

    Set ws = GetSheet(SH_OUTPUT_TX_CONVERTED)
    ws.Cells.Clear
    SetRowValues ws.Range("A1"), Array("銀行名", "支店名", "氏名", "科目", "口座番号", "日付", "時刻", "出金", "入金", "取扱店", "機番", "摘要欄", "その他")
    FormatOutputHeader ws.Range("A1:M1")
    ws.Columns("A:M").ColumnWidth = 14
    ws.Columns("F:F").NumberFormatLocal = "yyyy/m/d"
    ws.Columns("G:G").NumberFormatLocal = "hh:mm"
    ws.Columns("H:I").NumberFormatLocal = "#,##0"
    ws.Columns("E:E").NumberFormatLocal = "@"
    ws.Columns("J:K").NumberFormatLocal = "@"
    ws.Columns("M:M").NumberFormatLocal = "#,##0"
    AutoFitSheetSmart ws, "A:M", 8, 34
    Exit Sub
EH:
    Err.Raise Err.Number, "BuildOutputSheets", Err.Description
End Sub

Public Sub BuildBalanceInputFields(Optional ByVal showDoneMessage As Boolean = True)
    Dim ws As Worksheet
    Dim labels As Collection
    Dim dates As Collection
    Dim i As Long, col As Long, memoCol As Long, maxLabels As Long
    Dim stepName As String
    Dim eNo As Long
    Dim eDesc As String

    On Error GoTo EH
    If Not SheetExists(SH_INPUT) Then Exit Sub
    Set ws = GetSheet(SH_INPUT)

    AppBegin "残高欄を再構築しています..."
    stepName = "入力シート保護解除"
    ws.Visible = xlSheetVisible
    ws.Unprotect Password:=TOOL_PASSWORD

    stepName = "残高ラベル作成"
    BuildBalanceCollections labels, dates
    If labels Is Nothing Or dates Is Nothing Then Err.Raise vbObjectError + 1801, "BuildBalanceInputFields", "残高欄の見出しを作成できませんでした。"
    If labels.Count = 0 Then Err.Raise vbObjectError + 1802, "BuildBalanceInputFields", "残高欄の表示範囲が空です。設定シートの残高年表示範囲を確認してください。"

    stepName = "既存残高欄の初期化"
    ResetBalanceInputArea ws

    stepName = "残高欄の配置"
    maxLabels = labels.Count
    If maxLabels > BAL_MAX_LABELS Then
        maxLabels = BAL_MAX_LABELS
        LogStep "警告", "残高欄生成", "列数上限", "表示範囲が広いため、残高入力列は先頭9列まで生成しました。"
    End If

    For i = 1 To maxLabels
        col = BAL_FIRST_COL + i - 1
        ws.Cells(BAL_LABEL_ROW, col).Value = BalanceInputLabelDisplay(CStr(labels(i)))
        ws.Cells(BAL_VALUE_ROW, col).Value = vbNullString
        ws.Cells(BAL_DATE_ROW, col).Value = dates(i)
        ws.Cells(BAL_DATE_ROW, col).NumberFormatLocal = "yyyy/m/d"
    Next i

    memoCol = BAL_FIRST_COL + maxLabels
    If memoCol > BAL_MAX_COL Then memoCol = BAL_MAX_COL

    stepName = "その他欄の配置"
    If memoCol < BAL_MAX_COL Then
        MergeAndFormat ws.Range(ws.Cells(BAL_LABEL_ROW, memoCol), ws.Cells(BAL_LABEL_ROW, BAL_MAX_COL)), "その他"
        MergeAndFormat ws.Range(ws.Cells(BAL_VALUE_ROW, memoCol), ws.Cells(BAL_VALUE_ROW, BAL_MAX_COL)), vbNullString
    Else
        ws.Cells(BAL_LABEL_ROW, memoCol).Value = "その他"
        ws.Cells(BAL_VALUE_ROW, memoCol).Value = vbNullString
    End If

    stepName = "残高欄の書式設定"
    FormatBalanceInputArea ws, memoCol

    stepName = "入力画面の表示調整"
    PolishInputLayout ws

    stepName = "入力規則と保護の再適用"
    ApplyInputSettings False
    ProtectInputSheet
    AppEnd

    If showDoneMessage Then MsgBox "残高欄を再生成しました。", vbInformation
    Exit Sub

EH:
    eNo = Err.Number
    eDesc = Err.Description
    On Error Resume Next
    ProtectInputSheet
    AppEnd
    MsgBox "残高欄生成中にエラーが発生しました。" & vbCrLf & _
           "処理: " & stepName & vbCrLf & _
           "Err " & eNo & ": " & eDesc, vbExclamation
End Sub

Private Sub ResetBalanceInputArea(ByVal ws As Worksheet)
    Dim rng As Range
    Dim cell As Range
    Dim ma As Range
    Dim errNo As Long

    If ws Is Nothing Then Exit Sub
    Set rng = ws.Range(ws.Cells(BAL_LABEL_ROW, BAL_FIRST_COL), ws.Cells(BAL_DATE_ROW, BAL_MAX_COL))

    On Error Resume Next
    rng.Validation.Delete
    On Error GoTo 0

    '結合セルが残ったままClearすると1004が出ることがあるため、先にMergeArea単位で解除する。
    On Error Resume Next
    For Each cell In rng.Cells
        If cell.MergeCells Then
            Set ma = cell.MergeArea
            If Not ma Is Nothing Then ma.UnMerge
            Set ma = Nothing
        End If
    Next cell
    Err.Clear
    On Error GoTo 0

    On Error Resume Next
    rng.ClearContents
    errNo = Err.Number
    Err.Clear
    On Error GoTo 0
    If errNo <> 0 Then
        For Each cell In rng.Cells
            On Error Resume Next
            cell.ClearContents
            On Error GoTo 0
        Next cell
    End If

    On Error Resume Next
    rng.ClearFormats
    errNo = Err.Number
    Err.Clear
    On Error GoTo 0
    If errNo <> 0 Then
        For Each cell In rng.Cells
            On Error Resume Next
            cell.ClearFormats
            cell.Borders.LineStyle = xlNone
            On Error GoTo 0
        Next cell
    End If
End Sub

Private Sub FormatBalanceInputArea(ByVal ws As Worksheet, ByVal memoCol As Long)
    Dim labelRange As Range
    Dim valueRange As Range
    Dim dateRange As Range
    If ws Is Nothing Then Exit Sub

    Set labelRange = ws.Range(ws.Cells(BAL_LABEL_ROW, BAL_FIRST_COL), ws.Cells(BAL_LABEL_ROW, BAL_MAX_COL))
    Set valueRange = ws.Range(ws.Cells(BAL_VALUE_ROW, BAL_FIRST_COL), ws.Cells(BAL_VALUE_ROW, BAL_MAX_COL))
    Set dateRange = ws.Range(ws.Cells(BAL_DATE_ROW, BAL_FIRST_COL), ws.Cells(BAL_DATE_ROW, BAL_MAX_COL))

    With labelRange
        .Font.Bold = True
        .Font.Size = 10
        .Font.Color = ThemeColor("blue")
        .Interior.Color = ThemeColor("info-soft")
        .HorizontalAlignment = xlCenter
        .VerticalAlignment = xlCenter
        .Borders.LineStyle = xlContinuous
        .Borders.Color = ThemeColor("info-border-strong")
        .WrapText = True
        .ShrinkToFit = False
    End With

    With valueRange
        .Interior.Color = ThemeColor("canvas")
        .Font.Color = ThemeColor("text")
        .Borders.LineStyle = xlContinuous
        .VerticalAlignment = xlCenter
    End With

    With dateRange
        .Interior.Color = ThemeColor("locked")
        .Borders.LineStyle = xlContinuous
        .Font.Size = 8
        .Font.Color = ThemeColor("muted")
        .HorizontalAlignment = xlCenter
        .NumberFormatLocal = "yyyy/m/d"
    End With

    If memoCol > BAL_FIRST_COL Then ws.Range(ws.Cells(BAL_VALUE_ROW, BAL_FIRST_COL), ws.Cells(BAL_VALUE_ROW, memoCol - 1)).NumberFormatLocal = "#,##0"

    On Error Resume Next
    If ws.Cells(BAL_VALUE_ROW, memoCol).MergeCells Then
        ws.Cells(BAL_VALUE_ROW, memoCol).MergeArea.NumberFormatLocal = "@"
        ws.Cells(BAL_VALUE_ROW, memoCol).MergeArea.HorizontalAlignment = xlLeft
    Else
        ws.Cells(BAL_VALUE_ROW, memoCol).NumberFormatLocal = "@"
        ws.Cells(BAL_VALUE_ROW, memoCol).HorizontalAlignment = xlLeft
    End If
    On Error GoTo 0

    ws.Rows(BAL_LABEL_ROW).RowHeight = 42
    ws.Rows(BAL_VALUE_ROW).RowHeight = 25
    ws.Rows(BAL_DATE_ROW).Hidden = False
    ws.Rows(BAL_DATE_ROW).RowHeight = 18
End Sub

Public Sub ApplyInputSettings(Optional ByVal showDoneMessage As Boolean = True)
    Dim ws As Worksheet
    Dim memoCol As Long
    On Error GoTo EH
    If Not SheetExists(SH_INPUT) Then Exit Sub
    Set ws = GetSheet(SH_INPUT)
    ws.Unprotect Password:=TOOL_PASSWORD
    RefreshAccountCandidateNames
    RefreshLinkedPersonCandidates
    ApplyValidationList ws.Range(CELL_BANK), NM_LST_BANK_CAND, xlIMEModeHiragana, True
    ApplyValidationList ws.Range(CELL_BRANCH), NM_LST_BRANCH_CAND, xlIMEModeHiragana, True
    ApplyValidationList ws.Range(CELL_PERSON), NM_LST_PERSON_CAND, xlIMEModeHiragana, True
    ApplyValidationInputOnly ws.Range(CELL_RELATIONSHIP), xlIMEModeHiragana
    ApplyValidationList ws.Range(CELL_ACCOUNT_TYPE), NM_LST_ACCOUNT_TYPE, xlIMEModeOff, False
    ApplyValidationInputOnly ws.Range(CELL_ACCOUNT_NO), xlIMEModeOff
    ApplyValidationInputOnly ws.Range(CELL_OPEN_DATE), xlIMEModeOff
    ApplyValidationInputOnly ws.Range(CELL_CLOSE_DATE), xlIMEModeOff
    memoCol = BalanceMemoCol(ws)
    If memoCol > BAL_FIRST_COL Then ApplyValidationInputOnly ws.Range(ws.Cells(BAL_VALUE_ROW, BAL_FIRST_COL), ws.Cells(BAL_VALUE_ROW, memoCol - 1)), xlIMEModeOff
    ApplyValidationInputOnly ws.Cells(BAL_VALUE_ROW, memoCol), xlIMEModeHiragana
    ApplyValidationInputOnly ws.Range(ws.Cells(TX_FIRST_ROW, COL_TX_YEAR), ws.Cells(TX_LAST_ROW, COL_TX_DEPOSIT)), xlIMEModeOff
    ApplyValidationInputOnly ws.Range(ws.Cells(TX_FIRST_ROW, COL_TX_SHOP), ws.Cells(TX_LAST_ROW, COL_TX_MACHINE)), xlIMEModeOff
    ApplyValidationList ws.Range(ws.Cells(TX_FIRST_ROW, COL_TX_TEKIYO), ws.Cells(TX_LAST_ROW, COL_TX_TEKIYO)), NM_LST_TEKIYO, xlIMEModeHiragana, True
    ApplyValidationInputOnly ws.Range(ws.Cells(TX_FIRST_ROW, COL_TX_OTHER), ws.Cells(TX_LAST_ROW, COL_TX_OTHER)), xlIMEModeHiragana
    ApplyValidationList GetCfgCell(ROW_CFG_INPUT_MODE), NM_LST_INPUT_MODE, xlIMEModeOff, False
    ApplyValidationList GetCfgCell(ROW_CFG_YEAR_MODE), NM_LST_YEAR_MODE, xlIMEModeOff, False
    ApplyValidationList GetCfgCell(ROW_CFG_RELATIONSHIP), NM_LST_DISPLAY_OPTION, xlIMEModeOff, False
    ApplyValidationList GetCfgCell(ROW_CFG_SHOW_INHERITANCE_ROW), NM_LST_DISPLAY_OPTION, xlIMEModeOff, False
    ApplyValidationList GetCfgCell(ROW_CFG_SHOW_OPEN_DATE_ROW), NM_LST_DISPLAY_OPTION, xlIMEModeOff, False
    ApplyValidationList GetCfgCell(ROW_CFG_SHOW_CLOSE_DATE_ROW), NM_LST_DISPLAY_OPTION, xlIMEModeOff, False
    ApplyValidationList GetCfgCell(ROW_CFG_SHOW_BALANCE_ROWS), NM_LST_DISPLAY_OPTION, xlIMEModeOff, False
    ApplyValidationList GetCfgCell(ROW_CFG_LINK_MODE), NM_LST_DISPLAY_OPTION, xlIMEModeOff, False
    ApplyValidationList GetCfgCell(ROW_CFG_AUTO_SAVE_COMMON), NM_LST_DISPLAY_OPTION, xlIMEModeOff, False
    ApplyValidationList GetCfgCell(ROW_CFG_POST_KEEP), NM_LST_POST_KEEP, xlIMEModeOff, False
    ApplyValidationList GetCfgCell(ROW_CFG_POST_TX), NM_LST_POST_CLEAR, xlIMEModeOff, False
    ApplyValidationList GetCfgCell(ROW_CFG_POST_BAL), NM_LST_POST_CLEAR, xlIMEModeOff, False
    ws.Range(CELL_ACCOUNT_NO).NumberFormatLocal = "@"
    '開設日・解約日は入力補助で実日付に正規化するため、表示は日付形式に固定する。
    '文字列書式に戻すと、書式復旧後に日付シリアル値が見える恐れがある。
    ws.Range(CELL_OPEN_DATE).NumberFormatLocal = "yyyy/m/d"
    ws.Range(CELL_CLOSE_DATE).NumberFormatLocal = "yyyy/m/d"
    ws.Range(ws.Cells(TX_FIRST_ROW, COL_TX_TIME), ws.Cells(TX_LAST_ROW, COL_TX_TIME)).NumberFormatLocal = "@"
    ws.Range(ws.Cells(TX_FIRST_ROW, COL_TX_SHOP), ws.Cells(TX_LAST_ROW, COL_TX_MACHINE)).NumberFormatLocal = "@"
    ws.Range(ws.Cells(TX_FIRST_ROW, COL_TX_WITHDRAW), ws.Cells(TX_LAST_ROW, COL_TX_DEPOSIT)).NumberFormatLocal = "#,##0"
    ws.Cells.Locked = True
    UnlockRange ws.Range(CELL_BANK)
    UnlockRange ws.Range(CELL_BRANCH)
    UnlockRange ws.Range(CELL_PERSON)
    If UseRelationshipDisplay() Then
        UnlockRange ws.Range(CELL_RELATIONSHIP)
        ws.Range(CELL_RELATIONSHIP).Interior.Color = ThemeColor("canvas")
        ws.Range(CELL_RELATIONSHIP).Font.Color = ThemeColor("text")
    Else
        ClearEffectiveContents ws.Range(CELL_RELATIONSHIP)
        ws.Range(CELL_RELATIONSHIP).Locked = True
        ws.Range(CELL_RELATIONSHIP).Interior.Color = ThemeColor("border-soft")
        ws.Range(CELL_RELATIONSHIP).Font.Color = ThemeColor("line-muted")
    End If
    UnlockRange ws.Range(CELL_ACCOUNT_TYPE)
    UnlockRange ws.Range(CELL_ACCOUNT_NO)
    UnlockRange ws.Range(CELL_OPEN_DATE)
    UnlockRange ws.Range(CELL_CLOSE_DATE)
    If memoCol > BAL_FIRST_COL Then UnlockRange ws.Range(ws.Cells(BAL_VALUE_ROW, BAL_FIRST_COL), ws.Cells(BAL_VALUE_ROW, memoCol - 1))
    UnlockRange ws.Cells(BAL_VALUE_ROW, memoCol)
    ApplyBalanceAvailability ws
    UnlockTransactionInputCells ws
    ProtectInputSheet
    EnableInputKeys
    If showDoneMessage Then MsgBox "入力欄設定を更新しました。", vbInformation
    Exit Sub
EH:
    ProtectInputSheet
    EnableInputKeys
    MsgBox "入力欄設定中にエラーが発生しました。" & vbCrLf & "Err " & Err.Number & ": " & Err.Description, vbExclamation
End Sub

Private Sub UnlockTransactionInputCells(ByVal ws As Worksheet)
    Dim modeText As String
    If ws Is Nothing Then Exit Sub
    modeText = GetInputMode()

    '年・月は2行目以降も訂正できるようにロック解除する。
    'ただし通常のTabルートには入れず、普段の連続入力は「日」から始まる。
    UnlockRange ws.Range(ws.Cells(TX_FIRST_ROW, COL_TX_YEAR), ws.Cells(TX_LAST_ROW, COL_TX_MONTH))

    '通常入力で通る取引明細欄。
    UnlockRange ws.Range(ws.Cells(TX_FIRST_ROW, COL_TX_DAY), ws.Cells(TX_LAST_ROW, COL_TX_DEPOSIT))
    UnlockRange ws.Range(ws.Cells(TX_FIRST_ROW, COL_TX_SHOP), ws.Cells(TX_LAST_ROW, COL_TX_TEKIYO))

    'その他列は、通常Tabルートでは飛ばすが、クリック・矢印キーでは入力できるよう常にロック解除する。
    '気になったメモを取引入力中に直接書けるようにするため。
    UnlockRange ws.Range(ws.Cells(TX_FIRST_ROW, COL_TX_OTHER), ws.Cells(TX_LAST_ROW, COL_TX_OTHER))
End Sub

Public Sub ProtectInputSheet()
    On Error Resume Next
    If Not SheetExists(SH_INPUT) Then Exit Sub
    With ThisWorkbook.Worksheets(SH_INPUT)
        .Unprotect Password:=TOOL_PASSWORD
        '入力セルは編集可能、図形ボタンはクリック実行のみ可能にし、誤ドラッグや右クリック編集を防ぐ。
        LockToolShapes ThisWorkbook.Worksheets(SH_INPUT)
        .Protect Password:=TOOL_PASSWORD, DrawingObjects:=True, Contents:=True, Scenarios:=False, _
                 UserInterfaceOnly:=True, AllowFiltering:=True, AllowFormattingCells:=False, _
                 AllowFormattingColumns:=False, AllowFormattingRows:=False
        .EnableSelection = xlUnlockedCells
        ApplyFinanceInputViewport ThisWorkbook.Worksheets(SH_INPUT)
    End With
    On Error GoTo 0
End Sub

Public Sub SelfCheckTool()
    If Not SheetExists(SH_INPUT) Then Err.Raise vbObjectError + 1501, "SelfCheckTool", "入力シートがありません。"
    If Not SheetExists(SH_CONFIG) Then Err.Raise vbObjectError + 1502, "SelfCheckTool", "設定シートがありません。"
    If Not SheetExists(SH_WORK_TX) Then Err.Raise vbObjectError + 1503, "SelfCheckTool", "W_取引シートがありません。"
    If Not SheetExists(SH_WORK_BAL) Then Err.Raise vbObjectError + 1504, "SelfCheckTool", "W_残高シートがありません。"
    If Not SheetExists(SH_YEAR_MODE) Then Err.Raise vbObjectError + 1505, "SelfCheckTool", "年入力方式候補シートがありません。"
    If Not SheetExists(SH_DISPLAY_OPTION) Then Err.Raise vbObjectError + 1515, "SelfCheckTool", "表示切替候補シートがありません。"
    If Not SheetExists(SH_POST_KEEP) Then Err.Raise vbObjectError + 1506, "SelfCheckTool", "転記後保持候補シートがありません。"
    If Not SheetExists(SH_POST_CLEAR) Then Err.Raise vbObjectError + 1507, "SelfCheckTool", "転記後処理候補シートがありません。"
    If Not SheetExists(SH_BANK_CAND) Then Err.Raise vbObjectError + 1508, "SelfCheckTool", "銀行名候補シートがありません。"
    If Not SheetExists(SH_BRANCH_CAND) Then Err.Raise vbObjectError + 1509, "SelfCheckTool", "支店名候補シートがありません。"
    If Not SheetExists(SH_PERSON_CAND) Then Err.Raise vbObjectError + 1510, "SelfCheckTool", "人物候補シートがありません。"
    If Not SheetExists(SH_SHOP_TARGET) Then Err.Raise vbObjectError + 1511, "SelfCheckTool", "取扱店変換対象シートがありません。"
    If Not SheetExists(SH_OUTPUT_TX_CONVERTED) Then Err.Raise vbObjectError + 1512, "SelfCheckTool", "資金操作表_取扱店変換済シートがありません。"
    If Not SheetExists(SH_WORK_PERSON_REF) Then Err.Raise vbObjectError + 1516, "SelfCheckTool", "W_人物参照シートがありません。"
    If Not SheetExists(SH_WORK_ACCOUNT) Then Err.Raise vbObjectError + 1517, "SelfCheckTool", "W_口座シートがありません。"
    If Not SheetExists(SH_WORK_ID) Then Err.Raise vbObjectError + 1518, "SelfCheckTool", "W_ID管理シートがありません。"
    If Not SheetExists(SH_LINK_LOG) Then Err.Raise vbObjectError + 1519, "SelfCheckTool", "W_連携ログシートがありません。"
End Sub

Public Sub GoInputSheet()
    If Not SheetExists(SH_INPUT) Then Exit Sub
    ThisWorkbook.Worksheets(SH_INPUT).Visible = xlSheetVisible
    SafeSelectCell GetSheet(SH_INPUT), CELL_BANK
    HideDailySheets False
End Sub

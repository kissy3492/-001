Attribute VB_Name = "modFinalExport"
Option Explicit

'====================================================================================
' 最終成果物出力
'------------------------------------------------------------------------------------
' 作業用ブックには入力シート、作業シート、候補・設定・マクロ等が含まれる。
' 提出・共有用には不要なため、最終的な「資金操作表」と「残高推移表」だけを
' それぞれマクロなしの通常Excelブック（.xlsx）として外部出力する。
'
' 出力ファイル:
'   05_資金操作表.xlsx
'   06_残高推移表.xlsx
'
' 資金操作表は、取扱店反映済みシートが存在しデータがある場合はそれを優先する。
' まだ取扱店反映をしていない場合は、通常の「資金操作表」を出力する。
'====================================================================================

Private Const EXPORT_FILE_CASH As String = "05_資金操作表.xlsx"
Private Const EXPORT_FILE_BALANCE As String = "06_残高推移表.xlsx"

Public Sub ExportFinalWorkbooks()
    Dim folderPath As String
    Dim cashSheetName As String
    Dim balanceSheetName As String
    Dim cashPath As String
    Dim balancePath As String
    Dim exportedCount As Long

    If Not RequireToolReady() Then Exit Sub
    If Len(ThisWorkbook.Path) = 0 Then
        MsgBox "先にこのツールを案件フォルダへ保存してください。" & vbCrLf & _
               "未保存のままでは、00_共通データ.xlsx や出力フォルダの場所が不安定になります。", vbExclamation
        Exit Sub
    End If

    On Error GoTo EH
    AppBegin "最終成果物を出力中..."

    EnsureBaseOutputSheetsForExport
    If CellText(GetCfgCell(ROW_CFG_AUTO_SAVE_COMMON).Value) <> DISPLAY_OFF Then SaveFinanceCommonData False

    cashSheetName = GetFinalCashOperationSheetName()
    balanceSheetName = SH_OUTPUT_BAL

    If Len(cashSheetName) = 0 Then
        AppEnd
        MsgBox "出力できる資金操作表がありません。先に『一括作成』を実行してください。", vbExclamation
        Exit Sub
    End If
    If Not HasWorksheetData(balanceSheetName) Then
        AppEnd
        MsgBox "出力できる残高推移表がありません。先に『一括作成』を実行してください。", vbExclamation
        Exit Sub
    End If

    folderPath = PickFinalExportFolder()
    If Len(folderPath) = 0 Then
        AppEnd
        Exit Sub
    End If

    cashPath = CombinePath(folderPath, EXPORT_FILE_CASH)
    balancePath = CombinePath(folderPath, EXPORT_FILE_BALANCE)

    If Not ConfirmOverwriteIfNeeded(cashPath, balancePath) Then
        AppEnd
        Exit Sub
    End If

    ExportOneSheetAsXlsx GetSheet(cashSheetName), "資金操作表", cashPath
    exportedCount = exportedCount + 1

    ExportOneSheetAsXlsx GetSheet(balanceSheetName), "残高推移表", balancePath
    exportedCount = exportedCount + 1

    AppEnd

    MsgBox "マクロなしのExcelファイルを出力しました。" & vbCrLf & vbCrLf & _
           EXPORT_FILE_CASH & vbCrLf & _
           EXPORT_FILE_BALANCE & vbCrLf & vbCrLf & _
           "保存先: " & folderPath, vbInformation, "最終成果物出力"
    Exit Sub

EH:
    AppEnd
    MsgBox "最終成果物の出力中にエラーが発生しました。" & vbCrLf & _
           "Err " & Err.Number & ": " & Err.Description, vbExclamation, "出力エラー"
End Sub

Private Sub EnsureBaseOutputSheetsForExport()
    If Not SheetExists(SH_OUTPUT_TX) Or LastRow(GetSheet(SH_OUTPUT_TX), 1) < 2 Then
        BuildCashOperationSheetCore False
    End If
    If Not SheetExists(SH_OUTPUT_BAL) Or LastRow(GetSheet(SH_OUTPUT_BAL), 1) < 2 Then
        BuildBalanceTransitionSheetCore False
    End If
End Sub

Private Function GetFinalCashOperationSheetName() As String
    If HasWorksheetData(SH_OUTPUT_TX_CONVERTED) Then
        GetFinalCashOperationSheetName = SH_OUTPUT_TX_CONVERTED
    ElseIf HasWorksheetData(SH_OUTPUT_TX) Then
        GetFinalCashOperationSheetName = SH_OUTPUT_TX
    Else
        GetFinalCashOperationSheetName = ""
    End If
End Function

Private Function HasWorksheetData(ByVal sheetName As String) As Boolean
    If Not SheetExists(sheetName) Then Exit Function
    HasWorksheetData = LastRow(GetSheet(sheetName), 1) >= 2
End Function

Private Function PickFinalExportFolder() As String
    Dim basePath As String, outPath As String
    basePath = ThisWorkbook.Path
    If Len(basePath) = 0 Then Exit Function
    outPath = CombinePath(basePath, "出力")
    If Dir$(outPath, vbDirectory) = "" Then MkDir outPath
    PickFinalExportFolder = outPath
End Function

Private Function ConfirmOverwriteIfNeeded(ByVal path1 As String, ByVal path2 As String) As Boolean
    Dim msg As String
    If Len(Dir$(path1)) > 0 Then msg = msg & "・" & path1 & vbCrLf
    If Len(Dir$(path2)) > 0 Then msg = msg & "・" & path2 & vbCrLf

    If Len(msg) = 0 Then
        ConfirmOverwriteIfNeeded = True
    Else
        ConfirmOverwriteIfNeeded = (MsgBox("以下のファイルは既に存在します。上書きしますか？" & vbCrLf & vbCrLf & msg, _
                                           vbYesNo + vbQuestion, "上書き確認") = vbYes)
    End If
End Function

Private Sub ExportOneSheetAsXlsx(ByVal src As Worksheet, ByVal exportSheetName As String, ByVal savePath As String)
    Dim wbNew As Workbook
    Dim wsNew As Worksheet
    Dim prevAlerts As Boolean

    If src Is Nothing Then Err.Raise vbObjectError + 5201, "ExportOneSheetAsXlsx", "出力元シートを取得できません。"

    src.Visible = xlSheetVisible
    src.Copy
    Set wbNew = ActiveWorkbook
    Set wsNew = wbNew.Worksheets(1)

    On Error Resume Next
    wsNew.Name = exportSheetName
    DeleteToolShapes wsNew, False
    wsNew.Range("A1").Select
    On Error GoTo EH

    prevAlerts = Application.DisplayAlerts
    Application.DisplayAlerts = False
    PrepareOutputPathWithBackup savePath
    wbNew.SaveAs Filename:=savePath, FileFormat:=xlOpenXMLWorkbook
    wbNew.Close SaveChanges:=False
    Application.DisplayAlerts = prevAlerts
    Exit Sub

EH:
    On Error Resume Next
    Application.DisplayAlerts = prevAlerts
    If Not wbNew Is Nothing Then wbNew.Close SaveChanges:=False
    On Error GoTo 0
    Err.Raise Err.Number, "ExportOneSheetAsXlsx(" & exportSheetName & ")", Err.Description
End Sub

Private Function CombinePath(ByVal folderPath As String, ByVal fileName As String) As String
    If Right$(folderPath, 1) = "\" Or Right$(folderPath, 1) = "/" Then
        CombinePath = folderPath & fileName
    Else
        CombinePath = folderPath & "\" & fileName
    End If
End Function

Private Sub PrepareOutputPathWithBackup(ByVal filePath As String)
    Dim backupPath As String
    If Len(filePath) = 0 Then Exit Sub
    If Len(Dir$(filePath)) = 0 Then Exit Sub
    backupPath = filePath & ".bak_" & Format$(Now, "yyyymmdd_hhnnss")
    FileCopy filePath, backupPath
    Kill filePath
    AppendLinkLog "既存出力バックアップ", "作成", backupPath
End Sub

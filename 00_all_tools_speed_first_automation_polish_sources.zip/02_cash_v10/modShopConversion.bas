Attribute VB_Name = "modShopConversion"
Option Explicit

Public Sub BuildShopConversionTargetSheet()
    '資金操作表に登場した「コード形式の取扱店」だけを一覧化する。
    '変換作業そのものはこのシート上で行い、反映ボタンも同じシートに置く。
    If Not RequireToolReady() Then Exit Sub
    On Error GoTo EH
    AppBegin "取扱店変換対象を整理中..."
    If Not SheetExists(SH_OUTPUT_TX) Then
        BuildCashOperationSheetCore False
    ElseIf LastRow(GetSheet(SH_OUTPUT_TX), 1) < 2 Then
        BuildCashOperationSheetCore False
    End If
    BuildShopConversionTargetSheetCore True
    AppEnd
    MsgBox "取扱店変換対象を作成しました。" & vbCrLf & _
           "変換後取扱店を入力したら、このシート右上の『取扱店反映』を押してください。", vbInformation
    Exit Sub
EH:
    AppEnd
    MsgBox "取扱店変換対象の作成中にエラーが発生しました。" & vbCrLf & "Err " & Err.Number & ": " & Err.Description, vbExclamation
End Sub

Public Sub BuildShopConversionTargetSheetCore(Optional ByVal activateAfter As Boolean = False)
    Dim wsOut As Worksheet, wsTarget As Worksheet
    Dim lastR As Long, r As Long, targetR As Long, nextNo As Long, oldLastR As Long
    Dim bankName As String, shopText As String, codeText As String
    Dim oldData As Variant, preservedResult As String, preservedStatus As String

    If Not SheetExists(SH_OUTPUT_TX) Then Exit Sub
    Set wsOut = GetSheet(SH_OUTPUT_TX)
    Set wsTarget = GetOrCreateSheet(SH_SHOP_TARGET, False)

    '再生成しても、既に入力した「変換後取扱店」「確認状況」は銀行名+コード単位で引き継ぐ。
    oldLastR = LastRow(wsTarget, SHOP_TGT_COL_NO)
    If oldLastR >= 2 Then oldData = wsTarget.Range("A1:K" & oldLastR).Value

    SetupShopConversionTargetSheet wsTarget
    lastR = LastRow(wsOut, OUT_COL_BANK)
    nextNo = 1

    For r = 2 To lastR
        If IsCashOperationTransactionRow(wsOut, r) Then
            shopText = CellText(wsOut.Cells(r, OUT_COL_SHOP).Value)
            If IsCodeLikeShop(shopText) Then
                bankName = CellText(wsOut.Cells(r, OUT_COL_BANK).Value)
                codeText = NormalizeShopCodeText(shopText)
                targetR = FindShopTargetRow(wsTarget, bankName, codeText)

                If targetR = 0 Then
                    targetR = LastRow(wsTarget, SHOP_TGT_COL_NO) + 1
                    If targetR < 2 Then targetR = 2

                    wsTarget.Cells(targetR, SHOP_TGT_COL_NO).Value = nextNo
                    wsTarget.Cells(targetR, SHOP_TGT_COL_BANK).Value = bankName
                    wsTarget.Cells(targetR, SHOP_TGT_COL_CODE).Value = codeText
                    wsTarget.Cells(targetR, SHOP_TGT_COL_COUNT).Value = 1
                    wsTarget.Cells(targetR, SHOP_TGT_COL_ROWS).Value = CStr(r)

                    PreserveShopTargetValues oldData, bankName, codeText, preservedResult, preservedStatus
                    wsTarget.Cells(targetR, SHOP_TGT_COL_RESULT).Value = preservedResult
                    If Len(preservedStatus) > 0 Then
                        wsTarget.Cells(targetR, SHOP_TGT_COL_STATUS).Value = preservedStatus
                    ElseIf Len(preservedResult) > 0 Then
                        wsTarget.Cells(targetR, SHOP_TGT_COL_STATUS).Value = "入力済"
                    Else
                        wsTarget.Cells(targetR, SHOP_TGT_COL_STATUS).Value = "未入力"
                    End If
                    wsTarget.Cells(targetR, SHOP_TGT_COL_CREATED).Value = Now
                    nextNo = nextNo + 1
                Else
                    wsTarget.Cells(targetR, SHOP_TGT_COL_COUNT).Value = CLng(Val(wsTarget.Cells(targetR, SHOP_TGT_COL_COUNT).Value)) + 1
                    wsTarget.Cells(targetR, SHOP_TGT_COL_ROWS).Value = AppendRowNumber(CellText(wsTarget.Cells(targetR, SHOP_TGT_COL_ROWS).Value), r)
                End If
            End If
        End If
    Next r

    FormatShopConversionTargetSheet wsTarget
    wsTarget.Visible = xlSheetVisible
    If activateAfter Then
        wsTarget.Activate
        wsTarget.Range("A1").Select
    End If
End Sub

Public Sub ApplyShopConversionToCashOperation()
    If Not RequireToolReady() Then Exit Sub
    On Error GoTo EH
    AppBegin "取扱店を反映中..."
    If Not SheetExists(SH_OUTPUT_TX) Then
        BuildCashOperationSheetCore False
    ElseIf LastRow(GetSheet(SH_OUTPUT_TX), 1) < 2 Then
        BuildCashOperationSheetCore False
    End If
    If Not SheetExists(SH_SHOP_TARGET) Then
        BuildShopConversionTargetSheetCore False
    ElseIf LastRow(GetSheet(SH_SHOP_TARGET), SHOP_TGT_COL_NO) < 2 Then
        BuildShopConversionTargetSheetCore False
    End If
    ApplyShopConversionCore True
    AppEnd
    Exit Sub
EH:
    AppEnd
    MsgBox "取扱店反映中にエラーが発生しました。" & vbCrLf & "Err " & Err.Number & ": " & Err.Description, vbExclamation
End Sub

Private Sub ApplyShopConversionCore(ByVal activateAfter As Boolean)
    Dim wsSrc As Worksheet, wsTarget As Worksheet, wsDest As Worksheet
    Dim lastR As Long, r As Long
    Dim bankName As String, shopText As String, codeText As String, resultName As String
    Dim convertedCount As Long, remainedCount As Long
    Set wsSrc = GetSheet(SH_OUTPUT_TX)
    Set wsTarget = GetSheet(SH_SHOP_TARGET)
    wsTarget.Unprotect Password:=TOOL_PASSWORD
    Set wsDest = GetOrCreateSheet(SH_OUTPUT_TX_CONVERTED, True)
    lastR = LastUsedRowInSheet(wsSrc)
    If lastR < 1 Then lastR = 1
    wsDest.Range("A1").Resize(lastR, 19).Value = wsSrc.Range("A1:S" & CStr(lastR)).Value
    wsDest.Visible = xlSheetVisible
    lastR = LastUsedRowInSheet(wsDest)
    For r = 2 To lastR
        If IsCashOperationTransactionRow(wsDest, r) Then
            shopText = CellText(wsDest.Cells(r, OUT_COL_SHOP).Value)
            If IsCodeLikeShop(shopText) Then
                bankName = CellText(wsDest.Cells(r, OUT_COL_BANK).Value)
                codeText = NormalizeShopCodeText(shopText)
                resultName = LookupShopConversionName(wsTarget, bankName, codeText)
                If Len(resultName) > 0 Then
                    wsDest.Cells(r, OUT_COL_SHOP).Value = resultName
                    wsDest.Cells(r, OUT_COL_SHOP_FINAL).Value = resultName
                    wsDest.Cells(r, OUT_COL_SHOP).Interior.Color = ThemeColor("teal-soft")
                    convertedCount = convertedCount + 1
                Else
                    wsDest.Cells(r, OUT_COL_SHOP).Interior.Color = ThemeColor("warning-strong")
                    remainedCount = remainedCount + 1
                End If
            End If
        End If
    Next r
    NormalizeOutputShopFinal wsDest
    SortCashOperation wsDest
    FormatCashOperationOutputLayout wsDest
    SafeFreezeOutputHeader wsDest
    wsDest.Columns("E:E").NumberFormatLocal = "@"
    wsDest.Columns("J:K").NumberFormatLocal = "@"
    wsDest.Columns("N:S").Hidden = True
    ProtectReadOnlyOutputSheet wsDest
    UpdateShopTargetStatuses wsTarget
    FormatShopConversionTargetSheet wsTarget
    If activateAfter Then
        wsDest.Activate
        wsDest.Range("A1").Select
    End If
    MsgBox "取扱店反映済み資金操作表を作成しました。" & vbCrLf & _
           "反映済み: " & convertedCount & "件" & vbCrLf & _
           "未入力・未反映: " & remainedCount & "件", vbInformation
End Sub

Public Function FillBlankShopWithBranch(ByVal ws As Worksheet) As Long
    Dim lastR As Long, r As Long, branchName As String
    If ws Is Nothing Then Exit Function
    lastR = LastRow(ws, OUT_COL_BANK)
    For r = 2 To lastR
        If IsCashOperationTransactionRow(ws, r) Then
            If Len(CellText(ws.Cells(r, OUT_COL_SHOP).Value)) = 0 Then
                branchName = CellText(ws.Cells(r, OUT_COL_BRANCH).Value)
                If Len(branchName) > 0 Then
                    ws.Cells(r, OUT_COL_SHOP).Value = branchName
                    FillBlankShopWithBranch = FillBlankShopWithBranch + 1
                End If
            End If
        End If
    Next r
End Function

Public Sub SetupShopConversionTargetSheet(ByVal ws As Worksheet)
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    ws.Unprotect Password:=TOOL_PASSWORD
    DeleteToolShapes ws, False
    ws.Cells.UnMerge
    ws.Cells.Clear
    ws.Cells.ClearFormats
    ws.Cells.Validation.Delete
    ws.AutoFilterMode = False
    On Error GoTo 0

    ws.Cells.Font.Name = "Yu Gothic UI"
    ws.Cells.Font.Size = 10
    ws.Cells.Interior.Color = ThemeColor("canvas")
    ws.Cells.Font.Color = ThemeColor("text")

    SetRowValues ws.Range("A1"), Array("No", "銀行名", "取扱店コード", "該当件数", "該当行番号", "変換後取扱店", "確認状況", "作成日時")
    FormatOutputHeader ws.Range("A1:H1")
    ws.Range("A1:H1").Interior.Color = ThemeColor("blue")
    ws.Range("A1:H1").Font.Color = vbWhite
    ws.Range("A1:H1").Borders.Color = ThemeColor("info-border-strong")

    ws.Columns("A:A").ColumnWidth = 6
    ws.Columns("B:B").ColumnWidth = 24
    ws.Columns("C:C").ColumnWidth = 18
    ws.Columns("D:D").ColumnWidth = 10
    ws.Columns("E:E").ColumnWidth = 24
    ws.Columns("F:F").ColumnWidth = 34
    ws.Columns("G:G").ColumnWidth = 14
    ws.Columns("H:H").ColumnWidth = 18
    ws.Columns("J:N").ColumnWidth = 14

    ws.Columns("C:C").NumberFormatLocal = "@"
    ws.Columns("F:G").Interior.Color = vbWhite
    ws.Columns("H:H").NumberFormatLocal = "yyyy/m/d h:mm"
    ws.Rows(1).RowHeight = 28
    ws.Rows(1).Font.Bold = True
    ws.Range("F:F").Font.Bold = True

    On Error Resume Next
    ws.Range("G2:G1000").Validation.Delete
    ws.Range("G2:G1000").Validation.Add Type:=xlValidateList, AlertStyle:=xlValidAlertStop, Operator:=xlBetween, Formula1:="未入力,入力済,確認不要,保留"
    ws.Range("G2:G1000").Validation.InCellDropdown = True
    ws.Range("G2:G1000").Validation.ShowError = False
    On Error GoTo 0
End Sub

Public Sub FormatShopConversionTargetSheet(ByVal ws As Worksheet)
    Dim lastR As Long, r As Long
    If ws Is Nothing Then Exit Sub
    lastR = LastRow(ws, SHOP_TGT_COL_NO)
    On Error Resume Next
    ws.AutoFilterMode = False
    On Error GoTo 0

    If lastR < 2 Then
        ws.Range("A2:H2").UnMerge
        ws.Range("A2").Value = "変換対象の取扱店コードはありません。"
        ws.Range("A2:H2").Merge
        ws.Range("A2:H2").Interior.Color = ThemeColor("success-soft")
        ws.Range("A2:H2").Font.Color = ThemeColor("success-text")
        ws.Range("A2:H2").Font.Bold = True
        ws.Range("A2:H2").HorizontalAlignment = xlCenter
        ws.Rows(2).RowHeight = 28
    Else
        For r = 2 To lastR
            With ws.Range("A" & r & ":H" & r)
                .Borders.LineStyle = xlContinuous
                .Borders.Color = ThemeColor("border-soft")
                If (r Mod 2) = 0 Then
                    .Interior.Color = vbWhite
                Else
                    .Interior.Color = ThemeColor("canvas")
                End If
                .Font.Color = ThemeColor("text")
            End With
            ws.Cells(r, SHOP_TGT_COL_CODE).Interior.Color = ThemeColor("section")
            ws.Cells(r, SHOP_TGT_COL_RESULT).Interior.Color = ThemeColor("success-bg")
            ws.Cells(r, SHOP_TGT_COL_STATUS).Interior.Color = ThemeColor("warning-soft")
        Next r
        ws.Range("A1:H" & lastR).AutoFilter
    End If

    ws.Range("A1:H" & Application.Max(2, lastR)).VerticalAlignment = xlCenter
    ws.Range("A:E").HorizontalAlignment = xlCenter
    ws.Range("F:F").HorizontalAlignment = xlLeft
    ws.Range("G:G").HorizontalAlignment = xlCenter
    ws.Range("H:H").HorizontalAlignment = xlCenter
    ws.Range("E:F").WrapText = True
    ws.Range("A1:H1").HorizontalAlignment = xlCenter
    ws.Range("A1:H1").VerticalAlignment = xlCenter
    ws.Rows(1).RowHeight = 32

    AutoFitSheetSmart ws, "A:H", 6, 45
    If ws.Columns("B:B").ColumnWidth < 22 Then ws.Columns("B:B").ColumnWidth = 22
    If ws.Columns("C:C").ColumnWidth < 16 Then ws.Columns("C:C").ColumnWidth = 16
    If ws.Columns("E:E").ColumnWidth < 22 Then ws.Columns("E:E").ColumnWidth = 22
    If ws.Columns("F:F").ColumnWidth < 32 Then ws.Columns("F:F").ColumnWidth = 32
    If ws.Columns("G:G").ColumnWidth < 13 Then ws.Columns("G:G").ColumnWidth = 13
    If ws.Columns("H:H").ColumnWidth < 18 Then ws.Columns("H:H").ColumnWidth = 18

    BuildShopConversionTargetPanel ws
    FixUnreadableWhiteTextOnSheet ws
    LockToolShapes ws
    SafeFreezeOutputHeader ws
    ProtectShopConversionTargetSheet
End Sub

Public Sub BuildShopConversionTargetPanel(ByVal ws As Worksheet)
    '取扱店変換対象シートの操作カード。
    '一覧A:Hと干渉しないよう、右側J:Nの2行目以降に固定配置する。
    Dim x As Double, y As Double, w As Double, h As Double
    Dim margin As Double, gap As Double, mainH As Double, btnH As Double, smallW As Double
    If ws Is Nothing Then Exit Sub

    On Error Resume Next
    DeleteToolShapes ws, False
    ws.Columns("J:N").ColumnWidth = 14.5
    On Error GoTo 0

    '行高は取扱店一覧の入力行にも影響するため、ここでは変更しない。
    'パネルは図形の高さを固定して、一覧の見やすさを保つ。
    x = ws.Range("J2").Left
    y = ws.Range("J2").Top + 2
    w = ws.Range("J2:N6").Width
    h = 118

    margin = 12
    gap = 8
    mainH = 34
    btnH = 28
    smallW = (w - margin * 2 - gap) / 2

    AddPanelBack ws, x, y, w, h

    With ws.Range("J2:N2")
        .UnMerge
        .Merge
        .Value = "変換後取扱店を入力して反映"
        .Font.Name = "Yu Gothic UI"
        .Font.Size = 10.5
        .Font.Bold = True
        .Font.Color = ThemeColor("muted-strong")
        .Interior.Color = vbWhite
        .HorizontalAlignment = xlCenter
        .VerticalAlignment = xlCenter
        .WrapText = False
        .ShrinkToFit = True
    End With

    AddUIButton ws, x + margin, y + 26, w - margin * 2, mainH, "取扱店反映", "ApplyShopConversionToCashOperation", "hero"
    AddUIButton ws, x + margin, y + 26 + mainH + gap, smallW, btnH, "一覧更新", "BuildShopConversionTargetSheet", "tool"
    AddUIButton ws, x + margin + smallW + gap, y + 26 + mainH + gap, smallW, btnH, "入力へ戻る", "ShowInputSheet", "soft"

    FixUnreadableWhiteTextOnSheet ws
    LockToolShapes ws
End Sub


Public Sub ProtectShopConversionTargetSheet()
    '取扱店変換対象シートは、変換後取扱店・確認状況だけ入力できればよい。
    'ボタンやカードは保護して、誤って移動・サイズ変更されないようにする。
    Dim ws As Worksheet
    If Not SheetExists(SH_SHOP_TARGET) Then Exit Sub
    Set ws = GetSheet(SH_SHOP_TARGET)

    On Error Resume Next
    ws.Unprotect Password:=TOOL_PASSWORD
    ws.Cells.Locked = True
    ws.Range("F2:G1000").Locked = False
    LockToolShapes ws
    ws.Protect Password:=TOOL_PASSWORD, DrawingObjects:=True, Contents:=True, Scenarios:=False, _
               UserInterfaceOnly:=True, AllowFiltering:=True, AllowSorting:=True, _
               AllowFormattingCells:=False, AllowFormattingColumns:=False, AllowFormattingRows:=False
    ws.EnableSelection = xlNoRestrictions
    On Error GoTo 0
End Sub

Private Function IsCashOperationTransactionRow(ByVal ws As Worksheet, ByVal r As Long) As Boolean
    Dim txt As String
    If ws Is Nothing Then Exit Function
    If r < 2 Then Exit Function
    If CellText(ws.Cells(r, OUT_COL_ROW_KIND).Value) = ROW_KIND_TRANSACTION Then
        IsCashOperationTransactionRow = True
        Exit Function
    End If
    If Len(CellText(ws.Cells(r, OUT_COL_BANK).Value)) = 0 Then Exit Function
    txt = CellText(ws.Cells(r, OUT_COL_TEKIYO).Value)
    If IsSpecialCashOperationRow(txt) Then Exit Function
    If Len(CellText(ws.Cells(r, OUT_COL_DATE).Value)) = 0 Then Exit Function
    IsCashOperationTransactionRow = True
End Function

Private Function IsSpecialCashOperationRow(ByVal tekiyoText As String) As Boolean
    If tekiyoText = "口座開設日" Or tekiyoText = "口座解約日" Then
        IsSpecialCashOperationRow = True
    ElseIf InStr(tekiyoText, "残高") > 0 Then
        IsSpecialCashOperationRow = True
    End If
End Function

Private Function FindShopTargetRow(ByVal ws As Worksheet, ByVal bankName As String, ByVal codeText As String) As Long
    Dim lastR As Long, r As Long
    lastR = LastRow(ws, SHOP_TGT_COL_NO)
    For r = 2 To lastR
        If CellText(ws.Cells(r, SHOP_TGT_COL_BANK).Value) = bankName And _
           CellText(ws.Cells(r, SHOP_TGT_COL_CODE).Value) = codeText Then
            FindShopTargetRow = r
            Exit Function
        End If
    Next r
End Function

Private Function LookupShopConversionName(ByVal ws As Worksheet, ByVal bankName As String, ByVal codeText As String) As String
    Dim r As Long
    If ws Is Nothing Then Exit Function
    r = FindShopTargetRow(ws, bankName, codeText)
    If r > 0 Then LookupShopConversionName = CellText(ws.Cells(r, SHOP_TGT_COL_RESULT).Value)
End Function

Private Sub UpdateShopTargetStatuses(ByVal ws As Worksheet)
    Dim lastR As Long, r As Long
    If ws Is Nothing Then Exit Sub
    lastR = LastRow(ws, SHOP_TGT_COL_NO)
    For r = 2 To lastR
        If Len(CellText(ws.Cells(r, SHOP_TGT_COL_RESULT).Value)) > 0 Then
            ws.Cells(r, SHOP_TGT_COL_STATUS).Value = "入力済"
            ws.Cells(r, SHOP_TGT_COL_STATUS).Interior.Color = ThemeColor("success-border")
        ElseIf Len(CellText(ws.Cells(r, SHOP_TGT_COL_CODE).Value)) > 0 Then
            ws.Cells(r, SHOP_TGT_COL_STATUS).Value = "未入力"
            ws.Cells(r, SHOP_TGT_COL_STATUS).Interior.Color = ThemeColor("warning-soft")
        End If
    Next r
End Sub

Private Sub PreserveShopTargetValues(ByVal oldData As Variant, ByVal bankName As String, ByVal codeText As String, _
                                     ByRef resultName As String, ByRef statusText As String)
    '旧版の11列構成、新版の8列構成のどちらからでも入力済み結果を拾えるよう、ヘッダー名で列を探す。
    Dim i As Long
    Dim bankCol As Long, codeCol As Long, resultCol As Long, statusCol As Long
    resultName = "": statusText = ""
    If Not IsArray(oldData) Then Exit Sub
    On Error GoTo EH

    bankCol = OldDataHeaderIndex(oldData, "銀行名", 2)
    codeCol = OldDataHeaderIndex(oldData, "取扱店コード", 3)
    resultCol = OldDataHeaderIndex(oldData, "変換後取扱店", 6)
    statusCol = OldDataHeaderIndex(oldData, "確認状況", 7)

    For i = LBound(oldData, 1) + 1 To UBound(oldData, 1)
        If CellText(oldData(i, bankCol)) = bankName And CellText(oldData(i, codeCol)) = codeText Then
            resultName = CellText(oldData(i, resultCol))
            statusText = CellText(oldData(i, statusCol))
            Exit Sub
        End If
    Next i
EH:
End Sub

Private Function OldDataHeaderIndex(ByVal oldData As Variant, ByVal headerText As String, ByVal fallbackCol As Long) As Long
    Dim j As Long
    On Error GoTo EH
    For j = LBound(oldData, 2) To UBound(oldData, 2)
        If CellText(oldData(LBound(oldData, 1), j)) = headerText Then
            OldDataHeaderIndex = j
            Exit Function
        End If
    Next j
EH:
    If fallbackCol > 0 Then
        OldDataHeaderIndex = fallbackCol
    Else
        OldDataHeaderIndex = 1
    End If
End Function

Private Function AppendRowNumber(ByVal existingText As String, ByVal rowNo As Long) As String
    If Len(existingText) = 0 Then
        AppendRowNumber = CStr(rowNo)
    Else
        AppendRowNumber = existingText & "," & CStr(rowNo)
    End If
End Function

Public Function IsCodeLikeShop(ByVal valueText As String) As Boolean
    Dim s As String
    s = NormalizeShopCodeText(valueText)
    If Len(s) = 0 Then Exit Function
    If ContainsJapaneseChar(s) Then Exit Function
    If Not ContainsDigit(s) Then Exit Function
    If InStr(s, "支店") > 0 Or InStr(s, "本店") > 0 Then Exit Function
    IsCodeLikeShop = True
End Function

Public Function NormalizeShopCodeText(ByVal valueText As String) As String
    Dim s As String, i As Long, ch As String, code As Long, outText As String
    s = Trim$(CStr(valueText))
    s = Replace(s, "　", " ")
    s = Trim$(s)
    For i = 1 To Len(s)
        ch = Mid$(s, i, 1)
        code = AscW(ch)
        Select Case code
            Case &HFF10 To &HFF19
                outText = outText & ChrW$(code - &HFEE0)
            Case &HFF21 To &HFF3A
                outText = outText & ChrW$(code - &HFEE0)
            Case &HFF41 To &HFF5A
                outText = outText & UCase$(ChrW$(code - &HFEE0))
            Case &H2010, &H2011, &H2012, &H2013, &H2014, &H2212, &HFF0D
                outText = outText & "-"
            Case 32, 9
                '空白は除外
            Case Else
                outText = outText & UCase$(ch)
        End Select
    Next i
    NormalizeShopCodeText = outText
End Function

Private Function ContainsDigit(ByVal s As String) As Boolean
    Dim i As Long, code As Long
    For i = 1 To Len(s)
        code = AscW(Mid$(s, i, 1))
        If code >= 48 And code <= 57 Then ContainsDigit = True: Exit Function
    Next i
End Function

Private Function ContainsJapaneseChar(ByVal s As String) As Boolean
    Dim i As Long, code As Long
    For i = 1 To Len(s)
        code = AscW(Mid$(s, i, 1))
        If code < 0 Then code = code + 65536
        If (code >= &H3040 And code <= &H30FF) Or _
           (code >= &H3400 And code <= &H9FFF) Or _
           (code >= &HF900 And code <= &HFAFF) Or _
           (code >= &HFF66 And code <= &HFF9D) Then
            ContainsJapaneseChar = True
            Exit Function
        End If
    Next i
End Function

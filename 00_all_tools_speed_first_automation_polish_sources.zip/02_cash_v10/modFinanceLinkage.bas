Attribute VB_Name = "modFinanceLinkage"
Option Explicit

Public Function CommonDataPath() As String
    Dim folderPath As String, fileName As String
    On Error Resume Next
    fileName = CellText(GetCfgCell(ROW_CFG_COMMON_DATA).Value)
    On Error GoTo 0
    If Len(fileName) = 0 Then fileName = COMMON_DATA_FILE
    folderPath = ThisWorkbook.Path
    If Len(folderPath) = 0 Then folderPath = CurDir$
    CommonDataPath = LinkCombinePath(folderPath, fileName)
End Function

Private Function LinkCombinePath(ByVal folderPath As String, ByVal fileName As String) As String
    If Right$(folderPath, 1) = "\" Or Right$(folderPath, 1) = "/" Then
        LinkCombinePath = folderPath & fileName
    Else
        LinkCombinePath = folderPath & Application.PathSeparator & fileName
    End If
End Function

Public Function IsCommonLinkEnabled() As Boolean
    On Error Resume Next
    IsCommonLinkEnabled = (CellText(GetCfgCell(ROW_CFG_LINK_MODE).Value) <> DISPLAY_OFF)
    On Error GoTo 0
End Function

Public Sub LoadPersonMasterFromCommonData(Optional ByVal showMessage As Boolean = True)
    Dim p As String, wb As Workbook, wsSrc As Worksheet, wsRef As Worksheet, wsCand As Worksheet
    Dim lastR As Long, r As Long, outR As Long
    Dim colId As Long, colName As Long, colSurname As Long, colGiven As Long, colRel As Long, colDispRel As Long
    Dim colType As Long, colBirth As Long, colDeath As Long, colOld As Long
    Dim personId As String, personName As String, relText As String, typeText As String, oldSurname As String
    Dim inhDate As Variant

    If Not IsCommonLinkEnabled() Then Exit Sub
    If Len(ThisWorkbook.Path) = 0 Then
        AppendLinkLog "人物情報読込", "中止", "このツールが案件フォルダへ保存されていません。"
        If showMessage Then MsgBox "先にこのツールを案件フォルダへ保存してください。" & vbCrLf & _
                               "同じフォルダ内の 00_共通データ.xlsx を読みに行きます。", vbExclamation
        Exit Sub
    End If
    AppBegin "人物情報を読み込み中..."
    EnsureFinanceLinkSheets
    p = CommonDataPath()
    If Dir$(p) = "" Then
        AppendLinkLog "人物情報読込", "未実行", "共通データが見つかりません: " & p
        AppEnd
        If showMessage Then MsgBox "00_共通データ.xlsx が見つかりません。" & vbCrLf & p, vbInformation
        Exit Sub
    End If

    On Error GoTo EH
    Set wb = Workbooks.Open(Filename:=p, ReadOnly:=True, UpdateLinks:=False, IgnoreReadOnlyRecommended:=True, Notify:=False, AddToMru:=False)
    Set wsSrc = LinkWorksheet(wb, "T_人物")
    If wsSrc Is Nothing Then Err.Raise vbObjectError + 8301, "LoadPersonMasterFromCommonData", "T_人物 シートがありません。"

    colId = HeaderColumn(wsSrc, "人物ID", 1)
    colName = FirstHeaderColumn(wsSrc, Array("氏名表示", "氏名", "表示名"), 0)
    colSurname = FirstHeaderColumn(wsSrc, Array("現在姓", "姓"), 0)
    colGiven = FirstHeaderColumn(wsSrc, Array("名", "名前"), 0)
    colRel = FirstHeaderColumn(wsSrc, Array("被相続人から見た続柄", "続柄"), 0)
    colDispRel = FirstHeaderColumn(wsSrc, Array("表示用続柄"), 0)
    colType = FirstHeaderColumn(wsSrc, Array("人物区分", "区分"), 0)
    colBirth = FirstHeaderColumn(wsSrc, Array("生年月日"), 0)
    colDeath = FirstHeaderColumn(wsSrc, Array("死亡日"), 0)
    colOld = FirstHeaderColumn(wsSrc, Array("旧姓"), 0)

    Set wsRef = GetSheet(SH_WORK_PERSON_REF)
    wsRef.Cells.Clear
    SetRowValues wsRef.Range("A1"), Array("人物ID", "氏名表示", "続柄", "人物区分", "生年月日", "死亡日", "旧姓", "元データ行")
    FormatOutputHeader wsRef.Range("A1:H1")
    Set wsCand = GetOrCreateSheet(SH_PERSON_CAND, False)
    wsCand.Cells.Clear
    SetRowValues wsCand.Range("A1"), Array("人物候補", "人物ID", "続柄", "人物区分")
    FormatOutputHeader wsCand.Range("A1:D1")

    lastR = LastRow(wsSrc, colId)
    outR = 2
    For r = 2 To lastR
        personId = CellText(wsSrc.Cells(r, colId).Value)
        If Len(personId) > 0 Then
            personName = ""
            If colName > 0 Then personName = CellText(wsSrc.Cells(r, colName).Value)
            If Len(personName) = 0 Then personName = Trim$(CellText(wsSrc.Cells(r, colSurname).Value) & CellText(wsSrc.Cells(r, colGiven).Value))
            oldSurname = IIf(colOld > 0, CellText(wsSrc.Cells(r, colOld).Value), "")
            If Len(personName) > 0 And Len(oldSurname) > 0 And InStr(personName, "旧姓") = 0 Then personName = personName & "（旧姓：" & oldSurname & "）"
            relText = ""
            If colDispRel > 0 Then relText = CellText(wsSrc.Cells(r, colDispRel).Value)
            If Len(relText) = 0 And colRel > 0 Then relText = CellText(wsSrc.Cells(r, colRel).Value)
            typeText = IIf(colType > 0, CellText(wsSrc.Cells(r, colType).Value), "")
            wsRef.Cells(outR, 1).Value = personId
            wsRef.Cells(outR, 2).Value = personName
            wsRef.Cells(outR, 3).Value = relText
            wsRef.Cells(outR, 4).Value = typeText
            If colBirth > 0 Then wsRef.Cells(outR, 5).Value = wsSrc.Cells(r, colBirth).Value
            If colDeath > 0 Then wsRef.Cells(outR, 6).Value = wsSrc.Cells(r, colDeath).Value
            wsRef.Cells(outR, 7).Value = oldSurname
            wsRef.Cells(outR, 8).Value = r
            wsCand.Cells(outR, 1).Value = personName
            wsCand.Cells(outR, 2).Value = personId
            wsCand.Cells(outR, 3).Value = relText
            wsCand.Cells(outR, 4).Value = typeText
            outR = outR + 1
        End If
    Next r

    inhDate = ReadInheritanceDateFromCommon(wb)
    If IsDate(inhDate) Then GetCfgCell(ROW_CFG_INHERITANCE_DATE).Value = CDate(inhDate)
    wb.Close SaveChanges:=False
    AutoFitSheetSmart wsRef, "A:H", 6, 34
    AutoFitSheetSmart wsCand, "A:D", 6, 34
    RefreshLinkedPersonCandidates
    ApplyInputSettings False
    SyncSelectedPersonFromInput GetSheet(SH_INPUT)
    AppendLinkLog "人物情報読込", "完了", CStr(outR - 2) & "名を読み込みました。"
    AppEnd
    If showMessage Then MsgBox "人物情報を読み込みました。" & vbCrLf & CStr(outR - 2) & "名", vbInformation
    Exit Sub
EH:
    On Error Resume Next
    If Not wb Is Nothing Then wb.Close SaveChanges:=False
    AppendLinkLog "人物情報読込", "エラー", Err.Description
    AppEnd
    If showMessage Then MsgBox "人物情報読込中にエラーが発生しました。" & vbCrLf & Err.Description, vbExclamation
End Sub

Public Sub RefreshLinkedPersonCandidates()
    Dim ws As Worksheet, lastR As Long
    On Error Resume Next
    If SheetExists(SH_PERSON_CAND) Then
        Set ws = GetSheet(SH_PERSON_CAND)
        lastR = LastRow(ws, 1)
        If lastR < 2 Then lastR = 2
        ResetName NM_LST_PERSON_CAND, ws.Range("A2:A" & CStr(lastR))
        ResetName NM_LST_LINKED_PERSON_CAND, ws.Range("A2:A" & CStr(lastR))
    End If
    On Error GoTo 0
End Sub

Public Sub SyncSelectedPersonFromInput(ByVal ws As Worksheet)
    Dim displayName As String, personId As String, relText As String
    If ws Is Nothing Then Exit Sub
    If ws.Name <> SH_INPUT Then Exit Sub
    displayName = CellText(ws.Range(CELL_PERSON).Value)
    personId = PersonIdByDisplayName(displayName)
    relText = PersonRelationById(personId)
    On Error Resume Next
    ws.Unprotect Password:=TOOL_PASSWORD
    ws.Range(CELL_PERSON_ID).Value = personId
    If Len(relText) > 0 And UseRelationshipDisplay() Then ws.Range(CELL_RELATIONSHIP).Value = relText
    If Len(displayName) = 0 Then
        ws.Range(CELL_LINK_STATUS).Value = ""
    ElseIf Len(personId) > 0 Then
        ws.Range(CELL_LINK_STATUS).Value = "人物ID連携済: " & personId
    Else
        ws.Range(CELL_LINK_STATUS).Value = "人物ID未連携"
    End If
    ProtectInputSheet
    On Error GoTo 0
End Sub

Public Function ResolveInputPersonId(ByVal ws As Worksheet, ByVal personName As String) As String
    If Not ws Is Nothing Then ResolveInputPersonId = CellText(ws.Range(CELL_PERSON_ID).Value)
    If Len(ResolveInputPersonId) = 0 Then ResolveInputPersonId = PersonIdByDisplayName(personName)
End Function

Public Function PersonIdByDisplayName(ByVal displayName As String) As String
    Dim ws As Worksheet, lastR As Long, r As Long
    If Len(CellText(displayName)) = 0 Then Exit Function
    If Not SheetExists(SH_PERSON_CAND) Then Exit Function
    Set ws = GetSheet(SH_PERSON_CAND)
    lastR = LastRow(ws, 1)
    For r = 2 To lastR
        If CellText(ws.Cells(r, 1).Value) = CellText(displayName) Then
            PersonIdByDisplayName = CellText(ws.Cells(r, 2).Value)
            Exit Function
        End If
    Next r
End Function

Public Function PersonRelationById(ByVal personId As String) As String
    Dim ws As Worksheet, lastR As Long, r As Long
    If Len(personId) = 0 Then Exit Function
    If Not SheetExists(SH_WORK_PERSON_REF) Then Exit Function
    Set ws = GetSheet(SH_WORK_PERSON_REF)
    lastR = LastRow(ws, 1)
    For r = 2 To lastR
        If CellText(ws.Cells(r, 1).Value) = personId Then
            PersonRelationById = CellText(ws.Cells(r, 3).Value)
            Exit Function
        End If
    Next r
End Function

Public Sub ValidateFinanceLinkage()
    Dim wsCheck As Worksheet, wsTx As Worksheet, lastR As Long, r As Long
    Dim errCount As Long, warnCount As Long
    If Not RequireToolReady() Then Exit Sub
    On Error GoTo EH
    AppBegin "連携チェック中..."
    Set wsCheck = GetSheet(SH_CHECK)
    wsCheck.Visible = xlSheetVisible
    wsCheck.Cells.Clear
    SetRowValues wsCheck.Range("A1"), Array("区分", "場所", "内容")
    FormatOutputHeader wsCheck.Range("A1:C1")

    If Dir$(CommonDataPath()) = "" Then
        AddCheck "警告", "00_共通データ", "共通データがありません。人物情報系ツールで作成後、人物情報を読込んでください。"
        warnCount = warnCount + 1
    End If
    If SheetExists(SH_WORK_PERSON_REF) Then
        If LastRow(GetSheet(SH_WORK_PERSON_REF), 1) < 2 Then
            AddCheck "警告", SH_WORK_PERSON_REF, "人物情報が読み込まれていません。"
            warnCount = warnCount + 1
        End If
    End If
    Set wsTx = GetSheet(SH_WORK_TX)
    lastR = LastRow(wsTx, 1)
    For r = 2 To lastR
        If CellText(wsTx.Cells(r, WORK_TX_COL_ROW_KIND).Value) = ROW_KIND_TRANSACTION Then
            If Len(CellText(wsTx.Cells(r, WORK_TX_COL_PERSON_ID).Value)) = 0 Then AddCheck "警告", SH_WORK_TX & "!" & r & "行", "人物IDがありません。": warnCount = warnCount + 1
            If Len(CellText(wsTx.Cells(r, WORK_TX_COL_ACCOUNT_ID).Value)) = 0 Then AddCheck "エラー", SH_WORK_TX & "!" & r & "行", "口座IDがありません。": errCount = errCount + 1
            If Len(CellText(wsTx.Cells(r, WORK_TX_COL_TRANSACTION_ID).Value)) = 0 Then AddCheck "エラー", SH_WORK_TX & "!" & r & "行", "取引IDがありません。": errCount = errCount + 1
        End If
    Next r
    AutoFitSheetSmart wsCheck, "A:C", 6, 34
    HideDailySheets False
    ShowCheckSheet
    AppEnd
    MsgBox "連携チェック完了" & vbCrLf & "エラー: " & errCount & "件" & vbCrLf & "警告: " & warnCount & "件", IIf(errCount > 0, vbExclamation, vbInformation)
    Exit Sub
EH:
    AppEnd
    MsgBox "連携チェック中にエラーが発生しました。" & vbCrLf & Err.Description, vbExclamation
End Sub

Public Sub SaveFinanceCommonData(Optional ByVal showMessage As Boolean = True)
    Dim p As String, wb As Workbook, createdNew As Boolean
    If Not IsCommonLinkEnabled() Then Exit Sub
    If Len(ThisWorkbook.Path) = 0 Then
        AppendLinkLog "共通データ保存", "中止", "このツールが案件フォルダへ保存されていません。"
        If showMessage Then MsgBox "先にこのツールを案件フォルダへ保存してください。" & vbCrLf & _
                               "未保存のままでは、00_共通データ.xlsx の保存場所が不安定になります。", vbExclamation
        If Not showMessage Then Err.Raise vbObjectError + 8401, "SaveFinanceCommonData", "このツールが案件フォルダへ保存されていません。"
        Exit Sub
    End If

    On Error GoTo EH
    AppBegin "共通データへ保存中..."
    EnsureFinanceLinkSheets
    p = CommonDataPath()
    If Dir$(p) = "" Then
        AppendLinkLog "共通データ保存", "中止", "00_共通データ.xlsx が見つかりません。人物情報系ツールで先に共通データを作成してください: " & p
        AppEnd
        If showMessage Then
            MsgBox "00_共通データ.xlsx が見つかりません。" & vbCrLf & _
                   "連携運用では、人物情報系ツールで先に共通データを作成してから資金データを保存してください。" & vbCrLf & p, vbExclamation
        Else
            Err.Raise vbObjectError + 8402, "SaveFinanceCommonData", "00_共通データ.xlsx が見つかりません。人物情報系ツールで先に共通データを作成してください。"
        End If
        Exit Sub
    Else
        BackupCommonDataBeforeUpdate p, "02資金保存"
        Set wb = Workbooks.Open(Filename:=p, ReadOnly:=False, UpdateLinks:=False, IgnoreReadOnlyRecommended:=True, Notify:=False, AddToMru:=False)
    End If
    WriteFinanceSettings wb
    WriteAccountsTable wb
    WriteTransactionsTable wb
    WriteBalancesTable wb
    WriteShopConversionTable wb
    If createdNew Then
        wb.SaveAs Filename:=p, FileFormat:=xlOpenXMLWorkbook
    Else
        wb.Save
    End If
    wb.Close SaveChanges:=False
    AppendLinkLog "共通データ保存", "完了", p
    AppEnd
    If showMessage Then MsgBox "共通データへ保存しました。" & vbCrLf & p, vbInformation
    Exit Sub
EH:
    On Error Resume Next
    If Not wb Is Nothing Then wb.Close SaveChanges:=False
    AppendLinkLog "共通データ保存", "エラー", Err.Description
    AppEnd
    If showMessage Then
        MsgBox "共通データ保存中にエラーが発生しました。" & vbCrLf & Err.Description, vbExclamation
    Else
        Err.Raise Err.Number, "SaveFinanceCommonData", Err.Description
    End If
End Sub

Public Sub NormalizeOutputShopFinal(ByVal ws As Worksheet)
    Dim lastR As Long, r As Long, shopText As String
    If ws Is Nothing Then Exit Sub
    lastR = LastRow(ws, OUT_COL_BANK)
    If lastR < 2 Then Exit Sub
    For r = 2 To lastR
        shopText = CellText(ws.Cells(r, OUT_COL_SHOP).Value)
        If Len(shopText) = 0 Then shopText = CellText(ws.Cells(r, OUT_COL_BRANCH).Value)
        ws.Cells(r, OUT_COL_SHOP_FINAL).Value = shopText
        If Len(CellText(ws.Cells(r, OUT_COL_DATA_STATUS).Value)) = 0 Then ws.Cells(r, OUT_COL_DATA_STATUS).Value = DATA_STATUS_ACTIVE
    Next r
End Sub

Private Sub WriteFinanceSettings(ByVal wb As Workbook)
    Dim ws As Worksheet
    Set ws = LinkResetSheet(wb, "T_資金連携設定")
    SetRowValues ws.Range("A1"), Array("項目", "値")
    SetRowValues ws.Range("A2"), Array("スキーマバージョン", COMMON_SCHEMA_VERSION)
    SetRowValues ws.Range("A3"), Array("共通スキーマバージョン", "common-data-v1.1")
    SetRowValues ws.Range("A4"), Array("相続開始日", GetCfgCell(ROW_CFG_INHERITANCE_DATE).Value)
    SetRowValues ws.Range("A5"), Array("作成日時", Now)
    SetRowValues ws.Range("A6"), Array("作成ツール", ThisWorkbook.Name)
    AutoFitSheetSmart ws, "A:B", 6, 34

    UpdateCommonLinkControlSheet wb, "資金スキーマバージョン", COMMON_SCHEMA_VERSION, "02側の出力仕様"
    UpdateCommonLinkControlSheet wb, "保存日時", Now, "共通データを最後に更新した日時"
End Sub

Private Sub UpdateCommonLinkControlSheet(ByVal wb As Workbook, ByVal keyText As String, ByVal valueText As Variant, ByVal descText As String)
    Dim ws As Worksheet, r As Long, lastR As Long
    On Error Resume Next
    Set ws = wb.Worksheets("T_連携設定")
    On Error GoTo 0
    If ws Is Nothing Then
        Set ws = wb.Worksheets.Add(Before:=wb.Worksheets(1))
        ws.Name = "T_連携設定"
        ws.Range("A1:C1").Value = Array("キー", "値", "説明")
    End If
    If Len(CellText(ws.Cells(1, 1).Value)) = 0 Then ws.Range("A1:C1").Value = Array("キー", "値", "説明")

    lastR = LastRow(ws, 1)
    If lastR < 1 Then lastR = 1
    For r = 2 To lastR
        If CellText(ws.Cells(r, 1).Value) = keyText Then
            ws.Cells(r, 2).Value = valueText
            ws.Cells(r, 3).Value = descText
            ws.Columns("A:C").AutoFit
            Exit Sub
        End If
    Next r

    ws.Cells(lastR + 1, 1).Value = keyText
    ws.Cells(lastR + 1, 2).Value = valueText
    ws.Cells(lastR + 1, 3).Value = descText
    ws.Columns("A:C").AutoFit
End Sub

Private Sub WriteAccountsTable(ByVal wb As Workbook)
    Dim src As Worksheet, dst As Worksheet, lastR As Long
    Set dst = LinkResetSheet(wb, "T_口座")
    SetRowValues dst.Range("A1"), Array("口座ID", "人物ID", "氏名", "続柄", "銀行名", "支店名", "科目", "口座番号", "口座番号正規化", "口座開設日", "口座解約日", "データ状態", "作成日時", "更新日時")
    Set src = GetSheet(SH_WORK_ACCOUNT)
    lastR = LastRow(src, 1)
    If lastR >= 2 Then dst.Range("A2").Resize(lastR - 1, 14).Value = src.Range("A2:N" & CStr(lastR)).Value
    AutoFitSheetSmart dst, "A:N", 6, 34
End Sub

Private Sub WriteTransactionsTable(ByVal wb As Workbook)
    Dim src As Worksheet, dst As Worksheet, lastR As Long, r As Long, outR As Long
    Dim converted As Object, txId As String
    Dim shopRaw As String, shopFilled As String, shopConverted As String, shopFinal As String, convertedValue As String
    Dim otherValue As Variant, otherAmount As Variant, afterAmount As Variant
    Set dst = LinkResetSheet(wb, "T_取引")
    SetRowValues dst.Range("A1"), Array("取引ID", "口座ID", "人物ID", "氏名", "続柄", "銀行名", "支店名", "科目", "口座番号", "日付", "時刻", "出金", "入金", "取扱店原文", "取扱店補完値", "取扱店変換後", "取扱店確定値", "機番", "摘要", "その他", "取引後残高", "取引後残高原文", "残高情報元", "元行種別", "データ状態")
    Set converted = BuildConvertedShopDictionary()
    Set src = GetSheet(SH_WORK_TX)
    lastR = LastRow(src, 1)
    outR = 2
    For r = 2 To lastR
        If CellText(src.Cells(r, WORK_TX_COL_ROW_KIND).Value) = ROW_KIND_TRANSACTION And _
           CellText(src.Cells(r, WORK_TX_COL_DATA_STATUS).Value) <> DATA_STATUS_CANCELLED Then
            txId = CellText(src.Cells(r, WORK_TX_COL_TRANSACTION_ID).Value)
            shopRaw = CellText(src.Cells(r, OUT_COL_SHOP).Value)
            shopFilled = ""
            If Len(shopRaw) = 0 Then shopFilled = CellText(src.Cells(r, OUT_COL_BRANCH).Value)
            convertedValue = ""
            If converted.Exists(txId) Then convertedValue = CellText(converted(txId))
            shopConverted = ""
            If Len(convertedValue) > 0 Then shopConverted = convertedValue

            shopFinal = shopConverted
            If Len(shopFinal) = 0 Then shopFinal = CellText(src.Cells(r, WORK_TX_COL_SHOP_FINAL).Value)
            If Len(shopFinal) = 0 Then shopFinal = shopFilled
            If Len(shopFinal) = 0 Then shopFinal = shopRaw
            If Len(shopFinal) = 0 Then shopFinal = CellText(src.Cells(r, OUT_COL_BRANCH).Value)
            dst.Cells(outR, 1).Value = txId
            dst.Cells(outR, 2).Value = src.Cells(r, WORK_TX_COL_ACCOUNT_ID).Value
            dst.Cells(outR, 3).Value = src.Cells(r, WORK_TX_COL_PERSON_ID).Value
            dst.Cells(outR, 4).Value = src.Cells(r, OUT_COL_PERSON).Value
            dst.Cells(outR, 5).Value = src.Cells(r, WORK_TX_COL_RELATIONSHIP).Value
            dst.Cells(outR, 6).Value = src.Cells(r, OUT_COL_BANK).Value
            dst.Cells(outR, 7).Value = src.Cells(r, OUT_COL_BRANCH).Value
            dst.Cells(outR, 8).Value = src.Cells(r, OUT_COL_ACCOUNT_TYPE).Value
            dst.Cells(outR, 9).Value = src.Cells(r, OUT_COL_ACCOUNT_NO).Value
            dst.Cells(outR, 10).Value = src.Cells(r, OUT_COL_DATE).Value
            dst.Cells(outR, 11).Value = src.Cells(r, OUT_COL_TIME).Value
            dst.Cells(outR, 12).Value = src.Cells(r, OUT_COL_WITHDRAW).Value
            dst.Cells(outR, 13).Value = src.Cells(r, OUT_COL_DEPOSIT).Value
            dst.Cells(outR, 14).Value = shopRaw
            dst.Cells(outR, 15).Value = shopFilled
            dst.Cells(outR, 16).Value = shopConverted
            dst.Cells(outR, 17).Value = shopFinal
            dst.Cells(outR, 18).Value = src.Cells(r, OUT_COL_MACHINE).Value
            dst.Cells(outR, 19).Value = src.Cells(r, OUT_COL_TEKIYO).Value
            otherValue = src.Cells(r, OUT_COL_OTHER).Value
            If Len(CellText(src.Cells(r, WORK_TX_COL_BALANCE_SOURCE).Value)) > 0 Then
                otherAmount = ToAmountOrBlank(otherValue)
                afterAmount = ToAmountOrBlank(src.Cells(r, WORK_TX_COL_AFTER_BALANCE).Value)
                If IsNumeric(otherAmount) And IsNumeric(afterAmount) Then
                    If CDbl(otherAmount) = CDbl(afterAmount) Then otherValue = ""
                ElseIf CellText(otherValue) = CellText(src.Cells(r, WORK_TX_COL_AFTER_BALANCE_RAW).Value) Then
                    otherValue = ""
                End If
            End If
            dst.Cells(outR, 20).Value = otherValue
            dst.Cells(outR, 21).Value = src.Cells(r, WORK_TX_COL_AFTER_BALANCE).Value
            dst.Cells(outR, 22).Value = src.Cells(r, WORK_TX_COL_AFTER_BALANCE_RAW).Value
            dst.Cells(outR, 23).Value = src.Cells(r, WORK_TX_COL_BALANCE_SOURCE).Value
            dst.Cells(outR, 24).Value = ROW_KIND_TRANSACTION
            dst.Cells(outR, 25).Value = DATA_STATUS_ACTIVE
            outR = outR + 1
        End If
    Next r
    If outR > 2 Then
        dst.Range("J2:J" & CStr(outR - 1)).NumberFormatLocal = "yyyy/m/d"
        dst.Range("L2:M" & CStr(outR - 1)).NumberFormatLocal = "#,##0"
        dst.Range("U2:U" & CStr(outR - 1)).NumberFormatLocal = "#,##0"
    End If
    AutoFitSheetSmart dst, "A:Y", 6, 34
End Sub

Private Sub WriteBalancesTable(ByVal wb As Workbook)
    Dim src As Worksheet, dst As Worksheet, lastR As Long, r As Long, outR As Long
    Set dst = LinkResetSheet(wb, "T_残高")
    SetRowValues dst.Range("A1"), Array("残高ID", "口座ID", "人物ID", "氏名", "続柄", "銀行名", "支店名", "科目", "口座番号", "残高基準日", "残高見出し", "残高", "口座開設日", "口座解約日", "その他", "転記回ID", "データ状態")
    Set src = GetSheet(SH_WORK_BAL)
    lastR = LastRow(src, 1)
    outR = 2
    For r = 2 To lastR
        If Len(CellText(src.Cells(r, WORK_BAL_COL_BALANCE_ID).Value)) > 0 And _
           CellText(src.Cells(r, WORK_BAL_COL_DATA_STATUS).Value) <> DATA_STATUS_CANCELLED Then
            dst.Cells(outR, 1).Value = src.Cells(r, WORK_BAL_COL_BALANCE_ID).Value
            dst.Cells(outR, 2).Value = src.Cells(r, WORK_BAL_COL_ACCOUNT_ID).Value
            dst.Cells(outR, 3).Value = src.Cells(r, WORK_BAL_COL_PERSON_ID).Value
            dst.Cells(outR, 4).Value = src.Cells(r, OUT_COL_PERSON).Value
            dst.Cells(outR, 5).Value = src.Cells(r, WORK_BAL_COL_RELATIONSHIP).Value
            dst.Cells(outR, 6).Value = src.Cells(r, OUT_COL_BANK).Value
            dst.Cells(outR, 7).Value = src.Cells(r, OUT_COL_BRANCH).Value
            dst.Cells(outR, 8).Value = src.Cells(r, OUT_COL_ACCOUNT_TYPE).Value
            dst.Cells(outR, 9).Value = src.Cells(r, OUT_COL_ACCOUNT_NO).Value
            dst.Cells(outR, 10).Value = src.Cells(r, 8).Value
            dst.Cells(outR, 11).Value = src.Cells(r, 9).Value
            dst.Cells(outR, 12).Value = src.Cells(r, 10).Value
            dst.Cells(outR, 13).Value = src.Cells(r, 6).Value
            dst.Cells(outR, 14).Value = src.Cells(r, 7).Value
            dst.Cells(outR, 15).Value = src.Cells(r, 11).Value
            dst.Cells(outR, 16).Value = src.Cells(r, WORK_BAL_COL_TRANSFER_ID).Value
            dst.Cells(outR, 17).Value = src.Cells(r, WORK_BAL_COL_DATA_STATUS).Value
            If Len(CellText(dst.Cells(outR, 17).Value)) = 0 Then dst.Cells(outR, 17).Value = DATA_STATUS_ACTIVE
            outR = outR + 1
        End If
    Next r
    If outR > 2 Then
        dst.Range("J2:J" & CStr(outR - 1)).NumberFormatLocal = "yyyy/m/d"
        dst.Range("L2:L" & CStr(outR - 1)).NumberFormatLocal = "#,##0"
        dst.Range("M2:N" & CStr(outR - 1)).NumberFormatLocal = "yyyy/m/d"
    End If
    AutoFitSheetSmart dst, "A:Q", 6, 34
End Sub

Private Sub WriteShopConversionTable(ByVal wb As Workbook)
    Dim src As Worksheet, dst As Worksheet, lastR As Long
    Set dst = LinkResetSheet(wb, "T_取扱店変換")
    SetRowValues dst.Range("A1"), Array("No", "銀行名", "取扱店コード", "該当件数", "該当行番号", "変換後取扱店", "確認状況", "作成日時")
    If SheetExists(SH_SHOP_TARGET) Then
        Set src = GetSheet(SH_SHOP_TARGET)
        lastR = LastRow(src, SHOP_TGT_COL_NO)
        If lastR >= 2 Then dst.Range("A2").Resize(lastR - 1, 8).Value = src.Range("A2:H" & CStr(lastR)).Value
    End If
    AutoFitSheetSmart dst, "A:H", 6, 34
End Sub

Private Function BuildConvertedShopDictionary() As Object
    Dim d As Object, ws As Worksheet, lastR As Long, r As Long, txId As String, shopText As String
    Set d = CreateObject("Scripting.Dictionary")
    If SheetExists(SH_OUTPUT_TX_CONVERTED) Then
        Set ws = GetSheet(SH_OUTPUT_TX_CONVERTED)
        lastR = LastRow(ws, OUT_COL_BANK)
        For r = 2 To lastR
            txId = CellText(ws.Cells(r, OUT_COL_TRANSACTION_ID).Value)
            If Len(txId) > 0 Then
                shopText = CellText(ws.Cells(r, OUT_COL_SHOP_FINAL).Value)
                If Len(shopText) = 0 Then shopText = CellText(ws.Cells(r, OUT_COL_SHOP).Value)
                If Len(shopText) > 0 Then d(txId) = shopText
            End If
        Next r
    End If
    Set BuildConvertedShopDictionary = d
End Function

Private Function ReadInheritanceDateFromCommon(ByVal wb As Workbook) As Variant
    Dim ws As Worksheet
    For Each ws In wb.Worksheets
        If ws.Name = "T_連携設定" Or ws.Name = "T_設定" Or ws.Name = "T_資金連携設定" Then
            ReadInheritanceDateFromCommon = FindSettingDate(ws, "相続開始日")
            If IsDate(ReadInheritanceDateFromCommon) Then Exit Function
        End If
    Next ws
End Function

Private Function FindSettingDate(ByVal ws As Worksheet, ByVal keyText As String) As Variant
    Dim lastR As Long, lastC As Long, r As Long, c As Long
    lastR = LastUsedRowInSheet(ws)
    lastC = LastUsedColumnPublic(ws)
    For r = 1 To lastR
        For c = 1 To lastC
            If CellText(ws.Cells(r, c).Value) = keyText Then
                If c < lastC Then FindSettingDate = ws.Cells(r, c + 1).Value
                If IsDate(FindSettingDate) Then Exit Function
            End If
        Next c
    Next r
End Function

Private Function LinkWorksheet(ByVal wb As Workbook, ByVal sheetName As String) As Worksheet
    On Error Resume Next
    Set LinkWorksheet = wb.Worksheets(sheetName)
    On Error GoTo 0
End Function

Private Function LinkResetSheet(ByVal wb As Workbook, ByVal sheetName As String) As Worksheet
    Dim ws As Worksheet
    On Error Resume Next
    Set ws = wb.Worksheets(sheetName)
    On Error GoTo 0
    If ws Is Nothing Then
        Set ws = wb.Worksheets.Add(After:=wb.Worksheets(wb.Worksheets.Count))
        ws.Name = sheetName
    Else
        On Error Resume Next
        ws.Visible = xlSheetVisible
        ws.Unprotect Password:=TOOL_PASSWORD
        If ws.FilterMode Then ws.ShowAllData
        ws.AutoFilterMode = False
        Do While ws.ListObjects.Count > 0
            ws.ListObjects(1).Delete
        Loop
        ws.Cells.Clear
        On Error GoTo 0
    End If
    Set LinkResetSheet = ws
End Function

Private Function HeaderColumn(ByVal ws As Worksheet, ByVal headerText As String, Optional ByVal defaultCol As Long = 0) As Long
    Dim c As Long, lastC As Long
    lastC = LastUsedColumnPublic(ws)
    For c = 1 To lastC
        If CellText(ws.Cells(1, c).Value) = headerText Then HeaderColumn = c: Exit Function
    Next c
    HeaderColumn = defaultCol
End Function

Private Function FirstHeaderColumn(ByVal ws As Worksheet, ByVal names As Variant, Optional ByVal defaultCol As Long = 0) As Long
    Dim i As Long, c As Long
    For i = LBound(names) To UBound(names)
        c = HeaderColumn(ws, CStr(names(i)), 0)
        If c > 0 Then FirstHeaderColumn = c: Exit Function
    Next i
    FirstHeaderColumn = defaultCol
End Function

Private Sub BackupCommonDataBeforeUpdate(ByVal filePath As String, ByVal processName As String)
    Dim backupPath As String
    If Len(filePath) = 0 Then Exit Sub
    If Len(Dir$(filePath)) = 0 Then Exit Sub
    backupPath = filePath & ".bak_" & Format$(Now, "yyyymmdd_hhnnss")
    FileCopy filePath, backupPath
    AppendLinkLog processName, "更新前バックアップ", backupPath
End Sub

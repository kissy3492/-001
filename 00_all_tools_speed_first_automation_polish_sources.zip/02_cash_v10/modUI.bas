Attribute VB_Name = "modUI"
Option Explicit

Private mButtonSeq As Long

Public Sub BuildOperationPanel(ByVal ws As Worksheet)
    Dim x As Double, y As Double, w As Double, h As Double
    Dim margin As Double, gap As Double, btnH As Double, primaryH As Double
    Dim colW3 As Double, left1 As Double, left2 As Double, left3 As Double
    Dim topY As Double, contentH As Double
    If ws Is Nothing Then Exit Sub
    mButtonSeq = 0
    On Error Resume Next
    DeleteToolShapes ws, False
    On Error GoTo 0
    x = ws.Range("M2").Left
    y = ws.Range("M2").Top + 4
    w = ws.Range("M2:T13").Width
    h = Application.Max(ws.Range("M2:T15").Height - 8, 246)
    margin = 15
    gap = 6
    btnH = 23
    primaryH = 34
    colW3 = (w - margin * 2 - gap * 2) / 3
    left1 = x + margin
    left2 = left1 + colW3 + gap
    left3 = left2 + colW3 + gap
    AddPanelBack ws, x, y, w, h
    AddPanelLabel ws, x + margin, y + 8, w - margin * 2, 30, "Quick actions", "よく使う操作を上段へ。補助操作は下段に控えめに配置。"
    contentH = primaryH + btnH * 6 + gap * 6
    topY = y + 44
    If topY < y + 8 Then topY = y + 8
    AddUIButton ws, left1, topY, colW3, primaryH, "この口座を転記", "TransferCurrentAccount", "primary"
    AddUIButton ws, left2, topY, colW3, primaryH, "一括作成", "BuildAllOutputSheets", "hero"
    AddUIButton ws, left3, topY, colW3, primaryH, "共通保存", "SaveFinanceCommonData", "export"
    topY = topY + primaryH + gap
    AddUIButton ws, left1, topY, colW3, btnH, "人物読込", "LoadPersonMasterFromCommonData", "accent"
    AddUIButton ws, left2, topY, colW3, btnH, "外部表取込", "ImportExternalCashOperationTable", "accent"
    AddUIButton ws, left3, topY, colW3, btnH, "連携確認", "ValidateFinanceLinkage", "tool"
    topY = topY + btnH + gap
    AddUIButton ws, left1, topY, colW3, btnH, "残高再補完", "RebuildBalancesFromTransactionAfterBalanceButton", "tool"
    AddUIButton ws, left2, topY, colW3, btnH, "次枝番転記", "TransferCurrentAccountNextBranch", "accent"
    AddUIButton ws, left3, topY, colW3, btnH, "最終出力", "ExportFinalWorkbooks", "export"
    topY = topY + btnH + gap
    AddUIButton ws, left1, topY, colW3, btnH, "対象一覧", "BuildShopConversionTargetSheet", "tool"
    AddUIButton ws, left2, topY, colW3, btnH, "変換済表", "ShowConvertedCashOperationSheet", "soft"
    AddUIButton ws, left3, topY, colW3, btnH, "銀行支店転記", "TransferCurrentAccountKeepBankBranch", "tool"
    topY = topY + btnH + gap
    AddUIButton ws, left1, topY, colW3, btnH, "枝番+1", "IncrementAccountBranchNo", "tool"
    AddUIButton ws, left2, topY, colW3, btnH, "入力欄更新", "ApplyInputSettings", "tool"
    AddUIButton ws, left3, topY, colW3, btnH, "明細クリア", "ClearTransactionInput", "neutral"
    topY = topY + btnH + gap
    AddUIButton ws, left1, topY, colW3, btnH, "銀行支店残し", "ClearInputKeepBankBranch", "soft"
    AddUIButton ws, left2, topY, colW3, btnH, "氏名だけ残す", "ClearInputKeepPerson", "soft"
    AddUIButton ws, left3, topY, colW3, btnH, "候補管理", "ShowCandidateSheets", "tool"
    topY = topY + btnH + gap
    AddUIButton ws, left1, topY, colW3, btnH, "設定", "ShowConfigSheet", "tool"
    AddUIButton ws, left2, topY, colW3, btnH, "書式復旧", "RestoreToolFormatting", "tool"
    AddUIButton ws, left3, topY, colW3, btnH, "初期化", "InitializeToolData", "danger"
    LockToolShapes ws
End Sub

Public Sub AddPanelLabel(ByVal ws As Worksheet, ByVal x As Double, ByVal y As Double, ByVal w As Double, ByVal h As Double, ByVal titleText As String, ByVal subText As String)
    Dim shp As Shape
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    Set shp = ws.Shapes.AddTextbox(msoTextOrientationHorizontal, x, y, w, h)
    If Not shp Is Nothing Then
        shp.Name = UI_PREFIX & "panel_label"
        shp.Fill.Visible = msoFalse
        shp.Line.Visible = msoFalse
        shp.TextFrame2.TextRange.Text = titleText & vbCrLf & subText
        shp.TextFrame2.TextRange.Font.Name = THEME_FONT
        shp.TextFrame2.TextRange.Font.Size = 8.8
        shp.TextFrame2.TextRange.Font.Fill.ForeColor.RGB = ThemeColor("muted")
        shp.TextFrame2.TextRange.Characters(1, Len(titleText)).Font.Size = 11
        shp.TextFrame2.TextRange.Characters(1, Len(titleText)).Font.Bold = msoTrue
        shp.TextFrame2.TextRange.Characters(1, Len(titleText)).Font.Fill.ForeColor.RGB = ThemeColor("title")
        shp.TextFrame2.MarginLeft = 0
        shp.TextFrame2.MarginRight = 0
        shp.TextFrame2.MarginTop = 0
        shp.TextFrame2.MarginBottom = 0
        shp.PrintObject = False
        ThemeRegisterDecorativeShape shp, False
    End If
    On Error GoTo 0
End Sub

Public Sub AddPanelBack(ByVal ws As Worksheet, ByVal x As Double, ByVal y As Double, ByVal w As Double, ByVal h As Double)
    Dim shp As Shape
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    Set shp = ws.Shapes.AddShape(msoShapeRoundedRectangle, x, y, w, h)
    If Not shp Is Nothing Then
        shp.Name = UI_PREFIX & "panel_back"
        ThemeStylePanelShape shp, True
        shp.ZOrder msoSendToBack
    End If
    On Error GoTo 0
End Sub

Public Sub AddUIButton(ByVal ws As Worksheet, ByVal x As Double, ByVal y As Double, ByVal w As Double, ByVal h As Double, ByVal caption As String, ByVal macroName As String, ByVal styleName As String)
    Dim shp As Shape
    Dim btn As Object
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    Set shp = ws.Shapes.AddShape(msoShapeRoundedRectangle, x, y, w, h)
    If Not shp Is Nothing Then
        mButtonSeq = mButtonSeq + 1
        shp.Name = UI_PREFIX & "btn_" & CStr(mButtonSeq)
        ThemeStyleButtonShape shp, caption, styleName, MacroRef(macroName)
        shp.AlternativeText = macroName
        ThemeRegisterButtonShape shp, MacroRef(macroName)
        Exit Sub
    End If
    Err.Clear
    Set btn = ws.Buttons.Add(x, y, w, h)
    If Not btn Is Nothing Then
        btn.Caption = caption
        btn.OnAction = MacroRef(macroName)
        btn.Font.Name = THEME_FONT
        btn.Font.Bold = True
        btn.PrintObject = False
        On Error Resume Next
        btn.Locked = True
        btn.Placement = xlFreeFloating
        On Error GoTo 0
    End If
    On Error GoTo 0
End Sub

Private Sub GetButtonColors(ByVal styleName As String, ByRef fillColor As Long, ByRef lineColor As Long, ByRef fontColor As Long)
    fontColor = vbWhite
    Select Case LCase$(styleName)
        Case "hero", "primary"
            fillColor = ThemeColor("blue")
            lineColor = ThemeColor("blue")
        Case "accent"
            fillColor = ThemeColor("teal")
            lineColor = ThemeColor("teal")
        Case "export"
            fillColor = ThemeColor("purple")
            lineColor = ThemeColor("purple")
        Case "danger"
            fillColor = ThemeColor("red")
            lineColor = ThemeColor("red")
        Case "neutral", "tool", "soft"
            fillColor = ThemeColor("locked")
            lineColor = ThemeColor("border")
            fontColor = ThemeColor("text")
        Case Else
            fillColor = ThemeColor("blue")
            lineColor = ThemeColor("blue")
    End Select
End Sub

Public Sub AddConfigButton(ByVal ws As Worksheet, ByVal cellAddress As String, ByVal caption As String, ByVal macroName As String)
    Dim a As Range
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    Set a = ws.Range(cellAddress)
    On Error GoTo 0
    If a Is Nothing Then Exit Sub
    AddUIButton ws, a.Left, a.Top, 150, 28, caption, macroName, "tool"
End Sub

Public Sub BuildInputHelpCards(ByVal ws As Worksheet)
    '右上メニューの下に装飾や長文を置かない。入力欄へ自然に視線が落ちる余白にする。
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    ws.Range("M14:T14").UnMerge
    ws.Range("M14:T14").ClearContents
    ws.Range("M14:T14").Interior.Color = ThemeColor("canvas")
    ws.Range("M14:T14").Borders.LineStyle = xlNone
    ws.Rows(14).RowHeight = 22
    On Error GoTo 0
End Sub

Public Sub RefreshButtonActions()
    'SaveAs後にブック名が変わっても、図形ボタンの参照先を現在のThisWorkbookへ張り直す。
    Dim ws As Worksheet
    Dim shp As Shape
    Dim macroName As String
    On Error Resume Next
    For Each ws In ThisWorkbook.Worksheets
        For Each shp In ws.Shapes
            If Left$(shp.Name, Len(UI_PREFIX & "btn_")) = UI_PREFIX & "btn_" Then
                macroName = shp.AlternativeText
                If Len(macroName) > 0 Then shp.OnAction = MacroRef(macroName)
            End If
        Next shp
    Next ws
    On Error GoTo 0
End Sub

Public Sub FormatHeader(ByVal rng As Range, Optional ByVal fillColor As Long = 0)
    ThemeApplyHeader rng, fillColor
End Sub

Public Sub FormatOutputHeader(ByVal rng As Range)
    ThemeApplyTableHeader rng, True
End Sub

Attribute VB_Name = "modBuildOutputs"
Option Explicit

Public Sub BuildAllOutputSheets()
    If Not RequireToolReady() Then Exit Sub
    On Error GoTo EH
    AppBegin "一括作成中..."
    BuildCashOperationSheetCore False
    BuildBalanceTransitionSheetCore False
    BuildShopConversionTargetSheetCore False
    If SheetExists(SH_OUTPUT_TX) Then ThisWorkbook.Worksheets(SH_OUTPUT_TX).Visible = xlSheetVisible
    If SheetExists(SH_OUTPUT_BAL) Then ThisWorkbook.Worksheets(SH_OUTPUT_BAL).Visible = xlSheetVisible
    If SheetExists(SH_SHOP_TARGET) Then ThisWorkbook.Worksheets(SH_SHOP_TARGET).Visible = xlSheetVisible
    HideDailySheets False
    If SheetExists(SH_SHOP_TARGET) Then ThisWorkbook.Worksheets(SH_SHOP_TARGET).Activate
    AppEnd
    MsgBox "資金操作表、残高推移表、取扱店変換対象を一括作成しました。" & vbCrLf & _
           "取扱店反映後も人物ID・口座ID・取引IDを保持します。", vbInformation
    Exit Sub
EH:
    AppEnd
    MsgBox "一括作成中にエラーが発生しました。" & vbCrLf & "Err " & Err.Number & ": " & Err.Description, vbExclamation
End Sub

Public Sub BuildCashOperationSheet()
    If Not RequireToolReady() Then Exit Sub
    On Error GoTo EH
    AppBegin "資金操作表作成中..."
    BuildCashOperationSheetCore True
    BuildShopConversionTargetSheetCore False
    AppEnd
    MsgBox "資金操作表を作成しました。", vbInformation
    Exit Sub
EH:
    AppEnd
    MsgBox "資金操作表作成中にエラーが発生しました。" & vbCrLf & "Err " & Err.Number & ": " & Err.Description, vbExclamation
End Sub

Public Sub BuildCashOperationSheetCore(ByVal activateAfter As Boolean)
    Dim wsSrc As Worksheet, wsOut As Worksheet
    Dim lastR As Long, r As Long, outR As Long
    Dim inheritanceDate As Variant
    Set wsSrc = GetSheet(SH_WORK_TX)
    Set wsOut = GetSheet(SH_OUTPUT_TX)
    wsOut.Visible = xlSheetVisible
    On Error Resume Next
    wsOut.Unprotect Password:=TOOL_PASSWORD
    On Error GoTo 0
    DeleteToolShapes wsOut, True
    wsOut.Cells.Clear
    wsOut.Cells.Interior.Color = vbWhite
    wsOut.Cells.Font.Color = ThemeColor("text")
    SetRowValues wsOut.Range("A1"), Array("銀行名", "支店名", "氏名", "科目", "口座番号", "日付", "時刻", "出金", "入金", "取扱店", "機番", "摘要欄", "その他", "人物ID", "口座ID", "取引ID", "行種別", "取扱店確定値", "データ状態")
    FormatOutputHeader wsOut.Range("A1:S1")
    outR = 2
    inheritanceDate = GetCfgDateValue(ROW_CFG_INHERITANCE_DATE)
    If ShowInheritanceStartRow() And IsDate(inheritanceDate) Then
        wsOut.Cells(outR, OUT_COL_DATE).Value = CDate(inheritanceDate)
        wsOut.Cells(outR, OUT_COL_TEKIYO).Value = "相続開始日"
        wsOut.Cells(outR, OUT_COL_ROW_KIND).Value = ROW_KIND_INHERITANCE
        wsOut.Cells(outR, OUT_COL_DATA_STATUS).Value = DATA_STATUS_ACTIVE
        outR = outR + 1
    End If
    lastR = LastRow(wsSrc, 1)
    If lastR >= 2 Then
        For r = 2 To lastR
            If ShouldOutputCashOperationWorkRow(wsSrc, r) Then
                CopyWorkTxRowToCashOperation wsSrc, r, wsOut, outR
                outR = outR + 1
            End If
        Next r
    End If
    If outR > 2 Then
        SortCashOperation wsOut
        FillBlankShopWithBranch wsOut
        NormalizeOutputShopFinal wsOut
        FormatCashOperationRows wsOut
    End If
    FormatOutputSheetBase wsOut, "A:S"
    FormatCashOperationOutputLayout wsOut
    wsOut.Columns("N:S").Hidden = True
    SafeFreezeOutputHeader wsOut
    ProtectReadOnlyOutputSheet wsOut
    If activateAfter Then wsOut.Activate: wsOut.Range("A1").Select
End Sub

Private Function ShouldOutputCashOperationWorkRow(ByVal wsSrc As Worksheet, ByVal r As Long) As Boolean
    Dim rowKind As String, tekiyoText As String
    rowKind = CellText(wsSrc.Cells(r, WORK_TX_COL_ROW_KIND).Value)
    Select Case rowKind
        Case ROW_KIND_TRANSACTION
            ShouldOutputCashOperationWorkRow = True
        Case ROW_KIND_OPEN
            ShouldOutputCashOperationWorkRow = ShowOpenDateRow()
        Case ROW_KIND_CLOSE
            ShouldOutputCashOperationWorkRow = ShowCloseDateRow()
        Case ROW_KIND_BALANCE
            ShouldOutputCashOperationWorkRow = ShowBalanceRowsInCashOperation()
        Case Else
            tekiyoText = CellText(wsSrc.Cells(r, OUT_COL_TEKIYO).Value)
            If tekiyoText = "口座開設日" Then
                ShouldOutputCashOperationWorkRow = ShowOpenDateRow()
            ElseIf tekiyoText = "口座解約日" Then
                ShouldOutputCashOperationWorkRow = ShowCloseDateRow()
            ElseIf InStr(tekiyoText, "残高") > 0 Then
                ShouldOutputCashOperationWorkRow = ShowBalanceRowsInCashOperation()
            Else
                ShouldOutputCashOperationWorkRow = True
            End If
    End Select
End Function

Private Sub CopyWorkTxRowToCashOperation(ByVal wsSrc As Worksheet, ByVal srcRow As Long, ByVal wsOut As Worksheet, ByVal outRow As Long)
    wsOut.Range(wsOut.Cells(outRow, 1), wsOut.Cells(outRow, 13)).Value = wsSrc.Range(wsSrc.Cells(srcRow, 1), wsSrc.Cells(srcRow, 13)).Value
    wsOut.Cells(outRow, OUT_COL_PERSON_ID).Value = wsSrc.Cells(srcRow, WORK_TX_COL_PERSON_ID).Value
    wsOut.Cells(outRow, OUT_COL_ACCOUNT_ID).Value = wsSrc.Cells(srcRow, WORK_TX_COL_ACCOUNT_ID).Value
    wsOut.Cells(outRow, OUT_COL_TRANSACTION_ID).Value = wsSrc.Cells(srcRow, WORK_TX_COL_TRANSACTION_ID).Value
    wsOut.Cells(outRow, OUT_COL_ROW_KIND).Value = wsSrc.Cells(srcRow, WORK_TX_COL_ROW_KIND).Value
    wsOut.Cells(outRow, OUT_COL_SHOP_FINAL).Value = wsSrc.Cells(srcRow, WORK_TX_COL_SHOP_FINAL).Value
    wsOut.Cells(outRow, OUT_COL_DATA_STATUS).Value = wsSrc.Cells(srcRow, WORK_TX_COL_DATA_STATUS).Value
End Sub

Public Sub SortCashOperation(ByVal ws As Worksheet)
    Dim lastR As Long, helperCol As Long, r As Long
    If ws Is Nothing Then Exit Sub
    lastR = LastRow(ws, OUT_COL_DATE)
    If lastR < 3 Then Exit Sub
    helperCol = LastUsedColumnPublic(ws) + 1
    ws.Cells(1, helperCol).Value = "日付順"
    ws.Cells(1, helperCol + 1).Value = "行種別順"
    ws.Cells(1, helperCol + 2).Value = "時刻順"
    ws.Cells(1, helperCol + 3).Value = "入力順"
    ws.Range(ws.Cells(2, helperCol), ws.Cells(lastR, helperCol + 3)).FormulaR1C1 = ""
    For r = 2 To lastR
        ws.Cells(r, helperCol).Value = CashOperationDateSortKey(ws.Cells(r, OUT_COL_DATE).Value)
        ws.Cells(r, helperCol + 1).Value = CashOperationRowKindSortKey(CellText(ws.Cells(r, OUT_COL_ROW_KIND).Value), ws.Cells(r, OUT_COL_TIME).Value)
        ws.Cells(r, helperCol + 2).Value = CashOperationTimeSortKey(ws.Cells(r, OUT_COL_TIME).Value)
        ' 出力前の行順を入力順として保持する。日付・時刻が同じ場合は人間が入力した順を壊さない。
        ws.Cells(r, helperCol + 3).Value = r
    Next r
    With ws.Sort
        .SortFields.Clear
        .SortFields.Add Key:=ws.Range(ws.Cells(2, helperCol), ws.Cells(lastR, helperCol)), SortOn:=xlSortOnValues, Order:=xlAscending, DataOption:=xlSortNormal
        .SortFields.Add Key:=ws.Range(ws.Cells(2, helperCol + 1), ws.Cells(lastR, helperCol + 1)), SortOn:=xlSortOnValues, Order:=xlAscending, DataOption:=xlSortNormal
        .SortFields.Add Key:=ws.Range(ws.Cells(2, helperCol + 2), ws.Cells(lastR, helperCol + 2)), SortOn:=xlSortOnValues, Order:=xlAscending, DataOption:=xlSortNormal
        .SortFields.Add Key:=ws.Range(ws.Cells(2, helperCol + 3), ws.Cells(lastR, helperCol + 3)), SortOn:=xlSortOnValues, Order:=xlAscending, DataOption:=xlSortNormal
        .SetRange ws.Range(ws.Cells(1, 1), ws.Cells(lastR, helperCol + 3))
        .Header = xlYes
        .Apply
    End With
    ws.Range(ws.Cells(1, helperCol), ws.Cells(lastR, helperCol + 3)).Delete Shift:=xlToLeft
    ws.Columns("N:S").Hidden = True
End Sub

Private Function CashOperationDateSortKey(ByVal valueText As Variant) As Double
    If IsDate(valueText) Then
        CashOperationDateSortKey = CDbl(DateValue(CDate(valueText)))
    Else
        CashOperationDateSortKey = 9999999#
    End If
End Function

Private Function CashOperationRowKindSortKey(ByVal rowKind As String, ByVal timeValue As Variant) As Double
    Select Case rowKind
        Case ROW_KIND_INHERITANCE, ROW_KIND_OPEN
            CashOperationRowKindSortKey = 0
        Case ROW_KIND_TRANSACTION
            If CashOperationHasTime(timeValue) Then
                CashOperationRowKindSortKey = 1
            Else
                CashOperationRowKindSortKey = 2
            End If
        Case ROW_KIND_BALANCE, ROW_KIND_CLOSE
            CashOperationRowKindSortKey = 3
        Case Else
            CashOperationRowKindSortKey = 2
    End Select
End Function

Private Function CashOperationTimeSortKey(ByVal valueText As Variant) As Double
    Dim t As Variant
    t = CashOperationTimeFractionOrEmpty(valueText)
    If IsEmpty(t) Then
        ' 時刻不明は同日内の時刻あり取引より後ろ。時刻不明同士は入力順で保持する。
        CashOperationTimeSortKey = 1#
    Else
        CashOperationTimeSortKey = CDbl(t)
    End If
End Function

Private Function CashOperationHasTime(ByVal valueText As Variant) As Boolean
    CashOperationHasTime = Not IsEmpty(CashOperationTimeFractionOrEmpty(valueText))
End Function

Private Function CashOperationTimeFractionOrEmpty(ByVal v As Variant) As Variant
    Dim s As String, x As Double, hh As Long, mm As Long
    On Error GoTo EH
    If IsError(v) Or IsNull(v) Or IsEmpty(v) Then Exit Function
    s = CellText(v)
    If Len(s) = 0 Then Exit Function
    s = Replace$(s, "：", ":")

    ' 数値入力は先に時刻として解釈する。1200 を日付シリアル扱いして 0:00 にしないため。
    If IsNumeric(s) Then
        x = CDbl(s)
        If x >= 0 And x < 1 Then
            CashOperationTimeFractionOrEmpty = x
            Exit Function
        End If
        If x >= 100 And x <= 2359 Then
            hh = CLng(Fix(x / 100#))
            mm = CLng(x - hh * 100)
            If hh >= 0 And hh < 24 And mm >= 0 And mm < 60 Then
                CashOperationTimeFractionOrEmpty = (hh * 60# + mm) / 1440#
                Exit Function
            End If
        End If
        If x >= 0 And x < 24 Then
            CashOperationTimeFractionOrEmpty = x / 24#
            Exit Function
        End If
    End If

    If InStr(1, s, ":", vbTextCompare) > 0 Then
        x = CDbl(CDate(s)) - Int(CDbl(CDate(s)))
        CashOperationTimeFractionOrEmpty = x
        Exit Function
    End If

    If IsDate(v) Then
        x = CDbl(CDate(v)) - Int(CDbl(CDate(v)))
        CashOperationTimeFractionOrEmpty = x
        Exit Function
    End If
    Exit Function
EH:
    CashOperationTimeFractionOrEmpty = Empty
End Function

Private Sub FormatCashOperationRows(ByVal ws As Worksheet)
    Dim lastR As Long, r As Long
    If ws Is Nothing Then Exit Sub
    lastR = LastRow(ws, OUT_COL_DATE)
    If lastR < 2 Then Exit Sub
    ws.Range("A2:S" & CStr(lastR)).Borders.LineStyle = xlContinuous
    ws.Range("A2:S" & CStr(lastR)).Borders.Color = ThemeColor("border")
    ws.Columns("F:F").NumberFormatLocal = "yyyy/m/d"
    ws.Columns("G:G").NumberFormatLocal = "hh:mm"
    ws.Columns("H:I").NumberFormatLocal = "#,##0"
    ws.Columns("E:E").NumberFormatLocal = "@"
    ws.Columns("J:K").NumberFormatLocal = "@"
    ws.Columns("M:M").NumberFormatLocal = "#,##0"
    ws.Columns("N:S").NumberFormatLocal = "@"
    For r = 2 To lastR
        If CellText(ws.Cells(r, OUT_COL_ROW_KIND).Value) <> ROW_KIND_TRANSACTION Then
            ws.Range("A" & r & ":S" & r).Interior.Color = ThemeColor("locked")
            ws.Range("A" & r & ":S" & r).Font.Color = ThemeColor("muted")
        End If
    Next r
End Sub

Public Sub BuildBalanceTransitionSheet()
    If Not RequireToolReady() Then Exit Sub
    On Error GoTo EH
    AppBegin "残高推移表作成中..."
    BuildBalanceTransitionSheetCore True
    AppEnd
    MsgBox "残高推移表を作成しました。", vbInformation
    Exit Sub
EH:
    AppEnd
    MsgBox "残高推移表作成中にエラーが発生しました。" & vbCrLf & "Err " & Err.Number & ": " & Err.Description, vbExclamation
End Sub

Public Sub BuildBalanceTransitionSheetCore(ByVal activateAfter As Boolean)
    Dim wsSrc As Worksheet, wsOut As Worksheet
    Dim labels As Collection, dates As Collection
    Dim personKeys As Collection, accountKeys As Collection
    Dim lastR As Long, r As Long, outR As Long, i As Long
    Dim personKey As Variant, accKey As Variant
    Dim firstR As Long, found As Boolean
    Dim totals() As Double, val As Variant
    Dim firstRowByAccount As Object, balanceValueByAccountDate As Object

    Set wsSrc = GetSheet(SH_WORK_BAL)
    Set wsOut = GetSheet(SH_OUTPUT_BAL)
    wsOut.Visible = xlSheetVisible
    On Error Resume Next
    wsOut.Unprotect Password:=TOOL_PASSWORD
    On Error GoTo 0
    wsOut.Cells.Clear
    wsOut.Cells.Interior.Color = vbWhite
    wsOut.Cells.Font.Color = ThemeColor("text")
    wsOut.Range("A1").Value = "残高推移表"
    wsOut.Range("A1").Font.Bold = True
    wsOut.Range("A1").Font.Size = 18
    wsOut.Range("A1").Font.Color = ThemeColor("text")

    BuildBalanceCollections labels, dates
    CapBalanceCollections labels, dates, BAL_MAX_LABELS

    Set personKeys = New Collection
    Set accountKeys = New Collection
    lastR = LastRow(wsSrc, 1)
    Set firstRowByAccount = CreateObject("Scripting.Dictionary")
    Set balanceValueByAccountDate = CreateObject("Scripting.Dictionary")
    For r = 2 To lastR
        If HasText(wsSrc.Cells(r, 1).Value) Then
            AddUniqueCollection personKeys, MakeBalancePersonKey(wsSrc, r)
            AddUniqueCollection accountKeys, MakeBalanceAccountKey(wsSrc, r)
            IndexBalanceWorkRow wsSrc, r, firstRowByAccount, balanceValueByAccountDate
        End If
    Next r

    outR = 3
    For Each personKey In personKeys
        wsOut.Cells(outR, 1).Value = "氏名: " & BalancePersonKeyDisplay(CStr(personKey))
        wsOut.Cells(outR, 1).Font.Bold = True
        wsOut.Cells(outR, 1).Font.Size = 14
        wsOut.Cells(outR, 1).Font.Color = ThemeColor("blue")
        outR = outR + 1

        SetRowValues wsOut.Cells(outR, 1), Array("銀行名", "支店名", "科目", "口座番号", "口座開設日", "口座解約日")
        For i = 1 To labels.Count
            wsOut.Cells(outR, 6 + i).Value = labels(i)
        Next i
        wsOut.Cells(outR, 7 + labels.Count).Value = "その他"
        FormatOutputHeader wsOut.Range(wsOut.Cells(outR, 1), wsOut.Cells(outR, 7 + labels.Count))
        ReDim totals(1 To labels.Count)
        outR = outR + 1

        For Each accKey In accountKeys
            If BalanceKeyPart(CStr(accKey), 0) = CStr(personKey) Then
                firstR = FirstBalanceRowFromIndex(firstRowByAccount, CStr(accKey))
                If firstR > 0 Then
                    wsOut.Cells(outR, 1).Value = wsSrc.Cells(firstR, 2).Value
                    wsOut.Cells(outR, 2).Value = wsSrc.Cells(firstR, 3).Value
                    wsOut.Cells(outR, 3).Value = wsSrc.Cells(firstR, 4).Value
                    wsOut.Cells(outR, 4).Value = wsSrc.Cells(firstR, 5).Value
                    wsOut.Cells(outR, 5).Value = wsSrc.Cells(firstR, 6).Value
                    wsOut.Cells(outR, 6).Value = wsSrc.Cells(firstR, 7).Value
                    For i = 1 To labels.Count
                        If Not AccountExistsAtDate(CDate(dates(i)), wsSrc.Cells(firstR, 6).Value, wsSrc.Cells(firstR, 7).Value) Then
                            '開設日前・解約日後の時点は、口座が存在しないため「-」で明示する。
                            wsOut.Cells(outR, 6 + i).Value = "-"
                        Else
                            val = FindBalanceValueFast(balanceValueByAccountDate, CStr(accKey), CDate(dates(i)), found)
                            If found Then
                                wsOut.Cells(outR, 6 + i).Value = val
                                If IsNumeric(val) Then totals(i) = totals(i) + CDbl(val)
                            End If
                        End If
                    Next i
                    wsOut.Cells(outR, 7 + labels.Count).Value = wsSrc.Cells(firstR, 11).Value
                    outR = outR + 1
                End If
            End If
        Next accKey

        wsOut.Cells(outR, 1).Value = "合計"
        wsOut.Cells(outR, 1).Font.Bold = True
        For i = 1 To labels.Count
            wsOut.Cells(outR, 6 + i).Value = totals(i)
        Next i
        wsOut.Range(wsOut.Cells(outR, 1), wsOut.Cells(outR, 7 + labels.Count)).Interior.Color = ThemeColor("success-soft")
        wsOut.Range(wsOut.Cells(outR, 1), wsOut.Cells(outR, 7 + labels.Count)).Font.Color = ThemeColor("success-text")
        outR = outR + 1

        wsOut.Cells(outR, 1).Value = "前年比"
        For i = 2 To labels.Count
            wsOut.Cells(outR, 6 + i).Value = totals(i) - totals(i - 1)
        Next i
        wsOut.Range(wsOut.Cells(outR, 1), wsOut.Cells(outR, 7 + labels.Count)).Interior.Color = ThemeColor("locked")
        wsOut.Range(wsOut.Cells(outR, 1), wsOut.Cells(outR, 7 + labels.Count)).Font.Color = ThemeColor("text")
        outR = outR + 2
    Next personKey

    FormatOutputSheetBase wsOut, "A:Z"
    wsOut.Cells.NumberFormatLocal = "#,##0"
    wsOut.Columns("A:F").NumberFormatLocal = "@"
    wsOut.Columns("E:F").NumberFormatLocal = "yyyy/m/d"
    FormatBalanceTransitionOutputLayout wsOut
    ProtectReadOnlyOutputSheet wsOut
    If activateAfter Then wsOut.Activate
End Sub

Private Sub IndexBalanceWorkRow(ByVal ws As Worksheet, ByVal r As Long, ByVal firstRowByAccount As Object, ByVal balanceValueByAccountDate As Object)
    Dim accKey As String, dateKey As String
    accKey = MakeBalanceAccountKey(ws, r)
    If Len(accKey) = 0 Then Exit Sub
    If Not firstRowByAccount.Exists(accKey) Then firstRowByAccount.Add accKey, r
    If IsDate(ws.Cells(r, 8).Value) Then
        dateKey = BalanceDateLookupKey(accKey, CDate(ws.Cells(r, 8).Value))
        balanceValueByAccountDate(dateKey) = ws.Cells(r, 10).Value
    End If
End Sub

Private Function FirstBalanceRowFromIndex(ByVal firstRowByAccount As Object, ByVal keyText As String) As Long
    If Not firstRowByAccount Is Nothing Then
        If firstRowByAccount.Exists(keyText) Then FirstBalanceRowFromIndex = CLng(firstRowByAccount(keyText))
    End If
End Function

Private Function FindBalanceValueFast(ByVal balanceValueByAccountDate As Object, ByVal keyText As String, ByVal targetDate As Date, ByRef found As Boolean) As Variant
    Dim k As String
    found = False
    k = BalanceDateLookupKey(keyText, targetDate)
    If Not balanceValueByAccountDate Is Nothing Then
        If balanceValueByAccountDate.Exists(k) Then
            FindBalanceValueFast = balanceValueByAccountDate(k)
            found = True
            Exit Function
        End If
    End If
    FindBalanceValueFast = Empty
End Function

Private Function BalanceDateLookupKey(ByVal accountKey As String, ByVal targetDate As Date) As String
    BalanceDateLookupKey = accountKey & Chr$(29) & Format$(DateValue(targetDate), "yyyymmdd")
End Function

Private Sub AddUniqueCollection(ByVal col As Collection, ByVal key As String)
    On Error Resume Next
    col.Add key, key
    On Error GoTo 0
End Sub

Private Function MakeBalancePersonKey(ByVal ws As Worksheet, ByVal r As Long) As String
    '人物単位の見出しに使うキー。続柄表示OFF時は氏名だけでまとめる。
    MakeBalancePersonKey = CellText(ws.Cells(r, 1).Value) & Chr$(31) & _
                           IIf(UseRelationshipDisplay(), CellText(ws.Cells(r, WORK_BAL_COL_RELATIONSHIP).Value), "")
End Function

Private Function BalancePersonKeyDisplay(ByVal personKey As String) As String
    Dim parts As Variant
    parts = Split(personKey, Chr$(31))
    If UBound(parts) >= 1 Then
        BalancePersonKeyDisplay = DisplayPersonWithRelationship(CStr(parts(0)), CStr(parts(1)))
    Else
        BalancePersonKeyDisplay = personKey
    End If
End Function

Private Function MakeBalanceAccountKey(ByVal ws As Worksheet, ByVal r As Long) As String
    MakeBalanceAccountKey = MakeBalancePersonKey(ws, r) & Chr$(30) & _
                            CellText(ws.Cells(r, 2).Value) & Chr$(30) & _
                            CellText(ws.Cells(r, 3).Value) & Chr$(30) & _
                            CellText(ws.Cells(r, 4).Value) & Chr$(30) & _
                            CellText(ws.Cells(r, 5).Value)
End Function

Private Function BalanceKeyPart(ByVal keyText As String, ByVal indexNo As Long) As String
    Dim parts As Variant
    parts = Split(keyText, Chr$(30))
    If indexNo >= LBound(parts) And indexNo <= UBound(parts) Then BalanceKeyPart = CStr(parts(indexNo))
End Function

Private Function BalanceRowMatchesKey(ByVal ws As Worksheet, ByVal r As Long, ByVal keyText As String) As Boolean
    BalanceRowMatchesKey = (MakeBalanceAccountKey(ws, r) = keyText)
End Function

Private Sub FormatOutputSheetBase(ByVal ws As Worksheet, ByVal columnsAddress As String)
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    ws.Cells.Font.Name = THEME_FONT
    ws.Cells.Font.Size = 14
    AutoFitSheetSmart ws, columnsAddress, 8, 36
    ws.Rows(1).RowHeight = 34
    On Error GoTo 0
End Sub

Attribute VB_Name = "modSetup"
Option Explicit

Public Sub SetupWorkbook()
    On Error GoTo EH
    AppBegin
    BuildAllBaseSheets
    BuildMenuSheet
    BuildConfigSheet
    BuildPersonInputSheet
    BuildConfirmSheet
    BuildCheckSheet
    BuildOutputSheets
    BuildWorkSheets
    InitIdManager
    RefreshCandidates
    ApplyValidations
    BeginDecedentEntry
    InitUsabilityControls
    ShowOnlyInputCore True
    MsgBox "初期設定が完了しました。通常は人物入力シートだけを使います。まず被相続人を登録してください。", vbInformation
CleanExit:
    AppEnd
    Exit Sub
EH:
    AppEnd
    MsgBox "SetupWorkbookでエラー: " & Err.Description, vbExclamation
End Sub

Private Sub BuildAllBaseSheets()
    Dim names As Variant, i As Long
    names = Array(SH_MENU, SH_CONFIG, SH_INPUT, SH_CONFIRM, SH_CHECK, SH_DIAGRAM, SH_ADDR_TABLE, SH_COHAB, SH_TIMELINE, SH_PERSON_LIST, SH_W_PERSON, SH_W_REL, SH_W_ADDR_CAND, SH_W_ADDR_HIST, SH_W_EVENT, SH_W_CAND, SH_W_ID, SH_W_LOG)
    For i = LBound(names) To UBound(names)
        EnsureSheet CStr(names(i)), IIf(Left$(CStr(names(i)), 2) = "W_" Or CStr(names(i)) = SH_W_ID, xlSheetVeryHidden, xlSheetVisible)
    Next i
End Sub

Private Sub BuildMenuSheet()
    Dim ws As Worksheet
    Set ws = EnsureSheet(SH_MENU, xlSheetHidden)
    ClearSheetAll ws
    ApplySheetCanvas ws
    ws.Range("B2:J2").Merge
    TitleBannerStyle ws.Range("B2:J2"), "人物住所時系列ツール"
    ws.Range("B4:J4").Merge
    ws.Range("B4").Value = "1案件1フォルダで使用します。人物・関係・住所を先に固め、後続の資金関係ツールへ共通データを渡します。"
    ws.Range("B4:J4").WrapText = True
    ws.Range("B6").Value = "操作"
    ws.Range("E6").Value = "状況"
    HeaderStyle ws.Range("B6:C6")
    HeaderStyle ws.Range("E6:J6")
    AddButton ws, "B8", "被相続人入力へ", "BeginDecedentEntry", 150, 30
    AddButton ws, "B10", "人物入力へ", "GoPersonInput", 150, 30
    AddButton ws, "B12", "確認一覧更新", "BuildConfirmList", 150, 30
    AddButton ws, "B14", "整合チェック", "RunChecks", 150, 30
    AddButton ws, "B16", "一括作成", "BuildAllOutputs", 150, 30
    AddButton ws, "B18", "共通データ保存", "SaveCommonData", 150, 30
    AddButton ws, "B20", "人物情報整理資料出力", "ExportPersonInfoWorkbook", 150, 30

    ws.Range("E8").Value = "登録人物数"
    ws.Range("F8").Formula = "=COUNTA('" & SH_W_PERSON & "'!A:A)-1"
    ws.Range("E9").Value = "住所履歴件数"
    ws.Range("F9").Formula = "=COUNTA('" & SH_W_ADDR_HIST & "'!A:A)-1"
    ws.Range("E10").Value = "関係件数"
    ws.Range("F10").Formula = "=COUNTA('" & SH_W_REL & "'!A:A)-1"
    ws.Range("E11").Value = "相続開始日"
    ws.Range("F11").Formula = "='" & SH_CONFIG & "'!" & CELL_CONFIG_INHERIT_DATE
    ws.Range("E12").Value = "出力フォルダ"
    ws.Range("F12").Value = "このブックと同じフォルダ\出力"
    ws.Range("E8:E12").Font.Bold = True
    InputStyle ws.Range("F8:J12")
    ws.Columns("B:J").ColumnWidth = 16
    ws.Rows("2:22").RowHeight = 24
End Sub

Private Sub BuildConfigSheet()
    Dim ws As Worksheet
    Set ws = EnsureSheet(SH_CONFIG, xlSheetHidden)
    ClearSheetAll ws
    ApplySheetCanvas ws
    ws.Range("B2:F2").Merge
    TitleBannerStyle ws.Range("B2:F2"), "設定"
    SetRowValues ws.Range("B4"), Array("作成基準日", Date, "住所終了日補完・時系列の最終年に使います。")
    SetRowValues ws.Range("B5"), Array("相続開始日", "", "被相続人の死亡日から自動設定されます。")
    SetRowValues ws.Range("B6"), Array("出力モード", "標準", "詳細・標準・簡易。相続関係整理図の情報量を調整します。")
    SetRowValues ws.Range("B8"), Array("運用メモ", "人物入力画面で人物・関係・住所をまとめて登録します。", "")
    AddButton ws, "G4", "入力画面へ戻る", "ShowOnlyInput", 120, 28
    ws.Range("B4:B6").Font.Bold = True
    InputStyle ws.Range("C4:C6")
    ws.Range("C4:C5").NumberFormatLocal = "yyyy/m/d"
    ws.Range("D4:D8").WrapText = True
    ws.Columns("B:B").ColumnWidth = 18
    ws.Columns("C:C").ColumnWidth = 18
    ws.Columns("D:F").ColumnWidth = 30
End Sub

Private Sub BuildPersonInputSheet()
    Dim ws As Worksheet
    Set ws = EnsureSheet(SH_INPUT, xlSheetVisible)
    ClearSheetAll ws
    ApplySheetCanvas ws

    ws.Range("B2:J2").Merge
    TitleBannerStyle ws.Range("B2:J2"), "人物入力"
    ws.Range("B3:J3").Merge
    ws.Range("B3").Value = "通常表示はこのシートだけです。被相続人から始め、基準人物との関係で人物・住所・日付を再利用して登録します。"
    ws.Range("B3").WrapText = True
    ThemeApplyHintRange ws.Range("B3:J3"), "info-very-soft"
    ws.Range("B4:J4").Merge
    ws.Range("B4").Value = "入力の流れ：①被相続人登録 → ②関係者追加 → ③住所同時登録 → ④一括作成 → ⑤共通データ保存・後続ツール連携"
    FlowBarStyle ws.Range("B4:J4")

    ws.Range("B5:D5").Merge: SectionStyle ws.Range("B5:D5"), "基準人物カード"
    SetRowValues ws.Range("B6"), Array("基準人物候補", "")
    SetRowValues ws.Range("B7"), Array("基準人物ID", "")
    SetRowValues ws.Range("B8"), Array("氏名", "")
    SetRowValues ws.Range("B9"), Array("続柄", "")
    SetRowValues ws.Range("B10"), Array("代表住所", "")
    InputStyle ws.Range("C6:C6")
    LockedStyle ws.Range("C7:C10")
    AddButton ws, "E6", "基準人物読込", "LoadBaseFromSelection", 115, 26
    AddButton ws, "E8", "被相続人に戻る", "SetDecedentAsBase", 115, 26

    ws.Range("G5:J5").Merge: SectionStyle ws.Range("G5:J5"), "操作"
    AddButton ws, "G6", "設定", "ShowSettings", 95, 26
    AddButton ws, "H6", "入力だけ表示", "ShowOnlyInput", 105, 26
    AddButton ws, "G8", "共通データ保存", "SaveCommonData", 120, 26
    AddButton ws, "H8", "資料出力", "ExportPersonInfoWorkbook", 105, 26
    AddButton ws, "G10", "整合チェック", "RunChecksAndShow", 120, 26
    AddButton ws, "H10", "一括作成", "BuildAllOutputs", 105, 26

    ws.Range("B12:J12").Merge
    SectionStyle ws.Range("B12:J12"), "追加する関係者：関係を選ぶと姓・続柄・住所候補を自動表示"
    AddButton ws, "B13", "被相続人", "BeginDecedentEntry", 88, 26
    AddButton ws, "C13", "配偶者", "BeginAddSpouse", 88, 26
    AddButton ws, "D13", "父", "BeginAddFather", 88, 26
    AddButton ws, "E13", "母", "BeginAddMother", 88, 26
    AddButton ws, "F13", "子", "BeginAddChild", 88, 26
    AddButton ws, "G13", "兄弟姉妹", "BeginAddSibling", 88, 26
    AddButton ws, "H13", "孫", "BeginAddGrandchild", 88, 26
    AddButton ws, "I13", "その他", "BeginAddOther", 88, 26

    ws.Range("B16:D16").Merge: SectionStyle ws.Range("B16:D16"), "人物カード"
    SetRowValues ws.Range("B17"), Array("人物ID", "")
    SetRowValues ws.Range("B18"), Array("入力モード", "")
    SetRowValues ws.Range("B20"), Array("自動姓", "")
    SetRowValues ws.Range("B21"), Array("現在姓", "")
    SetRowValues ws.Range("B22"), Array("名", "")
    SetRowValues ws.Range("B23"), Array("旧姓", "")
    SetRowValues ws.Range("B24"), Array("性別", "")
    SetRowValues ws.Range("B25"), Array("続柄", "")
    SetRowValues ws.Range("B26"), Array("生年月日", "")
    SetRowValues ws.Range("B27"), Array("死亡日", "")
    SetRowValues ws.Range("B28"), Array("職業", "")
    SetRowValues ws.Range("B29"), Array("婚姻日", "")
    SetRowValues ws.Range("B30"), Array("離婚日", "")
    SetRowValues ws.Range("B31"), Array("備考", "")
    SetRowValues ws.Range("B32"), Array("図表示", SHOW_YES)
    LockedStyle ws.Range("C17:C20")
    InputStyle ws.Range("C21:C32")
    ws.Range("C23").Interior.Color = ThemeColor("warning-soft")
    ws.Range("C26:C27,C29:C30").NumberFormatLocal = "yyyy/m/d"

    ws.Range("E16:J16").Merge: SectionStyle ws.Range("E16:J16"), "住所カード：人物登録と同時に住所も登録"
    SetRowValues ws.Range("E17"), Array("住所候補", "")
    SetRowValues ws.Range("E18"), Array("住所", "")
    SetRowValues ws.Range("E19"), Array("住所キー", "")
    SetRowValues ws.Range("E20"), Array("住所区分", "居住地")
    SetRowValues ws.Range("E21"), Array("開始日", "")
    SetRowValues ws.Range("E22"), Array("終了日", "")
    SetRowValues ws.Range("E23"), Array("根拠", "")
    SetRowValues ws.Range("E24"), Array("住所備考", "")
    InputStyle ws.Range("F17:F24")
    ws.Range("F21:F22").NumberFormatLocal = "yyyy/m/d"
    AddButton ws, "G17", "候補住所を反映", "ApplySelectedAddressCandidate", 125, 26
    AddButton ws, "G18", "基準人物住所コピー", "CopyBaseCurrentAddress", 125, 26
    AddButton ws, "G19", "前回住所コピー", "CopyLastAddress", 125, 26
    AddButton ws, "G20", "住所キー作成", "MakeAddressKeyFromInput", 125, 26
    AddButton ws, "G21", "婚姻日を開始日に", "UseMarriageDateAsAddressStart", 125, 26
    AddButton ws, "G22", "生年月日を開始日に", "UseBirthDateAsAddressStart", 125, 26
    AddButton ws, "G23", "死亡日を終了日に", "UseDeathDateAsAddressEnd", 125, 26
    AddButton ws, "G24", "離婚日を終了日に", "UseDivorceDateAsAddressEnd", 125, 26

    AddButton ws, "B35", "登録・更新", "RegisterInputPerson", 120, 30
    AddButton ws, "D35", "入力クリア", "ClearPersonInput", 92, 30
    AddButton ws, "G35", "一括作成", "BuildAllOutputs", 120, 30
    AddButton ws, "I35", "共通データ保存", "SaveCommonData", 120, 30

    ws.Range("B38:J44").Merge
    ws.Range("B38").Value = "操作ナビ：最初は被相続人を登録してください。登録後は、配偶者、父、母、子を関係ボタンから順に追加します。住所は人物登録時に同時登録し、同じ住所は候補やコピーを使って二度打ちしないでください。"
    ws.Range("B38:J44").WrapText = True
    ws.Range("B38:J44").Font.Color = ThemeColor("text")
    LockedStyle ws.Range("B38:J44")

    ws.Columns("B:B").ColumnWidth = 15
    ws.Columns("C:C").ColumnWidth = 24
    ws.Columns("D:D").ColumnWidth = 3
    ws.Columns("E:E").ColumnWidth = 15
    ws.Columns("F:F").ColumnWidth = 38
    ws.Columns("G:J").ColumnWidth = 15
    ws.Rows("2:44").RowHeight = 23
    ws.Rows("38:44").RowHeight = 20
    PanelBorderStyle ws.Range("B5:D10")
    PanelBorderStyle ws.Range("G5:J10")
    PanelBorderStyle ws.Range("B16:D32")
    PanelBorderStyle ws.Range("E16:J24")
    InputStyle ws.Range("C6:C6")
    LockedStyle ws.Range("C7:C10")
    LockedStyle ws.Range("C17:C20")
    InputStyle ws.Range("C21:C32")
    InputStyle ws.Range("F17:F24")
    ws.Range("C23").Interior.Color = ThemeColor("warning-soft")
    ws.Range("B5:J44").Borders.Color = ThemeColor("border-soft")

    ws.Range("B46:J47").Merge
    ws.Range("B46").Value = "操作制御：白い入力欄だけ選択できます。図形・ボタン・出力帳票は保護し、Tab/Shift+Tabで自然な順に移動します。住所・旧姓・日付は候補から再利用できます。"
    ws.Range("B46:J47").WrapText = True
    ws.Range("B46:J47").Font.Color = ThemeColor("muted-strong")
    LockedStyle ws.Range("B46:J47")
    ws.Rows("46:47").RowHeight = 21
End Sub

Private Sub BuildConfirmSheet()
    Dim ws As Worksheet
    Set ws = EnsureSheet(SH_CONFIRM, xlSheetHidden)
    ClearSheetAll ws
    ws.Range("A1:J1").Merge
    SectionStyle ws.Range("A1:J1"), "確認一覧"
    SetRowValues ws.Range("A3"), Array("表示順", "人物ID", "人物区分", "続柄", "氏名", "旧姓", "生年月日", "死亡日", "代表住所", "備考")
    HeaderStyle ws.Range("A3:J3")
    ws.Columns("A:J").ColumnWidth = 16
    ws.Columns("E:E").ColumnWidth = 28
    ws.Columns("I:I").ColumnWidth = 36
    AddButton ws, "L3", "更新", "BuildConfirmList", 100, 26
    AddButton ws, "L5", "入力へ戻る", "ShowOnlyInput", 100, 26
End Sub

Private Sub BuildCheckSheet()
    Dim ws As Worksheet
    Set ws = EnsureSheet(SH_CHECK, xlSheetHidden)
    ClearSheetAll ws
    ws.Range("A1:H1").Merge
    SectionStyle ws.Range("A1:H1"), "チェック結果"
    SetRowValues ws.Range("A3"), Array("区分", "内容", "人物ID", "氏名", "対象", "対応", "作成日時", "備考")
    HeaderStyle ws.Range("A3:H3")
    ws.Columns("A:H").ColumnWidth = 18
    ws.Columns("B:B").ColumnWidth = 38
    AddButton ws, "I3", "入力へ戻る", "ShowOnlyInput", 100, 26
End Sub

Private Sub BuildOutputSheets()
    Dim ws As Worksheet
    Set ws = EnsureSheet(SH_DIAGRAM, xlSheetHidden): ClearSheetAll ws
    Set ws = EnsureSheet(SH_ADDR_TABLE, xlSheetHidden): ClearSheetAll ws
    Set ws = EnsureSheet(SH_COHAB, xlSheetHidden): ClearSheetAll ws
    Set ws = EnsureSheet(SH_TIMELINE, xlSheetHidden): ClearSheetAll ws
    Set ws = EnsureSheet(SH_PERSON_LIST, xlSheetHidden): ClearSheetAll ws
End Sub

Private Sub BuildWorkSheets()
    Dim ws As Worksheet
    Set ws = EnsureSheet(SH_W_PERSON, xlSheetVeryHidden): ws.Cells.Clear
    SetRowValues ws.Range("A1"), Array("人物ID", "表示順", "人物区分", "現在姓", "名", "旧姓", "氏名表示", "姓入力区分", "姓継承元人物ID", "被相続人から見た続柄", "表示用続柄", "性別", "生年月日", "死亡日", "職業", "代表住所ID", "図表示", "備考", "データ状態", "作成日時", "更新日時")
    HeaderStyle ws.Range("A1:U1")

    Set ws = EnsureSheet(SH_W_REL, xlSheetVeryHidden): ws.Cells.Clear
    SetRowValues ws.Range("A1"), Array("関係ID", "基準人物ID", "相手人物ID", "関係種別", "関係表示", "婚姻日", "離婚日", "自動作成区分", "備考", "データ状態", "作成日時", "更新日時")
    HeaderStyle ws.Range("A1:L1")

    Set ws = EnsureSheet(SH_W_ADDR_CAND, xlSheetVeryHidden): ws.Cells.Clear
    SetRowValues ws.Range("A1"), Array("住所候補ID", "住所原文代表", "住所キー", "建物名等", "初回使用人物ID", "最終使用人物ID", "使用回数", "最終使用日時", "備考")
    HeaderStyle ws.Range("A1:I1")

    Set ws = EnsureSheet(SH_W_ADDR_HIST, xlSheetVeryHidden): ws.Cells.Clear
    SetRowValues ws.Range("A1"), Array("住所ID", "人物ID", "住所候補ID", "住所区分", "開始日", "終了日", "住所原文", "住所キー", "根拠", "コピー元人物ID", "コピー元住所ID", "備考", "データ状態", "作成日時", "更新日時")
    HeaderStyle ws.Range("A1:O1")

    Set ws = EnsureSheet(SH_W_EVENT, xlSheetVeryHidden): ws.Cells.Clear
    SetRowValues ws.Range("A1"), Array("イベントID", "人物ID", "日付", "年", "種別", "内容", "自動生成区分", "元データ種別", "元データID", "表示", "備考", "データ状態")
    HeaderStyle ws.Range("A1:L1")

    Set ws = EnsureSheet(SH_W_CAND, xlSheetVeryHidden): ws.Cells.Clear
    SetRowValues ws.Range("A1"), Array("姓候補", "住所候補表示", "住所候補ID", "人物候補表示", "人物ID", "根拠候補", "職業候補", "続柄候補", "住所区分候補", "性別候補", "図表示候補", "婚姻日候補", "離婚日候補", "日付候補")
    HeaderStyle ws.Range("A1:N1")

    Set ws = EnsureSheet(SH_W_LOG, xlSheetVeryHidden): ws.Cells.Clear
    SetRowValues ws.Range("A1"), Array("日時", "処理", "内容")
    HeaderStyle ws.Range("A1:C1")
End Sub

Public Sub ApplyValidations()
    Dim ws As Worksheet
    Set ws = ThisWorkbook.Worksheets(SH_INPUT)
    On Error Resume Next
    ThisWorkbook.Names("lstPerson").Delete
    ThisWorkbook.Names("lstSurname").Delete
    ThisWorkbook.Names("lstAddress").Delete
    ThisWorkbook.Names("lstSource").Delete
    ThisWorkbook.Names("lstOccupation").Delete
    ThisWorkbook.Names("lstRelation").Delete
    ThisWorkbook.Names("lstAddressType").Delete
    ThisWorkbook.Names("lstGender").Delete
    ThisWorkbook.Names("lstShow").Delete
    ThisWorkbook.Names("lstMarriageDate").Delete
    ThisWorkbook.Names("lstDivorceDate").Delete
    ThisWorkbook.Names("lstDateCandidate").Delete
    On Error GoTo 0
    ThisWorkbook.Names.Add "lstPerson", "=" & QuoteSheet(SH_W_CAND) & "!$D$2:$D$300"
    ThisWorkbook.Names.Add "lstSurname", "=" & QuoteSheet(SH_W_CAND) & "!$A$2:$A$300"
    ThisWorkbook.Names.Add "lstAddress", "=" & QuoteSheet(SH_W_CAND) & "!$B$2:$B$300"
    ThisWorkbook.Names.Add "lstSource", "=" & QuoteSheet(SH_W_CAND) & "!$F$2:$F$100"
    ThisWorkbook.Names.Add "lstOccupation", "=" & QuoteSheet(SH_W_CAND) & "!$G$2:$G$100"
    ThisWorkbook.Names.Add "lstRelation", "=" & QuoteSheet(SH_W_CAND) & "!$H$2:$H$100"
    ThisWorkbook.Names.Add "lstAddressType", "=" & QuoteSheet(SH_W_CAND) & "!$I$2:$I$50"
    ThisWorkbook.Names.Add "lstGender", "=" & QuoteSheet(SH_W_CAND) & "!$J$2:$J$10"
    ThisWorkbook.Names.Add "lstShow", "=" & QuoteSheet(SH_W_CAND) & "!$K$2:$K$10"
    ThisWorkbook.Names.Add "lstMarriageDate", "=" & QuoteSheet(SH_W_CAND) & "!$L$2:$L$300"
    ThisWorkbook.Names.Add "lstDivorceDate", "=" & QuoteSheet(SH_W_CAND) & "!$M$2:$M$300"
    ThisWorkbook.Names.Add "lstDateCandidate", "=" & QuoteSheet(SH_W_CAND) & "!$N$2:$N$300"

    AddListValidation ws.Range(CELL_BASE_SELECT), "=lstPerson"
    AddListValidation ws.Range(CELL_SURNAME), "=lstSurname"
    AddListValidation ws.Range(CELL_FORMER_SURNAME), "=lstSurname"
    AddListValidation ws.Range(CELL_GENDER), "=lstGender"
    AddListValidation ws.Range(CELL_REL_TO_DECEDENT), "=lstRelation"
    AddListValidation ws.Range(CELL_OCCUPATION), "=lstOccupation"
    AddListValidation ws.Range(CELL_SHOW_DIAGRAM), "=lstShow"
    AddListValidation ws.Range(CELL_ADDR_CAND), "=lstAddress"
    AddListValidation ws.Range(CELL_ADDR_TYPE), "=lstAddressType"
    AddListValidation ws.Range(CELL_ADDR_SOURCE), "=lstSource"
    AddSoftListValidation ws.Range(CELL_MARRIAGE), "=lstMarriageDate"
    AddSoftListValidation ws.Range(CELL_DIVORCE), "=lstDivorceDate"
    AddSoftListValidation ws.Range(CELL_ADDR_START), "=lstDateCandidate"
    AddSoftListValidation ws.Range(CELL_ADDR_END), "=lstDateCandidate"
    ApplyInputUsability
End Sub

Private Sub AddListValidation(ByVal rng As Range, ByVal formula1 As String)
    On Error Resume Next
    rng.Validation.Delete
    rng.Validation.Add Type:=xlValidateList, AlertStyle:=xlValidAlertStop, Operator:=xlBetween, Formula1:=formula1
    rng.Validation.IgnoreBlank = True
    rng.Validation.InCellDropdown = True
    On Error GoTo 0
End Sub

Private Sub AddSoftListValidation(ByVal rng As Range, ByVal formula1 As String)
    On Error Resume Next
    rng.Validation.Delete
    rng.Validation.Add Type:=xlValidateList, AlertStyle:=xlValidAlertWarning, Operator:=xlBetween, Formula1:=formula1
    rng.Validation.IgnoreBlank = True
    rng.Validation.InCellDropdown = True
    rng.Validation.ErrorTitle = "候補外入力"
    rng.Validation.ErrorMessage = "候補にない日付でも入力できます。続行してください。"
    On Error GoTo 0
End Sub

Public Sub GoPersonInput()
    ThisWorkbook.Worksheets(SH_INPUT).Activate
End Sub

Attribute VB_Name = "modIdManager"
Option Explicit

Public Sub InitIdManager()
    Dim ws As Worksheet
    Set ws = EnsureSheet(SH_W_ID, xlSheetVeryHidden)
    ws.Cells.Clear
    SetRowValues ws.Range("A1"), Array("種別", "接頭辞", "次番号", "最終採番日時")
    SetRowValues ws.Range("A2"), Array("人物", "P", 1, "")
    SetRowValues ws.Range("A3"), Array("関係", "RL", 1, "")
    SetRowValues ws.Range("A4"), Array("住所候補", "AM", 1, "")
    SetRowValues ws.Range("A5"), Array("住所履歴", "AD", 1, "")
    SetRowValues ws.Range("A6"), Array("イベント", "EV", 1, "")
    HeaderStyle ws.Range("A1:D1")
End Sub

Public Function NextId(ByVal kind As String) As String
    Dim ws As Worksheet, r As Long, lastR As Long, prefix As String, nextNum As Long
    Set ws = EnsureSheet(SH_W_ID, xlSheetVeryHidden)
    lastR = LastRow(ws, 1)
    For r = 2 To lastR
        If CStr(ws.Cells(r, 1).Value) = kind Then
            prefix = CStr(ws.Cells(r, 2).Value)
            nextNum = CLng(ws.Cells(r, 3).Value)
            NextId = prefix & Format(nextNum, IIf(kind = "人物", "0000", "000000"))
            ws.Cells(r, 3).Value = nextNum + 1
            ws.Cells(r, 4).Value = Now
            Exit Function
        End If
    Next r
    Err.Raise 5, "NextId", "ID種別が見つかりません: " & kind
End Function

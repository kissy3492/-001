Attribute VB_Name = "modOutputs"
Option Explicit

Public Sub BuildAllOutputs()
    On Error GoTo EH
    AppBegin
    BuildConfirmList
    RunChecks
    GenerateEvents
    BuildRelationshipDiagram
    BuildAddressHistoryTable
    BuildCohabitationTable
    BuildTimelineTable
    BuildPersonList
    ApplyOutputUsability
    ShowOutputSheetsCore True
    MsgBox "人物情報系の帳票を一括作成しました。出力シートを表示しました。入力へ戻る場合は各シートのボタンを押してください。", vbInformation
CleanExit:
    AppEnd
    Exit Sub
EH:
    AppEnd
    MsgBox "一括作成でエラー: " & Err.Description, vbExclamation
End Sub

Public Sub BuildConfirmList()
    Dim ws As Worksheet, wp As Worksheet, r As Long, outR As Long, pid As String
    Set ws = ThisWorkbook.Worksheets(SH_CONFIRM)
    Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)
    ws.Range("A4:J1000").ClearContents
    outR = 4
    For r = 2 To LastRow(wp, 1)
        If Len(CStr(wp.Cells(r, P_ID).Value)) > 0 And CStr(wp.Cells(r, P_STATUS).Value) <> STATUS_CANCEL Then
            pid = CStr(wp.Cells(r, P_ID).Value)
            ws.Cells(outR, 1).Value = wp.Cells(r, P_ORDER).Value
            ws.Cells(outR, 2).Value = pid
            ws.Cells(outR, 3).Value = wp.Cells(r, P_TYPE).Value
            ws.Cells(outR, 4).Value = wp.Cells(r, P_REL_DEC).Value
            ws.Cells(outR, 5).Value = wp.Cells(r, P_DISPLAY).Value
            ws.Cells(outR, 6).Value = wp.Cells(r, P_FORMER).Value
            ws.Cells(outR, 7).Value = wp.Cells(r, P_BIRTH).Value
            ws.Cells(outR, 8).Value = wp.Cells(r, P_DEATH).Value
            ws.Cells(outR, 9).Value = GetCurrentAddressText(pid)
            ws.Cells(outR, 10).Value = wp.Cells(r, P_NOTE).Value
            outR = outR + 1
        End If
    Next r
    ws.Range("G4:H" & Application.Max(4, outR)).NumberFormatLocal = "yyyy/m/d"
    ws.Range("A3:J" & Application.Max(4, outR - 1)).Borders.LineStyle = xlContinuous
    ws.Range("A4:J" & Application.Max(4, outR - 1)).WrapText = True
    ws.Columns("A:J").AutoFit
    CapColumnWidths ws, 1, 10, 38
End Sub

Public Sub RunChecks()
    Dim ws As Worksheet, wp As Worksheet, r As Long, outR As Long, decCount As Long
    Set ws = ThisWorkbook.Worksheets(SH_CHECK)
    ws.Range("A4:H1000").ClearContents
    Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)
    outR = 4
    For r = 2 To LastRow(wp, 1)
        If CStr(wp.Cells(r, P_STATUS).Value) <> STATUS_CANCEL And Len(CStr(wp.Cells(r, P_ID).Value)) > 0 Then
            If wp.Cells(r, P_TYPE).Value = MODE_DECEDENT Then decCount = decCount + 1
            If Len(CStr(wp.Cells(r, P_GIVEN).Value)) = 0 Then AddCheck ws, outR, "エラー", "名が空欄です。", wp.Cells(r, P_ID).Value, wp.Cells(r, P_DISPLAY).Value, "人物", "名を入力"
            If Len(CStr(wp.Cells(r, P_REL_DEC).Value)) = 0 Then AddCheck ws, outR, "注意", "続柄が空欄です。", wp.Cells(r, P_ID).Value, wp.Cells(r, P_DISPLAY).Value, "人物", "続柄を確認"
            If InStr(CStr(wp.Cells(r, P_REL_DEC).Value), "配偶者") > 0 And Len(CStr(wp.Cells(r, P_FORMER).Value)) = 0 Then AddCheck ws, outR, "注意", "配偶者の旧姓が未入力です。", wp.Cells(r, P_ID).Value, wp.Cells(r, P_DISPLAY).Value, "旧姓", "必要に応じて入力"
            If CStr(wp.Cells(r, P_REL_DEC).Value) = "母" And Len(CStr(wp.Cells(r, P_FORMER).Value)) = 0 Then AddCheck ws, outR, "注意", "母の旧姓が未入力です。", wp.Cells(r, P_ID).Value, wp.Cells(r, P_DISPLAY).Value, "旧姓", "必要に応じて入力"
            If Len(GetCurrentAddressText(CStr(wp.Cells(r, P_ID).Value))) = 0 Then AddCheck ws, outR, "注意", "住所履歴が未入力です。", wp.Cells(r, P_ID).Value, wp.Cells(r, P_DISPLAY).Value, "住所", "住所を登録"
        End If
    Next r
    If decCount = 0 Then AddCheck ws, outR, "エラー", "被相続人が未登録です。", "", "", "被相続人", "被相続人を登録"
    If decCount > 1 Then AddCheck ws, outR, "エラー", "被相続人が複数登録されています。", "", "", "被相続人", "1人に整理"
    ws.Range("A3:H" & Application.Max(4, outR - 1)).Borders.LineStyle = xlContinuous
    ws.Columns("A:H").AutoFit
    CapColumnWidths ws, 1, 8, 42
End Sub

Private Sub AddCheck(ByVal ws As Worksheet, ByRef outR As Long, ByVal level As String, ByVal msg As String, ByVal pid As String, ByVal nameText As String, ByVal target As String, ByVal actionText As String)
    ws.Cells(outR, 1).Value = level
    ws.Cells(outR, 2).Value = msg
    ws.Cells(outR, 3).Value = pid
    ws.Cells(outR, 4).Value = nameText
    ws.Cells(outR, 5).Value = target
    ws.Cells(outR, 6).Value = actionText
    ws.Cells(outR, 7).Value = Now
    outR = outR + 1
End Sub

Private Sub GenerateEvents()
    Dim we As Worksheet, wp As Worksheet, wr As Worksheet, wa As Worksheet, r As Long
    Set we = ThisWorkbook.Worksheets(SH_W_EVENT)
    we.Range("A2:L2000").ClearContents
    Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)
    For r = 2 To LastRow(wp, 1)
        If CStr(wp.Cells(r, P_STATUS).Value) <> STATUS_CANCEL And Len(CStr(wp.Cells(r, P_ID).Value)) > 0 Then
            If IsDate(wp.Cells(r, P_BIRTH).Value) Then AddEvent wp.Cells(r, P_ID).Value, wp.Cells(r, P_BIRTH).Value, "出生", "出生", "自動", "人物", wp.Cells(r, P_ID).Value
            If IsDate(wp.Cells(r, P_DEATH).Value) Then AddEvent wp.Cells(r, P_ID).Value, wp.Cells(r, P_DEATH).Value, "死亡", "死亡", "自動", "人物", wp.Cells(r, P_ID).Value
        End If
    Next r
    Set wr = ThisWorkbook.Worksheets(SH_W_REL)
    For r = 2 To LastRow(wr, 1)
        If CStr(wr.Cells(r, R_STATUS).Value) <> STATUS_CANCEL Then
            If IsDate(wr.Cells(r, R_MARRIAGE).Value) Then
                AddEvent wr.Cells(r, R_BASE_ID).Value, wr.Cells(r, R_MARRIAGE).Value, "婚姻", "婚姻：" & GetPersonValue(wr.Cells(r, R_OTHER_ID).Value, P_DISPLAY), "自動", "関係", wr.Cells(r, R_ID).Value
                AddEvent wr.Cells(r, R_OTHER_ID).Value, wr.Cells(r, R_MARRIAGE).Value, "婚姻", "婚姻：" & GetPersonValue(wr.Cells(r, R_BASE_ID).Value, P_DISPLAY), "自動", "関係", wr.Cells(r, R_ID).Value
            End If
            If IsDate(wr.Cells(r, R_DIVORCE).Value) Then
                AddEvent wr.Cells(r, R_BASE_ID).Value, wr.Cells(r, R_DIVORCE).Value, "離婚", "離婚：" & GetPersonValue(wr.Cells(r, R_OTHER_ID).Value, P_DISPLAY), "自動", "関係", wr.Cells(r, R_ID).Value
                AddEvent wr.Cells(r, R_OTHER_ID).Value, wr.Cells(r, R_DIVORCE).Value, "離婚", "離婚：" & GetPersonValue(wr.Cells(r, R_BASE_ID).Value, P_DISPLAY), "自動", "関係", wr.Cells(r, R_ID).Value
            End If
        End If
    Next r
    Set wa = ThisWorkbook.Worksheets(SH_W_ADDR_HIST)
    For r = 2 To LastRow(wa, 1)
        If CStr(wa.Cells(r, A_STATUS).Value) <> STATUS_CANCEL And IsDate(wa.Cells(r, A_START).Value) Then
            AddEvent wa.Cells(r, A_PERSON_ID).Value, wa.Cells(r, A_START).Value, "住所移転", "住所移転：" & wa.Cells(r, A_TEXT).Value, "自動", "住所", wa.Cells(r, A_ID).Value
        End If
    Next r
    Dim decId As String, inhDate As Variant
    decId = GetDecedentId()
    inhDate = GetInheritanceDate()
    If Len(decId) > 0 And IsDate(inhDate) Then AddEvent decId, inhDate, "相続開始", "相続開始", "自動", "設定", "相続開始日"
End Sub

Private Sub AddEvent(ByVal personId As String, ByVal eventDate As Variant, ByVal eventType As String, ByVal content As String, ByVal autoFlag As String, ByVal srcType As String, ByVal srcId As String)
    Dim ws As Worksheet, r As Long
    Set ws = ThisWorkbook.Worksheets(SH_W_EVENT)
    r = NextBlankRow(ws, 1)
    ws.Cells(r, E_ID).Value = NextId("イベント")
    ws.Cells(r, E_PERSON_ID).Value = personId
    ws.Cells(r, E_DATE).Value = eventDate
    ws.Cells(r, E_YEAR).Value = Year(CDate(eventDate))
    ws.Cells(r, E_TYPE).Value = eventType
    ws.Cells(r, E_CONTENT).Value = content
    ws.Cells(r, E_AUTO).Value = autoFlag
    ws.Cells(r, E_SOURCE_TYPE).Value = srcType
    ws.Cells(r, E_SOURCE_ID).Value = srcId
    ws.Cells(r, E_SHOW).Value = SHOW_YES
    ws.Cells(r, E_STATUS).Value = STATUS_ACTIVE
End Sub

Private Sub BuildRelationshipDiagram()
    Dim ws As Worksheet
    Dim decId As String, decRow As Long, spouseRow As Long, fatherRow As Long, motherRow As Long
    Dim decShape As Shape, spouseShape As Shape, fatherShape As Shape, motherShape As Shape
    Dim originX As Double, originY As Double, decMidY As Double
    Dim children As Collection, childShapes As Object
    Dim i As Long, childRow As Long, childTop As Double, startY As Double
    Dim childX As Double, gcX As Double, parentX As Double, decX As Double
    Dim cardW As Double, cardH As Double, childGap As Double, branchX As Double
    Dim childTops() As Double, blockHeights() As Double, totalChildHeight As Double, cursorY As Double
    
    Set ws = ThisWorkbook.Worksheets(SH_DIAGRAM)
    ClearSheetAll ws
    
    ApplySheetCanvas ws
    ws.PageSetup.PaperSize = xlPaperA4
    ws.PageSetup.Orientation = xlLandscape
    ws.PageSetup.Zoom = False
    ws.PageSetup.FitToPagesWide = 1
    ws.PageSetup.FitToPagesTall = 1
    ws.PageSetup.LeftMargin = Application.CentimetersToPoints(0.5)
    ws.PageSetup.RightMargin = Application.CentimetersToPoints(0.5)
    ws.PageSetup.TopMargin = Application.CentimetersToPoints(0.6)
    ws.PageSetup.BottomMargin = Application.CentimetersToPoints(0.6)
    ws.PageSetup.PrintArea = "A1:Q38"
    
    ws.Columns("A:Q").ColumnWidth = 8.8
    ws.Rows("1:38").RowHeight = 18
    ws.Range("A1:Q1").Merge
    TitleBannerStyle ws.Range("A1:Q1"), "相続関係整理図（横型）"
    ws.Range("A2:Q2").Merge
    ws.Range("A2").Value = "左から右へ世代を流します。親世代は被相続人の左、配偶者は被相続人の下、子世代は右、孫はさらに右。線は水平・垂直のみで、斜線は使いません。"
    ws.Range("A2").HorizontalAlignment = xlCenter
    ws.Range("A2").Font.Color = ThemeColor("muted")
    ws.Range("A2").Font.Size = 9
    
    cardW = 128
    cardH = 64
    parentX = 22
    decX = 214
    childX = 410
    gcX = 620
    childGap = 106
    
    decId = GetDecedentId()
    decRow = FindPersonRow(decId)
    If decRow = 0 Then
        ws.Range("A5:H8").Merge
        ws.Range("A5").Value = "被相続人が未登録です。人物入力で被相続人を登録してください。"
        ws.Range("A5").Interior.Color = ThemeColor("danger-soft")
        ws.Range("A5").Font.Color = ThemeColor("red")
        ws.Range("A5").Font.Bold = True
        AddButton ws, "P1", "入力へ戻る", "ShowOnlyInput", 90, 24
        ThemeApplyMonochromePrint ws, "$A$1:$Q$12", True, "", 1, 1
        Exit Sub
    End If
    
    spouseRow = GetSpouseRowOfPerson(decId)
    fatherRow = GetFirstVisiblePersonRowByRelation("父")
    motherRow = GetFirstVisiblePersonRowByRelation("母")
    Set children = GetDirectChildRows(decId)
    Set childShapes = CreateObject("Scripting.Dictionary")
    If children.Count >= 5 Then
        childGap = Application.Max(58, 430 / Application.Max(1, children.Count - 1))
        cardH = Application.Max(46, Application.Min(60, childGap - 8))
        cardW = 120
    End If
    
    DrawGenerationLabel ws, parentX, 48, "親世代"
    DrawGenerationLabel ws, decX, 48, "被相続人世代"
    DrawGenerationLabel ws, childX, 48, "子世代"
    DrawGenerationLabel ws, gcX, 48, "孫世代"
    
    Set decShape = DrawPersonCardShape(ws, decRow, decX, 145, cardW, cardH)
    decMidY = ShapeCenterY(decShape)
    
    If spouseRow > 0 Then
        Set spouseShape = DrawPersonCardShape(ws, spouseRow, decX, 230, cardW, cardH)
        ConnectVerticalCouple ws, decShape, spouseShape, originX, originY
    Else
        originX = decShape.Left + decShape.Width
        originY = ShapeCenterY(decShape)
    End If
    
    If fatherRow > 0 And motherRow > 0 Then
        Set fatherShape = DrawPersonCardShape(ws, fatherRow, parentX, 105, cardW, cardH)
        Set motherShape = DrawPersonCardShape(ws, motherRow, parentX, 185, cardW, cardH)
        DrawVLine ws, ShapeCenterX(fatherShape), fatherShape.Top + fatherShape.Height, motherShape.Top
        DrawHLine ws, ShapeCenterX(fatherShape), decMidY, decShape.Left
    ElseIf fatherRow > 0 Then
        Set fatherShape = DrawPersonCardShape(ws, fatherRow, parentX, decShape.Top, cardW, cardH)
        DrawHLine ws, fatherShape.Left + fatherShape.Width, ShapeCenterY(fatherShape), decShape.Left
    ElseIf motherRow > 0 Then
        Set motherShape = DrawPersonCardShape(ws, motherRow, parentX, decShape.Top, cardW, cardH)
        DrawHLine ws, motherShape.Left + motherShape.Width, ShapeCenterY(motherShape), decShape.Left
    End If
    
    If children.Count > 0 Then
        ReDim childTops(1 To children.Count)
        ReDim blockHeights(1 To children.Count)
        totalChildHeight = 0
        For i = 1 To children.Count
            blockHeights(i) = EstimateChildFamilyBlockHeight(CLng(children(i)), cardH)
            totalChildHeight = totalChildHeight + blockHeights(i)
            If i < children.Count Then totalChildHeight = totalChildHeight + 20
        Next i
        startY = originY - totalChildHeight / 2
        If startY < 78 Then startY = 78
        cursorY = startY
        For i = 1 To children.Count
            childTops(i) = cursorY
            cursorY = cursorY + blockHeights(i) + 20
        Next i
        branchX = childX - 28
        DrawHLine ws, originX, originY, branchX
        DrawVLine ws, branchX, Application.Min(originY, childTops(1) + cardH / 2), Application.Max(originY, childTops(children.Count) + cardH / 2)
        For i = 1 To children.Count
            childRow = CLng(children(i))
            childTop = childTops(i)
            DrawChildFamilyBlock ws, childRow, childX, childTop, gcX, cardW, cardH, childShapes
            DrawHLine ws, branchX, childTop + cardH / 2, childX
        Next i
    End If
    
    DrawUnlinkedGrandchildren ws, gcX, 318, cardW, cardH
    PlaceOtherListHorizontal ws, 24, 332
    AddDiagramLegend ws, 24, 300
    AddButton ws, "P1", "入力へ戻る", "ShowOnlyInput", 90, 24
    PolishRelationshipDiagramOutput ws
    WarnDiagramIfCardCollisions ws
    WarnDiagramIfPrintBoundsRisk ws
    ThemeLockShapeLayer ws
End Sub


Private Function EstimateChildFamilyBlockHeight(ByVal childRow As Long, ByVal cardH As Double) As Double
    Dim childId As String, spouseRow As Long, gcRows As Collection, h As Double, gcH As Double
    childId = CStr(ThisWorkbook.Worksheets(SH_W_PERSON).Cells(childRow, P_ID).Value)
    spouseRow = GetSpouseRowOfPerson(childId)
    h = cardH
    If spouseRow > 0 Then h = h + 16 + cardH
    Set gcRows = GetGrandchildRowsForParent(childId)
    If Not gcRows Is Nothing Then
        If gcRows.Count > 0 Then
            gcH = cardH + (gcRows.Count - 1) * 76
            If gcH > h Then h = gcH
        End If
    End If
    EstimateChildFamilyBlockHeight = Application.Max(cardH, h)
End Function

Private Sub WarnDiagramIfCardCollisions(ByVal ws As Worksheet)
    Dim i As Long, j As Long, a As Shape, b As Shape, msg As String, nr As Long
    If ws Is Nothing Then Exit Sub
    For i = 1 To ws.Shapes.Count
        Set a = ws.Shapes(i)
        If Left$(a.Name, 5) = "card_" Then
            For j = i + 1 To ws.Shapes.Count
                Set b = ws.Shapes(j)
                If Left$(b.Name, 5) = "card_" Then
                    If ShapesOverlap(a, b, 3) Then
                        msg = "相続関係図のカード重なり候補があります。人数が多い場合は出力プレビューで確認してください: " & a.Name & " / " & b.Name
                        If SheetExists(SH_CHECK) Then
                            nr = LastRow(ThisWorkbook.Worksheets(SH_CHECK), 1) + 1
                            If nr < 2 Then nr = 2
                            ThisWorkbook.Worksheets(SH_CHECK).Cells(nr, 1).Value = "警告"
                            ThisWorkbook.Worksheets(SH_CHECK).Cells(nr, 2).Value = "相続関係整理図"
                            ThisWorkbook.Worksheets(SH_CHECK).Cells(nr, 3).Value = msg
                        End If
                        AddDiagramLayoutWarning ws, msg
                        Exit Sub
                    End If
                End If
            Next j
        End If
    Next i
End Sub

Private Function ShapesOverlap(ByVal a As Shape, ByVal b As Shape, Optional ByVal marginPt As Double = 0) As Boolean
    ShapesOverlap = Not (a.Left + a.Width + marginPt < b.Left Or b.Left + b.Width + marginPt < a.Left Or _
                         a.Top + a.Height + marginPt < b.Top Or b.Top + b.Height + marginPt < a.Top)
End Function

Private Sub WarnDiagramIfPrintBoundsRisk(ByVal ws As Worksheet)
    Dim shp As Shape
    Dim maxRight As Double, maxBottom As Double, printRight As Double, printBottom As Double
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    printRight = ws.Range("Q1").Left + ws.Range("Q1").Width
    printBottom = ws.Rows(60).Top + ws.Rows(60).Height
    For Each shp In ws.Shapes
        If Not ThemeIsButtonShape(shp) Then
            If shp.Left + shp.Width > maxRight Then maxRight = shp.Left + shp.Width
            If shp.Top + shp.Height > maxBottom Then maxBottom = shp.Top + shp.Height
        End If
    Next shp
    If maxRight > printRight + 8 Or maxBottom > printBottom + 8 Then
        AddDiagramLayoutWarning ws, "相続関係図の一部が印刷想定範囲からはみ出す可能性があります。印刷プレビューでカードの切れ・縮小率を確認してください。"
    End If
    On Error GoTo 0
End Sub

Private Sub AddDiagramLayoutWarning(ByVal ws As Worksheet, ByVal msg As String)
    Dim shp As Shape
    Set shp = ws.Shapes.AddShape(msoShapeRoundedRectangle, 24, 560, 560, 28)
    With shp
        .Name = "layout_warning"
        .Fill.ForeColor.RGB = ThemeColor("danger-soft")
        .Line.ForeColor.RGB = ThemeColor("red")
        .TextFrame2.TextRange.Text = msg
        .TextFrame2.TextRange.Font.Name = "Yu Gothic"
        .TextFrame2.TextRange.Font.Size = 8
        .TextFrame2.TextRange.Font.Fill.ForeColor.RGB = ThemeColor("red")
        .TextFrame2.MarginLeft = 6
        .TextFrame2.MarginRight = 6
        .PrintObject = True
    End With
End Sub

Private Sub PolishRelationshipDiagramOutput(ByVal ws As Worksheet)
    Dim shp As Shape
    Dim maxBottom As Double
    Dim printRows As Long
    If ws Is Nothing Then Exit Sub
    maxBottom = 0
    On Error Resume Next
    For Each shp In ws.Shapes
        If shp.Top + shp.Height > maxBottom Then maxBottom = shp.Top + shp.Height
        If Len(shp.OnAction) > 0 Then
            shp.PrintObject = False
        Else
            shp.PrintObject = True
            If shp.Type = msoLine Then
                shp.Line.ForeColor.RGB = ThemeColor("text")
                shp.Line.Weight = 1.15
            Else
                shp.Line.ForeColor.RGB = ThemeColor("text")
                If Left$(shp.Name, 5) = "card_" Then
                    shp.Line.Weight = 1.5
                    shp.Shadow.Visible = msoFalse
                    shp.TextFrame2.TextRange.Font.Fill.ForeColor.RGB = ThemeColor("text")
                    shp.TextFrame2.TextRange.Font.Bold = msoTrue
                End If
            End If
        End If
    Next shp
    printRows = Application.Max(38, CLng((maxBottom + 36) / 18) + 1)
    If printRows > 60 Then printRows = 60
    If printRows <= 42 Then
        ThemeApplyMonochromePrint ws, "$A$1:$Q$" & CStr(printRows), True, "", 1, 1
    Else
        '人数が多い案件では、1ページに無理に押し込めず、横1ページ・縦複数ページで可読性を優先する。
        ThemeApplyMonochromePrint ws, "$A$1:$Q$" & CStr(printRows), True, "", 1, 0
    End If
    ws.PageSetup.CenterHorizontally = True
    ThemeLockShapeLayer ws
    On Error GoTo 0
End Sub

Private Function DrawPersonCardShape(ByVal ws As Worksheet, ByVal personRow As Long, ByVal leftPt As Double, ByVal topPt As Double, ByVal widthPt As Double, ByVal heightPt As Double) As Shape
    Dim wp As Worksheet, shp As Shape, text As String, inh As Variant, relText As String, pid As String
    Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)
    relText = CStr(wp.Cells(personRow, P_REL_DEC).Value)
    pid = CStr(wp.Cells(personRow, P_ID).Value)
    text = CStr(wp.Cells(personRow, P_DISPLAY).Value) & vbLf & relText
    If Len(CStr(wp.Cells(personRow, P_FORMER).Value)) > 0 Then text = text & vbLf & "旧姓：" & wp.Cells(personRow, P_FORMER).Value
    If IsDate(wp.Cells(personRow, P_BIRTH).Value) Then text = text & vbLf & Format(wp.Cells(personRow, P_BIRTH).Value, "yyyy/m/d") & "生"
    If IsDate(wp.Cells(personRow, P_DEATH).Value) Then text = text & IIf(InStr(text, "生") > 0, " / ", vbLf) & Format(wp.Cells(personRow, P_DEATH).Value, "yyyy/m/d") & "死亡"
    inh = GetInheritanceDate()
    If IsDate(wp.Cells(personRow, P_BIRTH).Value) And IsDate(inh) And relText <> "被相続人" Then text = text & vbLf & "相続開始時 " & AgeOnDate(wp.Cells(personRow, P_BIRTH).Value, inh)
    
    Set shp = ws.Shapes.AddShape(msoShapeRoundedRectangle, leftPt, topPt, widthPt, heightPt)
    With shp
        .Name = "card_" & pid
        .Placement = xlFreeFloating
        .Locked = True
        .Fill.ForeColor.RGB = CardFillColor(relText)
        .Line.ForeColor.RGB = ThemeColor("muted")
        .Line.Weight = 1.35
        .Shadow.Visible = msoFalse
        .Shadow.ForeColor.RGB = ThemeColor("line-muted")
        .Shadow.Transparency = 0.82
        .Shadow.OffsetX = 1
        .Shadow.OffsetY = 1
        .TextFrame2.TextRange.Text = text
        .TextFrame2.TextRange.Font.Name = "Yu Gothic"
        .TextFrame2.TextRange.Font.Size = CardFontSizeForText(text)
        .TextFrame2.TextRange.Font.Bold = msoTrue
        .TextFrame2.WordWrap = msoTrue
        .TextFrame2.TextRange.Font.Fill.ForeColor.RGB = ThemeColor("text")
        .TextFrame2.VerticalAnchor = msoAnchorMiddle
        .TextFrame2.TextRange.ParagraphFormat.Alignment = msoAlignCenter
        .TextFrame2.MarginLeft = 4
        .TextFrame2.MarginRight = 4
        .TextFrame2.MarginTop = 3
        .TextFrame2.MarginBottom = 3
        .ZOrder msoBringToFront
    End With
    Set DrawPersonCardShape = shp
End Function

Private Function CardFontSizeForText(ByVal text As String) As Double
    '白黒印刷でもカード内の文字が潰れないよう、情報量に応じて少しだけ自動調整する。
    Dim n As Long
    n = Len(text)
    If n >= 115 Then
        CardFontSizeForText = 7.2
    ElseIf n >= 90 Then
        CardFontSizeForText = 7.6
    ElseIf n >= 72 Then
        CardFontSizeForText = 8
    Else
        CardFontSizeForText = 8.5
    End If
End Function

Private Function CardFillColor(ByVal relationText As String) As Long
    Select Case relationText
        Case "被相続人"
            CardFillColor = ThemeColor("info-soft")
        Case "配偶者"
            CardFillColor = ThemeColor("warning-soft")
        Case "父", "母"
            CardFillColor = ThemeColor("success-soft")
        Case "孫"
            CardFillColor = ThemeColor("purple-soft")
        Case Else
            If IsDirectChildRelationText(relationText) Then
                CardFillColor = ThemeColor("info-very-soft")
            ElseIf InStr(relationText, "配偶者") > 0 Then
                CardFillColor = ThemeColor("warning-soft")
            Else
                CardFillColor = ThemeColor("canvas")
            End If
    End Select
End Function

Private Sub ConnectVerticalCouple(ByVal ws As Worksheet, ByVal upperShape As Shape, ByVal lowerShape As Shape, ByRef originX As Double, ByRef originY As Double)
    originX = ShapeCenterX(upperShape)
    DrawVLine ws, originX, upperShape.Top + upperShape.Height, lowerShape.Top
    originY = (upperShape.Top + upperShape.Height + lowerShape.Top) / 2
End Sub

Private Sub DrawChildFamilyBlock(ByVal ws As Worksheet, ByVal childRow As Long, ByVal childX As Double, ByVal childTop As Double, ByVal gcX As Double, ByVal cardW As Double, ByVal cardH As Double, ByVal childShapes As Object)
    Dim childShape As Shape, spouseRow As Long, spouseShape As Shape
    Dim childId As String, originX As Double, originY As Double, gcRows As Collection
    Dim i As Long, topG As Double, startG As Double, branchX As Double, gRow As Long
    childId = CStr(ThisWorkbook.Worksheets(SH_W_PERSON).Cells(childRow, P_ID).Value)
    Set childShape = DrawPersonCardShape(ws, childRow, childX, childTop, cardW, cardH)
    If Not childShapes.Exists(childId) Then childShapes.Add childId, childShape.Name
    
    spouseRow = GetSpouseRowOfPerson(childId)
    If spouseRow > 0 Then
        Set spouseShape = DrawPersonCardShape(ws, spouseRow, childX, childTop + cardH + 16, cardW, cardH)
        ConnectVerticalCouple ws, childShape, spouseShape, originX, originY
    Else
        originX = childShape.Left + childShape.Width
        originY = ShapeCenterY(childShape)
    End If
    
    Set gcRows = GetGrandchildRowsForParent(childId)
    If gcRows.Count > 0 Then
        branchX = gcX - 28
        startG = originY - ((gcRows.Count - 1) * 76) / 2 - cardH / 2
        If startG < 78 Then startG = 78
        DrawHLine ws, originX, originY, branchX
        DrawVLine ws, branchX, Application.Min(originY, startG + cardH / 2), Application.Max(originY, startG + (gcRows.Count - 1) * 76 + cardH / 2)
        For i = 1 To gcRows.Count
            gRow = CLng(gcRows(i))
            topG = startG + (i - 1) * 76
            DrawPersonCardShape ws, gRow, gcX, topG, cardW, cardH
            DrawHLine ws, branchX, topG + cardH / 2, gcX
        Next i
    End If
End Sub

Private Sub DrawUnlinkedGrandchildren(ByVal ws As Worksheet, ByVal gcX As Double, ByVal topPt As Double, ByVal cardW As Double, ByVal cardH As Double)
    Dim rows As Collection, i As Long
    Set rows = GetUnlinkedGrandchildRows()
    If rows.Count = 0 Then Exit Sub
    DrawGenerationLabel ws, gcX, topPt - 24, "孫世代（親未指定）"
    For i = 1 To rows.Count
        DrawPersonCardShape ws, CLng(rows(i)), gcX, topPt + (i - 1) * 70, cardW, cardH
    Next i
End Sub

Private Function GetFirstVisiblePersonRowByRelation(ByVal relationText As String) As Long
    Dim wp As Worksheet, r As Long
    Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)
    For r = 2 To LastRow(wp, 1)
        If CStr(wp.Cells(r, P_STATUS).Value) <> STATUS_CANCEL And CStr(wp.Cells(r, P_SHOW).Value) <> SHOW_NO Then
            If CStr(wp.Cells(r, P_REL_DEC).Value) = relationText Then
                GetFirstVisiblePersonRowByRelation = r
                Exit Function
            End If
        End If
    Next r
End Function

Private Function GetDirectChildRows(ByVal decId As String) As Collection
    Dim col As New Collection, wp As Worksheet, r As Long, relText As String, pid As String
    Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)
    For r = 2 To LastRow(wp, 1)
        pid = CStr(wp.Cells(r, P_ID).Value)
        relText = CStr(wp.Cells(r, P_REL_DEC).Value)
        If CStr(wp.Cells(r, P_STATUS).Value) <> STATUS_CANCEL And CStr(wp.Cells(r, P_SHOW).Value) <> SHOW_NO Then
            If pid <> decId And IsDirectChildRelationText(relText) Then col.Add r
        End If
    Next r
    Set GetDirectChildRows = col
End Function

Private Function IsDirectChildRelationText(ByVal relText As String) As Boolean
    Select Case relText
        Case "長男", "二男", "三男", "四男", "五男", "六男", "長女", "二女", "三女", "四女", "五女", "六女", "子", "養子"
            IsDirectChildRelationText = True
    End Select
End Function

Private Function IsGrandchildRelationText(ByVal relText As String) As Boolean
    IsGrandchildRelationText = (relText = "孫" Or InStr(relText, "孫") > 0)
End Function

Private Function GetSpouseRowOfPerson(ByVal personId As String) As Long
    Dim wr As Worksheet, r As Long, otherId As String
    Set wr = ThisWorkbook.Worksheets(SH_W_REL)
    For r = 2 To LastRow(wr, 1)
        If CStr(wr.Cells(r, R_STATUS).Value) <> STATUS_CANCEL And CStr(wr.Cells(r, R_TYPE).Value) = "配偶者" Then
            If CStr(wr.Cells(r, R_BASE_ID).Value) = personId Then
                otherId = CStr(wr.Cells(r, R_OTHER_ID).Value)
                GetSpouseRowOfPerson = FindPersonRow(otherId)
                Exit Function
            ElseIf CStr(wr.Cells(r, R_OTHER_ID).Value) = personId Then
                otherId = CStr(wr.Cells(r, R_BASE_ID).Value)
                GetSpouseRowOfPerson = FindPersonRow(otherId)
                Exit Function
            End If
        End If
    Next r
End Function

Private Function GetGrandchildRowsForParent(ByVal parentId As String) As Collection
    Dim col As New Collection, wr As Worksheet, r As Long, gcId As String, gcRow As Long
    Set wr = ThisWorkbook.Worksheets(SH_W_REL)
    For r = 2 To LastRow(wr, 1)
        If CStr(wr.Cells(r, R_STATUS).Value) <> STATUS_CANCEL And CStr(wr.Cells(r, R_TYPE).Value) = "親子" Then
            If CStr(wr.Cells(r, R_BASE_ID).Value) = parentId Then
                gcId = CStr(wr.Cells(r, R_OTHER_ID).Value)
                gcRow = FindPersonRow(gcId)
                If gcRow > 0 Then
                    If IsGrandchildRelationText(CStr(ThisWorkbook.Worksheets(SH_W_PERSON).Cells(gcRow, P_REL_DEC).Value)) Then col.Add gcRow
                End If
            End If
        End If
    Next r
    Set GetGrandchildRowsForParent = col
End Function

Private Function GetUnlinkedGrandchildRows() As Collection
    Dim col As New Collection, wp As Worksheet, r As Long, pid As String
    Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)
    For r = 2 To LastRow(wp, 1)
        pid = CStr(wp.Cells(r, P_ID).Value)
        If CStr(wp.Cells(r, P_STATUS).Value) <> STATUS_CANCEL And CStr(wp.Cells(r, P_SHOW).Value) <> SHOW_NO Then
            If IsGrandchildRelationText(CStr(wp.Cells(r, P_REL_DEC).Value)) And Not HasParentRelationFromDirectChild(pid) Then col.Add r
        End If
    Next r
    Set GetUnlinkedGrandchildRows = col
End Function

Private Function HasParentRelationFromDirectChild(ByVal personId As String) As Boolean
    Dim wr As Worksheet, r As Long, pRow As Long
    Set wr = ThisWorkbook.Worksheets(SH_W_REL)
    For r = 2 To LastRow(wr, 1)
        If CStr(wr.Cells(r, R_STATUS).Value) <> STATUS_CANCEL And CStr(wr.Cells(r, R_TYPE).Value) = "親子" Then
            If CStr(wr.Cells(r, R_OTHER_ID).Value) = personId Then
                pRow = FindPersonRow(CStr(wr.Cells(r, R_BASE_ID).Value))
                If pRow > 0 Then
                    If IsDirectChildRelationText(CStr(ThisWorkbook.Worksheets(SH_W_PERSON).Cells(pRow, P_REL_DEC).Value)) Then
                        HasParentRelationFromDirectChild = True
                        Exit Function
                    End If
                End If
            End If
        End If
    Next r
End Function

Private Sub PlaceOtherListHorizontal(ByVal ws As Worksheet, ByVal leftPt As Double, ByVal topPt As Double)
    Dim wp As Worksheet, r As Long, relText As String, outText As String
    Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)
    For r = 2 To LastRow(wp, 1)
        relText = CStr(wp.Cells(r, P_REL_DEC).Value)
        If CStr(wp.Cells(r, P_STATUS).Value) <> STATUS_CANCEL And CStr(wp.Cells(r, P_SHOW).Value) <> SHOW_NO Then
            If ShouldListAsOther(relText) Then
                If Len(outText) > 0 Then outText = outText & vbLf
                outText = outText & "・" & wp.Cells(r, P_DISPLAY).Value & "（" & relText & "）"
            End If
        End If
    Next r
    If Len(outText) = 0 Then Exit Sub
    Dim shp As Shape
    Set shp = ws.Shapes.AddShape(msoShapeRoundedRectangle, leftPt, topPt, 360, 88)
    With shp
        .Name = "box_other_relations"
        .Placement = xlFreeFloating
        .Locked = True
        .Fill.ForeColor.RGB = ThemeColor("canvas")
        .Line.ForeColor.RGB = ThemeColor("line-muted")
        .Line.Weight = 1
        .TextFrame2.TextRange.Text = "その他関係者" & vbLf & outText
        .TextFrame2.TextRange.Font.Name = "Yu Gothic"
        .TextFrame2.TextRange.Font.Size = 8.5
        .TextFrame2.TextRange.Font.Fill.ForeColor.RGB = ThemeColor("text")
        .TextFrame2.MarginLeft = 8
        .TextFrame2.MarginRight = 8
        .TextFrame2.VerticalAnchor = msoAnchorTop
    End With
End Sub

Private Function ShouldListAsOther(ByVal relText As String) As Boolean
    If relText = "被相続人" Or relText = "配偶者" Or relText = "父" Or relText = "母" Then Exit Function
    If IsDirectChildRelationText(relText) Then Exit Function
    If IsGrandchildRelationText(relText) Then Exit Function
    If InStr(relText, "配偶者") > 0 Then Exit Function
    ShouldListAsOther = True
End Function

Private Sub AddDiagramLegend(ByVal ws As Worksheet, ByVal leftPt As Double, ByVal topPt As Double)
    Dim shp As Shape
    Set shp = ws.Shapes.AddShape(msoShapeRoundedRectangle, leftPt, topPt, 330, 26)
    With shp
        .Name = "legend_no_diagonal"
        .Placement = xlFreeFloating
        .Locked = True
        .Fill.ForeColor.RGB = ThemeColor("section")
        .Line.ForeColor.RGB = ThemeColor("info-border")
        .Line.Weight = 1
        .TextFrame2.TextRange.Text = "線の仕様：水平線・垂直線のみ。斜め線は使用しない。"
        .TextFrame2.TextRange.Font.Name = "Yu Gothic"
        .TextFrame2.TextRange.Font.Size = 8.5
        .TextFrame2.TextRange.Font.Bold = msoTrue
        .TextFrame2.TextRange.Font.Fill.ForeColor.RGB = ThemeColor("blue")
        .TextFrame2.VerticalAnchor = msoAnchorMiddle
        .TextFrame2.TextRange.ParagraphFormat.Alignment = msoAlignCenter
    End With
End Sub

Private Sub DrawGenerationLabel(ByVal ws As Worksheet, ByVal leftPt As Double, ByVal topPt As Double, ByVal caption As String)
    Dim shp As Shape
    Set shp = ws.Shapes.AddShape(msoShapeRoundedRectangle, leftPt, topPt, 118, 22)
    With shp
        .Name = "label_" & caption
        .Placement = xlFreeFloating
        .Locked = True
        .Fill.ForeColor.RGB = ThemeColor("locked")
        .Line.ForeColor.RGB = ThemeColor("border")
        .Line.Weight = 0.75
        .TextFrame2.TextRange.Text = caption
        .TextFrame2.TextRange.Font.Name = "Yu Gothic"
        .TextFrame2.TextRange.Font.Size = 8.5
        .TextFrame2.TextRange.Font.Bold = msoTrue
        .TextFrame2.TextRange.Font.Fill.ForeColor.RGB = ThemeColor("muted-strong")
        .TextFrame2.VerticalAnchor = msoAnchorMiddle
        .TextFrame2.TextRange.ParagraphFormat.Alignment = msoAlignCenter
    End With
End Sub

Private Sub DrawHLine(ByVal ws As Worksheet, ByVal x1 As Double, ByVal y As Double, ByVal x2 As Double)
    Dim shp As Shape
    Set shp = ws.Shapes.AddLine(x1, y, x2, y)
    shp.Placement = xlFreeFloating
    shp.Locked = True
    With shp.Line
        .ForeColor.RGB = ThemeColor("muted-strong")
        .Weight = 1.5
        .EndArrowheadStyle = msoArrowheadNone
        .BeginArrowheadStyle = msoArrowheadNone
    End With
    shp.ZOrder msoSendToBack
End Sub

Private Sub DrawVLine(ByVal ws As Worksheet, ByVal x As Double, ByVal y1 As Double, ByVal y2 As Double)
    Dim shp As Shape
    Set shp = ws.Shapes.AddLine(x, y1, x, y2)
    shp.Placement = xlFreeFloating
    shp.Locked = True
    With shp.Line
        .ForeColor.RGB = ThemeColor("muted-strong")
        .Weight = 1.5
        .EndArrowheadStyle = msoArrowheadNone
        .BeginArrowheadStyle = msoArrowheadNone
    End With
    shp.ZOrder msoSendToBack
End Sub

Private Function ShapeCenterX(ByVal shp As Shape) As Double
    ShapeCenterX = shp.Left + shp.Width / 2
End Function

Private Function ShapeCenterY(ByVal shp As Shape) As Double
    ShapeCenterY = shp.Top + shp.Height / 2
End Function


Private Sub BuildAddressHistoryTable()
    Dim ws As Worksheet, wa As Worksheet, outR As Long, r As Long, pid As String, endDate As Variant
    Set ws = ThisWorkbook.Worksheets(SH_ADDR_TABLE)
    ClearSheetAll ws
    ws.Range("A1:J1").Merge
    SectionStyle ws.Range("A1:J1"), "住所移転早見表"
    AddButton ws, "K1", "入力へ戻る", "ShowOnlyInput", 90, 24
    SetRowValues ws.Range("A3"), Array("人物ID", "氏名", "続柄", "住所区分", "開始日", "終了日", "居住期間", "住所", "住所キー", "根拠")
    HeaderStyle ws.Range("A3:J3")
    Set wa = ThisWorkbook.Worksheets(SH_W_ADDR_HIST)
    outR = 4
    For r = 2 To LastRow(wa, 1)
        If CStr(wa.Cells(r, A_STATUS).Value) <> STATUS_CANCEL And Len(CStr(wa.Cells(r, A_ID).Value)) > 0 Then
            pid = wa.Cells(r, A_PERSON_ID).Value
            endDate = EffectiveEndDate(r)
            ws.Cells(outR, 1).Value = pid
            ws.Cells(outR, 2).Value = GetPersonValue(pid, P_DISPLAY)
            ws.Cells(outR, 3).Value = GetPersonValue(pid, P_REL_DEC)
            ws.Cells(outR, 4).Value = wa.Cells(r, A_TYPE).Value
            ws.Cells(outR, 5).Value = wa.Cells(r, A_START).Value
            ws.Cells(outR, 6).Value = endDate
            ws.Cells(outR, 7).Value = PeriodText(wa.Cells(r, A_START).Value, endDate)
            ws.Cells(outR, 8).Value = wa.Cells(r, A_TEXT).Value
            ws.Cells(outR, 9).Value = wa.Cells(r, A_KEY).Value
            ws.Cells(outR, 10).Value = wa.Cells(r, A_SOURCE).Value
            outR = outR + 1
        End If
    Next r
    ws.Range("E4:F" & Application.Max(4, outR)).NumberFormatLocal = "yyyy/m/d"
    ws.Range("A3:J" & Application.Max(4, outR - 1)).Borders.LineStyle = xlContinuous
    ws.Columns("A:J").AutoFit
    ws.Columns("H:H").ColumnWidth = 42
    PolishSimplePersonOutput ws, Application.Max(4, outR - 1), 10, "$3:$3"
End Sub

Private Function EffectiveEndDate(ByVal addrRow As Long) As Variant
    Dim wa As Worksheet, pid As String, r As Long, bestNext As Variant, baseDate As Variant, death As Variant
    Set wa = ThisWorkbook.Worksheets(SH_W_ADDR_HIST)
    If IsDate(wa.Cells(addrRow, A_END).Value) Then EffectiveEndDate = wa.Cells(addrRow, A_END).Value: Exit Function
    pid = wa.Cells(addrRow, A_PERSON_ID).Value
    For r = 2 To LastRow(wa, 1)
        If r <> addrRow And wa.Cells(r, A_PERSON_ID).Value = pid And IsDate(wa.Cells(r, A_START).Value) And IsDate(wa.Cells(addrRow, A_START).Value) Then
            If CDate(wa.Cells(r, A_START).Value) > CDate(wa.Cells(addrRow, A_START).Value) Then
                If Not IsDate(bestNext) Or CDate(wa.Cells(r, A_START).Value) < CDate(bestNext) Then bestNext = wa.Cells(r, A_START).Value
            End If
        End If
    Next r
    If IsDate(bestNext) Then EffectiveEndDate = DateAdd("d", -1, CDate(bestNext)): Exit Function
    death = GetPersonValue(pid, P_DEATH)
    If IsDate(death) Then EffectiveEndDate = death: Exit Function
    baseDate = ThisWorkbook.Worksheets(SH_CONFIG).Range(CELL_CONFIG_BASE_DATE).Value
    If IsDate(baseDate) Then EffectiveEndDate = baseDate Else EffectiveEndDate = ""
End Function

Private Sub BuildCohabitationTable()
    Dim ws As Worksheet, wa As Worksheet, r1 As Long, r2 As Long, outR As Long, coNo As Long, s1 As Variant, e1 As Variant, s2 As Variant, e2 As Variant, st As Variant, en As Variant
    Set ws = ThisWorkbook.Worksheets(SH_COHAB)
    ClearSheetAll ws
    ApplySheetCanvas ws
    ws.Range("A1:J1").Merge
    TitleBannerStyle ws.Range("A1:J1"), "同居推定表"
    AddButton ws, "K1", "入力へ戻る", "ShowOnlyInput", 90, 24
    SetRowValues ws.Range("A3"), Array("同居推定ID", "人物A", "続柄A", "人物B", "続柄B", "住所", "同居推定開始", "同居推定終了", "期間", "判定")
    HeaderStyle ws.Range("A3:J3")
    Set wa = ThisWorkbook.Worksheets(SH_W_ADDR_HIST)
    outR = 4
    coNo = 1
    For r1 = 2 To LastRow(wa, 1)
        If CStr(wa.Cells(r1, A_STATUS).Value) <> STATUS_CANCEL And Len(CStr(wa.Cells(r1, A_KEY).Value)) > 0 Then
            For r2 = r1 + 1 To LastRow(wa, 1)
                If CStr(wa.Cells(r2, A_STATUS).Value) <> STATUS_CANCEL And wa.Cells(r1, A_KEY).Value = wa.Cells(r2, A_KEY).Value And wa.Cells(r1, A_PERSON_ID).Value <> wa.Cells(r2, A_PERSON_ID).Value Then
                    s1 = wa.Cells(r1, A_START).Value: e1 = EffectiveEndDate(r1)
                    s2 = wa.Cells(r2, A_START).Value: e2 = EffectiveEndDate(r2)
                    If IsDate(s1) And IsDate(e1) And IsDate(s2) And IsDate(e2) Then
                        st = IIf(CDate(s1) > CDate(s2), s1, s2)
                        en = IIf(CDate(e1) < CDate(e2), e1, e2)
                        If CDate(st) <= CDate(en) Then
                            WriteCohab ws, outR, "CO" & Format(coNo, "000000"), wa.Cells(r1, A_PERSON_ID).Value, wa.Cells(r2, A_PERSON_ID).Value, wa.Cells(r1, A_TEXT).Value, st, en, "同居推定"
                            coNo = coNo + 1
                            outR = outR + 1
                        End If
                    Else
                        WriteCohab ws, outR, "CO" & Format(coNo, "000000"), wa.Cells(r1, A_PERSON_ID).Value, wa.Cells(r2, A_PERSON_ID).Value, wa.Cells(r1, A_TEXT).Value, "", "", "同居推定・期間要確認"
                        coNo = coNo + 1
                        outR = outR + 1
                    End If
                End If
            Next r2
        End If
    Next r1
    ws.Range("G4:H" & Application.Max(4, outR)).NumberFormatLocal = "yyyy/m/d"
    ws.Range("A3:J" & Application.Max(4, outR - 1)).Borders.LineStyle = xlContinuous
    ws.Columns("A:J").AutoFit
    CapColumnWidths ws, 1, 10, 38
    ws.Columns("F:F").ColumnWidth = 42
    PolishSimplePersonOutput ws, Application.Max(4, outR - 1), 10, "$3:$3"
End Sub

Private Sub WriteCohab(ByVal ws As Worksheet, ByVal outR As Long, ByVal cohabId As String, ByVal p1 As String, ByVal p2 As String, ByVal addr As String, ByVal st As Variant, ByVal en As Variant, ByVal judge As String)
    ws.Cells(outR, 1).Value = cohabId
    ws.Cells(outR, 2).Value = GetPersonValue(p1, P_DISPLAY)
    ws.Cells(outR, 3).Value = GetPersonValue(p1, P_REL_DEC)
    ws.Cells(outR, 4).Value = GetPersonValue(p2, P_DISPLAY)
    ws.Cells(outR, 5).Value = GetPersonValue(p2, P_REL_DEC)
    ws.Cells(outR, 6).Value = addr
    ws.Cells(outR, 7).Value = st
    ws.Cells(outR, 8).Value = en
    ws.Cells(outR, 9).Value = PeriodText(st, en)
    ws.Cells(outR, 10).Value = judge
End Sub

Private Sub BuildTimelineTable()
    Dim ws As Worksheet, wp As Worksheet, we As Worksheet
    Dim minY As Long, maxY As Long, r As Long, c As Long, y As Long
    Dim rowOut As Long, lastCol As Long, lastDataRow As Long, baseDate As Variant
    Set ws = ThisWorkbook.Worksheets(SH_TIMELINE)
    ClearSheetAll ws
    Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)
    Set we = ThisWorkbook.Worksheets(SH_W_EVENT)

    baseDate = ThisWorkbook.Worksheets(SH_CONFIG).Range(CELL_CONFIG_BASE_DATE).Value
    If IsDate(baseDate) Then
        maxY = Year(CDate(baseDate))
    Else
        maxY = Year(Date)
    End If
    minY = maxY
    For r = 2 To LastRow(we, 1)
        If IsNumeric(we.Cells(r, E_YEAR).Value) And CStr(we.Cells(r, E_STATUS).Value) <> STATUS_CANCEL Then
            If CLng(we.Cells(r, E_YEAR).Value) < minY Then minY = CLng(we.Cells(r, E_YEAR).Value)
            If CLng(we.Cells(r, E_YEAR).Value) > maxY Then maxY = CLng(we.Cells(r, E_YEAR).Value)
        End If
    Next r
    If minY > maxY Then minY = maxY

    ApplySheetCanvas ws

    c = 3
    For r = 2 To LastRow(wp, 1)
        If CStr(wp.Cells(r, P_STATUS).Value) <> STATUS_CANCEL And CStr(wp.Cells(r, P_SHOW).Value) <> SHOW_NO Then c = c + 2
    Next r
    lastCol = Application.Max(5, c - 1)

    ws.Range(ws.Cells(1, 1), ws.Cells(1, lastCol)).Merge
    TitleBannerStyle ws.Range(ws.Cells(1, 1), ws.Cells(1, lastCol)), "時系列表"
    ws.Range(ws.Cells(2, 1), ws.Cells(2, lastCol)).Merge
    ws.Cells(2, 1).Value = "最古の出来事年から作成基準年まで、イベントがない年も1年ごとに表示します。左端に西暦と和暦を併記します。"
    ws.Cells(2, 1).HorizontalAlignment = xlCenter
    ws.Cells(2, 1).Font.Color = ThemeColor("muted")
    AddButton ws, ws.Cells(1, lastCol).Address(False, False), "入力へ戻る", "ShowOnlyInput", 90, 24

    ws.Cells(3, 1).Value = "西暦"
    ws.Range("A3:A5").Merge
    HeaderStyle ws.Range("A3:A5"), ThemeColor("blue")
    ws.Cells(3, 2).Value = "和暦"
    ws.Range("B3:B5").Merge
    HeaderStyle ws.Range("B3:B5"), ThemeColor("blue")

    c = 3
    For r = 2 To LastRow(wp, 1)
        If CStr(wp.Cells(r, P_STATUS).Value) <> STATUS_CANCEL And CStr(wp.Cells(r, P_SHOW).Value) <> SHOW_NO Then
            ws.Range(ws.Cells(3, c), ws.Cells(3, c + 1)).Merge
            ws.Cells(3, c).Value = wp.Cells(r, P_DISPLAY).Value
            ws.Range(ws.Cells(4, c), ws.Cells(4, c + 1)).Merge
            ws.Cells(4, c).Value = wp.Cells(r, P_REL_DEC).Value
            ws.Cells(5, c).Value = "年齢"
            ws.Cells(5, c + 1).Value = "出来事"
            HeaderStyle ws.Range(ws.Cells(3, c), ws.Cells(5, c + 1)), ThemeColor("muted-strong")
            c = c + 2
        End If
    Next r

    rowOut = 6
    For y = minY To maxY
        ws.Cells(rowOut, 1).Value = y
        ws.Cells(rowOut, 2).Value = EraYearText(y)
        c = 3
        For r = 2 To LastRow(wp, 1)
            If CStr(wp.Cells(r, P_STATUS).Value) <> STATUS_CANCEL And CStr(wp.Cells(r, P_SHOW).Value) <> SHOW_NO Then
                ws.Cells(rowOut, c).Value = AgeForYear(wp.Cells(r, P_BIRTH).Value, wp.Cells(r, P_DEATH).Value, y)
                ws.Cells(rowOut, c + 1).Value = EventsForPersonYear(wp.Cells(r, P_ID).Value, y)
                ws.Cells(rowOut, c).HorizontalAlignment = xlCenter
                ws.Cells(rowOut, c + 1).WrapText = True
                ws.Cells(rowOut, c + 1).VerticalAlignment = xlTop
                c = c + 2
            End If
        Next r
        If rowOut Mod 2 = 0 Then ws.Range(ws.Cells(rowOut, 1), ws.Cells(rowOut, lastCol)).Interior.Color = ThemeColor("canvas")
        rowOut = rowOut + 1
    Next y
    lastDataRow = Application.Max(6, rowOut - 1)
    With ws.Range(ws.Cells(3, 1), ws.Cells(lastDataRow, lastCol))
        .Borders.LineStyle = xlContinuous
        .Borders.Color = ThemeColor("border")
        .VerticalAlignment = xlTop
    End With
    ws.Columns("A:A").ColumnWidth = 8
    ws.Columns("B:B").ColumnWidth = 16
    For c = 3 To lastCol
        If (c - 3) Mod 2 = 0 Then ws.Columns(c).ColumnWidth = 9 Else ws.Columns(c).ColumnWidth = 34
    Next c
    ws.Rows("1:5").RowHeight = 23
    ws.Rows("6:" & lastDataRow).RowHeight = 42
    PolishTimelineOutput ws, lastDataRow, lastCol
End Sub

Private Sub PolishTimelineOutput(ByVal ws As Worksheet, ByVal lastDataRow As Long, ByVal lastCol As Long)
    Dim fitWide As Long
    If ws Is Nothing Then Exit Sub
    fitWide = 1
    If lastCol > 14 Then fitWide = 2
    If lastCol > 22 Then fitWide = 3
    ThemeApplyPrintTable ws.Range(ws.Cells(3, 1), ws.Cells(lastDataRow, lastCol)), 3
    ThemeCapRowHeights ws.Range(ws.Cells(6, 1), ws.Cells(lastDataRow, lastCol)), 32, 84
    ThemeApplyMonochromePrint ws, ws.Range(ws.Cells(1, 1), ws.Cells(lastDataRow, lastCol)).Address, True, "$1:$5", fitWide, 0
    On Error Resume Next
    ws.PageSetup.PrintTitleColumns = "$A:$B"
    On Error GoTo 0
End Sub

Private Function AgeForYear(ByVal birthDate As Variant, ByVal deathDate As Variant, ByVal y As Long) As String
    If Not IsDate(birthDate) Then AgeForYear = "": Exit Function
    If Year(CDate(birthDate)) > y Then AgeForYear = "出生前": Exit Function
    If IsDate(deathDate) And Year(CDate(deathDate)) < y Then AgeForYear = "死亡済": Exit Function
    Dim baseDate As Date
    If IsDate(deathDate) And Year(CDate(deathDate)) = y Then baseDate = CDate(deathDate) Else baseDate = DateSerial(y, 12, 31)
    AgeForYear = AgeOnDate(birthDate, baseDate)
End Function

Private Function EventsForPersonYear(ByVal personId As String, ByVal y As Long) As String
    Dim we As Worksheet, r As Long, s As String
    Set we = ThisWorkbook.Worksheets(SH_W_EVENT)
    For r = 2 To LastRow(we, 1)
        If CStr(we.Cells(r, E_PERSON_ID).Value) = personId And CLng(Val(we.Cells(r, E_YEAR).Value)) = y And CStr(we.Cells(r, E_STATUS).Value) <> STATUS_CANCEL Then
            If Len(s) > 0 Then s = s & vbLf
            If IsDate(we.Cells(r, E_DATE).Value) Then s = s & Format(we.Cells(r, E_DATE).Value, "m/d") & " "
            s = s & we.Cells(r, E_CONTENT).Value
        End If
    Next r
    EventsForPersonYear = s
End Function

Private Sub BuildPersonList()
    Dim ws As Worksheet, src As Worksheet
    Dim lastR As Long
    Set ws = ThisWorkbook.Worksheets(SH_PERSON_LIST)
    Set src = ThisWorkbook.Worksheets(SH_W_PERSON)
    ClearSheetAll ws
    ws.Range("A1:K1").Merge
    SectionStyle ws.Range("A1:K1"), "人物一覧"
    AddButton ws, "L1", "入力へ戻る", "ShowOnlyInput", 90, 24
    lastR = LastRow(src, 1)
    If lastR < 1 Then lastR = 1
    ws.Range("A3").Resize(lastR, 21).Value = src.Range("A1:U" & CStr(lastR)).Value
    HeaderStyle ws.Range("A3:U3")
    ws.Columns.AutoFit
    CapColumnWidths ws, 1, 21, 34
    PolishSimplePersonOutput ws, lastR + 2, 21, "$3:$3"
End Sub


Private Sub PolishSimplePersonOutput(ByVal ws As Worksheet, ByVal lastR As Long, ByVal lastC As Long, ByVal repeatRows As String)
    If ws Is Nothing Then Exit Sub
    If lastR < 1 Or lastC < 1 Then Exit Sub
    On Error Resume Next
    ThemeApplyPrintTable ws.Range(ws.Cells(3, 1), ws.Cells(lastR, lastC)), 1
    ThemeCapRowHeights ws.Range(ws.Cells(4, 1), ws.Cells(lastR, lastC)), 18, 72
    ThemeApplyMonochromePrint ws, ws.Range(ws.Cells(1, 1), ws.Cells(lastR, lastC)).Address, True, repeatRows, 1, 0
    On Error GoTo 0
End Sub

Public Sub SaveCommonData()

    On Error GoTo EH

    Dim folderPath As String, outPath As String, wb As Workbook, shNames As Variant, tNames As Variant, i As Long

    AppBegin

    folderPath = ThisWorkbook.Path

    If Len(folderPath) = 0 Then

        MsgBox "先にこのブックを案件フォルダへ保存してください。", vbExclamation

        GoTo CleanExit

    End If

    GenerateEvents

    BuildCohabitationTable

    ApplyOutputUsability

    outPath = folderPath & Application.PathSeparator & "00_共通データ.xlsx"

    Set wb = Workbooks.Add(xlWBATWorksheet)

    shNames = Array(SH_CONFIG, SH_W_PERSON, SH_W_REL, SH_W_ADDR_CAND, SH_W_ADDR_HIST, SH_COHAB, SH_W_EVENT)

    tNames = Array("T_設定_原本", "T_人物", "T_関係", "T_住所候補", "T_住所履歴", "T_同居推定", "T_イベント")

    For i = LBound(shNames) To UBound(shNames)

        If i = 0 Then

            wb.Worksheets(1).Name = tNames(i)

        Else

            wb.Worksheets.Add After:=wb.Worksheets(wb.Worksheets.Count)

            wb.Worksheets(wb.Worksheets.Count).Name = tNames(i)

        End If

        If CStr(tNames(i)) = "T_同居推定" Then

            WriteCohabCommonTable wb.Worksheets(tNames(i))

        Else

            CopySheetValuesToCommonWorkbook ThisWorkbook.Worksheets(shNames(i)), wb.Worksheets(tNames(i))

            wb.Worksheets(tNames(i)).Columns.AutoFit
            CapUsedColumnWidths wb.Worksheets(tNames(i)), 42

        End If

    Next i

    AddCommonDataControlSheets wb

    Application.CutCopyMode = False

    PrepareOutputPathWithBackup outPath
    wb.SaveAs Filename:=outPath, FileFormat:=xlOpenXMLWorkbook

    wb.Close SaveChanges:=False

    LogAction "共通データ保存", outPath

    MsgBox "共通データを保存しました。後続ツールはこのファイルのT_人物、T_住所履歴、T_同居推定、T_連携設定を読み込みます。" & vbCrLf & outPath, vbInformation

CleanExit:

    AppEnd

    Exit Sub

EH:

    AppEnd

    MsgBox "共通データ保存でエラー: " & Err.Description, vbExclamation

End Sub




Private Sub CopySheetValuesToCommonWorkbook(ByVal src As Worksheet, ByVal dst As Worksheet)
    'UsedRange/Clipboardを使わず、実データ範囲だけを配列転記する。
    Dim lastR As Long, lastC As Long
    If src Is Nothing Or dst Is Nothing Then Exit Sub
    lastR = LastNonEmptyRow(src)
    lastC = LastNonEmptyColumn(src)
    If lastR < 1 Or lastC < 1 Then Exit Sub
    With dst.Range("A1").Resize(lastR, lastC)
        .Value = src.Range(src.Cells(1, 1), src.Cells(lastR, lastC)).Value
        .NumberFormat = src.Range(src.Cells(1, 1), src.Cells(lastR, lastC)).NumberFormat
    End With
End Sub

Private Function LastNonEmptyRow(ByVal ws As Worksheet) As Long
    Dim f As Range
    If ws Is Nothing Then Exit Function
    On Error Resume Next
    Set f = ws.Cells.Find(What:="*", LookIn:=xlFormulas, SearchOrder:=xlByRows, SearchDirection:=xlPrevious)
    On Error GoTo 0
    If Not f Is Nothing Then LastNonEmptyRow = f.Row
End Function

Private Function LastNonEmptyColumn(ByVal ws As Worksheet) As Long
    Dim f As Range
    If ws Is Nothing Then Exit Function
    On Error Resume Next
    Set f = ws.Cells.Find(What:="*", LookIn:=xlFormulas, SearchOrder:=xlByColumns, SearchDirection:=xlPrevious)
    On Error GoTo 0
    If Not f Is Nothing Then LastNonEmptyColumn = f.Column
End Function

Private Sub WriteCohabCommonTable(ByVal dst As Worksheet)
    '後続分析ツールが確実に人物IDで同居推定を参照できるよう、
    '表示用の同居推定表ではなく、ID付き・1行目ヘッダーの連携専用表として保存する。
    Dim wa As Worksheet, r1 As Long, r2 As Long, outR As Long, coNo As Long
    Dim s1 As Variant, e1 As Variant, s2 As Variant, e2 As Variant, st As Variant, en As Variant
    Dim p1 As String, p2 As String, judge As String

    dst.Cells.Clear
    SetRowValues dst.Range("A1"), Array("同居推定ID", "人物ID_A", "人物A", "続柄A", "人物ID_B", "人物B", "続柄B", "住所", "住所キー", "同居推定開始", "同居推定終了", "期間", "判定")
    HeaderStyle dst.Range("A1:M1")

    Set wa = ThisWorkbook.Worksheets(SH_W_ADDR_HIST)
    outR = 2
    coNo = 1
    For r1 = 2 To LastRow(wa, 1)
        If CStr(wa.Cells(r1, A_STATUS).Value) <> STATUS_CANCEL And Len(CStr(wa.Cells(r1, A_KEY).Value)) > 0 Then
            For r2 = r1 + 1 To LastRow(wa, 1)
                If CStr(wa.Cells(r2, A_STATUS).Value) <> STATUS_CANCEL And wa.Cells(r1, A_KEY).Value = wa.Cells(r2, A_KEY).Value And wa.Cells(r1, A_PERSON_ID).Value <> wa.Cells(r2, A_PERSON_ID).Value Then
                    p1 = CStr(wa.Cells(r1, A_PERSON_ID).Value)
                    p2 = CStr(wa.Cells(r2, A_PERSON_ID).Value)
                    s1 = wa.Cells(r1, A_START).Value: e1 = EffectiveEndDate(r1)
                    s2 = wa.Cells(r2, A_START).Value: e2 = EffectiveEndDate(r2)
                    judge = "同居推定・期間要確認"
                    st = "": en = ""
                    If IsDate(s1) And IsDate(e1) And IsDate(s2) And IsDate(e2) Then
                        st = IIf(CDate(s1) > CDate(s2), s1, s2)
                        en = IIf(CDate(e1) < CDate(e2), e1, e2)
                        If CDate(st) <= CDate(en) Then
                            judge = "同居推定"
                        Else
                            GoTo NextPair
                        End If
                    End If
                    dst.Cells(outR, 1).Value = "CO" & Format(coNo, "000000")
                    dst.Cells(outR, 2).Value = p1
                    dst.Cells(outR, 3).Value = GetPersonValue(p1, P_DISPLAY)
                    dst.Cells(outR, 4).Value = GetPersonValue(p1, P_REL_DEC)
                    dst.Cells(outR, 5).Value = p2
                    dst.Cells(outR, 6).Value = GetPersonValue(p2, P_DISPLAY)
                    dst.Cells(outR, 7).Value = GetPersonValue(p2, P_REL_DEC)
                    dst.Cells(outR, 8).Value = wa.Cells(r1, A_TEXT).Value
                    dst.Cells(outR, 9).Value = wa.Cells(r1, A_KEY).Value
                    dst.Cells(outR, 10).Value = st
                    dst.Cells(outR, 11).Value = en
                    dst.Cells(outR, 12).Value = PeriodText(st, en)
                    dst.Cells(outR, 13).Value = judge
                    coNo = coNo + 1
                    outR = outR + 1
                End If
NextPair:
            Next r2
        End If
    Next r1
    If outR > 2 Then dst.Range("J2:K" & CStr(outR - 1)).NumberFormatLocal = "yyyy/m/d"
    dst.Columns.AutoFit
    CapUsedColumnWidths dst, 42
End Sub


Private Sub AddCommonDataControlSheets(ByVal wb As Workbook)

    Dim ws As Worksheet, decId As String, inheritDate As Variant, baseDate As Variant

    decId = GetDecedentId()

    inheritDate = GetInheritanceDate()

    baseDate = ThisWorkbook.Worksheets(SH_CONFIG).Range(CELL_CONFIG_BASE_DATE).Value



    Set ws = wb.Worksheets.Add(Before:=wb.Worksheets(1))

    ws.Name = "T_連携設定"

    ws.Range("A1:C1").Value = Array("キー", "値", "説明")

    ws.Range("A2:C2").Value = Array("スキーマバージョン", "common-data-v1.1", "互換用。共通データ全体のスキーマバージョン")

    ws.Range("A3:C3").Value = Array("共通スキーマバージョン", "common-data-v1.1", "4ツール共通の固定スキーマ")

    ws.Range("A4:C4").Value = Array("人物スキーマバージョン", "PERSON_INFO_V8", "人物住所時系列ツールの出力仕様")

    ws.Range("A5:C5").Value = Array("資金スキーマバージョン", "未作成", "02ツール保存後に T_資金連携設定 で更新・確認する")

    ws.Range("A6:C6").Value = Array("分析スキーマバージョン", "未作成", "03ツール保存後に T_分析連携設定 で更新・確認する")

    ws.Range("A7:C7").Value = Array("伝票依頼スキーマバージョン", "未作成", "04ツール保存後に T_伝票依頼連携設定 で更新・確認する")

    ws.Range("A8:C8").Value = Array("案件ID", "使用しない", "1案件1フォルダ運用のため案件IDは持たない")

    ws.Range("A9:C9").Value = Array("被相続人人物ID", decId, "T_人物の人物ID。資金系で被相続人口座を判定する")

    ws.Range("A10:C10").Value = Array("相続開始日", inheritDate, "相続関連シフト判定に使う")

    ws.Range("A11:C11").Value = Array("作成基準日", baseDate, "住所終了日補完・時系列最終年に使う")

    ws.Range("A12:C12").Value = Array("保存日時", Now, "この共通データを作成した日時")

    ws.Range("A13:C13").Value = Array("後続ツール", "02_資金操作表_残高推移表作成補助ツール;03_資金移動分析ツール;04_伝票依頼表作成ツール", "読み込み側の想定")

    ws.Range("A14:C14").Value = Array("主要キー", "人物ID;住所キー;口座ID;取引ID;同居推定ID", "各ツール間の連携キー")

    ws.Range("A1:C1").Font.Bold = True

    ws.Range("A1:C1").Interior.Color = ThemeColor("text")

    ws.Range("A1:C1").Font.Color = vbWhite

    ws.Columns("A:C").AutoFit



    Set ws = wb.Worksheets.Add(After:=wb.Worksheets("T_連携設定"))

    ws.Name = "T_共通データ索引"

    ws.Range("A1:D1").Value = Array("テーブル名", "主キー", "主な用途", "後続ツール")

    ws.Range("A2:D2").Value = Array("T_人物", "人物ID", "口座名義人候補、続柄表示、被相続人判定", "資金関係・分析・依頼")

    ws.Range("A3:D3").Value = Array("T_関係", "関係ID", "配偶者・親子・婚姻日・離婚日の参照", "分析・時系列")

    ws.Range("A4:D4").Value = Array("T_住所候補", "住所候補ID", "住所再利用・住所キー管理", "分析")

    ws.Range("A5:D5").Value = Array("T_住所履歴", "住所ID", "住所移転・同居推定・相続開始時住所", "分析")

    ws.Range("A6:D6").Value = Array("T_同居推定", "同居推定ID", "住所キー一致かつ期間重複の結果", "分析")

    ws.Range("A7:D7").Value = Array("T_イベント", "イベントID", "時系列・後続イベント追加の土台", "分析")

    ws.Range("A8:D8").Value = Array("T_連携設定", "キー", "相続開始日、被相続人人物ID、共通・人物別スキーマバージョン", "全ツール")

    ws.Range("A1:D1").Font.Bold = True

    ws.Range("A1:D1").Interior.Color = ThemeColor("text")

    ws.Range("A1:D1").Font.Color = vbWhite

    ws.Columns("A:D").AutoFit

End Sub



Public Sub ExportPersonInfoWorkbook()
    On Error GoTo EH
    Dim outFolder As String, outPath As String, wb As Workbook, shNames As Variant, i As Long
    AppBegin
    outFolder = EnsureOutputFolder()
    If Len(outFolder) = 0 Then
        MsgBox "先にこのブックを案件フォルダへ保存してください。", vbExclamation
        GoTo CleanExit
    End If
    outPath = outFolder & Application.PathSeparator & "01_人物情報整理資料.xlsx"
    GenerateEvents
    BuildConfirmList
    RunChecks
    BuildRelationshipDiagram
    BuildAddressHistoryTable
    BuildCohabitationTable
    BuildTimelineTable
    BuildPersonList
    ApplyOutputUsability
    shNames = Array(SH_DIAGRAM, SH_ADDR_TABLE, SH_COHAB, SH_TIMELINE, SH_PERSON_LIST, SH_CONFIRM, SH_CHECK)
    Set wb = Workbooks.Add(xlWBATWorksheet)
    For i = LBound(shNames) To UBound(shNames)
        ThisWorkbook.Worksheets(CStr(shNames(i))).Copy After:=wb.Worksheets(wb.Worksheets.Count)
        wb.Worksheets(wb.Worksheets.Count).Name = CStr(shNames(i))
    Next i
    Application.DisplayAlerts = False
    wb.Worksheets(1).Delete
    Application.DisplayAlerts = True
    DeleteUiButtonsInWorkbook wb
    Application.CutCopyMode = False
    PrepareOutputPathWithBackup outPath
    wb.SaveAs Filename:=outPath, FileFormat:=xlOpenXMLWorkbook
    wb.Close SaveChanges:=False
    LogAction "人物情報整理資料出力", outPath
    MsgBox "人物情報整理資料を出力しました: " & outPath, vbInformation
CleanExit:
    AppEnd
    Exit Sub
EH:
    On Error Resume Next
    Application.DisplayAlerts = True
    If Not wb Is Nothing Then wb.Close SaveChanges:=False
    AppEnd
    MsgBox "出力でエラー: " & Err.Description, vbExclamation
End Sub

Private Sub DeleteUiButtonsInWorkbook(ByVal wb As Workbook)
    Dim ws As Worksheet, i As Long
    On Error Resume Next
    For Each ws In wb.Worksheets
        For i = ws.Shapes.Count To 1 Step -1
            If Left$(ws.Shapes(i).Name, 4) = "btn_" Then ws.Shapes(i).Delete
        Next i
    Next ws
    On Error GoTo 0
End Sub

Private Sub LogAction(ByVal actionName As String, ByVal detail As String)
    Dim ws As Worksheet, r As Long
    Set ws = ThisWorkbook.Worksheets(SH_W_LOG)
    r = NextBlankRow(ws, 1)
    ws.Cells(r, 1).Value = Now
    ws.Cells(r, 2).Value = actionName
    ws.Cells(r, 3).Value = detail
End Sub

Private Sub PrepareOutputPathWithBackup(ByVal filePath As String)
    Dim backupPath As String
    If Len(filePath) = 0 Then Exit Sub
    If Len(Dir$(filePath)) = 0 Then Exit Sub
    backupPath = filePath & ".bak_" & Format$(Now, "yyyymmdd_hhnnss")
    FileCopy filePath, backupPath
    Kill filePath
    LogAction "既存ファイルバックアップ", backupPath
End Sub

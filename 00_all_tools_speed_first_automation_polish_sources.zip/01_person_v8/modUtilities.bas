Attribute VB_Name = "modUtilities"
Option Explicit

Private mAppDepth As Long
Private mPrevScreenUpdating As Boolean
Private mPrevEnableEvents As Boolean
Private mPrevDisplayAlerts As Boolean
Private mPrevCalculation As XlCalculation
Private mPrevStatusBar As Variant

Public Sub AppBegin(Optional ByVal statusText As String = "処理中...")
    ' 入れ子呼出しに対応してExcel状態を安全に制御する。
    On Error Resume Next
    If mAppDepth = 0 Then
        mPrevScreenUpdating = Application.ScreenUpdating
        mPrevEnableEvents = Application.EnableEvents
        mPrevDisplayAlerts = Application.DisplayAlerts
        mPrevCalculation = Application.Calculation
        mPrevStatusBar = Application.StatusBar
        Application.ScreenUpdating = False
        Application.EnableEvents = False
        Application.DisplayAlerts = False
        Application.Calculation = xlCalculationManual
    End If
    mAppDepth = mAppDepth + 1
    Application.StatusBar = statusText
    On Error GoTo 0
End Sub

Public Sub AppEnd()
    On Error Resume Next
    If mAppDepth > 0 Then mAppDepth = mAppDepth - 1
    If mAppDepth = 0 Then
        Application.Calculation = mPrevCalculation
        Application.DisplayAlerts = mPrevDisplayAlerts
        Application.EnableEvents = mPrevEnableEvents
        Application.ScreenUpdating = mPrevScreenUpdating
        Application.StatusBar = mPrevStatusBar
    End If
    On Error GoTo 0
End Sub

Public Sub AppForceRestore()
    ' エラー中断後の緊急復旧。
    On Error Resume Next
    mAppDepth = 0
    Application.Calculation = xlCalculationAutomatic
    Application.DisplayAlerts = True
    Application.EnableEvents = True
    Application.ScreenUpdating = True
    Application.StatusBar = False
    On Error GoTo 0
End Sub

Public Function SheetExists(ByVal sheetName As String, Optional ByVal wb As Workbook) As Boolean
    Dim ws As Worksheet
    If wb Is Nothing Then Set wb = ThisWorkbook
    On Error Resume Next
    Set ws = wb.Worksheets(sheetName)
    SheetExists = Not ws Is Nothing
    On Error GoTo 0
End Function

Public Function EnsureSheet(ByVal sheetName As String, Optional ByVal visibleState As XlSheetVisibility = xlSheetVisible) As Worksheet
    If SheetExists(sheetName, ThisWorkbook) Then
        Set EnsureSheet = ThisWorkbook.Worksheets(sheetName)
    Else
        Set EnsureSheet = ThisWorkbook.Worksheets.Add(After:=ThisWorkbook.Worksheets(ThisWorkbook.Worksheets.Count))
        EnsureSheet.Name = sheetName
    End If
    EnsureSheet.Visible = visibleState
End Function

Public Sub ClearSheetAll(ByVal ws As Worksheet)
    '出力シートは保護済みのことがあるため、再生成前に必ず保護を解除する。
    On Error Resume Next
    ws.Unprotect Password:=TOOL_PASSWORD
    ws.ScrollArea = ""
    ws.Cells.Clear
    ws.Buttons.Delete
    ws.Shapes.Delete
    ws.Cells.Locked = False
    On Error GoTo 0
End Sub

Public Function LastRow(ByVal ws As Worksheet, Optional ByVal col As Long = 1) As Long
    Dim r As Long
    r = ws.Cells(ws.Rows.Count, col).End(xlUp).Row
    If r < 1 Then r = 1
    LastRow = r
End Function

Public Function NextBlankRow(ByVal ws As Worksheet, Optional ByVal col As Long = 1) As Long
    Dim r As Long
    r = LastRow(ws, col)
    If r = 1 And Len(CStr(ws.Cells(1, col).Value)) = 0 Then
        NextBlankRow = 1
    Else
        NextBlankRow = r + 1
    End If
End Function

Public Sub SetRowValues(ByVal firstCell As Range, ByVal arr As Variant)
    Dim i As Long
    For i = LBound(arr) To UBound(arr)
        firstCell.Offset(0, i - LBound(arr)).Value = arr(i)
    Next i
End Sub

Public Sub HeaderStyle(ByVal rng As Range, Optional ByVal fillColor As Long = 0)
    ThemeApplyHeader rng, fillColor
End Sub

Public Sub SectionStyle(ByVal rng As Range, Optional ByVal titleText As String = "")
    ThemeApplySection rng, titleText
End Sub

Public Sub InputStyle(ByVal rng As Range)
    ThemeApplyInput rng
End Sub

Public Sub LockedStyle(ByVal rng As Range)
    ThemeApplyLocked rng
End Sub

Public Sub ApplySheetCanvas(ByVal ws As Worksheet)
    ThemeApplyCanvas ws
End Sub

Public Sub TitleBannerStyle(ByVal rng As Range, Optional ByVal titleText As String = "")
    ThemeApplyTitle rng, titleText
End Sub

Public Sub FlowBarStyle(ByVal rng As Range)
    If rng Is Nothing Then Exit Sub
    With rng
        .Interior.Color = ThemeColor("flow")
        .Font.Name = THEME_FONT
        .Font.Bold = True
        .Font.Color = ThemeColor("teal")
        .HorizontalAlignment = xlCenter
        .VerticalAlignment = xlCenter
        .Borders.LineStyle = xlContinuous
        .Borders.Color = ThemeColor("border")
    End With
End Sub

Public Sub PanelBorderStyle(ByVal rng As Range)
    If rng Is Nothing Then Exit Sub
    With rng
        .Borders.LineStyle = xlContinuous
        .Borders.Color = ThemeColor("border-soft")
    End With
End Sub

Private Function ButtonFillColor(ByVal caption As String) As Long
    ButtonFillColor = ThemeButtonFill(caption)
End Function

Public Sub AddButton(ByVal ws As Worksheet, ByVal cellAddress As String, ByVal caption As String, ByVal macroName As String, Optional ByVal width As Double = 120, Optional ByVal height As Double = 28)
    Dim c As Range, shp As Shape, b As Button
    Set c = ws.Range(cellAddress)
    On Error GoTo UseFormButton
    Set shp = ws.Shapes.AddShape(msoShapeRoundedRectangle, c.Left, c.Top, width, height)
    shp.Name = "btn_" & Replace(caption, " ", "_") & "_" & Format(Timer * 100, "0")
    ThemeStyleButtonShape shp, caption, "", macroName
    Exit Sub
UseFormButton:
    Err.Clear
    On Error Resume Next
    Set b = ws.Buttons.Add(c.Left, c.Top, width, height)
    With b
        .Caption = caption
        .OnAction = macroName
        .Font.Name = THEME_FONT
        .Font.Size = 10
        .Font.Bold = True
        .Placement = xlFreeFloating
        .Locked = True
        .PrintObject = False
    End With
    On Error GoTo 0
End Sub

Public Sub CapColumnWidths(ByVal ws As Worksheet, ByVal firstCol As Long, ByVal lastCol As Long, ByVal maxWidth As Double)
    Dim c As Long
    On Error Resume Next
    For c = firstCol To lastCol
        If ws.Columns(c).ColumnWidth > maxWidth Then ws.Columns(c).ColumnWidth = maxWidth
    Next c
    On Error GoTo 0
End Sub

Public Sub CapUsedColumnWidths(ByVal ws As Worksheet, Optional ByVal maxWidth As Double = 38)
    Dim lastC As Long
    Dim f As Range
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    Set f = ws.Cells.Find(What:="*", LookIn:=xlFormulas, SearchOrder:=xlByColumns, SearchDirection:=xlPrevious)
    If Not f Is Nothing Then lastC = f.Column
    If lastC > 0 Then CapColumnWidths ws, 1, lastC, maxWidth
    On Error GoTo 0
End Sub

Public Function CleanText(ByVal v As Variant) As String
    CleanText = Trim(CStr(v))
End Function

Public Function ComposeDisplayName(ByVal surname As String, ByVal givenName As String, ByVal formerSurname As String) As String
    Dim nm As String
    nm = Trim(surname & " " & givenName)
    If Len(formerSurname) > 0 Then nm = nm & "（旧姓：" & formerSurname & "）"
    ComposeDisplayName = nm
End Function

Public Function ParseIdFromCandidate(ByVal s As String) As String
    Dim p As Long
    s = Trim(s)
    p = InStr(1, s, " ")
    If p > 1 Then
        ParseIdFromCandidate = Left$(s, p - 1)
    ElseIf InStr(1, s, ":") > 1 Then
        ParseIdFromCandidate = Left$(s, InStr(1, s, ":") - 1)
    Else
        ParseIdFromCandidate = s
    End If
End Function

Public Function NormalizeAddress(ByVal addressText As String) As String
    Dim s As String
    s = Trim(addressText)
    On Error Resume Next
    s = StrConv(s, vbNarrow)
    On Error GoTo 0
    s = Replace(s, " ", "")
    s = Replace(s, "　", "")
    s = Replace(s, "－", "-")
    s = Replace(s, "ー", "-")
    s = Replace(s, "－", "-")
    s = Replace(s, "丁目", "-")
    s = Replace(s, "番地", "-")
    s = Replace(s, "番", "-")
    s = Replace(s, "号", "")
    s = Replace(s, "の", "-")
    Do While InStr(s, "--") > 0
        s = Replace(s, "--", "-")
    Loop
    If Right$(s, 1) = "-" Then s = Left$(s, Len(s) - 1)
    NormalizeAddress = s
End Function

Public Function SameDateOrBlank(ByVal v As Variant) As Variant
    If IsDate(v) Then SameDateOrBlank = CDate(v) Else SameDateOrBlank = ""
End Function

Public Function AgeOnDate(ByVal birthDate As Variant, ByVal baseDate As Variant) As String
    If Not IsDate(birthDate) Or Not IsDate(baseDate) Then
        AgeOnDate = ""
        Exit Function
    End If
    Dim age As Long
    age = Year(CDate(baseDate)) - Year(CDate(birthDate))
    If DateSerial(Year(CDate(baseDate)), Month(CDate(birthDate)), Day(CDate(birthDate))) > CDate(baseDate) Then age = age - 1
    AgeOnDate = CStr(age) & "歳"
End Function

Public Function PeriodText(ByVal startDate As Variant, ByVal endDate As Variant) As String
    If Not IsDate(startDate) Or Not IsDate(endDate) Then
        PeriodText = "期間要確認"
        Exit Function
    End If
    Dim s As Date, e As Date, y As Long, m As Long, d As Long, tmp As Date
    s = CDate(startDate): e = CDate(endDate)
    If e < s Then
        PeriodText = "期間要確認"
        Exit Function
    End If
    y = Year(e) - Year(s)
    tmp = DateAdd("yyyy", y, s)
    If tmp > e Then
        y = y - 1
        tmp = DateAdd("yyyy", y, s)
    End If
    m = DateDiff("m", tmp, e)
    If DateAdd("m", m, tmp) > e Then m = m - 1
    tmp = DateAdd("m", m, tmp)
    d = DateDiff("d", tmp, e) + 1
    PeriodText = y & "年" & m & "か月" & d & "日"
End Function



Public Function EraYearText(ByVal westernYear As Long) As String
    Select Case westernYear
        Case 2019
            EraYearText = "平成31年／令和元年"
        Case 1989
            EraYearText = "昭和64年／平成元年"
        Case 1926
            EraYearText = "大正15年／昭和元年"
        Case 1912
            EraYearText = "明治45年／大正元年"
        Case Is >= 2020
            EraYearText = "令和" & CStr(westernYear - 2018) & "年"
        Case Is >= 1990
            EraYearText = "平成" & CStr(westernYear - 1988) & "年"
        Case Is >= 1927
            EraYearText = "昭和" & CStr(westernYear - 1925) & "年"
        Case Is >= 1913
            EraYearText = "大正" & CStr(westernYear - 1911) & "年"
        Case Is >= 1868
            EraYearText = "明治" & CStr(westernYear - 1867) & "年"
        Case Else
            EraYearText = "西暦" & CStr(westernYear) & "年"
    End Select
End Function

Public Function EraDateText(ByVal v As Variant) As String
    If Not IsDate(v) Then
        EraDateText = ""
        Exit Function
    End If
    Dim d As Date, eraName As String, eraYear As Long
    d = CDate(v)
    If d >= DateSerial(2019, 5, 1) Then
        eraName = "令和": eraYear = Year(d) - 2018
    ElseIf d >= DateSerial(1989, 1, 8) Then
        eraName = "平成": eraYear = Year(d) - 1988
    ElseIf d >= DateSerial(1926, 12, 25) Then
        eraName = "昭和": eraYear = Year(d) - 1925
    ElseIf d >= DateSerial(1912, 7, 30) Then
        eraName = "大正": eraYear = Year(d) - 1911
    ElseIf d >= DateSerial(1868, 1, 25) Then
        eraName = "明治": eraYear = Year(d) - 1867
    Else
        EraDateText = Format(d, "yyyy/m/d")
        Exit Function
    End If
    If eraYear = 1 Then
        EraDateText = eraName & "元年" & Month(d) & "月" & Day(d) & "日"
    Else
        EraDateText = eraName & eraYear & "年" & Month(d) & "月" & Day(d) & "日"
    End If
End Function

Public Function EnsureOutputFolder() As String
    Dim basePath As String, outPath As String
    basePath = ThisWorkbook.Path
    If Len(basePath) = 0 Then
        EnsureOutputFolder = ""
        Exit Function
    End If
    outPath = basePath & Application.PathSeparator & "出力"
    If Dir(outPath, vbDirectory) = "" Then MkDir outPath
    EnsureOutputFolder = outPath
End Function

Public Function QuoteSheet(ByVal sheetName As String) As String
    QuoteSheet = "'" & Replace(sheetName, "'", "''") & "'"
End Function

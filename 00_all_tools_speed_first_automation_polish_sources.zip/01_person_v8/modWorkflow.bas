Attribute VB_Name = "modWorkflow"
Option Explicit

Public Sub BeginDecedentEntry()
    PrepareInput MODE_DECEDENT
End Sub
Public Sub BeginAddSpouse()
    PrepareInput MODE_SPOUSE
End Sub
Public Sub BeginAddFather()
    PrepareInput MODE_FATHER
End Sub
Public Sub BeginAddMother()
    PrepareInput MODE_MOTHER
End Sub
Public Sub BeginAddChild()
    PrepareInput MODE_CHILD
End Sub
Public Sub BeginAddSibling()
    PrepareInput MODE_SIBLING
End Sub
Public Sub BeginAddGrandchild()
    PrepareInput MODE_GRANDCHILD
End Sub
Public Sub BeginAddOther()
    PrepareInput MODE_OTHER
End Sub

Private Sub PrepareInput(ByVal modeName As String)
    Dim ws As Worksheet, baseId As String, autoSurname As String
    Set ws = ThisWorkbook.Worksheets(SH_INPUT)
    If modeName <> MODE_DECEDENT Then
        baseId = CleanText(ws.Range(CELL_BASE_ID).Value)
        If Len(baseId) = 0 Then
            MsgBox "先に基準人物を選んでください。被相続人登録後は自動で基準人物になります。", vbExclamation
            Exit Sub
        End If
    End If
    ws.Range(CELL_PERSON_ID & ":" & CELL_NOTE).ClearContents
    ws.Range(CELL_ADDR_CAND & ":" & CELL_ADDR_NOTE).ClearContents
    ws.Range(CELL_MODE).Value = modeName
    ws.Range(CELL_SHOW_DIAGRAM).Value = SHOW_YES

    autoSurname = SuggestSurname(modeName, baseId)
    ws.Range(CELL_AUTO_SURNAME).Value = autoSurname
    ws.Range(CELL_SURNAME).Value = autoSurname
    ws.Range(CELL_GIVEN_NAME).Select

    Select Case modeName
        Case MODE_DECEDENT
            ws.Range(CELL_REL_TO_DECEDENT).Value = MODE_DECEDENT
            ws.Range(CELL_SURNAME).ClearContents
        Case MODE_SPOUSE
            ws.Range(CELL_REL_TO_DECEDENT).Value = "配偶者"
            ws.Range(CELL_FORMER_SURNAME).Interior.Color = ThemeColor("warning-soft")
        Case MODE_FATHER
            ws.Range(CELL_REL_TO_DECEDENT).Value = "父"
        Case MODE_MOTHER
            ws.Range(CELL_REL_TO_DECEDENT).Value = "母"
            ws.Range(CELL_FORMER_SURNAME).Interior.Color = ThemeColor("warning-soft")
        Case MODE_CHILD
            ws.Range(CELL_REL_TO_DECEDENT).Value = "子"
        Case MODE_SIBLING
            ws.Range(CELL_REL_TO_DECEDENT).Value = "兄弟姉妹"
        Case MODE_GRANDCHILD
            ws.Range(CELL_REL_TO_DECEDENT).Value = "孫"
        Case Else
            ws.Range(CELL_REL_TO_DECEDENT).Value = "関係者"
    End Select
    CopyBaseCurrentAddress False
    UpdateInputGuide modeName
End Sub

Public Sub ClearPersonInput()
    Dim ws As Worksheet
    Set ws = ThisWorkbook.Worksheets(SH_INPUT)
    ws.Range(CELL_PERSON_ID & ":" & CELL_NOTE).ClearContents
    ws.Range(CELL_ADDR_CAND & ":" & CELL_ADDR_NOTE).ClearContents
    ws.Range(CELL_SHOW_DIAGRAM).Value = SHOW_YES
End Sub

Private Function SuggestSurname(ByVal modeName As String, ByVal baseId As String) As String
    Dim decId As String, s As String
    If modeName = MODE_OTHER Then
        SuggestSurname = ""
        Exit Function
    End If
    If modeName = MODE_DECEDENT Then
        SuggestSurname = ""
        Exit Function
    End If
    If Len(baseId) > 0 Then s = GetPersonValue(baseId, P_SURNAME)
    decId = GetDecedentId()
    Select Case modeName
        Case MODE_FATHER, MODE_MOTHER, MODE_SIBLING
            If Len(decId) > 0 Then SuggestSurname = GetPersonValue(decId, P_SURNAME) Else SuggestSurname = s
        Case Else
            SuggestSurname = s
    End Select
End Function

Public Sub LoadBaseFromSelection()
    Dim ws As Worksheet, sel As String, pid As String
    Set ws = ThisWorkbook.Worksheets(SH_INPUT)
    sel = CleanText(ws.Range(CELL_BASE_SELECT).Value)
    pid = ParseIdFromCandidate(sel)
    If Len(pid) = 0 Or FindPersonRow(pid) = 0 Then
        MsgBox "基準人物候補から人物を選んでください。", vbExclamation
        Exit Sub
    End If
    SetBasePerson pid
End Sub

Public Sub SetDecedentAsBase()
    Dim pid As String
    pid = GetDecedentId()
    If Len(pid) = 0 Then
        MsgBox "被相続人がまだ登録されていません。", vbExclamation
        Exit Sub
    End If
    SetBasePerson pid
End Sub

Public Sub SetBasePerson(ByVal personId As String)
    Dim ws As Worksheet, r As Long, addr As String
    Set ws = ThisWorkbook.Worksheets(SH_INPUT)
    r = FindPersonRow(personId)
    If r = 0 Then Exit Sub
    ws.Range(CELL_BASE_ID).Value = personId
    ws.Range(CELL_BASE_NAME).Value = ThisWorkbook.Worksheets(SH_W_PERSON).Cells(r, P_DISPLAY).Value
    ws.Range(CELL_BASE_REL).Value = ThisWorkbook.Worksheets(SH_W_PERSON).Cells(r, P_REL_DEC).Value
    addr = GetCurrentAddressText(personId)
    ws.Range(CELL_BASE_ADDRESS).Value = addr
    ws.Range(CELL_BASE_SELECT).Value = personId & " " & ws.Range(CELL_BASE_NAME).Value
    If Len(CleanText(ws.Range(CELL_MODE).Value)) > 0 Then UpdateInputGuide CleanText(ws.Range(CELL_MODE).Value)
End Sub

Public Function FindPersonRow(ByVal personId As String) As Long
    Dim ws As Worksheet, r As Long, lastR As Long
    Set ws = ThisWorkbook.Worksheets(SH_W_PERSON)
    lastR = LastRow(ws, 1)
    For r = 2 To lastR
        If CStr(ws.Cells(r, P_ID).Value) = personId And CStr(ws.Cells(r, P_STATUS).Value) <> STATUS_CANCEL Then
            FindPersonRow = r
            Exit Function
        End If
    Next r
End Function

Public Function GetPersonValue(ByVal personId As String, ByVal colNum As Long) As String
    Dim r As Long
    r = FindPersonRow(personId)
    If r > 0 Then GetPersonValue = CStr(ThisWorkbook.Worksheets(SH_W_PERSON).Cells(r, colNum).Value)
End Function

Public Function GetDecedentId() As String
    Dim ws As Worksheet, r As Long, lastR As Long
    Set ws = ThisWorkbook.Worksheets(SH_W_PERSON)
    lastR = LastRow(ws, 1)
    For r = 2 To lastR
        If CStr(ws.Cells(r, P_TYPE).Value) = MODE_DECEDENT And CStr(ws.Cells(r, P_STATUS).Value) <> STATUS_CANCEL Then
            GetDecedentId = CStr(ws.Cells(r, P_ID).Value)
            Exit Function
        End If
    Next r
End Function

Public Function GetInheritanceDate() As Variant
    Dim ws As Worksheet
    Set ws = ThisWorkbook.Worksheets(SH_CONFIG)
    If IsDate(ws.Range(CELL_CONFIG_INHERIT_DATE).Value) Then
        GetInheritanceDate = ws.Range(CELL_CONFIG_INHERIT_DATE).Value
    Else
        GetInheritanceDate = ""
    End If
End Function

Public Sub RegisterInputPerson()
    On Error GoTo EH
    AppBegin
    Dim wsIn As Worksheet, wsP As Worksheet, modeName As String, pid As String, r As Long
    Dim surname As String, givenName As String, former As String, autoSurname As String
    Dim displayName As String, personType As String, relationText As String, baseId As String
    Dim gender As String, birthDate As Variant, deathDate As Variant, occupation As String, note As String
    Set wsIn = ThisWorkbook.Worksheets(SH_INPUT)
    Set wsP = ThisWorkbook.Worksheets(SH_W_PERSON)

    modeName = CleanText(wsIn.Range(CELL_MODE).Value)
    If Len(modeName) = 0 Then modeName = MODE_DECEDENT
    baseId = CleanText(wsIn.Range(CELL_BASE_ID).Value)
    If modeName <> MODE_DECEDENT And Len(baseId) = 0 Then Err.Raise 5, , "基準人物が未設定です。"

    surname = CleanText(wsIn.Range(CELL_SURNAME).Value)
    givenName = CleanText(wsIn.Range(CELL_GIVEN_NAME).Value)
    former = CleanText(wsIn.Range(CELL_FORMER_SURNAME).Value)
    autoSurname = CleanText(wsIn.Range(CELL_AUTO_SURNAME).Value)
    If Len(surname) = 0 And Len(autoSurname) > 0 Then surname = autoSurname
    If Len(givenName) = 0 Then Err.Raise 5, , "名を入力してください。"
    If Len(surname) = 0 Then Err.Raise 5, , "姓を入力してください。"
    If Len(autoSurname) > 0 And surname <> autoSurname And Len(former) = 0 Then
        former = autoSurname
        wsIn.Range(CELL_FORMER_SURNAME).Value = former
    End If
    displayName = ComposeDisplayName(surname, givenName, former)
    gender = CleanText(wsIn.Range(CELL_GENDER).Value)
    relationText = CleanText(wsIn.Range(CELL_REL_TO_DECEDENT).Value)
    If Len(relationText) = 0 Or relationText = "子" Or relationText = "兄弟姉妹" Then relationText = AutoRelationText(modeName, baseId, gender, wsIn.Range(CELL_BIRTH).Value)
    personType = IIf(modeName = MODE_DECEDENT, MODE_DECEDENT, IIf(modeName = MODE_OTHER, "関係者", "親族"))
    If modeName = MODE_CHILD Or modeName = MODE_GRANDCHILD Then personType = "相続人"
    If modeName = MODE_SPOUSE And baseId = GetDecedentId() Then personType = "相続人"
    birthDate = SameDateOrBlank(wsIn.Range(CELL_BIRTH).Value)
    deathDate = SameDateOrBlank(wsIn.Range(CELL_DEATH).Value)
    occupation = CleanText(wsIn.Range(CELL_OCCUPATION).Value)
    note = CleanText(wsIn.Range(CELL_NOTE).Value)

    pid = CleanText(wsIn.Range(CELL_PERSON_ID).Value)
    If Len(pid) = 0 Then
        pid = NextId("人物")
        r = NextBlankRow(wsP, 1)
        wsP.Cells(r, P_CREATED).Value = Now
    Else
        r = FindPersonRow(pid)
        If r = 0 Then r = NextBlankRow(wsP, 1)
    End If
    wsP.Cells(r, P_ID).Value = pid
    wsP.Cells(r, P_ORDER).Value = IIf(Len(wsP.Cells(r, P_ORDER).Value) = 0, r - 1, wsP.Cells(r, P_ORDER).Value)
    wsP.Cells(r, P_TYPE).Value = personType
    wsP.Cells(r, P_SURNAME).Value = surname
    wsP.Cells(r, P_GIVEN).Value = givenName
    wsP.Cells(r, P_FORMER).Value = former
    wsP.Cells(r, P_DISPLAY).Value = displayName
    wsP.Cells(r, P_SUR_MODE).Value = IIf(Len(autoSurname) > 0 And surname = autoSurname, "自動", "手入力")
    wsP.Cells(r, P_SUR_SRC).Value = IIf(Len(autoSurname) > 0, baseId, "")
    wsP.Cells(r, P_REL_DEC).Value = relationText
    wsP.Cells(r, P_REL_DISP).Value = relationText
    wsP.Cells(r, P_GENDER).Value = gender
    wsP.Cells(r, P_BIRTH).Value = birthDate
    wsP.Cells(r, P_DEATH).Value = deathDate
    wsP.Cells(r, P_OCC).Value = occupation
    wsP.Cells(r, P_SHOW).Value = IIf(Len(CleanText(wsIn.Range(CELL_SHOW_DIAGRAM).Value)) = 0, SHOW_YES, wsIn.Range(CELL_SHOW_DIAGRAM).Value)
    wsP.Cells(r, P_NOTE).Value = note
    wsP.Cells(r, P_STATUS).Value = STATUS_ACTIVE
    wsP.Cells(r, P_UPDATED).Value = Now
    wsIn.Range(CELL_PERSON_ID).Value = pid

    If modeName = MODE_DECEDENT Then
        ThisWorkbook.Worksheets(SH_CONFIG).Range(CELL_CONFIG_INHERIT_DATE).Value = deathDate
    Else
        AddRelationIfNeeded baseId, pid, modeName, relationText, wsIn.Range(CELL_MARRIAGE).Value, wsIn.Range(CELL_DIVORCE).Value
    End If

    RegisterAddressFromInput pid
    RefreshCandidates
    ApplyValidations
    BuildConfirmList

    Dim nextBaseId As String
    nextBaseId = RecommendedNextBase(modeName, baseId, pid)
    If Len(nextBaseId) = 0 Then nextBaseId = pid
    SetBasePerson nextBaseId
    wsIn.Range(CELL_BASE_SELECT).Value = nextBaseId & " " & GetPersonValue(nextBaseId, P_DISPLAY)
    WriteGuideAfterRegister modeName, displayName, nextBaseId
    MsgBox displayName & " を登録しました。" & vbCrLf & vbCrLf & NextActionMessage(modeName, nextBaseId), vbInformation
CleanExit:
    AppEnd
    Exit Sub
EH:
    AppEnd
    MsgBox "登録できませんでした: " & Err.Description, vbExclamation
End Sub

Private Function RecommendedNextBase(ByVal modeName As String, ByVal baseId As String, ByVal newPersonId As String) As String
    Dim decId As String
    decId = GetDecedentId()
    Select Case modeName
        Case MODE_DECEDENT
            RecommendedNextBase = newPersonId
        Case MODE_SPOUSE
            If Len(baseId) > 0 Then RecommendedNextBase = baseId Else RecommendedNextBase = decId
        Case MODE_FATHER, MODE_MOTHER, MODE_SIBLING
            If Len(decId) > 0 Then RecommendedNextBase = decId Else RecommendedNextBase = baseId
        Case MODE_CHILD
            If Len(baseId) > 0 Then RecommendedNextBase = baseId Else RecommendedNextBase = decId
        Case MODE_GRANDCHILD
            If Len(baseId) > 0 Then RecommendedNextBase = baseId Else RecommendedNextBase = newPersonId
        Case Else
            RecommendedNextBase = newPersonId
    End Select
End Function

Private Function NextActionMessage(ByVal modeName As String, ByVal nextBaseId As String) As String
    Dim baseName As String
    baseName = GetPersonValue(nextBaseId, P_DISPLAY)
    Select Case modeName
        Case MODE_DECEDENT
            NextActionMessage = "次は配偶者、父、母、子を関係ボタンから追加してください。住所はコピー候補を使えます。"
        Case MODE_SPOUSE
            NextActionMessage = "基準人物を「" & baseName & "」に戻しました。次は子、父、母などを追加してください。配偶者の旧姓確認も忘れないでください。"
        Case MODE_FATHER, MODE_MOTHER
            NextActionMessage = "基準人物を「" & baseName & "」に戻しました。次はもう一方の親、配偶者、子を追加してください。"
        Case MODE_CHILD
            NextActionMessage = "基準人物は「" & baseName & "」です。続けて子を追加できます。子の配偶者や孫を入れる場合は、その人物を基準人物にしてください。"
        Case MODE_GRANDCHILD
            NextActionMessage = "基準人物は「" & baseName & "」です。続けて孫を追加するか、被相続人に戻って他の関係者を追加してください。"
        Case Else
            NextActionMessage = "必要な住所、婚姻日、根拠は候補から再利用できます。次の関係者を選んでください。"
    End Select
End Function

Private Sub WriteGuideAfterRegister(ByVal modeName As String, ByVal displayName As String, ByVal nextBaseId As String)
    Dim ws As Worksheet, guide As String
    Set ws = ThisWorkbook.Worksheets(SH_INPUT)
    guide = "登録完了：" & displayName & vbLf & _
            NextActionMessage(modeName, nextBaseId) & vbLf & _
            "入力の原則：同じ姓・住所・婚姻日・根拠は候補から選び、同じ内容を二度入力しない。住所キーが同じなら同居推定に反映されます。"
    ws.Range("B38").Value = guide
End Sub

Private Sub UpdateInputGuide(ByVal modeName As String)
    Dim ws As Worksheet, guide As String, baseId As String, baseName As String
    Set ws = ThisWorkbook.Worksheets(SH_INPUT)
    baseId = CleanText(ws.Range(CELL_BASE_ID).Value)
    baseName = GetPersonValue(baseId, P_DISPLAY)
    Select Case modeName
        Case MODE_DECEDENT
            guide = "手順1：被相続人を登録します。姓・名・死亡日・住所を入力してください。死亡日が相続開始日になります。登録後、配偶者、父、母、子の順に関係者を追加します。"
        Case MODE_SPOUSE
            guide = "配偶者追加：現在姓は基準人物と同じ姓を初期表示します。旧姓は必ず確認してください。住所は基準人物住所コピー、開始日は婚姻日を候補として使えます。"
        Case MODE_FATHER
            guide = "父追加：姓は被相続人側の姓を初期表示します。住所は被相続人や前回住所からコピーできます。登録後は被相続人を基準に戻して次を追加します。"
        Case MODE_MOTHER
            guide = "母追加：姓は被相続人側の姓を初期表示します。旧姓を目立つ欄に入力してください。住所は父・被相続人・前回住所から候補化できます。"
        Case MODE_CHILD
            guide = "子追加：姓は親の姓を初期表示します。性別を入れると長男・長女等を自動候補化します。姓を変えた場合は旧姓に元の姓を自動補完します。"
        Case MODE_SIBLING
            guide = "兄弟姉妹追加：姓は被相続人側の姓を初期表示します。性別と生年月日があれば兄・弟・姉・妹を自動判定します。"
        Case MODE_GRANDCHILD
            guide = "孫追加：基準人物の子として登録します。姓と住所は基準人物からコピーできます。孫世代は相続関係図で子世代のさらに右側に配置します。"
        Case Else
            guide = "その他関係者：姓・住所・根拠は候補から選べます。関係や備考に、調査上の位置付けを短く入れてください。"
    End Select
    If Len(baseName) > 0 Then guide = "基準人物：" & baseName & vbLf & guide
    ws.Range("B38").Value = guide
End Sub

Private Function AutoRelationText(ByVal modeName As String, ByVal baseId As String, ByVal gender As String, ByVal birthDate As Variant) As String
    Dim decId As String, baseRel As String
    decId = GetDecedentId()
    baseRel = GetPersonValue(baseId, P_REL_DEC)
    Select Case modeName
        Case MODE_DECEDENT
            AutoRelationText = "被相続人"
        Case MODE_SPOUSE
            If Len(baseId) = 0 Or baseId = decId Then
                AutoRelationText = "配偶者"
            ElseIf Len(baseRel) > 0 Then
                AutoRelationText = baseRel & "の配偶者"
            Else
                AutoRelationText = "配偶者"
            End If
        Case MODE_FATHER
            AutoRelationText = "父"
        Case MODE_MOTHER
            AutoRelationText = "母"
        Case MODE_CHILD
            If Len(baseId) > 0 And baseId <> decId Then
                AutoRelationText = "孫"
            Else
                AutoRelationText = ChildRelationText(gender)
            End If
        Case MODE_SIBLING
            AutoRelationText = SiblingRelationText(gender, birthDate)
        Case MODE_GRANDCHILD
            AutoRelationText = "孫"
        Case Else
            AutoRelationText = "関係者"
    End Select
End Function

Private Function ChildRelationText(ByVal gender As String) As String
    Dim n As Long
    If gender = "男" Then
        n = CountRelationStartsWith("長男", "二男", "三男", "男") + 1
        ChildRelationText = Array("", "長男", "二男", "三男", "四男", "五男")(Application.Min(n, 5))
    ElseIf gender = "女" Then
        n = CountRelationStartsWith("長女", "二女", "三女", "女") + 1
        ChildRelationText = Array("", "長女", "二女", "三女", "四女", "五女")(Application.Min(n, 5))
    Else
        ChildRelationText = "子"
    End If
End Function

Private Function CountRelationStartsWith(ByVal a As String, ByVal b As String, ByVal c As String, ByVal g As String) As Long
    Dim ws As Worksheet, r As Long, lastR As Long, v As String
    Set ws = ThisWorkbook.Worksheets(SH_W_PERSON)
    lastR = LastRow(ws, 1)
    For r = 2 To lastR
        v = CStr(ws.Cells(r, P_REL_DEC).Value)
        If v = a Or v = b Or v = c Or InStr(v, g) > 0 Then CountRelationStartsWith = CountRelationStartsWith + 1
    Next r
End Function

Private Function SiblingRelationText(ByVal gender As String, ByVal birthDate As Variant) As String
    Dim decId As String, decBirth As Variant, older As Boolean
    decId = GetDecedentId()
    decBirth = GetPersonValue(decId, P_BIRTH)
    If IsDate(birthDate) And IsDate(decBirth) Then older = CDate(birthDate) < CDate(decBirth)
    If gender = "男" Then
        SiblingRelationText = IIf(older, "兄", "弟")
    ElseIf gender = "女" Then
        SiblingRelationText = IIf(older, "姉", "妹")
    Else
        SiblingRelationText = "兄弟姉妹"
    End If
End Function

Private Sub AddRelationIfNeeded(ByVal baseId As String, ByVal otherId As String, ByVal modeName As String, ByVal relationText As String, ByVal marriageDate As Variant, ByVal divorceDate As Variant)
    If Len(baseId) = 0 Or Len(otherId) = 0 Then Exit Sub
    Dim ws As Worksheet, r As Long, relationType As String
    Set ws = ThisWorkbook.Worksheets(SH_W_REL)
    relationType = "その他"
    If modeName = MODE_SPOUSE Then relationType = "配偶者"
    If modeName = MODE_CHILD Or modeName = MODE_FATHER Or modeName = MODE_MOTHER Or modeName = MODE_GRANDCHILD Then relationType = "親子"
    If modeName = MODE_SIBLING Then relationType = "兄弟姉妹"
    r = NextBlankRow(ws, 1)
    ws.Cells(r, R_ID).Value = NextId("関係")
    ws.Cells(r, R_BASE_ID).Value = baseId
    ws.Cells(r, R_OTHER_ID).Value = otherId
    ws.Cells(r, R_TYPE).Value = relationType
    ws.Cells(r, R_DISPLAY).Value = relationText
    ws.Cells(r, R_MARRIAGE).Value = SameDateOrBlank(marriageDate)
    ws.Cells(r, R_DIVORCE).Value = SameDateOrBlank(divorceDate)
    ws.Cells(r, R_AUTO).Value = "自動"
    ws.Cells(r, R_STATUS).Value = STATUS_ACTIVE
    ws.Cells(r, R_CREATED).Value = Now
    ws.Cells(r, R_UPDATED).Value = Now
End Sub

Private Sub RegisterAddressFromInput(ByVal personId As String)
    Dim wsIn As Worksheet, addressText As String, addressKey As String, candId As String, addrId As String, r As Long, wsA As Worksheet
    Set wsIn = ThisWorkbook.Worksheets(SH_INPUT)
    addressText = CleanText(wsIn.Range(CELL_ADDR_TEXT).Value)
    If Len(addressText) = 0 Then Exit Sub
    addressKey = CleanText(wsIn.Range(CELL_ADDR_KEY).Value)
    If Len(addressKey) = 0 Then addressKey = NormalizeAddress(addressText)
    wsIn.Range(CELL_ADDR_KEY).Value = addressKey
    candId = GetOrCreateAddressCandidate(addressText, addressKey, personId)
    Set wsA = ThisWorkbook.Worksheets(SH_W_ADDR_HIST)
    r = NextBlankRow(wsA, 1)
    addrId = NextId("住所履歴")
    wsA.Cells(r, A_ID).Value = addrId
    wsA.Cells(r, A_PERSON_ID).Value = personId
    wsA.Cells(r, A_CAND_ID).Value = candId
    wsA.Cells(r, A_TYPE).Value = IIf(Len(CleanText(wsIn.Range(CELL_ADDR_TYPE).Value)) = 0, "居住地", wsIn.Range(CELL_ADDR_TYPE).Value)
    wsA.Cells(r, A_START).Value = SameDateOrBlank(wsIn.Range(CELL_ADDR_START).Value)
    wsA.Cells(r, A_END).Value = SameDateOrBlank(wsIn.Range(CELL_ADDR_END).Value)
    wsA.Cells(r, A_TEXT).Value = addressText
    wsA.Cells(r, A_KEY).Value = addressKey
    wsA.Cells(r, A_SOURCE).Value = CleanText(wsIn.Range(CELL_ADDR_SOURCE).Value)
    wsA.Cells(r, A_COPY_PERSON_ID).Value = CleanText(wsIn.Range(CELL_BASE_ID).Value)
    wsA.Cells(r, A_NOTE).Value = CleanText(wsIn.Range(CELL_ADDR_NOTE).Value)
    wsA.Cells(r, A_STATUS).Value = STATUS_ACTIVE
    wsA.Cells(r, A_CREATED).Value = Now
    wsA.Cells(r, A_UPDATED).Value = Now
    ThisWorkbook.Worksheets(SH_W_PERSON).Cells(FindPersonRow(personId), P_REP_ADDR_ID).Value = addrId
End Sub

Private Function GetOrCreateAddressCandidate(ByVal addressText As String, ByVal addressKey As String, ByVal personId As String) As String
    Dim ws As Worksheet, r As Long, lastR As Long
    Set ws = ThisWorkbook.Worksheets(SH_W_ADDR_CAND)
    lastR = LastRow(ws, 1)
    For r = 2 To lastR
        If CStr(ws.Cells(r, AC_KEY).Value) = addressKey Then
            ws.Cells(r, AC_LAST_PERSON).Value = personId
            ws.Cells(r, AC_USE_COUNT).Value = Val(ws.Cells(r, AC_USE_COUNT).Value) + 1
            ws.Cells(r, AC_LAST_USED).Value = Now
            GetOrCreateAddressCandidate = CStr(ws.Cells(r, AC_ID).Value)
            Exit Function
        End If
    Next r
    r = NextBlankRow(ws, 1)
    GetOrCreateAddressCandidate = NextId("住所候補")
    ws.Cells(r, AC_ID).Value = GetOrCreateAddressCandidate
    ws.Cells(r, AC_TEXT).Value = addressText
    ws.Cells(r, AC_KEY).Value = addressKey
    ws.Cells(r, AC_FIRST_PERSON).Value = personId
    ws.Cells(r, AC_LAST_PERSON).Value = personId
    ws.Cells(r, AC_USE_COUNT).Value = 1
    ws.Cells(r, AC_LAST_USED).Value = Now
End Function

Public Sub MakeAddressKeyFromInput()
    Dim ws As Worksheet
    Set ws = ThisWorkbook.Worksheets(SH_INPUT)
    ws.Range(CELL_ADDR_KEY).Value = NormalizeAddress(ws.Range(CELL_ADDR_TEXT).Value)
End Sub

Public Sub ApplySelectedAddressCandidate()
    Dim ws As Worksheet, sel As String, id As String, r As Long
    Set ws = ThisWorkbook.Worksheets(SH_INPUT)
    sel = CleanText(ws.Range(CELL_ADDR_CAND).Value)
    If Len(sel) = 0 Then Exit Sub
    id = ParseIdFromCandidate(sel)
    r = FindAddressCandidateRow(id)
    If r = 0 Then Exit Sub
    ws.Range(CELL_ADDR_TEXT).Value = ThisWorkbook.Worksheets(SH_W_ADDR_CAND).Cells(r, AC_TEXT).Value
    ws.Range(CELL_ADDR_KEY).Value = ThisWorkbook.Worksheets(SH_W_ADDR_CAND).Cells(r, AC_KEY).Value
End Sub

Public Sub CopyBaseCurrentAddress(Optional ByVal showMessage As Boolean = True)
    Dim ws As Worksheet, baseId As String, addrText As String, addrKey As String
    Set ws = ThisWorkbook.Worksheets(SH_INPUT)
    baseId = CleanText(ws.Range(CELL_BASE_ID).Value)
    If Len(baseId) = 0 Then Exit Sub
    GetCurrentAddressParts baseId, addrText, addrKey
    If Len(addrText) > 0 Then
        ws.Range(CELL_ADDR_TEXT).Value = addrText
        ws.Range(CELL_ADDR_KEY).Value = addrKey
        If showMessage Then MsgBox "基準人物の住所をコピーしました。", vbInformation
    End If
End Sub

Public Sub CopyLastAddress()
    Dim ws As Worksheet, r As Long
    Set ws = ThisWorkbook.Worksheets(SH_W_ADDR_CAND)
    r = LastRow(ws, AC_LAST_USED)
    If r < 2 Then Exit Sub
    ThisWorkbook.Worksheets(SH_INPUT).Range(CELL_ADDR_TEXT).Value = ws.Cells(r, AC_TEXT).Value
    ThisWorkbook.Worksheets(SH_INPUT).Range(CELL_ADDR_KEY).Value = ws.Cells(r, AC_KEY).Value
End Sub

Public Sub UseMarriageDateAsAddressStart()
    Dim ws As Worksheet
    Set ws = ThisWorkbook.Worksheets(SH_INPUT)
    If IsDate(ws.Range(CELL_MARRIAGE).Value) Then ws.Range(CELL_ADDR_START).Value = ws.Range(CELL_MARRIAGE).Value
End Sub

Public Sub UseBirthDateAsAddressStart()
    Dim ws As Worksheet
    Set ws = ThisWorkbook.Worksheets(SH_INPUT)
    If IsDate(ws.Range(CELL_BIRTH).Value) Then ws.Range(CELL_ADDR_START).Value = ws.Range(CELL_BIRTH).Value
End Sub

Public Sub UseDeathDateAsAddressEnd()
    Dim ws As Worksheet
    Set ws = ThisWorkbook.Worksheets(SH_INPUT)
    If IsDate(ws.Range(CELL_DEATH).Value) Then ws.Range(CELL_ADDR_END).Value = ws.Range(CELL_DEATH).Value
End Sub

Public Sub UseDivorceDateAsAddressEnd()
    Dim ws As Worksheet
    Set ws = ThisWorkbook.Worksheets(SH_INPUT)
    If IsDate(ws.Range(CELL_DIVORCE).Value) Then ws.Range(CELL_ADDR_END).Value = ws.Range(CELL_DIVORCE).Value
End Sub

Public Function FindAddressCandidateRow(ByVal candId As String) As Long
    Dim ws As Worksheet, r As Long, lastR As Long
    Set ws = ThisWorkbook.Worksheets(SH_W_ADDR_CAND)
    lastR = LastRow(ws, 1)
    For r = 2 To lastR
        If CStr(ws.Cells(r, AC_ID).Value) = candId Then FindAddressCandidateRow = r: Exit Function
    Next r
End Function

Public Sub GetCurrentAddressParts(ByVal personId As String, ByRef addressText As String, ByRef addressKey As String)
    Dim ws As Worksheet, r As Long, lastR As Long, bestR As Long
    Set ws = ThisWorkbook.Worksheets(SH_W_ADDR_HIST)
    lastR = LastRow(ws, 1)
    For r = 2 To lastR
        If CStr(ws.Cells(r, A_PERSON_ID).Value) = personId And CStr(ws.Cells(r, A_STATUS).Value) <> STATUS_CANCEL Then bestR = r
    Next r
    If bestR > 0 Then
        addressText = CStr(ws.Cells(bestR, A_TEXT).Value)
        addressKey = CStr(ws.Cells(bestR, A_KEY).Value)
    End If
End Sub

Public Function GetCurrentAddressText(ByVal personId As String) As String
    Dim t As String, k As String
    GetCurrentAddressParts personId, t, k
    GetCurrentAddressText = t
End Function

Public Sub RefreshCandidates()
    Dim wsC As Worksheet, wsP As Worksheet, wsA As Worksheet, r As Long, outR As Long, dict As Object, key As Variant
    Set wsC = ThisWorkbook.Worksheets(SH_W_CAND)
    wsC.Range("A2:N500").ClearContents
    Set dict = CreateObject("Scripting.Dictionary")
    Set wsP = ThisWorkbook.Worksheets(SH_W_PERSON)
    For r = 2 To LastRow(wsP, 1)
        If CStr(wsP.Cells(r, P_STATUS).Value) <> STATUS_CANCEL Then
            If Len(CStr(wsP.Cells(r, P_SURNAME).Value)) > 0 Then dict(CStr(wsP.Cells(r, P_SURNAME).Value)) = 1
            If Len(CStr(wsP.Cells(r, P_FORMER).Value)) > 0 Then dict(CStr(wsP.Cells(r, P_FORMER).Value)) = 1
        End If
    Next r
    outR = 2
    For Each key In dict.Keys
        wsC.Cells(outR, 1).Value = key
        outR = outR + 1
    Next key

    Set wsA = ThisWorkbook.Worksheets(SH_W_ADDR_CAND)
    For r = 2 To LastRow(wsA, 1)
        If Len(CStr(wsA.Cells(r, AC_ID).Value)) > 0 Then
            wsC.Cells(r, 2).Value = wsA.Cells(r, AC_ID).Value & " " & wsA.Cells(r, AC_TEXT).Value
            wsC.Cells(r, 3).Value = wsA.Cells(r, AC_ID).Value
        End If
    Next r

    For r = 2 To LastRow(wsP, 1)
        If Len(CStr(wsP.Cells(r, P_ID).Value)) > 0 And CStr(wsP.Cells(r, P_STATUS).Value) <> STATUS_CANCEL Then
            wsC.Cells(r, 4).Value = wsP.Cells(r, P_ID).Value & " " & wsP.Cells(r, P_DISPLAY).Value & "（" & wsP.Cells(r, P_REL_DEC).Value & "）"
            wsC.Cells(r, 5).Value = wsP.Cells(r, P_ID).Value
        End If
    Next r

    FillStaticCandidates wsC
    FillDateCandidates wsC
End Sub


Private Sub FillDateCandidates(ByVal wsC As Worksheet)
    Dim dictM As Object, dictD As Object, dictA As Object
    Dim wsR As Worksheet, wsP As Worksheet, wsA As Worksheet, r As Long, key As Variant, outR As Long
    Set dictM = CreateObject("Scripting.Dictionary")
    Set dictD = CreateObject("Scripting.Dictionary")
    Set dictA = CreateObject("Scripting.Dictionary")

    Set wsR = ThisWorkbook.Worksheets(SH_W_REL)
    For r = 2 To LastRow(wsR, 1)
        If CStr(wsR.Cells(r, R_STATUS).Value) <> STATUS_CANCEL Then
            AddDateCandidate dictM, wsR.Cells(r, R_MARRIAGE).Value
            AddDateCandidate dictA, wsR.Cells(r, R_MARRIAGE).Value
            AddDateCandidate dictD, wsR.Cells(r, R_DIVORCE).Value
            AddDateCandidate dictA, wsR.Cells(r, R_DIVORCE).Value
        End If
    Next r

    Set wsP = ThisWorkbook.Worksheets(SH_W_PERSON)
    For r = 2 To LastRow(wsP, 1)
        If CStr(wsP.Cells(r, P_STATUS).Value) <> STATUS_CANCEL Then
            AddDateCandidate dictA, wsP.Cells(r, P_BIRTH).Value
            AddDateCandidate dictA, wsP.Cells(r, P_DEATH).Value
        End If
    Next r

    Set wsA = ThisWorkbook.Worksheets(SH_W_ADDR_HIST)
    For r = 2 To LastRow(wsA, 1)
        If CStr(wsA.Cells(r, A_STATUS).Value) <> STATUS_CANCEL Then
            AddDateCandidate dictA, wsA.Cells(r, A_START).Value
            AddDateCandidate dictA, wsA.Cells(r, A_END).Value
        End If
    Next r

    outR = 2
    For Each key In dictM.Keys
        wsC.Cells(outR, 12).Value = CDate(dictM(key))
        outR = outR + 1
    Next key
    outR = 2
    For Each key In dictD.Keys
        wsC.Cells(outR, 13).Value = CDate(dictD(key))
        outR = outR + 1
    Next key
    outR = 2
    For Each key In dictA.Keys
        wsC.Cells(outR, 14).Value = CDate(dictA(key))
        outR = outR + 1
    Next key
    wsC.Range("L2:N500").NumberFormatLocal = "yyyy/m/d"
End Sub

Private Sub AddDateCandidate(ByVal dict As Object, ByVal v As Variant)
    If IsDate(v) Then dict(Format(CDate(v), "yyyy/mm/dd")) = CDate(v)
End Sub
Private Sub FillStaticCandidates(ByVal wsC As Worksheet)
    Dim arr, i As Long
    arr = Array("戸籍", "戸籍附票", "住民票", "申述", "金融資料", "その他")
    For i = 0 To UBound(arr): wsC.Cells(2 + i, 6).Value = arr(i): Next i
    arr = Array("無職", "会社員", "会社役員", "自営業", "公務員", "年金", "その他")
    For i = 0 To UBound(arr): wsC.Cells(2 + i, 7).Value = arr(i): Next i
    arr = Array("被相続人", "配偶者", "父", "母", "長男", "二男", "三男", "長女", "二女", "三女", "子", "孫", "兄", "弟", "姉", "妹", "関係者")
    For i = 0 To UBound(arr): wsC.Cells(2 + i, 8).Value = arr(i): Next i
    arr = Array("居住地", "住民票住所", "実居所", "本籍", "その他")
    For i = 0 To UBound(arr): wsC.Cells(2 + i, 9).Value = arr(i): Next i
    arr = Array("男", "女", "不明")
    For i = 0 To UBound(arr): wsC.Cells(2 + i, 10).Value = arr(i): Next i
    arr = Array(SHOW_YES, SHOW_NO)
    For i = 0 To UBound(arr): wsC.Cells(2 + i, 11).Value = arr(i): Next i
End Sub

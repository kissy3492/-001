Attribute VB_Name = "modUsability"
Option Explicit

'============================================================
' 入力ストレスを減らすための操作制御モジュール
' ・入力セル以外はロック
' ・通常時は人物入力だけを触る
' ・Tab / Shift+Tab で自然な順番に移動
' ・住所キー、旧姓、住所開始・終了日の候補を入力中に自動補助
'============================================================

Private Const INPUT_SCROLL_AREA As String = "B2:J47"
Private Const CONFIG_SCROLL_AREA As String = "B2:G10"
Private mHandlingInput As Boolean

Public Sub InitUsabilityControls()
    On Error Resume Next
    ApplyInputUsability
    ApplyConfigUsability
    ApplyOutputUsability
    EnableInputKeyNavigation
    On Error GoTo 0
End Sub

Public Sub ApplyInputUsability()
    On Error GoTo SafeExit
    Dim ws As Worksheet
    Set ws = ThisWorkbook.Worksheets(SH_INPUT)
    ws.Unprotect Password:=TOOL_PASSWORD
    ws.Cells.Locked = True
    ws.Cells.FormulaHidden = False
    EditableInputRange(ws).Locked = False
    EditableInputRange(ws).Interior.Color = vbWhite
    EditableInputRange(ws).Borders.Color = ThemeColor("blue")
    EditableInputRange(ws).Borders.Weight = xlThin
    LockedStyle ws.Range("C7:C10,C17:C20,B38:J44,B46:J47")
    ws.Range(CELL_FORMER_SURNAME).Interior.Color = ThemeColor("warning-soft")
    ws.Range(CELL_ADDR_KEY).Interior.Color = ThemeColor("section")
    ThemePrepareSheetForProtection ws
    ws.Protect Password:=TOOL_PASSWORD, DrawingObjects:=True, Contents:=True, Scenarios:=True, _
               UserInterfaceOnly:=True, AllowFormattingCells:=False, AllowFormattingColumns:=False, _
               AllowFormattingRows:=False, AllowInsertingRows:=False, AllowDeletingRows:=False, _
               AllowSorting:=False, AllowFiltering:=False
    ws.EnableSelection = xlUnlockedCells
    ws.ScrollArea = INPUT_SCROLL_AREA
    ApplyPersonInputViewport ws
SafeExit:
End Sub

Public Sub ApplyConfigUsability()
    On Error GoTo SafeExit
    Dim ws As Worksheet
    Set ws = ThisWorkbook.Worksheets(SH_CONFIG)
    ws.Unprotect Password:=TOOL_PASSWORD
    ws.Cells.Locked = True
    ws.Range("C4:C6").Locked = False
    InputStyle ws.Range("C4:C6")
    ThemePrepareSheetForProtection ws
    ws.Protect Password:=TOOL_PASSWORD, DrawingObjects:=True, Contents:=True, Scenarios:=True, UserInterfaceOnly:=True
    ws.EnableSelection = xlUnlockedCells
    ws.ScrollArea = CONFIG_SCROLL_AREA
SafeExit:
End Sub

Public Sub ApplyOutputUsability()
    On Error Resume Next
    Dim arr As Variant, i As Long, ws As Worksheet
    arr = Array(SH_CONFIRM, SH_CHECK, SH_DIAGRAM, SH_ADDR_TABLE, SH_COHAB, SH_TIMELINE, SH_PERSON_LIST)
    For i = LBound(arr) To UBound(arr)
        Set ws = ThisWorkbook.Worksheets(CStr(arr(i)))
        ws.Unprotect Password:=TOOL_PASSWORD
        ws.Cells.Locked = True
        ThemePrepareSheetForProtection ws
        ws.Protect Password:=TOOL_PASSWORD, DrawingObjects:=True, Contents:=True, Scenarios:=True, UserInterfaceOnly:=True
        ws.EnableSelection = xlNoRestrictions
        ws.ScrollArea = ""
    Next i
    On Error GoTo 0
End Sub

Public Sub EnableInputKeyNavigation()
    On Error Resume Next
    If ActiveWorkbook Is Nothing Then Exit Sub
    If ActiveWorkbook.Name <> ThisWorkbook.Name Then
        DisableInputKeyNavigation
        Exit Sub
    End If
    If ActiveSheet Is Nothing Then Exit Sub
    If ActiveSheet.Name = SH_INPUT Then
        Application.OnKey "{TAB}", "MoveToNextInputField"
        Application.OnKey "+{TAB}", "MoveToPreviousInputField"
        Application.OnKey "~", "MoveToNextInputField"
    Else
        DisableInputKeyNavigation
    End If
    On Error GoTo 0
End Sub

Public Sub DisableInputKeyNavigation()
    On Error Resume Next
    Application.OnKey "{TAB}"
    Application.OnKey "+{TAB}"
    Application.OnKey "~"
    Application.StatusBar = False
    On Error GoTo 0
End Sub

Public Sub MoveToNextInputField()
    MoveInputField 1
End Sub

Public Sub MoveToPreviousInputField()
    MoveInputField -1
End Sub

Private Sub MoveInputField(ByVal direction As Long)
    On Error GoTo SafeExit
    If ActiveWorkbook Is Nothing Then Exit Sub
    If ActiveWorkbook.Name <> ThisWorkbook.Name Then DisableInputKeyNavigation: Exit Sub
    If ActiveSheet.Name <> SH_INPUT Then Exit Sub
    Dim ws As Worksheet, arr As Variant, i As Long, cur As String, nextIndex As Long
    Set ws = ThisWorkbook.Worksheets(SH_INPUT)
    arr = InputOrder()
    cur = ActiveCell.Address(False, False)
    nextIndex = LBound(arr)
    For i = LBound(arr) To UBound(arr)
        If UCase$(CStr(arr(i))) = UCase$(cur) Then
            nextIndex = i + direction
            Exit For
        End If
    Next i
    If nextIndex < LBound(arr) Then nextIndex = UBound(arr)
    If nextIndex > UBound(arr) Then nextIndex = LBound(arr)
    ws.Range(CStr(arr(nextIndex))).Select
SafeExit:
End Sub

Public Sub HandleInputSheetActivated(ByVal sheetName As String)
    On Error Resume Next
    If sheetName = SH_INPUT Then
        ApplyInputUsability
        EnableInputKeyNavigation
    Else
        DisableInputKeyNavigation
    End If
    On Error GoTo 0
End Sub

Public Sub HandleInputSelectionChange(ByVal Target As Range)
    On Error GoTo SafeExit
    If mHandlingInput Then Exit Sub
    If Target.Worksheet.Name <> SH_INPUT Then Exit Sub
    If Target.CountLarge > 1 Then Exit Sub
    If Intersect(Target, EditableInputRange(Target.Worksheet)) Is Nothing Then
        Application.EnableEvents = False
        FirstUsefulInputCell(Target.Worksheet).Select
        Application.EnableEvents = True
    Else
        ShowPersonInputMicroHint Target
    End If
SafeExit:
    Application.EnableEvents = True
End Sub

Public Sub HandleInputChange(ByVal Target As Range)
    On Error GoTo SafeExit
    If mHandlingInput Then Exit Sub
    If Target.Worksheet.Name <> SH_INPUT Then Exit Sub
    If Target.CountLarge > 1 Then Exit Sub

    Dim ws As Worksheet
    Set ws = Target.Worksheet
    If Intersect(Target, EditableInputRange(ws)) Is Nothing Then Exit Sub

    mHandlingInput = True
    Application.EnableEvents = False

    If Not Intersect(Target, ws.Range(CELL_ADDR_CAND)) Is Nothing Then
        ApplySelectedAddressCandidate
    End If

    If Not Intersect(Target, ws.Range(CELL_ADDR_TEXT)) Is Nothing Then
        If Len(CleanText(ws.Range(CELL_ADDR_TEXT).Value)) > 0 And Len(CleanText(ws.Range(CELL_ADDR_KEY).Value)) = 0 Then
            ws.Range(CELL_ADDR_KEY).Value = NormalizeAddress(ws.Range(CELL_ADDR_TEXT).Value)
        End If
    End If

    If Not Intersect(Target, ws.Range(CELL_SURNAME)) Is Nothing Then
        Dim autoSurname As String, surname As String
        autoSurname = CleanText(ws.Range(CELL_AUTO_SURNAME).Value)
        surname = CleanText(ws.Range(CELL_SURNAME).Value)
        If Len(autoSurname) > 0 And Len(surname) > 0 And surname <> autoSurname And Len(CleanText(ws.Range(CELL_FORMER_SURNAME).Value)) = 0 Then
            ws.Range(CELL_FORMER_SURNAME).Value = autoSurname
            AppendInputGuide "姓が自動候補と異なるため、旧姓に「" & autoSurname & "」を補完しました。不要なら削除してください。"
        End If
    End If

    If Not Intersect(Target, ws.Range(CELL_MARRIAGE)) Is Nothing Then
        If IsDate(ws.Range(CELL_MARRIAGE).Value) And Len(CleanText(ws.Range(CELL_ADDR_START).Value)) = 0 Then ws.Range(CELL_ADDR_START).Value = ws.Range(CELL_MARRIAGE).Value
    End If
    If Not Intersect(Target, ws.Range(CELL_BIRTH)) Is Nothing Then
        If IsDate(ws.Range(CELL_BIRTH).Value) And Len(CleanText(ws.Range(CELL_ADDR_START).Value)) = 0 Then ws.Range(CELL_ADDR_START).Value = ws.Range(CELL_BIRTH).Value
    End If
    If Not Intersect(Target, ws.Range(CELL_DEATH)) Is Nothing Then
        If IsDate(ws.Range(CELL_DEATH).Value) And Len(CleanText(ws.Range(CELL_ADDR_END).Value)) = 0 Then ws.Range(CELL_ADDR_END).Value = ws.Range(CELL_DEATH).Value
    End If
    If Not Intersect(Target, ws.Range(CELL_DIVORCE)) Is Nothing Then
        If IsDate(ws.Range(CELL_DIVORCE).Value) And Len(CleanText(ws.Range(CELL_ADDR_END).Value)) = 0 Then ws.Range(CELL_ADDR_END).Value = ws.Range(CELL_DIVORCE).Value
    End If

    If IsDateInputCell(Target) Then
        If Len(CleanText(Target.Value)) > 0 And Not IsDate(Target.Value) Then
            MsgBox "日付欄は yyyy/m/d の形式で入力してください。例：2024/6/10", vbExclamation
            Target.Select
            GoTo SafeExit
        End If
    End If

    SelectNextAfterChange ws, Target
SafeExit:
    Application.EnableEvents = True
    mHandlingInput = False
End Sub

Private Function EditableInputRange(ByVal ws As Worksheet) As Range
    Set EditableInputRange = Union(ws.Range(CELL_BASE_SELECT), ws.Range("C21:C32"), ws.Range("F17:F24"))
End Function

Private Function InputOrder() As Variant
    InputOrder = Array(CELL_SURNAME, CELL_GIVEN_NAME, CELL_FORMER_SURNAME, CELL_GENDER, CELL_REL_TO_DECEDENT, _
                       CELL_BIRTH, CELL_DEATH, CELL_OCCUPATION, CELL_MARRIAGE, CELL_DIVORCE, _
                       CELL_ADDR_CAND, CELL_ADDR_TEXT, CELL_ADDR_KEY, CELL_ADDR_TYPE, CELL_ADDR_START, CELL_ADDR_END, CELL_ADDR_SOURCE, CELL_ADDR_NOTE, _
                       CELL_NOTE, CELL_SHOW_DIAGRAM)
End Function

Private Function FirstUsefulInputCell(ByVal ws As Worksheet) As Range
    If Len(CleanText(ws.Range(CELL_SURNAME).Value)) = 0 Then
        Set FirstUsefulInputCell = ws.Range(CELL_SURNAME)
    ElseIf Len(CleanText(ws.Range(CELL_GIVEN_NAME).Value)) = 0 Then
        Set FirstUsefulInputCell = ws.Range(CELL_GIVEN_NAME)
    Else
        Set FirstUsefulInputCell = ws.Range(CELL_ADDR_TEXT)
    End If
End Function

Private Sub ShowPersonInputMicroHint(ByVal Target As Range)
    Dim a As String, msg As String
    If Target Is Nothing Then Exit Sub
    a = Target.Address(False, False)
    Select Case a
        Case CELL_SURNAME
            msg = "姓を入力します。入力済みの姓は候補化され、家族登録時に再利用できます。"
        Case CELL_GIVEN_NAME
            msg = "名を入力します。姓・名から氏名を自動整理します。"
        Case CELL_FORMER_SURNAME
            msg = "旧姓欄です。婚姻・離婚・親子関係の確認に使います。不要なら空欄で構いません。"
        Case CELL_REL_TO_DECEDENT
            msg = "被相続人から見た続柄を選びます。後続の分析・伝票控えにも反映されます。"
        Case CELL_BIRTH
            msg = "生年月日です。年齢、出生前後の資金移動、20歳未満注意の分析に使います。"
        Case CELL_DEATH
            msg = "死亡日です。被相続人の場合は相続開始日の候補になります。"
        Case CELL_OCCUPATION
            msg = "職業です。一度入力したものは候補化されます。"
        Case CELL_MARRIAGE
            msg = "婚姻日です。婚姻前後の高額入出金分析や住所開始候補に使います。"
        Case CELL_DIVORCE
            msg = "離婚日です。住所終了候補や時系列に使います。"
        Case CELL_ADDR_CAND
            msg = "入力済み住所を選べます。同居家族や転居先の再入力を減らします。"
        Case CELL_ADDR_TEXT
            msg = "住所を入力します。住所キーは自動補完され、同居推定と転居分析に使います。"
        Case CELL_ADDR_KEY
            msg = "同居推定用の住所キーです。通常は自動補完値を使い、必要な時だけ整えます。"
        Case CELL_ADDR_START
            msg = "住所の開始日です。転居前後の資金移動分析に使います。"
        Case CELL_ADDR_END
            msg = "住所の終了日です。転居期間・同居推定の終期に使います。"
        Case CELL_ADDR_SOURCE
            msg = "住所の根拠です。戸籍附票・住民票・申述など、一度入力した根拠は再利用できます。"
        Case CELL_NOTE
            msg = "人物メモです。判断材料は短く残すと、後続確認が楽になります。"
        Case Else
            msg = "Enter / Tab で次の入力欄へ移動します。入力済みの姓・住所・根拠は候補として再利用されます。"
    End Select
    Application.StatusBar = msg
End Sub


Private Sub SelectNextAfterChange(ByVal ws As Worksheet, ByVal Target As Range)
    Dim arr As Variant, i As Long, nextIndex As Long
    arr = InputOrder()
    For i = LBound(arr) To UBound(arr)
        If UCase$(Target.Address(False, False)) = UCase$(CStr(arr(i))) Then
            nextIndex = i + 1
            If nextIndex > UBound(arr) Then nextIndex = UBound(arr)
            ws.Range(CStr(arr(nextIndex))).Select
            Exit Sub
        End If
    Next i
End Sub

Private Function IsDateInputCell(ByVal Target As Range) As Boolean
    Dim a As String
    a = Target.Address(False, False)
    IsDateInputCell = (a = CELL_BIRTH Or a = CELL_DEATH Or a = CELL_MARRIAGE Or a = CELL_DIVORCE Or a = CELL_ADDR_START Or a = CELL_ADDR_END)
End Function

Private Sub AppendInputGuide(ByVal text As String)
    On Error Resume Next
    Dim ws As Worksheet, oldText As String
    Set ws = ThisWorkbook.Worksheets(SH_INPUT)
    oldText = CleanText(ws.Range("B38").Value)
    If Len(oldText) > 0 Then
        ws.Range("B38").Value = text & vbCrLf & oldText
    Else
        ws.Range("B38").Value = text
    End If
    On Error GoTo 0
End Sub


Public Sub ApplyPersonInputViewport(Optional ByVal ws As Worksheet = Nothing)
    '入力画面は「迷わず、余計な場所に行かず、候補を見ながら入力」できる状態へ整える。
    Dim win As Window
    If ws Is Nothing Then
        If Not SheetExists(SH_INPUT) Then Exit Sub
        Set ws = ThisWorkbook.Worksheets(SH_INPUT)
    End If
    On Error Resume Next
    ws.ScrollArea = INPUT_SCROLL_AREA
    If ActiveWorkbook Is Nothing Then Exit Sub
    If ActiveWorkbook.Name <> ThisWorkbook.Name Then Exit Sub
    If ActiveSheet Is Nothing Then Exit Sub
    If ActiveSheet.Name <> ws.Name Then Exit Sub
    Set win = ActiveWindow
    If win Is Nothing Then Exit Sub
    win.DisplayGridlines = False
    If win.Zoom <> 95 Then win.Zoom = 95
    On Error GoTo 0
End Sub

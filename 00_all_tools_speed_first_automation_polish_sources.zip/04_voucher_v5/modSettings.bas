Attribute VB_Name = "modSettings"
Option Explicit

Public Function SettingValue(ByVal key As String, Optional ByVal defaultValue As Variant = "") As Variant
    Dim sh As Worksheet, r As Long, lr As Long
    Set sh = Ws(SH_SETTINGS)
    lr = LastRow(sh, 1)
    For r = 1 To lr
        If CStr(sh.Cells(r, 1).Value) = key Then
            If Len(Nz(sh.Cells(r, 2).Value)) = 0 Then
                SettingValue = defaultValue
            Else
                SettingValue = sh.Cells(r, 2).Value
            End If
            Exit Function
        End If
    Next r
    SettingValue = defaultValue
End Function

Public Function SettingLong(ByVal key As String, ByVal defaultValue As Long) As Long
    Dim v As Variant
    v = SettingValue(key, defaultValue)
    If IsNumeric(v) Then SettingLong = CLng(v) Else SettingLong = defaultValue
End Function

Public Function SettingText(ByVal key As String, ByVal defaultValue As String) As String
    SettingText = CStr(SettingValue(key, defaultValue))
End Function

Public Function IsSettingYes(ByVal key As String, Optional ByVal defaultYes As Boolean = True) As Boolean
    Dim v As String
    v = SettingText(key, IIf(defaultYes, "する", "しない"))
    IsSettingYes = (v = "する" Or v = "要" Or UCase$(v) = "YES" Or UCase$(v) = "TRUE")
End Function

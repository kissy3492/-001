Attribute VB_Name = "modUi"
Option Explicit

Public Sub HandleBeforeDoubleClick(ByVal Sh As Object, ByVal Target As Range, ByRef Cancel As Boolean)
    If Sh.Name = SH_DEST_LIST Then
        If Target.Row >= 5 And Target.Column = 6 Then
            Cancel = True
            ToggleDestinationTarget Target
        End If
    End If
End Sub

Private Sub ToggleDestinationTarget(ByVal cell As Range)
    Dim newValue As String
    If Nz(cell.Value) = "作成" Then newValue = "除外" Else newValue = "作成"
    cell.Value = newValue
    SyncDestinationTargetsFromList
End Sub

Public Sub HandleVoucherSheetChange(ByVal Sh As Object, ByVal Target As Range)
    '依頼先一覧のドロップダウン変更を即座に内部候補へ反映する。
    'ダブルクリックだけでなく、直接「作成/除外」を選んだ場合も出力対象がずれないようにする。
    Dim lr As Long, hit As Range
    Dim prevEvents As Boolean
    If Sh Is Nothing Or Target Is Nothing Then Exit Sub
    If Sh.Name <> SH_DEST_LIST Then Exit Sub
    lr = LastRow(Sh, 1)
    If lr < 5 Then lr = 5
    Set hit = Intersect(Target, Sh.Range("F5:F" & CStr(lr)))
    If hit Is Nothing Then Exit Sub
    prevEvents = Application.EnableEvents
    On Error GoTo SafeExit
    Application.EnableEvents = False
    NormalizeDestinationTargetCells hit
    SyncDestinationTargetsFromList
    Application.StatusBar = "依頼先一覧を更新しました。F列が「作成」の依頼先だけを出力します。"
    ApplyDestinationListProtection
SafeExit:
    Application.EnableEvents = prevEvents
End Sub

Private Sub NormalizeDestinationTargetCells(ByVal rng As Range)
    Dim cell As Range, v As String
    If rng Is Nothing Then Exit Sub
    For Each cell In rng.Cells
        v = Nz(cell.Value)
        If v <> "除外" Then
            cell.Value = "作成"
        End If
    Next cell
End Sub

Public Sub HandleVoucherSelectionChange(ByVal Sh As Object, ByVal Target As Range)
    Dim msg As String
    If Sh Is Nothing Or Target Is Nothing Then Exit Sub
    If Target.Cells.CountLarge > 1 Then Exit Sub
    Select Case Sh.Name
        Case SH_MAIN
            msg = "伝票依頼入力です。分析ツールで「要」かつ採用の取引だけを読み、依頼先別に作成します。"
        Case SH_SETTINGS
            If Target.Column = 2 And Target.Row >= 4 And Target.Row <= 12 Then
                msg = "設定欄です。前後銀行営業日・出力単位などを選びます。祝日は必要範囲だけ自動取得します。"
            Else
                msg = "設定シートです。白い欄だけ変更できます。"
            End If
        Case SH_DEST_LIST
            If Target.Column = 6 And Target.Row >= 5 Then
                msg = "作成/除外欄です。ダブルクリックまたはドロップダウンで切替できます。変更は即時反映されます。"
            Else
                msg = "依頼先一覧です。依頼先混在を防ぐため、銀行名＋取扱店ごとに1セットで作成します。"
            End If
        Case SH_REQUEST
            msg = "依頼用帳票です。金融機関へ渡すため、余計な明細は表示しません。"
        Case SH_CONTROL
            msg = "控え用帳票です。元取引日ごとの件数と対象取引を確認します。"
        Case Else
            msg = "伝票依頼ツールです。装飾図形は固定され、ボタンだけクリックできます。"
    End Select
    Application.StatusBar = msg
End Sub

Private Sub ApplyVoucherViewport(ByVal sh As Worksheet, Optional ByVal scrollAreaAddress As String = "", Optional ByVal zoomValue As Long = 95)
    Dim win As Window
    If sh Is Nothing Then Exit Sub
    On Error Resume Next
    If Len(scrollAreaAddress) > 0 Then sh.ScrollArea = scrollAreaAddress
    ThemeMarkMacroButtonsNonPrintable sh
    If ActiveWorkbook Is Nothing Then Exit Sub
    If ActiveWorkbook.Name <> ThisWorkbook.Name Then Exit Sub
    If ActiveSheet Is Nothing Then Exit Sub
    If ActiveSheet.Name <> sh.Name Then Exit Sub
    Set win = ActiveWindow
    If win Is Nothing Then Exit Sub
    win.DisplayGridlines = False
    If zoomValue > 0 Then win.Zoom = zoomValue
    On Error GoTo 0
End Sub

Private Sub UnprotectVoucherSheet(ByVal sh As Worksheet)
    If sh Is Nothing Then Exit Sub
    On Error Resume Next
    sh.Unprotect Password:=TOOL_PASSWORD
    If Err.Number <> 0 Then Err.Clear: sh.Unprotect
    On Error GoTo 0
End Sub

Public Sub ApplyVoucherSheetProtections()
    ApplyVoucherInputProtection
    ApplySettingsProtection
    ApplyDestinationListProtection
    ProtectOutputSheets
End Sub

Public Sub ApplyVoucherInputProtection()
    On Error Resume Next
    Dim sh As Worksheet
    Set sh = Ws(SH_MAIN)
    UnprotectVoucherSheet sh
    sh.Cells.Locked = True
    ThemePrepareSheetForProtection sh
    sh.Protect Password:=TOOL_PASSWORD, UserInterfaceOnly:=True, DrawingObjects:=True, Contents:=True, Scenarios:=True, _
               AllowFormattingCells:=False, AllowFormattingColumns:=False, AllowFormattingRows:=False
    sh.EnableSelection = xlNoRestrictions
    sh.ScrollArea = "A1:H32"
    ApplyVoucherViewport sh, "A1:H32", 96
    On Error GoTo 0
End Sub

Public Sub ApplySettingsProtection()
    On Error Resume Next
    If Not SheetExists(SH_SETTINGS) Then Exit Sub
    Dim sh As Worksheet
    Set sh = Ws(SH_SETTINGS)
    UnprotectVoucherSheet sh
    sh.Cells.Locked = True
    sh.Range("B4:B12").Locked = False
    sh.Range("B4:B12").Interior.Color = vbWhite
    ThemePrepareSheetForProtection sh
    sh.Protect Password:=TOOL_PASSWORD, UserInterfaceOnly:=True, DrawingObjects:=True, Contents:=True, Scenarios:=True, _
               AllowFormattingCells:=False, AllowFormattingColumns:=False, AllowFormattingRows:=False
    sh.EnableSelection = xlUnlockedCells
    sh.ScrollArea = "A1:C20"
    ApplyVoucherViewport sh, "A1:C20", 96
    On Error GoTo 0
End Sub

Public Sub ApplyDestinationListProtection()
    On Error Resume Next
    If Not SheetExists(SH_DEST_LIST) Then Exit Sub
    Dim sh As Worksheet, lr As Long
    Set sh = Ws(SH_DEST_LIST)
    lr = LastRow(sh, 1)
    If lr < 5 Then lr = 5
    UnprotectVoucherSheet sh
    sh.Cells.Locked = True
    sh.Range("F5:F" & CStr(lr)).Locked = False
    sh.Range("F5:F" & CStr(lr)).Interior.Color = C_LIGHT_YELLOW
    sh.Range("F5:F" & CStr(lr)).Validation.Delete
    sh.Range("F5:F" & CStr(lr)).Validation.Add Type:=xlValidateList, AlertStyle:=xlValidAlertStop, Formula1:="作成,除外"
    sh.Range("F5:F" & CStr(lr)).Validation.InCellDropdown = True
    ThemePrepareSheetForProtection sh
    sh.Protect Password:=TOOL_PASSWORD, UserInterfaceOnly:=True, DrawingObjects:=True, Contents:=True, Scenarios:=True, _
               AllowFiltering:=True, AllowSorting:=True, AllowFormattingCells:=False, AllowFormattingColumns:=False, AllowFormattingRows:=False
    sh.EnableSelection = xlUnlockedCells
    sh.ScrollArea = "A1:I" & CStr(Application.Max(lr + 10, 20))
    ApplyVoucherViewport sh, sh.ScrollArea, 92
    On Error GoTo 0
End Sub

Public Sub GoMain()
    ShowNormalMode
End Sub

Attribute VB_Name = "modCommonData"
Option Explicit

Public Sub LoadCommonData()
    On Error GoTo EH
    AppBegin "共通データを読み込み中..."
    Dim p As String
    p = CommonDataPath()
    If Dir(p) = vbNullString Then Err.Raise vbObjectError + 201, , COMMON_DATA_FILE & " が見つかりません。"

    Dim wb As Workbook
    Set wb = Workbooks.Open(Filename:=p, ReadOnly:=True, UpdateLinks:=False, IgnoreReadOnlyRecommended:=True, Notify:=False, AddToMru:=False)
    ImportVoucherCandidates wb
    wb.Close SaveChanges:=False
    BuildDestinationMaster
    RefreshDestinationList
    UpdateMainStatus
    WriteLog "共通データ読込完了"
    AppEnd ""
    MsgBox "伝票依頼候補を読み込みました。依頼先確認へ進んでください。", vbInformation
    Exit Sub
EH:
    On Error Resume Next
    If Not wb Is Nothing Then wb.Close SaveChanges:=False
    AppEnd ""
    MsgBox "共通データ読込でエラー: " & Err.Description, vbExclamation
End Sub

Private Sub ImportVoucherCandidates(ByVal srcWb As Workbook)
    If Not SheetExists(SRC_VOUCHER, srcWb) Then
        Err.Raise vbObjectError + 202, , SRC_VOUCHER & " がありません。分析ツールで共通データ保存を実行してください。"
    End If
    Dim src As Worksheet, dst As Worksheet
    Set src = srcWb.Worksheets(SRC_VOUCHER)
    Set dst = Ws(SH_W_CAND)
    ClearSheetKeepHeader dst

    Dim headers As Object
    Set headers = HeaderDictionary(src, 1)

    Dim cVoucherID As Long, cTxID As Long, cDate As Long, cBank As Long, cShop As Long, cBranch As Long
    Dim cPersonID As Long, cPerson As Long, cRel As Long, cKind As Long, cOut As Long, cIn As Long
    Dim cSummary As Long, cVoucher As Long, cAdopt As Long, cAnalysis As Long, cDetail As Long, cMemo As Long
    cVoucherID = FindHeader(headers, "伝票候補ID", "依頼候補ID")
    cTxID = FindHeader(headers, "取引ID", "TxID", "TX_ID")
    cDate = FindHeader(headers, "依頼対象日", "取引日", "日付", "元取引日")
    cBank = FindHeader(headers, "銀行名", "銀行")
    cShop = FindHeader(headers, "取扱店確定値", "取扱店", "取扱店表示", "依頼先取扱店")
    cBranch = FindHeader(headers, "支店名", "支店")
    cPersonID = FindHeader(headers, "人物ID")
    cPerson = FindHeader(headers, "人物名", "氏名", "名義人")
    cRel = FindHeader(headers, "続柄", "関係")
    cKind = FindHeader(headers, "区分", "分析区分")
    cOut = FindHeader(headers, "出金", "出金額")
    cIn = FindHeader(headers, "入金", "入金額")
    cSummary = FindHeader(headers, "摘要", "要点", "内容", "メモ摘要")
    cVoucher = FindHeader(headers, "伝票依頼", "伝票", "伝票依頼フラグ")
    cAdopt = FindHeader(headers, "採用", "シフト採用", "判断")
    cAnalysis = FindHeader(headers, "分析候補ID", "候補ID")
    cDetail = FindHeader(headers, "分析明細ID", "明細ID")
    cMemo = FindHeader(headers, "メモ", "分析メモ")

    If cDate = 0 Or cBank = 0 Or cShop = 0 Then
        Err.Raise vbObjectError + 203, , "T_伝票依頼候補に取引日・銀行名・取扱店の列が必要です。"
    End If

    Dim lr As Long, r As Long, outR As Long, target As Boolean
    lr = LastRow(src, 1)
    outR = 2
    For r = 2 To lr
        target = True
        If cVoucher > 0 Then target = (Nz(src.Cells(r, cVoucher).Value) = "要")
        If cAdopt > 0 Then
            If InStr(Nz(src.Cells(r, cAdopt).Value), "除外") > 0 Then target = False
        End If
        If target Then
            dst.Cells(outR, VC_ID).Value = GetCellText(src, r, cVoucherID)
            If Len(Nz(dst.Cells(outR, VC_ID).Value)) = 0 Then dst.Cells(outR, VC_ID).Value = "VR" & Format$(outR - 1, "000000")
            dst.Cells(outR, VC_ANALYSIS_ID).Value = GetCellText(src, r, cAnalysis)
            dst.Cells(outR, VC_DETAIL_ID).Value = GetCellText(src, r, cDetail)
            dst.Cells(outR, VC_TX_ID).Value = GetCellText(src, r, cTxID)
            dst.Cells(outR, VC_TX_DATE).Value = GetCellValue(src, r, cDate)
            dst.Cells(outR, VC_BANK).Value = GetCellText(src, r, cBank)
            dst.Cells(outR, VC_BRANCH).Value = GetCellText(src, r, cBranch)
            dst.Cells(outR, VC_SHOP).Value = GetCellText(src, r, cShop)
            dst.Cells(outR, VC_PERSON_ID).Value = GetCellText(src, r, cPersonID)
            dst.Cells(outR, VC_PERSON_NAME).Value = GetCellText(src, r, cPerson)
            dst.Cells(outR, VC_RELATION).Value = GetCellText(src, r, cRel)
            dst.Cells(outR, VC_KIND).Value = GetCellText(src, r, cKind)
            dst.Cells(outR, VC_OUT).Value = GetCellValue(src, r, cOut)
            dst.Cells(outR, VC_IN).Value = GetCellValue(src, r, cIn)
            dst.Cells(outR, VC_SUMMARY).Value = GetCellText(src, r, cSummary)
            dst.Cells(outR, VC_VOUCHER).Value = "要"
            dst.Cells(outR, VC_ADOPT).Value = IIf(cAdopt > 0, GetCellText(src, r, cAdopt), "採用")
            dst.Cells(outR, VC_TARGET).Value = "要"
            dst.Cells(outR, VC_MEMO).Value = GetCellText(src, r, cMemo)
            dst.Cells(outR, VC_DEST_KEY).Value = DestKey(dst.Cells(outR, VC_BANK).Value, dst.Cells(outR, VC_SHOP).Value)
            dst.Cells(outR, VC_STATUS).Value = "有効"
            outR = outR + 1
        End If
    Next r
    dst.Columns(VC_TX_DATE).NumberFormatLocal = "yyyy/m/d"
    dst.Columns(VC_OUT).NumberFormat = "#,##0"
    dst.Columns(VC_IN).NumberFormat = "#,##0"
End Sub

Private Function HeaderDictionary(ByVal sh As Worksheet, ByVal headerRow As Long) As Object
    Dim d As Object, c As Long, lc As Long, h As String
    Set d = CreateObject("Scripting.Dictionary")
    lc = LastCol(sh, headerRow)
    For c = 1 To lc
        h = CleanKey(Nz(sh.Cells(headerRow, c).Value))
        If Len(h) > 0 Then
            If Not d.Exists(h) Then d.Add h, c
        End If
    Next c
    Set HeaderDictionary = d
End Function

Private Function FindHeader(ByVal dict As Object, ParamArray names() As Variant) As Long
    Dim i As Long, k As String
    For i = LBound(names) To UBound(names)
        k = CleanKey(CStr(names(i)))
        If dict.Exists(k) Then
            FindHeader = CLng(dict(k))
            Exit Function
        End If
    Next i
    FindHeader = 0
End Function

Private Function GetCellText(ByVal sh As Worksheet, ByVal r As Long, ByVal c As Long) As String
    If c <= 0 Then GetCellText = "" Else GetCellText = Nz(sh.Cells(r, c).Value)
End Function

Private Function GetCellValue(ByVal sh As Worksheet, ByVal r As Long, ByVal c As Long) As Variant
    If c <= 0 Then GetCellValue = Empty Else GetCellValue = sh.Cells(r, c).Value
End Function

Private Sub ClearSheetKeepHeader(ByVal sh As Worksheet)
    Dim lr As Long
    lr = LastRow(sh, 1)
    If lr >= 2 Then sh.Range(sh.Rows(2), sh.Rows(lr)).ClearContents
End Sub

Public Sub BuildDestinationMaster()
    Dim src As Worksheet, dst As Worksheet, dict As Object, r As Long, lr As Long, key As String
    Dim keepTarget As Object, oldR As Long
    Set src = Ws(SH_W_CAND)
    Set dst = Ws(SH_W_DEST)
    Set keepTarget = CreateObject("Scripting.Dictionary")
    For oldR = 2 To LastRow(dst, DS_ID)
        If Len(Nz(dst.Cells(oldR, DS_KEY).Value)) > 0 Then keepTarget(dst.Cells(oldR, DS_KEY).Value) = Nz(dst.Cells(oldR, DS_TARGET).Value, "作成")
    Next oldR
    ClearSheetKeepHeader dst
    Set dict = CreateObject("Scripting.Dictionary")
    lr = LastRow(src, 1)
    Dim destR As Long
    destR = 2
    For r = 2 To lr
        If Nz(src.Cells(r, VC_TARGET).Value) = "要" Then
            key = Nz(src.Cells(r, VC_DEST_KEY).Value)
            If Len(key) = 0 Then key = DestKey(src.Cells(r, VC_BANK).Value, src.Cells(r, VC_SHOP).Value)
            If Not dict.Exists(key) Then
                dict.Add key, destR
                dst.Cells(destR, DS_ID).Value = "VD" & Format$(destR - 1, "0000")
                dst.Cells(destR, DS_KEY).Value = key
                dst.Cells(destR, DS_BANK).Value = src.Cells(r, VC_BANK).Value
                dst.Cells(destR, DS_SHOP).Value = src.Cells(r, VC_SHOP).Value
                If keepTarget.Exists(key) Then
                    dst.Cells(destR, DS_TARGET).Value = keepTarget(key)
                Else
                    dst.Cells(destR, DS_TARGET).Value = "作成"
                End If
                dst.Cells(destR, DS_REQ_SHEET).Value = SafeSheetName(dst.Cells(destR, DS_ID).Value & "_" & src.Cells(r, VC_BANK).Value & "_" & src.Cells(r, VC_SHOP).Value, "依頼_")
                dst.Cells(destR, DS_CTL_SHEET).Value = SafeSheetName(dst.Cells(destR, DS_ID).Value & "_" & src.Cells(r, VC_BANK).Value & "_" & src.Cells(r, VC_SHOP).Value, "控え_")
                destR = destR + 1
            End If
        End If
    Next r
    UpdateDestinationCounts
End Sub

Public Sub UpdateDestinationCounts()
    Dim cand As Worksheet, dest As Worksheet, r As Long, lr As Long, dr As Long, dlr As Long
    Dim key As String, dRows As Object, dateDict As Object
    Set cand = Ws(SH_W_CAND)
    Set dest = Ws(SH_W_DEST)
    Set dRows = CreateObject("Scripting.Dictionary")
    dlr = LastRow(dest, DS_ID)
    For dr = 2 To dlr
        dRows(dest.Cells(dr, DS_KEY).Value) = dr
        dest.Cells(dr, DS_TX_COUNT).Value = 0
        dest.Cells(dr, DS_TX_DATE_COUNT).Value = 0
    Next dr
    Set dateDict = CreateObject("Scripting.Dictionary")
    lr = LastRow(cand, VC_ID)
    For r = 2 To lr
        If Nz(cand.Cells(r, VC_TARGET).Value) = "要" Then
            key = cand.Cells(r, VC_DEST_KEY).Value
            If dRows.Exists(key) Then
                dr = dRows(key)
                dest.Cells(dr, DS_TX_COUNT).Value = NzDbl(dest.Cells(dr, DS_TX_COUNT).Value) + 1
                If IsDate(cand.Cells(r, VC_TX_DATE).Value) Then dateDict(key & "|" & CLng(CDate(cand.Cells(r, VC_TX_DATE).Value))) = 1
            End If
        End If
    Next r
    Dim k As Variant, parts As Variant
    For Each k In dateDict.Keys
        parts = Split(CStr(k), "|")
        If dRows.Exists(parts(0)) Then
            dr = dRows(parts(0))
            dest.Cells(dr, DS_TX_DATE_COUNT).Value = NzDbl(dest.Cells(dr, DS_TX_DATE_COUNT).Value) + 1
        End If
    Next k
End Sub

Public Sub RefreshDestinationList()
    Dim sh As Worksheet, src As Worksheet, r As Long, lr As Long, outR As Long
    Set sh = Ws(SH_DEST_LIST)
    Set src = Ws(SH_W_DEST)
    ClearSheetSafe sh
    sh.Cells.Font.Name = "Meiryo UI"
    sh.Cells.Font.Size = 10
    sh.Columns("A").ColumnWidth = 12
    sh.Columns("B").ColumnWidth = 22
    sh.Columns("C").ColumnWidth = 24
    sh.Columns("D").ColumnWidth = 12
    sh.Columns("E").ColumnWidth = 12
    sh.Columns("F").ColumnWidth = 12
    sh.Columns("G").ColumnWidth = 26
    sh.Columns("H").ColumnWidth = 26
    sh.Columns("I").ColumnWidth = 28
    sh.Rows.RowHeight = 21

    sh.Range("A1:I1").Merge
    With sh.Range("A1")
        .Value = "依頼先一覧（銀行名＋取扱店ごとに依頼用・控え用を1セット作成）"
        .Interior.Color = C_DARK
        .Font.Color = vbWhite
        .Font.Bold = True
        .Font.Size = 14
        .HorizontalAlignment = xlCenter
    End With
    sh.Range("A2:I2").Merge
    With sh.Range("A2")
        .Value = "F列をダブルクリックすると作成/除外を切替。依頼用シート・控え用シートは必ず依頼先単位で分かれます。複数依頼先を同じ依頼表に混在させません。"
        .Interior.Color = C_LIGHT_BLUE
        .Font.Bold = True
        .Font.Color = C_DARK
        .WrapText = True
    End With
    sh.Range("A4:I4").Value = Array("依頼先ID", "銀行名", "取扱店", "対象取引件数", "依頼日数", "作成対象", "依頼用シート", "控え用シート", "メモ")
    sh.Range("A4:I4").Interior.Color = C_NAVY
    sh.Range("A4:I4").Font.Color = vbWhite
    sh.Range("A4:I4").Font.Bold = True
    sh.Range("A4:I4").HorizontalAlignment = xlCenter

    lr = LastRow(src, DS_ID)
    outR = 5
    For r = 2 To lr
        sh.Cells(outR, 1).Value = src.Cells(r, DS_ID).Value
        sh.Cells(outR, 2).Value = src.Cells(r, DS_BANK).Value
        sh.Cells(outR, 3).Value = src.Cells(r, DS_SHOP).Value
        sh.Cells(outR, 4).Value = src.Cells(r, DS_TX_COUNT).Value
        sh.Cells(outR, 5).Value = src.Cells(r, DS_REQUEST_DATE_COUNT).Value
        sh.Cells(outR, 6).Value = src.Cells(r, DS_TARGET).Value
        sh.Cells(outR, 7).Value = src.Cells(r, DS_REQ_SHEET).Value
        sh.Cells(outR, 8).Value = src.Cells(r, DS_CTL_SHEET).Value
        sh.Cells(outR, 9).Value = src.Cells(r, DS_MEMO).Value
        If outR Mod 2 = 0 Then sh.Range(sh.Cells(outR, 1), sh.Cells(outR, 9)).Interior.Color = ThemeColor("canvas")
        outR = outR + 1
    Next r
    With sh.Range("A4:I" & Application.Max(outR - 1, 5))
        .Borders.Color = C_BORDER
        .VerticalAlignment = xlCenter
        .WrapText = True
    End With
    sh.Range("F5:F" & Application.Max(outR - 1, 5)).Validation.Delete
    sh.Range("F5:F" & Application.Max(outR - 1, 5)).Validation.Add Type:=xlValidateList, AlertStyle:=xlValidAlertStop, Formula1:="作成,除外"
    AddButton sh, "入力画面へ", "ShowNormalMode", 20, 20, 110, 30, ThemeColor("muted")
    AddButton sh, "依頼表作成", "BuildVoucherSheets", 145, 20, 110, 30, C_ORANGE
    ApplyDestinationListProtection
    ActiveWindow.DisplayGridlines = False
End Sub

Public Sub UpdateMainStatus()
    Dim m As Worksheet
    Set m = Ws(SH_MAIN)
    m.Range("C8").Value = IIf(Dir(CommonDataPath()) = vbNullString, "未検出", "読込済")
    m.Range("C9").Value = Application.Max(LastRow(Ws(SH_W_CAND), 1) - 1, 0) & "件"
    m.Range("C10").Value = Application.Max(LastRow(Ws(SH_W_DEST), 1) - 1, 0) & "件"
    m.Range("C11").Value = Application.Max(LastRow(Ws(SH_W_DATES), 1) - 1, 0) & "日"
    m.Range("C12").Value = Application.Max(LastRow(Ws(SH_W_CONTROL), 1) - 1, 0) & "件"
    m.Range("C13").Value = HolidayCoverageStatusText()
End Sub

Public Sub ShowDestinationList()
    RefreshDestinationList
    ApplyDestinationListProtection
    Ws(SH_DEST_LIST).Visible = xlSheetVisible
    Ws(SH_DEST_LIST).Activate
End Sub

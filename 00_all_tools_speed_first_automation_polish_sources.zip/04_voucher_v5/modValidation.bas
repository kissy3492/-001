Attribute VB_Name = "modValidation"
Option Explicit

Public Sub RunVoucherCheck()
    On Error GoTo EH
    AppBegin "整合チェック中..."
    Dim sh As Worksheet
    Set sh = Ws(SH_CHECK)
    ClearSheetSafe sh
    sh.Range("A1:D1").Value = Array("区分", "内容", "対象", "対応")
    With sh.Range("A1:D1")
        .Interior.Color = C_NAVY
        .Font.Color = vbWhite
        .Font.Bold = True
    End With
    Dim row As Long
    row = 2
    If LastRow(Ws(SH_W_CAND), 1) <= 1 Then AddCheck row, "エラー", "伝票依頼候補がありません。", SRC_VOUCHER, "分析ツールで共通データ保存後、読込してください。"
    CheckCandidates row
    CheckDestinations row
    CheckDates row
    If row = 2 Then AddCheck row, "OK", "重大な問題は見つかりません。", "全体", "依頼表作成へ進めます。"
    With sh.Range("A1:D" & row - 1)
        .Borders.Color = C_BORDER
        .WrapText = True
        .VerticalAlignment = xlTop
    End With
    sh.Columns("A:D").AutoFit
    CapColumns sh, 1, 4, 45
    ProtectSheetReadOnly sh
    sh.Visible = xlSheetVisible
    sh.Activate
    AppEnd ""
    Exit Sub
EH:
    AppEnd ""
    MsgBox "整合チェックでエラー: " & Err.Description, vbExclamation
End Sub

Private Sub CheckCandidates(ByRef row As Long)
    Dim sh As Worksheet, r As Long, lr As Long
    Set sh = Ws(SH_W_CAND)
    lr = LastRow(sh, 1)
    For r = 2 To lr
        If Nz(sh.Cells(r, VC_TARGET).Value) = "要" Then
            If Not IsDate(sh.Cells(r, VC_TX_DATE).Value) Then AddCheck row, "エラー", "取引日が不正です。", sh.Cells(r, VC_ID).Value, "分析結果を確認してください。"
            If Len(Nz(sh.Cells(r, VC_BANK).Value)) = 0 Then AddCheck row, "エラー", "銀行名が空欄です。", sh.Cells(r, VC_ID).Value, "資金操作表側を確認してください。"
            If Len(Nz(sh.Cells(r, VC_SHOP).Value)) = 0 Then AddCheck row, "エラー", "取扱店が空欄です。", sh.Cells(r, VC_ID).Value, "取扱店変換または分析結果を確認してください。"
        End If
    Next r
End Sub

Private Sub CheckDestinations(ByRef row As Long)
    Dim sh As Worksheet, r As Long, lr As Long, dict As Object, key As String
    Set sh = Ws(SH_W_DEST)
    Set dict = CreateObject("Scripting.Dictionary")
    lr = LastRow(sh, 1)
    For r = 2 To lr
        key = Nz(sh.Cells(r, DS_KEY).Value)
        If Len(key) = 0 Then AddCheck row, "エラー", "依頼先キーが空です。", sh.Cells(r, DS_ID).Value, "銀行名・取扱店を確認してください。"
        If dict.Exists(key) Then AddCheck row, "エラー", "依頼先キーが重複しています。", key, "依頼先一覧を再作成してください。"
        dict(key) = 1
        If sh.Cells(r, DS_TARGET).Value = "作成" And NzDbl(sh.Cells(r, DS_TX_COUNT).Value) = 0 Then AddCheck row, "警告", "作成対象ですが対象取引が0件です。", sh.Cells(r, DS_ID).Value, "通常は除外してください。"
    Next r
End Sub

Private Sub CheckDates(ByRef row As Long)
    Dim perPage As Long
    perPage = SettingLong("依頼用1ページ最大日数", 60)
    If perPage <> 60 Then AddCheck row, "注意", "依頼用1ページ最大日数が60以外です。", perPage, "要件上は60日が標準です。"
    If IsSettingYes("前後銀行営業日を含める", True) Then
        If EnsureHolidayCoverageForVoucherDates(False, False) Then
            AddCheck row, "OK", "祝日データは必要範囲だけ取得済です。", HolidayCoverageStatusText(), "依頼表作成へ進めます。"
            CheckRequestDatesAreBankBusinessDays row
        Else
            AddCheck row, "エラー", "祝日データを自動取得できません。", "必要範囲: " & RequiredHolidayRangeText(), "通信環境・祝日URL・対象日が公式CSVの収録範囲内か確認してください。"
        End If
    Else
        AddCheck row, "注意", "前後銀行営業日は含めない設定です。", "設定", "依頼用は元取引日のみになります。"
    End If
End Sub

Private Sub CheckRequestDatesAreBankBusinessDays(ByRef row As Long)
    Dim sh As Worksheet, r As Long, lr As Long, kind As String, d As Date
    Set sh = Ws(SH_W_DATES)
    lr = LastRow(sh, RD_ID)
    If lr <= 1 Then Exit Sub
    For r = 2 To lr
        kind = Nz(sh.Cells(r, RD_DATE_KIND).Value)
        If kind <> "当日" And IsDate(sh.Cells(r, RD_REQUEST_DATE).Value) Then
            d = CDate(sh.Cells(r, RD_REQUEST_DATE).Value)
            If Not IsBankBusinessDay(d) Then
                AddCheck row, "エラー", "前後日に銀行営業日でない日が含まれています。", Format$(d, "yyyy/m/d") & " " & BankHolidayName(d), "依頼表を再作成してください。"
            End If
        End If
    Next r
End Sub

Private Sub AddCheck(ByRef row As Long, ByVal level As String, ByVal content As String, ByVal target As String, ByVal action As String)
    With Ws(SH_CHECK)
        .Cells(row, 1).Value = level
        .Cells(row, 2).Value = content
        .Cells(row, 3).Value = target
        .Cells(row, 4).Value = action
        Select Case level
            Case "エラー": .Rows(row).Interior.Color = C_LIGHT_RED
            Case "警告": .Rows(row).Interior.Color = C_LIGHT_YELLOW
            Case "注意": .Rows(row).Interior.Color = C_LIGHT_BLUE
            Case "OK": .Rows(row).Interior.Color = C_LIGHT_GREEN
        End Select
    End With
    row = row + 1
End Sub


Public Function HasVoucherCheckError() As Boolean
    Dim sh As Worksheet, r As Long
    Set sh = Ws(SH_CHECK)
    For r = 2 To LastRow(sh, 1)
        If Nz(sh.Cells(r, 1).Value) = "エラー" Then
            HasVoucherCheckError = True
            Exit Function
        End If
    Next r
End Function

Public Function MissingHolidayCoverageMessage() As String
    ' 旧版互換。v5.1以降は年単位ではなく、実際の依頼日最小～最大の範囲で管理する。
    If RequiredHolidayRangeText() = "対象なし" Then Exit Function
    If Not EnsureHolidayCoverageForVoucherDates(False, False) Then
        MissingHolidayCoverageMessage = "必要範囲: " & RequiredHolidayRangeText()
    End If
End Function


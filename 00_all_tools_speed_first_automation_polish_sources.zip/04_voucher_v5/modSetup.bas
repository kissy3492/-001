Attribute VB_Name = "modSetup"
Option Explicit

Public Sub SetupWorkbook()
    On Error GoTo EH
    AppBegin "伝票依頼表作成ツールを初期化中..."
    BuildAllSheets
    BuildMainSheet
    BuildSettingsSheet
    BuildWorkSheets
    ShowNormalMode
    ApplyVoucherSheetProtections
    AppEnd ""
    MsgBox "伝票依頼表作成ツールの初期設定が完了しました。" & vbCrLf & _
           "通常操作は「伝票依頼入力」シートだけで進められます。", vbInformation
    Exit Sub
EH:
    AppEnd ""
    MsgBox "初期設定でエラー: " & Err.Description, vbExclamation
End Sub

Private Sub BuildAllSheets()
    Dim nm As Variant
    For Each nm In Array(SH_MAIN, SH_SETTINGS, SH_DEST_LIST, SH_REQUEST, SH_CONTROL, SH_CHECK, _
                         SH_W_CAND, SH_W_DEST, SH_W_DATES, SH_W_CONTROL, SH_W_HOLIDAY, SH_W_LOG, SH_W_ID)
        GetOrCreateSheet CStr(nm)
    Next nm
End Sub

Private Sub BuildMainSheet()
    Dim sh As Worksheet
    Set sh = Ws(SH_MAIN)
    ClearSheetSafe sh
    ThemeApplyCanvas sh

    sh.Cells.Font.Name = THEME_FONT
    sh.Cells.Font.Size = 10
    sh.Columns("A").ColumnWidth = 2
    sh.Columns("B").ColumnWidth = 16
    sh.Columns("C").ColumnWidth = 18
    sh.Columns("D").ColumnWidth = 18
    sh.Columns("E").ColumnWidth = 18
    sh.Columns("F").ColumnWidth = 18
    sh.Columns("G").ColumnWidth = 18
    sh.Columns("H").ColumnWidth = 18
    sh.Rows.RowHeight = 22

    sh.Range("B2:H3").Merge
    ThemeApplyTitle sh.Range("B2:H3"), "04_伝票依頼表作成ツール"
    sh.Rows("2:3").RowHeight = 28

    sh.Range("B5:H5").Merge
    With sh.Range("B5")
        .Value = "分析ツールで「伝票依頼＝要」とした取引を読み込み、銀行名＋取扱店ごとに「依頼用＋控え用」の1セットを分けて作成します。複数依頼先を1枚に混在させません。"
    End With
    ThemeApplyHintRange sh.Range("B5:H5"), "info-very-soft"

    BuildStatusPanel sh
    BuildOperationPanel sh
    BuildGuidancePanel sh
    BuildMiniSummary sh

    sh.Range("B7:H28").Borders.Color = C_BORDER
    sh.Range("B7:H28").VerticalAlignment = xlCenter
    sh.Activate
    ActiveWindow.DisplayGridlines = False
    sh.Range("A1").Select
End Sub

Private Sub BuildStatusPanel(ByVal sh As Worksheet)
    sh.Range("B7:D7").Merge
    ThemeApplySection sh.Range("B7:D7"), "連携状態"
    ThemeApplyStatusCard sh.Range("B8:D14")
    sh.Range("B8:C14").Interior.Color = ThemeColor("locked")
    sh.Range("B8:B14").Font.Bold = True
    sh.Range("B8:B14").Value = Application.Transpose(Array("共通データ", "候補取引", "依頼先", "依頼日", "控え明細", "祝日", "最終作成"))
    sh.Range("C8:C14").Value = Application.Transpose(Array("未読込", "0件", "0件", "0日", "0件", "未取得", "未作成"))
    sh.Range("C8:C14").Interior.Color = vbWhite
    sh.Range("D8:D14").Merge
    With sh.Range("D8")
        .Value = "通常はこの画面だけで操作します。入力や判断は分析ツールで済ませ、このツールでは依頼表化に集中します。"
        .WrapText = True
        .Interior.Color = ThemeColor("info-soft")
        .VerticalAlignment = xlTop
    End With
End Sub

Private Sub BuildOperationPanel(ByVal sh As Worksheet)
    sh.Range("F7:H7").Merge
    ThemeApplySection sh.Range("F7:H7"), "操作"
    ThemeApplyCommandBar sh.Range("F8:H14")
    AddButton sh, "共通データ読込", "LoadCommonData", 390, 160, 120, 34, C_BLUE
    AddButton sh, "祝日CSV取込", "ImportHolidayCsv", 520, 160, 120, 34, C_TEAL
    AddButton sh, "必要祝日取得", "DownloadHolidayCsv", 650, 160, 120, 34, C_TEAL
    AddButton sh, "依頼先確認", "ShowDestinationList", 390, 205, 120, 34, C_PURPLE
    AddButton sh, "整合チェック", "RunVoucherCheck", 520, 205, 120, 34, C_RED
    AddButton sh, "依頼表作成", "BuildVoucherSheets", 650, 205, 120, 34, C_ORANGE
    AddButton sh, "共通保存", "SaveVoucherCommonData", 390, 250, 120, 34, C_GREEN
    AddButton sh, "最終出力", "ExportVoucherWorkbooks", 520, 250, 120, 34, C_PURPLE
    AddButton sh, "設定", "ShowSettings", 650, 250, 120, 34, ThemeColor("muted")
End Sub

Private Sub BuildGuidancePanel(ByVal sh As Worksheet)
    sh.Range("B16:H16").Merge
    ThemeApplySection sh.Range("B16:H16"), "操作順"
    sh.Range("B17:H20").Merge
    With sh.Range("B17")
        .Value = "1. 共通データ読込 → 2. 依頼先確認 → 3. 依頼表作成（祝日は必要範囲を自動取得） → 4. 最終出力" & vbCrLf & _
                 "依頼先は必ず「銀行名＋取扱店」で分離し、依頼先ごとに依頼用シートと控え用シートを1セットで作成します。依頼用は設定に応じて元取引日だけ、または前後銀行営業日を含む日付だけを表示。控え用は元取引日ごとの見出しの下に対象取引を出します。"
        .WrapText = True
        .Interior.Color = ThemeColor("success-bg")
        .VerticalAlignment = xlTop
    End With
End Sub

Private Sub BuildMiniSummary(ByVal sh As Worksheet)
    sh.Range("B22:H22").Merge
    ThemeApplySection sh.Range("B22:H22"), "依頼表仕様"
    Dim spec As Variant, i As Long
    spec = Array( _
        Array("依頼先単位", "銀行名＋取扱店。1依頼先につき依頼用＋控え用の1セット。複数依頼先を同じ依頼表に混在させない。"), _
        Array("依頼用", "上部に銀行名・支店名欄。支店名欄には取扱店を表示。下部は依頼日だけ。"), _
        Array("控え用", "元取引日・日付別件数・対象取引明細を表示。前後1日は含めない。"), _
        Array("日付拡張", "設定で前後銀行営業日を含める/含めないを切替。含める場合も土日・祝日・12/31～1/3は前後日に含めない。祝日は作成対象の最古依頼日～最新依頼日の範囲だけ自動保持。"), _
        Array("ページ", "依頼用は1ページ最大60日。超過時は同じ依頼先内でページ分割。"))
    For i = 0 To 4
        sh.Cells(23 + i, 2).Value = spec(i)(0)
        sh.Range(sh.Cells(23 + i, 3), sh.Cells(23 + i, 8)).Merge
        sh.Cells(23 + i, 3).Value = spec(i)(1)
    Next i
    sh.Range("B23:B27").Font.Bold = True
    ThemeApplyZebraTable sh.Range("B23:H27"), 0
    sh.Range("C23:H27").WrapText = True
End Sub

Private Sub BuildSettingsSheet()
    Dim sh As Worksheet
    Set sh = Ws(SH_SETTINGS)
    ClearSheetSafe sh
    ThemeApplyCanvas sh
    sh.Cells.Font.Name = THEME_FONT
    sh.Cells.Font.Size = 10
    sh.Columns("A").ColumnWidth = 24
    sh.Columns("B").ColumnWidth = 18
    sh.Columns("C").ColumnWidth = 58
    sh.Range("A1:C1").Merge
    ThemeApplyTitle sh.Range("A1:C1"), "伝票依頼表作成 設定"
    sh.Range("A3:C3").Value = Array("設定項目", "値", "説明")
    ThemeApplyTableHeader sh.Range("A3:C3"), True
    Dim data As Variant, r As Long
    data = Array( _
        Array("前後銀行営業日を含める", "する", "する: 元取引日の前銀行営業日・翌銀行営業日を依頼日に追加。しない: 元取引日だけを依頼日にする。"), _
        Array("前後日数", 1, "前後銀行営業日を含める場合の片側日数。標準は1。"), _
        Array("依頼用1ページ最大日数", 60, "1ページに表示する依頼日の最大数。要件上60日。"), _
        Array("依頼日表示", "和暦曜日", "和暦曜日 / 和暦 / 西暦 から選択。"), _
        Array("控え用摘要表示", "する", "控え用に摘要を出すか。"), _
        Array("依頼先別ファイル", "しない", "従来互換用。依頼先別セット出力を使う場合は通常変更不要。"), _
        Array("依頼先別セット出力", "する", "する: 依頼先ごとに依頼用・控え用の2シート入りブックも出力。複数依頼先を混在させないため標準はする。"), _
        Array("祝日URL", HOLIDAY_URL, "自動取得時の公式CSV URL。作成対象の最古依頼日～最新依頼日の範囲だけW_祝日に保持。"), _
        Array("最終出力前チェック", "する", "出力前に依頼先・日付・件数チェックを行う。"))
    For r = 0 To 8
        sh.Cells(4 + r, 1).Value = data(r)(0)
        sh.Cells(4 + r, 2).Value = data(r)(1)
        sh.Cells(4 + r, 3).Value = data(r)(2)
    Next r
    sh.Range("A4:A12").Font.Bold = True
    sh.Range("B4:B12").Interior.Color = vbWhite
    sh.Range("C4:C12").Interior.Color = ThemeColor("locked")
    ThemeApplyFormCard sh.Range("A3:C12"), "accent"
    sh.Range("C:C").WrapText = True
    sh.Range("B4").Validation.Delete
    sh.Range("B4").Validation.Add Type:=xlValidateList, AlertStyle:=xlValidAlertStop, Formula1:="する,しない"
    sh.Range("B7").Validation.Delete
    sh.Range("B7").Validation.Add Type:=xlValidateList, AlertStyle:=xlValidAlertStop, Formula1:="和暦曜日,和暦,西暦"
    sh.Range("B8").Validation.Delete
    sh.Range("B8").Validation.Add Type:=xlValidateList, AlertStyle:=xlValidAlertStop, Formula1:="する,しない"
    sh.Range("B9").Validation.Delete
    sh.Range("B9").Validation.Add Type:=xlValidateList, AlertStyle:=xlValidAlertStop, Formula1:="する,しない"
    sh.Range("B10").Validation.Delete
    sh.Range("B10").Validation.Add Type:=xlValidateList, AlertStyle:=xlValidAlertStop, Formula1:="する,しない"
    sh.Range("B12").Validation.Delete
    sh.Range("B12").Validation.Add Type:=xlValidateList, AlertStyle:=xlValidAlertStop, Formula1:="する,しない"
    AddButton sh, "入力画面へ", "ShowNormalMode", 20, 260, 120, 32, ThemeColor("muted")
    ActiveWindow.DisplayGridlines = False
End Sub

Private Sub BuildWorkSheets()
    BuildSheetHeader Ws(SH_W_CAND), Array("依頼候補ID", "分析候補ID", "分析明細ID", "取引ID", "取引日", "銀行名", "支店名", "取扱店", "人物ID", "人物名", "続柄", "区分", "出金", "入金", "摘要", "伝票依頼", "採用", "依頼対象", "メモ", "依頼先キー", "データ状態")
    BuildSheetHeader Ws(SH_W_DEST), Array("依頼先ID", "依頼先キー", "銀行名", "取扱店", "取引日数", "依頼日数", "対象取引件数", "作成対象", "依頼用シート名", "控え用シート名", "メモ")
    BuildSheetHeader Ws(SH_W_DATES), Array("依頼日ID", "依頼先ID", "依頼先キー", "銀行名", "取扱店", "元取引日", "依頼日", "日付種別", "曜日", "休日区分", "元取引件数", "元候補ID")
    BuildSheetHeader Ws(SH_W_CONTROL), Array("依頼先ID", "依頼先キー", "銀行名", "取扱店", "取引日", "件数", "分析候補ID", "取引ID", "区分", "人物名", "続柄", "出金", "入金", "摘要", "メモ")
    BuildSheetHeader Ws(SH_W_HOLIDAY), Array("日付", "名称", "ソース", "更新日時", "取得範囲開始", "取得範囲終了", "取得元URL")
    BuildSheetHeader Ws(SH_CHECK), Array("区分", "内容", "対象", "対応")
    BuildSheetHeader Ws(SH_DEST_LIST), Array("依頼先ID", "銀行名", "取扱店", "対象取引件数", "依頼日数", "作成対象", "依頼用シート", "控え用シート", "メモ")
    Ws(SH_W_CAND).Visible = xlSheetVeryHidden
    Ws(SH_W_DEST).Visible = xlSheetVeryHidden
    Ws(SH_W_DATES).Visible = xlSheetVeryHidden
    Ws(SH_W_CONTROL).Visible = xlSheetVeryHidden
    Ws(SH_W_HOLIDAY).Visible = xlSheetVeryHidden
    Ws(SH_W_LOG).Visible = xlSheetVeryHidden
    Ws(SH_W_ID).Visible = xlSheetVeryHidden
End Sub

Private Sub BuildSheetHeader(ByVal sh As Worksheet, ByVal headers As Variant)
    ClearSheetSafe sh
    Dim i As Long
    For i = LBound(headers) To UBound(headers)
        sh.Cells(1, i + 1).Value = headers(i)
    Next i
    ThemeApplyTableHeader sh.Range(sh.Cells(1, 1), sh.Cells(1, UBound(headers) + 1)), True
    sh.Cells.Font.Name = THEME_FONT
    sh.Cells.Font.Size = 10
    sh.Rows(1).RowHeight = 22
    sh.Range("A1").AutoFilter
End Sub

Public Sub AddButton(ByVal sh As Worksheet, ByVal text As String, ByVal macroName As String, ByVal x As Double, ByVal y As Double, ByVal w As Double, ByVal h As Double, ByVal colorValue As Long)
    Dim shp As Shape
    Dim fillColor As Long
    Set shp = sh.Shapes.AddShape(msoShapeRoundedRectangle, x, y, w, h)
    shp.Name = "btn_" & Replace(text, " ", "") & "_" & Format$(Timer * 1000, "0")
    fillColor = IIf(colorValue = 0, ThemeButtonFill(text), colorValue)
    ThemeStyleButtonShapeWithColor shp, text, fillColor, fillColor, ThemeReadableFontColor(fillColor), macroName
End Sub

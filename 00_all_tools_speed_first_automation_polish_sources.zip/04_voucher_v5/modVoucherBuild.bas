Attribute VB_Name = "modVoucherBuild"
Option Explicit

Public Sub BuildVoucherSheets()
    On Error GoTo EH
    AppBegin "伝票依頼表を作成中..."
    If LastRow(Ws(SH_W_CAND), 1) <= 1 Then Err.Raise vbObjectError + 401, , "伝票依頼候補がありません。先に共通データ読込を実行してください。"
    SyncDestinationTargetsFromList
    BuildDestinationMaster
    If IsSettingYes("前後銀行営業日を含める", True) Then
        If Not EnsureHolidayCoverageForVoucherDates(False, False) Then
            Err.Raise vbObjectError + 402, , "祝日データを自動取得できませんでした。通信環境・祝日URL・対象日が公式CSVの収録範囲内か確認してください。"
        End If
    End If
    BuildRequestDates
    BuildControlDetails
    RenderDestinationSetSheets
    RefreshDestinationList
    RenderRequestPreview
    RenderControlPreview
    ShowAfterBuild
    ProtectOutputSheets
    UpdateMainStatus
    Ws(SH_MAIN).Range("C14").Value = Format$(Now, "yyyy/m/d h:mm")
    WriteLog "依頼表作成完了"
    AppEnd ""
    MsgBox "依頼表を作成しました。最終出力へ進めます。", vbInformation
    Exit Sub
EH:
    AppEnd ""
    MsgBox "依頼表作成でエラー: " & Err.Description, vbExclamation
End Sub

Public Sub SyncDestinationTargetsFromList()
    If Not SheetExists(SH_DEST_LIST) Then Exit Sub
    Dim list As Worksheet, dest As Worksheet, d As Object, r As Long, lr As Long, key As String
    Set list = Ws(SH_DEST_LIST)
    Set dest = Ws(SH_W_DEST)
    Set d = CreateObject("Scripting.Dictionary")
    lr = LastRow(list, 1)
    For r = 5 To lr
        If Len(Nz(list.Cells(r, 1).Value)) > 0 Then d(Nz(list.Cells(r, 1).Value)) = Nz(list.Cells(r, 6).Value, "作成")
    Next r
    lr = LastRow(dest, DS_ID)
    For r = 2 To lr
        key = Nz(dest.Cells(r, DS_ID).Value)
        If d.Exists(key) Then dest.Cells(r, DS_TARGET).Value = d(key)
    Next r
End Sub

Private Sub BuildRequestDates()
    Dim out As Worksheet, cand As Worksheet, dest As Worksheet
    Set out = Ws(SH_W_DATES)
    Set cand = Ws(SH_W_CAND)
    Set dest = Ws(SH_W_DEST)
    ClearRows out
    If IsSettingYes("前後銀行営業日を含める", True) Then EnsureHolidayCacheLoaded

    Dim destRows As Object, r As Long, lr As Long, key As String
    Set destRows = CreateObject("Scripting.Dictionary")
    For r = 2 To LastRow(dest, DS_ID)
        If Nz(dest.Cells(r, DS_TARGET).Value) = "作成" Then destRows(dest.Cells(r, DS_KEY).Value) = r
        dest.Cells(r, DS_REQUEST_DATE_COUNT).Value = 0
    Next r

    Dim dateSet As Object
    Set dateSet = CreateObject("Scripting.Dictionary")
    Dim outR As Long
    outR = 2
    lr = LastRow(cand, VC_ID)
    For r = 2 To lr
        If Nz(cand.Cells(r, VC_TARGET).Value) = "要" And IsDate(cand.Cells(r, VC_TX_DATE).Value) Then
            key = Nz(cand.Cells(r, VC_DEST_KEY).Value)
            If destRows.Exists(key) Then
                AddRequestDate out, dateSet, outR, dest, destRows(key), cand, r, CDate(cand.Cells(r, VC_TX_DATE).Value), "当日"
                If IsSettingYes("前後銀行営業日を含める", True) Then
                    AddBeforeAfterDates out, dateSet, outR, dest, destRows(key), cand, r, CDate(cand.Cells(r, VC_TX_DATE).Value)
                End If
            End If
        End If
    Next r
    If outR > 2 Then SortRequestDates out
    UpdateRequestDateCounts
End Sub

Private Sub AddBeforeAfterDates(ByVal out As Worksheet, ByVal dateSet As Object, ByRef outR As Long, ByVal dest As Worksheet, ByVal destRow As Long, ByVal cand As Worksheet, ByVal candRow As Long, ByVal txDate As Date)
    Dim mode As String, n As Long, i As Long, prevD As Date, nextD As Date
    mode = "銀行営業日" ' v4: 前後日を含める場合は常に銀行営業日で展開する。
    n = SettingLong("前後日数", 1)
    If n < 0 Then n = 0
    If n > 5 Then n = 5
    prevD = txDate
    nextD = txDate
    For i = 1 To n
        prevD = PreviousBankBusinessDay(prevD)
        nextD = NextBankBusinessDay(nextD)
        AddRequestDate out, dateSet, outR, dest, destRow, cand, candRow, prevD, "前日"
        AddRequestDate out, dateSet, outR, dest, destRow, cand, candRow, nextD, "翌日"
    Next i
End Sub

Private Sub AddRequestDate(ByVal out As Worksheet, ByVal dateSet As Object, ByRef outR As Long, ByVal dest As Worksheet, ByVal destRow As Long, ByVal cand As Worksheet, ByVal candRow As Long, ByVal reqDate As Date, ByVal kind As String)
    ' 前日・翌日は、設定で「前後銀行営業日を含める=する」の場合だけ追加される。追加する日は必ず銀行営業日に限定する。
    If kind <> "当日" Then
        If Not IsBankBusinessDay(reqDate) Then Exit Sub
    End If
    Dim uniq As String
    uniq = dest.Cells(destRow, DS_ID).Value & "|" & CLng(DateValue(reqDate))
    If dateSet.Exists(uniq) Then
        Dim rowIndex As Long
        rowIndex = dateSet(uniq)
        If InStr(out.Cells(rowIndex, RD_SOURCE_IDS).Value, cand.Cells(candRow, VC_ID).Value) = 0 Then
            out.Cells(rowIndex, RD_SOURCE_IDS).Value = out.Cells(rowIndex, RD_SOURCE_IDS).Value & "," & cand.Cells(candRow, VC_ID).Value
            out.Cells(rowIndex, RD_SOURCE_COUNT).Value = NzDbl(out.Cells(rowIndex, RD_SOURCE_COUNT).Value) + 1
        End If
        Exit Sub
    End If
    dateSet.Add uniq, outR
    out.Cells(outR, RD_ID).Value = "VDT" & Format$(outR - 1, "000000")
    out.Cells(outR, RD_DEST_ID).Value = dest.Cells(destRow, DS_ID).Value
    out.Cells(outR, RD_DEST_KEY).Value = dest.Cells(destRow, DS_KEY).Value
    out.Cells(outR, RD_BANK).Value = dest.Cells(destRow, DS_BANK).Value
    out.Cells(outR, RD_SHOP).Value = dest.Cells(destRow, DS_SHOP).Value
    out.Cells(outR, RD_SOURCE_DATE).Value = cand.Cells(candRow, VC_TX_DATE).Value
    out.Cells(outR, RD_REQUEST_DATE).Value = reqDate
    out.Cells(outR, RD_DATE_KIND).Value = kind
    out.Cells(outR, RD_WEEKDAY).Value = WeekdayNameJP(Weekday(reqDate, vbSunday))
    out.Cells(outR, RD_HOLIDAY).Value = BankHolidayName(reqDate)
    out.Cells(outR, RD_SOURCE_COUNT).Value = 1
    out.Cells(outR, RD_SOURCE_IDS).Value = cand.Cells(candRow, VC_ID).Value
    outR = outR + 1
End Sub

Private Sub SortRequestDates(ByVal sh As Worksheet)
    Dim lr As Long
    lr = LastRow(sh, RD_ID)
    With sh.Sort
        .SortFields.Clear
        .SortFields.Add Key:=sh.Range(sh.Cells(2, RD_DEST_ID), sh.Cells(lr, RD_DEST_ID)), SortOn:=xlSortOnValues, Order:=xlAscending
        .SortFields.Add Key:=sh.Range(sh.Cells(2, RD_REQUEST_DATE), sh.Cells(lr, RD_REQUEST_DATE)), SortOn:=xlSortOnValues, Order:=xlAscending
        .SetRange sh.Range(sh.Cells(1, 1), sh.Cells(lr, RD_COLS))
        .Header = xlYes
        .Apply
    End With
End Sub

Private Sub UpdateRequestDateCounts()
    Dim dates As Worksheet, dest As Worksheet, r As Long, lr As Long, d As Object, key As String
    Set dates = Ws(SH_W_DATES)
    Set dest = Ws(SH_W_DEST)
    Set d = CreateObject("Scripting.Dictionary")
    For r = 2 To LastRow(dest, DS_ID)
        d(dest.Cells(r, DS_ID).Value) = r
        dest.Cells(r, DS_REQUEST_DATE_COUNT).Value = 0
    Next r
    lr = LastRow(dates, RD_ID)
    For r = 2 To lr
        key = dates.Cells(r, RD_DEST_ID).Value
        If d.Exists(key) Then dest.Cells(d(key), DS_REQUEST_DATE_COUNT).Value = NzDbl(dest.Cells(d(key), DS_REQUEST_DATE_COUNT).Value) + 1
    Next r
End Sub

Private Sub BuildControlDetails()
    Dim out As Worksheet, cand As Worksheet, dest As Worksheet, d As Object, r As Long, lr As Long, outR As Long, key As String
    Set out = Ws(SH_W_CONTROL)
    Set cand = Ws(SH_W_CAND)
    Set dest = Ws(SH_W_DEST)
    ClearRows out
    Set d = CreateObject("Scripting.Dictionary")
    For r = 2 To LastRow(dest, DS_ID)
        If dest.Cells(r, DS_TARGET).Value = "作成" Then d(dest.Cells(r, DS_KEY).Value) = dest.Cells(r, DS_ID).Value
    Next r
    Dim countByDate As Object
    Set countByDate = CreateObject("Scripting.Dictionary")
    lr = LastRow(cand, VC_ID)
    For r = 2 To lr
        If cand.Cells(r, VC_TARGET).Value = "要" Then
            key = cand.Cells(r, VC_DEST_KEY).Value
            If d.Exists(key) And IsDate(cand.Cells(r, VC_TX_DATE).Value) Then
                countByDate(key & "|" & CLng(CDate(cand.Cells(r, VC_TX_DATE).Value))) = NzDbl(countByDate(key & "|" & CLng(CDate(cand.Cells(r, VC_TX_DATE).Value)))) + 1
            End If
        End If
    Next r
    outR = 2
    For r = 2 To lr
        If cand.Cells(r, VC_TARGET).Value = "要" Then
            key = cand.Cells(r, VC_DEST_KEY).Value
            If d.Exists(key) Then
                out.Cells(outR, CD_DEST_ID).Value = d(key)
                out.Cells(outR, CD_DEST_KEY).Value = key
                out.Cells(outR, CD_BANK).Value = cand.Cells(r, VC_BANK).Value
                out.Cells(outR, CD_SHOP).Value = cand.Cells(r, VC_SHOP).Value
                out.Cells(outR, CD_TX_DATE).Value = cand.Cells(r, VC_TX_DATE).Value
                If IsDate(cand.Cells(r, VC_TX_DATE).Value) Then out.Cells(outR, CD_DATE_COUNT).Value = countByDate(key & "|" & CLng(CDate(cand.Cells(r, VC_TX_DATE).Value)))
                out.Cells(outR, CD_ANALYSIS_ID).Value = cand.Cells(r, VC_ANALYSIS_ID).Value
                out.Cells(outR, CD_TX_ID).Value = cand.Cells(r, VC_TX_ID).Value
                out.Cells(outR, CD_KIND).Value = cand.Cells(r, VC_KIND).Value
                out.Cells(outR, CD_PERSON).Value = cand.Cells(r, VC_PERSON_NAME).Value
                out.Cells(outR, CD_RELATION).Value = cand.Cells(r, VC_RELATION).Value
                out.Cells(outR, CD_OUT).Value = cand.Cells(r, VC_OUT).Value
                out.Cells(outR, CD_IN).Value = cand.Cells(r, VC_IN).Value
                out.Cells(outR, CD_SUMMARY).Value = cand.Cells(r, VC_SUMMARY).Value
                out.Cells(outR, CD_MEMO).Value = cand.Cells(r, VC_MEMO).Value
                outR = outR + 1
            End If
        End If
    Next r
    If outR > 2 Then SortControlDetails out
End Sub

Private Sub SortControlDetails(ByVal sh As Worksheet)
    Dim lr As Long
    lr = LastRow(sh, CD_DEST_ID)
    With sh.Sort
        .SortFields.Clear
        .SortFields.Add Key:=sh.Range(sh.Cells(2, CD_DEST_ID), sh.Cells(lr, CD_DEST_ID)), Order:=xlAscending
        .SortFields.Add Key:=sh.Range(sh.Cells(2, CD_TX_DATE), sh.Cells(lr, CD_TX_DATE)), Order:=xlAscending
        .SetRange sh.Range(sh.Cells(1, 1), sh.Cells(lr, CD_COLS))
        .Header = xlYes
        .Apply
    End With
End Sub

Private Sub ClearRows(ByVal sh As Worksheet)
    Dim lr As Long
    lr = LastRow(sh, 1)
    If lr >= 2 Then sh.Range(sh.Rows(2), sh.Rows(lr)).ClearContents
End Sub

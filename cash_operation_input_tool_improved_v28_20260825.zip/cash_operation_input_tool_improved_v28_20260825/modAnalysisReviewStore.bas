Attribute VB_Name = "modAnalysisReviewStore"
Option Explicit

'�������\�͕��͏����ɂ��s���̂�������B���f�䒠�����\����Ɨ������A
'��₪�ꎞ�I�ɏ����Ă��m�F�󋵁E�����E�����̍���������Ȃ��悤�ɂ���B

Public Function AnalysisReviewStoreHeaders() As Variant
    AnalysisReviewStoreHeaders = Array( _
        "���L�[", "���\", "�敪", "�m�F��", "�m�F����", "��������", _
        "�\�����ID", "�X�V����", "���s���", "�O��m�F��", "�O�񍪋�����", _
        "�ύX���R", "�m�F��")
End Function

Public Function AnalysisReviewHistoryHeaders() As Variant
    AnalysisReviewHistoryHeaders = Array( _
        "����ID", "���L�[", "�ύX����", "�m�F��", "���\", "�敪", _
        "���m�F��", "�V�m�F��", "���m�F����", "�V�m�F����", _
        "����������", "�V��������", "�ύX���R")
End Function

Public Sub SetupAnalysisReviewStores(Optional ByVal resetContents As Boolean = False)
    PrepareAnalysisReviewStoreSheet GetOrCreateSheet(SH_WORK_ANALYSIS_REVIEW, False), _
                                    resetContents, AnalysisReviewStoreHeaders(), _
                                    ANALYSIS_REVIEW_STORE_LAST_COL
    PrepareAnalysisReviewStoreSheet GetOrCreateSheet(SH_WORK_ANALYSIS_HISTORY, False), _
                                    resetContents, AnalysisReviewHistoryHeaders(), _
                                    ANALYSIS_HISTORY_STORE_LAST_COL
End Sub

Private Sub PrepareAnalysisReviewStoreSheet(ByVal ws As Worksheet, ByVal resetContents As Boolean, _
                                            ByVal headers As Variant, ByVal lastColumn As Long)
    If ws Is Nothing Then Err.Raise vbObjectError + 4900, _
        "PrepareAnalysisReviewStoreSheet", "���͔��f�̓����ۑ��悪����܂���B"
    If resetContents Then ResetWorksheet ws
    If Len(CellText(ws.Cells(1, 1).Value)) = 0 Then
        SetRowValues ws.Range("A1"), headers
        FormatOutputHeader ws.Range(ws.Cells(1, 1), ws.Cells(1, lastColumn))
    End If
    ws.Columns("A:M").NumberFormat = "@"
    If StrComp(ws.Name, SH_WORK_ANALYSIS_HISTORY, vbTextCompare) = 0 Then
        ws.Columns("C:C").NumberFormat = "yyyy/m/d h:mm:ss"
    Else
        ws.Columns("H:H").NumberFormat = "yyyy/m/d h:mm:ss"
    End If
    SetSheetVeryHiddenSafe ws
End Sub

Public Function CapturePersistentAnalysisReviews() As Object
    Dim reviews As Object, ws As Worksheet
    Dim lastR As Long, data As Variant, r As Long
    Dim keyText As String, statusText As String, memoText As String
    Set reviews = CreateObject("Scripting.Dictionary")
    reviews.CompareMode = vbTextCompare
    If Not SheetExists(SH_WORK_ANALYSIS_REVIEW) Then
        Set CapturePersistentAnalysisReviews = reviews
        Exit Function
    End If
    Set ws = GetSheet(SH_WORK_ANALYSIS_REVIEW)
    lastR = LastUsedRowInSheet(ws)
    If lastR < 2 Then
        Set CapturePersistentAnalysisReviews = reviews
        Exit Function
    End If
    data = ws.Range(ws.Cells(2, 1), _
                    ws.Cells(lastR, ANALYSIS_REVIEW_STORE_LAST_COL)).Value2
    For r = 1 To UBound(data, 1)
        keyText = CellText(data(r, REVIEW_STORE_COL_KEY))
        statusText = CellText(data(r, REVIEW_STORE_COL_STATUS))
        If Len(statusText) = 0 Then statusText = ANALYSIS_STATUS_UNREVIEWED
        memoText = CellText(data(r, REVIEW_STORE_COL_MEMO))
        If Len(keyText) > 0 And _
           (statusText <> ANALYSIS_STATUS_UNREVIEWED Or Len(memoText) > 0) Then
            If reviews.Exists(keyText) Then _
                Err.Raise vbObjectError + 4901, "CapturePersistentAnalysisReviews", _
                          "���͔��f�䒠�̌��L�[���d�����Ă��܂�: " & keyText
            reviews.Add keyText, Array(statusText, memoText, _
                CellText(data(r, REVIEW_STORE_COL_EVIDENCE)))
        End If
    Next r
    Set CapturePersistentAnalysisReviews = reviews
End Function

Public Function MergeStoredAnalysisReviews(ByVal currentReviews As Object, _
                                           ByVal storedReviews As Object) As Object
    Dim result As Object, item As Variant
    Set result = CreateObject("Scripting.Dictionary")
    result.CompareMode = vbTextCompare
    If Not storedReviews Is Nothing Then
        For Each item In storedReviews.Keys
            result.Add CStr(item), storedReviews(item)
        Next item
    End If
    If Not currentReviews Is Nothing Then
        For Each item In currentReviews.Keys
            If result.Exists(CStr(item)) Then
                result(CStr(item)) = currentReviews(item)
            Else
                result.Add CStr(item), currentReviews(item)
            End If
        Next item
    End If
    Set MergeStoredAnalysisReviews = result
End Function

Public Sub PersistAnalysisReviewsFromCurrentSheets(ByVal markMissing As Boolean, _
                                                    Optional ByVal reasonText As String = "")
    Dim wsStore As Worksheet, indexByKey As Object, presentKeys As Object
    If Not SheetExists(SH_WORK_ANALYSIS_REVIEW) Or _
       Not SheetExists(SH_WORK_ANALYSIS_HISTORY) Then _
        Err.Raise vbObjectError + 4902, "PersistAnalysisReviewsFromCurrentSheets", _
                  "���͔��f�䒠������܂���B�ăZ�b�g�A�b�v���Ă��������B"
    Set wsStore = GetSheet(SH_WORK_ANALYSIS_REVIEW)
    Set indexByKey = BuildAnalysisReviewStoreIndex(wsStore)
    Set presentKeys = CreateObject("Scripting.Dictionary")
    presentKeys.CompareMode = vbTextCompare

    PersistOneAnalysisReviewSheet GetSheet(SH_ANALYSIS_SHIFT), SHIFT_ANALYSIS_STATUS_COL, _
        SHIFT_ANALYSIS_MEMO_COL, SHIFT_ANALYSIS_KEY_COL, SH_ANALYSIS_SHIFT, _
        "�����V�t�g", 33, 34, indexByKey, presentKeys, reasonText
    PersistOneAnalysisReviewSheet GetSheet(SH_ANALYSIS_FLOW), FLOW_ANALYSIS_STATUS_COL, _
        FLOW_ANALYSIS_MEMO_COL, FLOW_ANALYSIS_KEY_COL, SH_ANALYSIS_FLOW, _
        "�����t���[", 20, 0, indexByKey, presentKeys, reasonText
    PersistOneAnalysisReviewSheet GetSheet(SH_ANALYSIS_UNKNOWN), UNKNOWN_ANALYSIS_STATUS_COL, _
        UNKNOWN_ANALYSIS_MEMO_COL, UNKNOWN_ANALYSIS_KEY_COL, SH_ANALYSIS_UNKNOWN, _
        "", 24, 0, indexByKey, presentKeys, reasonText
    If markMissing Then MarkMissingAnalysisReviewRows wsStore, presentKeys, reasonText
    SetSheetVeryHiddenSafe wsStore
    SetSheetVeryHiddenSafe GetSheet(SH_WORK_ANALYSIS_HISTORY)
End Sub

Private Function BuildAnalysisReviewStoreIndex(ByVal ws As Worksheet) As Object
    Dim result As Object, lastR As Long, values As Variant, r As Long, keyText As String
    Set result = CreateObject("Scripting.Dictionary")
    result.CompareMode = vbTextCompare
    lastR = LastUsedRowInSheet(ws)
    If lastR >= 2 Then
        values = ws.Range(ws.Cells(2, REVIEW_STORE_COL_KEY), _
                          ws.Cells(lastR, REVIEW_STORE_COL_KEY)).Value2
        For r = 1 To lastR - 1
            keyText = ReviewStoreColumnValue(values, r, lastR - 1)
            If Len(keyText) > 0 Then
                If result.Exists(keyText) Then _
                    Err.Raise vbObjectError + 4903, "BuildAnalysisReviewStoreIndex", _
                              "���͔��f�䒠�̌��L�[���d�����Ă��܂�: " & keyText
                result.Add keyText, r + 1
            End If
        Next r
    End If
    Set BuildAnalysisReviewStoreIndex = result
End Function

Private Sub PersistOneAnalysisReviewSheet( _
        ByVal ws As Worksheet, ByVal statusColumn As Long, ByVal memoColumn As Long, _
        ByVal keyColumn As Long, ByVal sourceName As String, ByVal fixedCategory As String, _
        ByVal firstTxColumn As Long, ByVal secondTxColumn As Long, _
        ByVal indexByKey As Object, ByVal presentKeys As Object, ByVal reasonText As String)
    Dim lastR As Long, data As Variant, r As Long
    Dim storedKey As String, baseKey As String, evidenceText As String
    Dim statusText As String, memoText As String, categoryText As String, txIDs As String
    If ws Is Nothing Then Exit Sub
    lastR = LastUsedRowInSheet(ws)
    If lastR < 2 Then Exit Sub
    data = ws.Range(ws.Cells(2, 1), ws.Cells(lastR, _
                    Application.Max(keyColumn, firstTxColumn, secondTxColumn))).Value2
    For r = 1 To UBound(data, 1)
        storedKey = CellText(data(r, keyColumn))
        If Len(storedKey) > 0 Then
            baseKey = AnalysisBaseKey(storedKey, evidenceText)
            If Len(baseKey) = 0 Then _
                Err.Raise vbObjectError + 4904, "PersistOneAnalysisReviewSheet", _
                          sourceName & " " & CStr(r + 1) & "�s�ڂ̌��L�[���s���ł��B"
            presentKeys(baseKey) = True
            statusText = CellText(data(r, statusColumn))
            If Len(statusText) = 0 Then statusText = ANALYSIS_STATUS_UNREVIEWED
            memoText = CellText(data(r, memoColumn))
            categoryText = fixedCategory
            If Len(categoryText) = 0 Then categoryText = Replace(CellText(data(r, 3)), "���", "")
            txIDs = CellText(data(r, firstTxColumn))
            If secondTxColumn > 0 Then txIDs = JoinAnalysisReviewIDs(txIDs, _
                                                   CellText(data(r, secondTxColumn)))
            If statusText <> ANALYSIS_STATUS_UNREVIEWED Or Len(memoText) > 0 Or _
               indexByKey.Exists(baseKey) Then
                UpsertAnalysisReviewStore baseKey, sourceName, categoryText, statusText, memoText, _
                    evidenceText, txIDs, "���s", reasonText, indexByKey
            End If
        End If
    Next r
End Sub

Private Sub UpsertAnalysisReviewStore( _
        ByVal baseKey As String, ByVal sourceName As String, ByVal categoryText As String, _
        ByVal statusText As String, ByVal memoText As String, ByVal evidenceText As String, _
        ByVal txIDs As String, ByVal presenceText As String, ByVal reasonText As String, _
        ByVal indexByKey As Object)
    Dim ws As Worksheet, rowNo As Long
    Dim oldStatus As String, oldMemo As String, oldEvidence As String, oldPresence As String
    Dim changed As Boolean, effectiveReason As String
    Set ws = GetSheet(SH_WORK_ANALYSIS_REVIEW)
    If indexByKey.Exists(baseKey) Then
        rowNo = CLng(indexByKey(baseKey))
        oldStatus = CellText(ws.Cells(rowNo, REVIEW_STORE_COL_STATUS).Value)
        oldMemo = CellText(ws.Cells(rowNo, REVIEW_STORE_COL_MEMO).Value)
        oldEvidence = CellText(ws.Cells(rowNo, REVIEW_STORE_COL_EVIDENCE).Value)
        oldPresence = CellText(ws.Cells(rowNo, REVIEW_STORE_COL_PRESENCE).Value)
    Else
        rowNo = LastUsedRowInSheet(ws) + 1
        If rowNo < 2 Then rowNo = 2
        indexByKey.Add baseKey, rowNo
    End If
    changed = (StrComp(oldStatus, statusText, vbBinaryCompare) <> 0 Or _
               StrComp(oldMemo, memoText, vbBinaryCompare) <> 0 Or _
               StrComp(oldEvidence, evidenceText, vbBinaryCompare) <> 0 Or _
               StrComp(oldPresence, presenceText, vbBinaryCompare) <> 0)
    If Not changed And _
       StrComp(CellText(ws.Cells(rowNo, REVIEW_STORE_COL_SOURCE).Value), _
               sourceName, vbBinaryCompare) = 0 And _
       StrComp(CellText(ws.Cells(rowNo, REVIEW_STORE_COL_TX_IDS).Value), _
               txIDs, vbBinaryCompare) = 0 Then Exit Sub

    effectiveReason = reasonText
    If Len(effectiveReason) = 0 Then
        If Len(oldEvidence) > 0 And StrComp(oldEvidence, evidenceText, vbBinaryCompare) <> 0 Then
            effectiveReason = "�����܂��͕��͏����̕ύX"
        ElseIf oldPresence = "����" And presenceText = "���s" Then
            effectiveReason = "��₪�ďo��"
        ElseIf Len(oldStatus) = 0 Then
            effectiveReason = "���f�䒠�֓o�^"
        Else
            effectiveReason = "�m�F���e���X�V"
        End If
    End If
    If changed Then AppendAnalysisReviewHistory baseKey, sourceName, categoryText, _
        oldStatus, statusText, oldMemo, memoText, oldEvidence, evidenceText, effectiveReason

    ws.Cells(rowNo, REVIEW_STORE_COL_KEY).Value = baseKey
    ws.Cells(rowNo, REVIEW_STORE_COL_SOURCE).Value = sourceName
    ws.Cells(rowNo, REVIEW_STORE_COL_CATEGORY).Value = categoryText
    ws.Cells(rowNo, REVIEW_STORE_COL_STATUS).Value = statusText
    ws.Cells(rowNo, REVIEW_STORE_COL_MEMO).Value = memoText
    ws.Cells(rowNo, REVIEW_STORE_COL_EVIDENCE).Value = evidenceText
    ws.Cells(rowNo, REVIEW_STORE_COL_TX_IDS).Value = txIDs
    ws.Cells(rowNo, REVIEW_STORE_COL_UPDATED_AT).Value = Now
    ws.Cells(rowNo, REVIEW_STORE_COL_PRESENCE).Value = presenceText
    ws.Cells(rowNo, REVIEW_STORE_COL_PREVIOUS_STATUS).Value = oldStatus
    ws.Cells(rowNo, REVIEW_STORE_COL_PREVIOUS_EVIDENCE).Value = oldEvidence
    ws.Cells(rowNo, REVIEW_STORE_COL_REASON).Value = effectiveReason
    ws.Cells(rowNo, REVIEW_STORE_COL_USER).Value = AnalysisReviewUserName()
End Sub

Private Sub MarkMissingAnalysisReviewRows(ByVal ws As Worksheet, ByVal presentKeys As Object, _
                                          ByVal reasonText As String)
    Dim lastR As Long, r As Long, keyText As String, oldPresence As String
    Dim effectiveReason As String
    lastR = LastUsedRowInSheet(ws)
    If lastR < 2 Then Exit Sub
    effectiveReason = reasonText
    If Len(effectiveReason) = 0 Then effectiveReason = "���ݏ����ł͌��Ȃ�"
    For r = 2 To lastR
        keyText = CellText(ws.Cells(r, REVIEW_STORE_COL_KEY).Value)
        If Len(keyText) > 0 And Not presentKeys.Exists(keyText) Then
            oldPresence = CellText(ws.Cells(r, REVIEW_STORE_COL_PRESENCE).Value)
            If oldPresence <> "����" Then
                AppendAnalysisReviewHistory keyText, _
                    CellText(ws.Cells(r, REVIEW_STORE_COL_SOURCE).Value), _
                    CellText(ws.Cells(r, REVIEW_STORE_COL_CATEGORY).Value), _
                    CellText(ws.Cells(r, REVIEW_STORE_COL_STATUS).Value), _
                    CellText(ws.Cells(r, REVIEW_STORE_COL_STATUS).Value), _
                    CellText(ws.Cells(r, REVIEW_STORE_COL_MEMO).Value), _
                    CellText(ws.Cells(r, REVIEW_STORE_COL_MEMO).Value), _
                    CellText(ws.Cells(r, REVIEW_STORE_COL_EVIDENCE).Value), _
                    CellText(ws.Cells(r, REVIEW_STORE_COL_EVIDENCE).Value), effectiveReason
                ws.Cells(r, REVIEW_STORE_COL_UPDATED_AT).Value = Now
                ws.Cells(r, REVIEW_STORE_COL_PRESENCE).Value = "����"
                ws.Cells(r, REVIEW_STORE_COL_REASON).Value = effectiveReason
                ws.Cells(r, REVIEW_STORE_COL_USER).Value = AnalysisReviewUserName()
            End If
        End If
    Next r
End Sub

Private Sub AppendAnalysisReviewHistory( _
        ByVal baseKey As String, ByVal sourceName As String, ByVal categoryText As String, _
        ByVal oldStatus As String, ByVal newStatus As String, ByVal oldMemo As String, _
        ByVal newMemo As String, ByVal oldEvidence As String, ByVal newEvidence As String, _
        ByVal reasonText As String)
    Dim ws As Worksheet, rowNo As Long, historyID As String
    Set ws = GetSheet(SH_WORK_ANALYSIS_HISTORY)
    rowNo = LastUsedRowInSheet(ws) + 1
    If rowNo < 2 Then rowNo = 2
    If rowNo - 1 > MAX_INTERNAL_STORE_DATA_ROWS Then _
        Err.Raise vbObjectError + 4905, "AppendAnalysisReviewHistory", _
                  "���͔��f�������ۑ�����𒴂��܂����B�Č��t�@�C���𕪂��Ă��������B"
    historyID = "RH-" & Format$(Now, "yyyymmddhhnnss") & "-" & Format$(rowNo - 1, "000000")
    ws.Cells(rowNo, 1).Value = historyID
    ws.Cells(rowNo, 2).Value = baseKey
    ws.Cells(rowNo, 3).Value = Now
    ws.Cells(rowNo, 4).Value = AnalysisReviewUserName()
    ws.Cells(rowNo, 5).Value = sourceName
    ws.Cells(rowNo, 6).Value = categoryText
    ws.Cells(rowNo, 7).Value = oldStatus
    ws.Cells(rowNo, 8).Value = newStatus
    ws.Cells(rowNo, 9).Value = oldMemo
    ws.Cells(rowNo, 10).Value = newMemo
    ws.Cells(rowNo, 11).Value = oldEvidence
    ws.Cells(rowNo, 12).Value = newEvidence
    ws.Cells(rowNo, 13).Value = reasonText
End Sub

Private Function AnalysisReviewUserName() As String
    On Error Resume Next
    AnalysisReviewUserName = Trim$(Application.UserName)
    If Len(AnalysisReviewUserName) = 0 Then AnalysisReviewUserName = Trim$(Environ$("Username"))
    If Len(AnalysisReviewUserName) = 0 Then AnalysisReviewUserName = "�m�F�Җ��ݒ�"
    On Error GoTo 0
End Function

Private Function JoinAnalysisReviewIDs(ByVal firstID As String, ByVal secondID As String) As String
    If Len(firstID) = 0 Then
        JoinAnalysisReviewIDs = secondID
    ElseIf Len(secondID) = 0 Or StrComp(firstID, secondID, vbTextCompare) = 0 Then
        JoinAnalysisReviewIDs = firstID
    Else
        JoinAnalysisReviewIDs = firstID & ";" & secondID
    End If
End Function

Private Function ReviewStoreColumnValue(ByVal values As Variant, ByVal itemIndex As Long, _
                                        ByVal itemCount As Long) As String
    If itemCount = 1 Then
        ReviewStoreColumnValue = CellText(values)
    Else
        ReviewStoreColumnValue = CellText(values(itemIndex, 1))
    End If
End Function

Public Sub CheckAnalysisReviewStores(ByRef problems As String, _
                                     ByRef interfaceWarnings As String, _
                                     ByVal includeInterfaceChecks As Boolean)
    Dim ws As Worksheet, lastR As Long, data As Variant, r As Long
    Dim seen As Object, keyText As String, statusText As String, presenceText As String
    Dim sourceText As String, categoryText As String, evidenceText As String
    Dim wsHistory As Worksheet, historyData As Variant, historyID As String
    If Not SheetExists(SH_WORK_ANALYSIS_REVIEW) Or _
       Not SheetExists(SH_WORK_ANALYSIS_HISTORY) Then
        problems = problems & "�E���͔��f�䒠�܂��͗���������܂���" & vbCrLf
        Exit Sub
    End If
    Set ws = GetSheet(SH_WORK_ANALYSIS_REVIEW)
    Set seen = CreateObject("Scripting.Dictionary")
    seen.CompareMode = vbTextCompare
    lastR = LastUsedRowInSheet(ws)
    If lastR - 1 > MAX_INTERNAL_STORE_DATA_ROWS Then _
        problems = problems & "�E���͔��f�䒠���ۑ�����𒴂��Ă��܂�" & vbCrLf
    If lastR >= 2 Then
        data = ws.Range(ws.Cells(2, 1), _
                        ws.Cells(lastR, ANALYSIS_REVIEW_STORE_LAST_COL)).Value2
        For r = 1 To UBound(data, 1)
            keyText = CellText(data(r, REVIEW_STORE_COL_KEY))
            sourceText = CellText(data(r, REVIEW_STORE_COL_SOURCE))
            categoryText = CellText(data(r, REVIEW_STORE_COL_CATEGORY))
            statusText = CellText(data(r, REVIEW_STORE_COL_STATUS))
            evidenceText = CellText(data(r, REVIEW_STORE_COL_EVIDENCE))
            presenceText = CellText(data(r, REVIEW_STORE_COL_PRESENCE))
            If Len(keyText) = 0 Then
                problems = problems & "�E���͔��f�䒠 " & CStr(r + 1) & "�s: ���L�[�Ȃ�" & vbCrLf
            ElseIf seen.Exists(keyText) Then
                problems = problems & "�E���͔��f�䒠: ���L�[�d�� " & keyText & vbCrLf
            Else
                seen.Add keyText, True
            End If
            If InStr(1, keyText, ANALYSIS_EVIDENCE_MARKER, vbBinaryCompare) > 0 Then _
                problems = problems & "�E���͔��f�䒠 " & CStr(r + 1) & "�s: ���L�[�ɍ�������������" & vbCrLf
            If Not ReviewStoreStatusFits(sourceText, categoryText, statusText) Then _
                problems = problems & "�E���͔��f�䒠 " & CStr(r + 1) & "�s: ���\�E�敪�Ɗm�F�󋵂��s�K��" & vbCrLf
            If presenceText <> "���s" And presenceText <> "����" Then _
                problems = problems & "�E���͔��f�䒠 " & CStr(r + 1) & "�s: ���s��ԕs��" & vbCrLf
            If Len(CellText(data(r, REVIEW_STORE_COL_MEMO))) > ANALYSIS_REVIEW_MEMO_MAX Then _
                problems = problems & "�E���͔��f�䒠 " & CStr(r + 1) & "�s: �m�F�������������܂�" & vbCrLf
            If Len(evidenceText) = 0 Then
                If presenceText = "���s" Then _
                    problems = problems & "�E���͔��f�䒠 " & CStr(r + 1) & "�s: ���s���̍��������Ȃ�" & vbCrLf
            ElseIf Not ReviewEvidenceDigestIsValid(evidenceText) Then
                problems = problems & "�E���͔��f�䒠 " & CStr(r + 1) & "�s: ���������s��" & vbCrLf
            End If
            If Len(CellText(data(r, REVIEW_STORE_COL_TX_IDS))) = 0 Then _
                problems = problems & "�E���͔��f�䒠 " & CStr(r + 1) & "�s: �\�����ID�Ȃ�" & vbCrLf
            If Not IsDate(data(r, REVIEW_STORE_COL_UPDATED_AT)) Then _
                problems = problems & "�E���͔��f�䒠 " & CStr(r + 1) & "�s: �X�V�����s��" & vbCrLf
            If Len(CellText(data(r, REVIEW_STORE_COL_REASON))) = 0 Or _
               Len(CellText(data(r, REVIEW_STORE_COL_USER))) = 0 Then _
                problems = problems & "�E���͔��f�䒠 " & CStr(r + 1) & "�s: �ύX���R�܂��͊m�F�҂Ȃ�" & vbCrLf
            If Len(problems) > 700000 Then Exit For
        Next r
    End If
    If includeInterfaceChecks Then
        If ws.Visible <> xlSheetVeryHidden Then _
            interfaceWarnings = interfaceWarnings & "�E���͔��f�䒠��VeryHidden�ł͂���܂���" & vbCrLf
    End If
    Set wsHistory = GetSheet(SH_WORK_ANALYSIS_HISTORY)
    lastR = LastUsedRowInSheet(wsHistory)
    If lastR - 1 > MAX_INTERNAL_STORE_DATA_ROWS Then _
        problems = problems & "�E���͔��f�������ۑ�����𒴂��Ă��܂�" & vbCrLf
    Set seen = CreateObject("Scripting.Dictionary")
    seen.CompareMode = vbTextCompare
    If lastR >= 2 Then
        historyData = wsHistory.Range(wsHistory.Cells(2, 1), _
                        wsHistory.Cells(lastR, ANALYSIS_HISTORY_STORE_LAST_COL)).Value2
        For r = 1 To UBound(historyData, 1)
            historyID = CellText(historyData(r, 1))
            keyText = CellText(historyData(r, 2))
            sourceText = CellText(historyData(r, 5))
            categoryText = CellText(historyData(r, 6))
            statusText = CellText(historyData(r, 8))
            If Len(historyID) = 0 Or seen.Exists(historyID) Then
                problems = problems & "�E���͔��f���� " & CStr(r + 1) & "�s: ����ID�s���܂��͏d��" & vbCrLf
            Else
                seen.Add historyID, True
            End If
            If Len(keyText) = 0 Or Not IsDate(historyData(r, 3)) Or _
               Len(CellText(historyData(r, 4))) = 0 Or _
               Len(CellText(historyData(r, 13))) = 0 Then _
                problems = problems & "�E���͔��f���� " & CStr(r + 1) & "�s: �K�{���s��" & vbCrLf
            If Not ReviewStoreStatusFits(sourceText, categoryText, statusText) Then _
                problems = problems & "�E���͔��f���� " & CStr(r + 1) & "�s: �V�m�F�󋵕s��" & vbCrLf
            If Len(CellText(historyData(r, 7))) > 0 And _
               Not IsAnalysisReviewStatus(CellText(historyData(r, 7))) Then _
                problems = problems & "�E���͔��f���� " & CStr(r + 1) & "�s: ���m�F�󋵕s��" & vbCrLf
            If Len(CellText(historyData(r, 11))) > 0 And _
               Not ReviewEvidenceDigestIsValid(CellText(historyData(r, 11))) Then _
                problems = problems & "�E���͔��f���� " & CStr(r + 1) & "�s: �����������s��" & vbCrLf
            If Len(CellText(historyData(r, 12))) > 0 And _
               Not ReviewEvidenceDigestIsValid(CellText(historyData(r, 12))) Then _
                problems = problems & "�E���͔��f���� " & CStr(r + 1) & "�s: �V���������s��" & vbCrLf
            If Len(problems) > 700000 Then Exit For
        Next r
    End If
    If includeInterfaceChecks Then
        If wsHistory.Visible <> xlSheetVeryHidden Then _
            interfaceWarnings = interfaceWarnings & "�E���͔��f������VeryHidden�ł͂���܂���" & vbCrLf
    End If
End Sub

Private Function ReviewStoreStatusFits(ByVal sourceText As String, ByVal categoryText As String, _
                                       ByVal statusText As String) As Boolean
    Select Case sourceText
        Case SH_ANALYSIS_SHIFT, SH_ANALYSIS_FLOW
            Select Case statusText
                Case ANALYSIS_STATUS_UNREVIEWED, ANALYSIS_STATUS_SHIFT_CONFIRMED, _
                     ANALYSIS_STATUS_EXCLUDED, ANALYSIS_STATUS_FOLLOWUP
                    ReviewStoreStatusFits = True
            End Select
        Case SH_ANALYSIS_UNKNOWN
            If StrComp(categoryText, "�����s��", vbTextCompare) = 0 Then
                Select Case statusText
                    Case ANALYSIS_STATUS_UNREVIEWED, ANALYSIS_STATUS_SOURCE_CONFIRMED, _
                         ANALYSIS_STATUS_EXCLUDED, ANALYSIS_STATUS_FOLLOWUP
                        ReviewStoreStatusFits = True
                End Select
            ElseIf StrComp(categoryText, "�g�r�s��", vbTextCompare) = 0 Then
                Select Case statusText
                    Case ANALYSIS_STATUS_UNREVIEWED, ANALYSIS_STATUS_USE_CONFIRMED, _
                         ANALYSIS_STATUS_EXCLUDED, ANALYSIS_STATUS_FOLLOWUP
                        ReviewStoreStatusFits = True
                End Select
            End If
    End Select
End Function

Private Function ReviewEvidenceDigestIsValid(ByVal digestText As String) As Boolean
    Dim i As Long, characterText As String
    If Len(digestText) <> 17 Or Mid$(digestText, 9, 1) <> "-" Then Exit Function
    For i = 1 To Len(digestText)
        If i <> 9 Then
            characterText = UCase$(Mid$(digestText, i, 1))
            If InStr(1, "0123456789ABCDEF", characterText, vbBinaryCompare) = 0 Then Exit Function
        End If
    Next i
    ReviewEvidenceDigestIsValid = True
End Function

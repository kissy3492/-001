統合資金操作表プレビュー

01_cash_transfer.png
  資金移動候補と元取引を同じ資金操作表で確認する画面です。

02_unknown_withdrawal.png
  不明出金候補を表示します。出金と入金は別列のままです。

03_unknown_deposit.png
  不明入金候補を表示します。出金と入金は別列のままです。

04_manual_selection.png
  元取引を選択して手動候補を作成する画面です。

05_long_text_expanded.png
  分析理由・反証・確認メモを同じ画面で展開した状態です。

06_long_summary.png
  長い摘要を折り返した状態です。

integrated_cash_analysis_preview_v26.xlsx
  上記6状態をシートで確認できる参照用Excelです。

このプレビューはV26時点の画面参照です。V27では入力画面の列幅・行高・動的ズームを変更しているため、最終表示はWindows版Excelで生成したブックを確認してください。資金操作表の統合分析画面、出金H列・入金I列、不明出金・不明入金の独立表示は変更していません。

画像とxlsxは画面設計の参照用であり、Windows版Excel/VBAの実機動作証明ではありません。

Attribute VB_Name = "modCashAnalysisView"
Option Explicit

'��������\�ƕ��͌��ʂ𓯂���ʂɒu�����߂̗��p�Ҍ����r���[�B
'A:M�͏�ɒ�o�p�Ɠ����񏇂����A�o��(H)�Ɠ���(I)���΂ɍ��݂����Ȃ��B
'N:Z�͈���ID�A�i�荞�݁A�蓮�I���A��ʏ�Ԃ̂��߂̔�\����ł���B

Private Const VIEW_CATEGORY_TRANSFER As String = "�����ړ�"
Private Const VIEW_CATEGORY_UNKNOWN_WITHDRAW As String = "�s���o��"
Private Const VIEW_CATEGORY_UNKNOWN_DEPOSIT As String = "�s������"

Private Const VIEW_MODE_COMPONENT As String = "�\�����"
Private Const VIEW_MODE_RELATED As String = "�֘A���"
Private Const VIEW_MODE_ALL As String = "�S���"

Private Const VIEW_ROLE_WITHDRAW As String = "�o��"
Private Const VIEW_ROLE_DEPOSIT As String = "����"
Private Const VIEW_ROLE_BOTH As String = "�o���E����"

Private Const VIEW_STATE_CATEGORY As String = "V1"
Private Const VIEW_STATE_GROUP_ID As String = "V2"
Private Const VIEW_STATE_RESULT_ROW As String = "V3"
Private Const VIEW_STATE_MODE As String = "V4"
Private Const VIEW_STATE_MANUAL As String = "V5"
Private Const VIEW_STATE_SELECTED_IDS As String = "V6"
Private Const VIEW_STATE_VERSION As String = "V7"
Private Const VIEW_STATE_PANEL_EXPANDED As String = "V8"
Private Const VIEW_VERSION As String = "5"
Private Const VIEW_MEMO_MAX As Long = 1000
Private Const VIEW_SELECTED_IDS_MAX As Long = 32000

Public Sub SetupCashAnalysisViewSheet(ByVal ws As Worksheet)
    Dim emptyCounts(1 To 3) As Long
    If ws Is Nothing Then Exit Sub
    ws.Unprotect Password:=TOOL_PASSWORD
    ResetWorksheet ws
    BuildCashAnalysisViewStructure ws
    SetRowValues ws.Cells(CASH_VIEW_HEADER_ROW, 1), CashAnalysisViewHeaders()
    FormatOutputHeader ws.Range(ws.Cells(CASH_VIEW_HEADER_ROW, 1), _
                                    ws.Cells(CASH_VIEW_HEADER_ROW, CASH_VIEW_LAST_COL))
    ws.Range(VIEW_STATE_CATEGORY).Value = VIEW_CATEGORY_TRANSFER
    ws.Range(VIEW_STATE_MODE).Value = VIEW_MODE_COMPONENT
    ws.Range(VIEW_STATE_MANUAL).Value = "0"
    ws.Range(VIEW_STATE_PANEL_EXPANDED).Value = "0"
    ws.Range(VIEW_STATE_VERSION).Value = VIEW_VERSION
    FormatCashAnalysisViewLayout ws
    UpdateCategoryButtonCaptions ws, VIEW_CATEGORY_TRANSFER, emptyCounts
    ClearCashAnalysisCandidatePanel ws, VIEW_CATEGORY_TRANSFER, emptyCounts, 0, 0
    ProtectCashAnalysisViewSheet
End Sub

Public Function CashAnalysisViewHeaders() As Variant
    CashAnalysisViewHeaders = Array( _
        "��s��", "�x�X��", "����", "�Ȗ�", "�����ԍ�", "���t", "����", _
        "�o��", "����", "�戵�X", "�@��", "�E�v��", "�c��", _
        "����ID", "���ID", "�s���", "���͏�", _
        "�\���Ώ�", "��������", "�蓮�I��")
End Function

Public Sub BuildCashAnalysisViewCore(ByVal activateAfter As Boolean)
    Dim ws As Worksheet, wsSource As Worksheet
    Dim sourceLastRow As Long, outputLastRow As Long
    Dim keepCategory As String, keepGroupID As String, keepMode As String
    Dim keepManual As String, keepSelected As String
    Dim workbookWasSaved As Boolean
    Dim errorNumber As Long, errorDescription As String

    On Error GoTo EH
    If Not SheetExists(SH_OUTPUT_TX) Or Not SheetExists(SH_WORK_CASH) Then Exit Sub
    Set ws = GetSheet(SH_OUTPUT_TX)
    Set wsSource = GetSheet(SH_WORK_CASH)
    SyncCashAnalysisPanelReviewToWorkspace
    workbookWasSaved = ThisWorkbook.Saved

    If Len(CellText(ws.Range(VIEW_STATE_VERSION).Value)) > 0 Then
        keepCategory = CellText(ws.Range(VIEW_STATE_CATEGORY).Value)
        keepGroupID = CellText(ws.Range(VIEW_STATE_GROUP_ID).Value)
        keepMode = CellText(ws.Range(VIEW_STATE_MODE).Value)
        keepManual = CellText(ws.Range(VIEW_STATE_MANUAL).Value)
        keepSelected = CellText(ws.Range(VIEW_STATE_SELECTED_IDS).Value)
    End If
    If Not IsCashViewCategory(keepCategory) Then keepCategory = VIEW_CATEGORY_TRANSFER
    If Not IsCashViewMode(keepMode) Then keepMode = VIEW_MODE_COMPONENT
    If keepManual <> "1" Then keepManual = "0"

    ws.Unprotect Password:=TOOL_PASSWORD
    ResetWorksheet ws
    BuildCashAnalysisViewStructure ws
    SetRowValues ws.Cells(CASH_VIEW_HEADER_ROW, 1), CashAnalysisViewHeaders()

    sourceLastRow = LastUsedRowInSheet(wsSource)
    If sourceLastRow >= 2 Then
        outputLastRow = CASH_VIEW_FIRST_DATA_ROW + sourceLastRow - 2
        ws.Range(ws.Cells(CASH_VIEW_FIRST_DATA_ROW, 1), _
                 ws.Cells(outputLastRow, OUT_INTERNAL_LAST_COL)).Value = _
            wsSource.Range(wsSource.Cells(2, 1), _
                           wsSource.Cells(sourceLastRow, OUT_INTERNAL_LAST_COL)).Value
    End If

    ws.Range(VIEW_STATE_CATEGORY).Value = keepCategory
    ws.Range(VIEW_STATE_GROUP_ID).Value = keepGroupID
    ws.Range(VIEW_STATE_MODE).Value = keepMode
    ws.Range(VIEW_STATE_MANUAL).Value = keepManual
    ws.Range(VIEW_STATE_SELECTED_IDS).Value = keepSelected
    ws.Range(VIEW_STATE_PANEL_EXPANDED).Value = "0"
    ws.Range(VIEW_STATE_VERSION).Value = VIEW_VERSION
    FormatCashAnalysisViewLayout ws
    RefreshCashAnalysisPanel False
    ProtectCashAnalysisViewSheet
    SetSheetVeryHiddenSafe wsSource
    If SheetExists(SH_ANALYSIS_RESULT) Then SetSheetVeryHiddenSafe GetSheet(SH_ANALYSIS_RESULT)
    If SheetExists(SH_ANALYSIS_DETAIL) Then SetSheetVeryHiddenSafe GetSheet(SH_ANALYSIS_DETAIL)

    If activateAfter Then ApplyCashAnalysisViewWindowStyle True
    If workbookWasSaved Then ThisWorkbook.Saved = True
    Exit Sub
EH:
    errorNumber = Err.Number: errorDescription = Err.Description
    On Error Resume Next
    If Not ws Is Nothing Then ProtectCashAnalysisViewSheet
    If Not wsSource Is Nothing Then SetSheetVeryHiddenSafe wsSource
    On Error GoTo 0
    Err.Raise errorNumber, "BuildCashAnalysisViewCore", errorDescription
End Sub

Public Sub ApplyCashAnalysisViewWindowStyle(Optional ByVal selectTop As Boolean = True)
    '�쐬�o�H�ɂ�炸�A����\����A11�Œ�E88%�ɓ��ꂷ��B
    Dim ws As Worksheet
    If Not SheetExists(SH_OUTPUT_TX) Then Exit Sub
    Set ws = GetSheet(SH_OUTPUT_TX)
    ws.Visible = xlSheetVisible
    ws.Activate
    SafeFreezeSheetAt ws, "A" & CStr(CASH_VIEW_FIRST_DATA_ROW), 88
    ws.Activate
    If ActiveWindow Is Nothing Then _
        Err.Raise vbObjectError + 8006, "ApplyCashAnalysisViewWindowStyle", _
                  "��������\�̕\���E�B���h�E���擾�ł��܂���B"
    If Not ActiveWindow.FreezePanes Or ActiveWindow.SplitRow <> CASH_VIEW_HEADER_ROW Or _
       ActiveWindow.SplitColumn <> 0 Then _
        Err.Raise vbObjectError + 8007, "ApplyCashAnalysisViewWindowStyle", _
                  "��������\��A11�ŌŒ�ł��܂���B"
    If ActiveWindow.Zoom <> 88 Then _
        Err.Raise vbObjectError + 8008, "ApplyCashAnalysisViewWindowStyle", _
                  "��������\�̕\���{����88%�ɂł��܂���B"
    If selectTop Then
        SafeSelectCell ws, "A1"
    End If
End Sub

Private Sub BuildCashAnalysisViewStructure(ByVal ws As Worksheet)
    Dim rng As Range
    If ws Is Nothing Then Exit Sub
    ws.Unprotect Password:=TOOL_PASSWORD
    ws.Cells.Locked = True
    With ws.Range("A1:M8")
        .Font.Name = "Yu Gothic UI"
        .Font.Size = 10
        .VerticalAlignment = xlCenter
        .Borders.LineStyle = xlContinuous
        .Borders.Color = RGB(226, 232, 240)
        .Interior.Color = RGB(255, 255, 255)
    End With

    MergeViewCell ws.Range("A1:E1"), "��������\�b����ƕ��͂𓯎��m�F"
    With ws.Range("A1:E1")
        .Interior.Color = RGB(15, 23, 42)
        .Font.Color = RGB(255, 255, 255)
        .Font.Bold = True
        .Font.Size = 15
        .HorizontalAlignment = xlLeft
        .IndentLevel = 1
    End With
    MergeViewCell ws.Range("F1:M1"), "���͌����X�V����ƁA�����Ɍ����ƌ��݈ʒu���\������܂��B"
    With ws.Range("F1:M1")
        .Interior.Color = RGB(241, 245, 249)
        .Font.Color = RGB(51, 65, 85)
        .Font.Bold = True
        .HorizontalAlignment = xlLeft
        .IndentLevel = 1
    End With

    '�}�`�͉�ʐ�p�ň�����Ȃ����߁A������ɕK�v�Ȍ��݋敪�ƕ\���͈͂������Z���֎c���B
    MergeViewCell ws.Range("A2:C2"), "�����ړ�"
    MergeViewCell ws.Range("D2:F2"), "�s���o��"
    MergeViewCell ws.Range("G2:I2"), "�s������"
    MergeViewCell ws.Range("J2:K2"), ""
    MergeViewCell ws.Range("L2:M2"), ""
    MergeViewCell ws.Range("E3:F3"), ""
    MergeViewCell ws.Range("G3:H3"), "�\��: �\�����"
    MergeViewCell ws.Range("I3:J3"), ""
    MergeViewCell ws.Range("K3:M3"), ""
    StyleViewPrintControl ws.Range("A2:I2")
    StyleViewPrintControl ws.Range("G3:H3")

    MergeViewCell ws.Range("A3:B3"), "�m�F��"
    MergeViewCell ws.Range("C3:D3"), ANALYSIS_STATUS_UNREVIEWED
    StyleViewLabel ws.Range("A3:B3")
    StyleViewValue ws.Range("C3:D3")

    ws.Range("A4").Value = "�o�����v"
    MergeViewCell ws.Range("B4:D4"), "0"
    ws.Range("E4").Value = "�������v"
    MergeViewCell ws.Range("F4:H4"), "0"
    ws.Range("I4").Value = "���z�i���|�o�j"
    MergeViewCell ws.Range("J4:M4"), "0"
    StyleViewLabel ws.Range("A4")
    StyleViewLabel ws.Range("E4")
    StyleViewLabel ws.Range("I4")
    StyleViewMoney ws.Range("B4:D4"), RGB(254, 242, 242), RGB(185, 28, 28)
    StyleViewMoney ws.Range("F4:H4"), RGB(239, 246, 255), RGB(29, 78, 216)
    StyleViewMoney ws.Range("J4:M4"), RGB(248, 250, 252), RGB(15, 23, 42)

    MergeViewCell ws.Range("A5:B5"), "���t�E����"
    MergeViewCell ws.Range("C5:E5"), "�|"
    MergeViewCell ws.Range("F5:G5"), "�l���E�����o�H"
    MergeViewCell ws.Range("H5:M5"), "�|"
    StyleViewLabel ws.Range("A5:B5")
    StyleViewValue ws.Range("C5:E5")
    StyleViewLabel ws.Range("F5:G5")
    StyleViewValue ws.Range("H5:M5")

    MergeViewCell ws.Range("A6:B6"), "���o���R�E�v�_" & vbLf & "�m�_�u���N���b�N�œW�J�n"
    MergeViewCell ws.Range("C6:M6"), "����I������ƁA���o���R���\������܂��B"
    MergeViewCell ws.Range("A7:B7"), "���؁E����" & vbLf & "�m�_�u���N���b�N�œW�J�n"
    MergeViewCell ws.Range("C7:M7"), "��₪�������Ȃ��\���������Ŋm�F���܂��B"
    MergeViewCell ws.Range("A8:B8"), "�m�F����" & vbLf & "�m�_�u���N���b�N�œW�J�n"
    MergeViewCell ws.Range("C8:M8"), ""
    StyleViewLabel ws.Range("A6:B8")
    ws.Range("A6:B8").WrapText = True
    ws.Range("A6:B8").Font.Size = 9
    StyleViewValue ws.Range("C6:M8")
    ws.Range("C6:M8").WrapText = True
    ws.Range("C8:M8").Interior.Color = RGB(254, 249, 195)

    AddViewButton ws, ws.Range("A2:C2"), "�����ړ�", "ShowCashAnalysisTransfers", "primary"
    AddViewButton ws, ws.Range("D2:F2"), "�s���o��", "ShowCashAnalysisUnknownWithdrawals", "soft"
    AddViewButton ws, ws.Range("G2:I2"), "�s������", "ShowCashAnalysisUnknownDeposits", "soft"
    AddViewButton ws, ws.Range("J2:K2"), "�O�̌��", "PreviousCashAnalysisCandidate", "tool"
    AddViewButton ws, ws.Range("L2:M2"), "���̌��", "NextCashAnalysisCandidate", "tool"
    AddViewButton ws, ws.Range("E3:F3"), "�ĕ���", "BuildAllOutputSheets", "tool"
    AddViewButton ws, ws.Range("G3:H3"), "�\��: �\�����", "CycleCashAnalysisViewMode", "soft"
    AddViewButton ws, ws.Range("I3:J3"), "�蓮����I��", "CashAnalysisSecondaryAction", "tool"
    AddViewButton ws, ws.Range("K3:M3"), "�m�F�ς݂ɂ���", "CashAnalysisPrimaryAction", "primary"

    SetRowValues ws.Cells(CASH_VIEW_HEADER_ROW, 1), CashAnalysisViewHeaders()
    ws.Range("V1:Z12").NumberFormat = "@"
    ws.Columns("N:Z").Hidden = True
    Set rng = ws.Range("A9:M9")
    rng.Interior.Color = RGB(226, 232, 240)
    rng.Borders.LineStyle = xlNone
End Sub

Private Sub StyleViewPrintControl(ByVal target As Range)
    If target Is Nothing Then Exit Sub
    With target
        .Interior.Color = RGB(248, 250, 252)
        .Font.Color = RGB(51, 65, 85)
        .Font.Bold = True
        .HorizontalAlignment = xlCenter
        .VerticalAlignment = xlCenter
        .Borders.LineStyle = xlContinuous
        .Borders.Color = RGB(203, 213, 225)
    End With
End Sub

Private Sub MergeViewCell(ByVal target As Range, ByVal valueText As String)
    If target Is Nothing Then Exit Sub
    target.Merge
    target.Cells(1, 1).Value = valueText
End Sub

Private Sub StyleViewLabel(ByVal target As Range)
    If target Is Nothing Then Exit Sub
    With target
        .Interior.Color = RGB(241, 245, 249)
        .Font.Color = RGB(71, 85, 105)
        .Font.Bold = True
        .HorizontalAlignment = xlCenter
    End With
End Sub

Private Sub StyleViewValue(ByVal target As Range)
    If target Is Nothing Then Exit Sub
    With target
        .Interior.Color = RGB(255, 255, 255)
        .Font.Color = RGB(15, 23, 42)
        .HorizontalAlignment = xlLeft
        .IndentLevel = 1
    End With
End Sub

Private Sub StyleViewMoney(ByVal target As Range, ByVal fillColor As Long, ByVal fontColor As Long)
    If target Is Nothing Then Exit Sub
    With target
        .Interior.Color = fillColor
        .Font.Color = fontColor
        .Font.Bold = True
        .Font.Size = 12
        .HorizontalAlignment = xlRight
        .IndentLevel = 1
    End With
End Sub

Private Sub AddViewButton(ByVal ws As Worksheet, ByVal area As Range, ByVal caption As String, _
                          ByVal macroName As String, ByVal styleName As String)
    AddUIButton ws, area.Left + 2, area.Top + 2, area.Width - 4, area.Height - 4, _
                caption, macroName, styleName, False
End Sub

Public Sub FormatCashAnalysisViewLayout(ByVal ws As Worksheet)
    Dim lastR As Long, r As Long
    Dim recordTypes As Variant, tekiyoValues As Variant
    Dim recordType As String, tekiyoText As String
    If ws Is Nothing Then Exit Sub
    lastR = LastUsedRowInSheet(ws)
    If lastR < CASH_VIEW_HEADER_ROW Then lastR = CASH_VIEW_HEADER_ROW

    With ws.Range("A1:T" & CStr(lastR))
        .Font.Name = "Meiryo UI"
        .Font.Color = RGB(15, 23, 42)
        .VerticalAlignment = xlCenter
    End With
    ws.Range("A1:M8").Font.Name = "Yu Gothic UI"
    ws.Rows(1).RowHeight = 34
    ws.Rows(2).RowHeight = 36
    ws.Rows(3).RowHeight = 36
    ws.Rows(4).RowHeight = 31
    ws.Rows(5).RowHeight = 31
    ws.Rows(6).RowHeight = 38
    ws.Rows(7).RowHeight = 38
    ws.Rows(8).RowHeight = 42
    ws.Rows(9).RowHeight = 7
    ws.Rows(CASH_VIEW_HEADER_ROW).RowHeight = 34

    ws.Columns("A:A").ColumnWidth = 18
    ws.Columns("B:B").ColumnWidth = 16
    ws.Columns("C:C").ColumnWidth = 18
    ws.Columns("D:D").ColumnWidth = 10
    ws.Columns("E:E").ColumnWidth = 16
    ws.Columns("F:F").ColumnWidth = 12.5
    ws.Columns("G:G").ColumnWidth = 8.5
    ws.Columns("H:I").ColumnWidth = 14
    ws.Columns("J:J").ColumnWidth = 17
    ws.Columns("K:K").ColumnWidth = 9
    ws.Columns("L:L").ColumnWidth = 25
    ws.Columns("M:M").ColumnWidth = 15
    ws.Range("C5:M8").WrapText = True

    FormatOutputHeader ws.Range(ws.Cells(CASH_VIEW_HEADER_ROW, 1), _
                                    ws.Cells(CASH_VIEW_HEADER_ROW, CASH_VIEW_LAST_COL))
    With ws.Range(ws.Cells(CASH_VIEW_HEADER_ROW, 1), ws.Cells(CASH_VIEW_HEADER_ROW, OUT_COL_OTHER))
        .HorizontalAlignment = xlCenter
        .VerticalAlignment = xlCenter
        .WrapText = False
    End With
    With ws.Cells(CASH_VIEW_HEADER_ROW, OUT_COL_WITHDRAW)
        .Interior.Color = RGB(185, 28, 28)
        .Font.Color = RGB(255, 255, 255)
        .Font.Bold = True
    End With
    With ws.Cells(CASH_VIEW_HEADER_ROW, OUT_COL_DEPOSIT)
        .Interior.Color = RGB(29, 78, 216)
        .Font.Color = RGB(255, 255, 255)
        .Font.Bold = True
    End With
    ws.Columns("N:Z").Hidden = True

    If lastR >= CASH_VIEW_FIRST_DATA_ROW Then
        With ws.Range(ws.Cells(CASH_VIEW_FIRST_DATA_ROW, 1), ws.Cells(lastR, OUT_COL_OTHER))
            .Font.Size = 11
            .Borders.LineStyle = xlContinuous
            .Borders.Color = RGB(226, 232, 240)
            .VerticalAlignment = xlCenter
        End With
        ws.Rows(CStr(CASH_VIEW_FIRST_DATA_ROW) & ":" & CStr(lastR)).RowHeight = 30
        ws.Range(ws.Cells(CASH_VIEW_FIRST_DATA_ROW, 1), ws.Cells(lastR, OUT_COL_TIME)).HorizontalAlignment = xlCenter
        ws.Range(ws.Cells(CASH_VIEW_FIRST_DATA_ROW, OUT_COL_WITHDRAW), _
                 ws.Cells(lastR, OUT_COL_DEPOSIT)).HorizontalAlignment = xlRight
        ws.Range(ws.Cells(CASH_VIEW_FIRST_DATA_ROW, OUT_COL_WITHDRAW), _
                 ws.Cells(lastR, OUT_COL_WITHDRAW)).Font.Color = RGB(153, 27, 27)
        ws.Range(ws.Cells(CASH_VIEW_FIRST_DATA_ROW, OUT_COL_DEPOSIT), _
                 ws.Cells(lastR, OUT_COL_DEPOSIT)).Font.Color = RGB(30, 64, 175)
        ws.Range(ws.Cells(CASH_VIEW_FIRST_DATA_ROW, OUT_COL_SHOP), _
                 ws.Cells(lastR, OUT_COL_MACHINE)).HorizontalAlignment = xlCenter
        ws.Range(ws.Cells(CASH_VIEW_FIRST_DATA_ROW, OUT_COL_TEKIYO), _
                 ws.Cells(lastR, OUT_COL_TEKIYO)).HorizontalAlignment = xlLeft
        ws.Range(ws.Cells(CASH_VIEW_FIRST_DATA_ROW, OUT_COL_OTHER), _
                 ws.Cells(lastR, OUT_COL_OTHER)).HorizontalAlignment = xlRight
        ws.Range(ws.Cells(CASH_VIEW_FIRST_DATA_ROW, OUT_COL_DATE), _
                 ws.Cells(lastR, OUT_COL_DATE)).NumberFormat = "yyyy/m/d"
        ws.Range(ws.Cells(CASH_VIEW_FIRST_DATA_ROW, OUT_COL_TIME), _
                 ws.Cells(lastR, OUT_COL_TIME)).NumberFormat = "hh:mm"
        ws.Range(ws.Cells(CASH_VIEW_FIRST_DATA_ROW, OUT_COL_WITHDRAW), _
                 ws.Cells(lastR, OUT_COL_DEPOSIT)).NumberFormat = "#,##0.########"
        ws.Range(ws.Cells(CASH_VIEW_FIRST_DATA_ROW, OUT_COL_OTHER), _
                 ws.Cells(lastR, OUT_COL_OTHER)).NumberFormat = "#,##0.########"
        ws.Range(ws.Cells(CASH_VIEW_FIRST_DATA_ROW, OUT_COL_TEKIYO), _
                 ws.Cells(lastR, OUT_COL_OTHER)).WrapText = True

        If lastR = CASH_VIEW_FIRST_DATA_ROW Then
            ReDim recordTypes(1 To 1, 1 To 1)
            ReDim tekiyoValues(1 To 1, 1 To 1)
            recordTypes(1, 1) = ws.Cells(CASH_VIEW_FIRST_DATA_ROW, OUT_COL_RECORD_TYPE).Value2
            tekiyoValues(1, 1) = ws.Cells(CASH_VIEW_FIRST_DATA_ROW, OUT_COL_TEKIYO).Value2
        Else
            recordTypes = ws.Range(ws.Cells(CASH_VIEW_FIRST_DATA_ROW, OUT_COL_RECORD_TYPE), _
                                   ws.Cells(lastR, OUT_COL_RECORD_TYPE)).Value2
            tekiyoValues = ws.Range(ws.Cells(CASH_VIEW_FIRST_DATA_ROW, OUT_COL_TEKIYO), _
                                    ws.Cells(lastR, OUT_COL_TEKIYO)).Value2
        End If
        For r = CASH_VIEW_FIRST_DATA_ROW To lastR
            recordType = CellText(recordTypes(r - CASH_VIEW_FIRST_DATA_ROW + 1, 1))
            tekiyoText = CellText(tekiyoValues(r - CASH_VIEW_FIRST_DATA_ROW + 1, 1))
            If Len(tekiyoText) > 32 Or InStr(1, tekiyoText, vbLf, vbBinaryCompare) > 0 Or _
               InStr(1, tekiyoText, vbCr, vbBinaryCompare) > 0 Then _
                ws.Rows(r).RowHeight = ReadableOutputRowHeight(tekiyoText, 30, 120)
            If recordType = RECORD_BALANCE Or (Len(recordType) = 0 And InStr(1, tekiyoText, "�c��", vbTextCompare) > 0) Then
                ws.Range("A" & CStr(r) & ":M" & CStr(r)).Interior.Color = RGB(220, 252, 231)
                ws.Range("A" & CStr(r) & ":M" & CStr(r)).Font.Color = RGB(22, 101, 52)
            ElseIf recordType = RECORD_INHERITANCE Or tekiyoText = "�����J�n��" Then
                ws.Range("A" & CStr(r) & ":M" & CStr(r)).Interior.Color = RGB(254, 243, 199)
                ws.Range("A" & CStr(r) & ":M" & CStr(r)).Font.Color = RGB(146, 64, 14)
                ws.Range("A" & CStr(r) & ":M" & CStr(r)).Font.Bold = True
            ElseIf recordType = RECORD_OPEN Or recordType = RECORD_CLOSE Or _
                   tekiyoText = "�����J�ݓ�" Or tekiyoText = "��������" Then
                ws.Range("A" & CStr(r) & ":M" & CStr(r)).Interior.Color = RGB(219, 234, 254)
                ws.Range("A" & CStr(r) & ":M" & CStr(r)).Font.Color = RGB(30, 64, 175)
            End If
        Next r
    End If

    ApplyCashAnalysisConditionalFormatting ws, lastR
    ws.ScrollArea = "A1:M" & CStr(Application.Max(60, lastR + 20))
    ApplyPrintAreaVerified ws, ws.Range("A1:M" & CStr(lastR))
    '���̓p�l���͐擪�y�[�W�����ɒu���A2�y�[�W�ڈȍ~�͎�����o�������𔽕�����B
    ApplyReadablePrintSettings ws, "$10:$10"
    FixUnreadableWhiteTextOnSheet ws
End Sub

Private Sub ApplyCashAnalysisConditionalFormatting(ByVal ws As Worksheet, ByVal lastR As Long)
    Dim body As Range, fc As FormatCondition
    If ws Is Nothing Or lastR < CASH_VIEW_FIRST_DATA_ROW Then Exit Sub
    Set body = ws.Range(ws.Cells(CASH_VIEW_FIRST_DATA_ROW, 1), ws.Cells(lastR, OUT_COL_OTHER))
    body.FormatConditions.Delete

    Set fc = body.FormatConditions.Add(Type:=xlExpression, _
        Formula1:="=$S" & CStr(CASH_VIEW_FIRST_DATA_ROW) & "=" & Chr$(34) & _
                  VIEW_ROLE_WITHDRAW & Chr$(34))
    fc.Interior.Color = RGB(254, 242, 242)
    fc.Font.Color = RGB(127, 29, 29)

    Set fc = body.FormatConditions.Add(Type:=xlExpression, _
        Formula1:="=$S" & CStr(CASH_VIEW_FIRST_DATA_ROW) & "=" & Chr$(34) & _
                  VIEW_ROLE_DEPOSIT & Chr$(34))
    fc.Interior.Color = RGB(239, 246, 255)
    fc.Font.Color = RGB(30, 64, 175)

    Set fc = body.FormatConditions.Add(Type:=xlExpression, _
        Formula1:="=OR($S" & CStr(CASH_VIEW_FIRST_DATA_ROW) & "=" & Chr$(34) & _
                  VIEW_ROLE_BOTH & Chr$(34) & ",$T" & CStr(CASH_VIEW_FIRST_DATA_ROW) & _
                  "=" & Chr$(34) & "1" & Chr$(34) & ")")
    fc.Interior.Color = RGB(254, 249, 195)
    fc.Font.Color = RGB(133, 77, 14)
    On Error Resume Next
    fc.SetFirstPriority
    fc.StopIfTrue = True
    On Error GoTo 0
End Sub

Public Sub RefreshCashAnalysisPanel(Optional ByVal selectFirstVisible As Boolean = False)
    Dim ws As Worksheet, wsResult As Worksheet
    Dim categoryText As String, groupID As String, modeText As String
    Dim manualMode As Boolean, resultRow As Long, currentIndex As Long, categoryCount As Long
    Dim counts(1 To 3) As Long, followupCount As Long, unreviewedCount As Long
    Dim lastResultRow As Long, r As Long, itemCategory As String, statusText As String
    Dim categoryValues As Variant, statusValues As Variant, groupValues As Variant
    Dim workbookWasSaved As Boolean, previousEvents As Boolean, eventsCaptured As Boolean
    Dim errorNumber As Long, errorDescription As String

    On Error GoTo EH
    If Not SheetExists(SH_OUTPUT_TX) Then Exit Sub
    Set ws = GetSheet(SH_OUTPUT_TX)
    workbookWasSaved = ThisWorkbook.Saved
    previousEvents = Application.EnableEvents
    eventsCaptured = True
    Application.EnableEvents = False
    ws.Unprotect Password:=TOOL_PASSWORD

    categoryText = CellText(ws.Range(VIEW_STATE_CATEGORY).Value)
    If Not IsCashViewCategory(categoryText) Then categoryText = VIEW_CATEGORY_TRANSFER
    modeText = CellText(ws.Range(VIEW_STATE_MODE).Value)
    If Not IsCashViewMode(modeText) Then modeText = VIEW_MODE_COMPONENT
    manualMode = (CellText(ws.Range(VIEW_STATE_MANUAL).Value) = "1")

    If SheetExists(SH_ANALYSIS_RESULT) Then
        Set wsResult = GetSheet(SH_ANALYSIS_RESULT)
        lastResultRow = LastUsedRowInSheet(wsResult)
        If lastResultRow >= 2 Then
            categoryValues = CashResultColumnValues(wsResult, 2, lastResultRow, 2)
            statusValues = CashResultColumnValues(wsResult, 2, lastResultRow, ANALYSIS_RESULT_STATUS_COL)
            groupValues = CashResultColumnValues(wsResult, 2, lastResultRow, ANALYSIS_RESULT_GROUP_ID_COL)
        End If
        For r = 1 To Application.Max(0, lastResultRow - 1)
            itemCategory = CashViewCategoryForResult(CellText(categoryValues(r, 1)))
            Select Case itemCategory
                Case VIEW_CATEGORY_TRANSFER: counts(1) = counts(1) + 1
                Case VIEW_CATEGORY_UNKNOWN_WITHDRAW: counts(2) = counts(2) + 1
                Case VIEW_CATEGORY_UNKNOWN_DEPOSIT: counts(3) = counts(3) + 1
            End Select
            statusText = CellText(statusValues(r, 1))
            If statusText = ANALYSIS_STATUS_FOLLOWUP Then followupCount = followupCount + 1
            If Len(statusText) = 0 Or statusText = ANALYSIS_STATUS_UNREVIEWED Then _
                unreviewedCount = unreviewedCount + 1
        Next r
    End If

    UpdateCategoryButtonCaptions ws, categoryText, counts
    If manualMode Then
        RefreshCashManualSelectionPanel ws
    ElseIf wsResult Is Nothing Or lastResultRow < 2 Then
        ClearCashAnalysisCandidatePanel ws, categoryText, counts, unreviewedCount, followupCount
        ShowAllCashViewRows ws
    Else
        groupID = CellText(ws.Range(VIEW_STATE_GROUP_ID).Value)
        resultRow = FindCashAnalysisResultRow(categoryValues, groupValues, categoryText, groupID, _
                                               currentIndex, categoryCount)
        If resultRow = 0 Then
            ClearCashAnalysisCandidatePanel ws, categoryText, counts, unreviewedCount, followupCount
            ShowAllCashViewRows ws
        Else
            ws.Range(VIEW_STATE_GROUP_ID).Value = CellText(wsResult.Cells(resultRow, ANALYSIS_RESULT_GROUP_ID_COL).Value)
            ws.Range(VIEW_STATE_RESULT_ROW).Value = CStr(resultRow)
            ws.Range(VIEW_STATE_MODE).Value = modeText
            RenderCashAnalysisCandidate ws, wsResult, resultRow, currentIndex, categoryCount, _
                                        counts, unreviewedCount, followupCount, modeText
            ApplyCashAnalysisRowFilter ws, _
                CellText(wsResult.Cells(resultRow, ANALYSIS_RESULT_TX_IDS_COL).Value), modeText
        End If
    End If
    AdjustCashAnalysisPanelRowHeights ws
    ApplyCashAnalysisPanelValidation ws
    UpdateCashAnalysisStatusStyle ws
    ProtectCashAnalysisViewSheet
    Application.EnableEvents = previousEvents
    If workbookWasSaved Then ThisWorkbook.Saved = True
    If selectFirstVisible Then SelectFirstVisibleCashAnalysisRow ws
    Exit Sub
EH:
    errorNumber = Err.Number: errorDescription = Err.Description
    If eventsCaptured Then Application.EnableEvents = previousEvents
    On Error Resume Next
    ProtectCashAnalysisViewSheet
    On Error GoTo 0
    Err.Raise errorNumber, "RefreshCashAnalysisPanel", errorDescription
End Sub

Private Sub AdjustCashAnalysisPanelRowHeights(ByVal ws As Worksheet)
    Dim expanded As Boolean
    Dim routeMaximum As Double, textMaximum As Double, memoMaximum As Double
    Dim actionText As String
    If ws Is Nothing Then Exit Sub
    expanded = (CellText(ws.Range(VIEW_STATE_PANEL_EXPANDED).Value) = "1")
    If expanded Then
        routeMaximum = 360
        textMaximum = 240
        memoMaximum = 240
        actionText = "�m�_�u���N���b�N�Ő܂肽���ށn"
    Else
        routeMaximum = 54
        textMaximum = 68
        memoMaximum = 96
        actionText = "�m�_�u���N���b�N�œW�J�n"
    End If
    ws.Range("A6").Value = "���o���R�E�v�_" & vbLf & actionText
    ws.Range("A7").Value = "���؁E����" & vbLf & actionText
    ws.Range("A8").Value = "�m�F����" & vbLf & actionText
    ws.Rows(5).RowHeight = CashPanelTextRowHeight(CellText(ws.Range("H5").Value), 90, 31, routeMaximum)
    ws.Rows(6).RowHeight = CashPanelTextRowHeight(CellText(ws.Range("C6").Value), 150, 38, textMaximum)
    ws.Rows(7).RowHeight = CashPanelTextRowHeight(CellText(ws.Range("C7").Value), 150, 38, textMaximum)
    ws.Rows(8).RowHeight = CashPanelTextRowHeight(CellText(ws.Range("C8").Value), 150, 42, memoMaximum)
End Sub

Private Function CashPanelTextRowHeight(ByVal valueText As String, ByVal charactersPerLine As Long, _
                                        ByVal minimumHeight As Double, ByVal maximumHeight As Double) As Double
    Dim lineCount As Long
    Dim estimatedHeight As Double
    If charactersPerLine < 1 Then charactersPerLine = 1
    lineCount = ReadableTextLineCount(valueText, charactersPerLine)
    If lineCount < 1 Then lineCount = 1
    estimatedHeight = 18# * CDbl(lineCount) + 4#
    If estimatedHeight < minimumHeight Then estimatedHeight = minimumHeight
    If estimatedHeight > maximumHeight Then estimatedHeight = maximumHeight
    CashPanelTextRowHeight = estimatedHeight
End Function

Public Sub ToggleCashAnalysisPanelExpansion()
    Dim ws As Worksheet
    Dim workbookWasSaved As Boolean
    Dim errorNumber As Long, errorDescription As String
    If Not SheetExists(SH_OUTPUT_TX) Then Exit Sub
    On Error GoTo EH
    Set ws = GetSheet(SH_OUTPUT_TX)
    workbookWasSaved = ThisWorkbook.Saved
    ws.Unprotect Password:=TOOL_PASSWORD
    If CellText(ws.Range(VIEW_STATE_PANEL_EXPANDED).Value) = "1" Then
        ws.Range(VIEW_STATE_PANEL_EXPANDED).Value = "0"
    Else
        ws.Range(VIEW_STATE_PANEL_EXPANDED).Value = "1"
    End If
    AdjustCashAnalysisPanelRowHeights ws
    ProtectCashAnalysisViewSheet
    If workbookWasSaved Then ThisWorkbook.Saved = True
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    On Error Resume Next
    ProtectCashAnalysisViewSheet
    On Error GoTo 0
    MsgBox OperationFailureHeading(errorNumber, "���͐������̕\����؂�ւ����܂���ł����B") & vbCrLf & _
           OperationFailureDetail(errorNumber, errorDescription), OperationFailureIcon(errorNumber, vbExclamation)
End Sub

Private Sub RenderCashAnalysisCandidate(ByVal ws As Worksheet, ByVal wsResult As Worksheet, _
                                        ByVal resultRow As Long, ByVal currentIndex As Long, _
                                        ByVal categoryCount As Long, ByRef counts() As Long, _
                                        ByVal unreviewedCount As Long, ByVal followupCount As Long, _
                                        ByVal modeText As String)
    Dim categoryText As String, statusText As String, alternativeCount As Long
    Dim titleText As String, priorityText As String, manualStoredKey As String
    categoryText = CashViewCategoryForResult(CellText(wsResult.Cells(resultRow, 2).Value))
    statusText = CellText(wsResult.Cells(resultRow, ANALYSIS_RESULT_STATUS_COL).Value)
    If Len(statusText) = 0 Then statusText = ANALYSIS_STATUS_UNREVIEWED
    If IsNumeric(wsResult.Cells(resultRow, ANALYSIS_RESULT_ALTERNATIVE_COUNT_COL).Value) Then _
        alternativeCount = CLng(wsResult.Cells(resultRow, ANALYSIS_RESULT_ALTERNATIVE_COUNT_COL).Value)
    If alternativeCount < 1 Then alternativeCount = 1

    priorityText = CellText(wsResult.Cells(resultRow, 1).Value)
    titleText = categoryText & " " & CStr(currentIndex) & "/" & CStr(categoryCount)
    If categoryText = VIEW_CATEGORY_UNKNOWN_WITHDRAW Or _
       categoryText = VIEW_CATEGORY_UNKNOWN_DEPOSIT Then _
        titleText = titleText & "�i�v�m�F���j"
    If Len(priorityText) > 0 Then titleText = titleText & "�b�D��x " & priorityText
    If alternativeCount > 1 Then titleText = titleText & "�b��։��� " & CStr(alternativeCount) & "��"
    ws.Range("F1").Value = titleText & "�b�S�敪 ���m�F " & CStr(unreviewedCount) & _
                           "�� / �v���� " & CStr(followupCount) & "��"
    ws.Range("C3").Value = statusText
    ws.Range("C5").Value = CellText(wsResult.Cells(resultRow, 3).Value)
    ws.Range("H5").Value = CellText(wsResult.Cells(resultRow, 5).Value)
    ws.Range("C6").Value = CellText(wsResult.Cells(resultRow, 6).Value)
    ws.Range("C7").Value = CellText(wsResult.Cells(resultRow, 7).Value)
    ws.Range("C8").Value = CellText(wsResult.Cells(resultRow, ANALYSIS_RESULT_MEMO_COL).Value)
    SetShapeCaption ws, "CycleCashAnalysisViewMode", "�\��: " & modeText
    If CashAnalysisResultIsManual(wsResult, resultRow, manualStoredKey) Then
        SetShapeCaption ws, "CashAnalysisSecondaryAction", "�蓮���𖳌���"
        SetViewButtonColors ws, "CashAnalysisSecondaryAction", _
                            RGB(254, 242, 242), RGB(220, 38, 38), RGB(153, 27, 27)
    Else
        SetShapeCaption ws, "CashAnalysisSecondaryAction", "�蓮����I��"
        SetViewButtonColors ws, "CashAnalysisSecondaryAction", _
                            RGB(255, 255, 255), RGB(203, 213, 225), RGB(30, 64, 175)
    End If
    ws.Range("C3:D3").Locked = ThisWorkbook.ReadOnly
    ws.Range("C8:M8").Locked = ThisWorkbook.ReadOnly
End Sub

Private Sub ClearCashAnalysisCandidatePanel(ByVal ws As Worksheet, ByVal categoryText As String, _
                                            ByRef counts() As Long, ByVal unreviewedCount As Long, _
                                            ByVal followupCount As Long)
    Dim countValue As Long
    Select Case categoryText
        Case VIEW_CATEGORY_TRANSFER: countValue = counts(1)
        Case VIEW_CATEGORY_UNKNOWN_WITHDRAW: countValue = counts(2)
        Case VIEW_CATEGORY_UNKNOWN_DEPOSIT: countValue = counts(3)
    End Select
    ws.Range("F1").Value = categoryText & IIf(categoryText = VIEW_CATEGORY_TRANSFER, "", "�i�v�m�F���j") & _
                           "  0 / " & CStr(countValue) & _
                           "�@�S�敪 ���m�F " & CStr(unreviewedCount) & "�� / �v�ǉ����� " & _
                           CStr(followupCount) & "��"
    ws.Range(VIEW_STATE_GROUP_ID).ClearContents
    ws.Range(VIEW_STATE_RESULT_ROW).ClearContents
    ws.Range("C3").Value = "���Ȃ�"
    SetCashAnalysisTotals ws, 0, 0
    ws.Range("C5").Value = "�|"
    ws.Range("H5").Value = "���̋敪�ɂ͌��݌�₪����܂���B"
    ws.Range("C6").Value = "���͏�����ύX�����ꍇ�́A���[�E���͂��č쐬���Ă��������B"
    ws.Range("C7").Value = "���Ȃ��́A����Ȃ���ۏ؂�����̂ł͂���܂���B���������m�F���Ă��������B"
    ws.Range("C8").Value = ""
    ws.Range("C3:D3").Locked = True
    ws.Range("C8:M8").Locked = True
    SetShapeCaption ws, "CycleCashAnalysisViewMode", "�\��: �S���"
    SetShapeCaption ws, "CashAnalysisSecondaryAction", "�蓮����I��"
    SetViewButtonColors ws, "CashAnalysisSecondaryAction", _
                        RGB(255, 255, 255), RGB(203, 213, 225), RGB(30, 64, 175)
    SetShapeCaption ws, "CashAnalysisPrimaryAction", "���Ȃ�"
End Sub

Private Sub ApplyCashAnalysisRowFilter(ByVal ws As Worksheet, ByVal txIDList As String, _
                                       ByVal modeText As String)
    Dim lastR As Long, data As Variant, displayData() As Variant, roleData() As Variant
    Dim wanted As Object, accounts As Object, personIDs As Object, accountPersonMap As Object
    Dim txID As String, accountID As String, personID As String
    Dim r As Long, rowCount As Long, minDate As Double, maxDate As Double, transactionDateSerial As Double
    Dim relatedDays As Long, showRow As Boolean, withdrawal As Double, deposit As Double
    Dim candidateRow As Boolean

    lastR = CashAnalysisLastDataRow(ws)
    If lastR < CASH_VIEW_FIRST_DATA_ROW Then Exit Sub
    rowCount = lastR - CASH_VIEW_FIRST_DATA_ROW + 1
    data = ws.Range(ws.Cells(CASH_VIEW_FIRST_DATA_ROW, 1), _
                    ws.Cells(lastR, OUT_COL_RECORD_TYPE)).Value2
    ReDim displayData(1 To rowCount, 1 To 1)
    ReDim roleData(1 To rowCount, 1 To 1)
    Set wanted = IDsToDictionary(txIDList)
    Set accounts = CreateObject("Scripting.Dictionary")
    Set personIDs = CreateObject("Scripting.Dictionary")
    Set accountPersonMap = CashAnalysisAccountPersonMap()
    accounts.CompareMode = vbTextCompare
    personIDs.CompareMode = vbTextCompare

    For r = 1 To rowCount
        txID = CellText(data(r, OUT_COL_TRANSACTION_ID))
        If Len(txID) > 0 And wanted.Exists(txID) Then
            accountID = CellText(data(r, OUT_COL_ACCOUNT_ID))
            If Len(accountID) > 0 Then accounts(accountID) = True
            If Len(accountID) > 0 And accountPersonMap.Exists(accountID) Then
                personID = CellText(accountPersonMap(accountID))
                If Len(personID) > 0 Then personIDs(personID) = True
            End If
            If IsDate(data(r, OUT_COL_DATE)) Then
                transactionDateSerial = CDbl(CDate(data(r, OUT_COL_DATE)))
                If minDate = 0 Or transactionDateSerial < minDate Then minDate = transactionDateSerial
                If maxDate = 0 Or transactionDateSerial > maxDate Then maxDate = transactionDateSerial
            End If
        End If
    Next r

    If CellText(ws.Range(VIEW_STATE_CATEGORY).Value) = VIEW_CATEGORY_TRANSFER Then
        relatedDays = 30
        If IsNumeric(GetSheet(SH_CONFIG).Cells(ROW_CFG_ANALYSIS_DAY_WINDOW, COL_CFG_ANALYSIS_VALUE).Value) Then _
            relatedDays = Application.Max(relatedDays, _
                CLng(GetSheet(SH_CONFIG).Cells(ROW_CFG_ANALYSIS_DAY_WINDOW, COL_CFG_ANALYSIS_VALUE).Value))
    Else
        relatedDays = 365
    End If

    For r = 1 To rowCount
        txID = CellText(data(r, OUT_COL_TRANSACTION_ID))
        candidateRow = (Len(txID) > 0 And wanted.Exists(txID))
        showRow = False
        If modeText = VIEW_MODE_ALL Then
            showRow = True
        ElseIf modeText = VIEW_MODE_COMPONENT Then
            showRow = candidateRow
        ElseIf candidateRow Then
            showRow = True
        ElseIf IsDate(data(r, OUT_COL_DATE)) And minDate > 0 Then
                transactionDateSerial = CDbl(CDate(data(r, OUT_COL_DATE)))
                If transactionDateSerial >= minDate - relatedDays And _
                   transactionDateSerial <= maxDate + relatedDays Then
                    accountID = CellText(data(r, OUT_COL_ACCOUNT_ID))
                    personID = ""
                    If Len(accountID) > 0 And accountPersonMap.Exists(accountID) Then _
                        personID = CellText(accountPersonMap(accountID))
                    If (Len(accountID) > 0 And accounts.Exists(accountID)) Or _
                       (Len(personID) > 0 And personIDs.Exists(personID)) Then showRow = True
                End If
            End If
        If showRow Then displayData(r, 1) = "1" Else displayData(r, 1) = "0"
        If candidateRow Then
            withdrawal = CashViewDouble(data(r, OUT_COL_WITHDRAW))
            deposit = CashViewDouble(data(r, OUT_COL_DEPOSIT))
            roleData(r, 1) = CashViewRole(withdrawal, deposit)
        End If
    Next r

    ws.Range(ws.Cells(CASH_VIEW_FIRST_DATA_ROW, CASH_VIEW_COL_DISPLAY), _
             ws.Cells(lastR, CASH_VIEW_COL_DISPLAY)).Value = displayData
    ws.Range(ws.Cells(CASH_VIEW_FIRST_DATA_ROW, CASH_VIEW_COL_ROLE), _
             ws.Cells(lastR, CASH_VIEW_COL_ROLE)).Value = roleData
    ws.Range(ws.Cells(CASH_VIEW_FIRST_DATA_ROW, CASH_VIEW_COL_SELECTED), _
             ws.Cells(lastR, CASH_VIEW_COL_SELECTED)).ClearContents
    ApplyCashViewAutoFilter ws, lastR, (modeText <> VIEW_MODE_ALL)
    CalculateCashAnalysisTotals ws, wanted
End Sub

Private Function CashAnalysisAccountPersonMap() As Object
    '�֘A����͕\�������ł͂Ȃ������l��ID�ő��ˁA���������̕ʐl�����݂����Ȃ��B
    Dim result As Object
    Dim ws As Worksheet
    Dim lastR As Long, r As Long
    Dim data As Variant
    Dim accountID As String, personID As String
    Set result = CreateObject("Scripting.Dictionary")
    result.CompareMode = vbTextCompare
    If Not SheetExists(SH_WORK_ACCOUNT) Then
        Set CashAnalysisAccountPersonMap = result
        Exit Function
    End If
    Set ws = GetSheet(SH_WORK_ACCOUNT)
    lastR = LastUsedRowInSheet(ws)
    If lastR >= 2 Then
        data = ws.Range(ws.Cells(2, ACC_COL_ID), ws.Cells(lastR, ACC_COL_PERSON_ID)).Value2
        For r = 1 To lastR - 1
            accountID = CellText(data(r, ACC_COL_ID))
            personID = CellText(data(r, ACC_COL_PERSON_ID))
            If Len(accountID) > 0 And Len(personID) > 0 Then
                If result.Exists(accountID) Then
                    If StrComp(CellText(result(accountID)), personID, vbTextCompare) <> 0 Then _
                        Err.Raise vbObjectError + 4968, "CashAnalysisAccountPersonMap", _
                                  "��������ID�ɈقȂ�l��ID������܂�: " & accountID
                Else
                    result.Add accountID, personID
                End If
            End If
        Next r
    End If
    Set CashAnalysisAccountPersonMap = result
End Function

Private Sub CalculateCashAnalysisTotals(ByVal ws As Worksheet, ByVal wanted As Object)
    Dim lastR As Long, data As Variant, r As Long, txID As String
    Dim totalWithdrawal As Double, totalDeposit As Double
    lastR = CashAnalysisLastDataRow(ws)
    If lastR < CASH_VIEW_FIRST_DATA_ROW Then
        SetCashAnalysisTotals ws, 0, 0
        Exit Sub
    End If
    data = ws.Range(ws.Cells(CASH_VIEW_FIRST_DATA_ROW, OUT_COL_WITHDRAW), _
                    ws.Cells(lastR, OUT_COL_TRANSACTION_ID)).Value2
    For r = 1 To UBound(data, 1)
        txID = CellText(data(r, OUT_COL_TRANSACTION_ID - OUT_COL_WITHDRAW + 1))
        If Len(txID) > 0 And wanted.Exists(txID) Then
            totalWithdrawal = totalWithdrawal + CashViewDouble(data(r, 1))
            totalDeposit = totalDeposit + CashViewDouble(data(r, 2))
        End If
    Next r
    SetCashAnalysisTotals ws, totalWithdrawal, totalDeposit
End Sub

Private Sub SetCashAnalysisTotals(ByVal ws As Worksheet, ByVal totalWithdrawal As Double, _
                                  ByVal totalDeposit As Double)
    ws.Range("B4").Value = totalWithdrawal
    ws.Range("F4").Value = totalDeposit
    ws.Range("J4").Value = totalDeposit - totalWithdrawal
    ws.Range("B4:D4").NumberFormat = "#,##0.########"
    ws.Range("F4:H4").NumberFormat = "#,##0.########"
    ws.Range("J4:M4").NumberFormat = "+#,##0.########;-#,##0.########;0"
End Sub

Private Sub ShowAllCashViewRows(ByVal ws As Worksheet)
    Dim lastR As Long
    lastR = CashAnalysisLastDataRow(ws)
    If lastR < CASH_VIEW_FIRST_DATA_ROW Then Exit Sub
    ws.Range(ws.Cells(CASH_VIEW_FIRST_DATA_ROW, CASH_VIEW_COL_DISPLAY), _
             ws.Cells(lastR, CASH_VIEW_COL_DISPLAY)).Value = "1"
    ws.Range(ws.Cells(CASH_VIEW_FIRST_DATA_ROW, CASH_VIEW_COL_ROLE), _
             ws.Cells(lastR, CASH_VIEW_COL_SELECTED)).ClearContents
    ApplyCashViewAutoFilter ws, lastR, False
End Sub

Private Sub ApplyCashViewAutoFilter(ByVal ws As Worksheet, ByVal lastR As Long, _
                                    ByVal filterComponents As Boolean)
    If ws.AutoFilterMode Then ws.AutoFilterMode = False
    ws.Range(ws.Cells(CASH_VIEW_HEADER_ROW, 1), _
             ws.Cells(lastR, CASH_VIEW_COL_SELECTED)).AutoFilter
    If filterComponents Then
        ws.Range(ws.Cells(CASH_VIEW_HEADER_ROW, 1), _
                 ws.Cells(lastR, CASH_VIEW_COL_SELECTED)).AutoFilter _
                 Field:=CASH_VIEW_COL_DISPLAY, Criteria1:="1"
    End If
End Sub

Private Function FindCashAnalysisResultRow(ByRef categoryValues As Variant, _
                                           ByRef groupValues As Variant, _
                                           ByVal categoryText As String, ByVal groupID As String, _
                                           ByRef currentIndex As Long, ByRef categoryCount As Long) As Long
    Dim itemCount As Long, r As Long, firstRow As Long, resultRow As Long
    Dim itemCategory As String, itemGroupID As String
    If Not IsArray(categoryValues) Or Not IsArray(groupValues) Then Exit Function
    itemCount = UBound(categoryValues, 1)
    For r = 1 To itemCount
        resultRow = r + 1
        itemCategory = CashViewCategoryForResult(CellText(categoryValues(r, 1)))
        If itemCategory = categoryText Then
            categoryCount = categoryCount + 1
            If firstRow = 0 Then firstRow = resultRow
            itemGroupID = CellText(groupValues(r, 1))
            If Len(groupID) > 0 And StrComp(itemGroupID, groupID, vbTextCompare) = 0 Then
                FindCashAnalysisResultRow = resultRow
                currentIndex = categoryCount
            End If
        End If
    Next r
    If FindCashAnalysisResultRow = 0 Then
        FindCashAnalysisResultRow = firstRow
        If firstRow > 0 Then currentIndex = 1
    End If
End Function

Private Sub UpdateCategoryButtonCaptions(ByVal ws As Worksheet, ByVal activeCategory As String, _
                                         ByRef counts() As Long)
    SetShapeCaption ws, "ShowCashAnalysisTransfers", _
        IIf(activeCategory = VIEW_CATEGORY_TRANSFER, "�� ", "") & "�����ړ� " & CStr(counts(1))
    SetShapeCaption ws, "ShowCashAnalysisUnknownWithdrawals", _
        IIf(activeCategory = VIEW_CATEGORY_UNKNOWN_WITHDRAW, "�� ", "") & "�s���o�� " & CStr(counts(2))
    SetShapeCaption ws, "ShowCashAnalysisUnknownDeposits", _
        IIf(activeCategory = VIEW_CATEGORY_UNKNOWN_DEPOSIT, "�� ", "") & "�s������ " & CStr(counts(3))
    SetCategoryButtonState ws, "ShowCashAnalysisTransfers", _
                           (activeCategory = VIEW_CATEGORY_TRANSFER), RGB(15, 118, 110), RGB(13, 148, 136)
    SetCategoryButtonState ws, "ShowCashAnalysisUnknownWithdrawals", _
                           (activeCategory = VIEW_CATEGORY_UNKNOWN_WITHDRAW), RGB(185, 28, 28), RGB(153, 27, 27)
    SetCategoryButtonState ws, "ShowCashAnalysisUnknownDeposits", _
                           (activeCategory = VIEW_CATEGORY_UNKNOWN_DEPOSIT), RGB(29, 78, 216), RGB(30, 64, 175)
End Sub

Private Sub SetCategoryButtonState(ByVal ws As Worksheet, ByVal macroName As String, _
                                   ByVal isActive As Boolean, ByVal activeFill As Long, _
                                   ByVal activeLine As Long)
    Dim shp As Shape
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    For Each shp In ws.Shapes
        If StrComp(ToolShapeActionName(shp), macroName, vbTextCompare) = 0 Then
            If isActive Then
                shp.Fill.ForeColor.RGB = activeFill
                shp.Line.ForeColor.RGB = activeLine
                shp.TextFrame.Characters.Font.Color = RGB(255, 255, 255)
                shp.Line.Weight = 1.2
            Else
                shp.Fill.ForeColor.RGB = RGB(248, 250, 252)
                shp.Line.ForeColor.RGB = RGB(203, 213, 225)
                shp.TextFrame.Characters.Font.Color = RGB(51, 65, 85)
                shp.Line.Weight = 0.8
            End If
            Exit For
        End If
    Next shp
    On Error GoTo 0
    SetCashViewPrintControlState ws, macroName, isActive, activeFill, activeLine
End Sub

Private Sub SetShapeCaption(ByVal ws As Worksheet, ByVal macroName As String, ByVal caption As String)
    Dim shp As Shape
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    For Each shp In ws.Shapes
        If StrComp(ToolShapeActionName(shp), macroName, vbTextCompare) = 0 Then
            shp.TextFrame.Characters.Text = caption
            shp.TextFrame.Characters.Font.Name = "Yu Gothic UI"
            shp.TextFrame.Characters.Font.Bold = True
            SetToolShapeAccessibleLabel shp, caption
            Exit For
        End If
    Next shp
    On Error GoTo 0
    SetCashViewPrintCaption ws, macroName, caption
End Sub

Private Sub SetViewButtonColors(ByVal ws As Worksheet, ByVal macroName As String, _
                                ByVal fillColor As Long, ByVal lineColor As Long, _
                                ByVal fontColor As Long)
    Dim shp As Shape
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    For Each shp In ws.Shapes
        If StrComp(ToolShapeActionName(shp), macroName, vbTextCompare) = 0 Then
            shp.Fill.ForeColor.RGB = fillColor
            shp.Line.ForeColor.RGB = lineColor
            shp.TextFrame.Characters.Font.Color = fontColor
            Exit For
        End If
    Next shp
    On Error GoTo 0
    If StrComp(macroName, "CycleCashAnalysisViewMode", vbTextCompare) = 0 Then _
        SetCashViewPrintControlColors ws.Range("G3:H3"), fillColor, lineColor, fontColor
End Sub

Private Sub SetCashViewPrintCaption(ByVal ws As Worksheet, ByVal macroName As String, _
                                    ByVal caption As String)
    Dim target As Range
    If ws Is Nothing Then Exit Sub
    Select Case macroName
        Case "ShowCashAnalysisTransfers": Set target = ws.Range("A2:C2")
        Case "ShowCashAnalysisUnknownWithdrawals": Set target = ws.Range("D2:F2")
        Case "ShowCashAnalysisUnknownDeposits": Set target = ws.Range("G2:I2")
        Case "CycleCashAnalysisViewMode": Set target = ws.Range("G3:H3")
    End Select
    If Not target Is Nothing Then target.Cells(1, 1).Value = caption
End Sub

Private Sub SetCashViewPrintControlState(ByVal ws As Worksheet, ByVal macroName As String, _
                                         ByVal isActive As Boolean, ByVal activeFill As Long, _
                                         ByVal activeLine As Long)
    Dim target As Range
    If ws Is Nothing Then Exit Sub
    Select Case macroName
        Case "ShowCashAnalysisTransfers": Set target = ws.Range("A2:C2")
        Case "ShowCashAnalysisUnknownWithdrawals": Set target = ws.Range("D2:F2")
        Case "ShowCashAnalysisUnknownDeposits": Set target = ws.Range("G2:I2")
    End Select
    If target Is Nothing Then Exit Sub
    If isActive Then
        SetCashViewPrintControlColors target, activeFill, activeLine, RGB(255, 255, 255)
    Else
        SetCashViewPrintControlColors target, RGB(248, 250, 252), RGB(203, 213, 225), RGB(51, 65, 85)
    End If
End Sub

Private Sub SetCashViewPrintControlColors(ByVal target As Range, ByVal fillColor As Long, _
                                          ByVal lineColor As Long, ByVal fontColor As Long)
    If target Is Nothing Then Exit Sub
    With target
        .Interior.Color = fillColor
        .Font.Color = fontColor
        .Font.Bold = True
        .Borders.LineStyle = xlContinuous
        .Borders.Color = lineColor
    End With
End Sub

Private Function CashAnalysisResultIsManual(ByVal wsResult As Worksheet, ByVal resultRow As Long, _
                                            ByRef storedKey As String) As Boolean
    Dim wsFlow As Worksheet, sourceRow As Long
    If wsResult Is Nothing Or Not SheetExists(SH_ANALYSIS_FLOW) Then Exit Function
    If resultRow < 2 Or resultRow > LastUsedRowInSheet(wsResult) Then Exit Function
    If StrComp(CellText(wsResult.Cells(resultRow, ANALYSIS_RESULT_SOURCE_SHEET_COL).Value), _
               SH_ANALYSIS_FLOW, vbTextCompare) <> 0 Then Exit Function
    sourceRow = CLng(Val(CellText(wsResult.Cells(resultRow, ANALYSIS_RESULT_SOURCE_ROW_COL).Value)))
    Set wsFlow = GetSheet(SH_ANALYSIS_FLOW)
    If sourceRow < 2 Or sourceRow > LastUsedRowInSheet(wsFlow) Then Exit Function
    If StrComp(CellText(wsFlow.Cells(sourceRow, 3).Value), "�蓮�w��", vbTextCompare) <> 0 Then Exit Function
    storedKey = CellText(wsResult.Cells(resultRow, ANALYSIS_RESULT_SOURCE_KEY_COL).Value)
    If Len(storedKey) = 0 Then storedKey = CellText(wsFlow.Cells(sourceRow, FLOW_ANALYSIS_KEY_COL).Value)
    CashAnalysisResultIsManual = (Len(storedKey) > 0)
End Function

Public Sub ShowCashAnalysisTransfers()
    SelectCashAnalysisCategory VIEW_CATEGORY_TRANSFER
End Sub

Public Sub ShowCashAnalysisUnknownWithdrawals()
    SelectCashAnalysisCategory VIEW_CATEGORY_UNKNOWN_WITHDRAW
End Sub

Public Sub ShowCashAnalysisUnknownDeposits()
    SelectCashAnalysisCategory VIEW_CATEGORY_UNKNOWN_DEPOSIT
End Sub

Private Sub SelectCashAnalysisCategory(ByVal categoryText As String)
    Dim ws As Worksheet
    Dim workbookWasSaved As Boolean
    Dim errorNumber As Long, errorDescription As String
    If Not SheetExists(SH_OUTPUT_TX) Then Exit Sub
    If Not RequireCashAnalysisManualModeFinished("���͋敪�̐ؑ�") Then Exit Sub
    On Error GoTo EH
    SyncCashAnalysisPanelReviewToWorkspace
    workbookWasSaved = ThisWorkbook.Saved
    Set ws = GetSheet(SH_OUTPUT_TX)
    ws.Unprotect Password:=TOOL_PASSWORD
    ws.Range(VIEW_STATE_CATEGORY).Value = categoryText
    ws.Range(VIEW_STATE_GROUP_ID).ClearContents
    ws.Range(VIEW_STATE_MODE).Value = VIEW_MODE_COMPONENT
    ws.Range(VIEW_STATE_MANUAL).Value = "0"
    ws.Range(VIEW_STATE_SELECTED_IDS).ClearContents
    ws.Range(VIEW_STATE_PANEL_EXPANDED).Value = "0"
    RefreshCashAnalysisPanel True
    If workbookWasSaved Then ThisWorkbook.Saved = True
    Exit Sub
EH:
    errorNumber = Err.Number: errorDescription = Err.Description
    On Error Resume Next
    ProtectCashAnalysisViewSheet
    On Error GoTo 0
    MsgBox OperationFailureHeading(errorNumber, "���͋敪��؂�ւ����܂���ł����B") & vbCrLf & _
           OperationFailureDetail(errorNumber, errorDescription), OperationFailureIcon(errorNumber, vbExclamation)
End Sub

Public Sub PreviousCashAnalysisCandidate()
    NavigateCashAnalysisCandidate -1
End Sub

Public Sub NextCashAnalysisCandidate()
    NavigateCashAnalysisCandidate 1
End Sub

Private Sub NavigateCashAnalysisCandidate(ByVal direction As Long)
    Dim ws As Worksheet, wsResult As Worksheet
    Dim categoryText As String, groupID As String
    Dim candidateRows() As Long, candidateCount As Long
    Dim r As Long, currentIndex As Long, nextIndex As Long, lastR As Long
    Dim categoryValues As Variant, groupValues As Variant
    Dim workbookWasSaved As Boolean
    Dim errorNumber As Long, errorDescription As String
    If Not SheetExists(SH_OUTPUT_TX) Or Not SheetExists(SH_ANALYSIS_RESULT) Then Exit Sub
    If Not RequireCashAnalysisManualModeFinished("���̐ؑ�") Then Exit Sub
    On Error GoTo EH
    SyncCashAnalysisPanelReviewToWorkspace
    workbookWasSaved = ThisWorkbook.Saved
    Set ws = GetSheet(SH_OUTPUT_TX)
    Set wsResult = GetSheet(SH_ANALYSIS_RESULT)
    ws.Unprotect Password:=TOOL_PASSWORD
    ws.Range(VIEW_STATE_MANUAL).Value = "0"
    categoryText = CellText(ws.Range(VIEW_STATE_CATEGORY).Value)
    groupID = CellText(ws.Range(VIEW_STATE_GROUP_ID).Value)
    lastR = LastUsedRowInSheet(wsResult)
    If lastR >= 2 Then
        categoryValues = CashResultColumnValues(wsResult, 2, lastR, 2)
        groupValues = CashResultColumnValues(wsResult, 2, lastR, ANALYSIS_RESULT_GROUP_ID_COL)
        ReDim candidateRows(1 To lastR - 1)
    End If
    For r = 1 To Application.Max(0, lastR - 1)
        If CashViewCategoryForResult(CellText(categoryValues(r, 1))) = categoryText Then
            candidateCount = candidateCount + 1
            candidateRows(candidateCount) = r + 1
            If StrComp(CellText(groupValues(r, 1)), groupID, vbTextCompare) = 0 Then _
                currentIndex = candidateCount
        End If
    Next r
    If candidateCount = 0 Then
        RefreshCashAnalysisPanel False
        If workbookWasSaved Then ThisWorkbook.Saved = True
        Exit Sub
    End If
    If currentIndex = 0 Then currentIndex = 1
    nextIndex = currentIndex + direction
    If nextIndex < 1 Then nextIndex = candidateCount
    If nextIndex > candidateCount Then nextIndex = 1
    ws.Range(VIEW_STATE_GROUP_ID).Value = _
        CellText(groupValues(candidateRows(nextIndex) - 1, 1))
    ws.Range(VIEW_STATE_PANEL_EXPANDED).Value = "0"
    RefreshCashAnalysisPanel True
    If workbookWasSaved Then ThisWorkbook.Saved = True
    Exit Sub
EH:
    errorNumber = Err.Number: errorDescription = Err.Description
    On Error Resume Next
    ProtectCashAnalysisViewSheet
    On Error GoTo 0
    MsgBox OperationFailureHeading(errorNumber, "����؂�ւ����܂���ł����B") & vbCrLf & _
           OperationFailureDetail(errorNumber, errorDescription), OperationFailureIcon(errorNumber, vbExclamation)
End Sub

Public Sub CycleCashAnalysisViewMode()
    Dim ws As Worksheet, modeText As String
    Dim workbookWasSaved As Boolean
    Dim errorNumber As Long, errorDescription As String
    If Not SheetExists(SH_OUTPUT_TX) Then Exit Sub
    If Not RequireCashAnalysisManualModeFinished("�\���͈͂̐ؑ�") Then Exit Sub
    On Error GoTo EH
    Set ws = GetSheet(SH_OUTPUT_TX)
    If Len(CellText(ws.Range(VIEW_STATE_GROUP_ID).Value)) = 0 Then Exit Sub
    SyncCashAnalysisPanelReviewToWorkspace
    workbookWasSaved = ThisWorkbook.Saved
    ws.Unprotect Password:=TOOL_PASSWORD
    modeText = CellText(ws.Range(VIEW_STATE_MODE).Value)
    Select Case modeText
        Case VIEW_MODE_COMPONENT: modeText = VIEW_MODE_RELATED
        Case VIEW_MODE_RELATED: modeText = VIEW_MODE_ALL
        Case Else: modeText = VIEW_MODE_COMPONENT
    End Select
    ws.Range(VIEW_STATE_MODE).Value = modeText
    RefreshCashAnalysisPanel True
    If workbookWasSaved Then ThisWorkbook.Saved = True
    Exit Sub
EH:
    errorNumber = Err.Number: errorDescription = Err.Description
    On Error Resume Next
    ProtectCashAnalysisViewSheet
    On Error GoTo 0
    MsgBox OperationFailureHeading(errorNumber, "�\���͈͂�؂�ւ����܂���ł����B") & vbCrLf & _
           "�m�F�󋵁E�m�F�������m�F���Ă��������B" & vbCrLf & _
           OperationFailureDetail(errorNumber, errorDescription), OperationFailureIcon(errorNumber, vbExclamation)
End Sub

Public Sub CashAnalysisSecondaryAction()
    Dim ws As Worksheet, wsResult As Worksheet
    Dim resultRow As Long, storedKey As String
    Dim errorNumber As Long, errorDescription As String
    If Not SheetExists(SH_OUTPUT_TX) Then Exit Sub
    On Error GoTo EH
    Set ws = GetSheet(SH_OUTPUT_TX)
    If CellText(ws.Range(VIEW_STATE_MANUAL).Value) = "1" Then
        ClearCashAnalysisManualSelection True
    Else
        If SheetExists(SH_ANALYSIS_RESULT) Then
            Set wsResult = GetSheet(SH_ANALYSIS_RESULT)
            resultRow = CLng(Val(CellText(ws.Range(VIEW_STATE_RESULT_ROW).Value)))
        End If
        If CashAnalysisResultIsManual(wsResult, resultRow, storedKey) Then
            SyncCashAnalysisPanelReviewToWorkspace
            DeactivateManualFlowCandidateByStoredKey storedKey
        Else
            EnterCashAnalysisManualMode
        End If
    End If
    Exit Sub
EH:
    errorNumber = Err.Number: errorDescription = Err.Description
    On Error Resume Next
    ProtectCashAnalysisViewSheet
    On Error GoTo 0
    MsgBox OperationFailureHeading(errorNumber, "�蓮���̑���������ł��܂���ł����B") & vbCrLf & _
           OperationFailureDetail(errorNumber, errorDescription), OperationFailureIcon(errorNumber, vbExclamation)
End Sub

Public Sub CashAnalysisPrimaryAction()
    Dim ws As Worksheet, statusText As String, proposedStatus As String
    Dim errorNumber As Long, errorDescription As String
    If Not SheetExists(SH_OUTPUT_TX) Then Exit Sub
    On Error GoTo EH
    Set ws = GetSheet(SH_OUTPUT_TX)
    If CellText(ws.Range(VIEW_STATE_MANUAL).Value) = "1" Then
        RegisterCashAnalysisManualSelection
        Exit Sub
    End If
    If Len(CellText(ws.Range(VIEW_STATE_GROUP_ID).Value)) = 0 Then Exit Sub
    statusText = CellText(ws.Range("C3").Value)
    If Len(statusText) = 0 Or statusText = ANALYSIS_STATUS_UNREVIEWED Then
        proposedStatus = ConfirmedStatusForCashCategory(CellText(ws.Range(VIEW_STATE_CATEGORY).Value))
        If Len(proposedStatus) = 0 Then _
            Err.Raise vbObjectError + 4969, "CashAnalysisPrimaryAction", _
                      "���݂̕��͋敪�ɑΉ�����m�F�ςݏ�Ԃ�����܂���B"
        If MsgBox("���̌����u" & proposedStatus & "�v�Ƃ��ĕۑ����܂����H" & vbCrLf & _
                  "������A�o���E�����A�m�F������������x�m�F���Ă��������B", _
                  vbYesNo + vbQuestion + vbDefaultButton2, "�m�F�󋵂̊m��") <> vbYes Then Exit Sub
        statusText = proposedStatus
        ws.Unprotect Password:=TOOL_PASSWORD
        ws.Range("C3").Value = statusText
    Else
        ws.Unprotect Password:=TOOL_PASSWORD
    End If
    SyncCashAnalysisPanelReviewToWorkspace
    CommitPendingAnalysisReviews False, "��������\���番�͔��f��ۑ�"
    RefreshCashAnalysisPanel False
    Exit Sub
EH:
    errorNumber = Err.Number: errorDescription = Err.Description
    On Error Resume Next
    ProtectCashAnalysisViewSheet
    On Error GoTo 0
    MsgBox OperationFailureHeading(errorNumber, "�m�F���e��ۑ��ł��܂���ł����B") & vbCrLf & _
           "�m�F�󋵁E�m�F�������������Ă��������B" & vbCrLf & _
           OperationFailureDetail(errorNumber, errorDescription), OperationFailureIcon(errorNumber, vbExclamation)
End Sub

Private Sub EnterCashAnalysisManualMode()
    Dim ws As Worksheet
    Dim workbookWasSaved As Boolean
    Dim errorNumber As Long, errorDescription As String
    If ThisWorkbook.ReadOnly Then
        MsgBox "�ǂݎ���p�ł͎蓮����o�^�ł��܂���B", vbExclamation
        Exit Sub
    End If
    SyncCashAnalysisPanelReviewToWorkspace
    workbookWasSaved = ThisWorkbook.Saved
    Set ws = GetSheet(SH_OUTPUT_TX)
    '�ی���O������ԂŎ��s����Ǝ�������\���ҏW�\�Ȃ܂܎c��B�K���߂��B
    On Error GoTo EH
    ws.Unprotect Password:=TOOL_PASSWORD
    ws.Range(VIEW_STATE_MANUAL).Value = "1"
    ws.Range(VIEW_STATE_SELECTED_IDS).ClearContents
    ws.Range(VIEW_STATE_PANEL_EXPANDED).Value = "0"
    RefreshCashAnalysisPanel False
    If workbookWasSaved Then ThisWorkbook.Saved = True
    MsgBox "�蓮���̑I�����[�h�ɐ؂�ւ��܂����B" & vbCrLf & _
           "��������\�̎���s���_�u���N���b�N���đI�����Ă��������B" & vbCrLf & _
           "�E�vL����_�u���N���b�N����ƁA�I����ς����ɑS�����m�F�ł��܂��B" & vbCrLf & _
           "�o���Ɠ����͕ʁX�ɏW�v����A�㕔�ō��z���m�F�ł��܂��B", _
           vbInformation, "�蓮���̑I��"
    Exit Sub
EH:
    errorNumber = Err.Number: errorDescription = Err.Description
    On Error Resume Next
    ProtectCashAnalysisViewSheet
    If workbookWasSaved Then ThisWorkbook.Saved = True
    On Error GoTo 0
    Err.Raise errorNumber, "EnterCashAnalysisManualMode", errorDescription
End Sub

Private Sub RefreshCashManualSelectionPanel(ByVal ws As Worksheet)
    Dim selected As Object, validSelected As Object, lastR As Long, data As Variant
    Dim displayData() As Variant, roleData() As Variant, selectionData() As Variant
    Dim r As Long, rowCount As Long, txID As String, roleText As String
    Dim withdrawal As Double, deposit As Double, totalWithdrawal As Double, totalDeposit As Double
    Dim outCount As Long, inCount As Long
    Set selected = IDsToDictionary(CellText(ws.Range(VIEW_STATE_SELECTED_IDS).Value))
    Set validSelected = CreateObject("Scripting.Dictionary")
    validSelected.CompareMode = vbTextCompare
    lastR = CashAnalysisLastDataRow(ws)
    If lastR >= CASH_VIEW_FIRST_DATA_ROW Then
        data = ws.Range(ws.Cells(CASH_VIEW_FIRST_DATA_ROW, 1), _
                        ws.Cells(lastR, OUT_COL_RECORD_TYPE)).Value2
        rowCount = UBound(data, 1)
        ReDim displayData(1 To rowCount, 1 To 1)
        ReDim roleData(1 To rowCount, 1 To 1)
        ReDim selectionData(1 To rowCount, 1 To 1)
        For r = 1 To rowCount
            displayData(r, 1) = "1"
            txID = CellText(data(r, OUT_COL_TRANSACTION_ID))
            If Len(txID) > 0 And selected.Exists(txID) And _
               StrComp(CellText(data(r, OUT_COL_RECORD_TYPE)), RECORD_TRANSACTION, vbTextCompare) = 0 Then
                validSelected(txID) = True
                withdrawal = CashViewDouble(data(r, OUT_COL_WITHDRAW))
                deposit = CashViewDouble(data(r, OUT_COL_DEPOSIT))
                roleText = CashViewRole(withdrawal, deposit)
                roleData(r, 1) = roleText
                selectionData(r, 1) = "1"
                totalWithdrawal = totalWithdrawal + withdrawal
                totalDeposit = totalDeposit + deposit
                If withdrawal > 0 Then outCount = outCount + 1
                If deposit > 0 Then inCount = inCount + 1
            End If
        Next r
        ws.Range(ws.Cells(CASH_VIEW_FIRST_DATA_ROW, CASH_VIEW_COL_DISPLAY), _
                 ws.Cells(lastR, CASH_VIEW_COL_DISPLAY)).Value = displayData
        ws.Range(ws.Cells(CASH_VIEW_FIRST_DATA_ROW, CASH_VIEW_COL_ROLE), _
                 ws.Cells(lastR, CASH_VIEW_COL_ROLE)).Value = roleData
        ws.Range(ws.Cells(CASH_VIEW_FIRST_DATA_ROW, CASH_VIEW_COL_SELECTED), _
                 ws.Cells(lastR, CASH_VIEW_COL_SELECTED)).Value = selectionData
        ApplyCashViewAutoFilter ws, lastR, False
    End If
    Set selected = validSelected
    ws.Range(VIEW_STATE_SELECTED_IDS).Value = JoinCashDictionaryKeys(selected)

    ws.Range("F1").Value = "�蓮����I�𒆁@�I�� " & CStr(selected.Count) & _
                           "���i�o�� " & CStr(outCount) & "�� / ���� " & CStr(inCount) & "���j"
    ws.Range("C3").Value = "�I��"
    SetCashAnalysisTotals ws, totalWithdrawal, totalDeposit
    ws.Range("C5").Value = "�s���_�u���N���b�N�i�E�vL��͑S���\���j"
    ws.Range("H5").Value = "�o���Ɠ��������ꂼ��1���ȏ�I�����Ă��������B"
    ws.Range("C6").Value = "�E�vL��ȊO���_�u���N���b�N����ƑI���^�������܂��B�I���s�͒W�����F�ŕ\�����A�o���z�Ɠ����z�͕ʗ��̂܂܏W�v���܂��B"
    ws.Range("C7").Value = "�o�^�O�ɁA���t�E�����E�E�v�ƍ��z���������Ŋm�F���Ă��������B"
    ws.Range("C8").Value = ""
    ws.Range("C3:D3").Locked = True
    ws.Range("C8:M8").Locked = True
    SetShapeCaption ws, "CycleCashAnalysisViewMode", "�\��: �S���"
    SetShapeCaption ws, "CashAnalysisSecondaryAction", "�I����������"
    SetViewButtonColors ws, "CashAnalysisSecondaryAction", _
                        RGB(254, 242, 242), RGB(220, 38, 38), RGB(153, 27, 27)
    SetShapeCaption ws, "CashAnalysisPrimaryAction", "�I����������o�^"
End Sub

Public Sub OnCashAnalysisViewDoubleClick(ByVal targetRow As Long, _
                                         Optional ByVal targetColumn As Long = 0)
    Dim ws As Worksheet, txID As String
    If Not SheetExists(SH_OUTPUT_TX) Then Exit Sub
    Set ws = GetSheet(SH_OUTPUT_TX)
    If targetRow < CASH_VIEW_FIRST_DATA_ROW Or targetRow > CashAnalysisLastDataRow(ws) Then Exit Sub
    If StrComp(CellText(ws.Cells(targetRow, OUT_COL_RECORD_TYPE).Value), _
               RECORD_TRANSACTION, vbTextCompare) <> 0 Then Exit Sub
    txID = CellText(ws.Cells(targetRow, OUT_COL_TRANSACTION_ID).Value)
    If Len(txID) = 0 Then Exit Sub
    If targetColumn = OUT_COL_TEKIYO Then
        ShowCashAnalysisTransactionText ws, targetRow
    ElseIf CellText(ws.Range(VIEW_STATE_MANUAL).Value) = "1" Then
        ToggleCashManualTransaction ws, txID
    Else
        FocusCashAnalysisCandidateByTransaction ws, txID
    End If
End Sub

Private Sub ShowCashAnalysisTransactionText(ByVal ws As Worksheet, ByVal targetRow As Long)
    Dim dateText As String, timeText As String, amountText As String, promptText As String
    If ws Is Nothing Then Exit Sub
    If IsDate(ws.Cells(targetRow, OUT_COL_DATE).Value) Then _
        dateText = Format$(CDate(ws.Cells(targetRow, OUT_COL_DATE).Value), "yyyy/m/d")
    If IsDate(ws.Cells(targetRow, OUT_COL_TIME).Value) Then _
        timeText = Format$(CDate(ws.Cells(targetRow, OUT_COL_TIME).Value), "hh:mm")
    If CashViewDouble(ws.Cells(targetRow, OUT_COL_WITHDRAW).Value) <> 0 Then
        amountText = "�o�� " & Format$(CashViewDouble(ws.Cells(targetRow, OUT_COL_WITHDRAW).Value), "#,##0.########")
    ElseIf CashViewDouble(ws.Cells(targetRow, OUT_COL_DEPOSIT).Value) <> 0 Then
        amountText = "���� " & Format$(CashViewDouble(ws.Cells(targetRow, OUT_COL_DEPOSIT).Value), "#,##0.########")
    Else
        amountText = "���z 0"
    End If
    promptText = "���t�E����: " & dateText & IIf(Len(timeText) > 0, " " & timeText, "") & vbCrLf & _
                 "����: " & CellText(ws.Cells(targetRow, OUT_COL_BANK).Value) & " " & _
                 CellText(ws.Cells(targetRow, OUT_COL_BRANCH).Value) & " / " & _
                 CellText(ws.Cells(targetRow, OUT_COL_PERSON).Value) & vbCrLf & _
                 "���z: " & amountText & vbCrLf & _
                 "�戵�X�E�@��: " & CellText(ws.Cells(targetRow, OUT_COL_SHOP).Value) & " " & _
                 CellText(ws.Cells(targetRow, OUT_COL_MACHINE).Value) & vbCrLf & vbCrLf & _
                 "�E�v��" & vbCrLf & CellText(ws.Cells(targetRow, OUT_COL_TEKIYO).Value)
    ShowCashAnalysisLongMessage promptText, "����̓E�v��S���\��"
End Sub

Public Sub ShowCashAnalysisPanelText(ByVal targetRow As Long)
    Dim ws As Worksheet, titleText As String, promptText As String
    If Not SheetExists(SH_OUTPUT_TX) Then Exit Sub
    Set ws = GetSheet(SH_OUTPUT_TX)
    Select Case targetRow
        Case 5
            titleText = "���t�E�l���E�����o�H��S���\��"
            promptText = "���t�E����" & vbCrLf & CellText(ws.Range("C5").Value) & _
                         vbCrLf & vbCrLf & "�l���E�����o�H" & vbCrLf & _
                         CellText(ws.Range("H5").Value)
        Case 6
            titleText = "���o���R�E�v�_��S���\��"
            promptText = CellText(ws.Range("C6").Value)
        Case 7
            titleText = "���؁E�����S���\��"
            promptText = CellText(ws.Range("C7").Value)
        Case Else
            Exit Sub
    End Select
    If Len(promptText) = 0 Then promptText = "�i�\��������e�͂���܂���j"
    ShowCashAnalysisLongMessage promptText, titleText
End Sub

Private Sub ShowCashAnalysisLongMessage(ByVal valueText As String, ByVal titleText As String)
    'MsgBox�̕\������Œ����������������Ȃ��悤�A���S�Ȓ����Ńy�[�W��������B
    Const MESSAGE_CHUNK As Long = 900
    Dim pageCount As Long, pageNumber As Long
    Dim pageTitle As String, startAt As Long
    If Len(valueText) = 0 Then valueText = "�i�\��������e�͂���܂���j"
    pageCount = (Len(valueText) + MESSAGE_CHUNK - 1) \ MESSAGE_CHUNK
    If pageCount < 1 Then pageCount = 1
    For pageNumber = 1 To pageCount
        startAt = (pageNumber - 1) * MESSAGE_CHUNK + 1
        pageTitle = titleText
        If pageCount > 1 Then _
            pageTitle = pageTitle & "�i" & CStr(pageNumber) & "/" & CStr(pageCount) & "�j"
        MsgBox Mid$(valueText, startAt, MESSAGE_CHUNK), vbInformation, pageTitle
    Next pageNumber
End Sub

Public Function CashAnalysisManualModeActive() As Boolean
    If Not SheetExists(SH_OUTPUT_TX) Then Exit Function
    CashAnalysisManualModeActive = _
        (CellText(GetSheet(SH_OUTPUT_TX).Range(VIEW_STATE_MANUAL).Value) = "1")
End Function

Public Function HasCashAnalysisManualSelection() As Boolean
    If Not CashAnalysisManualModeActive() Then Exit Function
    HasCashAnalysisManualSelection = _
        (IDsToDictionary(CellText(GetSheet(SH_OUTPUT_TX).Range(VIEW_STATE_SELECTED_IDS).Value)).Count > 0)
End Function

Public Sub ClearCashAnalysisManualSelection(Optional ByVal refreshView As Boolean = True)
    Dim ws As Worksheet
    Dim workbookWasSaved As Boolean
    Dim errorNumber As Long, errorDescription As String
    On Error GoTo EH
    If Not SheetExists(SH_OUTPUT_TX) Then Exit Sub
    Set ws = GetSheet(SH_OUTPUT_TX)
    workbookWasSaved = ThisWorkbook.Saved
    ws.Unprotect Password:=TOOL_PASSWORD
    ws.Range(VIEW_STATE_MANUAL).Value = "0"
    ws.Range(VIEW_STATE_SELECTED_IDS).ClearContents
    If refreshView Then
        RefreshCashAnalysisPanel False
    Else
        ProtectCashAnalysisViewSheet
    End If
    If workbookWasSaved Then ThisWorkbook.Saved = True
    Exit Sub
EH:
    errorNumber = Err.Number: errorDescription = Err.Description
    On Error Resume Next
    ProtectCashAnalysisViewSheet
    On Error GoTo 0
    Err.Raise errorNumber, "ClearCashAnalysisManualSelection", errorDescription
End Sub

Private Sub ToggleCashManualTransaction(ByVal ws As Worksheet, ByVal txID As String)
    Dim selected As Object
    Dim workbookWasSaved As Boolean
    Dim selectedText As String
    Dim errorNumber As Long, errorDescription As String
    On Error GoTo EH
    workbookWasSaved = ThisWorkbook.Saved
    Set selected = IDsToDictionary(CellText(ws.Range(VIEW_STATE_SELECTED_IDS).Value))
    If selected.Exists(txID) Then
        selected.Remove txID
    Else
        selected(txID) = True
    End If
    selectedText = JoinCashDictionaryKeys(selected)
    If Len(selectedText) > VIEW_SELECTED_IDS_MAX Then
        MsgBox "��x�ɑI���ł����������̏���ɒB���܂����B" & vbCrLf & _
               "�蓮���𕡐��ɕ����ēo�^���Ă��������B", _
               vbInformation, "�蓮���̑I�����"
        Exit Sub
    End If
    ws.Unprotect Password:=TOOL_PASSWORD
    ws.Range(VIEW_STATE_SELECTED_IDS).Value = selectedText
    RefreshCashAnalysisPanel False
    If workbookWasSaved Then ThisWorkbook.Saved = True
    Exit Sub
EH:
    errorNumber = Err.Number: errorDescription = Err.Description
    On Error Resume Next
    ProtectCashAnalysisViewSheet
    On Error GoTo 0
    MsgBox OperationFailureHeading(errorNumber, "�蓮���̑I�����X�V�ł��܂���ł����B") & vbCrLf & _
           OperationFailureDetail(errorNumber, errorDescription), OperationFailureIcon(errorNumber, vbExclamation)
End Sub

Private Sub FocusCashAnalysisCandidateByTransaction(ByVal ws As Worksheet, ByVal txID As String)
    Dim wsResult As Worksheet, lastR As Long, r As Long
    Dim categoryText As String, firstMatch As Long, preferredMatch As Long
    Dim categoryValues As Variant, txIDValues As Variant
    Dim workbookWasSaved As Boolean
    Dim errorNumber As Long, errorDescription As String
    If Not SheetExists(SH_ANALYSIS_RESULT) Then Exit Sub
    On Error GoTo EH
    Set wsResult = GetSheet(SH_ANALYSIS_RESULT)
    categoryText = CellText(ws.Range(VIEW_STATE_CATEGORY).Value)
    lastR = LastUsedRowInSheet(wsResult)
    If lastR >= 2 Then
        categoryValues = CashResultColumnValues(wsResult, 2, lastR, 2)
        txIDValues = CashResultColumnValues(wsResult, 2, lastR, ANALYSIS_RESULT_TX_IDS_COL)
    End If
    For r = 1 To Application.Max(0, lastR - 1)
        If IDListContains(CellText(txIDValues(r, 1)), txID) Then
            If firstMatch = 0 Then firstMatch = r + 1
            If CashViewCategoryForResult(CellText(categoryValues(r, 1))) = categoryText Then
                preferredMatch = r + 1
                Exit For
            End If
        End If
    Next r
    If preferredMatch = 0 Then preferredMatch = firstMatch
    If preferredMatch = 0 Then
        MsgBox "���̎�����\������Ɋ܂ޕ��͌��͂���܂���B" & vbCrLf & _
               "�s�����o���̍Œ���z�ȂǁA���͏������m�F���Ă��������B", vbInformation
        Exit Sub
    End If
    SyncCashAnalysisPanelReviewToWorkspace
    workbookWasSaved = ThisWorkbook.Saved
    ws.Unprotect Password:=TOOL_PASSWORD
    ws.Range(VIEW_STATE_CATEGORY).Value = _
        CashViewCategoryForResult(CellText(wsResult.Cells(preferredMatch, 2).Value))
    ws.Range(VIEW_STATE_GROUP_ID).Value = _
        CellText(wsResult.Cells(preferredMatch, ANALYSIS_RESULT_GROUP_ID_COL).Value)
    ws.Range(VIEW_STATE_MODE).Value = VIEW_MODE_COMPONENT
    ws.Range(VIEW_STATE_PANEL_EXPANDED).Value = "0"
    RefreshCashAnalysisPanel True
    If workbookWasSaved Then ThisWorkbook.Saved = True
    Exit Sub
EH:
    errorNumber = Err.Number: errorDescription = Err.Description
    On Error Resume Next
    ProtectCashAnalysisViewSheet
    On Error GoTo 0
    MsgBox OperationFailureHeading(errorNumber, "����ɑΉ����镪�͌���\���ł��܂���ł����B") & vbCrLf & _
           OperationFailureDetail(errorNumber, errorDescription), OperationFailureIcon(errorNumber, vbExclamation)
End Sub

Private Sub RegisterCashAnalysisManualSelection()
    Dim ws As Worksheet, idList As String
    Dim errorNumber As Long, errorDescription As String
    If Not SheetExists(SH_OUTPUT_TX) Then Exit Sub
    Set ws = GetSheet(SH_OUTPUT_TX)
    idList = CellText(ws.Range(VIEW_STATE_SELECTED_IDS).Value)
    If IDsToDictionary(idList).Count < 2 Then
        MsgBox "�����2���ȏ�I�����Ă��������B�o���Ɠ��������ꂼ��܂߂�K�v������܂��B", vbInformation
        Exit Sub
    End If
    '�o�^�����͗�O�𓊂�����B���s���ɕی�Ȃ��E�I�������ŕ��u���Ȃ��B
    On Error GoTo EH
    ws.Unprotect Password:=TOOL_PASSWORD
    ws.Range(VIEW_STATE_MANUAL).Value = "0"
    If RegisterManualAnalysisCandidateByIDs(idList) Then
        If SheetExists(SH_OUTPUT_TX) Then
            Set ws = GetSheet(SH_OUTPUT_TX)
            ws.Unprotect Password:=TOOL_PASSWORD
            ws.Range(VIEW_STATE_CATEGORY).Value = VIEW_CATEGORY_TRANSFER
            ws.Range(VIEW_STATE_MODE).Value = VIEW_MODE_COMPONENT
            ws.Range(VIEW_STATE_SELECTED_IDS).ClearContents
            RefreshCashAnalysisPanel True
        Else
            ProtectCashAnalysisViewSheet
        End If
    Else
        ws.Range(VIEW_STATE_MANUAL).Value = "1"
        ws.Range(VIEW_STATE_SELECTED_IDS).Value = idList
        RefreshCashAnalysisPanel False
    End If
    Exit Sub
EH:
    errorNumber = Err.Number: errorDescription = Err.Description
    On Error Resume Next
    '�I����e�����킹�Ȃ��B�I�����[�h�̂܂ܖ߂��čĎ��s�ł���悤�ɂ���B
    If SheetExists(SH_OUTPUT_TX) Then
        Set ws = GetSheet(SH_OUTPUT_TX)
        ws.Unprotect Password:=TOOL_PASSWORD
        ws.Range(VIEW_STATE_MANUAL).Value = "1"
        ws.Range(VIEW_STATE_SELECTED_IDS).Value = idList
        ProtectCashAnalysisViewSheet
    End If
    On Error GoTo 0
    Err.Raise errorNumber, "RegisterCashAnalysisManualSelection", errorDescription
End Sub

Public Sub OnCashAnalysisViewChange(ByVal Target As Range)
    Dim ws As Worksheet
    Dim errorNumber As Long, errorDescription As String
    On Error GoTo EH
    If Target Is Nothing Or Not SheetExists(SH_OUTPUT_TX) Then Exit Sub
    Set ws = GetSheet(SH_OUTPUT_TX)
    If Intersect(Target, ws.Range("C3")) Is Nothing And _
       Intersect(Target, ws.Range("C8")) Is Nothing Then Exit Sub
    If CellText(ws.Range(VIEW_STATE_MANUAL).Value) = "1" Then Exit Sub
    If Len(CellText(ws.Range(VIEW_STATE_GROUP_ID).Value)) = 0 Then Exit Sub
    ws.Unprotect Password:=TOOL_PASSWORD
    ValidateCashAnalysisPanelReview ws
    MarkAnalysisReviewsDirty
    UpdateCashAnalysisStatusStyle ws
    AdjustCashAnalysisPanelRowHeights ws
    ProtectCashAnalysisViewSheet
    Exit Sub
EH:
    errorNumber = Err.Number: errorDescription = Err.Description
    On Error Resume Next
    RefreshCashAnalysisPanel False
    ProtectCashAnalysisViewSheet
    On Error GoTo 0
    MsgBox OperationFailureHeading(errorNumber, "�m�F�󋵂܂��͊m�F�������X�V�ł��܂���ł����B") & vbCrLf & _
           "���͑O�̓��e�֖߂��܂����B���敪�ɍ����m�F�󋵂ƁA" & _
           CStr(VIEW_MEMO_MAX) & "�����ȓ��̃�������͂��Ă��������B" & vbCrLf & _
           OperationFailureDetail(errorNumber, errorDescription), _
           OperationFailureIcon(errorNumber, vbExclamation), "���͔��f�̓��͂��m�F���Ă�������"
End Sub

Public Sub SyncCashAnalysisPanelReviewToWorkspace()
    Dim ws As Worksheet, wsResult As Worksheet
    Dim groupID As String, statusText As String, memoText As String
    Dim resultRow As Long, lastR As Long, r As Long
    Dim groupValues As Variant
    Dim previousEvents As Boolean, changed As Boolean, eventsCaptured As Boolean
    Dim errorNumber As Long, errorDescription As String
    On Error GoTo EH
    If ThisWorkbook.ReadOnly Then Exit Sub
    If Not SheetExists(SH_OUTPUT_TX) Or Not SheetExists(SH_ANALYSIS_RESULT) Then Exit Sub
    Set ws = GetSheet(SH_OUTPUT_TX)
    If CellText(ws.Range(VIEW_STATE_MANUAL).Value) = "1" Then Exit Sub
    groupID = CellText(ws.Range(VIEW_STATE_GROUP_ID).Value)
    If Len(groupID) = 0 Then Exit Sub
    ValidateCashAnalysisPanelReview ws
    statusText = CellText(ws.Range("C3").Value)
    memoText = CellText(ws.Range("C8").Value)
    Set wsResult = GetSheet(SH_ANALYSIS_RESULT)
    lastR = LastUsedRowInSheet(wsResult)
    resultRow = CLng(Val(CellText(ws.Range(VIEW_STATE_RESULT_ROW).Value)))
    If resultRow < 2 Or resultRow > lastR Or _
       StrComp(CellText(wsResult.Cells(resultRow, ANALYSIS_RESULT_GROUP_ID_COL).Value), _
               groupID, vbTextCompare) <> 0 Then
        resultRow = 0
        If lastR >= 2 Then _
            groupValues = CashResultColumnValues(wsResult, 2, lastR, ANALYSIS_RESULT_GROUP_ID_COL)
        For r = 1 To Application.Max(0, lastR - 1)
            If StrComp(CellText(groupValues(r, 1)), groupID, vbTextCompare) = 0 Then
                resultRow = r + 1
                Exit For
            End If
        Next r
    End If
    If resultRow = 0 Then Exit Sub
    previousEvents = Application.EnableEvents
    eventsCaptured = True
    Application.EnableEvents = False
    wsResult.Unprotect Password:=TOOL_PASSWORD
    If CellText(wsResult.Cells(resultRow, ANALYSIS_RESULT_STATUS_COL).Value) <> statusText Then
        wsResult.Cells(resultRow, ANALYSIS_RESULT_STATUS_COL).Value = statusText
        changed = True
    End If
    If CellText(wsResult.Cells(resultRow, ANALYSIS_RESULT_MEMO_COL).Value) <> memoText Then
        wsResult.Cells(resultRow, ANALYSIS_RESULT_MEMO_COL).Value = memoText
        changed = True
    End If
    ProtectSingleAnalysisSheet wsResult
    Application.EnableEvents = previousEvents
    If changed Then MarkAnalysisReviewsDirty
    Exit Sub
EH:
    errorNumber = Err.Number: errorDescription = Err.Description
    On Error Resume Next
    If eventsCaptured Then Application.EnableEvents = previousEvents
    If Not wsResult Is Nothing Then ProtectSingleAnalysisSheet wsResult
    On Error GoTo 0
    Err.Raise errorNumber, "SyncCashAnalysisPanelReviewToWorkspace", errorDescription
End Sub

Private Sub ValidateCashAnalysisPanelReview(ByVal ws As Worksheet)
    Dim categoryText As String, statusText As String, memoText As String
    categoryText = CellText(ws.Range(VIEW_STATE_CATEGORY).Value)
    statusText = CellText(ws.Range("C3").Value)
    memoText = CellText(ws.Range("C8").Value)
    If Len(statusText) = 0 Then
        statusText = ANALYSIS_STATUS_UNREVIEWED
        ws.Range("C3").Value = statusText
    End If
    If Not IsStatusAllowedForCashCategory(categoryText, statusText) Then _
        Err.Raise vbObjectError + 4980, "ValidateCashAnalysisPanelReview", _
                  "�m�F�󋵁u" & statusText & "�v��" & categoryText & "�ł͑I���ł��܂���B"
    If Len(memoText) > VIEW_MEMO_MAX Then _
        Err.Raise vbObjectError + 4981, "ValidateCashAnalysisPanelReview", _
                  "�m�F������" & CStr(VIEW_MEMO_MAX) & "�����ȓ��œ��͂��Ă��������B"
End Sub

Private Sub ApplyCashAnalysisPanelValidation(ByVal ws As Worksheet)
    Dim listName As String
    On Error Resume Next
    ws.Range("C3").Validation.Delete
    ws.Range("C8").Validation.Delete
    On Error GoTo 0
    If CellText(ws.Range(VIEW_STATE_MANUAL).Value) = "1" Or _
       Len(CellText(ws.Range(VIEW_STATE_GROUP_ID).Value)) = 0 Then Exit Sub
    Select Case CellText(ws.Range(VIEW_STATE_CATEGORY).Value)
        Case VIEW_CATEGORY_UNKNOWN_DEPOSIT: listName = NM_LST_ANALYSIS_SOURCE_STATUS
        Case VIEW_CATEGORY_UNKNOWN_WITHDRAW: listName = NM_LST_ANALYSIS_USE_STATUS
        Case Else: listName = NM_LST_ANALYSIS_SHIFT_STATUS
    End Select
    With ws.Range("C3").Validation
        .Add Type:=xlValidateList, AlertStyle:=xlValidAlertStop, _
             Operator:=xlBetween, Formula1:="=" & listName
        .IgnoreBlank = False
        .InCellDropdown = True
        .ShowError = True
        .ErrorTitle = "�m�F�󋵂�I�����Ă�������"
        .ErrorMessage = "���敪�ɍ����m�F�󋵂��ꗗ����I�����Ă��������B"
    End With
    With ws.Range("C8").Validation
        .Add Type:=xlValidateTextLength, AlertStyle:=xlValidAlertStop, _
             Operator:=xlLessEqual, Formula1:=CStr(VIEW_MEMO_MAX)
        .IgnoreBlank = True
        .ShowError = True
        .ErrorTitle = "�m�F�������������܂�"
        .ErrorMessage = "�m�F������" & CStr(VIEW_MEMO_MAX) & "�����ȓ��œ��͂��Ă��������B"
    End With
End Sub

Private Sub UpdateCashAnalysisStatusStyle(ByVal ws As Worksheet)
    Dim statusText As String
    statusText = CellText(ws.Range("C3").Value)
    With ws.Range("C3:D3")
        .Font.Bold = True
        .HorizontalAlignment = xlCenter
        Select Case statusText
            Case ANALYSIS_STATUS_SHIFT_CONFIRMED, ANALYSIS_STATUS_SOURCE_CONFIRMED, ANALYSIS_STATUS_USE_CONFIRMED
                .Interior.Color = RGB(220, 252, 231)
                .Font.Color = RGB(22, 101, 52)
            Case ANALYSIS_STATUS_FOLLOWUP
                .Interior.Color = RGB(254, 243, 199)
                .Font.Color = RGB(146, 64, 14)
            Case ANALYSIS_STATUS_EXCLUDED
                .Interior.Color = RGB(226, 232, 240)
                .Font.Color = RGB(71, 85, 105)
            Case Else
                .Interior.Color = RGB(254, 249, 195)
                .Font.Color = RGB(133, 77, 14)
        End Select
    End With
    UpdateCashAnalysisPrimaryActionState ws, statusText
End Sub

Private Sub UpdateCashAnalysisPrimaryActionState(ByVal ws As Worksheet, ByVal statusText As String)
    Dim confirmedStatus As String
    If ws Is Nothing Then Exit Sub
    If CellText(ws.Range(VIEW_STATE_MANUAL).Value) = "1" Then Exit Sub
    If Len(CellText(ws.Range(VIEW_STATE_GROUP_ID).Value)) = 0 Then
        SetShapeCaption ws, "CashAnalysisPrimaryAction", "���Ȃ�"
        SetViewButtonColors ws, "CashAnalysisPrimaryAction", _
                            RGB(241, 245, 249), RGB(203, 213, 225), RGB(100, 116, 139)
        Exit Sub
    End If
    confirmedStatus = ConfirmedStatusForCashCategory(CellText(ws.Range(VIEW_STATE_CATEGORY).Value))
    Select Case statusText
        Case confirmedStatus
            SetShapeCaption ws, "CashAnalysisPrimaryAction", "�m�F���e��ۑ�"
            SetViewButtonColors ws, "CashAnalysisPrimaryAction", _
                                RGB(220, 252, 231), RGB(34, 197, 94), RGB(22, 101, 52)
        Case ANALYSIS_STATUS_FOLLOWUP
            SetShapeCaption ws, "CashAnalysisPrimaryAction", "�v�ǉ������ŕۑ�"
            SetViewButtonColors ws, "CashAnalysisPrimaryAction", _
                                RGB(254, 243, 199), RGB(245, 158, 11), RGB(146, 64, 14)
        Case ANALYSIS_STATUS_EXCLUDED
            SetShapeCaption ws, "CashAnalysisPrimaryAction", "�ΏۊO�ŕۑ�"
            SetViewButtonColors ws, "CashAnalysisPrimaryAction", _
                                RGB(226, 232, 240), RGB(148, 163, 184), RGB(71, 85, 105)
        Case Else
            SetShapeCaption ws, "CashAnalysisPrimaryAction", "�m�F�ς݂ɂ���"
            SetViewButtonColors ws, "CashAnalysisPrimaryAction", _
                                RGB(37, 99, 235), RGB(29, 78, 216), RGB(255, 255, 255)
    End Select
End Sub

Public Function RequireCashAnalysisManualModeFinished(ByVal intendedAction As String) As Boolean
    Dim selectionText As String
    If Not CashAnalysisManualModeActive() Then
        RequireCashAnalysisManualModeFinished = True
        Exit Function
    End If
    If HasCashAnalysisManualSelection() Then
        selectionText = "�I�𒆂̎��������܂��B"
    Else
        selectionText = "���݁A�蓮���̑I�����[�h�ł��B"
    End If
    MsgBox selectionText & vbCrLf & _
           intendedAction & "�̑O�ɁA�m�I����������o�^�n�܂��́m�I�����������n�������Ă��������B" & _
           vbCrLf & "�I����e��ق��Ĕj�����邱�Ƃ͂���܂���B", _
           vbInformation, "�蓮���̑I�����������Ă�������"
End Function

Public Sub PrepareCashAnalysisViewForPrint()
    '����������͍������ȗ����Ȃ��B��������S�\�����Ă���A�}�`�̔����A
    '����͈́AA4���E��1�y�[�W���𒼑O�ɍČ��؂���B
    Dim ws As Worksheet, shp As Shape
    Dim lastR As Long
    Dim printStateKnown As Boolean
    Dim workbookWasSaved As Boolean
    Dim errorNumber As Long, errorDescription As String
    If Not SheetExists(SH_OUTPUT_TX) Then Exit Sub
    On Error GoTo EH
    Set ws = GetSheet(SH_OUTPUT_TX)
    workbookWasSaved = ThisWorkbook.Saved
    ws.Unprotect Password:=TOOL_PASSWORD
    ws.Range(VIEW_STATE_PANEL_EXPANDED).Value = "1"
    AdjustCashAnalysisPanelRowHeights ws
    ApplyCashAnalysisPrintPanelHeights ws
    lastR = CashAnalysisLastDataRow(ws)
    If lastR < CASH_VIEW_HEADER_ROW Then lastR = CASH_VIEW_HEADER_ROW
    ApplyPrintAreaVerified ws, ws.Range("A1:M" & CStr(lastR))
    ApplyReadablePrintSettings ws, "$10:$10"
    For Each shp In ws.Shapes
        If Left$(shp.Name, Len(UI_PREFIX)) = UI_PREFIX Then
            If Not SetToolShapePrintState(ws, shp.Name, False) Then _
                Err.Raise vbObjectError + 4990, "PrepareCashAnalysisViewForPrint", _
                          "��ʑ���p�}�`������ΏۊO�ɂł��܂���: " & shp.Name
            If ToolShapePrintState(ws, shp.Name, printStateKnown) Or Not printStateKnown Then _
                Err.Raise vbObjectError + 4991, "PrepareCashAnalysisViewForPrint", _
                          "��ʑ���p�}�`�̈���ݒ���m�F�ł��܂���: " & shp.Name
        End If
    Next shp
    ProtectCashAnalysisViewSheet
    If workbookWasSaved Then ThisWorkbook.Saved = True
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    On Error Resume Next
    If Not ws Is Nothing Then ProtectCashAnalysisViewSheet
    If workbookWasSaved Then ThisWorkbook.Saved = True
    On Error GoTo 0
    Err.Raise errorNumber, "PrepareCashAnalysisViewForPrint", errorDescription
End Sub

Private Sub ApplyCashAnalysisPrintPanelHeights(ByVal ws As Worksheet)
    'Excel��1�s������ŁA1,000�����̊m�F�����ƒ������͗��R�����ʂ֎c���B
    If ws Is Nothing Then Exit Sub
    ws.Rows(5).RowHeight = CashPanelTextRowHeight(CellText(ws.Range("H5").Value), 90, 31, 409.5)
    ws.Rows(6).RowHeight = CashPanelTextRowHeight(CellText(ws.Range("C6").Value), 150, 38, 409.5)
    ws.Rows(7).RowHeight = CashPanelTextRowHeight(CellText(ws.Range("C7").Value), 150, 38, 409.5)
    ws.Rows(8).RowHeight = CashPanelTextRowHeight(CellText(ws.Range("C8").Value), 150, 42, 409.5)
End Sub

Public Sub ProtectCashAnalysisViewSheet()
    Dim ws As Worksheet, canEdit As Boolean
    Dim lockLastRow As Long
    Dim workbookWasSaved As Boolean
    Dim errorNumber As Long, errorDescription As String
    If Not SheetExists(SH_OUTPUT_TX) Then Exit Sub
    Set ws = GetSheet(SH_OUTPUT_TX)
    workbookWasSaved = ThisWorkbook.Saved
    On Error GoTo EH
    ws.Unprotect Password:=TOOL_PASSWORD
    lockLastRow = Application.Min(ws.Rows.Count, _
                  Application.Max(60, LastUsedRowInSheet(ws) + 20))
    ws.Range("A1:Z" & CStr(lockLastRow)).Locked = True
    RestoreToolSheetScrollArea ws
    canEdit = Not ThisWorkbook.ReadOnly And _
              CellText(ws.Range(VIEW_STATE_MANUAL).Value) <> "1" And _
              Len(CellText(ws.Range(VIEW_STATE_GROUP_ID).Value)) > 0
    If canEdit Then
        ws.Range("C3:D3").Locked = False
        ws.Range("C8:M8").Locked = False
    End If
    '�ʏ�\���E�Z�b�g�A�b�v���́AOffice�r���h���̂���PrintObject������
    'best-effort�ɂ���B�������PrepareCashAnalysisViewForPrint�Ō��i���؂���B
    LockToolShapes ws, False
    ws.Protect Password:=TOOL_PASSWORD, DrawingObjects:=True, Contents:=True, Scenarios:=False, _
               UserInterfaceOnly:=True, AllowFiltering:=True, AllowSorting:=False, _
               AllowFormattingCells:=False, AllowFormattingColumns:=False, AllowFormattingRows:=False
    ws.EnableSelection = xlNoRestrictions
    VerifyToolShapeSecurity ws, True, False
    If workbookWasSaved Then ThisWorkbook.Saved = True
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    EmergencyProtectToolSheet ws
    If workbookWasSaved Then ThisWorkbook.Saved = True
    Err.Raise errorNumber, "ProtectCashAnalysisViewSheet", errorDescription
End Sub

Public Sub SetCashAnalysisViewEditingEnabled(ByVal enabled As Boolean)
    Dim ws As Worksheet
    Dim workbookWasSaved As Boolean
    Dim errorNumber As Long, errorDescription As String
    If Not SheetExists(SH_OUTPUT_TX) Then Exit Sub
    Set ws = GetSheet(SH_OUTPUT_TX)
    workbookWasSaved = ThisWorkbook.Saved
    On Error GoTo EH
    ws.Unprotect Password:=TOOL_PASSWORD
    ws.Range("C3:D3").Locked = Not enabled
    ws.Range("C8:M8").Locked = Not enabled
    ProtectCashAnalysisViewSheet
    If workbookWasSaved Then ThisWorkbook.Saved = True
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    On Error Resume Next
    EmergencyProtectToolSheet ws
    If workbookWasSaved Then ThisWorkbook.Saved = True
    On Error GoTo 0
    Err.Raise errorNumber, "SetCashAnalysisViewEditingEnabled", errorDescription
End Sub

Private Sub SelectFirstVisibleCashAnalysisRow(ByVal ws As Worksheet)
    Dim lastR As Long
    Dim visibleCells As Range
    lastR = CashAnalysisLastDataRow(ws)
    If lastR < CASH_VIEW_FIRST_DATA_ROW Then Exit Sub
    On Error Resume Next
    Set visibleCells = ws.Range(ws.Cells(CASH_VIEW_FIRST_DATA_ROW, 1), _
                                ws.Cells(lastR, 1)).SpecialCells(xlCellTypeVisible)
    On Error GoTo 0
    If Not visibleCells Is Nothing Then _
        SafeSelectCell ws, visibleCells.Cells(1, 1).Address(False, False)
End Sub

Private Function CashAnalysisLastDataRow(ByVal ws As Worksheet) As Long
    Dim lastByTx As Long, lastByDate As Long, lastByTekiyo As Long
    If ws Is Nothing Then Exit Function
    lastByTx = LastRow(ws, OUT_COL_TRANSACTION_ID)
    lastByDate = LastRow(ws, OUT_COL_DATE)
    lastByTekiyo = LastRow(ws, OUT_COL_TEKIYO)
    CashAnalysisLastDataRow = Application.Max(lastByTx, lastByDate, lastByTekiyo)
    If CashAnalysisLastDataRow < CASH_VIEW_FIRST_DATA_ROW Then CashAnalysisLastDataRow = 0
End Function

Private Function CashViewCategoryForResult(ByVal resultCategory As String) As String
    Select Case Trim$(resultCategory)
        Case "�g�r�s��": CashViewCategoryForResult = VIEW_CATEGORY_UNKNOWN_WITHDRAW
        Case "�����s��": CashViewCategoryForResult = VIEW_CATEGORY_UNKNOWN_DEPOSIT
        Case Else: CashViewCategoryForResult = VIEW_CATEGORY_TRANSFER
    End Select
End Function

Private Function IsCashViewCategory(ByVal categoryText As String) As Boolean
    IsCashViewCategory = (categoryText = VIEW_CATEGORY_TRANSFER Or _
                          categoryText = VIEW_CATEGORY_UNKNOWN_WITHDRAW Or _
                          categoryText = VIEW_CATEGORY_UNKNOWN_DEPOSIT)
End Function

Private Function IsCashViewMode(ByVal modeText As String) As Boolean
    IsCashViewMode = (modeText = VIEW_MODE_COMPONENT Or modeText = VIEW_MODE_RELATED Or _
                      modeText = VIEW_MODE_ALL)
End Function

Private Function ConfirmedStatusForCashCategory(ByVal categoryText As String) As String
    Select Case categoryText
        Case VIEW_CATEGORY_UNKNOWN_WITHDRAW
            ConfirmedStatusForCashCategory = ANALYSIS_STATUS_USE_CONFIRMED
        Case VIEW_CATEGORY_UNKNOWN_DEPOSIT
            ConfirmedStatusForCashCategory = ANALYSIS_STATUS_SOURCE_CONFIRMED
        Case Else
            ConfirmedStatusForCashCategory = ANALYSIS_STATUS_SHIFT_CONFIRMED
    End Select
End Function

Private Function IsStatusAllowedForCashCategory(ByVal categoryText As String, _
                                                ByVal statusText As String) As Boolean
    If statusText = ANALYSIS_STATUS_UNREVIEWED Or statusText = ANALYSIS_STATUS_EXCLUDED Or _
       statusText = ANALYSIS_STATUS_FOLLOWUP Then
        IsStatusAllowedForCashCategory = True
        Exit Function
    End If
    IsStatusAllowedForCashCategory = (statusText = ConfirmedStatusForCashCategory(categoryText))
End Function

Private Function CashViewRole(ByVal withdrawal As Double, ByVal deposit As Double) As String
    If withdrawal > 0 And deposit > 0 Then
        CashViewRole = VIEW_ROLE_BOTH
    ElseIf withdrawal > 0 Then
        CashViewRole = VIEW_ROLE_WITHDRAW
    ElseIf deposit > 0 Then
        CashViewRole = VIEW_ROLE_DEPOSIT
    End If
End Function

Private Function CashViewDouble(ByVal value As Variant) As Double
    If IsError(value) Or IsEmpty(value) Or Len(CellText(value)) = 0 Then Exit Function
    If IsNumeric(value) Then CashViewDouble = CDbl(value)
End Function

Private Function CashResultColumnValues(ByVal ws As Worksheet, ByVal firstRow As Long, _
                                        ByVal lastRow As Long, ByVal columnNumber As Long) As Variant
    Dim values As Variant
    If ws Is Nothing Or lastRow < firstRow Then Exit Function
    If lastRow = firstRow Then
        ReDim values(1 To 1, 1 To 1)
        values(1, 1) = ws.Cells(firstRow, columnNumber).Value2
    Else
        values = ws.Range(ws.Cells(firstRow, columnNumber), _
                          ws.Cells(lastRow, columnNumber)).Value2
    End If
    CashResultColumnValues = values
End Function

Private Function IDsToDictionary(ByVal idList As String) As Object
    Dim result As Object, parts As Variant, item As Variant, txID As String
    Set result = CreateObject("Scripting.Dictionary")
    result.CompareMode = vbTextCompare
    idList = Replace(Replace(idList, vbCrLf, ";"), vbLf, ";")
    idList = Replace(idList, ",", ";")
    If Len(Trim$(idList)) > 0 Then
        parts = Split(idList, ";")
        For Each item In parts
            txID = Trim$(CStr(item))
            If Len(txID) > 0 Then result(txID) = True
        Next item
    End If
    Set IDsToDictionary = result
End Function

Private Function JoinCashDictionaryKeys(ByVal values As Object) As String
    Dim item As Variant
    If values Is Nothing Then Exit Function
    For Each item In values.Keys
        If Len(JoinCashDictionaryKeys) > 0 Then JoinCashDictionaryKeys = JoinCashDictionaryKeys & ";"
        JoinCashDictionaryKeys = JoinCashDictionaryKeys & CStr(item)
    Next item
End Function

Private Function IDListContains(ByVal idList As String, ByVal wantedID As String) As Boolean
    Dim normalizedList As String, normalizedID As String
    normalizedID = Trim$(wantedID)
    If Len(normalizedID) = 0 Then Exit Function
    normalizedList = Replace(idList, vbCrLf, ";")
    normalizedList = Replace(normalizedList, vbCr, ";")
    normalizedList = Replace(normalizedList, vbLf, ";")
    normalizedList = Replace(normalizedList, ",", ";")
    normalizedList = Replace(normalizedList, " ", "")
    normalizedList = Replace(normalizedList, vbTab, "")
    normalizedID = Replace(normalizedID, " ", "")
    normalizedID = Replace(normalizedID, vbTab, "")
    normalizedList = ";" & normalizedList & ";"
    IDListContains = (InStr(1, normalizedList, ";" & normalizedID & ";", vbTextCompare) > 0)
End Function

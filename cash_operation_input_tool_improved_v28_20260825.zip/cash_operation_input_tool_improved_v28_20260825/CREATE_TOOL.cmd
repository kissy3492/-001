@echo off
setlocal
powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0CREATE_TOOL.ps1"
set "BUILD_EXIT=%ERRORLEVEL%"
if not "%BUILD_EXIT%"=="0" (
  echo.
  echo Tool creation did not complete. See the .setup_error.txt file and README.md.
  pause
  exit /b 1
)
exit /b 0

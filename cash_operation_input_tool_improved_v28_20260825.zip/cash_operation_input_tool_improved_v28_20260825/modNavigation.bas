Attribute VB_Name = "modNavigation"
Option Explicit

Private mLastHighlightRow As Long
Private mLastEditedRow As Long
Private mLastEditedCol As Long

'��������ԍ��x���́A���͍s���ړ����邽�тɍ�ƃV�[�g�S�̂𑖍�����Əd���Ȃ�B
'���݂̌������{��ƃV�[�g�������L�[�ɃL���b�V�����A������Ԃł͍đ������Ȃ��B
Private mDuplicateCacheKey As String
Private mDuplicateCacheMessage As String

'�I���s�����֐i�ނ��тɐ擪�s������t���Čv�Z����ƁA���ׂ������قǑ��삪�d���Ȃ�B
'�⊮�ς݂̔N�����ƃG���[�L�����s�P�ʂŕێ����A�ҏW�s�ȍ~�������Čv�Z����B
Private mDateCacheYear() As Long
Private mDateCacheMonth() As Long
Private mDateCacheDay() As Long
Private mDateCacheAnyDate() As Boolean
Private mDateCacheAnyInvalid() As Boolean
Private mDateCacheAnyIncomplete() As Boolean
Private mDateCacheValidThrough As Long
Private mDateCacheYearAdd As Long
Private mDateCacheReady As Boolean

Public Sub EnableInputKeys()
    '�ďo�����ݒ��ʂ�G���[�����ł��A���ۂɂ��̃u�b�N�̓��̓V�[�g���L���Ȏ�����
    'Tab/Enter�Ƌt�����L�[�𐧌䂷��B�ق��̃V�[�g�E�u�b�N�ł̓O���[�o����������������B
    On Error Resume Next
    DisableInputKeys
    If ActiveWorkbook Is ThisWorkbook Then
        If ActiveSheet.Name = SH_INPUT Then
            Application.OnKey "{TAB}", MacroRef("InputTabNext")
            Application.OnKey "+{TAB}", MacroRef("InputTabPrev")
            Application.OnKey "~", MacroRef("InputTabNext")
            Application.OnKey "+~", MacroRef("InputTabPrev")
            Application.OnKey "{ENTER}", MacroRef("InputTabNext")
            Application.OnKey "+{ENTER}", MacroRef("InputTabPrev")
            On Error GoTo 0
            Exit Sub
        End If
    End If
    On Error GoTo 0
End Sub

Public Sub DisableInputKeys()
    On Error Resume Next
    Application.OnKey "{TAB}"
    Application.OnKey "+{TAB}"
    Application.OnKey "~"
    Application.OnKey "+~"
    Application.OnKey "{ENTER}"
    Application.OnKey "+{ENTER}"
    On Error GoTo 0
End Sub

Public Sub InvalidateDuplicateAccountWarningCache()
    '�]�L�E�������E�蓮�ҏW�Ȃǂō�ƃV�[�g�̓��e���ς�������ɌĂԁB
    '�Â��u�d���Ȃ��v���肪�c��ƌx���������Ƃ����߁A�����I�ɔj������B
    mDuplicateCacheKey = vbNullString
    mDuplicateCacheMessage = vbNullString
End Sub

Public Sub InvalidateDateComplementCache(Optional ByVal fromSheetRow As Long = TX_FIRST_ROW)
    Dim keepThrough As Long
    If fromSheetRow <= TX_FIRST_ROW Then
        mDateCacheReady = False
        mDateCacheValidThrough = 0
        Exit Sub
    End If
    If Not mDateCacheReady Then Exit Sub
    keepThrough = fromSheetRow - TX_FIRST_ROW
    If keepThrough < mDateCacheValidThrough Then mDateCacheValidThrough = keepThrough
End Sub

Public Sub RestoreInputNavigation()
    '���Ń{�^���E�ً}���̒��ڎ��s�p�B���s�̐ݒ�p�l���ł́A�����E�ی������
    'RestoreToolFormatting�֕����������{�����Ă���B
    Dim errorNumber As Long, errorDescription As String
    On Error GoTo EH
    AppForceRestore True
    Application.EnableEvents = True
    If Not SheetExists(SH_INPUT) Then _
        Err.Raise vbObjectError + 3101, "RestoreInputNavigation", "���̓V�[�g��������܂���B"
    ThisWorkbook.Worksheets(SH_INPUT).Visible = xlSheetVisible
    ThisWorkbook.Worksheets(SH_INPUT).Activate
    ProtectInputSheet True
    EnableInputKeys
    ThisWorkbook.Worksheets(SH_INPUT).Cells(TX_FIRST_ROW, COL_TX_DAY).Select
    MsgBox "Tab�ړ��𕜋����܂����B�ʏ탂�[�h�ł́A�E�v�̎��Ɏ��s�̓��ֈړ����܂��B", vbInformation
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    AppForceRestore
    MsgBox OperationFailureHeading(errorNumber, "Tab�ړ��𕜋��ł��܂���ł����B") & vbCrLf & _
           OperationFailureDetail(errorNumber, errorDescription), OperationFailureIcon(errorNumber, vbExclamation)
End Sub

Public Sub InputTabNext()
    MoveInputCell False
End Sub

Public Sub InputTabPrev()
    MoveInputCell True
End Sub

Public Sub MoveInputCell(ByVal backwards As Boolean)
    Dim ws As Worksheet
    Dim nextCell As Range
    On Error GoTo Fallback
    If ActiveSheet Is Nothing Then GoTo Fallback
    If ActiveSheet.Name <> SH_INPUT Then GoTo Fallback
    Set ws = ActiveSheet
    '�s���l�ł��ړ��͎~�߂Ȃ��B�~�߂�Ɨ��p�҂ɂ͌ł܂����悤�ɂ����������A
    '��ԗ��̈ē��ɂ��C�t���Ȃ��B���͏�ԗ��Ŏw�E���A�o�^���Ɋm���Ɏ~�߂�B
    NoteAmountEntryProblem ActiveCell
    Set nextCell = GetNextInputCell(ws, ActiveCell, backwards)
    If Not nextCell Is Nothing Then
        Application.Goto nextCell, False
        Exit Sub
    End If
Fallback:
    On Error Resume Next
    If backwards Then ActiveCell.Offset(0, -1).Select Else ActiveCell.Offset(0, 1).Select
    On Error GoTo 0
End Sub

Public Function GetNextInputCell(ByVal ws As Worksheet, ByVal cur As Range, ByVal backwards As Boolean) As Range
    Dim r As Long, c As Long, memoCol As Long
    If ws Is Nothing Or cur Is Nothing Then Exit Function
    r = cur.Row: c = cur.Column
    memoCol = BalanceMemoCol(ws)
    If IsAccountCell(cur) Then
        Set GetNextInputCell = NextAccountCell(ws, cur, backwards)
        Exit Function
    End If
    If r = BAL_VALUE_ROW And c >= BAL_FIRST_COL And c <= memoCol Then
        Set GetNextInputCell = NextBalanceCell(ws, cur, backwards, memoCol)
        Exit Function
    End If
    If r >= TX_FIRST_ROW And r <= TX_LAST_ROW And c >= COL_TX_YEAR And c <= COL_TX_OTHER Then
        Set GetNextInputCell = NextTransactionCell(ws, cur, backwards)
        Exit Function
    End If
    Set GetNextInputCell = ws.Range(CELL_BANK)
End Function

Private Function IsAccountCell(ByVal cur As Range) As Boolean
    Dim a As String
    If cur Is Nothing Then Exit Function
    a = cur.Address(False, False)
    IsAccountCell = (a = CELL_BANK Or a = CELL_BRANCH Or a = CELL_PERSON Or _
                     (UseRelationshipDisplay() And a = CELL_RELATIONSHIP) Or _
                     a = CELL_ACCOUNT_TYPE Or a = CELL_ACCOUNT_NO Or a = CELL_OPEN_DATE Or a = CELL_CLOSE_DATE)
End Function

Private Function NextAccountCell(ByVal ws As Worksheet, ByVal cur As Range, ByVal backwards As Boolean) As Range
    Dim arr As Variant, i As Long
    If UseRelationshipDisplay() Then
        arr = Array(CELL_BANK, CELL_BRANCH, CELL_PERSON, CELL_ACCOUNT_TYPE, CELL_ACCOUNT_NO, CELL_RELATIONSHIP, CELL_OPEN_DATE, CELL_CLOSE_DATE)
    Else
        arr = Array(CELL_BANK, CELL_BRANCH, CELL_PERSON, CELL_ACCOUNT_TYPE, CELL_ACCOUNT_NO, CELL_OPEN_DATE, CELL_CLOSE_DATE)
    End If
    For i = LBound(arr) To UBound(arr)
        If cur.Address(False, False) = CStr(arr(i)) Then
            If backwards Then
                If i = LBound(arr) Then Set NextAccountCell = ws.Range(CELL_BANK) Else Set NextAccountCell = ws.Range(CStr(arr(i - 1)))
            Else
                If i = UBound(arr) Then
                    Set NextAccountCell = FirstAvailableBalanceInputCell(ws)
                Else
                    Set NextAccountCell = ws.Range(CStr(arr(i + 1)))
                End If
            End If
            Exit Function
        End If
    Next i
    Set NextAccountCell = ws.Range(CELL_BANK)
End Function

Private Function NextBalanceCell(ByVal ws As Worksheet, ByVal cur As Range, ByVal backwards As Boolean, ByVal memoCol As Long) As Range
    '�J�ݓ��O�E������Ń��b�N���ꂽ�c�����́ATab�ړ��ł���΂��B
    '�c�����̌�́A�c�����̓G���A�����̃������֐i�ށB
    If cur Is Nothing Then Exit Function
    If backwards Then
        Set NextBalanceCell = NextAvailableBalanceInputCell(ws, cur.Column, True)
    Else
        Set NextBalanceCell = NextAvailableBalanceInputCell(ws, cur.Column, False)
    End If
End Function

Private Function NextTransactionCell(ByVal ws As Worksheet, ByVal cur As Range, ByVal backwards As Boolean) As Range
    Dim cols As Variant, idx As Long, i As Long, targetCol As Long
    cols = TransactionRoute(GetInputMode())

    '�y�N�E���̍l�����z
    '2�s�ڈȍ~�̘A�����͂ł́u���v���痬���B����A�N�ւ�肾���͑f����������悤�A
    '���Z���� Shift+Tab �����ꍇ�͌��ł͂Ȃ��N�֒��ږ߂��B���Z���̓N���b�N�E���L�[�ł͕ҏW�\�B
    If cur.Column = COL_TX_YEAR And Not backwards Then Set NextTransactionCell = ws.Cells(cur.Row, COL_TX_MONTH): Exit Function
    If cur.Column = COL_TX_MONTH And Not backwards Then Set NextTransactionCell = ws.Cells(cur.Row, COL_TX_DAY): Exit Function
    If cur.Column = COL_TX_DAY And backwards Then Set NextTransactionCell = ws.Cells(cur.Row, COL_TX_YEAR): Exit Function
    If cur.Column = COL_TX_MONTH And backwards Then Set NextTransactionCell = ws.Cells(cur.Row, COL_TX_YEAR): Exit Function
    If cur.Column = COL_TX_YEAR And backwards Then
        If cur.Row <= TX_FIRST_ROW Then
            Set NextTransactionCell = ws.Cells(cur.Row, COL_TX_YEAR)
        Else
            Set NextTransactionCell = ws.Cells(cur.Row - 1, CLng(cols(UBound(cols))))
        End If
        Exit Function
    End If

    '�����c����͒ʏ탂�[�h�ł�Tab���[�g����O���A��p���[�h�������ʂ��B
    If cur.Column = COL_TX_OTHER Then
        If backwards Then
            Set NextTransactionCell = ws.Cells(cur.Row, COL_TX_TEKIYO)
        ElseIf cur.Row < TX_LAST_ROW Then
            Set NextTransactionCell = ws.Cells(cur.Row + 1, COL_TX_DAY)
        Else
            Set NextTransactionCell = ws.Cells(TX_LAST_ROW, COL_TX_OTHER)
        End If
        Exit Function
    End If

    idx = -1
    For i = LBound(cols) To UBound(cols)
        If CLng(cols(i)) = cur.Column Then idx = i: Exit For
    Next i
    If idx = -1 Then Set NextTransactionCell = ws.Cells(cur.Row, COL_TX_DAY): Exit Function
    If backwards Then
        If idx = LBound(cols) Then
            If cur.Row <= TX_FIRST_ROW Then Set NextTransactionCell = ws.Cells(TX_FIRST_ROW, COL_TX_DAY) Else Set NextTransactionCell = ws.Cells(cur.Row - 1, CLng(cols(UBound(cols))))
        Else
            Set NextTransactionCell = ws.Cells(cur.Row, CLng(cols(idx - 1)))
        End If
    Else
        If cur.Column = COL_TX_WITHDRAW And HasText(cur.Value) Then
            targetCol = RouteColumnAfter(cols, COL_TX_DEPOSIT)
            Set NextTransactionCell = ws.Cells(cur.Row, targetCol)
            Exit Function
        End If
        If idx = UBound(cols) Then
            If cur.Row >= TX_LAST_ROW Then Set NextTransactionCell = ws.Cells(TX_LAST_ROW, CLng(cols(idx))) Else Set NextTransactionCell = ws.Cells(cur.Row + 1, COL_TX_DAY)
        Else
            Set NextTransactionCell = ws.Cells(cur.Row, CLng(cols(idx + 1)))
        End If
    End If
End Function

Private Function TransactionRoute(ByVal modeText As String) As Variant
    If modeText = MODE_SIMPLE Then
        TransactionRoute = Array(COL_TX_DAY, COL_TX_WITHDRAW, COL_TX_DEPOSIT, COL_TX_SHOP)
    ElseIf modeText = MODE_NO_TIME Then
        TransactionRoute = Array(COL_TX_DAY, COL_TX_WITHDRAW, COL_TX_DEPOSIT, COL_TX_SHOP, COL_TX_MACHINE, COL_TX_TEKIYO)
    ElseIf modeText = MODE_NO_MACHINE Then
        TransactionRoute = Array(COL_TX_DAY, COL_TX_TIME, COL_TX_WITHDRAW, COL_TX_DEPOSIT, COL_TX_SHOP, COL_TX_TEKIYO)
    ElseIf modeText = MODE_NO_TEKIYO Then
        TransactionRoute = Array(COL_TX_DAY, COL_TX_TIME, COL_TX_WITHDRAW, COL_TX_DEPOSIT, COL_TX_SHOP, COL_TX_MACHINE)
    ElseIf modeText = MODE_WITH_OTHER Or modeText = "���̑�����" Then
        TransactionRoute = Array(COL_TX_DAY, COL_TX_TIME, COL_TX_WITHDRAW, COL_TX_DEPOSIT, COL_TX_SHOP, COL_TX_MACHINE, COL_TX_TEKIYO, COL_TX_OTHER)
    Else
        TransactionRoute = Array(COL_TX_DAY, COL_TX_TIME, COL_TX_WITHDRAW, COL_TX_DEPOSIT, COL_TX_SHOP, COL_TX_MACHINE, COL_TX_TEKIYO)
    End If
End Function

Private Function RouteColumnAfter(ByVal cols As Variant, ByVal afterCol As Long) As Long
    Dim i As Long
    For i = LBound(cols) To UBound(cols) - 1
        If CLng(cols(i)) = afterCol Then RouteColumnAfter = CLng(cols(i + 1)): Exit Function
    Next i
    RouteColumnAfter = COL_TX_SHOP
End Function

Public Sub OnInputSelectionChange(ByVal Target As Range)
    Dim t As Range
    Dim workbookWasSaved As Boolean
    Dim errorNumber As Long, errorDescription As String
    On Error GoTo EH
    If Target Is Nothing Then Exit Sub
    Set t = Target
    If t.Cells.CountLarge > 1 Then
        If t.MergeCells Then
            Set t = t.MergeArea.Cells(1, 1)
        Else
            Exit Sub
        End If
    End If
    workbookWasSaved = ThisWorkbook.Saved
    '�����c����͒ʏ�Tab���[�g�O�����A�N���b�N�E���L�[�ł͕ҏW�ł���B
    '�����Ŏ����ޔ�������ƁA���͒��̃����������Ȃ��Ȃ�B
    UpdateCurrentRowHighlight t
    If Not ShowPendingInputErrorIfAny(t.Worksheet) Then UpdateComplementStatus t
    If workbookWasSaved Then ThisWorkbook.Saved = True
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    On Error Resume Next
    If workbookWasSaved Then ThisWorkbook.Saved = True
    On Error GoTo 0
    Err.Raise errorNumber, "OnInputSelectionChange", errorDescription
End Sub

Public Sub OnInputChange(ByVal Target As Range)
    Dim t As Range, firstInvalidDate As Range
    Dim previousEvents As Boolean
    Dim accountDateOK As Boolean
    Dim invalidDateCount As Long
    Dim accountDateOrderInvalid As Boolean
    Dim errorNumber As Long, errorDescription As String
    If Target Is Nothing Then Exit Sub
    Set t = Target
    If t.Cells.CountLarge > 1 Then
        If t.MergeCells Then
            Set t = t.MergeArea.Cells(1, 1)
        Else
            HandleMultiCellInputChange t
            Exit Sub
        End If
    End If
    If t.Worksheet.Name <> SH_INPUT Then Exit Sub

    '���ւ̊w�K�͓o�^�����������s���B���͓r���̌뎚�����Ɏc���Ȃ��B
    If t.Address(False, False) = CELL_BANK Or t.Address(False, False) = CELL_BRANCH Or t.Address(False, False) = CELL_PERSON Or t.Address(False, False) = CELL_RELATIONSHIP Then
        If t.Address(False, False) = CELL_PERSON Then FillRelationshipFromPerson t.Worksheet
        If Not UpdateDuplicateAccountStatus(t.Worksheet) Then UpdateComplementStatus t
        Exit Sub
    End If

    If t.Address(False, False) = CELL_ACCOUNT_TYPE Or t.Address(False, False) = CELL_ACCOUNT_NO Then
        If Not UpdateDuplicateAccountStatus(t.Worksheet) Then UpdateComplementStatus t
        Exit Sub
    End If

    If t.Address(False, False) = CELL_OPEN_DATE Or t.Address(False, False) = CELL_CLOSE_DATE Then
        '�J�ݓ��E�����́A�a������͂����̏�� yyyy/m/d �\���֐����A�c�����̓��͉ۂ��X�V����B
        mLastEditedRow = t.Row
        mLastEditedCol = t.Column
        previousEvents = Application.EnableEvents
        On Error GoTo AccountDateEH
        Application.EnableEvents = False
        accountDateOK = NormalizeAccountDatePair(t.Worksheet, firstInvalidDate, _
                                                  invalidDateCount, accountDateOrderInvalid)
        Application.EnableEvents = previousEvents
        If Not accountDateOK Then
            If accountDateOrderInvalid Then
                SetInputStatus "�����͊J�ݓ��ȍ~�ɂ��Ă��������B", True
            Else
                SetInputStatus firstInvalidDate.Address(False, False) & _
                               " �̓��t�����߂ł��܂���B����܂��͌����R�[�h�̓��t���m�F���Ă��������B", True
            End If
            Exit Sub
        End If
        t.Worksheet.Unprotect Password:=TOOL_PASSWORD
        ApplyBalanceAvailability t.Worksheet
        ProtectInputSheet True
        If Not UpdateDuplicateAccountStatus(t.Worksheet) Then UpdateComplementStatus t
        Exit Sub
    End If

    If t.Row = BAL_VALUE_ROW And t.Column >= BAL_FIRST_COL And _
       t.Column < BalanceMemoCol(t.Worksheet) Then
        mLastEditedRow = t.Row
        mLastEditedCol = t.Column
        If Not NormalizeTransactionAmountEntry(t) Then
            SetInputStatus t.Address(False, False) & ": " & _
                           AmountInputProblemText(t.Value), True
            Exit Sub
        End If
        UpdateComplementStatus t
        Exit Sub
    End If

    If t.Row < TX_FIRST_ROW Or t.Row > TX_LAST_ROW Then Exit Sub

    mLastEditedRow = t.Row
    mLastEditedCol = t.Column
    InvalidateDateComplementCache t.Row

    If t.Column >= COL_TX_YEAR And t.Column <= COL_TX_DAY Then
        If TransactionDateRowHasUnsupportedValue(t.Worksheet, t.Row, firstInvalidDate) Then
            SetInputStatus firstInvalidDate.Address(False, False) & _
                           " �̓��t���ɂ͐����EExcel�G���[����͂ł��܂���B", True
            Exit Sub
        End If
        UpdateComplementStatus t
        Exit Sub
    End If

    If t.Column = COL_TX_TIME Then
        If Not NormalizeTransactionTimeEntry(t) Then
            SetInputStatus CStr(t.Row) & "�s�ڂ̎��������߂ł��܂���B00:00�`23:59�œ��͂��Ă��������B", True
            Exit Sub
        End If
        UpdateComplementStatus t
        Exit Sub
    End If

    If t.Column = COL_TX_WITHDRAW Or t.Column = COL_TX_DEPOSIT Or _
       t.Column = COL_TX_BALANCE Then
        If Not NormalizeTransactionAmountEntry(t) Then
            SetInputStatus CStr(t.Row) & "�s�� " & t.Address(False, False) & ": " & _
                           AmountInputProblemText(t.Value), True
            Exit Sub
        End If
    End If
    UpdateComplementStatus t
    Exit Sub
AccountDateEH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    On Error Resume Next
    Application.EnableEvents = previousEvents
    ProtectInputSheet True
    On Error GoTo 0
    Err.Raise errorNumber, "OnInputChange/�������t", errorDescription
End Sub

Public Sub OnConfigChange(ByVal Target As Range)
    Dim watched As Range, watchedAnalysis As Range, watchedEra As Range
    Dim errorNumber As Long, errorDescription As String
    If Target Is Nothing Then Exit Sub
    If Target.Worksheet.Name <> SH_CONFIG Then Exit Sub
    Set watched = Intersect(Target, Union( _
        Target.Worksheet.Range("C4:C17"), _
        Target.Worksheet.Range( _
            Target.Worksheet.Cells(ROW_CFG_ANALYSIS_MIN_AMOUNT, COL_CFG_ANALYSIS_VALUE), _
            Target.Worksheet.Cells(ROW_CFG_ANALYSIS_UNKNOWN_MIN, COL_CFG_ANALYSIS_VALUE)), _
        Target.Worksheet.Range( _
            Target.Worksheet.Cells(ERA_MASTER_FIRST_ROW, ERA_COL_CODE), _
            Target.Worksheet.Cells(ERA_MASTER_MAX_ROW, ERA_COL_ENABLED))))
    If watched Is Nothing Then Exit Sub
    On Error GoTo EH
    MarkOutputsDirty
    If Not Intersect(watched, Union( _
        Target.Worksheet.Cells(ROW_CFG_INHERITANCE_DATE, COL_CFG_VALUE), _
        Target.Worksheet.Cells(ROW_CFG_BAL_START_YEAR, COL_CFG_VALUE), _
        Target.Worksheet.Cells(ROW_CFG_BAL_END_YEAR, COL_CFG_VALUE), _
        Target.Worksheet.Cells(ROW_CFG_YEAR_ADD, COL_CFG_VALUE), _
        Target.Worksheet.Cells(ROW_CFG_YEAR_MODE, COL_CFG_VALUE))) Is Nothing Then _
        InvalidateDateComplementCache
    If Not Intersect(watched, Target.Worksheet.Cells(ROW_CFG_RELATIONSHIP, COL_CFG_VALUE)) Is Nothing Then _
        ApplyRelationshipSettingToInput True
    If Not Intersect(watched, Target.Worksheet.Cells(ROW_CFG_INHERITANCE_DATE, COL_CFG_VALUE)) Is Nothing Then
        If IsDate(GetCfgDateValue(ROW_CFG_INHERITANCE_DATE)) Then
            Target.Worksheet.Cells(ROW_CFG_INHERITANCE_DATE, COL_CFG_VALUE).Interior.Color = RGB(220, 252, 231)
        Else
            Target.Worksheet.Cells(ROW_CFG_INHERITANCE_DATE, COL_CFG_VALUE).Interior.Color = RGB(254, 249, 195)
        End If
    End If
    Set watchedAnalysis = Intersect(watched, Target.Worksheet.Range( _
        Target.Worksheet.Cells(ROW_CFG_ANALYSIS_MIN_AMOUNT, COL_CFG_ANALYSIS_VALUE), _
        Target.Worksheet.Cells(ROW_CFG_ANALYSIS_UNKNOWN_MIN, COL_CFG_ANALYSIS_VALUE)))
    Set watchedEra = Intersect(watched, Target.Worksheet.Range( _
        Target.Worksheet.Cells(ERA_MASTER_FIRST_ROW, ERA_COL_CODE), _
        Target.Worksheet.Cells(ERA_MASTER_MAX_ROW, ERA_COL_ENABLED)))
    If Not watchedEra Is Nothing Then
        InvalidateDateComplementCache
        SetInputStatus "�����}�X�^��ύX���܂����B�Z���t�`�F�b�N�ŊJ�n���E�I�������m�F���Ă��������B"
    ElseIf Not watchedAnalysis Is Nothing Then
        SetInputStatus "���͏�����ύX���܂����B�w���[�E���͂��X�V�x�Ō����Ē��o���Ă��������B"
    ElseIf Not Intersect(watched, Target.Worksheet.Range("C4:C6")) Is Nothing Then
        SetInputStatus "�c����̐ݒ��ύX���܂����B���͑O�ɐݒ��ʂ́u�c�������Đ����v�����s���Ă��������B"
    Else
        SetInputStatus "�ݒ��ύX���܂����B�ŏI�o�͎��ɒ��[���ŐV�����܂��B"
    End If
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    Err.Raise errorNumber, "OnConfigChange", errorDescription
End Sub

Private Sub HandleMultiCellInputChange(ByVal Target As Range)
    '�����s�\��t�������ۂ����A�����Ƌ��z���ꊇ�Ő��K������B
    '���X�V�E�Z���ړ��E���b�Z�[�W�{�b�N�X�͍s��Ȃ����߁A��ʓ\��t���ł��y���B
    Dim ws As Worksheet
    Dim rng As Range, cell As Range, area As Range, changedRowDate As Range
    Dim firstInvalid As Range, firstInvalidDate As Range, unsupportedDateCell As Range
    Dim dateRows As Object
    Dim memoCol As Long, invalidAmountCount As Long, invalidDateCount As Long
    Dim accountInvalidDateCount As Long
    Dim invalidTimeCount As Long, rowNo As Long, dateIndex As Long
    Dim minChangedRow As Long, minDateRow As Long, maxDateRow As Long
    Dim problemSummary As String
    Dim protectionChanged As Boolean, accountDateOrderInvalid As Boolean
    Dim previousEvents As Boolean
    Dim errorNumber As Long, errorDescription As String
    If Target Is Nothing Then Exit Sub
    Set ws = Target.Worksheet
    If ws.Name <> SH_INPUT Then Exit Sub
    Set rng = Intersect(Target, ws.Range(ws.Cells(TX_FIRST_ROW, COL_TX_YEAR), _
                                         ws.Cells(TX_LAST_ROW, COL_TX_OTHER)))
    If Not rng Is Nothing Then
        minChangedRow = TX_LAST_ROW
        For Each area In rng.Areas
            If area.Row < minChangedRow Then minChangedRow = area.Row
        Next area
        InvalidateDateComplementCache minChangedRow
    End If
    previousEvents = Application.EnableEvents
    On Error GoTo CleanUp
    Application.EnableEvents = False

    Set rng = Intersect(Target, ws.Range(ws.Cells(TX_FIRST_ROW, COL_TX_YEAR), _
                                         ws.Cells(TX_LAST_ROW, COL_TX_DAY)))
    If Not rng Is Nothing Then
        Set dateRows = CreateObject("Scripting.Dictionary")
        minDateRow = TX_LAST_ROW
        For Each area In rng.Areas
            For rowNo = area.Row To area.Row + area.Rows.Count - 1
                If Not dateRows.Exists(CStr(rowNo)) Then dateRows.Add CStr(rowNo), True
                If rowNo < minDateRow Then minDateRow = rowNo
                If rowNo > maxDateRow Then maxDateRow = rowNo
            Next rowNo
        Next area
        EnsureDateComplementCache ws, maxDateRow
        For rowNo = minDateRow To maxDateRow
            If dateRows.Exists(CStr(rowNo)) Then
                dateIndex = rowNo - TX_FIRST_ROW + 1
                Set unsupportedDateCell = Nothing
                If TransactionDateRowHasUnsupportedValue(ws, rowNo, unsupportedDateCell) Or _
                   mDateCacheAnyInvalid(dateIndex) Then
                    invalidDateCount = invalidDateCount + 1
                    If firstInvalid Is Nothing Then
                        If Not unsupportedDateCell Is Nothing Then
                            Set firstInvalid = unsupportedDateCell
                        Else
                            Set changedRowDate = Intersect(rng, ws.Range(ws.Cells(rowNo, COL_TX_YEAR), _
                                                                         ws.Cells(rowNo, COL_TX_DAY)))
                            Set firstInvalid = changedRowDate.Cells(1, 1)
                        End If
                    End If
                End If
            End If
        Next rowNo
    End If
    Set rng = Intersect(Target, ws.Range(ws.Cells(TX_FIRST_ROW, COL_TX_TIME), ws.Cells(TX_LAST_ROW, COL_TX_TIME)))
    If Not rng Is Nothing Then
        For Each cell In rng.Cells
            If Not NormalizeTransactionTimeEntry(cell) Then
                invalidTimeCount = invalidTimeCount + 1
                If firstInvalid Is Nothing Then Set firstInvalid = cell
            End If
        Next cell
    End If
    Set rng = Intersect(Target, Union( _
        ws.Range(ws.Cells(TX_FIRST_ROW, COL_TX_WITHDRAW), ws.Cells(TX_LAST_ROW, COL_TX_DEPOSIT)), _
        ws.Range(ws.Cells(TX_FIRST_ROW, COL_TX_BALANCE), ws.Cells(TX_LAST_ROW, COL_TX_BALANCE))))
    If Not rng Is Nothing Then
        For Each cell In rng.Cells
            If Not NormalizeTransactionAmountEntry(cell) Then
                invalidAmountCount = invalidAmountCount + 1
                If firstInvalid Is Nothing Then Set firstInvalid = cell
            End If
        Next cell
    End If
    memoCol = BalanceMemoCol(ws)
    If memoCol > BAL_FIRST_COL Then
        Set rng = Intersect(Target, ws.Range(ws.Cells(BAL_VALUE_ROW, BAL_FIRST_COL), _
                                             ws.Cells(BAL_VALUE_ROW, memoCol - 1)))
        If Not rng Is Nothing Then
            For Each cell In rng.Cells
                If Not NormalizeTransactionAmountEntry(cell) Then
                    invalidAmountCount = invalidAmountCount + 1
                    If firstInvalid Is Nothing Then Set firstInvalid = cell
                End If
            Next cell
        End If
    End If
    Set rng = Intersect(Target, Union(ws.Range(CELL_OPEN_DATE), ws.Range(CELL_CLOSE_DATE)))
    If Not rng Is Nothing Then
        Call NormalizeAccountDatePair(ws, firstInvalidDate, accountInvalidDateCount, accountDateOrderInvalid)
        If accountInvalidDateCount > 0 And firstInvalid Is Nothing Then Set firstInvalid = firstInvalidDate
        invalidDateCount = invalidDateCount + accountInvalidDateCount
        If accountInvalidDateCount = 0 Then
            ws.Unprotect Password:=TOOL_PASSWORD
            protectionChanged = True
            ApplyBalanceAvailability ws
            ProtectInputSheet True
            protectionChanged = False
        End If
    End If
CleanUp:
    errorNumber = Err.Number
    errorDescription = Err.Description
    On Error Resume Next
    If protectionChanged Then ProtectInputSheet True
    Application.EnableEvents = previousEvents
    If errorNumber = 0 And Err.Number <> 0 Then
        errorNumber = Err.Number
        errorDescription = Err.Description
    End If
    On Error GoTo 0
    If errorNumber <> 0 Then Err.Raise errorNumber, "HandleMultiCellInputChange", errorDescription
    If invalidDateCount > 0 Or invalidTimeCount > 0 Or invalidAmountCount > 0 Then
        mLastEditedRow = firstInvalid.Row
        mLastEditedCol = firstInvalid.Column
        If invalidDateCount > 0 Then problemSummary = "���t " & CStr(invalidDateCount) & "��"
        If invalidTimeCount > 0 Then
            If Len(problemSummary) > 0 Then problemSummary = problemSummary & "�A"
            problemSummary = problemSummary & "���� " & CStr(invalidTimeCount) & "��"
        End If
        If invalidAmountCount > 0 Then
            If Len(problemSummary) > 0 Then problemSummary = problemSummary & "�A"
            problemSummary = problemSummary & "���z " & CStr(invalidAmountCount) & "��"
        End If
        SetInputStatus "�\��t�����l�ɉ��ߕs�\�܂��͓��t�t�]������܂��i" & problemSummary & _
                       "�j�B�擪: " & firstInvalid.Address(False, False), True
        Exit Sub
    End If
    If Not UpdateDuplicateAccountStatus(ws) Then UpdateComplementStatus Target.Cells(1, 1)
End Sub

Private Function NormalizeAccountDatePair(ByVal ws As Worksheet, _
                                          ByRef firstInvalid As Range, _
                                          ByRef invalidCount As Long, _
                                          ByRef orderInvalid As Boolean) As Boolean
    '�Е������𒼂����Ƃ��ɁA�����Е��̕s���l�������Ƃ��ėΕ\���֖߂��Ȃ��B
    Dim cell As Range
    invalidCount = 0
    orderInvalid = False
    Set firstInvalid = Nothing
    If ws Is Nothing Then Exit Function

    For Each cell In Union(ws.Range(CELL_OPEN_DATE), ws.Range(CELL_CLOSE_DATE)).Cells
        If Not NormalizeAccountDateEntry(cell) Then
            invalidCount = invalidCount + 1
            If firstInvalid Is Nothing Then Set firstInvalid = cell
        End If
    Next cell
    If invalidCount > 0 Then Exit Function

    If IsDate(ws.Range(CELL_OPEN_DATE).Value) And IsDate(ws.Range(CELL_CLOSE_DATE).Value) Then
        If CDate(ws.Range(CELL_OPEN_DATE).Value) > CDate(ws.Range(CELL_CLOSE_DATE).Value) Then
            invalidCount = 1
            orderInvalid = True
            Set firstInvalid = ws.Range(CELL_CLOSE_DATE)
            Exit Function
        End If
    End If
    NormalizeAccountDatePair = True
End Function

Private Function ShowPendingInputErrorIfAny(ByVal ws As Worksheet) As Boolean
    '�N���b�N����ړ������ŁA�����Ă��Ȃ����̓G���[�̐Ԃ��ē��������Ȃ��B
    Dim editedCell As Range, firstInvalidDate As Range
    Dim invalidDateCount As Long
    Dim orderInvalid As Boolean
    If ws Is Nothing Then Exit Function
    If mLastEditedRow < 1 Or mLastEditedCol < 1 Then Exit Function
    If mLastEditedRow > ws.Rows.Count Or mLastEditedCol > ws.Columns.Count Then Exit Function
    Set editedCell = ws.Cells(mLastEditedRow, mLastEditedCol)

    If editedCell.Address(False, False) = CELL_OPEN_DATE Or _
       editedCell.Address(False, False) = CELL_CLOSE_DATE Then
        If AccountDatePairHasProblem(ws, firstInvalidDate, invalidDateCount, orderInvalid) Then
            If orderInvalid Then
                SetInputStatus "�����͊J�ݓ��ȍ~�ɂ��Ă��������B", True
            Else
                SetInputStatus firstInvalidDate.Address(False, False) & _
                               " �̓��t�����߂ł��܂���B�C�����Ă��������B", True
            End If
            ShowPendingInputErrorIfAny = True
        End If
        Exit Function
    End If

    If editedCell.Row >= TX_FIRST_ROW And editedCell.Row <= TX_LAST_ROW Then
        If editedCell.Column >= COL_TX_YEAR And editedCell.Column <= COL_TX_DAY Then
            If TransactionDateRowHasUnsupportedValue(ws, editedCell.Row, firstInvalidDate) Then
                SetInputStatus firstInvalidDate.Address(False, False) & _
                               " �̓��t���ɂ͐����EExcel�G���[����͂ł��܂���B", True
                ShowPendingInputErrorIfAny = True
                Exit Function
            End If
            EnsureDateComplementCache ws, editedCell.Row
            If mDateCacheAnyInvalid(editedCell.Row - TX_FIRST_ROW + 1) Then
                SetInputStatus CStr(editedCell.Row) & "�s�ڂ̓��t�����߂ł��܂���B�C�����Ă��������B", True
                ShowPendingInputErrorIfAny = True
            End If
            Exit Function
        End If
        If editedCell.Column = COL_TX_TIME Then
            If Not TimeEntryIsValidWithoutChange(editedCell) Then
                SetInputStatus CStr(editedCell.Row) & "�s�ڂ̎��������߂ł��܂���B�C�����Ă��������B", True
                ShowPendingInputErrorIfAny = True
            End If
            Exit Function
        End If
    End If

    If IsAmountInputCell(editedCell) Then
        If Not AmountEntryIsValidWithoutChange(editedCell) Then
            SetInputStatus editedCell.Address(False, False) & ": " & _
                           AmountInputProblemText(editedCell.Value), True
            ShowPendingInputErrorIfAny = True
        End If
    End If
End Function

Private Function TransactionDateRowHasUnsupportedValue(ByVal ws As Worksheet, _
                                                       ByVal rowNo As Long, _
                                                       ByRef firstInvalid As Range) As Boolean
    Dim cell As Range
    Set firstInvalid = Nothing
    If ws Is Nothing Then Exit Function
    If rowNo < TX_FIRST_ROW Or rowNo > TX_LAST_ROW Then Exit Function
    For Each cell In ws.Range(ws.Cells(rowNo, COL_TX_YEAR), ws.Cells(rowNo, COL_TX_DAY)).Cells
        If cell.HasFormula Or IsError(cell.Value) Then
            Set firstInvalid = cell
            TransactionDateRowHasUnsupportedValue = True
            Exit Function
        End If
    Next cell
End Function

Private Function AccountDatePairHasProblem(ByVal ws As Worksheet, _
                                           ByRef firstInvalid As Range, _
                                           ByRef invalidCount As Long, _
                                           ByRef orderInvalid As Boolean) As Boolean
    Dim cell As Range
    Dim ok As Boolean
    Dim resolved As Variant
    Dim openDate As Variant, closeDate As Variant
    invalidCount = 0
    orderInvalid = False
    Set firstInvalid = Nothing
    If ws Is Nothing Then Exit Function

    For Each cell In Union(ws.Range(CELL_OPEN_DATE), ws.Range(CELL_CLOSE_DATE)).Cells
        ok = False
        If Not cell.HasFormula And Not IsError(cell.Value) Then
            resolved = ResolveAccountDateInput(cell.Value, ok)
        End If
        If Not ok Then
            invalidCount = invalidCount + 1
            If firstInvalid Is Nothing Then Set firstInvalid = cell
        ElseIf cell.Address(False, False) = CELL_OPEN_DATE Then
            openDate = resolved
        Else
            closeDate = resolved
        End If
    Next cell
    If invalidCount > 0 Then
        AccountDatePairHasProblem = True
        Exit Function
    End If
    If IsDate(openDate) And IsDate(closeDate) Then
        If CDate(openDate) > CDate(closeDate) Then
            invalidCount = 1
            orderInvalid = True
            Set firstInvalid = ws.Range(CELL_CLOSE_DATE)
            AccountDatePairHasProblem = True
        End If
    End If
End Function

Private Function IsAmountInputCell(ByVal targetCell As Range) As Boolean
    Dim memoCol As Long
    If targetCell Is Nothing Then Exit Function
    If targetCell.Row >= TX_FIRST_ROW And targetCell.Row <= TX_LAST_ROW Then
        IsAmountInputCell = (targetCell.Column = COL_TX_WITHDRAW Or _
                             targetCell.Column = COL_TX_DEPOSIT Or _
                             targetCell.Column = COL_TX_BALANCE)
        Exit Function
    End If
    If targetCell.Row <> BAL_VALUE_ROW Then Exit Function
    memoCol = BalanceMemoCol(targetCell.Worksheet)
    IsAmountInputCell = (targetCell.Column >= BAL_FIRST_COL And targetCell.Column < memoCol)
End Function

Private Function AmountEntryIsValidWithoutChange(ByVal targetCell As Range) As Boolean
    Dim normalized As Variant
    Dim ok As Boolean
    If targetCell Is Nothing Then Exit Function
    If targetCell.HasFormula Then Exit Function
    If IsError(targetCell.Value) Then Exit Function
    If Not HasText(targetCell.Value) Then
        AmountEntryIsValidWithoutChange = True
        Exit Function
    End If
    normalized = TryParseAmount(targetCell.Value, ok)
    AmountEntryIsValidWithoutChange = (ok And HasText(normalized))
End Function

Private Function TimeEntryIsValidWithoutChange(ByVal targetCell As Range) As Boolean
    Dim normalized As Variant
    Dim ok As Boolean
    If targetCell Is Nothing Then Exit Function
    If targetCell.HasFormula Then Exit Function
    If IsError(targetCell.Value) Then Exit Function
    normalized = NormalizeTimeInput(targetCell.Value, ok)
    If Not ok Then Exit Function
    If Not HasText(targetCell.Value) Then
        TimeEntryIsValidWithoutChange = True
    ElseIf IsDate(normalized) Then
        TimeEntryIsValidWithoutChange = True
    End If
End Function

Private Sub NoteAmountEntryProblem(ByVal targetCell As Range)
    '�ړ��͖W�����A��肾������ԗ��֎c���B
    '���K����Worksheet_Change���Ŋ������Ă��邽�߁A�����ł̓Z���֏������܂Ȃ��B
    '����ɂ��Tab��񂠂���̐��K������x�����ɂȂ�B
    If targetCell Is Nothing Then Exit Sub
    If targetCell.Worksheet.Name <> SH_INPUT Then Exit Sub
    If Not IsAmountInputCell(targetCell) Then Exit Sub
    If AmountEntryIsValidWithoutChange(targetCell) Then Exit Sub
    SetInputStatus targetCell.Address(False, False) & ": " & _
                   AmountInputProblemText(targetCell.Value), True
End Sub

Private Function NormalizeTransactionAmountEntry(ByVal targetCell As Range) As Boolean
    Dim normalized As Variant
    Dim ok As Boolean
    Dim previousEvents As Boolean
    Dim errorNumber As Long, errorDescription As String
    NormalizeTransactionAmountEntry = False
    If targetCell Is Nothing Then Exit Function
    '�����i�󕶎���Ԃ������܂ށj��Excel�G���[�l���󗓂Ƃ��Ēʂ��Ȃ��B
    If targetCell.HasFormula Then Exit Function
    If IsError(targetCell.Value) Then Exit Function
    If Not HasText(targetCell.Value) Then
        NormalizeTransactionAmountEntry = True
        Exit Function
    End If
    '�����͕\���l�֖ق��Ēu�������A�o�^���̐��������Ɠ������s�����͂Ƃ��Ĉ����B
    normalized = TryParseAmount(targetCell.Value, ok)
    If Not ok Or Not HasText(normalized) Then Exit Function
    previousEvents = Application.EnableEvents
    On Error GoTo EH
    Application.EnableEvents = False
    targetCell.NumberFormat = "#,##0.########"
    targetCell.Value = normalized
    targetCell.HorizontalAlignment = xlRight
    Application.EnableEvents = previousEvents
    NormalizeTransactionAmountEntry = True
    Exit Function
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    On Error Resume Next
    Application.EnableEvents = previousEvents
    On Error GoTo 0
    Err.Raise errorNumber, "NormalizeTransactionAmountEntry", errorDescription
End Function

Private Function NormalizeTransactionTimeEntry(ByVal targetCell As Range) As Boolean
    Dim normalized As Variant
    Dim ok As Boolean
    Dim previousEvents As Boolean
    Dim errorNumber As Long, errorDescription As String
    NormalizeTransactionTimeEntry = False
    If targetCell Is Nothing Then Exit Function
    If targetCell.HasFormula Then Exit Function
    If IsError(targetCell.Value) Then Exit Function
    If Not HasText(targetCell.Value) Then
        NormalizeTransactionTimeEntry = True
        Exit Function
    End If
    normalized = NormalizeTimeInput(targetCell.Value, ok)
    If Not ok Or Not IsDate(normalized) Then Exit Function
    previousEvents = Application.EnableEvents
    On Error GoTo EH
    Application.EnableEvents = False
    targetCell.NumberFormat = "@"
    targetCell.Value = Format$(CDate(normalized), "hhmm")
    targetCell.HorizontalAlignment = xlRight
    Application.EnableEvents = previousEvents
    NormalizeTransactionTimeEntry = True
    Exit Function
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    On Error Resume Next
    Application.EnableEvents = previousEvents
    On Error GoTo 0
    Err.Raise errorNumber, "NormalizeTransactionTimeEntry", errorDescription
End Function

Private Sub FillRelationshipFromPerson(ByVal ws As Worksheet)
    Dim relationshipText As String
    Dim previousEvents As Boolean
    Dim errorNumber As Long, errorDescription As String
    If ws Is Nothing Then Exit Sub
    If Not UseRelationshipDisplay() Then Exit Sub
    relationshipText = RelationshipForName(CellText(ws.Range(CELL_PERSON).Value))
    previousEvents = Application.EnableEvents
    On Error GoTo EH
    Application.EnableEvents = False
    '������P�ƂŕύX�������́A�O�̐l���̑������c���Ȃ��B
    '�����Z���\��t���͂��̏�����ʂ�Ȃ����߁A�����Ƒ����̓����\��t���͕ێ������B
    ws.Range(CELL_RELATIONSHIP).Value = relationshipText
    Application.EnableEvents = previousEvents
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    On Error Resume Next
    Application.EnableEvents = previousEvents
    On Error GoTo 0
    Err.Raise errorNumber, "FillRelationshipFromPerson", errorDescription
End Sub

Private Sub UpdateCurrentRowHighlight(ByVal Target As Range)
    Dim ws As Worksheet
    Set ws = Target.Worksheet
    If mLastHighlightRow >= TX_FIRST_ROW And mLastHighlightRow <= TX_LAST_ROW Then
        RestoreTransactionRowStyle ws, mLastHighlightRow
    End If
    If Target.Row >= TX_FIRST_ROW And Target.Row <= TX_LAST_ROW Then
        With ws.Range(ws.Cells(Target.Row, COL_TX_YEAR), ws.Cells(Target.Row, COL_TX_OTHER))
            .Interior.Color = RGB(219, 234, 254)
            .Font.Color = RGB(15, 23, 42)
            .Borders.Color = RGB(37, 99, 235)
        End With
        mLastHighlightRow = Target.Row
    Else
        mLastHighlightRow = 0
    End If
End Sub

Private Sub RestoreTransactionRowStyle(ByVal ws As Worksheet, ByVal rowNo As Long)
    If ws Is Nothing Then Exit Sub
    With ws.Range(ws.Cells(rowNo, COL_TX_YEAR), ws.Cells(rowNo, COL_TX_OTHER))
        If (rowNo - TX_FIRST_ROW) Mod 2 = 0 Then
            .Interior.Color = RGB(255, 255, 255)
        Else
            .Interior.Color = RGB(248, 250, 252)
        End If
        .Font.Color = RGB(15, 23, 42)
        .Borders.Color = RGB(226, 232, 240)
    End With
End Sub
Private Sub UpdateComplementStatus(ByVal Target As Range)
    Dim ws As Worksheet, cy As Long, cm As Long, cd As Long
    Dim timeOK As Boolean, timeInvalid As Boolean, tVal As Variant
    Dim textY As String, textM As String, textD As String, textTime As String
    Dim anyDateRow As Boolean, anyDateInvalid As Boolean, anyDateIncomplete As Boolean
    Dim targetDataRow As Long
    Set ws = Target.Worksheet

    '���������ԍ������ɓ]�L�ς݂Ȃ�A���͕⏕�����x���J�[�h�Ƃ��Ďg���B
    '���b�Z�[�W�{�b�N�X���o���Ɠ��͂̎肪�~�܂邽�߁A��ʓ��̐F�ƕ��������Œm�点��B
    If UpdateDuplicateAccountStatus(ws) Then Exit Sub

    ApplyStatusStyle ws, False
    If Target.Row < TX_FIRST_ROW Or Target.Row > TX_LAST_ROW Then
        ws.Range(CELL_STATUS).Value = "���t�⊮�@-�N�@-���@-���@�^�@���͎����@--:--"
        Exit Sub
    End If
    textTime = "--:--"
    targetDataRow = Target.Row - TX_FIRST_ROW + 1
    EnsureDateComplementCache ws, Target.Row
    cy = mDateCacheYear(targetDataRow)
    cm = mDateCacheMonth(targetDataRow)
    cd = mDateCacheDay(targetDataRow)
    anyDateRow = mDateCacheAnyDate(targetDataRow)
    anyDateInvalid = mDateCacheAnyInvalid(targetDataRow)
    anyDateIncomplete = mDateCacheAnyIncomplete(targetDataRow)
    '�����͑O�s����⊮���Ȃ��B�I�𒆂̍s�ɓ��͂�����ꍇ�����\������B
    If HasText(ws.Cells(Target.Row, COL_TX_TIME).Value2) Then
        tVal = NormalizeTimeInput(ws.Cells(Target.Row, COL_TX_TIME).Value2, timeOK)
        If timeOK Then
            If IsDate(tVal) Then
                textTime = Format$(CDate(tVal), "hh:mm")
            Else
                textTime = "�����v�m�F"
                timeInvalid = True
            End If
        Else
            textTime = "�����v�m�F"
            timeInvalid = True
        End If
    End If
    If timeInvalid Then ApplyStatusStyle ws, True
    If anyDateRow And anyDateInvalid Then
        ApplyStatusStyle ws, True
        ws.Range(CELL_STATUS).Value = "���t�⊮�@�v�m�F�@�^�@���͎����@" & textTime
    ElseIf anyDateRow And anyDateIncomplete Then
        ws.Range(CELL_STATUS).Value = "���t�⊮�@���͒��@�^�@���͎����@" & textTime
    Else
        If cy = 0 Then textY = "-" Else textY = CStr(cy)
        If cm = 0 Then textM = "-" Else textM = CStr(cm)
        If cd = 0 Then textD = "-" Else textD = CStr(cd)
        ws.Range(CELL_STATUS).Value = "���t�⊮�@" & textY & "�N�@" & textM & "���@" & textD & "���@�^�@���͎����@" & textTime
    End If
End Sub

Private Sub EnsureDateComplementCache(ByVal ws As Worksheet, ByVal throughSheetRow As Long)
    Dim itemCount As Long, targetIndex As Long, startIndex As Long
    Dim r As Long, c As Long, cy As Long, cm As Long, cd As Long, sheetRow As Long
    Dim yAdd As Long, ok As Boolean, rowHasData As Boolean
    Dim anyDateRow As Boolean, rowDateInvalid As Boolean, rowDateIncomplete As Boolean
    Dim rowDateUnsupported As Boolean
    Dim inputData As Variant, resolvedDate As Variant
    Dim dateInputRange As Range
    Dim formulaRows As Object
    If ws Is Nothing Then Exit Sub
    itemCount = TX_LAST_ROW - TX_FIRST_ROW + 1
    targetIndex = throughSheetRow - TX_FIRST_ROW + 1
    If targetIndex < 1 Then Exit Sub
    If targetIndex > itemCount Then targetIndex = itemCount
    yAdd = GetCfgLong(ROW_CFG_YEAR_ADD, 2000)

    If Not mDateCacheReady Or mDateCacheYearAdd <> yAdd Then
        ReDim mDateCacheYear(1 To itemCount)
        ReDim mDateCacheMonth(1 To itemCount)
        ReDim mDateCacheDay(1 To itemCount)
        ReDim mDateCacheAnyDate(1 To itemCount)
        ReDim mDateCacheAnyInvalid(1 To itemCount)
        ReDim mDateCacheAnyIncomplete(1 To itemCount)
        mDateCacheValidThrough = 0
        mDateCacheYearAdd = yAdd
        mDateCacheReady = True
    End If
    If targetIndex <= mDateCacheValidThrough Then Exit Sub

    If mDateCacheValidThrough > 0 Then
        cy = mDateCacheYear(mDateCacheValidThrough)
        cm = mDateCacheMonth(mDateCacheValidThrough)
        cd = mDateCacheDay(mDateCacheValidThrough)
        anyDateRow = mDateCacheAnyDate(mDateCacheValidThrough)
    End If
    startIndex = mDateCacheValidThrough + 1
    Set dateInputRange = ws.Range( _
        ws.Cells(TX_FIRST_ROW + startIndex - 1, COL_TX_YEAR), _
        ws.Cells(TX_FIRST_ROW + targetIndex - 1, COL_TX_DAY))
    Set formulaRows = TransactionDateFormulaRowMap(dateInputRange)
    inputData = ws.Range( _
        ws.Cells(TX_FIRST_ROW + startIndex - 1, COL_TX_YEAR), _
        ws.Cells(TX_FIRST_ROW + targetIndex - 1, COL_TX_OTHER)).Value2

    For r = 1 To targetIndex - startIndex + 1
        rowHasData = False
        rowDateInvalid = False
        rowDateIncomplete = False
        sheetRow = TX_FIRST_ROW + startIndex + r - 2
        rowDateUnsupported = formulaRows.Exists(CStr(sheetRow)) Or _
                             IsError(inputData(r, 1)) Or _
                             IsError(inputData(r, COL_TX_MONTH - COL_TX_YEAR + 1)) Or _
                             IsError(inputData(r, COL_TX_DAY - COL_TX_YEAR + 1))
        For c = 1 To COL_TX_OTHER - COL_TX_YEAR + 1
            If HasText(inputData(r, c)) Then rowHasData = True: Exit For
        Next c
        If rowDateUnsupported Then rowHasData = True
        If rowHasData Then
            anyDateRow = True
            If rowDateUnsupported Then
                '�������ʂ�Excel�G���[��⊮��֍̗p���Ȃ��B�㑱�s�̔N���������������Ȃ��B
                rowDateInvalid = True
            Else
                resolvedDate = ResolveInputDate(inputData(r, 1), _
                    inputData(r, COL_TX_MONTH - COL_TX_YEAR + 1), _
                    inputData(r, COL_TX_DAY - COL_TX_YEAR + 1), _
                    cy, cm, cd, yAdd, ok)
                If Not ok Then
                    If DateInputHasExplicitProblem(inputData(r, 1), _
                            inputData(r, COL_TX_MONTH - COL_TX_YEAR + 1), _
                            inputData(r, COL_TX_DAY - COL_TX_YEAR + 1), _
                            cy, cm, cd, yAdd) Then
                        rowDateInvalid = True
                    Else
                        rowDateIncomplete = True
                    End If
                End If
            End If
        End If
        c = startIndex + r - 1
        mDateCacheYear(c) = cy
        mDateCacheMonth(c) = cm
        mDateCacheDay(c) = cd
        mDateCacheAnyDate(c) = anyDateRow
        '�s���E���͓r���͌��ݍs�����̏�ԁBResolveInputDate�͎��s���ɕ⊮���
        '�X�V���Ȃ����߁A�㑱�̐���s�܂ŉߋ��G���[�Őԕ\���������Ȃ��B
        mDateCacheAnyInvalid(c) = rowDateInvalid
        mDateCacheAnyIncomplete(c) = rowDateIncomplete
    Next r
    mDateCacheValidThrough = targetIndex
End Sub

Private Function TransactionDateFormulaRowMap(ByVal targetRange As Range) As Object
    'SpecialCells����x�����ĂсA�����Z��������s����������������B
    '�L���b�V���쐬���ɍő�5000�s���Z���P�ʂ�COM�ďo���ő������Ȃ��B
    Dim result As Object
    Dim formulaCells As Range, cell As Range
    Dim specialCellsError As Long, specialCellsDescription As String
    Set result = CreateObject("Scripting.Dictionary")
    result.CompareMode = vbBinaryCompare
    If targetRange Is Nothing Then
        Set TransactionDateFormulaRowMap = result
        Exit Function
    End If

    On Error Resume Next
    Set formulaCells = targetRange.SpecialCells(xlCellTypeFormulas)
    specialCellsError = Err.Number
    specialCellsDescription = Err.Description
    Err.Clear
    On Error GoTo EH
    If specialCellsError <> 0 And specialCellsError <> 1004 Then _
        Err.Raise specialCellsError, "TransactionDateFormulaRowMap", specialCellsDescription
    If Not formulaCells Is Nothing Then
        For Each cell In formulaCells.Cells
            If Not result.Exists(CStr(cell.Row)) Then result.Add CStr(cell.Row), True
        Next cell
    End If
    Set TransactionDateFormulaRowMap = result
    Exit Function
EH:
    Err.Raise Err.Number, "TransactionDateFormulaRowMap", Err.Description
End Function

Private Function DateInputHasExplicitProblem(ByVal yearValue As Variant, _
                                             ByVal monthValue As Variant, _
                                             ByVal dayValue As Variant, _
                                             ByVal baseYear As Long, _
                                             ByVal baseMonth As Long, _
                                             ByVal baseDay As Long, _
                                             ByVal yearAdd As Long) As Boolean
    Dim candidateYear As Long, candidateMonth As Long, candidateDay As Long
    Dim parsedMonth As Long, parsedDay As Long
    Dim valueText As String
    Dim yearOK As Boolean
    Dim candidateDate As Date
    On Error GoTo InvalidValue
    candidateYear = baseYear
    candidateMonth = baseMonth
    candidateDay = baseDay
    If HasText(yearValue) Then
        candidateYear = NormalizeYearInput(yearValue, yearAdd, yearOK)
        If Not yearOK Then GoTo InvalidValue
    End If
    If HasText(monthValue) Then
        valueText = NormalizeNumberText(CellText(monthValue))
        If Len(valueText) = 0 Or Len(valueText) > 2 Or _
           Not IsUnsignedIntegerText(valueText) Then GoTo InvalidValue
        candidateMonth = CLng(valueText)
        If candidateMonth < 1 Or candidateMonth > 12 Then GoTo InvalidValue
    End If
    If HasText(dayValue) Then
        valueText = NormalizeNumberText(CellText(dayValue))
        If Len(valueText) >= 3 Then
            If Not ParseMonthDay(dayValue, parsedMonth, parsedDay) Then GoTo InvalidValue
            candidateMonth = parsedMonth
            candidateDay = parsedDay
        Else
            If Len(valueText) = 0 Or Len(valueText) > 2 Or _
               Not IsUnsignedIntegerText(valueText) Then GoTo InvalidValue
            candidateDay = CLng(valueText)
            If candidateDay < 1 Or candidateDay > 31 Then GoTo InvalidValue
        End If
    End If
    '�N�����̂����ꂩ���܂�������Ԃ͕s���ł͂Ȃ����͓r���B
    If candidateYear = 0 Or candidateMonth = 0 Or candidateDay = 0 Then Exit Function
    candidateDate = DateSerial(candidateYear, candidateMonth, candidateDay)
    If Year(candidateDate) <> candidateYear Or Month(candidateDate) <> candidateMonth Or _
       Day(candidateDate) <> candidateDay Then GoTo InvalidValue
    Exit Function
InvalidValue:
    DateInputHasExplicitProblem = True
End Function



Public Function UpdateDuplicateAccountStatus(ByVal ws As Worksheet) As Boolean
    Dim msg As String
    If ws Is Nothing Then Exit Function
    msg = DuplicateAccountWarningMessage(ws)
    If Len(msg) > 0 Then
        ApplyStatusStyle ws, True
        ws.Range(CELL_STATUS).Value = msg
        UpdateDuplicateAccountStatus = True
    Else
        ApplyStatusStyle ws, False
    End If
End Function

Private Function DuplicateAccountWarningMessage(ByVal ws As Worksheet) As String
    Dim bankName As String, branchName As String, personName As String, accType As String, accNo As String
    Dim hitInfo As String
    Dim cacheKey As String
    If ws Is Nothing Then Exit Function

    accNo = NormalizeAccountHyphen(CellText(ws.Range(CELL_ACCOUNT_NO).Value))
    If Len(accNo) = 0 Then
        InvalidateDuplicateAccountWarningCache
        Exit Function
    End If

    bankName = CellText(ws.Range(CELL_BANK).Value)
    branchName = CellText(ws.Range(CELL_BRANCH).Value)
    personName = CellText(ws.Range(CELL_PERSON).Value)
    accType = CellText(ws.Range(CELL_ACCOUNT_TYPE).Value)

    cacheKey = DuplicateAccountCacheKey(bankName, branchName, personName, accType, accNo)
    If cacheKey = mDuplicateCacheKey Then
        DuplicateAccountWarningMessage = mDuplicateCacheMessage
        Exit Function
    End If

    '�����}�X�^��������������B����E�c����S�s�������Ȃ����߁A�����������Ă��y���B
    If Len(bankName) > 0 And Len(accType) > 0 Then
        hitInfo = FindAccountIDByLocator(bankName, branchName, accType, accNo, CurrentEditAccountID())
    End If
    If Len(hitInfo) > 0 Then
        DuplicateAccountWarningMessage = "�m�F�@������s�E�x�X�E�ȖځE�����ԍ��͓o�^�ς݂ł��F" & accNo & _
                                         "�@���`�������m�o�^�ς݌����n����s���Ă��������B"
    End If

    mDuplicateCacheKey = cacheKey
    mDuplicateCacheMessage = DuplicateAccountWarningMessage
End Function

Private Function DuplicateAccountCacheKey(ByVal bankName As String, ByVal branchName As String, ByVal personName As String, ByVal accType As String, ByVal accNo As String) As String
    '������񂾂��łȂ��A��ƃV�[�g�̍ŏI�s���L�[�Ɋ܂߂�B
    '�]�L��ɍs�����������ꍇ�͓��������ԍ��ł��Ĕ��肳���B
    Dim accountLast As Long

    If SheetExists(SH_WORK_ACCOUNT) Then accountLast = LastUsedRowInSheet(GetSheet(SH_WORK_ACCOUNT))

    DuplicateAccountCacheKey = bankName & Chr$(30) & branchName & Chr$(30) & personName & Chr$(30) & _
                               accType & Chr$(30) & accNo & Chr$(30) & CurrentEditAccountID() & Chr$(30) & CStr(accountLast)
End Function

Private Sub ApplyStatusStyle(ByVal ws As Worksheet, ByVal warningMode As Boolean)
    Dim rng As Range
    If ws Is Nothing Then Exit Sub
    Set rng = EffectiveRange(ws.Range(CELL_STATUS))
    If warningMode Then
        rng.Interior.Color = RGB(254, 226, 226)
        rng.Font.Color = RGB(153, 27, 27)
        rng.Borders.Color = RGB(248, 113, 113)
    Else
        rng.Interior.Color = RGB(236, 253, 245)
        rng.Font.Color = RGB(15, 118, 110)
        rng.Borders.Color = RGB(94, 234, 212)
    End If
    rng.Font.Bold = True
    rng.HorizontalAlignment = xlCenter
    rng.VerticalAlignment = xlCenter
    rng.WrapText = True
    rng.ShrinkToFit = True
End Sub

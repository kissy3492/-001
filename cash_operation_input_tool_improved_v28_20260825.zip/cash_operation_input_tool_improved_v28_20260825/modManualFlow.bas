Attribute VB_Name = "modManualFlow"
Option Explicit

'�����T������R��镡�G�ȑ��˕����A��������\�܂��͌݊��p��▾�ׂ��疾���I�ɓo�^����B
'�폜�ł͂Ȃ��L��/������ێ����A�둀�����č��\�ɂ���B

Private Const MANUAL_ACTIVE As String = "�L��"
Private Const MANUAL_INACTIVE As String = "����"
Private Const DETAIL_KIND_COL As Long = 8       'H
Private Const DETAIL_REFERENCE_COL As Long = 9  'I
Private Const DETAIL_SELECTED_COL As Long = 12  'L

Public Function ManualFlowStoreHeaders() As Variant
    ManualFlowStoreHeaders = Array( _
        "�蓮���ID", "�\�����ID", "�ǐՊz", "�m�F��", "�m�F����", _
        "�L�����", "�o�^����", "�o�^��", "�X�V����", "��������", "�m�F�L�[")
End Function

Public Sub SetupManualFlowStore(Optional ByVal resetContents As Boolean = False)
    Dim ws As Worksheet
    Set ws = GetOrCreateSheet(SH_WORK_MANUAL_FLOW, False)
    If resetContents Then ResetWorksheet ws
    If Len(CellText(ws.Cells(1, 1).Value)) = 0 Then
        SetRowValues ws.Range("A1"), ManualFlowStoreHeaders()
        FormatOutputHeader ws.Range(ws.Cells(1, 1), ws.Cells(1, MANUAL_FLOW_STORE_LAST_COL))
    End If
    ws.Columns("A:K").NumberFormat = "@"
    ws.Columns("C:C").NumberFormat = "#,##0.########"
    ws.Columns("G:G").NumberFormat = "yyyy/m/d h:mm:ss"
    ws.Columns("I:I").NumberFormat = "yyyy/m/d h:mm:ss"
    SetSheetVeryHiddenSafe ws
End Sub

Public Sub RegisterManualAnalysisCandidateFromDetail()
    Dim wsDetail As Worksheet, selected As Object
    Dim lastR As Long, r As Long, txID As String, idList As String
    Dim suggestedAmount As Double, amountInput As Variant
    Dim totalWithdrawal As Double, totalDeposit As Double, txCount As Long
    Dim storeSnapshot As Variant, storeSnapshotLastRow As Long, storeChanged As Boolean
    Dim analysisBuildStarted As Boolean
    Dim reviewsWerePending As Boolean
    Dim errorNumber As Long, errorDescription As String
    If Not RequireToolReady() Then Exit Sub
    If Not RequireInternalStoresSafeForWrite() Then Exit Sub
    If Not SheetExists(SH_ANALYSIS_DETAIL) Then Exit Sub
    On Error GoTo EH
    Set wsDetail = GetSheet(SH_ANALYSIS_DETAIL)
    reviewsWerePending = HasPendingAnalysisReviewChanges()
    Set selected = CreateObject("Scripting.Dictionary")
    selected.CompareMode = vbTextCompare
    lastR = LastUsedRowInSheet(wsDetail)
    For r = 1 To lastR
        If CellText(wsDetail.Cells(r, DETAIL_KIND_COL).Value) = "���" And _
           CellText(wsDetail.Cells(r, DETAIL_SELECTED_COL).Value) = "1" Then
            txID = CellText(wsDetail.Cells(r, DETAIL_REFERENCE_COL).Value)
            If Len(txID) > 0 Then selected(txID) = True
        End If
    Next r
    If selected.Count < 2 Then
        MsgBox "���ڍׂ̎���s��2���ȏ�I�����Ă��������B" & vbCrLf & _
               "����s���_�u���N���b�N����ƑI���E�����ł��܂��B", vbInformation
        Exit Sub
    End If
    idList = JoinManualDictionaryKeys(selected)
    ValidateManualTransactionIDs idList, txCount, totalWithdrawal, totalDeposit, _
                                 suggestedAmount, idList
    amountInput = Application.InputBox( _
        Prompt:="���̌��ŒǐՂ�����z����͂��Ă��������B" & vbCrLf & _
                "�I�����: " & CStr(txCount) & "�� / �o���v " & _
                Format$(totalWithdrawal, "#,##0.########") & " / �����v " & _
                Format$(totalDeposit, "#,##0.########"), _
        Title:="�蓮�̎����ړ����", Default:=suggestedAmount, Type:=1)
    If VarType(amountInput) = vbBoolean Then
        If CBool(amountInput) = False Then Exit Sub
    End If
    If Not IsNumeric(amountInput) Or CDbl(amountInput) <= 0 Or _
       CDbl(amountInput) > MAX_ABS_AMOUNT Then
        MsgBox "�ǐՊz��0���傫���L���ȋ��z�œ��͂��Ă��������B", vbExclamation
        Exit Sub
    End If
    If MsgBox("�I������ " & CStr(txCount) & "������A�ǐՊz " & _
              Format$(CDbl(amountInput), "#,##0.########") & _
              " �̎蓮���Ƃ��ēo�^���܂����H", _
              vbYesNo + vbQuestion + vbDefaultButton2, "�蓮���̊m�F") <> vbYes Then Exit Sub

    CaptureManualFlowStoreSnapshot storeSnapshot, storeSnapshotLastRow
    AppBegin "�蓮����o�^���ĕ��͌��ʂ��X�V���Ă��܂�..."
    storeChanged = True
    SaveManualFlowCandidate idList, CDbl(amountInput)
    MarkAnalysisReviewsDirty
    analysisBuildStarted = True
    BuildTransactionAnalysisSheetsCore True
    MarkAnalysisReviewsClean
    AppEnd
    MsgBox "�蓮�̎����ړ�����o�^���A���͌��ʂ֔��f���܂����B" & vbCrLf & _
           "���ڍׂŌʂ̊m�F�󋵂ƃ�������͂ł��܂��B", vbInformation
    Exit Sub
EH:
    errorNumber = Err.Number: errorDescription = Err.Description
    On Error Resume Next
    If storeChanged Then RestoreManualFlowStoreSnapshot storeSnapshot, storeSnapshotLastRow
    If Err.Number <> 0 Then errorDescription = errorDescription & _
        " / ���[���o�b�N�x��: " & Err.Description
    Err.Clear
    If analysisBuildStarted Or reviewsWerePending Then _
        MarkAnalysisReviewsDirty Else MarkAnalysisReviewsClean
    If analysisBuildStarted Then MarkOutputsDirty
    If IsUserCancelError(errorNumber) Then
        If analysisBuildStarted Then
            SetInputStatus "�蓮���̓o�^�����𒆒f���܂����B���͌��ʂ͍ŐV�Ƃ͌���܂���B"
        Else
            SetInputStatus "�蓮���̓o�^�𒆎~���܂����B�ۑ����e�͕ύX���Ă��܂���B"
        End If
    Else
        AddCheck "�G���[", "�蓮���o�^", _
                 "Err " & CStr(errorNumber) & ": " & errorDescription
        SetInputStatus "�蓮���̓o�^�Ɏ��s���܂����B���͌��ʂ͍ŐV�Ƃ͌���܂���BC_�`�F�b�N���m�F���Ă��������B"
    End If
    On Error GoTo 0
    AppEnd
    If IsUserCancelError(errorNumber) Then Exit Sub
    MsgBox OperationFailureHeading(errorNumber, "�蓮����o�^�ł��܂���ł����B") & vbCrLf & _
           OperationFailureDetail(errorNumber, errorDescription), OperationFailureIcon(errorNumber, vbExclamation)
End Sub

'��������\�̓�����ʂ���A���ڍׂ��o�R�����Ɏ蓮����o�^����B
'�o���v�Ɠ����v�͕ʁX�ɒ񎦂��A�������z���ւ܂Ƃ߂Ȃ��B
Public Function RegisterManualAnalysisCandidateByIDs(ByVal idList As String) As Boolean
    Dim suggestedAmount As Double, amountInput As Variant
    Dim totalWithdrawal As Double, totalDeposit As Double, txCount As Long
    Dim storeSnapshot As Variant, storeSnapshotLastRow As Long, storeChanged As Boolean
    Dim analysisBuildStarted As Boolean, reviewsWerePending As Boolean
    Dim errorNumber As Long, errorDescription As String

    If Not RequireToolReady() Then Exit Function
    If Not RequireInternalStoresSafeForWrite() Then Exit Function
    On Error GoTo EH
    reviewsWerePending = HasPendingAnalysisReviewChanges()
    ValidateManualTransactionIDs idList, txCount, totalWithdrawal, totalDeposit, _
                                 suggestedAmount, idList
    If txCount < 2 Then
        MsgBox "�����2���ȏ�I�����Ă��������B", vbInformation
        Exit Function
    End If
    amountInput = Application.InputBox( _
        Prompt:="���̌��ŒǐՂ�����z����͂��Ă��������B" & vbCrLf & _
                "�I�����: " & CStr(txCount) & "��" & vbCrLf & _
                "�o�����v: " & Format$(totalWithdrawal, "#,##0.########") & vbCrLf & _
                "�������v: " & Format$(totalDeposit, "#,##0.########") & vbCrLf & _
                "���z�i�����|�o���j: " & _
                Format$(totalDeposit - totalWithdrawal, "+#,##0.########;-#,##0.########;0"), _
        Title:="�蓮�̎����ړ����", Default:=suggestedAmount, Type:=1)
    If VarType(amountInput) = vbBoolean Then
        If CBool(amountInput) = False Then Exit Function
    End If
    If Not IsNumeric(amountInput) Or CDbl(amountInput) <= 0 Or _
       CDbl(amountInput) > MAX_ABS_AMOUNT Then
        MsgBox "�ǐՊz��0���傫���L���ȋ��z�œ��͂��Ă��������B", vbExclamation
        Exit Function
    End If
    If MsgBox("�I������ " & CStr(txCount) & "������蓮���Ƃ��ēo�^���܂����H" & vbCrLf & _
              "�o�����v: " & Format$(totalWithdrawal, "#,##0.########") & vbCrLf & _
              "�������v: " & Format$(totalDeposit, "#,##0.########") & vbCrLf & _
              "�ǐՊz: " & Format$(CDbl(amountInput), "#,##0.########"), _
              vbYesNo + vbQuestion + vbDefaultButton2, "�蓮���̊m�F") <> vbYes Then Exit Function

    CaptureManualFlowStoreSnapshot storeSnapshot, storeSnapshotLastRow
    AppBegin "�蓮����o�^���Ď�������\���X�V���Ă��܂�..."
    storeChanged = True
    SaveManualFlowCandidate idList, CDbl(amountInput)
    MarkAnalysisReviewsDirty
    analysisBuildStarted = True
    BuildTransactionAnalysisSheetsCore True
    MarkAnalysisReviewsClean
    AppEnd
    RegisterManualAnalysisCandidateByIDs = True
    MsgBox "�蓮�̎����ړ�����o�^���܂����B" & vbCrLf & _
           "��������\�̏㕔�Ŋm�F�󋵂ƃ������L�^�ł��܂��B", vbInformation
    Exit Function
EH:
    errorNumber = Err.Number: errorDescription = Err.Description
    On Error Resume Next
    If storeChanged Then RestoreManualFlowStoreSnapshot storeSnapshot, storeSnapshotLastRow
    If Err.Number <> 0 Then errorDescription = errorDescription & _
        " / ���[���o�b�N�x��: " & Err.Description
    Err.Clear
    If analysisBuildStarted Or reviewsWerePending Then _
        MarkAnalysisReviewsDirty Else MarkAnalysisReviewsClean
    If analysisBuildStarted Then MarkOutputsDirty
    If IsUserCancelError(errorNumber) Then
        If analysisBuildStarted Then
            SetInputStatus "�蓮���̓o�^�����𒆒f���܂����B���͌��ʂ͍ŐV�Ƃ͌���܂���B"
        Else
            SetInputStatus "�蓮���̓o�^�𒆎~���܂����B�ۑ����e�͕ύX���Ă��܂���B"
        End If
    Else
        AddCheck "�G���[", "��������\����̎蓮���o�^", _
                 "Err " & CStr(errorNumber) & ": " & errorDescription
        SetInputStatus "�蓮���̓o�^�Ɏ��s���܂����BC_�`�F�b�N���m�F���Ă��������B"
    End If
    On Error GoTo 0
    AppEnd
    If IsUserCancelError(errorNumber) Then Exit Function
    MsgBox OperationFailureHeading(errorNumber, "�蓮����o�^�ł��܂���ł����B") & vbCrLf & _
           OperationFailureDetail(errorNumber, errorDescription), OperationFailureIcon(errorNumber, vbExclamation)
End Function

Private Sub SaveManualFlowCandidate(ByVal canonicalTxIDs As String, ByVal trackingAmount As Double)
    Dim ws As Worksheet, lastR As Long, data As Variant, r As Long, rowNo As Long
    Dim activeText As String, currentIDs As String, idSetKey As String, currentSetKey As String
    Dim manualID As String, baseKey As String
    Set ws = GetSheet(SH_WORK_MANUAL_FLOW)
    lastR = LastUsedRowInSheet(ws)
    idSetKey = ManualIDSetSignature(canonicalTxIDs)
    If lastR >= 2 Then
        data = ws.Range(ws.Cells(2, 1), ws.Cells(lastR, MANUAL_FLOW_STORE_LAST_COL)).Value2
        For r = 1 To UBound(data, 1)
            currentIDs = CellText(data(r, MANUAL_FLOW_COL_TX_IDS))
            currentSetKey = ManualIDSetSignature(currentIDs)
            If Len(currentSetKey) > 0 And StrComp(currentSetKey, idSetKey, vbBinaryCompare) = 0 Then
                activeText = CellText(data(r, MANUAL_FLOW_COL_ACTIVE))
                If activeText = MANUAL_ACTIVE Then _
                    Err.Raise vbObjectError + 4950, "SaveManualFlowCandidate", _
                              "�����\������̎蓮���͊��ɓo�^����Ă��܂��B"
                If MsgBox("�����\������̖����Ȏ蓮��₪����܂��B�ėL�������܂����H", _
                          vbYesNo + vbQuestion + vbDefaultButton2) <> vbYes Then _
                    Err.Raise 18, "SaveManualFlowCandidate", "���p�҂��ėL�����𒆎~���܂����B"
                rowNo = r + 1
                ws.Cells(rowNo, MANUAL_FLOW_COL_TX_IDS).Value = canonicalTxIDs
                ws.Cells(rowNo, MANUAL_FLOW_COL_AMOUNT).Value = trackingAmount
                ws.Cells(rowNo, MANUAL_FLOW_COL_STATUS).Value = ANALYSIS_STATUS_FOLLOWUP
                ws.Cells(rowNo, MANUAL_FLOW_COL_MEMO).Value = _
                    AppendAnalysisMemo(CellText(ws.Cells(rowNo, MANUAL_FLOW_COL_MEMO).Value), _
                                       "[����] �����Ȏ蓮�����ėL�������܂����B")
                ws.Cells(rowNo, MANUAL_FLOW_COL_ACTIVE).Value = MANUAL_ACTIVE
                ws.Cells(rowNo, MANUAL_FLOW_COL_UPDATED_AT).Value = Now
                SetSheetVeryHiddenSafe ws
                Exit Sub
            End If
        Next r
    End If
    rowNo = lastR + 1
    If rowNo < 2 Then rowNo = 2
    If rowNo - 1 > MAX_INTERNAL_STORE_DATA_ROWS Then _
        Err.Raise vbObjectError + 4951, "SaveManualFlowCandidate", _
                  "�蓮��₪�ۑ�����𒴂��܂����B�Č��t�@�C���𕪂��Ă��������B"
    manualID = "MF-" & Format$(Now, "yyyymmddhhnnss") & "-" & Format$(rowNo - 1, "000000")
    baseKey = "MANUAL>" & manualID
    ws.Cells(rowNo, MANUAL_FLOW_COL_ID).Value = manualID
    ws.Cells(rowNo, MANUAL_FLOW_COL_TX_IDS).Value = canonicalTxIDs
    ws.Cells(rowNo, MANUAL_FLOW_COL_AMOUNT).Value = trackingAmount
    ws.Cells(rowNo, MANUAL_FLOW_COL_STATUS).Value = ANALYSIS_STATUS_UNREVIEWED
    ws.Cells(rowNo, MANUAL_FLOW_COL_MEMO).Value = vbNullString
    ws.Cells(rowNo, MANUAL_FLOW_COL_ACTIVE).Value = MANUAL_ACTIVE
    ws.Cells(rowNo, MANUAL_FLOW_COL_CREATED_AT).Value = Now
    ws.Cells(rowNo, MANUAL_FLOW_COL_CREATED_BY).Value = ManualFlowUserName()
    ws.Cells(rowNo, MANUAL_FLOW_COL_UPDATED_AT).Value = Now
    ws.Cells(rowNo, MANUAL_FLOW_COL_KEY).Value = baseKey
    SetSheetVeryHiddenSafe ws
End Sub

Public Sub AppendManualFlowAnalysisRecords( _
        ByRef sourceData As Variant, ByVal sourceRowCount As Long, ByVal wsOut As Worksheet, _
        ByVal reviews As Object, ByVal candidateCountByTx As Object, _
        ByVal bestScoreByTx As Object, ByVal bestRatingByTx As Object, _
        ByRef flowCount As Long)
    Dim wsStore As Worksheet, lastR As Long, data As Variant, r As Long
    Dim txIndex As Object, txIDs As String, baseKey As String, manualID As String
    Dim amountValue As Double, statusText As String, memoText As String
    Dim rows() As Long, rowCount As Long, rowList As String, canonicalIDs As String
    Dim evidenceText As String, storedEvidence As String, outputRow As Long
    Dim totalWithdrawal As Double, totalDeposit As Double
    If Not SheetExists(SH_WORK_MANUAL_FLOW) Then Exit Sub
    Set wsStore = GetSheet(SH_WORK_MANUAL_FLOW)
    lastR = LastUsedRowInSheet(wsStore)
    If lastR < 2 Then Exit Sub
    If sourceRowCount <= 0 Then _
        Err.Raise vbObjectError + 4952, "AppendManualFlowAnalysisRecords", _
                  "�蓮��₪����܂����A�\����������݂��܂���B"
    Set txIndex = BuildManualTransactionIndex(sourceData, sourceRowCount)
    data = wsStore.Range(wsStore.Cells(2, 1), _
                         wsStore.Cells(lastR, MANUAL_FLOW_STORE_LAST_COL)).Value2
    wsOut.Unprotect Password:=TOOL_PASSWORD
    outputRow = LastUsedRowInSheet(wsOut) + 1
    If outputRow < 2 Then outputRow = 2
    For r = 1 To UBound(data, 1)
        If CellText(data(r, MANUAL_FLOW_COL_ACTIVE)) = MANUAL_ACTIVE Then
            rowCount = 0: rowList = vbNullString: canonicalIDs = vbNullString
            manualID = CellText(data(r, MANUAL_FLOW_COL_ID))
            txIDs = CellText(data(r, MANUAL_FLOW_COL_TX_IDS))
            baseKey = CellText(data(r, MANUAL_FLOW_COL_KEY))
            If Len(manualID) = 0 Or _
               StrComp(baseKey, "MANUAL>" & manualID, vbBinaryCompare) <> 0 Or _
               Not IsNumeric(data(r, MANUAL_FLOW_COL_AMOUNT)) Then _
                Err.Raise vbObjectError + 4953, "AppendManualFlowAnalysisRecords", _
                          "W_�蓮������� " & CStr(r + 1) & "�s�ڂ��s���ł��B"
            amountValue = CDbl(data(r, MANUAL_FLOW_COL_AMOUNT))
            If amountValue <= 0 Or amountValue > MAX_ABS_AMOUNT Then _
                Err.Raise vbObjectError + 4963, "AppendManualFlowAnalysisRecords", _
                          "W_�蓮������� " & CStr(r + 1) & "�s�ڂ̒ǐՊz���s���ł��B"
            ManualRowsForIDs txIDs, txIndex, sourceData, rows, rowCount, rowList, canonicalIDs
            totalWithdrawal = 0: totalDeposit = 0
            ManualTotals sourceData, rows, rowCount, totalWithdrawal, totalDeposit
            If totalWithdrawal <= 0 Or totalDeposit <= 0 Then _
                Err.Raise vbObjectError + 4964, "AppendManualFlowAnalysisRecords", _
                          "W_�蓮������� " & CStr(r + 1) & _
                          "�s�ڂ͏o���E�����̗������܂�ł��܂���B"
            evidenceText = AnalysisEvidenceDigest(sourceData, rowList, _
                           "MANUAL|AMT=" & Trim$(Str$(amountValue)))
            statusText = CellText(data(r, MANUAL_FLOW_COL_STATUS))
            If Len(statusText) = 0 Then statusText = ANALYSIS_STATUS_UNREVIEWED
            If Not ManualFlowReviewStatus(statusText) Then _
                Err.Raise vbObjectError + 4965, "AppendManualFlowAnalysisRecords", _
                          "W_�蓮������� " & CStr(r + 1) & "�s�ڂ̊m�F�󋵂��s���ł��B"
            memoText = CellText(data(r, MANUAL_FLOW_COL_MEMO))
            storedEvidence = CellText(data(r, MANUAL_FLOW_COL_EVIDENCE))
            If Len(storedEvidence) > 0 And _
               StrComp(storedEvidence, evidenceText, vbBinaryCompare) <> 0 Then
                statusText = ANALYSIS_STATUS_FOLLOWUP
                memoText = AppendAnalysisMemo(memoText, _
                    "[����] �\������܂��͒ǐՊz�̕ύX�����m���A�Ċm�F�֖߂��܂����B")
            End If
            WriteManualFlowOutputRow wsOut, outputRow, sourceData, rows, rowCount, _
                                     canonicalIDs, amountValue, statusText, memoText, _
                                     AnalysisStoredKey(baseKey, evidenceText)
            outputRow = outputRow + 1
            UpdateManualCandidateStatistics canonicalIDs, candidateCountByTx, _
                                            bestScoreByTx, bestRatingByTx
            flowCount = flowCount + 1
            wsStore.Cells(r + 1, MANUAL_FLOW_COL_EVIDENCE).Value = evidenceText
            wsStore.Cells(r + 1, MANUAL_FLOW_COL_STATUS).Value = statusText
            wsStore.Cells(r + 1, MANUAL_FLOW_COL_MEMO).Value = memoText
            wsStore.Cells(r + 1, MANUAL_FLOW_COL_UPDATED_AT).Value = Now
        End If
    Next r
    FinalizeAdvancedFlowAnalysisSheet wsOut, flowCount
    SetSheetVeryHiddenSafe wsStore
End Sub

Public Sub SyncManualFlowReviewsFromAnalysisSheet()
    Dim wsFlow As Worksheet, wsStore As Worksheet, storeIndex As Object
    Dim lastR As Long, storeLastR As Long, data As Variant, r As Long
    Dim storedKey As String, baseKey As String, evidenceText As String
    Dim statusText As String, memoText As String, rowNo As Long
    If Not SheetExists(SH_ANALYSIS_FLOW) Or Not SheetExists(SH_WORK_MANUAL_FLOW) Then Exit Sub
    Set wsFlow = GetSheet(SH_ANALYSIS_FLOW)
    Set wsStore = GetSheet(SH_WORK_MANUAL_FLOW)
    Set storeIndex = CreateObject("Scripting.Dictionary")
    storeIndex.CompareMode = vbBinaryCompare
    storeLastR = LastUsedRowInSheet(wsStore)
    For r = 2 To storeLastR
        baseKey = CellText(wsStore.Cells(r, MANUAL_FLOW_COL_KEY).Value)
        If Len(baseKey) > 0 Then storeIndex(baseKey) = r
    Next r
    lastR = LastUsedRowInSheet(wsFlow)
    If lastR < 2 Then Exit Sub
    data = wsFlow.Range(wsFlow.Cells(2, 1), wsFlow.Cells(lastR, FLOW_ANALYSIS_LAST_COL)).Value2
    For r = 1 To UBound(data, 1)
        If CellText(data(r, 3)) = "�蓮�w��" Then
            storedKey = CellText(data(r, FLOW_ANALYSIS_KEY_COL))
            baseKey = AnalysisBaseKey(storedKey, evidenceText)
            If Not storeIndex.Exists(baseKey) Then _
                Err.Raise vbObjectError + 4960, "SyncManualFlowReviewsFromAnalysisSheet", _
                          "�����t���[�ǐ� " & CStr(r + 1) & "�s�ڂ̎蓮���ۑ��L�^������܂���B"
            statusText = CellText(data(r, FLOW_ANALYSIS_STATUS_COL))
            If Len(statusText) = 0 Then statusText = ANALYSIS_STATUS_UNREVIEWED
            If Not ManualFlowReviewStatus(statusText) Then _
                Err.Raise vbObjectError + 4961, "SyncManualFlowReviewsFromAnalysisSheet", _
                          "�����t���[�ǐ� " & CStr(r + 1) & "�s�ڂ̊m�F�󋵂��s���ł��B"
            memoText = CellText(data(r, FLOW_ANALYSIS_MEMO_COL))
            If Len(memoText) > 1000 Then _
                Err.Raise vbObjectError + 4962, "SyncManualFlowReviewsFromAnalysisSheet", _
                          "�����t���[�ǐ� " & CStr(r + 1) & "�s�ڂ̊m�F�������������܂��B"
            rowNo = CLng(storeIndex(baseKey))
            wsStore.Cells(rowNo, MANUAL_FLOW_COL_STATUS).Value = statusText
            wsStore.Cells(rowNo, MANUAL_FLOW_COL_MEMO).Value = memoText
            wsStore.Cells(rowNo, MANUAL_FLOW_COL_EVIDENCE).Value = evidenceText
            wsStore.Cells(rowNo, MANUAL_FLOW_COL_UPDATED_AT).Value = Now
        End If
    Next r
    SetSheetVeryHiddenSafe wsStore
End Sub

Private Sub WriteManualFlowOutputRow(ByVal ws As Worksheet, ByVal outputRow As Long, _
                                     ByRef sourceData As Variant, ByRef rows() As Long, _
                                     ByVal rowCount As Long, ByVal txIDs As String, _
                                     ByVal amountValue As Double, ByVal statusText As String, _
                                     ByVal memoText As String, ByVal storedKey As String)
    Dim i As Long, rowNo As Long, firstRow As Long, lastRow As Long
    Dim pathText As String, orderText As String, withdrawalText As String, depositText As String
    Dim accountText As String, directionText As String, itemText As String
    Dim hasAnyTime As Boolean, hasAllTimes As Boolean
    hasAllTimes = True
    firstRow = rows(1): lastRow = rows(rowCount)
    For i = 1 To rowCount
        rowNo = rows(i)
        If HasText(sourceData(rowNo, OUT_COL_TIME)) Then hasAnyTime = True Else hasAllTimes = False
        accountText = ManualAccountText(sourceData, rowNo)
        If CDbl(ManualNumber(sourceData(rowNo, OUT_COL_WITHDRAW))) > 0 Then
            directionText = "�o��"
            itemText = ManualTransactionText(sourceData, rowNo, directionText, _
                                              CDbl(sourceData(rowNo, OUT_COL_WITHDRAW)))
            If Len(withdrawalText) > 0 Then withdrawalText = withdrawalText & " / "
            withdrawalText = withdrawalText & itemText
        Else
            directionText = "����"
            itemText = ManualTransactionText(sourceData, rowNo, directionText, _
                                              CDbl(sourceData(rowNo, OUT_COL_DEPOSIT)))
            If Len(depositText) > 0 Then depositText = depositText & " / "
            depositText = depositText & itemText
        End If
        If Len(pathText) > 0 Then pathText = pathText & " �� "
        pathText = pathText & accountText & "�i" & directionText & "�j"
        If Len(orderText) > 0 Then orderText = orderText & " �� "
        orderText = orderText & ManualDateTimeText(sourceData, rowNo) & " " & directionText
    Next i
    ws.Cells(outputRow, 1).Value = "�蓮"
    ws.Cells(outputRow, 2).Value = 100
    ws.Cells(outputRow, 3).Value = "�蓮�w��"
    ws.Cells(outputRow, 4).Value = "���p�ґI��"
    If hasAllTimes Then
        ws.Cells(outputRow, 5).Value = "�S����������"
    ElseIf hasAnyTime Then
        ws.Cells(outputRow, 5).Value = "�������݁E��������"
    Else
        ws.Cells(outputRow, 5).Value = "�����Ȃ��E��������"
    End If
    ws.Cells(outputRow, 6).Value = ManualDateTimeText(sourceData, firstRow) & " �` " & _
                                   ManualDateTimeText(sourceData, lastRow)
    ws.Cells(outputRow, 7).Value = Application.Max(1, rowCount - 1)
    ws.Cells(outputRow, 8).Value = rowCount
    ws.Cells(outputRow, 9).Value = amountValue
    ws.Cells(outputRow, 10).Value = amountValue
    ws.Cells(outputRow, 11).Value = 0
    ws.Cells(outputRow, 12).Value = pathText
    ws.Cells(outputRow, 13).Value = orderText
    ws.Cells(outputRow, 14).Value = withdrawalText
    ws.Cells(outputRow, 15).Value = depositText
    ws.Cells(outputRow, 16).Value = _
        "��������\�ŗ��p�҂��\�������I��B�����Ȃ����܂ޓ��������͓��͏��ɂ�鐄��ł���A�������ł̊m�F���K�v�ł��B"
    ws.Cells(outputRow, 17).Value = statusText
    ws.Cells(outputRow, 18).Value = memoText
    ws.Cells(outputRow, 19).Value = storedKey
    ws.Cells(outputRow, 20).Value = txIDs
    ws.Cells(outputRow, 21).Value = CellText(sourceData(firstRow, WORK_TX_COL_ACCOUNT_ID))
    ws.Cells(outputRow, 22).Value = CellText(sourceData(lastRow, WORK_TX_COL_ACCOUNT_ID))
End Sub

Public Sub DeactivateManualFlowCandidateByStoredKey(ByVal storedKey As String)
    Dim ws As Worksheet, baseKey As String, evidenceText As String
    Dim lastR As Long, r As Long, errorNumber As Long, errorDescription As String
    Dim storeSnapshot As Variant, storeSnapshotLastRow As Long, storeChanged As Boolean
    Dim analysisBuildStarted As Boolean
    Dim reviewsWerePending As Boolean
    If Not RequireToolReady() Then Exit Sub
    If Not RequireInternalStoresSafeForWrite() Then Exit Sub
    On Error GoTo EH
    baseKey = AnalysisBaseKey(storedKey, evidenceText)
    If Left$(baseKey, 7) <> "MANUAL>" Then Exit Sub
    reviewsWerePending = HasPendingAnalysisReviewChanges()
    If MsgBox("���̎蓮���𖳌��ɂ��܂����H" & vbCrLf & _
              "�L�^�͍폜�����A�ォ�瓯�������I�ԂƍėL�����ł��܂��B", _
              vbYesNo + vbQuestion + vbDefaultButton2) <> vbYes Then Exit Sub
    Set ws = GetSheet(SH_WORK_MANUAL_FLOW)
    CaptureManualFlowStoreSnapshot storeSnapshot, storeSnapshotLastRow
    lastR = LastUsedRowInSheet(ws)
    For r = 2 To lastR
        If StrComp(CellText(ws.Cells(r, MANUAL_FLOW_COL_KEY).Value), baseKey, vbBinaryCompare) = 0 Then
            storeChanged = True
            ws.Cells(r, MANUAL_FLOW_COL_ACTIVE).Value = MANUAL_INACTIVE
            ws.Cells(r, MANUAL_FLOW_COL_UPDATED_AT).Value = Now
            MarkAnalysisReviewsDirty
            AppBegin "�蓮���𖳌��ɂ��Ď�������\���X�V���Ă��܂�..."
            analysisBuildStarted = True
            BuildTransactionAnalysisSheetsCore True
            MarkAnalysisReviewsClean
            AppEnd
            MsgBox "�蓮���𖳌��ɂ��܂����B", vbInformation
            Exit Sub
        End If
    Next r
    Err.Raise vbObjectError + 4954, "DeactivateManualFlowCandidateByStoredKey", _
              "�蓮���̕ۑ��L�^��������܂���B"
EH:
    errorNumber = Err.Number: errorDescription = Err.Description
    On Error Resume Next
    If storeChanged Then RestoreManualFlowStoreSnapshot storeSnapshot, storeSnapshotLastRow
    If Err.Number <> 0 Then errorDescription = errorDescription & _
        " / ���[���o�b�N�x��: " & Err.Description
    Err.Clear
    If analysisBuildStarted Or reviewsWerePending Then _
        MarkAnalysisReviewsDirty Else MarkAnalysisReviewsClean
    If analysisBuildStarted Then MarkOutputsDirty
    If IsUserCancelError(errorNumber) Then
        SetInputStatus "�蓮���̖����������𒆒f���܂����B��������\�̕��͕\���͍ŐV�Ƃ͌���܂���B"
    Else
        AddCheck "�G���[", "�蓮��△����", _
                 "Err " & CStr(errorNumber) & ": " & errorDescription
        SetInputStatus "�蓮���̖������Ɏ��s���܂����B��������\�̕��͕\���͍ŐV�Ƃ͌���܂���BC_�`�F�b�N���m�F���Ă��������B"
    End If
    On Error GoTo 0
    AppEnd
    MsgBox OperationFailureHeading(errorNumber, "�蓮���𖳌��ɂł��܂���ł����B") & vbCrLf & _
           OperationFailureDetail(errorNumber, errorDescription), OperationFailureIcon(errorNumber, vbExclamation)
End Sub

Private Sub CaptureManualFlowStoreSnapshot(ByRef snapshot As Variant, ByRef snapshotLastRow As Long)
    Dim ws As Worksheet
    Set ws = GetSheet(SH_WORK_MANUAL_FLOW)
    snapshotLastRow = LastUsedRowInSheet(ws)
    If snapshotLastRow >= 2 Then
        snapshot = ws.Range(ws.Cells(2, 1), _
                            ws.Cells(snapshotLastRow, MANUAL_FLOW_STORE_LAST_COL)).Value2
    Else
        snapshot = Empty
    End If
End Sub

Private Sub RestoreManualFlowStoreSnapshot(ByRef snapshot As Variant, ByVal snapshotLastRow As Long)
    Dim ws As Worksheet, currentLastRow As Long
    On Error GoTo EH
    Set ws = GetSheet(SH_WORK_MANUAL_FLOW)
    currentLastRow = LastUsedRowInSheet(ws)
    If currentLastRow >= 2 Then _
        ws.Range(ws.Cells(2, 1), _
                 ws.Cells(currentLastRow, MANUAL_FLOW_STORE_LAST_COL)).ClearContents
    If snapshotLastRow >= 2 Then _
        ws.Range(ws.Cells(2, 1), _
                 ws.Cells(snapshotLastRow, MANUAL_FLOW_STORE_LAST_COL)).Value = snapshot
    SetSheetVeryHiddenSafe ws
    Exit Sub
EH:
    Err.Raise vbObjectError + 4966, "RestoreManualFlowStoreSnapshot", _
              "�蓮���̑�������ɖ߂��܂���ł���: " & Err.Description
End Sub

Private Sub ValidateManualTransactionIDs(ByVal requestedIDs As String, ByRef txCount As Long, _
                                         ByRef totalWithdrawal As Double, _
                                         ByRef totalDeposit As Double, _
                                         ByRef suggestedAmount As Double, _
                                         ByRef canonicalIDs As String)
    Dim ws As Worksheet, data As Variant, lastR As Long, txIndex As Object
    Dim rows() As Long, rowList As String
    Set ws = GetSheet(SH_WORK_TX)
    lastR = LastUsedRowInSheet(ws)
    If lastR < 2 Then Err.Raise vbObjectError + 4955, , "������o�^����Ă��܂���B"
    data = ws.Range(ws.Cells(2, 1), ws.Cells(lastR, WORK_TX_COL_PERSON_ID)).Value2
    Set txIndex = BuildManualTransactionIndex(data, UBound(data, 1))
    ManualRowsForIDs requestedIDs, txIndex, data, rows, txCount, rowList, canonicalIDs
    ManualTotals data, rows, txCount, totalWithdrawal, totalDeposit
    If totalWithdrawal <= 0 Or totalDeposit <= 0 Then _
        Err.Raise vbObjectError + 4956, , _
                  "�蓮�̎����ړ����ɂ́A�o���Ɠ��������ꂼ��1���ȏ�I�����Ă��������B"
    If totalWithdrawal < totalDeposit Then suggestedAmount = totalWithdrawal Else suggestedAmount = totalDeposit
End Sub

Private Function BuildManualTransactionIndex(ByRef sourceData As Variant, _
                                             ByVal sourceRowCount As Long) As Object
    Dim result As Object, r As Long, txID As String
    Set result = CreateObject("Scripting.Dictionary")
    result.CompareMode = vbTextCompare
    For r = 1 To sourceRowCount
        If CellText(sourceData(r, WORK_TX_COL_RECORD_TYPE)) = RECORD_TRANSACTION Then
            txID = CellText(sourceData(r, WORK_TX_COL_TRANSACTION_ID))
            If Len(txID) > 0 Then
                If result.Exists(txID) Then Err.Raise vbObjectError + 4957, , _
                    "���ID���d�����Ă��܂�: " & txID
                result.Add txID, r
            End If
        End If
    Next r
    Set BuildManualTransactionIndex = result
End Function

Private Sub ManualRowsForIDs(ByVal txIDs As String, ByVal txIndex As Object, _
                             ByRef sourceData As Variant, ByRef rows() As Long, _
                             ByRef rowCount As Long, ByRef rowList As String, _
                             ByRef canonicalIDs As String)
    Dim parts As Variant, item As Variant, wanted As Object, txID As String
    Dim dayHasMissing As Object, i As Long, sourceRow As Long, dateKey As String
    Set wanted = CreateObject("Scripting.Dictionary")
    Set dayHasMissing = CreateObject("Scripting.Dictionary")
    wanted.CompareMode = vbTextCompare
    dayHasMissing.CompareMode = vbTextCompare
    parts = Split(txIDs, ";")
    For Each item In parts
        txID = Trim$(CStr(item))
        If Len(txID) > 0 Then wanted(txID) = True
    Next item
    If wanted.Count < 2 Then Err.Raise vbObjectError + 4958, , "�\�����ID��2�������ł��B"
    ReDim rows(1 To wanted.Count)
    For Each item In wanted.Keys
        txID = CStr(item)
        If Not txIndex.Exists(txID) Then _
            Err.Raise vbObjectError + 4959, , "�\�������������܂���: " & txID
        rowCount = rowCount + 1
        sourceRow = CLng(txIndex(txID))
        rows(rowCount) = sourceRow
        dateKey = Format$(CDate(sourceData(sourceRow, OUT_COL_DATE)), "yyyymmdd")
        If Not HasText(sourceData(sourceRow, OUT_COL_TIME)) Then dayHasMissing(dateKey) = True
    Next item
    If rowCount > 1 Then QuickSortManualRows sourceData, rows, 1, rowCount, dayHasMissing
    For i = 1 To rowCount
        If Len(rowList) > 0 Then rowList = rowList & ";": canonicalIDs = canonicalIDs & ";"
        rowList = rowList & CStr(rows(i))
        canonicalIDs = canonicalIDs & CellText(sourceData(rows(i), WORK_TX_COL_TRANSACTION_ID))
    Next i
End Sub

Private Sub QuickSortManualRows(ByRef data As Variant, ByRef rows() As Long, _
                                ByVal firstIndex As Long, ByVal lastIndex As Long, _
                                ByVal dayHasMissing As Object)
    Dim low As Long, high As Long, pivotRow As Long, tempRow As Long
    low = firstIndex: high = lastIndex: pivotRow = rows((firstIndex + lastIndex) \ 2)
    Do While low <= high
        Do While CompareManualRows(data, rows(low), pivotRow, dayHasMissing) < 0
            low = low + 1
        Loop
        Do While CompareManualRows(data, rows(high), pivotRow, dayHasMissing) > 0
            high = high - 1
        Loop
        If low <= high Then
            tempRow = rows(low): rows(low) = rows(high): rows(high) = tempRow
            low = low + 1: high = high - 1
        End If
    Loop
    If firstIndex < high Then QuickSortManualRows data, rows, firstIndex, high, dayHasMissing
    If low < lastIndex Then QuickSortManualRows data, rows, low, lastIndex, dayHasMissing
End Sub

Private Function CompareManualRows(ByRef data As Variant, ByVal firstRow As Long, _
                                   ByVal secondRow As Long, ByVal dayHasMissing As Object) As Long
    Dim firstDate As Long, secondDate As Long, dateKey As String
    Dim firstOrder As Double, secondOrder As Double, firstTime As Double, secondTime As Double
    firstDate = CLng(VBA.DateValue(CDate(data(firstRow, OUT_COL_DATE))))
    secondDate = CLng(VBA.DateValue(CDate(data(secondRow, OUT_COL_DATE))))
    If firstDate < secondDate Then CompareManualRows = -1: Exit Function
    If firstDate > secondDate Then CompareManualRows = 1: Exit Function
    dateKey = Format$(CDate(firstDate), "yyyymmdd")
    firstOrder = ManualNumber(data(firstRow, WORK_TX_COL_INPUT_ORDER))
    secondOrder = ManualNumber(data(secondRow, WORK_TX_COL_INPUT_ORDER))
    If Not dayHasMissing.Exists(dateKey) Then
        firstTime = ManualTimeNumber(data(firstRow, OUT_COL_TIME))
        secondTime = ManualTimeNumber(data(secondRow, OUT_COL_TIME))
        If firstTime < secondTime Then CompareManualRows = -1: Exit Function
        If firstTime > secondTime Then CompareManualRows = 1: Exit Function
    End If
    If firstOrder < secondOrder Then CompareManualRows = -1 ElseIf firstOrder > secondOrder Then CompareManualRows = 1 ElseIf firstRow < secondRow Then CompareManualRows = -1 ElseIf firstRow > secondRow Then CompareManualRows = 1
End Function

Private Sub ManualTotals(ByRef data As Variant, ByRef rows() As Long, ByVal rowCount As Long, _
                         ByRef totalWithdrawal As Double, ByRef totalDeposit As Double)
    Dim i As Long
    For i = 1 To rowCount
        totalWithdrawal = totalWithdrawal + ManualNumber(data(rows(i), OUT_COL_WITHDRAW))
        totalDeposit = totalDeposit + ManualNumber(data(rows(i), OUT_COL_DEPOSIT))
    Next i
End Sub

Private Sub UpdateManualCandidateStatistics(ByVal txIDs As String, ByVal candidateCounts As Object, _
                                            ByVal bestScores As Object, ByVal bestRatings As Object)
    Dim parts As Variant, item As Variant, txID As String
    parts = Split(txIDs, ";")
    For Each item In parts
        txID = Trim$(CStr(item))
        If Len(txID) > 0 Then
            If candidateCounts.Exists(txID) Then candidateCounts(txID) = CLng(candidateCounts(txID)) + 1 Else candidateCounts.Add txID, 1
            If Not bestScores.Exists(txID) Then
                bestScores.Add txID, 100: bestRatings.Add txID, "�蓮"
            ElseIf CLng(bestScores(txID)) < 100 Then
                bestScores(txID) = 100: bestRatings(txID) = "�蓮"
            End If
        End If
    Next item
End Sub

Private Function ManualDateTimeText(ByRef data As Variant, ByVal rowNo As Long) As String
    ManualDateTimeText = Format$(CDate(data(rowNo, OUT_COL_DATE)), "yyyy/m/d") & " "
    If HasText(data(rowNo, OUT_COL_TIME)) Then
        ManualDateTimeText = ManualDateTimeText & Format$(VBA.TimeValue(CDate(data(rowNo, OUT_COL_TIME))), "hh:mm")
    Else
        ManualDateTimeText = ManualDateTimeText & "--:--"
    End If
End Function

Private Function ManualTransactionText(ByRef data As Variant, ByVal rowNo As Long, _
                                       ByVal directionText As String, ByVal amountValue As Double) As String
    ManualTransactionText = ManualDateTimeText(data, rowNo) & " " & directionText & " " & _
                            Format$(amountValue, "#,##0.########") & " " & ManualAccountText(data, rowNo)
End Function

Private Function ManualAccountText(ByRef data As Variant, ByVal rowNo As Long) As String
    ManualAccountText = CellText(data(rowNo, OUT_COL_BANK)) & " " & _
                        CellText(data(rowNo, OUT_COL_BRANCH)) & " " & _
                        CellText(data(rowNo, OUT_COL_ACCOUNT_TYPE)) & " " & _
                        CellText(data(rowNo, OUT_COL_ACCOUNT_NO))
    ManualAccountText = Trim$(ManualAccountText)
End Function

Private Function ManualNumber(ByVal valueIn As Variant) As Double
    If IsError(valueIn) Or IsNull(valueIn) Or IsEmpty(valueIn) Then Exit Function
    If IsNumeric(valueIn) Then ManualNumber = CDbl(valueIn)
End Function

Private Function ManualTimeNumber(ByVal valueIn As Variant) As Double
    If HasText(valueIn) Then ManualTimeNumber = CDbl(VBA.TimeValue(CDate(valueIn)))
End Function

Private Function JoinManualDictionaryKeys(ByVal values As Object) As String
    Dim item As Variant
    For Each item In values.Keys
        If Len(JoinManualDictionaryKeys) > 0 Then JoinManualDictionaryKeys = JoinManualDictionaryKeys & ";"
        JoinManualDictionaryKeys = JoinManualDictionaryKeys & CStr(item)
    Next item
End Function

Private Function ManualIDSetSignature(ByVal txIDs As String) As String
    Dim parts As Variant, values() As String, item As Variant
    Dim seen As Object, count As Long, i As Long, j As Long, temp As String
    Set seen = CreateObject("Scripting.Dictionary")
    seen.CompareMode = vbTextCompare
    parts = Split(txIDs, ";")
    For Each item In parts
        temp = Trim$(CStr(item))
        If Len(temp) > 0 Then seen(temp) = True
    Next item
    If seen.Count = 0 Then Exit Function
    ReDim values(1 To seen.Count)
    For Each item In seen.Keys
        count = count + 1
        values(count) = UCase$(CStr(item))
    Next item
    For i = 2 To count
        temp = values(i): j = i - 1
        Do While j >= 1
            If StrComp(values(j), temp, vbBinaryCompare) <= 0 Then Exit Do
            values(j + 1) = values(j): j = j - 1
        Loop
        values(j + 1) = temp
    Next i
    For i = 1 To count
        If Len(ManualIDSetSignature) > 0 Then ManualIDSetSignature = ManualIDSetSignature & ";"
        ManualIDSetSignature = ManualIDSetSignature & values(i)
    Next i
End Function

Private Function ManualFlowUserName() As String
    On Error Resume Next
    ManualFlowUserName = Trim$(Application.UserName)
    If Len(ManualFlowUserName) = 0 Then ManualFlowUserName = Trim$(Environ$("Username"))
    If Len(ManualFlowUserName) = 0 Then ManualFlowUserName = "�o�^�Җ��ݒ�"
    On Error GoTo 0
End Function

Private Function ManualFlowReviewStatus(ByVal statusText As String) As Boolean
    Select Case Trim$(statusText)
        Case ANALYSIS_STATUS_UNREVIEWED, ANALYSIS_STATUS_SHIFT_CONFIRMED, _
             ANALYSIS_STATUS_EXCLUDED, ANALYSIS_STATUS_FOLLOWUP
            ManualFlowReviewStatus = True
    End Select
End Function

Public Sub CheckManualFlowStore(ByRef problems As String, _
                                ByRef interfaceWarnings As String, _
                                ByVal includeInterfaceChecks As Boolean)
    Dim ws As Worksheet, wsTx As Worksheet, lastR As Long, txLastR As Long
    Dim data As Variant, txData As Variant, txIndex As Object, seenIDs As Object, seenSets As Object
    Dim r As Long, manualID As String, txIDs As String, activeText As String, statusText As String
    Dim setKey As String, item As Variant, parts As Variant, txID As String
    Dim sourceRow As Long, hasWithdrawal As Boolean, hasDeposit As Boolean
    If Not SheetExists(SH_WORK_MANUAL_FLOW) Then
        problems = problems & "�EW_�蓮������₪����܂���" & vbCrLf
        Exit Sub
    End If
    Set ws = GetSheet(SH_WORK_MANUAL_FLOW)
    Set seenIDs = CreateObject("Scripting.Dictionary")
    Set seenSets = CreateObject("Scripting.Dictionary")
    Set txIndex = CreateObject("Scripting.Dictionary")
    seenIDs.CompareMode = vbTextCompare: seenSets.CompareMode = vbTextCompare
    txIndex.CompareMode = vbTextCompare
    If SheetExists(SH_WORK_TX) Then
        Set wsTx = GetSheet(SH_WORK_TX)
        txLastR = LastUsedRowInSheet(wsTx)
        If txLastR >= 2 Then
            txData = wsTx.Range(wsTx.Cells(2, 1), _
                                wsTx.Cells(txLastR, WORK_TX_COL_PERSON_ID)).Value2
            For r = 1 To UBound(txData, 1)
                If CellText(txData(r, WORK_TX_COL_RECORD_TYPE)) = RECORD_TRANSACTION Then
                    txID = CellText(txData(r, WORK_TX_COL_TRANSACTION_ID))
                    If Len(txID) > 0 And Not txIndex.Exists(txID) Then txIndex.Add txID, r
                End If
            Next r
        End If
    End If
    lastR = LastUsedRowInSheet(ws)
    If lastR >= 2 Then
        data = ws.Range(ws.Cells(2, 1), ws.Cells(lastR, MANUAL_FLOW_STORE_LAST_COL)).Value2
        For r = 1 To UBound(data, 1)
            manualID = CellText(data(r, MANUAL_FLOW_COL_ID))
            txIDs = CellText(data(r, MANUAL_FLOW_COL_TX_IDS))
            activeText = CellText(data(r, MANUAL_FLOW_COL_ACTIVE))
            statusText = CellText(data(r, MANUAL_FLOW_COL_STATUS))
            If Len(manualID) = 0 Or seenIDs.Exists(manualID) Then problems = problems & "�EW_�蓮������� " & CStr(r + 1) & "�s: ID�s���܂��͏d��" & vbCrLf Else seenIDs.Add manualID, True
            If activeText <> MANUAL_ACTIVE And activeText <> MANUAL_INACTIVE Then problems = problems & "�EW_�蓮������� " & CStr(r + 1) & "�s: �L����ԕs��" & vbCrLf
            If Not IsNumeric(data(r, MANUAL_FLOW_COL_AMOUNT)) Or _
               ManualNumber(data(r, MANUAL_FLOW_COL_AMOUNT)) <= 0 Or _
               ManualNumber(data(r, MANUAL_FLOW_COL_AMOUNT)) > MAX_ABS_AMOUNT Then _
                problems = problems & "�EW_�蓮������� " & CStr(r + 1) & "�s: �ǐՊz�s��" & vbCrLf
            If Not ManualFlowReviewStatus(statusText) Then problems = problems & "�EW_�蓮������� " & CStr(r + 1) & "�s: �m�F�󋵕s��" & vbCrLf
            If Len(CellText(data(r, MANUAL_FLOW_COL_MEMO))) > 1000 Then problems = problems & "�EW_�蓮������� " & CStr(r + 1) & "�s: �m�F��������" & vbCrLf
            If StrComp(CellText(data(r, MANUAL_FLOW_COL_KEY)), "MANUAL>" & manualID, vbBinaryCompare) <> 0 Then problems = problems & "�EW_�蓮������� " & CStr(r + 1) & "�s: �m�F�L�[�s��" & vbCrLf
            setKey = ManualIDSetSignature(txIDs)
            If Len(setKey) = 0 Or UBound(Split(setKey, ";")) < 1 Then
                problems = problems & "�EW_�蓮������� " & CStr(r + 1) & "�s: �\�������2������" & vbCrLf
            Else
                hasWithdrawal = False: hasDeposit = False
                parts = Split(setKey, ";")
                For Each item In parts
                    txID = Trim$(CStr(item))
                    If Not txIndex.Exists(txID) Then
                        problems = problems & "�EW_�蓮������� " & CStr(r + 1) & _
                                   "�s: �\�������������܂��� " & txID & vbCrLf
                    Else
                        sourceRow = CLng(txIndex(txID))
                        If ManualNumber(txData(sourceRow, OUT_COL_WITHDRAW)) > 0 Then _
                            hasWithdrawal = True
                        If ManualNumber(txData(sourceRow, OUT_COL_DEPOSIT)) > 0 Then _
                            hasDeposit = True
                    End If
                Next item
                If Not hasWithdrawal Or Not hasDeposit Then _
                    problems = problems & "�EW_�蓮������� " & CStr(r + 1) & _
                               "�s: �o���E�����̗����������Ă��܂���" & vbCrLf
            End If
            If Not IsDate(data(r, MANUAL_FLOW_COL_CREATED_AT)) Or _
               Not IsDate(data(r, MANUAL_FLOW_COL_UPDATED_AT)) Then _
                problems = problems & "�EW_�蓮������� " & CStr(r + 1) & "�s: �o�^�E�X�V�����s��" & vbCrLf
            If Len(CellText(data(r, MANUAL_FLOW_COL_CREATED_BY))) = 0 Then _
                problems = problems & "�EW_�蓮������� " & CStr(r + 1) & "�s: �o�^�҂Ȃ�" & vbCrLf
            If Len(CellText(data(r, MANUAL_FLOW_COL_EVIDENCE))) > 0 And _
               Not ManualEvidenceDigestIsValid(CellText(data(r, MANUAL_FLOW_COL_EVIDENCE))) Then _
                problems = problems & "�EW_�蓮������� " & CStr(r + 1) & "�s: ���������s��" & vbCrLf
            If activeText = MANUAL_ACTIVE And Len(setKey) > 0 Then
                If seenSets.Exists(setKey) Then problems = problems & "�EW_�蓮�������: �L���ȓ���\�����d��" & vbCrLf Else seenSets.Add setKey, True
            End If
            If Len(problems) > 700000 Then Exit For
        Next r
    End If
    If includeInterfaceChecks Then
        If ws.Visible <> xlSheetVeryHidden Then _
            interfaceWarnings = interfaceWarnings & "�EW_�蓮������₪VeryHidden�ł͂���܂���" & vbCrLf
    End If
End Sub

Private Function ManualEvidenceDigestIsValid(ByVal digestText As String) As Boolean
    Dim i As Long, characterText As String
    If Len(digestText) <> 17 Or Mid$(digestText, 9, 1) <> "-" Then Exit Function
    For i = 1 To Len(digestText)
        If i <> 9 Then
            characterText = UCase$(Mid$(digestText, i, 1))
            If InStr(1, "0123456789ABCDEF", characterText, vbBinaryCompare) = 0 Then Exit Function
        End If
    Next i
    ManualEvidenceDigestIsValid = True
End Function

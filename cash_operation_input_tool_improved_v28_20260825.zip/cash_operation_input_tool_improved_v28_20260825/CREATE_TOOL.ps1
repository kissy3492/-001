param(
    [string]$OutputPath = ""
)

$ErrorActionPreference = "Stop"
$currentPhase = "startup"
$sourceDir = Split-Path -Parent $MyInvocation.MyCommand.Path
if ([string]::IsNullOrWhiteSpace($OutputPath)) {
    $OutputPath = Join-Path $sourceDir "cash_operation_input_tool.xlsm"
}
$OutputPath = [System.IO.Path]::GetFullPath($OutputPath)
$outputDir = [System.IO.Path]::GetDirectoryName($OutputPath)
$outputName = [System.IO.Path]::GetFileName($OutputPath)
$setupErrorPath = [System.IO.Path]::ChangeExtension($OutputPath, ".setup_error.txt")
$stageDir = $null
$stagePath = $null
$diagnosticDir = $null
$published = $false
$stageSaved = $false
$setupInvoked = $false
$excel = $null
$workbooks = $null
$workbook = $null
$vbProject = $null
$vbComponents = $null
$thisWorkbookComponent = $null
$codeModule = $null
$escapedName = ""
$sourceTexts = @{}
$sourceManifestHash = ""
$cleanupDetails = New-Object System.Collections.Generic.List[string]

function Convert-ToHex([byte[]]$Bytes) {
    return (($Bytes | ForEach-Object { $_.ToString("x2") }) -join "")
}

function Release-ComObject($Value) {
    if ($null -ne $Value -and [System.Runtime.InteropServices.Marshal]::IsComObject($Value)) {
        try {
            [void][System.Runtime.InteropServices.Marshal]::ReleaseComObject($Value)
        }
        catch {}
    }
}

function Read-StrictCp932([string]$Path, [System.Text.Encoding]$Encoding) {
    [byte[]]$bytes = [System.IO.File]::ReadAllBytes($Path)
    if ($bytes.Length -eq 0) { throw "Source file is empty: $Path" }
    if (($bytes.Length -ge 3 -and $bytes[0] -eq 0xEF -and $bytes[1] -eq 0xBB -and $bytes[2] -eq 0xBF) -or
        ($bytes.Length -ge 2 -and (($bytes[0] -eq 0xFF -and $bytes[1] -eq 0xFE) -or
                                  ($bytes[0] -eq 0xFE -and $bytes[1] -eq 0xFF)))) {
        throw "Source must be BOM-less CP932: $Path"
    }
    $text = $Encoding.GetString($bytes)
    [byte[]]$roundTrip = $Encoding.GetBytes($text)
    $sourceBase64 = [Convert]::ToBase64String($bytes)
    $roundTripBase64 = [Convert]::ToBase64String($roundTrip)
    if (-not [string]::Equals($sourceBase64, $roundTripBase64,
                              [System.StringComparison]::Ordinal)) {
        throw "CP932 round-trip mismatch: $Path"
    }
    if ([regex]::IsMatch($text, "(?<!`r)`n|`r(?!`n)")) {
        throw "Source contains a non-CRLF line ending: $Path"
    }
    return $text
}

function Test-SourcePackage {
    $expectedModules = @(
        "modAdvancedFlowAnalysis.bas", "modAnalysisReviewStore.bas", "modAnalysisWorkspace.bas",
        "modAppState.bas", "modBalanceReconciliation.bas", "modBuildOutputs.bas",
        "modCandidates.bas", "modCashAnalysisView.bas", "modClear.bas", "modConstants.bas",
        "modExternalImport.bas", "modFinalExport.bas", "modManualFlow.bas", "modNavigation.bas",
        "modRecords.bas", "modSetup.bas", "modSetupLog.bas", "modShopConversion.bas",
        "modTransactionAnalysis.bas", "modTransfer.bas", "modUI.bas", "modUtilities.bas"
    )
    $expectedActions = @(
        "ApplyShopConversionToCashOperation", "BuildAllOutputSheets", "BuildBalanceInputFields",
        "BuildShopConversionTargetSheet", "CancelCorrection", "CashAnalysisPrimaryAction",
        "CashAnalysisSecondaryAction", "ClearCurrentAccountInput", "CycleCashAnalysisViewMode",
        "DeleteSelectedAccount", "ExportFinalWorkbooks", "ImportCommonDataWorkbook",
        "ImportExternal13ColumnWorkbook", "InitializeToolData", "InputTabNext", "InputTabPrev",
        "LoadSelectedAccountForEdit", "NextCashAnalysisCandidate", "OpenManualAnalysisCandidateBuilder",
        "OpenRegisteredAccounts", "PreviousCashAnalysisCandidate", "RestoreToolFormatting",
        "RestoreWorkbookAfterOpenCore", "SaveCurrentAccount", "SaveCurrentAccountNextBranch",
        "SelfCheckTool", "SetupWorkbook",
        "ShowAccountTypeCandidates", "ShowBankCandidates", "ShowBranchCandidates",
        "ShowCandidateSheets", "ShowCashAnalysisTransfers", "ShowCashAnalysisUnknownDeposits",
        "ShowCashAnalysisUnknownWithdrawals", "ShowConfigSheet", "ShowInputSheet",
        "ShowPersonCandidates", "ShowRecoveryNotice", "ShowTekiyoCandidates"
    )
    $expectedBooleanFunctions = @(
        "BuildSmokeTest", "BuildInterfaceSmokeTest", "GetLastSetupFailureDetail",
        "PrepareFailedSetupForInspection"
    )

    $actualModules = @(Get-ChildItem -LiteralPath $sourceDir -Filter "*.bas" -File | ForEach-Object { $_.Name })
    $missing = @($expectedModules | Where-Object { $actualModules -notcontains $_ })
    $extra = @($actualModules | Where-Object { $expectedModules -notcontains $_ })
    if ($missing.Count -gt 0 -or $extra.Count -gt 0) {
        throw "VBA module manifest mismatch. Missing=[$($missing -join ', ')] Extra=[$($extra -join ', ')]"
    }
    $thisWorkbookPath = Join-Path $sourceDir "ThisWorkbook_code.txt"
    if (-not [System.IO.File]::Exists($thisWorkbookPath)) {
        throw "ThisWorkbook_code.txt was not found."
    }

    $encoderFallback = New-Object System.Text.EncoderExceptionFallback
    $decoderFallback = New-Object System.Text.DecoderExceptionFallback
    $cp932 = [System.Text.Encoding]::GetEncoding(932, $encoderFallback, $decoderFallback)
    $publicNames = @{}
    $publicSubs = @{}
    $publicFunctions = @{}
    $manifestLines = New-Object System.Collections.Generic.List[string]
    $sha256 = [System.Security.Cryptography.SHA256]::Create()
    try {
        foreach ($moduleFile in $expectedModules) {
            $path = Join-Path $sourceDir $moduleFile
            $text = Read-StrictCp932 $path $cp932
            $sourceTexts[$moduleFile] = $text
            $moduleName = [System.IO.Path]::GetFileNameWithoutExtension($moduleFile)
            $nameMatches = [regex]::Matches($text, '(?im)^Attribute\s+VB_Name\s*=\s*"([^"]+)"\s*$')
            if ($nameMatches.Count -ne 1 -or
                -not [string]::Equals($nameMatches[0].Groups[1].Value, $moduleName,
                                      [System.StringComparison]::OrdinalIgnoreCase)) {
                throw "Attribute VB_Name does not match the filename: $moduleFile"
            }
            if (-not [regex]::IsMatch($text, '(?im)^Option\s+Explicit\s*$')) {
                throw "Option Explicit is missing: $moduleFile"
            }
            if ([regex]::IsMatch($text, '(?im)^\s*(?:Dim|Private|Public|Static|Const)\b[^\r\n]*\b(?:dateValue|timeValue)\b')) {
                throw "A VBA built-in name is shadowed: $moduleFile"
            }

            $logical = [regex]::Replace($text, '_\r\n\s*', ' ')
            foreach ($match in [regex]::Matches($logical, '(?im)^\s*Public\s+(?:Sub|Function|Property\s+(?:Get|Let|Set))\s+([A-Za-z_][A-Za-z0-9_]*)')) {
                $publicName = $match.Groups[1].Value
                if ($publicNames.ContainsKey($publicName)) {
                    throw "Duplicate Public procedure: $publicName ($moduleFile / $($publicNames[$publicName]))"
                }
                $publicNames[$publicName] = $moduleFile
            }
            foreach ($match in [regex]::Matches($logical, '(?im)^\s*Public\s+Sub\s+([A-Za-z_][A-Za-z0-9_]*)\s*(?:\(([^)]*)\))?')) {
                $publicSubs[$match.Groups[1].Value] = $match.Groups[2].Value
            }
            foreach ($match in [regex]::Matches($logical, '(?im)^\s*Public\s+Function\s+([A-Za-z_][A-Za-z0-9_]*)\s*(?:\(([^)]*)\))?')) {
                $publicFunctions[$match.Groups[1].Value] = $match.Groups[2].Value
            }
            foreach ($match in [regex]::Matches($text, '(?ims)^\s*(?:Public|Private|Friend)?\s*(?:Sub|Function|Property\s+(?:Get|Let|Set))\s+[A-Za-z_][A-Za-z0-9_]*.*?^\s*End\s+(?:Sub|Function|Property)\s*$')) {
                if ($cp932.GetByteCount($match.Value) -gt 60000) {
                    throw "A VBA procedure is too large for the release gate: $moduleFile"
                }
            }
            $hash = Convert-ToHex $sha256.ComputeHash([System.IO.File]::ReadAllBytes($path))
            $manifestLines.Add("$hash  $moduleFile")
        }

        $thisWorkbookText = Read-StrictCp932 $thisWorkbookPath $cp932
        if (-not [regex]::IsMatch($thisWorkbookText, '(?im)^Option\s+Explicit\s*$')) {
            throw "Option Explicit is missing: ThisWorkbook_code.txt"
        }
        $sourceTexts["ThisWorkbook_code.txt"] = $thisWorkbookText
        $hash = Convert-ToHex $sha256.ComputeHash([System.IO.File]::ReadAllBytes($thisWorkbookPath))
        $manifestLines.Add("$hash  ThisWorkbook_code.txt")

        foreach ($action in $expectedActions) {
            if (-not $publicSubs.ContainsKey($action)) {
                throw "Button/key action does not resolve to a Public Sub: $action"
            }
            $parameterText = [string]$publicSubs[$action]
            if (-not [string]::IsNullOrWhiteSpace($parameterText)) {
                foreach ($parameter in ($parameterText -split ',')) {
                    if ($parameter -notmatch '(?i)\bOptional\b') {
                        throw "Button/key action has a required parameter: $action"
                    }
                }
            }
        }
        foreach ($functionName in $expectedBooleanFunctions) {
            if (-not $publicFunctions.ContainsKey($functionName)) {
                throw "Build verification function does not resolve to a Public Function: $functionName"
            }
            $parameterText = [string]$publicFunctions[$functionName]
            if (-not [string]::IsNullOrWhiteSpace($parameterText)) {
                foreach ($parameter in ($parameterText -split ',')) {
                    if ($parameter -notmatch '(?i)\bOptional\b') {
                        throw "Build verification function has a required parameter: $functionName"
                    }
                }
            }
        }

        $allSourceText = ($sourceTexts.Values -join "`r`n")
        $logicalSourceText = [regex]::Replace($allSourceText, '_\r\n\s*', ' ')
        $requiredContracts = @{
            "SetupWorkbook" = '(?im)^\s*Public\s+Sub\s+SetupWorkbook\s*\(\s*Optional\s+ByVal\s+unattended\s+As\s+Boolean\s*=\s*False\s*\)\s*$'
            "RestoreWorkbookAfterOpenCore" = '(?im)^\s*Public\s+Sub\s+RestoreWorkbookAfterOpenCore\s*\(\s*Optional\s+ByVal\s+strictBuildVerification\s+As\s+Boolean\s*=\s*False\s*\)\s*$'
            "BuildSmokeTest" = '(?im)^\s*Public\s+Function\s+BuildSmokeTest\s*\(\s*\)\s+As\s+Boolean\s*$'
            "BuildInterfaceSmokeTest" = '(?im)^\s*Public\s+Function\s+BuildInterfaceSmokeTest\s*\(\s*\)\s+As\s+Boolean\s*$'
            "GetLastSetupFailureDetail" = '(?im)^\s*Public\s+Function\s+GetLastSetupFailureDetail\s*\(\s*\)\s+As\s+String\s*$'
            "PrepareFailedSetupForInspection" = '(?im)^\s*Public\s+Function\s+PrepareFailedSetupForInspection\s*\(\s*\)\s+As\s+Boolean\s*$'
        }
        foreach ($contractName in $requiredContracts.Keys) {
            if (-not [regex]::IsMatch($logicalSourceText, $requiredContracts[$contractName])) {
                throw "Build API signature mismatch: $contractName"
            }
        }
        if (-not [regex]::IsMatch($thisWorkbookText, '(?im)^\s*Private\s+Sub\s+Workbook_Open\s*\(\s*\)\s*$')) {
            throw "ThisWorkbook.Workbook_Open signature is missing or invalid."
        }
        $manifestText = ($manifestLines -join "`n") + "`n"
        $script:sourceManifestHash = Convert-ToHex $sha256.ComputeHash([System.Text.Encoding]::UTF8.GetBytes($manifestText))
    }
    finally {
        $sha256.Dispose()
    }
}

function Assert-VbaFunction([string]$MacroName) {
    $result = $excel.Run("'$escapedName'!$MacroName")
    if (-not [System.Convert]::ToBoolean($result)) {
        $detail = [string]$excel.Run("'$escapedName'!GetLastSetupFailureDetail")
        throw "$MacroName failed: $detail"
    }
}

function Assert-WorkbookNotOpen([string]$Path) {
    $expectedPath = [System.IO.Path]::GetFullPath($Path)
    for ($workbookIndex = 1; $workbookIndex -le $workbooks.Count; $workbookIndex++) {
        $candidateWorkbook = $null
        try {
            $candidateWorkbook = $workbooks.Item($workbookIndex)
            $candidatePath = [System.IO.Path]::GetFullPath([string]$candidateWorkbook.FullName)
            if ([string]::Equals($candidatePath, $expectedPath,
                                 [System.StringComparison]::OrdinalIgnoreCase)) {
                throw "Workbook.Close did not close the staged workbook: $expectedPath"
            }
        }
        finally { Release-ComObject $candidateWorkbook }
    }
}

function Test-MacroWorkbookPackage([string]$Path) {
    if (-not [System.IO.File]::Exists($Path)) { throw "Workbook file is missing: $Path" }
    if ((Get-Item -LiteralPath $Path).Length -le 0) { throw "Workbook file is empty: $Path" }
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $archive = [System.IO.Compression.ZipFile]::OpenRead($Path)
    try {
        $entryNames = @($archive.Entries | ForEach-Object { $_.FullName })
        $vbaProjectEntry = $archive.GetEntry("xl/vbaProject.bin")
        if ($entryNames -notcontains "xl/vbaProject.bin" -or $null -eq $vbaProjectEntry) {
            throw "The generated workbook has no xl/vbaProject.bin."
        }
        if ($vbaProjectEntry.Length -le 0) { throw "The generated xl/vbaProject.bin is empty." }
        $contentTypeEntry = $archive.GetEntry("[Content_Types].xml")
        if ($null -eq $contentTypeEntry) { throw "[Content_Types].xml is missing." }
        $reader = New-Object System.IO.StreamReader($contentTypeEntry.Open())
        try { $contentTypes = $reader.ReadToEnd() } finally { $reader.Dispose() }
        if ($contentTypes -notmatch 'application/vnd\.ms-excel\.sheet\.macroEnabled\.main\+xml') {
            throw "The workbook content type is not macro-enabled."
        }
    }
    finally {
        $archive.Dispose()
    }
}

try {
    $currentPhase = "output preflight"
    if ([System.IO.Path]::GetExtension($OutputPath) -ne ".xlsm") {
        throw "OutputPath must use the .xlsm extension: $OutputPath"
    }
    if ([System.IO.File]::Exists($OutputPath)) {
        throw "Output already exists. Move or rename it first: $OutputPath"
    }
    [void][System.IO.Directory]::CreateDirectory($outputDir)

    $currentPhase = "source preflight"
    Test-SourcePackage
    Write-Host "Source preflight passed. Manifest SHA-256: $sourceManifestHash"

    $stageDir = Join-Path $outputDir (".cashop-build-" + [Guid]::NewGuid().ToString("N"))
    [void][System.IO.Directory]::CreateDirectory($stageDir)
    $stagePath = Join-Path $stageDir $outputName

    $currentPhase = "Excel startup"
    $excel = New-Object -ComObject Excel.Application
    $excel.Visible = $false
    $excel.DisplayAlerts = $false
    $excel.EnableEvents = $false
    $workbooks = $excel.Workbooks
    $xlWBATWorksheet = -4167
    $workbook = $workbooks.Add($xlWBATWorksheet)

    $currentPhase = "VBA project access"
    try {
        $vbProject = $workbook.VBProject
        $vbComponents = $vbProject.VBComponents
        $null = $vbComponents.Count
    }
    catch {
        $originalMessage = $_.Exception.Message
        $originalHResult = ('0x{0:X8}' -f ($_.Exception.HResult -band 0xffffffffL))
        throw "Excel could not access the VBA project. If Excel blocked programmatic access, enable 'Trust access to the VBA project object model', then run CREATE_TOOL.cmd again. Original error: $originalMessage (HRESULT $originalHResult)"
    }

    $currentPhase = "VBA injection"
    $expectedModuleNames = @($sourceTexts.Keys | Where-Object { $_ -like "*.bas" } |
                             ForEach-Object { [System.IO.Path]::GetFileNameWithoutExtension($_) } | Sort-Object)
    foreach ($moduleName in $expectedModuleNames) {
        $moduleFile = "$moduleName.bas"
        $component = $null
        $moduleCode = $null
        try {
            $component = $vbComponents.Add(1)
            $component.Name = $moduleName
            if ($component.Name -ne $moduleName) { throw "VBE renamed module $moduleName to $($component.Name)." }
            $moduleCode = $component.CodeModule
            # Some VBE settings pre-populate a new module with Option Explicit.
            # Start from a truly empty CodeModule so the source read-back is deterministic.
            if ($moduleCode.CountOfLines -gt 0) {
                $moduleCode.DeleteLines(1, $moduleCode.CountOfLines)
            }
            $visibleCode = [regex]::Replace([string]$sourceTexts[$moduleFile],
                                            '(?im)^Attribute\s+VB_Name\s*=\s*"[^"]+"\s*\r\n?', '')
            $moduleCode.AddFromString($visibleCode)
            if ($moduleCode.CountOfLines -lt 2) { throw "No code was injected into $moduleName." }
            $readBack = $moduleCode.Lines(1, $moduleCode.CountOfLines)
            $expectedReadBack = ($visibleCode -replace "`r`n", "`n").TrimEnd()
            $actualReadBack = ([string]$readBack -replace "`r`n", "`n").TrimEnd()
            if (-not [string]::Equals($actualReadBack, $expectedReadBack,
                                      [System.StringComparison]::Ordinal)) {
                throw "Injected code read-back mismatch for $moduleName."
            }
        }
        finally {
            Release-ComObject $moduleCode
            Release-ComObject $component
        }
    }

    $thisWorkbookComponent = $vbComponents.Item("ThisWorkbook")
    $codeModule = $thisWorkbookComponent.CodeModule
    if ($codeModule.CountOfLines -gt 0) { $codeModule.DeleteLines(1, $codeModule.CountOfLines) }
    $codeModule.AddFromString([string]$sourceTexts["ThisWorkbook_code.txt"])
    $thisWorkbookReadBack = $codeModule.Lines(1, $codeModule.CountOfLines)
    $expectedThisWorkbookReadBack = ([string]$sourceTexts["ThisWorkbook_code.txt"] -replace "`r`n", "`n").TrimEnd()
    $actualThisWorkbookReadBack = ([string]$thisWorkbookReadBack -replace "`r`n", "`n").TrimEnd()
    if ($codeModule.CountOfLines -lt 2 -or
        -not [string]::Equals($actualThisWorkbookReadBack, $expectedThisWorkbookReadBack,
                              [System.StringComparison]::Ordinal)) {
        throw "ThisWorkbook code read-back failed."
    }

    $actualStandardModules = New-Object System.Collections.Generic.List[string]
    for ($index = 1; $index -le $vbComponents.Count; $index++) {
        $component = $null
        try {
            $component = $vbComponents.Item($index)
            if ([int]$component.Type -eq 1) { $actualStandardModules.Add([string]$component.Name) }
        }
        finally { Release-ComObject $component }
    }
    $actualStandardModules = @($actualStandardModules | Sort-Object)
    if (($actualStandardModules -join "`n") -ne ($expectedModuleNames -join "`n")) {
        throw "Injected VBA component set does not match the manifest."
    }

    $references = $null
    try {
        $references = $vbProject.References
        for ($index = 1; $index -le $references.Count; $index++) {
            $reference = $null
            try {
                $reference = $references.Item($index)
                if ([System.Convert]::ToBoolean($reference.IsBroken)) {
                    throw "Broken VBA reference: $($reference.Name)"
                }
            }
            finally { Release-ComObject $reference }
        }
    }
    finally { Release-ComObject $references }

    # Release all VBIDE wrappers before any close/reopen check. Lingering child COM
    # objects can keep the staged file locked even after Workbook.Close.
    Release-ComObject $codeModule; $codeModule = $null
    Release-ComObject $thisWorkbookComponent; $thisWorkbookComponent = $null
    Release-ComObject $vbComponents; $vbComponents = $null
    Release-ComObject $vbProject; $vbProject = $null

    $currentPhase = "staged workbook save"
    $xlOpenXmlWorkbookMacroEnabled = 52
    $workbook.SaveAs($stagePath, $xlOpenXmlWorkbookMacroEnabled)
    $stageSaved = $true
    if (-not [string]::Equals([System.IO.Path]::GetFullPath([string]$workbook.FullName),
                              [System.IO.Path]::GetFullPath($stagePath),
                              [System.StringComparison]::OrdinalIgnoreCase)) {
        throw "Excel saved the workbook to an unexpected path: $($workbook.FullName)"
    }
    if ([int]$workbook.FileFormat -ne $xlOpenXmlWorkbookMacroEnabled) {
        throw "Excel saved the staged workbook with an unexpected file format."
    }

    $currentPhase = "unattended setup"
    $excel.EnableEvents = $true
    $escapedName = $workbook.Name.Replace("'", "''")
    $setupInvoked = $true
    $null = $excel.Run("'$escapedName'!SetupWorkbook", $true)
    $setupDetail = [string]$excel.Run("'$escapedName'!GetLastSetupFailureDetail")
    if (-not [string]::IsNullOrWhiteSpace($setupDetail)) { throw "Setup failed: $setupDetail" }
    Assert-VbaFunction "BuildSmokeTest"
    Assert-VbaFunction "BuildInterfaceSmokeTest"

    $currentPhase = "post-save verification"
    $workbook.Save()
    if (-not [System.Convert]::ToBoolean($workbook.Saved)) {
        throw "Excel did not confirm the staged workbook save."
    }
    Assert-VbaFunction "BuildSmokeTest"
    Assert-VbaFunction "BuildInterfaceSmokeTest"
    $excel.EnableEvents = $false
    $workbook.Close($false)
    Assert-WorkbookNotOpen $stagePath
    Release-ComObject $workbook
    $workbook = $null
    [GC]::Collect()
    [GC]::WaitForPendingFinalizers()

    $currentPhase = "reopen verification"
    $excel.AutomationSecurity = 1
    $excel.EnableEvents = $false
    $missing = [Type]::Missing
    $workbook = $workbooks.Open($stagePath, 0, $false, $missing, $missing, $missing,
                                $true, $missing, $missing, $missing, $false, $missing,
                                $false, $missing, 0)
    if (-not [string]::Equals([System.IO.Path]::GetFullPath([string]$workbook.FullName),
                              [System.IO.Path]::GetFullPath($stagePath),
                              [System.StringComparison]::OrdinalIgnoreCase)) {
        throw "Excel reopened an unexpected workbook path: $($workbook.FullName)"
    }
    if ([System.Convert]::ToBoolean($workbook.ReadOnly)) {
        throw "The staged workbook reopened as read-only."
    }
    if ([int]$workbook.FileFormat -ne $xlOpenXmlWorkbookMacroEnabled) {
        throw "The reopened workbook format is not macro-enabled."
    }
    if (-not [System.Convert]::ToBoolean($workbook.Saved)) {
        throw "Excel reports unsaved or repaired content immediately after reopen."
    }
    $escapedName = $workbook.Name.Replace("'", "''")
    $null = $excel.Run("'$escapedName'!RestoreWorkbookAfterOpenCore", $true)
    Assert-VbaFunction "BuildSmokeTest"
    Assert-VbaFunction "BuildInterfaceSmokeTest"
    $excel.EnableEvents = $false
    $workbook.Close($false)
    Assert-WorkbookNotOpen $stagePath
    Release-ComObject $workbook
    $workbook = $null

    $currentPhase = "package verification"
    Test-MacroWorkbookPackage $stagePath
    $finalHash = (Get-FileHash -LiteralPath $stagePath -Algorithm SHA256).Hash.ToLowerInvariant()

    $currentPhase = "Excel shutdown"
    $excel.Quit()
    Release-ComObject $codeModule; $codeModule = $null
    Release-ComObject $thisWorkbookComponent; $thisWorkbookComponent = $null
    Release-ComObject $vbComponents; $vbComponents = $null
    Release-ComObject $vbProject; $vbProject = $null
    Release-ComObject $workbooks; $workbooks = $null
    Release-ComObject $excel; $excel = $null
    [GC]::Collect()
    [GC]::WaitForPendingFinalizers()

    $currentPhase = "atomic publication"
    if ([System.IO.File]::Exists($OutputPath)) {
        throw "Another process created the final output during the build: $OutputPath"
    }
    if ([System.IO.File]::Exists($setupErrorPath)) {
        try { [System.IO.File]::Delete($setupErrorPath) }
        catch { throw "Could not remove the previous setup error report: $setupErrorPath / $($_.Exception.Message)" }
        if ([System.IO.File]::Exists($setupErrorPath)) {
            throw "The previous setup error report still exists: $setupErrorPath"
        }
    }
    [System.IO.File]::Move($stagePath, $OutputPath)
    $published = $true
    try { [System.IO.Directory]::Delete($stageDir, $false) } catch {}
    $stageDir = $null
    Write-Host "Tool created and verified: $OutputPath"
    Write-Host "Workbook SHA-256: $finalHash"
    Write-Host "No incomplete workbook was published under the final filename."
}
catch {
    $failureMessage = $_.Exception.Message
    $canSaveDiagnosticWorkbook = $false

    if ($null -ne $workbook -and $stageSaved -and
        -not [string]::IsNullOrWhiteSpace($stagePath) -and
        [System.IO.File]::Exists($stagePath)) {
        try {
            $workbookPath = [System.IO.Path]::GetFullPath([string]$workbook.FullName)
            $expectedStagePath = [System.IO.Path]::GetFullPath($stagePath)
            $canSaveDiagnosticWorkbook = [string]::Equals(
                $workbookPath, $expectedStagePath, [System.StringComparison]::OrdinalIgnoreCase)
            if (-not $canSaveDiagnosticWorkbook) {
                $cleanupDetails.Add("Diagnostic save skipped because the open workbook path did not match the staged path.")
            }
        }
        catch {
            $cleanupDetails.Add("Could not verify the staged workbook path: $($_.Exception.Message)")
        }
    }

    if ($null -ne $excel) {
        try { $excel.EnableEvents = $false }
        catch { $cleanupDetails.Add("Could not disable Excel events during cleanup: $($_.Exception.Message)") }
    }
    if ($null -ne $workbook -and $canSaveDiagnosticWorkbook -and $setupInvoked -and
        -not [string]::IsNullOrWhiteSpace([string]$escapedName)) {
        try {
            $inspectionPrepared = [System.Convert]::ToBoolean(
                $excel.Run("'$escapedName'!PrepareFailedSetupForInspection"))
            if (-not $inspectionPrepared) {
                $cleanupDetails.Add("PrepareFailedSetupForInspection returned False.")
            }
        }
        catch { $cleanupDetails.Add("Could not prepare the failed setup workbook for inspection: $($_.Exception.Message)") }
    }
    if ($null -ne $workbook -and $canSaveDiagnosticWorkbook) {
        try { $workbook.Save() }
        catch { $cleanupDetails.Add("Could not save the diagnostic staged workbook: $($_.Exception.Message)") }
    }

    # Release VBIDE children before closing Excel. They can otherwise retain a file lock.
    Release-ComObject $codeModule; $codeModule = $null
    Release-ComObject $thisWorkbookComponent; $thisWorkbookComponent = $null
    Release-ComObject $vbComponents; $vbComponents = $null
    Release-ComObject $vbProject; $vbProject = $null

    if ($null -ne $workbook) {
        try { $workbook.Close($false) }
        catch { $cleanupDetails.Add("Could not close the workbook: $($_.Exception.Message)") }
        if ($null -ne $workbooks -and -not [string]::IsNullOrWhiteSpace($stagePath)) {
            try { Assert-WorkbookNotOpen $stagePath }
            catch { $cleanupDetails.Add($_.Exception.Message) }
        }
    }
    Release-ComObject $workbook; $workbook = $null
    if ($null -ne $excel) {
        try { $excel.Quit() }
        catch { $cleanupDetails.Add("Could not quit Excel: $($_.Exception.Message)") }
    }
    Release-ComObject $workbooks; $workbooks = $null
    Release-ComObject $excel; $excel = $null
    [GC]::Collect()
    [GC]::WaitForPendingFinalizers()

    if (-not $published -and -not [string]::IsNullOrWhiteSpace($stageDir) -and
        [System.IO.Directory]::Exists($stageDir)) {
        if (-not [string]::IsNullOrWhiteSpace($stagePath) -and [System.IO.File]::Exists($stagePath)) {
            $stamp = [DateTime]::Now.ToString("yyyyMMdd_HHmmss")
            $diagnosticDir = Join-Path $outputDir (".cashop-failed-" + $stamp + "-" + [Guid]::NewGuid().ToString("N").Substring(0, 8))
            try { [System.IO.Directory]::Move($stageDir, $diagnosticDir) }
            catch {
                $cleanupDetails.Add("Could not move the failed build folder: $($_.Exception.Message)")
                $diagnosticDir = $stageDir
            }
        }
        else {
            try { [System.IO.Directory]::Delete($stageDir, $true) }
            catch { $cleanupDetails.Add("Could not remove the empty staging folder: $($_.Exception.Message)") }
        }
    }

    $cleanupText = if ($cleanupDetails.Count -gt 0) {
        ($cleanupDetails | ForEach-Object { "- $_" }) -join [Environment]::NewLine
    }
    else {
        "- Cleanup completed without an additional error."
    }
    $diagnosticText = @(
        "Tool creation failed.",
        "Phase: $currentPhase",
        "Error: $failureMessage",
        "Final output: $OutputPath",
        "Final output published: $published",
        "Diagnostic build folder: $diagnosticDir",
        "Source manifest SHA-256: $sourceManifestHash",
        "Cleanup details:",
        $cleanupText,
        "Important: no failed workbook is intentionally published under the final filename."
    ) -join [Environment]::NewLine
    $sidecarWritten = $false
    try {
        $utf8WithBom = New-Object System.Text.UTF8Encoding($true)
        [System.IO.File]::WriteAllText($setupErrorPath, $diagnosticText, $utf8WithBom)
        $sidecarWritten = [System.IO.File]::Exists($setupErrorPath) -and
                          ((Get-Item -LiteralPath $setupErrorPath).Length -gt 0)
    }
    catch {
        [Console]::Error.WriteLine("Could not write the error-details file: $($_.Exception.Message)")
    }
    [Console]::Error.WriteLine("Tool creation failed during '$currentPhase': $failureMessage")
    if (-not [string]::IsNullOrWhiteSpace($diagnosticDir)) {
        [Console]::Error.WriteLine("Diagnostic build folder: $diagnosticDir")
    }
    if ($sidecarWritten) {
        [Console]::Error.WriteLine("Error details: $setupErrorPath")
    }
    else {
        [Console]::Error.WriteLine("The error-details file could not be created.")
    }
    exit 1
}
finally {
    if ($null -ne $excel) { try { $excel.EnableEvents = $false } catch {} }
    Release-ComObject $codeModule
    Release-ComObject $thisWorkbookComponent
    Release-ComObject $vbComponents
    Release-ComObject $vbProject
    if ($null -ne $workbook) { try { $workbook.Close($false) } catch {} }
    if ($null -ne $excel) { try { $excel.Quit() } catch {} }
    Release-ComObject $workbook
    Release-ComObject $workbooks
    Release-ComObject $excel
}

Attribute VB_Name = "modExternalImport"
Option Explicit

Private Const PREP_BANK As Long = 1
Private Const PREP_BRANCH As Long = 2
Private Const PREP_PERSON As Long = 3
Private Const PREP_RELATIONSHIP As Long = 4
Private Const PREP_TYPE As Long = 5
Private Const PREP_ACCOUNT_NO As Long = 6
Private Const PREP_DATE As Long = 7
Private Const PREP_TIME As Long = 8
Private Const PREP_WITHDRAW As Long = 9
Private Const PREP_DEPOSIT As Long = 10
Private Const PREP_SHOP As Long = 11
Private Const PREP_MACHINE As Long = 12
Private Const PREP_TEKIYO As Long = 13
Private Const PREP_AFTER_BALANCE As Long = 14
Private Const PREP_RECORD_TYPE As Long = 15
Private Const PREP_INPUT_ORDER As Long = 16
Private Const PREP_LAST_COL As Long = 16
Private Const MAX_EXTERNAL_DATA_ROWS As Long = 100000
Private Const MAX_EXTERNAL_COLUMNS As Long = 200
Private Const MAX_SOURCE_SHEETS As Long = 100
Private Const MAX_COMMON_TOTAL_ROWS As Long = 100000

Public Sub ImportExternal13ColumnWorkbook()
    Dim filePath As String
    Dim sourceBook As Workbook, sourceSheet As Worksheet
    Dim previousSecurity As Long
    Dim headerRow As Long, lastRow As Long, lastCol As Long
    Dim values As Variant, prepared() As Variant, mappedColumns As Variant, columnItem As Variant
    Dim bankCol As Long, branchCol As Long, personCol As Long, typeCol As Long, accountCol As Long
    Dim dateCol As Long, timeCol As Long, withdrawCol As Long, depositCol As Long
    Dim shopCol As Long, machineCol As Long, tekiyoCol As Long, balanceCol As Long
    Dim firstDataCol As Long, lastDataCol As Long
    Dim accountSourceCol As Long, shopSourceCol As Long, machineSourceCol As Long
    Dim sourceRow As Long, preparedCount As Long, errorCount As Long
    Dim firstError As String, firstErrorRow As Long
    Dim bankName As String, branchName As String, personName As String, relationshipText As String
    Dim accountType As String, accountNo As String, tekiyoText As String, recordType As String
    Dim shopText As String, machineText As String
    Dim txDate As Variant, txTime As Variant, withdrawValue As Variant, depositValue As Variant, afterBalance As Variant
    Dim ok As Boolean, amountOK As Boolean, securityChanged As Boolean
    Dim importedCount As Long, duplicateCount As Long, accountCount As Long
    Dim errorNumber As Long, errorDescription As String
    Dim relationshipIndex As Object

    If Not RequireToolReady() Then Exit Sub
    filePath = PickWorkbookFile("�捞���̎�������\��I�����Ă�������", False)
    If Len(filePath) = 0 Then Exit Sub
    If Len(ThisWorkbook.FullName) > 0 Then
        If StrComp(filePath, ThisWorkbook.FullName, vbTextCompare) = 0 Then
            MsgBox "��ƒ��̃c�[�����g�͎捞���Ɏw��ł��܂���B", vbExclamation
            Exit Sub
        End If
    End If

    On Error GoTo EH
    AppBegin "�O���u�b�N�����S�ɓǂݍ���ł��܂�..."
    '�ǋL�O�͓����ۊǂ��������i�m�F���A��ʕ��E�}�`�E�����[�Ȃ�
    '�捞�Ɩ��֌W�Ȋ��S�Z���t�`�F�b�N���ڂł͏������~�߂Ȃ��B
    If Not RequireInternalStoresSafeForWrite() Then
        AppEnd
        Exit Sub
    End If
    previousSecurity = Application.AutomationSecurity
    Application.AutomationSecurity = msoAutomationSecurityForceDisable
    securityChanged = True
    Set sourceBook = Workbooks.Open(Filename:=filePath, UpdateLinks:=0, ReadOnly:=True, _
                                    AddToMru:=False, IgnoreReadOnlyRecommended:=True, Notify:=False)
    If sourceBook.Worksheets.Count > MAX_SOURCE_SHEETS Then
        Err.Raise vbObjectError + 6107, "ImportExternal13ColumnWorkbook", _
                  "�捞���̃V�[�g��������i" & CStr(MAX_SOURCE_SHEETS) & "���j�𒴂��Ă��܂��B"
    End If
    Set sourceSheet = FindExternalTableSheet(sourceBook, headerRow)
    If sourceSheet Is Nothing Then Err.Raise vbObjectError + 6101, "ImportExternal13ColumnWorkbook", "13��\�̌��o�����������܂���B"

    lastCol = ExternalLastUsedColumn(sourceSheet)
    If lastCol > MAX_EXTERNAL_COLUMNS Then
        Err.Raise vbObjectError + 6106, "ImportExternal13ColumnWorkbook", _
                  "�g�p�񂪑������܂��B�捞�\��K�v�񂾂��̃V�[�g�֐������Ă��������B"
    End If
    If lastCol < 1 Then Err.Raise vbObjectError + 8012, "ImportExternal13ColumnWorkbook", "�捞�\�̗���m�F�ł��܂���B"

    '��Ɍ��o��1�s������ǂ݁A���f�[�^�͔F����������܂ލŏ��͈͂Ɍ��肷��B
    '�ő�200��~10���s�𖳏����ɔz�񉻂����A�ʏ��13��\�Ń������g�p�ʂ�啝�ɗ}����B
    values = sourceSheet.Range(sourceSheet.Cells(headerRow, 1), sourceSheet.Cells(headerRow, lastCol)).Value2

    bankCol = FindHeaderColumn(values, 1)
    branchCol = FindHeaderColumn(values, 2)
    personCol = FindHeaderColumn(values, 3)
    typeCol = FindHeaderColumn(values, 4)
    accountCol = FindHeaderColumn(values, 5)
    dateCol = FindHeaderColumn(values, 6)
    timeCol = FindHeaderColumn(values, 7)       '�������o�����Ȃ����0�B�ق��̗񂩂琄�����Ȃ��B
    withdrawCol = FindHeaderColumn(values, 8)
    depositCol = FindHeaderColumn(values, 9)
    shopCol = FindHeaderColumn(values, 10)
    machineCol = FindHeaderColumn(values, 11)
    tekiyoCol = FindHeaderColumn(values, 12)
    balanceCol = FindHeaderColumn(values, 13)   '��13��͎����c���B�N���c���ɂ͓]�p���Ȃ��B

    ValidateExternalHeaders bankCol, branchCol, personCol, typeCol, accountCol, dateCol, _
                            withdrawCol, depositCol, shopCol, machineCol, tekiyoCol, balanceCol
    ValidateExternalHeaderUniqueness values

    mappedColumns = Array(bankCol, branchCol, personCol, typeCol, accountCol, dateCol, timeCol, _
                          withdrawCol, depositCol, shopCol, machineCol, tekiyoCol, balanceCol)
    firstDataCol = lastCol
    For Each columnItem In mappedColumns
        If CLng(columnItem) > 0 Then
            If CLng(columnItem) < firstDataCol Then firstDataCol = CLng(columnItem)
            If CLng(columnItem) > lastDataCol Then lastDataCol = CLng(columnItem)
        End If
    Next columnItem
    lastRow = ExternalLastMappedDataRow(sourceSheet, headerRow, mappedColumns)
    If lastRow <= headerRow Then Err.Raise vbObjectError + 6102, "ImportExternal13ColumnWorkbook", "���o����艺�Ɏ���f�[�^������܂���B"
    If lastRow - headerRow > MAX_EXTERNAL_DATA_ROWS Then
        Err.Raise vbObjectError + 6105, "ImportExternal13ColumnWorkbook", _
                  "�捞�s������i" & Format$(MAX_EXTERNAL_DATA_ROWS, "#,##0") & "�s�j�𒴂��Ă��܂��B�t�@�C���𕪊����Ă��������B"
    End If
    ValidateExternalMappedColumnsNoFormulas sourceSheet, headerRow, lastRow, mappedColumns

    accountSourceCol = accountCol
    shopSourceCol = shopCol
    machineSourceCol = machineCol
    values = sourceSheet.Range(sourceSheet.Cells(headerRow, firstDataCol), _
                               sourceSheet.Cells(lastRow, lastDataCol)).Value2
    bankCol = bankCol - firstDataCol + 1
    branchCol = branchCol - firstDataCol + 1
    personCol = personCol - firstDataCol + 1
    typeCol = typeCol - firstDataCol + 1
    accountCol = accountCol - firstDataCol + 1
    dateCol = dateCol - firstDataCol + 1
    If timeCol > 0 Then timeCol = timeCol - firstDataCol + 1
    withdrawCol = withdrawCol - firstDataCol + 1
    depositCol = depositCol - firstDataCol + 1
    shopCol = shopCol - firstDataCol + 1
    machineCol = machineCol - firstDataCol + 1
    tekiyoCol = tekiyoCol - firstDataCol + 1
    balanceCol = balanceCol - firstDataCol + 1
    '�����̑������s���ƂɌ��E�����S������T���Ƒ�ʎ捞����掞�ԂɂȂ邽�߁A
    '�l�������Ƃ̈�ӂȑ�������x��������������B
    Set relationshipIndex = BuildExistingRelationshipLookup()

    ReDim prepared(1 To UBound(values, 1) - 1, 1 To PREP_LAST_COL)
    For sourceRow = 2 To UBound(values, 1)
        If ExternalArrayRowHasData(values, sourceRow) Then
            AddExternalCellValueError values(sourceRow, bankCol), "��s��", sourceRow + headerRow - 1, errorCount, firstError, firstErrorRow
            AddExternalCellValueError values(sourceRow, branchCol), "�x�X��", sourceRow + headerRow - 1, errorCount, firstError, firstErrorRow
            AddExternalCellValueError values(sourceRow, personCol), "����", sourceRow + headerRow - 1, errorCount, firstError, firstErrorRow
            AddExternalCellValueError values(sourceRow, typeCol), "�Ȗ�", sourceRow + headerRow - 1, errorCount, firstError, firstErrorRow
            AddExternalCellValueError values(sourceRow, accountCol), "�����ԍ�", sourceRow + headerRow - 1, errorCount, firstError, firstErrorRow
            AddExternalCellValueError values(sourceRow, dateCol), "���t", sourceRow + headerRow - 1, errorCount, firstError, firstErrorRow
            If timeCol > 0 Then _
                AddExternalCellValueError values(sourceRow, timeCol), "����", sourceRow + headerRow - 1, errorCount, firstError, firstErrorRow
            AddExternalCellValueError values(sourceRow, withdrawCol), "�o��", sourceRow + headerRow - 1, errorCount, firstError, firstErrorRow
            AddExternalCellValueError values(sourceRow, depositCol), "����", sourceRow + headerRow - 1, errorCount, firstError, firstErrorRow
            AddExternalCellValueError values(sourceRow, shopCol), "�戵�X", sourceRow + headerRow - 1, errorCount, firstError, firstErrorRow
            AddExternalCellValueError values(sourceRow, machineCol), "�@��", sourceRow + headerRow - 1, errorCount, firstError, firstErrorRow
            AddExternalCellValueError values(sourceRow, tekiyoCol), "�E�v", sourceRow + headerRow - 1, errorCount, firstError, firstErrorRow
            AddExternalCellValueError values(sourceRow, balanceCol), "�����c��", sourceRow + headerRow - 1, errorCount, firstError, firstErrorRow

            bankName = CellText(values(sourceRow, bankCol))
            branchName = CellText(values(sourceRow, branchCol))
            SplitExternalPerson CellText(values(sourceRow, personCol)), personName, relationshipText
            If Len(relationshipText) = 0 Then relationshipText = RelationshipFromExistingLookup(relationshipIndex, personName)
            accountType = CellText(values(sourceRow, typeCol))
            accountNo = NormalizeAccountHyphen(PrepareExternalIdentifier( _
                        values(sourceRow, accountCol), sourceSheet, sourceRow + headerRow - 1, accountSourceCol, _
                        "�����ԍ�", errorCount, firstError, firstErrorRow))
            tekiyoText = CellText(values(sourceRow, tekiyoCol))
            shopText = PrepareExternalIdentifier( _
                       values(sourceRow, shopCol), sourceSheet, sourceRow + headerRow - 1, shopSourceCol, _
                       "�戵�X", errorCount, firstError, firstErrorRow)
            machineText = PrepareExternalIdentifier( _
                          values(sourceRow, machineCol), sourceSheet, sourceRow + headerRow - 1, machineSourceCol, _
                          "�@��", errorCount, firstError, firstErrorRow)

            '�����J�n���̑S�̍s�͌������R�[�h�ł͂Ȃ����߁A�ݒ葤�ōĐ�������B
            If tekiyoText = "�����J�n��" And Len(bankName & accountNo) = 0 Then GoTo NextSourceRow

            If Len(bankName) = 0 Then AddImportError "��s�����󗓂ł��B", sourceRow + headerRow - 1, errorCount, firstError, firstErrorRow
            If Len(personName) = 0 Then AddImportError "�������󗓂ł��B", sourceRow + headerRow - 1, errorCount, firstError, firstErrorRow
            If Len(accountType) = 0 Then AddImportError "�Ȗڂ��󗓂ł��B", sourceRow + headerRow - 1, errorCount, firstError, firstErrorRow
            If Len(accountNo) = 0 Then AddImportError "�����ԍ����󗓂ł��B", sourceRow + headerRow - 1, errorCount, firstError, firstErrorRow
            AddImportLengthError bankName, 100, "��s��", sourceRow + headerRow - 1, errorCount, firstError, firstErrorRow
            AddImportLengthError branchName, 100, "�x�X��", sourceRow + headerRow - 1, errorCount, firstError, firstErrorRow
            AddImportLengthError personName, 100, "����", sourceRow + headerRow - 1, errorCount, firstError, firstErrorRow
            AddImportLengthError relationshipText, 50, "����", sourceRow + headerRow - 1, errorCount, firstError, firstErrorRow
            AddImportLengthError accountType, 100, "�Ȗ�", sourceRow + headerRow - 1, errorCount, firstError, firstErrorRow
            AddImportLengthError accountNo, 100, "�����ԍ�", sourceRow + headerRow - 1, errorCount, firstError, firstErrorRow
            AddImportLengthError shopText, 100, "�戵�X", sourceRow + headerRow - 1, errorCount, firstError, firstErrorRow
            AddImportLengthError machineText, 100, "�@��", sourceRow + headerRow - 1, errorCount, firstError, firstErrorRow
            AddImportLengthError tekiyoText, 500, "�E�v", sourceRow + headerRow - 1, errorCount, firstError, firstErrorRow

            txDate = ParseExternalDate(values(sourceRow, dateCol), ok)
            If Not ok Then AddImportError "���t�����߂ł��܂���B", sourceRow + headerRow - 1, errorCount, firstError, firstErrorRow
            'VBA��And�͒Z���]������Ȃ��B������Ȃ��itimeCol=0�j�̎���
            '�z���0��ڂ��Q�Ƃ��Ȃ��悤�A��L���ƒl�L����i�K�I�ɔ��肷��B
            txTime = ""
            If timeCol > 0 Then
                If HasText(values(sourceRow, timeCol)) Then
                    txTime = NormalizeTimeInput(values(sourceRow, timeCol), ok)
                    If Not ok Then AddImportError "���������߂ł��܂���B", sourceRow + headerRow - 1, errorCount, firstError, firstErrorRow
                End If
            End If

            withdrawValue = TryParseAmount(values(sourceRow, withdrawCol), amountOK)
            If Not amountOK Then AddImportError "�o���z���s���ł��i�L������15���E����8���ȓ��j�B", sourceRow + headerRow - 1, errorCount, firstError, firstErrorRow
            If amountOK Then
                If HasText(withdrawValue) Then
                    If CDbl(withdrawValue) < 0 Then AddImportError "�o���z��0�ȏ�œ��͂��Ă��������B", sourceRow + headerRow - 1, errorCount, firstError, firstErrorRow
                End If
            End If
            depositValue = TryParseAmount(values(sourceRow, depositCol), amountOK)
            If Not amountOK Then AddImportError "�����z���s���ł��i�L������15���E����8���ȓ��j�B", sourceRow + headerRow - 1, errorCount, firstError, firstErrorRow
            If amountOK Then
                If HasText(depositValue) Then
                    If CDbl(depositValue) < 0 Then AddImportError "�����z��0�ȏ�œ��͂��Ă��������B", sourceRow + headerRow - 1, errorCount, firstError, firstErrorRow
                End If
            End If
            If HasText(withdrawValue) And HasText(depositValue) Then
                AddImportError "�o���Ɠ����̗����ɋ��z������܂��B", sourceRow + headerRow - 1, errorCount, firstError, firstErrorRow
            End If
            afterBalance = TryParseAmount(values(sourceRow, balanceCol), amountOK)
            If Not amountOK Then AddImportError "�����c�����s���ł��i�L������15���E����8���ȓ��j�B", sourceRow + headerRow - 1, errorCount, firstError, firstErrorRow

            Select Case tekiyoText
                Case "�����J�ݓ�": recordType = RECORD_OPEN
                Case "��������": recordType = RECORD_CLOSE
                Case Else
                    If IsExternalBalanceRecord(tekiyoText, withdrawValue, depositValue, afterBalance) Then
                        recordType = RECORD_BALANCE
                    Else
                        recordType = RECORD_TRANSACTION
                    End If
            End Select
            If recordType = RECORD_OPEN Or recordType = RECORD_CLOSE Then
                If HasText(withdrawValue) Or HasText(depositValue) Or HasText(afterBalance) Or _
                   Len(shopText) > 0 Or Len(machineText) > 0 Then
                    AddImportError "�����J�ݓ��E���������s�ɂ͓��o���A�c���A�戵�X�A�@�Ԃ���͂ł��܂���B", _
                                   sourceRow + headerRow - 1, errorCount, firstError, firstErrorRow
                End If
            End If
            If recordType = RECORD_TRANSACTION Then
                If Not HasText(withdrawValue) And Not HasText(depositValue) And Not HasText(afterBalance) And _
                   Len(shopText) = 0 And Len(machineText) = 0 And Len(tekiyoText) = 0 Then
                    AddImportError "���t�ȊO�̎�����e������܂���B", sourceRow + headerRow - 1, errorCount, firstError, firstErrorRow
                End If
            End If

            preparedCount = preparedCount + 1
            prepared(preparedCount, PREP_BANK) = bankName
            prepared(preparedCount, PREP_BRANCH) = branchName
            prepared(preparedCount, PREP_PERSON) = personName
            prepared(preparedCount, PREP_RELATIONSHIP) = relationshipText
            prepared(preparedCount, PREP_TYPE) = accountType
            prepared(preparedCount, PREP_ACCOUNT_NO) = accountNo
            prepared(preparedCount, PREP_DATE) = txDate
            prepared(preparedCount, PREP_TIME) = txTime
            prepared(preparedCount, PREP_WITHDRAW) = withdrawValue
            prepared(preparedCount, PREP_DEPOSIT) = depositValue
            prepared(preparedCount, PREP_SHOP) = shopText
            prepared(preparedCount, PREP_MACHINE) = machineText
            prepared(preparedCount, PREP_TEKIYO) = tekiyoText
            prepared(preparedCount, PREP_AFTER_BALANCE) = afterBalance
            prepared(preparedCount, PREP_RECORD_TYPE) = recordType
            prepared(preparedCount, PREP_INPUT_ORDER) = sourceRow + headerRow - 1
        End If
NextSourceRow:
    Next sourceRow

    sourceBook.Close SaveChanges:=False
    Set sourceBook = Nothing
    Application.AutomationSecurity = previousSecurity
    securityChanged = False

    If errorCount > 0 Then
        AppEnd
        SetInputStatus "�O���捞�𒆎~���܂����i" & errorCount & "���j�@" & firstError
        MsgBox "�O���f�[�^�ɂ͓o�^�ł��Ȃ��s������܂��B�f�[�^�͔��f���Ă��܂���B" & vbCrLf & vbCrLf & _
               "�ŏ��̖��: " & firstErrorRow & "�s�@" & firstError & vbCrLf & _
               "��茏��: " & errorCount, vbExclamation, "�O���捞�̌��،���"
        Exit Sub
    End If
    If preparedCount = 0 Then
        AppEnd
        SetInputStatus "�捞�Ώۂ̎���s�͂���܂���ł����B"
        Exit Sub
    End If

    CommitExternalRows prepared, preparedCount, importedCount, duplicateCount, accountCount
    AppEnd
    EnableInputKeys
    SetInputStatus "�O���捞�����@�捞�s " & importedCount & "���A���� " & accountCount & "���B"
    MsgBox "�O���f�[�^����荞�݂܂����B" & vbCrLf & _
           "�V�K�捞�s: " & importedCount & "��" & vbCrLf & _
           "�d���̂��ߏ��O: " & duplicateCount & "��" & vbCrLf & _
           "�Ώی���: " & accountCount & "��" & vbCrLf & vbCrLf & _
           "�������o�����Ȃ������ɂ��ẮA������⊮���Ă��܂���B", vbInformation, "�O���捞����"
    Exit Sub

EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    On Error Resume Next
    If Not sourceBook Is Nothing Then sourceBook.Close SaveChanges:=False
    If securityChanged Then Application.AutomationSecurity = previousSecurity
    On Error GoTo 0
    AppForceRestore
    EnableInputKeys
    If InStr(1, errorDescription, "���[���o�b�N�m�F", vbTextCompare) > 0 Then
        SetInputStatus "�O���捞�Ɏ��s���A�������ʂ��v�m�F�ł��BC_�`�F�b�N���m�F���Ă��������B"
        AddCheck "�G���[", "�O���捞���[���o�b�N", errorDescription
    ElseIf InStr(1, errorDescription, "���[���o�b�N�����x��", vbTextCompare) > 0 Then
        SetInputStatus "�O���捞�Ɏ��s���܂����B�f�[�^�͎捞�O�ƈ�v���Ă��܂��B"
        AddCheck "�x��", "�O���捞���[���o�b�N", errorDescription
    Else
        SetInputStatus "�O���捞�Ɏ��s�������߁A�f�[�^�͔��f���Ă��܂���B"
    End If
    MsgBox OperationFailureHeading(errorNumber, "�O���捞���ɃG���[���������܂����B") & vbCrLf & _
           OperationFailureDetail(errorNumber, errorDescription), OperationFailureIcon(errorNumber, vbCritical)
End Sub

Private Function IsExternalBalanceRecord(ByVal tekiyoText As String, ByVal withdrawValue As Variant, _
                                         ByVal depositValue As Variant, ByVal afterBalance As Variant) As Boolean
    '���c�[�����o�͂���c���s������ێ�I�ɕ�������B
    '�E�v�Ɂu�c���v���܂܂��ʏ�������F���Ȃ��悤�A���o���Ȃ��E�c�����l��K�{�Ƃ���B
    Dim s As String
    If HasText(withdrawValue) Or HasText(depositValue) Then Exit Function
    If Not HasText(afterBalance) Or Not IsNumeric(afterBalance) Then Exit Function
    s = CellText(tekiyoText)
    s = Replace(s, vbCrLf, "")
    s = Replace(s, vbCr, "")
    s = Replace(s, vbLf, "")
    s = Replace(s, " ", "")
    s = Replace(s, "�@", "")
    If s = "�c��" Or InStr(1, s, "�N���c��", vbTextCompare) > 0 Or _
       InStr(1, s, "�����J�n�����_�c��", vbTextCompare) > 0 Then
        IsExternalBalanceRecord = True
    End If
End Function

Private Sub CommitExternalRows(ByRef prepared() As Variant, ByVal preparedCount As Long, _
                               ByRef importedCount As Long, ByRef duplicateCount As Long, ByRef accountCount As Long)
    Dim wsTx As Worksheet, wsBal As Worksheet, wsAcc As Worksheet
    Dim accountIDByKey As Object, transferIDByKey As Object, personIDByKey As Object, personIDByName As Object, relationshipByKey As Object
    Dim personLookupKeyByAccountKey As Object, pendingPersonKeys As Object
    Dim sourceRelationshipByKey As Object, sourceCanonicalByLocator As Object
    Dim firstIndexByKey As Object, newAccountByKey As Object, accountHasRows As Object
    Dim openDateByKey As Object, closeDateByKey As Object, signatures As Object, incomingSignatures As Object
    Dim createdAccountIDs As Object, sourceBalanceDates As Object, existingBalanceAmounts As Object
    Dim createdTransferIDs As Object, existingMasterByID As Object
    Dim existingSpecialDates As Object, skipSpecialByType As Object, existingAccountIDByKey As Object
    Dim existingAccountIDByLocator As Object, accountRowByID As Object
    Dim outData() As Variant, writeData() As Variant
    Dim balanceOutData() As Variant, writeBalanceData() As Variant
    Dim outAccountKeys() As String, balanceAccountKeys() As String
    Dim idCounterSnapshot As Variant, accountIDs As Variant, personIDs As Variant, transferIDs As Variant
    Dim transactionIDs As Variant, balanceIDs As Variant
    Dim newAccountKeys As Collection, newPersonKeyOrder As Collection, newTransferKeys As Collection
    Dim i As Long, c As Long, outCount As Long, firstR As Long, nextMasterRow As Long
    Dim personReserveIndex As Long
    Dim balanceCount As Long, balanceFirstR As Long, incomingCount As Long, existingCount As Long
    Dim keyText As String, locatorKey As String, accountID As String, transferID As String, personID As String, personNameKey As String, specialKey As String
    Dim existingID As String, signatureText As String, recordType As String, balanceKey As String
    Dim item As Variant, firstIndex As Long, masterRow As Long
    Dim effectiveOpen As Variant, effectiveClose As Variant, masterSnapshot As Variant
    Dim masterSource As String, rollbackDetail As String, rollbackVerifyDetail As String, postProcessDetail As String
    Dim relationshipText As String, sourceRelationshipText As String
    Dim writeStarted As Boolean, committed As Boolean, skipRow As Boolean, idCountersCaptured As Boolean
    Dim rollbackVerified As Boolean
    Dim errorNumber As Long, errorDescription As String

    On Error GoTo EH
    If Not ConfirmLargeArrayOperation(preparedCount, "�O���f�[�^�̎�荞��") Then Err.Raise 18
    Set wsTx = GetSheet(SH_WORK_TX)
    Set wsBal = GetSheet(SH_WORK_BAL)
    Set wsAcc = GetSheet(SH_WORK_ACCOUNT)
    Set accountIDByKey = NewTextDictionary()
    Set transferIDByKey = NewTextDictionary()
    Set personIDByKey = NewTextDictionary()
    Set personIDByName = NewTextDictionary()
    Set personLookupKeyByAccountKey = NewTextDictionary()
    Set pendingPersonKeys = NewTextDictionary()
    Set relationshipByKey = NewTextDictionary()
    Set sourceRelationshipByKey = NewTextDictionary()
    Set sourceCanonicalByLocator = NewTextDictionary()
    Set firstIndexByKey = NewTextDictionary()
    Set newAccountByKey = NewTextDictionary()
    Set accountHasRows = NewTextDictionary()
    Set openDateByKey = NewTextDictionary()
    Set closeDateByKey = NewTextDictionary()
    Set signatures = NewTextDictionary()
    Set incomingSignatures = NewTextDictionary()
    Set sourceBalanceDates = NewTextDictionary()
    Set existingBalanceAmounts = NewTextDictionary()
    Set createdAccountIDs = NewTextDictionary()
    Set createdTransferIDs = NewTextDictionary()
    Set existingMasterByID = NewTextDictionary()
    Set existingSpecialDates = NewTextDictionary()
    Set skipSpecialByType = NewTextDictionary()
    Set existingAccountIDByKey = NewTextDictionary()
    Set existingAccountIDByLocator = NewTextDictionary()
    Set accountRowByID = NewTextDictionary()
    Set newAccountKeys = New Collection
    Set newPersonKeyOrder = New Collection
    Set newTransferKeys = New Collection
    LoadExistingTransactionSignatures wsTx, signatures
    LoadExistingBalanceIndex wsBal, existingBalanceAmounts
    LoadExistingSpecialRecordDates wsTx, existingSpecialDates
    LoadExistingAccountIndexes wsAcc, existingAccountIDByKey, existingAccountIDByLocator, accountRowByID
    LoadExistingPersonIdIndex personIDByName
    idCounterSnapshot = CaptureInternalIdCounters()
    idCountersCaptured = True
    nextMasterRow = LastUsedRowInSheet(wsAcc) + 1
    If nextMasterRow < 2 Then nextMasterRow = 2

    For i = 1 To preparedCount
        keyText = CanonicalAccountKey(CStr(prepared(i, PREP_BANK)), CStr(prepared(i, PREP_BRANCH)), _
                                      CStr(prepared(i, PREP_PERSON)), CStr(prepared(i, PREP_TYPE)), _
                                      CStr(prepared(i, PREP_ACCOUNT_NO)))
        locatorKey = CanonicalAccountLocatorKey(CStr(prepared(i, PREP_BANK)), CStr(prepared(i, PREP_BRANCH)), _
                                                CStr(prepared(i, PREP_TYPE)), CStr(prepared(i, PREP_ACCOUNT_NO)))
        sourceRelationshipText = CStr(prepared(i, PREP_RELATIONSHIP))
        If sourceRelationshipByKey.Exists(keyText) Then
            relationshipText = CStr(sourceRelationshipByKey(keyText))
            If Len(relationshipText) = 0 And Len(sourceRelationshipText) > 0 Then
                sourceRelationshipByKey(keyText) = sourceRelationshipText
            ElseIf Len(relationshipText) > 0 And Len(sourceRelationshipText) > 0 Then
                If NormalizeRelationshipKey(relationshipText) <> NormalizeRelationshipKey(sourceRelationshipText) Then
                    Err.Raise vbObjectError + 6145, "CommitExternalRows", _
                              "���������̑������捞�������ň�v���܂���: " & CStr(prepared(i, PREP_ACCOUNT_NO))
                End If
            End If
        Else
            sourceRelationshipByKey.Add keyText, sourceRelationshipText
        End If
        If sourceCanonicalByLocator.Exists(locatorKey) Then
            If CStr(sourceCanonicalByLocator(locatorKey)) <> keyText Then
                Err.Raise vbObjectError + 6146, "CommitExternalRows", _
                          "������s�E�x�X�E�ȖځE�����ԍ��ɈقȂ閼�`������܂��B���`���m�F���A�K�v�Ȃ�������[�h���g�p���Ă�������: " & _
                          CStr(prepared(i, PREP_ACCOUNT_NO))
            End If
        Else
            sourceCanonicalByLocator.Add locatorKey, keyText
        End If
        If existingAccountIDByLocator.Exists(locatorKey) Then
            If Not existingAccountIDByKey.Exists(keyText) Then
                Err.Raise vbObjectError + 6147, "CommitExternalRows", _
                          "�o�^�ς݌����Ɠ�����s�E�x�X�E�ȖځE�����ԍ��ł����A���`���قȂ�܂��B�O���捞�ł͏㏑�������A�������[�h�Ŋm�F���Ă�������: " & _
                          CStr(prepared(i, PREP_ACCOUNT_NO))
            ElseIf CStr(existingAccountIDByLocator(locatorKey)) <> CStr(existingAccountIDByKey(keyText)) Then
                Err.Raise vbObjectError + 6148, "CommitExternalRows", _
                          "�o�^�ς݌����̎��ʏ�񂪖������Ă��܂��B��ɃZ���t�`�F�b�N�����s���Ă��������B"
            End If
        End If
        If Not accountIDByKey.Exists(keyText) Then
            existingID = ""
            If existingAccountIDByKey.Exists(keyText) Then existingID = CStr(existingAccountIDByKey(keyText))
            If Len(existingID) > 0 Then
                accountID = existingID
                newAccountByKey.Add keyText, False
                If Not accountRowByID.Exists(accountID) Then _
                    Err.Raise vbObjectError + 6113, "CommitExternalRows", "���������}�X�^���擾�ł��܂���: " & accountID
                masterRow = CLng(accountRowByID(accountID))
                If Not existingMasterByID.Exists(accountID) Then
                    masterSnapshot = wsAcc.Range(wsAcc.Cells(masterRow, 1), wsAcc.Cells(masterRow, ACC_COL_TRANSFER_ID)).Value
                    existingMasterByID.Add accountID, masterSnapshot
                End If
            Else
                accountID = ""
                newAccountByKey.Add keyText, True
                newAccountKeys.Add keyText
            End If
            relationshipText = CStr(sourceRelationshipByKey(keyText))
            If Len(existingID) > 0 Then
                If Not accountRowByID.Exists(existingID) Then _
                    Err.Raise vbObjectError + 8013, "CommitExternalRows", "���������}�X�^���擾�ł��܂���: " & existingID
                masterRow = CLng(accountRowByID(existingID))
                '���������̐l�������͌����}�X�^�𐳂Ƃ��A�O���\�����ŕύX���Ȃ��B
                sourceRelationshipText = relationshipText
                masterSnapshot = existingMasterByID(existingID)
                relationshipText = CellText(masterSnapshot(1, ACC_COL_RELATIONSHIP))
                If Len(sourceRelationshipText) > 0 And Len(relationshipText) > 0 Then
                    If NormalizeRelationshipKey(sourceRelationshipText) <> NormalizeRelationshipKey(relationshipText) Then
                        Err.Raise vbObjectError + 6149, "CommitExternalRows", _
                                  "�o�^�ς݌����Ǝ捞�����̑������قȂ�܂��B�������[�h�Ŋm�F���Ă�������: " & accountID
                    End If
                End If
            End If
            accountIDByKey.Add keyText, accountID
            relationshipByKey.Add keyText, relationshipText
            firstIndexByKey.Add keyText, i
            accountCount = accountCount + 1
        End If
        recordType = CStr(prepared(i, PREP_RECORD_TYPE))
        If recordType = RECORD_OPEN Then
            If openDateByKey.Exists(keyText) Then
                Err.Raise vbObjectError + 6111, "CommitExternalRows", _
                          "���������Ɍ����J�ݓ��s����������܂�: " & CStr(prepared(i, PREP_ACCOUNT_NO))
            End If
            openDateByKey.Add keyText, prepared(i, PREP_DATE)
        ElseIf recordType = RECORD_CLOSE Then
            If closeDateByKey.Exists(keyText) Then
                Err.Raise vbObjectError + 6112, "CommitExternalRows", _
                          "���������Ɍ��������s����������܂�: " & CStr(prepared(i, PREP_ACCOUNT_NO))
            End If
            closeDateByKey.Add keyText, prepared(i, PREP_DATE)
        ElseIf recordType = RECORD_BALANCE Then
            balanceKey = keyText & Chr$(29) & DateSignature(prepared(i, PREP_DATE))
            If sourceBalanceDates.Exists(balanceKey) Then
                Err.Raise vbObjectError + 6129, "CommitExternalRows", _
                          "���������E��������̎c���s����������܂�: " & _
                          CStr(prepared(i, PREP_ACCOUNT_NO)) & " / " & Format$(CDate(prepared(i, PREP_DATE)), "yyyy/m/d")
            End If
            sourceBalanceDates.Add balanceKey, True
        End If
    Next i

    '�V�K���������m�肵�Ă���܂Ƃ߂č̔Ԃ��AW_��Ԃ��������ƂɍX�V���Ȃ��B
    If newAccountKeys.Count > 0 Then
        accountIDs = ReserveInternalIds(STATE_NEXT_ACCOUNT, "A", newAccountKeys.Count)
        For i = 1 To newAccountKeys.Count
            keyText = CStr(newAccountKeys(i))
            accountID = CStr(accountIDs(i))
            accountIDByKey(keyText) = accountID
            createdAccountIDs(accountID) = True
            accountRowByID.Add accountID, nextMasterRow
            nextMasterRow = nextMasterRow + 1
        Next i
    End If

    '�l��ID���������Ƃɏ�ԕ\�֏������A����ID�Ƃ̐������m�F���Ă���V�K�l���������ꊇ�̔Ԃ���B
    For Each item In accountIDByKey.Keys
        keyText = CStr(item)
        accountID = CStr(accountIDByKey(keyText))
        firstIndex = CLng(firstIndexByKey(keyText))
        personNameKey = PersonLookupKey(CStr(prepared(firstIndex, PREP_PERSON)), _
                                        CStr(relationshipByKey(keyText)))
        personID = ""
        If Not CBool(newAccountByKey(keyText)) Then
            If Not accountRowByID.Exists(accountID) Then _
                Err.Raise vbObjectError + 8014, "CommitExternalRows", "���������}�X�^���擾�ł��܂���: " & accountID
            masterRow = CLng(accountRowByID(accountID))
            masterSnapshot = existingMasterByID(accountID)
            personID = CellText(masterSnapshot(1, ACC_COL_PERSON_ID))
        End If
        If Len(personID) = 0 Then
            If personIDByName.Exists(personNameKey) Then personID = CStr(personIDByName(personNameKey))
        End If
        If Len(personID) > 0 Then
            If personIDByName.Exists(personNameKey) Then
                existingID = CStr(personIDByName(personNameKey))
                If Len(existingID) > 0 And StrComp(existingID, personID, vbTextCompare) <> 0 Then
                    Err.Raise vbObjectError + 6126, "CommitExternalRows", _
                              "���������E�����ɈقȂ�l��ID������܂��B��ɃZ���t�`�F�b�N�����s���Ă�������: " & _
                              CStr(prepared(firstIndex, PREP_PERSON))
                ElseIf Len(existingID) = 0 Then
                    personIDByName(personNameKey) = personID
                    If pendingPersonKeys.Exists(personNameKey) Then pendingPersonKeys.Remove personNameKey
                End If
            Else
                personIDByName.Add personNameKey, personID
            End If
        ElseIf Not personIDByName.Exists(personNameKey) Then
            personIDByName.Add personNameKey, ""
            pendingPersonKeys.Add personNameKey, True
            newPersonKeyOrder.Add personNameKey
        End If
        personLookupKeyByAccountKey.Add keyText, personNameKey
        personIDByKey.Add keyText, personID
    Next item
    If pendingPersonKeys.Count > 0 Then
        personIDs = ReserveInternalIds(STATE_NEXT_PERSON, "P", pendingPersonKeys.Count)
        personReserveIndex = 0
        For i = 1 To newPersonKeyOrder.Count
            personNameKey = CStr(newPersonKeyOrder(i))
            If pendingPersonKeys.Exists(personNameKey) Then
                personReserveIndex = personReserveIndex + 1
                personIDByName(personNameKey) = CStr(personIDs(personReserveIndex))
            End If
        Next i
    End If
    For Each item In accountIDByKey.Keys
        keyText = CStr(item)
        If Len(CStr(personIDByKey(keyText))) = 0 Then
            personNameKey = CStr(personLookupKeyByAccountKey(keyText))
            If Not personIDByName.Exists(personNameKey) Then _
                Err.Raise vbObjectError + 6154, "CommitExternalRows", "�l��ID�̊������m�F�ł��܂���B"
            personID = CStr(personIDByName(personNameKey))
            If Len(personID) = 0 Then _
                Err.Raise vbObjectError + 8015, "CommitExternalRows", "�l��ID�̊������󗓂ł��B"
            personIDByKey(keyText) = personID
        End If
    Next item

    '���������̓��t���󗓂Ȃ�O���\�ŕ⊮�ł��邪�A�قȂ�o�^�ςݓ��t�͒������[�h���g���B
    '�O���捞�����Ŋ����̊J�ݓ��E�������㏑�������A����s�̓�d�o�^���h���B
    For Each item In accountIDByKey.Keys
        keyText = CStr(item)
        accountID = CStr(accountIDByKey(keyText))
        If CBool(newAccountByKey(keyText)) Then
            effectiveOpen = DictionaryValueOrBlank(openDateByKey, keyText)
            effectiveClose = DictionaryValueOrBlank(closeDateByKey, keyText)
        Else
            If Not accountRowByID.Exists(accountID) Then _
                Err.Raise vbObjectError + 8016, "CommitExternalRows", "���������}�X�^���擾�ł��܂���: " & accountID
            masterRow = CLng(accountRowByID(accountID))
            masterSnapshot = existingMasterByID(accountID)
            effectiveOpen = masterSnapshot(1, ACC_COL_OPEN_DATE)
            effectiveClose = masterSnapshot(1, ACC_COL_CLOSE_DATE)
            If IsError(effectiveOpen) Then Err.Raise vbObjectError + 6114, "CommitExternalRows", "���������̊J�ݓ����s���ł�: " & accountID
            If IsError(effectiveClose) Then Err.Raise vbObjectError + 6115, "CommitExternalRows", "���������̉������s���ł�: " & accountID
            If HasText(effectiveOpen) Then
                If Not IsDate(effectiveOpen) Then Err.Raise vbObjectError + 8017, "CommitExternalRows", "���������̊J�ݓ����s���ł�: " & accountID
            End If
            If HasText(effectiveClose) Then
                If Not IsDate(effectiveClose) Then Err.Raise vbObjectError + 8018, "CommitExternalRows", "���������̉������s���ł�: " & accountID
            End If
            If openDateByKey.Exists(keyText) Then
                If IsDate(effectiveOpen) Then
                    If DateSignature(effectiveOpen) <> DateSignature(openDateByKey(keyText)) Then
                        Err.Raise vbObjectError + 6116, "CommitExternalRows", _
                                  "���������̊J�ݓ��Ǝ捞�l���قȂ�܂��B�o�^�ς݌����̒������[�h���g�p���Ă�������: " & accountID
                    End If
                End If
                specialKey = ExistingSpecialRecordKey(accountID, RECORD_OPEN)
                If existingSpecialDates.Exists(specialKey) Then
                    If Not IsDate(effectiveOpen) Or CStr(existingSpecialDates(specialKey)) <> DateSignature(openDateByKey(keyText)) Then
                        Err.Raise vbObjectError + 6117, "CommitExternalRows", "�����̌����J�ݓ��s�ƌ����}�X�^����v���܂���: " & accountID
                    End If
                    skipSpecialByType(specialKey) = True
                End If
                effectiveOpen = openDateByKey(keyText)
            End If
            If closeDateByKey.Exists(keyText) Then
                If IsDate(effectiveClose) Then
                    If DateSignature(effectiveClose) <> DateSignature(closeDateByKey(keyText)) Then
                        Err.Raise vbObjectError + 6118, "CommitExternalRows", _
                                  "���������̉����Ǝ捞�l���قȂ�܂��B�o�^�ς݌����̒������[�h���g�p���Ă�������: " & accountID
                    End If
                End If
                specialKey = ExistingSpecialRecordKey(accountID, RECORD_CLOSE)
                If existingSpecialDates.Exists(specialKey) Then
                    If Not IsDate(effectiveClose) Or CStr(existingSpecialDates(specialKey)) <> DateSignature(closeDateByKey(keyText)) Then
                        Err.Raise vbObjectError + 6119, "CommitExternalRows", "�����̌��������s�ƌ����}�X�^����v���܂���: " & accountID
                    End If
                    skipSpecialByType(specialKey) = True
                End If
                effectiveClose = closeDateByKey(keyText)
            End If
            specialKey = ExistingSpecialRecordKey(accountID, RECORD_OPEN)
            If existingSpecialDates.Exists(specialKey) Then
                If Not IsDate(effectiveOpen) Then
                    Err.Raise vbObjectError + 6137, "CommitExternalRows", "�����J�ݓ��s�ɑΉ���������}�X�^���t������܂���: " & accountID
                ElseIf CStr(existingSpecialDates(specialKey)) <> DateSignature(effectiveOpen) Then
                    Err.Raise vbObjectError + 6138, "CommitExternalRows", "�����̌����J�ݓ��s�ƌ����}�X�^����v���܂���: " & accountID
                End If
            ElseIf IsDate(effectiveOpen) And Not openDateByKey.Exists(keyText) Then
                Err.Raise vbObjectError + 6139, "CommitExternalRows", "�����}�X�^�̊J�ݓ��ɑΉ��������s������܂���B��ɃZ���t�`�F�b�N�����s���Ă�������: " & accountID
            End If
            specialKey = ExistingSpecialRecordKey(accountID, RECORD_CLOSE)
            If existingSpecialDates.Exists(specialKey) Then
                If Not IsDate(effectiveClose) Then
                    Err.Raise vbObjectError + 6140, "CommitExternalRows", "���������s�ɑΉ���������}�X�^���t������܂���: " & accountID
                ElseIf CStr(existingSpecialDates(specialKey)) <> DateSignature(effectiveClose) Then
                    Err.Raise vbObjectError + 6141, "CommitExternalRows", "�����̌��������s�ƌ����}�X�^����v���܂���: " & accountID
                End If
            ElseIf IsDate(effectiveClose) And Not closeDateByKey.Exists(keyText) Then
                Err.Raise vbObjectError + 6142, "CommitExternalRows", "�����}�X�^�̉����ɑΉ��������s������܂���B��ɃZ���t�`�F�b�N�����s���Ă�������: " & accountID
            End If
        End If
        openDateByKey(keyText) = effectiveOpen
        closeDateByKey(keyText) = effectiveClose
        If IsDate(effectiveOpen) And IsDate(effectiveClose) Then
            If CDate(effectiveOpen) > CDate(effectiveClose) Then
                Err.Raise vbObjectError + 6110, "CommitExternalRows", _
                          "�����u" & CStr(prepared(CLng(firstIndexByKey(keyText)), PREP_ACCOUNT_NO)) & "�v�̊J�ݓ�����������ł��B"
            End If
        End If
    Next item

    '�J�ݑO�E����̎���́A�O���捞�ł�����͂Ɠ�����ŋ��ۂ���B
    For i = 1 To preparedCount
        keyText = CanonicalAccountKey(CStr(prepared(i, PREP_BANK)), CStr(prepared(i, PREP_BRANCH)), _
                                      CStr(prepared(i, PREP_PERSON)), CStr(prepared(i, PREP_TYPE)), _
                                      CStr(prepared(i, PREP_ACCOUNT_NO)))
        effectiveOpen = DictionaryValueOrBlank(openDateByKey, keyText)
        effectiveClose = DictionaryValueOrBlank(closeDateByKey, keyText)
        If IsDate(effectiveOpen) Then
            If CDate(prepared(i, PREP_DATE)) < CDate(effectiveOpen) Then
                Err.Raise vbObjectError + 6130, "CommitExternalRows", _
                          "�����u" & CStr(prepared(i, PREP_ACCOUNT_NO)) & "�v�ɊJ�ݓ��O�̍s������܂��i�捞�� " & _
                          CStr(prepared(i, PREP_INPUT_ORDER)) & "�s�j�B"
            End If
        End If
        If IsDate(effectiveClose) Then
            If CDate(prepared(i, PREP_DATE)) > CDate(effectiveClose) Then
                Err.Raise vbObjectError + 6131, "CommitExternalRows", _
                          "�����u" & CStr(prepared(i, PREP_ACCOUNT_NO)) & "�v�ɉ�����̍s������܂��i�捞�� " & _
                          CStr(prepared(i, PREP_INPUT_ORDER)) & "�s�j�B"
            End If
        End If
    Next i

    ReDim outData(1 To preparedCount, 1 To WORK_TX_COL_PERSON_ID)
    ReDim balanceOutData(1 To preparedCount, 1 To WORK_BAL_COL_PERSON_ID)
    ReDim outAccountKeys(1 To preparedCount)
    ReDim balanceAccountKeys(1 To preparedCount)
    For i = 1 To preparedCount
        keyText = CanonicalAccountKey(CStr(prepared(i, PREP_BANK)), CStr(prepared(i, PREP_BRANCH)), _
                                      CStr(prepared(i, PREP_PERSON)), CStr(prepared(i, PREP_TYPE)), _
                                      CStr(prepared(i, PREP_ACCOUNT_NO)))
        accountID = CStr(accountIDByKey(keyText))
        recordType = CStr(prepared(i, PREP_RECORD_TYPE))
        skipRow = False
        If recordType = RECORD_OPEN Or recordType = RECORD_CLOSE Then
            skipRow = skipSpecialByType.Exists(ExistingSpecialRecordKey(accountID, recordType))
        End If
        signatureText = ExternalRecordSignature(accountID, prepared, i)
        incomingCount = IncrementDictionaryCount(incomingSignatures, signatureText)
        existingCount = DictionaryLongValue(signatures, signatureText)
        If skipRow Then
            duplicateCount = duplicateCount + 1
        ElseIf incomingCount <= existingCount Then
            duplicateCount = duplicateCount + 1
        Else
            If transferIDByKey.Exists(keyText) Then
                transferID = CStr(transferIDByKey(keyText))
            Else
                transferID = ""
                transferIDByKey.Add keyText, transferID
                newTransferKeys.Add keyText
            End If
            personID = CStr(personIDByKey(keyText))
            outCount = outCount + 1
            outAccountKeys(outCount) = keyText
            outData(outCount, OUT_COL_BANK) = prepared(i, PREP_BANK)
            outData(outCount, OUT_COL_BRANCH) = prepared(i, PREP_BRANCH)
            outData(outCount, OUT_COL_PERSON) = prepared(i, PREP_PERSON)
            outData(outCount, OUT_COL_ACCOUNT_TYPE) = prepared(i, PREP_TYPE)
            outData(outCount, OUT_COL_ACCOUNT_NO) = prepared(i, PREP_ACCOUNT_NO)
            outData(outCount, OUT_COL_DATE) = prepared(i, PREP_DATE)
            outData(outCount, OUT_COL_TIME) = prepared(i, PREP_TIME)
            outData(outCount, OUT_COL_WITHDRAW) = prepared(i, PREP_WITHDRAW)
            outData(outCount, OUT_COL_DEPOSIT) = prepared(i, PREP_DEPOSIT)
            outData(outCount, OUT_COL_SHOP) = prepared(i, PREP_SHOP)
            outData(outCount, OUT_COL_MACHINE) = prepared(i, PREP_MACHINE)
            outData(outCount, OUT_COL_TEKIYO) = prepared(i, PREP_TEKIYO)
            outData(outCount, OUT_COL_OTHER) = prepared(i, PREP_AFTER_BALANCE)
            outData(outCount, WORK_TX_COL_RELATIONSHIP) = relationshipByKey(keyText)
            outData(outCount, WORK_TX_COL_ACCOUNT_ID) = accountID
            outData(outCount, WORK_TX_COL_TRANSFER_ID) = transferID
            outData(outCount, WORK_TX_COL_RECORD_TYPE) = prepared(i, PREP_RECORD_TYPE)
            outData(outCount, WORK_TX_COL_INPUT_ORDER) = prepared(i, PREP_INPUT_ORDER)
            outData(outCount, WORK_TX_COL_SOURCE) = SOURCE_EXTERNAL
            outData(outCount, WORK_TX_COL_PERSON_ID) = personID
            If recordType = RECORD_BALANCE Then
                balanceKey = BalanceImportKey(accountID, prepared(i, PREP_DATE))
                If existingBalanceAmounts.Exists(balanceKey) Then
                    Err.Raise vbObjectError + 6132, "CommitExternalRows", _
                              "�c���ۊǂɂ͓��������E����̎c�������ɂ���܂����A�Ή��������s����v���܂���: " & _
                              accountID & " / " & Format$(CDate(prepared(i, PREP_DATE)), "yyyy/m/d")
                End If
                balanceCount = balanceCount + 1
                balanceAccountKeys(balanceCount) = keyText
                balanceOutData(balanceCount, 1) = prepared(i, PREP_PERSON)
                balanceOutData(balanceCount, 2) = prepared(i, PREP_BANK)
                balanceOutData(balanceCount, 3) = prepared(i, PREP_BRANCH)
                balanceOutData(balanceCount, 4) = prepared(i, PREP_TYPE)
                balanceOutData(balanceCount, 5) = prepared(i, PREP_ACCOUNT_NO)
                balanceOutData(balanceCount, 6) = DictionaryValueOrBlank(openDateByKey, keyText)
                balanceOutData(balanceCount, 7) = DictionaryValueOrBlank(closeDateByKey, keyText)
                balanceOutData(balanceCount, 8) = prepared(i, PREP_DATE)
                balanceOutData(balanceCount, 9) = prepared(i, PREP_TEKIYO)
                balanceOutData(balanceCount, 10) = prepared(i, PREP_AFTER_BALANCE)
                balanceOutData(balanceCount, 11) = ""
                balanceOutData(balanceCount, WORK_BAL_COL_RELATIONSHIP) = relationshipByKey(keyText)
                balanceOutData(balanceCount, WORK_BAL_COL_ACCOUNT_ID) = accountID
                balanceOutData(balanceCount, WORK_BAL_COL_TRANSFER_ID) = transferID
                balanceOutData(balanceCount, WORK_BAL_COL_SOURCE) = SOURCE_EXTERNAL
                balanceOutData(balanceCount, WORK_BAL_COL_PERSON_ID) = personID
            End If
            accountHasRows(keyText) = True
        End If
        If recordType = RECORD_BALANCE And (skipRow Or incomingCount <= existingCount) Then
            balanceKey = BalanceImportKey(accountID, prepared(i, PREP_DATE))
            If Not existingBalanceAmounts.Exists(balanceKey) Then
                Err.Raise vbObjectError + 6133, "CommitExternalRows", _
                          "�����̎c������s�ɑΉ�����c���ۊǂ�����܂���B��ɃZ���t�`�F�b�N�����s���Ă�������: " & accountID
            ElseIf CStr(existingBalanceAmounts(balanceKey)) <> AmountSignature(prepared(i, PREP_AFTER_BALANCE)) Then
                Err.Raise vbObjectError + 6134, "CommitExternalRows", _
                          "�����̎c���ۊǂƎ捞�l����v���܂���: " & accountID & " / " & _
                          Format$(CDate(prepared(i, PREP_DATE)), "yyyy/m/d")
            End If
        End If
    Next i

    '�ǉ��Ώۂ̌����P�ʂœ]�L��ID���܂Ƃ߂č̔Ԃ���B�S���d���̌����ɂ͔��s���Ȃ��B
    If newTransferKeys.Count > 0 Then
        transferIDs = ReserveInternalIds(STATE_NEXT_TRANSFER, "R", newTransferKeys.Count)
        For i = 1 To newTransferKeys.Count
            keyText = CStr(newTransferKeys(i))
            transferID = CStr(transferIDs(i))
            transferIDByKey(keyText) = transferID
            createdTransferIDs(transferID) = True
        Next i
        For i = 1 To outCount
            outData(i, WORK_TX_COL_TRANSFER_ID) = transferIDByKey(outAccountKeys(i))
        Next i
        For i = 1 To balanceCount
            balanceOutData(i, WORK_BAL_COL_TRANSFER_ID) = transferIDByKey(balanceAccountKeys(i))
        Next i
    End If

    '�����m���ɖ���ID���܂Ƃ߂č̔Ԃ��A�ő�10���s�̎捞�ł�W_��Ԃւ�COM�����݂�
    '1�s���ƂɌJ��Ԃ��Ȃ��B
    If outCount > 0 Then
        transactionIDs = ReserveInternalIds(STATE_NEXT_TRANSACTION, "T", outCount)
        For i = 1 To outCount
            outData(i, WORK_TX_COL_TRANSACTION_ID) = transactionIDs(i)
        Next i
    End If
    If balanceCount > 0 Then
        balanceIDs = ReserveInternalIds(STATE_NEXT_BALANCE, "B", balanceCount)
        For i = 1 To balanceCount
            balanceOutData(i, WORK_BAL_COL_BALANCE_ID) = balanceIDs(i)
        Next i
    End If

    EnsureInternalAppendCapacity wsTx, outCount, "W_���"
    EnsureInternalAppendCapacity wsBal, balanceCount, "W_�c��"
    EnsureInternalAppendCapacity wsAcc, createdAccountIDs.Count, "W_����"

    If outCount > 0 Then
        ReDim writeData(1 To outCount, 1 To WORK_TX_COL_PERSON_ID)
        For i = 1 To outCount
            For c = 1 To WORK_TX_COL_PERSON_ID
                writeData(i, c) = outData(i, c)
            Next c
        Next i
        firstR = LastUsedRowInSheet(wsTx) + 1
        If firstR < 2 Then firstR = 2
        If outCount > wsTx.Rows.Count - firstR + 1 Then _
            Err.Raise vbObjectError + 6143, "CommitExternalRows", "����ۊǂ�Excel�̍s����𒴂��܂��B�Č��𕪊����Ă��������B"
        writeStarted = True
        wsTx.Range(wsTx.Cells(firstR, 1), wsTx.Cells(firstR + outCount - 1, OUT_COL_ACCOUNT_NO)).NumberFormat = "@"
        wsTx.Range(wsTx.Cells(firstR, OUT_COL_SHOP), wsTx.Cells(firstR + outCount - 1, OUT_COL_TEKIYO)).NumberFormat = "@"
        wsTx.Range(wsTx.Cells(firstR, WORK_TX_COL_RELATIONSHIP), _
                   wsTx.Cells(firstR + outCount - 1, WORK_TX_COL_PERSON_ID)).NumberFormat = "@"
        wsTx.Range(wsTx.Cells(firstR, 1), wsTx.Cells(firstR + outCount - 1, WORK_TX_COL_PERSON_ID)).Value = writeData
        FormatImportedWorkRows wsTx, firstR, firstR + outCount - 1
    End If
    If balanceCount > 0 Then
        ReDim writeBalanceData(1 To balanceCount, 1 To WORK_BAL_COL_PERSON_ID)
        For i = 1 To balanceCount
            For c = 1 To WORK_BAL_COL_PERSON_ID
                writeBalanceData(i, c) = balanceOutData(i, c)
            Next c
        Next i
        balanceFirstR = LastUsedRowInSheet(wsBal) + 1
        If balanceFirstR < 2 Then balanceFirstR = 2
        If balanceCount > wsBal.Rows.Count - balanceFirstR + 1 Then _
            Err.Raise vbObjectError + 6144, "CommitExternalRows", "�c���ۊǂ�Excel�̍s����𒴂��܂��B�Č��𕪊����Ă��������B"
        writeStarted = True
        wsBal.Range(wsBal.Cells(balanceFirstR, 1), wsBal.Cells(balanceFirstR + balanceCount - 1, 5)).NumberFormat = "@"
        wsBal.Range(wsBal.Cells(balanceFirstR, 9), wsBal.Cells(balanceFirstR + balanceCount - 1, 9)).NumberFormat = "@"
        wsBal.Range(wsBal.Cells(balanceFirstR, 11), _
                    wsBal.Cells(balanceFirstR + balanceCount - 1, WORK_BAL_COL_PERSON_ID)).NumberFormat = "@"
        wsBal.Range(wsBal.Cells(balanceFirstR, 1), _
                    wsBal.Cells(balanceFirstR + balanceCount - 1, WORK_BAL_COL_PERSON_ID)).Value = writeBalanceData
        FormatImportedBalanceRows wsBal, balanceFirstR, balanceFirstR + balanceCount - 1
    End If

    For Each item In accountIDByKey.Keys
        keyText = CStr(item)
        If accountHasRows.Exists(keyText) Then
            firstIndex = CLng(firstIndexByKey(keyText))
            accountID = CStr(accountIDByKey(keyText))
            transferID = CStr(transferIDByKey(keyText))
            personID = CStr(personIDByKey(keyText))
            masterSource = SOURCE_EXTERNAL
            If Not accountRowByID.Exists(accountID) Then _
                Err.Raise vbObjectError + 6125, "CommitExternalRows", "�����}�X�^�̏����ʒu���擾�ł��܂���: " & accountID
            masterRow = CLng(accountRowByID(accountID))
            If Not CBool(newAccountByKey(keyText)) Then
                masterSnapshot = existingMasterByID(accountID)
                If Len(CellText(masterSnapshot(1, ACC_COL_SOURCE))) > 0 Then
                    masterSource = CellText(masterSnapshot(1, ACC_COL_SOURCE))
                End If
            End If
            UpsertAccountMaster accountID, transferID, CStr(prepared(firstIndex, PREP_BANK)), _
                                CStr(prepared(firstIndex, PREP_BRANCH)), CStr(prepared(firstIndex, PREP_PERSON)), _
                                CStr(relationshipByKey(keyText)), CStr(prepared(firstIndex, PREP_TYPE)), _
                                CStr(prepared(firstIndex, PREP_ACCOUNT_NO)), DictionaryValueOrBlank(openDateByKey, keyText), _
                                DictionaryValueOrBlank(closeDateByKey, keyText), personID, masterSource, masterRow
        End If
    Next item

    If outCount > 0 Then
        MarkOutputsDirty
        InvalidateDuplicateAccountWarningCache
    End If
    committed = True
    importedCount = outCount

    On Error Resume Next
    For Each item In firstIndexByKey.Keys
        keyText = CStr(item)
        If accountHasRows.Exists(keyText) Then
            firstIndex = CLng(firstIndexByKey(keyText))
            Err.Clear
            AddBankCandidate CStr(prepared(firstIndex, PREP_BANK))
            If Err.Number <> 0 Then
                AppendExternalDetail postProcessDetail, "��s���: Err " & Err.Number & " " & Err.Description
            End If
            Err.Clear
            AddBranchCandidate CStr(prepared(firstIndex, PREP_BRANCH))
            If Err.Number <> 0 Then
                AppendExternalDetail postProcessDetail, "�x�X���: Err " & Err.Number & " " & Err.Description
            End If
            Err.Clear
            AddAccountTypeCandidate CStr(prepared(firstIndex, PREP_TYPE))
            If Err.Number <> 0 Then
                AppendExternalDetail postProcessDetail, "�Ȗڌ��: Err " & Err.Number & " " & Err.Description
            End If
            Err.Clear
            AddPersonCandidateWithID CStr(prepared(firstIndex, PREP_PERSON)), CStr(personIDByKey(keyText)), _
                                     CStr(relationshipByKey(keyText))
            If Err.Number <> 0 Then
                AppendExternalDetail postProcessDetail, "�l�����: Err " & Err.Number & " " & Err.Description
            End If
        End If
    Next item
    Err.Clear
    BuildRegisteredAccountsSheet False
    If Err.Number <> 0 Then
        AppendExternalDetail postProcessDetail, "�o�^�ς݌����ꗗ: Err " & Err.Number & " " & Err.Description
    End If
    Err.Clear
    On Error GoTo 0
    If Len(postProcessDetail) > 0 Then AddCheck "�x��", "�O���捞�㏈��", postProcessDetail
    Exit Sub

EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    If writeStarted And Not committed Then
        On Error Resume Next
        Err.Clear
        DeleteRowsForTransferDictionary wsTx, WORK_TX_COL_TRANSFER_ID, createdTransferIDs
        If Err.Number <> 0 Then _
            AppendExternalDetail rollbackDetail, "����s�̏����G���[: " & Err.Description
        Err.Clear
        DeleteRowsForTransferDictionary wsBal, WORK_BAL_COL_TRANSFER_ID, createdTransferIDs
        If Err.Number <> 0 Then _
            AppendExternalDetail rollbackDetail, "�c���s�̏����G���[: " & Err.Description
        Err.Clear
        CompactDeleteDataRowsByDictionary wsAcc, ACC_COL_TRANSFER_ID, ACC_COL_ID, createdAccountIDs
        If Err.Number <> 0 Then _
            AppendExternalDetail rollbackDetail, "�V�K�����̏����G���[: " & Err.Description
        Err.Clear
        RestoreExternalMasterSnapshots wsAcc, existingMasterByID
        If Err.Number <> 0 Then _
            AppendExternalDetail rollbackDetail, "���������}�X�^�̕����G���[: " & Err.Description
        Err.Clear
        rollbackVerifyDetail = VerifyExternalRollback(wsTx, wsBal, wsAcc, createdTransferIDs, createdAccountIDs, existingMasterByID)
        If Err.Number <> 0 Then
            AppendExternalDetail rollbackDetail, "�����m�F�G���[: " & Err.Description
        ElseIf Len(rollbackVerifyDetail) > 0 Then
            AppendExternalDetail rollbackDetail, rollbackVerifyDetail
        Else
            rollbackVerified = True
        End If
        Err.Clear
        On Error GoTo 0
    End If
    If idCountersCaptured And Not committed And (Not writeStarted Or rollbackVerified) Then
        On Error Resume Next
        Err.Clear
        RestoreInternalIdCounters idCounterSnapshot
        If Err.Number <> 0 Then
            AppendExternalDetail rollbackDetail, "ID�̔ԏ�Ԃ̕����G���[: " & Err.Description
        End If
        Err.Clear
        On Error GoTo 0
    End If
    If Len(rollbackDetail) > 0 Then
        If rollbackVerified Then
            errorDescription = errorDescription & " / ���[���o�b�N�����x���i�������ʂ͈�v�j: " & rollbackDetail
        Else
            errorDescription = errorDescription & " / ���[���o�b�N�m�F: " & rollbackDetail
        End If
    End If
    Err.Raise errorNumber, "CommitExternalRows", errorDescription
End Sub

Private Sub LoadExistingPersonIdIndex(ByVal personIndex As Object)
    '�O���捞���ɐl�����E�����}�X�^���������Ƃɍđ������Ȃ��B
    '����l�����ɈقȂ�ID�����ɂ���ꍇ�͒�~���邪�A�������ɂ�铯��ID�̕ʖ��`�͋��e����B
    Dim ws As Worksheet, lastR As Long, r As Long
    Dim sourceData As Variant
    If personIndex Is Nothing Then Exit Sub
    If SheetExists(SH_PERSON_CAND) Then
        Set ws = GetSheet(SH_PERSON_CAND)
        lastR = LastUsedRowInSheet(ws)
        If lastR >= 2 Then
            sourceData = ws.Range(ws.Cells(2, 1), ws.Cells(lastR, 3)).Value2
            For r = 1 To lastR - 1
                AddPersonIdToIndex personIndex, PersonLookupKey(CellText(sourceData(r, 1)), _
                                   CellText(sourceData(r, 3))), CellText(sourceData(r, 2)), _
                                   "�l����� " & CStr(r + 1) & "�s"
            Next r
        End If
    End If
    If SheetExists(SH_WORK_ACCOUNT) Then
        Set ws = GetSheet(SH_WORK_ACCOUNT)
        lastR = LastUsedRowInSheet(ws)
        If lastR >= 2 Then
            sourceData = ws.Range(ws.Cells(2, ACC_COL_PERSON), _
                                  ws.Cells(lastR, ACC_COL_PERSON_ID)).Value2
            For r = 1 To lastR - 1
                AddPersonIdToIndex personIndex, PersonLookupKey(CellText(sourceData(r, 1)), _
                                   CellText(sourceData(r, ACC_COL_RELATIONSHIP - ACC_COL_PERSON + 1))), _
                                   CellText(sourceData(r, ACC_COL_PERSON_ID - ACC_COL_PERSON + 1)), _
                                   "W_���� " & CStr(r + 1) & "�s"
            Next r
        End If
    End If
End Sub

Private Sub AddPersonIdToIndex(ByVal personIndex As Object, ByVal personNameKey As String, _
                               ByVal personID As String, ByVal sourceText As String)
    If personIndex Is Nothing Then Exit Sub
    If Len(personNameKey) = 0 Or Len(personID) = 0 Then Exit Sub
    If personIndex.Exists(personNameKey) Then
        If StrComp(CStr(personIndex(personNameKey)), personID, vbTextCompare) <> 0 Then
            Err.Raise vbObjectError + 6127, "LoadExistingPersonIdIndex", _
                      "���������E�����ɈقȂ�l��ID������܂��i" & sourceText & "�j�B��ɃZ���t�`�F�b�N�����s���Ă��������B"
        End If
    Else
        personIndex.Add personNameKey, personID
    End If
End Sub

Private Function PersonLookupKey(ByVal personName As String, ByVal relationshipText As String) As String
    PersonLookupKey = PersonIdentityKey(personName, relationshipText)
End Function

Private Sub LoadExistingAccountIndexes(ByVal wsAcc As Worksheet, ByVal accountIndex As Object, _
                                       ByVal locatorIndex As Object, ByVal rowByID As Object)
    Dim r As Long, lastR As Long
    Dim accountID As String, keyText As String, locatorKey As String
    Dim accountIDs As Object
    Dim sourceData As Variant
    If wsAcc Is Nothing Or accountIndex Is Nothing Or locatorIndex Is Nothing Or rowByID Is Nothing Then Exit Sub
    Set accountIDs = NewTextDictionary()
    lastR = LastUsedRowInSheet(wsAcc)
    If lastR < 2 Then Exit Sub
    sourceData = wsAcc.Range(wsAcc.Cells(2, ACC_COL_ID), wsAcc.Cells(lastR, ACC_COL_NO)).Value2
    For r = 1 To lastR - 1
        accountID = CellText(sourceData(r, ACC_COL_ID))
        If Len(accountID) = 0 Then
            Err.Raise vbObjectError + 6122, "LoadExistingAccountIndexes", _
                      "���������}�X�^�Ɍ���ID�̂Ȃ��s������܂��B��ɃZ���t�`�F�b�N�����s���Ă��������B"
        End If
        If accountIDs.Exists(accountID) Then
            Err.Raise vbObjectError + 6124, "LoadExistingAccountIndexes", _
                      "���������}�X�^�Ɍ���ID�̏d��������܂��B��ɃZ���t�`�F�b�N�����s���Ă�������: " & accountID
        End If
        accountIDs.Add accountID, True
        rowByID.Add accountID, r + 1
        keyText = CanonicalAccountKey(CellText(sourceData(r, ACC_COL_BANK)), _
                                      CellText(sourceData(r, ACC_COL_BRANCH)), _
                                      CellText(sourceData(r, ACC_COL_PERSON)), _
                                      CellText(sourceData(r, ACC_COL_TYPE)), _
                                      CellText(sourceData(r, ACC_COL_NO)))
        If accountIndex.Exists(keyText) Then
            Err.Raise vbObjectError + 6123, "LoadExistingAccountIndexes", _
                      "���������}�X�^�ɓ���������d�����Ă��܂��B��ɃZ���t�`�F�b�N�����s���Ă��������B"
        End If
        accountIndex.Add keyText, accountID
        locatorKey = CanonicalAccountLocatorKey(CellText(sourceData(r, ACC_COL_BANK)), _
                                                CellText(sourceData(r, ACC_COL_BRANCH)), _
                                                CellText(sourceData(r, ACC_COL_TYPE)), _
                                                CellText(sourceData(r, ACC_COL_NO)))
        If locatorIndex.Exists(locatorKey) Then
            Err.Raise vbObjectError + 6150, "LoadExistingAccountIndexes", _
                      "���������}�X�^�ɓ�����s�E�x�X�E�ȖځE�����ԍ��̏d��������܂��B��ɃZ���t�`�F�b�N�����s���Ă��������B"
        End If
        locatorIndex.Add locatorKey, accountID
    Next r
End Sub

Private Sub RestoreExternalMasterSnapshots(ByVal wsAcc As Worksheet, ByVal snapshots As Object)
    Dim item As Variant, r As Long, lastR As Long, nextR As Long
    Dim snapshot As Variant, idData As Variant, accountID As String
    Dim rowByID As Object
    Dim restoreProblems As String
    If wsAcc Is Nothing Or snapshots Is Nothing Then Exit Sub
    Set rowByID = NewTextDictionary()
    lastR = LastUsedRowInSheet(wsAcc)
    If lastR >= 2 Then
        idData = wsAcc.Range(wsAcc.Cells(2, ACC_COL_ID), wsAcc.Cells(lastR, ACC_COL_ID)).Value2
        For r = 1 To lastR - 1
            accountID = CellText(BulkArrayValue(idData, r))
            If Len(accountID) > 0 And Not rowByID.Exists(accountID) Then rowByID.Add accountID, r + 1
        Next r
    End If
    nextR = lastR + 1
    If nextR < 2 Then nextR = 2
    On Error Resume Next
    For Each item In snapshots.Keys
        Err.Clear
        accountID = CStr(item)
        If rowByID.Exists(accountID) Then
            r = CLng(rowByID(accountID))
        Else
            r = nextR
            nextR = nextR + 1
            rowByID.Add accountID, r
            If Err.Number <> 0 Then
                AppendExternalDetail restoreProblems, accountID & " �̕����ʒu����: " & Err.Description
                Err.Clear
            End If
        End If
        snapshot = snapshots(item)
        wsAcc.Range(wsAcc.Cells(r, 1), wsAcc.Cells(r, ACC_COL_TRANSFER_ID)).Value = snapshot
        If Err.Number <> 0 Then _
            AppendExternalDetail restoreProblems, accountID & " �̏��߂�: " & Err.Description
    Next item
    On Error GoTo 0
    If Len(restoreProblems) > 0 Then _
        Err.Raise vbObjectError + 6153, "RestoreExternalMasterSnapshots", restoreProblems
End Sub

Private Sub AppendExternalDetail(ByRef detailText As String, ByVal newDetail As String)
    newDetail = Trim$(newDetail)
    If Len(newDetail) = 0 Then Exit Sub
    If Len(detailText) > 0 Then detailText = detailText & " / "
    detailText = detailText & newDetail
End Sub

Private Function VerifyExternalRollback(ByVal wsTx As Worksheet, ByVal wsBal As Worksheet, ByVal wsAcc As Worksheet, _
                                        ByVal transferIDs As Object, ByVal accountIDs As Object, _
                                        ByVal masterSnapshots As Object) As String
    Dim r As Long, c As Long, item As Variant, problems As String, snapshot As Variant
    Dim lastR As Long, idText As String
    Dim transferData As Variant, accountData As Variant
    Dim accountRows As Object
    If Not wsTx Is Nothing Then
        lastR = LastUsedRowInSheet(wsTx)
        If lastR >= 2 Then _
            transferData = wsTx.Range(wsTx.Cells(2, WORK_TX_COL_TRANSFER_ID), _
                                      wsTx.Cells(lastR, WORK_TX_COL_TRANSFER_ID)).Value2
        For r = 1 To lastR - 1
            If transferIDs.Exists(CellText(BulkArrayValue(transferData, r))) Then
                problems = problems & "����s���c���Ă��܂��B "
                Exit For
            End If
        Next r
    End If
    If Not wsBal Is Nothing Then
        lastR = LastUsedRowInSheet(wsBal)
        If lastR >= 2 Then _
            transferData = wsBal.Range(wsBal.Cells(2, WORK_BAL_COL_TRANSFER_ID), _
                                       wsBal.Cells(lastR, WORK_BAL_COL_TRANSFER_ID)).Value2
        For r = 1 To lastR - 1
            If transferIDs.Exists(CellText(BulkArrayValue(transferData, r))) Then
                problems = problems & "�c���s���c���Ă��܂��B "
                Exit For
            End If
        Next r
    End If
    Set accountRows = NewTextDictionary()
    If Not wsAcc Is Nothing Then
        lastR = LastUsedRowInSheet(wsAcc)
        If lastR >= 2 Then
            accountData = wsAcc.Range(wsAcc.Cells(2, 1), wsAcc.Cells(lastR, ACC_COL_TRANSFER_ID)).Value2
            For r = 1 To UBound(accountData, 1)
                idText = CellText(accountData(r, ACC_COL_ID))
                If Len(idText) > 0 And Not accountRows.Exists(idText) Then accountRows.Add idText, r
            Next r
        End If
    End If
    For Each item In accountIDs.Keys
        If accountRows.Exists(CStr(item)) Then problems = problems & "�V�K�������c���Ă��܂��B ": Exit For
    Next item
    For Each item In masterSnapshots.Keys
        If Not accountRows.Exists(CStr(item)) Then
            problems = problems & "���������}�X�^������܂���B "
        Else
            r = CLng(accountRows(CStr(item)))
            snapshot = masterSnapshots(item)
            For c = 1 To ACC_COL_TRANSFER_ID
                If CellText(accountData(r, c)) <> CellText(snapshot(1, c)) Then
                    problems = problems & "���������}�X�^�������O�ƈ�v���܂���B "
                    Exit For
                End If
            Next c
        End If
    Next item
    VerifyExternalRollback = Trim$(problems)
End Function

Private Sub LoadExistingTransactionSignatures(ByVal ws As Worksheet, ByVal signatures As Object)
    Dim r As Long, lastR As Long, signatureText As String, accountID As String
    Dim coreData As Variant, accountData As Variant, recordTypeData As Variant
    If ws Is Nothing Or signatures Is Nothing Then Exit Sub
    lastR = LastUsedRowInSheet(ws)
    If lastR < 2 Then Exit Sub
    '�����ɕK�v�ȗ񂾂����ꊇ�擾���A1�s�ɂ��������Excel COM�ǎ�������B
    coreData = ws.Range(ws.Cells(2, OUT_COL_DATE), ws.Cells(lastR, OUT_COL_OTHER)).Value2
    accountData = ws.Range(ws.Cells(2, WORK_TX_COL_ACCOUNT_ID), _
                           ws.Cells(lastR, WORK_TX_COL_ACCOUNT_ID)).Value2
    recordTypeData = ws.Range(ws.Cells(2, WORK_TX_COL_RECORD_TYPE), _
                              ws.Cells(lastR, WORK_TX_COL_RECORD_TYPE)).Value2
    For r = 1 To lastR - 1
        accountID = CellText(BulkArrayValue(accountData, r))
        signatureText = ""
        If Len(accountID) > 0 Then
            signatureText = accountID & Chr$(28) & DateSignature(coreData(r, 1)) & Chr$(28) & _
                            TimeSignature(coreData(r, 2)) & Chr$(28) & AmountSignature(coreData(r, 3)) & Chr$(28) & _
                            AmountSignature(coreData(r, 4)) & Chr$(28) & CellText(coreData(r, 5)) & Chr$(28) & _
                            CellText(coreData(r, 6)) & Chr$(28) & CellText(coreData(r, 7)) & Chr$(28) & _
                            AmountSignature(coreData(r, 8)) & Chr$(28) & _
                            CellText(BulkArrayValue(recordTypeData, r))
        End If
        If Len(signatureText) > 0 Then IncrementDictionaryCount signatures, signatureText
    Next r
End Sub

Private Sub LoadExistingBalanceIndex(ByVal ws As Worksheet, ByVal balanceAmounts As Object)
    Dim r As Long, lastR As Long, keyText As String, accountID As String
    Dim accountData As Variant, dateAmountData As Variant, balanceDate As Variant, balanceAmount As Variant
    If ws Is Nothing Or balanceAmounts Is Nothing Then Exit Sub
    lastR = LastUsedRowInSheet(ws)
    If lastR < 2 Then Exit Sub
    accountData = ws.Range(ws.Cells(2, WORK_BAL_COL_ACCOUNT_ID), _
                           ws.Cells(lastR, WORK_BAL_COL_ACCOUNT_ID)).Value2
    dateAmountData = ws.Range(ws.Cells(2, 8), ws.Cells(lastR, 10)).Value2
    For r = 1 To lastR - 1
        accountID = CellText(BulkArrayValue(accountData, r))
        balanceDate = dateAmountData(r, 1)
        balanceAmount = dateAmountData(r, 3)
        If Len(accountID) = 0 Or Not IsDate(balanceDate) Or _
           Not HasText(balanceAmount) Or Not IsNumeric(balanceAmount) Then
            Err.Raise vbObjectError + 6135, "LoadExistingBalanceIndex", _
                      "�����̎c���ۊǂ��s���ł��B��ɃZ���t�`�F�b�N�����s���Ă��������iW_�c�� " & CStr(r + 1) & "�s�j�B"
        End If
        keyText = BalanceImportKey(accountID, balanceDate)
        If balanceAmounts.Exists(keyText) Then
            Err.Raise vbObjectError + 6136, "LoadExistingBalanceIndex", _
                      "�����̎c���ۊǂɓ�������E�������̏d��������܂�: " & accountID
        End If
        balanceAmounts.Add keyText, AmountSignature(balanceAmount)
    Next r
End Sub

Private Function BalanceImportKey(ByVal accountID As String, ByVal balanceDate As Variant) As String
    BalanceImportKey = CellText(accountID) & Chr$(29) & DateSignature(balanceDate)
End Function

Private Function IncrementDictionaryCount(ByVal dict As Object, ByVal keyText As String) As Long
    If dict.Exists(keyText) Then
        dict(keyText) = CLng(dict(keyText)) + 1
    Else
        dict.Add keyText, 1
    End If
    IncrementDictionaryCount = CLng(dict(keyText))
End Function

Private Function DictionaryLongValue(ByVal dict As Object, ByVal keyText As String) As Long
    If Not dict Is Nothing Then
        If dict.Exists(keyText) Then DictionaryLongValue = CLng(dict(keyText))
    End If
End Function

Private Sub LoadExistingSpecialRecordDates(ByVal ws As Worksheet, ByVal specialDates As Object)
    Dim r As Long, lastR As Long
    Dim accountID As String, recordType As String, keyText As String
    Dim dateData As Variant, accountData As Variant, recordTypeData As Variant, recordDate As Variant
    If ws Is Nothing Or specialDates Is Nothing Then Exit Sub
    lastR = LastUsedRowInSheet(ws)
    If lastR < 2 Then Exit Sub
    dateData = ws.Range(ws.Cells(2, OUT_COL_DATE), ws.Cells(lastR, OUT_COL_DATE)).Value2
    accountData = ws.Range(ws.Cells(2, WORK_TX_COL_ACCOUNT_ID), _
                           ws.Cells(lastR, WORK_TX_COL_ACCOUNT_ID)).Value2
    recordTypeData = ws.Range(ws.Cells(2, WORK_TX_COL_RECORD_TYPE), _
                              ws.Cells(lastR, WORK_TX_COL_RECORD_TYPE)).Value2
    For r = 1 To lastR - 1
        recordType = CellText(BulkArrayValue(recordTypeData, r))
        If recordType = RECORD_OPEN Or recordType = RECORD_CLOSE Then
            accountID = CellText(BulkArrayValue(accountData, r))
            If Len(accountID) = 0 Then
                Err.Raise vbObjectError + 6120, "LoadExistingSpecialRecordDates", _
                          "�����̌����J�ݓ��E���������s���s���ł��B��ɃZ���t�`�F�b�N�����s���Ă��������B"
            End If
            recordDate = BulkArrayValue(dateData, r)
            If IsError(recordDate) Then
                Err.Raise vbObjectError + 8019, "LoadExistingSpecialRecordDates", _
                          "�����̌����J�ݓ��E���������s���s���ł��B��ɃZ���t�`�F�b�N�����s���Ă��������B"
            End If
            If Not IsDate(recordDate) Then
                Err.Raise vbObjectError + 8020, "LoadExistingSpecialRecordDates", _
                          "�����̌����J�ݓ��E���������s���s���ł��B��ɃZ���t�`�F�b�N�����s���Ă��������B"
            End If
            keyText = ExistingSpecialRecordKey(accountID, recordType)
            If specialDates.Exists(keyText) Then
                Err.Raise vbObjectError + 6121, "LoadExistingSpecialRecordDates", _
                          "�����̌����J�ݓ��E���������s���d�����Ă��܂�: " & accountID
            End If
            specialDates.Add keyText, DateSignature(recordDate)
        End If
    Next r
End Sub

Private Function ExistingSpecialRecordKey(ByVal accountID As String, ByVal recordType As String) As String
    ExistingSpecialRecordKey = CellText(accountID) & Chr$(29) & CellText(recordType)
End Function

Private Function ExternalRecordSignature(ByVal accountID As String, ByRef prepared() As Variant, ByVal r As Long) As String
    ExternalRecordSignature = accountID & Chr$(28) & DateSignature(prepared(r, PREP_DATE)) & Chr$(28) & _
                              TimeSignature(prepared(r, PREP_TIME)) & Chr$(28) & AmountSignature(prepared(r, PREP_WITHDRAW)) & Chr$(28) & _
                              AmountSignature(prepared(r, PREP_DEPOSIT)) & Chr$(28) & CellText(prepared(r, PREP_SHOP)) & Chr$(28) & _
                              CellText(prepared(r, PREP_MACHINE)) & Chr$(28) & CellText(prepared(r, PREP_TEKIYO)) & Chr$(28) & _
                              AmountSignature(prepared(r, PREP_AFTER_BALANCE)) & Chr$(28) & CellText(prepared(r, PREP_RECORD_TYPE))
End Function

Private Function DateSignature(ByVal v As Variant) As String
    If IsDate(v) Then DateSignature = Format$(CDate(v), "yyyymmdd") Else DateSignature = CellText(v)
End Function

Private Function TimeSignature(ByVal v As Variant) As String
    If IsDate(v) Then TimeSignature = Format$(CDate(v), "hhmm") Else TimeSignature = CellText(v)
End Function

Private Function AmountSignature(ByVal v As Variant) As String
    If IsNumeric(v) And HasText(v) Then AmountSignature = Format$(CDbl(v), "0.################") Else AmountSignature = CellText(v)
End Function

Private Sub DeleteRowsForTransferDictionary(ByVal ws As Worksheet, ByVal transferIDCol As Long, ByVal transferIDs As Object)
    Dim lastColumn As Long
    If ws Is Nothing Or transferIDs Is Nothing Then Exit Sub
    If ws.Name = SH_WORK_TX Then
        lastColumn = WORK_TX_COL_PERSON_ID
    ElseIf ws.Name = SH_WORK_BAL Then
        lastColumn = WORK_BAL_COL_PERSON_ID
    Else
        Err.Raise vbObjectError + 6151, "DeleteRowsForTransferDictionary", _
                  "�ΏۊO�̓����V�[�g�ł�: " & ws.Name
    End If
    CompactDeleteDataRowsByDictionary ws, lastColumn, transferIDCol, transferIDs
End Sub

Private Sub FormatImportedWorkRows(ByVal ws As Worksheet, ByVal firstR As Long, ByVal lastR As Long)
    ws.Range(ws.Cells(firstR, 1), ws.Cells(lastR, OUT_COL_ACCOUNT_NO)).NumberFormat = "@"
    ws.Range(ws.Cells(firstR, OUT_COL_SHOP), ws.Cells(lastR, OUT_COL_TEKIYO)).NumberFormat = "@"
    ws.Range(ws.Cells(firstR, WORK_TX_COL_RELATIONSHIP), ws.Cells(lastR, WORK_TX_COL_PERSON_ID)).NumberFormat = "@"
    ws.Range(ws.Cells(firstR, OUT_COL_DATE), ws.Cells(lastR, OUT_COL_DATE)).NumberFormat = "yyyy/m/d"
    ws.Range(ws.Cells(firstR, OUT_COL_TIME), ws.Cells(lastR, OUT_COL_TIME)).NumberFormat = "hh:mm"
    ws.Range(ws.Cells(firstR, OUT_COL_WITHDRAW), ws.Cells(lastR, OUT_COL_DEPOSIT)).NumberFormat = "#,##0.########"
    ws.Range(ws.Cells(firstR, OUT_COL_OTHER), ws.Cells(lastR, OUT_COL_OTHER)).NumberFormat = "#,##0.########"
End Sub

Private Sub FormatImportedBalanceRows(ByVal ws As Worksheet, ByVal firstR As Long, ByVal lastR As Long)
    If ws Is Nothing Or firstR < 2 Or lastR < firstR Then Exit Sub
    ws.Range(ws.Cells(firstR, 1), ws.Cells(lastR, 5)).NumberFormat = "@"
    ws.Range(ws.Cells(firstR, 9), ws.Cells(lastR, 9)).NumberFormat = "@"
    ws.Range(ws.Cells(firstR, 11), ws.Cells(lastR, WORK_BAL_COL_PERSON_ID)).NumberFormat = "@"
    ws.Range(ws.Cells(firstR, 6), ws.Cells(lastR, 8)).NumberFormat = "yyyy/m/d"
    ws.Range(ws.Cells(firstR, 10), ws.Cells(lastR, 10)).NumberFormat = "#,##0.########"
End Sub

Private Function DictionaryValueOrBlank(ByVal dict As Object, ByVal keyText As String) As Variant
    If dict.Exists(keyText) Then DictionaryValueOrBlank = dict(keyText) Else DictionaryValueOrBlank = ""
End Function

Private Function BulkArrayValue(ByRef sourceData As Variant, ByVal rowIndex As Long, _
                                Optional ByVal colIndex As Long = 1) As Variant
    'Excel��1�Z��Range.Value2������2�����z��ł͂Ȃ��X�J���[��Ԃ����߁A�ꊇ�Ǎ����ŋz������B
    If IsArray(sourceData) Then
        BulkArrayValue = sourceData(rowIndex, colIndex)
    ElseIf rowIndex = 1 And colIndex = 1 Then
        BulkArrayValue = sourceData
    Else
        Err.Raise vbObjectError + 6152, "BulkArrayValue", "�ꊇ�Ǎ��z��͈̔͂��s���ł��B"
    End If
End Function

Private Function NewTextDictionary() As Object
    Dim dict As Object
    Set dict = CreateObject("Scripting.Dictionary")
    dict.CompareMode = vbTextCompare
    Set NewTextDictionary = dict
End Function

Private Sub AddImportError(ByVal messageText As String, ByVal sourceRow As Long, ByRef errorCount As Long, _
                           ByRef firstError As String, ByRef firstErrorRow As Long)
    errorCount = errorCount + 1
    If Len(firstError) = 0 Then
        firstError = messageText
        firstErrorRow = sourceRow
    End If
End Sub

Private Sub AddExternalCellValueError(ByVal valueIn As Variant, ByVal labelText As String, _
                                      ByVal sourceRow As Long, ByRef errorCount As Long, _
                                      ByRef firstError As String, ByRef firstErrorRow As Long)
    '�C�Ӎ��ڂ�Excel�G���[�l���󗓂Ƃ��Ėق��Ď�荞�܂Ȃ��B
    If IsError(valueIn) Then _
        AddImportError labelText & "��Excel�G���[�l�ł��B�捞���̐����܂��͒l���C�����Ă��������B", _
                       sourceRow, errorCount, firstError, firstErrorRow
End Sub

Private Sub AddImportLengthError(ByVal valueText As String, ByVal maxLength As Long, ByVal labelText As String, _
                                 ByVal sourceRow As Long, ByRef errorCount As Long, _
                                 ByRef firstError As String, ByRef firstErrorRow As Long)
    If Len(valueText) > maxLength Then
        AddImportError labelText & "��" & CStr(maxLength) & "�����ȓ��ɂ��Ă��������B", _
                       sourceRow, errorCount, firstError, firstErrorRow
    End If
End Sub

Private Function ParseExternalDate(ByVal v As Variant, ByRef ok As Boolean) As Variant
    Dim d As Variant
    ok = False
    If IsError(v) Or IsNull(v) Or IsEmpty(v) Then Exit Function
    If IsDate(v) Then
        ParseExternalDate = NormalizeDateOnlyValue(v, ok)
        Exit Function
    End If
    d = ResolveAccountDateInput(v, ok)
    If ok Then
        If IsDate(d) Then
            ParseExternalDate = CDate(d)
        Else
            ok = False
        End If
    End If
End Function

Private Function ExternalIdentifierText(ByVal sourceCell As Range, _
                                        Optional ByVal suppliedValue As Variant) As String
    '�����ԍ��E�戵�X�R�[�h�E�@�Ԃ͎��ʎq�B���l�Z���ł��\�������̐擪�[�����\�Ȍ���ێ�����B
    Dim shownText As String, formatText As String, zeroMask As String
    Dim formatParts As Variant
    Dim rawValue As Variant
    Dim i As Long, ch As String
    If sourceCell Is Nothing Then Exit Function
    If IsMissing(suppliedValue) Then rawValue = sourceCell.Value2 Else rawValue = suppliedValue
    If VarType(rawValue) = vbString Then
        ExternalIdentifierText = CellText(rawValue)
        Exit Function
    End If
    If Not HasText(rawValue) Then Exit Function
    shownText = Trim$(CStr(sourceCell.Text))
    '�Z���\���͐擪�[����n�C�t���̕ێ��ɂ����g���B����؂�A�ʉ݁A���t�Ȃǂ�
    '�\������������ʎq�Ƃ��Ď�荞�ނƕʔԍ��ɂȂ邽�ߍ̗p���Ȃ��B
    If IsSafeDisplayedIdentifierText(shownText) Then
        ExternalIdentifierText = shownText
        Exit Function
    End If
    If IsNumeric(rawValue) Then
        formatParts = Split(CStr(sourceCell.NumberFormat), ";")
        formatText = CStr(formatParts(LBound(formatParts)))
        For i = 1 To Len(formatText)
            ch = Mid$(formatText, i, 1)
            If ch = "0" Then zeroMask = zeroMask & "0"
        Next i
        If Len(zeroMask) > 0 And InStr(1, formatText, "E", vbTextCompare) = 0 And _
           InStr(1, formatText, "y", vbTextCompare) = 0 And InStr(1, formatText, "d", vbTextCompare) = 0 Then
            ExternalIdentifierText = Format$(CDbl(rawValue), zeroMask)
            Exit Function
        End If
    End If
    ExternalIdentifierText = CellText(rawValue)
End Function

Private Function IsSafeDisplayedIdentifierText(ByVal shownText As String) As Boolean
    Dim s As String, ch As String, i As Long
    Dim hasDigit As Boolean
    s = NormalizeAccountHyphen(Trim$(shownText))
    If Len(s) = 0 Or InStr(s, "#") > 0 Or InStr(1, s, "E", vbTextCompare) > 0 Then Exit Function
    For i = 1 To Len(s)
        ch = Mid$(s, i, 1)
        If ch >= "0" And ch <= "9" Then
            hasDigit = True
        ElseIf ch <> "-" Then
            Exit Function
        End If
    Next i
    IsSafeDisplayedIdentifierText = hasDigit
End Function

Private Function PrepareExternalIdentifier(ByVal rawValue As Variant, ByVal sourceSheet As Worksheet, _
                                           ByVal sourceRow As Long, ByVal sourceColumn As Long, _
                                           ByVal labelText As String, ByRef errorCount As Long, _
                                           ByRef firstError As String, ByRef firstErrorRow As Long) As String
    'Excel���l�͗L������15���܂ŁB16���ȏ�̎��ʎq�𐔒l�Z������ǂނƁA���Ɋۂ߂�ꂽ�l��
    '�����������ԍ��E�R�[�h�Ƃ��ēo�^���Ă��܂����߁A���\���ŕ����񉻂��Ă��炤�B
    '������Z���͎捞�z�񂾂��ŏ������A�\�������̊m�F���K�v�Ȑ��l�Z������Range�֐G���B
    Dim numericValue As Double
    Dim sourceCell As Range
    If IsError(rawValue) Or IsNull(rawValue) Or IsEmpty(rawValue) Then Exit Function
    If VarType(rawValue) = vbString Then
        PrepareExternalIdentifier = CellText(rawValue)
        Exit Function
    End If
    If VarType(rawValue) = vbBoolean Then
        AddImportError labelText & "��TRUE/FALSE�ł��B���ʎq�͕�����܂���0�ȏ�̐����ŕۑ����Ă��������B", _
                       sourceRow, errorCount, firstError, firstErrorRow
        PrepareExternalIdentifier = CellText(rawValue)
        Exit Function
    End If
    If Not IsNumeric(rawValue) Then
        PrepareExternalIdentifier = CellText(rawValue)
        Exit Function
    End If
    On Error GoTo UnsafeIdentifier
    numericValue = CDbl(rawValue)
    If numericValue < 0 Then
        AddImportError labelText & "�����̐��l�Z���ł��B���ʎq��0�ȏ�̐����܂��͕�����ŕۑ����Ă��������B", _
                       sourceRow, errorCount, firstError, firstErrorRow
        PrepareExternalIdentifier = CellText(rawValue)
        Exit Function
    ElseIf numericValue <> Fix(numericValue) Then
        AddImportError labelText & "�������̐��l�Z���ł��B���ʎq�͐����܂��͕�����ŕۑ����Ă��������B", _
                       sourceRow, errorCount, firstError, firstErrorRow
        PrepareExternalIdentifier = CellText(rawValue)
        Exit Function
    ElseIf numericValue >= 1000000000000000# Then
        AddImportError labelText & "��16���ȏ�̐��l�Z���ł��B���ۂ߂�h�����߁A�捞���ŕ�����Ƃ��ĕۑ����Ă��������B", _
                       sourceRow, errorCount, firstError, firstErrorRow
        PrepareExternalIdentifier = CellText(rawValue)
        Exit Function
    End If
    Set sourceCell = sourceSheet.Cells(sourceRow, sourceColumn)
    PrepareExternalIdentifier = ExternalIdentifierText(sourceCell, rawValue)
    Exit Function
UnsafeIdentifier:
    AddImportError labelText & "��16���ȏ�̐��l�Z���ł��B���ۂ߂�h�����߁A�捞���ŕ�����Ƃ��ĕۑ����Ă��������B", _
                   sourceRow, errorCount, firstError, firstErrorRow
    PrepareExternalIdentifier = CellText(rawValue)
    Err.Clear
End Function

Private Sub SplitExternalPerson(ByVal displayText As String, ByRef personName As String, ByRef relationshipText As String)
    Dim p As Long
    personName = CellText(displayText)
    relationshipText = ""
    If Right$(personName, 1) = "�j" Then
        p = InStrRev(personName, "�i")
        If p > 1 Then
            relationshipText = Mid$(personName, p + 1, Len(personName) - p - 1)
            personName = Trim$(Left$(personName, p - 1))
            Exit Sub
        End If
    End If
    If Right$(personName, 1) = ")" Then
        p = InStrRev(personName, "(")
        If p > 1 Then
            relationshipText = Mid$(personName, p + 1, Len(personName) - p - 1)
            personName = Trim$(Left$(personName, p - 1))
        End If
    End If
End Sub

Private Function BuildExistingRelationshipLookup() As Object
    '�����l�����ɕ����̑���������ꍇ�͎����⊮���Ȃ��A�Ƃ��������d�l��ۂ����܂�
    '���\�ƌ����}�X�^���e1�񂾂���������B
    Dim relationshipByPerson As Object, seenPairs As Object
    Set relationshipByPerson = NewTextDictionary()
    Set seenPairs = NewTextDictionary()
    If SheetExists(SH_PERSON_CAND) Then
        AddExistingRelationshipsToLookup GetSheet(SH_PERSON_CAND), 1, 3, relationshipByPerson, seenPairs
    End If
    If SheetExists(SH_WORK_ACCOUNT) Then
        AddExistingRelationshipsToLookup GetSheet(SH_WORK_ACCOUNT), ACC_COL_PERSON, ACC_COL_RELATIONSHIP, _
                                         relationshipByPerson, seenPairs
    End If
    Set BuildExistingRelationshipLookup = relationshipByPerson
End Function

Private Sub AddExistingRelationshipsToLookup(ByVal ws As Worksheet, ByVal personColumn As Long, _
                                              ByVal relationshipColumn As Long, _
                                              ByVal relationshipByPerson As Object, ByVal seenPairs As Object)
    Dim lastR As Long, firstColumn As Long, lastColumn As Long, dataRow As Long
    Dim personOffset As Long, relationshipOffset As Long
    Dim sourceData As Variant
    Dim personText As String, personKey As String
    Dim relationshipText As String, relationshipKey As String, pairKey As String
    If ws Is Nothing Then Exit Sub
    If relationshipByPerson Is Nothing Or seenPairs Is Nothing Then Exit Sub
    lastR = LastUsedRowInSheet(ws)
    If lastR < 2 Then Exit Sub
    firstColumn = Application.Min(personColumn, relationshipColumn)
    lastColumn = Application.Max(personColumn, relationshipColumn)
    personOffset = personColumn - firstColumn + 1
    relationshipOffset = relationshipColumn - firstColumn + 1
    sourceData = ws.Range(ws.Cells(2, firstColumn), ws.Cells(lastR, lastColumn)).Value2
    For dataRow = 1 To lastR - 1
        personText = CellText(BulkArrayValue(sourceData, dataRow, personOffset))
        relationshipText = CellText(BulkArrayValue(sourceData, dataRow, relationshipOffset))
        personKey = NormalizePersonNameKey(personText)
        relationshipKey = NormalizeRelationshipKey(relationshipText)
        If Len(personKey) > 0 And Len(relationshipKey) > 0 Then
            pairKey = personKey & Chr$(28) & relationshipKey
            If Not seenPairs.Exists(pairKey) Then
                seenPairs.Add pairKey, True
                If relationshipByPerson.Exists(personKey) Then
                    '2��ވȏ゠��ΞB���B�󕶎���ێ����A�㑱�̓��������Ō��֖߂��Ȃ��B
                    relationshipByPerson(personKey) = ""
                Else
                    relationshipByPerson.Add personKey, relationshipText
                End If
            End If
        End If
    Next dataRow
End Sub

Private Function RelationshipFromExistingLookup(ByVal relationshipByPerson As Object, _
                                                 ByVal personName As String) As String
    Dim personKey As String
    If relationshipByPerson Is Nothing Then Exit Function
    personKey = NormalizePersonNameKey(personName)
    If Len(personKey) = 0 Then Exit Function
    If relationshipByPerson.Exists(personKey) Then _
        RelationshipFromExistingLookup = CellText(relationshipByPerson(personKey))
End Function

Private Sub ValidateExternalHeaders(ByVal bankCol As Long, ByVal branchCol As Long, ByVal personCol As Long, _
                                    ByVal typeCol As Long, ByVal accountCol As Long, ByVal dateCol As Long, _
                                    ByVal withdrawCol As Long, ByVal depositCol As Long, ByVal shopCol As Long, _
                                    ByVal machineCol As Long, ByVal tekiyoCol As Long, ByVal balanceCol As Long)
    Dim missing As String
    If bankCol = 0 Then missing = missing & "��s���A"
    If branchCol = 0 Then missing = missing & "�x�X���A"
    If personCol = 0 Then missing = missing & "�����A"
    If typeCol = 0 Then missing = missing & "�ȖځA"
    If accountCol = 0 Then missing = missing & "�����ԍ��A"
    If dateCol = 0 Then missing = missing & "���t�A"
    If withdrawCol = 0 Then missing = missing & "�o���A"
    If depositCol = 0 Then missing = missing & "�����A"
    If shopCol = 0 Then missing = missing & "�戵�X�A"
    If machineCol = 0 Then missing = missing & "�@�ԁA"
    If tekiyoCol = 0 Then missing = missing & "�E�v�A"
    If balanceCol = 0 Then missing = missing & "�����c���A"
    If Len(missing) > 0 Then
        missing = Left$(missing, Len(missing) - 1)
        Err.Raise vbObjectError + 6103, "ValidateExternalHeaders", "�K�v�Ȍ��o��������܂���: " & missing
    End If
End Sub

Private Sub ValidateExternalHeaderUniqueness(ByVal values As Variant)
    Dim counts(1 To 13) As Long
    Dim c As Long, kindNo As Long
    For c = LBound(values, 2) To UBound(values, 2)
        kindNo = HeaderKind(values(1, c))
        If kindNo >= 1 And kindNo <= 13 Then counts(kindNo) = counts(kindNo) + 1
    Next c
    For kindNo = 1 To 13
        If counts(kindNo) > 1 Then
            Err.Raise vbObjectError + 6104, "ValidateExternalHeaderUniqueness", _
                      "���������̌��o������������܂�: " & ExternalHeaderName(kindNo)
        End If
    Next kindNo
End Sub

Private Function ExternalHeaderName(ByVal kindNo As Long) As String
    Select Case kindNo
        Case 1: ExternalHeaderName = "��s��"
        Case 2: ExternalHeaderName = "�x�X��"
        Case 3: ExternalHeaderName = "����"
        Case 4: ExternalHeaderName = "�Ȗ�"
        Case 5: ExternalHeaderName = "�����ԍ�"
        Case 6: ExternalHeaderName = "���t"
        Case 7: ExternalHeaderName = "����"
        Case 8: ExternalHeaderName = "�o��"
        Case 9: ExternalHeaderName = "����"
        Case 10: ExternalHeaderName = "�戵�X"
        Case 11: ExternalHeaderName = "�@��"
        Case 12: ExternalHeaderName = "�E�v"
        Case 13: ExternalHeaderName = "�����c��"
        Case 14: ExternalHeaderName = "�l��ID"
        Case 15: ExternalHeaderName = "����"
        Case Else: ExternalHeaderName = CStr(kindNo)
    End Select
End Function

Private Function FindExternalTableSheet(ByVal wb As Workbook, ByRef headerRow As Long) As Worksheet
    Dim ws As Worksheet, r As Long, c As Long, bestRow As Long
    Dim lastR As Long, lastC As Long
    Dim kinds(1 To 13) As Boolean, kindNo As Long, hasMandatory As Boolean
    Dim candidateCount As Long, candidateLocations As String
    For Each ws In wb.Worksheets
        lastR = ExternalLastUsedRow(ws)
        lastC = ExternalLastUsedColumn(ws)
        If lastR > MAX_EXTERNAL_DATA_ROWS + 10 Or lastC > MAX_EXTERNAL_COLUMNS Then
            Err.Raise vbObjectError + 6108, "FindExternalTableSheet", _
                      "�捞���u" & ws.Name & "�v�̎g�p�͈͂�����𒴂��Ă��܂��B�K�v�ȕ\�����̃u�b�N�֕����Ă��������B"
        End If
        For r = 1 To Application.Min(10, lastR)
            For kindNo = 1 To 13
                kinds(kindNo) = False
            Next kindNo
            For c = 1 To lastC
                kindNo = HeaderKind(ws.Cells(r, c).Value)
                If kindNo >= 1 And kindNo <= 13 Then
                    kinds(kindNo) = True
                End If
            Next c
            hasMandatory = HasMandatoryExternalHeaderKinds(kinds)
            If hasMandatory Then
                candidateCount = candidateCount + 1
                If candidateCount <= 10 Then
                    If Len(candidateLocations) > 0 Then candidateLocations = candidateLocations & "�A"
                    candidateLocations = candidateLocations & ws.Name & "!" & CStr(r) & "�s"
                End If
                If candidateCount = 1 Then
                    bestRow = r
                    Set FindExternalTableSheet = ws
                End If
            End If
        Next r
    Next ws
    If candidateCount = 0 Then
        Set FindExternalTableSheet = Nothing
        headerRow = 0
    ElseIf candidateCount > 1 Then
        Set FindExternalTableSheet = Nothing
        headerRow = 0
        Err.Raise vbObjectError + 6109, "FindExternalTableSheet", _
                  "�捞�\�ȕ\��" & CStr(candidateCount) & "��������܂��B�捞�Ώۂ����̃u�b�N�֕����Ă�������: " & _
                  candidateLocations
    Else
        headerRow = bestRow
    End If
End Function

Private Function HasMandatoryExternalHeaderKinds(ByRef kinds() As Boolean) As Boolean
    Dim kindNo As Long
    '����(7)�����͔C�ӁB����ȊO��13���`�͌�񐄑�������邽�ߕK�{�Ƃ���B
    For kindNo = 1 To 13
        If kindNo <> 7 Then
            If Not kinds(kindNo) Then Exit Function
        End If
    Next kindNo
    HasMandatoryExternalHeaderKinds = True
End Function

Private Function FindHeaderColumn(ByVal values As Variant, ByVal kindNo As Long) As Long
    Dim c As Long
    For c = LBound(values, 2) To UBound(values, 2)
        If HeaderKind(values(1, c)) = kindNo Then FindHeaderColumn = c: Exit Function
    Next c
End Function

Private Function HeaderKind(ByVal headerValue As Variant) As Long
    Dim s As String
    s = NormalizeHeaderText(CellText(headerValue))
    Select Case s
        Case "��s��", "���Z�@�֖�", "��s�����": HeaderKind = 1
        Case "�x�X��", "�X��", "�x�X�����": HeaderKind = 2
        Case "����", "���`�l", "�������`�l", "�l��", "�l�����", "�������": HeaderKind = 3
        Case "�Ȗ�", "�a�����", "�������", "�Ȗڌ��": HeaderKind = 4
        Case "�����ԍ�": HeaderKind = 5
        Case "���t", "�����": HeaderKind = 6
        Case "����", "����", "�������": HeaderKind = 7
        Case "�o��", "�o���z", "�x�����z": HeaderKind = 8
        Case "����", "�����z", "�a����z": HeaderKind = 9
        Case "�戵�X", "�X��", "�戵�X�ԍ�": HeaderKind = 10
        Case "�@��", "�@�B�ԍ�": HeaderKind = 11
        Case "�E�v", "�E�v��", "���e", "�E�v���": HeaderKind = 12
        Case "�����c��", "�c��", "���̑�": HeaderKind = 13
        Case "�l��ID": HeaderKind = 14
        Case "����", "�֌W": HeaderKind = 15
    End Select
End Function

Private Function NormalizeHeaderText(ByVal valueText As String) As String
    Dim s As String
    s = valueText
    s = Replace(s, " ", "")
    s = Replace(s, "�@", "")
    s = Replace(s, vbCr, "")
    s = Replace(s, vbLf, "")
    s = Replace(s, "�F", "")
    s = Replace(s, ":", "")
    NormalizeHeaderText = s
End Function

Private Function ExternalArrayRowHasData(ByVal values As Variant, ByVal r As Long) As Boolean
    Dim c As Long
    For c = LBound(values, 2) To UBound(values, 2)
        If IsError(values(r, c)) Or HasText(values(r, c)) Then ExternalArrayRowHasData = True: Exit Function
    Next c
End Function

Private Function ExternalLastMappedDataRow(ByVal ws As Worksheet, ByVal headerRow As Long, _
                                           ByVal mappedColumns As Variant) As Long
    '�\�̉���E�ɂ��������������s�Ƃ��Đ������A�F���ςݗ񂾂��ŏI�[�����߂�B
    Dim item As Variant, columnNo As Long, rowNo As Long
    ExternalLastMappedDataRow = headerRow
    If ws Is Nothing Then Exit Function
    For Each item In mappedColumns
        columnNo = CLng(item)
        If columnNo > 0 Then
            rowNo = ws.Cells(ws.Rows.Count, columnNo).End(xlUp).Row
            If rowNo > ExternalLastMappedDataRow Then ExternalLastMappedDataRow = rowNo
        End If
    Next item
End Function

Private Sub ValidateExternalMappedColumnsNoFormulas(ByVal ws As Worksheet, ByVal headerRow As Long, _
                                                    ByVal lastRow As Long, ByVal mappedColumns As Variant)
    '�捞�l���Čv�Z����O�������N�ŕς��Ȃ��悤�A�F���Ώۗ�͌Œ�l�������󂯕t����B
    Dim item As Variant, columnNo As Long
    Dim formulaCells As Range
    If ws Is Nothing Or lastRow < headerRow Then Exit Sub
    For Each item In mappedColumns
        columnNo = CLng(item)
        If columnNo > 0 Then
            Set formulaCells = Nothing
            On Error Resume Next
            Err.Clear
            Set formulaCells = ws.Range(ws.Cells(headerRow, columnNo), _
                                        ws.Cells(lastRow, columnNo)).SpecialCells(xlCellTypeFormulas)
            Err.Clear
            On Error GoTo 0
            If Not formulaCells Is Nothing Then
                Err.Raise vbObjectError + 6155, "ValidateExternalMappedColumnsNoFormulas", _
                          "�捞�Ώۗ�ɐ���������܂��B�l�֒u�������Ă���Ď��s���Ă�������: " & _
                          ws.Name & "!" & formulaCells.Cells(1, 1).Address(False, False)
            End If
        End If
    Next item
End Sub

Private Function ExternalLastUsedRow(ByVal ws As Worksheet) As Long
    Dim f As Range
    On Error Resume Next
    Set f = ws.Cells.Find(What:="*", After:=ws.Cells(1, 1), LookIn:=xlFormulas, LookAt:=xlPart, _
                          SearchOrder:=xlByRows, SearchDirection:=xlPrevious, MatchCase:=False, _
                          MatchByte:=False, SearchFormat:=False)
    If Not f Is Nothing Then ExternalLastUsedRow = f.Row
    On Error GoTo 0
End Function

Private Function ExternalLastUsedColumn(ByVal ws As Worksheet) As Long
    Dim f As Range
    On Error Resume Next
    Set f = ws.Cells.Find(What:="*", After:=ws.Cells(1, 1), LookIn:=xlFormulas, LookAt:=xlPart, _
                          SearchOrder:=xlByColumns, SearchDirection:=xlPrevious, MatchCase:=False, _
                          MatchByte:=False, SearchFormat:=False)
    If Not f Is Nothing Then ExternalLastUsedColumn = f.Column
    On Error GoTo 0
End Function

Private Function PickWorkbookFile(ByVal dialogTitle As String, ByVal preferCommonData As Boolean) As String
    Dim fd As FileDialog
    Dim initialPath As String
    Set fd = Application.FileDialog(msoFileDialogFilePicker)
    initialPath = ThisWorkbook.Path
    If preferCommonData And Len(initialPath) > 0 Then initialPath = initialPath & "\00_���ʃf�[�^.xlsx"
    With fd
        .Title = dialogTitle
        .AllowMultiSelect = False
        .Filters.Clear
        .Filters.Add "Excel�u�b�N", "*.xlsx;*.xlsm;*.xlsb;*.xls"
        If Len(initialPath) > 0 Then .InitialFileName = initialPath
        If .Show = -1 Then PickWorkbookFile = CStr(.SelectedItems(1))
    End With
End Function

Public Sub ImportCommonDataWorkbook()
    Dim filePath As String
    Dim sourceBook As Workbook, ws As Worksheet
    Dim previousSecurity As Long, securityChanged As Boolean
    Dim headerRow As Long, lastR As Long, lastC As Long, r As Long, c As Long, sourceDataRow As Long
    Dim bankCol As Long, branchCol As Long, personCol As Long, personIDCol As Long
    Dim relationshipCol As Long, typeCol As Long, tekiyoCol As Long
    Dim importedCount As Long, errorNumber As Long, errorDescription As String
    Dim bankSnapshot As Variant, branchSnapshot As Variant, personSnapshot As Variant
    Dim typeSnapshot As Variant, tekiyoSnapshot As Variant, checkSnapshot As Variant, idCounterSnapshot As Variant
    Dim commonData As Variant
    Dim bankRows As Long, branchRows As Long, personRows As Long, typeRows As Long, tekiyoRows As Long, checkRows As Long
    Dim candidateBatchStarted As Boolean, snapshotsTaken As Boolean, idCountersCaptured As Boolean
    Dim personValidationIndex As Object
    Dim restoreDetail As String

    If Not RequireToolReady() Then Exit Sub
    filePath = PickWorkbookFile("00_���ʃf�[�^.xlsx ��I�����Ă�������", True)
    If Len(filePath) = 0 Then Exit Sub
    If Len(ThisWorkbook.FullName) > 0 Then
        If StrComp(filePath, ThisWorkbook.FullName, vbTextCompare) = 0 Then
            MsgBox "��ƒ��̃c�[�����g�͋��ʃf�[�^�Ɏw��ł��܂���B", vbExclamation
            Exit Sub
        End If
    End If
    On Error GoTo EH
    AppBegin "���ʃf�[�^��ǂݍ���ł��܂�..."
    If Not RequireInternalStoresSafeForWrite() Then
        AppEnd
        Exit Sub
    End If
    previousSecurity = Application.AutomationSecurity
    Application.AutomationSecurity = msoAutomationSecurityForceDisable
    securityChanged = True
    Set sourceBook = Workbooks.Open(Filename:=filePath, UpdateLinks:=0, ReadOnly:=True, _
                                    AddToMru:=False, IgnoreReadOnlyRecommended:=True, Notify:=False)
    If sourceBook.Worksheets.Count > MAX_SOURCE_SHEETS Then
        Err.Raise vbObjectError + 6201, "ImportCommonDataWorkbook", _
                  "���ʃf�[�^�̃V�[�g��������i" & CStr(MAX_SOURCE_SHEETS) & "���j�𒴂��Ă��܂��B"
    End If
    ValidateCommonWorkbookSize sourceBook

    SnapshotSheetBlock SH_BANK_CAND, 4, bankSnapshot, bankRows
    SnapshotSheetBlock SH_BRANCH_CAND, 4, branchSnapshot, branchRows
    SnapshotSheetBlock SH_PERSON_CAND, 4, personSnapshot, personRows
    'AddCandidateValue�͋敪��D��ɂ��L�^���邽�߁A�ȖځE�E�v��A:D��ޔ�����B
    SnapshotSheetBlock SH_ACCOUNT_TYPE, 4, typeSnapshot, typeRows
    SnapshotSheetBlock SH_TEKIYO, 4, tekiyoSnapshot, tekiyoRows
    '�捞��Z���t�`�F�b�N�͉ߋ��̃Z���t�`�F�b�N�s�𐮗����邽�߁A���s���ɗ����܂ŕς��Ȃ��悤�ޔ�����B
    SnapshotSheetBlock SH_CHECK, 4, checkSnapshot, checkRows
    snapshotsTaken = True
    idCounterSnapshot = CaptureInternalIdCounters()
    idCountersCaptured = True

    BeginCandidateBatchUpdate
    candidateBatchStarted = True
    For Each ws In sourceBook.Worksheets
        lastR = ExternalLastUsedRow(ws)
        lastC = ExternalLastUsedColumn(ws)
        If lastR > MAX_EXTERNAL_DATA_ROWS + 1 Then
            Err.Raise vbObjectError + 6202, "ImportCommonDataWorkbook", _
                      "���ʃf�[�^�u" & ws.Name & "�v�̎g�p�s������𒴂��Ă��܂��B"
        End If
        If lastC > MAX_EXTERNAL_COLUMNS Then
            Err.Raise vbObjectError + 6203, "ImportCommonDataWorkbook", _
                      "���ʃf�[�^�u" & ws.Name & "�v�̎g�p�񂪏���𒴂��Ă��܂��B"
        End If
        headerRow = FindCommonHeaderRow(ws, lastR, lastC)
        If headerRow > 0 Then
            ValidateCommonHeaderUniqueness ws, headerRow, lastC
            bankCol = FindWorksheetHeaderColumn(ws, headerRow, 1, lastC)
            branchCol = FindWorksheetHeaderColumn(ws, headerRow, 2, lastC)
            personCol = FindWorksheetHeaderColumn(ws, headerRow, 3, lastC)
            typeCol = FindWorksheetHeaderColumn(ws, headerRow, 4, lastC)
            tekiyoCol = FindWorksheetHeaderColumn(ws, headerRow, 12, lastC)
            personIDCol = FindWorksheetHeaderColumn(ws, headerRow, 14, lastC)
            relationshipCol = FindWorksheetHeaderColumn(ws, headerRow, 15, lastC)
            If lastR > headerRow Then _
                commonData = ws.Range(ws.Cells(headerRow + 1, 1), ws.Cells(lastR, lastC)).Value2
            For sourceDataRow = 1 To lastR - headerRow
                r = headerRow + sourceDataRow
                '�񂪑��݂��Ȃ�����Cells(r, 0)�֐G��Ȃ��BVBA��And�͒Z���]������Ȃ����߁A
                '�e��̗L���ƒl�L����ʁX��If�Ŋm�F����B
                EnsureCommonBulkCellNotError commonData, sourceDataRow, bankCol, ws, r, "��s��"
                EnsureCommonBulkCellNotError commonData, sourceDataRow, branchCol, ws, r, "�x�X��"
                EnsureCommonBulkCellNotError commonData, sourceDataRow, personCol, ws, r, "����"
                EnsureCommonBulkCellNotError commonData, sourceDataRow, personIDCol, ws, r, "�l��ID"
                EnsureCommonBulkCellNotError commonData, sourceDataRow, relationshipCol, ws, r, "����"
                EnsureCommonBulkCellNotError commonData, sourceDataRow, typeCol, ws, r, "�Ȗ�"
                EnsureCommonBulkCellNotError commonData, sourceDataRow, tekiyoCol, ws, r, "�E�v"
                If bankCol > 0 Then
                    If HasText(BulkArrayValue(commonData, sourceDataRow, bankCol)) Then
                        AddBankCandidate CellText(BulkArrayValue(commonData, sourceDataRow, bankCol)), CAND_SOURCE_COMMON
                        importedCount = importedCount + 1
                    End If
                End If
                If branchCol > 0 Then
                    If HasText(BulkArrayValue(commonData, sourceDataRow, branchCol)) Then
                        AddBranchCandidate CellText(BulkArrayValue(commonData, sourceDataRow, branchCol)), CAND_SOURCE_COMMON
                        importedCount = importedCount + 1
                    End If
                End If
                If typeCol > 0 Then
                    If HasText(BulkArrayValue(commonData, sourceDataRow, typeCol)) Then
                        AddAccountTypeCandidate CellText(BulkArrayValue(commonData, sourceDataRow, typeCol))
                        importedCount = importedCount + 1
                    End If
                End If
                If tekiyoCol > 0 Then
                    If HasText(BulkArrayValue(commonData, sourceDataRow, tekiyoCol)) Then
                        AddTekiyoCandidate CellText(BulkArrayValue(commonData, sourceDataRow, tekiyoCol))
                        importedCount = importedCount + 1
                    End If
                End If
                If personCol > 0 Then
                    If HasText(BulkArrayValue(commonData, sourceDataRow, personCol)) Then
                        AddPersonCandidateWithID CellText(BulkArrayValue(commonData, sourceDataRow, personCol)), _
                                                 CommonBulkIdentifierAtOrBlank(commonData, sourceDataRow, _
                                                                               ws, r, personIDCol, "�l��ID"), _
                                                 CommonBulkText(commonData, sourceDataRow, relationshipCol), CAND_SOURCE_COMMON
                        importedCount = importedCount + 1
                    End If
                End If
            Next sourceDataRow
        Else
            ImportCommonSheetByName ws, importedCount
        End If
    Next ws
    EndCandidateBatchUpdate
    candidateBatchStarted = False
    ReconcileInternalIdCounters
    Set personValidationIndex = NewTextDictionary()
    LoadExistingPersonIdIndex personValidationIndex
    '���ʌ��̎捞��́A�ύX�������E�̔ԏ�Ԃ��������؂���B���X�V�̒��[��
    '���͕\���܂őS��������ƁA�������捞�𖳊֌W�ȕ\����ԂŊ����߂��Ă��܂��B
    If Not RequireInternalStoresSafeForWrite() Then _
        Err.Raise vbObjectError + 2206, "ImportCommonDataWorkbook", _
                  "�捞��̓����f�[�^�m�F�Ɏ��s���܂����B"
    ValidateCaseCandidateResetSources
    ValidateInitializationPreservedSettings

    sourceBook.Close SaveChanges:=False
    Set sourceBook = Nothing
    Application.AutomationSecurity = previousSecurity
    securityChanged = False
    ApplyInputSettings False, True
    AppEnd
    EnableInputKeys
    SetInputStatus "���ʃf�[�^�����֎�荞�݂܂����B"
    MsgBox "���ʃf�[�^���������荞�݂܂����B" & vbCrLf & _
           "�Ǎ���⍀�ڐ��i�d�����܂ށj: " & importedCount, vbInformation
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    On Error Resume Next
    If candidateBatchStarted Then
        EndCandidateBatchUpdate
        candidateBatchStarted = False
    End If
    If snapshotsTaken Then
        Err.Clear
        RestoreCommonCandidateSnapshots bankSnapshot, bankRows, branchSnapshot, branchRows, _
                                        personSnapshot, personRows, typeSnapshot, typeRows, _
                                        tekiyoSnapshot, tekiyoRows
        If Err.Number <> 0 Then
            restoreDetail = "���̕����G���[: " & Err.Description
        End If
        Err.Clear
        If idCountersCaptured Then
            RestoreInternalIdCounters idCounterSnapshot
            If Err.Number <> 0 Then
                If Len(restoreDetail) > 0 Then restoreDetail = restoreDetail & " / "
                restoreDetail = restoreDetail & "ID�̔ԏ�Ԃ̕����G���[: " & Err.Description
            End If
        End If
        Err.Clear
        RestoreSheetBlock SH_CHECK, 4, checkSnapshot, checkRows
        If Err.Number <> 0 Then
            If Len(restoreDetail) > 0 Then restoreDetail = restoreDetail & " / "
            restoreDetail = restoreDetail & "�`�F�b�N�����̕����G���[: " & Err.Description
        End If
        Err.Clear
        EndCandidateBatchUpdate
        If Err.Number <> 0 Then
            If Len(restoreDetail) > 0 Then restoreDetail = restoreDetail & " / "
            restoreDetail = restoreDetail & "���ꗗ���̍X�V�G���[: " & Err.Description
        End If
    End If
    If Not sourceBook Is Nothing Then sourceBook.Close SaveChanges:=False
    If securityChanged Then Application.AutomationSecurity = previousSecurity
    On Error GoTo 0
    AppForceRestore
    EnableInputKeys
    If Len(restoreDetail) > 0 Then AddCheck "�G���[", "���ʃf�[�^�捞���[���o�b�N", restoreDetail
    MsgBox OperationFailureHeading(errorNumber, "���ʃf�[�^�̎捞���ɃG���[���������܂����B") & vbCrLf & _
           OperationFailureDetail(errorNumber, errorDescription) & _
           IIf(Len(restoreDetail) > 0, vbCrLf & "�����m�F: " & restoreDetail, vbCrLf & "�捞�O�̌��֕������܂����B"), OperationFailureIcon(errorNumber, vbExclamation)
End Sub

Private Sub ValidateCommonWorkbookSize(ByVal sourceBook As Workbook)
    Dim ws As Worksheet, lastR As Long, lastC As Long
    Dim totalRows As Double
    If sourceBook Is Nothing Then Exit Sub
    For Each ws In sourceBook.Worksheets
        lastR = ExternalLastUsedRow(ws)
        lastC = ExternalLastUsedColumn(ws)
        If lastR > MAX_EXTERNAL_DATA_ROWS + 1 Then
            Err.Raise vbObjectError + 8021, "ValidateCommonWorkbookSize", _
                      "���ʃf�[�^�u" & ws.Name & "�v�̎g�p�s������𒴂��Ă��܂��B"
        End If
        If lastC > MAX_EXTERNAL_COLUMNS Then
            Err.Raise vbObjectError + 8022, "ValidateCommonWorkbookSize", _
                      "���ʃf�[�^�u" & ws.Name & "�v�̎g�p�񂪏���𒴂��Ă��܂��B"
        End If
        If lastR > 1 Then totalRows = totalRows + CDbl(lastR - 1)
        If totalRows > MAX_COMMON_TOTAL_ROWS Then
            Err.Raise vbObjectError + 6204, "ValidateCommonWorkbookSize", _
                      "���ʃf�[�^�̍��v�s��������i" & Format$(MAX_COMMON_TOTAL_ROWS, "#,##0") & _
                      "�s�j�𒴂��Ă��܂��B�t�@�C���𕪊����Ă��������B"
        End If
    Next ws
End Sub

Private Sub SnapshotSheetBlock(ByVal sheetName As String, ByVal lastCol As Long, _
                               ByRef snapshot As Variant, ByRef snapshotRows As Long)
    Dim ws As Worksheet
    Set ws = GetSheet(sheetName)
    snapshotRows = LastDataRowInColumns(ws, 1, lastCol)
    If snapshotRows < 1 Then snapshotRows = 1
    snapshot = ws.Range(ws.Cells(1, 1), ws.Cells(snapshotRows, lastCol)).Value
End Sub

Private Sub RestoreSheetBlock(ByVal sheetName As String, ByVal lastCol As Long, _
                              ByRef snapshot As Variant, ByVal snapshotRows As Long)
    Dim ws As Worksheet, clearRows As Long
    Set ws = GetSheet(sheetName)
    clearRows = Application.Max(snapshotRows, LastDataRowInColumns(ws, 1, lastCol), 1)
    ws.Range(ws.Cells(1, 1), ws.Cells(clearRows, lastCol)).ClearContents
    If snapshotRows > 0 Then
        ws.Range(ws.Cells(1, 1), ws.Cells(snapshotRows, lastCol)).Value = snapshot
    End If
End Sub

Private Sub RestoreCommonCandidateSnapshots(ByRef bankSnapshot As Variant, ByVal bankRows As Long, _
                                            ByRef branchSnapshot As Variant, ByVal branchRows As Long, _
                                            ByRef personSnapshot As Variant, ByVal personRows As Long, _
                                            ByRef typeSnapshot As Variant, ByVal typeRows As Long, _
                                            ByRef tekiyoSnapshot As Variant, ByVal tekiyoRows As Long)
    Dim restoreProblems As String
    On Error Resume Next
    Err.Clear
    RestoreSheetBlock SH_BANK_CAND, 4, bankSnapshot, bankRows
    If Err.Number <> 0 Then AppendExternalDetail restoreProblems, "��s���: " & Err.Description
    Err.Clear
    RestoreSheetBlock SH_BRANCH_CAND, 4, branchSnapshot, branchRows
    If Err.Number <> 0 Then AppendExternalDetail restoreProblems, "�x�X���: " & Err.Description
    Err.Clear
    RestoreSheetBlock SH_PERSON_CAND, 4, personSnapshot, personRows
    If Err.Number <> 0 Then AppendExternalDetail restoreProblems, "�l�����: " & Err.Description
    Err.Clear
    RestoreSheetBlock SH_ACCOUNT_TYPE, 4, typeSnapshot, typeRows
    If Err.Number <> 0 Then AppendExternalDetail restoreProblems, "�Ȗڌ��: " & Err.Description
    Err.Clear
    RestoreSheetBlock SH_TEKIYO, 4, tekiyoSnapshot, tekiyoRows
    If Err.Number <> 0 Then AppendExternalDetail restoreProblems, "�E�v���: " & Err.Description
    Err.Clear
    InvalidateInternalIdCaches
    If Err.Number <> 0 Then AppendExternalDetail restoreProblems, "����ID����: " & Err.Description
    On Error GoTo 0
    If Len(restoreProblems) > 0 Then _
        Err.Raise vbObjectError + 6208, "RestoreCommonCandidateSnapshots", restoreProblems
End Sub

Private Function FindCommonHeaderRow(ByVal ws As Worksheet, ByVal lastR As Long, ByVal lastC As Long) As Long
    Dim r As Long, c As Long, score As Long, bestScore As Long
    For r = 1 To Application.Min(10, lastR)
        score = 0
        For c = 1 To lastC
            If HeaderKind(ws.Cells(r, c).Value) > 0 Then score = score + 1
        Next c
        If score > bestScore Then bestScore = score: FindCommonHeaderRow = r
    Next r
    If bestScore = 0 Then FindCommonHeaderRow = 0
End Function

Private Function FindWorksheetHeaderColumn(ByVal ws As Worksheet, ByVal headerRow As Long, ByVal kindNo As Long, ByVal lastC As Long) As Long
    Dim c As Long
    For c = 1 To lastC
        If HeaderKind(ws.Cells(headerRow, c).Value) = kindNo Then FindWorksheetHeaderColumn = c: Exit Function
    Next c
End Function

Private Sub ValidateCommonHeaderUniqueness(ByVal ws As Worksheet, ByVal headerRow As Long, ByVal lastC As Long)
    Dim counts(1 To 15) As Long
    Dim c As Long, kindNo As Long
    If ws Is Nothing Or headerRow < 1 Or lastC < 1 Then Exit Sub
    For c = 1 To lastC
        kindNo = HeaderKind(ws.Cells(headerRow, c).Value)
        Select Case kindNo
            Case 1, 2, 3, 4, 12, 14, 15
                counts(kindNo) = counts(kindNo) + 1
        End Select
    Next c
    For kindNo = 1 To 15
        If counts(kindNo) > 1 Then
            Err.Raise vbObjectError + 6205, "ValidateCommonHeaderUniqueness", _
                      "���ʃf�[�^�u" & ws.Name & "�v�ɓ��������̌��o������������܂�: " & ExternalHeaderName(kindNo)
        End If
    Next kindNo
End Sub

Private Sub EnsureCommonBulkCellNotError(ByRef sourceData As Variant, ByVal dataRow As Long, _
                                         ByVal colNo As Long, ByVal ws As Worksheet, _
                                         ByVal sourceRow As Long, ByVal labelText As String)
    If colNo <= 0 Then Exit Sub
    If IsError(BulkArrayValue(sourceData, dataRow, colNo)) Then
        Err.Raise vbObjectError + 6206, "EnsureCommonBulkCellNotError", _
                  "���ʃf�[�^��" & labelText & "��Excel�G���[�l�ł�: " & ws.Name & "!" & _
                  ws.Cells(sourceRow, colNo).Address(False, False)
    End If
End Sub

Private Function CommonBulkText(ByRef sourceData As Variant, ByVal dataRow As Long, _
                                ByVal colNo As Long) As String
    If colNo <= 0 Then Exit Function
    CommonBulkText = CellText(BulkArrayValue(sourceData, dataRow, colNo))
End Function

Private Function CommonBulkIdentifierAtOrBlank(ByRef sourceData As Variant, ByVal dataRow As Long, _
                                                ByVal ws As Worksheet, ByVal sourceRow As Long, _
                                                ByVal colNo As Long, ByVal labelText As String) As String
    '�C�ӗ񂪂Ȃ��ꍇ�͔z���0��ڂ�]�����Ȃ��B������ID�͈ꊇ�Ǎ��l�����ŕԂ��B
    If colNo <= 0 Then Exit Function
    CommonBulkIdentifierAtOrBlank = CommonIdentifierAtOrBlank( _
                                  ws, sourceRow, colNo, labelText, _
                                  BulkArrayValue(sourceData, dataRow, colNo))
End Function

Private Function CommonIdentifierAtOrBlank(ByVal ws As Worksheet, ByVal rowNo As Long, _
                                           ByVal colNo As Long, ByVal labelText As String, _
                                           Optional ByVal suppliedValue As Variant) As String
    Dim numericValue As Double
    Dim rawValue As Variant
    Dim sourceCell As Range
    If ws Is Nothing Or colNo <= 0 Then Exit Function
    If IsMissing(suppliedValue) Then
        Set sourceCell = ws.Cells(rowNo, colNo)
        rawValue = sourceCell.Value2
    Else
        rawValue = suppliedValue
    End If
    If IsNull(rawValue) Or IsEmpty(rawValue) Then Exit Function
    If VarType(rawValue) = vbString Then
        CommonIdentifierAtOrBlank = CellText(rawValue)
        Exit Function
    End If
    If IsError(rawValue) Then
        If sourceCell Is Nothing Then Set sourceCell = ws.Cells(rowNo, colNo)
        Err.Raise vbObjectError + 8023, "CommonIdentifierAtOrBlank", _
                  "���ʃf�[�^��" & labelText & "��Excel�G���[�l�ł�: " & ws.Name & "!" & _
                  sourceCell.Address(False, False)
    End If
    If VarType(rawValue) = vbBoolean Then
        If sourceCell Is Nothing Then Set sourceCell = ws.Cells(rowNo, colNo)
        Err.Raise vbObjectError + 6210, "CommonIdentifierAtOrBlank", _
                  "���ʃf�[�^��" & labelText & "��TRUE/FALSE�ł��B" & _
                  "���ʎq�͕�����܂���0�ȏ�̐����ŕۑ����Ă�������: " & _
                  ws.Name & "!" & sourceCell.Address(False, False)
    End If
    If VarType(rawValue) <> vbString And VarType(rawValue) <> vbBoolean And Not IsEmpty(rawValue) Then
        If IsNumeric(rawValue) Then
            On Error GoTo UnsafeIdentifier
            numericValue = CDbl(rawValue)
            If numericValue < 0 Or numericValue <> Fix(numericValue) Then GoTo InvalidNumericIdentifier
            If numericValue >= 1000000000000000# Then GoTo UnsafeIdentifier
            On Error GoTo 0
            If sourceCell Is Nothing Then Set sourceCell = ws.Cells(rowNo, colNo)
            CommonIdentifierAtOrBlank = ExternalIdentifierText(sourceCell, rawValue)
            Exit Function
        End If
    End If
    CommonIdentifierAtOrBlank = CellText(rawValue)
    Exit Function
UnsafeIdentifier:
    If sourceCell Is Nothing Then Set sourceCell = ws.Cells(rowNo, colNo)
    Err.Raise vbObjectError + 6207, "CommonIdentifierAtOrBlank", _
              "���ʃf�[�^��" & labelText & "��16���ȏ�̐��l�Z���ł��B" & _
              "���ۂ߂�h�����߁A�捞���ŕ�����Ƃ��ĕۑ����Ă�������: " & _
              ws.Name & "!" & sourceCell.Address(False, False)
InvalidNumericIdentifier:
    If sourceCell Is Nothing Then Set sourceCell = ws.Cells(rowNo, colNo)
    Err.Raise vbObjectError + 6209, "CommonIdentifierAtOrBlank", _
              "���ʃf�[�^��" & labelText & "�������܂��͏����̐��l�Z���ł��B" & _
              "���ʎq��0�ȏ�̐����܂��͕�����ŕۑ����Ă�������: " & _
              ws.Name & "!" & sourceCell.Address(False, False)
End Function

Private Sub ImportCommonSheetByName(ByVal ws As Worksheet, ByRef importedCount As Long)
    Dim sheetKey As String, lastR As Long, r As Long, sheetKind As Long, dataRow As Long, dataCols As Long
    Dim sourceData As Variant, candidateText As String
    sheetKey = NormalizeHeaderText(ws.Name)
    If InStr(sheetKey, "��s") > 0 Then
        sheetKind = 1
    ElseIf InStr(sheetKey, "�x�X") > 0 Then
        sheetKind = 2
    ElseIf InStr(sheetKey, "�l��") > 0 Or InStr(sheetKey, "����") > 0 Then
        sheetKind = 3
    ElseIf InStr(sheetKey, "�Ȗ�") > 0 Or InStr(sheetKey, "���") > 0 Then
        sheetKind = 4
    ElseIf InStr(sheetKey, "�E�v") > 0 Then
        sheetKind = 5
    Else
        Exit Sub
    End If
    lastR = ExternalLastUsedRow(ws)
    If lastR < 2 Then Exit Sub
    If sheetKind = 3 Then dataCols = 3 Else dataCols = 1
    sourceData = ws.Range(ws.Cells(2, 1), ws.Cells(lastR, dataCols)).Value2
    For dataRow = 1 To lastR - 1
        r = dataRow + 1
        EnsureCommonBulkCellNotError sourceData, dataRow, 1, ws, r, "���l"
        If sheetKind = 3 Then
            EnsureCommonBulkCellNotError sourceData, dataRow, 2, ws, r, "�l��ID"
            EnsureCommonBulkCellNotError sourceData, dataRow, 3, ws, r, "����"
        End If
        candidateText = CellText(BulkArrayValue(sourceData, dataRow, 1))
        If Len(candidateText) > 0 Then
            Select Case sheetKind
                Case 1
                    AddBankCandidate candidateText, CAND_SOURCE_COMMON
                Case 2
                    AddBranchCandidate candidateText, CAND_SOURCE_COMMON
                Case 3
                    AddPersonCandidateWithID candidateText, _
                                             CommonBulkIdentifierAtOrBlank(sourceData, dataRow, _
                                                                           ws, r, 2, "�l��ID"), _
                                             CommonBulkText(sourceData, dataRow, 3), CAND_SOURCE_COMMON
                Case 4
                    AddAccountTypeCandidate candidateText
                Case 5
                    AddTekiyoCandidate candidateText
            End Select
            importedCount = importedCount + 1
        End If
    Next dataRow
End Sub

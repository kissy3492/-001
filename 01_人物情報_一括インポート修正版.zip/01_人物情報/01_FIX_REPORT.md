# 01 人物情報 修正レポート

## 対象

- 対象ツール: 01 人物情報
- 対象ZIP: 01_人物情報_相続関係図カード修正版.zip
- 実機報告: 一括インポートができない。前回報告では、相続関係図の被相続人カード作成で「オブジェクトは、このプロパティまたはメソッドをサポートしていません」が出ていた。

## 方針

今回は 01 のみを修正しました。02〜04は触っていません。

一括インポート失敗は、実機で最初に通らなければ以後のVBEコンパイル・実操作・印刷確認へ進めないため、VBA本体より優先して取込スクリプトを作り直しました。

## 修正内容

### 1. 一括インポートVBSを再構成

従来の取込は `VBComponents.Import` に .bas ファイルを直接渡していました。今回、以下の方式へ変更しました。

- `ADODB.Stream` で .bas / .txt を `shift_jis` として読む
- `.bas` の `Attribute VB_Name = ...` からモジュール名を取得
- `Attribute` 行は除去
- `VBComponents.Add(vbext_ct_StdModule)` で標準モジュールを作成
- `CodeModule.InsertLines` でコードを書き込み
- `ThisWorkbook` は削除せず、既存コードだけ差し替え
- シートモジュールは削除しない
- 非ドキュメントVBAコンポーネントは取込前に削除
- 失敗時は `IMPORT_FAILED`、失敗段階、ErrNumber、Description、Source、対象ファイル、バックアップパスを表示

これにより、文字コード・直接Import・古い標準モジュール残存・失敗箇所不明のリスクを下げています。

### 2. BATの失敗時表示を強化

- ルート直下 `IMPORT_01_MODULES.bat` を更新
- `import/IMPORT_01_MODULES.bat` を更新
- 失敗時または `SetupWorkbook` 未完了時に画面が閉じないよう `pause` を追加
- BATはASCIIのみを維持

### 3. 相続関係図カードのTextFrame2依存をさらに弱めた

前回は `TextFrame2` 失敗時に旧 `TextFrame` へフォールバックする構造でしたが、今回はさらに保守的にしました。

- まず旧 `TextFrame` に本文・フォント・配置を設定
- その後、使える環境だけ `TextFrame2` の装飾を上乗せ
- `TextFrame2` が438になってもカード本体・氏名・本文が消えない構造へ変更
- `PolishRelationshipDiagramOutput` の不要な `TextFrame2` 直書きを削除
- 本文ラベル強調も旧 `TextFrame` を先に使い、`TextFrame2` は任意装飾扱いに変更

## 静的チェック結果

- CP932デコード: OK
- Option Explicit: OK
- Sub / Function / Property 開始終了: OK
- Public重複: なし
- OnAction / AddButton / OnKey 未定義候補: なし
- IIf残存: なし
- 成功通知MsgBox候補: なし
- IMPORT_ORDER不足・余剰: なし
- BAT ASCII: OK
- VBS UTF-16LE BOM: OK
- VBS本文ASCII: OK
- VBS `ADODB.Stream` 使用: OK
- VBS `shift_jis` 読込: OK
- VBS `CodeModule.InsertLines` 使用: OK
- ZIP再展開テスト: OK

## 注意

実機ExcelでのVBEコンパイル、Windows上での一括取込実行、実Excel操作、印刷プレビュー、実データ通し検証は未実施です。完成扱いではありません。

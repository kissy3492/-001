IMPORT_01_MODULES.bat imports all 01 modules into an existing macro-enabled workbook.

Recommended use:
1. Extract the ZIP first. Do not run from inside the ZIP preview.
2. Drag the target 01 .xlsm file onto IMPORT_01_MODULES.bat.
3. If a security message appears, enable Trust access to the VBA project object model.
4. After import, open VBE and run Compile VBAProject.

This import script:
- removes old non-document VBA components before import
- keeps ThisWorkbook and sheet modules
- rewrites ThisWorkbook code without deleting sheet modules
- reads .bas and .txt source files as shift_jis through ADODB.Stream
- writes modules through CodeModule.InsertLines
- creates a backup next to the target workbook before changes
- reports the exact failed stage when import does not finish cleanly

Return codes:
0 = imported and SetupWorkbook ran
1 = import failed before save
2 = modules imported, but SetupWorkbook did not complete

@echo off
setlocal
set SCRIPT_DIR=%~dp0
set IMPORT_VBS=%SCRIPT_DIR%IMPORT_01_MODULES.vbs
if not exist "%IMPORT_VBS%" (
  echo IMPORT_FAILED
  echo Stage: locate import script
  echo File was not found: %IMPORT_VBS%
  pause
  exit /b 1
)
%SystemRoot%\System32\cscript.exe //nologo "%IMPORT_VBS%" %*
set RC=%ERRORLEVEL%
if not "%RC%"=="0" (
  echo.
  echo Import did not finish cleanly. See the message above.
  pause
)
exit /b %RC%

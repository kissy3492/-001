# 01 人物情報 関数・取込監査レポート

## 今回の重点

一括インポートができないという実機報告を受け、取込処理を最優先で見直しました。

## 変更した主なファイル

- `IMPORT_01_MODULES.bat`
- `import/IMPORT_01_MODULES.bat`
- `import/IMPORT_01_MODULES.vbs`
- `import/README_IMPORT.txt`
- `modules/modOutputs.bas`

## 取込処理の変更点

- `.bas` を `VBComponents.Import` で直接読ませる方式をやめた
- `ADODB.Stream` で `shift_jis` として読み込む方式へ変更
- `Attribute` 行を除去して `CodeModule.InsertLines` で投入
- 非ドキュメントモジュール削除を段階表示つきに変更
- `ThisWorkbook` とシートモジュールは削除しない
- `SetupWorkbook` 未完了を `IMPORT_PARTIAL` として区別
- 失敗時に `Stage` / `ErrNumber` / `Description` / `Source` を表示

## 相続関係図カードの変更点

- `SafeApplyShapeText` を旧 `TextFrame` 優先へ変更
- `TextFrame2` は使える場合だけの任意装飾に変更
- カード本文ラベル強調も旧 `TextFrame` を先に適用
- カード生成経路の装飾失敗でカード作成全体を落としにくくした

## 未実施

- 実機ExcelでのVBEコンパイル
- Windows上での一括取込実行
- 実Excel操作
- 印刷プレビュー
- 実データ通し検証

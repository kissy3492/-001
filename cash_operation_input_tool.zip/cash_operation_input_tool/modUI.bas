Attribute VB_Name = "modUI"
Option Explicit

Private mButtonSeq As Long

Public Sub BuildOperationPanel(ByVal ws As Worksheet)
    Dim x As Double, y As Double, w As Double, h As Double
    Dim margin As Double, gap As Double, btnH As Double, primaryH As Double
    Dim colW2 As Double, colW3 As Double, left1 As Double, left2 As Double, left3 As Double
    Dim topY As Double, contentH As Double
    If ws Is Nothing Then Exit Sub
    mButtonSeq = 0
    On Error Resume Next
    DeleteToolShapes ws, False
    On Error GoTo 0

    '���������㕔�������g���B15�s�ڈȍ~�̓��͗��ɂ͊������Ȃ��B
    x = ws.Range("M2").Left
    y = ws.Range("M2").Top + 2
    w = ws.Range("M2:T13").Width
    h = ws.Range("M2:T13").Height - 4

    margin = 12
    gap = 7
    btnH = 24
    primaryH = 36
    colW2 = (w - margin * 2 - gap) / 2
    colW3 = (w - margin * 2 - gap * 2) / 3
    left1 = x + margin
    left2 = left1 + colW3 + gap
    left3 = left2 + colW3 + gap

    AddPanelBack ws, x, y, w, h

    contentH = primaryH + btnH * 5 + gap * 5
    topY = y + (h - contentH) / 2
    If topY < y + 12 Then topY = y + 12

    '�哱���B������u���͂����������m��v���u���[���܂Ƃ߂č쐬�v�B
    AddUIButton ws, left1, topY, colW2, primaryH, "���̌�����]�L", "TransferCurrentAccount", "primary"
    AddUIButton ws, left1 + colW2 + gap, topY, colW2, primaryH, "�ꊇ�쐬", "BuildAllOutputSheets", "hero"

    topY = topY + primaryH + gap
    AddUIButton ws, left1, topY, colW3, btnH, "�Ώۈꗗ", "BuildShopConversionTargetSheet", "accent"
    AddUIButton ws, left2, topY, colW3, btnH, "�戵�X���f", "ApplyShopConversionToCashOperation", "accent"
    AddUIButton ws, left3, topY, colW3, btnH, "���}�ԓ]�L", "TransferCurrentAccountNextBranch", "tool"

    topY = topY + btnH + gap
    AddUIButton ws, left1, topY, colW3, btnH, "��s�x�X�]�L", "TransferCurrentAccountKeepBankBranch", "tool"
    AddUIButton ws, left2, topY, colW3, btnH, "�}��+1", "IncrementAccountBranchNo", "tool"
    AddUIButton ws, left3, topY, colW3, btnH, "�\������", "AutoFitToolLayout", "tool"

    topY = topY + btnH + gap
    AddUIButton ws, left1, topY, colW3, btnH, "���͗��X�V", "ApplyInputSettings", "tool"
    AddUIButton ws, left2, topY, colW3, btnH, "�ݒ�", "ShowConfigSheet", "tool"
    AddUIButton ws, left3, topY, colW3, btnH, "���Ǘ�", "ShowCandidateSheets", "tool"

    topY = topY + btnH + gap
    AddUIButton ws, left1, topY, colW3, btnH, "���׃N���A", "ClearTransactionInput", "neutral"
    AddUIButton ws, left2, topY, colW3, btnH, "��s�x�X�c��", "ClearInputKeepBankBranch", "soft"
    AddUIButton ws, left3, topY, colW3, btnH, "���������c��", "ClearInputKeepPerson", "soft"

    topY = topY + btnH + gap
    AddUIButton ws, left1, topY, colW3, btnH, "�S�N���A", "ClearAllInputFields", "danger"
    AddUIButton ws, left2, topY, colW3, btnH, "������", "InitializeToolData", "danger"
    AddUIButton ws, left3, topY, colW3, btnH, "���͂�", "GoInputSheet", "soft"
End Sub

Private Sub AddPanelBack(ByVal ws As Worksheet, ByVal x As Double, ByVal y As Double, ByVal w As Double, ByVal h As Double)
    Dim shp As Shape
    Dim bar As Shape
    Dim accent As Shape
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    Set shp = ws.Shapes.AddShape(msoShapeRoundedRectangle, x, y, w, h)
    If Not shp Is Nothing Then
        With shp
            .Name = UI_PREFIX & "panel_back"
            .Fill.ForeColor.RGB = RGB(10, 16, 30)
            .Line.ForeColor.RGB = RGB(51, 65, 85)
            .Line.Weight = 1
            .Placement = xlMoveAndSize
            .Locked = False
            .ZOrder msoSendToBack
            .Shadow.Visible = msoTrue
            .Shadow.Transparency = 0.78
            .Shadow.Blur = 5
            .Shadow.OffsetX = 0
            .Shadow.OffsetY = 1
        End With
    End If

    Set bar = ws.Shapes.AddShape(msoShapeRoundedRectangle, x + 10, y + 8, w - 20, 4)
    If Not bar Is Nothing Then
        With bar
            .Name = UI_PREFIX & "panel_accent"
            .Fill.ForeColor.RGB = RGB(45, 212, 191)
            .Line.Visible = msoFalse
            .Placement = xlMoveAndSize
            .Locked = False
        End With
    End If

    Set accent = ws.Shapes.AddShape(msoShapeRectangle, x, y + 18, 4, h - 36)
    If Not accent Is Nothing Then
        With accent
            .Name = UI_PREFIX & "panel_edge"
            .Fill.ForeColor.RGB = RGB(20, 184, 166)
            .Line.Visible = msoFalse
            .Placement = xlMoveAndSize
            .Locked = False
        End With
    End If
    On Error GoTo 0
End Sub

Public Sub AddUIButton(ByVal ws As Worksheet, ByVal x As Double, ByVal y As Double, ByVal w As Double, ByVal h As Double, ByVal caption As String, ByVal macroName As String, ByVal styleName As String)
    Dim shp As Shape
    Dim btn As Object
    Dim fillColor As Long, lineColor As Long, fontColor As Long
    If ws Is Nothing Then Exit Sub
    GetButtonColors styleName, fillColor, lineColor, fontColor
    On Error Resume Next
    Set shp = ws.Shapes.AddShape(msoShapeRoundedRectangle, x, y, w, h)
    If Not shp Is Nothing Then
        mButtonSeq = mButtonSeq + 1
        With shp
            .Name = UI_PREFIX & "btn_" & CStr(mButtonSeq)
            .TextFrame.Characters.Text = caption
            .TextFrame.HorizontalAlignment = xlHAlignCenter
            .TextFrame.VerticalAlignment = xlVAlignCenter
            .TextFrame.MarginLeft = 2
            .TextFrame.MarginRight = 2
            .TextFrame.MarginTop = 0
            .TextFrame.MarginBottom = 0
            .TextFrame.Characters.Font.Name = "Yu Gothic UI"
            .TextFrame.Characters.Font.Size = IIf(h >= 30, 11, 9.2)
            .TextFrame.Characters.Font.Bold = True
            .TextFrame.Characters.Font.Color = fontColor
            .Fill.ForeColor.RGB = fillColor
            .Line.ForeColor.RGB = lineColor
            .Line.Weight = 0.85
            .Placement = xlMoveAndSize
            .Locked = False
            .OnAction = MacroRef(macroName)
            .AlternativeText = macroName
            .Shadow.Visible = msoTrue
            .Shadow.Transparency = 0.82
            .Shadow.Blur = 3
            .Shadow.OffsetX = 0
            .Shadow.OffsetY = 1
        End With
        Exit Sub
    End If
    Err.Clear
    Set btn = ws.Buttons.Add(x, y, w, h)
    If Not btn Is Nothing Then
        btn.Caption = caption
        btn.OnAction = MacroRef(macroName)
    End If
    On Error GoTo 0
End Sub

Private Sub GetButtonColors(ByVal styleName As String, ByRef fillColor As Long, ByRef lineColor As Long, ByRef fontColor As Long)
    fontColor = RGB(248, 250, 252)
    Select Case LCase$(styleName)
        Case "hero"
            fillColor = RGB(45, 212, 191)
            lineColor = RGB(153, 246, 228)
            fontColor = RGB(6, 78, 59)
        Case "primary"
            fillColor = RGB(59, 130, 246)
            lineColor = RGB(191, 219, 254)
            fontColor = RGB(248, 250, 252)
        Case "accent"
            fillColor = RGB(14, 165, 233)
            lineColor = RGB(125, 211, 252)
            fontColor = RGB(240, 249, 255)
        Case "danger"
            fillColor = RGB(153, 27, 27)
            lineColor = RGB(252, 165, 165)
            fontColor = RGB(255, 241, 242)
        Case "neutral"
            fillColor = RGB(51, 65, 85)
            lineColor = RGB(148, 163, 184)
            fontColor = RGB(248, 250, 252)
        Case "tool"
            fillColor = RGB(22, 31, 49)
            lineColor = RGB(71, 85, 105)
            fontColor = RGB(226, 232, 240)
        Case "soft"
            fillColor = RGB(30, 41, 59)
            lineColor = RGB(71, 85, 105)
            fontColor = RGB(203, 213, 225)
        Case Else
            fillColor = RGB(30, 41, 59)
            lineColor = RGB(100, 116, 139)
            fontColor = RGB(241, 245, 249)
    End Select
End Sub

Public Sub AddConfigButton(ByVal ws As Worksheet, ByVal cellAddress As String, ByVal caption As String, ByVal macroName As String)
    Dim a As Range
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    Set a = ws.Range(cellAddress)
    On Error GoTo 0
    If a Is Nothing Then Exit Sub
    AddUIButton ws, a.Left, a.Top, 150, 28, caption, macroName, "tool"
End Sub

Public Sub BuildInputHelpCards(ByVal ws As Worksheet)
    '����p�l���̉��ɒ����������͒u���Ȃ��B���͔͈͂̒��O�͗]���Ǝ����̋�؂�ɂ���B
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    ws.Range("M14:T14").UnMerge
    ws.Range("M14:T14").ClearContents
    ws.Range("M14:T14").Interior.Color = RGB(12, 18, 32)
    ws.Range("M14:T14").Borders.LineStyle = xlNone
    ws.Rows(14).RowHeight = 22
    On Error GoTo 0
End Sub

Public Sub RefreshButtonActions()
    'SaveAs��Ƀu�b�N�����ς���Ă��A�}�`�{�^���̎Q�Ɛ�����݂�ThisWorkbook�֒��蒼���B
    Dim ws As Worksheet
    Dim shp As Shape
    Dim macroName As String
    On Error Resume Next
    For Each ws In ThisWorkbook.Worksheets
        For Each shp In ws.Shapes
            If Left$(shp.Name, Len(UI_PREFIX & "btn_")) = UI_PREFIX & "btn_" Then
                macroName = shp.AlternativeText
                If Len(macroName) > 0 Then shp.OnAction = MacroRef(macroName)
            End If
        Next shp
    Next ws
    On Error GoTo 0
End Sub

Public Sub FormatHeader(ByVal rng As Range, Optional ByVal fillColor As Long = 0)
    If rng Is Nothing Then Exit Sub
    If fillColor = 0 Then fillColor = RGB(15, 23, 42)
    With rng
        .Font.Bold = True
        .Font.Color = RGB(226, 232, 240)
        .Interior.Color = fillColor
        .Borders.LineStyle = xlContinuous
        .Borders.Color = RGB(51, 65, 85)
        .VerticalAlignment = xlCenter
    End With
End Sub

Public Sub FormatOutputHeader(ByVal rng As Range)
    If rng Is Nothing Then Exit Sub
    With rng
        .Font.Bold = True
        .Font.Color = RGB(236, 253, 245)
        .Interior.Color = RGB(15, 23, 42)
        .HorizontalAlignment = xlCenter
        .VerticalAlignment = xlCenter
        .Borders.LineStyle = xlContinuous
        .Borders.Color = RGB(51, 65, 85)
    End With
End Sub

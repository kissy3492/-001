Attribute VB_Name = "modUI"
Option Explicit

Private mButtonSeq As Long

Public Sub BuildOperationPanel(ByVal ws As Worksheet)
    Dim x As Double, y As Double, w As Double, h As Double
    Dim margin As Double, gap As Double, btnH As Double, primaryH As Double
    Dim colW2 As Double, colW3 As Double, left1 As Double, left2 As Double, left3 As Double
    Dim topY As Double, contentH As Double
    If ws Is Nothing Then Exit Sub

    mButtonSeq = 0
    On Error Resume Next
    DeleteToolShapes ws, False
    On Error GoTo 0

    '15�s�ڈȍ~�̓��͗����ז����Ȃ��B����ŁA�������͓���Ȃ��B
    x = ws.Range("M2").Left
    y = ws.Range("M2").Top + 4
    w = ws.Range("M2:T13").Width
    h = ws.Range("M2:T13").Height - 8

    margin = 14
    gap = 7
    btnH = 24
    primaryH = 36
    colW2 = (w - margin * 2 - gap) / 2
    colW3 = (w - margin * 2 - gap * 2) / 3
    left1 = x + margin
    left2 = left1 + colW3 + gap
    left3 = left2 + colW3 + gap

    AddPanelBack ws, x, y, w, h

    contentH = primaryH + btnH * 5 + gap * 5
    topY = y + (h - contentH) / 2
    If topY < y + 12 Then topY = y + 12

    AddUIButton ws, left1, topY, colW2, primaryH, "���̌�����]�L", "TransferCurrentAccount", "primary"
    AddUIButton ws, left1 + colW2 + gap, topY, colW2, primaryH, "�ꊇ�쐬", "BuildAllOutputSheets", "hero"

    topY = topY + primaryH + gap
    AddUIButton ws, left1, topY, colW3, btnH, "�Ώۈꗗ", "BuildShopConversionTargetSheet", "accent"
    AddUIButton ws, left2, topY, colW3, btnH, "�戵�X���f", "ApplyShopConversionToCashOperation", "accent"
    AddUIButton ws, left3, topY, colW3, btnH, "���}�ԓ]�L", "TransferCurrentAccountNextBranch", "tool"

    topY = topY + btnH + gap
    AddUIButton ws, left1, topY, colW3, btnH, "��s�x�X�]�L", "TransferCurrentAccountKeepBankBranch", "tool"
    AddUIButton ws, left2, topY, colW3, btnH, "�}��+1", "IncrementAccountBranchNo", "tool"
    AddUIButton ws, left3, topY, colW3, btnH, "�\������", "AutoFitToolLayout", "tool"

    topY = topY + btnH + gap
    AddUIButton ws, left1, topY, colW3, btnH, "���͗��X�V", "ApplyInputSettings", "tool"
    AddUIButton ws, left2, topY, colW3, btnH, "�ݒ�", "ShowConfigSheet", "tool"
    AddUIButton ws, left3, topY, colW3, btnH, "���Ǘ�", "ShowCandidateSheets", "tool"

    topY = topY + btnH + gap
    AddUIButton ws, left1, topY, colW3, btnH, "���׃N���A", "ClearTransactionInput", "neutral"
    AddUIButton ws, left2, topY, colW3, btnH, "��s�x�X�c��", "ClearInputKeepBankBranch", "soft"
    AddUIButton ws, left3, topY, colW3, btnH, "���������c��", "ClearInputKeepPerson", "soft"

    topY = topY + btnH + gap
    AddUIButton ws, left1, topY, colW3, btnH, "�S�N���A", "ClearAllInputFields", "danger"
    AddUIButton ws, left2, topY, colW3, btnH, "������", "InitializeToolData", "danger"
    AddUIButton ws, left3, topY, colW3, btnH, "Tab����", "RestoreInputNavigation", "soft"
End Sub

Private Sub AddPanelBack(ByVal ws As Worksheet, ByVal x As Double, ByVal y As Double, ByVal w As Double, ByVal h As Double)
    Dim shp As Shape
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    Set shp = ws.Shapes.AddShape(msoShapeRoundedRectangle, x, y, w, h)
    If Not shp Is Nothing Then
        With shp
            .Name = UI_PREFIX & "panel_back"
            .Fill.ForeColor.RGB = RGB(255, 255, 255)
            .Line.ForeColor.RGB = RGB(203, 213, 225)
            .Line.Weight = 1
            .Placement = xlMoveAndSize
            .Locked = False
            .ZOrder msoSendToBack
            .Shadow.Visible = msoTrue
            .Shadow.Transparency = 0.88
            .Shadow.Blur = 7
            .Shadow.OffsetX = 0
            .Shadow.OffsetY = 2
        End With
    End If
    On Error GoTo 0
End Sub

Public Sub AddUIButton(ByVal ws As Worksheet, ByVal x As Double, ByVal y As Double, ByVal w As Double, ByVal h As Double, ByVal caption As String, ByVal macroName As String, ByVal styleName As String)
    Dim shp As Shape
    Dim btn As Object
    Dim fillColor As Long, lineColor As Long, fontColor As Long
    If ws Is Nothing Then Exit Sub
    GetButtonColors styleName, fillColor, lineColor, fontColor
    On Error Resume Next
    Set shp = ws.Shapes.AddShape(msoShapeRoundedRectangle, x, y, w, h)
    If Not shp Is Nothing Then
        mButtonSeq = mButtonSeq + 1
        With shp
            .Name = UI_PREFIX & "btn_" & CStr(mButtonSeq)
            .TextFrame.Characters.Text = caption
            .TextFrame.HorizontalAlignment = xlHAlignCenter
            .TextFrame.VerticalAlignment = xlVAlignCenter
            .TextFrame.MarginLeft = 2
            .TextFrame.MarginRight = 2
            .TextFrame.MarginTop = 0
            .TextFrame.MarginBottom = 0
            .TextFrame.Characters.Font.Name = "Yu Gothic UI"
            .TextFrame.Characters.Font.Size = IIf(h >= 30, 10.5, 9)
            .TextFrame.Characters.Font.Bold = True
            .TextFrame.Characters.Font.Color = fontColor
            .Fill.ForeColor.RGB = fillColor
            .Line.ForeColor.RGB = lineColor
            .Line.Weight = 0.8
            .Placement = xlMoveAndSize
            .Locked = False
            .OnAction = MacroRef(macroName)
            .AlternativeText = macroName
            .Shadow.Visible = msoFalse
        End With
        Exit Sub
    End If
    Err.Clear
    Set btn = ws.Buttons.Add(x, y, w, h)
    If Not btn Is Nothing Then
        btn.Caption = caption
        btn.OnAction = MacroRef(macroName)
    End If
    On Error GoTo 0
End Sub

Private Sub GetButtonColors(ByVal styleName As String, ByRef fillColor As Long, ByRef lineColor As Long, ByRef fontColor As Long)
    fontColor = RGB(15, 23, 42)
    Select Case LCase$(styleName)
        Case "hero"
            fillColor = RGB(20, 184, 166)
            lineColor = RGB(13, 148, 136)
            fontColor = RGB(255, 255, 255)
        Case "primary"
            fillColor = RGB(37, 99, 235)
            lineColor = RGB(29, 78, 216)
            fontColor = RGB(255, 255, 255)
        Case "accent"
            fillColor = RGB(14, 165, 233)
            lineColor = RGB(2, 132, 199)
            fontColor = RGB(255, 255, 255)
        Case "danger"
            fillColor = RGB(239, 68, 68)
            lineColor = RGB(220, 38, 38)
            fontColor = RGB(255, 255, 255)
        Case "neutral"
            fillColor = RGB(241, 245, 249)
            lineColor = RGB(203, 213, 225)
            fontColor = RGB(15, 23, 42)
        Case "tool"
            fillColor = RGB(255, 255, 255)
            lineColor = RGB(203, 213, 225)
            fontColor = RGB(30, 64, 175)
        Case "soft"
            fillColor = RGB(248, 250, 252)
            lineColor = RGB(226, 232, 240)
            fontColor = RGB(51, 65, 85)
        Case Else
            fillColor = RGB(248, 250, 252)
            lineColor = RGB(203, 213, 225)
            fontColor = RGB(15, 23, 42)
    End Select
End Sub

Public Sub AddConfigButton(ByVal ws As Worksheet, ByVal cellAddress As String, ByVal caption As String, ByVal macroName As String)
    Dim a As Range
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    Set a = ws.Range(cellAddress)
    On Error GoTo 0
    If a Is Nothing Then Exit Sub
    AddUIButton ws, a.Left, a.Top, 150, 28, caption, macroName, "tool"
End Sub

Public Sub BuildInputHelpCards(ByVal ws As Worksheet)
    '�E�チ�j���[�̉��ɑ����Ⓑ����u���Ȃ��B���͗��֎��R�Ɏ�����������]���ɂ���B
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    ws.Range("M14:T14").UnMerge
    ws.Range("M14:T14").ClearContents
    ws.Range("M14:T14").Interior.Color = RGB(248, 250, 252)
    ws.Range("M14:T14").Borders.LineStyle = xlNone
    ws.Rows(14).RowHeight = 22
    On Error GoTo 0
End Sub

Public Sub RefreshButtonActions()
    'SaveAs��Ƀu�b�N�����ς���Ă��A�}�`�{�^���̎Q�Ɛ�����݂�ThisWorkbook�֒��蒼���B
    Dim ws As Worksheet
    Dim shp As Shape
    Dim macroName As String
    On Error Resume Next
    For Each ws In ThisWorkbook.Worksheets
        For Each shp In ws.Shapes
            If Left$(shp.Name, Len(UI_PREFIX & "btn_")) = UI_PREFIX & "btn_" Then
                macroName = shp.AlternativeText
                If Len(macroName) > 0 Then shp.OnAction = MacroRef(macroName)
            End If
        Next shp
    Next ws
    On Error GoTo 0
End Sub

Public Sub FormatHeader(ByVal rng As Range, Optional ByVal fillColor As Long = 0)
    If rng Is Nothing Then Exit Sub
    If fillColor = 0 Then fillColor = RGB(226, 232, 240)
    With rng
        .Font.Bold = True
        .Font.Color = RGB(15, 23, 42)
        .Interior.Color = fillColor
        .Borders.LineStyle = xlContinuous
        .Borders.Color = RGB(203, 213, 225)
        .VerticalAlignment = xlCenter
    End With
End Sub

Public Sub FormatOutputHeader(ByVal rng As Range)
    If rng Is Nothing Then Exit Sub
    With rng
        .Font.Bold = True
        .Font.Color = RGB(255, 255, 255)
        .Interior.Color = RGB(30, 64, 175)
        .HorizontalAlignment = xlCenter
        .VerticalAlignment = xlCenter
        .Borders.LineStyle = xlContinuous
        .Borders.Color = RGB(147, 197, 253)
    End With
End Sub

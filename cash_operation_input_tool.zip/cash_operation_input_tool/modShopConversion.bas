Attribute VB_Name = "modShopConversion"
Option Explicit

Public Sub BuildShopConversionTargetSheet()
    If Not RequireToolReady() Then Exit Sub
    On Error GoTo EH
    AppBegin "�戵�X�ϊ��Ώۂ𐮗���..."
    If Not SheetExists(SH_OUTPUT_TX) Then
        BuildCashOperationSheetCore False
    ElseIf LastRow(GetSheet(SH_OUTPUT_TX), 1) < 2 Then
        BuildCashOperationSheetCore False
    End If
    BuildShopConversionTargetSheetCore True
    AppEnd
    MsgBox "�戵�X�ϊ��Ώۂ��쐬���܂����B" & vbCrLf & _
           "�ϊ���戵�X���ɒ������ʂ���͂��A���̓V�[�g�́w�戵�X���f�x�������Ă��������B", vbInformation
    Exit Sub
EH:
    AppEnd
    MsgBox "�戵�X�ϊ��Ώۂ̍쐬���ɃG���[���������܂����B" & vbCrLf & "Err " & Err.Number & ": " & Err.Description, vbExclamation
End Sub

Public Sub BuildShopConversionTargetSheetCore(Optional ByVal activateAfter As Boolean = False)
    Dim wsOut As Worksheet, wsTarget As Worksheet
    Dim lastR As Long, r As Long, targetR As Long, nextNo As Long, oldLastR As Long
    Dim bankName As String, branchName As String, shopText As String, codeText As String, kindText As String
    Dim oldData As Variant, preservedResult As String, preservedStatus As String, preservedMemo As String
    If Not SheetExists(SH_OUTPUT_TX) Then Exit Sub
    Set wsOut = GetSheet(SH_OUTPUT_TX)
    Set wsTarget = GetOrCreateSheet(SH_SHOP_TARGET, False)
    oldLastR = LastRow(wsTarget, SHOP_TGT_COL_NO)
    If oldLastR >= 2 Then oldData = wsTarget.Range("A1:K" & oldLastR).Value
    SetupShopConversionTargetSheet wsTarget
    lastR = LastRow(wsOut, OUT_COL_BANK)
    nextNo = 1
    For r = 2 To lastR
        If IsCashOperationTransactionRow(wsOut, r) Then
            shopText = CellText(wsOut.Cells(r, OUT_COL_SHOP).Value)
            If IsCodeLikeShop(shopText) Then
                bankName = CellText(wsOut.Cells(r, OUT_COL_BANK).Value)
                branchName = CellText(wsOut.Cells(r, OUT_COL_BRANCH).Value)
                codeText = NormalizeShopCodeText(shopText)
                kindText = DetectShopCodeKind(bankName, codeText, CellText(wsOut.Cells(r, OUT_COL_TEKIYO).Value), CellText(wsOut.Cells(r, OUT_COL_MACHINE).Value))
                targetR = FindShopTargetRow(wsTarget, bankName, codeText)
                If targetR = 0 Then
                    targetR = LastRow(wsTarget, SHOP_TGT_COL_NO) + 1
                    If targetR < 2 Then targetR = 2
                    wsTarget.Cells(targetR, SHOP_TGT_COL_NO).Value = nextNo
                    wsTarget.Cells(targetR, SHOP_TGT_COL_BANK).Value = bankName
                    wsTarget.Cells(targetR, SHOP_TGT_COL_BRANCH).Value = branchName
                    wsTarget.Cells(targetR, SHOP_TGT_COL_CODE).Value = codeText
                    wsTarget.Cells(targetR, SHOP_TGT_COL_KIND).Value = kindText
                    wsTarget.Cells(targetR, SHOP_TGT_COL_COUNT).Value = 1
                    wsTarget.Cells(targetR, SHOP_TGT_COL_ROWS).Value = CStr(r)
                    PreserveShopTargetValues oldData, bankName, codeText, preservedResult, preservedStatus, preservedMemo
                    wsTarget.Cells(targetR, SHOP_TGT_COL_RESULT).Value = preservedResult
                    If Len(preservedStatus) > 0 Then
                        wsTarget.Cells(targetR, SHOP_TGT_COL_STATUS).Value = preservedStatus
                    ElseIf Len(preservedResult) > 0 Then
                        wsTarget.Cells(targetR, SHOP_TGT_COL_STATUS).Value = "���͍�"
                    Else
                        wsTarget.Cells(targetR, SHOP_TGT_COL_STATUS).Value = "������"
                    End If
                    wsTarget.Cells(targetR, SHOP_TGT_COL_MEMO).Value = preservedMemo
                    wsTarget.Cells(targetR, SHOP_TGT_COL_CREATED).Value = Now
                    nextNo = nextNo + 1
                Else
                    wsTarget.Cells(targetR, SHOP_TGT_COL_BRANCH).Value = AppendUniqueText(CellText(wsTarget.Cells(targetR, SHOP_TGT_COL_BRANCH).Value), branchName)
                    wsTarget.Cells(targetR, SHOP_TGT_COL_COUNT).Value = CLng(Val(wsTarget.Cells(targetR, SHOP_TGT_COL_COUNT).Value)) + 1
                    wsTarget.Cells(targetR, SHOP_TGT_COL_ROWS).Value = AppendRowNumber(CellText(wsTarget.Cells(targetR, SHOP_TGT_COL_ROWS).Value), r)
                End If
            End If
        End If
    Next r
    FormatShopConversionTargetSheet wsTarget
    wsTarget.Visible = xlSheetVisible
    If activateAfter Then
        wsTarget.Activate
        wsTarget.Range("A1").Select
    End If
End Sub

Public Sub ApplyShopConversionToCashOperation()
    If Not RequireToolReady() Then Exit Sub
    On Error GoTo EH
    AppBegin "�戵�X�𔽉f��..."
    If Not SheetExists(SH_OUTPUT_TX) Then
        BuildCashOperationSheetCore False
    ElseIf LastRow(GetSheet(SH_OUTPUT_TX), 1) < 2 Then
        BuildCashOperationSheetCore False
    End If
    If Not SheetExists(SH_SHOP_TARGET) Then
        BuildShopConversionTargetSheetCore False
    ElseIf LastRow(GetSheet(SH_SHOP_TARGET), SHOP_TGT_COL_NO) < 2 Then
        BuildShopConversionTargetSheetCore False
    End If
    ApplyShopConversionCore True
    AppEnd
    Exit Sub
EH:
    AppEnd
    MsgBox "�戵�X���f���ɃG���[���������܂����B" & vbCrLf & "Err " & Err.Number & ": " & Err.Description, vbExclamation
End Sub

Private Sub ApplyShopConversionCore(ByVal activateAfter As Boolean)
    Dim wsSrc As Worksheet, wsTarget As Worksheet, wsDest As Worksheet
    Dim lastR As Long, r As Long
    Dim bankName As String, shopText As String, codeText As String, resultName As String
    Dim convertedCount As Long, remainedCount As Long
    Set wsSrc = GetSheet(SH_OUTPUT_TX)
    Set wsTarget = GetSheet(SH_SHOP_TARGET)
    Set wsDest = GetOrCreateSheet(SH_OUTPUT_TX_CONVERTED, True)
    lastR = LastRow(wsSrc, OUT_COL_BANK)
    If lastR < 1 Then lastR = 1
    wsSrc.Range("A1:M" & CStr(lastR)).Copy Destination:=wsDest.Range("A1")
    wsDest.Visible = xlSheetVisible
    lastR = LastRow(wsDest, OUT_COL_BANK)
    For r = 2 To lastR
        If IsCashOperationTransactionRow(wsDest, r) Then
            shopText = CellText(wsDest.Cells(r, OUT_COL_SHOP).Value)
            If IsCodeLikeShop(shopText) Then
                bankName = CellText(wsDest.Cells(r, OUT_COL_BANK).Value)
                codeText = NormalizeShopCodeText(shopText)
                resultName = LookupShopConversionName(wsTarget, bankName, codeText)
                If Len(resultName) > 0 Then
                    wsDest.Cells(r, OUT_COL_SHOP).Value = resultName
                    wsDest.Cells(r, OUT_COL_SHOP).Interior.Color = RGB(204, 251, 241)
                    convertedCount = convertedCount + 1
                Else
                    wsDest.Cells(r, OUT_COL_SHOP).Interior.Color = RGB(254, 240, 138)
                    remainedCount = remainedCount + 1
                End If
            End If
        End If
    Next r
    FormatCashOperationOutputLayout wsDest
    wsDest.Columns("E:E").NumberFormatLocal = "@"
    wsDest.Columns("J:K").NumberFormatLocal = "@"
    UpdateShopTargetStatuses wsTarget
    If activateAfter Then
        wsDest.Activate
        wsDest.Range("A1").Select
    End If
    MsgBox "�戵�X���f�ςݎ�������\���쐬���܂����B" & vbCrLf & _
           "���f�ς�: " & convertedCount & "��" & vbCrLf & _
           "�����́E�����f: " & remainedCount & "��", vbInformation
End Sub

Public Function FillBlankShopWithBranch(ByVal ws As Worksheet) As Long
    Dim lastR As Long, r As Long, branchName As String
    If ws Is Nothing Then Exit Function
    lastR = LastRow(ws, OUT_COL_BANK)
    For r = 2 To lastR
        If IsCashOperationTransactionRow(ws, r) Then
            If Len(CellText(ws.Cells(r, OUT_COL_SHOP).Value)) = 0 Then
                branchName = CellText(ws.Cells(r, OUT_COL_BRANCH).Value)
                If Len(branchName) > 0 Then
                    ws.Cells(r, OUT_COL_SHOP).Value = branchName
                    FillBlankShopWithBranch = FillBlankShopWithBranch + 1
                End If
            End If
        End If
    Next r
End Function

Public Sub SetupShopConversionTargetSheet(ByVal ws As Worksheet)
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    ws.Unprotect Password:=TOOL_PASSWORD
    ws.Cells.UnMerge
    ws.Cells.Clear
    ws.Cells.ClearFormats
    ws.Cells.Validation.Delete
    ws.AutoFilterMode = False
    On Error GoTo 0

    ws.Cells.Font.Name = "Yu Gothic UI"
    ws.Cells.Font.Size = 10
    ws.Cells.Interior.Color = RGB(241, 245, 249)
    ws.Cells.Font.Color = RGB(15, 23, 42)
    SetRowValues ws.Range("A1"), Array("No", "��s��", "�x�X��", "�戵�X�R�[�h", "�R�[�h���", "�Y������", "�Y���s�ԍ�", "�ϊ���戵�X", "�m�F��", "���l", "�쐬����")
    FormatOutputHeader ws.Range("A1:K1")
    ws.Range("A1:K1").Interior.Color = RGB(30, 64, 175)
    ws.Range("A1:K1").Font.Color = RGB(255, 255, 255)
    ws.Range("A1:K1").Borders.Color = RGB(147, 197, 253)
    ws.Columns("A:A").ColumnWidth = 6
    ws.Columns("B:C").ColumnWidth = 19
    ws.Columns("D:D").ColumnWidth = 17
    ws.Columns("E:E").ColumnWidth = 22
    ws.Columns("F:F").ColumnWidth = 10
    ws.Columns("G:G").ColumnWidth = 20
    ws.Columns("H:H").ColumnWidth = 30
    ws.Columns("I:I").ColumnWidth = 13
    ws.Columns("J:J").ColumnWidth = 30
    ws.Columns("K:K").ColumnWidth = 18
    ws.Columns("D:D").NumberFormatLocal = "@"
    ws.Columns("H:J").Interior.Color = RGB(255, 255, 255)
    ws.Columns("H:J").Font.Color = RGB(15, 23, 42)
    ws.Columns("K:K").NumberFormatLocal = "yyyy/m/d h:mm"
    ws.Rows(1).RowHeight = 27
    ws.Rows(1).Font.Bold = True
    ws.Range("H:H").Font.Bold = True
    On Error Resume Next
    ws.Range("I2:I1000").Validation.Delete
    ws.Range("I2:I1000").Validation.Add Type:=xlValidateList, AlertStyle:=xlValidAlertStop, Operator:=xlBetween, Formula1:="������,���͍�,�m�F�s�v,�ۗ�"
    ws.Range("I2:I1000").Validation.InCellDropdown = True
    ws.Range("I2:I1000").Validation.ShowError = False
    On Error GoTo 0
End Sub

Private Sub FormatShopConversionTargetSheet(ByVal ws As Worksheet)
    Dim lastR As Long, r As Long
    If ws Is Nothing Then Exit Sub
    lastR = LastRow(ws, SHOP_TGT_COL_NO)
    On Error Resume Next
    ws.AutoFilterMode = False
    On Error GoTo 0
    If lastR < 2 Then
        ws.Range("A2:K2").UnMerge
        ws.Range("A2").Value = "�ϊ��Ώۂ̎戵�X�R�[�h�͂���܂���B"
        ws.Range("A2:K2").Merge
        ws.Range("A2:K2").Interior.Color = RGB(220, 252, 231)
        ws.Range("A2:K2").Font.Color = RGB(20, 83, 45)
        ws.Range("A2:K2").Font.Bold = True
        ws.Range("A2:K2").HorizontalAlignment = xlCenter
        ws.Rows(2).RowHeight = 26
    Else
        For r = 2 To lastR
            With ws.Range("A" & r & ":K" & r)
                .Borders.LineStyle = xlContinuous
                .Borders.Color = RGB(226, 232, 240)
                If (r Mod 2) = 0 Then
                    .Interior.Color = RGB(255, 255, 255)
                Else
                    .Interior.Color = RGB(248, 250, 252)
                End If
                .Font.Color = RGB(15, 23, 42)
            End With
            ws.Cells(r, SHOP_TGT_COL_CODE).Interior.Color = RGB(239, 246, 255)
            ws.Cells(r, SHOP_TGT_COL_RESULT).Interior.Color = RGB(204, 251, 241)
            ws.Cells(r, SHOP_TGT_COL_STATUS).Interior.Color = RGB(254, 249, 195)
        Next r
        ws.Range("A1:K" & lastR).AutoFilter
    End If
    ws.Range("A1:K" & Application.Max(2, lastR)).VerticalAlignment = xlCenter
    ws.Range("A:F").HorizontalAlignment = xlCenter
    ws.Range("G:G").HorizontalAlignment = xlLeft
    ws.Range("H:H").HorizontalAlignment = xlLeft
    ws.Range("I:I").HorizontalAlignment = xlCenter
    ws.Range("J:J").HorizontalAlignment = xlLeft
    ws.Range("K:K").HorizontalAlignment = xlCenter
    ws.Range("G:J").WrapText = True
    AutoFitSheetSmart ws, "A:K", 6, 45
    If lastR >= 2 Then
        If ws.Columns("B:B").ColumnWidth < 18 Then ws.Columns("B:B").ColumnWidth = 18
        If ws.Columns("C:C").ColumnWidth < 18 Then ws.Columns("C:C").ColumnWidth = 18
        If ws.Columns("D:D").ColumnWidth < 16 Then ws.Columns("D:D").ColumnWidth = 16
        If ws.Columns("H:H").ColumnWidth < 30 Then ws.Columns("H:H").ColumnWidth = 30
        If ws.Columns("J:J").ColumnWidth < 30 Then ws.Columns("J:J").ColumnWidth = 30
    End If
End Sub

Private Function IsCashOperationTransactionRow(ByVal ws As Worksheet, ByVal r As Long) As Boolean
    Dim txt As String
    If ws Is Nothing Then Exit Function
    If r < 2 Then Exit Function
    If Len(CellText(ws.Cells(r, OUT_COL_BANK).Value)) = 0 Then Exit Function
    txt = CellText(ws.Cells(r, OUT_COL_TEKIYO).Value)
    If IsSpecialCashOperationRow(txt) Then Exit Function
    If Len(CellText(ws.Cells(r, OUT_COL_DATE).Value)) = 0 Then Exit Function
    IsCashOperationTransactionRow = True
End Function

Private Function IsSpecialCashOperationRow(ByVal tekiyoText As String) As Boolean
    If tekiyoText = "�����J�ݓ�" Or tekiyoText = "��������" Then
        IsSpecialCashOperationRow = True
    ElseIf InStr(tekiyoText, "�c��") > 0 Then
        IsSpecialCashOperationRow = True
    End If
End Function

Private Function FindShopTargetRow(ByVal ws As Worksheet, ByVal bankName As String, ByVal codeText As String) As Long
    Dim lastR As Long, r As Long
    lastR = LastRow(ws, SHOP_TGT_COL_NO)
    For r = 2 To lastR
        If CellText(ws.Cells(r, SHOP_TGT_COL_BANK).Value) = bankName And _
           CellText(ws.Cells(r, SHOP_TGT_COL_CODE).Value) = codeText Then
            FindShopTargetRow = r
            Exit Function
        End If
    Next r
End Function

Private Function LookupShopConversionName(ByVal ws As Worksheet, ByVal bankName As String, ByVal codeText As String) As String
    Dim r As Long
    If ws Is Nothing Then Exit Function
    r = FindShopTargetRow(ws, bankName, codeText)
    If r > 0 Then LookupShopConversionName = CellText(ws.Cells(r, SHOP_TGT_COL_RESULT).Value)
End Function

Private Sub UpdateShopTargetStatuses(ByVal ws As Worksheet)
    Dim lastR As Long, r As Long
    If ws Is Nothing Then Exit Sub
    lastR = LastRow(ws, SHOP_TGT_COL_NO)
    For r = 2 To lastR
        If Len(CellText(ws.Cells(r, SHOP_TGT_COL_RESULT).Value)) > 0 Then
            ws.Cells(r, SHOP_TGT_COL_STATUS).Value = "���͍�"
            ws.Cells(r, SHOP_TGT_COL_STATUS).Interior.Color = RGB(187, 247, 208)
        ElseIf Len(CellText(ws.Cells(r, SHOP_TGT_COL_CODE).Value)) > 0 Then
            ws.Cells(r, SHOP_TGT_COL_STATUS).Value = "������"
            ws.Cells(r, SHOP_TGT_COL_STATUS).Interior.Color = RGB(254, 249, 195)
        End If
    Next r
End Sub
Private Sub PreserveShopTargetValues(ByVal oldData As Variant, ByVal bankName As String, ByVal codeText As String, _
                                     ByRef resultName As String, ByRef statusText As String, ByRef memoText As String)
    Dim i As Long
    resultName = "": statusText = "": memoText = ""
    If Not IsArray(oldData) Then Exit Sub
    On Error GoTo EH
    For i = LBound(oldData, 1) + 1 To UBound(oldData, 1)
        If CellText(oldData(i, SHOP_TGT_COL_BANK)) = bankName And CellText(oldData(i, SHOP_TGT_COL_CODE)) = codeText Then
            resultName = CellText(oldData(i, SHOP_TGT_COL_RESULT))
            statusText = CellText(oldData(i, SHOP_TGT_COL_STATUS))
            memoText = CellText(oldData(i, SHOP_TGT_COL_MEMO))
            Exit Sub
        End If
    Next i
EH:
End Sub


Private Function AppendUniqueText(ByVal existingText As String, ByVal addText As String) As String
    If Len(addText) = 0 Then
        AppendUniqueText = existingText
    ElseIf Len(existingText) = 0 Then
        AppendUniqueText = addText
    ElseIf InStr(1, " / " & existingText & " / ", " / " & addText & " / ", vbTextCompare) > 0 Then
        AppendUniqueText = existingText
    Else
        AppendUniqueText = existingText & " / " & addText
    End If
End Function

Private Function AppendRowNumber(ByVal existingText As String, ByVal rowNo As Long) As String
    If Len(existingText) = 0 Then
        AppendRowNumber = CStr(rowNo)
    Else
        AppendRowNumber = existingText & "," & CStr(rowNo)
    End If
End Function

Private Function DetectShopCodeKind(ByVal bankName As String, ByVal codeText As String, ByVal tekiyoText As String, ByVal machineText As String) As String
    Dim digitsOnly As Boolean, n As Long
    digitsOnly = IsDigitsOnly(codeText)
    n = Len(codeText)
    If InStr(bankName, "�䂤����") > 0 Or InStr(bankName, "�X��") > 0 Then
        If digitsOnly And (n = 5 Or n = 6) Then
            DetectShopCodeKind = "�䂤����戵�X�ԍ����"
        Else
            DetectShopCodeKind = "�䂤�������R�[�h���"
        End If
    ElseIf digitsOnly And n <= 3 Then
        DetectShopCodeKind = "�ʏ��s�x�X�R�[�h���"
    ElseIf digitsOnly And (n = 5 Or n = 6) Then
        DetectShopCodeKind = "5/6���R�[�h���"
    ElseIf digitsOnly And n = 7 Then
        DetectShopCodeKind = "7��ATM�R�[�h���"
    ElseIf ContainsDigit(codeText) Then
        DetectShopCodeKind = "�p�����R�[�h���"
    Else
        DetectShopCodeKind = "�v�m�F�R�[�h"
    End If
End Function

Public Function IsCodeLikeShop(ByVal valueText As String) As Boolean
    Dim s As String
    s = NormalizeShopCodeText(valueText)
    If Len(s) = 0 Then Exit Function
    If ContainsJapaneseChar(s) Then Exit Function
    If Not ContainsDigit(s) Then Exit Function
    If InStr(s, "�x�X") > 0 Or InStr(s, "�{�X") > 0 Then Exit Function
    IsCodeLikeShop = True
End Function

Public Function NormalizeShopCodeText(ByVal valueText As String) As String
    Dim s As String, i As Long, ch As String, code As Long, outText As String
    s = Trim$(CStr(valueText))
    s = Replace(s, "�@", " ")
    s = Trim$(s)
    For i = 1 To Len(s)
        ch = Mid$(s, i, 1)
        code = AscW(ch)
        Select Case code
            Case &HFF10 To &HFF19
                outText = outText & ChrW$(code - &HFEE0)
            Case &HFF21 To &HFF3A
                outText = outText & ChrW$(code - &HFEE0)
            Case &HFF41 To &HFF5A
                outText = outText & UCase$(ChrW$(code - &HFEE0))
            Case &H2010, &H2011, &H2012, &H2013, &H2014, &H2212, &HFF0D
                outText = outText & "-"
            Case 32, 9
                '�󔒂͏��O
            Case Else
                outText = outText & UCase$(ch)
        End Select
    Next i
    NormalizeShopCodeText = outText
End Function

Private Function ContainsDigit(ByVal s As String) As Boolean
    Dim i As Long, code As Long
    For i = 1 To Len(s)
        code = AscW(Mid$(s, i, 1))
        If code >= 48 And code <= 57 Then ContainsDigit = True: Exit Function
    Next i
End Function

Private Function IsDigitsOnly(ByVal s As String) As Boolean
    Dim i As Long, code As Long
    If Len(s) = 0 Then Exit Function
    For i = 1 To Len(s)
        code = AscW(Mid$(s, i, 1))
        If code < 48 Or code > 57 Then Exit Function
    Next i
    IsDigitsOnly = True
End Function

Private Function ContainsJapaneseChar(ByVal s As String) As Boolean
    Dim i As Long, code As Long
    For i = 1 To Len(s)
        code = AscW(Mid$(s, i, 1))
        If code < 0 Then code = code + 65536
        If (code >= &H3040 And code <= &H30FF) Or _
           (code >= &H3400 And code <= &H9FFF) Or _
           (code >= &HF900 And code <= &HFAFF) Or _
           (code >= &HFF66 And code <= &HFF9D) Then
            ContainsJapaneseChar = True
            Exit Function
        End If
    Next i
End Function

Attribute VB_Name = "modAppState"
Option Explicit

Private mStateActive As Boolean
Private mPrevEvents As Boolean
Private mPrevScreenUpdating As Boolean
Private mPrevDisplayAlerts As Boolean
Private mPrevCalculation As XlCalculation
Private mPrevStatusBar As Variant

Public Sub AppBegin(Optional ByVal statusText As String = "������...")
    On Error Resume Next
    If Not mStateActive Then
        mPrevEvents = Application.EnableEvents
        mPrevScreenUpdating = Application.ScreenUpdating
        mPrevDisplayAlerts = Application.DisplayAlerts
        mPrevCalculation = Application.Calculation
        mPrevStatusBar = Application.StatusBar
        mStateActive = True
    End If
    Application.EnableEvents = False
    Application.ScreenUpdating = False
    Application.DisplayAlerts = False
    Application.Calculation = xlCalculationManual
    Application.StatusBar = statusText
    On Error GoTo 0
End Sub

Public Sub AppEnd()
    On Error Resume Next
    If mStateActive Then
        Application.EnableEvents = mPrevEvents
        Application.ScreenUpdating = mPrevScreenUpdating
        Application.DisplayAlerts = mPrevDisplayAlerts
        Application.Calculation = mPrevCalculation
        Application.StatusBar = mPrevStatusBar
    Else
        Application.EnableEvents = True
        Application.ScreenUpdating = True
        Application.DisplayAlerts = True
        Application.StatusBar = False
    End If
    mStateActive = False
    On Error GoTo 0
End Sub

Public Sub AppForceRestore()
    On Error Resume Next
    DisableInputKeys
    If mStateActive Then
        AppEnd
        Exit Sub
    End If
    Application.EnableEvents = True
    Application.ScreenUpdating = True
    Application.DisplayAlerts = True
    Application.StatusBar = False
    On Error GoTo 0
End Sub

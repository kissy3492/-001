Attribute VB_Name = "modClear"
Option Explicit

Public Sub ClearTransactionInput()
    Dim ws As Worksheet
    If Not SheetExists(SH_INPUT) Then Exit Sub
    Set ws = GetSheet(SH_INPUT)
    On Error Resume Next
    ws.Unprotect Password:=TOOL_PASSWORD
    ws.Range(ws.Cells(TX_FIRST_ROW, COL_TX_YEAR), ws.Cells(TX_LAST_ROW, COL_TX_OTHER)).ClearContents
    RestoreAllTransactionRowStyles ws
    ProtectInputSheet
    On Error GoTo 0
End Sub

Public Sub ClearAllInputFields()
    ClearInputCore KEEP_NONE, True, True
End Sub

Public Sub ClearInputKeepPerson()
    ClearInputCore KEEP_PERSON_ONLY, True, True
End Sub

Public Sub ClearInputKeepBankBranch()
    ClearInputCore KEEP_BANK_BRANCH, True, True
End Sub

Public Sub ClearInputKeepBankBranchPersonType()
    ClearInputCore KEEP_BANK_BRANCH_PERSON_TYPE, True, True
End Sub

Public Sub ClearInputKeepBankAndPerson()
    '���{�^�����Ƃ̌݊��p�B�����ԍ��͕K�������B
    ClearInputCore KEEP_BANK_BRANCH_PERSON_TYPE, True, True
End Sub

Public Sub IncrementAccountBranchNo()
    Dim ws As Worksheet
    Dim s As String
    If Not SheetExists(SH_INPUT) Then Exit Sub
    Set ws = GetSheet(SH_INPUT)
    s = CellText(ws.Range(CELL_ACCOUNT_NO).Value)
    If Len(s) = 0 Then
        MsgBox "�����ԍ�����͂��Ă���}��+1�����s���Ă��������B" & vbCrLf & "��: 1234567 �� 1234567-1 / 1234567-1 �� 1234567-2", vbInformation
        Exit Sub
    End If
    SetNextBranchAccountNumber NextBranchAccountNo(s)
End Sub

Public Sub SetNextBranchAccountNumber(ByVal nextAccNo As String)
    Dim ws As Worksheet
    If Len(CellText(nextAccNo)) = 0 Then Exit Sub
    If Not SheetExists(SH_INPUT) Then Exit Sub
    Set ws = GetSheet(SH_INPUT)
    On Error Resume Next
    ws.Unprotect Password:=TOOL_PASSWORD
    ws.Range(CELL_ACCOUNT_NO).Value = nextAccNo
    ProtectInputSheet
    SafeSelectCell ws, CELL_ACCOUNT_NO
    On Error GoTo 0
End Sub

Public Sub ApplyPostTransferCleanup(Optional ByVal overrideKeepPolicy As String = "")
    Dim keepPolicy As String
    Dim clearTx As Boolean
    Dim clearBal As Boolean
    keepPolicy = overrideKeepPolicy
    If Len(keepPolicy) = 0 Then keepPolicy = GetPostTransferKeepPolicy()
    clearTx = GetPostTransferClearTransaction()
    clearBal = GetPostTransferClearBalance()
    ClearInputCore keepPolicy, clearTx, clearBal
End Sub

Public Sub ApplyPostTransferCleanupKeepBankBranch()
    ApplyPostTransferCleanup KEEP_BANK_BRANCH
End Sub

Private Sub ClearInputCore(ByVal keepPolicy As String, ByVal clearTx As Boolean, ByVal clearBal As Boolean)
    Dim ws As Worksheet
    Dim bankName As String, branchName As String, personName As String, accType As String
    Dim accNo As String, openDate As Variant, closeDate As Variant
    Dim memoCol As Long
    Dim rr As Long
    If Not SheetExists(SH_INPUT) Then Exit Sub
    Set ws = GetSheet(SH_INPUT)

    bankName = CellText(ws.Range(CELL_BANK).Value)
    branchName = CellText(ws.Range(CELL_BRANCH).Value)
    personName = CellText(ws.Range(CELL_PERSON).Value)
    accType = CellText(ws.Range(CELL_ACCOUNT_TYPE).Value)
    accNo = CellText(ws.Range(CELL_ACCOUNT_NO).Value)
    openDate = ws.Range(CELL_OPEN_DATE).Value
    closeDate = ws.Range(CELL_CLOSE_DATE).Value

    On Error Resume Next
    ws.Unprotect Password:=TOOL_PASSWORD

    ClearEffectiveContents ws.Range(CELL_BANK)
    ClearEffectiveContents ws.Range(CELL_BRANCH)
    ClearEffectiveContents ws.Range(CELL_PERSON)
    ClearEffectiveContents ws.Range(CELL_ACCOUNT_TYPE)
    ClearEffectiveContents ws.Range(CELL_ACCOUNT_NO)
    ClearEffectiveContents ws.Range(CELL_OPEN_DATE)
    ClearEffectiveContents ws.Range(CELL_CLOSE_DATE)

    memoCol = BalanceMemoCol(ws)
    If clearBal Then
        If memoCol > BAL_FIRST_COL Then ws.Range(ws.Cells(BAL_VALUE_ROW, BAL_FIRST_COL), ws.Cells(BAL_VALUE_ROW, memoCol - 1)).ClearContents
        ClearEffectiveContents ws.Cells(BAL_VALUE_ROW, memoCol)
    End If

    If clearTx Then
        ws.Range(ws.Cells(TX_FIRST_ROW, COL_TX_YEAR), ws.Cells(TX_LAST_ROW, COL_TX_OTHER)).ClearContents
        RestoreAllTransactionRowStyles ws
    End If

    Select Case keepPolicy
        Case KEEP_PERSON_ONLY
            ws.Range(CELL_PERSON).Value = personName
        Case KEEP_BANK_BRANCH
            ws.Range(CELL_BANK).Value = bankName
            ws.Range(CELL_BRANCH).Value = branchName
        Case KEEP_BANK_BRANCH_PERSON_TYPE
            ws.Range(CELL_BANK).Value = bankName
            ws.Range(CELL_BRANCH).Value = branchName
            ws.Range(CELL_PERSON).Value = personName
            ws.Range(CELL_ACCOUNT_TYPE).Value = accType
        Case KEEP_ALL_ACCOUNT
            ws.Range(CELL_BANK).Value = bankName
            ws.Range(CELL_BRANCH).Value = branchName
            ws.Range(CELL_PERSON).Value = personName
            ws.Range(CELL_ACCOUNT_TYPE).Value = accType
            ws.Range(CELL_ACCOUNT_NO).Value = accNo
            ws.Range(CELL_OPEN_DATE).Value = openDate
            ws.Range(CELL_CLOSE_DATE).Value = closeDate
        Case Else
            '�c���Ȃ�
    End Select

    ws.Range(CELL_STATUS).Value = "�⊮�l�@�N -�@�� -�@�� -"
    PolishInputLayout ws
    ProtectInputSheet
    On Error GoTo 0
End Sub

Public Sub InitializeToolData()
    Dim answer As VbMsgBoxResult
    answer = MsgBox("���͗��A��ƃf�[�^�A�o�̓V�[�g�A�`�F�b�N���ʂ����������܂��B" & vbCrLf & _
                    "�ݒ�ƌ��}�X�^�͎c���܂��B��낵���ł����H", vbYesNo + vbQuestion, "�c�[��������")
    If answer <> vbYes Then Exit Sub
    On Error GoTo EH
    AppBegin "��������..."
    ClearInputCore KEEP_NONE, True, True
    BuildWorkSheets
    BuildOutputSheets
    BuildBalanceInputFields False
    ApplyInputSettings False
    HideDailySheets True
    If SheetExists(SH_INPUT) Then ThisWorkbook.Worksheets(SH_INPUT).Visible = xlSheetVisible
    AppEnd
    MsgBox "���������܂����B", vbInformation
    Exit Sub
EH:
    AppEnd
    MsgBox "���������ɃG���[���������܂����B" & vbCrLf & "Err " & Err.Number & ": " & Err.Description, vbExclamation
End Sub

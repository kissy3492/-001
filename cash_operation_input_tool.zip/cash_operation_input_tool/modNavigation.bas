Attribute VB_Name = "modNavigation"
Option Explicit

Private mLastHighlightRow As Long
Private mLastEditedRow As Long
Private mLastEditedCol As Long
Private mRedirecting As Boolean

Public Sub EnableInputKeys()
    '���̓V�[�g���L���ȊԂ���Tab/Shift+Tab�𐧌䂷��B
    '�u�b�N��A�N�e�B�u���E���̓V�[�g���E���ɂ͕K����������B
    On Error Resume Next
    Application.OnKey "{TAB}", MacroRef("InputTabNext")
    Application.OnKey "+{TAB}", MacroRef("InputTabPrev")
    On Error GoTo 0
End Sub

Public Sub DisableInputKeys()
    On Error Resume Next
    Application.OnKey "{TAB}"
    Application.OnKey "+{TAB}"
    On Error GoTo 0
End Sub

Public Sub InputTabNext()
    MoveInputCell False
End Sub

Public Sub InputTabPrev()
    MoveInputCell True
End Sub

Public Sub MoveInputCell(ByVal backwards As Boolean)
    Dim ws As Worksheet
    Dim nextCell As Range
    On Error GoTo Fallback
    If ActiveSheet Is Nothing Then GoTo Fallback
    If ActiveSheet.Name <> SH_INPUT Then GoTo Fallback
    Set ws = ActiveSheet
    Set nextCell = GetNextInputCell(ws, ActiveCell, backwards)
    If Not nextCell Is Nothing Then
        Application.Goto nextCell, False
        Exit Sub
    End If
Fallback:
    On Error Resume Next
    If backwards Then ActiveCell.Offset(0, -1).Select Else ActiveCell.Offset(0, 1).Select
    On Error GoTo 0
End Sub

Public Function GetNextInputCell(ByVal ws As Worksheet, ByVal cur As Range, ByVal backwards As Boolean) As Range
    Dim r As Long, c As Long, memoCol As Long
    If ws Is Nothing Or cur Is Nothing Then Exit Function
    r = cur.Row: c = cur.Column
    memoCol = BalanceMemoCol(ws)
    If IsAccountCell(cur) Then
        Set GetNextInputCell = NextAccountCell(ws, cur, backwards)
        Exit Function
    End If
    If r = BAL_VALUE_ROW And c >= BAL_FIRST_COL And c <= memoCol Then
        Set GetNextInputCell = NextBalanceCell(ws, cur, backwards, memoCol)
        Exit Function
    End If
    If r >= TX_FIRST_ROW And r <= TX_LAST_ROW And c >= COL_TX_YEAR And c <= COL_TX_OTHER Then
        Set GetNextInputCell = NextTransactionCell(ws, cur, backwards)
        Exit Function
    End If
    Set GetNextInputCell = ws.Range(CELL_BANK)
End Function

Private Function IsAccountCell(ByVal cur As Range) As Boolean
    Dim a As String
    If cur Is Nothing Then Exit Function
    a = cur.Address(False, False)
    IsAccountCell = (a = CELL_BANK Or a = CELL_BRANCH Or a = CELL_PERSON Or a = CELL_ACCOUNT_TYPE Or _
                     a = CELL_ACCOUNT_NO Or a = CELL_OPEN_DATE Or a = CELL_CLOSE_DATE)
End Function

Private Function NextAccountCell(ByVal ws As Worksheet, ByVal cur As Range, ByVal backwards As Boolean) As Range
    Dim arr As Variant, i As Long
    arr = Array(CELL_BANK, CELL_BRANCH, CELL_PERSON, CELL_ACCOUNT_TYPE, CELL_ACCOUNT_NO, CELL_OPEN_DATE, CELL_CLOSE_DATE)
    For i = LBound(arr) To UBound(arr)
        If cur.Address(False, False) = CStr(arr(i)) Then
            If backwards Then
                If i = LBound(arr) Then Set NextAccountCell = ws.Range(CELL_BANK) Else Set NextAccountCell = ws.Range(CStr(arr(i - 1)))
            Else
                If i = UBound(arr) Then Set NextAccountCell = ws.Cells(BAL_VALUE_ROW, BAL_FIRST_COL) Else Set NextAccountCell = ws.Range(CStr(arr(i + 1)))
            End If
            Exit Function
        End If
    Next i
    Set NextAccountCell = ws.Range(CELL_BANK)
End Function

Private Function NextBalanceCell(ByVal ws As Worksheet, ByVal cur As Range, ByVal backwards As Boolean, ByVal memoCol As Long) As Range
    If backwards Then
        If cur.Column <= BAL_FIRST_COL Then Set NextBalanceCell = ws.Range(CELL_CLOSE_DATE) Else Set NextBalanceCell = ws.Cells(BAL_VALUE_ROW, cur.Column - 1)
    Else
        If cur.Column >= memoCol Then Set NextBalanceCell = ws.Cells(TX_FIRST_ROW, COL_TX_YEAR) Else Set NextBalanceCell = ws.Cells(BAL_VALUE_ROW, cur.Column + 1)
    End If
End Function

Private Function NextTransactionCell(ByVal ws As Worksheet, ByVal cur As Range, ByVal backwards As Boolean) As Range
    Dim cols As Variant, idx As Long, i As Long, targetCol As Long
    cols = TransactionRoute(GetInputMode())
    If cur.Column = COL_TX_YEAR And Not backwards Then Set NextTransactionCell = ws.Cells(cur.Row, COL_TX_MONTH): Exit Function
    If cur.Column = COL_TX_MONTH And Not backwards Then Set NextTransactionCell = ws.Cells(cur.Row, COL_TX_DAY): Exit Function
    If cur.Column = COL_TX_DAY And backwards And cur.Row <= TX_FIRST_ROW Then Set NextTransactionCell = ws.Cells(cur.Row, COL_TX_MONTH): Exit Function
    If cur.Column = COL_TX_MONTH And backwards Then Set NextTransactionCell = ws.Cells(cur.Row, COL_TX_YEAR): Exit Function
    If cur.Column = COL_TX_YEAR And backwards Then Set NextTransactionCell = ws.Cells(cur.Row, COL_TX_YEAR): Exit Function
    idx = -1
    For i = LBound(cols) To UBound(cols)
        If CLng(cols(i)) = cur.Column Then idx = i: Exit For
    Next i
    If idx = -1 Then Set NextTransactionCell = ws.Cells(cur.Row, COL_TX_DAY): Exit Function
    If backwards Then
        If idx = LBound(cols) Then
            If cur.Row <= TX_FIRST_ROW Then Set NextTransactionCell = ws.Cells(TX_FIRST_ROW, COL_TX_DAY) Else Set NextTransactionCell = ws.Cells(cur.Row - 1, CLng(cols(UBound(cols))))
        Else
            Set NextTransactionCell = ws.Cells(cur.Row, CLng(cols(idx - 1)))
        End If
    Else
        If cur.Column = COL_TX_WITHDRAW And HasText(cur.Value) Then
            targetCol = RouteColumnAfter(cols, COL_TX_DEPOSIT)
            Set NextTransactionCell = ws.Cells(cur.Row, targetCol)
            Exit Function
        End If
        If idx = UBound(cols) Then
            If cur.Row >= TX_LAST_ROW Then Set NextTransactionCell = ws.Cells(TX_LAST_ROW, CLng(cols(idx))) Else Set NextTransactionCell = ws.Cells(cur.Row + 1, COL_TX_DAY)
        Else
            Set NextTransactionCell = ws.Cells(cur.Row, CLng(cols(idx + 1)))
        End If
    End If
End Function

Private Function TransactionRoute(ByVal modeText As String) As Variant
    If modeText = MODE_SIMPLE Then
        TransactionRoute = Array(COL_TX_DAY, COL_TX_WITHDRAW, COL_TX_DEPOSIT, COL_TX_SHOP)
    ElseIf modeText = MODE_NO_TIME Then
        TransactionRoute = Array(COL_TX_DAY, COL_TX_WITHDRAW, COL_TX_DEPOSIT, COL_TX_SHOP, COL_TX_MACHINE, COL_TX_TEKIYO)
    ElseIf modeText = MODE_NO_MACHINE Then
        TransactionRoute = Array(COL_TX_DAY, COL_TX_TIME, COL_TX_WITHDRAW, COL_TX_DEPOSIT, COL_TX_SHOP, COL_TX_TEKIYO)
    ElseIf modeText = MODE_NO_TEKIYO Then
        TransactionRoute = Array(COL_TX_DAY, COL_TX_TIME, COL_TX_WITHDRAW, COL_TX_DEPOSIT, COL_TX_SHOP, COL_TX_MACHINE)
    ElseIf modeText = MODE_WITH_OTHER Then
        TransactionRoute = Array(COL_TX_DAY, COL_TX_TIME, COL_TX_WITHDRAW, COL_TX_DEPOSIT, COL_TX_SHOP, COL_TX_MACHINE, COL_TX_TEKIYO, COL_TX_OTHER)
    Else
        TransactionRoute = Array(COL_TX_DAY, COL_TX_TIME, COL_TX_WITHDRAW, COL_TX_DEPOSIT, COL_TX_SHOP, COL_TX_MACHINE, COL_TX_TEKIYO)
    End If
End Function

Private Function RouteColumnAfter(ByVal cols As Variant, ByVal afterCol As Long) As Long
    Dim i As Long
    For i = LBound(cols) To UBound(cols) - 1
        If CLng(cols(i)) = afterCol Then RouteColumnAfter = CLng(cols(i + 1)): Exit Function
    Next i
    RouteColumnAfter = COL_TX_SHOP
End Function

Public Sub OnInputSelectionChange(ByVal Target As Range)
    Dim t As Range
    On Error Resume Next
    If Target Is Nothing Then Exit Sub
    Set t = Target
    If t.Cells.CountLarge > 1 Then
        If t.MergeCells Then
            Set t = t.MergeArea.Cells(1, 1)
        Else
            Exit Sub
        End If
    End If
    If mRedirecting Then Exit Sub
    SmartRedirectAfterDefaultMove t
    UpdateCurrentRowHighlight t
    UpdateComplementStatus t
    On Error GoTo 0
End Sub

Public Sub OnInputChange(ByVal Target As Range)
    Dim nextCol As Long
    Dim t As Range
    If Target Is Nothing Then Exit Sub
    Set t = Target
    If t.Cells.CountLarge > 1 Then
        If t.MergeCells Then
            Set t = t.MergeArea.Cells(1, 1)
        Else
            Exit Sub
        End If
    End If
    If t.Worksheet.Name <> SH_INPUT Then Exit Sub

    '��s���E�x�X���E�l�����́A���͂������̂�����ȍ~�̌��ɂ���B
    If t.Address(False, False) = CELL_BANK Or t.Address(False, False) = CELL_BRANCH Or t.Address(False, False) = CELL_PERSON Then
        UpdateCandidateFromTarget t
        Exit Sub
    End If

    If t.Row < TX_FIRST_ROW Or t.Row > TX_LAST_ROW Then Exit Sub

    mLastEditedRow = t.Row
    mLastEditedCol = t.Column

    If t.Column = COL_TX_WITHDRAW And HasText(t.Value) Then
        nextCol = RouteColumnAfter(TransactionRoute(GetInputMode()), COL_TX_DEPOSIT)
        SafeGoto t.Worksheet.Cells(t.Row, nextCol)
    ElseIf t.Column = COL_TX_DEPOSIT And HasText(t.Value) Then
        nextCol = RouteColumnAfter(TransactionRoute(GetInputMode()), COL_TX_DEPOSIT)
        SafeGoto t.Worksheet.Cells(t.Row, nextCol)
    ElseIf t.Column = COL_TX_TEKIYO And GetInputMode() <> MODE_WITH_OTHER Then
        If t.Row < TX_LAST_ROW Then SafeGoto t.Worksheet.Cells(t.Row + 1, COL_TX_DAY)
    End If
End Sub

Private Sub SmartRedirectAfterDefaultMove(ByVal Target As Range)
    Dim nextCol As Long
    If Target.Worksheet.Name <> SH_INPUT Then Exit Sub
    If Target.Row < TX_FIRST_ROW Or Target.Row > TX_LAST_ROW Then Exit Sub
    If mLastEditedRow <> Target.Row Then Exit Sub

    If Target.Column = COL_TX_DEPOSIT And mLastEditedCol = COL_TX_WITHDRAW Then
        If HasText(Target.Worksheet.Cells(Target.Row, COL_TX_WITHDRAW).Value) Then
            nextCol = RouteColumnAfter(TransactionRoute(GetInputMode()), COL_TX_DEPOSIT)
            SafeGoto Target.Worksheet.Cells(Target.Row, nextCol)
        End If
    ElseIf Target.Column = COL_TX_OTHER And mLastEditedCol = COL_TX_TEKIYO Then
        If GetInputMode() <> MODE_WITH_OTHER Then
            If Target.Row < TX_LAST_ROW Then SafeGoto Target.Worksheet.Cells(Target.Row + 1, COL_TX_DAY)
        End If
    End If
End Sub

Private Sub SafeGoto(ByVal targetCell As Range)
    If targetCell Is Nothing Then Exit Sub
    On Error Resume Next
    mRedirecting = True
    Application.Goto targetCell, False
    mRedirecting = False
    On Error GoTo 0
End Sub

Private Sub UpdateCurrentRowHighlight(ByVal Target As Range)
    Dim ws As Worksheet
    Set ws = Target.Worksheet
    If mLastHighlightRow >= TX_FIRST_ROW And mLastHighlightRow <= TX_LAST_ROW Then
        RestoreTransactionRowStyle ws, mLastHighlightRow
    End If
    If Target.Row >= TX_FIRST_ROW And Target.Row <= TX_LAST_ROW Then
        With ws.Range(ws.Cells(Target.Row, COL_TX_YEAR), ws.Cells(Target.Row, COL_TX_OTHER))
            .Interior.Color = RGB(219, 234, 254)
            .Font.Color = RGB(15, 23, 42)
            .Borders.Color = RGB(59, 130, 246)
        End With
        mLastHighlightRow = Target.Row
    Else
        mLastHighlightRow = 0
    End If
End Sub

Private Sub RestoreTransactionRowStyle(ByVal ws As Worksheet, ByVal rowNo As Long)
    If ws Is Nothing Then Exit Sub
    With ws.Range(ws.Cells(rowNo, COL_TX_YEAR), ws.Cells(rowNo, COL_TX_OTHER))
        If (rowNo - TX_FIRST_ROW) Mod 2 = 0 Then
            .Interior.Color = RGB(255, 255, 255)
        Else
            .Interior.Color = RGB(248, 250, 252)
        End If
        .Font.Color = RGB(15, 23, 42)
        .Borders.Color = RGB(226, 232, 240)
    End With
End Sub
Private Sub UpdateComplementStatus(ByVal Target As Range)
    Dim ws As Worksheet, r As Long, cy As Long, cm As Long, cd As Long
    Dim ok As Boolean, yAdd As Long, d As Variant
    Dim textY As String, textM As String, textD As String
    Set ws = Target.Worksheet
    If Target.Row < TX_FIRST_ROW Then
        ws.Range(CELL_STATUS).Value = "�⊮�l�@�N -�@�� -�@�� -"
        Exit Sub
    End If
    yAdd = GetCfgLong(ROW_CFG_YEAR_ADD, 2000)
    For r = TX_FIRST_ROW To Target.Row
        If Not IsTransactionRowBlank(ws, r) Then d = ResolveInputDate(ws.Cells(r, COL_TX_YEAR).Value, ws.Cells(r, COL_TX_MONTH).Value, ws.Cells(r, COL_TX_DAY).Value, cy, cm, cd, yAdd, ok)
    Next r
    If cy = 0 Then textY = "-" Else textY = CStr(cy)
    If cm = 0 Then textM = "-" Else textM = CStr(cm)
    If cd = 0 Then textD = "-" Else textD = CStr(cd)
    ws.Range(CELL_STATUS).Value = "�⊮�l�@�N " & textY & "�@�� " & textM & "�@�� " & textD
End Sub

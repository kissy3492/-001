Attribute VB_Name = "modUtilities"
Option Explicit

Public Function SheetExists(ByVal sheetName As String) As Boolean
    Dim ws As Worksheet
    On Error Resume Next
    Set ws = ThisWorkbook.Worksheets(sheetName)
    SheetExists = Not ws Is Nothing
    On Error GoTo 0
End Function

Public Function GetSheet(ByVal sheetName As String) As Worksheet
    Dim ws As Worksheet
    On Error Resume Next
    Set ws = ThisWorkbook.Worksheets(sheetName)
    On Error GoTo 0
    If ws Is Nothing Then
        Err.Raise vbObjectError + 1001, "GetSheet", "�V�[�g�u" & sheetName & "�v��������܂���BSetupWorkbook�����s���Ă��������B"
    End If
    Set GetSheet = ws
End Function

Public Function GetOrCreateSheet(ByVal sheetName As String, Optional ByVal resetSheet As Boolean = False) As Worksheet
    Dim ws As Worksheet
    On Error GoTo EH
    If SheetExists(sheetName) Then
        Set ws = ThisWorkbook.Worksheets(sheetName)
    Else
        Set ws = ThisWorkbook.Worksheets.Add(After:=ThisWorkbook.Worksheets(ThisWorkbook.Worksheets.Count))
        ws.Name = sheetName
    End If
    If ws Is Nothing Then Err.Raise vbObjectError + 1002, "GetOrCreateSheet", "�V�[�g�擾�Ɏ��s���܂���: " & sheetName
    On Error Resume Next
    ws.Visible = xlSheetVisible
    On Error GoTo EH
    If resetSheet Then ResetWorksheet ws
    Set GetOrCreateSheet = ws
    Exit Function
EH:
    Err.Raise Err.Number, "GetOrCreateSheet(" & sheetName & ")", Err.Description
End Function

Public Sub ResetWorksheet(ByVal ws As Worksheet)
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    ws.Unprotect Password:=TOOL_PASSWORD
    DeleteToolShapes ws, True
    ws.Cells.UnMerge
    ws.Cells.Clear
    ws.Cells.ClearFormats
    ws.Cells.Validation.Delete
    ws.Cells.Locked = False
    On Error GoTo 0
End Sub

Public Sub DeleteToolShapes(ByVal ws As Worksheet, Optional ByVal deleteAll As Boolean = False)
    Dim i As Long
    Dim nm As String
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    For i = ws.Shapes.Count To 1 Step -1
        nm = ws.Shapes(i).Name
        If deleteAll Or Left$(nm, Len(UI_PREFIX)) = UI_PREFIX Then ws.Shapes(i).Delete
    Next i
    On Error GoTo 0
End Sub

Public Sub ResetName(ByVal nm As String, ByVal rng As Range)
    Dim refText As String
    If rng Is Nothing Then Exit Sub
    On Error Resume Next
    ThisWorkbook.Names(nm).Delete
    Err.Clear
    refText = "='" & Replace(rng.Worksheet.Name, "'", "''") & "'!" & rng.Address(True, True, xlA1, False)
    ThisWorkbook.Names.Add Name:=nm, RefersTo:=refText
    On Error GoTo 0
End Sub

Public Function MacroRef(ByVal macroName As String) As String
    '�}�`�{�^�����ʃu�b�N�̓����}�N�����E��Ȃ��悤�A���̃u�b�N�֖����I�ɕR�Â���B
    MacroRef = "'" & Replace(ThisWorkbook.Name, "'", "''") & "'!" & macroName
End Function

Public Sub SetRowValues(ByVal firstCell As Range, ByVal values As Variant)
    '1����Array��Range�֒��ڑ���������������A�������Ɋm���ɏ������ށB
    Dim i As Long
    If firstCell Is Nothing Then Exit Sub
    For i = LBound(values) To UBound(values)
        firstCell.Offset(0, i - LBound(values)).Value = values(i)
    Next i
End Sub

Public Sub CapBalanceCollections(ByRef labels As Collection, ByRef dates As Collection, ByVal maxItems As Long)
    Dim newLabels As Collection
    Dim newDates As Collection
    Dim i As Long
    If labels Is Nothing Or dates Is Nothing Then Exit Sub
    If maxItems <= 0 Then Exit Sub
    If labels.Count <= maxItems Then Exit Sub
    Set newLabels = New Collection
    Set newDates = New Collection
    For i = 1 To maxItems
        newLabels.Add labels(i)
        newDates.Add dates(i)
    Next i
    Set labels = newLabels
    Set dates = newDates
End Sub

Public Function LastRow(ByVal ws As Worksheet, Optional ByVal colNo As Long = 1) As Long
    Dim r As Long
    If ws Is Nothing Then Exit Function
    r = ws.Cells(ws.Rows.Count, colNo).End(xlUp).Row
    If r = 1 And Len(Trim$(CStr(ws.Cells(1, colNo).Value))) = 0 Then r = 0
    LastRow = r
End Function

Public Function CellText(ByVal v As Variant) As String
    If IsError(v) Or IsNull(v) Or IsEmpty(v) Then
        CellText = ""
    Else
        CellText = Trim$(CStr(v))
    End If
End Function

Public Function HasText(ByVal v As Variant) As Boolean
    HasText = Len(CellText(v)) > 0
End Function

Public Function ToAmountOrBlank(ByVal v As Variant) As Variant
    Dim s As String
    s = Replace(CellText(v), ",", "")
    If Len(s) = 0 Then
        ToAmountOrBlank = ""
    ElseIf IsNumeric(s) Then
        ToAmountOrBlank = CDbl(s)
    Else
        ToAmountOrBlank = v
    End If
End Function

Public Function GetCfgCell(ByVal rowNo As Long) As Range
    Dim ws As Worksheet
    Set ws = GetSheet(SH_CONFIG)
    Set GetCfgCell = ws.Cells(rowNo, COL_CFG_VALUE)
End Function

Public Function GetCfgLong(ByVal rowNo As Long, ByVal defaultValue As Long) As Long
    On Error GoTo EH
    If IsNumeric(GetCfgCell(rowNo).Value) Then
        GetCfgLong = CLng(GetCfgCell(rowNo).Value)
    Else
        GetCfgLong = defaultValue
    End If
    Exit Function
EH:
    GetCfgLong = defaultValue
End Function

Public Function GetCfgDateValue(ByVal rowNo As Long) As Variant
    On Error GoTo EH
    If IsDate(GetCfgCell(rowNo).Value) Then
        GetCfgDateValue = CDate(GetCfgCell(rowNo).Value)
    Else
        GetCfgDateValue = ""
    End If
    Exit Function
EH:
    GetCfgDateValue = ""
End Function

Public Function GetInputMode() As String
    On Error GoTo EH
    GetInputMode = CellText(GetCfgCell(ROW_CFG_INPUT_MODE).Value)
    If Len(GetInputMode) = 0 Then GetInputMode = MODE_NORMAL
    Exit Function
EH:
    GetInputMode = MODE_NORMAL
End Function


Public Function GetPostTransferKeepPolicy() As String
    On Error GoTo EH
    GetPostTransferKeepPolicy = CellText(GetCfgCell(ROW_CFG_POST_KEEP).Value)
    If Len(GetPostTransferKeepPolicy) = 0 Then GetPostTransferKeepPolicy = KEEP_BANK_BRANCH_PERSON_TYPE
    Exit Function
EH:
    GetPostTransferKeepPolicy = KEEP_BANK_BRANCH_PERSON_TYPE
End Function

Public Function GetPostTransferClearTransaction() As Boolean
    On Error GoTo EH
    GetPostTransferClearTransaction = (CellText(GetCfgCell(ROW_CFG_POST_TX).Value) <> POST_KEEP)
    Exit Function
EH:
    GetPostTransferClearTransaction = True
End Function

Public Function GetPostTransferClearBalance() As Boolean
    On Error GoTo EH
    GetPostTransferClearBalance = (CellText(GetCfgCell(ROW_CFG_POST_BAL).Value) <> POST_KEEP)
    Exit Function
EH:
    GetPostTransferClearBalance = True
End Function

Public Function IsTransactionRowBlank(ByVal ws As Worksheet, ByVal r As Long) As Boolean
    Dim c As Long
    If ws Is Nothing Then
        IsTransactionRowBlank = True
        Exit Function
    End If
    For c = COL_TX_YEAR To COL_TX_OTHER
        If HasText(ws.Cells(r, c).Value) Then
            IsTransactionRowBlank = False
            Exit Function
        End If
    Next c
    IsTransactionRowBlank = True
End Function

Public Function NormalizeYearInput(ByVal v As Variant, ByVal yearAdd As Long, ByRef ok As Boolean) As Long
    Dim s As String
    Dim y As Long
    ok = False
    s = CellText(v)
    If Len(s) = 0 Or Not IsNumeric(s) Then Exit Function
    y = CLng(s)
    If y >= 0 And y <= 99 Then y = yearAdd + y
    If y < 1900 Or y > 9999 Then Exit Function
    NormalizeYearInput = y
    ok = True
End Function

Public Function ParseMonthDay(ByVal v As Variant, ByRef m As Long, ByRef d As Long) As Boolean
    Dim s As String
    s = CellText(v)
    ParseMonthDay = False
    If Len(s) < 3 Or Len(s) > 4 Then Exit Function
    If Not IsNumeric(s) Then Exit Function
    If Len(s) = 3 Then
        m = CLng(Left$(s, 1))
        d = CLng(Right$(s, 2))
    Else
        m = CLng(Left$(s, 2))
        d = CLng(Right$(s, 2))
    End If
    If m < 1 Or m > 12 Then Exit Function
    If d < 1 Or d > 31 Then Exit Function
    ParseMonthDay = True
End Function

Public Function ResolveInputDate(ByVal yearVal As Variant, ByVal monthVal As Variant, ByVal dayVal As Variant, _
    ByRef currentYear As Long, ByRef currentMonth As Long, ByRef currentDay As Long, _
    ByVal yearAdd As Long, ByRef ok As Boolean) As Variant

    Dim tmpYear As Long
    Dim tmpMonth As Long
    Dim tmpDay As Long
    Dim yearOK As Boolean
    Dim d As Date

    ok = False
    If HasText(yearVal) Then
        tmpYear = NormalizeYearInput(yearVal, yearAdd, yearOK)
        If Not yearOK Then Exit Function
        currentYear = tmpYear
    End If
    If HasText(monthVal) Then
        If Not IsNumeric(CellText(monthVal)) Then Exit Function
        currentMonth = CLng(CellText(monthVal))
    End If
    If HasText(dayVal) Then
        If ParseMonthDay(dayVal, tmpMonth, tmpDay) Then
            currentMonth = tmpMonth
            currentDay = tmpDay
        Else
            If Not IsNumeric(CellText(dayVal)) Then Exit Function
            currentDay = CLng(CellText(dayVal))
        End If
    End If
    If currentYear = 0 Or currentMonth = 0 Or currentDay = 0 Then Exit Function
    If currentMonth < 1 Or currentMonth > 12 Or currentDay < 1 Or currentDay > 31 Then Exit Function
    On Error GoTo InvalidDate
    d = DateSerial(currentYear, currentMonth, currentDay)
    If Year(d) <> currentYear Or Month(d) <> currentMonth Or Day(d) <> currentDay Then GoTo InvalidDate
    ResolveInputDate = d
    ok = True
    Exit Function
InvalidDate:
    ResolveInputDate = ""
End Function

Public Function NormalizeTimeInput(ByVal v As Variant, ByRef ok As Boolean) As Variant
    Dim s As String
    Dim i As Long
    Dim h As Long
    Dim m As Long
    ok = False
    s = CellText(v)
    If Len(s) = 0 Then
        NormalizeTimeInput = ""
        ok = True
        Exit Function
    End If
    If Len(s) > 4 Then
        NormalizeTimeInput = v
        Exit Function
    End If
    For i = 1 To Len(s)
        If Mid$(s, i, 1) < "0" Or Mid$(s, i, 1) > "9" Then
            NormalizeTimeInput = v
            Exit Function
        End If
    Next i
    s = Right$("0000" & s, 4)
    h = CLng(Left$(s, 2))
    m = CLng(Right$(s, 2))
    If h < 0 Or h > 23 Or m < 0 Or m > 59 Then
        NormalizeTimeInput = v
        Exit Function
    End If
    NormalizeTimeInput = TimeSerial(h, m, 0)
    ok = True
End Function

Public Function NextBranchAccountNo(ByVal accountNo As String) As String
    Dim s As String
    Dim baseNo As String
    Dim suffixText As String
    Dim p As Long
    Dim suffixNo As Long
    s = NormalizeAccountHyphen(CellText(accountNo))
    If Len(s) = 0 Then
        NextBranchAccountNo = ""
        Exit Function
    End If
    p = InStrRev(s, "-")
    If p > 0 Then
        baseNo = Left$(s, p - 1)
        suffixText = Mid$(s, p + 1)
        If Len(baseNo) > 0 And IsNumeric(suffixText) Then
            suffixNo = CLng(suffixText) + 1
            NextBranchAccountNo = baseNo & "-" & CStr(suffixNo)
            Exit Function
        End If
    End If
    NextBranchAccountNo = s & "-1"
End Function

Public Function NormalizeAccountHyphen(ByVal accountNo As String) As String
    Dim s As String
    s = Trim$(accountNo)
    s = Replace(s, "�|", "-")
    s = Replace(s, "�\", "-")
    s = Replace(s, "�[", "-")
    s = Replace(s, "�", "-")
    s = Replace(s, "�|", "-")
    NormalizeAccountHyphen = s
End Function

Public Sub BuildBalanceCollections(ByRef labels As Collection, ByRef dates As Collection)
    Dim startYear As Long
    Dim endYear As Long
    Dim inheritDate As Variant
    Dim y As Long
    Dim dYearEnd As Date
    Dim eventAdded As Boolean
    Dim labelText As String
    Set labels = New Collection
    Set dates = New Collection
    startYear = GetCfgLong(ROW_CFG_BAL_START_YEAR, Year(Date) - 4)
    endYear = GetCfgLong(ROW_CFG_BAL_END_YEAR, Year(Date))
    If endYear < startYear Then endYear = startYear
    inheritDate = GetCfgDateValue(ROW_CFG_INHERITANCE_DATE)
    For y = startYear To endYear
        dYearEnd = DateSerial(y, 12, 31)
        If IsDate(inheritDate) Then
            If Not eventAdded And CDate(inheritDate) < dYearEnd Then
                labels.Add "�����J�n�����_�c���i" & Format$(CDate(inheritDate), "yyyy/m/d") & "�j"
                dates.Add CDate(inheritDate)
                eventAdded = True
            End If
            If CDate(inheritDate) = dYearEnd Then
                labelText = CStr(y) & "�N���E�����J�n�����_�c���i" & Format$(CDate(inheritDate), "yyyy/m/d") & "�j"
                eventAdded = True
            Else
                labelText = CStr(y) & "�N���c��"
            End If
        Else
            labelText = CStr(y) & "�N���c��"
        End If
        labels.Add labelText
        dates.Add dYearEnd
    Next y
    If IsDate(inheritDate) And Not eventAdded Then
        labels.Add "�����J�n�����_�c���i" & Format$(CDate(inheritDate), "yyyy/m/d") & "�j"
        dates.Add CDate(inheritDate)
    End If
End Sub

Public Function BalanceMemoCol(ByVal ws As Worksheet) As Long
    Dim c As Long
    If ws Is Nothing Then
        BalanceMemoCol = BAL_MAX_COL
        Exit Function
    End If
    For c = BAL_FIRST_COL To BAL_MAX_COL
        If CellText(ws.Cells(BAL_LABEL_ROW, c).Value) = "���̑�" Then
            BalanceMemoCol = c
            Exit Function
        End If
    Next c
    BalanceMemoCol = BAL_MAX_COL
End Function

Public Function EffectiveRange(ByVal rng As Range) As Range
    If rng Is Nothing Then Exit Function
    On Error Resume Next
    If rng.MergeCells Then
        Set EffectiveRange = rng.MergeArea
    Else
        Set EffectiveRange = rng
    End If
    On Error GoTo 0
End Function

Public Sub ApplyValidationInputOnly(ByVal rng As Range, ByVal imeMode As Long)
    Dim target As Range
    If rng Is Nothing Then Exit Sub
    Set target = EffectiveRange(rng)
    If target Is Nothing Then Set target = rng
    On Error Resume Next
    target.Validation.Delete
    target.Validation.Add Type:=xlValidateInputOnly
    target.Validation.IgnoreBlank = True
    target.Validation.IMEMode = imeMode
    On Error GoTo 0
End Sub

Public Sub ApplyValidationList(ByVal rng As Range, ByVal listName As String, ByVal imeMode As Long, Optional ByVal allowFreeText As Boolean = True)
    Dim target As Range
    If rng Is Nothing Then Exit Sub
    Set target = EffectiveRange(rng)
    If target Is Nothing Then Set target = rng
    On Error Resume Next
    target.Validation.Delete
    target.Validation.Add Type:=xlValidateList, AlertStyle:=xlValidAlertStop, Operator:=xlBetween, Formula1:="=" & listName
    target.Validation.IgnoreBlank = True
    target.Validation.InCellDropdown = True
    target.Validation.ShowError = Not allowFreeText
    target.Validation.IMEMode = imeMode
    On Error GoTo 0
End Sub

Public Sub UnlockRange(ByVal rng As Range)
    Dim target As Range
    If rng Is Nothing Then Exit Sub
    Set target = EffectiveRange(rng)
    If target Is Nothing Then Set target = rng
    On Error Resume Next
    target.Locked = False
    On Error GoTo 0
End Sub

Public Sub MergeAndFormat(ByVal rng As Range, ByVal valueText As String, Optional ByVal mergeCells As Boolean = True)
    If rng Is Nothing Then Exit Sub
    On Error Resume Next
    rng.UnMerge
    If mergeCells Then rng.Merge
    rng.Value = valueText
    rng.WrapText = True
    rng.VerticalAlignment = xlCenter
    On Error GoTo 0
End Sub


Public Sub ClearEffectiveContents(ByVal rng As Range)
    Dim target As Range
    If rng Is Nothing Then Exit Sub
    Set target = EffectiveRange(rng)
    If target Is Nothing Then Set target = rng
    On Error Resume Next
    target.ClearContents
    On Error GoTo 0
End Sub

Public Sub AutoFitSheetSmart(ByVal ws As Worksheet, Optional ByVal columnsAddress As String = "", Optional ByVal minWidth As Double = 6, Optional ByVal maxWidth As Double = 34)
    Dim rngCols As Range
    Dim c As Range
    Dim r As Range
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    If Len(columnsAddress) > 0 Then
        Set rngCols = ws.Columns(columnsAddress)
    ElseIf Not ws.UsedRange Is Nothing Then
        Set rngCols = ws.UsedRange.Columns
    End If
    If Not rngCols Is Nothing Then
        rngCols.AutoFit
        For Each c In rngCols.Columns
            If c.ColumnWidth < minWidth Then c.ColumnWidth = minWidth
            If c.ColumnWidth > maxWidth Then c.ColumnWidth = maxWidth
        Next c
    End If
    ws.UsedRange.Rows.AutoFit
    For Each r In ws.UsedRange.Rows
        If r.RowHeight < 18 Then r.RowHeight = 18
        If r.RowHeight > 72 Then r.RowHeight = 72
    Next r
    On Error GoTo 0
End Sub

Public Sub PolishInputLayout(Optional ByVal ws As Worksheet = Nothing)
    If ws Is Nothing Then
        If Not SheetExists(SH_INPUT) Then Exit Sub
        Set ws = GetSheet(SH_INPUT)
    End If
    ApplyInputColumnWidths ws
End Sub
Private Sub ApplyInputColumnWidths(ByVal ws As Worksheet)
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    '���͗�͍Œ�13���m�ہB�K�v�ȗ񂾂��L���āA�܂�Ԃ��ɂ�錩�Â炳��h���B
    ws.Columns("A:A").ColumnWidth = 2
    ws.Columns("B:I").ColumnWidth = 13.5
    ws.Columns("J:J").ColumnWidth = 17
    ws.Columns("K:K").ColumnWidth = 21
    ws.Columns("L:L").ColumnWidth = 2
    ws.Columns("M:T").ColumnWidth = 13.2
    ws.Columns("U:U").ColumnWidth = 2

    ws.Rows("1:1").RowHeight = 8
    ws.Rows("2:14").RowHeight = 21
    ws.Rows(2).RowHeight = 30
    ws.Rows(4).RowHeight = 23
    ws.Rows(5).RowHeight = 24
    ws.Rows(6).RowHeight = 24
    ws.Rows(8).RowHeight = 23
    ws.Rows(BAL_LABEL_ROW).RowHeight = 25
    ws.Rows(BAL_VALUE_ROW).RowHeight = 24
    ws.Rows(BAL_DATE_ROW).RowHeight = 18
    ws.Rows(12).RowHeight = 25
    ws.Rows(TX_HEADER_ROW).RowHeight = 23
    ws.Rows(TX_FIRST_ROW & ":" & TX_LAST_ROW).RowHeight = 21

    ws.Range("B2:K12").WrapText = True
    ws.Range(ws.Cells(BAL_LABEL_ROW, BAL_FIRST_COL), ws.Cells(BAL_LABEL_ROW, BAL_MAX_COL)).WrapText = False
    ws.Range(ws.Cells(BAL_LABEL_ROW, BAL_FIRST_COL), ws.Cells(BAL_LABEL_ROW, BAL_MAX_COL)).ShrinkToFit = True
    ws.Range("M2:T14").WrapText = False
    ws.Range("B15:K" & TX_LAST_ROW).WrapText = False
    On Error GoTo 0
End Sub
Public Sub AutoFitInputSheetSmart(ByVal ws As Worksheet)
    Dim c As Long
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    '���o���Ɩ��ׂ���xAutoFit���A���̌�Ŏ�����K�v�ȍŒᕝ��ۏ؂���B
    ws.Range("B14:K" & TX_LAST_ROW).Columns.AutoFit
    For c = 2 To 11
        If ws.Columns(c).ColumnWidth < 13 Then ws.Columns(c).ColumnWidth = 13
        If c = COL_TX_TEKIYO And ws.Columns(c).ColumnWidth < 17 Then ws.Columns(c).ColumnWidth = 17
        If c = COL_TX_OTHER And ws.Columns(c).ColumnWidth < 21 Then ws.Columns(c).ColumnWidth = 21
        If ws.Columns(c).ColumnWidth > 28 Then ws.Columns(c).ColumnWidth = 28
    Next c
    ws.UsedRange.Rows.AutoFit
    ApplyInputColumnWidths ws
    BuildOperationPanel ws
    BuildInputHelpCards ws
    On Error GoTo 0
End Sub
Public Sub AutoFitToolLayout()
    Dim ws As Worksheet
    If Not RequireToolReady() Then Exit Sub
    On Error GoTo EH
    AppBegin "�\���𐮂��Ă��܂�..."
    Set ws = GetSheet(SH_INPUT)
    ws.Unprotect Password:=TOOL_PASSWORD
    AutoFitInputSheetSmart ws
    If SheetExists(SH_OUTPUT_TX) Then AutoFitSheetSmart GetSheet(SH_OUTPUT_TX), "A:M", 8, 34
    If SheetExists(SH_OUTPUT_BAL) Then AutoFitSheetSmart GetSheet(SH_OUTPUT_BAL), "A:Z", 8, 34
    If SheetExists(SH_WORK_TX) Then AutoFitSheetSmart GetSheet(SH_WORK_TX), "A:M", 8, 34
    If SheetExists(SH_WORK_BAL) Then AutoFitSheetSmart GetSheet(SH_WORK_BAL), "A:K", 8, 34
    If SheetExists(SH_SHOP_TARGET) Then AutoFitSheetSmart GetSheet(SH_SHOP_TARGET), "A:K", 8, 45
    If SheetExists(SH_OUTPUT_TX_CONVERTED) Then AutoFitSheetSmart GetSheet(SH_OUTPUT_TX_CONVERTED), "A:M", 8, 34
    ProtectInputSheet
    EnableInputKeys
    AppEnd
    MsgBox "�\���𐮂��܂����B���͗�͍Œᕝ��ۂ��A�c�����o�����ǂ߂�悤�ɒ������Ă��܂��B", vbInformation
    Exit Sub
EH:
    ProtectInputSheet
    AppEnd
    MsgBox "�\���������ɃG���[���������܂����B" & vbCrLf & "Err " & Err.Number & ": " & Err.Description, vbExclamation
End Sub

Public Sub RestoreAllTransactionRowStyles(Optional ByVal ws As Worksheet = Nothing)
    Dim r As Long
    If ws Is Nothing Then
        If Not SheetExists(SH_INPUT) Then Exit Sub
        Set ws = GetSheet(SH_INPUT)
    End If
    On Error Resume Next
    For r = TX_FIRST_ROW To TX_LAST_ROW
        With ws.Range(ws.Cells(r, COL_TX_YEAR), ws.Cells(r, COL_TX_OTHER))
            If (r - TX_FIRST_ROW) Mod 2 = 0 Then
                .Interior.Color = RGB(255, 255, 255)
            Else
                .Interior.Color = RGB(248, 250, 252)
            End If
            .Font.Color = RGB(15, 23, 42)
            .Borders.LineStyle = xlContinuous
            .Borders.Color = RGB(226, 232, 240)
        End With
    Next r
    On Error GoTo 0
End Sub
Public Sub AddCheck(ByVal levelText As String, ByVal sourceText As String, ByVal messageText As String)
    Dim ws As Worksheet
    Dim r As Long
    On Error Resume Next
    Set ws = GetOrCreateSheet(SH_CHECK, False)
    If ws Is Nothing Then Exit Sub
    If Len(CellText(ws.Range("A1").Value)) = 0 Then SetRowValues ws.Range("A1"), Array("�敪", "������", "���e", "�L�^����")
    r = ws.Cells(ws.Rows.Count, 1).End(xlUp).Row + 1
    If r < 2 Then r = 2
    ws.Cells(r, 1).Value = levelText
    ws.Cells(r, 2).Value = sourceText
    ws.Cells(r, 3).Value = messageText
    ws.Cells(r, 4).Value = Now
    On Error GoTo 0
End Sub

Public Sub SafeSelectCell(ByVal ws As Worksheet, ByVal addressText As String)
    On Error Resume Next
    If ws Is Nothing Then Exit Sub
    ThisWorkbook.Activate
    ws.Activate
    ws.Range(addressText).Select
    On Error GoTo 0
End Sub

Public Sub SafeFreezeInput()
    Dim ws As Worksheet
    Dim win As Window
    On Error Resume Next
    Set ws = ThisWorkbook.Worksheets(SH_INPUT)
    If ws Is Nothing Then Exit Sub
    ThisWorkbook.Activate
    ws.Activate
    Set win = Application.ActiveWindow
    If win Is Nothing Then Exit Sub
    win.FreezePanes = False
    ws.Range("B15").Select
    win.FreezePanes = True
    On Error GoTo 0
End Sub

Public Function RequireToolReady() As Boolean
    RequireToolReady = False
    If Not SheetExists(SH_INPUT) Then
        MsgBox "���̓V�[�g������܂���BSetupWorkbook �����s���Ă��������B", vbExclamation
        Exit Function
    End If
    If Not SheetExists(SH_WORK_TX) Then
        MsgBox "��ƃV�[�g������܂���BSetupWorkbook �����s���Ă��������B", vbExclamation
        Exit Function
    End If
    If Not SheetExists(SH_CONFIG) Then
        MsgBox "�ݒ�V�[�g������܂���BSetupWorkbook �����s���Ă��������B", vbExclamation
        Exit Function
    End If
    RequireToolReady = True
End Function

Public Sub HideDailySheets(Optional ByVal hideOutputs As Boolean = False)
    '���i�G��Ȃ���ƁE���V�[�g���B���A���͉�ʂ���Ƃ̒��S�ɂ���B
    On Error Resume Next
    If SheetExists(SH_INPUT) Then ThisWorkbook.Worksheets(SH_INPUT).Visible = xlSheetVisible
    HideSheetIfExists SH_CONFIG
    HideSheetIfExists SH_TEKIYO
    HideSheetIfExists SH_ACCOUNT_TYPE
    HideSheetIfExists SH_INPUT_MODE
    HideSheetIfExists SH_POST_KEEP
    HideSheetIfExists SH_POST_CLEAR
    HideSheetIfExists SH_BANK_CAND
    HideSheetIfExists SH_BRANCH_CAND
    HideSheetIfExists SH_PERSON_CAND
    HideSheetIfExists SH_WORK_TX
    HideSheetIfExists SH_WORK_BAL
    HideSheetIfExists SH_CHECK
    HideSheetIfExists SH_SETUP_LOG
    If hideOutputs Then
        HideSheetIfExists SH_OUTPUT_TX
        HideSheetIfExists SH_OUTPUT_BAL
        HideSheetIfExists SH_SHOP_TARGET
        HideSheetIfExists SH_OUTPUT_TX_CONVERTED
    End If
    On Error GoTo 0
End Sub

Public Sub HideSheetIfExists(ByVal sheetName As String)
    On Error Resume Next
    If SheetExists(sheetName) Then
        If ThisWorkbook.Worksheets(sheetName).Name <> ActiveSheet.Name Then ThisWorkbook.Worksheets(sheetName).Visible = xlSheetHidden
    End If
    On Error GoTo 0
End Sub

Public Sub ShowCandidateSheets()
    If Not RequireToolReady() Then Exit Sub
    On Error Resume Next
    ThisWorkbook.Worksheets(SH_BANK_CAND).Visible = xlSheetVisible
    ThisWorkbook.Worksheets(SH_BRANCH_CAND).Visible = xlSheetVisible
    ThisWorkbook.Worksheets(SH_PERSON_CAND).Visible = xlSheetVisible
    ThisWorkbook.Worksheets(SH_BANK_CAND).Activate
    ThisWorkbook.Worksheets(SH_BANK_CAND).Range("A2").Select
    On Error GoTo 0
End Sub

Public Sub ShowConfigSheet()
    If Not RequireToolReady() Then Exit Sub
    On Error Resume Next
    ThisWorkbook.Worksheets(SH_CONFIG).Visible = xlSheetVisible
    ThisWorkbook.Worksheets(SH_CONFIG).Activate
    ThisWorkbook.Worksheets(SH_CONFIG).Range("C4").Select
    On Error GoTo 0
End Sub

Public Sub ShowCheckSheet()
    If Not SheetExists(SH_CHECK) Then Exit Sub
    On Error Resume Next
    ThisWorkbook.Worksheets(SH_CHECK).Visible = xlSheetVisible
    ThisWorkbook.Worksheets(SH_CHECK).Activate
    On Error GoTo 0
End Sub


Public Sub ShowShopConversionTargetSheet()
    If Not SheetExists(SH_SHOP_TARGET) Then Exit Sub
    On Error Resume Next
    ThisWorkbook.Worksheets(SH_SHOP_TARGET).Visible = xlSheetVisible
    ThisWorkbook.Worksheets(SH_SHOP_TARGET).Activate
    ThisWorkbook.Worksheets(SH_SHOP_TARGET).Range("A1").Select
    On Error GoTo 0
End Sub

Public Sub ShowConvertedCashOperationSheet()
    If Not SheetExists(SH_OUTPUT_TX_CONVERTED) Then Exit Sub
    On Error Resume Next
    ThisWorkbook.Worksheets(SH_OUTPUT_TX_CONVERTED).Visible = xlSheetVisible
    ThisWorkbook.Worksheets(SH_OUTPUT_TX_CONVERTED).Activate
    ThisWorkbook.Worksheets(SH_OUTPUT_TX_CONVERTED).Range("A1").Select
    On Error GoTo 0
End Sub

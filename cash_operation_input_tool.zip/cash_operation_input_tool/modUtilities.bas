Attribute VB_Name = "modUtilities"
Option Explicit

Public Function SheetExists(ByVal sheetName As String) As Boolean
    Dim ws As Worksheet
    On Error Resume Next
    Set ws = ThisWorkbook.Worksheets(sheetName)
    SheetExists = Not ws Is Nothing
    On Error GoTo 0
End Function

Public Function GetSheet(ByVal sheetName As String) As Worksheet
    Dim ws As Worksheet
    On Error Resume Next
    Set ws = ThisWorkbook.Worksheets(sheetName)
    On Error GoTo 0
    If ws Is Nothing Then
        Err.Raise vbObjectError + 1001, "GetSheet", "�V�[�g�u" & sheetName & "�v��������܂���BSetupWorkbook�����s���Ă��������B"
    End If
    Set GetSheet = ws
End Function

Public Function GetOrCreateSheet(ByVal sheetName As String, Optional ByVal resetSheet As Boolean = False) As Worksheet
    Dim ws As Worksheet
    On Error GoTo EH
    If SheetExists(sheetName) Then
        Set ws = ThisWorkbook.Worksheets(sheetName)
    Else
        Set ws = ThisWorkbook.Worksheets.Add(After:=ThisWorkbook.Worksheets(ThisWorkbook.Worksheets.Count))
        ws.Name = sheetName
    End If
    If ws Is Nothing Then Err.Raise vbObjectError + 1002, "GetOrCreateSheet", "�V�[�g�擾�Ɏ��s���܂���: " & sheetName
    On Error Resume Next
    ws.Visible = xlSheetVisible
    On Error GoTo EH
    If resetSheet Then ResetWorksheet ws
    Set GetOrCreateSheet = ws
    Exit Function
EH:
    Err.Raise Err.Number, "GetOrCreateSheet(" & sheetName & ")", Err.Description
End Function

Public Sub ResetWorksheet(ByVal ws As Worksheet)
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    ws.Unprotect Password:=TOOL_PASSWORD
    DeleteToolShapes ws, True
    ws.Cells.UnMerge
    ws.Cells.Clear
    ws.Cells.ClearFormats
    ws.Cells.Validation.Delete
    ws.Cells.Locked = False
    On Error GoTo 0
End Sub

Public Sub DeleteToolShapes(ByVal ws As Worksheet, Optional ByVal deleteAll As Boolean = False)
    Dim i As Long
    Dim nm As String
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    For i = ws.Shapes.Count To 1 Step -1
        nm = ws.Shapes(i).Name
        If deleteAll Or Left$(nm, Len(UI_PREFIX)) = UI_PREFIX Then ws.Shapes(i).Delete
    Next i
    On Error GoTo 0
End Sub

Public Sub ResetName(ByVal nm As String, ByVal rng As Range)
    Dim refText As String
    If rng Is Nothing Then Exit Sub
    On Error Resume Next
    ThisWorkbook.Names(nm).Delete
    Err.Clear
    refText = "='" & Replace(rng.Worksheet.Name, "'", "''") & "'!" & rng.Address(True, True, xlA1, False)
    ThisWorkbook.Names.Add Name:=nm, RefersTo:=refText
    On Error GoTo 0
End Sub

Public Function MacroRef(ByVal macroName As String) As String
    '�}�`�{�^�����ʃu�b�N�̓����}�N�����E��Ȃ��悤�A���̃u�b�N�֖����I�ɕR�Â���B
    MacroRef = "'" & Replace(ThisWorkbook.Name, "'", "''") & "'!" & macroName
End Function

Public Sub SetRowValues(ByVal firstCell As Range, ByVal values As Variant)
    '1����Array��Range�֒��ڑ���������������A�������Ɋm���ɏ������ށB
    Dim i As Long
    If firstCell Is Nothing Then Exit Sub
    For i = LBound(values) To UBound(values)
        firstCell.Offset(0, i - LBound(values)).Value = values(i)
    Next i
End Sub

Public Sub CapBalanceCollections(ByRef labels As Collection, ByRef dates As Collection, ByVal maxItems As Long)
    Dim newLabels As Collection
    Dim newDates As Collection
    Dim i As Long
    If labels Is Nothing Or dates Is Nothing Then Exit Sub
    If maxItems <= 0 Then Exit Sub
    If labels.Count <= maxItems Then Exit Sub
    Set newLabels = New Collection
    Set newDates = New Collection
    For i = 1 To maxItems
        newLabels.Add labels(i)
        newDates.Add dates(i)
    Next i
    Set labels = newLabels
    Set dates = newDates
End Sub

Public Function BalanceInputLabelDisplay(ByVal labelText As String) As String
    Dim s As String
    s = CellText(labelText)
    s = Replace(s, "�����J�n�����_�c���i", "�����J�n�����_" & vbLf & "�c���i")
    s = Replace(s, "�N���E�����J�n�����_�c���i", "�N���E�����J�n�����_" & vbLf & "�c���i")
    BalanceInputLabelDisplay = s
End Function

Public Function BalanceTekiyoLabel(ByVal labelText As String) As String
    '��������\�̓E�v���p�B���t���Ɋ�������邽�߁A�E�v���ɂ͋�̓��t���o���Ȃ��B
    Dim s As String
    Dim p As Long
    s = CellText(labelText)
    s = Replace(s, vbCrLf, "")
    s = Replace(s, vbCr, "")
    s = Replace(s, vbLf, "")
    p = InStr(1, s, "�i", vbTextCompare)
    If p > 0 And InStr(1, s, "�c��", vbTextCompare) > 0 Then s = Left$(s, p - 1)
    BalanceTekiyoLabel = s
End Function


Public Sub ApplyReadablePrintSettings(ByVal ws As Worksheet, Optional ByVal titleRows As String = "")
    '������̓ǂ݂₷����D�悷�鋤�ʐݒ�B
    'FitToPagesWide=1�͉����Ɏ��߂����ɕ������k�ނ��߁A���[��Zoom=100����{�ɂ���B
    '���ɒ����ꍇ�̓y�[�W��������Ă��A�t�H���g�T�C�Y��ۂ���D�悷��B
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    With ws.PageSetup
        .Orientation = xlLandscape
        .Zoom = 100
        .FitToPagesWide = False
        .FitToPagesTall = False
        .CenterHorizontally = False
        .LeftMargin = Application.InchesToPoints(0.25)
        .RightMargin = Application.InchesToPoints(0.25)
        .TopMargin = Application.InchesToPoints(0.35)
        .BottomMargin = Application.InchesToPoints(0.35)
        If Len(titleRows) > 0 Then
            .PrintTitleRows = titleRows
        Else
            .PrintTitleRows = ""
        End If
        .CenterFooter = "&P / &N"
    End With
    On Error GoTo 0
End Sub

Public Sub FormatCashOperationOutputLayout(ByVal ws As Worksheet)
    Dim lastR As Long
    Dim rng As Range
    Dim r As Long
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    lastR = LastUsedRowInSheet(ws)
    If lastR < 1 Then lastR = 1

    Set rng = ws.Range("A1:M" & lastR)
    With rng
        .Font.Name = "Meiryo UI"
        .Font.Size = 14
        .VerticalAlignment = xlCenter
        .Borders.LineStyle = xlContinuous
        .Borders.Color = RGB(226, 232, 240)
    End With

    FormatOutputHeader ws.Range("A1:M1")
    ws.Rows(1).RowHeight = 34

    ws.Columns("A:A").ColumnWidth = 22
    ws.Columns("B:B").ColumnWidth = 22
    ws.Columns("C:C").ColumnWidth = 20
    ws.Columns("D:D").ColumnWidth = 14
    ws.Columns("E:E").ColumnWidth = 18
    ws.Columns("F:F").ColumnWidth = 15
    ws.Columns("G:G").ColumnWidth = 12
    ws.Columns("H:I").ColumnWidth = 15
    ws.Columns("J:J").ColumnWidth = 22
    ws.Columns("K:K").ColumnWidth = 12
    ws.Columns("L:L").ColumnWidth = 28
    ws.Columns("M:M").ColumnWidth = 18

    ws.Columns("A:G").HorizontalAlignment = xlCenter
    ws.Columns("J:K").HorizontalAlignment = xlCenter
    ws.Columns("H:I").HorizontalAlignment = xlRight
    ws.Columns("L:L").HorizontalAlignment = xlLeft
    ws.Columns("M:M").HorizontalAlignment = xlRight
    ws.Columns("A:M").VerticalAlignment = xlCenter
    ws.Columns("L:M").WrapText = True

    '��P�ʂ̔z�u�ݒ�̓w�b�_�[�̒����������㏑�����邽�߁A�Ō�Ƀw�b�_�[�����ēK�p����B
    FormatOutputHeader ws.Range("A1:M1")
    With ws.Range("A1:M1")
        .HorizontalAlignment = xlCenter
        .VerticalAlignment = xlCenter
        .WrapText = False
    End With

    ws.Columns("F:F").NumberFormatLocal = "yyyy/m/d"
    ws.Columns("G:G").NumberFormatLocal = "hh:mm"
    ws.Columns("H:I").NumberFormatLocal = "#,##0"
    ws.Columns("M:M").NumberFormatLocal = "#,##0"

    If lastR >= 2 Then
        ws.Rows("2:" & lastR).RowHeight = 30
        '�c���s�͓E�v���������ɂ��A�s�S�̂����₷������B
        For r = 2 To lastR
            If InStr(1, CellText(ws.Cells(r, OUT_COL_TEKIYO).Value), "�c��", vbTextCompare) > 0 Then
                ws.Cells(r, OUT_COL_TEKIYO).Value = BalanceTekiyoLabel(ws.Cells(r, OUT_COL_TEKIYO).Value)
                ws.Cells(r, OUT_COL_TEKIYO).HorizontalAlignment = xlCenter
                ws.Cells(r, OUT_COL_OTHER).HorizontalAlignment = xlRight
                ws.Rows(r).RowHeight = 30
            ElseIf CellText(ws.Cells(r, OUT_COL_TEKIYO).Value) = "�����J�n��" Then
                ws.Range("A" & r & ":M" & r).Interior.Color = RGB(254, 243, 199)
                ws.Range("A" & r & ":M" & r).Font.Color = RGB(146, 64, 14)
                ws.Range("A" & r & ":M" & r).Font.Bold = True
                ws.Cells(r, OUT_COL_DATE).HorizontalAlignment = xlCenter
                ws.Cells(r, OUT_COL_TEKIYO).HorizontalAlignment = xlCenter
                ws.Rows(r).RowHeight = 32
            End If
        Next r
    End If

    ApplyReadablePrintSettings ws, "$1:$1"
    FixUnreadableWhiteTextOnSheet ws
    On Error GoTo 0
End Sub


Public Sub FormatBalanceTransitionOutputLayout(ByVal ws As Worksheet)
    Dim lastR As Long, lastC As Long
    Dim r As Long, c As Long
    Dim fullRange As Range, rowRange As Range
    Dim isDataRow As Boolean
    Dim headerRows As Collection, headerRow As Variant
    If ws Is Nothing Then Exit Sub
    On Error GoTo SafeExit

    lastR = LastRow(ws, 1)
    lastC = LastUsedColumnInSheet(ws, lastR)
    If lastR < 1 Then Exit Sub
    If lastC < 7 Then lastC = 7
    Set headerRows = New Collection

    Set fullRange = ws.Range(ws.Cells(1, 1), ws.Cells(lastR, lastC))
    With fullRange
        .Font.Name = "Meiryo UI"
        .Font.Size = 14
        .Font.Color = RGB(30, 41, 59)
        .VerticalAlignment = xlCenter
        .Interior.Pattern = xlSolid
        .Interior.Color = RGB(255, 255, 255)
        .Borders.LineStyle = xlNone
    End With

    '�^�C�g���́A�\�{�̂ƍ�����Ȃ��悤���������ŋ�؂�B
    With ws.Range(ws.Cells(1, 1), ws.Cells(1, lastC))
        .Interior.Color = RGB(248, 250, 252)
        .Borders(xlEdgeBottom).LineStyle = xlContinuous
        .Borders(xlEdgeBottom).Color = RGB(59, 130, 246)
        .Borders(xlEdgeBottom).Weight = xlMedium
    End With
    With ws.Cells(1, 1)
        .Font.Bold = True
        .Font.Size = 18
        .Font.Color = RGB(30, 64, 175)
        .HorizontalAlignment = xlLeft
    End With
    ws.Rows(1).RowHeight = 34

    For r = 2 To lastR
        Set rowRange = ws.Range(ws.Cells(r, 1), ws.Cells(r, lastC))

        If IsBalanceTransitionPersonRow(ws, r) Then
            With rowRange
                .Interior.Color = RGB(239, 246, 255)
                .Font.Bold = True
                .Font.Color = RGB(30, 64, 175)
                .Borders(xlEdgeTop).LineStyle = xlContinuous
                .Borders(xlEdgeTop).Color = RGB(147, 197, 253)
                .Borders(xlEdgeTop).Weight = xlMedium
                .Borders(xlEdgeBottom).LineStyle = xlContinuous
                .Borders(xlEdgeBottom).Color = RGB(191, 219, 254)
                .Borders(xlEdgeBottom).Weight = xlMedium
            End With
            ws.Cells(r, 1).HorizontalAlignment = xlLeft
            If ws.Rows(r).RowHeight < 34 Then ws.Rows(r).RowHeight = 34

        ElseIf CellText(ws.Cells(r, 1).Value) = "��s��" Then
            headerRows.Add r
            With rowRange
                .Interior.Color = RGB(30, 64, 175)
                .Font.Bold = True
                .Font.Color = RGB(255, 255, 255)
                .HorizontalAlignment = xlCenter
                .VerticalAlignment = xlCenter
                .WrapText = True
                .ShrinkToFit = False
                .Borders.LineStyle = xlContinuous
                .Borders.Color = RGB(30, 64, 175)
                .Borders.Weight = xlThin
                .Borders(xlEdgeTop).Weight = xlMedium
                .Borders(xlEdgeBottom).Weight = xlMedium
            End With
            '�����J�n�����_�c���Ȃ�2�s�\���̌��o�����B��Ȃ��悤���߂ɌŒ�B
            ws.Rows(r).RowHeight = 72

        ElseIf CellText(ws.Cells(r, 1).Value) = "���v" Then
            With rowRange
                .Interior.Color = RGB(220, 252, 231)
                .Font.Bold = True
                .Font.Color = RGB(22, 101, 52)
                .Borders.LineStyle = xlContinuous
                .Borders.Color = RGB(187, 247, 208)
                .Borders.Weight = xlThin
                .Borders(xlEdgeTop).Color = RGB(34, 197, 94)
                .Borders(xlEdgeTop).Weight = xlMedium
            End With
            If ws.Rows(r).RowHeight < 32 Then ws.Rows(r).RowHeight = 32

        ElseIf CellText(ws.Cells(r, 1).Value) = "�O�N��" Then
            With rowRange
                .Interior.Color = RGB(241, 245, 249)
                .Font.Bold = True
                .Font.Color = RGB(51, 65, 85)
                .Borders.LineStyle = xlContinuous
                .Borders.Color = RGB(226, 232, 240)
                .Borders.Weight = xlThin
                .Borders(xlEdgeBottom).Color = RGB(148, 163, 184)
                .Borders(xlEdgeBottom).Weight = xlMedium
            End With
            If ws.Rows(r).RowHeight < 31 Then ws.Rows(r).RowHeight = 31

        Else
            isDataRow = False
            For c = 1 To lastC
                If HasText(ws.Cells(r, c).Value) Then isDataRow = True: Exit For
            Next c
            If isDataRow Then
                If r Mod 2 = 0 Then
                    rowRange.Interior.Color = RGB(255, 255, 255)
                Else
                    rowRange.Interior.Color = RGB(248, 250, 252)
                End If
                With rowRange.Borders
                    .LineStyle = xlContinuous
                    .Color = RGB(226, 232, 240)
                    .Weight = xlThin
                End With
                If ws.Rows(r).RowHeight < 30 Then ws.Rows(r).RowHeight = 30
            Else
                '�l���Ɛl���̊Ԃ̋󔒍s�ɂ͌r������؎c���Ȃ��B
                rowRange.Borders.LineStyle = xlNone
                rowRange.Interior.Color = RGB(255, 255, 255)
                ws.Rows(r).RowHeight = 12
            End If
        End If
    Next r

    '�񕝁E�z�u�B�������A�c���A������3�u���b�N��������悤�ɂ���B
    ws.Columns("A:A").ColumnWidth = 22
    ws.Columns("B:B").ColumnWidth = 22
    ws.Columns("C:C").ColumnWidth = 14
    ws.Columns("D:D").ColumnWidth = 18
    ws.Columns("E:F").ColumnWidth = 16
    For c = 7 To lastC - 1
        ws.Columns(c).ColumnWidth = 22
        ws.Columns(c).NumberFormatLocal = "#,##0"
        ws.Columns(c).WrapText = True
    Next c
    ws.Columns(lastC).ColumnWidth = 56

    ws.Range(ws.Cells(1, 1), ws.Cells(lastR, lastC)).VerticalAlignment = xlCenter
    ws.Range(ws.Cells(1, 1), ws.Cells(lastR, 6)).HorizontalAlignment = xlCenter
    If lastC > 7 Then ws.Range(ws.Cells(1, 7), ws.Cells(lastR, lastC - 1)).HorizontalAlignment = xlRight
    ws.Columns(lastC).HorizontalAlignment = xlLeft
    ws.Columns(lastC).WrapText = True
    ws.Columns("A:F").NumberFormatLocal = "@"
    ws.Columns("E:F").NumberFormatLocal = "yyyy/m/d"

    '�c��؂���̓V�[�g�S�̂ɂ͈����Ȃ��B
    '�e�l���u���b�N�̃w�b�_�[�s����O�N��s�܂ł����ɓK�p���A�󔒍s�ɂ͎c���Ȃ��B
    ApplyBalanceTransitionBlockBorders ws, lastR, lastC

    '���̑����̒��������؂�Ȃ��悤�A�񕝊m�ی��AutoFit�B�������傫���Ȃ肷���Ȃ��悤�����݂���B
    ws.Range(ws.Cells(2, 1), ws.Cells(lastR, lastC)).Rows.AutoFit
    For r = 2 To lastR
        If CellText(ws.Cells(r, 1).Value) = "��s��" Then
            ws.Rows(r).RowHeight = 72
        ElseIf IsBalanceTransitionPersonRow(ws, r) Then
            If ws.Rows(r).RowHeight < 34 Then ws.Rows(r).RowHeight = 34
        ElseIf CellText(ws.Cells(r, 1).Value) = "���v" Then
            If ws.Rows(r).RowHeight < 32 Then ws.Rows(r).RowHeight = 32
        ElseIf CellText(ws.Cells(r, 1).Value) = "�O�N��" Then
            If ws.Rows(r).RowHeight < 31 Then ws.Rows(r).RowHeight = 31
        ElseIf IsBalanceTransitionBlankRow(ws, r, lastC) Then
            ws.Rows(r).RowHeight = 12
            ws.Range(ws.Cells(r, 1), ws.Cells(r, lastC)).Borders.LineStyle = xlNone
        ElseIf ws.Rows(r).RowHeight < 30 Then
            ws.Rows(r).RowHeight = 30
        End If
        If ws.Rows(r).RowHeight > 130 Then ws.Rows(r).RowHeight = 130
    Next r

    ws.Cells(1, 1).HorizontalAlignment = xlLeft

    '�w�b�_�[�s�͗�z�u�EAutoFit�̌�ɍēK�p�B��P�ʐݒ�ɕ����Ȃ��悤�ɂ���B
    For Each headerRow In headerRows
        With ws.Range(ws.Cells(CLng(headerRow), 1), ws.Cells(CLng(headerRow), lastC))
            .HorizontalAlignment = xlCenter
            .VerticalAlignment = xlCenter
            .WrapText = True
            .ShrinkToFit = False
        End With
        ws.Rows(CLng(headerRow)).RowHeight = 72
    Next headerRow

    FixUnreadableWhiteTextOnSheet ws

    '�c�����ڕ\�͈�����ɕ������������Ȃ�₷�����߁A��1�y�[�W�ɖ����ɏk�����Ȃ��B
    ApplyReadablePrintSettings ws, ""

SafeExit:
    On Error GoTo 0
End Sub

Private Sub ApplyBalanceTransitionBlockBorders(ByVal ws As Worksheet, ByVal lastR As Long, ByVal lastC As Long)
    Dim headerR As Long, endR As Long, r As Long
    If ws Is Nothing Or lastR < 2 Or lastC < 7 Then Exit Sub

    r = 2
    Do While r <= lastR
        If CellText(ws.Cells(r, 1).Value) = "��s��" Then
            headerR = r
            endR = lastR
            Do While endR > headerR And IsBalanceTransitionBlankRow(ws, endR, lastC)
                endR = endR - 1
            Loop
            For endR = headerR + 1 To lastR
                If endR > headerR And (IsBalanceTransitionBlankRow(ws, endR, lastC) Or IsBalanceTransitionPersonRow(ws, endR)) Then
                    endR = endR - 1
                    Exit For
                End If
            Next endR
            If endR > lastR Then endR = lastR
            Do While endR > headerR And IsBalanceTransitionBlankRow(ws, endR, lastC)
                endR = endR - 1
            Loop

            If endR >= headerR Then
                With ws.Range(ws.Cells(headerR, 6), ws.Cells(endR, 6)).Borders(xlEdgeRight)
                    .LineStyle = xlContinuous
                    .Color = RGB(59, 130, 246)
                    .Weight = xlMedium
                End With
                If lastC >= 8 Then
                    With ws.Range(ws.Cells(headerR, lastC - 1), ws.Cells(endR, lastC - 1)).Borders(xlEdgeRight)
                        .LineStyle = xlContinuous
                        .Color = RGB(59, 130, 246)
                        .Weight = xlMedium
                    End With
                    With ws.Range(ws.Cells(headerR, 7), ws.Cells(endR, lastC - 1)).Borders(xlInsideVertical)
                        .LineStyle = xlContinuous
                        .Color = RGB(219, 234, 254)
                        .Weight = xlHairline
                    End With
                End If
            End If
            r = endR + 1
        Else
            r = r + 1
        End If
    Loop
End Sub

Private Function IsBalanceTransitionPersonRow(ByVal ws As Worksheet, ByVal r As Long) As Boolean
    Dim s As String
    s = CellText(ws.Cells(r, 1).Value)
    IsBalanceTransitionPersonRow = (Left$(s, 3) = "����:" Or Left$(s, 3) = "�����F")
End Function

Private Function IsBalanceTransitionBlankRow(ByVal ws As Worksheet, ByVal r As Long, ByVal lastC As Long) As Boolean
    Dim c As Long
    For c = 1 To lastC
        If HasText(ws.Cells(r, c).Value) Then Exit Function
    Next c
    IsBalanceTransitionBlankRow = True
End Function

Private Function LastUsedColumnInSheet(ByVal ws As Worksheet, ByVal lastR As Long) As Long
    Dim r As Long, c As Long, maxC As Long
    If ws Is Nothing Then Exit Function
    If lastR < 1 Then lastR = ws.UsedRange.Rows.Count
    maxC = 1
    For r = 1 To lastR
        c = ws.Cells(r, ws.Columns.Count).End(xlToLeft).Column
        If c > maxC Then maxC = c
    Next r
    LastUsedColumnInSheet = maxC
End Function

Public Function LastRow(ByVal ws As Worksheet, Optional ByVal colNo As Long = 1) As Long
    Dim r As Long
    If ws Is Nothing Then Exit Function
    r = ws.Cells(ws.Rows.Count, colNo).End(xlUp).Row
    If r = 1 And Len(Trim$(CStr(ws.Cells(1, colNo).Value))) = 0 Then r = 0
    LastRow = r
End Function

Public Function CellText(ByVal v As Variant) As String
    If IsError(v) Or IsNull(v) Or IsEmpty(v) Then
        CellText = ""
    Else
        CellText = Trim$(CStr(v))
    End If
End Function

Public Function HasText(ByVal v As Variant) As Boolean
    HasText = Len(CellText(v)) > 0
End Function

Public Function ToAmountOrBlank(ByVal v As Variant) As Variant
    Dim s As String
    s = Replace(CellText(v), ",", "")
    If Len(s) = 0 Then
        ToAmountOrBlank = ""
    ElseIf IsNumeric(s) Then
        ToAmountOrBlank = CDbl(s)
    Else
        ToAmountOrBlank = v
    End If
End Function

Public Function GetCfgCell(ByVal rowNo As Long) As Range
    Dim ws As Worksheet
    Set ws = GetSheet(SH_CONFIG)
    Set GetCfgCell = ws.Cells(rowNo, COL_CFG_VALUE)
End Function

Public Function GetCfgLong(ByVal rowNo As Long, ByVal defaultValue As Long) As Long
    On Error GoTo EH
    If IsNumeric(GetCfgCell(rowNo).Value) Then
        GetCfgLong = CLng(GetCfgCell(rowNo).Value)
    Else
        GetCfgLong = defaultValue
    End If
    Exit Function
EH:
    GetCfgLong = defaultValue
End Function

Public Function GetCfgDateValue(ByVal rowNo As Long) As Variant
    On Error GoTo EH
    If IsDate(GetCfgCell(rowNo).Value) Then
        GetCfgDateValue = CDate(GetCfgCell(rowNo).Value)
    Else
        GetCfgDateValue = ""
    End If
    Exit Function
EH:
    GetCfgDateValue = ""
End Function

Public Function GetInputMode() As String
    On Error GoTo EH
    GetInputMode = CellText(GetCfgCell(ROW_CFG_INPUT_MODE).Value)
    If Len(GetInputMode) = 0 Then GetInputMode = MODE_NORMAL
    Exit Function
EH:
    GetInputMode = MODE_NORMAL
End Function

Public Function GetYearInputMode() As String
    On Error GoTo EH
    GetYearInputMode = CellText(GetCfgCell(ROW_CFG_YEAR_MODE).Value)
    If Len(GetYearInputMode) = 0 Then GetYearInputMode = YEAR_MODE_WAREKI
    Exit Function
EH:
    GetYearInputMode = YEAR_MODE_WAREKI
End Function


Public Function GetPostTransferKeepPolicy() As String
    On Error GoTo EH
    GetPostTransferKeepPolicy = CellText(GetCfgCell(ROW_CFG_POST_KEEP).Value)
    If Len(GetPostTransferKeepPolicy) = 0 Then GetPostTransferKeepPolicy = KEEP_BANK_BRANCH_PERSON_TYPE
    Exit Function
EH:
    GetPostTransferKeepPolicy = KEEP_BANK_BRANCH_PERSON_TYPE
End Function

Public Function GetPostTransferClearTransaction() As Boolean
    On Error GoTo EH
    GetPostTransferClearTransaction = (CellText(GetCfgCell(ROW_CFG_POST_TX).Value) <> POST_KEEP)
    Exit Function
EH:
    GetPostTransferClearTransaction = True
End Function

Public Function GetPostTransferClearBalance() As Boolean
    On Error GoTo EH
    GetPostTransferClearBalance = (CellText(GetCfgCell(ROW_CFG_POST_BAL).Value) <> POST_KEEP)
    Exit Function
EH:
    GetPostTransferClearBalance = True
End Function

Public Function GetDisplayOption(ByVal rowNo As Long, Optional ByVal defaultShow As Boolean = True) As Boolean
    '�ݒ�V�[�g�́u�\������ / �\�����Ȃ��v�����S�ɓǂݎ��B
    '�󗓂�z��O�̒l�́A�Ɩ��ō���ɂ����悤 defaultShow ��Ԃ��B
    Dim v As String
    On Error GoTo EH
    v = CellText(GetCfgCell(rowNo).Value)
    If v = DISPLAY_ON Then
        GetDisplayOption = True
    ElseIf v = DISPLAY_OFF Then
        GetDisplayOption = False
    Else
        GetDisplayOption = defaultShow
    End If
    Exit Function
EH:
    GetDisplayOption = defaultShow
End Function

Public Function UseRelationshipDisplay() As Boolean
    UseRelationshipDisplay = GetDisplayOption(ROW_CFG_RELATIONSHIP, True)
End Function

Public Function ShowInheritanceStartRow() As Boolean
    ShowInheritanceStartRow = GetDisplayOption(ROW_CFG_SHOW_INHERITANCE_ROW, True)
End Function

Public Function ShowOpenDateRow() As Boolean
    ShowOpenDateRow = GetDisplayOption(ROW_CFG_SHOW_OPEN_DATE_ROW, True)
End Function

Public Function ShowCloseDateRow() As Boolean
    ShowCloseDateRow = GetDisplayOption(ROW_CFG_SHOW_CLOSE_DATE_ROW, True)
End Function

Public Function ShowBalanceRowsInCashOperation() As Boolean
    ShowBalanceRowsInCashOperation = GetDisplayOption(ROW_CFG_SHOW_BALANCE_ROWS, True)
End Function

Public Function DisplayPersonWithRelationship(ByVal personName As String, ByVal relationshipText As String) As String
    '�o�͂ł͗�𑝂₳���A�������̒��Łu�����i�����j�v�Ƃ��ĕ\������B
    '�ݒ�ő������\���ɂ����ꍇ�͎����݂̂�Ԃ��B
    Dim p As String, rel As String
    p = CellText(personName)
    rel = CellText(relationshipText)
    If UseRelationshipDisplay() And Len(rel) > 0 Then
        DisplayPersonWithRelationship = p & "�i" & rel & "�j"
    Else
        DisplayPersonWithRelationship = p
    End If
End Function

Public Function IsLightExcelColor(ByVal colorValue As Long) As Boolean
    '���w�i�ɔ���������鎖�̂�h�����߂̖��x����B
    Dim r As Long, g As Long, b As Long
    Dim brightness As Double
    r = colorValue Mod 256
    g = (colorValue \ 256) Mod 256
    b = (colorValue \ 65536) Mod 256
    brightness = 0.299 * r + 0.587 * g + 0.114 * b
    IsLightExcelColor = (brightness >= 210)
End Function

Public Sub FixUnreadableWhiteTextOnSheet(ByVal ws As Worksheet)
    '�W�F�w�i�{�W�F�����ɂȂ����Z�����A�ǂ݂₷���Z�F�֖߂����ʕ␳�B
    Dim rng As Range, c As Range
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    Set rng = ws.UsedRange
    If rng Is Nothing Then Exit Sub
    For Each c In rng.Cells
        If IsLightExcelColor(c.Interior.Color) And IsLightExcelColor(c.Font.Color) Then
            c.Font.Color = RGB(15, 23, 42)
        End If
    Next c
    On Error GoTo 0
End Sub

Public Function LastUsedRowInSheet(ByVal ws As Worksheet) As Long
    '���t���E�E�v�������̑����J�n���s���E����悤�A�����ł͂Ȃ��V�[�g�S�̂ōŏI�s��T���B
    Dim f As Range
    If ws Is Nothing Then Exit Function
    On Error Resume Next
    Set f = ws.Cells.Find(What:="*", LookIn:=xlFormulas, SearchOrder:=xlByRows, SearchDirection:=xlPrevious)
    If Not f Is Nothing Then LastUsedRowInSheet = f.Row
    On Error GoTo 0
End Function

Public Function IsTransactionRowBlank(ByVal ws As Worksheet, ByVal r As Long) As Boolean
    Dim c As Long
    If ws Is Nothing Then
        IsTransactionRowBlank = True
        Exit Function
    End If
    For c = COL_TX_YEAR To COL_TX_OTHER
        If HasText(ws.Cells(r, c).Value) Then
            IsTransactionRowBlank = False
            Exit Function
        End If
    Next c
    IsTransactionRowBlank = True
End Function

Public Function NormalizeYearInput(ByVal v As Variant, ByVal yearAdd As Long, ByRef ok As Boolean) As Long
    Dim s As String
    Dim y As Long
    Dim modeText As String
    ok = False
    s = NormalizeNumberText(CellText(v))
    If Len(s) = 0 Then Exit Function

    '4���ȏ�́A�ǂ̓��͕����ł�����Ƃ��Ĉ����B
    If IsNumeric(s) Then
        y = CLng(s)
        If y >= 100 Then
            If y < 1900 Or y > 9999 Then Exit Function
            NormalizeYearInput = y
            ok = True
            Exit Function
        End If
    End If

    modeText = GetYearInputMode()
    If modeText = YEAR_MODE_WESTERN2 Then
        If Not IsNumeric(s) Then Exit Function
        y = CLng(s)
        If y < 0 Or y > 99 Then Exit Function
        y = yearAdd + y
    Else
        y = ResolveWarekiYearSmart(s)
    End If

    If y < 1900 Or y > 9999 Then Exit Function
    NormalizeYearInput = y
    ok = True
End Function

Private Function NormalizeNumberText(ByVal s As String) As String
    On Error Resume Next
    s = StrConv(s, vbNarrow)
    On Error GoTo 0
    s = Replace(s, " ", "")
    s = Replace(s, "�@", "")
    s = Replace(s, "�N", "")
    NormalizeNumberText = Trim$(s)
End Function

Private Function ResolveWarekiYearSmart(ByVal s As String) As Long
    Dim y As Long
    Dim n As Long

    If ResolveExplicitEraYear(s, y) Then
        ResolveWarekiYearSmart = y
        Exit Function
    End If

    If s = "��" Then s = "1"
    If Not IsNumeric(s) Then Exit Function
    n = CLng(s)
    If n <= 0 Or n > 99 Then Exit Function

    ResolveWarekiYearSmart = BestJapaneseEraCandidate(n)
End Function

Private Function ResolveExplicitEraYear(ByVal s As String, ByRef westernYear As Long) As Boolean
    Dim era As String
    Dim n As Long
    s = UCase$(s)
    s = Replace(s, ".", "")
    s = Replace(s, "-", "")
    s = Replace(s, "�ߘa", "R")
    s = Replace(s, "����", "H")
    s = Replace(s, "���a", "S")
    If Len(s) < 2 Then Exit Function
    era = Left$(s, 1)
    If era <> "R" And era <> "H" And era <> "S" Then Exit Function
    s = Mid$(s, 2)
    If s = "��" Then s = "1"
    If Not IsNumeric(s) Then Exit Function
    n = CLng(s)
    If n <= 0 Then Exit Function

    Select Case era
        Case "R"
            If n > 99 Then Exit Function
            westernYear = 2018 + n
        Case "H"
            If n > 31 Then Exit Function
            westernYear = 1988 + n
        Case "S"
            If n > 64 Then Exit Function
            westernYear = 1925 + n
    End Select
    ResolveExplicitEraYear = (westernYear >= 1900 And westernYear <= 9999)
End Function

Private Function BestJapaneseEraCandidate(ByVal eraYear As Long) As Long
    Dim candidates(1 To 3) As Long
    Dim count As Long
    Dim i As Long
    Dim refYear As Long
    Dim bestYear As Long
    Dim bestScore As Long
    Dim score As Long

    If eraYear >= 1 And eraYear <= 99 Then
        count = count + 1
        candidates(count) = 2018 + eraYear  '�ߘa
    End If
    If eraYear >= 1 And eraYear <= 31 Then
        count = count + 1
        candidates(count) = 1988 + eraYear  '����
    End If
    If eraYear >= 1 And eraYear <= 64 Then
        count = count + 1
        candidates(count) = 1925 + eraYear  '���a
    End If

    refYear = GetYearResolutionReferenceYear()
    bestScore = 999999
    For i = 1 To count
        If candidates(i) >= 1900 And candidates(i) <= 2100 Then
            score = Abs(candidates(i) - refYear) + JapaneseEraWindowPenalty(candidates(i))
            If score < bestScore Or (score = bestScore And candidates(i) > bestYear) Then
                bestScore = score
                bestYear = candidates(i)
            End If
        End If
    Next i
    BestJapaneseEraCandidate = bestYear
End Function

Private Function GetYearResolutionReferenceYear() As Long
    Dim inheritDate As Variant
    Dim startYear As Long
    Dim endYear As Long
    inheritDate = GetCfgDateValue(ROW_CFG_INHERITANCE_DATE)
    If IsDate(inheritDate) Then
        GetYearResolutionReferenceYear = Year(CDate(inheritDate))
        Exit Function
    End If
    startYear = GetCfgLong(ROW_CFG_BAL_START_YEAR, Year(Date) - 4)
    endYear = GetCfgLong(ROW_CFG_BAL_END_YEAR, Year(Date))
    If startYear > 0 And endYear >= startYear Then
        GetYearResolutionReferenceYear = CLng((startYear + endYear) / 2)
    Else
        GetYearResolutionReferenceYear = Year(Date)
    End If
End Function

Private Function JapaneseEraWindowPenalty(ByVal westernYear As Long) As Long
    Dim startYear As Long
    Dim endYear As Long
    startYear = GetCfgLong(ROW_CFG_BAL_START_YEAR, Year(Date) - 4)
    endYear = GetCfgLong(ROW_CFG_BAL_END_YEAR, Year(Date))
    If endYear < startYear Then endYear = startYear
    If westernYear < startYear - 5 Or westernYear > endYear + 5 Then
        JapaneseEraWindowPenalty = 1000
    Else
        JapaneseEraWindowPenalty = 0
    End If
End Function

Public Function ParseMonthDay(ByVal v As Variant, ByRef m As Long, ByRef d As Long) As Boolean
    Dim s As String
    s = CellText(v)
    ParseMonthDay = False
    If Len(s) < 3 Or Len(s) > 4 Then Exit Function
    If Not IsNumeric(s) Then Exit Function
    If Len(s) = 3 Then
        m = CLng(Left$(s, 1))
        d = CLng(Right$(s, 2))
    Else
        m = CLng(Left$(s, 2))
        d = CLng(Right$(s, 2))
    End If
    If m < 1 Or m > 12 Then Exit Function
    If d < 1 Or d > 31 Then Exit Function
    ParseMonthDay = True
End Function

Public Function ResolveInputDate(ByVal yearVal As Variant, ByVal monthVal As Variant, ByVal dayVal As Variant, _
    ByRef currentYear As Long, ByRef currentMonth As Long, ByRef currentDay As Long, _
    ByVal yearAdd As Long, ByRef ok As Boolean) As Variant

    Dim tmpYear As Long
    Dim tmpMonth As Long
    Dim tmpDay As Long
    Dim yearOK As Boolean
    Dim d As Date

    ok = False
    If HasText(yearVal) Then
        tmpYear = NormalizeYearInput(yearVal, yearAdd, yearOK)
        If Not yearOK Then Exit Function
        currentYear = tmpYear
    End If
    If HasText(monthVal) Then
        If Not IsNumeric(CellText(monthVal)) Then Exit Function
        currentMonth = CLng(CellText(monthVal))
    End If
    If HasText(dayVal) Then
        If ParseMonthDay(dayVal, tmpMonth, tmpDay) Then
            currentMonth = tmpMonth
            currentDay = tmpDay
        Else
            If Not IsNumeric(CellText(dayVal)) Then Exit Function
            currentDay = CLng(CellText(dayVal))
        End If
    End If
    If currentYear = 0 Or currentMonth = 0 Or currentDay = 0 Then Exit Function
    If currentMonth < 1 Or currentMonth > 12 Or currentDay < 1 Or currentDay > 31 Then Exit Function
    On Error GoTo InvalidDate
    d = DateSerial(currentYear, currentMonth, currentDay)
    If Year(d) <> currentYear Or Month(d) <> currentMonth Or Day(d) <> currentDay Then GoTo InvalidDate
    ResolveInputDate = d
    ok = True
    Exit Function
InvalidDate:
    ResolveInputDate = ""
End Function

Public Function NormalizeTimeInput(ByVal v As Variant, ByRef ok As Boolean) As Variant
    Dim s As String
    Dim i As Long
    Dim h As Long
    Dim m As Long
    ok = False
    s = CellText(v)
    If Len(s) = 0 Then
        NormalizeTimeInput = ""
        ok = True
        Exit Function
    End If
    If Len(s) > 4 Then
        NormalizeTimeInput = v
        Exit Function
    End If
    For i = 1 To Len(s)
        If Mid$(s, i, 1) < "0" Or Mid$(s, i, 1) > "9" Then
            NormalizeTimeInput = v
            Exit Function
        End If
    Next i
    s = Right$("0000" & s, 4)
    h = CLng(Left$(s, 2))
    m = CLng(Right$(s, 2))
    If h < 0 Or h > 23 Or m < 0 Or m > 59 Then
        NormalizeTimeInput = v
        Exit Function
    End If
    NormalizeTimeInput = TimeSerial(h, m, 0)
    ok = True
End Function

Public Function NextBranchAccountNo(ByVal accountNo As String) As String
    Dim s As String
    Dim baseNo As String
    Dim suffixText As String
    Dim p As Long
    Dim suffixNo As Long
    s = NormalizeAccountHyphen(CellText(accountNo))
    If Len(s) = 0 Then
        NextBranchAccountNo = ""
        Exit Function
    End If
    p = InStrRev(s, "-")
    If p > 0 Then
        baseNo = Left$(s, p - 1)
        suffixText = Mid$(s, p + 1)
        If Len(baseNo) > 0 And IsNumeric(suffixText) Then
            suffixNo = CLng(suffixText) + 1
            NextBranchAccountNo = baseNo & "-" & CStr(suffixNo)
            Exit Function
        End If
    End If
    NextBranchAccountNo = s & "-1"
End Function

Public Function NormalizeAccountHyphen(ByVal accountNo As String) As String
    Dim s As String
    s = Trim$(accountNo)
    s = Replace(s, "�|", "-")
    s = Replace(s, "�\", "-")
    s = Replace(s, "�[", "-")
    s = Replace(s, "�", "-")
    s = Replace(s, "�|", "-")
    NormalizeAccountHyphen = s
End Function

Public Sub BuildBalanceCollections(ByRef labels As Collection, ByRef dates As Collection)
    Dim startYear As Long
    Dim endYear As Long
    Dim inheritDate As Variant
    Dim y As Long
    Dim dYearEnd As Date
    Dim eventAdded As Boolean
    Dim labelText As String
    Set labels = New Collection
    Set dates = New Collection
    startYear = GetCfgLong(ROW_CFG_BAL_START_YEAR, Year(Date) - 4)
    endYear = GetCfgLong(ROW_CFG_BAL_END_YEAR, Year(Date))
    If endYear < startYear Then endYear = startYear
    inheritDate = GetCfgDateValue(ROW_CFG_INHERITANCE_DATE)
    For y = startYear To endYear
        dYearEnd = DateSerial(y, 12, 31)
        If IsDate(inheritDate) Then
            If Not eventAdded And CDate(inheritDate) < dYearEnd Then
                labels.Add "�����J�n�����_" & vbLf & "�c���i" & Format$(CDate(inheritDate), "yyyy/m/d") & "�j"
                dates.Add CDate(inheritDate)
                eventAdded = True
            End If
            If CDate(inheritDate) = dYearEnd Then
                labelText = CStr(y) & "�N���E�����J�n�����_" & vbLf & "�c���i" & Format$(CDate(inheritDate), "yyyy/m/d") & "�j"
                eventAdded = True
            Else
                labelText = CStr(y) & "�N���c��"
            End If
        Else
            labelText = CStr(y) & "�N���c��"
        End If
        labels.Add labelText
        dates.Add dYearEnd
    Next y
    If IsDate(inheritDate) And Not eventAdded Then
        labels.Add "�����J�n�����_" & vbLf & "�c���i" & Format$(CDate(inheritDate), "yyyy/m/d") & "�j"
        dates.Add CDate(inheritDate)
    End If
End Sub

Public Function BalanceMemoCol(ByVal ws As Worksheet) As Long
    Dim c As Long
    If ws Is Nothing Then
        BalanceMemoCol = BAL_MAX_COL
        Exit Function
    End If
    For c = BAL_FIRST_COL To BAL_MAX_COL
        If CellText(ws.Cells(BAL_LABEL_ROW, c).Value) = "���̑�" Then
            BalanceMemoCol = c
            Exit Function
        End If
    Next c
    BalanceMemoCol = BAL_MAX_COL
End Function

Public Function EffectiveRange(ByVal rng As Range) As Range
    If rng Is Nothing Then Exit Function
    On Error Resume Next
    If rng.MergeCells Then
        Set EffectiveRange = rng.MergeArea
    Else
        Set EffectiveRange = rng
    End If
    On Error GoTo 0
End Function

Public Sub ApplyValidationInputOnly(ByVal rng As Range, ByVal imeMode As Long)
    Dim target As Range
    If rng Is Nothing Then Exit Sub
    Set target = EffectiveRange(rng)
    If target Is Nothing Then Set target = rng
    On Error Resume Next
    target.Validation.Delete
    target.Validation.Add Type:=xlValidateInputOnly
    target.Validation.IgnoreBlank = True
    target.Validation.IMEMode = imeMode
    On Error GoTo 0
End Sub

Public Sub ApplyValidationList(ByVal rng As Range, ByVal listName As String, ByVal imeMode As Long, Optional ByVal allowFreeText As Boolean = True)
    Dim target As Range
    If rng Is Nothing Then Exit Sub
    Set target = EffectiveRange(rng)
    If target Is Nothing Then Set target = rng
    On Error Resume Next
    target.Validation.Delete
    target.Validation.Add Type:=xlValidateList, AlertStyle:=xlValidAlertStop, Operator:=xlBetween, Formula1:="=" & listName
    target.Validation.IgnoreBlank = True
    target.Validation.InCellDropdown = True
    target.Validation.ShowError = Not allowFreeText
    target.Validation.IMEMode = imeMode
    On Error GoTo 0
End Sub

Public Sub UnlockRange(ByVal rng As Range)
    Dim target As Range
    If rng Is Nothing Then Exit Sub
    Set target = EffectiveRange(rng)
    If target Is Nothing Then Set target = rng
    On Error Resume Next
    target.Locked = False
    On Error GoTo 0
End Sub

Public Sub MergeAndFormat(ByVal rng As Range, ByVal valueText As String, Optional ByVal mergeCells As Boolean = True)
    If rng Is Nothing Then Exit Sub
    On Error Resume Next
    rng.UnMerge
    If mergeCells Then rng.Merge
    rng.Value = valueText
    rng.WrapText = True
    rng.VerticalAlignment = xlCenter
    On Error GoTo 0
End Sub


Public Sub ClearEffectiveContents(ByVal rng As Range)
    Dim target As Range
    If rng Is Nothing Then Exit Sub
    Set target = EffectiveRange(rng)
    If target Is Nothing Then Set target = rng
    On Error Resume Next
    target.ClearContents
    On Error GoTo 0
End Sub

Public Sub AutoFitSheetSmart(ByVal ws As Worksheet, Optional ByVal columnsAddress As String = "", Optional ByVal minWidth As Double = 6, Optional ByVal maxWidth As Double = 34)
    Dim rngCols As Range
    Dim c As Range
    Dim r As Range
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    If Len(columnsAddress) > 0 Then
        Set rngCols = ws.Columns(columnsAddress)
    ElseIf Not ws.UsedRange Is Nothing Then
        Set rngCols = ws.UsedRange.Columns
    End If
    If Not rngCols Is Nothing Then
        rngCols.AutoFit
        For Each c In rngCols.Columns
            If c.ColumnWidth < minWidth Then c.ColumnWidth = minWidth
            If c.ColumnWidth > maxWidth Then c.ColumnWidth = maxWidth
        Next c
    End If
    ws.UsedRange.Rows.AutoFit
    For Each r In ws.UsedRange.Rows
        If r.RowHeight < 18 Then r.RowHeight = 18
        If r.RowHeight > 72 Then r.RowHeight = 72
    Next r
    On Error GoTo 0
End Sub

Public Sub PolishInputLayout(Optional ByVal ws As Worksheet = Nothing)
    If ws Is Nothing Then
        If Not SheetExists(SH_INPUT) Then Exit Sub
        Set ws = GetSheet(SH_INPUT)
    End If
    ApplyInputColumnWidths ws
End Sub
Private Sub ApplyInputColumnWidths(ByVal ws As Worksheet)
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    '���F���D��B���͗�͍Œ�13�ȏ�A�c�����o����2�s�\���œǂ܂���B
    ws.Columns("A:A").ColumnWidth = 2
    ws.Columns("B:I").ColumnWidth = 14.5
    ws.Columns("J:J").ColumnWidth = 18.5
    ws.Columns("K:K").ColumnWidth = 28
    ws.Columns("L:L").ColumnWidth = 2
    ws.Columns("M:T").ColumnWidth = 12.6
    ws.Columns("U:U").ColumnWidth = 2

    ws.Rows("1:1").RowHeight = 8
    ws.Rows("2:14").RowHeight = 21
    ws.Rows(2).RowHeight = 30
    ws.Rows(4).RowHeight = 23
    ws.Rows(5).RowHeight = 24
    ws.Rows(6).RowHeight = 24
    ws.Rows(8).RowHeight = 23
    ws.Rows(BAL_LABEL_ROW).RowHeight = 42
    ws.Rows(BAL_VALUE_ROW).RowHeight = 25
    ws.Rows(BAL_DATE_ROW).RowHeight = 18
    ws.Rows(12).RowHeight = 25
    ws.Rows(TX_HEADER_ROW).RowHeight = 28
    ws.Rows(TX_FIRST_ROW & ":" & TX_LAST_ROW).RowHeight = 21

    ws.Range("B2:K12").WrapText = True
    With ws.Range(ws.Cells(BAL_LABEL_ROW, BAL_FIRST_COL), ws.Cells(BAL_LABEL_ROW, BAL_MAX_COL))
        .WrapText = True
        .ShrinkToFit = False
        .Font.Size = 9
    End With
    ws.Range("M2:T14").WrapText = False
    ws.Range("B15:K" & TX_LAST_ROW).WrapText = False
    On Error GoTo 0
End Sub
Public Sub AutoFitInputSheetSmart(ByVal ws As Worksheet)
    Dim c As Long
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    '���o���Ɩ��ׂ���xAutoFit���A���̌�Ŏ�����K�v�ȍŒᕝ��ۏ؂���B
    ws.Range("B14:K" & TX_LAST_ROW).Columns.AutoFit
    For c = 2 To 11
        If ws.Columns(c).ColumnWidth < 13.2 Then ws.Columns(c).ColumnWidth = 13.2
        If c = COL_TX_TEKIYO And ws.Columns(c).ColumnWidth < 17 Then ws.Columns(c).ColumnWidth = 17
        If c = COL_TX_OTHER And ws.Columns(c).ColumnWidth < 28 Then ws.Columns(c).ColumnWidth = 28
        If ws.Columns(c).ColumnWidth > 32 Then ws.Columns(c).ColumnWidth = 32
    Next c
    ws.UsedRange.Rows.AutoFit
    ApplyInputColumnWidths ws
    BuildOperationPanel ws
    BuildInputHelpCards ws
    On Error GoTo 0
End Sub
Public Sub AutoFitToolLayout()
    '���{�^�����E���}�N�����Ƃ̌݊��p�B���̂͏��������֊񂹂�B
    RestoreToolFormatting
End Sub

Public Sub RestoreToolFormatting()
    Dim ws As Worksheet
    If Not RequireToolReady() Then Exit Sub
    On Error GoTo EH
    AppBegin "�����𕜋����Ă��܂�..."

    If SheetExists(SH_INPUT) Then
        Set ws = GetSheet(SH_INPUT)
        ws.Unprotect Password:=TOOL_PASSWORD
        PolishInputLayout ws
        RestoreAllTransactionRowStyles ws
        BuildOperationPanel ws
        BuildInputHelpCards ws
        ApplyInputSettings False
    End If

    If SheetExists(SH_OUTPUT_TX) Then FormatCashOperationOutputLayout GetSheet(SH_OUTPUT_TX)
    If SheetExists(SH_OUTPUT_TX_CONVERTED) Then FormatCashOperationOutputLayout GetSheet(SH_OUTPUT_TX_CONVERTED)
    If SheetExists(SH_SHOP_TARGET) Then FormatShopConversionTargetSheet GetSheet(SH_SHOP_TARGET)
    If SheetExists(SH_OUTPUT_BAL) Then FormatBalanceTransitionOutputLayout GetSheet(SH_OUTPUT_BAL)
    If SheetExists(SH_WORK_TX) Then FormatWorkTx
    If SheetExists(SH_WORK_BAL) Then FormatWorkBal

    If SheetExists(SH_INPUT) Then FixUnreadableWhiteTextOnSheet GetSheet(SH_INPUT)
    If SheetExists(SH_OUTPUT_TX) Then FixUnreadableWhiteTextOnSheet GetSheet(SH_OUTPUT_TX)
    If SheetExists(SH_OUTPUT_TX_CONVERTED) Then FixUnreadableWhiteTextOnSheet GetSheet(SH_OUTPUT_TX_CONVERTED)
    If SheetExists(SH_SHOP_TARGET) Then FixUnreadableWhiteTextOnSheet GetSheet(SH_SHOP_TARGET)
    If SheetExists(SH_OUTPUT_BAL) Then FixUnreadableWhiteTextOnSheet GetSheet(SH_OUTPUT_BAL)

    ProtectInputSheet
    EnableInputKeys
    AppEnd
    MsgBox "�����𕜋����܂����B���͗��A�{�^���A��������\�A�戵�X�ϊ��Ώۂ̌����ڂ𐮂������Ă��܂��B", vbInformation
    Exit Sub
EH:
    ProtectInputSheet
    EnableInputKeys
    AppEnd
    MsgBox "�����������ɃG���[���������܂����B" & vbCrLf & "Err " & Err.Number & ": " & Err.Description, vbExclamation
End Sub

Public Sub RestoreAllTransactionRowStyles(Optional ByVal ws As Worksheet = Nothing)
    Dim r As Long
    If ws Is Nothing Then
        If Not SheetExists(SH_INPUT) Then Exit Sub
        Set ws = GetSheet(SH_INPUT)
    End If
    On Error Resume Next
    For r = TX_FIRST_ROW To TX_LAST_ROW
        With ws.Range(ws.Cells(r, COL_TX_YEAR), ws.Cells(r, COL_TX_OTHER))
            If (r - TX_FIRST_ROW) Mod 2 = 0 Then
                .Interior.Color = RGB(255, 255, 255)
            Else
                .Interior.Color = RGB(248, 250, 252)
            End If
            .Font.Color = RGB(15, 23, 42)
            .Borders.LineStyle = xlContinuous
            .Borders.Color = RGB(226, 232, 240)
        End With
    Next r
    On Error GoTo 0
End Sub
Public Sub AddCheck(ByVal levelText As String, ByVal sourceText As String, ByVal messageText As String)
    Dim ws As Worksheet
    Dim r As Long
    On Error Resume Next
    Set ws = GetOrCreateSheet(SH_CHECK, False)
    If ws Is Nothing Then Exit Sub
    If Len(CellText(ws.Range("A1").Value)) = 0 Then SetRowValues ws.Range("A1"), Array("�敪", "������", "���e", "�L�^����")
    r = ws.Cells(ws.Rows.Count, 1).End(xlUp).Row + 1
    If r < 2 Then r = 2
    ws.Cells(r, 1).Value = levelText
    ws.Cells(r, 2).Value = sourceText
    ws.Cells(r, 3).Value = messageText
    ws.Cells(r, 4).Value = Now
    On Error GoTo 0
End Sub

Public Sub SafeSelectCell(ByVal ws As Worksheet, ByVal addressText As String)
    On Error Resume Next
    If ws Is Nothing Then Exit Sub
    ThisWorkbook.Activate
    ws.Activate
    ws.Range(addressText).Select
    On Error GoTo 0
End Sub

Public Sub SafeFreezeOutputHeader(ByVal ws As Worksheet)
    Dim prevSheet As Worksheet
    Dim win As Window
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    Set prevSheet = ActiveSheet
    If ws.Visible <> xlSheetVisible Then ws.Visible = xlSheetVisible
    ThisWorkbook.Activate
    ws.Activate
    Set win = Application.ActiveWindow
    If Not win Is Nothing Then
        win.FreezePanes = False
        win.SplitColumn = 0
        win.SplitRow = 0
        ws.Range("A2").Select
        win.FreezePanes = True
    End If
    If Not prevSheet Is Nothing Then prevSheet.Activate
    On Error GoTo 0
End Sub

Public Sub SafeFreezeInput()
    Dim ws As Worksheet
    Dim win As Window
    On Error Resume Next
    Set ws = ThisWorkbook.Worksheets(SH_INPUT)
    If ws Is Nothing Then Exit Sub
    ThisWorkbook.Activate
    ws.Activate
    Set win = Application.ActiveWindow
    If win Is Nothing Then Exit Sub
    win.FreezePanes = False
    ws.Range("B15").Select
    win.FreezePanes = True
    On Error GoTo 0
End Sub

Public Function RequireToolReady() As Boolean
    RequireToolReady = False
    If Not SheetExists(SH_INPUT) Then
        MsgBox "���̓V�[�g������܂���BSetupWorkbook �����s���Ă��������B", vbExclamation
        Exit Function
    End If
    If Not SheetExists(SH_WORK_TX) Then
        MsgBox "��ƃV�[�g������܂���BSetupWorkbook �����s���Ă��������B", vbExclamation
        Exit Function
    End If
    If Not SheetExists(SH_CONFIG) Then
        MsgBox "�ݒ�V�[�g������܂���BSetupWorkbook �����s���Ă��������B", vbExclamation
        Exit Function
    End If
    RequireToolReady = True
End Function

Public Sub HideDailySheets(Optional ByVal hideOutputs As Boolean = False)
    '���i�G��Ȃ���ƁE���V�[�g���B���A���͉�ʂ���Ƃ̒��S�ɂ���B
    On Error Resume Next
    If SheetExists(SH_INPUT) Then ThisWorkbook.Worksheets(SH_INPUT).Visible = xlSheetVisible
    HideSheetIfExists SH_CONFIG
    HideSheetIfExists SH_TEKIYO
    HideSheetIfExists SH_ACCOUNT_TYPE
    HideSheetIfExists SH_INPUT_MODE
    HideSheetIfExists SH_YEAR_MODE
    HideSheetIfExists SH_DISPLAY_OPTION
    HideSheetIfExists SH_POST_KEEP
    HideSheetIfExists SH_POST_CLEAR
    HideSheetIfExists SH_BANK_CAND
    HideSheetIfExists SH_BRANCH_CAND
    HideSheetIfExists SH_PERSON_CAND
    HideSheetIfExists SH_WORK_TX
    HideSheetIfExists SH_WORK_BAL
    HideSheetIfExists SH_CHECK
    HideSheetIfExists SH_SETUP_LOG
    If hideOutputs Then
        HideSheetIfExists SH_OUTPUT_TX
        HideSheetIfExists SH_OUTPUT_BAL
        HideSheetIfExists SH_SHOP_TARGET
        HideSheetIfExists SH_OUTPUT_TX_CONVERTED
    End If
    On Error GoTo 0
End Sub

Public Sub HideSheetIfExists(ByVal sheetName As String)
    On Error Resume Next
    If SheetExists(sheetName) Then
        If ThisWorkbook.Worksheets(sheetName).Name <> ActiveSheet.Name Then ThisWorkbook.Worksheets(sheetName).Visible = xlSheetHidden
    End If
    On Error GoTo 0
End Sub

Public Sub ShowCandidateSheets()
    If Not RequireToolReady() Then Exit Sub
    On Error Resume Next
    ThisWorkbook.Worksheets(SH_BANK_CAND).Visible = xlSheetVisible
    ThisWorkbook.Worksheets(SH_BRANCH_CAND).Visible = xlSheetVisible
    ThisWorkbook.Worksheets(SH_PERSON_CAND).Visible = xlSheetVisible
    ThisWorkbook.Worksheets(SH_BANK_CAND).Activate
    ThisWorkbook.Worksheets(SH_BANK_CAND).Range("A2").Select
    On Error GoTo 0
End Sub

Public Sub ShowConfigSheet()
    If Not RequireToolReady() Then Exit Sub
    On Error Resume Next
    ThisWorkbook.Worksheets(SH_CONFIG).Visible = xlSheetVisible
    ThisWorkbook.Worksheets(SH_CONFIG).Activate
    ThisWorkbook.Worksheets(SH_CONFIG).Range("C4").Select
    On Error GoTo 0
End Sub

Public Sub ShowInputSheet()
    '�戵�X�ϊ��Ώۂ�o�̓V�[�g����A���͍�Ƃ̒��S��ʂ֖߂邽�߂̓����B
    If Not SheetExists(SH_INPUT) Then Exit Sub
    On Error Resume Next
    ThisWorkbook.Worksheets(SH_INPUT).Visible = xlSheetVisible
    ThisWorkbook.Worksheets(SH_INPUT).Activate
    ProtectInputSheet
    EnableInputKeys
    ThisWorkbook.Worksheets(SH_INPUT).Range("C5").Select
    On Error GoTo 0
End Sub

Public Sub ShowCheckSheet()
    If Not SheetExists(SH_CHECK) Then Exit Sub
    On Error Resume Next
    ThisWorkbook.Worksheets(SH_CHECK).Visible = xlSheetVisible
    ThisWorkbook.Worksheets(SH_CHECK).Activate
    On Error GoTo 0
End Sub


Public Sub ShowShopConversionTargetSheet()
    If Not SheetExists(SH_SHOP_TARGET) Then Exit Sub
    On Error Resume Next
    ThisWorkbook.Worksheets(SH_SHOP_TARGET).Visible = xlSheetVisible
    ThisWorkbook.Worksheets(SH_SHOP_TARGET).Activate
    ThisWorkbook.Worksheets(SH_SHOP_TARGET).Range("A1").Select
    On Error GoTo 0
End Sub

Public Sub ShowConvertedCashOperationSheet()
    If Not SheetExists(SH_OUTPUT_TX_CONVERTED) Then Exit Sub
    On Error Resume Next
    ThisWorkbook.Worksheets(SH_OUTPUT_TX_CONVERTED).Visible = xlSheetVisible
    ThisWorkbook.Worksheets(SH_OUTPUT_TX_CONVERTED).Activate
    ThisWorkbook.Worksheets(SH_OUTPUT_TX_CONVERTED).Range("A1").Select
    On Error GoTo 0
End Sub

Attribute VB_Name = "modTransfer"
Option Explicit

Public Sub TransferCurrentAccount()
    TransferCurrentAccountCore ""
End Sub

Public Sub TransferCurrentAccountKeepBankBranch()
    TransferCurrentAccountCore KEEP_BANK_BRANCH
End Sub

Public Sub TransferCurrentAccountNextBranch()
    TransferCurrentAccountCore KEEP_BANK_BRANCH_PERSON_TYPE, True
End Sub

Private Sub TransferCurrentAccountCore(Optional ByVal keepOverride As String = "", Optional ByVal nextBranchAfter As Boolean = False)
    Dim wsIn As Worksheet, wsTx As Worksheet, wsBal As Worksheet
    Dim bankName As String, branchName As String, personName As String, accType As String, accNo As String
    Dim openDate As Variant, closeDate As Variant
    Dim yAdd As Long, currentYear As Long, currentMonth As Long, currentDay As Long
    Dim r As Long, outRow As Long, txCount As Long, warnCount As Long
    Dim txDate As Variant, txTime As Variant, dateOK As Boolean, timeOK As Boolean
    Dim tekiyo As String, prevTekiyo As String
    Dim cleanupText As String
    Dim nextAccNo As String
    If Not RequireToolReady() Then Exit Sub
    On Error GoTo EH
    AppBegin "�����]�L��..."
    Set wsIn = GetSheet(SH_INPUT)
    Set wsTx = GetSheet(SH_WORK_TX)
    Set wsBal = GetSheet(SH_WORK_BAL)
    bankName = CellText(wsIn.Range(CELL_BANK).Value)
    branchName = CellText(wsIn.Range(CELL_BRANCH).Value)
    personName = CellText(wsIn.Range(CELL_PERSON).Value)
    accType = CellText(wsIn.Range(CELL_ACCOUNT_TYPE).Value)
    accNo = CellText(wsIn.Range(CELL_ACCOUNT_NO).Value)
    openDate = wsIn.Range(CELL_OPEN_DATE).Value
    closeDate = wsIn.Range(CELL_CLOSE_DATE).Value
    nextAccNo = NextBranchAccountNo(accNo)
    yAdd = GetCfgLong(ROW_CFG_YEAR_ADD, 2000)
    If Len(bankName & branchName & personName & accType & accNo) = 0 Then
        AppEnd
        MsgBox "������񂪋�ł��B", vbExclamation
        Exit Sub
    End If
    UpdateAccountCandidates bankName, branchName, personName
    AppendAccountEvent wsTx, bankName, branchName, personName, accType, accNo, openDate, "�����J�ݓ�"
    AppendAccountEvent wsTx, bankName, branchName, personName, accType, accNo, closeDate, "��������"
    AppendBalances wsIn, wsTx, wsBal, bankName, branchName, personName, accType, accNo, openDate, closeDate
    For r = TX_FIRST_ROW To TX_LAST_ROW
        If Not IsTransactionRowBlank(wsIn, r) Then
            txDate = ResolveInputDate(wsIn.Cells(r, COL_TX_YEAR).Value, wsIn.Cells(r, COL_TX_MONTH).Value, wsIn.Cells(r, COL_TX_DAY).Value, currentYear, currentMonth, currentDay, yAdd, dateOK)
            If Not dateOK Then AddCheck "�m�F", "����!" & CStr(r) & "�s", "���t�ɕϊ��ł��܂���B": warnCount = warnCount + 1
            txTime = NormalizeTimeInput(wsIn.Cells(r, COL_TX_TIME).Value, timeOK)
            If Not timeOK Then AddCheck "�m�F", "����!" & CStr(r) & "�s", "�����ɕϊ��ł��܂���: " & CellText(wsIn.Cells(r, COL_TX_TIME).Value): warnCount = warnCount + 1
            tekiyo = CellText(wsIn.Cells(r, COL_TX_TEKIYO).Value)
            If tekiyo = "����" Then tekiyo = prevTekiyo
            If Len(tekiyo) > 0 Then prevTekiyo = tekiyo
            outRow = wsTx.Cells(wsTx.Rows.Count, 1).End(xlUp).Row + 1
            wsTx.Cells(outRow, OUT_COL_BANK).Value = bankName
            wsTx.Cells(outRow, OUT_COL_BRANCH).Value = branchName
            wsTx.Cells(outRow, OUT_COL_PERSON).Value = personName
            wsTx.Cells(outRow, OUT_COL_ACCOUNT_TYPE).Value = accType
            wsTx.Cells(outRow, OUT_COL_ACCOUNT_NO).Value = accNo
            wsTx.Cells(outRow, OUT_COL_DATE).Value = txDate
            wsTx.Cells(outRow, OUT_COL_TIME).Value = txTime
            wsTx.Cells(outRow, OUT_COL_WITHDRAW).Value = ToAmountOrBlank(wsIn.Cells(r, COL_TX_WITHDRAW).Value)
            wsTx.Cells(outRow, OUT_COL_DEPOSIT).Value = ToAmountOrBlank(wsIn.Cells(r, COL_TX_DEPOSIT).Value)
            wsTx.Cells(outRow, OUT_COL_SHOP).Value = CellText(wsIn.Cells(r, COL_TX_SHOP).Value)
            wsTx.Cells(outRow, OUT_COL_MACHINE).Value = CellText(wsIn.Cells(r, COL_TX_MACHINE).Value)
            wsTx.Cells(outRow, OUT_COL_TEKIYO).Value = tekiyo
            wsTx.Cells(outRow, OUT_COL_OTHER).Value = CellText(wsIn.Cells(r, COL_TX_OTHER).Value)
            txCount = txCount + 1
        End If
    Next r
    FormatWorkTx
    FormatWorkBal
    If warnCount = 0 Then
        If nextBranchAfter Then
            ApplyPostTransferCleanup KEEP_BANK_BRANCH_PERSON_TYPE
            SetNextBranchAccountNumber nextAccNo
            cleanupText = "���̎}�Ԍ�������͂��₷���悤�A�����ԍ��� " & nextAccNo & " �ɂ��܂����B"
        Else
            ApplyPostTransferCleanup keepOverride
            cleanupText = "�]�L��̓��͗��͐ݒ�ɏ]���Đ������܂����B"
        End If
    Else
        cleanupText = "�m�F���������邽�߁A���͗��͎c���Ă��܂��BC_�`�F�b�N���m�F���Ă��������B"
        ShowCheckSheet
    End If
    AppEnd
    MsgBox "���̌�����]�L���܂����B" & vbCrLf & "����s: " & txCount & "��" & vbCrLf & "�m�F����: " & warnCount & "��" & vbCrLf & cleanupText, vbInformation
    Exit Sub
EH:
    AppEnd
    MsgBox "�]�L���ɃG���[���������܂����B" & vbCrLf & "Err " & Err.Number & ": " & Err.Description, vbExclamation
End Sub

Private Sub AppendAccountEvent(ByVal wsTx As Worksheet, ByVal bankName As String, ByVal branchName As String, ByVal personName As String, ByVal accType As String, ByVal accNo As String, ByVal eventDate As Variant, ByVal eventText As String)
    Dim r As Long
    If wsTx Is Nothing Then Exit Sub
    If Not IsDate(eventDate) Then Exit Sub
    r = wsTx.Cells(wsTx.Rows.Count, 1).End(xlUp).Row + 1
    wsTx.Cells(r, OUT_COL_BANK).Value = bankName
    wsTx.Cells(r, OUT_COL_BRANCH).Value = branchName
    wsTx.Cells(r, OUT_COL_PERSON).Value = personName
    wsTx.Cells(r, OUT_COL_ACCOUNT_TYPE).Value = accType
    wsTx.Cells(r, OUT_COL_ACCOUNT_NO).Value = accNo
    wsTx.Cells(r, OUT_COL_DATE).Value = CDate(eventDate)
    wsTx.Cells(r, OUT_COL_TEKIYO).Value = eventText
End Sub

Private Sub AppendBalances(ByVal wsIn As Worksheet, ByVal wsTx As Worksheet, ByVal wsBal As Worksheet, ByVal bankName As String, ByVal branchName As String, ByVal personName As String, ByVal accType As String, ByVal accNo As String, ByVal openDate As Variant, ByVal closeDate As Variant)
    Dim memoCol As Long, c As Long, balVal As Variant, labelText As String, balDate As Variant, rTx As Long, rBal As Long, memoText As String
    If wsIn Is Nothing Or wsTx Is Nothing Or wsBal Is Nothing Then Exit Sub
    memoCol = BalanceMemoCol(wsIn)
    memoText = CellText(wsIn.Cells(BAL_VALUE_ROW, memoCol).Value)
    For c = BAL_FIRST_COL To memoCol - 1
        balVal = ToAmountOrBlank(wsIn.Cells(BAL_VALUE_ROW, c).Value)
        If HasText(balVal) Then
            labelText = BalanceTekiyoLabel(wsIn.Cells(BAL_LABEL_ROW, c).Value)
            balDate = wsIn.Cells(BAL_DATE_ROW, c).Value
            rTx = wsTx.Cells(wsTx.Rows.Count, 1).End(xlUp).Row + 1
            wsTx.Cells(rTx, OUT_COL_BANK).Value = bankName
            wsTx.Cells(rTx, OUT_COL_BRANCH).Value = branchName
            wsTx.Cells(rTx, OUT_COL_PERSON).Value = personName
            wsTx.Cells(rTx, OUT_COL_ACCOUNT_TYPE).Value = accType
            wsTx.Cells(rTx, OUT_COL_ACCOUNT_NO).Value = accNo
            wsTx.Cells(rTx, OUT_COL_DATE).Value = balDate
            wsTx.Cells(rTx, OUT_COL_TEKIYO).Value = labelText
            wsTx.Cells(rTx, OUT_COL_OTHER).Value = balVal
            rBal = wsBal.Cells(wsBal.Rows.Count, 1).End(xlUp).Row + 1
            wsBal.Cells(rBal, 1).Value = personName
            wsBal.Cells(rBal, 2).Value = bankName
            wsBal.Cells(rBal, 3).Value = branchName
            wsBal.Cells(rBal, 4).Value = accType
            wsBal.Cells(rBal, 5).Value = accNo
            wsBal.Cells(rBal, 6).Value = openDate
            wsBal.Cells(rBal, 7).Value = closeDate
            wsBal.Cells(rBal, 8).Value = balDate
            wsBal.Cells(rBal, 9).Value = labelText
            wsBal.Cells(rBal, 10).Value = balVal
            wsBal.Cells(rBal, 11).Value = memoText
        End If
    Next c
End Sub

Public Sub FormatWorkTx()
    Dim ws As Worksheet
    Set ws = GetSheet(SH_WORK_TX)
    ws.Columns("F:F").NumberFormatLocal = "yyyy/m/d"
    ws.Columns("G:G").NumberFormatLocal = "hh:mm"
    ws.Columns("H:I").NumberFormatLocal = "#,##0"
    ws.Columns("E:E").NumberFormatLocal = "@"
    ws.Columns("J:K").NumberFormatLocal = "@"
    ws.Columns("M:M").NumberFormatLocal = "#,##0"
End Sub

Public Sub FormatWorkBal()
    Dim ws As Worksheet
    Set ws = GetSheet(SH_WORK_BAL)
    ws.Columns("F:H").NumberFormatLocal = "yyyy/m/d"
    ws.Columns("J:J").NumberFormatLocal = "#,##0"
End Sub

Attribute VB_Name = "modBuildOutputs"
Option Explicit

Public Sub BuildAllOutputSheets()
    If Not RequireToolReady() Then Exit Sub
    On Error GoTo EH
    AppBegin "�ꊇ�쐬��..."
    BuildCashOperationSheetCore False
    BuildBalanceTransitionSheetCore False
    BuildShopConversionTargetSheetCore False
    If SheetExists(SH_OUTPUT_TX) Then ThisWorkbook.Worksheets(SH_OUTPUT_TX).Visible = xlSheetVisible
    If SheetExists(SH_OUTPUT_BAL) Then ThisWorkbook.Worksheets(SH_OUTPUT_BAL).Visible = xlSheetVisible
    If SheetExists(SH_SHOP_TARGET) Then ThisWorkbook.Worksheets(SH_SHOP_TARGET).Visible = xlSheetVisible
    HideDailySheets False
    If SheetExists(SH_SHOP_TARGET) Then ThisWorkbook.Worksheets(SH_SHOP_TARGET).Activate
    AppEnd
    MsgBox "��������\�A�c�����ڕ\�A�戵�X�ϊ��Ώۂ��ꊇ�쐬���܂����B" & vbCrLf & _
           "�ϊ���戵�X����͂�����A���̓V�[�g�́w�戵�X���f�x�ōŏI�ł��쐬�ł��܂��B", vbInformation
    Exit Sub
EH:
    AppEnd
    MsgBox "�ꊇ�쐬���ɃG���[���������܂����B" & vbCrLf & "Err " & Err.Number & ": " & Err.Description, vbExclamation
End Sub

Public Sub BuildCashOperationSheet()
    If Not RequireToolReady() Then Exit Sub
    On Error GoTo EH
    AppBegin "��������\�쐬��..."
    BuildCashOperationSheetCore True
    BuildShopConversionTargetSheetCore False
    AppEnd
    MsgBox "��������\���쐬���܂����B" & vbCrLf & _
           "�戵�X�󗓂̎���s�͎x�X���ŕ⊮���A�R�[�h�`���̎戵�X�͕ʃV�[�g�ɐ������܂����B", vbInformation
    Exit Sub
EH:
    AppEnd
    MsgBox "��������\�쐬���ɃG���[���������܂����B" & vbCrLf & "Err " & Err.Number & ": " & Err.Description, vbExclamation
End Sub

Public Sub BuildCashOperationSheetCore(ByVal activateAfter As Boolean)
    Dim wsSrc As Worksheet, wsOut As Worksheet
    Dim lastR As Long
    Set wsSrc = GetSheet(SH_WORK_TX)
    Set wsOut = GetSheet(SH_OUTPUT_TX)
    wsOut.Visible = xlSheetVisible
    wsOut.Cells.Clear
    wsOut.Cells.Interior.Color = RGB(255, 255, 255)
    wsOut.Cells.Font.Color = RGB(15, 23, 42)
    SetRowValues wsOut.Range("A1"), Array("��s��", "�x�X��", "����", "�Ȗ�", "�����ԍ�", "���t", "����", "�o��", "����", "�戵�X", "�@��", "�E�v��", "���̑�")
    FormatOutputHeader wsOut.Range("A1:M1")
    lastR = LastRow(wsSrc, 1)
    If lastR >= 2 Then
        wsSrc.Range("A2:M" & lastR).Copy Destination:=wsOut.Range("A2")
        SortCashOperation wsOut
        FillBlankShopWithBranch wsOut
        FormatCashOperationRows wsOut
    End If
    FormatOutputSheetBase wsOut, "A:M"
    FormatCashOperationOutputLayout wsOut
    If activateAfter Then wsOut.Activate
End Sub

Public Sub SortCashOperation(ByVal ws As Worksheet)
    Dim lastR As Long
    Dim r As Long
    If ws Is Nothing Then Exit Sub
    lastR = LastRow(ws, 1)
    If lastR < 3 Then Exit Sub

    '��������\�͎��n��œǂގ����Ȃ̂ŁA�l���E��s���ł͂Ȃ����t�����������͏��ŕ��ׂ�B
    '�����̓���������́A���́E�]�L���ꂽ���Ԃ�ێ����邽�߁A��Ɨp�̓��͏�����ꎞ�I�Ɏg���B
    On Error GoTo CleanUp
    ws.Cells(1, 14).Value = "���͏�"
    ws.Cells(1, 15).Value = "�����L�["
    For r = 2 To lastR
        ws.Cells(r, 14).Value = r - 1
        If Len(CellText(ws.Cells(r, OUT_COL_TIME).Value)) > 0 Then
            ws.Cells(r, 15).Value = CashOperationTimeSortKey(ws.Cells(r, OUT_COL_TIME).Value)
        Else
            ws.Cells(r, 15).Value = 0
        End If
    Next r

    With ws.Sort
        .SortFields.Clear
        .SortFields.Add Key:=ws.Range("F2:F" & lastR), SortOn:=xlSortOnValues, Order:=xlAscending, DataOption:=xlSortNormal
        .SortFields.Add Key:=ws.Range("O2:O" & lastR), SortOn:=xlSortOnValues, Order:=xlAscending, DataOption:=xlSortNormal
        .SortFields.Add Key:=ws.Range("N2:N" & lastR), SortOn:=xlSortOnValues, Order:=xlAscending, DataOption:=xlSortNormal
        .SetRange ws.Range("A1:O" & lastR)
        .Header = xlYes
        .Apply
    End With
CleanUp:
    On Error Resume Next
    ws.Columns("N:O").Delete
    On Error GoTo 0
End Sub

Private Function CashOperationTimeSortKey(ByVal v As Variant) As Double
    On Error GoTo EH
    If IsDate(v) Then
        CashOperationTimeSortKey = CDbl(CDate(v)) - Fix(CDbl(CDate(v)))
    ElseIf IsNumeric(v) Then
        CashOperationTimeSortKey = CDbl(v) - Fix(CDbl(v))
    Else
        CashOperationTimeSortKey = 0
    End If
    Exit Function
EH:
    CashOperationTimeSortKey = 0
End Function

Private Sub FormatCashOperationRows(ByVal ws As Worksheet)
    Dim r As Long, lastR As Long, txt As String
    If ws Is Nothing Then Exit Sub
    lastR = LastRow(ws, 1)
    For r = 2 To lastR
        txt = CellText(ws.Cells(r, OUT_COL_TEKIYO).Value)
        If InStr(txt, "�c��") > 0 Then
            ws.Range("A" & r & ":M" & r).Interior.Color = RGB(220, 252, 231)
            ws.Range("A" & r & ":M" & r).Font.Color = RGB(22, 101, 52)
        ElseIf txt = "�����J�ݓ�" Or txt = "��������" Then
            ws.Range("A" & r & ":M" & r).Interior.Color = RGB(219, 234, 254)
            ws.Range("A" & r & ":M" & r).Font.Color = RGB(30, 64, 175)
        End If
    Next r
End Sub

Public Sub BuildBalanceTransitionSheet()
    If Not RequireToolReady() Then Exit Sub
    On Error GoTo EH
    AppBegin "�c�����ڕ\�쐬��..."
    BuildBalanceTransitionSheetCore True
    AppEnd
    MsgBox "�c�����ڕ\���쐬���܂����B", vbInformation
    Exit Sub
EH:
    AppEnd
    MsgBox "�c�����ڕ\�쐬���ɃG���[���������܂����B" & vbCrLf & "Err " & Err.Number & ": " & Err.Description, vbExclamation
End Sub

Private Sub BuildBalanceTransitionSheetCore(ByVal activateAfter As Boolean)
    Dim wsSrc As Worksheet, wsOut As Worksheet
    Dim labels As Collection, dates As Collection
    Dim personKeys As Collection, accountKeys As Collection
    Dim lastR As Long, r As Long, outR As Long, i As Long
    Dim personKey As Variant, accKey As Variant
    Dim firstR As Long, found As Boolean
    Dim totals() As Double, val As Variant

    Set wsSrc = GetSheet(SH_WORK_BAL)
    Set wsOut = GetSheet(SH_OUTPUT_BAL)
    wsOut.Visible = xlSheetVisible
    wsOut.Cells.Clear
    wsOut.Cells.Interior.Color = RGB(255, 255, 255)
    wsOut.Cells.Font.Color = RGB(15, 23, 42)
    wsOut.Range("A1").Value = "�c�����ڕ\"
    wsOut.Range("A1").Font.Bold = True
    wsOut.Range("A1").Font.Size = 14
    wsOut.Range("A1").Font.Color = RGB(15, 23, 42)

    BuildBalanceCollections labels, dates
    CapBalanceCollections labels, dates, BAL_MAX_LABELS

    Set personKeys = New Collection
    Set accountKeys = New Collection
    lastR = LastRow(wsSrc, 1)
    For r = 2 To lastR
        If HasText(wsSrc.Cells(r, 1).Value) Then
            AddUniqueCollection personKeys, CellText(wsSrc.Cells(r, 1).Value)
            AddUniqueCollection accountKeys, MakeBalanceAccountKey(wsSrc, r)
        End If
    Next r

    outR = 3
    For Each personKey In personKeys
        wsOut.Cells(outR, 1).Value = "����: " & CStr(personKey)
        wsOut.Cells(outR, 1).Font.Bold = True
        wsOut.Cells(outR, 1).Font.Size = 12
        wsOut.Cells(outR, 1).Font.Color = RGB(30, 64, 175)
        outR = outR + 1

        SetRowValues wsOut.Cells(outR, 1), Array("��s��", "�x�X��", "�Ȗ�", "�����ԍ�", "�����J�ݓ�", "��������")
        For i = 1 To labels.Count
            wsOut.Cells(outR, 6 + i).Value = labels(i)
        Next i
        wsOut.Cells(outR, 7 + labels.Count).Value = "���̑�"
        FormatOutputHeader wsOut.Range(wsOut.Cells(outR, 1), wsOut.Cells(outR, 7 + labels.Count))
        ReDim totals(1 To labels.Count)
        outR = outR + 1

        For Each accKey In accountKeys
            If BalanceKeyPart(CStr(accKey), 0) = CStr(personKey) Then
                firstR = FindFirstBalanceRow(wsSrc, lastR, CStr(accKey))
                If firstR > 0 Then
                    wsOut.Cells(outR, 1).Value = wsSrc.Cells(firstR, 2).Value
                    wsOut.Cells(outR, 2).Value = wsSrc.Cells(firstR, 3).Value
                    wsOut.Cells(outR, 3).Value = wsSrc.Cells(firstR, 4).Value
                    wsOut.Cells(outR, 4).Value = wsSrc.Cells(firstR, 5).Value
                    wsOut.Cells(outR, 5).Value = wsSrc.Cells(firstR, 6).Value
                    wsOut.Cells(outR, 6).Value = wsSrc.Cells(firstR, 7).Value
                    For i = 1 To labels.Count
                        val = FindBalanceValue(wsSrc, lastR, CStr(accKey), CDate(dates(i)), found)
                        If found Then
                            wsOut.Cells(outR, 6 + i).Value = val
                            If IsNumeric(val) Then totals(i) = totals(i) + CDbl(val)
                        End If
                    Next i
                    wsOut.Cells(outR, 7 + labels.Count).Value = wsSrc.Cells(firstR, 11).Value
                    outR = outR + 1
                End If
            End If
        Next accKey

        wsOut.Cells(outR, 1).Value = "���v"
        wsOut.Cells(outR, 1).Font.Bold = True
        For i = 1 To labels.Count
            wsOut.Cells(outR, 6 + i).Value = totals(i)
        Next i
        wsOut.Range(wsOut.Cells(outR, 1), wsOut.Cells(outR, 7 + labels.Count)).Interior.Color = RGB(220, 252, 231)
        wsOut.Range(wsOut.Cells(outR, 1), wsOut.Cells(outR, 7 + labels.Count)).Font.Color = RGB(22, 101, 52)
        outR = outR + 1

        wsOut.Cells(outR, 1).Value = "�O�N��"
        For i = 2 To labels.Count
            wsOut.Cells(outR, 6 + i).Value = totals(i) - totals(i - 1)
        Next i
        wsOut.Range(wsOut.Cells(outR, 1), wsOut.Cells(outR, 7 + labels.Count)).Interior.Color = RGB(241, 245, 249)
        wsOut.Range(wsOut.Cells(outR, 1), wsOut.Cells(outR, 7 + labels.Count)).Font.Color = RGB(15, 23, 42)
        outR = outR + 2
    Next personKey

    FormatOutputSheetBase wsOut, "A:Z"
    wsOut.Cells.NumberFormatLocal = "#,##0"
    wsOut.Columns("A:F").NumberFormatLocal = "@"
    wsOut.Columns("E:F").NumberFormatLocal = "yyyy/m/d"
    FormatBalanceTransitionOutputLayout wsOut
    If activateAfter Then wsOut.Activate
End Sub

Private Sub AddUniqueCollection(ByVal col As Collection, ByVal key As String)
    On Error Resume Next
    col.Add key, key
    On Error GoTo 0
End Sub

Private Function MakeBalanceAccountKey(ByVal ws As Worksheet, ByVal r As Long) As String
    MakeBalanceAccountKey = CellText(ws.Cells(r, 1).Value) & Chr$(30) & _
                            CellText(ws.Cells(r, 2).Value) & Chr$(30) & _
                            CellText(ws.Cells(r, 3).Value) & Chr$(30) & _
                            CellText(ws.Cells(r, 4).Value) & Chr$(30) & _
                            CellText(ws.Cells(r, 5).Value)
End Function

Private Function BalanceKeyPart(ByVal keyText As String, ByVal indexNo As Long) As String
    Dim parts As Variant
    parts = Split(keyText, Chr$(30))
    If indexNo >= LBound(parts) And indexNo <= UBound(parts) Then BalanceKeyPart = CStr(parts(indexNo))
End Function

Private Function BalanceRowMatchesKey(ByVal ws As Worksheet, ByVal r As Long, ByVal keyText As String) As Boolean
    BalanceRowMatchesKey = (MakeBalanceAccountKey(ws, r) = keyText)
End Function

Private Function FindFirstBalanceRow(ByVal ws As Worksheet, ByVal lastR As Long, ByVal keyText As String) As Long
    Dim r As Long
    For r = 2 To lastR
        If BalanceRowMatchesKey(ws, r, keyText) Then FindFirstBalanceRow = r: Exit Function
    Next r
End Function

Private Function FindBalanceValue(ByVal ws As Worksheet, ByVal lastR As Long, ByVal keyText As String, ByVal targetDate As Date, ByRef found As Boolean) As Variant
    Dim r As Long
    found = False
    For r = 2 To lastR
        If BalanceRowMatchesKey(ws, r, keyText) Then
            If IsDate(ws.Cells(r, 8).Value) Then
                If Format$(CDate(ws.Cells(r, 8).Value), "yyyymmdd") = Format$(targetDate, "yyyymmdd") Then
                    FindBalanceValue = ws.Cells(r, 10).Value
                    found = True
                    Exit Function
                End If
            End If
        End If
    Next r
    FindBalanceValue = Empty
End Function

Private Sub FormatOutputSheetBase(ByVal ws As Worksheet, ByVal columnsAddress As String)
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    ws.Cells.Font.Name = "Meiryo UI"
    ws.Cells.Font.Size = 10
    AutoFitSheetSmart ws, columnsAddress, 8, 36
    ws.Rows(1).RowHeight = 24
    On Error GoTo 0
End Sub

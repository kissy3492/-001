Attribute VB_Name = "modSetupLog"
Option Explicit

Public Sub ResetSetupLog()
    Dim ws As Worksheet
    On Error Resume Next
    Set ws = GetOrCreateSheet(SH_SETUP_LOG, True)
    If ws Is Nothing Then Exit Sub
    With ws
        SetRowValues .Range("A1"), Array("����", "�敪", "�H��", "���", "�ڍ�")
        .Range("A1:E1").Font.Bold = True
        .Range("A1:E1").Interior.Color = RGB(68, 114, 196)
        .Range("A1:E1").Font.Color = vbWhite
        .Columns("A:E").ColumnWidth = 22
    End With
    On Error GoTo 0
End Sub

Public Sub LogStep(ByVal categoryText As String, ByVal stepText As String, Optional ByVal stateText As String = "", Optional ByVal detailText As String = "")
    Dim ws As Worksheet
    Dim r As Long
    On Error Resume Next
    Set ws = GetOrCreateSheet(SH_SETUP_LOG, False)
    If ws Is Nothing Then Exit Sub
    r = ws.Cells(ws.Rows.Count, 1).End(xlUp).Row + 1
    If r < 2 Then r = 2
    ws.Cells(r, 1).Value = Now
    ws.Cells(r, 2).Value = categoryText
    ws.Cells(r, 3).Value = stepText
    ws.Cells(r, 4).Value = stateText
    ws.Cells(r, 5).Value = detailText
    ws.Columns("A:E").AutoFit
    On Error GoTo 0
End Sub

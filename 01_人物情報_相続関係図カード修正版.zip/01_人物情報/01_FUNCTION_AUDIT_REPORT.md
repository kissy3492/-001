# 01 人物情報 関数・参照監査レポート

## 今回の重点

相続関係図カード生成で、被相続人カード作成時に `TextFrame2` 系プロパティの実機互換エラーがカード作成失敗へ直結していたため、カード生成経路の文字設定を安全ラッパー化しました。

## 追加・変更した主なプロシージャ

- `DrawPersonCardShape`
- `SafeClearShapeText`
- `SafeApplyShapeText`
- `SafeGetShapeText`
- `LegacyHorizontalAlignmentForShapeText`
- `LegacyVerticalAlignmentForShapeText`

## 監査結果

- Public重複候補: なし
- OnAction / AddButton / OnKey 未定義候補: なし
- TextFrame2 直書きでカード作成を落とす候補: 修正済み
- 成功通知MsgBox候補: なし
- IIf残存: なし

## 注意

実機Excelでのコンパイル・実行確認は未実施です。

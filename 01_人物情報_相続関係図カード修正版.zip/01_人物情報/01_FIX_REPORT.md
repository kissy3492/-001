# 01 人物情報 修正レポート

## 対象

- 対象ツール: 01 人物情報
- 対象ZIP: 01_人物情報(17).zip
- 実機報告: 相続関係図で、被相続人のカード作成が失敗する。チェックシートに「オブジェクトは、このプロパティまたはメソッドをサポートしていません」と出る。

## 原因整理

相続関係図のカード生成は `BuildRelationshipDiagram` から `DrawTreeCard`、さらに `DrawPersonCardShape` に進む構造です。

`DrawPersonCardShape` では、カード本体、見出し帯、氏名欄、続柄バッジ、本文欄などの複合図形を作成していますが、修正前は各図形の文字設定を `TextFrame2` に直接書いていました。

実機Excelのバージョン、図形種別、または一部プロパティの対応状況によって、以下のような `TextFrame2` 系プロパティが 438 エラーになる可能性があります。

- `TextFrame2.TextRange.Font.Fill.ForeColor.RGB`
- `TextFrame2.WordWrap`
- `TextFrame2.AutoSize`
- `TextFrame2.TextRange.ParagraphFormat.SpaceAfter`
- その他 `TextFrame2` 配下の文字・段落設定

修正前は、これらの装飾系プロパティの失敗がカード作成全体の失敗として扱われ、`DrawPersonCardShape` が `Nothing` を返し、最終的に「被相続人カードを作成できませんでした」へ進んでいました。

## 修正内容

### 1. カード作成を TextFrame2 依存から分離

`DrawPersonCardShape` 内の文字設定直書きをやめ、以下の安全ラッパーを追加しました。

- `SafeClearShapeText`
- `SafeApplyShapeText`
- `SafeGetShapeText`
- `LegacyHorizontalAlignmentForShapeText`
- `LegacyVerticalAlignmentForShapeText`

`SafeApplyShapeText` は、まず `TextFrame2` で文字設定を試し、未対応または途中でエラーになった場合は旧来の `TextFrame` にフォールバックします。

### 2. 装飾系プロパティでカード作成全体を落とさない構造へ変更

カード本体、見出し帯、アクセントバー、氏名欄、続柄バッジ、本文背景、本文欄について、図形の作成自体と任意の装飾設定を分けました。

これにより、罫線、影、印刷対象、ZOrder、TextFrame2 の一部装飾が実機で未対応でも、カード本体の作成を失敗扱いにしないようにしています。

### 3. 同種箇所の横断修正

相続関係図内で `TextFrame2` に依存していた以下も、安全ラッパー経由へ変更しました。

- その他の関係人ラベル
- 入力へ戻るボタン等の印刷除外判定用テキスト取得
- その他関係者ボックス
- 世代ラベル描画

`PolishRelationshipDiagramOutput` と `EmphasizeCardBodyLabels` に残る `TextFrame2` 参照は、既に `On Error Resume Next` 配下であり、カード作成失敗には直結しないため、今回は致命化しない確認対象として残しています。

## 静的チェック結果

- CP932デコード: OK
- Option Explicit: OK
- Sub / Function / Property 開始終了: OK
- Public重複: OK
- OnAction / AddButton / OnKey 未定義候補: OK
- IIf残存: OK
- 成功通知MsgBox候補: OK
- 相続関係図カード作成経路の TextFrame2 直書き致命化候補: OK
- BAT ASCII: OK
- VBS UTF-16LE BOM: OK
- VBS ADODB.Stream + shift_jis 読込: OK
- IMPORT_ORDER不足・余剰: OK

詳細は `01_STATIC_CHECK.json` と `01_FUNCTION_STATIC_AUDIT.json` に記録しています。

## 実機で再確認してほしいこと

1. `IMPORT_01_MODULES.bat` で一括取込する。
2. VBEでコンパイルする。
3. 被相続人のみ登録済み、または被相続人＋配偶者・子がいるデータで相続関係図を作成する。
4. チェックシートに「オブジェクトは、このプロパティまたはメソッドをサポートしていません」が出ないことを確認する。
5. 被相続人カードに、氏名、続柄、性別、生年月日、没年月日、没年齢、死亡場所、住所等が見切れず表示されるか確認する。
6. 印刷プレビューで入力へ戻るボタンが映らないことを確認する。

## 未実施

この環境では以下は未実施です。

- 実機ExcelでのVBEコンパイル
- Windows上での一括取込実行
- 実Excel操作
- 印刷プレビュー
- 実データ通し検証

完成扱いではありません。実機結果を見て次の1点を潰します。

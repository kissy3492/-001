Attribute VB_Name = "modOutputs"
Option Explicit

Private Type RelationshipDiagramPlan
    CardW As Double
    CardH As Double
    CoupleGap As Double
    BlockGap As Double
    RowGap As Double
    PageLeft As Double
    PageRight As Double
    PageWidth As Double
    PageCenter As Double
    IsLandscape As Boolean
    PersonCount As Long
    MaxDepth As Long
    MaxSiblings As Long
    RootWidth As Double
    FitWideHint As Long
End Type

Private mRelationshipDiagramHasPlan As Boolean
Private mRelationshipDiagramLandscape As Boolean
Private mRelationshipDiagramFitWideHint As Long

Public Sub BuildAllOutputs()
    On Error GoTo EH
    Dim stepText As String
    AppBegin "�l�����n�̒��[���ꊇ�쐬��..."

    stepText = "�֌W���x������"
    NormalizePersonRelationLabels
    stepText = "��\�Z���X�V"
    RefreshRepresentativeAddresses
    stepText = "���n��C�x���g����"
    GenerateEvents
    stepText = "�m�F�ꗗ�쐬"
    BuildConfirmList
    stepText = "���̓`�F�b�N"
    RunChecks
    stepText = "�����֌W�}�쐬"
    BuildRelationshipDiagram
    stepText = "�Z�����𑁌��\�쐬"
    BuildAddressHistoryTable
    stepText = "��������\�쐬"
    BuildCohabitationTable
    stepText = "���n��\�쐬"
    BuildTimelineTable
    stepText = "�l���ꗗ�쐬"
    BuildPersonList
    stepText = "�o�̓V�[�g�ی�E�\������"
    ApplyOutputUsability
    stepText = "�o�̓V�[�g�\��"
    ShowOutputSheetsCore True
CleanExit:
    AppEnd
    Exit Sub
EH:
    Dim errNum As Long, errDesc As String, errSrc As String
    errNum = Err.Number: errDesc = Err.Description: errSrc = Err.Source
    AppEnd
    RuntimeShowErrorValues "BuildAllOutputs", "�ꊇ�쐬", _
        "�����i�K: " & stepText & vbCrLf & _
        "�l���E�֌W�E�Z�������E�o�̓V�[�g�ی��Ԃ��m�F���Ă��������B", _
        "", errNum, errDesc, errSrc
End Sub

Public Sub BuildConfirmList()
    Dim ws As Worksheet, wp As Worksheet, r As Long, outR As Long, pid As String
    Set ws = ThisWorkbook.Worksheets(SH_CONFIRM)
    Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)
    ws.Range("A4:J1000").ClearContents
    outR = 4
    For r = 2 To LastRow(wp, 1)
        If Len(CStr(wp.Cells(r, P_ID).Value)) > 0 And CStr(wp.Cells(r, P_STATUS).Value) <> STATUS_CANCEL Then
            pid = CStr(wp.Cells(r, P_ID).Value)
            ws.Cells(outR, 1).Value = wp.Cells(r, P_ORDER).Value
            ws.Cells(outR, 2).Value = pid
            ws.Cells(outR, 3).Value = wp.Cells(r, P_TYPE).Value
            ws.Cells(outR, 4).Value = wp.Cells(r, P_REL_DEC).Value
            ws.Cells(outR, 5).Value = wp.Cells(r, P_DISPLAY).Value
            ws.Cells(outR, 6).Value = wp.Cells(r, P_FORMER).Value
            ws.Cells(outR, 7).Value = wp.Cells(r, P_BIRTH).Value
            ws.Cells(outR, 8).Value = wp.Cells(r, P_DEATH).Value
            ws.Cells(outR, 9).Value = GetCurrentAddressText(pid)
            ws.Cells(outR, 10).Value = wp.Cells(r, P_NOTE).Value
            outR = outR + 1
        End If
    Next r
    ws.Range("G4:H" & Application.Max(4, outR)).NumberFormatLocal = "yyyy/m/d"
    ThemeApplyCompleteBorders ws.Range("A3:K" & Application.Max(4, outR - 1)), "border"
    ws.Range("A4:J" & Application.Max(4, outR - 1)).WrapText = True
    ws.Columns("A:K").AutoFit
    CapColumnWidths ws, 1, 10, 38
End Sub

Public Sub ShowConfirmList()
    On Error GoTo EH
    AppBegin "�l���m�F�ꗗ���X�V��..."
    BuildConfirmList
    ShowOnlyInputCore False
    With ThisWorkbook.Worksheets(SH_CONFIRM)
        .Visible = xlSheetVisible
        .Activate
        .Range("A1").Select
    End With
    AppEnd
    Exit Sub
EH:
    AppEnd
    RuntimeShowError "ShowConfirmList", "�l���m�F", "�m�F�ꗗ�V�[�g�A�l���\�A�Z������\���m�F���Ă��������B"
End Sub

Public Sub RunChecks()
    Dim ws As Worksheet, wp As Worksheet, r As Long, outR As Long, decCount As Long
    Set ws = ThisWorkbook.Worksheets(SH_CHECK)
    ws.Range("A4:H1000").ClearContents
    Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)
    outR = 4
    For r = 2 To LastRow(wp, 1)
        If CStr(wp.Cells(r, P_STATUS).Value) <> STATUS_CANCEL And Len(CStr(wp.Cells(r, P_ID).Value)) > 0 Then
            If wp.Cells(r, P_TYPE).Value = MODE_DECEDENT Then decCount = decCount + 1
            If Len(CStr(wp.Cells(r, P_GIVEN).Value)) = 0 Then AddCheck ws, outR, "�G���[", "�����󗓂ł��B", wp.Cells(r, P_ID).Value, wp.Cells(r, P_DISPLAY).Value, "�l��", "�������"
            If Len(CStr(wp.Cells(r, P_REL_DEC).Value)) = 0 Then AddCheck ws, outR, "����", "�������󗓂ł��B", wp.Cells(r, P_ID).Value, wp.Cells(r, P_DISPLAY).Value, "�l��", "�������m�F"
            If Len(GetCurrentAddressText(CStr(wp.Cells(r, P_ID).Value))) = 0 Then AddCheck ws, outR, "����", "�Z�������������͂ł��B", wp.Cells(r, P_ID).Value, wp.Cells(r, P_DISPLAY).Value, "�Z��", "�Z����o�^"
        End If
    Next r
    CheckAddressHistoryIssues ws, outR
    CheckRelationIntegrityIssues ws, outR
    CheckMarriageHistoryIssues ws, outR
    CheckInputAssistIssues ws, outR
    If decCount = 0 Then AddCheck ws, outR, "�G���[", "�푊���l�����o�^�ł��B", "", "", "�푊���l", "�푊���l��o�^"
    If decCount > 1 Then AddCheck ws, outR, "�G���[", "�푊���l�������o�^����Ă��܂��B", "", "", "�푊���l", "1�l�ɐ���"
    ThemeApplyCompleteBorders ws.Range("A3:H" & Application.Max(4, outR - 1)), "border"
    ws.Columns("A:H").AutoFit
    CapColumnWidths ws, 1, 8, 42
End Sub

Private Sub CheckAddressHistoryIssues(ByVal ws As Worksheet, ByRef outR As Long)
    Dim wa As Worksheet, r As Long, pid As String
    If Not SheetExists(SH_W_ADDR_HIST, ThisWorkbook) Then Exit Sub
    Set wa = ThisWorkbook.Worksheets(SH_W_ADDR_HIST)
    For r = 2 To LastRow(wa, 1)
        If CStr(wa.Cells(r, A_STATUS).Value) <> STATUS_CANCEL And Len(CStr(wa.Cells(r, A_ID).Value)) > 0 Then
            pid = CStr(wa.Cells(r, A_PERSON_ID).Value)
            If Len(pid) = 0 Or FindPersonRow(pid) = 0 Then
                AddCheck ws, outR, "�G���[", "�Z�������̐l��ID���l���ꗗ�ɂ���܂���B", _
                    pid, "", "�Z��", "�l����I�ђ����ďZ����o�^"
            End If
            If IsDate(wa.Cells(r, A_START).Value) And IsDate(wa.Cells(r, A_END).Value) Then
                If CDate(wa.Cells(r, A_START).Value) > CDate(wa.Cells(r, A_END).Value) Then
                    AddCheck ws, outR, "�G���[", "�Z���̔c���J�n�����I��������ł��B", _
                        pid, GetPersonValue(pid, P_DISPLAY), "�Z������", "�c���J�n���E�I�������C��"
                End If
            End If
        End If
    Next r
End Sub

Private Sub CheckRelationIntegrityIssues(ByVal ws As Worksheet, ByRef outR As Long)
    Dim wr As Worksheet, wp As Worksheet, r As Long
    Dim pId As String, cId As String, pRow As Long, cRow As Long
    Dim childLevel As Long, relText As String, parentId As String
    If Not SheetExists(SH_W_REL, ThisWorkbook) Or Not SheetExists(SH_W_PERSON, ThisWorkbook) Then Exit Sub
    Set wr = ThisWorkbook.Worksheets(SH_W_REL)
    Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)

    For r = 2 To LastRow(wr, 1)
        If CStr(wr.Cells(r, R_STATUS).Value) <> STATUS_CANCEL Then
            If CStr(wr.Cells(r, R_TYPE).Value) <> "�z���" Then
                If IsDate(wr.Cells(r, R_MARRIAGE).Value) Or IsDate(wr.Cells(r, R_DIVORCE).Value) Then
                    AddCheck ws, outR, "����", "�z��҈ȊO�̊֌W�s�ɍ�����/���������c���Ă��܂��B���n��ł͖������܂��B", _
                        CStr(wr.Cells(r, R_OTHER_ID).Value), "", "�֌W", "�֌W��ʂƓ��t���͈ʒu���m�F"
                End If
            End If
            If CStr(wr.Cells(r, R_TYPE).Value) = "�e�q" Then
                If Not TryResolveDiagramParentChildRelationRow(wr, r, pId, cId) Then
                    AddCheck ws, outR, "����", "�e�q�֌W�̐e�q�������m��ł��܂���B�����֌W�}�̐�����O���܂��B", _
                        CStr(wr.Cells(r, R_OTHER_ID).Value), "", "�e�q�֌W", "��l������q��o�^���������֌W�\���m�F"
                ElseIf CStr(wr.Cells(r, R_BASE_ID).Value) <> pId Or CStr(wr.Cells(r, R_OTHER_ID).Value) <> cId Then
                    AddCheck ws, outR, "����", "�e�q�֌W���������ł��B�o�^�����ł͐e���q�֐��K���ς݂ł��B", _
                        cId, GetPersonValue(cId, P_DISPLAY), "�e�q�֌W", "�����f�[�^�͎���o�^/�������ɐe���q�֏C��"
                End If
            End If
        End If
    Next r

    For r = 2 To LastRow(wp, 1)
        If CStr(wp.Cells(r, P_STATUS).Value) <> STATUS_CANCEL And CStr(wp.Cells(r, P_SHOW).Value) <> SHOW_NO Then
            relText = NormalizeDiagramRelationText(CStr(wp.Cells(r, P_REL_DEC).Value))
            childLevel = DiagramDescendantLevel(relText)
            If childLevel >= 2 Then
                parentId = InferredDiagramParentIdForChildRow(r)
                If Len(parentId) = 0 Then
                    AddCheck ws, outR, "�G���[", "���ȉ��̐l���ɐe�q���̐e�����ł��܂���B�}�ł͊֌W�v�m�F�Ƃ��ĕ������܂��B", _
                        CStr(wp.Cells(r, P_ID).Value), CStr(wp.Cells(r, P_DISPLAY).Value), "�����֌W�}", "�e�ƂȂ�l������Ɏq�Ƃ��ēo�^"
                End If
            End If
        End If
    Next r
End Sub

Private Sub CheckMarriageHistoryIssues(ByVal ws As Worksheet, ByRef outR As Long)
    Dim mh As Worksheet, r As Long, pid As String, cpId As String
    EnsureMarriageHistoryWorkSheet
    BackfillMarriageHistoryFromLegacyFacts
    Set mh = ThisWorkbook.Worksheets(SH_W_MARRIAGE_HIST)
    For r = 2 To LastRow(mh, 1)
        If CStr(mh.Cells(r, MH_STATUS).Value) <> STATUS_CANCEL And Len(CStr(mh.Cells(r, MH_ID).Value)) > 0 Then
            pid = CStr(mh.Cells(r, MH_PERSON_ID).Value)
            cpId = CStr(mh.Cells(r, MH_COUNTERPART_ID).Value)
            If Len(pid) = 0 Or FindPersonRow(pid) = 0 Then
                AddCheck ws, outR, "�G���[", "���������̐l��ID���l���ꗗ�ɂ���܂���B", _
                    pid, "", "��������", "�l����I�ђ����������s�𐮗�"
            End If
            If Len(cpId) > 0 And FindPersonRow(cpId) = 0 Then
                AddCheck ws, outR, "�G���[", "���������̑���l��ID���l���ꗗ�ɂ���܂���B", _
                    cpId, "", "��������", "����l����o�^�����������薼�݂̂֐���"
            End If
            If Not IsDate(mh.Cells(r, MH_MARRIAGE).Value) And Not IsDate(mh.Cells(r, MH_DIVORCE).Value) Then
                AddCheck ws, outR, "����", "���������ɍ������E�������̗���������܂���B���n��ɂ͏o�܂���B", _
                    pid, GetPersonValue(pid, P_DISPLAY), "��������", "��������t��������"
            End If
            If IsDate(mh.Cells(r, MH_MARRIAGE).Value) And IsDate(mh.Cells(r, MH_DIVORCE).Value) Then
                If CDate(mh.Cells(r, MH_MARRIAGE).Value) > CDate(mh.Cells(r, MH_DIVORCE).Value) Then
                    AddCheck ws, outR, "�G���[", "������������������ł��B", _
                        pid, GetPersonValue(pid, P_DISPLAY), "��������", "�������E���������C��"
                End If
            End If
        End If
    Next r
End Sub

Private Sub CheckInputAssistIssues(ByVal ws As Worksheet, ByRef outR As Long)
    Dim wi As Worksheet, wc As Worksheet
    If Not SheetExists(SH_INPUT, ThisWorkbook) Then
        AddCheck ws, outR, "�G���[", "�l�����̓V�[�g������܂���B", "", "", "���͕⏕", "SetupWorkbook�����s"
        Exit Sub
    End If
    Set wi = ThisWorkbook.Worksheets(SH_INPUT)

    If Not HasListValidationLocal(wi.Range(CELL_BASE_SELECT)) Then _
        AddCheck ws, outR, "����", "��l�����̓��͕⏕���O��Ă��܂��B", "", "", "���͕⏕", "�����܂���SetupWorkbook�����s"
    If Not HasListValidationLocal(wi.Range(CELL_SURNAME)) Then _
        AddCheck ws, outR, "����", "���ݐ��̌����͂��O��Ă��܂��B", "", "", "���͕⏕", "�����܂���SetupWorkbook�����s"
    If Not HasListValidationLocal(wi.Range(CELL_FORMER_SURNAME)) Then _
        AddCheck ws, outR, "����", "�����̌����͂��O��Ă��܂��B", "", "", "���͕⏕", "�����܂���SetupWorkbook�����s"
    If Not HasListValidationLocal(wi.Range(CELL_REL_TO_DECEDENT)) Then _
        AddCheck ws, outR, "����", "�����̌����͂��O��Ă��܂��B", "", "", "���͕⏕", "�����܂���SetupWorkbook�����s"
    If Not HasListValidationLocal(wi.Range(CELL_OCCUPATION)) Then _
        AddCheck ws, outR, "����", "�E�Ƃ̌����͂��O��Ă��܂��B", "", "", "���͕⏕", "�����܂���SetupWorkbook�����s"
    If Not HasListValidationLocal(wi.Range(CELL_ADDR_CAND)) Then _
        AddCheck ws, outR, "����", "�Z�����̓��͕⏕���O��Ă��܂��B", "", "", "���͕⏕", "�����܂���SetupWorkbook�����s"
    If Not HasListValidationLocal(wi.Range(CELL_ADDR_START_KIND)) Then _
        AddCheck ws, outR, "����", "�Z���J�n���̈����̑I��⏕���O��Ă��܂��B", "", "", "���͕⏕", "�����܂���SetupWorkbook�����s"
    If Not HasListValidationLocal(wi.Range(CELL_MARRIAGE)) Then _
        AddCheck ws, outR, "����", "�������̌����͂��O��Ă��܂��B", "", "", "���͕⏕", "�����܂���SetupWorkbook�����s"
    If Not HasListValidationLocal(wi.Range(CELL_DIVORCE)) Then _
        AddCheck ws, outR, "����", "�������̌����͂��O��Ă��܂��B", "", "", "���͕⏕", "�����܂���SetupWorkbook�����s"
    If Not HasListValidationLocal(wi.Range(CELL_ADDR_START)) Then _
        AddCheck ws, outR, "����", "�Z���J�n���̌����͂��O��Ă��܂��B", "", "", "���͕⏕", "�����܂���SetupWorkbook�����s"
    If Not HasListValidationLocal(wi.Range(CELL_ADDR_END)) Then _
        AddCheck ws, outR, "����", "�Z���I�����̌����͂��O��Ă��܂��B", "", "", "���͕⏕", "�����܂���SetupWorkbook�����s"

    If Not HasInputActionButton(wi, "ApplySelectedAddressCandidate") Then _
        AddCheck ws, outR, "�G���[", "�Z�����𔽉f����{�^����������܂���B", "", "", "���͕⏕", "�����܂���SetupWorkbook�����s"
    If Not HasInputActionButton(wi, "CopyBaseCurrentAddress") Then _
        AddCheck ws, outR, "�G���[", "��Z���R�s�[�̃{�^����������܂���B", "", "", "���͕⏕", "�����܂���SetupWorkbook�����s"
    If Not HasInputActionButton(wi, "CopyBaseAddressHistoryToCurrentOrPending") Then _
        AddCheck ws, outR, "�G���[", "��l���̏Z�������R�s�[�̃{�^����������܂���B", "", "", "���͕⏕", "�����܂���SetupWorkbook�����s"
    If Not HasInputActionButton(wi, "CopyLastAddress") Then _
        AddCheck ws, outR, "����", "�O�Z���R�s�[�̃{�^����������܂���B", "", "", "���͕⏕", "�����܂���SetupWorkbook�����s"
    If Not HasInputActionButton(wi, "MarkAddressStartConfirmed") Then _
        AddCheck ws, outR, "����", "���Z�J�n�{�^����������܂���B", "", "", "���͕⏕", "�����܂���SetupWorkbook�����s"
    If Not HasInputActionButton(wi, "MarkAddressStartObserved") Then _
        AddCheck ws, outR, "����", "�c�����{�^����������܂���B", "", "", "���͕⏕", "�����܂���SetupWorkbook�����s"
    If Not HasInputActionButton(wi, "UseBirthDateAsAddressStart") Then _
        AddCheck ws, outR, "����", "�o�����J�n�{�^����������܂���B", "", "", "���͕⏕", "�����܂���SetupWorkbook�����s"
    If Not HasInputActionButton(wi, "UseMarriageDateAsAddressStart") Then _
        AddCheck ws, outR, "����", "���������J�n�{�^����������܂���B", "", "", "���͕⏕", "�����܂���SetupWorkbook�����s"
    If Not HasInputActionButton(wi, "UseDeathDateAsAddressEnd") Then _
        AddCheck ws, outR, "����", "���S�����I���{�^����������܂���B", "", "", "���͕⏕", "�����܂���SetupWorkbook�����s"
    If Not HasInputActionButton(wi, "UseDivorceDateAsAddressEnd") Then _
        AddCheck ws, outR, "����", "���������I���{�^����������܂���B", "", "", "���͕⏕", "�����܂���SetupWorkbook�����s"
    If Not HasInputActionButton(wi, "RegisterInputPerson") Then _
        AddCheck ws, outR, "�G���[", "�o�^�E�X�V�{�^����������܂���B", "", "", "���͕⏕", "�����܂���SetupWorkbook�����s"
    If Not HasInputActionButton(wi, "AddAddressAndStartNext") Then _
        AddCheck ws, outR, "����", "�Z���ǉ������Z���{�^����������܂���B", "", "", "���͕⏕", "�����܂���SetupWorkbook�����s"

    If SheetExists(SH_W_CAND, ThisWorkbook) Then
        Set wc = ThisWorkbook.Worksheets(SH_W_CAND)
        If LastRow(wc, 8) < 2 Then _
            AddCheck ws, outR, "����", "������⃊�X�g����ł��B", "", "", "���͕⏕", "RefreshCandidates�܂���SetupWorkbook�����s"
        If LastRow(wc, 14) < 2 Then _
            AddCheck ws, outR, "����", "���Z�J�n����⃊�X�g����ł��B�o�^�ςݓ��t��������ΐ���ł��B", "", "", "���͕⏕", "�K�v�Ȃ�Z�����t�����"
    Else
        AddCheck ws, outR, "�G���[", "���Ǘ��V�[�g W_��� ������܂���B", "", "", "���͕⏕", "SetupWorkbook�����s"
    End If
End Sub

Private Function HasListValidationLocal(ByVal rng As Range) As Boolean
    On Error Resume Next
    HasListValidationLocal = (rng.Validation.Type = xlValidateList)
    If Err.Number <> 0 Then
        Err.Clear
        HasListValidationLocal = False
    End If
    On Error GoTo 0
End Function

Private Function HasInputActionButton(ByVal ws As Worksheet, ByVal macroName As String) As Boolean
    Dim shp As Shape, btn As Button, actionText As String
    On Error Resume Next
    For Each shp In ws.Shapes
        actionText = CStr(shp.OnAction)
        If Err.Number <> 0 Then Err.Clear: actionText = ""
        If InStr(1, actionText, macroName, vbTextCompare) > 0 _
                Or InStr(1, CStr(shp.AlternativeText), macroName, vbTextCompare) > 0 Then
            HasInputActionButton = True
            Exit Function
        End If
    Next shp
    For Each btn In ws.Buttons
        actionText = CStr(btn.OnAction)
        If Err.Number <> 0 Then Err.Clear: actionText = ""
        If InStr(1, actionText, macroName, vbTextCompare) > 0 Then
            HasInputActionButton = True
            Exit Function
        End If
    Next btn
    On Error GoTo 0
End Function

Private Sub AddCheck(ByVal ws As Worksheet, _
        ByRef outR As Long, _
        ByVal level As String, _
        ByVal msg As String, _
        ByVal pid As String, _
        ByVal nameText As String, _
        ByVal target As String, _
        ByVal actionText As String)
    ws.Cells(outR, 1).Value = level
    ws.Cells(outR, 2).Value = msg
    ws.Cells(outR, 3).Value = pid
    ws.Cells(outR, 4).Value = nameText
    ws.Cells(outR, 5).Value = target
    ws.Cells(outR, 6).Value = actionText
    ws.Cells(outR, 7).Value = Now
    outR = outR + 1
End Sub

Private Sub GenerateEvents()
    Dim we As Worksheet, wp As Worksheet, wr As Worksheet, wa As Worksheet, r As Long
    Dim decId As String, inhDate As Variant, pid As String, otherId As String
    Dim decDeathValue As Variant, addInheritanceEvent As Boolean
    Dim manualEvents As Collection
    Dim stepText As String
    SyncMarriageHistoryFromLegacyTables
    Set we = ThisWorkbook.Worksheets(SH_W_EVENT)
    Set manualEvents = PreserveManualTimelineEvents(we)
    we.Range("A2:L" & CStr(Application.Max(2, LastRow(we, 1)))).ClearContents
    RestoreManualTimelineEvents we, manualEvents
    AddMarriageHistoryEvents we

    '�o�͐�������W_�֌W�����������Ȃ��B��z��ҍs�̍���/���������c���Ă��Ă��A
    '�֌W�C�x���g�����ł͔z��ҍs������ǂނ��߁AC_�`�F�b�N�Ōx�����Ė�������B

    Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)
    For r = 2 To LastRow(wp, 1)
        If CStr(wp.Cells(r, P_STATUS).Value) <> STATUS_CANCEL And Len(CStr(wp.Cells(r, P_ID).Value)) > 0 Then
            pid = CStr(wp.Cells(r, P_ID).Value)
            If IsDate(wp.Cells(r, P_BIRTH).Value) Then AddEvent pid, wp.Cells(r, P_BIRTH).Value, "�o��", "�o��", "����", "�l��", pid
            If IsDate(wp.Cells(r, P_DEATH).Value) Then AddEvent pid, wp.Cells(r, P_DEATH).Value, "���S", "�v", "����", "�l��", pid
            If IsDate(wp.Cells(r, P_MARRIAGE).Value) Then
                If Not HasSpouseRelationEventForPersonDate(pid, wp.Cells(r, P_MARRIAGE).Value, "����") _
                        And Not HasMarriageHistoryEventForPersonDate(pid, wp.Cells(r, P_MARRIAGE).Value, "����") Then _
                    AddEvent pid, wp.Cells(r, P_MARRIAGE).Value, "����", "����", "����", "�l��", pid & "|����"
            End If
            If IsDate(wp.Cells(r, P_DIVORCE).Value) Then
                If Not HasSpouseRelationEventForPersonDate(pid, wp.Cells(r, P_DIVORCE).Value, "����") _
                        And Not HasMarriageHistoryEventForPersonDate(pid, wp.Cells(r, P_DIVORCE).Value, "����") Then _
                    AddEvent pid, wp.Cells(r, P_DIVORCE).Value, "����", "����", "����", "�l��", pid & "|����"
            End If
        End If
    Next r

    Set wr = ThisWorkbook.Worksheets(SH_W_REL)
    For r = 2 To LastRow(wr, 1)
        If CStr(wr.Cells(r, R_STATUS).Value) <> STATUS_CANCEL And CStr(wr.Cells(r, R_TYPE).Value) = "�z���" Then
            pid = CStr(wr.Cells(r, R_BASE_ID).Value)
            otherId = CStr(wr.Cells(r, R_OTHER_ID).Value)
            If Len(pid) > 0 And Len(otherId) > 0 And pid <> otherId _
                    And FindPersonRow(pid) > 0 And FindPersonRow(otherId) > 0 Then
                If IsDate(wr.Cells(r, R_MARRIAGE).Value) Then
                    AddEvent pid, wr.Cells(r, R_MARRIAGE).Value, "����", "����", "����", "�֌W", wr.Cells(r, R_ID).Value
                    AddEvent otherId, wr.Cells(r, R_MARRIAGE).Value, "����", "����", "����", "�֌W", wr.Cells(r, R_ID).Value
                End If
                If IsDate(wr.Cells(r, R_DIVORCE).Value) Then
                    AddEvent pid, wr.Cells(r, R_DIVORCE).Value, "����", "�����F" & GetPersonValue(otherId, P_DISPLAY), "����", "�֌W", wr.Cells(r, R_ID).Value
                    AddEvent otherId, wr.Cells(r, R_DIVORCE).Value, "����", "�����F" & GetPersonValue(pid, P_DISPLAY), "����", "�֌W", wr.Cells(r, R_ID).Value
                End If
            End If
        End If
    Next r

    Set wa = ThisWorkbook.Worksheets(SH_W_ADDR_HIST)
    For r = 2 To LastRow(wa, 1)
        If CStr(wa.Cells(r, A_STATUS).Value) <> STATUS_CANCEL Then
            pid = CStr(wa.Cells(r, A_PERSON_ID).Value)
            If Len(pid) > 0 And FindPersonRow(pid) > 0 Then
                If IsDate(wa.Cells(r, A_START).Value) Then
                    AddEvent pid, wa.Cells(r, A_START).Value, _
                        AddressStartEventType(wa, r), AddressStartEventContent(wa, r), "����", "�Z��", wa.Cells(r, A_ID).Value
                End If
                If IsDate(wa.Cells(r, A_END).Value) Then
                    If Not IsPersonDeathDate(pid, wa.Cells(r, A_END).Value) Then
                        AddEvent pid, wa.Cells(r, A_END).Value, _
                            "���Z�I��", "���Z�I���F" & wa.Cells(r, A_TEXT).Value, "����", "�Z��", wa.Cells(r, A_ID).Value
                    End If
                End If
            End If
        End If
    Next r
    stepText = "�푊���l�擾"
    decId = GetDecedentId()
    inhDate = GetInheritanceDate()
    If Len(decId) > 0 And IsDate(inhDate) Then
        decDeathValue = GetPersonValue(decId, P_DEATH)
        addInheritanceEvent = True
        If IsDate(decDeathValue) Then
            If CLng(CDate(decDeathValue)) = CLng(CDate(inhDate)) Then addInheritanceEvent = False
        End If
        If addInheritanceEvent Then AddEvent decId, inhDate, "�����J�n", "�����J�n", "����", "�ݒ�", "�����J�n��"
    End If
    CompactTimelineDisplayEvents we
End Sub

Private Sub AddMarriageHistoryEvents(ByVal we As Worksheet)
    Dim mh As Worksheet, r As Long, pid As String, cpId As String, cpName As String, mhId As String
    If we Is Nothing Then Exit Sub
    EnsureMarriageHistoryWorkSheet
    BackfillMarriageHistoryFromLegacyFacts
    Set mh = ThisWorkbook.Worksheets(SH_W_MARRIAGE_HIST)
    For r = 2 To LastRow(mh, 1)
        If CStr(mh.Cells(r, MH_STATUS).Value) <> STATUS_CANCEL _
                And CStr(mh.Cells(r, MH_SHOW).Value) <> SHOW_NO _
                And Len(CStr(mh.Cells(r, MH_ID).Value)) > 0 Then
            mhId = CStr(mh.Cells(r, MH_ID).Value)
            pid = CStr(mh.Cells(r, MH_PERSON_ID).Value)
            cpId = CStr(mh.Cells(r, MH_COUNTERPART_ID).Value)
            cpName = CleanText(mh.Cells(r, MH_COUNTERPART_NAME).Value)
            If Len(cpName) = 0 And Len(cpId) > 0 Then cpName = GetPersonValue(cpId, P_DISPLAY)
            If IsDate(mh.Cells(r, MH_MARRIAGE).Value) Then
                AddEvent pid, mh.Cells(r, MH_MARRIAGE).Value, "����", "����", "����", "��������", mhId
                If Len(cpId) > 0 Then AddEvent cpId, mh.Cells(r, MH_MARRIAGE).Value, "����", "����", "����", "��������", mhId
            End If
            If IsDate(mh.Cells(r, MH_DIVORCE).Value) Then
                AddEvent pid, mh.Cells(r, MH_DIVORCE).Value, "����", DivorceContentText(cpName), "����", "��������", mhId
                If Len(cpId) > 0 Then AddEvent cpId, mh.Cells(r, MH_DIVORCE).Value, "����", DivorceContentText(GetPersonValue(pid, P_DISPLAY)), "����", "��������", mhId
            End If
        End If
    Next r
End Sub

Private Function DivorceContentText(ByVal counterpartName As String) As String
    counterpartName = CleanText(counterpartName)
    If Len(counterpartName) > 0 Then
        DivorceContentText = "�����F" & counterpartName
    Else
        DivorceContentText = "����"
    End If
End Function

Private Function HasMarriageHistoryEventForPersonDate(ByVal personId As String, _
        ByVal eventDate As Variant, _
        ByVal eventType As String) As Boolean
    Dim mh As Worksheet, r As Long, d As Variant
    If Len(personId) = 0 Or Not IsDate(eventDate) Then Exit Function
    EnsureMarriageHistoryWorkSheet
    BackfillMarriageHistoryFromLegacyFacts
    Set mh = ThisWorkbook.Worksheets(SH_W_MARRIAGE_HIST)
    For r = 2 To LastRow(mh, 1)
        If CStr(mh.Cells(r, MH_STATUS).Value) <> STATUS_CANCEL Then
            If CStr(mh.Cells(r, MH_PERSON_ID).Value) = personId Or CStr(mh.Cells(r, MH_COUNTERPART_ID).Value) = personId Then
                If eventType = "����" Then
                    d = mh.Cells(r, MH_MARRIAGE).Value
                Else
                    d = mh.Cells(r, MH_DIVORCE).Value
                End If
                If IsDate(d) Then
                    If CLng(CDate(d)) = CLng(CDate(eventDate)) Then
                        HasMarriageHistoryEventForPersonDate = True
                        Exit Function
                    End If
                End If
            End If
        End If
    Next r
End Function

Private Function HasSpouseRelationEventForPersonDate(ByVal personId As String, _
        ByVal eventDate As Variant, _
        ByVal eventType As String) As Boolean

    Dim wr As Worksheet, r As Long, d As Variant
    If Len(personId) = 0 Or Not IsDate(eventDate) Then Exit Function
    Set wr = ThisWorkbook.Worksheets(SH_W_REL)
    For r = 2 To LastRow(wr, 1)
        If CStr(wr.Cells(r, R_STATUS).Value) <> STATUS_CANCEL _
                And CStr(wr.Cells(r, R_TYPE).Value) = "�z���" Then
            If CStr(wr.Cells(r, R_BASE_ID).Value) = personId _
                    Or CStr(wr.Cells(r, R_OTHER_ID).Value) = personId Then
                If eventType = "����" Then
                    d = wr.Cells(r, R_MARRIAGE).Value
                Else
                    d = wr.Cells(r, R_DIVORCE).Value
                End If
                If IsDate(d) Then
                    If CLng(CDate(d)) = CLng(CDate(eventDate)) Then
                        HasSpouseRelationEventForPersonDate = True
                        Exit Function
                    End If
                End If
            End If
        End If
    Next r

End Function

Private Sub CompactTimelineDisplayEvents(ByVal ws As Worksheet)
    '�\���㓯��̃C�x���g��1���ɏW�񂷂�B���łō��ꂽ�d���������Ŕ�\��������B
    Dim seen As Object, r As Long, key As String
    If ws Is Nothing Then Exit Sub
    Set seen = CreateObject("Scripting.Dictionary")
    For r = 2 To LastRow(ws, 1)
        If CStr(ws.Cells(r, E_STATUS).Value) <> STATUS_CANCEL _
                And Len(CStr(ws.Cells(r, E_PERSON_ID).Value)) > 0 _
                And IsDate(ws.Cells(r, E_DATE).Value) Then
            key = CStr(ws.Cells(r, E_PERSON_ID).Value) & "|" & _
                Format(CDate(ws.Cells(r, E_DATE).Value), "yyyymmdd") & "|" & _
                CStr(ws.Cells(r, E_TYPE).Value) & "|" & CStr(ws.Cells(r, E_CONTENT).Value)
            If seen.Exists(key) Then
                ws.Cells(r, E_STATUS).Value = STATUS_CANCEL
                ws.Cells(r, E_SHOW).Value = SHOW_NO
            Else
                seen.Add key, True
            End If
        End If
    Next r
End Sub

Private Function AddressStartEventType(ByVal wsA As Worksheet, ByVal rowNo As Long) As String
    Dim kindText As String
    kindText = CleanText(wsA.Cells(rowNo, A_START_KIND).Value)
    If kindText = "�c����" Then
        AddressStartEventType = "���Z�c��"
    Else
        AddressStartEventType = "���Z�J�n"
    End If
End Function

Private Function AddressStartEventContent(ByVal wsA As Worksheet, ByVal rowNo As Long) As String
    AddressStartEventContent = AddressStartEventType(wsA, rowNo) & "�F" & wsA.Cells(rowNo, A_TEXT).Value
End Function

Private Function IsFirstAddressHistoryRowForPerson(ByVal wsA As Worksheet, ByVal rowNo As Long) As Boolean
    Dim pid As String, r As Long, st As Variant, bestR As Long
    If wsA Is Nothing Then Exit Function
    pid = CStr(wsA.Cells(rowNo, A_PERSON_ID).Value)
    st = wsA.Cells(rowNo, A_START).Value
    For r = 2 To LastRow(wsA, 1)
        If CStr(wsA.Cells(r, A_PERSON_ID).Value) = pid _
                And CStr(wsA.Cells(r, A_STATUS).Value) <> STATUS_CANCEL _
                And Len(CStr(wsA.Cells(r, A_ID).Value)) > 0 Then
            If bestR = 0 Then
                bestR = r
            ElseIf IsDate(wsA.Cells(r, A_START).Value) And IsDate(wsA.Cells(bestR, A_START).Value) Then
                If CDate(wsA.Cells(r, A_START).Value) < CDate(wsA.Cells(bestR, A_START).Value) Then bestR = r
            ElseIf IsDate(wsA.Cells(r, A_START).Value) And Not IsDate(wsA.Cells(bestR, A_START).Value) Then
                bestR = r
            End If
        End If
    Next r
    IsFirstAddressHistoryRowForPerson = (bestR = rowNo)
End Function

Private Function PreserveManualTimelineEvents(ByVal ws As Worksheet) As Collection
    Dim col As New Collection, r As Long, c As Long
    Dim arr As Variant
    If ws Is Nothing Then
        Set PreserveManualTimelineEvents = col
        Exit Function
    End If
    For r = 2 To LastRow(ws, 1)
        If Len(CStr(ws.Cells(r, E_ID).Value)) > 0 _
                And CStr(ws.Cells(r, E_STATUS).Value) <> STATUS_CANCEL _
                And CStr(ws.Cells(r, E_AUTO).Value) <> "����" Then
            ReDim arr(1 To 12)
            For c = 1 To 12
                arr(c) = ws.Cells(r, c).Value
            Next c
            col.Add arr
        End If
    Next r
    Set PreserveManualTimelineEvents = col
End Function

Private Sub RestoreManualTimelineEvents(ByVal ws As Worksheet, ByVal events As Collection)
    Dim item As Variant, r As Long, c As Long
    If ws Is Nothing Then Exit Sub
    If events Is Nothing Then Exit Sub
    For Each item In events
        r = NextBlankRow(ws, 1)
        For c = 1 To 12
            ws.Cells(r, c).Value = item(c)
        Next c
    Next item
End Sub

Private Sub SanitizeRelationDatesForTimeline()
    '�p�~: �o�͏��������f�[�^���C�����Ă͂����Ȃ��B
    '���Ō݊��̂��߃v���V�[�W�������c�����A��z��ҍs�̍���/��������RunChecks�Ōx�����A���n�񐶐��ł͖�������B
End Sub

Private Function IsPersonDeathDate(ByVal personId As String, ByVal v As Variant) As Boolean
    Dim d As Variant
    If Len(personId) = 0 Or Not IsDate(v) Then Exit Function
    d = GetPersonValue(personId, P_DEATH)
    If IsDate(d) Then IsPersonDeathDate = (CLng(CDate(d)) = CLng(CDate(v)))
End Function

Private Sub AddEvent(ByVal personId As String, _
        ByVal eventDate As Variant, _
        ByVal eventType As String, _
        ByVal content As String, _
        ByVal autoFlag As String, _
        ByVal srcType As String, _
        ByVal srcId As String)
    Dim ws As Worksheet, r As Long
    If Len(CStr(personId)) = 0 Or Not IsDate(eventDate) Then Exit Sub
    If FindPersonRow(CStr(personId)) = 0 Then Exit Sub
    Set ws = ThisWorkbook.Worksheets(SH_W_EVENT)
    If TimelineEventExists(ws, CStr(personId), eventDate, eventType, content, srcType, srcId) Then Exit Sub
    r = NextBlankRow(ws, 1)
    ws.Cells(r, E_ID).Value = NextId("�C�x���g")
    ws.Cells(r, E_PERSON_ID).Value = personId
    ws.Cells(r, E_DATE).Value = eventDate
    ws.Cells(r, E_YEAR).Value = Year(CDate(eventDate))
    ws.Cells(r, E_TYPE).Value = eventType
    ws.Cells(r, E_CONTENT).Value = content
    ws.Cells(r, E_AUTO).Value = autoFlag
    ws.Cells(r, E_SOURCE_TYPE).Value = srcType
    ws.Cells(r, E_SOURCE_ID).Value = srcId
    ws.Cells(r, E_SHOW).Value = SHOW_YES
    ws.Cells(r, E_STATUS).Value = STATUS_ACTIVE
End Sub

Private Function TimelineEventExists(ByVal ws As Worksheet, _
        ByVal personId As String, _
        ByVal eventDate As Variant, _
        ByVal eventType As String, _
        ByVal content As String, _
        ByVal srcType As String, _
        ByVal srcId As String) As Boolean
    '�����l���E�������t�E������ށE�����\�����e�́A�ۑ��o�H������Ă�1���ɏW�񂷂�B
    '�z��ғo�^�A������ǉ��A�l�����̍������������������d�������Ȃ����߁B
    Dim r As Long
    For r = 2 To LastRow(ws, 1)
        If CStr(ws.Cells(r, E_PERSON_ID).Value) = personId Then
            If IsDate(ws.Cells(r, E_DATE).Value) And IsDate(eventDate) Then
                If CLng(CDate(ws.Cells(r, E_DATE).Value)) = CLng(CDate(eventDate)) Then
                    If CStr(ws.Cells(r, E_TYPE).Value) = eventType _
                            And CStr(ws.Cells(r, E_CONTENT).Value) = content _
                            And CStr(ws.Cells(r, E_STATUS).Value) <> STATUS_CANCEL Then
                        TimelineEventExists = True
                        Exit Function
                    End If
                End If
            End If
        End If
    Next r
End Function

Public Sub ShowAddressHistoryOutput()
    On Error GoTo EH
    AppBegin
    RefreshRepresentativeAddresses
    BuildAddressHistoryTable
    ApplyOutputUsability
    ShowOnlyInputCore False
    ThisWorkbook.Worksheets(SH_ADDR_TABLE).Visible = xlSheetVisible
    ThisWorkbook.Worksheets(SH_ADDR_TABLE).Activate
CleanExit:
    AppEnd
    Exit Sub
EH:
    AppEnd
    RuntimeShowError "ShowAddressHistoryOutput", "�Z������\��", "�Z�������V�[�g�E�Z�������f�[�^�̏�Ԃ��m�F���Ă��������B"
End Sub

Public Sub ShowRelationshipDiagramOutput()
    On Error GoTo EH
    AppBegin "�����֌W�}���쐬��..."
    NormalizePersonRelationLabels
    RefreshRepresentativeAddresses
    BuildRelationshipDiagram
    ApplyOutputUsability
    ShowOnlyInputCore False
    ThisWorkbook.Worksheets(SH_DIAGRAM).Visible = xlSheetVisible
    ThisWorkbook.Worksheets(SH_DIAGRAM).Activate
CleanExit:
    AppEnd
    Exit Sub
EH:
    AppEnd
    RuntimeShowError "ShowRelationshipDiagramOutput", "�����֌W�}�쐬", _
        "�푊���l�A�֌W�ҁA�}�\���ݒ�A�o�̓V�[�g�̏�Ԃ��m�F���Ă��������B"
End Sub

Public Sub ShowTimelineOutput()
    On Error GoTo EH
    AppBegin "���n��\���쐬��..."
    NormalizePersonRelationLabels
    RefreshRepresentativeAddresses
    GenerateEvents
    BuildTimelineTable
    ApplyOutputUsability
    ShowOnlyInputCore False
    ThisWorkbook.Worksheets(SH_TIMELINE).Visible = xlSheetVisible
    ThisWorkbook.Worksheets(SH_TIMELINE).Activate
CleanExit:
    AppEnd
    Exit Sub
EH:
    AppEnd
    RuntimeShowError "ShowTimelineOutput", "���n��\�쐬", _
        "�l���A���N�����E���S���A�������A�Z���J�n���E�I�����̏�Ԃ��m�F���Ă��������B"
End Sub

Private Sub BuildRelationshipDiagram()
    On Error GoTo EH
    Dim ws As Worksheet
    Dim decId As String, decRow As Long, spouseRow As Long, fatherRow As Long, motherRow As Long
    Dim decShape As Shape, spouseShape As Shape, fatherShape As Shape, motherShape As Shape
    Dim children As Collection, siblings As Collection, drawn As Object
    Dim plan As RelationshipDiagramPlan
    Dim parentY As Double, decY As Double, childTop As Double
    Dim decX As Double, spouseX As Double, parentOriginX As Double, parentOriginY As Double
    Dim coupleOriginX As Double, coupleOriginY As Double
    Dim maxBottom As Double
    Dim hasParents As Boolean, titleLastCol As Long, buttonLeftCol As Long
    Dim stepText As String, errNum As Long, errDesc As String, errSrc As String

    stepText = "�o�̓V�[�g�擾"
    Set ws = ThisWorkbook.Worksheets(SH_DIAGRAM)
    stepText = "�V�[�g������"
    ClearSheetAll ws
    ApplySheetCanvas ws
    Set drawn = CreateObject("Scripting.Dictionary")
    NormalizePersonRelationLabels
    '�����f�[�^�ɐe�q�s�������Ă��Ă��A��R�Â����Ȃ��͈͂Ő}��̐e����⊮����B
    '���������ł͂Ȃ��AW_�֌W��P_SUR_SRC���P����̏��ɔ��肷��B
    mRelationshipDiagramHasPlan = False
    mRelationshipDiagramLandscape = True
    mRelationshipDiagramFitWideHint = 1

    decId = GetDecedentId()
    decRow = FindPersonRow(decId)
    If decRow = 0 Then
        PrepareSimpleRelationshipDiagramPage ws, True
        ws.Range("A1:Q1").Merge
        TitleBannerStyle ws.Range("A1:Q1"), "�����֌W�}"
        ws.Range("A4:Q8").Merge
        ws.Range("A4").Value = "�푊���l�����o�^�ł��B"
        ws.Range("A4").Interior.Color = ThemeColor("danger-soft")
        ws.Range("A4").Font.Color = ThemeColor("red")
        ws.Range("A4").Font.Bold = True
        ThemeApplyMonochromePrint ws, "$A$1:$Q$10", True, "", 1, 0
        Exit Sub
    End If

    stepText = "�l���֌W�擾"
    spouseRow = GetSpouseRowOfPerson(decId)
    fatherRow = GetFirstVisiblePersonRowByRelation("��")
    motherRow = GetFirstVisiblePersonRowByRelation("��")
    Set children = GetRootChildRows(decId)
    Set siblings = GetSiblingRowsForPerson(decId)
    AuditRelationshipDiagramBeforeBuild decId
    stepText = "���C�A�E�g�v��"
    plan = BuildRelationshipDiagramPlan(decId, decRow, spouseRow, fatherRow, motherRow, children, siblings)

    stepText = "�y�[�W�ݒ�"
    ApplyRelationshipDiagramPageSetup ws, plan
    PrepareRelationshipDiagramGrid ws, plan
    titleLastCol = Application.Max(16, PrintColumnForRightPoint(ws, Application.Max(plan.PageRight, plan.PageLeft + plan.RootWidth + 42)))
    ws.Range(ws.Cells(1, 1), ws.Cells(1, titleLastCol)).Merge
    TitleBannerStyle ws.Range(ws.Cells(1, 1), ws.Cells(1, titleLastCol)), "�����֌W�}"
    buttonLeftCol = Application.Max(1, titleLastCol - 1)
    AddButton ws, ws.Range(ws.Cells(1, buttonLeftCol), ws.Cells(1, titleLastCol)).Address(False, False), "���֖͂߂�", "ShowOnlyInput", 120, 28

    hasParents = (fatherRow > 0 Or motherRow > 0)
    If hasParents Then
        parentY = 58
        decY = parentY + plan.CardH + plan.RowGap
    Else
        parentY = 0
        decY = 72
    End If
    childTop = decY + plan.CardH + plan.RowGap
    If plan.MaxDepth >= 3 Then childTop = childTop + 28
    If plan.CardH >= 520 Then childTop = childTop + 16

    decX = DecedentLeftForRootGeneration(decRow, spouseRow, siblings, plan.PageCenter, plan.CardW, plan.CoupleGap, plan.BlockGap)
    If spouseRow > 0 Then
        spouseX = decX + plan.CardW + plan.CoupleGap
    Else
        spouseX = 0
    End If

    stepText = "�e����`��"
    If fatherRow > 0 And motherRow > 0 Then
        Set fatherShape = DrawTreeCard(ws, fatherRow, ShapeCenterTargetX(decX, plan.CardW) - plan.CardW - plan.CoupleGap / 2, parentY, plan.CardW, plan.CardH, drawn)
        Set motherShape = DrawTreeCard(ws, motherRow, ShapeCenterTargetX(decX, plan.CardW) + plan.CoupleGap / 2, parentY, plan.CardW, plan.CardH, drawn)
        ConnectHorizontalCouple ws, fatherShape, motherShape, parentOriginX, parentOriginY
    ElseIf fatherRow > 0 Then
        Set fatherShape = DrawTreeCard(ws, fatherRow, ShapeCenterTargetX(decX, plan.CardW) - plan.CardW / 2, parentY, plan.CardW, plan.CardH, drawn)
        If Not fatherShape Is Nothing Then
            parentOriginX = ShapeCenterX(fatherShape)
            parentOriginY = fatherShape.Top + fatherShape.Height
        End If
    ElseIf motherRow > 0 Then
        Set motherShape = DrawTreeCard(ws, motherRow, ShapeCenterTargetX(decX, plan.CardW) - plan.CardW / 2, parentY, plan.CardW, plan.CardH, drawn)
        If Not motherShape Is Nothing Then
            parentOriginX = ShapeCenterX(motherShape)
            parentOriginY = motherShape.Top + motherShape.Height
        End If
    End If

    stepText = "�e���ォ��Z��o���ւ̐��`��"
    If hasParents Then
        DrawParentToRootGenerationLines ws, parentOriginX, parentOriginY, decX, decY, plan.CardW, plan.CoupleGap, plan.BlockGap, spouseRow, siblings
    End If

    stepText = "�푊���l�E�z��ҁE�Z��o���`��"
    Set decShape = DrawTreeCard(ws, decRow, decX, decY, plan.CardW, plan.CardH, drawn)
    If decShape Is Nothing Then Err.Raise vbObjectError + 781, "BuildRelationshipDiagram", "�푊���l�J�[�h���쐬�ł��܂���ł����B"
    If spouseRow > 0 Then
        Set spouseShape = DrawTreeCard(ws, spouseRow, spouseX, decY, plan.CardW, plan.CardH, drawn)
        If Not spouseShape Is Nothing Then
            ConnectHorizontalCouple ws, decShape, spouseShape, coupleOriginX, coupleOriginY
        End If
    Else
        coupleOriginX = ShapeCenterX(decShape)
        coupleOriginY = decShape.Top + decShape.Height
    End If
    DrawRootSiblingCards ws, siblings, decRow, decX, decY, plan.CardW, plan.CardH, plan.CoupleGap, plan.BlockGap, spouseRow, drawn, Not hasParents
    maxBottom = decY + plan.CardH

    stepText = "�q���u���b�N�`��"
    maxBottom = DrawRootChildrenRowsSafe(ws, decId, children, plan, childTop, maxBottom, _
        decShape, spouseShape, coupleOriginX, coupleOriginY, drawn)

    stepText = "���ڑ��l���m�F"
    maxBottom = DrawRemainingVisiblePersons(ws, drawn, plan.PageLeft, maxBottom + Application.Max(44, plan.RowGap * 0.48), plan.CardW, plan.CardH, plan.BlockGap, Application.Max(plan.PageRight, plan.PageLeft + plan.RootWidth + 80))
    stepText = "����͈͐��`"
    ShiftPrintableDiagramShapesLeft ws, plan.PageLeft
    stepText = "�d�グ"
    PolishRelationshipDiagramOutput ws
    WarnDiagramIfCardCollisions ws
    WarnDiagramIfPrintBoundsRisk ws
    ThemeLockShapeLayer ws
    Exit Sub
EH:
    errNum = Err.Number
    errDesc = Err.Description
    errSrc = Err.Source
    AppendRelationshipDiagramBuildFailure stepText, errNum, errDesc, errSrc
    On Error Resume Next
    If Not ws Is Nothing Then
        ClearSheetAll ws
        PrepareSimpleRelationshipDiagramPage ws, True
        ws.Range("A1:Q1").Merge
        TitleBannerStyle ws.Range("A1:Q1"), "�����֌W�}"
        ws.Range("A4:Q6").Merge
        ws.Range("A4").Value = "�����֌W�}�̍쐬�Ɏ��s���܂����BC_�`�F�b�N�̒�~�H�����m�F���Ă��������B"
        ws.Range("A4").Interior.Color = ThemeColor("danger-soft")
        ws.Range("A4").Font.Color = ThemeColor("red")
        ws.Range("A4").Font.Bold = True
        ThemeApplyMonochromePrint ws, "$A$1:$Q$8", True, "", 1, 0
    End If
    On Error GoTo 0
End Sub

Private Sub AppendRelationshipDiagramBuildFailure(ByVal stepText As String, ByVal errNum As Long, ByVal errDesc As String, ByVal errSrc As String)
    Dim wsC As Worksheet, outR As Long
    On Error Resume Next
    RuntimeAppendLog "ERROR", "�����֌W�}", stepText, errDesc, errNum, errDesc, errSrc
    If SheetExists(SH_CHECK, ThisWorkbook) Then
        Set wsC = ThisWorkbook.Worksheets(SH_CHECK)
        outR = LastRow(wsC, 1) + 1
        If outR < 4 Then outR = 4
        AddCheck wsC, outR, "�G���[", "�����֌W�}�̍쐬���ɒ�~���܂����B�H��=" & stepText & " / " & errDesc, _
            "", "", "�����֌W�}", "C_�`�F�b�N�̍H���Ɛl���֌W�E�Z���������m�F"
    End If
    On Error GoTo 0
End Sub

Private Sub PrepareSimpleRelationshipDiagramPage(ByVal ws As Worksheet, ByVal landscape As Boolean)
    If ws Is Nothing Then Exit Sub
    With ws.PageSetup
        .PaperSize = xlPaperA4
        If landscape Then
            .Orientation = xlLandscape
        Else
            .Orientation = xlPortrait
        End If
        .Zoom = False
        .FitToPagesWide = 1
        .FitToPagesTall = False
        .LeftMargin = Application.CentimetersToPoints(0.35)
        .RightMargin = Application.CentimetersToPoints(0.35)
        .TopMargin = Application.CentimetersToPoints(0.35)
        .BottomMargin = Application.CentimetersToPoints(0.35)
        .PrintArea = ""
    End With
    ws.Range(ws.Cells(1, 1), ws.Cells(1, 32)).EntireColumn.ColumnWidth = 5.2
    ws.Range(ws.Cells(1, 1), ws.Cells(180, 1)).EntireRow.RowHeight = 14.2
End Sub

Private Function DrawRootChildrenRowsSafe(ByVal ws As Worksheet, _
        ByVal decId As String, _
        ByVal children As Collection, _
        ByRef plan As RelationshipDiagramPlan, _
        ByVal firstChildTop As Double, _
        ByVal currentMaxBottom As Double, _
        ByVal decShape As Shape, _
        ByVal spouseShape As Shape, _
        ByVal coupleOriginX As Double, _
        ByVal coupleOriginY As Double, _
        ByVal drawn As Object) As Double
    Dim childTop As Double, maxBottom As Double
    Dim idx As Long, rowStart As Long, i As Long
    Dim rowW As Double, w As Double, startX As Double, x As Double
    Dim branchY As Double, blockW As Double, blockBottom As Double

    On Error GoTo EH
    maxBottom = currentMaxBottom
    childTop = firstChildTop
    If children Is Nothing Then
        DrawRootChildrenRowsSafe = maxBottom
        Exit Function
    End If

    idx = 1
    Do While idx <= children.Count
        rowStart = idx
        rowW = 0
        Do While idx <= children.Count
            w = SafeRootChildBlockWidth(children(idx), plan.CardW, plan.CardH, plan.CoupleGap, plan.BlockGap)
            If rowW > 0 Then
                If rowW + plan.BlockGap + w > plan.PageWidth Then Exit Do
                rowW = rowW + plan.BlockGap
            End If
            rowW = rowW + w
            idx = idx + 1
        Loop
        If rowW <= 0 Then
            rowW = plan.CardW
            idx = idx + 1
        End If
        startX = plan.PageCenter - rowW / 2
        If startX < plan.PageLeft Then startX = plan.PageLeft
        branchY = childTop - DiagramBranchOffsetForDepth(0)
        x = startX
        For i = rowStart To idx - 1
            blockW = SafeRootChildBlockWidth(children(i), plan.CardW, plan.CardH, plan.CoupleGap, plan.BlockGap)
            blockBottom = DrawRootChildDescendantBlockSafe(ws, decId, children(i), x, childTop, branchY, _
                plan.CardW, plan.CardH, plan.CoupleGap, plan.BlockGap, decShape, spouseShape, _
                coupleOriginX, coupleOriginY, drawn)
            If blockBottom > maxBottom Then maxBottom = blockBottom
            x = x + blockW + plan.BlockGap
        Next i
        childTop = maxBottom + Application.Max(plan.RowGap, 112)
        '�v�w���̒����͏�ɃJ�[�h�Ԃ̌�������ɌŒ肷��B
        '���s�֐i�߂邽�߂� branchY �֍X�V����ƁA2�s�ڈȍ~�̐e�q�����v�w�Ԃ���L�тȂ��Ȃ�B
    Loop

    DrawRootChildrenRowsSafe = maxBottom
    Exit Function
EH:
    AppendRelationshipDiagramDrawWarning "�q���u���b�N�`��", "���n�q�S�̂��ꕔ�X�L�b�v���Čp��: " & Err.Description
    Err.Clear
    If currentMaxBottom >= firstChildTop + plan.CardH Then
        DrawRootChildrenRowsSafe = currentMaxBottom
    Else
        DrawRootChildrenRowsSafe = firstChildTop + plan.CardH
    End If
End Function

Private Function BuildRelationshipDiagramPlan(ByVal decId As String, _
        ByVal decRow As Long, _
        ByVal spouseRow As Long, _
        ByVal fatherRow As Long, _
        ByVal motherRow As Long, _
        ByVal children As Collection, _
        ByVal siblings As Collection) As RelationshipDiagramPlan
    Dim plan As RelationshipDiagramPlan
    Dim childWidth As Double, rootOwnWidth As Double, parentWidth As Double, siblingWidth As Double
    Dim wideFamily As Boolean, deepFamily As Boolean

    '�J�[�h����1�s1���B�S�l���̍ő�s�������āA�J�[�h�������Ɋm�ۂ���B
    '�l���������ꍇ���������ɒ[�ɍ�炸�A�}���������ׂ���茩�؂�h�~��D�悷��B
    plan.CardW = 348
    plan.CardH = DiagramCardHeightFromLines(MaxDiagramCardVisualLineCount(plan.CardW))
    plan.CoupleGap = 38
    plan.BlockGap = 66
    plan.RowGap = Application.Max(126, plan.CardH * 0.28)
    plan.PersonCount = CountVisibleDiagramPersons()
    plan.MaxDepth = MaxDescendantDepthForPerson(decId, CreateObject("Scripting.Dictionary"), 0)
    plan.MaxSiblings = Application.Max(MaxSiblingCountForPerson(decId, CreateObject("Scripting.Dictionary")), SiblingRowsCount(siblings) + 1)
    childWidth = CollectionFamilyTreeWidth(children, plan.CardW, plan.CardH, plan.CoupleGap, plan.BlockGap, 1)
    rootOwnWidth = plan.CardW
    If spouseRow > 0 Then rootOwnWidth = plan.CardW * 2 + plan.CoupleGap
    siblingWidth = RootGenerationWidth(spouseRow, siblings, plan.CardW, plan.CoupleGap, plan.BlockGap)
    parentWidth = 0
    If fatherRow > 0 And motherRow > 0 Then
        parentWidth = plan.CardW * 2 + plan.CoupleGap
    ElseIf fatherRow > 0 Or motherRow > 0 Then
        parentWidth = plan.CardW
    End If
    plan.RootWidth = Application.Max(Application.Max(rootOwnWidth, siblingWidth), Application.Max(parentWidth, childWidth))

    wideFamily = (plan.MaxSiblings >= 5 Or plan.RootWidth > 760 Or plan.PersonCount >= 18 Or SiblingRowsCount(siblings) >= 3)
    deepFamily = (plan.MaxDepth >= 3)
    plan.IsLandscape = True
    If deepFamily And Not wideFamily Then plan.IsLandscape = False
    If deepFamily And plan.MaxSiblings <= 3 And plan.PersonCount <= 20 And SiblingRowsCount(siblings) <= 1 Then plan.IsLandscape = False
    If plan.MaxSiblings >= 6 Or childWidth > 780 Or SiblingRowsCount(siblings) >= 3 Then plan.IsLandscape = True

    If plan.PersonCount >= 22 Or plan.MaxSiblings >= 7 Or plan.RootWidth > 1250 Then
        plan.CardW = 334
        plan.CardH = Application.Max(plan.CardH, DiagramCardHeightFromLines(MaxDiagramCardVisualLineCount(plan.CardW)))
        plan.CoupleGap = 34
        plan.BlockGap = 56
        plan.RowGap = Application.Max(118, plan.CardH * 0.24)
    ElseIf deepFamily And Not wideFamily Then
        plan.CardW = 340
        plan.CardH = Application.Max(plan.CardH, DiagramCardHeightFromLines(MaxDiagramCardVisualLineCount(plan.CardW)))
        plan.CoupleGap = 36
        plan.BlockGap = 62
        plan.RowGap = Application.Max(132, plan.CardH * 0.28)
    End If

    childWidth = CollectionFamilyTreeWidth(children, plan.CardW, plan.CardH, plan.CoupleGap, plan.BlockGap, 1)
    rootOwnWidth = plan.CardW
    If spouseRow > 0 Then rootOwnWidth = plan.CardW * 2 + plan.CoupleGap
    siblingWidth = RootGenerationWidth(spouseRow, siblings, plan.CardW, plan.CoupleGap, plan.BlockGap)
    parentWidth = 0
    If fatherRow > 0 And motherRow > 0 Then
        parentWidth = plan.CardW * 2 + plan.CoupleGap
    ElseIf fatherRow > 0 Or motherRow > 0 Then
        parentWidth = plan.CardW
    End If
    plan.RootWidth = Application.Max(Application.Max(rootOwnWidth, siblingWidth), Application.Max(parentWidth, childWidth))

    plan.PageLeft = 18
    If plan.IsLandscape Then
        plan.PageRight = 820
    Else
        plan.PageRight = 575
    End If
    plan.PageWidth = plan.PageRight - plan.PageLeft
    If Not plan.IsLandscape And plan.RootWidth > plan.PageWidth * 1.2 Then
        plan.IsLandscape = True
        plan.PageRight = 820
        plan.PageWidth = plan.PageRight - plan.PageLeft
    End If
    plan.PageCenter = plan.PageLeft + plan.PageWidth / 2
    plan.FitWideHint = PagesNeededForPointWidth(plan.RootWidth + 60, plan.IsLandscape)
    If plan.FitWideHint < 1 Then plan.FitWideHint = 1

    mRelationshipDiagramHasPlan = True
    mRelationshipDiagramLandscape = plan.IsLandscape
    mRelationshipDiagramFitWideHint = plan.FitWideHint
    BuildRelationshipDiagramPlan = plan
End Function

Private Sub ApplyRelationshipDiagramPageSetup(ByVal ws As Worksheet, ByRef plan As RelationshipDiagramPlan)
    If ws Is Nothing Then Exit Sub
    With ws.PageSetup
        .PaperSize = xlPaperA4
        If plan.IsLandscape Then
            .Orientation = xlLandscape
        Else
            .Orientation = xlPortrait
        End If
        .Zoom = False
        .FitToPagesWide = Application.Max(1, plan.FitWideHint)
        .FitToPagesTall = False
        .LeftMargin = Application.CentimetersToPoints(0.35)
        .RightMargin = Application.CentimetersToPoints(0.35)
        .TopMargin = Application.CentimetersToPoints(0.35)
        .BottomMargin = Application.CentimetersToPoints(0.35)
        .HeaderMargin = Application.CentimetersToPoints(0.18)
        .FooterMargin = Application.CentimetersToPoints(0.18)
        .PrintArea = ""
    End With
End Sub

Private Sub PrepareRelationshipDiagramGrid(ByVal ws As Worksheet, ByRef plan As RelationshipDiagramPlan)
    Dim initCols As Long, initRows As Long
    If ws Is Nothing Then Exit Sub
    initCols = 32
    If plan.IsLandscape Then initCols = 40
    If plan.RootWidth > plan.PageWidth Then initCols = initCols + CLng((plan.RootWidth - plan.PageWidth) / 35) + 4
    If initCols < 24 Then initCols = 24
    If initCols > 120 Then initCols = 120
    initRows = 180
    If plan.MaxDepth >= 3 Then initRows = 220
    If plan.MaxDepth >= 5 Or plan.PersonCount >= 24 Then initRows = 280
    ws.Range(ws.Cells(1, 1), ws.Cells(1, initCols)).EntireColumn.ColumnWidth = 5.2
    ws.Range(ws.Cells(1, 1), ws.Cells(initRows, 1)).EntireRow.RowHeight = 14.2
End Sub


Private Function RootGenerationWidth(ByVal spouseRow As Long, _
        ByVal siblings As Collection, _
        ByVal cardW As Double, _
        ByVal coupleGap As Double, _
        ByVal blockGap As Double) As Double
    Dim rootW As Double, n As Long
    rootW = cardW
    If spouseRow > 0 Then rootW = cardW * 2 + coupleGap
    n = SiblingRowsCount(siblings)
    RootGenerationWidth = rootW
    If n > 0 Then RootGenerationWidth = rootW + n * cardW + n * blockGap
End Function

Private Function SiblingRowsCount(ByVal siblings As Collection) As Long
    If siblings Is Nothing Then
        SiblingRowsCount = 0
    Else
        SiblingRowsCount = siblings.Count
    End If
End Function

Private Function RootOwnWidthForDiagram(ByVal spouseRow As Long, ByVal cardW As Double, ByVal coupleGap As Double) As Double
    RootOwnWidthForDiagram = cardW
    If spouseRow > 0 Then RootOwnWidthForDiagram = cardW * 2 + coupleGap
End Function

Private Function SiblingCollectionWidth(ByVal siblingRows As Collection, ByVal cardW As Double, ByVal blockGap As Double) As Double
    Dim n As Long
    n = SiblingRowsCount(siblingRows)
    If n <= 0 Then Exit Function
    SiblingCollectionWidth = n * cardW
    If n > 1 Then SiblingCollectionWidth = SiblingCollectionWidth + (n - 1) * blockGap
End Function

Private Function DecedentLeftForRootGeneration(ByVal decRow As Long, _
        ByVal spouseRow As Long, _
        ByVal siblings As Collection, _
        ByVal pageCenter As Double, _
        ByVal cardW As Double, _
        ByVal coupleGap As Double, _
        ByVal blockGap As Double) As Double
    Dim leftRows As Collection, rightRows As Collection
    Dim rootW As Double, leftPart As Double, rightPart As Double
    rootW = RootOwnWidthForDiagram(spouseRow, cardW, coupleGap)
    SplitSiblingRowsForDiagram siblings, decRow, leftRows, rightRows
    leftPart = SiblingCollectionWidth(leftRows, cardW, blockGap)
    rightPart = SiblingCollectionWidth(rightRows, cardW, blockGap)
    If leftPart > 0 Then leftPart = leftPart + blockGap
    If rightPart > 0 Then rightPart = rightPart + blockGap
    DecedentLeftForRootGeneration = pageCenter - rootW / 2 + (leftPart - rightPart) / 2
End Function

Private Sub SplitSiblingRowsForDiagram(ByVal siblings As Collection, _
        ByVal decRow As Long, _
        ByRef leftRows As Collection, _
        ByRef rightRows As Collection)
    Dim i As Long, sideValue As Long, unknownToLeft As Boolean
    Set leftRows = New Collection
    Set rightRows = New Collection
    unknownToLeft = True
    If siblings Is Nothing Then Exit Sub
    For i = 1 To siblings.Count
        sideValue = SiblingSideForDiagram(CLng(siblings(i)), decRow, unknownToLeft)
        If sideValue < 0 Then
            AddPersonRowUnique leftRows, CLng(siblings(i))
        Else
            AddPersonRowUnique rightRows, CLng(siblings(i))
        End If
    Next i
End Sub

Private Function SiblingSideForDiagram(ByVal personRow As Long, ByVal decRow As Long, ByRef unknownToLeft As Boolean) As Long
    Dim wp As Worksheet, relBase As String
    Dim personBirth As Variant, decBirth As Variant
    If personRow <= 0 Then Exit Function
    Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)
    relBase = DiagramBaseRelationLabel(CleanText(wp.Cells(personRow, P_REL_DEC).Value))
    Select Case relBase
        Case "�Z", "�o"
            SiblingSideForDiagram = -1
            Exit Function
        Case "��", "��"
            SiblingSideForDiagram = 1
            Exit Function
    End Select
    If decRow > 0 Then
        personBirth = wp.Cells(personRow, P_BIRTH).Value
        decBirth = wp.Cells(decRow, P_BIRTH).Value
        If IsDate(personBirth) And IsDate(decBirth) Then
            If CDate(personBirth) < CDate(decBirth) Then
                SiblingSideForDiagram = -1
            Else
                SiblingSideForDiagram = 1
            End If
            Exit Function
        End If
    End If
    If unknownToLeft Then
        SiblingSideForDiagram = -1
    Else
        SiblingSideForDiagram = 1
    End If
    unknownToLeft = Not unknownToLeft
End Function

Private Function RootSiblingLeftFromSide(ByVal sideIndex As Long, _
        ByVal isLeftSide As Boolean, _
        ByVal sideCount As Long, _
        ByVal decLeft As Double, _
        ByVal spouseRow As Long, _
        ByVal cardW As Double, _
        ByVal coupleGap As Double, _
        ByVal blockGap As Double) As Double
    Dim rootW As Double
    rootW = RootOwnWidthForDiagram(spouseRow, cardW, coupleGap)
    If isLeftSide Then
        RootSiblingLeftFromSide = decLeft - (sideCount - sideIndex + 1) * (cardW + blockGap)
    Else
        RootSiblingLeftFromSide = decLeft + rootW + blockGap + (sideIndex - 1) * (cardW + blockGap)
    End If
End Function

Private Sub DrawParentToRootGenerationLines(ByVal ws As Worksheet, _
        ByVal parentOriginX As Double, _
        ByVal parentOriginY As Double, _
        ByVal decLeft As Double, _
        ByVal rootTop As Double, _
        ByVal cardW As Double, _
        ByVal coupleGap As Double, _
        ByVal blockGap As Double, _
        ByVal spouseRow As Long, _
        ByVal siblings As Collection)
    Dim leftRows As Collection, rightRows As Collection
    Dim i As Long, centerX As Double, minX As Double, maxX As Double, branchY As Double, decRow As Long
    If ws Is Nothing Then Exit Sub
    If parentOriginX < 1 Or parentOriginY < 1 Then Exit Sub
    decRow = FindPersonRow(GetDecedentId())
    SplitSiblingRowsForDiagram siblings, decRow, leftRows, rightRows
    branchY = rootTop - 34
    If branchY <= parentOriginY + 8 Then branchY = rootTop - 22
    centerX = decLeft + cardW / 2
    minX = centerX
    maxX = centerX
    For i = 1 To SiblingRowsCount(leftRows)
        centerX = RootSiblingLeftFromSide(i, True, SiblingRowsCount(leftRows), decLeft, spouseRow, cardW, coupleGap, blockGap) + cardW / 2
        If centerX < minX Then minX = centerX
        If centerX > maxX Then maxX = centerX
    Next i
    For i = 1 To SiblingRowsCount(rightRows)
        centerX = RootSiblingLeftFromSide(i, False, SiblingRowsCount(rightRows), decLeft, spouseRow, cardW, coupleGap, blockGap) + cardW / 2
        If centerX < minX Then minX = centerX
        If centerX > maxX Then maxX = centerX
    Next i
    DrawVLine ws, parentOriginX, parentOriginY, branchY
    DrawHLine ws, minX, branchY, maxX
    DrawVLine ws, decLeft + cardW / 2, branchY, rootTop
    For i = 1 To SiblingRowsCount(leftRows)
        centerX = RootSiblingLeftFromSide(i, True, SiblingRowsCount(leftRows), decLeft, spouseRow, cardW, coupleGap, blockGap) + cardW / 2
        DrawVLine ws, centerX, branchY, rootTop
    Next i
    For i = 1 To SiblingRowsCount(rightRows)
        centerX = RootSiblingLeftFromSide(i, False, SiblingRowsCount(rightRows), decLeft, spouseRow, cardW, coupleGap, blockGap) + cardW / 2
        DrawVLine ws, centerX, branchY, rootTop
    Next i
End Sub

Private Sub DrawRootSiblingCards(ByVal ws As Worksheet, _
        ByVal siblings As Collection, _
        ByVal decRow As Long, _
        ByVal decLeft As Double, _
        ByVal rootTop As Double, _
        ByVal cardW As Double, _
        ByVal cardH As Double, _
        ByVal coupleGap As Double, _
        ByVal blockGap As Double, _
        ByVal spouseRow As Long, _
        ByVal drawn As Object, _
        ByVal drawSameGenerationLine As Boolean)
    Dim leftRows As Collection, rightRows As Collection
    Dim i As Long, leftPt As Double, centerX As Double, minX As Double, maxX As Double, branchY As Double
    If ws Is Nothing Then Exit Sub
    SplitSiblingRowsForDiagram siblings, decRow, leftRows, rightRows
    If SiblingRowsCount(leftRows) + SiblingRowsCount(rightRows) <= 0 Then Exit Sub
    centerX = decLeft + cardW / 2
    minX = centerX
    maxX = centerX
    For i = 1 To SiblingRowsCount(leftRows)
        leftPt = RootSiblingLeftFromSide(i, True, SiblingRowsCount(leftRows), decLeft, spouseRow, cardW, coupleGap, blockGap)
        DrawTreeCard ws, CLng(leftRows(i)), leftPt, rootTop, cardW, cardH, drawn
        centerX = leftPt + cardW / 2
        If centerX < minX Then minX = centerX
        If centerX > maxX Then maxX = centerX
    Next i
    For i = 1 To SiblingRowsCount(rightRows)
        leftPt = RootSiblingLeftFromSide(i, False, SiblingRowsCount(rightRows), decLeft, spouseRow, cardW, coupleGap, blockGap)
        DrawTreeCard ws, CLng(rightRows(i)), leftPt, rootTop, cardW, cardH, drawn
        centerX = leftPt + cardW / 2
        If centerX < minX Then minX = centerX
        If centerX > maxX Then maxX = centerX
    Next i
    If drawSameGenerationLine Then
        branchY = rootTop + cardH + 16
        DrawHLine ws, minX, branchY, maxX
        DrawVLine ws, decLeft + cardW / 2, rootTop + cardH, branchY
        For i = 1 To SiblingRowsCount(leftRows)
            leftPt = RootSiblingLeftFromSide(i, True, SiblingRowsCount(leftRows), decLeft, spouseRow, cardW, coupleGap, blockGap)
            DrawVLine ws, leftPt + cardW / 2, rootTop + cardH, branchY
        Next i
        For i = 1 To SiblingRowsCount(rightRows)
            leftPt = RootSiblingLeftFromSide(i, False, SiblingRowsCount(rightRows), decLeft, spouseRow, cardW, coupleGap, blockGap)
            DrawVLine ws, leftPt + cardW / 2, rootTop + cardH, branchY
        Next i
    End If
End Sub

Private Function CollectionFamilyTreeWidth(ByVal personRows As Collection, _
        ByVal cardW As Double, _
        ByVal cardH As Double, _
        ByVal coupleGap As Double, _
        ByVal blockGap As Double, _
        ByVal depth As Long) As Double
    Dim i As Long, w As Double, totalW As Double
    If personRows Is Nothing Then Exit Function
    For i = 1 To personRows.Count
        w = FamilyTreeBlockWidth(CLng(personRows(i)), cardW, cardH, coupleGap, blockGap, depth)
        If totalW > 0 Then totalW = totalW + blockGap
        totalW = totalW + w
    Next i
    CollectionFamilyTreeWidth = totalW
End Function

Private Function CountVisibleDiagramPersons() As Long
    Dim wp As Worksheet, r As Long
    Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)
    For r = 2 To LastRow(wp, 1)
        If Len(CStr(wp.Cells(r, P_ID).Value)) > 0 Then
            If CStr(wp.Cells(r, P_STATUS).Value) <> STATUS_CANCEL And CStr(wp.Cells(r, P_SHOW).Value) <> SHOW_NO Then CountVisibleDiagramPersons = CountVisibleDiagramPersons + 1
        End If
    Next r
End Function

Private Function MaxDescendantDepthForPerson(ByVal parentId As String, ByVal path As Object, ByVal depth As Long) As Long
    Dim childRows As Collection, i As Long, childId As String, childDepth As Long
    If Len(parentId) = 0 Then MaxDescendantDepthForPerson = depth: Exit Function
    If depth > 12 Then MaxDescendantDepthForPerson = depth: Exit Function
    If path.Exists(parentId) Then MaxDescendantDepthForPerson = depth: Exit Function
    path.Add parentId, True
    Set childRows = GetChildRowsForParent(parentId)
    MaxDescendantDepthForPerson = depth
    For i = 1 To childRows.Count
        childId = CStr(ThisWorkbook.Worksheets(SH_W_PERSON).Cells(CLng(childRows(i)), P_ID).Value)
        childDepth = MaxDescendantDepthForPerson(childId, path, depth + 1)
        If childDepth > MaxDescendantDepthForPerson Then MaxDescendantDepthForPerson = childDepth
    Next i
    path.Remove parentId
End Function

Private Function MaxSiblingCountForPerson(ByVal parentId As String, ByVal path As Object) As Long
    Dim childRows As Collection, i As Long, childId As String, childMax As Long
    If Len(parentId) = 0 Then Exit Function
    If path.Exists(parentId) Then Exit Function
    path.Add parentId, True
    Set childRows = GetChildRowsForParent(parentId)
    MaxSiblingCountForPerson = childRows.Count
    For i = 1 To childRows.Count
        childId = CStr(ThisWorkbook.Worksheets(SH_W_PERSON).Cells(CLng(childRows(i)), P_ID).Value)
        childMax = MaxSiblingCountForPerson(childId, path)
        If childMax > MaxSiblingCountForPerson Then MaxSiblingCountForPerson = childMax
    Next i
    path.Remove parentId
End Function

Private Function PagesNeededForPointWidth(ByVal contentWidthPt As Double, ByVal landscape As Boolean) As Long
    Dim usablePt As Double, pages As Long
    If landscape Then
        usablePt = 760
    Else
        usablePt = 515
    End If
    If contentWidthPt <= 0 Then
        PagesNeededForPointWidth = 1
    Else
        pages = CLng(Int((contentWidthPt + usablePt - 1) / usablePt))
        If pages < 1 Then pages = 1
        If pages > 6 Then pages = 6
        PagesNeededForPointWidth = pages
    End If
End Function

Private Sub ShiftPrintableDiagramShapesLeft(ByVal ws As Worksheet, ByVal targetLeft As Double)
    Dim shp As Shape, minLeft As Double, delta As Double
    If ws Is Nothing Then Exit Sub
    minLeft = 0
    For Each shp In ws.Shapes
        If Len(shp.OnAction) = 0 Then
            If minLeft = 0 Or shp.Left < minLeft Then minLeft = shp.Left
        End If
    Next shp
    If minLeft = 0 Then Exit Sub
    delta = minLeft - targetLeft
    If delta <= 1 Then Exit Sub
    For Each shp In ws.Shapes
        If Len(shp.OnAction) = 0 Then shp.Left = shp.Left - delta
    Next shp
End Sub

Private Function ShapeCenterTargetX(ByVal leftPt As Double, ByVal widthPt As Double) As Double
    ShapeCenterTargetX = leftPt + widthPt / 2
End Function

Private Function DrawTreeCard(ByVal ws As Worksheet, _
        ByVal personRow As Long, _
        ByVal leftPt As Double, _
        ByVal topPt As Double, _
        ByVal widthPt As Double, _
        ByVal heightPt As Double, _
        ByVal drawn As Object) As Shape
    Dim pid As String, existingShape As Shape
    If personRow <= 0 Then Exit Function
    pid = CStr(ThisWorkbook.Worksheets(SH_W_PERSON).Cells(personRow, P_ID).Value)
    If Len(pid) > 0 Then
        If Not drawn Is Nothing Then
            If drawn.Exists(pid) Then
                Set existingShape = FindPersonCardShape(ws, pid)
                If Not existingShape Is Nothing Then
                    Set DrawTreeCard = existingShape
                    Exit Function
                End If
            End If
        End If
    End If

    Set DrawTreeCard = DrawPersonCardShape(ws, personRow, leftPt, topPt, widthPt, heightPt)
    If DrawTreeCard Is Nothing Then Exit Function
    If Len(pid) > 0 Then
        If Not drawn Is Nothing Then
            If Not drawn.Exists(pid) Then drawn.Add pid, True
        End If
    End If
End Function

Private Function IsDrawnPerson(ByVal drawn As Object, ByVal personRow As Long) As Boolean
    Dim pid As String
    pid = CStr(ThisWorkbook.Worksheets(SH_W_PERSON).Cells(personRow, P_ID).Value)
    If Len(pid) = 0 Then Exit Function
    IsDrawnPerson = drawn.Exists(pid)
End Function

Private Function FamilyTreeBlockWidth(ByVal personRow As Long, _
        ByVal cardW As Double, _
        ByVal cardH As Double, _
        ByVal coupleGap As Double, _
        ByVal blockGap As Double, _
        ByVal depth As Long) As Double
    Dim pid As String, spouseRow As Long, ownW As Double, childW As Double, i As Long
    Dim childRows As Collection, w As Double
    If personRow <= 0 Or depth > 12 Then
        FamilyTreeBlockWidth = cardW
        Exit Function
    End If
    pid = CStr(ThisWorkbook.Worksheets(SH_W_PERSON).Cells(personRow, P_ID).Value)
    spouseRow = GetSpouseRowOfPerson(pid)
    ownW = cardW
    If spouseRow > 0 Then ownW = cardW * 2 + coupleGap
    Set childRows = GetChildRowsForParent(pid)
    childW = 0
    For i = 1 To childRows.Count
        w = FamilyTreeBlockWidth(CLng(childRows(i)), cardW, cardH, coupleGap, blockGap, depth + 1)
        If childW > 0 Then childW = childW + blockGap
        childW = childW + w
    Next i
    FamilyTreeBlockWidth = Application.Max(ownW, childW)
End Function

Private Function DescendantIncomingY(ByVal personRow As Long, ByVal blockTop As Double, ByVal cardH As Double) As Double
    '�e�q���́A�q�{�l�J�[�h�̏㒆���֒��ړ����B
    '�q���������ĉ��ɔz��҃J�[�h�������Ă��Ă��A�v�w�u���b�N�����֓������Ȃ��B
    DescendantIncomingY = blockTop
End Function

Private Function DescendantChildCardCenterX(ByVal personRow As Long, _
        ByVal blockLeft As Double, _
        ByVal cardW As Double, _
        ByVal cardH As Double, _
        ByVal coupleGap As Double, _
        ByVal blockGap As Double, _
        ByVal depth As Long) As Double
    Dim pid As String, spouseRow As Long, ownW As Double, blockW As Double, ownLeft As Double
    If personRow <= 0 Then
        DescendantChildCardCenterX = blockLeft + cardW / 2
        Exit Function
    End If
    pid = CStr(ThisWorkbook.Worksheets(SH_W_PERSON).Cells(personRow, P_ID).Value)
    blockW = SafeFamilyTreeBlockWidth(personRow, cardW, cardH, coupleGap, blockGap, depth, "�q���u���b�N��")
    spouseRow = GetSpouseRowOfPerson(pid)
    ownW = cardW
    If spouseRow > 0 Then ownW = cardW * 2 + coupleGap
    ownLeft = blockLeft + (blockW - ownW) / 2
    DescendantChildCardCenterX = ownLeft + cardW / 2
End Function


Private Function SafeRootChildBlockWidth(ByVal childRowValue As Variant, _
        ByVal cardW As Double, _
        ByVal cardH As Double, _
        ByVal coupleGap As Double, _
        ByVal blockGap As Double) As Double
    On Error GoTo EH
    SafeRootChildBlockWidth = SafeFamilyTreeBlockWidth(CLng(childRowValue), cardW, cardH, coupleGap, blockGap, 1, "���n�q�u���b�N��")
    If SafeRootChildBlockWidth < cardW Then SafeRootChildBlockWidth = cardW
    Exit Function
EH:
    AppendRelationshipDiagramDrawWarning "���n�q�u���b�N��", "���v�Z������l�Ōp��: " & Err.Description
    Err.Clear
    SafeRootChildBlockWidth = cardW
End Function

Private Function DrawRootChildDescendantBlockSafe(ByVal ws As Worksheet, _
        ByVal decId As String, _
        ByVal childRowValue As Variant, _
        ByVal blockLeft As Double, _
        ByVal childTop As Double, _
        ByVal branchY As Double, _
        ByVal cardW As Double, _
        ByVal cardH As Double, _
        ByVal coupleGap As Double, _
        ByVal blockGap As Double, _
        ByVal decShape As Shape, _
        ByVal spouseShape As Shape, _
        ByVal coupleOriginX As Double, _
        ByVal coupleOriginY As Double, _
        ByVal drawn As Object) As Double
    Dim childRow As Long, childRootX As Double, childOriginX As Double, childOriginY As Double
    On Error GoTo EH
    childRow = CLng(childRowValue)
    childRootX = SafeDescendantChildCardCenterX(childRow, blockLeft, cardW, cardH, coupleGap, blockGap, 1, "���n�q�J�[�h���S")
    SafeChildLinkOriginForDiagram decId, childRow, decShape, spouseShape, coupleOriginX, coupleOriginY, childOriginX, childOriginY
    DrawVLine ws, childOriginX, childOriginY, branchY
    DrawHLine ws, MinDouble(childOriginX, childRootX), branchY, MaxDouble(childOriginX, childRootX)
    DrawVLine ws, childRootX, branchY, DescendantIncomingY(childRow, childTop, cardH)
    DrawRootChildDescendantBlockSafe = SafeDrawDescendantFamilyBlock(ws, childRow, blockLeft, childTop, cardW, cardH, coupleGap, blockGap, drawn, 1)
    Exit Function
EH:
    AppendRelationshipDiagramDrawWarning "�q���u���b�N�`��", "���n�q�u���b�N���ꕔ�X�L�b�v���Čp��: " & Err.Description
    Err.Clear
    DrawRootChildDescendantBlockSafe = childTop + cardH
End Function

Private Function SafeDrawDescendantFamilyBlock(ByVal ws As Worksheet, _
        ByVal personRow As Long, _
        ByVal blockLeft As Double, _
        ByVal blockTop As Double, _
        ByVal cardW As Double, _
        ByVal cardH As Double, _
        ByVal coupleGap As Double, _
        ByVal blockGap As Double, _
        ByVal drawn As Object, _
        ByVal depth As Long) As Double
    On Error GoTo EH
    SafeDrawDescendantFamilyBlock = DrawDescendantFamilyBlock(ws, personRow, blockLeft, blockTop, cardW, cardH, coupleGap, blockGap, drawn, depth)
    Exit Function
EH:
    AppendRelationshipDiagramDrawWarning "�q���u���b�N�`��", "�`����p��: row=" & CStr(personRow) & " / depth=" & CStr(depth) & " / " & Err.Description
    Err.Clear
    SafeDrawDescendantFamilyBlock = blockTop + cardH
End Function

Private Function SafeFamilyTreeBlockWidth(ByVal personRow As Long, _
        ByVal cardW As Double, _
        ByVal cardH As Double, _
        ByVal coupleGap As Double, _
        ByVal blockGap As Double, _
        ByVal depth As Long, _
        Optional ByVal phaseText As String = "�u���b�N��") As Double
    On Error GoTo EH
    SafeFamilyTreeBlockWidth = FamilyTreeBlockWidth(personRow, cardW, cardH, coupleGap, blockGap, depth)
    If SafeFamilyTreeBlockWidth < cardW Then SafeFamilyTreeBlockWidth = cardW
    Exit Function
EH:
    AppendRelationshipDiagramDrawWarning phaseText, "���v�Z������l�Ōp��: row=" & CStr(personRow) & " / depth=" & CStr(depth) & " / " & Err.Description
    Err.Clear
    SafeFamilyTreeBlockWidth = cardW
End Function

Private Function SafeDescendantChildCardCenterX(ByVal personRow As Long, _
        ByVal blockLeft As Double, _
        ByVal cardW As Double, _
        ByVal cardH As Double, _
        ByVal coupleGap As Double, _
        ByVal blockGap As Double, _
        ByVal depth As Long, _
        Optional ByVal phaseText As String = "�q�J�[�h���S") As Double
    On Error GoTo EH
    SafeDescendantChildCardCenterX = DescendantChildCardCenterX(personRow, blockLeft, cardW, cardH, coupleGap, blockGap, depth)
    If SafeDescendantChildCardCenterX < 1 Then SafeDescendantChildCardCenterX = blockLeft + cardW / 2
    Exit Function
EH:
    AppendRelationshipDiagramDrawWarning phaseText, "���S�v�Z������l�Ōp��: row=" & CStr(personRow) & " / depth=" & CStr(depth) & " / " & Err.Description
    Err.Clear
    SafeDescendantChildCardCenterX = blockLeft + cardW / 2
End Function

Private Sub SafeChildLinkOriginForDiagram(ByVal parentId As String, _
        ByVal childRow As Long, _
        ByVal parentShape As Shape, _
        ByVal spouseShape As Shape, _
        ByVal coupleOriginX As Double, _
        ByVal coupleOriginY As Double, _
        ByRef originX As Double, _
        ByRef originY As Double)
    On Error GoTo EH
    ChildLinkOriginForDiagram parentId, childRow, parentShape, spouseShape, coupleOriginX, coupleOriginY, originX, originY
    If originX < 1 Then originX = coupleOriginX
    If originY < 1 Then originY = coupleOriginY
    Exit Sub
EH:
    AppendRelationshipDiagramDrawWarning "�e�q���N�_", "�Аe/�v�w���N�_������l�Ōp��: row=" & CStr(childRow) & " / " & Err.Description
    Err.Clear
    originX = coupleOriginX
    originY = coupleOriginY
End Sub

Private Function MinDouble(ByVal a As Double, ByVal b As Double) As Double
    If a < b Then
        MinDouble = a
    Else
        MinDouble = b
    End If
End Function

Private Function MaxDouble(ByVal a As Double, ByVal b As Double) As Double
    If a > b Then
        MaxDouble = a
    Else
        MaxDouble = b
    End If
End Function

Private Function DiagramVerticalGapForDepth(ByVal depth As Long) As Double
    If depth <= 0 Then
        DiagramVerticalGapForDepth = 106
    ElseIf depth <= 2 Then
        DiagramVerticalGapForDepth = 112
    Else
        DiagramVerticalGapForDepth = 118
    End If
End Function

Private Function DiagramBranchOffsetForDepth(ByVal depth As Long) As Double
    If depth <= 0 Then
        DiagramBranchOffsetForDepth = 48
    ElseIf depth <= 2 Then
        DiagramBranchOffsetForDepth = 50
    Else
        DiagramBranchOffsetForDepth = 52
    End If
End Function

Private Function DrawDescendantFamilyBlock(ByVal ws As Worksheet, _
        ByVal personRow As Long, _
        ByVal blockLeft As Double, _
        ByVal blockTop As Double, _
        ByVal cardW As Double, _
        ByVal cardH As Double, _
        ByVal coupleGap As Double, _
        ByVal blockGap As Double, _
        ByVal drawn As Object, _
        ByVal depth As Long) As Double
    Dim pid As String, spouseRow As Long, ownW As Double, blockW As Double, ownLeft As Double
    Dim personShape As Shape, spouseShape As Shape, originX As Double, originY As Double
    Dim childRows As Collection, childTop As Double, branchY As Double, rowW As Double, x As Double
    Dim i As Long, childBlockW As Double, childRootX As Double, bottomY As Double, childBottom As Double
    Dim childOriginX As Double, childOriginY As Double
    On Error GoTo EH

    If personRow <= 0 Or depth > 12 Then
        DrawDescendantFamilyBlock = blockTop + cardH
        Exit Function
    End If
    pid = CStr(ThisWorkbook.Worksheets(SH_W_PERSON).Cells(personRow, P_ID).Value)
    blockW = FamilyTreeBlockWidth(personRow, cardW, cardH, coupleGap, blockGap, depth)
    spouseRow = GetSpouseRowOfPerson(pid)
    ownW = cardW
    If spouseRow > 0 And Not IsDrawnPerson(drawn, spouseRow) Then ownW = cardW * 2 + coupleGap
    ownLeft = blockLeft + (blockW - ownW) / 2

    If IsDrawnPerson(drawn, personRow) Then
        DrawDescendantFamilyBlock = blockTop + cardH
        Exit Function
    End If
    Set personShape = DrawTreeCard(ws, personRow, ownLeft, blockTop, cardW, cardH, drawn)
    If personShape Is Nothing Then
        AppendRelationshipDiagramDrawWarning "�q���u���b�N�`��", "�l���J�[�h�쐬���s row=" & CStr(personRow)
        DrawDescendantFamilyBlock = blockTop + cardH
        Exit Function
    End If
    originX = ShapeCenterX(personShape)
    originY = personShape.Top + personShape.Height
    If spouseRow > 0 Then
        If Not IsDrawnPerson(drawn, spouseRow) Then
            Set spouseShape = DrawTreeCard(ws, spouseRow, ownLeft + cardW + coupleGap, blockTop, cardW, cardH, drawn)
            If Not spouseShape Is Nothing Then
                ConnectHorizontalCouple ws, personShape, spouseShape, originX, originY
            End If
        End If
    End If
    bottomY = blockTop + cardH

    Set childRows = GetChildRowsForParent(pid)
    If childRows.Count > 0 Then
        rowW = 0
        For i = 1 To childRows.Count
            childBlockW = SafeFamilyTreeBlockWidth(CLng(childRows(i)), cardW, cardH, coupleGap, blockGap, depth + 1, "�q���s��")
            If rowW > 0 Then rowW = rowW + blockGap
            rowW = rowW + childBlockW
        Next i
        x = blockLeft + (blockW - rowW) / 2
        childTop = bottomY + DiagramVerticalGapForDepth(depth)
        branchY = childTop - DiagramBranchOffsetForDepth(depth)
        For i = 1 To childRows.Count
            childBlockW = SafeFamilyTreeBlockWidth(CLng(childRows(i)), cardW, cardH, coupleGap, blockGap, depth + 1, "�q���u���b�N��")
            childRootX = SafeDescendantChildCardCenterX(CLng(childRows(i)), x, cardW, cardH, coupleGap, blockGap, depth + 1, "�q���J�[�h���S")
            SafeChildLinkOriginForDiagram pid, CLng(childRows(i)), personShape, spouseShape, originX, originY, childOriginX, childOriginY
            DrawVLine ws, childOriginX, childOriginY, branchY
            DrawHLine ws, MinDouble(childOriginX, childRootX), branchY, MaxDouble(childOriginX, childRootX)
            DrawVLine ws, childRootX, branchY, DescendantIncomingY(CLng(childRows(i)), childTop, cardH)
            childBottom = SafeDrawDescendantFamilyBlock(ws, CLng(childRows(i)), x, childTop, cardW, cardH, coupleGap, blockGap, drawn, depth + 1)
            If childBottom > bottomY Then bottomY = childBottom
            x = x + childBlockW + blockGap
        Next i
    End If

    DrawDescendantFamilyBlock = bottomY
    Exit Function
EH:
    AppendRelationshipDiagramDrawWarning "�q���u���b�N�`��", "�u���b�N�P�ʂŌp��: row=" & CStr(personRow) & " / depth=" & CStr(depth) & " / " & Err.Description
    Err.Clear
    DrawDescendantFamilyBlock = blockTop + cardH
End Function


Private Function GetSiblingRowsForPerson(ByVal personId As String) As Collection
    Dim col As New Collection
    Dim wr As Worksheet, wp As Worksheet
    Dim r As Long, baseId As String, otherId As String, targetId As String
    If Len(personId) = 0 Then
        Set GetSiblingRowsForPerson = col
        Exit Function
    End If

    If SheetExists(SH_W_REL, ThisWorkbook) Then
        Set wr = ThisWorkbook.Worksheets(SH_W_REL)
        For r = 2 To LastRow(wr, R_ID)
            If CleanText(wr.Cells(r, R_STATUS).Value) <> STATUS_CANCEL Then
                If CleanText(wr.Cells(r, R_TYPE).Value) = "�Z��o��" Then
                    baseId = CleanText(wr.Cells(r, R_BASE_ID).Value)
                    otherId = CleanText(wr.Cells(r, R_OTHER_ID).Value)
                    targetId = ""
                    If baseId = personId Then
                        targetId = otherId
                    ElseIf otherId = personId Then
                        targetId = baseId
                    End If
                    If Len(targetId) > 0 Then AddPersonRowUnique col, FindPersonRow(targetId)
                End If
            End If
        Next r
    End If

    Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)
    For r = 2 To LastRow(wp, P_ID)
        If VisibleDiagramPersonRow(r) Then
            If CleanText(wp.Cells(r, P_ID).Value) <> personId Then
                If IsSiblingRelationText(wp.Cells(r, P_REL_DEC).Value) Then AddPersonRowUnique col, r
            End If
        End If
    Next r
    Set GetSiblingRowsForPerson = col
End Function

Private Function IsSiblingRelationText(ByVal relText As String) As Boolean
    relText = DiagramBaseRelationLabel(CleanText(relText))
    Select Case relText
        Case "�Z", "��", "�o", "��", "�Z��", "�o��", "�Z��o��"
            IsSiblingRelationText = True
    End Select
End Function

Private Function GetChildRowsForParent(ByVal parentId As String) As Collection
    Dim col As New Collection, wr As Worksheet, wp As Worksheet
    Dim r As Long, childId As String, childRow As Long, parentKey As String, resolvedParentId As String
    If Len(parentId) = 0 Then
        Set GetChildRowsForParent = col
        Exit Function
    End If

    '�e�{�l���猩���q������Ԃ��B�z��ґ������ɕR�Â��q�͍����Ȃ��B
    '�v�w�o���̎q���ǂ����͐��̋N�_����ŕʓr����B
    Set wr = ThisWorkbook.Worksheets(SH_W_REL)
    For r = 2 To LastRow(wr, 1)
        If CStr(wr.Cells(r, R_STATUS).Value) <> STATUS_CANCEL And CStr(wr.Cells(r, R_TYPE).Value) = "�e�q" Then
            If TryResolveDiagramParentChildRelationRow(wr, r, resolvedParentId, childId) Then
                If resolvedParentId = parentId Then
                    childRow = FindPersonRow(childId)
                    If ChildRowCanAppearUnderParent(childRow, parentId) Then AddPersonRowUnique col, childRow
                End If
            ElseIf CleanText(wr.Cells(r, R_BASE_ID).Value) = parentId Then
                childId = CleanText(wr.Cells(r, R_OTHER_ID).Value)
                childRow = FindPersonRow(childId)
                If DiagramExplicitParentChildRowDirectionCanBeTrusted(FindPersonRow(parentId), childRow) Then
                    If ChildRowCanAppearUnderParent(childRow, parentId) Then AddPersonRowUnique col, childRow
                End If
            End If
        End If
    Next r

    '���ŁE�r���ł�W_�֌W�̐e�q�s���������l�����A��R�Â����Ȃ��͈͂Ő}�ゾ���~�ς���B
    '�D�揇�ʂ� W_�֌W �� P_SUR_SRC�Ɏc���l��ID �� ���㐢�オ��ӂɌ��܂�ꍇ�B
    '�������̏ꍇ�͏���Ɍ��΂��AC_�`�F�b�N���̊č��Ɏc���B
    Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)
    For r = 2 To LastRow(wp, 1)
        If CStr(wp.Cells(r, P_STATUS).Value) <> STATUS_CANCEL And CStr(wp.Cells(r, P_SHOW).Value) <> SHOW_NO Then
            parentKey = InferredDiagramParentIdForChildRow(r)
            If parentKey = parentId Then
                If ChildRowCanAppearUnderParent(r, parentId) Then AddPersonRowUnique col, r
            End If
        End If
    Next r

    Set GetChildRowsForParent = col
End Function

Private Function TryResolveDiagramParentChildRelationRow(ByVal wr As Worksheet, ByVal relRow As Long, ByRef parentId As String, ByRef childId As String) As Boolean
    Dim baseId As String, otherId As String, baseRow As Long, otherRow As Long
    Dim baseRel As String, otherRel As String
    parentId = ""
    childId = ""
    If wr Is Nothing Or relRow <= 0 Then Exit Function
    If CStr(wr.Cells(relRow, R_STATUS).Value) = STATUS_CANCEL Then Exit Function
    If CStr(wr.Cells(relRow, R_TYPE).Value) <> "�e�q" Then Exit Function

    baseId = CStr(wr.Cells(relRow, R_BASE_ID).Value)
    otherId = CStr(wr.Cells(relRow, R_OTHER_ID).Value)
    If Len(baseId) = 0 Or Len(otherId) = 0 Or baseId = otherId Then Exit Function

    baseRow = FindPersonRow(baseId)
    otherRow = FindPersonRow(otherId)
    If baseRow = 0 Or otherRow = 0 Then Exit Function

    baseRel = CStr(ThisWorkbook.Worksheets(SH_W_PERSON).Cells(baseRow, P_REL_DEC).Value)
    otherRel = CStr(ThisWorkbook.Worksheets(SH_W_PERSON).Cells(otherRow, P_REL_DEC).Value)

    '�܂��������玩�R�Ȑe�q�����𔻒肷��B
    '���f�[�^�̋t�����s���ɋ~�ς��Ȃ��ƁA���Ƒ]���̐e�q�����t���������ŗ�����B
    If IsExpectedChildRelation(baseRel, otherRel) Then
        parentId = baseId
        childId = otherId
        TryResolveDiagramParentChildRelationRow = True
        Exit Function
    End If
    If IsExpectedChildRelation(otherRel, baseRel) Then
        parentId = otherId
        childId = baseId
        TryResolveDiagramParentChildRelationRow = True
        Exit Function
    End If

    '���s�o�^�� R_BASE_ID=�e / R_OTHER_ID=�q�B
    '�q���̑������������ł̂܂ܓ�����E�󂢐���Ɏc��ꍇ�́A�����s��M�����Đ������ԁB
    '�������A���ҁE���҂Ȃǂ̂��̑��֌W�l�͐e�q���֍����Ȃ��B
    If DiagramExplicitParentChildDirectionIsUsable(baseRel, otherRel) _
            Or DiagramExplicitParentChildRowDirectionCanBeTrusted(baseRow, otherRow) Then
        parentId = baseId
        childId = otherId
        TryResolveDiagramParentChildRelationRow = True
    End If
End Function

Private Function DiagramExplicitParentChildRowDirectionCanBeTrusted(ByVal parentRow As Long, ByVal childRow As Long) As Boolean
    Dim wp As Worksheet, parentId As String, childId As String
    Dim parentRel As String, childRel As String, childSourceId As String
    If parentRow <= 0 Or childRow <= 0 Then Exit Function
    Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)
    parentId = CleanText(wp.Cells(parentRow, P_ID).Value)
    childId = CleanText(wp.Cells(childRow, P_ID).Value)
    If Len(parentId) = 0 Or Len(childId) = 0 Then Exit Function
    If parentId = childId Then Exit Function
    If DiagramPersonIsOtherRelationOnly(parentRow) Then Exit Function
    If DiagramPersonIsOtherRelationOnly(childRow) Then Exit Function

    parentRel = CleanText(wp.Cells(parentRow, P_REL_DEC).Value)
    childRel = CleanText(wp.Cells(childRow, P_REL_DEC).Value)
    If IsExpectedChildRelation(parentRel, childRel) Then
        DiagramExplicitParentChildRowDirectionCanBeTrusted = True
        Exit Function
    End If
    If DiagramDescendantLevel(childRel) > 0 Then
        DiagramExplicitParentChildRowDirectionCanBeTrusted = True
        Exit Function
    End If
    If IsDirectChildRelationText(childRel) Then
        DiagramExplicitParentChildRowDirectionCanBeTrusted = True
        Exit Function
    End If
    childSourceId = CleanText(wp.Cells(childRow, P_SUR_SRC).Value)
    If childSourceId = parentId Then DiagramExplicitParentChildRowDirectionCanBeTrusted = True
End Function

Private Function DiagramPersonIsOtherRelationOnly(ByVal personRow As Long) As Boolean
    Dim wp As Worksheet, relText As String, displayRel As String, noteText As String, rawText As String, normText As String
    If personRow <= 0 Then Exit Function
    Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)
    relText = CleanText(wp.Cells(personRow, P_REL_DEC).Value)
    displayRel = CleanText(wp.Cells(personRow, P_REL_DISP).Value)
    noteText = CleanText(wp.Cells(personRow, P_NOTE).Value)
    normText = NormalizeDiagramRelationText(relText)
    If normText = "�푊���l" Or normText = "�z���" Or normText = "�O�z���" Or normText = "��" Or normText = "��" Then Exit Function
    If IsSiblingRelationText(normText) Then Exit Function
    If IsDirectChildRelationText(normText) Then Exit Function
    If DiagramDescendantLevel(normText) > 0 Then Exit Function
    If InStr(normText, "�z���") > 0 Then Exit Function
    rawText = relText & " " & displayRel & " " & noteText
    DiagramPersonIsOtherRelationOnly = DiagramRelationTextIsOtherParty(rawText)
End Function

Private Function DiagramRelationTextIsOtherParty(ByVal relText As String) As Boolean
    relText = CleanText(relText)
    If Len(relText) = 0 Then Exit Function
    If InStr(relText, "����") > 0 Then DiagramRelationTextIsOtherParty = True: Exit Function
    If InStr(relText, "����") > 0 Then DiagramRelationTextIsOtherParty = True: Exit Function
    If InStr(relText, "������") > 0 Then DiagramRelationTextIsOtherParty = True: Exit Function
    If InStr(relText, "��") > 0 Then DiagramRelationTextIsOtherParty = True: Exit Function
    If InStr(relText, "����") > 0 Then DiagramRelationTextIsOtherParty = True: Exit Function
    If InStr(relText, "����") > 0 Then DiagramRelationTextIsOtherParty = True: Exit Function
    If InStr(relText, "�㗝�l") > 0 Then DiagramRelationTextIsOtherParty = True: Exit Function
    If InStr(relText, "�֌W�l") > 0 Then DiagramRelationTextIsOtherParty = True: Exit Function
    If InStr(relText, "�֌W��") > 0 Then DiagramRelationTextIsOtherParty = True: Exit Function
    If InStr(relText, "���̑�") > 0 Then DiagramRelationTextIsOtherParty = True
End Function

Private Function DiagramExplicitParentChildDirectionIsUsable(ByVal parentRel As String, ByVal childRel As String) As Boolean
    Dim parentLevel As Long, childLevel As Long
    parentLevel = DiagramParentLevelForChildren(parentRel)
    childLevel = DiagramDescendantLevel(childRel)
    If childLevel <= 0 Then Exit Function
    If parentLevel = 0 Then
        DiagramExplicitParentChildDirectionIsUsable = (childLevel = 1)
    ElseIf parentLevel > 0 Then
        If childLevel = parentLevel + 1 Then
            DiagramExplicitParentChildDirectionIsUsable = True
        ElseIf childLevel <= parentLevel Then
            DiagramExplicitParentChildDirectionIsUsable = True
        End If
    End If
End Function

Private Function DiagramExplicitParentChildRowExists(ByVal parentId As String, ByVal childId As String) As Boolean
    Dim wr As Worksheet, r As Long, resolvedParentId As String, resolvedChildId As String
    parentId = CleanText(parentId)
    childId = CleanText(childId)
    If Len(parentId) = 0 Or Len(childId) = 0 Then Exit Function
    If parentId = childId Then Exit Function
    If Not SheetExists(SH_W_REL, ThisWorkbook) Then Exit Function
    Set wr = ThisWorkbook.Worksheets(SH_W_REL)
    For r = 2 To LastRow(wr, 1)
        If CleanText(wr.Cells(r, R_STATUS).Value) <> STATUS_CANCEL And CleanText(wr.Cells(r, R_TYPE).Value) = "�e�q" Then
            If CleanText(wr.Cells(r, R_BASE_ID).Value) = parentId Then
                If CleanText(wr.Cells(r, R_OTHER_ID).Value) = childId Then
                    DiagramExplicitParentChildRowExists = True
                    Exit Function
                End If
            End If
            If TryResolveDiagramParentChildRelationRow(wr, r, resolvedParentId, resolvedChildId) Then
                If resolvedParentId = parentId Then
                    If resolvedChildId = childId Then
                        DiagramExplicitParentChildRowExists = True
                        Exit Function
                    End If
                End If
            End If
        End If
    Next r
End Function

Private Function DiagramParentIdForChildRow(ByVal childRow As Long) As String
    Dim wr As Worksheet, r As Long, pId As String, cId As String
    Dim childId As String
    If childRow <= 0 Then Exit Function
    childId = CStr(ThisWorkbook.Worksheets(SH_W_PERSON).Cells(childRow, P_ID).Value)
    If Len(childId) = 0 Then Exit Function
    Set wr = ThisWorkbook.Worksheets(SH_W_REL)
    For r = 2 To LastRow(wr, 1)
        If TryResolveDiagramParentChildRelationRow(wr, r, pId, cId) Then
            If cId = childId Then
                DiagramParentIdForChildRow = pId
                Exit Function
            End If
        End If
    Next r
End Function

Private Function DiagramPersonIsChildOfParent(ByVal childRow As Long, ByVal parentId As String) As Boolean
    Dim wr As Worksheet, r As Long, pId As String, cId As String
    Dim childId As String
    If childRow <= 0 Or Len(parentId) = 0 Then Exit Function
    childId = CStr(ThisWorkbook.Worksheets(SH_W_PERSON).Cells(childRow, P_ID).Value)
    If Len(childId) = 0 Then Exit Function
    Set wr = ThisWorkbook.Worksheets(SH_W_REL)
    For r = 2 To LastRow(wr, 1)
        If TryResolveDiagramParentChildRelationRow(wr, r, pId, cId) Then
            If pId = parentId And cId = childId Then
                DiagramPersonIsChildOfParent = True
                Exit Function
            End If
        End If
    Next r
End Function

Private Function InferredDiagramParentIdForChildRow(ByVal childRow As Long) As String
    Dim wp As Worksheet, childId As String, existingParentId As String
    Dim relText As String, childLevel As Long, parentKey As String, decId As String
    If childRow <= 0 Then Exit Function
    Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)
    childId = CleanText(wp.Cells(childRow, P_ID).Value)
    If Len(childId) = 0 Then Exit Function

    existingParentId = DiagramParentIdForChildRow(childRow)
    If Len(existingParentId) > 0 Then
        InferredDiagramParentIdForChildRow = existingParentId
        Exit Function
    End If

    relText = NormalizeDiagramRelationText(CleanText(wp.Cells(childRow, P_REL_DEC).Value))
    childLevel = DiagramDescendantLevel(relText)
    If childLevel <= 0 Then Exit Function

    parentKey = CleanText(wp.Cells(childRow, P_SUR_SRC).Value)
    If CandidateParentMatchesChildLevel(parentKey, childId, childLevel, False, True) Then
        InferredDiagramParentIdForChildRow = parentKey
        Exit Function
    End If
    If CandidateParentMatchesChildLevel(parentKey, childId, childLevel, True, True) Then
        InferredDiagramParentIdForChildRow = parentKey
        Exit Function
    End If

    If childLevel = 1 Then
        If Not DiagramChildHasSeparateParentNote(CleanText(wp.Cells(childRow, P_REL_DEC).Value) & " " & CleanText(wp.Cells(childRow, P_REL_DISP).Value) & " " & CleanText(wp.Cells(childRow, P_NOTE).Value)) Then
            decId = GetDecedentId()
            If Len(decId) > 0 And decId <> childId Then InferredDiagramParentIdForChildRow = decId
        End If
        Exit Function
    End If

    InferredDiagramParentIdForChildRow = UniqueDiagramParentCandidateId(childId, childLevel, False)
    If Len(InferredDiagramParentIdForChildRow) = 0 Then
        InferredDiagramParentIdForChildRow = UniqueDiagramParentCandidateId(childId, childLevel, True)
    End If
End Function

Private Function CandidateParentMatchesChildLevel(ByVal candidateId As String, _
        ByVal childId As String, _
        ByVal childLevel As Long, _
        ByVal allowSpouseParent As Boolean, _
        Optional ByVal allowStaleChildLevel As Boolean = False) As Boolean
    Dim parentRow As Long, rawParentRel As String, parentLevel As Long
    candidateId = CleanText(candidateId)
    childId = CleanText(childId)
    If Len(candidateId) = 0 Or Len(childId) = 0 Then Exit Function
    If candidateId = childId Then Exit Function
    parentRow = FindPersonRow(candidateId)
    If parentRow = 0 Then Exit Function
    If Not VisibleDiagramPersonRow(parentRow) Then Exit Function
    rawParentRel = CleanText(ThisWorkbook.Worksheets(SH_W_PERSON).Cells(parentRow, P_REL_DEC).Value)
    If Not allowSpouseParent And InStr(rawParentRel, "�z���") > 0 Then Exit Function
    parentLevel = DiagramParentLevelForChildren(rawParentRel)
    If childLevel = 1 Then
        CandidateParentMatchesChildLevel = (parentLevel = 0 And candidateId = GetDecedentId())
    ElseIf parentLevel > 0 Then
        If childLevel = parentLevel + 1 Then
            CandidateParentMatchesChildLevel = True
        ElseIf allowStaleChildLevel Then
            '�o�^���̊�l��ID���c���Ă���ꍇ�����A���ł̂܂ܓ�����E�󂢐���Ɏc�����q���~�ς���B
            '��Ӑ���ł͂�����������A���E�]�����t�����Ɍ�ڑ����Ȃ��B
            CandidateParentMatchesChildLevel = (childLevel <= parentLevel)
        End If
    End If
End Function

Private Function UniqueDiagramParentCandidateId(ByVal childId As String, ByVal childLevel As Long, ByVal allowSpouseParent As Boolean) As String
    Dim wp As Worksheet, r As Long, candidateId As String, foundId As String, countFound As Long
    If childLevel <= 1 Then Exit Function
    Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)
    For r = 2 To LastRow(wp, 1)
        candidateId = CleanText(wp.Cells(r, P_ID).Value)
        If CandidateParentMatchesChildLevel(candidateId, childId, childLevel, allowSpouseParent) Then
            countFound = countFound + 1
            foundId = candidateId
            If countFound > 1 Then
                UniqueDiagramParentCandidateId = ""
                Exit Function
            End If
        End If
    Next r
    If countFound = 1 Then UniqueDiagramParentCandidateId = foundId
End Function

Private Function VisibleDiagramPersonRow(ByVal personRow As Long) As Boolean
    Dim wp As Worksheet
    If personRow <= 0 Then Exit Function
    Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)
    If Len(CleanText(wp.Cells(personRow, P_ID).Value)) = 0 Then Exit Function
    If CleanText(wp.Cells(personRow, P_STATUS).Value) = STATUS_CANCEL Then Exit Function
    If CleanText(wp.Cells(personRow, P_SHOW).Value) = SHOW_NO Then Exit Function
    VisibleDiagramPersonRow = True
End Function

Private Sub ChildLinkOriginForDiagram(ByVal parentId As String, _
        ByVal childRow As Long, _
        ByVal parentShape As Shape, _
        ByVal spouseShape As Shape, _
        ByVal coupleOriginX As Double, _
        ByVal coupleOriginY As Double, _
        ByRef originX As Double, _
        ByRef originY As Double)
    Dim spouseId As String
    If parentShape Is Nothing Then Exit Sub
    originX = ShapeCenterX(parentShape)
    originY = parentShape.Top + parentShape.Height
    If spouseShape Is Nothing Then Exit Sub
    spouseId = ShapePersonId(spouseShape)
    If Len(spouseId) = 0 Then Exit Sub

    '�v�w�u���b�N������ʏ�P�[�X�ł́A�q�ւ̐��͕v�w���������牺�낷�B
    '�O�z��ҁE�ʕ���E�A��q�ȂǁA���ݔz��҂ƕ�����ׂ����L������ꍇ�����Аe�J�[�h�N�_�ɖ߂��B
    If ChildShouldUseCoupleOriginForDiagram(childRow, spouseId) Then
        originX = coupleOriginX
        originY = coupleOriginY
    End If
End Sub

Private Function ChildShouldUseCoupleOriginForDiagram(ByVal childRow As Long, ByVal spouseId As String) As Boolean
    Dim wp As Worksheet, relAndNote As String
    If childRow <= 0 Or Len(spouseId) = 0 Then Exit Function
    Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)
    relAndNote = CleanText(wp.Cells(childRow, P_REL_DEC).Value) & " " & CleanText(wp.Cells(childRow, P_REL_DISP).Value) & " " & CleanText(wp.Cells(childRow, P_NOTE).Value)
    If DiagramChildHasSeparateParentNote(relAndNote) Then Exit Function
    ChildShouldUseCoupleOriginForDiagram = True
End Function

Private Function DiagramChildHasSeparateParentNote(ByVal relAndNote As String) As Boolean
    relAndNote = CleanText(relAndNote)
    DiagramChildHasSeparateParentNote = (InStr(relAndNote, "�O�z���") > 0 _
        Or InStr(relAndNote, "�O��") > 0 _
        Or InStr(relAndNote, "�O�v") > 0 _
        Or InStr(relAndNote, "�ʕ�") > 0 _
        Or InStr(relAndNote, "�ʕ�") > 0 _
        Or InStr(relAndNote, "�A��q") > 0)
End Function

Private Function ShapePersonId(ByVal shp As Shape) As String
    Dim altText As String
    If shp Is Nothing Then Exit Function
    On Error Resume Next
    altText = CStr(shp.AlternativeText)
    On Error GoTo 0
    If Left$(altText, 9) = "personId=" Then
        ShapePersonId = Mid$(altText, 10)
    ElseIf Left$(shp.Name, 5) = "card_" Then
        ShapePersonId = Mid$(shp.Name, 6)
    End If
End Function

Private Function FindPersonCardShape(ByVal ws As Worksheet, ByVal personId As String) As Shape
    Dim shp As Shape
    If ws Is Nothing Or Len(personId) = 0 Then Exit Function
    For Each shp In ws.Shapes
        If ShapePersonId(shp) = personId Then
            Set FindPersonCardShape = shp
            Exit Function
        End If
    Next shp
End Function

Private Function UniqueShapeName(ByVal ws As Worksheet, ByVal baseName As String) As String
    Dim i As Long, candidate As String, rootName As String
    rootName = SafeShapeNameToken(baseName)
    If Len(rootName) = 0 Then rootName = "shape"
    If Len(rootName) > 120 Then rootName = Left$(rootName, 120)
    candidate = rootName
    i = 1
    Do While ShapeNameExists(ws, candidate)
        i = i + 1
        candidate = Left$(rootName, 110) & "_" & CStr(i)
        If i > 9999 Then
            candidate = Left$(rootName, 90) & "_" & Format$(Now, "hhmmss") & "_" & CStr(i)
            Exit Do
        End If
    Loop
    UniqueShapeName = candidate
End Function

Private Function SafeShapeNameToken(ByVal rawText As String) As String
    Dim i As Long, ch As String, outText As String
    rawText = CleanText(rawText)
    If Len(rawText) = 0 Then
        SafeShapeNameToken = "shape"
        Exit Function
    End If
    For i = 1 To Len(rawText)
        ch = Mid$(rawText, i, 1)
        If ch Like "[A-Za-z0-9_]" Then
            outText = outText & ch
        Else
            outText = outText & "_"
        End If
    Next i
    Do While InStr(outText, "__") > 0
        outText = Replace(outText, "__", "_")
    Loop
    If Left$(outText, 1) = "_" Then outText = "sh" & outText
    SafeShapeNameToken = outText
End Function

Private Function SafeDiagramPoint(ByVal valuePt As Double, Optional ByVal fallbackPt As Double = 1) As Double
    If valuePt < 1 Or valuePt > 30000 Then
        SafeDiagramPoint = fallbackPt
    Else
        SafeDiagramPoint = valuePt
    End If
End Function

Private Function SafeDiagramSize(ByVal valuePt As Double, Optional ByVal fallbackPt As Double = 120) As Double
    If valuePt < 8 Or valuePt > 3000 Then
        SafeDiagramSize = fallbackPt
    Else
        SafeDiagramSize = valuePt
    End If
End Function

Private Sub AppendRelationshipDiagramDrawWarning(ByVal phaseText As String, ByVal detailText As String)
    Dim wsC As Worksheet, outR As Long
    On Error Resume Next
    RuntimeAppendLog "WARN", "�����֌W�}", phaseText, detailText, 0, detailText, ""
    If SheetExists(SH_CHECK, ThisWorkbook) Then
        Set wsC = ThisWorkbook.Worksheets(SH_CHECK)
        outR = LastRow(wsC, 1) + 1
        If outR < 4 Then outR = 4
        AddCheck wsC, outR, "�x��", "�����֌W�}�̕`����ꕔ�X�L�b�v���܂����B" & detailText, "", "", "�����֌W�}", "�l���֌W�ƏZ���������m�F"
    End If
    On Error GoTo 0
End Sub

Private Function ShapeNameExists(ByVal ws As Worksheet, ByVal shapeName As String) As Boolean
    Dim tmp As Shape
    If ws Is Nothing Or Len(shapeName) = 0 Then Exit Function
    On Error Resume Next
    Set tmp = ws.Shapes(shapeName)
    ShapeNameExists = Not tmp Is Nothing
    Set tmp = Nothing
    On Error GoTo 0
End Function

Private Function ChildRowCanAppearUnderParent(ByVal childRow As Long, ByVal parentId As String) As Boolean
    Dim wp As Worksheet, parentRow As Long
    Dim parentRel As String, childRel As String
    If childRow <= 0 Or Len(parentId) = 0 Then Exit Function
    Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)
    If CStr(wp.Cells(childRow, P_STATUS).Value) = STATUS_CANCEL Then Exit Function
    If CStr(wp.Cells(childRow, P_SHOW).Value) = SHOW_NO Then Exit Function
    If CStr(wp.Cells(childRow, P_ID).Value) = parentId Then Exit Function
    parentRow = FindPersonRow(parentId)
    If parentRow = 0 Then Exit Function
    If DiagramPersonIsOtherRelationOnly(parentRow) Then Exit Function
    If DiagramPersonIsOtherRelationOnly(childRow) Then Exit Function
    parentRel = NormalizeDiagramRelationText(CStr(wp.Cells(parentRow, P_REL_DEC).Value))
    childRel = NormalizeDiagramRelationText(CStr(wp.Cells(childRow, P_REL_DEC).Value))
    If Len(childRel) = 0 Then Exit Function
    If InStr(childRel, "�z���") > 0 Then
        If DiagramDescendantLevel(childRel) = 0 Then Exit Function
    End If
    If DiagramExplicitParentChildRowExists(parentId, CStr(wp.Cells(childRow, P_ID).Value)) Then
        ChildRowCanAppearUnderParent = True
    Else
        ChildRowCanAppearUnderParent = IsExpectedChildRelation(parentRel, childRel)
    End If
End Function

Private Function NormalizeDiagramRelationText(ByVal relText As String) As String
    Dim rawText As String
    rawText = CleanText(relText)
    relText = DiagramBaseRelationLabel(rawText)
    If Len(relText) = 0 Then Exit Function

    '���\�L�u�Б��v�u�\���v�͓ǂݍ��݌݊��Ƃ��Ď󂯂邪�A�\���E���[��̐��K�\�L�́u�]���v�ɓ��ꂷ��B
    '�u�]���̔z��҂̎q�v�u���\�L�Б��̎q�v�͔푊���l���猩�Č����B
    If RelationTextContainsGreatGrandchild(relText) Then
        If InStr(relText, "�z���") > 0 Then
            If InStr(relText, "�q") > 0 Then
                NormalizeDiagramRelationText = "����"
                Exit Function
            End If
        End If
    End If
    If InStr(relText, "�]���̎q") > 0 Or InStr(relText, "�\���̎q") > 0 Or InStr(relText, "�Б��̎q") > 0 Then
        NormalizeDiagramRelationText = "����"
        Exit Function
    End If

    If InStr(relText, "��") > 0 Then
        If Not RelationTextContainsGreatGrandchild(relText) Then
            If InStr(relText, "�z���") > 0 Then
                If InStr(relText, "�q") > 0 Then
                    NormalizeDiagramRelationText = "�]��"
                    Exit Function
                End If
            End If
            If InStr(relText, "���̎q") > 0 Then
                NormalizeDiagramRelationText = "�]��"
                Exit Function
            End If
        End If
    End If

    If IsDirectChildRelationText(relText) Then
        NormalizeDiagramRelationText = relText
    ElseIf relText = "��" Or Left$(relText, 2) = "���i" Or Left$(relText, 2) = "��(" Then
        NormalizeDiagramRelationText = "��"
    ElseIf IsGreatGrandchildRelationBase(relText) Then
        NormalizeDiagramRelationText = "�]��"
    ElseIf relText = "����" Or Left$(relText, 2) = "����" Then
        NormalizeDiagramRelationText = "����"
    Else
        NormalizeDiagramRelationText = relText
    End If
End Function

Private Function DiagramRelationDisplayText(ByVal relationText As String) As String
    Dim rawText As String, baseText As String
    rawText = CleanText(relationText)
    baseText = NormalizeDiagramRelationText(rawText)
    If Len(baseText) = 0 Then baseText = rawText
    If Len(baseText) = 0 Then Exit Function
    If InStr(rawText, "�O�z���") > 0 Then
        If InStr(baseText, "�O�z���") = 0 Then baseText = baseText & "�i�O�z��҂Ƃ̎q�j"
    End If
    If InStr(rawText, "�������ԗv�m�F") > 0 Then
        If InStr(baseText, "�������ԗv�m�F") = 0 Then baseText = baseText & "�i�������ԗv�m�F�j"
    End If
    DiagramRelationDisplayText = baseText
End Function

Private Function RelationTextContainsGreatGrandchild(ByVal relText As String) As Boolean
    relText = CleanText(relText)
    If InStr(relText, "�]��") > 0 Then
        RelationTextContainsGreatGrandchild = True
    ElseIf InStr(relText, "�\��") > 0 Then
        RelationTextContainsGreatGrandchild = True
    ElseIf InStr(relText, "�Б�") > 0 Then
        RelationTextContainsGreatGrandchild = True
    End If
End Function

Private Function IsGreatGrandchildRelationBase(ByVal relText As String) As Boolean
    relText = CleanText(relText)
    If relText = "�]��" Or Left$(relText, 2) = "�]��" Then
        IsGreatGrandchildRelationBase = True
    ElseIf relText = "�\��" Or Left$(relText, 2) = "�\��" Then
        IsGreatGrandchildRelationBase = True
    ElseIf relText = "�Б�" Or Left$(relText, 3) = "�Б�" Then
        IsGreatGrandchildRelationBase = True
    End If
End Function

Private Function DiagramBaseRelationLabel(ByVal relText As String) As String
    Dim p As Long, closeP As Long
    relText = CleanText(relText)
    p = InStr(1, relText, "�i", vbTextCompare)
    If p > 1 Then closeP = InStr(p + 1, relText, "�j", vbTextCompare)
    If p = 0 Then
        p = InStr(1, relText, "(", vbTextCompare)
        If p > 1 Then closeP = InStr(p + 1, relText, ")", vbTextCompare)
    End If
    If p > 1 And closeP = Len(relText) Then relText = Left$(relText, p - 1)
    DiagramBaseRelationLabel = relText
End Function

Private Function IsExpectedChildRelation(ByVal parentRel As String, ByVal childRel As String) As Boolean
    Dim pLevel As Long, cLevel As Long
    pLevel = DiagramParentLevelForChildren(parentRel)
    cLevel = DiagramDescendantLevel(childRel)
    If pLevel = 0 Then
        IsExpectedChildRelation = (cLevel = 1)
    ElseIf pLevel > 0 Then
        IsExpectedChildRelation = (cLevel = pLevel + 1)
    End If
End Function

Private Function DiagramParentLevelForChildren(ByVal relText As String) As Long
    Dim rawText As String, normText As String
    rawText = CleanText(relText)
    normText = NormalizeDiagramRelationText(rawText)

    If normText = "�푊���l" Or normText = "�z���" Or normText = "�O�z���" Then
        DiagramParentLevelForChildren = 0
        Exit Function
    End If

    If InStr(rawText, "�z���") > 0 Then
        If InStr(rawText, "����") > 0 Then
            DiagramParentLevelForChildren = 4
        ElseIf RelationTextContainsGreatGrandchild(rawText) Then
            DiagramParentLevelForChildren = 3
        ElseIf InStr(rawText, "��") > 0 Then
            DiagramParentLevelForChildren = 2
        ElseIf DiagramRelationContainsDirectChildLabel(rawText) Then
            DiagramParentLevelForChildren = 1
        End If
        Exit Function
    End If

    DiagramParentLevelForChildren = DiagramDescendantLevel(normText)
End Function

Private Function DiagramRelationContainsDirectChildLabel(ByVal relText As String) As Boolean
    relText = CleanText(relText)
    If InStr(relText, "���j") > 0 Or InStr(relText, "��j") > 0 Or InStr(relText, "�O�j") > 0 _
            Or InStr(relText, "�l�j") > 0 Or InStr(relText, "�ܒj") > 0 Or InStr(relText, "�Z�j") > 0 _
            Or InStr(relText, "����") > 0 Or InStr(relText, "��") > 0 Or InStr(relText, "�O��") > 0 _
            Or InStr(relText, "�l��") > 0 Or InStr(relText, "�܏�") > 0 Or InStr(relText, "�Z��") > 0 _
            Or InStr(relText, "�{�q") > 0 Or InStr(relText, "�q") > 0 Then
        DiagramRelationContainsDirectChildLabel = True
    End If
End Function

Private Function DiagramDescendantLevel(ByVal relText As String) As Long
    relText = NormalizeDiagramRelationText(relText)
    If InStr(relText, "�z���") > 0 Then Exit Function
    If IsDirectChildRelationText(relText) Then
        DiagramDescendantLevel = 1
    ElseIf relText = "��" Or Left$(relText, 2) = "���i" Then
        DiagramDescendantLevel = 2
    ElseIf IsGreatGrandchildRelationBase(relText) Then
        DiagramDescendantLevel = 3
    ElseIf relText = "����" Or Left$(relText, 2) = "����" Then
        DiagramDescendantLevel = 4
    End If
End Function

Private Sub AddPersonRowUnique(ByVal col As Collection, ByVal personRow As Long)
    Dim i As Long, pid As String, existingId As String
    If personRow <= 0 Then Exit Sub
    pid = CStr(ThisWorkbook.Worksheets(SH_W_PERSON).Cells(personRow, P_ID).Value)
    If Len(pid) = 0 Then Exit Sub
    For i = 1 To col.Count
        existingId = CStr(ThisWorkbook.Worksheets(SH_W_PERSON).Cells(CLng(col(i)), P_ID).Value)
        If existingId = pid Then Exit Sub
    Next i
    col.Add personRow
End Sub

Private Function FamilyBlockWidth(ByVal childRow As Long, ByVal cardW As Double, ByVal coupleGap As Double) As Double
    Dim childId As String, spouseRow As Long
    childId = CStr(ThisWorkbook.Worksheets(SH_W_PERSON).Cells(childRow, P_ID).Value)
    spouseRow = GetSpouseRowOfPerson(childId)
    If spouseRow > 0 Then
        FamilyBlockWidth = cardW * 2 + coupleGap
    Else
        FamilyBlockWidth = cardW
    End If
End Function

Private Function DrawHorizontalChildFamilyBlock(ByVal ws As Worksheet, _
        ByVal childRow As Long, _
        ByVal blockLeft As Double, _
        ByVal blockTop As Double, _
        ByVal cardW As Double, _
        ByVal cardH As Double, _
        ByVal coupleGap As Double, _
        ByVal blockGap As Double, _
        ByVal drawn As Object) As Double
    Dim childShape As Shape, spouseShape As Shape
    Dim childId As String, spouseRow As Long, originX As Double, originY As Double
    Dim gcRows As Collection, rowCount As Long, firstIndex As Long, col As Long
    Dim gW As Double, startX As Double, gX As Double, gTop As Double, branchY As Double, bottomY As Double
    Dim gcBlockW As Double, gcCenterX As Double, gcBottom As Double
    childId = CStr(ThisWorkbook.Worksheets(SH_W_PERSON).Cells(childRow, P_ID).Value)
    Set childShape = DrawTreeCard(ws, childRow, blockLeft, blockTop, cardW, cardH, drawn)
    originX = ShapeCenterX(childShape)
    originY = blockTop + cardH
    bottomY = blockTop + cardH

    spouseRow = GetSpouseRowOfPerson(childId)
    If spouseRow > 0 And Not IsDrawnPerson(drawn, spouseRow) Then
        Set spouseShape = DrawTreeCard(ws, spouseRow, blockLeft + cardW + coupleGap, blockTop, cardW, cardH, drawn)
        ConnectHorizontalCouple ws, childShape, spouseShape, originX, originY
        bottomY = blockTop + cardH
    End If

    Set gcRows = GetGrandchildRowsForParent(childId)
    If gcRows.Count > 0 Then
        gTop = bottomY + 58
        firstIndex = 1
        Do While firstIndex <= gcRows.Count
            rowCount = Application.Min(2, gcRows.Count - firstIndex + 1)
            gW = 0
            For col = 0 To rowCount - 1
                If col > 0 Then gW = gW + blockGap
                gW = gW + FamilyBlockWidth(CLng(gcRows(firstIndex + col)), cardW, coupleGap)
            Next col
            startX = blockLeft + (FamilyBlockWidth(childRow, cardW, coupleGap) - gW) / 2
            branchY = gTop - 30
            DrawVLine ws, originX, originY, branchY
            gX = startX
            For col = 0 To rowCount - 1
                gcBlockW = FamilyBlockWidth(CLng(gcRows(firstIndex + col)), cardW, coupleGap)
                gcCenterX = gX + gcBlockW / 2
                DrawHLine ws, Application.Min(originX, gcCenterX), branchY, Application.Max(originX, gcCenterX)
                DrawVLine ws, gcCenterX, branchY, gTop
                gcBottom = DrawGrandchildFamilyBlock(ws, CLng(gcRows(firstIndex + col)), gX, gTop, cardW, cardH, coupleGap, drawn)
                If gcBottom > bottomY Then bottomY = gcBottom
                gX = gX + gcBlockW + blockGap
            Next col
            originY = branchY
            firstIndex = firstIndex + rowCount
            gTop = bottomY + 34
        Loop
    End If
    DrawHorizontalChildFamilyBlock = bottomY
End Function

Private Function DrawGrandchildFamilyBlock(ByVal ws As Worksheet, _
        ByVal gcRow As Long, _
        ByVal blockLeft As Double, _
        ByVal blockTop As Double, _
        ByVal cardW As Double, _
        ByVal cardH As Double, _
        ByVal coupleGap As Double, _
        ByVal drawn As Object) As Double
    Dim gcShape As Shape, spouseShape As Shape
    Dim gcId As String, spouseRow As Long, originX As Double, originY As Double
    gcId = CStr(ThisWorkbook.Worksheets(SH_W_PERSON).Cells(gcRow, P_ID).Value)
    If IsDrawnPerson(drawn, gcRow) Then
        DrawGrandchildFamilyBlock = blockTop + cardH
        Exit Function
    End If
    Set gcShape = DrawTreeCard(ws, gcRow, blockLeft, blockTop, cardW, cardH, drawn)
    originX = ShapeCenterX(gcShape)
    originY = blockTop + cardH
    spouseRow = GetSpouseRowOfPerson(gcId)
    If spouseRow > 0 And Not IsDrawnPerson(drawn, spouseRow) Then
        Set spouseShape = DrawTreeCard(ws, spouseRow, blockLeft + cardW + coupleGap, blockTop, cardW, cardH, drawn)
        ConnectHorizontalCouple ws, gcShape, spouseShape, originX, originY
    End If
    DrawGrandchildFamilyBlock = blockTop + cardH
End Function

Private Function DrawRemainingVisiblePersons(ByVal ws As Worksheet, _
        ByVal drawn As Object, _
        ByVal leftPt As Double, _
        ByVal topPt As Double, _
        ByVal cardW As Double, _
        ByVal cardH As Double, _
        ByVal gapPt As Double, _
        ByVal rightLimit As Double) As Double
    Dim wp As Worksheet, r As Long, x As Double, y As Double, maxBottom As Double
    Dim hasAny As Boolean, labelShape As Shape
    Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)
    x = leftPt
    y = topPt
    maxBottom = y

    For r = 2 To LastRow(wp, 1)
        If CStr(wp.Cells(r, P_STATUS).Value) <> STATUS_CANCEL And CStr(wp.Cells(r, P_SHOW).Value) <> SHOW_NO Then
            If Not IsDrawnPerson(drawn, r) Then
                hasAny = True
                Exit For
            End If
        End If
    Next r
    If Not hasAny Then
        DrawRemainingVisiblePersons = topPt
        Exit Function
    End If

    Set labelShape = ws.Shapes.AddShape(msoShapeRoundedRectangle, leftPt, y, Application.Min(420, rightLimit - leftPt), 28)
    With labelShape
        .Name = "diagram_unresolved_label"
        .Placement = xlFreeFloating
        .Locked = True
        .Fill.ForeColor.RGB = ThemeColor("surface-soft")
        .Line.ForeColor.RGB = ThemeColor("border-strong")
        .Line.Weight = 0.9
        SafeApplyShapeText labelShape, "���̑��̊֌W�l", 9.2, ThemeColor("muted-strong"), True, msoAlignCenter, msoAnchorMiddle, 2, 2, 0, 0, True, 0
        .PrintObject = True
    End With
    y = y + 42
    maxBottom = y

    For r = 2 To LastRow(wp, 1)
        If CStr(wp.Cells(r, P_STATUS).Value) <> STATUS_CANCEL And CStr(wp.Cells(r, P_SHOW).Value) <> SHOW_NO Then
            If Not IsDrawnPerson(drawn, r) Then
                If x + cardW > rightLimit Then
                    x = leftPt
                    y = y + cardH + 28
                End If
                If DiagramPersonRequiresLine(r) Then AppendDiagramUnresolvedCheck r
                DrawTreeCard ws, r, x, y, cardW, cardH, drawn
                If y + cardH > maxBottom Then maxBottom = y + cardH
                x = x + cardW + gapPt
            End If
        End If
    Next r
    DrawRemainingVisiblePersons = maxBottom
End Function


Private Function DiagramPersonRequiresLine(ByVal personRow As Long) As Boolean
    Dim relText As String, normRel As String
    If personRow <= 0 Then Exit Function
    relText = CleanText(ThisWorkbook.Worksheets(SH_W_PERSON).Cells(personRow, P_REL_DEC).Value)
    normRel = NormalizeDiagramRelationText(relText)
    Select Case normRel
        Case "��", "��", "�z���", "�O�z���"
            DiagramPersonRequiresLine = True
            Exit Function
    End Select
    If DiagramDescendantLevel(relText) > 0 Then
        DiagramPersonRequiresLine = True
    ElseIf IsSiblingRelationText(relText) Then
        DiagramPersonRequiresLine = True
    End If
End Function

Private Sub AppendDiagramUnresolvedCheck(ByVal personRow As Long)
    Dim wsC As Worksheet, outR As Long, pid As String, nameText As String
    On Error GoTo SafeExit
    If personRow <= 0 Then Exit Sub
    If Not SheetExists(SH_CHECK, ThisWorkbook) Then Exit Sub
    Set wsC = ThisWorkbook.Worksheets(SH_CHECK)
    pid = CStr(ThisWorkbook.Worksheets(SH_W_PERSON).Cells(personRow, P_ID).Value)
    nameText = CStr(ThisWorkbook.Worksheets(SH_W_PERSON).Cells(personRow, P_DISPLAY).Value)
    outR = LastRow(wsC, 1) + 1
    If outR < 4 Then outR = 4
    AddCheck wsC, outR, "�G���[", "�����֌W�}�Őe�q�����m��ł��������\�����܂����B", _
        pid, nameText, "�����֌W�}", "��l������q�Ƃ��ēo�^���������֌W�\���m�F"
SafeExit:
End Sub

Private Sub ConnectHorizontalCouple(ByVal ws As Worksheet, ByVal leftShape As Shape, ByVal rightShape As Shape, ByRef originX As Double, ByRef originY As Double)
    On Error GoTo EH
    If leftShape Is Nothing Or rightShape Is Nothing Then Exit Sub
    originY = ShapeCenterY(leftShape)
    originX = (leftShape.Left + leftShape.Width + rightShape.Left) / 2
    DrawHLine ws, leftShape.Left + leftShape.Width, originY, rightShape.Left
    Exit Sub
EH:
    AppendRelationshipDiagramDrawWarning "�v�w���`��", "�v�w�����X�L�b�v: " & Err.Description
    Err.Clear
End Sub

Private Function DrawPortraitChildFamilyBlock(ByVal ws As Worksheet, _
        ByVal childRow As Long, _
        ByVal childX As Double, _
        ByVal childTop As Double, _
        ByVal cardW As Double, _
        ByVal cardH As Double, _
        ByVal smallW As Double, _
        ByVal smallH As Double) As Double
    Dim childShape As Shape, spouseShape As Shape
    Dim spouseRow As Long, childId As String, gcRows As Collection
    Dim bottomY As Double, i As Long, gTop As Double, gX As Double
    Dim lineStartY As Double
    childId = CStr(ThisWorkbook.Worksheets(SH_W_PERSON).Cells(childRow, P_ID).Value)
    Set childShape = DrawPersonCardShape(ws, childRow, childX, childTop, cardW, cardH)
    bottomY = childTop + cardH

    spouseRow = GetSpouseRowOfPerson(childId)
    If spouseRow > 0 Then
        Set spouseShape = DrawPersonCardShape(ws, spouseRow, childX, bottomY + 10, cardW, cardH)
        DrawVLine ws, ShapeCenterX(childShape), bottomY, spouseShape.Top
        bottomY = spouseShape.Top + spouseShape.Height
    End If

    Set gcRows = GetGrandchildRowsForParent(childId)
    If gcRows.Count > 0 Then
        DrawVLine ws, childX + cardW / 2, bottomY, bottomY + 18
        For i = 1 To gcRows.Count
            gX = childX + (cardW - smallW) / 2
            gTop = bottomY + 20 + (i - 1) * (smallH + 8)
            If i = 1 Then
                lineStartY = bottomY + 18
            Else
                lineStartY = gTop - 8
            End If
            DrawVLine ws, childX + cardW / 2, lineStartY, gTop
            DrawPersonCardShape ws, CLng(gcRows(i)), gX, gTop, smallW, smallH
        Next i
        bottomY = bottomY + 20 + gcRows.Count * smallH + (gcRows.Count - 1) * 8
    End If
    DrawPortraitChildFamilyBlock = bottomY
End Function

Private Function EstimateChildFamilyBlockHeight(ByVal childRow As Long, ByVal cardH As Double) As Double
    Dim childId As String, spouseRow As Long, gcRows As Collection, h As Double, gcH As Double
    childId = CStr(ThisWorkbook.Worksheets(SH_W_PERSON).Cells(childRow, P_ID).Value)
    spouseRow = GetSpouseRowOfPerson(childId)
    h = cardH
    If spouseRow > 0 Then h = h + 16 + cardH
    Set gcRows = GetGrandchildRowsForParent(childId)
    If Not gcRows Is Nothing Then
        If gcRows.Count > 0 Then
            gcH = cardH + (gcRows.Count - 1) * (cardH + 18)
            If gcH > h Then h = gcH
        End If
    End If
    EstimateChildFamilyBlockHeight = Application.Max(cardH, h)
End Function

Private Sub WarnDiagramIfCardCollisions(ByVal ws As Worksheet)
    Dim i As Long, j As Long, a As Shape, b As Shape, msg As String, nr As Long
    If ws Is Nothing Then Exit Sub
    For i = 1 To ws.Shapes.Count
        Set a = ws.Shapes(i)
        If Left$(a.Name, 5) = "card_" Then
            For j = i + 1 To ws.Shapes.Count
                Set b = ws.Shapes(j)
                If Left$(b.Name, 5) = "card_" Then
                    If ShapesOverlap(a, b, 14) Then
                        msg = "�����֌W�}�̃J�[�h�d�Ȃ��₪����܂��B�l���������ꍇ�͏o�̓v���r���[�Ŋm�F���Ă�������: " & a.Name & " / " & b.Name
                        If SheetExists(SH_CHECK) Then
                            nr = LastRow(ThisWorkbook.Worksheets(SH_CHECK), 1) + 1
                            If nr < 2 Then nr = 2
                            ThisWorkbook.Worksheets(SH_CHECK).Cells(nr, 1).Value = "�x��"
                            ThisWorkbook.Worksheets(SH_CHECK).Cells(nr, 2).Value = "�����֌W�����}"
                            ThisWorkbook.Worksheets(SH_CHECK).Cells(nr, 3).Value = msg
                        End If
                        AddDiagramLayoutWarning ws, msg
                        Exit Sub
                    End If
                End If
            Next j
        End If
    Next i
End Sub

Private Function ShapesOverlap(ByVal a As Shape, ByVal b As Shape, Optional ByVal marginPt As Double = 0) As Boolean
    ShapesOverlap = Not (a.Left + a.Width + marginPt < b.Left Or b.Left + b.Width + marginPt < a.Left Or _
                         a.Top + a.Height + marginPt < b.Top Or b.Top + b.Height + marginPt < a.Top)
End Function

Private Sub WarnDiagramIfPrintBoundsRisk(ByVal ws As Worksheet)
    Dim shp As Shape
    Dim maxRight As Double, maxBottom As Double
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    For Each shp In ws.Shapes
        If Not ThemeIsButtonShape(shp) Then
            If shp.Left + shp.Width > maxRight Then maxRight = shp.Left + shp.Width
            If shp.Top + shp.Height > maxBottom Then maxBottom = shp.Top + shp.Height
        End If
    Next shp
    If maxRight > 1100 Or maxBottom > 1500 Then
        AddDiagramLayoutWarning ws, "�����֌W�}���傫�����߁A�����A4���̕����y�[�W�ɂȂ�\��������܂��B�}���������ׂ����ǐ���D�悵�܂��B"
    End If
    On Error GoTo 0
End Sub

Private Sub AddDiagramLayoutWarning(ByVal ws As Worksheet, ByVal msg As String)
    RuntimeAppendLog "WARN", "�����֌W�}", "���C�A�E�g", msg, 0, "", ""
End Sub

Private Function IsRelationshipDiagramNonPrintableControl(ByVal shp As Shape) As Boolean
    Dim textValue As String, nm As String
    If shp Is Nothing Then Exit Function
    On Error Resume Next
    nm = LCase$(shp.Name)
    textValue = CleanText(SafeGetShapeText(shp))
    On Error GoTo 0
    If ThemeIsButtonShape(shp) Then
        IsRelationshipDiagramNonPrintableControl = True
    ElseIf InStr(1, nm, "btn", vbTextCompare) > 0 Then
        IsRelationshipDiagramNonPrintableControl = True
    ElseIf InStr(1, textValue, "���֖͂߂�", vbTextCompare) > 0 Then
        IsRelationshipDiagramNonPrintableControl = True
    ElseIf InStr(1, textValue, "�߂�", vbTextCompare) > 0 And InStr(1, textValue, "����", vbTextCompare) > 0 Then
        IsRelationshipDiagramNonPrintableControl = True
    End If
End Function

Private Sub PolishRelationshipDiagramOutput(ByVal ws As Worksheet)
    Dim shp As Shape
    Dim maxBottom As Double, maxRight As Double
    Dim printRows As Long, printCols As Long, decId As String, fitWide As Long
    Dim useLandscape As Boolean
    If ws Is Nothing Then Exit Sub
    decId = GetDecedentId()
    maxBottom = 0
    maxRight = 0
    On Error Resume Next
    For Each shp In ws.Shapes
        If IsRelationshipDiagramNonPrintableControl(shp) Then
            shp.PrintObject = False
        Else
            shp.PrintObject = True
            If shp.Top + shp.Height > maxBottom Then maxBottom = shp.Top + shp.Height
            If shp.Left + shp.Width > maxRight Then maxRight = shp.Left + shp.Width
            If shp.Type = msoLine Then
                shp.Line.ForeColor.RGB = ThemeColor("text")
                shp.Line.Weight = 1.05
            ElseIf Left$(shp.Name, 5) = "card_" Or Left$(shp.Name, 9) = "cardname_" Then
                If ShapePersonId(shp) = decId Then
                    shp.Line.ForeColor.RGB = ThemeColor("title")
                    shp.Line.Weight = 2.4
                Else
                    shp.Line.ForeColor.RGB = ThemeColor("text")
                    If Left$(shp.Name, 9) = "cardname_" Then
                        shp.Line.Weight = 0.8
                    Else
                        shp.Line.Weight = 1.35
                    End If
                End If
                shp.Shadow.Visible = msoFalse
                shp.TextFrame2.TextRange.Font.Fill.ForeColor.RGB = ThemeColor("text")
            End If
        End If
    Next shp
    If maxBottom < 120 Then maxBottom = 120
    If maxRight < 420 Then maxRight = 420
    printRows = Application.Max(18, CLng((maxBottom + 30) / 14.2) + 1)
    If printRows > 520 Then printRows = 520
    printCols = PrintColumnForRightPoint(ws, maxRight + 30)
    If printCols < 16 Then printCols = 16

    If mRelationshipDiagramHasPlan Then
        useLandscape = mRelationshipDiagramLandscape
    Else
        useLandscape = (maxRight >= maxBottom * 0.72)
    End If
    fitWide = PagesNeededForPointWidth(maxRight + 30, useLandscape)
    If mRelationshipDiagramFitWideHint > fitWide Then fitWide = mRelationshipDiagramFitWideHint
    If fitWide < 1 Then fitWide = 1

    MarkOutputNavigationShapesNonPrintable ws
    ThemeApplyMonochromePrint ws, ws.Range(ws.Cells(1, 1), ws.Cells(printRows, printCols)).Address, useLandscape, "", fitWide, 0
    MarkOutputNavigationShapesNonPrintable ws
    ws.PageSetup.CenterHorizontally = True
    ws.PageSetup.CenterVertically = False
    ThemeLockShapeLayer ws
    MarkOutputNavigationShapesNonPrintable ws
    On Error GoTo 0
End Sub

Private Sub MarkOutputNavigationShapesNonPrintable(ByVal ws As Worksheet)
    Dim shp As Shape, captionText As String
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    For Each shp In ws.Shapes
        captionText = ""
        captionText = SafeGetShapeText(shp)
        If Len(shp.OnAction) > 0 Or InStr(1, captionText, "���֖͂߂�", vbTextCompare) > 0 Or InStr(1, shp.Name, "btn_", vbTextCompare) > 0 Then
            shp.PrintObject = False
            shp.Placement = xlMoveAndSize
        End If
    Next shp
    On Error GoTo 0
End Sub

Private Function PrintColumnForRightPoint(ByVal ws As Worksheet, ByVal rightPt As Double) As Long
    Dim c As Long, maxScan As Long
    If ws Is Nothing Then Exit Function
    maxScan = 256
    If ws.Columns.Count < maxScan Then maxScan = ws.Columns.Count
    For c = 1 To maxScan
        If ws.Cells(1, c).Left + ws.Cells(1, c).Width >= rightPt Then
            PrintColumnForRightPoint = c
            Exit Function
        End If
    Next c
    PrintColumnForRightPoint = maxScan
End Function

Private Function DrawPersonCardShape(ByVal ws As Worksheet, _
        ByVal personRow As Long, _
        ByVal leftPt As Double, _
        ByVal topPt As Double, _
        ByVal widthPt As Double, _
        ByVal heightPt As Double) As Shape
    Dim wp As Worksheet
    Dim cardBase As Shape, headerBand As Shape, nameBox As Shape, bodyBox As Shape, badgeShape As Shape, accentBar As Shape
    Dim bodyPanel As Shape, dividerLine As Shape
    Dim displayName As String, bodyText As String, pid As String, relText As String, badgeText As String
    Dim headerH As Double, padX As Double, badgeW As Double, badgeH As Double
    Dim nameW As Double, bodyTop As Double, bodyH As Double, bodyFontSize As Double
    If ws Is Nothing Then Exit Function
    If personRow <= 0 Then Exit Function
    Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)
    pid = CStr(wp.Cells(personRow, P_ID).Value)
    displayName = DiagramCardTitleText(personRow)
    relText = CStr(wp.Cells(personRow, P_REL_DEC).Value)
    bodyText = DiagramCardBodyText(personRow)
    badgeText = CardBadgeText(relText)

    leftPt = SafeDiagramPoint(leftPt, 12)
    topPt = SafeDiagramPoint(topPt, 12)
    widthPt = SafeDiagramSize(widthPt, 190)
    heightPt = SafeDiagramSize(heightPt, 180)
    headerH = CardHeaderHeight(widthPt, heightPt)
    If Len(displayName) >= 18 Then headerH = Application.Max(headerH, 56)
    If Len(displayName) >= 28 Then headerH = Application.Max(headerH, 72)
    padX = 16
    badgeH = 25
    badgeW = CardBadgeWidth(badgeText)
    nameW = widthPt - padX * 2 - badgeW - 10
    If nameW < 110 Then nameW = widthPt - padX * 2
    bodyTop = topPt + headerH + 20
    bodyH = heightPt - headerH - 46
    If bodyH < 56 Then bodyH = 56
    bodyFontSize = CardFontSizeForShape(bodyText, widthPt, bodyH)

    On Error GoTo EH
    Set cardBase = ws.Shapes.AddShape(msoShapeRoundedRectangle, leftPt, topPt, widthPt, heightPt)
    On Error Resume Next
    With cardBase
        .Name = UniqueShapeName(ws, "card_" & pid)
        .AlternativeText = "personId=" & pid
        .Placement = xlFreeFloating
        .Locked = True
        .Fill.ForeColor.RGB = CardFillColor(relText)
        If NormalizeDiagramRelationText(relText) = "�푊���l" Then
            .Line.ForeColor.RGB = ThemeColor("title")
            .Line.Weight = 2.6
        Else
            .Line.ForeColor.RGB = ThemeColor("border-strong")
            .Line.Weight = 1.15
        End If
        .Shadow.Visible = msoFalse
        .PrintObject = True
        .ZOrder msoBringToFront
    End With
    Err.Clear
    On Error GoTo EH
    SafeClearShapeText cardBase

    Set headerBand = ws.Shapes.AddShape(msoShapeRectangle, leftPt + 1.6, topPt + 1.6, widthPt - 3.2, headerH)
    On Error Resume Next
    With headerBand
        .Name = UniqueShapeName(ws, "band_" & pid)
        .AlternativeText = "cardPart=header;" & pid
        .Placement = xlFreeFloating
        .Locked = True
        .Fill.ForeColor.RGB = CardHeaderFillColor(relText)
        .Line.Visible = msoFalse
        .PrintObject = True
        .ZOrder msoBringToFront
    End With
    Err.Clear
    On Error GoTo EH
    SafeClearShapeText headerBand

    Set accentBar = ws.Shapes.AddShape(msoShapeRectangle, leftPt + 1.6, topPt + 1.6, 4.2, heightPt - 3.2)
    On Error Resume Next
    With accentBar
        .Name = UniqueShapeName(ws, "accent_" & pid)
        .AlternativeText = "cardPart=accent;" & pid
        .Placement = xlFreeFloating
        .Locked = True
        .Fill.ForeColor.RGB = CardAccentColor(relText)
        .Line.Visible = msoFalse
        .PrintObject = True
        .ZOrder msoBringToFront
    End With
    Err.Clear
    On Error GoTo EH
    SafeClearShapeText accentBar

    Set nameBox = ws.Shapes.AddTextbox(msoTextOrientationHorizontal, leftPt + padX, topPt + 6, nameW, headerH - 9)
    On Error Resume Next
    With nameBox
        .Name = UniqueShapeName(ws, "name_" & pid)
        .AlternativeText = "cardPart=name;" & pid
        .Placement = xlFreeFloating
        .Locked = True
        .Fill.Visible = msoFalse
        .Line.Visible = msoFalse
        .PrintObject = True
        .ZOrder msoBringToFront
    End With
    Err.Clear
    On Error GoTo EH
    SafeApplyShapeText nameBox, displayName, CardTitleFontSizeForName(displayName, nameW), ThemeColor("title"), True, msoAlignLeft, msoAnchorMiddle, 2, 2, 2, 2, True, 0

    If Len(badgeText) > 0 Then
        Set badgeShape = ws.Shapes.AddShape(msoShapeRoundedRectangle, leftPt + widthPt - padX - badgeW, topPt + 9, badgeW, badgeH)
        On Error Resume Next
        With badgeShape
            .Name = UniqueShapeName(ws, "badge_" & pid)
            .AlternativeText = "cardPart=badge;" & pid
            .Placement = xlFreeFloating
            .Locked = True
            .Fill.ForeColor.RGB = CardBadgeFillColor(relText)
            .Line.ForeColor.RGB = CardAccentColor(relText)
            .Line.Weight = 0.8
            .PrintObject = True
            .ZOrder msoBringToFront
        End With
        Err.Clear
        On Error GoTo EH
        SafeApplyShapeText badgeShape, badgeText, CardBadgeFontSize(badgeText), CardBadgeFontColor(relText), True, msoAlignCenter, msoAnchorMiddle, 2, 2, 0, 0, True, 0
    End If

    Set dividerLine = ws.Shapes.AddLine(leftPt + padX, topPt + headerH + 5, leftPt + widthPt - padX, topPt + headerH + 5)
    On Error Resume Next
    With dividerLine
        .Name = UniqueShapeName(ws, "divider_" & pid)
        .AlternativeText = "cardPart=divider;" & pid
        .Placement = xlFreeFloating
        .Locked = True
        .Line.ForeColor.RGB = ThemeColor("border")
        .Line.Weight = 0.75
        .PrintObject = True
        .ZOrder msoBringToFront
    End With
    Err.Clear
    On Error GoTo EH

    Set bodyPanel = ws.Shapes.AddShape(msoShapeRoundedRectangle, leftPt + padX - 5, bodyTop - 5, widthPt - padX * 2 + 10, bodyH + 10)
    On Error Resume Next
    With bodyPanel
        .Name = UniqueShapeName(ws, "bodypanel_" & pid)
        .AlternativeText = "cardPart=bodyPanel;" & pid
        .Placement = xlFreeFloating
        .Locked = True
        .Fill.ForeColor.RGB = ThemeColor("surface")
        .Line.ForeColor.RGB = ThemeColor("border-soft")
        .Line.Weight = 0.6
        .PrintObject = True
        .ZOrder msoBringToFront
    End With
    Err.Clear
    On Error GoTo EH
    SafeClearShapeText bodyPanel

    Set bodyBox = ws.Shapes.AddTextbox(msoTextOrientationHorizontal, leftPt + padX, bodyTop, widthPt - padX * 2, bodyH)
    On Error Resume Next
    With bodyBox
        .Name = UniqueShapeName(ws, "body_" & pid)
        .AlternativeText = "cardPart=body;" & pid
        .Placement = xlFreeFloating
        .Locked = True
        .Fill.Visible = msoFalse
        .Line.Visible = msoFalse
        .PrintObject = True
        .ZOrder msoBringToFront
    End With
    Err.Clear
    On Error GoTo EH
    SafeApplyShapeText bodyBox, bodyText, bodyFontSize, ThemeColor("text"), False, msoAlignLeft, msoAnchorTop, 0, 0, 0, 0, True, 2.4
    EmphasizeCardBodyLabels bodyBox, bodyText

    Set DrawPersonCardShape = cardBase
    Exit Function
EH:
    AppendRelationshipDiagramDrawWarning "�l���J�[�h�`��", "�l��ID=" & pid & " / " & Err.Description
    Err.Clear
End Function

Private Sub SafeClearShapeText(ByVal shp As Shape)
    If shp Is Nothing Then Exit Sub
    On Error Resume Next
    Err.Clear
    shp.TextFrame2.TextRange.Text = ""
    If Err.Number <> 0 Then
        Err.Clear
        shp.TextFrame.Characters.Text = ""
    End If
    Err.Clear
    On Error GoTo 0
End Sub

Private Sub SafeApplyShapeText(ByVal shp As Shape, _
        ByVal textValue As String, _
        ByVal fontSize As Double, _
        ByVal fontColor As Long, _
        Optional ByVal isBold As Boolean = False, _
        Optional ByVal horizontalAlign As Long = msoAlignLeft, _
        Optional ByVal verticalAnchor As Long = msoAnchorTop, _
        Optional ByVal marginLeftPt As Double = 0, _
        Optional ByVal marginRightPt As Double = 0, _
        Optional ByVal marginTopPt As Double = 0, _
        Optional ByVal marginBottomPt As Double = 0, _
        Optional ByVal useWordWrap As Boolean = True, _
        Optional ByVal spaceAfterPt As Double = 0)
    Dim textFrame2Ok As Boolean
    If shp Is Nothing Then Exit Sub
    If fontSize <= 0 Then fontSize = 9

    On Error Resume Next
    Err.Clear
    shp.TextFrame2.TextRange.Text = CStr(textValue)
    textFrame2Ok = (Err.Number = 0)
    If textFrame2Ok Then
        shp.TextFrame2.TextRange.Font.Name = THEME_FONT
        shp.TextFrame2.TextRange.Font.Size = fontSize
        shp.TextFrame2.TextRange.Font.Bold = isBold
        shp.TextFrame2.TextRange.Font.Fill.ForeColor.RGB = fontColor
        If useWordWrap Then
            shp.TextFrame2.WordWrap = msoTrue
        Else
            shp.TextFrame2.WordWrap = msoFalse
        End If
        shp.TextFrame2.AutoSize = msoAutoSizeNone
        shp.TextFrame2.VerticalAnchor = verticalAnchor
        shp.TextFrame2.TextRange.ParagraphFormat.Alignment = horizontalAlign
        If spaceAfterPt > 0 Then shp.TextFrame2.TextRange.ParagraphFormat.SpaceAfter = spaceAfterPt
        shp.TextFrame2.MarginLeft = marginLeftPt
        shp.TextFrame2.MarginRight = marginRightPt
        shp.TextFrame2.MarginTop = marginTopPt
        shp.TextFrame2.MarginBottom = marginBottomPt
    End If

    If Err.Number <> 0 Or Not textFrame2Ok Then
        Err.Clear
        shp.TextFrame.Characters.Text = CStr(textValue)
        shp.TextFrame.Characters.Font.Name = THEME_FONT
        shp.TextFrame.Characters.Font.Size = fontSize
        shp.TextFrame.Characters.Font.Bold = isBold
        shp.TextFrame.Characters.Font.Color = fontColor
        shp.TextFrame.HorizontalAlignment = LegacyHorizontalAlignmentForShapeText(horizontalAlign)
        shp.TextFrame.VerticalAlignment = LegacyVerticalAlignmentForShapeText(verticalAnchor)
        shp.TextFrame.MarginLeft = marginLeftPt
        shp.TextFrame.MarginRight = marginRightPt
        shp.TextFrame.MarginTop = marginTopPt
        shp.TextFrame.MarginBottom = marginBottomPt
        shp.TextFrame.AutoSize = False
    End If
    Err.Clear
    On Error GoTo 0
End Sub

Private Function SafeGetShapeText(ByVal shp As Shape) As String
    If shp Is Nothing Then Exit Function
    On Error Resume Next
    Err.Clear
    SafeGetShapeText = CStr(shp.TextFrame2.TextRange.Text)
    If Err.Number <> 0 Then
        Err.Clear
        SafeGetShapeText = CStr(shp.TextFrame.Characters.Text)
    End If
    Err.Clear
    On Error GoTo 0
End Function

Private Function LegacyHorizontalAlignmentForShapeText(ByVal horizontalAlign As Long) As Long
    Select Case horizontalAlign
        Case msoAlignCenter
            LegacyHorizontalAlignmentForShapeText = xlHAlignCenter
        Case msoAlignRight
            LegacyHorizontalAlignmentForShapeText = xlHAlignRight
        Case Else
            LegacyHorizontalAlignmentForShapeText = xlHAlignLeft
    End Select
End Function

Private Function LegacyVerticalAlignmentForShapeText(ByVal verticalAnchor As Long) As Long
    Select Case verticalAnchor
        Case msoAnchorMiddle
            LegacyVerticalAlignmentForShapeText = xlVAlignCenter
        Case msoAnchorBottom
            LegacyVerticalAlignmentForShapeText = xlVAlignBottom
        Case Else
            LegacyVerticalAlignmentForShapeText = xlVAlignTop
    End Select
End Function

Private Function DiagramCardText(ByVal personRow As Long) As String
    Dim titleText As String, bodyText As String
    titleText = DiagramCardTitleText(personRow)
    bodyText = DiagramCardBodyText(personRow)
    If Len(bodyText) > 0 Then
        DiagramCardText = titleText & vbLf & bodyText
    Else
        DiagramCardText = titleText
    End If
End Function

Private Function DiagramCardTitleText(ByVal personRow As Long) As String
    Dim wp As Worksheet, displayName As String
    Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)
    displayName = CleanText(wp.Cells(personRow, P_DISPLAY).Value)
    If Len(displayName) = 0 Then displayName = CleanText(CStr(wp.Cells(personRow, P_SURNAME).Value) & " " & CStr(wp.Cells(personRow, P_GIVEN).Value))
    If Len(displayName) = 0 Then displayName = "�������o�^"
    DiagramCardTitleText = displayName
End Function

Private Function DiagramCardBodyText(ByVal personRow As Long) As String
    Dim wp As Worksheet, pid As String, relText As String, genderText As String, s As String
    Dim inh As Variant, birthValue As Variant, deathValue As Variant
    Dim addrAtInh As String, addrCurrent As String, deathPlace As String, occText As String
    Dim mText As String, dText As String, sameAddrText As String
    Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)
    pid = CleanText(wp.Cells(personRow, P_ID).Value)
    relText = DiagramRelationDisplayText(CleanText(wp.Cells(personRow, P_REL_DEC).Value))
    genderText = CleanText(wp.Cells(personRow, P_GENDER).Value)
    birthValue = wp.Cells(personRow, P_BIRTH).Value
    deathValue = wp.Cells(personRow, P_DEATH).Value
    inh = GetInheritanceDate()

    '�{���́u1�s�ɂ�1���v�B�����͌��o���ɓƗ��z�u���A�{���͎����m�F���ڂ����𐮂���B
    If Len(relText) > 0 Then AppendCardLine s, "����: " & relText
    If Len(genderText) > 0 Then AppendCardLine s, "����: " & genderText
    If IsDate(birthValue) Then AppendCardLine s, "���N����: " & DateWithEraYear(birthValue)
    If IsDate(deathValue) Then
        AppendCardLine s, "�v�N����: " & DateWithEraYear(deathValue)
        If IsDate(birthValue) Then AppendCardLine s, "�v�N��: " & CStr(AgeOnDate(birthValue, deathValue)) & "��"
    End If
    If NormalizeDiagramRelationText(relText) = "�푊���l" Then
        deathPlace = CleanText(wp.Cells(personRow, P_DEATH_PLACE).Value)
        If Len(deathPlace) > 0 Then AppendCardLine s, "���S�ꏊ: " & AddressForCard(deathPlace)
    Else
        If IsDate(birthValue) And IsDate(inh) Then AppendCardLine s, "�������N��: " & CStr(AgeOnDate(birthValue, inh)) & "��"
    End If

    mText = PersonMarriageDateListForCard(pid, True)
    dText = PersonMarriageDateListForCard(pid, False)
    If Len(mText) > 0 Then AppendCardLine s, "������: " & mText
    If Len(dText) > 0 Then AppendCardLine s, "������: " & dText

    occText = CleanText(wp.Cells(personRow, P_OCC).Value)
    If Len(occText) > 0 Then AppendCardLine s, "�E��: " & occText

    addrCurrent = GetCurrentAddressText(pid)
    If IsDate(inh) Then
        addrAtInh = GetAddressTextAtDate(pid, inh)
        If SameAddressForCard(addrAtInh, addrCurrent) Then
            sameAddrText = addrCurrent
            If Len(CleanText(sameAddrText)) = 0 Then sameAddrText = addrAtInh
            AppendCardLine s, "���E���Z��: " & AddressForCard(sameAddrText)
        Else
            AppendCardLine s, "���Z: " & AddressForCard(addrAtInh)
            AppendCardLine s, "���Z: " & AddressForCard(addrCurrent)
        End If
    Else
        AppendCardLine s, "���Z: " & AddressForCard(addrCurrent)
    End If
    DiagramCardBodyText = s
End Function
Private Sub AppendCardLine(ByRef s As String, ByVal lineText As String)
    lineText = CleanText(lineText)
    If Len(lineText) = 0 Then Exit Sub
    If Len(s) > 0 Then s = s & vbLf
    s = s & lineText
End Sub

Private Sub EmphasizeCardBodyLabels(ByVal shp As Shape, ByVal bodyText As String)
    Dim lines As Variant, i As Long, pos As Long, labelLen As Long, lineText As String
    If shp Is Nothing Then Exit Sub
    lines = Split(CStr(bodyText) & vbLf, vbLf)
    pos = 1
    On Error Resume Next
    For i = LBound(lines) To UBound(lines) - 1
        lineText = CStr(lines(i))
        labelLen = InStr(1, lineText, ":", vbTextCompare)
        If labelLen > 1 Then
            shp.TextFrame2.TextRange.Characters(pos, labelLen).Font.Bold = msoTrue
            shp.TextFrame2.TextRange.Characters(pos, labelLen).Font.Fill.ForeColor.RGB = ThemeColor("muted-strong")
        End If
        pos = pos + Len(lineText) + 1
    Next i
    On Error GoTo 0
End Sub

Private Function CompactCardText(ByVal s As String, ByVal maxLen As Long) As String
    s = CleanText(s)
    If Len(s) = 0 Then
        CompactCardText = "���o�^"
    ElseIf Len(s) > maxLen Then
        If maxLen <= 1 Then
            CompactCardText = Left$(s, maxLen)
        Else
            CompactCardText = Left$(s, maxLen - 1) & "�c"
        End If
    Else
        CompactCardText = s
    End If
End Function

Private Function AddressForCard(ByVal s As String) As String
    s = CleanText(s)
    s = Replace(s, vbCrLf, " ")
    s = Replace(s, vbCr, " ")
    s = Replace(s, vbLf, " ")
    Do While InStr(s, "  ") > 0
        s = Replace(s, "  ", " ")
    Loop
    If Len(s) = 0 Then
        AddressForCard = "���o�^"
    Else
        AddressForCard = s
    End If
End Function

Private Function SameAddressForCard(ByVal leftAddress As String, ByVal rightAddress As String) As Boolean
    SameAddressForCard = (NormalizeAddressForCardCompare(leftAddress) = NormalizeAddressForCardCompare(rightAddress))
End Function

Private Function NormalizeAddressForCardCompare(ByVal s As String) As String
    s = AddressForCard(s)
    If s = "���o�^" Then s = ""
    s = Replace(s, " ", "")
    s = Replace(s, "�@", "")
    NormalizeAddressForCardCompare = s
End Function

Private Function PersonMarriageDateListForCard(ByVal personId As String, ByVal wantMarriage As Boolean) As String
    Dim d As Object, result As String
    Set d = CreateObject("Scripting.Dictionary")
    AddLegacyPersonMarriageDateForCard d, personId, wantMarriage
    AddMarriageHistoryDateForCard d, personId, wantMarriage
    AddRelationMarriageDateForCard d, personId, wantMarriage
    result = JoinDictionaryKeysForCard(d, "�A")
    PersonMarriageDateListForCard = result
End Function

Private Sub AddLegacyPersonMarriageDateForCard(ByVal d As Object, ByVal personId As String, ByVal wantMarriage As Boolean)
    Dim wp As Worksheet, r As Long, v As Variant
    If Len(personId) = 0 Or Not SheetExists(SH_W_PERSON, ThisWorkbook) Then Exit Sub
    Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)
    For r = 2 To LastRow(wp, P_ID)
        If CleanText(wp.Cells(r, P_ID).Value) = personId Then
            If wantMarriage Then
                v = wp.Cells(r, P_MARRIAGE).Value
            Else
                v = wp.Cells(r, P_DIVORCE).Value
            End If
            AddDateToCardDictionary d, v
            Exit For
        End If
    Next r
End Sub

Private Sub AddMarriageHistoryDateForCard(ByVal d As Object, ByVal personId As String, ByVal wantMarriage As Boolean)
    Dim ws As Worksheet, r As Long, v As Variant
    If Len(personId) = 0 Or Not SheetExists(SH_W_MARRIAGE_HIST, ThisWorkbook) Then Exit Sub
    Set ws = ThisWorkbook.Worksheets(SH_W_MARRIAGE_HIST)
    For r = 2 To LastRow(ws, MH_ID)
        If CleanText(ws.Cells(r, MH_STATUS).Value) <> STATUS_CANCEL And CleanText(ws.Cells(r, MH_SHOW).Value) <> SHOW_NO Then
            If CleanText(ws.Cells(r, MH_PERSON_ID).Value) = personId Or CleanText(ws.Cells(r, MH_COUNTERPART_ID).Value) = personId Then
                If wantMarriage Then
                    v = ws.Cells(r, MH_MARRIAGE).Value
                Else
                    v = ws.Cells(r, MH_DIVORCE).Value
                End If
                AddDateToCardDictionary d, v
            End If
        End If
    Next r
End Sub

Private Sub AddRelationMarriageDateForCard(ByVal d As Object, ByVal personId As String, ByVal wantMarriage As Boolean)
    Dim wr As Worksheet, r As Long, relType As String, v As Variant
    If Len(personId) = 0 Or Not SheetExists(SH_W_REL, ThisWorkbook) Then Exit Sub
    Set wr = ThisWorkbook.Worksheets(SH_W_REL)
    For r = 2 To LastRow(wr, R_ID)
        If CleanText(wr.Cells(r, R_STATUS).Value) <> STATUS_CANCEL Then
            relType = CleanText(wr.Cells(r, R_TYPE).Value)
            If relType = "�z���" Then
                If CleanText(wr.Cells(r, R_BASE_ID).Value) = personId Or CleanText(wr.Cells(r, R_OTHER_ID).Value) = personId Then
                    If wantMarriage Then
                        v = wr.Cells(r, R_MARRIAGE).Value
                    Else
                        v = wr.Cells(r, R_DIVORCE).Value
                    End If
                    AddDateToCardDictionary d, v
                End If
            End If
        End If
    Next r
End Sub

Private Sub AddDateToCardDictionary(ByVal d As Object, ByVal v As Variant)
    Dim key As String
    If d Is Nothing Then Exit Sub
    If Not IsDate(v) Then Exit Sub
    key = DateWithEraYear(v)
    If Len(key) > 0 Then
        If Not d.Exists(key) Then d.Add key, True
    End If
End Sub

Private Function JoinDictionaryKeysForCard(ByVal d As Object, ByVal delimiterText As String) As String
    Dim k As Variant, s As String
    If d Is Nothing Then Exit Function
    For Each k In d.Keys
        If Len(s) > 0 Then s = s & delimiterText
        s = s & CStr(k)
    Next k
    JoinDictionaryKeysForCard = s
End Function

Private Function GetAddressTextAtDate(ByVal personId As String, ByVal baseDate As Variant) As String
    Dim wa As Worksheet, r As Long, bestR As Long, bestScore As Double, score As Double
    Dim st As Variant, en As Variant
    If Len(personId) = 0 Or Not IsDate(baseDate) Then Exit Function
    If Not SheetExists(SH_W_ADDR_HIST, ThisWorkbook) Then Exit Function
    Set wa = ThisWorkbook.Worksheets(SH_W_ADDR_HIST)
    bestScore = -1E+20
    For r = 2 To LastRow(wa, 1)
        If CStr(wa.Cells(r, A_PERSON_ID).Value) = personId And CStr(wa.Cells(r, A_STATUS).Value) <> STATUS_CANCEL Then
            st = wa.Cells(r, A_START).Value
            en = wa.Cells(r, A_END).Value
            If AddressRowCoversDate(st, en, baseDate) Then
                score = r
                If CleanText(wa.Cells(r, A_TYPE).Value) = "���Z�n" Then score = score + 100000
                If IsDate(st) Then score = score + CDbl(CDate(st)) / 100
                If score > bestScore Then
                    bestScore = score
                    bestR = r
                End If
            End If
        End If
    Next r
    If bestR > 0 Then GetAddressTextAtDate = CStr(wa.Cells(bestR, A_TEXT).Value)
End Function

Private Function AddressRowCoversDate(ByVal startValue As Variant, ByVal endValue As Variant, ByVal baseDate As Variant) As Boolean
    If Not IsDate(baseDate) Then Exit Function
    If IsDate(startValue) Then
        If CDate(startValue) > CDate(baseDate) Then Exit Function
    End If
    If IsDate(endValue) Then
        If CDate(endValue) < CDate(baseDate) Then Exit Function
    End If
    AddressRowCoversDate = True
End Function

Private Function DateWithEraYear(ByVal v As Variant) As String
    If Not IsDate(v) Then Exit Function
    DateWithEraYear = Format(CDate(v), "yyyy/m/d") & "�i" & EraCodeForDate(v) & "�j"
End Function

Private Function EraCodeForDate(ByVal v As Variant) As String
    Dim d As Date, y As Long
    If Not IsDate(v) Then Exit Function
    d = CDate(v)
    If d >= DateSerial(2019, 5, 1) Then
        y = Year(d) - 2018
        EraCodeForDate = "R" & CStr(y)
    ElseIf d >= DateSerial(1989, 1, 8) Then
        y = Year(d) - 1988
        EraCodeForDate = "H" & CStr(y)
    ElseIf d >= DateSerial(1926, 12, 25) Then
        y = Year(d) - 1925
        EraCodeForDate = "S" & CStr(y)
    ElseIf d >= DateSerial(1912, 7, 30) Then
        y = Year(d) - 1911
        EraCodeForDate = "T" & CStr(y)
    ElseIf d >= DateSerial(1868, 1, 25) Then
        y = Year(d) - 1867
        EraCodeForDate = "M" & CStr(y)
    Else
        EraCodeForDate = CStr(Year(d))
    End If
End Function

Private Function MaxDiagramCardVisualLineCount(ByVal cardWidthPt As Double) As Long
    Dim wp As Worksheet, r As Long, n As Long, lineCount As Long
    If Not SheetExists(SH_W_PERSON, ThisWorkbook) Then
        MaxDiagramCardVisualLineCount = 12
        Exit Function
    End If
    Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)
    For r = 2 To LastRow(wp, 1)
        If CStr(wp.Cells(r, P_STATUS).Value) <> STATUS_CANCEL Then
            If Len(CStr(wp.Cells(r, P_ID).Value)) > 0 Then
                If CStr(wp.Cells(r, P_STATUS).Value) <> STATUS_CANCEL And CStr(wp.Cells(r, P_SHOW).Value) <> SHOW_NO Then
                    n = DiagramCardVisualLineCount(r, cardWidthPt)
                    If n > lineCount Then lineCount = n
                End If
            End If
        End If
    Next r
    If lineCount < 12 Then lineCount = 12
    If lineCount > 64 Then lineCount = 64
    MaxDiagramCardVisualLineCount = lineCount
End Function

Private Function DiagramCardVisualLineCount(ByVal personRow As Long, ByVal cardWidthPt As Double) As Long
    DiagramCardVisualLineCount = EstimateCardTextVisualLines(DiagramCardText(personRow), cardWidthPt)
End Function

Private Function EstimateCardTextVisualLines(ByVal text As String, ByVal cardWidthPt As Double) As Long
    Dim arr As Variant, i As Long, capacity As Long, n As Long, total As Long
    arr = Split(text & vbLf, vbLf)
    capacity = CLng((cardWidthPt - 54) / 8.6)
    If capacity < 10 Then capacity = 10
    For i = LBound(arr) To UBound(arr) - 1
        n = Len(CStr(arr(i)))
        If n < 1 Then n = 1
        total = total + Application.Max(1, Int((n - 1) / capacity) + 1)
    Next i
    If total < 1 Then total = 1
    EstimateCardTextVisualLines = total
End Function

Private Function DiagramCardHeightFromLines(ByVal lineCount As Long) As Double
    If lineCount < 12 Then lineCount = 12
    If lineCount > 64 Then lineCount = 64
    '���o���E�����o�b�W�E�{���𕪗��������߁A�{�����������ׂ����]�����݂ō��������߂�B
    '�Z���������P�[�X�ł̓J�[�h���c�ɐL�΂��āA�{�����̌��؂�������B
    DiagramCardHeightFromLines = Application.Max(432, Application.Min(1480, lineCount * 24.5 + 176))
End Function

Private Function CardHeaderHeight(ByVal widthPt As Double, ByVal heightPt As Double) As Double
    If widthPt >= 320 Then
        CardHeaderHeight = 54
    ElseIf widthPt >= 280 Then
        CardHeaderHeight = 50
    Else
        CardHeaderHeight = 46
    End If
    If heightPt < 250 Then CardHeaderHeight = 42
End Function

Private Function CardTitleFontSizeForName(ByVal displayName As String, ByVal widthPt As Double) As Double
    If Len(displayName) >= 30 Or widthPt < 150 Then
        CardTitleFontSizeForName = 11.2
    ElseIf Len(displayName) >= 22 Or widthPt < 190 Then
        CardTitleFontSizeForName = 12.2
    ElseIf Len(displayName) >= 14 Then
        CardTitleFontSizeForName = 13.2
    Else
        CardTitleFontSizeForName = 14.2
    End If
End Function

Private Function HeaderFontSizeForName(ByVal displayName As String, ByVal widthPt As Double) As Double
    HeaderFontSizeForName = CardTitleFontSizeForName(displayName, widthPt)
End Function

Private Function CardFontSizeForText(ByVal text As String, ByVal widthPt As Double, ByVal heightPt As Double) As Double
    CardFontSizeForText = CardFontSizeForShape(text, widthPt, heightPt)
End Function

Private Function CardFontSizeForShape(ByVal text As String, ByVal cardW As Double, ByVal cardH As Double) As Double
    Dim lineCount As Long, sizeFromHeight As Double, targetSize As Double
    lineCount = EstimateWrappedLineCount(text, cardW)
    sizeFromHeight = (cardH - 6) / Application.Max(1, lineCount * 1.32)

    If lineCount >= 36 Or Len(text) >= 660 Then
        targetSize = 9.8
    ElseIf lineCount >= 28 Or Len(text) >= 540 Then
        targetSize = 10.3
    ElseIf lineCount >= 22 Or Len(text) >= 420 Then
        targetSize = 10.8
    ElseIf lineCount >= 15 Or Len(text) >= 280 Then
        targetSize = 11.2
    Else
        targetSize = 11.6
    End If

    '�J�[�h�������Ɋm�ۂ��������ŁA�Ōゾ�������ɍ��킹�Ĕ���������B�ǂ߂Ȃ��قǏ������ׂ��Ȃ��B
    CardFontSizeForShape = Application.Min(targetSize, Application.Max(9.1, sizeFromHeight))
End Function

Private Function EstimateWrappedLineCount(ByVal text As String, ByVal cardW As Double) As Long
    Dim arr As Variant, i As Long, charsPerLine As Long, s As String, n As Long, total As Long
    charsPerLine = CLng(Application.Max(10, (cardW - 54) / 8.6))
    arr = Split(CStr(text) & vbLf, vbLf)
    For i = LBound(arr) To UBound(arr)
        s = CleanText(arr(i))
        n = Len(s)
        If n = 0 Then
            total = total + 1
        Else
            total = total + Application.Max(1, WorksheetFunction.RoundUp(n / charsPerLine, 0))
        End If
    Next i
    If total < 1 Then total = 1
    EstimateWrappedLineCount = total
End Function

Private Function CardBadgeText(ByVal relationText As String) As String
    Dim baseText As String
    baseText = NormalizeDiagramRelationText(relationText)
    If Len(baseText) = 0 Then baseText = CleanText(relationText)
    If Len(baseText) = 0 Then Exit Function
    If InStr(baseText, "�i") > 0 Then baseText = Left$(baseText, InStr(baseText, "�i") - 1)
    If InStr(baseText, "(") > 0 Then baseText = Left$(baseText, InStr(baseText, "(") - 1)
    CardBadgeText = baseText
End Function

Private Function CardBadgeWidth(ByVal badgeText As String) As Double
    Dim n As Long
    n = Len(CleanText(badgeText))
    If n = 0 Then
        CardBadgeWidth = 0
    ElseIf n <= 2 Then
        CardBadgeWidth = 46
    ElseIf n <= 4 Then
        CardBadgeWidth = 58
    Else
        CardBadgeWidth = Application.Min(88, 34 + n * 9)
    End If
End Function

Private Function CardBadgeFontSize(ByVal badgeText As String) As Double
    If Len(CleanText(badgeText)) >= 5 Then
        CardBadgeFontSize = 8.4
    Else
        CardBadgeFontSize = 9.1
    End If
End Function

Private Function CardHeaderFillColor(ByVal relationText As String) As Long
    Select Case NormalizeDiagramRelationText(relationText)
        Case "�푊���l"
            CardHeaderFillColor = ThemeColor("teal-soft")
        Case "�z���", "�O�z���"
            CardHeaderFillColor = ThemeColor("warning-soft")
        Case "��", "��"
            CardHeaderFillColor = ThemeColor("success-soft")
        Case "�Z", "��", "�o", "��", "�Z��", "�o��", "�Z��o��"
            CardHeaderFillColor = ThemeColor("orange-soft")
        Case "��", "�]��", "����"
            CardHeaderFillColor = ThemeColor("purple-soft")
        Case Else
            If IsDirectChildRelationText(relationText) Then
                CardHeaderFillColor = ThemeColor("info-soft")
            Else
                CardHeaderFillColor = ThemeColor("surface-soft")
            End If
    End Select
End Function

Private Function CardAccentColor(ByVal relationText As String) As Long
    Select Case NormalizeDiagramRelationText(relationText)
        Case "�푊���l"
            CardAccentColor = ThemeColor("teal")
        Case "�z���", "�O�z���"
            CardAccentColor = ThemeColor("orange")
        Case "��", "��"
            CardAccentColor = ThemeColor("green")
        Case "�Z", "��", "�o", "��", "�Z��", "�o��", "�Z��o��"
            CardAccentColor = ThemeColor("orange")
        Case "��", "�]��", "����"
            CardAccentColor = ThemeColor("purple")
        Case Else
            If IsDirectChildRelationText(relationText) Then
                CardAccentColor = ThemeColor("accent")
            Else
                CardAccentColor = ThemeColor("muted-strong")
            End If
    End Select
End Function

Private Function CardBadgeFillColor(ByVal relationText As String) As Long
    CardBadgeFillColor = CardHeaderFillColor(relationText)
End Function

Private Function CardBadgeFontColor(ByVal relationText As String) As Long
    Select Case NormalizeDiagramRelationText(relationText)
        Case "�푊���l"
            CardBadgeFontColor = ThemeColor("teal-text")
        Case "�z���", "�O�z���"
            CardBadgeFontColor = ThemeColor("warning-text")
        Case "��", "��"
            CardBadgeFontColor = ThemeColor("success-text")
        Case "�Z", "��", "�o", "��", "�Z��", "�o��", "�Z��o��"
            CardBadgeFontColor = ThemeColor("warning-text")
        Case "��", "�]��", "����"
            CardBadgeFontColor = ThemeColor("purple")
        Case Else
            If IsDirectChildRelationText(relationText) Then
                CardBadgeFontColor = ThemeColor("accent")
            Else
                CardBadgeFontColor = ThemeColor("muted-strong")
            End If
    End Select
End Function

Private Function CardFillColor(ByVal relationText As String) As Long
    relationText = NormalizeDiagramRelationText(relationText)
    Select Case relationText
        Case "�푊���l"
            CardFillColor = ThemeColor("info-very-soft")
        Case "�z���"
            CardFillColor = ThemeColor("warning-soft")
        Case "��", "��"
            CardFillColor = ThemeColor("success-soft")
        Case "�Z", "��", "�o", "��", "�Z��", "�o��", "�Z��o��"
            CardFillColor = ThemeColor("orange-soft")
        Case "��", "�]��", "����"
            CardFillColor = ThemeColor("purple-soft")
        Case Else
            If IsDirectChildRelationText(relationText) Then
                CardFillColor = ThemeColor("info-very-soft")
            ElseIf InStr(relationText, "�z���") > 0 Then
                CardFillColor = ThemeColor("warning-soft")
            Else
                CardFillColor = ThemeColor("canvas")
            End If
    End Select
End Function

Private Sub ConnectVerticalCouple(ByVal ws As Worksheet, ByVal upperShape As Shape, ByVal lowerShape As Shape, ByRef originX As Double, ByRef originY As Double)
    originX = ShapeCenterX(upperShape)
    DrawVLine ws, originX, upperShape.Top + upperShape.Height, lowerShape.Top
    originY = (upperShape.Top + upperShape.Height + lowerShape.Top) / 2
End Sub

Private Sub DrawChildFamilyBlock(ByVal ws As Worksheet, _
        ByVal childRow As Long, _
        ByVal childX As Double, _
        ByVal childTop As Double, _
        ByVal gcX As Double, _
        ByVal cardW As Double, _
        ByVal cardH As Double, _
        ByVal childShapes As Object)
    Dim childShape As Shape, spouseRow As Long, spouseShape As Shape
    Dim childId As String, originX As Double, originY As Double, gcRows As Collection
    Dim i As Long, topG As Double, startG As Double, branchX As Double, gRow As Long
    childId = CStr(ThisWorkbook.Worksheets(SH_W_PERSON).Cells(childRow, P_ID).Value)
    Set childShape = DrawPersonCardShape(ws, childRow, childX, childTop, cardW, cardH)
    If Not childShapes.Exists(childId) Then childShapes.Add childId, childShape.Name
    
    spouseRow = GetSpouseRowOfPerson(childId)
    If spouseRow > 0 Then
        Set spouseShape = DrawPersonCardShape(ws, spouseRow, childX, childTop + cardH + 16, cardW, cardH)
        ConnectVerticalCouple ws, childShape, spouseShape, originX, originY
    Else
        originX = childShape.Left + childShape.Width
        originY = ShapeCenterY(childShape)
    End If
    
    Set gcRows = GetGrandchildRowsForParent(childId)
    If gcRows.Count > 0 Then
        branchX = gcX - 28
        startG = originY - ((gcRows.Count - 1) * 76) / 2 - cardH / 2
        If startG < 78 Then startG = 78
        DrawHLine ws, originX, originY, branchX
        DrawVLine ws, branchX, Application.Min(originY, startG + cardH / 2), Application.Max(originY, startG + (gcRows.Count - 1) * 76 + cardH / 2)
        For i = 1 To gcRows.Count
            gRow = CLng(gcRows(i))
            topG = startG + (i - 1) * 76
            DrawPersonCardShape ws, gRow, gcX, topG, cardW, cardH
            DrawHLine ws, branchX, topG + cardH / 2, gcX
        Next i
    End If
End Sub

Private Sub DrawUnlinkedGrandchildren(ByVal ws As Worksheet, ByVal gcX As Double, ByVal topPt As Double, ByVal cardW As Double, ByVal cardH As Double)
    Dim unlinkedRows As Collection, i As Long
    Set unlinkedRows = GetUnlinkedGrandchildRows()
    If unlinkedRows.Count = 0 Then Exit Sub
    For i = 1 To unlinkedRows.Count
        DrawPersonCardShape ws, CLng(unlinkedRows(i)), gcX, topPt + (i - 1) * 70, cardW, cardH
    Next i
End Sub

Private Function GetFirstVisiblePersonRowByRelation(ByVal relationText As String) As Long
    Dim wp As Worksheet, r As Long
    Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)
    For r = 2 To LastRow(wp, 1)
        If CStr(wp.Cells(r, P_STATUS).Value) <> STATUS_CANCEL And CStr(wp.Cells(r, P_SHOW).Value) <> SHOW_NO Then
            If CStr(wp.Cells(r, P_REL_DEC).Value) = relationText Then
                GetFirstVisiblePersonRowByRelation = r
                Exit Function
            End If
        End If
    Next r
End Function

Private Function GetRootChildRows(ByVal decId As String) As Collection
    Dim col As New Collection, linked As Collection, i As Long
    Dim wp As Worksheet, r As Long, relText As String, pid As String
    Set linked = GetChildRowsForParent(decId)
    For i = 1 To linked.Count
        AddPersonRowUnique col, CLng(linked(i))
    Next i
    Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)
    For r = 2 To LastRow(wp, 1)
        pid = CStr(wp.Cells(r, P_ID).Value)
        relText = CStr(wp.Cells(r, P_REL_DEC).Value)
        If CStr(wp.Cells(r, P_STATUS).Value) <> STATUS_CANCEL Then
            If CStr(wp.Cells(r, P_SHOW).Value) <> SHOW_NO Then
                If pid <> decId Then
                    If IsDirectChildRelationText(relText) Then AddPersonRowUnique col, r
                End If
            End If
        End If
    Next r
    Set GetRootChildRows = col
End Function

Private Function GetDirectChildRows(ByVal decId As String) As Collection
    Set GetDirectChildRows = GetRootChildRows(decId)
End Function

Private Function IsDirectChildRelationText(ByVal relText As String) As Boolean
    relText = DiagramBaseRelationLabel(relText)
    Select Case relText
        Case "���j", "��j", "�O�j", "�l�j", "�ܒj", "�Z�j", "����", "��", "�O��", "�l��", "�܏�", "�Z��", "�q", "�{�q"
            IsDirectChildRelationText = True
    End Select
End Function

Private Function IsGrandchildRelationText(ByVal relText As String) As Boolean
    relText = NormalizeDiagramRelationText(relText)
    If InStr(relText, "�z���") > 0 Then Exit Function
    IsGrandchildRelationText = (relText = "��" Or Left$(relText, 2) = "���i")
End Function

Private Function IsGreatGrandchildRelationText(ByVal relText As String) As Boolean
    relText = NormalizeDiagramRelationText(relText)
    If InStr(relText, "�z���") > 0 Then Exit Function
    IsGreatGrandchildRelationText = IsGreatGrandchildRelationBase(relText)
End Function

Private Function GetSpouseRowOfPerson(ByVal personId As String) As Long
    Dim wr As Worksheet, r As Long, otherId As String
    Set wr = ThisWorkbook.Worksheets(SH_W_REL)
    For r = 2 To LastRow(wr, 1)
        If CStr(wr.Cells(r, R_STATUS).Value) <> STATUS_CANCEL And CStr(wr.Cells(r, R_TYPE).Value) = "�z���" And Not IsDate(wr.Cells(r, R_DIVORCE).Value) Then
            If CStr(wr.Cells(r, R_BASE_ID).Value) = personId Then
                otherId = CStr(wr.Cells(r, R_OTHER_ID).Value)
                GetSpouseRowOfPerson = FindPersonRow(otherId)
                Exit Function
            ElseIf CStr(wr.Cells(r, R_OTHER_ID).Value) = personId Then
                otherId = CStr(wr.Cells(r, R_BASE_ID).Value)
                GetSpouseRowOfPerson = FindPersonRow(otherId)
                Exit Function
            End If
        End If
    Next r
End Function

Private Function GetGrandchildRowsForParent(ByVal parentId As String) As Collection
    Dim col As New Collection, wr As Worksheet, r As Long, pId As String, cId As String, gcRow As Long
    Set wr = ThisWorkbook.Worksheets(SH_W_REL)
    For r = 2 To LastRow(wr, 1)
        If TryResolveDiagramParentChildRelationRow(wr, r, pId, cId) Then
            If pId = parentId Then
                gcRow = FindPersonRow(cId)
                If gcRow > 0 Then
                    If IsGrandchildRelationText(CStr(ThisWorkbook.Worksheets(SH_W_PERSON).Cells(gcRow, P_REL_DEC).Value)) Then AddPersonRowUnique col, gcRow
                End If
            End If
        End If
    Next r
    Set GetGrandchildRowsForParent = col
End Function

Private Function GetUnlinkedGrandchildRows() As Collection
    Dim col As New Collection, wp As Worksheet, r As Long, pid As String
    Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)
    For r = 2 To LastRow(wp, 1)
        pid = CStr(wp.Cells(r, P_ID).Value)
        If CStr(wp.Cells(r, P_STATUS).Value) <> STATUS_CANCEL Then
            If CStr(wp.Cells(r, P_SHOW).Value) <> SHOW_NO Then
                If IsGrandchildRelationText(CStr(wp.Cells(r, P_REL_DEC).Value)) Then
                    If Not HasParentRelationFromDirectChild(pid) Then col.Add r
                End If
            End If
        End If
    Next r
    Set GetUnlinkedGrandchildRows = col
End Function

Private Function HasParentRelationFromDirectChild(ByVal personId As String) As Boolean
    Dim wr As Worksheet, r As Long, pId As String, cId As String, pRow As Long
    Set wr = ThisWorkbook.Worksheets(SH_W_REL)
    For r = 2 To LastRow(wr, 1)
        If TryResolveDiagramParentChildRelationRow(wr, r, pId, cId) Then
            If cId = personId Then
                pRow = FindPersonRow(pId)
                If pRow > 0 Then
                    If IsDirectChildRelationText(CStr(ThisWorkbook.Worksheets(SH_W_PERSON).Cells(pRow, P_REL_DEC).Value)) Then
                        HasParentRelationFromDirectChild = True
                        Exit Function
                    End If
                End If
            End If
        End If
    Next r
End Function

Private Sub PlaceOtherListHorizontal(ByVal ws As Worksheet, ByVal leftPt As Double, ByVal topPt As Double)
    Dim wp As Worksheet, r As Long, relText As String, outText As String
    Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)
    For r = 2 To LastRow(wp, 1)
        relText = CStr(wp.Cells(r, P_REL_DEC).Value)
        If CStr(wp.Cells(r, P_STATUS).Value) <> STATUS_CANCEL And CStr(wp.Cells(r, P_SHOW).Value) <> SHOW_NO Then
            If ShouldListAsOther(relText) Then
                If Len(outText) > 0 Then outText = outText & vbLf
                outText = outText & "�E" & wp.Cells(r, P_DISPLAY).Value & "�i" & relText & "�j"
            End If
        End If
    Next r
    If Len(outText) = 0 Then Exit Sub
    Dim shp As Shape
    Set shp = ws.Shapes.AddShape(msoShapeRoundedRectangle, leftPt, topPt, 360, 88)
    With shp
        .Name = "box_other_relations"
        .Placement = xlFreeFloating
        .Locked = True
        .Fill.ForeColor.RGB = ThemeColor("canvas")
        .Line.ForeColor.RGB = ThemeColor("line-muted")
        .Line.Weight = 1
        SafeApplyShapeText shp, "���̑��֌W��" & vbLf & outText, 8.5, ThemeColor("text"), False, msoAlignLeft, msoAnchorTop, 8, 8, 0, 0, True, 0
    End With
End Sub

Private Function ShouldListAsOther(ByVal relText As String) As Boolean
    Dim rawText As String
    rawText = CleanText(relText)
    relText = NormalizeDiagramRelationText(rawText)
    If relText = "�푊���l" Or relText = "�z���" Or relText = "��" Or relText = "��" Then Exit Function
    If IsSiblingRelationText(relText) Then Exit Function
    If IsDirectChildRelationText(relText) Then Exit Function
    If DiagramDescendantLevel(relText) > 0 Then Exit Function
    If InStr(relText, "�z���") > 0 Then Exit Function
    If DiagramRelationTextIsOtherParty(rawText) Then
        ShouldListAsOther = True
    ElseIf Len(relText) > 0 Then
        ShouldListAsOther = True
    End If
End Function

Private Sub AddDiagramLegend(ByVal ws As Worksheet, ByVal leftPt As Double, ByVal topPt As Double)
    '�o�͐}�ɂ͐��������ڂ��Ȃ��B
End Sub

Private Sub DrawGenerationLabel(ByVal ws As Worksheet, ByVal leftPt As Double, ByVal topPt As Double, ByVal caption As String)
    Dim shp As Shape
    Set shp = ws.Shapes.AddShape(msoShapeRoundedRectangle, leftPt, topPt, 118, 22)
    With shp
        .Name = "label_" & caption
        .Placement = xlFreeFloating
        .Locked = True
        .Fill.ForeColor.RGB = ThemeColor("locked")
        .Line.ForeColor.RGB = ThemeColor("border")
        .Line.Weight = 0.75
        SafeApplyShapeText shp, caption, 8.5, ThemeColor("muted-strong"), True, msoAlignCenter, msoAnchorMiddle, 2, 2, 0, 0, True, 0
    End With
End Sub

Private Sub DrawHLine(ByVal ws As Worksheet, ByVal x1 As Double, ByVal y As Double, ByVal x2 As Double)
    Dim shp As Shape
    If ws Is Nothing Then Exit Sub
    x1 = SafeDiagramPoint(x1, 1)
    x2 = SafeDiagramPoint(x2, 1)
    y = SafeDiagramPoint(y, 1)
    If Abs(x2 - x1) < 0.5 Then Exit Sub
    On Error GoTo EH
    Set shp = ws.Shapes.AddLine(x1, y, x2, y)
    shp.Placement = xlFreeFloating
    shp.Locked = True
    With shp.Line
        .ForeColor.RGB = ThemeColor("muted-strong")
        .Weight = 1.5
        .EndArrowheadStyle = msoArrowheadNone
        .BeginArrowheadStyle = msoArrowheadNone
    End With
    shp.ZOrder msoSendToBack
    Exit Sub
EH:
    AppendRelationshipDiagramDrawWarning "���`��", "�������X�L�b�v: " & Err.Description
    Err.Clear
End Sub

Private Sub DrawVLine(ByVal ws As Worksheet, ByVal x As Double, ByVal y1 As Double, ByVal y2 As Double)
    Dim shp As Shape
    If ws Is Nothing Then Exit Sub
    x = SafeDiagramPoint(x, 1)
    y1 = SafeDiagramPoint(y1, 1)
    y2 = SafeDiagramPoint(y2, 1)
    If Abs(y2 - y1) < 0.5 Then Exit Sub
    On Error GoTo EH
    Set shp = ws.Shapes.AddLine(x, y1, x, y2)
    shp.Placement = xlFreeFloating
    shp.Locked = True
    With shp.Line
        .ForeColor.RGB = ThemeColor("muted-strong")
        .Weight = 1.5
        .EndArrowheadStyle = msoArrowheadNone
        .BeginArrowheadStyle = msoArrowheadNone
    End With
    shp.ZOrder msoSendToBack
    Exit Sub
EH:
    AppendRelationshipDiagramDrawWarning "���`��", "�c�����X�L�b�v: " & Err.Description
    Err.Clear
End Sub

Private Function ShapeCenterX(ByVal shp As Shape) As Double
    On Error GoTo EH
    If shp Is Nothing Then Exit Function
    ShapeCenterX = shp.Left + shp.Width / 2
    Exit Function
EH:
    Err.Clear
End Function

Private Function ShapeCenterY(ByVal shp As Shape) As Double
    On Error GoTo EH
    If shp Is Nothing Then Exit Function
    ShapeCenterY = shp.Top + shp.Height / 2
    Exit Function
EH:
    Err.Clear
End Function


Public Sub BuildAddressHistoryTable()
    Dim ws As Worksheet, wa As Worksheet, outR As Long, r As Long, pid As String, endDate As Variant
    Dim headerRow As Long, firstDataRow As Long, lastDataRow As Long
    Set ws = ThisWorkbook.Worksheets(SH_ADDR_TABLE)
    ClearSheetAll ws
    ApplySheetCanvas ws
    headerRow = 8
    firstDataRow = headerRow + 1

    ws.Range("A1:I1").Merge
    TitleBannerStyle ws.Range("A1:I1"), "�Z���ꗗ�E�Z�����𑁌��\"
    AddButton ws, "K1", "�I���Z�������", "LoadSelectedAddressHistoryForEdit", 118, 26
    AddButton ws, "L1", "�I���Z�����폜", "DeleteSelectedAddressFromTable", 118, 26
    AddButton ws, "M1", "���֖͂߂�", "ShowOnlyInput", 96, 26
    ws.Range("A7:I7").Merge
    SectionStyle ws.Range("A7:I7"), "�l���ʏZ���ꗗ"

    Set wa = ThisWorkbook.Worksheets(SH_W_ADDR_HIST)
    outR = firstDataRow
    For r = 2 To LastRow(wa, 1)
        If CStr(wa.Cells(r, A_STATUS).Value) <> STATUS_CANCEL And Len(CStr(wa.Cells(r, A_ID).Value)) > 0 Then
            pid = CleanText(wa.Cells(r, A_PERSON_ID).Value)
            endDate = EffectiveEndDate(r)
            ws.Cells(outR, 1).Value = pid
            ws.Cells(outR, 2).Value = GetPersonValue(pid, P_DISPLAY)
            ws.Cells(outR, 3).Value = DiagramRelationDisplayText(CleanText(GetPersonValue(pid, P_REL_DEC)))
            ws.Cells(outR, 4).Value = wa.Cells(r, A_START).Value
            ws.Cells(outR, 5).Value = EffectiveAddressStartKind(wa, r)
            ws.Cells(outR, 6).Value = endDate
            ws.Cells(outR, 7).Value = PeriodText(wa.Cells(r, A_START).Value, endDate)
            ws.Cells(outR, 8).Value = wa.Cells(r, A_TEXT).Value
            ws.Cells(outR, 9).Value = AddressHistoryStatusText(pid, r, endDate)
            ws.Cells(outR, 10).Value = wa.Cells(r, A_ID).Value
            outR = outR + 1
        End If
    Next r
    lastDataRow = Application.Max(firstDataRow, outR - 1)
    SetRowValues ws.Cells(headerRow, 1), Array("�l��ID", "����", "����", "�J�n��", "�J�n�敪", "�I����", "����", "�Z��", "���", "�Z��ID")
    HeaderStyle ws.Range(ws.Cells(headerRow, 1), ws.Cells(headerRow, 10))
    If outR > firstDataRow Then SortAddressHistoryOutput ws, lastDataRow, headerRow
    BuildAddressSummaryBand ws, lastDataRow, firstDataRow
    SetRowValues ws.Cells(headerRow, 1), Array("�l��ID", "����", "����", "�J�n��", "�J�n�敪", "�I����", "����", "�Z��", "���", "�Z��ID")
    HeaderStyle ws.Range(ws.Cells(headerRow, 1), ws.Cells(headerRow, 10))
    ws.Range(ws.Cells(firstDataRow, 4), ws.Cells(Application.Max(firstDataRow, lastDataRow), 4)).NumberFormatLocal = "yyyy/m/d"
    ws.Range(ws.Cells(firstDataRow, 6), ws.Cells(Application.Max(firstDataRow, lastDataRow), 6)).NumberFormatLocal = "yyyy/m/d"
    PolishAddressHistoryOutput ws, headerRow, firstDataRow, lastDataRow
End Sub

Private Sub PolishAddressHistoryOutput(ByVal ws As Worksheet, ByVal headerRow As Long, ByVal firstDataRow As Long, ByVal lastDataRow As Long)
    If ws Is Nothing Then Exit Sub
    If lastDataRow < firstDataRow Then lastDataRow = firstDataRow
    With ws.Range(ws.Cells(headerRow, 1), ws.Cells(lastDataRow, 10))
        .Font.Name = THEME_FONT
        .Font.Size = 10.6
        .VerticalAlignment = xlTop
        .WrapText = True
    End With
    ThemeApplyZebraTable ws.Range(ws.Cells(headerRow, 1), ws.Cells(lastDataRow, 10)), 1
    ThemeApplyPrintTable ws.Range(ws.Cells(headerRow, 1), ws.Cells(lastDataRow, 10)), 1
    ws.Columns("A:A").ColumnWidth = 9
    ws.Columns("B:B").ColumnWidth = 20
    ws.Columns("C:C").ColumnWidth = 11
    ws.Columns("D:D").ColumnWidth = 12
    ws.Columns("E:E").ColumnWidth = 12
    ws.Columns("F:F").ColumnWidth = 12
    ws.Columns("G:G").ColumnWidth = 17
    ws.Columns("H:H").ColumnWidth = 74
    ws.Columns("I:I").ColumnWidth = 15
    ws.Columns("J:J").ColumnWidth = 14
    ws.Columns("J:J").Hidden = True
    ws.Rows("1:1").RowHeight = 30
    ws.Rows("3:5").RowHeight = 25
    ws.Rows("6:6").RowHeight = 12
    ws.Rows("7:7").RowHeight = 25
    ws.Rows(CStr(headerRow) & ":" & CStr(headerRow)).RowHeight = 28
    If lastDataRow >= firstDataRow Then
        FitAddressHistoryRowHeights ws, firstDataRow, lastDataRow
        HighlightAddressHistorySemantics ws, firstDataRow, lastDataRow
        PolishAddressPersonColumns ws, firstDataRow, lastDataRow
        MarkAddressPersonBreaks ws, firstDataRow, lastDataRow
    End If
    ThemeMarkMacroButtonsNonPrintable ws
    ApplyAdaptiveOutputPrint ws, ws.Range(ws.Cells(1, 1), ws.Cells(lastDataRow, 9)).Address, "$8:$8", lastDataRow, 9, False
End Sub

Private Sub FitAddressHistoryRowHeights(ByVal ws As Worksheet, ByVal firstDataRow As Long, ByVal lastDataRow As Long)
    Dim r As Long, visualLines As Long, targetHeight As Double
    If ws Is Nothing Then Exit Sub
    If lastDataRow < firstDataRow Then Exit Sub
    For r = firstDataRow To lastDataRow
        visualLines = Application.Max(1, WorksheetFunction.RoundUp(Application.Max(1, Len(CleanText(ws.Cells(r, 8).Value))) / 34, 0))
        targetHeight = 42 + visualLines * 16
        If targetHeight < 58 Then targetHeight = 58
        If targetHeight > 178 Then targetHeight = 178
        ws.Rows(r).RowHeight = targetHeight
    Next r
End Sub

Private Sub HighlightAddressHistorySemantics(ByVal ws As Worksheet, ByVal firstDataRow As Long, ByVal lastDataRow As Long)
    Dim r As Long, kindText As String, statusText As String
    If ws Is Nothing Then Exit Sub
    For r = firstDataRow To lastDataRow
        kindText = CleanText(ws.Cells(r, 5).Value)
        statusText = CleanText(ws.Cells(r, 9).Value)
        If kindText = "�c����" Then
            ws.Cells(r, 5).Interior.Color = ThemeColor("warning-soft")
            ws.Cells(r, 5).Font.Color = ThemeColor("warning-text")
            ws.Cells(r, 5).Font.Bold = True
        ElseIf kindText = "���Z�J�n" Then
            ws.Cells(r, 5).Interior.Color = ThemeColor("info-soft")
            ws.Cells(r, 5).Font.Color = ThemeColor("accent")
            ws.Cells(r, 5).Font.Bold = True
        End If
        If Len(CleanText(ws.Cells(r, 8).Value)) = 0 Or CleanText(ws.Cells(r, 8).Value) = "���o�^" Then
            ws.Cells(r, 8).Interior.Color = ThemeColor("danger-soft")
            ws.Cells(r, 8).Font.Color = ThemeColor("danger-text")
        End If
        ws.Cells(r, 7).Font.Color = ThemeColor("muted-strong")
        If InStr(statusText, "�v�m�F") > 0 Then
            ws.Cells(r, 9).Interior.Color = ThemeColor("warning-soft")
            ws.Cells(r, 9).Font.Color = ThemeColor("warning-text")
            ws.Cells(r, 9).Font.Bold = True
        ElseIf InStr(statusText, "���Z��") > 0 Then
            ws.Cells(r, 9).Interior.Color = ThemeColor("success-soft")
            ws.Cells(r, 9).Font.Color = ThemeColor("success-text")
            ws.Cells(r, 9).Font.Bold = True
        ElseIf InStr(statusText, "������") > 0 Then
            ws.Cells(r, 9).Interior.Color = ThemeColor("teal-soft")
            ws.Cells(r, 9).Font.Color = ThemeColor("teal-text")
            ws.Cells(r, 9).Font.Bold = True
        Else
            ws.Cells(r, 9).Interior.Color = ThemeColor("surface-soft")
            ws.Cells(r, 9).Font.Color = ThemeColor("muted-strong")
        End If
    Next r
End Sub

Private Sub MarkAddressPersonBreaks(ByVal ws As Worksheet, ByVal firstDataRow As Long, ByVal lastDataRow As Long)
    Dim r As Long
    If ws Is Nothing Then Exit Sub
    If lastDataRow < firstDataRow + 1 Then Exit Sub
    On Error Resume Next
    For r = firstDataRow + 1 To lastDataRow
        If CleanText(ws.Cells(r, 1).Value) <> CleanText(ws.Cells(r - 1, 1).Value) Then
            With ws.Range(ws.Cells(r, 1), ws.Cells(r, 9)).Borders(xlEdgeTop)
                .LineStyle = xlContinuous
                .Color = ThemeColor("border-strong")
                .Weight = xlMedium
            End With
            ws.Rows(r).RowHeight = ws.Rows(r).RowHeight + 8
        End If
    Next r
    On Error GoTo 0
End Sub

Private Sub PolishAddressPersonColumns(ByVal ws As Worksheet, ByVal firstDataRow As Long, ByVal lastDataRow As Long)
    Dim r As Long, isNewPerson As Boolean
    If ws Is Nothing Then Exit Sub
    If lastDataRow < firstDataRow Then Exit Sub
    On Error Resume Next
    For r = firstDataRow To lastDataRow
        isNewPerson = (r = firstDataRow)
        If Not isNewPerson Then isNewPerson = (CleanText(ws.Cells(r, 1).Value) <> CleanText(ws.Cells(r - 1, 1).Value))
        With ws.Range(ws.Cells(r, 1), ws.Cells(r, 3))
            .Interior.Color = ThemeColor("surface-soft")
            .Font.Color = ThemeColor("title")
            .Font.Bold = isNewPerson
            .VerticalAlignment = xlTop
        End With
        If Not isNewPerson Then
            ws.Cells(r, 2).Font.Color = ThemeColor("muted")
            ws.Cells(r, 3).Font.Color = ThemeColor("muted")
        End If
        ws.Cells(r, 8).Font.Size = 10.4
        ws.Cells(r, 8).HorizontalAlignment = xlLeft
        ws.Cells(r, 8).VerticalAlignment = xlTop
        ws.Cells(r, 9).HorizontalAlignment = xlCenter
        ws.Cells(r, 9).VerticalAlignment = xlCenter
    Next r
    On Error GoTo 0
End Sub

Private Sub BuildAddressSummaryBand(ByVal ws As Worksheet, ByVal lastDataRow As Long, ByVal firstDataRow As Long)
    Dim totalCount As Long, personCount As Long, currentCount As Long, reviewCount As Long
    totalCount = CountNonBlankTextInRange(ws.Range(ws.Cells(firstDataRow, 1), ws.Cells(Application.Max(firstDataRow, lastDataRow), 1)))
    personCount = CountDistinctTextInRange(ws.Range(ws.Cells(firstDataRow, 1), ws.Cells(Application.Max(firstDataRow, lastDataRow), 1)))
    currentCount = CountTextContainsInRange(ws.Range(ws.Cells(firstDataRow, 9), ws.Cells(Application.Max(firstDataRow, lastDataRow), 9)), "���Z��")
    reviewCount = CountTextContainsInRange(ws.Range(ws.Cells(firstDataRow, 9), ws.Cells(Application.Max(firstDataRow, lastDataRow), 9)), "�v�m�F")
    WriteMetricCard ws.Range("A3:B5"), "�Z������", CStr(totalCount) & "��"
    WriteMetricCard ws.Range("C3:D5"), "�o�^�l��", CStr(personCount) & "��"
    WriteMetricCard ws.Range("E3:F5"), "���Z��", CStr(currentCount) & "��"
    WriteMetricCard ws.Range("G3:I5"), "�v�m�F", CStr(reviewCount) & "��"
End Sub

Private Function AddressHistoryStatusText(ByVal personId As String, ByVal addrRow As Long, ByVal endDate As Variant) As String
    Dim wa As Worksheet, inh As Variant, s As String, coversInh As Boolean, isCurrent As Boolean
    If Len(personId) = 0 Or addrRow <= 0 Then
        AddressHistoryStatusText = "�v�m�F"
        Exit Function
    End If
    Set wa = ThisWorkbook.Worksheets(SH_W_ADDR_HIST)
    If Len(CleanText(wa.Cells(addrRow, A_TEXT).Value)) = 0 Then
        AddressHistoryStatusText = "�v�m�F"
        Exit Function
    End If
    If Not IsDate(wa.Cells(addrRow, A_START).Value) Then
        AddressHistoryStatusText = "�v�m�F"
        Exit Function
    End If
    inh = GetInheritanceDate()
    If IsDate(inh) Then coversInh = AddressRowCoversEffectiveDate(wa.Cells(addrRow, A_START).Value, endDate, inh)
    isCurrent = AddressHistoryIsCurrentRow(personId, addrRow)
    If coversInh And isCurrent Then
        s = "�������E���Z��"
    ElseIf coversInh Then
        s = "�������Z��"
    ElseIf isCurrent Then
        s = "���Z��"
    Else
        s = "����"
    End If
    If EffectiveAddressStartKind(wa, addrRow) = "�c����" Then s = s & "�E�c����"
    AddressHistoryStatusText = s
End Function

Private Function AddressRowCoversEffectiveDate(ByVal startValue As Variant, ByVal endValue As Variant, ByVal targetDate As Variant) As Boolean
    If Not IsDate(targetDate) Then Exit Function
    If IsDate(startValue) Then
        If CDate(startValue) > CDate(targetDate) Then Exit Function
    End If
    If IsDate(endValue) Then
        If CDate(endValue) < CDate(targetDate) Then Exit Function
    End If
    AddressRowCoversEffectiveDate = True
End Function

Private Function AddressHistoryIsCurrentRow(ByVal personId As String, ByVal addrRow As Long) As Boolean
    Dim wa As Worksheet, r As Long, baseStart As Variant, otherStart As Variant, deathValue As Variant
    If Len(personId) = 0 Or addrRow <= 0 Then Exit Function
    Set wa = ThisWorkbook.Worksheets(SH_W_ADDR_HIST)
    If IsDate(wa.Cells(addrRow, A_END).Value) Then Exit Function
    deathValue = GetPersonValue(personId, P_DEATH)
    If IsDate(deathValue) Then Exit Function
    baseStart = wa.Cells(addrRow, A_START).Value
    If Not IsDate(baseStart) Then Exit Function
    For r = 2 To LastRow(wa, A_ID)
        If r <> addrRow Then
            If CleanText(wa.Cells(r, A_STATUS).Value) <> STATUS_CANCEL Then
                If CleanText(wa.Cells(r, A_PERSON_ID).Value) = personId Then
                    otherStart = wa.Cells(r, A_START).Value
                    If IsDate(otherStart) Then
                        If CDate(otherStart) > CDate(baseStart) Then Exit Function
                    End If
                End If
            End If
        End If
    Next r
    AddressHistoryIsCurrentRow = True
End Function

Private Sub PolishCohabitationOutput(ByVal ws As Worksheet, ByVal headerRow As Long, ByVal firstDataRow As Long, ByVal lastDataRow As Long)
    If ws Is Nothing Then Exit Sub
    If lastDataRow < firstDataRow Then lastDataRow = firstDataRow
    With ws.Range(ws.Cells(headerRow, 1), ws.Cells(lastDataRow, 11))
        .Font.Name = THEME_FONT
        .Font.Size = 10.4
        .VerticalAlignment = xlTop
        .WrapText = True
    End With
    ThemeApplyZebraTable ws.Range(ws.Cells(headerRow, 1), ws.Cells(lastDataRow, 11)), 1
    ThemeApplyPrintTable ws.Range(ws.Cells(headerRow, 1), ws.Cells(lastDataRow, 11)), 1
    ws.Columns("A:A").ColumnWidth = 9
    ws.Columns("B:B").ColumnWidth = 18
    ws.Columns("C:C").ColumnWidth = 10
    ws.Columns("D:D").ColumnWidth = 18
    ws.Columns("E:E").ColumnWidth = 10
    ws.Columns("F:F").ColumnWidth = 52
    ws.Columns("G:H").ColumnWidth = 12
    ws.Columns("I:I").ColumnWidth = 18
    ws.Columns("J:J").ColumnWidth = 15
    ws.Columns("K:K").ColumnWidth = 34
    ws.Rows("1:1").RowHeight = 30
    ws.Rows("3:5").RowHeight = 25
    ws.Rows("6:6").RowHeight = 12
    ws.Rows("7:7").RowHeight = 25
    ws.Rows(CStr(headerRow) & ":" & CStr(headerRow)).RowHeight = 28
    If lastDataRow >= firstDataRow Then
        FitCohabitationRowHeights ws, firstDataRow, lastDataRow
        HighlightCohabitationJudgement ws, firstDataRow, lastDataRow
        PolishCohabitationNameColumns ws, firstDataRow, lastDataRow
        MarkCohabitationAddressBreaks ws, firstDataRow, lastDataRow
    End If
    ThemeMarkMacroButtonsNonPrintable ws
    ApplyAdaptiveOutputPrint ws, ws.Range(ws.Cells(1, 1), ws.Cells(lastDataRow, 11)).Address, "$8:$8", lastDataRow, 11, True
End Sub

Private Sub FitCohabitationRowHeights(ByVal ws As Worksheet, ByVal firstDataRow As Long, ByVal lastDataRow As Long)
    Dim r As Long, addressLines As Long, evidenceLines As Long, targetHeight As Double
    If ws Is Nothing Then Exit Sub
    If lastDataRow < firstDataRow Then Exit Sub
    For r = firstDataRow To lastDataRow
        addressLines = Application.Max(1, WorksheetFunction.RoundUp(Application.Max(1, Len(CleanText(ws.Cells(r, 6).Value))) / 28, 0))
        evidenceLines = Application.Max(1, WorksheetFunction.RoundUp(Application.Max(1, Len(CleanText(ws.Cells(r, 11).Value))) / 18, 0))
        targetHeight = 42 + Application.Max(addressLines, evidenceLines) * 16
        If targetHeight < 58 Then targetHeight = 58
        If targetHeight > 164 Then targetHeight = 164
        ws.Rows(r).RowHeight = targetHeight
    Next r
End Sub

Private Sub SortCohabitationOutput(ByVal ws As Worksheet, ByVal lastDataRow As Long, Optional ByVal headerRow As Long = 8)
    If ws Is Nothing Then Exit Sub
    If lastDataRow <= headerRow + 1 Then Exit Sub
    On Error Resume Next
    With ws.Sort
        .SortFields.Clear
        .SortFields.Add Key:=ws.Range("F" & CStr(headerRow + 1) & ":F" & lastDataRow), Order:=xlAscending
        .SortFields.Add Key:=ws.Range("G" & CStr(headerRow + 1) & ":G" & lastDataRow), Order:=xlAscending
        .SortFields.Add Key:=ws.Range("B" & CStr(headerRow + 1) & ":B" & lastDataRow), Order:=xlAscending
        .SortFields.Add Key:=ws.Range("D" & CStr(headerRow + 1) & ":D" & lastDataRow), Order:=xlAscending
        .SetRange ws.Range("A" & CStr(headerRow) & ":K" & lastDataRow)
        .Header = xlYes
        .Apply
    End With
    On Error GoTo 0
End Sub

Private Sub MarkCohabitationAddressBreaks(ByVal ws As Worksheet, ByVal firstDataRow As Long, ByVal lastDataRow As Long)
    Dim r As Long
    If ws Is Nothing Then Exit Sub
    If lastDataRow < firstDataRow + 1 Then Exit Sub
    On Error Resume Next
    For r = firstDataRow + 1 To lastDataRow
        If CleanText(ws.Cells(r, 6).Value) <> CleanText(ws.Cells(r - 1, 6).Value) Then
            With ws.Range(ws.Cells(r, 1), ws.Cells(r, 11)).Borders(xlEdgeTop)
                .LineStyle = xlContinuous
                .Color = ThemeColor("border-strong")
                .Weight = xlMedium
            End With
            ws.Rows(r).RowHeight = ws.Rows(r).RowHeight + 8
        End If
    Next r
    On Error GoTo 0
End Sub

Private Sub PolishCohabitationNameColumns(ByVal ws As Worksheet, ByVal firstDataRow As Long, ByVal lastDataRow As Long)
    Dim r As Long
    If ws Is Nothing Then Exit Sub
    If lastDataRow < firstDataRow Then Exit Sub
    On Error Resume Next
    For r = firstDataRow To lastDataRow
        With ws.Range(ws.Cells(r, 2), ws.Cells(r, 5))
            .Interior.Color = ThemeColor("surface-soft")
            .Font.Color = ThemeColor("title")
        End With
        ws.Cells(r, 2).Font.Bold = True
        ws.Cells(r, 4).Font.Bold = True
        ws.Cells(r, 3).Font.Color = ThemeColor("muted-strong")
        ws.Cells(r, 5).Font.Color = ThemeColor("muted-strong")
        ws.Cells(r, 6).Font.Size = 10.2
        ws.Cells(r, 6).HorizontalAlignment = xlLeft
        ws.Cells(r, 6).VerticalAlignment = xlTop
        ws.Cells(r, 9).Font.Color = ThemeColor("muted-strong")
        ws.Cells(r, 10).HorizontalAlignment = xlCenter
        ws.Cells(r, 10).VerticalAlignment = xlCenter
        ws.Cells(r, 11).Font.Size = 9.8
        ws.Cells(r, 11).Font.Color = ThemeColor("muted-strong")
    Next r
    On Error GoTo 0
End Sub

Private Sub BuildCohabitationSummaryBand(ByVal ws As Worksheet, ByVal lastDataRow As Long, ByVal firstDataRow As Long)
    Dim totalCount As Long, needReviewCount As Long, addressCount As Long, strongCount As Long
    totalCount = CountNonBlankTextInRange(ws.Range(ws.Cells(firstDataRow, 1), ws.Cells(Application.Max(firstDataRow, lastDataRow), 1)))
    needReviewCount = CountTextContainsInRange(ws.Range(ws.Cells(firstDataRow, 10), ws.Cells(Application.Max(firstDataRow, lastDataRow), 10)), "�m�F")
    addressCount = CountDistinctTextInRange(ws.Range(ws.Cells(firstDataRow, 6), ws.Cells(Application.Max(firstDataRow, lastDataRow), 6)))
    strongCount = CountTextContainsInRange(ws.Range(ws.Cells(firstDataRow, 10), ws.Cells(Application.Max(firstDataRow, lastDataRow), 10)), "��������")
    WriteMetricCard ws.Range("A3:C5"), "��������", CStr(totalCount) & "��"
    WriteMetricCard ws.Range("D3:F5"), "����Z��", CStr(addressCount) & "��"
    WriteMetricCard ws.Range("G3:H5"), "����", CStr(strongCount) & "��"
    WriteMetricCard ws.Range("I3:K5"), "�v�m�F", CStr(needReviewCount) & "��"
End Sub

Private Sub HighlightCohabitationJudgement(ByVal ws As Worksheet, ByVal firstDataRow As Long, ByVal lastDataRow As Long)
    Dim r As Long, judgeText As String
    If ws Is Nothing Then Exit Sub
    If lastDataRow < firstDataRow Then Exit Sub
    For r = firstDataRow To lastDataRow
        judgeText = CleanText(ws.Cells(r, 10).Value)
        If InStr(judgeText, "�m�F") > 0 Then
            ws.Cells(r, 10).Interior.Color = ThemeColor("warning-soft")
            ws.Cells(r, 10).Font.Color = ThemeColor("warning-text")
            ws.Cells(r, 10).Font.Bold = True
            ws.Cells(r, 11).Interior.Color = ThemeColor("warning-soft")
        ElseIf Len(judgeText) > 0 Then
            ws.Cells(r, 10).Interior.Color = ThemeColor("success-soft")
            ws.Cells(r, 10).Font.Color = ThemeColor("success-text")
            ws.Cells(r, 10).Font.Bold = True
        End If
    Next r
End Sub







Private Sub SortAddressHistoryOutput(ByVal ws As Worksheet, ByVal lastDataRow As Long, Optional ByVal headerRow As Long = 3)
    If ws Is Nothing Then Exit Sub
    If lastDataRow <= headerRow + 1 Then Exit Sub
    On Error Resume Next
    With ws.Sort
        .SortFields.Clear
        .SortFields.Add Key:=ws.Range("A" & CStr(headerRow + 1) & ":A" & lastDataRow), Order:=xlAscending
        .SortFields.Add Key:=ws.Range("D" & CStr(headerRow + 1) & ":D" & lastDataRow), Order:=xlAscending
        .SetRange ws.Range("A" & CStr(headerRow) & ":J" & lastDataRow)
        .Header = xlYes
        .Apply
    End With
    On Error GoTo 0
End Sub


Private Function EffectiveAddressStartKind(ByVal wsA As Worksheet, ByVal rowNo As Long) As String
    Dim kindText As String
    kindText = CleanText(wsA.Cells(rowNo, A_START_KIND).Value)
    If kindText = "���Z�J�n" Or kindText = "�c����" Then
        EffectiveAddressStartKind = kindText
    Else
        EffectiveAddressStartKind = "���Z�J�n"
    End If
End Function

Private Function EffectiveEndDate(ByVal addrRow As Long) As Variant
    Dim wa As Worksheet, pid As String, r As Long, bestNext As Variant, baseDate As Variant, death As Variant
    Dim baseStart As Variant, otherStart As Variant
    Set wa = ThisWorkbook.Worksheets(SH_W_ADDR_HIST)
    If IsDate(wa.Cells(addrRow, A_END).Value) Then
        EffectiveEndDate = wa.Cells(addrRow, A_END).Value
        Exit Function
    End If
    pid = CleanText(wa.Cells(addrRow, A_PERSON_ID).Value)
    baseStart = wa.Cells(addrRow, A_START).Value
    If IsDate(baseStart) Then
        For r = 2 To LastRow(wa, 1)
            If r <> addrRow Then
                If CleanText(wa.Cells(r, A_PERSON_ID).Value) = pid Then
                    otherStart = wa.Cells(r, A_START).Value
                    If IsDate(otherStart) Then
                        If CDate(otherStart) > CDate(baseStart) Then
                            If Not IsDate(bestNext) Then
                                bestNext = otherStart
                            ElseIf CDate(otherStart) < CDate(bestNext) Then
                                bestNext = otherStart
                            End If
                        End If
                    End If
                End If
            End If
        Next r
    End If
    If IsDate(bestNext) Then
        EffectiveEndDate = DateAdd("d", -1, CDate(bestNext))
        Exit Function
    End If
    death = GetPersonValue(pid, P_DEATH)
    If IsDate(death) Then
        EffectiveEndDate = death
        Exit Function
    End If
    baseDate = ThisWorkbook.Worksheets(SH_CONFIG).Range(CELL_CONFIG_BASE_DATE).Value
    If IsDate(baseDate) Then
        EffectiveEndDate = baseDate
    Else
        EffectiveEndDate = ""
    End If
End Function

Private Sub BuildCohabitationTable()
    Dim ws As Worksheet, wa As Worksheet, r1 As Long, r2 As Long, outR As Long, coNo As Long
    Dim s1 As Variant, e1 As Variant, s2 As Variant, e2 As Variant, st As Variant, en As Variant
    Dim headerRow As Long, firstDataRow As Long, lastDataRow As Long
    Dim key1 As String, key2 As String, matchKind As String, judgeText As String, evidenceText As String
    Dim p1 As String, p2 As String, dupKey As String, written As Object
    Set ws = ThisWorkbook.Worksheets(SH_COHAB)
    ClearSheetAll ws
    ApplySheetCanvas ws
    headerRow = 8
    firstDataRow = headerRow + 1
    ws.Range("A1:K1").Merge
    TitleBannerStyle ws.Range("A1:K1"), "��������\"
    AddButton ws, "L1", "���֖͂߂�", "ShowOnlyInput", 90, 24
    ws.Range("A7:K7").Merge
    SectionStyle ws.Range("A7:K7"), "�������薾��"
    Set wa = ThisWorkbook.Worksheets(SH_W_ADDR_HIST)
    Set written = CreateObject("Scripting.Dictionary")
    outR = firstDataRow
    coNo = 1

    For r1 = 2 To LastRow(wa, 1)
        If CStr(wa.Cells(r1, A_STATUS).Value) <> STATUS_CANCEL Then
            key1 = CohabAddressCompareKey(wa, r1)
            If Len(key1) > 0 Then
                For r2 = r1 + 1 To LastRow(wa, 1)
                    If CStr(wa.Cells(r2, A_STATUS).Value) <> STATUS_CANCEL Then
                        key2 = CohabAddressCompareKey(wa, r2)
                        If Len(key2) > 0 Then
                            If key1 = key2 Then
                                p1 = CleanText(wa.Cells(r1, A_PERSON_ID).Value)
                                p2 = CleanText(wa.Cells(r2, A_PERSON_ID).Value)
                                If Len(p1) > 0 Then
                                    If Len(p2) > 0 Then
                                        If p1 <> p2 Then
                                            s1 = wa.Cells(r1, A_START).Value
                                            e1 = EffectiveEndDate(r1)
                                            s2 = wa.Cells(r2, A_START).Value
                                            e2 = EffectiveEndDate(r2)
                                            matchKind = CohabAddressMatchKind(key1)
                                            If CohabRowsHaveComparablePeriod(s1, e1, s2, e2) Then
                                                If CDate(s1) > CDate(s2) Then st = s1 Else st = s2
                                                If CDate(e1) < CDate(e2) Then en = e1 Else en = e2
                                                If CDate(st) <= CDate(en) Then
                                                    judgeText = "��������"
                                                    If matchKind <> "�Z���L�[��v" Then judgeText = "�����v�m�F"
                                                    evidenceText = matchKind & "�E���ԏd�� " & CStr(CohabitationOverlapDays(st, en)) & "��"
                                                    dupKey = CohabPairKey(p1, p2, key1, st, en)
                                                    If Not written.Exists(dupKey) Then
                                                        WriteCohab ws, outR, "CO" & Format(coNo, "000000"), p1, p2, wa.Cells(r1, A_TEXT).Value, st, en, judgeText, evidenceText
                                                        written.Add dupKey, True
                                                        coNo = coNo + 1
                                                        outR = outR + 1
                                                    End If
                                                End If
                                            Else
                                                judgeText = "���ԗv�m�F"
                                                evidenceText = matchKind & "�E�J�n���܂��͏I�������m�F"
                                                dupKey = CohabPairKey(p1, p2, key1, "", "")
                                                If Not written.Exists(dupKey) Then
                                                    WriteCohab ws, outR, "CO" & Format(coNo, "000000"), p1, p2, wa.Cells(r1, A_TEXT).Value, "", "", judgeText, evidenceText
                                                    written.Add dupKey, True
                                                    coNo = coNo + 1
                                                    outR = outR + 1
                                                End If
                                            End If
                                        End If
                                    End If
                                End If
                            End If
                        End If
                    End If
                Next r2
            End If
        End If
    Next r1
    lastDataRow = Application.Max(firstDataRow, outR - 1)
    SetRowValues ws.Cells(headerRow, 1), Array("����ID", "�l��A", "����A", "�l��B", "����B", "����Z��", "�J�n", "�I��", "����", "����", "�m�F�|�C���g")
    If outR > firstDataRow Then SortCohabitationOutput ws, lastDataRow, headerRow
    BuildCohabitationSummaryBand ws, lastDataRow, firstDataRow
    SetRowValues ws.Cells(headerRow, 1), Array("����ID", "�l��A", "����A", "�l��B", "����B", "����Z��", "�J�n", "�I��", "����", "����", "�m�F�|�C���g")
    HeaderStyle ws.Range(ws.Cells(headerRow, 1), ws.Cells(headerRow, 11))
    ws.Range(ws.Cells(firstDataRow, 7), ws.Cells(Application.Max(firstDataRow, lastDataRow), 8)).NumberFormatLocal = "yyyy/m/d"
    PolishCohabitationOutput ws, headerRow, firstDataRow, lastDataRow
End Sub

Private Function CohabRowsHaveComparablePeriod(ByVal s1 As Variant, ByVal e1 As Variant, ByVal s2 As Variant, ByVal e2 As Variant) As Boolean
    If Not IsDate(s1) Then Exit Function
    If Not IsDate(e1) Then Exit Function
    If Not IsDate(s2) Then Exit Function
    If Not IsDate(e2) Then Exit Function
    CohabRowsHaveComparablePeriod = True
End Function

Private Sub WriteMetricCard(ByVal rng As Range, ByVal labelText As String, ByVal valueText As String)
    If rng Is Nothing Then Exit Sub
    On Error Resume Next
    rng.Merge
    With rng
        .Interior.Color = ThemeColor("surface-raised")
        .Font.Name = THEME_FONT
        .Font.Color = ThemeColor("text")
        .HorizontalAlignment = xlCenter
        .VerticalAlignment = xlCenter
        .WrapText = True
        .Value = labelText & vbLf & valueText
        .Characters(1, Len(labelText)).Font.Size = 9
        .Characters(1, Len(labelText)).Font.Color = ThemeColor("muted-strong")
        .Characters(Len(labelText) + 2, Len(valueText)).Font.Size = 16
        .Characters(Len(labelText) + 2, Len(valueText)).Font.Bold = True
        .Characters(Len(labelText) + 2, Len(valueText)).Font.Color = ThemeColor("title")
    End With
    ThemeApplyCompleteBorders rng, "border"
    With rng.Borders(xlEdgeTop)
        .LineStyle = xlContinuous
        .Color = ThemeColor("accent")
        .Weight = xlMedium
    End With
    On Error GoTo 0
End Sub

Private Function CountDistinctTextInRange(ByVal rng As Range) As Long
    Dim d As Object, c As Range, key As String
    Set d = CreateObject("Scripting.Dictionary")
    If rng Is Nothing Then Exit Function
    For Each c In rng.Cells
        key = CleanText(c.Value)
        If Len(key) > 0 Then
            If Not d.Exists(key) Then d.Add key, True
        End If
    Next c
    CountDistinctTextInRange = d.Count
End Function

Private Function CountNonBlankTextInRange(ByVal rng As Range) As Long
    Dim c As Range
    If rng Is Nothing Then Exit Function
    For Each c In rng.Cells
        If Len(CleanText(c.Value)) > 0 Then CountNonBlankTextInRange = CountNonBlankTextInRange + 1
    Next c
End Function

Private Function CountTextContainsInRange(ByVal rng As Range, ByVal needleText As String) As Long
    Dim c As Range
    If rng Is Nothing Then Exit Function
    For Each c In rng.Cells
        If InStr(CleanText(c.Value), needleText) > 0 Then CountTextContainsInRange = CountTextContainsInRange + 1
    Next c
End Function

Private Function CountVisiblePersonsWithoutCurrentAddress() As Long
    Dim wp As Worksheet, r As Long, pid As String
    If Not SheetExists(SH_W_PERSON, ThisWorkbook) Then Exit Function
    Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)
    For r = 2 To LastRow(wp, P_ID)
        If VisibleDiagramPersonRow(r) Then
            pid = CleanText(wp.Cells(r, P_ID).Value)
            If Len(pid) > 0 Then
                If Len(CleanText(GetCurrentAddressText(pid))) = 0 Then CountVisiblePersonsWithoutCurrentAddress = CountVisiblePersonsWithoutCurrentAddress + 1
            End If
        End If
    Next r
End Function

Private Sub WriteCohab(ByVal ws As Worksheet, _
        ByVal outR As Long, _
        ByVal cohabId As String, _
        ByVal p1 As String, _
        ByVal p2 As String, _
        ByVal addr As String, _
        ByVal st As Variant, _
        ByVal en As Variant, _
        ByVal judge As String, _
        ByVal evidenceText As String)
    ws.Cells(outR, 1).Value = cohabId
    ws.Cells(outR, 2).Value = GetPersonValue(p1, P_DISPLAY)
    ws.Cells(outR, 3).Value = DiagramRelationDisplayText(CleanText(GetPersonValue(p1, P_REL_DEC)))
    ws.Cells(outR, 4).Value = GetPersonValue(p2, P_DISPLAY)
    ws.Cells(outR, 5).Value = DiagramRelationDisplayText(CleanText(GetPersonValue(p2, P_REL_DEC)))
    ws.Cells(outR, 6).Value = addr
    ws.Cells(outR, 7).Value = st
    ws.Cells(outR, 8).Value = en
    ws.Cells(outR, 9).Value = PeriodText(st, en)
    ws.Cells(outR, 10).Value = judge
    ws.Cells(outR, 11).Value = evidenceText
End Sub

Private Function CohabAddressCompareKey(ByVal wa As Worksheet, ByVal rowNo As Long) As String
    Dim keyText As String, addrText As String
    If wa Is Nothing Or rowNo <= 0 Then Exit Function
    If CleanText(wa.Cells(rowNo, A_STATUS).Value) = STATUS_CANCEL Then Exit Function
    keyText = CleanText(wa.Cells(rowNo, A_KEY).Value)
    If Len(keyText) > 0 Then
        CohabAddressCompareKey = "K|" & keyText
        Exit Function
    End If
    addrText = NormalizeAddressForCohabCompare(CleanText(wa.Cells(rowNo, A_TEXT).Value))
    If Len(addrText) >= 8 Then CohabAddressCompareKey = "T|" & addrText
End Function

Private Function CohabAddressMatchKind(ByVal compareKey As String) As String
    If Left$(compareKey, 2) = "K|" Then
        CohabAddressMatchKind = "�Z���L�[��v"
    Else
        CohabAddressMatchKind = "�Z���������v"
    End If
End Function

Private Function NormalizeAddressForCohabCompare(ByVal addrText As String) As String
    addrText = CleanText(addrText)
    addrText = Replace(addrText, " ", "")
    addrText = Replace(addrText, "�@", "")
    addrText = Replace(addrText, "����", "-")
    addrText = Replace(addrText, "�Ԓn", "-")
    addrText = Replace(addrText, "��", "-")
    addrText = Replace(addrText, "��", "")
    Do While InStr(addrText, "--") > 0
        addrText = Replace(addrText, "--", "-")
    Loop
    NormalizeAddressForCohabCompare = addrText
End Function

Private Function CohabPairKey(ByVal p1 As String, ByVal p2 As String, ByVal addrKey As String, ByVal st As Variant, ByVal en As Variant) As String
    Dim leftId As String, rightId As String
    p1 = CleanText(p1)
    p2 = CleanText(p2)
    If StrComp(p1, p2, vbTextCompare) <= 0 Then
        leftId = p1
        rightId = p2
    Else
        leftId = p2
        rightId = p1
    End If
    CohabPairKey = leftId & "|" & rightId & "|" & addrKey & "|" & CohabDateKey(st) & "|" & CohabDateKey(en)
End Function

Private Function CohabDateKey(ByVal v As Variant) As String
    If IsDate(v) Then CohabDateKey = Format$(CDate(v), "yyyymmdd")
End Function

Private Function CohabitationOverlapDays(ByVal st As Variant, ByVal en As Variant) As Long
    If Not IsDate(st) Then Exit Function
    If Not IsDate(en) Then Exit Function
    If CDate(en) >= CDate(st) Then CohabitationOverlapDays = DateDiff("d", CDate(st), CDate(en)) + 1
End Function

Private Sub BuildTimelineTable()
    Dim ws As Worksheet, wp As Worksheet, we As Worksheet
    Dim minY As Long, maxY As Long, r As Long, c As Long, y As Long
    Dim rowOut As Long, lastCol As Long, lastDataRow As Long, baseDate As Variant
    Set ws = ThisWorkbook.Worksheets(SH_TIMELINE)
    ClearSheetAll ws
    Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)
    Set we = ThisWorkbook.Worksheets(SH_W_EVENT)

    baseDate = ThisWorkbook.Worksheets(SH_CONFIG).Range(CELL_CONFIG_BASE_DATE).Value
    If IsDate(baseDate) Then
        maxY = Year(CDate(baseDate))
    Else
        maxY = Year(Date)
    End If
    minY = maxY
    For r = 2 To LastRow(we, 1)
        If IsNumeric(we.Cells(r, E_YEAR).Value) And CStr(we.Cells(r, E_STATUS).Value) <> STATUS_CANCEL Then
            If CLng(we.Cells(r, E_YEAR).Value) < minY Then minY = CLng(we.Cells(r, E_YEAR).Value)
            If CLng(we.Cells(r, E_YEAR).Value) > maxY Then maxY = CLng(we.Cells(r, E_YEAR).Value)
        End If
    Next r
    If minY > maxY Then minY = maxY

    ApplySheetCanvas ws

    c = 3
    For r = 2 To LastRow(wp, 1)
        If CStr(wp.Cells(r, P_STATUS).Value) <> STATUS_CANCEL And CStr(wp.Cells(r, P_SHOW).Value) <> SHOW_NO Then c = c + 2
    Next r
    lastCol = Application.Max(5, c - 1)

    ws.Range(ws.Cells(1, 1), ws.Cells(1, lastCol)).Merge
    TitleBannerStyle ws.Range(ws.Cells(1, 1), ws.Cells(1, lastCol)), "���n��\"
    AddButton ws, ws.Cells(1, lastCol).Address(False, False), "���֖͂߂�", "ShowOnlyInput", 90, 24

    ws.Cells(3, 1).Value = "����"
    ws.Range("A3:A5").Merge
    HeaderStyle ws.Range("A3:A5"), ThemeColor("blue")
    ws.Cells(3, 2).Value = "�a��"
    ws.Range("B3:B5").Merge
    HeaderStyle ws.Range("B3:B5"), ThemeColor("blue")

    c = 3
    For r = 2 To LastRow(wp, 1)
        If CStr(wp.Cells(r, P_STATUS).Value) <> STATUS_CANCEL And CStr(wp.Cells(r, P_SHOW).Value) <> SHOW_NO Then
            ws.Range(ws.Cells(3, c), ws.Cells(3, c + 1)).Merge
            ws.Cells(3, c).Value = wp.Cells(r, P_DISPLAY).Value
            ws.Range(ws.Cells(4, c), ws.Cells(4, c + 1)).Merge
            ws.Cells(4, c).Value = wp.Cells(r, P_REL_DEC).Value
            ws.Cells(5, c).Value = "�N��"
            ws.Cells(5, c + 1).Value = "�o����"
            HeaderStyle ws.Range(ws.Cells(3, c), ws.Cells(5, c + 1)), ThemeColor("muted-strong")
            c = c + 2
        End If
    Next r

    rowOut = 6
    For y = minY To maxY
        ws.Cells(rowOut, 1).Value = y
        ws.Cells(rowOut, 2).Value = EraYearText(y)
        c = 3
        For r = 2 To LastRow(wp, 1)
            If CStr(wp.Cells(r, P_STATUS).Value) <> STATUS_CANCEL And CStr(wp.Cells(r, P_SHOW).Value) <> SHOW_NO Then
                ws.Cells(rowOut, c).Value = AgeForYear(wp.Cells(r, P_BIRTH).Value, wp.Cells(r, P_DEATH).Value, y)
                ws.Cells(rowOut, c + 1).Value = EventsForPersonYear(wp.Cells(r, P_ID).Value, y)
                ws.Cells(rowOut, c).HorizontalAlignment = xlCenter
                ws.Cells(rowOut, c + 1).WrapText = True
                ws.Cells(rowOut, c + 1).VerticalAlignment = xlTop
                c = c + 2
            End If
        Next r
        If rowOut Mod 2 = 0 Then ws.Range(ws.Cells(rowOut, 1), ws.Cells(rowOut, lastCol)).Interior.Color = ThemeColor("canvas")
        rowOut = rowOut + 1
    Next y
    lastDataRow = Application.Max(6, rowOut - 1)
    With ws.Range(ws.Cells(3, 1), ws.Cells(lastDataRow, lastCol))
        .VerticalAlignment = xlTop
    End With
    ThemeApplyCompleteBorders ws.Range(ws.Cells(3, 1), ws.Cells(lastDataRow, lastCol)), "border"
    ws.Columns("A:A").ColumnWidth = 8
    ws.Columns("B:B").ColumnWidth = 16
    For c = 3 To lastCol
        If (c - 3) Mod 2 = 0 Then ws.Columns(c).ColumnWidth = 9 Else ws.Columns(c).ColumnWidth = 34
    Next c
    ws.Rows("1:5").RowHeight = 23
    ws.Rows("6:" & lastDataRow).RowHeight = 42
    PolishTimelineOutput ws, lastDataRow, lastCol
End Sub

Private Sub PolishTimelineOutput(ByVal ws As Worksheet, ByVal lastDataRow As Long, ByVal lastCol As Long)
    If ws Is Nothing Then Exit Sub
    ThemeMarkMacroButtonsNonPrintable ws
    ThemeApplyPrintTable ws.Range(ws.Cells(3, 1), ws.Cells(lastDataRow, lastCol)), 3
    ThemeCapRowHeights ws.Range(ws.Cells(6, 1), ws.Cells(lastDataRow, lastCol)), 32, 84
    ApplyAdaptiveOutputPrint ws, ws.Range(ws.Cells(1, 1), ws.Cells(lastDataRow, lastCol)).Address, "$1:$5", lastDataRow, lastCol, True
    On Error Resume Next
    ws.PageSetup.PrintTitleColumns = "$A:$B"
    On Error GoTo 0
End Sub

Private Function AgeForYear(ByVal birthDate As Variant, ByVal deathDate As Variant, ByVal y As Long) As String
    If Not IsDate(birthDate) Then AgeForYear = "": Exit Function
    If Year(CDate(birthDate)) > y Then AgeForYear = "�o���O": Exit Function
    If IsDate(deathDate) Then
        If Year(CDate(deathDate)) < y Then AgeForYear = "���S��": Exit Function
    End If
    Dim baseDate As Date
    baseDate = DateSerial(y, 12, 31)
    If IsDate(deathDate) Then
        If Year(CDate(deathDate)) = y Then baseDate = CDate(deathDate)
    End If
    AgeForYear = AgeOnDate(birthDate, baseDate)
End Function

Private Function EventsForPersonYear(ByVal personId As String, ByVal y As Long) As String
    Dim we As Worksheet, r As Long, s As String, lineText As String
    Dim seen As Object
    Set seen = CreateObject("Scripting.Dictionary")
    Set we = ThisWorkbook.Worksheets(SH_W_EVENT)
    For r = 2 To LastRow(we, 1)
        If CStr(we.Cells(r, E_PERSON_ID).Value) = personId And CLng(Val(we.Cells(r, E_YEAR).Value)) = y And CStr(we.Cells(r, E_STATUS).Value) <> STATUS_CANCEL Then
            lineText = ""
            If IsDate(we.Cells(r, E_DATE).Value) Then lineText = Format(we.Cells(r, E_DATE).Value, "m/d") & "�i" & EraCodeForDate(we.Cells(r, E_DATE).Value) & "�j "
            lineText = lineText & CStr(we.Cells(r, E_CONTENT).Value)
            If Not seen.Exists(lineText) Then
                seen.Add lineText, True
                If Len(s) > 0 Then s = s & vbLf
                s = s & lineText
            End If
        End If
    Next r
    EventsForPersonYear = s
End Function

Private Sub BuildPersonList()
    Dim ws As Worksheet, src As Worksheet
    Dim lastR As Long
    Set ws = ThisWorkbook.Worksheets(SH_PERSON_LIST)
    Set src = ThisWorkbook.Worksheets(SH_W_PERSON)
    ClearSheetAll ws
    ws.Range("A1:V1").Merge
    SectionStyle ws.Range("A1:V1"), "�l���ꗗ"
    AddButton ws, "W1", "���֖͂߂�", "ShowOnlyInput", 90, 24
    lastR = LastRow(src, 1)
    If lastR < 1 Then lastR = 1
    ws.Range("A3").Resize(lastR, 22).Value = src.Range("A1:V" & CStr(lastR)).Value
    HeaderStyle ws.Range("A3:V3")
    ws.Columns.AutoFit
    CapColumnWidths ws, 1, 22, 34
    PolishSimplePersonOutput ws, lastR + 2, 22, "$3:$3"
End Sub


Private Sub PolishSimplePersonOutput(ByVal ws As Worksheet, ByVal lastR As Long, ByVal lastC As Long, ByVal repeatRows As String)
    If ws Is Nothing Then Exit Sub
    ThemeMarkMacroButtonsNonPrintable ws
    If lastR < 1 Or lastC < 1 Then Exit Sub
    On Error Resume Next
    ThemeApplyPrintTable ws.Range(ws.Cells(3, 1), ws.Cells(lastR, lastC)), 1
    ThemeCapRowHeights ws.Range(ws.Cells(4, 1), ws.Cells(lastR, lastC)), 18, 72
    ApplyAdaptiveOutputPrint ws, ws.Range(ws.Cells(1, 1), ws.Cells(lastR, lastC)).Address, repeatRows, lastR, lastC, False
    On Error GoTo 0
End Sub

Private Sub ApplyAdaptiveOutputPrint(ByVal ws As Worksheet, _
        ByVal printAreaAddress As String, _
        ByVal repeatRows As String, _
        ByVal lastR As Long, _
        ByVal lastC As Long, _
        Optional ByVal preferWideBecauseMatrix As Boolean = False)
    Dim useLandscape As Boolean, fitWide As Long
    If ws Is Nothing Then Exit Sub
    useLandscape = ShouldUseLandscapeForOutput(lastR, lastC, preferWideBecauseMatrix)
    fitWide = FitWideForOutput(lastC, useLandscape)
    ThemeApplyMonochromePrint ws, printAreaAddress, useLandscape, repeatRows, fitWide, 0
End Sub

Private Function ShouldUseLandscapeForOutput(ByVal lastR As Long, ByVal lastC As Long, ByVal preferWideBecauseMatrix As Boolean) As Boolean
    If preferWideBecauseMatrix Then
        ShouldUseLandscapeForOutput = (lastC >= 7)
    ElseIf lastC >= 10 Then
        ShouldUseLandscapeForOutput = True
    ElseIf lastC <= 8 And lastR >= 36 Then
        ShouldUseLandscapeForOutput = False
    Else
        ShouldUseLandscapeForOutput = (lastC >= 8)
    End If
End Function

Private Function FitWideForOutput(ByVal lastC As Long, ByVal landscape As Boolean) As Long
    Dim baseCols As Long
    If landscape Then
        baseCols = 12
    Else
        baseCols = 8
    End If
    FitWideForOutput = CLng(Int((lastC + baseCols - 1) / baseCols))
    If FitWideForOutput < 1 Then FitWideForOutput = 1
    If FitWideForOutput > 4 Then FitWideForOutput = 4
End Function

Public Sub SaveCommonData()

    On Error GoTo EH

    Dim folderPath As String, outPath As String, wb As Workbook, shNames As Variant, tNames As Variant, i As Long
    Dim stepText As String

    folderPath = ThisWorkbook.Path

    If Len(folderPath) = 0 Then

        QuietWarn "��ɂ��̃u�b�N���Č��t�H���_�֕ۑ����Ă��������B", True, "�o�͑O�m�F"

        GoTo CleanExit

    End If

    AppBegin

    NormalizePersonRelationLabels

    RefreshRepresentativeAddresses

    EnsureMarriageHistoryWorkSheet

    SyncMarriageHistoryFromLegacyTables

    GenerateEvents

    BuildCohabitationTable

    ApplyOutputUsability

    outPath = folderPath & Application.PathSeparator & "00_���ʃf�[�^.xlsx"

    stepText = "�o�͗p�u�b�N�쐬"
    Set wb = Workbooks.Add(xlWBATWorksheet)

    shNames = Array(SH_CONFIG, SH_W_PERSON, SH_W_REL, SH_W_MARRIAGE_HIST, SH_W_ADDR_CAND, SH_W_ADDR_HIST, SH_COHAB, SH_W_EVENT)

    tNames = Array("T_�ݒ�_���{", "T_�l��", "T_�֌W", "T_��������", "T_�Z�����", "T_�Z������", "T_��������", "T_�C�x���g")

    For i = LBound(shNames) To UBound(shNames)

        If i = 0 Then

            wb.Worksheets(1).Name = tNames(i)

        Else

            wb.Worksheets.Add After:=wb.Worksheets(wb.Worksheets.Count)

            wb.Worksheets(wb.Worksheets.Count).Name = tNames(i)

        End If

        If CStr(tNames(i)) = "T_��������" Then

            WriteCohabCommonTable wb.Worksheets(tNames(i))

        Else

            CopySheetValuesToCommonWorkbook ThisWorkbook.Worksheets(shNames(i)), wb.Worksheets(tNames(i))

            wb.Worksheets(tNames(i)).Columns.AutoFit
            CapUsedColumnWidths wb.Worksheets(tNames(i)), 42

        End If

    Next i

    AddCommonDataControlSheets wb

    Application.CutCopyMode = False

    RuntimeSafeSaveAsXlsxAndClose wb, outPath, "SaveCommonData", "00_���ʃf�[�^.xlsx�ۑ�"

    LogAction "���ʃf�[�^�ۑ�", outPath

CleanExit:

    AppEnd

    If Len(outPath) > 0 Then NotifyInfo "���ʃf�[�^��ۑ����܂����B�㑱�c�[���͂��̃t�@�C����T_�l���AT_�Z�������AT_��������AT_�A�g�ݒ��ǂݍ��݂܂��B" & vbCrLf & outPath

    Exit Sub

EH:

    Dim errNum As Long, errDesc As String, errSrc As String
    errNum = Err.Number: errDesc = Err.Description: errSrc = Err.Source
    On Error Resume Next
    If Not wb Is Nothing Then wb.Close SaveChanges:=False
    AppEnd
    On Error GoTo 0
    RuntimeShowErrorValues "SaveCommonData", "���ʃf�[�^�ۑ�", "�ۑ��悪�J���Ă��Ȃ����A�o�̓t�H���_�֏������߂邩�m�F���Ă��������B", outPath, errNum, errDesc, errSrc

End Sub




Private Sub CopySheetValuesToCommonWorkbook(ByVal src As Worksheet, ByVal dst As Worksheet)
    'UsedRange/Clipboard���g�킸�A���f�[�^�͈͂�����z��]�L����B
    Dim lastR As Long, lastC As Long
    If src Is Nothing Or dst Is Nothing Then Exit Sub
    lastR = LastNonEmptyRow(src)
    lastC = LastNonEmptyColumn(src)
    If lastR < 1 Or lastC < 1 Then Exit Sub
    With dst.Range("A1").Resize(lastR, lastC)
        .Value = src.Range(src.Cells(1, 1), src.Cells(lastR, lastC)).Value
        .NumberFormat = src.Range(src.Cells(1, 1), src.Cells(lastR, lastC)).NumberFormat
    End With
End Sub

Private Function LastNonEmptyRow(ByVal ws As Worksheet) As Long
    Dim f As Range
    If ws Is Nothing Then Exit Function
    On Error Resume Next
    Set f = ws.Cells.Find(What:="*", LookIn:=xlFormulas, SearchOrder:=xlByRows, SearchDirection:=xlPrevious)
    On Error GoTo 0
    If Not f Is Nothing Then LastNonEmptyRow = f.Row
End Function

Private Function LastNonEmptyColumn(ByVal ws As Worksheet) As Long
    Dim f As Range
    If ws Is Nothing Then Exit Function
    On Error Resume Next
    Set f = ws.Cells.Find(What:="*", LookIn:=xlFormulas, SearchOrder:=xlByColumns, SearchDirection:=xlPrevious)
    On Error GoTo 0
    If Not f Is Nothing Then LastNonEmptyColumn = f.Column
End Function

Private Sub WriteCohabCommonTable(ByVal dst As Worksheet)
    '�㑱���̓c�[�����m���ɐl��ID�œ���������Q�Ƃł���悤�A
    '�\���p�̓�������\�ł͂Ȃ��AID�t���E1�s�ڃw�b�_�[�̘A�g��p�\�Ƃ��ĕۑ�����B
    Dim wa As Worksheet, r1 As Long, r2 As Long, outR As Long, coNo As Long
    Dim s1 As Variant, e1 As Variant, s2 As Variant, e2 As Variant, st As Variant, en As Variant
    Dim p1 As String, p2 As String, judge As String

    dst.Cells.Clear
    SetRowValues dst.Range("A1"), Array("��������ID", "�l��ID_A", "�l��A", "����A", "�l��ID_B", "�l��B", "����B", "�Z��", "�Z���L�[", "��������J�n", "��������I��", "����", "����")
    HeaderStyle dst.Range("A1:M1")

    Set wa = ThisWorkbook.Worksheets(SH_W_ADDR_HIST)
    outR = 2
    coNo = 1
    For r1 = 2 To LastRow(wa, 1)
        If CStr(wa.Cells(r1, A_STATUS).Value) <> STATUS_CANCEL And Len(CStr(wa.Cells(r1, A_KEY).Value)) > 0 Then
            For r2 = r1 + 1 To LastRow(wa, 1)
                If CStr(wa.Cells(r2, A_STATUS).Value) <> STATUS_CANCEL And wa.Cells(r1, A_KEY).Value = wa.Cells(r2, A_KEY).Value And wa.Cells(r1, A_PERSON_ID).Value <> wa.Cells(r2, A_PERSON_ID).Value Then
                    p1 = CStr(wa.Cells(r1, A_PERSON_ID).Value)
                    p2 = CStr(wa.Cells(r2, A_PERSON_ID).Value)
                    s1 = wa.Cells(r1, A_START).Value: e1 = EffectiveEndDate(r1)
                    s2 = wa.Cells(r2, A_START).Value: e2 = EffectiveEndDate(r2)
                    judge = "��������E���ԗv�m�F"
                    st = "": en = ""
                    If IsDate(s1) And IsDate(e1) And IsDate(s2) And IsDate(e2) Then
                        If CDate(s1) > CDate(s2) Then st = s1 Else st = s2
                        If CDate(e1) < CDate(e2) Then en = e1 Else en = e2
                        If CDate(st) <= CDate(en) Then
                            judge = "��������"
                        Else
                            GoTo NextPair
                        End If
                    End If
                    dst.Cells(outR, 1).Value = "CO" & Format(coNo, "000000")
                    dst.Cells(outR, 2).Value = p1
                    dst.Cells(outR, 3).Value = GetPersonValue(p1, P_DISPLAY)
                    dst.Cells(outR, 4).Value = GetPersonValue(p1, P_REL_DEC)
                    dst.Cells(outR, 5).Value = p2
                    dst.Cells(outR, 6).Value = GetPersonValue(p2, P_DISPLAY)
                    dst.Cells(outR, 7).Value = GetPersonValue(p2, P_REL_DEC)
                    dst.Cells(outR, 8).Value = wa.Cells(r1, A_TEXT).Value
                    dst.Cells(outR, 9).Value = wa.Cells(r1, A_KEY).Value
                    dst.Cells(outR, 10).Value = st
                    dst.Cells(outR, 11).Value = en
                    dst.Cells(outR, 12).Value = PeriodText(st, en)
                    dst.Cells(outR, 13).Value = judge
                    coNo = coNo + 1
                    outR = outR + 1
                End If
NextPair:
            Next r2
        End If
    Next r1
    If outR > 2 Then dst.Range("J2:K" & CStr(outR - 1)).NumberFormatLocal = "yyyy/m/d"
    dst.Columns.AutoFit
    CapUsedColumnWidths dst, 42
End Sub


Private Sub AddCommonDataControlSheets(ByVal wb As Workbook)

    Dim ws As Worksheet, decId As String, inheritDate As Variant, baseDate As Variant

    decId = GetDecedentId()

    inheritDate = GetInheritanceDate()

    baseDate = ThisWorkbook.Worksheets(SH_CONFIG).Range(CELL_CONFIG_BASE_DATE).Value



    Set ws = wb.Worksheets.Add(Before:=wb.Worksheets(1))

    ws.Name = "T_�A�g�ݒ�"

    ws.Range("A1:C1").Value = Array("�L�[", "�l", "����")

    ws.Range("A2:C2").Value = Array("���ʃf�[�^�d�l", "common-data", "�݊��p�B���ʃf�[�^�S�̂̎d�l")

    ws.Range("A3:C3").Value = Array("���ʃf�[�^�d�l", "common-data", "4�c�[�����ʂ̌Œ�d�l")

    ws.Range("A4:C4").Value = Array("�l���f�[�^�d�l", "PERSON_INFO", "�l���Z�����n��c�[���̏o�͎d�l")

    ws.Range("A5:C5").Value = Array("�����f�[�^�d�l", "���쐬", "02�c�[���ۑ���� T_�����A�g�ݒ� �ōX�V�E�m�F����")

    ws.Range("A6:C6").Value = Array("���̓f�[�^�d�l", "���쐬", "03�c�[���ۑ���� T_���͘A�g�ݒ� �ōX�V�E�m�F����")

    ws.Range("A7:C7").Value = Array("�`�[�˗��f�[�^�d�l", "���쐬", "04�c�[���ۑ���� T_�`�[�˗��A�g�ݒ� �ōX�V�E�m�F����")

    ws.Range("A8:C8").Value = Array("�Č�ID", "�g�p���Ȃ�", "1�Č�1�t�H���_�^�p�̂��߈Č�ID�͎����Ȃ�")

    ws.Range("A9:C9").Value = Array("�푊���l�l��ID", decId, "T_�l���̐l��ID�B�����n�Ŕ푊���l�����𔻒肷��")

    ws.Range("A10:C10").Value = Array("�����J�n��", inheritDate, "�����֘A�V�t�g����Ɏg��")

    ws.Range("A11:C11").Value = Array("�쐬���", baseDate, "�Z���I�����⊮�E���n��ŏI�N�Ɏg��")

    ws.Range("A12:C12").Value = Array("�ۑ�����", Now, "���̋��ʃf�[�^���쐬��������")

    ws.Range("A13:C13").Value = Array("�㑱�c�[��", "02_��������\_�c�����ڕ\�쐬�⏕�c�[��;03_�����ړ����̓c�[��;04_�`�[�˗��\�쐬�c�[��", "�ǂݍ��ݑ��̑z��")

    ws.Range("A14:C14").Value = Array("��v�L�[", "�l��ID;��������ID;�Z���L�[;����ID;���ID;��������ID", "�e�c�[���Ԃ̘A�g�L�[")

    ws.Range("A1:C1").Font.Bold = True

    ws.Range("A1:C1").Interior.Color = ThemeColor("text")

    ws.Range("A1:C1").Font.Color = vbWhite

    ws.Columns("A:C").AutoFit



    Set ws = wb.Worksheets.Add(After:=wb.Worksheets("T_�A�g�ݒ�"))

    ws.Name = "T_���ʃf�[�^����"

    ws.Range("A1:D1").Value = Array("�e�[�u����", "��L�[", "��ȗp�r", "�㑱�c�[��")

    ws.Range("A2:D2").Value = Array("T_�l��", "�l��ID", "�������`�l���A�����\���A�푊���l����", "�����֌W�E���́E�˗�")

    ws.Range("A3:D3").Value = Array("T_�֌W", "�֌WID", "�z��ҁE�e�q�̎Q�ƁB������/�������͋��`���݊�", "���́E���n��")

    ws.Range("A4:D4").Value = Array("T_��������", "��������ID", "���������E�����E���薢�o�^�̍�������", "���́E���n��")

    ws.Range("A5:D5").Value = Array("T_�Z�����", "�Z�����ID", "�Z���ė��p�E�Z���L�[�Ǘ�", "����")

    ws.Range("A6:D6").Value = Array("T_�Z������", "�Z��ID", "�Z�������E��������E�����J�n���Z��", "����")

    ws.Range("A7:D7").Value = Array("T_��������", "��������ID", "�Z���L�[��v�����ԏd���̌���", "����")

    ws.Range("A8:D8").Value = Array("T_�C�x���g", "�C�x���gID", "���n��E�㑱�C�x���g�ǉ��̓y��", "����")

    ws.Range("A9:D9").Value = Array("T_�A�g�ݒ�", "�L�[", "�����J�n���A�푊���l�l��ID�A���ʁE�l���ʃf�[�^�d�l", "�S�c�[��")

    ws.Range("A1:D1").Font.Bold = True

    ws.Range("A1:D1").Interior.Color = ThemeColor("text")

    ws.Range("A1:D1").Font.Color = vbWhite

    ws.Columns("A:D").AutoFit

End Sub



Public Sub ExportPersonInfoWorkbook()
    On Error GoTo EH
    Dim outFolder As String, outPath As String, wb As Workbook, shNames As Variant, i As Long
    Dim oldVis As Object, shName As String, stepText As String
    Set oldVis = CreateObject("Scripting.Dictionary")
    stepText = "�o�̓t�H���_�m�F"
    outFolder = EnsureOutputFolder()
    If Len(outFolder) = 0 Then
        QuietWarn "��ɂ��̃u�b�N���Č��t�H���_�֕ۑ����Ă��������B", True, "�o�͑O�m�F"
        GoTo CleanExit
    End If
    AppBegin
    outPath = outFolder & Application.PathSeparator & "01_�l����񐮗�����.xlsx"
    stepText = "�֌W���x������"
    NormalizePersonRelationLabels
    stepText = "��\�Z���X�V"
    RefreshRepresentativeAddresses
    stepText = "���n��C�x���g����"
    GenerateEvents
    stepText = "�m�F�ꗗ�쐬"
    BuildConfirmList
    stepText = "���̓`�F�b�N"
    RunChecks
    stepText = "�����֌W�}�쐬"
    BuildRelationshipDiagram
    stepText = "�Z�����𑁌��\�쐬"
    BuildAddressHistoryTable
    stepText = "��������\�쐬"
    BuildCohabitationTable
    stepText = "���n��\�쐬"
    BuildTimelineTable
    stepText = "�l���ꗗ�쐬"
    BuildPersonList
    stepText = "�o�̓V�[�g�ی�E�\������"
    ApplyOutputUsability
    shNames = Array(SH_DIAGRAM, SH_ADDR_TABLE, SH_COHAB, SH_TIMELINE, SH_PERSON_LIST, SH_CONFIRM, SH_CHECK)
    For i = LBound(shNames) To UBound(shNames)
        shName = CStr(shNames(i))
        oldVis(shName) = ThisWorkbook.Worksheets(shName).Visible
        ThisWorkbook.Worksheets(shName).Visible = xlSheetVisible
    Next i

    stepText = "�o�͗p�u�b�N�쐬"
    Set wb = Workbooks.Add(xlWBATWorksheet)
    For i = LBound(shNames) To UBound(shNames)
        shName = CStr(shNames(i))
        stepText = "�V�[�g�R�s�[: " & shName
        ThisWorkbook.Worksheets(shName).Copy After:=wb.Worksheets(wb.Worksheets.Count)
        wb.Worksheets(wb.Worksheets.Count).Name = shName
        wb.Worksheets(wb.Worksheets.Count).Visible = xlSheetVisible
    Next i
    Application.DisplayAlerts = False
    If wb.Worksheets.Count > 1 Then wb.Worksheets(1).Delete
    Application.DisplayAlerts = True
    stepText = "�o�̓u�b�N����"
    DeleteUiButtonsInWorkbook wb
    Application.CutCopyMode = False
    stepText = "�l����񐮗������ۑ�"
    RuntimeSafeSaveAsXlsxAndClose wb, outPath, "ExportPersonInfoWorkbook", "�l����񐮗������ۑ�"
    LogAction "�l����񐮗������o��", outPath
CleanExit:
    RestoreExportSourceSheetVisibility shNames, oldVis
    AppEnd
    If Len(outPath) > 0 Then NotifyInfo "�l����񐮗��������o�͂��܂���: " & outPath
    Exit Sub
EH:
    Dim errNum As Long, errDesc As String, errSrc As String
    errNum = Err.Number: errDesc = Err.Description: errSrc = Err.Source
    On Error Resume Next
    Application.DisplayAlerts = True
    RestoreExportSourceSheetVisibility shNames, oldVis
    If Not wb Is Nothing Then wb.Close SaveChanges:=False
    AppEnd
    On Error GoTo 0
    RuntimeShowErrorValues "ExportPersonInfoWorkbook", "�l����񐮗������o��", _
        "�����i�K: " & stepText & vbCrLf & "�o�͐�t�@�C�����J���Ă��Ȃ����A�o�̓t�H���_�֏������߂邩�m�F���Ă��������B", _
        outPath, errNum, errDesc, errSrc
End Sub

Private Sub RestoreExportSourceSheetVisibility(ByVal shNames As Variant, ByVal oldVis As Object)
    Dim i As Long, shName As String
    On Error Resume Next
    If oldVis Is Nothing Then Exit Sub
    If IsEmpty(shNames) Then Exit Sub
    For i = LBound(shNames) To UBound(shNames)
        shName = CStr(shNames(i))
        If oldVis.Exists(shName) Then ThisWorkbook.Worksheets(shName).Visible = oldVis(shName)
    Next i
    On Error GoTo 0
End Sub

Private Sub DeleteUiButtonsInWorkbook(ByVal wb As Workbook)
    Dim ws As Worksheet, i As Long, shp As Shape
    On Error Resume Next
    For Each ws In wb.Worksheets
        ws.Unprotect Password:=TOOL_PASSWORD
        For i = ws.Shapes.Count To 1 Step -1
            Set shp = ws.Shapes(i)
            If Left$(shp.Name, 4) = "btn_" Or Len(shp.OnAction) > 0 Then shp.Delete
        Next i
        ws.Cells.Locked = False
        ws.Protect Password:=TOOL_PASSWORD, DrawingObjects:=True, Contents:=True, Scenarios:=True, UserInterfaceOnly:=True
    Next ws
    On Error GoTo 0
End Sub

Private Sub LogAction(ByVal actionName As String, ByVal detail As String)
    Dim ws As Worksheet, r As Long
    Set ws = ThisWorkbook.Worksheets(SH_W_LOG)
    r = NextBlankRow(ws, 1)
    ws.Cells(r, 1).Value = Now
    ws.Cells(r, 2).Value = actionName
    ws.Cells(r, 3).Value = detail
End Sub

Private Sub PrepareOutputPathWithBackup(ByVal filePath As String)
    If Len(filePath) = 0 Then Exit Sub
    If Len(Dir$(filePath)) = 0 Then Exit Sub
    RuntimeBackupAndRemoveExistingFile filePath, "PrepareOutputPathWithBackup"
    AppendLinkLog "�����o�͑ޔ�", "�쐬", filePath
End Sub

# 01 人物情報 修正レポート

## 対象

01 人物情報のみ。02〜04は未変更。

## 修正の中心

相続関係図で、孫の配偶者を基準に子を登録した場合でも、婚姻日〜離婚日の期間中に出生した子であれば、図上は「孫と孫の配偶者の子」として扱うようにした。

これまでは、登録時に `孫 → 配偶者 → 子` の導線があっても、描画時に `孫の配偶者 → 子` のまま残り、孫本人の子孫ブロックへ戻らない場合があった。今回、描画前に関係を正規化し、W_関係・P_SUR_SRC・婚姻期間・出生年月日を使って親IDを確定する方式に変更した。

## 主な修正

### 1. 夫婦期間による子判定

以下を満たす場合、子は夫婦の子として血族側親IDへ戻す。

- 親候補が血族本人の配偶者である
- 配偶者関係が W_関係 または P_SUR_SRC から確認できる
- 子の出生年月日が婚姻日以後である
- 離婚日がある場合は、出生年月日が離婚日以前である
- 前配偶者・別父母・連れ子などの注記がない

対象例:

```text
孫 ─ 孫の配偶者
      │
      曽孫
```

内部的に一時的に `孫の配偶者 → 子` と残っていても、出生が婚姻期間内なら `孫 → 曽孫` として描画する。

### 2. 入力後の関係確定を補強

人物登録時に、以下を補強した。

- 父を基準に配偶者を登録した場合は母として確定
- 母を基準に配偶者を登録した場合は父として確定
- 孫などの配偶者を基準に子を登録し、出生が婚姻期間内なら血族側親IDへ確定
- 夫婦の子である場合、配偶者側の親子行も補助的に保持

### 3. 描画前の関係正規化

相続関係図作成前に、既存データも補正するようにした。

- 配偶者関係行に婚姻日・離婚日がない場合、人物側の婚姻日・離婚日から補完
- 父・母の親子行が欠けている場合、被相続人との親子行を補完
- 父の配偶者を母、母の配偶者を父として補正
- 孫・曽孫などの配偶者の子を、婚姻期間と出生年月日で血族側の子へ補正

### 4. カード表示の再調整

カード内表示を以下の方針に変更した。

- 続柄と性別を `続柄/性別` として併記
- 日付は `S11 1936/1/2` のように和暦を前に表示
- 生年月日は、相続時に生存している人物のみ相続時年齢を併記
- 没年月日は没年齢を併記
- 相続開始前に死亡している人物には相続時年齢を出さない
- 死亡者にも最後の住所を表示
- 配偶者の人物登録がなくても、人物側・婚姻履歴側・関係表側にある婚姻日/離婚日を表示
- メモを表示
- 文字の左端見切れを避けるため、カード左余白とカード高さを再調整

## 追加・変更した主な関数

- `NormalizeDiagramRelationsBeforeBuild`
- `NormalizeDiagramDescendantSpouseChildFacts`
- `NormalizeDiagramChildrenForCouple`
- `DiagramConfirmedParentIdForChildRow`
- `DiagramNormalizeParentCandidateByMarriage`
- `DiagramBloodlinePartnerForSpouseCandidate`
- `EnsureDiagramRelationRow`
- `DiagramAddressTextForCard`
- `GetLastAddressHistoryTextForCard`
- `ConfirmRelationshipFactsAfterRegister`
- `DiagramCardBodyText`

## 静的チェック

- CP932デコード OK
- Option Explicit不足なし
- Sub / Function / Property 開始終了不一致なし
- Public重複なし
- OnAction / AddButton / OnKey 未定義候補なし
- TextFrame2残存なし
- IIf残存なし
- Cells(r, 0)候補なし
- IMPORT_ORDER不足・余剰なし
- BAT ASCII OK
- VBS UTF-16LE BOM OK
- VBS ADODB.Stream + shift_jis 記述確認
- ZIP再展開テスト OK

## 未実施

この環境では以下は未実施。

- Windows 11 / Office 365 実機での一括インポート
- 実機ExcelでのVBEコンパイル
- 実Excel操作
- 印刷プレビュー
- 実データ通し検証

Attribute VB_Name = "modVisualTheme"
Option Explicit

' White Studio design system shared by the 4 workbooks.
' This is intentionally restrained: wide white space, soft borders, clear hierarchy,
' and monochrome-safe print output.
Public Const THEME_FONT As String = "Meiryo UI"
Public Const THEME_FONT_ALT As String = "Yu Gothic UI"
Public Const THEME_VERSION As String = "white-studio-v3-locked"

Public Function ThemeColor(ByVal roleName As String) As Long
    Select Case LCase$(Trim$(roleName))
        Case "title", "dark", "navy", "ink"
            ThemeColor = RGB(17, 24, 39)
        Case "header"
            ThemeColor = RGB(31, 41, 55)
        Case "accent", "blue"
            ThemeColor = RGB(29, 78, 216)
        Case "accent-soft"
            ThemeColor = RGB(219, 234, 254)
        Case "canvas", "background"
            ThemeColor = RGB(253, 253, 252)
        Case "surface", "card", "input"
            ThemeColor = RGB(255, 255, 255)
        Case "surface-soft", "section"
            ThemeColor = RGB(248, 250, 252)
        Case "surface-raised"
            ThemeColor = RGB(255, 255, 255)
        Case "locked", "protected"
            ThemeColor = RGB(246, 248, 251)
        Case "field"
            ThemeColor = RGB(255, 255, 255)
        Case "field-focus"
            ThemeColor = RGB(239, 246, 255)
        Case "flow", "hint", "info-very-soft"
            ThemeColor = RGB(245, 249, 255)
        Case "warning", "yellow", "warning-soft", "light-yellow"
            ThemeColor = RGB(255, 251, 235)
        Case "warning-strong"
            ThemeColor = RGB(254, 240, 138)
        Case "border"
            ThemeColor = RGB(226, 232, 240)
        Case "border-soft"
            ThemeColor = RGB(241, 245, 249)
        Case "border-strong"
            ThemeColor = RGB(148, 163, 184)
        Case "field-border"
            ThemeColor = RGB(203, 213, 225)
        Case "text"
            ThemeColor = RGB(15, 23, 42)
        Case "muted"
            ThemeColor = RGB(100, 116, 139)
        Case "muted-strong"
            ThemeColor = RGB(51, 65, 85)
        Case "line-muted"
            ThemeColor = RGB(148, 163, 184)
        Case "green"
            ThemeColor = RGB(21, 128, 61)
        Case "orange"
            ThemeColor = RGB(194, 65, 12)
        Case "red"
            ThemeColor = RGB(185, 28, 28)
        Case "purple"
            ThemeColor = RGB(109, 40, 217)
        Case "teal"
            ThemeColor = RGB(15, 118, 110)
        Case "success-bg", "success-soft", "light-green"
            ThemeColor = RGB(240, 253, 244)
        Case "success-border"
            ThemeColor = RGB(187, 247, 208)
        Case "success-text"
            ThemeColor = RGB(22, 101, 52)
        Case "danger-soft", "light-red"
            ThemeColor = RGB(254, 242, 242)
        Case "danger-text"
            ThemeColor = RGB(153, 27, 27)
        Case "danger-border"
            ThemeColor = RGB(248, 113, 113)
        Case "warning-text"
            ThemeColor = RGB(146, 64, 14)
        Case "info-soft", "light-blue"
            ThemeColor = RGB(239, 246, 255)
        Case "info-border"
            ThemeColor = RGB(191, 219, 254)
        Case "info-border-strong"
            ThemeColor = RGB(96, 165, 250)
        Case "purple-soft"
            ThemeColor = RGB(245, 243, 255)
        Case "orange-soft"
            ThemeColor = RGB(255, 247, 237)
        Case "teal-soft"
            ThemeColor = RGB(240, 253, 250)
        Case "teal-text"
            ThemeColor = RGB(15, 118, 110)
        Case "teal-border"
            ThemeColor = RGB(153, 246, 228)
        Case "shadow"
            ThemeColor = RGB(203, 213, 225)
        Case Else
            ThemeColor = RGB(253, 253, 252)
    End Select
End Function

Public Function ThemeButtonFill(ByVal captionOrRole As String) As Long
    Dim s As String
    s = LCase$(Trim$(captionOrRole))
    If InStr(s, "�o��") > 0 Or InStr(s, "����") > 0 Or InStr(s, "����") > 0 Or InStr(s, "export") > 0 Then
        ThemeButtonFill = ThemeColor("purple")
    ElseIf InStr(s, "�o�^") > 0 Or InStr(s, "�X�V") > 0 Or InStr(s, "�ۑ�") > 0 Or InStr(s, "����") > 0 Or InStr(s, "save") > 0 Then
        ThemeButtonFill = ThemeColor("green")
    ElseIf InStr(s, "�ꊇ") > 0 Or InStr(s, "����") > 0 Or InStr(s, "�쐬") > 0 Or InStr(s, "�ĕ���") > 0 Then
        ThemeButtonFill = ThemeColor("orange")
    ElseIf InStr(s, "�`�F�b�N") > 0 Or InStr(s, "�x��") > 0 Or InStr(s, "���O") > 0 Or InStr(s, "�N���A") > 0 Or InStr(s, "�폜") > 0 Or InStr(s, "������") > 0 Or InStr(s, "danger") > 0 Then
        ThemeButtonFill = ThemeColor("red")
    ElseIf InStr(s, "�Ǎ�") > 0 Or InStr(s, "����") > 0 Or InStr(s, "�\��") > 0 Or InStr(s, "�߂�") > 0 Or InStr(s, "�捞") > 0 Then
        ThemeButtonFill = ThemeColor("blue")
    ElseIf InStr(s, "�ݒ�") > 0 Or InStr(s, "���") > 0 Or InStr(s, "tool") > 0 Or InStr(s, "soft") > 0 Then
        ThemeButtonFill = ThemeColor("teal")
    Else
        ThemeButtonFill = ThemeColor("blue")
    End If
End Function

Public Sub ThemeApplyCanvas(ByVal ws As Worksheet)
    If ws Is Nothing Then Exit Sub
    With ws.Cells
        .Interior.Color = ThemeColor("canvas")
        .Font.Name = THEME_FONT
        .Font.Size = 10
        .Font.Color = ThemeColor("text")
        .VerticalAlignment = xlCenter
    End With
    On Error Resume Next
    ws.Parent.Windows(1).DisplayGridlines = False
    ws.Parent.Windows(1).DisplayHeadings = False
    On Error GoTo 0
End Sub

Public Sub ThemeApplyTitle(ByVal rng As Range, Optional ByVal titleText As String = "")
    If rng Is Nothing Then Exit Sub
    With rng
        .Interior.Color = ThemeColor("surface")
        .Font.Name = THEME_FONT
        .Font.Bold = True
        .Font.Color = ThemeColor("title")
        .Font.Size = 18
        .HorizontalAlignment = xlLeft
        .VerticalAlignment = xlCenter
        .WrapText = False
        .IndentLevel = 1
        .Borders.LineStyle = xlNone
    End With
    ThemeSetBorder rng.Borders(xlEdgeBottom), ThemeColor("accent"), xlMedium
    If Len(titleText) > 0 Then rng.Cells(1, 1).Value = titleText
End Sub

Public Sub ThemeApplyHeader(ByVal rng As Range, Optional ByVal fillColor As Long = 0)
    If rng Is Nothing Then Exit Sub
    If fillColor = 0 Then fillColor = ThemeColor("surface-soft")
    With rng
        .Interior.Color = fillColor
        .Font.Name = THEME_FONT
        .Font.Bold = True
        .Font.Color = ThemeReadableFontColor(fillColor)
        If ThemeBrightness(fillColor) > 178 Then .Font.Color = ThemeColor("muted-strong")
        .HorizontalAlignment = xlCenter
        .VerticalAlignment = xlCenter
    End With
    ThemeApplyCompleteBorders rng, "border"
    ThemeSetBorder rng.Borders(xlEdgeBottom), ThemeColor("border-strong"), xlThin
End Sub

Public Sub ThemeApplyTableHeader(ByVal rng As Range, Optional ByVal soft As Boolean = True)
    If rng Is Nothing Then Exit Sub
    With rng
        .Interior.Color = IIf(soft, ThemeColor("surface-soft"), ThemeColor("header"))
        .Font.Name = THEME_FONT
        .Font.Bold = True
        .Font.Size = 10
        .Font.Color = IIf(soft, ThemeColor("muted-strong"), vbWhite)
        .HorizontalAlignment = xlCenter
        .VerticalAlignment = xlCenter
    End With
    ThemeApplyCompleteBorders rng, "border"
    ThemeSetBorder rng.Borders(xlEdgeBottom), ThemeColor("border-strong"), xlThin
End Sub

Public Sub ThemeApplySection(ByVal rng As Range, Optional ByVal titleText As String = "")
    If rng Is Nothing Then Exit Sub
    With rng
        .Interior.Color = ThemeColor("surface")
        .Font.Name = THEME_FONT
        .Font.Bold = True
        .Font.Color = ThemeColor("muted-strong")
        .Font.Size = 10.5
        .HorizontalAlignment = xlLeft
        .VerticalAlignment = xlCenter
        .IndentLevel = 1
    End With
    ThemeApplyCompleteBorders rng, "border"
    ThemeSetBorder rng.Borders(xlEdgeLeft), ThemeColor("accent"), xlMedium
    If Len(titleText) > 0 Then rng.Cells(1, 1).Value = titleText
End Sub

Public Sub ThemeApplyInput(ByVal rng As Range)
    If rng Is Nothing Then Exit Sub
    With rng
        .Interior.Color = ThemeColor("field")
        .Font.Name = THEME_FONT
        .Font.Color = ThemeColor("text")
        .VerticalAlignment = xlCenter
        .HorizontalAlignment = xlLeft
        .IndentLevel = 1
    End With
    ThemeApplyCompleteBorders rng, "field-border"
End Sub

Public Sub ThemeApplyLocked(ByVal rng As Range)
    If rng Is Nothing Then Exit Sub
    With rng
        .Interior.Color = ThemeColor("locked")
        .Font.Name = THEME_FONT
        .Font.Color = ThemeColor("muted")
        .VerticalAlignment = xlCenter
    End With
    ThemeApplyCompleteBorders rng, "border"
End Sub

Public Sub ThemeApplyEditableFocus(ByVal rng As Range)
    If rng Is Nothing Then Exit Sub
    ThemeApplyInput rng
    rng.Interior.Color = ThemeColor("field-focus")
    ThemeApplyCompleteBorders rng, "info-border-strong"
End Sub

Public Sub ThemeApplyCardRange(ByVal rng As Range, Optional ByVal accentLeft As Boolean = False)
    If rng Is Nothing Then Exit Sub
    With rng
        .Interior.Color = ThemeColor("surface")
        .Font.Name = THEME_FONT
        .Font.Color = ThemeColor("text")
        .VerticalAlignment = xlCenter
    End With
    ThemeApplyCompleteBorders rng, "border"
    If accentLeft Then ThemeSetBorder rng.Borders(xlEdgeLeft), ThemeColor("accent"), xlMedium
End Sub

Public Sub ThemeApplyFormCard(ByVal rng As Range, Optional ByVal accentName As String = "accent")
    If rng Is Nothing Then Exit Sub
    With rng
        .Interior.Color = ThemeColor("surface")
        .Font.Name = THEME_FONT
        .Font.Color = ThemeColor("text")
        .VerticalAlignment = xlCenter
    End With
    ThemeApplyCompleteBorders rng, "border"
    ThemeSetBorder rng.Borders(xlEdgeTop), ThemeColor("border-soft"), xlThin
    ThemeSetBorder rng.Borders(xlEdgeLeft), ThemeColor(accentName), xlMedium
End Sub

Public Sub ThemeApplyCommandBar(ByVal rng As Range)
    If rng Is Nothing Then Exit Sub
    With rng
        .Interior.Color = ThemeColor("surface")
        .Font.Name = THEME_FONT
        .Font.Color = ThemeColor("text")
        .VerticalAlignment = xlCenter
    End With
    ThemeApplyCompleteBorders rng, "border"
    ThemeSetBorder rng.Borders(xlEdgeTop), ThemeColor("border-soft"), xlThin
End Sub

Public Sub ThemeApplyStatusCard(ByVal rng As Range)
    If rng Is Nothing Then Exit Sub
    ThemeApplyFormCard rng, "teal"
    With rng
        .Font.Name = THEME_FONT
        .Font.Color = ThemeColor("muted-strong")
        .VerticalAlignment = xlCenter
    End With
End Sub

Public Sub ThemeApplyHintRange(ByVal rng As Range, Optional ByVal roleName As String = "hint")
    If rng Is Nothing Then Exit Sub
    With rng
        .Interior.Color = ThemeColor(roleName)
        .Font.Name = THEME_FONT
        .Font.Color = ThemeColor("muted-strong")
        .WrapText = True
        .VerticalAlignment = xlCenter
        .IndentLevel = 1
    End With
    ThemeApplyCompleteBorders rng, "border"
    ThemeSetBorder rng.Borders(xlEdgeLeft), ThemeColor("accent"), xlMedium
End Sub

Public Sub ThemeApplyStepBar(ByVal rng As Range)
    If rng Is Nothing Then Exit Sub
    With rng
        .Interior.Color = ThemeColor("surface")
        .Font.Name = THEME_FONT
        .Font.Bold = True
        .Font.Color = ThemeColor("teal-text")
        .HorizontalAlignment = xlCenter
        .VerticalAlignment = xlCenter
    End With
    ThemeApplyCompleteBorders rng, "teal-border"
    ThemeSetBorder rng.Borders(xlEdgeBottom), ThemeColor("teal"), xlThin
End Sub

Public Sub ThemeApplyZebraTable(ByVal rng As Range, Optional ByVal headerRowCount As Long = 1)
    Dim i As Long
    If rng Is Nothing Then Exit Sub
    On Error Resume Next
    With rng
        .Font.Name = THEME_FONT
        .Font.Color = ThemeColor("text")
        .VerticalAlignment = xlCenter
    End With
    ThemeApplyCompleteBorders rng, "border"
    If headerRowCount > 0 Then ThemeApplyTableHeader rng.Resize(headerRowCount, rng.Columns.Count), True
    For i = headerRowCount + 1 To rng.Rows.Count
        If (i - headerRowCount) Mod 2 = 0 Then
            rng.Rows(i).Interior.Color = ThemeColor("surface-soft")
        Else
            rng.Rows(i).Interior.Color = ThemeColor("surface")
        End If
    Next i
    On Error GoTo 0
End Sub

Public Sub ThemeApplyCompleteBorders(ByVal rng As Range, Optional ByVal colorRole As String = "border", Optional ByVal lineWeight As Long = xlThin)
    If rng Is Nothing Then Exit Sub
    ThemeApplyCompleteBordersColor rng, ThemeColor(colorRole), lineWeight
End Sub

Public Sub ThemeApplyOuterBorders(ByVal rng As Range, Optional ByVal colorRole As String = "border", Optional ByVal lineWeight As Long = xlThin)
    If rng Is Nothing Then Exit Sub
    ThemeApplyOuterBordersColor rng, ThemeColor(colorRole), lineWeight
End Sub

Public Sub ThemeApplyCompleteBordersColor(ByVal rng As Range, ByVal borderColor As Long, Optional ByVal lineWeight As Long = xlThin)
    '�r���́u��x���͈̔͂��������� �� �����i�q �� �O�g�v�̏��Ŋm�肷��B
    '�Â��i�q�����c�����܂܏d�˓h�肵�Ȃ��B���ꂪ�r���œr�؂��/�]���ɐ����c�錴���ɂȂ�B
    If rng Is Nothing Then Exit Sub
    On Error Resume Next
    ThemeClearBorders rng
    With rng
        If .Columns.Count > 1 Then ThemeSetBorder .Borders(xlInsideVertical), borderColor, xlThin
        If .Rows.Count > 1 Then ThemeSetBorder .Borders(xlInsideHorizontal), borderColor, xlThin
        ThemeSetBorder .Borders(xlEdgeLeft), borderColor, lineWeight
        ThemeSetBorder .Borders(xlEdgeTop), borderColor, lineWeight
        ThemeSetBorder .Borders(xlEdgeBottom), borderColor, lineWeight
        ThemeSetBorder .Borders(xlEdgeRight), borderColor, lineWeight
    End With
    On Error GoTo 0
End Sub

Public Sub ThemeClearBorders(ByVal rng As Range)
    If rng Is Nothing Then Exit Sub
    On Error Resume Next
    rng.Borders(xlEdgeLeft).LineStyle = xlNone
    rng.Borders(xlEdgeTop).LineStyle = xlNone
    rng.Borders(xlEdgeBottom).LineStyle = xlNone
    rng.Borders(xlEdgeRight).LineStyle = xlNone
    rng.Borders(xlInsideVertical).LineStyle = xlNone
    rng.Borders(xlInsideHorizontal).LineStyle = xlNone
    On Error GoTo 0
End Sub

Public Sub ThemeApplyPanelBorders(ByVal rng As Range, _
        Optional ByVal outerRole As String = "field-border", _
        Optional ByVal innerRole As String = "border", _
        Optional ByVal outerWeight As Long = xlMedium)
    '�p�l���g�͐F�Ŏ咣�������Ȃ��B�F�͌��o���E�{�^���Ŏg���A�g���͑S�c�[���Œ����F�ɑ�����B
    '����: �p�l���͈͂̌Â��������� �� �����i�q �� �O�g�B
    If rng Is Nothing Then Exit Sub
    ThemeClearBorders rng
    ThemeApplyCompleteBorders rng, innerRole, xlThin
    ThemeApplyOuterBorders rng, ThemePanelOuterRole(outerRole), outerWeight
End Sub

Private Function ThemePanelOuterRole(ByVal roleName As String) As String
    Select Case LCase$(Trim$(roleName))
        Case "blue", "accent", "orange", "green", "teal", "purple", "red", "yellow", "warning"
            ThemePanelOuterRole = "field-border"
        Case "border-strong", "dark", "navy", "ink"
            ThemePanelOuterRole = "border-strong"
        Case ""
            ThemePanelOuterRole = "field-border"
        Case Else
            ThemePanelOuterRole = roleName
    End Select
End Function
Public Sub ThemeApplyOuterBordersColor(ByVal rng As Range, ByVal borderColor As Long, Optional ByVal lineWeight As Long = xlThin)
    If rng Is Nothing Then Exit Sub
    On Error Resume Next
    ThemeSetBorder rng.Borders(xlEdgeLeft), borderColor, lineWeight
    ThemeSetBorder rng.Borders(xlEdgeTop), borderColor, lineWeight
    ThemeSetBorder rng.Borders(xlEdgeBottom), borderColor, lineWeight
    ThemeSetBorder rng.Borders(xlEdgeRight), borderColor, lineWeight
    On Error GoTo 0
End Sub

Private Sub ThemeSetBorder(ByVal borderObj As Border, ByVal borderColor As Long, ByVal lineWeight As Long)
    If borderObj Is Nothing Then Exit Sub
    With borderObj
        .LineStyle = xlContinuous
        .Color = borderColor
        .Weight = lineWeight
    End With
End Sub

Public Sub ThemeStyleButtonShape(ByVal shp As Shape, ByVal caption As String, Optional ByVal styleName As String = "", Optional ByVal macroName As String = "")
    Dim fillColor As Long, lineColor As Long, fontColor As Long
    If shp Is Nothing Then Exit Sub
    ThemeButtonColors caption, styleName, fillColor, lineColor, fontColor
    ThemeStyleButtonShapeWithColor shp, caption, fillColor, lineColor, fontColor, macroName
End Sub

Public Sub ThemeStyleButtonShapeWithColor(ByVal shp As Shape, _
        ByVal caption As String, _
        ByVal fillColor As Long, _
        Optional ByVal lineColor As Long = 0, _
        Optional ByVal fontColor As Long = -1, _
        Optional ByVal macroName As String = "")
    Dim isLightButton As Boolean
    If shp Is Nothing Then Exit Sub
    If lineColor = 0 Then lineColor = fillColor
    If fontColor = -1 Then fontColor = ThemeReadableFontColor(fillColor)
    isLightButton = (ThemeBrightness(fillColor) > 220)
    On Error Resume Next
    With shp
        .Fill.Visible = msoTrue
        .Fill.ForeColor.RGB = fillColor
        .Line.Visible = msoTrue
        .Line.ForeColor.RGB = IIf(isLightButton, ThemeColor("field-border"), lineColor)
        .Line.Weight = IIf(isLightButton, 1, 0.85)
        .Placement = xlMoveAndSize
        .Locked = True
        .PrintObject = False
        If Len(macroName) > 0 Then .OnAction = macroName
        .Shadow.Visible = msoFalse
        .Adjustments.Item(1) = 0.16
        .TextFrame2.TextRange.Text = caption
        .TextFrame2.TextRange.Font.Name = THEME_FONT
        .TextFrame2.TextRange.Font.Size = ThemeButtonFontSize(caption, .Width, .Height)
        .TextFrame2.TextRange.Font.Bold = msoTrue
        .TextFrame2.TextRange.Font.Fill.ForeColor.RGB = fontColor
        .TextFrame2.VerticalAnchor = msoAnchorMiddle
        .TextFrame2.WordWrap = msoTrue
        .TextFrame2.AutoSize = msoAutoSizeNone
        .TextFrame2.TextRange.ParagraphFormat.Alignment = msoAlignCenter
        .TextFrame2.MarginLeft = IIf(.Width < 80 Or Len(caption) >= 10, 1, 3)
        .TextFrame2.MarginRight = IIf(.Width < 80 Or Len(caption) >= 10, 1, 3)
        .TextFrame2.MarginTop = 0
        .TextFrame2.MarginBottom = 0
    End With
    ThemeRegisterButtonShape shp, macroName
    If Err.Number <> 0 Then
        Err.Clear
        With shp
            .TextFrame.Characters.Text = caption
            .TextFrame.Characters.Font.Name = THEME_FONT
            .TextFrame.Characters.Font.Size = 9
            .TextFrame.Characters.Font.Bold = True
            .TextFrame.Characters.Font.Color = fontColor
            .TextFrame.HorizontalAlignment = xlHAlignCenter
            .TextFrame.VerticalAlignment = xlVAlignCenter
        End With
    End If
    On Error GoTo 0
End Sub

Private Function ThemeButtonFontSize(ByVal caption As String, ByVal widthPt As Double, ByVal heightPt As Double) As Double
    Dim n As Long
    n = Len(caption)
    If widthPt < 58 Or heightPt < 20 Then
        ThemeButtonFontSize = 7.0
    ElseIf widthPt < 74 Or n >= 14 Then
        ThemeButtonFontSize = IIf(heightPt >= 30, 8.0, 7.2)
    ElseIf n >= 10 Or widthPt < 96 Then
        ThemeButtonFontSize = IIf(heightPt >= 30, 8.8, 7.8)
    ElseIf n >= 7 Then
        ThemeButtonFontSize = IIf(heightPt >= 30, 9.3, 8.4)
    Else
        ThemeButtonFontSize = IIf(heightPt >= 30, 9.8, 8.9)
    End If
End Function

Public Sub ThemeStylePanelShape(ByVal shp As Shape, Optional ByVal accent As Boolean = False)
    If shp Is Nothing Then Exit Sub
    On Error Resume Next
    With shp
        .Fill.Visible = msoTrue
        .Fill.ForeColor.RGB = ThemeColor("surface")
        .Line.Visible = msoTrue
        .Line.ForeColor.RGB = IIf(accent, ThemeColor("info-border"), ThemeColor("border"))
        .Line.Weight = IIf(accent, 1.05, 0.75)
        .Placement = xlMoveAndSize
        .Locked = True
        .Shadow.Visible = msoFalse
        .PrintObject = False
        .Adjustments.Item(1) = 0.07
    End With
    ThemeRegisterDecorativeShape shp, False
    On Error GoTo 0
End Sub

Private Sub ThemeButtonColors(ByVal caption As String, ByVal styleName As String, ByRef fillColor As Long, ByRef lineColor As Long, ByRef fontColor As Long)
    Select Case LCase$(Trim$(styleName))
        Case "hero"
            fillColor = ThemeColor("ink")
            lineColor = ThemeColor("ink")
            fontColor = vbWhite
        Case "primary"
            fillColor = ThemeColor("blue")
            lineColor = ThemeColor("blue")
            fontColor = vbWhite
        Case "accent"
            fillColor = ThemeColor("teal")
            lineColor = ThemeColor("teal")
            fontColor = vbWhite
        Case "export"
            fillColor = ThemeColor("purple")
            lineColor = ThemeColor("purple")
            fontColor = vbWhite
        Case "danger"
            fillColor = ThemeColor("red")
            lineColor = ThemeColor("red")
            fontColor = vbWhite
        Case "tool", "soft", "neutral", "secondary"
            fillColor = ThemeColor("surface")
            lineColor = ThemeColor("border")
            fontColor = ThemeColor("muted-strong")
        Case Else
            fillColor = ThemeButtonFill(caption)
            lineColor = fillColor
            fontColor = ThemeReadableFontColor(fillColor)
    End Select
End Sub

Public Function ThemeReadableFontColor(ByVal fillColor As Long) As Long
    If ThemeBrightness(fillColor) > 178 Then
        ThemeReadableFontColor = ThemeColor("text")
    Else
        ThemeReadableFontColor = vbWhite
    End If
End Function

Private Function ThemeBrightness(ByVal colorValue As Long) As Double
    Dim r As Long, g As Long, b As Long
    r = colorValue Mod 256
    g = (colorValue \ 256) Mod 256
    b = (colorValue \ 65536) Mod 256
    ThemeBrightness = 0.299 * r + 0.587 * g + 0.114 * b
End Function


Public Sub ThemeRegisterButtonShape(ByVal shp As Shape, Optional ByVal macroName As String = "")
    If shp Is Nothing Then Exit Sub
    On Error Resume Next
    ThemeSetShapeTag shp, "ui_kind", "button"
    If Len(macroName) > 0 Then ThemeSetShapeTag shp, "ui_macro", macroName
    shp.Locked = True
    shp.Placement = xlMoveAndSize
    shp.PrintObject = False
    If Len(macroName) > 0 Then shp.OnAction = macroName
    shp.ZOrder msoBringToFront
    On Error GoTo 0
End Sub

Public Sub ThemeRegisterDecorativeShape(ByVal shp As Shape, Optional ByVal printObject As Boolean = False)
    If shp Is Nothing Then Exit Sub
    On Error Resume Next
    ThemeSetShapeTag shp, "ui_kind", "decor"
    ThemeSetShapeTag shp, "ui_print", IIf(printObject, "print", "nonprint")
    shp.Locked = True
    shp.Placement = xlMoveAndSize
    shp.PrintObject = printObject
    On Error GoTo 0
End Sub

Private Sub ThemeSetShapeTag(ByVal shp As Shape, ByVal tagName As String, ByVal tagValue As String)
    If shp Is Nothing Then Exit Sub
    On Error Resume Next
    shp.Tags.Delete tagName
    shp.Tags.Add tagName, tagValue
    On Error GoTo 0
End Sub

Private Function ThemeShapeTagValue(ByVal shp As Shape, ByVal tagName As String) As String
    If shp Is Nothing Then Exit Function
    On Error Resume Next
    ThemeShapeTagValue = CStr(shp.Tags(tagName))
    On Error GoTo 0
End Function

Public Function ThemeIsButtonShape(ByVal shp As Shape) As Boolean
    Dim nm As String
    If shp Is Nothing Then Exit Function
    On Error Resume Next
    nm = LCase$(shp.Name)
    ThemeIsButtonShape = (Len(shp.OnAction) > 0) _
                         Or (InStr(1, nm, "btn", vbTextCompare) > 0) _
                         Or (ThemeShapeTagValue(shp, "ui_kind") = "button")
    On Error GoTo 0
End Function

Public Function ThemeIsDecorativeShape(ByVal shp As Shape) As Boolean
    If shp Is Nothing Then Exit Function
    ThemeIsDecorativeShape = Not ThemeIsButtonShape(shp)
End Function

Public Sub ThemeLockShapeLayer(ByVal ws As Worksheet)
    Dim shp As Shape
    Dim isButton As Boolean
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    For Each shp In ws.Shapes
        isButton = ThemeIsButtonShape(shp)
        shp.Locked = True
        If isButton Then
            ThemeSetShapeTag shp, "ui_kind", "button"
            shp.Placement = xlMoveAndSize
            shp.PrintObject = False
            shp.ZOrder msoBringToFront
        Else
            ThemeSetShapeTag shp, "ui_kind", "decor"
            shp.Placement = xlMoveAndSize
            If Left$(shp.Name, 3) = "ui_" Or ThemeShapeTagValue(shp, "ui_print") = "nonprint" Then
                shp.PrintObject = False
            End If
        End If
    Next shp
    On Error GoTo 0
End Sub

Public Sub ThemePrepareSheetForProtection(ByVal ws As Worksheet)
    If ws Is Nothing Then Exit Sub
    ThemeLockShapeLayer ws
    ThemeMarkMacroButtonsNonPrintable ws
End Sub

Public Sub ThemeMarkMacroButtonsNonPrintable(ByVal ws As Worksheet)
    Dim shp As Shape
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    For Each shp In ws.Shapes
        If ThemeIsButtonShape(shp) Then
            shp.PrintObject = False
            shp.Locked = True
            shp.Placement = xlMoveAndSize
            shp.ZOrder msoBringToFront
        End If
    Next shp
    On Error GoTo 0
End Sub

Public Sub ThemeApplyMonochromePrint(ByVal ws As Worksheet, _
        ByVal printAreaAddress As String, _
        Optional ByVal landscape As Boolean = True, _
        Optional ByVal repeatRows As String = "", _
        Optional ByVal fitWide As Long = 1, _
        Optional ByVal fitTall As Long = 0)
    If ws Is Nothing Then Exit Sub
    ThemePrepareSheetForProtection ws
    On Error Resume Next
    With ws.PageSetup
        .PaperSize = xlPaperA4
        If landscape Then
            .Orientation = xlLandscape
        Else
            .Orientation = xlPortrait
        End If
        .Zoom = False
        If fitWide <= 0 Then fitWide = 1
        .FitToPagesWide = fitWide
        If fitTall > 0 Then
            .FitToPagesTall = fitTall
        Else
            .FitToPagesTall = False
        End If
        .LeftMargin = Application.CentimetersToPoints(0.55)
        .RightMargin = Application.CentimetersToPoints(0.55)
        .TopMargin = Application.CentimetersToPoints(0.65)
        .BottomMargin = Application.CentimetersToPoints(0.65)
        .HeaderMargin = Application.CentimetersToPoints(0.25)
        .FooterMargin = Application.CentimetersToPoints(0.25)
        .CenterHorizontally = True
        .CenterVertically = False
        .PrintGridlines = False
        .PrintHeadings = False
        .BlackAndWhite = True
        .Draft = False
        .CenterFooter = "&P / &N"
        If Len(printAreaAddress) > 0 Then .PrintArea = printAreaAddress
        If Len(repeatRows) > 0 Then
            .PrintTitleRows = repeatRows
        Else
            .PrintTitleRows = ""
        End If
    End With
    On Error GoTo 0
End Sub

Public Sub ThemeApplyPrintTable(ByVal rng As Range, Optional ByVal headerRowCount As Long = 1)
    Dim headerRng As Range
    If rng Is Nothing Then Exit Sub
    On Error Resume Next
    With rng
        .Font.Name = THEME_FONT
        .Font.Color = ThemeColor("text")
        .VerticalAlignment = xlTop
    End With
    ThemeApplyCompleteBordersColor rng, RGB(0, 0, 0), xlThin
    If headerRowCount > 0 Then
        Set headerRng = rng.Resize(Application.Min(headerRowCount, rng.Rows.Count), rng.Columns.Count)
        With headerRng
            .Interior.Color = RGB(235, 235, 235)
            .Font.Color = RGB(0, 0, 0)
            .Font.Bold = True
            .HorizontalAlignment = xlCenter
            .VerticalAlignment = xlCenter
        End With
        ThemeApplyCompleteBordersColor headerRng, RGB(0, 0, 0), xlMedium
    End If
    On Error GoTo 0
End Sub

Public Sub ThemeCapRowHeights(ByVal rng As Range, Optional ByVal minHeight As Double = 18, Optional ByVal maxHeight As Double = 96)
    Dim rowRng As Range
    If rng Is Nothing Then Exit Sub
    On Error Resume Next
    For Each rowRng In rng.Rows
        If rowRng.RowHeight < minHeight Then rowRng.RowHeight = minHeight
        If rowRng.RowHeight > maxHeight Then rowRng.RowHeight = maxHeight
    Next rowRng
    On Error GoTo 0
End Sub

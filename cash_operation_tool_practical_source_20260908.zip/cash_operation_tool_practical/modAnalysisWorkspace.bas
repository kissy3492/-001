Attribute VB_Name = "modAnalysisWorkspace"
Option Explicit

'��������\�֕\����������A������9��̒����P�ʂ֏W�񂷂�B
'����3���͕\�ƌ��ڍׂ́A�m�F�L�^�Ɗč�������ێ���������\�Ƃ��Ďc���B
Private Const WORKSPACE_BUFFER_ROWS As Long = 1000
Private Const WORKSPACE_MEMO_MAX As Long = 1000
Private Const WORKSPACE_DETAIL_LIMIT As Long = 500
Private Const WORKSPACE_TEXT_LIMIT As Long = 1000
Private Const MANUAL_BUILDER_MAX_ROWS As Long = 50000
Private Const MANUAL_BUILDER_HEADER_ROW As Long = 5
Private Const DETAIL_COL_KIND As Long = 8
Private Const DETAIL_COL_REFERENCE As Long = 9
Private Const DETAIL_COL_SOURCE_ROW As Long = 10
Private Const DETAIL_COL_SOURCE_KEY As Long = 11
Private Const DETAIL_COL_SELECTED As Long = 12
Private Const ANALYSIS_CAPACITY_BASE_COLUMNS As Long = 16
Private Const ANALYSIS_CAPACITY_LONG_MAX As Double = 2147483647#
Private Const ANALYSIS_CAPACITY_64_PROMPT_ROWS As Double = 150000#
Private Const ANALYSIS_CAPACITY_32_PROMPT_ROWS As Double = 50000#
Private Const ANALYSIS_CAPACITY_32_MAX_ROWS As Double = 75000#
Private Const WORKSPACE_PERSON_DIFFERENT As String = "�ʐl����"
Private Const WORKSPACE_PERSON_SAME As String = "����l����"
Private Const ANALYSIS_WORKSPACE_RECOVERY_FATAL_ERROR As Long = vbObjectError + 5191
Private Const ANALYSIS_WORKSPACE_RECOVERY_FATAL_SOURCE As String = _
    "AnalysisWorkspaceRecoveryFatal/"

Private Type AnalysisDetailSelectionSnapshot
    ItemCount As Long
    Rows() As Long
    SelectedValues() As Variant
    SelectedHasFormula() As Boolean
    SelectedFormulas() As String
    DisplayValues() As Variant
    DisplayHasFormula() As Boolean
    DisplayFormulas() As String
    FillColors() As Long
    FillPatterns() As Long
    FillTints() As Double
    FontBolds() As Boolean
    SummaryValue As Variant
    SummaryHasFormula As Boolean
    SummaryFormula As String
End Type

Private mAnalysisDetailReviewsDirty As Boolean

Private Function AnalysisCapacitySheetRows(ByVal sheetName As String, _
                                           ByVal lastColumn As Long) As Long
    Dim lastR As Long
    If lastColumn < 1 Then _
        Err.Raise vbObjectError + 4865, "AnalysisCapacitySheetRows", _
                  "���͗e�ʂ̌����񂪕s���ł�: " & sheetName
    If Not SheetExists(sheetName) Then _
        Err.Raise vbObjectError + 4866, "AnalysisCapacitySheetRows", _
                  "���͗e�ʂ���������V�[�g������܂���: " & sheetName
    lastR = LastDataRowInColumns(GetSheet(sheetName), 1, lastColumn)
    If lastR >= 2 Then AnalysisCapacitySheetRows = lastR - 1
End Function

Private Function AnalysisReviewCellWork( _
        ByVal reviewRows As Long, ByVal historyRows As Long, _
        ByVal shiftRows As Long, ByVal flowRows As Long, ByVal unknownRows As Long, _
        ByVal resultRows As Long, ByVal groupRows As Long, ByVal detailRows As Long, _
        ByVal manualRows As Long, ByVal transactionRows As Long) As Double
    If reviewRows < 0 Or historyRows < 0 Or shiftRows < 0 Or flowRows < 0 Or _
       unknownRows < 0 Or resultRows < 0 Or groupRows < 0 Or detailRows < 0 Or _
       manualRows < 0 Or transactionRows < 0 Then _
        Err.Raise vbObjectError + 4867, "AnalysisReviewCellWork", _
                  "���͗e�ʂ̍s���ɕ���������܂��B"
    AnalysisReviewCellWork = _
        CDbl(reviewRows) * CDbl(ANALYSIS_REVIEW_STORE_LAST_COL) + _
        CDbl(historyRows) * CDbl(ANALYSIS_HISTORY_STORE_LAST_COL) + _
        CDbl(shiftRows) * CDbl(SHIFT_ANALYSIS_LAST_COL) + _
        CDbl(flowRows) * CDbl(FLOW_ANALYSIS_LAST_COL) + _
        CDbl(unknownRows) * CDbl(UNKNOWN_ANALYSIS_LAST_COL) + _
        CDbl(resultRows) * CDbl(ANALYSIS_RESULT_LAST_COL) + _
        CDbl(groupRows) * CDbl(ANALYSIS_GROUP_LAST_COL) + _
        CDbl(detailRows) * CDbl(DETAIL_COL_SELECTED) + _
        CDbl(manualRows) * CDbl(MANUAL_FLOW_STORE_LAST_COL) + _
        CDbl(transactionRows) * CDbl(WORK_TX_COL_PERSON_ID)
End Function

Private Function AnalysisCapacityEquivalentRows(ByVal cellWork As Double) As Double
    Dim equivalentRows As Double
    If cellWork < 0# Then _
        Err.Raise vbObjectError + 4867, "AnalysisCapacityEquivalentRows", _
                  "���͗e�ʂ̃Z�������s���ł��B"
    equivalentRows = Int(cellWork / CDbl(ANALYSIS_CAPACITY_BASE_COLUMNS))
    If cellWork > equivalentRows * CDbl(ANALYSIS_CAPACITY_BASE_COLUMNS) Then _
        equivalentRows = equivalentRows + 1#
    AnalysisCapacityEquivalentRows = equivalentRows
End Function

Private Function AnalysisWorkspaceCandidateWorkloadRows( _
        ByVal shiftRows As Long, ByVal flowRows As Long) As Double
    If shiftRows < 0 Or flowRows < 0 Then _
        Err.Raise vbObjectError + 4867, "AnalysisWorkspaceCandidateWorkloadRows", _
                  "���͌��̍s�����s���ł��B"
    AnalysisWorkspaceCandidateWorkloadRows = CDbl(shiftRows) + CDbl(flowRows)
End Function

Private Function AnalysisCapacityNeedsConfirmation( _
        ByVal requiredWorkloadRows As Double, _
        ByVal confirmedWorkloadRows As Double) As Boolean
#If Win64 Or Mac Then
    AnalysisCapacityNeedsConfirmation = _
        (requiredWorkloadRows > ANALYSIS_CAPACITY_64_PROMPT_ROWS And _
         confirmedWorkloadRows <= ANALYSIS_CAPACITY_64_PROMPT_ROWS)
#Else
    If requiredWorkloadRows > ANALYSIS_CAPACITY_32_MAX_ROWS Then
        AnalysisCapacityNeedsConfirmation = True
    Else
        AnalysisCapacityNeedsConfirmation = _
            (requiredWorkloadRows > ANALYSIS_CAPACITY_32_PROMPT_ROWS And _
             confirmedWorkloadRows <= ANALYSIS_CAPACITY_32_PROMPT_ROWS)
    End If
#End If
End Function

Public Function ConfirmAnalysisReviewOperationCapacity( _
        ByVal operationName As String, ByRef confirmedWorkloadRows As Double, _
        Optional ByVal plannedShiftRows As Long = -1, _
        Optional ByVal plannedFlowRows As Long = -1, _
        Optional ByVal plannedUnknownRows As Long = -1, _
        Optional ByVal plannedResultRows As Long = -1, _
        Optional ByVal plannedGroupRows As Long = -1, _
        Optional ByVal allowUserConfirmation As Boolean = True, _
        Optional ByVal additionalManualRows As Long = 0, _
        Optional ByVal additionalSnapshotCellWork As Double = 0#) As Boolean
    Dim reviewRows As Long, historyRows As Long
    Dim shiftRows As Long, flowRows As Long, unknownRows As Long
    Dim resultRows As Long, groupRows As Long, detailRows As Long
    Dim manualRows As Long, transactionRows As Long
    Dim sourceRows As Double, plannedManualRows As Double
    Dim cellWork As Double, requiredWorkloadRows As Double

    If confirmedWorkloadRows < 0# Or confirmedWorkloadRows > ANALYSIS_CAPACITY_LONG_MAX Then _
        Err.Raise vbObjectError + 4869, "ConfirmAnalysisReviewOperationCapacity", _
                  "�m�F�ς݂̕��͗e�ʂ��s���ł��B"
#If Win64 Or Mac Then
#Else
    If confirmedWorkloadRows > ANALYSIS_CAPACITY_32_MAX_ROWS Then _
        Err.Raise vbObjectError + 4869, "ConfirmAnalysisReviewOperationCapacity", _
                  "32bit��Excel�̈��S����𒴂���m�F�ςݕ��͗e�ʂ͎g�p�ł��܂���B"
#End If
    If plannedShiftRows < -1 Or plannedFlowRows < -1 Or plannedUnknownRows < -1 Or _
       plannedResultRows < -1 Or plannedGroupRows < -1 Then _
        Err.Raise vbObjectError + 4867, "ConfirmAnalysisReviewOperationCapacity", _
                  "���̗͂\��s�����s���ł��B"
    If additionalManualRows < 0 Then _
        Err.Raise vbObjectError + 4867, "ConfirmAnalysisReviewOperationCapacity", _
                  "�蓮���̒ǉ��\��s�����s���ł��B"
    If additionalSnapshotCellWork < 0# Or _
       additionalSnapshotCellWork > ANALYSIS_CAPACITY_LONG_MAX * _
                                            CDbl(ANALYSIS_CAPACITY_BASE_COLUMNS) Then _
        Err.Raise vbObjectError + 4867, "ConfirmAnalysisReviewOperationCapacity", _
                  "���͍X�V���[���o�b�N�p�̑ޔ�e�ʂ��s���ł��B"

    reviewRows = AnalysisCapacitySheetRows( _
                     SH_WORK_ANALYSIS_REVIEW, ANALYSIS_REVIEW_STORE_LAST_COL)
    historyRows = AnalysisCapacitySheetRows( _
                      SH_WORK_ANALYSIS_HISTORY, ANALYSIS_HISTORY_STORE_LAST_COL)
    shiftRows = AnalysisCapacitySheetRows(SH_ANALYSIS_SHIFT, SHIFT_ANALYSIS_LAST_COL)
    flowRows = AnalysisCapacitySheetRows(SH_ANALYSIS_FLOW, FLOW_ANALYSIS_LAST_COL)
    unknownRows = AnalysisCapacitySheetRows(SH_ANALYSIS_UNKNOWN, UNKNOWN_ANALYSIS_LAST_COL)
    resultRows = AnalysisCapacitySheetRows(SH_ANALYSIS_RESULT, ANALYSIS_RESULT_LAST_COL)
    groupRows = AnalysisCapacitySheetRows(SH_WORK_ANALYSIS_GROUP, ANALYSIS_GROUP_LAST_COL)
    detailRows = AnalysisCapacitySheetRows(SH_ANALYSIS_DETAIL, DETAIL_COL_SELECTED)
    manualRows = AnalysisCapacitySheetRows(SH_WORK_MANUAL_FLOW, MANUAL_FLOW_STORE_LAST_COL)
    transactionRows = AnalysisCapacitySheetRows(SH_WORK_TX, WORK_TX_COL_PERSON_ID)
    plannedManualRows = CDbl(manualRows) + CDbl(additionalManualRows)
    If plannedManualRows > ANALYSIS_CAPACITY_LONG_MAX Then _
        Err.Raise vbObjectError + 4873, "ConfirmAnalysisReviewOperationCapacity", _
                  "�蓮���̗\�茏����Long�͈͂ŕ\���ł��܂���B"
    manualRows = CLng(plannedManualRows)

    '�\�茏���͋��\�Ɠ����ێ�����ǉ��ʂł͂Ȃ��A���ꂩ��\�z����z�񐡖@�֒u��������B
    '���\�S�͔̂z�񉻂����A�m�F�����̕K�v������������̑䒠�����ŕʓr�ێ�I�Ɍ��ς���B
    If plannedShiftRows >= 0 Then shiftRows = plannedShiftRows
    If plannedFlowRows >= 0 Then flowRows = plannedFlowRows
    If plannedUnknownRows >= 0 Then unknownRows = plannedUnknownRows
    If plannedResultRows >= 0 Then resultRows = plannedResultRows
    If plannedGroupRows >= 0 Then groupRows = plannedGroupRows

    cellWork = AnalysisReviewCellWork( _
                   reviewRows, historyRows, shiftRows, flowRows, unknownRows, _
                   resultRows, groupRows, detailRows, manualRows, transactionRows)
    cellWork = cellWork + additionalSnapshotCellWork
    '�䒠�ɂ͊e���\�̑S���A�����ɂ͑S���Ɗ����䒠�̖��f�ڕ����������E��������B
    'Persist�����Ōv�挏��������������ɏ��߂ėe�ʒ��߂��Ȃ��悤�A�����Ő��肷��B
    sourceRows = CDbl(shiftRows) + CDbl(flowRows) + CDbl(unknownRows)
    cellWork = cellWork + _
               (2# * sourceRows + CDbl(reviewRows)) * _
               CDbl(ANALYSIS_HISTORY_STORE_LAST_COL)

    requiredWorkloadRows = AnalysisCapacityEquivalentRows(cellWork)
    If requiredWorkloadRows > ANALYSIS_CAPACITY_LONG_MAX Then _
        Err.Raise vbObjectError + 4868, "ConfirmAnalysisReviewOperationCapacity", _
                  "���͏����̈��S�e�ʂ�Long�͈͂ŕ\���ł��܂���B"
    If Len(Trim$(operationName)) = 0 Then operationName = "���͏���"
    If requiredWorkloadRows <= confirmedWorkloadRows Then
        ConfirmAnalysisReviewOperationCapacity = True
        Exit Function
    End If
    If AnalysisCapacityNeedsConfirmation(requiredWorkloadRows, confirmedWorkloadRows) Then
        If Not allowUserConfirmation Then _
            Err.Raise vbObjectError + 4872, "ConfirmAnalysisReviewOperationCapacity", _
                      operationName & _
                      "�͓����Ŋm�F�ς݂̈��S�e�ʂ𒴂��܂����B�r���m�F�͍s�킸�������~���܂��B"
        If Not ConfirmLargeArrayOperation( _
                   CLng(requiredWorkloadRows), _
                   operationName & "�i���f�䒠�E�����E�֘A�z��̎��O���S�����j") Then _
            Exit Function
    End If
    confirmedWorkloadRows = requiredWorkloadRows
    ConfirmAnalysisReviewOperationCapacity = True
End Function

Private Function ConfirmCurrentAnalysisWorkspaceCapacity( _
        ByVal operationName As String, ByRef confirmedWorkloadRows As Double, _
        ByRef shiftCount As Long, ByRef flowCount As Long, ByRef unknownCount As Long, _
        ByRef candidateCount As Long, ByRef prospectiveResultCount As Long, _
        Optional ByVal allowUserConfirmation As Boolean = True, _
        Optional ByVal additionalSnapshotCellWork As Double = 0#) As Boolean
    Dim candidateWorkloadRows As Double, prospectiveResultRows As Double
    shiftCount = AnalysisCapacitySheetRows(SH_ANALYSIS_SHIFT, SHIFT_ANALYSIS_LAST_COL)
    flowCount = AnalysisCapacitySheetRows(SH_ANALYSIS_FLOW, FLOW_ANALYSIS_LAST_COL)
    unknownCount = AnalysisCapacitySheetRows(SH_ANALYSIS_UNKNOWN, UNKNOWN_ANALYSIS_LAST_COL)
    candidateWorkloadRows = AnalysisWorkspaceCandidateWorkloadRows(shiftCount, flowCount)
    If candidateWorkloadRows > 2# * CDbl(MAX_ANALYSIS_OUTPUT_ROWS) Then _
        Err.Raise vbObjectError + 4800, "ConfirmCurrentAnalysisWorkspaceCapacity", _
                  "���͌��̓����������������p����𒴂��Ă��܂��B"
    If candidateWorkloadRows > ANALYSIS_CAPACITY_LONG_MAX Then _
        Err.Raise vbObjectError + 4870, "ConfirmCurrentAnalysisWorkspaceCapacity", _
                  "���͌��̓�������������Long�͈͂ŕ\���ł��܂���B"
    candidateCount = CLng(candidateWorkloadRows)
    prospectiveResultRows = candidateWorkloadRows + CDbl(unknownCount)
    If prospectiveResultRows > ANALYSIS_CAPACITY_LONG_MAX Then _
        Err.Raise vbObjectError + 4871, "ConfirmCurrentAnalysisWorkspaceCapacity", _
                  "���͌��ʂ̗\�茏����Long�͈͂ŕ\���ł��܂���B"
    prospectiveResultCount = CLng(prospectiveResultRows)
    ConfirmCurrentAnalysisWorkspaceCapacity = _
        ConfirmAnalysisReviewOperationCapacity( _
            operationName, confirmedWorkloadRows, shiftCount, flowCount, unknownCount, _
            prospectiveResultCount, candidateCount, allowUserConfirmation, _
            additionalSnapshotCellWork:=additionalSnapshotCellWork)
End Function

Public Function AnalysisResultHeaders() As Variant
    AnalysisResultHeaders = Array( _
        "�D��x", _
        "�敪", "���t�E����", "���z", "�l���E�����o�H", "�v�_", "���؁E����", _
        "�m�F��", "�m�F����", "�������\", "�����m�F�L�[", "�����O���[�vID", _
        "�������s", "�\�����ID", "��֌�␔")
End Function

Public Function AnalysisGroupHeaders() As Variant
    AnalysisGroupHeaders = Array( _
        "�O���[�vID", "���\", "���s", "�m�F�L�[", "�\�����ID", "�X�R�A", _
        "��\", "�敪", "�m�F��", "�m�F����")
End Function

Public Sub SetupAnalysisWorkspaceSheets(Optional ByVal preserveVisibility As Boolean = False)
    Dim resultVisibility As XlSheetVisibility, detailVisibility As XlSheetVisibility
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim cleanupErrorNumber As Long, cleanupErrorDescription As String
    Dim cleanupErrorSource As String
    On Error GoTo EH
    If preserveVisibility Then
        resultVisibility = GetSheet(SH_ANALYSIS_RESULT).Visible
        detailVisibility = GetSheet(SH_ANALYSIS_DETAIL).Visible
    End If
    PrepareAnalysisResultSheet GetSheet(SH_ANALYSIS_RESULT)
    PrepareAnalysisDetailSheet GetSheet(SH_ANALYSIS_DETAIL)
    PrepareAnalysisGroupSheet GetSheet(SH_WORK_ANALYSIS_GROUP)
    If preserveVisibility Then
        GetSheet(SH_ANALYSIS_RESULT).Visible = resultVisibility
        GetSheet(SH_ANALYSIS_DETAIL).Visible = detailVisibility
    Else
        SetSheetVeryHiddenSafe GetSheet(SH_ANALYSIS_DETAIL)
    End If
    SetSheetVeryHiddenSafe GetSheet(SH_WORK_ANALYSIS_GROUP)
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    If IsAnalysisWorkspaceRecoveryFatalError(errorNumber, errorSource) Then _
        RethrowAnalysisWorkspaceUpstreamRecoveryFatal _
            errorNumber, errorSource, errorDescription, _
            "SetupAnalysisWorkspaceSheets"
    On Error Resume Next
    Err.Clear
    ProtectTransactionAnalysisSheets False
    cleanupErrorNumber = Err.Number
    cleanupErrorDescription = Err.Description
    cleanupErrorSource = Err.Source
    Err.Clear
    On Error GoTo 0
    If IsAnalysisWorkspaceRecoveryFatalError( _
           cleanupErrorNumber, cleanupErrorSource) Then _
        RethrowAnalysisWorkspaceUpstreamRecoveryFatal _
            cleanupErrorNumber, cleanupErrorSource, _
            cleanupErrorDescription, "SetupAnalysisWorkspaceSheets/�ُ�I���ĕی�"
    On Error Resume Next
    If SheetExists(SH_WORK_ANALYSIS_GROUP) Then _
        SetSheetVeryHiddenSafe GetSheet(SH_WORK_ANALYSIS_GROUP)
    On Error GoTo 0
    Err.Raise errorNumber, "SetupAnalysisWorkspaceSheets", errorSource & " / " & errorDescription
End Sub

Private Sub PrepareAnalysisResultSheet(ByVal ws As Worksheet)
    If ws Is Nothing Then Exit Sub
    ws.Unprotect Password:=TOOL_PASSWORD
    If ws.AutoFilterMode Then ws.AutoFilterMode = False
    ResetWorksheet ws
    SetRowValues ws.Range("A1"), AnalysisResultHeaders()
    FormatOutputHeader ws.Range(ws.Cells(1, 1), ws.Cells(1, ANALYSIS_RESULT_LAST_COL))
    ws.Columns("A:O").NumberFormatLocal = "@"
    ws.Columns("A:A").NumberFormatLocal = "0"
    ws.Columns("D:D").NumberFormatLocal = "#,##0.########"
    ApplyAnalysisResultColumnWidths ws
    ws.Rows(1).RowHeight = 52
    ws.Columns("J:O").Hidden = True
    AddManualBuilderHint ws
    ProtectSingleAnalysisSheet ws
End Sub

Private Sub PrepareAnalysisDetailSheet(ByVal ws As Worksheet)
    If ws Is Nothing Then Exit Sub
    ws.Unprotect Password:=TOOL_PASSWORD
    If ws.AutoFilterMode Then ws.AutoFilterMode = False
    ResetWorksheet ws
    With ws.Range("A1:L" & CStr(MANUAL_BUILDER_MAX_ROWS + MANUAL_BUILDER_HEADER_ROW + 5))
        .Font.Name = "Yu Gothic UI"
        .Font.Size = 10
    End With
    ws.Columns("A:A").ColumnWidth = 13
    ws.Columns("B:B").ColumnWidth = 14
    ws.Columns("C:C").ColumnWidth = 18
    ws.Columns("D:D").ColumnWidth = 28
    ws.Columns("E:E").ColumnWidth = 36
    ws.Columns("F:F").ColumnWidth = 18
    ws.Columns("G:G").ColumnWidth = 30
    ws.Columns("H:L").Hidden = True
    ws.Cells.Locked = True
    ProtectSingleAnalysisSheet ws
    mAnalysisDetailReviewsDirty = False
End Sub

Private Sub PrepareAnalysisGroupSheet(ByVal ws As Worksheet)
    If ws Is Nothing Then Exit Sub
    ws.Unprotect Password:=TOOL_PASSWORD
    ResetWorksheet ws
    SetRowValues ws.Range("A1"), AnalysisGroupHeaders()
    FormatOutputHeader ws.Range(ws.Cells(1, 1), ws.Cells(1, ANALYSIS_GROUP_LAST_COL))
    ws.Columns("A:J").NumberFormatLocal = "@"
    SetSheetVeryHiddenSafe ws
End Sub

Public Function AnalysisDetailReviewDirtySnapshot() As Boolean
    AnalysisDetailReviewDirtySnapshot = mAnalysisDetailReviewsDirty
End Function

Public Sub RestoreAnalysisWorkspaceTransactionSnapshot( _
        ByRef resultSnapshot As Variant, ByVal resultLastRow As Long, _
        ByVal resultVisibility As Long, ByVal resultProtected As Boolean, _
        ByRef groupSnapshot As Variant, ByVal groupLastRow As Long, _
        ByVal groupVisibility As Long, ByVal groupProtected As Boolean, _
        ByRef detailHeaderSnapshot As Variant, ByRef detailSnapshot As Variant, _
        ByVal detailLastRow As Long, ByVal detailVisibility As Long, _
        ByVal detailProtected As Boolean, ByVal detailReviewsDirty As Boolean)
    Dim wsResult As Worksheet, wsGroup As Worksheet, wsDetail As Worksheet
    Dim detailHeader As Range, resultRange As Range
    Dim resultCount As Long
    Set wsResult = GetSheet(SH_ANALYSIS_RESULT)
    Set wsGroup = GetSheet(SH_WORK_ANALYSIS_GROUP)
    Set wsDetail = GetSheet(SH_ANALYSIS_DETAIL)

    PrepareAnalysisResultSheet wsResult
    PrepareAnalysisGroupSheet wsGroup
    PrepareAnalysisDetailSheet wsDetail
    wsResult.Unprotect Password:=TOOL_PASSWORD
    wsDetail.Unprotect Password:=TOOL_PASSWORD
    RestoreAtomicConstantWorksheetData wsResult, ANALYSIS_RESULT_LAST_COL, _
        MAX_ANALYSIS_OUTPUT_ROWS, resultSnapshot, resultLastRow, "���͌���"
    RestoreAtomicConstantWorksheetData wsGroup, ANALYSIS_GROUP_LAST_COL, _
        MAX_ANALYSIS_OUTPUT_ROWS * 2, groupSnapshot, groupLastRow, "���̓O���[�v"
    Set detailHeader = wsDetail.Range(wsDetail.Cells(1, 1), _
                                      wsDetail.Cells(1, DETAIL_COL_SELECTED))
    detailHeader.Value2 = detailHeaderSnapshot
    If Not RangeValue2MatchesMatrixStrict( _
               detailHeader, detailHeaderSnapshot, 1, DETAIL_COL_SELECTED) Then _
        Err.Raise vbObjectError + 4874, "RestoreAnalysisWorkspaceTransactionSnapshot", _
                  "���ڍׂ̌��o���������ɕ����ł��܂���B"
    RestoreAtomicConstantWorksheetData wsDetail, DETAIL_COL_SELECTED, _
        MAX_ANALYSIS_OUTPUT_ROWS, detailSnapshot, detailLastRow, "���ڍ�"
    RebuildAnalysisDetailSnapshotLayout wsDetail, detailLastRow
    If detailLastRow >= 2 Then
        If Not RangeValue2MatchesMatrixStrict( _
                   wsDetail.Range(wsDetail.Cells(2, 1), _
                                  wsDetail.Cells(detailLastRow, DETAIL_COL_SELECTED)), _
                   detailSnapshot, detailLastRow - 1, DETAIL_COL_SELECTED) Then _
            Err.Raise vbObjectError + 4877, _
                      "RestoreAnalysisWorkspaceTransactionSnapshot", _
                      "���ڍׂ̍č\�z��f�[�^���J�n���ƈ�v���܂���B"
    End If
    If Not RangeValue2MatchesMatrixStrict( _
               detailHeader, detailHeaderSnapshot, 1, DETAIL_COL_SELECTED) Then _
        Err.Raise vbObjectError + 4878, _
                  "RestoreAnalysisWorkspaceTransactionSnapshot", _
                  "���ڍׂ̍č\�z�㌩�o�����J�n���ƈ�v���܂���B"

    resultCount = resultLastRow - 1
    If resultCount < 0 Then resultCount = 0
    FinalizeAnalysisResultSheet wsResult, resultCount
    If resultLastRow >= 2 Then
        Set resultRange = wsResult.Range(wsResult.Cells(2, 1), _
                                         wsResult.Cells(resultLastRow, _
                                                        ANALYSIS_RESULT_LAST_COL))
        If Not RangeValue2MatchesMatrixStrict( _
                   resultRange, resultSnapshot, resultCount, _
                   ANALYSIS_RESULT_LAST_COL) Then
            '�����ʍs�̍�Sort�����ς���Ă��A����J�n���̍s�����Ō�ɖ߂��B
            wsResult.Unprotect Password:=TOOL_PASSWORD
            RestoreAtomicConstantWorksheetData wsResult, ANALYSIS_RESULT_LAST_COL, _
                MAX_ANALYSIS_OUTPUT_ROWS, resultSnapshot, resultLastRow, "���͌���"
            ProtectSingleAnalysisSheet wsResult
        End If
    End If
    ProtectSingleAnalysisSheet wsDetail
    If groupProtected Then
        EmergencyProtectToolSheet wsGroup
    Else
        wsGroup.Unprotect Password:=TOOL_PASSWORD
    End If
    If Not resultProtected Then wsResult.Unprotect Password:=TOOL_PASSWORD
    If Not detailProtected Then wsDetail.Unprotect Password:=TOOL_PASSWORD
    wsResult.Visible = resultVisibility
    wsGroup.Visible = groupVisibility
    wsDetail.Visible = detailVisibility
    If CLng(wsResult.Visible) <> resultVisibility Or _
       CLng(wsGroup.Visible) <> groupVisibility Or _
       CLng(wsDetail.Visible) <> detailVisibility Then _
        Err.Raise vbObjectError + 4875, "RestoreAnalysisWorkspaceTransactionSnapshot", _
                  "����workspace�̕\����Ԃ𕜌��ł��܂���B"
    If wsResult.ProtectContents <> resultProtected Or _
       wsGroup.ProtectContents <> groupProtected Or _
       wsDetail.ProtectContents <> detailProtected Then _
        Err.Raise vbObjectError + 4876, "RestoreAnalysisWorkspaceTransactionSnapshot", _
                  "����workspace�̕ی��Ԃ𕜌��ł��܂���B"
    mAnalysisDetailReviewsDirty = detailReviewsDirty
End Sub

Private Sub RebuildAnalysisDetailSnapshotLayout( _
        ByVal ws As Worksheet, ByVal snapshotLastRow As Long)
    Dim r As Long, firstDataRow As Long
    Dim manualBuilder As Boolean, legacyDetail As Boolean
    Dim sourceSheet As String, categoryText As String
    If ws Is Nothing Then Exit Sub
    ws.Unprotect Password:=TOOL_PASSWORD
    ws.Columns("H:L").Hidden = True
    ws.Cells.Locked = True
    If snapshotLastRow < 2 Then
        ws.ScrollArea = "A1:G50"
        Exit Sub
    End If

    legacyDetail = (CellText(ws.Cells(2, DETAIL_COL_KIND).Value) = "�蓮�o�^")
    manualBuilder = legacyDetail And snapshotLastRow >= MANUAL_BUILDER_HEADER_ROW And _
                    CellText(ws.Cells(MANUAL_BUILDER_HEADER_ROW, 1).Value) = "�I��" And _
                    CellText(ws.Cells(MANUAL_BUILDER_HEADER_ROW, 2).Value) = "���t"
    If manualBuilder Then
        ws.Range("A1:G1").Merge
        ws.Range("A2:G2").Merge
        ws.Range("A3:G3").Merge
        With ws.Range("A1:G1")
            .Interior.Color = RGB(239, 246, 255)
            .Font.Color = RGB(30, 64, 175)
            .Font.Bold = True
            .Font.Size = 15
            .HorizontalAlignment = xlCenter
        End With
        With ws.Range("A2:G2")
            .Interior.Color = RGB(254, 249, 195)
            .Font.Color = RGB(133, 77, 14)
            .Font.Bold = True
            .HorizontalAlignment = xlCenter
        End With
        FormatOutputHeader ws.Range(ws.Cells(MANUAL_BUILDER_HEADER_ROW, 1), _
                                     ws.Cells(MANUAL_BUILDER_HEADER_ROW, 7))
        ws.Columns("A:A").ColumnWidth = 10
        ws.Columns("B:B").ColumnWidth = 13
        ws.Columns("C:C").ColumnWidth = 9
        ws.Columns("D:E").ColumnWidth = 15.5
        ws.Columns("F:F").ColumnWidth = 38
        ws.Columns("G:G").ColumnWidth = 42
        ws.Columns("D:E").NumberFormatLocal = "#,##0.########"
        firstDataRow = MANUAL_BUILDER_HEADER_ROW + 1
        If snapshotLastRow >= firstDataRow Then
            With ws.Range(ws.Cells(firstDataRow, 1), ws.Cells(snapshotLastRow, 7))
                .Borders.LineStyle = xlContinuous
                .Borders.Color = RGB(226, 232, 240)
                .VerticalAlignment = xlTop
                .WrapText = True
            End With
            ws.Rows(CStr(firstDataRow) & ":" & CStr(snapshotLastRow)).RowHeight = 32
            For r = firstDataRow To snapshotLastRow
                If CellText(ws.Cells(r, DETAIL_COL_SELECTED).Value) = "1" Then
                    ws.Range(ws.Cells(r, 1), ws.Cells(r, 7)).Interior.Color = RGB(219, 234, 254)
                    ws.Range(ws.Cells(r, 1), ws.Cells(r, 7)).Font.Bold = True
                End If
            Next r
        End If
        ws.Rows(1).RowHeight = 30
        ws.Rows(2).RowHeight = 32
        ws.Rows(3).RowHeight = 30
        ws.Rows(MANUAL_BUILDER_HEADER_ROW).RowHeight = 30
        If ws.AutoFilterMode Then ws.AutoFilterMode = False
        ws.Range(ws.Cells(MANUAL_BUILDER_HEADER_ROW, 1), _
                 ws.Cells(Application.Max(MANUAL_BUILDER_HEADER_ROW, snapshotLastRow), 7)).AutoFilter
        ws.ScrollArea = "A1:G" & CStr(snapshotLastRow + 20)
        Exit Sub
    End If

    If legacyDetail Then
        ws.Range("A1:G1").Merge
        ws.Range("A2:G2").Merge
        ws.Range("F3:G3").Merge
        ws.Range("B4:D4").Merge
        ws.Range("F4:G4").Merge
        ws.Range("B5:G5").Merge
        ws.Range("B7:G8").Merge
        ws.Range("B10:G11").Merge
        ws.Range("B13:G13").Merge
        ws.Range("B14:G14").Merge
        ws.Range("B15:G15").Merge
        With ws.Range("A1:G1")
            .Interior.Color = RGB(239, 246, 255)
            .Font.Color = RGB(30, 64, 175)
            .Font.Bold = True
            .Font.Size = 15
            .HorizontalAlignment = xlCenter
        End With
        With ws.Range("A2:G2")
            .Interior.Color = RGB(254, 249, 195)
            .Font.Color = RGB(133, 77, 14)
            .Font.Bold = True
            .HorizontalAlignment = xlCenter
            .WrapText = True
        End With
        With ws.Range("A3:G15")
            .Borders.LineStyle = xlContinuous
            .Borders.Color = RGB(203, 213, 225)
            .WrapText = True
        End With
        ws.Rows(1).RowHeight = 30
        ws.Rows(2).RowHeight = 36
        ws.Rows("3:4").RowHeight = 24
        ws.Rows(5).RowHeight = 30
        ws.Rows(6).RowHeight = 8
        ws.Rows("7:8").RowHeight = 30
        ws.Rows(9).RowHeight = 8
        ws.Rows("10:11").RowHeight = 30
        ws.Rows(12).RowHeight = 8
        ws.Rows(13).RowHeight = 32
        ws.Rows("14:15").RowHeight = 30
        ws.Range("A6:G6,A9:G9,A12:G12").Borders.LineStyle = xlNone
        For r = 2 To snapshotLastRow
            Select Case CellText(ws.Cells(r, DETAIL_COL_KIND).Value)
                Case "���"
                    sourceSheet = CellText(ws.Cells(r, DETAIL_COL_REFERENCE).Value)
                    categoryText = CellText(ws.Cells(r, 1).Value)
                    ws.Cells(r, 6).Locked = False
                    ApplyAnalysisDetailStatusValidation ws.Cells(r, 6), _
                                                        sourceSheet, categoryText
                    With ws.Range(ws.Cells(r, 1), ws.Cells(r, 7))
                        .Borders.LineStyle = xlContinuous
                        .Borders.Color = RGB(226, 232, 240)
                        .WrapText = True
                        .VerticalAlignment = xlTop
                    End With
                    ws.Rows(r).RowHeight = 48
                Case "��⃁��"
                    ws.Range(ws.Cells(r, 2), ws.Cells(r, 7)).Merge
                    ws.Range(ws.Cells(r, 2), ws.Cells(r, 7)).Locked = False
                    ApplyAnalysisDetailMemoValidation ws.Cells(r, 2)
                    With ws.Range(ws.Cells(r, 1), ws.Cells(r, 7))
                        .Borders.LineStyle = xlContinuous
                        .Borders.Color = RGB(226, 232, 240)
                        .Interior.Color = RGB(255, 251, 235)
                        .WrapText = True
                    End With
                    ws.Rows(r).RowHeight = 38
                Case "���"
                    With ws.Range(ws.Cells(r, 1), ws.Cells(r, 7))
                        .Borders.LineStyle = xlContinuous
                        .Borders.Color = RGB(226, 232, 240)
                        .WrapText = True
                        .VerticalAlignment = xlTop
                    End With
                    If CellText(ws.Cells(r, DETAIL_COL_SELECTED).Value) = "1" Then
                        ws.Range(ws.Cells(r, 1), ws.Cells(r, 7)).Interior.Color = RGB(219, 234, 254)
                        ws.Range(ws.Cells(r, 1), ws.Cells(r, 7)).Font.Bold = True
                    End If
            End Select
        Next r
        ws.ScrollArea = "A1:G" & CStr(Application.Max(50, snapshotLastRow + 20))
    Else
        ws.ScrollArea = "A1:G" & CStr(Application.Max(50, snapshotLastRow + 20))
    End If
End Sub

Public Sub BuildAnalysisWorkspaceCore( _
        ByVal callerContext As String, _
        Optional ByRef confirmedWorkloadRows As Double = 0#, _
        Optional ByVal allowCapacityPrompt As Boolean = True, _
        Optional ByVal additionalSnapshotCellWork As Double = 0#)
    Dim wsShift As Worksheet, wsFlow As Worksheet, wsUnknown As Worksheet
    Dim wsResult As Worksheet, wsGroup As Worksheet
    Dim shiftCount As Long, flowCount As Long, unknownCount As Long
    Dim candidateCount As Long, resultCount As Long
    Dim parent() As Long, sourceRows() As Long, scores() As Long
    Dim sourceSheets() As String, sourceKeys() As String, txIDs() As String
    Dim categories() As String, datesText() As String, routes() As String
    Dim points() As String, constraints() As String, statuses() As String, memos() As String
    Dim amounts() As Double
    Dim personClasses() As String, oneToOneFlags() As Boolean
    Dim owners As Object, txPersonByID As Object, txDirectionByID As Object
    Dim groupCounts() As Long, representatives() As Long
    Dim groupHasDifferent() As Boolean, groupHasSame() As Boolean
    Dim groupSeedParts() As Collection, groupIDs() As String
    Dim i As Long, rootIndex As Long, groupTotal As Long, outputTotal As Long
    Dim resultBuffer() As Variant, resultBufferCount As Long, nextResultRow As Long
    Dim prospectiveResultCount As Long
    Dim errorNumber As Long, errorDescription As String, errorSource As String

    If Len(Trim$(callerContext)) = 0 Then _
        Err.Raise vbObjectError + 4799, "BuildAnalysisWorkspaceCore", _
                  "�ďo���R���e�L�X�g������܂���B�O���̕��͍X�V����������s���Ă��������B"
    Set wsShift = GetSheet(SH_ANALYSIS_SHIFT)
    Set wsFlow = GetSheet(SH_ANALYSIS_FLOW)
    Set wsUnknown = GetSheet(SH_ANALYSIS_UNKNOWN)
    Set wsResult = GetSheet(SH_ANALYSIS_RESULT)
    Set wsGroup = GetSheet(SH_WORK_ANALYSIS_GROUP)
    '���\�̓Ǎ��ݔz��ƌ��ʁE�O���[�v�̍ő�\�萡�@���A��workspace�̏������O�Ɋm�F����B
    If Not ConfirmCurrentAnalysisWorkspaceCapacity( _
               callerContext, confirmedWorkloadRows, shiftCount, flowCount, unknownCount, _
               candidateCount, prospectiveResultCount, allowCapacityPrompt, _
               additionalSnapshotCellWork) Then _
        Err.Raise 18, "BuildAnalysisWorkspaceCore", _
                  "����workspace�̗e�ʊm�F����������܂����B"

    On Error GoTo EH
    '�l���������G���[�ŋ����͌��ʂ������Ȃ��悤�A�V�[�g����������ɓǎ挟������B
    If candidateCount > 0 Then _
        LoadWorkspaceTransactionIdentity txPersonByID, txDirectionByID

    If candidateCount > 0 Then
        ReDim parent(1 To candidateCount)
        ReDim sourceRows(1 To candidateCount)
        ReDim scores(1 To candidateCount)
        ReDim sourceSheets(1 To candidateCount)
        ReDim sourceKeys(1 To candidateCount)
        ReDim txIDs(1 To candidateCount)
        ReDim categories(1 To candidateCount)
        ReDim datesText(1 To candidateCount)
        ReDim routes(1 To candidateCount)
        ReDim points(1 To candidateCount)
        ReDim constraints(1 To candidateCount)
        ReDim statuses(1 To candidateCount)
        ReDim memos(1 To candidateCount)
        ReDim amounts(1 To candidateCount)
        ReDim personClasses(1 To candidateCount)
        ReDim oneToOneFlags(1 To candidateCount)
        Set owners = CreateObject("Scripting.Dictionary")
        owners.CompareMode = vbTextCompare
        i = 0
        LoadWorkspaceShiftCandidates wsShift, shiftCount, i, parent, sourceRows, scores, _
                                     sourceSheets, sourceKeys, txIDs, categories, datesText, _
                                     routes, points, constraints, statuses, memos, amounts, _
                                     personClasses, oneToOneFlags, txPersonByID, txDirectionByID, owners
        LoadWorkspaceFlowCandidates wsFlow, flowCount, i, parent, sourceRows, scores, _
                                    sourceSheets, sourceKeys, txIDs, categories, datesText, _
                                    routes, points, constraints, statuses, memos, amounts, _
                                    personClasses, oneToOneFlags, txPersonByID, txDirectionByID, owners

        ReDim groupCounts(1 To candidateCount)
        ReDim representatives(1 To candidateCount)
        ReDim groupSeedParts(1 To candidateCount)
        ReDim groupIDs(1 To candidateCount)
        ReDim groupHasDifferent(1 To candidateCount)
        ReDim groupHasSame(1 To candidateCount)
        For i = 1 To candidateCount
            rootIndex = WorkspaceFindRoot(parent, i)
            groupCounts(rootIndex) = groupCounts(rootIndex) + 1
            If personClasses(i) = WORKSPACE_PERSON_DIFFERENT Then
                groupHasDifferent(rootIndex) = True
            ElseIf personClasses(i) = WORKSPACE_PERSON_SAME Then
                groupHasSame(rootIndex) = True
            Else
                Err.Raise vbObjectError + 4850, "BuildAnalysisWorkspaceCore", _
                          "���̐l���敪���s���ł��B"
            End If
            If groupSeedParts(rootIndex) Is Nothing Then _
                Set groupSeedParts(rootIndex) = New Collection
            groupSeedParts(rootIndex).Add sourceSheets(i) & ":" & sourceKeys(i) & "|"
            If representatives(rootIndex) = 0 Then
                representatives(rootIndex) = i
            ElseIf WorkspaceCandidateIsBetterRepresentative( _
                       i, representatives(rootIndex), statuses, oneToOneFlags, _
                       personClasses, scores) Then
                representatives(rootIndex) = i
            End If
        Next i
        For i = 1 To candidateCount
            If groupCounts(i) > 0 Then
                groupTotal = groupTotal + 1
                groupIDs(i) = "G-" & WorkspaceDigest( _
                    JoinWorkspaceGroupSeedParts(groupSeedParts(i)))
            End If
        Next i
    End If

    resultCount = groupTotal + unknownCount
    If resultCount > MAX_ANALYSIS_OUTPUT_ROWS Then _
        Err.Raise vbObjectError + 4801, "BuildAnalysisWorkspaceCore", _
                  "������̕��͌��ʂ����p����i" & Format$(MAX_ANALYSIS_OUTPUT_ROWS, "#,##0") & _
                  "���j�𒴂��Ă��܂��B���͏������i���Ă��������B"

    '�ǎ挟���E��␮���E�ŏI�����������S�Đ������Ă��狌workspace��u��������B
    PrepareAnalysisResultSheet wsResult
    PrepareAnalysisGroupSheet wsGroup
    PrepareAnalysisDetailSheet GetSheet(SH_ANALYSIS_DETAIL)
    SetSheetVeryHiddenSafe GetSheet(SH_ANALYSIS_DETAIL)

    If candidateCount > 0 Then
        WriteWorkspaceGroupTable wsGroup, candidateCount, parent, sourceRows, scores, _
                                 sourceSheets, sourceKeys, txIDs, categories, statuses, memos, _
                                 personClasses, groupCounts, representatives, groupIDs
        ReDim resultBuffer(1 To WORKSPACE_BUFFER_ROWS, 1 To ANALYSIS_RESULT_LAST_COL)
        nextResultRow = 2
        For i = 1 To candidateCount
            If representatives(i) > 0 Then
                outputTotal = outputTotal + 1
                resultBufferCount = resultBufferCount + 1
                FillWorkspaceCandidateResult resultBuffer, resultBufferCount, representatives(i), _
                                              groupCounts(i), groupIDs(i), sourceRows, scores, _
                                              sourceSheets, sourceKeys, txIDs, categories, datesText, _
                                              routes, points, constraints, statuses, memos, amounts
                If groupHasDifferent(i) And personClasses(representatives(i)) <> _
                   WORKSPACE_PERSON_DIFFERENT Then
                    resultBuffer(resultBufferCount, 7) = WorkspaceTrimText( _
                        WorkspaceAppend(CellText(resultBuffer(resultBufferCount, 7)), _
                        "�ʐl���Ԃ̑�֌�₠��B���؁E���񗓂��_�u���N���b�N���Ċm�F�ł��܂��B", " / "), _
                        WORKSPACE_TEXT_LIMIT)
                ElseIf groupHasSame(i) And personClasses(representatives(i)) <> _
                       WORKSPACE_PERSON_SAME Then
                    resultBuffer(resultBufferCount, 7) = WorkspaceTrimText( _
                        WorkspaceAppend(CellText(resultBuffer(resultBufferCount, 7)), _
                        "����l���Ԃ̑�֌�₠��B", " / "), _
                        WORKSPACE_TEXT_LIMIT)
                End If
                If resultBufferCount = WORKSPACE_BUFFER_ROWS Then
                    FlushWorkspaceBuffer wsResult, resultBuffer, resultBufferCount, nextResultRow, _
                                         ANALYSIS_RESULT_LAST_COL
                    ReDim resultBuffer(1 To WORKSPACE_BUFFER_ROWS, 1 To ANALYSIS_RESULT_LAST_COL)
                    resultBufferCount = 0
                End If
            End If
        Next i
        If resultBufferCount > 0 Then _
            FlushWorkspaceBuffer wsResult, resultBuffer, resultBufferCount, nextResultRow, _
                                 ANALYSIS_RESULT_LAST_COL
    End If
    If unknownCount > 0 Then _
        WriteWorkspaceUnknownResults wsUnknown, wsResult, outputTotal, unknownCount, wsGroup
    If outputTotal <> resultCount Then _
        Err.Raise vbObjectError + 4802, "BuildAnalysisWorkspaceCore", _
                  "���͌��ʂ̎��O�����Əo�͌�������v���܂���B"

    FinalizeAnalysisResultSheet wsResult, resultCount
    SetSheetVeryHiddenSafe wsResult
    SetSheetVeryHiddenSafe wsGroup
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    If IsAnalysisWorkspaceRecoveryFatalError(errorNumber, errorSource) Then _
        RethrowAnalysisWorkspaceUpstreamRecoveryFatal _
            errorNumber, errorSource, errorDescription, _
            "BuildAnalysisWorkspaceCore"
    On Error Resume Next
    If Not wsResult Is Nothing Then EmergencyProtectToolSheet wsResult
    If SheetExists(SH_ANALYSIS_DETAIL) Then _
        EmergencyProtectToolSheet GetSheet(SH_ANALYSIS_DETAIL)
    If SheetExists(SH_WORK_ANALYSIS_GROUP) Then _
        SetSheetVeryHiddenSafe GetSheet(SH_WORK_ANALYSIS_GROUP)
    On Error GoTo 0
    Err.Raise errorNumber, "BuildAnalysisWorkspaceCore", errorDescription
End Sub

Private Function JoinWorkspaceGroupSeedParts(ByVal seedParts As Collection) As String
    Dim values() As String, i As Long
    If seedParts Is Nothing Then Exit Function
    If seedParts.Count < 1 Then Exit Function
    ReDim values(0 To seedParts.Count - 1)
    For i = 1 To seedParts.Count
        values(i - 1) = CStr(seedParts(i))
    Next i
    JoinWorkspaceGroupSeedParts = Join(values, vbNullString)
End Function

Private Sub LoadWorkspaceShiftCandidates( _
        ByVal ws As Worksheet, ByVal itemCount As Long, ByRef outputIndex As Long, _
        ByRef parent() As Long, ByRef sourceRows() As Long, ByRef scores() As Long, _
        ByRef sourceSheets() As String, ByRef sourceKeys() As String, ByRef txIDs() As String, _
        ByRef categories() As String, ByRef datesText() As String, ByRef routes() As String, _
        ByRef points() As String, ByRef constraints() As String, ByRef statuses() As String, _
        ByRef memos() As String, ByRef amounts() As Double, _
        ByRef personClasses() As String, ByRef oneToOneFlags() As Boolean, _
        ByVal txPersonByID As Object, ByVal txDirectionByID As Object, ByVal owners As Object)
    Dim data As Variant, r As Long, itemIndex As Long
    If itemCount <= 0 Then Exit Sub
    data = ws.Range(ws.Cells(2, 1), ws.Cells(itemCount + 1, SHIFT_ANALYSIS_LAST_COL)).Value2
    For r = 1 To itemCount
        If r Mod 2048 = 0 Then AppProgress "�����V�t�g���𒲍��P�ʂ֐������Ă��܂�...", r, itemCount
        outputIndex = outputIndex + 1: itemIndex = outputIndex
        parent(itemIndex) = itemIndex
        sourceRows(itemIndex) = r + 1
        sourceSheets(itemIndex) = SH_ANALYSIS_SHIFT
        sourceKeys(itemIndex) = CellText(data(r, SHIFT_ANALYSIS_KEY_COL))
        txIDs(itemIndex) = WorkspaceJoinIDs(CellText(data(r, 33)), CellText(data(r, 34)))
        scores(itemIndex) = WorkspaceLong(data(r, 2))
        categories(itemIndex) = "�����V�t�g"
        datesText(itemIndex) = WorkspacePeriodText(data(r, 9), data(r, 19))
        amounts(itemIndex) = WorkspaceDouble(data(r, 17))
        routes(itemIndex) = WorkspacePartyAccount(data(r, 11), data(r, 12), data(r, 13), _
                            data(r, 14), data(r, 15), data(r, 16)) & " �� " & _
                            WorkspacePartyAccount(data(r, 21), data(r, 22), data(r, 23), _
                            data(r, 24), data(r, 25), data(r, 26))
        points(itemIndex) = WorkspaceTrimText(CellText(data(r, 1)) & "�E" & _
                            CellText(data(r, 3)) & "�E" & CellText(data(r, 4)) & "�B" & _
                            CellText(data(r, 29)), WORKSPACE_TEXT_LIMIT)
        constraints(itemIndex) = WorkspaceTrimText("�������x: " & CellText(data(r, 5)) & _
                                 " / �o��: " & CellText(data(r, 6)) & _
                                 " / ���z��: " & WorkspaceAmountText(data(r, 8)), WORKSPACE_TEXT_LIMIT)
        statuses(itemIndex) = WorkspaceStatusOrDefault(data(r, SHIFT_ANALYSIS_STATUS_COL))
        memos(itemIndex) = CellText(data(r, SHIFT_ANALYSIS_MEMO_COL))
        personClasses(itemIndex) = WorkspaceCandidatePersonClass( _
            txIDs(itemIndex), txPersonByID, txDirectionByID, oneToOneFlags(itemIndex))
        routes(itemIndex) = personClasses(itemIndex) & "�b" & routes(itemIndex)
        RegisterWorkspaceOwners txIDs(itemIndex), itemIndex, parent, owners
    Next r
End Sub

Private Sub LoadWorkspaceFlowCandidates( _
        ByVal ws As Worksheet, ByVal itemCount As Long, ByRef outputIndex As Long, _
        ByRef parent() As Long, ByRef sourceRows() As Long, ByRef scores() As Long, _
        ByRef sourceSheets() As String, ByRef sourceKeys() As String, ByRef txIDs() As String, _
        ByRef categories() As String, ByRef datesText() As String, ByRef routes() As String, _
        ByRef points() As String, ByRef constraints() As String, ByRef statuses() As String, _
        ByRef memos() As String, ByRef amounts() As Double, _
        ByRef personClasses() As String, ByRef oneToOneFlags() As Boolean, _
        ByVal txPersonByID As Object, ByVal txDirectionByID As Object, ByVal owners As Object)
    Dim data As Variant, r As Long, itemIndex As Long
    If itemCount <= 0 Then Exit Sub
    data = ws.Range(ws.Cells(2, 1), ws.Cells(itemCount + 1, FLOW_ANALYSIS_LAST_COL)).Value2
    For r = 1 To itemCount
        If r Mod 2048 = 0 Then AppProgress "�����t���[���𒲍��P�ʂ֐������Ă��܂�...", r, itemCount
        outputIndex = outputIndex + 1: itemIndex = outputIndex
        parent(itemIndex) = itemIndex
        sourceRows(itemIndex) = r + 1
        sourceSheets(itemIndex) = SH_ANALYSIS_FLOW
        sourceKeys(itemIndex) = CellText(data(r, FLOW_ANALYSIS_KEY_COL))
        txIDs(itemIndex) = CellText(data(r, 20))
        scores(itemIndex) = WorkspaceLong(data(r, 2))
        categories(itemIndex) = "�����t���["
        datesText(itemIndex) = CellText(data(r, 6))
        amounts(itemIndex) = WorkspaceDouble(data(r, 9))
        routes(itemIndex) = WorkspaceTrimText(CellText(data(r, 12)), WORKSPACE_TEXT_LIMIT)
        points(itemIndex) = WorkspaceTrimText(CellText(data(r, 3)) & "�E" & _
                            CellText(data(r, 4)) & "�B" & CellText(data(r, 16)), WORKSPACE_TEXT_LIMIT)
        constraints(itemIndex) = WorkspaceTrimText("�������x: " & CellText(data(r, 5)) & _
                                 " / �N�I�_��: " & WorkspaceAmountText(data(r, 11)) & _
                                 " / " & CStr(WorkspaceLong(data(r, 7))) & "�i�E" & _
                                 CStr(WorkspaceLong(data(r, 8))) & "���", WORKSPACE_TEXT_LIMIT)
        statuses(itemIndex) = WorkspaceStatusOrDefault(data(r, FLOW_ANALYSIS_STATUS_COL))
        memos(itemIndex) = CellText(data(r, FLOW_ANALYSIS_MEMO_COL))
        personClasses(itemIndex) = WorkspaceCandidatePersonClass( _
            txIDs(itemIndex), txPersonByID, txDirectionByID, oneToOneFlags(itemIndex))
        routes(itemIndex) = personClasses(itemIndex) & "�b" & routes(itemIndex)
        RegisterWorkspaceOwners txIDs(itemIndex), itemIndex, parent, owners
    Next r
End Sub

Private Sub LoadWorkspaceTransactionIdentity(ByRef txPersonByID As Object, _
                                             ByRef txDirectionByID As Object)
    Dim ws As Worksheet, lastR As Long, r As Long
    Dim txValues As Variant, personValues As Variant
    Dim withdrawalValues As Variant, depositValues As Variant
    Dim dataCount As Long, txID As String, personID As String, directionText As String
    Dim withdrawal As Double, deposit As Double
    If Not SheetExists(SH_WORK_TX) Then _
        Err.Raise vbObjectError + 4851, "LoadWorkspaceTransactionIdentity", _
                  "W_���������܂���B�l���敪���쐬�ł��܂���B"
    Set txPersonByID = CreateObject("Scripting.Dictionary")
    Set txDirectionByID = CreateObject("Scripting.Dictionary")
    txPersonByID.CompareMode = vbTextCompare
    txDirectionByID.CompareMode = vbTextCompare
    Set ws = GetSheet(SH_WORK_TX)
    lastR = LastUsedRowInSheet(ws)
    If lastR < 2 Then Exit Sub
    dataCount = lastR - 1
    txValues = ws.Range(ws.Cells(2, WORK_TX_COL_TRANSACTION_ID), _
                        ws.Cells(lastR, WORK_TX_COL_TRANSACTION_ID)).Value2
    personValues = ws.Range(ws.Cells(2, WORK_TX_COL_PERSON_ID), _
                            ws.Cells(lastR, WORK_TX_COL_PERSON_ID)).Value2
    withdrawalValues = ws.Range(ws.Cells(2, OUT_COL_WITHDRAW), _
                                ws.Cells(lastR, OUT_COL_WITHDRAW)).Value2
    depositValues = ws.Range(ws.Cells(2, OUT_COL_DEPOSIT), _
                             ws.Cells(lastR, OUT_COL_DEPOSIT)).Value2
    For r = 1 To dataCount
        txID = CellText(WorkspaceColumnArrayValue(txValues, r, dataCount))
        If Len(txID) > 0 Then
            If Not IsInternalIdValue(txID, "T") Then _
                Err.Raise vbObjectError + 4852, "LoadWorkspaceTransactionIdentity", _
                          "W_��� " & CStr(r + 1) & "�s�ڂ̎��ID�`�����s���ł�: " & txID
            personID = CellText(WorkspaceColumnArrayValue(personValues, r, dataCount))
            If Len(personID) = 0 Then _
                Err.Raise vbObjectError + 4853, "LoadWorkspaceTransactionIdentity", _
                          "W_��� " & CStr(r + 1) & _
                          "�s�ڂɐl��ID������܂���B�����ł͑�ւ��܂���B"
            If Not IsInternalIdValue(personID, "P") Then _
                Err.Raise vbObjectError + 4854, "LoadWorkspaceTransactionIdentity", _
                          "W_��� " & CStr(r + 1) & "�s�ڂ̐l��ID�`�����s���ł�: " & personID
            withdrawal = WorkspaceDouble( _
                WorkspaceColumnArrayValue(withdrawalValues, r, dataCount))
            deposit = WorkspaceDouble( _
                WorkspaceColumnArrayValue(depositValues, r, dataCount))
            If withdrawal > 0 And deposit <= 0 Then
                directionText = "W"
            ElseIf deposit > 0 And withdrawal <= 0 Then
                directionText = "D"
            Else
                Err.Raise vbObjectError + 4855, "LoadWorkspaceTransactionIdentity", _
                          "W_��� " & CStr(r + 1) & _
                          "�s�ڂ̏o�����敪��1�Ɋm��ł��܂���: " & txID
            End If
            If txPersonByID.Exists(txID) Then
                If StrComp(CellText(txPersonByID(txID)), personID, vbTextCompare) <> 0 Or _
                   StrComp(CellText(txDirectionByID(txID)), directionText, vbBinaryCompare) <> 0 Then _
                    Err.Raise vbObjectError + 4856, "LoadWorkspaceTransactionIdentity", _
                              "�������ID�ɈقȂ�l���܂��͏o�����敪������܂�: " & txID
            Else
                txPersonByID.Add txID, personID
                txDirectionByID.Add txID, directionText
            End If
        End If
    Next r
End Sub

Private Function WorkspaceCandidatePersonClass(ByVal txIDList As String, _
                                               ByVal txPersonByID As Object, _
                                               ByVal txDirectionByID As Object, _
                                               ByRef oneToOne As Boolean) As String
    Dim parts As Variant, item As Variant, txID As String, personID As String
    Dim directionText As String, seenTx() As String, seenPersons() As String
    Dim withdrawalCount As Long, depositCount As Long
    Dim uniqueCount As Long, personCount As Long, i As Long, alreadySeen As Boolean
    oneToOne = False
    If txPersonByID Is Nothing Or txDirectionByID Is Nothing Then _
        Err.Raise vbObjectError + 4857, "WorkspaceCandidatePersonClass", _
                  "����̐l��ID����������܂���B"
    parts = Split(txIDList, ";")
    ReDim seenTx(1 To UBound(parts) - LBound(parts) + 1)
    ReDim seenPersons(1 To UBound(parts) - LBound(parts) + 1)
    For Each item In parts
        txID = Trim$(CStr(item))
        alreadySeen = False
        If Len(txID) > 0 Then
            For i = 1 To uniqueCount
                If StrComp(seenTx(i), txID, vbTextCompare) = 0 Then
                    alreadySeen = True
                    Exit For
                End If
            Next i
        End If
        If Len(txID) > 0 And Not alreadySeen Then
            If Not txPersonByID.Exists(txID) Or Not txDirectionByID.Exists(txID) Then _
                Err.Raise vbObjectError + 4858, "WorkspaceCandidatePersonClass", _
                          "���̍\�������W_����ɂ���܂���: " & txID
            If Len(CellText(txPersonByID(txID))) = 0 Then _
                Err.Raise vbObjectError + 4859, "WorkspaceCandidatePersonClass", _
                          "���̍\������ɐl��ID������܂���: " & txID
            uniqueCount = uniqueCount + 1
            seenTx(uniqueCount) = txID
            personID = CellText(txPersonByID(txID))
            alreadySeen = False
            For i = 1 To personCount
                If StrComp(seenPersons(i), personID, vbTextCompare) = 0 Then
                    alreadySeen = True
                    Exit For
                End If
            Next i
            If Not alreadySeen Then
                personCount = personCount + 1
                seenPersons(personCount) = personID
            End If
            directionText = CellText(txDirectionByID(txID))
            If directionText = "W" Then
                withdrawalCount = withdrawalCount + 1
            ElseIf directionText = "D" Then
                depositCount = depositCount + 1
            Else
                Err.Raise vbObjectError + 4860, "WorkspaceCandidatePersonClass", _
                          "���̏o�����敪���s���ł�: " & txID
            End If
        End If
    Next item
    If uniqueCount < 2 Or withdrawalCount < 1 Or depositCount < 1 Then _
        Err.Raise vbObjectError + 4861, "WorkspaceCandidatePersonClass", _
                  "���̍\��������o���E�����̑g�����ɂȂ��Ă��܂���B"
    oneToOne = (withdrawalCount = 1 And depositCount = 1)
    If personCount > 1 Then
        WorkspaceCandidatePersonClass = WORKSPACE_PERSON_DIFFERENT
    ElseIf personCount = 1 Then
        WorkspaceCandidatePersonClass = WORKSPACE_PERSON_SAME
    Else
        Err.Raise vbObjectError + 4862, "WorkspaceCandidatePersonClass", _
                  "���̐l��ID���m��ł��܂���B"
    End If
End Function

Private Sub RegisterWorkspaceOwners(ByVal idList As String, ByVal itemIndex As Long, _
                                    ByRef parent() As Long, ByVal owners As Object)
    Dim parts As Variant, item As Variant, txID As String
    If Len(idList) = 0 Then Exit Sub
    parts = Split(idList, ";")
    For Each item In parts
        txID = Trim$(CStr(item))
        If Len(txID) > 0 Then
            If owners.Exists(txID) Then
                WorkspaceUnion parent, itemIndex, CLng(owners(txID))
            Else
                owners.Add txID, itemIndex
            End If
        End If
    Next item
End Sub

Private Function WorkspaceFindRoot(ByRef parent() As Long, ByVal itemIndex As Long) As Long
    Dim rootIndex As Long, nextIndex As Long
    rootIndex = itemIndex
    Do While parent(rootIndex) <> rootIndex
        rootIndex = parent(rootIndex)
    Loop
    Do While parent(itemIndex) <> itemIndex
        nextIndex = parent(itemIndex)
        parent(itemIndex) = rootIndex
        itemIndex = nextIndex
    Loop
    WorkspaceFindRoot = rootIndex
End Function

Private Sub WorkspaceUnion(ByRef parent() As Long, ByVal firstIndex As Long, ByVal secondIndex As Long)
    Dim firstRoot As Long, secondRoot As Long
    firstRoot = WorkspaceFindRoot(parent, firstIndex)
    secondRoot = WorkspaceFindRoot(parent, secondIndex)
    If firstRoot = secondRoot Then Exit Sub
    If firstRoot < secondRoot Then
        parent(secondRoot) = firstRoot
    Else
        parent(firstRoot) = secondRoot
    End If
End Sub

Private Function WorkspaceReviewStateRank(ByVal statusText As String) As Long
    Select Case Trim$(statusText)
        Case ANALYSIS_STATUS_SHIFT_CONFIRMED
            WorkspaceReviewStateRank = 4
        Case ANALYSIS_STATUS_FOLLOWUP
            WorkspaceReviewStateRank = 3
        Case ANALYSIS_STATUS_EXCLUDED
            WorkspaceReviewStateRank = 1
        Case Else
            WorkspaceReviewStateRank = 2
    End Select
End Function

Private Function WorkspaceCandidateIsBetterRepresentative( _
        ByVal candidateIndex As Long, ByVal currentIndex As Long, _
        ByRef statuses() As String, ByRef oneToOneFlags() As Boolean, _
        ByRef personClasses() As String, ByRef scores() As Long) As Boolean
    Dim candidateRank As Long, currentRank As Long
    candidateRank = WorkspaceReviewStateRank(statuses(candidateIndex))
    currentRank = WorkspaceReviewStateRank(statuses(currentIndex))
    If candidateRank <> currentRank Then
        WorkspaceCandidateIsBetterRepresentative = (candidateRank > currentRank)
        Exit Function
    End If
    If oneToOneFlags(candidateIndex) <> oneToOneFlags(currentIndex) Then
        WorkspaceCandidateIsBetterRepresentative = oneToOneFlags(candidateIndex)
        Exit Function
    End If
    If personClasses(candidateIndex) <> personClasses(currentIndex) Then
        WorkspaceCandidateIsBetterRepresentative = _
            (personClasses(candidateIndex) = WORKSPACE_PERSON_DIFFERENT)
        Exit Function
    End If
    If scores(candidateIndex) <> scores(currentIndex) Then
        WorkspaceCandidateIsBetterRepresentative = (scores(candidateIndex) > scores(currentIndex))
        Exit Function
    End If
    WorkspaceCandidateIsBetterRepresentative = (candidateIndex < currentIndex)
End Function

Public Function AnalysisWorkspacePriorityRegressionTest() As Boolean
    Dim txPersonByID As Object, txDirectionByID As Object
    Dim statuses(1 To 2) As String, personClasses(1 To 2) As String
    Dim oneToOneFlags(1 To 2) As Boolean, scores(1 To 2) As Long
    Dim oneToOne As Boolean, classText As String
    On Error GoTo TestFailed
    If AnalysisReviewCellWork(1, 1, 1, 1, 1, 1, 1, 1, 1, 1) <> 177# Then Exit Function
    If AnalysisCapacityEquivalentRows(15#) <> 1# Then Exit Function
    If AnalysisCapacityEquivalentRows(16#) <> 1# Then Exit Function
    If AnalysisCapacityEquivalentRows(17#) <> 2# Then Exit Function
    If AnalysisCapacityEquivalentRows(32#) <> 2# Then Exit Function
    If AnalysisCapacityEquivalentRows(33#) <> 3# Then Exit Function
    If AnalysisCapacityEquivalentRows(177#) <> 12# Then Exit Function
    If AnalysisCapacityEquivalentRows( _
           ANALYSIS_CAPACITY_LONG_MAX * CDbl(ANALYSIS_CAPACITY_BASE_COLUMNS)) <> _
       ANALYSIS_CAPACITY_LONG_MAX Then Exit Function
    If AnalysisCapacityEquivalentRows( _
           ANALYSIS_CAPACITY_LONG_MAX * CDbl(ANALYSIS_CAPACITY_BASE_COLUMNS) + 1#) <= _
       ANALYSIS_CAPACITY_LONG_MAX Then Exit Function
    If AnalysisWorkspaceCandidateWorkloadRows(40000, 35000) <> 75000# Then Exit Function
#If Win64 Or Mac Then
    If AnalysisCapacityNeedsConfirmation(150000#, 0#) Then Exit Function
    If Not AnalysisCapacityNeedsConfirmation(150001#, 150000#) Then Exit Function
    If AnalysisCapacityNeedsConfirmation(200000#, 150001#) Then Exit Function
#Else
    If AnalysisCapacityNeedsConfirmation(50000#, 0#) Then Exit Function
    If Not AnalysisCapacityNeedsConfirmation(50001#, 50000#) Then Exit Function
    If AnalysisCapacityNeedsConfirmation(75000#, 50001#) Then Exit Function
    If Not AnalysisCapacityNeedsConfirmation(75001#, 60000#) Then Exit Function
#End If
    Set txPersonByID = CreateObject("Scripting.Dictionary")
    Set txDirectionByID = CreateObject("Scripting.Dictionary")
    txPersonByID.CompareMode = vbTextCompare
    txDirectionByID.CompareMode = vbTextCompare
    txPersonByID.Add "T1", "P1": txDirectionByID.Add "T1", "W"
    txPersonByID.Add "T2", "P1": txDirectionByID.Add "T2", "D"
    txPersonByID.Add "T3", "P2": txDirectionByID.Add "T3", "D"
    txPersonByID.Add "T4", "P1": txDirectionByID.Add "T4", "W"
    txPersonByID.Add "T5", "P2": txDirectionByID.Add "T5", "W"

    classText = WorkspaceCandidatePersonClass( _
                    "T1;T2", txPersonByID, txDirectionByID, oneToOne)
    If classText <> WORKSPACE_PERSON_SAME Or Not oneToOne Then Exit Function
    classText = WorkspaceCandidatePersonClass( _
                    "T1;T3", txPersonByID, txDirectionByID, oneToOne)
    If classText <> WORKSPACE_PERSON_DIFFERENT Or Not oneToOne Then Exit Function
    classText = WorkspaceCandidatePersonClass( _
                    "T1;T4;T2", txPersonByID, txDirectionByID, oneToOne)
    If classText <> WORKSPACE_PERSON_SAME Or oneToOne Then Exit Function
    classText = WorkspaceCandidatePersonClass( _
                    "T1;T5;T2;T3", txPersonByID, txDirectionByID, oneToOne)
    If classText <> WORKSPACE_PERSON_DIFFERENT Or oneToOne Then Exit Function
    If WorkspaceRoutePersonPriority(WORKSPACE_PERSON_DIFFERENT & "�bA��B") <> 2 Then Exit Function
    If WorkspaceRoutePersonPriority(WORKSPACE_PERSON_SAME & "�bA��A") <> 1 Then Exit Function
    If WorkspaceResultPersonPriority( _
           WORKSPACE_PERSON_SAME & "�bA��A", _
           "�ʐl���Ԃ̑�֌�₠��B") <> 2 Then Exit Function
    If WorkspaceAlternativePersonOrder(WORKSPACE_PERSON_DIFFERENT) <= _
       WorkspaceAlternativePersonOrder(WORKSPACE_PERSON_SAME) Then Exit Function

    statuses(1) = ANALYSIS_STATUS_SHIFT_CONFIRMED
    statuses(2) = ANALYSIS_STATUS_UNREVIEWED
    oneToOneFlags(1) = False: oneToOneFlags(2) = True
    personClasses(1) = WORKSPACE_PERSON_SAME
    personClasses(2) = WORKSPACE_PERSON_DIFFERENT
    scores(1) = 1: scores(2) = 100
    If WorkspaceCandidateIsBetterRepresentative( _
           2, 1, statuses, oneToOneFlags, personClasses, scores) Then Exit Function
    If scores(1) <> 1 Or scores(2) <> 100 Then Exit Function

    statuses(1) = ANALYSIS_STATUS_UNREVIEWED
    If Not WorkspaceCandidateIsBetterRepresentative( _
               2, 1, statuses, oneToOneFlags, personClasses, scores) Then Exit Function
    If scores(1) <> 1 Or scores(2) <> 100 Then Exit Function

    oneToOneFlags(1) = True
    scores(1) = 100: scores(2) = 1
    If Not WorkspaceCandidateIsBetterRepresentative( _
               2, 1, statuses, oneToOneFlags, personClasses, scores) Then Exit Function

    personClasses(1) = WORKSPACE_PERSON_DIFFERENT
    scores(1) = 100: scores(2) = 1
    If WorkspaceCandidateIsBetterRepresentative( _
           2, 1, statuses, oneToOneFlags, personClasses, scores) Then Exit Function
    AnalysisWorkspacePriorityRegressionTest = True
    Exit Function
TestFailed:
    Err.Clear
End Function

Private Sub WriteWorkspaceGroupTable( _
        ByVal ws As Worksheet, ByVal candidateCount As Long, ByRef parent() As Long, _
        ByRef sourceRows() As Long, ByRef scores() As Long, ByRef sourceSheets() As String, _
        ByRef sourceKeys() As String, ByRef txIDs() As String, ByRef categories() As String, _
        ByRef statuses() As String, ByRef memos() As String, ByRef personClasses() As String, _
        ByRef groupCounts() As Long, ByRef representatives() As Long, _
        ByRef groupIDs() As String)
    Dim buffer() As Variant, bufferCount As Long, nextRow As Long
    Dim i As Long, rootIndex As Long, personPass As Long
    ReDim buffer(1 To WORKSPACE_BUFFER_ROWS, 1 To ANALYSIS_GROUP_LAST_COL)
    nextRow = 2
    '��֌���ǂނƂ��͕ʐl���Ԃ��ɂ���B�X�R�A�Ƒ�\�t���O�͕ύX���Ȃ��B
    For personPass = 2 To 1 Step -1
        For i = 1 To candidateCount
            If WorkspaceAlternativePersonOrder(personClasses(i)) = personPass Then
                rootIndex = WorkspaceFindRoot(parent, i)
                bufferCount = bufferCount + 1
                buffer(bufferCount, 1) = groupIDs(rootIndex)
                buffer(bufferCount, 2) = sourceSheets(i)
                buffer(bufferCount, 3) = sourceRows(i)
                buffer(bufferCount, 4) = sourceKeys(i)
                buffer(bufferCount, 5) = txIDs(i)
                buffer(bufferCount, 6) = scores(i)
                If representatives(rootIndex) = i Then buffer(bufferCount, 7) = "��\" Else buffer(bufferCount, 7) = "���"
                buffer(bufferCount, 8) = categories(i)
                buffer(bufferCount, 9) = statuses(i)
                buffer(bufferCount, 10) = memos(i)
                If bufferCount = WORKSPACE_BUFFER_ROWS Then
                    FlushWorkspaceBuffer ws, buffer, bufferCount, nextRow, ANALYSIS_GROUP_LAST_COL
                    ReDim buffer(1 To WORKSPACE_BUFFER_ROWS, 1 To ANALYSIS_GROUP_LAST_COL)
                    bufferCount = 0
                End If
            End If
        Next i
    Next personPass
    If bufferCount > 0 Then FlushWorkspaceBuffer ws, buffer, bufferCount, nextRow, ANALYSIS_GROUP_LAST_COL
End Sub

Private Function WorkspaceAlternativePersonOrder(ByVal personClass As String) As Long
    If personClass = WORKSPACE_PERSON_DIFFERENT Then
        WorkspaceAlternativePersonOrder = 2
    ElseIf personClass = WORKSPACE_PERSON_SAME Then
        WorkspaceAlternativePersonOrder = 1
    Else
        Err.Raise vbObjectError + 4864, "WorkspaceAlternativePersonOrder", _
                  "��֌��̐l���敪���s���ł��B"
    End If
End Function

Private Sub FillWorkspaceCandidateResult( _
        ByRef buffer() As Variant, ByVal bufferRow As Long, ByVal itemIndex As Long, _
        ByVal alternativeCount As Long, ByVal groupID As String, _
        ByRef sourceRows() As Long, ByRef scores() As Long, ByRef sourceSheets() As String, _
        ByRef sourceKeys() As String, ByRef txIDs() As String, ByRef categories() As String, _
        ByRef datesText() As String, ByRef routes() As String, ByRef points() As String, _
        ByRef constraints() As String, ByRef statuses() As String, ByRef memos() As String, _
        ByRef amounts() As Double)
    Dim constraintText As String
    constraintText = constraints(itemIndex)
    If alternativeCount > 1 Then
        constraintText = WorkspaceAppend(constraintText, "������������L�����։��� " & _
                         CStr(alternativeCount) & _
                         "���B��������\�ō\������Ɗ֘A�����؂�ւ��Ċm�F���Ă��������B", " / ")
    End If
    buffer(bufferRow, 1) = scores(itemIndex)
    buffer(bufferRow, 2) = categories(itemIndex)
    buffer(bufferRow, 3) = datesText(itemIndex)
    buffer(bufferRow, 4) = amounts(itemIndex)
    buffer(bufferRow, 5) = routes(itemIndex)
    buffer(bufferRow, 6) = points(itemIndex)
    buffer(bufferRow, 7) = WorkspaceTrimText(constraintText, WORKSPACE_TEXT_LIMIT)
    buffer(bufferRow, 8) = statuses(itemIndex)
    buffer(bufferRow, 9) = memos(itemIndex)
    buffer(bufferRow, 10) = sourceSheets(itemIndex)
    buffer(bufferRow, 11) = sourceKeys(itemIndex)
    buffer(bufferRow, 12) = groupID
    buffer(bufferRow, 13) = sourceRows(itemIndex)
    buffer(bufferRow, 14) = txIDs(itemIndex)
    buffer(bufferRow, 15) = alternativeCount
End Sub

Private Sub WriteWorkspaceUnknownResults(ByVal wsUnknown As Worksheet, ByVal wsResult As Worksheet, _
                                         ByRef outputTotal As Long, ByVal unknownCount As Long, _
                                         ByVal wsGroup As Worksheet)
    Dim data As Variant, resultBuffer() As Variant, groupBuffer() As Variant
    Dim resultBufferCount As Long, groupBufferCount As Long
    Dim nextResultRow As Long, nextGroupRow As Long
    Dim r As Long, categoryText As String, txID As String, groupID As String
    Dim amountValue As Double, timeText As String, routeText As String
    nextResultRow = outputTotal + 2
    nextGroupRow = LastUsedRowInSheet(wsGroup) + 1
    If nextGroupRow < 2 Then nextGroupRow = 2
    ReDim resultBuffer(1 To WORKSPACE_BUFFER_ROWS, 1 To ANALYSIS_RESULT_LAST_COL)
    ReDim groupBuffer(1 To WORKSPACE_BUFFER_ROWS, 1 To ANALYSIS_GROUP_LAST_COL)
    data = wsUnknown.Range(wsUnknown.Cells(2, 1), _
                           wsUnknown.Cells(unknownCount + 1, UNKNOWN_ANALYSIS_LAST_COL)).Value2
    For r = 1 To unknownCount
        txID = CellText(data(r, 24))
        groupID = "U-" & WorkspaceDigest(txID & "|" & CellText(data(r, 26)))
        If StrComp(CellText(data(r, 3)), "�����s�����", vbTextCompare) = 0 Then
            categoryText = "�����s��"
            amountValue = WorkspaceDouble(data(r, 13))
        Else
            categoryText = "�g�r�s��"
            amountValue = WorkspaceDouble(data(r, 14))
        End If
        timeText = WorkspaceTimeText(data(r, 5))
        routeText = WorkspacePartyAccount(data(r, 7), data(r, 8), data(r, 9), _
                    data(r, 10), data(r, 11), data(r, 12))
        resultBufferCount = resultBufferCount + 1
        resultBuffer(resultBufferCount, 1) = WorkspaceLong(data(r, 2))
        resultBuffer(resultBufferCount, 2) = categoryText
        resultBuffer(resultBufferCount, 3) = WorkspaceDateText(data(r, 4)) & " " & timeText
        resultBuffer(resultBufferCount, 4) = amountValue
        resultBuffer(resultBufferCount, 5) = routeText
        resultBuffer(resultBufferCount, 6) = WorkspaceTrimText(CellText(data(r, 20)), WORKSPACE_TEXT_LIMIT)
        resultBuffer(resultBufferCount, 7) = WorkspaceTrimText( _
            "�������x: " & CellText(data(r, 6)) & " / ���: " & CellText(data(r, 18)) & _
            " / �ō��]��: " & CellText(data(r, 19)) & " / �E�v: " & _
            WorkspaceBlankLabel(data(r, 17)), WORKSPACE_TEXT_LIMIT)
        resultBuffer(resultBufferCount, 8) = WorkspaceStatusOrDefault(data(r, 21))
        resultBuffer(resultBufferCount, 9) = CellText(data(r, 22))
        resultBuffer(resultBufferCount, 10) = SH_ANALYSIS_UNKNOWN
        resultBuffer(resultBufferCount, 11) = CellText(data(r, 26))
        resultBuffer(resultBufferCount, 12) = groupID
        resultBuffer(resultBufferCount, 13) = r + 1
        resultBuffer(resultBufferCount, 14) = txID
        resultBuffer(resultBufferCount, 15) = 1

        groupBufferCount = groupBufferCount + 1
        groupBuffer(groupBufferCount, 1) = groupID
        groupBuffer(groupBufferCount, 2) = SH_ANALYSIS_UNKNOWN
        groupBuffer(groupBufferCount, 3) = r + 1
        groupBuffer(groupBufferCount, 4) = CellText(data(r, 26))
        groupBuffer(groupBufferCount, 5) = txID
        groupBuffer(groupBufferCount, 6) = WorkspaceLong(data(r, 2))
        groupBuffer(groupBufferCount, 7) = "��\"
        groupBuffer(groupBufferCount, 8) = categoryText
        groupBuffer(groupBufferCount, 9) = WorkspaceStatusOrDefault(data(r, 21))
        groupBuffer(groupBufferCount, 10) = CellText(data(r, 22))
        outputTotal = outputTotal + 1

        If resultBufferCount = WORKSPACE_BUFFER_ROWS Then
            FlushWorkspaceBuffer wsResult, resultBuffer, resultBufferCount, nextResultRow, ANALYSIS_RESULT_LAST_COL
            ReDim resultBuffer(1 To WORKSPACE_BUFFER_ROWS, 1 To ANALYSIS_RESULT_LAST_COL)
            resultBufferCount = 0
        End If
        If groupBufferCount = WORKSPACE_BUFFER_ROWS Then
            FlushWorkspaceBuffer wsGroup, groupBuffer, groupBufferCount, nextGroupRow, ANALYSIS_GROUP_LAST_COL
            ReDim groupBuffer(1 To WORKSPACE_BUFFER_ROWS, 1 To ANALYSIS_GROUP_LAST_COL)
            groupBufferCount = 0
        End If
    Next r
    If resultBufferCount > 0 Then _
        FlushWorkspaceBuffer wsResult, resultBuffer, resultBufferCount, nextResultRow, ANALYSIS_RESULT_LAST_COL
    If groupBufferCount > 0 Then _
        FlushWorkspaceBuffer wsGroup, groupBuffer, groupBufferCount, nextGroupRow, ANALYSIS_GROUP_LAST_COL
End Sub

Private Sub FlushWorkspaceBuffer(ByVal ws As Worksheet, ByRef buffer() As Variant, _
                                 ByVal bufferCount As Long, ByRef nextRow As Long, _
                                 ByVal columnCount As Long)
    Dim outputData() As Variant, r As Long, c As Long
    If bufferCount <= 0 Then Exit Sub
    ReDim outputData(1 To bufferCount, 1 To columnCount)
    For r = 1 To bufferCount
        For c = 1 To columnCount
            outputData(r, c) = buffer(r, c)
        Next c
    Next r
    ws.Range(ws.Cells(nextRow, 1), ws.Cells(nextRow + bufferCount - 1, columnCount)).Value = outputData
    nextRow = nextRow + bufferCount
End Sub

Private Sub FinalizeAnalysisResultSheet(ByVal ws As Worksheet, ByVal dataCount As Long)
    Dim lastR As Long
    lastR = dataCount + 1
    ws.Unprotect Password:=TOOL_PASSWORD
    FormatOutputHeader ws.Range(ws.Cells(1, 1), ws.Cells(1, ANALYSIS_RESULT_LAST_COL))
    ApplyAnalysisResultColumnWidths ws
    ws.Rows(1).RowHeight = 52
    ws.Columns("J:O").Hidden = True
    If dataCount > 0 Then
        With ws.Range(ws.Cells(2, 1), ws.Cells(lastR, ANALYSIS_RESULT_VISIBLE_COL))
            .VerticalAlignment = xlTop
            .WrapText = True
        End With
        With ws.Range(ws.Cells(2, 1), ws.Cells(lastR, 4))
            .VerticalAlignment = xlCenter
        End With
        ws.Range(ws.Cells(2, 1), ws.Cells(lastR, 3)).HorizontalAlignment = xlCenter
        ws.Range(ws.Cells(2, 4), ws.Cells(lastR, 4)).HorizontalAlignment = xlRight
        ws.Range(ws.Cells(2, ANALYSIS_RESULT_STATUS_COL), _
                 ws.Cells(lastR, ANALYSIS_RESULT_STATUS_COL)).HorizontalAlignment = xlCenter
        ws.Range(ws.Cells(2, 1), ws.Cells(lastR, 1)).Font.Bold = True
        ws.Range(ws.Cells(2, ANALYSIS_RESULT_STATUS_COL), _
                 ws.Cells(lastR, ANALYSIS_RESULT_MEMO_COL)).Interior.Color = RGB(254, 249, 195)
        With ws.Range(ws.Cells(2, 1), ws.Cells(lastR, 7)).FormatConditions
            .Delete
            .Add Type:=xlExpression, Formula1:="=MOD(ROW(),2)=0"
            .Item(.Count).Interior.Color = RGB(248, 250, 252)
        End With
        ws.Rows("2:" & CStr(lastR)).RowHeight = 62
        SortAnalysisResult ws, lastR
    End If
    If ws.AutoFilterMode Then ws.AutoFilterMode = False
    ws.Range(ws.Cells(1, 1), ws.Cells(lastR, ANALYSIS_RESULT_LAST_COL)).AutoFilter
    ws.ScrollArea = "A1:I" & CStr(Application.Max(50, lastR + 20))
    ApplyWorkspaceReviewValidation ws, lastR
    AddManualBuilderHint ws
    SafeFreezeSheetAt ws, "A2", 85
    ProtectSingleAnalysisSheet ws
End Sub

Private Sub AddManualBuilderHint(ByVal ws As Worksheet)
    Dim i As Long
    Dim x As Double, y As Double, w As Double
    Dim errorNumber As Long, errorDescription As String
    If ws Is Nothing Then Exit Sub
    On Error GoTo EH
    For i = ws.Shapes.Count To 1 Step -1
        If ToolShapeActionName(ws.Shapes(i)) = "OpenManualAnalysisCandidateBuilder" Then _
            ws.Shapes(i).Delete
    Next i
    If Not ws.Cells(1, 1).Comment Is Nothing Then ws.Cells(1, 1).Comment.Delete
    ws.Cells(1, 1).AddComment _
        "�������ɂȂ������ړ��́A���o����̃{�^���܂��͌��o���s�̃_�u���N���b�N����쐬�ł��܂��B" & _
        vbCrLf & "�S�������o���E�����𕡐��I���ł��܂��B"
    ws.Cells(1, 1).Comment.Visible = False
    '���o���̏㔼���������ȃc�[���o�[�Ƃ��Ďg���A�B�����삾�����蓮���쐬�𖾎�����B
    ws.Range("A1:I1").VerticalAlignment = xlBottom
    x = ws.Range("F1").Left + 3
    y = ws.Range("F1").Top + 2
    w = ws.Range("F1:I1").Width - 6
    AddUIButton ws, x, y, w, 20, "�{ �蓮�����쐬", _
                "OpenManualAnalysisCandidateBuilder", "tool"
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    Err.Raise errorNumber, "AddManualBuilderHint", errorDescription
End Sub

Private Sub ApplyAnalysisResultColumnWidths(ByVal ws As Worksheet)
    ws.Columns("A:A").ColumnWidth = 9
    ws.Columns("B:B").ColumnWidth = 12
    ws.Columns("C:C").ColumnWidth = 16
    ws.Columns("D:D").ColumnWidth = 13
    ws.Columns("E:E").ColumnWidth = 23
    ws.Columns("F:F").ColumnWidth = 28
    ws.Columns("G:G").ColumnWidth = 24
    ws.Columns("H:H").ColumnWidth = 14
    ws.Columns("I:I").ColumnWidth = 22
End Sub

Private Sub SortAnalysisResult(ByVal ws As Worksheet, ByVal lastR As Long)
    Dim sourceData As Variant, familyData() As Variant, personPriorityData() As Variant
    Dim r As Long, categoryText As String, routeText As String, constraintText As String
    Dim errorNumber As Long, errorDescription As String
    If lastR < 2 Then Exit Sub
    On Error GoTo EH
    sourceData = ws.Range(ws.Cells(2, 2), ws.Cells(lastR, 7)).Value2
    ReDim familyData(1 To lastR - 1, 1 To 1)
    ReDim personPriorityData(1 To lastR - 1, 1 To 1)
    For r = 1 To lastR - 1
        categoryText = CellText(sourceData(r, 1))
        routeText = CellText(sourceData(r, 4))
        constraintText = CellText(sourceData(r, 6))
        familyData(r, 1) = WorkspaceResultCategoryRank(categoryText)
        If categoryText = "�����V�t�g" Or categoryText = "�����t���[" Then
            personPriorityData(r, 1) = WorkspaceResultPersonPriority(routeText, constraintText)
        Else
            personPriorityData(r, 1) = 0
        End If
    Next r
    ws.Range("P1").Value2 = "�����敪��"
    ws.Range("Q1").Value2 = "�����l����"
    ws.Range(ws.Cells(2, 16), ws.Cells(lastR, 16)).Value2 = familyData
    ws.Range(ws.Cells(2, 17), ws.Cells(lastR, 17)).Value2 = personPriorityData
    With ws.Sort
        .SortFields.Clear
        .SortFields.Add Key:=ws.Range(ws.Cells(2, 16), ws.Cells(lastR, 16)), _
                        SortOn:=xlSortOnValues, Order:=xlAscending, DataOption:=xlSortNormal
        .SortFields.Add Key:=ws.Range(ws.Cells(2, 17), ws.Cells(lastR, 17)), _
                        SortOn:=xlSortOnValues, Order:=xlDescending, DataOption:=xlSortNormal
        .SortFields.Add Key:=ws.Range(ws.Cells(2, 1), ws.Cells(lastR, 1)), _
                        SortOn:=xlSortOnValues, Order:=xlDescending, DataOption:=xlSortNormal
        .SortFields.Add Key:=ws.Range(ws.Cells(2, 2), ws.Cells(lastR, 2)), _
                        SortOn:=xlSortOnValues, Order:=xlAscending, DataOption:=xlSortNormal
        .SortFields.Add Key:=ws.Range(ws.Cells(2, 3), ws.Cells(lastR, 3)), _
                        SortOn:=xlSortOnValues, Order:=xlAscending, DataOption:=xlSortNormal
        .SetRange ws.Range(ws.Cells(1, 1), ws.Cells(lastR, 17))
        .Header = xlYes
        .Apply
    End With
    ws.Range(ws.Cells(1, 16), ws.Cells(lastR, 17)).ClearContents
    ws.Columns("P:Q").Hidden = True
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    On Error Resume Next
    ws.Range(ws.Cells(1, 16), ws.Cells(Application.Max(1, lastR), 17)).ClearContents
    ws.Columns("P:Q").Hidden = True
    On Error GoTo 0
    Err.Raise errorNumber, "SortAnalysisResult", errorDescription
End Sub

Private Function WorkspaceResultCategoryRank(ByVal categoryText As String) As Long
    Select Case categoryText
        Case "�����V�t�g", "�����t���["
            WorkspaceResultCategoryRank = 1
        Case "�����s��"
            WorkspaceResultCategoryRank = 2
        Case "�g�r�s��"
            WorkspaceResultCategoryRank = 3
        Case Else
            WorkspaceResultCategoryRank = 9
    End Select
End Function

Private Function WorkspaceResultPersonPriority(ByVal routeText As String, _
                                               ByVal constraintText As String) As Long
    WorkspaceResultPersonPriority = WorkspaceRoutePersonPriority(routeText)
    If WorkspaceResultPersonPriority < 2 And _
       InStr(1, constraintText, "�ʐl���Ԃ̑�֌�₠��", vbBinaryCompare) > 0 Then _
        WorkspaceResultPersonPriority = 2
End Function

Private Function WorkspaceRoutePersonPriority(ByVal routeText As String) As Long
    If Left$(routeText, Len(WORKSPACE_PERSON_DIFFERENT) + 1) = _
       WORKSPACE_PERSON_DIFFERENT & "�b" Then
        WorkspaceRoutePersonPriority = 2
    ElseIf Left$(routeText, Len(WORKSPACE_PERSON_SAME) + 1) = _
           WORKSPACE_PERSON_SAME & "�b" Then
        WorkspaceRoutePersonPriority = 1
    Else
        Err.Raise vbObjectError + 4863, "WorkspaceRoutePersonPriority", _
                  "�����ړ����ɐl���敪������܂���B�ĕ��͂��Ă��������B"
    End If
End Function

Private Sub ApplyWorkspaceReviewValidation(ByVal ws As Worksheet, ByVal lastR As Long)
    Dim statusRange As Range, memoRange As Range
    ws.Cells.Locked = True
    If lastR < 2 Then Exit Sub
    Set statusRange = ws.Range(ws.Cells(2, ANALYSIS_RESULT_STATUS_COL), _
                               ws.Cells(lastR, ANALYSIS_RESULT_STATUS_COL))
    Set memoRange = ws.Range(ws.Cells(2, ANALYSIS_RESULT_MEMO_COL), _
                             ws.Cells(lastR, ANALYSIS_RESULT_MEMO_COL))
    statusRange.Locked = False
    memoRange.Locked = False
    With statusRange.Validation
        .Delete
        .Add Type:=xlValidateList, AlertStyle:=xlValidAlertStop, Operator:=xlBetween, _
             Formula1:="=INDIRECT(IF(OR($B2=""�����V�t�g"",$B2=""�����t���[""),""" & _
                      NM_LST_ANALYSIS_SHIFT_STATUS & """,IF($B2=""�����s��"",""" & _
                      NM_LST_ANALYSIS_SOURCE_STATUS & """,""" & NM_LST_ANALYSIS_USE_STATUS & """)))"
        .IgnoreBlank = True
        .InCellDropdown = True
        .ShowError = True
        .ErrorTitle = "�m�F�󋵂�I�����Ă�������"
        .ErrorMessage = "�s�̋敪�ɑΉ�����m�F�󋵂�I�����Ă��������B"
    End With
    With memoRange.Validation
        .Delete
        .Add Type:=xlValidateTextLength, AlertStyle:=xlValidAlertStop, _
             Operator:=xlLessEqual, Formula1:=CStr(WORKSPACE_MEMO_MAX)
        .IgnoreBlank = True
        .ShowError = True
        .ErrorTitle = "�m�F�����̕��������m�F���Ă�������"
        .ErrorMessage = "�m�F������" & CStr(WORKSPACE_MEMO_MAX) & "�����ȓ��œ��͂��Ă��������B"
    End With
End Sub

Public Sub SetAnalysisReviewEditingEnabled(ByVal enabled As Boolean)
    Dim ws As Worksheet, lastR As Long, r As Long
    Dim workbookWasSaved As Boolean, emergencyProtected As Boolean
    Dim previousEvents As Boolean, eventsCaptured As Boolean
    Dim eventsStopped As Boolean
    Dim normalProtectionConfirmed As Boolean
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim emergencyErrorNumber As Long, emergencyErrorDescription As String
    Dim emergencyReadErrorNumber As Long, emergencyReadErrorDescription As String
    Dim savedErrorNumber As Long, savedErrorDescription As String
    Dim recoveryStateConfirmed As Boolean
    Dim recoveryAttempted As Boolean, recoveryTerminalFailure As Boolean
    Dim eventStateDetail As String, convergenceDetail As String
    Dim recoveryDetail As String
    workbookWasSaved = ThisWorkbook.Saved
    On Error GoTo EH
    If Not TryGetAnalysisWorkspaceEnableEvents( _
               previousEvents, eventStateDetail) Then _
        Err.Raise vbObjectError + 4897, "SetAnalysisReviewEditingEnabled", _
                  "Excel�C�x���g�̊J�n��Ԃ��擾�ł��܂���B " & eventStateDetail
    eventsCaptured = True
    If Not TrySetAnalysisWorkspaceEnableEventsExact(False, eventStateDetail) Then _
        Err.Raise vbObjectError + 4898, "SetAnalysisReviewEditingEnabled", _
                  "�ҏW�ۂ̕ύX�O��Excel�C�x���g���~�ł��܂���ł����B " & _
                  eventStateDetail
    eventsStopped = True
    normalProtectionConfirmed = True
    If SheetExists(SH_ANALYSIS_RESULT) Then
        Set ws = GetSheet(SH_ANALYSIS_RESULT)
        ws.Unprotect Password:=TOOL_PASSWORD
        lastR = LastUsedRowInSheet(ws)
        If enabled Then
            ApplyWorkspaceReviewValidation ws, lastR
        Else
            ws.Range(ws.Cells(1, 1), _
                     ws.Cells(Application.Max(50, lastR + 20), ANALYSIS_RESULT_LAST_COL)).Locked = True
        End If
        ProtectSingleAnalysisSheet ws
        normalProtectionConfirmed = _
            ws.ProtectContents And ws.ProtectDrawingObjects
        If Not normalProtectionConfirmed Then _
            Err.Raise vbObjectError + 4899, "SetAnalysisReviewEditingEnabled", _
                      ws.Name & "�̃Z���E�}�`�ی��ǖ߂��m�F�ł��܂���B"
    End If
    If SheetExists(SH_ANALYSIS_DETAIL) Then
        Set ws = GetSheet(SH_ANALYSIS_DETAIL)
        ws.Unprotect Password:=TOOL_PASSWORD
        lastR = LastUsedRowInSheet(ws)
        ws.Range(ws.Cells(1, 1), _
                 ws.Cells(Application.Max(50, lastR + 20), DETAIL_COL_KIND)).Locked = True
        If enabled Then
            For r = 2 To lastR
                If CellText(ws.Cells(r, DETAIL_COL_KIND).Value) = "���" Then
                    ws.Cells(r, 6).Locked = False
                ElseIf CellText(ws.Cells(r, DETAIL_COL_KIND).Value) = "��⃁��" Then
                    ws.Range(ws.Cells(r, 2), ws.Cells(r, 7)).Locked = False
                End If
            Next r
        End If
        ProtectSingleAnalysisSheet ws
        normalProtectionConfirmed = _
            normalProtectionConfirmed And _
            ws.ProtectContents And ws.ProtectDrawingObjects
        If Not normalProtectionConfirmed Then _
            Err.Raise vbObjectError + 4899, "SetAnalysisReviewEditingEnabled", _
                      ws.Name & "�̃Z���E�}�`�ی��ǖ߂��m�F�ł��܂���B"
    End If
    If workbookWasSaved And normalProtectionConfirmed Then _
        ThisWorkbook.Saved = True
    If Not TryRestoreAnalysisWorkspaceEnableEvents( _
               previousEvents, _
               "SetAnalysisReviewEditingEnabled/����I��", _
               recoveryAttempted, recoveryTerminalFailure, _
               eventStateDetail) Then
        eventsCaptured = False
        If Not TryStopAnalysisWorkspaceEventsForBookWrites(convergenceDetail) Then
            AppendAnalysisWorkspaceRollbackDetail eventStateDetail, _
                "�C�x���g��Ԃ�False�ֈ��S�����ł��܂���: " & convergenceDetail
        Else
            AppendAnalysisWorkspaceRollbackDetail eventStateDetail, _
                "�J�n��Ԃ̕������s��A�C�x���g��Ԃ�False�ֈ��S�������܂����B"
        End If
        On Error GoTo 0
        If recoveryAttempted Or recoveryTerminalFailure Then _
            RaiseAnalysisWorkspaceLocalRecoveryFatal _
                "SetAnalysisReviewEditingEnabled", _
                vbObjectError + 4900, _
                "SetAnalysisReviewEditingEnabled", eventStateDetail, _
                eventStateDetail
        Err.Raise vbObjectError + 4900, "SetAnalysisReviewEditingEnabled", _
                  eventStateDetail
    End If
    eventsCaptured = False
    If recoveryAttempted Or recoveryTerminalFailure Then _
        RaiseAnalysisWorkspaceLocalRecoveryFatal _
            "SetAnalysisReviewEditingEnabled", _
            vbObjectError + 4900, "SetAnalysisReviewEditingEnabled", _
            "�J�n�l�̕�������local Recovery�����s���܂����B", _
            eventStateDetail
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    If IsAnalysisWorkspaceRecoveryFatalError(errorNumber, errorSource) Then _
        RethrowAnalysisWorkspaceUpstreamRecoveryFatal _
            errorNumber, errorSource, errorDescription, _
            "SetAnalysisReviewEditingEnabled"
    If eventsCaptured Then
        eventsStopped = _
            TryStopAnalysisWorkspaceEventsForBookWrites(eventStateDetail)
    Else
        eventsStopped = False
        eventStateDetail = _
            "Excel�C�x���g�̊J�n�l���擾�ł��Ă��Ȃ����߁A�ً}�ĕی���J�n���Ă��܂���B"
    End If
    If eventsStopped And Not ws Is Nothing Then
        On Error Resume Next
        Err.Clear
        EmergencyProtectToolSheet ws
        emergencyErrorNumber = Err.Number
        emergencyErrorDescription = Err.Description
        Err.Clear
        emergencyProtected = ws.ProtectContents And ws.ProtectDrawingObjects
        emergencyReadErrorNumber = Err.Number
        emergencyReadErrorDescription = Err.Description
        Err.Clear
        On Error GoTo 0
        emergencyProtected = emergencyProtected And _
                             (emergencyErrorNumber = 0) And _
                             (emergencyReadErrorNumber = 0)
    ElseIf Not eventsStopped Then
        emergencyProtected = False
        AppendAnalysisWorkspaceRollbackDetail errorDescription, _
            "Excel�C�x���g��~��exact�m�F�ł��Ȃ����߁A�ً}�ĕی�����s���Ă��܂���: " & _
            eventStateDetail
    Else
        emergencyProtected = False
        AppendAnalysisWorkspaceRollbackDetail errorDescription, _
            "�ً}�ĕی삷�镪�̓V�[�g���擾�ł��܂���B"
    End If
    If Not emergencyProtected Then
        If emergencyErrorNumber <> 0 Then _
            AppendAnalysisWorkspaceRollbackDetail errorDescription, _
                "�ً}�ĕی� Err " & CStr(emergencyErrorNumber) & " " & _
                emergencyErrorDescription
        If emergencyReadErrorNumber <> 0 Then _
            AppendAnalysisWorkspaceRollbackDetail errorDescription, _
                "�ی�ǖ߂� Err " & CStr(emergencyReadErrorNumber) & " " & _
                emergencyReadErrorDescription
        If emergencyErrorNumber = 0 And emergencyReadErrorNumber = 0 And _
           eventsStopped And Not ws Is Nothing Then _
            AppendAnalysisWorkspaceRollbackDetail errorDescription, _
                "�ً}�ĕی��̃Z���E�}�`�ی�𗼕�True�Ƃ��Ċm�F�ł��܂���B"
    End If
    If Not emergencyProtected Then
        '�ی�������m�F�ł��Ȃ��ꍇ�́AFalse exact����Recovery���m�肷��B
        'Recovery���m�肵�Ă����̌o�H�ł͊J�n�lTrue�֖߂����A�C�x���g���~�����܂܂ɂ���B
        If eventsStopped Then
            recoveryDetail = errorDescription
            recoveryStateConfirmed = _
                StopAfterAnalysisWorkspaceEventStateFailure( _
                    "SetAnalysisReviewEditingEnabled/�ً}�ĕی�", _
                    recoveryDetail, recoveryAttempted, _
                    recoveryTerminalFailure, errorNumber, errorSource, _
                    errorDescription)
            If recoveryStateConfirmed Then
                AppendAnalysisWorkspaceRollbackDetail recoveryDetail, _
                    "�ً}�ĕی얢�m�F�̂��߁ARecovery�m�����C�x���g���ĊJ���܂���B"
            Else
                AppendAnalysisWorkspaceRollbackDetail recoveryDetail, _
                    "�ً}�ĕی��Recovery�������m�F�ł��Ȃ����߁A�C�x���g���ĊJ���܂���B"
            End If
            AppendAnalysisWorkspaceRollbackDetail errorDescription, recoveryDetail
            If Not TryStopAnalysisWorkspaceEventsForBookWrites( _
                       convergenceDetail) Then
                AppendAnalysisWorkspaceRollbackDetail errorDescription, _
                    "�C�x���g��Ԃ�False�ֈ��S�����ł��܂���: " & _
                    convergenceDetail
            Else
                AppendAnalysisWorkspaceRollbackDetail errorDescription, _
                    "�ً}�ĕی얢�m�F�̂���Excel�C�x���g��False�̂܂ܒ�~���܂����B"
            End If
        End If
        eventsCaptured = False
    Else
        If workbookWasSaved Then
            On Error Resume Next
            Err.Clear
            ThisWorkbook.Saved = True
            savedErrorNumber = Err.Number
            savedErrorDescription = Err.Description
            Err.Clear
            On Error GoTo 0
            If savedErrorNumber <> 0 Then _
                AppendAnalysisWorkspaceRollbackDetail errorDescription, _
                    "�ی쐬����̕ۑ���ԕ��� Err " & CStr(savedErrorNumber) & _
                    " " & savedErrorDescription
        End If
        If eventsCaptured Then
            If Not TryRestoreAnalysisWorkspaceEnableEvents( _
                       previousEvents, _
                       "SetAnalysisReviewEditingEnabled/�ً}�ĕی�", _
                       recoveryAttempted, recoveryTerminalFailure, _
                       eventStateDetail) Then
                AppendAnalysisWorkspaceRollbackDetail errorDescription, _
                    eventStateDetail
                If Not TryStopAnalysisWorkspaceEventsForBookWrites( _
                           convergenceDetail) Then
                    AppendAnalysisWorkspaceRollbackDetail errorDescription, _
                        "�C�x���g��Ԃ�False�ֈ��S�����ł��܂���: " & _
                        convergenceDetail
                Else
                    AppendAnalysisWorkspaceRollbackDetail errorDescription, _
                        "�J�n��Ԃ̕������s��A�C�x���g��Ԃ�False�ֈ��S�������܂����B"
                End If
            End If
            eventsCaptured = False
        End If
    End If
    If recoveryAttempted Or recoveryTerminalFailure Then _
        RaiseAnalysisWorkspaceLocalRecoveryFatal _
            "SetAnalysisReviewEditingEnabled", errorNumber, errorSource, _
            errorDescription, recoveryDetail & " / " & eventStateDetail
    Err.Raise errorNumber, "SetAnalysisReviewEditingEnabled", _
              IIf(Len(errorSource) > 0, _
                  errorSource & " / ", vbNullString) & errorDescription
End Sub

Public Sub RequireAnalysisReviewConstantRange(ByVal target As Range, ByVal labelText As String)
    Dim formulaCell As Range, errorCell As Range
    Dim area As Range, chunk As Range, cell As Range
    Dim rowOffset As Long, chunkRows As Long
    Dim prefixState As Variant, prefixError As Long, scanCells As Boolean
    Const PREFIX_CHECK_ROWS As Long = 500
    If target Is Nothing Then _
        Err.Raise vbObjectError + 4830, "RequireAnalysisReviewConstantRange", _
                  labelText & "���擾�ł��܂���B"
    If Not TryFindFirstFormulaCell(target, formulaCell) Then _
        Err.Raise vbObjectError + 4831, "RequireAnalysisReviewConstantRange", _
                  labelText & "�̐��������Ɏ��s���܂����B"
    If Not formulaCell Is Nothing Then _
        Err.Raise vbObjectError + 4831, "RequireAnalysisReviewConstantRange", _
                  labelText & "�ɐ���������܂�: " & formulaCell.Address(False, False)
    If Not TryFindFirstErrorConstantCell(target, errorCell) Then _
        Err.Raise vbObjectError + 4832, "RequireAnalysisReviewConstantRange", _
                  labelText & "��Excel�G���[�����Ɏ��s���܂����B"
    If Not errorCell Is Nothing Then _
        Err.Raise vbObjectError + 4832, "RequireAnalysisReviewConstantRange", _
                  labelText & "��Excel�G���[������܂�: " & errorCell.Address(False, False)

    For Each area In target.Areas
        rowOffset = 0
        Do While rowOffset < area.Rows.Count
            chunkRows = CLng(Application.Min(PREFIX_CHECK_ROWS, _
                                             area.Rows.Count - rowOffset))
            Set chunk = area.Rows(rowOffset + 1).Resize(chunkRows, area.Columns.Count)
            scanCells = False
            On Error Resume Next
            Err.Clear
            prefixState = chunk.PrefixCharacter
            prefixError = Err.Number
            Err.Clear
            On Error GoTo 0
            If prefixError <> 0 Or IsNull(prefixState) Then
                scanCells = True
            ElseIf Len(CStr(prefixState)) > 0 Then
                scanCells = True
            End If
            If scanCells Then
                On Error GoTo PrefixInspectionError
                For Each cell In chunk.Cells
                    If Len(CStr(cell.PrefixCharacter)) > 0 Then _
                        Err.Raise vbObjectError + 4833, _
                                  "RequireAnalysisReviewConstantRange", _
                                  labelText & "�ɐ擪�A�|�X�g���t�B�t���̒l������܂�: " & _
                                  cell.Address(False, False)
                Next cell
                On Error GoTo 0
            End If
            rowOffset = rowOffset + chunkRows
        Loop
    Next area
    Exit Sub
PrefixInspectionError:
    If Err.Number = vbObjectError + 4833 Then
        Err.Raise Err.Number, "RequireAnalysisReviewConstantRange", Err.Description
    Else
        Err.Raise vbObjectError + 4833, "RequireAnalysisReviewConstantRange", _
                  labelText & "�̐擪�A�|�X�g���t�B�����Ɏ��s���܂����B"
    End If
End Sub

Private Sub CaptureAnalysisSourceReviewSnapshots(ByRef snapshots() As Variant, _
                                                 ByRef lastRows() As Long)
    Dim i As Long, sourceName As String
    Dim ws As Worksheet, lastR As Long
    Dim statusCol As Long, memoCol As Long, keyCol As Long
    Dim reviewRange As Range, validationRange As Range
    For i = 1 To 3
        sourceName = AnalysisSourceNameByIndex(i)
        If Not WorkspaceSourceColumns(sourceName, statusCol, memoCol, keyCol) Then _
            Err.Raise vbObjectError + 4834, "CaptureAnalysisSourceReviewSnapshots", _
                      "���͌��\�̗��`���s���ł�: " & sourceName
        Set ws = GetSheet(sourceName)
        If Not TryGetLastUsedRowInSheet(ws, lastR) Then _
            Err.Raise vbObjectError + 4834, "CaptureAnalysisSourceReviewSnapshots", _
                      sourceName & "�̍ŏI�s���m�F�ł��܂���B"
        If lastR - 1 > MAX_ANALYSIS_OUTPUT_ROWS Then _
            Err.Raise vbObjectError + 4835, "CaptureAnalysisSourceReviewSnapshots", _
                      sourceName & "�̊m�F�L�^�����p����𒴂��Ă��܂��B"
        lastRows(i) = lastR
        snapshots(i) = Empty
        If lastR >= 2 Then
            Set reviewRange = ws.Range(ws.Cells(2, statusCol), _
                                       ws.Cells(lastR, memoCol))
            Set validationRange = Union(reviewRange, _
                ws.Range(ws.Cells(2, keyCol), ws.Cells(lastR, keyCol)))
            RequireAnalysisReviewConstantRange validationRange, _
                sourceName & "�̊m�F���܂��͓����L�["
            snapshots(i) = reviewRange.Value2
            If Not RangeValue2MatchesMatrixStrict( _
                       reviewRange, snapshots(i), lastR - 1, 2) Then _
                Err.Raise vbObjectError + 4836, _
                          "CaptureAnalysisSourceReviewSnapshots", _
                          sourceName & "�̊m�F�L�^���^�܂Ō����ɑޔ��ł��܂���B"
        End If
    Next i
End Sub

Private Function RestoreAnalysisSourceReviewSnapshots( _
        ByRef snapshots() As Variant, ByRef lastRows() As Long, _
        ByRef detailText As String) As Boolean
    Dim i As Long, sourceName As String, oneDetail As String
    Dim allOK As Boolean
    allOK = True
    For i = 1 To 3
        sourceName = AnalysisSourceNameByIndex(i)
        oneDetail = vbNullString
        If Not RestoreOneAnalysisSourceReviewSnapshot( _
                   sourceName, snapshots(i), lastRows(i), oneDetail) Then
            allOK = False
            AppendAnalysisWorkspaceRollbackDetail detailText, oneDetail
        End If
    Next i
    RestoreAnalysisSourceReviewSnapshots = allOK
End Function

Private Function RestoreOneAnalysisSourceReviewSnapshot( _
        ByVal sourceName As String, ByVal snapshot As Variant, _
        ByVal snapshotLastRow As Long, ByRef detailText As String) As Boolean
    Dim ws As Worksheet, currentLastRow As Long
    Dim statusCol As Long, memoCol As Long, keyCol As Long
    Dim target As Range
    On Error GoTo EH
    If Not WorkspaceSourceColumns(sourceName, statusCol, memoCol, keyCol) Then _
        Err.Raise vbObjectError + 4837, "RestoreOneAnalysisSourceReviewSnapshot", _
                  "���͌��\�̗��`���s���ł��B"
    Set ws = GetSheet(sourceName)
    If Not TryGetLastUsedRowInSheet(ws, currentLastRow) Then _
        Err.Raise vbObjectError + 4837, "RestoreOneAnalysisSourceReviewSnapshot", _
                  "�ŏI�s���m�F�ł��܂���B"
    If currentLastRow <> snapshotLastRow Then _
        Err.Raise vbObjectError + 4838, "RestoreOneAnalysisSourceReviewSnapshot", _
                  "�ޔ���ɍs�����ω����Ă��܂��B"
    If snapshotLastRow >= 2 Then
        If Not IsArray(snapshot) Then _
            Err.Raise vbObjectError + 4839, "RestoreOneAnalysisSourceReviewSnapshot", _
                      "�ޔ�z�񂪂���܂���B"
        Set target = ws.Range(ws.Cells(2, statusCol), _
                              ws.Cells(snapshotLastRow, memoCol))
        target.Value2 = snapshot
        If Not RangeValue2MatchesMatrixStrict( _
                   target, snapshot, snapshotLastRow - 1, 2) Then _
            Err.Raise vbObjectError + 4840, "RestoreOneAnalysisSourceReviewSnapshot", _
                      "�����ǖ߂����S�Z���E�^�ň�v���܂���B"
        RequireAnalysisReviewConstantRange target, sourceName & "�̕����m�F��"
    End If
    RestoreOneAnalysisSourceReviewSnapshot = True
    Exit Function
EH:
    detailText = sourceName & "�̕����G���[: " & Err.Description
    Err.Clear
End Function

Private Function AnalysisSourceNameByIndex(ByVal itemIndex As Long) As String
    Select Case itemIndex
        Case 1: AnalysisSourceNameByIndex = SH_ANALYSIS_SHIFT
        Case 2: AnalysisSourceNameByIndex = SH_ANALYSIS_FLOW
        Case 3: AnalysisSourceNameByIndex = SH_ANALYSIS_UNKNOWN
    End Select
End Function

Private Function WriteAnalysisReviewTextCellIfChanged( _
        ByVal target As Range, ByVal textValue As String, _
        ByVal labelText As String) As Boolean
    Dim expectedData As Variant
    ReDim expectedData(1 To 1, 1 To 1)
    If target Is Nothing Then _
        Err.Raise vbObjectError + 4841, "WriteAnalysisReviewTextCellIfChanged", _
                  labelText & "�̏�������擾�ł��܂���B"
    If target.Cells.CountLarge <> 1 Then _
        Err.Raise vbObjectError + 4841, "WriteAnalysisReviewTextCellIfChanged", _
                  labelText & "�̏����悪�P��Z���ł͂���܂���B"
    If Len(textValue) = 0 Then
        expectedData(1, 1) = Empty
    Else
        expectedData(1, 1) = CStr(textValue)
    End If
    If StrictVariantValuesMatch(expectedData(1, 1), target.Value2) And _
       Not target.HasFormula And Len(CStr(target.PrefixCharacter)) = 0 Then Exit Function
    target.NumberFormatLocal = "@"
    target.Value2 = expectedData(1, 1)
    If Not RangeValue2MatchesMatrixStrict(target, expectedData, 1, 1) Then _
        Err.Raise vbObjectError + 4842, "WriteAnalysisReviewTextCellIfChanged", _
                  labelText & "�̏����ǖ߂����^�܂ň�v���܂���B"
    RequireAnalysisReviewConstantRange target, labelText
    WriteAnalysisReviewTextCellIfChanged = True
End Function

Private Sub CaptureAnalysisDetailReviewCellSnapshots( _
        ByVal ws As Worksheet, ByRef statusRows() As Long, ByRef memoRows() As Long, _
        ByVal itemCount As Long, ByRef statusSnapshots() As Variant, _
        ByRef memoSnapshots() As Variant)
    Dim i As Long
    If ws Is Nothing Or itemCount < 1 Then _
        Err.Raise vbObjectError + 4843, "CaptureAnalysisDetailReviewCellSnapshots", _
                  "���ڍׂ̑ޔ��������s���ł��B"
    For i = 1 To itemCount
        statusSnapshots(i) = ws.Cells(statusRows(i), 6).Value2
        memoSnapshots(i) = ws.Cells(memoRows(i), 2).Value2
        If Not StrictVariantValuesMatch( _
                   statusSnapshots(i), ws.Cells(statusRows(i), 6).Value2) Or _
           Not StrictVariantValuesMatch( _
                   memoSnapshots(i), ws.Cells(memoRows(i), 2).Value2) Then _
            Err.Raise vbObjectError + 4844, _
                      "CaptureAnalysisDetailReviewCellSnapshots", _
                      "���ڍׂ̊m�F�L�^���^�܂Ō����ɑޔ��ł��܂���B"
    Next i
End Sub

Private Function RestoreAnalysisDetailReviewCellSnapshots( _
        ByVal ws As Worksheet, ByRef statusRows() As Long, ByRef memoRows() As Long, _
        ByVal itemCount As Long, ByRef statusSnapshots() As Variant, _
        ByRef memoSnapshots() As Variant, ByRef detailText As String) As Boolean
    Dim i As Long, expectedData As Variant
    ReDim expectedData(1 To 1, 1 To 1)
    On Error GoTo EH
    If ws Is Nothing Or itemCount < 1 Then _
        Err.Raise vbObjectError + 4845, "RestoreAnalysisDetailReviewCellSnapshots", _
                  "���ڍׂ̕����������s���ł��B"
    ws.Unprotect Password:=TOOL_PASSWORD
    For i = 1 To itemCount
        expectedData(1, 1) = statusSnapshots(i)
        ws.Cells(statusRows(i), 6).Value2 = expectedData(1, 1)
        If Not RangeValue2MatchesMatrixStrict( _
                   ws.Cells(statusRows(i), 6), expectedData, 1, 1) Then _
            Err.Raise vbObjectError + 4846, _
                      "RestoreAnalysisDetailReviewCellSnapshots", _
                      "���ڍׂ̊m�F�󋵂������ɕ����ł��܂���B"
        expectedData(1, 1) = memoSnapshots(i)
        ws.Cells(memoRows(i), 2).Value2 = expectedData(1, 1)
        If Not RangeValue2MatchesMatrixStrict( _
                   ws.Cells(memoRows(i), 2), expectedData, 1, 1) Then _
            Err.Raise vbObjectError + 4847, _
                      "RestoreAnalysisDetailReviewCellSnapshots", _
                      "���ڍׂ̊m�F�����������ɕ����ł��܂���B"
    Next i
    RestoreAnalysisDetailReviewCellSnapshots = True
    Exit Function
EH:
    AppendAnalysisWorkspaceRollbackDetail detailText, _
        "���ڍׂ̕����G���[: " & Err.Description
    Err.Clear
End Function

Private Sub AppendAnalysisWorkspaceRollbackDetail(ByRef detailText As String, _
                                                  ByVal newDetail As String)
    newDetail = Trim$(newDetail)
    If Len(newDetail) = 0 Then Exit Sub
    If Len(detailText) > 0 Then detailText = detailText & " / "
    detailText = detailText & newDetail
End Sub

Private Function TryGetAnalysisWorkspaceEnableEvents( _
        ByRef currentValue As Boolean, _
        ByRef detailText As String) As Boolean
    Dim errorNumber As Long, errorDescription As String
    detailText = vbNullString
    On Error GoTo EH
    currentValue = Application.EnableEvents
    TryGetAnalysisWorkspaceEnableEvents = True
    Exit Function
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    detailText = "Err " & CStr(errorNumber) & ": " & errorDescription
    Err.Clear
End Function

Private Function TrySetAnalysisWorkspaceEnableEventsExact( _
        ByVal desiredValue As Boolean, _
        ByRef detailText As String) As Boolean
    Dim errorNumber As Long, errorDescription As String
    detailText = vbNullString
    On Error GoTo EH
    Application.EnableEvents = desiredValue
    If Application.EnableEvents <> desiredValue Then
        detailText = "EnableEvents�̏����݌�ǖ߂�����v���܂���B"
        Exit Function
    End If
    TrySetAnalysisWorkspaceEnableEventsExact = True
    Exit Function
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    detailText = "Err " & CStr(errorNumber) & ": " & errorDescription
    Err.Clear
End Function

Private Function TryStopAnalysisWorkspaceEventsForBookWrites( _
        ByRef detailText As String) As Boolean
    Dim firstDetail As String, retryDetail As String
    detailText = vbNullString
    If TrySetAnalysisWorkspaceEnableEventsExact(False, firstDetail) Then
        TryStopAnalysisWorkspaceEventsForBookWrites = True
        Exit Function
    End If
    If TrySetAnalysisWorkspaceEnableEventsExact(False, retryDetail) Then
        TryStopAnalysisWorkspaceEventsForBookWrites = True
        Exit Function
    End If
    detailText = "Excel�C�x���g��False�֒�~���ēǖ߂��m�F�ł��܂���ł����B����=" & _
                 firstDetail & " / �Ď��s=" & retryDetail
End Function

Private Function TryConfirmAnalysisWorkspaceRecoveryState( _
        ByRef detailText As String) As Boolean
    Dim latchIsSet As Boolean, latchReadSucceeded As Boolean
    Dim healthValue As String, healthReadSucceeded As Boolean
    latchReadSucceeded = TryGetRollbackRecoveryLatch(latchIsSet)
    If Not latchReadSucceeded Or Not latchIsSet Then
        AppendAnalysisWorkspaceRollbackDetail detailText, _
            "�Ɨ��������b�`��ݒ�ς݂Ƃ��Ĉ�ӂɊm�F�ł��܂���B"
        Exit Function
    End If
    healthReadSucceeded = TryGetExactStateValue(STATE_DATA_HEALTH, healthValue)
    If Not healthReadSucceeded Then
        AppendAnalysisWorkspaceRollbackDetail detailText, _
            "�Č��v������Ԃ���ӂɊm�F�ł��܂���B"
        Exit Function
    End If
    If StrComp(healthValue, DATA_HEALTH_NEEDS_RECOVERY, _
               vbBinaryCompare) <> 0 Then
        AppendAnalysisWorkspaceRollbackDetail detailText, _
            "�Č��v������Ԃ���ӂɊm�F�ł��܂���B"
        Exit Function
    End If
    TryConfirmAnalysisWorkspaceRecoveryState = True
End Function

Private Function TryConfirmAnalysisWorkspaceApplicationState( _
        ByRef detailText As String) As Boolean
    Dim stateProblems As String
    Dim errorNumber As Long, errorDescription As String
    detailText = vbNullString
    On Error GoTo EH
    If AppStateIsRestored(stateProblems) Then
        TryConfirmAnalysisWorkspaceApplicationState = True
    Else
        detailText = stateProblems
    End If
    Exit Function
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    detailText = "Application��Ԋm�F�G���[: Err " & _
                 CStr(errorNumber) & " " & errorDescription
    Err.Clear
End Function

Private Sub EnforceAnalysisWorkspaceRecoveryStateTerminal( _
        ByVal operationName As String, ByRef detailText As String, _
        ByRef recoveryAttempted As Boolean, _
        ByRef recoveryTerminalFailure As Boolean, _
        ByVal originalErrorNumber As Long, _
        ByVal originalErrorSource As String, _
        ByVal originalErrorDescription As String)
    Dim recoveryErrorNumber As Long, recoveryErrorDescription As String
    Dim recoveryErrorSource As String
    Dim eventsStopped As Boolean, eventStateDetail As String
    Dim recoveryConfirmed As Boolean, applicationStateConfirmed As Boolean
    Dim applicationStateDetail As String
    If recoveryAttempted Or recoveryTerminalFailure Then
        recoveryTerminalFailure = True
        eventsStopped = _
            TryStopAnalysisWorkspaceEventsForBookWrites(eventStateDetail)
        AppendAnalysisWorkspaceRollbackDetail detailText, _
            "Recovery�����ݒ�͂��̑���Ŋ��Ɏ��s�ς݂̂��߁A�Ď��s���܂���B"
        If Not eventsStopped Then _
            AppendAnalysisWorkspaceRollbackDetail detailText, _
                "�Ď��s�}�~���Excel�C�x���gFalse�����ɂ����s���܂���: " & _
                eventStateDetail
        RaiseAnalysisWorkspaceLocalRecoveryFatal _
            operationName, originalErrorNumber, originalErrorSource, _
            originalErrorDescription, detailText
    End If
    If Not TryStopAnalysisWorkspaceEventsForBookWrites(eventStateDetail) Then
        recoveryTerminalFailure = True
        AppendAnalysisWorkspaceRollbackDetail detailText, _
            "Recovery�����ݒ�O��Excel�C�x���g��False�֎����ł��܂���: " & _
            eventStateDetail
        RaiseAnalysisWorkspaceLocalRecoveryFatal _
            operationName, originalErrorNumber, originalErrorSource, _
            originalErrorDescription, detailText
    End If
    recoveryAttempted = True
    On Error Resume Next
    Err.Clear
    EnforceRollbackRecoveryState detailText
    recoveryErrorNumber = Err.Number
    recoveryErrorDescription = Err.Description
    recoveryErrorSource = Err.Source
    Err.Clear
    eventsStopped = _
        TryStopAnalysisWorkspaceEventsForBookWrites(eventStateDetail)
    On Error GoTo 0
    If recoveryErrorNumber <> 0 Then
        recoveryTerminalFailure = True
        AppendAnalysisWorkspaceRollbackDetail detailText, _
            "�v������Ԃ̋����ݒ�G���[: Err " & _
            CStr(recoveryErrorNumber) & " " & recoveryErrorDescription
        If Not eventsStopped Then _
            AppendAnalysisWorkspaceRollbackDetail detailText, _
                "Recovery��O��̃C�x���gFalse�����ɂ����s���܂���: " & _
                eventStateDetail
        RaiseAnalysisWorkspaceLocalRecoveryFatal _
            operationName, originalErrorNumber, originalErrorSource, _
            originalErrorDescription, detailText
    End If
    If Not eventsStopped Then
        recoveryTerminalFailure = True
        AppendAnalysisWorkspaceRollbackDetail detailText, _
            "Recovery�������Excel�C�x���g��False�֎����ł��܂���: " & _
            eventStateDetail
        RaiseAnalysisWorkspaceLocalRecoveryFatal _
            operationName, originalErrorNumber, originalErrorSource, _
            originalErrorDescription, detailText
    End If
    recoveryConfirmed = _
        TryConfirmAnalysisWorkspaceRecoveryState(detailText)
    If Not recoveryConfirmed Then
        recoveryTerminalFailure = True
        RaiseAnalysisWorkspaceLocalRecoveryFatal _
            operationName, originalErrorNumber, originalErrorSource, _
            originalErrorDescription, detailText
    End If
    applicationStateConfirmed = _
        TryConfirmAnalysisWorkspaceApplicationState(applicationStateDetail)
    If Not applicationStateConfirmed Then
        recoveryTerminalFailure = True
        AppendAnalysisWorkspaceRollbackDetail detailText, _
            "Recovery���Application��Ԃ��m�F�ł��܂���: " & _
            applicationStateDetail
        RaiseAnalysisWorkspaceLocalRecoveryFatal _
            operationName, originalErrorNumber, originalErrorSource, _
            originalErrorDescription, detailText
    End If
    If Not TryStopAnalysisWorkspaceEventsForBookWrites(eventStateDetail) Then
        recoveryTerminalFailure = True
        AppendAnalysisWorkspaceRollbackDetail detailText, _
            "Recovery���S�m�F��̍ŏI�C�x���gFalse���m�F�ł��܂���: " & _
            eventStateDetail
        RaiseAnalysisWorkspaceLocalRecoveryFatal _
            operationName, originalErrorNumber, originalErrorSource, _
            originalErrorDescription, detailText
    End If
    AppendAnalysisWorkspaceRollbackDetail detailText, _
        "�����Recovery��d��ԁAApplication��ԁA�ŏI�C�x���gFalse���m�F���܂����B"
    RaiseAnalysisWorkspaceLocalRecoveryFatal _
        operationName, originalErrorNumber, originalErrorSource, _
        originalErrorDescription, detailText
End Sub

Private Function IsAnalysisWorkspaceRecoveryFatalError( _
        ByVal errorNumber As Long, ByVal errorSource As String) As Boolean
    Dim sourcePrefix As String
    Select Case errorNumber
        Case vbObjectError + 3599, vbObjectError + 4499
            IsAnalysisWorkspaceRecoveryFatalError = True
            Exit Function
        Case ANALYSIS_WORKSPACE_RECOVERY_FATAL_ERROR
            sourcePrefix = ANALYSIS_WORKSPACE_RECOVERY_FATAL_SOURCE
        Case vbObjectError + 5192
            sourcePrefix = "SetupConvergeRecoveryFatal/"
        Case vbObjectError + 5194
            sourcePrefix = "CashAnalysisRecoveryFatal/"
        Case vbObjectError + 5195
            sourcePrefix = "TransactionAnalysisRecoveryFatal/"
        Case vbObjectError + 5196
            sourcePrefix = "CashManualSelectionRecoveryFatal/"
        Case vbObjectError + 5197
            sourcePrefix = "ClearRecoveryFatal/"
        Case Else
            Exit Function
    End Select
    IsAnalysisWorkspaceRecoveryFatalError = _
        (Len(errorSource) >= Len(sourcePrefix)) And _
        (StrComp(Left$(errorSource, Len(sourcePrefix)), _
                 sourcePrefix, vbBinaryCompare) = 0)
End Function

Private Sub RethrowAnalysisWorkspaceUpstreamRecoveryFatal( _
        ByVal errorNumber As Long, ByVal errorSource As String, _
        ByVal errorDescription As String, ByVal operationName As String)
    Dim eventStateDetail As String
    Call TryStopAnalysisWorkspaceEventsForBookWrites(eventStateDetail)
    Err.Raise errorNumber, errorSource, errorDescription
End Sub

Private Sub RaiseAnalysisWorkspaceLocalRecoveryFatal( _
        ByVal operationName As String, ByVal originalErrorNumber As Long, _
        ByVal originalErrorSource As String, _
        ByVal originalErrorDescription As String, _
        ByVal recoveryDetail As String)
    Dim eventStateDetail As String, fatalDescription As String
    If Not TryStopAnalysisWorkspaceEventsForBookWrites(eventStateDetail) Then _
        AppendAnalysisWorkspaceRollbackDetail recoveryDetail, _
            "local Recovery���Excel�C�x���gFalse�������m�F�ł��܂���: " & _
            eventStateDetail
    fatalDescription = "���G���[ Err " & CStr(originalErrorNumber)
    If Len(originalErrorSource) > 0 Then _
        fatalDescription = fatalDescription & " / " & originalErrorSource
    If Len(originalErrorDescription) > 0 Then _
        fatalDescription = fatalDescription & ": " & originalErrorDescription
    If Len(recoveryDetail) > 0 Then _
        fatalDescription = fatalDescription & " / Recovery: " & recoveryDetail
    Err.Raise ANALYSIS_WORKSPACE_RECOVERY_FATAL_ERROR, _
              ANALYSIS_WORKSPACE_RECOVERY_FATAL_SOURCE & operationName, _
              fatalDescription
End Sub

Private Function TryRestoreAnalysisWorkspaceEnableEvents( _
        ByVal previousValue As Boolean, _
        ByVal operationName As String, _
        ByRef recoveryAttempted As Boolean, _
        ByRef recoveryTerminalFailure As Boolean, _
        ByRef detailText As String) As Boolean
    Dim firstDetail As String, retryDetail As String
    Dim safeStopDetail As String
    Dim recoveryStateConfirmed As Boolean, applicationStateConfirmed As Boolean
    Dim applicationStateDetail As String
    detailText = vbNullString
    If recoveryAttempted Or recoveryTerminalFailure Then
        recoveryTerminalFailure = True
        If TryStopAnalysisWorkspaceEventsForBookWrites(safeStopDetail) Then
            detailText = "Recovery�I�[��̂��ߊJ�n�l�֖߂����A" & _
                         "Excel�C�x���g��False�Œ�~���܂����B"
        Else
            detailText = "Recovery�I�[���Excel�C�x���gFalse�����ɂ����s���܂���: " & _
                         safeStopDetail
        End If
        RaiseAnalysisWorkspaceLocalRecoveryFatal _
            operationName, ANALYSIS_WORKSPACE_RECOVERY_FATAL_ERROR, _
            ANALYSIS_WORKSPACE_RECOVERY_FATAL_SOURCE & operationName, _
            "Recovery�I�[��ɃC�x���g�J�n�l�����֍Đi�����܂����B", _
            detailText
    End If
    If previousValue Then
        If Not TryStopAnalysisWorkspaceEventsForBookWrites(safeStopDetail) Then
            detailText = "�J�n�lTrue�̕����O��Excel�C�x���gFalse���m�F�ł��܂���: " & _
                         safeStopDetail
            Exit Function
        End If
        applicationStateConfirmed = _
            TryConfirmAnalysisWorkspaceApplicationState(applicationStateDetail)
        If Not applicationStateConfirmed Then
            detailText = _
                "Application��Ԃ����S�Ɋm�F�ł��Ȃ����ߊJ�n�lTrue�֖߂��܂���: " & _
                applicationStateDetail
            recoveryStateConfirmed = _
                StopAfterAnalysisWorkspaceEventStateFailure( _
                    operationName & "/Application��Ԗ�����", detailText, _
                    recoveryAttempted, recoveryTerminalFailure, 0, _
                    operationName, detailText)
            If recoveryStateConfirmed Then _
                AppendAnalysisWorkspaceRollbackDetail detailText, _
                    "local Recovery�����S�m�F���܂������A�J�n�l�֖߂���" & _
                    "Recovery fatal�Ƃ��ē`�d���܂��B"
            Exit Function
        End If
        If Not TryStopAnalysisWorkspaceEventsForBookWrites(safeStopDetail) Then
            detailText = _
                "Application��Ԋm�F��A�J�n�lTrue�̕������O��" & _
                "Excel�C�x���gFalse���m�F�ł��܂���: " & safeStopDetail
            Exit Function
        End If
    End If
    If TrySetAnalysisWorkspaceEnableEventsExact(previousValue, firstDetail) Then
        TryRestoreAnalysisWorkspaceEnableEvents = True
        Exit Function
    End If
    '�ꎞ�I��COM���s�����𓯂��J�n�l�ւ̍Ď��s�ŋz�����A�e���s�œǖ߂��܂Ŋm�F����B
    If TrySetAnalysisWorkspaceEnableEventsExact(previousValue, retryDetail) Then
        TryRestoreAnalysisWorkspaceEnableEvents = True
        Exit Function
    End If
    detailText = "Excel�C�x���g��Ԃ��J�n�l�֕����ł��܂���ł����B����=" & _
                 firstDetail & " / �Ď��s=" & retryDetail
    recoveryStateConfirmed = _
        StopAfterAnalysisWorkspaceEventStateFailure( _
            operationName, detailText, recoveryAttempted, _
            recoveryTerminalFailure, 0, operationName, detailText)
End Function

Private Function StopAfterAnalysisWorkspaceEventStateFailure( _
        ByVal operationName As String, _
        ByRef detailText As String, _
        ByRef recoveryAttempted As Boolean, _
        ByRef recoveryTerminalFailure As Boolean, _
        ByVal originalErrorNumber As Long, _
        ByVal originalErrorSource As String, _
        ByVal originalErrorDescription As String) As Boolean
    Dim recoveryDetail As String, stopDetail As String
    recoveryDetail = operationName & ": " & detailText
    If Not TryStopAnalysisWorkspaceEventsForBookWrites(stopDetail) Then
        AppendAnalysisWorkspaceRollbackDetail recoveryDetail, _
            "�C�x���g��~���m�F�̂��߁A�u�b�N�ւ�Recovery�E�f�f�E��ԕ\���̏����݂�������܂���: " & _
            stopDetail
        AppendAnalysisWorkspaceRollbackDetail recoveryDetail, _
            "Excel�C�x���g��ԂƈČ��̈��S��Ԃ͕s���ł��B"
        detailText = recoveryDetail
        On Error Resume Next
        MsgBox "Excel�C�x���g�����S�ɒ�~�ł����A�u�b�N�ւ̕����L�^��������܂����B" & _
               vbCrLf & "Excel�C�x���g��ԂƈČ��̈��S��Ԃ͕s���ł��B" & _
               vbCrLf & "���݂̃u�b�N���㏑�����Ȃ��ł��������B", _
               vbCritical, "Excel�C�x���g��Ԃ��m�F�ł��܂���"
        On Error GoTo 0
        Exit Function
    End If
    If recoveryAttempted Or recoveryTerminalFailure Then
        recoveryTerminalFailure = True
        AppendAnalysisWorkspaceRollbackDetail recoveryDetail, _
            "Recovery�����ݒ�͂��̑���Ŋ��Ɏ��s�ς݂̂��߁A�Ď��s�����C�x���g���~���܂��B"
        detailText = recoveryDetail
        RaiseAnalysisWorkspaceLocalRecoveryFatal _
            operationName, originalErrorNumber, originalErrorSource, _
            originalErrorDescription, recoveryDetail
    End If
    AppendAnalysisWorkspaceRollbackDetail recoveryDetail, _
        "�v�����L�^�O��Excel�C�x���g��~��ǖ߂��m�F���܂����B"
    EnforceAnalysisWorkspaceRecoveryStateTerminal _
        operationName, recoveryDetail, recoveryAttempted, _
        recoveryTerminalFailure, originalErrorNumber, _
        originalErrorSource, originalErrorDescription
End Function

Public Sub SyncAnalysisWorkspaceReviewsToSources()
    Dim wsResult As Worksheet, lastR As Long, resultData As Variant
    Dim checkRange As Range
    Dim r As Long, statusCol As Long, memoCol As Long, keyCol As Long
    Dim sourceSheet As String
    Dim sourceSnapshots() As Variant, sourceLastRows() As Long
    Dim snapshotsCaptured As Boolean, writeStarted As Boolean, rollbackOK As Boolean
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim rollbackDetail As String
    Dim recoveryAttempted As Boolean, recoveryTerminalFailure As Boolean
    If Not SheetExists(SH_ANALYSIS_RESULT) Then Exit Sub
    Set wsResult = GetSheet(SH_ANALYSIS_RESULT)
    If Not TryGetLastUsedRowInSheet(wsResult, lastR) Then _
        Err.Raise vbObjectError + 4803, "SyncAnalysisWorkspaceReviewsToSources", _
                  "���͌��ʂ̍ŏI�s���m�F�ł��܂���B"
    If lastR < 2 Then Exit Sub
    Set checkRange = Union( _
        wsResult.Range(wsResult.Cells(2, 2), wsResult.Cells(lastR, 2)), _
        wsResult.Range(wsResult.Cells(2, ANALYSIS_RESULT_STATUS_COL), _
                       wsResult.Cells(lastR, ANALYSIS_RESULT_MEMO_COL)), _
        wsResult.Range(wsResult.Cells(2, ANALYSIS_RESULT_SOURCE_SHEET_COL), _
                       wsResult.Cells(lastR, ANALYSIS_RESULT_ALTERNATIVE_COUNT_COL)))
    RequireAnalysisReviewConstantRange checkRange, "���͌��ʂ̊m�F���܂��͓����Q��"
    resultData = wsResult.Range(wsResult.Cells(2, 1), _
                                wsResult.Cells(lastR, ANALYSIS_RESULT_LAST_COL)).Value2
    For r = 1 To lastR - 1
        sourceSheet = CellText(resultData(r, ANALYSIS_RESULT_SOURCE_SHEET_COL))
        If Not WorkspaceSourceColumns(sourceSheet, statusCol, memoCol, keyCol) Then _
            Err.Raise vbObjectError + 4805, "SyncAnalysisWorkspaceReviewsToSources", _
                      "���͌��� " & CStr(r + 1) & "�s�ڂ̓������\���s���ł��B"
    Next r
    ReDim sourceSnapshots(1 To 3)
    ReDim sourceLastRows(1 To 3)
    CaptureAnalysisSourceReviewSnapshots sourceSnapshots, sourceLastRows
    snapshotsCaptured = True
    On Error GoTo EH
    writeStarted = True
    SyncWorkspaceSourceReviews resultData, lastR - 1, SH_ANALYSIS_SHIFT
    SyncWorkspaceSourceReviews resultData, lastR - 1, SH_ANALYSIS_FLOW
    SyncWorkspaceSourceReviews resultData, lastR - 1, SH_ANALYSIS_UNKNOWN
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    If IsAnalysisWorkspaceRecoveryFatalError(errorNumber, errorSource) Then _
        RethrowAnalysisWorkspaceUpstreamRecoveryFatal _
            errorNumber, errorSource, errorDescription, _
            "SyncAnalysisWorkspaceReviewsToSources"
    If writeStarted And snapshotsCaptured Then
        rollbackOK = RestoreAnalysisSourceReviewSnapshots( _
                         sourceSnapshots, sourceLastRows, rollbackDetail)
        If Not rollbackOK Then
            EnforceAnalysisWorkspaceRecoveryStateTerminal _
                "SyncAnalysisWorkspaceReviewsToSources", _
                rollbackDetail, recoveryAttempted, _
                recoveryTerminalFailure, errorNumber, errorSource, _
                errorDescription
        End If
    End If
    If Len(rollbackDetail) > 0 Then _
        errorDescription = errorDescription & " / ���[���o�b�N�m�F: " & rollbackDetail
    Err.Raise errorNumber, "SyncAnalysisWorkspaceReviewsToSources", errorDescription
End Sub

Public Sub SyncAnalysisDetailReviewsToSources()
    Dim wsDetail As Worksheet, wsSource As Worksheet
    Dim lastR As Long, sourceLastR As Long, r As Long, sourceRow As Long
    Dim sourceSheet As String, sourceKey As String, actualKey As String
    Dim statusText As String, memoText As String, categoryText As String
    Dim statusCol As Long, memoCol As Long, keyCol As Long
    Dim checkRange As Range, seenTargets As Object, targetID As String
    Dim planSheets() As String, planRows() As Long
    Dim planStatuses() As String, planMemos() As String, planCount As Long
    Dim sourceSnapshots() As Variant, sourceLastRows() As Long
    Dim snapshotsCaptured As Boolean, writeStarted As Boolean, rollbackOK As Boolean
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim rollbackDetail As String
    Dim recoveryAttempted As Boolean, recoveryTerminalFailure As Boolean
    If Not SheetExists(SH_ANALYSIS_DETAIL) Then Exit Sub
    Set wsDetail = GetSheet(SH_ANALYSIS_DETAIL)
    If Not TryGetLastUsedRowInSheet(wsDetail, lastR) Then _
        Err.Raise vbObjectError + 4810, "SyncAnalysisDetailReviewsToSources", _
                  "���ڍׂ̍ŏI�s���m�F�ł��܂���B"
    If lastR < 2 Then Exit Sub
    Set checkRange = Union( _
        wsDetail.Range(wsDetail.Cells(2, 1), wsDetail.Cells(lastR, 2)), _
        wsDetail.Range(wsDetail.Cells(2, 6), wsDetail.Cells(lastR, 6)), _
        wsDetail.Range(wsDetail.Cells(2, DETAIL_COL_KIND), _
                       wsDetail.Cells(lastR, DETAIL_COL_SOURCE_KEY)))
    RequireAnalysisReviewConstantRange checkRange, "���ڍׂ̊m�F���܂��͓����Q��"
    ReDim sourceSnapshots(1 To 3)
    ReDim sourceLastRows(1 To 3)
    CaptureAnalysisSourceReviewSnapshots sourceSnapshots, sourceLastRows
    snapshotsCaptured = True
    ReDim planSheets(1 To lastR - 1)
    ReDim planRows(1 To lastR - 1)
    ReDim planStatuses(1 To lastR - 1)
    ReDim planMemos(1 To lastR - 1)
    Set seenTargets = CreateObject("Scripting.Dictionary")
    seenTargets.CompareMode = vbTextCompare
    On Error GoTo EH
    For r = 2 To lastR
        If CellText(wsDetail.Cells(r, DETAIL_COL_KIND).Value) = "���" Then
            sourceSheet = CellText(wsDetail.Cells(r, DETAIL_COL_REFERENCE).Value)
            sourceRow = WorkspaceLong(wsDetail.Cells(r, DETAIL_COL_SOURCE_ROW).Value)
            sourceKey = CellText(wsDetail.Cells(r, DETAIL_COL_SOURCE_KEY).Value)
            If Not WorkspaceSourceColumns(sourceSheet, statusCol, memoCol, keyCol) Then _
                Err.Raise vbObjectError + 4812, "SyncAnalysisDetailReviewsToSources", _
                          "���ڍ� " & CStr(r) & "�s�ڂ̓������\���s���ł��B"
            Set wsSource = GetSheet(sourceSheet)
            If Not TryGetLastUsedRowInSheet(wsSource, sourceLastR) Then _
                Err.Raise vbObjectError + 4813, "SyncAnalysisDetailReviewsToSources", _
                          "���ڍ� " & CStr(r) & "�s�ڂ̓������\���m�F�ł��܂���B"
            If sourceRow < 2 Or sourceRow > sourceLastR Then _
                Err.Raise vbObjectError + 4813, "SyncAnalysisDetailReviewsToSources", _
                          "���ڍ� " & CStr(r) & "�s�ڂ̓������s��������܂���B"
            actualKey = CellText(wsSource.Cells(sourceRow, keyCol).Value)
            If Len(sourceKey) = 0 Or StrComp(actualKey, sourceKey, vbBinaryCompare) <> 0 Then _
                Err.Raise vbObjectError + 4814, "SyncAnalysisDetailReviewsToSources", _
                          "���ڍ� " & CStr(r) & "�s�ڂƓ��������̊m�F�L�[����v���܂���B"
            statusText = WorkspaceStatusOrDefault(wsDetail.Cells(r, 6).Value)
            categoryText = CellText(wsDetail.Cells(r, 1).Value)
            If Not WorkspaceStatusFitsSource(sourceSheet, categoryText, statusText) Then _
                Err.Raise vbObjectError + 4815, "SyncAnalysisDetailReviewsToSources", _
                          "���ڍ� " & CStr(r) & "�s�ڂ̊m�F�󋵂��敪�ɓK�����܂���B"
            If r + 1 > lastR Or _
               CellText(wsDetail.Cells(r + 1, DETAIL_COL_KIND).Value) <> "��⃁��" Then _
                Err.Raise vbObjectError + 4816, "SyncAnalysisDetailReviewsToSources", _
                          "���ڍ� " & CStr(r) & "�s�ڂ̌ʃ�����������܂���B"
            If StrComp(CellText(wsDetail.Cells(r + 1, DETAIL_COL_REFERENCE).Value2), _
                       sourceSheet, vbBinaryCompare) <> 0 Or _
               WorkspaceLong(wsDetail.Cells(r + 1, DETAIL_COL_SOURCE_ROW).Value2) <> _
                   sourceRow Or _
               StrComp(CellText(wsDetail.Cells(r + 1, DETAIL_COL_SOURCE_KEY).Value2), _
                       sourceKey, vbBinaryCompare) <> 0 Then _
                Err.Raise vbObjectError + 4816, "SyncAnalysisDetailReviewsToSources", _
                          "���ڍ� " & CStr(r) & "�s�ڂ̌ʃ����Q�Ƃ���v���܂���B"
            memoText = CellText(wsDetail.Cells(r + 1, 2).Value)
            If Len(memoText) > WORKSPACE_MEMO_MAX Then _
                Err.Raise vbObjectError + 4817, "SyncAnalysisDetailReviewsToSources", _
                          "���ڍ� " & CStr(r + 1) & "�s�ڂ̊m�F�������������܂��B"
            targetID = sourceSheet & "|" & CStr(sourceRow)
            If seenTargets.Exists(targetID) Then _
                Err.Raise vbObjectError + 4818, "SyncAnalysisDetailReviewsToSources", _
                          "���ڍׂɓ���������₪�d�����Ă��܂�: " & targetID
            seenTargets.Add targetID, True
            planCount = planCount + 1
            planSheets(planCount) = sourceSheet
            planRows(planCount) = sourceRow
            planStatuses(planCount) = statusText
            planMemos(planCount) = memoText
        End If
    Next r
    If planCount > 0 Then
        writeStarted = True
        For r = 1 To planCount
            If Not WorkspaceSourceColumns(planSheets(r), statusCol, memoCol, keyCol) Then _
                Err.Raise vbObjectError + 4812, "SyncAnalysisDetailReviewsToSources", _
                          "���ڍׂ̓������\���������O�ɕs���ɂȂ�܂����B"
            Set wsSource = GetSheet(planSheets(r))
            WriteAnalysisReviewTextCellIfChanged wsSource.Cells(planRows(r), statusCol), _
                planStatuses(r), "���ڍׂ̊m�F��"
            WriteAnalysisReviewTextCellIfChanged wsSource.Cells(planRows(r), memoCol), _
                planMemos(r), "���ڍׂ̊m�F����"
        Next r
    End If
    mAnalysisDetailReviewsDirty = False
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    If IsAnalysisWorkspaceRecoveryFatalError(errorNumber, errorSource) Then _
        RethrowAnalysisWorkspaceUpstreamRecoveryFatal _
            errorNumber, errorSource, errorDescription, _
            "SyncAnalysisDetailReviewsToSources"
    If writeStarted And snapshotsCaptured Then
        rollbackOK = RestoreAnalysisSourceReviewSnapshots( _
                         sourceSnapshots, sourceLastRows, rollbackDetail)
        If Not rollbackOK Then
            EnforceAnalysisWorkspaceRecoveryStateTerminal _
                "SyncAnalysisDetailReviewsToSources", _
                rollbackDetail, recoveryAttempted, _
                recoveryTerminalFailure, errorNumber, errorSource, _
                errorDescription
        End If
    End If
    If Len(rollbackDetail) > 0 Then _
        errorDescription = errorDescription & " / ���[���o�b�N�m�F: " & rollbackDetail
    Err.Raise errorNumber, "SyncAnalysisDetailReviewsToSources", errorDescription
End Sub

Public Function SyncCashAnalysisReviewToSourceAndDetailSnapshot( _
        ByVal sourceSheet As String, ByVal sourceRow As Long, _
        ByVal sourceKey As String, ByVal categoryText As String, _
        ByVal statusText As String, ByVal memoText As String) As Boolean
    '��������\�̕��̓p�l�����ŏI���͖ʂƂ��Ĉ����B���\�����łȂ��A��Commit����
    '�㏟����������ڍׂ̕\���X�i�b�v�V���b�g�������ɓ����l�ւ��낦��B
    Dim wsSource As Worksheet, wsDetail As Worksheet
    Dim statusCol As Long, memoCol As Long, keyCol As Long
    Dim lastR As Long, sourceLastR As Long, r As Long
    Dim detailData As Variant
    Dim detailChanged As Boolean, detailUnprotected As Boolean
    Dim changed As Boolean
    Dim detailStatusRows() As Long, detailMemoRows() As Long, detailCount As Long
    Dim detailStatusSnapshots() As Variant, detailMemoSnapshots() As Variant
    Dim sourceSnapshots() As Variant, sourceLastRows() As Long
    Dim sourceSnapshotsCaptured As Boolean, detailSnapshotsCaptured As Boolean
    Dim writeStarted As Boolean, sourceRollbackOK As Boolean, detailRollbackOK As Boolean
    Dim protectRollbackOK As Boolean, checkRange As Range
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim protectErrorNumber As Long, protectErrorDescription As String
    Dim protectErrorSource As String
    Dim rollbackDetail As String
    Dim recoveryAttempted As Boolean, recoveryTerminalFailure As Boolean

    On Error GoTo EH
    statusText = WorkspaceStatusOrDefault(statusText)
    If Not WorkspaceSourceColumns(sourceSheet, statusCol, memoCol, keyCol) Then _
        Err.Raise vbObjectError + 4824, "SyncCashAnalysisReviewToSourceAndDetailSnapshot", _
                  "��������\�̌�₪�Q�Ƃ���������\���s���ł��B"
    Set wsSource = GetSheet(sourceSheet)
    If Not TryGetLastUsedRowInSheet(wsSource, sourceLastR) Then _
        Err.Raise vbObjectError + 4825, "SyncCashAnalysisReviewToSourceAndDetailSnapshot", _
                  "��������\�̌�₪�Q�Ƃ���������\���m�F�ł��܂���B"
    If sourceRow < 2 Or sourceRow > sourceLastR Then _
        Err.Raise vbObjectError + 4825, "SyncCashAnalysisReviewToSourceAndDetailSnapshot", _
                  "��������\�̌�₪�Q�Ƃ���������s��������܂���B"
    If Len(sourceKey) = 0 Or _
       StrComp(CellText(wsSource.Cells(sourceRow, keyCol).Value), _
               sourceKey, vbBinaryCompare) <> 0 Then _
        Err.Raise vbObjectError + 4826, "SyncCashAnalysisReviewToSourceAndDetailSnapshot", _
                  "��������\�̌��Ɠ��������̊m�F�L�[����v���܂���B"
    If Not WorkspaceStatusFitsSource(sourceSheet, categoryText, statusText) Then _
        Err.Raise vbObjectError + 4827, "SyncCashAnalysisReviewToSourceAndDetailSnapshot", _
                  "��������\�̊m�F�󋵂����敪�ɓK�����܂���B"
    If Len(memoText) > WORKSPACE_MEMO_MAX Then _
        Err.Raise vbObjectError + 4828, "SyncCashAnalysisReviewToSourceAndDetailSnapshot", _
                  "��������\�̊m�F�������������܂��B"

    If SheetExists(SH_ANALYSIS_DETAIL) Then
        Set wsDetail = GetSheet(SH_ANALYSIS_DETAIL)
        If Not TryGetLastUsedRowInSheet(wsDetail, lastR) Then _
            Err.Raise vbObjectError + 4829, _
                      "SyncCashAnalysisReviewToSourceAndDetailSnapshot", _
                      "���ڍׂ̍ŏI�s���m�F�ł��܂���B"
        If lastR >= 2 Then
            Set checkRange = Union( _
                wsDetail.Range(wsDetail.Cells(2, 2), wsDetail.Cells(lastR, 2)), _
                wsDetail.Range(wsDetail.Cells(2, 6), wsDetail.Cells(lastR, 6)), _
                wsDetail.Range(wsDetail.Cells(2, DETAIL_COL_KIND), _
                               wsDetail.Cells(lastR, DETAIL_COL_SOURCE_KEY)))
            RequireAnalysisReviewConstantRange checkRange, _
                "���ڍׂ̊m�F���܂��͓����Q��"
            detailData = wsDetail.Range(wsDetail.Cells(2, DETAIL_COL_KIND), _
                                        wsDetail.Cells(lastR, DETAIL_COL_SOURCE_KEY)).Value2
            ReDim detailStatusRows(1 To UBound(detailData, 1))
            ReDim detailMemoRows(1 To UBound(detailData, 1))
            For r = 1 To UBound(detailData, 1)
                If CellText(detailData(r, 1)) = "���" And _
                   StrComp(CellText(detailData(r, DETAIL_COL_REFERENCE - DETAIL_COL_KIND + 1)), _
                           sourceSheet, vbBinaryCompare) = 0 And _
                   WorkspaceLong(detailData(r, DETAIL_COL_SOURCE_ROW - DETAIL_COL_KIND + 1)) = sourceRow And _
                   StrComp(CellText(detailData(r, DETAIL_COL_SOURCE_KEY - DETAIL_COL_KIND + 1)), _
                           sourceKey, vbBinaryCompare) = 0 Then
                    If r + 1 > UBound(detailData, 1) Then _
                        Err.Raise vbObjectError + 4829, _
                                  "SyncCashAnalysisReviewToSourceAndDetailSnapshot", _
                                  "��������\�̌��ɑΉ�������ڍ׃�����������܂���B"
                    If CellText(detailData(r + 1, 1)) <> "��⃁��" Or _
                       StrComp(CellText(detailData(r + 1, DETAIL_COL_REFERENCE - DETAIL_COL_KIND + 1)), _
                               sourceSheet, vbBinaryCompare) <> 0 Or _
                       WorkspaceLong(detailData(r + 1, DETAIL_COL_SOURCE_ROW - DETAIL_COL_KIND + 1)) <> sourceRow Or _
                       StrComp(CellText(detailData(r + 1, DETAIL_COL_SOURCE_KEY - DETAIL_COL_KIND + 1)), _
                               sourceKey, vbBinaryCompare) <> 0 Then _
                        Err.Raise vbObjectError + 4829, _
                                  "SyncCashAnalysisReviewToSourceAndDetailSnapshot", _
                                  "��������\�̌��ɑΉ�������ڍ׃��������s���ł��B"
                    detailCount = detailCount + 1
                    detailStatusRows(detailCount) = r + 1
                    detailMemoRows(detailCount) = r + 2
                End If
            Next r
        End If
    End If

    ReDim sourceSnapshots(1 To 3)
    ReDim sourceLastRows(1 To 3)
    CaptureAnalysisSourceReviewSnapshots sourceSnapshots, sourceLastRows
    sourceSnapshotsCaptured = True
    If detailCount > 0 Then
        ReDim detailStatusSnapshots(1 To detailCount)
        ReDim detailMemoSnapshots(1 To detailCount)
        CaptureAnalysisDetailReviewCellSnapshots wsDetail, detailStatusRows, _
            detailMemoRows, detailCount, detailStatusSnapshots, detailMemoSnapshots
        detailSnapshotsCaptured = True
    End If

    writeStarted = True
    changed = WriteAnalysisReviewTextCellIfChanged( _
                  wsSource.Cells(sourceRow, statusCol), statusText, _
                  "��������\�̊m�F��")
    If WriteAnalysisReviewTextCellIfChanged( _
           wsSource.Cells(sourceRow, memoCol), memoText, _
           "��������\�̊m�F����") Then changed = True
    If detailCount > 0 Then
        wsDetail.Unprotect Password:=TOOL_PASSWORD
        detailUnprotected = True
        For r = 1 To detailCount
            If WriteAnalysisReviewTextCellIfChanged( _
                   wsDetail.Cells(detailStatusRows(r), 6), statusText, _
                   "���ڍׂ̊m�F��") Then detailChanged = True
            If WriteAnalysisReviewTextCellIfChanged( _
                   wsDetail.Cells(detailMemoRows(r), 2), memoText, _
                   "���ڍׂ̊m�F����") Then detailChanged = True
        Next r
        ProtectSingleAnalysisSheet wsDetail
        detailUnprotected = False
    End If
    SyncCashAnalysisReviewToSourceAndDetailSnapshot = (changed Or detailChanged)
    Exit Function
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    If IsAnalysisWorkspaceRecoveryFatalError(errorNumber, errorSource) Then _
        RethrowAnalysisWorkspaceUpstreamRecoveryFatal _
            errorNumber, errorSource, errorDescription, _
            "SyncCashAnalysisReviewToSourceAndDetailSnapshot"
    If writeStarted Then
        If sourceSnapshotsCaptured Then
            sourceRollbackOK = RestoreAnalysisSourceReviewSnapshots( _
                                   sourceSnapshots, sourceLastRows, rollbackDetail)
        Else
            sourceRollbackOK = False
            AppendAnalysisWorkspaceRollbackDetail rollbackDetail, _
                "���͌��\�̑ޔ�������܂���B"
        End If
        detailRollbackOK = True
        If detailSnapshotsCaptured Then _
            detailRollbackOK = RestoreAnalysisDetailReviewCellSnapshots( _
                                   wsDetail, detailStatusRows, detailMemoRows, detailCount, _
                                   detailStatusSnapshots, detailMemoSnapshots, rollbackDetail)
        protectRollbackOK = True
        If Not wsDetail Is Nothing Then
            On Error Resume Next
            Err.Clear
            ProtectSingleAnalysisSheet wsDetail
            protectErrorNumber = Err.Number
            protectErrorDescription = Err.Description
            protectErrorSource = Err.Source
            Err.Clear
            On Error GoTo 0
            If IsAnalysisWorkspaceRecoveryFatalError( _
                   protectErrorNumber, protectErrorSource) Then _
                RethrowAnalysisWorkspaceUpstreamRecoveryFatal _
                    protectErrorNumber, protectErrorSource, _
                    protectErrorDescription, _
                    "SyncCashAnalysisReviewToSourceAndDetailSnapshot/�ُ�I���ĕی�"
            If protectErrorNumber <> 0 Then
                protectRollbackOK = False
                AppendAnalysisWorkspaceRollbackDetail rollbackDetail, _
                    "���ڍׂ̍ĕی�G���[: " & protectErrorDescription
            End If
        End If
        If Not sourceRollbackOK Or Not detailRollbackOK Or Not protectRollbackOK Then
            EnforceAnalysisWorkspaceRecoveryStateTerminal _
                "SyncCashAnalysisReviewToSourceAndDetailSnapshot", _
                rollbackDetail, recoveryAttempted, _
                recoveryTerminalFailure, errorNumber, errorSource, _
                errorDescription
        End If
    ElseIf detailUnprotected And Not wsDetail Is Nothing Then
        On Error Resume Next
        Err.Clear
        ProtectSingleAnalysisSheet wsDetail
        protectErrorNumber = Err.Number
        protectErrorDescription = Err.Description
        protectErrorSource = Err.Source
        Err.Clear
        On Error GoTo 0
        If IsAnalysisWorkspaceRecoveryFatalError( _
               protectErrorNumber, protectErrorSource) Then _
            RethrowAnalysisWorkspaceUpstreamRecoveryFatal _
                protectErrorNumber, protectErrorSource, _
                protectErrorDescription, _
                "SyncCashAnalysisReviewToSourceAndDetailSnapshot/�ُ�I���ĕی�"
    End If
    If Len(rollbackDetail) > 0 Then _
        errorDescription = errorDescription & " / ���[���o�b�N�m�F: " & rollbackDetail
    Err.Raise errorNumber, "SyncCashAnalysisReviewToSourceAndDetailSnapshot", errorDescription
End Function

Public Sub CommitAnalysisDetailReviews()
    CommitPendingAnalysisReviews False, "���ڍׂ̌ʊm�F��ۑ�"
End Sub

Public Function HasPendingAnalysisReviewChanges() As Boolean
    If AnalysisReviewsAreDirty() Or mAnalysisDetailReviewsDirty Then
        HasPendingAnalysisReviewChanges = True
    ElseIf AnalysisWorkspaceReviewsDifferFromSources() Then
        HasPendingAnalysisReviewChanges = True
    ElseIf AnalysisDetailReviewsDifferFromSources() Then
        HasPendingAnalysisReviewChanges = True
    End If
End Function

Public Sub CommitPendingAnalysisReviews( _
        Optional ByVal rebuildWorkspace As Boolean = False, _
        Optional ByVal reasonText As String = "���͔��f��ۑ�", _
        Optional ByVal capacityConfirmed As Boolean = False, _
        Optional ByRef confirmedAnalysisWorkloadRows As Double = 0#, _
        Optional ByVal allowLateCapacityPrompt As Boolean = True, _
        Optional ByVal additionalSnapshotCellWork As Double = 0#)
    Dim previousEvents As Boolean, eventsCaptured As Boolean
    Dim eventsReadyForRecovery As Boolean
    Dim eventStateDetail As String
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim dirtyErrorNumber As Long, dirtyErrorDescription As String
    Dim sourceSnapshots() As Variant, sourceLastRows() As Long
    Dim manualSnapshot As Variant, manualSnapshotLastRow As Long
    Dim allocationSnapshot As Variant, allocationSnapshotLastRow As Long
    Dim allocationSnapshotDigest As String
    Dim sourceSnapshotsCaptured As Boolean, manualSnapshotCaptured As Boolean
    Dim allocationSnapshotCaptured As Boolean
    Dim writeStarted As Boolean, persistenceCommitted As Boolean
    Dim sourceRollbackOK As Boolean, manualRollbackOK As Boolean
    Dim allocationRollbackOK As Boolean
    Dim rollbackSafe As Boolean, safeToRestoreEntry As Boolean
    Dim rollbackDetail As String, rollbackErrorNumber As Long
    Dim rollbackErrorDescription As String
    Dim recoveryAttempted As Boolean, recoveryTerminalFailure As Boolean
    Dim fatalContainmentRequired As Boolean
    Dim capacityShiftCount As Long, capacityFlowCount As Long, capacityUnknownCount As Long
    Dim capacityCandidateCount As Long, capacityResultCount As Long
    Dim allocationSnapshotCellWork As Double
    Dim effectiveAdditionalSnapshotCellWork As Double
    '�ۑ��C�x���g�̂��тɑ�K�͂Ȕ�r�E�e�ʊm�F���s��Ȃ��B�ҏW�C�x���g�͕K��
    '�i��dirty��Ԃ𗧂āA�ǎ�s�\����AnalysisReviewsAreDirty�����S����True��Ԃ��B
    If Not AnalysisReviewsAreDirty() And Not mAnalysisDetailReviewsDirty Then Exit Sub
    'dirty�������Ă��Ă��A�č\�z�Ȃǂŕ\���Ɛ��{�����Ɉ�v���Ă���Ώ����ݕs�v�B
    If Not HasPendingAnalysisReviewChanges() Then Exit Sub
    If ThisWorkbook.ReadOnly Then _
        Err.Raise vbObjectError + 4820, "CommitPendingAnalysisReviews", _
                  "�ǂݎ���p�̂��߁A���͂̊m�F�󋵂ƃ�����ۑ��ł��܂���B"
    '�O��snapshot�A�z��commit��snapshot�A�������ؔz��̓����ێ���E�B
    allocationSnapshotCellWork = _
        CDbl(AllocationLedgerStoredRowCount() + 1) * 10# * 3#
    If AnalysisOperationTransactionIsActive() Then
        '�O��transaction��peak�l�́A�������܂ޓ�g��O:X�ޔ������Ɋ܂ށB
        effectiveAdditionalSnapshotCellWork = additionalSnapshotCellWork
    Else
        effectiveAdditionalSnapshotCellWork = _
            additionalSnapshotCellWork + allocationSnapshotCellWork
    End If
    If Not capacityConfirmed Then
        If Not RequireManualFlowMutationCapacity("���͔��f�̕ۑ�") Then _
            Err.Raise 18, "CommitPendingAnalysisReviews", _
                      "���p�҂��蓮���̗e�ʊm�F���������܂����B"
    End If
    If rebuildWorkspace Then
        If Not ConfirmCurrentAnalysisWorkspaceCapacity( _
                   reasonText, confirmedAnalysisWorkloadRows, _
                   capacityShiftCount, capacityFlowCount, capacityUnknownCount, _
                   capacityCandidateCount, capacityResultCount, _
                   allowLateCapacityPrompt, effectiveAdditionalSnapshotCellWork) Then _
            Err.Raise 18, "CommitPendingAnalysisReviews", _
                      "���p�҂�����workspace�̗e�ʊm�F���������܂����B"
    Else
        If Not ConfirmAnalysisReviewOperationCapacity( _
                   reasonText, confirmedAnalysisWorkloadRows, _
                   allowUserConfirmation:=allowLateCapacityPrompt, _
                   additionalSnapshotCellWork:=effectiveAdditionalSnapshotCellWork) Then _
            Err.Raise 18, "CommitPendingAnalysisReviews", _
                      "���p�҂����͔��f�̗e�ʊm�F���������܂����B"
    End If
    On Error GoTo EH
    '�C�x���g��~�A�ޔ��A�����݂��O�ɑS�e�ʊm�F����������B
    If Not TryGetAnalysisWorkspaceEnableEvents(previousEvents, eventStateDetail) Then
        eventsReadyForRecovery = _
            StopAfterAnalysisWorkspaceEventStateFailure( _
                "CommitPendingAnalysisReviews/�J�n��Ԏ擾", eventStateDetail, _
                recoveryAttempted, recoveryTerminalFailure, _
                vbObjectError + 4879, "CommitPendingAnalysisReviews", _
                "Excel�C�x���g�̊J�n��Ԃ��擾�ł��܂���ł����B")
        If recoveryAttempted Or recoveryTerminalFailure Then _
            RaiseAnalysisWorkspaceLocalRecoveryFatal _
                "CommitPendingAnalysisReviews", _
                vbObjectError + 4879, "CommitPendingAnalysisReviews", _
                "Excel�C�x���g�̊J�n��Ԃ��擾�ł��܂���ł����B", _
                eventStateDetail
        Err.Raise vbObjectError + 4879, "CommitPendingAnalysisReviews", _
                  "Excel�C�x���g�̊J�n��Ԃ��擾�ł��܂���ł����B " & eventStateDetail
    End If
    eventsCaptured = True
    If Not TrySetAnalysisWorkspaceEnableEventsExact(False, eventStateDetail) Then _
        Err.Raise vbObjectError + 4880, "CommitPendingAnalysisReviews", _
                  "���͔��f�̕ۑ��O��Excel�C�x���g���~�ł��܂���ł����B " & _
                  eventStateDetail
    ReDim sourceSnapshots(1 To 3)
    ReDim sourceLastRows(1 To 3)
    CaptureAnalysisSourceReviewSnapshots sourceSnapshots, sourceLastRows
    sourceSnapshotsCaptured = True
    CaptureManualFlowStoreSnapshot manualSnapshot, manualSnapshotLastRow
    manualSnapshotCaptured = True
    CaptureAllocationLedgerTransactionSnapshot allocationSnapshot, _
        allocationSnapshotLastRow, allocationSnapshotDigest
    allocationSnapshotCaptured = True
    writeStarted = True
    '�ꗗ�Əڍׂ̗����𓯊����A�ڍב��̌ʔ��f���Ō�ɗD�悷��B
    SyncAnalysisWorkspaceReviewsToSources
    SyncAnalysisDetailReviewsToSources
    '���L���ID�̏d���m��́A�����̔��f�E���R�E�����������ύX�����A
    '�蓮���X�g�A���܂ތ㑱�ۑ����O�ɒ�~����B���\��EH�őޔ����_�֖߂��B
    ResolveAnalysisReviewConflicts GetSheet(SH_ANALYSIS_SHIFT), GetSheet(SH_ANALYSIS_FLOW)
    SyncManualFlowReviewsFromAnalysisSheet True
    '�m�F�󋵂̕ۑ��Ɠ���transaction�ŁA���s��₩��z���E�c�����Ċm�肷��B
    '������Ȃ��ƁA���m�F���m�F�ς݂̕ύX����s���c�z���������l�̂܂܎c��B
    RebuildCurrentAnalysisAllocationPlan
    '�B���z����v�ǉ��m�F�֖߂����ꍇ�A���̍ŏI��Ԃ��蓮��␳�{�ɂ����f����B
    SyncManualFlowReviewsFromAnalysisSheet True
    If rebuildWorkspace Then
        BuildAnalysisWorkspaceCore "���͔��f�̕ۑ�", _
                                   confirmedAnalysisWorkloadRows, False
    Else
        RefreshAnalysisReviewDisplaysFromSources
    End If
    '���ڍׂ���ۑ������ꍇ���A����̏o�͎��ɋ��p�l���l���ēK�p����Ȃ��悤
    '�����p�l�����m��ς݂̌��\�֖߂��B
    RefreshCashAnalysisPanel False
    '���\�E�蓮���E��ʍč\�z���S�Đ������Ă���䒠�Ɨ����𓯈�o�b�`�Ŋm�肷��B
    If Not ConfirmAnalysisReviewOperationCapacity( _
               "���͔��f�䒠�̕ۑ�", confirmedAnalysisWorkloadRows, _
               allowUserConfirmation:=False, _
               additionalSnapshotCellWork:=effectiveAdditionalSnapshotCellWork) Then _
        Err.Raise 18, "CommitPendingAnalysisReviews", _
                  "���͔��f�䒠�̊m�F�ςݗe�ʂ��s�����Ă��܂��B"
    PersistAnalysisReviewsFromCurrentSheets False, reasonText
    persistenceCommitted = True
    MarkAnalysisReviewsClean
    mAnalysisDetailReviewsDirty = False
    If Not TryRestoreAnalysisWorkspaceEnableEvents( _
               previousEvents, "CommitPendingAnalysisReviews/����I��", _
               recoveryAttempted, recoveryTerminalFailure, _
               eventStateDetail) Then
        eventsCaptured = False
        If recoveryAttempted Or recoveryTerminalFailure Then _
            RaiseAnalysisWorkspaceLocalRecoveryFatal _
                "CommitPendingAnalysisReviews", _
                vbObjectError + 4881, "CommitPendingAnalysisReviews", _
                "����I������Excel�C�x���g�J�n�l�����Ɏ��s���܂����B", _
                eventStateDetail
        Err.Raise vbObjectError + 4881, "CommitPendingAnalysisReviews", eventStateDetail
    End If
    eventsCaptured = False
    If recoveryAttempted Or recoveryTerminalFailure Then _
        RaiseAnalysisWorkspaceLocalRecoveryFatal _
            "CommitPendingAnalysisReviews", _
            vbObjectError + 4881, "CommitPendingAnalysisReviews", _
            "����I������Excel�C�x���g�J�n�l������local Recovery�����s���܂����B", _
            eventStateDetail
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    fatalContainmentRequired = _
        IsAnalysisWorkspaceRecoveryFatalError(errorNumber, errorSource)
    If fatalContainmentRequired Then
        Call TryStopAnalysisWorkspaceEventsForBookWrites(eventStateDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    eventsReadyForRecovery = False
    safeToRestoreEntry = (Not writeStarted) And Not fatalContainmentRequired
    If eventsCaptured Then
        eventsReadyForRecovery = _
            TryStopAnalysisWorkspaceEventsForBookWrites(eventStateDetail)
        If writeStarted And Not eventsReadyForRecovery Then _
            AppendAnalysisWorkspaceRollbackDetail rollbackDetail, _
                "Excel�C�x���g��~���m�F�ł��Ȃ����߁A�u�b�N�ւ̕����ERecovery�Edirty�����݂�������܂�: " & _
                eventStateDetail
    End If
    '�䒠�m��O�̎��s�́A���͌��\�Ǝ蓮���𗼕��Ƃ��ޔ����_�֖߂��B
    '�䒠�m���͌��\�����������߂��Ƒ䒠�Ƃ̕s��v����邽�߁A�ă��[���o�b�N���Ȃ��B
    If Not fatalContainmentRequired And writeStarted And _
       Not persistenceCommitted Then
        If Not eventsReadyForRecovery Then
            AppendAnalysisWorkspaceRollbackDetail rollbackDetail, _
                "�C�x���g��~���m�F�̂��߁A���͌��\�E�蓮���E�z���������ď����݂��܂���B"
        ElseIf sourceSnapshotsCaptured Then
            sourceRollbackOK = RestoreAnalysisSourceReviewSnapshots( _
                                   sourceSnapshots, sourceLastRows, rollbackDetail)
        Else
            AppendAnalysisWorkspaceRollbackDetail rollbackDetail, _
                "���͌��\�̑ޔ�������܂���B"
        End If
        If eventsReadyForRecovery And manualSnapshotCaptured Then
            On Error Resume Next
            Err.Clear
            RestoreManualFlowStoreSnapshot manualSnapshot, manualSnapshotLastRow
            rollbackErrorNumber = Err.Number
            rollbackErrorDescription = Err.Description
            Err.Clear
            On Error GoTo 0
            If rollbackErrorNumber = 0 Then
                manualRollbackOK = True
            Else
                AppendAnalysisWorkspaceRollbackDetail rollbackDetail, _
                    "�蓮�������̕����G���[: " & rollbackErrorDescription
            End If
        ElseIf eventsReadyForRecovery Then
            AppendAnalysisWorkspaceRollbackDetail rollbackDetail, _
                "�蓮�������̑ޔ�������܂���B"
        End If
        If eventsReadyForRecovery And allocationSnapshotCaptured Then
            On Error Resume Next
            Err.Clear
            RestoreAllocationLedgerTransactionSnapshot allocationSnapshot, _
                allocationSnapshotLastRow, allocationSnapshotDigest
            rollbackErrorNumber = Err.Number
            rollbackErrorDescription = Err.Description
            Err.Clear
            On Error GoTo 0
            If rollbackErrorNumber = 0 Then
                allocationRollbackOK = True
            Else
                AppendAnalysisWorkspaceRollbackDetail rollbackDetail, _
                    "�z�������̕����G���[: " & rollbackErrorDescription
            End If
        ElseIf eventsReadyForRecovery Then
            AppendAnalysisWorkspaceRollbackDetail rollbackDetail, _
                "�z�������̑ޔ�������܂���B"
        End If
        rollbackSafe = sourceRollbackOK And manualRollbackOK And _
                       allocationRollbackOK
        If rollbackSafe Then
            safeToRestoreEntry = True
            AppendAnalysisWorkspaceRollbackDetail rollbackDetail, _
                "���͌��\�E�蓮���E�z��������ޔ����_�֌����ɕ������܂����B"
        End If
    ElseIf Not fatalContainmentRequired And writeStarted And _
           persistenceCommitted Then
        AppendAnalysisWorkspaceRollbackDetail rollbackDetail, _
            "���f�䒠�̊m���Ɏ��s�������߁A�m��ς݃f�[�^�����ޔ��֊����߂��܂���B"
    End If

    '���[���o�b�N�ň��S���m��ł��Ȃ��o�H�́AFalse exact����Recovery����������B
    'Recovery����x�ł����s�����ꍇ�́A����private���E���ň��S�m�F��ɕK��
    '5191�I�[�𑗏o���Adirty�E�f�f�E�C�x���g�J�n�l�����֖߂�Ȃ��B
    If Not fatalContainmentRequired And writeStarted And Not rollbackSafe Then
        If eventsReadyForRecovery Then
            EnforceAnalysisWorkspaceRecoveryStateTerminal _
                "CommitPendingAnalysisReviews", rollbackDetail, _
                recoveryAttempted, recoveryTerminalFailure, _
                errorNumber, errorSource, errorDescription
        Else
            AppendAnalysisWorkspaceRollbackDetail rollbackDetail, _
                "Recovery�����݂�������A�Č��̈��S��Ԃ͕s���ł��B"
        End If
    End If

    'dirty�̓��[���o�b�N���S�܂���Recovery exact�̊m���Ɍ���A
    '�����ݒ��O��False exact���m�F���Ă���L�^����B
    If Not fatalContainmentRequired And writeStarted And safeToRestoreEntry Then
        eventsReadyForRecovery = _
            TryStopAnalysisWorkspaceEventsForBookWrites(eventStateDetail)
        If eventsReadyForRecovery Then
            On Error Resume Next
            Err.Clear
            MarkAnalysisReviewsDirty
            dirtyErrorNumber = Err.Number
            dirtyErrorDescription = Err.Description
            Err.Clear
            On Error GoTo 0
            If Not TryStopAnalysisWorkspaceEventsForBookWrites(eventStateDetail) Then
                safeToRestoreEntry = False
                AppendAnalysisWorkspaceRollbackDetail rollbackDetail, _
                    "dirty�L�^���Excel�C�x���g��~���m�F�ł��Ȃ����߁A" & _
                    "�J�n�l�֖߂��܂���: " & eventStateDetail
            End If
        Else
            safeToRestoreEntry = False
            AppendAnalysisWorkspaceRollbackDetail errorDescription, _
                "Excel�C�x���g��~���m�F�̂��߁A���͗v�X�V��Ԃ̏����݂�������܂����B"
        End If
    ElseIf writeStarted Then
        AppendAnalysisWorkspaceRollbackDetail errorDescription, _
            "���[���o�b�N���S�܂���Recovery exact���m�F�ł��Ȃ����߁A" & _
            "���͗v�X�V��Ԃ̏����݂�������܂����B"
    End If

    '�J�n�l�֖߂��̂́A�ύX�O�i�������݁j�A���S���[���o�b�N�ARecovery exact�̂����ꂩ�����B
    If eventsCaptured And safeToRestoreEntry Then
        If Not TryRestoreAnalysisWorkspaceEnableEvents( _
                   previousEvents, "CommitPendingAnalysisReviews/�ُ�I��", _
                   recoveryAttempted, recoveryTerminalFailure, _
                   eventStateDetail) Then _
            AppendAnalysisWorkspaceRollbackDetail errorDescription, _
                "Excel�C�x���g��Ԃ̕����G���[: " & eventStateDetail
        eventsCaptured = False
    ElseIf eventsCaptured Then
        If TryStopAnalysisWorkspaceEventsForBookWrites(eventStateDetail) Then
            AppendAnalysisWorkspaceRollbackDetail errorDescription, _
                "�Č��̈��S��Ԃ��m�F�ł��Ȃ����߁AExcel�C�x���g��False�̂܂ܒ�~���܂����B"
        Else
            AppendAnalysisWorkspaceRollbackDetail errorDescription, _
                "�Č��̈��S��Ԃ��m�F�ł����AExcel�C�x���g��False�����ɂ����s���܂���: " & _
                eventStateDetail
        End If
        eventsCaptured = False
    End If
    If Len(rollbackDetail) > 0 Then _
        errorDescription = errorDescription & " / ���[���o�b�N�m�F: " & rollbackDetail
    If dirtyErrorNumber <> 0 Then _
        errorDescription = errorDescription & " / ���͗v�X�V��Ԃ̋L�^�G���[: Err " & _
                           CStr(dirtyErrorNumber) & " " & dirtyErrorDescription
    If recoveryAttempted Or recoveryTerminalFailure Then _
        RaiseAnalysisWorkspaceLocalRecoveryFatal _
            "CommitPendingAnalysisReviews", errorNumber, errorSource, _
            errorDescription, rollbackDetail
    Err.Raise errorNumber, "CommitPendingAnalysisReviews", errorDescription
End Sub

Public Sub MarkAnalysisDetailReviewDirty()
    mAnalysisDetailReviewsDirty = True
    MarkAnalysisReviewsDirty
End Sub

Private Function AnalysisWorkspaceReviewsDifferFromSources() As Boolean
    Dim wsResult As Worksheet, wsSource As Worksheet
    Dim lastR As Long, r As Long, sourceRow As Long
    Dim sourceSheet As String, sourceKey As String
    Dim statusCol As Long, memoCol As Long, keyCol As Long
    Dim resultStatus As String, sourceStatus As String
    If Not SheetExists(SH_ANALYSIS_RESULT) Then Exit Function
    Set wsResult = GetSheet(SH_ANALYSIS_RESULT)
    lastR = LastUsedRowInSheet(wsResult)
    For r = 2 To lastR
        sourceSheet = CellText(wsResult.Cells(r, ANALYSIS_RESULT_SOURCE_SHEET_COL).Value)
        sourceRow = WorkspaceLong(wsResult.Cells(r, ANALYSIS_RESULT_SOURCE_ROW_COL).Value)
        sourceKey = CellText(wsResult.Cells(r, ANALYSIS_RESULT_SOURCE_KEY_COL).Value)
        If Not WorkspaceSourceColumns(sourceSheet, statusCol, memoCol, keyCol) Then
            AnalysisWorkspaceReviewsDifferFromSources = True
            Exit Function
        End If
        Set wsSource = GetSheet(sourceSheet)
        If sourceRow < 2 Or sourceRow > LastUsedRowInSheet(wsSource) Then
            AnalysisWorkspaceReviewsDifferFromSources = True
            Exit Function
        End If
        If StrComp(CellText(wsSource.Cells(sourceRow, keyCol).Value), _
                   sourceKey, vbBinaryCompare) <> 0 Then
            AnalysisWorkspaceReviewsDifferFromSources = True
            Exit Function
        End If
        resultStatus = WorkspaceStatusOrDefault( _
            wsResult.Cells(r, ANALYSIS_RESULT_STATUS_COL).Value)
        sourceStatus = WorkspaceStatusOrDefault(wsSource.Cells(sourceRow, statusCol).Value)
        If StrComp(resultStatus, sourceStatus, vbBinaryCompare) <> 0 Or _
           StrComp(CellText(wsResult.Cells(r, ANALYSIS_RESULT_MEMO_COL).Value), _
                   CellText(wsSource.Cells(sourceRow, memoCol).Value), _
                   vbBinaryCompare) <> 0 Then
            AnalysisWorkspaceReviewsDifferFromSources = True
            Exit Function
        End If
    Next r
End Function

Private Function AnalysisDetailReviewsDifferFromSources() As Boolean
    Dim wsDetail As Worksheet, wsSource As Worksheet
    Dim lastR As Long, r As Long, sourceRow As Long
    Dim sourceSheet As String, sourceKey As String
    Dim statusCol As Long, memoCol As Long, keyCol As Long
    Dim detailStatus As String, sourceStatus As String
    Dim detailMemo As String, sourceMemo As String
    If Not SheetExists(SH_ANALYSIS_DETAIL) Then Exit Function
    Set wsDetail = GetSheet(SH_ANALYSIS_DETAIL)
    lastR = LastUsedRowInSheet(wsDetail)
    For r = 2 To lastR
        If CellText(wsDetail.Cells(r, DETAIL_COL_KIND).Value) = "���" Then
            sourceSheet = CellText(wsDetail.Cells(r, DETAIL_COL_REFERENCE).Value)
            sourceRow = WorkspaceLong(wsDetail.Cells(r, DETAIL_COL_SOURCE_ROW).Value)
            sourceKey = CellText(wsDetail.Cells(r, DETAIL_COL_SOURCE_KEY).Value)
            If Not WorkspaceSourceColumns(sourceSheet, statusCol, memoCol, keyCol) Then
                AnalysisDetailReviewsDifferFromSources = True
                Exit Function
            End If
            Set wsSource = GetSheet(sourceSheet)
            If sourceRow < 2 Or sourceRow > LastUsedRowInSheet(wsSource) Then
                AnalysisDetailReviewsDifferFromSources = True
                Exit Function
            End If
            If StrComp(CellText(wsSource.Cells(sourceRow, keyCol).Value), _
                       sourceKey, vbBinaryCompare) <> 0 Then
                AnalysisDetailReviewsDifferFromSources = True
                Exit Function
            End If
            If r + 1 > lastR Or _
               CellText(wsDetail.Cells(r + 1, DETAIL_COL_KIND).Value) <> "��⃁��" Then
                AnalysisDetailReviewsDifferFromSources = True
                Exit Function
            End If
            detailStatus = WorkspaceStatusOrDefault(wsDetail.Cells(r, 6).Value)
            sourceStatus = WorkspaceStatusOrDefault(wsSource.Cells(sourceRow, statusCol).Value)
            detailMemo = CellText(wsDetail.Cells(r + 1, 2).Value)
            sourceMemo = CellText(wsSource.Cells(sourceRow, memoCol).Value)
            If StrComp(detailStatus, sourceStatus, vbBinaryCompare) <> 0 Or _
               StrComp(detailMemo, sourceMemo, vbBinaryCompare) <> 0 Then
                AnalysisDetailReviewsDifferFromSources = True
                Exit Function
            End If
        End If
    Next r
End Function

Private Sub RefreshAnalysisReviewDisplaysFromSources()
    RefreshAnalysisResultReviewsFromSources
    RefreshAnalysisGroupReviewsFromSources
    RefreshAnalysisDetailReviewsFromSources
End Sub

Private Sub RefreshAnalysisResultReviewsFromSources()
    Dim wsResult As Worksheet, wsSource As Worksheet
    Dim lastR As Long, r As Long, sourceRow As Long
    Dim sourceSheet As String, sourceKey As String
    Dim statusCol As Long, memoCol As Long, keyCol As Long
    If Not SheetExists(SH_ANALYSIS_RESULT) Then Exit Sub
    Set wsResult = GetSheet(SH_ANALYSIS_RESULT)
    lastR = LastUsedRowInSheet(wsResult)
    If lastR < 2 Then Exit Sub
    wsResult.Unprotect Password:=TOOL_PASSWORD
    For r = 2 To lastR
        sourceSheet = CellText(wsResult.Cells(r, ANALYSIS_RESULT_SOURCE_SHEET_COL).Value)
        sourceRow = WorkspaceLong(wsResult.Cells(r, ANALYSIS_RESULT_SOURCE_ROW_COL).Value)
        sourceKey = CellText(wsResult.Cells(r, ANALYSIS_RESULT_SOURCE_KEY_COL).Value)
        ValidateAnalysisReviewReference sourceSheet, sourceRow, sourceKey, _
                                        statusCol, memoCol, keyCol, "���͌���", r
        Set wsSource = GetSheet(sourceSheet)
        wsResult.Cells(r, ANALYSIS_RESULT_STATUS_COL).Value = _
            WorkspaceStatusOrDefault(wsSource.Cells(sourceRow, statusCol).Value)
        wsResult.Cells(r, ANALYSIS_RESULT_MEMO_COL).Value = _
            CellText(wsSource.Cells(sourceRow, memoCol).Value)
    Next r
    ProtectSingleAnalysisSheet wsResult
End Sub

Private Sub RefreshAnalysisGroupReviewsFromSources()
    Dim wsGroup As Worksheet, wsSource As Worksheet
    Dim lastR As Long, r As Long, sourceRow As Long
    Dim sourceSheet As String, sourceKey As String
    Dim statusCol As Long, memoCol As Long, keyCol As Long
    If Not SheetExists(SH_WORK_ANALYSIS_GROUP) Then Exit Sub
    Set wsGroup = GetSheet(SH_WORK_ANALYSIS_GROUP)
    lastR = LastUsedRowInSheet(wsGroup)
    If lastR < 2 Then Exit Sub
    For r = 2 To lastR
        sourceSheet = CellText(wsGroup.Cells(r, 2).Value)
        sourceRow = WorkspaceLong(wsGroup.Cells(r, 3).Value)
        sourceKey = CellText(wsGroup.Cells(r, 4).Value)
        ValidateAnalysisReviewReference sourceSheet, sourceRow, sourceKey, _
                                        statusCol, memoCol, keyCol, "W_���̓O���[�v", r
        Set wsSource = GetSheet(sourceSheet)
        wsGroup.Cells(r, 9).Value = _
            WorkspaceStatusOrDefault(wsSource.Cells(sourceRow, statusCol).Value)
        wsGroup.Cells(r, 10).Value = CellText(wsSource.Cells(sourceRow, memoCol).Value)
    Next r
    SetSheetVeryHiddenSafe wsGroup
End Sub

Private Sub RefreshAnalysisDetailReviewsFromSources()
    Dim wsDetail As Worksheet, wsSource As Worksheet
    Dim lastR As Long, r As Long, sourceRow As Long
    Dim sourceSheet As String, sourceKey As String
    Dim statusCol As Long, memoCol As Long, keyCol As Long
    If Not SheetExists(SH_ANALYSIS_DETAIL) Then Exit Sub
    Set wsDetail = GetSheet(SH_ANALYSIS_DETAIL)
    lastR = LastUsedRowInSheet(wsDetail)
    If lastR < 2 Then Exit Sub
    wsDetail.Unprotect Password:=TOOL_PASSWORD
    For r = 2 To lastR
        If CellText(wsDetail.Cells(r, DETAIL_COL_KIND).Value) = "���" Then
            sourceSheet = CellText(wsDetail.Cells(r, DETAIL_COL_REFERENCE).Value)
            sourceRow = WorkspaceLong(wsDetail.Cells(r, DETAIL_COL_SOURCE_ROW).Value)
            sourceKey = CellText(wsDetail.Cells(r, DETAIL_COL_SOURCE_KEY).Value)
            ValidateAnalysisReviewReference sourceSheet, sourceRow, sourceKey, _
                                            statusCol, memoCol, keyCol, "���ڍ�", r
            Set wsSource = GetSheet(sourceSheet)
            wsDetail.Cells(r, 6).Value = _
                WorkspaceStatusOrDefault(wsSource.Cells(sourceRow, statusCol).Value)
            If r + 1 <= lastR And _
               CellText(wsDetail.Cells(r + 1, DETAIL_COL_KIND).Value) = "��⃁��" Then _
                wsDetail.Cells(r + 1, 2).Value = CellText(wsSource.Cells(sourceRow, memoCol).Value)
        End If
    Next r
    ProtectSingleAnalysisSheet wsDetail
End Sub

Private Sub ValidateAnalysisReviewReference( _
        ByVal sourceSheet As String, ByVal sourceRow As Long, ByVal sourceKey As String, _
        ByRef statusCol As Long, ByRef memoCol As Long, ByRef keyCol As Long, _
        ByVal labelText As String, ByVal displayRow As Long)
    Dim wsSource As Worksheet
    If Not WorkspaceSourceColumns(sourceSheet, statusCol, memoCol, keyCol) Then _
        Err.Raise vbObjectError + 4821, "ValidateAnalysisReviewReference", _
                  labelText & " " & CStr(displayRow) & "�s�ڂ̓������\���s���ł��B"
    Set wsSource = GetSheet(sourceSheet)
    If sourceRow < 2 Or sourceRow > LastUsedRowInSheet(wsSource) Then _
        Err.Raise vbObjectError + 4822, "ValidateAnalysisReviewReference", _
                  labelText & " " & CStr(displayRow) & "�s�ڂ̓������s��������܂���B"
    If Len(sourceKey) = 0 Or _
       StrComp(CellText(wsSource.Cells(sourceRow, keyCol).Value), _
               sourceKey, vbBinaryCompare) <> 0 Then _
        Err.Raise vbObjectError + 4823, "ValidateAnalysisReviewReference", _
                  labelText & " " & CStr(displayRow) & "�s�ڂ̊m�F�L�[����v���܂���B"
End Sub

Public Sub ToggleAnalysisDetailTransactionSelection(ByVal targetRow As Long)
    Dim ws As Worksheet, isSelected As Boolean, workbookWasSaved As Boolean
    Dim targetRows() As Long, snapshot As AnalysisDetailSelectionSnapshot
    Dim previousEvents As Boolean, eventsCaptured As Boolean
    Dim mutationStarted As Boolean, snapshotCaptured As Boolean
    Dim protectionConfirmed As Boolean, eventsRestored As Boolean
    Dim recoverySafeForEventRestore As Boolean
    Dim recoveryAttempted As Boolean, recoveryTerminalFailure As Boolean
    Dim workbookSavedCaptured As Boolean
    Dim c As Long, expectedColor As Long, expectedBold As Boolean
    Dim errorNumber As Long, errorDescription As String
    Dim errorSource As String, eventStateDetail As String
    Dim eventRestoreDetail As String, cleanupDetail As String
    If Not SheetExists(SH_ANALYSIS_DETAIL) Then Exit Sub
    Set ws = GetSheet(SH_ANALYSIS_DETAIL)
    If targetRow < 1 Or targetRow > LastUsedRowInSheet(ws) Then Exit Sub
    If CellText(ws.Cells(targetRow, DETAIL_COL_KIND).Value) <> "���" Then Exit Sub
    If Not TryGetAnalysisWorkspaceEnableEvents( _
               previousEvents, eventStateDetail) Then
        On Error Resume Next
        MsgBox "����I���̕ύX�O��Excel�C�x���g�̊J�n��Ԃ��擾�ł��܂���ł����B" & _
               vbCrLf & "�u�b�N�ւ̕ύX�͍s���Ă��܂���B", _
               vbCritical, "Excel�C�x���g��Ԃ��m�F�ł��܂���"
        On Error GoTo 0
        Err.Raise vbObjectError + 4901, _
                  "ToggleAnalysisDetailTransactionSelection", _
                  "Excel�C�x���g�̊J�n��Ԃ��擾�ł��܂���ł����B " & _
                  eventStateDetail
    End If
    eventsCaptured = True
    If Not TrySetAnalysisWorkspaceEnableEventsExact(False, eventStateDetail) Then
        errorDescription = _
            "����I���̕ύX�O��Excel�C�x���g��False�֒�~����" & _
            "�ǖ߂��m�F�ł��܂���ł����B�u�b�N�ւ̕ύX�͍s���Ă��܂���B " & _
            eventStateDetail
        eventsRestored = TryRestoreAnalysisWorkspaceEnableEvents( _
                             previousEvents, _
                             "ToggleAnalysisDetailTransactionSelection/�ύX�J�n�O", _
                             recoveryAttempted, recoveryTerminalFailure, _
                             eventRestoreDetail)
        eventsCaptured = False
        If Not eventsRestored Then _
            AppendAnalysisWorkspaceRollbackDetail errorDescription, _
                "Excel�C�x���g�J�n�l�̕���������: " & eventRestoreDetail
        If recoveryAttempted Or recoveryTerminalFailure Then _
            RaiseAnalysisWorkspaceLocalRecoveryFatal _
                "ToggleAnalysisDetailTransactionSelection", _
                vbObjectError + 4902, _
                "ToggleAnalysisDetailTransactionSelection", _
                errorDescription, eventRestoreDetail
        Err.Raise vbObjectError + 4902, _
                  "ToggleAnalysisDetailTransactionSelection", errorDescription
    End If
    On Error GoTo EH
    workbookWasSaved = ThisWorkbook.Saved
    workbookSavedCaptured = True
    ReDim targetRows(1 To 1)
    targetRows(1) = targetRow
    CaptureAnalysisDetailSelectionSnapshot ws, targetRows, 1, snapshot
    snapshotCaptured = True
    mutationStarted = True
    ws.Unprotect Password:=TOOL_PASSWORD
    isSelected = (CellText(ws.Cells(targetRow, DETAIL_COL_SELECTED).Value) = "1")
    If isSelected Then
        ws.Cells(targetRow, DETAIL_COL_SELECTED).Value = "0"
        ws.Range(ws.Cells(targetRow, 1), ws.Cells(targetRow, 7)).Interior.Color = vbWhite
        ws.Range(ws.Cells(targetRow, 1), ws.Cells(targetRow, 7)).Font.Bold = False
        expectedColor = vbWhite
        expectedBold = False
        If CellText(ws.Cells(targetRow, DETAIL_COL_SOURCE_KEY).Value) = "GLOBAL" Then _
            ws.Cells(targetRow, 1).Value = "���I��"
    Else
        ws.Cells(targetRow, DETAIL_COL_SELECTED).Value = "1"
        ws.Range(ws.Cells(targetRow, 1), ws.Cells(targetRow, 7)).Interior.Color = RGB(219, 234, 254)
        ws.Range(ws.Cells(targetRow, 1), ws.Cells(targetRow, 7)).Font.Bold = True
        expectedColor = RGB(219, 234, 254)
        expectedBold = True
        If CellText(ws.Cells(targetRow, DETAIL_COL_SOURCE_KEY).Value) = "GLOBAL" Then _
            ws.Cells(targetRow, 1).Value = "�I��"
    End If
    If ws.Cells(targetRow, DETAIL_COL_SELECTED).HasFormula Or _
       Not StrictVariantValuesMatch( _
               IIf(isSelected, "0", "1"), _
               ws.Cells(targetRow, DETAIL_COL_SELECTED).Value2) Then _
        Err.Raise vbObjectError + 4903, _
                  "ToggleAnalysisDetailTransactionSelection", _
                  "����I���t���O�̏����ǖ߂����^�܂ň�v���܂���B"
    If CellText(ws.Cells(targetRow, DETAIL_COL_SOURCE_KEY).Value) = "GLOBAL" Then
        If ws.Cells(targetRow, 1).HasFormula Or _
           Not StrictVariantValuesMatch( _
                   IIf(isSelected, "���I��", "�I��"), _
                   ws.Cells(targetRow, 1).Value2) Then _
            Err.Raise vbObjectError + 4904, _
                      "ToggleAnalysisDetailTransactionSelection", _
                      "����I��\���̏����ǖ߂����^�܂ň�v���܂���B"
    End If
    For c = 1 To 7
        If CLng(ws.Cells(targetRow, c).Interior.Color) <> expectedColor Or _
           CBool(ws.Cells(targetRow, c).Font.Bold) <> expectedBold Then _
            Err.Raise vbObjectError + 4905, _
                      "ToggleAnalysisDetailTransactionSelection", _
                      "����I�������̏����ǖ߂�����v���܂���B"
    Next c
    RefreshManualSelectionSummary ws
    ProtectSingleAnalysisSheet ws
    protectionConfirmed = ws.ProtectContents And ws.ProtectDrawingObjects
    If Not protectionConfirmed Then _
        Err.Raise vbObjectError + 4906, _
                  "ToggleAnalysisDetailTransactionSelection", _
                  "����I��ύX��̃Z���E�}�`�ی�𗼕�True�Ƃ��Ċm�F�ł��܂���B"
    '�I��F�E�����t���O�͈ꎞ�I�ȉ�ʏ�ԂȂ̂ŁA���ꂾ���ŕۑ��m�F�𔭐������Ȃ��B
    If workbookWasSaved Then
        ThisWorkbook.Saved = True
        If Not ThisWorkbook.Saved Then _
            Err.Raise vbObjectError + 4907, _
                      "ToggleAnalysisDetailTransactionSelection", _
                      "�ĕی��Ƀu�b�N�ۑ���Ԃ��J�n�l�֕����ł��܂���ł����B"
    End If
    On Error GoTo 0
    eventsRestored = TryRestoreAnalysisWorkspaceEnableEvents( _
                         previousEvents, _
                         "ToggleAnalysisDetailTransactionSelection/����I��", _
                         recoveryAttempted, recoveryTerminalFailure, _
                         eventRestoreDetail)
    eventsCaptured = False
    If recoveryAttempted Or recoveryTerminalFailure Then _
        RaiseAnalysisWorkspaceLocalRecoveryFatal _
            "ToggleAnalysisDetailTransactionSelection", _
            vbObjectError + 4908, _
            "ToggleAnalysisDetailTransactionSelection", _
            "����I������Excel�C�x���g�J�n�l������local Recovery�����s���܂����B", _
            eventRestoreDetail
    If Not eventsRestored Then _
        Err.Raise vbObjectError + 4908, _
                  "ToggleAnalysisDetailTransactionSelection", eventRestoreDetail
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    If IsAnalysisWorkspaceRecoveryFatalError(errorNumber, errorSource) Then _
        RethrowAnalysisWorkspaceUpstreamRecoveryFatal _
            errorNumber, errorSource, errorDescription, _
            "ToggleAnalysisDetailTransactionSelection"
    If eventsCaptured Then
        recoverySafeForEventRestore = False
        If TryStopAnalysisWorkspaceEventsForBookWrites(eventStateDetail) Then
            recoverySafeForEventRestore = _
                RecoverAnalysisDetailSelectionMutation( _
                    ws, snapshot, snapshotCaptured, mutationStarted, _
                    workbookSavedCaptured, workbookWasSaved, _
                    "ToggleAnalysisDetailTransactionSelection", _
                    errorNumber, errorSource, errorDescription, _
                    recoveryAttempted, recoveryTerminalFailure, cleanupDetail)
            AppendAnalysisWorkspaceRollbackDetail errorDescription, cleanupDetail
        Else
            AppendAnalysisWorkspaceRollbackDetail errorDescription, _
                "Excel�C�x���g��False�֒�~���ēǖ߂��m�F�ł��Ȃ����߁A" & _
                "���[���o�b�N�E�ĕی�ERecovery�E�f�f�E��ԕ\���E" & _
                "�ۑ���Ԃւ̏����݂�������܂����B�Č��̈��S��Ԃ͕s���ł�: " & _
                eventStateDetail
            On Error Resume Next
            MsgBox "����I���̕ύX�Ɏ��s���AExcel�C�x���g�����S�ɒ�~�ł��܂���ł����B" & _
                   vbCrLf & "�u�b�N�ւ̕��������݂͍s���Ă��܂���B" & _
                   vbCrLf & "���݂̃u�b�N���㏑�����Ȃ��ł��������B", _
                   vbCritical, "����I���̈��S��Ԃ��m�F�ł��܂���"
            On Error GoTo 0
        End If
        If recoverySafeForEventRestore Then
            eventsRestored = TryRestoreAnalysisWorkspaceEnableEvents( _
                                 previousEvents, _
                                 "ToggleAnalysisDetailTransactionSelection/�ُ�I��", _
                                 recoveryAttempted, recoveryTerminalFailure, _
                                 eventRestoreDetail)
        Else
            eventsRestored = False
            If TryStopAnalysisWorkspaceEventsForBookWrites(eventRestoreDetail) Then
                AppendAnalysisWorkspaceRollbackDetail errorDescription, _
                    "���[���o�b�N���S�܂���Recovery exact���m�F�ł��Ȃ����߁A" & _
                    "Excel�C�x���g��False�̂܂ܒ�~���܂����B"
                eventRestoreDetail = _
                    "���S��Ԗ��m�F�̂��ߊJ�n�l�ւ̕��������s���Ă��܂���B"
            Else
                AppendAnalysisWorkspaceRollbackDetail errorDescription, _
                    "���S��Ԃ��m�F�ł����AExcel�C�x���g��False�����ɂ����s���܂���: " & _
                    eventRestoreDetail
            End If
        End If
        eventsCaptured = False
        If Not eventsRestored Then _
            AppendAnalysisWorkspaceRollbackDetail errorDescription, _
                "Excel�C�x���g���������𐳏튮���Ƃ��Ĉ����܂���: " & eventRestoreDetail
    End If
    If recoveryAttempted Or recoveryTerminalFailure Then _
        RaiseAnalysisWorkspaceLocalRecoveryFatal _
            "ToggleAnalysisDetailTransactionSelection", _
            errorNumber, errorSource, errorDescription, _
            cleanupDetail & " / " & eventRestoreDetail
    Err.Raise errorNumber, "ToggleAnalysisDetailTransactionSelection", _
              IIf(Len(errorSource) > 0, _
                  errorSource & " / ", vbNullString) & errorDescription
End Sub

Public Function HasSelectedAnalysisDetailTransactions() As Boolean
    Dim ws As Worksheet, lastR As Long, r As Long
    Dim selectionData As Variant
    If Not SheetExists(SH_ANALYSIS_DETAIL) Then Exit Function
    Set ws = GetSheet(SH_ANALYSIS_DETAIL)
    '�ۑ��E�ăI�[�v����͌��ڍׂ��\���֖߂����A���o�^�̑I���t���O�܂�
    '�����������̂Ƃ��Ĉ���Ȃ��B�\����Ԃɂ�����炸������𑖍�����B
    lastR = LastUsedRowInSheet(ws)
    If lastR < 1 Then Exit Function
    selectionData = ws.Range(ws.Cells(1, DETAIL_COL_KIND), _
                             ws.Cells(lastR, DETAIL_COL_SELECTED)).Value2
    For r = 1 To UBound(selectionData, 1)
        If CellText(selectionData(r, 1)) = "���" And _
           CellText(selectionData(r, DETAIL_COL_SELECTED - DETAIL_COL_KIND + 1)) = "1" Then
            HasSelectedAnalysisDetailTransactions = True
            Exit Function
        End If
    Next r
End Function

Public Sub ClearAnalysisDetailTransactionSelections()
    Dim ws As Worksheet, lastR As Long, r As Long, workbookWasSaved As Boolean
    Dim selectionData As Variant
    Dim selectedRows() As Long, selectedCount As Long, selectedIndex As Long
    Dim snapshot As AnalysisDetailSelectionSnapshot
    Dim previousEvents As Boolean, eventsCaptured As Boolean
    Dim mutationStarted As Boolean, snapshotCaptured As Boolean
    Dim protectionConfirmed As Boolean, eventsRestored As Boolean
    Dim recoverySafeForEventRestore As Boolean
    Dim recoveryAttempted As Boolean, recoveryTerminalFailure As Boolean
    Dim workbookSavedCaptured As Boolean, c As Long
    Dim errorNumber As Long, errorDescription As String
    Dim errorSource As String, eventStateDetail As String
    Dim eventRestoreDetail As String, cleanupDetail As String
    If Not SheetExists(SH_ANALYSIS_DETAIL) Then Exit Sub
    Set ws = GetSheet(SH_ANALYSIS_DETAIL)
    lastR = LastUsedRowInSheet(ws)
    If lastR >= 1 Then
        selectionData = ws.Range(ws.Cells(1, DETAIL_COL_KIND), _
                                 ws.Cells(lastR, DETAIL_COL_SELECTED)).Value2
        For r = 1 To UBound(selectionData, 1)
            If CellText(selectionData(r, 1)) = "���" And _
               CellText(selectionData( _
                            r, DETAIL_COL_SELECTED - DETAIL_COL_KIND + 1)) = "1" Then _
                selectedCount = selectedCount + 1
        Next r
        If selectedCount > 0 Then
            ReDim selectedRows(1 To selectedCount)
            For r = 1 To UBound(selectionData, 1)
                If CellText(selectionData(r, 1)) = "���" And _
                   CellText(selectionData( _
                                r, DETAIL_COL_SELECTED - DETAIL_COL_KIND + 1)) = "1" Then
                    selectedIndex = selectedIndex + 1
                    selectedRows(selectedIndex) = r
                End If
            Next r
        End If
    End If
    If Not TryGetAnalysisWorkspaceEnableEvents( _
               previousEvents, eventStateDetail) Then
        On Error Resume Next
        MsgBox "����I���̉����O��Excel�C�x���g�̊J�n��Ԃ��擾�ł��܂���ł����B" & _
               vbCrLf & "�u�b�N�ւ̕ύX�͍s���Ă��܂���B", _
               vbCritical, "Excel�C�x���g��Ԃ��m�F�ł��܂���"
        On Error GoTo 0
        Err.Raise vbObjectError + 4909, _
                  "ClearAnalysisDetailTransactionSelections", _
                  "Excel�C�x���g�̊J�n��Ԃ��擾�ł��܂���ł����B " & _
                  eventStateDetail
    End If
    eventsCaptured = True
    If Not TrySetAnalysisWorkspaceEnableEventsExact(False, eventStateDetail) Then
        errorDescription = _
            "����I���̉����O��Excel�C�x���g��False�֒�~����" & _
            "�ǖ߂��m�F�ł��܂���ł����B�u�b�N�ւ̕ύX�͍s���Ă��܂���B " & _
            eventStateDetail
        eventsRestored = TryRestoreAnalysisWorkspaceEnableEvents( _
                             previousEvents, _
                             "ClearAnalysisDetailTransactionSelections/�ύX�J�n�O", _
                             recoveryAttempted, recoveryTerminalFailure, _
                             eventRestoreDetail)
        eventsCaptured = False
        If Not eventsRestored Then _
            AppendAnalysisWorkspaceRollbackDetail errorDescription, _
                "Excel�C�x���g�J�n�l�̕���������: " & eventRestoreDetail
        If recoveryAttempted Or recoveryTerminalFailure Then _
            RaiseAnalysisWorkspaceLocalRecoveryFatal _
                "ClearAnalysisDetailTransactionSelections", _
                vbObjectError + 4910, _
                "ClearAnalysisDetailTransactionSelections", _
                errorDescription, eventRestoreDetail
        Err.Raise vbObjectError + 4910, _
                  "ClearAnalysisDetailTransactionSelections", errorDescription
    End If
    On Error GoTo EH
    workbookWasSaved = ThisWorkbook.Saved
    workbookSavedCaptured = True
    CaptureAnalysisDetailSelectionSnapshot _
        ws, selectedRows, selectedCount, snapshot
    snapshotCaptured = True
    mutationStarted = True
    ws.Unprotect Password:=TOOL_PASSWORD
    For selectedIndex = 1 To selectedCount
        r = selectedRows(selectedIndex)
        ws.Cells(r, DETAIL_COL_SELECTED).Value2 = "0"
        If CellText(selectionData( _
                        r, DETAIL_COL_SOURCE_KEY - DETAIL_COL_KIND + 1)) = "GLOBAL" Then _
            ws.Cells(r, 1).Value2 = "���I��"
        '�����X�V�͑I������Ă��������s�����Ɍ��肷��B
        ws.Range(ws.Cells(r, 1), ws.Cells(r, 7)).Interior.Color = vbWhite
        ws.Range(ws.Cells(r, 1), ws.Cells(r, 7)).Font.Bold = False
        If ws.Cells(r, DETAIL_COL_SELECTED).HasFormula Or _
           Not StrictVariantValuesMatch( _
                   "0", ws.Cells(r, DETAIL_COL_SELECTED).Value2) Then _
            Err.Raise vbObjectError + 4911, _
                      "ClearAnalysisDetailTransactionSelections", _
                      CStr(r) & "�s�ڂ̎���I���t���O�������ɉ����ł��܂���B"
        If CellText(selectionData( _
                        r, DETAIL_COL_SOURCE_KEY - DETAIL_COL_KIND + 1)) = "GLOBAL" Then
            If ws.Cells(r, 1).HasFormula Or _
               Not StrictVariantValuesMatch("���I��", ws.Cells(r, 1).Value2) Then _
                Err.Raise vbObjectError + 4912, _
                          "ClearAnalysisDetailTransactionSelections", _
                          CStr(r) & "�s�ڂ̎���I��\���������ɉ����ł��܂���B"
        End If
        For c = 1 To 7
            If CLng(ws.Cells(r, c).Interior.Color) <> vbWhite Or _
               CBool(ws.Cells(r, c).Font.Bold) Then _
                Err.Raise vbObjectError + 4913, _
                          "ClearAnalysisDetailTransactionSelections", _
                          CStr(r) & "�s�ڂ̎���I�������������ɉ����ł��܂���B"
        Next c
    Next selectedIndex
    RefreshManualSelectionSummary ws
    ProtectSingleAnalysisSheet ws
    protectionConfirmed = ws.ProtectContents And ws.ProtectDrawingObjects
    If Not protectionConfirmed Then _
        Err.Raise vbObjectError + 4914, _
                  "ClearAnalysisDetailTransactionSelections", _
                  "����I��������̃Z���E�}�`�ی�𗼕�True�Ƃ��Ċm�F�ł��܂���B"
    If workbookWasSaved Then
        ThisWorkbook.Saved = True
        If Not ThisWorkbook.Saved Then _
            Err.Raise vbObjectError + 4915, _
                      "ClearAnalysisDetailTransactionSelections", _
                      "�ĕی��Ƀu�b�N�ۑ���Ԃ��J�n�l�֕����ł��܂���ł����B"
    End If
    On Error GoTo 0
    eventsRestored = TryRestoreAnalysisWorkspaceEnableEvents( _
                         previousEvents, _
                         "ClearAnalysisDetailTransactionSelections/����I��", _
                         recoveryAttempted, recoveryTerminalFailure, _
                         eventRestoreDetail)
    eventsCaptured = False
    If recoveryAttempted Or recoveryTerminalFailure Then _
        RaiseAnalysisWorkspaceLocalRecoveryFatal _
            "ClearAnalysisDetailTransactionSelections", _
            vbObjectError + 4916, _
            "ClearAnalysisDetailTransactionSelections", _
            "����I������Excel�C�x���g�J�n�l������local Recovery�����s���܂����B", _
            eventRestoreDetail
    If Not eventsRestored Then _
        Err.Raise vbObjectError + 4916, _
                  "ClearAnalysisDetailTransactionSelections", eventRestoreDetail
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    If IsAnalysisWorkspaceRecoveryFatalError(errorNumber, errorSource) Then _
        RethrowAnalysisWorkspaceUpstreamRecoveryFatal _
            errorNumber, errorSource, errorDescription, _
            "ClearAnalysisDetailTransactionSelections"
    If eventsCaptured Then
        recoverySafeForEventRestore = False
        If TryStopAnalysisWorkspaceEventsForBookWrites(eventStateDetail) Then
            recoverySafeForEventRestore = _
                RecoverAnalysisDetailSelectionMutation( _
                    ws, snapshot, snapshotCaptured, mutationStarted, _
                    workbookSavedCaptured, workbookWasSaved, _
                    "ClearAnalysisDetailTransactionSelections", _
                    errorNumber, errorSource, errorDescription, _
                    recoveryAttempted, recoveryTerminalFailure, cleanupDetail)
            AppendAnalysisWorkspaceRollbackDetail errorDescription, cleanupDetail
        Else
            AppendAnalysisWorkspaceRollbackDetail errorDescription, _
                "Excel�C�x���g��False�֒�~���ēǖ߂��m�F�ł��Ȃ����߁A" & _
                "���[���o�b�N�E�ĕی�ERecovery�E�f�f�E��ԕ\���E" & _
                "�ۑ���Ԃւ̏����݂�������܂����B�Č��̈��S��Ԃ͕s���ł�: " & _
                eventStateDetail
            On Error Resume Next
            MsgBox "����I���̉����Ɏ��s���AExcel�C�x���g�����S�ɒ�~�ł��܂���ł����B" & _
                   vbCrLf & "�u�b�N�ւ̕��������݂͍s���Ă��܂���B" & _
                   vbCrLf & "���݂̃u�b�N���㏑�����Ȃ��ł��������B", _
                   vbCritical, "����I���̈��S��Ԃ��m�F�ł��܂���"
            On Error GoTo 0
        End If
        If recoverySafeForEventRestore Then
            eventsRestored = TryRestoreAnalysisWorkspaceEnableEvents( _
                                 previousEvents, _
                                 "ClearAnalysisDetailTransactionSelections/�ُ�I��", _
                                 recoveryAttempted, recoveryTerminalFailure, _
                                 eventRestoreDetail)
        Else
            eventsRestored = False
            If TryStopAnalysisWorkspaceEventsForBookWrites(eventRestoreDetail) Then
                AppendAnalysisWorkspaceRollbackDetail errorDescription, _
                    "���[���o�b�N���S�܂���Recovery exact���m�F�ł��Ȃ����߁A" & _
                    "Excel�C�x���g��False�̂܂ܒ�~���܂����B"
                eventRestoreDetail = _
                    "���S��Ԗ��m�F�̂��ߊJ�n�l�ւ̕��������s���Ă��܂���B"
            Else
                AppendAnalysisWorkspaceRollbackDetail errorDescription, _
                    "���S��Ԃ��m�F�ł����AExcel�C�x���g��False�����ɂ����s���܂���: " & _
                    eventRestoreDetail
            End If
        End If
        eventsCaptured = False
        If Not eventsRestored Then _
            AppendAnalysisWorkspaceRollbackDetail errorDescription, _
                "Excel�C�x���g���������𐳏튮���Ƃ��Ĉ����܂���: " & eventRestoreDetail
    End If
    If recoveryAttempted Or recoveryTerminalFailure Then _
        RaiseAnalysisWorkspaceLocalRecoveryFatal _
            "ClearAnalysisDetailTransactionSelections", _
            errorNumber, errorSource, errorDescription, _
            cleanupDetail & " / " & eventRestoreDetail
    Err.Raise errorNumber, "ClearAnalysisDetailTransactionSelections", _
              IIf(Len(errorSource) > 0, _
                  errorSource & " / ", vbNullString) & errorDescription
End Sub

Private Sub CaptureAnalysisDetailSelectionSnapshot( _
        ByVal ws As Worksheet, ByRef targetRows() As Long, _
        ByVal itemCount As Long, _
        ByRef snapshot As AnalysisDetailSelectionSnapshot)
    Dim i As Long, c As Long, formatIndex As Long, targetRow As Long
    Dim targetCell As Range
    If ws Is Nothing Or itemCount < 0 Then _
        Err.Raise vbObjectError + 4917, _
                  "CaptureAnalysisDetailSelectionSnapshot", _
                  "����I����Ԃ̑ޔ��������s���ł��B"
    snapshot.ItemCount = itemCount
    If itemCount > 0 Then
        ReDim snapshot.Rows(1 To itemCount)
        ReDim snapshot.SelectedValues(1 To itemCount)
        ReDim snapshot.SelectedHasFormula(1 To itemCount)
        ReDim snapshot.SelectedFormulas(1 To itemCount)
        ReDim snapshot.DisplayValues(1 To itemCount)
        ReDim snapshot.DisplayHasFormula(1 To itemCount)
        ReDim snapshot.DisplayFormulas(1 To itemCount)
        ReDim snapshot.FillColors(1 To itemCount * 7)
        ReDim snapshot.FillPatterns(1 To itemCount * 7)
        ReDim snapshot.FillTints(1 To itemCount * 7)
        ReDim snapshot.FontBolds(1 To itemCount * 7)
    End If
    For i = 1 To itemCount
        targetRow = targetRows(i)
        If targetRow < 1 Or targetRow > LastUsedRowInSheet(ws) Then _
            Err.Raise vbObjectError + 4918, _
                      "CaptureAnalysisDetailSelectionSnapshot", _
                      "����I����Ԃ�ޔ�����s���s���ł�: " & CStr(targetRow)
        snapshot.Rows(i) = targetRow
        Set targetCell = ws.Cells(targetRow, DETAIL_COL_SELECTED)
        snapshot.SelectedValues(i) = targetCell.Value2
        snapshot.SelectedHasFormula(i) = targetCell.HasFormula
        If snapshot.SelectedHasFormula(i) Then _
            snapshot.SelectedFormulas(i) = CStr(targetCell.Formula)
        Set targetCell = ws.Cells(targetRow, 1)
        snapshot.DisplayValues(i) = targetCell.Value2
        snapshot.DisplayHasFormula(i) = targetCell.HasFormula
        If snapshot.DisplayHasFormula(i) Then _
            snapshot.DisplayFormulas(i) = CStr(targetCell.Formula)
        For c = 1 To 7
            formatIndex = (i - 1) * 7 + c
            Set targetCell = ws.Cells(targetRow, c)
            snapshot.FillColors(formatIndex) = CLng(targetCell.Interior.Color)
            snapshot.FillPatterns(formatIndex) = CLng(targetCell.Interior.Pattern)
            snapshot.FillTints(formatIndex) = CDbl(targetCell.Interior.TintAndShade)
            snapshot.FontBolds(formatIndex) = CBool(targetCell.Font.Bold)
        Next c
    Next i
    Set targetCell = ws.Range("A2")
    snapshot.SummaryValue = targetCell.Value2
    snapshot.SummaryHasFormula = targetCell.HasFormula
    If snapshot.SummaryHasFormula Then _
        snapshot.SummaryFormula = CStr(targetCell.Formula)
End Sub

Private Function TryRestoreAnalysisDetailSelectionSnapshot( _
        ByVal ws As Worksheet, _
        ByRef snapshot As AnalysisDetailSelectionSnapshot, _
        ByRef detailText As String) As Boolean
    Dim i As Long, c As Long, formatIndex As Long, targetRow As Long
    Dim targetCell As Range
    detailText = vbNullString
    On Error GoTo EH
    If ws Is Nothing Or snapshot.ItemCount < 0 Then _
        Err.Raise vbObjectError + 4919, _
                  "TryRestoreAnalysisDetailSelectionSnapshot", _
                  "����I����Ԃ̕����������s���ł��B"
    ws.Unprotect Password:=TOOL_PASSWORD
    For i = 1 To snapshot.ItemCount
        targetRow = snapshot.Rows(i)
        Set targetCell = ws.Cells(targetRow, DETAIL_COL_SELECTED)
        RestoreAnalysisDetailSelectionCell targetCell, _
            snapshot.SelectedValues(i), snapshot.SelectedHasFormula(i), _
            snapshot.SelectedFormulas(i), _
            CStr(targetRow) & "�s�ڂ̑I���t���O"
        Set targetCell = ws.Cells(targetRow, 1)
        RestoreAnalysisDetailSelectionCell targetCell, _
            snapshot.DisplayValues(i), snapshot.DisplayHasFormula(i), _
            snapshot.DisplayFormulas(i), _
            CStr(targetRow) & "�s�ڂ̑I��\��"
        For c = 1 To 7
            formatIndex = (i - 1) * 7 + c
            Set targetCell = ws.Cells(targetRow, c)
            With targetCell.Interior
                .Color = snapshot.FillColors(formatIndex)
                .TintAndShade = snapshot.FillTints(formatIndex)
                .Pattern = snapshot.FillPatterns(formatIndex)
            End With
            targetCell.Font.Bold = snapshot.FontBolds(formatIndex)
            If CLng(targetCell.Interior.Pattern) <> _
                   snapshot.FillPatterns(formatIndex) Then _
                Err.Raise vbObjectError + 4920, _
                          "TryRestoreAnalysisDetailSelectionSnapshot", _
                          CStr(targetRow) & "�s�ڂ̓h��p�^�[���𕜌��ł��܂���B"
            If snapshot.FillPatterns(formatIndex) <> xlNone Then
                If CLng(targetCell.Interior.Color) <> _
                       snapshot.FillColors(formatIndex) Or _
                   CDbl(targetCell.Interior.TintAndShade) <> _
                       snapshot.FillTints(formatIndex) Then _
                    Err.Raise vbObjectError + 4921, _
                              "TryRestoreAnalysisDetailSelectionSnapshot", _
                              CStr(targetRow) & "�s�ڂ̓h��F�𕜌��ł��܂���B"
            End If
            If CBool(targetCell.Font.Bold) <> _
                   snapshot.FontBolds(formatIndex) Then _
                Err.Raise vbObjectError + 4922, _
                          "TryRestoreAnalysisDetailSelectionSnapshot", _
                          CStr(targetRow) & "�s�ڂ̑�����Ԃ𕜌��ł��܂���B"
        Next c
    Next i
    RestoreAnalysisDetailSelectionCell ws.Range("A2"), _
        snapshot.SummaryValue, snapshot.SummaryHasFormula, _
        snapshot.SummaryFormula, "�蓮�o�^�̑I���W�v"
    TryRestoreAnalysisDetailSelectionSnapshot = True
    Exit Function
EH:
    detailText = "����I����Ԃ̕����G���[: Err " & _
                 CStr(Err.Number) & " " & Err.Description
    Err.Clear
End Function

Private Sub RestoreAnalysisDetailSelectionCell( _
        ByVal targetCell As Range, ByVal expectedValue As Variant, _
        ByVal expectedHasFormula As Boolean, ByVal expectedFormula As String, _
        ByVal labelText As String)
    If targetCell Is Nothing Or targetCell.Cells.CountLarge <> 1 Then _
        Err.Raise vbObjectError + 4923, _
                  "RestoreAnalysisDetailSelectionCell", _
                  labelText & "�̕����悪�P��Z���ł͂���܂���B"
    If expectedHasFormula Then
        targetCell.Formula = expectedFormula
        If Not targetCell.HasFormula Or _
           StrComp(CStr(targetCell.Formula), _
                   expectedFormula, vbBinaryCompare) <> 0 Then _
            Err.Raise vbObjectError + 4924, _
                      "RestoreAnalysisDetailSelectionCell", _
                      labelText & "�̐����������ɕ����ł��܂���B"
    Else
        targetCell.Value2 = expectedValue
        If targetCell.HasFormula Or _
           Not StrictVariantValuesMatch(expectedValue, targetCell.Value2) Then _
            Err.Raise vbObjectError + 4925, _
                      "RestoreAnalysisDetailSelectionCell", _
                      labelText & "�̒l���^�܂Ō����ɕ����ł��܂���B"
    End If
End Sub

Private Function TryEmergencyProtectAnalysisDetailSelectionSheet( _
        ByVal ws As Worksheet, ByRef detailText As String) As Boolean
    detailText = vbNullString
    On Error GoTo EH
    If ws Is Nothing Then _
        Err.Raise vbObjectError + 4926, _
                  "TryEmergencyProtectAnalysisDetailSelectionSheet", _
                  "�ً}�ĕی삷����ڍ׃V�[�g���擾�ł��܂���B"
    EmergencyProtectToolSheet ws
    If Not ws.ProtectContents Or Not ws.ProtectDrawingObjects Then _
        Err.Raise vbObjectError + 4927, _
                  "TryEmergencyProtectAnalysisDetailSelectionSheet", _
                  "�ً}�ĕی��̃Z���E�}�`�ی�𗼕�True�Ƃ��Ċm�F�ł��܂���B"
    TryEmergencyProtectAnalysisDetailSelectionSheet = True
    Exit Function
EH:
    detailText = "���ڍׂً̋}�ĕی�G���[: Err " & _
                 CStr(Err.Number) & " " & Err.Description
    Err.Clear
End Function

Private Function RecoverAnalysisDetailSelectionMutation( _
        ByVal ws As Worksheet, _
        ByRef snapshot As AnalysisDetailSelectionSnapshot, _
        ByVal snapshotCaptured As Boolean, ByVal mutationStarted As Boolean, _
        ByVal workbookSavedCaptured As Boolean, ByVal workbookWasSaved As Boolean, _
        ByVal operationName As String, _
        ByVal originalErrorNumber As Long, _
        ByVal originalErrorSource As String, _
        ByVal originalErrorDescription As String, _
        ByRef recoveryAttempted As Boolean, _
        ByRef recoveryTerminalFailure As Boolean, _
        ByRef detailText As String) As Boolean
    Dim rollbackOK As Boolean, protectionOK As Boolean
    Dim savedRestored As Boolean, recoveryCallOK As Boolean
    Dim rollbackDetail As String, protectionDetail As String
    Dim recoveryDetail As String, savedDetail As String
    Dim savedErrorNumber As Long, savedErrorDescription As String
    detailText = vbNullString
    If Not mutationStarted Then
        RecoverAnalysisDetailSelectionMutation = True
        Exit Function
    End If
    If snapshotCaptured Then
        rollbackOK = TryRestoreAnalysisDetailSelectionSnapshot( _
                         ws, snapshot, rollbackDetail)
    Else
        rollbackDetail = "����I����Ԃ̑ޔ����Ȃ����ߕ����ł��܂���B"
    End If
    protectionOK = _
        TryEmergencyProtectAnalysisDetailSelectionSheet(ws, protectionDetail)
    If rollbackOK And protectionOK Then
        AppendAnalysisWorkspaceRollbackDetail detailText, _
            "����I����Ԃ��J�n�l�֕������A�Z���E�}�`�̍ĕی���m�F���܂����B"
        If workbookSavedCaptured And workbookWasSaved Then
            On Error Resume Next
            Err.Clear
            ThisWorkbook.Saved = True
            savedErrorNumber = Err.Number
            savedErrorDescription = Err.Description
            Err.Clear
            If savedErrorNumber = 0 Then
                savedRestored = ThisWorkbook.Saved
                savedErrorNumber = Err.Number
                savedErrorDescription = Err.Description
                Err.Clear
            End If
            On Error GoTo 0
            If Not savedRestored Then
                savedDetail = "�ĕی��̕ۑ���Ԃ��J�n�l�֕����ł��܂���B"
                If savedErrorNumber <> 0 Then _
                    savedDetail = savedDetail & " Err " & _
                                  CStr(savedErrorNumber) & " " & savedErrorDescription
                AppendAnalysisWorkspaceRollbackDetail detailText, savedDetail
            End If
        End If
        RecoverAnalysisDetailSelectionMutation = True
        Exit Function
    End If
    AppendAnalysisWorkspaceRollbackDetail recoveryDetail, rollbackDetail
    AppendAnalysisWorkspaceRollbackDetail recoveryDetail, protectionDetail
    If Not rollbackOK Then _
        AppendAnalysisWorkspaceRollbackDetail recoveryDetail, _
            "����I����Ԃ��J�n�l�֌����ɕ����ł��܂���B"
    If Not protectionOK Then _
        AppendAnalysisWorkspaceRollbackDetail recoveryDetail, _
            "���ڍׂ̃Z���E�}�`�ی�𗼕�True�Ƃ��Ċm�F�ł��܂���B"
    recoveryCallOK = StopAfterAnalysisWorkspaceEventStateFailure( _
                         operationName & "/���[���o�b�N�܂��͍ĕی�", _
                         recoveryDetail, recoveryAttempted, _
                         recoveryTerminalFailure, originalErrorNumber, _
                         originalErrorSource, originalErrorDescription)
    If Not recoveryCallOK Then _
        AppendAnalysisWorkspaceRollbackDetail recoveryDetail, _
            "�Ɨ����b�`�ƈČ�health��Recovery��Ԃ������m�F�ł��܂���ł����B"
    AppendAnalysisWorkspaceRollbackDetail detailText, recoveryDetail
    RecoverAnalysisDetailSelectionMutation = recoveryCallOK
End Function

Private Sub RefreshManualSelectionSummary(ByVal ws As Worksheet)
    Dim lastR As Long, r As Long
    Dim withdrawalIndex As Long, depositIndex As Long
    Dim withdrawalValue As Double, depositValue As Double
    Dim withdrawCount As Long, depositCount As Long
    Dim withdrawTotal As Double, depositTotal As Double
    Dim summaryData As Variant
    If ws Is Nothing Then Exit Sub
    If CellText(ws.Cells(2, DETAIL_COL_KIND).Value) <> "�蓮�o�^" Then Exit Sub
    lastR = LastUsedRowInSheet(ws)
    If lastR >= MANUAL_BUILDER_HEADER_ROW + 1 Then
        '�_�u���N���b�N�̂��тɍő�5���s���Z���P�ʂœǂނƑ��삪�~�܂邽�߁A
        '�\����D�`G�Ɠ�����H�`L����x�����z��֓ǂݍ���ŏW�v����B
        summaryData = ws.Range( _
            ws.Cells(MANUAL_BUILDER_HEADER_ROW + 1, 4), _
            ws.Cells(lastR, DETAIL_COL_SELECTED)).Value2
        For r = 1 To UBound(summaryData, 1)
            If CellText(summaryData(r, DETAIL_COL_KIND - 4 + 1)) = "���" And _
               CellText(summaryData(r, DETAIL_COL_SELECTED - 4 + 1)) = "1" Then
                If CellText(summaryData(r, DETAIL_COL_SOURCE_KEY - 4 + 1)) = "GLOBAL" Then
                    withdrawalIndex = 1
                    depositIndex = 2
                Else
                    withdrawalIndex = 2
                    depositIndex = 3
                End If
                withdrawalValue = WorkspaceDouble(summaryData(r, withdrawalIndex))
                depositValue = WorkspaceDouble(summaryData(r, depositIndex))
                If withdrawalValue > 0 Then
                    withdrawCount = withdrawCount + 1
                    withdrawTotal = withdrawTotal + withdrawalValue
                End If
                If depositValue > 0 Then
                    depositCount = depositCount + 1
                    depositTotal = depositTotal + depositValue
                End If
            End If
        Next r
    End If
    If withdrawCount + depositCount = 0 Then
        ws.Range("A2").Value = _
            "������_�u���N���b�N���đI�� �� ���̈ē��s���_�u���N���b�N���ēo�^"
    Else
        ws.Range("A2").Value = "�I�𒆁F�o�� " & CStr(withdrawCount) & "�� " & _
            Format$(withdrawTotal, "#,##0.########") & "�~�@�^�@���� " & _
            CStr(depositCount) & "�� " & Format$(depositTotal, "#,##0.########") & _
            "�~�@�^�@���z " & Format$(depositTotal - withdrawTotal, "+#,##0.########;-#,##0.########;0") & _
            "�~�@�b�@���̍s���_�u���N���b�N���ēo�^"
    End If
End Sub

Public Function IsManualAnalysisDetailAlternative(ByVal targetRow As Long) As Boolean
    Dim wsDetail As Worksheet, wsFlow As Worksheet, sourceRow As Long
    If Not SheetExists(SH_ANALYSIS_DETAIL) Or Not SheetExists(SH_ANALYSIS_FLOW) Then Exit Function
    Set wsDetail = GetSheet(SH_ANALYSIS_DETAIL)
    If targetRow < 1 Or targetRow > LastUsedRowInSheet(wsDetail) Then Exit Function
    If CellText(wsDetail.Cells(targetRow, DETAIL_COL_KIND).Value) <> "���" Or _
       CellText(wsDetail.Cells(targetRow, DETAIL_COL_REFERENCE).Value) <> SH_ANALYSIS_FLOW Then Exit Function
    sourceRow = WorkspaceLong(wsDetail.Cells(targetRow, DETAIL_COL_SOURCE_ROW).Value)
    Set wsFlow = GetSheet(SH_ANALYSIS_FLOW)
    If sourceRow >= 2 And sourceRow <= LastUsedRowInSheet(wsFlow) Then _
        IsManualAnalysisDetailAlternative = _
            (CellText(wsFlow.Cells(sourceRow, 3).Value) = "�蓮�w��")
End Function

Public Function AnalysisDetailStoredKey(ByVal targetRow As Long) As String
    If SheetExists(SH_ANALYSIS_DETAIL) Then _
        AnalysisDetailStoredKey = CellText(GetSheet(SH_ANALYSIS_DETAIL).Cells( _
                                                   targetRow, DETAIL_COL_SOURCE_KEY).Value)
End Function

Private Sub SyncWorkspaceSourceReviews(ByRef resultData As Variant, ByVal resultCount As Long, _
                                       ByVal targetSheetName As String)
    Dim wsSource As Worksheet, lastR As Long, sourceDataRows As Long
    Dim statusCol As Long, memoCol As Long, keyCol As Long
    Dim keyValues As Variant, seenTargets As Object
    Dim planRows() As Long, planStatuses() As String, planMemos() As String
    Dim planCount As Long, targetID As String
    Dim r As Long, sourceRow As Long, sourceIndex As Long
    Dim sourceKey As String, statusText As String, memoText As String, categoryText As String
    If Not WorkspaceSourceColumns(targetSheetName, statusCol, memoCol, keyCol) Then Exit Sub
    If resultCount < 1 Then Exit Sub
    Set wsSource = GetSheet(targetSheetName)
    If Not TryGetLastUsedRowInSheet(wsSource, lastR) Then _
        Err.Raise vbObjectError + 4806, "SyncWorkspaceSourceReviews", _
                  targetSheetName & "�̍ŏI�s���m�F�ł��܂���B"
    If lastR < 2 Then
        For r = 1 To resultCount
            If StrComp(CellText(resultData(r, ANALYSIS_RESULT_SOURCE_SHEET_COL)), _
                       targetSheetName, vbTextCompare) = 0 Then _
                Err.Raise vbObjectError + 4806, "SyncWorkspaceSourceReviews", _
                          "���͌��� " & CStr(r + 1) & "�s�ڂ̓������\�Ɍ�₪����܂���B"
        Next r
        Exit Sub
    End If
    sourceDataRows = lastR - 1
    keyValues = wsSource.Range(wsSource.Cells(2, keyCol), wsSource.Cells(lastR, keyCol)).Value2
    ReDim planRows(1 To resultCount)
    ReDim planStatuses(1 To resultCount)
    ReDim planMemos(1 To resultCount)
    Set seenTargets = CreateObject("Scripting.Dictionary")
    seenTargets.CompareMode = vbTextCompare
    For r = 1 To resultCount
        If StrComp(CellText(resultData(r, ANALYSIS_RESULT_SOURCE_SHEET_COL)), _
                   targetSheetName, vbTextCompare) = 0 Then
            sourceRow = WorkspaceLong(resultData(r, ANALYSIS_RESULT_SOURCE_ROW_COL))
            sourceIndex = sourceRow - 1
            If sourceIndex < 1 Or sourceIndex > sourceDataRows Then _
                Err.Raise vbObjectError + 4806, "SyncWorkspaceSourceReviews", _
                          "���͌��� " & CStr(r + 1) & "�s�ڂ̓������s��������܂���B"
            sourceKey = CellText(resultData(r, ANALYSIS_RESULT_SOURCE_KEY_COL))
            If StrComp(CellText(WorkspaceColumnArrayValue(keyValues, sourceIndex, sourceDataRows)), _
                       sourceKey, vbBinaryCompare) <> 0 Then _
                Err.Raise vbObjectError + 4807, "SyncWorkspaceSourceReviews", _
                          "���͌��� " & CStr(r + 1) & "�s�ڂƓ��������\�̊m�F�L�[����v���܂���B"
            statusText = WorkspaceStatusOrDefault(resultData(r, ANALYSIS_RESULT_STATUS_COL))
            memoText = CellText(resultData(r, ANALYSIS_RESULT_MEMO_COL))
            categoryText = CellText(resultData(r, 2))
            If Len(memoText) > WORKSPACE_MEMO_MAX Then _
                Err.Raise vbObjectError + 4808, "SyncWorkspaceSourceReviews", _
                          "���͌��� " & CStr(r + 1) & "�s�ڂ̊m�F�������������܂��B"
            If Not WorkspaceStatusFitsSource(targetSheetName, categoryText, statusText) Then _
                Err.Raise vbObjectError + 4809, "SyncWorkspaceSourceReviews", _
                          "���͌��� " & CStr(r + 1) & "�s�ڂ̊m�F�󋵂��敪�ɓK�����܂���B"
            targetID = CStr(sourceRow)
            If seenTargets.Exists(targetID) Then _
                Err.Raise vbObjectError + 4811, "SyncWorkspaceSourceReviews", _
                          "���͌��ʂɓ���������₪�d�����Ă��܂�: " & _
                          targetSheetName & " " & targetID & "�s"
            seenTargets.Add targetID, True
            planCount = planCount + 1
            planRows(planCount) = sourceRow
            planStatuses(planCount) = statusText
            planMemos(planCount) = memoText
        End If
    Next r
    For r = 1 To planCount
        WriteAnalysisReviewTextCellIfChanged wsSource.Cells(planRows(r), statusCol), _
            planStatuses(r), "���͌��ʂ̊m�F��"
        WriteAnalysisReviewTextCellIfChanged wsSource.Cells(planRows(r), memoCol), _
            planMemos(r), "���͌��ʂ̊m�F����"
    Next r
End Sub

Private Function WorkspaceColumnArrayValue(ByRef values As Variant, ByVal itemIndex As Long, _
                                           ByVal itemCount As Long) As Variant
    If itemCount = 1 Then
        WorkspaceColumnArrayValue = values
    Else
        WorkspaceColumnArrayValue = values(itemIndex, 1)
    End If
End Function

Private Function WorkspaceSourceColumns(ByVal sheetName As String, ByRef statusCol As Long, _
                                        ByRef memoCol As Long, ByRef keyCol As Long) As Boolean
    Select Case sheetName
        Case SH_ANALYSIS_SHIFT
            statusCol = SHIFT_ANALYSIS_STATUS_COL: memoCol = SHIFT_ANALYSIS_MEMO_COL
            keyCol = SHIFT_ANALYSIS_KEY_COL
        Case SH_ANALYSIS_FLOW
            statusCol = FLOW_ANALYSIS_STATUS_COL: memoCol = FLOW_ANALYSIS_MEMO_COL
            keyCol = FLOW_ANALYSIS_KEY_COL
        Case SH_ANALYSIS_UNKNOWN
            statusCol = UNKNOWN_ANALYSIS_STATUS_COL: memoCol = UNKNOWN_ANALYSIS_MEMO_COL
            keyCol = UNKNOWN_ANALYSIS_KEY_COL
        Case Else
            Exit Function
    End Select
    WorkspaceSourceColumns = True
End Function

Private Function WorkspaceStatusFitsSource(ByVal sourceSheet As String, ByVal categoryText As String, _
                                           ByVal statusText As String) As Boolean
    Select Case sourceSheet
        Case SH_ANALYSIS_SHIFT, SH_ANALYSIS_FLOW
            Select Case statusText
                Case ANALYSIS_STATUS_UNREVIEWED, ANALYSIS_STATUS_SHIFT_CONFIRMED, _
                     ANALYSIS_STATUS_EXCLUDED, ANALYSIS_STATUS_FOLLOWUP
                    WorkspaceStatusFitsSource = True
            End Select
        Case SH_ANALYSIS_UNKNOWN
            If StrComp(categoryText, "�����s��", vbTextCompare) = 0 Then
                Select Case statusText
                    Case ANALYSIS_STATUS_UNREVIEWED, ANALYSIS_STATUS_SOURCE_CONFIRMED, _
                         ANALYSIS_STATUS_EXCLUDED, ANALYSIS_STATUS_FOLLOWUP
                        WorkspaceStatusFitsSource = True
                End Select
            ElseIf StrComp(categoryText, "�g�r�s��", vbTextCompare) = 0 Then
                Select Case statusText
                    Case ANALYSIS_STATUS_UNREVIEWED, ANALYSIS_STATUS_USE_CONFIRMED, _
                         ANALYSIS_STATUS_EXCLUDED, ANALYSIS_STATUS_FOLLOWUP
                        WorkspaceStatusFitsSource = True
                End Select
            End If
    End Select
End Function

Public Sub FormatAnalysisWorkspaceSheets()
    Dim ws As Worksheet, dataCount As Long, lastDetailRow As Long
    If SheetExists(SH_ANALYSIS_RESULT) Then
        Set ws = GetSheet(SH_ANALYSIS_RESULT)
        dataCount = Application.Max(0, LastUsedRowInSheet(ws) - 1)
        FinalizeAnalysisResultSheet ws, dataCount
    End If
    If SheetExists(SH_ANALYSIS_DETAIL) Then
        Set ws = GetSheet(SH_ANALYSIS_DETAIL)
        ws.Unprotect Password:=TOOL_PASSWORD
        lastDetailRow = Application.Max(1, LastUsedRowInSheet(ws))
        With ws.Range("A1:L" & CStr(lastDetailRow))
            .Font.Name = "Yu Gothic UI"
            .Font.Size = 10
        End With
        ProtectSingleAnalysisSheet ws
    End If
End Sub

Public Sub CheckAnalysisWorkspace(ByRef problems As String, _
                                  ByRef interfaceWarnings As String, _
                                  ByVal includeInterfaceChecks As Boolean)
    Dim ws As Worksheet, wsGroup As Worksheet
    Dim lastR As Long, groupLastR As Long, r As Long
    Dim sourceStatusCol As Long, sourceMemoCol As Long, sourceKeyCol As Long
    Dim sourceSheet As String, sourceKey As String, categoryText As String, statusText As String
    Dim groupID As String, referenceKey As String, representativeText As String
    Dim resultData As Variant, groupData As Variant
    Dim groupCounts As Object, representativeRefs As Object, resultGroups As Object
    Dim validSourceRefs As Object
    Dim item As Variant, expectedCount As Long
    If Not SheetExists(SH_ANALYSIS_RESULT) Or Not SheetExists(SH_WORK_ANALYSIS_GROUP) Then Exit Sub
    Set ws = GetSheet(SH_ANALYSIS_RESULT)
    Set wsGroup = GetSheet(SH_WORK_ANALYSIS_GROUP)
    If includeInterfaceChecks Then
        If ws.Protection.AllowSorting Then _
            interfaceWarnings = interfaceWarnings & _
                                "�E���͌��ʂŕی쉺�̕��בւ����L���ł��B���ƍ����̑Ή�����邽�ߖ����ɂ��Ă�������" & vbCrLf
    End If
    Set groupCounts = CreateObject("Scripting.Dictionary")
    Set representativeRefs = CreateObject("Scripting.Dictionary")
    Set resultGroups = CreateObject("Scripting.Dictionary")
    Set validSourceRefs = CreateObject("Scripting.Dictionary")
    groupCounts.CompareMode = vbBinaryCompare
    representativeRefs.CompareMode = vbBinaryCompare
    resultGroups.CompareMode = vbBinaryCompare
    validSourceRefs.CompareMode = vbBinaryCompare
    AddWorkspaceSourceReferences SH_ANALYSIS_SHIFT, SHIFT_ANALYSIS_KEY_COL, validSourceRefs
    AddWorkspaceSourceReferences SH_ANALYSIS_FLOW, FLOW_ANALYSIS_KEY_COL, validSourceRefs
    AddWorkspaceSourceReferences SH_ANALYSIS_UNKNOWN, UNKNOWN_ANALYSIS_KEY_COL, validSourceRefs
    groupLastR = LastUsedRowInSheet(wsGroup)
    If groupLastR >= 2 Then
        groupData = wsGroup.Range(wsGroup.Cells(2, 1), _
                                  wsGroup.Cells(groupLastR, ANALYSIS_GROUP_LAST_COL)).Value2
        For r = 1 To UBound(groupData, 1)
            groupID = CellText(groupData(r, 1))
            sourceSheet = CellText(groupData(r, 2))
            sourceKey = CellText(groupData(r, 4))
            representativeText = CellText(groupData(r, 7))
            If Len(groupID) = 0 Then
                problems = problems & "�EW_���̓O���[�v " & CStr(r + 1) & "�s: �O���[�vID������܂���" & vbCrLf
            Else
                If groupCounts.Exists(groupID) Then
                    groupCounts(groupID) = CLng(groupCounts(groupID)) + 1
                Else
                    groupCounts.Add groupID, 1
                End If
            End If
            If Not WorkspaceSourceColumns(sourceSheet, sourceStatusCol, sourceMemoCol, sourceKeyCol) Then
                problems = problems & "�EW_���̓O���[�v " & CStr(r + 1) & "�s: ���\���s���ł�" & vbCrLf
            ElseIf WorkspaceLong(groupData(r, 3)) < 2 Then
                problems = problems & "�EW_���̓O���[�v " & CStr(r + 1) & "�s: ���s���s���ł�" & vbCrLf
            Else
                referenceKey = WorkspaceReferenceKey(sourceSheet, WorkspaceLong(groupData(r, 3)), sourceKey)
                If Not validSourceRefs.Exists(referenceKey) Then _
                    problems = problems & "�EW_���̓O���[�v " & CStr(r + 1) & "�s: ���\�̊m�F�L�[�ƈ�v���܂���" & vbCrLf
            End If
            If Len(sourceKey) = 0 Or Len(CellText(groupData(r, 5))) = 0 Then _
                problems = problems & "�EW_���̓O���[�v " & CStr(r + 1) & "�s: �m�F�L�[�܂��͎��ID������܂���" & vbCrLf
            If StrComp(representativeText, "��\", vbTextCompare) = 0 Then
                referenceKey = WorkspaceReferenceKey(sourceSheet, WorkspaceLong(groupData(r, 3)), sourceKey)
                If representativeRefs.Exists(groupID) Then
                    problems = problems & "�EW_���̓O���[�v " & CStr(r + 1) & "�s: ��\��₪�d�����Ă��܂�" & vbCrLf
                Else
                    representativeRefs.Add groupID, referenceKey
                End If
            ElseIf StrComp(representativeText, "���", vbTextCompare) <> 0 Then
                problems = problems & "�EW_���̓O���[�v " & CStr(r + 1) & "�s: �ʒu�t�����s���ł�" & vbCrLf
            End If
            If Len(problems) > 700000 Then Exit Sub
        Next r
    End If
    lastR = LastUsedRowInSheet(ws)
    If lastR >= 2 Then
        resultData = ws.Range(ws.Cells(2, 1), ws.Cells(lastR, ANALYSIS_RESULT_LAST_COL)).Value2
        For r = 1 To UBound(resultData, 1)
            sourceSheet = CellText(resultData(r, ANALYSIS_RESULT_SOURCE_SHEET_COL))
            sourceKey = CellText(resultData(r, ANALYSIS_RESULT_SOURCE_KEY_COL))
            categoryText = CellText(resultData(r, 2))
            statusText = WorkspaceStatusOrDefault(resultData(r, ANALYSIS_RESULT_STATUS_COL))
            groupID = CellText(resultData(r, ANALYSIS_RESULT_GROUP_ID_COL))
            If Len(sourceSheet) = 0 Or Len(sourceKey) = 0 Then
                problems = problems & "�E���͌��� " & CStr(r + 1) & "�s: �����Q�Ƃ�����܂���" & vbCrLf
            ElseIf Not WorkspaceSourceColumns(sourceSheet, sourceStatusCol, sourceMemoCol, sourceKeyCol) Then
                problems = problems & "�E���͌��� " & CStr(r + 1) & "�s: �������\���s���ł�" & vbCrLf
            ElseIf Not WorkspaceStatusFitsSource(sourceSheet, categoryText, statusText) Then
                problems = problems & "�E���͌��� " & CStr(r + 1) & "�s: �m�F�󋵂��敪�ɓK�����܂���" & vbCrLf
            End If
            If Len(CellText(resultData(r, ANALYSIS_RESULT_MEMO_COL))) > WORKSPACE_MEMO_MAX Then _
                problems = problems & "�E���͌��� " & CStr(r + 1) & "�s: �m�F�������������܂�" & vbCrLf
            If Len(groupID) = 0 Or Not groupCounts.Exists(groupID) Then
                problems = problems & "�E���͌��� " & CStr(r + 1) & "�s: �����O���[�v��������܂���" & vbCrLf
            Else
                expectedCount = WorkspaceLong(resultData(r, ANALYSIS_RESULT_ALTERNATIVE_COUNT_COL))
                If expectedCount <> CLng(groupCounts(groupID)) Then _
                    problems = problems & "�E���͌��� " & CStr(r + 1) & "�s: ��֌�␔�������\�ƈ�v���܂���" & vbCrLf
                If resultGroups.Exists(groupID) Then
                    problems = problems & "�E���͌��� " & CStr(r + 1) & "�s: �O���[�vID���d�����Ă��܂�" & vbCrLf
                Else
                    resultGroups.Add groupID, True
                End If
                referenceKey = WorkspaceReferenceKey(sourceSheet, _
                               WorkspaceLong(resultData(r, ANALYSIS_RESULT_SOURCE_ROW_COL)), sourceKey)
                If Not representativeRefs.Exists(groupID) Then
                    problems = problems & "�E���͌��� " & CStr(r + 1) & "�s: ��\��₪����܂���" & vbCrLf
                ElseIf StrComp(CStr(representativeRefs(groupID)), referenceKey, vbBinaryCompare) <> 0 Then
                    problems = problems & "�E���͌��� " & CStr(r + 1) & "�s: ��\���Q�Ƃ���v���܂���" & vbCrLf
                End If
            End If
            If Len(problems) > 700000 Then Exit Sub
        Next r
    End If
    If resultGroups.Count <> groupCounts.Count Then _
        problems = problems & "�E���͌��ʂ�W_���̓O���[�v�̃O���[�v��������v���܂���" & vbCrLf
    For Each item In groupCounts.Keys
        If Not representativeRefs.Exists(CStr(item)) Then _
            problems = problems & "�EW_���̓O���[�v: ��\��₪�Ȃ��O���[�v������܂�: " & CStr(item) & vbCrLf
        If Not resultGroups.Exists(CStr(item)) Then _
            problems = problems & "�EW_���̓O���[�v: ���͌��ʂɂȂ��O���[�v������܂�: " & CStr(item) & vbCrLf
        If Len(problems) > 700000 Then Exit For
    Next item
    If includeInterfaceChecks Then
        If Not ws.ProtectContents Then _
            interfaceWarnings = interfaceWarnings & "�E���͌��ʂ��ی삳��Ă��܂���" & vbCrLf
        If ws.Columns("J:O").Hidden = False Then _
            interfaceWarnings = interfaceWarnings & "�E���͌��ʂ̓����񂪕\������Ă��܂�" & vbCrLf
        If Not GetSheet(SH_ANALYSIS_DETAIL).ProtectContents Then _
            interfaceWarnings = interfaceWarnings & "�E���ڍׂ��ی삳��Ă��܂���" & vbCrLf
        If GetSheet(SH_ANALYSIS_DETAIL).Columns("H:L").Hidden = False Then _
            interfaceWarnings = interfaceWarnings & "�E���ڍׂ̓����񂪕\������Ă��܂�" & vbCrLf
        If wsGroup.Visible <> xlSheetVeryHidden Then _
            interfaceWarnings = interfaceWarnings & "�EW_���̓O���[�v��VeryHidden�ł͂���܂���" & vbCrLf
    End If
End Sub

Private Function WorkspaceReferenceKey(ByVal sourceSheet As String, ByVal sourceRow As Long, _
                                       ByVal sourceKey As String) As String
    WorkspaceReferenceKey = TransferLikeLengthPart(sourceSheet) & CStr(sourceRow) & "|" & _
                            TransferLikeLengthPart(sourceKey)
End Function

Private Sub AddWorkspaceSourceReferences(ByVal sourceSheet As String, ByVal keyColumn As Long, _
                                         ByVal target As Object)
    Dim ws As Worksheet, lastR As Long, dataCount As Long, r As Long
    Dim keyValues As Variant, sourceKey As String
    Set ws = GetSheet(sourceSheet)
    lastR = LastUsedRowInSheet(ws)
    If lastR < 2 Then Exit Sub
    dataCount = lastR - 1
    keyValues = ws.Range(ws.Cells(2, keyColumn), ws.Cells(lastR, keyColumn)).Value2
    For r = 1 To dataCount
        sourceKey = CellText(WorkspaceColumnArrayValue(keyValues, r, dataCount))
        If Len(sourceKey) > 0 Then _
            target(WorkspaceReferenceKey(sourceSheet, r + 1, sourceKey)) = True
    Next r
End Sub

Private Function TransferLikeLengthPart(ByVal valueText As String) As String
    TransferLikeLengthPart = CStr(Len(valueText)) & ":" & valueText & "|"
End Function

Public Sub OpenManualAnalysisCandidateBuilder()
    If Not SheetExists(SH_OUTPUT_TX) Then Exit Sub
    If ActiveSheet Is Nothing Then Exit Sub
    If ActiveSheet.Name <> SH_OUTPUT_TX Then
        MsgBox "�蓮���́A��������\�̏㕔�p�l������쐬���Ă��������B", _
               vbInformation, "��������\���ō쐬���܂�"
        Exit Sub
    End If
    CashAnalysisSecondaryAction
End Sub

Private Function TryCloseAnalysisWorkspaceApplicationLease( _
        ByRef applicationLeaseStarted As Boolean, _
        ByRef detailText As String) As Boolean
    Dim appEndErrorNumber As Long, appEndErrorDescription As String
    Dim forceErrorNumber As Long, forceErrorDescription As String

    detailText = vbNullString
    If Not applicationLeaseStarted Then
        TryCloseAnalysisWorkspaceApplicationLease = True
        Exit Function
    End If

    On Error Resume Next
    Err.Clear
    AppEnd
    appEndErrorNumber = Err.Number
    appEndErrorDescription = Err.Description
    Err.Clear
    If appEndErrorNumber = 0 Then
        applicationLeaseStarted = False
        On Error GoTo 0
        TryCloseAnalysisWorkspaceApplicationLease = True
        Exit Function
    End If

    'AppBegin������return�������Llease�������AAppEnd���s���Ɍ��苭����������B
    AppForceRestore
    forceErrorNumber = Err.Number
    forceErrorDescription = Err.Description
    Err.Clear
    On Error GoTo 0
    If forceErrorNumber = 0 Then
        applicationLeaseStarted = False
        TryCloseAnalysisWorkspaceApplicationLease = True
        Exit Function
    End If

    detailText = "Application lease�̏I���G���[: AppEnd Err " & _
                 CStr(appEndErrorNumber) & " " & appEndErrorDescription & _
                 " / AppForceRestore Err " & CStr(forceErrorNumber) & _
                 " " & forceErrorDescription
End Function

Private Sub LegacyOpenManualAnalysisCandidateBuilder()
    Dim wsTx As Worksheet, wsDetail As Worksheet
    Dim lastR As Long, r As Long, transactionCount As Long, matchCount As Long
    Dim data As Variant, outputData() As Variant, outputRow As Long
    Dim queryInput As Variant, queryText As String
    Dim directionText As String, amountValue As Double
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim eventStateDetail As String, applicationLeaseDetail As String
    Dim fatalContainmentRequired As Boolean
    Dim eventsStopped As Boolean
    Dim workbookWasSaved As Boolean, reviewsWerePending As Boolean
    Dim applicationLeaseStarted As Boolean
    Dim applicationLeaseCleanupAttempted As Boolean
    If Not RequireToolReady() Then Exit Sub
    If Not RequireNoPendingAccountInput("�蓮���͌��̍쐬") Then Exit Sub
    If Not RequireInternalStoresSafeForWrite(False, False) Then Exit Sub
    On Error GoTo EH
    workbookWasSaved = ThisWorkbook.Saved
    If HasSelectedAnalysisDetailTransactions() Then
        '�����I����PrepareAnalysisDetailSheet�Ŗق��ď������Ȃ��B�ĕ\�����āA
        '�o�^�܂��͖����I�ȑI�������𗘗p�҂֐�Ɋ������Ă��炤�B
        Set wsDetail = GetSheet(SH_ANALYSIS_DETAIL)
        SetSheetVeryHiddenSafe wsDetail
        ProtectSingleAnalysisSheet wsDetail
        MsgBox "���ڍׂɁA�蓮���Ƃ��Ė��o�^�̑I�����������܂��B" & vbCrLf & _
               "�\���������ڍׂŁA��Ɍ���o�^���邩�I�����������Ă��������B" & vbCrLf & _
               "���݂̑I����e��V�����ꗗ�ŏ㏑�����邱�Ƃ͂���܂���B", _
               vbInformation, "�����̎���I�����������Ă�������"
        Exit Sub
    End If
    reviewsWerePending = HasPendingAnalysisReviewChanges()
    CommitPendingAnalysisReviews False, "�蓮���쐬�O�̕��͔��f��ۑ�"
    Set wsTx = GetSheet(SH_WORK_TX)
    lastR = LastUsedRowInSheet(wsTx)
    If lastR < 2 Then
        MsgBox "�蓮���Ɏg�p�ł�����������܂���B", vbInformation
        Exit Sub
    End If
    data = wsTx.Range(wsTx.Cells(2, 1), _
                      wsTx.Cells(lastR, WORK_TX_COL_PERSON_ID)).Value2
    For r = 1 To UBound(data, 1)
        If CellText(data(r, WORK_TX_COL_RECORD_TYPE)) = RECORD_TRANSACTION Then _
            transactionCount = transactionCount + 1
    Next r
    If transactionCount = 0 Then
        MsgBox "�蓮���Ɏg�p�ł�����������܂���B", vbInformation
        Exit Sub
    End If
    If transactionCount > MANUAL_BUILDER_MAX_ROWS Then
        queryInput = Application.InputBox( _
            Prompt:="����� " & Format$(transactionCount, "#,##0") & _
                    "�����邽�߁A�\���Ώۂ�������ōi���Ă��������B" & vbCrLf & _
                    "��s�E�x�X�E�����E�����ԍ��E���t�E���z�E�E�v�����������܂��B" & vbCrLf & _
                    "�󔒋�؂��AND�A|�i�c���j��؂��OR�ł��B", _
            Title:="�蓮���Ɏg��������i�荞��", Type:=2)
        If VarType(queryInput) = vbBoolean Then
            If CBool(queryInput) = False Then Exit Sub
        End If
        queryText = Trim$(CStr(queryInput))
        If Len(queryText) = 0 Then
            MsgBox "��ʎ������x�ɕ\�����Ȃ����߁A���������͂��Ă��������B", vbInformation
            Exit Sub
        End If
    End If
    For r = 1 To UBound(data, 1)
        If CellText(data(r, WORK_TX_COL_RECORD_TYPE)) = RECORD_TRANSACTION Then
            If ManualBuilderRowMatches(data, r, queryText) Then matchCount = matchCount + 1
        End If
    Next r
    If matchCount = 0 Then
        MsgBox "���������Ɉ�v������������܂���B", vbInformation
        Exit Sub
    End If
    If matchCount > MANUAL_BUILDER_MAX_ROWS Then
        MsgBox "�������ʂ� " & Format$(matchCount, "#,##0") & _
               "������܂��B�������ǉ����� " & _
               Format$(MANUAL_BUILDER_MAX_ROWS, "#,##0") & _
               "���ȉ��֍i���Ă��������B", vbExclamation
        Exit Sub
    End If

    AppBegin "�蓮���p�̎���ꗗ���쐬���Ă��܂�..."
    applicationLeaseStarted = True
    ReDim outputData(1 To matchCount, 1 To DETAIL_COL_SELECTED)
    For r = 1 To UBound(data, 1)
        If CellText(data(r, WORK_TX_COL_RECORD_TYPE)) = RECORD_TRANSACTION And _
           ManualBuilderRowMatches(data, r, queryText) Then
            outputRow = outputRow + 1
            ManualBuilderDirectionAmount data, r, directionText, amountValue
            outputData(outputRow, 1) = "���I��"
            outputData(outputRow, 2) = Format$(CDate(data(r, OUT_COL_DATE)), "yyyy/m/d")
            If HasText(data(r, OUT_COL_TIME)) Then
                outputData(outputRow, 3) = Format$(CDate(data(r, OUT_COL_TIME)), "hh:mm")
            Else
                outputData(outputRow, 3) = "�����L�ڂȂ�"
            End If
            If directionText = "�o��" Then
                outputData(outputRow, 4) = amountValue
            Else
                outputData(outputRow, 5) = amountValue
            End If
            outputData(outputRow, 6) = ManualBuilderAccountText(data, r)
            outputData(outputRow, 7) = ManualBuilderSummaryText(data, r)
            outputData(outputRow, DETAIL_COL_KIND) = "���"
            outputData(outputRow, DETAIL_COL_REFERENCE) = _
                CellText(data(r, WORK_TX_COL_TRANSACTION_ID))
            outputData(outputRow, DETAIL_COL_SOURCE_ROW) = r + 1
            outputData(outputRow, DETAIL_COL_SOURCE_KEY) = "GLOBAL"
            outputData(outputRow, DETAIL_COL_SELECTED) = "0"
        End If
    Next r

    Set wsDetail = GetSheet(SH_ANALYSIS_DETAIL)
    PrepareAnalysisDetailSheet wsDetail
    SetSheetVeryHiddenSafe wsDetail
    wsDetail.Unprotect Password:=TOOL_PASSWORD
    MergeAndFormat wsDetail.Range("A1:G1"), "�蓮�̎����ړ������쐬"
    With wsDetail.Range("A1:G1")
        .Interior.Color = RGB(239, 246, 255)
        .Font.Color = RGB(30, 64, 175)
        .Font.Bold = True
        .Font.Size = 15
        .HorizontalAlignment = xlCenter
    End With
    MergeAndFormat wsDetail.Range("A2:G2"), _
        "������_�u���N���b�N���đI�� �� ���̈ē��s���_�u���N���b�N���ēo�^"
    With wsDetail.Range("A2:G2")
        .Interior.Color = RGB(254, 249, 195)
        .Font.Color = RGB(133, 77, 14)
        .Font.Bold = True
        .HorizontalAlignment = xlCenter
    End With
    wsDetail.Cells(2, DETAIL_COL_KIND).Value = "�蓮�o�^"
    MergeAndFormat wsDetail.Range("A3:G3"), _
        "�o���Ɠ������e1���ȏ�I�����Ă��������B�����̂Ȃ�����́u�����L�ڂȂ��v�A�������́u�����������s���v�Ƃ��Ĉ����܂��B"
    SetRowValues wsDetail.Cells(MANUAL_BUILDER_HEADER_ROW, 1), _
        Array("�I��", "���t", "����", "�o��", "����", "�����E���`", "�E�v�E�戵�X")
    FormatOutputHeader wsDetail.Range(wsDetail.Cells(MANUAL_BUILDER_HEADER_ROW, 1), _
                                      wsDetail.Cells(MANUAL_BUILDER_HEADER_ROW, 7))
    wsDetail.Range(wsDetail.Cells(MANUAL_BUILDER_HEADER_ROW + 1, 1), _
                   wsDetail.Cells(MANUAL_BUILDER_HEADER_ROW + matchCount, _
                                  DETAIL_COL_SELECTED)).Value = outputData
    wsDetail.Columns("A:A").ColumnWidth = 10
    wsDetail.Columns("B:B").ColumnWidth = 13
    wsDetail.Columns("C:C").ColumnWidth = 9
    wsDetail.Columns("D:E").ColumnWidth = 15.5
    wsDetail.Columns("F:F").ColumnWidth = 38
    wsDetail.Columns("G:G").ColumnWidth = 42
    wsDetail.Columns("D:E").NumberFormatLocal = "#,##0.########"
    wsDetail.Cells(MANUAL_BUILDER_HEADER_ROW, 4).Interior.Color = RGB(185, 28, 28)
    wsDetail.Cells(MANUAL_BUILDER_HEADER_ROW, 5).Interior.Color = RGB(29, 78, 216)
    wsDetail.Range(wsDetail.Cells(MANUAL_BUILDER_HEADER_ROW + 1, 4), _
                   wsDetail.Cells(MANUAL_BUILDER_HEADER_ROW + matchCount, 4)).Font.Color = RGB(153, 27, 27)
    wsDetail.Range(wsDetail.Cells(MANUAL_BUILDER_HEADER_ROW + 1, 5), _
                   wsDetail.Cells(MANUAL_BUILDER_HEADER_ROW + matchCount, 5)).Font.Color = RGB(30, 64, 175)
    With wsDetail.Range(wsDetail.Cells(MANUAL_BUILDER_HEADER_ROW + 1, 1), _
                        wsDetail.Cells(MANUAL_BUILDER_HEADER_ROW + matchCount, 7))
        .Borders.LineStyle = xlContinuous
        .Borders.Color = RGB(226, 232, 240)
        .VerticalAlignment = xlTop
        .WrapText = True
    End With
    wsDetail.Rows(CStr(MANUAL_BUILDER_HEADER_ROW + 1) & ":" & _
                  CStr(MANUAL_BUILDER_HEADER_ROW + matchCount)).RowHeight = 32
    wsDetail.Rows(1).RowHeight = 30
    wsDetail.Rows(2).RowHeight = 32
    wsDetail.Rows(3).RowHeight = 30
    wsDetail.Rows(MANUAL_BUILDER_HEADER_ROW).RowHeight = 30
    If wsDetail.AutoFilterMode Then wsDetail.AutoFilterMode = False
    wsDetail.Range(wsDetail.Cells(MANUAL_BUILDER_HEADER_ROW, 1), _
                   wsDetail.Cells(MANUAL_BUILDER_HEADER_ROW + matchCount, 7)).AutoFilter
    wsDetail.Columns("H:L").Hidden = True
    wsDetail.ScrollArea = "A1:G" & CStr(MANUAL_BUILDER_HEADER_ROW + matchCount + 20)
    RefreshManualSelectionSummary wsDetail
    ProtectSingleAnalysisSheet wsDetail
    mAnalysisDetailReviewsDirty = False
    If applicationLeaseStarted Then
        applicationLeaseCleanupAttempted = True
        If Not TryCloseAnalysisWorkspaceApplicationLease( _
                   applicationLeaseStarted, applicationLeaseDetail) Then
            Call TryStopAnalysisWorkspaceEventsForBookWrites(eventStateDetail)
            Err.Raise ANALYSIS_WORKSPACE_RECOVERY_FATAL_ERROR, _
                      ANALYSIS_WORKSPACE_RECOVERY_FATAL_SOURCE & _
                          "LegacyOpenManualAnalysisCandidateBuilder/ApplicationLease", _
                      applicationLeaseDetail
        End If
    End If
    If workbookWasSaved And Not reviewsWerePending Then ThisWorkbook.Saved = True
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    fatalContainmentRequired = _
        IsAnalysisWorkspaceRecoveryFatalError(errorNumber, errorSource)
    If fatalContainmentRequired Then _
        RethrowAnalysisWorkspaceUpstreamRecoveryFatal _
            errorNumber, errorSource, errorDescription, _
            "LegacyOpenManualAnalysisCandidateBuilder"
    '���Llease�̏I���Ɏ��s�����ꍇ�́A�ی�E��\���EUI�֐i�܂��I�[������B
    If applicationLeaseStarted And Not applicationLeaseCleanupAttempted Then
        applicationLeaseCleanupAttempted = True
        If Not TryCloseAnalysisWorkspaceApplicationLease( _
                   applicationLeaseStarted, applicationLeaseDetail) Then
            Call TryStopAnalysisWorkspaceEventsForBookWrites(eventStateDetail)
            Err.Raise ANALYSIS_WORKSPACE_RECOVERY_FATAL_ERROR, _
                      ANALYSIS_WORKSPACE_RECOVERY_FATAL_SOURCE & _
                          "LegacyOpenManualAnalysisCandidateBuilder/ApplicationLease", _
                      applicationLeaseDetail
        End If
    End If
    '�ی쏈�����̂̍Ď��s��Application lease�I���֓��B�ł��Ȃ���Ԃ����Ȃ��B
    On Error Resume Next
    ProtectSingleAnalysisSheet wsDetail
    SetSheetVeryHiddenSafe wsDetail
    On Error GoTo 0
    If IsUserCancelError(errorNumber) Then Exit Sub
    MsgBox "�蓮���p�̎���ꗗ���쐬�ł��܂���ł����B" & vbCrLf & _
           "Err " & CStr(errorNumber) & ": " & errorDescription, vbExclamation
End Sub

Private Function ManualBuilderRowMatches(ByRef data As Variant, ByVal rowNo As Long, _
                                         ByVal queryText As String) As Boolean
    Dim searchText As String, groups As Variant, terms As Variant
    Dim groupItem As Variant, termItem As Variant, groupOK As Boolean
    If Len(Trim$(queryText)) = 0 Then
        ManualBuilderRowMatches = True
        Exit Function
    End If
    searchText = ManualBuilderSearchText(data, rowNo)
    groups = Split(Replace(queryText, "�@", " "), "|")
    For Each groupItem In groups
        terms = Split(Application.Trim(CStr(groupItem)), " ")
        groupOK = True
        For Each termItem In terms
            If Len(Trim$(CStr(termItem))) > 0 Then
                If InStr(1, searchText, Trim$(CStr(termItem)), vbTextCompare) = 0 Then
                    groupOK = False
                    Exit For
                End If
            End If
        Next termItem
        If groupOK Then
            ManualBuilderRowMatches = True
            Exit Function
        End If
    Next groupItem
End Function

Private Function ManualBuilderSearchText(ByRef data As Variant, ByVal rowNo As Long) As String
    ManualBuilderSearchText = CellText(data(rowNo, OUT_COL_BANK)) & " " & _
        CellText(data(rowNo, OUT_COL_BRANCH)) & " " & CellText(data(rowNo, OUT_COL_PERSON)) & " " & _
        CellText(data(rowNo, OUT_COL_ACCOUNT_TYPE)) & " " & _
        CellText(data(rowNo, OUT_COL_ACCOUNT_NO)) & " " & _
        Format$(CDate(data(rowNo, OUT_COL_DATE)), "yyyy/m/d") & " " & _
        CellText(data(rowNo, OUT_COL_WITHDRAW)) & " " & _
        CellText(data(rowNo, OUT_COL_DEPOSIT)) & " " & _
        CellText(data(rowNo, OUT_COL_SHOP)) & " " & _
        CellText(data(rowNo, OUT_COL_MACHINE)) & " " & _
        CellText(data(rowNo, OUT_COL_TEKIYO))
End Function

Private Sub ManualBuilderDirectionAmount(ByRef data As Variant, ByVal rowNo As Long, _
                                         ByRef directionText As String, _
                                         ByRef amountValue As Double)
    If WorkspaceDouble(data(rowNo, OUT_COL_WITHDRAW)) > 0 Then
        directionText = "�o��"
        amountValue = WorkspaceDouble(data(rowNo, OUT_COL_WITHDRAW))
    Else
        directionText = "����"
        amountValue = WorkspaceDouble(data(rowNo, OUT_COL_DEPOSIT))
    End If
End Sub

Private Function ManualBuilderAccountText(ByRef data As Variant, ByVal rowNo As Long) As String
    ManualBuilderAccountText = CellText(data(rowNo, OUT_COL_PERSON)) & " / " & _
        CellText(data(rowNo, OUT_COL_BANK)) & " " & CellText(data(rowNo, OUT_COL_BRANCH)) & _
        " / " & CellText(data(rowNo, OUT_COL_ACCOUNT_TYPE)) & " " & _
        CellText(data(rowNo, OUT_COL_ACCOUNT_NO))
End Function

Private Function ManualBuilderSummaryText(ByRef data As Variant, ByVal rowNo As Long) As String
    ManualBuilderSummaryText = "�戵�X: " & WorkspaceBlankLabel(data(rowNo, OUT_COL_SHOP)) & _
        " / �@��: " & WorkspaceBlankLabel(data(rowNo, OUT_COL_MACHINE)) & _
        " / �E�v: " & WorkspaceBlankLabel(data(rowNo, OUT_COL_TEKIYO))
End Function

Public Sub OpenAnalysisResultDetail(ByVal resultRow As Long)
    If Not SheetExists(SH_OUTPUT_TX) Then Exit Sub
    If ActiveSheet Is Nothing Then Exit Sub
    If ActiveSheet.Name <> SH_OUTPUT_TX Then
        MsgBox "���̍����́A��������\�̏㕔�p�l���Ŋm�F���Ă��������B", _
               vbInformation, "��������\���ɕ\�����܂�"
        Exit Sub
    End If
    ShowCashAnalysisPanelText 7
End Sub

Private Sub LegacyOpenAnalysisResultDetail(ByVal resultRow As Long)
    Dim wsResult As Worksheet, wsDetail As Worksheet, wsGroup As Worksheet
    Dim groupID As String, txIDList As String, focusTxID As String
    Dim nextRow As Long, errorNumber As Long, errorDescription As String
    Dim errorSource As String, eventStateDetail As String
    Dim applicationLeaseDetail As String
    Dim fatalContainmentRequired As Boolean, eventsStopped As Boolean
    Dim workbookWasSaved As Boolean, reviewsWerePending As Boolean
    Dim applicationLeaseStarted As Boolean
    Dim applicationLeaseCleanupAttempted As Boolean
    If Not RequireToolReady() Then Exit Sub
    Set wsResult = GetSheet(SH_ANALYSIS_RESULT)
    If resultRow < 2 Or resultRow > LastUsedRowInSheet(wsResult) Then Exit Sub
    groupID = CellText(wsResult.Cells(resultRow, ANALYSIS_RESULT_GROUP_ID_COL).Value)
    If Len(groupID) = 0 Then Exit Sub
    On Error GoTo EH
    workbookWasSaved = ThisWorkbook.Saved
    reviewsWerePending = HasPendingAnalysisReviewChanges()
    '�ڍׂɕ\������m�F�󋵂��ꗗ�̍ŐV���͂ւ��낦��B
    SyncAnalysisWorkspaceReviewsToSources
    AppBegin "���ڍׂ�365���֘A����𐮗����Ă��܂�..."
    applicationLeaseStarted = True
    Set wsDetail = GetSheet(SH_ANALYSIS_DETAIL)
    Set wsGroup = GetSheet(SH_WORK_ANALYSIS_GROUP)
    PrepareAnalysisDetailSheet wsDetail
    SetSheetVeryHiddenSafe wsDetail
    wsDetail.Unprotect Password:=TOOL_PASSWORD
    WriteAnalysisDetailSummary wsResult, resultRow, wsDetail
    nextRow = 17
    txIDList = WriteAnalysisAlternativeDetails(wsGroup, groupID, wsDetail, nextRow)
    WriteAnalysisComponentTransactions txIDList, wsDetail, nextRow
    focusTxID = WorkspaceFirstTransactionID( _
        CellText(wsResult.Cells(resultRow, ANALYSIS_RESULT_TX_IDS_COL).Value))
    WriteUnknownLongTrace focusTxID, wsDetail, nextRow
    wsDetail.Columns("A:G").VerticalAlignment = xlTop
    wsDetail.Columns("A:G").WrapText = True
    wsDetail.Columns("H:L").Hidden = True
    wsDetail.ScrollArea = "A1:G" & CStr(Application.Max(50, nextRow + 20))
    ProtectSingleAnalysisSheet wsDetail
    mAnalysisDetailReviewsDirty = False
    If applicationLeaseStarted Then
        applicationLeaseCleanupAttempted = True
        If Not TryCloseAnalysisWorkspaceApplicationLease( _
                   applicationLeaseStarted, applicationLeaseDetail) Then
            Call TryStopAnalysisWorkspaceEventsForBookWrites(eventStateDetail)
            Err.Raise ANALYSIS_WORKSPACE_RECOVERY_FATAL_ERROR, _
                      ANALYSIS_WORKSPACE_RECOVERY_FATAL_SOURCE & _
                          "LegacyOpenAnalysisResultDetail/ApplicationLease", _
                      applicationLeaseDetail
        End If
    End If
    If workbookWasSaved And Not reviewsWerePending Then ThisWorkbook.Saved = True
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    fatalContainmentRequired = _
        IsAnalysisWorkspaceRecoveryFatalError(errorNumber, errorSource)
    If fatalContainmentRequired Then _
        RethrowAnalysisWorkspaceUpstreamRecoveryFatal _
            errorNumber, errorSource, errorDescription, _
            "LegacyOpenAnalysisResultDetail"
    '���Llease�̏I���Ɏ��s�����ꍇ�́A�ی�E��\���EUI�֐i�܂��I�[������B
    If applicationLeaseStarted And Not applicationLeaseCleanupAttempted Then
        applicationLeaseCleanupAttempted = True
        If Not TryCloseAnalysisWorkspaceApplicationLease( _
                   applicationLeaseStarted, applicationLeaseDetail) Then
            Call TryStopAnalysisWorkspaceEventsForBookWrites(eventStateDetail)
            Err.Raise ANALYSIS_WORKSPACE_RECOVERY_FATAL_ERROR, _
                      ANALYSIS_WORKSPACE_RECOVERY_FATAL_SOURCE & _
                          "LegacyOpenAnalysisResultDetail/ApplicationLease", _
                      applicationLeaseDetail
        End If
    End If
    '�ی쏈�����̂̍Ď��s��Application lease�I���֓��B�ł��Ȃ���Ԃ����Ȃ��B
    On Error Resume Next
    ProtectSingleAnalysisSheet wsDetail
    SetSheetVeryHiddenSafe wsDetail
    On Error GoTo 0
    If IsUserCancelError(errorNumber) Then
        MsgBox "���ڍׂ̍쐬�𒆒f���܂����B���͌��ʂƊm�F�L�^�͕ύX���Ă��܂���B", _
               vbInformation
        Exit Sub
    End If
    MsgBox "���ڍׂ̍쐬���ɃG���[���������܂����B" & vbCrLf & _
           "Err " & CStr(errorNumber) & ": " & errorDescription, vbExclamation
End Sub

Private Function WorkspaceFirstTransactionID(ByVal txIDList As String) As String
    Dim parts As Variant, item As Variant
    parts = Split(txIDList, ";")
    For Each item In parts
        WorkspaceFirstTransactionID = Trim$(CStr(item))
        If Len(WorkspaceFirstTransactionID) > 0 Then Exit Function
    Next item
End Function

Private Sub WriteAnalysisDetailSummary(ByVal wsResult As Worksheet, ByVal resultRow As Long, _
                                       ByVal wsDetail As Worksheet)
    MergeAndFormat wsDetail.Range("A1:G1"), "���͌��̏ڍ�"
    With wsDetail.Range("A1:G1")
        .Interior.Color = RGB(239, 246, 255)
        .Font.Color = RGB(30, 64, 175)
        .Font.Bold = True
        .Font.Size = 15
        .HorizontalAlignment = xlCenter
    End With
    MergeAndFormat wsDetail.Range("A2:G2"), _
        "����s���_�u���N���b�N����2���ȏ�I�� �� ���̈ē��s���_�u���N���b�N����Ǝ蓮����o�^�ł��܂��B"
    With wsDetail.Range("A2:G2")
        .Interior.Color = RGB(254, 249, 195)
        .Font.Color = RGB(133, 77, 14)
        .Font.Bold = True
        .HorizontalAlignment = xlCenter
        .WrapText = True
    End With
    wsDetail.Rows(1).RowHeight = 30
    wsDetail.Rows(2).RowHeight = 36
    wsDetail.Cells(2, DETAIL_COL_KIND).Value = "�蓮�o�^"
    wsDetail.Range("A3").Value = "�D��x": wsDetail.Range("B3").Value = wsResult.Cells(resultRow, 1).Value
    wsDetail.Range("C3").Value = "�敪": wsDetail.Range("D3").Value = wsResult.Cells(resultRow, 2).Value
    wsDetail.Range("E3").Value = "�m�F��": wsDetail.Range("F3:G3").Merge
    wsDetail.Range("F3").Value = wsResult.Cells(resultRow, 8).Value
    wsDetail.Range("A4").Value = "���t�E����": wsDetail.Range("B4:D4").Merge
    wsDetail.Range("B4").Value = wsResult.Cells(resultRow, 3).Value
    wsDetail.Range("E4").Value = "���z": wsDetail.Range("F4:G4").Merge
    wsDetail.Range("F4").Value = wsResult.Cells(resultRow, 4).Value
    wsDetail.Range("F4").NumberFormatLocal = "#,##0.########"
    wsDetail.Range("A5").Value = "�l���E�o�H": wsDetail.Range("B5:G5").Merge
    wsDetail.Range("B5").Value = wsResult.Cells(resultRow, 5).Value
    wsDetail.Range("A7").Value = "�v�_": wsDetail.Range("B7:G8").Merge
    wsDetail.Range("B7").Value = wsResult.Cells(resultRow, 6).Value
    wsDetail.Range("A10").Value = "���؁E����": wsDetail.Range("B10:G11").Merge
    wsDetail.Range("B10").Value = wsResult.Cells(resultRow, 7).Value
    wsDetail.Range("A13").Value = "�m�F����": wsDetail.Range("B13:G13").Merge
    wsDetail.Range("B13").Value = wsResult.Cells(resultRow, 9).Value
    wsDetail.Range("A14").Value = "���͎����͈�": wsDetail.Range("B14:G14").Merge
    wsDetail.Range("B14").Value = WorkspaceCoverageText( _
        CellText(wsResult.Cells(resultRow, ANALYSIS_RESULT_TX_IDS_COL).Value))
    wsDetail.Range("A15").Value = "�����m�F": wsDetail.Range("B15:G15").Merge
    wsDetail.Range("B15").Value = WorkspaceRecommendedCheck( _
        CellText(wsResult.Cells(resultRow, 2).Value), _
        WorkspaceLong(wsResult.Cells(resultRow, ANALYSIS_RESULT_ALTERNATIVE_COUNT_COL).Value))
    With wsDetail.Range("A3:G15")
        .Borders.LineStyle = xlContinuous
        .Borders.Color = RGB(203, 213, 225)
        .WrapText = True
    End With
    wsDetail.Range("A3:A15,C3:C3,E3:E4").Font.Bold = True
    wsDetail.Rows("3:4").RowHeight = 24
    wsDetail.Rows(5).RowHeight = 30
    wsDetail.Rows(6).RowHeight = 8
    wsDetail.Rows("7:8").RowHeight = 30
    wsDetail.Rows(9).RowHeight = 8
    wsDetail.Rows("10:11").RowHeight = 30
    wsDetail.Rows(12).RowHeight = 8
    wsDetail.Rows(13).RowHeight = 32
    wsDetail.Rows("14:15").RowHeight = 30
    wsDetail.Range("A6:G6,A9:G9,A12:G12").Borders.LineStyle = xlNone
    wsDetail.Range("A6:G6,A9:G9,A12:G12").Interior.Color = vbWhite
End Sub

Private Function WorkspaceRecommendedCheck(ByVal categoryText As String, _
                                           ByVal alternativeCount As Long) As String
    Select Case categoryText
        Case "�����V�t�g", "�����t���["
            WorkspaceRecommendedCheck = _
                "�ʒ����{�A���o���E�U���`�[�A������������œ��t�E�������E���`�E���z�E�o�H���ƍ����Ă��������B"
            If alternativeCount > 1 Then _
                WorkspaceRecommendedCheck = WorkspaceRecommendedCheck & _
                    " ��\�s�����Ŋm�肹���A���̑�։������r���Ă��������B"
        Case "�����s��"
            WorkspaceRecommendedCheck = _
                "�����`�[�E�U���˗��l�A���������߁A�����E���p�E���^�E�ؓ��E���������A�]�O�̎苖�������m�F���Ă��������B�E�v�����Ō����m�F�ς݂ɂ��Ȃ��ł��������B"
        Case "�g�r�s��"
            WorkspaceRecommendedCheck = _
                "���߁E�U���`�[�A����掑���A���������������A�擾���Y�E���ԍρE���^�E������E�苖�����c���m�F���Ă��������B�E�v�����Ŏg�r�m�F�ς݂ɂ��Ȃ��ł��������B"
        Case Else
            WorkspaceRecommendedCheck = "�������ƍ\��������ƍ����A���������m�莖���Ƃ��Ĉ���Ȃ��ł��������B"
    End Select
End Function

Private Function WorkspaceCoverageText(ByVal txIDList As String) As String
    Dim wsTx As Worksheet, data As Variant, lastR As Long, r As Long
    Dim wanted As Object, personIDs As Object, accounts As Object
    Dim txID As String, personID As String, accountID As String
    Dim transactionCount As Long, minDate As Long, maxDate As Long, transactionDateSerial As Long
    Set wanted = CreateObject("Scripting.Dictionary")
    Set personIDs = CreateObject("Scripting.Dictionary")
    Set accounts = CreateObject("Scripting.Dictionary")
    wanted.CompareMode = vbTextCompare
    personIDs.CompareMode = vbTextCompare
    accounts.CompareMode = vbTextCompare
    AddWorkspaceIDsToSet txIDList, wanted
    Set wsTx = GetSheet(SH_WORK_TX)
    lastR = LastUsedRowInSheet(wsTx)
    If lastR < 2 Then
        WorkspaceCoverageText = "���͍ςݎ��������܂���B"
        Exit Function
    End If
    data = wsTx.Range(wsTx.Cells(2, 1), wsTx.Cells(lastR, WORK_TX_COL_PERSON_ID)).Value2
    For r = 1 To UBound(data, 1)
        txID = CellText(data(r, WORK_TX_COL_TRANSACTION_ID))
        If wanted.Exists(txID) Then
            personID = WorkspacePersonIdentity(data, r)
            If Len(personID) > 0 Then personIDs(personID) = True
        End If
    Next r
    For r = 1 To UBound(data, 1)
        personID = WorkspacePersonIdentity(data, r)
        If personIDs.Exists(personID) Then
            If WorkspaceDouble(data(r, OUT_COL_WITHDRAW)) > 0 Or _
               WorkspaceDouble(data(r, OUT_COL_DEPOSIT)) > 0 Then
                transactionCount = transactionCount + 1
                accountID = CellText(data(r, WORK_TX_COL_ACCOUNT_ID))
                If Len(accountID) > 0 Then accounts(accountID) = True
                If IsDate(data(r, OUT_COL_DATE)) Then
                    transactionDateSerial = CLng(VBA.DateValue(CDate(data(r, OUT_COL_DATE))))
                    If minDate = 0 Or transactionDateSerial < minDate Then minDate = transactionDateSerial
                    If transactionDateSerial > maxDate Then maxDate = transactionDateSerial
                End If
            End If
        End If
    Next r
    WorkspaceCoverageText = "�\������Ɠ���l���ɂ��āA���͍ς� " & _
        Format$(accounts.Count, "#,##0") & "�����E" & Format$(transactionCount, "#,##0") & "���"
    If minDate > 0 Then
        WorkspaceCoverageText = WorkspaceCoverageText & "�i" & _
            Format$(CDate(minDate), "yyyy/m/d") & "�`" & Format$(CDate(maxDate), "yyyy/m/d") & "�j"
    End If
    WorkspaceCoverageText = WorkspaceCoverageText & _
        "���ϑ��B�����͎����E�����ۗL���͊܂܂ꂸ�A���Ȃ��͕s���݂̏ؖ��ł͂���܂���B"
End Function

Private Function WriteAnalysisAlternativeDetails(ByVal wsGroup As Worksheet, ByVal groupID As String, _
                                                 ByVal wsDetail As Worksheet, ByRef nextRow As Long) As String
    Dim lastR As Long, data As Variant, r As Long, sourceRow As Long
    Dim sourceSheet As String, txIDs As String, memberCount As Long
    Dim txSet As Object
    Set txSet = CreateObject("Scripting.Dictionary")
    txSet.CompareMode = vbTextCompare
    lastR = LastUsedRowInSheet(wsGroup)
    wsDetail.Cells(nextRow, 1).Value = "��։����i������������L������j"
    wsDetail.Cells(nextRow, 1).Font.Bold = True
    nextRow = nextRow + 1
    SetRowValues wsDetail.Cells(nextRow, 1), Array("���", "�]���E�_", "���t�E����", "�����o�H�E�Ώ�", "���藝�R", "�m�F��", "�ʒu�t��")
    FormatOutputHeader wsDetail.Range(wsDetail.Cells(nextRow, 1), wsDetail.Cells(nextRow, 7))
    nextRow = nextRow + 1
    If lastR >= 2 Then
        data = wsGroup.Range(wsGroup.Cells(2, 1), wsGroup.Cells(lastR, ANALYSIS_GROUP_LAST_COL)).Value2
        For r = 1 To UBound(data, 1)
            If StrComp(CellText(data(r, 1)), groupID, vbBinaryCompare) = 0 Then
                sourceSheet = CellText(data(r, 2))
                sourceRow = WorkspaceLong(data(r, 3))
                txIDs = CellText(data(r, 5))
                AddWorkspaceIDsToSet txIDs, txSet
                WriteOneAlternativeDetail GetSheet(sourceSheet), sourceRow, sourceSheet, _
                                          CellText(data(r, 7)), wsDetail, nextRow
                nextRow = nextRow + 2
                memberCount = memberCount + 1
            End If
        Next r
    End If
    If memberCount = 0 Then
        wsDetail.Cells(nextRow, 1).Value = "�����O���[�v��񂪂���܂���B�ĕ��͂��Ă��������B"
        nextRow = nextRow + 1
    End If
    nextRow = nextRow + 1
    WriteAnalysisAlternativeDetails = WorkspaceJoinDictionaryKeys(txSet)
End Function

Private Sub WriteOneAlternativeDetail(ByVal wsSource As Worksheet, ByVal sourceRow As Long, _
                                      ByVal sourceSheet As String, ByVal positionText As String, _
                                      ByVal wsDetail As Worksheet, ByVal outputRow As Long)
    If sourceRow < 2 Or sourceRow > LastUsedRowInSheet(wsSource) Then _
        Err.Raise vbObjectError + 4810, "WriteOneAlternativeDetail", "�������s��������܂���B"
    Select Case sourceSheet
        Case SH_ANALYSIS_SHIFT
            wsDetail.Cells(outputRow, 1).Value = "�����V�t�g"
            wsDetail.Cells(outputRow, 2).Value = CellText(wsSource.Cells(sourceRow, 1).Value) & _
                                                        " / " & CellText(wsSource.Cells(sourceRow, 2).Value)
            wsDetail.Cells(outputRow, 3).Value = WorkspacePeriodText(wsSource.Cells(sourceRow, 9).Value, _
                                                                     wsSource.Cells(sourceRow, 19).Value)
            wsDetail.Cells(outputRow, 4).Value = WorkspacePartyAccount( _
                wsSource.Cells(sourceRow, 11).Value, wsSource.Cells(sourceRow, 12).Value, _
                wsSource.Cells(sourceRow, 13).Value, wsSource.Cells(sourceRow, 14).Value, _
                wsSource.Cells(sourceRow, 15).Value, wsSource.Cells(sourceRow, 16).Value) & " �� " & _
                WorkspacePartyAccount(wsSource.Cells(sourceRow, 21).Value, wsSource.Cells(sourceRow, 22).Value, _
                wsSource.Cells(sourceRow, 23).Value, wsSource.Cells(sourceRow, 24).Value, _
                wsSource.Cells(sourceRow, 25).Value, wsSource.Cells(sourceRow, 26).Value)
            wsDetail.Cells(outputRow, 5).Value = WorkspaceTrimText(CellText(wsSource.Cells(sourceRow, 29).Value), WORKSPACE_TEXT_LIMIT)
            wsDetail.Cells(outputRow, 6).Value = wsSource.Cells(sourceRow, SHIFT_ANALYSIS_STATUS_COL).Value
        Case SH_ANALYSIS_FLOW
            wsDetail.Cells(outputRow, 1).Value = "�����t���["
            wsDetail.Cells(outputRow, 2).Value = CellText(wsSource.Cells(sourceRow, 1).Value) & _
                                                        " / " & CellText(wsSource.Cells(sourceRow, 2).Value)
            wsDetail.Cells(outputRow, 3).Value = wsSource.Cells(sourceRow, 6).Value
            wsDetail.Cells(outputRow, 4).Value = wsSource.Cells(sourceRow, 12).Value
            wsDetail.Cells(outputRow, 5).Value = WorkspaceTrimText(CellText(wsSource.Cells(sourceRow, 16).Value), WORKSPACE_TEXT_LIMIT)
            wsDetail.Cells(outputRow, 6).Value = wsSource.Cells(sourceRow, FLOW_ANALYSIS_STATUS_COL).Value
        Case SH_ANALYSIS_UNKNOWN
            wsDetail.Cells(outputRow, 1).Value = Replace(CellText(wsSource.Cells(sourceRow, 3).Value), "���", "")
            wsDetail.Cells(outputRow, 2).Value = CellText(wsSource.Cells(sourceRow, 1).Value) & _
                                                        " / " & CellText(wsSource.Cells(sourceRow, 2).Value)
            wsDetail.Cells(outputRow, 3).Value = WorkspaceDateText(wsSource.Cells(sourceRow, 4).Value) & _
                                                " " & WorkspaceTimeText(wsSource.Cells(sourceRow, 5).Value)
            wsDetail.Cells(outputRow, 4).Value = WorkspacePartyAccount( _
                wsSource.Cells(sourceRow, 7).Value, wsSource.Cells(sourceRow, 8).Value, _
                wsSource.Cells(sourceRow, 9).Value, wsSource.Cells(sourceRow, 10).Value, _
                wsSource.Cells(sourceRow, 11).Value, wsSource.Cells(sourceRow, 12).Value)
            wsDetail.Cells(outputRow, 5).Value = WorkspaceTrimText(CellText(wsSource.Cells(sourceRow, 20).Value), WORKSPACE_TEXT_LIMIT)
            wsDetail.Cells(outputRow, 6).Value = wsSource.Cells(sourceRow, UNKNOWN_ANALYSIS_STATUS_COL).Value
    End Select
    If sourceSheet = SH_ANALYSIS_FLOW And _
       CellText(wsSource.Cells(sourceRow, 3).Value) = "�蓮�w��" Then
        wsDetail.Cells(outputRow, 7).Value = positionText & " / �_�u���N���b�N�Ŗ�����"
    Else
        wsDetail.Cells(outputRow, 7).Value = positionText
    End If
    wsDetail.Cells(outputRow, DETAIL_COL_KIND).Value = "���"
    wsDetail.Cells(outputRow, DETAIL_COL_REFERENCE).Value = sourceSheet
    wsDetail.Cells(outputRow, DETAIL_COL_SOURCE_ROW).Value = sourceRow
    wsDetail.Cells(outputRow, DETAIL_COL_SOURCE_KEY).Value = _
        wsSource.Cells(sourceRow, WorkspaceDetailKeyColumn(sourceSheet)).Value
    wsDetail.Cells(outputRow, 6).Locked = False
    ApplyAnalysisDetailStatusValidation wsDetail.Cells(outputRow, 6), sourceSheet, _
                                        CellText(wsDetail.Cells(outputRow, 1).Value)
    With wsDetail.Range(wsDetail.Cells(outputRow, 1), wsDetail.Cells(outputRow, 7))
        .Borders.LineStyle = xlContinuous
        .Borders.Color = RGB(226, 232, 240)
        .WrapText = True
        .VerticalAlignment = xlTop
    End With
    wsDetail.Rows(outputRow).RowHeight = 48
    wsDetail.Cells(outputRow + 1, 1).Value = "�ʊm�F����"
    wsDetail.Range(wsDetail.Cells(outputRow + 1, 2), wsDetail.Cells(outputRow + 1, 7)).Merge
    Select Case sourceSheet
        Case SH_ANALYSIS_SHIFT
            wsDetail.Cells(outputRow + 1, 2).Value = wsSource.Cells(sourceRow, SHIFT_ANALYSIS_MEMO_COL).Value
        Case SH_ANALYSIS_FLOW
            wsDetail.Cells(outputRow + 1, 2).Value = wsSource.Cells(sourceRow, FLOW_ANALYSIS_MEMO_COL).Value
        Case SH_ANALYSIS_UNKNOWN
            wsDetail.Cells(outputRow + 1, 2).Value = wsSource.Cells(sourceRow, UNKNOWN_ANALYSIS_MEMO_COL).Value
    End Select
    wsDetail.Cells(outputRow + 1, DETAIL_COL_KIND).Value = "��⃁��"
    wsDetail.Cells(outputRow + 1, DETAIL_COL_REFERENCE).Value = sourceSheet
    wsDetail.Cells(outputRow + 1, DETAIL_COL_SOURCE_ROW).Value = sourceRow
    wsDetail.Cells(outputRow + 1, DETAIL_COL_SOURCE_KEY).Value = _
        wsDetail.Cells(outputRow, DETAIL_COL_SOURCE_KEY).Value
    wsDetail.Range(wsDetail.Cells(outputRow + 1, 2), _
                   wsDetail.Cells(outputRow + 1, 7)).Locked = False
    ApplyAnalysisDetailMemoValidation wsDetail.Cells(outputRow + 1, 2)
    With wsDetail.Range(wsDetail.Cells(outputRow + 1, 1), wsDetail.Cells(outputRow + 1, 7))
        .Borders.LineStyle = xlContinuous
        .Borders.Color = RGB(226, 232, 240)
        .Interior.Color = RGB(255, 251, 235)
        .WrapText = True
        .VerticalAlignment = xlTop
    End With
    wsDetail.Rows(outputRow + 1).RowHeight = 38
End Sub

Private Sub WriteAnalysisComponentTransactions(ByVal txIDList As String, ByVal wsDetail As Worksheet, _
                                               ByRef nextRow As Long)
    Dim wsTx As Worksheet, data As Variant, lastR As Long, r As Long, outputCount As Long
    Dim wanted As Object, txID As String, amountValue As Double, kindText As String
    Set wanted = CreateObject("Scripting.Dictionary")
    wanted.CompareMode = vbTextCompare
    AddWorkspaceIDsToSet txIDList, wanted
    wsDetail.Cells(nextRow, 1).Value = "�\������i�����󗓂́u�����L�ڂȂ��v�B�������̑O��́u�����������s���v�j"
    wsDetail.Cells(nextRow, 1).Font.Bold = True
    nextRow = nextRow + 1
    SetRowValues wsDetail.Cells(nextRow, 1), Array("���t", "����", "�l��", "����", "�o��", "����", "�E�v")
    FormatOutputHeader wsDetail.Range(wsDetail.Cells(nextRow, 1), wsDetail.Cells(nextRow, 7))
    wsDetail.Cells(nextRow, 5).Interior.Color = RGB(185, 28, 28)
    wsDetail.Cells(nextRow, 6).Interior.Color = RGB(29, 78, 216)
    nextRow = nextRow + 1
    Set wsTx = GetSheet(SH_WORK_TX)
    lastR = LastUsedRowInSheet(wsTx)
    If lastR >= 2 And wanted.Count > 0 Then
        data = wsTx.Range(wsTx.Cells(2, 1), wsTx.Cells(lastR, WORK_TX_COL_PERSON_ID)).Value2
        For r = 1 To UBound(data, 1)
            txID = CellText(data(r, WORK_TX_COL_TRANSACTION_ID))
            If wanted.Exists(txID) Then
                WorkspaceTransactionDirection data, r, kindText, amountValue
                WriteWorkspaceTransactionRow wsDetail, nextRow, data, r, kindText, amountValue, vbNullString
                nextRow = nextRow + 1
                outputCount = outputCount + 1
            End If
        Next r
    End If
    If outputCount < wanted.Count Then
        wsDetail.Cells(nextRow, 1).Value = "����: �\�����ID " & CStr(wanted.Count - outputCount) & _
                                             "�������s�f�[�^�Ŋm�F�ł��܂���B�ĕ��͂��Ă��������B"
        nextRow = nextRow + 1
    End If
    nextRow = nextRow + 1
End Sub

Private Sub WriteUnknownLongTrace(ByVal selectedTxID As String, ByVal wsDetail As Worksheet, _
                                  ByRef nextRow As Long)
    Dim wsTx As Worksheet, data As Variant, lastR As Long, selectedRow As Long
    Dim candidateRows() As Long, candidateScores() As Long, candidateDayDiffs() As Long
    Dim candidateCount As Long, r As Long, dayDifference As Long, relevance As Long
    Dim selectedDate As Long, selectedAmount As Double, selectedKind As String
    Dim selectedAccount As String, selectedPerson As String, currentAccount As String, currentPerson As String
    Dim currentAmount As Double, currentKind As String, relationText As String
    Dim displayCount As Long, omittedCount As Long
    Dim totals(1 To 3, 1 To 4) As Double, counts(1 To 3, 1 To 4) As Long
    Dim absoluteTolerance As Double, rateTolerance As Double
    Set wsTx = GetSheet(SH_WORK_TX)
    lastR = LastUsedRowInSheet(wsTx)
    If lastR < 2 Or Len(selectedTxID) = 0 Then Exit Sub
    data = wsTx.Range(wsTx.Cells(2, 1), wsTx.Cells(lastR, WORK_TX_COL_PERSON_ID)).Value2
    For r = 1 To UBound(data, 1)
        If StrComp(CellText(data(r, WORK_TX_COL_TRANSACTION_ID)), selectedTxID, vbTextCompare) = 0 Then
            selectedRow = r
            Exit For
        End If
    Next r
    If selectedRow = 0 Then Exit Sub
    selectedDate = CLng(VBA.DateValue(CDate(data(selectedRow, OUT_COL_DATE))))
    selectedAccount = CellText(data(selectedRow, WORK_TX_COL_ACCOUNT_ID))
    selectedPerson = WorkspacePersonIdentity(data, selectedRow)
    WorkspaceTransactionDirection data, selectedRow, selectedKind, selectedAmount
    absoluteTolerance = WorkspaceDouble(GetSheet(SH_CONFIG).Cells(ROW_CFG_ANALYSIS_ABS_TOLERANCE, _
                                                                  COL_CFG_ANALYSIS_VALUE).Value)
    rateTolerance = WorkspaceRateTolerance(GetSheet(SH_CONFIG).Cells(ROW_CFG_ANALYSIS_RATE_TOLERANCE, _
                                                                     COL_CFG_ANALYSIS_VALUE))
    ReDim candidateRows(1 To UBound(data, 1))
    ReDim candidateScores(1 To UBound(data, 1))
    ReDim candidateDayDiffs(1 To UBound(data, 1))
    For r = 1 To UBound(data, 1)
        If r Mod 4096 = 0 Then AppProgress "365���֘A������ƍ����Ă��܂�...", r, UBound(data, 1)
        If r <> selectedRow And IsDate(data(r, OUT_COL_DATE)) Then
            WorkspaceTransactionDirection data, r, currentKind, currentAmount
            If currentAmount > 0 Then
                dayDifference = Abs(CLng(VBA.DateValue(CDate(data(r, OUT_COL_DATE)))) - selectedDate)
                If dayDifference <= 365 Then
                    currentAccount = CellText(data(r, WORK_TX_COL_ACCOUNT_ID))
                    currentPerson = WorkspacePersonIdentity(data, r)
                    If StrComp(currentAccount, selectedAccount, vbTextCompare) = 0 Or _
                       (Len(selectedPerson) > 0 And StrComp(currentPerson, selectedPerson, vbTextCompare) = 0) Then
                        relevance = WorkspaceTraceRelevance(data, selectedRow, r, selectedKind, currentKind, _
                                                           selectedAmount, currentAmount, dayDifference, _
                                                           absoluteTolerance, rateTolerance)
                        candidateCount = candidateCount + 1
                        candidateRows(candidateCount) = r
                        candidateScores(candidateCount) = relevance
                        candidateDayDiffs(candidateCount) = dayDifference
                        AccumulateWorkspaceTrace totals, counts, dayDifference, _
                            (StrComp(currentAccount, selectedAccount, vbTextCompare) = 0), _
                            (StrComp(currentKind, selectedKind, vbTextCompare) = 0), currentAmount
                    End If
                End If
            End If
        End If
    Next r
    If candidateCount > 1 Then _
        QuickSortWorkspaceTrace candidateRows, candidateScores, candidateDayDiffs, 1, candidateCount

    wsDetail.Cells(nextRow, 1).Value = "�I������𒆐S�Ƃ���365���֘A���"
    wsDetail.Cells(nextRow, 1).Font.Bold = True
    nextRow = nextRow + 1
    wsDetail.Range(wsDetail.Cells(nextRow, 1), wsDetail.Cells(nextRow, 7)).Merge
    wsDetail.Cells(nextRow, 1).Value = _
        "��������܂��͓���l���̎�����֘A�x���ɕ\�����܂��B���͉����ł���A�����������̑O��֌W�͒f�肵�܂���B"
    wsDetail.Cells(nextRow, 1).Interior.Color = RGB(255, 251, 235)
    nextRow = nextRow + 1
    SetRowValues wsDetail.Cells(nextRow, 1), Array("���t", "����", "�l��", "����", "�o��", "����", "�֌W�E�E�v")
    FormatOutputHeader wsDetail.Range(wsDetail.Cells(nextRow, 1), wsDetail.Cells(nextRow, 7))
    wsDetail.Cells(nextRow, 5).Interior.Color = RGB(185, 28, 28)
    wsDetail.Cells(nextRow, 6).Interior.Color = RGB(29, 78, 216)
    nextRow = nextRow + 1
    displayCount = candidateCount
    If displayCount > WORKSPACE_DETAIL_LIMIT Then displayCount = WORKSPACE_DETAIL_LIMIT
    For r = 1 To displayCount
        relationText = WorkspaceTraceRelation(data, selectedRow, candidateRows(r), selectedKind)
        WorkspaceTransactionDirection data, candidateRows(r), currentKind, currentAmount
        relationText = relationText & "�E�֘A�x" & CStr(candidateScores(r))
        WriteWorkspaceTransactionRow wsDetail, nextRow, data, candidateRows(r), _
                                     currentKind, currentAmount, relationText
        nextRow = nextRow + 1
    Next r
    omittedCount = candidateCount - displayCount
    If omittedCount > 0 Then
        wsDetail.Cells(nextRow, 1).Value = "�\������̂��ߊ֘A�x�̒Ⴂ " & _
                                             Format$(omittedCount, "#,##0") & "�����ȗ����܂����B"
        nextRow = nextRow + 1
    End If
    nextRow = nextRow + 1
    WriteWorkspaceAggregateSummary wsDetail, nextRow, totals, counts
End Sub

Private Sub AccumulateWorkspaceTrace(ByRef totals() As Double, ByRef counts() As Long, _
                                     ByVal dayDifference As Long, ByVal sameAccount As Boolean, _
                                     ByVal sameDirection As Boolean, ByVal amountValue As Double)
    Dim windowIndex As Long, categoryIndex As Long, limitDays As Long
    If sameAccount Then
        If sameDirection Then categoryIndex = 1 Else categoryIndex = 2
    Else
        If sameDirection Then categoryIndex = 3 Else categoryIndex = 4
    End If
    For windowIndex = 1 To 3
        Select Case windowIndex
            Case 1: limitDays = 30
            Case 2: limitDays = 90
            Case Else: limitDays = 365
        End Select
        If dayDifference <= limitDays Then
            totals(windowIndex, categoryIndex) = totals(windowIndex, categoryIndex) + amountValue
            counts(windowIndex, categoryIndex) = counts(windowIndex, categoryIndex) + 1
        End If
    Next windowIndex
End Sub

Private Sub WriteWorkspaceAggregateSummary(ByVal ws As Worksheet, ByRef nextRow As Long, _
                                           ByRef totals() As Double, ByRef counts() As Long)
    Dim windowIndex As Long, categoryIndex As Long, limitDays As Long
    Dim labels As Variant
    labels = Array("�������E����", "�������E����", "���������l���E����", "���������l���E����")
    ws.Cells(nextRow, 1).Value = "30�E90�E365���ݐρi�ʂ̎����ړ��m��ł͂Ȃ��A�����E�����̊m�F�⏕�j"
    ws.Cells(nextRow, 1).Font.Bold = True
    nextRow = nextRow + 1
    SetRowValues ws.Cells(nextRow, 1), Array("����", "�֌W", "����", "�݌v�z", "���ߏ�̒���", "", "")
    FormatOutputHeader ws.Range(ws.Cells(nextRow, 1), ws.Cells(nextRow, 7))
    nextRow = nextRow + 1
    For windowIndex = 1 To 3
        Select Case windowIndex
            Case 1: limitDays = 30
            Case 2: limitDays = 90
            Case Else: limitDays = 365
        End Select
        For categoryIndex = 1 To 4
            ws.Cells(nextRow, 1).Value = "�O��" & CStr(limitDays) & "��"
            ws.Cells(nextRow, 2).Value = labels(categoryIndex - 1)
            ws.Cells(nextRow, 3).Value = counts(windowIndex, categoryIndex)
            ws.Cells(nextRow, 4).Value = totals(windowIndex, categoryIndex)
            ws.Cells(nextRow, 4).NumberFormatLocal = "#,##0.########"
            ws.Range(ws.Cells(nextRow, 5), ws.Cells(nextRow, 7)).Merge
            ws.Cells(nextRow, 5).Value = "�݌v�͊֘A�͈͂̏���l�ŁA���ꎑ���̏d���v����������m��z�ł͂���܂���B"
            With ws.Range(ws.Cells(nextRow, 1), ws.Cells(nextRow, 7)).Borders
                .LineStyle = xlContinuous
                .Color = RGB(226, 232, 240)
            End With
            nextRow = nextRow + 1
        Next categoryIndex
    Next windowIndex
    nextRow = nextRow + 1
End Sub

Private Function WorkspaceTraceRelevance(ByRef data As Variant, ByVal selectedRow As Long, _
                                         ByVal currentRow As Long, ByVal selectedKind As String, _
                                         ByVal currentKind As String, ByVal selectedAmount As Double, _
                                         ByVal currentAmount As Double, ByVal dayDifference As Long, _
                                         ByVal absoluteTolerance As Double, ByVal rateTolerance As Double) As Long
    Dim allowedDifference As Double
    If StrComp(CellText(data(selectedRow, WORK_TX_COL_ACCOUNT_ID)), _
               CellText(data(currentRow, WORK_TX_COL_ACCOUNT_ID)), vbTextCompare) = 0 Then
        WorkspaceTraceRelevance = WorkspaceTraceRelevance + 24
    Else
        WorkspaceTraceRelevance = WorkspaceTraceRelevance + 12
    End If
    If StrComp(selectedKind, currentKind, vbTextCompare) <> 0 Then _
        WorkspaceTraceRelevance = WorkspaceTraceRelevance + 20
    allowedDifference = absoluteTolerance
    If selectedAmount * rateTolerance > allowedDifference Then allowedDifference = selectedAmount * rateTolerance
    If currentAmount * rateTolerance > allowedDifference Then allowedDifference = currentAmount * rateTolerance
    If Abs(selectedAmount - currentAmount) <= allowedDifference + 0.0000001 Then _
        WorkspaceTraceRelevance = WorkspaceTraceRelevance + 30
    If dayDifference = 0 Then
        WorkspaceTraceRelevance = WorkspaceTraceRelevance + 16
    ElseIf dayDifference <= 7 Then
        WorkspaceTraceRelevance = WorkspaceTraceRelevance + 12
    ElseIf dayDifference <= 30 Then
        WorkspaceTraceRelevance = WorkspaceTraceRelevance + 8
    ElseIf dayDifference <= 90 Then
        WorkspaceTraceRelevance = WorkspaceTraceRelevance + 4
    End If
End Function

Private Function WorkspaceTraceRelation(ByRef data As Variant, ByVal selectedRow As Long, _
                                        ByVal currentRow As Long, ByVal selectedKind As String) As String
    Dim selectedDate As Long, currentDate As Long
    Dim selectedTime As Double, currentTime As Double
    Dim selectedHasTime As Boolean, currentHasTime As Boolean
    Dim accountText As String
    If StrComp(CellText(data(selectedRow, WORK_TX_COL_ACCOUNT_ID)), _
               CellText(data(currentRow, WORK_TX_COL_ACCOUNT_ID)), vbTextCompare) = 0 Then
        accountText = "������"
    Else
        accountText = "���l���E������"
    End If
    selectedDate = CLng(VBA.DateValue(CDate(data(selectedRow, OUT_COL_DATE))))
    currentDate = CLng(VBA.DateValue(CDate(data(currentRow, OUT_COL_DATE))))
    If currentDate < selectedDate Then
        WorkspaceTraceRelation = accountText & "�E�I��������O"
    ElseIf currentDate > selectedDate Then
        WorkspaceTraceRelation = accountText & "�E�I���������"
    Else
        selectedHasTime = WorkspaceTryTime(data(selectedRow, OUT_COL_TIME), selectedTime)
        currentHasTime = WorkspaceTryTime(data(currentRow, OUT_COL_TIME), currentTime)
        If selectedHasTime And currentHasTime Then
            If currentTime < selectedTime - 0.000000001 Then
                WorkspaceTraceRelation = accountText & "�E�����őO"
            ElseIf currentTime > selectedTime + 0.000000001 Then
                WorkspaceTraceRelation = accountText & "�E�����Ō�"
            Else
                WorkspaceTraceRelation = accountText & "�E������"
            End If
        Else
            WorkspaceTraceRelation = accountText & "�E�����������s��"
        End If
    End If
End Function

Private Sub QuickSortWorkspaceTrace(ByRef rows() As Long, ByRef scores() As Long, _
                                    ByRef dayDiffs() As Long, ByVal firstIndex As Long, _
                                    ByVal lastIndex As Long)
    Dim low As Long, high As Long, pivotScore As Long, pivotDays As Long
    Dim tempLong As Long
    low = firstIndex: high = lastIndex
    pivotScore = scores((firstIndex + lastIndex) \ 2)
    pivotDays = dayDiffs((firstIndex + lastIndex) \ 2)
    Do While low <= high
        Do While WorkspaceTraceBefore(scores(low), dayDiffs(low), pivotScore, pivotDays)
            low = low + 1
        Loop
        Do While WorkspaceTraceBefore(pivotScore, pivotDays, scores(high), dayDiffs(high))
            high = high - 1
        Loop
        If low <= high Then
            tempLong = rows(low): rows(low) = rows(high): rows(high) = tempLong
            tempLong = scores(low): scores(low) = scores(high): scores(high) = tempLong
            tempLong = dayDiffs(low): dayDiffs(low) = dayDiffs(high): dayDiffs(high) = tempLong
            low = low + 1: high = high - 1
        End If
    Loop
    If firstIndex < high Then QuickSortWorkspaceTrace rows, scores, dayDiffs, firstIndex, high
    If low < lastIndex Then QuickSortWorkspaceTrace rows, scores, dayDiffs, low, lastIndex
End Sub

Private Function WorkspaceTraceBefore(ByVal firstScore As Long, ByVal firstDays As Long, _
                                      ByVal secondScore As Long, ByVal secondDays As Long) As Boolean
    If firstScore > secondScore Then
        WorkspaceTraceBefore = True
    ElseIf firstScore = secondScore Then
        WorkspaceTraceBefore = (firstDays < secondDays)
    End If
End Function

Private Sub WriteWorkspaceTransactionRow(ByVal ws As Worksheet, ByVal outputRow As Long, _
                                         ByRef data As Variant, ByVal sourceRow As Long, _
                                         ByVal kindText As String, ByVal amountValue As Double, _
                                         ByVal extraText As String)
    ws.Cells(outputRow, 1).Value = CDate(data(sourceRow, OUT_COL_DATE))
    ws.Cells(outputRow, 1).NumberFormatLocal = "yyyy/m/d"
    ws.Cells(outputRow, 2).Value = WorkspaceTimeText(data(sourceRow, OUT_COL_TIME))
    ws.Cells(outputRow, 3).Value = CellText(data(sourceRow, OUT_COL_PERSON)) & _
                                          WorkspaceRelationshipSuffix(data(sourceRow, WORK_TX_COL_RELATIONSHIP))
    ws.Cells(outputRow, 4).Value = WorkspacePartyAccount(vbNullString, vbNullString, _
        data(sourceRow, OUT_COL_BANK), data(sourceRow, OUT_COL_BRANCH), _
        data(sourceRow, OUT_COL_ACCOUNT_TYPE), data(sourceRow, OUT_COL_ACCOUNT_NO))
    If InStr(1, kindText, "�o��", vbTextCompare) > 0 Then
        ws.Cells(outputRow, 5).Value = amountValue
    ElseIf InStr(1, kindText, "����", vbTextCompare) > 0 Then
        ws.Cells(outputRow, 6).Value = amountValue
    End If
    ws.Range(ws.Cells(outputRow, 5), ws.Cells(outputRow, 6)).NumberFormatLocal = "#,##0.########"
    ws.Cells(outputRow, 5).Font.Color = RGB(153, 27, 27)
    ws.Cells(outputRow, 6).Font.Color = RGB(30, 64, 175)
    If Len(extraText) > 0 Then
        ws.Cells(outputRow, 7).Value = extraText & " / �E�v: " & _
                                       WorkspaceBlankLabel(data(sourceRow, OUT_COL_TEKIYO))
    Else
        ws.Cells(outputRow, 7).Value = WorkspaceBlankLabel(data(sourceRow, OUT_COL_TEKIYO))
    End If
    ws.Cells(outputRow, DETAIL_COL_KIND).Value = "���"
    ws.Cells(outputRow, DETAIL_COL_REFERENCE).Value = _
        CellText(data(sourceRow, WORK_TX_COL_TRANSACTION_ID))
    ws.Cells(outputRow, DETAIL_COL_SOURCE_ROW).Value = sourceRow
    ws.Cells(outputRow, DETAIL_COL_SELECTED).Value = "0"
    With ws.Range(ws.Cells(outputRow, 1), ws.Cells(outputRow, 7))
        .Borders.LineStyle = xlContinuous
        .Borders.Color = RGB(226, 232, 240)
        .WrapText = True
        .VerticalAlignment = xlTop
    End With
End Sub

Private Function WorkspaceDetailKeyColumn(ByVal sourceSheet As String) As Long
    Select Case sourceSheet
        Case SH_ANALYSIS_SHIFT: WorkspaceDetailKeyColumn = SHIFT_ANALYSIS_KEY_COL
        Case SH_ANALYSIS_FLOW: WorkspaceDetailKeyColumn = FLOW_ANALYSIS_KEY_COL
        Case SH_ANALYSIS_UNKNOWN: WorkspaceDetailKeyColumn = UNKNOWN_ANALYSIS_KEY_COL
        Case Else
            Err.Raise vbObjectError + 4811, "WorkspaceDetailKeyColumn", _
                      "���ڍׂ̓������\���s���ł��B"
    End Select
End Function

Private Sub ApplyAnalysisDetailStatusValidation(ByVal target As Range, _
                                                ByVal sourceSheet As String, _
                                                ByVal categoryText As String)
    Dim listName As String
    If sourceSheet = SH_ANALYSIS_SHIFT Or sourceSheet = SH_ANALYSIS_FLOW Then
        listName = NM_LST_ANALYSIS_SHIFT_STATUS
    ElseIf categoryText = "�����s��" Then
        listName = NM_LST_ANALYSIS_SOURCE_STATUS
    Else
        listName = NM_LST_ANALYSIS_USE_STATUS
    End If
    With target.Validation
        .Delete
        .Add Type:=xlValidateList, AlertStyle:=xlValidAlertStop, _
             Operator:=xlBetween, Formula1:="=" & listName
        .IgnoreBlank = True
        .InCellDropdown = True
        .ShowError = True
        .ErrorTitle = "�m�F�󋵂�I�����Ă�������"
        .ErrorMessage = "���̋敪�ɑΉ�����m�F�󋵂�I�����Ă��������B"
    End With
End Sub

Private Sub ApplyAnalysisDetailMemoValidation(ByVal target As Range)
    With target.Validation
        .Delete
        .Add Type:=xlValidateTextLength, AlertStyle:=xlValidAlertStop, _
             Operator:=xlLessEqual, Formula1:=CStr(WORKSPACE_MEMO_MAX)
        .IgnoreBlank = True
        .ShowError = True
        .ErrorTitle = "�m�F�����̕��������m�F���Ă�������"
        .ErrorMessage = "�m�F������" & CStr(WORKSPACE_MEMO_MAX) & "�����ȓ��œ��͂��Ă��������B"
    End With
End Sub

Private Sub WorkspaceTransactionDirection(ByRef data As Variant, ByVal sourceRow As Long, _
                                          ByRef kindText As String, ByRef amountValue As Double)
    If WorkspaceDouble(data(sourceRow, OUT_COL_WITHDRAW)) > 0 Then
        kindText = "�o��"
        amountValue = WorkspaceDouble(data(sourceRow, OUT_COL_WITHDRAW))
    ElseIf WorkspaceDouble(data(sourceRow, OUT_COL_DEPOSIT)) > 0 Then
        kindText = "����"
        amountValue = WorkspaceDouble(data(sourceRow, OUT_COL_DEPOSIT))
    Else
        kindText = "�ΏۊO"
        amountValue = 0
    End If
End Sub

Private Function WorkspacePersonIdentity(ByRef data As Variant, ByVal sourceRow As Long) As String
    Dim personID As String
    personID = CellText(data(sourceRow, WORK_TX_COL_PERSON_ID))
    If Len(personID) = 0 Then _
        Err.Raise vbObjectError + 4848, "WorkspacePersonIdentity", _
                  "W_��� " & CStr(sourceRow + 1) & _
                  "�s�ڂɐl��ID������܂���B�����ł͑�ւ����A�l�����������C�����Ă��������B"
    If Not IsInternalIdValue(personID, "P") Then _
        Err.Raise vbObjectError + 4849, "WorkspacePersonIdentity", _
                  "W_��� " & CStr(sourceRow + 1) & _
                  "�s�ڂ̐l��ID�`�����s���ł�: " & personID
    WorkspacePersonIdentity = personID
End Function

Private Sub AddWorkspaceIDsToSet(ByVal idList As String, ByVal target As Object)
    Dim parts As Variant, item As Variant, txID As String
    If Len(idList) = 0 Then Exit Sub
    parts = Split(idList, ";")
    For Each item In parts
        txID = Trim$(CStr(item))
        If Len(txID) > 0 Then target(txID) = True
    Next item
End Sub

Private Function WorkspaceJoinDictionaryKeys(ByVal values As Object) As String
    Dim keys As Variant, i As Long, j As Long, tempText As String
    If values Is Nothing Then Exit Function
    If values.Count = 0 Then Exit Function
    keys = values.Keys
    For i = LBound(keys) + 1 To UBound(keys)
        tempText = CStr(keys(i)): j = i - 1
        Do While j >= LBound(keys)
            If StrComp(CStr(keys(j)), tempText, vbTextCompare) <= 0 Then Exit Do
            keys(j + 1) = keys(j): j = j - 1
        Loop
        keys(j + 1) = tempText
    Next i
    For i = LBound(keys) To UBound(keys)
        If Len(WorkspaceJoinDictionaryKeys) > 0 Then WorkspaceJoinDictionaryKeys = WorkspaceJoinDictionaryKeys & ";"
        WorkspaceJoinDictionaryKeys = WorkspaceJoinDictionaryKeys & CStr(keys(i))
    Next i
End Function

Private Function WorkspaceJoinIDs(ByVal firstID As String, ByVal secondID As String) As String
    If Len(firstID) = 0 Then
        WorkspaceJoinIDs = secondID
    ElseIf Len(secondID) = 0 Then
        WorkspaceJoinIDs = firstID
    ElseIf StrComp(firstID, secondID, vbTextCompare) <= 0 Then
        WorkspaceJoinIDs = firstID & ";" & secondID
    Else
        WorkspaceJoinIDs = secondID & ";" & firstID
    End If
End Function

Private Function WorkspacePartyAccount(ByVal personValue As Variant, ByVal relationshipValue As Variant, _
                                       ByVal bankValue As Variant, ByVal branchValue As Variant, _
                                       ByVal typeValue As Variant, ByVal numberValue As Variant) As String
    Dim personText As String, accountText As String
    personText = CellText(personValue)
    If Len(personText) > 0 Then personText = personText & WorkspaceRelationshipSuffix(relationshipValue) & " "
    accountText = Trim$(CellText(bankValue) & " " & CellText(branchValue) & " " & _
                        CellText(typeValue) & " " & CellText(numberValue))
    WorkspacePartyAccount = Trim$(personText & accountText)
End Function

Private Function WorkspaceRelationshipSuffix(ByVal relationshipValue As Variant) As String
    If Len(CellText(relationshipValue)) > 0 Then _
        WorkspaceRelationshipSuffix = "�i" & CellText(relationshipValue) & "�j"
End Function

Private Function WorkspacePeriodText(ByVal firstDate As Variant, ByVal secondDate As Variant) As String
    Dim firstValue As Date, secondValue As Date
    If Not IsDate(firstDate) Or Not IsDate(secondDate) Then
        WorkspacePeriodText = WorkspaceDateText(firstDate) & " �` " & WorkspaceDateText(secondDate)
        Exit Function
    End If
    firstValue = DateSerial(Year(CDate(firstDate)), Month(CDate(firstDate)), Day(CDate(firstDate)))
    secondValue = DateSerial(Year(CDate(secondDate)), Month(CDate(secondDate)), Day(CDate(secondDate)))
    If firstValue = secondValue Then
        WorkspacePeriodText = Format$(firstValue, "yyyy/m/d") & "�i�����j"
    ElseIf firstValue < secondValue Then
        WorkspacePeriodText = Format$(firstValue, "yyyy/m/d") & " �` " & _
                              Format$(secondValue, "yyyy/m/d")
    Else
        WorkspacePeriodText = Format$(secondValue, "yyyy/m/d") & " �` " & _
                              Format$(firstValue, "yyyy/m/d")
    End If
End Function

Private Function WorkspaceDateText(ByVal valueIn As Variant) As String
    If IsDate(valueIn) Then WorkspaceDateText = Format$(CDate(valueIn), "yyyy/m/d") Else WorkspaceDateText = "���t�v�m�F"
End Function

Private Function WorkspaceTimeText(ByVal valueIn As Variant) As String
    Dim parsedTimeFraction As Double
    If WorkspaceTryTime(valueIn, parsedTimeFraction) Then
        WorkspaceTimeText = Format$(parsedTimeFraction, "hh:mm")
    Else
        WorkspaceTimeText = "�����L�ڂȂ�"
    End If
End Function

Private Function WorkspaceTryTime(ByVal valueIn As Variant, ByRef parsedTimeFraction As Double) As Boolean
    If IsError(valueIn) Or IsNull(valueIn) Or IsEmpty(valueIn) Then Exit Function
    If VarType(valueIn) = vbString And Len(Trim$(CStr(valueIn))) = 0 Then Exit Function
    If Not IsDate(valueIn) And Not IsNumeric(valueIn) Then Exit Function
    On Error GoTo InvalidTime
    parsedTimeFraction = CDbl(VBA.TimeValue(CDate(valueIn)))
    WorkspaceTryTime = (parsedTimeFraction >= 0 And parsedTimeFraction < 1)
    Exit Function
InvalidTime:
    WorkspaceTryTime = False
End Function

Private Function WorkspaceAmountText(ByVal valueIn As Variant) As String
    If IsNumeric(valueIn) Then WorkspaceAmountText = Format$(CDbl(valueIn), "#,##0.########") Else WorkspaceAmountText = "�v�m�F"
End Function

Private Function WorkspaceDouble(ByVal valueIn As Variant) As Double
    If IsError(valueIn) Or IsNull(valueIn) Or IsEmpty(valueIn) Then Exit Function
    If IsNumeric(valueIn) Then WorkspaceDouble = CDbl(valueIn)
End Function

Private Function WorkspaceLong(ByVal valueIn As Variant) As Long
    If IsError(valueIn) Or IsNull(valueIn) Or IsEmpty(valueIn) Then Exit Function
    If IsNumeric(valueIn) Then
        If CDbl(valueIn) >= -2147483648# And CDbl(valueIn) <= 2147483647# Then _
            WorkspaceLong = CLng(valueIn)
    End If
End Function

Private Function WorkspaceStatusOrDefault(ByVal valueIn As Variant) As String
    WorkspaceStatusOrDefault = CellText(valueIn)
    If Len(WorkspaceStatusOrDefault) = 0 Then WorkspaceStatusOrDefault = ANALYSIS_STATUS_UNREVIEWED
End Function

Private Function WorkspaceBlankLabel(ByVal valueIn As Variant) As String
    WorkspaceBlankLabel = CellText(valueIn)
    If Len(WorkspaceBlankLabel) = 0 Then WorkspaceBlankLabel = "�i�󗓁E�����^�̉\���j"
End Function

Private Function WorkspaceAppend(ByVal currentText As String, ByVal newText As String, _
                                 ByVal separatorText As String) As String
    If Len(newText) = 0 Then
        WorkspaceAppend = currentText
    ElseIf Len(currentText) = 0 Then
        WorkspaceAppend = newText
    Else
        WorkspaceAppend = currentText & separatorText & newText
    End If
End Function

Private Function WorkspaceTrimText(ByVal valueIn As String, ByVal maxLength As Long) As String
    If Len(valueIn) <= maxLength Then
        WorkspaceTrimText = valueIn
    Else
        WorkspaceTrimText = Left$(valueIn, maxLength - 14) & "�c�i�����̂��߈ꕔ�\���j"
    End If
End Function

Private Function WorkspaceRateTolerance(ByVal rateCell As Range) As Double
    Dim numericValue As Double
    If rateCell Is Nothing Then Exit Function
    If Not IsNumeric(rateCell.Value) Then Exit Function
    numericValue = CDbl(rateCell.Value)
    If InStr(1, rateCell.NumberFormat, "%", vbBinaryCompare) > 0 Or _
       InStr(1, rateCell.NumberFormatLocal, "%", vbBinaryCompare) > 0 Then
        WorkspaceRateTolerance = numericValue
    Else
        WorkspaceRateTolerance = numericValue / 100#
    End If
End Function

Private Function WorkspaceDigest(ByVal rawText As String) As String
    Dim firstHash As Double, secondHash As Double, i As Long, codeValue As Long
    firstHash = 104729#: secondHash = 130363#
    For i = 1 To Len(rawText)
        codeValue = AscW(Mid$(rawText, i, 1))
        If codeValue < 0 Then codeValue = codeValue + 65536
        firstHash = firstHash * 257# + codeValue + i
        firstHash = firstHash - Fix(firstHash / 2147483629#) * 2147483629#
        secondHash = secondHash * 263# + codeValue + i * 3#
        secondHash = secondHash - Fix(secondHash / 2147483587#) * 2147483587#
    Next i
    WorkspaceDigest = Right$("00000000" & Hex$(CLng(firstHash)), 8) & "-" & _
                      Right$("00000000" & Hex$(CLng(secondHash)), 8)
End Function

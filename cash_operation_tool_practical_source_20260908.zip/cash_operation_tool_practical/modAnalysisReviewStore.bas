Attribute VB_Name = "modAnalysisReviewStore"
Option Explicit

'�������\�͕��͏����ɂ��s���̂�������B���f�䒠�����\����Ɨ������A
'��₪�ꎞ�I�ɏ����Ă��m�F�󋵁E�����E�����̍���������Ȃ��悤�ɂ���B

Private mReviewPersistActive As Boolean
Private mReviewStoreNextRow As Long
Private mReviewHistoryNextRow As Long
Private mReviewCommitStamp As Date
Private mReviewCommitUser As String
Private mReviewActualStoreAdds As Long
Private mReviewActualHistoryAdds As Long
Private mAllocationBatchActive As Boolean

'W_���͔��f�䒠��A:M�͊����̌�┻�f�䒠�Ƃ��ČŒ肷��BN������E�Ƃ��ċ󂯁A
'O:X�ɔz��1��=1�s�̓Ɨ�������u���B�V�����V�[�g�����A:M�̍s�Ӗ��𑝂₳�Ȃ��B
Private Const ALLOC_LEDGER_FIRST_COL As Long = 15       'O
Private Const ALLOC_LEDGER_COL_ID As Long = 15
Private Const ALLOC_LEDGER_COL_CANDIDATE_KEY As Long = 16
Private Const ALLOC_LEDGER_COL_TRANSACTION_ID As Long = 17
Private Const ALLOC_LEDGER_COL_DIRECTION As Long = 18
Private Const ALLOC_LEDGER_COL_AMOUNT As Long = 19
Private Const ALLOC_LEDGER_COL_STATUS As Long = 20
Private Const ALLOC_LEDGER_COL_EVIDENCE As Long = 21
Private Const ALLOC_LEDGER_COL_SOURCE_TYPE As Long = 22
Private Const ALLOC_LEDGER_COL_SOURCE_AMOUNT As Long = 23
Private Const ALLOC_LEDGER_COL_UPDATED_AT As Long = 24  'X
Private Const ALLOC_LEDGER_LAST_COL As Long = ALLOC_LEDGER_COL_UPDATED_AT
Private Const ALLOC_LEDGER_COLUMN_COUNT As Long = 10
Private Const ALLOC_DATA_COL_ID As Long = 1
Private Const ALLOC_DATA_COL_CANDIDATE_KEY As Long = 2
Private Const ALLOC_DATA_COL_TRANSACTION_ID As Long = 3
Private Const ALLOC_DATA_COL_DIRECTION As Long = 4
Private Const ALLOC_DATA_COL_AMOUNT As Long = 5
Private Const ALLOC_DATA_COL_STATUS As Long = 6
Private Const ALLOC_DATA_COL_EVIDENCE As Long = 7
Private Const ALLOC_DATA_COL_SOURCE_TYPE As Long = 8
Private Const ALLOC_DATA_COL_SOURCE_AMOUNT As Long = 9
Private Const ALLOC_DATA_COL_UPDATED_AT As Long = 10

Private Const ALLOC_INPUT_COL_CANDIDATE_KEY As Long = 1
Private Const ALLOC_INPUT_COL_TRANSACTION_ID As Long = 2
Private Const ALLOC_INPUT_COL_DIRECTION As Long = 3
Private Const ALLOC_INPUT_COL_AMOUNT As Long = 4
Private Const ALLOC_INPUT_COL_STATUS As Long = 5
Private Const ALLOC_INPUT_COL_EVIDENCE As Long = 6
Private Const ALLOC_INPUT_COL_SOURCE_TYPE As Long = 7
Private Const ALLOC_INPUT_COL_SOURCE_AMOUNT As Long = 8
Private Const ALLOC_INPUT_COLUMN_COUNT As Long = 8

Public Const ALLOCATION_DIRECTION_WITHDRAW As String = "WITHDRAW"
Public Const ALLOCATION_DIRECTION_DEPOSIT As String = "DEPOSIT"
Public Const ALLOCATION_STATUS_CONFIRMED As String = "CONFIRMED"
Public Const ALLOCATION_STATUS_REVIEW_REQUIRED As String = "REVIEW_REQUIRED"
Public Const ALLOCATION_STATUS_EXCLUDED As String = "EXCLUDED"
Public Const ALLOCATION_STATUS_UNREVIEWED As String = "UNREVIEWED"
Public Const ALLOCATION_STATUS_UNTRACKED As String = "UNTRACKED"
Public Const ALLOCATION_SOURCE_RESIDUAL As String = "RESIDUAL"
Public Const ALLOCATION_SOURCE_RESIDUAL_LOT As String = "RESIDUAL_LOT"
Public Const ALLOCATION_SOURCE_SCOPE As String = "SCOPE"

Public Function AnalysisReviewStoreHeaders() As Variant
    AnalysisReviewStoreHeaders = Array( _
        "���L�[", "���\", "�敪", "�m�F��", "�m�F����", "��������", _
        "�\�����ID", "�X�V����", "���s���", "�O��m�F��", "�O�񍪋�����", _
        "�ύX���R", "�m�F��")
End Function

Public Function AnalysisReviewHistoryHeaders() As Variant
    AnalysisReviewHistoryHeaders = Array( _
        "����ID", "���L�[", "�ύX����", "�m�F��", "���\", "�敪", _
        "���m�F��", "�V�m�F��", "���m�F����", "�V�m�F����", _
        "����������", "�V��������", "�ύX���R")
End Function

Public Function AllocationLedgerHeaders() As Variant
    AllocationLedgerHeaders = Array( _
        "AllocationID", "CandidateKey", "TransactionID", "Direction", _
        "AllocatedAmount", "DecisionStatus", "EvidenceDigest", "SourceType", _
        "SourceAmount", "UpdatedAt")
End Function

Public Sub SetupAnalysisReviewStores(Optional ByVal resetContents As Boolean = False)
    PrepareAnalysisReviewStoreSheet GetOrCreateSheet(SH_WORK_ANALYSIS_REVIEW, False), _
                                    resetContents, AnalysisReviewStoreHeaders(), _
                                    ANALYSIS_REVIEW_STORE_LAST_COL
    PrepareAnalysisReviewStoreSheet GetOrCreateSheet(SH_WORK_ANALYSIS_HISTORY, False), _
                                    resetContents, AnalysisReviewHistoryHeaders(), _
                                    ANALYSIS_HISTORY_STORE_LAST_COL
    SetupAllocationLedger resetContents
End Sub

Public Sub SetupAllocationLedger(Optional ByVal resetContents As Boolean = False)
    Dim ws As Worksheet
    Set ws = GetSheet(SH_WORK_ANALYSIS_REVIEW)
    If resetContents Then _
        ws.Range(ws.Cells(1, ALLOC_LEDGER_FIRST_COL), _
                 ws.Cells(ws.Rows.Count, ALLOC_LEDGER_LAST_COL)).ClearContents
    If Len(CellText(ws.Cells(1, ALLOC_LEDGER_FIRST_COL).Value2)) = 0 Then _
        SetRowValues ws.Cells(1, ALLOC_LEDGER_FIRST_COL), AllocationLedgerHeaders()
    ws.Range(ws.Cells(1, ALLOC_LEDGER_FIRST_COL), _
             ws.Cells(1, ALLOC_LEDGER_LAST_COL)).Font.Bold = True
    ws.Range(ws.Cells(1, ALLOC_LEDGER_FIRST_COL), _
             ws.Cells(1, ALLOC_LEDGER_LAST_COL)).Interior.Color = RGB(68, 114, 196)
    ws.Range(ws.Cells(1, ALLOC_LEDGER_FIRST_COL), _
             ws.Cells(1, ALLOC_LEDGER_LAST_COL)).Font.Color = vbWhite
    ws.Range(ws.Cells(1, ALLOC_LEDGER_FIRST_COL), _
             ws.Cells(ws.Rows.Count, ALLOC_LEDGER_LAST_COL)).NumberFormatLocal = "@"
    ws.Columns(ALLOC_LEDGER_COL_AMOUNT).NumberFormatLocal = "#,##0.########"
    ws.Columns(ALLOC_LEDGER_COL_SOURCE_AMOUNT).NumberFormatLocal = "#,##0.########"
    ws.Columns(ALLOC_LEDGER_COL_UPDATED_AT).NumberFormatLocal = "yyyy/m/d h:mm:ss"
    SetSheetVeryHiddenSafe ws
End Sub

Public Sub CommitAllocationBatch(ByVal rows As Variant, _
                                 Optional ByVal sourceType As String = "", _
                                 Optional ByVal evidenceDigest As String = "")
    '���P�ʂ̑����m��B��������E�����ɂ���ʌ��͕ێ�����B
    CommitAllocationBatchCore rows, sourceType, evidenceDigest, False, False
End Sub

Public Sub ReplaceAllocationPlanForTransactions( _
        ByVal rows As Variant, Optional ByVal sourceType As String = "", _
        Optional ByVal evidenceDigest As String = "", _
        Optional ByVal replaceEntireLedger As Boolean = False)
    '�S���͍č\�z��p�Brows�Ɋ܂߂�����E�����̋�����S�ĊO���A
    '�V����plan�Ǝc���ֈꊇ�u������B�z��0���̑Ώۂ�SourceType=SCOPE��
    '����s�Ŗ�������BSCOPE�s���̂͌����֕ۑ����Ȃ��BW_����S�̂�
    '�č\�z����ꍇ��replaceEntireLedger=True�Ƃ��A�폜�ς݋�������c���Ȃ��B
    CommitAllocationBatchCore rows, sourceType, evidenceDigest, True, _
                              replaceEntireLedger
End Sub

Public Sub ClearAnalysisAllocationPlan()
    'W_�����0���ɂȂ����S���͍č\�z��p�B������̔z�����c�����A
    'O:X�����𓯈�snapshot��������E�ǖ߂��E���؂���B
    Dim ws As Worksheet, ledgerProblems As String
    Dim snapshot As Variant, snapshotLastRow As Long
    Dim writeStarted As Boolean, rollbackVerified As Boolean
    Dim errorNumber As Long, errorDescription As String, rollbackDetail As String

    If mAllocationBatchActive Then _
        Err.Raise vbObjectError + 4998, "ClearAnalysisAllocationPlan", _
                  "�z�������̍X�V���������Ɏ��s���ł��B"
    On Error GoTo EH
    mAllocationBatchActive = True
    Set ws = GetSheet(SH_WORK_ANALYSIS_REVIEW)
    If Not ValidateAllocationLedgerSheet(ws, ledgerProblems) Then _
        Err.Raise vbObjectError + 4999, "ClearAnalysisAllocationPlan", _
                  "�����̔z���������s���ł�: " & ledgerProblems
    CaptureAllocationLedgerSnapshot ws, snapshot, snapshotLastRow
    If snapshotLastRow >= 2 Then
        writeStarted = True
        ws.Range(ws.Cells(2, ALLOC_LEDGER_FIRST_COL), _
                 ws.Cells(snapshotLastRow, ALLOC_LEDGER_LAST_COL)).ClearContents
        If AllocationLedgerLastRow(ws) <> 1 Then _
            Err.Raise vbObjectError + 5000, "ClearAnalysisAllocationPlan", _
                      "�z�������̏�����s������v���܂���B"
        ledgerProblems = vbNullString
        If Not ValidateAllocationLedgerSheet(ws, ledgerProblems) Then _
            Err.Raise vbObjectError + 5001, "ClearAnalysisAllocationPlan", _
                      "�z�������̏����㌟�؂Ɏ��s���܂���: " & ledgerProblems
        MarkOutputsDirty
    End If
    SetSheetVeryHiddenSafe ws
    If Not AllocationLedgerIsVeryHidden(ws) Then _
        Err.Raise vbObjectError + 5002, "ClearAnalysisAllocationPlan", _
                  "�z�������������\���֖߂��܂���B"
    mAllocationBatchActive = False
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    If writeStarted Then
        rollbackVerified = TryRollbackAllocationLedger( _
                               ws, snapshot, snapshotLastRow, rollbackDetail)
        If Not rollbackVerified Then _
            AppendAnalysisReviewRollbackDetail rollbackDetail, _
                "����Recovery�̏��L�����O���̎������transaction�֓`�d���܂����B"
    End If
    mAllocationBatchActive = False
    If Len(rollbackDetail) > 0 Then _
        errorDescription = errorDescription & " / ���[���o�b�N�m�F: " & rollbackDetail
    Err.Raise errorNumber, "ClearAnalysisAllocationPlan", errorDescription
End Sub

Private Sub CommitAllocationBatchCore( _
        ByVal rows As Variant, ByVal sourceType As String, _
        ByVal evidenceDigest As String, ByVal replaceAllGroups As Boolean, _
        ByVal replaceEntireLedger As Boolean)
    'rows��8��: CandidateKey, TransactionID, Direction, AllocatedAmount,
    'DecisionStatus, EvidenceDigest, SourceType, SourceAmount�B
    '����܂��͈ꑀ��Ɋ܂܂��S������A���snapshot����ꊇ�m�肷��B
    Dim ws As Worksheet
    Dim firstInputRow As Long, lastInputRow As Long, inputRowCount As Long
    Dim firstInputCol As Long, lastInputCol As Long, inputColumnCount As Long
    Dim inputRow As Long, normalizedRow As Long, componentRow As Long, c As Long
    Dim normalized() As Variant
    Dim candidateKey As String, transactionID As String, directionText As String
    Dim statusText As String, rowEvidence As String, rowSourceType As String
    Dim allocatedAmount As Double, sourceAmount As Double
    Dim groupKey As String, candidateGroupKey As String, item As Variant
    Dim componentItem As Variant, componentIDs As Variant
    Dim isResidualLot As Boolean, isScopeRow As Boolean
    Dim affectedGroups As Object, sourceAmounts As Object
    Dim confirmedTotals As Object, proposedTotals As Object, seenCandidates As Object
    Dim affectedCandidates As Object, residualLotRows As Object
    Dim ledgerProblems As String
    Dim snapshot As Variant, snapshotLastRow As Long, oldRows As Long
    Dim oldData As Variant, outputData As Variant
    Dim retainedRows As Long, outputRows As Long, writeRow As Long
    Dim persistedInputRows As Long
    Dim retainRow As Boolean
    Dim allocationID As String, idSet As Object
    Dim residualAmount As Double, commitStamp As Date
    Dim lotSourceTotal As Double, lotResidualAvailable As Double, lotAmount As Double
    Dim writeStarted As Boolean, rollbackVerified As Boolean
    Dim errorNumber As Long, errorDescription As String, rollbackDetail As String

    If mAllocationBatchActive Then _
        Err.Raise vbObjectError + 4931, "CommitAllocationBatch", _
                  "�z�������̍X�V���������Ɏ��s���ł��B"
    If Not AllocationBatchShape(rows, firstInputRow, lastInputRow, _
            firstInputCol, lastInputCol) Then _
        Err.Raise vbObjectError + 4932, "CommitAllocationBatch", _
                  "�z���o�b�`��8��̓񎟌��z��Ŏw�肵�Ă��������B"
    inputRowCount = lastInputRow - firstInputRow + 1
    inputColumnCount = lastInputCol - firstInputCol + 1
    If inputRowCount < 1 Or inputColumnCount <> ALLOC_INPUT_COLUMN_COUNT Then _
        Err.Raise vbObjectError + 4932, "CommitAllocationBatch", _
                  "�z���o�b�`�̍s���܂��͗񐔂��s���ł��B"
    If inputRowCount > MAX_INTERNAL_STORE_DATA_ROWS Then _
        Err.Raise vbObjectError + 4933, "CommitAllocationBatch", _
                  "�z���o�b�`���ۑ�����𒴂��Ă��܂��B"

    Set affectedGroups = CreateObject("Scripting.Dictionary")
    affectedGroups.CompareMode = vbBinaryCompare
    Set sourceAmounts = CreateObject("Scripting.Dictionary")
    sourceAmounts.CompareMode = vbBinaryCompare
    Set confirmedTotals = CreateObject("Scripting.Dictionary")
    confirmedTotals.CompareMode = vbBinaryCompare
    Set proposedTotals = CreateObject("Scripting.Dictionary")
    proposedTotals.CompareMode = vbBinaryCompare
    Set seenCandidates = CreateObject("Scripting.Dictionary")
    seenCandidates.CompareMode = vbBinaryCompare
    Set affectedCandidates = CreateObject("Scripting.Dictionary")
    affectedCandidates.CompareMode = vbBinaryCompare
    Set residualLotRows = CreateObject("Scripting.Dictionary")
    residualLotRows.CompareMode = vbBinaryCompare
    ReDim normalized(1 To inputRowCount, 1 To ALLOC_INPUT_COLUMN_COUNT)

    sourceType = Trim$(sourceType)
    evidenceDigest = Trim$(evidenceDigest)
    For inputRow = firstInputRow To lastInputRow
        normalizedRow = inputRow - firstInputRow + 1
        candidateKey = AllocationRequiredText( _
            rows(inputRow, firstInputCol + ALLOC_INPUT_COL_CANDIDATE_KEY - 1), _
            "CandidateKey")
        transactionID = AllocationRequiredText( _
            rows(inputRow, firstInputCol + ALLOC_INPUT_COL_TRANSACTION_ID - 1), _
            "TransactionID")
        directionText = UCase$(AllocationRequiredText( _
            rows(inputRow, firstInputCol + ALLOC_INPUT_COL_DIRECTION - 1), _
            "Direction"))
        If Not AllocationDirectionIsValid(directionText) Then _
            Err.Raise vbObjectError + 4934, "CommitAllocationBatch", _
                      "Direction��WITHDRAW�܂���DEPOSIT�Ŏw�肵�Ă�������: " & directionText
        allocatedAmount = AllocationRequiredAmount( _
            rows(inputRow, firstInputCol + ALLOC_INPUT_COL_AMOUNT - 1), _
            "AllocatedAmount")
        statusText = UCase$(AllocationRequiredText( _
            rows(inputRow, firstInputCol + ALLOC_INPUT_COL_STATUS - 1), _
            "DecisionStatus"))
        If Not AllocationInputStatusIsValid(statusText) Then _
            Err.Raise vbObjectError + 4935, "CommitAllocationBatch", _
                      "DecisionStatus���s���ł�: " & statusText
        rowEvidence = Trim$(CellText(rows(inputRow, _
            firstInputCol + ALLOC_INPUT_COL_EVIDENCE - 1)))
        If Len(rowEvidence) = 0 Then rowEvidence = evidenceDigest
        rowSourceType = Trim$(CellText(rows(inputRow, _
            firstInputCol + ALLOC_INPUT_COL_SOURCE_TYPE - 1)))
        If Len(rowSourceType) = 0 Then rowSourceType = sourceType
        rowSourceType = AllocationRequiredText(rowSourceType, "SourceType")
        If StrComp(rowSourceType, ALLOCATION_SOURCE_RESIDUAL_LOT, vbTextCompare) = 0 Then _
            rowSourceType = ALLOCATION_SOURCE_RESIDUAL_LOT
        If StrComp(rowSourceType, ALLOCATION_SOURCE_SCOPE, vbTextCompare) = 0 Then _
            rowSourceType = ALLOCATION_SOURCE_SCOPE
        If StrComp(rowSourceType, ALLOCATION_SOURCE_RESIDUAL, vbTextCompare) = 0 Then _
            Err.Raise vbObjectError + 4937, "CommitAllocationBatch", _
                      "���͔z����SourceType��RESIDUAL�͎w��ł��܂���B"
        sourceAmount = AllocationRequiredAmount( _
            rows(inputRow, firstInputCol + ALLOC_INPUT_COL_SOURCE_AMOUNT - 1), _
            "SourceAmount")
        If allocatedAmount > sourceAmount + AllocationTolerance(sourceAmount) Then _
            Err.Raise vbObjectError + 4938, "CommitAllocationBatch", _
                      "�z���z�������z�𒴂��Ă��܂�: " & transactionID
        isResidualLot = (StrComp(rowSourceType, ALLOCATION_SOURCE_RESIDUAL_LOT, _
                                 vbBinaryCompare) = 0)
        isScopeRow = (StrComp(rowSourceType, ALLOCATION_SOURCE_SCOPE, _
                             vbBinaryCompare) = 0)
        If Not isScopeRow And Not ReviewEvidenceDigestIsValid(rowEvidence) Then _
            Err.Raise vbObjectError + 4936, "CommitAllocationBatch", _
                      "EvidenceDigest���s���ł�: " & candidateKey
        If isScopeRow Then
            If Not replaceAllGroups Then _
                Err.Raise vbObjectError + 4937, "CommitAllocationBatch", _
                          "SCOPE����s�͑S���͒u��API�����Ŏw��ł��܂��B"
            If allocatedAmount <> 0# Or statusText <> ALLOCATION_STATUS_UNREVIEWED Then _
                Err.Raise vbObjectError + 4939, "CommitAllocationBatch", _
                          "SCOPE����s��0�~�EUNREVIEWED�Ŏw�肵�Ă��������B"
            rowEvidence = vbNullString
        End If
        If isResidualLot Then
            If statusText <> ALLOCATION_STATUS_REVIEW_REQUIRED Then _
                Err.Raise vbObjectError + 4939, "CommitAllocationBatch", _
                          "RESIDUAL_LOT��REVIEW_REQUIRED�łȂ���΂Ȃ�܂���B"
            transactionID = CanonicalResidualLotTransactionIDs(transactionID)
            residualLotRows.Add CStr(normalizedRow), transactionID
        ElseIf (statusText = ALLOCATION_STATUS_EXCLUDED Or _
            statusText = ALLOCATION_STATUS_UNREVIEWED) And allocatedAmount <> 0# Then _
            Err.Raise vbObjectError + 4939, "CommitAllocationBatch", _
                      "EXCLUDED�܂���UNREVIEWED�̔z���z��0�łȂ���΂Ȃ�܂���B"
        End If

        If Not isScopeRow Then
            persistedInputRows = persistedInputRows + 1
            If Not affectedCandidates.Exists(candidateKey) Then _
                affectedCandidates.Add candidateKey, True
        End If
        If Not isResidualLot Then
            groupKey = AllocationGroupKey(transactionID, directionText)
            If Not affectedGroups.Exists(groupKey) Then
                affectedGroups.Add groupKey, True
                sourceAmounts.Add groupKey, sourceAmount
                confirmedTotals.Add groupKey, 0#
                proposedTotals.Add groupKey, 0#
            ElseIf Not AllocationAmountsMatch(CDbl(sourceAmounts(groupKey)), sourceAmount) Then
                Err.Raise vbObjectError + 4940, "CommitAllocationBatch", _
                          "��������E������SourceAmount����v���܂���: " & transactionID
            End If
            If Not isScopeRow Then
                candidateGroupKey = groupKey & ChrW$(30) & candidateKey
                If seenCandidates.Exists(candidateGroupKey) Then _
                    Err.Raise vbObjectError + 4941, "CommitAllocationBatch", _
                              "��������E�����E���̔z�����d�����Ă��܂�: " & candidateKey
                seenCandidates.Add candidateGroupKey, normalizedRow
                proposedTotals(groupKey) = CDbl(proposedTotals(groupKey)) + allocatedAmount
                If statusText = ALLOCATION_STATUS_CONFIRMED Then _
                    confirmedTotals(groupKey) = CDbl(confirmedTotals(groupKey)) + allocatedAmount
            End If
        End If

        normalized(normalizedRow, ALLOC_INPUT_COL_CANDIDATE_KEY) = candidateKey
        normalized(normalizedRow, ALLOC_INPUT_COL_TRANSACTION_ID) = transactionID
        normalized(normalizedRow, ALLOC_INPUT_COL_DIRECTION) = directionText
        normalized(normalizedRow, ALLOC_INPUT_COL_AMOUNT) = allocatedAmount
        normalized(normalizedRow, ALLOC_INPUT_COL_STATUS) = statusText
        normalized(normalizedRow, ALLOC_INPUT_COL_EVIDENCE) = rowEvidence
        normalized(normalizedRow, ALLOC_INPUT_COL_SOURCE_TYPE) = rowSourceType
        normalized(normalizedRow, ALLOC_INPUT_COL_SOURCE_AMOUNT) = sourceAmount
    Next inputRow
    '�B����n:n����ResidualLot�����Ō��z�������Ȃ��B����atomic batch���ɁA
    '�S�\�������0�~REVIEW_REQUIRED�s��v�����A�e����̎c���𖞊z��������B
    For Each item In residualLotRows.Keys
        normalizedRow = CLng(item)
        componentIDs = Split(CStr(residualLotRows(CStr(item))), ";")
        directionText = CStr(normalized(normalizedRow, ALLOC_INPUT_COL_DIRECTION))
        For Each componentItem In componentIDs
            groupKey = AllocationGroupKey(CStr(componentItem), directionText)
            If Not affectedGroups.Exists(groupKey) Then _
                Err.Raise vbObjectError + 4942, "CommitAllocationBatch", _
                          "RESIDUAL_LOT�̑S�\������𓯂�batch�֊܂߂Ă�������: " & _
                          CStr(componentItem)
            candidateGroupKey = groupKey & ChrW$(30) & _
                                CStr(normalized(normalizedRow, _
                                      ALLOC_INPUT_COL_CANDIDATE_KEY))
            If Not seenCandidates.Exists(candidateGroupKey) Then _
                Err.Raise vbObjectError + 4942, "CommitAllocationBatch", _
                          "RESIDUAL_LOT�\������̌���0�~�s������܂���: " & _
                          CStr(componentItem)
            componentRow = CLng(seenCandidates(candidateGroupKey))
            If CDbl(normalized(componentRow, ALLOC_INPUT_COL_AMOUNT)) <> 0# Or _
               CStr(normalized(componentRow, ALLOC_INPUT_COL_STATUS)) <> _
                   ALLOCATION_STATUS_REVIEW_REQUIRED Then _
                Err.Raise vbObjectError + 4942, "CommitAllocationBatch", _
                          "RESIDUAL_LOT�\�������0�~�EREVIEW_REQUIRED�Ŏw�肵�Ă�������: " & _
                          CStr(componentItem)
            If CDbl(confirmedTotals(groupKey)) <> 0# Or _
               CDbl(proposedTotals(groupKey)) <> 0# Then _
                Err.Raise vbObjectError + 4942, "CommitAllocationBatch", _
                          "RESIDUAL_LOT�\�������active�z����0�łȂ���΂Ȃ�܂���: " & _
                          CStr(componentItem)
        Next componentItem
    Next item
    For Each item In affectedGroups.Keys
        groupKey = CStr(item)
        sourceAmount = CDbl(sourceAmounts(groupKey))
        If CDbl(confirmedTotals(groupKey)) > _
           sourceAmount + AllocationTolerance(sourceAmount) Then _
            Err.Raise vbObjectError + 4942, "CommitAllocationBatch", _
                      "�m��z�����v�������z�𒴂��Ă��܂�: " & groupKey
        If CDbl(proposedTotals(groupKey)) > _
           sourceAmount + AllocationTolerance(sourceAmount) Then _
            Err.Raise vbObjectError + 4943, "CommitAllocationBatch", _
                      "��Ē����܂ޔz�����v�������z�𒴂��Ă��܂�: " & groupKey
    Next item

    On Error GoTo EH
    mAllocationBatchActive = True
    Set ws = GetSheet(SH_WORK_ANALYSIS_REVIEW)
    If Not ValidateAllocationLedgerSheet(ws, ledgerProblems) Then _
        Err.Raise vbObjectError + 4944, "CommitAllocationBatch", _
                  "�����̔z���������s���ł�: " & ledgerProblems
    CaptureAllocationLedgerSnapshot ws, snapshot, snapshotLastRow
    oldRows = snapshotLastRow - 1
    If oldRows > 0 Then oldData = snapshot
    '��������֌ォ��ʌ����m�肵�Ă��A�����̕ʌ��z���������Ȃ��B
    '�u���Ώۂ́u����batch�Ɋ܂܂����~����E�����v�����Ƃ��A�c����z��
    '���v�։�������Œ��߂Ǝc�����Čv�Z����B
    If Not replaceAllGroups Then
        For inputRow = 1 To oldRows
            rowSourceType = CellText(oldData(inputRow, ALLOC_DATA_COL_SOURCE_TYPE))
            If rowSourceType <> ALLOCATION_SOURCE_RESIDUAL And _
               rowSourceType <> ALLOCATION_SOURCE_RESIDUAL_LOT Then
                groupKey = AllocationGroupKey( _
                    CellText(oldData(inputRow, ALLOC_DATA_COL_TRANSACTION_ID)), _
                    CellText(oldData(inputRow, ALLOC_DATA_COL_DIRECTION)))
                candidateKey = CellText(oldData(inputRow, ALLOC_DATA_COL_CANDIDATE_KEY))
                candidateGroupKey = groupKey & ChrW$(30) & candidateKey
                If affectedGroups.Exists(groupKey) And _
                   Not seenCandidates.Exists(candidateGroupKey) Then
                    sourceAmount = CDbl(oldData(inputRow, ALLOC_DATA_COL_SOURCE_AMOUNT))
                    If Not AllocationAmountsMatch(CDbl(sourceAmounts(groupKey)), sourceAmount) Then _
                        Err.Raise vbObjectError + 4940, "CommitAllocationBatch", _
                                  "�����z����batch��SourceAmount����v���܂���: " & groupKey
                    allocatedAmount = CDbl(oldData(inputRow, ALLOC_DATA_COL_AMOUNT))
                    proposedTotals(groupKey) = CDbl(proposedTotals(groupKey)) + allocatedAmount
                    If CellText(oldData(inputRow, ALLOC_DATA_COL_STATUS)) = _
                       ALLOCATION_STATUS_CONFIRMED Then _
                        confirmedTotals(groupKey) = _
                            CDbl(confirmedTotals(groupKey)) + allocatedAmount
                End If
            End If
        Next inputRow
    End If
    For Each item In affectedGroups.Keys
        groupKey = CStr(item)
        sourceAmount = CDbl(sourceAmounts(groupKey))
        If CDbl(confirmedTotals(groupKey)) > _
           sourceAmount + AllocationTolerance(sourceAmount) Then _
            Err.Raise vbObjectError + 4942, "CommitAllocationBatch", _
                      "���������܂ފm��z�����v�������z�𒴂��Ă��܂�: " & groupKey
        If CDbl(proposedTotals(groupKey)) > _
           sourceAmount + AllocationTolerance(sourceAmount) Then _
            Err.Raise vbObjectError + 4943, "CommitAllocationBatch", _
                      "���������܂ޒ�Ĕz�����v�������z�𒴂��Ă��܂�: " & groupKey
    Next item
    For Each item In residualLotRows.Keys
        normalizedRow = CLng(item)
        componentIDs = Split(CStr(residualLotRows(CStr(item))), ";")
        directionText = CStr(normalized(normalizedRow, ALLOC_INPUT_COL_DIRECTION))
        lotSourceTotal = 0#: lotResidualAvailable = 0#
        For Each componentItem In componentIDs
            groupKey = AllocationGroupKey(CStr(componentItem), directionText)
            lotSourceTotal = lotSourceTotal + CDbl(sourceAmounts(groupKey))
            lotResidualAvailable = lotResidualAvailable + _
                CDbl(sourceAmounts(groupKey)) - CDbl(confirmedTotals(groupKey))
        Next componentItem
        If Not AllocationAmountsMatch( _
                   CDbl(normalized(normalizedRow, ALLOC_INPUT_COL_SOURCE_AMOUNT)), _
                   lotSourceTotal) Then _
            Err.Raise vbObjectError + 4943, "CommitAllocationBatch", _
                      "RESIDUAL_LOT��SourceAmount�͍\��������z���v�ƈ�v�����Ă��������B"
        lotAmount = CDbl(normalized(normalizedRow, ALLOC_INPUT_COL_AMOUNT))
        If Not AllocationAmountsMatch(lotAmount, lotSourceTotal) Then _
            Err.Raise vbObjectError + 4943, "CommitAllocationBatch", _
                      "RESIDUAL_LOT�z�͍\��������z���v�̖��z�Ŏw�肵�Ă��������B"
        If lotAmount > lotResidualAvailable + AllocationTolerance(lotSourceTotal) Then _
            Err.Raise vbObjectError + 4943, "CommitAllocationBatch", _
                      "RESIDUAL_LOT�z���\������̖��ǐՎc�z���v�𒴂��Ă��܂��B"
    Next item
    For inputRow = 1 To oldRows
        If replaceEntireLedger Then
            retainRow = False
        Else
            retainRow = AllocationExistingRowShouldBeRetained( _
                oldData, inputRow, affectedGroups, affectedCandidates, seenCandidates, _
                replaceAllGroups)
        End If
        If retainRow Then retainedRows = retainedRows + 1
    Next inputRow
    outputRows = retainedRows + persistedInputRows + affectedGroups.Count
    If outputRows < 1 Or outputRows > MAX_INTERNAL_STORE_DATA_ROWS Or _
       outputRows + 1 > ws.Rows.Count Then _
        Err.Raise vbObjectError + 4945, "CommitAllocationBatch", _
                  "�z�������̊m���s�����ۑ�����𒴂��܂��B"
    ReDim outputData(1 To outputRows, 1 To ALLOC_LEDGER_COLUMN_COUNT)
    Set idSet = CreateObject("Scripting.Dictionary")
    idSet.CompareMode = vbBinaryCompare
    For inputRow = 1 To oldRows
        If replaceEntireLedger Then
            retainRow = False
        Else
            retainRow = AllocationExistingRowShouldBeRetained( _
                oldData, inputRow, affectedGroups, affectedCandidates, seenCandidates, _
                replaceAllGroups)
        End If
        If retainRow Then
            writeRow = writeRow + 1
            For c = 1 To ALLOC_LEDGER_COLUMN_COUNT
                outputData(writeRow, c) = oldData(inputRow, c)
            Next c
            allocationID = CellText(outputData(writeRow, ALLOC_DATA_COL_ID))
            If idSet.Exists(allocationID) Then _
                Err.Raise vbObjectError + 4946, "CommitAllocationBatch", _
                          "����AllocationID���d�����Ă��܂�: " & allocationID
            idSet.Add allocationID, True
        End If
    Next inputRow
    commitStamp = Now
    For inputRow = 1 To inputRowCount
        candidateKey = CStr(normalized(inputRow, ALLOC_INPUT_COL_CANDIDATE_KEY))
        transactionID = CStr(normalized(inputRow, ALLOC_INPUT_COL_TRANSACTION_ID))
        directionText = CStr(normalized(inputRow, ALLOC_INPUT_COL_DIRECTION))
        rowSourceType = CStr(normalized(inputRow, ALLOC_INPUT_COL_SOURCE_TYPE))
        If rowSourceType = ALLOCATION_SOURCE_SCOPE Then GoTo NextAllocationInputRow
        writeRow = writeRow + 1
        If rowSourceType = ALLOCATION_SOURCE_RESIDUAL_LOT Then
            allocationID = StableResidualLotID(candidateKey, transactionID, directionText)
        Else
            allocationID = StableAllocationID(candidateKey, transactionID, directionText, False)
        End If
        If idSet.Exists(allocationID) Then _
            Err.Raise vbObjectError + 4947, "CommitAllocationBatch", _
                      "AllocationID���Փ˂��Ă��܂�: " & allocationID
        idSet.Add allocationID, True
        outputData(writeRow, ALLOC_DATA_COL_ID) = allocationID
        outputData(writeRow, ALLOC_DATA_COL_CANDIDATE_KEY) = candidateKey
        outputData(writeRow, ALLOC_DATA_COL_TRANSACTION_ID) = transactionID
        outputData(writeRow, ALLOC_DATA_COL_DIRECTION) = directionText
        outputData(writeRow, ALLOC_DATA_COL_AMOUNT) = _
            CDbl(normalized(inputRow, ALLOC_INPUT_COL_AMOUNT))
        outputData(writeRow, ALLOC_DATA_COL_STATUS) = _
            CStr(normalized(inputRow, ALLOC_INPUT_COL_STATUS))
        outputData(writeRow, ALLOC_DATA_COL_EVIDENCE) = _
            CStr(normalized(inputRow, ALLOC_INPUT_COL_EVIDENCE))
        outputData(writeRow, ALLOC_DATA_COL_SOURCE_TYPE) = _
            CStr(normalized(inputRow, ALLOC_INPUT_COL_SOURCE_TYPE))
        outputData(writeRow, ALLOC_DATA_COL_SOURCE_AMOUNT) = _
            CDbl(normalized(inputRow, ALLOC_INPUT_COL_SOURCE_AMOUNT))
        outputData(writeRow, ALLOC_DATA_COL_UPDATED_AT) = CDbl(commitStamp)
NextAllocationInputRow:
    Next inputRow
    For Each item In affectedGroups.Keys
        groupKey = CStr(item)
        AllocationGroupParts groupKey, transactionID, directionText
        sourceAmount = CDbl(sourceAmounts(groupKey))
        residualAmount = sourceAmount - CDbl(confirmedTotals(groupKey))
        If Abs(residualAmount) <= AllocationTolerance(sourceAmount) Then residualAmount = 0#
        writeRow = writeRow + 1
        candidateKey = "UNTRACKED>" & transactionID & ">" & directionText
        allocationID = StableAllocationID(candidateKey, transactionID, directionText, True)
        If idSet.Exists(allocationID) Then _
            Err.Raise vbObjectError + 4947, "CommitAllocationBatch", _
                      "�c��AllocationID���Փ˂��Ă��܂�: " & allocationID
        idSet.Add allocationID, True
        outputData(writeRow, ALLOC_DATA_COL_ID) = allocationID
        outputData(writeRow, ALLOC_DATA_COL_CANDIDATE_KEY) = candidateKey
        outputData(writeRow, ALLOC_DATA_COL_TRANSACTION_ID) = transactionID
        outputData(writeRow, ALLOC_DATA_COL_DIRECTION) = directionText
        outputData(writeRow, ALLOC_DATA_COL_AMOUNT) = residualAmount
        outputData(writeRow, ALLOC_DATA_COL_STATUS) = ALLOCATION_STATUS_UNTRACKED
        outputData(writeRow, ALLOC_DATA_COL_EVIDENCE) = Empty
        outputData(writeRow, ALLOC_DATA_COL_SOURCE_TYPE) = ALLOCATION_SOURCE_RESIDUAL
        outputData(writeRow, ALLOC_DATA_COL_SOURCE_AMOUNT) = sourceAmount
        outputData(writeRow, ALLOC_DATA_COL_UPDATED_AT) = CDbl(commitStamp)
    Next item
    If writeRow <> outputRows Then _
        Err.Raise vbObjectError + 4948, "CommitAllocationBatch", _
                  "�z�������̎��O�����Ɗm�茏������v���܂���B"
    If Not ValidateAllocationLedgerMatrix(outputData, outputRows, ledgerProblems) Then _
        Err.Raise vbObjectError + 4949, "CommitAllocationBatch", _
                  "�z�������̊m��v�悪�s���ł�: " & ledgerProblems

    writeStarted = True
    WriteAllocationLedgerMatrix ws, outputData, outputRows, snapshotLastRow
    ledgerProblems = vbNullString
    If Not ValidateAllocationLedgerSheet(ws, ledgerProblems) Then _
        Err.Raise vbObjectError + 4950, "CommitAllocationBatch", _
                  "�z�������̏����㌟�؂Ɏ��s���܂���: " & ledgerProblems
    MarkOutputsDirty
    SetSheetVeryHiddenSafe ws
    If Not AllocationLedgerIsVeryHidden(ws) Then _
        Err.Raise vbObjectError + 4951, "CommitAllocationBatch", _
                  "�z�������������\���֖߂��܂���B"
    mAllocationBatchActive = False
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    If writeStarted Then
        rollbackVerified = TryRollbackAllocationLedger( _
                               ws, snapshot, snapshotLastRow, rollbackDetail)
        If Not rollbackVerified Then _
            AppendAnalysisReviewRollbackDetail rollbackDetail, _
                "����Recovery�̏��L�����O���̎������transaction�֓`�d���܂����B"
    End If
    mAllocationBatchActive = False
    If Len(rollbackDetail) > 0 Then _
        errorDescription = errorDescription & " / ���[���o�b�N�m�F: " & rollbackDetail
    Err.Raise errorNumber, "CommitAllocationBatch", errorDescription
End Sub

Private Function TryRollbackAllocationLedger( _
        ByVal ws As Worksheet, ByVal snapshot As Variant, _
        ByVal snapshotLastRow As Long, ByRef rollbackDetail As String) As Boolean
    On Error GoTo EH
    RestoreAllocationLedgerSnapshot ws, snapshot, snapshotLastRow
    TryRollbackAllocationLedger = True
    Exit Function
EH:
    rollbackDetail = "�z�������̕����G���[: Err " & _
                     CStr(Err.Number) & " " & Err.Description
    Err.Clear
End Function

Private Function AllocationBatchShape(ByVal rows As Variant, _
                                      ByRef firstRow As Long, ByRef lastRow As Long, _
                                      ByRef firstColumn As Long, ByRef lastColumn As Long) As Boolean
    On Error GoTo EH
    If Not IsArray(rows) Then Exit Function
    firstRow = LBound(rows, 1)
    lastRow = UBound(rows, 1)
    firstColumn = LBound(rows, 2)
    lastColumn = UBound(rows, 2)
    AllocationBatchShape = (lastRow >= firstRow And lastColumn >= firstColumn)
    Exit Function
EH:
    firstRow = 0: lastRow = -1
    firstColumn = 0: lastColumn = -1
    Err.Clear
End Function

Private Function AllocationRequiredText(ByVal valueIn As Variant, _
                                        ByVal labelText As String) As String
    Dim valueText As String
    If IsError(valueIn) Or IsNull(valueIn) Then _
        Err.Raise vbObjectError + 4952, "AllocationRequiredText", _
                  labelText & "��Excel�G���[�܂���Null������܂��B"
    valueText = Trim$(CellText(valueIn))
    If Len(valueText) = 0 Or Len(valueText) > 3000 Then _
        Err.Raise vbObjectError + 4952, "AllocationRequiredText", _
                  labelText & "���󗓂܂��͒������܂��B"
    If InStr(1, valueText, ChrW$(31), vbBinaryCompare) > 0 Or _
       InStr(1, valueText, ChrW$(30), vbBinaryCompare) > 0 Then _
        Err.Raise vbObjectError + 4952, "AllocationRequiredText", _
                  labelText & "�ɓ�����؂蕶��������܂��B"
    AllocationRequiredText = valueText
End Function

Private Function AllocationRequiredAmount(ByVal valueIn As Variant, _
                                          ByVal labelText As String) As Double
    Dim amountValue As Double
    If IsError(valueIn) Or IsNull(valueIn) Or IsEmpty(valueIn) Or _
       Not IsNumeric(valueIn) Then _
        Err.Raise vbObjectError + 4953, "AllocationRequiredAmount", _
                  labelText & "�����l�ł͂���܂���B"
    amountValue = CDbl(valueIn)
    If amountValue < 0# Or amountValue > 1E+15 Or amountValue <> amountValue Then _
        Err.Raise vbObjectError + 4953, "AllocationRequiredAmount", _
                  labelText & "�����e�͈͊O�ł��B"
    AllocationRequiredAmount = amountValue
End Function

Private Function AllocationDirectionIsValid(ByVal directionText As String) As Boolean
    AllocationDirectionIsValid = _
        (StrComp(directionText, ALLOCATION_DIRECTION_WITHDRAW, vbBinaryCompare) = 0 Or _
         StrComp(directionText, ALLOCATION_DIRECTION_DEPOSIT, vbBinaryCompare) = 0)
End Function

Private Function AllocationInputStatusIsValid(ByVal statusText As String) As Boolean
    Select Case statusText
        Case ALLOCATION_STATUS_CONFIRMED, ALLOCATION_STATUS_REVIEW_REQUIRED, _
             ALLOCATION_STATUS_EXCLUDED, ALLOCATION_STATUS_UNREVIEWED
            AllocationInputStatusIsValid = True
    End Select
End Function

Private Function AllocationTolerance(ByVal sourceAmount As Double) As Double
    Dim toleranceValue As Double
    toleranceValue = Abs(sourceAmount) * 0.0000000000005
    If toleranceValue < 0.00000001 Then toleranceValue = 0.00000001
    AllocationTolerance = toleranceValue
End Function

Private Function AllocationAmountsMatch(ByVal firstAmount As Double, _
                                        ByVal secondAmount As Double) As Boolean
    Dim scaleValue As Double
    scaleValue = Abs(firstAmount)
    If Abs(secondAmount) > scaleValue Then scaleValue = Abs(secondAmount)
    AllocationAmountsMatch = _
        (Abs(firstAmount - secondAmount) <= AllocationTolerance(scaleValue))
End Function

Private Function AllocationGroupKey(ByVal transactionID As String, _
                                    ByVal directionText As String) As String
    AllocationGroupKey = transactionID & ChrW$(31) & directionText
End Function

Private Sub AllocationGroupParts(ByVal groupKey As String, _
                                 ByRef transactionID As String, _
                                 ByRef directionText As String)
    Dim separatorPos As Long
    separatorPos = InStr(1, groupKey, ChrW$(31), vbBinaryCompare)
    If separatorPos < 2 Or separatorPos >= Len(groupKey) Then _
        Err.Raise vbObjectError + 4954, "AllocationGroupParts", _
                  "�z���O���[�v�L�[�𕪉��ł��܂���B"
    transactionID = Left$(groupKey, separatorPos - 1)
    directionText = Mid$(groupKey, separatorPos + 1)
End Sub

Private Function AllocationExistingRowShouldBeRetained( _
        ByRef oldData As Variant, ByVal dataRow As Long, _
        ByVal affectedGroups As Object, ByVal affectedCandidates As Object, _
        ByVal replacementKeys As Object, ByVal replaceAllGroups As Boolean) As Boolean
    Dim sourceType As String, candidateKey As String
    Dim transactionIDs As String, directionText As String, groupKey As String
    Dim candidateGroupKey As String
    sourceType = CellText(oldData(dataRow, ALLOC_DATA_COL_SOURCE_TYPE))
    candidateKey = CellText(oldData(dataRow, ALLOC_DATA_COL_CANDIDATE_KEY))
    transactionIDs = CellText(oldData(dataRow, ALLOC_DATA_COL_TRANSACTION_ID))
    directionText = CellText(oldData(dataRow, ALLOC_DATA_COL_DIRECTION))
    If sourceType = ALLOCATION_SOURCE_RESIDUAL_LOT Then
        If replaceAllGroups Then
            AllocationExistingRowShouldBeRetained = Not _
                ResidualLotAnyGroupAffected(transactionIDs, directionText, affectedGroups)
        ElseIf Not affectedCandidates.Exists(candidateKey) Then
            AllocationExistingRowShouldBeRetained = True
        Else
            '�����c���͑S�\������𓯂�batch�Œu������ꍇ������lot���O���B
            AllocationExistingRowShouldBeRetained = Not _
                ResidualLotAllGroupsAffected(transactionIDs, directionText, affectedGroups)
        End If
        Exit Function
    End If
    groupKey = AllocationGroupKey(transactionIDs, directionText)
    If sourceType = ALLOCATION_SOURCE_RESIDUAL Then
        AllocationExistingRowShouldBeRetained = Not affectedGroups.Exists(groupKey)
    ElseIf replaceAllGroups Then
        AllocationExistingRowShouldBeRetained = Not affectedGroups.Exists(groupKey)
    Else
        candidateGroupKey = groupKey & ChrW$(30) & candidateKey
        AllocationExistingRowShouldBeRetained = _
            Not replacementKeys.Exists(candidateGroupKey)
    End If
End Function

Private Function ResidualLotAnyGroupAffected( _
        ByVal canonicalTransactionIDs As String, ByVal directionText As String, _
        ByVal affectedGroups As Object) As Boolean
    Dim parts As Variant, item As Variant
    parts = Split(CanonicalResidualLotTransactionIDs(canonicalTransactionIDs), ";")
    For Each item In parts
        If affectedGroups.Exists(AllocationGroupKey(CStr(item), directionText)) Then
            ResidualLotAnyGroupAffected = True
            Exit Function
        End If
    Next item
End Function

Private Function ResidualLotAllGroupsAffected( _
        ByVal canonicalTransactionIDs As String, ByVal directionText As String, _
        ByVal affectedGroups As Object) As Boolean
    Dim parts As Variant, item As Variant
    parts = Split(CanonicalResidualLotTransactionIDs(canonicalTransactionIDs), ";")
    For Each item In parts
        If Not affectedGroups.Exists(AllocationGroupKey(CStr(item), directionText)) Then _
            Exit Function
    Next item
    ResidualLotAllGroupsAffected = True
End Function

Private Function StableAllocationID(ByVal candidateKey As String, _
                                    ByVal transactionID As String, _
                                    ByVal directionText As String, _
                                    ByVal isResidual As Boolean) As String
    Dim rawText As String, idPrefix As String
    rawText = CStr(Len(transactionID)) & ":" & transactionID & "|" & _
              CStr(Len(directionText)) & ":" & directionText & "|" & _
              CStr(Len(candidateKey)) & ":" & candidateKey
    If isResidual Then idPrefix = "AR-" Else idPrefix = "AL-"
    StableAllocationID = idPrefix & _
        AllocationHashPart(rawText, 104729#, 257#) & "-" & _
        AllocationHashPart(rawText, 130363#, 263#)
End Function

Private Function StableResidualLotID(ByVal candidateKey As String, _
                                     ByVal canonicalTransactionIDs As String, _
                                     ByVal directionText As String) As String
    Dim rawText As String
    rawText = CStr(Len(candidateKey)) & ":" & candidateKey & "|" & _
              CStr(Len(canonicalTransactionIDs)) & ":" & canonicalTransactionIDs & "|" & _
              CStr(Len(directionText)) & ":" & directionText
    StableResidualLotID = "RL-" & _
        AllocationHashPart(rawText, 15485863#, 269#) & "-" & _
        AllocationHashPart(rawText, 32452843#, 271#)
End Function

Private Function CanonicalResidualLotTransactionIDs(ByVal rawIDs As String) As String
    Dim parts As Variant, ids() As String, seen As Object
    Dim i As Long, j As Long, itemCount As Long
    Dim transactionID As String, swapText As String
    rawIDs = Trim$(rawIDs)
    parts = Split(rawIDs, ";")
    If UBound(parts) - LBound(parts) + 1 < 2 Then _
        Err.Raise vbObjectError + 4992, "CanonicalResidualLotTransactionIDs", _
                  "ResidualLot�ɂ�2���ȏ�̍\�����ID���K�v�ł��B"
    ReDim ids(0 To UBound(parts) - LBound(parts))
    Set seen = CreateObject("Scripting.Dictionary")
    seen.CompareMode = vbBinaryCompare
    For i = LBound(parts) To UBound(parts)
        transactionID = AllocationRequiredText(CStr(parts(i)), "ResidualLot�\�����ID")
        If InStr(1, transactionID, ";", vbBinaryCompare) > 0 Then _
            Err.Raise vbObjectError + 4992, "CanonicalResidualLotTransactionIDs", _
                      "ResidualLot�\�����ID�ɋ�؂蕶��������܂��B"
        If seen.Exists(transactionID) Then _
            Err.Raise vbObjectError + 4992, "CanonicalResidualLotTransactionIDs", _
                      "ResidualLot�\�����ID���d�����Ă��܂�: " & transactionID
        seen.Add transactionID, True
        ids(itemCount) = transactionID
        itemCount = itemCount + 1
    Next i
    For i = 0 To itemCount - 2
        For j = i + 1 To itemCount - 1
            If StrComp(ids(i), ids(j), vbBinaryCompare) > 0 Then
                swapText = ids(i)
                ids(i) = ids(j)
                ids(j) = swapText
            End If
        Next j
    Next i
    CanonicalResidualLotTransactionIDs = Join(ids, ";")
End Function

Private Function AllocationHashPart(ByVal rawText As String, _
                                    ByVal seedValue As Double, _
                                    ByVal multiplier As Double) As String
    Const HASH_MODULUS As Double = 2147483629#
    Dim hashValue As Double, i As Long, codeValue As Long
    Dim hexText As String
    hashValue = seedValue
    For i = 1 To Len(rawText)
        codeValue = AscW(Mid$(rawText, i, 1))
        If codeValue < 0 Then codeValue = codeValue + 65536
        hashValue = hashValue * multiplier + CDbl(codeValue) + CDbl(i)
        hashValue = hashValue - Fix(hashValue / HASH_MODULUS) * HASH_MODULUS
    Next i
    hexText = Hex$(CLng(hashValue))
    AllocationHashPart = Right$("00000000" & hexText, 8)
End Function

Private Sub CaptureAllocationLedgerSnapshot(ByVal ws As Worksheet, _
                                            ByRef snapshot As Variant, _
                                            ByRef snapshotLastRow As Long)
    Dim rowCount As Long, target As Range
    snapshot = Empty
    snapshotLastRow = AllocationLedgerLastRow(ws)
    If snapshotLastRow < 2 Then
        snapshotLastRow = 1
        Exit Sub
    End If
    rowCount = snapshotLastRow - 1
    If rowCount > MAX_INTERNAL_STORE_DATA_ROWS Then _
        Err.Raise vbObjectError + 4955, "CaptureAllocationLedgerSnapshot", _
                  "�z���������ޔ�����𒴂��Ă��܂��B"
    Set target = ws.Range(ws.Cells(2, ALLOC_LEDGER_FIRST_COL), _
                          ws.Cells(snapshotLastRow, ALLOC_LEDGER_LAST_COL))
    RequireAnalysisReviewConstantRange target, "�z������"
    snapshot = target.Value2
    If Not RangeValue2MatchesMatrixStrict(target, snapshot, rowCount, _
                                          ALLOC_LEDGER_COLUMN_COUNT) Then _
        Err.Raise vbObjectError + 4956, "CaptureAllocationLedgerSnapshot", _
                  "�z�������̑ޔ�ǖ߂�����v���܂���B"
End Sub

Private Sub RestoreAllocationLedgerSnapshot(ByVal ws As Worksheet, _
                                            ByVal snapshot As Variant, _
                                            ByVal snapshotLastRow As Long)
    Dim currentLastRow As Long, clearLastRow As Long, rowCount As Long
    Dim target As Range, problems As String
    currentLastRow = AllocationLedgerLastRow(ws)
    clearLastRow = CLng(Application.Max(currentLastRow, snapshotLastRow))
    If clearLastRow >= 2 Then _
        ws.Range(ws.Cells(2, ALLOC_LEDGER_FIRST_COL), _
                 ws.Cells(clearLastRow, ALLOC_LEDGER_LAST_COL)).ClearContents
    If snapshotLastRow >= 2 Then
        rowCount = snapshotLastRow - 1
        Set target = ws.Range(ws.Cells(2, ALLOC_LEDGER_FIRST_COL), _
                              ws.Cells(snapshotLastRow, ALLOC_LEDGER_LAST_COL))
        target.Value2 = snapshot
        If Not RangeValue2MatchesMatrixStrict(target, snapshot, rowCount, _
                                              ALLOC_LEDGER_COLUMN_COUNT) Then _
            Err.Raise vbObjectError + 4957, "RestoreAllocationLedgerSnapshot", _
                      "�z�������̕����ǖ߂�����v���܂���B"
    End If
    If AllocationLedgerLastRow(ws) <> snapshotLastRow Then _
        Err.Raise vbObjectError + 4958, "RestoreAllocationLedgerSnapshot", _
                  "�z�������̕����s������v���܂���B"
    '�l�����߂��Ă��������{���\�����ꂽ�܂܂Ȃ畜�������Ƃ͂��Ȃ��B
    SetSheetVeryHiddenSafe ws
    If Not AllocationLedgerIsVeryHidden(ws) Then _
        Err.Raise vbObjectError + 5003, "RestoreAllocationLedgerSnapshot", _
                  "�z�������������\���֕����ł��܂���B"
    If Not ValidateAllocationLedgerSheet(ws, problems) Then _
        Err.Raise vbObjectError + 4959, "RestoreAllocationLedgerSnapshot", _
                  "�z�������̕����㌟�؂Ɏ��s���܂���: " & problems
End Sub

Private Sub WriteAllocationLedgerMatrix(ByVal ws As Worksheet, _
                                        ByRef outputData As Variant, _
                                        ByVal outputRows As Long, _
                                        ByVal previousLastRow As Long)
    Dim clearLastRow As Long, target As Range
    clearLastRow = CLng(Application.Max(previousLastRow, outputRows + 1))
    If clearLastRow >= 2 Then _
        ws.Range(ws.Cells(2, ALLOC_LEDGER_FIRST_COL), _
                 ws.Cells(clearLastRow, ALLOC_LEDGER_LAST_COL)).ClearContents
    Set target = ws.Range(ws.Cells(2, ALLOC_LEDGER_FIRST_COL), _
                          ws.Cells(outputRows + 1, ALLOC_LEDGER_LAST_COL))
    target.Value2 = outputData
    If Not RangeValue2MatchesMatrixStrict(target, outputData, outputRows, _
                                          ALLOC_LEDGER_COLUMN_COUNT) Then _
        Err.Raise vbObjectError + 4960, "WriteAllocationLedgerMatrix", _
                  "�z�������̈ꊇ�����ǖ߂�����v���܂���B"
    RequireAnalysisReviewConstantRange target, "�z�������̊m����e"
    If AllocationLedgerLastRow(ws) <> outputRows + 1 Then _
        Err.Raise vbObjectError + 4961, "WriteAllocationLedgerMatrix", _
                  "�z�������̊m��s������v���܂���B"
End Sub

Private Function AllocationLedgerLastRow(ByVal ws As Worksheet) As Long
    If ws Is Nothing Then _
        Err.Raise vbObjectError + 4962, "AllocationLedgerLastRow", _
                  "�z�������̃V�[�g���擾�ł��܂���B"
    AllocationLedgerLastRow = LastDataRowInColumns( _
                                  ws, ALLOC_LEDGER_FIRST_COL, ALLOC_LEDGER_LAST_COL)
End Function

Private Function AllocationLedgerIsVeryHidden(ByVal ws As Worksheet) As Boolean
    On Error GoTo EH
    If ws Is Nothing Then Exit Function
    AllocationLedgerIsVeryHidden = (ws.Visible = xlSheetVeryHidden)
    Exit Function
EH:
    AllocationLedgerIsVeryHidden = False
    Err.Clear
End Function

Public Function ValidateAllocationLedgerForSave(ByRef problems As String) As Boolean
    Dim ledgerProblems As String
    On Error GoTo EH
    If Not SheetExists(SH_WORK_ANALYSIS_REVIEW) Then
        ledgerProblems = "�z�������̕ۑ��悪����܂���B"
    ElseIf Not ValidateAllocationLedgerSheet( _
                   GetSheet(SH_WORK_ANALYSIS_REVIEW), ledgerProblems) Then
        '���؊֐������R��ݒ肷��B
    End If
    If Len(ledgerProblems) > 0 Then
        problems = problems & "�E�z������: " & ledgerProblems & vbCrLf
        Exit Function
    End If
    ValidateAllocationLedgerForSave = True
    Exit Function
EH:
    problems = problems & "�E�z�����������؂ł��܂���: Err " & _
               CStr(Err.Number) & " " & Err.Description & vbCrLf
    Err.Clear
End Function

Public Sub CaptureAllocationLedgerTransactionSnapshot( _
        ByRef snapshot As Variant, ByRef snapshotLastRow As Long, _
        ByRef snapshotDigest As String)
    Dim ws As Worksheet, problems As String
    If mAllocationBatchActive Then _
        Err.Raise vbObjectError + 4993, "CaptureAllocationLedgerTransactionSnapshot", _
                  "�z�������̍X�V���͊O��snapshot���擾�ł��܂���B"
    Set ws = GetSheet(SH_WORK_ANALYSIS_REVIEW)
    If Not ValidateAllocationLedgerSheet(ws, problems) Then _
        Err.Raise vbObjectError + 4993, "CaptureAllocationLedgerTransactionSnapshot", _
                  "�z��������ޔ��ł��܂���: " & problems
    CaptureAllocationLedgerSnapshot ws, snapshot, snapshotLastRow
    snapshotDigest = AllocationSnapshotDigest(snapshot, snapshotLastRow)
    If Len(snapshotDigest) <> 17 Then _
        Err.Raise vbObjectError + 4993, "CaptureAllocationLedgerTransactionSnapshot", _
                  "�z������snapshot�̏������쐬�ł��܂���B"
End Sub

Public Sub RestoreAllocationLedgerTransactionSnapshot( _
        ByVal snapshot As Variant, ByVal snapshotLastRow As Long, _
        ByVal expectedDigest As String)
    Dim ws As Worksheet, currentSnapshot As Variant, currentLastRow As Long
    Dim currentDigest As String, problems As String
    If mAllocationBatchActive Then _
        Err.Raise vbObjectError + 4994, "RestoreAllocationLedgerTransactionSnapshot", _
                  "�z�������̍X�V���͊O��snapshot�𕜌��ł��܂���B"
    If StrComp(AllocationSnapshotDigest(snapshot, snapshotLastRow), _
               expectedDigest, vbBinaryCompare) <> 0 Then _
        Err.Raise vbObjectError + 4994, "RestoreAllocationLedgerTransactionSnapshot", _
                  "�z������snapshot�̏�������v���܂���B"
    Set ws = GetSheet(SH_WORK_ANALYSIS_REVIEW)
    RestoreAllocationLedgerSnapshot ws, snapshot, snapshotLastRow
    CaptureAllocationLedgerSnapshot ws, currentSnapshot, currentLastRow
    currentDigest = AllocationSnapshotDigest(currentSnapshot, currentLastRow)
    If currentLastRow <> snapshotLastRow Or _
       StrComp(currentDigest, expectedDigest, vbBinaryCompare) <> 0 Then _
        Err.Raise vbObjectError + 4995, "RestoreAllocationLedgerTransactionSnapshot", _
                  "�z�������̕����㏐�����ޔ����ƈ�v���܂���B"
    If Not ValidateAllocationLedgerSheet(ws, problems) Then _
        Err.Raise vbObjectError + 4995, "RestoreAllocationLedgerTransactionSnapshot", _
                  "�z�������̕����㌟�؂Ɏ��s���܂���: " & problems
End Sub

Public Function AllocationLedgerStoredRowCount() As Long
    Dim ws As Worksheet, problems As String, lastR As Long
    Set ws = GetSheet(SH_WORK_ANALYSIS_REVIEW)
    If Not ValidateAllocationLedgerSheet(ws, problems) Then _
        Err.Raise vbObjectError + 4996, "AllocationLedgerStoredRowCount", problems
    lastR = AllocationLedgerLastRow(ws)
    If lastR >= 2 Then AllocationLedgerStoredRowCount = lastR - 1
End Function

Private Function AllocationSnapshotDigest(ByVal snapshot As Variant, _
                                          ByVal snapshotLastRow As Long) As String
    Const HASH_MODULUS_ONE As Double = 2147483629#
    Const HASH_MODULUS_TWO As Double = 2147483587#
    Dim firstHash As Double, secondHash As Double, sequenceNo As Double
    Dim rowCount As Long, r As Long, c As Long, i As Long
    Dim pieceText As String, codeValue As Long
    If snapshotLastRow < 1 Then _
        Err.Raise vbObjectError + 4997, "AllocationSnapshotDigest", _
                  "�z������snapshot�̍ŏI�s���s���ł��B"
    rowCount = snapshotLastRow - 1
    If rowCount > 0 Then
        If Not IsArray(snapshot) Then _
            Err.Raise vbObjectError + 4997, "AllocationSnapshotDigest", _
                      "�z������snapshot�z�񂪂���܂���B"
        If LBound(snapshot, 1) <> 1 Or UBound(snapshot, 1) <> rowCount Or _
           LBound(snapshot, 2) <> 1 Or _
           UBound(snapshot, 2) <> ALLOC_LEDGER_COLUMN_COUNT Then _
            Err.Raise vbObjectError + 4997, "AllocationSnapshotDigest", _
                      "�z������snapshot�z��̌`���s���ł��B"
    End If
    firstHash = 104729#: secondHash = 130363#
    For r = 0 To rowCount
        If r = 0 Then
            pieceText = "ROWS:" & CStr(rowCount) & "|COLS:" & _
                        CStr(ALLOC_LEDGER_COLUMN_COUNT)
            AllocationDigestFeed pieceText, firstHash, secondHash, sequenceNo, _
                                 HASH_MODULUS_ONE, HASH_MODULUS_TWO
        Else
            For c = 1 To ALLOC_LEDGER_COLUMN_COUNT
                pieceText = AllocationSnapshotValue(snapshot(r, c))
                AllocationDigestFeed pieceText, firstHash, secondHash, sequenceNo, _
                                     HASH_MODULUS_ONE, HASH_MODULUS_TWO
            Next c
        End If
    Next r
    AllocationSnapshotDigest = Right$("00000000" & Hex$(CLng(firstHash)), 8) & "-" & _
                               Right$("00000000" & Hex$(CLng(secondHash)), 8)
End Function

Private Sub AllocationDigestFeed(ByVal pieceText As String, _
                                 ByRef firstHash As Double, ByRef secondHash As Double, _
                                 ByRef sequenceNo As Double, ByVal firstModulus As Double, _
                                 ByVal secondModulus As Double)
    Dim i As Long, codeValue As Long
    pieceText = CStr(Len(pieceText)) & ":" & pieceText & "|"
    For i = 1 To Len(pieceText)
        sequenceNo = sequenceNo + 1#
        codeValue = AscW(Mid$(pieceText, i, 1))
        If codeValue < 0 Then codeValue = codeValue + 65536
        firstHash = firstHash * 257# + CDbl(codeValue) + sequenceNo
        firstHash = firstHash - Fix(firstHash / firstModulus) * firstModulus
        secondHash = secondHash * 263# + CDbl(codeValue) + sequenceNo * 3#
        secondHash = secondHash - Fix(secondHash / secondModulus) * secondModulus
    Next i
End Sub

Private Function AllocationSnapshotValue(ByVal valueIn As Variant) As String
    If IsError(valueIn) Then
        AllocationSnapshotValue = "ERR:" & CStr(CLng(valueIn))
    ElseIf IsNull(valueIn) Then
        AllocationSnapshotValue = "NULL"
    ElseIf IsEmpty(valueIn) Then
        AllocationSnapshotValue = "EMPTY"
    ElseIf VarType(valueIn) = vbString Then
        AllocationSnapshotValue = "S:" & CStr(valueIn)
    ElseIf VarType(valueIn) = vbBoolean Then
        AllocationSnapshotValue = "B:" & IIf(CBool(valueIn), "1", "0")
    ElseIf IsNumeric(valueIn) Then
        AllocationSnapshotValue = "N:" & Trim$(Str$(CDbl(valueIn)))
    Else
        AllocationSnapshotValue = "V" & CStr(VarType(valueIn)) & ":" & CStr(valueIn)
    End If
End Function

Private Function ValidateAllocationLedgerSheet(ByVal ws As Worksheet, _
                                                ByRef problems As String) As Boolean
    Dim headers As Variant, c As Long, lastR As Long, rowCount As Long
    Dim target As Range, data As Variant
    problems = vbNullString
    On Error GoTo EH
    If ws Is Nothing Then
        problems = "�ۑ���V�[�g���擾�ł��܂���B"
        Exit Function
    End If
    If Not AllocationLedgerIsVeryHidden(ws) Then
        problems = "�z�������̕ۑ��悪������\���ł͂���܂���B"
        Exit Function
    End If
    headers = AllocationLedgerHeaders()
    For c = 1 To ALLOC_LEDGER_COLUMN_COUNT
        If StrComp(CellText(ws.Cells(1, ALLOC_LEDGER_FIRST_COL + c - 1).Value2), _
                   CStr(headers(c - 1)), vbBinaryCompare) <> 0 Then
            problems = "���o������v���܂���: " & _
                       ws.Cells(1, ALLOC_LEDGER_FIRST_COL + c - 1).Address(False, False)
            Exit Function
        End If
    Next c
    If LastDataRowInColumns(ws, ALLOC_LEDGER_FIRST_COL - 1, _
                            ALLOC_LEDGER_FIRST_COL - 1) > 1 Or _
       Len(CellText(ws.Cells(1, ALLOC_LEDGER_FIRST_COL - 1).Value2)) > 0 Then
        problems = "�������f�䒠�Ƃ̋��E��N���󗓂ł͂���܂���B"
        Exit Function
    End If
    lastR = AllocationLedgerLastRow(ws)
    If lastR - 1 > MAX_INTERNAL_STORE_DATA_ROWS Then
        problems = "�ۑ�����𒴂��Ă��܂��B"
        Exit Function
    End If
    If lastR < 2 Then
        ValidateAllocationLedgerSheet = True
        Exit Function
    End If
    rowCount = lastR - 1
    Set target = ws.Range(ws.Cells(2, ALLOC_LEDGER_FIRST_COL), _
                          ws.Cells(lastR, ALLOC_LEDGER_LAST_COL))
    RequireAnalysisReviewConstantRange target, "�z������"
    data = target.Value2
    If Not RangeValue2MatchesMatrixStrict(target, data, rowCount, _
                                          ALLOC_LEDGER_COLUMN_COUNT) Then
        problems = "�S��E�^�̓ǖ߂�����v���܂���B"
        Exit Function
    End If
    ValidateAllocationLedgerSheet = _
        ValidateAllocationLedgerMatrix(data, rowCount, problems)
    Exit Function
EH:
    problems = "���؃G���[: Err " & CStr(Err.Number) & " " & Err.Description
    Err.Clear
End Function

Private Function ValidateAllocationLedgerMatrix(ByRef data As Variant, _
                                                ByVal rowCount As Long, _
                                                ByRef problems As String) As Boolean
    Dim idSet As Object, groupSources As Object, confirmedTotals As Object
    Dim proposedTotals As Object, residualCounts As Object, residualAmounts As Object
    Dim candidateSet As Object, residualLotRows As Object
    Dim candidateEvidence As Object, candidateSourceTypes As Object
    Dim candidateWithdrawTotals As Object, candidateDepositTotals As Object
    Dim r As Long, componentRow As Long
    Dim item As Variant, componentItem As Variant, componentIDs As Variant
    Dim allocationID As String, candidateKey As String, transactionID As String
    Dim directionText As String, statusText As String, evidenceText As String
    Dim sourceType As String, groupKey As String, candidateGroupKey As String
    Dim amountValue As Double, sourceAmount As Double, expectedID As String
    Dim lotSourceTotal As Double, lotResidualAvailable As Double
    Dim isResidual As Boolean, isResidualLot As Boolean
    problems = vbNullString
    On Error GoTo EH
    If rowCount < 0 Or rowCount > MAX_INTERNAL_STORE_DATA_ROWS Then
        problems = "�s�������e�͈͊O�ł��B"
        Exit Function
    End If
    If rowCount = 0 Then
        ValidateAllocationLedgerMatrix = True
        Exit Function
    End If
    If Not IsArray(data) Then
        problems = "�z���f�[�^�z�񂪂���܂���B"
        Exit Function
    End If
    If LBound(data, 1) <> 1 Or UBound(data, 1) <> rowCount Or _
       LBound(data, 2) <> 1 Or UBound(data, 2) <> ALLOC_LEDGER_COLUMN_COUNT Then
        problems = "�z���f�[�^�z��̌`����v���܂���B"
        Exit Function
    End If
    Set idSet = CreateObject("Scripting.Dictionary")
    idSet.CompareMode = vbBinaryCompare
    Set groupSources = CreateObject("Scripting.Dictionary")
    groupSources.CompareMode = vbBinaryCompare
    Set confirmedTotals = CreateObject("Scripting.Dictionary")
    confirmedTotals.CompareMode = vbBinaryCompare
    Set proposedTotals = CreateObject("Scripting.Dictionary")
    proposedTotals.CompareMode = vbBinaryCompare
    Set residualCounts = CreateObject("Scripting.Dictionary")
    residualCounts.CompareMode = vbBinaryCompare
    Set residualAmounts = CreateObject("Scripting.Dictionary")
    residualAmounts.CompareMode = vbBinaryCompare
    Set candidateSet = CreateObject("Scripting.Dictionary")
    candidateSet.CompareMode = vbBinaryCompare
    Set residualLotRows = CreateObject("Scripting.Dictionary")
    residualLotRows.CompareMode = vbBinaryCompare
    Set candidateEvidence = CreateObject("Scripting.Dictionary")
    candidateEvidence.CompareMode = vbBinaryCompare
    Set candidateSourceTypes = CreateObject("Scripting.Dictionary")
    candidateSourceTypes.CompareMode = vbBinaryCompare
    Set candidateWithdrawTotals = CreateObject("Scripting.Dictionary")
    candidateWithdrawTotals.CompareMode = vbBinaryCompare
    Set candidateDepositTotals = CreateObject("Scripting.Dictionary")
    candidateDepositTotals.CompareMode = vbBinaryCompare

    For r = 1 To rowCount
        allocationID = AllocationRequiredText(data(r, ALLOC_DATA_COL_ID), "AllocationID")
        candidateKey = AllocationRequiredText(data(r, ALLOC_DATA_COL_CANDIDATE_KEY), "CandidateKey")
        transactionID = AllocationRequiredText(data(r, ALLOC_DATA_COL_TRANSACTION_ID), "TransactionID")
        directionText = UCase$(AllocationRequiredText( _
                            data(r, ALLOC_DATA_COL_DIRECTION), "Direction"))
        If Not AllocationDirectionIsValid(directionText) Then _
            Err.Raise vbObjectError + 4963, "ValidateAllocationLedgerMatrix", _
                      CStr(r + 1) & "�s�ڂ�Direction���s���ł��B"
        amountValue = AllocationRequiredAmount(data(r, ALLOC_DATA_COL_AMOUNT), _
                                               "AllocatedAmount")
        statusText = UCase$(AllocationRequiredText( _
                         data(r, ALLOC_DATA_COL_STATUS), "DecisionStatus"))
        evidenceText = Trim$(CellText(data(r, ALLOC_DATA_COL_EVIDENCE)))
        sourceType = AllocationRequiredText(data(r, ALLOC_DATA_COL_SOURCE_TYPE), _
                                            "SourceType")
        If StrComp(sourceType, ALLOCATION_SOURCE_SCOPE, vbBinaryCompare) = 0 Then _
            Err.Raise vbObjectError + 4966, "ValidateAllocationLedgerMatrix", _
                      "SCOPE����s���z�������֕ۑ�����Ă��܂��B"
        sourceAmount = AllocationRequiredAmount( _
                           data(r, ALLOC_DATA_COL_SOURCE_AMOUNT), "SourceAmount")
        If Not IsDate(data(r, ALLOC_DATA_COL_UPDATED_AT)) Then _
            Err.Raise vbObjectError + 4964, "ValidateAllocationLedgerMatrix", _
                      CStr(r + 1) & "�s�ڂ�UpdatedAt���s���ł��B"
        If idSet.Exists(allocationID) Then _
            Err.Raise vbObjectError + 4965, "ValidateAllocationLedgerMatrix", _
                      "AllocationID���d�����Ă��܂�: " & allocationID
        idSet.Add allocationID, True
        isResidualLot = (StrComp(sourceType, ALLOCATION_SOURCE_RESIDUAL_LOT, _
                                 vbBinaryCompare) = 0)
        If isResidualLot Then
            If statusText <> ALLOCATION_STATUS_REVIEW_REQUIRED Or _
               Not ReviewEvidenceDigestIsValid(evidenceText) Or _
               transactionID <> CanonicalResidualLotTransactionIDs(transactionID) Or _
               allocationID <> StableResidualLotID(candidateKey, transactionID, directionText) Then _
                Err.Raise vbObjectError + 4966, "ValidateAllocationLedgerMatrix", _
                          "ResidualLot�̎��ʏ�񂪕s���ł�: " & allocationID
            If amountValue > sourceAmount + AllocationTolerance(sourceAmount) Then _
                Err.Raise vbObjectError + 4967, "ValidateAllocationLedgerMatrix", _
                          "ResidualLot�z�������c�����z�𒴂��Ă��܂�: " & allocationID
            If candidateEvidence.Exists(candidateKey) Then
                If StrComp(CStr(candidateEvidence(candidateKey)), evidenceText, _
                           vbBinaryCompare) <> 0 Then _
                    Err.Raise vbObjectError + 4966, "ValidateAllocationLedgerMatrix", _
                              "��������EvidenceDigest����v���܂���: " & candidateKey
            Else
                candidateEvidence.Add candidateKey, evidenceText
                candidateWithdrawTotals.Add candidateKey, 0#
                candidateDepositTotals.Add candidateKey, 0#
            End If
            residualLotRows.Add CStr(r), transactionID
            GoTo NextAllocationLedgerRow
        End If
        groupKey = AllocationGroupKey(transactionID, directionText)
        If Not groupSources.Exists(groupKey) Then
            groupSources.Add groupKey, sourceAmount
            confirmedTotals.Add groupKey, 0#
            proposedTotals.Add groupKey, 0#
            residualCounts.Add groupKey, 0&
            residualAmounts.Add groupKey, 0#
        ElseIf Not AllocationAmountsMatch(CDbl(groupSources(groupKey)), sourceAmount) Then
            Err.Raise vbObjectError + 4966, "ValidateAllocationLedgerMatrix", _
                      "��������E������SourceAmount����v���܂���: " & transactionID
        End If
        If amountValue > sourceAmount + AllocationTolerance(sourceAmount) Then _
            Err.Raise vbObjectError + 4967, "ValidateAllocationLedgerMatrix", _
                      "�z���z�������z�𒴂��Ă��܂�: " & allocationID

        isResidual = (StrComp(sourceType, ALLOCATION_SOURCE_RESIDUAL, _
                              vbBinaryCompare) = 0)
        If isResidual Then
            expectedID = StableAllocationID(candidateKey, transactionID, directionText, True)
            If statusText <> ALLOCATION_STATUS_UNTRACKED Or Len(evidenceText) > 0 Or _
               StrComp(candidateKey, "UNTRACKED>" & transactionID & ">" & directionText, _
                       vbBinaryCompare) <> 0 Or allocationID <> expectedID Then _
                Err.Raise vbObjectError + 4968, "ValidateAllocationLedgerMatrix", _
                          "�c���s�̎��ʏ�񂪕s���ł�: " & allocationID
            residualCounts(groupKey) = CLng(residualCounts(groupKey)) + 1
            residualAmounts(groupKey) = amountValue
        Else
            If Not AllocationInputStatusIsValid(statusText) Then _
                Err.Raise vbObjectError + 4969, "ValidateAllocationLedgerMatrix", _
                          "�z���s��DecisionStatus���s���ł�: " & allocationID
            If Not ReviewEvidenceDigestIsValid(evidenceText) Then _
                Err.Raise vbObjectError + 4970, "ValidateAllocationLedgerMatrix", _
                          "�z���s��EvidenceDigest���s���ł�: " & allocationID
            If candidateEvidence.Exists(candidateKey) Then
                If StrComp(CStr(candidateEvidence(candidateKey)), evidenceText, _
                           vbBinaryCompare) <> 0 Then _
                    Err.Raise vbObjectError + 4970, "ValidateAllocationLedgerMatrix", _
                              "��������EvidenceDigest����v���܂���: " & candidateKey
            Else
                candidateEvidence.Add candidateKey, evidenceText
                candidateWithdrawTotals.Add candidateKey, 0#
                candidateDepositTotals.Add candidateKey, 0#
            End If
            If candidateSourceTypes.Exists(candidateKey) Then
                If StrComp(CStr(candidateSourceTypes(candidateKey)), sourceType, _
                           vbBinaryCompare) <> 0 Then _
                    Err.Raise vbObjectError + 4970, "ValidateAllocationLedgerMatrix", _
                              "��������SourceType����v���܂���: " & candidateKey
            Else
                candidateSourceTypes.Add candidateKey, sourceType
            End If
            expectedID = StableAllocationID(candidateKey, transactionID, directionText, False)
            If allocationID <> expectedID Then _
                Err.Raise vbObjectError + 4971, "ValidateAllocationLedgerMatrix", _
                          "AllocationID������L�[�ƈ�v���܂���: " & allocationID
            candidateGroupKey = groupKey & ChrW$(30) & candidateKey
            If candidateSet.Exists(candidateGroupKey) Then _
                Err.Raise vbObjectError + 4972, "ValidateAllocationLedgerMatrix", _
                          "��������E�����E���̔z�����d�����Ă��܂�: " & candidateKey
            candidateSet.Add candidateGroupKey, r
            If (statusText = ALLOCATION_STATUS_EXCLUDED Or _
                statusText = ALLOCATION_STATUS_UNREVIEWED) And amountValue <> 0# Then _
                Err.Raise vbObjectError + 4973, "ValidateAllocationLedgerMatrix", _
                          "EXCLUDED�܂���UNREVIEWED�̔z���z��0�ł͂���܂���B"
            proposedTotals(groupKey) = CDbl(proposedTotals(groupKey)) + amountValue
            If statusText = ALLOCATION_STATUS_CONFIRMED Then
                confirmedTotals(groupKey) = CDbl(confirmedTotals(groupKey)) + amountValue
                If directionText = ALLOCATION_DIRECTION_WITHDRAW Then
                    candidateWithdrawTotals(candidateKey) = _
                        CDbl(candidateWithdrawTotals(candidateKey)) + amountValue
                Else
                    candidateDepositTotals(candidateKey) = _
                        CDbl(candidateDepositTotals(candidateKey)) + amountValue
                End If
            End If
        End If
NextAllocationLedgerRow:
    Next r
    For Each item In groupSources.Keys
        groupKey = CStr(item)
        sourceAmount = CDbl(groupSources(groupKey))
        If CLng(residualCounts(groupKey)) <> 1 Then _
            Err.Raise vbObjectError + 4974, "ValidateAllocationLedgerMatrix", _
                      "����E�������Ƃ̎c���s��1�s�ł͂���܂���: " & groupKey
        If CDbl(proposedTotals(groupKey)) > _
           sourceAmount + AllocationTolerance(sourceAmount) Then _
            Err.Raise vbObjectError + 4975, "ValidateAllocationLedgerMatrix", _
                      "��Ē����܂ޔz�����v�������z�𒴂��Ă��܂�: " & groupKey
        If Not AllocationAmountsMatch( _
                   CDbl(confirmedTotals(groupKey)) + CDbl(residualAmounts(groupKey)), _
                   sourceAmount) Then _
            Err.Raise vbObjectError + 4976, "ValidateAllocationLedgerMatrix", _
                      "�m��z�����v+���ǐՎc�z�������z�ƈ�v���܂���: " & groupKey
    Next item
    '�����active�z���͕K���o���������Œނ荇���B�Б��������m�肵��
    '�B��1:n/n:1/n:n�������ƁA�s���c�z����Б������������邽�ߋ��ۂ���B
    For Each item In candidateEvidence.Keys
        candidateKey = CStr(item)
        If Not AllocationAmountsMatch( _
                   CDbl(candidateWithdrawTotals(candidateKey)), _
                   CDbl(candidateDepositTotals(candidateKey))) Then _
            Err.Raise vbObjectError + 4976, "ValidateAllocationLedgerMatrix", _
                      "���̊m��o���z���Ɗm������z������v���܂���: " & candidateKey
    Next item
    For Each item In residualLotRows.Keys
        r = CLng(item)
        componentIDs = Split(CStr(residualLotRows(CStr(item))), ";")
        directionText = CellText(data(r, ALLOC_DATA_COL_DIRECTION))
        lotSourceTotal = 0#: lotResidualAvailable = 0#
        For Each componentItem In componentIDs
            groupKey = AllocationGroupKey(CStr(componentItem), directionText)
            If Not groupSources.Exists(groupKey) Then _
                Err.Raise vbObjectError + 4976, "ValidateAllocationLedgerMatrix", _
                          "ResidualLot�\������̌ʎc���s������܂���: " & CStr(componentItem)
            candidateGroupKey = groupKey & ChrW$(30) & _
                                CellText(data(r, ALLOC_DATA_COL_CANDIDATE_KEY))
            If Not candidateSet.Exists(candidateGroupKey) Then _
                Err.Raise vbObjectError + 4976, "ValidateAllocationLedgerMatrix", _
                          "ResidualLot�\������̌���0�~�s������܂���: " & CStr(componentItem)
            componentRow = CLng(candidateSet(candidateGroupKey))
            If CDbl(data(componentRow, ALLOC_DATA_COL_AMOUNT)) <> 0# Or _
               CellText(data(componentRow, ALLOC_DATA_COL_STATUS)) <> _
                   ALLOCATION_STATUS_REVIEW_REQUIRED Then _
                Err.Raise vbObjectError + 4976, "ValidateAllocationLedgerMatrix", _
                          "ResidualLot�\�������0�~�EREVIEW_REQUIRED�ł͂���܂���: " & _
                          CStr(componentItem)
            lotSourceTotal = lotSourceTotal + CDbl(groupSources(groupKey))
            lotResidualAvailable = lotResidualAvailable + _
                CDbl(groupSources(groupKey)) - CDbl(confirmedTotals(groupKey))
        Next componentItem
        If Not AllocationAmountsMatch( _
                   CDbl(data(r, ALLOC_DATA_COL_SOURCE_AMOUNT)), lotSourceTotal) Then _
            Err.Raise vbObjectError + 4976, "ValidateAllocationLedgerMatrix", _
                      "ResidualLot��SourceAmount���\��������z���v�ƈ�v���܂���B"
        If Not AllocationAmountsMatch( _
                   CDbl(data(r, ALLOC_DATA_COL_AMOUNT)), lotSourceTotal) Then _
            Err.Raise vbObjectError + 4976, "ValidateAllocationLedgerMatrix", _
                      "ResidualLot�z���\��������z���v�̖��z�ł͂���܂���B"
        If CDbl(data(r, ALLOC_DATA_COL_AMOUNT)) > _
           lotResidualAvailable + AllocationTolerance(lotSourceTotal) Then _
            Err.Raise vbObjectError + 4976, "ValidateAllocationLedgerMatrix", _
                      "ResidualLot�z���\������̖��ǐՎc�z���v�𒴂��Ă��܂��B"
    Next item
    ValidateAllocationLedgerMatrix = True
    Exit Function
EH:
    problems = "Err " & CStr(Err.Number) & " " & Err.Description
    Err.Clear
End Function

Public Function MarkAllocationEvidenceChanged(ByVal candidateKey As String, _
                                              ByVal transactionID As String, _
                                              ByVal newEvidenceDigest As String) As Boolean
    Dim ws As Worksheet, problems As String
    Dim snapshot As Variant, snapshotLastRow As Long, rowCount As Long
    Dim data As Variant, r As Long, sourceType As String, groupKey As String
    Dim affectedGroups As Object, stamp As Date
    Dim matched As Boolean, evidenceChanged As Boolean
    Dim changed As Boolean, writeStarted As Boolean
    Dim rollbackVerified As Boolean
    Dim errorNumber As Long, errorDescription As String, rollbackDetail As String
    candidateKey = AllocationRequiredText(candidateKey, "CandidateKey")
    transactionID = AllocationRequiredText(transactionID, "TransactionID")
    newEvidenceDigest = Trim$(newEvidenceDigest)
    If Not ReviewEvidenceDigestIsValid(newEvidenceDigest) Then _
        Err.Raise vbObjectError + 4977, "MarkAllocationEvidenceChanged", _
                  "�V����EvidenceDigest���s���ł��B"
    If mAllocationBatchActive Then _
        Err.Raise vbObjectError + 4978, "MarkAllocationEvidenceChanged", _
                  "�z�������̍X�V���������Ɏ��s���ł��B"
    On Error GoTo EH
    mAllocationBatchActive = True
    Set ws = GetSheet(SH_WORK_ANALYSIS_REVIEW)
    If Not ValidateAllocationLedgerSheet(ws, problems) Then _
        Err.Raise vbObjectError + 4979, "MarkAllocationEvidenceChanged", problems
    CaptureAllocationLedgerSnapshot ws, snapshot, snapshotLastRow
    rowCount = snapshotLastRow - 1
    If rowCount < 1 Then GoTo CleanExit
    data = snapshot
    Set affectedGroups = CreateObject("Scripting.Dictionary")
    affectedGroups.CompareMode = vbBinaryCompare
    'requested transaction�����ɑ����邱�ƂƁA���P�ʂ̍����ύX���Ɋm�F����B
    '�������̈ꕔ��������������ƁAn:1 / 1:n / n:n�̎c�����s�����ɂȂ�B
    For r = 1 To rowCount
        sourceType = CellText(data(r, ALLOC_DATA_COL_SOURCE_TYPE))
        If StrComp(sourceType, ALLOCATION_SOURCE_RESIDUAL, vbBinaryCompare) <> 0 And _
           StrComp(CellText(data(r, ALLOC_DATA_COL_CANDIDATE_KEY)), _
                   candidateKey, vbBinaryCompare) = 0 Then
            If AllocationEvidenceTransactionMatches( _
                   CellText(data(r, ALLOC_DATA_COL_TRANSACTION_ID)), _
                   transactionID, sourceType) Then matched = True
            If StrComp(CellText(data(r, ALLOC_DATA_COL_EVIDENCE)), _
                       newEvidenceDigest, vbBinaryCompare) <> 0 Then _
                evidenceChanged = True
        End If
    Next r
    If Not matched Or Not evidenceChanged Then GoTo CleanExit

    stamp = Now
    For r = 1 To rowCount
        sourceType = CellText(data(r, ALLOC_DATA_COL_SOURCE_TYPE))
        If StrComp(sourceType, ALLOCATION_SOURCE_RESIDUAL, vbBinaryCompare) <> 0 And _
           StrComp(CellText(data(r, ALLOC_DATA_COL_CANDIDATE_KEY)), _
                   candidateKey, vbBinaryCompare) = 0 Then
            data(r, ALLOC_DATA_COL_EVIDENCE) = newEvidenceDigest
            data(r, ALLOC_DATA_COL_STATUS) = ALLOCATION_STATUS_REVIEW_REQUIRED
            data(r, ALLOC_DATA_COL_UPDATED_AT) = CDbl(stamp)
            If sourceType <> ALLOCATION_SOURCE_RESIDUAL_LOT Then
                '�������ς�������z���ė\��Ƃ��Ďc�����Aactive�z��0�֖߂��B
                data(r, ALLOC_DATA_COL_AMOUNT) = 0#
                groupKey = AllocationGroupKey( _
                    CellText(data(r, ALLOC_DATA_COL_TRANSACTION_ID)), _
                    CellText(data(r, ALLOC_DATA_COL_DIRECTION)))
                If Not affectedGroups.Exists(groupKey) Then _
                    affectedGroups.Add groupKey, True
            End If
            changed = True
        End If
    Next r
    If Not changed Then GoTo CleanExit
    RecomputeAllocationResiduals data, rowCount, affectedGroups, stamp
    problems = vbNullString
    If Not ValidateAllocationLedgerMatrix(data, rowCount, problems) Then _
        Err.Raise vbObjectError + 4980, "MarkAllocationEvidenceChanged", _
                  "�؋��ύX��̔z���v�悪�s���ł�: " & problems
    writeStarted = True
    WriteAllocationLedgerMatrix ws, data, rowCount, snapshotLastRow
    problems = vbNullString
    If Not ValidateAllocationLedgerSheet(ws, problems) Then _
        Err.Raise vbObjectError + 4981, "MarkAllocationEvidenceChanged", _
                  "�؋��ύX��̔z���������s���ł�: " & problems
    MarkOutputsDirty
    SetSheetVeryHiddenSafe ws
    If Not AllocationLedgerIsVeryHidden(ws) Then _
        Err.Raise vbObjectError + 4982, "MarkAllocationEvidenceChanged", _
                  "�z�������������\���֖߂��܂���B"
    MarkAllocationEvidenceChanged = True
CleanExit:
    mAllocationBatchActive = False
    Exit Function
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    If writeStarted Then
        rollbackVerified = TryRollbackAllocationLedger( _
                               ws, snapshot, snapshotLastRow, rollbackDetail)
        If Not rollbackVerified Then _
            AppendAnalysisReviewRollbackDetail rollbackDetail, _
                "����Recovery�̏��L�����O���̎������transaction�֓`�d���܂����B"
    End If
    mAllocationBatchActive = False
    If Len(rollbackDetail) > 0 Then _
        errorDescription = errorDescription & " / ���[���o�b�N�m�F: " & rollbackDetail
    Err.Raise errorNumber, "MarkAllocationEvidenceChanged", errorDescription
End Function

Private Function AllocationEvidenceTransactionMatches( _
        ByVal storedTransactionIDs As String, ByVal requestedTransactionID As String, _
        ByVal sourceType As String) As Boolean
    Dim parts As Variant, item As Variant
    If sourceType <> ALLOCATION_SOURCE_RESIDUAL_LOT Then
        AllocationEvidenceTransactionMatches = _
            (StrComp(storedTransactionIDs, requestedTransactionID, vbBinaryCompare) = 0)
        Exit Function
    End If
    parts = Split(storedTransactionIDs, ";")
    For Each item In parts
        If StrComp(CStr(item), requestedTransactionID, vbBinaryCompare) = 0 Then
            AllocationEvidenceTransactionMatches = True
            Exit Function
        End If
    Next item
End Function

Private Sub RecomputeAllocationResiduals(ByRef data As Variant, ByVal rowCount As Long, _
                                         ByVal affectedGroups As Object, ByVal stamp As Date)
    Dim confirmedTotals As Object, sourceAmounts As Object, residualRows As Object
    Dim r As Long, groupKey As String, statusText As String, sourceType As String
    Dim item As Variant, sourceAmount As Double, residualAmount As Double
    Set confirmedTotals = CreateObject("Scripting.Dictionary")
    confirmedTotals.CompareMode = vbBinaryCompare
    Set sourceAmounts = CreateObject("Scripting.Dictionary")
    sourceAmounts.CompareMode = vbBinaryCompare
    Set residualRows = CreateObject("Scripting.Dictionary")
    residualRows.CompareMode = vbBinaryCompare
    For r = 1 To rowCount
        groupKey = AllocationGroupKey( _
            CellText(data(r, ALLOC_DATA_COL_TRANSACTION_ID)), _
            CellText(data(r, ALLOC_DATA_COL_DIRECTION)))
        If affectedGroups.Exists(groupKey) Then
            sourceAmount = CDbl(data(r, ALLOC_DATA_COL_SOURCE_AMOUNT))
            If Not sourceAmounts.Exists(groupKey) Then
                sourceAmounts.Add groupKey, sourceAmount
                confirmedTotals.Add groupKey, 0#
            End If
            sourceType = CellText(data(r, ALLOC_DATA_COL_SOURCE_TYPE))
            statusText = CellText(data(r, ALLOC_DATA_COL_STATUS))
            If sourceType = ALLOCATION_SOURCE_RESIDUAL Then
                If residualRows.Exists(groupKey) Then _
                    Err.Raise vbObjectError + 4983, "RecomputeAllocationResiduals", _
                              "�c���s���d�����Ă��܂�: " & groupKey
                residualRows.Add groupKey, r
            ElseIf statusText = ALLOCATION_STATUS_CONFIRMED Then
                confirmedTotals(groupKey) = CDbl(confirmedTotals(groupKey)) + _
                                            CDbl(data(r, ALLOC_DATA_COL_AMOUNT))
            End If
        End If
    Next r
    For Each item In affectedGroups.Keys
        groupKey = CStr(item)
        If Not sourceAmounts.Exists(groupKey) Or Not residualRows.Exists(groupKey) Then _
            Err.Raise vbObjectError + 4984, "RecomputeAllocationResiduals", _
                      "�c���Čv�Z�ɕK�v�ȍs������܂���: " & groupKey
        sourceAmount = CDbl(sourceAmounts(groupKey))
        residualAmount = sourceAmount - CDbl(confirmedTotals(groupKey))
        If residualAmount < -AllocationTolerance(sourceAmount) Then _
            Err.Raise vbObjectError + 4985, "RecomputeAllocationResiduals", _
                      "�؋��ύX��̊m��z���������z�𒴂��Ă��܂�: " & groupKey
        If Abs(residualAmount) <= AllocationTolerance(sourceAmount) Then residualAmount = 0#
        r = CLng(residualRows(groupKey))
        data(r, ALLOC_DATA_COL_AMOUNT) = residualAmount
        data(r, ALLOC_DATA_COL_UPDATED_AT) = CDbl(stamp)
    Next item
End Sub

Public Function CaptureAllocationLedgerIndex() As Object
    Dim result As Object, ws As Worksheet, problems As String
    Dim lastR As Long, rowCount As Long, data As Variant, r As Long
    Dim groupKey As String, sourceType As String, statusText As String
    Dim summary As Variant
    Set result = CreateObject("Scripting.Dictionary")
    result.CompareMode = vbBinaryCompare
    Set ws = GetSheet(SH_WORK_ANALYSIS_REVIEW)
    If Not ValidateAllocationLedgerSheet(ws, problems) Then _
        Err.Raise vbObjectError + 4986, "CaptureAllocationLedgerIndex", problems
    lastR = AllocationLedgerLastRow(ws)
    If lastR < 2 Then
        Set CaptureAllocationLedgerIndex = result
        Exit Function
    End If
    rowCount = lastR - 1
    data = ws.Range(ws.Cells(2, ALLOC_LEDGER_FIRST_COL), _
                    ws.Cells(lastR, ALLOC_LEDGER_LAST_COL)).Value2
    For r = 1 To rowCount
        sourceType = CellText(data(r, ALLOC_DATA_COL_SOURCE_TYPE))
        If sourceType = ALLOCATION_SOURCE_RESIDUAL_LOT Then GoTo NextAllocationIndexRow
        groupKey = AllocationGroupKey( _
            CellText(data(r, ALLOC_DATA_COL_TRANSACTION_ID)), _
            CellText(data(r, ALLOC_DATA_COL_DIRECTION)))
        If Not result.Exists(groupKey) Then _
            result.Add groupKey, Array(0#, 0#, _
                CDbl(data(r, ALLOC_DATA_COL_SOURCE_AMOUNT)), 0&)
        summary = result(groupKey)
        statusText = CellText(data(r, ALLOC_DATA_COL_STATUS))
        If sourceType = ALLOCATION_SOURCE_RESIDUAL Then
            summary(1) = CDbl(data(r, ALLOC_DATA_COL_AMOUNT))
        ElseIf statusText = ALLOCATION_STATUS_CONFIRMED Then
            summary(0) = CDbl(summary(0)) + CDbl(data(r, ALLOC_DATA_COL_AMOUNT))
            If CDbl(data(r, ALLOC_DATA_COL_AMOUNT)) > _
               AllocationTolerance(CDbl(data(r, ALLOC_DATA_COL_SOURCE_AMOUNT))) Then _
                summary(3) = CLng(summary(3)) + 1
        End If
        result(groupKey) = summary
NextAllocationIndexRow:
    Next r
    Set CaptureAllocationLedgerIndex = result
End Function

Public Function GetTransactionUnresolvedAmount( _
        ByVal transactionID As String, ByVal directionText As String, _
        ByVal sourceAmount As Double, ByRef allocatedAmount As Double, _
        ByRef unresolvedAmount As Double, ByRef allocationCount As Long) As Boolean
    Dim allocationIndex As Object
    Set allocationIndex = CaptureAllocationLedgerIndex()
    GetTransactionUnresolvedAmount = GetTransactionUnresolvedAmountFromIndex( _
        allocationIndex, transactionID, directionText, sourceAmount, _
        allocatedAmount, unresolvedAmount, allocationCount)
End Function

Public Function GetTransactionUnresolvedAmountFromIndex( _
        ByVal allocationIndex As Object, ByVal transactionID As String, _
        ByVal directionText As String, ByVal sourceAmount As Double, _
        ByRef allocatedAmount As Double, ByRef unresolvedAmount As Double, _
        ByRef allocationCount As Long) As Boolean
    Dim groupKey As String, summary As Variant
    allocatedAmount = 0#
    unresolvedAmount = 0#
    allocationCount = 0
    transactionID = AllocationRequiredText(transactionID, "TransactionID")
    directionText = UCase$(AllocationRequiredText(directionText, "Direction"))
    If Not AllocationDirectionIsValid(directionText) Then _
        Err.Raise vbObjectError + 4987, "GetTransactionUnresolvedAmountFromIndex", _
                  "Direction���s���ł��B"
    sourceAmount = AllocationRequiredAmount(sourceAmount, "SourceAmount")
    If allocationIndex Is Nothing Then _
        Err.Raise vbObjectError + 4988, "GetTransactionUnresolvedAmountFromIndex", _
                  "�z����������������܂���B"
    groupKey = AllocationGroupKey(transactionID, directionText)
    If Not allocationIndex.Exists(groupKey) Then
        unresolvedAmount = sourceAmount
        GetTransactionUnresolvedAmountFromIndex = True
        Exit Function
    End If
    summary = allocationIndex(groupKey)
    If Not AllocationAmountsMatch(CDbl(summary(2)), sourceAmount) Then _
        Err.Raise vbObjectError + 4989, "GetTransactionUnresolvedAmountFromIndex", _
                  "�z��������SourceAmount�����ݎ���z�ƈ�v���܂���: " & transactionID
    allocatedAmount = CDbl(summary(0))
    unresolvedAmount = CDbl(summary(1))
    allocationCount = CLng(summary(3))
    If Not AllocationAmountsMatch(allocatedAmount + unresolvedAmount, sourceAmount) Then _
        Err.Raise vbObjectError + 4990, "GetTransactionUnresolvedAmountFromIndex", _
                  "�m��z�����v+���ǐՎc�z�������z�ƈ�v���܂���: " & transactionID
    GetTransactionUnresolvedAmountFromIndex = True
End Function

Public Function CaptureAllocationsForCandidate(ByVal candidateKey As String) As Collection
    Dim result As New Collection
    Dim ws As Worksheet, problems As String, lastR As Long, data As Variant, r As Long
    candidateKey = AllocationRequiredText(candidateKey, "CandidateKey")
    Set ws = GetSheet(SH_WORK_ANALYSIS_REVIEW)
    If Not ValidateAllocationLedgerSheet(ws, problems) Then _
        Err.Raise vbObjectError + 4991, "CaptureAllocationsForCandidate", problems
    lastR = AllocationLedgerLastRow(ws)
    If lastR >= 2 Then
        data = ws.Range(ws.Cells(2, ALLOC_LEDGER_FIRST_COL), _
                        ws.Cells(lastR, ALLOC_LEDGER_LAST_COL)).Value2
        For r = 1 To lastR - 1
            If StrComp(CellText(data(r, ALLOC_DATA_COL_CANDIDATE_KEY)), _
                       candidateKey, vbBinaryCompare) = 0 And _
               StrComp(CellText(data(r, ALLOC_DATA_COL_SOURCE_TYPE)), _
                       ALLOCATION_SOURCE_RESIDUAL, vbBinaryCompare) <> 0 Then _
                result.Add Array( _
                    data(r, ALLOC_DATA_COL_ID), data(r, ALLOC_DATA_COL_CANDIDATE_KEY), _
                    data(r, ALLOC_DATA_COL_TRANSACTION_ID), data(r, ALLOC_DATA_COL_DIRECTION), _
                    data(r, ALLOC_DATA_COL_AMOUNT), data(r, ALLOC_DATA_COL_STATUS), _
                    data(r, ALLOC_DATA_COL_EVIDENCE), data(r, ALLOC_DATA_COL_SOURCE_TYPE), _
                    data(r, ALLOC_DATA_COL_SOURCE_AMOUNT), data(r, ALLOC_DATA_COL_UPDATED_AT))
        Next r
    End If
    Set CaptureAllocationsForCandidate = result
End Function

Public Function AllocationLedgerContractRegressionTest() As Boolean
    'Excel���f�[�^���g�킸�A�z���s�Ϗ����E���ߋ��ہE���m�F0�~�E����ID�����؂���B
    Dim data As Variant, sequential As Variant, crossRows As Variant, lotData As Variant
    Dim problems As String, stamp As Date
    Dim digestText As String, transactionID As String, directionText As String
    Dim depositTransactionID As String, depositDirection As String
    Dim candidateOne As String, candidateTwo As String, residualKey As String
    Dim depositResidualKey As String
    Dim secondTransactionID As String, secondGroupKey As String
    Dim rowValues As Variant, c As Long
    Dim affectedGroups As Object, affectedCandidates As Object, replacementKeys As Object
    Dim groupKey As String
    On Error GoTo EH
    ReDim data(1 To 5, 1 To ALLOC_LEDGER_COLUMN_COUNT)
    ReDim sequential(1 To 6, 1 To ALLOC_LEDGER_COLUMN_COUNT)
    ReDim crossRows(1 To 2, 1 To ALLOC_LEDGER_COLUMN_COUNT)
    ReDim lotData(1 To 5, 1 To ALLOC_LEDGER_COLUMN_COUNT)
    stamp = #1/2/2020 3:04:05 AM#
    digestText = "01234567-89ABCDEF"
    transactionID = "T000001"
    directionText = ALLOCATION_DIRECTION_WITHDRAW
    depositTransactionID = "T000001D"
    depositDirection = ALLOCATION_DIRECTION_DEPOSIT
    candidateOne = "SHIFT>C1"
    candidateTwo = "FLOW>C2"
    residualKey = "UNTRACKED>" & transactionID & ">" & directionText
    depositResidualKey = "UNTRACKED>" & depositTransactionID & ">" & depositDirection

    data(1, ALLOC_DATA_COL_ID) = StableAllocationID( _
        candidateOne, transactionID, directionText, False)
    data(1, ALLOC_DATA_COL_CANDIDATE_KEY) = candidateOne
    data(1, ALLOC_DATA_COL_TRANSACTION_ID) = transactionID
    data(1, ALLOC_DATA_COL_DIRECTION) = directionText
    data(1, ALLOC_DATA_COL_AMOUNT) = 40#
    data(1, ALLOC_DATA_COL_STATUS) = ALLOCATION_STATUS_CONFIRMED
    data(1, ALLOC_DATA_COL_EVIDENCE) = digestText
    data(1, ALLOC_DATA_COL_SOURCE_TYPE) = "AUTO_SHIFT"
    data(1, ALLOC_DATA_COL_SOURCE_AMOUNT) = 100#
    data(1, ALLOC_DATA_COL_UPDATED_AT) = CDbl(stamp)

    data(2, ALLOC_DATA_COL_ID) = StableAllocationID( _
        candidateTwo, transactionID, directionText, False)
    data(2, ALLOC_DATA_COL_CANDIDATE_KEY) = candidateTwo
    data(2, ALLOC_DATA_COL_TRANSACTION_ID) = transactionID
    data(2, ALLOC_DATA_COL_DIRECTION) = directionText
    data(2, ALLOC_DATA_COL_AMOUNT) = 10#
    data(2, ALLOC_DATA_COL_STATUS) = ALLOCATION_STATUS_REVIEW_REQUIRED
    data(2, ALLOC_DATA_COL_EVIDENCE) = digestText
    data(2, ALLOC_DATA_COL_SOURCE_TYPE) = "AUTO_FLOW"
    data(2, ALLOC_DATA_COL_SOURCE_AMOUNT) = 100#
    data(2, ALLOC_DATA_COL_UPDATED_AT) = CDbl(stamp)

    data(3, ALLOC_DATA_COL_ID) = StableAllocationID( _
        residualKey, transactionID, directionText, True)
    data(3, ALLOC_DATA_COL_CANDIDATE_KEY) = residualKey
    data(3, ALLOC_DATA_COL_TRANSACTION_ID) = transactionID
    data(3, ALLOC_DATA_COL_DIRECTION) = directionText
    data(3, ALLOC_DATA_COL_AMOUNT) = 60#
    data(3, ALLOC_DATA_COL_STATUS) = ALLOCATION_STATUS_UNTRACKED
    data(3, ALLOC_DATA_COL_EVIDENCE) = Empty
    data(3, ALLOC_DATA_COL_SOURCE_TYPE) = ALLOCATION_SOURCE_RESIDUAL
    data(3, ALLOC_DATA_COL_SOURCE_AMOUNT) = 100#
    data(3, ALLOC_DATA_COL_UPDATED_AT) = CDbl(stamp)
    rowValues = AllocationFixtureRow(candidateOne, depositTransactionID, depositDirection, _
        40#, ALLOCATION_STATUS_CONFIRMED, digestText, "AUTO_SHIFT", 100#, stamp, False, False)
    For c = 1 To ALLOC_LEDGER_COLUMN_COUNT: data(4, c) = rowValues(c - 1): Next c
    rowValues = AllocationFixtureRow(depositResidualKey, depositTransactionID, depositDirection, _
        60#, ALLOCATION_STATUS_UNTRACKED, "", ALLOCATION_SOURCE_RESIDUAL, _
        100#, stamp, True, False)
    For c = 1 To ALLOC_LEDGER_COLUMN_COUNT: data(5, c) = rowValues(c - 1): Next c
    If Not ValidateAllocationLedgerMatrix(data, 5, problems) Then Exit Function
    If StableAllocationID(candidateOne, transactionID, directionText, False) <> _
       CStr(data(1, ALLOC_DATA_COL_ID)) Then Exit Function

    data(1, ALLOC_DATA_COL_AMOUNT) = 101#
    data(3, ALLOC_DATA_COL_AMOUNT) = 0#
    problems = vbNullString
    If ValidateAllocationLedgerMatrix(data, 5, problems) Then Exit Function
    data(1, ALLOC_DATA_COL_AMOUNT) = 40#
    data(3, ALLOC_DATA_COL_AMOUNT) = 60#

    data(2, ALLOC_DATA_COL_STATUS) = ALLOCATION_STATUS_EXCLUDED
    data(2, ALLOC_DATA_COL_AMOUNT) = 1#
    problems = vbNullString
    If ValidateAllocationLedgerMatrix(data, 5, problems) Then Exit Function
    data(2, ALLOC_DATA_COL_AMOUNT) = 0#
    problems = vbNullString
    If Not ValidateAllocationLedgerMatrix(data, 5, problems) Then Exit Function
    data(2, ALLOC_DATA_COL_SOURCE_TYPE) = ALLOCATION_SOURCE_SCOPE
    problems = vbNullString
    If ValidateAllocationLedgerMatrix(data, 5, problems) Then Exit Function
    data(2, ALLOC_DATA_COL_SOURCE_TYPE) = "AUTO_FLOW"

    '�e����̎c�����������Ă��A���̊m��o���Ɗm��������s��v�Ȃ狑�ۂ���B
    data(4, ALLOC_DATA_COL_AMOUNT) = 39#
    data(5, ALLOC_DATA_COL_AMOUNT) = 61#
    problems = vbNullString
    If ValidateAllocationLedgerMatrix(data, 5, problems) Then Exit Function
    data(4, ALLOC_DATA_COL_AMOUNT) = 40#
    data(5, ALLOC_DATA_COL_AMOUNT) = 60#

    'AN-07: C1=60�m��ς݂̓�������C2=30�𒀎��ǉ����Ă�C1��ێ����A
    '�c��10�ƂȂ�B������C2������u���ΏۂƂ��A�����ʌ��C1�͕ێ�����B
    Set affectedGroups = CreateObject("Scripting.Dictionary")
    affectedGroups.CompareMode = vbBinaryCompare
    groupKey = AllocationGroupKey(transactionID, directionText)
    affectedGroups.Add groupKey, True
    Set affectedCandidates = CreateObject("Scripting.Dictionary")
    affectedCandidates.CompareMode = vbBinaryCompare
    affectedCandidates.Add candidateTwo, True
    Set replacementKeys = CreateObject("Scripting.Dictionary")
    replacementKeys.CompareMode = vbBinaryCompare
    replacementKeys.Add groupKey & ChrW$(30) & candidateTwo, True
    rowValues = AllocationFixtureRow(candidateOne, transactionID, directionText, _
        60#, ALLOCATION_STATUS_CONFIRMED, digestText, "AUTO_SHIFT", 100#, stamp, False, False)
    For c = 1 To ALLOC_LEDGER_COLUMN_COUNT
        sequential(1, c) = rowValues(c - 1)
    Next c
    rowValues = AllocationFixtureRow(residualKey, transactionID, directionText, _
        40#, ALLOCATION_STATUS_UNTRACKED, "", ALLOCATION_SOURCE_RESIDUAL, _
        100#, stamp, True, False)
    For c = 1 To ALLOC_LEDGER_COLUMN_COUNT
        sequential(2, c) = rowValues(c - 1)
    Next c
    If Not AllocationExistingRowShouldBeRetained( _
               sequential, 1, affectedGroups, affectedCandidates, replacementKeys, _
               False) Then Exit Function
    If AllocationExistingRowShouldBeRetained( _
           sequential, 2, affectedGroups, affectedCandidates, replacementKeys, _
           False) Then Exit Function
    rowValues = AllocationFixtureRow(candidateTwo, transactionID, directionText, _
        30#, ALLOCATION_STATUS_CONFIRMED, digestText, "AUTO_FLOW", 100#, stamp, False, False)
    For c = 1 To ALLOC_LEDGER_COLUMN_COUNT
        sequential(2, c) = rowValues(c - 1)
    Next c
    rowValues = AllocationFixtureRow(residualKey, transactionID, directionText, _
        10#, ALLOCATION_STATUS_UNTRACKED, "", ALLOCATION_SOURCE_RESIDUAL, _
        100#, stamp, True, False)
    For c = 1 To ALLOC_LEDGER_COLUMN_COUNT
        sequential(3, c) = rowValues(c - 1)
    Next c
    rowValues = AllocationFixtureRow(candidateOne, depositTransactionID, depositDirection, _
        60#, ALLOCATION_STATUS_CONFIRMED, digestText, "AUTO_SHIFT", 100#, stamp, False, False)
    For c = 1 To ALLOC_LEDGER_COLUMN_COUNT: sequential(4, c) = rowValues(c - 1): Next c
    rowValues = AllocationFixtureRow(candidateTwo, depositTransactionID, depositDirection, _
        30#, ALLOCATION_STATUS_CONFIRMED, digestText, "AUTO_FLOW", 100#, stamp, False, False)
    For c = 1 To ALLOC_LEDGER_COLUMN_COUNT: sequential(5, c) = rowValues(c - 1): Next c
    rowValues = AllocationFixtureRow(depositResidualKey, depositTransactionID, depositDirection, _
        10#, ALLOCATION_STATUS_UNTRACKED, "", ALLOCATION_SOURCE_RESIDUAL, _
        100#, stamp, True, False)
    For c = 1 To ALLOC_LEDGER_COLUMN_COUNT: sequential(6, c) = rowValues(c - 1): Next c
    problems = vbNullString
    If Not ValidateAllocationLedgerMatrix(sequential, 6, problems) Then Exit Function

    '����batch: C1/W2��C2/W1��u�����Ă��A����o��C1/W1�𒼐ςŏ����Ȃ��B
    secondTransactionID = "T000002"
    rowValues = AllocationFixtureRow(candidateOne, transactionID, directionText, _
        60#, ALLOCATION_STATUS_CONFIRMED, digestText, "AUTO_SHIFT", 100#, stamp, False, False)
    For c = 1 To ALLOC_LEDGER_COLUMN_COUNT: crossRows(1, c) = rowValues(c - 1): Next c
    rowValues = AllocationFixtureRow(candidateOne, secondTransactionID, directionText, _
        20#, ALLOCATION_STATUS_CONFIRMED, digestText, "AUTO_SHIFT", 100#, stamp, False, False)
    For c = 1 To ALLOC_LEDGER_COLUMN_COUNT: crossRows(2, c) = rowValues(c - 1): Next c
    affectedGroups.RemoveAll
    affectedCandidates.RemoveAll
    replacementKeys.RemoveAll
    groupKey = AllocationGroupKey(transactionID, directionText)
    secondGroupKey = AllocationGroupKey(secondTransactionID, directionText)
    affectedGroups.Add groupKey, True
    affectedGroups.Add secondGroupKey, True
    affectedCandidates.Add candidateOne, True
    affectedCandidates.Add candidateTwo, True
    replacementKeys.Add secondGroupKey & ChrW$(30) & candidateOne, True
    replacementKeys.Add groupKey & ChrW$(30) & candidateTwo, True
    If Not AllocationExistingRowShouldBeRetained( _
               crossRows, 1, affectedGroups, affectedCandidates, replacementKeys, _
               False) Then Exit Function
    If AllocationExistingRowShouldBeRetained( _
           crossRows, 2, affectedGroups, affectedCandidates, replacementKeys, _
           False) Then Exit Function

    '�S�ĕ��͒u���ł͑Ώێ���̋��������L�[�Ɋ֌W�Ȃ��O���B
    '�������ł��ΏۊO����ɂ���s�͕ێ����Agroup���E���z���ď����Ȃ��B
    affectedGroups.RemoveAll
    affectedGroups.Add groupKey, True
    If AllocationExistingRowShouldBeRetained( _
           crossRows, 1, affectedGroups, affectedCandidates, replacementKeys, _
           True) Then Exit Function
    If Not AllocationExistingRowShouldBeRetained( _
               crossRows, 2, affectedGroups, affectedCandidates, replacementKeys, _
               True) Then Exit Function

    '�B��n:n�͌�active�z��0�A�e����̖��z�c���A����ResidualLot������
    'REVIEW_REQUIRED�ŕێ�����BLot�͎c�z������Ȃ��B
    rowValues = AllocationFixtureRow("AMB>C1", "T000010", directionText, _
        0#, ALLOCATION_STATUS_REVIEW_REQUIRED, digestText, "AMBIGUOUS", 60#, stamp, False, False)
    For c = 1 To ALLOC_LEDGER_COLUMN_COUNT: lotData(1, c) = rowValues(c - 1): Next c
    rowValues = AllocationFixtureRow("UNTRACKED>T000010>" & directionText, _
        "T000010", directionText, 60#, ALLOCATION_STATUS_UNTRACKED, "", _
        ALLOCATION_SOURCE_RESIDUAL, 60#, stamp, True, False)
    For c = 1 To ALLOC_LEDGER_COLUMN_COUNT: lotData(2, c) = rowValues(c - 1): Next c
    rowValues = AllocationFixtureRow("AMB>C1", "T000011", directionText, _
        0#, ALLOCATION_STATUS_REVIEW_REQUIRED, digestText, "AMBIGUOUS", 40#, stamp, False, False)
    For c = 1 To ALLOC_LEDGER_COLUMN_COUNT: lotData(3, c) = rowValues(c - 1): Next c
    rowValues = AllocationFixtureRow("UNTRACKED>T000011>" & directionText, _
        "T000011", directionText, 40#, ALLOCATION_STATUS_UNTRACKED, "", _
        ALLOCATION_SOURCE_RESIDUAL, 40#, stamp, True, False)
    For c = 1 To ALLOC_LEDGER_COLUMN_COUNT: lotData(4, c) = rowValues(c - 1): Next c
    rowValues = AllocationFixtureRow("AMB>C1", "T000010;T000011", directionText, _
        100#, ALLOCATION_STATUS_REVIEW_REQUIRED, digestText, _
        ALLOCATION_SOURCE_RESIDUAL_LOT, 100#, stamp, False, True)
    For c = 1 To ALLOC_LEDGER_COLUMN_COUNT: lotData(5, c) = rowValues(c - 1): Next c
    problems = vbNullString
    If Not ValidateAllocationLedgerMatrix(lotData, 5, problems) Then Exit Function
    lotData(5, ALLOC_DATA_COL_AMOUNT) = 99#
    problems = vbNullString
    If ValidateAllocationLedgerMatrix(lotData, 5, problems) Then Exit Function
    lotData(5, ALLOC_DATA_COL_AMOUNT) = 101#
    problems = vbNullString
    If ValidateAllocationLedgerMatrix(lotData, 5, problems) Then Exit Function
    AllocationLedgerContractRegressionTest = True
    Exit Function
EH:
    AllocationLedgerContractRegressionTest = False
    Err.Clear
End Function

Private Function AllocationFixtureRow( _
        ByVal candidateKey As String, ByVal transactionIDs As String, _
        ByVal directionText As String, ByVal amountValue As Double, _
        ByVal statusText As String, ByVal evidenceText As String, _
        ByVal sourceType As String, ByVal sourceAmount As Double, _
        ByVal stamp As Date, ByVal isResidual As Boolean, _
        ByVal isResidualLot As Boolean) As Variant
    Dim rowValues(0 To ALLOC_LEDGER_COLUMN_COUNT - 1) As Variant
    If isResidualLot Then
        rowValues(ALLOC_DATA_COL_ID - 1) = _
            StableResidualLotID(candidateKey, transactionIDs, directionText)
    Else
        rowValues(ALLOC_DATA_COL_ID - 1) = _
            StableAllocationID(candidateKey, transactionIDs, directionText, isResidual)
    End If
    rowValues(ALLOC_DATA_COL_CANDIDATE_KEY - 1) = candidateKey
    rowValues(ALLOC_DATA_COL_TRANSACTION_ID - 1) = transactionIDs
    rowValues(ALLOC_DATA_COL_DIRECTION - 1) = directionText
    rowValues(ALLOC_DATA_COL_AMOUNT - 1) = amountValue
    rowValues(ALLOC_DATA_COL_STATUS - 1) = statusText
    If Len(evidenceText) = 0 Then _
        rowValues(ALLOC_DATA_COL_EVIDENCE - 1) = Empty Else _
        rowValues(ALLOC_DATA_COL_EVIDENCE - 1) = evidenceText
    rowValues(ALLOC_DATA_COL_SOURCE_TYPE - 1) = sourceType
    rowValues(ALLOC_DATA_COL_SOURCE_AMOUNT - 1) = sourceAmount
    rowValues(ALLOC_DATA_COL_UPDATED_AT - 1) = CDbl(stamp)
    AllocationFixtureRow = rowValues
End Function

Private Sub PrepareAnalysisReviewStoreSheet(ByVal ws As Worksheet, ByVal resetContents As Boolean, _
                                            ByVal headers As Variant, ByVal lastColumn As Long)
    If ws Is Nothing Then Err.Raise vbObjectError + 4900, _
        "PrepareAnalysisReviewStoreSheet", "���͔��f�̓����ۑ��悪����܂���B"
    If resetContents Then ResetWorksheet ws
    If Len(CellText(ws.Cells(1, 1).Value)) = 0 Then
        SetRowValues ws.Range("A1"), headers
        FormatOutputHeader ws.Range(ws.Cells(1, 1), ws.Cells(1, lastColumn))
    End If
    ws.Columns("A:M").NumberFormatLocal = "@"
    If StrComp(ws.Name, SH_WORK_ANALYSIS_HISTORY, vbTextCompare) = 0 Then
        ws.Columns("C:C").NumberFormatLocal = "yyyy/m/d h:mm:ss"
    Else
        ws.Columns("H:H").NumberFormatLocal = "yyyy/m/d h:mm:ss"
    End If
    SetSheetVeryHiddenSafe ws
End Sub

Public Function CapturePersistentAnalysisReviews() As Object
    Dim reviews As Object, ws As Worksheet
    Dim lastR As Long, data As Variant, r As Long
    Dim keyText As String, statusText As String, memoText As String
    Set reviews = CreateObject("Scripting.Dictionary")
    reviews.CompareMode = vbTextCompare
    If Not SheetExists(SH_WORK_ANALYSIS_REVIEW) Then
        Set CapturePersistentAnalysisReviews = reviews
        Exit Function
    End If
    Set ws = GetSheet(SH_WORK_ANALYSIS_REVIEW)
    lastR = AnalysisReviewLastRowStrict(ws, "���͔��f�䒠")
    If lastR < 2 Then
        Set CapturePersistentAnalysisReviews = reviews
        Exit Function
    End If
    data = ws.Range(ws.Cells(2, 1), _
                    ws.Cells(lastR, ANALYSIS_REVIEW_STORE_LAST_COL)).Value2
    For r = 1 To UBound(data, 1)
        keyText = CellText(data(r, REVIEW_STORE_COL_KEY))
        statusText = CellText(data(r, REVIEW_STORE_COL_STATUS))
        If Len(statusText) = 0 Then statusText = ANALYSIS_STATUS_UNREVIEWED
        memoText = CellText(data(r, REVIEW_STORE_COL_MEMO))
        If Len(keyText) > 0 And _
           (statusText <> ANALYSIS_STATUS_UNREVIEWED Or Len(memoText) > 0) Then
            If reviews.Exists(keyText) Then _
                Err.Raise vbObjectError + 4901, "CapturePersistentAnalysisReviews", _
                          "���͔��f�䒠�̌��L�[���d�����Ă��܂�: " & keyText
            reviews.Add keyText, Array(statusText, memoText, _
                CellText(data(r, REVIEW_STORE_COL_EVIDENCE)))
        End If
    Next r
    Set CapturePersistentAnalysisReviews = reviews
End Function

Public Function MergeStoredAnalysisReviews(ByVal currentReviews As Object, _
                                           ByVal storedReviews As Object) As Object
    Dim result As Object, item As Variant
    Set result = CreateObject("Scripting.Dictionary")
    result.CompareMode = vbTextCompare
    If Not storedReviews Is Nothing Then
        For Each item In storedReviews.Keys
            result.Add CStr(item), storedReviews(item)
        Next item
    End If
    If Not currentReviews Is Nothing Then
        For Each item In currentReviews.Keys
            If result.Exists(CStr(item)) Then
                result(CStr(item)) = currentReviews(item)
            Else
                result.Add CStr(item), currentReviews(item)
            End If
        Next item
    End If
    Set MergeStoredAnalysisReviews = result
End Function

Public Sub PersistAnalysisReviewsFromCurrentSheets(ByVal markMissing As Boolean, _
                                                    Optional ByVal reasonText As String = "")
    Dim wsStore As Worksheet, indexByKey As Object, presentKeys As Object
    Dim plannedPresentKeys As Object
    Dim wsHistory As Worksheet
    Dim storeSnapshot As Variant, historySnapshot As Variant
    Dim storeSnapshotLastRow As Long, historySnapshotLastRow As Long
    Dim plannedStoreAdds As Long, plannedHistoryAdds As Long
    Dim snapshotsCaptured As Boolean, writeStarted As Boolean
    Dim rollbackVerified As Boolean, storeRestored As Boolean, historyRestored As Boolean
    Dim errorNumber As Long, errorDescription As String, rollbackDetail As String
    If mReviewPersistActive Then _
        Err.Raise vbObjectError + 4906, "PersistAnalysisReviewsFromCurrentSheets", _
                  "���͔��f�䒠�̕ۑ����������Ɏ��s���ł��B"
    If Not SheetExists(SH_WORK_ANALYSIS_REVIEW) Or _
       Not SheetExists(SH_WORK_ANALYSIS_HISTORY) Then _
        Err.Raise vbObjectError + 4902, "PersistAnalysisReviewsFromCurrentSheets", _
                  "���͔��f�䒠������܂���B�ăZ�b�g�A�b�v���Ă��������B"
    On Error GoTo EH
    '�䒠�E������1�s�ł������O�ɁA3�̕��͕\��S�����؂���B
    'Value2�������ɓǂނƁA�������ʂ�Excel�G���[�𐳏�Ȕ��f�Ƃ��ĉi�����������
    '�ĕ��͑���CaptureAnalysisReviews�����ۂ��邽�߁A���؏���������֓��ꂷ��B
    ValidateAnalysisReviewSourcesBeforePersist
    Set wsStore = GetSheet(SH_WORK_ANALYSIS_REVIEW)
    Set wsHistory = GetSheet(SH_WORK_ANALYSIS_HISTORY)
    EnsureAnalysisPersistenceStoreSafe wsStore, ANALYSIS_REVIEW_STORE_LAST_COL, "���͔��f�䒠"
    EnsureAnalysisPersistenceStoreSafe wsHistory, ANALYSIS_HISTORY_STORE_LAST_COL, "���͔��f����"
    CaptureConstantDataStoreSnapshot wsStore, ANALYSIS_REVIEW_STORE_LAST_COL, _
                                     storeSnapshot, storeSnapshotLastRow
    CaptureConstantDataStoreSnapshot wsHistory, ANALYSIS_HISTORY_STORE_LAST_COL, _
                                     historySnapshot, historySnapshotLastRow
    snapshotsCaptured = True
    Set indexByKey = BuildAnalysisReviewStoreIndex(wsStore)
    Set plannedPresentKeys = CreateObject("Scripting.Dictionary")
    plannedPresentKeys.CompareMode = vbTextCompare
    PlanOneAnalysisReviewSheet GetSheet(SH_ANALYSIS_SHIFT), SHIFT_ANALYSIS_STATUS_COL, _
        SHIFT_ANALYSIS_MEMO_COL, SHIFT_ANALYSIS_KEY_COL, SH_ANALYSIS_SHIFT, _
        "�����V�t�g", 33, 34, indexByKey, plannedPresentKeys, _
        plannedStoreAdds, plannedHistoryAdds
    PlanOneAnalysisReviewSheet GetSheet(SH_ANALYSIS_FLOW), FLOW_ANALYSIS_STATUS_COL, _
        FLOW_ANALYSIS_MEMO_COL, FLOW_ANALYSIS_KEY_COL, SH_ANALYSIS_FLOW, _
        "�����t���[", 20, 0, indexByKey, plannedPresentKeys, _
        plannedStoreAdds, plannedHistoryAdds
    PlanOneAnalysisReviewSheet GetSheet(SH_ANALYSIS_UNKNOWN), UNKNOWN_ANALYSIS_STATUS_COL, _
        UNKNOWN_ANALYSIS_MEMO_COL, UNKNOWN_ANALYSIS_KEY_COL, SH_ANALYSIS_UNKNOWN, _
        "", 24, 0, indexByKey, plannedPresentKeys, _
        plannedStoreAdds, plannedHistoryAdds
    If markMissing Then _
        PlanMissingAnalysisReviewRows wsStore, plannedPresentKeys, plannedHistoryAdds
    EnsureAnalysisReviewBatchCapacity wsStore, wsHistory, storeSnapshotLastRow, _
                                      historySnapshotLastRow, plannedStoreAdds, plannedHistoryAdds

    Set presentKeys = CreateObject("Scripting.Dictionary")
    presentKeys.CompareMode = vbTextCompare
    mReviewPersistActive = True
    mReviewStoreNextRow = storeSnapshotLastRow + 1
    If mReviewStoreNextRow < 2 Then mReviewStoreNextRow = 2
    mReviewHistoryNextRow = historySnapshotLastRow + 1
    If mReviewHistoryNextRow < 2 Then mReviewHistoryNextRow = 2
    mReviewCommitStamp = Now
    mReviewCommitUser = AnalysisReviewUserName()
    mReviewActualStoreAdds = 0
    mReviewActualHistoryAdds = 0
    writeStarted = True

    PersistOneAnalysisReviewSheet GetSheet(SH_ANALYSIS_SHIFT), SHIFT_ANALYSIS_STATUS_COL, _
        SHIFT_ANALYSIS_MEMO_COL, SHIFT_ANALYSIS_KEY_COL, SH_ANALYSIS_SHIFT, _
        "�����V�t�g", 33, 34, indexByKey, presentKeys, reasonText
    PersistOneAnalysisReviewSheet GetSheet(SH_ANALYSIS_FLOW), FLOW_ANALYSIS_STATUS_COL, _
        FLOW_ANALYSIS_MEMO_COL, FLOW_ANALYSIS_KEY_COL, SH_ANALYSIS_FLOW, _
        "�����t���[", 20, 0, indexByKey, presentKeys, reasonText
    PersistOneAnalysisReviewSheet GetSheet(SH_ANALYSIS_UNKNOWN), UNKNOWN_ANALYSIS_STATUS_COL, _
        UNKNOWN_ANALYSIS_MEMO_COL, UNKNOWN_ANALYSIS_KEY_COL, SH_ANALYSIS_UNKNOWN, _
        "", 24, 0, indexByKey, presentKeys, reasonText
    If markMissing Then MarkMissingAnalysisReviewRows wsStore, presentKeys, reasonText
    If mReviewActualStoreAdds <> plannedStoreAdds Or _
       mReviewActualHistoryAdds <> plannedHistoryAdds Then _
        Err.Raise vbObjectError + 4907, "PersistAnalysisReviewsFromCurrentSheets", _
                  "���͔��f�䒠�̎��O�����Ǝ�������������v���܂���B"
    If LastDataRowInColumns(wsStore, 1, ANALYSIS_REVIEW_STORE_LAST_COL) <> _
       storeSnapshotLastRow + plannedStoreAdds Then _
        Err.Raise vbObjectError + 4908, "PersistAnalysisReviewsFromCurrentSheets", _
                  "���͔��f�䒠�̊m��s������v���܂���B"
    If LastDataRowInColumns(wsHistory, 1, ANALYSIS_HISTORY_STORE_LAST_COL) <> _
       historySnapshotLastRow + plannedHistoryAdds Then _
        Err.Raise vbObjectError + 4909, "PersistAnalysisReviewsFromCurrentSheets", _
                  "���͔��f�����̊m��s������v���܂���B"
    EnsureAnalysisPersistenceStoreSafe wsStore, ANALYSIS_REVIEW_STORE_LAST_COL, "���͔��f�䒠"
    EnsureAnalysisPersistenceStoreSafe wsHistory, ANALYSIS_HISTORY_STORE_LAST_COL, "���͔��f����"
    SetSheetVeryHiddenSafe wsStore
    If Not AnalysisReviewStoreIsVeryHidden(wsStore) Then _
        Err.Raise vbObjectError + 4928, "PersistAnalysisReviewsFromCurrentSheets", _
                  "���͔��f�䒠�������\���֖߂��܂���B"
    SetSheetVeryHiddenSafe wsHistory
    If Not AnalysisReviewStoreIsVeryHidden(wsHistory) Then _
        Err.Raise vbObjectError + 4929, "PersistAnalysisReviewsFromCurrentSheets", _
                  "���͔��f�����������\���֖߂��܂���B"
    ResetAnalysisReviewPersistState
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    ResetAnalysisReviewPersistState
    If writeStarted And snapshotsCaptured Then
        On Error Resume Next
        Err.Clear
        RestoreConstantDataStoreSnapshot wsStore, ANALYSIS_REVIEW_STORE_LAST_COL, _
                                         storeSnapshot, storeSnapshotLastRow
        If Err.Number = 0 Then
            storeRestored = True
        Else
            AppendAnalysisReviewRollbackDetail rollbackDetail, _
                "���͔��f�䒠�̕����G���[: " & Err.Description
        End If
        Err.Clear
        RestoreConstantDataStoreSnapshot wsHistory, ANALYSIS_HISTORY_STORE_LAST_COL, _
                                         historySnapshot, historySnapshotLastRow
        If Err.Number = 0 Then
            historyRestored = True
        Else
            AppendAnalysisReviewRollbackDetail rollbackDetail, _
                "���͔��f�����̕����G���[: " & Err.Description
        End If
        Err.Clear
        SetSheetVeryHiddenSafe wsStore
        If Not AnalysisReviewStoreIsVeryHidden(wsStore) Then
            AppendAnalysisReviewRollbackDetail rollbackDetail, _
                "���͔��f�䒠�������\���֖߂��܂���B"
        End If
        Err.Clear
        SetSheetVeryHiddenSafe wsHistory
        If Not AnalysisReviewStoreIsVeryHidden(wsHistory) Then
            AppendAnalysisReviewRollbackDetail rollbackDetail, _
                "���͔��f�����������\���֖߂��܂���B"
        End If
        Err.Clear
        On Error GoTo 0
        rollbackVerified = storeRestored And historyRestored And Len(rollbackDetail) = 0
        If Not rollbackVerified Then
            AppendAnalysisReviewRollbackDetail rollbackDetail, _
                "����Recovery�̏��L�����O���̎�����͂܂���" & _
                "����workspace transaction�֓`�d���܂����B"
        End If
    End If
    If Len(rollbackDetail) > 0 Then _
        errorDescription = errorDescription & " / ���[���o�b�N�m�F: " & rollbackDetail
    Err.Raise errorNumber, "PersistAnalysisReviewsFromCurrentSheets", errorDescription
End Sub

Private Function AnalysisReviewStoreIsVeryHidden(ByVal ws As Worksheet) As Boolean
    'SetSheetVeryHiddenSafe�͌݊�����̂��ߓ����G���[��}�~����B
    '�i�����̊m�苫�E�ł͎���Ԃ�ʓr�ǖ߂��A�擾�s�\���s��v�Ƃ��Ĉ����B
    On Error GoTo EH
    If ws Is Nothing Then Exit Function
    AnalysisReviewStoreIsVeryHidden = (ws.Visible = xlSheetVeryHidden)
    Exit Function
EH:
    AnalysisReviewStoreIsVeryHidden = False
    Err.Clear
End Function

Private Function AnalysisReviewLastRowStrict(ByVal ws As Worksheet, _
                                             ByVal labelText As String) As Long
    Dim lastR As Long
    If ws Is Nothing Then _
        Err.Raise vbObjectError + 4930, "AnalysisReviewLastRowStrict", _
                  labelText & "���擾�ł��܂���B"
    On Error GoTo EH
    If StrComp(ws.Name, SH_WORK_ANALYSIS_HISTORY, vbTextCompare) = 0 Then
        lastR = LastDataRowInColumns(ws, 1, ANALYSIS_HISTORY_STORE_LAST_COL)
    Else
        lastR = LastDataRowInColumns(ws, 1, ANALYSIS_REVIEW_STORE_LAST_COL)
    End If
    AnalysisReviewLastRowStrict = lastR
    Exit Function
EH:
    Err.Raise vbObjectError + 4930, "AnalysisReviewLastRowStrict", _
              labelText & "�̍ŏI�s���m�F�ł��܂���: Err " & _
              CStr(Err.Number) & " " & Err.Description
End Function

Private Sub ResetAnalysisReviewPersistState()
    mReviewPersistActive = False
    mReviewStoreNextRow = 0
    mReviewHistoryNextRow = 0
    mReviewCommitStamp = 0
    mReviewCommitUser = vbNullString
    mReviewActualStoreAdds = 0
    mReviewActualHistoryAdds = 0
End Sub

Private Sub EnsureAnalysisPersistenceStoreSafe(ByVal ws As Worksheet, ByVal lastColumn As Long, _
                                               ByVal labelText As String)
    Dim lastR As Long, dataRange As Range
    Dim formulaCell As Range, errorCell As Range
    If ws Is Nothing Or lastColumn < 1 Then _
        Err.Raise vbObjectError + 4910, "EnsureAnalysisPersistenceStoreSafe", _
                  labelText & "�̌����͈͂��s���ł��B"
    lastR = LastDataRowInColumns(ws, 1, lastColumn)
    If lastR - 1 > MAX_INTERNAL_STORE_DATA_ROWS Then _
        Err.Raise vbObjectError + 4911, "EnsureAnalysisPersistenceStoreSafe", _
                  labelText & "���ۑ�����𒴂��Ă��܂��B"
    If lastR < 2 Then Exit Sub
    Set dataRange = ws.Range(ws.Cells(2, 1), ws.Cells(lastR, lastColumn))
    If Not TryFindFirstFormulaCell(dataRange, formulaCell) Then _
        Err.Raise vbObjectError + 4912, "EnsureAnalysisPersistenceStoreSafe", _
                  labelText & "�̐��������Ɏ��s���܂����B"
    If Not formulaCell Is Nothing Then _
        Err.Raise vbObjectError + 4912, "EnsureAnalysisPersistenceStoreSafe", _
                  labelText & "�ɐ���������܂�: " & formulaCell.Address(False, False)
    If Not TryFindFirstErrorConstantCell(dataRange, errorCell) Then _
        Err.Raise vbObjectError + 4913, "EnsureAnalysisPersistenceStoreSafe", _
                  labelText & "��Excel�G���[�����Ɏ��s���܂����B"
    If Not errorCell Is Nothing Then _
        Err.Raise vbObjectError + 4913, "EnsureAnalysisPersistenceStoreSafe", _
                  labelText & "��Excel�G���[������܂�: " & errorCell.Address(False, False)
    EnsureAnalysisReviewRangeHasNoPrefix dataRange, labelText
End Sub

Private Sub EnsureAnalysisReviewRangeHasNoPrefix(ByVal target As Range, ByVal labelText As String)
    Const PREFIX_CHECK_ROWS As Long = 500
    Dim rowOffset As Long, chunkRows As Long
    Dim chunk As Range, cell As Range
    Dim prefixState As Variant, scanCells As Boolean
    Dim scanError As Long
    If target Is Nothing Then Exit Sub
    For rowOffset = 1 To target.Rows.Count Step PREFIX_CHECK_ROWS
        chunkRows = CLng(Application.Min(PREFIX_CHECK_ROWS, _
                                         target.Rows.Count - rowOffset + 1))
        Set chunk = target.Rows(rowOffset).Resize(chunkRows, target.Columns.Count)
        scanCells = False
        On Error Resume Next
        Err.Clear
        prefixState = chunk.PrefixCharacter
        scanError = Err.Number
        Err.Clear
        On Error GoTo 0
        If scanError <> 0 Or IsNull(prefixState) Then
            scanCells = True
        ElseIf Len(CStr(prefixState)) > 0 Then
            scanCells = True
        End If
        If scanCells Then
            For Each cell In chunk.Cells
                If Len(CStr(cell.PrefixCharacter)) > 0 Then _
                    Err.Raise vbObjectError + 4914, "EnsureAnalysisReviewRangeHasNoPrefix", _
                              labelText & "�ɐ擪�A�|�X�g���t�B�t���̒l������܂�: " & _
                              cell.Address(False, False)
            Next cell
        End If
    Next rowOffset
End Sub

Private Sub EnsureAnalysisReviewBatchCapacity(ByVal wsStore As Worksheet, _
                                              ByVal wsHistory As Worksheet, _
                                              ByVal storeLastRow As Long, _
                                              ByVal historyLastRow As Long, _
                                              ByVal storeAdds As Long, _
                                              ByVal historyAdds As Long)
    If storeAdds < 0 Or historyAdds < 0 Then _
        Err.Raise vbObjectError + 4915, "EnsureAnalysisReviewBatchCapacity", _
                  "���͔��f�̒ǉ��\�茏�����s���ł��B"
    If storeLastRow - 1 + storeAdds > MAX_INTERNAL_STORE_DATA_ROWS Or _
       storeLastRow + storeAdds > wsStore.Rows.Count Then _
        Err.Raise vbObjectError + 4916, "EnsureAnalysisReviewBatchCapacity", _
                  "���͔��f�䒠�̋󂫍s���s�����Ă��܂��B�Č��t�@�C���𕪂��Ă��������B"
    If historyLastRow - 1 + historyAdds > MAX_INTERNAL_STORE_DATA_ROWS Or _
       historyLastRow + historyAdds > wsHistory.Rows.Count Then _
        Err.Raise vbObjectError + 4917, "EnsureAnalysisReviewBatchCapacity", _
                  "���͔��f�����̋󂫍s���s�����Ă��܂��B�Č��t�@�C���𕪂��Ă��������B"
End Sub

Private Sub AppendAnalysisReviewRollbackDetail(ByRef detailText As String, _
                                               ByVal newDetail As String)
    newDetail = Trim$(newDetail)
    If Len(newDetail) = 0 Then Exit Sub
    If Len(detailText) > 0 Then detailText = detailText & " / "
    detailText = detailText & newDetail
End Sub

Private Sub ValidateAnalysisReviewSourcesBeforePersist()
    Dim ws As Worksheet
    Dim validatedReviews As Object

    Set ws = GetSheet(SH_ANALYSIS_SHIFT)
    EnsureExistingAnalysisReviewBounds ws, "�����V�t�g���"
    EnsureAnalysisReviewSourceInputsSafe ws, SHIFT_ANALYSIS_STATUS_COL, _
        SHIFT_ANALYSIS_MEMO_COL, SHIFT_ANALYSIS_KEY_COL, 33, 34, 0, _
        "�����V�t�g���"
    Set validatedReviews = CaptureAnalysisReviews( _
                               ws, SHIFT_ANALYSIS_STATUS_COL, _
                               SHIFT_ANALYSIS_MEMO_COL, SHIFT_ANALYSIS_KEY_COL)

    Set ws = GetSheet(SH_ANALYSIS_FLOW)
    EnsureExistingAnalysisReviewBounds ws, "�����t���[�ǐ�"
    EnsureAnalysisReviewSourceInputsSafe ws, FLOW_ANALYSIS_STATUS_COL, _
        FLOW_ANALYSIS_MEMO_COL, FLOW_ANALYSIS_KEY_COL, 20, 0, 0, _
        "�����t���[�ǐ�"
    Set validatedReviews = CaptureAnalysisReviews( _
                               ws, FLOW_ANALYSIS_STATUS_COL, _
                               FLOW_ANALYSIS_MEMO_COL, FLOW_ANALYSIS_KEY_COL)

    Set ws = GetSheet(SH_ANALYSIS_UNKNOWN)
    EnsureExistingAnalysisReviewBounds ws, "�s�����o��"
    EnsureAnalysisReviewSourceInputsSafe ws, UNKNOWN_ANALYSIS_STATUS_COL, _
        UNKNOWN_ANALYSIS_MEMO_COL, UNKNOWN_ANALYSIS_KEY_COL, 24, 0, 3, _
        "�s�����o��"
    Set validatedReviews = CaptureAnalysisReviews( _
                               ws, UNKNOWN_ANALYSIS_STATUS_COL, _
                               UNKNOWN_ANALYSIS_MEMO_COL, UNKNOWN_ANALYSIS_KEY_COL)
End Sub

Private Function BuildAnalysisReviewStoreIndex(ByVal ws As Worksheet) As Object
    Dim result As Object, lastR As Long, values As Variant, r As Long, keyText As String
    Set result = CreateObject("Scripting.Dictionary")
    result.CompareMode = vbTextCompare
    lastR = AnalysisReviewLastRowStrict(ws, "���͔��f�䒠")
    If lastR >= 2 Then
        values = ws.Range(ws.Cells(2, REVIEW_STORE_COL_KEY), _
                          ws.Cells(lastR, REVIEW_STORE_COL_KEY)).Value2
        For r = 1 To lastR - 1
            keyText = ReviewStoreColumnValue(values, r, lastR - 1)
            If Len(keyText) > 0 Then
                If result.Exists(keyText) Then _
                    Err.Raise vbObjectError + 4903, "BuildAnalysisReviewStoreIndex", _
                              "���͔��f�䒠�̌��L�[���d�����Ă��܂�: " & keyText
                result.Add keyText, r + 1
            End If
        Next r
    End If
    Set BuildAnalysisReviewStoreIndex = result
End Function

Private Sub PlanOneAnalysisReviewSheet( _
        ByVal ws As Worksheet, ByVal statusColumn As Long, ByVal memoColumn As Long, _
        ByVal keyColumn As Long, ByVal sourceName As String, ByVal fixedCategory As String, _
        ByVal firstTxColumn As Long, ByVal secondTxColumn As Long, _
        ByVal indexByKey As Object, ByVal presentKeys As Object, _
        ByRef plannedStoreAdds As Long, ByRef plannedHistoryAdds As Long)
    Dim lastR As Long, lastColumn As Long, data As Variant, r As Long, rowNo As Long
    Dim storedKey As String, baseKey As String, evidenceText As String
    Dim statusText As String, memoText As String
    Dim oldStatus As String, oldMemo As String, oldEvidence As String, oldPresence As String
    Dim changed As Boolean, wsStore As Worksheet
    If ws Is Nothing Then Exit Sub
    Set wsStore = GetSheet(SH_WORK_ANALYSIS_REVIEW)
    lastR = AnalysisReviewLastRowStrict(ws, sourceName)
    If lastR < 2 Then Exit Sub
    lastColumn = CLng(Application.Max(statusColumn, memoColumn, keyColumn, _
                                      firstTxColumn, secondTxColumn, 3))
    data = ws.Range(ws.Cells(2, 1), ws.Cells(lastR, lastColumn)).Value2
    For r = 1 To UBound(data, 1)
        storedKey = CellText(data(r, keyColumn))
        If Len(storedKey) > 0 Then
            baseKey = AnalysisBaseKey(storedKey, evidenceText)
            If Len(baseKey) = 0 Then _
                Err.Raise vbObjectError + 4904, "PlanOneAnalysisReviewSheet", _
                          sourceName & " " & CStr(r + 1) & "�s�ڂ̌��L�[���s���ł��B"
            If presentKeys.Exists(baseKey) Then _
                Err.Raise vbObjectError + 4918, "PlanOneAnalysisReviewSheet", _
                          "���͕\�ԂŌ��L�[���d�����Ă��܂�: " & baseKey
            presentKeys.Add baseKey, True
            statusText = CellText(data(r, statusColumn))
            If Len(statusText) = 0 Then statusText = ANALYSIS_STATUS_UNREVIEWED
            memoText = CellText(data(r, memoColumn))
            If statusText <> ANALYSIS_STATUS_UNREVIEWED Or Len(memoText) > 0 Or _
               indexByKey.Exists(baseKey) Then
                If indexByKey.Exists(baseKey) Then
                    rowNo = CLng(indexByKey(baseKey))
                    oldStatus = CellText(wsStore.Cells( _
                                             rowNo, REVIEW_STORE_COL_STATUS).Value2)
                    oldMemo = CellText(wsStore.Cells( _
                                           rowNo, REVIEW_STORE_COL_MEMO).Value2)
                    oldEvidence = CellText(wsStore.Cells( _
                                               rowNo, REVIEW_STORE_COL_EVIDENCE).Value2)
                    oldPresence = CellText(wsStore.Cells( _
                                               rowNo, REVIEW_STORE_COL_PRESENCE).Value2)
                Else
                    plannedStoreAdds = plannedStoreAdds + 1
                    oldStatus = vbNullString
                    oldMemo = vbNullString
                    oldEvidence = vbNullString
                    oldPresence = vbNullString
                End If
                changed = (StrComp(oldStatus, statusText, vbBinaryCompare) <> 0 Or _
                           StrComp(oldMemo, memoText, vbBinaryCompare) <> 0 Or _
                           StrComp(oldEvidence, evidenceText, vbBinaryCompare) <> 0 Or _
                           StrComp(oldPresence, "���s", vbBinaryCompare) <> 0)
                If changed Then plannedHistoryAdds = plannedHistoryAdds + 1
            End If
        End If
    Next r
End Sub

Private Sub EnsureAnalysisReviewSourceInputsSafe(ByVal ws As Worksheet, _
                                                 ByVal statusColumn As Long, _
                                                 ByVal memoColumn As Long, _
                                                 ByVal keyColumn As Long, _
                                                 ByVal firstTxColumn As Long, _
                                                 ByVal secondTxColumn As Long, _
                                                 ByVal categoryColumn As Long, _
                                                 ByVal labelText As String)
    Dim lastR As Long, reviewRange As Range
    Dim formulaCell As Range, errorCell As Range
    If ws Is Nothing Then _
        Err.Raise vbObjectError + 4925, "EnsureAnalysisReviewSourceInputsSafe", _
                  labelText & "���擾�ł��܂���B"
    If Not TryGetLastUsedRowInSheet(ws, lastR) Then _
        Err.Raise vbObjectError + 4925, "EnsureAnalysisReviewSourceInputsSafe", _
                  labelText & "�̍ŏI�s���m�F�ł��܂���B"
    If lastR < 2 Then Exit Sub
    Set reviewRange = Union( _
        ws.Range(ws.Cells(2, statusColumn), ws.Cells(lastR, statusColumn)), _
        ws.Range(ws.Cells(2, memoColumn), ws.Cells(lastR, memoColumn)), _
        ws.Range(ws.Cells(2, keyColumn), ws.Cells(lastR, keyColumn)), _
        ws.Range(ws.Cells(2, firstTxColumn), ws.Cells(lastR, firstTxColumn)))
    If secondTxColumn > 0 Then _
        Set reviewRange = Union(reviewRange, ws.Range( _
            ws.Cells(2, secondTxColumn), ws.Cells(lastR, secondTxColumn)))
    If categoryColumn > 0 Then _
        Set reviewRange = Union(reviewRange, ws.Range( _
            ws.Cells(2, categoryColumn), ws.Cells(lastR, categoryColumn)))
    If Not TryFindFirstFormulaCell(reviewRange, formulaCell) Then _
        Err.Raise vbObjectError + 4926, "EnsureAnalysisReviewSourceInputsSafe", _
                  labelText & "�̐��������Ɏ��s���܂����B"
    If Not formulaCell Is Nothing Then _
        Err.Raise vbObjectError + 4926, "EnsureAnalysisReviewSourceInputsSafe", _
                  labelText & "�̉i�����Ώۂɐ���������܂�: " & _
                  formulaCell.Address(False, False)
    If Not TryFindFirstErrorConstantCell(reviewRange, errorCell) Then _
        Err.Raise vbObjectError + 4927, "EnsureAnalysisReviewSourceInputsSafe", _
                  labelText & "��Excel�G���[�����Ɏ��s���܂����B"
    If Not errorCell Is Nothing Then _
        Err.Raise vbObjectError + 4927, "EnsureAnalysisReviewSourceInputsSafe", _
                  labelText & "�̉i�����Ώۂ�Excel�G���[������܂�: " & _
                  errorCell.Address(False, False)
    EnsureAnalysisReviewRangeHasNoPrefix reviewRange, labelText
End Sub

Private Sub PlanMissingAnalysisReviewRows(ByVal ws As Worksheet, ByVal presentKeys As Object, _
                                          ByRef plannedHistoryAdds As Long)
    Dim lastR As Long, r As Long, keyText As String
    lastR = AnalysisReviewLastRowStrict(ws, "���͔��f�䒠")
    If lastR < 2 Then Exit Sub
    For r = 2 To lastR
        keyText = CellText(ws.Cells(r, REVIEW_STORE_COL_KEY).Value2)
        If Len(keyText) > 0 And Not presentKeys.Exists(keyText) Then
            If CellText(ws.Cells(r, REVIEW_STORE_COL_PRESENCE).Value2) <> "����" Then _
                plannedHistoryAdds = plannedHistoryAdds + 1
        End If
    Next r
End Sub

Private Sub PersistOneAnalysisReviewSheet( _
        ByVal ws As Worksheet, ByVal statusColumn As Long, ByVal memoColumn As Long, _
        ByVal keyColumn As Long, ByVal sourceName As String, ByVal fixedCategory As String, _
        ByVal firstTxColumn As Long, ByVal secondTxColumn As Long, _
        ByVal indexByKey As Object, ByVal presentKeys As Object, ByVal reasonText As String)
    Dim lastR As Long, lastColumn As Long, data As Variant, r As Long
    Dim storedKey As String, baseKey As String, evidenceText As String
    Dim statusText As String, memoText As String, categoryText As String, txIDs As String
    If ws Is Nothing Then Exit Sub
    lastR = AnalysisReviewLastRowStrict(ws, sourceName)
    If lastR < 2 Then Exit Sub
    lastColumn = CLng(Application.Max(statusColumn, memoColumn, keyColumn, _
                                      firstTxColumn, secondTxColumn, 3))
    data = ws.Range(ws.Cells(2, 1), ws.Cells(lastR, lastColumn)).Value2
    For r = 1 To UBound(data, 1)
        storedKey = CellText(data(r, keyColumn))
        If Len(storedKey) > 0 Then
            baseKey = AnalysisBaseKey(storedKey, evidenceText)
            If Len(baseKey) = 0 Then _
                Err.Raise vbObjectError + 4904, "PersistOneAnalysisReviewSheet", _
                          sourceName & " " & CStr(r + 1) & "�s�ڂ̌��L�[���s���ł��B"
            If presentKeys.Exists(baseKey) Then _
                Err.Raise vbObjectError + 4918, "PersistOneAnalysisReviewSheet", _
                          "���͕\�ԂŌ��L�[���d�����Ă��܂�: " & baseKey
            presentKeys.Add baseKey, True
            statusText = CellText(data(r, statusColumn))
            If Len(statusText) = 0 Then statusText = ANALYSIS_STATUS_UNREVIEWED
            memoText = CellText(data(r, memoColumn))
            categoryText = fixedCategory
            If Len(categoryText) = 0 Then categoryText = Replace(CellText(data(r, 3)), "���", "")
            txIDs = CellText(data(r, firstTxColumn))
            If secondTxColumn > 0 Then txIDs = JoinAnalysisReviewIDs(txIDs, _
                                                   CellText(data(r, secondTxColumn)))
            If statusText <> ANALYSIS_STATUS_UNREVIEWED Or Len(memoText) > 0 Or _
               indexByKey.Exists(baseKey) Then
                UpsertAnalysisReviewStore baseKey, sourceName, categoryText, statusText, memoText, _
                    evidenceText, txIDs, "���s", reasonText, indexByKey
            End If
        End If
    Next r
End Sub

Private Sub UpsertAnalysisReviewStore( _
        ByVal baseKey As String, ByVal sourceName As String, ByVal categoryText As String, _
        ByVal statusText As String, ByVal memoText As String, ByVal evidenceText As String, _
        ByVal txIDs As String, ByVal presenceText As String, ByVal reasonText As String, _
        ByVal indexByKey As Object)
    Dim ws As Worksheet, rowNo As Long, c As Long
    Dim oldStatus As String, oldMemo As String, oldEvidence As String, oldPresence As String
    Dim changed As Boolean, effectiveReason As String, isNewRow As Boolean
    Dim currentData As Variant, expectedData As Variant
    Dim writtenRange As Range
    If Not mReviewPersistActive Then _
        Err.Raise vbObjectError + 4919, "UpsertAnalysisReviewStore", _
                  "���͔��f�䒠�̏����g�����U�N�V�������J�n����Ă��܂���B"
    Set ws = GetSheet(SH_WORK_ANALYSIS_REVIEW)
    If indexByKey.Exists(baseKey) Then
        rowNo = CLng(indexByKey(baseKey))
        oldStatus = CellText(ws.Cells(rowNo, REVIEW_STORE_COL_STATUS).Value2)
        oldMemo = CellText(ws.Cells(rowNo, REVIEW_STORE_COL_MEMO).Value2)
        oldEvidence = CellText(ws.Cells(rowNo, REVIEW_STORE_COL_EVIDENCE).Value2)
        oldPresence = CellText(ws.Cells(rowNo, REVIEW_STORE_COL_PRESENCE).Value2)
    Else
        isNewRow = True
        rowNo = mReviewStoreNextRow
        mReviewStoreNextRow = mReviewStoreNextRow + 1
        mReviewActualStoreAdds = mReviewActualStoreAdds + 1
        indexByKey.Add baseKey, rowNo
    End If
    changed = (StrComp(oldStatus, statusText, vbBinaryCompare) <> 0 Or _
               StrComp(oldMemo, memoText, vbBinaryCompare) <> 0 Or _
               StrComp(oldEvidence, evidenceText, vbBinaryCompare) <> 0 Or _
               StrComp(oldPresence, presenceText, vbBinaryCompare) <> 0)
    If Not changed And _
       StrComp(CellText(ws.Cells(rowNo, REVIEW_STORE_COL_SOURCE).Value2), _
               sourceName, vbBinaryCompare) = 0 And _
       StrComp(CellText(ws.Cells(rowNo, REVIEW_STORE_COL_CATEGORY).Value2), _
               categoryText, vbBinaryCompare) = 0 And _
       StrComp(CellText(ws.Cells(rowNo, REVIEW_STORE_COL_TX_IDS).Value2), _
               txIDs, vbBinaryCompare) = 0 Then Exit Sub

    effectiveReason = reasonText
    If Len(effectiveReason) = 0 Then
        If Len(oldEvidence) > 0 And StrComp(oldEvidence, evidenceText, vbBinaryCompare) <> 0 Then
            effectiveReason = "�����܂��͕��͏����̕ύX"
        ElseIf oldPresence = "����" And presenceText = "���s" Then
            effectiveReason = "��₪�ďo��"
        ElseIf Len(oldStatus) = 0 Then
            effectiveReason = "���f�䒠�֓o�^"
        Else
            effectiveReason = "�m�F���e���X�V"
        End If
    End If
    If changed Then AppendAnalysisReviewHistory baseKey, sourceName, categoryText, _
        oldStatus, statusText, oldMemo, memoText, oldEvidence, evidenceText, effectiveReason

    ReDim expectedData(1 To 1, 1 To ANALYSIS_REVIEW_STORE_LAST_COL)
    Set writtenRange = ws.Range(ws.Cells(rowNo, 1), _
                                ws.Cells(rowNo, ANALYSIS_REVIEW_STORE_LAST_COL))
    If Not isNewRow Then
        currentData = writtenRange.Value2
        For c = 1 To ANALYSIS_REVIEW_STORE_LAST_COL
            expectedData(1, c) = currentData(1, c)
        Next c
    End If
    expectedData(1, REVIEW_STORE_COL_KEY) = AnalysisReviewExpectedValue2(baseKey)
    expectedData(1, REVIEW_STORE_COL_SOURCE) = AnalysisReviewExpectedValue2(sourceName)
    expectedData(1, REVIEW_STORE_COL_CATEGORY) = AnalysisReviewExpectedValue2(categoryText)
    expectedData(1, REVIEW_STORE_COL_STATUS) = AnalysisReviewExpectedValue2(statusText)
    expectedData(1, REVIEW_STORE_COL_MEMO) = AnalysisReviewExpectedValue2(memoText)
    expectedData(1, REVIEW_STORE_COL_EVIDENCE) = AnalysisReviewExpectedValue2(evidenceText)
    expectedData(1, REVIEW_STORE_COL_TX_IDS) = AnalysisReviewExpectedValue2(txIDs)
    expectedData(1, REVIEW_STORE_COL_UPDATED_AT) = CDbl(mReviewCommitStamp)
    expectedData(1, REVIEW_STORE_COL_PRESENCE) = AnalysisReviewExpectedValue2(presenceText)
    expectedData(1, REVIEW_STORE_COL_PREVIOUS_STATUS) = AnalysisReviewExpectedValue2(oldStatus)
    expectedData(1, REVIEW_STORE_COL_PREVIOUS_EVIDENCE) = AnalysisReviewExpectedValue2(oldEvidence)
    expectedData(1, REVIEW_STORE_COL_REASON) = AnalysisReviewExpectedValue2(effectiveReason)
    expectedData(1, REVIEW_STORE_COL_USER) = AnalysisReviewExpectedValue2(mReviewCommitUser)
    writtenRange.Value2 = expectedData
    If Not RangeValue2MatchesMatrixStrict(writtenRange, expectedData, 1, _
                                          ANALYSIS_REVIEW_STORE_LAST_COL) Then _
        Err.Raise vbObjectError + 4920, "UpsertAnalysisReviewStore", _
                  "���͔��f�䒠�̏����ǖ߂����S��E�^�ň�v���܂���: " & baseKey
End Sub

Private Sub MarkMissingAnalysisReviewRows(ByVal ws As Worksheet, ByVal presentKeys As Object, _
                                          ByVal reasonText As String)
    Dim lastR As Long, r As Long, keyText As String, oldPresence As String
    Dim effectiveReason As String
    lastR = AnalysisReviewLastRowStrict(ws, "���͔��f�䒠")
    If lastR < 2 Then Exit Sub
    effectiveReason = reasonText
    If Len(effectiveReason) = 0 Then effectiveReason = "���ݏ����ł͌��Ȃ�"
    For r = 2 To lastR
        keyText = CellText(ws.Cells(r, REVIEW_STORE_COL_KEY).Value)
        If Len(keyText) > 0 And Not presentKeys.Exists(keyText) Then
            oldPresence = CellText(ws.Cells(r, REVIEW_STORE_COL_PRESENCE).Value)
            If oldPresence <> "����" Then
                AppendAnalysisReviewHistory keyText, _
                    CellText(ws.Cells(r, REVIEW_STORE_COL_SOURCE).Value), _
                    CellText(ws.Cells(r, REVIEW_STORE_COL_CATEGORY).Value), _
                    CellText(ws.Cells(r, REVIEW_STORE_COL_STATUS).Value), _
                    CellText(ws.Cells(r, REVIEW_STORE_COL_STATUS).Value), _
                    CellText(ws.Cells(r, REVIEW_STORE_COL_MEMO).Value), _
                    CellText(ws.Cells(r, REVIEW_STORE_COL_MEMO).Value), _
                    CellText(ws.Cells(r, REVIEW_STORE_COL_EVIDENCE).Value), _
                    CellText(ws.Cells(r, REVIEW_STORE_COL_EVIDENCE).Value), effectiveReason
                WriteMissingAnalysisReviewRow ws, r, effectiveReason
            End If
        End If
    Next r
End Sub

Private Sub WriteMissingAnalysisReviewRow(ByVal ws As Worksheet, ByVal rowNo As Long, _
                                          ByVal effectiveReason As String)
    Dim expectedData As Variant, writtenRange As Range
    Set writtenRange = ws.Range(ws.Cells(rowNo, 1), _
                                ws.Cells(rowNo, ANALYSIS_REVIEW_STORE_LAST_COL))
    expectedData = writtenRange.Value2
    expectedData(1, REVIEW_STORE_COL_UPDATED_AT) = CDbl(mReviewCommitStamp)
    expectedData(1, REVIEW_STORE_COL_PRESENCE) = AnalysisReviewExpectedValue2("����")
    expectedData(1, REVIEW_STORE_COL_REASON) = AnalysisReviewExpectedValue2(effectiveReason)
    expectedData(1, REVIEW_STORE_COL_USER) = AnalysisReviewExpectedValue2(mReviewCommitUser)
    writtenRange.Value2 = expectedData
    If Not RangeValue2MatchesMatrixStrict(writtenRange, expectedData, 1, _
                                          ANALYSIS_REVIEW_STORE_LAST_COL) Then _
        Err.Raise vbObjectError + 4921, "WriteMissingAnalysisReviewRow", _
                  "���ł������͔��f�̏����ǖ߂����S��E�^�ň�v���܂���B"
End Sub

Private Sub AppendAnalysisReviewHistory( _
        ByVal baseKey As String, ByVal sourceName As String, ByVal categoryText As String, _
        ByVal oldStatus As String, ByVal newStatus As String, ByVal oldMemo As String, _
        ByVal newMemo As String, ByVal oldEvidence As String, ByVal newEvidence As String, _
        ByVal reasonText As String)
    Dim ws As Worksheet, rowNo As Long, historyID As String
    Dim expectedData As Variant
    Dim writtenRange As Range
    If Not mReviewPersistActive Then _
        Err.Raise vbObjectError + 4922, "AppendAnalysisReviewHistory", _
                  "���͔��f�����̏����g�����U�N�V�������J�n����Ă��܂���B"
    Set ws = GetSheet(SH_WORK_ANALYSIS_HISTORY)
    ReDim expectedData(1 To 1, 1 To ANALYSIS_HISTORY_STORE_LAST_COL)
    rowNo = mReviewHistoryNextRow
    mReviewHistoryNextRow = mReviewHistoryNextRow + 1
    mReviewActualHistoryAdds = mReviewActualHistoryAdds + 1
    historyID = "RH-" & Format$(mReviewCommitStamp, "yyyymmddhhnnss") & _
                "-" & Format$(rowNo - 1, "000000")
    expectedData(1, 1) = AnalysisReviewExpectedValue2(historyID)
    expectedData(1, 2) = AnalysisReviewExpectedValue2(baseKey)
    expectedData(1, 3) = CDbl(mReviewCommitStamp)
    expectedData(1, 4) = AnalysisReviewExpectedValue2(mReviewCommitUser)
    expectedData(1, 5) = AnalysisReviewExpectedValue2(sourceName)
    expectedData(1, 6) = AnalysisReviewExpectedValue2(categoryText)
    expectedData(1, 7) = AnalysisReviewExpectedValue2(oldStatus)
    expectedData(1, 8) = AnalysisReviewExpectedValue2(newStatus)
    expectedData(1, 9) = AnalysisReviewExpectedValue2(oldMemo)
    expectedData(1, 10) = AnalysisReviewExpectedValue2(newMemo)
    expectedData(1, 11) = AnalysisReviewExpectedValue2(oldEvidence)
    expectedData(1, 12) = AnalysisReviewExpectedValue2(newEvidence)
    expectedData(1, 13) = AnalysisReviewExpectedValue2(reasonText)
    Set writtenRange = ws.Range(ws.Cells(rowNo, 1), _
                                ws.Cells(rowNo, ANALYSIS_HISTORY_STORE_LAST_COL))
    writtenRange.Value2 = expectedData
    If Not RangeValue2MatchesMatrixStrict(writtenRange, expectedData, 1, _
                                          ANALYSIS_HISTORY_STORE_LAST_COL) Then _
        Err.Raise vbObjectError + 4923, "AppendAnalysisReviewHistory", _
                  "���͔��f�����̏����ǖ߂����S��E�^�ň�v���܂���B"
End Sub

Private Function AnalysisReviewExpectedValue2(ByVal valueIn As Variant) As Variant
    If IsError(valueIn) Or IsNull(valueIn) Then _
        Err.Raise vbObjectError + 4924, "AnalysisReviewExpectedValue2", _
                  "���͔��f�䒠�֕ۑ��ł��Ȃ��l������܂��B"
    If IsEmpty(valueIn) Then
        AnalysisReviewExpectedValue2 = Empty
    ElseIf VarType(valueIn) = vbString And Len(CStr(valueIn)) = 0 Then
        AnalysisReviewExpectedValue2 = Empty
    ElseIf VarType(valueIn) = vbDate Then
        AnalysisReviewExpectedValue2 = CDbl(valueIn)
    ElseIf VarType(valueIn) <> vbString And VarType(valueIn) <> vbBoolean And _
           IsNumeric(valueIn) Then
        AnalysisReviewExpectedValue2 = CDbl(valueIn)
    Else
        AnalysisReviewExpectedValue2 = valueIn
    End If
End Function

Private Function AnalysisReviewUserName() As String
    On Error Resume Next
    AnalysisReviewUserName = Trim$(Application.UserName)
    If Len(AnalysisReviewUserName) = 0 Then AnalysisReviewUserName = Trim$(Environ$("Username"))
    If Len(AnalysisReviewUserName) = 0 Then AnalysisReviewUserName = "�m�F�Җ��ݒ�"
    On Error GoTo 0
End Function

Private Function JoinAnalysisReviewIDs(ByVal firstID As String, ByVal secondID As String) As String
    If Len(firstID) = 0 Then
        JoinAnalysisReviewIDs = secondID
    ElseIf Len(secondID) = 0 Or StrComp(firstID, secondID, vbTextCompare) = 0 Then
        JoinAnalysisReviewIDs = firstID
    Else
        JoinAnalysisReviewIDs = firstID & ";" & secondID
    End If
End Function

Private Function ReviewStoreColumnValue(ByVal values As Variant, ByVal itemIndex As Long, _
                                        ByVal itemCount As Long) As String
    If itemCount = 1 Then
        ReviewStoreColumnValue = CellText(values)
    Else
        ReviewStoreColumnValue = CellText(values(itemIndex, 1))
    End If
End Function

Public Sub CheckAnalysisReviewStores(ByRef problems As String, _
                                     ByRef interfaceWarnings As String, _
                                     ByVal includeInterfaceChecks As Boolean)
    Dim ws As Worksheet, lastR As Long, data As Variant, r As Long
    Dim seen As Object, keyText As String, statusText As String, presenceText As String
    Dim sourceText As String, categoryText As String, evidenceText As String
    Dim wsHistory As Worksheet, historyData As Variant, historyID As String
    If Not SheetExists(SH_WORK_ANALYSIS_REVIEW) Or _
       Not SheetExists(SH_WORK_ANALYSIS_HISTORY) Then
        problems = problems & "�E���͔��f�䒠�܂��͗���������܂���" & vbCrLf
        Exit Sub
    End If
    Set ws = GetSheet(SH_WORK_ANALYSIS_REVIEW)
    Set seen = CreateObject("Scripting.Dictionary")
    seen.CompareMode = vbTextCompare
    lastR = AnalysisReviewLastRowStrict(ws, "���͔��f�䒠")
    If lastR - 1 > MAX_INTERNAL_STORE_DATA_ROWS Then _
        problems = problems & "�E���͔��f�䒠���ۑ�����𒴂��Ă��܂�" & vbCrLf
    If lastR >= 2 Then
        data = ws.Range(ws.Cells(2, 1), _
                        ws.Cells(lastR, ANALYSIS_REVIEW_STORE_LAST_COL)).Value2
        For r = 1 To UBound(data, 1)
            keyText = CellText(data(r, REVIEW_STORE_COL_KEY))
            sourceText = CellText(data(r, REVIEW_STORE_COL_SOURCE))
            categoryText = CellText(data(r, REVIEW_STORE_COL_CATEGORY))
            statusText = CellText(data(r, REVIEW_STORE_COL_STATUS))
            evidenceText = CellText(data(r, REVIEW_STORE_COL_EVIDENCE))
            presenceText = CellText(data(r, REVIEW_STORE_COL_PRESENCE))
            If Len(keyText) = 0 Then
                problems = problems & "�E���͔��f�䒠 " & CStr(r + 1) & "�s: ���L�[�Ȃ�" & vbCrLf
            ElseIf seen.Exists(keyText) Then
                problems = problems & "�E���͔��f�䒠: ���L�[�d�� " & keyText & vbCrLf
            Else
                seen.Add keyText, True
            End If
            If InStr(1, keyText, ANALYSIS_EVIDENCE_MARKER, vbBinaryCompare) > 0 Then _
                problems = problems & "�E���͔��f�䒠 " & CStr(r + 1) & "�s: ���L�[�ɍ�������������" & vbCrLf
            If Not ReviewStoreStatusFits(sourceText, categoryText, statusText) Then _
                problems = problems & "�E���͔��f�䒠 " & CStr(r + 1) & "�s: ���\�E�敪�Ɗm�F�󋵂��s�K��" & vbCrLf
            If presenceText <> "���s" And presenceText <> "����" Then _
                problems = problems & "�E���͔��f�䒠 " & CStr(r + 1) & "�s: ���s��ԕs��" & vbCrLf
            If Len(CellText(data(r, REVIEW_STORE_COL_MEMO))) > ANALYSIS_REVIEW_MEMO_MAX Then _
                problems = problems & "�E���͔��f�䒠 " & CStr(r + 1) & "�s: �m�F�������������܂�" & vbCrLf
            If Len(evidenceText) = 0 Then
                If presenceText = "���s" Then _
                    problems = problems & "�E���͔��f�䒠 " & CStr(r + 1) & "�s: ���s���̍��������Ȃ�" & vbCrLf
            ElseIf Not ReviewEvidenceDigestIsValid(evidenceText) Then
                problems = problems & "�E���͔��f�䒠 " & CStr(r + 1) & "�s: ���������s��" & vbCrLf
            End If
            If Len(CellText(data(r, REVIEW_STORE_COL_TX_IDS))) = 0 Then _
                problems = problems & "�E���͔��f�䒠 " & CStr(r + 1) & "�s: �\�����ID�Ȃ�" & vbCrLf
            If Not IsDate(data(r, REVIEW_STORE_COL_UPDATED_AT)) Then _
                problems = problems & "�E���͔��f�䒠 " & CStr(r + 1) & "�s: �X�V�����s��" & vbCrLf
            If Len(CellText(data(r, REVIEW_STORE_COL_REASON))) = 0 Or _
               Len(CellText(data(r, REVIEW_STORE_COL_USER))) = 0 Then _
                problems = problems & "�E���͔��f�䒠 " & CStr(r + 1) & "�s: �ύX���R�܂��͊m�F�҂Ȃ�" & vbCrLf
            If Len(problems) > 700000 Then Exit For
        Next r
    End If
    If includeInterfaceChecks Then
        If ws.Visible <> xlSheetVeryHidden Then _
            interfaceWarnings = interfaceWarnings & "�E���͔��f�䒠��VeryHidden�ł͂���܂���" & vbCrLf
    End If
    Set wsHistory = GetSheet(SH_WORK_ANALYSIS_HISTORY)
    lastR = AnalysisReviewLastRowStrict(wsHistory, "���͔��f����")
    If lastR - 1 > MAX_INTERNAL_STORE_DATA_ROWS Then _
        problems = problems & "�E���͔��f�������ۑ�����𒴂��Ă��܂�" & vbCrLf
    Set seen = CreateObject("Scripting.Dictionary")
    seen.CompareMode = vbTextCompare
    If lastR >= 2 Then
        historyData = wsHistory.Range(wsHistory.Cells(2, 1), _
                        wsHistory.Cells(lastR, ANALYSIS_HISTORY_STORE_LAST_COL)).Value2
        For r = 1 To UBound(historyData, 1)
            historyID = CellText(historyData(r, 1))
            keyText = CellText(historyData(r, 2))
            sourceText = CellText(historyData(r, 5))
            categoryText = CellText(historyData(r, 6))
            statusText = CellText(historyData(r, 8))
            If Len(historyID) = 0 Or seen.Exists(historyID) Then
                problems = problems & "�E���͔��f���� " & CStr(r + 1) & "�s: ����ID�s���܂��͏d��" & vbCrLf
            Else
                seen.Add historyID, True
            End If
            If Len(keyText) = 0 Or Not IsDate(historyData(r, 3)) Or _
               Len(CellText(historyData(r, 4))) = 0 Or _
               Len(CellText(historyData(r, 13))) = 0 Then _
                problems = problems & "�E���͔��f���� " & CStr(r + 1) & "�s: �K�{���s��" & vbCrLf
            If Not ReviewStoreStatusFits(sourceText, categoryText, statusText) Then _
                problems = problems & "�E���͔��f���� " & CStr(r + 1) & "�s: �V�m�F�󋵕s��" & vbCrLf
            If Len(CellText(historyData(r, 7))) > 0 And _
               Not IsAnalysisReviewStatus(CellText(historyData(r, 7))) Then _
                problems = problems & "�E���͔��f���� " & CStr(r + 1) & "�s: ���m�F�󋵕s��" & vbCrLf
            If Len(CellText(historyData(r, 11))) > 0 And _
               Not ReviewEvidenceDigestIsValid(CellText(historyData(r, 11))) Then _
                problems = problems & "�E���͔��f���� " & CStr(r + 1) & "�s: �����������s��" & vbCrLf
            If Len(CellText(historyData(r, 12))) > 0 And _
               Not ReviewEvidenceDigestIsValid(CellText(historyData(r, 12))) Then _
                problems = problems & "�E���͔��f���� " & CStr(r + 1) & "�s: �V���������s��" & vbCrLf
            If Len(problems) > 700000 Then Exit For
        Next r
    End If
    If includeInterfaceChecks Then
        If wsHistory.Visible <> xlSheetVeryHidden Then _
            interfaceWarnings = interfaceWarnings & "�E���͔��f������VeryHidden�ł͂���܂���" & vbCrLf
    End If
    ValidateAllocationLedgerForSave problems
End Sub

Private Function ReviewStoreStatusFits(ByVal sourceText As String, ByVal categoryText As String, _
                                       ByVal statusText As String) As Boolean
    Select Case sourceText
        Case SH_ANALYSIS_SHIFT, SH_ANALYSIS_FLOW
            Select Case statusText
                Case ANALYSIS_STATUS_UNREVIEWED, ANALYSIS_STATUS_SHIFT_CONFIRMED, _
                     ANALYSIS_STATUS_EXCLUDED, ANALYSIS_STATUS_FOLLOWUP
                    ReviewStoreStatusFits = True
            End Select
        Case SH_ANALYSIS_UNKNOWN
            If StrComp(categoryText, "�����s��", vbTextCompare) = 0 Then
                Select Case statusText
                    Case ANALYSIS_STATUS_UNREVIEWED, ANALYSIS_STATUS_SOURCE_CONFIRMED, _
                         ANALYSIS_STATUS_EXCLUDED, ANALYSIS_STATUS_FOLLOWUP
                        ReviewStoreStatusFits = True
                End Select
            ElseIf StrComp(categoryText, "�g�r�s��", vbTextCompare) = 0 Then
                Select Case statusText
                    Case ANALYSIS_STATUS_UNREVIEWED, ANALYSIS_STATUS_USE_CONFIRMED, _
                         ANALYSIS_STATUS_EXCLUDED, ANALYSIS_STATUS_FOLLOWUP
                        ReviewStoreStatusFits = True
                End Select
            End If
    End Select
End Function

Private Function ReviewEvidenceDigestIsValid(ByVal digestText As String) As Boolean
    Dim i As Long, characterText As String
    If Len(digestText) <> 17 Or Mid$(digestText, 9, 1) <> "-" Then Exit Function
    For i = 1 To Len(digestText)
        If i <> 9 Then
            characterText = UCase$(Mid$(digestText, i, 1))
            If InStr(1, "0123456789ABCDEF", characterText, vbBinaryCompare) = 0 Then Exit Function
        End If
    Next i
    ReviewEvidenceDigestIsValid = True
End Function

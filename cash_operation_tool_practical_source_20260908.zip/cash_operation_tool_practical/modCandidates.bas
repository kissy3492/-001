Attribute VB_Name = "modCandidates"
Option Explicit

Private mCandidateBatchDepth As Long
Private mCandidateBatchRows As Object
Private mCandidateBatchRelationshipByID As Object
Private mCandidateBatchPersonRowByNameID As Object
Private mCandidateBatchAssignedRowByIdentity As Object
Private mCandidateBatchAssignedIDByIdentity As Object
Private mCandidateBatchRegisteredIDByIdentity As Object
Private mCandidateBatchBlankRowByIdentity As Object
Private mCandidateBatchBlankRowByName As Object
Private mCandidateEditableThrough As Object
Private Const MAX_CANDIDATE_DATA_ROWS As Long = 100000
Private Const CANDIDATE_EDIT_BUFFER_ROWS As Long = 500
Private Const CANDIDATE_LOCK_BUFFER_ROWS As Long = 100
Private Const CANDIDATE_RECOVERY_HARD_BARRIER_ERROR As Long = _
    vbObjectError + 4499
Private Const CANDIDATE_RECOVERY_HARD_BARRIER_SOURCE As String = _
    "CandidateRecoveryFatal/"

Private Function CandidateProtectionMarkerName(ByVal sheetName As String) As String
    Select Case sheetName
        Case SH_BANK_CAND: CandidateProtectionMarkerName = "_cand_edit_bank"
        Case SH_BRANCH_CAND: CandidateProtectionMarkerName = "_cand_edit_branch"
        Case SH_PERSON_CAND: CandidateProtectionMarkerName = "_cand_edit_person"
        Case SH_ACCOUNT_TYPE: CandidateProtectionMarkerName = "_cand_edit_account_type"
        Case SH_TEKIYO: CandidateProtectionMarkerName = "_cand_edit_tekiyo"
    End Select
End Function

Private Function StoredCandidateEditableLastRow(ByVal ws As Worksheet) As Long
    'VBE��Reset���Ń��W���[���ϐ��������Ă��A�ȑO�J�����������܂Ŋm���ɍă��b�N�ł���悤
    '�u�b�N���̔�\�������璼�߂̕ی�͈͂𕜌�����B
    Dim markerName As String, refersText As String
    Dim markerValue As Double
    On Error GoTo MissingMarker
    If ws Is Nothing Then Exit Function
    markerName = CandidateProtectionMarkerName(ws.Name)
    If Len(markerName) = 0 Then Exit Function
    refersText = ThisWorkbook.Names(markerName).RefersTo
    If Left$(refersText, 1) = "=" Then refersText = Mid$(refersText, 2)
    If Not IsNumeric(refersText) Then Exit Function
    markerValue = CDbl(refersText)
    If markerValue <> Fix(markerValue) Then Exit Function
    If markerValue < 2 Or markerValue > MAX_CANDIDATE_DATA_ROWS + 1 Then Exit Function
    StoredCandidateEditableLastRow = CLng(markerValue)
MissingMarker:
End Function

Private Sub StoreCandidateEditableLastRow(ByVal ws As Worksheet, ByVal editableLastRow As Long)
    Dim markerName As String
    Dim marker As Name
    If ws Is Nothing Then Exit Sub
    markerName = CandidateProtectionMarkerName(ws.Name)
    If Len(markerName) = 0 Then Exit Sub
    On Error Resume Next
    Set marker = ThisWorkbook.Names(markerName)
    On Error GoTo 0
    If marker Is Nothing Then
        ThisWorkbook.Names.Add Name:=markerName, RefersTo:="=" & CStr(editableLastRow), Visible:=False
    Else
        marker.RefersTo = "=" & CStr(editableLastRow)
    End If
End Sub

Public Sub BeginCandidateBatchUpdate()
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim eventStateDetail As String
    On Error GoTo EH
    If mCandidateBatchDepth = 0 Then BuildCandidateBatchIndex
    mCandidateBatchDepth = mCandidateBatchDepth + 1
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    If IsCandidateRecoveryHardBarrier(errorNumber, errorSource) Then
        Call TryStopCandidateEventsForBookWrites(eventStateDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    mCandidateBatchDepth = 0
    ClearCandidateBatchIndexes
    If Len(errorSource) = 0 Then errorSource = "BeginCandidateBatchUpdate"
    Err.Raise errorNumber, errorSource, errorDescription
End Sub

Public Sub EndCandidateBatchUpdate()
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim eventStateDetail As String
    If mCandidateBatchDepth > 0 Then mCandidateBatchDepth = mCandidateBatchDepth - 1
    If mCandidateBatchDepth = 0 Then
        On Error GoTo CleanUp
        ConvergeCandidateBatchBlankRelationships
        RefreshAllCandidateNames
CleanUp:
        errorNumber = Err.Number
        errorDescription = Err.Description
        errorSource = Err.Source
        If errorNumber <> 0 Then
            If IsCandidateRecoveryHardBarrier(errorNumber, errorSource) Then
                Call TryStopCandidateEventsForBookWrites(eventStateDetail)
                Err.Raise errorNumber, errorSource, errorDescription
            End If
            ClearCandidateBatchIndexes
            If Len(errorSource) = 0 Then errorSource = "EndCandidateBatchUpdate"
            Err.Raise errorNumber, errorSource, errorDescription
        End If
        ClearCandidateBatchIndexes
    End If
End Sub

Private Sub ClearCandidateBatchIndexes()
    Set mCandidateBatchRows = Nothing
    Set mCandidateBatchRelationshipByID = Nothing
    Set mCandidateBatchPersonRowByNameID = Nothing
    Set mCandidateBatchAssignedRowByIdentity = Nothing
    Set mCandidateBatchAssignedIDByIdentity = Nothing
    Set mCandidateBatchRegisteredIDByIdentity = Nothing
    Set mCandidateBatchBlankRowByIdentity = Nothing
    Set mCandidateBatchBlankRowByName = Nothing
End Sub

Private Sub BuildCandidateBatchIndex()
    Set mCandidateBatchRows = CreateObject("Scripting.Dictionary")
    mCandidateBatchRows.CompareMode = vbTextCompare
    Set mCandidateBatchRelationshipByID = NewCandidateBatchDictionary()
    Set mCandidateBatchPersonRowByNameID = NewCandidateBatchDictionary()
    Set mCandidateBatchAssignedRowByIdentity = NewCandidateBatchDictionary()
    Set mCandidateBatchAssignedIDByIdentity = NewCandidateBatchDictionary()
    Set mCandidateBatchRegisteredIDByIdentity = NewCandidateBatchDictionary()
    Set mCandidateBatchBlankRowByIdentity = NewCandidateBatchDictionary()
    Set mCandidateBatchBlankRowByName = NewCandidateBatchDictionary()
    IndexCandidateSheet SH_BANK_CAND
    IndexCandidateSheet SH_BRANCH_CAND
    IndexCandidateSheet SH_PERSON_CAND
    IndexCandidateSheet SH_ACCOUNT_TYPE
    IndexCandidateSheet SH_TEKIYO
    IndexRegisteredPersonRelationships
End Sub

Private Function NewCandidateBatchDictionary() As Object
    Dim result As Object
    Set result = CreateObject("Scripting.Dictionary")
    result.CompareMode = vbTextCompare
    Set NewCandidateBatchDictionary = result
End Function

Private Sub IndexCandidateSheet(ByVal sheetName As String)
    Dim ws As Worksheet, lastR As Long, r As Long
    Dim valueText As String, keyText As String
    Dim candidateData As Variant
    If Not SheetExists(sheetName) Then Exit Sub
    Set ws = GetSheet(sheetName)
    lastR = LastRow(ws, 1)
    If lastR < 2 Then Exit Sub
    '���ʃf�[�^�捞�ł͍ő�10���s�����������邽�߁A�Z���P�ʂ�COM�ǎ�������B
    candidateData = ws.Range(ws.Cells(2, 1), ws.Cells(lastR, 4)).Value2
    For r = 1 To UBound(candidateData, 1)
        valueText = CellText(candidateData(r, 1))
        If Len(valueText) > 0 Then
            If sheetName = SH_PERSON_CAND Then
                keyText = CandidateBatchKey(sheetName, valueText, CellText(candidateData(r, 2)), _
                                            CellText(candidateData(r, 3)))
                IndexCandidateBatchPersonRow r + 1, valueText, CellText(candidateData(r, 2)), _
                                             CellText(candidateData(r, 3)), _
                                             sheetName & " " & CStr(r + 1) & "�s"
            Else
                keyText = CandidateBatchKey(sheetName, valueText)
            End If
            If Not mCandidateBatchRows.Exists(keyText) Then mCandidateBatchRows.Add keyText, r + 1
        End If
    Next r
End Sub

Private Sub IndexRegisteredPersonRelationships()
    Dim ws As Worksheet
    Dim lastR As Long, r As Long
    Dim sourceData As Variant
    Dim personID As String, personName As String, relationshipText As String
    If Not SheetExists(SH_WORK_ACCOUNT) Then Exit Sub
    Set ws = GetSheet(SH_WORK_ACCOUNT)
    lastR = LastDataRowInColumns(ws, ACC_COL_ID, ACC_COL_TRANSFER_ID)
    If lastR < 2 Then Exit Sub
    sourceData = ws.Range(ws.Cells(2, ACC_COL_PERSON), _
                          ws.Cells(lastR, ACC_COL_PERSON_ID)).Value2
    For r = 1 To UBound(sourceData, 1)
        personName = CellText(sourceData(r, 1))
        relationshipText = CellText( _
                               sourceData(r, ACC_COL_RELATIONSHIP - ACC_COL_PERSON + 1))
        personID = CellText( _
                       sourceData(r, ACC_COL_PERSON_ID - ACC_COL_PERSON + 1))
        AddCandidateBatchRelationship personID, relationshipText, _
                                      SH_WORK_ACCOUNT & " " & CStr(r + 1) & "�s"
        IndexCandidateBatchRegisteredIdentity personName, personID, relationshipText, _
                                              SH_WORK_ACCOUNT & " " & CStr(r + 1) & "�s"
    Next r
End Sub

Private Sub IndexCandidateBatchRegisteredIdentity( _
        ByVal personName As String, ByVal personID As String, _
        ByVal relationshipText As String, ByVal sourceText As String)
    Dim identityKey As String, existingID As String
    personID = CellText(personID)
    identityKey = PersonIdentityKey(personName, relationshipText)
    If Len(identityKey) = 0 Or Len(personID) = 0 Then Exit Sub
    If mCandidateBatchRegisteredIDByIdentity Is Nothing Then _
        Err.Raise vbObjectError + 2139, "BuildCandidateBatchIndex", _
                  "�o�^�ςݐl���̓��ꐫ�������쐬�ł��܂���B"
    If mCandidateBatchAssignedIDByIdentity.Exists(identityKey) Then
        existingID = CStr(mCandidateBatchAssignedIDByIdentity(identityKey))
        If StrComp(existingID, personID, vbTextCompare) <> 0 Then _
            Err.Raise vbObjectError + 2135, "BuildCandidateBatchIndex", _
                      "���������E�����ɈقȂ�l��ID������܂��i" & _
                      sourceText & "�j�B��ɃZ���t�`�F�b�N�����s���Ă��������B"
    End If
    If mCandidateBatchRegisteredIDByIdentity.Exists(identityKey) Then
        existingID = CStr(mCandidateBatchRegisteredIDByIdentity(identityKey))
        If StrComp(existingID, personID, vbTextCompare) <> 0 Then _
            Err.Raise vbObjectError + 2135, "BuildCandidateBatchIndex", _
                      "�o�^�ς݌����̓��������E�����ɈقȂ�l��ID������܂��i" & _
                      sourceText & "�j�B��ɃZ���t�`�F�b�N�����s���Ă��������B"
    Else
        mCandidateBatchRegisteredIDByIdentity.Add identityKey, personID
    End If
End Sub

Private Sub AddCandidateBatchRelationship(ByVal personID As String, _
                                          ByVal relationshipText As String, _
                                          ByVal sourceText As String)
    Dim relationshipKey As String, storedRelationship As String
    personID = CellText(personID)
    If Len(personID) = 0 Then Exit Sub
    If Not IsInternalIdValue(personID, "P") Then _
        Err.Raise vbObjectError + 2131, "BuildCandidateBatchIndex", _
                  "�l��ID�̌`�����s���ł��i" & sourceText & "�j: " & personID
    relationshipText = CellText(relationshipText)
    relationshipKey = NormalizeRelationshipKey(relationshipText)
    If Len(relationshipKey) = 0 Then Exit Sub
    If mCandidateBatchRelationshipByID.Exists(personID) Then
        storedRelationship = CStr(mCandidateBatchRelationshipByID(personID))
        If NormalizeRelationshipKey(storedRelationship) <> relationshipKey Then _
            Err.Raise vbObjectError + 2132, "BuildCandidateBatchIndex", _
                      "����l��ID�ɈقȂ鑱��������܂��i" & sourceText & "�j: " & personID
    Else
        mCandidateBatchRelationshipByID.Add personID, relationshipText
    End If
End Sub

Private Sub IndexCandidateBatchPersonRow(ByVal rowNo As Long, ByVal personName As String, _
                                         ByVal personID As String, ByVal relationshipText As String, _
                                         ByVal sourceText As String)
    Dim nameKey As String, nameIDKey As String, identityKey As String
    Dim storedRow As Long
    nameKey = NormalizePersonNameKey(personName)
    If Len(nameKey) = 0 Or rowNo < 2 Then Exit Sub
    personID = CellText(personID)
    identityKey = PersonIdentityKey(personName, relationshipText)
    If Len(personID) > 0 Then
        AddCandidateBatchRelationship personID, relationshipText, sourceText
        nameIDKey = nameKey & Chr$(29) & UCase$(personID)
        If mCandidateBatchPersonRowByNameID.Exists(nameIDKey) Then
            storedRow = CLng(mCandidateBatchPersonRowByNameID(nameIDKey))
            If rowNo < storedRow Then mCandidateBatchPersonRowByNameID(nameIDKey) = rowNo
        Else
            mCandidateBatchPersonRowByNameID.Add nameIDKey, rowNo
        End If
        If mCandidateBatchAssignedIDByIdentity.Exists(identityKey) Then
            If StrComp(CStr(mCandidateBatchAssignedIDByIdentity(identityKey)), _
                       personID, vbTextCompare) <> 0 Then _
                Err.Raise vbObjectError + 2135, "BuildCandidateBatchIndex", _
                          "���������E�����ɈقȂ�l��ID������܂��i" & _
                          sourceText & "�j�B��ɃZ���t�`�F�b�N�����s���Ă��������B"
            storedRow = CLng(mCandidateBatchAssignedRowByIdentity(identityKey))
            If rowNo < storedRow Then
                mCandidateBatchAssignedIDByIdentity(identityKey) = personID
                mCandidateBatchAssignedRowByIdentity(identityKey) = rowNo
            End If
        Else
            mCandidateBatchAssignedIDByIdentity.Add identityKey, personID
            mCandidateBatchAssignedRowByIdentity.Add identityKey, rowNo
        End If
    Else
        AddCandidateBatchQueuedRow mCandidateBatchBlankRowByIdentity, identityKey, rowNo
        If Len(NormalizeRelationshipKey(relationshipText)) = 0 Then
            AddCandidateBatchQueuedRow mCandidateBatchBlankRowByName, nameKey, rowNo
        End If
    End If
End Sub

Private Sub AddCandidateBatchQueuedRow(ByVal queueIndex As Object, ByVal keyText As String, _
                                       ByVal rowNo As Long)
    Dim queuedRows As Collection
    If queueIndex Is Nothing Or Len(keyText) = 0 Or rowNo < 2 Then Exit Sub
    If queueIndex.Exists(keyText) Then
        Set queuedRows = queueIndex(keyText)
    Else
        Set queuedRows = New Collection
        queueIndex.Add keyText, queuedRows
    End If
    queuedRows.Add rowNo
End Sub

Private Function CandidateBatchFirstQueuedRow(ByVal queueIndex As Object, _
                                              ByVal keyText As String) As Long
    Dim queuedRows As Collection
    If queueIndex Is Nothing Or Len(keyText) = 0 Then Exit Function
    If Not queueIndex.Exists(keyText) Then Exit Function
    Set queuedRows = queueIndex(keyText)
    If queuedRows.Count > 0 Then CandidateBatchFirstQueuedRow = CLng(queuedRows(1))
End Function

Private Sub RemoveCandidateBatchQueuedHead(ByVal queueIndex As Object, ByVal keyText As String, _
                                           ByVal rowNo As Long)
    Dim queuedRows As Collection
    If queueIndex Is Nothing Or Len(keyText) = 0 Or rowNo < 2 Then Exit Sub
    If Not queueIndex.Exists(keyText) Then Exit Sub
    Set queuedRows = queueIndex(keyText)
    If queuedRows.Count > 0 Then
        If CLng(queuedRows(1)) = rowNo Then queuedRows.Remove 1
    End If
    If queuedRows.Count = 0 Then queueIndex.Remove keyText
End Sub

Private Function ValidatedBatchRelationshipForPersonID(ByVal personID As String, _
                                                        ByVal requestedRelationship As String) As String
    Dim storedRelationship As String
    Dim storedKey As String, requestedKey As String
    personID = CellText(personID)
    requestedRelationship = CellText(requestedRelationship)
    If Len(personID) = 0 Then
        ValidatedBatchRelationshipForPersonID = requestedRelationship
        Exit Function
    End If
    If Not IsInternalIdValue(personID, "P") Then _
        Err.Raise vbObjectError + 2133, "ValidatedBatchRelationshipForPersonID", _
                  "�l��ID�̌`�����s���ł�: " & personID
    requestedKey = NormalizeRelationshipKey(requestedRelationship)
    If mCandidateBatchRelationshipByID.Exists(personID) Then
        storedRelationship = CStr(mCandidateBatchRelationshipByID(personID))
        storedKey = NormalizeRelationshipKey(storedRelationship)
        If Len(requestedKey) > 0 And requestedKey <> storedKey Then _
            Err.Raise vbObjectError + 2134, "ValidatedBatchRelationshipForPersonID", _
                      "����l��ID�̑������������܂��͓o�^�ς݌����ƈ�v���܂���: " & personID
        If Len(requestedKey) = 0 Then
            ValidatedBatchRelationshipForPersonID = storedRelationship
        Else
            ValidatedBatchRelationshipForPersonID = requestedRelationship
        End If
    Else
        ValidatedBatchRelationshipForPersonID = requestedRelationship
    End If
End Function

Private Function EarlierCandidateBatchRow(ByVal currentRow As Long, ByVal candidateRow As Long) As Long
    If candidateRow < 2 Then
        EarlierCandidateBatchRow = currentRow
    ElseIf currentRow < 2 Or candidateRow < currentRow Then
        EarlierCandidateBatchRow = candidateRow
    Else
        EarlierCandidateBatchRow = currentRow
    End If
End Function

Private Function CandidateBatchMappedRow(ByVal rowIndex As Object, ByVal keyText As String) As Long
    If rowIndex Is Nothing Or Len(keyText) = 0 Then Exit Function
    If Not rowIndex.Exists(keyText) Then Exit Function
    If IsNumeric(rowIndex(keyText)) Then CandidateBatchMappedRow = CLng(rowIndex(keyText))
End Function

Private Function FindCandidateBatchPersonRow(ByVal ws As Worksheet, ByVal personName As String, _
                                             ByVal personID As String, ByVal relationshipText As String, _
                                             ByRef conflictingPersonID As String) As Long
    Dim rowNo As Long, matchedRow As Long, conflictRow As Long
    Dim nameKey As String, nameIDKey As String, identityKey As String
    Dim storedID As String, storedRelationship As String
    If ws Is Nothing Then Exit Function
    nameKey = NormalizePersonNameKey(personName)
    identityKey = PersonIdentityKey(personName, relationshipText)
    personID = CellText(personID)

    If Len(personID) > 0 Then
        nameIDKey = nameKey & Chr$(29) & UCase$(personID)
        rowNo = CandidateBatchMappedRow(mCandidateBatchPersonRowByNameID, nameIDKey)
        If rowNo >= 2 Then
            If NormalizePersonNameKey(CellText(ws.Cells(rowNo, 1).Value)) = nameKey And _
               StrComp(CellText(ws.Cells(rowNo, 2).Value), personID, vbTextCompare) = 0 Then
                matchedRow = EarlierCandidateBatchRow(matchedRow, rowNo)
            Else
                mCandidateBatchPersonRowByNameID.Remove nameIDKey
            End If
        End If

        rowNo = CandidateBatchFirstQueuedRow(mCandidateBatchBlankRowByIdentity, identityKey)
        If rowNo >= 2 Then
            storedID = CellText(ws.Cells(rowNo, 2).Value)
            storedRelationship = CellText(ws.Cells(rowNo, 3).Value)
            If Len(storedID) = 0 And _
               PersonIdentityKey(CellText(ws.Cells(rowNo, 1).Value), storedRelationship) = identityKey Then
                matchedRow = EarlierCandidateBatchRow(matchedRow, rowNo)
            Else
                RemoveCandidateBatchQueuedHead mCandidateBatchBlankRowByIdentity, identityKey, rowNo
            End If
        End If

        If mCandidateBatchAssignedIDByIdentity.Exists(identityKey) Then
            storedID = CStr(mCandidateBatchAssignedIDByIdentity(identityKey))
            If StrComp(storedID, personID, vbTextCompare) <> 0 Then
                conflictRow = CandidateBatchMappedRow(mCandidateBatchAssignedRowByIdentity, identityKey)
                If matchedRow < 2 Or (conflictRow >= 2 And conflictRow < matchedRow) Then
                    conflictingPersonID = storedID
                    Exit Function
                End If
            End If
        End If
        '�o�b�`�J�n���ɍ����������o�^�ς݌����Ƃ��A���V�[�g�֐G��O�ɏƍ�����B
        '�O���̎捞��������őS�̌������邱�Ƃɂ͈ˑ������A���J���API�P�̂�
        '���������{������ʂ̐l��ID�֕��򂳂��Ȃ��B
        If Not mCandidateBatchRegisteredIDByIdentity Is Nothing Then
            If mCandidateBatchRegisteredIDByIdentity.Exists(identityKey) Then
                storedID = CStr(mCandidateBatchRegisteredIDByIdentity(identityKey))
                If StrComp(storedID, personID, vbTextCompare) <> 0 Then
                    conflictingPersonID = storedID
                    Exit Function
                End If
            End If
        End If
        FindCandidateBatchPersonRow = matchedRow
    Else
        rowNo = CandidateBatchMappedRow(mCandidateBatchAssignedRowByIdentity, identityKey)
        If rowNo >= 2 Then
            If PersonIdentityKey(CellText(ws.Cells(rowNo, 1).Value), _
                                 CellText(ws.Cells(rowNo, 3).Value)) = identityKey Then
                matchedRow = EarlierCandidateBatchRow(matchedRow, rowNo)
            Else
                mCandidateBatchAssignedRowByIdentity.Remove identityKey
            End If
        End If
        rowNo = CandidateBatchFirstQueuedRow(mCandidateBatchBlankRowByIdentity, identityKey)
        If rowNo >= 2 Then
            If Len(CellText(ws.Cells(rowNo, 2).Value)) = 0 And _
               PersonIdentityKey(CellText(ws.Cells(rowNo, 1).Value), _
                                 CellText(ws.Cells(rowNo, 3).Value)) = identityKey Then
                matchedRow = EarlierCandidateBatchRow(matchedRow, rowNo)
            Else
                RemoveCandidateBatchQueuedHead mCandidateBatchBlankRowByIdentity, identityKey, rowNo
            End If
        End If
        FindCandidateBatchPersonRow = matchedRow
    End If
End Function

Private Sub RemoveCandidateBatchMappedRow(ByVal rowIndex As Object, ByVal keyText As String, _
                                          ByVal rowNo As Long)
    If rowIndex Is Nothing Or Len(keyText) = 0 Or rowNo < 2 Then Exit Sub
    If Not rowIndex.Exists(keyText) Then Exit Sub
    If IsNumeric(rowIndex(keyText)) Then
        If CLng(rowIndex(keyText)) = rowNo Then rowIndex.Remove keyText
    End If
End Sub

Private Sub UnindexCandidateBatchPersonRow(ByVal rowNo As Long, ByVal personName As String, _
                                           ByVal personID As String, ByVal relationshipText As String)
    Dim nameKey As String, nameIDKey As String, identityKey As String
    If rowNo < 2 Then Exit Sub
    nameKey = NormalizePersonNameKey(personName)
    If Len(nameKey) = 0 Then Exit Sub
    personID = CellText(personID)
    identityKey = PersonIdentityKey(personName, relationshipText)
    If Len(personID) > 0 Then
        nameIDKey = nameKey & Chr$(29) & UCase$(personID)
        RemoveCandidateBatchMappedRow mCandidateBatchPersonRowByNameID, nameIDKey, rowNo
        If CandidateBatchMappedRow(mCandidateBatchAssignedRowByIdentity, identityKey) = rowNo Then
            mCandidateBatchAssignedRowByIdentity.Remove identityKey
            If mCandidateBatchAssignedIDByIdentity.Exists(identityKey) Then _
                mCandidateBatchAssignedIDByIdentity.Remove identityKey
        End If
    Else
        RemoveCandidateBatchQueuedHead mCandidateBatchBlankRowByIdentity, identityKey, rowNo
        If Len(NormalizeRelationshipKey(relationshipText)) = 0 Then _
            RemoveCandidateBatchQueuedHead mCandidateBatchBlankRowByName, nameKey, rowNo
    End If
End Sub

Private Sub ConvergeCandidateBatchBlankRelationships()
    Dim ws As Worksheet
    Dim lastR As Long, r As Long
    Dim sourceData As Variant, relationshipData As Variant
    Dim personID As String, personName As String, relationshipText As String
    Dim identityKey As String, conflictingPersonID As String
    Dim stagedIDByIdentity As Object
    Dim changed As Boolean
    If mCandidateBatchRelationshipByID Is Nothing Then Exit Sub
    If Not SheetExists(SH_PERSON_CAND) Then Exit Sub
    Set ws = GetSheet(SH_PERSON_CAND)
    lastR = LastDataRowInColumns(ws, 1, 4)
    If lastR < 2 Then Exit Sub
    '����p��A:C�͈�x�����z��֓ǂ݁A���߂��͕ύX�Ώۂ̑���C�񂾂��Ɍ��肷��B
    '���֌W�Ȏ����E�l��ID����đ�������A10���s�ł��Z���P��COM�X�V�������B
    sourceData = ws.Range(ws.Cells(2, 1), ws.Cells(lastR, 3)).Value2
    '1�s������Range.Value2�͔z��łȂ�Scalar��Ԃ����߁A��ɓ񎟌��z������B
    ReDim relationshipData(1 To lastR - 1, 1 To 1)
    For r = 1 To UBound(sourceData, 1)
        relationshipData(r, 1) = sourceData(r, 3)
    Next r
    Set stagedIDByIdentity = NewCandidateBatchDictionary()
    For r = 1 To UBound(sourceData, 1)
        personName = CellText(sourceData(r, 1))
        personID = CellText(sourceData(r, 2))
        If Len(personID) > 0 And _
           Len(NormalizeRelationshipKey(CellText(sourceData(r, 3)))) = 0 Then
            If mCandidateBatchRelationshipByID.Exists(personID) Then
                relationshipText = CStr(mCandidateBatchRelationshipByID(personID))
                If Len(NormalizeRelationshipKey(relationshipText)) > 0 Then
                    identityKey = PersonIdentityKey(personName, relationshipText)
                    conflictingPersonID = CandidateBatchConvergenceConflictID( _
                                              identityKey, personID, stagedIDByIdentity)
                    If Len(conflictingPersonID) > 0 Then _
                        Err.Raise vbObjectError + 2140, _
                                  "ConvergeCandidateBatchBlankRelationships", _
                                  "�����⊮��ɓ��������E�����ֈقȂ�l��ID�������܂��B" & _
                                  "�l�������C�����Ă���Ď��s���Ă�������: " & _
                                  personName & "�i�⊮�Ώ�=" & personID & _
                                  " / ����=" & conflictingPersonID & "�j"
                    If Not stagedIDByIdentity.Exists(identityKey) Then _
                        stagedIDByIdentity.Add identityKey, personID
                    relationshipData(r, 1) = relationshipText
                    changed = True
                End If
            End If
        End If
    Next r
    If changed Then _
        ws.Range(ws.Cells(2, 3), ws.Cells(lastR, 3)).Value2 = relationshipData
End Sub

Private Function CandidateBatchConvergenceConflictID( _
        ByVal identityKey As String, ByVal allowedPersonID As String, _
        ByVal stagedIDByIdentity As Object) As String
    Dim existingID As String
    If Len(identityKey) = 0 Then Exit Function
    If Not mCandidateBatchAssignedIDByIdentity Is Nothing Then
        If mCandidateBatchAssignedIDByIdentity.Exists(identityKey) Then
            existingID = CStr(mCandidateBatchAssignedIDByIdentity(identityKey))
            If StrComp(existingID, allowedPersonID, vbTextCompare) <> 0 Then
                CandidateBatchConvergenceConflictID = existingID
                Exit Function
            End If
        End If
    End If
    If Not mCandidateBatchRegisteredIDByIdentity Is Nothing Then
        If mCandidateBatchRegisteredIDByIdentity.Exists(identityKey) Then
            existingID = CStr(mCandidateBatchRegisteredIDByIdentity(identityKey))
            If StrComp(existingID, allowedPersonID, vbTextCompare) <> 0 Then
                CandidateBatchConvergenceConflictID = existingID
                Exit Function
            End If
        End If
    End If
    If Not stagedIDByIdentity Is Nothing Then
        If stagedIDByIdentity.Exists(identityKey) Then
            existingID = CStr(stagedIDByIdentity(identityKey))
            If StrComp(existingID, allowedPersonID, vbTextCompare) <> 0 Then _
                CandidateBatchConvergenceConflictID = existingID
        End If
    End If
End Function

Public Function CandidateRelationshipConvergenceRegressionTest() As Boolean
    Dim stagedIDByIdentity As Object
    Dim identityKey As String
    On Error GoTo Failed
    If mCandidateBatchDepth <> 0 Then Exit Function
    ClearCandidateBatchIndexes
    Set mCandidateBatchAssignedIDByIdentity = NewCandidateBatchDictionary()
    Set mCandidateBatchRegisteredIDByIdentity = NewCandidateBatchDictionary()
    Set stagedIDByIdentity = NewCandidateBatchDictionary()

    identityKey = PersonIdentityKey("Alice", "�z���")
    mCandidateBatchAssignedIDByIdentity.Add identityKey, "P2"
    If StrComp(CandidateBatchConvergenceConflictID( _
                   identityKey, "P1", stagedIDByIdentity), _
               "P2", vbBinaryCompare) <> 0 Then GoTo Failed

    identityKey = PersonIdentityKey("Bob", "�z���")
    mCandidateBatchRegisteredIDByIdentity.Add identityKey, "P3"
    If StrComp(CandidateBatchConvergenceConflictID( _
                   identityKey, "P1", stagedIDByIdentity), _
               "P3", vbBinaryCompare) <> 0 Then GoTo Failed

    identityKey = PersonIdentityKey("Carol", "�z���")
    stagedIDByIdentity.Add identityKey, "P4"
    If StrComp(CandidateBatchConvergenceConflictID( _
                   identityKey, "P5", stagedIDByIdentity), _
               "P4", vbBinaryCompare) <> 0 Then GoTo Failed
    If Len(CandidateBatchConvergenceConflictID( _
               identityKey, "P4", stagedIDByIdentity)) <> 0 Then GoTo Failed

    'P1/�󗓂�P2/�󗓂𓯂������{�����֓����⊮���鏫����Ԃ����ۂ���B
    identityKey = PersonIdentityKey("�����⊮", "�{�l")
    stagedIDByIdentity.RemoveAll
    stagedIDByIdentity.Add identityKey, "P1"
    If StrComp(CandidateBatchConvergenceConflictID( _
                   identityKey, "P2", stagedIDByIdentity), _
               "P1", vbBinaryCompare) <> 0 Then GoTo Failed

    ClearCandidateBatchIndexes
    CandidateRelationshipConvergenceRegressionTest = True
    Exit Function
Failed:
    ClearCandidateBatchIndexes
    CandidateRelationshipConvergenceRegressionTest = False
End Function

Private Function CandidateBatchKey(ByVal sheetName As String, ByVal valueText As String, _
                                   Optional ByVal personID As String = "", _
                                   Optional ByVal relationshipText As String = "") As String
    If sheetName = SH_PERSON_CAND Then
        valueText = NormalizePersonNameKey(valueText) & Chr$(29) & UCase$(Trim$(CellText(personID))) & _
                    Chr$(29) & NormalizeRelationshipKey(relationshipText)
    Else
        valueText = Trim$(CellText(valueText))
    End If
    CandidateBatchKey = sheetName & Chr$(29) & valueText
End Function

Public Sub BuildCandidateSheets(Optional ByVal resetContents As Boolean = False)
    SetupCandidateSheet SH_BANK_CAND, "��s�����", NM_LST_BANK_CAND, resetContents
    SetupCandidateSheet SH_BRANCH_CAND, "�x�X�����", NM_LST_BRANCH_CAND, resetContents
    SetupCandidateSheet SH_PERSON_CAND, "�l�����", NM_LST_PERSON_CAND, resetContents
End Sub

Public Sub ShowBankCandidates()
    ShowCandidateSheet SH_BANK_CAND
End Sub

Public Sub ShowBranchCandidates()
    ShowCandidateSheet SH_BRANCH_CAND
End Sub

Public Sub ShowPersonCandidates()
    ShowCandidateSheet SH_PERSON_CAND
End Sub

Public Sub ShowAccountTypeCandidates()
    ShowCandidateSheet SH_ACCOUNT_TYPE
End Sub

Public Sub ShowTekiyoCandidates()
    ShowCandidateSheet SH_TEKIYO
End Sub

Public Sub ShowCandidateSheet(ByVal sheetName As String)
    Dim ws As Worksheet
    Dim names As Variant, item As Variant
    Dim previousEvents As Boolean, eventsCaptured As Boolean
    Dim eventsReadyForBookWrites As Boolean
    Dim sheetWritesStarted As Boolean, displayCompleted As Boolean
    Dim recoveryStateConfirmed As Boolean, safeToRestoreEntry As Boolean
    Dim applicationStateSafe As Boolean
    Dim eventRestoreSucceeded As Boolean
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim protectErrorNumber As Long, protectErrorDescription As String
    Dim protectErrorSource As String
    Dim protectReadErrorNumber As Long, protectReadErrorDescription As String
    Dim recoveryErrorNumber As Long, recoveryErrorDescription As String
    Dim recoveryErrorSource As String
    Dim eventStateDetail As String, eventRestoreDetail As String
    Dim postRecoveryStopDetail As String
    Dim recoveryDetail As String
    Dim applicationStateProblems As String
    Dim protectionConfirmed As Boolean
    If Not IsCandidateSheetName(sheetName) Then _
        Err.Raise vbObjectError + 2120, "ShowCandidateSheet", "���V�[�g�����s���ł�: " & sheetName
    On Error GoTo EH
    '�\���E�����E�}�`�E�ی�E�����^�u�̔�\������̃C�x���g���[�X�ŕ�ށB
    '������ProtectCandidateSheet�ɂ�False�������n���AFalse�̂܂ܕԂ�����B
    If Not TryGetCandidateEnableEvents(previousEvents, eventStateDetail) Then
        errorNumber = vbObjectError + 2151
        errorDescription = _
            "���\���̊J�n����Excel�C�x���g��Ԃ��擾�ł��܂���ł����B " & _
            eventStateDetail
        Call StopAfterCandidateEventStateFailure( _
                 "ShowCandidateSheet/�J�n��Ԏ擾", errorDescription)
        GoTo ReportFailureWithoutEntryState
    End If
    eventsCaptured = True
    If Not TryStopCandidateEventsForBookWrites(eventStateDetail) Then
        errorNumber = vbObjectError + 2152
        errorDescription = _
            "���\���O��Excel�C�x���g���~���ēǖ߂��m�F�ł��܂���ł����B " & _
            eventStateDetail & _
            " �u�b�N�̕\���E�����E�}�`�E�ی�͕ύX���Ă��܂���B"
        GoTo RestoreEntryEventsAndReport
    End If
    eventsReadyForBookWrites = True
    If Not RequireToolReady() Then GoTo SafeExit
    Set ws = GetSheet(sheetName)
    If Not TryStopCandidateEventsForBookWrites(eventStateDetail) Then _
        Err.Raise vbObjectError + 2154, "ShowCandidateSheet", _
                  "���V�[�g�����ݒ��O��Excel�C�x���g��False���m�F�ł��܂���ł����B " & _
                  eventStateDetail
    sheetWritesStarted = True
    ws.Visible = xlSheetVisible
    ws.Unprotect Password:=TOOL_PASSWORD
    FormatCandidateSheetForEditing ws
    BuildCandidateNavigationPanel ws
    ProtectCandidateSheet ws, True
    If Not TryStopCandidateEventsForBookWrites(eventStateDetail) Then _
        Err.Raise vbObjectError + 2155, "ShowCandidateSheet", _
                  "���V�[�g�ی���Excel�C�x���g��False���m�F�ł��܂���ł����B " & _
                  eventStateDetail
    ws.Activate
    ApplyActiveSheetWindowStyle ws
    SafeFreezeSheetAt ws, "A2", 95
    ws.Activate
    If Not ThisWorkbook.ReadOnly And _
       Not (ws.Name = SH_PERSON_CAND And _
            (IsEditMode() Or CurrentAccountInputHasData())) Then ws.Range("A2").Select

    '���^�u��5�������ɕ��ׂȂ��B�����Ă����ނ�����\�����A�ؑւ͉E���p�l���֏W�񂷂�B
    names = CandidateSheetNames()
    For Each item In names
        If CStr(item) <> sheetName Then HideSheetIfExists CStr(item)
    Next item
    displayCompleted = True
SafeExit:
    '�J�n�l�̕������A���̃��[�`���ɂ�����Ō��Excel��ԑ���ɂ���B
    If eventsCaptured Then
        If Not TryRestoreCandidateEnableEvents( _
                   previousEvents, "ShowCandidateSheet/����I��", _
                   eventRestoreDetail) Then
            eventsCaptured = False
            errorNumber = vbObjectError + 2153
            If displayCompleted Then
                errorDescription = _
                    "���͌��̕\���͊������܂������AExcel�C�x���g��Ԃ��J�n�l��" & _
                    "�����ł��܂���ł����B " & eventRestoreDetail
            Else
                errorDescription = _
                    "���\���̎��O�m�F�I����ɁAExcel�C�x���g��Ԃ��J�n�l��" & _
                    "�����ł��܂���ł����B " & eventRestoreDetail
            End If
            On Error GoTo 0
            GoTo ReportFailure
        End If
        eventsCaptured = False
    End If
    Exit Sub
EH:
    errorNumber = Err.Number
    errorSource = Err.Source
    errorDescription = Err.Description
    If IsCandidateRecoveryHardBarrier(errorNumber, errorSource) Then
        Call TryStopCandidateEventsForBookWrites(eventStateDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    If errorNumber = 0 Then errorNumber = vbObjectError + 2156
    If Len(errorDescription) = 0 Then _
        errorDescription = "���V�[�g�̕\���������Ɍ����s���̃G���[���������܂����B"
    On Error Resume Next
    Err.Clear
    '�ُ�I�������AFalse�̓ǖ߂������Ȃ�����V�[�g�ERecovery�E�f�f�֐G��Ȃ��B
    eventsReadyForBookWrites = _
        TryStopCandidateEventsForBookWrites(eventStateDetail)
    If Not eventsReadyForBookWrites Then
        AppendCandidateSafetyDetail errorDescription, _
            "�ُ�I�����Excel�C�x���g��False�֒�~���ēǖ߂��m�F�ł��Ȃ����߁A" & _
            "���V�[�g�ĕی�ƃu�b�N�ւ̕����L�^��������܂���: " & _
            eventStateDetail
        GoTo RestoreEntryEventsAndReport
    End If
    If sheetWritesStarted And Not ws Is Nothing Then
        ProtectCandidateSheet ws, True
        protectErrorNumber = Err.Number
        protectErrorDescription = Err.Description
        protectErrorSource = Err.Source
        Err.Clear
        If IsCandidateRecoveryHardBarrier( _
               protectErrorNumber, protectErrorSource) Then
            Call TryStopCandidateEventsForBookWrites(eventStateDetail)
            On Error GoTo 0
            Err.Raise protectErrorNumber, protectErrorSource, _
                      protectErrorDescription
        End If
        eventsReadyForBookWrites = _
            TryStopCandidateEventsForBookWrites(eventStateDetail)
        If Not eventsReadyForBookWrites Then
            AppendCandidateSafetyDetail errorDescription, _
                "���V�[�g�ĕی���Excel�C�x���g��False���m�F�ł��Ȃ����߁A" & _
                "�ی�ǖ߂��ƃu�b�N�ւ̕����L�^��������܂���: " & _
                eventStateDetail
            GoTo RestoreEntryEventsAndReport
        End If
        protectionConfirmed = ws.ProtectContents And ws.ProtectDrawingObjects
        protectReadErrorNumber = Err.Number
        protectReadErrorDescription = Err.Description
        Err.Clear
        If protectErrorNumber <> 0 Or protectReadErrorNumber <> 0 Or _
           Not protectionConfirmed Then
            AppendCandidateSafetyDetail errorDescription, _
                "���V�[�g�ĕی����ӂɊm�F�ł��܂���" & _
                IIf(protectErrorNumber <> 0, _
                    ": Err " & CStr(protectErrorNumber) & " " & _
                    protectErrorDescription, vbNullString) & _
                IIf(protectReadErrorNumber <> 0, _
                    " / �ی�ǖ߂� Err " & CStr(protectReadErrorNumber) & _
                    " " & protectReadErrorDescription, vbNullString)
        Else
            AppendCandidateSafetyDetail errorDescription, _
                "���V�[�g�͍ĕی�Ɠǖ߂��m�F���������܂����B"
        End If
    End If
    If sheetWritesStarted Then
        recoveryDetail = _
            "���\�������������I�Ɏ��s���܂���: " & errorDescription
        postRecoveryStopDetail = vbNullString
        recoveryStateConfirmed = _
            TryEnterCandidateRecoveryStateExact( _
                recoveryDetail, postRecoveryStopDetail)
        recoveryErrorNumber = Err.Number
        recoveryErrorSource = Err.Source
        recoveryErrorDescription = Err.Description
        Err.Clear
        If IsCandidateRecoveryHardBarrier( _
               recoveryErrorNumber, recoveryErrorSource) Then
            Call TryStopCandidateEventsForBookWrites(eventStateDetail)
            On Error GoTo 0
            Err.Raise recoveryErrorNumber, recoveryErrorSource, _
                      recoveryErrorDescription
        End If
        eventsReadyForBookWrites = recoveryStateConfirmed
        If recoveryStateConfirmed Then
            On Error Resume Next
            AddCheck "�G���[", "���\���̕������s", recoveryDetail
            SetInputStatus _
                "���͌��̕\���������r���Ŏ��s�������߁A�Č���v�����Ƃ��Ē�~���܂����B" & _
                "���݂̃u�b�N���㏑�����Ȃ��ł��������B", True
            Err.Clear
            On Error GoTo 0
            postRecoveryStopDetail = vbNullString
            eventsReadyForBookWrites = _
                TryStopCandidateEventsForBookWrites(postRecoveryStopDetail)
            If eventsReadyForBookWrites Then
                recoveryStateConfirmed = _
                    TryConfirmCandidateRecoveryState(recoveryDetail)
            Else
                recoveryStateConfirmed = False
            End If
        Else
            AppendCandidateSafetyDetail recoveryDetail, _
                "Recovery����ӂɊm�F�ł��Ȃ����߁A�f�f�E��ԕ\�����s���܂���: " & _
                postRecoveryStopDetail
            eventStateDetail = vbNullString
            eventsReadyForBookWrites = _
                TryStopCandidateEventsForBookWrites(eventStateDetail)
        End If
        AppendCandidateSafetyDetail errorDescription, recoveryDetail
    End If
RestoreEntryEventsAndReport:
    '���̃��x���ȍ~�̓u�b�N�֏������܂Ȃ��B�J�n�l������K���Ō�ɍs���B
    safeToRestoreEntry = Not previousEvents
    If previousEvents Then
        If Not sheetWritesStarted Then
            safeToRestoreEntry = True
        ElseIf eventsReadyForBookWrites And recoveryStateConfirmed Then
            applicationStateProblems = vbNullString
            applicationStateSafe = _
                AppStateIsRestored(applicationStateProblems)
            safeToRestoreEntry = applicationStateSafe
            If Not applicationStateSafe Then _
                AppendCandidateSafetyDetail errorDescription, _
                    "�J�n�lTrue�ւ̕����O��Application��Ԃ��m�F�ł��܂���: " & _
                    applicationStateProblems
        End If
    End If
    If eventsCaptured Then
        If safeToRestoreEntry Then
            eventRestoreSucceeded = _
                TryRestoreCandidateEnableEvents( _
                    previousEvents, "ShowCandidateSheet/�ُ�I��", _
                    eventRestoreDetail)
            recoveryErrorNumber = Err.Number
            recoveryErrorSource = Err.Source
            recoveryErrorDescription = Err.Description
            Err.Clear
            If IsCandidateRecoveryHardBarrier( _
                   recoveryErrorNumber, recoveryErrorSource) Then
                Call TryStopCandidateEventsForBookWrites(eventStateDetail)
                On Error GoTo 0
                Err.Raise recoveryErrorNumber, recoveryErrorSource, _
                          recoveryErrorDescription
            End If
            If Not eventRestoreSucceeded Then _
                AppendCandidateSafetyDetail errorDescription, _
                    "Excel�C�x���g��Ԃ̕����G���[: " & eventRestoreDetail
        Else
            eventStateDetail = vbNullString
            If TryStopCandidateEventsForBookWrites(eventStateDetail) Then
                AppendCandidateSafetyDetail errorDescription, _
                    "���[���o�b�N�E�ی�܂��͗v�����̊m�����������Ȃ����߁A" & _
                    "�J�n�l�ւ̕����������s�킸Excel�C�x���g��False�ɕێ����܂����B"
            Else
                AppendCandidateSafetyDetail errorDescription, _
                    "Excel�C�x���g��False�������m�F�ł����A�Č��̈��S��Ԃ͕s���ł�: " & _
                    eventStateDetail
            End If
        End If
        eventsCaptured = False
    End If
    On Error GoTo 0
ReportFailure:
    MsgBox "���͌���\���ł��܂���ł����B" & vbCrLf & _
           "Err " & errorNumber & ": " & errorDescription, vbExclamation
    Exit Sub
ReportFailureWithoutEntryState:
    '�J�n��Ԃ��擾�ł��Ȃ������ꍇ�́AStopAfter...��False���m�F�ł���������
    'Recovery�E�f�f�֏������݁A�m�F�ł��Ȃ���΃u�b�N����ؕύX���Ȃ��B
    On Error GoTo 0
    GoTo ReportFailure
End Sub

Public Sub OnCandidateSheetChange(ByVal ws As Worksheet, ByVal Target As Range)
    Dim affected As Range, identityAffected As Range, cell As Range
    Dim snapshotRange As Range
    Dim candidateSnapshot As Variant, candidateMergeSignature As String
    Dim previousEvents As Boolean
    Dim firstStyleRow As Long, lastStyleRow As Long
    Dim snapshotLastRow As Long, currentLastRow As Long
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim restoreErrorNumber As Long, restoreErrorDescription As String
    Dim restoreErrorSource As String, eventStateDetail As String
    Dim eventRestoreDetail As String, postRecoveryStopDetail As String
    Dim recoveryDetail As String, restoreDetail As String
    Dim snapshotCaptured As Boolean, postProcessStarted As Boolean, rollbackFailed As Boolean
    Dim eventsCaptured As Boolean, eventsReadyForRecovery As Boolean
    Dim eventRecoveryEnforced As Boolean
    Dim recoveryStateConfirmed As Boolean, protectionConfirmed As Boolean
    Dim safeToRestoreEntry As Boolean
    Dim applicationStateSafe As Boolean, applicationStateProblems As String
    Dim recoveryErrorNumber As Long, recoveryErrorDescription As String
    Dim recoveryErrorSource As String
    Dim protectionReadErrorNumber As Long, protectionReadErrorDescription As String
    Dim blockIdentityEdit As Boolean, blockMessage As String
    If ws Is Nothing Or Target Is Nothing Then Exit Sub
    If Not IsCandidateSheetName(ws.Name) Then Exit Sub
    Set affected = Intersect(Target, ws.Range("A2:D" & CStr(ws.Rows.Count)))
    If affected Is Nothing Then Exit Sub
    If Not TryGetCandidateEnableEvents(previousEvents, eventStateDetail) Then
        StopAfterCandidateEventStateFailure _
            "OnCandidateSheetChange/�J�n��Ԏ擾", eventStateDetail
        Err.Raise vbObjectError + 2141, "OnCandidateSheetChange", _
                  "Excel�C�x���g�̊J�n��Ԃ��擾�ł��܂���ł����B " & eventStateDetail
    End If
    eventsCaptured = True
    '������ʂ͓Ǎ����_�̐l��������ێ����Ă���B�������ɐl�����̎����E������
    '��ɕς���ƁA��̒����ۑ����Â��l�Ō��������߂����ߕύX���̂������Ȃ��B
    If ws.Name = SH_PERSON_CAND Then
        Set identityAffected = Intersect(affected, Union(ws.Columns(1), ws.Columns(3)))
        If Not identityAffected Is Nothing Then
            If IsEditMode() Or CurrentAccountInputHasData() Then
                blockIdentityEdit = True
                blockMessage = "�������̓��͒��́A�l�����̎����E������ύX�ł��܂���B" & vbCrLf & _
                               "��ɓ��͂�o�^�܂��͏������Ă������ҏW���Ă��������B"
            ElseIf PersonCandidateIdentityEditTouchesAssignedID(ws, identityAffected) Then
                blockIdentityEdit = True
                blockMessage = "�l��ID���t�������̎����E�����͒��ڕύX�ł��܂���B" & vbCrLf & _
                               "�o�^�ς݌������������ƁA�����l��ID�̌��ֈ��S�ɔ��f����܂��B"
            End If
        End If
        If blockIdentityEdit Then
            If Not TrySetCandidateEnableEventsExact(False, eventStateDetail) Then
                errorNumber = vbObjectError + 2142
                errorDescription = _
                    "�l�����̕ύX����O��Excel�C�x���g���~�ł��܂���ł����B " & _
                    eventStateDetail
                rollbackFailed = True
                eventRecoveryEnforced = True
                eventsReadyForRecovery = _
                    StopAfterCandidateEventStateFailure( _
                        "OnCandidateSheetChange/�l�����ύX����O�̃C�x���g��~", _
                        eventStateDetail)
                recoveryStateConfirmed = eventsReadyForRecovery
                AppendCandidateSafetyDetail errorDescription, eventStateDetail
                GoTo BlockIdentityFinalize
            End If
            eventsReadyForRecovery = True
            On Error Resume Next
            Err.Clear
            Application.Undo
            errorNumber = Err.Number
            errorDescription = Err.Description
            Err.Clear
            On Error GoTo 0
            If errorNumber <> 0 Then rollbackFailed = True
BlockIdentityFinalize:
            On Error Resume Next
            Err.Clear
            If eventsReadyForRecovery Then
                ProtectCandidateSheet ws, True
                restoreErrorNumber = Err.Number
                restoreErrorDescription = Err.Description
                restoreErrorSource = Err.Source
                Err.Clear
                If IsCandidateRecoveryHardBarrier( _
                       restoreErrorNumber, restoreErrorSource) Then
                    Call TryStopCandidateEventsForBookWrites(eventStateDetail)
                    On Error GoTo 0
                    Err.Raise restoreErrorNumber, restoreErrorSource, _
                              restoreErrorDescription
                End If
                eventStateDetail = vbNullString
                eventsReadyForRecovery = _
                    TryStopCandidateEventsForBookWrites(eventStateDetail)
                If Not eventsReadyForRecovery Then
                    AppendCandidateSafetyDetail errorDescription, _
                        "���V�[�g�ĕی���Excel�C�x���g��~���m�F�ł��܂���: " & _
                        eventStateDetail
                    rollbackFailed = True
                Else
                    protectionConfirmed = ws.ProtectContents And _
                                          ws.ProtectDrawingObjects
                    protectionReadErrorNumber = Err.Number
                    protectionReadErrorDescription = Err.Description
                    Err.Clear
                    If protectionReadErrorNumber <> 0 Or _
                       Not protectionConfirmed Then
                        rollbackFailed = True
                        AppendCandidateSafetyDetail errorDescription, _
                            "���V�[�g�ĕی��ǂݖ߂��܂���" & _
                            IIf(protectionReadErrorNumber <> 0, _
                                ": Err " & CStr(protectionReadErrorNumber) & _
                                " " & protectionReadErrorDescription, _
                                vbNullString)
                    End If
                End If
                If restoreErrorNumber <> 0 Then
                    If errorNumber = 0 Then
                        errorNumber = restoreErrorNumber
                        errorDescription = _
                            "�l�����̕ύX�����Ɍ��V�[�g���ĕی�ł��܂���ł����B " & _
                            restoreErrorDescription
                    Else
                        AppendCandidateSafetyDetail errorDescription, _
                            "���V�[�g�ĕی�: Err " & _
                            CStr(restoreErrorNumber) & " " & restoreErrorDescription
                    End If
                    rollbackFailed = True
                    protectionConfirmed = False
                End If
            End If
            If rollbackFailed And eventsReadyForRecovery And _
               Not eventRecoveryEnforced Then
                recoveryDetail = errorDescription
                postRecoveryStopDetail = vbNullString
                recoveryStateConfirmed = _
                    TryEnterCandidateRecoveryStateExact( _
                        recoveryDetail, postRecoveryStopDetail)
                recoveryErrorNumber = Err.Number
                recoveryErrorSource = Err.Source
                recoveryErrorDescription = Err.Description
                Err.Clear
                If IsCandidateRecoveryHardBarrier( _
                       recoveryErrorNumber, recoveryErrorSource) Then
                    Call TryStopCandidateEventsForBookWrites(eventStateDetail)
                    On Error GoTo 0
                    Err.Raise recoveryErrorNumber, recoveryErrorSource, _
                              recoveryErrorDescription
                End If
                eventsReadyForRecovery = recoveryStateConfirmed
                If Not recoveryStateConfirmed Then
                    AppendCandidateSafetyDetail recoveryDetail, _
                        "Recovery����ӂɊm�F�ł��Ȃ����߁A�f�f�E��ԕ\�����s���܂���: " & _
                        postRecoveryStopDetail
                End If
            End If
            If rollbackFailed And Not eventRecoveryEnforced And _
               eventsReadyForRecovery Then
                'Undo�s�\�܂��̓C�x���g��ԕs���̕ύX�l��ʏ�o�^����Q�Ƃ����Ȃ��B
                If recoveryStateConfirmed Then
                    On Error Resume Next
                    AddCheck "�G���[", "�l�����ύX�̎��", _
                             "�l�����̕ύX�����S�Ɏ������܂���ł����B�Č���v�����Ƃ��Ē�~���܂��BErr " & _
                             CStr(errorNumber) & ": " & errorDescription & _
                             IIf(Len(recoveryDetail) > 0, " / " & recoveryDetail, "")
                    SetInputStatus "�l�����̕ύX�����S�Ɏ������Ȃ����߁A" & _
                                   "�Č���v�����Ƃ��Ē�~���܂����B", True
                    Err.Clear
                    On Error GoTo 0
                    postRecoveryStopDetail = vbNullString
                    eventsReadyForRecovery = _
                        TryStopCandidateEventsForBookWrites( _
                            postRecoveryStopDetail)
                    If eventsReadyForRecovery Then
                        recoveryStateConfirmed = _
                            TryConfirmCandidateRecoveryState(recoveryDetail)
                    Else
                        recoveryStateConfirmed = False
                    End If
                End If
            End If
            On Error GoTo 0
            safeToRestoreEntry = Not previousEvents
            If previousEvents Then
                safeToRestoreEntry = eventsReadyForRecovery And _
                    ((Not rollbackFailed And protectionConfirmed) Or _
                     recoveryStateConfirmed)
                If safeToRestoreEntry Then
                    applicationStateProblems = vbNullString
                    applicationStateSafe = _
                        AppStateIsRestored(applicationStateProblems)
                    safeToRestoreEntry = applicationStateSafe
                    If Not applicationStateSafe Then _
                        AppendCandidateSafetyDetail errorDescription, _
                            "�J�n�lTrue�ւ̕����O��Application��Ԃ��m�F�ł��܂���: " & _
                            applicationStateProblems
                End If
            End If
            If eventsCaptured Then
                If safeToRestoreEntry Then
                    If Not TryRestoreCandidateEnableEvents( _
                               previousEvents, _
                               "OnCandidateSheetChange/�l�����ύX���", _
                               eventStateDetail) Then
                        eventRecoveryEnforced = True
                        If errorNumber = 0 Then
                            errorNumber = vbObjectError + 2143
                            errorDescription = _
                                "�l�����̕ύX������Excel�C�x���g��Ԃ𕜌��ł��܂���ł����B " & _
                                eventStateDetail
                        Else
                            AppendCandidateSafetyDetail errorDescription, _
                                eventStateDetail
                        End If
                        rollbackFailed = True
                    End If
                Else
                    eventStateDetail = vbNullString
                    If TryStopCandidateEventsForBookWrites( _
                           eventStateDetail) Then
                        AppendCandidateSafetyDetail errorDescription, _
                            "���[���o�b�N�E�ی�܂��͗v��������ӂɊm��ł��Ȃ����߁A" & _
                            "Excel�C�x���g��False�ɕێ����܂����B"
                    Else
                        AppendCandidateSafetyDetail errorDescription, _
                            "Excel�C�x���g��False�������m�F�ł����A" & _
                            "�Č��̈��S��Ԃ͕s���ł�: " & _
                            eventStateDetail
                    End If
                    eventRecoveryEnforced = True
                    rollbackFailed = True
                    If errorNumber = 0 Then
                        errorNumber = vbObjectError + 2143
                        errorDescription = _
                            "�l�����̕ύX�����̈��S��Ԃ��m��ł��܂���B"
                    End If
                End If
                eventsCaptured = False
            End If
            If errorNumber = 0 Then
                MsgBox blockMessage, vbExclamation, "�l�����̕ύX���������܂���"
                Exit Sub
            End If
            Err.Raise errorNumber, "OnCandidateSheetChange/�������̕ύX���", _
                      errorDescription & _
                      IIf(Len(recoveryDetail) > 0, " / " & recoveryDetail, "")
        End If
    End If
    On Error GoTo CleanUp
    '�C�x���g�J�n���_�i���p�҂̋��ςݕύX���܂ށj�̌��\��ޔ�����B
    '���̌�̏d�������E��l�߁E��`���E�ی�X�V���r���Ŏ��s���Ă��A
    '�㏈�����������[�ɔ��f���ꂽ�\���c���Ȃ��B
    snapshotLastRow = LastDataRowInColumns(ws, 1, 4)
    If snapshotLastRow < 2 Then snapshotLastRow = 2
    Set snapshotRange = ws.Range(ws.Cells(2, 1), ws.Cells(snapshotLastRow, 4))
    candidateMergeSignature = InputRangeMergeSignature(snapshotRange)
    candidateSnapshot = CaptureInputFormulaSnapshot(snapshotRange)
    snapshotCaptured = True
    If Not TrySetCandidateEnableEventsExact(False, eventStateDetail) Then
        rollbackFailed = True
        Err.Raise vbObjectError + 2144, "OnCandidateSheetChange", _
                  "���X�V�O��Excel�C�x���g���~�ł��܂���ł����B " & eventStateDetail
    End If
    eventsReadyForRecovery = True
    postProcessStarted = True

    '��s�E�x�X�E�l��������͂Œǉ������s�́A�Č��������ŏ����Ȃ����ʌ��Ƃ��Ĉ����B
    For Each cell In Intersect(affected.EntireRow, ws.Columns(1)).Cells
        If cell.HasFormula Or IsError(cell.Value) Then
            '�s���l�͊��S�Z���t�`�F�b�N�֎c���A�l��ID�E�����E�敪��s�t�ɏ����Ȃ��B
        ElseIf Not HasText(cell.Value) Then
            'A�񂪋󗓂Ȃ�A�ύX���ꂽ��ɂ�����炸�l��ID�E�����E�敪���Ǘ������Ȃ��B
            '�l�����͕K���������ɓ��͂��邽�߁A��̍s�֑����������c���Ȃ��B
            ws.Range(ws.Cells(cell.Row, 2), ws.Cells(cell.Row, 4)).ClearContents
        ElseIf ws.Name = SH_BANK_CAND Or ws.Name = SH_BRANCH_CAND Or _
               ws.Name = SH_PERSON_CAND Then
                If Not HasText(ws.Cells(cell.Row, 4).Value) Then _
                    ws.Cells(cell.Row, 4).Value = CAND_SOURCE_COMMON
        End If
    Next cell
    If ws.Name = SH_PERSON_CAND Then MergeBlankPersonCandidateDuplicates ws
    CompactCandidateRows ws
    RefreshCandidateNameForSheet ws.Name
    '���p�҂��ҏW�ł���A/C��ł͐l��ID�͕ς��Ȃ��B�̔Ԓ��O�̏ƍ��֔C���A�S�䒠�đ������Ȃ��B
    If ws.Name = SH_PERSON_CAND Then InvalidateInternalIdCaches
    firstStyleRow = Application.Max(2, Target.Row)
    lastStyleRow = Application.Min(ws.Rows.Count, _
                   Application.Max(firstStyleRow, Target.Row + Target.Rows.Count))
    FormatCandidateEntryArea ws, lastStyleRow, firstStyleRow
    ws.ScrollArea = "A1:J" & CStr(Application.Min(ws.Rows.Count, _
                    Application.Max(500, LastRow(ws, 1) + 500)))
    EnsureCandidateProtectionCapacity ws
CleanUp:
    errorNumber = Err.Number
    errorSource = Err.Source
    errorDescription = Err.Description
    If IsCandidateRecoveryHardBarrier(errorNumber, errorSource) Then
        Call TryStopCandidateEventsForBookWrites(eventStateDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    eventsReadyForRecovery = False
    If eventsCaptured Then
        If TrySetCandidateEnableEventsExact(False, eventStateDetail) Then
            eventsReadyForRecovery = True
        Else
            rollbackFailed = True
            eventRecoveryEnforced = True
            eventsReadyForRecovery = _
                StopAfterCandidateEventStateFailure( _
                    "OnCandidateSheetChange/�㏈���O�̃C�x���g��~", _
                    eventStateDetail)
            recoveryStateConfirmed = eventsReadyForRecovery
            If errorNumber = 0 Then
                errorNumber = vbObjectError + 2145
                errorDescription = _
                    "���X�V�̏I�������O��Excel�C�x���g���~�ł��܂���ł����B " & _
                    eventStateDetail
            Else
                restoreDetail = restoreDetail & _
                    " / ���\�����O��Excel�C�x���g��~�G���[: " & eventStateDetail
            End If
        End If
    End If
    If errorNumber <> 0 And postProcessStarted And snapshotCaptured Then
        If eventsReadyForRecovery Then
            On Error Resume Next
            Err.Clear
            currentLastRow = LastDataRowInColumns(ws, 1, 4)
            If currentLastRow < snapshotLastRow Then currentLastRow = snapshotLastRow
            ws.Unprotect Password:=TOOL_PASSWORD
            ws.Range(ws.Cells(2, 1), ws.Cells(currentLastRow, 4)).ClearContents
            RestoreInputFormulaSnapshot snapshotRange, candidateSnapshot, _
                                        candidateMergeSignature, ws.Name & "���"
            AssertInputFormulaSnapshot snapshotRange, candidateSnapshot, _
                                       candidateMergeSignature, ws.Name & "���"
            RefreshCandidateNameForSheet ws.Name
            ProtectCandidateSheet ws, True
            restoreErrorNumber = Err.Number
            restoreErrorDescription = Err.Description
            restoreErrorSource = Err.Source
            If IsCandidateRecoveryHardBarrier( _
                   restoreErrorNumber, restoreErrorSource) Then
                Call TryStopCandidateEventsForBookWrites(eventStateDetail)
                On Error GoTo 0
                Err.Raise restoreErrorNumber, restoreErrorSource, _
                          restoreErrorDescription
            End If
            If restoreErrorNumber <> 0 Then
                rollbackFailed = True
                restoreDetail = restoreDetail & _
                    " / ���\�E��`���E�ی�̕����G���[: Err " & _
                    CStr(restoreErrorNumber) & " " & restoreErrorDescription
            End If
            Err.Clear
            On Error GoTo 0
        Else
            rollbackFailed = True
            restoreDetail = restoreDetail & _
                " / Excel�C�x���g��~���m�F�ł��Ȃ����ߌ��\�̕��������s���܂���ł����B"
        End If
    End If
    On Error Resume Next
    Err.Clear
    If rollbackFailed And Not eventRecoveryEnforced Then
        If eventsReadyForRecovery Then
            If Len(recoveryDetail) = 0 Then _
                recoveryDetail = errorDescription & restoreDetail
            postRecoveryStopDetail = vbNullString
            recoveryStateConfirmed = _
                TryEnterCandidateRecoveryStateExact( _
                    recoveryDetail, postRecoveryStopDetail)
            recoveryErrorNumber = Err.Number
            recoveryErrorSource = Err.Source
            recoveryErrorDescription = Err.Description
            Err.Clear
            If IsCandidateRecoveryHardBarrier( _
                   recoveryErrorNumber, recoveryErrorSource) Then
                Call TryStopCandidateEventsForBookWrites(eventStateDetail)
                On Error GoTo 0
                Err.Raise recoveryErrorNumber, recoveryErrorSource, _
                          recoveryErrorDescription
            End If
            eventsReadyForRecovery = recoveryStateConfirmed
            If Not recoveryStateConfirmed Then
                AppendCandidateSafetyDetail recoveryDetail, _
                    "Recovery����ӂɊm�F�ł��Ȃ����߁A�ǉ��I���L�^���s���܂���: " & _
                    postRecoveryStopDetail
            End If
            If eventsReadyForRecovery And recoveryStateConfirmed Then
                AppendCandidateSafetyDetail restoreDetail, _
                    "�Č���v�����Ƃ��Ē�~���܂����B"
            Else
                AppendCandidateSafetyDetail restoreDetail, _
                    "�Č��̈��S��Ԃ��m�F�ł��܂���B"
            End If
            If Len(recoveryDetail) > 0 Then _
                AppendCandidateSafetyDetail restoreDetail, recoveryDetail
        Else
            AppendCandidateSafetyDetail restoreDetail, _
                "�C�x���g��~���m�F�̂���Recovery�����݂�������A�Č��̈��S��Ԃ͕s���ł��B"
        End If
    End If
    On Error GoTo 0
    safeToRestoreEntry = Not previousEvents
    If previousEvents Then
        safeToRestoreEntry = eventsReadyForRecovery And _
            ((Not rollbackFailed) Or recoveryStateConfirmed)
        If safeToRestoreEntry Then
            applicationStateProblems = vbNullString
            applicationStateSafe = AppStateIsRestored(applicationStateProblems)
            safeToRestoreEntry = applicationStateSafe
            If Not applicationStateSafe Then _
                AppendCandidateSafetyDetail restoreDetail, _
                    "�J�n�lTrue�ւ̕����O��Application��Ԃ��m�F�ł��܂���: " & _
                    applicationStateProblems
        End If
    End If
    If eventsCaptured Then
        If safeToRestoreEntry Then
            If Not TryRestoreCandidateEnableEvents( _
                       previousEvents, "OnCandidateSheetChange", _
                       eventStateDetail) Then
                eventRecoveryEnforced = True
                eventRestoreDetail = _
                    " / Excel�C�x���g��Ԃ̕����G���[: " & eventStateDetail
                If errorNumber = 0 Then
                    errorNumber = vbObjectError + 2146
                    errorDescription = _
                        "���X�V���Excel�C�x���g��Ԃ𕜌��ł��܂���B"
                End If
                rollbackFailed = True
            End If
        Else
            eventStateDetail = vbNullString
            If TryStopCandidateEventsForBookWrites(eventStateDetail) Then
                AppendCandidateSafetyDetail restoreDetail, _
                    "���[���o�b�N�܂��͗v��������ӂɊm��ł��Ȃ����߁A" & _
                    "Excel�C�x���g��False�ɕێ����܂����B"
            Else
                AppendCandidateSafetyDetail restoreDetail, _
                    "Excel�C�x���g��False�������m�F�ł����A" & _
                    "�Č��̈��S��Ԃ͕s���ł�: " & eventStateDetail
            End If
            rollbackFailed = True
        End If
        eventsCaptured = False
    End If
    If errorNumber <> 0 Then _
        Err.Raise errorNumber, "OnCandidateSheetChange", _
                  errorDescription & restoreDetail & eventRestoreDetail
End Sub

Private Sub AppendCandidateSafetyDetail(ByRef detailText As String, _
                                        ByVal itemText As String)
    If Len(itemText) = 0 Then Exit Sub
    If Len(detailText) > 0 Then detailText = detailText & " / "
    detailText = detailText & itemText
End Sub

Private Function IsCandidateRecoveryHardBarrier( _
        ByVal errorNumber As Long, _
        ByVal errorSource As String) As Boolean
    IsCandidateRecoveryHardBarrier = _
        (errorNumber = CANDIDATE_RECOVERY_HARD_BARRIER_ERROR)
End Function

Private Function TryGetCandidateEnableEvents( _
        ByRef currentValue As Boolean, _
        ByRef detailText As String) As Boolean
    Dim errorNumber As Long, errorDescription As String
    detailText = vbNullString
    On Error GoTo EH
    currentValue = Application.EnableEvents
    TryGetCandidateEnableEvents = True
    Exit Function
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    detailText = "Err " & CStr(errorNumber) & ": " & errorDescription
    Err.Clear
End Function

Private Function TrySetCandidateEnableEventsExact( _
        ByVal desiredValue As Boolean, _
        ByRef detailText As String) As Boolean
    Dim errorNumber As Long, errorDescription As String
    detailText = vbNullString
    On Error GoTo EH
    Application.EnableEvents = desiredValue
    If Application.EnableEvents <> desiredValue Then _
        Err.Raise vbObjectError + 2147, _
                  "TrySetCandidateEnableEventsExact", _
                  "EnableEvents�̏����݌�ǖ߂�����v���܂���B"
    TrySetCandidateEnableEventsExact = True
    Exit Function
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    detailText = "Err " & CStr(errorNumber) & ": " & errorDescription
    Err.Clear
End Function

Private Function TryStopCandidateEventsForBookWrites( _
        ByRef detailText As String) As Boolean
    Dim firstDetail As String, retryDetail As String
    detailText = vbNullString
    If TrySetCandidateEnableEventsExact(False, firstDetail) Then
        TryStopCandidateEventsForBookWrites = True
        Exit Function
    End If
    If TrySetCandidateEnableEventsExact(False, retryDetail) Then
        TryStopCandidateEventsForBookWrites = True
        Exit Function
    End If
    detailText = "Excel�C�x���g��False�֒�~���ēǖ߂��m�F�ł��܂���ł����B����=" & _
                 firstDetail & " / �Ď��s=" & retryDetail
End Function

Private Function TryConfirmCandidateRecoveryState( _
        ByRef detailText As String) As Boolean
    Dim latchIsSet As Boolean, latchReadSucceeded As Boolean
    Dim healthValue As String, healthReadSucceeded As Boolean
    latchReadSucceeded = TryGetRollbackRecoveryLatch(latchIsSet)
    healthReadSucceeded = TryGetExactStateValue(STATE_DATA_HEALTH, healthValue)
    If Not latchReadSucceeded Or Not latchIsSet Then _
        AppendCandidateSafetyDetail detailText, _
            "�Ɨ��������b�`��ݒ�ς݂Ƃ��Ĉ�ӂɊm�F�ł��܂���B"
    If Not healthReadSucceeded Or _
       StrComp(healthValue, DATA_HEALTH_NEEDS_RECOVERY, vbBinaryCompare) <> 0 Then _
        AppendCandidateSafetyDetail detailText, _
            "�Č��v������Ԃ���ӂɊm�F�ł��܂���B"
    TryConfirmCandidateRecoveryState = _
        latchReadSucceeded And latchIsSet And healthReadSucceeded And _
        (StrComp(healthValue, DATA_HEALTH_NEEDS_RECOVERY, vbBinaryCompare) = 0)
End Function

Private Function TryEnterCandidateRecoveryStateExact( _
        ByRef recoveryDetail As String, _
        ByRef gateDetail As String) As Boolean
    Dim recoveryErrorNumber As Long, recoveryErrorDescription As String
    Dim postRecoveryStopDetail As String, finalStopDetail As String
    Dim confirmationDetail As String, applicationStateProblems As String
    Dim postRecoveryStopped As Boolean
    gateDetail = vbNullString

    If Not TryStopCandidateEventsForBookWrites(gateDetail) Then
        gateDetail = "Recovery�����ݑO��Excel�C�x���g��~���m�F�ł��܂���: " & _
                     gateDetail
        Exit Function
    End If

    On Error Resume Next
    Err.Clear
    EnforceRollbackRecoveryState recoveryDetail
    recoveryErrorNumber = Err.Number
    recoveryErrorDescription = Err.Description
    Err.Clear
    On Error GoTo 0

    'Enforce�������C�x���g�l��߂����邽�߁A���ʂɂ�����炸fresh False�֎�������B
    postRecoveryStopDetail = vbNullString
    postRecoveryStopped = _
        TryStopCandidateEventsForBookWrites(postRecoveryStopDetail)
    If Not postRecoveryStopped Then
        gateDetail = "Recovery�������Excel�C�x���g��~���m�F�ł��܂���: " & _
                     postRecoveryStopDetail
        If recoveryErrorNumber <> 0 Then _
            AppendCandidateSafetyDetail gateDetail, _
                "Enforce Err " & CStr(recoveryErrorNumber) & " " & _
                recoveryErrorDescription
        gateDetail = recoveryDetail & " / " & gateDetail
    ElseIf recoveryErrorNumber <> 0 Then
        gateDetail = "Enforce Err " & CStr(recoveryErrorNumber) & " " & _
                     recoveryErrorDescription & _
                     "�B����Recovery��Ԃ͓ǂݖ߂����AExcel�C�x���g��False�Ɉێ����܂����B"
    Else
        gateDetail = recoveryDetail
    End If

    '�Ǐ�Enforce����x���s������́A�����E���s���킸�O��owner��terminal marker��n���B
    'Err����False�����ȊO���s�킸�A����return������Recovery/AppState/final False���m�F����B
    If recoveryErrorNumber <> 0 Then
        Err.Raise CANDIDATE_RECOVERY_HARD_BARRIER_ERROR, _
                  CANDIDATE_RECOVERY_HARD_BARRIER_SOURCE & _
                      "TryEnterCandidateRecoveryStateExact/EnforceError", _
                  gateDetail
    End If
    If Not postRecoveryStopped Then
        Err.Raise CANDIDATE_RECOVERY_HARD_BARRIER_ERROR, _
                  CANDIDATE_RECOVERY_HARD_BARRIER_SOURCE & _
                      "TryEnterCandidateRecoveryStateExact/PostFalseFailed", _
                  gateDetail
    End If

    confirmationDetail = vbNullString
    If Not TryConfirmCandidateRecoveryState(confirmationDetail) Then
        AppendCandidateSafetyDetail gateDetail, _
            "Recovery�̓�d��Ԃ��m�F�ł��܂���: " & confirmationDetail
        finalStopDetail = vbNullString
        Call TryStopCandidateEventsForBookWrites(finalStopDetail)
        Err.Raise CANDIDATE_RECOVERY_HARD_BARRIER_ERROR, _
                  CANDIDATE_RECOVERY_HARD_BARRIER_SOURCE & _
                      "TryEnterCandidateRecoveryStateExact/RecoveryUnconfirmed", _
                  gateDetail
    End If
    applicationStateProblems = vbNullString
    If Not AppStateIsRestored(applicationStateProblems) Then
        AppendCandidateSafetyDetail gateDetail, _
            "Application��Ԃ����S�Ɋm�F�ł��܂���: " & _
            applicationStateProblems
        finalStopDetail = vbNullString
        Call TryStopCandidateEventsForBookWrites(finalStopDetail)
        Err.Raise CANDIDATE_RECOVERY_HARD_BARRIER_ERROR, _
                  CANDIDATE_RECOVERY_HARD_BARRIER_SOURCE & _
                      "TryEnterCandidateRecoveryStateExact/AppStateUnconfirmed", _
                  gateDetail
    End If
    finalStopDetail = vbNullString
    If Not TryStopCandidateEventsForBookWrites(finalStopDetail) Then _
        AppendCandidateSafetyDetail gateDetail, _
            "�ŏIExcel�C�x���g��~���m�F�ł��܂���: " & finalStopDetail
    Err.Raise CANDIDATE_RECOVERY_HARD_BARRIER_ERROR, _
              CANDIDATE_RECOVERY_HARD_BARRIER_SOURCE & _
                  "TryEnterCandidateRecoveryStateExact/EnforceReturned", _
              gateDetail
End Function

Private Function TryRestoreCandidateEnableEvents( _
        ByVal previousValue As Boolean, _
        ByVal operationName As String, _
        ByRef detailText As String) As Boolean
    Dim firstDetail As String, retryDetail As String
    detailText = vbNullString
    If TrySetCandidateEnableEventsExact(previousValue, firstDetail) Then
        TryRestoreCandidateEnableEvents = True
        Exit Function
    End If
    '�ꎞ�I��COM���s�Ȃ瓯���J�n�l�ւ̍Ď��s�Ŏ���������B
    If TrySetCandidateEnableEventsExact(previousValue, retryDetail) Then
        TryRestoreCandidateEnableEvents = True
        Exit Function
    End If
    detailText = "Excel�C�x���g��Ԃ��J�n�l�֕����ł��܂���ł����B����=" & _
                 firstDetail & " / �Ď��s=" & retryDetail
    '����Recovery����x�ł����s������́A���̓�����terminal�Ƃ���B
    'StopAfter�͎��s����hard barrier��raise���A���s�O��~�s�\������False��Ԃ��B
    '������̏ꍇ���J�n�lTrue�ւ̍Ď��s�͍s��Ȃ��B
    Call StopAfterCandidateEventStateFailure(operationName, detailText)
End Function

Private Function StopAfterCandidateEventStateFailure( _
        ByVal operationName As String, _
        ByRef detailText As String) As Boolean
    Dim recoveryDetail As String, stopDetail As String
    Dim postRecoveryStopDetail As String
    Dim recoveryConfirmed As Boolean
    recoveryDetail = operationName & ": " & detailText
    If Not TryStopCandidateEventsForBookWrites(stopDetail) Then
        AppendCandidateSafetyDetail recoveryDetail, _
            "�C�x���g��~���m�F�̂��߁A�u�b�N�ւ�Recovery�E�f�f�E��ԕ\���̏����݂�������܂���: " & _
            stopDetail
        AppendCandidateSafetyDetail recoveryDetail, _
            "Excel�C�x���g��ԂƈČ��̈��S��Ԃ͕s���ł��B"
        detailText = recoveryDetail
        Exit Function
    End If
    AppendCandidateSafetyDetail recoveryDetail, _
        "�v�����L�^�O��Excel�C�x���g��~��ǖ߂��m�F���܂����B"
    postRecoveryStopDetail = vbNullString
    recoveryConfirmed = _
        TryEnterCandidateRecoveryStateExact( _
            recoveryDetail, postRecoveryStopDetail)
    If Not recoveryConfirmed Then
        AppendCandidateSafetyDetail recoveryDetail, _
            "Recovery����ӂɊm�F�ł��Ȃ����߁A�f�f�E��ԕ\�����s���܂���: " & _
            postRecoveryStopDetail
        detailText = recoveryDetail
        Exit Function
    End If
    'TryEnter��Enforce attempt�̐��ۂ��킸hard barrier��raise����_��ł���B
    '��������Đ���return���Ă��A�f�f�E��ԕ\���E�J�n�l�����ւ͐i�߂Ȃ��B
    detailText = recoveryDetail
End Function

Private Function PersonCandidateIdentityEditTouchesAssignedID(ByVal ws As Worksheet, _
                                                               ByVal identityAffected As Range) As Boolean
    Dim cell As Range
    If ws Is Nothing Or identityAffected Is Nothing Then Exit Function
    For Each cell In identityAffected.Cells
        If cell.Row >= 2 And Len(CellText(ws.Cells(cell.Row, 2).Value)) > 0 Then
            PersonCandidateIdentityEditTouchesAssignedID = True
            Exit Function
        End If
    Next cell
End Function

Private Sub MergeBlankPersonCandidateDuplicates(ByVal ws As Worksheet)
    '����͂œ��������E�����𖖔��֒ǉ����Ă��A�l��ID�Ȃ��̕\���d�����c���Ȃ��B
    '�قȂ���ID���m�̖����͕s�t�ɓ��������A���S�Z���t�`�F�b�N�֎c���B
    Dim lastR As Long, r As Long, keptRow As Long
    Dim identityKey As String, personID As String, keptID As String
    Dim sourceText As String, keptSource As String
    Dim rowsByIdentity As Object
    If ws Is Nothing Then Exit Sub
    lastR = LastDataRowInColumns(ws, 1, 4)
    If lastR < 2 Then Exit Sub
    Set rowsByIdentity = CreateObject("Scripting.Dictionary")
    rowsByIdentity.CompareMode = vbTextCompare
    For r = 2 To lastR
        If Not ws.Cells(r, 1).HasFormula And Not ws.Cells(r, 3).HasFormula And _
           Not IsError(ws.Cells(r, 1).Value) And Not IsError(ws.Cells(r, 3).Value) Then
            identityKey = PersonIdentityKey(CellText(ws.Cells(r, 1).Value), _
                                            CellText(ws.Cells(r, 3).Value))
            If Len(identityKey) > 0 Then
                personID = CellText(ws.Cells(r, 2).Value)
                If Len(personID) = 0 Or IsInternalIdValue(personID, "P") Then
                    If rowsByIdentity.Exists(identityKey) Then
                        keptRow = CLng(rowsByIdentity(identityKey))
                        keptID = CellText(ws.Cells(keptRow, 2).Value)
                        sourceText = CellText(ws.Cells(r, 4).Value)
                        keptSource = CellText(ws.Cells(keptRow, 4).Value)
                        If Len(keptID) > 0 And Len(personID) > 0 And _
                           StrComp(keptID, personID, vbTextCompare) <> 0 Then
                            '�قȂ�l��ID�͂����ŏ����Ȃ��B
                        ElseIf Len(keptID) = 0 And Len(personID) > 0 Then
                            If sourceText = CAND_SOURCE_COMMON Or keptSource = CAND_SOURCE_COMMON Then _
                                ws.Cells(r, 4).Value = CAND_SOURCE_COMMON
                            ws.Range(ws.Cells(keptRow, 1), ws.Cells(keptRow, 4)).ClearContents
                            rowsByIdentity(identityKey) = r
                        Else
                            If sourceText = CAND_SOURCE_COMMON Or keptSource = CAND_SOURCE_COMMON Then _
                                ws.Cells(keptRow, 4).Value = CAND_SOURCE_COMMON
                            ws.Range(ws.Cells(r, 1), ws.Cells(r, 4)).ClearContents
                        End If
                    Else
                        rowsByIdentity.Add identityKey, r
                    End If
                End If
            End If
        End If
    Next r
End Sub

Private Sub CompactCandidateRows(ByVal ws As Worksheet)
    '�r���s���폜�E��эs�֓\��t���Ă��A��▼�̒�`�͈͂֋󔒂��c���Ȃ��B
    'Formula�őޔ��E�������A�s���Ȑ�����G���[�l�̓Z���t�`�F�b�N�Ō��o�ł���`��ۂB
    Dim lastR As Long, rowCount As Long
    Dim sourceData As Variant, compactedData() As Variant
    Dim r As Long, c As Long, writeRow As Long
    Dim keepRow As Boolean, compactionNeeded As Boolean
    If ws Is Nothing Then Exit Sub
    lastR = LastDataRowInColumns(ws, 1, 4)
    If lastR < 2 Then Exit Sub
    rowCount = lastR - 1
    sourceData = ws.Range(ws.Cells(2, 1), ws.Cells(lastR, 4)).Formula
    ReDim compactedData(1 To rowCount, 1 To 4)
    For r = 1 To rowCount
        keepRow = IsError(sourceData(r, 1)) Or Len(CellText(sourceData(r, 1))) > 0
        If keepRow Then
            writeRow = writeRow + 1
            If writeRow <> r Then compactionNeeded = True
            For c = 1 To 4
                compactedData(writeRow, c) = sourceData(r, c)
            Next c
        Else
            compactionNeeded = True
        End If
    Next r
    If compactionNeeded Then
        ws.Range(ws.Cells(2, 1), ws.Cells(lastR, 4)).ClearContents
        If writeRow > 0 Then
            ws.Range(ws.Cells(2, 1), ws.Cells(1 + rowCount, 4)).Formula = compactedData
        End If
    End If
End Sub

Private Sub RefreshCandidateNameForSheet(ByVal sheetName As String)
    Select Case sheetName
        Case SH_BANK_CAND
            RefreshSingleCandidateName SH_BANK_CAND, NM_LST_BANK_CAND
        Case SH_BRANCH_CAND
            RefreshSingleCandidateName SH_BRANCH_CAND, NM_LST_BRANCH_CAND
        Case SH_PERSON_CAND
            RefreshSingleCandidateName SH_PERSON_CAND, NM_LST_PERSON_CAND
        Case SH_ACCOUNT_TYPE
            RefreshSingleCandidateName SH_ACCOUNT_TYPE, NM_LST_ACCOUNT_TYPE
        Case SH_TEKIYO
            RefreshSingleCandidateName SH_TEKIYO, NM_LST_TEKIYO
    End Select
End Sub

Private Function CandidateSheetNames() As Variant
    CandidateSheetNames = Array(SH_BANK_CAND, SH_BRANCH_CAND, SH_PERSON_CAND, _
                                SH_ACCOUNT_TYPE, SH_TEKIYO)
End Function

Public Function IsCandidateSheetName(ByVal sheetName As String) As Boolean
    Dim item As Variant
    For Each item In CandidateSheetNames()
        If StrComp(CStr(item), sheetName, vbTextCompare) = 0 Then
            IsCandidateSheetName = True
            Exit Function
        End If
    Next item
End Function

Public Function CandidateEditableLastRow(ByVal ws As Worksheet) As Long
    Dim lastR As Long
    CandidateEditableLastRow = 2
    If ws Is Nothing Then Exit Function
    lastR = LastDataRowInColumns(ws, 1, 4)
    If lastR < 1 Then lastR = 1
    CandidateEditableLastRow = Application.Min(MAX_CANDIDATE_DATA_ROWS + 1, _
        Application.Max(501, lastR + CANDIDATE_EDIT_BUFFER_ROWS))
End Function

Private Sub EnsureCandidateProtectionCapacity(ByVal ws As Worksheet)
    Dim requiredLastRow As Long, protectedLastRow As Long
    If ws Is Nothing Then Exit Sub
    requiredLastRow = CandidateEditableLastRow(ws)
    If mCandidateEditableThrough Is Nothing Then
        ProtectCandidateSheet ws, True
        Exit Sub
    End If
    If Not mCandidateEditableThrough.Exists(ws.Name) Then
        ProtectCandidateSheet ws, True
        Exit Sub
    End If
    protectedLastRow = CLng(mCandidateEditableThrough(ws.Name))
    '���������łȂ��k���������J���͈͂��ă��b�N���A���ݏ���̒����K������B
    If protectedLastRow <> requiredLastRow Then ProtectCandidateSheet ws, True
End Sub

Public Sub ProtectCandidateSheet(ByVal ws As Worksheet, _
                                 Optional ByVal raiseOnError As Boolean = False)
    '���l�̓��͗񂾂����J���A�E���i�r�Q�[�V�����ƃ��C�A�E�g�͕ی삷��B
    '�ő���p�����܂ł��ꊇ�ݒ肵�A�\���̂��тɑS104���s�𑖍����Ȃ��B
    Dim editableLastRow As Long, lockLastRow As Long, cachedEditableLastRow As Long
    Dim protectionModeMatches As Boolean, candidateReadOnly As Boolean
    Dim previousRangeKnown As Boolean
    Dim workbookWasSaved As Boolean
    Dim emergencyProtected As Boolean, savedReadback As Boolean
    Dim previousEvents As Boolean, eventsCaptured As Boolean
    Dim eventsStoppedForRecovery As Boolean, recoveryStateConfirmed As Boolean
    Dim safeToRestoreEntry As Boolean
    Dim eventRestoreSucceeded As Boolean
    Dim applicationStateSafe As Boolean, applicationStateProblems As String
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim emergencyErrorNumber As Long, emergencyErrorDescription As String
    Dim emergencyReadErrorNumber As Long, emergencyReadErrorDescription As String
    Dim savedErrorNumber As Long, savedErrorDescription As String
    Dim savedReadErrorNumber As Long, savedReadErrorDescription As String
    Dim recoveryErrorNumber As Long, recoveryErrorDescription As String
    Dim recoveryErrorSource As String
    Dim recoveryDetail As String, sheetName As String
    Dim eventStateDetail As String, eventRestoreDetail As String
    Dim postRecoveryStopDetail As String
    If ws Is Nothing Then Exit Sub
    If Not IsCandidateSheetName(ws.Name) Then _
        Err.Raise vbObjectError + 2130, "ProtectCandidateSheet", _
                  "���V�[�g�ł͂���܂���: " & ws.Name
    sheetName = ws.Name
    If Not TryGetCandidateEnableEvents(previousEvents, eventStateDetail) Then
        Call StopAfterCandidateEventStateFailure( _
                 "ProtectCandidateSheet/�J�n��Ԏ擾", eventStateDetail)
        If raiseOnError Then _
            Err.Raise vbObjectError + 2148, _
                      "ProtectCandidateSheet(" & sheetName & ")", _
                      "Excel�C�x���g�̊J�n��Ԃ��擾�ł��܂���ł����B " & _
                      eventStateDetail
        Exit Sub
    End If
    eventsCaptured = True
    If Not TryStopCandidateEventsForBookWrites(eventStateDetail) Then
        errorDescription = _
            "���V�[�g�ی�O��Excel�C�x���g���~���ēǖ߂��m�F�ł��܂���ł����B " & _
            eventStateDetail
        On Error Resume Next
        MsgBox errorDescription & vbCrLf & _
               "�u�b�N�ւ̕ی�E��ԋL�^�͍s�킸�A�Č��̈��S��Ԃ͕s���ł��B" & _
               vbCrLf & "���݂̃u�b�N���㏑�����Ȃ��ł��������B", _
               vbCritical, "���V�[�g�����S�ɕی�ł��܂���"
        On Error GoTo 0
        If Not TryRestoreCandidateEnableEvents( _
                   previousEvents, "ProtectCandidateSheet/�ی�J�n�O", _
                   eventRestoreDetail) Then _
            AppendCandidateSafetyDetail errorDescription, _
                "Excel�C�x���g��Ԃ̕����G���[: " & eventRestoreDetail
        eventsCaptured = False
        If raiseOnError Then _
            Err.Raise vbObjectError + 2149, _
                      "ProtectCandidateSheet(" & sheetName & ")", _
                      errorDescription
        Exit Sub
    End If
    eventsStoppedForRecovery = True
    workbookWasSaved = ThisWorkbook.Saved
    On Error GoTo EH
    candidateReadOnly = ThisWorkbook.ReadOnly Or _
                        (ws.Name = SH_PERSON_CAND And _
                         (IsEditMode() Or CurrentAccountInputHasData()))
    editableLastRow = CandidateEditableLastRow(ws)
    If mCandidateEditableThrough Is Nothing Then
        Set mCandidateEditableThrough = CreateObject("Scripting.Dictionary")
        mCandidateEditableThrough.CompareMode = vbTextCompare
    End If
    If mCandidateEditableThrough.Exists(ws.Name) Then
        cachedEditableLastRow = CLng(mCandidateEditableThrough(ws.Name))
        previousRangeKnown = True
    Else
        cachedEditableLastRow = StoredCandidateEditableLastRow(ws)
        If cachedEditableLastRow > 0 Then
            mCandidateEditableThrough(ws.Name) = cachedEditableLastRow
            previousRangeKnown = True
        End If
    End If
    If previousRangeKnown Then
        If candidateReadOnly Then
            protectionModeMatches = CBool(ws.Range("A2").Locked)
        Else
            protectionModeMatches = Not CBool(ws.Range("A2").Locked)
            If ws.Name = SH_PERSON_CAND Then _
                protectionModeMatches = protectionModeMatches And _
                                        Not CBool(ws.Range("C2").Locked)
        End If
        '�����\�������Activate�C�x���g���璼��ɍēx�Ă΂�Ă��A
        '�ҏW�͈͂Ɠǎ��p��Ԃ���v����ی�ς݃V�[�g�͐����Z�����Đݒ肵�Ȃ��B
        If ws.ProtectContents And _
           cachedEditableLastRow = editableLastRow And protectionModeMatches Then
            RestoreToolSheetScrollArea ws
            If candidateReadOnly Then
                ws.EnableSelection = xlNoSelection
            Else
                ws.EnableSelection = xlUnlockedCells
            End If
            VerifyToolShapeSecurity ws, True, False
            If workbookWasSaved Then ThisWorkbook.Saved = True
            GoTo SafeExit
        End If
    End If
    lockLastRow = editableLastRow + CANDIDATE_LOCK_BUFFER_ROWS
    '��⌸�����́A�ȑO�J���Ă����͈͂���x���b�N�������Ă��猻�ݔ͈͂������J����B
    If previousRangeKnown Then
        If cachedEditableLastRow > lockLastRow Then lockLastRow = cachedEditableLastRow
    Else
        '���͈͂������L���b�V�����i���}�[�J�[���Ȃ����́A�ߋ��̉���unlock���c���Ȃ��B
        lockLastRow = MAX_CANDIDATE_DATA_ROWS + 1 + CANDIDATE_LOCK_BUFFER_ROWS
    End If
    If lockLastRow > ws.Rows.Count Then lockLastRow = ws.Rows.Count
    If editableLastRow > lockLastRow Then editableLastRow = lockLastRow
    ws.Unprotect Password:=TOOL_PASSWORD
    RestoreToolSheetScrollArea ws
    ws.Range("A1:D" & CStr(lockLastRow)).Locked = True
    If Not candidateReadOnly Then
        ws.Range("A2:A" & CStr(editableLastRow)).Locked = False
        If ws.Name = SH_PERSON_CAND Then _
            ws.Range("C2:C" & CStr(editableLastRow)).Locked = False
    End If
    LockToolShapes ws, False
    ws.Protect Password:=TOOL_PASSWORD, DrawingObjects:=True, Contents:=True, Scenarios:=False, _
               UserInterfaceOnly:=True, AllowFiltering:=False, AllowSorting:=False, _
               AllowFormattingCells:=False, AllowFormattingColumns:=False, AllowFormattingRows:=False, _
               AllowInsertingColumns:=False, AllowInsertingRows:=False, _
               AllowDeletingColumns:=False, AllowDeletingRows:=False
    If candidateReadOnly Then
        ws.EnableSelection = xlNoSelection
    Else
        ws.EnableSelection = xlUnlockedCells
    End If
    mCandidateEditableThrough(ws.Name) = editableLastRow
    StoreCandidateEditableLastRow ws, editableLastRow
    VerifyToolShapeSecurity ws, True, False
    If workbookWasSaved Then ThisWorkbook.Saved = True
SafeExit:
    If eventsCaptured Then
        If Not TryRestoreCandidateEnableEvents( _
                   previousEvents, "ProtectCandidateSheet/����I��", _
                   eventRestoreDetail) Then
            eventsCaptured = False
            On Error GoTo 0
            If raiseOnError Then _
                Err.Raise vbObjectError + 2150, _
                          "ProtectCandidateSheet(" & sheetName & ")", _
                          eventRestoreDetail
            Exit Sub
        End If
        eventsCaptured = False
    End If
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    If IsCandidateRecoveryHardBarrier(errorNumber, errorSource) Then
        Call TryStopCandidateEventsForBookWrites(eventStateDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    On Error Resume Next
    Err.Clear
    EmergencyProtectToolSheet ws
    emergencyErrorNumber = Err.Number
    emergencyErrorDescription = Err.Description
    Err.Clear
    emergencyProtected = ws.ProtectContents And ws.ProtectDrawingObjects
    emergencyReadErrorNumber = Err.Number
    emergencyReadErrorDescription = Err.Description
    Err.Clear
    If emergencyErrorNumber <> 0 Then emergencyProtected = False
    If emergencyErrorNumber <> 0 Or emergencyReadErrorNumber <> 0 Or _
       Not emergencyProtected Then
        recoveryDetail = "���V�[�g�ً̋}�ĕی���m�F�ł��܂���B"
        If emergencyErrorNumber <> 0 Then _
            recoveryDetail = recoveryDetail & " Err " & _
                             CStr(emergencyErrorNumber) & " " & _
                             emergencyErrorDescription
        If emergencyReadErrorNumber <> 0 Then _
            recoveryDetail = recoveryDetail & " / �ی�ǖ߂� Err " & _
                             CStr(emergencyReadErrorNumber) & " " & _
                             emergencyReadErrorDescription
        eventsStoppedForRecovery = _
            TryStopCandidateEventsForBookWrites(eventStateDetail)
        If eventsStoppedForRecovery Then
            AppendCandidateSafetyDetail recoveryDetail, _
                "�v�����L�^�O��Excel�C�x���g��~��ǖ߂��m�F���܂����B"
            postRecoveryStopDetail = vbNullString
            recoveryStateConfirmed = _
                TryEnterCandidateRecoveryStateExact( _
                    recoveryDetail, postRecoveryStopDetail)
            recoveryErrorNumber = Err.Number
            recoveryErrorSource = Err.Source
            recoveryErrorDescription = Err.Description
            Err.Clear
            If IsCandidateRecoveryHardBarrier( _
                   recoveryErrorNumber, recoveryErrorSource) Then
                Call TryStopCandidateEventsForBookWrites(eventStateDetail)
                On Error GoTo 0
                Err.Raise recoveryErrorNumber, recoveryErrorSource, _
                          recoveryErrorDescription
            End If
            eventsStoppedForRecovery = recoveryStateConfirmed
            AppendCandidateSafetyDetail errorDescription, recoveryDetail
            If recoveryStateConfirmed Then
                On Error Resume Next
                AddCheck "�G���[", "���V�[�g�ً̋}�ĕی�", recoveryDetail
                SetInputStatus "���V�[�g�ً̋}�ĕی���m�F�ł��Ȃ����߁A" & _
                               "�Č���v�����Ƃ��Ē�~���܂����B", True
                Err.Clear
                On Error GoTo 0
                postRecoveryStopDetail = vbNullString
                eventsStoppedForRecovery = _
                    TryStopCandidateEventsForBookWrites( _
                        postRecoveryStopDetail)
                If eventsStoppedForRecovery Then
                    recoveryStateConfirmed = _
                        TryConfirmCandidateRecoveryState(recoveryDetail)
                Else
                    recoveryStateConfirmed = False
                End If
            Else
                AppendCandidateSafetyDetail recoveryDetail, _
                    "Recovery����ӂɊm�F�ł��Ȃ����߁A�f�f�E��ԕ\�����s���܂���: " & _
                    postRecoveryStopDetail
                eventStateDetail = vbNullString
                eventsStoppedForRecovery = _
                    TryStopCandidateEventsForBookWrites(eventStateDetail)
            End If
        Else
            AppendCandidateSafetyDetail errorDescription, recoveryDetail
            AppendCandidateSafetyDetail errorDescription, _
                "Excel�C�x���g��~���m�F�ł��Ȃ�����Recovery�E�f�f�E��ԕ\���̏����݂�������A" & _
                "�Č��̈��S��Ԃ͕s���ł�: " & eventStateDetail
            Err.Clear
            MsgBox "���V�[�g�ً̋}�ĕی�Ɏ��s���AExcel�C�x���g�����S�ɒ�~�ł��܂���ł����B" & _
                   vbCrLf & "�u�b�N�ւ̕����L�^��������A�Č��̈��S��Ԃ͕s���ł��B" & _
                   vbCrLf & "���݂̃u�b�N���㏑�����Ȃ��ł��������B", _
                   vbCritical, "���V�[�g�̈��S��Ԃ��m�F�ł��܂���"
            Err.Clear
        End If
    End If
    '�J�n���ɕۑ��ς݂ł��A�ً}�ی�Ƃ��̓ǖ߂������������ꍇ����
    '�ی쑀��ɂ��Saved�ύX��߂��B�ی�s������ۑ��ς݈����ŉB���Ȃ��B
    If emergencyProtected Then
        eventStateDetail = vbNullString
        eventsStoppedForRecovery = _
            TryStopCandidateEventsForBookWrites(eventStateDetail)
        If Not eventsStoppedForRecovery Then _
            AppendCandidateSafetyDetail errorDescription, _
                "�ً}�ĕی���Excel�C�x���g��~���m�F�ł��Ȃ����߁A" & _
                "Saved�����ƊJ�n�l�ւ̃C�x���g������������܂���: " & _
                eventStateDetail
    End If
    If emergencyProtected And eventsStoppedForRecovery And workbookWasSaved Then
        ThisWorkbook.Saved = True
        savedErrorNumber = Err.Number
        savedErrorDescription = Err.Description
        Err.Clear
        savedReadback = ThisWorkbook.Saved
        savedReadErrorNumber = Err.Number
        savedReadErrorDescription = Err.Description
        Err.Clear
        If savedErrorNumber <> 0 Or savedReadErrorNumber <> 0 Or _
           Not savedReadback Then
            AppendCandidateSafetyDetail errorDescription, _
                "�u�b�N�ۑ���Ԃ̕������m�F�ł��܂���" & _
                IIf(savedErrorNumber <> 0, _
                    ": Err " & CStr(savedErrorNumber) & " " & _
                    savedErrorDescription, vbNullString) & _
                IIf(savedReadErrorNumber <> 0, _
                    " / �ǖ߂� Err " & CStr(savedReadErrorNumber) & _
                    " " & savedReadErrorDescription, vbNullString)
        End If
    End If
    safeToRestoreEntry = Not previousEvents
    If previousEvents Then
        safeToRestoreEntry = eventsStoppedForRecovery And emergencyProtected
        If Not safeToRestoreEntry And eventsStoppedForRecovery And _
           recoveryStateConfirmed Then
            applicationStateProblems = vbNullString
            applicationStateSafe = _
                AppStateIsRestored(applicationStateProblems)
            safeToRestoreEntry = applicationStateSafe
            If Not applicationStateSafe Then _
                AppendCandidateSafetyDetail errorDescription, _
                    "�J�n�lTrue�ւ̕����O��Application��Ԃ��m�F�ł��܂���: " & _
                    applicationStateProblems
        End If
    End If
    If eventsCaptured Then
        If safeToRestoreEntry Then
            eventRestoreSucceeded = _
                TryRestoreCandidateEnableEvents( _
                    previousEvents, "ProtectCandidateSheet/�ُ�I��", _
                    eventRestoreDetail)
            recoveryErrorNumber = Err.Number
            recoveryErrorSource = Err.Source
            recoveryErrorDescription = Err.Description
            Err.Clear
            If IsCandidateRecoveryHardBarrier( _
                   recoveryErrorNumber, recoveryErrorSource) Then
                Call TryStopCandidateEventsForBookWrites(eventStateDetail)
                On Error GoTo 0
                Err.Raise recoveryErrorNumber, recoveryErrorSource, _
                          recoveryErrorDescription
            End If
            If Not eventRestoreSucceeded Then _
                AppendCandidateSafetyDetail errorDescription, _
                    "Excel�C�x���g��Ԃ̕����G���[: " & eventRestoreDetail
        Else
            eventStateDetail = vbNullString
            If TryStopCandidateEventsForBookWrites(eventStateDetail) Then
                AppendCandidateSafetyDetail errorDescription, _
                    "�ی�܂��͗v��������ӂɊm��ł��Ȃ����߁A" & _
                    "Excel�C�x���g��False�ɕێ����܂����B"
            Else
                AppendCandidateSafetyDetail errorDescription, _
                    "Excel�C�x���g��False�������m�F�ł����A" & _
                    "�Č��̈��S��Ԃ͕s���ł�: " & eventStateDetail
            End If
        End If
    End If
    eventsCaptured = False
    On Error GoTo 0
    If raiseOnError Then _
        Err.Raise errorNumber, "ProtectCandidateSheet(" & sheetName & ")", _
                  IIf(Len(errorSource) > 0, errorSource & " / ", vbNullString) & _
                  errorDescription
End Sub

Public Sub ProtectAllCandidateSheets(Optional ByVal raiseOnError As Boolean = False)
    Dim item As Variant
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim eventStateDetail As String
    On Error GoTo EH
    For Each item In CandidateSheetNames()
        If SheetExists(CStr(item)) Then ProtectCandidateSheet GetSheet(CStr(item)), True
    Next item
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    If IsCandidateRecoveryHardBarrier(errorNumber, errorSource) Then
        Call TryStopCandidateEventsForBookWrites(eventStateDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    If raiseOnError Then Err.Raise errorNumber, "ProtectAllCandidateSheets", errorDescription
End Sub

Private Sub FormatCandidateSheetForEditing(ByVal ws As Worksheet)
    Dim lastStyleRow As Long
    If ws Is Nothing Then Exit Sub
    lastStyleRow = Application.Min(10000, Application.Max(50, LastRow(ws, 1) + 25))
    With ws
        .Range("A1:J" & CStr(lastStyleRow)).Font.Name = "Yu Gothic UI"
        .Range("A1:J" & CStr(lastStyleRow)).Font.Size = 10.5
        .Columns("A:A").ColumnWidth = IIf(ws.Name = SH_TEKIYO, 48, 30)
        .Columns("B:D").Hidden = True
        If ws.Name = SH_PERSON_CAND Then
            .Columns("C:C").Hidden = False
            .Columns("C:C").ColumnWidth = 18
        End If
        .Columns("F:J").Hidden = False
        .Columns("F:J").ColumnWidth = 13
        .Rows(1).RowHeight = 28
        .ScrollArea = "A1:J" & CStr(Application.Min(.Rows.Count, _
                      Application.Max(500, LastRow(ws, 1) + 500)))
    End With
    FormatOutputHeader ws.Range("A1:D1")
    FormatCandidateEntryArea ws, lastStyleRow
End Sub

Private Sub FormatCandidateEntryArea(ByVal ws As Worksheet, ByVal lastStyleRow As Long, _
                                     Optional ByVal firstStyleRow As Long = 2)
    Dim visibleRange As Range
    If ws Is Nothing Or lastStyleRow < 2 Then Exit Sub
    If firstStyleRow < 2 Then firstStyleRow = 2
    If firstStyleRow > lastStyleRow Then Exit Sub
    If ws.Name = SH_PERSON_CAND Then
        Set visibleRange = Union(ws.Range("A" & CStr(firstStyleRow) & ":A" & CStr(lastStyleRow)), _
                                 ws.Range("C" & CStr(firstStyleRow) & ":C" & CStr(lastStyleRow)))
    Else
        Set visibleRange = ws.Range("A" & CStr(firstStyleRow) & ":A" & CStr(lastStyleRow))
    End If
    With visibleRange
        .Interior.Color = RGB(255, 255, 255)
        .Font.Color = RGB(15, 23, 42)
        .Borders.LineStyle = xlContinuous
        .Borders.Color = RGB(226, 232, 240)
        .VerticalAlignment = xlCenter
    End With
    ws.Rows(CStr(firstStyleRow) & ":" & CStr(lastStyleRow)).RowHeight = 22
End Sub

Public Sub BuildCandidateNavigationPanel(ByVal ws As Worksheet)
    Dim x As Double, y As Double, w As Double, h As Double
    Dim margin As Double, gap As Double, buttonW As Double, buttonH As Double
    Dim rowY As Double
    If ws Is Nothing Then Exit Sub
    DeleteToolShapesVerified ws, False
    x = ws.Range("F2").Left
    y = ws.Range("F2").Top
    w = ws.Range("F2:J10").Width
    h = ws.Range("F2:J10").Height
    margin = 10
    gap = 7
    buttonW = (w - margin * 2 - gap) / 2
    buttonH = 30

    AddCandidateTextShape ws, UI_PREFIX & "candidate_title", _
                          ws.Range("F1").Left, ws.Range("F1").Top, _
                          ws.Range("F1:J1").Width, ws.Range("F1:J1").Height, _
                          "���͌��𐮗�", True
    AddPanelBack ws, x, y, w, h
    rowY = y + margin
    AddUIButton ws, x + margin, rowY, buttonW, buttonH, "��s��", "ShowBankCandidates", _
                IIf(ws.Name = SH_BANK_CAND, "primary", "tool")
    AddUIButton ws, x + margin + buttonW + gap, rowY, buttonW, buttonH, "�x�X��", _
                "ShowBranchCandidates", IIf(ws.Name = SH_BRANCH_CAND, "primary", "tool")
    rowY = rowY + buttonH + gap
    AddUIButton ws, x + margin, rowY, buttonW, buttonH, "�l���E����", _
                "ShowPersonCandidates", IIf(ws.Name = SH_PERSON_CAND, "primary", "tool")
    AddUIButton ws, x + margin + buttonW + gap, rowY, buttonW, buttonH, "�Ȗ�", _
                "ShowAccountTypeCandidates", IIf(ws.Name = SH_ACCOUNT_TYPE, "primary", "tool")
    rowY = rowY + buttonH + gap
    AddUIButton ws, x + margin, rowY, buttonW, buttonH, "�E�v", "ShowTekiyoCandidates", _
                IIf(ws.Name = SH_TEKIYO, "primary", "tool")
    AddUIButton ws, x + margin + buttonW + gap, rowY, buttonW, buttonH, "���֖͂߂�", _
                "ShowInputSheet", "soft"
    AddCandidateTextShape ws, UI_PREFIX & "candidate_note", _
                          ws.Range("F12").Left, ws.Range("F12").Top, _
                          ws.Range("F12:J13").Width, ws.Range("F12:J13").Height, _
                          "A��֌�����͂��܂��B�l����₾����C��ɑ�������͂ł��܂��B�ύX�͓��̓��X�g�֎������f����܂��B", False
    LockToolShapes ws, False
End Sub

Private Sub AddCandidateTextShape(ByVal ws As Worksheet, ByVal shapeName As String, _
                                  ByVal x As Double, ByVal y As Double, _
                                  ByVal w As Double, ByVal h As Double, _
                                  ByVal textValue As String, ByVal titleStyle As Boolean)
    Dim shp As Shape
    If ws Is Nothing Then Exit Sub
    Set shp = ws.Shapes.AddShape(msoShapeRoundedRectangle, x, y, w, h)
    With shp
        .Name = shapeName
        .TextFrame.Characters.Text = textValue
        .TextFrame.HorizontalAlignment = xlHAlignCenter
        .TextFrame.VerticalAlignment = xlVAlignCenter
        .TextFrame.MarginLeft = 6
        .TextFrame.MarginRight = 6
        .TextFrame.Characters.Font.Name = "Yu Gothic UI"
        .TextFrame.Characters.Font.Bold = titleStyle
        .TextFrame.Characters.Font.Size = IIf(titleStyle, 10.5, 9.5)
        If titleStyle Then
            .Fill.ForeColor.RGB = RGB(239, 246, 255)
            .Line.ForeColor.RGB = RGB(191, 219, 254)
            .TextFrame.Characters.Font.Color = RGB(30, 64, 175)
        Else
            .Fill.ForeColor.RGB = RGB(248, 250, 252)
            .Line.ForeColor.RGB = RGB(226, 232, 240)
            .TextFrame.Characters.Font.Color = RGB(71, 85, 105)
        End If
        .Placement = xlMove
        .Locked = True
    End With
End Sub

Private Sub SetupCandidateSheet(ByVal sheetName As String, ByVal titleText As String, ByVal listName As String, ByVal resetContents As Boolean)
    Dim ws As Worksheet, styleLastRow As Long, lastR As Long, r As Long
    Dim candidateData As Variant, sourceMigrated As Boolean
    Dim needsReset As Boolean
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim eventStateDetail As String
    On Error GoTo EH
    Set ws = GetOrCreateSheet(sheetName, False)
    If ws Is Nothing Then Err.Raise vbObjectError + 2001, "SetupCandidateSheet", "���V�[�g���쐬�ł��܂���: " & sheetName
    needsReset = resetContents Or Len(CellText(ws.Range("A1").Value)) = 0
    If needsReset Then
        ResetWorksheet ws
        ws.Range("A1").Value = titleText
        ws.Range("A1").Font.Bold = True
        ws.Range("A2:D2").ClearContents
        If sheetName = SH_PERSON_CAND Then
            ws.Range("B1").Value = "�l��ID"
            ws.Range("C1").Value = "����"
            ws.Range("B1:C1").Font.Bold = True
        End If
        ws.Range("D1").Value = "�敪"
        ws.Range("D1").Font.Bold = True
    End If
    '���ł�1����������p���ꍇ�A�敪�󗓂̂܂܂��ƈČ��������ŏ�����B
    '�������͗��p�҂��p�����p���Ă������ʌ��Ƃ��ĕی삷��B
    lastR = LastDataRowInColumns(ws, 1, 4)
    If lastR >= 2 Then
        candidateData = ws.Range(ws.Cells(2, 1), ws.Cells(lastR, 4)).Value2
        For r = 1 To UBound(candidateData, 1)
            If Len(CellText(candidateData(r, 1))) > 0 And Len(CellText(candidateData(r, 4))) = 0 Then
                candidateData(r, 4) = CAND_SOURCE_COMMON
                sourceMigrated = True
            End If
        Next r
        If sourceMigrated Then ws.Range(ws.Cells(2, 1), ws.Cells(lastR, 4)).Value2 = candidateData
    End If
    ws.Visible = xlSheetVisible
    styleLastRow = Application.Max(2, LastRow(ws, 1))
    With ws.Range("A1:D" & CStr(styleLastRow))
        .Font.Name = "Yu Gothic UI"
        .Font.Size = 10
    End With
    ws.Columns("A:A").ColumnWidth = 28
    ws.Columns("A:D").NumberFormatLocal = "@"
    If sheetName = SH_PERSON_CAND Then
        ws.Columns("B:B").ColumnWidth = 18
        ws.Columns("B:B").Hidden = True
        ws.Columns("C:C").ColumnWidth = 18
    End If
    ws.Columns("D:D").Hidden = True
    RefreshSingleCandidateName sheetName, listName
    ProtectCandidateSheet ws, True
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    If IsCandidateRecoveryHardBarrier(errorNumber, errorSource) Then
        Call TryStopCandidateEventsForBookWrites(eventStateDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    Err.Raise errorNumber, "SetupCandidateSheet(" & sheetName & ")", errorDescription
End Sub

Public Sub RefreshAccountCandidateNames()
    RefreshSingleCandidateName SH_BANK_CAND, NM_LST_BANK_CAND
    RefreshSingleCandidateName SH_BRANCH_CAND, NM_LST_BRANCH_CAND
    RefreshSingleCandidateName SH_PERSON_CAND, NM_LST_PERSON_CAND
End Sub

Public Sub RefreshAllCandidateNames()
    RefreshAccountCandidateNames
    RefreshSingleCandidateName SH_ACCOUNT_TYPE, NM_LST_ACCOUNT_TYPE
    RefreshSingleCandidateName SH_TEKIYO, NM_LST_TEKIYO
End Sub

Private Sub RefreshSingleCandidateName(ByVal sheetName As String, ByVal listName As String)
    Dim ws As Worksheet
    Dim lastR As Long
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim eventStateDetail As String
    On Error GoTo EH
    If Not SheetExists(sheetName) Then Exit Sub
    Set ws = GetSheet(sheetName)
    lastR = LastRow(ws, 1)
    If lastR < 2 Then
        lastR = 2
    End If
    ResetName listName, ws.Range("A2:A" & CStr(lastR))
    '�C�x���g��~���̈ꊇ�ǉ��E�������ł��A��⌏���ɍ��킹�ĊJ���͈͂𑝌�������B
    EnsureCandidateProtectionCapacity ws
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    If IsCandidateRecoveryHardBarrier(errorNumber, errorSource) Then
        Call TryStopCandidateEventsForBookWrites(eventStateDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    If Len(errorSource) = 0 Then _
        errorSource = "RefreshSingleCandidateName(" & sheetName & ")"
    Err.Raise errorNumber, errorSource, errorDescription
End Sub

Public Sub UpdateAccountCandidates(ByVal bankName As String, ByVal branchName As String, ByVal personName As String)
    AddCandidateValue SH_BANK_CAND, NM_LST_BANK_CAND, bankName, CAND_SOURCE_CASE
    AddCandidateValue SH_BRANCH_CAND, NM_LST_BRANCH_CAND, branchName, CAND_SOURCE_CASE
    '�l���͐l��ID�E�����ƈ�̂� AddPersonCandidateWithID ����o�^����B
End Sub

Public Sub ResetCaseCandidates()
    '���ʃf�[�^�R���͎c���A�Č����́E�O���捞�Ŋw�K������₾���������B
    RemoveCaseCandidateRows SH_BANK_CAND, NM_LST_BANK_CAND
    RemoveCaseCandidateRows SH_BRANCH_CAND, NM_LST_BRANCH_CAND
    RemoveCaseCandidateRows SH_PERSON_CAND, NM_LST_PERSON_CAND
    '���p�҂��ȖځE�E�v���֒��ڒǋL�����ꍇ���A��������̓��͋K���֑S�����Đڑ�����B
    RefreshAllCandidateNames
End Sub

Public Sub ValidateCaseCandidateResetSources()
    '����������c�鋤�ʌ��ɕs���ȋ敪������ƁA�Č��f�[�^�����������
    '�Z���t�`�F�b�N�ŏ������S�̂����s����B�j��I�������O�Ɍ��o����B
    ValidateCandidateResetSourceSheet SH_BANK_CAND
    ValidateCandidateResetSourceSheet SH_BRANCH_CAND
    ValidateCandidateResetSourceSheet SH_PERSON_CAND
End Sub

Public Sub AddAccountTypeCandidate(ByVal accountType As String)
    AddCandidateValue SH_ACCOUNT_TYPE, NM_LST_ACCOUNT_TYPE, accountType
End Sub

Public Sub AddBankCandidate(ByVal bankName As String, Optional ByVal sourceText As String = CAND_SOURCE_CASE)
    AddCandidateValue SH_BANK_CAND, NM_LST_BANK_CAND, bankName, sourceText
End Sub

Public Sub AddBranchCandidate(ByVal branchName As String, Optional ByVal sourceText As String = CAND_SOURCE_CASE)
    AddCandidateValue SH_BRANCH_CAND, NM_LST_BRANCH_CAND, branchName, sourceText
End Sub

Public Sub AddTekiyoCandidate(ByVal tekiyoText As String)
    AddCandidateValue SH_TEKIYO, NM_LST_TEKIYO, tekiyoText
End Sub

Public Sub AddPersonCandidateWithID(ByVal personName As String, ByVal personID As String, ByVal relationshipText As String, _
                                    Optional ByVal sourceText As String = CAND_SOURCE_CASE)
    Dim ws As Worksheet
    Dim lastR As Long, r As Long
    Dim s As String, batchKey As String
    Dim storedID As String, storedRelationship As String
    Dim requestedIdentityKey As String, storedIdentityKey As String
    Dim conflictingPersonID As String
    Dim conflictingPersonName As String
    Dim previousName As String, previousID As String, previousRelationship As String
    Dim indexedPersonID As String, indexedRelationship As String
    Dim refreshBatchPersonIndex As Boolean
    s = Trim$(CellText(personName))
    If Len(s) = 0 Then Exit Sub
    sourceText = CellText(sourceText)
    If sourceText <> CAND_SOURCE_CASE And sourceText <> CAND_SOURCE_COMMON Then _
        Err.Raise vbObjectError + 2112, "AddPersonCandidateWithID", "���敪���s���ł�: " & sourceText
    personID = CellText(personID)
    If Len(personID) > 0 And Not IsInternalIdValue(personID, "P") Then _
        Err.Raise vbObjectError + 2126, "AddPersonCandidateWithID", "�l��ID�̌`�����s���ł�: " & personID
    If mCandidateBatchDepth > 0 And Not mCandidateBatchRelationshipByID Is Nothing Then
        relationshipText = ValidatedBatchRelationshipForPersonID(personID, relationshipText)
    Else
        relationshipText = ValidatedRelationshipForPersonID(personID, relationshipText)
    End If
    If mCandidateBatchDepth = 0 And Len(personID) > 0 And _
       Len(NormalizeRelationshipKey(relationshipText)) > 0 Then
        If FindConflictingPersonIDForRelationshipChange( _
                personID, s, relationshipText, conflictingPersonName, _
                conflictingPersonID) Then _
            Err.Raise vbObjectError + 2138, "AddPersonCandidateWithID", _
                      "�����⊮��ɓ��������E�����ֈقȂ�l��ID�������܂��B" & _
                      "�l�������C�����Ă���Ď��s���Ă�������: " & _
                      conflictingPersonName & "�i�⊮�Ώ�=" & personID & _
                      " / ����=" & conflictingPersonID & "�j"
    End If
    If Len(s) > 100 Then Err.Raise vbObjectError + 2101, "AddPersonCandidateWithID", "��������100�����ȓ��ɂ��Ă��������B"
    If Len(CellText(personID)) > 100 Then Err.Raise vbObjectError + 2102, "AddPersonCandidateWithID", "�l��ID��100�����ȓ��ɂ��Ă��������B"
    If Len(CellText(relationshipText)) > 50 Then Err.Raise vbObjectError + 2103, "AddPersonCandidateWithID", "��������50�����ȓ��ɂ��Ă��������B"
    If Not SheetExists(SH_PERSON_CAND) Then BuildCandidateSheets False
    Set ws = GetSheet(SH_PERSON_CAND)
    lastR = LastRow(ws, 1)
    requestedIdentityKey = PersonIdentityKey(s, relationshipText)
    If mCandidateBatchDepth > 0 And Not mCandidateBatchRows Is Nothing Then
        batchKey = CandidateBatchKey(SH_PERSON_CAND, s, personID, relationshipText)
        r = FindCandidateBatchPersonRow(ws, s, personID, relationshipText, conflictingPersonID)
        If Len(conflictingPersonID) > 0 Then
            Err.Raise vbObjectError + 2136, "AddPersonCandidateWithID", _
                      "���������E�����ɈقȂ�l��ID������܂��B" & _
                      "�捞�𒆎~���A�l���������ɖ߂��܂�: " & s & _
                      "�i" & relationshipText & " / ����=" & conflictingPersonID & _
                      " / �捞=" & personID & "�j"
        End If
        If r >= 2 Then
            previousName = CellText(ws.Cells(r, 1).Value)
            previousID = CellText(ws.Cells(r, 2).Value)
            previousRelationship = CellText(ws.Cells(r, 3).Value)
            UpdateExistingPersonCandidate ws, r, s, personID, relationshipText, sourceText
            If NormalizePersonNameKey(previousName) <> _
               NormalizePersonNameKey(CellText(ws.Cells(r, 1).Value)) Or _
               StrComp(previousID, CellText(ws.Cells(r, 2).Value), vbTextCompare) <> 0 Or _
               NormalizeRelationshipKey(previousRelationship) <> _
               NormalizeRelationshipKey(CellText(ws.Cells(r, 3).Value)) Then
                UnindexCandidateBatchPersonRow r, previousName, previousID, previousRelationship
                refreshBatchPersonIndex = True
            End If
            GoTo Updated
        End If
        GoTo AppendNewPersonCandidate
    End If
    For r = 2 To lastR
        storedID = CellText(ws.Cells(r, 2).Value)
        If Len(personID) > 0 And Len(NormalizeRelationshipKey(relationshipText)) > 0 And _
           StrComp(storedID, personID, vbTextCompare) = 0 And _
           Len(NormalizeRelationshipKey(CellText(ws.Cells(r, 3).Value))) = 0 Then
            '�ʖ��`�œ����l��ID�̑������m�肵����A�����̖��m����������Ɏ���������B
            ws.Cells(r, 3).Value = relationshipText
        End If
        If NormalizePersonNameKey(CellText(ws.Cells(r, 1).Value)) = NormalizePersonNameKey(s) Then
            storedRelationship = CellText(ws.Cells(r, 3).Value)
            storedIdentityKey = PersonIdentityKey(CellText(ws.Cells(r, 1).Value), storedRelationship)
            If Len(personID) > 0 And StrComp(storedID, personID, vbTextCompare) = 0 Then
                UpdateExistingPersonCandidate ws, r, s, personID, relationshipText, sourceText
                GoTo Updated
            ElseIf Len(storedID) = 0 And storedIdentityKey = requestedIdentityKey Then
                UpdateExistingPersonCandidate ws, r, s, personID, relationshipText, sourceText
                GoTo Updated
            ElseIf Len(personID) = 0 And storedIdentityKey = requestedIdentityKey Then
                UpdateExistingPersonCandidate ws, r, s, personID, relationshipText, sourceText
                GoTo Updated
            ElseIf Len(personID) > 0 And Len(storedID) > 0 And storedIdentityKey = requestedIdentityKey Then
                Err.Raise vbObjectError + 2136, "AddPersonCandidateWithID", _
                          "���������E�����ɈقȂ�l��ID������܂��B" & _
                          "�l�������㏑�����܂���: " & s & _
                          "�i" & relationshipText & " / ����=" & storedID & _
                          " / �w��=" & personID & "�j"
            End If
        End If
    Next r
AppendNewPersonCandidate:
    r = lastR + 1
    If r < 2 Then r = 2
    If r - 1 > MAX_CANDIDATE_DATA_ROWS Then _
        Err.Raise vbObjectError + 2106, "AddPersonCandidateWithID", _
                  "�l����₪���p����i" & Format$(MAX_CANDIDATE_DATA_ROWS, "#,##0") & "���j�ɒB���Ă��܂��B"
    If r > ws.Rows.Count Then _
        Err.Raise vbObjectError + 2109, "AddPersonCandidateWithID", _
                  "�l����₪Excel�̍s����ɒB���Ă��܂��B���ʃf�[�^�𕪊����Ă��������B"
    ws.Cells(r, 1).Value = s
    ws.Cells(r, 2).Value = personID
    ws.Cells(r, 3).Value = relationshipText
    ws.Cells(r, 4).Value = sourceText
    refreshBatchPersonIndex = True
Updated:
    If mCandidateBatchDepth > 0 And Not mCandidateBatchRows Is Nothing Then
        If refreshBatchPersonIndex Then
            IndexCandidateBatchPersonRow r, CellText(ws.Cells(r, 1).Value), _
                                         CellText(ws.Cells(r, 2).Value), _
                                         CellText(ws.Cells(r, 3).Value), _
                                         SH_PERSON_CAND & " " & CStr(r) & "�s"
        End If
        indexedPersonID = CellText(ws.Cells(r, 2).Value)
        indexedRelationship = CellText(ws.Cells(r, 3).Value)
        If Len(indexedPersonID) > 0 And _
           Len(NormalizeRelationshipKey(indexedRelationship)) > 0 Then
            mCandidateBatchRelationshipByID(indexedPersonID) = indexedRelationship
        End If
        mCandidateBatchRows(CandidateBatchKey(SH_PERSON_CAND, s, personID, relationshipText)) = r
    End If
    If Len(personID) > 0 Then InvalidateInternalIdCaches
    If mCandidateBatchDepth = 0 Then RefreshSingleCandidateName SH_PERSON_CAND, NM_LST_PERSON_CAND
End Sub

Private Sub UpdateExistingPersonCandidate(ByVal ws As Worksheet, ByVal rowNo As Long, ByVal personName As String, _
                                          ByVal personID As String, ByVal relationshipText As String, _
                                          ByVal sourceText As String)
    If ws Is Nothing Or rowNo < 2 Then Exit Sub
    If Len(personID) > 0 Then
        If Len(CellText(ws.Cells(rowNo, 2).Value)) = 0 Then
            ws.Cells(rowNo, 2).Value = personID
            InvalidateInternalIdCaches
        ElseIf StrComp(CellText(ws.Cells(rowNo, 2).Value), personID, vbTextCompare) <> 0 Then
            Err.Raise vbObjectError + 2137, "UpdateExistingPersonCandidate", _
                      "���������E�����ɈقȂ�l��ID������܂��B" & _
                      "�l�������X�V���܂���: " & personName & _
                      "�i����=" & CellText(ws.Cells(rowNo, 2).Value) & _
                      " / �w��=" & personID & "�j"
        End If
    End If
    If Len(relationshipText) > 0 Then
        If Len(CellText(ws.Cells(rowNo, 3).Value)) > 0 And _
           NormalizeRelationshipKey(CellText(ws.Cells(rowNo, 3).Value)) <> NormalizeRelationshipKey(relationshipText) Then
            Err.Raise vbObjectError + 2107, "UpdateExistingPersonCandidate", _
                      "�����l��ID�̑������������ƈقȂ�܂��B���������̒������[�h�Ŋm�F���Ă�������: " & personName
        End If
        ws.Cells(rowNo, 3).Value = relationshipText
    End If
    If sourceText = CAND_SOURCE_COMMON Then ws.Cells(rowNo, 4).Value = CAND_SOURCE_COMMON
    If mCandidateBatchDepth = 0 Then RefreshSingleCandidateName SH_PERSON_CAND, NM_LST_PERSON_CAND
End Sub

Private Sub AddCandidateValue(ByVal sheetName As String, ByVal listName As String, ByVal valueText As String, _
                              Optional ByVal sourceText As String = CAND_SOURCE_CASE)
    Dim ws As Worksheet
    Dim lastR As Long, r As Long
    Dim s As String, batchKey As String
    s = Trim$(valueText)
    If Len(s) = 0 Then Exit Sub
    sourceText = CellText(sourceText)
    If sourceText <> CAND_SOURCE_CASE And sourceText <> CAND_SOURCE_COMMON Then _
        Err.Raise vbObjectError + 2113, "AddCandidateValue", "���敪���s���ł�: " & sourceText
    If sheetName = SH_TEKIYO Then
        If Len(s) > 500 Then Err.Raise vbObjectError + 2104, "AddCandidateValue", "�E�v����500�����ȓ��ɂ��Ă��������B"
    Else
        If Len(s) > 100 Then Err.Raise vbObjectError + 2105, "AddCandidateValue", "���l��100�����ȓ��ɂ��Ă��������B"
    End If
    If Not SheetExists(sheetName) Then BuildCandidateSheets False
    If Not SheetExists(sheetName) Then Exit Sub
    Set ws = GetSheet(sheetName)
    lastR = LastRow(ws, 1)
    If lastR < 2 Then lastR = 1
    If mCandidateBatchDepth > 0 And Not mCandidateBatchRows Is Nothing Then
        batchKey = CandidateBatchKey(sheetName, s)
        If mCandidateBatchRows.Exists(batchKey) Then
            r = CLng(mCandidateBatchRows(batchKey))
            If sourceText = CAND_SOURCE_COMMON Then ws.Cells(r, 4).Value = CAND_SOURCE_COMMON
            Exit Sub
        End If
        GoTo AppendNewCandidateValue
    End If
    For r = 2 To lastR
        If (sheetName = SH_PERSON_CAND And NormalizePersonNameKey(CellText(ws.Cells(r, 1).Value)) = NormalizePersonNameKey(s)) Or _
           (sheetName <> SH_PERSON_CAND And StrComp(CellText(ws.Cells(r, 1).Value), s, vbTextCompare) = 0) Then
            If sourceText = CAND_SOURCE_COMMON Then ws.Cells(r, 4).Value = CAND_SOURCE_COMMON
            If mCandidateBatchDepth = 0 Then RefreshSingleCandidateName sheetName, listName
            Exit Sub
        End If
    Next r
AppendNewCandidateValue:
    If lastR > MAX_CANDIDATE_DATA_ROWS Then _
        Err.Raise vbObjectError + 2110, "AddCandidateValue", _
                  "���ꗗ�����p����i" & Format$(MAX_CANDIDATE_DATA_ROWS, "#,##0") & "���j�ɒB���Ă��܂��B"
    If lastR + 1 > ws.Rows.Count Then _
        Err.Raise vbObjectError + 2111, "AddCandidateValue", _
                  "���ꗗ��Excel�̍s����ɒB���Ă��܂��B���ʃf�[�^�𕪊����Ă��������B"
    ws.Cells(lastR + 1, 1).Value = s
    ws.Cells(lastR + 1, 4).Value = sourceText
    If mCandidateBatchDepth > 0 And Not mCandidateBatchRows Is Nothing Then mCandidateBatchRows(CandidateBatchKey(sheetName, s)) = lastR + 1
    If mCandidateBatchDepth = 0 Then RefreshSingleCandidateName sheetName, listName
End Sub

Private Sub RemoveCaseCandidateRows(ByVal sheetName As String, ByVal listName As String)
    Dim ws As Worksheet
    If Not SheetExists(sheetName) Then Exit Sub
    Set ws = GetSheet(sheetName)
    '���V�[�g�͗��p�҂�����A��֒ǋL�ł���B�敪����͂ł��Ȃ��ʏ푀���
    '�ǉ����ꂽ�s�́A���Č��ł��g���蓮���ʌ��Ƃ��ĕی삷��B
    MigrateBlankCandidateSourcesToCommon ws
    '���m�̈Č���₾����z�񈳏k�ō폜����B�s���ȋ敪�͖ق��ď������Z���t�`�F�b�N�֎c���B
    CompactDeleteDataRows ws, 4, 4, CAND_SOURCE_CASE
    RefreshSingleCandidateName sheetName, listName
End Sub

Private Sub ValidateCandidateResetSourceSheet(ByVal sheetName As String)
    Dim ws As Worksheet, lastR As Long, r As Long
    Dim sourceData As Variant
    Dim candidateText As String, personID As String, relationshipText As String, sourceText As String
    Dim duplicateKey As String, identityKey As String, relationshipKey As String
    Dim seen As Object, identityIDs As Object, idRelationships As Object
    Dim formulaCell As Range
    If Not SheetExists(sheetName) Then _
        Err.Raise vbObjectError + 2114, "ValidateCaseCandidateResetSources", _
                  "���V�[�g������܂���: " & sheetName
    Set ws = GetSheet(sheetName)
    lastR = LastDataRowInColumns(ws, 1, 4)
    If lastR < 2 Then Exit Sub
    If Not TryFindFirstFormulaCell(ws.Range(ws.Cells(2, 1), ws.Cells(lastR, 4)), formulaCell) Then _
        Err.Raise vbObjectError + 2125, "ValidateCaseCandidateResetSources", _
                  sheetName & "�̐����L�����m�F�ł��܂���B�������𒆎~���܂����B"
    If Not formulaCell Is Nothing Then _
        Err.Raise vbObjectError + 2125, "ValidateCaseCandidateResetSources", _
                  sheetName & " " & formulaCell.Address(False, False) & _
                  "�ɐ���������܂��B�������O�ɒl�֒u�������Ă��������B"
    sourceData = ws.Range(ws.Cells(2, 1), ws.Cells(lastR, 4)).Value2
    Set seen = CreateObject("Scripting.Dictionary")
    Set identityIDs = CreateObject("Scripting.Dictionary")
    Set idRelationships = CreateObject("Scripting.Dictionary")
    seen.CompareMode = vbTextCompare
    identityIDs.CompareMode = vbTextCompare
    idRelationships.CompareMode = vbTextCompare
    For r = 1 To UBound(sourceData, 1)
        If IsError(sourceData(r, 1)) Or IsError(sourceData(r, 2)) Or _
           IsError(sourceData(r, 3)) Or IsError(sourceData(r, 4)) Then
            Err.Raise vbObjectError + 2115, "ValidateCaseCandidateResetSources", _
                      sheetName & " " & CStr(r + 1) & "�s��Excel�G���[�l������܂��B�Z���t�`�F�b�N�ŏC�����Ă��������B"
        End If
        candidateText = CellText(sourceData(r, 1))
        personID = CellText(sourceData(r, 2))
        relationshipText = CellText(sourceData(r, 3))
        sourceText = CellText(sourceData(r, 4))
        If Len(candidateText) = 0 Then
            Err.Raise vbObjectError + 2116, "ValidateCaseCandidateResetSources", _
                      sheetName & " " & CStr(r + 1) & "�s�͌��l���󗓂ł��B��s���l�߂Ă��������B"
        ElseIf Len(sourceText) > 0 And sourceText <> CAND_SOURCE_CASE And sourceText <> CAND_SOURCE_COMMON Then
            Err.Raise vbObjectError + 2117, "ValidateCaseCandidateResetSources", _
                      sheetName & " " & CStr(r + 1) & "�s�̋敪���s���ł�: " & sourceText
        End If
        '�Č����͏������ō폜�����B���ʌ��ƁA���ʂֈڍs����蓮�ǋL�s������
        '��������̏�ԂƂ��ďd���E�����E�l��ID�����܂Ŏ��O���؂���B
        If sourceText <> CAND_SOURCE_CASE Then
            If Len(candidateText) > 100 Then _
                Err.Raise vbObjectError + 2119, "ValidateCaseCandidateResetSources", _
                          sheetName & " " & CStr(r + 1) & "�s�̌��l��100�����𒴂��Ă��܂��B"
            If sheetName = SH_PERSON_CAND Then
                If Len(personID) > 100 Then _
                    Err.Raise vbObjectError + 2120, "ValidateCaseCandidateResetSources", _
                              sheetName & " " & CStr(r + 1) & "�s�̐l��ID��100�����𒴂��Ă��܂��B"
                If Len(personID) > 0 And Not IsInternalIdValue(personID, "P") Then _
                    Err.Raise vbObjectError + 2126, "ValidateCaseCandidateResetSources", _
                              sheetName & " " & CStr(r + 1) & "�s�̐l��ID�`�����s���ł�: " & personID
                If Len(relationshipText) > 50 Then _
                    Err.Raise vbObjectError + 2121, "ValidateCaseCandidateResetSources", _
                              sheetName & " " & CStr(r + 1) & "�s�̑�����50�����𒴂��Ă��܂��B"
                identityKey = PersonIdentityKey(candidateText, relationshipText)
                duplicateKey = identityKey & Chr$(29) & UCase$(personID)
                If Len(personID) > 0 Then
                    If identityIDs.Exists(identityKey) Then
                        If StrComp(CStr(identityIDs(identityKey)), personID, vbTextCompare) <> 0 Then _
                            Err.Raise vbObjectError + 2123, "ValidateCaseCandidateResetSources", _
                                      sheetName & " " & CStr(r + 1) & "�s�͓��������E�����ɈقȂ�l��ID������܂��B"
                    Else
                        identityIDs.Add identityKey, personID
                    End If
                    relationshipKey = NormalizeRelationshipKey(relationshipText)
                    If Len(relationshipKey) > 0 Then
                        If idRelationships.Exists(personID) Then
                            If StrComp(CStr(idRelationships(personID)), relationshipKey, vbTextCompare) <> 0 Then _
                                Err.Raise vbObjectError + 2124, "ValidateCaseCandidateResetSources", _
                                          sheetName & " " & CStr(r + 1) & "�s�͓���l��ID�̑�������v���܂���B"
                        Else
                            idRelationships.Add personID, relationshipKey
                        End If
                    End If
                End If
            Else
                duplicateKey = UCase$(Trim$(candidateText))
            End If
            If seen.Exists(duplicateKey) Then _
                Err.Raise vbObjectError + 2122, "ValidateCaseCandidateResetSources", _
                          sheetName & " " & CStr(r + 1) & "�s�ɏ���������c��d����₪����܂��B"
            seen.Add duplicateKey, True
        End If
    Next r
End Sub

Private Sub MigrateBlankCandidateSourcesToCommon(ByVal ws As Worksheet)
    Dim lastR As Long, r As Long
    Dim sourceData As Variant, changed As Boolean
    If ws Is Nothing Then Exit Sub
    lastR = LastDataRowInColumns(ws, 1, 4)
    If lastR < 2 Then Exit Sub
    sourceData = ws.Range(ws.Cells(2, 1), ws.Cells(lastR, 4)).Value2
    For r = 1 To UBound(sourceData, 1)
        If Len(CellText(sourceData(r, 1))) > 0 And Len(CellText(sourceData(r, 4))) = 0 Then
            sourceData(r, 4) = CAND_SOURCE_COMMON
            changed = True
        End If
    Next r
    If changed Then ws.Range(ws.Cells(2, 1), ws.Cells(lastR, 4)).Value2 = sourceData
End Sub

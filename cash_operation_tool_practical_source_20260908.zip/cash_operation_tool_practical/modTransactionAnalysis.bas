Attribute VB_Name = "modTransactionAnalysis"
Option Explicit

Private Const ANALYSIS_BUFFER_ROWS As Long = 1000
Private Const ANALYSIS_CHECK_MAX_DETAIL_CHARS As Long = 700000
Private Const ANALYSIS_CONTEXT_TEXT_MAX As Long = 700
Private Const VALIDATION_CHECK_CHUNK_ROWS As Long = 2000
Private Const VALIDATION_CHECK_DIRECT_ROWS As Long = 64
Private Const TRANSACTION_ATOMIC_SHEET_COUNT As Long = 11
Private Const TRANSACTION_ATOMIC_DETAIL_LAST_COL As Long = 12
Private Const TRANSACTION_ATOMIC_SNAPSHOT_COPIES As Long = 3
Private Const TRANSACTION_ATOMIC_CASH_STATE_ROWS As Long = 9
Private Const TRANSACTION_OPERATION_PEAK_SNAPSHOT_SETS As Long = 2
Private Const ALLOCATION_AMBIGUITY_MEMO_MARKER As String = _
    "[����] ����������̍��z�A��"

Private Type TransactionAnalysisSheetSnapshot
    SheetName As String
    LabelText As String
    LastColumn As Long
    MaximumDataRows As Long
    HeaderData As Variant
    Data As Variant
    LastRow As Long
    Visibility As Long
    WasProtected As Boolean
End Type

Private Type TransactionCashViewSnapshot
    Captured As Boolean
    PanelData As Variant
    Data As Variant
    DataLastRow As Long
    Visibility As Long
    WasProtected As Boolean
    WorkCashVisibility As Long
    WorkCashWasProtected As Boolean
    WasActive As Boolean
    SelectionAddress As String
    ActiveCellAddress As String
    WindowStateCaptured As Boolean
    FreezePanes As Boolean
    SplitRow As Long
    SplitColumn As Long
    ScrollRow As Long
    ScrollColumn As Long
    Zoom As Long
    EntryActiveSheetName As String
    EntryActiveCellAddress As String
End Type

Private mAnalysisRowEvidenceCache As Object
Private mAnalysisInheritanceDate As Variant
Private mAnalysisOperationActive As Boolean
Private mAnalysisOperationName As String
Private mAnalysisOperationSheets() As TransactionAnalysisSheetSnapshot
Private mAnalysisOperationCash As TransactionCashViewSnapshot
Private mAnalysisOperationDetailReviewsDirty As Boolean
Private mAnalysisOperationWorkbookWasSaved As Boolean
Private mAnalysisOperationEntryEvents As Boolean
Private mAnalysisOperationEntryInheritanceDate As Variant
Private mAnalysisOperationConfirmedWorkloadRows As Double
Private mAnalysisOperationPeakSnapshotCellWork As Double
Private mAnalysisOperationAllocationSnapshot As Variant
Private mAnalysisOperationAllocationSnapshotLastRow As Long
Private mAnalysisOperationAllocationSnapshotDigest As String
Private mAnalysisOperationAllocationSnapshotCaptured As Boolean

Public Function ShiftAnalysisHeaders() As Variant
    ShiftAnalysisHeaders = Array( _
        "�]��", "�X�R�A", "�ƍ��`��", "���n��", "�������x", "�o��", "���z�ƍ�", "���z��", _
        "�o����", "�o������", "�o������", "�o������", "�o����s", "�o���x�X", "�o���Ȗ�", _
        "�o�������ԍ�", "�o���z", "�o���E�v", "������", "��������", "��������", "��������", _
        "������s", "�����x�X", "�����Ȗ�", "���������ԍ�", "�����z", "�����E�v", "���藝�R", _
        "�m�F��", "�m�F����", "���L�[", "�o�����ID", "�������ID")
End Function

Public Function UnknownAnalysisHeaders() As Variant
    UnknownAnalysisHeaders = Array( _
        "�m�F�D��x", "�X�R�A", "�s���敪", "���t", "����", "�������x", "����", "����", _
        "��s", "�x�X", "�Ȗ�", "�����ԍ�", "����", "�o��", "�戵�X", "�@��", "�E�v", _
        "��⌏���i�S/�m�F�ρj", "�ō����]��", "���o���R", "�m�F��", "�m�F����", "�o�^��", _
        "���ID", "����ID", "�m�F�L�[")
End Function

Public Sub SetupTransactionAnalysisSheets(Optional ByVal preserveVisibility As Boolean = False)
    Dim shiftVisible As XlSheetVisibility, flowVisible As XlSheetVisibility
    Dim unknownVisible As XlSheetVisibility
    Dim ws As Worksheet
    Dim convergenceDetail As String
    Dim cleanupErrorNumber As Long
    Dim cleanupErrorDescription As String, cleanupErrorSource As String
    Dim errorNumber As Long, errorDescription As String, errorSource As String

    On Error GoTo EH

    If preserveVisibility Then
        shiftVisible = GetSheet(SH_ANALYSIS_SHIFT).Visible
        flowVisible = GetSheet(SH_ANALYSIS_FLOW).Visible
        unknownVisible = GetSheet(SH_ANALYSIS_UNKNOWN).Visible
    End If

    Set ws = GetSheet(SH_ANALYSIS_SHIFT)
    PrepareShiftAnalysisSheet ws
    Set ws = GetSheet(SH_ANALYSIS_FLOW)
    PrepareAdvancedFlowAnalysisSheet ws
    Set ws = GetSheet(SH_ANALYSIS_UNKNOWN)
    PrepareUnknownAnalysisSheet ws
    SetupAnalysisWorkspaceSheets preserveVisibility

    If preserveVisibility Then
        GetSheet(SH_ANALYSIS_SHIFT).Visible = shiftVisible
        GetSheet(SH_ANALYSIS_FLOW).Visible = flowVisible
        GetSheet(SH_ANALYSIS_UNKNOWN).Visible = unknownVisible
    End If
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    If IsTransactionAnalysisRecoveryFatal(errorNumber, errorSource) Then
        Call TryStopTransactionAnalysisEventsForBookWrites(convergenceDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    On Error Resume Next
    Err.Clear
    ProtectTransactionAnalysisSheets False
    cleanupErrorNumber = Err.Number
    cleanupErrorSource = Err.Source
    cleanupErrorDescription = Err.Description
    Err.Clear
    On Error GoTo 0
    If IsTransactionAnalysisRecoveryFatal( _
           cleanupErrorNumber, cleanupErrorSource) Then
        Call TryStopTransactionAnalysisEventsForBookWrites(convergenceDetail)
        Err.Raise cleanupErrorNumber, cleanupErrorSource, _
                  cleanupErrorDescription
    End If
    On Error Resume Next
    If SheetExists(SH_WORK_ANALYSIS_GROUP) Then _
        SetSheetVeryHiddenSafe GetSheet(SH_WORK_ANALYSIS_GROUP)
    If preserveVisibility Then
        GetSheet(SH_ANALYSIS_SHIFT).Visible = shiftVisible
        GetSheet(SH_ANALYSIS_FLOW).Visible = flowVisible
        GetSheet(SH_ANALYSIS_UNKNOWN).Visible = unknownVisible
    End If
    On Error GoTo 0
    Err.Raise errorNumber, "SetupTransactionAnalysisSheets", errorSource & " / " & errorDescription
End Sub

Public Function AnalysisOperationTransactionIsActive() As Boolean
    AnalysisOperationTransactionIsActive = mAnalysisOperationActive
End Function

Public Function AnalysisOperationConfirmedWorkloadRows() As Double
    If Not mAnalysisOperationActive Then _
        Err.Raise vbObjectError + 4686, _
                  "AnalysisOperationConfirmedWorkloadRows", _
                  "���͑���g�����U�N�V�������J�n����Ă��܂���B"
    AnalysisOperationConfirmedWorkloadRows = _
        mAnalysisOperationConfirmedWorkloadRows
End Function

Public Sub BeginAnalysisOperationTransaction(ByVal operationName As String)
    '��������\�ȂǁA�m�F�l�̕ύX����䒠�m��܂ŕ���module�ւ܂����鑀����A
    '���p�҂��ҏW����O��1���_�ւ܂Ƃ߂Ė߂���悤�O���őޔ�����B
    Dim recoveryLatchSet As Boolean
    Dim confirmedWorkloadRows As Double
    Dim atomicSnapshotCellWork As Double
    Dim eventStateDetail As String
    Dim errorNumber As Long, errorDescription As String, errorSource As String

    On Error GoTo EH
    If mAnalysisOperationActive Then _
        Err.Raise vbObjectError + 4678, "BeginAnalysisOperationTransaction", _
                  "�ʂ̕��͑���g�����U�N�V���������s���ł��B"
    If Not TryGetRollbackRecoveryLatch(recoveryLatchSet) Then _
        Err.Raise vbObjectError + 4679, "BeginAnalysisOperationTransaction", _
                  "���[���o�b�N�v������Ԃ��m�F�ł��܂���B"
    If recoveryLatchSet Then _
        Err.Raise vbObjectError + 4679, "BeginAnalysisOperationTransaction", _
                  "�O��̃��[���o�b�N�v������Ԃ��c���Ă��邽�߁A���͑�����J�n�ł��܂���B"
    If ThisWorkbook.ReadOnly Then _
        Err.Raise vbObjectError + 4680, "BeginAnalysisOperationTransaction", _
                  "�ǂݎ���p�̂��߁A���͔��f��ۑ��ł��܂���B"
    If Not SheetExists(SH_OUTPUT_TX) Or Not SheetExists(SH_WORK_CASH) Then _
        Err.Raise vbObjectError + 4681, "BeginAnalysisOperationTransaction", _
                  "��������\�܂��͗\�莑���\������܂���B"
    If Len(Trim$(operationName)) = 0 Then operationName = "���͔��f�̕ۑ�"

    '��i��Commit���͊O���ޔ���ێ������܂܁A��3�\�Ǝ蓮���̓����ޔ������B
    '�O���ޔ�2�g�����𓯎��ێ��s�[�N�Ƃ��ē����Ŋm�F���AC3�ύX��͊m�F���Ȃ��B
    If Not RequireManualFlowMutationCapacity(operationName) Then _
        Err.Raise 18, "BeginAnalysisOperationTransaction", _
                  "���p�҂��蓮���̗e�ʊm�F���������܂����B"
    InitializeTransactionAnalysisAtomicSheets mAnalysisOperationSheets
    atomicSnapshotCellWork = _
        TransactionAnalysisAtomicSnapshotCellWork(mAnalysisOperationSheets, True)
    mAnalysisOperationPeakSnapshotCellWork = _
        TransactionAnalysisOperationPeakSnapshotCellWork(atomicSnapshotCellWork)
    If Not ConfirmAnalysisReviewOperationCapacity( _
               operationName, confirmedWorkloadRows, _
               additionalSnapshotCellWork:=mAnalysisOperationPeakSnapshotCellWork) Then _
        Err.Raise 18, "BeginAnalysisOperationTransaction", _
                  "���p�҂����͔��f�̗e�ʊm�F���������܂����B"

    mAnalysisOperationName = operationName
    mAnalysisOperationWorkbookWasSaved = ThisWorkbook.Saved
    If Not TryGetTransactionAnalysisEnableEvents( _
               mAnalysisOperationEntryEvents, eventStateDetail) Then _
        Err.Raise vbObjectError + 4701, "BeginAnalysisOperationTransaction", _
                  "Excel�C�x���g�̊J�n��Ԃ��擾�ł��܂���ł����B " & eventStateDetail
    mAnalysisOperationEntryInheritanceDate = mAnalysisInheritanceDate
    CaptureTransactionAnalysisAtomicSnapshot _
        mAnalysisOperationSheets, True, mAnalysisOperationCash
    CaptureAllocationLedgerTransactionSnapshot _
        mAnalysisOperationAllocationSnapshot, _
        mAnalysisOperationAllocationSnapshotLastRow, _
        mAnalysisOperationAllocationSnapshotDigest
    mAnalysisOperationAllocationSnapshotCaptured = True
    mAnalysisOperationDetailReviewsDirty = AnalysisDetailReviewDirtySnapshot()
    mAnalysisOperationConfirmedWorkloadRows = confirmedWorkloadRows
    mAnalysisOperationActive = True
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    ResetAnalysisOperationTransactionState
    Err.Raise errorNumber, "BeginAnalysisOperationTransaction", errorDescription
End Sub

Public Sub CommitAnalysisOperationPendingReviews( _
        Optional ByVal reasonText As String = "��������\���番�͔��f��ۑ�")
    If Not mAnalysisOperationActive Then _
        Err.Raise vbObjectError + 4682, _
                  "CommitAnalysisOperationPendingReviews", _
                  "���͑���g�����U�N�V�������J�n����Ă��܂���B"
    CommitPendingAnalysisReviews _
        False, reasonText, True, mAnalysisOperationConfirmedWorkloadRows, _
        False, mAnalysisOperationPeakSnapshotCellWork
End Sub

Public Sub CommitAnalysisOperationTransaction()
    Dim recoveryLatchSet As Boolean
    Dim currentEvents As Boolean, eventStateDetail As String
    If Not mAnalysisOperationActive Then _
        Err.Raise vbObjectError + 4683, _
                  "CommitAnalysisOperationTransaction", _
                  "���͑���g�����U�N�V�������J�n����Ă��܂���B"
    If Not TryGetRollbackRecoveryLatch(recoveryLatchSet) Then _
        Err.Raise vbObjectError + 4684, _
                  "CommitAnalysisOperationTransaction", _
                  "���[���o�b�N�v������Ԃ�ǂݕԂ��Ȃ����߁A���͑�����m��ł��܂���B"
    If recoveryLatchSet Then _
        Err.Raise vbObjectError + 4684, _
                  "CommitAnalysisOperationTransaction", _
                  "���[���o�b�N�v������Ԃ����邽�߁A���͑�����m��ł��܂���B"
    If Not TryGetTransactionAnalysisEnableEvents( _
               currentEvents, eventStateDetail) Then _
        Err.Raise vbObjectError + 4702, "CommitAnalysisOperationTransaction", _
                  "Excel�C�x���g��Ԃ��m�F�ł��܂���ł����B " & eventStateDetail
    If currentEvents <> mAnalysisOperationEntryEvents Then _
        Err.Raise vbObjectError + 4687, _
                  "CommitAnalysisOperationTransaction", _
                  "Excel�C�x���g��Ԃ�����J�n���ƈ�v���Ȃ����߁A���͑�����m��ł��܂���B"
    If HasPendingAnalysisReviewChanges() Then _
        Err.Raise vbObjectError + 4688, _
                  "CommitAnalysisOperationTransaction", _
                  "���ۑ��̕��͔��f���c���Ă��邽�߁A���͑�����m��ł��܂���B"
    ResetAnalysisOperationTransactionState
End Sub

Public Function RollbackAnalysisOperationTransaction( _
        ByRef detailText As String) As Boolean
    Dim restoreOK As Boolean
    Dim recoveryLatchSet As Boolean, latchReadSucceeded As Boolean
    Dim recoveryConfirmed As Boolean, safeToRestoreEntry As Boolean
    Dim recoveryEnforcementFailed As Boolean
    Dim recoveryAttempted As Boolean
    Dim applicationStateConfirmed As Boolean
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim eventStateDetail As String
    Dim recoveryEventDetail As String
    Dim postEnforceEventDetail As String, convergenceDetail As String
    Dim finalRecoveryEventDetail As String
    Dim eventsReadyForRollback As Boolean

    If Not mAnalysisOperationActive Then
        AppendTransactionRollbackDetail detailText, _
            "���͑���g�����U�N�V�����̑ޔ�������܂���B"
        Exit Function
    End If

    restoreOK = True
    eventsReadyForRollback = _
        TrySetTransactionAnalysisEnableEventsExact(False, eventStateDetail)
    If Not eventsReadyForRollback Then
        restoreOK = False
        AppendTransactionRollbackDetail detailText, _
            "Excel�C�x���g���~���ēǖ߂��m�F�ł��܂���: " & eventStateDetail
        AppendTransactionRollbackDetail detailText, _
            "�C�x���g��~���m�F�̂��߁A�ޔ�l���u�b�N�֍ď����݂��܂���B"
    End If

    If eventsReadyForRollback Then
        On Error Resume Next
        Err.Clear
        If Not RestoreTransactionAnalysisAtomicSnapshot( _
                   mAnalysisOperationSheets, _
                   mAnalysisOperationDetailReviewsDirty, _
                   mAnalysisOperationCash, detailText) Then _
            restoreOK = False
        errorNumber = Err.Number
        errorSource = Err.Source
        errorDescription = Err.Description
        Err.Clear
        On Error GoTo 0
        If IsTransactionAnalysisRecoveryFatal(errorNumber, errorSource) Then
            Call TryStopTransactionAnalysisEventsForBookWrites( _
                convergenceDetail)
            Err.Raise errorNumber, errorSource, errorDescription
        End If
        On Error Resume Next
        If errorNumber <> 0 Then
            restoreOK = False
            AppendTransactionRollbackDetail detailText, _
                "���͑���̕����G���[: " & errorDescription
        End If
        If mAnalysisOperationAllocationSnapshotCaptured Then
            RestoreAllocationLedgerTransactionSnapshot _
                mAnalysisOperationAllocationSnapshot, _
                mAnalysisOperationAllocationSnapshotLastRow, _
                mAnalysisOperationAllocationSnapshotDigest
            If Err.Number <> 0 Then
                restoreOK = False
                AppendTransactionRollbackDetail detailText, _
                    "�z�������̕����G���[: " & Err.Description
            End If
            Err.Clear
        End If

        latchReadSucceeded = TryGetRollbackRecoveryLatch(recoveryLatchSet)
        If Not latchReadSucceeded Then
            restoreOK = False
            AppendTransactionRollbackDetail detailText, _
                "���[���o�b�N�v������Ԃ��m�F�ł��܂���B"
        ElseIf recoveryLatchSet Then
            restoreOK = False
            AppendTransactionRollbackDetail detailText, _
                "�����̕��͏����Ń��[���o�b�N�v������Ԃ��ݒ肳��܂����B"
        End If
        mAnalysisInheritanceDate = mAnalysisOperationEntryInheritanceDate
        ResetAnalysisEvidenceCache
        If restoreOK And mAnalysisOperationWorkbookWasSaved Then
            ThisWorkbook.Saved = True
            If Err.Number <> 0 Then
                restoreOK = False
                AppendTransactionRollbackDetail detailText, _
                    "�u�b�N�ۑ���Ԃ𕜌��ł��܂���: " & Err.Description
            End If
            Err.Clear
        End If
        On Error GoTo 0
    End If

    If Not restoreOK Then
        'Recovery�̋L�^���u�b�N�ւ̏����݂ł���B����̃C�x���g��~��
        '���s�����ꍇ�͂����ōĊm�F���AFalse��ǖ߂������������s����B
        If Not eventsReadyForRollback Then
            eventsReadyForRollback = _
                TrySetTransactionAnalysisEnableEventsExact( _
                    False, recoveryEventDetail)
            If eventsReadyForRollback Then
                AppendTransactionRollbackDetail detailText, _
                    "�v�����L�^�O��Excel�C�x���g��~���Ċm�F���܂����B"
            Else
                AppendTransactionRollbackDetail detailText, _
                    "Excel�C�x���g��~���Ċm�F�ł����A" & _
                    "�v������Ԃ̏����݂����S�̂��ߌ�����܂���: " & _
                    recoveryEventDetail
            End If
        End If
        If eventsReadyForRollback Then
            recoveryAttempted = True
            On Error Resume Next
            Err.Clear
            EnforceRollbackRecoveryState detailText
            errorNumber = Err.Number
            errorDescription = Err.Description
            Err.Clear
            On Error GoTo 0
            'Enforce�̌��ʂ�ۑ����������False���Ċm�肷��B���s����
            '����Recovery�l�̓ǎ��E�\�������݁E�J�n�l�����֐i�܂Ȃ��B
            eventsReadyForRollback = _
                TryStopTransactionAnalysisEventsForBookWrites( _
                    postEnforceEventDetail)
            If errorNumber <> 0 Then
                recoveryEnforcementFailed = True
                AppendTransactionRollbackDetail detailText, _
                    "�v������Ԃ̋L�^�G���[: Err " & _
                    CStr(errorNumber) & " " & errorDescription
            ElseIf eventsReadyForRollback Then
                recoveryConfirmed = _
                    TransactionAnalysisRecoveryStateIsConfirmedExact(detailText)
                If recoveryConfirmed Then
                    applicationStateConfirmed = _
                        TransactionAnalysisApplicationStateAllowsEntryRestore( _
                            True, detailText)
                End If
                If applicationStateConfirmed Then
                    eventsReadyForRollback = _
                        TryStopTransactionAnalysisEventsForBookWrites( _
                            finalRecoveryEventDetail)
                End If
            Else
                AppendTransactionRollbackDetail detailText, _
                    "Recovery�������Excel�C�x���g��~���m�F�ł��Ȃ����߁A" & _
                    "������Ԃ̓ǎ��E��ԕ\���E�J�n�l�������s���܂���: " & _
                    postEnforceEventDetail
            End If
            eventsReadyForRollback = _
                TryStopTransactionAnalysisEventsForBookWrites( _
                    convergenceDetail)
            Err.Raise vbObjectError + 5195, _
                      "TransactionAnalysisRecoveryFatal/RollbackAnalysisOperationTransaction", _
                      detailText
        End If
    End If

    safeToRestoreEntry = Not recoveryEnforcementFailed And _
                         Not recoveryAttempted And _
                         eventsReadyForRollback And _
                         (restoreOK Or recoveryConfirmed)
    If safeToRestoreEntry Then
        eventsReadyForRollback = _
            TryStopTransactionAnalysisEventsForBookWrites(eventStateDetail)
        safeToRestoreEntry = eventsReadyForRollback
    End If
    If safeToRestoreEntry Then
        safeToRestoreEntry = _
            TransactionAnalysisApplicationStateAllowsEntryRestore( _
                mAnalysisOperationEntryEvents, detailText)
    End If
    If safeToRestoreEntry Then
        If Not TryRestoreTransactionAnalysisEnableEvents( _
                   mAnalysisOperationEntryEvents, _
                   "���͑���g�����U�N�V�����̃��[���o�b�N", _
                   eventStateDetail) Then
            restoreOK = False
            AppendTransactionRollbackDetail detailText, _
                "Excel�C�x���g��Ԃ𕜌��ł��܂���: " & eventStateDetail
        End If
    ElseIf TryStopTransactionAnalysisEventsForBookWrites(convergenceDetail) Then
        restoreOK = False
        AppendTransactionRollbackDetail detailText, _
            "���[���o�b�N�܂���Recovery�������m�F�ł��Ȃ����߁A" & _
            "�J�n���C�x���g�l�֖߂���False�Œ�~���܂����B"
    Else
        restoreOK = False
        AppendTransactionRollbackDetail detailText, _
            "���S��Ԃ������m�F�ł����AExcel�C�x���g��False�����ɂ�" & _
            "���s���܂����B���ݏ�Ԃ͕s���ł�: " & convergenceDetail
    End If

    '���s���͍Ď��s�ł���悤�A�ޔ��ƊJ�n��Ԃ�ێ�����B
    If restoreOK Then ResetAnalysisOperationTransactionState
    RollbackAnalysisOperationTransaction = restoreOK
End Function

Private Sub ResetAnalysisOperationTransactionState()
    mAnalysisOperationActive = False
    mAnalysisOperationName = vbNullString
    Erase mAnalysisOperationSheets
    mAnalysisOperationCash.Captured = False
    mAnalysisOperationCash.PanelData = Empty
    mAnalysisOperationCash.Data = Empty
    mAnalysisOperationCash.SelectionAddress = vbNullString
    mAnalysisOperationCash.ActiveCellAddress = vbNullString
    mAnalysisOperationCash.EntryActiveSheetName = vbNullString
    mAnalysisOperationCash.EntryActiveCellAddress = vbNullString
    mAnalysisOperationDetailReviewsDirty = False
    mAnalysisOperationWorkbookWasSaved = False
    mAnalysisOperationEntryEvents = False
    mAnalysisOperationEntryInheritanceDate = Empty
    mAnalysisOperationConfirmedWorkloadRows = 0#
    mAnalysisOperationPeakSnapshotCellWork = 0#
    mAnalysisOperationAllocationSnapshot = Empty
    mAnalysisOperationAllocationSnapshotLastRow = 0
    mAnalysisOperationAllocationSnapshotDigest = vbNullString
    mAnalysisOperationAllocationSnapshotCaptured = False
End Sub

Public Sub BuildTransactionAnalysisSheetsCore( _
        ByVal activateAfter As Boolean, _
        Optional ByVal capacityConfirmed As Boolean = False, _
        Optional ByRef confirmedAnalysisWorkloadRows As Double = 0#, _
        Optional ByVal allowLateCapacityPrompt As Boolean = True, _
        Optional ByVal outerSnapshotCellWork As Double = 0#)
    Dim wsSource As Worksheet, wsShift As Worksheet, wsFlow As Worksheet, wsUnknown As Worksheet
    Dim sourceData As Variant
    Dim withdrawalRows() As Long, depositRows() As Long
    Dim unknownWithdrawalRows() As Long, unknownDepositRows() As Long
    Dim componentWithdrawalRows() As Long, componentDepositRows() As Long
    Dim depositAmounts() As Double, depositSortRows() As Long
    Dim withdrawalCount As Long, depositCount As Long, sourceRowCount As Long
    Dim componentWithdrawalCount As Long, componentDepositCount As Long
    Dim shiftCount As Long, writtenShiftCount As Long, flowCount As Long
    Dim unknownCount As Long, writtenUnknownCount As Long
    Dim unknownWithdrawalCount As Long, unknownDepositCount As Long
    Dim minAmount As Double, unknownMinAmount As Double
    Dim absoluteTolerance As Double, rateTolerance As Double
    Dim dayWindow As Long
    Dim shiftReviews As Object, flowReviews As Object, unknownReviews As Object
    Dim storedReviews As Object
    Dim candidateCountByTx As Object, bestScoreByTx As Object, bestRatingByTx As Object
    Dim confirmedCountByTx As Object, unknownContextByTx As Object
    Dim allocationIndex As Object
    Dim lastR As Long, r As Long
    Dim detailText As String, personIntegrityProblems As String
    Dim settingsSignature As String, unknownSettingsSignature As String
    Dim errorNumber As Long, errorSource As String
    Dim errorDescription As String, rollbackDetail As String
    Dim preferCashPanel As Boolean
    Dim plannedUnknownRows As Long
    Dim atomicSheets() As TransactionAnalysisSheetSnapshot
    Dim cashSnapshot As TransactionCashViewSnapshot
    Dim atomicSnapshotCellWork As Double
    Dim operationSnapshotCellWork As Double
    Dim cashSnapshotNeeded As Boolean
    Dim atomicSnapshotsCaptured As Boolean, atomicMutationStarted As Boolean
    Dim detailReviewsDirty As Boolean
    Dim rollbackOK As Boolean, recoveryConfirmed As Boolean
    Dim safeToRestoreEntry As Boolean
    Dim applicationStateConfirmed As Boolean
    Dim recoveryLatchSet As Boolean, latchReadSucceeded As Boolean
    Dim entryEvents As Boolean, entryEventsCaptured As Boolean
    Dim eventsReadyForRollback As Boolean, eventStateDetail As String
    Dim recoveryErrorNumber As Long, recoveryErrorDescription As String
    Dim rollbackErrorNumber As Long, rollbackErrorSource As String
    Dim rollbackErrorDescription As String
    Dim recoveryEnforcementFailed As Boolean
    Dim postEnforceEventDetail As String, convergenceDetail As String
    Dim finalRecoveryEventDetail As String
    Dim workbookWasSaved As Boolean, workbookSavedCaptured As Boolean
    Dim entryInheritanceDate As Variant
    Dim allocationSnapshot As Variant
    Dim allocationSnapshotLastRow As Long
    Dim allocationSnapshotDigest As String
    Dim allocationSnapshotCaptured As Boolean

    If outerSnapshotCellWork < 0# Or _
       outerSnapshotCellWork > 2147483647# * 16# Then _
        Err.Raise vbObjectError + 4685, "BuildTransactionAnalysisSheetsCore", _
                  "������͂̊O���ޔ�e�ʂ��s���ł��B"
    If Not capacityConfirmed Then
        If Not RequireOutputBuildCapacity("���[�E���͂̍X�V", activateAfter, False, False, _
                                          True, False, False) Then _
            Err.Raise 18, "BuildTransactionAnalysisSheetsCore", _
                      "���p�҂����[�E���̗͂e�ʊm�F���������܂����B"
        If Not RequireManualFlowMutationCapacity("������͂̍X�V") Then _
            Err.Raise 18, "BuildTransactionAnalysisSheetsCore", _
                      "���p�҂��蓮���̗e�ʊm�F���������܂����B"
        capacityConfirmed = True
    End If

    If Not ActiveSheet Is Nothing Then _
        preferCashPanel = (ActiveSheet.Name = SH_OUTPUT_TX)
    cashSnapshotNeeded = SheetExists(SH_OUTPUT_TX) And SheetExists(SH_WORK_CASH) And _
                         (preferCashPanel Or activateAfter)
    InitializeTransactionAnalysisAtomicSheets atomicSheets
    atomicSnapshotCellWork = _
        TransactionAnalysisAtomicSnapshotCellWork(atomicSheets, cashSnapshotNeeded)
    operationSnapshotCellWork = atomicSnapshotCellWork + outerSnapshotCellWork
    If operationSnapshotCellWork < atomicSnapshotCellWork Or _
       operationSnapshotCellWork > 2147483647# * 16# Then _
        Err.Raise vbObjectError + 4685, "BuildTransactionAnalysisSheetsCore", _
                  "������͂̓����ޔ�e�ʂ����S�͈͂𒴂��Ă��܂��B"
    If Not ConfirmAnalysisReviewOperationCapacity( _
               "������͂̍X�V", confirmedAnalysisWorkloadRows, _
               allowUserConfirmation:=allowLateCapacityPrompt, _
               additionalSnapshotCellWork:=operationSnapshotCellWork) Then _
        Err.Raise 18, "BuildTransactionAnalysisSheetsCore", _
                  "���p�҂����͔��f�̗e�ʊm�F���������܂����B"

    '������ɕی�E��\���Edirty��Ԃ�ύX���Ȃ��悤�A�S�����e�ʌ����̌��EH��L���ɂ���B
    On Error GoTo EH
    '�m�F�L�^�̓����E�ޔ����␶�����O�ɁA�������{�Ɩ��ׂ̐l��������������B
    '��̏����Z�b�g�A�b�v��validator���Ő�����0���Ƃ���True�ɂȂ�B
    If Not ValidateCorePersonIntegrity(personIntegrityProblems, False) Then
        If Len(Trim$(personIntegrityProblems)) = 0 Then _
            personIntegrityProblems = "�l�������������Ɏ��s���܂����B"
        Err.Raise vbObjectError + 4627, "BuildTransactionAnalysisSheetsCore", _
                  "�l�����̐������ɖ�肪���邽�߁A������͂��J�n�ł��܂���B" & _
                  vbCrLf & personIntegrityProblems
    End If

    If Not ValidateTransactionAnalysisSettings(detailText) Then _
        Err.Raise vbObjectError + 4600, "BuildTransactionAnalysisSheetsCore", detailText
    ReadTransactionAnalysisSettings minAmount, dayWindow, absoluteTolerance, rateTolerance, _
                                    unknownMinAmount

    Set wsShift = GetSheet(SH_ANALYSIS_SHIFT)
    Set wsFlow = GetSheet(SH_ANALYSIS_FLOW)
    Set wsUnknown = GetSheet(SH_ANALYSIS_UNKNOWN)
    Set wsSource = GetSheet(SH_WORK_TX)
    EnsureExistingAnalysisReviewBounds wsShift, "�����V�t�g���"
    EnsureExistingAnalysisReviewBounds wsFlow, "�����t���[�ǐ�"
    EnsureExistingAnalysisReviewBounds wsUnknown, "�s�����o��"

    '���������͊m�F�����E�䒠�ۑ��E�o�͒u���������\�֘A������B
    '�ŏ��̏����݂��O�ɁA�ύX������S�\�Ɛ���UI�𓯂����_�őޔ�����B
    workbookWasSaved = ThisWorkbook.Saved
    workbookSavedCaptured = True
    If Not TryGetTransactionAnalysisEnableEvents(entryEvents, eventStateDetail) Then _
        Err.Raise vbObjectError + 4703, "BuildTransactionAnalysisSheetsCore", _
                  "Excel�C�x���g�̊J�n��Ԃ��擾�ł��܂���ł����B " & eventStateDetail
    entryEventsCaptured = True
    entryInheritanceDate = mAnalysisInheritanceDate
    CaptureTransactionAnalysisAtomicSnapshot atomicSheets, cashSnapshotNeeded, cashSnapshot
    CaptureAllocationLedgerTransactionSnapshot allocationSnapshot, _
        allocationSnapshotLastRow, allocationSnapshotDigest
    allocationSnapshotCaptured = True
    detailReviewsDirty = AnalysisDetailReviewDirtySnapshot()
    atomicSnapshotsCaptured = True

    ResetAnalysisEvidenceCache
    mAnalysisInheritanceDate = GetCfgDateValue(ROW_CFG_INHERITANCE_DATE)
    settingsSignature = AnalysisSettingsSignature(minAmount, dayWindow, absoluteTolerance, rateTolerance)
    unknownSettingsSignature = AnalysisSettingsSignature(unknownMinAmount, dayWindow, _
                                                         absoluteTolerance, rateTolerance) & _
                               "|SCOPE=UNKNOWN"

    '��������\�㕔�ōX�V�����m�F�L�^��������͌��ʂ֖߂��A�����\�Ɠ������Ă���ĕ��͂���B
    atomicMutationStarted = True
    If preferCashPanel Then SyncCashAnalysisPanelReviewToWorkspace
    SyncAnalysisWorkspaceReviewsToSources
    SyncAnalysisDetailReviewsToSources
    '���ڍׂ̋��X�i�b�v�V���b�g���A��������\�̕\�����p�l�����l���Ō�ɗD�悷��B
    If preferCashPanel Then SyncCashAnalysisPanelReviewToWorkspace
    SyncManualFlowReviewsFromAnalysisSheet True
    '���s3�\�̊m�F���e�Ɋ�������������΁A��␶���E�\�u���E�i���䒠�ۑ����O�ɒ�~����B
    ResolveAnalysisReviewConflicts wsShift, wsFlow
    PersistAnalysisReviewsFromCurrentSheets False, "�ĕ��͑O�̊m�F���e��ۑ�"
    Set shiftReviews = CaptureAnalysisReviews(wsShift, SHIFT_ANALYSIS_STATUS_COL, _
                                               SHIFT_ANALYSIS_MEMO_COL, SHIFT_ANALYSIS_KEY_COL)
    Set flowReviews = CaptureAnalysisReviews(wsFlow, FLOW_ANALYSIS_STATUS_COL, _
                                              FLOW_ANALYSIS_MEMO_COL, FLOW_ANALYSIS_KEY_COL)
    Set unknownReviews = CaptureAnalysisReviews(wsUnknown, UNKNOWN_ANALYSIS_STATUS_COL, _
                                                 UNKNOWN_ANALYSIS_MEMO_COL, UNKNOWN_ANALYSIS_KEY_COL)
    Set storedReviews = CapturePersistentAnalysisReviews()
    Set shiftReviews = MergeStoredAnalysisReviews(shiftReviews, storedReviews)
    Set flowReviews = MergeStoredAnalysisReviews(flowReviews, storedReviews)
    Set unknownReviews = MergeStoredAnalysisReviews(unknownReviews, storedReviews)
    Set candidateCountByTx = CreateObject("Scripting.Dictionary")
    Set bestScoreByTx = CreateObject("Scripting.Dictionary")
    Set bestRatingByTx = CreateObject("Scripting.Dictionary")
    Set confirmedCountByTx = CreateObject("Scripting.Dictionary")
    Set unknownContextByTx = CreateObject("Scripting.Dictionary")
    candidateCountByTx.CompareMode = vbTextCompare
    bestScoreByTx.CompareMode = vbTextCompare
    bestRatingByTx.CompareMode = vbTextCompare
    confirmedCountByTx.CompareMode = vbTextCompare
    unknownContextByTx.CompareMode = vbTextCompare

    lastR = LastDataRowInColumns(wsSource, 1, WORK_TX_COL_PERSON_ID)
    If lastR >= 2 Then
        sourceData = wsSource.Range(wsSource.Cells(2, 1), _
                                    wsSource.Cells(lastR, WORK_TX_COL_PERSON_ID)).Value2
        sourceRowCount = UBound(sourceData, 1)
        ReDim withdrawalRows(1 To sourceRowCount)
        ReDim depositRows(1 To sourceRowCount)
        ReDim componentWithdrawalRows(1 To sourceRowCount)
        ReDim componentDepositRows(1 To sourceRowCount)
        ReDim unknownWithdrawalRows(1 To sourceRowCount)
        ReDim unknownDepositRows(1 To sourceRowCount)
        ValidateAndIndexAnalysisTransactions sourceData, minAmount, withdrawalRows, withdrawalCount, _
                                             depositRows, depositCount, componentWithdrawalRows, _
                                             componentWithdrawalCount, componentDepositRows, _
                                             componentDepositCount
        FilterAnalysisRowsByMinimum sourceData, componentWithdrawalRows, _
                                    componentWithdrawalCount, False, unknownMinAmount, _
                                    unknownWithdrawalRows, unknownWithdrawalCount
        FilterAnalysisRowsByMinimum sourceData, componentDepositRows, _
                                    componentDepositCount, True, unknownMinAmount, _
                                    unknownDepositRows, unknownDepositCount
        Set unknownContextByTx = BuildUnknownContextIndex(sourceData, componentWithdrawalRows, _
                                                           componentWithdrawalCount, componentDepositRows, _
                                                           componentDepositCount)
    End If

    If depositCount > 0 Then
        ReDim depositAmounts(1 To depositCount)
        ReDim depositSortRows(1 To depositCount)
        For r = 1 To depositCount
            depositSortRows(r) = depositRows(r)
            depositAmounts(r) = CDbl(sourceData(depositRows(r), OUT_COL_DEPOSIT))
        Next r
        If depositCount > 1 Then QuickSortAnalysisAmounts depositAmounts, depositSortRows, 1, depositCount
    End If

    If withdrawalCount > 0 And depositCount > 0 Then
        AppProgress "1��1�̎����V�t�g�������O�m�F���Ă��܂�..."
        ProcessShiftCandidates sourceData, withdrawalRows, withdrawalCount, depositAmounts, _
                               depositSortRows, depositCount, dayWindow, absoluteTolerance, rateTolerance, _
                               settingsSignature, False, Nothing, Nothing, candidateCountByTx, _
                               bestScoreByTx, bestRatingByTx, shiftCount
    End If
    If shiftCount > MAX_ANALYSIS_OUTPUT_ROWS Then _
        Err.Raise vbObjectError + 4601, "BuildTransactionAnalysisSheetsCore", _
                  "�����V�t�g��₪���p����i" & Format$(MAX_ANALYSIS_OUTPUT_ROWS, "#,##0") & _
                  "���j�𒴂��܂��B�Œ���z���グ�邩�A���z�����e�����߂Ă��������B"

    '�s�����o���̊m�茏���́A�m�F�ς݌������O�ł����i�Ő�����B

    '�����E���Z�E���i�A���́A�S���Ə�����m�肵�Ă��玑���t���[�ǐՕ\��u��������B
    '�����Ō�ⓝ�v�����Z���A�㑱�̕s�����o���\��1��1�ȊO�̊֘A�𔽉f����B
    plannedUnknownRows = AnalysisUnknownCapacityUpperBound( _
                             unknownWithdrawalCount, unknownDepositCount)
    BuildAdvancedFlowAnalysisSheetCore sourceData, sourceRowCount, withdrawalRows, withdrawalCount, _
                                       depositRows, depositCount, componentWithdrawalRows, _
                                       componentWithdrawalCount, componentDepositRows, _
                                       componentDepositCount, minAmount, dayWindow, absoluteTolerance, _
                                       rateTolerance, settingsSignature, wsFlow, flowReviews, _
                                       candidateCountByTx, bestScoreByTx, bestRatingByTx, flowCount, _
                                       shiftCount, plannedUnknownRows, -1, _
                                       confirmedAnalysisWorkloadRows, False, _
                                       operationSnapshotCellWork
    AppendManualFlowAnalysisRecords sourceData, sourceRowCount, wsFlow, flowReviews, _
                                    candidateCountByTx, bestScoreByTx, bestRatingByTx, flowCount, True
    If flowCount > MAX_ANALYSIS_OUTPUT_ROWS Then _
        Err.Raise vbObjectError + 4605, "BuildTransactionAnalysisSheetsCore", _
                  "�������Ǝ蓮�������킹�������t���[�ǐՂ����p����i" & _
                  Format$(MAX_ANALYSIS_OUTPUT_ROWS, "#,##0") & "���j�𒴂��܂��B"

    '���f�[�^���؁E��������m�F�E�m�F�L�^�̑ޔ����I����Ă���������ʂ�u��������B
    PrepareShiftAnalysisSheet wsShift
    PrepareUnknownAnalysisSheet wsUnknown

    If shiftCount > 0 Then
        AppProgress "1��1�̎����V�t�g���������o���Ă��܂�..."
        ProcessShiftCandidates sourceData, withdrawalRows, withdrawalCount, depositAmounts, _
                               depositSortRows, depositCount, dayWindow, absoluteTolerance, rateTolerance, _
                               settingsSignature, True, wsShift, shiftReviews, candidateCountByTx, _
                               bestScoreByTx, bestRatingByTx, writtenShiftCount
    End If
    If writtenShiftCount <> shiftCount Then _
        Err.Raise vbObjectError + 4603, "BuildTransactionAnalysisSheetsCore", _
                  "�����V�t�g���̎��O�����Əo�͌�������v���܂���B"

    '��������ւ̕������͎��ID���������ł͋��ۂ����A���ʔz�������ŋ��z���v�����؂���B
    ResolveAnalysisReviewConflicts wsShift, wsFlow
    CommitCurrentAnalysisAllocations sourceData, sourceRowCount, wsShift, wsFlow
    '�B���ȕ�������Commit���ŗv�ǉ������֖߂邽�߁A���̌�̏�Ԃ���m�茏�������B
    Set confirmedCountByTx = BuildConfirmedCandidateCountByTransaction(wsShift, wsFlow)
    Set allocationIndex = CaptureAllocationLedgerIndex()

    unknownCount = CountUnresolvedUnknownAnalysisRows( _
                       sourceData, unknownWithdrawalRows, unknownWithdrawalCount, _
                       unknownDepositRows, unknownDepositCount, allocationIndex)
    If unknownCount > MAX_ANALYSIS_OUTPUT_ROWS Then _
        Err.Raise vbObjectError + 4602, "BuildTransactionAnalysisSheetsCore", _
                  "���m�F�̕s�����o�������p����i" & Format$(MAX_ANALYSIS_OUTPUT_ROWS, "#,##0") & _
                  "���j�𒴂��܂��B�s�����o���̍Œ���z���グ�Ă��������B"

    If unknownCount > 0 Then
        WriteUnknownAnalysis sourceData, unknownWithdrawalRows, unknownWithdrawalCount, _
                             unknownDepositRows, unknownDepositCount, _
                             unknownReviews, candidateCountByTx, confirmedCountByTx, allocationIndex, _
                             bestRatingByTx, _
                             unknownContextByTx, unknownSettingsSignature, wsUnknown, writtenUnknownCount
    End If
    If writtenUnknownCount <> unknownCount Then _
        Err.Raise vbObjectError + 4604, "BuildTransactionAnalysisSheetsCore", _
                  "�s�����o���̎��O�����Əo�͌�������v���܂���B"

    FinalizeShiftAnalysisSheet wsShift, shiftCount
    FinalizeUnknownAnalysisSheet wsUnknown, unknownCount
    BuildAnalysisWorkspaceCore "������͂̍č\�z", _
                               confirmedAnalysisWorkloadRows, False, _
                               operationSnapshotCellWork
    If Not ConfirmAnalysisReviewOperationCapacity( _
               "�ĕ��͌��ʂ̔��f�䒠�ۑ�", confirmedAnalysisWorkloadRows, _
               allowUserConfirmation:=False, _
               additionalSnapshotCellWork:=operationSnapshotCellWork) Then _
        Err.Raise 18, "BuildTransactionAnalysisSheetsCore", _
                  "���p�҂����͔��f�䒠�̗e�ʊm�F���������܂����B"
    PersistAnalysisReviewsFromCurrentSheets True, vbNullString
    SetSheetVeryHiddenSafe wsShift
    SetSheetVeryHiddenSafe wsFlow
    SetSheetVeryHiddenSafe wsUnknown
    SetSheetVeryHiddenSafe GetSheet(SH_ANALYSIS_RESULT)
    If activateAfter Then BuildCashAnalysisViewCore True, False, capacityConfirmed
    ResetAnalysisEvidenceCache
    mAnalysisInheritanceDate = Empty
    Exit Sub
EH:
    errorNumber = Err.Number
    errorSource = Err.Source
    errorDescription = Err.Description
    If IsTransactionAnalysisRecoveryFatal(errorNumber, errorSource) Then
        Call TryStopTransactionAnalysisEventsForBookWrites(convergenceDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    rollbackOK = True
    safeToRestoreEntry = Not atomicMutationStarted
    If atomicMutationStarted And atomicSnapshotsCaptured Then
        If entryEventsCaptured Then
            eventsReadyForRollback = _
                TrySetTransactionAnalysisEnableEventsExact(False, eventStateDetail)
        End If
        If Not eventsReadyForRollback Then
            rollbackOK = False
            If entryEventsCaptured Then
                AppendTransactionRollbackDetail rollbackDetail, _
                    "Excel�C�x���g���~���ēǖ߂��m�F�ł��܂���: " & eventStateDetail
            Else
                AppendTransactionRollbackDetail rollbackDetail, _
                    "Excel�C�x���g�̊J�n��Ԃ����擾�ł��B"
            End If
            AppendTransactionRollbackDetail rollbackDetail, _
                "�C�x���g��~���m�F�̂��߁A�ޔ�l���u�b�N�֍ď����݂��܂���B"
        Else
            On Error Resume Next
            Err.Clear
            rollbackOK = RestoreTransactionAnalysisAtomicSnapshot( _
                             atomicSheets, detailReviewsDirty, cashSnapshot, rollbackDetail)
            rollbackErrorNumber = Err.Number
            rollbackErrorSource = Err.Source
            rollbackErrorDescription = Err.Description
            Err.Clear
            On Error GoTo 0
            If IsTransactionAnalysisRecoveryFatal( _
                   rollbackErrorNumber, rollbackErrorSource) Then
                Call TryStopTransactionAnalysisEventsForBookWrites( _
                    convergenceDetail)
                Err.Raise rollbackErrorNumber, rollbackErrorSource, _
                          rollbackErrorDescription
            End If
            On Error Resume Next
            If allocationSnapshotCaptured Then
                RestoreAllocationLedgerTransactionSnapshot allocationSnapshot, _
                    allocationSnapshotLastRow, allocationSnapshotDigest
                If Err.Number <> 0 Then
                    rollbackOK = False
                    AppendTransactionRollbackDetail rollbackDetail, _
                        "�z�������̕����G���[: " & Err.Description
                End If
                Err.Clear
            End If
            latchReadSucceeded = TryGetRollbackRecoveryLatch(recoveryLatchSet)
            If Not latchReadSucceeded Or recoveryLatchSet Then
                rollbackOK = False
                If Not latchReadSucceeded Then
                    AppendTransactionRollbackDetail rollbackDetail, _
                        "�v�������b�`�̓ǖ߂��Ɏ��s���܂����B"
                Else
                    AppendTransactionRollbackDetail rollbackDetail, _
                        "�����������v�������b�`��ݒ肵�����߁A���S�ネ�[���o�b�N�����ɂ͂ł��܂���B"
                End If
            End If
            Err.Clear
            If workbookSavedCaptured And workbookWasSaved And rollbackOK Then
                ThisWorkbook.Saved = True
                If Err.Number <> 0 Then
                    rollbackOK = False
                    AppendTransactionRollbackDetail rollbackDetail, _
                        "�u�b�N�ۑ���Ԃ̕����G���[: " & Err.Description
                End If
            End If
            Err.Clear
            On Error GoTo 0
        End If
        If Not rollbackOK Then
            On Error Resume Next
            Err.Clear
            EnforceRollbackRecoveryState rollbackDetail
            recoveryErrorNumber = Err.Number
            recoveryErrorDescription = Err.Description
            Err.Clear
            On Error GoTo 0
            'Enforce�̗�O�l��ۑ����������False���Ċm�肷��B
            eventsReadyForRollback = _
                TryStopTransactionAnalysisEventsForBookWrites( _
                    postEnforceEventDetail)
            If recoveryErrorNumber <> 0 Then
                recoveryEnforcementFailed = True
                AppendTransactionRollbackDetail rollbackDetail, _
                    "�v������Ԃ̋����ݒ�G���[: Err " & _
                    CStr(recoveryErrorNumber) & " " & _
                    recoveryErrorDescription
                Err.Raise vbObjectError + 5195, _
                    "TransactionAnalysisRecoveryFatal/BuildTransactionAnalysisSheetsCore", _
                    errorDescription & " / " & rollbackDetail
            End If
            If Not eventsReadyForRollback Then _
                Err.Raise vbObjectError + 5195, _
                    "TransactionAnalysisRecoveryFatal/BuildTransactionAnalysisSheetsCore", _
                    errorDescription & " / Recovery�������Excel�C�x���g" & _
                    "False�������m�F�ł��܂���: " & postEnforceEventDetail
            recoveryConfirmed = _
                TransactionAnalysisRecoveryStateIsConfirmedExact( _
                    rollbackDetail)
            If Not recoveryConfirmed Then _
                Err.Raise vbObjectError + 5195, _
                    "TransactionAnalysisRecoveryFatal/BuildTransactionAnalysisSheetsCore", _
                    errorDescription & " / �����Recovery��d��Ԃ�" & _
                    "�����m�F�ł��܂���: " & rollbackDetail
            applicationStateConfirmed = _
                TransactionAnalysisApplicationStateAllowsEntryRestore( _
                    True, rollbackDetail)
            If Not applicationStateConfirmed Then
                eventsReadyForRollback = _
                    TryStopTransactionAnalysisEventsForBookWrites( _
                        finalRecoveryEventDetail)
                Err.Raise vbObjectError + 5195, _
                    "TransactionAnalysisRecoveryFatal/BuildTransactionAnalysisSheetsCore", _
                    errorDescription & " / Application��Ԃ����S��" & _
                    "�m�F�ł��܂���: " & rollbackDetail
            End If
            eventsReadyForRollback = _
                TryStopTransactionAnalysisEventsForBookWrites( _
                    finalRecoveryEventDetail)
            If Not eventsReadyForRollback Then _
                Err.Raise vbObjectError + 5195, _
                    "TransactionAnalysisRecoveryFatal/BuildTransactionAnalysisSheetsCore", _
                    errorDescription & " / Recovery�m�F���Excel�C�x���g" & _
                    "False�������m�F�ł��܂���: " & finalRecoveryEventDetail
            Err.Raise vbObjectError + 5195, _
                "TransactionAnalysisRecoveryFatal/BuildTransactionAnalysisSheetsCore", _
                errorDescription & " / ���͏o�͂����S�ɕ����ł����A" & _
                "�����Recovery��Ԃ֒�~���܂���: " & rollbackDetail
        End If
        safeToRestoreEntry = eventsReadyForRollback And _
                             Not recoveryEnforcementFailed And _
                             (rollbackOK Or recoveryConfirmed)
    End If

    If entryEventsCaptured Then
        If safeToRestoreEntry Then
            eventsReadyForRollback = _
                TryStopTransactionAnalysisEventsForBookWrites(eventStateDetail)
            safeToRestoreEntry = eventsReadyForRollback
        End If
        If safeToRestoreEntry Then
            safeToRestoreEntry = _
                TransactionAnalysisApplicationStateAllowsEntryRestore( _
                    entryEvents, rollbackDetail)
        End If
        If safeToRestoreEntry Then
            If Not TryRestoreTransactionAnalysisEnableEvents( _
                       entryEvents, "������͍č\�z�̃G���[�I��", _
                       eventStateDetail) Then
                rollbackOK = False
                AppendTransactionRollbackDetail rollbackDetail, _
                    "Excel�C�x���g��Ԃ𕜌��ł��܂���: " & _
                    eventStateDetail
            End If
        ElseIf TryStopTransactionAnalysisEventsForBookWrites( _
                       convergenceDetail) Then
            rollbackOK = False
            AppendTransactionRollbackDetail rollbackDetail, _
                "���[���o�b�N�܂���Recovery�������m�F�ł��Ȃ����߁A" & _
                "�J�n���C�x���g�l�֖߂���False�Œ�~���܂����B"
        Else
            rollbackOK = False
            AppendTransactionRollbackDetail rollbackDetail, _
                "���S��Ԃ������m�F�ł����AExcel�C�x���g��False�����ɂ�" & _
                "���s���܂����B���ݏ�Ԃ͕s���ł�: " & convergenceDetail
        End If
    End If

    On Error Resume Next
    ResetAnalysisEvidenceCache
    mAnalysisInheritanceDate = entryInheritanceDate
    On Error GoTo 0
    If Len(rollbackDetail) > 0 Then _
        errorDescription = errorDescription & " / �����m�F: " & rollbackDetail
    If Len(errorSource) = 0 Then _
        errorSource = "BuildTransactionAnalysisSheetsCore"
    Err.Raise errorNumber, errorSource, errorDescription
End Sub

Private Sub InitializeTransactionAnalysisAtomicSheets( _
        ByRef snapshots() As TransactionAnalysisSheetSnapshot)
    ReDim snapshots(1 To TRANSACTION_ATOMIC_SHEET_COUNT)
    ConfigureTransactionAnalysisAtomicSheet snapshots(1), SH_ANALYSIS_SHIFT, _
        "�����V�t�g���", SHIFT_ANALYSIS_LAST_COL, MAX_ANALYSIS_OUTPUT_ROWS
    ConfigureTransactionAnalysisAtomicSheet snapshots(2), SH_ANALYSIS_FLOW, _
        "�����t���[�ǐ�", FLOW_ANALYSIS_LAST_COL, MAX_ANALYSIS_OUTPUT_ROWS
    ConfigureTransactionAnalysisAtomicSheet snapshots(3), SH_ANALYSIS_UNKNOWN, _
        "�s�����o��", UNKNOWN_ANALYSIS_LAST_COL, MAX_ANALYSIS_OUTPUT_ROWS
    ConfigureTransactionAnalysisAtomicSheet snapshots(4), SH_ANALYSIS_RESULT, _
        "���͌���", ANALYSIS_RESULT_LAST_COL, MAX_ANALYSIS_OUTPUT_ROWS
    ConfigureTransactionAnalysisAtomicSheet snapshots(5), SH_WORK_ANALYSIS_GROUP, _
        "���̓O���[�v", ANALYSIS_GROUP_LAST_COL, MAX_ANALYSIS_OUTPUT_ROWS * 2
    ConfigureTransactionAnalysisAtomicSheet snapshots(6), SH_ANALYSIS_DETAIL, _
        "���ڍ�", TRANSACTION_ATOMIC_DETAIL_LAST_COL, MAX_ANALYSIS_OUTPUT_ROWS
    ConfigureTransactionAnalysisAtomicSheet snapshots(7), SH_WORK_ANALYSIS_REVIEW, _
        "���͔��f�䒠", ANALYSIS_REVIEW_STORE_LAST_COL, MAX_INTERNAL_STORE_DATA_ROWS
    ConfigureTransactionAnalysisAtomicSheet snapshots(8), SH_WORK_ANALYSIS_HISTORY, _
        "���͔��f����", ANALYSIS_HISTORY_STORE_LAST_COL, MAX_INTERNAL_STORE_DATA_ROWS
    ConfigureTransactionAnalysisAtomicSheet snapshots(9), SH_WORK_MANUAL_FLOW, _
        "�蓮�������", MANUAL_FLOW_STORE_LAST_COL, MAX_INTERNAL_STORE_DATA_ROWS
    ConfigureTransactionAnalysisAtomicSheet snapshots(10), SH_WORK_STATE, _
        "�������", 2, MAX_INTERNAL_STORE_DATA_ROWS
    ConfigureTransactionAnalysisAtomicSheet snapshots(11), SH_CHECK, _
        "�m�F����", 4, MAX_INTERNAL_STORE_DATA_ROWS
End Sub

Private Sub ConfigureTransactionAnalysisAtomicSheet( _
        ByRef snapshot As TransactionAnalysisSheetSnapshot, _
        ByVal sheetName As String, ByVal labelText As String, _
        ByVal lastColumn As Long, ByVal maximumDataRows As Long)
    snapshot.SheetName = sheetName
    snapshot.LabelText = labelText
    snapshot.LastColumn = lastColumn
    snapshot.MaximumDataRows = maximumDataRows
End Sub

Private Function TransactionAnalysisAtomicSnapshotCellWork( _
        ByRef snapshots() As TransactionAnalysisSheetSnapshot, _
        ByVal includeCashView As Boolean) As Double
    Dim i As Long, lastR As Long, cashLastRow As Long
    Dim dataRows() As Long, cashDataRows As Long
    Dim ws As Worksheet
    ReDim dataRows(LBound(snapshots) To UBound(snapshots))
    For i = LBound(snapshots) To UBound(snapshots)
        Set ws = GetSheet(snapshots(i).SheetName)
        lastR = LastDataRowInColumns(ws, 1, snapshots(i).LastColumn)
        If lastR < 1 Then lastR = 1
        dataRows(i) = lastR - 1
    Next i
    If includeCashView Then
        Set ws = GetSheet(SH_OUTPUT_TX)
        cashLastRow = LastDataRowInColumns(ws, 1, CASH_VIEW_INTERNAL_LAST_COL)
        If cashLastRow < CASH_VIEW_HEADER_ROW Then cashLastRow = CASH_VIEW_HEADER_ROW
        cashDataRows = cashLastRow - CASH_VIEW_HEADER_ROW
    End If
    TransactionAnalysisAtomicSnapshotCellWork = _
        TransactionAnalysisAtomicSnapshotCellWorkFromCounts( _
            snapshots, dataRows, cashDataRows, includeCashView)
End Function

Private Function TransactionAnalysisAtomicSnapshotCellWorkFromCounts( _
        ByRef snapshots() As TransactionAnalysisSheetSnapshot, _
        ByRef dataRows() As Long, ByVal cashDataRows As Long, _
        ByVal includeCashView As Boolean) As Double
    Dim i As Long
    Dim cellWork As Double
    If LBound(dataRows) <> LBound(snapshots) Or _
       UBound(dataRows) <> UBound(snapshots) Then _
        Err.Raise vbObjectError + 4653, _
                  "TransactionAnalysisAtomicSnapshotCellWorkFromCounts", _
                  "���͍X�V���[���o�b�N�e�ʂ̍s���z�񂪕s���ł��B"
    For i = LBound(snapshots) To UBound(snapshots)
        If dataRows(i) < 0 Or dataRows(i) > snapshots(i).MaximumDataRows Then _
            Err.Raise vbObjectError + 4653, _
                      "TransactionAnalysisAtomicSnapshotCellWorkFromCounts", _
                      snapshots(i).LabelText & "���ޔ�����i" & _
                      Format$(snapshots(i).MaximumDataRows, "#,##0") & _
                      "�s�j�𒴂��Ă��܂��B"
        cellWork = cellWork + _
                   CDbl(dataRows(i) + 1) * CDbl(snapshots(i).LastColumn) * _
                   CDbl(TRANSACTION_ATOMIC_SNAPSHOT_COPIES)
    Next i
    If includeCashView Then
        If cashDataRows < 0 Or cashDataRows > MAX_ANALYSIS_OUTPUT_ROWS Then _
            Err.Raise vbObjectError + 4654, _
                      "TransactionAnalysisAtomicSnapshotCellWorkFromCounts", _
                      "��������\���ޔ�����i" & _
                      Format$(MAX_ANALYSIS_OUTPUT_ROWS, "#,##0") & "�s�j�𒴂��Ă��܂��B"
        cellWork = cellWork + _
                   CDbl(cashDataRows + 1) * _
                   CDbl(CASH_VIEW_INTERNAL_LAST_COL) * _
                   CDbl(TRANSACTION_ATOMIC_SNAPSHOT_COPIES)
        cellWork = cellWork + _
                   CDbl(TRANSACTION_ATOMIC_CASH_STATE_ROWS) * _
                   CDbl(CASH_VIEW_INTERNAL_LAST_COL) * _
                   CDbl(TRANSACTION_ATOMIC_SNAPSHOT_COPIES)
    End If
    cellWork = cellWork + _
               CDbl(AllocationLedgerStoredRowCount() + 1) * 10# * _
               CDbl(TRANSACTION_ATOMIC_SNAPSHOT_COPIES)
    TransactionAnalysisAtomicSnapshotCellWorkFromCounts = cellWork
End Function

Private Function TransactionAnalysisOperationPeakSnapshotCellWork( _
        ByVal atomicSnapshotCellWork As Double) As Double
    Dim peakCellWork As Double
    If atomicSnapshotCellWork < 0# Then _
        Err.Raise vbObjectError + 4685, _
                  "TransactionAnalysisOperationPeakSnapshotCellWork", _
                  "���͑���g�����U�N�V�����̑ޔ�e�ʂ��s���ł��B"
    peakCellWork = atomicSnapshotCellWork * _
                   CDbl(TRANSACTION_OPERATION_PEAK_SNAPSHOT_SETS)
    If peakCellWork < atomicSnapshotCellWork Or _
       peakCellWork > 2147483647# * 16# Then _
        Err.Raise vbObjectError + 4685, _
                  "TransactionAnalysisOperationPeakSnapshotCellWork", _
                  "���͑���g�����U�N�V�����̓����ޔ�e�ʂ����S�͈͂𒴂��Ă��܂��B"
    TransactionAnalysisOperationPeakSnapshotCellWork = peakCellWork
End Function

Private Sub CaptureTransactionAnalysisAtomicSnapshot( _
        ByRef snapshots() As TransactionAnalysisSheetSnapshot, _
        ByVal includeCashView As Boolean, _
        ByRef cashSnapshot As TransactionCashViewSnapshot)
    Dim i As Long
    Dim ws As Worksheet
    For i = LBound(snapshots) To UBound(snapshots)
        Set ws = GetSheet(snapshots(i).SheetName)
        snapshots(i).Visibility = CLng(ws.Visible)
        snapshots(i).WasProtected = ws.ProtectContents
        CaptureTransactionAtomicHeader ws, snapshots(i).LastColumn, _
            snapshots(i).HeaderData, snapshots(i).LabelText
        CaptureAtomicConstantWorksheetData ws, snapshots(i).LastColumn, _
            snapshots(i).MaximumDataRows, snapshots(i).Data, _
            snapshots(i).LastRow, snapshots(i).LabelText
    Next i
    If includeCashView Then CaptureTransactionCashViewSnapshot cashSnapshot
End Sub

Private Sub CaptureTransactionAtomicHeader( _
        ByVal ws As Worksheet, ByVal lastColumn As Long, _
        ByRef headerSnapshot As Variant, ByVal labelText As String)
    Dim headerRange As Range, formulaCell As Range
    Set headerRange = ws.Range(ws.Cells(1, 1), ws.Cells(1, lastColumn))
    If Not TryFindFirstFormulaCell(headerRange, formulaCell) Then _
        Err.Raise vbObjectError + 4655, "CaptureTransactionAtomicHeader", _
                  labelText & "�̌��o�����������Ɏ��s���܂����B"
    If Not formulaCell Is Nothing Then _
        Err.Raise vbObjectError + 4655, "CaptureTransactionAtomicHeader", _
                  labelText & "�̌��o���ɐ���������܂��B"
    headerSnapshot = headerRange.Value2
    If VariantMatrixContainsError(headerSnapshot, 1, lastColumn) Or _
       Not RangeValue2MatchesMatrixStrict( _
               headerRange, headerSnapshot, 1, lastColumn) Then _
        Err.Raise vbObjectError + 4656, "CaptureTransactionAtomicHeader", _
                  labelText & "�̌��o�����^�܂Ō����ɑޔ��ł��܂���B"
End Sub

Private Sub RestoreTransactionAtomicHeader( _
        ByVal ws As Worksheet, ByVal lastColumn As Long, _
        ByRef headerSnapshot As Variant, ByVal labelText As String)
    Dim headerRange As Range
    Set headerRange = ws.Range(ws.Cells(1, 1), ws.Cells(1, lastColumn))
    headerRange.Value2 = headerSnapshot
    If Not RangeValue2MatchesMatrixStrict( _
               headerRange, headerSnapshot, 1, lastColumn) Then _
        Err.Raise vbObjectError + 4657, "RestoreTransactionAtomicHeader", _
                  labelText & "�̌��o�����^�܂Ō����ɕ����ł��܂���B"
End Sub

Private Sub CaptureTransactionCashViewSnapshot( _
        ByRef snapshot As TransactionCashViewSnapshot)
    Dim ws As Worksheet, wsWorkCash As Worksheet
    Dim panelRange As Range, dataRange As Range, formulaCell As Range
    Dim dataRows As Long
    Set ws = GetSheet(SH_OUTPUT_TX)
    Set wsWorkCash = GetSheet(SH_WORK_CASH)
    snapshot.Visibility = CLng(ws.Visible)
    snapshot.WasProtected = ws.ProtectContents
    snapshot.WorkCashVisibility = CLng(wsWorkCash.Visible)
    snapshot.WorkCashWasProtected = wsWorkCash.ProtectContents

    Set panelRange = ws.Range(ws.Cells(1, 1), _
                              ws.Cells(TRANSACTION_ATOMIC_CASH_STATE_ROWS, _
                                       CASH_VIEW_INTERNAL_LAST_COL))
    If Not TryFindFirstFormulaCell(panelRange, formulaCell) Then _
        Err.Raise vbObjectError + 4658, "CaptureTransactionCashViewSnapshot", _
                  "��������\�̃p�l�����������Ɏ��s���܂����B"
    If Not formulaCell Is Nothing Then _
        Err.Raise vbObjectError + 4658, "CaptureTransactionCashViewSnapshot", _
                  "��������\�̃p�l���܂��͉�ʏ�Ԃɐ���������܂��B"
    snapshot.PanelData = panelRange.Value2
    If VariantMatrixContainsError( _
            snapshot.PanelData, TRANSACTION_ATOMIC_CASH_STATE_ROWS, _
            CASH_VIEW_INTERNAL_LAST_COL) Or _
       Not RangeValue2MatchesMatrixStrict( _
               panelRange, snapshot.PanelData, _
               TRANSACTION_ATOMIC_CASH_STATE_ROWS, _
               CASH_VIEW_INTERNAL_LAST_COL) Then _
        Err.Raise vbObjectError + 4659, "CaptureTransactionCashViewSnapshot", _
                  "��������\�̃p�l���Ɖ�ʏ�Ԃ������ɑޔ��ł��܂���B"

    snapshot.DataLastRow = _
        LastDataRowInColumns(ws, 1, CASH_VIEW_INTERNAL_LAST_COL)
    If snapshot.DataLastRow < CASH_VIEW_HEADER_ROW Then _
        snapshot.DataLastRow = CASH_VIEW_HEADER_ROW
    dataRows = snapshot.DataLastRow - CASH_VIEW_HEADER_ROW + 1
    If dataRows - 1 > MAX_ANALYSIS_OUTPUT_ROWS Then _
        Err.Raise vbObjectError + 4660, "CaptureTransactionCashViewSnapshot", _
                  "��������\���ޔ�����𒴂��Ă��܂��B"
    Set dataRange = ws.Range(ws.Cells(CASH_VIEW_HEADER_ROW, 1), _
                             ws.Cells(snapshot.DataLastRow, _
                                      CASH_VIEW_INTERNAL_LAST_COL))
    If Not TryFindFirstFormulaCell(dataRange, formulaCell) Then _
        Err.Raise vbObjectError + 4661, "CaptureTransactionCashViewSnapshot", _
                  "��������\�̈ꗗ���������Ɏ��s���܂����B"
    If Not formulaCell Is Nothing Then _
        Err.Raise vbObjectError + 4661, "CaptureTransactionCashViewSnapshot", _
                  "��������\�̈ꗗ�ɐ���������܂��B"
    snapshot.Data = dataRange.Value2
    If VariantMatrixContainsError( _
            snapshot.Data, dataRows, CASH_VIEW_INTERNAL_LAST_COL) Or _
       Not RangeValue2MatchesMatrixStrict( _
               dataRange, snapshot.Data, dataRows, _
               CASH_VIEW_INTERNAL_LAST_COL) Then _
        Err.Raise vbObjectError + 4662, "CaptureTransactionCashViewSnapshot", _
                  "��������\�̈ꗗ�������ɑޔ��ł��܂���B"

    If Not ActiveSheet Is Nothing Then
        If TypeName(ActiveSheet) = "Worksheet" Then
            snapshot.EntryActiveSheetName = ActiveSheet.Name
            If Not ActiveCell Is Nothing Then _
                snapshot.EntryActiveCellAddress = ActiveCell.Address(False, False)
        End If
    End If
    snapshot.WasActive = (snapshot.EntryActiveSheetName = SH_OUTPUT_TX)
    If snapshot.WasActive Then
        If TypeName(Selection) = "Range" Then _
            snapshot.SelectionAddress = Selection.Address(False, False)
        snapshot.ActiveCellAddress = ActiveCell.Address(False, False)
        If Not ActiveWindow Is Nothing Then
            snapshot.FreezePanes = ActiveWindow.FreezePanes
            snapshot.SplitRow = CLng(ActiveWindow.SplitRow)
            snapshot.SplitColumn = CLng(ActiveWindow.SplitColumn)
            snapshot.ScrollRow = ActiveWindow.ScrollRow
            snapshot.ScrollColumn = ActiveWindow.ScrollColumn
            snapshot.Zoom = CLng(ActiveWindow.Zoom)
            snapshot.WindowStateCaptured = True
        End If
    End If
    snapshot.Captured = True
End Sub

Private Function RestoreTransactionAnalysisAtomicSnapshot( _
        ByRef snapshots() As TransactionAnalysisSheetSnapshot, _
        ByVal detailReviewsDirty As Boolean, _
        ByRef cashSnapshot As TransactionCashViewSnapshot, _
        ByRef detailText As String) As Boolean
    Dim i As Long
    Dim restoreOK As Boolean
    Dim fatalErrorNumber As Long
    Dim fatalErrorSource As String, fatalErrorDescription As String
    Dim fatalStopDetail As String
    restoreOK = True
    On Error Resume Next

    For i = 1 To 3
        Err.Clear
        RestoreTransactionAnalysisSourceSnapshot snapshots(i)
        If IsTransactionAnalysisRecoveryFatal(Err.Number, Err.Source) Then _
            GoTo RecoveryFatal
        If Err.Number <> 0 Then
            restoreOK = False
            AppendTransactionRollbackDetail detailText, _
                snapshots(i).LabelText & "�̕����G���[: " & Err.Description
        End If
    Next i

    Err.Clear
    RestoreAnalysisWorkspaceTransactionSnapshot _
        snapshots(4).Data, snapshots(4).LastRow, _
        snapshots(4).Visibility, snapshots(4).WasProtected, _
        snapshots(5).Data, snapshots(5).LastRow, _
        snapshots(5).Visibility, snapshots(5).WasProtected, _
        snapshots(6).HeaderData, snapshots(6).Data, snapshots(6).LastRow, _
        snapshots(6).Visibility, snapshots(6).WasProtected, detailReviewsDirty
    If IsTransactionAnalysisRecoveryFatal(Err.Number, Err.Source) Then _
        GoTo RecoveryFatal
    If Err.Number = 0 Then _
        RestoreTransactionWorkspaceHeaders snapshots(4), snapshots(5)
    If IsTransactionAnalysisRecoveryFatal(Err.Number, Err.Source) Then _
        GoTo RecoveryFatal
    If Err.Number <> 0 Then
        restoreOK = False
        AppendTransactionRollbackDetail detailText, _
            "����workspace�̕����G���[: " & Err.Description
    End If

    For i = 7 To 9
        Err.Clear
        RestoreTransactionConstantStoreSnapshot snapshots(i)
        If IsTransactionAnalysisRecoveryFatal(Err.Number, Err.Source) Then _
            GoTo RecoveryFatal
        If Err.Number <> 0 Then
            restoreOK = False
            AppendTransactionRollbackDetail detailText, _
                snapshots(i).LabelText & "�̕����G���[: " & Err.Description
        End If
    Next i

    If cashSnapshot.Captured Then
        Err.Clear
        RestoreTransactionCashViewContent cashSnapshot
        If IsTransactionAnalysisRecoveryFatal(Err.Number, Err.Source) Then _
            GoTo RecoveryFatal
        If Err.Number <> 0 Then
            restoreOK = False
            AppendTransactionRollbackDetail detailText, _
                "��������\�̕����G���[: " & Err.Description
        End If
    End If

    Err.Clear
    RestoreTransactionConstantStoreSnapshot snapshots(11)
    If IsTransactionAnalysisRecoveryFatal(Err.Number, Err.Source) Then _
        GoTo RecoveryFatal
    If Err.Number <> 0 Then
        restoreOK = False
        AppendTransactionRollbackDetail detailText, _
            snapshots(11).LabelText & "�̕����G���[: " & Err.Description
    End If

    'Cash�̍č\�z��Change���`��dirty�t���O�֐G��邽�߁AW_��Ԃ͕K���Ō�ɖ߂��B
    Err.Clear
    RestoreTransactionConstantStoreSnapshot snapshots(10)
    If IsTransactionAnalysisRecoveryFatal(Err.Number, Err.Source) Then _
        GoTo RecoveryFatal
    If Err.Number <> 0 Then
        restoreOK = False
        AppendTransactionRollbackDetail detailText, _
            snapshots(10).LabelText & "�̕����G���[: " & Err.Description
    End If

    For i = LBound(snapshots) To UBound(snapshots)
        Err.Clear
        RestoreTransactionAnalysisSheetSurfaceState _
            GetSheet(snapshots(i).SheetName), snapshots(i).Visibility, _
            snapshots(i).WasProtected
        If IsTransactionAnalysisRecoveryFatal(Err.Number, Err.Source) Then _
            GoTo RecoveryFatal
        If Err.Number <> 0 Then
            restoreOK = False
            AppendTransactionRollbackDetail detailText, _
                snapshots(i).LabelText & "�̕\���E�ی앜���G���[: " & Err.Description
        End If
    Next i

    If cashSnapshot.Captured Then
        Err.Clear
        RestoreTransactionAnalysisSheetSurfaceState _
            GetSheet(SH_WORK_CASH), cashSnapshot.WorkCashVisibility, _
            cashSnapshot.WorkCashWasProtected
        If IsTransactionAnalysisRecoveryFatal(Err.Number, Err.Source) Then _
            GoTo RecoveryFatal
        If Err.Number <> 0 Then
            restoreOK = False
            AppendTransactionRollbackDetail detailText, _
                "�\�莑���\�̕\���E�ی앜���G���[: " & Err.Description
        End If
        Err.Clear
        RestoreTransactionAnalysisSheetSurfaceState _
            GetSheet(SH_OUTPUT_TX), cashSnapshot.Visibility, _
            cashSnapshot.WasProtected
        If IsTransactionAnalysisRecoveryFatal(Err.Number, Err.Source) Then _
            GoTo RecoveryFatal
        If Err.Number <> 0 Then
            restoreOK = False
            AppendTransactionRollbackDetail detailText, _
                "��������\�̕\���E�ی앜���G���[: " & Err.Description
        End If
        Err.Clear
        RestoreTransactionEntryViewState cashSnapshot
        If Err.Number <> 0 Then
            restoreOK = False
            AppendTransactionRollbackDetail detailText, _
                "����J�n���̑I���E��ʕ����G���[: " & Err.Description
        End If
    End If

    'W_��ԂƗv�������b�`�𓥂܂��A�呀��{�^�����Ō�Ɍ���I�ē�������B
    Err.Clear
    RefreshMainActionCaption
    If Err.Number <> 0 Or Not TransactionMainActionCaptionStateMatches() Then
        restoreOK = False
        AppendTransactionRollbackDetail detailText, _
            "�呀��{�^���\������ԕ\�ƈ�v�������܂���B" & _
            IIf(Err.Number <> 0, " " & Err.Description, vbNullString)
    End If

    Err.Clear
    On Error GoTo 0
    RestoreTransactionAnalysisAtomicSnapshot = restoreOK
    Exit Function
RecoveryFatal:
    fatalErrorNumber = Err.Number
    fatalErrorSource = Err.Source
    fatalErrorDescription = Err.Description
    Err.Clear
    On Error GoTo 0
    Call TryStopTransactionAnalysisEventsForBookWrites(fatalStopDetail)
    Err.Raise fatalErrorNumber, fatalErrorSource, fatalErrorDescription
End Function

Private Sub RestoreTransactionAnalysisSourceSnapshot( _
        ByRef snapshot As TransactionAnalysisSheetSnapshot)
    Dim ws As Worksheet
    Dim dataCount As Long
    Set ws = GetSheet(snapshot.SheetName)
    Select Case snapshot.SheetName
        Case SH_ANALYSIS_SHIFT
            PrepareShiftAnalysisSheet ws
            ws.Unprotect Password:=TOOL_PASSWORD
            RestoreAtomicConstantWorksheetData ws, snapshot.LastColumn, _
                snapshot.MaximumDataRows, snapshot.Data, snapshot.LastRow, _
                snapshot.LabelText
            FinalizeShiftAnalysisSheet ws, snapshot.LastRow - 1
        Case SH_ANALYSIS_FLOW
            PrepareAdvancedFlowAnalysisSheet ws
            ws.Unprotect Password:=TOOL_PASSWORD
            RestoreAtomicConstantWorksheetData ws, snapshot.LastColumn, _
                snapshot.MaximumDataRows, snapshot.Data, snapshot.LastRow, _
                snapshot.LabelText
            FinalizeAdvancedFlowAnalysisSheet ws, snapshot.LastRow - 1
        Case SH_ANALYSIS_UNKNOWN
            PrepareUnknownAnalysisSheet ws
            ws.Unprotect Password:=TOOL_PASSWORD
            RestoreAtomicConstantWorksheetData ws, snapshot.LastColumn, _
                snapshot.MaximumDataRows, snapshot.Data, snapshot.LastRow, _
                snapshot.LabelText
            FinalizeUnknownAnalysisSheet ws, snapshot.LastRow - 1
        Case Else
            Err.Raise vbObjectError + 4663, _
                      "RestoreTransactionAnalysisSourceSnapshot", _
                      "���͌��\�̑ޔ��w�肪�s���ł�: " & snapshot.SheetName
    End Select

    dataCount = snapshot.LastRow - 1
    If dataCount > 0 Then
        If Not RangeValue2MatchesMatrixStrict( _
                   ws.Range(ws.Cells(2, 1), _
                            ws.Cells(snapshot.LastRow, snapshot.LastColumn)), _
                   snapshot.Data, dataCount, snapshot.LastColumn) Then
            '������Sort�̏��Ԃ��ς���Ă��A�J�n���̍s�����Ō�Ɍ�����������B
            ws.Unprotect Password:=TOOL_PASSWORD
            RestoreAtomicConstantWorksheetData ws, snapshot.LastColumn, _
                snapshot.MaximumDataRows, snapshot.Data, snapshot.LastRow, _
                snapshot.LabelText
        End If
    End If
    ws.Unprotect Password:=TOOL_PASSWORD
    RestoreTransactionAtomicHeader ws, snapshot.LastColumn, _
        snapshot.HeaderData, snapshot.LabelText
    If dataCount > 0 Then
        If Not RangeValue2MatchesMatrixStrict( _
                   ws.Range(ws.Cells(2, 1), _
                            ws.Cells(snapshot.LastRow, snapshot.LastColumn)), _
                   snapshot.Data, dataCount, snapshot.LastColumn) Then _
            Err.Raise vbObjectError + 4664, _
                      "RestoreTransactionAnalysisSourceSnapshot", _
                      snapshot.LabelText & "�̊J�n���s���𕜌��ł��܂���B"
    End If
End Sub

Private Sub RestoreTransactionWorkspaceHeaders( _
        ByRef resultSnapshot As TransactionAnalysisSheetSnapshot, _
        ByRef groupSnapshot As TransactionAnalysisSheetSnapshot)
    Dim ws As Worksheet
    Set ws = GetSheet(resultSnapshot.SheetName)
    ws.Unprotect Password:=TOOL_PASSWORD
    RestoreTransactionAtomicHeader ws, resultSnapshot.LastColumn, _
        resultSnapshot.HeaderData, resultSnapshot.LabelText
    Set ws = GetSheet(groupSnapshot.SheetName)
    ws.Unprotect Password:=TOOL_PASSWORD
    RestoreTransactionAtomicHeader ws, groupSnapshot.LastColumn, _
        groupSnapshot.HeaderData, groupSnapshot.LabelText
End Sub

Private Sub RestoreTransactionConstantStoreSnapshot( _
        ByRef snapshot As TransactionAnalysisSheetSnapshot)
    Dim ws As Worksheet
    Set ws = GetSheet(snapshot.SheetName)
    ws.Unprotect Password:=TOOL_PASSWORD
    RestoreAtomicConstantWorksheetData ws, snapshot.LastColumn, _
        snapshot.MaximumDataRows, snapshot.Data, snapshot.LastRow, snapshot.LabelText
    RestoreTransactionAtomicHeader ws, snapshot.LastColumn, _
        snapshot.HeaderData, snapshot.LabelText
End Sub

Private Sub RestoreTransactionCashViewContent( _
        ByRef snapshot As TransactionCashViewSnapshot)
    Dim ws As Worksheet
    Dim currentLastRow As Long, clearLastRow As Long, dataRows As Long
    Dim restoredRange As Range
    Set ws = GetSheet(SH_OUTPUT_TX)

    'BuildCash�������E���\�����[�h���g���悤�AV1:V9������ɖ߂��B
    ws.Unprotect Password:=TOOL_PASSWORD
    RestoreTransactionCashStateCells ws, snapshot.PanelData
    BuildCashAnalysisViewCore False, False, True
    ws.Unprotect Password:=TOOL_PASSWORD

    currentLastRow = LastDataRowInColumns(ws, 1, CASH_VIEW_INTERNAL_LAST_COL)
    If currentLastRow < CASH_VIEW_HEADER_ROW Then currentLastRow = CASH_VIEW_HEADER_ROW
    clearLastRow = CLng(Application.Max(currentLastRow, snapshot.DataLastRow))
    ws.Range(ws.Cells(CASH_VIEW_HEADER_ROW, 1), _
             ws.Cells(clearLastRow, CASH_VIEW_INTERNAL_LAST_COL)).ClearContents
    dataRows = snapshot.DataLastRow - CASH_VIEW_HEADER_ROW + 1
    Set restoredRange = ws.Range(ws.Cells(CASH_VIEW_HEADER_ROW, 1), _
                                 ws.Cells(snapshot.DataLastRow, _
                                          CASH_VIEW_INTERNAL_LAST_COL))
    restoredRange.Value2 = snapshot.Data
    If Not RangeValue2MatchesMatrixStrict( _
               restoredRange, snapshot.Data, dataRows, _
               CASH_VIEW_INTERNAL_LAST_COL) Then _
        Err.Raise vbObjectError + 4665, "RestoreTransactionCashViewContent", _
                  "��������\�̈ꗗ���^�܂Ō����ɕ����ł��܂���B"
    If LastDataRowInColumns(ws, 1, CASH_VIEW_INTERNAL_LAST_COL) <> _
       snapshot.DataLastRow Then _
        Err.Raise vbObjectError + 4666, "RestoreTransactionCashViewContent", _
                  "��������\�̕����s������v���܂���B"

    RestoreTransactionCashPanelValues ws, snapshot.PanelData
    FormatCashAnalysisViewLayout ws
    OnCashAnalysisViewChange Union(ws.Range("C3"), ws.Range("C8"))
    If Not RangeValue2MatchesMatrixStrict( _
               ws.Range(ws.Cells(1, 1), _
                        ws.Cells(TRANSACTION_ATOMIC_CASH_STATE_ROWS, _
                                 CASH_VIEW_INTERNAL_LAST_COL)), _
               snapshot.PanelData, TRANSACTION_ATOMIC_CASH_STATE_ROWS, _
               CASH_VIEW_INTERNAL_LAST_COL) Then _
        Err.Raise vbObjectError + 4667, "RestoreTransactionCashViewContent", _
                  "��������\�̃p�l���܂��͉�ʏ�Ԃ������ɕ����ł��܂���B"
End Sub

Private Sub RestoreTransactionCashStateCells( _
        ByVal ws As Worksheet, ByRef panelSnapshot As Variant)
    Dim stateData() As Variant, r As Long
    ReDim stateData(1 To TRANSACTION_ATOMIC_CASH_STATE_ROWS, 1 To 1)
    For r = 1 To TRANSACTION_ATOMIC_CASH_STATE_ROWS
        stateData(r, 1) = panelSnapshot(r, 22)
    Next r
    ws.Range("V1:V" & CStr(TRANSACTION_ATOMIC_CASH_STATE_ROWS)).Value2 = stateData
    If Not RangeValue2MatchesMatrixStrict( _
               ws.Range("V1:V" & CStr(TRANSACTION_ATOMIC_CASH_STATE_ROWS)), _
               stateData, TRANSACTION_ATOMIC_CASH_STATE_ROWS, 1) Then _
        Err.Raise vbObjectError + 4668, "RestoreTransactionCashStateCells", _
                  "��������\�̉�ʏ�Ԃ��č\�z�O�ɕ����ł��܂���B"
End Sub

Private Sub RestoreTransactionCashPanelValues( _
        ByVal ws As Worksheet, ByRef panelSnapshot As Variant)
    Dim r As Long, c As Long
    Dim target As Range, topLeft As Range
    For r = 1 To TRANSACTION_ATOMIC_CASH_STATE_ROWS
        For c = 1 To CASH_VIEW_INTERNAL_LAST_COL
            Set target = ws.Cells(r, c)
            If target.MergeCells Then
                Set topLeft = target.MergeArea.Cells(1, 1)
                If target.Address = topLeft.Address Then _
                    topLeft.Value2 = panelSnapshot(r, c)
            Else
                target.Value2 = panelSnapshot(r, c)
            End If
        Next c
    Next r
    If Not RangeValue2MatchesMatrixStrict( _
               ws.Range(ws.Cells(1, 1), _
                        ws.Cells(TRANSACTION_ATOMIC_CASH_STATE_ROWS, _
                                 CASH_VIEW_INTERNAL_LAST_COL)), _
               panelSnapshot, TRANSACTION_ATOMIC_CASH_STATE_ROWS, _
               CASH_VIEW_INTERNAL_LAST_COL) Then _
        Err.Raise vbObjectError + 4669, "RestoreTransactionCashPanelValues", _
                  "��������\�̃p�l���l���^�܂Ō����ɕ����ł��܂���B"
End Sub

Private Sub RestoreTransactionAnalysisSheetSurfaceState( _
        ByVal ws As Worksheet, ByVal visibilityState As Long, _
        ByVal protectedState As Boolean)
    If ws Is Nothing Then _
        Err.Raise vbObjectError + 4670, _
                  "RestoreTransactionAnalysisSheetSurfaceState", _
                  "�\���E�ی��߂��V�[�g������܂���B"
    If protectedState Then
        Select Case ws.Name
            Case SH_ANALYSIS_SHIFT, SH_ANALYSIS_FLOW, SH_ANALYSIS_UNKNOWN, _
                 SH_ANALYSIS_RESULT, SH_ANALYSIS_DETAIL
                ProtectSingleAnalysisSheet ws
            Case SH_OUTPUT_TX
                ProtectCashAnalysisViewSheet
            Case Else
                EmergencyProtectToolSheet ws
        End Select
    Else
        ws.Unprotect Password:=TOOL_PASSWORD
    End If
    ws.Visible = visibilityState
    If ws.ProtectContents <> protectedState Or _
       CLng(ws.Visible) <> visibilityState Then _
        Err.Raise vbObjectError + 4671, _
                  "RestoreTransactionAnalysisSheetSurfaceState", _
                  "�\����Ԃ܂��͕ی��Ԃ̓ǖ߂�����v���܂���: " & ws.Name
End Sub

Private Sub RestoreTransactionEntryViewState( _
        ByRef snapshot As TransactionCashViewSnapshot)
    Dim ws As Worksheet
    Dim restoredAddress As String
    If Len(snapshot.EntryActiveSheetName) = 0 Then Exit Sub
    If Not SheetExists(snapshot.EntryActiveSheetName) Then _
        Err.Raise vbObjectError + 4672, "RestoreTransactionEntryViewState", _
                  "����J�n���̃V�[�g��������܂���B"
    Set ws = GetSheet(snapshot.EntryActiveSheetName)
    If ws.Visible <> xlSheetVisible Then _
        Err.Raise vbObjectError + 4673, "RestoreTransactionEntryViewState", _
                  "����J�n���̃V�[�g���\����Ԃ֖߂��Ă��܂���B"
    ws.Activate
    If snapshot.WasActive And snapshot.WindowStateCaptured Then
        If ActiveWindow Is Nothing Then _
            Err.Raise vbObjectError + 4674, "RestoreTransactionEntryViewState", _
                      "��������\�̕\���E�B���h�E�𕜌��ł��܂���B"
        ActiveWindow.FreezePanes = False
        ActiveWindow.SplitRow = snapshot.SplitRow
        ActiveWindow.SplitColumn = snapshot.SplitColumn
        ActiveWindow.FreezePanes = snapshot.FreezePanes
        ActiveWindow.Zoom = snapshot.Zoom
        ActiveWindow.ScrollRow = snapshot.ScrollRow
        ActiveWindow.ScrollColumn = snapshot.ScrollColumn
        If ActiveWindow.FreezePanes <> snapshot.FreezePanes Or _
           CLng(ActiveWindow.SplitRow) <> snapshot.SplitRow Or _
           CLng(ActiveWindow.SplitColumn) <> snapshot.SplitColumn Or _
           ActiveWindow.Zoom <> snapshot.Zoom Or _
           ActiveWindow.ScrollRow <> snapshot.ScrollRow Or _
           ActiveWindow.ScrollColumn <> snapshot.ScrollColumn Then _
            Err.Raise vbObjectError + 4675, "RestoreTransactionEntryViewState", _
                      "��������\�̌Œ�E�{���E�X�N���[���ʒu����v���܂���B"
    End If
    If snapshot.WasActive And Len(snapshot.SelectionAddress) > 0 Then
        ws.Range(snapshot.SelectionAddress).Select
        If TypeName(Selection) <> "Range" Then _
            Err.Raise vbObjectError + 4676, "RestoreTransactionEntryViewState", _
                      "��������\�̑I��͈͂𕜌��ł��܂���B"
        restoredAddress = Selection.Address(False, False)
        If StrComp(restoredAddress, snapshot.SelectionAddress, vbBinaryCompare) <> 0 Then _
            Err.Raise vbObjectError + 4676, "RestoreTransactionEntryViewState", _
                      "��������\�̑I��͈͂̓ǖ߂�����v���܂���B"
    ElseIf Len(snapshot.EntryActiveCellAddress) > 0 Then
        ws.Range(snapshot.EntryActiveCellAddress).Select
    End If
    If ActiveSheet.Name <> snapshot.EntryActiveSheetName Then _
        Err.Raise vbObjectError + 4677, "RestoreTransactionEntryViewState", _
                  "����J�n���̃A�N�e�B�u�V�[�g�𕜌��ł��܂���B"
End Sub

Private Sub AppendTransactionRollbackDetail( _
        ByRef detailText As String, ByVal addedText As String)
    If Len(Trim$(addedText)) = 0 Then Exit Sub
    If Len(detailText) > 0 Then detailText = detailText & " / "
    detailText = detailText & addedText
    If Len(detailText) > ANALYSIS_CHECK_MAX_DETAIL_CHARS Then _
        detailText = Left$(detailText, ANALYSIS_CHECK_MAX_DETAIL_CHARS)
End Sub

Private Function TryGetTransactionAnalysisEnableEvents( _
        ByRef currentValue As Boolean, _
        ByRef detailText As String) As Boolean
    Dim errorNumber As Long, errorDescription As String
    detailText = vbNullString
    On Error GoTo EH
    currentValue = Application.EnableEvents
    TryGetTransactionAnalysisEnableEvents = True
    Exit Function
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    detailText = "Err " & CStr(errorNumber) & ": " & errorDescription
    Err.Clear
End Function

Private Function TrySetTransactionAnalysisEnableEventsExact( _
        ByVal desiredValue As Boolean, _
        ByRef detailText As String) As Boolean
    Dim errorNumber As Long, errorDescription As String
    detailText = vbNullString
    On Error GoTo EH
    Application.EnableEvents = desiredValue
    If Application.EnableEvents <> desiredValue Then _
        Err.Raise vbObjectError + 4700, _
                  "TrySetTransactionAnalysisEnableEventsExact", _
                  "EnableEvents�̏����݌�ǖ߂�����v���܂���B"
    TrySetTransactionAnalysisEnableEventsExact = True
    Exit Function
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    detailText = "Err " & CStr(errorNumber) & ": " & errorDescription
    Err.Clear
End Function

Private Function TryStopTransactionAnalysisEventsForBookWrites( _
        ByRef detailText As String) As Boolean
    Dim firstDetail As String, retryDetail As String
    detailText = vbNullString
    If TrySetTransactionAnalysisEnableEventsExact(False, firstDetail) Then
        TryStopTransactionAnalysisEventsForBookWrites = True
        Exit Function
    End If
    If TrySetTransactionAnalysisEnableEventsExact(False, retryDetail) Then
        TryStopTransactionAnalysisEventsForBookWrites = True
        Exit Function
    End If
    detailText = "Excel�C�x���g��False�֒�~���ēǖ߂��m�F�ł��܂���ł����B����=" & _
                 firstDetail & " / �Ď��s=" & retryDetail
End Function

Private Function TransactionAnalysisRecoveryStateIsConfirmedExact( _
        ByRef detailText As String) As Boolean
    Dim latchIsSet As Boolean, latchReadSucceeded As Boolean
    Dim healthValue As String, healthReadSucceeded As Boolean
    latchReadSucceeded = TryGetRollbackRecoveryLatch(latchIsSet)
    healthReadSucceeded = _
        TryGetExactStateValue(STATE_DATA_HEALTH, healthValue)
    TransactionAnalysisRecoveryStateIsConfirmedExact = _
        latchReadSucceeded And latchIsSet And healthReadSucceeded And _
        (StrComp(healthValue, DATA_HEALTH_NEEDS_RECOVERY, _
                 vbBinaryCompare) = 0)
    If TransactionAnalysisRecoveryStateIsConfirmedExact Then Exit Function
    If Not latchReadSucceeded Then
        AppendTransactionRollbackDetail detailText, _
            "�Ɨ��������b�`����ӂɓǂݕԂ��܂���B"
    ElseIf Not latchIsSet Then
        AppendTransactionRollbackDetail detailText, _
            "�Ɨ��������b�`���ݒ肳��Ă��܂���B"
    End If
    If Not healthReadSucceeded Then
        AppendTransactionRollbackDetail detailText, _
            "�Č�health����ӂɓǂݕԂ��܂���B"
    ElseIf StrComp(healthValue, DATA_HEALTH_NEEDS_RECOVERY, _
                   vbBinaryCompare) <> 0 Then
        AppendTransactionRollbackDetail detailText, _
            "�Č�health���v�����ł͂���܂���i���l=" & healthValue & "�j�B"
    End If
End Function

Private Function TransactionAnalysisApplicationStateAllowsEntryRestore( _
        ByVal entryEvents As Boolean, _
        ByRef detailText As String) As Boolean
    Dim appStateProblems As String
    If Not entryEvents Then
        TransactionAnalysisApplicationStateAllowsEntryRestore = True
        Exit Function
    End If
    If AppStateIsRestored(appStateProblems) Then
        TransactionAnalysisApplicationStateAllowsEntryRestore = True
    Else
        AppendTransactionRollbackDetail detailText, _
            "Application��Ԃ����S�ɕ����ς݂Ɗm�F�ł��܂���: " & _
            appStateProblems
    End If
End Function

Private Function IsTransactionAnalysisRecoveryFatal( _
        ByVal errorNumber As Long, ByVal errorSource As String) As Boolean
    Dim expectedSource As String
    Select Case errorNumber
        Case vbObjectError + 3599, vbObjectError + 4499
            IsTransactionAnalysisRecoveryFatal = True
            Exit Function
        Case vbObjectError + 5191
            expectedSource = "AnalysisWorkspaceRecoveryFatal/"
        Case vbObjectError + 5192
            expectedSource = "SetupConvergeRecoveryFatal/"
        Case vbObjectError + 5194
            expectedSource = "CashAnalysisRecoveryFatal/"
        Case vbObjectError + 5195
            expectedSource = "TransactionAnalysisRecoveryFatal/"
        Case vbObjectError + 5196
            expectedSource = "CashManualSelectionRecoveryFatal/"
        Case vbObjectError + 5197
            expectedSource = "ClearRecoveryFatal/"
        Case Else
            Exit Function
    End Select
    If Len(errorSource) < Len(expectedSource) Then Exit Function
    IsTransactionAnalysisRecoveryFatal = _
        (StrComp(Left$(errorSource, Len(expectedSource)), expectedSource, _
                 vbBinaryCompare) = 0)
End Function

Private Function TryRestoreTransactionAnalysisEnableEvents( _
        ByVal previousValue As Boolean, _
        ByVal operationName As String, _
        ByRef detailText As String) As Boolean
    Dim firstDetail As String, retryDetail As String
    Dim stopDetail As String, safeStopDetail As String
    Dim eventsStoppedForRecovery As Boolean
    Dim recoveryEnforcementFailed As Boolean
    Dim recoveryConfirmedThisAttempt As Boolean
    Dim eventsStoppedAfterRecovery As Boolean
    Dim recoveryAttempted As Boolean
    detailText = vbNullString
    If TrySetTransactionAnalysisEnableEventsExact(previousValue, firstDetail) Then
        TryRestoreTransactionAnalysisEnableEvents = True
        Exit Function
    End If
    If TrySetTransactionAnalysisEnableEventsExact(previousValue, retryDetail) Then
        TryRestoreTransactionAnalysisEnableEvents = True
        Exit Function
    End If
    detailText = "Excel�C�x���g��Ԃ��J�n�l�֕����ł��܂���ł����B����=" & _
                 firstDetail & " / �Ď��s=" & retryDetail
    eventsStoppedForRecovery = _
        TrySetTransactionAnalysisEnableEventsExact(False, stopDetail)
    If eventsStoppedForRecovery Then
        AppendTransactionRollbackDetail detailText, _
            "�v�����L�^�O��Excel�C�x���g��~��ǖ߂��m�F���܂����B"
        StopAfterTransactionAnalysisEventStateFailure _
            operationName, detailText, recoveryEnforcementFailed, _
            recoveryConfirmedThisAttempt, eventsStoppedAfterRecovery, _
            recoveryAttempted
    Else
        AppendTransactionRollbackDetail detailText, _
            "�v�����L�^�O�ɂ�Excel�C�x���g��~���m�F�ł����A" & _
            "�u�b�N�ւ�Recovery�����݂����S�̂��ߌ�����܂���: " & _
            stopDetail
        AppendTransactionRollbackDetail detailText, _
            "Excel�C�x���g��ԂƈČ��̈��S��Ԃ͕s���ł��B"
        On Error Resume Next
        MsgBox "Excel�C�x���g�����S�ɒ�~�ł����A�u�b�N�ւ̕����L�^��������܂����B" & _
               vbCrLf & "Excel�C�x���g��ԂƈČ��̈��S��Ԃ͕s���ł��B" & _
               vbCrLf & "���݂̃u�b�N���㏑�����Ȃ��ł��������B", _
               vbCritical, "Excel�C�x���g��Ԃ��m�F�ł��܂���"
        On Error GoTo 0
    End If
    If recoveryAttempted Then _
        Err.Raise vbObjectError + 5195, _
                  "TransactionAnalysisRecoveryFatal/TryRestoreTransactionAnalysisEnableEvents", _
                  detailText
    eventsStoppedForRecovery = _
        TryStopTransactionAnalysisEventsForBookWrites(safeStopDetail)
End Function

Private Sub StopAfterTransactionAnalysisEventStateFailure( _
        ByVal operationName As String, _
        ByRef detailText As String, _
        Optional ByRef recoveryEnforcementFailed As Boolean = False, _
        Optional ByRef recoveryConfirmedThisAttempt As Boolean = False, _
        Optional ByRef eventsStoppedAfterRecovery As Boolean = False, _
        Optional ByRef recoveryAttempted As Boolean = False)
    Dim recoveryDetail As String, stopDetail As String
    Dim recoveryErrorNumber As Long, recoveryErrorDescription As String
    Dim recoveryConfirmed As Boolean
    Dim applicationStateConfirmed As Boolean
    If recoveryAttempted Then
        eventsStoppedAfterRecovery = _
            TryStopTransactionAnalysisEventsForBookWrites(stopDetail)
        AppendTransactionRollbackDetail detailText, _
            "���̏�ʏ����ł�Recovery�ݒ�����Ɏ��s�ς݂̂��߁A" & _
            "��d���s���s���܂���B"
        Err.Raise vbObjectError + 5195, _
                  "TransactionAnalysisRecoveryFatal/StopAfterTransactionAnalysisEventStateFailure", _
                  detailText
    End If
    recoveryEnforcementFailed = False
    recoveryConfirmedThisAttempt = False
    eventsStoppedAfterRecovery = False
    recoveryDetail = operationName & ": " & detailText
    If Not TryStopTransactionAnalysisEventsForBookWrites(stopDetail) Then
        AppendTransactionRollbackDetail recoveryDetail, _
            "�C�x���g��~���m�F�̂��߁A�u�b�N�ւ�Recovery�E�f�f�E��ԕ\���̏����݂�������܂���: " & _
            stopDetail
        AppendTransactionRollbackDetail recoveryDetail, _
            "Excel�C�x���g��ԂƈČ��̈��S��Ԃ͕s���ł��B"
        detailText = recoveryDetail
        Err.Raise vbObjectError + 5195, _
                  "TransactionAnalysisRecoveryFatal/StopAfterTransactionAnalysisEventStateFailure", _
                  detailText
    End If
    AppendTransactionRollbackDetail recoveryDetail, _
        "Recovery�����O��Excel�C�x���g��~��ǖ߂��m�F���܂����B"
    recoveryAttempted = True
    On Error Resume Next
    Err.Clear
    EnforceRollbackRecoveryState recoveryDetail
    recoveryErrorNumber = Err.Number
    recoveryErrorDescription = Err.Description
    Err.Clear
    On Error GoTo 0
    'Enforce����̐V����False exact�������Ȍ�̈��S�����Ɏg���B
    eventsStoppedAfterRecovery = _
        TryStopTransactionAnalysisEventsForBookWrites(stopDetail)
    If recoveryErrorNumber <> 0 Then
        recoveryEnforcementFailed = True
        AppendTransactionRollbackDetail recoveryDetail, _
            "�v������Ԃ̋����ݒ�G���[: Err " & _
            CStr(recoveryErrorNumber) & " " & recoveryErrorDescription
        If Not eventsStoppedAfterRecovery Then _
            AppendTransactionRollbackDetail recoveryDetail, _
                "Recovery��O���Excel�C�x���gFalse�������m�F�ł��܂���: " & _
                stopDetail
        detailText = recoveryDetail
        Err.Raise vbObjectError + 5195, _
                  "TransactionAnalysisRecoveryFatal/StopAfterTransactionAnalysisEventStateFailure", _
                  detailText
    End If

    'Recovery�����͓�����Application lease������邽�߁A��Ԋm�F�O��
    '�O����False exact����蒼���B�m�F��������u�b�N�����ݒ��O�Ɏ�蒼���B
    If Not eventsStoppedAfterRecovery Then
        AppendTransactionRollbackDetail recoveryDetail, _
            "Recovery�������Excel�C�x���g��~���m�F�ł��Ȃ����߁A" & _
            "�f�f�E��ԕ\���̏����݂�������܂���: " & stopDetail
        AppendTransactionRollbackDetail recoveryDetail, _
            "Excel�C�x���g��ԂƈČ��̈��S��Ԃ͕s���ł��B"
        detailText = recoveryDetail
        Err.Raise vbObjectError + 5195, _
                  "TransactionAnalysisRecoveryFatal/StopAfterTransactionAnalysisEventStateFailure", _
                  detailText
    End If
    recoveryConfirmed = _
        TransactionAnalysisRecoveryStateIsConfirmedExact(recoveryDetail)
    If Not recoveryConfirmed Then
        AppendTransactionRollbackDetail recoveryDetail, _
            "�����Recovery��d��Ԃ������m�F�ł��Ȃ����߁A" & _
            "�f�f�E��ԕ\���E�J�n�l�������s���܂���B"
        eventsStoppedAfterRecovery = _
            TryStopTransactionAnalysisEventsForBookWrites(stopDetail)
        detailText = recoveryDetail
        Err.Raise vbObjectError + 5195, _
                  "TransactionAnalysisRecoveryFatal/StopAfterTransactionAnalysisEventStateFailure", _
                  detailText
    End If
    applicationStateConfirmed = _
        TransactionAnalysisApplicationStateAllowsEntryRestore( _
            True, recoveryDetail)
    If Not applicationStateConfirmed Then
        eventsStoppedAfterRecovery = _
            TryStopTransactionAnalysisEventsForBookWrites(stopDetail)
        AppendTransactionRollbackDetail recoveryDetail, _
            "Application��Ԃ��m�F�ł��܂���B"
        detailText = recoveryDetail
        Err.Raise vbObjectError + 5195, _
                  "TransactionAnalysisRecoveryFatal/StopAfterTransactionAnalysisEventStateFailure", _
                  detailText
    End If
    If Not TryStopTransactionAnalysisEventsForBookWrites(stopDetail) Then
        AppendTransactionRollbackDetail recoveryDetail, _
            "Recovery��Ԃ�Application��Ԃ̊m�F���Excel�C�x���gFalse������" & _
            "�m�F�ł��܂���: " & stopDetail
        detailText = recoveryDetail
        Err.Raise vbObjectError + 5195, _
                  "TransactionAnalysisRecoveryFatal/StopAfterTransactionAnalysisEventStateFailure", _
                  detailText
    End If
    detailText = recoveryDetail
    eventsStoppedAfterRecovery = _
        TryStopTransactionAnalysisEventsForBookWrites(stopDetail)
    recoveryConfirmedThisAttempt = eventsStoppedAfterRecovery
    Err.Raise vbObjectError + 5195, _
              "TransactionAnalysisRecoveryFatal/StopAfterTransactionAnalysisEventStateFailure", _
              detailText
End Sub

Private Function TransactionMainActionCaptionStateMatches() As Boolean
    Dim ws As Worksheet, shp As Shape
    Dim expectedCaption As String
    Dim expectedFill As Long, expectedLine As Long
    Dim actionFound As Boolean
    On Error GoTo Failed
    If Not SheetExists(SH_INPUT) Then Exit Function
    Set ws = GetSheet(SH_INPUT)
    If OutputsAreDirty() Then
        expectedCaption = "���[�E���͂��X�V"
        expectedFill = RGB(180, 83, 9)
        expectedLine = RGB(146, 64, 14)
    Else
        expectedCaption = "���[�E���͂��čX�V"
        expectedFill = RGB(15, 118, 110)
        expectedLine = RGB(13, 148, 136)
    End If
    For Each shp In ws.Shapes
        If ToolShapeActionName(shp) = "BuildAllOutputSheets" Then
            actionFound = True
            If StrComp(shp.TextFrame.Characters.Text, expectedCaption, _
                       vbBinaryCompare) <> 0 Then Exit Function
            If shp.Fill.ForeColor.RGB <> expectedFill Or _
               shp.Line.ForeColor.RGB <> expectedLine Then Exit Function
        End If
    Next shp
    TransactionMainActionCaptionStateMatches = actionFound
    Exit Function
Failed:
    Err.Clear
End Function

Public Function ValidateTransactionAnalysisSettings(ByRef detailText As String) As Boolean
    Dim ws As Worksheet
    Dim minAmount As Double, unknownMinAmount As Double
    Dim absoluteTolerance As Double, rateTolerance As Double
    Dim dayValue As Double
    Dim rateOK As Boolean
    Dim problems As String

    If Not SheetExists(SH_CONFIG) Then
        detailText = "�ݒ�V�[�g������܂���B"
        Exit Function
    End If
    Set ws = GetSheet(SH_CONFIG)
    If ws.Cells(ROW_CFG_ANALYSIS_MIN_AMOUNT, COL_CFG_ANALYSIS_VALUE).HasFormula Or _
       ws.Cells(ROW_CFG_ANALYSIS_DAY_WINDOW, COL_CFG_ANALYSIS_VALUE).HasFormula Or _
       ws.Cells(ROW_CFG_ANALYSIS_ABS_TOLERANCE, COL_CFG_ANALYSIS_VALUE).HasFormula Or _
       ws.Cells(ROW_CFG_ANALYSIS_RATE_TOLERANCE, COL_CFG_ANALYSIS_VALUE).HasFormula Or _
       ws.Cells(ROW_CFG_ANALYSIS_UNKNOWN_MIN, COL_CFG_ANALYSIS_VALUE).HasFormula Then _
        problems = problems & "���͏����ɂ͐������g�p�ł��܂���B "
    If Not TryReadAnalysisNumber(ws.Cells(ROW_CFG_ANALYSIS_MIN_AMOUNT, COL_CFG_ANALYSIS_VALUE).Value, _
                                 minAmount) Or minAmount < 0 Or minAmount > MAX_ABS_AMOUNT Then _
        problems = problems & "�V�t�g�E�t���[�̍Œ���z��0�`" & Format$(MAX_ABS_AMOUNT, "#,##0") & "�Ŏw�肵�Ă��������B "
    If Not TryReadAnalysisNumber(ws.Cells(ROW_CFG_ANALYSIS_UNKNOWN_MIN, COL_CFG_ANALYSIS_VALUE).Value, _
                                 unknownMinAmount) Or unknownMinAmount < 0 Or _
                                 unknownMinAmount > MAX_ABS_AMOUNT Then _
        problems = problems & "�s�����o���̍Œ���z��0�`" & _
                   Format$(MAX_ABS_AMOUNT, "#,##0") & "�Ŏw�肵�Ă��������B "
    If Not TryReadAnalysisNumber(ws.Cells(ROW_CFG_ANALYSIS_DAY_WINDOW, COL_CFG_ANALYSIS_VALUE).Value, _
                                 dayValue) Or dayValue <> 3 Then _
        problems = problems & "�������̓�������3����Œ�ł��B�ݒ�l��3�֖߂��Ă��������B "
    If Not TryReadAnalysisNumber(ws.Cells(ROW_CFG_ANALYSIS_ABS_TOLERANCE, COL_CFG_ANALYSIS_VALUE).Value, _
                                 absoluteTolerance) Or absoluteTolerance < 0 Or _
       absoluteTolerance > AUTO_CANDIDATE_MAX_AMOUNT_DIFFERENCE Then _
        problems = problems & "���z���̋��e�z��0�`1,000,000�~�Ŏw�肵�Ă��������B "
    rateOK = TryReadAnalysisRatePercent( _
        ws.Cells(ROW_CFG_ANALYSIS_RATE_TOLERANCE, COL_CFG_ANALYSIS_VALUE), rateTolerance)
    If Not rateOK Or rateTolerance < 0 Or rateTolerance > 10 Then _
        problems = problems & "���z���̋��e����0�`10%�Ŏw�肵�Ă��������B "

    detailText = Trim$(problems)
    ValidateTransactionAnalysisSettings = (Len(detailText) = 0)
End Function

Public Function IsAnalysisReviewStatus(ByVal statusText As String) As Boolean
    Select Case Trim$(statusText)
        Case ANALYSIS_STATUS_UNREVIEWED, ANALYSIS_STATUS_SHIFT_CONFIRMED, _
             ANALYSIS_STATUS_SOURCE_CONFIRMED, ANALYSIS_STATUS_USE_CONFIRMED, _
             ANALYSIS_STATUS_EXCLUDED, ANALYSIS_STATUS_FOLLOWUP
            IsAnalysisReviewStatus = True
    End Select
End Function

Public Sub ProtectTransactionAnalysisSheets(Optional ByVal raiseOnError As Boolean = False)
    Dim sheetNames As Variant, item As Variant
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim currentErrorNumber As Long
    Dim currentErrorDescription As String, currentErrorSource As String
    Dim convergenceDetail As String
    sheetNames = Array(SH_ANALYSIS_SHIFT, SH_ANALYSIS_FLOW, SH_ANALYSIS_UNKNOWN, _
                       SH_ANALYSIS_RESULT, SH_ANALYSIS_DETAIL, SH_BALANCE_RECONCILIATION)
    '�ŏ��̃V�[�g�Ŏ��s���Ă��c���K���ĕی삷��B�ŏ��̌���������ێ����A
    '���i�ďo���ł͑S�V�[�g����������ɍ�Raise����B
    For Each item In sheetNames
        If SheetExists(CStr(item)) Then
            On Error Resume Next
            Err.Clear
            ProtectSingleAnalysisSheet GetSheet(CStr(item))
            currentErrorNumber = Err.Number
            currentErrorDescription = Err.Description
            currentErrorSource = Err.Source
            Err.Clear
            On Error GoTo 0
            If IsTransactionAnalysisRecoveryFatal( _
                   currentErrorNumber, currentErrorSource) Then
                Call TryStopTransactionAnalysisEventsForBookWrites( _
                    convergenceDetail)
                Err.Raise currentErrorNumber, currentErrorSource, _
                          currentErrorDescription
            End If
            If currentErrorNumber <> 0 And errorNumber = 0 Then
                errorNumber = currentErrorNumber
                errorDescription = currentErrorDescription
                errorSource = currentErrorSource
            End If
        End If
    Next item
    If raiseOnError And errorNumber <> 0 Then _
        Err.Raise errorNumber, "ProtectTransactionAnalysisSheets", _
                  errorSource & " / " & errorDescription
End Sub

Public Sub FormatTransactionAnalysisSheets()
    Dim shiftCount As Long, flowCount As Long, unknownCount As Long
    Dim shiftVisible As XlSheetVisibility, flowVisible As XlSheetVisibility
    Dim unknownVisible As XlSheetVisibility
    Dim convergenceDetail As String
    Dim cleanupErrorNumber As Long
    Dim cleanupErrorDescription As String, cleanupErrorSource As String
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    On Error GoTo EH
    If SheetExists(SH_ANALYSIS_SHIFT) Then
        shiftVisible = GetSheet(SH_ANALYSIS_SHIFT).Visible
        shiftCount = Application.Max(0, LastUsedRowInSheet(GetSheet(SH_ANALYSIS_SHIFT)) - 1)
        FinalizeShiftAnalysisSheet GetSheet(SH_ANALYSIS_SHIFT), shiftCount
        GetSheet(SH_ANALYSIS_SHIFT).Visible = shiftVisible
    End If
    If SheetExists(SH_ANALYSIS_FLOW) Then
        flowVisible = GetSheet(SH_ANALYSIS_FLOW).Visible
        flowCount = Application.Max(0, LastUsedRowInSheet(GetSheet(SH_ANALYSIS_FLOW)) - 1)
        FinalizeAdvancedFlowAnalysisSheet GetSheet(SH_ANALYSIS_FLOW), flowCount
        GetSheet(SH_ANALYSIS_FLOW).Visible = flowVisible
    End If
    If SheetExists(SH_ANALYSIS_UNKNOWN) Then
        unknownVisible = GetSheet(SH_ANALYSIS_UNKNOWN).Visible
        unknownCount = Application.Max(0, LastUsedRowInSheet(GetSheet(SH_ANALYSIS_UNKNOWN)) - 1)
        FinalizeUnknownAnalysisSheet GetSheet(SH_ANALYSIS_UNKNOWN), unknownCount
        GetSheet(SH_ANALYSIS_UNKNOWN).Visible = unknownVisible
    End If
    If SheetExists(SH_ANALYSIS_RESULT) Then FormatAnalysisWorkspaceSheets
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    If IsTransactionAnalysisRecoveryFatal(errorNumber, errorSource) Then
        Call TryStopTransactionAnalysisEventsForBookWrites(convergenceDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    On Error Resume Next
    Err.Clear
    ProtectTransactionAnalysisSheets False
    cleanupErrorNumber = Err.Number
    cleanupErrorSource = Err.Source
    cleanupErrorDescription = Err.Description
    Err.Clear
    On Error GoTo 0
    If IsTransactionAnalysisRecoveryFatal( _
           cleanupErrorNumber, cleanupErrorSource) Then
        Call TryStopTransactionAnalysisEventsForBookWrites(convergenceDetail)
        Err.Raise cleanupErrorNumber, cleanupErrorSource, _
                  cleanupErrorDescription
    End If
    Err.Raise errorNumber, "FormatTransactionAnalysisSheets", errorSource & " / " & errorDescription
End Sub

Public Sub CheckTransactionAnalysisSheets(ByRef problems As String, _
                                          ByRef interfaceWarnings As String, _
                                          ByVal includeInterfaceChecks As Boolean)
    CheckSingleAnalysisSheet GetSheet(SH_ANALYSIS_SHIFT), SHIFT_ANALYSIS_STATUS_COL, _
                             SHIFT_ANALYSIS_MEMO_COL, SHIFT_ANALYSIS_KEY_COL, "�����V�t�g���", _
                             problems, interfaceWarnings, includeInterfaceChecks
    CheckSingleAnalysisSheet GetSheet(SH_ANALYSIS_FLOW), FLOW_ANALYSIS_STATUS_COL, _
                             FLOW_ANALYSIS_MEMO_COL, FLOW_ANALYSIS_KEY_COL, "�����t���[�ǐ�", _
                             problems, interfaceWarnings, includeInterfaceChecks
    CheckSingleAnalysisSheet GetSheet(SH_ANALYSIS_UNKNOWN), UNKNOWN_ANALYSIS_STATUS_COL, _
                             UNKNOWN_ANALYSIS_MEMO_COL, UNKNOWN_ANALYSIS_KEY_COL, "�s�����o��", _
                             problems, interfaceWarnings, includeInterfaceChecks
    CheckAnalysisReviewConflicts GetSheet(SH_ANALYSIS_SHIFT), GetSheet(SH_ANALYSIS_FLOW), problems
    CheckAnalysisWorkspace problems, interfaceWarnings, includeInterfaceChecks
End Sub

Private Sub ReadTransactionAnalysisSettings(ByRef minAmount As Double, ByRef dayWindow As Long, _
                                            ByRef absoluteTolerance As Double, _
                                            ByRef rateTolerance As Double, _
                                            ByRef unknownMinAmount As Double)
    Dim ws As Worksheet
    Set ws = GetSheet(SH_CONFIG)
    minAmount = CDbl(ws.Cells(ROW_CFG_ANALYSIS_MIN_AMOUNT, COL_CFG_ANALYSIS_VALUE).Value)
    dayWindow = CLng(ws.Cells(ROW_CFG_ANALYSIS_DAY_WINDOW, COL_CFG_ANALYSIS_VALUE).Value)
    dayWindow = AutoCandidateEffectiveDayWindow(dayWindow)
    absoluteTolerance = CDbl(ws.Cells(ROW_CFG_ANALYSIS_ABS_TOLERANCE, COL_CFG_ANALYSIS_VALUE).Value)
    unknownMinAmount = CDbl(ws.Cells(ROW_CFG_ANALYSIS_UNKNOWN_MIN, COL_CFG_ANALYSIS_VALUE).Value)
    If Not TryReadAnalysisRatePercent( _
        ws.Cells(ROW_CFG_ANALYSIS_RATE_TOLERANCE, COL_CFG_ANALYSIS_VALUE), rateTolerance) Then _
        Err.Raise vbObjectError + 4624, "ReadTransactionAnalysisSettings", _
                  "���z���̋��e����ǂݎ��܂���B"
End Sub

Private Sub FilterAnalysisRowsByMinimum(ByRef sourceData As Variant, ByRef sourceRows() As Long, _
                                        ByVal sourceCount As Long, ByVal isDeposit As Boolean, _
                                        ByVal minimumAmount As Double, ByRef filteredRows() As Long, _
                                        ByRef filteredCount As Long)
    Dim i As Long, sourceRow As Long, amountColumn As Long
    If isDeposit Then amountColumn = OUT_COL_DEPOSIT Else amountColumn = OUT_COL_WITHDRAW
    For i = 1 To sourceCount
        sourceRow = sourceRows(i)
        If CDbl(sourceData(sourceRow, amountColumn)) >= minimumAmount Then
            filteredCount = filteredCount + 1
            filteredRows(filteredCount) = sourceRow
        End If
    Next i
End Sub

Private Function TryReadAnalysisRatePercent(ByVal rateCell As Range, _
                                            ByRef ratePercentOut As Double) As Boolean
    Dim rawRate As Double
    Dim formatText As String, valueText As String
    If rateCell Is Nothing Then Exit Function
    valueText = Replace(CellText(rateCell.Value), "��", "%")
    If Right$(valueText, 1) = "%" Then
        valueText = Trim$(Left$(valueText, Len(valueText) - 1))
        If Not TryReadAnalysisNumber(valueText, rawRate) Then Exit Function
        ratePercentOut = rawRate
        TryReadAnalysisRatePercent = True
        Exit Function
    End If
    If Not TryReadAnalysisNumber(rateCell.Value, rawRate) Then Exit Function
    '�u3�v��Excel�S���������́u3%�v�i�����l0.03�j�̂ǂ����3%�Ƃ��Ĉ����B
    formatText = CellText(rateCell.NumberFormat) & CellText(rateCell.NumberFormatLocal)
    If InStr(1, formatText, "%", vbBinaryCompare) > 0 Then rawRate = rawRate * 100#
    ratePercentOut = rawRate
    TryReadAnalysisRatePercent = True
End Function

Public Sub EnsureExistingAnalysisReviewBounds(ByVal ws As Worksheet, ByVal labelText As String)
    Dim lastR As Long
    If ws Is Nothing Then Exit Sub
    lastR = LastUsedRowInSheet(ws)
    If lastR > MAX_ANALYSIS_OUTPUT_ROWS + 1 Then _
        Err.Raise vbObjectError + 4623, "EnsureExistingAnalysisReviewBounds", _
                  labelText & "�̊����s�����p����𒴂��Ă��܂��B" & _
                  "�m�F�L�^��ی삷�邽�߁A�Đ����O�ɃZ���t�`�F�b�N�ŕs�v�s���m�F���Ă��������B"
End Sub

Private Function TryReadAnalysisNumber(ByVal valueIn As Variant, ByRef numberOut As Double) As Boolean
    On Error GoTo EH
    If IsError(valueIn) Then Exit Function
    If VarType(valueIn) = vbBoolean Then Exit Function
    If Not HasText(valueIn) Then Exit Function
    If Not IsNumeric(valueIn) Then Exit Function
    numberOut = CDbl(valueIn)
    If numberOut <> numberOut Then Exit Function
    TryReadAnalysisNumber = True
    Exit Function
EH:
    TryReadAnalysisNumber = False
End Function

Private Function IsValidAnalysisAmountValue(ByVal valueIn As Variant) As Boolean
    If IsError(valueIn) Then Exit Function
    If IsNull(valueIn) Then Exit Function
    If IsEmpty(valueIn) Then Exit Function
    If VarType(valueIn) = vbBoolean Then Exit Function
    If Not IsNumeric(valueIn) Then Exit Function
    IsValidAnalysisAmountValue = True
End Function

Private Sub ValidateAndIndexAnalysisTransactions(ByRef sourceData As Variant, ByVal minAmount As Double, _
                                                 ByRef withdrawalRows() As Long, ByRef withdrawalCount As Long, _
                                                 ByRef depositRows() As Long, ByRef depositCount As Long, _
                                                 ByRef componentWithdrawalRows() As Long, _
                                                 ByRef componentWithdrawalCount As Long, _
                                                 ByRef componentDepositRows() As Long, _
                                                 ByRef componentDepositCount As Long)
    Dim r As Long
    Dim withdrawalAmount As Double, depositAmount As Double
    Dim hasWithdrawal As Boolean, hasDeposit As Boolean
    Dim timeOK As Boolean, normalizedTime As Variant
    Dim dateOK As Boolean, normalizedDate As Variant
    Dim txID As String, accountID As String
    Dim seenTransactionIDs As Object
    Set seenTransactionIDs = CreateObject("Scripting.Dictionary")
    seenTransactionIDs.CompareMode = vbTextCompare

    For r = 1 To UBound(sourceData, 1)
        If CellText(sourceData(r, WORK_TX_COL_RECORD_TYPE)) = RECORD_TRANSACTION Then
            dateOK = False
            normalizedDate = NormalizeDateOnlyValue(sourceData(r, OUT_COL_DATE), dateOK)
            If Not dateOK Then _
                Err.Raise vbObjectError + 4605, "ValidateAndIndexAnalysisTransactions", _
                          "W_��� " & CStr(r + 1) & "�s�ڂ̓��t���s���ł��B"
            If Abs(CDbl(CDate(sourceData(r, OUT_COL_DATE))) - CDbl(CDate(normalizedDate))) > 0.0000001 Then _
                Err.Raise vbObjectError + 4620, "ValidateAndIndexAnalysisTransactions", _
                          "W_��� " & CStr(r + 1) & "�s�ڂ̓��t��Ɏ������������Ă��܂��B"
            If HasText(sourceData(r, OUT_COL_TIME)) Then
                timeOK = False
                normalizedTime = NormalizeTimeInput(sourceData(r, OUT_COL_TIME), timeOK)
                If Not timeOK Then _
                    Err.Raise vbObjectError + 4606, "ValidateAndIndexAnalysisTransactions", _
                              "W_��� " & CStr(r + 1) & "�s�ڂ̎������s���ł��B"
            End If

            hasWithdrawal = HasText(sourceData(r, OUT_COL_WITHDRAW))
            hasDeposit = HasText(sourceData(r, OUT_COL_DEPOSIT))
            If hasWithdrawal And hasDeposit Then _
                Err.Raise vbObjectError + 4607, "ValidateAndIndexAnalysisTransactions", _
                          "W_��� " & CStr(r + 1) & "�s�ڂɏo���Ɠ������������͂���Ă��܂��B"
            If hasWithdrawal Then
                If Not IsValidAnalysisAmountValue(sourceData(r, OUT_COL_WITHDRAW)) Then _
                    Err.Raise vbObjectError + 4608, "ValidateAndIndexAnalysisTransactions", _
                              "W_��� " & CStr(r + 1) & "�s�ڂ̏o���z���s���ł��B"
                withdrawalAmount = CDbl(sourceData(r, OUT_COL_WITHDRAW))
                If withdrawalAmount < 0 Or withdrawalAmount > MAX_ABS_AMOUNT Then _
                    Err.Raise vbObjectError + 4609, "ValidateAndIndexAnalysisTransactions", _
                              "W_��� " & CStr(r + 1) & "�s�ڂ̏o���z���͈͊O�ł��B"
            Else
                withdrawalAmount = 0
            End If
            If hasDeposit Then
                If Not IsValidAnalysisAmountValue(sourceData(r, OUT_COL_DEPOSIT)) Then _
                    Err.Raise vbObjectError + 4610, "ValidateAndIndexAnalysisTransactions", _
                              "W_��� " & CStr(r + 1) & "�s�ڂ̓����z���s���ł��B"
                depositAmount = CDbl(sourceData(r, OUT_COL_DEPOSIT))
                If depositAmount < 0 Or depositAmount > MAX_ABS_AMOUNT Then _
                    Err.Raise vbObjectError + 4611, "ValidateAndIndexAnalysisTransactions", _
                              "W_��� " & CStr(r + 1) & "�s�ڂ̓����z���͈͊O�ł��B"
            Else
                depositAmount = 0
            End If

            If withdrawalAmount > 0 Or depositAmount > 0 Then
                txID = CellText(sourceData(r, WORK_TX_COL_TRANSACTION_ID))
                accountID = CellText(sourceData(r, WORK_TX_COL_ACCOUNT_ID))
                If Len(txID) = 0 Or Len(accountID) = 0 Then _
                    Err.Raise vbObjectError + 4612, "ValidateAndIndexAnalysisTransactions", _
                              "W_��� " & CStr(r + 1) & "�s�ڂ̎��ID�܂��͌���ID������܂���B"
                If seenTransactionIDs.Exists(txID) Then _
                    Err.Raise vbObjectError + 4618, "ValidateAndIndexAnalysisTransactions", _
                              "W_����̎��ID���d�����Ă��܂�: " & txID
                seenTransactionIDs.Add txID, True
            End If
            If withdrawalAmount > 0 Then
                componentWithdrawalCount = componentWithdrawalCount + 1
                componentWithdrawalRows(componentWithdrawalCount) = r
                If withdrawalAmount >= minAmount Then
                    withdrawalCount = withdrawalCount + 1
                    withdrawalRows(withdrawalCount) = r
                End If
            ElseIf depositAmount > 0 Then
                componentDepositCount = componentDepositCount + 1
                componentDepositRows(componentDepositCount) = r
                If depositAmount >= minAmount Then
                    depositCount = depositCount + 1
                    depositRows(depositCount) = r
                End If
            End If
        End If
    Next r
End Sub

Private Sub ProcessShiftCandidates(ByRef sourceData As Variant, ByRef withdrawalRows() As Long, _
                                   ByVal withdrawalCount As Long, ByRef depositAmounts() As Double, _
                                   ByRef depositSortRows() As Long, ByVal depositCount As Long, _
                                   ByVal dayWindow As Long, ByVal absoluteTolerance As Double, _
                                   ByVal rateTolerance As Double, ByVal settingsSignature As String, _
                                   ByVal writeOutput As Boolean, _
                                   ByVal wsOut As Worksheet, ByVal reviews As Object, _
                                   ByVal candidateCountByTx As Object, ByVal bestScoreByTx As Object, _
                                   ByVal bestRatingByTx As Object, ByRef candidateTotal As Long)
    Dim i As Long, j As Long, firstMatch As Long, lastMatch As Long
    Dim withdrawalRow As Long, depositRow As Long
    Dim withdrawalAmount As Double, depositAmount As Double
    Dim lowerAmount As Double, upperAmount As Double, differenceAmount As Double
    Dim buffer() As Variant, bufferCount As Long, nextOutputRow As Long
    Dim chronology As String, timePrecision As String, elapsedText As String
    Dim amountMatch As String, reasonText As String, ratingText As String
    Dim score As Long, candidateKey As String
    Dim withdrawalTxID As String, depositTxID As String, evidenceDigest As String
    Dim ambiguityCount As Long
    Dim comparisonCount As Double, comparisonRangeCount As Double
    Dim processedComparisons As Long

    candidateTotal = 0
    If writeOutput Then
        If wsOut Is Nothing Then Err.Raise vbObjectError + 4613, "ProcessShiftCandidates", "�o�͐悪����܂���B"
        ReDim buffer(1 To ANALYSIS_BUFFER_ROWS, 1 To SHIFT_ANALYSIS_LAST_COL)
        nextOutputRow = 2
    End If

    For i = 1 To withdrawalCount
        If i Mod 512 = 0 Then AppProgress "�����V�t�g�����ƍ����Ă��܂�...", i, withdrawalCount
        withdrawalRow = withdrawalRows(i)
        withdrawalAmount = CDbl(sourceData(withdrawalRow, OUT_COL_WITHDRAW))
        AnalysisAmountSearchBounds withdrawalAmount, absoluteTolerance, rateTolerance, lowerAmount, upperAmount
        firstMatch = LowerBoundAnalysisAmount(depositAmounts, depositCount, lowerAmount)
        lastMatch = UpperBoundAnalysisAmount(depositAmounts, depositCount, upperAmount)
        If firstMatch <= lastMatch Then
            '���ɂȂ������������ł́A��������E���t�͈͊O�Ƃ��Č�ŏ��O�����
            '�c��ȑg�������~�߂��Ȃ��B�������[�v�֓���O�ɔ�r�\�萔�𐔂���B
            comparisonRangeCount = CDbl(lastMatch - firstMatch + 1)
            If comparisonCount + comparisonRangeCount > MAX_SHIFT_PAIR_COMPARISONS Then
                Err.Raise vbObjectError + 4619, "ProcessShiftCandidates", _
                          "�����V�t�g���̏ƍ��͈͂��L�����邽�߁A���S�̂��ߒ�~���܂����B" & _
                          vbCrLf & "��r�\�肪" & _
                          Format$(comparisonCount + comparisonRangeCount, "#,##0") & _
                          "���𒴂��Ă��܂��B" & vbCrLf & _
                          "�ݒ�̍Œ���z���グ�邩�A���z�����e�����߂Ă���Ď��s���Ă��������B" & _
                          vbCrLf & "�����̕��͌��ʂ͊����ς݂Ƃ��čX�V����܂���B"
            End If
            comparisonCount = comparisonCount + comparisonRangeCount
            For j = firstMatch To lastMatch
                processedComparisons = processedComparisons + 1
                If processedComparisons Mod 32768 = 0 Then _
                    AppProgress "�����V�t�g�����ƍ����Ă��܂�...", _
                                processedComparisons, CLng(MAX_SHIFT_PAIR_COMPARISONS)
                depositRow = depositSortRows(j)
                depositAmount = CDbl(sourceData(depositRow, OUT_COL_DEPOSIT))
                differenceAmount = Abs(withdrawalAmount - depositAmount)
                If AutoCandidateAmountGatePasses(withdrawalAmount, depositAmount, _
                                                  absoluteTolerance, rateTolerance) Then
                    If IsShiftPairEligible(sourceData, withdrawalRow, depositRow, dayWindow) Then
                        EvaluateShiftPair sourceData, withdrawalRow, depositRow, absoluteTolerance, _
                                          chronology, timePrecision, elapsedText, amountMatch, _
                                          reasonText, score, ratingText
                        candidateTotal = candidateTotal + 1
                        If candidateTotal > MAX_ANALYSIS_OUTPUT_ROWS Then Exit Sub
                        withdrawalTxID = CellText(sourceData(withdrawalRow, WORK_TX_COL_TRANSACTION_ID))
                        depositTxID = CellText(sourceData(depositRow, WORK_TX_COL_TRANSACTION_ID))
                        candidateKey = withdrawalTxID & ">" & depositTxID
                        If writeOutput Then
                            ambiguityCount = AnalysisMaximumCandidateCount(candidateCountByTx, _
                                             withdrawalTxID & ";" & depositTxID)
                            evidenceDigest = AnalysisEvidenceDigest(sourceData, _
                                CStr(withdrawalRow) & ";" & CStr(depositRow), _
                                "SHIFT|" & settingsSignature & "|AMB=" & CStr(ambiguityCount))
                            bufferCount = bufferCount + 1
                            FillShiftAnalysisRow buffer, bufferCount, sourceData, withdrawalRow, depositRow, _
                                                 differenceAmount, chronology, timePrecision, elapsedText, _
                                                 amountMatch, reasonText, score, ratingText, candidateKey, _
                                                 evidenceDigest, reviews, candidateCountByTx
                            If bufferCount = ANALYSIS_BUFFER_ROWS Then
                                FlushAnalysisBuffer wsOut, buffer, bufferCount, nextOutputRow, SHIFT_ANALYSIS_LAST_COL
                                ReDim buffer(1 To ANALYSIS_BUFFER_ROWS, 1 To SHIFT_ANALYSIS_LAST_COL)
                                bufferCount = 0
                            End If
                        Else
                            UpdateShiftCandidateStats candidateCountByTx, bestScoreByTx, bestRatingByTx, _
                                                      withdrawalTxID, score, ratingText
                            UpdateShiftCandidateStats candidateCountByTx, bestScoreByTx, bestRatingByTx, _
                                                      depositTxID, score, ratingText
                        End If
                    End If
                End If
            Next j
        End If
    Next i
    If writeOutput And bufferCount > 0 Then _
        FlushAnalysisBuffer wsOut, buffer, bufferCount, nextOutputRow, SHIFT_ANALYSIS_LAST_COL
End Sub

Private Function IsShiftPairEligible(ByRef sourceData As Variant, ByVal withdrawalRow As Long, _
                                     ByVal depositRow As Long, ByVal dayWindow As Long) As Boolean
    Dim withdrawalAccountID As String, depositAccountID As String
    Dim withdrawalDate As Long, depositDate As Long
    Dim withdrawalTime As Double, depositTime As Double
    Dim withdrawalHasTime As Boolean, depositHasTime As Boolean
    withdrawalAccountID = CellText(sourceData(withdrawalRow, WORK_TX_COL_ACCOUNT_ID))
    depositAccountID = CellText(sourceData(depositRow, WORK_TX_COL_ACCOUNT_ID))
    If Len(withdrawalAccountID) = 0 Or Len(depositAccountID) = 0 Then Exit Function
    '����������̏o�����͎����̌����Ԉړ��ł͂Ȃ����ߌ�₩��O���B
    If StrComp(withdrawalAccountID, depositAccountID, vbTextCompare) = 0 Then Exit Function
    withdrawalDate = CLng(VBA.DateValue(CDate(sourceData(withdrawalRow, OUT_COL_DATE))))
    depositDate = CLng(VBA.DateValue(CDate(sourceData(depositRow, OUT_COL_DATE))))
    If Not AutoCandidateDepositDatePasses(withdrawalDate, depositDate, dayWindow) Then _
        Exit Function
    withdrawalHasTime = TryGetAnalysisTime( _
                        sourceData(withdrawalRow, OUT_COL_TIME), withdrawalTime)
    depositHasTime = TryGetAnalysisTime(sourceData(depositRow, OUT_COL_TIME), depositTime)
    If Not AutoCandidatePairChronologyPasses( _
               withdrawalDate, withdrawalHasTime, withdrawalTime, _
               depositDate, depositHasTime, depositTime) Then Exit Function
    IsShiftPairEligible = True
End Function

Private Sub EvaluateShiftPair(ByRef sourceData As Variant, ByVal withdrawalRow As Long, _
                              ByVal depositRow As Long, ByVal absoluteTolerance As Double, _
                              ByRef chronology As String, ByRef timePrecision As String, _
                              ByRef elapsedText As String, ByRef amountMatch As String, _
                              ByRef reasonText As String, ByRef score As Long, ByRef ratingText As String)
    Dim withdrawalDate As Long, depositDate As Long, dayDifference As Long
    Dim withdrawalTime As Double, depositTime As Double
    Dim withdrawalHasTime As Boolean, depositHasTime As Boolean
    Dim signedMinutes As Double, absoluteMinutes As Double
    Dim withdrawalAmount As Double, depositAmount As Double, differenceAmount As Double
    Dim samePerson As Boolean, sameBank As Boolean, timeEvidencePoints As Long
    Dim withdrawalPersonID As String, depositPersonID As String
    Dim personEvidenceText As String
    Dim inheritanceDate As Long
    Dim nearInheritance As Boolean, straddlesInheritance As Boolean

    withdrawalDate = CLng(VBA.DateValue(CDate(sourceData(withdrawalRow, OUT_COL_DATE))))
    depositDate = CLng(VBA.DateValue(CDate(sourceData(depositRow, OUT_COL_DATE))))
    dayDifference = Abs(withdrawalDate - depositDate)
    withdrawalHasTime = TryGetAnalysisTime(sourceData(withdrawalRow, OUT_COL_TIME), withdrawalTime)
    depositHasTime = TryGetAnalysisTime(sourceData(depositRow, OUT_COL_TIME), depositTime)
    If Not AutoCandidatePairChronologyPasses( _
               withdrawalDate, withdrawalHasTime, withdrawalTime, _
               depositDate, depositHasTime, depositTime) Then _
        Err.Raise vbObjectError + 4640, "EvaluateShiftPair", _
                  "�L�^��A�������o�����O�̂��ߎ������ɂł��܂���B"
    If withdrawalHasTime And depositHasTime Then
        timePrecision = "���������L�ڂ���"
    ElseIf withdrawalHasTime Or depositHasTime Then
        timePrecision = "�ꕔ�����L�ڂȂ�"
    Else
        timePrecision = "�����L�ڂȂ�"
    End If

    If withdrawalDate = depositDate Then
        If withdrawalHasTime And depositHasTime Then
            signedMinutes = ((depositDate + depositTime) - (withdrawalDate + withdrawalTime)) * 1440#
            absoluteMinutes = Abs(signedMinutes)
            '�̔ۑ���AutoCandidatePairChronologyPasses�Ɠ���1e-9�����g���B
            '���E�����̔ۂł͓������A�\���ł͋t���ƂȂ�s���������Ȃ��B
            If signedMinutes > 0.00000144 Then
                chronology = "�o��������"
            ElseIf signedMinutes < -0.00000144 Then
                chronology = "�������o��"
            Else
                '�����L�^��������͐��𕜌��ł��Ȃ��B���͏�����ID�ŕ⊮���Ȃ��B
                chronology = "�����������s��"
                elapsedText = "�������i�����s���j"
            End If
            If Len(elapsedText) = 0 Then _
                elapsedText = FormatAnalysisElapsedMinutes(absoluteMinutes)
        Else
            '�����ł��������Е��ȏ㌇����ƁA�L������f��ł��Ȃ��B
            '�����͎����o�H�̌��Ƃ��Ĉ����A���ۂ̑O��֌W�͍��������Ŋm�F����B
            chronology = "�����������s��"
            elapsedText = "�����i�����L�ڂȂ��j"
        End If
    ElseIf withdrawalDate < depositDate Then
        chronology = "�o��������"
        If withdrawalHasTime And depositHasTime Then
            absoluteMinutes = ((depositDate + depositTime) - (withdrawalDate + withdrawalTime)) * 1440#
            elapsedText = FormatAnalysisElapsedMinutes(Abs(absoluteMinutes))
        Else
            elapsedText = CStr(dayDifference) & "��"
        End If
    Else
        chronology = "�������o��"
        If withdrawalHasTime And depositHasTime Then
            absoluteMinutes = ((withdrawalDate + withdrawalTime) - (depositDate + depositTime)) * 1440#
            elapsedText = FormatAnalysisElapsedMinutes(Abs(absoluteMinutes))
        Else
            elapsedText = CStr(dayDifference) & "��"
        End If
    End If

    withdrawalAmount = CDbl(sourceData(withdrawalRow, OUT_COL_WITHDRAW))
    depositAmount = CDbl(sourceData(depositRow, OUT_COL_DEPOSIT))
    differenceAmount = Abs(withdrawalAmount - depositAmount)
    If differenceAmount < 0.0000001 Then
        amountMatch = "���S��v"
        score = 45
    ElseIf differenceAmount <= absoluteTolerance + 0.0000001 Then
        amountMatch = "���e�z��"
        score = 35
    Else
        amountMatch = "���e����"
        score = 25
    End If

    '�����͗�����ɋL�ڂ�����ꍇ���������_�Ƃ���B�Б��ł����L�ڂȂ�0�_�ŁA
    '���L�ڂ��̂��̂ɂ�錸�_�������݂��Ȃ��B
    timeEvidencePoints = ShiftTimeEvidencePoints(withdrawalHasTime, depositHasTime, _
                                                 absoluteMinutes, dayDifference)
    score = score + timeEvidencePoints

    withdrawalPersonID = CellText(sourceData(withdrawalRow, WORK_TX_COL_PERSON_ID))
    depositPersonID = CellText(sourceData(depositRow, WORK_TX_COL_PERSON_ID))
    If Len(withdrawalPersonID) = 0 Or Len(depositPersonID) = 0 Then _
        Err.Raise vbObjectError + 4638, "EvaluateShiftPair", _
                  "���͑Ώێ���ɐl��ID������܂���B�����ł͑�ւ����A�l�����������C�����Ă��������B"
    If Not IsInternalIdValue(withdrawalPersonID, "P") Or _
       Not IsInternalIdValue(depositPersonID, "P") Then _
        Err.Raise vbObjectError + 4639, "EvaluateShiftPair", _
                  "���͑Ώێ���̐l��ID�`�����s���ł��i�o��=" & withdrawalPersonID & _
                  " / ����=" & depositPersonID & "�j�B"
    samePerson = (StrComp(withdrawalPersonID, depositPersonID, vbTextCompare) = 0)
    If samePerson Then
        personEvidenceText = "�l��ID�m�F�ς݁i����l�����j�ł��B"
    Else
        personEvidenceText = "�ʐl���Ԃ̌��ł��i���l��ID�m�F�ς݁j�B"
    End If
    '�����̐l��������������ʉ߂����l��ID�́A����l���E�ʐl���̕ʂ��킸
    '������b�_�Ƃ���B�l���̕ʂ͒�����̕��ނł���A�m�x�������闝�R�ł͂Ȃ��B
    score = score + 12
    score = score + 8  '�قȂ����ID�ł��邱�Ƃ�IsShiftPairEligible�Ŋm�F�ς݁B
    sameBank = (StrComp(CellText(sourceData(withdrawalRow, OUT_COL_BANK)), _
                         CellText(sourceData(depositRow, OUT_COL_BANK)), vbTextCompare) = 0)
    If sameBank Then score = score + 2 Else score = score + 4
    If IsDate(mAnalysisInheritanceDate) Then
        inheritanceDate = CLng(VBA.DateValue(CDate(mAnalysisInheritanceDate)))
        nearInheritance = (Abs(withdrawalDate - inheritanceDate) <= 30 Or _
                           Abs(depositDate - inheritanceDate) <= 30)
        straddlesInheritance = _
            (withdrawalDate < inheritanceDate And depositDate >= inheritanceDate) Or _
            (depositDate < inheritanceDate And withdrawalDate >= inheritanceDate)
    End If

    '���m�̋t����IsShiftPairEligible�Ō��O�Ƃ���B�������L�ڂɂ��
    '�����������s���ɂ́A���_���X�R�A������K�p���Ȃ��B
    If score < 0 Then score = 0
    If score > 100 Then score = 100

    If score >= 80 Then
        ratingText = "��"
    ElseIf score >= 60 Then
        ratingText = "��"
    Else
        ratingText = "��"
    End If
    Select Case amountMatch
        Case "���S��v"
            reasonText = "�o���z�Ɠ����z�͈�v���Ă��܂��B"
        Case "���e�z��"
            reasonText = "���z���͐ݒ肵�����e�z���ł��B"
        Case Else
            reasonText = "���z���͐ݒ肵�����e�����ł��B"
    End Select
    If StrComp(chronology, "�����������s��", vbTextCompare) = 0 Then
        If withdrawalHasTime And depositHasTime Then
            reasonText = AppendAnalysisReason(reasonText, _
                         "�o���Ɠ����̋L�^����������̂��ߓ����������s���ł��B�O��֌W�͒f�肵�Ă��܂���B")
        Else
            reasonText = AppendAnalysisReason(reasonText, _
                         "�����̎���ł����A�����L�ڂȂ��̂��ߓ����������s���ł��B�O��֌W�͒f�肵�Ă��܂���B")
        End If
    ElseIf StrComp(chronology, "������", vbTextCompare) = 0 Then
        reasonText = AppendAnalysisReason(reasonText, "�L�^��͓������ł��B")
    Else
        reasonText = AppendAnalysisReason(reasonText, chronology & "�̏��ŁA�o�߂�" & elapsedText & "�ł��B")
    End If
    reasonText = AppendAnalysisReason(reasonText, "������̌����͈قȂ�܂��B")
    reasonText = AppendAnalysisReason(reasonText, personEvidenceText)
    If sameBank Then
        reasonText = AppendAnalysisReason(reasonText, "��s�͓����ł��B")
    Else
        reasonText = AppendAnalysisReason(reasonText, "��s�͈قȂ�܂��B")
    End If
    If nearInheritance Then _
        reasonText = AppendAnalysisReason(reasonText, "�����J�n���O��30���ȓ��̎�����܂݂܂��B")
    If straddlesInheritance Then _
        reasonText = AppendAnalysisReason(reasonText, _
                     "�����J�n�����܂����ł��܂����A���̓_�͎����ړ��̊m�x�ɂ͉��_���Ă��܂���B")
    reasonText = AppendAnalysisReason(reasonText, _
                 "�E�v�̓��e�͎�������Ɏg�p���Ă��Ȃ����߁A�������Ŋm�F���Ă��������B")
End Sub

'S40: �Б��ł����������L�ڂȂ�A����������0�_�B��������t�ߐړ_�ő�ւ��Ȃ��B
Private Function ShiftTimeEvidencePoints(ByVal withdrawalHasTime As Boolean, _
                                         ByVal depositHasTime As Boolean, _
                                         ByVal absoluteMinutes As Double, _
                                         ByVal dayDifference As Long) As Long
    If Not withdrawalHasTime Or Not depositHasTime Then Exit Function
    If absoluteMinutes <= 15# Then
        ShiftTimeEvidencePoints = 30
    ElseIf absoluteMinutes <= 60# Then
        ShiftTimeEvidencePoints = 26
    ElseIf absoluteMinutes <= 360# Then
        ShiftTimeEvidencePoints = 22
    ElseIf absoluteMinutes <= 1440# Then
        ShiftTimeEvidencePoints = 18
    ElseIf dayDifference <= 2 Then
        ShiftTimeEvidencePoints = 12
    ElseIf dayDifference <= AUTO_CANDIDATE_MAX_CALENDAR_DAYS Then
        ShiftTimeEvidencePoints = 7
    End If
End Function

Private Function AnalysisSingleTimeEvidenceLabel(ByVal rawTimeEntry As Variant) As String
    If HasText(rawTimeEntry) Then
        AnalysisSingleTimeEvidenceLabel = "�����L�ڂ���"
    Else
        AnalysisSingleTimeEvidenceLabel = "�����L�ڂȂ�"
    End If
End Function

Private Function AnalysisUnknownCapacityUpperBound( _
        ByVal withdrawalRows As Long, ByVal depositRows As Long) As Long
    Dim plannedRows As Double
    If withdrawalRows < 0 Or depositRows < 0 Then _
        Err.Raise vbObjectError + 4631, "AnalysisUnknownCapacityUpperBound", _
                  "�s�����o���̗\�茏�����s���ł��B"
    plannedRows = CDbl(withdrawalRows) + CDbl(depositRows)
    If plannedRows > 2147483647# Then _
        Err.Raise vbObjectError + 4631, "AnalysisUnknownCapacityUpperBound", _
                  "�s�����o���̗\�茏����Long�͈͂ŕ\���ł��܂���B"
    If plannedRows > CDbl(MAX_ANALYSIS_OUTPUT_ROWS) Then
        AnalysisUnknownCapacityUpperBound = MAX_ANALYSIS_OUTPUT_ROWS
    Else
        AnalysisUnknownCapacityUpperBound = CLng(plannedRows)
    End If
End Function

'�V�[�g�������������A�����E���������E�l��ID�K�{�̕]���������Œ肷��B
Public Function TransactionAnalysisRegressionTest() As Boolean
    Dim sourceData As Variant, previousInheritanceDate As Variant
    Dim chronology As String, timePrecision As String, elapsedText As String
    Dim amountMatch As String, reasonText As String, ratingText As String
    Dim forwardScore As Long, missingTimeScore As Long
    Dim partialMissingScore As Long
    Dim differentPersonScore As Long
    Dim missingChronology As String, missingPrecision As String, differentPersonReason As String
    Dim equalTimeChronology As String
    Dim shiftDateGatePasses As Boolean, shiftChronologyGatePasses As Boolean
    Dim missingPersonRejected As Boolean
    previousInheritanceDate = mAnalysisInheritanceDate
    On Error GoTo Failed
    If AnalysisUnknownCapacityUpperBound(2, 3) <> 5 Then GoTo Failed
    If AnalysisUnknownCapacityUpperBound( _
           MAX_ANALYSIS_OUTPUT_ROWS, MAX_ANALYSIS_OUTPUT_ROWS) <> _
       MAX_ANALYSIS_OUTPUT_ROWS Then GoTo Failed
    If Not AnalysisAllocationAmountsMatch(1000000#, 1000000.0000004) Then _
        GoTo Failed
    If AnalysisAllocationAmountsMatch(1000000#, 1000000.0005) Then GoTo Failed
    If Not FlowAllocationReviewNeedsLedger( _
               ANALYSIS_STATUS_SHIFT_CONFIRMED, vbNullString) Then GoTo Failed
    If Not FlowAllocationReviewNeedsLedger( _
               ANALYSIS_STATUS_FOLLOWUP, _
               ALLOCATION_AMBIGUITY_MEMO_MARKER & "���Ċm�F") Then GoTo Failed
    If FlowAllocationReviewNeedsLedger( _
           ANALYSIS_STATUS_FOLLOWUP, "�C�ӂ̒ǉ�����") Then GoTo Failed
    If FlowAllocationReviewNeedsLedger( _
           ANALYSIS_STATUS_EXCLUDED, ALLOCATION_AMBIGUITY_MEMO_MARKER) Then GoTo Failed
    If Not FlowAllocationCandidateRequiresReview( _
               ANALYSIS_STATUS_SHIFT_CONFIRMED, 2, 2, 100#, 100#, 100#) Then _
        GoTo Failed
    If FlowAllocationCandidateRequiresReview( _
           ANALYSIS_STATUS_SHIFT_CONFIRMED, 1, 2, 100#, 100#, 100#) Then _
        GoTo Failed
    If Not FlowAllocationCandidateRequiresReview( _
               ANALYSIS_STATUS_SHIFT_CONFIRMED, 1, 2, 90#, 100#, 90#) Then _
        GoTo Failed
    If Not TransactionAnalysisAtomicSnapshotCapacityRegression() Then GoTo Failed
    mAnalysisInheritanceDate = Empty
    ReDim sourceData(1 To 2, 1 To WORK_TX_COL_PERSON_ID)
    sourceData(1, OUT_COL_DATE) = DateSerial(2026, 1, 2)
    sourceData(2, OUT_COL_DATE) = DateSerial(2026, 1, 2)
    sourceData(1, OUT_COL_WITHDRAW) = 100000#
    sourceData(2, OUT_COL_DEPOSIT) = 100000#
    sourceData(1, OUT_COL_PERSON) = "�b"
    sourceData(2, OUT_COL_PERSON) = "�b"
    sourceData(1, WORK_TX_COL_PERSON_ID) = "P1"
    sourceData(2, WORK_TX_COL_PERSON_ID) = "P1"
    sourceData(1, OUT_COL_BANK) = "A��s"
    sourceData(2, OUT_COL_BANK) = "B��s"
    sourceData(1, WORK_TX_COL_ACCOUNT_ID) = "A1"
    sourceData(2, WORK_TX_COL_ACCOUNT_ID) = "A2"

    sourceData(1, OUT_COL_TIME) = TimeSerial(9, 50, 0)
    sourceData(2, OUT_COL_TIME) = TimeSerial(10, 0, 0)
    shiftChronologyGatePasses = IsShiftPairEligible(sourceData, 1, 2, 365)
    EvaluateShiftPair sourceData, 1, 2, 0#, chronology, timePrecision, _
                      elapsedText, amountMatch, reasonText, forwardScore, ratingText

    sourceData(1, OUT_COL_TIME) = TimeSerial(10, 0, 0)
    sourceData(2, OUT_COL_TIME) = TimeSerial(9, 50, 0)
    shiftChronologyGatePasses = shiftChronologyGatePasses And _
                                Not IsShiftPairEligible(sourceData, 1, 2, 365)

    sourceData(2, OUT_COL_TIME) = TimeSerial(10, 0, 0)
    shiftChronologyGatePasses = shiftChronologyGatePasses And _
                                IsShiftPairEligible(sourceData, 1, 2, 365)
    EvaluateShiftPair sourceData, 1, 2, 0#, equalTimeChronology, timePrecision, _
                      elapsedText, amountMatch, reasonText, partialMissingScore, ratingText
    If StrComp(equalTimeChronology, "�����������s��", vbBinaryCompare) <> 0 Then _
        GoTo Failed

    '1e-9���ȓ��̊ۂߋ��E�͍̔ۂƕ\�����Ƃ��ɓ����������ɂ���B
    sourceData(1, OUT_COL_TIME) = 0.5
    sourceData(2, OUT_COL_TIME) = 0.5 - 0.0000000008
    shiftChronologyGatePasses = shiftChronologyGatePasses And _
                                IsShiftPairEligible(sourceData, 1, 2, 365)
    EvaluateShiftPair sourceData, 1, 2, 0#, equalTimeChronology, timePrecision, _
                      elapsedText, amountMatch, reasonText, partialMissingScore, ratingText
    If StrComp(equalTimeChronology, "�����������s��", vbBinaryCompare) <> 0 Then _
        GoTo Failed

    sourceData(1, OUT_COL_TIME) = Empty
    sourceData(2, OUT_COL_TIME) = Empty
    shiftChronologyGatePasses = shiftChronologyGatePasses And _
                                IsShiftPairEligible(sourceData, 1, 2, 365)
    EvaluateShiftPair sourceData, 1, 2, 0#, chronology, timePrecision, _
                      elapsedText, amountMatch, reasonText, missingTimeScore, ratingText
    missingChronology = chronology
    missingPrecision = timePrecision

    sourceData(1, OUT_COL_TIME) = TimeSerial(9, 50, 0)
    sourceData(2, OUT_COL_TIME) = Empty
    EvaluateShiftPair sourceData, 1, 2, 0#, chronology, timePrecision, _
                      elapsedText, amountMatch, reasonText, partialMissingScore, ratingText
    If partialMissingScore <> missingTimeScore Then GoTo Failed
    If StrComp(chronology, "�����������s��", vbBinaryCompare) <> 0 Then GoTo Failed
    If StrComp(timePrecision, "�ꕔ�����L�ڂȂ�", vbBinaryCompare) <> 0 Then GoTo Failed

    sourceData(1, OUT_COL_TIME) = TimeSerial(9, 50, 0)
    sourceData(2, OUT_COL_TIME) = TimeSerial(10, 0, 0)
    sourceData(2, WORK_TX_COL_PERSON_ID) = "P2"
    EvaluateShiftPair sourceData, 1, 2, 0#, chronology, timePrecision, _
                      elapsedText, amountMatch, reasonText, differentPersonScore, ratingText
    differentPersonReason = reasonText
    sourceData(2, WORK_TX_COL_PERSON_ID) = "P1"

    sourceData(1, WORK_TX_COL_PERSON_ID) = Empty
    sourceData(2, WORK_TX_COL_PERSON_ID) = Empty
    missingPersonRejected = ShiftPairRejectsMissingPersonID(sourceData, 1, 2)
    sourceData(1, WORK_TX_COL_PERSON_ID) = "P1"
    sourceData(2, WORK_TX_COL_PERSON_ID) = "P1"

    sourceData(1, OUT_COL_DATE) = DateSerial(2026, 1, 2)
    sourceData(1, OUT_COL_TIME) = Empty
    sourceData(2, OUT_COL_TIME) = Empty
    sourceData(2, OUT_COL_DATE) = DateSerial(2026, 1, 2)
    shiftDateGatePasses = IsShiftPairEligible(sourceData, 1, 2, 365)
    sourceData(2, OUT_COL_DATE) = DateSerial(2026, 1, 5)
    shiftDateGatePasses = shiftDateGatePasses And _
                          IsShiftPairEligible(sourceData, 1, 2, 365)
    sourceData(2, OUT_COL_DATE) = DateSerial(2026, 1, 6)
    shiftDateGatePasses = shiftDateGatePasses And _
                          Not IsShiftPairEligible(sourceData, 1, 2, 365)
    sourceData(2, OUT_COL_DATE) = DateSerial(2026, 1, 1)
    shiftDateGatePasses = shiftDateGatePasses And _
                          Not IsShiftPairEligible(sourceData, 1, 2, 365)
    sourceData(2, OUT_COL_DATE) = DateSerial(2026, 1, 4)
    shiftDateGatePasses = shiftDateGatePasses And _
                          Not IsShiftPairEligible(sourceData, 1, 2, 1)

    If StrComp(AnalysisSingleTimeEvidenceLabel(Empty), "�����L�ڂȂ�", _
               vbBinaryCompare) <> 0 Then GoTo Failed
    If Not AnalysisReviewConflictStopRegression() Then GoTo Failed
    '�����_�̌Œ�l�ł͂Ȃ��AS38�ES40�̊֌W�ƕ\���_����Œ肷��B
    TransactionAnalysisRegressionTest = _
        (forwardScore > missingTimeScore And shiftChronologyGatePasses And _
         ShiftTimeEvidencePoints(False, False, 0#, 0) = 0 And _
         ShiftTimeEvidencePoints(True, False, 0#, 0) = 0 And _
         StrComp(missingChronology, "�����������s��", vbBinaryCompare) = 0 And _
         InStr(1, missingPrecision, "�����L�ڂȂ�", vbBinaryCompare) > 0 And _
         forwardScore = differentPersonScore And _
         InStr(1, differentPersonReason, "�ʐl����", vbBinaryCompare) > 0 And _
         missingPersonRejected And shiftDateGatePasses And _
         DecidedAnalysisPolicyRegressionTest())
    mAnalysisInheritanceDate = previousInheritanceDate
    Exit Function
Failed:
    mAnalysisInheritanceDate = previousInheritanceDate
    TransactionAnalysisRegressionTest = False
End Function

Private Function TransactionAnalysisAtomicSnapshotCapacityRegression() As Boolean
    Dim snapshots() As TransactionAnalysisSheetSnapshot
    Dim rowCounts() As Long
    Dim i As Long, errorNumber As Long
    Dim calculatedWork As Double, ledgerCellWork As Double
    Dim expectedWork As Double
    On Error GoTo Failed
    InitializeTransactionAnalysisAtomicSheets snapshots
    ReDim rowCounts(LBound(snapshots) To UBound(snapshots))
    ledgerCellWork = CDbl(AllocationLedgerStoredRowCount() + 1) * 10# * _
                     CDbl(TRANSACTION_ATOMIC_SNAPSHOT_COPIES)

    expectedWork = 456# + ledgerCellWork
    If TransactionAnalysisAtomicSnapshotCellWorkFromCounts( _
           snapshots, rowCounts, 0, False) <> expectedWork Then GoTo Failed
    If TransactionAnalysisOperationPeakSnapshotCellWork(expectedWork) <> _
       expectedWork * 2# Then _
        GoTo Failed
    expectedWork = 1236# + ledgerCellWork
    If TransactionAnalysisAtomicSnapshotCellWorkFromCounts( _
           snapshots, rowCounts, 0, True) <> expectedWork Then GoTo Failed
    If TransactionAnalysisOperationPeakSnapshotCellWork(expectedWork) <> _
       expectedWork * 2# Then _
        GoTo Failed
    For i = LBound(rowCounts) To UBound(rowCounts)
        rowCounts(i) = 1
    Next i
    expectedWork = 1800# + ledgerCellWork
    If TransactionAnalysisAtomicSnapshotCellWorkFromCounts( _
           snapshots, rowCounts, 1, True) <> expectedWork Then GoTo Failed
    If TransactionAnalysisOperationPeakSnapshotCellWork(expectedWork) <> _
       expectedWork * 2# Then _
        GoTo Failed

    For i = LBound(rowCounts) To UBound(rowCounts)
        rowCounts(i) = 0
    Next i
    rowCounts(5) = MAX_ANALYSIS_OUTPUT_ROWS * 2
    expectedWork = 12000456# + ledgerCellWork
    If TransactionAnalysisAtomicSnapshotCellWorkFromCounts( _
           snapshots, rowCounts, 0, False) <> expectedWork Then GoTo Failed
    If TransactionAnalysisOperationPeakSnapshotCellWork(expectedWork) <> _
       expectedWork * 2# Then GoTo Failed

    rowCounts(5) = MAX_ANALYSIS_OUTPUT_ROWS * 2 + 1
    On Error Resume Next
    Err.Clear
    calculatedWork = TransactionAnalysisAtomicSnapshotCellWorkFromCounts( _
                         snapshots, rowCounts, 0, False)
    errorNumber = Err.Number
    Err.Clear
    On Error GoTo Failed
    If errorNumber <> vbObjectError + 4653 Then GoTo Failed
    TransactionAnalysisAtomicSnapshotCapacityRegression = True
    Exit Function
Failed:
    Err.Clear
    TransactionAnalysisAtomicSnapshotCapacityRegression = False
End Function

'S45: ���L���ID�̊m�F�ς݋����́A�����̊m�F������ؕύX�����ۑ����~����B
'���[�N�V�[�g���g��Ȃ�����fixture�ŁA��~�G���[�Ɗm�F�󋵁E���R�E�����̕s�ς��Œ肷��B
Private Function AnalysisReviewConflictStopRegression() As Boolean
    Dim candidateRows As Object, countByTx As Object, membership As Object
    Dim reviewCells(1 To 2, 1 To 3) As Variant
    Dim errorNumber As Long, errorDescription As String
    On Error GoTo ExpectedConflict
    Set candidateRows = CreateObject("Scripting.Dictionary")
    Set countByTx = CreateObject("Scripting.Dictionary")
    Set membership = CreateObject("Scripting.Dictionary")
    candidateRows.CompareMode = vbTextCompare
    countByTx.CompareMode = vbTextCompare
    membership.CompareMode = vbTextCompare
    reviewCells(1, 1) = ANALYSIS_STATUS_SHIFT_CONFIRMED
    reviewCells(1, 2) = "�������RA"
    reviewCells(1, 3) = "��������A"
    reviewCells(2, 1) = ANALYSIS_STATUS_SHIFT_CONFIRMED
    reviewCells(2, 2) = "�������RB"
    reviewCells(2, 3) = "��������B"
    RegisterConfirmedAnalysisCandidate candidateRows, countByTx, membership, _
                                       "1|���A", 1, 2, "TX-SHARED;TX-A"
    RegisterConfirmedAnalysisCandidate candidateRows, countByTx, membership, _
                                       "2|���B", 2, 2, "TX-SHARED;TX-B"
    RequireNoConfirmedAnalysisReviewConflict countByTx
    Exit Function
ExpectedConflict:
    errorNumber = Err.Number
    errorDescription = Err.Description
    Err.Clear
    On Error GoTo Failed
    If errorNumber <> vbObjectError + 4630 Then Exit Function
    If InStr(1, errorDescription, "TX-SHARED", vbBinaryCompare) = 0 Then Exit Function
    If StrComp(CStr(reviewCells(1, 1)), ANALYSIS_STATUS_SHIFT_CONFIRMED, _
               vbBinaryCompare) <> 0 Then Exit Function
    If StrComp(CStr(reviewCells(1, 2)), "�������RA", vbBinaryCompare) <> 0 Then Exit Function
    If StrComp(CStr(reviewCells(1, 3)), "��������A", vbBinaryCompare) <> 0 Then Exit Function
    If StrComp(CStr(reviewCells(2, 1)), ANALYSIS_STATUS_SHIFT_CONFIRMED, _
               vbBinaryCompare) <> 0 Then Exit Function
    If StrComp(CStr(reviewCells(2, 2)), "�������RB", vbBinaryCompare) <> 0 Then Exit Function
    If StrComp(CStr(reviewCells(2, 3)), "��������B", vbBinaryCompare) <> 0 Then Exit Function
    countByTx("TX-SHARED") = 1
    RequireNoConfirmedAnalysisReviewConflict countByTx
    AnalysisReviewConflictStopRegression = True
    Exit Function
Failed:
    Err.Clear
    AnalysisReviewConflictStopRegression = False
End Function

Private Function ShiftPairRejectsMissingPersonID(ByRef sourceData As Variant, _
                                                  ByVal withdrawalRow As Long, _
                                                  ByVal depositRow As Long) As Boolean
    Dim chronology As String, timePrecision As String, elapsedText As String
    Dim amountMatch As String, reasonText As String, ratingText As String, score As Long
    On Error GoTo Rejected
    EvaluateShiftPair sourceData, withdrawalRow, depositRow, 0#, chronology, timePrecision, _
                      elapsedText, amountMatch, reasonText, score, ratingText
    Exit Function
Rejected:
    ShiftPairRejectsMissingPersonID = (Err.Number = vbObjectError + 4638)
    Err.Clear
End Function

Private Sub FillShiftAnalysisRow(ByRef buffer() As Variant, ByVal bufferRow As Long, _
                                 ByRef sourceData As Variant, ByVal withdrawalRow As Long, _
                                 ByVal depositRow As Long, ByVal differenceAmount As Double, _
                                 ByVal chronology As String, ByVal timePrecision As String, _
                                 ByVal elapsedText As String, ByVal amountMatch As String, _
                                 ByVal reasonText As String, ByVal score As Long, _
                                 ByVal ratingText As String, ByVal candidateKey As String, _
                                 ByVal evidenceDigest As String, ByVal reviews As Object, _
                                 ByVal candidateCountByTx As Object)
    Dim reviewValues As Variant
    Dim withdrawalTxID As String, depositTxID As String, ambiguityCount As Long
    withdrawalTxID = CellText(sourceData(withdrawalRow, WORK_TX_COL_TRANSACTION_ID))
    depositTxID = CellText(sourceData(depositRow, WORK_TX_COL_TRANSACTION_ID))
    ambiguityCount = AnalysisMaximumCandidateCount(candidateCountByTx, _
                                                    withdrawalTxID & ";" & depositTxID)
    If ambiguityCount > 1 Then
        reasonText = AppendAnalysisReason(reasonText, "���������܂ތ�₪�ő�" & _
                     CStr(ambiguityCount) & "������A�m��O�ɏd�����p���m�F���Ă��������B")
    End If
    reasonText = AppendAnalysisReason(reasonText, _
                 "���͓��͍ςݎ���͈͓̔��ł̐���ł��B�����ڎ���̕s���݂��Ӗ����܂���B")
    reviewValues = AnalysisReviewValues(reviews, candidateKey, evidenceDigest)
    If CBool(reviewValues(2)) Then
        reasonText = AppendAnalysisReason(reasonText, _
                     "�O��m�F��ɍ�������܂��͕��͏������ς�������߁A�Ċm�F�֖߂��܂����B")
        reviewValues(1) = AppendAnalysisMemo(CStr(reviewValues(1)), _
                          "[����] ��������܂��͕��͏����̕ύX�����m���A�Ċm�F�֖߂��܂����B")
    End If
    buffer(bufferRow, 1) = ratingText
    buffer(bufferRow, 2) = score
    buffer(bufferRow, 3) = "1��1"
    buffer(bufferRow, 4) = chronology
    buffer(bufferRow, 5) = timePrecision
    buffer(bufferRow, 6) = elapsedText
    buffer(bufferRow, 7) = amountMatch
    buffer(bufferRow, 8) = differenceAmount
    buffer(bufferRow, 9) = CDate(sourceData(withdrawalRow, OUT_COL_DATE))
    buffer(bufferRow, 10) = AnalysisTimeOutputValue(sourceData(withdrawalRow, OUT_COL_TIME))
    buffer(bufferRow, 11) = sourceData(withdrawalRow, OUT_COL_PERSON)
    buffer(bufferRow, 12) = sourceData(withdrawalRow, WORK_TX_COL_RELATIONSHIP)
    buffer(bufferRow, 13) = sourceData(withdrawalRow, OUT_COL_BANK)
    buffer(bufferRow, 14) = sourceData(withdrawalRow, OUT_COL_BRANCH)
    buffer(bufferRow, 15) = sourceData(withdrawalRow, OUT_COL_ACCOUNT_TYPE)
    buffer(bufferRow, 16) = sourceData(withdrawalRow, OUT_COL_ACCOUNT_NO)
    buffer(bufferRow, 17) = sourceData(withdrawalRow, OUT_COL_WITHDRAW)
    buffer(bufferRow, 18) = sourceData(withdrawalRow, OUT_COL_TEKIYO)
    buffer(bufferRow, 19) = CDate(sourceData(depositRow, OUT_COL_DATE))
    buffer(bufferRow, 20) = AnalysisTimeOutputValue(sourceData(depositRow, OUT_COL_TIME))
    buffer(bufferRow, 21) = sourceData(depositRow, OUT_COL_PERSON)
    buffer(bufferRow, 22) = sourceData(depositRow, WORK_TX_COL_RELATIONSHIP)
    buffer(bufferRow, 23) = sourceData(depositRow, OUT_COL_BANK)
    buffer(bufferRow, 24) = sourceData(depositRow, OUT_COL_BRANCH)
    buffer(bufferRow, 25) = sourceData(depositRow, OUT_COL_ACCOUNT_TYPE)
    buffer(bufferRow, 26) = sourceData(depositRow, OUT_COL_ACCOUNT_NO)
    buffer(bufferRow, 27) = sourceData(depositRow, OUT_COL_DEPOSIT)
    buffer(bufferRow, 28) = sourceData(depositRow, OUT_COL_TEKIYO)
    buffer(bufferRow, 29) = reasonText
    buffer(bufferRow, 30) = reviewValues(0)
    buffer(bufferRow, 31) = reviewValues(1)
    buffer(bufferRow, 32) = AnalysisStoredKey(candidateKey, evidenceDigest)
    buffer(bufferRow, 33) = sourceData(withdrawalRow, WORK_TX_COL_TRANSACTION_ID)
    buffer(bufferRow, 34) = sourceData(depositRow, WORK_TX_COL_TRANSACTION_ID)
End Sub

Public Sub UpdateShiftCandidateStats(ByVal candidateCountByTx As Object, ByVal bestScoreByTx As Object, _
                                      ByVal bestRatingByTx As Object, ByVal transactionID As String, _
                                      ByVal score As Long, ByVal ratingText As String)
    If candidateCountByTx.Exists(transactionID) Then
        candidateCountByTx(transactionID) = CLng(candidateCountByTx(transactionID)) + 1
    Else
        candidateCountByTx.Add transactionID, 1
    End If
    If Not bestScoreByTx.Exists(transactionID) Then
        bestScoreByTx.Add transactionID, score
        bestRatingByTx.Add transactionID, ratingText
    ElseIf score > CLng(bestScoreByTx(transactionID)) Then
        bestScoreByTx(transactionID) = score
        bestRatingByTx(transactionID) = ratingText
    End If
End Sub

Private Sub WriteUnknownAnalysis(ByRef sourceData As Variant, ByRef withdrawalRows() As Long, _
                                 ByVal withdrawalCount As Long, ByRef depositRows() As Long, _
                                 ByVal depositCount As Long, ByVal reviews As Object, _
                                 ByVal candidateCountByTx As Object, ByVal confirmedCountByTx As Object, _
                                 ByVal allocationIndex As Object, _
                                 ByVal bestRatingByTx As Object, ByVal unknownContextByTx As Object, _
                                 ByVal settingsSignature As String, _
                                 ByVal wsOut As Worksheet, ByRef writtenCount As Long)
    Dim buffer() As Variant
    Dim bufferCount As Long, nextOutputRow As Long, i As Long
    Dim allocatedAmount As Double, unresolvedAmount As Double
    Dim allocationCount As Long
    ReDim buffer(1 To ANALYSIS_BUFFER_ROWS, 1 To UNKNOWN_ANALYSIS_LAST_COL)
    nextOutputRow = 2
    For i = 1 To withdrawalCount
        If TryGetUnknownResidual(sourceData, withdrawalRows(i), False, allocationIndex, _
                                 allocatedAmount, unresolvedAmount, allocationCount) Then
            bufferCount = bufferCount + 1
            FillUnknownAnalysisRow buffer, bufferCount, sourceData, withdrawalRows(i), False, reviews, _
                                   candidateCountByTx, confirmedCountByTx, bestRatingByTx, _
                                   unknownContextByTx, settingsSignature, allocatedAmount, _
                                   unresolvedAmount, allocationCount
            writtenCount = writtenCount + 1
            If bufferCount = ANALYSIS_BUFFER_ROWS Then
                FlushAnalysisBuffer wsOut, buffer, bufferCount, nextOutputRow, UNKNOWN_ANALYSIS_LAST_COL
                ReDim buffer(1 To ANALYSIS_BUFFER_ROWS, 1 To UNKNOWN_ANALYSIS_LAST_COL)
                bufferCount = 0
            End If
        End If
    Next i
    For i = 1 To depositCount
        If TryGetUnknownResidual(sourceData, depositRows(i), True, allocationIndex, _
                                 allocatedAmount, unresolvedAmount, allocationCount) Then
            bufferCount = bufferCount + 1
            FillUnknownAnalysisRow buffer, bufferCount, sourceData, depositRows(i), True, reviews, _
                                   candidateCountByTx, confirmedCountByTx, bestRatingByTx, _
                                   unknownContextByTx, settingsSignature, allocatedAmount, _
                                   unresolvedAmount, allocationCount
            writtenCount = writtenCount + 1
            If bufferCount = ANALYSIS_BUFFER_ROWS Then
                FlushAnalysisBuffer wsOut, buffer, bufferCount, nextOutputRow, UNKNOWN_ANALYSIS_LAST_COL
                ReDim buffer(1 To ANALYSIS_BUFFER_ROWS, 1 To UNKNOWN_ANALYSIS_LAST_COL)
                bufferCount = 0
            End If
        End If
    Next i
    If bufferCount > 0 Then _
        FlushAnalysisBuffer wsOut, buffer, bufferCount, nextOutputRow, UNKNOWN_ANALYSIS_LAST_COL
End Sub

Private Function CountUnresolvedUnknownAnalysisRows( _
        ByRef sourceData As Variant, ByRef withdrawalRows() As Long, _
        ByVal withdrawalCount As Long, ByRef depositRows() As Long, _
        ByVal depositCount As Long, ByVal allocationIndex As Object) As Long
    Dim i As Long, allocatedAmount As Double, unresolvedAmount As Double
    Dim allocationCount As Long
    For i = 1 To withdrawalCount
        If TryGetUnknownResidual(sourceData, withdrawalRows(i), False, allocationIndex, _
                                 allocatedAmount, unresolvedAmount, allocationCount) Then _
            CountUnresolvedUnknownAnalysisRows = CountUnresolvedUnknownAnalysisRows + 1
    Next i
    For i = 1 To depositCount
        If TryGetUnknownResidual(sourceData, depositRows(i), True, allocationIndex, _
                                 allocatedAmount, unresolvedAmount, allocationCount) Then _
            CountUnresolvedUnknownAnalysisRows = CountUnresolvedUnknownAnalysisRows + 1
    Next i
End Function

Private Function TryGetUnknownResidual( _
        ByRef sourceData As Variant, ByVal sourceRow As Long, _
        ByVal isDeposit As Boolean, ByVal allocationIndex As Object, _
        ByRef allocatedAmount As Double, ByRef unresolvedAmount As Double, _
        ByRef allocationCount As Long) As Boolean
    Const AMOUNT_EPSILON As Double = 0.0000001
    Dim transactionID As String, directionText As String, sourceAmount As Double
    transactionID = CellText(sourceData(sourceRow, WORK_TX_COL_TRANSACTION_ID))
    If isDeposit Then
        sourceAmount = CDbl(sourceData(sourceRow, OUT_COL_DEPOSIT))
        directionText = ALLOCATION_DIRECTION_DEPOSIT
    Else
        sourceAmount = CDbl(sourceData(sourceRow, OUT_COL_WITHDRAW))
        directionText = ALLOCATION_DIRECTION_WITHDRAW
    End If
    If Not GetTransactionUnresolvedAmountFromIndex( _
            allocationIndex, transactionID, directionText, sourceAmount, _
            allocatedAmount, unresolvedAmount, allocationCount) Then Exit Function
    If Abs((allocatedAmount + unresolvedAmount) - sourceAmount) > _
       Application.Max(AMOUNT_EPSILON, Abs(sourceAmount) * 0.000000001) Then _
        Err.Raise vbObjectError + 4690, "TryGetUnknownResidual", _
                  "�z���z�Ɩ��ǐՎc�z�̍��v�������z�ƈ�v���܂���: " & transactionID
    TryGetUnknownResidual = (unresolvedAmount > AMOUNT_EPSILON)
End Function

Private Sub FillUnknownAnalysisRow(ByRef buffer() As Variant, ByVal bufferRow As Long, _
                                   ByRef sourceData As Variant, ByVal sourceRow As Long, _
                                   ByVal isDeposit As Boolean, ByVal reviews As Object, _
                                   ByVal candidateCountByTx As Object, _
                                   ByVal confirmedCountByTx As Object, ByVal bestRatingByTx As Object, _
                                   ByVal unknownContextByTx As Object, _
                                   ByVal settingsSignature As String, _
                                   ByVal allocatedAmount As Double, _
                                   ByVal unresolvedAmount As Double, _
                                   ByVal allocationCount As Long)
    Dim amountValue As Double, originalAmount As Double
    Dim score As Long, priorityText As String, reasonText As String
    Dim transactionID As String, reviewKey As String, kindText As String
    Dim candidateCount As Long, confirmedCount As Long, bestRating As String
    Dim contextText As String, contextScore As Long, evidenceDigest As String
    Dim reviewValues As Variant
    transactionID = CellText(sourceData(sourceRow, WORK_TX_COL_TRANSACTION_ID))
    If isDeposit Then
        originalAmount = CDbl(sourceData(sourceRow, OUT_COL_DEPOSIT))
        kindText = "�����s�����"
    Else
        originalAmount = CDbl(sourceData(sourceRow, OUT_COL_WITHDRAW))
        kindText = "�g�r�s�����"
    End If
    amountValue = unresolvedAmount
    If candidateCountByTx.Exists(transactionID) Then candidateCount = CLng(candidateCountByTx(transactionID))
    If confirmedCountByTx.Exists(transactionID) Then confirmedCount = CLng(confirmedCountByTx(transactionID))
    If bestRatingByTx.Exists(transactionID) Then bestRating = CStr(bestRatingByTx(transactionID))
    contextText = UnknownContextText(unknownContextByTx, transactionID)
    contextScore = UnknownContextScore(unknownContextByTx, transactionID)
    EvaluateUnknownTransaction sourceData, sourceRow, isDeposit, amountValue, candidateCount, _
                               bestRating, contextText, contextScore, score, priorityText, reasonText
    reasonText = AppendAnalysisReason(reasonText, _
                 "�����z " & Format$(originalAmount, "#,##0.########") & _
                 "�A�m��z�� " & Format$(allocatedAmount, "#,##0.########") & _
                 "�A���ǐՎc�z " & Format$(unresolvedAmount, "#,##0.########") & _
                 "�i�m��z��+���ǐՎc�z=�����z�A�z���L�^" & _
                 CStr(allocationCount) & "���j�B")
    reviewKey = transactionID & ">" & kindText
    evidenceDigest = AnalysisEvidenceDigest(sourceData, CStr(sourceRow), _
                     "UNKNOWN|" & settingsSignature & "|C=" & CStr(candidateCount) & _
                     "|K=" & CStr(confirmedCount) & "|A=" & _
                     Format$(allocatedAmount, "0.############") & "|U=" & _
                     Format$(unresolvedAmount, "0.############") & _
                     "|R=" & bestRating & "|" & contextText)
    reviewValues = AnalysisReviewValues(reviews, reviewKey, evidenceDigest)
    If CBool(reviewValues(2)) Then
        reasonText = AppendAnalysisReason(reasonText, _
                     "�O��m�F��ɍ�������܂��͕��͏������ς�������߁A�Ċm�F�֖߂��܂����B")
        reviewValues(1) = AppendAnalysisMemo(CStr(reviewValues(1)), _
                          "[����] ��������܂��͕��͏����̕ύX�����m���A�Ċm�F�֖߂��܂����B")
    End If

    buffer(bufferRow, 1) = priorityText
    buffer(bufferRow, 2) = score
    buffer(bufferRow, 3) = kindText
    buffer(bufferRow, 4) = CDate(sourceData(sourceRow, OUT_COL_DATE))
    buffer(bufferRow, 5) = AnalysisTimeOutputValue(sourceData(sourceRow, OUT_COL_TIME))
    buffer(bufferRow, 6) = AnalysisSingleTimeEvidenceLabel( _
                           sourceData(sourceRow, OUT_COL_TIME))
    buffer(bufferRow, 7) = sourceData(sourceRow, OUT_COL_PERSON)
    buffer(bufferRow, 8) = sourceData(sourceRow, WORK_TX_COL_RELATIONSHIP)
    buffer(bufferRow, 9) = sourceData(sourceRow, OUT_COL_BANK)
    buffer(bufferRow, 10) = sourceData(sourceRow, OUT_COL_BRANCH)
    buffer(bufferRow, 11) = sourceData(sourceRow, OUT_COL_ACCOUNT_TYPE)
    buffer(bufferRow, 12) = sourceData(sourceRow, OUT_COL_ACCOUNT_NO)
    If isDeposit Then buffer(bufferRow, 13) = amountValue Else buffer(bufferRow, 14) = amountValue
    buffer(bufferRow, 15) = sourceData(sourceRow, OUT_COL_SHOP)
    buffer(bufferRow, 16) = sourceData(sourceRow, OUT_COL_MACHINE)
    buffer(bufferRow, 17) = sourceData(sourceRow, OUT_COL_TEKIYO)
    buffer(bufferRow, 18) = CStr(candidateCount) & " / " & CStr(confirmedCount)
    buffer(bufferRow, 19) = bestRating
    buffer(bufferRow, 20) = reasonText
    buffer(bufferRow, 21) = reviewValues(0)
    buffer(bufferRow, 22) = reviewValues(1)
    buffer(bufferRow, 23) = sourceData(sourceRow, WORK_TX_COL_SOURCE)
    buffer(bufferRow, 24) = transactionID
    buffer(bufferRow, 25) = sourceData(sourceRow, WORK_TX_COL_ACCOUNT_ID)
    buffer(bufferRow, 26) = AnalysisStoredKey(reviewKey, evidenceDigest)
End Sub

Private Sub EvaluateUnknownTransaction(ByRef sourceData As Variant, ByVal sourceRow As Long, _
                                       ByVal isDeposit As Boolean, ByVal amountValue As Double, _
                                       ByVal candidateCount As Long, ByVal bestRating As String, _
                                       ByVal contextText As String, ByVal contextScore As Long, _
                                       ByRef score As Long, ByRef priorityText As String, _
                                       ByRef reasonText As String)
    Dim memoText As String, candidateRatingText As String
    Dim transactionDate As Long, inheritanceDate As Long, signedDays As Long
    Dim candidatePriorityCap As Long
    score = 10
    If isDeposit Then
        reasonText = "�����̌��������m�F�ł��B"
    Else
        reasonText = "�o���̎g�r�����m�F�ł��B"
    End If

    If amountValue >= 10000000# Then
        score = score + 35
        reasonText = AppendAnalysisReason(reasonText, "���z��1,000���~�ȏ�ł��B")
    ElseIf amountValue >= 1000000# Then
        score = score + 25
        reasonText = AppendAnalysisReason(reasonText, "���z��100���~�ȏ�ł��B")
    ElseIf amountValue >= 100000# Then
        score = score + 15
        reasonText = AppendAnalysisReason(reasonText, "���z��10���~�ȏ�ł��B")
    Else
        score = score + 5
    End If

    memoText = CellText(sourceData(sourceRow, OUT_COL_TEKIYO))
    If Len(memoText) = 0 Then
        score = score + 20
        reasonText = AppendAnalysisReason(reasonText, _
                     "�E�v���󗓂̂��߁A������e�𔻕ʂł��܂���B")
    Else
        score = score + 5
        reasonText = AppendAnalysisReason(reasonText, _
                     "�E�v�ɋL�ڂ�����܂����A�L�ڂ����ł͊m�F�ς݂Ƃ��Ĉ����܂���B")
    End If
    If IsAnalysisRoundAmount(amountValue, 100000#) Then
        score = score + 10
        reasonText = AppendAnalysisReason(reasonText, "10���~�P�ʂ̋��z�ł��B")
    ElseIf IsAnalysisRoundAmount(amountValue, 10000#) Then
        score = score + 5
        reasonText = AppendAnalysisReason(reasonText, "1���~�P�ʂ̋��z�ł��B")
    End If
    If candidateCount > 0 Then
        candidateRatingText = bestRating
        If Len(candidateRatingText) = 0 Then candidateRatingText = "�]�����ݒ�"
        If bestRating = "��" Or _
           InStr(1, bestRating, "�蓮", vbTextCompare) = 1 Then
            score = score - 10
            candidatePriorityCap = 64
        ElseIf bestRating = "��" Then
            score = score - 5
            candidatePriorityCap = 64
        Else
            candidatePriorityCap = 0
        End If
        reasonText = AppendAnalysisReason(reasonText, _
                     "�����V�t�g�E�t���[��₪�ʕ\��" & CStr(candidateCount) & _
                     "������܂��B�ō��]���́u" & candidateRatingText & "�v�ł��B")
        reasonText = AppendAnalysisReason(reasonText, _
                     "��₪���m�F�̂��ߖ{�\�ɂ��c���Ă��܂����A�d�����č��D��ɂ͂��Ă��܂���B")
    Else
        reasonText = AppendAnalysisReason(reasonText, _
                     "���͍ςݎ���̒��ɂ͑Ή���₪����܂���B�����ڎ�����Ȃ����Ƃ��Ӗ�������̂ł͂���܂���B")
    End If
    If Len(contextText) > 0 Then
        score = score + contextScore
        reasonText = AppendAnalysisReason(reasonText, contextText & "�B")
    End If
    If IsDate(mAnalysisInheritanceDate) Then
        transactionDate = CLng(VBA.DateValue(CDate(sourceData(sourceRow, OUT_COL_DATE))))
        inheritanceDate = CLng(VBA.DateValue(CDate(mAnalysisInheritanceDate)))
        signedDays = transactionDate - inheritanceDate
        If Abs(signedDays) <= 30 Then
            score = score + 15
            reasonText = AppendAnalysisReason(reasonText, "�����J�n���O��30���ȓ��̎���ł��B")
        ElseIf Abs(signedDays) <= 90 Then
            score = score + 8
            reasonText = AppendAnalysisReason(reasonText, "�����J�n���O��90���ȓ��̎���ł��B")
        ElseIf Abs(signedDays) <= 365 Then
            score = score + 3
            reasonText = AppendAnalysisReason(reasonText, "�����J�n���O��365���ȓ��̎���ł��B")
        End If
        If signedDays >= 0 And signedDays <= 365 Then
            score = score + 5
            If isDeposit Then
                reasonText = AppendAnalysisReason(reasonText, _
                             "�����J�n��̓����ł��邽�߁A�������ʂɊm�F���Ă��������B")
            Else
                reasonText = AppendAnalysisReason(reasonText, _
                             "�����J�n��̏o���ł��邽�߁A�g�r���ʂɊm�F���Ă��������B")
            End If
        End If
    End If
    If Not HasText(sourceData(sourceRow, OUT_COL_TIME)) Then _
        reasonText = AppendAnalysisReason(reasonText, _
                     "�����L�ڂȂ��̂��߁A��������Ƃ̑O��֌W�͔���ł��܂���B")
    If candidatePriorityCap > 0 And score > candidatePriorityCap Then score = candidatePriorityCap
    If score < 0 Then score = 0
    If score > 100 Then score = 100
    If score >= 65 Then
        priorityText = "��"
    ElseIf score >= 45 Then
        priorityText = "��"
    Else
        priorityText = "�ʏ�"
    End If
End Sub

Private Function IsAnalysisRoundAmount(ByVal amountValue As Double, ByVal unitValue As Double) As Boolean
    Dim quotient As Double
    If unitValue <= 0 Then Exit Function
    quotient = amountValue / unitValue
    IsAnalysisRoundAmount = (Abs(quotient - Fix(quotient)) < 0.0000001)
End Function

Private Function BuildUnknownContextIndex( _
        ByRef sourceData As Variant, ByRef withdrawalRows() As Long, _
        ByVal withdrawalCount As Long, ByRef depositRows() As Long, _
        ByVal depositCount As Long) As Object
    Dim contextIndex As Object, amountCounts As Object, dayAccountCounts As Object
    Dim operationCounts As Object, cashCounts As Object
    Dim allRows() As Long, allCount As Long, i As Long
    Set contextIndex = CreateObject("Scripting.Dictionary")
    Set amountCounts = CreateObject("Scripting.Dictionary")
    Set dayAccountCounts = CreateObject("Scripting.Dictionary")
    Set operationCounts = CreateObject("Scripting.Dictionary")
    Set cashCounts = CreateObject("Scripting.Dictionary")
    contextIndex.CompareMode = vbTextCompare
    amountCounts.CompareMode = vbTextCompare
    dayAccountCounts.CompareMode = vbTextCompare
    operationCounts.CompareMode = vbTextCompare
    cashCounts.CompareMode = vbTextCompare

    allCount = withdrawalCount + depositCount
    If allCount = 0 Then
        Set BuildUnknownContextIndex = contextIndex
        Exit Function
    End If
    ReDim allRows(1 To allCount)
    For i = 1 To withdrawalCount
        allRows(i) = withdrawalRows(i)
        RegisterUnknownContextCount sourceData, withdrawalRows(i), False, amountCounts, _
                                    dayAccountCounts, operationCounts, cashCounts
    Next i
    For i = 1 To depositCount
        allRows(withdrawalCount + i) = depositRows(i)
        RegisterUnknownContextCount sourceData, depositRows(i), True, amountCounts, _
                                    dayAccountCounts, operationCounts, cashCounts
    Next i
    For i = 1 To allCount
        AddUnknownSimpleContext sourceData, allRows(i), contextIndex, amountCounts, _
                                dayAccountCounts, operationCounts, cashCounts
    Next i
    AddUnknownRollingContext sourceData, allRows, allCount, contextIndex
    Set BuildUnknownContextIndex = contextIndex
End Function

Private Sub RegisterUnknownContextCount( _
        ByRef sourceData As Variant, ByVal sourceRow As Long, ByVal isDeposit As Boolean, _
        ByVal amountCounts As Object, ByVal dayAccountCounts As Object, _
        ByVal operationCounts As Object, ByVal cashCounts As Object)
    Dim operationKey As String, cashKey As String
    IncrementAnalysisCount amountCounts, UnknownAmountContextKey(sourceData, sourceRow, isDeposit)
    IncrementAnalysisCount dayAccountCounts, UnknownDayAccountContextKey(sourceData, sourceRow, isDeposit)
    operationKey = UnknownOperationContextKey(sourceData, sourceRow)
    If Len(operationKey) > 0 Then IncrementAnalysisCount operationCounts, operationKey
    cashKey = UnknownCashContextKey(sourceData, sourceRow)
    If Len(cashKey) > 0 Then IncrementAnalysisCount cashCounts, cashKey
End Sub

Private Sub AddUnknownSimpleContext( _
        ByRef sourceData As Variant, ByVal sourceRow As Long, ByVal contextIndex As Object, _
        ByVal amountCounts As Object, ByVal dayAccountCounts As Object, _
        ByVal operationCounts As Object, ByVal cashCounts As Object)
    Dim transactionID As String, keyText As String, itemCount As Long
    Dim isDeposit As Boolean
    transactionID = CellText(sourceData(sourceRow, WORK_TX_COL_TRANSACTION_ID))
    If Len(transactionID) = 0 Then Exit Sub
    isDeposit = HasText(sourceData(sourceRow, OUT_COL_DEPOSIT))

    keyText = UnknownAmountContextKey(sourceData, sourceRow, isDeposit)
    itemCount = CLng(amountCounts(keyText))
    If itemCount >= 2 Then _
        AddUnknownContextTag contextIndex, transactionID, _
            "���͔͈͓��œ��z�E����̎��" & CStr(itemCount) & "��", 4

    keyText = UnknownDayAccountContextKey(sourceData, sourceRow, isDeposit)
    itemCount = CLng(dayAccountCounts(keyText))
    If itemCount >= 2 Then _
        AddUnknownContextTag contextIndex, transactionID, _
            "�����E�������̓�����" & CStr(itemCount) & "��", 4

    keyText = UnknownOperationContextKey(sourceData, sourceRow)
    If Len(keyText) > 0 Then
        itemCount = CLng(operationCounts(keyText))
        If itemCount >= 2 Then _
            AddUnknownContextTag contextIndex, transactionID, _
                "�����E����s�E���戵�X/�@�Ԃ̎��" & CStr(itemCount) & "��", 6
    End If

    keyText = UnknownCashContextKey(sourceData, sourceRow)
    If Len(keyText) > 0 Then
        itemCount = CLng(cashCounts(keyText))
        If itemCount >= 2 Then _
            AddUnknownContextTag contextIndex, transactionID, _
                "�����E���l���E����s�̑����^���" & CStr(itemCount) & "��", 6
    End If
End Sub

Private Sub AddUnknownRollingContext(ByRef sourceData As Variant, ByRef allRows() As Long, _
                                     ByVal allCount As Long, ByVal contextIndex As Object)
    Dim accountKeys() As String, dates() As Long, rows() As Long
    Dim groupStart As Long, groupEnd As Long, groupCount As Long
    Dim groupDates() As Long, depositAmounts() As Double, withdrawalAmounts() As Double
    Dim depositCounts() As Long, withdrawalCounts() As Long
    Dim i As Long, p As Long, sourceRow As Long, currentDate As Long
    Dim lower30 As Long, lower90 As Long, lower365 As Long
    Dim futureStart As Long, upper30 As Long, upper90 As Long, upper365 As Long
    Dim sameCount As Long, oppositeCount As Long, sameAmount As Double, oppositeAmount As Double
    Dim transactionID As String, oppositeLabel As String, isDeposit As Boolean
    ReDim accountKeys(1 To allCount)
    ReDim dates(1 To allCount)
    ReDim rows(1 To allCount)
    For i = 1 To allCount
        rows(i) = allRows(i)
        accountKeys(i) = UCase$(CellText(sourceData(allRows(i), WORK_TX_COL_ACCOUNT_ID)))
        dates(i) = CLng(VBA.DateValue(CDate(sourceData(allRows(i), OUT_COL_DATE))))
    Next i
    If allCount > 1 Then QuickSortUnknownContextRows accountKeys, dates, rows, 1, allCount

    groupStart = 1
    Do While groupStart <= allCount
        groupEnd = groupStart
        Do While groupEnd < allCount
            If StrComp(accountKeys(groupEnd + 1), accountKeys(groupStart), vbTextCompare) <> 0 Then Exit Do
            groupEnd = groupEnd + 1
        Loop
        groupCount = groupEnd - groupStart + 1
        ReDim groupDates(1 To groupCount)
        ReDim depositAmounts(0 To groupCount)
        ReDim withdrawalAmounts(0 To groupCount)
        ReDim depositCounts(0 To groupCount)
        ReDim withdrawalCounts(0 To groupCount)
        For p = 1 To groupCount
            sourceRow = rows(groupStart + p - 1)
            groupDates(p) = dates(groupStart + p - 1)
            depositAmounts(p) = depositAmounts(p - 1)
            withdrawalAmounts(p) = withdrawalAmounts(p - 1)
            depositCounts(p) = depositCounts(p - 1)
            withdrawalCounts(p) = withdrawalCounts(p - 1)
            If HasText(sourceData(sourceRow, OUT_COL_DEPOSIT)) Then
                depositAmounts(p) = depositAmounts(p) + CDbl(sourceData(sourceRow, OUT_COL_DEPOSIT))
                depositCounts(p) = depositCounts(p) + 1
            Else
                withdrawalAmounts(p) = withdrawalAmounts(p) + CDbl(sourceData(sourceRow, OUT_COL_WITHDRAW))
                withdrawalCounts(p) = withdrawalCounts(p) + 1
            End If
        Next p

        For p = 1 To groupCount
            sourceRow = rows(groupStart + p - 1)
            transactionID = CellText(sourceData(sourceRow, WORK_TX_COL_TRANSACTION_ID))
            currentDate = groupDates(p)
            isDeposit = HasText(sourceData(sourceRow, OUT_COL_DEPOSIT))
            lower30 = LowerBoundUnknownContextDate(groupDates, groupCount, currentDate - 29)
            lower90 = LowerBoundUnknownContextDate(groupDates, groupCount, currentDate - 89)
            lower365 = LowerBoundUnknownContextDate(groupDates, groupCount, currentDate - 364)
            If isDeposit Then
                sameCount = depositCounts(p) - depositCounts(lower30 - 1)
                sameAmount = depositAmounts(p) - depositAmounts(lower30 - 1)
            Else
                sameCount = withdrawalCounts(p) - withdrawalCounts(lower30 - 1)
                sameAmount = withdrawalAmounts(p) - withdrawalAmounts(lower30 - 1)
            End If
            If sameCount >= 2 Then
                AddUnknownContextTag contextIndex, transactionID, _
                    "����30���E�������̓�����" & CStr(sameCount) & "���v" & _
                    Format$(sameAmount, "#,##0.########") & "�~", 6
            Else
                If isDeposit Then
                    sameCount = depositCounts(p) - depositCounts(lower90 - 1)
                    sameAmount = depositAmounts(p) - depositAmounts(lower90 - 1)
                Else
                    sameCount = withdrawalCounts(p) - withdrawalCounts(lower90 - 1)
                    sameAmount = withdrawalAmounts(p) - withdrawalAmounts(lower90 - 1)
                End If
                If sameCount >= 3 Then
                    AddUnknownContextTag contextIndex, transactionID, _
                        "����90���E�������̓�����" & CStr(sameCount) & "���v" & _
                        Format$(sameAmount, "#,##0.########") & "�~", 5
                Else
                    If isDeposit Then
                        sameCount = depositCounts(p) - depositCounts(lower365 - 1)
                        sameAmount = depositAmounts(p) - depositAmounts(lower365 - 1)
                    Else
                        sameCount = withdrawalCounts(p) - withdrawalCounts(lower365 - 1)
                        sameAmount = withdrawalAmounts(p) - withdrawalAmounts(lower365 - 1)
                    End If
                    If sameCount >= 4 Then _
                        AddUnknownContextTag contextIndex, transactionID, _
                            "����365���E�������̓�����" & CStr(sameCount) & "���v" & _
                            Format$(sameAmount, "#,##0.########") & "�~", 4
                End If
            End If

            '�����������s���Ȏ���𖳗��ɕ��ׂ��A�����ȍ~�������㑱�Ƃ��ďW�v����B
            futureStart = UpperBoundUnknownContextDate(groupDates, groupCount, currentDate) + 1
            If futureStart <= groupCount Then
                upper30 = UpperBoundUnknownContextDate(groupDates, groupCount, currentDate + 30)
                upper90 = UpperBoundUnknownContextDate(groupDates, groupCount, currentDate + 90)
                upper365 = UpperBoundUnknownContextDate(groupDates, groupCount, currentDate + 365)
                If upper30 < futureStart Then upper30 = futureStart - 1
                If upper90 < futureStart Then upper90 = futureStart - 1
                If upper365 < futureStart Then upper365 = futureStart - 1
                If isDeposit Then
                    oppositeLabel = "�o��"
                    oppositeCount = withdrawalCounts(upper30) - withdrawalCounts(futureStart - 1)
                    oppositeAmount = withdrawalAmounts(upper30) - withdrawalAmounts(futureStart - 1)
                Else
                    oppositeLabel = "����"
                    oppositeCount = depositCounts(upper30) - depositCounts(futureStart - 1)
                    oppositeAmount = depositAmounts(upper30) - depositAmounts(futureStart - 1)
                End If
                If oppositeCount > 0 Then
                    AddUnknownContextTag contextIndex, transactionID, _
                        "�������̗����ȍ~30���ȓ���" & oppositeLabel & CStr(oppositeCount) & _
                        "���v" & Format$(oppositeAmount, "#,##0.########") & "�~", 6
                Else
                    If isDeposit Then
                        oppositeCount = withdrawalCounts(upper90) - withdrawalCounts(futureStart - 1)
                        oppositeAmount = withdrawalAmounts(upper90) - withdrawalAmounts(futureStart - 1)
                    Else
                        oppositeCount = depositCounts(upper90) - depositCounts(futureStart - 1)
                        oppositeAmount = depositAmounts(upper90) - depositAmounts(futureStart - 1)
                    End If
                    If oppositeCount > 0 Then
                        AddUnknownContextTag contextIndex, transactionID, _
                            "�������̗����ȍ~90���ȓ���" & oppositeLabel & CStr(oppositeCount) & _
                            "���v" & Format$(oppositeAmount, "#,##0.########") & "�~", 4
                    Else
                        If isDeposit Then
                            oppositeCount = withdrawalCounts(upper365) - withdrawalCounts(futureStart - 1)
                            oppositeAmount = withdrawalAmounts(upper365) - withdrawalAmounts(futureStart - 1)
                        Else
                            oppositeCount = depositCounts(upper365) - depositCounts(futureStart - 1)
                            oppositeAmount = depositAmounts(upper365) - depositAmounts(futureStart - 1)
                        End If
                        If oppositeCount > 0 Then _
                            AddUnknownContextTag contextIndex, transactionID, _
                                "�������̗����ȍ~365���ȓ���" & oppositeLabel & CStr(oppositeCount) & _
                                "���v" & Format$(oppositeAmount, "#,##0.########") & "�~", 3
                    End If
                End If
            End If
        Next p
        groupStart = groupEnd + 1
    Loop
End Sub

Private Function UnknownAmountContextKey(ByRef sourceData As Variant, ByVal sourceRow As Long, _
                                         ByVal isDeposit As Boolean) As String
    Dim amountValue As Double, sideText As String
    If isDeposit Then
        amountValue = CDbl(sourceData(sourceRow, OUT_COL_DEPOSIT))
        sideText = "D"
    Else
        amountValue = CDbl(sourceData(sourceRow, OUT_COL_WITHDRAW))
        sideText = "W"
    End If
    UnknownAmountContextKey = sideText & "|" & Trim$(Str$(amountValue))
End Function

Private Function UnknownDayAccountContextKey(ByRef sourceData As Variant, ByVal sourceRow As Long, _
                                             ByVal isDeposit As Boolean) As String
    UnknownDayAccountContextKey = IIf(isDeposit, "D|", "W|") & _
        UCase$(CellText(sourceData(sourceRow, WORK_TX_COL_ACCOUNT_ID))) & "|" & _
        CStr(CLng(VBA.DateValue(CDate(sourceData(sourceRow, OUT_COL_DATE)))))
End Function

Private Function UnknownOperationContextKey(ByRef sourceData As Variant, _
                                            ByVal sourceRow As Long) As String
    Dim shopText As String, machineText As String
    shopText = UCase$(CellText(sourceData(sourceRow, OUT_COL_SHOP)))
    machineText = UCase$(CellText(sourceData(sourceRow, OUT_COL_MACHINE)))
    If Len(shopText) = 0 And Len(machineText) = 0 Then Exit Function
    UnknownOperationContextKey = UCase$(CellText(sourceData(sourceRow, OUT_COL_BANK))) & "|" & _
        CStr(CLng(VBA.DateValue(CDate(sourceData(sourceRow, OUT_COL_DATE))))) & "|" & _
        shopText & "|" & machineText
End Function

Private Function UnknownCashContextKey(ByRef sourceData As Variant, ByVal sourceRow As Long) As String
    Dim personKey As String
    If HasText(sourceData(sourceRow, OUT_COL_TEKIYO)) Or _
       HasText(sourceData(sourceRow, OUT_COL_SHOP)) Or _
       HasText(sourceData(sourceRow, OUT_COL_MACHINE)) Then Exit Function
    personKey = CellText(sourceData(sourceRow, WORK_TX_COL_PERSON_ID))
    If Len(personKey) = 0 Then _
        Err.Raise vbObjectError + 4638, "UnknownCashContextKey", _
                  "W_��� " & CStr(sourceRow + 1) & _
                  "�s�ڂɐl��ID������܂���B�����ł͑�ւ��܂���B"
    If Not IsInternalIdValue(personKey, "P") Then _
        Err.Raise vbObjectError + 4639, "UnknownCashContextKey", _
                  "W_��� " & CStr(sourceRow + 1) & _
                  "�s�ڂ̐l��ID�`�����s���ł�: " & personKey
    UnknownCashContextKey = UCase$(CellText(sourceData(sourceRow, OUT_COL_BANK))) & "|" & _
        UCase$(personKey) & "|" & _
        CStr(CLng(VBA.DateValue(CDate(sourceData(sourceRow, OUT_COL_DATE)))))
End Function

Private Sub IncrementAnalysisCount(ByVal values As Object, ByVal keyText As String)
    If values.Exists(keyText) Then
        values(keyText) = CLng(values(keyText)) + 1
    Else
        values.Add keyText, 1
    End If
End Sub

Private Sub AddUnknownContextTag(ByVal contextIndex As Object, ByVal transactionID As String, _
                                 ByVal tagText As String, ByVal scoreIncrement As Long)
    Dim textKey As String, scoreKey As String, currentText As String, proposedText As String
    textKey = "T|" & transactionID
    scoreKey = "S|" & transactionID
    If contextIndex.Exists(textKey) Then currentText = CStr(contextIndex(textKey))
    If InStr(1, currentText, tagText, vbTextCompare) > 0 Then Exit Sub
    If Len(currentText) = 0 Then proposedText = tagText Else proposedText = currentText & "�A" & tagText
    '�\���ł��Ȃ����������ŗD��x���オ��Ɛ����s�\�ɂȂ邽�߁A
    '���R���̏���𒴂���^�O�̓X�R�A�ɂ����f���Ȃ��B
    If Len(proposedText) > ANALYSIS_CONTEXT_TEXT_MAX Then Exit Sub
    If contextIndex.Exists(textKey) Then
        contextIndex(textKey) = proposedText
    Else
        contextIndex.Add textKey, proposedText
    End If
    If contextIndex.Exists(scoreKey) Then
        contextIndex(scoreKey) = CLng(contextIndex(scoreKey)) + scoreIncrement
    Else
        contextIndex.Add scoreKey, scoreIncrement
    End If
    If CLng(contextIndex(scoreKey)) > 25 Then contextIndex(scoreKey) = 25
End Sub

Private Function UnknownContextText(ByVal contextIndex As Object, ByVal transactionID As String) As String
    If Not contextIndex Is Nothing Then
        If contextIndex.Exists("T|" & transactionID) Then _
            UnknownContextText = CStr(contextIndex("T|" & transactionID))
    End If
End Function

Private Function UnknownContextScore(ByVal contextIndex As Object, ByVal transactionID As String) As Long
    If Not contextIndex Is Nothing Then
        If contextIndex.Exists("S|" & transactionID) Then _
            UnknownContextScore = CLng(contextIndex("S|" & transactionID))
    End If
End Function

Private Function LowerBoundUnknownContextDate(ByRef dates() As Long, ByVal itemCount As Long, _
                                              ByVal targetDate As Long) As Long
    Dim low As Long, high As Long, mid As Long
    low = 1: high = itemCount + 1
    Do While low < high
        mid = low + (high - low) \ 2
        If mid <= itemCount And dates(mid) < targetDate Then low = mid + 1 Else high = mid
    Loop
    LowerBoundUnknownContextDate = low
End Function

Private Function UpperBoundUnknownContextDate(ByRef dates() As Long, ByVal itemCount As Long, _
                                              ByVal targetDate As Long) As Long
    Dim low As Long, high As Long, mid As Long
    low = 1: high = itemCount + 1
    Do While low < high
        mid = low + (high - low) \ 2
        If mid <= itemCount And dates(mid) <= targetDate Then low = mid + 1 Else high = mid
    Loop
    UpperBoundUnknownContextDate = low - 1
End Function

Private Sub QuickSortUnknownContextRows(ByRef accountKeys() As String, ByRef dates() As Long, _
                                        ByRef rows() As Long, ByVal firstIndex As Long, _
                                        ByVal lastIndex As Long)
    Dim low As Long, high As Long, pivotIndex As Long
    Dim pivotKey As String, pivotDate As Long, pivotRow As Long
    Dim tempKey As String, tempDate As Long, tempRow As Long
    low = firstIndex: high = lastIndex
    pivotIndex = (firstIndex + lastIndex) \ 2
    pivotKey = accountKeys(pivotIndex): pivotDate = dates(pivotIndex): pivotRow = rows(pivotIndex)
    Do While low <= high
        Do While CompareUnknownContextRows(accountKeys(low), dates(low), rows(low), _
                                           pivotKey, pivotDate, pivotRow) < 0
            low = low + 1
        Loop
        Do While CompareUnknownContextRows(accountKeys(high), dates(high), rows(high), _
                                           pivotKey, pivotDate, pivotRow) > 0
            high = high - 1
        Loop
        If low <= high Then
            tempKey = accountKeys(low): accountKeys(low) = accountKeys(high): accountKeys(high) = tempKey
            tempDate = dates(low): dates(low) = dates(high): dates(high) = tempDate
            tempRow = rows(low): rows(low) = rows(high): rows(high) = tempRow
            low = low + 1: high = high - 1
        End If
    Loop
    If firstIndex < high Then QuickSortUnknownContextRows accountKeys, dates, rows, firstIndex, high
    If low < lastIndex Then QuickSortUnknownContextRows accountKeys, dates, rows, low, lastIndex
End Sub

Private Function CompareUnknownContextRows(ByVal firstKey As String, ByVal firstDate As Long, _
                                           ByVal firstRow As Long, ByVal secondKey As String, _
                                           ByVal secondDate As Long, ByVal secondRow As Long) As Long
    CompareUnknownContextRows = StrComp(firstKey, secondKey, vbTextCompare)
    If CompareUnknownContextRows <> 0 Then Exit Function
    If firstDate < secondDate Then
        CompareUnknownContextRows = -1
    ElseIf firstDate > secondDate Then
        CompareUnknownContextRows = 1
    ElseIf firstRow < secondRow Then
        CompareUnknownContextRows = -1
    ElseIf firstRow > secondRow Then
        CompareUnknownContextRows = 1
    End If
End Function

Public Function AnalysisSettingsSignature(ByVal minAmount As Double, ByVal dayWindow As Long, _
                                          ByVal absoluteTolerance As Double, _
                                          ByVal rateTolerance As Double) As String
    AnalysisSettingsSignature = "MIN=" & Trim$(Str$(minAmount)) & "|DAY=" & CStr(dayWindow) & _
                                "|ABS=" & Trim$(Str$(absoluteTolerance)) & _
                                "|RATE=" & Trim$(Str$(rateTolerance))
    If IsDate(mAnalysisInheritanceDate) Then _
        AnalysisSettingsSignature = AnalysisSettingsSignature & "|INH=" & _
                                    Format$(CDate(mAnalysisInheritanceDate), "yyyymmdd")
End Function

Public Function AnalysisEvidenceDigest(ByRef sourceData As Variant, ByVal rowList As String, _
                                       ByVal contextText As String) As String
    Dim rowParts As Variant, rowTexts() As String, item As Variant
    Dim itemCount As Long, i As Long, j As Long, tempText As String, rawText As String
    If Len(rowList) > 0 Then
        rowParts = Split(rowList, ";")
        ReDim rowTexts(1 To UBound(rowParts) - LBound(rowParts) + 1)
        For Each item In rowParts
            If Len(Trim$(CStr(item))) > 0 Then
                itemCount = itemCount + 1
                rowTexts(itemCount) = AnalysisRowEvidenceDigest(sourceData, CLng(item))
            End If
        Next item
    End If
    For i = 2 To itemCount
        tempText = rowTexts(i)
        j = i - 1
        Do While j >= 1
            If StrComp(rowTexts(j), tempText, vbBinaryCompare) <= 0 Then Exit Do
            rowTexts(j + 1) = rowTexts(j)
            j = j - 1
        Loop
        rowTexts(j + 1) = tempText
    Next i
    rawText = CStr(Len(contextText)) & ":" & contextText
    For i = 1 To itemCount
        rawText = rawText & "|" & CStr(Len(rowTexts(i))) & ":" & rowTexts(i)
    Next i
    AnalysisEvidenceDigest = AnalysisHashPart(rawText, 104729#, 131#) & "-" & _
                             AnalysisHashPart(rawText, 130363#, 137#)
End Function

Private Function AnalysisRowEvidenceDigest(ByRef sourceData As Variant, _
                                           ByVal sourceRow As Long) As String
    Dim transactionID As String, rowText As String
    transactionID = CellText(sourceData(sourceRow, WORK_TX_COL_TRANSACTION_ID))
    If mAnalysisRowEvidenceCache Is Nothing Then
        Set mAnalysisRowEvidenceCache = CreateObject("Scripting.Dictionary")
        mAnalysisRowEvidenceCache.CompareMode = vbTextCompare
    End If
    If Len(transactionID) > 0 Then
        If mAnalysisRowEvidenceCache.Exists(transactionID) Then
            AnalysisRowEvidenceDigest = CStr(mAnalysisRowEvidenceCache(transactionID))
            Exit Function
        End If
    End If
    rowText = AnalysisRowEvidenceText(sourceData, sourceRow)
    AnalysisRowEvidenceDigest = AnalysisHashPart(rowText, 15485863#, 139#) & "-" & _
                                AnalysisHashPart(rowText, 32452843#, 149#)
    If Len(transactionID) > 0 Then _
        mAnalysisRowEvidenceCache.Add transactionID, AnalysisRowEvidenceDigest
End Function

Private Sub ResetAnalysisEvidenceCache()
    Set mAnalysisRowEvidenceCache = Nothing
End Sub

Private Function AnalysisRowEvidenceText(ByRef sourceData As Variant, ByVal sourceRow As Long) As String
    Dim c As Long, valueText As String, resultText As String
    For c = 1 To UBound(sourceData, 2)
        valueText = AnalysisEvidenceValue(sourceData(sourceRow, c))
        resultText = resultText & CStr(Len(valueText)) & ":" & valueText & "|"
    Next c
    AnalysisRowEvidenceText = resultText
End Function

Private Function AnalysisEvidenceValue(ByVal valueIn As Variant) As String
    If IsError(valueIn) Then
        AnalysisEvidenceValue = "#ERROR"
    ElseIf IsEmpty(valueIn) Or IsNull(valueIn) Then
        AnalysisEvidenceValue = vbNullString
    ElseIf VarType(valueIn) = vbBoolean Then
        If CBool(valueIn) Then AnalysisEvidenceValue = "TRUE" Else AnalysisEvidenceValue = "FALSE"
    ElseIf IsNumeric(valueIn) Then
        AnalysisEvidenceValue = Trim$(Str$(CDbl(valueIn)))
    Else
        AnalysisEvidenceValue = CStr(valueIn)
    End If
End Function

Private Function AnalysisHashPart(ByVal rawText As String, ByVal seedValue As Double, _
                                  ByVal multiplier As Double) As String
    Const HASH_MODULUS As Double = 2147483629#
    Dim hashValue As Double, i As Long, codeValue As Long, hexText As String
    hashValue = seedValue
    For i = 1 To Len(rawText)
        codeValue = AscW(Mid$(rawText, i, 1))
        If codeValue < 0 Then codeValue = codeValue + 65536
        hashValue = hashValue * multiplier + CDbl(codeValue)
        hashValue = hashValue - Fix(hashValue / HASH_MODULUS) * HASH_MODULUS
    Next i
    hexText = Hex$(CLng(hashValue))
    AnalysisHashPart = Right$("00000000" & hexText, 8)
End Function

Public Function AnalysisStoredKey(ByVal baseKey As String, ByVal evidenceDigest As String) As String
    AnalysisStoredKey = baseKey & ANALYSIS_EVIDENCE_MARKER & evidenceDigest
End Function

Public Function AnalysisBaseKey(ByVal storedKey As String, ByRef evidenceDigest As String) As String
    Dim markerPosition As Long
    markerPosition = InStrRev(storedKey, ANALYSIS_EVIDENCE_MARKER, -1, vbBinaryCompare)
    If markerPosition > 0 Then
        AnalysisBaseKey = Left$(storedKey, markerPosition - 1)
        evidenceDigest = Mid$(storedKey, markerPosition + Len(ANALYSIS_EVIDENCE_MARKER))
    Else
        AnalysisBaseKey = storedKey
        evidenceDigest = vbNullString
    End If
End Function

Public Function AnalysisMaximumCandidateCount(ByVal candidateCountByTx As Object, _
                                              ByVal transactionIDs As String) As Long
    Dim items As Variant, item As Variant, transactionID As String, itemCount As Long
    If candidateCountByTx Is Nothing Or Len(transactionIDs) = 0 Then Exit Function
    items = Split(transactionIDs, ";")
    For Each item In items
        transactionID = Trim$(CStr(item))
        If candidateCountByTx.Exists(transactionID) Then
            itemCount = CLng(candidateCountByTx(transactionID))
            If itemCount > AnalysisMaximumCandidateCount Then _
                AnalysisMaximumCandidateCount = itemCount
        End If
    Next item
End Function

Public Function AppendAnalysisReason(ByVal currentText As String, ByVal additionalText As String) As String
    If Len(additionalText) = 0 Or InStr(1, currentText, additionalText, vbTextCompare) > 0 Then
        AppendAnalysisReason = currentText
    ElseIf Len(currentText) = 0 Then
        AppendAnalysisReason = additionalText
    Else
        AppendAnalysisReason = Trim$(currentText) & " " & additionalText
    End If
End Function

Public Function AppendAnalysisMemo(ByVal currentText As String, ByVal additionalText As String) As String
    Dim separatorText As String, availableChars As Long
    If Len(additionalText) = 0 Or InStr(1, currentText, additionalText, vbTextCompare) > 0 Then
        AppendAnalysisMemo = currentText
        Exit Function
    End If
    If Len(currentText) > 0 Then separatorText = vbLf
    availableChars = ANALYSIS_REVIEW_MEMO_MAX - Len(currentText) - Len(separatorText)
    If availableChars <= 0 Then
        AppendAnalysisMemo = currentText
    Else
        AppendAnalysisMemo = currentText & separatorText & Left$(additionalText, availableChars)
    End If
End Function

'���s�̑S�����scope�s�Ƃ��ē���batch�֊܂߁A�m�F�ς݂̎����E�蓮����
'�����Allocation�֕ϊ�����B���Ԃ̉ߏ�z���͋��ʌ�����atomic���؂ֈς˂�B
Public Sub RebuildCurrentAnalysisAllocationPlan()
    Dim wsSource As Worksheet, sourceData As Variant
    Dim lastR As Long, sourceRowCount As Long
    If Not SheetExists(SH_WORK_TX) Or Not SheetExists(SH_ANALYSIS_SHIFT) Or _
       Not SheetExists(SH_ANALYSIS_FLOW) Then _
        Err.Raise vbObjectError + 4691, "RebuildCurrentAnalysisAllocationPlan", _
                  "�z���v��̍č\�z�ɕK�v�Ȋ����\������܂���B"
    Set wsSource = GetSheet(SH_WORK_TX)
    lastR = LastDataRowInColumns(wsSource, 1, WORK_TX_COL_PERSON_ID)
    If lastR < 2 Then
        ClearAnalysisAllocationPlan
        Exit Sub
    End If
    sourceData = wsSource.Range(wsSource.Cells(2, 1), _
                                wsSource.Cells(lastR, WORK_TX_COL_PERSON_ID)).Value2
    sourceRowCount = UBound(sourceData, 1)
    CommitCurrentAnalysisAllocations sourceData, sourceRowCount, _
        GetSheet(SH_ANALYSIS_SHIFT), GetSheet(SH_ANALYSIS_FLOW)
End Sub

Private Sub CommitCurrentAnalysisAllocations( _
        ByRef sourceData As Variant, ByVal sourceRowCount As Long, _
        ByVal wsShift As Worksheet, ByVal wsFlow As Worksheet)
    Dim allocationRows As New Collection
    Dim transactionIndex As Object, manualIndex As Object
    Dim batchRows() As Variant, rowValues As Variant
    Dim r As Long, c As Long, sourceAmount As Double
    Dim transactionID As String, directionText As String
    If sourceRowCount <= 0 Then
        '�S����폜��̍ĕ��͂ł����z�����c���Ȃ��B��W���ւ�full replacement�B
        ClearAnalysisAllocationPlan
        Exit Sub
    End If
    Set transactionIndex = BuildAnalysisAllocationTransactionIndex(sourceData, sourceRowCount)
    Set manualIndex = CaptureManualFlowAllocationIndex()

    'scope�s�ɂ��A�ΏۊO�֖߂���������������̋�active�z�������ݎ���P�ʂŒu������B
    For r = 1 To sourceRowCount
        transactionID = CellText(sourceData(r, WORK_TX_COL_TRANSACTION_ID))
        If CDbl(sourceData(r, OUT_COL_WITHDRAW)) > 0# Then
            sourceAmount = CDbl(sourceData(r, OUT_COL_WITHDRAW))
            directionText = ALLOCATION_DIRECTION_WITHDRAW
        ElseIf CDbl(sourceData(r, OUT_COL_DEPOSIT)) > 0# Then
            sourceAmount = CDbl(sourceData(r, OUT_COL_DEPOSIT))
            directionText = ALLOCATION_DIRECTION_DEPOSIT
        Else
            GoTo NextScopeRow
        End If
        AddAnalysisAllocationRow allocationRows, _
            "__SCOPE__", transactionID, directionText, 0#, _
            ALLOCATION_STATUS_UNREVIEWED, vbNullString, _
            ALLOCATION_SOURCE_SCOPE, sourceAmount
NextScopeRow:
    Next r

    CollectShiftAllocationRows wsShift, sourceData, transactionIndex, allocationRows
    CollectFlowAllocationRows wsFlow, sourceData, transactionIndex, manualIndex, allocationRows
    If allocationRows.Count = 0 Then
        '����s�������Ă��z���Ώە�����0���Ȃ�A��W���ւ�full replacement�Ƃ���B
        ClearAnalysisAllocationPlan
        Exit Sub
    End If
    ReDim batchRows(1 To allocationRows.Count, 1 To 8)
    For r = 1 To allocationRows.Count
        rowValues = allocationRows(r)
        For c = 1 To 8
            batchRows(r, c) = rowValues(c - 1)
        Next c
    Next r
    ReplaceAllocationPlanForTransactions batchRows, "ANALYSIS", _
                                         replaceEntireLedger:=True
    ValidateCurrentAnalysisAllocationCoverage sourceData, sourceRowCount
End Sub

Private Function BuildAnalysisAllocationTransactionIndex( _
        ByRef sourceData As Variant, ByVal sourceRowCount As Long) As Object
    Dim result As Object, r As Long, transactionID As String
    Set result = CreateObject("Scripting.Dictionary")
    result.CompareMode = vbTextCompare
    For r = 1 To sourceRowCount
        transactionID = CellText(sourceData(r, WORK_TX_COL_TRANSACTION_ID))
        If Len(transactionID) = 0 Or result.Exists(transactionID) Then _
            Err.Raise vbObjectError + 4691, "BuildAnalysisAllocationTransactionIndex", _
                      "�z���Ώۂ̎��ID���󗓂܂��͏d�����Ă��܂�: " & transactionID
        result.Add transactionID, r
    Next r
    Set BuildAnalysisAllocationTransactionIndex = result
End Function

Private Sub CollectShiftAllocationRows( _
        ByVal ws As Worksheet, ByRef sourceData As Variant, _
        ByVal transactionIndex As Object, ByVal allocationRows As Collection)
    Dim lastR As Long, data As Variant, r As Long
    Dim storedKey As String, baseKey As String, evidenceDigest As String
    Dim withdrawalID As String, depositID As String
    Dim withdrawalRow As Long, depositRow As Long
    Dim withdrawalAmount As Double, depositAmount As Double, trackingAmount As Double
    If ws Is Nothing Then Exit Sub
    lastR = LastUsedRowInSheet(ws)
    If lastR < 2 Then Exit Sub
    data = ws.Range(ws.Cells(2, 1), ws.Cells(lastR, SHIFT_ANALYSIS_LAST_COL)).Value2
    For r = 1 To UBound(data, 1)
        If StrComp(CellText(data(r, SHIFT_ANALYSIS_STATUS_COL)), _
                   ANALYSIS_STATUS_SHIFT_CONFIRMED, vbTextCompare) = 0 Then
            storedKey = CellText(data(r, SHIFT_ANALYSIS_KEY_COL))
            baseKey = AnalysisBaseKey(storedKey, evidenceDigest)
            withdrawalID = CellText(data(r, 33))
            depositID = CellText(data(r, 34))
            If Len(baseKey) = 0 Or Len(evidenceDigest) = 0 Or _
               Not transactionIndex.Exists(withdrawalID) Or _
               Not transactionIndex.Exists(depositID) Then _
                Err.Raise vbObjectError + 4692, "CollectShiftAllocationRows", _
                          "�m�F�ς�1��1���̍����܂��͎��ID���s���ł��B"
            withdrawalRow = CLng(transactionIndex(withdrawalID))
            depositRow = CLng(transactionIndex(depositID))
            withdrawalAmount = CDbl(sourceData(withdrawalRow, OUT_COL_WITHDRAW))
            depositAmount = CDbl(sourceData(depositRow, OUT_COL_DEPOSIT))
            If withdrawalAmount < depositAmount Then
                trackingAmount = withdrawalAmount
            Else
                trackingAmount = depositAmount
            End If
            AddAnalysisAllocationRow allocationRows, "SHIFT>" & baseKey, withdrawalID, _
                ALLOCATION_DIRECTION_WITHDRAW, trackingAmount, ALLOCATION_STATUS_CONFIRMED, _
                evidenceDigest, "SHIFT", withdrawalAmount
            AddAnalysisAllocationRow allocationRows, "SHIFT>" & baseKey, depositID, _
                ALLOCATION_DIRECTION_DEPOSIT, trackingAmount, ALLOCATION_STATUS_CONFIRMED, _
                evidenceDigest, "SHIFT", depositAmount
        End If
    Next r
End Sub

Private Sub CollectFlowAllocationRows( _
        ByVal ws As Worksheet, ByRef sourceData As Variant, _
        ByVal transactionIndex As Object, ByVal manualIndex As Object, _
        ByVal allocationRows As Collection)
    Dim lastR As Long, data As Variant, r As Long
    Dim storedKey As String, baseKey As String, evidenceDigest As String
    Dim transactionIDs As String, parts As Variant, item As Variant
    Dim transactionID As String, sourceType As String
    Dim statusText As String, memoText As String
    Dim seen As Object, withdrawalIDs As Collection, depositIDs As Collection
    Dim sourceRow As Long, withdrawalTotal As Double, depositTotal As Double
    Dim trackingAmount As Double, manualEntry As Variant
    Dim candidateRequiresReview As Boolean
    If ws Is Nothing Then Exit Sub
    lastR = LastUsedRowInSheet(ws)
    If lastR < 2 Then Exit Sub
    data = ws.Range(ws.Cells(2, 1), ws.Cells(lastR, FLOW_ANALYSIS_LAST_COL)).Value2
    For r = 1 To UBound(data, 1)
        statusText = CellText(data(r, FLOW_ANALYSIS_STATUS_COL))
        memoText = CellText(data(r, FLOW_ANALYSIS_MEMO_COL))
        If FlowAllocationReviewNeedsLedger(statusText, memoText) Then
            storedKey = CellText(data(r, FLOW_ANALYSIS_KEY_COL))
            baseKey = AnalysisBaseKey(storedKey, evidenceDigest)
            transactionIDs = CellText(data(r, 20))
            If Len(baseKey) = 0 Or Len(evidenceDigest) = 0 Or Len(transactionIDs) = 0 Then _
                Err.Raise vbObjectError + 4693, "CollectFlowAllocationRows", _
                          "�m�F�ςݎ����t���[���̍������s���ł��B"
            Set seen = CreateObject("Scripting.Dictionary")
            seen.CompareMode = vbTextCompare
            Set withdrawalIDs = New Collection
            Set depositIDs = New Collection
            withdrawalTotal = 0#: depositTotal = 0#
            parts = Split(transactionIDs, ";")
            For Each item In parts
                transactionID = Trim$(CStr(item))
                If Len(transactionID) = 0 Or seen.Exists(transactionID) Or _
                   Not transactionIndex.Exists(transactionID) Then _
                    Err.Raise vbObjectError + 4694, "CollectFlowAllocationRows", _
                              "�����t���[���̍\�����ID���󗓁E�d���E�s���݂ł�: " & _
                              transactionID
                seen.Add transactionID, True
                sourceRow = CLng(transactionIndex(transactionID))
                If CDbl(sourceData(sourceRow, OUT_COL_WITHDRAW)) > 0# Then
                    withdrawalIDs.Add transactionID
                    withdrawalTotal = withdrawalTotal + _
                                      CDbl(sourceData(sourceRow, OUT_COL_WITHDRAW))
                ElseIf CDbl(sourceData(sourceRow, OUT_COL_DEPOSIT)) > 0# Then
                    depositIDs.Add transactionID
                    depositTotal = depositTotal + CDbl(sourceData(sourceRow, OUT_COL_DEPOSIT))
                Else
                    Err.Raise vbObjectError + 4695, "CollectFlowAllocationRows", _
                              "�\������ɔz���\�ȏo���܂��͓���������܂���: " & transactionID
                End If
            Next item
            If withdrawalIDs.Count = 0 Or depositIDs.Count = 0 Then _
                Err.Raise vbObjectError + 4696, "CollectFlowAllocationRows", _
                          "�����t���[���͏o���E�����̗�����K�v�Ƃ��܂��B"
            If Left$(baseKey, 7) = "MANUAL>" Then
                If manualIndex Is Nothing Then _
                    Err.Raise vbObjectError + 4697, "CollectFlowAllocationRows", _
                              "�蓮���̒ǐՎw��z����������܂���: " & baseKey
                If Not manualIndex.Exists(baseKey) Then _
                    Err.Raise vbObjectError + 4697, "CollectFlowAllocationRows", _
                              "�蓮���̒ǐՎw��z��������܂���: " & baseKey
                manualEntry = manualIndex(baseKey)
                trackingAmount = CDbl(manualEntry(0))
                sourceType = "MANUAL_FLOW"
            Else
                If withdrawalTotal < depositTotal Then
                    trackingAmount = withdrawalTotal
                Else
                    trackingAmount = depositTotal
                End If
                sourceType = "AUTO_FLOW"
            End If
            If trackingAmount <= 0# Or _
               trackingAmount > Application.Min(withdrawalTotal, depositTotal) + _
                                AnalysisAllocationTolerance(trackingAmount) Then _
                Err.Raise vbObjectError + 4698, "CollectFlowAllocationRows", _
                          "�����t���[���̒ǐՊz���\��������v�𒴂��Ă��܂�: " & baseKey
            'n:n�͌ʏo�����ʓ����̑Ή�����ӂłȂ��A�Б������̊m���
            '�m��z�����v����Ώ̂ɂ���Bn:n���͂ǂ��炩�̕������ō��z�A����
            '��ӂłȂ���Ό��S�̂�fail-closed�ɂ��A���������Ċm�F�֑���B
            candidateRequiresReview = FlowAllocationCandidateRequiresReview( _
                statusText, withdrawalIDs.Count, depositIDs.Count, _
                withdrawalTotal, depositTotal, trackingAmount)
            If candidateRequiresReview Then
                '���p�҂������ړ��m�F��I��ł����z�A���͐����m�肵�Ȃ��B
                '���\�����{�����Ɠ����v�Ċm�F��Ԃ֖߂��A�ق����s��v���c���Ȃ��B
                ws.Cells(r + 1, FLOW_ANALYSIS_STATUS_COL).Value = _
                    ANALYSIS_STATUS_FOLLOWUP
                ws.Cells(r + 1, FLOW_ANALYSIS_MEMO_COL).Value = _
                    AppendAnalysisMemo( _
                        CellText(ws.Cells(r + 1, FLOW_ANALYSIS_MEMO_COL).Value2), _
                        ALLOCATION_AMBIGUITY_MEMO_MARKER & _
                        "���q�σf�[�^�����Ŋm��ł��Ȃ����߁A" & _
                        "�ʔz����0�~�E�����ʎc���𖞊z�Ƃ��ėv�ǉ������֖߂��܂����B")
            End If
            AddCandidateSideAllocationRows allocationRows, "FLOW>" & baseKey, _
                sourceData, transactionIndex, withdrawalIDs, False, withdrawalTotal, _
                trackingAmount, evidenceDigest, sourceType, candidateRequiresReview
            AddCandidateSideAllocationRows allocationRows, "FLOW>" & baseKey, _
                sourceData, transactionIndex, depositIDs, True, depositTotal, _
                trackingAmount, evidenceDigest, sourceType, candidateRequiresReview
        End If
    Next r
End Sub

Private Function FlowAllocationReviewNeedsLedger( _
        ByVal statusText As String, ByVal memoText As String) As Boolean
    If StrComp(statusText, ANALYSIS_STATUS_SHIFT_CONFIRMED, vbTextCompare) = 0 Then
        FlowAllocationReviewNeedsLedger = True
    ElseIf StrComp(statusText, ANALYSIS_STATUS_FOLLOWUP, vbTextCompare) = 0 Then
        FlowAllocationReviewNeedsLedger = _
            (InStr(1, memoText, ALLOCATION_AMBIGUITY_MEMO_MARKER, _
                   vbTextCompare) > 0)
    End If
End Function

Private Function FlowAllocationCandidateRequiresReview( _
        ByVal statusText As String, ByVal withdrawalCount As Long, _
        ByVal depositCount As Long, ByVal withdrawalTotal As Double, _
        ByVal depositTotal As Double, ByVal trackingAmount As Double) As Boolean
    FlowAllocationCandidateRequiresReview = _
        (StrComp(statusText, ANALYSIS_STATUS_FOLLOWUP, vbTextCompare) = 0) Or _
        (withdrawalCount > 1 And depositCount > 1) Or _
        (withdrawalCount > 1 And _
         Not AnalysisAllocationAmountsMatch(withdrawalTotal, trackingAmount)) Or _
        (depositCount > 1 And _
         Not AnalysisAllocationAmountsMatch(depositTotal, trackingAmount))
End Function

Private Sub AddCandidateSideAllocationRows( _
        ByVal allocationRows As Collection, ByVal candidateKey As String, _
        ByRef sourceData As Variant, ByVal transactionIndex As Object, _
        ByVal transactionIDs As Collection, ByVal isDeposit As Boolean, _
        ByVal sideTotal As Double, ByVal trackingAmount As Double, _
        ByVal evidenceDigest As String, ByVal sourceType As String, _
        ByVal forceReviewRequired As Boolean)
    Dim item As Variant, transactionID As String, sourceRow As Long
    Dim sourceAmount As Double, directionText As String, componentIDs As String
    Dim isUnambiguous As Boolean
    If isDeposit Then
        directionText = ALLOCATION_DIRECTION_DEPOSIT
    Else
        directionText = ALLOCATION_DIRECTION_WITHDRAW
    End If
    isUnambiguous = Not forceReviewRequired And _
                    (transactionIDs.Count = 1 Or _
                     AnalysisAllocationAmountsMatch(sideTotal, trackingAmount))
    For Each item In transactionIDs
        transactionID = CStr(item)
        sourceRow = CLng(transactionIndex(transactionID))
        If isDeposit Then
            sourceAmount = CDbl(sourceData(sourceRow, OUT_COL_DEPOSIT))
        Else
            sourceAmount = CDbl(sourceData(sourceRow, OUT_COL_WITHDRAW))
        End If
        If isUnambiguous Then
            If transactionIDs.Count = 1 Then
                AddAnalysisAllocationRow allocationRows, candidateKey, transactionID, _
                    directionText, Application.Min(sourceAmount, trackingAmount), _
                    ALLOCATION_STATUS_CONFIRMED, evidenceDigest, sourceType, sourceAmount
            Else
                AddAnalysisAllocationRow allocationRows, candidateKey, transactionID, _
                    directionText, sourceAmount, ALLOCATION_STATUS_CONFIRMED, _
                    evidenceDigest, sourceType, sourceAmount
            End If
        Else
            '��������̂ǂ�ɍ��z���c�邩�͋q�σf�[�^�����ł͌��߂��Ȃ��B
            '�����������e�����0�~�v�Ċm�F�Ƃ��A����ResidualLot���c���B
            AddAnalysisAllocationRow allocationRows, candidateKey, transactionID, _
                directionText, 0#, ALLOCATION_STATUS_REVIEW_REQUIRED, _
                evidenceDigest, sourceType, sourceAmount
        End If
        If Len(componentIDs) > 0 Then componentIDs = componentIDs & ";"
        componentIDs = componentIDs & transactionID
    Next item
    'ResidualLot�͍��z�A�����B���ȕ�������������ɍ��B���S�̂�
    'fail-closed�ɂ������ʂ̒P�������́A���0�~�ʍs�����z�c����ێ�����B
    If Not isUnambiguous And transactionIDs.Count > 1 Then
        AddAnalysisAllocationRow allocationRows, candidateKey, _
            componentIDs, directionText, sideTotal, _
            ALLOCATION_STATUS_REVIEW_REQUIRED, evidenceDigest, _
            ALLOCATION_SOURCE_RESIDUAL_LOT, sideTotal
    End If
End Sub

Private Sub AddAnalysisAllocationRow( _
        ByVal allocationRows As Collection, ByVal candidateKey As String, _
        ByVal transactionID As String, ByVal directionText As String, _
        ByVal allocatedAmount As Double, ByVal statusText As String, _
        ByVal evidenceDigest As String, ByVal sourceType As String, _
        ByVal sourceAmount As Double)
    allocationRows.Add Array(candidateKey, transactionID, directionText, allocatedAmount, _
                             statusText, evidenceDigest, sourceType, sourceAmount)
End Sub

Private Function AnalysisAllocationTolerance(ByVal amountValue As Double) As Double
    '�z�����{�̌������؂Ɠ��ꋖ�e���ɌŒ肷��B���T���p�̋��z���e�Ƃ͕ʕ��B
    AnalysisAllocationTolerance = _
        Application.Max(0.00000001, Abs(amountValue) * 0.0000000000005)
End Function

Private Function AnalysisAllocationAmountsMatch( _
        ByVal leftAmount As Double, ByVal rightAmount As Double) As Boolean
    AnalysisAllocationAmountsMatch = _
        (Abs(leftAmount - rightAmount) <= _
         Application.Max(AnalysisAllocationTolerance(leftAmount), _
                         AnalysisAllocationTolerance(rightAmount)))
End Function

Private Sub ValidateCurrentAnalysisAllocationCoverage( _
        ByRef sourceData As Variant, ByVal sourceRowCount As Long)
    Dim allocationIndex As Object, r As Long, transactionID As String
    Dim directionText As String, sourceAmount As Double
    Dim allocatedAmount As Double, unresolvedAmount As Double, allocationCount As Long
    Set allocationIndex = CaptureAllocationLedgerIndex()
    For r = 1 To sourceRowCount
        transactionID = CellText(sourceData(r, WORK_TX_COL_TRANSACTION_ID))
        If CDbl(sourceData(r, OUT_COL_WITHDRAW)) > 0# Then
            directionText = ALLOCATION_DIRECTION_WITHDRAW
            sourceAmount = CDbl(sourceData(r, OUT_COL_WITHDRAW))
        ElseIf CDbl(sourceData(r, OUT_COL_DEPOSIT)) > 0# Then
            directionText = ALLOCATION_DIRECTION_DEPOSIT
            sourceAmount = CDbl(sourceData(r, OUT_COL_DEPOSIT))
        Else
            GoTo NextCoverageRow
        End If
        If Not GetTransactionUnresolvedAmountFromIndex( _
                allocationIndex, transactionID, directionText, sourceAmount, _
                allocatedAmount, unresolvedAmount, allocationCount) Then _
            Err.Raise vbObjectError + 4699, "ValidateCurrentAnalysisAllocationCoverage", _
                      "�z�������̓ǖ߂��Ɏ��s���܂���: " & transactionID
        If Not AnalysisAllocationAmountsMatch( _
                allocatedAmount + unresolvedAmount, sourceAmount) Then _
            Err.Raise vbObjectError + 4699, "ValidateCurrentAnalysisAllocationCoverage", _
                      "�m��z��+���ǐՎc�z�������z�ƈ�v���܂���: " & transactionID
NextCoverageRow:
    Next r
End Sub

Public Sub ResolveAnalysisReviewConflicts(ByVal wsShift As Worksheet, ByVal wsFlow As Worksheet)
    Dim problems As String
    '��������𕡐���₪�������p���邱�Ǝ��̂͋����ł͂Ȃ��B
    '�����ł͂Ȃ��A���ʔz�������̋��z�s�Ϗ���������ۑ��O�Ɍ��؂���B
    If Not ValidateAllocationLedgerForSave(problems) Then _
        Err.Raise vbObjectError + 4630, "ResolveAnalysisReviewConflicts", _
                  "�z���������s���Ȃ��ߊm�F�󋵂�ۑ��ł��܂���B" & vbCrLf & problems
End Sub

Private Sub RequireNoConfirmedAnalysisReviewConflict(ByVal countByTx As Object)
    Dim transactionID As String
    transactionID = FirstConfirmedAnalysisReviewConflictTransactionID(countByTx)
    If Len(transactionID) = 0 Then Exit Sub
    Err.Raise vbObjectError + 4630, "ResolveAnalysisReviewConflicts", _
              "���ID�u" & transactionID & _
              "�v�������̌��Łu�����ړ��m�F�v�ɂȂ��Ă��܂��B" & vbCrLf & _
              "�����̊m�F�󋵁E���藝�R�E�m�F�����͕ύX���Ă��܂���B" & vbCrLf & _
              "����������̈���𖢊m�F�܂��͑ΏۊO�֕ύX���Ă���A������x�ۑ����Ă��������B"
End Sub

Private Function FirstConfirmedAnalysisReviewConflictTransactionID( _
        ByVal countByTx As Object) As String
    Dim item As Variant, transactionID As String, firstID As String
    If countByTx Is Nothing Then Exit Function
    For Each item In countByTx.Keys
        If CLng(countByTx(item)) > 1 Then
            transactionID = Trim$(CStr(item))
            If Len(transactionID) > 0 Then
                If Len(firstID) = 0 Or _
                   StrComp(transactionID, firstID, vbTextCompare) < 0 Then _
                    firstID = transactionID
            End If
        End If
    Next item
    FirstConfirmedAnalysisReviewConflictTransactionID = firstID
End Function

Public Function BuildConfirmedCandidateCountByTransaction(ByVal wsShift As Worksheet, _
                                                          ByVal wsFlow As Worksheet) As Object
    Dim candidateRows As Object, countByTx As Object
    Set candidateRows = CreateObject("Scripting.Dictionary")
    Set countByTx = CreateObject("Scripting.Dictionary")
    candidateRows.CompareMode = vbTextCompare
    countByTx.CompareMode = vbTextCompare
    CollectConfirmedAnalysisUsage wsShift, wsFlow, candidateRows, countByTx
    Set BuildConfirmedCandidateCountByTransaction = countByTx
End Function

Private Sub CollectConfirmedAnalysisUsage(ByVal wsShift As Worksheet, ByVal wsFlow As Worksheet, _
                                          ByVal candidateRows As Object, ByVal countByTx As Object)
    Dim membership As Object
    Set membership = CreateObject("Scripting.Dictionary")
    membership.CompareMode = vbTextCompare
    CollectConfirmedUsageFromSheet wsShift, 1, SHIFT_ANALYSIS_STATUS_COL, SHIFT_ANALYSIS_KEY_COL, _
                                   33, 34, candidateRows, countByTx, membership
    CollectConfirmedUsageFromSheet wsFlow, 2, FLOW_ANALYSIS_STATUS_COL, FLOW_ANALYSIS_KEY_COL, _
                                   20, 0, candidateRows, countByTx, membership
End Sub

Private Sub CollectConfirmedUsageFromSheet( _
        ByVal ws As Worksheet, ByVal sheetCode As Long, ByVal statusColumn As Long, _
        ByVal keyColumn As Long, ByVal transactionColumn As Long, ByVal secondTransactionColumn As Long, _
        ByVal candidateRows As Object, ByVal countByTx As Object, ByVal membership As Object)
    Dim lastR As Long, dataRows As Long, r As Long
    Dim statusValues As Variant, keyValues As Variant, transactionValues As Variant
    Dim secondTransactionValues As Variant
    Dim storedKey As String, baseKey As String, digestText As String, transactionIDs As String
    Dim candidateID As String
    If ws Is Nothing Then Exit Sub
    lastR = LastUsedRowInSheet(ws)
    If lastR < 2 Then Exit Sub
    dataRows = lastR - 1
    statusValues = ws.Range(ws.Cells(2, statusColumn), ws.Cells(lastR, statusColumn)).Value2
    keyValues = ws.Range(ws.Cells(2, keyColumn), ws.Cells(lastR, keyColumn)).Value2
    transactionValues = ws.Range(ws.Cells(2, transactionColumn), _
                                 ws.Cells(lastR, transactionColumn)).Value2
    If secondTransactionColumn > 0 Then _
        secondTransactionValues = ws.Range(ws.Cells(2, secondTransactionColumn), _
                                           ws.Cells(lastR, secondTransactionColumn)).Value2
    For r = 1 To dataRows
        If StrComp(CellText(AnalysisColumnValue(statusValues, r, dataRows)), _
                   ANALYSIS_STATUS_SHIFT_CONFIRMED, vbTextCompare) = 0 Then
            storedKey = CellText(AnalysisColumnValue(keyValues, r, dataRows))
            baseKey = AnalysisBaseKey(storedKey, digestText)
            If secondTransactionColumn > 0 Then
                transactionIDs = CellText(AnalysisColumnValue(transactionValues, r, dataRows)) & ";" & _
                                 CellText(AnalysisColumnValue(secondTransactionValues, r, dataRows))
            Else
                transactionIDs = CellText(AnalysisColumnValue(transactionValues, r, dataRows))
            End If
            candidateID = CStr(sheetCode) & "|" & baseKey
            RegisterConfirmedAnalysisCandidate candidateRows, countByTx, membership, candidateID, _
                                               sheetCode, r + 1, transactionIDs
        End If
    Next r
End Sub

Private Sub RegisterConfirmedAnalysisCandidate( _
        ByVal candidateRows As Object, ByVal countByTx As Object, ByVal membership As Object, _
        ByVal candidateID As String, ByVal sheetCode As Long, ByVal rowNumber As Long, _
        ByVal transactionIDs As String)
    Dim items As Variant, item As Variant, transactionID As String, membershipKey As String
    If Len(candidateID) = 0 Or candidateRows.Exists(candidateID) Then Exit Sub
    candidateRows.Add candidateID, Array(sheetCode, rowNumber, transactionIDs)
    items = Split(transactionIDs, ";")
    For Each item In items
        transactionID = Trim$(CStr(item))
        If Len(transactionID) > 0 Then
            membershipKey = transactionID & ChrW(30) & candidateID
            If Not membership.Exists(membershipKey) Then
                membership.Add membershipKey, True
                IncrementAnalysisCount countByTx, transactionID
            End If
        End If
    Next item
End Sub

Private Sub CheckAnalysisReviewConflicts(ByVal wsShift As Worksheet, ByVal wsFlow As Worksheet, _
                                         ByRef problems As String)
    Dim ledgerProblems As String
    If Not ValidateAllocationLedgerForSave(ledgerProblems) Then _
        problems = problems & "�E���͔z������: " & ledgerProblems & vbCrLf
End Sub

Private Sub PrepareShiftAnalysisSheet(ByVal ws As Worksheet)
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim cleanupErrorNumber As Long
    Dim cleanupErrorDescription As String, cleanupErrorSource As String
    Dim convergenceDetail As String
    If ws Is Nothing Then Exit Sub
    On Error GoTo EH
    ws.Unprotect Password:=TOOL_PASSWORD
    If ws.AutoFilterMode Then ws.AutoFilterMode = False
    ResetWorksheet ws
    SetRowValues ws.Range("A1"), ShiftAnalysisHeaders()
    FormatOutputHeader ws.Range(ws.Cells(1, 1), ws.Cells(1, SHIFT_ANALYSIS_LAST_COL))
    ws.Columns("A:AH").NumberFormatLocal = "@"
    ws.Columns("B:B").NumberFormatLocal = "0"
    ws.Columns("H:H").NumberFormatLocal = "#,##0.########"
    ws.Columns("I:I").NumberFormatLocal = "yyyy/m/d"
    ws.Columns("J:J").NumberFormatLocal = "hh:mm"
    ws.Columns("Q:Q").NumberFormatLocal = "#,##0.########"
    ws.Columns("S:S").NumberFormatLocal = "yyyy/m/d"
    ws.Columns("T:T").NumberFormatLocal = "hh:mm"
    ws.Columns("AA:AA").NumberFormatLocal = "#,##0.########"
    ApplyShiftColumnWidths ws
    ws.Columns("AF:AH").Hidden = True
    ProtectSingleAnalysisSheet ws
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    If IsTransactionAnalysisRecoveryFatal(errorNumber, errorSource) Then
        Call TryStopTransactionAnalysisEventsForBookWrites(convergenceDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    On Error Resume Next
    Err.Clear
    EmergencyProtectToolSheet ws
    cleanupErrorNumber = Err.Number
    cleanupErrorSource = Err.Source
    cleanupErrorDescription = Err.Description
    Err.Clear
    On Error GoTo 0
    If IsTransactionAnalysisRecoveryFatal( _
           cleanupErrorNumber, cleanupErrorSource) Then
        Call TryStopTransactionAnalysisEventsForBookWrites(convergenceDetail)
        Err.Raise cleanupErrorNumber, cleanupErrorSource, _
                  cleanupErrorDescription
    End If
    Err.Raise errorNumber, "PrepareShiftAnalysisSheet", errorSource & " / " & errorDescription
End Sub

Private Sub PrepareUnknownAnalysisSheet(ByVal ws As Worksheet)
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim cleanupErrorNumber As Long
    Dim cleanupErrorDescription As String, cleanupErrorSource As String
    Dim convergenceDetail As String
    If ws Is Nothing Then Exit Sub
    On Error GoTo EH
    ws.Unprotect Password:=TOOL_PASSWORD
    If ws.AutoFilterMode Then ws.AutoFilterMode = False
    ResetWorksheet ws
    SetRowValues ws.Range("A1"), UnknownAnalysisHeaders()
    FormatOutputHeader ws.Range(ws.Cells(1, 1), ws.Cells(1, UNKNOWN_ANALYSIS_LAST_COL))
    ws.Columns("A:Z").NumberFormatLocal = "@"
    ws.Columns("B:B").NumberFormatLocal = "0"
    ws.Columns("D:D").NumberFormatLocal = "yyyy/m/d"
    ws.Columns("E:E").NumberFormatLocal = "hh:mm"
    ws.Columns("M:N").NumberFormatLocal = "#,##0.########"
    ws.Columns("R:R").NumberFormatLocal = "0"
    ApplyUnknownColumnWidths ws
    ws.Columns("X:Z").Hidden = True
    ProtectSingleAnalysisSheet ws
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    If IsTransactionAnalysisRecoveryFatal(errorNumber, errorSource) Then
        Call TryStopTransactionAnalysisEventsForBookWrites(convergenceDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    On Error Resume Next
    Err.Clear
    EmergencyProtectToolSheet ws
    cleanupErrorNumber = Err.Number
    cleanupErrorSource = Err.Source
    cleanupErrorDescription = Err.Description
    Err.Clear
    On Error GoTo 0
    If IsTransactionAnalysisRecoveryFatal( _
           cleanupErrorNumber, cleanupErrorSource) Then
        Call TryStopTransactionAnalysisEventsForBookWrites(convergenceDetail)
        Err.Raise cleanupErrorNumber, cleanupErrorSource, _
                  cleanupErrorDescription
    End If
    Err.Raise errorNumber, "PrepareUnknownAnalysisSheet", errorSource & " / " & errorDescription
End Sub

Private Sub FinalizeShiftAnalysisSheet(ByVal ws As Worksheet, ByVal dataCount As Long)
    Dim lastR As Long
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim cleanupErrorNumber As Long
    Dim cleanupErrorDescription As String, cleanupErrorSource As String
    Dim convergenceDetail As String
    If ws Is Nothing Then Exit Sub
    On Error GoTo EH
    ws.Unprotect Password:=TOOL_PASSWORD
    lastR = dataCount + 1
    FormatOutputHeader ws.Range(ws.Cells(1, 1), ws.Cells(1, SHIFT_ANALYSIS_LAST_COL))
    If dataCount > 1 Then SortShiftAnalysis ws, lastR
    ApplyShiftColumnWidths ws
    ws.Columns("AF:AH").Hidden = True
    If dataCount > 0 Then
        With ws.Range(ws.Cells(2, 1), ws.Cells(lastR, SHIFT_ANALYSIS_LAST_COL))
            .VerticalAlignment = xlTop
            .WrapText = False
        End With
        If dataCount <= 10000 Then
            With ws.Range(ws.Cells(2, 1), ws.Cells(lastR, SHIFT_ANALYSIS_LAST_COL)).Borders
                .Color = RGB(226, 232, 240)
                .LineStyle = xlContinuous
            End With
        End If
        ws.Range(ws.Cells(2, 29), ws.Cells(lastR, 31)).WrapText = True
        ws.Range(ws.Cells(2, SHIFT_ANALYSIS_STATUS_COL), _
                 ws.Cells(lastR, SHIFT_ANALYSIS_MEMO_COL)).Interior.Color = RGB(254, 249, 195)
        ws.Rows("2:" & CStr(lastR)).RowHeight = 32
    End If
    If ws.AutoFilterMode Then ws.AutoFilterMode = False
    ws.Range(ws.Cells(1, 1), ws.Cells(lastR, SHIFT_ANALYSIS_LAST_COL)).AutoFilter
    ApplyAnalysisReviewValidation ws, SHIFT_ANALYSIS_STATUS_COL, SHIFT_ANALYSIS_MEMO_COL, lastR
    SafeFreezeOutputHeader ws
    ProtectSingleAnalysisSheet ws
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    If IsTransactionAnalysisRecoveryFatal(errorNumber, errorSource) Then
        Call TryStopTransactionAnalysisEventsForBookWrites(convergenceDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    On Error Resume Next
    Err.Clear
    EmergencyProtectToolSheet ws
    cleanupErrorNumber = Err.Number
    cleanupErrorSource = Err.Source
    cleanupErrorDescription = Err.Description
    Err.Clear
    On Error GoTo 0
    If IsTransactionAnalysisRecoveryFatal( _
           cleanupErrorNumber, cleanupErrorSource) Then
        Call TryStopTransactionAnalysisEventsForBookWrites(convergenceDetail)
        Err.Raise cleanupErrorNumber, cleanupErrorSource, _
                  cleanupErrorDescription
    End If
    Err.Raise errorNumber, "FinalizeShiftAnalysisSheet", errorSource & " / " & errorDescription
End Sub

Private Sub FinalizeUnknownAnalysisSheet(ByVal ws As Worksheet, ByVal dataCount As Long)
    Dim lastR As Long
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim cleanupErrorNumber As Long
    Dim cleanupErrorDescription As String, cleanupErrorSource As String
    Dim convergenceDetail As String
    If ws Is Nothing Then Exit Sub
    On Error GoTo EH
    ws.Unprotect Password:=TOOL_PASSWORD
    lastR = dataCount + 1
    FormatOutputHeader ws.Range(ws.Cells(1, 1), ws.Cells(1, UNKNOWN_ANALYSIS_LAST_COL))
    If dataCount > 1 Then SortUnknownAnalysis ws, lastR
    ApplyUnknownColumnWidths ws
    ws.Columns("X:Z").Hidden = True
    If dataCount > 0 Then
        With ws.Range(ws.Cells(2, 1), ws.Cells(lastR, UNKNOWN_ANALYSIS_LAST_COL))
            .VerticalAlignment = xlTop
            .WrapText = False
        End With
        If dataCount <= 10000 Then
            With ws.Range(ws.Cells(2, 1), ws.Cells(lastR, UNKNOWN_ANALYSIS_LAST_COL)).Borders
                .Color = RGB(226, 232, 240)
                .LineStyle = xlContinuous
            End With
        End If
        ws.Range(ws.Cells(2, 20), ws.Cells(lastR, 22)).WrapText = True
        ws.Range(ws.Cells(2, UNKNOWN_ANALYSIS_STATUS_COL), _
                 ws.Cells(lastR, UNKNOWN_ANALYSIS_MEMO_COL)).Interior.Color = RGB(254, 249, 195)
        ws.Rows("2:" & CStr(lastR)).RowHeight = 32
    End If
    If ws.AutoFilterMode Then ws.AutoFilterMode = False
    ws.Range(ws.Cells(1, 1), ws.Cells(lastR, UNKNOWN_ANALYSIS_LAST_COL)).AutoFilter
    ApplyAnalysisReviewValidation ws, UNKNOWN_ANALYSIS_STATUS_COL, UNKNOWN_ANALYSIS_MEMO_COL, lastR
    SafeFreezeOutputHeader ws
    ProtectSingleAnalysisSheet ws
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    If IsTransactionAnalysisRecoveryFatal(errorNumber, errorSource) Then
        Call TryStopTransactionAnalysisEventsForBookWrites(convergenceDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    On Error Resume Next
    Err.Clear
    EmergencyProtectToolSheet ws
    cleanupErrorNumber = Err.Number
    cleanupErrorSource = Err.Source
    cleanupErrorDescription = Err.Description
    Err.Clear
    On Error GoTo 0
    If IsTransactionAnalysisRecoveryFatal( _
           cleanupErrorNumber, cleanupErrorSource) Then
        Call TryStopTransactionAnalysisEventsForBookWrites(convergenceDetail)
        Err.Raise cleanupErrorNumber, cleanupErrorSource, _
                  cleanupErrorDescription
    End If
    Err.Raise errorNumber, "FinalizeUnknownAnalysisSheet", errorSource & " / " & errorDescription
End Sub

Private Sub ApplyShiftColumnWidths(ByVal ws As Worksheet)
    ws.Columns("A:A").ColumnWidth = 8
    ws.Columns("B:B").ColumnWidth = 8
    ws.Columns("C:G").ColumnWidth = 16
    ws.Columns("H:H").ColumnWidth = 14
    ws.Columns("I:J").ColumnWidth = 13
    ws.Columns("K:P").ColumnWidth = 16
    ws.Columns("Q:Q").ColumnWidth = 15
    ws.Columns("R:R").ColumnWidth = 24
    ws.Columns("S:T").ColumnWidth = 13
    ws.Columns("U:Z").ColumnWidth = 16
    ws.Columns("AA:AA").ColumnWidth = 15
    ws.Columns("AB:AB").ColumnWidth = 24
    ws.Columns("AC:AC").ColumnWidth = 48
    ws.Columns("AD:AD").ColumnWidth = 16
    ws.Columns("AE:AE").ColumnWidth = 36
End Sub

Private Sub ApplyUnknownColumnWidths(ByVal ws As Worksheet)
    ws.Columns("A:C").ColumnWidth = 14
    ws.Columns("D:E").ColumnWidth = 13
    ws.Columns("F:F").ColumnWidth = 16
    ws.Columns("G:L").ColumnWidth = 16
    ws.Columns("M:N").ColumnWidth = 15
    ws.Columns("O:Q").ColumnWidth = 20
    ws.Columns("R:S").ColumnWidth = 14
    ws.Columns("T:T").ColumnWidth = 52
    ws.Columns("U:U").ColumnWidth = 16
    ws.Columns("V:V").ColumnWidth = 36
    ws.Columns("W:W").ColumnWidth = 14
End Sub

Public Sub ApplyAnalysisReviewValidation(ByVal ws As Worksheet, ByVal statusColumn As Long, _
                                          ByVal memoColumn As Long, ByVal lastR As Long)
    Dim statusRange As Range
    If ws Is Nothing Then Exit Sub
    ws.Cells.Locked = True
    If lastR >= 2 Then
        Set statusRange = ws.Range(ws.Cells(2, statusColumn), ws.Cells(lastR, statusColumn))
        statusRange.Locked = False
        ws.Range(ws.Cells(2, memoColumn), ws.Cells(lastR, memoColumn)).Locked = False
        If StrComp(ws.Name, SH_ANALYSIS_UNKNOWN, vbTextCompare) = 0 Then
            ApplyUnknownAnalysisStatusValidation statusRange
        Else
            ApplyValidationList statusRange, NM_LST_ANALYSIS_SHIFT_STATUS, xlIMEModeOff, False
        End If
        ApplyAnalysisMemoValidation ws.Range(ws.Cells(2, memoColumn), ws.Cells(lastR, memoColumn))
    End If
End Sub

Private Sub ApplyUnknownAnalysisStatusValidation(ByVal target As Range)
    If target Is Nothing Then Exit Sub
    With target.Validation
        .Delete
        .Add Type:=xlValidateList, AlertStyle:=xlValidAlertStop, Operator:=xlBetween, _
             Formula1:=AnalysisReviewValidationFormula(SH_ANALYSIS_UNKNOWN)
        .IgnoreBlank = True
        .InCellDropdown = True
        .ShowError = True
        .ErrorTitle = "�m�F�󋵂�I�����Ă�������"
        .ErrorMessage = "�����s�����Ǝg�r�s�����ɑΉ�����m�F�󋵂�I�����Ă��������B"
    End With
    On Error Resume Next
    target.Validation.IMEMode = xlIMEModeOff
    On Error GoTo 0
End Sub

Private Function AnalysisReviewValidationFormula(ByVal sheetName As String) As String
    If StrComp(sheetName, SH_ANALYSIS_UNKNOWN, vbTextCompare) = 0 Then
        AnalysisReviewValidationFormula = "=INDIRECT(IF($C2=""�����s�����"",""" & _
            NM_LST_ANALYSIS_SOURCE_STATUS & """,""" & NM_LST_ANALYSIS_USE_STATUS & """))"
    Else
        AnalysisReviewValidationFormula = "=" & NM_LST_ANALYSIS_SHIFT_STATUS
    End If
End Function

Private Sub ApplyAnalysisMemoValidation(ByVal target As Range)
    If target Is Nothing Then Exit Sub
    With target.Validation
        .Delete
        .Add Type:=xlValidateTextLength, AlertStyle:=xlValidAlertStop, _
             Operator:=xlLessEqual, Formula1:=CStr(ANALYSIS_REVIEW_MEMO_MAX)
        .IgnoreBlank = True
        .ShowError = True
        .ErrorTitle = "�m�F�����̕��������m�F���Ă�������"
        .ErrorMessage = "�m�F������" & CStr(ANALYSIS_REVIEW_MEMO_MAX) & "�����ȓ��œ��͂��Ă��������B"
    End With
    'IME������Ȃ�Excel�ł��������������̂��̂͗L���ɂ���B
    On Error Resume Next
    target.Validation.IMEMode = xlIMEModeHiragana
    On Error GoTo 0
End Sub

Public Sub ProtectSingleAnalysisSheet(ByVal ws As Worksheet)
    Dim workbookWasSaved As Boolean, emergencyProtected As Boolean
    Dim previousEvents As Boolean, eventsCaptured As Boolean
    Dim recoveryEnforcementFailed As Boolean
    Dim recoveryConfirmedThisAttempt As Boolean
    Dim eventsStoppedAfterRecovery As Boolean
    Dim recoveryAttempted As Boolean
    Dim safeToRestoreEntry As Boolean
    Dim restoreErrorNumber As Long, restoreErrorSource As String
    Dim restoreErrorDescription As String
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim emergencyDetail As String, recoveryDetail As String, sheetName As String
    Dim eventStateDetail As String, eventRestoreDetail As String
    If ws Is Nothing Then Exit Sub
    sheetName = ws.Name
    If Not TryGetTransactionAnalysisEnableEvents( _
               previousEvents, eventStateDetail) Then
        On Error Resume Next
        MsgBox "���̓V�[�g�̕ی�O��Excel�C�x���g�̊J�n��Ԃ��擾�ł��܂���ł����B" & _
               vbCrLf & "�ی�ERecovery�E��ԕ\���͍s�킸�A�Č��̈��S��Ԃ͕s���ł��B" & _
               vbCrLf & "���݂̃u�b�N���㏑�����Ȃ��ł��������B", _
               vbCritical, "Excel�C�x���g��Ԃ��m�F�ł��܂���"
        On Error GoTo 0
        Err.Raise vbObjectError + 4703, _
                  "ProtectSingleAnalysisSheet(" & sheetName & ")", _
                  "Excel�C�x���g�̊J�n��Ԃ��擾�ł��܂���ł����B " & _
                  eventStateDetail
    End If
    eventsCaptured = True
    If Not TryStopTransactionAnalysisEventsForBookWrites(eventStateDetail) Then
        errorDescription = _
            "���̓V�[�g�̕ی�O��Excel�C�x���g���~���ēǖ߂��m�F�ł��܂���ł����B " & _
            eventStateDetail
        On Error Resume Next
        MsgBox errorDescription & vbCrLf & _
               "���̓V�[�g�̕ی�͍s�킸�A�J�n���C�x���g��Ԃւ̕������������݂܂��B" & _
               vbCrLf & "�Č��̈��S��Ԃ͊m�肵�Ă��܂���B" & _
               vbCrLf & "���݂̃u�b�N���㏑�����Ȃ��ł��������B", _
               vbCritical, "���̓V�[�g�����S�ɕی�ł��܂���"
        On Error GoTo 0
        If Not TryRestoreTransactionAnalysisEnableEvents( _
                   previousEvents, _
                   "ProtectSingleAnalysisSheet/�ی�J�n�O", _
                   eventRestoreDetail) Then _
            AppendTransactionRollbackDetail errorDescription, _
                "Excel�C�x���g��Ԃ̕����G���[: " & eventRestoreDetail
        eventsCaptured = False
        Err.Raise vbObjectError + 4704, _
                  "ProtectSingleAnalysisSheet(" & sheetName & ")", _
                  errorDescription
    End If
    On Error GoTo EH
    workbookWasSaved = ThisWorkbook.Saved
    ws.Unprotect Password:=TOOL_PASSWORD
    RestoreToolSheetScrollArea ws
    LockToolShapes ws, False
    ws.Protect Password:=TOOL_PASSWORD, DrawingObjects:=True, Contents:=True, Scenarios:=False, _
               UserInterfaceOnly:=True, AllowFiltering:=True, AllowSorting:=False, _
               AllowFormattingCells:=False, AllowFormattingColumns:=False, AllowFormattingRows:=False
    ws.EnableSelection = xlNoRestrictions
    If Not ws.ProtectContents Or Not ws.ProtectDrawingObjects Then _
        Err.Raise vbObjectError + 4614, "ProtectSingleAnalysisSheet", _
                  ws.Name & "��ی�ł��܂���ł����B"
    VerifyToolShapeSecurity ws, True, False
    If workbookWasSaved Then
        If Not TryStopTransactionAnalysisEventsForBookWrites(eventStateDetail) Then _
            Err.Raise vbObjectError + 4707, "ProtectSingleAnalysisSheet", _
                      "Saved�����O��Excel�C�x���g��~���m�F�ł��܂���ł����B " & _
                      eventStateDetail
        ThisWorkbook.Saved = True
        If Not ThisWorkbook.Saved Then _
            Err.Raise vbObjectError + 4705, "ProtectSingleAnalysisSheet", _
                      "�ی�m�F��Ƀu�b�N�ۑ���Ԃ𕜌��ł��܂���ł����B"
    End If
    On Error GoTo 0
    If eventsCaptured Then
        If Not TryRestoreTransactionAnalysisEnableEvents( _
                   previousEvents, "ProtectSingleAnalysisSheet/����I��", _
                   eventRestoreDetail) Then
            eventsCaptured = False
            Err.Raise vbObjectError + 4706, _
                      "ProtectSingleAnalysisSheet(" & sheetName & ")", _
                      eventRestoreDetail
        End If
        eventsCaptured = False
    End If
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    If IsTransactionAnalysisRecoveryFatal(errorNumber, errorSource) Then
        Call TryStopTransactionAnalysisEventsForBookWrites(eventStateDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    If TryStopTransactionAnalysisEventsForBookWrites(eventStateDetail) Then
        emergencyProtected = _
            TryEmergencyProtectAnalysisSheet(ws, emergencyDetail)
        If Not emergencyProtected Then
            recoveryDetail = sheetName & "�ً̋}�ĕی���m�F�ł��܂���B"
            AppendTransactionRollbackDetail recoveryDetail, emergencyDetail
            StopAfterTransactionAnalysisEventStateFailure _
                "ProtectSingleAnalysisSheet/�ً}�ĕی�", recoveryDetail, _
                recoveryEnforcementFailed, recoveryConfirmedThisAttempt, _
                eventsStoppedAfterRecovery, recoveryAttempted
            AppendTransactionRollbackDetail errorDescription, recoveryDetail
            If recoveryAttempted Then
                eventsCaptured = False
                Err.Raise vbObjectError + 5195, _
                    "TransactionAnalysisRecoveryFatal/ProtectSingleAnalysisSheet", _
                    errorDescription
            End If
        End If
    Else
        AppendTransactionRollbackDetail errorDescription, _
            "Excel�C�x���g��~���m�F�ł��Ȃ����ߋً}�ĕی�ERecovery�E�f�f�E" & _
            "��ԕ\���̏����݂�������A�Č��̈��S��Ԃ͕s���ł�: " & _
            eventStateDetail
        On Error Resume Next
        MsgBox "���̓V�[�g�̕ی�Ɏ��s���AExcel�C�x���g�����S�ɒ�~�ł��܂���ł����B" & _
               vbCrLf & "�ً}�ĕی�ƕ����L�^���s�킸�A�Č��̈��S��Ԃ͕s���ł��B" & _
               vbCrLf & "���݂̃u�b�N���㏑�����Ȃ��ł��������B", _
               vbCritical, "���̓V�[�g�̈��S��Ԃ��m�F�ł��܂���"
        On Error GoTo 0
    End If
    '�ً}�ی�Ƃ��̓ǖ߂����������A�C�x���g��False exact�̏ꍇ����
    '�ی쑀��ɂ��Saved�ύX���J�n�l�֖߂��B
    If emergencyProtected And workbookWasSaved Then
        If TryStopTransactionAnalysisEventsForBookWrites(eventStateDetail) Then
            RestoreSavedFlagAfterAnalysisProtection errorDescription
        Else
            AppendTransactionRollbackDetail errorDescription, _
                "�ً}�ی���Excel�C�x���g��~���m�F�ł��Ȃ����߁A" & _
                "�u�b�N�ۑ���Ԃ̕�����������܂���: " & eventStateDetail
            On Error Resume Next
            MsgBox "�ً}�ی���Excel�C�x���g��Ԃ��m�F�ł��Ȃ����߁A" & _
                   "�u�b�N�ۑ���Ԃ̕�����������܂����B" & _
                   vbCrLf & "���݂̃u�b�N���㏑�����Ȃ��ł��������B", _
                   vbCritical, "Excel�C�x���g��Ԃ��m�F�ł��܂���"
            On Error GoTo 0
        End If
    End If
    If eventsCaptured Then
        On Error Resume Next
        Err.Clear
        safeToRestoreEntry = emergencyProtected Or _
                             (recoveryConfirmedThisAttempt And _
                              eventsStoppedAfterRecovery)
        If safeToRestoreEntry Then _
            safeToRestoreEntry = _
                TransactionAnalysisApplicationStateAllowsEntryRestore( _
                    previousEvents, errorDescription)
        If safeToRestoreEntry Then
            If Not TryRestoreTransactionAnalysisEnableEvents( _
                       previousEvents, "ProtectSingleAnalysisSheet/�ُ�I��", _
                       eventRestoreDetail) Then _
                AppendTransactionRollbackDetail errorDescription, _
                    "Excel�C�x���g��Ԃ̕����G���[: " & eventRestoreDetail
            restoreErrorNumber = Err.Number
            restoreErrorSource = Err.Source
            restoreErrorDescription = Err.Description
        Else
            eventsStoppedAfterRecovery = _
                TryStopTransactionAnalysisEventsForBookWrites(eventStateDetail)
        End If
        Err.Clear
        On Error GoTo 0
        If IsTransactionAnalysisRecoveryFatal( _
               restoreErrorNumber, restoreErrorSource) Then
            Call TryStopTransactionAnalysisEventsForBookWrites(eventStateDetail)
            Err.Raise restoreErrorNumber, restoreErrorSource, _
                      restoreErrorDescription
        End If
        eventsCaptured = False
        If restoreErrorNumber <> 0 Then _
            AppendTransactionRollbackDetail errorDescription, _
                "Excel�C�x���g��Ԃ̕��������G���[: Err " & _
                CStr(restoreErrorNumber) & " " & restoreErrorDescription
    End If
    Err.Raise errorNumber, "ProtectSingleAnalysisSheet(" & sheetName & ")", _
              IIf(Len(errorSource) > 0, errorSource & " / ", vbNullString) & _
              errorDescription
End Sub

Private Function TryEmergencyProtectAnalysisSheet(ByVal ws As Worksheet, _
                                                   ByRef failureText As String) As Boolean
    failureText = vbNullString
    If ws Is Nothing Then
        failureText = "�ً}�ĕی삷�镪�̓V�[�g���擾�ł��܂���B"
        Exit Function
    End If
    On Error GoTo EH
    EmergencyProtectToolSheet ws
    If Not ws.ProtectContents Or Not ws.ProtectDrawingObjects Then
        failureText = "�ً}�ĕی��̃Z���E�}�`�ی��ǂݖ߂��܂���B"
        Exit Function
    End If
    TryEmergencyProtectAnalysisSheet = True
    Exit Function
EH:
    failureText = "Err " & CStr(Err.Number) & " [" & Err.Source & "] " & _
                  Err.Description
    Err.Clear
End Function

Private Sub RestoreSavedFlagAfterAnalysisProtection(ByRef detailText As String)
    Dim savedReadback As Boolean
    Dim savedErrorNumber As Long, savedErrorDescription As String
    Dim readErrorNumber As Long, readErrorDescription As String
    On Error Resume Next
    Err.Clear
    ThisWorkbook.Saved = True
    savedErrorNumber = Err.Number
    savedErrorDescription = Err.Description
    Err.Clear
    savedReadback = ThisWorkbook.Saved
    readErrorNumber = Err.Number
    readErrorDescription = Err.Description
    Err.Clear
    On Error GoTo 0
    If savedErrorNumber <> 0 Or readErrorNumber <> 0 Or Not savedReadback Then
        AppendTransactionRollbackDetail detailText, _
            "�u�b�N�ۑ���Ԃ̕������m�F�ł��܂���" & _
            IIf(savedErrorNumber <> 0, _
                ": Err " & CStr(savedErrorNumber) & " " & savedErrorDescription, _
                vbNullString) & _
            IIf(readErrorNumber <> 0, _
                " / �ǖ߂� Err " & CStr(readErrorNumber) & " " & _
                readErrorDescription, vbNullString)
    End If
End Sub

Private Sub SortShiftAnalysis(ByVal ws As Worksheet, ByVal lastR As Long)
    With ws.Sort
        .SortFields.Clear
        .SortFields.Add Key:=ws.Range(ws.Cells(2, 2), ws.Cells(lastR, 2)), _
                        SortOn:=xlSortOnValues, Order:=xlDescending, DataOption:=xlSortNormal
        .SortFields.Add Key:=ws.Range(ws.Cells(2, 9), ws.Cells(lastR, 9)), _
                        SortOn:=xlSortOnValues, Order:=xlAscending, DataOption:=xlSortNormal
        .SortFields.Add Key:=ws.Range(ws.Cells(2, 19), ws.Cells(lastR, 19)), _
                        SortOn:=xlSortOnValues, Order:=xlAscending, DataOption:=xlSortNormal
        .SetRange ws.Range(ws.Cells(1, 1), ws.Cells(lastR, SHIFT_ANALYSIS_LAST_COL))
        .Header = xlYes
        .Apply
    End With
End Sub

Private Sub SortUnknownAnalysis(ByVal ws As Worksheet, ByVal lastR As Long)
    With ws.Sort
        .SortFields.Clear
        '�����s���i�����j�Ǝg�r�s���i�o���j�����݂������A����\���ŕʌQ�ɂ���B
        .SortFields.Add Key:=ws.Range(ws.Cells(2, 3), ws.Cells(lastR, 3)), _
                        SortOn:=xlSortOnValues, Order:=xlAscending, DataOption:=xlSortNormal
        .SortFields.Add Key:=ws.Range(ws.Cells(2, 2), ws.Cells(lastR, 2)), _
                        SortOn:=xlSortOnValues, Order:=xlDescending, DataOption:=xlSortNormal
        .SortFields.Add Key:=ws.Range(ws.Cells(2, 4), ws.Cells(lastR, 4)), _
                        SortOn:=xlSortOnValues, Order:=xlAscending, DataOption:=xlSortNormal
        .SetRange ws.Range(ws.Cells(1, 1), ws.Cells(lastR, UNKNOWN_ANALYSIS_LAST_COL))
        .Header = xlYes
        .Apply
    End With
End Sub

Public Function CaptureAnalysisReviews(ByVal ws As Worksheet, ByVal statusColumn As Long, _
                                        ByVal memoColumn As Long, ByVal keyColumn As Long) As Object
    Dim reviews As Object
    Dim lastR As Long, r As Long, dataRows As Long
    Dim keyText As String, baseKey As String, evidenceDigest As String
    Dim statusText As String, memoText As String, kindText As String
    Dim firstValues As Variant, statusValues As Variant, memoValues As Variant, keyValues As Variant
    Dim kindValues As Variant
    Dim reviewRange As Range, formulaCells As Range, errorCells As Range
    Dim seenKeys As Object
    Set reviews = CreateObject("Scripting.Dictionary")
    reviews.CompareMode = vbTextCompare
    Set seenKeys = CreateObject("Scripting.Dictionary")
    seenKeys.CompareMode = vbTextCompare
    If ws Is Nothing Then
        Set CaptureAnalysisReviews = reviews
        Exit Function
    End If
    lastR = LastUsedRowInSheet(ws)
    If lastR < 2 Then
        Set CaptureAnalysisReviews = reviews
        Exit Function
    End If
    dataRows = lastR - 1
    Set reviewRange = Union( _
        ws.Range(ws.Cells(2, statusColumn), ws.Cells(lastR, statusColumn)), _
        ws.Range(ws.Cells(2, memoColumn), ws.Cells(lastR, memoColumn)), _
        ws.Range(ws.Cells(2, keyColumn), ws.Cells(lastR, keyColumn)))
    If Not TryFindFirstFormulaCell(reviewRange, formulaCells) Then _
        Err.Raise vbObjectError + 4625, "CaptureAnalysisReviews", _
                  ws.Name & "�̊m�F���E�����L�[�𐔎������ł��܂���ł����B"
    If Not TryFindFirstErrorConstantCell(reviewRange, errorCells) Then _
        Err.Raise vbObjectError + 4626, "CaptureAnalysisReviews", _
                  ws.Name & "�̊m�F���E�����L�[��Excel�G���[�����ł��܂���ł����B"
    If Not formulaCells Is Nothing Then _
        Err.Raise vbObjectError + 4621, "CaptureAnalysisReviews", _
                  ws.Name & "�̊m�F���܂��͓����L�[�ɐ���������܂��B"
    If Not errorCells Is Nothing Then _
        Err.Raise vbObjectError + 4622, "CaptureAnalysisReviews", _
                  ws.Name & "�̊m�F���܂��͓����L�[��Excel�G���[�l������܂��B"
    firstValues = ws.Range(ws.Cells(2, 1), ws.Cells(lastR, 1)).Value2
    statusValues = ws.Range(ws.Cells(2, statusColumn), ws.Cells(lastR, statusColumn)).Value2
    memoValues = ws.Range(ws.Cells(2, memoColumn), ws.Cells(lastR, memoColumn)).Value2
    keyValues = ws.Range(ws.Cells(2, keyColumn), ws.Cells(lastR, keyColumn)).Value2
    If StrComp(ws.Name, SH_ANALYSIS_UNKNOWN, vbTextCompare) = 0 Then _
        kindValues = ws.Range(ws.Cells(2, 3), ws.Cells(lastR, 3)).Value2
    For r = 1 To dataRows
        keyText = CellText(AnalysisColumnValue(keyValues, r, dataRows))
        If Len(keyText) > 0 Then
            baseKey = AnalysisBaseKey(keyText, evidenceDigest)
            If Len(baseKey) = 0 Then _
                Err.Raise vbObjectError + 4623, "CaptureAnalysisReviews", _
                          ws.Name & " " & CStr(r + 1) & "�s�ڂ̊m�F�L�[�{�̂�����܂���B"
            If seenKeys.Exists(baseKey) Then _
                Err.Raise vbObjectError + 4617, "CaptureAnalysisReviews", _
                          ws.Name & "�̊m�F�L�[���d�����Ă��܂�: " & baseKey
            seenKeys.Add baseKey, True
            statusText = CellText(AnalysisColumnValue(statusValues, r, dataRows))
            If Len(statusText) = 0 Then statusText = ANALYSIS_STATUS_UNREVIEWED
            memoText = CellText(AnalysisColumnValue(memoValues, r, dataRows))
            kindText = vbNullString
            If StrComp(ws.Name, SH_ANALYSIS_UNKNOWN, vbTextCompare) = 0 Then _
                kindText = CellText(AnalysisColumnValue(kindValues, r, dataRows))
            If Not IsAnalysisReviewStatusForSheet(ws.Name, statusText, kindText) Then _
                Err.Raise vbObjectError + 4615, "CaptureAnalysisReviews", _
                          ws.Name & " " & CStr(r + 1) & _
                          "�s�ڂ̊m�F�󋵂��s�̎�ނɓK�����܂���: " & statusText
            If Len(memoText) > ANALYSIS_REVIEW_MEMO_MAX Then _
                Err.Raise vbObjectError + 4616, "CaptureAnalysisReviews", _
                          ws.Name & " " & CStr(r + 1) & "�s�ڂ̊m�F������" & _
                          CStr(ANALYSIS_REVIEW_MEMO_MAX) & "�����𒴂��Ă��܂��B"
            '����̖��m�F�E�����Ȃ��͍Đ������������ɂȂ邽�ߎ����֕ێ����Ȃ��B
            '���p�҂����ۂɊm�F�����s������ޔ����A��K�͈Č��̃������g�p��}����B
            If statusText <> ANALYSIS_STATUS_UNREVIEWED Or Len(memoText) > 0 Then
                reviews.Add baseKey, Array(statusText, memoText, evidenceDigest)
            End If
        ElseIf HasText(AnalysisColumnValue(firstValues, r, dataRows)) Or _
               HasText(AnalysisColumnValue(statusValues, r, dataRows)) Or _
               HasText(AnalysisColumnValue(memoValues, r, dataRows)) Then
            Err.Raise vbObjectError + 4619, "CaptureAnalysisReviews", _
                      ws.Name & " " & CStr(r + 1) & "�s�ڂɊm�F�L�[������܂���B"
        End If
    Next r
    Set CaptureAnalysisReviews = reviews
End Function

Public Function AnalysisReviewValues(ByVal reviews As Object, ByVal keyText As String, _
                                     ByVal currentEvidenceDigest As String) As Variant
    Dim storedValues As Variant, storedDigest As String
    If Not reviews Is Nothing Then
        If reviews.Exists(keyText) Then
            storedValues = reviews(keyText)
            If UBound(storedValues) >= 2 Then storedDigest = CStr(storedValues(2))
            If Len(currentEvidenceDigest) > 0 And _
               StrComp(storedDigest, currentEvidenceDigest, vbBinaryCompare) <> 0 Then
                AnalysisReviewValues = Array(ANALYSIS_STATUS_FOLLOWUP, CStr(storedValues(1)), True)
            Else
                AnalysisReviewValues = Array(CStr(storedValues(0)), CStr(storedValues(1)), False)
            End If
            Exit Function
        End If
    End If
    AnalysisReviewValues = Array(ANALYSIS_STATUS_UNREVIEWED, vbNullString, False)
End Function

Private Function IsAnalysisReviewStatusForSheet(ByVal sheetName As String, _
                                                ByVal statusText As String, _
                                                ByVal kindText As String) As Boolean
    statusText = Trim$(statusText)
    If StrComp(sheetName, SH_ANALYSIS_SHIFT, vbTextCompare) = 0 Or _
       StrComp(sheetName, SH_ANALYSIS_FLOW, vbTextCompare) = 0 Then
        Select Case statusText
            Case ANALYSIS_STATUS_UNREVIEWED, ANALYSIS_STATUS_SHIFT_CONFIRMED, _
                 ANALYSIS_STATUS_EXCLUDED, ANALYSIS_STATUS_FOLLOWUP
                IsAnalysisReviewStatusForSheet = True
        End Select
    ElseIf StrComp(sheetName, SH_ANALYSIS_UNKNOWN, vbTextCompare) = 0 Then
        If StrComp(kindText, "�����s�����", vbTextCompare) = 0 Then
            Select Case statusText
                Case ANALYSIS_STATUS_UNREVIEWED, ANALYSIS_STATUS_SOURCE_CONFIRMED, _
                     ANALYSIS_STATUS_EXCLUDED, ANALYSIS_STATUS_FOLLOWUP
                    IsAnalysisReviewStatusForSheet = True
            End Select
        ElseIf StrComp(kindText, "�g�r�s�����", vbTextCompare) = 0 Then
            Select Case statusText
                Case ANALYSIS_STATUS_UNREVIEWED, ANALYSIS_STATUS_USE_CONFIRMED, _
                     ANALYSIS_STATUS_EXCLUDED, ANALYSIS_STATUS_FOLLOWUP
                    IsAnalysisReviewStatusForSheet = True
            End Select
        End If
    Else
        IsAnalysisReviewStatusForSheet = IsAnalysisReviewStatus(statusText)
    End If
End Function

Public Sub CheckSingleAnalysisSheet(ByVal ws As Worksheet, ByVal statusColumn As Long, _
                                     ByVal memoColumn As Long, ByVal keyColumn As Long, _
                                     ByVal labelText As String, ByRef problems As String, _
                                     ByRef interfaceWarnings As String, _
                                     ByVal includeInterfaceChecks As Boolean)
    Dim lastR As Long, r As Long, dataRows As Long
    Dim keyText As String, baseKey As String, evidenceDigest As String
    Dim statusText As String, memoText As String, kindText As String
    Dim keys As Object
    Dim statusValues As Variant, memoValues As Variant, keyValues As Variant, kindValues As Variant
    Dim validationFormula As String
    Dim lockedValue As Variant
    If ws Is Nothing Then Exit Sub
    Set keys = CreateObject("Scripting.Dictionary")
    keys.CompareMode = vbTextCompare
    If includeInterfaceChecks Then
        If Not ws.ProtectContents Then _
            interfaceWarnings = interfaceWarnings & "�E" & labelText & "���ی삳��Ă��܂���" & vbCrLf
        If ws.Protection.AllowSorting Then _
            interfaceWarnings = interfaceWarnings & "�E" & labelText & _
                                "�ŕی쉺�̕��בւ����L���ł��B���̍����s����邽�ߖ����ɂ��Ă�������" & vbCrLf
    End If
    lastR = LastUsedRowInSheet(ws)
    If lastR >= 2 Then
        dataRows = lastR - 1
        If includeInterfaceChecks Then
            validationFormula = AnalysisReviewValidationFormula(ws.Name)
            CheckAnalysisValidationRange ws.Range(ws.Cells(2, statusColumn), ws.Cells(lastR, statusColumn)), _
                                         xlValidateList, validationFormula, _
                                         labelText & "�̊m�F��", interfaceWarnings
            CheckAnalysisValidationRange ws.Range(ws.Cells(2, memoColumn), ws.Cells(lastR, memoColumn)), _
                                         xlValidateTextLength, CStr(ANALYSIS_REVIEW_MEMO_MAX), _
                                         labelText & "�̊m�F����", interfaceWarnings, xlLessEqual
            lockedValue = ws.Range(ws.Cells(2, statusColumn), ws.Cells(lastR, statusColumn)).Locked
            If IsNull(lockedValue) Then
                interfaceWarnings = interfaceWarnings & "�E" & labelText & _
                                    "�̊m�F�󋵗�Ƀ��b�N��Ԃ����݂��Ă��܂�" & vbCrLf
            ElseIf CBool(lockedValue) Then
                interfaceWarnings = interfaceWarnings & "�E" & labelText & _
                                    "�̊m�F�󋵗�ɕҏW�s�Z��������܂�" & vbCrLf
            End If
            lockedValue = ws.Range(ws.Cells(2, memoColumn), ws.Cells(lastR, memoColumn)).Locked
            If IsNull(lockedValue) Then
                interfaceWarnings = interfaceWarnings & "�E" & labelText & _
                                    "�̊m�F������Ƀ��b�N��Ԃ����݂��Ă��܂�" & vbCrLf
            ElseIf CBool(lockedValue) Then
                interfaceWarnings = interfaceWarnings & "�E" & labelText & _
                                    "�̊m�F������ɕҏW�s�Z��������܂�" & vbCrLf
            End If
            lockedValue = ws.Range(ws.Cells(2, keyColumn), ws.Cells(lastR, keyColumn)).Locked
            If IsNull(lockedValue) Then
                interfaceWarnings = interfaceWarnings & "�E" & labelText & _
                                    "�̊m�F�L�[��Ƀ��b�N��Ԃ����݂��Ă��܂�" & vbCrLf
            ElseIf Not CBool(lockedValue) Then
                interfaceWarnings = interfaceWarnings & "�E" & labelText & _
                                    "�̊m�F�L�[��ɕҏW�\�Z��������܂�" & vbCrLf
            End If
        End If
        statusValues = ws.Range(ws.Cells(2, statusColumn), ws.Cells(lastR, statusColumn)).Value2
        memoValues = ws.Range(ws.Cells(2, memoColumn), ws.Cells(lastR, memoColumn)).Value2
        keyValues = ws.Range(ws.Cells(2, keyColumn), ws.Cells(lastR, keyColumn)).Value2
        If StrComp(ws.Name, SH_ANALYSIS_UNKNOWN, vbTextCompare) = 0 Then _
            kindValues = ws.Range(ws.Cells(2, 3), ws.Cells(lastR, 3)).Value2
    End If
    For r = 1 To dataRows
        If Len(problems) >= ANALYSIS_CHECK_MAX_DETAIL_CHARS Then Exit For
        baseKey = vbNullString
        evidenceDigest = vbNullString
        keyText = CellText(AnalysisColumnValue(keyValues, r, dataRows))
        statusText = CellText(AnalysisColumnValue(statusValues, r, dataRows))
        memoText = CellText(AnalysisColumnValue(memoValues, r, dataRows))
        kindText = vbNullString
        If StrComp(ws.Name, SH_ANALYSIS_UNKNOWN, vbTextCompare) = 0 Then _
            kindText = CellText(AnalysisColumnValue(kindValues, r, dataRows))
        If Len(keyText) = 0 Then
            problems = problems & "�E" & labelText & " " & CStr(r + 1) & "�s: �m�F�L�[�Ȃ�" & vbCrLf
        Else
            baseKey = AnalysisBaseKey(keyText, evidenceDigest)
        End If
        If Len(keyText) > 0 And Len(baseKey) = 0 Then
            problems = problems & "�E" & labelText & " " & CStr(r + 1) & "�s: �m�F�L�[�{�̂Ȃ�" & vbCrLf
        ElseIf Len(keyText) > 0 And Not IsAnalysisEvidenceDigest(evidenceDigest) Then
            problems = problems & "�E" & labelText & " " & CStr(r + 1) & "�s: ���������s��" & vbCrLf
        ElseIf Len(keyText) > 0 And keys.Exists(baseKey) Then
            problems = problems & "�E" & labelText & " " & CStr(r + 1) & "�s: �m�F�L�[�d��" & vbCrLf
        ElseIf Len(keyText) > 0 Then
            keys.Add baseKey, True
        End If
        If Not IsAnalysisReviewStatusForSheet(ws.Name, statusText, kindText) Then _
            problems = problems & "�E" & labelText & " " & CStr(r + 1) & _
                       "�s: �m�F�󋵂��s�̎�ނɕs�K��" & vbCrLf
        If Len(memoText) > ANALYSIS_REVIEW_MEMO_MAX Then _
            problems = problems & "�E" & labelText & " " & CStr(r + 1) & "�s: �m�F�������������܂�" & vbCrLf
    Next r
End Sub

Private Function IsAnalysisEvidenceDigest(ByVal evidenceDigest As String) As Boolean
    Dim i As Long, characterText As String
    If Len(evidenceDigest) <> 17 Or Mid$(evidenceDigest, 9, 1) <> "-" Then Exit Function
    For i = 1 To Len(evidenceDigest)
        If i <> 9 Then
            characterText = UCase$(Mid$(evidenceDigest, i, 1))
            If InStr(1, "0123456789ABCDEF", characterText, vbBinaryCompare) = 0 Then Exit Function
        End If
    Next i
    IsAnalysisEvidenceDigest = True
End Function

Private Function AnalysisColumnValue(ByRef columnData As Variant, ByVal dataIndex As Long, _
                                     ByVal dataRows As Long) As Variant
    If dataRows = 1 Then
        AnalysisColumnValue = columnData
    Else
        AnalysisColumnValue = columnData(dataIndex, 1)
    End If
End Function

Private Sub CheckAnalysisValidationRange(ByVal target As Range, ByVal expectedType As Long, _
                                         ByVal expectedFormula As String, ByVal labelText As String, _
                                         ByRef problems As String, _
                                         Optional ByVal expectedOperator As Long = 0)
    Dim validationCells As Range, coveredCells As Range, cell As Range
    Dim chunkRange As Range
    Dim typeValue As Variant, formulaValue As Variant, showErrorValue As Variant
    Dim operatorValue As Variant
    Dim issueText As String
    Dim aggregateReadable As Boolean
    Dim uniformCriteria As Boolean, uniformCriteriaKnown As Boolean
    Dim validationCoverageKnown As Boolean
    Dim specialCellsErrorNumber As Long
    Dim rowOffset As Long, chunkRowCount As Long, splitRowCount As Long
    Dim problemsLengthBefore As Long
    On Error GoTo EH
    If target Is Nothing Then issueText = "�Ώ۔͈͂Ȃ�": GoTo InvalidValidation
    '1�Z��Range��SpecialCells�̓V�[�g�S�̂�Ԃ����Ƃ����邽�߁A�����Z�������Ŏg���B
    If CDbl(target.CountLarge) > 1 Then
        On Error Resume Next
        Err.Clear
        Set validationCells = target.SpecialCells(xlCellTypeAllValidation)
        specialCellsErrorNumber = Err.Number
        Err.Clear
        If Not validationCells Is Nothing Then Set coveredCells = Intersect(target, validationCells)
        If Err.Number <> 0 Then specialCellsErrorNumber = Err.Number
        Err.Clear
        On Error GoTo EH
        validationCoverageKnown = (specialCellsErrorNumber = 0 And Not validationCells Is Nothing)
        If validationCoverageKnown Then
            If coveredCells Is Nothing Then
                validationCoverageKnown = False
            ElseIf CDbl(coveredCells.CountLarge) <> CDbl(target.CountLarge) Then
                'SpecialCells�̕����W�������Ō����ƒf�肵�Ȃ��B
                'Office�r���h��������A���̕����E�Z���ʓǖ߂��Ŏ��Z�����m�F����B
                validationCoverageKnown = False
            End If
        End If

        uniformCriteria = ValidationRangeHasUniformCriteria(target, uniformCriteriaKnown)

        On Error Resume Next
        Err.Clear
        typeValue = target.Validation.Type
        aggregateReadable = (Err.Number = 0 And Not IsNull(typeValue))
        If aggregateReadable Then
            formulaValue = target.Validation.Formula1
            If Err.Number <> 0 Or IsNull(formulaValue) Then aggregateReadable = False
            Err.Clear
            showErrorValue = target.Validation.ShowError
            If Err.Number <> 0 Or IsNull(showErrorValue) Then aggregateReadable = False
            If expectedOperator <> 0 Then
                Err.Clear
                operatorValue = target.Validation.Operator
                If Err.Number <> 0 Or IsNull(operatorValue) Then aggregateReadable = False
            End If
        End If
        Err.Clear
        On Error GoTo EH
        If aggregateReadable Then
            If CLng(typeValue) <> expectedType Then _
                issueText = target.Cells(1, 1).Address(False, False) & "�̎�ނ��s��v": GoTo InvalidValidation
            If Not AnalysisValidationFormulaMatches(target.Cells(1, 1), _
                                                     CellText(formulaValue), expectedType, expectedFormula) Then _
                issueText = target.Cells(1, 1).Address(False, False) & "�̐������s��v": GoTo InvalidValidation
            If Not CBool(showErrorValue) Then _
                issueText = target.Cells(1, 1).Address(False, False) & "�̃G���[�\��������": GoTo InvalidValidation
            If expectedOperator <> 0 Then
                If CLng(operatorValue) <> expectedOperator Then _
                    issueText = target.Cells(1, 1).Address(False, False) & "�̉��Z�q���s��v": GoTo InvalidValidation
            End If
            If uniformCriteriaKnown And uniformCriteria Then Exit Sub
        End If
    End If

    If CDbl(target.Rows.CountLarge) > VALIDATION_CHECK_DIRECT_ROWS Then
            '�ő�20���s���܂�2,000�s�A���ɍő�64�s�֒i�K��������B
            '�e�q�͈͂ŏW��fast path���Ď��s���A�擾�s�\���̒��ڑ������������ۂB
            If CDbl(target.Rows.CountLarge) > VALIDATION_CHECK_CHUNK_ROWS Then
                splitRowCount = VALIDATION_CHECK_CHUNK_ROWS
            Else
                splitRowCount = VALIDATION_CHECK_DIRECT_ROWS
            End If
            For rowOffset = 1 To CLng(target.Rows.CountLarge) Step splitRowCount
                chunkRowCount = Application.Min(splitRowCount, _
                                                CLng(target.Rows.CountLarge) - rowOffset + 1)
                Set chunkRange = target.Rows(rowOffset).Resize(chunkRowCount, target.Columns.Count)
                problemsLengthBefore = Len(problems)
                CheckAnalysisValidationRange chunkRange, expectedType, expectedFormula, _
                                             labelText, problems, expectedOperator
                If Len(problems) > problemsLengthBefore Then Exit Sub
            Next rowOffset
            Exit Sub
    End If

    For Each cell In target.Cells
        issueText = AnalysisValidationCellIssue(cell, expectedType, expectedFormula, expectedOperator)
        If Len(issueText) > 0 Then GoTo InvalidValidation
    Next cell
    Exit Sub
InvalidValidation:
    problems = problems & "�E" & labelText & "�̓��͋K��: " & issueText & vbCrLf
    Exit Sub
EH:
    problems = problems & "�E" & labelText & "�̓��͋K�����m�F�ł��܂���: " & Err.Description & vbCrLf
    Err.Clear
End Sub

Private Function AnalysisValidationCellIssue(ByVal cell As Range, ByVal expectedType As Long, _
                                             ByVal expectedFormula As String, _
                                             Optional ByVal expectedOperator As Long = 0) As String
    Dim typeValue As Variant, formulaValue As Variant, showErrorValue As Variant
    Dim operatorValue As Variant
    Dim addressText As String
    On Error GoTo EH
    If cell Is Nothing Then
        AnalysisValidationCellIssue = "�ΏۃZ���Ȃ�"
        Exit Function
    End If
    addressText = cell.Address(False, False)
    typeValue = cell.Validation.Type
    If IsNull(typeValue) Then
        AnalysisValidationCellIssue = addressText & "�̎�ނ��擾�s�\"
        Exit Function
    End If
    If CLng(typeValue) <> expectedType Then
        AnalysisValidationCellIssue = addressText & "�̎�ނ��s��v"
        Exit Function
    End If
    If expectedType <> xlValidateList And expectedType <> xlValidateTextLength Then Exit Function
    formulaValue = cell.Validation.Formula1
    showErrorValue = cell.Validation.ShowError
    If IsNull(formulaValue) Then
        AnalysisValidationCellIssue = addressText & "�̐������擾�s�\"
        Exit Function
    End If
    If Not AnalysisValidationFormulaMatches(cell, CellText(formulaValue), _
                                            expectedType, expectedFormula) Then
        AnalysisValidationCellIssue = addressText & "�̐������s��v�i����: " & _
                                      ValidationFormulaDiagnostic(expectedFormula) & _
                                      " / ����: " & _
                                      ValidationFormulaDiagnostic(CellText(formulaValue)) & "�j"
        Exit Function
    End If
    If IsNull(showErrorValue) Then
        AnalysisValidationCellIssue = addressText & "�̃G���[�\���ݒ���擾�s�\"
    ElseIf Not CBool(showErrorValue) Then
        AnalysisValidationCellIssue = addressText & "�̃G���[�\��������"
    End If
    If Len(AnalysisValidationCellIssue) > 0 Then Exit Function
    If expectedOperator <> 0 Then
        operatorValue = cell.Validation.Operator
        If IsNull(operatorValue) Then
            AnalysisValidationCellIssue = addressText & "�̉��Z�q���擾�s�\"
        ElseIf CLng(operatorValue) <> expectedOperator Then
            AnalysisValidationCellIssue = addressText & "�̉��Z�q���s��v"
        End If
    End If
    Exit Function
EH:
    If Len(addressText) = 0 Then addressText = "�ΏۃZ��"
    AnalysisValidationCellIssue = addressText & "���m�F�ł��܂���: " & Err.Description
    Err.Clear
End Function

Private Function AnalysisValidationFormulaMatches(ByVal targetCell As Range, _
                                                  ByVal actualFormulaText As String, _
                                                  ByVal expectedType As Long, _
                                                  ByVal expectedFormulaText As String) As Boolean
    Dim actualFormula As String, expectedFormula As String
    If targetCell Is Nothing Then Exit Function
    actualFormula = NormalizedValidationFormulaText(actualFormulaText)
    expectedFormula = NormalizedValidationFormulaText(expectedFormulaText)
    If expectedType = xlValidateList And _
       StrComp(expectedFormula, UCase$(NM_LST_ANALYSIS_SHIFT_STATUS), vbBinaryCompare) = 0 Then
        AnalysisValidationFormulaMatches = _
            ValidationListSourceMatches(targetCell, actualFormulaText, NM_LST_ANALYSIS_SHIFT_STATUS)
        Exit Function
    End If
    If StrComp(actualFormula, expectedFormula, vbBinaryCompare) = 0 Then
        AnalysisValidationFormulaMatches = True
        Exit Function
    End If
    '�s�����o���̎��͍s���ΎQ�ƂȂ̂ŁAExcel���e�s�֓W�J���ĕԂ��\�L�����e����B
    expectedFormula = Replace(expectedFormula, "$C2", "$C" & CStr(targetCell.Row), 1, -1, vbTextCompare)
    AnalysisValidationFormulaMatches = _
        (StrComp(actualFormula, expectedFormula, vbBinaryCompare) = 0)
End Function

Private Function NormalizedValidationFormulaText(ByVal formulaText As String) As String
    Dim normalizedText As String
    normalizedText = Trim$(formulaText)
    If Len(normalizedText) > 0 Then
        If Left$(normalizedText, 1) = "=" Then normalizedText = Mid$(normalizedText, 2)
    End If
    If Len(normalizedText) > 0 Then
        'Microsoft 365�n���Öق̌������Z�q��t����Formula1��Ԃ��\�L�����z������B
        If Left$(normalizedText, 1) = "@" Then normalizedText = Mid$(normalizedText, 2)
    End If
    normalizedText = Replace(normalizedText, " ", "")
    normalizedText = Replace(normalizedText, "�@", "")
    NormalizedValidationFormulaText = UCase$(normalizedText)
End Function

Public Sub FlushAnalysisBuffer(ByVal ws As Worksheet, ByRef buffer() As Variant, ByVal bufferCount As Long, _
                                ByRef nextOutputRow As Long, ByVal lastColumn As Long)
    Dim tail() As Variant
    Dim r As Long, c As Long
    If bufferCount <= 0 Then Exit Sub
    If bufferCount = UBound(buffer, 1) Then
        ws.Range(ws.Cells(nextOutputRow, 1), _
                 ws.Cells(nextOutputRow + bufferCount - 1, lastColumn)).Value = buffer
    Else
        ReDim tail(1 To bufferCount, 1 To lastColumn)
        For r = 1 To bufferCount
            For c = 1 To lastColumn
                tail(r, c) = buffer(r, c)
            Next c
        Next r
        ws.Range(ws.Cells(nextOutputRow, 1), _
                 ws.Cells(nextOutputRow + bufferCount - 1, lastColumn)).Value = tail
    End If
    nextOutputRow = nextOutputRow + bufferCount
End Sub

Private Sub AnalysisAmountSearchBounds(ByVal amountValue As Double, ByVal absoluteTolerance As Double, _
                                       ByVal rateTolerance As Double, ByRef lowerAmount As Double, _
                                       ByRef upperAmount As Double)
    AutoCandidateAmountSearchBounds amountValue, lowerAmount, upperAmount, _
                                    absoluteTolerance, rateTolerance
    If upperAmount > MAX_ABS_AMOUNT Then upperAmount = MAX_ABS_AMOUNT
End Sub

Private Function LowerBoundAnalysisAmount(ByRef amounts() As Double, ByVal itemCount As Long, _
                                          ByVal targetValue As Double) As Long
    Dim low As Long, high As Long, mid As Long
    low = 1
    high = itemCount + 1
    Do While low < high
        mid = low + (high - low) \ 2
        If mid <= itemCount And amounts(mid) < targetValue Then low = mid + 1 Else high = mid
    Loop
    LowerBoundAnalysisAmount = low
End Function

Private Function UpperBoundAnalysisAmount(ByRef amounts() As Double, ByVal itemCount As Long, _
                                          ByVal targetValue As Double) As Long
    Dim low As Long, high As Long, mid As Long
    low = 1
    high = itemCount + 1
    Do While low < high
        mid = low + (high - low) \ 2
        If mid <= itemCount And amounts(mid) <= targetValue Then low = mid + 1 Else high = mid
    Loop
    UpperBoundAnalysisAmount = low - 1
End Function

Private Sub QuickSortAnalysisAmounts(ByRef amounts() As Double, ByRef sourceRows() As Long, _
                                     ByVal firstIndex As Long, ByVal lastIndex As Long)
    Dim low As Long, high As Long
    Dim pivot As Double, tempAmount As Double
    Dim tempRow As Long
    low = firstIndex
    high = lastIndex
    pivot = amounts((firstIndex + lastIndex) \ 2)
    Do While low <= high
        Do While amounts(low) < pivot
            low = low + 1
        Loop
        Do While amounts(high) > pivot
            high = high - 1
        Loop
        If low <= high Then
            tempAmount = amounts(low): amounts(low) = amounts(high): amounts(high) = tempAmount
            tempRow = sourceRows(low): sourceRows(low) = sourceRows(high): sourceRows(high) = tempRow
            low = low + 1
            high = high - 1
        End If
    Loop
    If firstIndex < high Then QuickSortAnalysisAmounts amounts, sourceRows, firstIndex, high
    If low < lastIndex Then QuickSortAnalysisAmounts amounts, sourceRows, low, lastIndex
End Sub

Private Function TryGetAnalysisTime(ByVal valueIn As Variant, ByRef timeFraction As Double) As Boolean
    Dim ok As Boolean, normalizedTime As Variant
    If Not HasText(valueIn) Then Exit Function
    normalizedTime = NormalizeTimeInput(valueIn, ok)
    If Not ok Then Exit Function
    timeFraction = CDbl(CDate(normalizedTime)) - Fix(CDbl(CDate(normalizedTime)))
    TryGetAnalysisTime = True
End Function

Private Function AnalysisTimeOutputValue(ByVal valueIn As Variant) As Variant
    Dim timeFraction As Double
    If TryGetAnalysisTime(valueIn, timeFraction) Then
        AnalysisTimeOutputValue = timeFraction
    Else
        AnalysisTimeOutputValue = Empty
    End If
End Function

Private Function FormatAnalysisElapsedMinutes(ByVal minuteValue As Double) As String
    Dim wholeMinutes As Long, days As Long, hours As Long, minutes As Long
    If minuteValue < 0 Then minuteValue = -minuteValue
    If minuteValue > 2147483646# Then
        FormatAnalysisElapsedMinutes = Format$(minuteValue / 1440#, "0.0") & "��"
        Exit Function
    End If
    wholeMinutes = CLng(minuteValue + 0.5)
    days = wholeMinutes \ 1440
    hours = (wholeMinutes Mod 1440) \ 60
    minutes = wholeMinutes Mod 60
    If days > 0 Then
        FormatAnalysisElapsedMinutes = CStr(days) & "��" & CStr(hours) & "����" & CStr(minutes) & "��"
    ElseIf hours > 0 Then
        FormatAnalysisElapsedMinutes = CStr(hours) & "����" & CStr(minutes) & "��"
    Else
        FormatAnalysisElapsedMinutes = CStr(minutes) & "��"
    End If
End Function

Attribute VB_Name = "modReleaseRegression"
Option Explicit

Private mLastReleaseRegressionFailure As String

Public Function GetLastReleaseRegressionFailure() As String
    GetLastReleaseRegressionFailure = mLastReleaseRegressionFailure
End Function

'�o�׃r���h���K���ĂԏW������B�����{�E��O�EFalse�����ׂĕs���i�ɂ���B
Public Function RunReleaseRegressionTests() As Boolean
    Dim currentTest As String
    Dim failureDetail As String
    On Error GoTo Failed
    mLastReleaseRegressionFailure = vbNullString

    currentTest = "BuildSmokeTest"
    If Not BuildSmokeTest() Then GoTo ReturnedFalse
    currentTest = "BuildInterfaceSmokeTest"
    If Not BuildInterfaceSmokeTest() Then GoTo ReturnedFalse
    currentTest = "ManualFlowRegressionTest"
    If Not ManualFlowRegressionTest() Then GoTo ReturnedFalse
    currentTest = "AllocationLedgerContractRegressionTest"
    If Not AllocationLedgerContractRegressionTest() Then GoTo ReturnedFalse
    currentTest = "BalanceReconciliationRegressionTest"
    If Not BalanceReconciliationRegressionTest() Then GoTo ReturnedFalse
    currentTest = "TransactionAnalysisRegressionTest"
    If Not TransactionAnalysisRegressionTest() Then GoTo ReturnedFalse
    currentTest = "AdvancedFlowRegressionTest"
    If Not AdvancedFlowRegressionTest() Then GoTo ReturnedFalse
    currentTest = "AnalysisWorkspacePriorityRegressionTest"
    If Not AnalysisWorkspacePriorityRegressionTest() Then GoTo ReturnedFalse
    currentTest = "CashAnalysisPersonDisplayRegressionTest"
    If Not CashAnalysisPersonDisplayRegressionTest() Then GoTo ReturnedFalse
    currentTest = "CashAnalysisNavigationRegressionTest"
    If Not CashAnalysisNavigationRegressionTest() Then GoTo ReturnedFalse
    currentTest = "NativeInputNavigationContractRegressionTest"
    If Not NativeInputNavigationContractRegressionTest() Then GoTo ReturnedFalse
    currentTest = "ExternalIdentifierRegressionTest"
    If Not ExternalIdentifierRegressionTest() Then GoTo ReturnedFalse
    currentTest = "ExternalFutureIdentityRegressionTest"
    If Not ExternalFutureIdentityRegressionTest() Then GoTo ReturnedFalse
    currentTest = "ExternalHeaderSchemaRegressionTest"
    If Not ExternalHeaderSchemaRegressionTest() Then GoTo ReturnedFalse
    currentTest = "ExternalYearEndBalanceRegressionTest"
    If Not ExternalYearEndBalanceRegressionTest() Then GoTo ReturnedFalse
    currentTest = "EditPersonIDReuseRegressionTest"
    If Not EditPersonIDReuseRegressionTest() Then GoTo ReturnedFalse
    currentTest = "DecidedAnalysisPolicyRegressionTest"
    If Not DecidedAnalysisPolicyRegressionTest() Then GoTo ReturnedFalse
    currentTest = "FinalExportSafetyRegressionTest"
    If Not FinalExportSafetyRegressionTest() Then GoTo ReturnedFalse
    currentTest = "PersonIntegrityRegressionTest"
    If Not PersonIntegrityRegressionTest() Then GoTo ReturnedFalse

    RunReleaseRegressionTests = True
    Exit Function
ReturnedFalse:
    mLastReleaseRegressionFailure = currentTest & " returned False."
    If StrComp(currentTest, "BuildSmokeTest", vbBinaryCompare) = 0 Or _
       StrComp(currentTest, "BuildInterfaceSmokeTest", vbBinaryCompare) = 0 Then
        failureDetail = GetLastSetupFailureDetail()
        If Len(failureDetail) > 0 Then _
            mLastReleaseRegressionFailure = mLastReleaseRegressionFailure & " " & failureDetail
    ElseIf StrComp(currentTest, "PersonIntegrityRegressionTest", vbBinaryCompare) = 0 Then
        failureDetail = GetLastPersonIntegrityRegressionFailure()
        If Len(failureDetail) > 0 Then _
            mLastReleaseRegressionFailure = mLastReleaseRegressionFailure & " " & failureDetail
    End If
    Exit Function
Failed:
    mLastReleaseRegressionFailure = currentTest & " raised Err " & _
                                    CStr(Err.Number) & ": " & Err.Description
    RunReleaseRegressionTests = False
End Function

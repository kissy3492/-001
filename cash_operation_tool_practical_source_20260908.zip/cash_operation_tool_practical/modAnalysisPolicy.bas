Attribute VB_Name = "modAnalysisPolicy"
Option Explicit

'�������̋��ʃn�[�h�Q�[�g�B
'��ʑ��̐ݒ�l�⋌�u�b�N�l���c���Ă��Ă��A���̏�����L���Ă͂Ȃ�Ȃ��B
Public Const AUTO_CANDIDATE_MIN_DEPOSIT_RATIO As Double = 0.9
Public Const AUTO_CANDIDATE_MAX_DEPOSIT_RATIO As Double = 1.1
Public Const AUTO_CANDIDATE_MAX_AMOUNT_DIFFERENCE As Double = 1000000#
Public Const AUTO_CANDIDATE_MAX_CALENDAR_DAYS As Long = 3
Public Const AUTO_CANDIDATE_MAX_GROUP_TRANSACTIONS As Long = 4

Private Function EffectiveAutoCandidateAbsoluteTolerance( _
        ByVal configuredAbsoluteTolerance As Double) As Double
    If configuredAbsoluteTolerance <= 0# Then Exit Function
    If configuredAbsoluteTolerance > AUTO_CANDIDATE_MAX_AMOUNT_DIFFERENCE Then
        EffectiveAutoCandidateAbsoluteTolerance = AUTO_CANDIDATE_MAX_AMOUNT_DIFFERENCE
    Else
        EffectiveAutoCandidateAbsoluteTolerance = configuredAbsoluteTolerance
    End If
End Function

Private Function EffectiveAutoCandidateRateTolerance( _
        ByVal configuredRateTolerance As Double) As Double
    If configuredRateTolerance <= 0# Then Exit Function
    If configuredRateTolerance > 10# Then
        EffectiveAutoCandidateRateTolerance = 10#
    Else
        EffectiveAutoCandidateRateTolerance = configuredRateTolerance
    End If
End Function

Public Function AutoCandidateEffectiveDayWindow(ByVal configuredDayWindow As Long) As Long
    '�������͏�ɋ֎~���A�ݒ�l��0�`3����͈̔͂����߂邱�Ƃ������ł���B
    If configuredDayWindow <= 0 Then Exit Function
    If configuredDayWindow > AUTO_CANDIDATE_MAX_CALENDAR_DAYS Then
        AutoCandidateEffectiveDayWindow = AUTO_CANDIDATE_MAX_CALENDAR_DAYS
    Else
        AutoCandidateEffectiveDayWindow = configuredDayWindow
    End If
End Function

Public Function AutoCandidateAmountGatePasses(ByVal withdrawalAmount As Double, _
                                               ByVal depositAmount As Double, _
                                               Optional ByVal configuredAbsoluteTolerance As Double = 1000000#, _
                                               Optional ByVal configuredRateTolerance As Double = 10#) As Boolean
    Const EPSILON As Double = 0.0000001
    Dim effectiveAbsoluteTolerance As Double, effectiveRateTolerance As Double
    Dim configuredMinimumRatio As Double, configuredMaximumRatio As Double
    If withdrawalAmount <= 0# Or depositAmount <= 0# Then Exit Function
    effectiveAbsoluteTolerance = _
        EffectiveAutoCandidateAbsoluteTolerance(configuredAbsoluteTolerance)
    effectiveRateTolerance = EffectiveAutoCandidateRateTolerance(configuredRateTolerance)
    configuredMinimumRatio = 1# - effectiveRateTolerance / 100#
    configuredMaximumRatio = 1# + effectiveRateTolerance / 100#
    If configuredMinimumRatio < AUTO_CANDIDATE_MIN_DEPOSIT_RATIO Then _
        configuredMinimumRatio = AUTO_CANDIDATE_MIN_DEPOSIT_RATIO
    If configuredMaximumRatio > AUTO_CANDIDATE_MAX_DEPOSIT_RATIO Then _
        configuredMaximumRatio = AUTO_CANDIDATE_MAX_DEPOSIT_RATIO

    '�ݒ�l�͌���ς݃n�[�h�Q�[�g�����߂邱�Ƃ������ł��A�L���邱�Ƃ͂ł��Ȃ��B
    If depositAmount + EPSILON < withdrawalAmount * configuredMinimumRatio Then Exit Function
    If depositAmount - EPSILON > withdrawalAmount * configuredMaximumRatio Then Exit Function
    If Abs(depositAmount - withdrawalAmount) > effectiveAbsoluteTolerance + EPSILON Then _
        Exit Function
    AutoCandidateAmountGatePasses = True
End Function

Public Sub AutoCandidateAmountSearchBounds(ByVal withdrawalAmount As Double, _
                                            ByRef lowerDepositAmount As Double, _
                                            ByRef upperDepositAmount As Double, _
                                            Optional ByVal configuredAbsoluteTolerance As Double = 1000000#, _
                                            Optional ByVal configuredRateTolerance As Double = 10#)
    Dim rateLower As Double, rateUpper As Double
    Dim differenceLower As Double, differenceUpper As Double
    Dim effectiveAbsoluteTolerance As Double, effectiveRateTolerance As Double
    If withdrawalAmount <= 0# Then _
        Err.Raise vbObjectError + 5094, "AutoCandidateAmountSearchBounds", _
                  "�o���z��0�~���傫���K�v������܂��B"

    effectiveAbsoluteTolerance = _
        EffectiveAutoCandidateAbsoluteTolerance(configuredAbsoluteTolerance)
    effectiveRateTolerance = EffectiveAutoCandidateRateTolerance(configuredRateTolerance)
    rateLower = withdrawalAmount * (1# - effectiveRateTolerance / 100#)
    If rateLower < withdrawalAmount * AUTO_CANDIDATE_MIN_DEPOSIT_RATIO Then _
        rateLower = withdrawalAmount * AUTO_CANDIDATE_MIN_DEPOSIT_RATIO
    rateUpper = withdrawalAmount * (1# + effectiveRateTolerance / 100#)
    If rateUpper > withdrawalAmount * AUTO_CANDIDATE_MAX_DEPOSIT_RATIO Then _
        rateUpper = withdrawalAmount * AUTO_CANDIDATE_MAX_DEPOSIT_RATIO
    differenceLower = withdrawalAmount - effectiveAbsoluteTolerance
    differenceUpper = withdrawalAmount + effectiveAbsoluteTolerance
    If differenceLower < 0# Then differenceLower = 0#

    lowerDepositAmount = rateLower
    If differenceLower > lowerDepositAmount Then lowerDepositAmount = differenceLower
    upperDepositAmount = rateUpper
    If differenceUpper < upperDepositAmount Then upperDepositAmount = differenceUpper
End Sub

'�����z�����m�ŁA�Ή�����o���������z���z�񂩂�T������Ƃ��̋t���������͈́B
'�ŏI���莩�̂͏�� AutoCandidateAmountGatePasses(�o���z, �����z) �ōs���B
Public Sub AutoCandidateWithdrawalSearchBounds(ByVal depositAmount As Double, _
                                                ByRef lowerWithdrawalAmount As Double, _
                                                ByRef upperWithdrawalAmount As Double, _
                                                Optional ByVal configuredAbsoluteTolerance As Double = 1000000#, _
                                                Optional ByVal configuredRateTolerance As Double = 10#)
    Dim minimumRatio As Double, maximumRatio As Double
    Dim ratioLower As Double, ratioUpper As Double
    Dim differenceLower As Double, differenceUpper As Double
    Dim effectiveAbsoluteTolerance As Double, effectiveRateTolerance As Double
    If depositAmount <= 0# Then _
        Err.Raise vbObjectError + 5095, "AutoCandidateWithdrawalSearchBounds", _
                  "�����z��0�~���傫���K�v������܂��B"

    effectiveAbsoluteTolerance = _
        EffectiveAutoCandidateAbsoluteTolerance(configuredAbsoluteTolerance)
    effectiveRateTolerance = EffectiveAutoCandidateRateTolerance(configuredRateTolerance)
    minimumRatio = 1# - effectiveRateTolerance / 100#
    maximumRatio = 1# + effectiveRateTolerance / 100#
    If minimumRatio < AUTO_CANDIDATE_MIN_DEPOSIT_RATIO Then _
        minimumRatio = AUTO_CANDIDATE_MIN_DEPOSIT_RATIO
    If maximumRatio > AUTO_CANDIDATE_MAX_DEPOSIT_RATIO Then _
        maximumRatio = AUTO_CANDIDATE_MAX_DEPOSIT_RATIO
    ratioLower = depositAmount / maximumRatio
    ratioUpper = depositAmount / minimumRatio
    differenceLower = depositAmount - effectiveAbsoluteTolerance
    differenceUpper = depositAmount + effectiveAbsoluteTolerance
    If differenceLower < 0# Then differenceLower = 0#

    lowerWithdrawalAmount = ratioLower
    If differenceLower > lowerWithdrawalAmount Then lowerWithdrawalAmount = differenceLower
    upperWithdrawalAmount = ratioUpper
    If differenceUpper < upperWithdrawalAmount Then upperWithdrawalAmount = differenceUpper
End Sub

'1��1���܂ގ������̌`��_��B��������1:2�A2:1�A1:3�A3:1�A2:2�����ƂȂ�B
Public Function AutoCandidateGroupShapePasses(ByVal withdrawalCount As Long, _
                                               ByVal depositCount As Long) As Boolean
    If withdrawalCount < 1 Or depositCount < 1 Then Exit Function
    If withdrawalCount >= AUTO_CANDIDATE_MAX_GROUP_TRANSACTIONS Or _
       depositCount >= AUTO_CANDIDATE_MAX_GROUP_TRANSACTIONS Then Exit Function
    If withdrawalCount + depositCount > AUTO_CANDIDATE_MAX_GROUP_TRANSACTIONS Then _
        Exit Function
    AutoCandidateGroupShapePasses = True
End Function

'1��1���ł́A�o������0���ڂƂ��ē�������0�`3������ł��邱�ƁB
'�������͑�\���𐄒肹���A����S41�S�g�����Q�[�g�Ŕ��肷��B
Public Function AutoCandidateDepositDatePasses(ByVal withdrawalDateSerial As Long, _
                                                ByVal depositDateSerial As Long, _
                                                Optional ByVal configuredDayWindow As Long = 3) As Boolean
    Dim dayDifference As Long
    If withdrawalDateSerial <= 0 Or depositDateSerial <= 0 Then Exit Function
    dayDifference = depositDateSerial - withdrawalDateSerial
    AutoCandidateDepositDatePasses = _
        (dayDifference >= 0 And _
         dayDifference <= AutoCandidateEffectiveDayWindow(configuredDayWindow))
End Function

'�����̑S�o�����ƑS�������̒��ς��A�o������0���ڂƂ���0�`3������ł��邱�ƁB
'�[�_�����Ŕ���ł��邪�A�t�]�E�s���Ȓ[�_�͐���ŕ␳����fail closed�Ƃ���B
Public Function AutoCandidateBundleDatePasses(ByVal withdrawalMinDate As Long, _
                                               ByVal withdrawalMaxDate As Long, _
                                               ByVal depositMinDate As Long, _
                                               ByVal depositMaxDate As Long, _
                                               Optional ByVal configuredDayWindow As Long = 3) As Boolean
    Dim effectiveDayWindow As Long
    If withdrawalMinDate <= 0 Or withdrawalMaxDate <= 0 Or _
       depositMinDate <= 0 Or depositMaxDate <= 0 Then Exit Function
    If withdrawalMinDate > withdrawalMaxDate Or depositMinDate > depositMaxDate Then Exit Function
    effectiveDayWindow = AutoCandidateEffectiveDayWindow(configuredDayWindow)
    If depositMinDate < withdrawalMaxDate Then Exit Function
    If depositMaxDate - withdrawalMinDate > effectiveDayWindow Then Exit Function
    AutoCandidateBundleDatePasses = True
End Function

'���t�������ꍇ�A���������L�^����Ă���g�����͋L�^��̋t�]���m��ł���B
'������������͏��E�s���ŕ⊮�����A�������Ȃ����m����Ƃ��Ďc���B
Public Function AutoCandidatePairChronologyPasses( _
        ByVal withdrawalDateSerial As Long, ByVal withdrawalHasTime As Boolean, _
        ByVal withdrawalTimeFraction As Double, ByVal depositDateSerial As Long, _
        ByVal depositHasTime As Boolean, ByVal depositTimeFraction As Double) As Boolean
    Const TIME_EPSILON As Double = 0.000000001
    If withdrawalDateSerial <= 0 Or depositDateSerial <= 0 Then Exit Function
    If depositDateSerial < withdrawalDateSerial Then Exit Function
    If depositDateSerial > withdrawalDateSerial Then
        AutoCandidatePairChronologyPasses = True
        Exit Function
    End If
    If withdrawalHasTime And depositHasTime Then
        If withdrawalTimeFraction < 0# Or withdrawalTimeFraction >= 1# Or _
           depositTimeFraction < 0# Or depositTimeFraction >= 1# Then Exit Function
        If depositTimeFraction + TIME_EPSILON < withdrawalTimeFraction Then Exit Function
    End If
    AutoCandidatePairChronologyPasses = True
End Function

'�������̑S���Ɏ���������ꍇ�́A�Ō�̏o�����ŏ��̓������O�Ȃ�s�̗p�B
'�����̑S�o���~�����Ɋ��m�̋t�������Ȃ����Ƃ�[�_�Ŕ��肷��B
Public Function AutoCandidateBundleChronologyPasses( _
        ByVal withdrawalMaxDate As Long, ByVal withdrawalMaxStamp As Double, _
        ByVal withdrawalHasAllTimes As Boolean, ByVal depositMinDate As Long, _
        ByVal depositMinStamp As Double, ByVal depositHasAllTimes As Boolean) As Boolean
    Const TIME_EPSILON As Double = 0.000000001
    If withdrawalMaxDate <= 0 Or depositMinDate <= 0 Then Exit Function
    If depositMinDate < withdrawalMaxDate Then Exit Function
    If depositMinDate > withdrawalMaxDate Then
        AutoCandidateBundleChronologyPasses = True
        Exit Function
    End If
    If withdrawalHasAllTimes And depositHasAllTimes Then
        If depositMinStamp + TIME_EPSILON < withdrawalMaxStamp Then Exit Function
    End If
    AutoCandidateBundleChronologyPasses = True
End Function

Public Function AutoCandidateTimeEvidenceLabel(ByVal withdrawalHasTime As Boolean, _
                                                ByVal depositHasTime As Boolean, _
                                                ByVal sameCalendarDate As Boolean) As String
    If withdrawalHasTime And depositHasTime Then
        AutoCandidateTimeEvidenceLabel = "�����L�ڂ���"
    ElseIf sameCalendarDate Then
        AutoCandidateTimeEvidenceLabel = "�����L�ڂȂ��E�����������s��"
    Else
        AutoCandidateTimeEvidenceLabel = "�����L�ڂȂ�"
    End If
End Function

'�l��ID�Ɩ��`�l�́A�����������������̐��{�ƈ�v���Ă���K�v������B
Public Function AutoCandidatePersonIntegrityPasses(ByVal accountPersonID As String, _
                                                    ByVal transactionPersonID As String, _
                                                    ByVal accountPersonName As String, _
                                                    ByVal transactionPersonName As String) As Boolean
    Dim accountNameKey As String, transactionNameKey As String
    accountPersonID = CellText(accountPersonID)
    transactionPersonID = CellText(transactionPersonID)
    If Len(accountPersonID) = 0 Or Len(transactionPersonID) = 0 Then Exit Function
    If Not IsInternalIdValue(accountPersonID, "P") Or _
       Not IsInternalIdValue(transactionPersonID, "P") Then Exit Function
    If StrComp(accountPersonID, transactionPersonID, vbTextCompare) <> 0 Then Exit Function

    accountNameKey = NormalizePersonNameKey(CellText(accountPersonName))
    transactionNameKey = NormalizePersonNameKey(CellText(transactionPersonName))
    If Len(accountNameKey) = 0 Or Len(transactionNameKey) = 0 Then Exit Function
    If StrComp(accountNameKey, transactionNameKey, vbTextCompare) <> 0 Then Exit Function
    AutoCandidatePersonIntegrityPasses = True
End Function

Public Function AutoCandidateIsDifferentPerson(ByVal withdrawalPersonID As String, _
                                                ByVal depositPersonID As String) As Boolean
    withdrawalPersonID = CellText(withdrawalPersonID)
    depositPersonID = CellText(depositPersonID)
    If Not IsInternalIdValue(withdrawalPersonID, "P") Or _
       Not IsInternalIdValue(depositPersonID, "P") Then Exit Function
    AutoCandidateIsDifferentPerson = _
        (StrComp(withdrawalPersonID, depositPersonID, vbTextCompare) <> 0)
End Function

'�V�[�g�������������A����ς݋��E�������Œ肷��B
Public Function DecidedAnalysisPolicyRegressionTest() As Boolean
    Dim lowerAmount As Double, upperAmount As Double
    On Error GoTo Failed

    If AutoCandidateAmountGatePasses(1000000#, 100000#) Then Exit Function
    If Not AutoCandidateAmountGatePasses(1000000#, 900000#) Then Exit Function
    If Not AutoCandidateAmountGatePasses(1000000#, 1100000#) Then Exit Function
    If AutoCandidateAmountGatePasses(1000000#, 899999#) Then Exit Function
    If AutoCandidateAmountGatePasses(1000000#, 1100001#) Then Exit Function
    If Not AutoCandidateAmountGatePasses(20000000#, 19000000#) Then Exit Function
    If Not AutoCandidateAmountGatePasses(20000000#, 21000000#) Then Exit Function
    If AutoCandidateAmountGatePasses(20000000#, 18999999#) Then Exit Function
    If AutoCandidateAmountGatePasses(20000000#, 21000001#) Then Exit Function

    AutoCandidateAmountSearchBounds 20000000#, lowerAmount, upperAmount
    If Abs(lowerAmount - 19000000#) > 0.0000001 Then Exit Function
    If Abs(upperAmount - 21000000#) > 0.0000001 Then Exit Function
    AutoCandidateAmountSearchBounds 50000000#, lowerAmount, upperAmount
    If Abs(lowerAmount - 49000000#) > 0.0000001 Then Exit Function
    If Abs(upperAmount - 51000000#) > 0.0000001 Then Exit Function
    AutoCandidateAmountSearchBounds 1000000#, lowerAmount, upperAmount, 50000#, 5#
    If Abs(lowerAmount - 950000#) > 0.0000001 Then Exit Function
    If Abs(upperAmount - 1050000#) > 0.0000001 Then Exit Function
    If Not AutoCandidateAmountGatePasses(1000000#, 950000#, 50000#, 5#) Then Exit Function
    If Not AutoCandidateAmountGatePasses(1000000#, 1050000#, 50000#, 5#) Then Exit Function
    If AutoCandidateAmountGatePasses(1000000#, 900000#, 2000000#, 100#) = False Then _
        Exit Function
    If AutoCandidateAmountGatePasses(1000000#, 100000#, 2000000#, 100#) Then Exit Function
    If AutoCandidateAmountGatePasses(1000000#, 1100001#, 2000000#, 100#) Then Exit Function
    If AutoCandidateAmountGatePasses(20000000#, 18999999#, 2000000#, 100#) Then Exit Function
    If AutoCandidateAmountGatePasses(1000000#, 949999#, 50000#, 10#) Then Exit Function
    If AutoCandidateAmountGatePasses(1000000#, 949999#, 1000000#, 5#) Then Exit Function
    AutoCandidateWithdrawalSearchBounds 900000#, lowerAmount, upperAmount
    If Abs(lowerAmount - (900000# / 1.1)) > 0.0000001 Then Exit Function
    If Abs(upperAmount - 1000000#) > 0.0000001 Then Exit Function
    If Not AutoCandidateAmountGatePasses(upperAmount, 900000#) Then Exit Function
    AutoCandidateWithdrawalSearchBounds 1100000#, lowerAmount, upperAmount
    If Abs(lowerAmount - 1000000#) > 0.0000001 Then Exit Function
    If Abs(upperAmount - (1100000# / 0.9)) > 0.0000001 Then Exit Function
    If Not AutoCandidateAmountGatePasses(lowerAmount, 1100000#) Then Exit Function

    If Not AutoCandidateGroupShapePasses(1, 1) Then Exit Function
    If Not AutoCandidateGroupShapePasses(1, 2) Then Exit Function
    If Not AutoCandidateGroupShapePasses(2, 1) Then Exit Function
    If Not AutoCandidateGroupShapePasses(1, 3) Then Exit Function
    If Not AutoCandidateGroupShapePasses(3, 1) Then Exit Function
    If Not AutoCandidateGroupShapePasses(2, 2) Then Exit Function
    If AutoCandidateGroupShapePasses(1, 4) Then Exit Function
    If AutoCandidateGroupShapePasses(4, 1) Then Exit Function
    If AutoCandidateGroupShapePasses(2, 3) Then Exit Function
    If AutoCandidateGroupShapePasses(0, 1) Then Exit Function
    If AutoCandidateGroupShapePasses(2147483647, 1) Then Exit Function

    If Not AutoCandidateDepositDatePasses(46000, 46000) Then Exit Function
    If Not AutoCandidateDepositDatePasses(46000, 46003) Then Exit Function
    If AutoCandidateDepositDatePasses(46000, 45999) Then Exit Function
    If AutoCandidateDepositDatePasses(46000, 46004) Then Exit Function
    If AutoCandidateDepositDatePasses(46000, 46001, 0) Then Exit Function
    If Not AutoCandidateDepositDatePasses(46000, 46000, 0) Then Exit Function
    If Not AutoCandidateDepositDatePasses(46000, 46003, 365) Then Exit Function
    If AutoCandidateDepositDatePasses(46000, 46004, 365) Then Exit Function
    If Not AutoCandidateBundleDatePasses(46000, 46001, 46001, 46003) Then Exit Function
    If AutoCandidateBundleDatePasses(46000, 46001, 46000, 46003) Then Exit Function
    If AutoCandidateBundleDatePasses(46000, 46001, 46001, 46004) Then Exit Function
    If AutoCandidateBundleDatePasses(46001, 46000, 46001, 46003) Then Exit Function
    If AutoCandidateBundleDatePasses(46000, 46001, 46001, 46000) Then Exit Function
    If AutoCandidateBundleDatePasses(0, 46001, 46001, 46003) Then Exit Function

    If Not AutoCandidatePairChronologyPasses(46000, True, 0.5, _
                                              46000, True, 0.5001) Then Exit Function
    If Not AutoCandidatePairChronologyPasses(46000, True, 0.5, _
                                              46000, True, 0.5) Then Exit Function
    If AutoCandidatePairChronologyPasses(46000, True, 0.5, _
                                         46000, True, 0.49) Then Exit Function
    If Not AutoCandidatePairChronologyPasses(46000, False, 0#, _
                                              46000, True, 0.49) Then Exit Function
    If AutoCandidatePairChronologyPasses(46000, False, 0#, _
                                         45999, False, 0#) Then Exit Function
    If Not AutoCandidateBundleChronologyPasses(46000, 46000.5, True, _
                                                46000, 46000.6, True) Then Exit Function
    If AutoCandidateBundleChronologyPasses(46000, 46000.5, True, _
                                           46000, 46000.4, True) Then Exit Function
    If Not AutoCandidateBundleChronologyPasses(46000, 46000.5, False, _
                                                46000, 46000.4, True) Then Exit Function

    If StrComp(AutoCandidateTimeEvidenceLabel(False, False, True), _
               "�����L�ڂȂ��E�����������s��", vbBinaryCompare) <> 0 Then Exit Function
    If StrComp(AutoCandidateTimeEvidenceLabel(True, False, False), _
               "�����L�ڂȂ�", vbBinaryCompare) <> 0 Then Exit Function
    If StrComp(AutoCandidateTimeEvidenceLabel(True, True, True), _
               "�����L�ڂ���", vbBinaryCompare) <> 0 Then Exit Function

    If Not AutoCandidatePersonIntegrityPasses("P1", "P1", "�b", "�b") Then Exit Function
    If AutoCandidatePersonIntegrityPasses("", "P1", "�b", "�b") Then Exit Function
    If AutoCandidatePersonIntegrityPasses("P1", "", "�b", "�b") Then Exit Function
    If AutoCandidatePersonIntegrityPasses("P1", "P2", "�b", "�b") Then Exit Function
    If AutoCandidatePersonIntegrityPasses("P1", "P1", "�b", "��") Then Exit Function
    If Not AutoCandidateIsDifferentPerson("P1", "P2") Then Exit Function
    If AutoCandidateIsDifferentPerson("P1", "P1") Then Exit Function

    DecidedAnalysisPolicyRegressionTest = True
    Exit Function
Failed:
    DecidedAnalysisPolicyRegressionTest = False
End Function

Attribute VB_Name = "modCashAnalysisView"
Option Explicit

'��������\�ƕ��͌��ʂ𓯂���ʂɒu�����߂̗��p�Ҍ����r���[�B
'A:M�͏�ɒ�o�p�Ɠ����񏇂����A�o��(H)�Ɠ���(I)���΂ɍ��݂����Ȃ��B
'N:Z�͈���ID�A�i�荞�݁A�蓮�I���A��ʏ�Ԃ̂��߂̔�\����ł���B

Private Const VIEW_CATEGORY_TRANSFER As String = "�����ړ�"
Private Const VIEW_CATEGORY_UNKNOWN_WITHDRAW As String = "�s���o��"
Private Const VIEW_CATEGORY_UNKNOWN_DEPOSIT As String = "�s������"

Private Const VIEW_MODE_COMPONENT As String = "�\�����"
Private Const VIEW_MODE_RELATED As String = "�֘A���"
Private Const VIEW_MODE_ALL As String = "�S���"

Private Const VIEW_ROLE_WITHDRAW As String = "�o��"
Private Const VIEW_ROLE_DEPOSIT As String = "����"
Private Const VIEW_ROLE_BOTH As String = "�o���E����"
Private Const VIEW_PERSON_DIFFERENT As String = "�ʐl����"
Private Const VIEW_PERSON_SAME As String = "����l����"

Private Const VIEW_STATE_CATEGORY As String = "V1"
Private Const VIEW_STATE_GROUP_ID As String = "V2"
Private Const VIEW_STATE_RESULT_ROW As String = "V3"
Private Const VIEW_STATE_MODE As String = "V4"
Private Const VIEW_STATE_MANUAL As String = "V5"
Private Const VIEW_STATE_SELECTED_IDS As String = "V6"
Private Const VIEW_STATE_VERSION As String = "V7"
Private Const VIEW_STATE_PANEL_EXPANDED As String = "V8"
Private Const VIEW_STATE_CANDIDATE_REF As String = "V9"
Private Const VIEW_VERSION As String = "7"
Private Const VIEW_MEMO_MAX As Long = 1000
Private Const VIEW_SELECTED_IDS_MAX As Long = 32000

'A:M�̉��������łȂ��A�Œ�p�l���ƍŒ���̖��׍s�������Ɍ�����{����
'���݂�Excel�E�B���h�E�̃|�C���g���@���猈�߂�B�|�C���g�P�ʂŌv�Z���邽�߁A
'Windows��100%/125%�\�����ʂ�DPI�萔�Ő������Ȃ��B
Private Const VIEW_DESIGN_ZOOM As Long = 88
Private Const VIEW_MIN_ZOOM As Long = 80
Private Const VIEW_MIN_VISIBLE_DATA_ROWS As Long = 2
Private Const VIEW_DATA_ROW_HEIGHT As Double = 30#
Private Const VIEW_VERTICAL_CHROME_RESERVE_POINTS As Double = 135#

Private Type CashAnalysisViewSnapshot
    Captured As Boolean
    PanelData As Variant
    Data As Variant
    DataLastRow As Long
    Visibility As Long
    WasProtected As Boolean
    WorkCashVisibility As Long
    WorkCashWasProtected As Boolean
    ResultCaptured As Boolean
    ResultVisibility As Long
    ResultWasProtected As Boolean
    DetailCaptured As Boolean
    DetailVisibility As Long
    DetailWasProtected As Boolean
    EntryActiveSheetName As String
    EntryActiveCellAddress As String
    SelectionAddress As String
    WindowStateCaptured As Boolean
    FreezePanes As Boolean
    SplitRow As Long
    SplitColumn As Long
    ScrollRow As Long
    ScrollColumn As Long
    Zoom As Long
    WorkbookWasSaved As Boolean
End Type

Public Sub SetupCashAnalysisViewSheet(ByVal ws As Worksheet)
    Dim emptyCounts(1 To 3) As Long
    If ws Is Nothing Then Exit Sub
    ws.Unprotect Password:=TOOL_PASSWORD
    ResetWorksheet ws
    BuildCashAnalysisViewStructure ws
    SetRowValues ws.Cells(CASH_VIEW_HEADER_ROW, 1), CashAnalysisViewHeaders()
    FormatOutputHeader ws.Range(ws.Cells(CASH_VIEW_HEADER_ROW, 1), _
                                    ws.Cells(CASH_VIEW_HEADER_ROW, CASH_VIEW_LAST_COL))
    ws.Range(VIEW_STATE_CATEGORY).Value = VIEW_CATEGORY_TRANSFER
    ws.Range(VIEW_STATE_MODE).Value = VIEW_MODE_COMPONENT
    ws.Range(VIEW_STATE_MANUAL).Value = "0"
    ws.Range(VIEW_STATE_PANEL_EXPANDED).Value = "0"
    ws.Range(VIEW_STATE_CANDIDATE_REF).ClearContents
    ws.Range(VIEW_STATE_VERSION).Value = VIEW_VERSION
    FormatCashAnalysisViewLayout ws
    UpdateCategoryButtonCaptions ws, VIEW_CATEGORY_TRANSFER, emptyCounts
    ClearCashAnalysisCandidatePanel ws, VIEW_CATEGORY_TRANSFER, emptyCounts, 0, 0
    ProtectCashAnalysisViewSheet
End Sub

Public Function CashAnalysisViewHeaders() As Variant
    CashAnalysisViewHeaders = Array( _
        "��s��", "�x�X��", "����", "�Ȗ�", "�����ԍ�", "���t", "����", _
        "�o��", "����", "�戵�X", "�@��", "�E�v��", "�c��", _
        "����ID", "���ID", "�s���", "���͏�", _
        "�\���Ώ�", "��������", "�蓮�I��")
End Function

Public Function CashAnalysisViewVersion() As String
    '�ۑ��Z���ƃZ���t�`�F�b�N�������Œ�`���Q�Ƃ��A�萔�̓�d�Ǘ��������B
    CashAnalysisViewVersion = VIEW_VERSION
End Function

Private Sub CaptureCashAnalysisViewSnapshot( _
        ByVal ws As Worksheet, ByRef snapshot As CashAnalysisViewSnapshot)
    Const PANEL_ROWS As Long = 9
    Dim wsWorkCash As Worksheet, wsResult As Worksheet, wsDetail As Worksheet
    Dim panelRange As Range, dataRange As Range, formulaCell As Range
    Dim dataRows As Long
    If ws Is Nothing Then _
        Err.Raise vbObjectError + 5072, "CaptureCashAnalysisViewSnapshot", _
                  "��������\�̑ޔ�悪����܂���B"

    snapshot.Visibility = CLng(ws.Visible)
    snapshot.WasProtected = ws.ProtectContents
    snapshot.WorkbookWasSaved = ThisWorkbook.Saved
    Set wsWorkCash = GetSheet(SH_WORK_CASH)
    snapshot.WorkCashVisibility = CLng(wsWorkCash.Visible)
    snapshot.WorkCashWasProtected = wsWorkCash.ProtectContents
    If SheetExists(SH_ANALYSIS_RESULT) Then
        Set wsResult = GetSheet(SH_ANALYSIS_RESULT)
        snapshot.ResultVisibility = CLng(wsResult.Visible)
        snapshot.ResultWasProtected = wsResult.ProtectContents
        snapshot.ResultCaptured = True
    End If
    If SheetExists(SH_ANALYSIS_DETAIL) Then
        Set wsDetail = GetSheet(SH_ANALYSIS_DETAIL)
        snapshot.DetailVisibility = CLng(wsDetail.Visible)
        snapshot.DetailWasProtected = wsDetail.ProtectContents
        snapshot.DetailCaptured = True
    End If

    Set panelRange = ws.Range(ws.Cells(1, 1), _
                              ws.Cells(PANEL_ROWS, CASH_VIEW_INTERNAL_LAST_COL))
    If Not TryFindFirstFormulaCell(panelRange, formulaCell) Then _
        Err.Raise vbObjectError + 5073, "CaptureCashAnalysisViewSnapshot", _
                  "��������\�̃p�l�����������Ɏ��s���܂����B"
    If Not formulaCell Is Nothing Then _
        Err.Raise vbObjectError + 5073, "CaptureCashAnalysisViewSnapshot", _
                  "��������\�̃p�l���܂��͉�ʏ�Ԃɐ���������܂��B"
    snapshot.PanelData = panelRange.Value2
    If VariantMatrixContainsError( _
            snapshot.PanelData, PANEL_ROWS, CASH_VIEW_INTERNAL_LAST_COL) Or _
       Not RangeValue2MatchesMatrixStrict( _
               panelRange, snapshot.PanelData, PANEL_ROWS, _
               CASH_VIEW_INTERNAL_LAST_COL) Then _
        Err.Raise vbObjectError + 5074, "CaptureCashAnalysisViewSnapshot", _
                  "��������\�̃p�l���Ɖ�ʏ�Ԃ��^�܂Ō����ɑޔ��ł��܂���B"

    snapshot.DataLastRow = _
        LastDataRowInColumns(ws, 1, CASH_VIEW_INTERNAL_LAST_COL)
    If snapshot.DataLastRow < CASH_VIEW_HEADER_ROW Then _
        snapshot.DataLastRow = CASH_VIEW_HEADER_ROW
    dataRows = snapshot.DataLastRow - CASH_VIEW_HEADER_ROW + 1
    If dataRows - 1 > MAX_ANALYSIS_OUTPUT_ROWS Then _
        Err.Raise vbObjectError + 5075, "CaptureCashAnalysisViewSnapshot", _
                  "��������\���ޔ�����𒴂��Ă��܂��B"
    Set dataRange = ws.Range(ws.Cells(CASH_VIEW_HEADER_ROW, 1), _
                             ws.Cells(snapshot.DataLastRow, _
                                      CASH_VIEW_INTERNAL_LAST_COL))
    Set formulaCell = Nothing
    If Not TryFindFirstFormulaCell(dataRange, formulaCell) Then _
        Err.Raise vbObjectError + 5076, "CaptureCashAnalysisViewSnapshot", _
                  "��������\�̈ꗗ���������Ɏ��s���܂����B"
    If Not formulaCell Is Nothing Then _
        Err.Raise vbObjectError + 5076, "CaptureCashAnalysisViewSnapshot", _
                  "��������\�̈ꗗ�ɐ���������܂��B"
    snapshot.Data = dataRange.Value2
    If VariantMatrixContainsError( _
            snapshot.Data, dataRows, CASH_VIEW_INTERNAL_LAST_COL) Or _
       Not RangeValue2MatchesMatrixStrict( _
               dataRange, snapshot.Data, dataRows, _
               CASH_VIEW_INTERNAL_LAST_COL) Then _
        Err.Raise vbObjectError + 5077, "CaptureCashAnalysisViewSnapshot", _
                  "��������\�̈ꗗ���^�܂Ō����ɑޔ��ł��܂���B"

    If Not ActiveSheet Is Nothing Then
        If TypeName(ActiveSheet) = "Worksheet" Then
            snapshot.EntryActiveSheetName = ActiveSheet.Name
            If Not ActiveCell Is Nothing Then _
                snapshot.EntryActiveCellAddress = ActiveCell.Address(False, False)
            If TypeName(Selection) = "Range" Then _
                snapshot.SelectionAddress = Selection.Address(False, False)
            If Not ActiveWindow Is Nothing Then
                snapshot.FreezePanes = ActiveWindow.FreezePanes
                snapshot.SplitRow = CLng(ActiveWindow.SplitRow)
                snapshot.SplitColumn = CLng(ActiveWindow.SplitColumn)
                snapshot.ScrollRow = ActiveWindow.ScrollRow
                snapshot.ScrollColumn = ActiveWindow.ScrollColumn
                snapshot.Zoom = CLng(ActiveWindow.Zoom)
                snapshot.WindowStateCaptured = True
            End If
        End If
    End If
    snapshot.Captured = True
End Sub

Private Sub RestoreCashAnalysisViewSnapshot( _
        ByVal ws As Worksheet, ByRef snapshot As CashAnalysisViewSnapshot)
    Const PANEL_ROWS As Long = 9
    Dim dataRange As Range, panelRange As Range
    Dim dataRows As Long, currentLastRow As Long, clearLastRow As Long
    If ws Is Nothing Or Not snapshot.Captured Then _
        Err.Raise vbObjectError + 5078, "RestoreCashAnalysisViewSnapshot", _
                  "��������\�̑ޔ���񂪂���܂���B"

    ws.Unprotect Password:=TOOL_PASSWORD
    ResetWorksheet ws
    BuildCashAnalysisViewStructure ws
    ws.Range("A" & CStr(CASH_VIEW_HEADER_ROW) & ":E" & _
             CStr(snapshot.DataLastRow)).NumberFormatLocal = "@"
    ws.Range("J" & CStr(CASH_VIEW_HEADER_ROW) & ":L" & _
             CStr(snapshot.DataLastRow)).NumberFormatLocal = "@"
    ws.Range("N" & CStr(CASH_VIEW_HEADER_ROW) & ":Z" & _
             CStr(snapshot.DataLastRow)).NumberFormatLocal = "@"
    Set dataRange = ws.Range(ws.Cells(CASH_VIEW_HEADER_ROW, 1), _
                             ws.Cells(snapshot.DataLastRow, _
                                      CASH_VIEW_INTERNAL_LAST_COL))
    dataRange.Value2 = snapshot.Data
    RestoreCashAnalysisPanelSnapshotValues ws, snapshot.PanelData
    FormatCashAnalysisViewLayout ws

    '��ʏ�Ԃ���t�B���^�[�E�}�`�L���v�V�����E���͋K�����č\������B
    RefreshCashAnalysisPanel False
    ws.Unprotect Password:=TOOL_PASSWORD
    dataRange.Value2 = snapshot.Data
    RestoreCashAnalysisPanelSnapshotValues ws, snapshot.PanelData
    AdjustCashAnalysisPanelRowHeights ws
    ApplyCashAnalysisPanelValidation ws
    UpdateCashAnalysisStatusStyle ws

    dataRows = snapshot.DataLastRow - CASH_VIEW_HEADER_ROW + 1
    If Not RangeValue2MatchesMatrixStrict( _
               dataRange, snapshot.Data, dataRows, _
               CASH_VIEW_INTERNAL_LAST_COL) Then _
        Err.Raise vbObjectError + 5079, "RestoreCashAnalysisViewSnapshot", _
                  "��������\�̈ꗗ���^�܂Ō����ɕ����ł��܂���B"
    Set panelRange = ws.Range(ws.Cells(1, 1), _
                              ws.Cells(PANEL_ROWS, CASH_VIEW_INTERNAL_LAST_COL))
    If Not RangeValue2MatchesMatrixStrict( _
               panelRange, snapshot.PanelData, PANEL_ROWS, _
               CASH_VIEW_INTERNAL_LAST_COL) Then _
        Err.Raise vbObjectError + 5080, "RestoreCashAnalysisViewSnapshot", _
                  "��������\�̃p�l���܂��͉�ʏ�Ԃ������ɕ����ł��܂���B"
    currentLastRow = LastDataRowInColumns(ws, 1, CASH_VIEW_INTERNAL_LAST_COL)
    clearLastRow = CLng(Application.Max(currentLastRow, snapshot.DataLastRow))
    If currentLastRow <> snapshot.DataLastRow Then _
        Err.Raise vbObjectError + 5081, "RestoreCashAnalysisViewSnapshot", _
                  "��������\�̕����s������v���܂���B"
    If clearLastRow > snapshot.DataLastRow Then _
        Err.Raise vbObjectError + 5081, "RestoreCashAnalysisViewSnapshot", _
                  "��������\�̑ޔ�͈͊O�ɒl���c���Ă��܂��B"

    RestoreCashAnalysisEntryView snapshot
    RestoreCashAnalysisSnapshotSurfaces ws, snapshot
    If snapshot.WorkbookWasSaved Then ThisWorkbook.Saved = True
End Sub

Private Sub RestoreCashAnalysisPanelSnapshotValues( _
        ByVal ws As Worksheet, ByRef panelSnapshot As Variant)
    Const PANEL_ROWS As Long = 9
    Dim r As Long, c As Long
    Dim target As Range, topLeft As Range
    For r = 1 To PANEL_ROWS
        For c = 1 To CASH_VIEW_INTERNAL_LAST_COL
            Set target = ws.Cells(r, c)
            If target.MergeCells Then
                Set topLeft = target.MergeArea.Cells(1, 1)
                If target.Address = topLeft.Address Then _
                    topLeft.Value2 = panelSnapshot(r, c)
            Else
                target.Value2 = panelSnapshot(r, c)
            End If
        Next c
    Next r
End Sub

Private Sub RestoreCashAnalysisSnapshotSurfaces( _
        ByVal ws As Worksheet, ByRef snapshot As CashAnalysisViewSnapshot)
    Dim wsItem As Worksheet
    If snapshot.WasProtected Then
        ProtectCashAnalysisViewSheet
    Else
        ws.Unprotect Password:=TOOL_PASSWORD
    End If
    ws.Visible = snapshot.Visibility
    If ws.ProtectContents <> snapshot.WasProtected Or _
       CLng(ws.Visible) <> snapshot.Visibility Then _
        Err.Raise vbObjectError + 5082, "RestoreCashAnalysisSnapshotSurfaces", _
                  "��������\�̕ی�܂��͕\����Ԃ𕜌��ł��܂���B"

    Set wsItem = GetSheet(SH_WORK_CASH)
    RestoreCashAnalysisOneSurface wsItem, snapshot.WorkCashVisibility, _
                                  snapshot.WorkCashWasProtected, False
    If snapshot.ResultCaptured Then
        Set wsItem = GetSheet(SH_ANALYSIS_RESULT)
        RestoreCashAnalysisOneSurface wsItem, snapshot.ResultVisibility, _
                                      snapshot.ResultWasProtected, True
    End If
    If snapshot.DetailCaptured Then
        Set wsItem = GetSheet(SH_ANALYSIS_DETAIL)
        RestoreCashAnalysisOneSurface wsItem, snapshot.DetailVisibility, _
                                      snapshot.DetailWasProtected, True
    End If
End Sub

Private Sub RestoreCashAnalysisOneSurface( _
        ByVal ws As Worksheet, ByVal visibilityState As Long, _
        ByVal protectedState As Boolean, ByVal analysisSheet As Boolean)
    If ws Is Nothing Then _
        Err.Raise vbObjectError + 5083, "RestoreCashAnalysisOneSurface", _
                  "�\���E�ی�𕜌�����V�[�g������܂���B"
    If protectedState Then
        If analysisSheet Then
            ProtectSingleAnalysisSheet ws
        Else
            ProtectGeneratedOutputSheet ws, True
        End If
    Else
        ws.Unprotect Password:=TOOL_PASSWORD
    End If
    ws.Visible = visibilityState
    If ws.ProtectContents <> protectedState Or _
       CLng(ws.Visible) <> visibilityState Then _
        Err.Raise vbObjectError + 5084, "RestoreCashAnalysisOneSurface", _
                  "�\���܂��͕ی��Ԃ𕜌��ł��܂���: " & ws.Name
End Sub

Private Sub RestoreCashAnalysisEntryView( _
        ByRef snapshot As CashAnalysisViewSnapshot)
    Dim ws As Worksheet, restoredAddress As String
    If Len(snapshot.EntryActiveSheetName) = 0 Then Exit Sub
    If Not SheetExists(snapshot.EntryActiveSheetName) Then _
        Err.Raise vbObjectError + 5085, "RestoreCashAnalysisEntryView", _
                  "����J�n���̃V�[�g��������܂���B"
    Set ws = GetSheet(snapshot.EntryActiveSheetName)
    If ws.Visible <> xlSheetVisible Then ws.Visible = xlSheetVisible
    If ws.Visible <> xlSheetVisible Then _
        Err.Raise vbObjectError + 5086, "RestoreCashAnalysisEntryView", _
                  "����J�n���̃V�[�g���\����Ԃł͂���܂���B"
    ws.Activate
    If snapshot.WindowStateCaptured Then
        If ActiveWindow Is Nothing Then _
            Err.Raise vbObjectError + 5087, "RestoreCashAnalysisEntryView", _
                      "����J�n���̃E�B���h�E�𕜌��ł��܂���B"
        ActiveWindow.FreezePanes = False
        ActiveWindow.SplitRow = snapshot.SplitRow
        ActiveWindow.SplitColumn = snapshot.SplitColumn
        ActiveWindow.FreezePanes = snapshot.FreezePanes
        ActiveWindow.Zoom = snapshot.Zoom
        ActiveWindow.ScrollRow = snapshot.ScrollRow
        ActiveWindow.ScrollColumn = snapshot.ScrollColumn
        If ActiveWindow.FreezePanes <> snapshot.FreezePanes Or _
           CLng(ActiveWindow.SplitRow) <> snapshot.SplitRow Or _
           CLng(ActiveWindow.SplitColumn) <> snapshot.SplitColumn Or _
           ActiveWindow.Zoom <> snapshot.Zoom Or _
           ActiveWindow.ScrollRow <> snapshot.ScrollRow Or _
           ActiveWindow.ScrollColumn <> snapshot.ScrollColumn Then _
            Err.Raise vbObjectError + 5088, "RestoreCashAnalysisEntryView", _
                      "����J�n���̌Œ�E�{���E�X�N���[���ʒu����v���܂���B"
    End If
    If Len(snapshot.SelectionAddress) > 0 Then
        ws.Range(snapshot.SelectionAddress).Select
        If TypeName(Selection) <> "Range" Then _
            Err.Raise vbObjectError + 5089, "RestoreCashAnalysisEntryView", _
                      "����J�n���̑I��͈͂𕜌��ł��܂���B"
        restoredAddress = Selection.Address(False, False)
        If StrComp(restoredAddress, snapshot.SelectionAddress, _
                   vbBinaryCompare) <> 0 Then _
            Err.Raise vbObjectError + 5089, "RestoreCashAnalysisEntryView", _
                      "����J�n���̑I��͈͂���v���܂���B"
    ElseIf Len(snapshot.EntryActiveCellAddress) > 0 Then
        ws.Range(snapshot.EntryActiveCellAddress).Select
    End If
    If StrComp(ActiveSheet.Name, snapshot.EntryActiveSheetName, _
               vbBinaryCompare) <> 0 Then _
        Err.Raise vbObjectError + 5090, "RestoreCashAnalysisEntryView", _
                  "����J�n���̃A�N�e�B�u�V�[�g�𕜌��ł��܂���B"
End Sub

Private Sub AppendCashAnalysisRollbackDetail( _
        ByRef detailText As String, ByVal addedText As String)
    If Len(Trim$(addedText)) = 0 Then Exit Sub
    If Len(detailText) > 0 Then detailText = detailText & " / "
    detailText = detailText & addedText
End Sub

Private Function TryGetCashAnalysisEnableEvents( _
        ByRef currentValue As Boolean, _
        ByRef detailText As String) As Boolean
    Dim errorNumber As Long, errorSource As String, errorDescription As String
    detailText = vbNullString
    On Error GoTo EH
    currentValue = Application.EnableEvents
    TryGetCashAnalysisEnableEvents = True
    Exit Function
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    detailText = "Err " & CStr(errorNumber) & ": " & errorDescription
    Err.Clear
End Function

Private Function TrySetCashAnalysisEnableEventsExact( _
        ByVal desiredValue As Boolean, _
        ByRef detailText As String) As Boolean
    Dim errorNumber As Long, errorSource As String, errorDescription As String
    detailText = vbNullString
    On Error GoTo EH
    Application.EnableEvents = desiredValue
    If Application.EnableEvents <> desiredValue Then _
        Err.Raise vbObjectError + 5094, _
                  "TrySetCashAnalysisEnableEventsExact", _
                  "EnableEvents�̏����݌�ǖ߂�����v���܂���B"
    TrySetCashAnalysisEnableEventsExact = True
    Exit Function
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    detailText = "Err " & CStr(errorNumber) & ": " & errorDescription
    Err.Clear
End Function

Private Function TryRestoreCashAnalysisEnableEvents( _
        ByVal previousValue As Boolean, _
        ByVal operationName As String, _
        ByRef detailText As String) As Boolean
    Dim firstDetail As String, retryDetail As String
    Dim stopDetail As String, stopRetryDetail As String
    Dim safeStopDetail As String
    Dim eventsStoppedForRecovery As Boolean
    Dim recoveryEnforcementFailed As Boolean
    Dim recoveryConfirmedThisAttempt As Boolean
    Dim recoveryAttempted As Boolean
    detailText = vbNullString
    If TrySetCashAnalysisEnableEventsExact(previousValue, firstDetail) Then
        TryRestoreCashAnalysisEnableEvents = True
        Exit Function
    End If
    If TrySetCashAnalysisEnableEventsExact(previousValue, retryDetail) Then
        TryRestoreCashAnalysisEnableEvents = True
        Exit Function
    End If
    detailText = "Excel�C�x���g��Ԃ��J�n�l�֕����ł��܂���ł����B����=" & _
                 firstDetail & " / �Ď��s=" & retryDetail
    eventsStoppedForRecovery = _
        TrySetCashAnalysisEnableEventsExact(False, stopDetail)
    If Not eventsStoppedForRecovery Then _
        eventsStoppedForRecovery = _
            TrySetCashAnalysisEnableEventsExact(False, stopRetryDetail)
    StopAfterCashAnalysisEventStateFailure _
        operationName, detailText, eventsStoppedForRecovery, True, _
        "����=" & stopDetail & " / �Ď��s=" & stopRetryDetail, _
        recoveryEnforcementFailed, recoveryConfirmedThisAttempt, _
        recoveryAttempted
    If recoveryAttempted Then _
        Err.Raise vbObjectError + 5194, _
                  "CashAnalysisRecoveryFatal/TryRestoreCashAnalysisEnableEvents", _
                  detailText
    eventsStoppedForRecovery = _
        TryStopCashAnalysisEventsForRecovery(safeStopDetail)
End Function

Private Sub StopAfterCashAnalysisEventStateFailure( _
        ByVal operationName As String, _
        ByRef detailText As String, _
        ByRef eventsStoppedForRecovery As Boolean, _
        ByVal stopGateAlreadyAttempted As Boolean, _
        ByVal attemptedStopDetail As String, _
        Optional ByRef recoveryEnforcementFailed As Boolean = False, _
        Optional ByRef recoveryConfirmedThisAttempt As Boolean = False, _
        Optional ByRef recoveryAttempted As Boolean = False)
    Dim recoveryDetail As String, stopDetail As String
    Dim postEnforceStopDetail As String, finalStopDetail As String
    Dim recoveryErrorNumber As Long, recoveryErrorDescription As String
    Dim recoveryConfirmed As Boolean
    Dim applicationStateConfirmed As Boolean
    If recoveryAttempted Then
        eventsStoppedForRecovery = _
            TryStopCashAnalysisEventsForRecovery(finalStopDetail)
        AppendCashAnalysisRollbackDetail detailText, _
            "���̏�ʏ����ł�Recovery�ݒ�����Ɏ��s�ς݂̂��߁A" & _
            "��d���s���s���܂���B"
        Err.Raise vbObjectError + 5194, _
                  "CashAnalysisRecoveryFatal/StopAfterCashAnalysisEventStateFailure", _
                  detailText
    End If
    recoveryEnforcementFailed = False
    recoveryConfirmedThisAttempt = False
    recoveryDetail = operationName & ": " & detailText
    If stopGateAlreadyAttempted Then
        stopDetail = attemptedStopDetail
    Else
        eventsStoppedForRecovery = _
            TryStopCashAnalysisEventsForRecovery(stopDetail)
    End If
    If Not eventsStoppedForRecovery Then
        AppendCashAnalysisRollbackDetail recoveryDetail, _
            "�v�����L�^�O��Excel�C�x���g��~���m�F�ł����A" & _
            "�u�b�N�ւ�Recovery�E�`�F�b�N�E��ԏ����݂�" & _
            "���S�̂��ߌ�����܂����B���݂̃C�x���g��Ԃ͕s���ł�: " & _
            stopDetail
        detailText = recoveryDetail
        Exit Sub
    End If
    AppendCashAnalysisRollbackDetail recoveryDetail, _
        "�v�����L�^�O��Excel�C�x���g��~��ǖ߂��m�F���܂����B"
    recoveryAttempted = True
    On Error Resume Next
    Err.Clear
    EnforceRollbackRecoveryState recoveryDetail
    recoveryErrorNumber = Err.Number
    recoveryErrorDescription = Err.Description
    Err.Clear
    On Error GoTo 0
    eventsStoppedForRecovery = _
        TryStopCashAnalysisEventsForRecovery(postEnforceStopDetail)
    If recoveryErrorNumber <> 0 Then
        recoveryEnforcementFailed = True
        AppendCashAnalysisRollbackDetail recoveryDetail, _
            "�v������Ԃ̋����ݒ�G���[: Err " & _
            CStr(recoveryErrorNumber) & " " & recoveryErrorDescription
        AppendCashAnalysisRollbackDetail recoveryDetail, _
            "Recovery�����ݒ�ŃG���[�����o�������߁A" & _
            "������Ԃ̏ƍ��E�`�F�b�N�E��ԏ����݂��s���܂���ł����B"
        If Not eventsStoppedForRecovery Then _
            AppendCashAnalysisRollbackDetail recoveryDetail, _
                "Recovery�����ݒ���Excel�C�x���g��~���m�F�ł����A" & _
                "���ݏ�Ԃ͕s���ł�: " & postEnforceStopDetail
        eventsStoppedForRecovery = False
        detailText = recoveryDetail
        Err.Raise vbObjectError + 5194, _
                  "CashAnalysisRecoveryFatal/StopAfterCashAnalysisEventStateFailure", _
                  detailText
    End If
    If Not eventsStoppedForRecovery Then
        AppendCashAnalysisRollbackDetail recoveryDetail, _
            "Recovery�����ݒ���Excel�C�x���g��~���m�F�ł����A" & _
            "������Ԃ̏ƍ��E�`�F�b�N�E��ԏ����݂��s���܂���ł����B" & _
            "���ݏ�Ԃ͕s���ł�: " & postEnforceStopDetail
        detailText = recoveryDetail
        Err.Raise vbObjectError + 5194, _
                  "CashAnalysisRecoveryFatal/StopAfterCashAnalysisEventStateFailure", _
                  detailText
    End If
    recoveryConfirmed = _
        CashAnalysisRecoveryStateIsConfirmedExact(recoveryDetail)
    recoveryConfirmedThisAttempt = recoveryConfirmed
    If Not recoveryConfirmed Then
        AppendCashAnalysisRollbackDetail recoveryDetail, _
            "�v������Ԃ������m�F�ł��܂���B"
        eventsStoppedForRecovery = _
            TryStopCashAnalysisEventsForRecovery(finalStopDetail)
        eventsStoppedForRecovery = False
        detailText = recoveryDetail
        Err.Raise vbObjectError + 5194, _
                  "CashAnalysisRecoveryFatal/StopAfterCashAnalysisEventStateFailure", _
                  detailText
    End If
    applicationStateConfirmed = _
        CashAnalysisApplicationStateAllowsEntryRestore( _
            True, recoveryDetail)
    If Not applicationStateConfirmed Then
        eventsStoppedForRecovery = _
            TryStopCashAnalysisEventsForRecovery(finalStopDetail)
        AppendCashAnalysisRollbackDetail recoveryDetail, _
            "Application��Ԃ��m�F�ł��܂���B"
        detailText = recoveryDetail
        Err.Raise vbObjectError + 5194, _
                  "CashAnalysisRecoveryFatal/StopAfterCashAnalysisEventStateFailure", _
                  detailText
    End If
    eventsStoppedForRecovery = _
        TryStopCashAnalysisEventsForRecovery(finalStopDetail)
    If Not eventsStoppedForRecovery Then
        AppendCashAnalysisRollbackDetail recoveryDetail, _
            "Application��Ԋm�F���Excel�C�x���gFalse������" & _
            "�m�F�ł��܂���B���ݏ�Ԃ͕s���ł�: " & finalStopDetail
        detailText = recoveryDetail
        Err.Raise vbObjectError + 5194, _
                  "CashAnalysisRecoveryFatal/StopAfterCashAnalysisEventStateFailure", _
                  detailText
    End If
    detailText = recoveryDetail
    Err.Raise vbObjectError + 5194, _
              "CashAnalysisRecoveryFatal/StopAfterCashAnalysisEventStateFailure", _
              detailText
End Sub

Private Function TryStopCashAnalysisEventsForRecovery( _
        ByRef detailText As String) As Boolean
    Dim firstDetail As String, retryDetail As String
    detailText = vbNullString
    If TrySetCashAnalysisEnableEventsExact(False, firstDetail) Then
        TryStopCashAnalysisEventsForRecovery = True
        Exit Function
    End If
    If TrySetCashAnalysisEnableEventsExact(False, retryDetail) Then
        TryStopCashAnalysisEventsForRecovery = True
        Exit Function
    End If
    detailText = "����=" & firstDetail & " / �Ď��s=" & retryDetail
End Function

Private Function CashAnalysisRecoveryStateIsConfirmedExact( _
        ByRef detailText As String) As Boolean
    Dim latchIsSet As Boolean, latchReadSucceeded As Boolean
    Dim healthValue As String, healthReadSucceeded As Boolean
    latchReadSucceeded = TryGetRollbackRecoveryLatch(latchIsSet)
    healthReadSucceeded = _
        TryGetExactStateValue(STATE_DATA_HEALTH, healthValue)
    CashAnalysisRecoveryStateIsConfirmedExact = _
        latchReadSucceeded And latchIsSet And healthReadSucceeded And _
        (StrComp(healthValue, DATA_HEALTH_NEEDS_RECOVERY, _
                 vbBinaryCompare) = 0)
    If CashAnalysisRecoveryStateIsConfirmedExact Then Exit Function
    If Not latchReadSucceeded Or Not latchIsSet Then _
        AppendCashAnalysisRollbackDetail detailText, _
            "�Ɨ��������b�`��ݒ�ς݂Ƃ��Ĉ�ӂɊm�F�ł��܂���B"
    If Not healthReadSucceeded Or _
       StrComp(healthValue, DATA_HEALTH_NEEDS_RECOVERY, _
               vbBinaryCompare) <> 0 Then _
        AppendCashAnalysisRollbackDetail detailText, _
            "�Č���health=�v��������ӂɊm�F�ł��܂���B"
End Function

Private Function TryProtectCashAnalysisViewAfterFailure( _
        ByVal ws As Worksheet, _
        ByVal operationName As String, _
        ByVal emergencyOnly As Boolean, _
        ByRef detailText As String, _
        Optional ByRef recoveryAttempted As Boolean = False, _
        Optional ByRef recoveryEnforcementFailed As Boolean = False, _
        Optional ByRef recoveryConfirmedThisAttempt As Boolean = False) As Boolean
    Dim protectErrorNumber As Long, recoveryErrorNumber As Long
    Dim protectErrorSource As String
    Dim protectErrorDescription As String, recoveryErrorDescription As String
    Dim recoveryDetail As String, protectionLabel As String
    Dim entryEvents As Boolean, eventsCaptured As Boolean
    Dim eventsReady As Boolean, protectSucceeded As Boolean
    Dim recoveryConfirmed As Boolean, safeToRestoreEntry As Boolean
    Dim eventDetail As String, restoreDetail As String
    Dim postProtectStopDetail As String, postEnforceStopDetail As String
    Dim convergenceDetail As String, policyDetail As String
    Dim finalRecoveryStopDetail As String

    If recoveryAttempted Then
        eventsReady = _
            TryStopCashAnalysisEventsForRecovery(convergenceDetail)
        AppendCashAnalysisRollbackDetail detailText, _
            operationName & ": ���̏�ʏ����ł�Recovery�ݒ������" & _
            "���s�ς݂̂��߁A��d���s���s���܂���B"
        Err.Raise vbObjectError + 5194, _
                  "CashAnalysisRecoveryFatal/TryProtectCashAnalysisViewAfterFailure", _
                  detailText
    End If
    recoveryEnforcementFailed = False
    recoveryConfirmedThisAttempt = False

    If Not TryGetCashAnalysisEnableEvents(entryEvents, eventDetail) Then
        AppendCashAnalysisRollbackDetail detailText, _
            operationName & ": Excel�C�x���g�̊J�n��Ԃ��擾�ł����A" & _
            "�ĕی��Recovery�����݂��s���܂���ł����B " & eventDetail
        Exit Function
    End If
    eventsCaptured = True
    eventsReady = TryStopCashAnalysisEventsForRecovery(eventDetail)
    If Not eventsReady Then
        AppendCashAnalysisRollbackDetail detailText, _
            operationName & ": Excel�C�x���g��~���m�F�ł����A" & _
            "�ĕی��Recovery�����݂��s���܂���ł����B " & eventDetail
        GoTo CleanExit
    End If
    If emergencyOnly Then
        protectionLabel = "�ً}�ĕی�"
    Else
        protectionLabel = "�ĕی�"
    End If
    If ws Is Nothing Then
        On Error Resume Next
        Err.Clear
        Set ws = GetSheet(SH_OUTPUT_TX)
        protectErrorNumber = Err.Number
        protectErrorSource = Err.Source
        protectErrorDescription = Err.Description
        Err.Clear
        On Error GoTo 0
        If ws Is Nothing And protectErrorNumber = 0 Then
            protectErrorNumber = vbObjectError + 5105
            protectErrorDescription = "��������\���擾�ł��܂���B"
        End If
    End If
    If protectErrorNumber = 0 Then
        On Error Resume Next
        Err.Clear
        If emergencyOnly Then
            EmergencyProtectToolSheet ws
        Else
            ProtectCashAnalysisViewSheet
        End If
        protectErrorNumber = Err.Number
        protectErrorSource = Err.Source
        protectErrorDescription = Err.Description
        Err.Clear
        On Error GoTo 0
    End If
    '����q�̕ی쏈����terminal��Ԃ����ꍇ�A����Err triple��ύX�����A
    'fresh��False exact�����������Ē����ɏ�ʂ֓`�d����B
    If IsCashAnalysisRecoveryFatal( _
           protectErrorNumber, protectErrorSource) Then
        Call TryStopCashAnalysisEventsForRecovery(convergenceDetail)
        Err.Raise protectErrorNumber, protectErrorSource, _
                  protectErrorDescription
    End If
    eventsReady = _
        TryStopCashAnalysisEventsForRecovery(postProtectStopDetail)
    If Not eventsReady Then
        AppendCashAnalysisRollbackDetail detailText, _
            operationName & ": �ĕی���Excel�C�x���g��~���m�F�ł��܂���B" & _
            "���ݏ�Ԃ͕s���ł�: " & postProtectStopDetail
        GoTo CleanExit
    End If
    policyDetail = vbNullString
    protectSucceeded = _
        CashAnalysisProtectionPolicyIsConfirmedExact(ws, policyDetail)
    If Not protectSucceeded Then _
        AppendCashAnalysisRollbackDetail detailText, _
            operationName & ": �ĕی��̎��ی�|���V�[���m�F�ł��܂���B " & _
            policyDetail
    If protectErrorNumber <> 0 Then _
        AppendCashAnalysisRollbackDetail detailText, _
            operationName & "��" & protectionLabel & "�G���[: Err " & _
            CStr(protectErrorNumber) & " " & protectErrorDescription
    If protectSucceeded Then
        protectSucceeded = True
        safeToRestoreEntry = _
            CashAnalysisApplicationStateAllowsEntryRestore( _
                entryEvents, detailText)
        TryProtectCashAnalysisViewAfterFailure = True
        GoTo CleanExit
    End If

    recoveryDetail = detailText
    recoveryAttempted = True
    On Error Resume Next
    Err.Clear
    EnforceRollbackRecoveryState recoveryDetail
    recoveryErrorNumber = Err.Number
    recoveryErrorDescription = Err.Description
    Err.Clear
    On Error GoTo 0
    'Enforce�̗�O�l��ۑ����������False���Ċm�肷��B��O�I���Ȃ�A
    '�ȑO����c��Recovery�l�����񐬌��̍����ɂ͈�؎g��Ȃ��B
    eventsReady = _
        TryStopCashAnalysisEventsForRecovery(postEnforceStopDetail)
    detailText = recoveryDetail
    If recoveryErrorNumber <> 0 Then _
        AppendCashAnalysisRollbackDetail detailText, _
            "�v������Ԃ̋����ݒ�G���[: Err " & _
            CStr(recoveryErrorNumber) & " " & recoveryErrorDescription
    If recoveryErrorNumber <> 0 Then
        recoveryEnforcementFailed = True
        AppendCashAnalysisRollbackDetail detailText, _
            "Recovery��������O�I���������߁A������Ԃ�ǂݎ�炸�A" & _
            "�J�n���C�x���g�l�ւ��߂��܂���B"
        safeToRestoreEntry = False
    ElseIf eventsReady Then
        recoveryConfirmed = _
            CashAnalysisRecoveryStateIsConfirmedExact(detailText)
        recoveryConfirmedThisAttempt = recoveryConfirmed
        If Not recoveryConfirmed Then _
            AppendCashAnalysisRollbackDetail detailText, _
                "�v�����Ƃ��Ă̒�~�����͊m�F�ł��܂���B"
    Else
        AppendCashAnalysisRollbackDetail detailText, _
            "Recovery�������Excel�C�x���g��~���m�F�ł��Ȃ����߁A" & _
            "������Ԃ�ǂݎ��܂���ł����B���ݏ�Ԃ͕s���ł�: " & _
            postEnforceStopDetail
    End If
    If recoveryErrorNumber = 0 And eventsReady And recoveryConfirmed Then
        safeToRestoreEntry = _
            CashAnalysisApplicationStateAllowsEntryRestore( _
                True, detailText)
        If safeToRestoreEntry Then
            eventsReady = _
                TryStopCashAnalysisEventsForRecovery( _
                    finalRecoveryStopDetail)
            If Not eventsReady Then _
                AppendCashAnalysisRollbackDetail detailText, _
                    "Application��Ԋm�F���Excel�C�x���gFalse������" & _
                    "�m�F�ł��܂���: " & finalRecoveryStopDetail
        End If
        safeToRestoreEntry = False
    End If
    eventsReady = _
        TryStopCashAnalysisEventsForRecovery(convergenceDetail)
    Err.Raise vbObjectError + 5194, _
              "CashAnalysisRecoveryFatal/TryProtectCashAnalysisViewAfterFailure", _
              detailText
CleanExit:
    If eventsCaptured Then
        If safeToRestoreEntry Then
            eventsReady = _
                TryStopCashAnalysisEventsForRecovery(convergenceDetail)
            safeToRestoreEntry = eventsReady
            If safeToRestoreEntry Then
                If Not TryRestoreCashAnalysisEnableEvents( _
                           entryEvents, operationName & "/�ĕی�", _
                           restoreDetail) Then
                    protectSucceeded = False
                    safeToRestoreEntry = False
                    AppendCashAnalysisRollbackDetail detailText, restoreDetail
                End If
            End If
        End If
        If Not safeToRestoreEntry Then
            eventsReady = _
                TryStopCashAnalysisEventsForRecovery(convergenceDetail)
        End If
        If Not safeToRestoreEntry And eventsReady Then
            AppendCashAnalysisRollbackDetail detailText, _
                operationName & ": �ی�܂���Recovery�������m�F�ł��Ȃ����߁A" & _
                "�J�n���C�x���g�l�֖߂���False�Œ�~���܂����B"
        ElseIf Not safeToRestoreEntry Then
            AppendCashAnalysisRollbackDetail detailText, _
                operationName & ": �ی�܂���Recovery�������m�F�ł����A" & _
                "Excel�C�x���g��False�����ɂ����s���܂����B���ݏ�Ԃ͕s���ł�: " & _
                convergenceDetail
        End If
    End If
    TryProtectCashAnalysisViewAfterFailure = protectSucceeded
End Function

Private Function CashAnalysisOuterLeaseMayRestoreAfterProtection( _
        ByVal protectOK As Boolean, _
        ByRef detailText As String) As Boolean
    Dim eventDetail As String, appStateProblems As String
    'TryProtectCashAnalysisViewAfterFailure�͓�����Recovery�ƓƎ�lease�������B
    '�O��caller�͌Â�eventsReady���ė��p�����AFalse exact����蒼�������
    '�ĕی쐬���܂���Recovery��d��Ԃ̂ǂ��炩�������m�F����B
    If Not TryStopCashAnalysisEventsForRecovery(eventDetail) Then
        AppendCashAnalysisRollbackDetail detailText, _
            "�ĕی쏈�����Excel�C�x���g��~���m�F�ł����A" & _
            "�J�n���C�x���g�l�֖߂��܂���B���ݏ�Ԃ͕s���ł�: " & _
            eventDetail
        Exit Function
    End If
    If protectOK Then
        If AppStateIsRestored(appStateProblems) Then
            CashAnalysisOuterLeaseMayRestoreAfterProtection = True
        Else
            AppendCashAnalysisRollbackDetail detailText, _
                "�ĕی���Application��Ԃ����S�ɕ����ς݂Ɗm�F�ł��܂���: " & _
                appStateProblems
        End If
    Else
        'TryProtect����Enforce����O�I�������\�����O�������ʂł��Ȃ����߁A
        '������Recovery�l���ė��p����False�̂܂ܕԂ��B
        AppendCashAnalysisRollbackDetail detailText, _
            "����̍ĕی쐬�����m�F�ł��Ȃ����߁A����Recovery�l��" & _
            "�J�n���C�x���g�����̍����ɂ͎g���܂���B"
    End If
End Function

Private Function CashAnalysisProtectionPolicyIsConfirmedExact( _
        ByVal ws As Worksheet, _
        ByRef detailText As String) As Boolean
    Dim errorNumber As Long, errorSource As String, errorDescription As String
    If ws Is Nothing Then
        detailText = "��������\���擾�ł��܂���B"
        Exit Function
    End If
    On Error GoTo EH
    If Not ws.ProtectContents Or Not ws.ProtectDrawingObjects Then _
        Err.Raise vbObjectError + 5193, _
                  "CashAnalysisProtectionPolicyIsConfirmedExact", _
                  "�Z���ی�܂��͐}�`�ی��ǂݖ߂��܂���B"
    If ws.EnableSelection <> xlNoRestrictions Then _
        Err.Raise vbObjectError + 5193, _
                  "CashAnalysisProtectionPolicyIsConfirmedExact", _
                  "�I���|���V�[��xlNoRestrictions�Ƃ��ēǂݖ߂��܂���B"
    VerifyToolShapeSecurity ws, True, False
    CashAnalysisProtectionPolicyIsConfirmedExact = True
    Exit Function
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    detailText = "Err " & CStr(errorNumber) & " " & errorDescription
    Err.Clear
End Function

Private Function CashAnalysisApplicationStateAllowsEntryRestore( _
        ByVal entryEvents As Boolean, _
        ByRef detailText As String) As Boolean
    Dim appStateProblems As String
    If Not entryEvents Then
        CashAnalysisApplicationStateAllowsEntryRestore = True
        Exit Function
    End If
    If AppStateIsRestored(appStateProblems) Then
        CashAnalysisApplicationStateAllowsEntryRestore = True
    Else
        AppendCashAnalysisRollbackDetail detailText, _
            "Application��Ԃ����S�ɕ����ς݂Ɗm�F�ł��܂���: " & _
            appStateProblems
    End If
End Function

Private Function IsCashAnalysisRecoveryFatal( _
        ByVal errorNumber As Long, ByVal errorSource As String) As Boolean
    Dim expectedSource As String
    Select Case errorNumber
        Case vbObjectError + 3599, vbObjectError + 4499
            IsCashAnalysisRecoveryFatal = True
            Exit Function
        Case vbObjectError + 5191
            expectedSource = "AnalysisWorkspaceRecoveryFatal/"
        Case vbObjectError + 5192
            expectedSource = "SetupConvergeRecoveryFatal/"
        Case vbObjectError + 5194
            expectedSource = "CashAnalysisRecoveryFatal/"
        Case vbObjectError + 5195
            expectedSource = "TransactionAnalysisRecoveryFatal/"
        Case vbObjectError + 5196
            expectedSource = "CashManualSelectionRecoveryFatal/"
        Case vbObjectError + 5197
            expectedSource = "ClearRecoveryFatal/"
        Case Else
            Exit Function
    End Select
    If Len(errorSource) < Len(expectedSource) Then Exit Function
    IsCashAnalysisRecoveryFatal = _
        (StrComp(Left$(errorSource, Len(expectedSource)), expectedSource, _
                 vbBinaryCompare) = 0)
End Function

Public Sub BuildCashAnalysisViewCore(ByVal activateAfter As Boolean, _
                                     Optional ByVal syncCurrentReview As Boolean = True, _
                                     Optional ByVal capacityConfirmed As Boolean = False)
    Dim ws As Worksheet, wsSource As Worksheet
    Dim sourceLastRow As Long, outputLastRow As Long
    Dim sourceData As Variant
    Dim keepCategory As String, keepGroupID As String, keepMode As String
    Dim keepManual As String, keepSelected As String, keepCandidateRef As String
    Dim workbookWasSaved As Boolean
    Dim viewSnapshot As CashAnalysisViewSnapshot
    Dim viewMutationStarted As Boolean, rollbackOK As Boolean
    Dim eventsReadyForRecovery As Boolean
    Dim recoveryConfirmed As Boolean, applicationStateConfirmed As Boolean
    Dim recoveryErrorNumber As Long, recoveryErrorDescription As String
    Dim rollbackErrorNumber As Long, rollbackErrorSource As String
    Dim rollbackErrorDescription As String
    Dim errorNumber As Long, errorSource As String
    Dim errorDescription As String, rollbackDetail As String
    Dim convergenceDetail As String, postEnforceStopDetail As String
    Dim finalRecoveryStopDetail As String

    On Error GoTo EH
    'CashOperation�e�ʂ́AW_����E�\�莑���\�ɉ����ĕ����̕��בւ��z���
    '���Z���Ă���A�����ōs���ő�17��̌��\���\���\�]���i���\�{�o�͍s�j���܂���B
    If Not capacityConfirmed Then
        If Not RequireOutputBuildCapacity("��������\�̕\���č\�z", True, False, _
                                          False, False, False, False) Then Err.Raise 18
        capacityConfirmed = True
    End If
    If Not SheetExists(SH_OUTPUT_TX) Or Not SheetExists(SH_WORK_CASH) Then Exit Sub
    Set ws = GetSheet(SH_OUTPUT_TX)
    Set wsSource = GetSheet(SH_WORK_CASH)
    CaptureCashAnalysisViewSnapshot ws, viewSnapshot
    '���͌��ʂ����܂��ɍč\�z�����ďo���́A�ĕ��͑O�ɋ����̔��f�𓯊��ς݁B
    '�č\�z��ɏ��ł�����groupID��V���ʂ֍ē��������A�V�������\���֎���������B
    If syncCurrentReview Then
        'Cash�p�l�������݂̕ҏW�ʂł��鎞�����A���̌��l�����ЂƂ��ē�������B
        '���ڍׂ�ҏW���̒��ڃ}�N�����s�ŁA��\�����̋�Cash�l���㏟�������Ȃ��B
        If Not ActiveSheet Is Nothing Then
            If ActiveSheet.Name = SH_OUTPUT_TX Then _
                SyncCashAnalysisPanelReviewToWorkspace
        End If
    End If
    '�m�F�����������ȉi���ύX���s�����ꍇ�A����dirty��Ԃ��r���[�����ŏ����Ȃ��B
    viewSnapshot.WorkbookWasSaved = ThisWorkbook.Saved
    workbookWasSaved = ThisWorkbook.Saved

    If Len(CellText(ws.Range(VIEW_STATE_VERSION).Value)) > 0 Then
        keepCategory = CellText(ws.Range(VIEW_STATE_CATEGORY).Value)
        keepGroupID = CellText(ws.Range(VIEW_STATE_GROUP_ID).Value)
        keepMode = CellText(ws.Range(VIEW_STATE_MODE).Value)
        keepManual = CellText(ws.Range(VIEW_STATE_MANUAL).Value)
        keepSelected = CellText(ws.Range(VIEW_STATE_SELECTED_IDS).Value)
        keepCandidateRef = CellText(ws.Range(VIEW_STATE_CANDIDATE_REF).Value)
    End If
    If Not IsCashViewCategory(keepCategory) Then keepCategory = VIEW_CATEGORY_TRANSFER
    If Not IsCashViewMode(keepMode) Then keepMode = VIEW_MODE_COMPONENT
    If keepManual <> "1" Then keepManual = "0"

    viewMutationStarted = True
    ws.Unprotect Password:=TOOL_PASSWORD
    ResetWorksheet ws
    BuildCashAnalysisViewStructure ws
    SetRowValues ws.Cells(CASH_VIEW_HEADER_ROW, 1), CashAnalysisViewHeaders()

    sourceLastRow = LastUsedRowInSheet(wsSource)
    If sourceLastRow >= 2 Then
        outputLastRow = CASH_VIEW_FIRST_DATA_ROW + sourceLastRow - 2
        sourceData = wsSource.Range( _
            wsSource.Cells(2, 1), _
            wsSource.Cells(sourceLastRow, OUT_INTERNAL_LAST_COL)).Value2
        '��s���E�����ԍ��E�E�v�E����ID����l����ɕ����񏑎��֌Œ肵�A
        '�u=�v���Ŏn�܂��s���[������𐔎��Ƃ��ĉ��߂����Ȃ��B
        ws.Range("A" & CStr(CASH_VIEW_FIRST_DATA_ROW) & ":E" & _
                 CStr(outputLastRow)).NumberFormatLocal = "@"
        ws.Range("J" & CStr(CASH_VIEW_FIRST_DATA_ROW) & ":L" & _
                 CStr(outputLastRow)).NumberFormatLocal = "@"
        ws.Range("N" & CStr(CASH_VIEW_FIRST_DATA_ROW) & ":Q" & _
                 CStr(outputLastRow)).NumberFormatLocal = "@"
        ws.Range(ws.Cells(CASH_VIEW_FIRST_DATA_ROW, 1), _
                 ws.Cells(outputLastRow, OUT_INTERNAL_LAST_COL)).Value2 = sourceData
    End If

    ws.Range(VIEW_STATE_CATEGORY).Value = keepCategory
    ws.Range(VIEW_STATE_GROUP_ID).Value = keepGroupID
    ws.Range(VIEW_STATE_MODE).Value = keepMode
    ws.Range(VIEW_STATE_MANUAL).Value = keepManual
    ws.Range(VIEW_STATE_SELECTED_IDS).Value = keepSelected
    ws.Range(VIEW_STATE_PANEL_EXPANDED).Value = "0"
    ws.Range(VIEW_STATE_CANDIDATE_REF).Value = keepCandidateRef
    ws.Range(VIEW_STATE_VERSION).Value = VIEW_VERSION
    FormatCashAnalysisViewLayout ws
    RefreshCashAnalysisPanel False
    If sourceLastRow >= 2 Then _
        VerifyGeneratedRangeValue2 ws, sourceData, CASH_VIEW_FIRST_DATA_ROW, 1, _
                                   sourceLastRow - 1, OUT_INTERNAL_LAST_COL, _
                                   "��������\�̐����\��", True
    ProtectCashAnalysisViewSheet
    SetSheetVeryHiddenSafe wsSource
    If SheetExists(SH_ANALYSIS_RESULT) Then SetSheetVeryHiddenSafe GetSheet(SH_ANALYSIS_RESULT)
    If SheetExists(SH_ANALYSIS_DETAIL) Then SetSheetVeryHiddenSafe GetSheet(SH_ANALYSIS_DETAIL)

    'FreezePanes�EZoom���̓E�B���h�E�ŗL�̕\����ԂŁA�����ς݃f�[�^�̐��ۂł͂Ȃ��B
    '�����Ŏ��s���Đ���ȕ��͌��ʂ�rollback���Ȃ��B����\�����ɂ��ēK�p�����B
    If activateAfter Then
        On Error Resume Next
        ApplyCashAnalysisViewWindowStyle True
        Err.Clear
        On Error GoTo EH
    End If
    If workbookWasSaved Then ThisWorkbook.Saved = True
    Exit Sub
EH:
    errorNumber = Err.Number
    errorSource = Err.Source
    errorDescription = Err.Description
    If IsCashAnalysisRecoveryFatal(errorNumber, errorSource) Then
        Call TryStopCashAnalysisEventsForRecovery(convergenceDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    On Error Resume Next
    Err.Clear
    rollbackOK = True
    If viewMutationStarted And viewSnapshot.Captured Then
        RestoreCashAnalysisViewSnapshot ws, viewSnapshot
        rollbackErrorNumber = Err.Number
        rollbackErrorSource = Err.Source
        rollbackErrorDescription = Err.Description
        Err.Clear
        If IsCashAnalysisRecoveryFatal( _
               rollbackErrorNumber, rollbackErrorSource) Then
            On Error GoTo 0
            Call TryStopCashAnalysisEventsForRecovery(convergenceDetail)
            Err.Raise rollbackErrorNumber, rollbackErrorSource, _
                      rollbackErrorDescription
        End If
        If rollbackErrorNumber <> 0 Then
            rollbackOK = False
            AppendCashAnalysisRollbackDetail rollbackDetail, _
                "��������\�̕����G���[: " & rollbackErrorDescription
        End If
    End If
    Err.Clear
    If Not rollbackOK Then
        Err.Clear
        EnforceRollbackRecoveryState rollbackDetail
        recoveryErrorNumber = Err.Number
        recoveryErrorDescription = Err.Description
        Err.Clear
        On Error GoTo 0
        eventsReadyForRecovery = _
            TryStopCashAnalysisEventsForRecovery(postEnforceStopDetail)
        If recoveryErrorNumber <> 0 Then
            Err.Raise vbObjectError + 5194, _
                "CashAnalysisRecoveryFatal/BuildCashAnalysisViewCore", _
                errorDescription & " / Recovery�����ݒ�G���[: Err " & _
                CStr(recoveryErrorNumber) & " " & recoveryErrorDescription
        End If
        If Not eventsReadyForRecovery Then _
            Err.Raise vbObjectError + 5194, _
                "CashAnalysisRecoveryFatal/BuildCashAnalysisViewCore", _
                errorDescription & " / Recovery�������Excel�C�x���g" & _
                "False�������m�F�ł��܂���: " & postEnforceStopDetail
        recoveryConfirmed = _
            CashAnalysisRecoveryStateIsConfirmedExact(rollbackDetail)
        If Not recoveryConfirmed Then _
            Err.Raise vbObjectError + 5194, _
                "CashAnalysisRecoveryFatal/BuildCashAnalysisViewCore", _
                errorDescription & " / �����Recovery��d��Ԃ�" & _
                "�����m�F�ł��܂���: " & rollbackDetail
        applicationStateConfirmed = _
            CashAnalysisApplicationStateAllowsEntryRestore( _
                True, rollbackDetail)
        If Not applicationStateConfirmed Then
            eventsReadyForRecovery = _
                TryStopCashAnalysisEventsForRecovery( _
                    finalRecoveryStopDetail)
            Err.Raise vbObjectError + 5194, _
                "CashAnalysisRecoveryFatal/BuildCashAnalysisViewCore", _
                errorDescription & " / Application��Ԃ����S��" & _
                "�m�F�ł��܂���: " & rollbackDetail
        End If
        eventsReadyForRecovery = _
            TryStopCashAnalysisEventsForRecovery(finalRecoveryStopDetail)
        If Not eventsReadyForRecovery Then _
            Err.Raise vbObjectError + 5194, _
                "CashAnalysisRecoveryFatal/BuildCashAnalysisViewCore", _
                errorDescription & " / Recovery�m�F���Excel�C�x���g" & _
                "False�������m�F�ł��܂���: " & finalRecoveryStopDetail
        Err.Raise vbObjectError + 5194, _
            "CashAnalysisRecoveryFatal/BuildCashAnalysisViewCore", _
            errorDescription & " / ��������\�����S�ɕ����ł����A" & _
            "�����Recovery��Ԃ֒�~���܂���: " & rollbackDetail
    End If
    On Error GoTo 0
    If Len(rollbackDetail) > 0 Then _
        errorDescription = errorDescription & " / �����m�F: " & rollbackDetail
    Err.Raise errorNumber, "BuildCashAnalysisViewCore", errorDescription
End Sub

Public Sub ApplyCashAnalysisViewWindowStyle(Optional ByVal selectTop As Boolean = True)
    '1366�~768�E125%�����ł�80%�����֏k�����Ȃ��񕝂ŁAA:M�ƌŒ�p�l���{
    '�Œ�2���׍s�������Ɍ�����{���֎���������B
    '�����Ɍ�����{���֎���������BRange/Window�͂�������|�C���g�P�ʂȂ̂ŁA
    'Windows 125%�\���ł�DPI�𐄑������������画�f�ł���B
    Dim ws As Worksheet, win As Window
    Dim requiredWidth As Double, availableWidth As Double
    Dim requiredHeight As Double, availableHeight As Double
    Dim targetZoom As Long, fitAtReturnedZoom As Boolean
    If Not SheetExists(SH_OUTPUT_TX) Then Exit Sub
    Set ws = GetSheet(SH_OUTPUT_TX)
    ws.Visible = xlSheetVisible
    ws.Activate
    Set win = Application.ActiveWindow
    '�E�B���h�E�{���ƌŒ�ʒu�̓f�[�^�E�ۑ���Ԃł͂Ȃ��B�����E�B���h�E�A
    '�ی�r���[�A�����[�g�\�����Ŏ擾�ł��Ȃ��ꍇ�����͌��ʂ����s�����ɂ��Ȃ��B
    If win Is Nothing Then Exit Sub

    requiredWidth = ws.Range("A1:M1").Width
    availableWidth = InputAvailableWidthPoints(win)
    requiredHeight = ws.Range("1:" & CStr(CASH_VIEW_HEADER_ROW)).Height + _
                     VIEW_DATA_ROW_HEIGHT * CDbl(VIEW_MIN_VISIBLE_DATA_ROWS)
    availableHeight = CashAnalysisAvailableHeightPoints(win)
    targetZoom = CashAnalysisFitZoomPercent( _
                     requiredWidth, availableWidth, _
                     requiredHeight, availableHeight, _
                     fitAtReturnedZoom)

    '80%�������Ȃ��Ǝ��܂�Ȃ������E�B���h�E�ł́A�ǐ���D�悵��
    '80%��Ԃ��AfitAtReturnedZoom=False�Ƃ���B���X�N���[�������e���Ă��A
    '�{����������9pt�����ɂȂ�k���͍s��Ȃ��B

    SafeFreezeSheetAt ws, "A" & CStr(CASH_VIEW_FIRST_DATA_ROW), targetZoom
    ws.Activate
    If selectTop Then
        SafeSelectCell ws, "A1"
    End If
End Sub

Private Function CashAnalysisAvailableHeightPoints(ByVal win As Window) As Double
    'Application.UsableHeight��Window.Height�̓|�C���g�P�ʁB���{���A�����o�[�A
    '�V�[�g���o�����̗̈��ێ�I�ɍ��������A�Z���\���֎g���鍂����Ԃ��B
    Dim availableHeight As Double
    On Error Resume Next
    availableHeight = Application.UsableHeight
    If Not win Is Nothing Then
        If win.Height > 0 Then
            If availableHeight <= 0 Then
                availableHeight = win.Height
            ElseIf win.Height < availableHeight Then
                availableHeight = win.Height
            End If
        End If
    End If
    On Error GoTo 0
    If availableHeight > VIEW_VERTICAL_CHROME_RESERVE_POINTS Then
        availableHeight = availableHeight - VIEW_VERTICAL_CHROME_RESERVE_POINTS
    Else
        availableHeight = 0
    End If
    CashAnalysisAvailableHeightPoints = availableHeight
End Function

Public Function CashAnalysisFitZoomPercent( _
        ByVal requiredWidth As Double, ByVal availableWidth As Double, _
        ByVal requiredHeight As Double, ByVal availableHeight As Double, _
        Optional ByRef fitAtReturnedZoom As Boolean = False) As Long
    '����ʂ�ύX���Ȃ�����I�v�Z�B�����܂��͍����̌��������֍��킹�A
    '�݌v�{��88%������A�ʏ핶����ǂ߂�80%�������Ƃ���B�߂�l�͏��
    '���ۂɐݒ肷��{���BfitAtReturnedZoom�́A�w�肳�ꂽ�S�K�v���@�����̔{����
    '���܂�ꍇ����True�Ƃ���B�K�v�{����80%�����A�܂��͗��p�\���@���擾
    '�ł��Ȃ��ꍇ��False�Ȃ̂ŁA80%���u���e�ς݁v�ƌ�F���Ȃ��B
    Dim targetZoom As Double, widthZoom As Double, heightZoom As Double
    targetZoom = CDbl(VIEW_DESIGN_ZOOM)
    If requiredWidth > 0 Then
        If availableWidth > 0 Then
            widthZoom = 100# * availableWidth / requiredWidth
            If widthZoom < targetZoom Then targetZoom = widthZoom
        End If
    End If
    If requiredHeight > 0 Then
        If availableHeight > 0 Then
            heightZoom = 100# * availableHeight / requiredHeight
            If heightZoom < targetZoom Then targetZoom = heightZoom
        End If
    End If
    If targetZoom < VIEW_MIN_ZOOM Then targetZoom = VIEW_MIN_ZOOM
    If targetZoom > VIEW_DESIGN_ZOOM Then targetZoom = VIEW_DESIGN_ZOOM
    CashAnalysisFitZoomPercent = CLng(Int(targetZoom))
    fitAtReturnedZoom = True
    If requiredWidth > 0 Then
        If availableWidth <= 0 Then
            fitAtReturnedZoom = False
        ElseIf requiredWidth * CDbl(CashAnalysisFitZoomPercent) / 100# > _
               availableWidth + 0.5 Then
            fitAtReturnedZoom = False
        End If
    End If
    If requiredHeight > 0 Then
        If availableHeight <= 0 Then
            fitAtReturnedZoom = False
        ElseIf requiredHeight * CDbl(CashAnalysisFitZoomPercent) / 100# > _
               availableHeight + 0.5 Then
            fitAtReturnedZoom = False
        End If
    End If
End Function

Private Sub BuildCashAnalysisViewStructure(ByVal ws As Worksheet)
    Dim rng As Range
    If ws Is Nothing Then Exit Sub
    ws.Unprotect Password:=TOOL_PASSWORD
    '�}�`�͍쐬���̃Z�����@��ێ�����B�S�č\�z�o�H�Ő�ɐ݌v���@�֎���������B
    ApplyCashAnalysisViewGeometry ws
    ws.Cells.Locked = True
    With ws.Range("A1:M8")
        .Font.Name = "Yu Gothic UI"
        .Font.Size = 10
        .VerticalAlignment = xlCenter
        .Borders.LineStyle = xlContinuous
        .Borders.Color = RGB(226, 232, 240)
        .Interior.Color = RGB(255, 255, 255)
    End With

    MergeViewCell ws.Range("A1:E1"), "��������\�b����ƕ��͂𓯎��m�F"
    With ws.Range("A1:E1")
        .Interior.Color = RGB(15, 23, 42)
        .Font.Color = RGB(255, 255, 255)
        .Font.Bold = True
        .Font.Size = 15
        .HorizontalAlignment = xlLeft
        .IndentLevel = 1
    End With
    MergeViewCell ws.Range("F1:M1"), "���͌����X�V����ƁA�����Ɍ����ƌ��݈ʒu���\������܂��B"
    With ws.Range("F1:M1")
        .Interior.Color = RGB(241, 245, 249)
        .Font.Color = RGB(51, 65, 85)
        .Font.Bold = True
        .HorizontalAlignment = xlLeft
        .IndentLevel = 1
        '��⌏�����傫���ꍇ��1�s�̗v������������Ȃ��ŏI�h��B
        '�ڍ׏���5�`7�s�֕\�����A�����ɂ͒Z����Ԃ�����u���B
        .WrapText = False
        .ShrinkToFit = True
    End With

    '�}�`�͉�ʐ�p�ň�����Ȃ����߁A������ɕK�v�Ȍ��݋敪�ƕ\���͈͂������Z���֎c���B
    MergeViewCell ws.Range("A2:C2"), "�����ړ�"
    MergeViewCell ws.Range("D2:F2"), "�s���o��"
    MergeViewCell ws.Range("G2:I2"), "�s������"
    MergeViewCell ws.Range("J2:K2"), ""
    MergeViewCell ws.Range("L2:M2"), ""
    MergeViewCell ws.Range("E3:F3"), ""
    MergeViewCell ws.Range("G3:H3"), "�\��: �\�����"
    MergeViewCell ws.Range("I3:J3"), ""
    MergeViewCell ws.Range("K3:M3"), ""
    StyleViewPrintControl ws.Range("A2:I2")
    StyleViewPrintControl ws.Range("G3:H3")

    MergeViewCell ws.Range("A3:B3"), "�m�F��"
    MergeViewCell ws.Range("C3:D3"), ANALYSIS_STATUS_UNREVIEWED
    StyleViewLabel ws.Range("A3:B3")
    StyleViewValue ws.Range("C3:D3")

    ws.Range("A4").Value = "�o�����v"
    MergeViewCell ws.Range("B4:D4"), "0"
    ws.Range("E4").Value = "�������v"
    MergeViewCell ws.Range("F4:H4"), "0"
    ws.Range("I4").Value = "���z�i���|�o�j"
    MergeViewCell ws.Range("J4:M4"), "0"
    StyleViewLabel ws.Range("A4")
    StyleViewLabel ws.Range("E4")
    StyleViewLabel ws.Range("I4")
    StyleViewMoney ws.Range("B4:D4"), RGB(254, 242, 242), RGB(185, 28, 28)
    StyleViewMoney ws.Range("F4:H4"), RGB(239, 246, 255), RGB(29, 78, 216)
    StyleViewMoney ws.Range("J4:M4"), RGB(248, 250, 252), RGB(15, 23, 42)

    MergeViewCell ws.Range("A5:B5"), "���t�E����"
    MergeViewCell ws.Range("C5:E5"), "�|"
    MergeViewCell ws.Range("F5:G5"), "�l���E�����o�H"
    MergeViewCell ws.Range("H5:M5"), "�|"
    StyleViewLabel ws.Range("A5:B5")
    StyleViewValue ws.Range("C5:E5")
    StyleViewLabel ws.Range("F5:G5")
    StyleViewValue ws.Range("H5:M5")

    MergeViewCell ws.Range("A6:B6"), "���o���R�E�v�_" & vbLf & "�m�_�u���N���b�N�œW�J�n"
    MergeViewCell ws.Range("C6:M6"), "����I������ƁA���o���R���\������܂��B"
    MergeViewCell ws.Range("A7:B7"), "���؁E����" & vbLf & "�m�_�u���N���b�N�œW�J�n"
    MergeViewCell ws.Range("C7:M7"), "��₪�������Ȃ��\���������Ŋm�F���܂��B"
    MergeViewCell ws.Range("A8:B8"), "�m�F����" & vbLf & "�m�_�u���N���b�N�œW�J�n"
    MergeViewCell ws.Range("C8:M8"), ""
    StyleViewLabel ws.Range("A6:B8")
    ws.Range("A6:B8").WrapText = True
    ws.Range("A6:B8").Font.Size = 9
    StyleViewValue ws.Range("C6:M8")
    ws.Range("C6:M8").WrapText = True
    ws.Range("C8:M8").Interior.Color = RGB(254, 249, 195)

    BuildCashAnalysisViewButtons ws

    SetRowValues ws.Cells(CASH_VIEW_HEADER_ROW, 1), CashAnalysisViewHeaders()
    ws.Range("V1:Z12").NumberFormatLocal = "@"
    ws.Columns("N:Z").Hidden = True
    Set rng = ws.Range("A9:M9")
    rng.Interior.Color = RGB(226, 232, 240)
    rng.Borders.LineStyle = xlNone
End Sub

Private Sub StyleViewPrintControl(ByVal target As Range)
    If target Is Nothing Then Exit Sub
    With target
        .Interior.Color = RGB(248, 250, 252)
        .Font.Color = RGB(51, 65, 85)
        .Font.Bold = True
        .HorizontalAlignment = xlCenter
        .VerticalAlignment = xlCenter
        .Borders.LineStyle = xlContinuous
        .Borders.Color = RGB(203, 213, 225)
    End With
End Sub

Private Sub MergeViewCell(ByVal target As Range, ByVal valueText As String)
    If target Is Nothing Then Exit Sub
    target.Merge
    target.Cells(1, 1).Value = valueText
End Sub

Private Sub StyleViewLabel(ByVal target As Range)
    If target Is Nothing Then Exit Sub
    With target
        .Interior.Color = RGB(241, 245, 249)
        .Font.Color = RGB(71, 85, 105)
        .Font.Bold = True
        .HorizontalAlignment = xlCenter
    End With
End Sub

Private Sub StyleViewValue(ByVal target As Range)
    If target Is Nothing Then Exit Sub
    With target
        .Interior.Color = RGB(255, 255, 255)
        .Font.Color = RGB(15, 23, 42)
        .HorizontalAlignment = xlLeft
        .IndentLevel = 1
    End With
End Sub

Private Sub StyleViewMoney(ByVal target As Range, ByVal fillColor As Long, ByVal fontColor As Long)
    If target Is Nothing Then Exit Sub
    With target
        .Interior.Color = fillColor
        .Font.Color = fontColor
        .Font.Bold = True
        .Font.Size = 12
        .HorizontalAlignment = xlRight
        .IndentLevel = 1
    End With
End Sub

Private Sub AddViewButton(ByVal ws As Worksheet, ByVal area As Range, ByVal caption As String, _
                          ByVal macroName As String, ByVal styleName As String)
    AddUIButton ws, area.Left + 2, area.Top + 2, area.Width - 4, area.Height - 4, _
                caption, macroName, styleName, False
End Sub

Private Sub ApplyCashAnalysisViewGeometry(ByVal ws As Worksheet)
    If ws Is Nothing Then Exit Sub
    ws.Rows(1).RowHeight = 34
    ws.Rows(2).RowHeight = 36
    ws.Rows(3).RowHeight = 36
    ws.Rows(4).RowHeight = 31
    ws.Rows(5).RowHeight = 31
    ws.Rows(6).RowHeight = 38
    ws.Rows(7).RowHeight = 38
    ws.Rows(8).RowHeight = 42
    ws.Rows(9).RowHeight = 7
    ws.Rows(CASH_VIEW_HEADER_ROW).RowHeight = 34
    '��o��A:M���ێ������܂܁A1366px����80%�ȏ�Ɏ��߂�B�����̓E�v��
    '�ܕԂ��E�s�������œǂ݁A�ʏ��ʂ��{���։���������Œ蕝���������Ȃ��B
    ws.Columns("A:A").ColumnWidth = 15
    ws.Columns("B:B").ColumnWidth = 13.5
    ws.Columns("C:C").ColumnWidth = 15
    ws.Columns("D:D").ColumnWidth = 8.5
    ws.Columns("E:E").ColumnWidth = 13.5
    ws.Columns("F:F").ColumnWidth = 11
    ws.Columns("G:G").ColumnWidth = 7.5
    ws.Columns("H:I").ColumnWidth = 12
    ws.Columns("J:J").ColumnWidth = 14
    ws.Columns("K:K").ColumnWidth = 7.5
    ws.Columns("L:L").ColumnWidth = 20
    ws.Columns("M:M").ColumnWidth = 12.5
    ws.Range("C5:M8").WrapText = True
End Sub

Private Sub BuildCashAnalysisViewButtons(ByVal ws As Worksheet)
    If ws Is Nothing Then Exit Sub
    AddViewButton ws, ws.Range("A2:C2"), "�����ړ�", "ShowCashAnalysisTransfers", "primary"
    AddViewButton ws, ws.Range("D2:F2"), "�s���o��", "ShowCashAnalysisUnknownWithdrawals", "soft"
    AddViewButton ws, ws.Range("G2:I2"), "�s������", "ShowCashAnalysisUnknownDeposits", "soft"
    AddViewButton ws, ws.Range("J2:K2"), "�O�̌��", "PreviousCashAnalysisCandidate", "tool"
    AddViewButton ws, ws.Range("L2:M2"), "���̌��", "NextCashAnalysisCandidate", "tool"
    AddViewButton ws, ws.Range("E3:F3"), "���m�F��", "NextUnreviewedCashAnalysisGroup", "tool"
    AddViewButton ws, ws.Range("G3:H3"), "�\��: �\�����", "CycleCashAnalysisViewMode", "soft"
    AddViewButton ws, ws.Range("I3:J3"), "�蓮����I��", "CashAnalysisSecondaryAction", "tool"
    AddViewButton ws, ws.Range("K3:M3"), "�m�F�ς݂ɂ���", "CashAnalysisPrimaryAction", "primary"
End Sub

Public Sub RestoreCashAnalysisViewControls(ByVal ws As Worksheet)
    '�����������ɂ��A��ꂽ�񕝂�����ꂽ�}�`�̈ʒu�E���@��݌v�l�ō�蒼���B
    Dim workbookWasSaved As Boolean, protectOK As Boolean
    Dim savedErrorNumber As Long, savedErrorDescription As String
    Dim errorNumber As Long, errorSource As String, errorDescription As String
    Dim eventsReady As Boolean, convergenceDetail As String
    If ws Is Nothing Then Exit Sub
    workbookWasSaved = ThisWorkbook.Saved
    On Error GoTo EH
    ws.Unprotect Password:=TOOL_PASSWORD
    ApplyCashAnalysisViewGeometry ws
    DeleteToolShapesVerified ws, False
    BuildCashAnalysisViewButtons ws
    RefreshCashAnalysisPanel False
    If workbookWasSaved Then ThisWorkbook.Saved = True
    Exit Sub
EH:
    errorNumber = Err.Number
    errorSource = Err.Source
    errorDescription = Err.Description
    If IsCashAnalysisRecoveryFatal(errorNumber, errorSource) Then
        Call TryStopCashAnalysisEventsForRecovery(convergenceDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    protectOK = TryProtectCashAnalysisViewAfterFailure( _
                    ws, "RestoreCashAnalysisViewControls", False, errorDescription)
    If workbookWasSaved And protectOK Then
        On Error Resume Next
        Err.Clear
        ThisWorkbook.Saved = True
        savedErrorNumber = Err.Number
        savedErrorDescription = Err.Description
        Err.Clear
        On Error GoTo 0
        If savedErrorNumber <> 0 Then _
            AppendCashAnalysisRollbackDetail errorDescription, _
                "�u�b�N�ۑ���Ԃ̕����G���[: Err " & _
                CStr(savedErrorNumber) & " " & savedErrorDescription
    End If
    Err.Raise errorNumber, "RestoreCashAnalysisViewControls", errorDescription
End Sub

Public Sub FormatCashAnalysisViewLayout(ByVal ws As Worksheet)
    Dim lastR As Long, r As Long
    Dim recordTypes As Variant, tekiyoValues As Variant
    Dim recordType As String, tekiyoText As String
    If ws Is Nothing Then Exit Sub
    lastR = LastUsedRowInSheet(ws)
    If lastR < CASH_VIEW_HEADER_ROW Then lastR = CASH_VIEW_HEADER_ROW

    With ws.Range("A1:T" & CStr(lastR))
        '�F�̓^�C�g���A��ԁA���z�ȂǊe���i�̈Ӗ��������߁A�����ł͏㏑�����Ȃ��B
        .Font.Name = "Yu Gothic UI"
        .VerticalAlignment = xlCenter
    End With
    ApplyCashAnalysisViewGeometry ws

    FormatOutputHeader ws.Range(ws.Cells(CASH_VIEW_HEADER_ROW, 1), _
                                    ws.Cells(CASH_VIEW_HEADER_ROW, CASH_VIEW_LAST_COL))
    With ws.Range(ws.Cells(CASH_VIEW_HEADER_ROW, 1), ws.Cells(CASH_VIEW_HEADER_ROW, OUT_COL_OTHER))
        .HorizontalAlignment = xlCenter
        .VerticalAlignment = xlCenter
        .WrapText = False
    End With
    With ws.Cells(CASH_VIEW_HEADER_ROW, OUT_COL_WITHDRAW)
        .Interior.Color = RGB(185, 28, 28)
        .Font.Color = RGB(255, 255, 255)
        .Font.Bold = True
    End With
    With ws.Cells(CASH_VIEW_HEADER_ROW, OUT_COL_DEPOSIT)
        .Interior.Color = RGB(29, 78, 216)
        .Font.Color = RGB(255, 255, 255)
        .Font.Bold = True
    End With
    ws.Columns("N:Z").Hidden = True

    If lastR >= CASH_VIEW_FIRST_DATA_ROW Then
        With ws.Range(ws.Cells(CASH_VIEW_FIRST_DATA_ROW, 1), ws.Cells(lastR, OUT_COL_OTHER))
            .Font.Size = 11.5
            .Font.Color = RGB(15, 23, 42)
            .Font.Bold = False
            .Interior.Pattern = xlSolid
            .Interior.Color = RGB(255, 255, 255)
            .Borders.LineStyle = xlContinuous
            .Borders.Color = RGB(226, 232, 240)
            .VerticalAlignment = xlCenter
        End With
        ws.Rows(CStr(CASH_VIEW_FIRST_DATA_ROW) & ":" & CStr(lastR)).RowHeight = 30
        ws.Range(ws.Cells(CASH_VIEW_FIRST_DATA_ROW, 1), ws.Cells(lastR, OUT_COL_TIME)).HorizontalAlignment = xlCenter
        ws.Range(ws.Cells(CASH_VIEW_FIRST_DATA_ROW, OUT_COL_WITHDRAW), _
                 ws.Cells(lastR, OUT_COL_DEPOSIT)).HorizontalAlignment = xlRight
        ws.Range(ws.Cells(CASH_VIEW_FIRST_DATA_ROW, OUT_COL_WITHDRAW), _
                 ws.Cells(lastR, OUT_COL_WITHDRAW)).Font.Color = RGB(153, 27, 27)
        ws.Range(ws.Cells(CASH_VIEW_FIRST_DATA_ROW, OUT_COL_DEPOSIT), _
                 ws.Cells(lastR, OUT_COL_DEPOSIT)).Font.Color = RGB(30, 64, 175)
        ws.Range(ws.Cells(CASH_VIEW_FIRST_DATA_ROW, OUT_COL_SHOP), _
                 ws.Cells(lastR, OUT_COL_MACHINE)).HorizontalAlignment = xlCenter
        ws.Range(ws.Cells(CASH_VIEW_FIRST_DATA_ROW, OUT_COL_TEKIYO), _
                 ws.Cells(lastR, OUT_COL_TEKIYO)).HorizontalAlignment = xlLeft
        ws.Range(ws.Cells(CASH_VIEW_FIRST_DATA_ROW, OUT_COL_OTHER), _
                 ws.Cells(lastR, OUT_COL_OTHER)).HorizontalAlignment = xlRight
        ws.Range(ws.Cells(CASH_VIEW_FIRST_DATA_ROW, OUT_COL_DATE), _
                 ws.Cells(lastR, OUT_COL_DATE)).NumberFormatLocal = "yyyy/m/d"
        ws.Range(ws.Cells(CASH_VIEW_FIRST_DATA_ROW, OUT_COL_TIME), _
                 ws.Cells(lastR, OUT_COL_TIME)).NumberFormatLocal = "hh:mm"
        ws.Range(ws.Cells(CASH_VIEW_FIRST_DATA_ROW, OUT_COL_WITHDRAW), _
                 ws.Cells(lastR, OUT_COL_DEPOSIT)).NumberFormatLocal = "#,##0.########"
        ws.Range(ws.Cells(CASH_VIEW_FIRST_DATA_ROW, OUT_COL_OTHER), _
                 ws.Cells(lastR, OUT_COL_OTHER)).NumberFormatLocal = "#,##0.########"
        ws.Range(ws.Cells(CASH_VIEW_FIRST_DATA_ROW, OUT_COL_TEKIYO), _
                 ws.Cells(lastR, OUT_COL_OTHER)).WrapText = True

        If lastR = CASH_VIEW_FIRST_DATA_ROW Then
            ReDim recordTypes(1 To 1, 1 To 1)
            ReDim tekiyoValues(1 To 1, 1 To 1)
            recordTypes(1, 1) = ws.Cells(CASH_VIEW_FIRST_DATA_ROW, OUT_COL_RECORD_TYPE).Value2
            tekiyoValues(1, 1) = ws.Cells(CASH_VIEW_FIRST_DATA_ROW, OUT_COL_TEKIYO).Value2
        Else
            recordTypes = ws.Range(ws.Cells(CASH_VIEW_FIRST_DATA_ROW, OUT_COL_RECORD_TYPE), _
                                   ws.Cells(lastR, OUT_COL_RECORD_TYPE)).Value2
            tekiyoValues = ws.Range(ws.Cells(CASH_VIEW_FIRST_DATA_ROW, OUT_COL_TEKIYO), _
                                    ws.Cells(lastR, OUT_COL_TEKIYO)).Value2
        End If
        For r = CASH_VIEW_FIRST_DATA_ROW To lastR
            recordType = CellText(recordTypes(r - CASH_VIEW_FIRST_DATA_ROW + 1, 1))
            tekiyoText = CellText(tekiyoValues(r - CASH_VIEW_FIRST_DATA_ROW + 1, 1))
            If Len(tekiyoText) > 32 Or InStr(1, tekiyoText, vbLf, vbBinaryCompare) > 0 Or _
               InStr(1, tekiyoText, vbCr, vbBinaryCompare) > 0 Then _
                ws.Rows(r).RowHeight = ReadableOutputRowHeight(tekiyoText, 30, 120)
            '����s�̐F�����͉��̏����t�������ňꊇ�K�p����B
            '�s���Ƃ�13�Z�������ݒ������AVBA/Excel�Ԃ�COM�����𒷊����ׂł��}����B
        Next r
    End If

    ApplyCashAnalysisConditionalFormatting ws, lastR
    ws.ScrollArea = "A1:M" & CStr(Application.Max(60, lastR + 20))
    ApplyPrintAreaVerified ws, ws.Range("A1:M" & CStr(lastR))
    '���̓p�l���͐擪�y�[�W�����ɒu���A2�y�[�W�ڈȍ~�͎�����o�������𔽕�����B
    ApplyReadablePrintSettings ws, "$10:$10"
End Sub

Private Sub ApplyCashAnalysisConditionalFormatting(ByVal ws As Worksheet, ByVal lastR As Long)
    Dim body As Range, fc As FormatCondition
    If ws Is Nothing Or lastR < CASH_VIEW_FIRST_DATA_ROW Then Exit Sub
    Set body = ws.Range(ws.Cells(CASH_VIEW_FIRST_DATA_ROW, 1), ws.Cells(lastR, OUT_COL_OTHER))
    body.FormatConditions.Delete

    Set fc = body.FormatConditions.Add(Type:=xlExpression, _
        Formula1:="=OR($P" & CStr(CASH_VIEW_FIRST_DATA_ROW) & "=" & Chr$(34) & _
                  RECORD_BALANCE & Chr$(34) & ",AND($P" & _
                  CStr(CASH_VIEW_FIRST_DATA_ROW) & "=" & Chr$(34) & Chr$(34) & _
                  ",ISNUMBER(SEARCH(" & Chr$(34) & "�c��" & Chr$(34) & ",$L" & _
                  CStr(CASH_VIEW_FIRST_DATA_ROW) & "))))")
    fc.Interior.Color = RGB(220, 252, 231)
    fc.Font.Color = RGB(22, 101, 52)

    Set fc = body.FormatConditions.Add(Type:=xlExpression, _
        Formula1:="=OR($P" & CStr(CASH_VIEW_FIRST_DATA_ROW) & "=" & Chr$(34) & _
                  RECORD_INHERITANCE & Chr$(34) & ",$L" & _
                  CStr(CASH_VIEW_FIRST_DATA_ROW) & "=" & Chr$(34) & _
                  "�����J�n��" & Chr$(34) & ")")
    fc.Interior.Color = RGB(254, 243, 199)
    fc.Font.Color = RGB(146, 64, 14)
    fc.Font.Bold = True

    Set fc = body.FormatConditions.Add(Type:=xlExpression, _
        Formula1:="=OR($P" & CStr(CASH_VIEW_FIRST_DATA_ROW) & "=" & Chr$(34) & _
                  RECORD_OPEN & Chr$(34) & ",$P" & _
                  CStr(CASH_VIEW_FIRST_DATA_ROW) & "=" & Chr$(34) & _
                  RECORD_CLOSE & Chr$(34) & ",$L" & _
                  CStr(CASH_VIEW_FIRST_DATA_ROW) & "=" & Chr$(34) & _
                  "�����J�ݓ�" & Chr$(34) & ",$L" & _
                  CStr(CASH_VIEW_FIRST_DATA_ROW) & "=" & Chr$(34) & _
                  "��������" & Chr$(34) & ")")
    fc.Interior.Color = RGB(219, 234, 254)
    fc.Font.Color = RGB(30, 64, 175)

    Set fc = body.FormatConditions.Add(Type:=xlExpression, _
        Formula1:="=$S" & CStr(CASH_VIEW_FIRST_DATA_ROW) & "=" & Chr$(34) & _
                  VIEW_ROLE_WITHDRAW & Chr$(34))
    fc.Interior.Color = RGB(254, 242, 242)
    fc.Font.Color = RGB(127, 29, 29)

    Set fc = body.FormatConditions.Add(Type:=xlExpression, _
        Formula1:="=$S" & CStr(CASH_VIEW_FIRST_DATA_ROW) & "=" & Chr$(34) & _
                  VIEW_ROLE_DEPOSIT & Chr$(34))
    fc.Interior.Color = RGB(239, 246, 255)
    fc.Font.Color = RGB(30, 64, 175)

    Set fc = body.FormatConditions.Add(Type:=xlExpression, _
        Formula1:="=OR($S" & CStr(CASH_VIEW_FIRST_DATA_ROW) & "=" & Chr$(34) & _
                  VIEW_ROLE_BOTH & Chr$(34) & ",$T" & CStr(CASH_VIEW_FIRST_DATA_ROW) & _
                  "=" & Chr$(34) & "1" & Chr$(34) & ")")
    fc.Interior.Color = RGB(254, 249, 195)
    fc.Font.Color = RGB(133, 77, 14)
    On Error Resume Next
    fc.SetFirstPriority
    fc.StopIfTrue = True
    On Error GoTo 0
End Sub

Public Sub RefreshCashAnalysisPanel(Optional ByVal selectFirstVisible As Boolean = False)
    Dim ws As Worksheet, wsResult As Worksheet, wsGroup As Worksheet
    Dim categoryText As String, groupID As String, modeText As String
    Dim candidateRef As String, txIDList As String
    Dim manualMode As Boolean, resultRow As Long, groupRow As Long
    Dim currentIndex As Long, categoryCount As Long
    Dim counts(1 To 3) As Long, followupCount As Long, unreviewedCount As Long
    Dim lastResultRow As Long, r As Long, itemCategory As String, statusText As String
    Dim categoryValues As Variant, statusValues As Variant, groupValues As Variant
    Dim workbookWasSaved As Boolean, previousEvents As Boolean, eventsCaptured As Boolean
    Dim eventsReadyForRecovery As Boolean, protectOK As Boolean
    Dim recoveryConfirmed As Boolean, safeToRestoreEntry As Boolean
    Dim applicationStateConfirmed As Boolean
    Dim protectionRecoveryAttempted As Boolean
    Dim protectionRecoveryFailed As Boolean
    Dim protectionRecoveryConfirmed As Boolean
    Dim recoveryFatal As Boolean
    Dim eventStateDetail As String, recoveryDetail As String
    Dim stopDetail As String, stopRetryDetail As String
    Dim postProtectStopDetail As String, postEnforceStopDetail As String
    Dim convergenceDetail As String, finalRecoveryStopDetail As String
    Dim recoveryErrorNumber As Long, recoveryErrorDescription As String
    Dim errorNumber As Long, errorSource As String, errorDescription As String

    On Error GoTo EH
    If Not SheetExists(SH_OUTPUT_TX) Then Exit Sub
    Set ws = GetSheet(SH_OUTPUT_TX)
    workbookWasSaved = ThisWorkbook.Saved
    If Not TryGetCashAnalysisEnableEvents(previousEvents, eventStateDetail) Then
        StopAfterCashAnalysisEventStateFailure _
            "RefreshCashAnalysisPanel/�J�n��Ԏ擾", eventStateDetail, _
            eventsReadyForRecovery, False, vbNullString
        Err.Raise vbObjectError + 5102, "RefreshCashAnalysisPanel", _
                  "Excel�C�x���g�̊J�n��Ԃ��擾�ł��܂���ł����B " & eventStateDetail
    End If
    eventsCaptured = True
    If Not TrySetCashAnalysisEnableEventsExact(False, eventStateDetail) Then _
        Err.Raise vbObjectError + 5103, "RefreshCashAnalysisPanel", _
                  "���̓p�l���X�V�O��Excel�C�x���g���~�ł��܂���ł����B " & _
                  eventStateDetail
    ws.Unprotect Password:=TOOL_PASSWORD

    categoryText = CellText(ws.Range(VIEW_STATE_CATEGORY).Value)
    If Not IsCashViewCategory(categoryText) Then categoryText = VIEW_CATEGORY_TRANSFER
    modeText = CellText(ws.Range(VIEW_STATE_MODE).Value)
    If Not IsCashViewMode(modeText) Then modeText = VIEW_MODE_COMPONENT
    manualMode = (CellText(ws.Range(VIEW_STATE_MANUAL).Value) = "1")

    If SheetExists(SH_ANALYSIS_RESULT) Then
        Set wsResult = GetSheet(SH_ANALYSIS_RESULT)
        lastResultRow = LastUsedRowInSheet(wsResult)
        If lastResultRow >= 2 Then
            categoryValues = CashResultColumnValues(wsResult, 2, lastResultRow, 2)
            statusValues = CashResultColumnValues(wsResult, 2, lastResultRow, ANALYSIS_RESULT_STATUS_COL)
            groupValues = CashResultColumnValues(wsResult, 2, lastResultRow, ANALYSIS_RESULT_GROUP_ID_COL)
        End If
        For r = 1 To Application.Max(0, lastResultRow - 1)
            itemCategory = CashViewCategoryForResult(CellText(categoryValues(r, 1)))
            Select Case itemCategory
                Case VIEW_CATEGORY_TRANSFER: counts(1) = counts(1) + 1
                Case VIEW_CATEGORY_UNKNOWN_WITHDRAW: counts(2) = counts(2) + 1
                Case VIEW_CATEGORY_UNKNOWN_DEPOSIT: counts(3) = counts(3) + 1
            End Select
            statusText = CellText(statusValues(r, 1))
            If statusText = ANALYSIS_STATUS_FOLLOWUP Then followupCount = followupCount + 1
            If Len(statusText) = 0 Or statusText = ANALYSIS_STATUS_UNREVIEWED Then _
                unreviewedCount = unreviewedCount + 1
        Next r
    End If

    UpdateCategoryButtonCaptions ws, categoryText, counts
    If manualMode Then
        RefreshCashManualSelectionPanel ws
    ElseIf wsResult Is Nothing Or lastResultRow < 2 Then
        ClearCashAnalysisCandidatePanel ws, categoryText, counts, unreviewedCount, followupCount
        ShowAllCashViewRows ws
    Else
        groupID = CellText(ws.Range(VIEW_STATE_GROUP_ID).Value)
        resultRow = FindCashAnalysisResultRow(categoryValues, groupValues, categoryText, groupID, _
                                               currentIndex, categoryCount)
        If resultRow = 0 Then
            ClearCashAnalysisCandidatePanel ws, categoryText, counts, unreviewedCount, followupCount
            ShowAllCashViewRows ws
        Else
            ws.Range(VIEW_STATE_GROUP_ID).Value = CellText(wsResult.Cells(resultRow, ANALYSIS_RESULT_GROUP_ID_COL).Value)
            ws.Range(VIEW_STATE_RESULT_ROW).Value = CStr(resultRow)
            ws.Range(VIEW_STATE_MODE).Value = modeText
            candidateRef = CellText(ws.Range(VIEW_STATE_CANDIDATE_REF).Value)
            If Len(candidateRef) > 0 And SheetExists(SH_WORK_ANALYSIS_GROUP) Then
                Set wsGroup = GetSheet(SH_WORK_ANALYSIS_GROUP)
                groupRow = FindCashAnalysisAlternativeRow( _
                               wsGroup, _
                               CellText(wsResult.Cells(resultRow, ANALYSIS_RESULT_GROUP_ID_COL).Value), _
                               candidateRef)
            End If
            If groupRow > 0 Then
                RenderCashAnalysisAlternativeCandidate ws, wsResult, resultRow, _
                    wsGroup, groupRow, currentIndex, categoryCount, counts, _
                    unreviewedCount, followupCount, modeText
                txIDList = CellText(wsGroup.Cells(groupRow, 5).Value)
            Else
                '�ĕ��͂ő�֌�₪�������ꍇ�́A�����O���[�v�̑�\�ֈ��S�ɖ߂��B
                ws.Range(VIEW_STATE_CANDIDATE_REF).ClearContents
                RenderCashAnalysisCandidate ws, wsResult, resultRow, currentIndex, categoryCount, _
                                            counts, unreviewedCount, followupCount, modeText
                txIDList = CellText(wsResult.Cells(resultRow, ANALYSIS_RESULT_TX_IDS_COL).Value)
            End If
            ApplyCashAnalysisRowFilter ws, txIDList, modeText
        End If
    End If
    AdjustCashAnalysisPanelRowHeights ws
    ApplyCashAnalysisPanelValidation ws
    UpdateCashAnalysisStatusStyle ws
    ProtectCashAnalysisViewSheet
    If workbookWasSaved Then ThisWorkbook.Saved = True
    If selectFirstVisible Then SelectFirstVisibleCashAnalysisRow ws
    If Not TryRestoreCashAnalysisEnableEvents( _
               previousEvents, "RefreshCashAnalysisPanel", eventStateDetail) Then _
        Err.Raise vbObjectError + 5104, "RefreshCashAnalysisPanel", eventStateDetail
    eventsCaptured = False
    Exit Sub
EH:
    errorNumber = Err.Number
    errorSource = Err.Source
    errorDescription = Err.Description
    If IsCashAnalysisRecoveryFatal(errorNumber, errorSource) Then
        Call TryStopCashAnalysisEventsForRecovery(convergenceDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    If eventsCaptured Then
        eventsReadyForRecovery = _
            TrySetCashAnalysisEnableEventsExact(False, stopDetail)
        If Not eventsReadyForRecovery Then _
            eventsReadyForRecovery = _
                TrySetCashAnalysisEnableEventsExact(False, stopRetryDetail)
        If Not eventsReadyForRecovery Then _
            stopDetail = "����=" & stopDetail & " / �Ď��s=" & stopRetryDetail
    End If
    If Not eventsReadyForRecovery Then
        If eventsCaptured Then
            AppendCashAnalysisRollbackDetail recoveryDetail, _
                "�ĕی�O��Excel�C�x���g���~���ēǖ߂��m�F�ł��܂���: " & _
                stopDetail
        ElseIf Len(stopDetail) > 0 Then
            AppendCashAnalysisRollbackDetail recoveryDetail, _
                "Excel�C�x���g�̊J�n��Ԃ��擾�ł����A" & _
                "��~�̓ǖ߂��m�F�ɂ����s�������ߌ��ݏ�Ԃ͕s���ł�: " & _
                stopDetail
        Else
            AppendCashAnalysisRollbackDetail recoveryDetail, _
                "Excel�C�x���g�̊J�n��Ԃƌ��ݏ�Ԃ��m�F�ł��܂���ł����B"
        End If
        AppendCashAnalysisRollbackDetail recoveryDetail, _
            "�C�x���g��~���m�F�̂��߁A�u�b�N�̍ĕی��" & _
            "Recovery��Ԃ̏����݂��s���܂���ł����B"
    End If

    If eventsReadyForRecovery Then
        protectOK = TryProtectCashAnalysisViewAfterFailure( _
                        ws, "RefreshCashAnalysisPanel", False, recoveryDetail, _
                        protectionRecoveryAttempted, _
                        protectionRecoveryFailed, _
                        protectionRecoveryConfirmed)
        '�ĕی�̓���Recovery/lease���C�x���g�l��ύX�����邽�߁A
        '����Recovery���f���O�ɊO����False����蒼���B
        eventsReadyForRecovery = _
            TryStopCashAnalysisEventsForRecovery(postProtectStopDetail)
        If Not eventsReadyForRecovery Then _
            AppendCashAnalysisRollbackDetail recoveryDetail, _
                "�ĕی쏈�����Excel�C�x���g��~���m�F�ł��܂���B" & _
                "���ݏ�Ԃ͕s���ł�: " & postProtectStopDetail
    End If

    If protectionRecoveryFailed Then
        recoveryFatal = True
        errorNumber = vbObjectError + 5194
        errorSource = "CashAnalysisRecoveryFatal/RefreshCashAnalysisPanel"
        AppendCashAnalysisRollbackDetail errorDescription, _
            "�ĕی쒆��Recovery�����ݒ肪��O�I�����܂����B"
    ElseIf protectionRecoveryAttempted Then
        recoveryConfirmed = protectionRecoveryConfirmed
    ElseIf eventsReadyForRecovery And Not protectOK Then
        On Error Resume Next
        Err.Clear
        EnforceRollbackRecoveryState recoveryDetail
        recoveryErrorNumber = Err.Number
        recoveryErrorDescription = Err.Description
        Err.Clear
        On Error GoTo 0
        '��O�l��ۑ����������False����蒼���BEnforce���s���́A
        '�Â�Recovery�l�̓ǎ��A�u�b�N�����݁A�J�n�l�������s��Ȃ��B
        eventsReadyForRecovery = _
            TryStopCashAnalysisEventsForRecovery(postEnforceStopDetail)
        If recoveryErrorNumber <> 0 Then
            recoveryFatal = True
            errorNumber = vbObjectError + 5194
            errorSource = "CashAnalysisRecoveryFatal/RefreshCashAnalysisPanel"
            AppendCashAnalysisRollbackDetail recoveryDetail, _
                "�v������Ԃ̋����ݒ�G���[: Err " & _
                CStr(recoveryErrorNumber) & " " & recoveryErrorDescription
        ElseIf eventsReadyForRecovery Then
            recoveryConfirmed = _
                CashAnalysisRecoveryStateIsConfirmedExact(recoveryDetail)
            If recoveryConfirmed Then _
                applicationStateConfirmed = _
                    CashAnalysisApplicationStateAllowsEntryRestore( _
                        True, recoveryDetail)
            If applicationStateConfirmed Then _
                eventsReadyForRecovery = _
                    TryStopCashAnalysisEventsForRecovery( _
                        finalRecoveryStopDetail)
        Else
            AppendCashAnalysisRollbackDetail recoveryDetail, _
                "Recovery�������Excel�C�x���g��~���m�F�ł��Ȃ����߁A" & _
                "������Ԃ�ǂݎ�炸�J�n�l�ւ��߂��܂���B���ݏ�Ԃ͕s���ł�: " & _
                postEnforceStopDetail
        End If
        recoveryFatal = True
        errorNumber = vbObjectError + 5194
        errorSource = "CashAnalysisRecoveryFatal/RefreshCashAnalysisPanel"
        If Not recoveryConfirmed Then _
            AppendCashAnalysisRollbackDetail recoveryDetail, _
                "�����Recovery��d��Ԃ������m�F�ł��܂���B"
        If recoveryConfirmed And Not applicationStateConfirmed Then _
            AppendCashAnalysisRollbackDetail recoveryDetail, _
                "Recovery�m�F���Application��Ԃ������m�F�ł��܂���B"
        If applicationStateConfirmed And Not eventsReadyForRecovery Then _
            AppendCashAnalysisRollbackDetail recoveryDetail, _
                "Application��Ԋm�F���Excel�C�x���gFalse������" & _
                "�m�F�ł��܂���: " & finalRecoveryStopDetail
        eventsReadyForRecovery = _
            TryStopCashAnalysisEventsForRecovery(convergenceDetail)
        eventsCaptured = False
        Err.Raise vbObjectError + 5194, _
                  "CashAnalysisRecoveryFatal/RefreshCashAnalysisPanel", _
                  errorDescription & " / " & recoveryDetail
    End If

    If eventsCaptured Then
        safeToRestoreEntry = eventsReadyForRecovery And _
                             Not recoveryFatal And _
                             (protectOK Or recoveryConfirmed)
        If safeToRestoreEntry Then _
            safeToRestoreEntry = _
                CashAnalysisApplicationStateAllowsEntryRestore( _
                    previousEvents, recoveryDetail)
        If safeToRestoreEntry Then
            eventsReadyForRecovery = _
                TryStopCashAnalysisEventsForRecovery(eventStateDetail)
            safeToRestoreEntry = eventsReadyForRecovery
        End If
        If safeToRestoreEntry Then
            If Not TryRestoreCashAnalysisEnableEvents( _
                       previousEvents, "RefreshCashAnalysisPanel", _
                       eventStateDetail) Then _
                AppendCashAnalysisRollbackDetail recoveryDetail, eventStateDetail
        ElseIf TryStopCashAnalysisEventsForRecovery(convergenceDetail) Then
            AppendCashAnalysisRollbackDetail recoveryDetail, _
                "�ĕی�܂���Recovery�������m�F�ł��Ȃ����߁A" & _
                "�J�n���C�x���g�l�֖߂���False�Œ�~���܂����B"
        Else
            AppendCashAnalysisRollbackDetail recoveryDetail, _
                "�ĕی�܂���Recovery�������m�F�ł����A" & _
                "Excel�C�x���g��False�����ɂ����s���܂����B���ݏ�Ԃ͕s���ł�: " & _
                convergenceDetail
        End If
    End If
    eventsCaptured = False
    If Len(recoveryDetail) > 0 Then _
        errorDescription = errorDescription & " / �����m�F: " & recoveryDetail
    If Len(errorSource) = 0 Then errorSource = "RefreshCashAnalysisPanel"
    Err.Raise errorNumber, errorSource, errorDescription
End Sub

Private Sub AdjustCashAnalysisPanelRowHeights(ByVal ws As Worksheet)
    Dim expanded As Boolean
    Dim routeMaximum As Double, textMaximum As Double, memoMaximum As Double
    Dim actionText As String
    If ws Is Nothing Then Exit Sub
    expanded = (CellText(ws.Range(VIEW_STATE_PANEL_EXPANDED).Value) = "1")
    If expanded Then
        routeMaximum = 360
        textMaximum = 240
        memoMaximum = 240
        actionText = "�m�_�u���N���b�N�Ő܂肽���ށn"
    Else
        '�܂肽���ݎ��͓��e�ʂŌŒ�p�l�����c�֖c��܂Ȃ��悤�A
        '�e�s��݌v�ŏ����֌Œ肷��B�S���̓_�u���N���b�N�܂��͓W�J�Ŋm�F�ł���B
        routeMaximum = 31
        textMaximum = 38
        memoMaximum = 42
        actionText = "�m�_�u���N���b�N�œW�J�n"
    End If
    ws.Range("A6").Value = "���o���R�E�v�_" & vbLf & actionText
    ws.Range("A7").Value = "���؁E����" & vbLf & actionText
    ws.Range("A8").Value = "�m�F����" & vbLf & actionText
    ws.Rows(5).RowHeight = CashPanelTextRowHeight(CellText(ws.Range("H5").Value), 90, 31, routeMaximum)
    ws.Rows(6).RowHeight = CashPanelTextRowHeight(CellText(ws.Range("C6").Value), 150, 38, textMaximum)
    ws.Rows(7).RowHeight = CashPanelTextRowHeight(CellText(ws.Range("C7").Value), 150, 38, textMaximum)
    ws.Rows(8).RowHeight = CashPanelTextRowHeight(CellText(ws.Range("C8").Value), 150, 42, memoMaximum)
End Sub

Private Function CashPanelTextRowHeight(ByVal valueText As String, ByVal charactersPerLine As Long, _
                                        ByVal minimumHeight As Double, ByVal maximumHeight As Double) As Double
    Dim lineCount As Long
    Dim estimatedHeight As Double
    If charactersPerLine < 1 Then charactersPerLine = 1
    lineCount = ReadableTextLineCount(valueText, charactersPerLine)
    If lineCount < 1 Then lineCount = 1
    estimatedHeight = 18# * CDbl(lineCount) + 4#
    If estimatedHeight < minimumHeight Then estimatedHeight = minimumHeight
    If estimatedHeight > maximumHeight Then estimatedHeight = maximumHeight
    CashPanelTextRowHeight = estimatedHeight
End Function

Public Sub ToggleCashAnalysisPanelExpansion()
    Dim ws As Worksheet
    Dim workbookWasSaved As Boolean
    Dim previousEvents As Boolean, eventsCaptured As Boolean
    Dim eventsRestoreAttempted As Boolean, eventsReadyForRecovery As Boolean
    Dim actionMutationStarted As Boolean, protectOK As Boolean
    Dim safeToRestoreEntry As Boolean
    Dim eventStateDetail As String, stopDetail As String
    Dim convergenceDetail As String
    Dim errorNumber As Long, errorSource As String, errorDescription As String
    If Not SheetExists(SH_OUTPUT_TX) Then Exit Sub
    On Error GoTo EH
    Set ws = GetSheet(SH_OUTPUT_TX)
    workbookWasSaved = ThisWorkbook.Saved
    If Not TryGetCashAnalysisEnableEvents(previousEvents, eventStateDetail) Then _
        Err.Raise vbObjectError + 5119, "ToggleCashAnalysisPanelExpansion", _
                  "Excel�C�x���g�̊J�n��Ԃ��擾�ł��܂���ł����B " & eventStateDetail
    eventsCaptured = True
    If Not TrySetCashAnalysisEnableEventsExact(False, eventStateDetail) Then _
        Err.Raise vbObjectError + 5120, "ToggleCashAnalysisPanelExpansion", _
                  "�\���֑ؑO��Excel�C�x���g���~�ł��܂���ł����B " & eventStateDetail
    actionMutationStarted = True
    ws.Unprotect Password:=TOOL_PASSWORD
    If CellText(ws.Range(VIEW_STATE_PANEL_EXPANDED).Value) = "1" Then
        ws.Range(VIEW_STATE_PANEL_EXPANDED).Value = "0"
    Else
        ws.Range(VIEW_STATE_PANEL_EXPANDED).Value = "1"
    End If
    AdjustCashAnalysisPanelRowHeights ws
    ProtectCashAnalysisViewSheet
    If workbookWasSaved Then ThisWorkbook.Saved = True
    eventsRestoreAttempted = True
    If Not TryRestoreCashAnalysisEnableEvents( _
               previousEvents, "ToggleCashAnalysisPanelExpansion", _
               eventStateDetail) Then _
        Err.Raise vbObjectError + 5121, _
                  "ToggleCashAnalysisPanelExpansion", eventStateDetail
    eventsCaptured = False
    Exit Sub
EH:
    errorNumber = Err.Number
    errorSource = Err.Source
    errorDescription = Err.Description
    If IsCashAnalysisRecoveryFatal(errorNumber, errorSource) Then
        Call TryStopCashAnalysisEventsForRecovery(convergenceDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    If eventsCaptured Then
        If Not eventsRestoreAttempted Then _
            eventsReadyForRecovery = _
                TryStopCashAnalysisEventsForRecovery(stopDetail)
    End If
    If actionMutationStarted And Not eventsRestoreAttempted Then
        If eventsReadyForRecovery Then
            protectOK = TryProtectCashAnalysisViewAfterFailure( _
                            ws, "ToggleCashAnalysisPanelExpansion", _
                            False, errorDescription)
            safeToRestoreEntry = _
                CashAnalysisOuterLeaseMayRestoreAfterProtection( _
                    protectOK, errorDescription)
        Else
            AppendCashAnalysisRollbackDetail errorDescription, _
                "Excel�C�x���g��~��ǖ߂��m�F�ł��Ȃ����߁A" & _
                "�u�b�N�̍ĕی��Recovery�����݂��s���܂���ł����B " & _
                stopDetail
        End If
    End If
    If eventsCaptured And Not eventsRestoreAttempted Then
        eventsRestoreAttempted = True
        If Not actionMutationStarted Or safeToRestoreEntry Then
            If Not TryRestoreCashAnalysisEnableEvents( _
                       previousEvents, _
                       "ToggleCashAnalysisPanelExpansion/�G���[�I��", _
                       eventStateDetail) Then _
                AppendCashAnalysisRollbackDetail errorDescription, _
                    eventStateDetail
        ElseIf TryStopCashAnalysisEventsForRecovery(convergenceDetail) Then
            AppendCashAnalysisRollbackDetail errorDescription, _
                "�ĕی�܂���Recovery�������m�F�ł��Ȃ����߁A" & _
                "�J�n���C�x���g�l�֖߂���False�Œ�~���܂����B"
        Else
            AppendCashAnalysisRollbackDetail errorDescription, _
                "���S��Ԃ������m�F�ł����AExcel�C�x���g��False�����ɂ�" & _
                "���s���܂����B���ݏ�Ԃ͕s���ł�: " & convergenceDetail
        End If
    End If
    eventsCaptured = False
    MsgBox "���͐������̕\����؂�ւ����܂���ł����B" & vbCrLf & _
           "Err " & CStr(errorNumber) & ": " & errorDescription, vbExclamation
End Sub

Private Sub RenderCashAnalysisCandidate(ByVal ws As Worksheet, ByVal wsResult As Worksheet, _
                                        ByVal resultRow As Long, ByVal currentIndex As Long, _
                                        ByVal categoryCount As Long, ByRef counts() As Long, _
                                        ByVal unreviewedCount As Long, ByVal followupCount As Long, _
                                        ByVal modeText As String)
    Dim categoryText As String, statusText As String, alternativeCount As Long
    Dim priorityText As String, manualStoredKey As String
    Dim dateText As String, routeText As String, pointText As String
    Dim constraintText As String, personClassText As String
    Dim isManualCandidate As Boolean
    categoryText = CashViewCategoryForResult(CellText(wsResult.Cells(resultRow, 2).Value))
    statusText = CellText(wsResult.Cells(resultRow, ANALYSIS_RESULT_STATUS_COL).Value)
    If Len(statusText) = 0 Then statusText = ANALYSIS_STATUS_UNREVIEWED
    If IsNumeric(wsResult.Cells(resultRow, ANALYSIS_RESULT_ALTERNATIVE_COUNT_COL).Value) Then _
        alternativeCount = CLng(wsResult.Cells(resultRow, ANALYSIS_RESULT_ALTERNATIVE_COUNT_COL).Value)
    If alternativeCount < 1 Then alternativeCount = 1

    priorityText = CellText(wsResult.Cells(resultRow, 1).Value)
    dateText = CashAnalysisNormalizeTimeEvidenceText( _
                   CellText(wsResult.Cells(resultRow, 3).Value))
    routeText = CashAnalysisNormalizeTimeEvidenceText( _
                    CellText(wsResult.Cells(resultRow, 5).Value))
    pointText = CashAnalysisNormalizeTimeEvidenceText( _
                    CellText(wsResult.Cells(resultRow, 6).Value))
    constraintText = CashAnalysisNormalizeTimeEvidenceText( _
                         CellText(wsResult.Cells(resultRow, 7).Value))
    personClassText = CashAnalysisTransferPersonClass(categoryText, routeText)
    isManualCandidate = CashAnalysisResultIsManual(wsResult, resultRow, manualStoredKey)
    If Len(personClassText) > 0 Then
        If Len(routeText) = 0 Then
            routeText = personClassText
        ElseIf InStr(1, routeText, personClassText, vbBinaryCompare) = 0 Then
            routeText = personClassText & "�b" & routeText
        End If
    End If
    If isManualCandidate Then
        If InStr(1, constraintText, "�蓮�I��E������", vbBinaryCompare) = 0 Then _
            constraintText = CashAnalysisAppendText( _
                                 constraintText, "�蓮�I��E������", " / ")
    End If
    If alternativeCount > 1 Then _
        constraintText = CashAnalysisAppendText( _
                             constraintText, _
                             "���O���[�v" & CStr(alternativeCount) & _
                             "�����̑�\���", " / ")
    pointText = CashAnalysisAppendText( _
                    pointText, _
                    CashAnalysisReviewProgressText(unreviewedCount, followupCount), _
                    vbLf)
    ws.Range("F1").Value = CashAnalysisCompactHeader( _
                               categoryText, currentIndex, categoryCount, _
                               priorityText, 0, 0, isManualCandidate)
    ws.Range("C3").Value = statusText
    ws.Range("C5").Value = dateText
    ws.Range("H5").Value = routeText
    ws.Range("C6").Value = pointText
    ws.Range("C7").Value = constraintText
    ws.Range("C8").Value = CellText(wsResult.Cells(resultRow, ANALYSIS_RESULT_MEMO_COL).Value)
    SetShapeCaption ws, "CycleCashAnalysisViewMode", "�\��: " & modeText
    If isManualCandidate Then
        SetShapeCaption ws, "CashAnalysisSecondaryAction", "�蓮���𖳌���"
        SetViewButtonColors ws, "CashAnalysisSecondaryAction", _
                            RGB(254, 242, 242), RGB(220, 38, 38), RGB(153, 27, 27)
    Else
        SetShapeCaption ws, "CashAnalysisSecondaryAction", "�蓮����I��"
        SetViewButtonColors ws, "CashAnalysisSecondaryAction", _
                            RGB(255, 255, 255), RGB(203, 213, 225), RGB(30, 64, 175)
    End If
    ws.Range("C3:D3").Locked = ThisWorkbook.ReadOnly
    ws.Range("C8:M8").Locked = ThisWorkbook.ReadOnly
End Sub

Private Sub RenderCashAnalysisAlternativeCandidate( _
        ByVal ws As Worksheet, ByVal wsResult As Worksheet, _
        ByVal resultRow As Long, ByVal wsGroup As Worksheet, _
        ByVal groupRow As Long, ByVal currentIndex As Long, _
        ByVal categoryCount As Long, ByRef counts() As Long, _
        ByVal unreviewedCount As Long, ByVal followupCount As Long, _
        ByVal modeText As String)
    Dim categoryText As String, groupID As String, sourceSheet As String
    Dim sourceKey As String, txIDList As String, statusText As String, memoText As String
    Dim dateText As String, routeText As String, pointText As String, constraintText As String
    Dim priorityText As String, personClassText As String
    Dim sourceRow As Long, candidatePosition As Long, candidateCount As Long
    Dim isManualCandidate As Boolean
    Dim txPersonMap As Object

    If ws Is Nothing Or wsResult Is Nothing Or wsGroup Is Nothing Then _
        Err.Raise vbObjectError + 4992, "RenderCashAnalysisAlternativeCandidate", _
                  "��֌��̕\�������擾�ł��܂���B"
    categoryText = CashViewCategoryForResult(CellText(wsResult.Cells(resultRow, 2).Value))
    If categoryText <> VIEW_CATEGORY_TRANSFER Then _
        Err.Raise vbObjectError + 4993, "RenderCashAnalysisAlternativeCandidate", _
                  "�����ړ��ȊO�ɑ�֌�₪�w�肳��Ă��܂��B"
    groupID = CellText(wsResult.Cells(resultRow, ANALYSIS_RESULT_GROUP_ID_COL).Value)
    ReadCashAnalysisAlternativeSource wsGroup, groupRow, groupID, _
        sourceSheet, sourceRow, sourceKey, txIDList, priorityText, statusText, memoText, _
        dateText, routeText, pointText, constraintText, isManualCandidate

    Set txPersonMap = CashAnalysisTransactionPersonMap()
    personClassText = CashAlternativePersonClass(txIDList, txPersonMap)
    routeText = personClassText & "�b" & routeText
    CashAnalysisGroupCandidatePosition wsGroup, groupID, groupRow, txPersonMap, _
                                       candidatePosition, candidateCount
    If candidatePosition < 2 Or candidateCount < candidatePosition Then _
        Err.Raise vbObjectError + 4994, "RenderCashAnalysisAlternativeCandidate", _
                  "��֌��̏z�ʒu���m��ł��܂���B"
    If Not IsNumeric(wsResult.Cells(resultRow, _
                                    ANALYSIS_RESULT_ALTERNATIVE_COUNT_COL).Value) Then _
        Err.Raise vbObjectError + 4994, "RenderCashAnalysisAlternativeCandidate", _
                  "��֌��̕\�����������l�ł͂���܂���B"
    If CLng(wsResult.Cells(resultRow, _
                           ANALYSIS_RESULT_ALTERNATIVE_COUNT_COL).Value) <> candidateCount Then _
        Err.Raise vbObjectError + 4994, "RenderCashAnalysisAlternativeCandidate", _
                  "��֌��̕\�������Ɠ����O���[�v��������v���܂���B"
    constraintText = CashAnalysisAppendText(constraintText, _
        "������������L�����։��� " & CStr(candidateCount) & _
        "���B���݂͑�\�Ƃ͕ʂ̉�����\�����Ă��܂��B", " / ")
    If isManualCandidate Then
        If InStr(1, constraintText, "�蓮�I��E������", vbBinaryCompare) = 0 Then _
            constraintText = CashAnalysisAppendText( _
                                 constraintText, "�蓮�I��E������", " / ")
    End If
    pointText = CashAnalysisAppendText( _
                    CashAnalysisNormalizeTimeEvidenceText(pointText), _
                    CashAnalysisReviewProgressText(unreviewedCount, followupCount), _
                    vbLf)
    ws.Range("F1").Value = CashAnalysisCompactHeader( _
                               categoryText, currentIndex, categoryCount, _
                               priorityText, candidatePosition, candidateCount, _
                               isManualCandidate)
    ws.Range("C3").Value = statusText
    ws.Range("C5").Value = CashAnalysisNormalizeTimeEvidenceText(dateText)
    ws.Range("H5").Value = CashAnalysisNormalizeTimeEvidenceText(routeText)
    ws.Range("C6").Value = pointText
    ws.Range("C7").Value = CashAnalysisNormalizeTimeEvidenceText(constraintText)
    ws.Range("C8").Value = memoText
    SetShapeCaption ws, "CycleCashAnalysisViewMode", "�\��: " & modeText
    If isManualCandidate Then
        SetShapeCaption ws, "CashAnalysisSecondaryAction", "�蓮���𖳌���"
        SetViewButtonColors ws, "CashAnalysisSecondaryAction", _
                            RGB(254, 242, 242), RGB(220, 38, 38), RGB(153, 27, 27)
    Else
        SetShapeCaption ws, "CashAnalysisSecondaryAction", "�蓮����I��"
        SetViewButtonColors ws, "CashAnalysisSecondaryAction", _
                            RGB(255, 255, 255), RGB(203, 213, 225), RGB(30, 64, 175)
    End If
    ws.Range("C3:D3").Locked = ThisWorkbook.ReadOnly
    ws.Range("C8:M8").Locked = ThisWorkbook.ReadOnly
End Sub

Private Sub ReadCashAnalysisAlternativeSource( _
        ByVal wsGroup As Worksheet, ByVal groupRow As Long, ByVal expectedGroupID As String, _
        ByRef sourceSheet As String, ByRef sourceRow As Long, ByRef sourceKey As String, _
        ByRef txIDList As String, ByRef priorityText As String, ByRef statusText As String, _
        ByRef memoText As String, ByRef dateText As String, ByRef routeText As String, _
        ByRef pointText As String, ByRef constraintText As String, _
        ByRef isManualCandidate As Boolean)
    Dim wsSource As Worksheet, sourceLastRow As Long
    If wsGroup Is Nothing Then _
        Err.Raise vbObjectError + 4995, "ReadCashAnalysisAlternativeSource", _
                  "��֌��̓����\���擾�ł��܂���B"
    If groupRow < 2 Or groupRow > LastUsedRowInSheet(wsGroup) Then _
        Err.Raise vbObjectError + 4995, "ReadCashAnalysisAlternativeSource", _
                  "��֌��̓����s��������܂���B"
    RequireAnalysisReviewConstantRange _
        wsGroup.Range(wsGroup.Cells(groupRow, 1), _
                      wsGroup.Cells(groupRow, ANALYSIS_GROUP_LAST_COL)), _
        "��֌��̓����Q��"
    If StrComp(CellText(wsGroup.Cells(groupRow, 1).Value), _
               expectedGroupID, vbBinaryCompare) <> 0 Or _
       StrComp(CellText(wsGroup.Cells(groupRow, 7).Value), _
               "���", vbBinaryCompare) <> 0 Then _
        Err.Raise vbObjectError + 4996, "ReadCashAnalysisAlternativeSource", _
                  "�\�����O���[�v�Ƒ�֌��̓����Q�Ƃ���v���܂���B"

    sourceSheet = CellText(wsGroup.Cells(groupRow, 2).Value)
    sourceRow = CLng(Val(CellText(wsGroup.Cells(groupRow, 3).Value)))
    sourceKey = CellText(wsGroup.Cells(groupRow, 4).Value)
    txIDList = CellText(wsGroup.Cells(groupRow, 5).Value)
    priorityText = CellText(wsGroup.Cells(groupRow, 6).Value)
    If Len(sourceKey) = 0 Or Len(txIDList) = 0 Then _
        Err.Raise vbObjectError + 4997, "ReadCashAnalysisAlternativeSource", _
                  "��֌��̊m�F�L�[�܂��͍\�����ID������܂���B"
    If Not SheetExists(sourceSheet) Then _
        Err.Raise vbObjectError + 4998, "ReadCashAnalysisAlternativeSource", _
                  "��֌��̓������\������܂���B"
    Set wsSource = GetSheet(sourceSheet)
    sourceLastRow = LastUsedRowInSheet(wsSource)
    If sourceRow < 2 Or sourceRow > sourceLastRow Then _
        Err.Raise vbObjectError + 4999, "ReadCashAnalysisAlternativeSource", _
                  "��֌��̓������s������܂���B"

    Select Case sourceSheet
        Case SH_ANALYSIS_SHIFT
            RequireAnalysisReviewConstantRange _
                wsSource.Range(wsSource.Cells(sourceRow, 1), _
                               wsSource.Cells(sourceRow, SHIFT_ANALYSIS_LAST_COL)), _
                "�����V�t�g��֌��"
            If StrComp(CellText(wsSource.Cells(sourceRow, SHIFT_ANALYSIS_KEY_COL).Value), _
                       sourceKey, vbBinaryCompare) <> 0 Then _
                Err.Raise vbObjectError + 5000, "ReadCashAnalysisAlternativeSource", _
                          "�����V�t�g��֌��̊m�F�L�[����v���܂���B"
            statusText = CashAnalysisStatusOrDefault( _
                             wsSource.Cells(sourceRow, SHIFT_ANALYSIS_STATUS_COL).Value)
            memoText = CellText(wsSource.Cells(sourceRow, SHIFT_ANALYSIS_MEMO_COL).Value)
            dateText = CashAnalysisPeriodText(wsSource.Cells(sourceRow, 9).Value, _
                                              wsSource.Cells(sourceRow, 19).Value)
            routeText = CashAnalysisPartyAccount( _
                            wsSource.Cells(sourceRow, 11).Value, _
                            wsSource.Cells(sourceRow, 12).Value, _
                            wsSource.Cells(sourceRow, 13).Value, _
                            wsSource.Cells(sourceRow, 14).Value, _
                            wsSource.Cells(sourceRow, 15).Value, _
                            wsSource.Cells(sourceRow, 16).Value) & " �� " & _
                        CashAnalysisPartyAccount( _
                            wsSource.Cells(sourceRow, 21).Value, _
                            wsSource.Cells(sourceRow, 22).Value, _
                            wsSource.Cells(sourceRow, 23).Value, _
                            wsSource.Cells(sourceRow, 24).Value, _
                            wsSource.Cells(sourceRow, 25).Value, _
                            wsSource.Cells(sourceRow, 26).Value)
            pointText = CellText(wsSource.Cells(sourceRow, 1).Value) & "�E" & _
                        CellText(wsSource.Cells(sourceRow, 3).Value) & "�E" & _
                        CellText(wsSource.Cells(sourceRow, 4).Value) & "�B" & _
                        CellText(wsSource.Cells(sourceRow, 29).Value)
            constraintText = "�������x: " & CellText(wsSource.Cells(sourceRow, 5).Value) & _
                             " / �o��: " & CellText(wsSource.Cells(sourceRow, 6).Value) & _
                             " / ���z��: " & _
                             CashAnalysisAmountText(wsSource.Cells(sourceRow, 8).Value)
        Case SH_ANALYSIS_FLOW
            RequireAnalysisReviewConstantRange _
                wsSource.Range(wsSource.Cells(sourceRow, 1), _
                               wsSource.Cells(sourceRow, FLOW_ANALYSIS_LAST_COL)), _
                "�����t���[��֌��"
            If StrComp(CellText(wsSource.Cells(sourceRow, FLOW_ANALYSIS_KEY_COL).Value), _
                       sourceKey, vbBinaryCompare) <> 0 Then _
                Err.Raise vbObjectError + 5001, "ReadCashAnalysisAlternativeSource", _
                          "�����t���[��֌��̊m�F�L�[����v���܂���B"
            statusText = CashAnalysisStatusOrDefault( _
                             wsSource.Cells(sourceRow, FLOW_ANALYSIS_STATUS_COL).Value)
            memoText = CellText(wsSource.Cells(sourceRow, FLOW_ANALYSIS_MEMO_COL).Value)
            dateText = CellText(wsSource.Cells(sourceRow, 6).Value)
            routeText = CellText(wsSource.Cells(sourceRow, 12).Value)
            pointText = CellText(wsSource.Cells(sourceRow, 3).Value) & "�E" & _
                        CellText(wsSource.Cells(sourceRow, 4).Value) & "�B" & _
                        CellText(wsSource.Cells(sourceRow, 16).Value)
            constraintText = "�������x: " & CellText(wsSource.Cells(sourceRow, 5).Value) & _
                             " / �N�I�_��: " & _
                             CashAnalysisAmountText(wsSource.Cells(sourceRow, 11).Value) & _
                             " / " & CellText(wsSource.Cells(sourceRow, 7).Value) & _
                             "�i�E" & CellText(wsSource.Cells(sourceRow, 8).Value) & "���"
        Case Else
            Err.Raise vbObjectError + 5002, "ReadCashAnalysisAlternativeSource", _
                      "��֌��̓������\�������ړ��ł͂���܂���B"
    End Select
    isManualCandidate = CashAnalysisSourceIsManual(sourceSheet, sourceRow, sourceKey)
End Sub

Private Function CashAnalysisStatusOrDefault(ByVal valueIn As Variant) As String
    CashAnalysisStatusOrDefault = CellText(valueIn)
    If Len(CashAnalysisStatusOrDefault) = 0 Then _
        CashAnalysisStatusOrDefault = ANALYSIS_STATUS_UNREVIEWED
End Function

Private Function CashAnalysisPartyAccount( _
        ByVal personValue As Variant, ByVal relationshipValue As Variant, _
        ByVal bankValue As Variant, ByVal branchValue As Variant, _
        ByVal typeValue As Variant, ByVal numberValue As Variant) As String
    Dim personText As String, accountText As String
    personText = CellText(personValue)
    If Len(personText) > 0 And Len(CellText(relationshipValue)) > 0 Then _
        personText = personText & "�i" & CellText(relationshipValue) & "�j"
    If Len(personText) > 0 Then personText = personText & " "
    accountText = Trim$(CellText(bankValue) & " " & CellText(branchValue) & " " & _
                        CellText(typeValue) & " " & CellText(numberValue))
    CashAnalysisPartyAccount = Trim$(personText & accountText)
End Function

Private Function CashAnalysisPeriodText(ByVal firstDate As Variant, _
                                        ByVal secondDate As Variant) As String
    Dim firstValue As Date, secondValue As Date
    If Not IsDate(firstDate) Or Not IsDate(secondDate) Then
        CashAnalysisPeriodText = CashAlternativeDateText(firstDate) & " �` " & _
                                 CashAlternativeDateText(secondDate)
        Exit Function
    End If
    firstValue = DateSerial(Year(CDate(firstDate)), Month(CDate(firstDate)), Day(CDate(firstDate)))
    secondValue = DateSerial(Year(CDate(secondDate)), Month(CDate(secondDate)), Day(CDate(secondDate)))
    If firstValue = secondValue Then
        CashAnalysisPeriodText = Format$(firstValue, "yyyy/m/d") & "�i�����j"
    ElseIf firstValue < secondValue Then
        CashAnalysisPeriodText = Format$(firstValue, "yyyy/m/d") & " �` " & _
                                 Format$(secondValue, "yyyy/m/d")
    Else
        CashAnalysisPeriodText = Format$(secondValue, "yyyy/m/d") & " �` " & _
                                 Format$(firstValue, "yyyy/m/d")
    End If
End Function

Private Function CashAnalysisAmountText(ByVal valueIn As Variant) As String
    If IsError(valueIn) Or IsNull(valueIn) Or IsEmpty(valueIn) Then
        CashAnalysisAmountText = "�v�m�F"
    ElseIf IsNumeric(valueIn) Then
        CashAnalysisAmountText = Format$(CDbl(valueIn), "#,##0.########")
    Else
        CashAnalysisAmountText = "�v�m�F"
    End If
End Function

Private Function CashAnalysisAppendText(ByVal currentText As String, _
                                        ByVal newText As String, _
                                        ByVal separatorText As String) As String
    If Len(newText) = 0 Then
        CashAnalysisAppendText = currentText
    ElseIf Len(currentText) = 0 Then
        CashAnalysisAppendText = newText
    Else
        CashAnalysisAppendText = currentText & separatorText & newText
    End If
End Function

Private Function CashAnalysisReviewProgressText(ByVal unreviewedCount As Long, _
                                                ByVal followupCount As Long) As String
    If unreviewedCount < 0 Then unreviewedCount = 0
    If followupCount < 0 Then followupCount = 0
    CashAnalysisReviewProgressText = _
        "�S�敪: ���m�F " & CStr(unreviewedCount) & _
        "�� / �v�ǉ����� " & CStr(followupCount) & "��"
End Function

Private Function CashAnalysisCompactHeader( _
        ByVal categoryText As String, ByVal currentIndex As Long, _
        ByVal categoryCount As Long, ByVal priorityText As String, _
        Optional ByVal candidatePosition As Long = 0, _
        Optional ByVal candidateCount As Long = 0, _
        Optional ByVal isManualCandidate As Boolean = False) As String
    'F1�͌Œ�34pt��1�s�����Ɏ��߂�B�l���敪�E�����E�S�敪�̊m�F�i������
    '������H5/C6/C7�֕\�����A�����ɂ͌��݈ʒu�ƒZ����Ԃ������c���B
    '�ďo���̋敪��4���ȓ��B�S�Ă̌�����Long�ő�l�ł��A�D��x8�����܂�
    '�ő�66���Ȃ̂ŁAShrinkToFit���ɏ������֏k�����钷���𐶐����Ȃ��B
    Dim resultText As String, shortPriority As String
    If currentIndex < 0 Then currentIndex = 0
    If categoryCount < 0 Then categoryCount = 0
    resultText = Trim$(categoryText) & " " & CStr(currentIndex) & "/" & _
                 CStr(categoryCount)
    If candidatePosition > 0 Then
        If candidateCount >= candidatePosition Then _
            resultText = resultText & "�b��� " & CStr(candidatePosition) & "/" & _
                         CStr(candidateCount)
    End If
    shortPriority = Trim$(Replace(Replace(priorityText, vbCr, " "), vbLf, " "))
    If Len(shortPriority) > 8 Then shortPriority = Left$(shortPriority, 8)
    If Len(shortPriority) > 0 Then resultText = resultText & "�b�D�� " & shortPriority
    If isManualCandidate Then resultText = resultText & "�b�蓮"
    CashAnalysisCompactHeader = resultText
End Function

Private Function CashAnalysisTransferPersonClass(ByVal categoryText As String, _
                                                 ByVal routeText As String) As String
    If categoryText <> VIEW_CATEGORY_TRANSFER Then Exit Function
    If Left$(routeText, Len(VIEW_PERSON_DIFFERENT) + 1) = _
       VIEW_PERSON_DIFFERENT & "�b" Then
        CashAnalysisTransferPersonClass = VIEW_PERSON_DIFFERENT
    ElseIf Left$(routeText, Len(VIEW_PERSON_SAME) + 1) = VIEW_PERSON_SAME & "�b" Then
        CashAnalysisTransferPersonClass = VIEW_PERSON_SAME
    Else
        Err.Raise vbObjectError + 4975, "CashAnalysisTransferPersonClass", _
                  "�����ړ����ɐl��ID�ɂ��敪������܂���B" & _
                  "�����ł͑�ւł��܂���B�ĕ��͂��Ă��������B"
    End If
End Function

Private Function CashAnalysisNormalizeTimeEvidenceText(ByVal valueText As String) As String
    valueText = Replace(valueText, String$(2, "-") & ":" & String$(2, "-"), _
                        "�����L�ڂȂ�", 1, -1, vbBinaryCompare)
    valueText = Replace(valueText, "����" & "�E����" & "���m��" & _
                        "�i�V�t�g" & "����j", _
                        "�����������s��", 1, -1, vbBinaryCompare)
    valueText = Replace(valueText, "����" & "�E����" & "���m��", _
                        "�����������s��", 1, -1, vbBinaryCompare)
    valueText = Replace(valueText, "����" & "�E�����s��", _
                        "�����������s��", 1, -1, vbBinaryCompare)
    valueText = Replace(valueText, "����" & "����" & "����", _
                        "�����������s��", 1, -1, vbBinaryCompare)
    valueText = Replace(valueText, "����" & "��" & "����", _
                        "�����������s��", 1, -1, vbBinaryCompare)
    valueText = Replace(valueText, "�ꕔ����" & "�s��", _
                        "�ꕔ�����L�ڂȂ�", 1, -1, vbBinaryCompare)
    valueText = Replace(valueText, "����" & "�s��", _
                        "�����L�ڂȂ�", 1, -1, vbBinaryCompare)
    CashAnalysisNormalizeTimeEvidenceText = valueText
End Function

Public Function CashAnalysisPersonDisplayRegressionTest() As Boolean
    Dim txPersonMap As Object
    Dim totalWithdrawal As Double, totalDeposit As Double
    Dim withdrawalCount As Long, depositCount As Long
    Dim fitAtReturnedZoom As Boolean, maximumLongValue As Long
    On Error GoTo TestFailed
    If CashAnalysisTransferPersonClass( _
           VIEW_CATEGORY_TRANSFER, VIEW_PERSON_DIFFERENT & "�b�b�ˉ�") <> _
       VIEW_PERSON_DIFFERENT Then Exit Function
    If CashAnalysisTransferPersonClass( _
           VIEW_CATEGORY_TRANSFER, VIEW_PERSON_SAME & "�b�b�ˍb") <> _
       VIEW_PERSON_SAME Then Exit Function
    If Len(CashAnalysisTransferPersonClass( _
           VIEW_CATEGORY_UNKNOWN_WITHDRAW, "�b")) <> 0 Then Exit Function
    If CashAnalysisNormalizeTimeEvidenceText( _
           String$(2, "-") & ":" & String$(2, "-")) <> "�����L�ڂȂ�" Then Exit Function
    If CashAnalysisNormalizeTimeEvidenceText( _
           "����" & "�E����" & "���m��") <> "�����������s��" Then Exit Function
    If CashAnalysisPeriodText(DateSerial(2026, 1, 1), DateSerial(2026, 1, 1)) <> _
       "2026/1/1�i�����j" Then Exit Function
    If CashAnalysisPeriodText(DateSerial(2026, 1, 3), DateSerial(2026, 1, 1)) <> _
       "2026/1/1 �` 2026/1/3" Then Exit Function
    Set txPersonMap = CreateObject("Scripting.Dictionary")
    txPersonMap.CompareMode = vbTextCompare
    txPersonMap.Add "T1", "P1"
    txPersonMap.Add "T2", "P2"
    If CashAlternativePersonClass("T1;T2", txPersonMap) <> _
       VIEW_PERSON_DIFFERENT Then Exit Function
    txPersonMap("T2") = "P1"
    If CashAlternativePersonClass("T1;T2", txPersonMap) <> _
       VIEW_PERSON_SAME Then Exit Function
    AccumulateCashManualTotals 100#, 80#, totalWithdrawal, totalDeposit, _
                               withdrawalCount, depositCount
    If totalWithdrawal <> 100# Or totalDeposit <> 80# Or _
       totalDeposit - totalWithdrawal <> -20# Then Exit Function
    If withdrawalCount <> 1 Or depositCount <> 1 Then Exit Function
    If CashAnalysisViewVersion() <> "6" Then Exit Function
    If CashAnalysisFitZoomPercent(900#, 960#, 387#, 405#, _
                                  fitAtReturnedZoom) <> 88 Then _
        Exit Function
    If Not fitAtReturnedZoom Then Exit Function
    '1366�~768�EWindows 125%���|�C���g���Z���A���E58pt�E�㉺135pt���T���B
    If CashAnalysisFitZoomPercent(900#, 761.6, 387#, 325.8, _
                                  fitAtReturnedZoom) <> 84 Then _
        Exit Function
    If Not fitAtReturnedZoom Then Exit Function
    '����ɍ�����297pt�܂ŋ��߂��ꍇ��80%���ێ����A���e�ς݂Ƃ͈���Ȃ��B
    If CashAnalysisFitZoomPercent(900#, 760#, 387#, 297#, _
                                  fitAtReturnedZoom) <> 80 Then _
        Exit Function
    If fitAtReturnedZoom Then Exit Function
    If CashAnalysisFitZoomPercent(900#, 500#, 387#, 200#, _
                                  fitAtReturnedZoom) <> 80 Then _
        Exit Function
    If fitAtReturnedZoom Then Exit Function
    If CashAnalysisFitZoomPercent(0#, 0#, 0#, 0#, _
                                  fitAtReturnedZoom) <> 88 Then Exit Function
    If Not fitAtReturnedZoom Then Exit Function
    If StrComp(CashAnalysisCompactHeader( _
                   VIEW_CATEGORY_TRANSFER, 12, 345, "��", 2, 4, True), _
               "�����ړ� 12/345�b��� 2/4�b�D�� ���b�蓮", _
               vbBinaryCompare) <> 0 Then Exit Function
    If StrComp(CashAnalysisReviewProgressText(7, 3), _
               "�S�敪: ���m�F 7�� / �v�ǉ����� 3��", _
               vbBinaryCompare) <> 0 Then Exit Function
    maximumLongValue = 2147483647
    If Len(CashAnalysisCompactHeader( _
               VIEW_CATEGORY_TRANSFER, maximumLongValue, maximumLongValue, _
               String$(40, "�D"), maximumLongValue, maximumLongValue, True)) > 66 Then _
        Exit Function
    If ExcelColorContrastRatio(RGB(15, 23, 42), RGB(255, 255, 255)) < 4.5 Then _
        Exit Function
    If ReadableFontColor(RGB(15, 23, 42), RGB(15, 23, 42)) <> _
       RGB(255, 255, 255) Then Exit Function
    If ExcelColorContrastRatio(RGB(120, 120, 120), _
            ReadableFontColor(RGB(120, 120, 120), RGB(120, 120, 120))) < 4.5 Then _
        Exit Function
    If Not StrictVariantValuesMatch(CLng(1), CDbl(1)) Then Exit Function
    If StrictVariantValuesMatch("1", CDbl(1)) Then Exit Function
    CashAnalysisPersonDisplayRegressionTest = True
    Exit Function
TestFailed:
    Err.Clear
End Function

'�V�[�g��ύX�����AS45�̏����ƑO��z�����S�ɑΏ̂ł��邱�Ƃ��m�F����B
Public Function CashAnalysisNavigationRegressionTest() As Boolean
    Dim currentIndex As Long, nextIndex As Long, previousIndex As Long
    On Error GoTo TestFailed
    If CashAnalysisNavigationRank("��\", VIEW_PERSON_SAME) <> 0 Then Exit Function
    If CashAnalysisNavigationRank("��\", VIEW_PERSON_DIFFERENT) <> 0 Then Exit Function
    If CashAnalysisNavigationRank("���", VIEW_PERSON_DIFFERENT) <> 1 Then Exit Function
    If CashAnalysisNavigationRank("���", VIEW_PERSON_SAME) <> 2 Then Exit Function
    '���s���� rank 0��1��2 �̏��ɁA��\���ʐl����ց�����l����ւ�ǉ�����B
    For currentIndex = 1 To 7
        nextIndex = CashAnalysisWrappedNavigationIndex(currentIndex, 7, 1)
        previousIndex = CashAnalysisWrappedNavigationIndex(nextIndex, 7, -1)
        If previousIndex <> currentIndex Then Exit Function
        previousIndex = CashAnalysisWrappedNavigationIndex(currentIndex, 7, -1)
        nextIndex = CashAnalysisWrappedNavigationIndex(previousIndex, 7, 1)
        If nextIndex <> currentIndex Then Exit Function
    Next currentIndex
    If CashAnalysisWrappedNavigationIndex(7, 7, 1) <> 1 Then Exit Function
    If CashAnalysisWrappedNavigationIndex(1, 7, -1) <> 7 Then Exit Function
    If Not CashAnalysisConfirmationPairConflicts( _
               ANALYSIS_STATUS_SHIFT_CONFIRMED, "���A", "���B", _
               ANALYSIS_STATUS_SHIFT_CONFIRMED) Then Exit Function
    If CashAnalysisConfirmationPairConflicts( _
           ANALYSIS_STATUS_SHIFT_CONFIRMED, "���A", "���A", _
           ANALYSIS_STATUS_SHIFT_CONFIRMED) Then Exit Function
    If CashAnalysisConfirmationPairConflicts( _
           ANALYSIS_STATUS_SHIFT_CONFIRMED, "���A", "���B", _
           ANALYSIS_STATUS_FOLLOWUP) Then Exit Function
    If CashAnalysisConfirmationPairConflicts( _
           ANALYSIS_STATUS_FOLLOWUP, "���A", "���B", _
           ANALYSIS_STATUS_SHIFT_CONFIRMED) Then Exit Function
    If CashManualFailureRecoveryMayRebuild(False) Then Exit Function
    If Not CashManualFailureRecoveryMayRebuild(True) Then Exit Function
    CashAnalysisNavigationRegressionTest = True
    Exit Function
TestFailed:
    Err.Clear
End Function

Private Sub ClearCashAnalysisCandidatePanel(ByVal ws As Worksheet, ByVal categoryText As String, _
                                            ByRef counts() As Long, ByVal unreviewedCount As Long, _
                                            ByVal followupCount As Long)
    Dim countValue As Long
    Select Case categoryText
        Case VIEW_CATEGORY_TRANSFER: countValue = counts(1)
        Case VIEW_CATEGORY_UNKNOWN_WITHDRAW: countValue = counts(2)
        Case VIEW_CATEGORY_UNKNOWN_DEPOSIT: countValue = counts(3)
    End Select
    ws.Range("F1").Value = CashAnalysisCompactHeader( _
                               categoryText, 0, countValue, "")
    ws.Range(VIEW_STATE_GROUP_ID).ClearContents
    ws.Range(VIEW_STATE_RESULT_ROW).ClearContents
    ws.Range(VIEW_STATE_CANDIDATE_REF).ClearContents
    ws.Range("C3").Value = "���Ȃ�"
    SetCashAnalysisTotals ws, 0, 0
    ws.Range("C5").Value = "�|"
    ws.Range("H5").Value = "���̋敪�ɂ͌��݌�₪����܂���B"
    ws.Range("C6").Value = CashAnalysisAppendText( _
                               "���͏�����ύX�����ꍇ�́A���[�E���͂��č쐬���Ă��������B", _
                               CashAnalysisReviewProgressText( _
                                   unreviewedCount, followupCount), _
                               vbLf)
    ws.Range("C7").Value = "���Ȃ��́A����Ȃ���ۏ؂�����̂ł͂���܂���B���������m�F���Ă��������B"
    ws.Range("C8").Value = ""
    ws.Range("C3:D3").Locked = True
    ws.Range("C8:M8").Locked = True
    SetShapeCaption ws, "CycleCashAnalysisViewMode", "�\��: �S���"
    SetShapeCaption ws, "CashAnalysisSecondaryAction", "�蓮����I��"
    SetViewButtonColors ws, "CashAnalysisSecondaryAction", _
                        RGB(255, 255, 255), RGB(203, 213, 225), RGB(30, 64, 175)
    SetShapeCaption ws, "CashAnalysisPrimaryAction", "���Ȃ�"
End Sub

Private Sub ApplyCashAnalysisRowFilter(ByVal ws As Worksheet, ByVal txIDList As String, _
                                       ByVal modeText As String)
    Dim lastR As Long, data As Variant, displayData() As Variant, roleData() As Variant
    Dim wanted As Object, accounts As Object, personIDs As Object, txPersonMap As Object
    Dim txID As String, accountID As String, personID As String
    Dim r As Long, rowCount As Long, minDate As Double, maxDate As Double, transactionDateSerial As Double
    Dim relatedDays As Long, showRow As Boolean, withdrawal As Double, deposit As Double
    Dim candidateRow As Boolean
    Dim totalWithdrawal As Double, totalDeposit As Double

    lastR = CashAnalysisLastDataRow(ws)
    If lastR < CASH_VIEW_FIRST_DATA_ROW Then Exit Sub
    rowCount = lastR - CASH_VIEW_FIRST_DATA_ROW + 1
    data = ws.Range(ws.Cells(CASH_VIEW_FIRST_DATA_ROW, 1), _
                    ws.Cells(lastR, OUT_COL_RECORD_TYPE)).Value2
    ReDim displayData(1 To rowCount, 1 To 1)
    ReDim roleData(1 To rowCount, 1 To 1)
    Set wanted = IDsToDictionary(txIDList)
    Set accounts = CreateObject("Scripting.Dictionary")
    Set personIDs = CreateObject("Scripting.Dictionary")
    Set txPersonMap = CashAnalysisTransactionPersonMap()
    accounts.CompareMode = vbTextCompare
    personIDs.CompareMode = vbTextCompare

    For r = 1 To rowCount
        txID = CellText(data(r, OUT_COL_TRANSACTION_ID))
        If Len(txID) > 0 And wanted.Exists(txID) Then
            accountID = CellText(data(r, OUT_COL_ACCOUNT_ID))
            If Len(accountID) = 0 Then _
                Err.Raise vbObjectError + 4972, "ApplyCashAnalysisRowFilter", _
                          "����� " & txID & " �Ɍ���ID������܂���B"
            If Not txPersonMap.Exists(txID) Then _
                Err.Raise vbObjectError + 4973, "ApplyCashAnalysisRowFilter", _
                          "������̐l��ID��W_����Ŋm�F�ł��܂���: " & txID
            personID = CellText(txPersonMap(txID))
            accounts(accountID) = True
            personIDs(personID) = True
            If IsDate(data(r, OUT_COL_DATE)) Then
                transactionDateSerial = CDbl(CDate(data(r, OUT_COL_DATE)))
                If minDate = 0 Or transactionDateSerial < minDate Then minDate = transactionDateSerial
                If maxDate = 0 Or transactionDateSerial > maxDate Then maxDate = transactionDateSerial
            End If
        End If
    Next r

    If CellText(ws.Range(VIEW_STATE_CATEGORY).Value) = VIEW_CATEGORY_TRANSFER Then
        relatedDays = 30
        If IsNumeric(GetSheet(SH_CONFIG).Cells(ROW_CFG_ANALYSIS_DAY_WINDOW, COL_CFG_ANALYSIS_VALUE).Value) Then _
            relatedDays = Application.Max(relatedDays, _
                CLng(GetSheet(SH_CONFIG).Cells(ROW_CFG_ANALYSIS_DAY_WINDOW, COL_CFG_ANALYSIS_VALUE).Value))
    Else
        relatedDays = 365
    End If

    For r = 1 To rowCount
        txID = CellText(data(r, OUT_COL_TRANSACTION_ID))
        candidateRow = (Len(txID) > 0 And wanted.Exists(txID))
        showRow = False
        If modeText = VIEW_MODE_ALL Then
            showRow = True
        ElseIf modeText = VIEW_MODE_COMPONENT Then
            showRow = candidateRow
        ElseIf candidateRow Then
            showRow = True
        ElseIf IsDate(data(r, OUT_COL_DATE)) And minDate > 0 Then
                transactionDateSerial = CDbl(CDate(data(r, OUT_COL_DATE)))
                If transactionDateSerial >= minDate - relatedDays And _
                   transactionDateSerial <= maxDate + relatedDays Then
                    accountID = CellText(data(r, OUT_COL_ACCOUNT_ID))
                    personID = ""
                    If Len(txID) > 0 Then
                        If Not txPersonMap.Exists(txID) Then _
                            Err.Raise vbObjectError + 4974, "ApplyCashAnalysisRowFilter", _
                                      "�֘A����̐l��ID��W_����Ŋm�F�ł��܂���: " & txID
                        personID = CellText(txPersonMap(txID))
                    End If
                    If (Len(accountID) > 0 And accounts.Exists(accountID)) Or _
                       (Len(personID) > 0 And personIDs.Exists(personID)) Then showRow = True
                End If
            End If
        If showRow Then displayData(r, 1) = "1" Else displayData(r, 1) = "0"
        If candidateRow Then
            withdrawal = CashViewDouble(data(r, OUT_COL_WITHDRAW))
            deposit = CashViewDouble(data(r, OUT_COL_DEPOSIT))
            totalWithdrawal = totalWithdrawal + withdrawal
            totalDeposit = totalDeposit + deposit
            roleData(r, 1) = CashViewRole(withdrawal, deposit)
        End If
    Next r

    ws.Range(ws.Cells(CASH_VIEW_FIRST_DATA_ROW, CASH_VIEW_COL_DISPLAY), _
             ws.Cells(lastR, CASH_VIEW_COL_DISPLAY)).Value = displayData
    ws.Range(ws.Cells(CASH_VIEW_FIRST_DATA_ROW, CASH_VIEW_COL_ROLE), _
             ws.Cells(lastR, CASH_VIEW_COL_ROLE)).Value = roleData
    ws.Range(ws.Cells(CASH_VIEW_FIRST_DATA_ROW, CASH_VIEW_COL_SELECTED), _
             ws.Cells(lastR, CASH_VIEW_COL_SELECTED)).ClearContents
    ApplyCashViewAutoFilter ws, lastR, (modeText <> VIEW_MODE_ALL)
    '�i���ݗp�Ɏ擾�ς݂̔z����g���A���v�̂��߂̑S���ēǍ����Ȃ��B
    SetCashAnalysisTotals ws, totalWithdrawal, totalDeposit
End Sub

Private Function CashAnalysisTransactionPersonMap() As Object
    '���E�֘A�����W_����̐l��ID�ő��ˁA������������`�ő�ւ��Ȃ��B
    Dim result As Object
    Dim ws As Worksheet
    Dim lastR As Long, r As Long
    Dim txValues As Variant, personValues As Variant, dataCount As Long
    Dim txID As String, personID As String
    Set result = CreateObject("Scripting.Dictionary")
    result.CompareMode = vbTextCompare
    If Not SheetExists(SH_WORK_TX) Then _
        Err.Raise vbObjectError + 4968, "CashAnalysisTransactionPersonMap", _
                  "W_���������܂���B�l��ID�������쐬�ł��܂���B"
    Set ws = GetSheet(SH_WORK_TX)
    lastR = LastUsedRowInSheet(ws)
    If lastR >= 2 Then
        dataCount = lastR - 1
        txValues = CashResultColumnValues( _
                       ws, 2, lastR, WORK_TX_COL_TRANSACTION_ID)
        personValues = CashResultColumnValues( _
                           ws, 2, lastR, WORK_TX_COL_PERSON_ID)
        For r = 1 To dataCount
            txID = CellText(txValues(r, 1))
            If Len(txID) > 0 Then
                If Not IsInternalIdValue(txID, "T") Then _
                    Err.Raise vbObjectError + 4968, "CashAnalysisTransactionPersonMap", _
                              "W_��� " & CStr(r + 1) & "�s�ڂ̎��ID�`�����s���ł�: " & txID
                personID = CellText(personValues(r, 1))
                If Len(personID) = 0 Then _
                    Err.Raise vbObjectError + 4968, "CashAnalysisTransactionPersonMap", _
                              "W_��� " & CStr(r + 1) & _
                              "�s�ڂɐl��ID������܂���B�����ł͑�ւ��܂���B"
                If Not IsInternalIdValue(personID, "P") Then _
                    Err.Raise vbObjectError + 4968, "CashAnalysisTransactionPersonMap", _
                              "W_��� " & CStr(r + 1) & "�s�ڂ̐l��ID�`�����s���ł�: " & personID
                If result.Exists(txID) Then
                    If StrComp(CellText(result(txID)), personID, vbTextCompare) <> 0 Then _
                        Err.Raise vbObjectError + 4968, "CashAnalysisTransactionPersonMap", _
                                  "�������ID�ɈقȂ�l��ID������܂�: " & txID
                Else
                    result.Add txID, personID
                End If
            End If
        Next r
    End If
    Set CashAnalysisTransactionPersonMap = result
End Function

Private Sub CalculateCashAnalysisTotals(ByVal ws As Worksheet, ByVal wanted As Object)
    Dim lastR As Long, data As Variant, r As Long, txID As String
    Dim totalWithdrawal As Double, totalDeposit As Double
    lastR = CashAnalysisLastDataRow(ws)
    If lastR < CASH_VIEW_FIRST_DATA_ROW Then
        SetCashAnalysisTotals ws, 0, 0
        Exit Sub
    End If
    data = ws.Range(ws.Cells(CASH_VIEW_FIRST_DATA_ROW, OUT_COL_WITHDRAW), _
                    ws.Cells(lastR, OUT_COL_TRANSACTION_ID)).Value2
    For r = 1 To UBound(data, 1)
        txID = CellText(data(r, OUT_COL_TRANSACTION_ID - OUT_COL_WITHDRAW + 1))
        If Len(txID) > 0 And wanted.Exists(txID) Then
            totalWithdrawal = totalWithdrawal + CashViewDouble(data(r, 1))
            totalDeposit = totalDeposit + CashViewDouble(data(r, 2))
        End If
    Next r
    SetCashAnalysisTotals ws, totalWithdrawal, totalDeposit
End Sub

Private Sub SetCashAnalysisTotals(ByVal ws As Worksheet, ByVal totalWithdrawal As Double, _
                                  ByVal totalDeposit As Double)
    ws.Range("B4").Value = totalWithdrawal
    ws.Range("F4").Value = totalDeposit
    ws.Range("J4").Value = totalDeposit - totalWithdrawal
    ws.Range("B4:D4").NumberFormatLocal = "#,##0.########"
    ws.Range("F4:H4").NumberFormatLocal = "#,##0.########"
    ws.Range("J4:M4").NumberFormatLocal = "+#,##0.########;-#,##0.########;0"
End Sub

Private Sub ShowAllCashViewRows(ByVal ws As Worksheet)
    Dim lastR As Long
    lastR = CashAnalysisLastDataRow(ws)
    If lastR < CASH_VIEW_FIRST_DATA_ROW Then Exit Sub
    ws.Range(ws.Cells(CASH_VIEW_FIRST_DATA_ROW, CASH_VIEW_COL_DISPLAY), _
             ws.Cells(lastR, CASH_VIEW_COL_DISPLAY)).Value = "1"
    ws.Range(ws.Cells(CASH_VIEW_FIRST_DATA_ROW, CASH_VIEW_COL_ROLE), _
             ws.Cells(lastR, CASH_VIEW_COL_SELECTED)).ClearContents
    ApplyCashViewAutoFilter ws, lastR, False
End Sub

Private Sub ApplyCashViewAutoFilter(ByVal ws As Worksheet, ByVal lastR As Long, _
                                    ByVal filterComponents As Boolean)
    If ws.AutoFilterMode Then ws.AutoFilterMode = False
    ws.Range(ws.Cells(CASH_VIEW_HEADER_ROW, 1), _
             ws.Cells(lastR, CASH_VIEW_COL_SELECTED)).AutoFilter
    If filterComponents Then
        ws.Range(ws.Cells(CASH_VIEW_HEADER_ROW, 1), _
                 ws.Cells(lastR, CASH_VIEW_COL_SELECTED)).AutoFilter _
                 Field:=CASH_VIEW_COL_DISPLAY, Criteria1:="1"
    End If
End Sub

Private Function FindCashAnalysisResultRow(ByRef categoryValues As Variant, _
                                           ByRef groupValues As Variant, _
                                           ByVal categoryText As String, ByVal groupID As String, _
                                           ByRef currentIndex As Long, ByRef categoryCount As Long) As Long
    Dim itemCount As Long, r As Long, firstRow As Long, resultRow As Long
    Dim itemCategory As String, itemGroupID As String
    If Not IsArray(categoryValues) Or Not IsArray(groupValues) Then Exit Function
    itemCount = UBound(categoryValues, 1)
    For r = 1 To itemCount
        resultRow = r + 1
        itemCategory = CashViewCategoryForResult(CellText(categoryValues(r, 1)))
        If itemCategory = categoryText Then
            categoryCount = categoryCount + 1
            If firstRow = 0 Then firstRow = resultRow
            itemGroupID = CellText(groupValues(r, 1))
            If Len(groupID) > 0 And StrComp(itemGroupID, groupID, vbTextCompare) = 0 Then
                FindCashAnalysisResultRow = resultRow
                currentIndex = categoryCount
            End If
        End If
    Next r
    If FindCashAnalysisResultRow = 0 Then
        FindCashAnalysisResultRow = firstRow
        If firstRow > 0 Then currentIndex = 1
    End If
End Function

Private Sub UpdateCategoryButtonCaptions(ByVal ws As Worksheet, ByVal activeCategory As String, _
                                         ByRef counts() As Long)
    SetShapeCaption ws, "ShowCashAnalysisTransfers", _
        IIf(activeCategory = VIEW_CATEGORY_TRANSFER, "�� ", "") & "�����ړ� " & CStr(counts(1))
    SetShapeCaption ws, "ShowCashAnalysisUnknownWithdrawals", _
        IIf(activeCategory = VIEW_CATEGORY_UNKNOWN_WITHDRAW, "�� ", "") & "�s���o�� " & CStr(counts(2))
    SetShapeCaption ws, "ShowCashAnalysisUnknownDeposits", _
        IIf(activeCategory = VIEW_CATEGORY_UNKNOWN_DEPOSIT, "�� ", "") & "�s������ " & CStr(counts(3))
    SetCategoryButtonState ws, "ShowCashAnalysisTransfers", _
                           (activeCategory = VIEW_CATEGORY_TRANSFER), RGB(15, 118, 110), RGB(13, 148, 136)
    SetCategoryButtonState ws, "ShowCashAnalysisUnknownWithdrawals", _
                           (activeCategory = VIEW_CATEGORY_UNKNOWN_WITHDRAW), RGB(185, 28, 28), RGB(153, 27, 27)
    SetCategoryButtonState ws, "ShowCashAnalysisUnknownDeposits", _
                           (activeCategory = VIEW_CATEGORY_UNKNOWN_DEPOSIT), RGB(29, 78, 216), RGB(30, 64, 175)
End Sub

Private Sub SetCategoryButtonState(ByVal ws As Worksheet, ByVal macroName As String, _
                                   ByVal isActive As Boolean, ByVal activeFill As Long, _
                                   ByVal activeLine As Long)
    Dim shp As Shape
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    For Each shp In ws.Shapes
        If StrComp(ToolShapeActionName(shp), macroName, vbTextCompare) = 0 Then
            If isActive Then
                shp.Fill.ForeColor.RGB = activeFill
                shp.Line.ForeColor.RGB = activeLine
                shp.TextFrame.Characters.Font.Color = RGB(255, 255, 255)
                shp.Line.Weight = 1.2
            Else
                shp.Fill.ForeColor.RGB = RGB(248, 250, 252)
                shp.Line.ForeColor.RGB = RGB(203, 213, 225)
                shp.TextFrame.Characters.Font.Color = RGB(51, 65, 85)
                shp.Line.Weight = 0.8
            End If
            Exit For
        End If
    Next shp
    On Error GoTo 0
    SetCashViewPrintControlState ws, macroName, isActive, activeFill, activeLine
End Sub

Private Sub SetShapeCaption(ByVal ws As Worksheet, ByVal macroName As String, ByVal caption As String)
    Dim shp As Shape
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    For Each shp In ws.Shapes
        If StrComp(ToolShapeActionName(shp), macroName, vbTextCompare) = 0 Then
            shp.TextFrame.Characters.Text = caption
            shp.TextFrame.Characters.Font.Name = "Yu Gothic UI"
            shp.TextFrame.Characters.Font.Bold = True
            SetToolShapeAccessibleLabel shp, caption
            Exit For
        End If
    Next shp
    On Error GoTo 0
    SetCashViewPrintCaption ws, macroName, caption
End Sub

Private Sub SetViewButtonColors(ByVal ws As Worksheet, ByVal macroName As String, _
                                ByVal fillColor As Long, ByVal lineColor As Long, _
                                ByVal fontColor As Long)
    Dim shp As Shape
    If ws Is Nothing Then Exit Sub
    fontColor = ReadableFontColor(fillColor, fontColor)
    On Error Resume Next
    For Each shp In ws.Shapes
        If StrComp(ToolShapeActionName(shp), macroName, vbTextCompare) = 0 Then
            shp.Fill.ForeColor.RGB = fillColor
            shp.Line.ForeColor.RGB = lineColor
            shp.TextFrame.Characters.Font.Color = fontColor
            Exit For
        End If
    Next shp
    On Error GoTo 0
    If StrComp(macroName, "CycleCashAnalysisViewMode", vbTextCompare) = 0 Then _
        SetCashViewPrintControlColors ws.Range("G3:H3"), fillColor, lineColor, fontColor
End Sub

Private Sub SetCashViewPrintCaption(ByVal ws As Worksheet, ByVal macroName As String, _
                                    ByVal caption As String)
    Dim target As Range
    If ws Is Nothing Then Exit Sub
    Select Case macroName
        Case "ShowCashAnalysisTransfers": Set target = ws.Range("A2:C2")
        Case "ShowCashAnalysisUnknownWithdrawals": Set target = ws.Range("D2:F2")
        Case "ShowCashAnalysisUnknownDeposits": Set target = ws.Range("G2:I2")
        Case "CycleCashAnalysisViewMode": Set target = ws.Range("G3:H3")
    End Select
    If Not target Is Nothing Then target.Cells(1, 1).Value = caption
End Sub

Private Sub SetCashViewPrintControlState(ByVal ws As Worksheet, ByVal macroName As String, _
                                         ByVal isActive As Boolean, ByVal activeFill As Long, _
                                         ByVal activeLine As Long)
    Dim target As Range
    If ws Is Nothing Then Exit Sub
    Select Case macroName
        Case "ShowCashAnalysisTransfers": Set target = ws.Range("A2:C2")
        Case "ShowCashAnalysisUnknownWithdrawals": Set target = ws.Range("D2:F2")
        Case "ShowCashAnalysisUnknownDeposits": Set target = ws.Range("G2:I2")
    End Select
    If target Is Nothing Then Exit Sub
    If isActive Then
        SetCashViewPrintControlColors target, activeFill, activeLine, RGB(255, 255, 255)
    Else
        SetCashViewPrintControlColors target, RGB(248, 250, 252), RGB(203, 213, 225), RGB(51, 65, 85)
    End If
End Sub

Private Sub SetCashViewPrintControlColors(ByVal target As Range, ByVal fillColor As Long, _
                                          ByVal lineColor As Long, ByVal fontColor As Long)
    If target Is Nothing Then Exit Sub
    With target
        .Interior.Color = fillColor
        .Font.Color = fontColor
        .Font.Bold = True
        .Borders.LineStyle = xlContinuous
        .Borders.Color = lineColor
    End With
End Sub

Private Function CashAnalysisResultIsManual(ByVal wsResult As Worksheet, ByVal resultRow As Long, _
                                            ByRef storedKey As String) As Boolean
    Dim sourceSheet As String, sourceKey As String, sourceRow As Long
    If wsResult Is Nothing Then Exit Function
    If resultRow < 2 Or resultRow > LastUsedRowInSheet(wsResult) Then Exit Function
    sourceSheet = CellText( _
                      wsResult.Cells(resultRow, ANALYSIS_RESULT_SOURCE_SHEET_COL).Value)
    sourceRow = CLng(Val(CellText(wsResult.Cells(resultRow, ANALYSIS_RESULT_SOURCE_ROW_COL).Value)))
    sourceKey = CellText(wsResult.Cells(resultRow, ANALYSIS_RESULT_SOURCE_KEY_COL).Value)
    If CashAnalysisSourceIsManual(sourceSheet, sourceRow, sourceKey) Then
        storedKey = sourceKey
        CashAnalysisResultIsManual = True
    End If
End Function

Private Function CashAnalysisSourceIsManual( _
        ByVal sourceSheet As String, ByVal sourceRow As Long, _
        ByVal sourceKey As String) As Boolean
    Dim wsFlow As Worksheet
    If StrComp(sourceSheet, SH_ANALYSIS_FLOW, vbTextCompare) <> 0 Or _
       Not SheetExists(SH_ANALYSIS_FLOW) Then Exit Function
    Set wsFlow = GetSheet(SH_ANALYSIS_FLOW)
    If sourceRow < 2 Or sourceRow > LastUsedRowInSheet(wsFlow) Then Exit Function
    If StrComp(CellText(wsFlow.Cells(sourceRow, 3).Value), "�蓮�w��", vbTextCompare) <> 0 Then Exit Function
    If Len(sourceKey) = 0 Or _
       StrComp(CellText(wsFlow.Cells(sourceRow, FLOW_ANALYSIS_KEY_COL).Value), _
               sourceKey, vbBinaryCompare) <> 0 Then Exit Function
    CashAnalysisSourceIsManual = True
End Function

Private Function CashAnalysisCurrentSourceReference( _
        ByVal ws As Worksheet, ByVal wsResult As Worksheet, _
        ByVal resultRow As Long, ByRef sourceSheet As String, _
        ByRef sourceRow As Long, ByRef sourceKey As String, _
        ByRef sourceCategory As String, ByRef isAlternative As Boolean) As Boolean
    Dim wsGroup As Worksheet, groupRow As Long
    Dim groupID As String, candidateRef As String
    If ws Is Nothing Or wsResult Is Nothing Then Exit Function
    If resultRow < 2 Or resultRow > LastUsedRowInSheet(wsResult) Then Exit Function
    groupID = CellText(ws.Range(VIEW_STATE_GROUP_ID).Value)
    If Len(groupID) = 0 Or _
       StrComp(CellText(wsResult.Cells(resultRow, ANALYSIS_RESULT_GROUP_ID_COL).Value), _
               groupID, vbTextCompare) <> 0 Then Exit Function
    candidateRef = CellText(ws.Range(VIEW_STATE_CANDIDATE_REF).Value)
    If Len(candidateRef) > 0 Then
        If Not SheetExists(SH_WORK_ANALYSIS_GROUP) Then Exit Function
        Set wsGroup = GetSheet(SH_WORK_ANALYSIS_GROUP)
        groupRow = FindCashAnalysisAlternativeRow(wsGroup, groupID, candidateRef)
        If groupRow = 0 Then Exit Function
        RequireAnalysisReviewConstantRange _
            wsGroup.Range(wsGroup.Cells(groupRow, 1), _
                          wsGroup.Cells(groupRow, ANALYSIS_GROUP_LAST_COL)), _
            "�\�����̑�֌��Q��"
        sourceSheet = CellText(wsGroup.Cells(groupRow, 2).Value)
        sourceRow = CLng(Val(CellText(wsGroup.Cells(groupRow, 3).Value)))
        sourceKey = CellText(wsGroup.Cells(groupRow, 4).Value)
        sourceCategory = CellText(wsGroup.Cells(groupRow, 8).Value)
        isAlternative = True
    Else
        sourceSheet = CellText( _
            wsResult.Cells(resultRow, ANALYSIS_RESULT_SOURCE_SHEET_COL).Value)
        sourceRow = CLng(Val(CellText( _
            wsResult.Cells(resultRow, ANALYSIS_RESULT_SOURCE_ROW_COL).Value)))
        sourceKey = CellText( _
            wsResult.Cells(resultRow, ANALYSIS_RESULT_SOURCE_KEY_COL).Value)
        sourceCategory = CellText(wsResult.Cells(resultRow, 2).Value)
    End If
    CashAnalysisCurrentSourceReference = _
        (Len(sourceSheet) > 0 And sourceRow >= 2 And Len(sourceKey) > 0)
End Function

Private Sub RequireCashAnalysisGroupConfirmationAvailable( _
        ByVal groupID As String, ByVal currentCandidateRef As String, _
        ByVal proposedStatus As String)
    Dim wsGroup As Worksheet
    Dim lastR As Long, r As Long, sourceRow As Long
    Dim groupIDs As Variant, sourceSheets As Variant, sourceRows As Variant
    Dim sourceKeys As Variant, representativeFlags As Variant
    Dim otherRef As String, otherStatus As String, representativeText As String
    If proposedStatus <> ANALYSIS_STATUS_SHIFT_CONFIRMED Then Exit Sub
    If Len(groupID) = 0 Or Len(currentCandidateRef) = 0 Or _
       Not SheetExists(SH_WORK_ANALYSIS_GROUP) Then _
        Err.Raise vbObjectError + 5012, _
                  "RequireCashAnalysisGroupConfirmationAvailable", _
                  "�m�F�ΏۃO���[�v�܂��͌��Q�Ƃ��擾�ł��܂���B"
    Set wsGroup = GetSheet(SH_WORK_ANALYSIS_GROUP)
    lastR = LastUsedRowInSheet(wsGroup)
    If lastR < 2 Then _
        Err.Raise vbObjectError + 5013, _
                  "RequireCashAnalysisGroupConfirmationAvailable", _
                  "�m�F�ΏۃO���[�v�̓����ꗗ������܂���B"
    groupIDs = CashResultColumnValues(wsGroup, 2, lastR, 1)
    sourceSheets = CashResultColumnValues(wsGroup, 2, lastR, 2)
    sourceRows = CashResultColumnValues(wsGroup, 2, lastR, 3)
    sourceKeys = CashResultColumnValues(wsGroup, 2, lastR, 4)
    representativeFlags = CashResultColumnValues(wsGroup, 2, lastR, 7)
    For r = 1 To lastR - 1
        If StrComp(CellText(groupIDs(r, 1)), groupID, vbBinaryCompare) = 0 Then
            representativeText = CellText(representativeFlags(r, 1))
            If StrComp(representativeText, "��\", vbBinaryCompare) <> 0 And _
               StrComp(representativeText, "���", vbBinaryCompare) <> 0 Then _
                Err.Raise vbObjectError + 5014, _
                          "RequireCashAnalysisGroupConfirmationAvailable", _
                          "���̓O���[�v�̑�\�敪���s���ł��B"
            sourceRow = CLng(Val(CellText(sourceRows(r, 1))))
            otherRef = CashAnalysisCandidateReference( _
                           CellText(sourceSheets(r, 1)), sourceRow, _
                           CellText(sourceKeys(r, 1)))
            If Len(otherRef) = 0 Then _
                Err.Raise vbObjectError + 5015, _
                          "RequireCashAnalysisGroupConfirmationAvailable", _
                          "���̓O���[�v�̌��Q�Ƃ��s�����Ă��܂��B"
            If StrComp(otherRef, currentCandidateRef, vbBinaryCompare) <> 0 Then
                otherStatus = CashAnalysisSourceReviewStatus( _
                                  CellText(sourceSheets(r, 1)), sourceRow, _
                                  CellText(sourceKeys(r, 1)))
                If CashAnalysisConfirmationPairConflicts( _
                       proposedStatus, currentCandidateRef, otherRef, otherStatus) Then _
                    Err.Raise vbObjectError + 5016, _
                              "RequireCashAnalysisGroupConfirmationAvailable", _
                              "���������O���[�v�̕ʌ�₪���Ɏ����ړ��m�F�ł��B" & _
                              "��ɂ��̌���v�ǉ������܂��͑ΏۊO�֕ύX���Ă��������B"
            End If
        End If
    Next r
End Sub

Private Function CashAnalysisSourceReviewStatus( _
        ByVal sourceSheet As String, ByVal sourceRow As Long, _
        ByVal sourceKey As String) As String
    Dim wsSource As Worksheet, statusCol As Long, keyCol As Long
    If Not SheetExists(sourceSheet) Then _
        Err.Raise vbObjectError + 5017, "CashAnalysisSourceReviewStatus", _
                  "���̓������\������܂���B"
    Select Case sourceSheet
        Case SH_ANALYSIS_SHIFT
            statusCol = SHIFT_ANALYSIS_STATUS_COL
            keyCol = SHIFT_ANALYSIS_KEY_COL
        Case SH_ANALYSIS_FLOW
            statusCol = FLOW_ANALYSIS_STATUS_COL
            keyCol = FLOW_ANALYSIS_KEY_COL
        Case Else
            Err.Raise vbObjectError + 5018, "CashAnalysisSourceReviewStatus", _
                      "�����ړ����ȊO�����������O���[�v�Ɋ܂܂�Ă��܂��B"
    End Select
    Set wsSource = GetSheet(sourceSheet)
    If sourceRow < 2 Or sourceRow > LastUsedRowInSheet(wsSource) Then _
        Err.Raise vbObjectError + 5019, "CashAnalysisSourceReviewStatus", _
                  "���̓������s������܂���B"
    RequireAnalysisReviewConstantRange Union( _
        wsSource.Cells(sourceRow, statusCol), wsSource.Cells(sourceRow, keyCol)), _
        "����O���[�v���̊m�F���"
    If Len(sourceKey) = 0 Or _
       StrComp(CellText(wsSource.Cells(sourceRow, keyCol).Value), _
               sourceKey, vbBinaryCompare) <> 0 Then _
        Err.Raise vbObjectError + 5020, "CashAnalysisSourceReviewStatus", _
                  "���̓����m�F�L�[����v���܂���B"
    CashAnalysisSourceReviewStatus = _
        CashAnalysisStatusOrDefault(wsSource.Cells(sourceRow, statusCol).Value)
End Function

Private Function CashAnalysisConfirmationPairConflicts( _
        ByVal proposedStatus As String, ByVal currentCandidateRef As String, _
        ByVal otherCandidateRef As String, ByVal otherStatus As String) As Boolean
    CashAnalysisConfirmationPairConflicts = _
        (proposedStatus = ANALYSIS_STATUS_SHIFT_CONFIRMED And _
         Len(currentCandidateRef) > 0 And Len(otherCandidateRef) > 0 And _
         StrComp(currentCandidateRef, otherCandidateRef, vbBinaryCompare) <> 0 And _
         otherStatus = ANALYSIS_STATUS_SHIFT_CONFIRMED)
End Function

Public Sub ShowCashAnalysisTransfers()
    SelectCashAnalysisCategory VIEW_CATEGORY_TRANSFER
End Sub

Public Sub ShowCashAnalysisUnknownWithdrawals()
    SelectCashAnalysisCategory VIEW_CATEGORY_UNKNOWN_WITHDRAW
End Sub

Public Sub ShowCashAnalysisUnknownDeposits()
    SelectCashAnalysisCategory VIEW_CATEGORY_UNKNOWN_DEPOSIT
End Sub

Private Sub SelectCashAnalysisCategory(ByVal categoryText As String)
    Dim ws As Worksheet
    Dim workbookWasSaved As Boolean
    Dim previousEvents As Boolean, eventsCaptured As Boolean
    Dim eventsRestoreAttempted As Boolean, eventsReadyForRecovery As Boolean
    Dim actionMutationStarted As Boolean, protectOK As Boolean
    Dim safeToRestoreEntry As Boolean
    Dim eventStateDetail As String, stopDetail As String
    Dim convergenceDetail As String
    Dim errorNumber As Long, errorSource As String, errorDescription As String
    If Not SheetExists(SH_OUTPUT_TX) Then Exit Sub
    If Not RequireCashAnalysisManualModeFinished("���͋敪�̐ؑ�") Then Exit Sub
    On Error GoTo EH
    Set ws = GetSheet(SH_OUTPUT_TX)
    workbookWasSaved = ThisWorkbook.Saved
    If Not TryGetCashAnalysisEnableEvents(previousEvents, eventStateDetail) Then _
        Err.Raise vbObjectError + 5122, "SelectCashAnalysisCategory", _
                  "Excel�C�x���g�̊J�n��Ԃ��擾�ł��܂���ł����B " & eventStateDetail
    eventsCaptured = True
    If Not TrySetCashAnalysisEnableEventsExact(False, eventStateDetail) Then _
        Err.Raise vbObjectError + 5123, "SelectCashAnalysisCategory", _
                  "���͋敪�֑ؑO��Excel�C�x���g���~�ł��܂���ł����B " & eventStateDetail
    actionMutationStarted = True
    SyncCashAnalysisPanelReviewToWorkspace
    ws.Unprotect Password:=TOOL_PASSWORD
    ws.Range(VIEW_STATE_CATEGORY).Value = categoryText
    ws.Range(VIEW_STATE_GROUP_ID).ClearContents
    ws.Range(VIEW_STATE_CANDIDATE_REF).ClearContents
    ws.Range(VIEW_STATE_MODE).Value = VIEW_MODE_COMPONENT
    ws.Range(VIEW_STATE_MANUAL).Value = "0"
    ws.Range(VIEW_STATE_SELECTED_IDS).ClearContents
    ws.Range(VIEW_STATE_PANEL_EXPANDED).Value = "0"
    RefreshCashAnalysisPanel True
    If workbookWasSaved Then ThisWorkbook.Saved = True
    eventsRestoreAttempted = True
    If Not TryRestoreCashAnalysisEnableEvents( _
               previousEvents, "SelectCashAnalysisCategory", _
               eventStateDetail) Then _
        Err.Raise vbObjectError + 5124, _
                  "SelectCashAnalysisCategory", eventStateDetail
    eventsCaptured = False
    Exit Sub
EH:
    errorNumber = Err.Number
    errorSource = Err.Source
    errorDescription = Err.Description
    If IsCashAnalysisRecoveryFatal(errorNumber, errorSource) Then
        Call TryStopCashAnalysisEventsForRecovery(convergenceDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    If eventsCaptured Then
        If Not eventsRestoreAttempted Then _
            eventsReadyForRecovery = _
                TryStopCashAnalysisEventsForRecovery(stopDetail)
    End If
    If actionMutationStarted And Not eventsRestoreAttempted Then
        If eventsReadyForRecovery Then
            protectOK = TryProtectCashAnalysisViewAfterFailure( _
                            ws, "SelectCashAnalysisCategory", _
                            False, errorDescription)
            safeToRestoreEntry = _
                CashAnalysisOuterLeaseMayRestoreAfterProtection( _
                    protectOK, errorDescription)
        Else
            AppendCashAnalysisRollbackDetail errorDescription, _
                "Excel�C�x���g��~��ǖ߂��m�F�ł��Ȃ����߁A" & _
                "�u�b�N�̍ĕی��Recovery�����݂��s���܂���ł����B " & _
                stopDetail
        End If
    End If
    If eventsCaptured And Not eventsRestoreAttempted Then
        eventsRestoreAttempted = True
        If Not actionMutationStarted Or safeToRestoreEntry Then
            If Not TryRestoreCashAnalysisEnableEvents( _
                       previousEvents, _
                       "SelectCashAnalysisCategory/�G���[�I��", _
                       eventStateDetail) Then _
                AppendCashAnalysisRollbackDetail errorDescription, _
                    eventStateDetail
        ElseIf TryStopCashAnalysisEventsForRecovery(convergenceDetail) Then
            AppendCashAnalysisRollbackDetail errorDescription, _
                "�ĕی�܂���Recovery�������m�F�ł��Ȃ����߁A" & _
                "�J�n���C�x���g�l�֖߂���False�Œ�~���܂����B"
        Else
            AppendCashAnalysisRollbackDetail errorDescription, _
                "���S��Ԃ������m�F�ł����AExcel�C�x���g��False�����ɂ�" & _
                "���s���܂����B���ݏ�Ԃ͕s���ł�: " & convergenceDetail
        End If
    End If
    eventsCaptured = False
    MsgBox "���͋敪��؂�ւ����܂���ł����B" & vbCrLf & _
           "Err " & CStr(errorNumber) & ": " & errorDescription, vbExclamation
End Sub

Public Sub PreviousCashAnalysisCandidate()
    NavigateCashAnalysisCandidate -1
End Sub

Public Sub NextCashAnalysisCandidate()
    NavigateCashAnalysisCandidate 1
End Sub

Public Sub NextUnreviewedCashAnalysisGroup()
    NavigateCashAnalysisCandidate 1, True
End Sub

Private Sub NavigateCashAnalysisCandidate(ByVal direction As Long, _
                                          Optional ByVal unreviewedOnly As Boolean = False)
    Dim ws As Worksheet, wsResult As Worksheet, wsGroup As Worksheet
    Dim categoryText As String, groupID As String, candidateRef As String
    Dim entry As Variant, entries As Collection
    Dim i As Long, currentIndex As Long, nextIndex As Long
    Dim workbookWasSaved As Boolean
    Dim previousEvents As Boolean, eventsCaptured As Boolean
    Dim eventsRestoreAttempted As Boolean, eventsReadyForRecovery As Boolean
    Dim actionMutationStarted As Boolean, protectOK As Boolean
    Dim safeToRestoreEntry As Boolean
    Dim eventStateDetail As String, stopDetail As String
    Dim convergenceDetail As String
    Dim errorNumber As Long, errorSource As String, errorDescription As String
    Dim noUnreviewedGroups As Boolean
    If Not SheetExists(SH_OUTPUT_TX) Or Not SheetExists(SH_ANALYSIS_RESULT) Then Exit Sub
    If Not RequireCashAnalysisManualModeFinished("���̐ؑ�") Then Exit Sub
    On Error GoTo EH
    Set ws = GetSheet(SH_OUTPUT_TX)
    Set wsResult = GetSheet(SH_ANALYSIS_RESULT)
    workbookWasSaved = ThisWorkbook.Saved
    If Not TryGetCashAnalysisEnableEvents(previousEvents, eventStateDetail) Then _
        Err.Raise vbObjectError + 5125, "NavigateCashAnalysisCandidate", _
                  "Excel�C�x���g�̊J�n��Ԃ��擾�ł��܂���ł����B " & eventStateDetail
    eventsCaptured = True
    If Not TrySetCashAnalysisEnableEventsExact(False, eventStateDetail) Then _
        Err.Raise vbObjectError + 5126, "NavigateCashAnalysisCandidate", _
                  "���֑ؑO��Excel�C�x���g���~�ł��܂���ł����B " & eventStateDetail
    actionMutationStarted = True
    SyncCashAnalysisPanelReviewToWorkspace
    If Not SheetExists(SH_WORK_ANALYSIS_GROUP) Then _
        Err.Raise vbObjectError + 5003, "NavigateCashAnalysisCandidate", _
                  "��֌��̓����ꗗ������܂���B"
    Set wsGroup = GetSheet(SH_WORK_ANALYSIS_GROUP)
    ws.Unprotect Password:=TOOL_PASSWORD
    ws.Range(VIEW_STATE_MANUAL).Value = "0"
    categoryText = CellText(ws.Range(VIEW_STATE_CATEGORY).Value)
    groupID = CellText(ws.Range(VIEW_STATE_GROUP_ID).Value)
    candidateRef = CellText(ws.Range(VIEW_STATE_CANDIDATE_REF).Value)
    Set entries = BuildCashAnalysisNavigationEntries( _
                      wsResult, wsGroup, categoryText, _
                      CashAnalysisTransactionPersonMap())
    If entries.Count = 0 Then
        RefreshCashAnalysisPanel False
        GoTo CompleteAction
    End If
    For i = 1 To entries.Count
        entry = entries(i)
        If StrComp(CStr(entry(0)), groupID, vbTextCompare) = 0 And _
           StrComp(CStr(entry(1)), candidateRef, vbBinaryCompare) = 0 Then
            currentIndex = i
            Exit For
        End If
    Next i
    If currentIndex = 0 Then
        '�ĕ��͂ő�ւ������������ꍇ�́A�����O���[�v�̑�\�����݈ʒu�Ƃ���B
        For i = 1 To entries.Count
            entry = entries(i)
            If StrComp(CStr(entry(0)), groupID, vbTextCompare) = 0 And _
               Len(CStr(entry(1))) = 0 Then
                currentIndex = i
                Exit For
            End If
        Next i
    End If
    If currentIndex = 0 Then currentIndex = 1
    nextIndex = CashAnalysisWrappedNavigationIndex(currentIndex, entries.Count, direction)
    If unreviewedOnly Then
        nextIndex = NextUnreviewedGroupIndex(wsResult, entries, currentIndex)
        If nextIndex = 0 Then
            noUnreviewedGroups = True
            RefreshCashAnalysisPanel False
            GoTo CompleteAction
        End If
    End If
    entry = entries(nextIndex)
    ws.Range(VIEW_STATE_GROUP_ID).Value = CStr(entry(0))
    If Len(CStr(entry(1))) = 0 Then
        ws.Range(VIEW_STATE_CANDIDATE_REF).ClearContents
    Else
        ws.Range(VIEW_STATE_CANDIDATE_REF).Value = CStr(entry(1))
    End If
    ws.Range(VIEW_STATE_PANEL_EXPANDED).Value = "0"
    RefreshCashAnalysisPanel True
CompleteAction:
    If workbookWasSaved Then ThisWorkbook.Saved = True
    eventsRestoreAttempted = True
    If Not TryRestoreCashAnalysisEnableEvents( _
               previousEvents, "NavigateCashAnalysisCandidate", _
               eventStateDetail) Then _
        Err.Raise vbObjectError + 5127, _
                  "NavigateCashAnalysisCandidate", eventStateDetail
    eventsCaptured = False
    If noUnreviewedGroups Then _
        MsgBox "���̕��͋敪�ɖ��m�F�̃O���[�v�͂���܂���B" & vbCrLf & _
               "��֌��E�v�ǉ������́u���ցv�Ŋm�F�ł��܂��B", vbInformation
    Exit Sub
EH:
    errorNumber = Err.Number
    errorSource = Err.Source
    errorDescription = Err.Description
    If IsCashAnalysisRecoveryFatal(errorNumber, errorSource) Then
        Call TryStopCashAnalysisEventsForRecovery(convergenceDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    If eventsCaptured Then
        If Not eventsRestoreAttempted Then _
            eventsReadyForRecovery = _
                TryStopCashAnalysisEventsForRecovery(stopDetail)
    End If
    If actionMutationStarted And Not eventsRestoreAttempted Then
        If eventsReadyForRecovery Then
            protectOK = TryProtectCashAnalysisViewAfterFailure( _
                            ws, "NavigateCashAnalysisCandidate", _
                            False, errorDescription)
            safeToRestoreEntry = _
                CashAnalysisOuterLeaseMayRestoreAfterProtection( _
                    protectOK, errorDescription)
        Else
            AppendCashAnalysisRollbackDetail errorDescription, _
                "Excel�C�x���g��~��ǖ߂��m�F�ł��Ȃ����߁A" & _
                "�u�b�N�̍ĕی��Recovery�����݂��s���܂���ł����B " & _
                stopDetail
        End If
    End If
    If eventsCaptured And Not eventsRestoreAttempted Then
        eventsRestoreAttempted = True
        If Not actionMutationStarted Or safeToRestoreEntry Then
            If Not TryRestoreCashAnalysisEnableEvents( _
                       previousEvents, _
                       "NavigateCashAnalysisCandidate/�G���[�I��", _
                       eventStateDetail) Then _
                AppendCashAnalysisRollbackDetail errorDescription, _
                    eventStateDetail
        ElseIf TryStopCashAnalysisEventsForRecovery(convergenceDetail) Then
            AppendCashAnalysisRollbackDetail errorDescription, _
                "�ĕی�܂���Recovery�������m�F�ł��Ȃ����߁A" & _
                "�J�n���C�x���g�l�֖߂���False�Œ�~���܂����B"
        Else
            AppendCashAnalysisRollbackDetail errorDescription, _
                "���S��Ԃ������m�F�ł����AExcel�C�x���g��False�����ɂ�" & _
                "���s���܂����B���ݏ�Ԃ͕s���ł�: " & convergenceDetail
        End If
    End If
    eventsCaptured = False
    MsgBox "����؂�ւ����܂���ł����B" & vbCrLf & _
           "Err " & CStr(errorNumber) & ": " & errorDescription, vbExclamation
End Sub

Public Sub CycleCashAnalysisViewMode()
    Dim ws As Worksheet, modeText As String
    Dim workbookWasSaved As Boolean
    Dim previousEvents As Boolean, eventsCaptured As Boolean
    Dim eventsRestoreAttempted As Boolean, eventsReadyForRecovery As Boolean
    Dim actionMutationStarted As Boolean, protectOK As Boolean
    Dim safeToRestoreEntry As Boolean
    Dim eventStateDetail As String, stopDetail As String
    Dim convergenceDetail As String
    Dim errorNumber As Long, errorSource As String, errorDescription As String
    If Not SheetExists(SH_OUTPUT_TX) Then Exit Sub
    If Not RequireCashAnalysisManualModeFinished("�\���͈͂̐ؑ�") Then Exit Sub
    On Error GoTo EH
    Set ws = GetSheet(SH_OUTPUT_TX)
    If Len(CellText(ws.Range(VIEW_STATE_GROUP_ID).Value)) = 0 Then Exit Sub
    workbookWasSaved = ThisWorkbook.Saved
    If Not TryGetCashAnalysisEnableEvents(previousEvents, eventStateDetail) Then _
        Err.Raise vbObjectError + 5128, "CycleCashAnalysisViewMode", _
                  "Excel�C�x���g�̊J�n��Ԃ��擾�ł��܂���ł����B " & eventStateDetail
    eventsCaptured = True
    If Not TrySetCashAnalysisEnableEventsExact(False, eventStateDetail) Then _
        Err.Raise vbObjectError + 5129, "CycleCashAnalysisViewMode", _
                  "�\���͈֑͐ؑO��Excel�C�x���g���~�ł��܂���ł����B " & eventStateDetail
    actionMutationStarted = True
    SyncCashAnalysisPanelReviewToWorkspace
    ws.Unprotect Password:=TOOL_PASSWORD
    modeText = CellText(ws.Range(VIEW_STATE_MODE).Value)
    Select Case modeText
        Case VIEW_MODE_COMPONENT: modeText = VIEW_MODE_RELATED
        Case VIEW_MODE_RELATED: modeText = VIEW_MODE_ALL
        Case Else: modeText = VIEW_MODE_COMPONENT
    End Select
    ws.Range(VIEW_STATE_MODE).Value = modeText
    RefreshCashAnalysisPanel True
    If workbookWasSaved Then ThisWorkbook.Saved = True
    eventsRestoreAttempted = True
    If Not TryRestoreCashAnalysisEnableEvents( _
               previousEvents, "CycleCashAnalysisViewMode", _
               eventStateDetail) Then _
        Err.Raise vbObjectError + 5130, _
                  "CycleCashAnalysisViewMode", eventStateDetail
    eventsCaptured = False
    Exit Sub
EH:
    errorNumber = Err.Number
    errorSource = Err.Source
    errorDescription = Err.Description
    If IsCashAnalysisRecoveryFatal(errorNumber, errorSource) Then
        Call TryStopCashAnalysisEventsForRecovery(convergenceDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    If eventsCaptured Then
        If Not eventsRestoreAttempted Then _
            eventsReadyForRecovery = _
                TryStopCashAnalysisEventsForRecovery(stopDetail)
    End If
    If actionMutationStarted And Not eventsRestoreAttempted Then
        If eventsReadyForRecovery Then
            protectOK = TryProtectCashAnalysisViewAfterFailure( _
                            ws, "CycleCashAnalysisViewMode", _
                            False, errorDescription)
            safeToRestoreEntry = _
                CashAnalysisOuterLeaseMayRestoreAfterProtection( _
                    protectOK, errorDescription)
        Else
            AppendCashAnalysisRollbackDetail errorDescription, _
                "Excel�C�x���g��~��ǖ߂��m�F�ł��Ȃ����߁A" & _
                "�u�b�N�̍ĕی��Recovery�����݂��s���܂���ł����B " & _
                stopDetail
        End If
    End If
    If eventsCaptured And Not eventsRestoreAttempted Then
        eventsRestoreAttempted = True
        If Not actionMutationStarted Or safeToRestoreEntry Then
            If Not TryRestoreCashAnalysisEnableEvents( _
                       previousEvents, _
                       "CycleCashAnalysisViewMode/�G���[�I��", _
                       eventStateDetail) Then _
                AppendCashAnalysisRollbackDetail errorDescription, _
                    eventStateDetail
        ElseIf TryStopCashAnalysisEventsForRecovery(convergenceDetail) Then
            AppendCashAnalysisRollbackDetail errorDescription, _
                "�ĕی�܂���Recovery�������m�F�ł��Ȃ����߁A" & _
                "�J�n���C�x���g�l�֖߂���False�Œ�~���܂����B"
        Else
            AppendCashAnalysisRollbackDetail errorDescription, _
                "���S��Ԃ������m�F�ł����AExcel�C�x���g��False�����ɂ�" & _
                "���s���܂����B���ݏ�Ԃ͕s���ł�: " & convergenceDetail
        End If
    End If
    eventsCaptured = False
    MsgBox "�\���͈͂�؂�ւ����܂���ł����B" & vbCrLf & _
           "�m�F�󋵁E�m�F�������m�F���Ă��������B" & vbCrLf & _
           "Err " & CStr(errorNumber) & ": " & errorDescription, vbExclamation
End Sub

Public Sub CashAnalysisSecondaryAction()
    Dim ws As Worksheet, wsResult As Worksheet
    Dim resultRow As Long, storedKey As String, sourceSheet As String
    Dim sourceRow As Long, sourceCategory As String, isAlternative As Boolean
    Dim entryEvents As Boolean, entryEventsCaptured As Boolean
    Dim eventsReady As Boolean, actionCompleted As Boolean
    Dim protectOK As Boolean, safeToRestoreEntry As Boolean
    Dim mutationDispatchStarted As Boolean, recoveryConfirmed As Boolean
    Dim protectionRecoveryAttempted As Boolean
    Dim protectionRecoveryFailed As Boolean
    Dim protectionRecoveryConfirmed As Boolean
    Dim rethrowRecoveryFatal As Boolean
    Dim protectRecoveryFatal As Boolean
    Dim sourceReferenceConfirmed As Boolean, sourceIsManual As Boolean
    Dim eventDetail As String, restoreDetail As String
    Dim protectErrorNumber As Long, protectErrorDescription As String
    Dim protectErrorSource As String
    Dim errorNumber As Long, errorSource As String, errorDescription As String
    If Not SheetExists(SH_OUTPUT_TX) Then Exit Sub
    On Error GoTo EH
    Set ws = GetSheet(SH_OUTPUT_TX)
    If Not TryGetCashAnalysisEnableEvents(entryEvents, eventDetail) Then
        StopAfterCashAnalysisEventStateFailure _
            "CashAnalysisSecondaryAction/�J�n��Ԏ擾", eventDetail, _
            eventsReady, False, vbNullString
        MsgBox "�蓮���̑�����J�n�ł��܂���ł����B" & vbCrLf & _
               "Excel�C�x���g�̊J�n��Ԃ��擾�ł��܂���B " & eventDetail, _
               vbExclamation, "�蓮���̑���͈��S��~"
        Exit Sub
    End If
    entryEventsCaptured = True
    eventsReady = TryStopCashAnalysisEventsForRecovery(eventDetail)
    If Not eventsReady Then _
        Err.Raise vbObjectError + 5143, "CashAnalysisSecondaryAction", _
                  "�蓮���̑���O��Excel�C�x���g��~���m�F�ł��܂���ł����B " & _
                  eventDetail
    mutationDispatchStarted = True
    If CellText(ws.Range(VIEW_STATE_MANUAL).Value) = "1" Then
        ClearCashAnalysisManualSelection True
    Else
        If SheetExists(SH_ANALYSIS_RESULT) Then
            Set wsResult = GetSheet(SH_ANALYSIS_RESULT)
            resultRow = CLng(Val(CellText(ws.Range(VIEW_STATE_RESULT_ROW).Value)))
        End If
        sourceReferenceConfirmed = _
            CashAnalysisCurrentSourceReference( _
                ws, wsResult, resultRow, sourceSheet, sourceRow, storedKey, _
                sourceCategory, isAlternative)
        If sourceReferenceConfirmed Then _
            sourceIsManual = _
                CashAnalysisSourceIsManual( _
                    sourceSheet, sourceRow, storedKey)
        If sourceIsManual Then
            SyncCashAnalysisPanelReviewToWorkspace
            DeactivateManualFlowCandidateByStoredKey storedKey
        Else
            EnterCashAnalysisManualMode
        End If
    End If
    actionCompleted = True
    safeToRestoreEntry = True
    GoTo CleanExit
EH:
    errorNumber = Err.Number
    errorSource = Err.Source
    errorDescription = Err.Description
    On Error GoTo 0
    If IsCashAnalysisRecoveryFatal(errorNumber, errorSource) Then
        Call TryStopCashAnalysisEventsForRecovery(eventDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    eventsReady = TryStopCashAnalysisEventsForRecovery(eventDetail)
    If Not mutationDispatchStarted Then
        safeToRestoreEntry = True
    ElseIf eventsReady Then
        On Error Resume Next
        Err.Clear
        protectOK = TryProtectCashAnalysisViewAfterFailure( _
                        ws, "CashAnalysisSecondaryAction", _
                        False, errorDescription, _
                        protectionRecoveryAttempted, _
                        protectionRecoveryFailed, _
                        protectionRecoveryConfirmed)
        protectErrorNumber = Err.Number
        protectErrorSource = Err.Source
        protectErrorDescription = Err.Description
        Err.Clear
        On Error GoTo 0
        protectRecoveryFatal = _
            IsCashAnalysisRecoveryFatal( _
                protectErrorNumber, protectErrorSource)
        If protectRecoveryFatal Then
            Call TryStopCashAnalysisEventsForRecovery(eventDetail)
            Err.Raise protectErrorNumber, protectErrorSource, _
                      protectErrorDescription
        End If
        If protectErrorNumber <> 0 Then _
            AppendCashAnalysisRollbackDetail errorDescription, _
                "�ĕی쏈���̗\�����Ȃ��G���[: Err " & _
                CStr(protectErrorNumber) & " " & protectErrorDescription
        If protectionRecoveryFailed Then
            rethrowRecoveryFatal = True
            errorNumber = vbObjectError + 5194
            errorSource = _
                "CashAnalysisRecoveryFatal/CashAnalysisSecondaryAction"
            safeToRestoreEntry = False
            GoTo CleanExit
        End If
        If Not protectOK And protectErrorNumber = 0 And _
           Len(Trim$(errorDescription)) = 0 Then _
            errorDescription = "��������\�̍ĕی슮�����m�F�ł��܂���ł����B"
        eventsReady = TryStopCashAnalysisEventsForRecovery(eventDetail)
        If Not eventsReady Then
            AppendCashAnalysisRollbackDetail errorDescription, _
                "�ĕی쏈�����Excel�C�x���g��~���m�F�ł����A" & _
                "�J�n��Ԃ֖߂�����S�������m�F�ł��܂���ł����B " & _
                eventDetail
        ElseIf protectOK Then
            safeToRestoreEntry = True
        ElseIf protectionRecoveryAttempted Then
            recoveryConfirmed = protectionRecoveryConfirmed
            safeToRestoreEntry = recoveryConfirmed
        End If
    Else
        AppendCashAnalysisRollbackDetail errorDescription, _
            "Excel�C�x���g��~���m�F�ł��Ȃ����߁A�ĕی��" & _
            "Recovery��Ԃ̏����݂��s���܂���ł����B " & eventDetail
    End If
CleanExit:
    If entryEventsCaptured Then
        entryEventsCaptured = False
        If safeToRestoreEntry Then _
            safeToRestoreEntry = _
                CashAnalysisApplicationStateAllowsEntryRestore( _
                    entryEvents, errorDescription)
        If safeToRestoreEntry Then
            If Not TryRestoreCashAnalysisEnableEvents( _
                       entryEvents, "CashAnalysisSecondaryAction/�I������", _
                       restoreDetail) Then
                If errorNumber = 0 Then errorNumber = vbObjectError + 5144
                AppendCashAnalysisRollbackDetail errorDescription, restoreDetail
                actionCompleted = False
            End If
        Else
            eventsReady = TryStopCashAnalysisEventsForRecovery(restoreDetail)
            If eventsReady Then
                If entryEvents Then
                    AppendCashAnalysisRollbackDetail errorDescription, _
                        "���S��Ԃ��m�F�ł��Ȃ����߁A�J�n�l(True)�֖߂���" & _
                        "Excel�C�x���g��False�Œ�~���܂����B"
                Else
                    AppendCashAnalysisRollbackDetail errorDescription, _
                        "���S��Ԃ��m�F�ł��Ȃ����߁A�J�n�l(False)�̂܂�" & _
                        "Excel�C�x���g���~���܂����B"
                End If
            Else
                AppendCashAnalysisRollbackDetail errorDescription, _
                    "���S��Ԃ��m�F�ł����AExcel�C�x���g��False��" & _
                    "���������邱�Ƃ��ł��܂���ł����B���ݏ�Ԃ͕s���ł��B " & _
                    restoreDetail
            End If
            actionCompleted = False
        End If
    End If
    If actionCompleted Then Exit Sub
    If rethrowRecoveryFatal Then _
        Err.Raise errorNumber, errorSource, errorDescription
    MsgBox "�蓮���̑���������ł��܂���ł����B" & vbCrLf & _
           "Err " & CStr(errorNumber) & ": " & errorDescription, vbExclamation
End Sub

Public Sub CashAnalysisPrimaryAction()
    Dim ws As Worksheet, statusText As String, proposedStatus As String
    Dim errorNumber As Long, errorSource As String, errorDescription As String
    Dim analysisTransactionStarted As Boolean, rollbackOK As Boolean
    Dim actionCompleted As Boolean, coreCompleted As Boolean
    Dim operationCommitted As Boolean
    Dim entryEvents As Boolean, entryEventsCaptured As Boolean
    Dim mutationDispatchStarted As Boolean, safeToRestoreEntry As Boolean
    Dim protectOK As Boolean
    Dim eventsReadyForRecovery As Boolean, recoveryConfirmed As Boolean
    Dim recoveryEnforcementFailed As Boolean
    Dim recoveryConfirmedThisAttempt As Boolean
    Dim protectionRecoveryAttempted As Boolean
    Dim protectionRecoveryFailed As Boolean
    Dim protectionRecoveryConfirmed As Boolean
    Dim rethrowRecoveryFatal As Boolean
    Dim protectRecoveryFatal As Boolean
    Dim rollbackDetail As String, eventDetail As String, restoreDetail As String
    Dim rollbackErrorNumber As Long, rollbackErrorDescription As String
    Dim rollbackErrorSource As String
    Dim protectErrorNumber As Long, protectErrorDescription As String
    Dim protectErrorSource As String
    If Not SheetExists(SH_OUTPUT_TX) Then Exit Sub
    On Error GoTo EH
    Set ws = GetSheet(SH_OUTPUT_TX)
    If Not TryGetCashAnalysisEnableEvents(entryEvents, eventDetail) Then
        StopAfterCashAnalysisEventStateFailure _
            "CashAnalysisPrimaryAction/�J�n��Ԏ擾", eventDetail, _
            eventsReadyForRecovery, False, vbNullString
        MsgBox "�m�F���e�̕ۑ����J�n�ł��܂���ł����B" & vbCrLf & _
               "Excel�C�x���g�̊J�n��Ԃ��擾�ł��܂���B " & eventDetail, _
               vbExclamation, "���͔��f�̕ۑ��͈��S��~"
        Exit Sub
    End If
    entryEventsCaptured = True
    eventsReadyForRecovery = _
        TryStopCashAnalysisEventsForRecovery(eventDetail)
    If Not eventsReadyForRecovery Then _
        Err.Raise vbObjectError + 5145, "CashAnalysisPrimaryAction", _
                  "���͔��f�̕ۑ��O��Excel�C�x���g��~���m�F�ł��܂���ł����B " & _
                  eventDetail
    If CellText(ws.Range(VIEW_STATE_MANUAL).Value) = "1" Then
        mutationDispatchStarted = True
        RegisterCashAnalysisManualSelection
        coreCompleted = True
        actionCompleted = True
        GoTo CleanExit
    End If
    If Len(CellText(ws.Range(VIEW_STATE_GROUP_ID).Value)) = 0 Then
        coreCompleted = True
        actionCompleted = True
        GoTo CleanExit
    End If
    statusText = CellText(ws.Range("C3").Value)
    If Len(statusText) = 0 Or statusText = ANALYSIS_STATUS_UNREVIEWED Then
        proposedStatus = ConfirmedStatusForCashCategory(CellText(ws.Range(VIEW_STATE_CATEGORY).Value))
        If Len(proposedStatus) = 0 Then _
            Err.Raise vbObjectError + 4969, "CashAnalysisPrimaryAction", _
                      "���݂̕��͋敪�ɑΉ�����m�F�ςݏ�Ԃ�����܂���B"
        If MsgBox("���̌����u" & proposedStatus & "�v�Ƃ��ĕۑ����܂����H" & vbCrLf & _
                  "������A�o���E�����A�m�F������������x�m�F���Ă��������B", _
                  vbYesNo + vbQuestion + vbDefaultButton2, _
                  "�m�F�󋵂̊m��") <> vbYes Then
            coreCompleted = True
            actionCompleted = True
            GoTo CleanExit
        End If
        statusText = proposedStatus
        BeginAnalysisOperationTransaction "��������\���番�͔��f��ۑ�"
        analysisTransactionStarted = True
        mutationDispatchStarted = True
        ws.Unprotect Password:=TOOL_PASSWORD
        ws.Range("C3").Value = statusText
    Else
        BeginAnalysisOperationTransaction "��������\���番�͔��f��ۑ�"
        analysisTransactionStarted = True
        mutationDispatchStarted = True
        ws.Unprotect Password:=TOOL_PASSWORD
    End If
    SyncCashAnalysisPanelReviewToWorkspace
    CommitAnalysisOperationPendingReviews "��������\���番�͔��f��ۑ�"
    RefreshCashAnalysisPanel False
    CommitAnalysisOperationTransaction
    analysisTransactionStarted = False
    operationCommitted = True
    coreCompleted = True
    actionCompleted = True
    safeToRestoreEntry = True
    GoTo CleanExit
EH:
    errorNumber = Err.Number
    errorSource = Err.Source
    errorDescription = Err.Description
    On Error GoTo 0
    If IsCashAnalysisRecoveryFatal(errorNumber, errorSource) Then
        Call TryStopCashAnalysisEventsForRecovery(eventDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    rollbackOK = True
    eventsReadyForRecovery = _
        TryStopCashAnalysisEventsForRecovery(eventDetail)
    If Not mutationDispatchStarted Then
        safeToRestoreEntry = True
        If Not eventsReadyForRecovery Then _
            AppendCashAnalysisRollbackDetail rollbackDetail, _
                "�u�b�N�ւ̕ύX�J�n�O�Ɏ��s�������ߏ����݂͂���܂���B" & _
                "�I�����̃C�x���g��Ԃ������J�n�l�֖߂��܂��B " & eventDetail
    ElseIf Not eventsReadyForRecovery Then
        AppendCashAnalysisRollbackDetail rollbackDetail, _
            "Excel�C�x���g��~���m�F�ł��Ȃ����߁A���[���o�b�N��" & _
            "Recovery�E�`�F�b�N�E��Ԃ̏����݂��s���܂���ł����B " & _
            eventDetail
        If analysisTransactionStarted Then rollbackOK = False
    ElseIf analysisTransactionStarted Then
        On Error Resume Next
        Err.Clear
        rollbackOK = RollbackAnalysisOperationTransaction(rollbackDetail)
        rollbackErrorNumber = Err.Number
        rollbackErrorSource = Err.Source
        rollbackErrorDescription = Err.Description
        Err.Clear
        On Error GoTo 0
        If IsCashAnalysisRecoveryFatal( _
               rollbackErrorNumber, rollbackErrorSource) Then
            Call TryStopCashAnalysisEventsForRecovery(eventDetail)
            Err.Raise rollbackErrorNumber, rollbackErrorSource, _
                      rollbackErrorDescription
        End If
        If rollbackErrorNumber <> 0 Then
            rollbackOK = False
            AppendCashAnalysisRollbackDetail rollbackDetail, _
                "���͑���g�����U�N�V�����̕����G���[: Err " & _
                CStr(rollbackErrorNumber) & " " & rollbackErrorDescription
        End If

        '�����̃��[���o�b�N�͊J�n�l(False)�֖߂��݌v�����A�O����
        'Recovery�E�`�F�b�N�E��ԏ����݂��O�ɂ�����x�ǖ߂��m�F����B
        eventsReadyForRecovery = _
            TryStopCashAnalysisEventsForRecovery(eventDetail)
        If Not eventsReadyForRecovery Then
            AppendCashAnalysisRollbackDetail rollbackDetail, _
                "���[���o�b�N���Excel�C�x���g��~���m�F�ł��Ȃ����߁A" & _
                "�O����Recovery�E�`�F�b�N�E��ԏ����݂��s���܂���ł����B " & _
                eventDetail
        ElseIf Not rollbackOK Then
            StopAfterCashAnalysisEventStateFailure _
                "CashAnalysisPrimaryAction/���[���o�b�N", rollbackDetail, _
                eventsReadyForRecovery, True, _
                "�O���C�x���g��~��ǖ߂��m�F�ς�", _
                recoveryEnforcementFailed, recoveryConfirmedThisAttempt
            recoveryConfirmed = recoveryConfirmedThisAttempt
            If recoveryEnforcementFailed Then
                rethrowRecoveryFatal = True
                errorNumber = vbObjectError + 5194
                errorSource = _
                    "CashAnalysisRecoveryFatal/CashAnalysisPrimaryAction"
                AppendCashAnalysisRollbackDetail errorDescription, rollbackDetail
                safeToRestoreEntry = False
                GoTo CleanExit
            End If
        End If
        If rollbackOK Then
            analysisTransactionStarted = False
            safeToRestoreEntry = True
        Else
            safeToRestoreEntry = _
                recoveryConfirmed And eventsReadyForRecovery
            If recoveryConfirmed Then
                AppendCashAnalysisRollbackDetail rollbackDetail, _
                    "���͑���g�����U�N�V���������S�ɂ͕����ł����A" & _
                    "�v������ԂƂ��Ă̒�~���m�F���܂����B"
            Else
                AppendCashAnalysisRollbackDetail rollbackDetail, _
                    "���͑���g�����U�N�V���������S�ɂ͕����ł����A" & _
                    "���S��Ԃ���ӂɊm�F�ł��܂���B"
            End If
        End If
    Else
        '�蓮��⑤�̓���q���������s�����ꍇ���A�O���ōĕی�܂���
        'Recovery��Ԃ������m�F�ł����ꍇ�����J�n���C�x���g�֖߂��B
        On Error Resume Next
        Err.Clear
        protectOK = TryProtectCashAnalysisViewAfterFailure( _
                        ws, "CashAnalysisPrimaryAction", _
                        False, rollbackDetail, _
                        protectionRecoveryAttempted, _
                        protectionRecoveryFailed, _
                        protectionRecoveryConfirmed)
        protectErrorNumber = Err.Number
        protectErrorSource = Err.Source
        protectErrorDescription = Err.Description
        Err.Clear
        On Error GoTo 0
        protectRecoveryFatal = _
            IsCashAnalysisRecoveryFatal( _
                protectErrorNumber, protectErrorSource)
        If protectRecoveryFatal Then
            Call TryStopCashAnalysisEventsForRecovery(eventDetail)
            Err.Raise protectErrorNumber, protectErrorSource, _
                      protectErrorDescription
        End If
        If protectErrorNumber <> 0 Then _
            AppendCashAnalysisRollbackDetail rollbackDetail, _
                "�ĕی쏈���̗\�����Ȃ��G���[: Err " & _
                CStr(protectErrorNumber) & " " & protectErrorDescription
        eventsReadyForRecovery = _
            TryStopCashAnalysisEventsForRecovery(eventDetail)
        If Not eventsReadyForRecovery Then
            AppendCashAnalysisRollbackDetail rollbackDetail, _
                "�ĕی쏈�����Excel�C�x���g��~���m�F�ł����A" & _
                "�J�n��Ԃ֖߂�����S�������m�F�ł��܂���ł����B " & _
                eventDetail
        ElseIf protectionRecoveryAttempted Then
            rethrowRecoveryFatal = True
            errorNumber = vbObjectError + 5194
            errorSource = _
                "CashAnalysisRecoveryFatal/CashAnalysisPrimaryAction"
            AppendCashAnalysisRollbackDetail errorDescription, rollbackDetail
            safeToRestoreEntry = False
            GoTo CleanExit
        ElseIf protectOK Then
            safeToRestoreEntry = True
        ElseIf protectionRecoveryAttempted Then
            recoveryConfirmed = protectionRecoveryConfirmed
            safeToRestoreEntry = recoveryConfirmed
        End If
    End If
    If Len(rollbackDetail) > 0 Then _
        errorDescription = errorDescription & " / �����m�F: " & rollbackDetail
    actionCompleted = False
CleanExit:
    '��������̓u�b�N�֏������܂Ȃ��B�O���C�x���g��Ԃ̕�����
    '�S�����̍Ō�ɍs���A���̌�ɋ���UI������MsgBox�����Ƃ���B
    If entryEventsCaptured Then
        entryEventsCaptured = False
        If actionCompleted And Not rethrowRecoveryFatal Then _
            safeToRestoreEntry = True
        If safeToRestoreEntry Then _
            safeToRestoreEntry = _
                CashAnalysisApplicationStateAllowsEntryRestore( _
                    entryEvents, errorDescription)
        If safeToRestoreEntry Then
            If Not TryRestoreCashAnalysisEnableEvents( _
                       entryEvents, "CashAnalysisPrimaryAction/�I������", _
                       restoreDetail) Then
                If errorNumber = 0 Then errorNumber = vbObjectError + 5146
                If actionCompleted Then
                    errorDescription = _
                        "����{�̂̏I�����Excel�C�x���g��Ԃ��J�n����" & _
                        "�߂��܂���ł����B"
                End If
                AppendCashAnalysisRollbackDetail errorDescription, restoreDetail
                actionCompleted = False
            End If
        Else
            eventsReadyForRecovery = _
                TryStopCashAnalysisEventsForRecovery(restoreDetail)
            If eventsReadyForRecovery Then
                If entryEvents Then
                    AppendCashAnalysisRollbackDetail errorDescription, _
                        "���S��Ԃ��m�F�ł��Ȃ����߁A�J�n�l(True)�֖߂���" & _
                        "Excel�C�x���g��False�Œ�~���܂����B"
                Else
                    AppendCashAnalysisRollbackDetail errorDescription, _
                        "���S��Ԃ��m�F�ł��Ȃ����߁A�J�n�l(False)�̂܂�" & _
                        "Excel�C�x���g���~���܂����B"
                End If
            Else
                AppendCashAnalysisRollbackDetail errorDescription, _
                    "���S��Ԃ��m�F�ł����AExcel�C�x���g��False��" & _
                    "���������邱�Ƃ��ł��܂���ł����B���ݏ�Ԃ͕s���ł��B " & _
                    restoreDetail
            End If
            actionCompleted = False
        End If
    End If
    If actionCompleted Then Exit Sub
    If rethrowRecoveryFatal Then
        If Len(errorSource) = 0 Then _
            errorSource = "CashAnalysisRecoveryFatal/CashAnalysisPrimaryAction"
        Err.Raise errorNumber, errorSource, errorDescription
    End If

    If operationCommitted Then
        MsgBox "�m�F���e�̕ۑ��͊������܂������A�I������Excel�C�x���g��Ԃ�" & _
               "�J�n���֖߂��܂���ł����B" & vbCrLf & _
               "���݂̃u�b�N���㏑�������A�\�����ꂽ���������m�F���Ă��������B" & _
               vbCrLf & "Err " & CStr(errorNumber) & ": " & errorDescription, _
               vbExclamation, "���͔��f�̕ۑ���ɗv�m�F"
    ElseIf coreCompleted Then
        MsgBox "����{�̂͏I�����܂������A�I������Excel�C�x���g��Ԃ�" & _
               "�J�n���֖߂��܂���ł����B" & vbCrLf & _
               "Err " & CStr(errorNumber) & ": " & errorDescription, _
               vbExclamation, "��������\�̏I����Ԃ�v�m�F"
    ElseIf analysisTransactionStarted And Not rollbackOK Then
        If recoveryConfirmed Then
            MsgBox "�m�F���e��ۑ��ł����A����J�n�O�̏�Ԃ֊��S�ɂ͖߂��܂���ł����B" & _
                   vbCrLf & "�Č���v�����Ƃ��Ē�~���܂����B���݂̃u�b�N���㏑�����Ȃ��ł��������B" & vbCrLf & _
                   "Err " & CStr(errorNumber) & ": " & errorDescription, _
                   vbExclamation, "���͔��f�̕ۑ��͗v����"
        Else
            MsgBox "�m�F���e��ۑ��ł����A����J�n�O�̏�Ԃ֊��S�ɂ͖߂��܂���ł����B" & _
                   vbCrLf & "���S��Ԃ���ӂɊm�F�ł����A�ʏ푀��֖߂��܂���B" & _
                   "���݂̃u�b�N���㏑�����Ȃ��ł��������B" & vbCrLf & _
                   "Err " & CStr(errorNumber) & ": " & errorDescription, _
                   vbExclamation, "���͔��f�̕ۑ��͈��S��Ԗ��m�F"
        End If
    Else
        MsgBox "�m�F���e��ۑ��ł��܂���ł����B" & vbCrLf & _
               "�m�F�󋵁E�m�F�������������Ă��������B" & vbCrLf & _
               "Err " & CStr(errorNumber) & ": " & errorDescription, vbExclamation
    End If
End Sub

Private Sub EnterCashAnalysisManualMode()
    Dim ws As Worksheet
    Dim workbookWasSaved As Boolean
    Dim previousEvents As Boolean, eventsCaptured As Boolean
    Dim eventsRestoreAttempted As Boolean, eventsReadyForRecovery As Boolean
    Dim actionMutationStarted As Boolean, protectOK As Boolean
    Dim safeToRestoreEntry As Boolean
    Dim eventStateDetail As String, stopDetail As String
    Dim convergenceDetail As String
    Dim errorNumber As Long, errorSource As String, errorDescription As String
    If ThisWorkbook.ReadOnly Then
        MsgBox "�ǂݎ���p�ł͎蓮����o�^�ł��܂���B", vbExclamation
        Exit Sub
    End If
    On Error GoTo EH
    Set ws = GetSheet(SH_OUTPUT_TX)
    workbookWasSaved = ThisWorkbook.Saved
    If Not TryGetCashAnalysisEnableEvents(previousEvents, eventStateDetail) Then _
        Err.Raise vbObjectError + 5134, "EnterCashAnalysisManualMode", _
                  "Excel�C�x���g�̊J�n��Ԃ��擾�ł��܂���ł����B " & eventStateDetail
    eventsCaptured = True
    If Not TrySetCashAnalysisEnableEventsExact(False, eventStateDetail) Then _
        Err.Raise vbObjectError + 5135, "EnterCashAnalysisManualMode", _
                  "�蓮�I�����[�h�J�n�O��Excel�C�x���g���~�ł��܂���ł����B " & eventStateDetail
    actionMutationStarted = True
    SyncCashAnalysisPanelReviewToWorkspace
    ws.Unprotect Password:=TOOL_PASSWORD
    ws.Range(VIEW_STATE_MANUAL).Value = "1"
    ws.Range(VIEW_STATE_SELECTED_IDS).ClearContents
    ws.Range(VIEW_STATE_PANEL_EXPANDED).Value = "0"
    RefreshCashAnalysisPanel False
    If workbookWasSaved Then ThisWorkbook.Saved = True
    eventsRestoreAttempted = True
    If Not TryRestoreCashAnalysisEnableEvents( _
               previousEvents, "EnterCashAnalysisManualMode", _
               eventStateDetail) Then _
        Err.Raise vbObjectError + 5136, _
                  "EnterCashAnalysisManualMode", eventStateDetail
    eventsCaptured = False
    MsgBox "�蓮���̑I�����[�h�ɐ؂�ւ��܂����B" & vbCrLf & _
           "��������\�̎���s���_�u���N���b�N���đI�����Ă��������B" & vbCrLf & _
           "�E�vL����_�u���N���b�N����ƁA�I����ς����ɑS�����m�F�ł��܂��B" & vbCrLf & _
           "�o���Ɠ����͕ʁX�ɏW�v����A�㕔�ō��z���m�F�ł��܂��B", _
           vbInformation, "�蓮���̑I��"
    Exit Sub
EH:
    errorNumber = Err.Number
    errorSource = Err.Source
    errorDescription = Err.Description
    If IsCashAnalysisRecoveryFatal(errorNumber, errorSource) Then
        Call TryStopCashAnalysisEventsForRecovery(convergenceDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    If eventsCaptured Then
        If Not eventsRestoreAttempted Then _
            eventsReadyForRecovery = _
                TryStopCashAnalysisEventsForRecovery(stopDetail)
    End If
    If actionMutationStarted And Not eventsRestoreAttempted Then
        If eventsReadyForRecovery Then
            protectOK = TryProtectCashAnalysisViewAfterFailure( _
                            ws, "EnterCashAnalysisManualMode", _
                            False, errorDescription)
            safeToRestoreEntry = _
                CashAnalysisOuterLeaseMayRestoreAfterProtection( _
                    protectOK, errorDescription)
        Else
            AppendCashAnalysisRollbackDetail errorDescription, _
                "Excel�C�x���g��~��ǖ߂��m�F�ł��Ȃ����߁A" & _
                "�u�b�N�̍ĕی��Recovery�����݂��s���܂���ł����B " & _
                stopDetail
        End If
    End If
    If eventsCaptured And Not eventsRestoreAttempted Then
        eventsRestoreAttempted = True
        If Not actionMutationStarted Or safeToRestoreEntry Then
            If Not TryRestoreCashAnalysisEnableEvents( _
                       previousEvents, _
                       "EnterCashAnalysisManualMode/�G���[�I��", _
                       eventStateDetail) Then _
                AppendCashAnalysisRollbackDetail errorDescription, _
                    eventStateDetail
        ElseIf TryStopCashAnalysisEventsForRecovery(convergenceDetail) Then
            AppendCashAnalysisRollbackDetail errorDescription, _
                "�ĕی�܂���Recovery�������m�F�ł��Ȃ����߁A" & _
                "�J�n���C�x���g�l�֖߂���False�Œ�~���܂����B"
        Else
            AppendCashAnalysisRollbackDetail errorDescription, _
                "���S��Ԃ������m�F�ł����AExcel�C�x���g��False�����ɂ�" & _
                "���s���܂����B���ݏ�Ԃ͕s���ł�: " & convergenceDetail
        End If
    End If
    eventsCaptured = False
    If Len(errorSource) = 0 Then errorSource = "EnterCashAnalysisManualMode"
    Err.Raise errorNumber, errorSource, errorDescription
End Sub

Private Sub RefreshCashManualSelectionPanel(ByVal ws As Worksheet)
    Dim selected As Object, validSelected As Object, lastR As Long, data As Variant
    Dim displayData() As Variant, roleData() As Variant, selectionData() As Variant
    Dim r As Long, rowCount As Long, txID As String, roleText As String
    Dim withdrawal As Double, deposit As Double, totalWithdrawal As Double, totalDeposit As Double
    Dim outCount As Long, inCount As Long
    Set selected = IDsToDictionary(CellText(ws.Range(VIEW_STATE_SELECTED_IDS).Value))
    Set validSelected = CreateObject("Scripting.Dictionary")
    validSelected.CompareMode = vbTextCompare
    lastR = CashAnalysisLastDataRow(ws)
    If lastR >= CASH_VIEW_FIRST_DATA_ROW Then
        data = ws.Range(ws.Cells(CASH_VIEW_FIRST_DATA_ROW, 1), _
                        ws.Cells(lastR, OUT_COL_RECORD_TYPE)).Value2
        rowCount = UBound(data, 1)
        ReDim displayData(1 To rowCount, 1 To 1)
        ReDim roleData(1 To rowCount, 1 To 1)
        ReDim selectionData(1 To rowCount, 1 To 1)
        For r = 1 To rowCount
            displayData(r, 1) = "1"
            txID = CellText(data(r, OUT_COL_TRANSACTION_ID))
            If Len(txID) > 0 And selected.Exists(txID) And _
               StrComp(CellText(data(r, OUT_COL_RECORD_TYPE)), RECORD_TRANSACTION, vbTextCompare) = 0 Then
                validSelected(txID) = True
                withdrawal = CashViewDouble(data(r, OUT_COL_WITHDRAW))
                deposit = CashViewDouble(data(r, OUT_COL_DEPOSIT))
                roleText = CashViewRole(withdrawal, deposit)
                roleData(r, 1) = roleText
                selectionData(r, 1) = "1"
                AccumulateCashManualTotals withdrawal, deposit, totalWithdrawal, _
                                           totalDeposit, outCount, inCount
            End If
        Next r
        ws.Range(ws.Cells(CASH_VIEW_FIRST_DATA_ROW, CASH_VIEW_COL_DISPLAY), _
                 ws.Cells(lastR, CASH_VIEW_COL_DISPLAY)).Value = displayData
        ws.Range(ws.Cells(CASH_VIEW_FIRST_DATA_ROW, CASH_VIEW_COL_ROLE), _
                 ws.Cells(lastR, CASH_VIEW_COL_ROLE)).Value = roleData
        ws.Range(ws.Cells(CASH_VIEW_FIRST_DATA_ROW, CASH_VIEW_COL_SELECTED), _
                 ws.Cells(lastR, CASH_VIEW_COL_SELECTED)).Value = selectionData
        ApplyCashViewAutoFilter ws, lastR, False
    End If
    Set selected = validSelected
    ws.Range(VIEW_STATE_SELECTED_IDS).Value = JoinCashDictionaryKeys(selected)

    ws.Range("F1").Value = "�蓮����I�𒆁@�I�� " & CStr(selected.Count) & _
                           "���i�o�� " & CStr(outCount) & "�� / ���� " & CStr(inCount) & "���j"
    ws.Range("C3").Value = "�I��"
    SetCashAnalysisTotals ws, totalWithdrawal, totalDeposit
    ws.Range("C5").Value = "�s���_�u���N���b�N�i�E�vL��͑S���\���j"
    ws.Range("H5").Value = "�o���Ɠ��������ꂼ��1���ȏ�I�����Ă��������B"
    ws.Range("C6").Value = "�E�vL��ȊO���_�u���N���b�N����ƑI���^�������܂��B�I���s�͒W�����F�ŕ\�����A�o���z�Ɠ����z�͕ʗ��̂܂܏W�v���܂��B"
    ws.Range("C7").Value = "�o�^�O�ɁA���t�E�����E�E�v�ƍ��z���������Ŋm�F���Ă��������B"
    ws.Range("C8").Value = ""
    ws.Range("C3:D3").Locked = True
    ws.Range("C8:M8").Locked = True
    SetShapeCaption ws, "CycleCashAnalysisViewMode", "�\��: �S���"
    SetShapeCaption ws, "CashAnalysisSecondaryAction", "�I����������"
    SetViewButtonColors ws, "CashAnalysisSecondaryAction", _
                        RGB(254, 242, 242), RGB(220, 38, 38), RGB(153, 27, 27)
    SetShapeCaption ws, "CashAnalysisPrimaryAction", "�I����������o�^"
    '���O���̊m�F�ς݁E�ΏۊO�E���Ȃ��F�������p���Ȃ��B
    '�蓮�I���ł͓o�^�Ƃ��������������ɓ����F�Ŏ����B
    SetViewButtonColors ws, "CashAnalysisPrimaryAction", _
                        RGB(37, 99, 235), RGB(29, 78, 216), RGB(255, 255, 255)
End Sub

Public Sub OnCashAnalysisViewDoubleClick(ByVal targetRow As Long, _
                                         Optional ByVal targetColumn As Long = 0)
    Dim ws As Worksheet, txID As String
    If Not SheetExists(SH_OUTPUT_TX) Then Exit Sub
    Set ws = GetSheet(SH_OUTPUT_TX)
    If targetRow < CASH_VIEW_FIRST_DATA_ROW Or targetRow > CashAnalysisLastDataRow(ws) Then Exit Sub
    If StrComp(CellText(ws.Cells(targetRow, OUT_COL_RECORD_TYPE).Value), _
               RECORD_TRANSACTION, vbTextCompare) <> 0 Then Exit Sub
    txID = CellText(ws.Cells(targetRow, OUT_COL_TRANSACTION_ID).Value)
    If Len(txID) = 0 Then Exit Sub
    If targetColumn = OUT_COL_TEKIYO Then
        ShowCashAnalysisTransactionText ws, targetRow
    ElseIf CellText(ws.Range(VIEW_STATE_MANUAL).Value) = "1" Then
        ToggleCashManualTransaction ws, txID
    Else
        FocusCashAnalysisCandidateByTransaction ws, txID
    End If
End Sub

Private Sub ShowCashAnalysisTransactionText(ByVal ws As Worksheet, ByVal targetRow As Long)
    Dim dateText As String, timeText As String, amountText As String, promptText As String
    If ws Is Nothing Then Exit Sub
    If IsDate(ws.Cells(targetRow, OUT_COL_DATE).Value) Then _
        dateText = Format$(CDate(ws.Cells(targetRow, OUT_COL_DATE).Value), "yyyy/m/d")
    If IsDate(ws.Cells(targetRow, OUT_COL_TIME).Value) Then _
        timeText = Format$(CDate(ws.Cells(targetRow, OUT_COL_TIME).Value), "hh:mm")
    If Len(timeText) = 0 Then timeText = "�����L�ڂȂ�"
    If CashViewDouble(ws.Cells(targetRow, OUT_COL_WITHDRAW).Value) <> 0 Then
        amountText = "�o�� " & Format$(CashViewDouble(ws.Cells(targetRow, OUT_COL_WITHDRAW).Value), "#,##0.########")
    ElseIf CashViewDouble(ws.Cells(targetRow, OUT_COL_DEPOSIT).Value) <> 0 Then
        amountText = "���� " & Format$(CashViewDouble(ws.Cells(targetRow, OUT_COL_DEPOSIT).Value), "#,##0.########")
    Else
        amountText = "���z 0"
    End If
    promptText = "���t�E����: " & dateText & " " & timeText & vbCrLf & _
                 "����: " & CellText(ws.Cells(targetRow, OUT_COL_BANK).Value) & " " & _
                 CellText(ws.Cells(targetRow, OUT_COL_BRANCH).Value) & " / " & _
                 CellText(ws.Cells(targetRow, OUT_COL_PERSON).Value) & vbCrLf & _
                 "���z: " & amountText & vbCrLf & _
                 "�戵�X�E�@��: " & CellText(ws.Cells(targetRow, OUT_COL_SHOP).Value) & " " & _
                 CellText(ws.Cells(targetRow, OUT_COL_MACHINE).Value) & vbCrLf & vbCrLf & _
                 "�E�v��" & vbCrLf & CellText(ws.Cells(targetRow, OUT_COL_TEKIYO).Value)
    ShowCashAnalysisLongMessage promptText, "����̓E�v��S���\��"
End Sub

Public Sub ShowCashAnalysisPanelText(ByVal targetRow As Long)
    Dim ws As Worksheet, titleText As String, promptText As String, alternativeText As String
    If Not SheetExists(SH_OUTPUT_TX) Then Exit Sub
    Set ws = GetSheet(SH_OUTPUT_TX)
    Select Case targetRow
        Case 5
            titleText = "���t�E�l���E�����o�H��S���\��"
            promptText = "���t�E����" & vbCrLf & CellText(ws.Range("C5").Value) & _
                         vbCrLf & vbCrLf & "�l���E�����o�H" & vbCrLf & _
                         CellText(ws.Range("H5").Value)
        Case 6
            titleText = "���o���R�E�v�_��S���\��"
            promptText = CellText(ws.Range("C6").Value)
        Case 7
            titleText = "���؁E�����S���\��"
            promptText = CellText(ws.Range("C7").Value)
            alternativeText = CashAnalysisAlternativePanelText(ws)
            If Len(alternativeText) > 0 Then _
                promptText = promptText & vbCrLf & vbCrLf & alternativeText
        Case Else
            Exit Sub
    End Select
    If Len(promptText) = 0 Then promptText = "�i�\��������e�͂���܂���j"
    ShowCashAnalysisLongMessage promptText, titleText
End Sub

Private Function NextUnreviewedGroupIndex(ByVal wsResult As Worksheet, _
                                          ByVal entries As Collection, _
                                          ByVal currentIndex As Long) As Long
    '���m�F���Ɠ����P�ʁi��\�O���[�v�j�ňړ��B��֌��͒ʏ�̑O��ړ��Ŋm�F����B
    '�m�F�󋵂��ꊇ�擾���A��␔�ɔ�Ⴕ���Z���A�N�Z�X�������B
    Dim pending As Object, groupValues As Variant, statusValues As Variant
    Dim lastR As Long, r As Long, offset As Long, index As Long
    Dim groupID As String, statusText As String, entry As Variant
    Set pending = CreateObject("Scripting.Dictionary")
    pending.CompareMode = vbTextCompare
    lastR = LastUsedRowInSheet(wsResult)
    If lastR < 2 Or entries.Count = 0 Then Exit Function
    groupValues = CashResultColumnValues(wsResult, 2, lastR, ANALYSIS_RESULT_GROUP_ID_COL)
    statusValues = CashResultColumnValues(wsResult, 2, lastR, ANALYSIS_RESULT_STATUS_COL)
    For r = 1 To lastR - 1
        groupID = CellText(groupValues(r, 1))
        statusText = CellText(statusValues(r, 1))
        If Len(groupID) > 0 Then
            If Len(statusText) = 0 Or statusText = ANALYSIS_STATUS_UNREVIEWED Then _
                pending(groupID) = True
        End If
    Next r
    For offset = 1 To entries.Count
        index = ((currentIndex - 1 + offset) Mod entries.Count) + 1
        entry = entries(index)
        If Len(CStr(entry(1))) = 0 And pending.Exists(CStr(entry(0))) Then
            NextUnreviewedGroupIndex = index
            Exit Function
        End If
    Next offset
End Function

Private Function BuildCashAnalysisNavigationEntries( _
        ByVal wsResult As Worksheet, ByVal wsGroup As Worksheet, _
        ByVal categoryText As String, ByVal txPersonMap As Object) As Collection
    Dim entries As New Collection
    Dim groupRowsByID As Object, groupRows As Collection
    Dim lastResultRow As Long, lastGroupRow As Long
    Dim resultCategories As Variant, resultGroups As Variant
    Dim groupIDs As Variant, sourceSheets As Variant, sourceRows As Variant
    Dim sourceKeys As Variant, txIDs As Variant, representativeFlags As Variant
    Dim seenRefs As Object, seenResultGroups As Object
    Dim groupID As String, personClass As String, candidateRef As String
    Dim r As Long, passNo As Long, rowItem As Variant, groupRow As Long
    Dim representativeCount As Long

    Set groupRowsByID = CreateObject("Scripting.Dictionary")
    groupRowsByID.CompareMode = vbTextCompare
    lastGroupRow = LastUsedRowInSheet(wsGroup)
    If lastGroupRow >= 2 Then
        groupIDs = CashResultColumnValues(wsGroup, 2, lastGroupRow, 1)
        sourceSheets = CashResultColumnValues(wsGroup, 2, lastGroupRow, 2)
        sourceRows = CashResultColumnValues(wsGroup, 2, lastGroupRow, 3)
        sourceKeys = CashResultColumnValues(wsGroup, 2, lastGroupRow, 4)
        txIDs = CashResultColumnValues(wsGroup, 2, lastGroupRow, 5)
        representativeFlags = CashResultColumnValues(wsGroup, 2, lastGroupRow, 7)
        For r = 1 To lastGroupRow - 1
            groupID = CellText(groupIDs(r, 1))
            If Len(groupID) > 0 Then
                If Not groupRowsByID.Exists(groupID) Then
                    Set groupRows = New Collection
                    groupRowsByID.Add groupID, groupRows
                End If
                Set groupRows = groupRowsByID(groupID)
                groupRows.Add r
            End If
        Next r
    End If

    lastResultRow = LastUsedRowInSheet(wsResult)
    If lastResultRow < 2 Then
        Set BuildCashAnalysisNavigationEntries = entries
        Exit Function
    End If
    resultCategories = CashResultColumnValues(wsResult, 2, lastResultRow, 2)
    resultGroups = CashResultColumnValues( _
                       wsResult, 2, lastResultRow, ANALYSIS_RESULT_GROUP_ID_COL)
    Set seenResultGroups = CreateObject("Scripting.Dictionary")
    seenResultGroups.CompareMode = vbTextCompare
    For r = 1 To lastResultRow - 1
        If CashViewCategoryForResult(CellText(resultCategories(r, 1))) = categoryText Then
            groupID = CellText(resultGroups(r, 1))
            If Len(groupID) = 0 Then _
                Err.Raise vbObjectError + 5004, "BuildCashAnalysisNavigationEntries", _
                          "���͌��ʂɃO���[�vID������܂���B"
            If seenResultGroups.Exists(groupID) Then _
                Err.Raise vbObjectError + 5004, "BuildCashAnalysisNavigationEntries", _
                          "���͌��ʂɓ����O���[�vID���d�����Ă��܂��B"
            seenResultGroups.Add groupID, True
            entries.Add Array(groupID, vbNullString)
            Set seenRefs = CreateObject("Scripting.Dictionary")
            seenRefs.CompareMode = vbBinaryCompare
            If Not groupRowsByID.Exists(groupID) Then _
                Err.Raise vbObjectError + 5005, _
                          "BuildCashAnalysisNavigationEntries", _
                          "���͌��ʂɑΉ���������O���[�v������܂���B"
            Set groupRows = groupRowsByID(groupID)
            representativeCount = 0
            For Each rowItem In groupRows
                groupRow = CLng(rowItem)
                If StrComp(CellText(representativeFlags(groupRow, 1)), _
                           "��\", vbBinaryCompare) = 0 Then
                    representativeCount = representativeCount + 1
                ElseIf StrComp(CellText(representativeFlags(groupRow, 1)), _
                              "���", vbBinaryCompare) <> 0 Then
                    Err.Raise vbObjectError + 5006, _
                              "BuildCashAnalysisNavigationEntries", _
                              "���̓O���[�v�̑�\�敪���s���ł��B"
                End If
            Next rowItem
            If representativeCount <> 1 Then _
                Err.Raise vbObjectError + 5006, _
                          "BuildCashAnalysisNavigationEntries", _
                          "���̓O���[�v�̑�\��₪��ӂł͂���܂���B"
            For passNo = 1 To 2
                For Each rowItem In groupRows
                    groupRow = CLng(rowItem)
                    If StrComp(CellText(representativeFlags(groupRow, 1)), _
                               "���", vbBinaryCompare) = 0 Then
                        personClass = CashAlternativePersonClass( _
                                          CellText(txIDs(groupRow, 1)), txPersonMap)
                        If CashAnalysisNavigationRank("���", personClass) = passNo Then
                            candidateRef = CashAnalysisCandidateReference( _
                                               CellText(sourceSheets(groupRow, 1)), _
                                               CLng(Val(CellText(sourceRows(groupRow, 1)))), _
                                               CellText(sourceKeys(groupRow, 1)))
                            If Len(candidateRef) = 0 Or seenRefs.Exists(candidateRef) Then _
                                Err.Raise vbObjectError + 5005, _
                                          "BuildCashAnalysisNavigationEntries", _
                                          "�����O���[�v�̑�֌��Q�Ƃ��s���܂��͏d�����Ă��܂��B"
                            seenRefs.Add candidateRef, True
                            entries.Add Array(groupID, candidateRef)
                        End If
                    End If
                Next rowItem
            Next passNo
        End If
    Next r
    Set BuildCashAnalysisNavigationEntries = entries
End Function

Private Function CashAnalysisNavigationRank(ByVal representativeText As String, _
                                            ByVal personClass As String) As Long
    If StrComp(representativeText, "��\", vbBinaryCompare) = 0 Then
        CashAnalysisNavigationRank = 0
    ElseIf StrComp(representativeText, "���", vbBinaryCompare) <> 0 Then
        Err.Raise vbObjectError + 5007, "CashAnalysisNavigationRank", _
                  "���̑�\�敪���s���ł��B"
    ElseIf personClass = VIEW_PERSON_DIFFERENT Then
        CashAnalysisNavigationRank = 1
    ElseIf personClass = VIEW_PERSON_SAME Then
        CashAnalysisNavigationRank = 2
    Else
        Err.Raise vbObjectError + 5008, "CashAnalysisNavigationRank", _
                  "���̐l���敪���s���ł��B"
    End If
End Function

Private Function CashAnalysisWrappedNavigationIndex( _
        ByVal currentIndex As Long, ByVal entryCount As Long, _
        ByVal direction As Long) As Long
    If entryCount < 1 Or currentIndex < 1 Or currentIndex > entryCount Or _
       (direction <> -1 And direction <> 1) Then _
        Err.Raise vbObjectError + 5009, "CashAnalysisWrappedNavigationIndex", _
                  "���z�̈ʒu�܂��͕������s���ł��B"
    CashAnalysisWrappedNavigationIndex = currentIndex + direction
    If CashAnalysisWrappedNavigationIndex < 1 Then _
        CashAnalysisWrappedNavigationIndex = entryCount
    If CashAnalysisWrappedNavigationIndex > entryCount Then _
        CashAnalysisWrappedNavigationIndex = 1
End Function

Private Function CashAnalysisCandidateReference( _
        ByVal sourceSheet As String, ByVal sourceRow As Long, _
        ByVal sourceKey As String) As String
    If Len(sourceSheet) = 0 Or sourceRow < 2 Or Len(sourceKey) = 0 Then Exit Function
    'XML�֕ۑ��ł��Ȃ����䕶������ԃZ���֓��ꂸ�A�����t���̈���Q�Ƃɂ���B
    CashAnalysisCandidateReference = CStr(Len(sourceSheet)) & ":" & sourceSheet & ":" & _
                                     CStr(sourceRow) & ":" & sourceKey
End Function

Private Function FindCashAnalysisAlternativeRow( _
        ByVal wsGroup As Worksheet, ByVal groupID As String, _
        ByVal candidateRef As String) As Long
    Dim lastR As Long, r As Long
    Dim groupIDs As Variant, sourceSheets As Variant, sourceRows As Variant
    Dim sourceKeys As Variant, representativeFlags As Variant
    Dim rowRef As String
    If wsGroup Is Nothing Or Len(groupID) = 0 Or Len(candidateRef) = 0 Then Exit Function
    lastR = LastUsedRowInSheet(wsGroup)
    If lastR < 2 Then Exit Function
    groupIDs = CashResultColumnValues(wsGroup, 2, lastR, 1)
    sourceSheets = CashResultColumnValues(wsGroup, 2, lastR, 2)
    sourceRows = CashResultColumnValues(wsGroup, 2, lastR, 3)
    sourceKeys = CashResultColumnValues(wsGroup, 2, lastR, 4)
    representativeFlags = CashResultColumnValues(wsGroup, 2, lastR, 7)
    For r = 1 To lastR - 1
        If StrComp(CellText(groupIDs(r, 1)), groupID, vbBinaryCompare) = 0 And _
           StrComp(CellText(representativeFlags(r, 1)), "���", vbBinaryCompare) = 0 Then
            rowRef = CashAnalysisCandidateReference( _
                         CellText(sourceSheets(r, 1)), _
                         CLng(Val(CellText(sourceRows(r, 1)))), _
                         CellText(sourceKeys(r, 1)))
            If StrComp(rowRef, candidateRef, vbBinaryCompare) = 0 Then
                If FindCashAnalysisAlternativeRow <> 0 Then _
                    Err.Raise vbObjectError + 5010, _
                              "FindCashAnalysisAlternativeRow", _
                              "��֌��̓����Q�Ƃ��d�����Ă��܂��B"
                FindCashAnalysisAlternativeRow = r + 1
            End If
        End If
    Next r
End Function

Private Sub CashAnalysisGroupCandidatePosition( _
        ByVal wsGroup As Worksheet, ByVal groupID As String, _
        ByVal targetGroupRow As Long, ByVal txPersonMap As Object, _
        ByRef candidatePosition As Long, ByRef candidateCount As Long)
    Dim lastR As Long, r As Long, passNo As Long
    Dim groupIDs As Variant, txIDs As Variant, representativeFlags As Variant
    Dim personClass As String
    candidateCount = 1
    If wsGroup Is Nothing Or Len(groupID) = 0 Then Exit Sub
    lastR = LastUsedRowInSheet(wsGroup)
    If lastR < 2 Then Exit Sub
    groupIDs = CashResultColumnValues(wsGroup, 2, lastR, 1)
    txIDs = CashResultColumnValues(wsGroup, 2, lastR, 5)
    representativeFlags = CashResultColumnValues(wsGroup, 2, lastR, 7)
    For passNo = 1 To 2
        For r = 1 To lastR - 1
            If StrComp(CellText(groupIDs(r, 1)), groupID, vbBinaryCompare) = 0 And _
               StrComp(CellText(representativeFlags(r, 1)), "���", vbBinaryCompare) = 0 Then
                personClass = CashAlternativePersonClass( _
                                  CellText(txIDs(r, 1)), txPersonMap)
                If CashAnalysisNavigationRank("���", personClass) = passNo Then
                    candidateCount = candidateCount + 1
                    If r + 1 = targetGroupRow Then candidatePosition = candidateCount
                End If
            End If
        Next r
    Next passNo
End Sub

Private Sub AccumulateCashManualTotals(ByVal withdrawal As Double, ByVal deposit As Double, _
                                       ByRef totalWithdrawal As Double, _
                                       ByRef totalDeposit As Double, _
                                       ByRef withdrawalCount As Long, _
                                       ByRef depositCount As Long)
    totalWithdrawal = totalWithdrawal + withdrawal
    totalDeposit = totalDeposit + deposit
    If withdrawal > 0 Then withdrawalCount = withdrawalCount + 1
    If deposit > 0 Then depositCount = depositCount + 1
End Sub

Private Function CashAnalysisAlternativePanelText(ByVal wsView As Worksheet) As String
    Const MAX_VISIBLE_ALTERNATIVES As Long = 12
    Dim wsGroup As Worksheet, lastR As Long, r As Long, matchCount As Long, shownCount As Long
    Dim data As Variant, groupID As String, lineText As String, sourceSheet As String
    Dim sourceRow As Long, personClass As String, txIDList As String
    Dim txPersonMap As Object
    If wsView Is Nothing Or Not SheetExists(SH_WORK_ANALYSIS_GROUP) Then Exit Function
    groupID = CellText(wsView.Range(VIEW_STATE_GROUP_ID).Value)
    If Len(groupID) = 0 Then Exit Function
    Set wsGroup = GetSheet(SH_WORK_ANALYSIS_GROUP)
    lastR = LastUsedRowInSheet(wsGroup)
    If lastR < 2 Then Exit Function
    data = wsGroup.Range(wsGroup.Cells(2, 1), _
                         wsGroup.Cells(lastR, ANALYSIS_GROUP_LAST_COL)).Value2
    For r = 1 To UBound(data, 1)
        If StrComp(CellText(data(r, 1)), groupID, vbBinaryCompare) = 0 Then _
            matchCount = matchCount + 1
    Next r
    If matchCount <= 1 Then Exit Function
    Set txPersonMap = CashAnalysisTransactionPersonMap()
    CashAnalysisAlternativePanelText = _
        "��։����ꗗ�i�ʐl���Ԃ��ɕ\���j"
    For r = 1 To UBound(data, 1)
        If StrComp(CellText(data(r, 1)), groupID, vbBinaryCompare) = 0 Then
            shownCount = shownCount + 1
            If shownCount <= MAX_VISIBLE_ALTERNATIVES Then
                sourceSheet = CellText(data(r, 2))
                sourceRow = CLng(Val(CellText(data(r, 3))))
                txIDList = CellText(data(r, 5))
                personClass = CashAlternativePersonClass(txIDList, txPersonMap)
                lineText = CStr(shownCount) & ". �m" & personClass & " / " & _
                           CellText(data(r, 7)) & "�n " & CellText(data(r, 8)) & _
                           "�@�]�� " & CellText(data(r, 6)) & _
                           "�@�m�F�� " & CellText(data(r, 9))
                lineText = lineText & vbCrLf & _
                           CashAlternativeSourceSummary(sourceSheet, sourceRow)
                CashAnalysisAlternativePanelText = CashAnalysisAlternativePanelText & _
                    vbCrLf & vbCrLf & lineText
            End If
        End If
    Next r
    If matchCount > MAX_VISIBLE_ALTERNATIVES Then _
        CashAnalysisAlternativePanelText = CashAnalysisAlternativePanelText & _
            vbCrLf & vbCrLf & "�ق� " & CStr(matchCount - MAX_VISIBLE_ALTERNATIVES) & _
            "���B�\������̏d�����m�F���A�����i�荞��ł��������B"
End Function

Private Function CashAlternativePersonClass(ByVal txIDList As String, _
                                            ByVal txPersonMap As Object) As String
    Dim wanted As Object, persons As Object, item As Variant, txID As String, personID As String
    Set wanted = IDsToDictionary(txIDList)
    Set persons = CreateObject("Scripting.Dictionary")
    persons.CompareMode = vbTextCompare
    If wanted.Count < 2 Or txPersonMap Is Nothing Then _
        Err.Raise vbObjectError + 4976, "CashAlternativePersonClass", _
                  "��֌��̍\��������m�F�ł��܂���B"
    For Each item In wanted.Keys
        txID = CStr(item)
        If Not txPersonMap.Exists(txID) Then _
            Err.Raise vbObjectError + 4977, "CashAlternativePersonClass", _
                      "��֌��̐l��ID��W_����Ŋm�F�ł��܂���: " & txID
        personID = CellText(txPersonMap(txID))
        If Len(personID) = 0 Then _
            Err.Raise vbObjectError + 4978, "CashAlternativePersonClass", _
                      "��֌��̐l��ID������܂���: " & txID
        persons(personID) = True
    Next item
    If persons.Count > 1 Then
        CashAlternativePersonClass = VIEW_PERSON_DIFFERENT
    Else
        CashAlternativePersonClass = VIEW_PERSON_SAME
    End If
End Function

Private Function CashAlternativeSourceSummary(ByVal sourceSheet As String, _
                                              ByVal sourceRow As Long) As String
    Dim ws As Worksheet, routeText As String, dateText As String, amountText As String
    If sourceSheet <> SH_ANALYSIS_SHIFT And sourceSheet <> SH_ANALYSIS_FLOW Then _
        Err.Raise vbObjectError + 4981, "CashAlternativeSourceSummary", _
                  "��֌��̓��������\�������ړ��ł͂���܂���B"
    If Not SheetExists(sourceSheet) Then _
        Err.Raise vbObjectError + 4979, "CashAlternativeSourceSummary", _
                  "��֌��̓��������\������܂���B"
    Set ws = GetSheet(sourceSheet)
    If sourceRow < 2 Or sourceRow > LastUsedRowInSheet(ws) Then _
        Err.Raise vbObjectError + 4980, "CashAlternativeSourceSummary", _
                  "��֌��̓��������s������܂���B"
    If sourceSheet = SH_ANALYSIS_SHIFT Then
        dateText = CashAlternativeDateText(ws.Cells(sourceRow, 9).Value) & " �� " & _
                   CashAlternativeDateText(ws.Cells(sourceRow, 19).Value)
        amountText = Format$(CashViewDouble(ws.Cells(sourceRow, 17).Value), "#,##0.########") & _
                     " �� " & Format$(CashViewDouble(ws.Cells(sourceRow, 27).Value), "#,##0.########")
        routeText = CellText(ws.Cells(sourceRow, 11).Value) & " / " & _
                    CellText(ws.Cells(sourceRow, 13).Value) & " " & _
                    CellText(ws.Cells(sourceRow, 14).Value) & " �� " & _
                    CellText(ws.Cells(sourceRow, 21).Value) & " / " & _
                    CellText(ws.Cells(sourceRow, 23).Value) & " " & _
                    CellText(ws.Cells(sourceRow, 24).Value)
    ElseIf sourceSheet = SH_ANALYSIS_FLOW Then
        dateText = CellText(ws.Cells(sourceRow, 6).Value)
        amountText = Format$(CashViewDouble(ws.Cells(sourceRow, 9).Value), "#,##0.########") & _
                     " �� " & Format$(CashViewDouble(ws.Cells(sourceRow, 10).Value), "#,##0.########")
        routeText = CellText(ws.Cells(sourceRow, 12).Value)
    End If
    CashAlternativeSourceSummary = _
        CashAnalysisNormalizeTimeEvidenceText(dateText & " / " & amountText & vbCrLf & routeText)
End Function

Private Function CashAlternativeDateText(ByVal valueIn As Variant) As String
    If IsDate(valueIn) Then
        CashAlternativeDateText = Format$(CDate(valueIn), "yyyy/m/d")
    Else
        CashAlternativeDateText = "���t�v�m�F"
    End If
End Function

Private Sub ShowCashAnalysisLongMessage(ByVal valueText As String, ByVal titleText As String)
    'MsgBox�̕\������Œ����������������Ȃ��悤�A���S�Ȓ����Ńy�[�W��������B
    Const MESSAGE_CHUNK As Long = 900
    Dim pageCount As Long, pageNumber As Long
    Dim pageTitle As String, startAt As Long
    If Len(valueText) = 0 Then valueText = "�i�\��������e�͂���܂���j"
    pageCount = (Len(valueText) + MESSAGE_CHUNK - 1) \ MESSAGE_CHUNK
    If pageCount < 1 Then pageCount = 1
    For pageNumber = 1 To pageCount
        startAt = (pageNumber - 1) * MESSAGE_CHUNK + 1
        pageTitle = titleText
        If pageCount > 1 Then _
            pageTitle = pageTitle & "�i" & CStr(pageNumber) & "/" & CStr(pageCount) & "�j"
        MsgBox Mid$(valueText, startAt, MESSAGE_CHUNK), vbInformation, pageTitle
    Next pageNumber
End Sub

Public Function CashAnalysisManualModeActive() As Boolean
    If Not SheetExists(SH_OUTPUT_TX) Then Exit Function
    CashAnalysisManualModeActive = _
        (CellText(GetSheet(SH_OUTPUT_TX).Range(VIEW_STATE_MANUAL).Value) = "1")
End Function

Public Function HasCashAnalysisManualSelection() As Boolean
    If Not CashAnalysisManualModeActive() Then Exit Function
    HasCashAnalysisManualSelection = _
        (IDsToDictionary(CellText(GetSheet(SH_OUTPUT_TX).Range(VIEW_STATE_SELECTED_IDS).Value)).Count > 0)
End Function

Public Sub ClearCashAnalysisManualSelection(Optional ByVal refreshView As Boolean = True)
    Dim ws As Worksheet
    Dim workbookWasSaved As Boolean
    Dim previousEvents As Boolean, eventsCaptured As Boolean
    Dim eventsRestoreAttempted As Boolean, eventsReadyForRecovery As Boolean
    Dim actionMutationStarted As Boolean, protectOK As Boolean
    Dim safeToRestoreEntry As Boolean
    Dim eventStateDetail As String, stopDetail As String
    Dim convergenceDetail As String
    Dim errorNumber As Long, errorSource As String, errorDescription As String
    On Error GoTo EH
    If Not SheetExists(SH_OUTPUT_TX) Then Exit Sub
    Set ws = GetSheet(SH_OUTPUT_TX)
    workbookWasSaved = ThisWorkbook.Saved
    If Not TryGetCashAnalysisEnableEvents(previousEvents, eventStateDetail) Then _
        Err.Raise vbObjectError + 5131, "ClearCashAnalysisManualSelection", _
                  "Excel�C�x���g�̊J�n��Ԃ��擾�ł��܂���ł����B " & eventStateDetail
    eventsCaptured = True
    If Not TrySetCashAnalysisEnableEventsExact(False, eventStateDetail) Then _
        Err.Raise vbObjectError + 5132, "ClearCashAnalysisManualSelection", _
                  "�蓮�I�������O��Excel�C�x���g���~�ł��܂���ł����B " & eventStateDetail
    actionMutationStarted = True
    ws.Unprotect Password:=TOOL_PASSWORD
    ws.Range(VIEW_STATE_MANUAL).Value = "0"
    ws.Range(VIEW_STATE_SELECTED_IDS).ClearContents
    If refreshView Then
        RefreshCashAnalysisPanel False
    Else
        ProtectCashAnalysisViewSheet
    End If
    If workbookWasSaved Then ThisWorkbook.Saved = True
    eventsRestoreAttempted = True
    If Not TryRestoreCashAnalysisEnableEvents( _
               previousEvents, "ClearCashAnalysisManualSelection", _
               eventStateDetail) Then _
        Err.Raise vbObjectError + 5133, _
                  "ClearCashAnalysisManualSelection", eventStateDetail
    eventsCaptured = False
    Exit Sub
EH:
    errorNumber = Err.Number
    errorSource = Err.Source
    errorDescription = Err.Description
    If IsCashAnalysisRecoveryFatal(errorNumber, errorSource) Then
        Call TryStopCashAnalysisEventsForRecovery(convergenceDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    If eventsCaptured Then
        If Not eventsRestoreAttempted Then _
            eventsReadyForRecovery = _
                TryStopCashAnalysisEventsForRecovery(stopDetail)
    End If
    If actionMutationStarted And Not eventsRestoreAttempted Then
        If eventsReadyForRecovery Then
            protectOK = TryProtectCashAnalysisViewAfterFailure( _
                            ws, "ClearCashAnalysisManualSelection", _
                            False, errorDescription)
            safeToRestoreEntry = _
                CashAnalysisOuterLeaseMayRestoreAfterProtection( _
                    protectOK, errorDescription)
        Else
            AppendCashAnalysisRollbackDetail errorDescription, _
                "Excel�C�x���g��~��ǖ߂��m�F�ł��Ȃ����߁A" & _
                "�u�b�N�̍ĕی��Recovery�����݂��s���܂���ł����B " & _
                stopDetail
        End If
    End If
    If eventsCaptured And Not eventsRestoreAttempted Then
        eventsRestoreAttempted = True
        If Not actionMutationStarted Or safeToRestoreEntry Then
            If Not TryRestoreCashAnalysisEnableEvents( _
                       previousEvents, _
                       "ClearCashAnalysisManualSelection/�G���[�I��", _
                       eventStateDetail) Then _
                AppendCashAnalysisRollbackDetail errorDescription, _
                    eventStateDetail
        ElseIf TryStopCashAnalysisEventsForRecovery(convergenceDetail) Then
            AppendCashAnalysisRollbackDetail errorDescription, _
                "�ĕی�܂���Recovery�������m�F�ł��Ȃ����߁A" & _
                "�J�n���C�x���g�l�֖߂���False�Œ�~���܂����B"
        Else
            AppendCashAnalysisRollbackDetail errorDescription, _
                "���S��Ԃ������m�F�ł����AExcel�C�x���g��False�����ɂ�" & _
                "���s���܂����B���ݏ�Ԃ͕s���ł�: " & convergenceDetail
        End If
    End If
    eventsCaptured = False
    Err.Raise errorNumber, "ClearCashAnalysisManualSelection", errorDescription
End Sub

Private Sub ToggleCashManualTransaction(ByVal ws As Worksheet, ByVal txID As String)
    Dim selected As Object
    Dim workbookWasSaved As Boolean
    Dim selectedText As String
    Dim previousEvents As Boolean, eventsCaptured As Boolean
    Dim eventsRestoreAttempted As Boolean, eventsReadyForRecovery As Boolean
    Dim actionMutationStarted As Boolean, protectOK As Boolean
    Dim safeToRestoreEntry As Boolean
    Dim eventStateDetail As String, stopDetail As String
    Dim convergenceDetail As String
    Dim errorNumber As Long, errorSource As String, errorDescription As String
    On Error GoTo EH
    workbookWasSaved = ThisWorkbook.Saved
    Set selected = IDsToDictionary(CellText(ws.Range(VIEW_STATE_SELECTED_IDS).Value))
    If selected.Exists(txID) Then
        selected.Remove txID
    Else
        selected(txID) = True
    End If
    selectedText = JoinCashDictionaryKeys(selected)
    If Len(selectedText) > VIEW_SELECTED_IDS_MAX Then
        MsgBox "��x�ɑI���ł����������̏���ɒB���܂����B" & vbCrLf & _
               "�蓮���𕡐��ɕ����ēo�^���Ă��������B", _
               vbInformation, "�蓮���̑I�����"
        Exit Sub
    End If
    If Not TryGetCashAnalysisEnableEvents(previousEvents, eventStateDetail) Then _
        Err.Raise vbObjectError + 5137, "ToggleCashManualTransaction", _
                  "Excel�C�x���g�̊J�n��Ԃ��擾�ł��܂���ł����B " & eventStateDetail
    eventsCaptured = True
    If Not TrySetCashAnalysisEnableEventsExact(False, eventStateDetail) Then _
        Err.Raise vbObjectError + 5138, "ToggleCashManualTransaction", _
                  "�蓮���I���X�V�O��Excel�C�x���g���~�ł��܂���ł����B " & eventStateDetail
    actionMutationStarted = True
    ws.Unprotect Password:=TOOL_PASSWORD
    ws.Range(VIEW_STATE_SELECTED_IDS).Value = selectedText
    RefreshCashAnalysisPanel False
    If workbookWasSaved Then ThisWorkbook.Saved = True
    eventsRestoreAttempted = True
    If Not TryRestoreCashAnalysisEnableEvents( _
               previousEvents, "ToggleCashManualTransaction", _
               eventStateDetail) Then _
        Err.Raise vbObjectError + 5139, _
                  "ToggleCashManualTransaction", eventStateDetail
    eventsCaptured = False
    Exit Sub
EH:
    errorNumber = Err.Number
    errorSource = Err.Source
    errorDescription = Err.Description
    If IsCashAnalysisRecoveryFatal(errorNumber, errorSource) Then
        Call TryStopCashAnalysisEventsForRecovery(convergenceDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    If eventsCaptured Then
        If Not eventsRestoreAttempted Then _
            eventsReadyForRecovery = _
                TryStopCashAnalysisEventsForRecovery(stopDetail)
    End If
    If actionMutationStarted And Not eventsRestoreAttempted Then
        If eventsReadyForRecovery Then
            protectOK = TryProtectCashAnalysisViewAfterFailure( _
                            ws, "ToggleCashManualTransaction", _
                            False, errorDescription)
            safeToRestoreEntry = _
                CashAnalysisOuterLeaseMayRestoreAfterProtection( _
                    protectOK, errorDescription)
        Else
            AppendCashAnalysisRollbackDetail errorDescription, _
                "Excel�C�x���g��~��ǖ߂��m�F�ł��Ȃ����߁A" & _
                "�u�b�N�̍ĕی��Recovery�����݂��s���܂���ł����B " & _
                stopDetail
        End If
    End If
    If eventsCaptured And Not eventsRestoreAttempted Then
        eventsRestoreAttempted = True
        If Not actionMutationStarted Or safeToRestoreEntry Then
            If Not TryRestoreCashAnalysisEnableEvents( _
                       previousEvents, _
                       "ToggleCashManualTransaction/�G���[�I��", _
                       eventStateDetail) Then _
                AppendCashAnalysisRollbackDetail errorDescription, _
                    eventStateDetail
        ElseIf TryStopCashAnalysisEventsForRecovery(convergenceDetail) Then
            AppendCashAnalysisRollbackDetail errorDescription, _
                "�ĕی�܂���Recovery�������m�F�ł��Ȃ����߁A" & _
                "�J�n���C�x���g�l�֖߂���False�Œ�~���܂����B"
        Else
            AppendCashAnalysisRollbackDetail errorDescription, _
                "���S��Ԃ������m�F�ł����AExcel�C�x���g��False�����ɂ�" & _
                "���s���܂����B���ݏ�Ԃ͕s���ł�: " & convergenceDetail
        End If
    End If
    eventsCaptured = False
    MsgBox "�蓮���̑I�����X�V�ł��܂���ł����B" & vbCrLf & _
           "Err " & CStr(errorNumber) & ": " & errorDescription, vbExclamation
End Sub

Private Sub FocusCashAnalysisCandidateByTransaction(ByVal ws As Worksheet, ByVal txID As String)
    Dim wsResult As Worksheet, lastR As Long, r As Long
    Dim categoryText As String, firstMatch As Long, preferredMatch As Long
    Dim categoryValues As Variant, txIDValues As Variant
    Dim workbookWasSaved As Boolean
    Dim previousEvents As Boolean, eventsCaptured As Boolean
    Dim eventsRestoreAttempted As Boolean, eventsReadyForRecovery As Boolean
    Dim actionMutationStarted As Boolean, protectOK As Boolean
    Dim safeToRestoreEntry As Boolean
    Dim eventStateDetail As String, stopDetail As String
    Dim convergenceDetail As String
    Dim errorNumber As Long, errorSource As String, errorDescription As String
    If Not SheetExists(SH_ANALYSIS_RESULT) Then Exit Sub
    On Error GoTo EH
    '���ݕ\�����̑�\�E��ւ̍\��������Ďw�肵�������Ȃ�A�\���ʒu��ς��Ȃ��B
    If CashAnalysisCurrentCandidateContainsTransaction(ws, txID) Then Exit Sub
    Set wsResult = GetSheet(SH_ANALYSIS_RESULT)
    categoryText = CellText(ws.Range(VIEW_STATE_CATEGORY).Value)
    lastR = LastUsedRowInSheet(wsResult)
    If lastR >= 2 Then
        categoryValues = CashResultColumnValues(wsResult, 2, lastR, 2)
        txIDValues = CashResultColumnValues(wsResult, 2, lastR, ANALYSIS_RESULT_TX_IDS_COL)
    End If
    For r = 1 To Application.Max(0, lastR - 1)
        If IDListContains(CellText(txIDValues(r, 1)), txID) Then
            If firstMatch = 0 Then firstMatch = r + 1
            If CashViewCategoryForResult(CellText(categoryValues(r, 1))) = categoryText Then
                preferredMatch = r + 1
                Exit For
            End If
        End If
    Next r
    If preferredMatch = 0 Then preferredMatch = firstMatch
    If preferredMatch = 0 Then
        MsgBox "���̎�����\������Ɋ܂ޕ��͌��͂���܂���B" & vbCrLf & _
               "�s�����o���̍Œ���z�ȂǁA���͏������m�F���Ă��������B", vbInformation
        Exit Sub
    End If
    workbookWasSaved = ThisWorkbook.Saved
    If Not TryGetCashAnalysisEnableEvents(previousEvents, eventStateDetail) Then _
        Err.Raise vbObjectError + 5140, _
                  "FocusCashAnalysisCandidateByTransaction", _
                  "Excel�C�x���g�̊J�n��Ԃ��擾�ł��܂���ł����B " & eventStateDetail
    eventsCaptured = True
    If Not TrySetCashAnalysisEnableEventsExact(False, eventStateDetail) Then _
        Err.Raise vbObjectError + 5141, _
                  "FocusCashAnalysisCandidateByTransaction", _
                  "���\���֑ؑO��Excel�C�x���g���~�ł��܂���ł����B " & eventStateDetail
    actionMutationStarted = True
    SyncCashAnalysisPanelReviewToWorkspace
    ws.Unprotect Password:=TOOL_PASSWORD
    ws.Range(VIEW_STATE_CATEGORY).Value = _
        CashViewCategoryForResult(CellText(wsResult.Cells(preferredMatch, 2).Value))
    ws.Range(VIEW_STATE_GROUP_ID).Value = _
        CellText(wsResult.Cells(preferredMatch, ANALYSIS_RESULT_GROUP_ID_COL).Value)
    ws.Range(VIEW_STATE_CANDIDATE_REF).ClearContents
    ws.Range(VIEW_STATE_MODE).Value = VIEW_MODE_COMPONENT
    ws.Range(VIEW_STATE_PANEL_EXPANDED).Value = "0"
    RefreshCashAnalysisPanel True
    If workbookWasSaved Then ThisWorkbook.Saved = True
    eventsRestoreAttempted = True
    If Not TryRestoreCashAnalysisEnableEvents( _
               previousEvents, _
               "FocusCashAnalysisCandidateByTransaction", _
               eventStateDetail) Then _
        Err.Raise vbObjectError + 5142, _
                  "FocusCashAnalysisCandidateByTransaction", _
                  eventStateDetail
    eventsCaptured = False
    Exit Sub
EH:
    errorNumber = Err.Number
    errorSource = Err.Source
    errorDescription = Err.Description
    If IsCashAnalysisRecoveryFatal(errorNumber, errorSource) Then
        Call TryStopCashAnalysisEventsForRecovery(convergenceDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    If eventsCaptured Then
        If Not eventsRestoreAttempted Then _
            eventsReadyForRecovery = _
                TryStopCashAnalysisEventsForRecovery(stopDetail)
    End If
    If actionMutationStarted And Not eventsRestoreAttempted Then
        If eventsReadyForRecovery Then
            protectOK = TryProtectCashAnalysisViewAfterFailure( _
                            ws, "FocusCashAnalysisCandidateByTransaction", _
                            False, errorDescription)
            safeToRestoreEntry = _
                CashAnalysisOuterLeaseMayRestoreAfterProtection( _
                    protectOK, errorDescription)
        Else
            AppendCashAnalysisRollbackDetail errorDescription, _
                "Excel�C�x���g��~��ǖ߂��m�F�ł��Ȃ����߁A" & _
                "�u�b�N�̍ĕی��Recovery�����݂��s���܂���ł����B " & _
                stopDetail
        End If
    End If
    If eventsCaptured And Not eventsRestoreAttempted Then
        eventsRestoreAttempted = True
        If Not actionMutationStarted Or safeToRestoreEntry Then
            If Not TryRestoreCashAnalysisEnableEvents( _
                       previousEvents, _
                       "FocusCashAnalysisCandidateByTransaction/�G���[�I��", _
                       eventStateDetail) Then _
                AppendCashAnalysisRollbackDetail errorDescription, _
                    eventStateDetail
        ElseIf TryStopCashAnalysisEventsForRecovery(convergenceDetail) Then
            AppendCashAnalysisRollbackDetail errorDescription, _
                "�ĕی�܂���Recovery�������m�F�ł��Ȃ����߁A" & _
                "�J�n���C�x���g�l�֖߂���False�Œ�~���܂����B"
        Else
            AppendCashAnalysisRollbackDetail errorDescription, _
                "���S��Ԃ������m�F�ł����AExcel�C�x���g��False�����ɂ�" & _
                "���s���܂����B���ݏ�Ԃ͕s���ł�: " & convergenceDetail
        End If
    End If
    eventsCaptured = False
    MsgBox "����ɑΉ����镪�͌���\���ł��܂���ł����B" & vbCrLf & _
           "Err " & CStr(errorNumber) & ": " & errorDescription, vbExclamation
End Sub

Private Function CashAnalysisCurrentCandidateContainsTransaction( _
        ByVal ws As Worksheet, ByVal txID As String) As Boolean
    Dim wsResult As Worksheet, wsGroup As Worksheet
    Dim resultRow As Long, groupRow As Long, txIDList As String
    Dim groupID As String, candidateRef As String
    If ws Is Nothing Or Len(txID) = 0 Or Not SheetExists(SH_ANALYSIS_RESULT) Then Exit Function
    Set wsResult = GetSheet(SH_ANALYSIS_RESULT)
    resultRow = CLng(Val(CellText(ws.Range(VIEW_STATE_RESULT_ROW).Value)))
    groupID = CellText(ws.Range(VIEW_STATE_GROUP_ID).Value)
    If resultRow < 2 Or resultRow > LastUsedRowInSheet(wsResult) Or Len(groupID) = 0 Then Exit Function
    If StrComp(CellText(wsResult.Cells(resultRow, ANALYSIS_RESULT_GROUP_ID_COL).Value), _
               groupID, vbTextCompare) <> 0 Then Exit Function
    candidateRef = CellText(ws.Range(VIEW_STATE_CANDIDATE_REF).Value)
    If Len(candidateRef) > 0 Then
        If Not SheetExists(SH_WORK_ANALYSIS_GROUP) Then Exit Function
        Set wsGroup = GetSheet(SH_WORK_ANALYSIS_GROUP)
        groupRow = FindCashAnalysisAlternativeRow(wsGroup, groupID, candidateRef)
        If groupRow = 0 Then Exit Function
        txIDList = CellText(wsGroup.Cells(groupRow, 5).Value)
    Else
        txIDList = CellText(wsResult.Cells(resultRow, ANALYSIS_RESULT_TX_IDS_COL).Value)
    End If
    CashAnalysisCurrentCandidateContainsTransaction = IDListContains(txIDList, txID)
End Function

Private Sub RegisterCashAnalysisManualSelection()
    Dim ws As Worksheet, idList As String, restoreDetail As String
    Dim outputCapacityConfirmed As Boolean
    Dim entryEvents As Boolean, eventsCaptured As Boolean, eventsReady As Boolean
    Dim eventsRestoreAttempted As Boolean
    Dim eventDetail As String
    Dim errorNumber As Long, errorSource As String, errorDescription As String
    If Not SheetExists(SH_OUTPUT_TX) Then Exit Sub
    On Error GoTo EH
    Set ws = GetSheet(SH_OUTPUT_TX)
    idList = CellText(ws.Range(VIEW_STATE_SELECTED_IDS).Value)
    If IDsToDictionary(idList).Count < 2 Then
        MsgBox "�����2���ȏ�I�����Ă��������B�o���Ɠ��������ꂼ��܂߂�K�v������܂��B", vbInformation
        Exit Sub
    End If
    If Not TryGetCashAnalysisEnableEvents(entryEvents, eventDetail) Then _
        Err.Raise vbObjectError + 5109, "RegisterCashAnalysisManualSelection", _
                  "Excel�C�x���g�̊J�n��Ԃ��擾�ł��܂���ł����B " & eventDetail
    eventsCaptured = True
    eventsReady = TryStopCashAnalysisEventsForRecovery(eventDetail)
    If Not eventsReady Then _
        Err.Raise vbObjectError + 5110, "RegisterCashAnalysisManualSelection", _
                  "�蓮���o�^�O��Excel�C�x���g��~���m�F�ł��܂���ł����B " & eventDetail
    ws.Unprotect Password:=TOOL_PASSWORD
    ws.Range(VIEW_STATE_MANUAL).Value = "0"
    If RegisterManualAnalysisCandidateByIDs(idList, outputCapacityConfirmed) Then
        eventsReady = TryStopCashAnalysisEventsForRecovery(eventDetail)
        If Not eventsReady Then _
            Err.Raise vbObjectError + 5111, "RegisterCashAnalysisManualSelection", _
                      "�蓮���o�^���Excel�C�x���g��~���m�F�ł��܂���ł����B " & eventDetail
        If SheetExists(SH_OUTPUT_TX) Then
            Set ws = GetSheet(SH_OUTPUT_TX)
            ws.Unprotect Password:=TOOL_PASSWORD
            ws.Range(VIEW_STATE_CATEGORY).Value = VIEW_CATEGORY_TRANSFER
            ws.Range(VIEW_STATE_MODE).Value = VIEW_MODE_COMPONENT
            ws.Range(VIEW_STATE_SELECTED_IDS).ClearContents
            RefreshCashAnalysisPanel True
        End If
    Else
        '���͍č\�z���r���[Reset��Ɏ��s���Ă���\��������B�����r���[�֒P��Refresh����ƁA
        '���݂��Ȃ��s�Ƃ��đI��ID����֎��������邽�߁A���������\�����蒼���Č����ƍ�����B
        eventsReady = TryStopCashAnalysisEventsForRecovery(eventDetail)
        If Not eventsReady Then _
            Err.Raise vbObjectError + 5112, "RegisterCashAnalysisManualSelection", _
                      "�蓮���̎��s�����O��Excel�C�x���g��~���m�F�ł��܂���ł����B " & eventDetail
        If Not RestoreCashManualSelectionAfterFailure( _
                   idList, outputCapacityConfirmed, restoreDetail) Then _
            StopAfterCashManualSelectionRestoreFailure restoreDetail
    End If
    If eventsCaptured Then
        eventsRestoreAttempted = True
        If Not TryRestoreCashAnalysisEnableEvents( _
                   entryEvents, "RegisterCashAnalysisManualSelection", _
                   eventDetail) Then _
            Err.Raise vbObjectError + 5113, _
                      "RegisterCashAnalysisManualSelection", eventDetail
        eventsCaptured = False
    End If
    Exit Sub
EH:
    errorNumber = Err.Number
    errorSource = Err.Source
    errorDescription = Err.Description
    If IsCashAnalysisRecoveryFatal(errorNumber, errorSource) Then
        Call TryStopCashAnalysisEventsForRecovery(eventDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    If eventsCaptured And Not eventsRestoreAttempted Then
        If Not TryRestoreCashAnalysisEnableEvents( _
                   entryEvents, "RegisterCashAnalysisManualSelection/�G���[�I��", _
                   eventDetail) Then _
            AppendCashAnalysisRollbackDetail errorDescription, eventDetail
    End If
    Err.Raise errorNumber, "RegisterCashAnalysisManualSelection", errorDescription
End Sub

Private Function RestoreCashManualSelectionAfterFailure( _
        ByVal idList As String, ByVal outputCapacityConfirmed As Boolean, _
        ByRef detailText As String) As Boolean
    Dim ws As Worksheet
    Dim expected As Object, actual As Object, found As Object
    Dim lastR As Long, r As Long
    Dim rowData As Variant, txID As String
    Dim item As Variant
    Dim workbookWasSaved As Boolean
    Dim entryEvents As Boolean, eventsCaptured As Boolean, eventsReady As Boolean
    Dim restoreSucceeded As Boolean, mutationStarted As Boolean
    Dim protectOK As Boolean, safeToRestoreEntry As Boolean
    Dim eventDetail As String, convergenceDetail As String
    Dim errorNumber As Long, errorSource As String, errorDescription As String

    On Error GoTo EH
    detailText = vbNullString
    Set expected = IDsToDictionary(idList)
    If expected.Count < 2 Then
        detailText = "�ޔ������蓮���̑I��ID��2�������ł��B"
        Exit Function
    End If
    If Not SheetExists(SH_OUTPUT_TX) Or Not SheetExists(SH_WORK_CASH) Then
        detailText = "��������\�܂��͓��������\������܂���B"
        Exit Function
    End If
    If Not TryGetCashAnalysisEnableEvents(entryEvents, eventDetail) Then
        detailText = "Excel�C�x���g�̊J�n��Ԃ��擾�ł��܂���ł����B " & eventDetail
        Exit Function
    End If
    eventsCaptured = True
    eventsReady = TryStopCashAnalysisEventsForRecovery(eventDetail)
    If Not eventsReady Then
        detailText = "Excel�C�x���g��~���m�F�ł����A�I����e���ď����݂��܂���ł����B " & eventDetail
        GoTo CleanExit
    End If

    If Not CashManualFailureRecoveryMayRebuild(outputCapacityConfirmed) Then
        '�e�ʊm�F�O�̎��s�ł́A�X�V��̒ǉ�prompt���K��Reset���s��Ȃ��B
        '���ɕύX�����\����Ԃ�����߂��A���[�͗v�X�V�̂܂܈��S���֌Œ肷��B
        mutationStarted = True
        Set ws = GetSheet(SH_OUTPUT_TX)
        MarkOutputsDirty
        ws.Unprotect Password:=TOOL_PASSWORD
        ws.Range(VIEW_STATE_MANUAL).Value = "1"
        ws.Range(VIEW_STATE_SELECTED_IDS).Value = JoinCashDictionaryKeys(expected)
        Set actual = IDsToDictionary(CellText(ws.Range(VIEW_STATE_SELECTED_IDS).Value))
        If CellText(ws.Range(VIEW_STATE_MANUAL).Value) <> "1" Or _
           actual.Count <> expected.Count Then
            detailText = "�e�ʖ��m�F���̍ŏ��I�𕜌����ƍ��ł��܂���B"
            GoTo RestoreFailed
        End If
        For Each item In expected.Keys
            If Not actual.Exists(CStr(item)) Then
                detailText = "�e�ʖ��m�F���̑I�����ID�𕜌��ł��܂���: " & CStr(item)
                GoTo RestoreFailed
            End If
        Next item
        ProtectCashAnalysisViewSheet
        restoreSucceeded = True
        GoTo CleanExit
    End If

    workbookWasSaved = ThisWorkbook.Saved
    '��ꂩ�����\���\�̍s��M�p�����A���������\��B��̕������ɂ���B
    mutationStarted = True
    BuildCashAnalysisViewCore False, False, outputCapacityConfirmed
    eventsReady = TryStopCashAnalysisEventsForRecovery(eventDetail)
    If Not eventsReady Then
        detailText = "�\���č\�z���Excel�C�x���g��~���m�F�ł����A�I����e���ď����݂��܂���ł����B " & eventDetail
        GoTo CleanExit
    End If
    Set ws = GetSheet(SH_OUTPUT_TX)
    ws.Unprotect Password:=TOOL_PASSWORD
    ws.Range(VIEW_STATE_MANUAL).Value = "1"
    ws.Range(VIEW_STATE_SELECTED_IDS).Value = JoinCashDictionaryKeys(expected)
    RefreshCashAnalysisPanel False

    Set actual = IDsToDictionary(CellText(ws.Range(VIEW_STATE_SELECTED_IDS).Value))
    If CellText(ws.Range(VIEW_STATE_MANUAL).Value) <> "1" Then
        detailText = "�蓮���̑I�����[�h�𕜌��ł��܂���B"
        GoTo RestoreFailed
    End If
    If actual.Count <> expected.Count Then
        detailText = "������̑I������������ޔ�l�ƈ�v���܂���B"
        GoTo RestoreFailed
    End If
    For Each item In expected.Keys
        If Not actual.Exists(CStr(item)) Then
            detailText = "������̑I�����ID���ޔ�l�ƈ�v���܂���: " & CStr(item)
            GoTo RestoreFailed
        End If
    Next item

    '��\����ԃZ�������łȂ��A�č\�z������������\�̎���s�ɂ��SID�����݂��邱�Ƃ��m�F����B
    Set found = CreateObject("Scripting.Dictionary")
    found.CompareMode = vbTextCompare
    lastR = CashAnalysisLastDataRow(ws)
    If lastR >= CASH_VIEW_FIRST_DATA_ROW Then
        rowData = ws.Range(ws.Cells(CASH_VIEW_FIRST_DATA_ROW, OUT_COL_TRANSACTION_ID), _
                           ws.Cells(lastR, OUT_COL_RECORD_TYPE)).Value2
        For r = 1 To UBound(rowData, 1)
            If StrComp(CellText(rowData(r, 2)), RECORD_TRANSACTION, vbTextCompare) = 0 Then
                txID = CellText(rowData(r, 1))
                If Len(txID) > 0 Then found(txID) = True
            End If
        Next r
    End If
    For Each item In expected.Keys
        If Not found.Exists(CStr(item)) Then
            detailText = "���������\����I��������ē���ł��܂���: " & CStr(item)
            GoTo RestoreFailed
        End If
    Next item

    eventsReady = TryStopCashAnalysisEventsForRecovery(eventDetail)
    If Not eventsReady Then
        detailText = "�������Excel�C�x���g��~���m�F�ł����A�ۑ���Ԃ��ď����݂��܂���ł����B " & eventDetail
        GoTo CleanExit
    End If
    If workbookWasSaved Then ThisWorkbook.Saved = True
    restoreSucceeded = True
    GoTo CleanExit

RestoreFailed:
    eventsReady = TryStopCashAnalysisEventsForRecovery(eventDetail)
    If Not eventsReady Then _
        AppendCashAnalysisRollbackDetail detailText, _
            "�ĕی�O��Excel�C�x���g��~���m�F�ł��܂���ł����B " & eventDetail
    If eventsReady Then
        protectOK = TryProtectCashAnalysisViewAfterFailure( _
                        ws, "RestoreCashManualSelectionAfterFailure", _
                        False, detailText)
        safeToRestoreEntry = _
            CashAnalysisOuterLeaseMayRestoreAfterProtection( _
                protectOK, detailText)
    End If
    GoTo CleanExit
EH:
    errorNumber = Err.Number
    errorSource = Err.Source
    errorDescription = Err.Description
    If IsCashAnalysisRecoveryFatal(errorNumber, errorSource) Then
        Call TryStopCashAnalysisEventsForRecovery(convergenceDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    detailText = "Err " & CStr(errorNumber) & ": " & errorDescription
    If eventsCaptured Then _
        eventsReady = TryStopCashAnalysisEventsForRecovery(eventDetail)
    If eventsReady Then
        Resume RestoreFailed
    Else
        AppendCashAnalysisRollbackDetail detailText, _
            "Excel�C�x���g��~���m�F�̂��߁A�ĕی���s���܂���ł����B " & eventDetail
        Resume CleanExit
    End If
CleanExit:
    If eventsCaptured Then
        If Not mutationStarted Or restoreSucceeded Then
            eventsReady = TryStopCashAnalysisEventsForRecovery(eventDetail)
            safeToRestoreEntry = eventsReady
        End If
        If safeToRestoreEntry Then
            If Not TryRestoreCashAnalysisEnableEvents( _
                       entryEvents, "RestoreCashManualSelectionAfterFailure", _
                       eventDetail) Then
                restoreSucceeded = False
                AppendCashAnalysisRollbackDetail detailText, eventDetail
            End If
        ElseIf TryStopCashAnalysisEventsForRecovery(convergenceDetail) Then
            restoreSucceeded = False
            AppendCashAnalysisRollbackDetail detailText, _
                "�I�𕜌��E�ĕی�܂���Recovery�������m�F�ł��Ȃ����߁A" & _
                "�J�n���C�x���g�l�֖߂���False�Œ�~���܂����B"
        Else
            restoreSucceeded = False
            AppendCashAnalysisRollbackDetail detailText, _
                "���S��Ԃ������m�F�ł����AExcel�C�x���g��False�����ɂ�" & _
                "���s���܂����B���ݏ�Ԃ͕s���ł�: " & convergenceDetail
        End If
    End If
    RestoreCashManualSelectionAfterFailure = restoreSucceeded
End Function

Private Function CashManualFailureRecoveryMayRebuild( _
        ByVal outputCapacityConfirmed As Boolean) As Boolean
    CashManualFailureRecoveryMayRebuild = outputCapacityConfirmed
End Function

Private Sub StopAfterCashManualSelectionRestoreFailure(ByVal restoreDetail As String)
    Dim detailText As String
    Dim stateErrorNumber As Long, stateErrorDescription As String
    Dim entryEvents As Boolean, eventsCaptured As Boolean, eventsReady As Boolean
    Dim recoveryConfirmed As Boolean, recoveryAttempted As Boolean
    Dim applicationStateConfirmed As Boolean
    Dim recoveryErrorNumber As Long, recoveryErrorDescription As String
    Dim eventDetail As String, preEnforceStopDetail As String
    Dim postEnforceStopDetail As String, finalStopDetail As String

    detailText = "��������\�̎蓮���I���𕜌��E�ƍ��ł��܂���B"
    If Len(restoreDetail) > 0 Then detailText = detailText & " / " & restoreDetail
    If Not TryGetCashAnalysisEnableEvents(entryEvents, eventDetail) Then
        AppendCashAnalysisRollbackDetail detailText, _
            "Excel�C�x���g�̊J�n��Ԃ��擾�ł����A�����E�`�F�b�N�E��ԏ����݂��s���܂���ł����B " & eventDetail
        GoTo ShowFailure
    End If
    eventsCaptured = True
    eventsReady = TryStopCashAnalysisEventsForRecovery(eventDetail)
    If Not eventsReady Then
        AppendCashAnalysisRollbackDetail detailText, _
            "Excel�C�x���g��~���m�F�ł����A�����E�`�F�b�N�E��ԏ����݂��s���܂���ł����B " & eventDetail
        GoTo RestoreEvents
    End If
    recoveryAttempted = True
    On Error Resume Next
    Err.Clear
    MarkOutputsDirty
    stateErrorNumber = Err.Number
    stateErrorDescription = Err.Description
    Err.Clear
    On Error GoTo 0
    If stateErrorNumber <> 0 Then _
        detailText = detailText & " / ���[�v�X�V��Ԃ̋L�^�G���[: Err " & _
                     CStr(stateErrorNumber) & " " & stateErrorDescription
    eventsReady = TryStopCashAnalysisEventsForRecovery(preEnforceStopDetail)
    If Not eventsReady Then
        AppendCashAnalysisRollbackDetail detailText, _
            "Recovery�����ݒ蒼�O��Excel�C�x���g��~���m�F�ł����A" & _
            "�Ȍ�̕����E�`�F�b�N�E��ԏ����݂��s���܂���ł����B" & _
            "���ݏ�Ԃ͕s���ł�: " & preEnforceStopDetail
        GoTo RestoreEvents
    End If
    On Error Resume Next
    Err.Clear
    EnforceRollbackRecoveryState detailText
    recoveryErrorNumber = Err.Number
    recoveryErrorDescription = Err.Description
    Err.Clear
    On Error GoTo 0
    eventsReady = TryStopCashAnalysisEventsForRecovery(postEnforceStopDetail)
    If recoveryErrorNumber <> 0 Then
        AppendCashAnalysisRollbackDetail detailText, _
            "�v������Ԃ̋����ݒ�G���[: Err " & _
            CStr(recoveryErrorNumber) & " " & recoveryErrorDescription
        AppendCashAnalysisRollbackDetail detailText, _
            "Recovery�����ݒ�ŃG���[�����o�������߁A" & _
            "������Ԃ̏ƍ��E�`�F�b�N�E��ԏ����݂��s���܂���ł����B"
        If Not eventsReady Then _
            AppendCashAnalysisRollbackDetail detailText, _
                "Recovery�����ݒ���Excel�C�x���g��~���m�F�ł����A" & _
                "���ݏ�Ԃ͕s���ł�: " & postEnforceStopDetail
        GoTo TerminalFailure
    End If
    If Not eventsReady Then
        AppendCashAnalysisRollbackDetail detailText, _
            "Recovery�����ݒ���Excel�C�x���g��~���m�F�ł����A" & _
            "������Ԃ̏ƍ��E�`�F�b�N�E��ԏ����݂��s���܂���ł����B" & _
            "���ݏ�Ԃ͕s���ł�: " & postEnforceStopDetail
        GoTo TerminalFailure
    End If
    recoveryConfirmed = _
        CashAnalysisRecoveryStateIsConfirmedExact(detailText)
    If Not recoveryConfirmed Then
        AppendCashAnalysisRollbackDetail detailText, _
            "�v������Ԃ������m�F�ł��܂���B"
        eventsReady = TryStopCashAnalysisEventsForRecovery(finalStopDetail)
        GoTo TerminalFailure
    End If
    applicationStateConfirmed = _
        CashAnalysisApplicationStateAllowsEntryRestore( _
            True, detailText)
    If Not applicationStateConfirmed Then
        eventsReady = _
            TryStopCashAnalysisEventsForRecovery(finalStopDetail)
        AppendCashAnalysisRollbackDetail detailText, _
            "Application��Ԃ��m�F�ł��܂���B"
        GoTo TerminalFailure
    End If
    eventsReady = TryStopCashAnalysisEventsForRecovery(finalStopDetail)
    If Not eventsReady Then
        AppendCashAnalysisRollbackDetail detailText, _
            "Application��Ԋm�F���Excel�C�x���gFalse������" & _
            "�m�F�ł��܂���B���ݏ�Ԃ͕s���ł�: " & finalStopDetail
    End If
    GoTo TerminalFailure
RestoreEvents:
    If eventsCaptured Then
        eventsReady = TryStopCashAnalysisEventsForRecovery(eventDetail)
        If eventsReady Then
            AppendCashAnalysisRollbackDetail detailText, _
                "�蓮���̎��s�����������ł��Ȃ����߁A�J�n���C�x���g�l��" & _
                "�߂���Excel�C�x���g��False�Œ�~���܂����B"
        Else
            AppendCashAnalysisRollbackDetail detailText, _
                "���S��Ԃ������m�F�ł����AExcel�C�x���g��False��" & _
                "���������邱�Ƃ��ł��܂���ł����B���ݏ�Ԃ͕s���ł�: " & _
                eventDetail
        End If
    End If
ShowFailure:
    eventsReady = TryStopCashAnalysisEventsForRecovery(finalStopDetail)
    If Not eventsReady Then _
        AppendCashAnalysisRollbackDetail detailText, _
            "�ŏI�I��Excel�C�x���gFalse�������m�F�ł��܂���ł���: " & _
            finalStopDetail
    If Not recoveryAttempted Then
        If recoveryConfirmed Then
            eventDetail = "�Č���v�����Ƃ��Ē�~���܂����B"
        Else
            eventDetail = "�v������Ԃ̐ݒ茋�ʂ͊m�F�ł��܂���B"
        End If
        MsgBox "�蓮���̓o�^�Ɏ��s���A�I�����Ă�����������S�ɕ����ł��܂���ł����B" & vbCrLf & _
               eventDetail & "���݂̃u�b�N���㏑�����Ȃ��ł��������B" & vbCrLf & _
               detailText, vbCritical, "�蓮���̑I�𕜌��Ɏ��s���܂���"
    End If
TerminalFailure:
    eventsReady = TryStopCashAnalysisEventsForRecovery(finalStopDetail)
    Err.Raise vbObjectError + 5196, _
              "CashManualSelectionRecoveryFatal/StopAfterCashManualSelectionRestoreFailure", _
              detailText
End Sub

Public Sub OnCashAnalysisViewChange(ByVal Target As Range)
    Dim ws As Worksheet
    Dim previousEvents As Boolean, eventsCaptured As Boolean
    Dim eventsRestoreAttempted As Boolean
    Dim eventsReadyForRecovery As Boolean, viewRestoreConfirmed As Boolean
    Dim protectOK As Boolean, recoveryConfirmed As Boolean
    Dim applicationStateConfirmed As Boolean
    Dim safeToRestoreEntry As Boolean
    Dim refreshError As Long, recoveryErrorNumber As Long
    Dim refreshErrorSource As String, refreshErrorDescription As String
    Dim recoveryErrorDescription As String
    Dim protectionRecoveryAttempted As Boolean
    Dim protectionRecoveryFailed As Boolean
    Dim protectionRecoveryConfirmed As Boolean
    Dim recoveryDetail As String, eventStateDetail As String, stopDetail As String
    Dim postRefreshStopDetail As String, postProtectStopDetail As String
    Dim postEnforceStopDetail As String, convergenceDetail As String
    Dim finalRecoveryStopDetail As String
    Dim userMessage As String
    Dim errorNumber As Long, errorSource As String, errorDescription As String
    If Target Is Nothing Then Exit Sub
    On Error GoTo EH
    '��O���̉�ʕ�����Worksheet_Change�֍ē����Ȃ��悤�A
    '�V�[�g�擾������������ɃC�x���g��Ԃ�ޔ����Ē�~����B
    If Not TryGetCashAnalysisEnableEvents(previousEvents, eventStateDetail) Then
        StopAfterCashAnalysisEventStateFailure _
            "OnCashAnalysisViewChange/�J�n��Ԏ擾", eventStateDetail, _
            eventsReadyForRecovery, False, vbNullString
        Err.Raise vbObjectError + 5095, "OnCashAnalysisViewChange", _
                  "Excel�C�x���g�̊J�n��Ԃ��擾�ł��܂���ł����B " & eventStateDetail
    End If
    eventsCaptured = True
    If Not TrySetCashAnalysisEnableEventsExact(False, eventStateDetail) Then _
        Err.Raise vbObjectError + 5096, "OnCashAnalysisViewChange", _
                  "���͔��f�̌��ؑO��Excel�C�x���g���~�ł��܂���ł����B " & _
                  eventStateDetail
    If Not SheetExists(SH_OUTPUT_TX) Then GoTo SafeExit
    Set ws = GetSheet(SH_OUTPUT_TX)
    If Intersect(Target, ws.Range("C3")) Is Nothing And _
       Intersect(Target, ws.Range("C8")) Is Nothing Then GoTo SafeExit
    If CellText(ws.Range(VIEW_STATE_MANUAL).Value) = "1" Then GoTo SafeExit
    If Len(CellText(ws.Range(VIEW_STATE_GROUP_ID).Value)) = 0 Then GoTo SafeExit
    ws.Unprotect Password:=TOOL_PASSWORD
    ValidateCashAnalysisPanelReview ws
    MarkAnalysisReviewsDirty
    UpdateCashAnalysisStatusStyle ws
    AdjustCashAnalysisPanelRowHeights ws
    ProtectCashAnalysisViewSheet
SafeExit:
    If eventsCaptured Then
        eventsRestoreAttempted = True
        If Not TryRestoreCashAnalysisEnableEvents( _
                   previousEvents, "OnCashAnalysisViewChange", eventStateDetail) Then _
            Err.Raise vbObjectError + 5097, _
                      "OnCashAnalysisViewChange", eventStateDetail
        eventsCaptured = False
    End If
    Exit Sub
EH:
    errorNumber = Err.Number
    errorSource = Err.Source
    errorDescription = Err.Description
    If IsCashAnalysisRecoveryFatal(errorNumber, errorSource) Then
        Call TryStopCashAnalysisEventsForRecovery(convergenceDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    If eventsCaptured Then _
        eventsReadyForRecovery = _
            TryStopCashAnalysisEventsForRecovery(stopDetail)
    If Not eventsReadyForRecovery Then
        If eventsCaptured Then
            AppendCashAnalysisRollbackDetail recoveryDetail, _
                "��ʕ����O��Excel�C�x���g���~���ēǖ߂��m�F�ł��܂���ł���: " & _
                stopDetail
        ElseIf Len(stopDetail) > 0 Then
            AppendCashAnalysisRollbackDetail recoveryDetail, _
                "Excel�C�x���g�̊J�n��Ԃ��擾�ł����A" & _
                "��~�̓ǖ߂��m�F�ɂ����s�������ߌ��ݏ�Ԃ͕s���ł�: " & _
                stopDetail
        Else
            AppendCashAnalysisRollbackDetail recoveryDetail, _
                "Excel�C�x���g�̊J�n��Ԃƌ��ݏ�Ԃ��m�F�ł��܂���ł����B"
        End If
    End If
    On Error Resume Next
    Err.Clear
    If eventsReadyForRecovery And eventsCaptured Then
        RefreshCashAnalysisPanel False
        refreshError = Err.Number
        refreshErrorSource = Err.Source
        refreshErrorDescription = Err.Description
        viewRestoreConfirmed = (refreshError = 0)
        If refreshError <> 0 Then _
            AppendCashAnalysisRollbackDetail recoveryDetail, _
                "���̓p�l���̕����G���[: " & refreshErrorDescription
    ElseIf Not eventsReadyForRecovery Then
        refreshError = vbObjectError + 5098
        AppendCashAnalysisRollbackDetail recoveryDetail, _
            "Excel�C�x���g��~���m�F�ł��Ȃ����ߕ��̓p�l���̍ď����݂��s���܂���ł����B"
    Else
        refreshError = vbObjectError + 5098
        AppendCashAnalysisRollbackDetail recoveryDetail, _
            "Excel�C�x���g�̊J�n��Ԃ����擾�̂��߁A" & _
            "���̓p�l���̍ď����݂��s���܂���ł����B"
    End If
    On Error GoTo 0
    If IsCashAnalysisRecoveryFatal( _
           refreshError, refreshErrorSource) Then
        Call TryStopCashAnalysisEventsForRecovery(convergenceDetail)
        Err.Raise refreshError, refreshErrorSource, refreshErrorDescription
    End If
    If eventsReadyForRecovery Then
        eventsReadyForRecovery = _
            TryStopCashAnalysisEventsForRecovery(postRefreshStopDetail)
        If Not eventsReadyForRecovery Then _
            AppendCashAnalysisRollbackDetail recoveryDetail, _
                "���̓p�l���������Excel�C�x���g��~���m�F�ł��܂���B" & _
                "���ݏ�Ԃ͕s���ł�: " & postRefreshStopDetail
    End If
    If eventsReadyForRecovery Then
        protectOK = TryProtectCashAnalysisViewAfterFailure( _
                        ws, "OnCashAnalysisViewChange", False, recoveryDetail, _
                        protectionRecoveryAttempted, _
                        protectionRecoveryFailed, _
                        protectionRecoveryConfirmed)
        eventsReadyForRecovery = _
            TryStopCashAnalysisEventsForRecovery(postProtectStopDetail)
        If Not eventsReadyForRecovery Then
            AppendCashAnalysisRollbackDetail recoveryDetail, _
                "�ĕی쏈�����Excel�C�x���g��~���m�F�ł��܂���B" & _
                "���ݏ�Ԃ͕s���ł�: " & postProtectStopDetail
        ElseIf protectionRecoveryAttempted Then
            recoveryConfirmed = protectionRecoveryConfirmed
        End If
    End If
    If protectionRecoveryFailed Then
        eventsReadyForRecovery = _
            TryStopCashAnalysisEventsForRecovery(convergenceDetail)
        eventsCaptured = False
        Err.Raise vbObjectError + 5194, _
                  "CashAnalysisRecoveryFatal/OnCashAnalysisViewChange", _
                  errorDescription & " / " & recoveryDetail
    End If
    If eventsReadyForRecovery And refreshError <> 0 And _
       Not protectionRecoveryAttempted Then
        On Error Resume Next
        Err.Clear
        EnforceRollbackRecoveryState recoveryDetail
        recoveryErrorNumber = Err.Number
        recoveryErrorDescription = Err.Description
        Err.Clear
        On Error GoTo 0
        eventsReadyForRecovery = _
            TryStopCashAnalysisEventsForRecovery(postEnforceStopDetail)
        If recoveryErrorNumber <> 0 Then
            AppendCashAnalysisRollbackDetail recoveryDetail, _
                "�v������Ԃ̋����ݒ�G���[: Err " & _
                CStr(recoveryErrorNumber) & " " & recoveryErrorDescription
            eventsCaptured = False
            Err.Raise vbObjectError + 5194, _
                      "CashAnalysisRecoveryFatal/OnCashAnalysisViewChange", _
                      errorDescription & " / " & recoveryDetail
        ElseIf eventsReadyForRecovery Then
            recoveryConfirmed = _
                CashAnalysisRecoveryStateIsConfirmedExact(recoveryDetail)
            If recoveryConfirmed Then _
                applicationStateConfirmed = _
                    CashAnalysisApplicationStateAllowsEntryRestore( _
                        True, recoveryDetail)
            If applicationStateConfirmed Then _
                eventsReadyForRecovery = _
                    TryStopCashAnalysisEventsForRecovery( _
                        finalRecoveryStopDetail)
        Else
            AppendCashAnalysisRollbackDetail recoveryDetail, _
                "Recovery�������Excel�C�x���g��~���m�F�ł��Ȃ����߁A" & _
                "������Ԃ�ǂݎ�炸�J�n�l�ւ��߂��܂���B���ݏ�Ԃ͕s���ł�: " & _
                postEnforceStopDetail
        End If
        If Not recoveryConfirmed Then _
            AppendCashAnalysisRollbackDetail recoveryDetail, _
                "�����Recovery��d��Ԃ������m�F�ł��܂���B"
        If recoveryConfirmed And Not applicationStateConfirmed Then _
            AppendCashAnalysisRollbackDetail recoveryDetail, _
                "Recovery�m�F���Application��Ԃ������m�F�ł��܂���B"
        If applicationStateConfirmed And Not eventsReadyForRecovery Then _
            AppendCashAnalysisRollbackDetail recoveryDetail, _
                "Application��Ԋm�F���Excel�C�x���gFalse������" & _
                "�m�F�ł��܂���: " & finalRecoveryStopDetail
        eventsReadyForRecovery = _
            TryStopCashAnalysisEventsForRecovery(convergenceDetail)
        eventsCaptured = False
        Err.Raise vbObjectError + 5194, _
                  "CashAnalysisRecoveryFatal/OnCashAnalysisViewChange", _
                  errorDescription & " / " & recoveryDetail
    End If
    If eventsCaptured Then
        safeToRestoreEntry = eventsReadyForRecovery And _
                             ((viewRestoreConfirmed And protectOK) Or _
                              recoveryConfirmed)
        If safeToRestoreEntry Then _
            safeToRestoreEntry = _
                CashAnalysisApplicationStateAllowsEntryRestore( _
                    previousEvents, recoveryDetail)
        If safeToRestoreEntry Then
            eventsReadyForRecovery = _
                TryStopCashAnalysisEventsForRecovery(eventStateDetail)
            safeToRestoreEntry = eventsReadyForRecovery
        End If
        If Not eventsRestoreAttempted And safeToRestoreEntry Then
            If Not TryRestoreCashAnalysisEnableEvents( _
                       previousEvents, "OnCashAnalysisViewChange", _
                       eventStateDetail) Then _
                AppendCashAnalysisRollbackDetail recoveryDetail, eventStateDetail
        ElseIf TryStopCashAnalysisEventsForRecovery(convergenceDetail) Then
            AppendCashAnalysisRollbackDetail recoveryDetail, _
                "��ʕ����E�ĕی�܂���Recovery�������m�F�ł��Ȃ����߁A" & _
                "�J�n���C�x���g�l�֖߂���False�Œ�~���܂����B"
        Else
            AppendCashAnalysisRollbackDetail recoveryDetail, _
                "���S��Ԃ������m�F�ł����AExcel�C�x���g��False�����ɂ�" & _
                "���s���܂����B���ݏ�Ԃ͕s���ł�: " & convergenceDetail
        End If
    End If
    eventsCaptured = False
    If Len(recoveryDetail) > 0 Then _
        errorDescription = errorDescription & " / �����m�F: " & recoveryDetail
    userMessage = "�m�F�󋵂܂��͊m�F�������X�V�ł��܂���ł����B" & vbCrLf
    If viewRestoreConfirmed Then
        userMessage = userMessage & "���͑O�̓��e�֖߂��܂����B"
    Else
        userMessage = userMessage & _
            "���͑O�̓��e�ւ̕����͊m�F�ł��܂���B" & _
            "���݂̃u�b�N���㏑�����Ȃ��ł��������B"
    End If
    MsgBox userMessage & vbCrLf & _
           "���敪�ɍ����m�F�󋵂ƁA" & _
           CStr(VIEW_MEMO_MAX) & "�����ȓ��̃�������͂��Ă��������B" & vbCrLf & _
           "Err " & CStr(errorNumber) & ": " & errorDescription, _
           vbExclamation, "���͔��f�̓��͂��m�F���Ă�������"
End Sub

Public Sub SyncCashAnalysisPanelReviewToWorkspace()
    Dim ws As Worksheet, wsResult As Worksheet
    Dim groupID As String, statusText As String, memoText As String
    Dim sourceSheet As String, sourceKey As String, categoryText As String
    Dim resultRow As Long, sourceRow As Long, lastR As Long, r As Long
    Dim groupValues As Variant
    Dim resultStatusSnapshot As Variant, resultMemoSnapshot As Variant
    Dim previousEvents As Boolean, changed As Boolean, eventsCaptured As Boolean
    Dim eventsRestoreAttempted As Boolean
    Dim snapshotsCaptured As Boolean, writeStarted As Boolean
    Dim isAlternative As Boolean
    Dim workspaceSyncCompleted As Boolean, rollbackOK As Boolean, protectOK As Boolean
    Dim eventsReadyForRollback As Boolean, recoveryConfirmed As Boolean
    Dim applicationStateConfirmed As Boolean
    Dim safeToRestoreEntry As Boolean
    Dim recoveryDetail As String, eventStateDetail As String, stopDetail As String
    Dim dirtyErrorNumber As Long, dirtyErrorDescription As String
    Dim recoveryErrorNumber As Long, recoveryErrorDescription As String
    Dim postEnforceStopDetail As String, convergenceDetail As String
    Dim finalRecoveryStopDetail As String
    Dim errorNumber As Long, errorSource As String, errorDescription As String
    If ThisWorkbook.ReadOnly Then Exit Sub
    On Error GoTo EH
    '�����E�ĕی�Edirty�L�^���܂ޑS�o�H�ŃC�x���g�ē���h���B
    If Not TryGetCashAnalysisEnableEvents(previousEvents, eventStateDetail) Then
        StopAfterCashAnalysisEventStateFailure _
            "SyncCashAnalysisPanelReviewToWorkspace/�J�n��Ԏ擾", _
            eventStateDetail, eventsReadyForRollback, False, vbNullString
        Err.Raise vbObjectError + 5099, _
                  "SyncCashAnalysisPanelReviewToWorkspace", _
                  "Excel�C�x���g�̊J�n��Ԃ��擾�ł��܂���ł����B " & eventStateDetail
    End If
    eventsCaptured = True
    If Not TrySetCashAnalysisEnableEventsExact(False, eventStateDetail) Then _
        Err.Raise vbObjectError + 5100, _
                  "SyncCashAnalysisPanelReviewToWorkspace", _
                  "���͔��f�̓����O��Excel�C�x���g���~�ł��܂���ł����B " & _
                  eventStateDetail
    If Not SheetExists(SH_OUTPUT_TX) Or Not SheetExists(SH_ANALYSIS_RESULT) Then GoTo SafeExit
    Set ws = GetSheet(SH_OUTPUT_TX)
    If CellText(ws.Range(VIEW_STATE_MANUAL).Value) = "1" Then GoTo SafeExit
    groupID = CellText(ws.Range(VIEW_STATE_GROUP_ID).Value)
    If Len(groupID) = 0 Then GoTo SafeExit
    ValidateCashAnalysisPanelReview ws
    statusText = CellText(ws.Range("C3").Value)
    memoText = CellText(ws.Range("C8").Value)
    Set wsResult = GetSheet(SH_ANALYSIS_RESULT)
    If Not TryGetLastUsedRowInSheet(wsResult, lastR) Then _
        Err.Raise vbObjectError + 4982, "SyncCashAnalysisPanelReviewToWorkspace", _
                  "���͌��ʂ̍ŏI�s���m�F�ł��܂���B"
    If lastR >= 2 Then _
        RequireAnalysisReviewConstantRange wsResult.Range( _
            wsResult.Cells(2, ANALYSIS_RESULT_GROUP_ID_COL), _
            wsResult.Cells(lastR, ANALYSIS_RESULT_GROUP_ID_COL)), _
            "���͌��ʂ̓����O���[�vID"
    resultRow = CLng(Val(CellText(ws.Range(VIEW_STATE_RESULT_ROW).Value)))
    'VBA��Or�͒Z���]������Ȃ����߁A�͈͊O�s��Cells��ǂ܂��i�K�I�ɍČ����֗��Ƃ��B
    If resultRow < 2 Or resultRow > lastR Then
        resultRow = 0
    ElseIf StrComp( _
               CellText(wsResult.Cells(resultRow, ANALYSIS_RESULT_GROUP_ID_COL).Value), _
               groupID, vbTextCompare) <> 0 Then
        resultRow = 0
    End If
    If resultRow = 0 Then
        If lastR >= 2 Then _
            groupValues = CashResultColumnValues(wsResult, 2, lastR, ANALYSIS_RESULT_GROUP_ID_COL)
        For r = 1 To Application.Max(0, lastR - 1)
            If StrComp(CellText(groupValues(r, 1)), groupID, vbTextCompare) = 0 Then
                resultRow = r + 1
                Exit For
            End If
        Next r
    End If
    If resultRow = 0 Then _
        Err.Raise vbObjectError + 4982, "SyncCashAnalysisPanelReviewToWorkspace", _
                  "��������\�ɕ\�����̕��͌�₪�A���͌��ʂ��猩����܂���B�ĕ��͑O�̓����𒆎~���܂����B"
    If Not CashAnalysisCurrentSourceReference( _
               ws, wsResult, resultRow, sourceSheet, sourceRow, sourceKey, _
               categoryText, isAlternative) Then _
        Err.Raise vbObjectError + 5011, "SyncCashAnalysisPanelReviewToWorkspace", _
                  "��������\�ɕ\�����̌��Ɠ�����������ӂɑΉ��t�����܂���B"
    RequireCashAnalysisGroupConfirmationAvailable groupID, _
        CashAnalysisCandidateReference(sourceSheet, sourceRow, sourceKey), statusText
    If isAlternative Then
        '��֌��̔��f�́A���̑�ւ̌��\�E���ڍׂ����֕ۑ�����B
        '�O���[�v��\�̕��͌��ʂ�����ď㏑�����Ȃ��B
        MarkAnalysisReviewsDirty
        If SyncCashAnalysisReviewToSourceAndDetailSnapshot( _
                sourceSheet, sourceRow, sourceKey, categoryText, statusText, memoText) Then _
            changed = True
        workspaceSyncCompleted = True
        GoTo SafeExit
    End If
    RequireAnalysisReviewConstantRange Union( _
        wsResult.Cells(resultRow, 2), _
        wsResult.Range(wsResult.Cells(resultRow, ANALYSIS_RESULT_STATUS_COL), _
                       wsResult.Cells(resultRow, ANALYSIS_RESULT_MEMO_COL)), _
        wsResult.Range(wsResult.Cells(resultRow, ANALYSIS_RESULT_SOURCE_SHEET_COL), _
                       wsResult.Cells(resultRow, ANALYSIS_RESULT_ALTERNATIVE_COUNT_COL))), _
        "���͌��ʂ̊m�F���܂��͓����Q��"
    wsResult.Unprotect Password:=TOOL_PASSWORD
    resultStatusSnapshot = wsResult.Cells(resultRow, ANALYSIS_RESULT_STATUS_COL).Value2
    resultMemoSnapshot = wsResult.Cells(resultRow, ANALYSIS_RESULT_MEMO_COL).Value2
    If Not StrictVariantValuesMatch( _
               resultStatusSnapshot, _
               wsResult.Cells(resultRow, ANALYSIS_RESULT_STATUS_COL).Value2) Or _
       Not StrictVariantValuesMatch( _
               resultMemoSnapshot, _
               wsResult.Cells(resultRow, ANALYSIS_RESULT_MEMO_COL).Value2) Then _
        Err.Raise vbObjectError + 4983, "SyncCashAnalysisPanelReviewToWorkspace", _
                  "���͌��ʂ̊m�F�����^�܂Ō����ɑޔ��ł��܂���B"
    snapshotsCaptured = True
    writeStarted = True
    changed = WriteCashAnalysisReviewTextCellIfChanged( _
                  wsResult.Cells(resultRow, ANALYSIS_RESULT_STATUS_COL), _
                  statusText, "���͌��ʂ̊m�F��")
    If WriteCashAnalysisReviewTextCellIfChanged( _
           wsResult.Cells(resultRow, ANALYSIS_RESULT_MEMO_COL), _
           memoText, "���͌��ʂ̊m�F����") Then changed = True
    ProtectSingleAnalysisSheet wsResult
    MarkAnalysisReviewsDirty
    '���ڍׂɓ������̋��X�i�b�v�V���b�g���c���Ă��Ă��A�㑱Commit�Ō��ݒl��
    '�㏑�����Ȃ��悤�A���\�ƑΉ�����ڍ׍s�𓯂��l�֌�����������B
    If SyncCashAnalysisReviewToSourceAndDetailSnapshot( _
            sourceSheet, sourceRow, sourceKey, categoryText, statusText, memoText) Then _
        changed = True
    workspaceSyncCompleted = True
SafeExit:
    If eventsCaptured Then
        eventsRestoreAttempted = True
        If Not TryRestoreCashAnalysisEnableEvents( _
                   previousEvents, _
                   "SyncCashAnalysisPanelReviewToWorkspace", _
                   eventStateDetail) Then _
            Err.Raise vbObjectError + 5101, _
                      "SyncCashAnalysisPanelReviewToWorkspace", eventStateDetail
        eventsCaptured = False
    End If
    Exit Sub
EH:
    errorNumber = Err.Number
    errorSource = Err.Source
    errorDescription = Err.Description
    If IsCashAnalysisRecoveryFatal(errorNumber, errorSource) Then
        Call TryStopCashAnalysisEventsForRecovery(convergenceDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    If eventsCaptured Then _
        eventsReadyForRollback = _
            TryStopCashAnalysisEventsForRecovery(stopDetail)
    If Not eventsReadyForRollback Then
        If eventsCaptured Then
            AppendCashAnalysisRollbackDetail recoveryDetail, _
                "���[���o�b�N�O��Excel�C�x���g���~���ēǖ߂��m�F�ł��܂���ł���: " & _
                stopDetail
        ElseIf Len(stopDetail) > 0 Then
            AppendCashAnalysisRollbackDetail recoveryDetail, _
                "Excel�C�x���g�̊J�n��Ԃ��擾�ł����A" & _
                "��~�̓ǖ߂��m�F�ɂ����s�������ߌ��ݏ�Ԃ͕s���ł�: " & _
                stopDetail
        Else
            AppendCashAnalysisRollbackDetail recoveryDetail, _
                "Excel�C�x���g�̊J�n��Ԃƌ��ݏ�Ԃ��m�F�ł��܂���ł����B"
        End If
    End If
    On Error Resume Next
    Err.Clear
    rollbackOK = True
    If writeStarted And snapshotsCaptured And Not workspaceSyncCompleted Then
        If eventsReadyForRollback Then
            rollbackOK = RestoreCashAnalysisResultReviewSnapshot( _
                             wsResult, resultRow, resultStatusSnapshot, _
                             resultMemoSnapshot, recoveryDetail)
        Else
            rollbackOK = False
            AppendCashAnalysisRollbackDetail recoveryDetail, _
                "Excel�C�x���g��~���m�F�ł��Ȃ����ߕ��͌��ʂ̑ޔ�l���ď����݂��܂���ł����B"
        End If
    End If
    protectOK = True
    If Not wsResult Is Nothing Then
        If eventsReadyForRollback Then
            Err.Clear
            ProtectSingleAnalysisSheet wsResult
        Else
            protectOK = False
            AppendCashAnalysisRollbackDetail recoveryDetail, _
                "�C�x���g��~���m�F�̂��ߕ��͌��ʂ��ĕی삵�܂���ł����B"
        End If
        If eventsReadyForRollback And Err.Number <> 0 Then
            protectOK = False
            AppendCashAnalysisRollbackDetail recoveryDetail, _
                "���͌��ʂ̍ĕی�G���[: " & Err.Description
        End If
    End If
    Err.Clear
    If eventsReadyForRollback Then
        MarkAnalysisReviewsDirty
        dirtyErrorNumber = Err.Number
        dirtyErrorDescription = Err.Description
    Else
        AppendCashAnalysisRollbackDetail recoveryDetail, _
            "�C�x���g��~���m�F�̂��ߕ��͔��f�v������Ԃ��L�^���܂���ł����B"
    End If
    Err.Clear
    If dirtyErrorNumber <> 0 Then _
        AppendCashAnalysisRollbackDetail recoveryDetail, _
            "���͔��f�v������Ԃ̋L�^�G���[: Err " & _
            CStr(dirtyErrorNumber) & " " & dirtyErrorDescription
    If Not eventsReadyForRollback Or Not rollbackOK Or Not protectOK Or _
        dirtyErrorNumber <> 0 Then
        If eventsReadyForRollback Then
            Err.Clear
            EnforceRollbackRecoveryState recoveryDetail
            recoveryErrorNumber = Err.Number
            recoveryErrorDescription = Err.Description
            Err.Clear
            'Enforce�̌��ʂ�ۑ����������False����蒼���B���s���́A
            '�Â�Recovery�l�̓ǎ��E�ǉ������݁E�J�n�l�����֐i�܂Ȃ��B
            eventsReadyForRollback = _
                TryStopCashAnalysisEventsForRecovery(postEnforceStopDetail)
            If recoveryErrorNumber <> 0 Then
                AppendCashAnalysisRollbackDetail recoveryDetail, _
                    "�v������Ԃ̋����ݒ�G���[: Err " & _
                    CStr(recoveryErrorNumber) & " " & recoveryErrorDescription
                On Error GoTo 0
                eventsCaptured = False
                Err.Raise vbObjectError + 5194, _
                    "CashAnalysisRecoveryFatal/SyncCashAnalysisPanelReviewToWorkspace", _
                    errorDescription & " / " & recoveryDetail
            ElseIf eventsReadyForRollback Then
                recoveryConfirmed = _
                    CashAnalysisRecoveryStateIsConfirmedExact(recoveryDetail)
                If recoveryConfirmed Then _
                    applicationStateConfirmed = _
                        CashAnalysisApplicationStateAllowsEntryRestore( _
                            True, recoveryDetail)
                If applicationStateConfirmed Then _
                    eventsReadyForRollback = _
                        TryStopCashAnalysisEventsForRecovery( _
                            finalRecoveryStopDetail)
            Else
                AppendCashAnalysisRollbackDetail recoveryDetail, _
                    "Recovery�������Excel�C�x���g��~���m�F�ł��Ȃ����߁A" & _
                    "������Ԃ�ǂݎ�炸�J�n�l�ւ��߂��܂���B���ݏ�Ԃ͕s���ł�: " & _
                    postEnforceStopDetail
            End If
            If Not recoveryConfirmed Then _
                AppendCashAnalysisRollbackDetail recoveryDetail, _
                    "�����Recovery��d��Ԃ������m�F�ł��܂���B"
            If recoveryConfirmed And Not applicationStateConfirmed Then _
                AppendCashAnalysisRollbackDetail recoveryDetail, _
                    "Recovery�m�F���Application��Ԃ������m�F�ł��܂���B"
            If applicationStateConfirmed And Not eventsReadyForRollback Then _
                AppendCashAnalysisRollbackDetail recoveryDetail, _
                    "Application��Ԋm�F���Excel�C�x���gFalse������" & _
                    "�m�F�ł��܂���: " & finalRecoveryStopDetail
            eventsReadyForRollback = _
                TryStopCashAnalysisEventsForRecovery(convergenceDetail)
            On Error GoTo 0
            eventsCaptured = False
            Err.Raise vbObjectError + 5194, _
                "CashAnalysisRecoveryFatal/SyncCashAnalysisPanelReviewToWorkspace", _
                errorDescription & " / " & recoveryDetail
        Else
            AppendCashAnalysisRollbackDetail recoveryDetail, _
                "�C�x���g��~���m�F�̂���Recovery��Ԃ��L�^���܂���ł����B"
        End If
    End If
    On Error GoTo 0
    If eventsCaptured Then
        safeToRestoreEntry = eventsReadyForRollback And _
                             ((rollbackOK And protectOK And _
                               dirtyErrorNumber = 0) Or recoveryConfirmed)
        If safeToRestoreEntry Then _
            safeToRestoreEntry = _
                CashAnalysisApplicationStateAllowsEntryRestore( _
                    previousEvents, recoveryDetail)
        If safeToRestoreEntry Then
            eventsReadyForRollback = _
                TryStopCashAnalysisEventsForRecovery(eventStateDetail)
            safeToRestoreEntry = eventsReadyForRollback
        End If
        If Not eventsRestoreAttempted And safeToRestoreEntry Then
            If Not TryRestoreCashAnalysisEnableEvents( _
                       previousEvents, _
                       "SyncCashAnalysisPanelReviewToWorkspace", _
                       eventStateDetail) Then _
                AppendCashAnalysisRollbackDetail recoveryDetail, eventStateDetail
        ElseIf TryStopCashAnalysisEventsForRecovery(convergenceDetail) Then
            AppendCashAnalysisRollbackDetail recoveryDetail, _
                "���[���o�b�N�E�ĕی�܂���Recovery�������m�F�ł��Ȃ����߁A" & _
                "�J�n���C�x���g�l�֖߂���False�Œ�~���܂����B"
        Else
            AppendCashAnalysisRollbackDetail recoveryDetail, _
                "���S��Ԃ������m�F�ł����AExcel�C�x���g��False�����ɂ�" & _
                "���s���܂����B���ݏ�Ԃ͕s���ł�: " & convergenceDetail
        End If
    End If
    eventsCaptured = False
    If Len(recoveryDetail) > 0 Then _
        errorDescription = errorDescription & " / �����m�F: " & recoveryDetail
    If Len(errorSource) = 0 Then _
        errorSource = "SyncCashAnalysisPanelReviewToWorkspace"
    Err.Raise errorNumber, errorSource, errorDescription
End Sub

Private Function WriteCashAnalysisReviewTextCellIfChanged( _
        ByVal target As Range, ByVal textValue As String, _
        ByVal labelText As String) As Boolean
    Dim expectedData As Variant
    ReDim expectedData(1 To 1, 1 To 1)
    If target Is Nothing Then _
        Err.Raise vbObjectError + 4984, _
                  "WriteCashAnalysisReviewTextCellIfChanged", _
                  labelText & "�̏�������擾�ł��܂���B"
    If target.Cells.CountLarge <> 1 Then _
        Err.Raise vbObjectError + 4984, _
                  "WriteCashAnalysisReviewTextCellIfChanged", _
                  labelText & "�̏����悪�P��Z���ł͂���܂���B"
    If Len(textValue) = 0 Then
        expectedData(1, 1) = Empty
    Else
        expectedData(1, 1) = CStr(textValue)
    End If
    If StrictVariantValuesMatch(expectedData(1, 1), target.Value2) And _
       Not target.HasFormula And Len(CStr(target.PrefixCharacter)) = 0 Then Exit Function
    target.NumberFormatLocal = "@"
    target.Value2 = expectedData(1, 1)
    If Not RangeValue2MatchesMatrixStrict(target, expectedData, 1, 1) Then _
        Err.Raise vbObjectError + 4985, _
                  "WriteCashAnalysisReviewTextCellIfChanged", _
                  labelText & "�̏����ǖ߂����^�܂ň�v���܂���B"
    RequireAnalysisReviewConstantRange target, labelText
    WriteCashAnalysisReviewTextCellIfChanged = True
End Function

Private Function RestoreCashAnalysisResultReviewSnapshot( _
        ByVal ws As Worksheet, ByVal resultRow As Long, _
        ByVal statusSnapshot As Variant, ByVal memoSnapshot As Variant, _
        ByRef detailText As String) As Boolean
    Dim expectedData As Variant
    ReDim expectedData(1 To 1, 1 To 1)
    On Error GoTo EH
    If ws Is Nothing Or resultRow < 2 Then _
        Err.Raise vbObjectError + 4986, _
                  "RestoreCashAnalysisResultReviewSnapshot", _
                  "���͌��ʂ̕����悪�s���ł��B"
    ws.Unprotect Password:=TOOL_PASSWORD
    expectedData(1, 1) = statusSnapshot
    ws.Cells(resultRow, ANALYSIS_RESULT_STATUS_COL).Value2 = expectedData(1, 1)
    If Not RangeValue2MatchesMatrixStrict( _
               ws.Cells(resultRow, ANALYSIS_RESULT_STATUS_COL), _
               expectedData, 1, 1) Then _
        Err.Raise vbObjectError + 4987, _
                  "RestoreCashAnalysisResultReviewSnapshot", _
                  "���͌��ʂ̊m�F�󋵂������ɕ����ł��܂���B"
    expectedData(1, 1) = memoSnapshot
    ws.Cells(resultRow, ANALYSIS_RESULT_MEMO_COL).Value2 = expectedData(1, 1)
    If Not RangeValue2MatchesMatrixStrict( _
               ws.Cells(resultRow, ANALYSIS_RESULT_MEMO_COL), _
               expectedData, 1, 1) Then _
        Err.Raise vbObjectError + 4988, _
                  "RestoreCashAnalysisResultReviewSnapshot", _
                  "���͌��ʂ̊m�F�����������ɕ����ł��܂���B"
    RestoreCashAnalysisResultReviewSnapshot = True
    Exit Function
EH:
    detailText = "���͌��ʂ̕����G���[: " & Err.Description
    Err.Clear
End Function

Private Sub ValidateCashAnalysisPanelReview(ByVal ws As Worksheet)
    Dim categoryText As String, statusText As String, memoText As String
    RequireAnalysisReviewConstantRange Union(ws.Range("C3"), ws.Range("C8")), _
        "��������\�̕��͊m�F��"
    categoryText = CellText(ws.Range(VIEW_STATE_CATEGORY).Value)
    statusText = CellText(ws.Range("C3").Value)
    memoText = CellText(ws.Range("C8").Value)
    If Len(statusText) = 0 Then
        statusText = ANALYSIS_STATUS_UNREVIEWED
        WriteCashAnalysisReviewTextCellIfChanged ws.Range("C3"), statusText, _
            "��������\�̊m�F��"
    End If
    If Not IsStatusAllowedForCashCategory(categoryText, statusText) Then _
        Err.Raise vbObjectError + 4980, "ValidateCashAnalysisPanelReview", _
                  "�m�F�󋵁u" & statusText & "�v��" & categoryText & "�ł͑I���ł��܂���B"
    If Len(memoText) > VIEW_MEMO_MAX Then _
        Err.Raise vbObjectError + 4981, "ValidateCashAnalysisPanelReview", _
                  "�m�F������" & CStr(VIEW_MEMO_MAX) & "�����ȓ��œ��͂��Ă��������B"
End Sub

Private Sub ApplyCashAnalysisPanelValidation(ByVal ws As Worksheet)
    Dim listName As String
    On Error Resume Next
    ws.Range("C3").Validation.Delete
    ws.Range("C8").Validation.Delete
    On Error GoTo 0
    If CellText(ws.Range(VIEW_STATE_MANUAL).Value) = "1" Or _
       Len(CellText(ws.Range(VIEW_STATE_GROUP_ID).Value)) = 0 Then Exit Sub
    Select Case CellText(ws.Range(VIEW_STATE_CATEGORY).Value)
        Case VIEW_CATEGORY_UNKNOWN_DEPOSIT: listName = NM_LST_ANALYSIS_SOURCE_STATUS
        Case VIEW_CATEGORY_UNKNOWN_WITHDRAW: listName = NM_LST_ANALYSIS_USE_STATUS
        Case Else: listName = NM_LST_ANALYSIS_SHIFT_STATUS
    End Select
    With ws.Range("C3").Validation
        .Add Type:=xlValidateList, AlertStyle:=xlValidAlertStop, _
             Operator:=xlBetween, Formula1:="=" & listName
        .IgnoreBlank = False
        .InCellDropdown = True
        .ShowError = True
        .ErrorTitle = "�m�F�󋵂�I�����Ă�������"
        .ErrorMessage = "���敪�ɍ����m�F�󋵂��ꗗ����I�����Ă��������B"
    End With
    With ws.Range("C8").Validation
        .Add Type:=xlValidateTextLength, AlertStyle:=xlValidAlertStop, _
             Operator:=xlLessEqual, Formula1:=CStr(VIEW_MEMO_MAX)
        .IgnoreBlank = True
        .ShowError = True
        .ErrorTitle = "�m�F�������������܂�"
        .ErrorMessage = "�m�F������" & CStr(VIEW_MEMO_MAX) & "�����ȓ��œ��͂��Ă��������B"
    End With
End Sub

Private Sub UpdateCashAnalysisStatusStyle(ByVal ws As Worksheet)
    Dim statusText As String
    statusText = CellText(ws.Range("C3").Value)
    With ws.Range("C3:D3")
        .Font.Bold = True
        .HorizontalAlignment = xlCenter
        Select Case statusText
            Case ANALYSIS_STATUS_SHIFT_CONFIRMED, ANALYSIS_STATUS_SOURCE_CONFIRMED, ANALYSIS_STATUS_USE_CONFIRMED
                .Interior.Color = RGB(220, 252, 231)
                .Font.Color = RGB(22, 101, 52)
            Case ANALYSIS_STATUS_FOLLOWUP
                .Interior.Color = RGB(254, 243, 199)
                .Font.Color = RGB(146, 64, 14)
            Case ANALYSIS_STATUS_EXCLUDED
                .Interior.Color = RGB(226, 232, 240)
                .Font.Color = RGB(71, 85, 105)
            Case Else
                .Interior.Color = RGB(254, 249, 195)
                .Font.Color = RGB(133, 77, 14)
        End Select
    End With
    UpdateCashAnalysisPrimaryActionState ws, statusText
End Sub

Private Sub UpdateCashAnalysisPrimaryActionState(ByVal ws As Worksheet, ByVal statusText As String)
    Dim confirmedStatus As String
    If ws Is Nothing Then Exit Sub
    If CellText(ws.Range(VIEW_STATE_MANUAL).Value) = "1" Then Exit Sub
    If Len(CellText(ws.Range(VIEW_STATE_GROUP_ID).Value)) = 0 Then
        SetShapeCaption ws, "CashAnalysisPrimaryAction", "���Ȃ�"
        SetViewButtonColors ws, "CashAnalysisPrimaryAction", _
                            RGB(241, 245, 249), RGB(203, 213, 225), RGB(100, 116, 139)
        Exit Sub
    End If
    confirmedStatus = ConfirmedStatusForCashCategory(CellText(ws.Range(VIEW_STATE_CATEGORY).Value))
    Select Case statusText
        Case confirmedStatus
            SetShapeCaption ws, "CashAnalysisPrimaryAction", "�m�F���e��ۑ�"
            SetViewButtonColors ws, "CashAnalysisPrimaryAction", _
                                RGB(220, 252, 231), RGB(34, 197, 94), RGB(22, 101, 52)
        Case ANALYSIS_STATUS_FOLLOWUP
            SetShapeCaption ws, "CashAnalysisPrimaryAction", "�v�ǉ������ŕۑ�"
            SetViewButtonColors ws, "CashAnalysisPrimaryAction", _
                                RGB(254, 243, 199), RGB(245, 158, 11), RGB(146, 64, 14)
        Case ANALYSIS_STATUS_EXCLUDED
            SetShapeCaption ws, "CashAnalysisPrimaryAction", "�ΏۊO�ŕۑ�"
            SetViewButtonColors ws, "CashAnalysisPrimaryAction", _
                                RGB(226, 232, 240), RGB(148, 163, 184), RGB(71, 85, 105)
        Case Else
            SetShapeCaption ws, "CashAnalysisPrimaryAction", "�m�F�ς݂ɂ���"
            SetViewButtonColors ws, "CashAnalysisPrimaryAction", _
                                RGB(37, 99, 235), RGB(29, 78, 216), RGB(255, 255, 255)
    End Select
End Sub

Public Function RequireCashAnalysisManualModeFinished(ByVal intendedAction As String) As Boolean
    Dim selectionText As String
    If Not CashAnalysisManualModeActive() Then
        RequireCashAnalysisManualModeFinished = True
        Exit Function
    End If
    If HasCashAnalysisManualSelection() Then
        selectionText = "�I�𒆂̎��������܂��B"
    Else
        selectionText = "���݁A�蓮���̑I�����[�h�ł��B"
    End If
    MsgBox selectionText & vbCrLf & _
           intendedAction & "�̑O�ɁA�m�I����������o�^�n�܂��́m�I�����������n�������Ă��������B" & _
           vbCrLf & "�I����e��ق��Ĕj�����邱�Ƃ͂���܂���B", _
           vbInformation, "�蓮���̑I�����������Ă�������"
End Function

Public Sub PrepareCashAnalysisViewForPrint()
    '����������͍������ȗ����Ȃ��B��������S�\�����Ă���A�}�`�̔����A
    '����͈́AA4���E��1�y�[�W���𒼑O�ɍČ��؂���B
    Dim ws As Worksheet
    Dim lastR As Long
    Dim eventsReady As Boolean
    Dim convergenceDetail As String
    Dim errorNumber As Long, errorSource As String, errorDescription As String
    If Not SheetExists(SH_OUTPUT_TX) Then Exit Sub
    On Error GoTo EH
    Set ws = GetSheet(SH_OUTPUT_TX)
    ws.Unprotect Password:=TOOL_PASSWORD
    ws.Range(VIEW_STATE_PANEL_EXPANDED).Value = "1"
    AdjustCashAnalysisPanelRowHeights ws
    ApplyCashAnalysisPrintPanelHeights ws
    lastR = CashAnalysisLastDataRow(ws)
    If lastR < CASH_VIEW_HEADER_ROW Then lastR = CASH_VIEW_HEADER_ROW
    ApplyPrintAreaVerified ws, ws.Range("A1:M" & CStr(lastR)), True
    ApplyReadablePrintSettings ws, "$10:$10", 1, "", True
    '������O�́u�ݒ�API������������悢�v�ł͂Ȃ��A�S����}�`�ɂ���
    '������ǖ߂������Ƃ܂ŕK�{�ɂ���B���m��Ԃ̂܂܎��ʂ֐i�܂��Ȃ��B
    LockToolShapes ws, True
    ProtectCashAnalysisViewSheet
    Exit Sub
EH:
    errorNumber = Err.Number
    errorSource = Err.Source
    errorDescription = Err.Description
    If IsCashAnalysisRecoveryFatal(errorNumber, errorSource) Then
        Call TryStopCashAnalysisEventsForRecovery(convergenceDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    Call TryProtectCashAnalysisViewAfterFailure( _
        ws, "PrepareCashAnalysisViewForPrint", False, errorDescription)
    Err.Raise errorNumber, "PrepareCashAnalysisViewForPrint", errorDescription
End Sub

Private Sub ApplyCashAnalysisPrintPanelHeights(ByVal ws As Worksheet)
    'Excel��1�s������ŁA1,000�����̊m�F�����ƒ������͗��R�����ʂ֎c���B
    If ws Is Nothing Then Exit Sub
    ws.Rows(5).RowHeight = CashPanelTextRowHeight(CellText(ws.Range("H5").Value), 90, 31, 409.5)
    ws.Rows(6).RowHeight = CashPanelTextRowHeight(CellText(ws.Range("C6").Value), 150, 38, 409.5)
    ws.Rows(7).RowHeight = CashPanelTextRowHeight(CellText(ws.Range("C7").Value), 150, 38, 409.5)
    ws.Rows(8).RowHeight = CashPanelTextRowHeight(CellText(ws.Range("C8").Value), 150, 42, 409.5)
End Sub

Public Sub ProtectCashAnalysisViewSheet()
    Dim ws As Worksheet, canEdit As Boolean
    Dim lockLastRow As Long
    Dim workbookWasSaved As Boolean, protectOK As Boolean
    Dim entryEvents As Boolean, eventsCaptured As Boolean, eventsReady As Boolean
    Dim protectionMutationStarted As Boolean, safeToRestoreEntry As Boolean
    Dim protectionRecoveryAttempted As Boolean
    Dim protectionRecoveryFailed As Boolean
    Dim protectionRecoveryConfirmed As Boolean
    Dim policyConfirmed As Boolean
    Dim eventDetail As String, convergenceDetail As String
    Dim finalRecoveryStopDetail As String
    Dim policyDetail As String
    Dim savedErrorNumber As Long, savedErrorDescription As String
    Dim errorNumber As Long, errorSource As String, errorDescription As String
    If Not SheetExists(SH_OUTPUT_TX) Then Exit Sub
    On Error GoTo EH
    Set ws = GetSheet(SH_OUTPUT_TX)
    workbookWasSaved = ThisWorkbook.Saved
    If Not TryGetCashAnalysisEnableEvents(entryEvents, eventDetail) Then _
        Err.Raise vbObjectError + 5106, "ProtectCashAnalysisViewSheet", _
                  "Excel�C�x���g�̊J�n��Ԃ��擾�ł��܂���ł����B " & eventDetail
    eventsCaptured = True
    eventsReady = TryStopCashAnalysisEventsForRecovery(eventDetail)
    If Not eventsReady Then _
        Err.Raise vbObjectError + 5107, "ProtectCashAnalysisViewSheet", _
                  "�ی�O��Excel�C�x���g��~���m�F�ł��܂���ł����B " & eventDetail
    protectionMutationStarted = True
    ws.Unprotect Password:=TOOL_PASSWORD
    lockLastRow = Application.Min(ws.Rows.Count, _
                  Application.Max(60, LastUsedRowInSheet(ws) + 20))
    ws.Range("A1:Z" & CStr(lockLastRow)).Locked = True
    RestoreToolSheetScrollArea ws
    canEdit = Not ThisWorkbook.ReadOnly And _
              CellText(ws.Range(VIEW_STATE_MANUAL).Value) <> "1" And _
              Len(CellText(ws.Range(VIEW_STATE_GROUP_ID).Value)) > 0
    If canEdit Then
        ws.Range("C3:D3").Locked = False
        ws.Range("C8:M8").Locked = False
    End If
    '�ʏ�\���E�Z�b�g�A�b�v���́AOffice�r���h���̂���PrintObject������
    'best-effort�ɂ���B�������PrepareCashAnalysisViewForPrint�Ō��i���؂���B
    LockToolShapes ws, False
    ws.Protect Password:=TOOL_PASSWORD, DrawingObjects:=True, Contents:=True, Scenarios:=False, _
               UserInterfaceOnly:=True, AllowFiltering:=True, AllowSorting:=False, _
               AllowFormattingCells:=False, AllowFormattingColumns:=False, AllowFormattingRows:=False
    ws.EnableSelection = xlNoRestrictions
    VerifyToolShapeSecurity ws, True, False
    policyConfirmed = _
        CashAnalysisProtectionPolicyIsConfirmedExact(ws, policyDetail)
    If Not policyConfirmed Then _
        Err.Raise vbObjectError + 5114, "ProtectCashAnalysisViewSheet", _
                  "��������\�̑S�ی�|���V�[��ǖ߂��m�F�ł��܂���ł����B " & _
                  policyDetail
    If workbookWasSaved Then ThisWorkbook.Saved = True
    If Not TryRestoreCashAnalysisEnableEvents( _
               entryEvents, "ProtectCashAnalysisViewSheet", eventDetail) Then _
        Err.Raise vbObjectError + 5108, "ProtectCashAnalysisViewSheet", eventDetail
    eventsCaptured = False
    Exit Sub
EH:
    errorNumber = Err.Number
    errorSource = Err.Source
    errorDescription = Err.Description
    If IsCashAnalysisRecoveryFatal(errorNumber, errorSource) Then
        Call TryStopCashAnalysisEventsForRecovery(convergenceDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    eventsReady = False
    If eventsCaptured Then _
        eventsReady = TryStopCashAnalysisEventsForRecovery(eventDetail)
    safeToRestoreEntry = Not protectionMutationStarted
    If eventsReady Then
        protectOK = TryProtectCashAnalysisViewAfterFailure( _
                        ws, "ProtectCashAnalysisViewSheet", True, _
                        errorDescription, protectionRecoveryAttempted, _
                        protectionRecoveryFailed, _
                        protectionRecoveryConfirmed)
        eventsReady = TryStopCashAnalysisEventsForRecovery(eventDetail)
        If Not protectionRecoveryFailed And eventsReady And protectOK Then
            policyDetail = vbNullString
            policyConfirmed = _
                CashAnalysisProtectionPolicyIsConfirmedExact(ws, policyDetail)
            If Not policyConfirmed Then _
                AppendCashAnalysisRollbackDetail errorDescription, policyDetail
        Else
            policyConfirmed = False
        End If
        safeToRestoreEntry = eventsReady And _
            Not protectionRecoveryFailed And _
            (policyConfirmed Or protectionRecoveryConfirmed)
    End If
    If safeToRestoreEntry Then _
        safeToRestoreEntry = _
            CashAnalysisApplicationStateAllowsEntryRestore( _
                entryEvents, errorDescription)
    If safeToRestoreEntry Then
        eventsReady = _
            TryStopCashAnalysisEventsForRecovery(finalRecoveryStopDetail)
        safeToRestoreEntry = eventsReady
    End If
    If eventsReady And Not protectionRecoveryFailed Then
        If workbookWasSaved And policyConfirmed Then
            On Error Resume Next
            Err.Clear
            ThisWorkbook.Saved = True
            savedErrorNumber = Err.Number
            savedErrorDescription = Err.Description
            Err.Clear
            On Error GoTo 0
            If savedErrorNumber <> 0 Then _
                AppendCashAnalysisRollbackDetail errorDescription, _
                    "�u�b�N�ۑ���Ԃ̕����G���[: Err " & _
                    CStr(savedErrorNumber) & " " & savedErrorDescription
        End If
    End If
    If Not eventsReady Then _
        AppendCashAnalysisRollbackDetail errorDescription, _
            "Excel�C�x���g��~���m�F�̂��߁A�ً}�ĕی�ƕۑ���Ԃ̏����݂��s���܂���ł����B"
    If eventsCaptured Then
        If safeToRestoreEntry Then
            eventsReady = TryStopCashAnalysisEventsForRecovery(eventDetail)
            safeToRestoreEntry = eventsReady
        End If
        If safeToRestoreEntry Then
            If Not TryRestoreCashAnalysisEnableEvents( _
                       entryEvents, "ProtectCashAnalysisViewSheet/�G���[�I��", _
                       eventDetail) Then
                AppendCashAnalysisRollbackDetail errorDescription, eventDetail
                safeToRestoreEntry = False
                eventsReady = _
                    TryStopCashAnalysisEventsForRecovery(convergenceDetail)
            End If
        ElseIf TryStopCashAnalysisEventsForRecovery(convergenceDetail) Then
            AppendCashAnalysisRollbackDetail errorDescription, _
                "�ĕی�܂���Recovery�������m�F�ł��Ȃ����߁A" & _
                "�J�n���C�x���g�l�֖߂���False�Œ�~���܂����B"
        Else
            AppendCashAnalysisRollbackDetail errorDescription, _
                "���S��Ԃ������m�F�ł����AExcel�C�x���g��False�����ɂ�" & _
                "���s���܂����B���ݏ�Ԃ͕s���ł�: " & convergenceDetail
        End If
    End If
    eventsCaptured = False
    If protectionRecoveryFailed Then _
        Err.Raise vbObjectError + 5194, _
                  "CashAnalysisRecoveryFatal/ProtectCashAnalysisViewSheet", _
                  errorDescription
    Err.Raise errorNumber, "ProtectCashAnalysisViewSheet", errorDescription
End Sub

Public Sub SetCashAnalysisViewEditingEnabled(ByVal enabled As Boolean)
    Dim ws As Worksheet
    Dim workbookWasSaved As Boolean, protectOK As Boolean
    Dim entryEvents As Boolean, eventsCaptured As Boolean
    Dim eventsReady As Boolean
    Dim protectionMutationStarted As Boolean, safeToRestoreEntry As Boolean
    Dim protectionRecoveryAttempted As Boolean
    Dim protectionRecoveryFailed As Boolean
    Dim protectionRecoveryConfirmed As Boolean
    Dim policyConfirmed As Boolean
    Dim eventDetail As String, recoveryDetail As String
    Dim convergenceDetail As String, policyDetail As String
    Dim finalRecoveryStopDetail As String
    Dim savedErrorNumber As Long, savedErrorDescription As String
    Dim errorNumber As Long, errorSource As String, errorDescription As String
    If Not SheetExists(SH_OUTPUT_TX) Then Exit Sub
    On Error GoTo EH
    Set ws = GetSheet(SH_OUTPUT_TX)
    workbookWasSaved = ThisWorkbook.Saved
    If Not TryGetCashAnalysisEnableEvents(entryEvents, eventDetail) Then _
        Err.Raise vbObjectError + 5115, "SetCashAnalysisViewEditingEnabled", _
                  "Excel�C�x���g�̊J�n��Ԃ��擾�ł��܂���ł����B " & eventDetail
    eventsCaptured = True
    eventsReady = TryStopCashAnalysisEventsForRecovery(eventDetail)
    If Not eventsReady Then _
        Err.Raise vbObjectError + 5116, "SetCashAnalysisViewEditingEnabled", _
                  "�ҏW�ۂ̕ύX�O��Excel�C�x���g��~���m�F�ł��܂���ł����B " & _
                  eventDetail
    protectionMutationStarted = True
    ws.Unprotect Password:=TOOL_PASSWORD
    ws.Range("C3:D3").Locked = Not enabled
    ws.Range("C8:M8").Locked = Not enabled
    ProtectCashAnalysisViewSheet
    eventsReady = TryStopCashAnalysisEventsForRecovery(eventDetail)
    If Not eventsReady Then _
        Err.Raise vbObjectError + 5117, "SetCashAnalysisViewEditingEnabled", _
                  "����q�̕ی쏈�����Excel�C�x���g��~���m�F�ł��܂���ł����B " & _
                  eventDetail
    policyConfirmed = _
        CashAnalysisProtectionPolicyIsConfirmedExact(ws, policyDetail)
    If Not policyConfirmed Then _
        Err.Raise vbObjectError + 5117, "SetCashAnalysisViewEditingEnabled", _
                  "�ҏW�ۂ̕ύX��ɑS�ی�|���V�[��ǖ߂��m�F�ł��܂���ł����B " & _
                  policyDetail
    If workbookWasSaved Then ThisWorkbook.Saved = True
    If Not TryRestoreCashAnalysisEnableEvents( _
               entryEvents, "SetCashAnalysisViewEditingEnabled", eventDetail) Then _
        Err.Raise vbObjectError + 5118, "SetCashAnalysisViewEditingEnabled", eventDetail
    eventsCaptured = False
    Exit Sub
EH:
    errorNumber = Err.Number
    errorSource = Err.Source
    errorDescription = Err.Description
    If IsCashAnalysisRecoveryFatal(errorNumber, errorSource) Then
        Call TryStopCashAnalysisEventsForRecovery(convergenceDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    eventsReady = False
    If eventsCaptured Then _
        eventsReady = TryStopCashAnalysisEventsForRecovery(eventDetail)
    safeToRestoreEntry = Not protectionMutationStarted
    If eventsReady Then
        protectOK = TryProtectCashAnalysisViewAfterFailure( _
                        ws, "SetCashAnalysisViewEditingEnabled", True, _
                        recoveryDetail, protectionRecoveryAttempted, _
                        protectionRecoveryFailed, _
                        protectionRecoveryConfirmed)
        eventsReady = TryStopCashAnalysisEventsForRecovery(eventDetail)
        If Not protectionRecoveryFailed And eventsReady And protectOK Then
            policyConfirmed = _
                CashAnalysisProtectionPolicyIsConfirmedExact(ws, policyDetail)
            If Not policyConfirmed Then _
                AppendCashAnalysisRollbackDetail recoveryDetail, policyDetail
        Else
            policyConfirmed = False
        End If
        safeToRestoreEntry = eventsReady And _
            Not protectionRecoveryFailed And _
            (policyConfirmed Or protectionRecoveryConfirmed)
    End If
    If safeToRestoreEntry Then _
        safeToRestoreEntry = _
            CashAnalysisApplicationStateAllowsEntryRestore( _
                entryEvents, recoveryDetail)
    If safeToRestoreEntry Then
        eventsReady = _
            TryStopCashAnalysisEventsForRecovery(finalRecoveryStopDetail)
        safeToRestoreEntry = eventsReady
    End If
    If eventsReady And Not protectionRecoveryFailed Then
        On Error Resume Next
        Err.Clear
        If workbookWasSaved And policyConfirmed Then
            ThisWorkbook.Saved = True
            savedErrorNumber = Err.Number
            savedErrorDescription = Err.Description
            Err.Clear
        End If
        On Error GoTo 0
    Else
        AppendCashAnalysisRollbackDetail recoveryDetail, _
            "Excel�C�x���g��~���m�F�̂��߁A�ً}�ĕی�ƕۑ���Ԃ̏����݂��s���܂���ł����B"
    End If
    If savedErrorNumber <> 0 Then _
        AppendCashAnalysisRollbackDetail recoveryDetail, _
            "�u�b�N�ۑ���Ԃ̕����G���[: Err " & CStr(savedErrorNumber) & _
            " " & savedErrorDescription
    If eventsCaptured Then
        If safeToRestoreEntry Then
            eventsReady = TryStopCashAnalysisEventsForRecovery(eventDetail)
            safeToRestoreEntry = eventsReady
        End If
        If safeToRestoreEntry Then
            If Not TryRestoreCashAnalysisEnableEvents( _
                       entryEvents, _
                       "SetCashAnalysisViewEditingEnabled/�G���[�I��", _
                       eventDetail) Then
                AppendCashAnalysisRollbackDetail recoveryDetail, eventDetail
                safeToRestoreEntry = False
                eventsReady = _
                    TryStopCashAnalysisEventsForRecovery(convergenceDetail)
            End If
        ElseIf TryStopCashAnalysisEventsForRecovery(convergenceDetail) Then
            AppendCashAnalysisRollbackDetail recoveryDetail, _
                "�ĕی�܂���Recovery�������m�F�ł��Ȃ����߁A" & _
                "�J�n���C�x���g�l�֖߂���False�Œ�~���܂����B"
        Else
            AppendCashAnalysisRollbackDetail recoveryDetail, _
                "���S��Ԃ������m�F�ł����AExcel�C�x���g��False�����ɂ�" & _
                "���s���܂����B���ݏ�Ԃ͕s���ł�: " & convergenceDetail
        End If
    End If
    eventsCaptured = False
    If Len(recoveryDetail) > 0 Then _
        errorDescription = errorDescription & " / �����m�F: " & recoveryDetail
    If protectionRecoveryFailed Then _
        Err.Raise vbObjectError + 5194, _
                  "CashAnalysisRecoveryFatal/SetCashAnalysisViewEditingEnabled", _
                  errorDescription
    Err.Raise errorNumber, "SetCashAnalysisViewEditingEnabled", errorDescription
End Sub

Private Sub SelectFirstVisibleCashAnalysisRow(ByVal ws As Worksheet)
    Dim lastR As Long
    Dim visibleCells As Range
    lastR = CashAnalysisLastDataRow(ws)
    If lastR < CASH_VIEW_FIRST_DATA_ROW Then Exit Sub
    On Error Resume Next
    Set visibleCells = ws.Range(ws.Cells(CASH_VIEW_FIRST_DATA_ROW, 1), _
                                ws.Cells(lastR, 1)).SpecialCells(xlCellTypeVisible)
    On Error GoTo 0
    If Not visibleCells Is Nothing Then _
        SafeSelectCell ws, visibleCells.Cells(1, 1).Address(False, False)
End Sub

Private Function CashAnalysisLastDataRow(ByVal ws As Worksheet) As Long
    Dim lastByTx As Long, lastByDate As Long, lastByTekiyo As Long
    If ws Is Nothing Then Exit Function
    lastByTx = LastRow(ws, OUT_COL_TRANSACTION_ID)
    lastByDate = LastRow(ws, OUT_COL_DATE)
    lastByTekiyo = LastRow(ws, OUT_COL_TEKIYO)
    CashAnalysisLastDataRow = Application.Max(lastByTx, lastByDate, lastByTekiyo)
    If CashAnalysisLastDataRow < CASH_VIEW_FIRST_DATA_ROW Then CashAnalysisLastDataRow = 0
End Function

Private Function CashViewCategoryForResult(ByVal resultCategory As String) As String
    Select Case Trim$(resultCategory)
        Case "�g�r�s��": CashViewCategoryForResult = VIEW_CATEGORY_UNKNOWN_WITHDRAW
        Case "�����s��": CashViewCategoryForResult = VIEW_CATEGORY_UNKNOWN_DEPOSIT
        Case Else: CashViewCategoryForResult = VIEW_CATEGORY_TRANSFER
    End Select
End Function

Private Function IsCashViewCategory(ByVal categoryText As String) As Boolean
    IsCashViewCategory = (categoryText = VIEW_CATEGORY_TRANSFER Or _
                          categoryText = VIEW_CATEGORY_UNKNOWN_WITHDRAW Or _
                          categoryText = VIEW_CATEGORY_UNKNOWN_DEPOSIT)
End Function

Private Function IsCashViewMode(ByVal modeText As String) As Boolean
    IsCashViewMode = (modeText = VIEW_MODE_COMPONENT Or modeText = VIEW_MODE_RELATED Or _
                      modeText = VIEW_MODE_ALL)
End Function

Private Function ConfirmedStatusForCashCategory(ByVal categoryText As String) As String
    Select Case categoryText
        Case VIEW_CATEGORY_UNKNOWN_WITHDRAW
            ConfirmedStatusForCashCategory = ANALYSIS_STATUS_USE_CONFIRMED
        Case VIEW_CATEGORY_UNKNOWN_DEPOSIT
            ConfirmedStatusForCashCategory = ANALYSIS_STATUS_SOURCE_CONFIRMED
        Case Else
            ConfirmedStatusForCashCategory = ANALYSIS_STATUS_SHIFT_CONFIRMED
    End Select
End Function

Private Function IsStatusAllowedForCashCategory(ByVal categoryText As String, _
                                                ByVal statusText As String) As Boolean
    If statusText = ANALYSIS_STATUS_UNREVIEWED Or statusText = ANALYSIS_STATUS_EXCLUDED Or _
       statusText = ANALYSIS_STATUS_FOLLOWUP Then
        IsStatusAllowedForCashCategory = True
        Exit Function
    End If
    IsStatusAllowedForCashCategory = (statusText = ConfirmedStatusForCashCategory(categoryText))
End Function

Private Function CashViewRole(ByVal withdrawal As Double, ByVal deposit As Double) As String
    If withdrawal > 0 And deposit > 0 Then
        CashViewRole = VIEW_ROLE_BOTH
    ElseIf withdrawal > 0 Then
        CashViewRole = VIEW_ROLE_WITHDRAW
    ElseIf deposit > 0 Then
        CashViewRole = VIEW_ROLE_DEPOSIT
    End If
End Function

Private Function CashViewDouble(ByVal value As Variant) As Double
    If IsError(value) Or IsEmpty(value) Or Len(CellText(value)) = 0 Then Exit Function
    If IsNumeric(value) Then CashViewDouble = CDbl(value)
End Function

Private Function CashResultColumnValues(ByVal ws As Worksheet, ByVal firstRow As Long, _
                                        ByVal lastRow As Long, ByVal columnNumber As Long) As Variant
    Dim values As Variant
    If ws Is Nothing Or lastRow < firstRow Then Exit Function
    If lastRow = firstRow Then
        ReDim values(1 To 1, 1 To 1)
        values(1, 1) = ws.Cells(firstRow, columnNumber).Value2
    Else
        values = ws.Range(ws.Cells(firstRow, columnNumber), _
                          ws.Cells(lastRow, columnNumber)).Value2
    End If
    CashResultColumnValues = values
End Function

Private Function IDsToDictionary(ByVal idList As String) As Object
    Dim result As Object, parts As Variant, item As Variant, txID As String
    Set result = CreateObject("Scripting.Dictionary")
    result.CompareMode = vbTextCompare
    idList = Replace(Replace(idList, vbCrLf, ";"), vbLf, ";")
    idList = Replace(idList, ",", ";")
    If Len(Trim$(idList)) > 0 Then
        parts = Split(idList, ";")
        For Each item In parts
            txID = Trim$(CStr(item))
            If Len(txID) > 0 Then result(txID) = True
        Next item
    End If
    Set IDsToDictionary = result
End Function

Private Function JoinCashDictionaryKeys(ByVal values As Object) As String
    Dim item As Variant
    If values Is Nothing Then Exit Function
    For Each item In values.Keys
        If Len(JoinCashDictionaryKeys) > 0 Then JoinCashDictionaryKeys = JoinCashDictionaryKeys & ";"
        JoinCashDictionaryKeys = JoinCashDictionaryKeys & CStr(item)
    Next item
End Function

Private Function IDListContains(ByVal idList As String, ByVal wantedID As String) As Boolean
    Dim normalizedList As String, normalizedID As String
    normalizedID = Trim$(wantedID)
    If Len(normalizedID) = 0 Then Exit Function
    normalizedList = Replace(idList, vbCrLf, ";")
    normalizedList = Replace(normalizedList, vbCr, ";")
    normalizedList = Replace(normalizedList, vbLf, ";")
    normalizedList = Replace(normalizedList, ",", ";")
    normalizedList = Replace(normalizedList, " ", "")
    normalizedList = Replace(normalizedList, vbTab, "")
    normalizedID = Replace(normalizedID, " ", "")
    normalizedID = Replace(normalizedID, vbTab, "")
    normalizedList = ";" & normalizedList & ";"
    IDListContains = (InStr(1, normalizedList, ";" & normalizedID & ";", vbTextCompare) > 0)
End Function

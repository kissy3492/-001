﻿param(
    [string]$OutputPath = "",
    [switch]$SourceTestOnly
)

$ErrorActionPreference = "Stop"
$currentPhase = "startup"
$sourceDir = Split-Path -Parent $MyInvocation.MyCommand.Path
if ([string]::IsNullOrWhiteSpace($OutputPath)) {
    $OutputPath = Join-Path $sourceDir "cash_operation_input_tool.xlsm"
}
$OutputPath = [System.IO.Path]::GetFullPath($OutputPath)
$outputDir = [System.IO.Path]::GetDirectoryName($OutputPath)
$outputName = [System.IO.Path]::GetFileName($OutputPath)
$setupErrorPath = [System.IO.Path]::ChangeExtension($OutputPath, ".setup_error.txt")
$lockPath = $OutputPath + ".build.lock"
$buildLock = $null
$buildLockAcquired = $false
$stageDir = $null
$stagePath = $null
$diagnosticDir = $null
$published = $false
$stageSaved = $false
$setupInvoked = $false
$excel = $null
$workbooks = $null
$workbook = $null
$vbProject = $null
$vbComponents = $null
$thisWorkbookComponent = $null
$codeModule = $null
$escapedName = ""
$sourceTexts = @{}
$sourceManifestHash = ""
$buildId = ""
$expectedWorksheetNames = @()
$cleanupDetails = New-Object System.Collections.Generic.List[string]

function Convert-ToHex([byte[]]$Bytes) {
    return (($Bytes | ForEach-Object { $_.ToString("x2") }) -join "")
}

function Release-ComObject($Value) {
    if ($null -ne $Value -and [System.Runtime.InteropServices.Marshal]::IsComObject($Value)) {
        try {
            [void][System.Runtime.InteropServices.Marshal]::ReleaseComObject($Value)
        }
        catch {}
    }
}

function Add-WorkbookStringProperty($Workbook, [string]$Name, [string]$Value) {
    if ($null -eq $Workbook -or [string]::IsNullOrWhiteSpace($Name) -or
        [string]::IsNullOrWhiteSpace($Value)) {
        throw "A workbook build-identity property is incomplete: $Name"
    }
    $properties = $null
    $property = $null
    try {
        $properties = $Workbook.CustomDocumentProperties
        # msoPropertyTypeString = 4. Add must fail if a property of the same name
        # already exists; silently overwriting an unrelated identity is forbidden.
        $property = $properties.Add($Name, $false, 4, $Value)
        if (-not [string]::Equals([string]$property.Value, $Value,
                                  [System.StringComparison]::Ordinal)) {
            throw "Workbook build-identity property read-back mismatch: $Name"
        }
    }
    finally {
        Release-ComObject $property
        Release-ComObject $properties
    }
}

function Assert-WorkbookStringProperty($Workbook, [string]$Name, [string]$ExpectedValue) {
    if ($null -eq $Workbook -or [string]::IsNullOrWhiteSpace($Name) -or
        [string]::IsNullOrWhiteSpace($ExpectedValue)) {
        throw "A workbook build-identity assertion is incomplete: $Name"
    }
    $properties = $null
    $property = $null
    try {
        $properties = $Workbook.CustomDocumentProperties
        try { $property = $properties.Item($Name) }
        catch { throw "Workbook build-identity property is missing or unreadable: $Name / $($_.Exception.Message)" }
        if (-not [string]::Equals([string]$property.Value, $ExpectedValue,
                                  [System.StringComparison]::Ordinal)) {
            throw "Workbook build-identity property mismatch: $Name"
        }
    }
    finally {
        Release-ComObject $property
        Release-ComObject $properties
    }
}

function Set-WorkbookBuildIdentity($Workbook) {
    Add-WorkbookStringProperty $Workbook "COITBuildId" $script:buildId
    Add-WorkbookStringProperty $Workbook "COITSourceManifestSHA256" $script:sourceManifestHash
}

function Assert-WorkbookBuildIdentity($Workbook) {
    Assert-WorkbookStringProperty $Workbook "COITBuildId" $script:buildId
    Assert-WorkbookStringProperty $Workbook "COITSourceManifestSHA256" $script:sourceManifestHash
}

function Read-StrictCp932([string]$Path, [System.Text.Encoding]$Encoding) {
    [byte[]]$bytes = [System.IO.File]::ReadAllBytes($Path)
    if ($bytes.Length -eq 0) { throw "Source file is empty: $Path" }
    if (($bytes.Length -ge 3 -and $bytes[0] -eq 0xEF -and $bytes[1] -eq 0xBB -and $bytes[2] -eq 0xBF) -or
        ($bytes.Length -ge 2 -and (($bytes[0] -eq 0xFF -and $bytes[1] -eq 0xFE) -or
                                  ($bytes[0] -eq 0xFE -and $bytes[1] -eq 0xFF)))) {
        throw "Source must be BOM-less CP932: $Path"
    }
    $text = $Encoding.GetString($bytes)
    [byte[]]$roundTrip = $Encoding.GetBytes($text)
    $sourceBase64 = [Convert]::ToBase64String($bytes)
    $roundTripBase64 = [Convert]::ToBase64String($roundTrip)
    if (-not [string]::Equals($sourceBase64, $roundTripBase64,
                              [System.StringComparison]::Ordinal)) {
        throw "CP932 round-trip mismatch: $Path"
    }
    if ([regex]::IsMatch($text, "(?<!`r)`n|`r(?!`n)")) {
        throw "Source contains a non-CRLF line ending: $Path"
    }
    return $text
}

function Read-StrictUtf8BomCrLf([string]$Path) {
    [byte[]]$bytes = [System.IO.File]::ReadAllBytes($Path)
    if ($bytes.Length -le 3 -or
        $bytes[0] -ne 0xEF -or $bytes[1] -ne 0xBB -or $bytes[2] -ne 0xBF) {
        throw "PowerShell source must be UTF-8 with BOM: $Path"
    }
    $strictUtf8 = [System.Text.Encoding]::GetEncoding(
        65001,
        (New-Object System.Text.EncoderExceptionFallback),
        (New-Object System.Text.DecoderExceptionFallback))
    $text = $strictUtf8.GetString($bytes, 3, $bytes.Length - 3)
    [byte[]]$roundTrip = $strictUtf8.GetBytes($text)
    if (-not [string]::Equals(
            [Convert]::ToBase64String($bytes, 3, $bytes.Length - 3),
            [Convert]::ToBase64String($roundTrip),
            [System.StringComparison]::Ordinal)) {
        throw "PowerShell source is not strict UTF-8: $Path"
    }
    if ([regex]::IsMatch($text, "(?<!`r)`n|`r(?!`n)")) {
        throw "PowerShell source contains a non-CRLF line ending: $Path"
    }
    return $text
}

function Read-StrictAsciiCrLf([string]$Path) {
    [byte[]]$bytes = [System.IO.File]::ReadAllBytes($Path)
    if ($bytes.Length -eq 0) { throw "ASCII source file is empty: $Path" }
    foreach ($value in $bytes) {
        if ($value -gt 0x7F) { throw "Source must be ASCII: $Path" }
    }
    $text = [System.Text.Encoding]::ASCII.GetString($bytes)
    if ([regex]::IsMatch($text, "(?<!`r)`n|`r(?!`n)")) {
        throw "ASCII source contains a non-CRLF line ending: $Path"
    }
    return $text
}

function Test-VbaPhysicalLineLimits([string]$Text, [string]$Label) {
    $lines = [regex]::Split($Text, "`r`n")
    $continuationCount = 0
    for ($lineIndex = 0; $lineIndex -lt $lines.Count; $lineIndex++) {
        $line = [string]$lines[$lineIndex]
        if ($line.Length -gt 1023) {
            throw "VBA physical line exceeds 1023 characters: $Label line $($lineIndex + 1)"
        }
        $commentFreeLine = Remove-VbaLineComment $line
        if ($commentFreeLine -match '\s_\s*$' -and $line -notmatch '\s_\s*$') {
            throw "A VBA continuation cannot be followed by a comment: $Label line $($lineIndex + 1)"
        }
        if ($line -match '\s_\s*$') {
            $continuationCount++
            if ($continuationCount -gt 24) {
                throw "VBA statement exceeds 24 consecutive continuations: $Label line $($lineIndex + 1)"
            }
        }
        else {
            $continuationCount = 0
        }
    }
}

function Remove-VbaLineComment([string]$LineText) {
    if ($LineText -match '(?i)^\s*Rem(?:\s|$)') { return "" }
    $result = New-Object System.Text.StringBuilder
    $insideString = $false
    for ($charIndex = 0; $charIndex -lt $LineText.Length; $charIndex++) {
        $character = $LineText[$charIndex]
        if ($character -eq '"') {
            [void]$result.Append($character)
            if ($insideString -and $charIndex + 1 -lt $LineText.Length -and
                $LineText[$charIndex + 1] -eq '"') {
                [void]$result.Append($LineText[$charIndex + 1])
                $charIndex++
            }
            else {
                $insideString = -not $insideString
            }
        }
        elseif ($character -eq "'" -and -not $insideString) {
            break
        }
        else {
            [void]$result.Append($character)
        }
    }
    if ($insideString) { throw "Unbalanced VBA string literal: $LineText" }
    return $result.ToString()
}

function Test-SourcePackage {
    # Distribution completeness and encoding only. Business regression tests are
    # developer tools, not prerequisites for creating or using the workbook.
    $expectedModules = @(
        "modAdvancedFlowAnalysis.bas", "modAnalysisPolicy.bas", "modAnalysisReviewStore.bas", "modAnalysisWorkspace.bas",
        "modAppState.bas", "modBalanceReconciliation.bas", "modBuildOutputs.bas",
        "modCandidates.bas", "modCashAnalysisView.bas", "modClear.bas", "modConstants.bas",
        "modExternalImport.bas", "modFinalExport.bas", "modManualFlow.bas", "modNavigation.bas",
        "modPersonIntegrity.bas", "modRecords.bas", "modReleaseRegression.bas", "modSetup.bas", "modSetupLog.bas", "modShopConversion.bas",
        "modTransactionAnalysis.bas", "modTransfer.bas", "modUI.bas", "modUtilities.bas"
    )
    $script:expectedWorksheetNames = @(@(
        "設定", "入力", "摘要候補", "科目候補", "入力モード", "年入力方式候補",
        "表示切替候補", "転記後保持候補", "転記後処理候補", "銀行名候補", "支店名候補",
        "人物候補", "W_取引", "W_残高", "W_口座", "W_状態", "C_チェック",
        "登録済み口座", "資金操作表", "W_資金操作表", "残高推移表", "取扱店変換対象",
        "資金操作表_取扱店変換済", "資金シフト候補", "資金フロー追跡", "不明入出金",
        "分析結果", "候補詳細", "W_分析グループ", "W_分析判断台帳", "W_分析判断履歴",
        "W_手動資金候補", "分析確認候補", "残高検算", "W_セットアップログ"
    ) | Sort-Object)
    $actualModules = @(Get-ChildItem -LiteralPath $sourceDir -File -Filter "*.bas" |
                       Select-Object -ExpandProperty Name | Sort-Object)
    if (($actualModules -join "`n") -ne (@($expectedModules | Sort-Object) -join "`n")) {
        throw "VBA module files are missing or unexpected. Extract the complete ZIP into a new folder."
    }
    $encoding = [System.Text.Encoding]::GetEncoding(
        932, (New-Object System.Text.EncoderExceptionFallback),
        (New-Object System.Text.DecoderExceptionFallback))
    $script:sourceTexts = @{}
    foreach ($moduleFile in $expectedModules) {
        $text = Read-StrictCp932 (Join-Path $sourceDir $moduleFile) $encoding
        Test-VbaPhysicalLineLimits $text $moduleFile
        $moduleName = [System.IO.Path]::GetFileNameWithoutExtension($moduleFile)
        $attributes = [regex]::Matches($text, '(?m)^Attribute VB_Name = "([^"]+)"\r?$')
        if ($attributes.Count -ne 1 -or $attributes[0].Groups[1].Value -cne $moduleName) {
            throw "VBA module name does not match its filename: $moduleFile"
        }
        if ($text -notmatch '(?im)^Option Explicit\s*$') {
            throw "Option Explicit is missing: $moduleFile"
        }
        $script:sourceTexts[$moduleFile] = $text
    }
    $workbookText = Read-StrictCp932 (Join-Path $sourceDir "ThisWorkbook_code.txt") $encoding
    Test-VbaPhysicalLineLimits $workbookText "ThisWorkbook_code.txt"
    if ($workbookText -notmatch '(?im)^Option Explicit\s*$' -or
        $workbookText -notmatch '(?im)^Private Sub Workbook_Open\(\)\s*$') {
        throw "ThisWorkbook initialization code is missing."
    }
    $script:sourceTexts["ThisWorkbook_code.txt"] = $workbookText
    # All worksheet events are centralized in ThisWorkbook. Do not silently
    # discard executable code if a future edit adds it to the reference stub.
    $inputStub = Read-StrictCp932 (Join-Path $sourceDir "Sheet_Input_code.txt") $encoding
    foreach ($line in [regex]::Split($inputStub, "`r`n")) {
        $code = (Remove-VbaLineComment $line).Trim()
        if ($code.Length -gt 0 -and $code -ine "Option Explicit") {
            throw "Sheet_Input_code.txt contains code that must be explicitly integrated before generation."
        }
    }
    $null = Read-StrictUtf8BomCrLf (Join-Path $sourceDir "CREATE_TOOL.ps1")
    $null = Read-StrictAsciiCrLf (Join-Path $sourceDir "CREATE_TOOL.cmd")
    $sourceSetFiles = @("CREATE_TOOL.cmd", "CREATE_TOOL.ps1", "Sheet_Input_code.txt", "ThisWorkbook_code.txt") + $expectedModules
    $manifestLines = New-Object System.Collections.Generic.List[string]
    $sha256 = [System.Security.Cryptography.SHA256]::Create()
    try {
        foreach ($fileName in $sourceSetFiles) {
            $fileBytes = [System.IO.File]::ReadAllBytes((Join-Path $sourceDir $fileName))
            $fileHash = Convert-ToHex ($sha256.ComputeHash($fileBytes))
            $manifestLines.Add($fileHash + "  " + $fileName)
        }
        $manifestText = ($manifestLines -join "`n") + "`n"
        $script:sourceManifestHash = Convert-ToHex ($sha256.ComputeHash(
            [System.Text.Encoding]::UTF8.GetBytes($manifestText)))
        $script:buildId = "COIT-PRACTICAL/1:" + $script:sourceManifestHash
    }
    finally { $sha256.Dispose() }
}

function Assert-VbaFunction([string]$MacroName) {
    $result = $excel.Run("'$escapedName'!$MacroName")
    if (-not [System.Convert]::ToBoolean($result)) {
        $detail = [string]$excel.Run("'$escapedName'!GetLastSetupFailureDetail")
        throw "$MacroName failed: $detail"
    }
}

function Assert-WorkbookNotOpen([string]$Path) {
    $expectedPath = [System.IO.Path]::GetFullPath($Path)
    for ($workbookIndex = 1; $workbookIndex -le $workbooks.Count; $workbookIndex++) {
        $candidateWorkbook = $null
        try {
            $candidateWorkbook = $workbooks.Item($workbookIndex)
            $candidatePath = [System.IO.Path]::GetFullPath([string]$candidateWorkbook.FullName)
            if ([string]::Equals($candidatePath, $expectedPath,
                                 [System.StringComparison]::OrdinalIgnoreCase)) {
                throw "Workbook.Close did not close the staged workbook: $expectedPath"
            }
        }
        finally { Release-ComObject $candidateWorkbook }
    }
}

function Test-MacroWorkbookPackage([string]$Path) {
    if (-not [System.IO.File]::Exists($Path)) { throw "Workbook file is missing: $Path" }
    if ((Get-Item -LiteralPath $Path).Length -le 0) { throw "Workbook file is empty: $Path" }
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $archive = [System.IO.Compression.ZipFile]::OpenRead($Path)
    try {
        $entryNames = @($archive.Entries | ForEach-Object { $_.FullName })
        $vbaProjectEntry = $archive.GetEntry("xl/vbaProject.bin")
        if ($entryNames -notcontains "xl/vbaProject.bin" -or $null -eq $vbaProjectEntry) {
            throw "The generated workbook has no xl/vbaProject.bin."
        }
        if ($vbaProjectEntry.Length -le 0) { throw "The generated xl/vbaProject.bin is empty." }
        $contentTypeEntry = $archive.GetEntry("[Content_Types].xml")
        if ($null -eq $contentTypeEntry) { throw "[Content_Types].xml is missing." }
        $reader = New-Object System.IO.StreamReader($contentTypeEntry.Open())
        try { $contentTypes = $reader.ReadToEnd() } finally { $reader.Dispose() }
        if ($contentTypes -notmatch 'application/vnd\.ms-excel\.sheet\.macroEnabled\.main\+xml') {
            throw "The workbook content type is not macro-enabled."
        }
    }
    finally {
        $archive.Dispose()
    }
}

function Assert-NoDefaultSheetTemplate([object]$ExcelApplication) {
    $startupPath = [string]$ExcelApplication.StartupPath
    if ([string]::IsNullOrWhiteSpace($startupPath)) {
        throw "Excel did not report its XLSTART folder, so the default Sheet template could not be verified."
    }
    foreach ($templateName in @("Sheet.xlt", "Sheet.xltx", "Sheet.xltm")) {
        $templatePath = Join-Path $startupPath $templateName
        if ([System.IO.File]::Exists($templatePath)) {
            throw "A custom default Sheet template is active in XLSTART. Move it outside XLSTART and run CREATE_TOOL.cmd again."
        }
    }
}

function Test-IsAllowedGeneratedLocalName([string]$NameText) {
    if ([string]::IsNullOrWhiteSpace($NameText)) { return $false }
    $leafName = $NameText
    $separatorIndex = $leafName.LastIndexOf("!")
    if ($separatorIndex -ge 0) { $leafName = $leafName.Substring($separatorIndex + 1) }
    $leafName = $leafName.Trim("'")
    return [regex]::IsMatch(
        $leafName, '^(?:_xlnm\.)?(?:_FilterDatabase|Print_Area|Print_Titles)$',
        [System.Text.RegularExpressions.RegexOptions]::IgnoreCase)
}

function Test-IsBlankDocumentModule([object]$CodeModule) {
    if ($null -eq $CodeModule -or [int]$CodeModule.CountOfLines -eq 0) { return $true }
    $moduleText = [string]$CodeModule.Lines(1, $CodeModule.CountOfLines)
    $normalizedText = ($moduleText -replace "`r`n|`r|`n", "`n").Trim()
    if ([string]::IsNullOrWhiteSpace($normalizedText)) { return $true }
    return [regex]::IsMatch($normalizedText, '^Option\s+Explicit$',
                            [System.Text.RegularExpressions.RegexOptions]::IgnoreCase)
}

function Assert-CleanInitialWorkbook([object]$TargetWorkbook, [object]$Project) {
    $sheets = $null
    $worksheets = $null
    $workbookNames = $null
    $worksheet = $null
    $worksheetNames = $null
    $shapes = $null
    $listObjects = $null
    $hyperlinks = $null
    $queryTables = $null
    $usedRange = $null
    $worksheetFunction = $null
    $components = $null
    try {
        $sheets = $TargetWorkbook.Sheets
        $worksheets = $TargetWorkbook.Worksheets
        if ([int]$sheets.Count -ne 1 -or [int]$worksheets.Count -ne 1) {
            throw "The new workbook is not a clean one-worksheet workbook. Remove any default Sheet template from XLSTART and run CREATE_TOOL.cmd again."
        }

        $workbookNames = $TargetWorkbook.Names
        if ([int]$workbookNames.Count -ne 0) {
            throw "The new workbook contains inherited names. Remove any default Sheet template from XLSTART and run CREATE_TOOL.cmd again."
        }

        $worksheet = $worksheets.Item(1)
        $worksheetNames = $worksheet.Names
        if ([int]$worksheetNames.Count -ne 0) {
            throw "The new worksheet contains inherited local names. Remove any default Sheet template from XLSTART and run CREATE_TOOL.cmd again."
        }
        $shapes = $worksheet.Shapes
        $listObjects = $worksheet.ListObjects
        $hyperlinks = $worksheet.Hyperlinks
        $queryTables = $worksheet.QueryTables
        if ([int]$shapes.Count -ne 0 -or [int]$listObjects.Count -ne 0 -or
            [int]$hyperlinks.Count -ne 0 -or [int]$queryTables.Count -ne 0) {
            throw "The new worksheet contains inherited objects. Remove any default Sheet template from XLSTART and run CREATE_TOOL.cmd again."
        }

        $usedRange = $worksheet.UsedRange
        $usedAddress = [string]$usedRange.Address($true, $true, 1, $false)
        $worksheetFunction = $excel.WorksheetFunction
        $nonEmptyCellCount = [double]$worksheetFunction.CountA($usedRange)
        if ($usedAddress -ne '$A$1' -or $nonEmptyCellCount -ne 0) {
            throw "The new worksheet contains inherited cells or formatting. Remove any default Sheet template from XLSTART and run CREATE_TOOL.cmd again."
        }

        $components = $Project.VBComponents
        $expectedDocumentNames = @("ThisWorkbook", ([string]$worksheet.CodeName)) | Sort-Object
        $actualDocumentNames = New-Object System.Collections.Generic.List[string]
        for ($componentIndex = 1; $componentIndex -le $components.Count; $componentIndex++) {
            $component = $null
            $componentCode = $null
            try {
                $component = $components.Item($componentIndex)
                if ([int]$component.Type -ne 100) {
                    throw "The new workbook contains an inherited VBA component: $($component.Name). Remove any default macro-enabled Sheet template from XLSTART and run CREATE_TOOL.cmd again."
                }
                $actualDocumentNames.Add([string]$component.Name)
                $componentCode = $component.CodeModule
                if (-not (Test-IsBlankDocumentModule $componentCode)) {
                    throw "The new workbook contains inherited document-module code: $($component.Name). Remove any default macro-enabled Sheet template from XLSTART and run CREATE_TOOL.cmd again."
                }
            }
            finally {
                Release-ComObject $componentCode
                Release-ComObject $component
            }
        }
        if ((@($actualDocumentNames | Sort-Object) -join "`n") -ne
            (@($expectedDocumentNames) -join "`n")) {
            throw "The new workbook document-module set is not clean. Remove any default Sheet template from XLSTART and run CREATE_TOOL.cmd again."
        }
    }
    finally {
        Release-ComObject $components
        Release-ComObject $worksheetFunction
        Release-ComObject $usedRange
        Release-ComObject $queryTables
        Release-ComObject $hyperlinks
        Release-ComObject $listObjects
        Release-ComObject $shapes
        Release-ComObject $worksheetNames
        Release-ComObject $worksheet
        Release-ComObject $workbookNames
        Release-ComObject $worksheets
        Release-ComObject $sheets
    }
}

function Assert-GeneratedWorkbookStructureCore([object]$TargetWorkbook, [object]$Project,
                                                [string[]]$ExpectedStandardModules) {
    $sheets = $null
    $worksheets = $null
    $components = $null
    try {
        $sheets = $TargetWorkbook.Sheets
        $worksheets = $TargetWorkbook.Worksheets
        if ([int]$sheets.Count -ne $script:expectedWorksheetNames.Count -or
            [int]$worksheets.Count -ne $script:expectedWorksheetNames.Count) {
            throw "Generated workbook sheet count does not match the source contract."
        }

        $actualWorksheetNames = New-Object System.Collections.Generic.List[string]
        $expectedDocumentNames = New-Object System.Collections.Generic.List[string]
        $expectedDocumentNames.Add("ThisWorkbook")
        for ($worksheetIndex = 1; $worksheetIndex -le $worksheets.Count; $worksheetIndex++) {
            $worksheet = $null
            $localNames = $null
            try {
                $worksheet = $worksheets.Item($worksheetIndex)
                $actualWorksheetNames.Add([string]$worksheet.Name)
                $expectedDocumentNames.Add([string]$worksheet.CodeName)
                $localNames = $worksheet.Names
                for ($nameIndex = 1; $nameIndex -le $localNames.Count; $nameIndex++) {
                    $localName = $null
                    try {
                        $localName = $localNames.Item($nameIndex)
                        if (-not (Test-IsAllowedGeneratedLocalName ([string]$localName.Name))) {
                            throw "Generated worksheet contains an unexpected local name: $($worksheet.Name) / $($localName.Name)"
                        }
                    }
                    finally { Release-ComObject $localName }
                }
            }
            finally {
                Release-ComObject $localNames
                Release-ComObject $worksheet
            }
        }
        if ((@($actualWorksheetNames | Sort-Object) -join "`n") -ne
            ($script:expectedWorksheetNames -join "`n")) {
            throw "Generated workbook worksheet names do not match the source contract."
        }

        $components = $Project.VBComponents
        $actualStandardNames = New-Object System.Collections.Generic.List[string]
        $actualDocumentNames = New-Object System.Collections.Generic.List[string]
        for ($componentIndex = 1; $componentIndex -le $components.Count; $componentIndex++) {
            $component = $null
            $componentCode = $null
            try {
                $component = $components.Item($componentIndex)
                switch ([int]$component.Type) {
                    1 {
                        $actualStandardNames.Add([string]$component.Name)
                    }
                    100 {
                        $actualDocumentNames.Add([string]$component.Name)
                        if (-not [string]::Equals([string]$component.Name, "ThisWorkbook",
                                                  [System.StringComparison]::OrdinalIgnoreCase)) {
                            $componentCode = $component.CodeModule
                            if (-not (Test-IsBlankDocumentModule $componentCode)) {
                                throw "Generated worksheet document module contains unexpected code: $($component.Name)"
                            }
                        }
                    }
                    default {
                        throw "Generated VBA project contains an unexpected class, form, or component: $($component.Name) (type $($component.Type))"
                    }
                }
            }
            finally {
                Release-ComObject $componentCode
                Release-ComObject $component
            }
        }

        $expectedStandardNames = @($ExpectedStandardModules | Sort-Object)
        if ((@($actualStandardNames | Sort-Object) -join "`n") -ne
            ($expectedStandardNames -join "`n")) {
            throw "Generated standard-module set does not match the source manifest."
        }
        if ((@($actualDocumentNames | Sort-Object) -join "`n") -ne
            (@($expectedDocumentNames | Sort-Object) -join "`n")) {
            throw "Generated document-module set does not match the worksheet set."
        }
        if ([int]$components.Count -ne
            ($expectedStandardNames.Count + $expectedDocumentNames.Count)) {
            throw "Generated VBA project contains an unexpected component."
        }
    }
    finally {
        Release-ComObject $components
        Release-ComObject $worksheets
        Release-ComObject $sheets
    }
}

function Assert-GeneratedWorkbookStructure([object]$TargetWorkbook) {
    $project = $null
    try {
        $project = $TargetWorkbook.VBProject
        Assert-GeneratedWorkbookStructureCore $TargetWorkbook $project $expectedModuleNames
    }
    finally { Release-ComObject $project }
}

function Assert-ReopenedVbaProject {
    $project = $null
    $components = $null
    try {
        $project = $workbook.VBProject
        Assert-GeneratedWorkbookStructureCore $workbook $project $expectedModuleNames
        $components = $project.VBComponents
        $actualNames = New-Object System.Collections.Generic.List[string]
        for ($i = 1; $i -le $components.Count; $i++) {
            $component = $null
            try {
                $component = $components.Item($i)
                if ([int]$component.Type -eq 1) { $actualNames.Add([string]$component.Name) }
            }
            finally { Release-ComObject $component }
        }
        if ((@($actualNames | Sort-Object) -join "`n") -ne ($expectedModuleNames -join "`n")) {
            throw "Reopened VBA component set does not match the manifest."
        }
        foreach ($moduleName in $expectedModuleNames) {
            $component = $null
            $moduleCode = $null
            try {
                $component = $components.Item($moduleName)
                $moduleCode = $component.CodeModule
                $actual = ([string]$moduleCode.Lines(1, $moduleCode.CountOfLines) -replace "`r`n", "`n").TrimEnd()
                $visible = [regex]::Replace([string]$sourceTexts["$moduleName.bas"],
                                            '(?im)^Attribute\s+VB_Name\s*=\s*"[^"]+"\s*\r\n?', '')
                $expected = ($visible -replace "`r`n", "`n").TrimEnd()
                if (-not [string]::Equals($actual, $expected, [System.StringComparison]::Ordinal)) {
                    throw "Reopened code read-back mismatch for $moduleName."
                }
            }
            finally {
                Release-ComObject $moduleCode
                Release-ComObject $component
            }
        }
        $component = $null
        $moduleCode = $null
        try {
            $component = $components.Item("ThisWorkbook")
            $moduleCode = $component.CodeModule
            $actual = ([string]$moduleCode.Lines(1, $moduleCode.CountOfLines) -replace "`r`n", "`n").TrimEnd()
            $expected = ([string]$sourceTexts["ThisWorkbook_code.txt"] -replace "`r`n", "`n").TrimEnd()
            if (-not [string]::Equals($actual, $expected, [System.StringComparison]::Ordinal)) {
                throw "Reopened ThisWorkbook code read-back mismatch."
            }
        }
        finally {
            Release-ComObject $moduleCode
            Release-ComObject $component
        }
        $references = $null
        try {
            $references = $project.References
            for ($i = 1; $i -le $references.Count; $i++) {
                $reference = $null
                try {
                    $reference = $references.Item($i)
                    if ([System.Convert]::ToBoolean($reference.IsBroken)) {
                        throw "Broken VBA reference after reopen: $($reference.Name)"
                    }
                }
                finally { Release-ComObject $reference }
            }
        }
        finally { Release-ComObject $references }
    }
    finally {
        Release-ComObject $components
        Release-ComObject $project
    }
}

try {
    if ($SourceTestOnly) {
        $currentPhase = "source preflight"
        Test-SourcePackage
        Write-Host "Source preflight passed. Manifest SHA-256: $sourceManifestHash"
        Write-Host "Build ID: $buildId"
        Write-Host "No Excel process was started because SourceTestOnly was specified."
        return
    }

    $currentPhase = "output preflight"
    if ([System.IO.Path]::GetExtension($OutputPath) -ne ".xlsm") {
        throw "OutputPath must use the .xlsm extension: $OutputPath"
    }
    if ([System.IO.File]::Exists($OutputPath)) {
        throw "Output already exists. Move or rename it first: $OutputPath"
    }
    [void][System.IO.Directory]::CreateDirectory($outputDir)
    try {
        $buildLock = [System.IO.File]::Open($lockPath, [System.IO.FileMode]::OpenOrCreate,
                                           [System.IO.FileAccess]::Write, [System.IO.FileShare]::None)
        $buildLockAcquired = $true
    }
    catch {
        $lockError = $_.Exception.Message
        throw "Could not acquire the exclusive build lock for this output path: $OutputPath. Close another build if one is running, and verify write permission and free disk space. Original error: $lockError"
    }

    $currentPhase = "source preflight"
    Test-SourcePackage
    Write-Host "Source preflight passed. Manifest SHA-256: $sourceManifestHash"
    Write-Host "Build ID: $buildId"

    $stageDir = Join-Path $outputDir (".cashop-build-" + [Guid]::NewGuid().ToString("N"))
    [void][System.IO.Directory]::CreateDirectory($stageDir)
    $stagePath = Join-Path $stageDir $outputName

    $currentPhase = "Excel startup"
    $excel = New-Object -ComObject Excel.Application
    $excel.Visible = $false
    $excel.DisplayAlerts = $false
    $excel.EnableEvents = $false
    Assert-NoDefaultSheetTemplate $excel
    $workbooks = $excel.Workbooks
    $xlWBATWorksheet = -4167
    $workbook = $workbooks.Add($xlWBATWorksheet)

    $currentPhase = "VBA project access"
    $probeComponents = $null
    try {
        $vbProject = $workbook.VBProject
        $probeComponents = $vbProject.VBComponents
        $null = $probeComponents.Count
    }
    catch {
        $originalMessage = $_.Exception.Message
        $originalHResult = ('0x{0:X8}' -f ($_.Exception.HResult -band 0xffffffffL))
        throw "Excel could not access the VBA project. If Excel blocked programmatic access, enable 'Trust access to the VBA project object model', then run CREATE_TOOL.cmd again. Original error: $originalMessage (HRESULT $originalHResult)"
    }
    finally { Release-ComObject $probeComponents }

    $currentPhase = "blank workbook verification"
    Assert-CleanInitialWorkbook $workbook $vbProject

    $currentPhase = "VBA injection"
    $vbComponents = $vbProject.VBComponents
    $expectedModuleNames = @($sourceTexts.Keys | Where-Object { $_ -like "*.bas" } |
                             ForEach-Object { [System.IO.Path]::GetFileNameWithoutExtension($_) } | Sort-Object)
    foreach ($moduleName in $expectedModuleNames) {
        $moduleFile = "$moduleName.bas"
        $component = $null
        $moduleCode = $null
        try {
            $component = $vbComponents.Add(1)
            $component.Name = $moduleName
            if ($component.Name -ne $moduleName) { throw "VBE renamed module $moduleName to $($component.Name)." }
            $moduleCode = $component.CodeModule
            # Some VBE settings pre-populate a new module with Option Explicit.
            # Start from a truly empty CodeModule so the source read-back is deterministic.
            if ($moduleCode.CountOfLines -gt 0) {
                $moduleCode.DeleteLines(1, $moduleCode.CountOfLines)
            }
            $visibleCode = [regex]::Replace([string]$sourceTexts[$moduleFile],
                                            '(?im)^Attribute\s+VB_Name\s*=\s*"[^"]+"\s*\r\n?', '')
            $moduleCode.AddFromString($visibleCode)
            if ($moduleCode.CountOfLines -lt 2) { throw "No code was injected into $moduleName." }
            $readBack = $moduleCode.Lines(1, $moduleCode.CountOfLines)
            $expectedReadBack = ($visibleCode -replace "`r`n", "`n").TrimEnd()
            $actualReadBack = ([string]$readBack -replace "`r`n", "`n").TrimEnd()
            if (-not [string]::Equals($actualReadBack, $expectedReadBack,
                                      [System.StringComparison]::Ordinal)) {
                throw "Injected code read-back mismatch for $moduleName."
            }
        }
        finally {
            Release-ComObject $moduleCode
            Release-ComObject $component
        }
    }

    $thisWorkbookComponent = $vbComponents.Item("ThisWorkbook")
    $codeModule = $thisWorkbookComponent.CodeModule
    if ($codeModule.CountOfLines -gt 0) { $codeModule.DeleteLines(1, $codeModule.CountOfLines) }
    $codeModule.AddFromString([string]$sourceTexts["ThisWorkbook_code.txt"])
    $thisWorkbookReadBack = $codeModule.Lines(1, $codeModule.CountOfLines)
    $expectedThisWorkbookReadBack = ([string]$sourceTexts["ThisWorkbook_code.txt"] -replace "`r`n", "`n").TrimEnd()
    $actualThisWorkbookReadBack = ([string]$thisWorkbookReadBack -replace "`r`n", "`n").TrimEnd()
    if ($codeModule.CountOfLines -lt 2 -or
        -not [string]::Equals($actualThisWorkbookReadBack, $expectedThisWorkbookReadBack,
                              [System.StringComparison]::Ordinal)) {
        throw "ThisWorkbook code read-back failed."
    }

    $actualStandardModules = New-Object System.Collections.Generic.List[string]
    for ($index = 1; $index -le $vbComponents.Count; $index++) {
        $component = $null
        try {
            $component = $vbComponents.Item($index)
            if ([int]$component.Type -eq 1) { $actualStandardModules.Add([string]$component.Name) }
        }
        finally { Release-ComObject $component }
    }
    $actualStandardModules = @($actualStandardModules | Sort-Object)
    if (($actualStandardModules -join "`n") -ne ($expectedModuleNames -join "`n")) {
        throw "Injected VBA component set does not match the manifest."
    }

    $references = $null
    try {
        $references = $vbProject.References
        for ($index = 1; $index -le $references.Count; $index++) {
            $reference = $null
            try {
                $reference = $references.Item($index)
                if ([System.Convert]::ToBoolean($reference.IsBroken)) {
                    throw "Broken VBA reference: $($reference.Name)"
                }
            }
            finally { Release-ComObject $reference }
        }
    }
    finally { Release-ComObject $references }

    # Release all VBIDE wrappers before any close/reopen check. Lingering child COM
    # objects can keep the staged file locked even after Workbook.Close.
    Release-ComObject $codeModule; $codeModule = $null
    Release-ComObject $thisWorkbookComponent; $thisWorkbookComponent = $null
    Release-ComObject $vbComponents; $vbComponents = $null
    Release-ComObject $vbProject; $vbProject = $null

    $currentPhase = "staged workbook save"
    $xlOpenXmlWorkbookMacroEnabled = 52
    $workbook.SaveAs($stagePath, $xlOpenXmlWorkbookMacroEnabled)
    $stageSaved = $true
    if (-not [string]::Equals([System.IO.Path]::GetFullPath([string]$workbook.FullName),
                              [System.IO.Path]::GetFullPath($stagePath),
                              [System.StringComparison]::OrdinalIgnoreCase)) {
        throw "Excel saved the workbook to an unexpected path: $($workbook.FullName)"
    }
    if ([int]$workbook.FileFormat -ne $xlOpenXmlWorkbookMacroEnabled) {
        throw "Excel saved the staged workbook with an unexpected file format."
    }

    $currentPhase = "workbook build identity"
    Set-WorkbookBuildIdentity $workbook
    Assert-WorkbookBuildIdentity $workbook
    $workbook.Save()

    $currentPhase = "unattended setup"
    $excel.EnableEvents = $true
    $escapedName = $workbook.Name.Replace("'", "''")
    $setupInvoked = $true
    $null = $excel.Run("'$escapedName'!SetupWorkbook", $true)
    $setupDetail = [string]$excel.Run("'$escapedName'!GetLastSetupFailureDetail")
    if (-not [string]::IsNullOrWhiteSpace($setupDetail)) { throw "Setup failed: $setupDetail" }
    # SetupWorkbook already validates core data. Do not run the full developer
    # regression suite as part of normal generation.

    $currentPhase = "generated workbook structure"
    Assert-GeneratedWorkbookStructure $workbook

    $currentPhase = "post-save verification"
    $workbook.Save()
    if (-not [System.Convert]::ToBoolean($workbook.Saved)) {
        throw "Excel did not confirm the staged workbook save."
    }
    Assert-WorkbookBuildIdentity $workbook
    $eventErrorCount = [int]$excel.Run("'$escapedName'!GetWorkbookEventErrorCount")
    if ($eventErrorCount -ne 0) {
        throw "Workbook event verification recorded $eventErrorCount error(s) during setup/save."
    }
    $excel.EnableEvents = $false
    $workbook.Close($false)
    Assert-WorkbookNotOpen $stagePath
    Release-ComObject $workbook
    $workbook = $null
    Release-ComObject $workbooks
    $workbooks = $null
    $excel.Quit()
    Release-ComObject $excel
    $excel = $null
    [GC]::Collect()
    [GC]::WaitForPendingFinalizers()
    [GC]::Collect()
    [GC]::WaitForPendingFinalizers()

    $currentPhase = "reopen verification"
    # 保存時のExcel状態を持ち越さず、新しいExcelプロセス相当のApplicationで検査する。
    $excel = New-Object -ComObject Excel.Application
    $excel.Visible = $false
    $excel.DisplayAlerts = $false
    $excel.AutomationSecurity = 1
    # Workbook_Openを実際の利用時と同じイベント経路で通す。
    $excel.EnableEvents = $true
    $workbooks = $excel.Workbooks
    $missing = [Type]::Missing
    $workbook = $workbooks.Open($stagePath, 0, $false, $missing, $missing, $missing,
                                $true, $missing, $missing, $missing, $false, $missing,
                                $false, $missing, 0)
    if (-not [string]::Equals([System.IO.Path]::GetFullPath([string]$workbook.FullName),
                              [System.IO.Path]::GetFullPath($stagePath),
                              [System.StringComparison]::OrdinalIgnoreCase)) {
        throw "Excel reopened an unexpected workbook path: $($workbook.FullName)"
    }
    if ([System.Convert]::ToBoolean($workbook.ReadOnly)) {
        throw "The staged workbook reopened as read-only."
    }
    if ([int]$workbook.FileFormat -ne $xlOpenXmlWorkbookMacroEnabled) {
        throw "The reopened workbook format is not macro-enabled."
    }
    if (-not [System.Convert]::ToBoolean($workbook.Saved)) {
        throw "Excel reports unsaved or repaired content immediately after reopen."
    }
    Assert-WorkbookBuildIdentity $workbook
    Assert-ReopenedVbaProject
    $escapedName = $workbook.Name.Replace("'", "''")
    $openRestoreRunCount = [int]$excel.Run("'$escapedName'!GetOpenRestoreRunCount")
    if ($openRestoreRunCount -lt 1) {
        throw "Workbook_Open did not execute the shared restore path."
    }
    $eventErrorCount = [int]$excel.Run("'$escapedName'!GetWorkbookEventErrorCount")
    if ($eventErrorCount -ne 0) {
        throw "Workbook event verification recorded $eventErrorCount error(s) after reopen."
    }
    # Workbook_Open already ran the restore path. Verify core data once here;
    # do not repeat restoration, full-source read-back, or developer diagnostics.
    Assert-VbaFunction "BuildSmokeTest"
    $excel.EnableEvents = $false
    $workbook.Close($false)
    Assert-WorkbookNotOpen $stagePath
    Release-ComObject $workbook
    $workbook = $null

    $currentPhase = "package verification"
    Test-MacroWorkbookPackage $stagePath
    $finalHash = (Get-FileHash -LiteralPath $stagePath -Algorithm SHA256).Hash.ToLowerInvariant()

    $currentPhase = "Excel shutdown"
    $excel.Quit()
    Release-ComObject $codeModule; $codeModule = $null
    Release-ComObject $thisWorkbookComponent; $thisWorkbookComponent = $null
    Release-ComObject $vbComponents; $vbComponents = $null
    Release-ComObject $vbProject; $vbProject = $null
    Release-ComObject $workbooks; $workbooks = $null
    Release-ComObject $excel; $excel = $null
    [GC]::Collect()
    [GC]::WaitForPendingFinalizers()

    $currentPhase = "atomic publication"
    if ([System.IO.File]::Exists($OutputPath)) {
        throw "Another process created the final output during the build: $OutputPath"
    }
    if ([System.IO.File]::Exists($setupErrorPath)) {
        try { [System.IO.File]::Delete($setupErrorPath) }
        catch { throw "Could not remove the previous setup error report: $setupErrorPath / $($_.Exception.Message)" }
        if ([System.IO.File]::Exists($setupErrorPath)) {
            throw "The previous setup error report still exists: $setupErrorPath"
        }
    }
    [System.IO.File]::Move($stagePath, $OutputPath)
    $published = $true
    try { [System.IO.Directory]::Delete($stageDir, $false) } catch {}
    $stageDir = $null
    try {
        Write-Host "Workbook generated; save and reopen verification passed: $OutputPath"
        Write-Host "Workbook SHA-256: $finalHash"
        Write-Host "Build ID: $buildId"
        Write-Host "No incomplete workbook was published under the final filename."
    }
    catch {}
}
catch {
    $failureMessage = $_.Exception.Message
    $canSaveDiagnosticWorkbook = $false

    if ($null -ne $workbook -and $stageSaved -and
        -not [string]::IsNullOrWhiteSpace($stagePath) -and
        [System.IO.File]::Exists($stagePath)) {
        try {
            $workbookPath = [System.IO.Path]::GetFullPath([string]$workbook.FullName)
            $expectedStagePath = [System.IO.Path]::GetFullPath($stagePath)
            $canSaveDiagnosticWorkbook = [string]::Equals(
                $workbookPath, $expectedStagePath, [System.StringComparison]::OrdinalIgnoreCase)
            if (-not $canSaveDiagnosticWorkbook) {
                $cleanupDetails.Add("Diagnostic save skipped because the open workbook path did not match the staged path.")
            }
        }
        catch {
            $cleanupDetails.Add("Could not verify the staged workbook path: $($_.Exception.Message)")
        }
    }

    if ($null -ne $excel) {
        try { $excel.EnableEvents = $false }
        catch { $cleanupDetails.Add("Could not disable Excel events during cleanup: $($_.Exception.Message)") }
    }
    if ($null -ne $workbook -and $canSaveDiagnosticWorkbook -and $setupInvoked -and
        -not [string]::IsNullOrWhiteSpace([string]$escapedName)) {
        try {
            $inspectionPrepared = [System.Convert]::ToBoolean(
                $excel.Run("'$escapedName'!PrepareFailedSetupForInspection"))
            if (-not $inspectionPrepared) {
                $cleanupDetails.Add("PrepareFailedSetupForInspection returned False.")
            }
        }
        catch { $cleanupDetails.Add("Could not prepare the failed setup workbook for inspection: $($_.Exception.Message)") }
    }
    if ($null -ne $workbook -and $canSaveDiagnosticWorkbook) {
        try { $workbook.Save() }
        catch { $cleanupDetails.Add("Could not save the diagnostic staged workbook: $($_.Exception.Message)") }
    }

    # Release VBIDE children before closing Excel. They can otherwise retain a file lock.
    Release-ComObject $codeModule; $codeModule = $null
    Release-ComObject $thisWorkbookComponent; $thisWorkbookComponent = $null
    Release-ComObject $vbComponents; $vbComponents = $null
    Release-ComObject $vbProject; $vbProject = $null

    if ($null -ne $workbook) {
        try { $workbook.Close($false) }
        catch { $cleanupDetails.Add("Could not close the workbook: $($_.Exception.Message)") }
        if ($null -ne $workbooks -and -not [string]::IsNullOrWhiteSpace($stagePath)) {
            try { Assert-WorkbookNotOpen $stagePath }
            catch { $cleanupDetails.Add($_.Exception.Message) }
        }
    }
    Release-ComObject $workbook; $workbook = $null
    if ($null -ne $excel) {
        try { $excel.Quit() }
        catch { $cleanupDetails.Add("Could not quit Excel: $($_.Exception.Message)") }
    }
    Release-ComObject $workbooks; $workbooks = $null
    Release-ComObject $excel; $excel = $null
    [GC]::Collect()
    [GC]::WaitForPendingFinalizers()

    if (-not $published -and -not [string]::IsNullOrWhiteSpace($stageDir) -and
        [System.IO.Directory]::Exists($stageDir)) {
        if (-not [string]::IsNullOrWhiteSpace($stagePath) -and [System.IO.File]::Exists($stagePath)) {
            $stamp = [DateTime]::Now.ToString("yyyyMMdd_HHmmss")
            $diagnosticDir = Join-Path $outputDir (".cashop-failed-" + $stamp + "-" + [Guid]::NewGuid().ToString("N").Substring(0, 8))
            try { [System.IO.Directory]::Move($stageDir, $diagnosticDir) }
            catch {
                $cleanupDetails.Add("Could not move the failed build folder: $($_.Exception.Message)")
                $diagnosticDir = $stageDir
            }
        }
        else {
            try { [System.IO.Directory]::Delete($stageDir, $true) }
            catch { $cleanupDetails.Add("Could not remove the empty staging folder: $($_.Exception.Message)") }
        }
    }

    $cleanupText = if ($cleanupDetails.Count -gt 0) {
        ($cleanupDetails | ForEach-Object { "- $_" }) -join [Environment]::NewLine
    }
    else {
        "- Cleanup completed without an additional error."
    }
    $diagnosticText = @(
        "Tool creation failed.",
        "Phase: $currentPhase",
        "Error: $failureMessage",
        "Final output: $OutputPath",
        "Final output published: $published",
        "Diagnostic build folder: $diagnosticDir",
        "Source manifest SHA-256: $sourceManifestHash",
        "Build ID: $buildId",
        "Cleanup details:",
        $cleanupText,
        "Important: no failed workbook is intentionally published under the final filename."
    ) -join [Environment]::NewLine
    $sidecarWritten = $false
    if ($buildLockAcquired -and $null -ne $buildLock -and -not $published) {
        try {
            $utf8WithBom = New-Object System.Text.UTF8Encoding($true)
            [System.IO.File]::WriteAllText($setupErrorPath, $diagnosticText, $utf8WithBom)
            $sidecarWritten = [System.IO.File]::Exists($setupErrorPath) -and
                              ((Get-Item -LiteralPath $setupErrorPath).Length -gt 0)
        }
        catch {
            [Console]::Error.WriteLine("Could not write the error-details file: $($_.Exception.Message)")
        }
    }
    [Console]::Error.WriteLine("Tool creation failed during '$currentPhase': $failureMessage")
    if (-not [string]::IsNullOrWhiteSpace($diagnosticDir)) {
        [Console]::Error.WriteLine("Diagnostic build folder: $diagnosticDir")
    }
    if ($sidecarWritten) {
        [Console]::Error.WriteLine("Error details: $setupErrorPath")
    }
    elseif ($published) {
        [Console]::Error.WriteLine("No shared error-details file was written after the verified final output had already been published.")
    }
    elseif (-not $buildLockAcquired) {
        [Console]::Error.WriteLine("No shared error-details file was written because this process did not own the output build lock.")
    }
    else {
        [Console]::Error.WriteLine("The error-details file could not be created.")
    }
    exit 1
}
finally {
    if ($null -ne $excel) { try { $excel.EnableEvents = $false } catch {} }
    Release-ComObject $codeModule
    Release-ComObject $thisWorkbookComponent
    Release-ComObject $vbComponents
    Release-ComObject $vbProject
    if ($null -ne $workbook) { try { $workbook.Close($false) } catch {} }
    if ($null -ne $excel) { try { $excel.Quit() } catch {} }
    Release-ComObject $workbook
    Release-ComObject $workbooks
    Release-ComObject $excel
    if ($null -ne $buildLock) {
        try { $buildLock.Dispose() } catch {}
        $buildLock = $null
    }
    # 自分が排他取得したロックだけを削除する。出力既存・権限不足・他ビルド稼働中など、
    # 取得前に失敗したプロセスが他者のロックファイルを片付けてはならない。
    if ($buildLockAcquired -and
        -not [string]::IsNullOrWhiteSpace($lockPath) -and
        [System.IO.File]::Exists($lockPath)) {
        try { [System.IO.File]::Delete($lockPath) } catch {}
    }
}

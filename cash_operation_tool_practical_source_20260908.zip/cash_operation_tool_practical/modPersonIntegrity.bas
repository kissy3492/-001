Attribute VB_Name = "modPersonIntegrity"
Option Explicit

Private Const PERSON_INTEGRITY_DETAIL_LIMIT As Long = 30000
Private Const BALANCE_PERSON_NAME_COLUMN As Long = 1
Private Const PERSON_CANDIDATE_DATA_ROW_LIMIT As Long = 100000
Private Const PERSON_INTEGRITY_CAPACITY_BASE_COLUMNS As Long = 16
Private Const PERSON_INTEGRITY_CAPACITY_SNAPSHOT_COPIES As Double = 3#
Private Const PERSON_INTEGRITY_CAPACITY_LONG_MAX As Double = 2147483647#

Private mLastPersonIntegrityRegressionFailure As String

Public Function RequireCorePersonIntegrityCapacity( _
        ByVal operationName As String, _
        Optional ByVal capacityAlreadyConfirmed As Boolean = False, _
        Optional ByVal includePersonCandidates As Boolean = True) As Boolean
    Dim accountRows As Long, transactionRows As Long
    Dim balanceRows As Long, personRows As Long
    Dim workRows As Double

    If capacityAlreadyConfirmed Then
        RequireCorePersonIntegrityCapacity = True
        Exit Function
    End If
    If Len(Trim$(operationName)) = 0 Then operationName = "�����f�[�^�̐l������������"
    If Not SheetExists(SH_WORK_ACCOUNT) Or Not SheetExists(SH_WORK_TX) Or _
       Not SheetExists(SH_WORK_BAL) Then _
        Err.Raise vbObjectError + 6307, "RequireCorePersonIntegrityCapacity", _
                  "�l�������������ɕK�v�ȓ����f�[�^�V�[�g���s�����Ă��܂��B"
    If includePersonCandidates And Not SheetExists(SH_PERSON_CAND) Then _
        Err.Raise vbObjectError + 6307, "RequireCorePersonIntegrityCapacity", _
                  "�l�������܂ސ����������ɕK�v�ȃV�[�g���s�����Ă��܂��B"

    accountRows = CorePersonIntegrityDataRows( _
                      GetSheet(SH_WORK_ACCOUNT), ACC_COL_TRANSFER_ID)
    transactionRows = CorePersonIntegrityDataRows( _
                          GetSheet(SH_WORK_TX), WORK_TX_COL_PERSON_ID)
    balanceRows = CorePersonIntegrityDataRows( _
                      GetSheet(SH_WORK_BAL), WORK_BAL_COL_PERSON_ID)
    If includePersonCandidates Then _
        personRows = CorePersonIntegrityDataRows(GetSheet(SH_PERSON_CAND), 4)
    workRows = CorePersonIntegrityCapacityWorkRows( _
                   accountRows, transactionRows, balanceRows, personRows)
    If workRows > PERSON_INTEGRITY_CAPACITY_LONG_MAX Then _
        Err.Raise vbObjectError + 6308, "RequireCorePersonIntegrityCapacity", _
                  "�l�������������̈��S�e�ʂ�Long�^�֕ϊ��ł��܂���B"
    RequireCorePersonIntegrityCapacity = ConfirmLargeArrayOperation( _
        CLng(workRows), operationName & "�i����4�ۊǂ̔z�񌟍��j")
End Function

Private Function CorePersonIntegrityDataRows(ByVal ws As Worksheet, _
                                             ByVal lastColumn As Long) As Long
    Dim lastDataRow As Long
    If ws Is Nothing Or lastColumn < 1 Then _
        Err.Raise vbObjectError + 6307, "CorePersonIntegrityDataRows", _
                  "�l�������������̍s�����擾�ł��܂���B"
    lastDataRow = LastDataRowInColumns(ws, 1, lastColumn)
    If lastDataRow > 1 Then CorePersonIntegrityDataRows = lastDataRow - 1
End Function

Private Function CorePersonIntegrityCapacityWorkRows( _
        ByVal accountRows As Long, ByVal transactionRows As Long, _
        ByVal balanceRows As Long, ByVal personRows As Long) As Double
    Dim cellWork As Double
    If accountRows < 0 Or transactionRows < 0 Or _
       balanceRows < 0 Or personRows < 0 Then _
        Err.Raise vbObjectError + 6308, "CorePersonIntegrityCapacityWorkRows", _
                  "�l�������������̗e�ʌv��ɕ������܂܂�Ă��܂��B"
    cellWork = PERSON_INTEGRITY_CAPACITY_SNAPSHOT_COPIES * _
               (CDbl(accountRows) * CDbl(ACC_COL_TRANSFER_ID) + _
                CDbl(transactionRows) * CDbl(WORK_TX_COL_PERSON_ID) + _
                CDbl(balanceRows) * CDbl(WORK_BAL_COL_PERSON_ID) + _
                CDbl(personRows) * 4#)
    CorePersonIntegrityCapacityWorkRows = _
        CorePersonIntegrityEquivalentWorkRows(cellWork)
End Function

Private Function CorePersonIntegrityEquivalentWorkRows( _
        ByVal cellWork As Double) As Double
    Dim workRows As Double
    If cellWork < 0# Or _
       cellWork > PERSON_INTEGRITY_CAPACITY_LONG_MAX * _
                  CDbl(PERSON_INTEGRITY_CAPACITY_BASE_COLUMNS) Then _
        Err.Raise vbObjectError + 6308, _
                  "CorePersonIntegrityEquivalentWorkRows", _
                  "�l�������������̈��S�e�ʂ�16�񑊓��Ɋ��Z�ł��܂���B"
    workRows = Int((cellWork + _
                    CDbl(PERSON_INTEGRITY_CAPACITY_BASE_COLUMNS) - 1#) / _
                   CDbl(PERSON_INTEGRITY_CAPACITY_BASE_COLUMNS))
    If workRows < 0# Or workRows > PERSON_INTEGRITY_CAPACITY_LONG_MAX Then _
        Err.Raise vbObjectError + 6308, _
                  "CorePersonIntegrityEquivalentWorkRows", _
                  "�l�������������̈��S�e�ʂ�Long�^�̏���𒴂��Ă��܂��B"
    CorePersonIntegrityEquivalentWorkRows = workRows
End Function

Public Function PersonIntegrityCapacityRegressionTest() As Boolean
    Dim capturedErrorNumber As Long
    Dim workRows As Double
    On Error GoTo Failed
    If CorePersonIntegrityCapacityWorkRows(0, 0, 0, 0) <> 0# Then Exit Function
    If CorePersonIntegrityCapacityWorkRows(1, 0, 0, 0) <> 3# Then Exit Function
    If CorePersonIntegrityCapacityWorkRows(0, 1, 0, 0) <> 4# Then Exit Function
    If CorePersonIntegrityCapacityWorkRows(0, 0, 1, 0) <> 4# Then Exit Function
    If CorePersonIntegrityCapacityWorkRows(0, 0, 0, 1) <> 1# Then Exit Function
    If CorePersonIntegrityCapacityWorkRows(1, 1, 1, 1) <> 11# Then Exit Function
    If CorePersonIntegrityCapacityWorkRows(1000, 10000, 10000, 500) <> 74063# Then _
        Exit Function
    If CorePersonIntegrityEquivalentWorkRows(15#) <> 1# Then Exit Function
    If CorePersonIntegrityEquivalentWorkRows(16#) <> 1# Then Exit Function
    If CorePersonIntegrityEquivalentWorkRows(17#) <> 2# Then Exit Function
    If CorePersonIntegrityEquivalentWorkRows(34359738352#) <> 2147483647# Then _
        Exit Function
    capturedErrorNumber = 0
    On Error Resume Next
    workRows = CorePersonIntegrityCapacityWorkRows(-1, 0, 0, 0)
    capturedErrorNumber = Err.Number
    Err.Clear
    On Error GoTo Failed
    If capturedErrorNumber <> vbObjectError + 6308 Then Exit Function
    capturedErrorNumber = 0
    On Error Resume Next
    workRows = CorePersonIntegrityEquivalentWorkRows(34359738353#)
    capturedErrorNumber = Err.Number
    Err.Clear
    On Error GoTo Failed
    If capturedErrorNumber <> vbObjectError + 6308 Then Exit Function
    PersonIntegrityCapacityRegressionTest = True
    Exit Function
Failed:
    PersonIntegrityCapacityRegressionTest = False
End Function

'W_������B��̐��{�Ƃ��āAW_����EW_�c���ɕ������ꂽ�l��������������B
'���̊֐��̓V�[�g��ǂݎ�邾���ŁA�I���A�\���A�����݁A���b�Z�[�W�\�����s��Ȃ��B
Public Function ValidateCorePersonIntegrity(ByRef problems As String, _
                                            Optional ByVal includePersonCandidates As Boolean = True) As Boolean
    Dim storeProblems As String
    On Error GoTo Failed
    problems = vbNullString

    If Not SheetExists(SH_WORK_ACCOUNT) Then _
        AppendPersonIntegrityProblem problems, "W_����������܂���B"
    If Not SheetExists(SH_WORK_TX) Then _
        AppendPersonIntegrityProblem problems, "W_���������܂���B"
    If Not SheetExists(SH_WORK_BAL) Then _
        AppendPersonIntegrityProblem problems, "W_�c��������܂���B"
    If includePersonCandidates And Not SheetExists(SH_PERSON_CAND) Then _
        AppendPersonIntegrityProblem problems, "�l����₪����܂���B"
    If Len(problems) > 0 Then Exit Function

    If Not ValidateCorePersonStoreSafety(storeProblems, includePersonCandidates) Then
        AppendPersonIntegrityProblem problems, storeProblems
        Exit Function
    End If

    ValidateCorePersonIntegrity = _
        ValidatePersonIntegritySheetsSequentially(problems, includePersonCandidates)
    Exit Function
Failed:
    problems = vbNullString
    AppendPersonIntegrityProblem problems, _
        "�l�������������������ł��܂���iErr " & CStr(Err.Number) & "�j: " & Err.Description
    ValidateCorePersonIntegrity = False
End Function

'�z�񂾂�����͂Ƃ��鏃���Ȍ����{�́B��A����������V�[�g��ύX�����ɌĂяo����B
'�e�z��͖{�ԃV�[�g�Ɠ���1�n�܂�E������ԍ��ł��邱�Ƃ��_��Ƃ���B
'����E�c���̑��������͐l�����S���Q�[�g�̔���ΏۂɊ܂߂Ȃ��B
'�������l��ID�̎��������_��ɍ��킹�AW_�����Ő��K����̎����{�����������Ȃ�
'�����l��ID�łȂ���΂Ȃ�Ȃ��B�ʐl���͈قȂ鎁���œo�^����^�p�Ƃ���B
Public Function ValidatePersonIntegrityFixture(ByRef accountData As Variant, _
                                                ByRef transactionData As Variant, _
                                                ByRef balanceData As Variant, _
                                                ByRef problems As String) As Boolean
    Dim accountFirstRow As Long, accountLastRow As Long, accountHasRows As Boolean
    Dim transactionFirstRow As Long, transactionLastRow As Long, transactionHasRows As Boolean
    Dim balanceFirstRow As Long, balanceLastRow As Long, balanceHasRows As Boolean
    Dim personIDByAccount As Object, personNameByAccount As Object
    Dim accountSourceRowByID As Object
    Dim personIDByIdentity As Object, identitySourceRow As Object
    Dim relationshipByPersonID As Object, relationshipSourceByPersonID As Object

    On Error GoTo Failed
    problems = vbNullString
    If Not TryPersonIntegrityMatrixBounds(accountData, ACC_COL_TRANSFER_ID, "W_����", _
                                           accountFirstRow, accountLastRow, accountHasRows, problems) Then _
        Exit Function
    If Not TryPersonIntegrityMatrixBounds(transactionData, WORK_TX_COL_PERSON_ID, "W_���", _
                                           transactionFirstRow, transactionLastRow, _
                                           transactionHasRows, problems) Then Exit Function
    If Not TryPersonIntegrityMatrixBounds(balanceData, WORK_BAL_COL_PERSON_ID, "W_�c��", _
                                           balanceFirstRow, balanceLastRow, balanceHasRows, problems) Then _
        Exit Function

    Set personIDByAccount = NewPersonIntegrityDictionary()
    Set personNameByAccount = NewPersonIntegrityDictionary()
    Set accountSourceRowByID = NewPersonIntegrityDictionary()
    Set personIDByIdentity = NewPersonIntegrityDictionary()
    Set identitySourceRow = NewPersonIntegrityDictionary()
    Set relationshipByPersonID = NewPersonIntegrityDictionary()
    Set relationshipSourceByPersonID = NewPersonIntegrityDictionary()

    If accountHasRows Then
        ValidatePersonIntegrityAccounts accountData, accountFirstRow, accountLastRow, _
                                        personIDByAccount, personNameByAccount, _
                                        accountSourceRowByID, personIDByIdentity, _
                                        identitySourceRow, relationshipByPersonID, _
                                        relationshipSourceByPersonID, problems
    End If
    If transactionHasRows Then
        ValidatePersonIntegrityLinkedRows transactionData, transactionFirstRow, transactionLastRow, _
                                          "W_���", WORK_TX_COL_ACCOUNT_ID, _
                                          WORK_TX_COL_PERSON_ID, OUT_COL_PERSON, _
                                          personIDByAccount, personNameByAccount, _
                                          accountSourceRowByID, problems
    End If
    If balanceHasRows Then
        ValidatePersonIntegrityLinkedRows balanceData, balanceFirstRow, balanceLastRow, _
                                          "W_�c��", WORK_BAL_COL_ACCOUNT_ID, _
                                          WORK_BAL_COL_PERSON_ID, BALANCE_PERSON_NAME_COLUMN, _
                                          personIDByAccount, personNameByAccount, _
                                          accountSourceRowByID, problems
    End If

    ValidatePersonIntegrityFixture = (Len(problems) = 0)
    Exit Function
Failed:
    problems = vbNullString
    AppendPersonIntegrityProblem problems, _
        "�l��������fixture�����������ł��܂���iErr " & CStr(Err.Number) & "�j: " & Err.Description
    ValidatePersonIntegrityFixture = False
End Function

Public Function PersonIntegrityRegressionTest() As Boolean
    Dim accountData As Variant, transactionData As Variant, balanceData As Variant
    Dim candidateData As Variant
    Dim emptyAccountData As Variant, emptyTransactionData As Variant, emptyBalanceData As Variant
    Dim malformedAccountData As Variant
    On Error GoTo Failed
    mLastPersonIntegrityRegressionFailure = vbNullString

    If Not PersonIntegrityCapacityRegressionTest() Then
        mLastPersonIntegrityRegressionFailure = _
            "�l�������������̗e�ʌv��fixture�Ɏ��s���܂����B"
        Exit Function
    End If

    SeedPersonIntegrityFixture accountData, transactionData, balanceData
    If Not PersonIntegrityCasePasses("����E�ʐl�������e", True, vbNullString, _
                                     accountData, transactionData, balanceData) Then Exit Function

    SeedPersonIntegrityFixture accountData, transactionData, balanceData
    accountData(1, ACC_COL_PERSON) = Empty
    If Not PersonIntegrityCasePasses("�������`�l����", False, "W_���� 2�s: �������`�l�Ȃ�", _
                                     accountData, transactionData, balanceData) Then Exit Function

    SeedPersonIntegrityFixture accountData, transactionData, balanceData
    accountData(1, ACC_COL_PERSON) = vbTab & vbCrLf & ChrW(160)
    If Not PersonIntegrityCasePasses("�������`�l���󔒐��䕶���̂�", False, _
                                     "W_���� 2�s: �������`�l�Ȃ�", _
                                     accountData, transactionData, balanceData) Then Exit Function

    SeedPersonIntegrityFixture accountData, transactionData, balanceData
    accountData(1, ACC_COL_PERSON_ID) = Empty
    If Not PersonIntegrityCasePasses("�����l��ID����", False, "W_���� 2�s: �l��ID�Ȃ�", _
                                     accountData, transactionData, balanceData) Then Exit Function

    SeedPersonIntegrityFixture accountData, transactionData, balanceData
    accountData(1, ACC_COL_PERSON_ID) = "X1"
    If Not PersonIntegrityCasePasses("�����l��ID�`���s��", False, "�l��ID�`���s�� X1", _
                                     accountData, transactionData, balanceData) Then Exit Function

    SeedPersonIntegrityFixture accountData, transactionData, balanceData
    accountData(1, ACC_COL_ID) = "X1"
    If Not PersonIntegrityCasePasses("����ID�`���s��", False, "����ID�`���s�� X1", _
                                     accountData, transactionData, balanceData) Then Exit Function

    SeedPersonIntegrityFixture accountData, transactionData, balanceData
    accountData(2, ACC_COL_ID) = "A1"
    If Not PersonIntegrityCasePasses("����ID�d��", False, "����ID�d�� A1", _
                                     accountData, transactionData, balanceData) Then Exit Function

    SeedPersonIntegrityFixture accountData, transactionData, balanceData
    accountData(2, ACC_COL_PERSON) = "�b"
    accountData(2, ACC_COL_RELATIONSHIP) = "�{�l"
    transactionData(2, OUT_COL_PERSON) = "�b"
    transactionData(2, WORK_TX_COL_RELATIONSHIP) = "�{�l"
    balanceData(2, BALANCE_PERSON_NAME_COLUMN) = "�b"
    balanceData(2, WORK_BAL_COL_RELATIONSHIP) = "�{�l"
    If Not PersonIntegrityCasePasses("���������E�����̕ʐl��ID������", False, _
                                     "���������E�����ɈقȂ�l��ID", _
                                     accountData, transactionData, balanceData) Then Exit Function

    'W_���������łȂ��l�����Ƃ̉��f�������A�ʏ�̓o�^�E���͑O�Q�[�g�ŋ��ۂ���B
    SeedPersonIntegrityFixture accountData, transactionData, balanceData
    ReDim candidateData(1 To 1, 1 To 3)
    candidateData(1, 1) = "�b"
    candidateData(1, 2) = "P1"
    candidateData(1, 3) = "�{�l"
    If Not PersonCandidateIntegrityCasePasses( _
            "�l�����̓���l��ID�ė��p", True, vbNullString, _
            accountData, candidateData) Then Exit Function

    '���͌��͈̖͂����ɂ́A�����E���͋K������������s���܂܂꓾��B
    '��̓��ꐫ�L�[��Dictionary�֒ǉ�������A���f�[�^�j���Ƃ��Ĉ���Ȃ��B
    ReDim candidateData(1 To 2, 1 To 3)
    candidateData(1, 1) = "�b"
    candidateData(1, 2) = "P1"
    candidateData(1, 3) = "�{�l"
    If Not PersonCandidateIntegrityCasePasses( _
            "�l�����̖�����s�𖳎�", True, vbNullString, _
            accountData, candidateData) Then Exit Function

    ReDim candidateData(1 To 1, 1 To 3)

    candidateData(1, 1) = "�ʖ��`"
    candidateData(1, 3) = "�z���"
    If Not PersonCandidateIntegrityCasePasses( _
            "�l�����̓���l��ID�E�قȂ鑱��������", False, _
            "����l��ID�ɈقȂ鑱��", accountData, candidateData) Then Exit Function

    candidateData(1, 2) = "P2"
    candidateData(1, 1) = "�b"
    candidateData(1, 3) = "�{�l"
    If Not PersonCandidateIntegrityCasePasses( _
            "�l�����̓��������E�����ɕ�ID������", False, _
            "���������E�����ɈقȂ�l��ID", accountData, candidateData) Then Exit Function

    candidateData(1, 1) = "��"
    candidateData(1, 3) = "�z���"
    If Not PersonCandidateIntegrityCasePasses( _
            "�l�����̕ʐl�������e", True, vbNullString, _
            accountData, candidateData) Then Exit Function

    candidateData(1, 1) = "�b"
    candidateData(1, 2) = vbNullString
    candidateData(1, 3) = "�{�l"
    If Not PersonCandidateIntegrityCasePasses( _
            "�l������ID�Ȃ��EID�t���d��������", False, _
            "�l��ID�t�����Əd��", accountData, candidateData) Then Exit Function

    candidateData(1, 1) = "��"
    candidateData(1, 3) = "�z���"
    If Not PersonCandidateIntegrityCasePasses( _
            "�l�����̖��o�^�ʐl�������e", True, vbNullString, _
            accountData, candidateData) Then Exit Function

    ReDim candidateData(1 To 2, 1 To 3)
    candidateData(1, 1) = "��"
    candidateData(1, 3) = "�z���"
    candidateData(2, 1) = " �� "
    candidateData(2, 3) = " �z �� �� "
    If Not PersonCandidateIntegrityCasePasses( _
            "�l�����̐l��ID�Ȃ��d��������", False, _
            "�l��ID�Ȃ���₪�d��", accountData, candidateData) Then Exit Function

    If Not PersonIDResolverRegressionTest() Then
        mLastPersonIntegrityRegressionFailure = _
            "�����{�����ɂ��l��ID�����ė��p�̎��s��A�Ɏ��s���܂����B"
        Exit Function
    End If
    If Not CandidateRelationshipConvergenceRegressionTest() Then
        mLastPersonIntegrityRegressionFailure = _
            "�l�����̋󗓑��������S�ɕ⊮������s��A�Ɏ��s���܂����B"
        Exit Function
    End If

    SeedPersonIntegrityFixture accountData, transactionData, balanceData
    accountData(2, ACC_COL_PERSON_ID) = "P1"
    transactionData(2, WORK_TX_COL_PERSON_ID) = "P1"
    balanceData(2, WORK_BAL_COL_PERSON_ID) = "P1"
    If Not PersonIntegrityCasePasses("����l��ID�̈قȂ鑱��������", False, _
                                     "����l��ID�ɈقȂ鑱��", _
                                     accountData, transactionData, balanceData) Then Exit Function

    SeedPersonIntegrityFixture accountData, transactionData, balanceData
    accountData(2, ACC_COL_PERSON_ID) = "P1"
    accountData(2, ACC_COL_RELATIONSHIP) = "�{�l"
    transactionData(2, WORK_TX_COL_PERSON_ID) = "P1"
    transactionData(2, WORK_TX_COL_RELATIONSHIP) = "�{�l"
    balanceData(2, WORK_BAL_COL_PERSON_ID) = "P1"
    balanceData(2, WORK_BAL_COL_RELATIONSHIP) = "�{�l"
    If Not PersonIntegrityCasePasses("����l��ID�̕ʖ��`�����e", True, vbNullString, _
                                     accountData, transactionData, balanceData) Then Exit Function

    SeedPersonIntegrityFixture accountData, transactionData, balanceData
    transactionData(1, WORK_TX_COL_ACCOUNT_ID) = Empty
    If Not PersonIntegrityCasePasses("�������ID����", False, "W_��� 2�s: ����ID�Ȃ�", _
                                     accountData, transactionData, balanceData) Then Exit Function

    SeedPersonIntegrityFixture accountData, transactionData, balanceData
    transactionData(1, WORK_TX_COL_ACCOUNT_ID) = "X1"
    If Not PersonIntegrityCasePasses("�������ID�`���s��", False, "����ID�`���s�� X1", _
                                     accountData, transactionData, balanceData) Then Exit Function

    SeedPersonIntegrityFixture accountData, transactionData, balanceData
    transactionData(1, WORK_TX_COL_ACCOUNT_ID) = "A99"
    If Not PersonIntegrityCasePasses("����̌Ǘ�����", False, "�Ǘ�����ID A99", _
                                     accountData, transactionData, balanceData) Then Exit Function

    SeedPersonIntegrityFixture accountData, transactionData, balanceData
    transactionData(1, WORK_TX_COL_PERSON_ID) = Empty
    If Not PersonIntegrityCasePasses("����l��ID����", False, "W_��� 2�s: �l��ID�Ȃ�", _
                                     accountData, transactionData, balanceData) Then Exit Function

    SeedPersonIntegrityFixture accountData, transactionData, balanceData
    transactionData(1, WORK_TX_COL_PERSON_ID) = "PX"
    If Not PersonIntegrityCasePasses("����l��ID�`���s��", False, "�l��ID�`���s�� PX", _
                                     accountData, transactionData, balanceData) Then Exit Function

    SeedPersonIntegrityFixture accountData, transactionData, balanceData
    transactionData(1, WORK_TX_COL_PERSON_ID) = "P2"
    If Not PersonIntegrityCasePasses("����l��ID�s��v", False, "�l��ID�������}�X�^�ƕs��v", _
                                     accountData, transactionData, balanceData) Then Exit Function

    SeedPersonIntegrityFixture accountData, transactionData, balanceData
    transactionData(1, OUT_COL_PERSON) = "�ʖ��`"
    If Not PersonIntegrityCasePasses("������`�s��v", False, "�������`�l�������}�X�^�ƕs��v", _
                                     accountData, transactionData, balanceData) Then Exit Function

    SeedPersonIntegrityFixture accountData, transactionData, balanceData
    transactionData(1, OUT_COL_PERSON) = Empty
    If Not PersonIntegrityCasePasses("������`����", False, "W_��� 2�s: �������`�l�Ȃ�", _
                                     accountData, transactionData, balanceData) Then Exit Function

    SeedPersonIntegrityFixture accountData, transactionData, balanceData
    transactionData(1, WORK_TX_COL_RELATIONSHIP) = Empty
    If Not PersonIntegrityCasePasses("������������𔻒肵�Ȃ�", True, vbNullString, _
                                     accountData, transactionData, balanceData) Then Exit Function

    SeedPersonIntegrityFixture accountData, transactionData, balanceData
    transactionData(1, WORK_TX_COL_RELATIONSHIP) = "�z���"
    If Not PersonIntegrityCasePasses("��������s��v�𔻒肵�Ȃ�", True, vbNullString, _
                                     accountData, transactionData, balanceData) Then Exit Function

    SeedPersonIntegrityFixture accountData, transactionData, balanceData
    balanceData(1, WORK_BAL_COL_PERSON_ID) = "P2"
    If Not PersonIntegrityCasePasses("�c���l��ID�s��v", False, "�l��ID�������}�X�^�ƕs��v", _
                                     accountData, transactionData, balanceData) Then Exit Function

    SeedPersonIntegrityFixture accountData, transactionData, balanceData
    balanceData(1, WORK_BAL_COL_PERSON_ID) = Empty
    If Not PersonIntegrityCasePasses("�c���l��ID����", False, "W_�c�� 2�s: �l��ID�Ȃ�", _
                                     accountData, transactionData, balanceData) Then Exit Function

    SeedPersonIntegrityFixture accountData, transactionData, balanceData
    balanceData(1, WORK_BAL_COL_PERSON_ID) = "PX"
    If Not PersonIntegrityCasePasses("�c���l��ID�`���s��", False, "�l��ID�`���s�� PX", _
                                     accountData, transactionData, balanceData) Then Exit Function

    SeedPersonIntegrityFixture accountData, transactionData, balanceData
    balanceData(1, WORK_BAL_COL_ACCOUNT_ID) = Empty
    If Not PersonIntegrityCasePasses("�c������ID����", False, "W_�c�� 2�s: ����ID�Ȃ�", _
                                     accountData, transactionData, balanceData) Then Exit Function

    SeedPersonIntegrityFixture accountData, transactionData, balanceData
    balanceData(1, WORK_BAL_COL_ACCOUNT_ID) = "X1"
    If Not PersonIntegrityCasePasses("�c������ID�`���s��", False, "����ID�`���s�� X1", _
                                     accountData, transactionData, balanceData) Then Exit Function

    SeedPersonIntegrityFixture accountData, transactionData, balanceData
    balanceData(1, WORK_BAL_COL_ACCOUNT_ID) = "A99"
    If Not PersonIntegrityCasePasses("�c���̌Ǘ�����", False, "�Ǘ�����ID A99", _
                                     accountData, transactionData, balanceData) Then Exit Function

    SeedPersonIntegrityFixture accountData, transactionData, balanceData
    balanceData(1, BALANCE_PERSON_NAME_COLUMN) = Empty
    If Not PersonIntegrityCasePasses("�c�����`����", False, "W_�c�� 2�s: �������`�l�Ȃ�", _
                                     accountData, transactionData, balanceData) Then Exit Function

    SeedPersonIntegrityFixture accountData, transactionData, balanceData
    balanceData(1, BALANCE_PERSON_NAME_COLUMN) = "�ʖ��`"
    If Not PersonIntegrityCasePasses("�c�����`�s��v", False, "�������`�l�������}�X�^�ƕs��v", _
                                     accountData, transactionData, balanceData) Then Exit Function

    SeedPersonIntegrityFixture accountData, transactionData, balanceData
    balanceData(1, WORK_BAL_COL_RELATIONSHIP) = "�z���"
    If Not PersonIntegrityCasePasses("�c�������s��v�𔻒肵�Ȃ�", True, vbNullString, _
                                     accountData, transactionData, balanceData) Then Exit Function

    SeedPersonIntegrityFixture accountData, transactionData, balanceData
    transactionData(1, WORK_TX_COL_RELATIONSHIP) = CVErr(xlErrValue)
    If Not PersonIntegrityCasePasses("��������G���[�l�𔻒肵�Ȃ�", True, vbNullString, _
                                     accountData, transactionData, balanceData) Then Exit Function

    SeedPersonIntegrityFixture accountData, transactionData, balanceData
    transactionData(1, OUT_COL_TIME) = Empty
    transactionData(2, OUT_COL_TIME) = CVErr(xlErrValue)
    If Not PersonIntegrityCasePasses("������l�����S���̔���Ώۂɂ��Ȃ�", True, vbNullString, _
                                     accountData, transactionData, balanceData) Then Exit Function

    SeedPersonIntegrityFixture accountData, transactionData, balanceData
    accountData(1, ACC_COL_RELATIONSHIP) = Empty
    transactionData(1, WORK_TX_COL_RELATIONSHIP) = Empty
    balanceData(1, WORK_BAL_COL_RELATIONSHIP) = Empty
    If Not PersonIntegrityCasePasses("���{�Ɩ��ׂ̑����󗓈�v", True, vbNullString, _
                                     accountData, transactionData, balanceData) Then Exit Function

    SeedPersonIntegrityFixture accountData, transactionData, balanceData
    accountData(1, ACC_COL_RELATIONSHIP) = Empty
    transactionData(1, WORK_TX_COL_RELATIONSHIP) = "�{�l"
    balanceData(1, WORK_BAL_COL_RELATIONSHIP) = Empty
    If Not PersonIntegrityCasePasses("���{�󗓂Ɩ��ב������𔻒肵�Ȃ�", True, vbNullString, _
                                     accountData, transactionData, balanceData) Then Exit Function

    If Not PersonIntegrityCasePasses("�S�ۊǕ\����", True, vbNullString, _
                                     emptyAccountData, emptyTransactionData, emptyBalanceData) Then _
        Exit Function

    malformedAccountData = Array("A1")
    If Not PersonIntegrityCasePasses("fixture�����s��", False, "fixture�̎������m�F�ł��܂���", _
                                     malformedAccountData, emptyTransactionData, _
                                     emptyBalanceData) Then Exit Function

    PersonIntegrityRegressionTest = True
    Exit Function
Failed:
    mLastPersonIntegrityRegressionFailure = "��A�������̂� Err " & _
                                            CStr(Err.Number) & ": " & Err.Description
    PersonIntegrityRegressionTest = False
End Function

Private Function PersonCandidateIntegrityCasePasses( _
        ByVal caseLabel As String, ByVal expectedValid As Boolean, _
        ByVal expectedProblemText As String, ByRef accountData As Variant, _
        ByRef candidateData As Variant) As Boolean
    Dim actualValid As Boolean, problems As String
    actualValid = ValidatePersonCandidateIntegrityFixture(accountData, candidateData, problems)
    If actualValid <> expectedValid Then
        mLastPersonIntegrityRegressionFailure = caseLabel & _
            ": ����=" & CStr(expectedValid) & " / ����=" & CStr(actualValid) & _
            " / �ڍ�=" & problems
        Exit Function
    End If
    If Len(expectedProblemText) > 0 Then
        If InStr(1, problems, expectedProblemText, vbBinaryCompare) = 0 Then
            mLastPersonIntegrityRegressionFailure = caseLabel & _
                ": �K�{�G���[��������܂��� / �ڍ�=" & problems
            Exit Function
        End If
    End If
    PersonCandidateIntegrityCasePasses = True
End Function

Private Function ValidatePersonCandidateIntegrityFixture( _
        ByRef accountData As Variant, ByRef candidateData As Variant, _
        ByRef problems As String) As Boolean
    Dim accountFirstRow As Long, accountLastRow As Long, accountHasRows As Boolean
    Dim candidateFirstRow As Long, candidateLastRow As Long, candidateHasRows As Boolean
    Dim personIDByAccount As Object, personNameByAccount As Object
    Dim accountSourceRowByID As Object
    Dim personIDByIdentity As Object, identitySourceRow As Object
    Dim relationshipByPersonID As Object, relationshipSourceByPersonID As Object

    problems = vbNullString
    If Not TryPersonIntegrityMatrixBounds(accountData, ACC_COL_TRANSFER_ID, "W_����", _
                                           accountFirstRow, accountLastRow, _
                                           accountHasRows, problems) Then Exit Function
    If Not TryPersonIntegrityMatrixBounds(candidateData, 3, "�l�����", _
                                           candidateFirstRow, candidateLastRow, _
                                           candidateHasRows, problems) Then Exit Function
    Set personIDByAccount = NewPersonIntegrityDictionary()
    Set personNameByAccount = NewPersonIntegrityDictionary()
    Set accountSourceRowByID = NewPersonIntegrityDictionary()
    Set personIDByIdentity = NewPersonIntegrityDictionary()
    Set identitySourceRow = NewPersonIntegrityDictionary()
    Set relationshipByPersonID = NewPersonIntegrityDictionary()
    Set relationshipSourceByPersonID = NewPersonIntegrityDictionary()
    If accountHasRows Then
        ValidatePersonIntegrityAccounts accountData, accountFirstRow, accountLastRow, _
                                        personIDByAccount, personNameByAccount, _
                                        accountSourceRowByID, personIDByIdentity, _
                                        identitySourceRow, relationshipByPersonID, _
                                        relationshipSourceByPersonID, problems
    End If
    If candidateHasRows Then
        ValidatePersonIntegrityCandidates candidateData, candidateFirstRow, candidateLastRow, _
                                          personIDByIdentity, identitySourceRow, _
                                          relationshipByPersonID, _
                                          relationshipSourceByPersonID, problems
    End If
    ValidatePersonCandidateIntegrityFixture = (Len(problems) = 0)
End Function

Public Function GetLastPersonIntegrityRegressionFailure() As String
    GetLastPersonIntegrityRegressionFailure = mLastPersonIntegrityRegressionFailure
End Function

Private Function ValidatePersonIntegritySheetsSequentially( _
        ByRef problems As String, _
        Optional ByVal includePersonCandidates As Boolean = True) As Boolean
    Dim accountData As Variant, transactionData As Variant, balanceData As Variant
    Dim candidateData As Variant
    Dim firstRow As Long, lastRow As Long, hasRows As Boolean
    Dim personIDByAccount As Object, personNameByAccount As Object
    Dim accountSourceRowByID As Object
    Dim personIDByIdentity As Object, identitySourceRow As Object
    Dim relationshipByPersonID As Object, relationshipSourceByPersonID As Object

    Set personIDByAccount = NewPersonIntegrityDictionary()
    Set personNameByAccount = NewPersonIntegrityDictionary()
    Set accountSourceRowByID = NewPersonIntegrityDictionary()
    Set personIDByIdentity = NewPersonIntegrityDictionary()
    Set identitySourceRow = NewPersonIntegrityDictionary()
    Set relationshipByPersonID = NewPersonIntegrityDictionary()
    Set relationshipSourceByPersonID = NewPersonIntegrityDictionary()

    '32bit Excel�ł�3�ۊǕ\�𓯎��ێ����Ȃ��B���{�������������͔z��������������B
    accountData = LoadPersonIntegrityMatrix(SH_WORK_ACCOUNT, ACC_COL_TRANSFER_ID)
    If Not TryPersonIntegrityMatrixBounds(accountData, ACC_COL_TRANSFER_ID, "W_����", _
                                           firstRow, lastRow, hasRows, problems) Then Exit Function
    If hasRows Then
        ValidatePersonIntegrityAccounts accountData, firstRow, lastRow, _
                                        personIDByAccount, personNameByAccount, _
                                        accountSourceRowByID, personIDByIdentity, _
                                        identitySourceRow, relationshipByPersonID, _
                                        relationshipSourceByPersonID, problems
    End If
    If IsArray(accountData) Then Erase accountData

    transactionData = LoadPersonIntegrityMatrix(SH_WORK_TX, WORK_TX_COL_PERSON_ID)
    If Not TryPersonIntegrityMatrixBounds(transactionData, WORK_TX_COL_PERSON_ID, "W_���", _
                                           firstRow, lastRow, hasRows, problems) Then Exit Function
    If hasRows Then
        ValidatePersonIntegrityLinkedRows transactionData, firstRow, lastRow, "W_���", _
                                          WORK_TX_COL_ACCOUNT_ID, WORK_TX_COL_PERSON_ID, _
                                          OUT_COL_PERSON, personIDByAccount, _
                                          personNameByAccount, accountSourceRowByID, problems
    End If
    If IsArray(transactionData) Then Erase transactionData

    balanceData = LoadPersonIntegrityMatrix(SH_WORK_BAL, WORK_BAL_COL_PERSON_ID)
    If Not TryPersonIntegrityMatrixBounds(balanceData, WORK_BAL_COL_PERSON_ID, "W_�c��", _
                                           firstRow, lastRow, hasRows, problems) Then Exit Function
    If hasRows Then
        ValidatePersonIntegrityLinkedRows balanceData, firstRow, lastRow, "W_�c��", _
                                          WORK_BAL_COL_ACCOUNT_ID, WORK_BAL_COL_PERSON_ID, _
                                          BALANCE_PERSON_NAME_COLUMN, personIDByAccount, _
                                          personNameByAccount, accountSourceRowByID, problems
    End If
    If IsArray(balanceData) Then Erase balanceData

    If includePersonCandidates Then
        candidateData = LoadPersonIntegrityMatrix( _
                            SH_PERSON_CAND, 3, PERSON_CANDIDATE_DATA_ROW_LIMIT)
        If Not TryPersonIntegrityMatrixBounds(candidateData, 3, "�l�����", _
                                               firstRow, lastRow, hasRows, problems) Then Exit Function
        If hasRows Then
            ValidatePersonIntegrityCandidates candidateData, firstRow, lastRow, _
                                              personIDByIdentity, identitySourceRow, _
                                              relationshipByPersonID, _
                                              relationshipSourceByPersonID, problems
        End If
        If IsArray(candidateData) Then Erase candidateData
    End If
    ValidatePersonIntegritySheetsSequentially = (Len(problems) = 0)
End Function

Private Function LoadPersonIntegrityMatrix(ByVal sheetName As String, _
                                           ByVal lastColumn As Long, _
                                           Optional ByVal maxDataRows As Long = _
                                               MAX_INTERNAL_STORE_DATA_ROWS) As Variant
    Dim ws As Worksheet, lastDataRow As Long
    Set ws = GetSheet(sheetName)
    lastDataRow = LastDataRowInColumns(ws, 1, lastColumn)
    If maxDataRows < 1 Then _
        Err.Raise vbObjectError + 6301, "LoadPersonIntegrityMatrix", _
                  "�l�������������̍s������s���ł�: " & CStr(maxDataRows)
    If lastDataRow > maxDataRows + 1 Then _
        Err.Raise vbObjectError + 6300, "LoadPersonIntegrityMatrix", _
                  sheetName & "���l�������������̎��p����i" & _
                  Format$(maxDataRows, "#,##0") & "�s�j�𒴂��Ă��܂��B"
    If lastDataRow >= 2 Then
        LoadPersonIntegrityMatrix = ws.Range(ws.Cells(2, 1), _
                                             ws.Cells(lastDataRow, lastColumn)).Value2
    End If
End Function

Private Function NewPersonIntegrityDictionary() As Object
    Dim result As Object
    Set result = CreateObject("Scripting.Dictionary")
    result.CompareMode = vbTextCompare
    Set NewPersonIntegrityDictionary = result
End Function

Private Function TryPersonIntegrityMatrixBounds(ByRef sourceData As Variant, _
                                                ByVal expectedLastColumn As Long, _
                                                ByVal storeLabel As String, _
                                                ByRef firstRow As Long, _
                                                ByRef lastRow As Long, _
                                                ByRef hasRows As Boolean, _
                                                ByRef problems As String) As Boolean
    Dim firstColumn As Long, lastColumn As Long
    firstRow = 0
    lastRow = 0
    hasRows = False
    If IsEmpty(sourceData) Then
        TryPersonIntegrityMatrixBounds = True
        Exit Function
    End If
    If Not IsArray(sourceData) Then
        AppendPersonIntegrityProblem problems, storeLabel & " fixture��2�����z��ł͂���܂���B"
        Exit Function
    End If

    On Error GoTo InvalidMatrix
    firstRow = LBound(sourceData, 1)
    lastRow = UBound(sourceData, 1)
    firstColumn = LBound(sourceData, 2)
    lastColumn = UBound(sourceData, 2)
    If firstRow <> 1 Or firstColumn <> 1 Or lastRow < firstRow Or _
       lastColumn < expectedLastColumn Then
        AppendPersonIntegrityProblem problems, _
            storeLabel & " fixture�͈̔͂��s���ł��i�K�v��=" & _
            CStr(expectedLastColumn) & "�j�B"
        Exit Function
    End If
    hasRows = True
    TryPersonIntegrityMatrixBounds = True
    Exit Function
InvalidMatrix:
    AppendPersonIntegrityProblem problems, storeLabel & " fixture�̎������m�F�ł��܂���B"
    Err.Clear
End Function

Private Sub ValidatePersonIntegrityAccounts(ByRef accountData As Variant, _
                                             ByVal firstRow As Long, _
                                             ByVal lastRow As Long, _
                                             ByVal personIDByAccount As Object, _
                                             ByVal personNameByAccount As Object, _
                                             ByVal accountSourceRowByID As Object, _
                                             ByVal personIDByIdentity As Object, _
                                             ByVal identitySourceRow As Object, _
                                             ByVal relationshipByPersonID As Object, _
                                             ByVal relationshipSourceByPersonID As Object, _
                                             ByRef problems As String)
    Dim sourceIndex As Long, worksheetRow As Long
    Dim accountID As String, personID As String
    Dim personName As String, relationshipText As String, identityKey As String
    For sourceIndex = firstRow To lastRow
        worksheetRow = sourceIndex - firstRow + 2
        accountID = CellText(accountData(sourceIndex, ACC_COL_ID))
        personName = CellText(accountData(sourceIndex, ACC_COL_PERSON))
        relationshipText = CellText(accountData(sourceIndex, ACC_COL_RELATIONSHIP))
        personID = CellText(accountData(sourceIndex, ACC_COL_PERSON_ID))

        If Len(accountID) = 0 Then
            AppendPersonIntegrityProblem problems, _
                "W_���� " & CStr(worksheetRow) & "�s: ����ID�Ȃ�"
        Else
            If Not IsInternalIdValue(accountID, "A") Then _
                AppendPersonIntegrityProblem problems, _
                    "W_���� " & CStr(worksheetRow) & "�s: ����ID�`���s�� " & accountID
            If personIDByAccount.Exists(accountID) Then
                AppendPersonIntegrityProblem problems, _
                    "W_���� " & CStr(worksheetRow) & "�s: ����ID�d�� " & accountID & _
                    "�i��s=" & CStr(accountSourceRowByID(accountID)) & "�s�j"
            Else
                personIDByAccount.Add accountID, personID
                personNameByAccount.Add accountID, personName
                accountSourceRowByID.Add accountID, worksheetRow
            End If
        End If

        If Not HasPersonIntegrityName(personName) Then _
            AppendPersonIntegrityProblem problems, _
                "W_���� " & CStr(worksheetRow) & "�s: �������`�l�Ȃ�"
        If Len(personID) = 0 Then
            AppendPersonIntegrityProblem problems, _
                "W_���� " & CStr(worksheetRow) & "�s: �l��ID�Ȃ�"
        ElseIf Not IsInternalIdValue(personID, "P") Then
            AppendPersonIntegrityProblem problems, _
                "W_���� " & CStr(worksheetRow) & "�s: �l��ID�`���s�� " & personID
        ElseIf HasPersonIntegrityName(personName) Then
            ValidatePersonIDRelationship personID, relationshipText, _
                                         "W_���� " & CStr(worksheetRow) & "�s", _
                                         relationshipByPersonID, _
                                         relationshipSourceByPersonID, problems
            identityKey = PersonIdentityKey(personName, relationshipText)
            If personIDByIdentity.Exists(identityKey) Then
                If StrComp(CStr(personIDByIdentity(identityKey)), personID, _
                           vbTextCompare) <> 0 Then _
                    AppendPersonIntegrityProblem problems, _
                        "W_���� " & CStr(worksheetRow) & _
                        "�s: ���������E�����ɈقȂ�l��ID" & _
                        "�i��s=" & CStr(identitySourceRow(identityKey)) & _
                        "�s / ����=" & CStr(personIDByIdentity(identityKey)) & _
                        " / ����=" & personID & "�j"
            Else
                personIDByIdentity.Add identityKey, personID
                identitySourceRow.Add identityKey, worksheetRow
            End If
        End If
    Next sourceIndex
End Sub

Private Sub ValidatePersonIntegrityCandidates(ByRef candidateData As Variant, _
                                              ByVal firstRow As Long, _
                                              ByVal lastRow As Long, _
                                              ByVal personIDByIdentity As Object, _
                                              ByVal identitySourceRow As Object, _
                                              ByVal relationshipByPersonID As Object, _
                                              ByVal relationshipSourceByPersonID As Object, _
                                              ByRef problems As String)
    Dim sourceIndex As Long, worksheetRow As Long
    Dim personName As String, relationshipText As String
    Dim personID As String, identityKey As String
    Dim blankIdentityRows As Object
    Set blankIdentityRows = NewPersonIntegrityDictionary()
    For sourceIndex = firstRow To lastRow
        worksheetRow = sourceIndex - firstRow + 2
        personName = CellText(candidateData(sourceIndex, 1))
        personID = CellText(candidateData(sourceIndex, 2))
        relationshipText = CellText(candidateData(sourceIndex, 3))

        '�l��ID�Ȃ��̕ʐl�����͓��͌��Ƃ��ċ��e����B���������{������
        'ID�t���s�����ɂ���ꍇ�͏d���Ƃ��Ď~�߁A�قȂ�ID�ւ̕����S�����Ŗh���B
        If Len(personID) > 0 Then
            If Not IsInternalIdValue(personID, "P") Then
                AppendPersonIntegrityProblem problems, _
                    "�l����� " & CStr(worksheetRow) & "�s: �l��ID�`���s�� " & personID
            ElseIf Not HasPersonIntegrityName(personName) Then
                AppendPersonIntegrityProblem problems, _
                    "�l����� " & CStr(worksheetRow) & "�s: �����Ȃ��̐l��ID " & personID
            Else
                ValidatePersonIDRelationship personID, relationshipText, _
                                             "�l����� " & CStr(worksheetRow) & "�s", _
                                             relationshipByPersonID, _
                                             relationshipSourceByPersonID, problems
                identityKey = PersonIdentityKey(personName, relationshipText)
                If personIDByIdentity.Exists(identityKey) Then
                    If StrComp(CStr(personIDByIdentity(identityKey)), personID, _
                               vbTextCompare) <> 0 Then _
                        AppendPersonIntegrityProblem problems, _
                            "�l����� " & CStr(worksheetRow) & _
                            "�s: ���������E�����ɈقȂ�l��ID" & _
                            "�i��s=" & CStr(identitySourceRow(identityKey)) & _
                            " / ����=" & CStr(personIDByIdentity(identityKey)) & _
                            " / ����=" & personID & "�j"
                Else
                    personIDByIdentity.Add identityKey, personID
                    identitySourceRow.Add identityKey, _
                                          "�l����� " & CStr(worksheetRow) & "�s"
                End If
                If blankIdentityRows.Exists(identityKey) Then _
                    AppendPersonIntegrityProblem problems, _
                        "�l����� " & CStr(worksheetRow) & _
                        "�s: ���������E�����ɐl��ID�Ȃ��̏d���s������܂��i" & _
                        CStr(blankIdentityRows(identityKey)) & "�s�j"
            End If
        ElseIf HasPersonIntegrityName(personName) Then
            identityKey = PersonIdentityKey(personName, relationshipText)
            If personIDByIdentity.Exists(identityKey) Then
                AppendPersonIntegrityProblem problems, _
                    "�l����� " & CStr(worksheetRow) & _
                    "�s: ���������E�����̐l��ID�t�����Əd�����Ă��܂�"
            ElseIf blankIdentityRows.Exists(identityKey) Then
                AppendPersonIntegrityProblem problems, _
                    "�l����� " & CStr(worksheetRow) & _
                    "�s: ���������E�����̐l��ID�Ȃ���₪�d�����Ă��܂��i��s=" & _
                    CStr(blankIdentityRows(identityKey)) & "�s�j"
            Else
                blankIdentityRows.Add identityKey, worksheetRow
            End If
        End If
    Next sourceIndex
End Sub

Private Sub ValidatePersonIDRelationship(ByVal personID As String, _
                                         ByVal relationshipText As String, _
                                         ByVal sourceText As String, _
                                         ByVal relationshipByPersonID As Object, _
                                         ByVal relationshipSourceByPersonID As Object, _
                                         ByRef problems As String)
    Dim relationshipKey As String, expectedRelationship As String
    personID = CellText(personID)
    relationshipText = CellText(relationshipText)
    If Len(personID) = 0 Then Exit Sub
    relationshipKey = NormalizeRelationshipKey(relationshipText)
    '�󗓂͖��m��Ƃ��ċ��e����B�m��ς݂̔�󗓓��m�������r���A
    '��̐l��ID�֕����̑��������蓖�Ă����Ԃ�ۑ��O�Q�[�g�Ŏ~�߂�B
    If Len(relationshipKey) = 0 Then Exit Sub
    If relationshipByPersonID.Exists(personID) Then
        expectedRelationship = CellText(relationshipByPersonID(personID))
        If StrComp(NormalizeRelationshipKey(expectedRelationship), _
                   relationshipKey, vbBinaryCompare) <> 0 Then _
            AppendPersonIntegrityProblem problems, sourceText & _
                ": ����l��ID�ɈقȂ鑱��" & _
                "�i�l��ID=" & personID & _
                " / ��s=" & CStr(relationshipSourceByPersonID(personID)) & _
                " / ����=" & expectedRelationship & _
                " / ����=" & relationshipText & "�j"
    Else
        relationshipByPersonID.Add personID, relationshipText
        relationshipSourceByPersonID.Add personID, sourceText
    End If
End Sub

Private Sub ValidatePersonIntegrityLinkedRows(ByRef sourceData As Variant, _
                                              ByVal firstRow As Long, _
                                              ByVal lastRow As Long, _
                                              ByVal storeLabel As String, _
                                              ByVal accountIDColumn As Long, _
                                              ByVal personIDColumn As Long, _
                                              ByVal personNameColumn As Long, _
                                              ByVal personIDByAccount As Object, _
                                              ByVal personNameByAccount As Object, _
                                              ByVal accountSourceRowByID As Object, _
                                              ByRef problems As String)
    Dim sourceIndex As Long, worksheetRow As Long
    Dim accountID As String, personID As String, personName As String
    Dim expectedPersonID As String, expectedPersonName As String
    Dim accountExists As Boolean, personIDIsValid As Boolean

    For sourceIndex = firstRow To lastRow
        worksheetRow = sourceIndex - firstRow + 2
        accountID = CellText(sourceData(sourceIndex, accountIDColumn))
        personID = CellText(sourceData(sourceIndex, personIDColumn))
        personName = CellText(sourceData(sourceIndex, personNameColumn))
        accountExists = False

        If Len(accountID) = 0 Then
            AppendPersonIntegrityProblem problems, _
                storeLabel & " " & CStr(worksheetRow) & "�s: ����ID�Ȃ�"
        Else
            If Not IsInternalIdValue(accountID, "A") Then _
                AppendPersonIntegrityProblem problems, _
                    storeLabel & " " & CStr(worksheetRow) & "�s: ����ID�`���s�� " & accountID
            accountExists = personIDByAccount.Exists(accountID)
            If Not accountExists Then _
                AppendPersonIntegrityProblem problems, _
                    storeLabel & " " & CStr(worksheetRow) & "�s: �Ǘ�����ID " & accountID
        End If

        personIDIsValid = False
        If Len(personID) = 0 Then
            AppendPersonIntegrityProblem problems, _
                storeLabel & " " & CStr(worksheetRow) & "�s: �l��ID�Ȃ�"
        ElseIf Not IsInternalIdValue(personID, "P") Then
            AppendPersonIntegrityProblem problems, _
                storeLabel & " " & CStr(worksheetRow) & "�s: �l��ID�`���s�� " & personID
        Else
            personIDIsValid = True
        End If
        If Not HasPersonIntegrityName(personName) Then _
            AppendPersonIntegrityProblem problems, _
                storeLabel & " " & CStr(worksheetRow) & "�s: �������`�l�Ȃ�"

        If accountExists Then
            expectedPersonID = CellText(personIDByAccount(accountID))
            expectedPersonName = CellText(personNameByAccount(accountID))
            If personIDIsValid And IsInternalIdValue(expectedPersonID, "P") Then
                If StrComp(personID, expectedPersonID, vbTextCompare) <> 0 Then _
                    AppendPersonIntegrityProblem problems, _
                        storeLabel & " " & CStr(worksheetRow) & _
                        "�s: �l��ID�������}�X�^�ƕs��v�i����=" & accountID & _
                        " / ����=" & expectedPersonID & " / ����=" & personID & _
                        " / W_����=" & CStr(accountSourceRowByID(accountID)) & "�s�j"
            End If

            If HasPersonIntegrityName(personName) And _
               HasPersonIntegrityName(expectedPersonName) Then
                If StrComp(personName, expectedPersonName, vbBinaryCompare) <> 0 Then _
                    AppendPersonIntegrityProblem problems, _
                        storeLabel & " " & CStr(worksheetRow) & _
                        "�s: �������`�l�������}�X�^�ƕs��v�i����=" & accountID & _
                        " / ����=" & expectedPersonName & " / ����=" & personName & _
                        " / W_����=" & CStr(accountSourceRowByID(accountID)) & "�s�j"
            End If
        End If
    Next sourceIndex
End Sub

Private Function HasPersonIntegrityName(ByVal personName As String) As Boolean
    HasPersonIntegrityName = (Len(NormalizePersonNameKey(personName)) > 0)
End Function

Private Sub AppendPersonIntegrityProblem(ByRef problems As String, _
                                         ByVal problemText As String)
    Const TRUNCATED_TEXT As String = "�E�ȍ~�̐l���������G���[�͏ȗ����܂����B"
    Dim appendedText As String, retainedLength As Long
    If InStr(1, problems, TRUNCATED_TEXT, vbBinaryCompare) > 0 Then Exit Sub
    If Len(problems) >= PERSON_INTEGRITY_DETAIL_LIMIT Then Exit Sub
    appendedText = "�E" & problemText & vbCrLf
    If Len(problems) + Len(appendedText) <= PERSON_INTEGRITY_DETAIL_LIMIT Then
        problems = problems & appendedText
    Else
        retainedLength = PERSON_INTEGRITY_DETAIL_LIMIT - Len(TRUNCATED_TEXT) - Len(vbCrLf)
        If retainedLength < 0 Then retainedLength = 0
        problems = Left$(problems, retainedLength) & TRUNCATED_TEXT & vbCrLf
    End If
End Sub

Private Sub SeedPersonIntegrityFixture(ByRef accountData As Variant, _
                                       ByRef transactionData As Variant, _
                                       ByRef balanceData As Variant)
    ReDim accountData(1 To 2, 1 To ACC_COL_TRANSFER_ID)
    ReDim transactionData(1 To 2, 1 To WORK_TX_COL_PERSON_ID)
    ReDim balanceData(1 To 2, 1 To WORK_BAL_COL_PERSON_ID)

    accountData(1, ACC_COL_ID) = "A1"
    accountData(1, ACC_COL_PERSON) = "�b"
    accountData(1, ACC_COL_RELATIONSHIP) = "�{�l"
    accountData(1, ACC_COL_PERSON_ID) = "P1"
    accountData(2, ACC_COL_ID) = "A2"
    accountData(2, ACC_COL_PERSON) = "��"
    accountData(2, ACC_COL_RELATIONSHIP) = "�q"
    accountData(2, ACC_COL_PERSON_ID) = "P2"

    transactionData(1, OUT_COL_PERSON) = "�b"
    transactionData(1, WORK_TX_COL_RELATIONSHIP) = "�{�l"
    transactionData(1, WORK_TX_COL_ACCOUNT_ID) = "A1"
    transactionData(1, WORK_TX_COL_PERSON_ID) = "P1"
    transactionData(2, OUT_COL_PERSON) = "��"
    transactionData(2, WORK_TX_COL_RELATIONSHIP) = "�q"
    transactionData(2, WORK_TX_COL_ACCOUNT_ID) = "A2"
    transactionData(2, WORK_TX_COL_PERSON_ID) = "P2"

    balanceData(1, BALANCE_PERSON_NAME_COLUMN) = "�b"
    balanceData(1, WORK_BAL_COL_RELATIONSHIP) = "�{�l"
    balanceData(1, WORK_BAL_COL_ACCOUNT_ID) = "A1"
    balanceData(1, WORK_BAL_COL_PERSON_ID) = "P1"
    balanceData(2, BALANCE_PERSON_NAME_COLUMN) = "��"
    balanceData(2, WORK_BAL_COL_RELATIONSHIP) = "�q"
    balanceData(2, WORK_BAL_COL_ACCOUNT_ID) = "A2"
    balanceData(2, WORK_BAL_COL_PERSON_ID) = "P2"
End Sub

Private Function PersonIntegrityCasePasses(ByVal caseLabel As String, _
                                           ByVal expectedValid As Boolean, _
                                           ByVal expectedProblemText As String, _
                                           ByRef accountData As Variant, _
                                           ByRef transactionData As Variant, _
                                           ByRef balanceData As Variant) As Boolean
    Dim problems As String, actualValid As Boolean
    actualValid = ValidatePersonIntegrityFixture(accountData, transactionData, _
                                                  balanceData, problems)
    If actualValid <> expectedValid Then
        mLastPersonIntegrityRegressionFailure = caseLabel & _
            ": �߂�l���s��v�i����=" & CStr(expectedValid) & _
            " / ����=" & CStr(actualValid) & "�j�B�ڍ�=" & problems
        Exit Function
    End If
    If Len(expectedProblemText) > 0 Then
        If InStr(1, problems, expectedProblemText, vbBinaryCompare) = 0 Then
            mLastPersonIntegrityRegressionFailure = caseLabel & _
                ": �z�肵���f�f������܂���i����=" & expectedProblemText & _
                "�j�B�ڍ�=" & problems
            Exit Function
        End If
    ElseIf Len(problems) > 0 Then
        mLastPersonIntegrityRegressionFailure = caseLabel & _
            ": ����fixture�Őf�f���Ԃ�܂����B�ڍ�=" & problems
        Exit Function
    End If
    PersonIntegrityCasePasses = True
End Function

﻿Attribute VB_Name = "modFinalExport"
Option Explicit

'====================================================================================
' 最終成果物出力
'------------------------------------------------------------------------------------
' 作業用ブックには入力シート、作業シート、候補・設定・マクロ等が含まれる。
' 提出・共有用には不要なため、最終的な「資金操作表」と「残高推移表」だけを
' それぞれマクロなしの通常Excelブック（.xlsx）として外部出力する。
'
' 出力先は時刻付きの完成フォルダーとし、2ファイルと出力確認票を一組で公開する。
' 生成途中は専用ステージフォルダーへ保存し、全検査後にフォルダー名を一度だけ変更する。
'
' 最終出力時は更新フラグを確認し、変更があれば内部保管から両帳票・分析・
' 確認済みの変換内容を反映した資金操作表を提出用として使用する。
'====================================================================================

Private Const EXPORT_FILE_CASH As String = "01_資金操作表.xlsx"
Private Const EXPORT_FILE_BALANCE As String = "02_残高推移表.xlsx"
Private Const EXPORT_FILE_MANIFEST As String = "出力確認.txt"
Private Const EXPORT_FOLDER_PREFIX As String = "最終成果物_"
Private Const EXPORT_STAGE_PREFIX As String = ".cashop_stage_"
Private Const FINAL_EXPORT_RECOVERY_FATAL_ERROR As Long = vbObjectError + 4499
Private Const FINAL_EXPORT_RECOVERY_FATAL_SOURCE As String = "FinalExportRecoveryFatal/"

Public Sub ExportFinalWorkbooks()
    Dim folderPath As String
    Dim cashSheetName As String
    Dim balanceSheetName As String
    Dim cashPath As String, balancePath As String, manifestPath As String
    Dim stageFolderPath As String, packageFolderPath As String
    Dim cleanupDetail As String, reportingDetail As String
    Dim outputsRebuilt As Boolean
    Dim pairCommitted As Boolean, stageCreated As Boolean
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim confirmedAnalysisWorkloadRows As Double
    Dim entryEvents As Boolean, entryEventsCaptured As Boolean
    Dim applicationLeaseStarted As Boolean
    Dim cleanupEventsStopped As Boolean
    Dim eventDetail As String
    Dim operationSucceeded As Boolean
    On Error GoTo EH

    'このPublic入口自身がExcelイベントのleaseを所有する。AppBeginはFalseを開始値として
    '捕捉するため、Application状態を戻した後も、最後の明示的な復元までイベントは再開しない。
    If Not TryGetFinalExportEnableEvents(entryEvents, eventDetail) Then _
        Err.Raise vbObjectError + 5246, "ExportFinalWorkbooks", _
                  "Excelイベントの開始状態を取得できません。 " & eventDetail
    entryEventsCaptured = True
    If Not TrySetFinalExportEnableEventsExact(False, eventDetail) Then _
        Err.Raise vbObjectError + 5247, "ExportFinalWorkbooks", _
                  "Excelイベントを安全に停止できないため、最終出力を開始していません。 " & _
                  eventDetail
    cleanupEventsStopped = True

    If Not RequireCashAnalysisManualModeFinished("最終成果物の出力") Then GoTo CLEAN_EXIT
    If HasSelectedAnalysisDetailTransactions() Then
        MsgBox "候補詳細に、手動候補として未登録の選択取引があります。" & vbCrLf & _
               "最終成果物の出力前に、候補を登録するか選択を解除してください。" & vbCrLf & _
               "選択内容を黙って破棄することはありません。", _
               vbInformation, "手動候補の選択を完了してください"
        GoTo CLEAN_EXIT
    End If
    If Not RequireToolReady() Then GoTo CLEAN_EXIT
    If Not RequireOutputBuildCapacity("最終成果物の出力", True, True, True, _
                                      True, True, True) Then
        reportingDetail = vbNullString
        TrySetFinalExportStatus _
            "最終成果物の出力を開始せず中止しました。内部データ、既存帳票、出力先は変更していません。", _
            False, reportingDetail
        GoTo CLEAN_EXIT
    End If
    If Not ConfirmAnalysisReviewOperationCapacity( _
            "最終成果物の出力", confirmedAnalysisWorkloadRows) Then
        reportingDetail = vbNullString
        TrySetFinalExportStatus _
            "最終成果物の出力を開始せず中止しました。内部データ、既存帳票、出力先は変更していません。", _
            False, reportingDetail
        GoTo CLEAN_EXIT
    End If
    If Not RequireNoPendingAccountInput("最終成果物の出力") Then GoTo CLEAN_EXIT
    If Not RequireInternalStoresSafeForWrite(False, False) Then GoTo CLEAN_EXIT
    If Not EnsureCaseReadyForOutputs(True) Then GoTo CLEAN_EXIT

    '保存先の取消・パス不備で、帳票や分析だけを更新済みにしない。
    folderPath = PickFinalExportFolder()
    If Len(folderPath) = 0 Then GoTo CLEAN_EXIT
    BuildUniqueExportPackagePaths folderPath, stageFolderPath, packageFolderPath
    ValidateFinalExportDestination folderPath, stageFolderPath, packageFolderPath

    '入力更新後の古い帳票を出さないよう、更新状態を見て必要時だけ再構築する。
    AppBegin "最新データから帳票・分析を確認しています..."
    applicationLeaseStarted = True
    RequireFinalExportEventsStoppedExact "帳票・分析の最新化前"
    EnsureBaseOutputSheetsForExport confirmedAnalysisWorkloadRows
    outputsRebuilt = True
    If Not EnsureShopConversionReadyForFinalExport() Then GoTo CLEAN_EXIT

    cashSheetName = GetFinalCashOperationSheetName()
    balanceSheetName = SH_OUTPUT_BAL

    If Len(cashSheetName) = 0 Then
        MsgBox "出力できる資金操作表がありません。先に『帳票・分析を更新』を実行してください。", vbExclamation
        GoTo CLEAN_EXIT
    End If
    If Not HasWorksheetData(balanceSheetName) Then
        MsgBox "出力できる残高推移表がありません。先に『帳票・分析を更新』を実行してください。", vbExclamation
        GoTo CLEAN_EXIT
    End If

    'この提出物を生成した判断・帳票更新時刻を作業ブックへ確定してから公開する。
    RequireFinalExportEventsStoppedExact "作業ブック保存前"
    If ThisWorkbook.FileFormat <> xlOpenXMLWorkbookMacroEnabled Then _
        Err.Raise vbObjectError + 5242, "ExportFinalWorkbooks", _
                  "作業ブックがマクロ有効形式（.xlsm）ではありません。"
    ThisWorkbook.SaveWorkbookForFinalExport

    '旧案件や別案件の一時フォルダーは、今回の一意なステージ名と衝突しない。
    '自動削除も全出力停止も行わず、今回作成するパスだけを検証する。
    MkDir stageFolderPath
    stageCreated = True
    cashPath = CombinePath(stageFolderPath, EXPORT_FILE_CASH)
    balancePath = CombinePath(stageFolderPath, EXPORT_FILE_BALANCE)
    manifestPath = CombinePath(stageFolderPath, EXPORT_FILE_MANIFEST)

    Application.StatusBar = "最終成果物を出力中..."
    ExportOneSheetAsXlsx GetSheet(cashSheetName), "01_資金操作表", cashPath
    ExportOneSheetAsXlsx GetSheet(balanceSheetName), "02_残高推移表", balancePath
    WriteExportManifest manifestPath, cashPath, balancePath
    PublishExportPackage stageFolderPath, packageFolderPath, pairCommitted
    stageCreated = False
    stageFolderPath = vbNullString

    'ブックへの最終結果表示もイベント停止中に完了させる。
    reportingDetail = vbNullString
    TrySetFinalExportStatus _
        "最終成果物を完成フォルダーへ出力しました。", False, reportingDetail
    If Len(reportingDetail) > 0 Then _
        Err.Raise vbObjectError + 5251, "ExportFinalWorkbooks", reportingDetail
    operationSucceeded = True

CLEAN_EXIT:
    'この入口が開始したApplication leaseだけを一度閉じる。AppBeginが失敗した
    '経路では未所有のleaseをAppEnd/AppForceRestoreで巻き戻さない。
    FinishFinalExportApplicationLease _
        applicationLeaseStarted, "ExportFinalWorkbooks/NormalExit", _
        0, "ExportFinalWorkbooks", "正常終了処理"
    RestoreFinalExportEntryEventsOrTerminate _
        entryEvents, "ExportFinalWorkbooks/NormalExit", _
        0, "ExportFinalWorkbooks", "正常終了時のイベントlease復元"

    If Not operationSucceeded Then Exit Sub
    MsgBox "マクロなしのExcelファイルを出力しました。" & vbCrLf & vbCrLf & _
           "01_資金操作表.xlsx" & vbCrLf & _
           "02_残高推移表.xlsx" & vbCrLf & vbCrLf & _
           "出力確認.txt" & vbCrLf & vbCrLf & _
           "保存先: " & packageFolderPath, vbInformation, "最終成果物出力"
    Exit Sub

EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    Err.Clear

    '下位層が既にRecoveryを試行した終端エラーは、この入口でも終端である。
    '外部成果物・ブック・Applicationへ触れず、freshなFalse exactだけを試して伝播する。
    If IsFinalExportUpstreamRecoveryFatal(errorNumber, errorSource) Then
        RethrowFinalExportRecoveryFatal _
            errorNumber, errorSource, errorDescription
    End If

    '失敗復旧の最初にFalseをexact確認する。開始値が不明、またはFalseを確認
    'できない場合は、ブック・Application・外部成果物へ以後一切触れない。
    cleanupEventsStopped = _
        TrySetFinalExportEnableEventsExact(False, eventDetail)
    If Not entryEventsCaptured Or Not cleanupEventsStopped Then
        If Not entryEventsCaptured Then _
            AppendFinalExportCleanupDetail eventDetail, _
                "Excelイベントの開始状態を取得できていません。"
        RaiseFinalExportRecoveryFatal _
            "ExportFinalWorkbooks/EventGate", errorNumber, errorSource, _
            errorDescription, _
            "失敗復旧開始時にExcelイベントFalseを一意に確認できません: " & _
            eventDetail
    End If

    '完成フォルダー公開後は外部成果物を巻き戻さない。未公開時だけ今回所有する
    'ステージを後始末する（外部ファイル操作であり、ブックへは書き込まない）。
    If Not pairCommitted And stageCreated And Len(stageFolderPath) > 0 Then _
        CleanupExportStage stageFolderPath, cleanupDetail

    '正常に開始できたleaseだけを閉じる。AppEnd失敗時に限り、今回所有する
    '捕捉済み状態へAppForceRestoreを一度だけ試す。復元不能ならここで終端化する。
    FinishFinalExportApplicationLease _
        applicationLeaseStarted, "ExportFinalWorkbooks/ErrorExit", _
        errorNumber, errorSource, errorDescription

    'Application復元後、診断を書き込む直前にもFalseをexact確認する。
    If Not TrySetFinalExportEnableEventsExact(False, eventDetail) Then _
        RaiseFinalExportRecoveryFatal _
            "ExportFinalWorkbooks/DiagnosticGate", errorNumber, errorSource, _
            errorDescription, _
            "診断前にExcelイベントFalseを一意に確認できません: " & eventDetail
    reportingDetail = vbNullString
    If pairCommitted Then
        TrySetFinalExportStatus _
            "完成フォルダーは公開済みですが、公開後確認でエラーがありました。移動・削除せずC_チェックを確認してください。", _
            True, reportingDetail
        TryAddFinalExportCheck "エラー", "最終出力後の確認", _
            "完成フォルダー公開後に Err " & CStr(errorNumber) & ": " & _
            errorDescription, reportingDetail
    Else
        If Len(cleanupDetail) > 0 Then _
            TryAddFinalExportCheck "エラー", "最終出力の残留物", _
                                   cleanupDetail, reportingDetail
        If IsUserCancelError(errorNumber) Then
            If Len(cleanupDetail) > 0 Then
                TrySetFinalExportStatus _
                    "最終出力を中断しました。作成中フォルダーが残っているため確認してください。", _
                    True, reportingDetail
            Else
                TrySetFinalExportStatus _
                    "最終出力を中断しました。完成フォルダーは公開していません。", _
                    False, reportingDetail
            End If
        Else
            TrySetFinalExportStatus _
                "最終出力に失敗しました。C_チェックを確認してください。", _
                True, reportingDetail
            TryAddFinalExportCheck "エラー", "最終成果物出力", _
                "Err " & CStr(errorNumber) & ": " & errorDescription, reportingDetail
        End If
    End If
    If Len(reportingDetail) > 0 Then _
        AppendFinalExportCleanupDetail cleanupDetail, reportingDetail

    '最後のブック書込みとApplication安全確認が完了した後だけ開始値へ戻す。
    RestoreFinalExportEntryEventsOrTerminate _
        entryEvents, "ExportFinalWorkbooks/ErrorExit", _
        errorNumber, errorSource, errorDescription

    If pairCommitted Then
        MsgBox "完成フォルダーへの公開は完了しています。" & vbCrLf & _
               "ただし、公開直後の確認でエラーが発生しました。" & vbCrLf & _
               "Excel状態は操作開始時へ復元しました。" & vbCrLf & _
               "完成フォルダーを移動・削除せず、現在のブックを上書きしないでください。" & vbCrLf & _
               "Err " & errorNumber & ": " & errorDescription, _
               vbExclamation, "完成フォルダー公開済み・確認が必要です"
        Exit Sub
    End If
    If IsUserCancelError(errorNumber) Then
        If outputsRebuilt Then
            MsgBox "最終出力を中断しました。帳票・分析は最新化済みですが、完成フォルダーは公開していません。" & _
                   IIf(Len(cleanupDetail) > 0, vbCrLf & cleanupDetail, vbNullString), _
                   vbInformation, "出力中断"
        Else
            MsgBox "帳票・分析の再構築を中断しました。更新済みとは扱いません。" & _
                   IIf(Len(cleanupDetail) > 0, vbCrLf & cleanupDetail, vbNullString), _
                   vbInformation, "出力中断"
        End If
        Exit Sub
    End If
    MsgBox "最終成果物の出力中にエラーが発生しました。" & vbCrLf & _
           "Err " & errorNumber & ": " & errorDescription, vbExclamation, "出力エラー"
End Sub

Private Function IsFinalExportUpstreamRecoveryFatal( _
        ByVal errorNumber As Long, ByVal errorSource As String) As Boolean
    Dim sourcePrefix As String

    '3599は共通Recovery、4499は各機能のRecovery終端であり、発生元に
    'かかわらず二度目のRecoveryを禁止するhard barrierである。
    Select Case errorNumber
        Case vbObjectError + 3599, FINAL_EXPORT_RECOVERY_FATAL_ERROR
            IsFinalExportUpstreamRecoveryFatal = True
            Exit Function
        Case vbObjectError + 5191
            sourcePrefix = "AnalysisWorkspaceRecoveryFatal/"
        Case vbObjectError + 5192
            sourcePrefix = "SetupConvergeRecoveryFatal/"
        Case vbObjectError + 5194
            sourcePrefix = "CashAnalysisRecoveryFatal/"
        Case vbObjectError + 5195
            sourcePrefix = "TransactionAnalysisRecoveryFatal/"
        Case vbObjectError + 5196
            sourcePrefix = "CashManualSelectionRecoveryFatal/"
        Case vbObjectError + 5197
            sourcePrefix = "ClearRecoveryFatal/"
        Case Else
            Exit Function
    End Select
    If Len(errorSource) < Len(sourcePrefix) Then Exit Function
    IsFinalExportUpstreamRecoveryFatal = _
        (StrComp(Left$(errorSource, Len(sourcePrefix)), sourcePrefix, _
                 vbBinaryCompare) = 0)
End Function

Private Sub RethrowFinalExportRecoveryFatal( _
        ByVal errorNumber As Long, ByVal errorSource As String, _
        ByVal errorDescription As String)
    Dim eventDetail As String
    '元のNumber/Source/Descriptionを変更しない。終端後に許される操作は
    'freshなイベントFalse収束だけである。
    Call TrySetFinalExportEnableEventsExact(False, eventDetail)
    Err.Raise errorNumber, errorSource, errorDescription
End Sub

Private Sub RaiseFinalExportRecoveryFatal( _
        ByVal operationName As String, _
        ByVal originalErrorNumber As Long, _
        ByVal originalErrorSource As String, _
        ByVal originalErrorDescription As String, _
        ByVal recoveryDetail As String)
    Dim eventDetail As String, fatalDescription As String

    If Not TrySetFinalExportEnableEventsExact(False, eventDetail) Then _
        AppendFinalExportCleanupDetail recoveryDetail, _
            "Recovery終端のExcelイベントFalse収束に失敗しました: " & _
            eventDetail
    fatalDescription = "元エラー Err " & CStr(originalErrorNumber)
    If Len(originalErrorSource) > 0 Then _
        fatalDescription = fatalDescription & " / " & originalErrorSource
    If Len(originalErrorDescription) > 0 Then _
        fatalDescription = fatalDescription & ": " & originalErrorDescription
    If Len(recoveryDetail) > 0 Then _
        fatalDescription = fatalDescription & " / Recovery: " & recoveryDetail
    Err.Raise FINAL_EXPORT_RECOVERY_FATAL_ERROR, _
              FINAL_EXPORT_RECOVERY_FATAL_SOURCE & operationName, _
              fatalDescription
End Sub

Public Function EnsureShopConversionReadyForFinalExport() As Boolean
    Dim ws As Worksheet, lastR As Long, r As Long, dataCount As Long
    Dim statusText As String, resultText As String, codeText As String
    Dim unresolvedCount As Long, firstUnresolvedRow As Long
    Dim targetData As Variant
    If Not SheetExists(SH_SHOP_TARGET) Then
        EnsureShopConversionReadyForFinalExport = True
        Exit Function
    End If
    Set ws = GetSheet(SH_SHOP_TARGET)
    lastR = LastRow(ws, SHOP_TGT_COL_CODE)
    If lastR >= 2 Then
        targetData = ws.Range(ws.Cells(2, 1), ws.Cells(lastR, SHOP_TGT_LAST_COL)).Value2
        dataCount = lastR - 1
    End If
    For r = 1 To dataCount
        codeText = CellText(targetData(r, SHOP_TGT_COL_CODE))
        If Len(codeText) > 0 Then
            statusText = CellText(targetData(r, SHOP_TGT_COL_STATUS))
            resultText = CellText(targetData(r, SHOP_TGT_COL_RESULT))
            If statusText = "確認不要" Then
                '利用者がコード表記のままでよいと明示した行。
            ElseIf statusText = "入力済" And Len(resultText) > 0 And Len(resultText) <= 100 Then
                '変換先を確認済み。
            Else
                unresolvedCount = unresolvedCount + 1
                If firstUnresolvedRow = 0 Then firstUnresolvedRow = r + 1
            End If
        End If
    Next r
    If unresolvedCount = 0 Then
        EnsureShopConversionReadyForFinalExport = True
        Exit Function
    End If

    RequireFinalExportEventsStoppedExact "未確定の取扱店変換一覧を表示する前"
    ws.Visible = xlSheetVisible
    ws.Activate
    SafeSelectCell ws, ws.Cells(firstUnresolvedRow, SHOP_TGT_COL_RESULT).Address(False, False)
    MsgBox "取扱店変換対象に未確定の行が " & unresolvedCount & "件あります。" & vbCrLf & _
           "変換後取扱店を入力するか、コード表記のままでよい行は確認状況を「確認不要」にしてください。" & vbCrLf & _
           "誤提出を防ぐため、提出・印刷処理を中止しました。", _
           vbExclamation, "取扱店の確認が未完了です"
End Function

Private Sub EnsureBaseOutputSheetsForExport( _
        ByRef confirmedAnalysisWorkloadRows As Double)
    '入力・設定・確認欄・出力表の変更はイベントで要更新へ戻す。変更がない時は、
    '高コストな全再分析を省略して構造検査だけを行う。
    Dim structureProblems As String
    RequireFinalExportEventsStoppedExact "最終出力用帳票の同期前"
    If OutputsAreDirty() Then
        MarkOutputsDirty
        BuildCashOperationSheetCore False, True
        BuildBalanceTransitionSheetCore False, True
        BuildBalanceReconciliationCore False, True
        '変換一覧の入力済み内容を引き継いで再整理し、最終出力時点の値を自動反映する。
        BuildShopConversionTargetSheetCore False, True
        ApplyShopConversionCore False, False, True
        BuildTransactionAnalysisSheetsCore False, True, _
                                           confirmedAnalysisWorkloadRows, False
        BuildCashAnalysisViewCore False, False, True
        If Not ValidateAuthoritativeDataStructure(structureProblems, True, False) Then _
            Err.Raise vbObjectError + 6601, "EnsureBaseOutputSheetsForExport", _
                      "最終出力前の中核データ構造が不正です: " & _
                      Left$(Replace(structureProblems, vbCrLf, " / "), 3000)
        RequireFinalExportEventsStoppedExact "最終出力用帳票の確定前"
        MarkOutputsClean
    Else
        '変換済み表はここでも作り直す。途中失敗時に更新済みフラグだけが残らないよう、
        '再構成前に必ず要更新へ戻し、全検査成功後だけ正常へ戻す。
        MarkOutputsDirty
        '資金操作表上部の現在値を、シート移動イベントに依存せず確定する。
        '同じシートからPublicマクロを直接実行しても、現在の判断を取りこぼさない。
        If Not ActiveSheet Is Nothing Then
            If ActiveSheet.Name = SH_OUTPUT_TX Then _
                SyncCashAnalysisPanelReviewToWorkspace
        End If
        CommitPendingAnalysisReviews False, "最終出力前の確認内容を保存"
        '更新済みフラグだけを信用しない。変換一覧の現在値から提出候補を毎回再作成する。
        ApplyShopConversionCore False, False, True
        If Not ValidateAuthoritativeDataStructure(structureProblems, True, False) Then _
            Err.Raise vbObjectError + 6601, "EnsureBaseOutputSheetsForExport", _
                      "最終出力前の中核データ構造が不正です: " & _
                      Left$(Replace(structureProblems, vbCrLf, " / "), 3000)
        RequireFinalExportEventsStoppedExact "最終出力用確認内容の確定前"
        MarkOutputsClean
    End If
End Sub

Private Function GetFinalCashOperationSheetName() As String
    '変換対象があるのに反映済み表が空の場合、通常表へ黙ってフォールバックしない。
    'コードのまま提出する事故を防ぎ、呼出元で明示的なエラーとして扱う。
    If HasWorksheetData(SH_OUTPUT_TX_CONVERTED) Then
        GetFinalCashOperationSheetName = SH_OUTPUT_TX_CONVERTED
    ElseIf Not HasWorksheetData(SH_SHOP_TARGET) And HasWorksheetData(SH_WORK_CASH) Then
        GetFinalCashOperationSheetName = SH_WORK_CASH
    Else
        GetFinalCashOperationSheetName = ""
    End If
End Function

Private Function HasWorksheetData(ByVal sheetName As String) As Boolean
    If Not SheetExists(sheetName) Then Exit Function
    HasWorksheetData = LastUsedRowInSheet(GetSheet(sheetName)) >= 2
End Function

Private Function PickFinalExportFolder() As String
    Dim fd As FileDialog
    Dim defaultPath As String

    defaultPath = ThisWorkbook.Path
    If Len(defaultPath) = 0 Or PathLooksLikeWebUrl(defaultPath) Then _
        defaultPath = Environ$("USERPROFILE") & "\Documents"
    If Len(Dir$(defaultPath, vbDirectory)) = 0 Then _
        defaultPath = Environ$("USERPROFILE") & "\Desktop"

    Set fd = Application.FileDialog(msoFileDialogFolderPicker)
    With fd
        .Title = "最終成果物の保存先を選択してください"
        .AllowMultiSelect = False
        'SharePointのURLやOffice差で初期フォルダーを設定できなくても、
        'フォルダーピッカー自体は利用できるようbest-effortにする。
        On Error Resume Next
        Err.Clear
        .InitialFileName = defaultPath & "\"
        Err.Clear
        On Error GoTo 0
        If .Show <> -1 Then
            PickFinalExportFolder = ""
        Else
            PickFinalExportFolder = CStr(.SelectedItems(1))
        End If
    End With
End Function

Private Function PathLooksLikeWebUrl(ByVal pathText As String) As Boolean
    PathLooksLikeWebUrl = _
        (InStr(1, pathText, "://", vbTextCompare) > 0 Or _
         Left$(LCase$(Trim$(pathText)), 5) = "https")
End Function

Private Sub BuildUniqueExportPackagePaths(ByVal parentFolder As String, _
                                          ByRef stageFolder As String, _
                                          ByRef packageFolder As String)
    Dim token As String, suffixText As String
    Dim n As Long

    token = Format$(Now, "yyyymmdd_hhnnss")
    Do
        If n = 0 Then suffixText = vbNullString Else suffixText = "_" & CStr(n)
        stageFolder = CombinePath(parentFolder, EXPORT_STAGE_PREFIX & token & suffixText)
        packageFolder = CombinePath(parentFolder, EXPORT_FOLDER_PREFIX & token & suffixText)
        If Not ExportPathEntryExists(stageFolder) And _
           Not ExportPathEntryExists(packageFolder) Then Exit Do
        n = n + 1
        If n > 1000 Then _
            Err.Raise vbObjectError + 5230, "BuildUniqueExportPackagePaths", _
                      "重複しない出力フォルダー名を作成できません。保存先を変更してください。"
    Loop
End Sub


Private Function ExportPathEntryExists(ByVal fullPath As String) As Boolean
    Dim entryName As String
    On Error GoTo EH
    entryName = Dir$(fullPath, _
                     vbReadOnly Or vbHidden Or vbSystem Or vbDirectory Or vbArchive)
    ExportPathEntryExists = (Len(entryName) > 0)
    Exit Function
EH:
    Err.Raise vbObjectError + 5232, "ExportPathEntryExists", _
              "出力先の存在確認に失敗しました: " & fullPath & _
              " / Err " & CStr(Err.Number) & ": " & Err.Description
End Function

Private Sub ExportOneSheetAsXlsx(ByVal src As Worksheet, ByVal exportSheetName As String, ByVal savePath As String)
    Dim wbNew As Workbook
    Dim wsNew As Worksheet
    Dim expectedValues As Variant
    Dim expectedRows As Long, expectedColumns As Long
    Dim prevAlerts As Boolean
    Dim srcVisibility As XlSheetVisibility
    Dim errorNumber As Long, errorDescription As String, cleanupDetail As String

    RequireFinalExportEventsStoppedExact exportSheetName & "の複製前"
    If src Is Nothing Then Err.Raise vbObjectError + 5201, "ExportOneSheetAsXlsx", "出力元シートを取得できません。"
    prevAlerts = Application.DisplayAlerts
    srcVisibility = src.Visible
    On Error GoTo EH

    'Sheet.Copyで書式、列幅、ページ設定、ウィンドウ枠固定に近い状態を維持する。
    '新規ブックとして保存するため、元の作業ブックやマクロは壊さない。
    src.Visible = xlSheetVisible
    src.Copy
    Set wbNew = ActiveWorkbook
    src.Visible = srcVisibility
    Set wsNew = wbNew.Worksheets(1)

    wsNew.Name = exportSheetName
    '提出物へ操作ボタンや利用者が誤って置いた図形を持ち込まない。
    DeleteToolShapes wsNew, True
    If wsNew.Shapes.Count > 0 Then _
        Err.Raise vbObjectError + 5213, "ExportOneSheetAsXlsx", _
                  "提出用シートから図形を除去できませんでした。"
    If exportSheetName = "01_資金操作表" Then
        '連携用ID・行種別・入力順は作業ブック内だけに保持し、提出用は固定13列にする。
        wsNew.Columns("N:Q").Delete
        VerifyCashExportSheet wsNew
    ElseIf exportSheetName = "02_残高推移表" Then
        VerifyBalanceExportSheet wsNew
    End If
    expectedRows = LastUsedRowInSheet(wsNew)
    expectedColumns = LastUsedColumnInSheet(wsNew, expectedRows)
    If expectedRows < 1 Or expectedColumns < 1 Then _
        Err.Raise vbObjectError + 5218, "ExportOneSheetAsXlsx", _
                  exportSheetName & "に保存対象の値がありません。"
    expectedValues = wsNew.Range(wsNew.Cells(1, 1), _
                                 wsNew.Cells(expectedRows, expectedColumns)).Value2
    wsNew.Activate
    wsNew.Range("A1").Select

    If Len(Dir$(savePath)) > 0 Then _
        Err.Raise vbObjectError + 5239, "ExportOneSheetAsXlsx", _
                  "作成中フォルダーに同名ファイルが既にあります: " & savePath
    Application.DisplayAlerts = False
    If Application.DisplayAlerts Then _
        Err.Raise vbObjectError + 5238, "ExportOneSheetAsXlsx", _
                  "保存中のExcel確認ダイアログを安全に抑止できません。"
    wbNew.SaveAs Filename:=savePath, FileFormat:=xlOpenXMLWorkbook
    If wbNew.FileFormat <> xlOpenXMLWorkbook Then Err.Raise vbObjectError + 5202, "ExportOneSheetAsXlsx", "xlsx形式で保存できませんでした。"
    RestoreExportWorkbookState src, srcVisibility, wbNew, prevAlerts, cleanupDetail
    If Len(cleanupDetail) > 0 Then _
        Err.Raise vbObjectError + 5237, "ExportOneSheetAsXlsx", cleanupDetail
    If Len(Dir$(savePath)) = 0 Then Err.Raise vbObjectError + 5203, "ExportOneSheetAsXlsx", "出力ファイルが作成されませんでした。"
    If FileLen(savePath) <= 0 Then Err.Raise vbObjectError + 5204, "ExportOneSheetAsXlsx", "出力ファイルのサイズが0です。"
    VerifySavedExportWorkbook savePath, exportSheetName, expectedValues, _
                              expectedRows, expectedColumns
    Exit Sub

EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    cleanupDetail = vbNullString
    RestoreExportWorkbookState src, srcVisibility, wbNew, prevAlerts, cleanupDetail
    If Len(cleanupDetail) > 0 Then _
        errorDescription = errorDescription & " / 終了処理: " & cleanupDetail
    Err.Raise errorNumber, "ExportOneSheetAsXlsx(" & exportSheetName & ")", errorDescription
End Sub

Private Sub RestoreExportWorkbookState(ByVal sourceSheet As Worksheet, _
                                       ByVal sourceVisibility As XlSheetVisibility, _
                                       ByRef exportWorkbook As Workbook, _
                                       ByVal previousDisplayAlerts As Boolean, _
                                       ByRef cleanupDetail As String)
    Dim cleanupErrorNumber As Long, cleanupErrorDescription As String
    Dim restoredVisibility As XlSheetVisibility
    Dim restoredAlerts As Boolean
    Dim eventsStopped As Boolean, eventDetail As String

    cleanupDetail = vbNullString
    If Not exportWorkbook Is Nothing Then
        On Error Resume Next
        Err.Clear
        exportWorkbook.Close SaveChanges:=False
        cleanupErrorNumber = Err.Number
        cleanupErrorDescription = Err.Description
        Err.Clear
        On Error GoTo 0
        If cleanupErrorNumber = 0 Then
            Set exportWorkbook = Nothing
        Else
            AppendFinalExportCleanupDetail cleanupDetail, _
                "作成用ブックを閉じられません（Err " & CStr(cleanupErrorNumber) & _
                ": " & cleanupErrorDescription & "）。"
        End If
    End If

    If Not sourceSheet Is Nothing Then
        eventsStopped = _
            TrySetFinalExportEnableEventsExact(False, eventDetail)
        If Not eventsStopped Then
            AppendFinalExportCleanupDetail cleanupDetail, _
                "出力元シートの表示状態を戻す前にExcelイベント停止を確認できず、" & _
                "ブックへの書込みを見送りました: " & eventDetail
        Else
            On Error Resume Next
            Err.Clear
            sourceSheet.Visible = sourceVisibility
            cleanupErrorNumber = Err.Number
            cleanupErrorDescription = Err.Description
            Err.Clear
            If cleanupErrorNumber = 0 Then
                restoredVisibility = sourceSheet.Visible
                cleanupErrorNumber = Err.Number
                cleanupErrorDescription = Err.Description
            End If
            Err.Clear
            On Error GoTo 0
            If cleanupErrorNumber <> 0 Or restoredVisibility <> sourceVisibility Then
                AppendFinalExportCleanupDetail cleanupDetail, _
                    "出力元シートの表示状態を復元できません" & _
                    IIf(cleanupErrorNumber <> 0, "（Err " & CStr(cleanupErrorNumber) & _
                        ": " & cleanupErrorDescription & "）", vbNullString) & "。"
            End If
        End If
    End If

    On Error Resume Next
    Err.Clear
    Application.DisplayAlerts = previousDisplayAlerts
    cleanupErrorNumber = Err.Number
    cleanupErrorDescription = Err.Description
    Err.Clear
    If cleanupErrorNumber = 0 Then
        restoredAlerts = Application.DisplayAlerts
        cleanupErrorNumber = Err.Number
        cleanupErrorDescription = Err.Description
    End If
    Err.Clear
    On Error GoTo 0
    If cleanupErrorNumber <> 0 Or restoredAlerts <> previousDisplayAlerts Then
        AppendFinalExportCleanupDetail cleanupDetail, _
            "Excelの警告表示状態を復元できません" & _
            IIf(cleanupErrorNumber <> 0, "（Err " & CStr(cleanupErrorNumber) & _
                ": " & cleanupErrorDescription & "）", vbNullString) & "。"
    End If
End Sub

Private Sub VerifySavedExportWorkbook(ByVal savePath As String, ByVal expectedSheetName As String, _
                                      ByRef expectedValues As Variant, _
                                      ByVal expectedRows As Long, ByVal expectedColumns As Long)
    Dim wbCheck As Workbook, wsCheck As Worksheet
    Dim actualRows As Long, actualColumns As Long
    Dim errorNumber As Long, errorDescription As String, cleanupDetail As String

    On Error GoTo EH
    '出力はxlOpenXMLWorkbookで保存済みで、下でHasVBProject=Falseも確認する。
    '管理対象のExcel全体のAutomationSecurityを変更せず、読取専用で再オープンする。
    Set wbCheck = Application.Workbooks.Open( _
        Filename:=savePath, UpdateLinks:=0, ReadOnly:=True, _
        IgnoreReadOnlyRecommended:=True, AddToMru:=False, _
        CorruptLoad:=xlNormalLoad)
    If wbCheck Is Nothing Then _
        Err.Raise vbObjectError + 5219, "VerifySavedExportWorkbook", _
                  "保存後の再オープンに失敗しました: " & expectedSheetName
    If Not wbCheck.ReadOnly Then _
        Err.Raise vbObjectError + 5220, "VerifySavedExportWorkbook", _
                  "保存後検査を読み取り専用で実行できませんでした: " & expectedSheetName
    If wbCheck.FileFormat <> xlOpenXMLWorkbook Then _
        Err.Raise vbObjectError + 5221, "VerifySavedExportWorkbook", _
                  "保存後のファイル形式がxlsxではありません: " & expectedSheetName
    If wbCheck.HasVBProject Then _
        Err.Raise vbObjectError + 5225, "VerifySavedExportWorkbook", _
                  "提出用ブックにVBAプロジェクトが残っています: " & expectedSheetName
    If wbCheck.Worksheets.Count <> 1 Then _
        Err.Raise vbObjectError + 5222, "VerifySavedExportWorkbook", _
                  "提出用ブックのシート数が1ではありません: " & expectedSheetName
    Set wsCheck = wbCheck.Worksheets(1)
    If StrComp(wsCheck.Name, expectedSheetName, vbBinaryCompare) <> 0 Then _
        Err.Raise vbObjectError + 5223, "VerifySavedExportWorkbook", _
                  "保存後のシート名が一致しません: " & wsCheck.Name
    EnsureExportWorkbookHasNoExternalDependencies wbCheck, expectedSheetName

    actualRows = LastUsedRowInSheet(wsCheck)
    actualColumns = LastUsedColumnInSheet(wsCheck, actualRows)
    If actualRows <> expectedRows Or actualColumns <> expectedColumns Then _
        Err.Raise vbObjectError + 5224, "VerifySavedExportWorkbook", _
                  "保存後の出力範囲が一致しません: " & expectedSheetName & _
                  "（期待 " & CStr(expectedRows) & "行×" & CStr(expectedColumns) & _
                  "列 / 実値 " & CStr(actualRows) & "行×" & CStr(actualColumns) & "列）"
    EnsureExportHasNoFormulas wsCheck, "保存後の" & expectedSheetName
    VerifyGeneratedRangeValue2 wsCheck, expectedValues, 1, 1, expectedRows, _
                               expectedColumns, "保存後の" & expectedSheetName, True

    CloseVerificationWorkbook wbCheck, cleanupDetail
    If Len(cleanupDetail) > 0 Then _
        Err.Raise vbObjectError + 5234, "VerifySavedExportWorkbook", cleanupDetail
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    cleanupDetail = vbNullString
    If Not wbCheck Is Nothing Then CloseVerificationWorkbook wbCheck, cleanupDetail
    If Len(cleanupDetail) > 0 Then _
        errorDescription = errorDescription & " / 終了処理: " & cleanupDetail
    Err.Raise errorNumber, "VerifySavedExportWorkbook(" & expectedSheetName & ")", errorDescription
End Sub

Private Sub RaiseExportExternalDependency(ByVal workbookLabel As String, _
                                          ByVal dependencyDetail As String)
    Err.Raise vbObjectError + 5240, "EnsureExportWorkbookHasNoExternalDependencies", _
              "保存後の" & workbookLabel & "に外部依存が残っています: " & dependencyDetail
End Sub

Private Function ExportReferenceLooksExternal(ByVal referenceText As String) As Boolean
    Dim normalizedText As String
    Dim bracketOpen As Long, bracketClose As Long, bracketText As String
    normalizedText = LCase$(Trim$(referenceText))
    If Len(normalizedText) = 0 Then Exit Function
    bracketOpen = InStr(1, normalizedText, "[", vbBinaryCompare)
    If bracketOpen > 0 Then _
        bracketClose = InStr(bracketOpen + 1, normalizedText, "]", vbBinaryCompare)
    If bracketClose > bracketOpen Then _
        bracketText = Mid$(normalizedText, bracketOpen + 1, _
                           bracketClose - bracketOpen - 1)
    '内部テーブルの構造化参照[列名]は許可し、外部ブック名だけを拒否する。
    If InStr(1, bracketText, ".xls", vbBinaryCompare) > 0 Or _
       InStr(1, normalizedText, "http://", vbBinaryCompare) > 0 Or _
       InStr(1, normalizedText, "https://", vbBinaryCompare) > 0 Or _
       InStr(1, normalizedText, "ftp://", vbBinaryCompare) > 0 Or _
       InStr(1, normalizedText, "file://", vbBinaryCompare) > 0 Or _
       InStr(1, normalizedText, "\\", vbBinaryCompare) > 0 Or _
       InStr(1, normalizedText, ":\", vbBinaryCompare) > 0 Or _
       InStr(1, normalizedText, ":/", vbBinaryCompare) > 0 Or _
       InStr(1, normalizedText, "|", vbBinaryCompare) > 0 Or _
       InStr(1, normalizedText, "odbc;", vbBinaryCompare) > 0 Or _
       InStr(1, normalizedText, "oledb;", vbBinaryCompare) > 0 Or _
       InStr(1, normalizedText, "#ref!", vbBinaryCompare) > 0 Then _
        ExportReferenceLooksExternal = True
End Function

Private Function TryGetOptionalExportObject(ByVal ownerObject As Object, _
                                            ByVal propertyName As String, _
                                            ByRef resultObject As Object) As Boolean
    Set resultObject = Nothing
    If ownerObject Is Nothing Then Exit Function
    Dim errorNumber As Long, errorDescription As String
    On Error GoTo PropertyFailed
    Set resultObject = CallByName(ownerObject, propertyName, VbGet)
    TryGetOptionalExportObject = True
    Exit Function
PropertyFailed:
    errorNumber = Err.Number
    errorDescription = Err.Description
    Set resultObject = Nothing
    '旧Excelでメンバー自体がない438だけを「API未対応」とする。
    '権限・COM状態・破損など別の失敗を0件へ読み替えない。
    If errorNumber <> 438 Then _
        Err.Raise errorNumber, "TryGetOptionalExportObject(" & propertyName & ")", _
                  errorDescription
    Err.Clear
End Function

Private Function OptionalExportCollectionCount(ByVal ownerObject As Object, _
                                               ByVal propertyName As String, _
                                               ByRef propertySupported As Boolean) As Long
    Dim collectionObject As Object
    Dim errorNumber As Long, errorDescription As String
    propertySupported = False
    If Not TryGetOptionalExportObject(ownerObject, propertyName, collectionObject) Then Exit Function
    propertySupported = True
    If collectionObject Is Nothing Then Exit Function
    On Error GoTo CountFailed
    OptionalExportCollectionCount = CLng(CallByName(collectionObject, "Count", VbGet))
    Exit Function
CountFailed:
    errorNumber = Err.Number
    errorDescription = Err.Description
    Err.Raise errorNumber, "OptionalExportCollectionCount(" & propertyName & ")", _
              errorDescription
End Function

Private Sub EnsureExportWorkbookHasNoExternalDependencies( _
        ByVal workbookToInspect As Workbook, ByVal workbookLabel As String)
    Dim linkItems As Variant
    Dim worksheetItem As Worksheet
    Dim nameItem As Name
    Dim hyperlinkItem As Hyperlink
    Dim listItem As ListObject
    Dim modelObject As Object
    Dim optionalSupported As Boolean
    Dim optionalCount As Long
    Dim errorNumber As Long, errorDescription As String

    On Error GoTo InspectionFailed
    If workbookToInspect Is Nothing Then _
        Err.Raise vbObjectError + 5241, _
                  "EnsureExportWorkbookHasNoExternalDependencies", _
                  "保存後ブックを取得できません。"

    linkItems = workbookToInspect.LinkSources(Type:=xlExcelLinks)
    If Not IsEmpty(linkItems) Then _
        RaiseExportExternalDependency workbookLabel, "Excelブックリンク"
    linkItems = workbookToInspect.LinkSources(Type:=xlOLELinks)
    If Not IsEmpty(linkItems) Then _
        RaiseExportExternalDependency workbookLabel, "OLEリンク"

    If workbookToInspect.Connections.Count > 0 Then _
        RaiseExportExternalDependency workbookLabel, "ブック接続"
    If workbookToInspect.PivotCaches.Count > 0 Then _
        RaiseExportExternalDependency workbookLabel, "PivotCache"
    optionalCount = OptionalExportCollectionCount( _
                        workbookToInspect, "Queries", optionalSupported)
    If optionalSupported And optionalCount > 0 Then _
        RaiseExportExternalDependency workbookLabel, "Power Query"

    For Each nameItem In workbookToInspect.Names
        If ExportReferenceLooksExternal(CStr(nameItem.RefersTo)) Then _
            RaiseExportExternalDependency workbookLabel, _
                "外部参照または破損参照の名前: " & nameItem.Name
    Next nameItem

    For Each worksheetItem In workbookToInspect.Worksheets
        For Each nameItem In worksheetItem.Names
            If ExportReferenceLooksExternal(CStr(nameItem.RefersTo)) Then _
                RaiseExportExternalDependency workbookLabel, _
                    "外部参照または破損参照のシート名: " & nameItem.Name
        Next nameItem
        If worksheetItem.QueryTables.Count > 0 Then _
            RaiseExportExternalDependency workbookLabel, _
                "QueryTable: " & worksheetItem.Name
        If worksheetItem.OLEObjects.Count > 0 Then _
            RaiseExportExternalDependency workbookLabel, _
                "OLEObject: " & worksheetItem.Name
        For Each hyperlinkItem In worksheetItem.Hyperlinks
            If Len(CellText(hyperlinkItem.Address)) > 0 Or _
               ExportReferenceLooksExternal(CellText(hyperlinkItem.SubAddress)) Then _
                RaiseExportExternalDependency workbookLabel, _
                    "外部ハイパーリンク: " & worksheetItem.Name
        Next hyperlinkItem
        For Each listItem In worksheetItem.ListObjects
            If listItem.SourceType <> xlSrcRange Then _
                RaiseExportExternalDependency workbookLabel, _
                    "外部ソースのListObject: " & listItem.Name
        Next listItem
        '提出帳票にPivotTableは不要であり、外部PivotCacheを判別不能な状態で通さない。
        If worksheetItem.PivotTables.Count > 0 Then _
            RaiseExportExternalDependency workbookLabel, _
                "PivotTableまたはPivotCache: " & worksheetItem.Name
    Next worksheetItem

    'Queries/ModelはExcel版によりAPI自体がない。作成元は単一シートCopyで、
    '上のリンク・接続・QueryTable・Pivot検査を通過済みなので、未対応APIは0件相当。
    If TryGetOptionalExportObject(workbookToInspect, "Model", modelObject) Then
        If Not modelObject Is Nothing Then
            optionalCount = OptionalExportCollectionCount( _
                                modelObject, "ModelTables", optionalSupported)
            If optionalSupported And optionalCount > 0 Then _
                RaiseExportExternalDependency workbookLabel, "Data Model table"
            optionalCount = OptionalExportCollectionCount( _
                                modelObject, "ModelRelationships", optionalSupported)
            If optionalSupported And optionalCount > 0 Then _
                RaiseExportExternalDependency workbookLabel, "Data Model relationship"
        End If
    End If
    Exit Sub

InspectionFailed:
    errorNumber = Err.Number
    errorDescription = Err.Description
    If errorNumber = vbObjectError + 5240 Then _
        Err.Raise errorNumber, "EnsureExportWorkbookHasNoExternalDependencies", _
                  errorDescription
    Err.Raise vbObjectError + 5241, _
              "EnsureExportWorkbookHasNoExternalDependencies", _
              "保存後の" & workbookLabel & _
              "について外部依存ゼロを確認できません。Err " & _
              CStr(errorNumber) & ": " & errorDescription
End Sub


Private Sub CloseVerificationWorkbook(ByRef workbookToClose As Workbook, _
                                      ByRef cleanupDetail As String)
    Dim closeErrorNumber As Long, closeErrorDescription As String

    cleanupDetail = vbNullString
    If Not workbookToClose Is Nothing Then
        On Error Resume Next
        Err.Clear
        workbookToClose.Close SaveChanges:=False
        closeErrorNumber = Err.Number
        closeErrorDescription = Err.Description
        Err.Clear
        On Error GoTo 0
        If closeErrorNumber = 0 Then
            Set workbookToClose = Nothing
        Else
            AppendFinalExportCleanupDetail cleanupDetail, _
                "検査用ブックを閉じられません（Err " & CStr(closeErrorNumber) & _
                ": " & closeErrorDescription & "）。"
        End If
    End If

End Sub

Private Sub VerifyCashExportSheet(ByVal ws As Worksheet)
    Dim expected As Variant, i As Long
    Dim lastValueCol As Long, lastValueRow As Long
    expected = Array("銀行名", "支店名", "氏名", "科目", "口座番号", "日付", "時刻", "出金", "入金", "取扱店", "機番", "摘要欄", "残高")
    For i = LBound(expected) To UBound(expected)
        If CellText(ws.Cells(1, i + 1).Value) <> CStr(expected(i)) Then
            Err.Raise vbObjectError + 5205, "VerifyCashExportSheet", "提出用見出しが不正です: " & ws.Cells(1, i + 1).Address(False, False)
        End If
    Next i
    lastValueCol = LastUsedColumnInSheet(ws, LastUsedRowInSheet(ws))
    If lastValueCol > OUT_COL_OTHER Then
        Err.Raise vbObjectError + 5206, "VerifyCashExportSheet", "提出用資金操作表に内部列が残っています。"
    End If
    lastValueRow = LastUsedRowInSheet(ws)
    ApplyPrintAreaVerified ws, ws.Range(ws.Cells(1, 1), _
                                        ws.Cells(lastValueRow, OUT_COL_OTHER)), True
    ApplyReadablePrintSettings ws, "$1:$1", 1, "", True
    EnsureExportHasNoFormulas ws, "提出用資金操作表"
End Sub


Private Function TryGetFinalExportEnableEvents( _
        ByRef currentValue As Boolean, _
        ByRef detailText As String) As Boolean
    Dim errorNumber As Long, errorDescription As String
    detailText = vbNullString
    On Error GoTo EH
    currentValue = Application.EnableEvents
    TryGetFinalExportEnableEvents = True
    Exit Function
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    detailText = "Err " & CStr(errorNumber) & ": " & errorDescription
    Err.Clear
End Function

Private Function TrySetFinalExportEnableEventsExact( _
        ByVal desiredValue As Boolean, _
        ByRef detailText As String) As Boolean
    Dim errorNumber As Long, errorDescription As String
    detailText = vbNullString
    On Error GoTo EH
    Application.EnableEvents = desiredValue
    If Application.EnableEvents <> desiredValue Then _
        Err.Raise vbObjectError + 5248, _
                  "TrySetFinalExportEnableEventsExact", _
                  "EnableEventsの書込み後読戻しが一致しません。"
    TrySetFinalExportEnableEventsExact = True
    Exit Function
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    detailText = "Err " & CStr(errorNumber) & ": " & errorDescription
    Err.Clear
End Function

Private Sub RequireFinalExportEventsStoppedExact(ByVal operationName As String)
    Dim detailText As String
    If Not TrySetFinalExportEnableEventsExact(False, detailText) Then _
        Err.Raise vbObjectError + 5252, _
                  "RequireFinalExportEventsStoppedExact", _
                  operationName & "にExcelイベント停止を読戻し確認できません。 " & _
                  detailText
End Sub

Private Sub EnterFinalExportRecoveryStateTerminal( _
        ByVal operationName As String, _
        ByVal reasonText As String, _
        ByVal originalErrorNumber As Long, _
        ByVal originalErrorSource As String, _
        ByVal originalErrorDescription As String)
    Dim workingDetail As String, eventDetail As String
    Dim enforceErrorNumber As Long, enforceErrorDescription As String
    Dim enforceErrorSource As String, eventsStopped As Boolean

    If Not TrySetFinalExportEnableEventsExact(False, eventDetail) Then _
        RaiseFinalExportRecoveryFatal _
            operationName, originalErrorNumber, originalErrorSource, _
            originalErrorDescription, _
            "Recovery書込み前にExcelイベントFalseを確認できません: " & _
            eventDetail

    workingDetail = reasonText
    On Error Resume Next
    Err.Clear
    EnforceRollbackRecoveryState workingDetail
    enforceErrorNumber = Err.Number
    enforceErrorSource = Err.Source
    enforceErrorDescription = Err.Description
    Err.Clear
    '中央Enforceは成功・失敗とも3599で終端する。返却直後は判定や
    'Recovery読戻しより先に、許可される唯一の操作であるfresh Falseを行う。
    eventsStopped = TrySetFinalExportEnableEventsExact(False, eventDetail)
    On Error GoTo 0

    If enforceErrorNumber <> 0 Then
        AppendFinalExportCleanupDetail workingDetail, _
            "要復旧処理終端: Err " & CStr(enforceErrorNumber) & " " & _
            enforceErrorDescription
        If Len(enforceErrorSource) > 0 Then _
            AppendFinalExportCleanupDetail workingDetail, _
                "要復旧処理発生元: " & enforceErrorSource
    Else
        AppendFinalExportCleanupDetail workingDetail, _
            "共通Recovery処理が終端エラーを返さず終了しました。"
    End If
    If Not eventsStopped Then _
        AppendFinalExportCleanupDetail workingDetail, _
            "要復旧処理直後のExcelイベントFalse収束にも失敗しました: " & _
            eventDetail
    RaiseFinalExportRecoveryFatal _
        operationName, originalErrorNumber, originalErrorSource, _
        originalErrorDescription, workingDetail
End Sub

Private Sub FinishFinalExportApplicationLease( _
        ByRef applicationLeaseStarted As Boolean, _
        ByVal operationName As String, _
        ByVal originalErrorNumber As Long, _
        ByVal originalErrorSource As String, _
        ByVal originalErrorDescription As String)
    Dim appEndErrorNumber As Long, appEndErrorSource As String
    Dim appEndErrorDescription As String
    Dim forceErrorNumber As Long, forceErrorSource As String
    Dim forceErrorDescription As String
    Dim stateErrorNumber As Long, stateErrorDescription As String
    Dim stateProblems As String, eventDetail As String, recoveryDetail As String
    Dim applicationStateSafe As Boolean, eventsStopped As Boolean

    If applicationLeaseStarted Then
        On Error Resume Next
        Err.Clear
        AppEnd
        appEndErrorNumber = Err.Number
        appEndErrorSource = Err.Source
        appEndErrorDescription = Err.Description
        Err.Clear
        eventsStopped = TrySetFinalExportEnableEventsExact(False, eventDetail)
        On Error GoTo 0
        '一度AppEndを呼んだ所有権を再利用しない。失敗時の再試行は
        '今回所有していた捕捉済み状態に対するAppForceRestoreだけである。
        applicationLeaseStarted = False
        If Not eventsStopped Then _
            RaiseFinalExportRecoveryFatal _
                operationName, originalErrorNumber, originalErrorSource, _
                originalErrorDescription, _
                "AppEnd直後のExcelイベントFalseを確認できません: " & _
                eventDetail

        If appEndErrorNumber <> 0 Then
            On Error Resume Next
            Err.Clear
            AppForceRestore
            forceErrorNumber = Err.Number
            forceErrorSource = Err.Source
            forceErrorDescription = Err.Description
            Err.Clear
            eventsStopped = _
                TrySetFinalExportEnableEventsExact(False, eventDetail)
            On Error GoTo 0
            If Not eventsStopped Then _
                RaiseFinalExportRecoveryFatal _
                    operationName, originalErrorNumber, originalErrorSource, _
                    originalErrorDescription, _
                    "所有leaseの強制復元直後にExcelイベントFalseを確認できません: " & _
                    eventDetail
            If forceErrorNumber <> 0 Then
                recoveryDetail = "AppEnd Err " & CStr(appEndErrorNumber) & _
                                 " " & appEndErrorDescription & _
                                 " / AppForceRestore Err " & _
                                 CStr(forceErrorNumber) & " " & _
                                 forceErrorDescription
                If Len(appEndErrorSource) > 0 Then _
                    AppendFinalExportCleanupDetail recoveryDetail, _
                        "AppEnd発生元: " & appEndErrorSource
                If Len(forceErrorSource) > 0 Then _
                    AppendFinalExportCleanupDetail recoveryDetail, _
                        "AppForceRestore発生元: " & forceErrorSource
                EnterFinalExportRecoveryStateTerminal _
                    operationName, recoveryDetail, originalErrorNumber, _
                    originalErrorSource, originalErrorDescription
            End If
        End If
    Else
        'AppBegin未成功の経路ではAppEnd/AppForceRestoreを呼ばない。
        If Not TrySetFinalExportEnableEventsExact(False, eventDetail) Then _
            RaiseFinalExportRecoveryFatal _
                operationName, originalErrorNumber, originalErrorSource, _
                originalErrorDescription, _
                "Application状態確認前にExcelイベントFalseを確認できません: " & _
                eventDetail
    End If

    On Error Resume Next
    Err.Clear
    stateProblems = vbNullString
    applicationStateSafe = AppStateIsRestored(stateProblems)
    stateErrorNumber = Err.Number
    stateErrorDescription = Err.Description
    Err.Clear
    'Application読戻し後、成否判定より先にfresh Falseを再確定する。
    eventsStopped = TrySetFinalExportEnableEventsExact(False, eventDetail)
    On Error GoTo 0
    If Not eventsStopped Then _
        RaiseFinalExportRecoveryFatal _
            operationName, originalErrorNumber, originalErrorSource, _
            originalErrorDescription, _
            "Application状態読戻し後のExcelイベントFalseを確認できません: " & _
            eventDetail
    If stateErrorNumber <> 0 Or Not applicationStateSafe Then
        recoveryDetail = "Application状態を安全に復元済みと確認できません。"
        If stateErrorNumber <> 0 Then _
            AppendFinalExportCleanupDetail recoveryDetail, _
                "読戻しエラー: Err " & CStr(stateErrorNumber) & " " & _
                stateErrorDescription
        If Len(stateProblems) > 0 Then _
            AppendFinalExportCleanupDetail recoveryDetail, stateProblems
        EnterFinalExportRecoveryStateTerminal _
            operationName, recoveryDetail, originalErrorNumber, _
            originalErrorSource, originalErrorDescription
    End If
End Sub

Private Sub RestoreFinalExportEntryEventsOrTerminate( _
        ByVal entryValue As Boolean, _
        ByVal operationName As String, _
        ByVal originalErrorNumber As Long, _
        ByVal originalErrorSource As String, _
        ByVal originalErrorDescription As String)
    Dim firstDetail As String, retryDetail As String, eventDetail As String
    Dim stateProblems As String, recoveryDetail As String
    Dim stateErrorNumber As Long, stateErrorDescription As String
    Dim applicationStateSafe As Boolean, eventsStopped As Boolean

    If Not TrySetFinalExportEnableEventsExact(False, eventDetail) Then _
        RaiseFinalExportRecoveryFatal _
            operationName, originalErrorNumber, originalErrorSource, _
            originalErrorDescription, _
            "開始値復元前のExcelイベントFalseを確認できません: " & eventDetail

    'Trueへ戻す場合だけ、Application状態の完全復元を独立に読戻す。
    If entryValue Then
        On Error Resume Next
        Err.Clear
        stateProblems = vbNullString
        applicationStateSafe = AppStateIsRestored(stateProblems)
        stateErrorNumber = Err.Number
        stateErrorDescription = Err.Description
        Err.Clear
        eventsStopped = TrySetFinalExportEnableEventsExact(False, eventDetail)
        On Error GoTo 0
        If Not eventsStopped Then _
            RaiseFinalExportRecoveryFatal _
                operationName, originalErrorNumber, originalErrorSource, _
                originalErrorDescription, _
                "開始値復元前のApplication読戻し後にイベントFalseを確認できません: " & _
                eventDetail
        If stateErrorNumber <> 0 Or Not applicationStateSafe Then
            recoveryDetail = "開始時イベントTrueへ戻す前にApplication状態を確認できません。"
            If stateErrorNumber <> 0 Then _
                AppendFinalExportCleanupDetail recoveryDetail, _
                    "読戻しエラー: Err " & CStr(stateErrorNumber) & " " & _
                    stateErrorDescription
            If Len(stateProblems) > 0 Then _
                AppendFinalExportCleanupDetail recoveryDetail, stateProblems
            EnterFinalExportRecoveryStateTerminal _
                operationName, recoveryDetail, originalErrorNumber, _
                originalErrorSource, originalErrorDescription
        End If
    End If

    'この代入が最後の操作である。成功後はブック・Application・状態確認へ戻らない。
    If TrySetFinalExportEnableEventsExact(entryValue, firstDetail) Then Exit Sub
    If TrySetFinalExportEnableEventsExact(entryValue, retryDetail) Then Exit Sub

    recoveryDetail = "Excelイベントを開始値へ復元できません。初回=" & _
                     firstDetail & " / 再試行=" & retryDetail
    If Not TrySetFinalExportEnableEventsExact(False, eventDetail) Then _
        RaiseFinalExportRecoveryFatal _
            operationName, originalErrorNumber, originalErrorSource, _
            originalErrorDescription, recoveryDetail & _
            " / False安全停止にも失敗しました: " & eventDetail
    If Not entryValue Then Exit Sub

    EnterFinalExportRecoveryStateTerminal _
        operationName, recoveryDetail, originalErrorNumber, _
        originalErrorSource, originalErrorDescription
End Sub

Private Sub TrySetFinalExportStatus( _
        ByVal messageText As String, ByVal isError As Boolean, _
        ByRef detailText As String)
    Dim errorNumber As Long, errorDescription As String
    Dim eventDetail As String
    If Not TrySetFinalExportEnableEventsExact(False, eventDetail) Then
        AppendFinalExportCleanupDetail detailText, _
            "状態表示前にExcelイベント停止を確認できないため、書込みを見送りました: " & _
            eventDetail
        Exit Sub
    End If
    On Error GoTo EH
    SetInputStatus messageText, isError
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    AppendFinalExportCleanupDetail detailText, _
        "入力画面へ結果を表示できません（Err " & CStr(errorNumber) & _
        ": " & errorDescription & "）。"
    Err.Clear
End Sub

Private Sub TryAddFinalExportCheck( _
        ByVal categoryText As String, ByVal sourceText As String, _
        ByVal messageText As String, ByRef detailText As String)
    Dim errorNumber As Long, errorDescription As String
    Dim eventDetail As String
    If Not TrySetFinalExportEnableEventsExact(False, eventDetail) Then
        AppendFinalExportCleanupDetail detailText, _
            "診断記録前にExcelイベント停止を確認できないため、書込みを見送りました: " & _
            eventDetail
        Exit Sub
    End If
    On Error GoTo EH
    If Not SheetExists(SH_CHECK) Then
        AppendFinalExportCleanupDetail detailText, _
            "C_チェックがないため診断を記録できません。"
        Exit Sub
    End If
    AddCheck categoryText, sourceText, messageText
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    AppendFinalExportCleanupDetail detailText, _
        "C_チェックへ診断を記録できません（Err " & _
        CStr(errorNumber) & ": " & errorDescription & "）。"
    Err.Clear
End Sub

Private Sub VerifyBalanceExportSheet(ByVal ws As Worksheet)
    Dim lastValueCol As Long, lastValueRow As Long
    Dim balancePointCount As Long, printPagesWide As Long
    If CellText(ws.Range("A1").Value) <> "残高推移表" Then
        Err.Raise vbObjectError + 5207, "VerifyBalanceExportSheet", "提出用残高推移表のタイトルが不正です。"
    End If
    lastValueCol = LastUsedColumnInSheet(ws, LastUsedRowInSheet(ws))
    If lastValueCol > 7 + BAL_MAX_LABELS Then
        Err.Raise vbObjectError + 5208, "VerifyBalanceExportSheet", "提出用残高推移表の列数が上限を超えています。"
    End If
    lastValueRow = LastUsedRowInSheet(ws)
    balancePointCount = Application.Max(0, lastValueCol - 7)
    If balancePointCount <= 4 Then
        printPagesWide = 1
    ElseIf balancePointCount <= 8 Then
        printPagesWide = 2
    Else
        printPagesWide = 3
    End If
    ApplyPrintAreaVerified ws, ws.Range(ws.Cells(1, 1), _
                                        ws.Cells(lastValueRow, lastValueCol)), True
    ApplyReadablePrintSettings ws, "$1:$1", printPagesWide, "$A:$F", True
    EnsureExportHasNoFormulas ws, "提出用残高推移表"
End Sub

Private Sub EnsureExportHasNoFormulas(ByVal ws As Worksheet, ByVal labelText As String)
    Dim scanRange As Range
    Dim formulaCell As Range
    Dim errorCell As Range
    Dim lastValueRow As Long, lastValueColumn As Long
    If ws Is Nothing Then Exit Sub
    '列全体へ書式が付いた帳票でも、1,048,576行を走査しない。値・数式を基準に
    '確定した実出力範囲だけを全セル検査する。
    lastValueRow = LastUsedRowInSheet(ws)
    If lastValueRow < 1 Then Exit Sub
    lastValueColumn = LastUsedColumnInSheet(ws, lastValueRow)
    If lastValueColumn < 1 Then Exit Sub
    Set scanRange = ws.Range(ws.Cells(1, 1), _
                             ws.Cells(lastValueRow, lastValueColumn))
    If Not TryFindFirstFormulaCell(scanRange, formulaCell) Then
        Err.Raise vbObjectError + 5226, "EnsureExportHasNoFormulas", _
                  labelText & "の数式有無を検査できません。"
    End If
    If Not formulaCell Is Nothing Then
        Err.Raise vbObjectError + 5209, "EnsureExportHasNoFormulas", _
                  labelText & "に数式が残っています: " & formulaCell.Address(False, False)
    End If
    If Not TryFindFirstErrorConstantCell(scanRange, errorCell) Then
        Err.Raise vbObjectError + 5227, "EnsureExportHasNoFormulas", _
                  labelText & "のExcelエラー値有無を検査できません。"
    End If
    If Not errorCell Is Nothing Then
        Err.Raise vbObjectError + 5214, "EnsureExportHasNoFormulas", _
                  labelText & "にExcelエラー値があります: " & errorCell.Address(False, False)
    End If
End Sub

Private Sub ValidateFinalExportDestination(ByVal folderPath As String, _
                                           ByVal stageFolderPath As String, _
                                           ByVal packageFolderPath As String)
    'Excelが保存・オープンできる完全パスは218文字以内。完成フォルダーと
    '作成中ステージの全ファイルを同じ基準で先に検査する。
    Const EXCEL_FULL_PATH_MAX As Long = 218
    Dim probePath As String
    Dim stageCashPath As String, stageBalancePath As String, stageManifestPath As String
    Dim finalCashPath As String, finalBalancePath As String, finalManifestPath As String
    Dim fileNo As Integer, testByte As Byte
    Dim probeOpened As Boolean, probeOwned As Boolean
    Dim folderAttributes As Long, attributeErrorNumber As Long
    Dim errorNumber As Long, errorDescription As String

    On Error GoTo EH
    If Len(folderPath) = 0 Then _
        Err.Raise vbObjectError + 5215, "ValidateFinalExportDestination", _
                  "保存先フォルダーが指定されていません。"
    If PathLooksLikeWebUrl(folderPath) Then _
        Err.Raise vbObjectError + 5216, "ValidateFinalExportDestination", _
                  "Web URLへは直接出力できません。同期済みのローカルフォルダーを選択してください。"
    'Dir$はUNC共有のルートで空文字を返す環境があるため、属性を直接確認する。
    On Error Resume Next
    Err.Clear
    folderAttributes = GetAttr(folderPath)
    attributeErrorNumber = Err.Number
    Err.Clear
    On Error GoTo EH
    If attributeErrorNumber <> 0 Then _
        Err.Raise vbObjectError + 5216, "ValidateFinalExportDestination", _
                  "保存先フォルダーを確認できません: " & folderPath
    If (folderAttributes And vbDirectory) = 0 Then _
        Err.Raise vbObjectError + 5216, "ValidateFinalExportDestination", _
                  "選択先はフォルダーではありません: " & folderPath

    If ExportPathEntryExists(stageFolderPath) Or ExportPathEntryExists(packageFolderPath) Then _
        Err.Raise vbObjectError + 5216, "ValidateFinalExportDestination", _
                  "出力用フォルダー名が既に使用されています。もう一度実行してください。"

    stageCashPath = CombinePath(stageFolderPath, EXPORT_FILE_CASH)
    stageBalancePath = CombinePath(stageFolderPath, EXPORT_FILE_BALANCE)
    stageManifestPath = CombinePath(stageFolderPath, EXPORT_FILE_MANIFEST)
    finalCashPath = CombinePath(packageFolderPath, EXPORT_FILE_CASH)
    finalBalancePath = CombinePath(packageFolderPath, EXPORT_FILE_BALANCE)
    finalManifestPath = CombinePath(packageFolderPath, EXPORT_FILE_MANIFEST)
    ValidateFinalExportPathLength stageCashPath, "作成中の資金操作表", EXCEL_FULL_PATH_MAX
    ValidateFinalExportPathLength stageBalancePath, "作成中の残高推移表", EXCEL_FULL_PATH_MAX
    ValidateFinalExportPathLength stageManifestPath, "作成中の出力確認票", EXCEL_FULL_PATH_MAX
    ValidateFinalExportPathLength finalCashPath, "完成版の資金操作表", EXCEL_FULL_PATH_MAX
    ValidateFinalExportPathLength finalBalancePath, "完成版の残高推移表", EXCEL_FULL_PATH_MAX
    ValidateFinalExportPathLength finalManifestPath, "完成版の出力確認票", EXCEL_FULL_PATH_MAX

    probePath = CombinePath(folderPath, ".~co_write_" & _
                            Format$(Now, "yyyymmdd_hhnnss") & "_" & _
                            CStr(CLng(Timer * 100)) & ".tmp")
    ValidateFinalExportPathLength probePath, "保存先の書込確認ファイル", EXCEL_FULL_PATH_MAX
    fileNo = FreeFile
    Open probePath For Binary Access Write Lock Read Write As #fileNo
    probeOpened = True
    probeOwned = True
    Put #fileNo, , testByte
    Close #fileNo
    probeOpened = False
    Kill probePath
    probeOwned = False
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    On Error Resume Next
    If probeOpened Then Close #fileNo
    If probeOwned And Len(probePath) > 0 Then _
        If Len(Dir$(probePath)) > 0 Then Kill probePath
    Err.Clear
    If probeOwned And Len(probePath) > 0 Then
        If Len(Dir$(probePath)) > 0 Then _
            errorDescription = errorDescription & _
                               " / 書込確認用の一時ファイルが残っています: " & probePath
    End If
    On Error GoTo 0
    If errorNumber >= vbObjectError + 5215 And errorNumber <= vbObjectError + 5217 Then
        Err.Raise errorNumber, "ValidateFinalExportDestination", errorDescription
    Else
        Err.Raise vbObjectError + 5217, "ValidateFinalExportDestination", _
                  "保存先へ書き込めません。アクセス権、同期状態、空き容量を確認してください。" & _
                  vbCrLf & folderPath & vbCrLf & _
                  "詳細: Err " & CStr(errorNumber) & ": " & errorDescription
    End If
End Sub

Private Sub ValidateFinalExportPathLength(ByVal fullPath As String, ByVal labelText As String, _
                                          ByVal maximumLength As Long)
    If Len(fullPath) > maximumLength Then
        Err.Raise vbObjectError + 5217, "ValidateFinalExportPathLength", _
                  labelText & "の完全パスが長すぎます（" & CStr(Len(fullPath)) & "文字）。" & _
                  vbCrLf & "Excelで安全に扱える" & CStr(maximumLength) & _
                  "文字以内になるよう、より浅い保存先を選択してください。" & vbCrLf & fullPath
    End If
End Sub

Private Sub WriteExportManifest(ByVal manifestPath As String, ByVal cashPath As String, _
                                ByVal balancePath As String)
    Dim fileNo As Integer
    Dim fileOpened As Boolean, manifestCreated As Boolean
    Dim errorNumber As Long, errorDescription As String
    Dim statusLine As String

    On Error GoTo EH
    If Len(Dir$(cashPath)) = 0 Or Len(Dir$(balancePath)) = 0 Then _
        Err.Raise vbObjectError + 5210, "WriteExportManifest", _
                  "出力確認票を作成する前に成果物2点を確認できません。"
    If FileLen(cashPath) <= 0 Or FileLen(balancePath) <= 0 Then _
        Err.Raise vbObjectError + 5212, "WriteExportManifest", _
                  "成果物2点のいずれかが空です。"
    If Len(Dir$(manifestPath)) > 0 Then _
        Err.Raise vbObjectError + 5235, "WriteExportManifest", _
                  "作成中フォルダーに出力確認票が既にあります。"

    fileNo = FreeFile
    Open manifestPath For Output Access Write Lock Read Write As #fileNo
    fileOpened = True
    manifestCreated = True
    Print #fileNo, "STATUS=COMPLETE"
    Print #fileNo, "出力状態: 完了"
    Print #fileNo, "作成日時: " & Format$(Now, "yyyy/mm/dd hh:nn:ss")
    Print #fileNo, "資金操作表: " & EXPORT_FILE_CASH & "（" & _
                   Format$(FileLen(cashPath), "#,##0") & " bytes）"
    Print #fileNo, "残高推移表: " & EXPORT_FILE_BALANCE & "（" & _
                   Format$(FileLen(balancePath), "#,##0") & " bytes）"
    Print #fileNo, "作業ブック: " & ThisWorkbook.Name
    Print #fileNo, "注意: このフォルダー内の2つのExcelファイルを一組として取り扱ってください。"
    Close #fileNo
    fileOpened = False
    If Len(Dir$(manifestPath)) = 0 Then _
        Err.Raise vbObjectError + 5235, "WriteExportManifest", _
                  "出力確認票を作成できませんでした。"
    If FileLen(manifestPath) <= 0 Then _
        Err.Raise vbObjectError + 5235, "WriteExportManifest", _
                  "出力確認票を作成できませんでした。"
    fileNo = FreeFile
    Open manifestPath For Input Access Read Lock Read Write As #fileNo
    fileOpened = True
    Line Input #fileNo, statusLine
    Close #fileNo
    fileOpened = False
    If StrComp(statusLine, "STATUS=COMPLETE", vbBinaryCompare) <> 0 Then _
        Err.Raise vbObjectError + 5235, "WriteExportManifest", _
                  "出力確認票の読戻し結果が一致しません。"
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    On Error Resume Next
    If fileOpened Then Close #fileNo
    If manifestCreated And Len(manifestPath) > 0 Then _
        If Len(Dir$(manifestPath)) > 0 Then Kill manifestPath
    On Error GoTo 0
    Err.Raise errorNumber, "WriteExportManifest", errorDescription
End Sub

Private Sub PublishExportPackage(ByVal stageFolderPath As String, _
                                 ByVal packageFolderPath As String, _
                                 ByRef packagePublished As Boolean)
    Dim cashPath As String, balancePath As String, manifestPath As String
    Dim errorNumber As Long, errorDescription As String
    Dim stageExistsAfterError As Boolean, packageExistsAfterError As Boolean
    Dim publicationStateKnown As Boolean

    On Error GoTo EH
    packagePublished = False
    cashPath = CombinePath(stageFolderPath, EXPORT_FILE_CASH)
    balancePath = CombinePath(stageFolderPath, EXPORT_FILE_BALANCE)
    manifestPath = CombinePath(stageFolderPath, EXPORT_FILE_MANIFEST)
    If Not ExportPathEntryExists(stageFolderPath) Then _
        Err.Raise vbObjectError + 5236, "PublishExportPackage", _
                  "作成中フォルダーを確認できません。"
    If ExportPathEntryExists(packageFolderPath) Then _
        Err.Raise vbObjectError + 5236, "PublishExportPackage", _
                  "完成フォルダー名が既に使用されています。"
    If Len(Dir$(cashPath)) = 0 Or Len(Dir$(balancePath)) = 0 Or _
       Len(Dir$(manifestPath)) = 0 Then _
        Err.Raise vbObjectError + 5210, "PublishExportPackage", _
                  "成果物2点と出力確認票が揃っていません。"
    If FileLen(cashPath) <= 0 Or FileLen(balancePath) <= 0 Or _
       FileLen(manifestPath) <= 0 Then _
        Err.Raise vbObjectError + 5212, "PublishExportPackage", _
                  "成果物2点または出力確認票が空です。"

    '同じ親フォルダー内で、検査済みステージを完成名へ一度だけ切り替える。
    Name stageFolderPath As packageFolderPath
    packagePublished = True
    cashPath = CombinePath(packageFolderPath, EXPORT_FILE_CASH)
    balancePath = CombinePath(packageFolderPath, EXPORT_FILE_BALANCE)
    manifestPath = CombinePath(packageFolderPath, EXPORT_FILE_MANIFEST)
    If Len(Dir$(cashPath)) = 0 Or Len(Dir$(balancePath)) = 0 Or _
       Len(Dir$(manifestPath)) = 0 Then _
        Err.Raise vbObjectError + 5211, "PublishExportPackage", _
                  "完成フォルダーの公開後確認に失敗しました。フォルダーを移動・削除しないでください。"
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    'Name成功直後からフラグ設定までに割込みが入っても、実在状態から公開済みを再判定する。
    '公開済みフォルダーを未公開としてステージ後始末へ渡してはならない。
    On Error Resume Next
    Err.Clear
    stageExistsAfterError = ExportPathEntryExists(stageFolderPath)
    If Err.Number = 0 Then
        Err.Clear
        packageExistsAfterError = ExportPathEntryExists(packageFolderPath)
        If Err.Number = 0 Then publicationStateKnown = True
    End If
    If publicationStateKnown Then _
        packagePublished = (Not stageExistsAfterError And packageExistsAfterError)
    Err.Clear
    On Error GoTo 0
    Err.Raise errorNumber, "PublishExportPackage", errorDescription
End Sub

Private Sub CleanupExportStage(ByVal stageFolderPath As String, ByRef cleanupDetail As String)
    Dim errorNumber As Long, errorDescription As String
    Dim targetPath As String
    Dim stageStillExists As Boolean, existenceCheckError As Long
    Dim existenceCheckDescription As String

    cleanupDetail = vbNullString
    If Len(stageFolderPath) = 0 Then Exit Sub
    On Error Resume Next
    targetPath = CombinePath(stageFolderPath, EXPORT_FILE_CASH)
    Err.Clear
    If Len(Dir$(targetPath)) > 0 Then Kill targetPath
    If Err.Number <> 0 Then
        AppendFinalExportCleanupDetail cleanupDetail, _
            EXPORT_FILE_CASH & "を除去できません（Err " & CStr(Err.Number) & _
            ": " & Err.Description & "）。"
    End If
    targetPath = CombinePath(stageFolderPath, EXPORT_FILE_BALANCE)
    Err.Clear
    If Len(Dir$(targetPath)) > 0 Then Kill targetPath
    If Err.Number <> 0 Then
        AppendFinalExportCleanupDetail cleanupDetail, _
            EXPORT_FILE_BALANCE & "を除去できません（Err " & CStr(Err.Number) & _
            ": " & Err.Description & "）。"
    End If
    targetPath = CombinePath(stageFolderPath, EXPORT_FILE_MANIFEST)
    Err.Clear
    If Len(Dir$(targetPath)) > 0 Then Kill targetPath
    If Err.Number <> 0 Then
        AppendFinalExportCleanupDetail cleanupDetail, _
            EXPORT_FILE_MANIFEST & "を除去できません（Err " & CStr(Err.Number) & _
            ": " & Err.Description & "）。"
    End If
    Err.Clear
    stageStillExists = (Len(Dir$(stageFolderPath, _
                                vbReadOnly Or vbHidden Or vbSystem Or vbDirectory Or vbArchive)) > 0)
    If stageStillExists Then RmDir stageFolderPath
    errorNumber = Err.Number
    errorDescription = Err.Description
    Err.Clear
    stageStillExists = (Len(Dir$(stageFolderPath, _
                                vbReadOnly Or vbHidden Or vbSystem Or vbDirectory Or vbArchive)) > 0)
    existenceCheckError = Err.Number
    existenceCheckDescription = Err.Description
    Err.Clear
    On Error GoTo 0
    If existenceCheckError <> 0 Then
        AppendFinalExportCleanupDetail cleanupDetail, _
            "作成中フォルダーの残存確認に失敗しました: " & stageFolderPath & _
            "（Err " & CStr(existenceCheckError) & ": " & _
            existenceCheckDescription & "）"
    ElseIf errorNumber <> 0 Or stageStillExists Then
        AppendFinalExportCleanupDetail cleanupDetail, _
            "作成中フォルダーが残っています: " & stageFolderPath & _
            IIf(errorNumber <> 0, "（Err " & CStr(errorNumber) & ": " & _
                errorDescription & "）", vbNullString)
    End If
End Sub

Private Sub AppendFinalExportCleanupDetail(ByRef detailText As String, ByVal newDetail As String)
    If Len(newDetail) = 0 Then Exit Sub
    If Len(detailText) > 0 Then detailText = detailText & " "
    detailText = detailText & newDetail
End Sub

Private Function CombinePath(ByVal folderPath As String, ByVal fileName As String) As String
    If Right$(folderPath, 1) = "\" Or Right$(folderPath, 1) = "/" Then
        CombinePath = folderPath & fileName
    Else
        CombinePath = folderPath & "\" & fileName
    End If
End Function

# -*- coding: utf-8 -*-
from pathlib import Path
import json
import os
import shutil
import subprocess
import sys
import time
import urllib.request
import webbrowser

ROOT = Path(__file__).resolve().parent
SERVER = ROOT / 'app' / 'server.py'
FLOATING = ROOT / 'START_BLACKCAT_FLOATING.pyw'
PORT = 8765
HOST = '127.0.0.1'
BASE = f'http://{HOST}:{PORT}'


def _data_root():
    env = os.environ.get('BLACKCAT_WORKTOOL_DATA') or os.environ.get('BLACKCAT_DATA_ROOT')
    if env:
        return Path(env).expanduser().resolve()
    if sys.platform.startswith('win'):
        base = os.environ.get('APPDATA') or str(Path.home() / 'AppData' / 'Roaming')
        return Path(base) / 'BlackCatWorktool' / 'data'
    if sys.platform == 'darwin':
        return Path.home() / 'Library' / 'Application Support' / 'BlackCatWorktool' / 'data'
    return Path.home() / '.local' / 'share' / 'blackcat-worktool' / 'data'


def _log(message):
    try:
        folder = _data_root() / 'logs'
        folder.mkdir(parents=True, exist_ok=True)
        with (folder / 'launcher.log').open('a', encoding='utf-8') as stream:
            stream.write(f'[{time.strftime("%Y-%m-%d %H:%M:%S")}] {message}\n')
    except Exception:
        pass


def _flags():
    return getattr(subprocess, 'CREATE_NO_WINDOW', 0) if sys.platform.startswith('win') else 0


def alive():
    try:
        with urllib.request.urlopen(f'{BASE}/api/runtime/status', timeout=0.6) as r:
            data = json.loads(r.read().decode('utf-8'))
            return r.status == 200 and data.get('schema') == 'blackcat-worktool-runtime'
    except Exception:
        return False


def edge_path():
    roots = [os.environ.get('ProgramFiles'), os.environ.get('ProgramFiles(x86)'), os.environ.get('LOCALAPPDATA')]
    rels = [r'Microsoft\Edge\Application\msedge.exe', r'Microsoft\Edge SxS\Application\msedge.exe']
    for root in roots:
        if not root:
            continue
        for rel in rels:
            p = Path(root) / rel
            if p.exists():
                return str(p)
    for name in ['msedge.exe', 'microsoft-edge.exe', 'msedge', 'microsoft-edge', 'chromium', 'chromium-browser', 'google-chrome']:
        p = shutil.which(name)
        if p:
            return p
    return ''


def start_server():
    if alive():
        return True
    env = os.environ.copy()
    env['PYTHONUTF8'] = '1'
    env['PYTHONIOENCODING'] = 'utf-8'
    out_log = err_log = None
    try:
        log_dir = _data_root() / 'logs'
        log_dir.mkdir(parents=True, exist_ok=True)
        out_log = (log_dir / 'server_stdout.log').open('a', encoding='utf-8', errors='replace')
        err_log = (log_dir / 'server_stderr.log').open('a', encoding='utf-8', errors='replace')
        process = subprocess.Popen([sys.executable, str(SERVER), '--host', HOST, '--port', str(PORT), '--no-browser'], cwd=str(ROOT), stdin=subprocess.DEVNULL, stdout=out_log, stderr=err_log, creationflags=_flags(), env=env)
    except Exception as exc:
        _log('サーバーを起動できませんでした: ' + str(exc))
        return False
    finally:
        if out_log is not None:
            out_log.close()
        if err_log is not None:
            err_log.close()
    for _ in range(80):
        if alive():
            return True
        # ポート競合や起動時エラーで子プロセスが終了した場合は、待ち時間を
        # 使い切らず直ちに失敗として扱う。正常判定は引き続き専用の
        # runtime schema を返す health 応答だけで行う。
        if process.poll() is not None:
            _log(f'サーバーが起動前に終了しました（終了コード {process.returncode}）。ポート8765の使用状況とサーバーログを確認してください。')
            return False
        time.sleep(0.15)
    # 最後の確認と同時に応答可能になった場合を取りこぼさない。
    if alive():
        return True
    if process.poll() is None:
        # このランチャー自身が起動した未応答プロセスだけを終了し、再実行時に
        # 同じサーバーが重複して残らないようにする。保存先の移行は完成後に
        # 一括で切り替えるため、途中終了でも既存データは上書きしない。
        _log('サーバーは動作中ですが、起動確認が時間内に完了しないため終了します。')
        try:
            process.terminate()
            process.wait(timeout=2.0)
        except subprocess.TimeoutExpired:
            try:
                process.kill()
                process.wait(timeout=1.0)
            except Exception:
                pass
        except Exception as exc:
            _log('未応答のサーバーを終了できませんでした: ' + str(exc))
    _log('サーバーの起動確認が時間内に完了しませんでした。ポート8765の使用状況を確認してください。')
    return False


def _token():
    try:
        with urllib.request.urlopen(f'{BASE}/api/security/token', timeout=1.0) as r:
            return json.loads(r.read().decode('utf-8')).get('token', '')
    except Exception:
        return ''


def _post_json(path, payload):
    body = json.dumps(payload, ensure_ascii=False).encode('utf-8')
    req = urllib.request.Request(f'{BASE}{path}', data=body, method='POST', headers={
        'Content-Type': 'application/json',
        'X-Blackcat-Token': _token(),
    })
    with urllib.request.urlopen(req, timeout=1.8) as r:
        return r.status == 200


def open_main(view='today'):
    # メイン画面は今日・日付確認と作業管理を一つの通常ブラウザ画面で切り替える。
    # 既に黒猫ワークツールが開いていればサーバー側で前面化とタブ切替を試み、見つからない時だけ新しく開く。
    view = view if view in {'today', 'schedule', 'work', 'tasks', 'cases', 'people', 'career'} else 'today'
    target = '/continuum' if view == 'work' else f'/speculum#{view}'
    try:
        if _post_json('/api/ui/open-app', {'target': target}):
            return
    except Exception:
        pass
    url = f'{BASE}/workspace#' + ('continuum' if view == 'work' else f'speculum:{view}')
    edge = edge_path()
    if edge:
        subprocess.Popen([edge, url], cwd=str(ROOT), stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, creationflags=_flags())
    else:
        webbrowser.open(url)


def start_resident_blackcat():
    # 常駐黒猫は Edge ではなく、Tk のネイティブ最前面アイコンとして起動する。
    if not FLOATING.exists():
        return
    pyw = Path(sys.executable).with_name('pythonw.exe') if sys.platform.startswith('win') else Path(sys.executable)
    exe = str(pyw if pyw.exists() else Path(sys.executable))
    subprocess.Popen([exe, str(FLOATING)], cwd=str(ROOT), stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, creationflags=_flags())


def show_start_error():
    log_dir = _data_root() / 'logs'
    message = (
        '黒猫ワークツールを起動できませんでした。\n\n'
        'ほかのアプリが必要な接続先を使用しているか、起動処理でエラーが発生しています。'
        'いったんほかの黒猫ワークツールを終了してから、もう一度お試しください。\n\n'
        f'詳しい内容は次のフォルダに記録されています。\n{log_dir}'
    )
    _log('起動できなかったため、常駐黒猫と画面を開きませんでした。')
    if not sys.platform.startswith('win'):
        return
    try:
        import tkinter as tk
        from tkinter import messagebox
        root = tk.Tk()
        root.withdraw()
        try:
            root.attributes('-topmost', True)
        except Exception:
            pass
        try:
            messagebox.showerror('黒猫ワークツールを起動できません', message, parent=root)
        finally:
            root.destroy()
        return
    except Exception as exc:
        _log('起動エラー画面を表示できませんでした: ' + str(exc))
    try:
        import ctypes
        ctypes.windll.user32.MessageBoxW(None, message, '黒猫ワークツールを起動できません', 0x10)
    except Exception:
        pass


def main():
    ready = start_server()
    if not (ready or alive()):
        show_start_error()
        return 1
    start_resident_blackcat()
    open_main('today')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())

# -*- coding: utf-8 -*-
from pathlib import Path
import json
import os
import shutil
import subprocess
import sys
import time
import urllib.request
import webbrowser

ROOT = Path(__file__).resolve().parent
SERVER = ROOT / 'app' / 'server.py'
FLOATING = ROOT / 'START_BLACKCAT_FLOATING.pyw'
PORT = 8765
HOST = '127.0.0.1'
BASE = f'http://{HOST}:{PORT}'
WORKSPACE_MAXIMIZE_WATCH_ARG = '--maximize-workspace-watch'
WORKSPACE_MAXIMIZE_SEARCH_SECONDS = 5.0
WORKSPACE_MAXIMIZE_SETTLE_SECONDS = 1.2
WORKSPACE_MAXIMIZE_RETRY_SECONDS = 0.14
WORKSPACE_WINDOW_TITLES = (
    '黒猫ワークツール｜今日・日付確認',
    '黒猫ワークツール｜作業管理',
    '今日・日付確認｜黒猫ワークツール',
    '作業管理｜黒猫ワークツール',
    '黒猫ワークスペース',
    'Black Cat Workspace',
)


def _data_root():
    env = os.environ.get('BLACKCAT_WORKTOOL_DATA') or os.environ.get('BLACKCAT_DATA_ROOT')
    if env:
        return Path(env).expanduser().resolve()
    if sys.platform.startswith('win'):
        base = os.environ.get('APPDATA') or str(Path.home() / 'AppData' / 'Roaming')
        return Path(base) / 'BlackCatWorktool' / 'data'
    if sys.platform == 'darwin':
        return Path.home() / 'Library' / 'Application Support' / 'BlackCatWorktool' / 'data'
    return Path.home() / '.local' / 'share' / 'blackcat-worktool' / 'data'


def _log(message):
    try:
        folder = _data_root() / 'logs'
        folder.mkdir(parents=True, exist_ok=True)
        with (folder / 'launcher.log').open('a', encoding='utf-8') as stream:
            stream.write(f'[{time.strftime("%Y-%m-%d %H:%M:%S")}] {message}\n')
    except Exception:
        pass


def _flags():
    return getattr(subprocess, 'CREATE_NO_WINDOW', 0) if sys.platform.startswith('win') else 0


def _declare_winapi(library, name, argtypes, restype):
    function = getattr(library, name, None) if library is not None else None
    if function is None:
        return None
    try:
        function.argtypes = argtypes
        function.restype = restype
    except Exception:
        pass
    return function


def _is_workspace_window_title(title):
    """予定・作業の本体窓だけを許可し、コンパクトな吹き出しを除外する。"""
    value = str(title or '').strip()
    if not value or any(part in value for part in ('黒猫の吹き出し', 'Black Cat Command', '/floating')):
        return False
    return any(
        value == base or any(value.startswith(base + separator) for separator in (' - ', ' – ', ' — '))
        for base in WORKSPACE_WINDOW_TITLES
    )


def _maximize_workspace_window(activate=True):
    """表示済みの予定・作業窓へ Win32 の最大化を直接適用する。"""
    if not sys.platform.startswith('win'):
        return False
    try:
        import ctypes
        from ctypes import wintypes

        user32 = ctypes.windll.user32
        enum_proc_type = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
        is_visible = _declare_winapi(user32, 'IsWindowVisible', [wintypes.HWND], wintypes.BOOL)
        get_text_length = _declare_winapi(user32, 'GetWindowTextLengthW', [wintypes.HWND], ctypes.c_int)
        get_text = _declare_winapi(
            user32,
            'GetWindowTextW',
            [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int],
            ctypes.c_int,
        )
        enum_windows = _declare_winapi(user32, 'EnumWindows', [enum_proc_type, wintypes.LPARAM], wintypes.BOOL)
        show_window = _declare_winapi(user32, 'ShowWindow', [wintypes.HWND, ctypes.c_int], wintypes.BOOL)
        bring_to_top = _declare_winapi(user32, 'BringWindowToTop', [wintypes.HWND], wintypes.BOOL)
        set_foreground = _declare_winapi(user32, 'SetForegroundWindow', [wintypes.HWND], wintypes.BOOL)
        if not all((is_visible, get_text_length, get_text, enum_windows, show_window)):
            return False

        found = []

        @enum_proc_type
        def enum_proc(hwnd, _lparam):
            hwnd_w = wintypes.HWND(hwnd)
            if not is_visible(hwnd_w):
                return True
            length = get_text_length(hwnd_w)
            if length <= 0:
                return True
            buffer = ctypes.create_unicode_buffer(length + 1)
            get_text(hwnd_w, buffer, length + 1)
            if _is_workspace_window_title(buffer.value):
                found.append(int(hwnd or 0))
                return False
            return True

        enum_windows(enum_proc, wintypes.LPARAM(0))
        if not found:
            return False
        hwnd = wintypes.HWND(found[0])
        show_window(hwnd, 3)  # SW_MAXIMIZE
        if activate:
            try:
                if bring_to_top:
                    bring_to_top(hwnd)
                if set_foreground:
                    set_foreground(hwnd)
            except Exception:
                pass
        # ShowWindow の戻り値は成功可否ではなく変更前の表示状態である。
        # 対象窓を厳密に識別して命令を送れた時点で処理済みとする。
        return True
    except Exception:
        return False


def _watch_workspace_maximized(search_seconds=WORKSPACE_MAXIMIZE_SEARCH_SECONDS,
                                settle_seconds=WORKSPACE_MAXIMIZE_SETTLE_SECONDS,
                                retry_seconds=WORKSPACE_MAXIMIZE_RETRY_SECONDS):
    """Edgeの遅いタイトル確定と起動直後のサイズ復元を越えて最大化を定着させる。"""
    search_deadline = time.monotonic() + max(0.1, float(search_seconds))
    settle_deadline = None
    while True:
        found = _maximize_workspace_window(activate=settle_deadline is None)
        now = time.monotonic()
        if found and settle_deadline is None:
            # Edgeが起動指定の後から通常サイズを復元する場合に備え、
            # 短い安定時間だけ最大化を重ねる。
            settle_deadline = now + max(0.0, float(settle_seconds))
        if settle_deadline is not None and now >= settle_deadline:
            return True
        if settle_deadline is None and now >= search_deadline:
            return False
        time.sleep(max(0.02, float(retry_seconds)))


def _start_workspace_maximize_watch():
    """呼出元を待たせず、短命のpythonwプロセスで最大化を見届ける。"""
    if not sys.platform.startswith('win'):
        return False
    try:
        watcher = Path(__file__).resolve()
        pythonw = Path(sys.executable).with_name('pythonw.exe')
        executable = str(pythonw if pythonw.exists() else Path(sys.executable))
        subprocess.Popen(
            [executable, str(watcher), WORKSPACE_MAXIMIZE_WATCH_ARG],
            cwd=str(ROOT),
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            creationflags=_flags(),
        )
        return True
    except Exception as exc:
        _log('画面の最大化確認を開始できませんでした: ' + str(exc))
        return False


def alive():
    try:
        with urllib.request.urlopen(f'{BASE}/api/runtime/status', timeout=0.6) as r:
            data = json.loads(r.read().decode('utf-8'))
            return r.status == 200 and data.get('schema') == 'blackcat-worktool-runtime'
    except Exception:
        return False


def edge_path():
    roots = [os.environ.get('ProgramFiles'), os.environ.get('ProgramFiles(x86)'), os.environ.get('LOCALAPPDATA')]
    rels = [r'Microsoft\Edge\Application\msedge.exe', r'Microsoft\Edge SxS\Application\msedge.exe']
    for root in roots:
        if not root:
            continue
        for rel in rels:
            p = Path(root) / rel
            if p.exists():
                return str(p)
    for name in ['msedge.exe', 'microsoft-edge.exe', 'msedge', 'microsoft-edge', 'chromium', 'chromium-browser', 'google-chrome']:
        p = shutil.which(name)
        if p:
            return p
    return ''


def start_server():
    if alive():
        return True
    env = os.environ.copy()
    env['PYTHONUTF8'] = '1'
    env['PYTHONIOENCODING'] = 'utf-8'
    out_log = err_log = None
    try:
        log_dir = _data_root() / 'logs'
        log_dir.mkdir(parents=True, exist_ok=True)
        out_log = (log_dir / 'server_stdout.log').open('a', encoding='utf-8', errors='replace')
        err_log = (log_dir / 'server_stderr.log').open('a', encoding='utf-8', errors='replace')
        process = subprocess.Popen([sys.executable, str(SERVER), '--host', HOST, '--port', str(PORT), '--no-browser'], cwd=str(ROOT), stdin=subprocess.DEVNULL, stdout=out_log, stderr=err_log, creationflags=_flags(), env=env)
    except Exception as exc:
        _log('サーバーを起動できませんでした: ' + str(exc))
        return False
    finally:
        if out_log is not None:
            out_log.close()
        if err_log is not None:
            err_log.close()
    for _ in range(80):
        if alive():
            return True
        # ポート競合や起動時エラーで子プロセスが終了した場合は、待ち時間を
        # 使い切らず直ちに失敗として扱う。正常判定は引き続き専用の
        # runtime schema を返す health 応答だけで行う。
        if process.poll() is not None:
            _log(f'サーバーが起動前に終了しました（終了コード {process.returncode}）。ポート8765の使用状況とサーバーログを確認してください。')
            return False
        time.sleep(0.15)
    # 最後の確認と同時に応答可能になった場合を取りこぼさない。
    if alive():
        return True
    if process.poll() is None:
        # このランチャー自身が起動した未応答プロセスだけを終了し、再実行時に
        # 同じサーバーが重複して残らないようにする。保存先の移行は完成後に
        # 一括で切り替えるため、途中終了でも既存データは上書きしない。
        _log('サーバーは動作中ですが、起動確認が時間内に完了しないため終了します。')
        try:
            process.terminate()
            process.wait(timeout=2.0)
        except subprocess.TimeoutExpired:
            try:
                process.kill()
                process.wait(timeout=1.0)
            except Exception:
                pass
        except Exception as exc:
            _log('未応答のサーバーを終了できませんでした: ' + str(exc))
    _log('サーバーの起動確認が時間内に完了しませんでした。ポート8765の使用状況を確認してください。')
    return False


def _token():
    try:
        with urllib.request.urlopen(f'{BASE}/api/security/token', timeout=1.0) as r:
            return json.loads(r.read().decode('utf-8')).get('token', '')
    except Exception:
        return ''


def _post_json(path, payload):
    body = json.dumps(payload, ensure_ascii=False).encode('utf-8')
    req = urllib.request.Request(f'{BASE}{path}', data=body, method='POST', headers={
        'Content-Type': 'application/json',
        'X-Blackcat-Token': _token(),
    })
    with urllib.request.urlopen(req, timeout=1.8) as r:
        return r.status == 200


def open_main(view='today'):
    # メイン画面は今日・日付確認と作業管理を一つの通常ブラウザ画面で切り替える。
    # 既存窓は最大化して前面へ戻し、見つからない時だけ最大化した新規窓を開く。
    view = view if view in {'today', 'schedule', 'work', 'tasks', 'cases', 'people', 'career'} else 'today'
    target = '/continuum' if view == 'work' else f'/speculum#{view}'
    try:
        if _post_json('/api/ui/open-app', {'target': target}):
            return
    except Exception:
        pass
    url = f'{BASE}/workspace#' + ('continuum' if view == 'work' else f'speculum:{view}')
    edge = edge_path()
    if edge:
        subprocess.Popen([edge, '--new-window', '--start-maximized', url], cwd=str(ROOT), stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, creationflags=_flags())
        _start_workspace_maximize_watch()
    else:
        if webbrowser.open(url):
            _start_workspace_maximize_watch()


def start_resident_blackcat():
    # 常駐黒猫は Edge ではなく、Tk のネイティブ最前面アイコンとして起動する。
    if not FLOATING.exists():
        return
    pyw = Path(sys.executable).with_name('pythonw.exe') if sys.platform.startswith('win') else Path(sys.executable)
    exe = str(pyw if pyw.exists() else Path(sys.executable))
    subprocess.Popen([exe, str(FLOATING)], cwd=str(ROOT), stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, creationflags=_flags())


def show_start_error():
    log_dir = _data_root() / 'logs'
    message = (
        '黒猫ワークツールを起動できませんでした。\n\n'
        'ほかのアプリが必要な接続先を使用しているか、起動処理でエラーが発生しています。'
        'いったんほかの黒猫ワークツールを終了してから、もう一度お試しください。\n\n'
        f'詳しい内容は次のフォルダに記録されています。\n{log_dir}'
    )
    _log('起動できなかったため、常駐黒猫と画面を開きませんでした。')
    if not sys.platform.startswith('win'):
        return
    try:
        import tkinter as tk
        from tkinter import messagebox
        root = tk.Tk()
        root.withdraw()
        try:
            root.attributes('-topmost', True)
        except Exception:
            pass
        try:
            messagebox.showerror('黒猫ワークツールを起動できません', message, parent=root)
        finally:
            root.destroy()
        return
    except Exception as exc:
        _log('起動エラー画面を表示できませんでした: ' + str(exc))
    try:
        import ctypes
        ctypes.windll.user32.MessageBoxW(None, message, '黒猫ワークツールを起動できません', 0x10)
    except Exception:
        pass


def main():
    if WORKSPACE_MAXIMIZE_WATCH_ARG in sys.argv[1:]:
        return 0 if _watch_workspace_maximized() else 1
    ready = start_server()
    if not (ready or alive()):
        show_start_error()
        return 1
    start_resident_blackcat()
    open_main('today')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())

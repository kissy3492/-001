# -*- coding: utf-8 -*-
from pathlib import Path
import os
import traceback
import sys

ROOT = Path(__file__).resolve().parent


def _error_log_dir() -> Path:
    env = os.environ.get('BLACKCAT_WORKTOOL_DATA') or os.environ.get('BLACKCAT_DATA_ROOT')
    if env:
        return Path(env).expanduser().resolve() / 'logs'
    if sys.platform.startswith('win'):
        base = os.environ.get('APPDATA') or str(Path.home() / 'AppData' / 'Roaming')
        return Path(base) / 'BlackCatWorktool' / 'data' / 'logs'
    if sys.platform == 'darwin':
        return Path.home() / 'Library' / 'Application Support' / 'BlackCatWorktool' / 'data' / 'logs'
    return Path.home() / '.local' / 'share' / 'blackcat-worktool' / 'data' / 'logs'


if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
try:
    from app.floating_launcher import main
    raise SystemExit(main())
except SystemExit:
    raise
except Exception:
    try:
        log_dir = _error_log_dir()
        log_dir.mkdir(parents=True, exist_ok=True)
        (log_dir / 'resident_start_error.log').write_text(traceback.format_exc(), encoding='utf-8')
    except Exception:
        pass
    raise

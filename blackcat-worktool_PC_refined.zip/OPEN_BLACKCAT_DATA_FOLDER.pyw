# -*- coding: utf-8 -*-
from pathlib import Path
import os
import subprocess
import sys


def data_root() -> Path:
    env = os.environ.get('BLACKCAT_WORKTOOL_DATA') or os.environ.get('BLACKCAT_DATA_ROOT')
    if env:
        return Path(env).expanduser().resolve()
    if sys.platform.startswith('win'):
        base = os.environ.get('APPDATA') or str(Path.home() / 'AppData' / 'Roaming')
        return Path(base) / 'BlackCatWorktool' / 'data'
    if sys.platform == 'darwin':
        return Path.home() / 'Library' / 'Application Support' / 'BlackCatWorktool' / 'data'
    return Path.home() / '.local' / 'share' / 'blackcat-worktool' / 'data'

p = data_root()
p.mkdir(parents=True, exist_ok=True)
try:
    if sys.platform.startswith('win'):
        os.startfile(str(p))  # type: ignore[attr-defined]
    elif sys.platform == 'darwin':
        subprocess.Popen(['open', str(p)])
    else:
        subprocess.Popen(['xdg-open', str(p)])
except Exception as e:
    print(p)
    print(e)

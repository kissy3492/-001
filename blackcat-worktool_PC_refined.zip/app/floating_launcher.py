# -*- coding: utf-8 -*-
"""黒猫のネイティブ常駐アイコン。

常駐するのはこの Tk 小窓だけ。吹き出しは Edge --app、今日・日付確認・作業管理は一つのワークスペースタブで切り替える。
"""
from __future__ import annotations

import contextlib
import json
import os
import shutil
import struct
import subprocess
import sys
import time
import urllib.request
import webbrowser
import zlib
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
SERVER = ROOT / "app" / "server.py"
HOST = "127.0.0.1"
PORT = 8765
BASE = f"http://{HOST}:{PORT}"
def _preferred_data_root() -> Path:
    env = os.environ.get("BLACKCAT_WORKTOOL_DATA") or os.environ.get("BLACKCAT_DATA_ROOT")
    if env:
        return Path(env).expanduser().resolve()
    if sys.platform.startswith("win"):
        base = os.environ.get("APPDATA") or str(Path.home() / "AppData" / "Roaming")
        return Path(base) / "BlackCatWorktool" / "data"
    if sys.platform == "darwin":
        return Path.home() / "Library" / "Application Support" / "BlackCatWorktool" / "data"
    return Path.home() / ".local" / "share" / "blackcat-worktool" / "data"


DATA = _preferred_data_root()
LOGS = DATA / "logs"
STATE = DATA / "resident_blackcat_state.json"
LOCK = DATA / "resident_blackcat.lock"
PID = DATA / "resident_blackcat.pid"
ICON = ROOT / "web" / "assets" / "blackcat_resident_icon.png"
ICO = ROOT / "web" / "assets" / "blackcat_icon.ico"
TITLE_ICON = "黒猫常駐"
TITLE_BUBBLE = "黒猫の吹き出し"
ICON_SIZE = 128
ICON_INSET = 2
ICON_ALPHA_THRESHOLD = 12
BUBBLE_W = 500
BUBBLE_H = 760
TRANSPARENT = "#010203"
KEEP_FRONT_INTERVAL_MS = 1800
BUBBLE_SCAN_COOLDOWN_SECONDS = 0.12
BUBBLE_WINDOW_TITLES = (
    TITLE_BUBBLE,
    "Black Cat Command",
    "127.0.0.1:8765/floating",
    "localhost:8765/floating",
)
_LOCK: Any | None = None
_SERVER_START_PROCESS: Any | None = None


def _transparent_rgb() -> tuple[int, int, int]:
    s = TRANSPARENT.lstrip("#")
    try:
        return int(s[0:2], 16), int(s[2:4], 16), int(s[4:6], 16)
    except Exception:
        return 1, 2, 3


class _BinaryImageMask:
    """Pillow がない環境でも Windows の表示領域へ渡せる二値マスク。"""

    def __init__(self, width: int, height: int, data: bytes) -> None:
        self.size = (width, height)
        self._data = data

    def tobytes(self) -> bytes:
        return self._data


def _png_alpha_mask(path: Path, alpha_threshold: int = ICON_ALPHA_THRESHOLD) -> _BinaryImageMask | None:
    """標準ライブラリだけで同梱 RGBA PNG のアルファ領域を読み取る。"""
    try:
        raw = path.read_bytes()
        if raw[:8] != b"\x89PNG\r\n\x1a\n":
            return None
        width = height = bit_depth = color_type = interlace = 0
        compressed = bytearray()
        offset = 8
        while offset + 12 <= len(raw):
            length = struct.unpack(">I", raw[offset:offset + 4])[0]
            kind = raw[offset + 4:offset + 8]
            payload = raw[offset + 8:offset + 8 + length]
            offset += 12 + length
            if kind == b"IHDR" and len(payload) == 13:
                width, height, bit_depth, color_type, _compression, _filter, interlace = struct.unpack(">IIBBBBB", payload)
            elif kind == b"IDAT":
                compressed.extend(payload)
            elif kind == b"IEND":
                break
        if not width or not height or bit_depth != 8 or color_type != 6 or interlace != 0:
            return None
        decoded = zlib.decompress(bytes(compressed))
        bytes_per_pixel = 4
        stride = width * bytes_per_pixel
        expected = height * (stride + 1)
        if len(decoded) != expected:
            return None
        previous = bytearray(stride)
        alpha = bytearray(width * height)

        def paeth(left: int, above: int, upper_left: int) -> int:
            estimate = left + above - upper_left
            dl = abs(estimate - left)
            da = abs(estimate - above)
            du = abs(estimate - upper_left)
            return left if dl <= da and dl <= du else (above if da <= du else upper_left)

        src_at = 0
        out_at = 0
        for _y in range(height):
            filter_type = decoded[src_at]
            src_at += 1
            source_row = decoded[src_at:src_at + stride]
            src_at += stride
            row = bytearray(stride)
            for x, value in enumerate(source_row):
                left = row[x - bytes_per_pixel] if x >= bytes_per_pixel else 0
                above = previous[x]
                upper_left = previous[x - bytes_per_pixel] if x >= bytes_per_pixel else 0
                if filter_type == 0:
                    result = value
                elif filter_type == 1:
                    result = value + left
                elif filter_type == 2:
                    result = value + above
                elif filter_type == 3:
                    result = value + ((left + above) // 2)
                elif filter_type == 4:
                    result = value + paeth(left, above, upper_left)
                else:
                    return None
                row[x] = result & 0xFF
            for x in range(3, stride, bytes_per_pixel):
                alpha[out_at] = 255 if row[x] > alpha_threshold else 0
                out_at += 1
            previous = row
        return _BinaryImageMask(width, height, bytes(alpha))
    except Exception as exc:
        _log("PNG alpha mask failed: " + str(exc))
        return None


def _prepare_resident_icon(image: Any) -> tuple[Any, Any]:
    """表示用画像と Windows のウィンドウ領域用マスクを作る。

    元 PNG は変更しない。外周のごく薄い半透明ピクセルだけを表示時に落とし、
    transparentcolor と同色の可視ピクセルは一段ずらして意図しない穴を防ぐ。
    """
    from PIL import Image

    key = _transparent_rgb()
    render_size = max(1, ICON_SIZE - ICON_INSET * 2)
    src = image.convert("RGBA")
    if src.size != (render_size, render_size):
        src = src.resize((render_size, render_size), Image.Resampling.LANCZOS)

    prepared = Image.new("RGBA", (ICON_SIZE, ICON_SIZE), (*key, 0))
    prepared.alpha_composite(src, (ICON_INSET, ICON_INSET))
    pixels = list(prepared.getdata())
    region = bytearray(len(pixels))
    cleaned: list[tuple[int, int, int, int]] = []
    for index, (red, green, blue, alpha) in enumerate(pixels):
        if alpha <= ICON_ALPHA_THRESHOLD:
            cleaned.append((*key, 0))
            continue
        if (red, green, blue) == key:
            red = min(255, red + 1)
            green = min(255, green + 1)
            blue = min(255, blue + 1)
        cleaned.append((red, green, blue, alpha))
        region[index] = 255
    prepared.putdata(cleaned)
    mask = Image.frombytes("L", prepared.size, bytes(region))
    return prepared, mask



def _ensure_dirs() -> None:
    DATA.mkdir(parents=True, exist_ok=True)
    LOGS.mkdir(parents=True, exist_ok=True)


def _log(message: object) -> None:
    with contextlib.suppress(Exception):
        _ensure_dirs()
        with (LOGS / "resident_blackcat.log").open("a", encoding="utf-8") as f:
            f.write("[" + time.strftime("%Y-%m-%d %H:%M:%S") + "] " + str(message) + "\n")


def _creationflags() -> int:
    return getattr(subprocess, "CREATE_NO_WINDOW", 0) if sys.platform.startswith("win") else 0


def _python_candidates() -> list[str]:
    out: list[str] = []
    exe = sys.executable or ""
    if exe:
        if os.name == "nt" and exe.lower().endswith("python.exe"):
            out.append(exe[:-10] + "pythonw.exe")
        out.append(exe)
    out.extend(["pythonw.exe", "python.exe", "py.exe"])
    seen: set[str] = set()
    ans: list[str] = []
    for item in out:
        key = str(item).lower()
        if key not in seen:
            seen.add(key); ans.append(item)
    return ans


def _url(path: str) -> str:
    return BASE + (path if path.startswith("/") else "/" + path)


def _token() -> str:
    try:
        with urllib.request.urlopen(_url("/api/security/token"), timeout=0.8) as r:
            data = json.loads(r.read().decode("utf-8"))
            return str(data.get("token") or "")
    except Exception:
        return ""


def _post_json(path: str, payload: dict[str, Any]) -> bool:
    try:
        token = _token()
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        req = urllib.request.Request(_url(path), data=body, method="POST", headers={
            "Content-Type": "application/json",
            "X-Blackcat-Token": token,
        })
        with urllib.request.urlopen(req, timeout=1.2) as r:
            return 200 <= int(r.status) < 300
    except Exception as exc:
        _log("post failed " + path + ": " + str(exc))
        return False


def _alive() -> bool:
    for path in ("/api/runtime/status", "/api/app/alive"):
        try:
            with urllib.request.urlopen(_url(path), timeout=0.5) as r:
                data = json.loads(r.read().decode("utf-8"))
                if 200 <= r.status < 300 and data.get("schema") == "blackcat-worktool-runtime":
                    return True
        except Exception:
            pass
    return False


def _start_server() -> bool:
    global _SERVER_START_PROCESS
    if _alive():
        return True
    # 前回起動した子がまだ準備中なら、別のPython候補を重ねて起動しない。
    if _SERVER_START_PROCESS is not None:
        try:
            if _SERVER_START_PROCESS.poll() is None:
                _log("server process is still starting; duplicate launch skipped")
                return False
        except Exception:
            pass
        _SERVER_START_PROCESS = None
    _ensure_dirs()
    env = os.environ.copy()
    env["PYTHONUTF8"] = "1"
    env["PYTHONIOENCODING"] = "utf-8"
    for exe in _python_candidates():
        cmd = [exe, "-3", str(SERVER), "--host", HOST, "--port", str(PORT), "--no-browser"] if Path(str(exe)).name.lower() == "py.exe" or str(exe).lower() == "py.exe" else [exe, str(SERVER), "--host", HOST, "--port", str(PORT), "--no-browser"]
        try:
            # Popen が子プロセス用ハンドルを確保した時点で、常駐側のログ
            # ハンドルは閉じる。再起動を繰り返しても親プロセスへ残さない。
            with (LOGS / "server_stdout.log").open("a", encoding="utf-8", errors="replace") as out_log, \
                    (LOGS / "server_stderr.log").open("a", encoding="utf-8", errors="replace") as err_log:
                process = subprocess.Popen(cmd, cwd=str(ROOT), stdin=subprocess.DEVNULL, stdout=out_log, stderr=err_log, creationflags=_creationflags(), env=env)
            _SERVER_START_PROCESS = process
            end = time.time() + 14
            while time.time() < end:
                if _alive():
                    _log("server ready via " + str(exe))
                    return True
                # ポート競合や起動時エラーで終了済みなら、14秒を使い切らず
                # 次の候補へ進む。正常判定は専用 runtime schema の応答だけ。
                if process.poll() is not None:
                    _log("server exited before ready via " + str(exe) + ": " + str(process.returncode))
                    _SERVER_START_PROCESS = None
                    break
                time.sleep(0.18)
            if process.poll() is None:
                # 起動済み候補が遅れて準備を終える可能性があるため尊重し、
                # 別候補を重複起動しない。次回呼出しでも上の参照で抑止する。
                _log("server is still running without a health response; additional launch skipped")
                return False
        except Exception as exc:
            _log("server start failed " + str(exe) + ": " + str(exc))
    _log("server did not become ready")
    return False


def _server_start_process_running() -> bool:
    try:
        return _SERVER_START_PROCESS is not None and _SERVER_START_PROCESS.poll() is None
    except Exception:
        return False


def _finish_slow_server_start(extra_seconds: float = 6.0) -> bool:
    """遅い起動に短い猶予を与え、なお未応答なら自分が起動した子だけを片付ける。"""
    global _SERVER_START_PROCESS
    if not _server_start_process_running():
        return _alive()
    end = time.monotonic() + max(0.0, float(extra_seconds))
    while time.monotonic() < end:
        if _alive():
            return True
        if not _server_start_process_running():
            _SERVER_START_PROCESS = None
            return False
        time.sleep(0.2)
    if _alive():
        return True
    process = _SERVER_START_PROCESS
    if process is not None and _server_start_process_running():
        _log("server remained unresponsive after the extra wait; terminating owned process")
        try:
            process.terminate()
            process.wait(timeout=2.0)
        except subprocess.TimeoutExpired:
            try:
                process.kill()
                process.wait(timeout=1.0)
            except Exception:
                pass
        except Exception as exc:
            _log("unresponsive server termination failed: " + str(exc))
    _SERVER_START_PROCESS = None
    return False


def _ensure_server_ready() -> bool:
    return _start_server() or _finish_slow_server_start()


def _show_server_start_error() -> None:
    message = (
        "黒猫ワークツール本体を起動できませんでした。\n\n"
        "起動中のほかの黒猫ワークツールやアプリを終了してから、もう一度お試しください。\n\n"
        "詳しい内容は次のフォルダに記録されています。\n" + str(LOGS)
    )
    _log("resident did not open because the server was unavailable")
    if os.name != "nt":
        return
    try:
        import ctypes
        ctypes.windll.user32.MessageBoxW(None, message, "黒猫ワークツールを起動できません", 0x10)
    except Exception:
        pass


def _stop_server() -> bool:
    """常駐黒猫の右クリックメニューからサーバーを止める。

    止めた後でも、今日・日付確認や吹き出しを開く操作をすれば _start_server() が再起動する。
    """
    if not _alive():
        return True
    return _post_json("/api/shutdown", {})


def _edge_candidates() -> list[str]:
    found: list[str] = []
    if sys.platform.startswith("win"):
        for env_name in ("ProgramFiles", "ProgramFiles(x86)", "LOCALAPPDATA", "LocalAppData"):
            base = os.environ.get(env_name)
            if base:
                for rel in (r"Microsoft\Edge\Application\msedge.exe", r"Microsoft\Edge SxS\Application\msedge.exe"):
                    p = str(Path(base) / rel)
                    if Path(p).exists():
                        found.append(p)
        found.extend(["msedge.exe", "microsoft-edge.exe"])
    elif sys.platform == "darwin":
        found.append("/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge")
    else:
        found.extend(["microsoft-edge", "microsoft-edge-stable", "msedge", "chromium", "chromium-browser", "google-chrome"])
    for name in ("msedge", "microsoft-edge", "chromium", "chromium-browser", "google-chrome"):
        p = shutil.which(name)
        if p:
            found.append(p)
    seen: set[str] = set(); out: list[str] = []
    for item in found:
        key = item.lower()
        if key not in seen:
            seen.add(key); out.append(item)
    return out


def _open_edge_app(path: str, width: int, height: int, x: int | None = None, y: int | None = None) -> bool:
    if not _ensure_server_ready():
        _show_server_start_error()
        return False
    url = _url(path)
    args = ["--new-window", f"--app={url}", f"--window-size={int(width)},{int(height)}"]
    if x is not None and y is not None:
        args.append(f"--window-position={int(x)},{int(y)}")
    for exe in _edge_candidates():
        try:
            subprocess.Popen([exe, *args], cwd=str(ROOT), stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, creationflags=_creationflags())
            return True
        except Exception as exc:
            _log("edge app failed " + str(exe) + ": " + str(exc))
    with contextlib.suppress(Exception):
        webbrowser.open(url)
        return True
    return False

def _open_workspace(anchor: str = "speculum:today") -> bool:
    """今日・日付確認・作業管理は増やさず、サーバー側に既存画面への切替を依頼する。"""
    if not _ensure_server_ready():
        _show_server_start_error()
        return False
    anchor = str(anchor or "speculum:today").lstrip("#")
    target = "/continuum" if anchor in {"continuum", "work", "task", "tasks"} else "/speculum#" + anchor.replace("speculum:", "")
    if _post_json("/api/ui/open-app", {"target": target}):
        return True
    url = _url("/workspace#" + ("continuum" if target == "/continuum" else "speculum:" + target.split("#", 1)[-1]))
    for exe in _edge_candidates():
        try:
            subprocess.Popen([exe, url], cwd=str(ROOT), stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, creationflags=_creationflags())
            return True
        except Exception as exc:
            _log("workspace open failed " + str(exe) + ": " + str(exc))
    with contextlib.suppress(Exception):
        webbrowser.open(url)
        return True
    return False


def _load_state() -> dict[str, Any]:
    try:
        if STATE.exists():
            obj = json.loads(STATE.read_text(encoding="utf-8"))
            return obj if isinstance(obj, dict) else {}
    except Exception as exc:
        _log("state load failed: " + str(exc))
    return {}


def _save_state(patch: dict[str, Any]) -> None:
    with contextlib.suppress(Exception):
        _ensure_dirs()
        cur = _load_state(); cur.update(patch)
        STATE.write_text(json.dumps(cur, ensure_ascii=False, indent=2), encoding="utf-8")


def _write_pid() -> None:
    with contextlib.suppress(Exception):
        _ensure_dirs()
        PID.write_text(json.dumps({"pid": os.getpid(), "root": str(ROOT), "time": time.strftime("%Y-%m-%dT%H:%M:%S")}, ensure_ascii=False, indent=2), encoding="utf-8")


def _acquire_lock() -> bool:
    global _LOCK
    _ensure_dirs()
    try:
        fp = LOCK.open("a+b")
        if os.name == "nt":
            import msvcrt
            try:
                msvcrt.locking(fp.fileno(), msvcrt.LK_NBLCK, 1)
            except OSError:
                fp.close(); return False
        else:
            import fcntl
            try:
                fcntl.flock(fp.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            except OSError:
                fp.close(); return False
        _LOCK = fp
        return True
    except Exception as exc:
        _log("lock failed: " + str(exc))
        return True


def _release_lock() -> None:
    global _LOCK
    try:
        if _LOCK is not None:
            if os.name == "nt":
                import msvcrt
                _LOCK.seek(0); msvcrt.locking(_LOCK.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                import fcntl
                fcntl.flock(_LOCK.fileno(), fcntl.LOCK_UN)
            _LOCK.close()
    except Exception:
        pass
    _LOCK = None


def _user32() -> Any | None:
    if os.name != "nt":
        return None
    try:
        import ctypes
        return ctypes.windll.user32
    except Exception:
        return None


def _set_dpi_awareness() -> None:
    if os.name != "nt":
        return
    try:
        import ctypes
        with contextlib.suppress(Exception):
            ctypes.windll.user32.SetThreadDpiAwarenessContext(ctypes.c_void_p(-4))
        with contextlib.suppress(Exception):
            ctypes.windll.user32.SetProcessDpiAwarenessContext(ctypes.c_void_p(-4))
            return
        with contextlib.suppress(Exception):
            ctypes.windll.shcore.SetProcessDpiAwareness(2)
            return
        with contextlib.suppress(Exception):
            ctypes.windll.user32.SetProcessDPIAware()
    except Exception:
        pass


def _workareas() -> list[tuple[int, int, int, int, bool]]:
    if os.name != "nt":
        return []
    try:
        import ctypes
        from ctypes import wintypes

        class RECT(ctypes.Structure):
            _fields_ = [("left", wintypes.LONG), ("top", wintypes.LONG), ("right", wintypes.LONG), ("bottom", wintypes.LONG)]

        class MONITORINFO(ctypes.Structure):
            _fields_ = [("cbSize", wintypes.DWORD), ("rcMonitor", RECT), ("rcWork", RECT), ("dwFlags", wintypes.DWORD)]

        u = _user32() or ctypes.windll.user32
        areas: list[tuple[int, int, int, int, bool]] = []
        proc = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HANDLE, wintypes.HDC, ctypes.POINTER(RECT), wintypes.LPARAM)

        @proc
        def _enum(hmon: int, _hdc: int, _rc: Any, _data: int) -> bool:
            mi = MONITORINFO(); mi.cbSize = ctypes.sizeof(MONITORINFO)
            if u.GetMonitorInfoW(hmon, ctypes.byref(mi)):
                l,t,r,b = int(mi.rcWork.left), int(mi.rcWork.top), int(mi.rcWork.right), int(mi.rcWork.bottom)
                if r > l and b > t:
                    areas.append((l,t,r,b,bool(mi.dwFlags & 1)))
            return True
        u.EnumDisplayMonitors(0, 0, _enum, 0)
        return areas
    except Exception:
        return []


def _cursor_pos() -> tuple[int, int] | None:
    if os.name != "nt":
        return None
    try:
        import ctypes
        from ctypes import wintypes
        pt = wintypes.POINT()
        u = _user32() or ctypes.windll.user32
        if u.GetCursorPos(ctypes.byref(pt)):
            return int(pt.x), int(pt.y)
    except Exception:
        pass
    return None


def _area_for_point(x: int, y: int) -> tuple[int, int, int, int]:
    areas = _workareas()
    if not areas:
        return _virtual_workarea()
    for l,t,r,b,_primary in areas:
        if l <= x <= r and t <= y <= b:
            return l,t,r,b
    def dist(a: tuple[int, int, int, int, bool]) -> int:
        l,t,r,b,_ = a
        cx = min(max(x,l),r); cy = min(max(y,t),b)
        return (x-cx)*(x-cx)+(y-cy)*(y-cy)
    l,t,r,b,_ = min(areas, key=dist)
    return l,t,r,b


def _virtual_workarea() -> tuple[int, int, int, int]:
    areas = _workareas()
    if areas:
        return min(a[0] for a in areas), min(a[1] for a in areas), max(a[2] for a in areas), max(a[3] for a in areas)
    if os.name == "nt":
        with contextlib.suppress(Exception):
            u = _user32()
            if u:
                l = int(u.GetSystemMetrics(76)); t = int(u.GetSystemMetrics(77)); w = int(u.GetSystemMetrics(78)); h = int(u.GetSystemMetrics(79))
                if w > 0 and h > 0:
                    return l,t,l+w,t+h
    return 0,0,1280,720


def _default_xy() -> tuple[int, int]:
    pos = _cursor_pos()
    area = _area_for_point(*pos) if pos else _virtual_workarea()
    l,t,r,b = area
    return max(l + 20, r - ICON_SIZE - 34), max(t + 20, b - ICON_SIZE - 74)


def _clamp_xy(x: int, y: int) -> tuple[int, int]:
    area = _area_for_point(x + ICON_SIZE // 2, y + ICON_SIZE // 2)
    l,t,r,b = area
    return min(max(l + 6, int(x)), max(l + 6, r - ICON_SIZE - 6)), min(max(t + 6, int(y)), max(t + 6, b - ICON_SIZE - 6))


def _find_windows_any(title_parts: tuple[str, ...]) -> list[int]:
    if os.name != "nt":
        return []
    try:
        import ctypes
        from ctypes import wintypes
        u = _user32()
        if not u:
            return []
        found: list[int] = []
        enum_proc = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

        @enum_proc
        def _enum(hwnd: int, _lparam: int) -> bool:
            with contextlib.suppress(Exception):
                n = int(u.GetWindowTextLengthW(hwnd))
                if n > 0:
                    buf = ctypes.create_unicode_buffer(n + 1)
                    u.GetWindowTextW(hwnd, buf, n + 1)
                    title = str(buf.value or "")
                    if any(part in title for part in title_parts):
                        found.append(int(hwnd))
            return True
        u.EnumWindows(_enum, 0)
        return found
    except Exception as exc:
        _log("find windows failed: " + str(exc))
        return []


def _find_windows(title_part: str) -> list[int]:
    return _find_windows_any((title_part,))


def _window_exists(hwnd: int) -> bool:
    if os.name != "nt" or not hwnd:
        return False
    try:
        u = _user32()
        return bool(u and u.IsWindow(hwnd))
    except Exception:
        return False


def _is_visible(hwnd: int) -> bool:
    try:
        u = _user32()
        return bool(u and u.IsWindow(hwnd) and u.IsWindowVisible(hwnd))
    except Exception:
        return False


def _set_topmost(hwnd: int, x: int | None = None, y: int | None = None, w: int | None = None, h: int | None = None, activate: bool = False) -> None:
    if os.name != "nt" or not hwnd:
        return
    try:
        import ctypes
        from ctypes import wintypes
        u = _user32()
        if not u:
            return
        HWND_TOPMOST = wintypes.HWND(-1)
        SWP_NOMOVE = 0x0002; SWP_NOSIZE = 0x0001; SWP_NOACTIVATE = 0x0010; SWP_SHOWWINDOW = 0x0040; SWP_NOOWNERZORDER = 0x0200
        flags = SWP_SHOWWINDOW | SWP_NOOWNERZORDER | (0 if activate else SWP_NOACTIVATE)
        if x is None or y is None:
            x = y = 0; flags |= SWP_NOMOVE
        if w is None or h is None:
            w = h = 0; flags |= SWP_NOSIZE
        u.ShowWindow(wintypes.HWND(hwnd), 5)
        u.SetWindowPos(wintypes.HWND(hwnd), HWND_TOPMOST, int(x), int(y), int(w), int(h), flags)
        if activate:
            with contextlib.suppress(Exception):
                u.SetForegroundWindow(wintypes.HWND(hwnd))
    except Exception as exc:
        _log("topmost failed: " + str(exc))


def _apply_resident_style(hwnd: int) -> None:
    if os.name != "nt" or not hwnd:
        return
    try:
        import ctypes
        from ctypes import wintypes
        u = _user32()
        if not u:
            return
        GWL_EXSTYLE = -20
        WS_EX_TOPMOST = 0x00000008
        WS_EX_TOOLWINDOW = 0x00000080
        WS_EX_APPWINDOW = 0x00040000
        get_long = getattr(u, "GetWindowLongPtrW", None) or u.GetWindowLongW
        set_long = getattr(u, "SetWindowLongPtrW", None) or u.SetWindowLongW
        hwnd_w = wintypes.HWND(hwnd)
        style = int(get_long(hwnd_w, GWL_EXSTYLE))
        style = (style | WS_EX_TOPMOST | WS_EX_TOOLWINDOW) & ~WS_EX_APPWINDOW
        set_long(hwnd_w, GWL_EXSTYLE, style)
    except Exception:
        pass


def _apply_window_region(hwnd: int, mask: Any) -> bool:
    """アイコンの不透明部分だけをネイティブウィンドウ領域にする。"""
    if os.name != "nt" or not hwnd or mask is None:
        return False
    try:
        import ctypes
        from ctypes import wintypes

        u = _user32()
        if not u:
            return False
        gdi = ctypes.windll.gdi32
        gdi.CreateRectRgn.argtypes = [ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int]
        gdi.CreateRectRgn.restype = wintypes.HANDLE
        gdi.CombineRgn.argtypes = [wintypes.HANDLE, wintypes.HANDLE, wintypes.HANDLE, ctypes.c_int]
        gdi.CombineRgn.restype = ctypes.c_int
        gdi.DeleteObject.argtypes = [wintypes.HANDLE]
        gdi.DeleteObject.restype = wintypes.BOOL
        u.SetWindowRgn.argtypes = [wintypes.HWND, wintypes.HANDLE, wintypes.BOOL]
        u.SetWindowRgn.restype = ctypes.c_int

        width, height = (int(value) for value in mask.size)
        data = mask.tobytes()
        combined = gdi.CreateRectRgn(0, 0, 0, 0)
        if not combined:
            return False
        try:
            # 連続する不透明ピクセルを横一列の矩形にまとめるため、
            # 1 ピクセルごとのリージョン生成より十分軽い。
            for y in range(height):
                row = data[y * width:(y + 1) * width]
                x = 0
                while x < width:
                    while x < width and not row[x]:
                        x += 1
                    start = x
                    while x < width and row[x]:
                        x += 1
                    if start >= x:
                        continue
                    part = gdi.CreateRectRgn(start, y, x, y + 1)
                    if part:
                        gdi.CombineRgn(combined, combined, part, 2)  # RGN_OR
                        gdi.DeleteObject(part)
            if u.SetWindowRgn(wintypes.HWND(hwnd), combined, True):
                # 成功時は Windows が HRGN の所有権を引き継ぐ。
                combined = None
                return True
            return False
        finally:
            if combined:
                gdi.DeleteObject(combined)
    except Exception as exc:
        _log("window region failed: " + str(exc))
        return False


def _hide_window(hwnd: int) -> None:
    if os.name != "nt" or not hwnd:
        return
    with contextlib.suppress(Exception):
        u = _user32()
        if u:
            u.ShowWindow(hwnd, 0)


def _show_window(hwnd: int) -> None:
    """隠れた/最小化された Edge --app 吹き出しを確実に戻す。"""
    if os.name != "nt" or not hwnd:
        return
    with contextlib.suppress(Exception):
        u = _user32()
        if u:
            # SW_RESTORE の後に SW_SHOW。閉じていないが隠れている時の復帰を強める。
            u.ShowWindow(hwnd, 9)
            u.ShowWindow(hwnd, 5)


class ResidentBlackCat:
    def __init__(self, tk: Any, root: Any) -> None:
        self.tk = tk
        self.root = root
        self.canvas: Any | None = None
        self.image: Any | None = None
        self.icon_region_mask: Any | None = None
        self.drag_start: tuple[int, int] | None = None
        self.win_start: tuple[int, int] | None = None
        self.moved = False
        self.single_click_job: Any | None = None
        self.suppress_next_release = False
        self.last_toggle = 0.0
        self._hwnd_cache = 0
        self._region_hwnd = 0
        self._bubble_hwnds: list[int] = []
        self._bubble_scan_at = 0.0
        self._build()

    def _build(self) -> None:
        state = _load_state()
        x = int(state.get("x") or _default_xy()[0]); y = int(state.get("y") or _default_xy()[1])
        x, y = _clamp_xy(x, y)
        self.root.title(TITLE_ICON)
        self.root.geometry(f"{ICON_SIZE}x{ICON_SIZE}+20+20")
        self.root.overrideredirect(True)
        self.root.resizable(False, False)
        self.root.configure(bg=TRANSPARENT, cursor="fleur")
        with contextlib.suppress(Exception):
            self.root.iconbitmap(str(ICO))
        with contextlib.suppress(Exception):
            self.root.attributes("-transparentcolor", TRANSPARENT)
        with contextlib.suppress(Exception):
            self.root.attributes("-alpha", 1.0)
        with contextlib.suppress(Exception):
            self.root.attributes("-topmost", True)
        self.canvas = self.tk.Canvas(self.root, width=ICON_SIZE, height=ICON_SIZE, bg=TRANSPARENT, bd=0, highlightthickness=0, cursor="fleur")
        self.canvas.pack(fill="both", expand=True)
        self._draw_icon()
        for target in (self.root, self.canvas):
            target.bind("<ButtonPress-1>", self._press)
            target.bind("<B1-Motion>", self._motion)
            target.bind("<ButtonRelease-1>", self._release)
            target.bind("<Double-Button-1>", self._open_schedule)
            target.bind("<Button-3>", self._menu)
        self.root.bind("<Escape>", lambda _e: (self.hide_bubble(), "break")[-1])
        self.root.protocol("WM_DELETE_WINDOW", self.root.destroy)
        self._move_to(x, y)
        _save_state({"x": x, "y": y})
        self._keep_front()

    def _draw_icon(self) -> None:
        c = self.canvas
        if c is None:
            return
        if ICON.exists():
            try:
                from PIL import Image, ImageTk  # type: ignore
                src = Image.open(ICON).convert("RGBA")
                prepared, self.icon_region_mask = _prepare_resident_icon(src)
                self.image = ImageTk.PhotoImage(prepared)
                c.create_image(ICON_SIZE // 2, ICON_SIZE // 2, image=self.image)
                return
            except Exception as exc:
                _log("PIL icon load failed: " + str(exc))
                try:
                    self.icon_region_mask = _png_alpha_mask(ICON)
                    self.image = self.tk.PhotoImage(file=str(ICON))
                    c.create_image(ICON_SIZE // 2, ICON_SIZE // 2, image=self.image)
                    return
                except Exception as exc2:
                    _log("tk icon load failed: " + str(exc2))
        c.create_oval(8, 8, ICON_SIZE - 8, ICON_SIZE - 8, fill="#080a0d", outline="#2b3037", width=3)
        c.create_text(ICON_SIZE // 2, ICON_SIZE // 2, text="黒猫", fill="#eef2f6", font=("Yu Gothic UI", 22, "bold"))

    def _window_hwnd(self) -> int:
        if os.name != "nt":
            return 0
        try:
            import ctypes
            from ctypes import wintypes
            u = _user32()
            if not u:
                return 0
            if self._hwnd_cache and u.IsWindow(wintypes.HWND(self._hwnd_cache)):
                return self._hwnd_cache
            self._hwnd_cache = 0
            self._region_hwnd = 0
            hwnd = int(self.root.winfo_id())
            with contextlib.suppress(Exception):
                u.GetAncestor.argtypes = [wintypes.HWND, ctypes.c_uint]
                u.GetAncestor.restype = wintypes.HWND
            self._hwnd_cache = int(u.GetAncestor(wintypes.HWND(hwnd), 2) or hwnd)
            return self._hwnd_cache
        except Exception:
            return 0

    def _ensure_window_region(self, hwnd: int) -> None:
        if not hwnd or hwnd == self._region_hwnd or self.icon_region_mask is None:
            return
        if _apply_window_region(hwnd, self.icon_region_mask):
            self._region_hwnd = hwnd

    def _position(self) -> tuple[int, int]:
        try:
            if os.name == "nt":
                hwnd = self._window_hwnd()
                if hwnd:
                    import ctypes
                    from ctypes import wintypes
                    class RECT(ctypes.Structure):
                        _fields_ = [("left", wintypes.LONG), ("top", wintypes.LONG), ("right", wintypes.LONG), ("bottom", wintypes.LONG)]
                    rc = RECT(); u = _user32()
                    if u and u.GetWindowRect(wintypes.HWND(hwnd), ctypes.byref(rc)):
                        return int(rc.left), int(rc.top)
            return int(self.root.winfo_x()), int(self.root.winfo_y())
        except Exception:
            return _default_xy()

    def _move_to(self, x: int, y: int) -> None:
        x, y = int(x), int(y)
        if os.name != "nt" or (x >= 0 and y >= 0):
            with contextlib.suppress(Exception):
                self.root.geometry(f"{ICON_SIZE}x{ICON_SIZE}+{x}+{y}")
        hwnd = self._window_hwnd()
        if hwnd:
            _apply_resident_style(hwnd)
            self._ensure_window_region(hwnd)
            _set_topmost(hwnd, x, y, ICON_SIZE, ICON_SIZE, activate=False)
        else:
            with contextlib.suppress(Exception):
                self.root.lift()
            with contextlib.suppress(Exception):
                self.root.attributes("-topmost", True)

    def _press(self, event: Any) -> str:
        self.drag_start = (int(event.x_root), int(event.y_root))
        self.win_start = self._position()
        self.moved = False
        return "break"

    def _motion(self, event: Any) -> str:
        if not self.drag_start or not self.win_start:
            return "break"
        dx = int(event.x_root) - self.drag_start[0]
        dy = int(event.y_root) - self.drag_start[1]
        if abs(dx) + abs(dy) > 4:
            self.moved = True
        self._move_to(self.win_start[0] + dx, self.win_start[1] + dy)
        return "break"

    def _release(self, _event: Any) -> str:
        if self.moved:
            x, y = _clamp_xy(*self._position())
            self._move_to(x, y); _save_state({"x": x, "y": y})
            self._reattach_bubble_if_visible()
        else:
            if self.suppress_next_release:
                self.suppress_next_release = False
            else:
                if self.single_click_job is not None:
                    with contextlib.suppress(Exception):
                        self.root.after_cancel(self.single_click_job)
                self.single_click_job = self.root.after(230, self._single_click)
        self.drag_start = None; self.win_start = None; self.moved = False
        return "break"

    def _single_click(self) -> None:
        self.single_click_job = None
        if time.time() - self.last_toggle < 0.32:
            return
        self.last_toggle = time.time()
        # 左クリックは表示/非表示を明確に切り替える。非表示・最小化・見失い状態なら必ず再表示する。
        if any(_is_visible(hwnd) for hwnd in self._bubble_windows()):
            self.hide_bubble()
        else:
            self.show_bubble()

    def _bubble_rect(self) -> tuple[int, int, int, int, str]:
        ix, iy = self._position()
        l,t,r,b = _area_for_point(ix + ICON_SIZE // 2, iy + ICON_SIZE // 2)
        w = min(BUBBLE_W, max(430, r - l - 28))
        h = min(BUBBLE_H, max(560, b - t - 28))
        gap = 8
        if ix + ICON_SIZE + gap + w <= r - 8:
            x = ix + ICON_SIZE + gap; anchor = "left"
        else:
            x = ix - w - gap; anchor = "right"
        x = min(max(l + 8, x), max(l + 8, r - w - 8))
        y = iy + ICON_SIZE // 2 - 112
        y = min(max(t + 8, y), max(t + 8, b - h - 8))
        return int(x), int(y), int(w), int(h), anchor

    def _bubble_windows(self) -> list[int]:
        cached = [hwnd for hwnd in self._bubble_hwnds if _window_exists(hwnd)]
        if cached:
            self._bubble_hwnds = cached
            return list(cached)
        now = time.monotonic()
        if now - self._bubble_scan_at < BUBBLE_SCAN_COOLDOWN_SECONDS:
            return []
        self._bubble_scan_at = now
        self._bubble_hwnds = list(dict.fromkeys(_find_windows_any(BUBBLE_WINDOW_TITLES)))
        return list(self._bubble_hwnds)

    def _force_bubble_front(self, activate: bool = True) -> bool:
        x, y, w, h, _anchor = self._bubble_rect()
        visible = False
        for hwnd in self._bubble_windows():
            _show_window(hwnd)
            _set_topmost(hwnd, x, y, w, h, activate=activate)
            visible = _is_visible(hwnd) or visible
        return visible

    def show_bubble(self, tools: bool = False) -> None:
        x, y, w, h, anchor = self._bubble_rect()
        # 既存吹き出しが「隠れている・最小化している・背面に回っている」場合も、まず復帰と吸着を強制する。
        if self._force_bubble_front(activate=True):
            for delay in (80, 240, 520):
                with contextlib.suppress(Exception):
                    self.root.after(delay, lambda: self._force_bubble_front(activate=False))
            return
        unique = int(time.time() * 1000)
        path = f"/floating?resident=1&anchor={anchor}&t={unique}" + ("#tools" if tools else "")
        _open_edge_app(path, w, h, x, y)
        # Edge --app 起動直後は配置・タイトル反映が遅れることがあるので、数回に分けて黒猫へ吸着し直す。
        with contextlib.suppress(Exception):
            for delay in (160, 420, 800, 1400, 2400):
                self.root.after(delay, lambda: self._force_bubble_front(activate=False))

    def hide_bubble(self) -> None:
        for hwnd in self._bubble_windows():
            if _is_visible(hwnd):
                _hide_window(hwnd)

    def toggle_bubble(self) -> None:
        if any(_is_visible(hwnd) for hwnd in self._bubble_windows()):
            self.hide_bubble()
        else:
            self.show_bubble()

    def _reattach_bubble_if_visible(self) -> None:
        hwnds = [h for h in self._bubble_windows() if _is_visible(h)]
        if not hwnds:
            return
        x, y, w, h, _anchor = self._bubble_rect()
        _set_topmost(hwnds[0], x, y, w, h, activate=False)

    def _open_schedule(self, _event: Any = None) -> str:
        self.suppress_next_release = True
        if self.single_click_job is not None:
            with contextlib.suppress(Exception):
                self.root.after_cancel(self.single_click_job)
            self.single_click_job = None
        _open_workspace("speculum:today")
        return "break"

    def _open_work(self) -> None:
        _open_workspace("continuum")

    def _bring_home(self) -> None:
        x, y = _default_xy()
        self._move_to(x, y); _save_state({"x": x, "y": y})

    def _stop_server_only(self) -> None:
        self.hide_bubble()
        _stop_server()

    def _stop_server_and_exit(self) -> None:
        self.hide_bubble()
        _stop_server()
        with contextlib.suppress(Exception):
            self.root.destroy()

    def _menu(self, event: Any) -> str:
        try:
            menu = self.tk.Menu(self.root, tearoff=False)
            menu.add_command(label="吹き出しを表示・前面へ", command=self.show_bubble)
            menu.add_command(label="吹き出しを隠す", command=self.hide_bubble)
            menu.add_separator()
            menu.add_command(label="今日・日付確認を開く", command=lambda: _open_workspace("speculum:today"))
            menu.add_command(label="作業管理を開く", command=self._open_work)
            menu.add_command(label="ローカルツールを探す", command=lambda: self.show_bubble(True))
            menu.add_separator()
            menu.add_command(label="今の画面の右下へ戻す", command=self._bring_home)
            menu.add_separator()
            menu.add_command(label="黒猫ワークツールを一時停止", command=self._stop_server_only)
            menu.add_command(label="黒猫ワークツールを終了", command=self._stop_server_and_exit)
            menu.add_command(label="常駐黒猫だけ終了", command=self.root.destroy)
            # 右クリックメニューが常駐アイコンに重ならないよう、アイコンの右側へずらして出す。
            ix, iy = self._position()
            l, t, r, b = _area_for_point(ix + ICON_SIZE // 2, iy + ICON_SIZE // 2)
            menu_x = ix + ICON_SIZE + 24
            menu_y = iy + 10
            if menu_x > r - 180:
                menu_x = max(l + 10, ix - 260)
            menu_y = min(max(t + 10, menu_y), max(t + 10, b - 280))
            menu.tk_popup(int(menu_x), int(menu_y))
        except Exception as exc:
            _log("menu failed: " + str(exc))
        return "break"

    def _keep_front(self) -> None:
        try:
            with contextlib.suppress(Exception):
                self.root.deiconify()
            with contextlib.suppress(Exception):
                self.root.attributes("-topmost", True)
            hwnd = self._window_hwnd()
            if hwnd:
                _apply_resident_style(hwnd)
                self._ensure_window_region(hwnd)
                _set_topmost(hwnd, activate=False)
            self._reattach_bubble_if_visible()
        finally:
            with contextlib.suppress(Exception):
                self.root.after(KEEP_FRONT_INTERVAL_MS, self._keep_front)


def _restore_existing_icon() -> bool:
    restored = False
    x, y = _default_xy()
    for hwnd in _find_windows_any((TITLE_ICON, "黒猫常駐アイコン", "BlackCat Resident")):
        _apply_resident_style(hwnd); _set_topmost(hwnd, x, y, ICON_SIZE, ICON_SIZE, activate=False)
        restored = True
    if restored:
        _save_state({"x": x, "y": y, "recovered": True})
    return restored


def main() -> int:
    _ensure_dirs(); _set_dpi_awareness()
    if not _ensure_server_ready():
        _show_server_start_error()
        return 1
    have_lock = _acquire_lock()
    if not have_lock and _restore_existing_icon():
        return 0
    if not have_lock:
        # 既存プロセスがロックを持ったまま画面外・透明化している場合は、見える常駐性を優先して新しいアイコンを出す。
        _log("lock busy but no visible icon found; starting another visible resident icon")
    _write_pid()
    try:
        import tkinter as tk
        root = tk.Tk()
        ResidentBlackCat(tk, root)
        root.mainloop()
        return 0
    except Exception as exc:
        _log("resident icon failed: " + repr(exc))
        # 最後の保険として吹き出しだけ開く。ただし常駐アイコン失敗は logs/resident_blackcat.log に残す。
        _open_edge_app("/floating?resident_fallback=1", BUBBLE_W, BUBBLE_H)
        return 0
    finally:
        if have_lock:
            _release_lock()


if __name__ == "__main__":
    raise SystemExit(main())

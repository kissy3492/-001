#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""黒猫ワークツールのローカルサーバー。予定・作業・人物・経歴・ローカルツールをまとめて扱う。"""

from __future__ import annotations

import argparse
import ast
import copy
import datetime as _dt
import csv
import hashlib
import io
import json
import math
import mimetypes
import os
import queue
import re
import secrets
import shutil
import sqlite3
import subprocess
import sys
import threading
import time
import unicodedata
import webbrowser
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs, quote, unquote, urlparse
import urllib.request

APP_ROOT = Path(__file__).resolve().parents[1]
WEB_ROOT = APP_ROOT / "web"
LEGACY_DATA_ROOT = APP_ROOT / "data"


def preferred_data_root() -> Path:
    """ZIPを入れ替えてもデータを失わない固定保存先。

    以前の版はアプリフォルダ直下の data に保存していたため、
    新しいZIPを別フォルダへ展開すると「データが消えた／上書きされた」ように見えた。
    以後はユーザープロファイル側に固定し、起動時に旧 data から移行する。
    """
    env = os.environ.get("BLACKCAT_WORKTOOL_DATA") or os.environ.get("BLACKCAT_DATA_ROOT")
    if env:
        return Path(env).expanduser().resolve()
    if sys.platform.startswith("win"):
        base = os.environ.get("APPDATA") or str(Path.home() / "AppData" / "Roaming")
        return Path(base) / "BlackCatWorktool" / "data"
    if sys.platform == "darwin":
        return Path.home() / "Library" / "Application Support" / "BlackCatWorktool" / "data"
    return Path.home() / ".local" / "share" / "blackcat-worktool" / "data"


DATA_ROOT = preferred_data_root()
BACKUP_ROOT = DATA_ROOT / "backups"
LOCAL_TOOLS_ROOT = APP_ROOT / "external_tools" / "LocalTools"
DB_PATH = DATA_ROOT / "blackcat_worktool.sqlite3"
RUNTIME_ROOT = DATA_ROOT / "runtime"
UI_ROUTE_PATH = RUNTIME_ROOT / "workspace_route.json"
UI_ROUTE_LOCK = threading.Lock()
DEFAULT_HOST = "127.0.0.1"
DEFAULT_PORT = 8765
TOKEN = secrets.token_urlsafe(32)
DIRS_READY = False
DIRS_LOCK = threading.Lock()
DB_SCHEMA_LOCK = threading.Lock()
DB_SCHEMA_READY_PATH = ""
RECORD_CACHE_LOCK = threading.RLock()
RECORD_CACHE: dict[tuple[str, str], dict[str, Any]] = {}
PEOPLE_FOCUS_INDEX_LOCK = threading.Lock()
PEOPLE_FOCUS_INDEX_KEY = ""
PEOPLE_FOCUS_INDEX: list[dict[str, Any]] = []
SUMMARY_CACHE_LOCK = threading.Lock()
SUMMARY_CACHE_KEY: tuple[str, str, str, str] | None = None
SUMMARY_CACHE_VALUE: dict[str, Any] | None = None
SAVE_RECORD_LOCK = threading.RLock()
DELETE_RESTORE_TOKEN_LOCK = threading.Lock()
DELETE_RESTORE_TOKENS: dict[str, dict[str, Any]] = {}
DELETE_RESTORE_TOKEN_TTL_SECONDS = 10 * 60.0
BACKUP_QUEUE: "queue.Queue[tuple[str, str, str, str]]" = queue.Queue()
BACKUP_WORKER_STARTED = False
BACKUP_WORKER_LOCK = threading.Lock()
BACKUP_FILE_LOCK = threading.RLock()
AUTO_BACKUP_LOCK = threading.Lock()
AUTO_BACKUP_LAST: dict[tuple[str, str, str], float] = {}
AUTO_BACKUP_INTERVAL_SECONDS = 60.0
APP_HISTORY_KEEP_PER_STORE = 160
JSON_BACKUP_KEEP_PER_STORE = 120
CORRUPT_STORE_KEEP_PER_STORE = 32
STARTUP_BACKUP_INTERVAL_SECONDS = 6 * 60 * 60
# ローカル専用でも、壊れた/巨大な要求で保存処理全体がメモリ不足になるのを防ぐ。
# 通常の数千件規模の全件保存には十分な余裕を持たせる。
MAX_JSON_BODY_BYTES = 64 * 1024 * 1024
# 応答が届かず同じ登録要求が再送されても、二重登録しないための短期台帳。
# 業務データと同じSQLiteへ保存し、サーバー再起動をまたぐ再送も判定する。
IDEMPOTENCY_LOCK = threading.RLock()
# 成功応答は通常の通信再試行より十分長い7日を保持する。1週間に8192件を
# 超える完了操作だけ古い順に整理し、日常利用でDBを際限なく増やさない。
IDEMPOTENCY_DONE_KEEP_SECONDS = 7 * 24 * 60 * 60
IDEMPOTENCY_DONE_KEEP_ROWS = 8192
# pending は「保存直後に停止した可能性がある」ため、完了行の件数整理から
# 除外する。30日経過分だけ整理し、上限到達時も古い行を消さず新規操作を止める。
IDEMPOTENCY_PENDING_KEEP_SECONDS = 30 * 24 * 60 * 60
IDEMPOTENCY_PENDING_MAX_ROWS = 2048
IDEMPOTENCY_ID_MAX_LENGTH = 128
OPENABLE_EXTENSIONS = {".bat", ".cmd", ".ps1", ".py", ".pyw", ".exe", ".lnk", ".url"}
TOOL_EXTENSIONS = {".bat", ".cmd", ".ps1", ".py", ".pyw", ".exe", ".lnk", ".url"}
LOCAL_TOOL_QUERY_WORDS = {"ローカル", "ツール", "tool", "tools", "起動", "実行", "開く", "呼び出し", "呼び出す", "立ち上げ", "立ち上げる", "アプリ", "app"}
LOCAL_TOOL_CATALOG_CACHE: dict[str, Any] = {"stamp": None, "items": []}
LOCAL_TOOL_CATALOG_LOCK = threading.Lock()
WEEKDAYS = {"月": 0, "火": 1, "水": 2, "木": 3, "金": 4, "土": 5, "日": 6}
CASE_STATUSES = ["事案交付", "事前通知済", "着手済", "反面済", "再臨宅済", "重審済", "修正勧奨済", "加算税賦課済", "完了"]
CASE_STARTED_STATUSES = {"着手済", "反面済", "再臨宅済", "重審済", "修正勧奨済", "加算税賦課済"}
CASE_STATUS_ALIASES = {
    "調査中": "着手済", "対応中": "着手済", "確認待ち": "事前通知済", "保留": "着手済",
    "open": "事案交付", "done": "完了", "closed": "完了", "": "事案交付",
}
CABINET_HOLIDAY_CSV_URL = "https://www8.cao.go.jp/chosei/shukujitsu/syukujitsu.csv"
HOLIDAY_IMPORT_START_YEAR = 2000


class SaveConflictError(Exception):
    """古い画面の保存で新しいデータを黙って上書きしないための例外。"""

    def __init__(self, app: str, key: str, base_hash: str, current_hash: str, updated_at: str = "") -> None:
        super().__init__("別画面または別操作でデータが更新されています。")
        self.app = app
        self.key = key
        self.base_hash = base_hash
        self.current_hash = current_hash
        self.updated_at = updated_at


class DataCorruptionError(Exception):
    """保存本文を検証できず、安全な自動復旧もできない場合に更新を止める。"""


class RequestPayloadError(Exception):
    """HTTP要求の形式・大きさが不正な場合の利用者向けエラー。"""

    def __init__(self, message: str, status: int = 400) -> None:
        super().__init__(message)
        self.status = status


def normalize_work_status(value: Any) -> str:
    s = clean_text(value).lower()
    aliases = {
        "今日": "today", "today": "today",
        "次": "next", "次に進める": "next", "active": "next", "open": "next", "": "next", "next": "next",
        "待ち": "waiting", "waiting": "waiting", "wait": "waiting",
        "完了": "done", "done": "done", "closed": "done",
    }
    return aliases.get(s, "next")


def jst_now() -> _dt.datetime:
    return _dt.datetime.now(_dt.timezone(_dt.timedelta(hours=9)))


def today_date() -> _dt.date:
    return jst_now().date()


def iso_now() -> str:
    return jst_now().isoformat(timespec="microseconds")


def date_s(d: _dt.date | None = None) -> str:
    return (d or today_date()).isoformat()


def stable_json(data: Any) -> str:
    return json.dumps(data, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def pretty_json(data: Any) -> str:
    return json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True)


def text_hash(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def new_id(prefix: str) -> str:
    return f"{prefix}_{int(time.time() * 1000):x}_{secrets.token_hex(3)}"


def as_list(value: Any) -> list[Any]:
    return value if isinstance(value, list) else []


def as_dict(value: Any) -> dict[str, Any]:
    return value if isinstance(value, dict) else {}


def json_value_is_safe(value: Any) -> bool:
    """ブラウザーとUTF-8ファイルの双方で往復できないJSON値を拒否する。"""
    stack = [value]
    while stack:
        current = stack.pop()
        if isinstance(current, str):
            if any(0xD800 <= ord(char) <= 0xDFFF for char in current):
                return False
        elif isinstance(current, float):
            if not math.isfinite(current):
                return False
        elif isinstance(current, dict):
            stack.extend(current.keys())
            stack.extend(current.values())
        elif isinstance(current, list):
            stack.extend(current)
    return True


def clean_text(value: Any) -> str:
    text = unicodedata.normalize("NFKC", str(value or ""))
    return re.sub(r"\s+", " ", text).strip()


def loopback_host_header_ok(value: Any) -> bool:
    """HostヘッダーがこのPCだけを指しているか、ポートを含めて厳密に調べる。

    文字列の部分一致や最初のコロンでの分割は、IPv6や
    ``localhost.example`` を安全に区別できないため使わない。
    """
    authority = str(value or "").strip()
    if not authority or len(authority) > 255 or re.search(r"[\x00-\x20\x7f/@,]", authority):
        return False
    host = authority
    port = ""
    if authority.startswith("["):
        match = re.fullmatch(r"\[([^\]]+)\](?::([0-9]{1,5}))?", authority)
        if not match:
            return False
        host, port = match.group(1), match.group(2) or ""
    elif authority.count(":") == 1:
        host, port = authority.rsplit(":", 1)
        if not port.isdigit():
            return False
    elif authority.count(":") > 1:
        # ポート付きIPv6は角括弧が必須。ポートなしのループバックだけ許可する。
        if authority != "::1":
            return False
        host = authority
    if port and not 1 <= int(port) <= 65535:
        return False
    return host.lower() in {"127.0.0.1", "localhost", "::1"}


def boolish(value: Any) -> bool:
    """JSON・旧文字列の真偽値を、人が意図した値として読む。"""
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return value != 0
    text = clean_text(value).lower()
    if text in {"", "0", "false", "no", "off", "none", "null", "いいえ", "無効"}:
        return False
    if text in {"1", "true", "yes", "on", "はい", "有効"}:
        return True
    return bool(value)


DONE_RECORD_STATUSES = {
    "done", "complete", "completed", "closed",
    "完了", "完了済", "完了済み", "終了", "終了済", "終了済み",
}
DONE_RECORD_STATES = DONE_RECORD_STATUSES | {"ended"}


def record_is_done(item: Any) -> bool:
    """期限・事務・作業の旧形式を含め、完了済みかを一か所で判定する。

    明示的な状態と真偽値を優先する。完了日は、状態が保存されていない旧データで
    だけ補助判定に使い、再開済みの項目を古い完了日だけで隠さない。
    """
    row = as_dict(item)
    status = clean_text(row.get("status")).lower()
    state = clean_text(row.get("state")).lower()
    if status in DONE_RECORD_STATUSES or state in DONE_RECORD_STATES:
        return True
    for key in ("done", "completed", "closed"):
        if key in row and boolish(row.get(key)):
            return True
    if not status and any(clean_text(row.get(key)) for key in ("completedAt", "doneAt", "closedAt", "endedAt")):
        return True
    return False


def clean_multiline_text(value: Any) -> str:
    """メモの改行と行内の空白を保ったまま、文字表現だけを統一する。"""
    text = unicodedata.normalize("NFKC", str(value or ""))
    return text.replace("\r\n", "\n").replace("\r", "\n").strip()


def _continuum_settings(value: Any) -> dict[str, Any]:
    """表示設定をJSONの型ごと保持し、旧版で文字列化された条件だけ復元する。

    文字列・数値・真偽値・配列・辞書を一律に文字列へ変換すると、保存した検索条件の
    配列が失われる。未知の設定も含めて値をそのまま複製し、型が既知の
    savedWorkFilters だけは過去のJSON文字列から安全に戻す。
    """
    out: dict[str, Any] = {}
    for raw_key, raw_value in as_dict(value).items():
        key = clean_text(raw_key)
        if not key:
            continue
        setting_value = copy.deepcopy(raw_value)
        if key == "savedWorkFilters" and isinstance(setting_value, str):
            candidate: Any = setting_value.strip()
            # 旧版を複数回経由して二重にJSON文字列化されたデータにも対応する。
            for _ in range(2):
                if not isinstance(candidate, str) or not candidate.strip().startswith(("[", '"')):
                    break
                try:
                    decoded = json.loads(candidate)
                except (TypeError, ValueError, json.JSONDecodeError):
                    # clean_text(list) を通った旧データはPythonのリスト表記になる。
                    # literal_eval ならコードを実行せず、リテラルだけを復元できる。
                    try:
                        decoded = ast.literal_eval(candidate)
                    except (SyntaxError, ValueError, TypeError):
                        break
                candidate = decoded
            if isinstance(candidate, list):
                setting_value = candidate
        out[key] = setting_value
    return out


def clean_lines(value: Any) -> list[str]:
    """改行・読点・タブ区切りの複数人入力を、空要素なしの一覧へ整える。"""
    if isinstance(value, list):
        raw_items = value
    else:
        raw_items = re.split(r"[\r\n]+|[、,\t]", str(value or ""))
    out: list[str] = []
    seen: set[str] = set()
    for item in raw_items:
        s = clean_text(item)
        if not s or s in seen:
            continue
        seen.add(s); out.append(s)
    return out


def clean_number_text(value: Any) -> str:
    s = clean_text(value)
    if not s:
        return ""
    return s.replace(",", "")


def _data_score(root: Path) -> tuple[int, float]:
    """保存済みデータ量の目安を返す。移行候補の安全な比較だけに使う。"""
    db_path = root / "blackcat_worktool.sqlite3"
    if not db_path.is_file():
        return 0, 0.0
    count = 0
    try:
        con = sqlite3.connect(db_path)
        try:
            rows = con.execute("SELECT json_text FROM app_store").fetchall()
        finally:
            con.close()
        for (raw,) in rows:
            try:
                data = json.loads(raw or "{}")
            except Exception:
                data = {}
            if isinstance(data, dict):
                for key in ("events", "deadlines", "jimu", "cases", "people", "career", "tasks", "cycleTasks"):
                    val = data.get(key)
                    if isinstance(val, list):
                        count += len(val)
                memo = data.get("memo")
                if isinstance(memo, str) and memo.strip():
                    count += 1
                elif isinstance(memo, dict) and any(str(v or "").strip() for v in memo.values()):
                    count += 1
    except Exception:
        count = 0
    try:
        mtime = db_path.stat().st_mtime
    except OSError:
        mtime = 0.0
    return count, mtime




def _store_has_records(root: Path) -> bool:
    """固定保存先に保存済みレコードがあるかを安全側で判定する。

    件数ゼロに見える設定だけのDBでも、利用者が一度保存したデータである可能性がある。
    自動移行では、既存の保存先に何か記録がある時点で上書きしない。
    """
    db_path = root / "blackcat_worktool.sqlite3"
    if not db_path.is_file():
        return False
    try:
        con = sqlite3.connect(db_path)
        try:
            row = con.execute("SELECT 1 FROM app_store LIMIT 1").fetchone()
            if row:
                return True
            row = con.execute("SELECT 1 FROM app_history LIMIT 1").fetchone()
            return bool(row)
        finally:
            con.close()
    except Exception:
        # 読めないDBを空扱いして上書きする方が危ない。
        return True


def _candidate_legacy_data_roots() -> list[Path]:
    """自動移行してよい、現在の配布物に同梱された旧 data だけを返す。

    デスクトップやダウンロード内の別展開物を推測して選ぶと、検証コピーや
    古い控えを誤って本番データとして採用し得る。自動移行は、利用者が今まさに
    起動したツール直下の data に限定する。
    """
    try:
        if LEGACY_DATA_ROOT.resolve() == DATA_ROOT.resolve():
            return []
    except Exception:
        if str(LEGACY_DATA_ROOT).lower() == str(DATA_ROOT).lower():
            return []
    return [LEGACY_DATA_ROOT]


def _legacy_copy_ignore(_directory: str, names: list[str]) -> set[str]:
    db_name = DB_PATH.name
    excluded = {db_name, f"{db_name}-wal", f"{db_name}-shm", f"{db_name}-journal"}
    return {name for name in names if name in excluded}


def _copy_sqlite_snapshot(source_db: Path, destination_db: Path) -> None:
    """WAL未反映分を含む一貫したSQLiteスナップショットを作る。"""
    source = sqlite3.connect(source_db, timeout=10.0)
    destination = sqlite3.connect(destination_db, timeout=10.0)
    try:
        source.execute("PRAGMA query_only=ON")
        source.backup(destination)
        destination.commit()
        check = destination.execute("PRAGMA quick_check").fetchone()
        if not check or clean_text(check[0]).lower() != "ok":
            raise sqlite3.DatabaseError("移行後の保存データの整合性を確認できません。")
    finally:
        destination.close()
        source.close()


def _unique_sibling_path(base: Path, suffix: str) -> Path:
    candidate = base.parent / f"{base.name}_{suffix}"
    counter = 1
    while candidate.exists():
        candidate = base.parent / f"{base.name}_{suffix}_{counter}"
        counter += 1
    return candidate


def migrate_legacy_data_if_needed() -> None:
    """旧 data から固定保存先へ自動移行する。

    既に固定保存先に実データがある場合は絶対に上書きしない。
    固定保存先が空のときだけ、現在のツール直下にある旧 data をコピーする。
    """
    staging: Path | None = None
    moved_target: Path | None = None
    try:
        current_score, _ = _data_score(DATA_ROOT)
        if current_score > 0 or _store_has_records(DATA_ROOT):
            return
        best: tuple[int, float, Path] | None = None
        data_root_resolved = DATA_ROOT.resolve()
        for cand in _candidate_legacy_data_roots():
            try:
                if cand.resolve() == data_root_resolved:
                    continue
            except Exception:
                pass
            score, mtime = _data_score(cand)
            if score <= 0:
                continue
            if best is None or (score, mtime) > (best[0], best[1]):
                best = (score, mtime, cand)
        if not best:
            return
        src = best[2]
        DATA_ROOT.parent.mkdir(parents=True, exist_ok=True)
        stamp = jst_now().strftime("%Y%m%d_%H%M%S_%f")
        staging = _unique_sibling_path(DATA_ROOT, f"migration_staging_{stamp}_{secrets.token_hex(3)}")
        staging.mkdir(parents=True)

        # 固定保存先にDB以外の控え・設定が既にあれば、移行先へ引き継ぐ。
        if DATA_ROOT.exists():
            shutil.copytree(DATA_ROOT, staging, dirs_exist_ok=True, ignore=_legacy_copy_ignore)
        shutil.copytree(src, staging, dirs_exist_ok=True, ignore=_legacy_copy_ignore)
        source_db = src / DB_PATH.name
        destination_db = staging / DB_PATH.name
        _copy_sqlite_snapshot(source_db, destination_db)
        migrated_score, _ = _data_score(staging)
        if migrated_score <= 0 or not _store_has_records(staging):
            raise sqlite3.DatabaseError("移行後の保存データを確認できません。")

        _atomic_write_text(
            staging / "MIGRATION_NOTE.txt",
            f"旧データを自動移行しました。\n移行元: {src}\n移行日時: {iso_now()}\n"
            "今後はこの固定保存先を使います。ZIPを入れ替えても、この data フォルダは上書きされません。\n",
        )

        # 同一親フォルダ内で完成済みステージへ切り替える。途中終了時に半端な
        # DBを固定保存先として残さず、切替失敗時は元フォルダを戻す。
        if DATA_ROOT.exists():
            moved_target = _unique_sibling_path(DATA_ROOT, f"before_auto_migration_{stamp}")
            os.replace(DATA_ROOT, moved_target)
        try:
            os.replace(staging, DATA_ROOT)
            staging = None
        except Exception:
            if moved_target is not None and not DATA_ROOT.exists():
                os.replace(moved_target, DATA_ROOT)
                moved_target = None
            raise
    except Exception as exc:
        try:
            DATA_ROOT.mkdir(parents=True, exist_ok=True)
            _atomic_write_text(DATA_ROOT / "migration_error.log", str(exc))
        except Exception:
            pass
    finally:
        if staging is not None and staging.exists():
            try:
                shutil.rmtree(staging)
            except OSError:
                pass


def ensure_dirs() -> None:
    """データ保存先の準備。

    DBアクセスのたびに旧データ探索を走らせると、吹き出し候補の表示が重くなる。
    起動後は一度だけ実行し、通常の候補検索では即戻る。
    """
    global DIRS_READY
    if DIRS_READY and DATA_ROOT.exists() and BACKUP_ROOT.exists() and LOCAL_TOOLS_ROOT.exists():
        return
    with DIRS_LOCK:
        if DIRS_READY and DATA_ROOT.exists() and BACKUP_ROOT.exists() and LOCAL_TOOLS_ROOT.exists():
            return
        migrate_legacy_data_if_needed()
        DATA_ROOT.mkdir(parents=True, exist_ok=True)
        BACKUP_ROOT.mkdir(parents=True, exist_ok=True)
        RUNTIME_ROOT.mkdir(parents=True, exist_ok=True)
        LOCAL_TOOLS_ROOT.mkdir(parents=True, exist_ok=True)
        readme = LOCAL_TOOLS_ROOT / "README_LOCAL_TOOLS.txt"
        if not readme.exists():
            readme.write_text(
                "ここに .bat / .cmd / .ps1 / .py / .pyw / .exe / .lnk / .url を直下に置くと、黒猫から起動できます。\n"
                "サブフォルダ内、.txt / .pdf / .docx / .xlsx などの文書ファイルはローカルツールの起動対象にしません。\n",
                encoding="utf-8",
            )
        DIRS_READY = True


def db() -> sqlite3.Connection:
    global DB_SCHEMA_READY_PATH
    ensure_dirs()
    con = sqlite3.connect(DB_PATH, timeout=5.0)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA busy_timeout=5000")
    # 画面に「保存済み」と返した直近の更新を、停電・強制終了でも失いにくくする。
    # WAL + FULL は整合性だけでなく確定済みトランザクションの耐久性も優先する。
    con.execute("PRAGMA synchronous=FULL")
    schema_path = str(DB_PATH.resolve())
    if DB_SCHEMA_READY_PATH != schema_path:
        with DB_SCHEMA_LOCK:
            if DB_SCHEMA_READY_PATH != schema_path:
                try:
                    try:
                        con.execute("PRAGMA journal_mode=WAL").fetchone()
                    except sqlite3.DatabaseError:
                        pass
                    con.execute(
                        "CREATE TABLE IF NOT EXISTS app_store ("
                        "app TEXT NOT NULL, store_key TEXT NOT NULL, json_text TEXT NOT NULL, "
                        "sha256 TEXT NOT NULL, updated_at TEXT NOT NULL, PRIMARY KEY(app, store_key))"
                    )
                    con.execute(
                        "CREATE TABLE IF NOT EXISTS app_history ("
                        "id INTEGER PRIMARY KEY AUTOINCREMENT, app TEXT NOT NULL, store_key TEXT NOT NULL, "
                        "sha256 TEXT NOT NULL, json_text TEXT NOT NULL, created_at TEXT NOT NULL)"
                    )
                    con.execute(
                        "CREATE TABLE IF NOT EXISTS app_corrupt_store ("
                        "id INTEGER PRIMARY KEY AUTOINCREMENT, app TEXT NOT NULL, store_key TEXT NOT NULL, "
                        "sha256 TEXT NOT NULL, json_text TEXT NOT NULL, detected_at TEXT NOT NULL, reason TEXT NOT NULL)"
                    )
                    con.execute(
                        "CREATE TABLE IF NOT EXISTS request_idempotency ("
                        "request_id TEXT PRIMARY KEY, route TEXT NOT NULL, request_sha256 TEXT NOT NULL, "
                        "state TEXT NOT NULL, response_json TEXT NOT NULL, created_at REAL NOT NULL, updated_at REAL NOT NULL)"
                    )
                    # 履歴本文が大きくなっても、競合確認と世代整理ではJSON本文を
                    # 走査せず索引だけで対象を絞れるようにする。
                    con.execute(
                        "CREATE INDEX IF NOT EXISTS idx_app_history_store_id "
                        "ON app_history(app, store_key, id DESC)"
                    )
                    con.execute(
                        "CREATE INDEX IF NOT EXISTS idx_app_history_store_sha_id "
                        "ON app_history(app, store_key, sha256, id DESC)"
                    )
                    con.execute(
                        "CREATE INDEX IF NOT EXISTS idx_request_idempotency_updated "
                        "ON request_idempotency(updated_at DESC)"
                    )
                    con.commit()
                    DB_SCHEMA_READY_PATH = schema_path
                except Exception:
                    con.close()
                    raise
    return con


def _request_id(value: Any) -> str:
    raw = str(value or "").strip()
    if not raw:
        return ""
    if len(raw) > IDEMPOTENCY_ID_MAX_LENGTH or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._:-]{7,127}", raw):
        raise RequestPayloadError("再送防止IDの形式が正しくありません。画面を読み込み直してください。")
    return raw


def _trim_idempotency_rows(con: sqlite3.Connection, now: float) -> None:
    con.execute(
        "DELETE FROM request_idempotency WHERE state='done' AND updated_at < ?",
        (now - IDEMPOTENCY_DONE_KEEP_SECONDS,),
    )
    con.execute(
        "DELETE FROM request_idempotency WHERE state<>'done' AND updated_at < ?",
        (now - IDEMPOTENCY_PENDING_KEEP_SECONDS,),
    )
    con.execute(
        "DELETE FROM request_idempotency WHERE state='done' AND request_id NOT IN ("
        "SELECT request_id FROM request_idempotency WHERE state='done' ORDER BY updated_at DESC LIMIT ?)",
        (IDEMPOTENCY_DONE_KEEP_ROWS,),
    )


def run_idempotent_request(route: str, payload: dict[str, Any], operation: Any) -> dict[str, Any]:
    """任意のrequestId付き更新を一度だけ実行し、成功応答も再利用する。

    処理開始を先に永続化するため、保存直後にプロセスが停止した場合も同じIDを
    再実行しない。状態が不明な時は安全側で止め、画面の再読込を促す。
    """
    request_id = _request_id(payload.get("requestId"))
    if not request_id:
        return operation()
    fingerprint_payload = dict(payload)
    fingerprint_payload.pop("requestId", None)
    request_sha = text_hash(stable_json({"route": route, "payload": fingerprint_payload}))
    with IDEMPOTENCY_LOCK:
        with db() as con:
            row = con.execute(
                "SELECT route, request_sha256, state, response_json FROM request_idempotency WHERE request_id=?",
                (request_id,),
            ).fetchone()
        if row:
            if row["route"] != route or row["request_sha256"] != request_sha:
                raise RequestPayloadError("同じ再送防止IDが別の操作に使われています。画面を読み込み直してください。", status=409)
            if row["state"] == "done":
                try:
                    replayed = _decode_json_object(row["response_json"], label="再送済みの操作結果")
                except DataCorruptionError as exc:
                    raise RequestPayloadError("前回の操作結果を確認できません。画面を読み込み直してください。", status=409) from exc
                replayed["replayed"] = True
                replayed["requestId"] = request_id
                return replayed
            raise RequestPayloadError("前回の操作結果を確定できません。画面を更新して登録内容を確認してください。", status=409)

        now = time.time()
        with db() as con:
            _trim_idempotency_rows(con, now)
            pending_count = int(con.execute(
                "SELECT count(*) FROM request_idempotency WHERE state<>'done'"
            ).fetchone()[0])
            if pending_count >= IDEMPOTENCY_PENDING_MAX_ROWS:
                # 保存済みか不明な行を削って新しい操作を通すと、古い要求を後で
                # 二重実行できてしまう。整理分だけ確定して新規受付を安全側で止める。
                con.commit()
                raise RequestPayloadError(
                    "処理結果を確認中の操作が多いため、新しい操作を開始できません。画面を更新してからもう一度お試しください。",
                    status=503,
                )
            try:
                con.execute(
                    "INSERT INTO request_idempotency(request_id, route, request_sha256, state, response_json, created_at, updated_at) "
                    "VALUES(?,?,?,?,?,?,?)",
                    (request_id, route, request_sha, "pending", "{}", now, now),
                )
                _trim_idempotency_rows(con, now)
                con.commit()
            except sqlite3.IntegrityError:
                # 別プロセスが同時に同じIDを開始した場合も、二重実行せず再確認させる。
                raise RequestPayloadError("同じ操作を処理中です。少し待ってから画面を更新してください。", status=409)

        try:
            result = operation()
        except (RequestPayloadError, SaveConflictError, ValueError):
            # 入力不備・保存競合は更新前に確定する既知の失敗なので、訂正後の再操作を妨げない。
            # 予期しない例外は保存直後の停止か判別できないため pending のまま残し、二重実行を防ぐ。
            with db() as con:
                con.execute("DELETE FROM request_idempotency WHERE request_id=? AND state='pending'", (request_id,))
                con.commit()
            raise
        if not isinstance(result, dict):
            raise RequestPayloadError("操作結果の形式が正しくありません。", status=500)
        stored = dict(result)
        stored["requestId"] = request_id
        response_json = stable_json(stored)
        with db() as con:
            con.execute(
                "UPDATE request_idempotency SET state='done', response_json=?, updated_at=? WHERE request_id=?",
                (response_json, time.time(), request_id),
            )
            _trim_idempotency_rows(con, time.time())
            con.commit()
        return stored


def default_speculum() -> dict[str, Any]:
    return {
        "schema": 2,
        "events": [],
        "deadlines": [],
        "jimu": [],
        "cases": [],
        "people": [],
        "career": [],
        "holidays": {"items": {}, "source": CABINET_HOLIDAY_CSV_URL, "startYear": HOLIDAY_IMPORT_START_YEAR, "lastImportedAt": ""},
        "memo": {"today": "", "todayDate": "", "permanent": "", "days": {}},
        "settings": {"homeRangeDays": 7, "dueDayCountMode": "business"},
        "updatedAt": iso_now(),
    }


def default_continuum() -> dict[str, Any]:
    return {
        "schema": 2,
        "tasks": [],
        "cycleTasks": [],
        "memo": "",
        "settings": {"doneVisibleDays": "0", "boardLimit": "20", "boardDensity": "compact", "workSortMode": "urgency", "dueDayCountMode": "business"},
        "updatedAt": iso_now(),
    }


def normalise_speculum(data: Any) -> dict[str, Any]:
    base = default_speculum()
    src = as_dict(data)
    for k in ("events", "deadlines", "jimu", "cases", "people", "career"):
        base[k] = [normalise_item(k, x) for x in as_list(src.get(k)) if isinstance(x, dict)]
    raw_memo = as_dict(src.get("memo"))
    base["memo"] = {
        **base["memo"],
        **raw_memo,
        "today": clean_multiline_text(raw_memo.get("today")),
        "todayDate": clean_date(raw_memo.get("todayDate") or raw_memo.get("day")),
        "permanent": clean_multiline_text(raw_memo.get("permanent")),
        "days": {
            day: clean_multiline_text(value)
            for key, value in as_dict(raw_memo.get("days")).items()
            if (day := clean_date(key))
        },
    }
    holidays = as_dict(src.get("holidays"))
    items = as_dict(holidays.get("items") or holidays.get("data"))
    base["holidays"] = {**base["holidays"], **holidays, "items": {clean_date(k): clean_text(v) for k, v in items.items() if clean_date(k) and clean_text(v)}}
    base["settings"] = {**base["settings"], **as_dict(src.get("settings"))}
    base["updatedAt"] = clean_text(src.get("updatedAt")) or iso_now()
    return base


def normalise_continuum(data: Any) -> dict[str, Any]:
    base = default_continuum()
    src = as_dict(data)
    base["tasks"] = [normalise_item("tasks", x) for x in as_list(src.get("tasks")) if isinstance(x, dict)]
    base["cycleTasks"] = [normalise_item("cycleTasks", x) for x in as_list(src.get("cycleTasks")) if isinstance(x, dict)]
    base["memo"] = clean_multiline_text(src.get("memo"))
    base["settings"] = {**base["settings"], **_continuum_settings(src.get("settings"))}
    base["updatedAt"] = clean_text(src.get("updatedAt")) or iso_now()
    return base


def canonical_value(data: dict[str, Any], canonical: str, *aliases: str) -> Any:
    """標準項目が明示されていれば、空欄や0でも旧項目より優先する。"""
    for key in (canonical, *aliases):
        if key in data:
            return data.get(key)
    return None


def sync_present_aliases(data: dict[str, Any], canonical: str, *aliases: str) -> None:
    """残っている旧項目を標準値へ揃え、次回読込時の値の復活を防ぐ。"""
    for key in aliases:
        if key in data:
            data[key] = data.get(canonical)


def normalise_career_departments(data: dict[str, Any]) -> list[dict[str, Any]]:
    """経歴の部門を可変長の一覧へ揃える。

    先頭を現在の部門として扱う。departments が明示された場合は、空配列や
    空欄も利用者の入力として優先し、旧 manager/departmentStaff 等から値を
    復活させない。旧形式だけの経歴は、現在の部門を1件作り、関係部門職員が
    ある場合に限って2件目へ移す。
    """
    career_id = clean_text(data.get("id")) or "career"
    main_department_id = f"{career_id}_department_main"
    explicit = "departments" in data
    if explicit:
        raw_departments = [dict(x) for x in as_list(data.get("departments")) if isinstance(x, dict)]
    else:
        raw_departments = [{
            "id": main_department_id,
            "name": data.get("division"),
            "manager": data.get("manager"),
            "managerPersonId": data.get("managerPersonId"),
            "staff": data.get("departmentStaff"),
            "staffPersonIds": data.get("departmentStaffPersonIds"),
        }]
        related_name = clean_text(canonical_value(data, "relatedDepartment", "relatedDepartmentName", "relatedDivision", "関係部門"))
        related_manager = clean_text(canonical_value(data, "relatedManager", "関係部門責任者"))
        related_manager_id = clean_text(canonical_value(data, "relatedManagerPersonId", "関係部門責任者人物ID"))
        related_staff = clean_lines(data.get("relatedStaff"))
        related_staff_ids = clean_lines(data.get("relatedStaffPersonIds"))
        if related_name or related_manager or related_manager_id or related_staff or related_staff_ids:
            raw_departments.append({
                "id": f"{career_id}_department_related",
                "name": related_name or "関係部門",
                "manager": related_manager,
                "managerPersonId": related_manager_id,
                "staff": related_staff,
                "staffPersonIds": related_staff_ids,
            })

    # 現在の部門は常に1件だけ用意する。明示された空配列では旧値を引き継がない。
    if not raw_departments:
        raw_departments = [{"id": main_department_id}]

    departments: list[dict[str, Any]] = []
    used_ids: set[str] = set()
    for index, raw in enumerate(raw_departments):
        department = dict(raw)
        base_id = clean_text(department.get("id")) or (main_department_id if index == 0 else f"{career_id}_department_{index + 1}")
        department_id = base_id
        suffix = 2
        while department_id in used_ids:
            department_id = f"{base_id}_{suffix}"
            suffix += 1
        used_ids.add(department_id)
        department["id"] = department_id
        department["kind"] = "current" if index == 0 else "additional"
        department["name"] = clean_text(canonical_value(department, "name", "departmentName", "division"))
        department["manager"] = clean_text(canonical_value(department, "manager", "responsiblePerson", "responsibleName"))
        department["managerPersonId"] = clean_text(canonical_value(department, "managerPersonId", "responsiblePersonId"))
        department["staff"] = clean_lines(canonical_value(department, "staff", "members", "departmentStaff"))
        department["staffPersonIds"] = clean_lines(canonical_value(department, "staffPersonIds", "memberPersonIds", "departmentStaffPersonIds"))
        departments.append(department)
    return departments



def normalize_case_status(value: Any) -> str:
    s = clean_text(value)
    s = CASE_STATUS_ALIASES.get(s, s)
    return s if s in CASE_STATUSES else "事案交付"


def parse_case_targets(value: Any, fallback: Any = "", case_defaults: dict[str, Any] | None = None) -> list[dict[str, str]]:
    """調査対象者を人物管理の人物とは別枠で保持する。

    1つの事案に複数の調査対象者がいる場合でも、対象者ごとに進行状態・着手日・次回予定を持てるようにする。
    旧データのように事案本体だけに状態がある場合は、その値を対象者へ引き継ぐ。
    """
    defaults = case_defaults or {}
    def target_obj(src: dict[str, Any] | None, name_value: Any) -> dict[str, str]:
        src = src or {}
        has_target_status = bool(clean_text(src.get("status")))
        status = normalize_case_status(src.get("status") if has_target_status else defaults.get("status"))
        raw_started = canonical_value(src, "startedAt", "startDate")
        # 対象者ごとに進行が違うため、対象者側に状態がある場合は事案本体の着手日を勝手に継承しない。
        # 旧データで対象者側に状態がない場合だけ、事案本体の着手日を代表値として引き継ぐ。
        started_at = clean_date(raw_started) if raw_started else ("" if has_target_status else clean_date(defaults.get("startedAt")))
        if status in CASE_STARTED_STATUSES and not started_at:
            started_at = date_s()
        return {
            "id": clean_text(src.get("id")) or new_id("tg"),
            "name": clean_text(name_value),
            "role": clean_text(src.get("role")),
            "status": status,
            "startedAt": started_at,
            "nextDate": clean_date(src.get("nextDate") or defaults.get("nextDate")),
            "owner": clean_text(src.get("owner") or defaults.get("owner")),
            "priority": clean_text(src.get("priority") or defaults.get("priority")) or "normal",
            "nextAction": clean_text(src.get("nextAction") or defaults.get("nextAction")),
            "note": clean_text(src.get("note")),
        }

    out: list[dict[str, str]] = []
    if isinstance(value, list):
        for x in value:
            if isinstance(x, dict):
                name = clean_text(x.get("name") or x.get("title") or x.get("client"))
                if name:
                    out.append(target_obj(x, name))
            else:
                name = clean_text(x)
                if name:
                    out.append(target_obj({}, name))
    elif isinstance(value, str):
        for line in re.split(r"[\r\n]+", value):
            parts = [clean_text(x) for x in re.split(r"[,、\t]", line) if clean_text(x)]
            if parts:
                src = {"role": parts[1] if len(parts) > 1 else ""}
                if len(parts) > 2 and normalize_case_status(parts[2]) in CASE_STATUSES:
                    src["status"] = parts[2]
                    if len(parts) > 3: src["startedAt"] = parts[3]
                    if len(parts) > 4: src["nextDate"] = parts[4]
                    if len(parts) > 5: src["nextAction"] = parts[5]
                    if len(parts) > 6: src["note"] = " ".join(parts[6:])
                else:
                    src["note"] = " ".join(parts[2:])
                out.append(target_obj(src, parts[0]))
    if not out:
        fb = clean_text(fallback)
        if fb:
            out.append(target_obj({}, fb))
    return out

def case_target_names(case: dict[str, Any]) -> str:
    names = [clean_text(x.get("name")) for x in as_list(case.get("targetPersons")) if isinstance(x, dict) and clean_text(x.get("name"))]
    return "、".join(names)


def case_three_month_limit(started_at: Any) -> str:
    s = clean_date(started_at)
    if not s:
        return ""
    try:
        return add_months(_dt.date.fromisoformat(s), 3).isoformat()
    except Exception:
        return ""


def case_elapsed_alert(case: dict[str, Any], _date_diff: Any = None) -> dict[str, Any] | None:
    status = normalize_case_status(case.get("status"))
    if status == "完了":
        return None
    limit = case_three_month_limit(case.get("startedAt"))
    if not limit:
        return None
    dd = (_date_diff or date_diff)(limit)
    if dd is not None and dd < 0:
        return {**case, "alertDate": limit, "diff": dd, "alertKind": "長期化"}
    return None


def case_target_alerts(case: dict[str, Any], _date_diff: Any = None) -> list[dict[str, Any]]:
    """事案本体ではなく、調査対象者カード単位で3か月超過アラートを出す。"""
    alerts: list[dict[str, Any]] = []
    targets = parse_case_targets(case.get("targetPersons"), "", case)
    if not targets:
        hit = case_elapsed_alert(case, _date_diff)
        return [hit] if hit else []
    for target in targets:
        status = normalize_case_status(target.get("status"))
        if status == "完了" or status not in CASE_STARTED_STATUSES:
            continue
        limit = case_three_month_limit(target.get("startedAt"))
        if not limit:
            continue
        dd = (_date_diff or date_diff)(limit)
        if dd is not None and dd < 0:
            alerts.append({
                **case,
                "targetId": target.get("id"),
                "targetName": target.get("name"),
                "targetStatus": status,
                "startedAt": target.get("startedAt") or case.get("startedAt"),
                "nextDate": target.get("nextDate") or case.get("nextDate"),
                "nextAction": target.get("nextAction") or case.get("nextAction"),
                "owner": target.get("owner") or case.get("owner"),
                "alertDate": limit,
                "diff": dd,
                "alertKind": "長期化",
            })
    return alerts

def normalise_item(kind: str, item: dict[str, Any]) -> dict[str, Any]:
    now = iso_now()
    d = dict(item)
    prefix = {
        "events": "ev",
        "deadlines": "dl",
        "jimu": "jm",
        "cases": "ca",
        "people": "pe",
        "career": "cr",
        "tasks": "wk",
        "cycleTasks": "cy",
    }.get(kind, "it")
    d["id"] = clean_text(d.get("id")) or new_id(prefix)
    d["createdAt"] = clean_text(d.get("createdAt")) or now
    d["updatedAt"] = clean_text(d.get("updatedAt")) or now
    if kind == "events":
        raw_kind = clean_text(canonical_value(d, "calendarKind", "eventKind", "type", "kind"))
        if raw_kind.lower() in {"happening", "occurrence", "diary"} or raw_kind in {"出来事", "できごと", "出来ごと", "日記"}:
            d["calendarKind"] = "happening"
            fallback_title = "無題の出来事"
        else:
            d["calendarKind"] = "schedule"
            fallback_title = "無題の予定"
        d["title"] = clean_text(d.get("title")) or fallback_title
        d["date"] = clean_date(d.get("date")) or date_s()
        d["time"] = clean_time(d.get("time"))
        d["endTime"] = clean_time(d.get("endTime"))
        try:
            duration = int(float(str(canonical_value(d, "durationMinutes", "estimateMinutes") or 0).replace(",", "")))
        except Exception:
            duration = 0
        d["durationMinutes"] = max(0, min(24 * 60, duration))
        if d["time"] and d["endTime"]:
            sh, sm = [int(x) for x in d["time"].split(":")]
            eh, em = [int(x) for x in d["endTime"].split(":")]
            elapsed = ((eh * 60 + em) - (sh * 60 + sm)) % (24 * 60)
            if elapsed or d["durationMinutes"] < 24 * 60:
                d["durationMinutes"] = elapsed
        if d["time"] and d["durationMinutes"] and not d["endTime"]:
            d["endTime"] = add_minutes_to_time(d["time"], d["durationMinutes"])
        d["place"] = clean_text(d.get("place"))
        repeat_value = d.get("repeat")
        raw_repeat_obj = as_dict(repeat_value) if isinstance(repeat_value, dict) else as_dict(d.get("repeatRule"))
        if "repeat" in d and not isinstance(repeat_value, dict):
            raw_repeat = repeat_value
        else:
            raw_repeat = raw_repeat_obj.get("frequency") if raw_repeat_obj else repeat_value
        rep = clean_text(raw_repeat or "none").lower()
        repeat_aliases = {"": "none", "なし": "none", "no": "none", "none": "none", "daily": "daily", "毎日": "daily", "weekly": "weekly", "毎週": "weekly", "monthly": "monthly", "毎月": "monthly", "yearly": "yearly", "毎年": "yearly"}
        d["repeat"] = repeat_aliases.get(rep, rep if rep in {"none", "daily", "weekly", "monthly", "yearly"} else "none")
        if raw_repeat_obj and raw_repeat_obj.get("enabled") is False:
            d["repeat"] = "none"
        repeat_until = d.get("repeatUntil") if "repeatUntil" in d else raw_repeat_obj.get("until")
        d["repeatUntil"] = clean_date(repeat_until)
        try:
            interval_value = d.get("repeatInterval") if "repeatInterval" in d else raw_repeat_obj.get("interval")
            interval = int(float(interval_value or 1))
        except Exception:
            interval = 1
        d["repeatInterval"] = max(1, interval)
        monthly_mode_value = d.get("repeatMonthlyMode") if "repeatMonthlyMode" in d else raw_repeat_obj.get("monthlyMode")
        monthly_mode = clean_text(monthly_mode_value or "dayOfMonth")
        monthly_aliases = {"monthEnd": "endOfMonth", "lastDay": "endOfMonth", "月末": "endOfMonth", "最終平日": "lastBusinessDay", "nth": "nthWeekday", "nthWeekday": "nthWeekday"}
        d["repeatMonthlyMode"] = monthly_aliases.get(monthly_mode, monthly_mode if monthly_mode in {"dayOfMonth", "endOfMonth", "lastBusinessDay", "nthWeekday"} else "dayOfMonth")
        try:
            day_value = d.get("repeatDayOfMonth") if "repeatDayOfMonth" in d else raw_repeat_obj.get("dayOfMonth")
            day_of_month = int(float(day_value or _dt.date.fromisoformat(d["date"]).day))
        except Exception:
            day_of_month = 1
        d["repeatDayOfMonth"] = min(31, max(1, day_of_month))
        missing_value = d.get("repeatMissingDatePolicy") if "repeatMissingDatePolicy" in d else raw_repeat_obj.get("missingDatePolicy")
        raw_missing = clean_text(missing_value or "skip")
        missing_aliases = {"": "skip", "skip": "skip", "スキップ": "skip", "lastDay": "lastDay", "monthEnd": "lastDay", "月末": "lastDay", "previous": "previousBusiness", "previousBusiness": "previousBusiness", "前の平日": "previousBusiness", "next": "nextBusiness", "nextBusiness": "nextBusiness", "後ろの平日": "nextBusiness"}
        d["repeatMissingDatePolicy"] = missing_aliases.get(raw_missing, raw_missing if raw_missing in {"skip", "lastDay", "previousBusiness", "nextBusiness"} else "skip")
        nth_value = d.get("repeatNth") if "repeatNth" in d else raw_repeat_obj.get("nth")
        raw_nth = clean_text(nth_value or "1")
        d["repeatNth"] = "last" if raw_nth in {"last", "最終", "-1"} else clean_text(raw_nth if raw_nth in {"1", "2", "3", "4", "5"} else "1")
        try:
            start_for_weekday = _dt.date.fromisoformat(d["date"])
            default_weekday = (start_for_weekday.weekday() + 1) % 7
        except Exception:
            default_weekday = 0
        try:
            weekday_value = d.get("repeatWeekday") if "repeatWeekday" in d else raw_repeat_obj.get("weekday", default_weekday)
            weekday = int(float(weekday_value if clean_text(weekday_value) else default_weekday))
        except Exception:
            weekday = default_weekday
        # JSのDate.getDay()と同じ、日曜0〜土曜6で保存する。
        d["repeatWeekday"] = weekday if 0 <= weekday <= 6 else default_weekday
        shift_value = canonical_value(d, "repeatBusinessDayShift", "businessDayShift", "holidayShift")
        if shift_value is None:
            shift_value = raw_repeat_obj.get("businessDayPolicy")
        raw_shift = clean_text(shift_value).lower()
        shift_aliases = {"": "none", "no": "none", "none": "none", "なし": "none", "調整しない": "none", "prev": "previous", "before": "previous", "previous": "previous", "前": "previous", "前へ": "previous", "前営業日": "previous", "next": "next", "after": "next", "後": "next", "後ろ": "next", "後営業日": "next", "nearest": "nearest", "closest": "nearest", "近い": "nearest", "最寄り": "nearest"}
        d["repeatBusinessDayShift"] = shift_aliases.get(raw_shift, raw_shift if raw_shift in {"none", "previous", "next", "nearest"} else "none")
        tie_value = canonical_value(d, "repeatBusinessDayTie", "businessDayTie", "nearestTie")
        if tie_value is None:
            tie_value = raw_repeat_obj.get("nearestTiePolicy")
        raw_tie = clean_text(tie_value).lower()
        tie_aliases = {"": "previous", "prev": "previous", "before": "previous", "previous": "previous", "前": "previous", "前へ": "previous", "next": "next", "after": "next", "後": "next", "後ろ": "next"}
        d["repeatBusinessDayTie"] = tie_aliases.get(raw_tie, raw_tie if raw_tie in {"previous", "next"} else "previous")
        exception_value = d.get("exceptions") if "exceptions" in d else raw_repeat_obj.get("exceptions")
        d["exceptions"] = as_dict(exception_value)
        d["note"] = str(d.get("note") or "")
        d["personIds"] = [clean_text(x) for x in as_list(d.get("personIds")) if clean_text(x)]
        d["peopleText"] = clean_text(d.get("peopleText"))
        d["caseId"] = clean_text(d.get("caseId"))
    elif kind in ("deadlines", "jimu"):
        title_key = "title" if kind == "deadlines" else "name"
        d[title_key] = clean_text(d.get(title_key) or d.get("title") or d.get("name")) or ("無題の期限" if kind == "deadlines" else "無題の事務")
        d["title"] = d.get(title_key)
        d["name"] = d.get(title_key)
        d["due"] = clean_date(d.get("due")) or date_s()
        d["priority"] = clean_text(d.get("priority")) or "normal"
        completed = record_is_done(d)
        d["status"] = "done" if completed else (clean_text(d.get("status")) or "open")
        d["done"] = completed
        d["nextAction"] = clean_text(d.get("nextAction"))
        d["note"] = str(d.get("note") or "")
        d["personIds"] = [clean_text(x) for x in as_list(d.get("personIds")) if clean_text(x)]
        d["peopleText"] = clean_text(d.get("peopleText"))
        d["caseId"] = clean_text(d.get("caseId"))
    elif kind == "cases":
        d["title"] = clean_text(d.get("title") or d.get("name")) or "無題の事案"
        d["name"] = d["title"]
        d["status"] = normalize_case_status(d.get("status"))
        d["startedAt"] = clean_date(canonical_value(d, "startedAt", "startDate"))
        if d["status"] in CASE_STARTED_STATUSES and not d["startedAt"]:
            d["startedAt"] = date_s()
        sync_present_aliases(d, "startedAt", "startDate")
        d["nextDate"] = clean_date(d.get("nextDate"))
        d["owner"] = clean_text(d.get("owner"))
        d["nextAction"] = clean_text(d.get("nextAction"))
        d["priority"] = clean_text(d.get("priority")) or "normal"
        d["targetPersons"] = parse_case_targets(d.get("targetPersons") or d.get("targets") or d.get("subjects"), d.get("client"), d)
        d["client"] = case_target_names(d)
        d["subjects"] = [x.get("name", "") for x in as_list(d.get("targetPersons")) if isinstance(x, dict) and x.get("name")]
        d["note"] = str(d.get("note") or "")
        d["personIds"] = []
    elif kind == "people":
        d["name"] = clean_text(d.get("name")) or "無名の人物"
        d["kind"] = clean_text(d.get("kind"))
        d["term"] = clean_text(d.get("term"))
        display_order = clean_text(canonical_value(d, "displayOrder", "sortOrder", "order"))
        d["displayOrder"] = clean_number_text(display_order)
        sync_present_aliases(d, "displayOrder", "sortOrder", "order")
        d["role"] = clean_text(d.get("role"))
        d["org"] = clean_text(d.get("org"))
        d["tel"] = clean_text(d.get("tel"))
        d["email"] = clean_text(d.get("email"))
        d["tags"] = clean_text(d.get("tags"))
        if "retiredAt" in d:
            retired_at = clean_date(d.get("retiredAt"))
        elif "retirementDate" in d:
            retired_at = clean_date(d.get("retirementDate"))
        else:
            retired_at = clean_date(d.get("leftAt"))
        d["retired"] = boolish(d.get("retired")) or bool(retired_at)
        d["retiredAt"] = retired_at if d["retired"] else ""
        sync_present_aliases(d, "retiredAt", "retirementDate", "leftAt")
        d["note"] = str(d.get("note") or "")
    elif kind == "career":
        # 経歴は「事務年度ごとの職場・評価・出来事のセット」として保持する。
        # 旧データの title/date/department 等は可能な範囲で新しい項目へ移す。
        d["fiscalYear"] = clean_text(canonical_value(d, "fiscalYear", "yearLabel", "title")) or "R1"
        try:
            d["order"] = int(float(d.get("order")))
        except Exception:
            d["order"] = ""
        d["date"] = clean_date(d.get("date"))
        d["title"] = d["fiscalYear"]
        d["office"] = clean_text(canonical_value(d, "office", "affiliation", "署", "client"))
        d["division"] = clean_text(canonical_value(d, "division", "department", "課"))
        d["section"] = clean_text(canonical_value(d, "section", "係", "担当"))
        d["position"] = clean_text(canonical_value(d, "position", "role", "職名"))
        d["manager"] = clean_text(canonical_value(d, "manager", "departmentManager", "部門責任者"))
        d["managerPersonId"] = clean_text(d.get("managerPersonId"))
        d["reviewOfficer"] = clean_text(canonical_value(d, "reviewOfficer", "審理専門官"))
        d["reviewOfficerPersonId"] = clean_text(d.get("reviewOfficerPersonId"))
        d["departmentStaff"] = clean_lines(canonical_value(d, "departmentStaff", "staff", "部門職員"))
        d["departmentStaffPersonIds"] = [clean_text(x) for x in as_list(d.get("departmentStaffPersonIds")) if clean_text(x)]
        d["relatedStaff"] = clean_lines(canonical_value(d, "relatedStaff", "関係部門職員"))
        d["relatedStaffPersonIds"] = [clean_text(x) for x in as_list(d.get("relatedStaffPersonIds")) if clean_text(x)]
        departments = normalise_career_departments(d)
        d["departments"] = departments

        # 旧画面・旧データとの互換用。先頭（現在の部門）を従来項目へ同期し、
        # 追加部門の所属者は従来の「関係部門職員」へまとめる。
        current_department = departments[0]
        d["division"] = current_department["name"]
        d["manager"] = current_department["manager"]
        d["managerPersonId"] = current_department["managerPersonId"]
        d["departmentStaff"] = list(current_department["staff"])
        d["departmentStaffPersonIds"] = list(current_department["staffPersonIds"])
        related_departments = departments[1:]
        d["relatedDepartment"] = related_departments[0]["name"] if related_departments else ""
        d["relatedManager"] = related_departments[0]["manager"] if related_departments else ""
        d["relatedManagerPersonId"] = related_departments[0]["managerPersonId"] if related_departments else ""
        d["relatedStaff"] = clean_lines([name for department in related_departments for name in department["staff"]])
        d["relatedStaffPersonIds"] = clean_lines([pid for department in related_departments for pid in department["staffPersonIds"]])
        sync_present_aliases(d, "division", "department", "課")
        sync_present_aliases(d, "manager", "departmentManager", "部門責任者")
        sync_present_aliases(d, "departmentStaff", "staff", "部門職員")
        sync_present_aliases(d, "relatedDepartment", "relatedDepartmentName", "relatedDivision", "関係部門")
        sync_present_aliases(d, "relatedManager", "関係部門責任者")
        sync_present_aliases(d, "relatedManagerPersonId", "関係部門責任者人物ID")
        sync_present_aliases(d, "relatedStaff", "関係部門職員")
        legacy_note = str(d.get("note") or "")
        my_events = canonical_value(d, "myEvents", "自分の出来事")
        d["myEvents"] = str(legacy_note if my_events is None else (my_events or ""))
        d["othersEvents"] = str(canonical_value(d, "othersEvents", "他者の出来事") or "")
        d["abilityEval"] = clean_text(canonical_value(d, "abilityEval", "ability", "能力評価"))
        d["performanceEvalAprSep"] = clean_text(canonical_value(d, "performanceEvalAprSep", "performanceH1", "業績評価上期"))
        d["performanceEvalOctMar"] = clean_text(canonical_value(d, "performanceEvalOctMar", "performanceH2", "業績評価下期"))
        d["bonusUpper"] = clean_text(canonical_value(d, "bonusUpper", "勤勉手当上期"))
        d["raiseCategory"] = clean_text(canonical_value(d, "raiseCategory", "昇給区分"))
        d["bonusLower"] = clean_text(canonical_value(d, "bonusLower", "勤勉手当下期"))
        d["annualIncome"] = clean_number_text(canonical_value(d, "annualIncome", "収入", "年収"))
        d["income"] = clean_number_text(canonical_value(d, "income", "所得"))
        d["withholdingIncomeTax"] = clean_number_text(canonical_value(d, "withholdingIncomeTax", "源泉所得税額", "厳選所得税額"))
        d["hrGoal1"] = str(canonical_value(d, "hrGoal1", "人事目標1") or "")
        d["hrGoal2"] = str(canonical_value(d, "hrGoal2", "人事目標2") or "")
        d["hrGoal3"] = str(canonical_value(d, "hrGoal3", "人事目標3") or "")
        d["selfEval1"] = str(canonical_value(d, "selfEval1", "自己評価1") or "")
        d["selfEval2"] = str(canonical_value(d, "selfEval2", "自己評価2") or "")
        d["selfEval3"] = str(canonical_value(d, "selfEval3", "自己評価3") or "")
        d["note"] = d["myEvents"]
        career_person_ids: list[str] = []
        department_person_ids: list[Any] = []
        for department in departments:
            department_person_ids.extend([department.get("managerPersonId"), *as_list(department.get("staffPersonIds"))])
        # personIds は派生値として完全に作り直し、削除した責任者・所属者を
        # 旧 personIds から復活させない。
        for pid in [*department_person_ids, d.get("reviewOfficerPersonId")]:
            pid_text = clean_text(pid)
            if pid_text and pid_text not in career_person_ids:
                career_person_ids.append(pid_text)
        d["personIds"] = career_person_ids
        d["caseId"] = ""
    elif kind == "tasks":
        d["title"] = clean_text(d.get("title")) or "無題の作業"
        d["status"] = normalize_work_status(d.get("status"))
        d["priority"] = clean_text(d.get("priority")) or "normal"
        d["due"] = clean_date(d.get("due"))
        d["nextAction"] = clean_text(d.get("nextAction"))
        d["caseId"] = clean_text(d.get("caseId"))
        d["personIds"] = [clean_text(x) for x in as_list(d.get("personIds")) if clean_text(x)]
        d["note"] = str(d.get("note") or "")
        raw_source = d.get("source")
        if isinstance(raw_source, dict):
            d["sourceInfo"] = raw_source
            d["source"] = clean_text(raw_source.get("ref") or raw_source.get("legacy") or raw_source.get("id"))
        else:
            d["source"] = clean_text(raw_source)
            d["sourceInfo"] = as_dict(d.get("sourceInfo"))
        d["peopleText"] = clean_text(d.get("peopleText"))
        d["sortOrder"] = clean_number_text(d.get("sortOrder"))
        try:
            estimate = int(float(str(canonical_value(d, "estimateMinutes", "durationMinutes") or 0).replace(",", "")))
        except Exception:
            estimate = 0
        d["estimateMinutes"] = max(0, min(24 * 60, estimate))
        d["archivedAt"] = clean_date(d.get("archivedAt"))
        d["completedAt"] = clean_date(canonical_value(d, "completedAt", "doneAt"))
        if d["status"] != "done":
            d["completedAt"] = ""
        sync_present_aliases(d, "completedAt", "doneAt")
    elif kind == "cycleTasks":
        d["title"] = clean_text(d.get("title")) or "無題の周期作業"
        d["status"] = normalize_work_status(d.get("status"))
        raw_state = clean_text(d.get("state")).lower()
        if raw_state not in {"active", "paused", "ended"}:
            if d["status"] == "done" or clean_date(d.get("endedAt")):
                raw_state = "ended"
            elif clean_date(d.get("pausedAt")):
                raw_state = "paused"
            else:
                raw_state = "active"
        d["state"] = raw_state
        if d["state"] == "paused":
            d["status"] = "waiting"
        elif d["state"] == "ended":
            d["status"] = "done"
        elif d["status"] == "done":
            d["status"] = "next"
        d["rule"] = clean_text(d.get("rule")) or "毎月"
        d["nextRunDate"] = clean_date(d.get("nextRunDate")) or clean_date(d.get("nextDate")) or date_s()
        d["lastDoneDate"] = clean_date(canonical_value(d, "lastDoneDate", "lastCompletedAt"))
        d["priority"] = clean_text(d.get("priority")) or "normal"
        d["completedAt"] = clean_date(canonical_value(d, "completedAt", "doneAt"))
        d["pausedAt"] = clean_date(d.get("pausedAt"))
        d["endedAt"] = clean_date(d.get("endedAt"))
        if d["state"] != "paused":
            d["pausedAt"] = ""
        if d["state"] != "ended":
            d["endedAt"] = ""
            d["completedAt"] = ""
        sync_present_aliases(d, "lastDoneDate", "lastCompletedAt")
        sync_present_aliases(d, "completedAt", "doneAt")
        # 周期操作の追記前に必ず独立させ、保存失敗時にキャッシュ内の旧履歴だけが
        # 先に書き換わる参照共有を防ぐ。
        d["history"] = copy.deepcopy(as_list(d.get("history")))
        d["note"] = str(d.get("note") or "")
    return d


def clean_date(value: Any) -> str:
    s = clean_text(value)
    if not s:
        return ""
    s = s.replace("/", "-")
    m = re.match(r"^(\d{4})-(\d{1,2})-(\d{1,2})$", s)
    if m:
        try:
            return _dt.date(int(m.group(1)), int(m.group(2)), int(m.group(3))).isoformat()
        except ValueError:
            return ""
    return ""


def clean_time(value: Any) -> str:
    s = clean_text(value)
    if not s:
        return ""
    s = s.replace("時", ":").replace("分", "")
    m = re.match(r"^(\d{1,2})(?::(\d{1,2}))?$", s)
    if not m:
        return ""
    hh = int(m.group(1)); mm = int(m.group(2) or 0)
    if 0 <= hh <= 23 and 0 <= mm <= 59:
        return f"{hh:02d}:{mm:02d}"
    return ""


def add_minutes_to_time(time_text: str, minutes: int) -> str:
    t = clean_time(time_text)
    if not t or not minutes:
        return ""
    hh, mm = [int(x) for x in t.split(":")]
    total = hh * 60 + mm + int(minutes)
    if total < 0 or total >= 24 * 60:
        return ""
    return f"{total // 60:02d}:{total % 60:02d}"


def clone_record(record: dict[str, Any]) -> dict[str, Any]:
    return {
        "ok": bool(record.get("ok", True)),
        "data": copy.deepcopy(record.get("data", {})),
        "hash": clean_text(record.get("hash")),
        "updatedAt": clean_text(record.get("updatedAt")),
    }


def _normalise_record_data(app: str, data: Any) -> dict[str, Any]:
    if app == "speculum":
        return normalise_speculum(data)
    if app == "continuum":
        return normalise_continuum(data)
    raise ValueError("対象データが不正です。")


def _decode_json_object(text: Any, *, label: str = "保存データ") -> dict[str, Any]:
    try:
        parsed = json.loads(str(text or ""))
    except (TypeError, ValueError, json.JSONDecodeError, RecursionError) as exc:
        raise DataCorruptionError(f"{label}のJSONを読み取れません。") from exc
    if not isinstance(parsed, dict):
        raise DataCorruptionError(f"{label}の形式が正しくありません。")
    if not json_value_is_safe(parsed):
        raise DataCorruptionError(f"{label}に扱えない文字または数値が含まれています。")
    return parsed


def _invalidate_record_caches(app: str, key: str = "main") -> None:
    global PEOPLE_FOCUS_INDEX_KEY, PEOPLE_FOCUS_INDEX
    with RECORD_CACHE_LOCK:
        RECORD_CACHE.pop((app, key), None)
    with COMMAND_SEARCH_CACHE_LOCK:
        COMMAND_SEARCH_CACHE.clear()
    if app == "speculum":
        with PEOPLE_FOCUS_INDEX_LOCK:
            PEOPLE_FOCUS_INDEX_KEY = ""
            PEOPLE_FOCUS_INDEX = []


def _trim_history(con: sqlite3.Connection, app: str, key: str) -> None:
    con.execute(
        "DELETE FROM app_history WHERE app=? AND store_key=? AND id NOT IN ("
        "SELECT id FROM app_history WHERE app=? AND store_key=? ORDER BY id DESC LIMIT ?)",
        (app, key, app, key, APP_HISTORY_KEEP_PER_STORE),
    )


def _quarantine_corrupt_row(
    con: sqlite3.Connection,
    app: str,
    key: str,
    raw_text: str,
    sha256: str,
    reason: str,
) -> None:
    """壊れた本文を上書きする前にSQLite内へそのまま隔離する。"""
    previous = con.execute(
        "SELECT sha256, json_text FROM app_corrupt_store WHERE app=? AND store_key=? ORDER BY id DESC LIMIT 1",
        (app, key),
    ).fetchone()
    if previous and previous["sha256"] == sha256 and previous["json_text"] == raw_text:
        return
    con.execute(
        "INSERT INTO app_corrupt_store(app, store_key, sha256, json_text, detected_at, reason) VALUES(?,?,?,?,?,?)",
        (app, key, sha256, raw_text, iso_now(), reason),
    )
    con.execute(
        "DELETE FROM app_corrupt_store WHERE app=? AND store_key=? AND id NOT IN ("
        "SELECT id FROM app_corrupt_store WHERE app=? AND store_key=? ORDER BY id DESC LIMIT ?)",
        (app, key, app, key, CORRUPT_STORE_KEEP_PER_STORE),
    )


def _ensure_valid_store_row(
    con: sqlite3.Connection,
    app: str,
    key: str,
    row: sqlite3.Row,
    *,
    allow_unrecoverable: bool = False,
) -> tuple[dict[str, Any], dict[str, Any] | None]:
    """本文とハッシュを検査し、可能なら履歴から同一トランザクションで復旧する。"""
    raw_text = str(row["json_text"] or "")
    stored_sha = clean_text(row["sha256"])
    parsed: dict[str, Any] | None = None
    reason = ""
    try:
        parsed = _decode_json_object(raw_text)
    except DataCorruptionError:
        reason = "invalid_json"
    if parsed is not None and text_hash(raw_text) == stored_sha:
        return dict(row), parsed
    if parsed is not None:
        # 本文が読める場合は、壊れたハッシュだけを直して内容を一切捨てない。
        reason = "hash_mismatch"

    _quarantine_corrupt_row(con, app, key, raw_text, stored_sha, reason)
    now = iso_now()
    repaired_text = ""
    repaired_sha = ""
    repaired_data: dict[str, Any] | None = None
    if parsed is not None:
        repaired_text = raw_text
        repaired_sha = text_hash(raw_text)
        repaired_data = parsed
    else:
        history_rows = con.execute(
            "SELECT sha256, json_text FROM app_history WHERE app=? AND store_key=? ORDER BY id DESC LIMIT ?",
            (app, key, APP_HISTORY_KEEP_PER_STORE),
        ).fetchall()
        for history_row in history_rows:
            candidate_text = str(history_row["json_text"] or "")
            candidate_sha = clean_text(history_row["sha256"])
            if not candidate_sha or text_hash(candidate_text) != candidate_sha:
                continue
            try:
                candidate_data = _decode_json_object(candidate_text, label="保存履歴")
            except DataCorruptionError:
                continue
            repaired_text = candidate_text
            repaired_sha = candidate_sha
            repaired_data = candidate_data
            break

    if repaired_data is None:
        con.commit()  # 隔離記録だけは残し、元の壊れた行は変更しない。
        if allow_unrecoverable:
            return dict(row), None
        raise DataCorruptionError("保存データを自動復旧できなかったため、書き換えを停止しました。保存・復元から控えを選んでください。")

    con.execute(
        "UPDATE app_store SET json_text=?, sha256=?, updated_at=? WHERE app=? AND store_key=?",
        (repaired_text, repaired_sha, now, app, key),
    )
    con.execute(
        "INSERT INTO app_history(app, store_key, sha256, json_text, created_at) VALUES(?,?,?,?,?)",
        (app, key, repaired_sha, repaired_text, now),
    )
    _trim_history(con, app, key)
    con.commit()
    _invalidate_record_caches(app, key)
    return {
        "json_text": repaired_text,
        "sha256": repaired_sha,
        "updated_at": now,
    }, repaired_data


def load_record(app: str, key: str = "main", *, clone: bool = True) -> dict[str, Any]:
    if app not in {"speculum", "continuum"}:
        raise ValueError("対象データが不正です。")
    cache_key = (app, key)
    with RECORD_CACHE_LOCK:
        cached = RECORD_CACHE.get(cache_key)
        if cached is not None:
            return clone_record(cached) if clone else cached
    with SAVE_RECORD_LOCK:
        # キャッシュ確認とDB読込の間に別スレッドが保存した場合も、古い行を再登録しない。
        with RECORD_CACHE_LOCK:
            cached = RECORD_CACHE.get(cache_key)
            if cached is not None:
                return clone_record(cached) if clone else cached
        with db() as con:
            row = con.execute("SELECT json_text, sha256, updated_at FROM app_store WHERE app=? AND store_key=?", (app, key)).fetchone()
            if row:
                row_data, raw = _ensure_valid_store_row(con, app, key, row)
            else:
                row_data, raw = {}, None
        if not row:
            data = default_speculum() if app == "speculum" else default_continuum()
            record = {"ok": True, "data": data, "hash": "", "updatedAt": ""}
        else:
            data = _normalise_record_data(app, raw)
            record = {"ok": True, "data": data, "hash": row_data["sha256"], "updatedAt": row_data["updated_at"]}
        with RECORD_CACHE_LOCK:
            RECORD_CACHE[cache_key] = record
        return clone_record(record) if clone else record


def record_data_at_hash(app: str, sha256: str, key: str = "main") -> dict[str, Any] | None:
    """部分保存の基準になった内容を履歴から読む。見つからない古い基準は安全側で扱う。"""
    target = clean_text(sha256)
    if not target:
        return None
    with db() as con:
        row = con.execute(
            "SELECT json_text FROM app_history WHERE app=? AND store_key=? AND sha256=? ORDER BY id DESC LIMIT 1",
            (app, key, target),
        ).fetchone()
    if not row:
        return None
    raw_text = str(row["json_text"] or "")
    if text_hash(raw_text) != target:
        return None
    try:
        raw = _decode_json_object(raw_text, label="保存履歴")
    except DataCorruptionError:
        return None
    return _normalise_record_data(app, raw)


def touched_mapping_changed(base_value: Any, current_value: Any, incoming_value: Any, nested_keys: set[str] | None = None) -> bool:
    """受信したキーだけを比べ、別画面が同じキーを変更済みか判定する。"""
    base = as_dict(base_value)
    current = as_dict(current_value)
    incoming = as_dict(incoming_value)
    nested = nested_keys or set()
    for key, value in incoming.items():
        if key in nested and isinstance(value, dict):
            base_children = as_dict(base.get(key))
            current_children = as_dict(current.get(key))
            for child_key in value:
                if base_children.get(child_key) != current_children.get(child_key):
                    return True
        elif base.get(key) != current.get(key):
            return True
    return False


def _backup_due(app: str, key: str, kind: str, policy: bool | str = "auto") -> bool:
    """重いJSON控えの作成頻度を抑える。"""
    if policy is True or policy == "always":
        return True
    if policy is False or policy == "never":
        return False
    now_m = time.monotonic()
    cache_key = (app, key, kind)
    with AUTO_BACKUP_LOCK:
        last = AUTO_BACKUP_LAST.get(cache_key, 0.0)
        if now_m - last >= AUTO_BACKUP_INTERVAL_SECONDS:
            AUTO_BACKUP_LAST[cache_key] = now_m
            return True
    return False


def _copy_continuum_for_write(data: dict[str, Any]) -> dict[str, Any]:
    """作業追加・作業化用。既存項目を全件正規化せず、外枠だけ浅く複製する。"""
    return {
        "schema": 2,
        "tasks": list(as_list(data.get("tasks"))),
        "cycleTasks": list(as_list(data.get("cycleTasks"))),
        "memo": clean_multiline_text(data.get("memo")),
        "settings": _continuum_settings(data.get("settings")),
        "updatedAt": clean_text(data.get("updatedAt")) or iso_now(),
    }


def _copy_speculum_for_write(data: dict[str, Any]) -> dict[str, Any]:
    """今日・日付確認・台帳の部分保存用。外枠だけ複製して、既存配列を使い回す。"""
    holidays = as_dict(data.get("holidays"))
    return {
        "schema": 2,
        "events": list(as_list(data.get("events"))),
        "deadlines": list(as_list(data.get("deadlines"))),
        "jimu": list(as_list(data.get("jimu"))),
        "cases": list(as_list(data.get("cases"))),
        "people": list(as_list(data.get("people"))),
        "career": list(as_list(data.get("career"))),
        "holidays": {**holidays, "items": dict(as_dict(holidays.get("items")))},
        "memo": {**as_dict(data.get("memo")), "days": dict(as_dict(as_dict(data.get("memo")).get("days")))},
        "settings": dict(as_dict(data.get("settings"))),
        "updatedAt": clean_text(data.get("updatedAt")) or iso_now(),
    }


def _speculum_collection(kind: str) -> str:
    k = clean_text(kind)
    aliases = {
        "event": "events", "events": "events", "schedule": "events", "happening": "events",
        "deadline": "deadlines", "deadlines": "deadlines", "due": "deadlines",
        "jimu": "jimu", "office": "jimu",
        "case": "cases", "cases": "cases",
        "person": "people", "people": "people",
        "career": "career",
    }
    collection = aliases.get(k)
    if not collection:
        raise ValueError("保存対象の種類が不正です。")
    return collection


def _record_content_equal(left: Any, right: Any) -> bool:
    """ルートの更新時刻を除き、保存内容が同じかを軽量に判定する。

    updatedAt はサーバーが付ける管理値なので、同じ内容の再送だけで更新扱いに
    しない。各配列は通常の辞書・リスト比較を使い、JSON化とハッシュ計算より
    先に同一保存を短絡できるようにする。
    """
    a = as_dict(left)
    b = as_dict(right)
    a_keys = set(a)
    b_keys = set(b)
    a_keys.discard("updatedAt")
    b_keys.discard("updatedAt")
    if a_keys != b_keys:
        return False
    return all(a.get(key) == b.get(key) for key in a_keys)


def _item_revision_conflicts(item: Any, base_item_updated_at: Any, *, base_required: bool = False) -> bool:
    """項目単位の保存基準が現在の内容と一致するか確認する。

    画面全体のハッシュが最新でも、編集フォーム自体はそれより前に開かれた
    可能性がある。項目の更新時刻が明示された場合は常に照合し、古いフォーム
    による同一項目の上書き・削除を防ぐ。
    """
    base_updated = clean_text(base_item_updated_at)
    if base_updated:
        return clean_text(as_dict(item).get("updatedAt")) != base_updated
    return base_required


def _issue_delete_restore_tokens(app: str, collection: str, items: list[Any]) -> dict[str, str]:
    """正規の削除直後だけ、削除した実体を同じIDへ戻せる短期トークンを発行する。"""
    now_m = time.monotonic()
    expires = now_m + DELETE_RESTORE_TOKEN_TTL_SECONDS
    issued: dict[str, str] = {}
    with DELETE_RESTORE_TOKEN_LOCK:
        for token, state in list(DELETE_RESTORE_TOKENS.items()):
            if float(state.get("expires") or 0) <= now_m:
                DELETE_RESTORE_TOKENS.pop(token, None)
        # 応答を受け取れなかった削除が続いても、メモリを使い続けない。
        if len(DELETE_RESTORE_TOKENS) > 512:
            oldest = sorted(DELETE_RESTORE_TOKENS, key=lambda token: float(DELETE_RESTORE_TOKENS[token].get("expires") or 0))
            for token in oldest[: len(DELETE_RESTORE_TOKENS) - 512]:
                DELETE_RESTORE_TOKENS.pop(token, None)
        for value in items:
            item = as_dict(value)
            item_id = clean_text(item.get("id"))
            if not item_id:
                continue
            token = secrets.token_urlsafe(24)
            DELETE_RESTORE_TOKENS[token] = {
                "app": app,
                "collection": collection,
                "id": item_id,
                "item": copy.deepcopy(item),
                "expires": expires,
            }
            issued[item_id] = token
    return issued


def _delete_restore_item(token: Any, app: str, collection: str, item_id: str) -> dict[str, Any] | None:
    value = clean_text(token)
    if not value:
        return None
    now_m = time.monotonic()
    with DELETE_RESTORE_TOKEN_LOCK:
        state = DELETE_RESTORE_TOKENS.get(value)
        if not state or float(state.get("expires") or 0) <= now_m:
            DELETE_RESTORE_TOKENS.pop(value, None)
            return None
        if state.get("app") != app or state.get("collection") != collection or clean_text(state.get("id")) != item_id:
            return None
        return copy.deepcopy(as_dict(state.get("item")))


def _consume_delete_restore_token(token: Any) -> None:
    value = clean_text(token)
    if not value:
        return
    with DELETE_RESTORE_TOKEN_LOCK:
        DELETE_RESTORE_TOKENS.pop(value, None)


def _clear_delete_restore_tokens() -> None:
    with DELETE_RESTORE_TOKEN_LOCK:
        DELETE_RESTORE_TOKENS.clear()


def save_record(app: str, data: Any, key: str = "main", base_hash: str | None = None, force: bool = False, *, already_normalised: bool = False, backup_policy: bool | str = "auto") -> dict[str, Any]:
    """アプリ別JSONを保存する。

    通常保存ではSQLite履歴を毎回残し、重いJSON控えは一定間隔に抑える。
    作業追加などサーバー内で1件だけ足す経路では already_normalised=True を使い、
    既存の全作業を毎回正規化し直さない。
    """
    if app not in {"speculum", "continuum"}:
        raise ValueError("対象データが不正です。")
    # 画面が同じ内容を再送した場合は、全件正規化・JSON化・履歴追加を避ける。
    # 通常は直前の読込でキャッシュが温まっているため、大量データほど効く。
    normalised: dict[str, Any] | None = None
    cached_candidate: dict[str, Any] | None = None
    if isinstance(data, dict) and not force:
        with RECORD_CACHE_LOCK:
            cached = RECORD_CACHE.get((app, key))
            if cached is not None and _record_content_equal(data, cached.get("data")):
                cached_candidate = cached
                normalised = as_dict(cached.get("data"))
    if normalised is None:
        normalised = data if already_normalised and isinstance(data, dict) else _normalise_record_data(app, data)

    base_hash_clean = clean_text(base_hash) if base_hash is not None else None
    backup_before_change: tuple[str, str] | None = None
    changed = False
    text = ""
    h = ""
    now = ""
    with SAVE_RECORD_LOCK:
        with db() as con:
            row = con.execute("SELECT json_text, sha256, updated_at FROM app_store WHERE app=? AND store_key=?", (app, key)).fetchone()
            stored_data: dict[str, Any] | None = None
            if row:
                # このプロセスが検証済みの同一ハッシュを保持している間は、大量JSONを
                # 保存のたびに再ハッシュしない。起動後の初回読込では必ず全文を検証する。
                with RECORD_CACHE_LOCK:
                    current_cached = RECORD_CACHE.get((app, key))
                if (
                    not force
                    and current_cached is not None
                    and clean_text(current_cached.get("hash")) == clean_text(row["sha256"])
                ):
                    row_data = dict(row)
                    stored_data = as_dict(current_cached.get("data"))
                else:
                    row_data, stored_data = _ensure_valid_store_row(con, app, key, row, allow_unrecoverable=force)
            else:
                row_data = {}
            current_hash = clean_text(row_data.get("sha256")) if row else ""
            current_updated = clean_text(row_data.get("updated_at")) if row else ""
            if base_hash_clean is not None and base_hash_clean != current_hash and not force:
                raise SaveConflictError(app, key, base_hash_clean, current_hash, current_updated)

            same_content = False
            if row and not force:
                if cached_candidate is not None and clean_text(cached_candidate.get("hash")) == current_hash:
                    same_content = True
                    normalised = as_dict(cached_candidate.get("data"))
                elif stored_data is not None:
                    if _record_content_equal(normalised, stored_data):
                        same_content = True
                        normalised = stored_data

            if same_content:
                # 保存時刻・ハッシュ・履歴を変えず、他画面へ不要な再読込を発生させない。
                normalised["updatedAt"] = current_updated
                text = str(row_data.get("json_text") or "{}")
                h = current_hash
                now = current_updated
            else:
                now = iso_now()
                normalised["updatedAt"] = now
                text = stable_json(normalised)
                h = text_hash(text)
                changed = (not row) or current_hash != h
                if changed and row and stored_data is not None and _backup_due(app, key, "before", backup_policy):
                    backup_before_change = (str(row_data.get("json_text") or "{}"), current_hash or "before")
                con.execute(
                    "INSERT OR REPLACE INTO app_store(app, store_key, json_text, sha256, updated_at) VALUES(?,?,?,?,?)",
                    (app, key, text, h, now),
                )
                con.execute(
                    "INSERT INTO app_history(app, store_key, sha256, json_text, created_at) VALUES(?,?,?,?,?)",
                    (app, key, h, text, now),
                )
                _trim_history(con, app, key)
                con.commit()
        with RECORD_CACHE_LOCK:
            RECORD_CACHE[(app, key)] = {"ok": True, "data": normalised, "hash": h, "updatedAt": now}
        if changed:
            with COMMAND_SEARCH_CACHE_LOCK:
                COMMAND_SEARCH_CACHE.clear()
            if app == "speculum":
                global PEOPLE_FOCUS_INDEX_KEY, PEOPLE_FOCUS_INDEX
                with PEOPLE_FOCUS_INDEX_LOCK:
                    PEOPLE_FOCUS_INDEX_KEY = ""
                    PEOPLE_FOCUS_INDEX = []
    if backup_before_change:
        queue_backup_text(app, key, backup_before_change[0], f"before_{backup_before_change[1]}")
    if changed and _backup_due(app, key, "after", backup_policy):
        queue_backup_text(app, key, text, f"after_{h}")
    return {"ok": True, "data": normalised, "hash": h, "changed": changed, "updatedAt": now}

def _atomic_write_text(path: Path, text: str) -> None:
    """同一フォルダ内の一時ファイルをfsyncしてから置換し、途中終了の断片を見せない。"""
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(f".{path.name}.{os.getpid()}.{secrets.token_hex(6)}.tmp")
    try:
        with temp.open("x", encoding="utf-8", newline="\n") as handle:
            handle.write(text)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temp, path)
        # ディレクトリエントリの確定も可能なOSでは同期する。Windows等では置換成功を採用する。
        try:
            directory_fd = os.open(path.parent, os.O_RDONLY | getattr(os, "O_DIRECTORY", 0))
            try:
                os.fsync(directory_fd)
            finally:
                os.close(directory_fd)
        except OSError:
            pass
    finally:
        try:
            temp.unlink()
        except FileNotFoundError:
            pass


def _next_backup_path(app: str, key: str, sha: str, content_sha: str) -> Path:
    stamp = jst_now().strftime("%Y%m%d_%H%M%S_%f")
    safe_app = re.sub(r"[^0-9A-Za-z_-]+", "", clean_text(app)) or "data"
    safe_key = re.sub(r"[^0-9A-Za-z_-]+", "", clean_text(key)) or "main"
    tag = re.sub(r"[^0-9A-Za-z_-]+", "", clean_text(sha) or "backup")[:32] or "backup"
    actual = re.sub(r"[^0-9a-f]+", "", clean_text(content_sha).lower())[:64]
    p = BACKUP_ROOT / f"{safe_app}_{safe_key}_{stamp}_{tag}_h{actual}.json"
    counter = 1
    while p.exists():
        p = BACKUP_ROOT / f"{safe_app}_{safe_key}_{stamp}_{tag}_h{actual}_{counter}.json"
        counter += 1
    return p


def _prune_json_backups(app: str, key: str) -> None:
    safe_app = re.sub(r"[^0-9A-Za-z_-]+", "", clean_text(app)) or "data"
    safe_key = re.sub(r"[^0-9A-Za-z_-]+", "", clean_text(key)) or "main"
    backups: list[tuple[float, Path]] = []
    for path in BACKUP_ROOT.glob(f"{safe_app}_{safe_key}_*.json"):
        try:
            modified = path.stat().st_mtime
        except OSError:
            continue
        backups.append((modified, path))
    backups.sort(key=lambda item: item[0], reverse=True)
    for _, extra_backup in backups[JSON_BACKUP_KEEP_PER_STORE:]:
        try:
            extra_backup.unlink()
        except OSError:
            pass


def _write_backup_content(app: str, key: str, text: str, sha: str) -> Path:
    ensure_dirs()
    content = text or "{}"
    with BACKUP_FILE_LOCK:
        # 実際に書く本文の完全なSHAを名前へ含め、JSONとして読めても内容が
        # 変質した控えを復元前に検出できるようにする。
        path = _next_backup_path(app, key, sha, text_hash(content))
        _atomic_write_text(path, content)
        _prune_json_backups(app, key)
        return path


def write_backup(app: str, key: str, data: Any, sha: str) -> Path:
    return _write_backup_content(app, key, pretty_json(data), sha)


def write_backup_text(app: str, key: str, text: str, sha: str) -> Path:
    return _write_backup_content(app, key, text or "{}", sha)


def _backup_worker() -> None:
    while True:
        app, key, text, sha = BACKUP_QUEUE.get()
        try:
            write_backup_text(app, key, text, sha)
        except Exception as exc:
            try:
                ensure_dirs()
                with (BACKUP_ROOT / "backup_error.log").open("a", encoding="utf-8") as f:
                    f.write(f"{iso_now()} {app}/{key}: {exc}\n")
            except Exception:
                pass
        finally:
            BACKUP_QUEUE.task_done()


def ensure_backup_worker() -> None:
    global BACKUP_WORKER_STARTED
    if BACKUP_WORKER_STARTED:
        return
    with BACKUP_WORKER_LOCK:
        if BACKUP_WORKER_STARTED:
            return
        threading.Thread(target=_backup_worker, name="blackcat-backup-writer", daemon=True).start()
        BACKUP_WORKER_STARTED = True


def queue_backup_text(app: str, key: str, text: str, sha: str) -> None:
    ensure_backup_worker()
    BACKUP_QUEUE.put((app, key, text or "{}", sha or "backup"))


def flush_pending_backups(timeout_seconds: float = 5.0) -> bool:
    """通常終了時に、確定済み保存のJSON控えを可能な範囲で書き切る。"""
    if BACKUP_QUEUE.unfinished_tasks <= 0:
        return True
    ensure_backup_worker()
    deadline = time.monotonic() + max(0.0, timeout_seconds)
    while BACKUP_QUEUE.unfinished_tasks > 0 and time.monotonic() < deadline:
        time.sleep(0.02)
    return BACKUP_QUEUE.unfinished_tasks <= 0


def save_draft_backup(app: str, data: Any, key: str = "main") -> Path:
    normalised = normalise_speculum(data) if app == "speculum" else normalise_continuum(data)
    normalised["draftSavedAt"] = iso_now()
    return write_backup(app, key, normalised, f"draft_{text_hash(stable_json(normalised))}")


def valid_store_app(value: Any) -> str:
    app = clean_text(value) or "speculum"
    if app not in {"speculum", "continuum"}:
        raise ValueError("対象データが不正です。")
    return app


def _backup_label_time(value: Any) -> str:
    if isinstance(value, _dt.datetime):
        dt = value
    else:
        try:
            dt = _dt.datetime.fromisoformat(clean_text(value))
        except ValueError:
            return "日時不明"
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=_dt.timezone.utc).astimezone(_dt.timezone(_dt.timedelta(hours=9)))
    else:
        dt = dt.astimezone(_dt.timezone(_dt.timedelta(hours=9)))
    return dt.strftime("%Y/%m/%d %H:%M")


def _json_backup_kind(name: str) -> str:
    lower = clean_text(name).lower()
    if "_draft_" in lower:
        return "下書きの控え"
    if "_before_restore_" in lower:
        return "復元前の控え"
    if "_before_" in lower:
        return "保存前の控え"
    if "_startup_" in lower:
        return "起動時の控え"
    if "_after_" in lower or "_auto_" in lower:
        return "自動の控え"
    return "手動の控え"


def backup_list(app: str, key: str = "main") -> list[dict[str, Any]]:
    app = valid_store_app(app)
    out: list[dict[str, Any]] = []
    seen_history: set[str] = set()
    file_rows: list[tuple[float, Path, os.stat_result]] = []
    with BACKUP_FILE_LOCK:
        for path in BACKUP_ROOT.glob(f"{app}_{key}_*.json"):
            try:
                stat = path.stat()
            except OSError:
                continue
            file_rows.append((stat.st_mtime, path, stat))
    for _, p, st in sorted(file_rows, key=lambda item: item[0], reverse=True):
        # ラベルに含まれる元保存ハッシュは、同じSQLite履歴を重複表示しすぎないための目印にする。
        for bit in p.stem.split("_"):
            if re.fullmatch(r"[0-9a-fA-F]{12,64}", bit):
                seen_history.add(bit)
                seen_history.add(bit[:12])
        updated_dt = _dt.datetime.fromtimestamp(st.st_mtime, tz=_dt.timezone.utc).astimezone(_dt.timezone(_dt.timedelta(hours=9)))
        out.append({
            "name": p.name,
            "label": f"{_json_backup_kind(p.name)}（{_backup_label_time(updated_dt)}）",
            "source": "json",
            "size": st.st_size,
            "updatedAt": updated_dt.isoformat(),
        })
    try:
        with db() as con:
            rows = con.execute(
                "SELECT id, sha256, length(json_text) AS size, created_at FROM app_history WHERE app=? AND store_key=? ORDER BY id DESC LIMIT ?",
                (app, key, APP_HISTORY_KEEP_PER_STORE),
            ).fetchall()
        for row in rows:
            sha = clean_text(row["sha256"])
            tag = sha[:12]
            if tag and tag in seen_history:
                continue
            out.append({
                "name": f"history:{int(row['id'])}",
                "label": f"保存履歴（{_backup_label_time(row['created_at'])}）",
                "source": "sqlite",
                "size": int(row["size"] or 0),
                "updatedAt": clean_text(row["created_at"]),
            })
    except Exception:
        pass
    out.sort(key=lambda x: clean_text(x.get("updatedAt")), reverse=True)
    return out[: max(120, APP_HISTORY_KEEP_PER_STORE)]


def _restore_json_object(text: str, *, expected_sha: str = "") -> dict[str, Any]:
    if expected_sha and text_hash(text) != clean_text(expected_sha):
        raise ValueError("復元する控えの整合性を確認できません。別の控えを選んでください。")
    try:
        return _decode_json_object(text, label="復元する控え")
    except DataCorruptionError as exc:
        raise ValueError("復元する控えを読み取れません。別の控えを選んでください。") from exc


def _backup_content_sha_from_name(name: str) -> str:
    match = re.search(r"_h([0-9a-f]{64})(?:_\d+)?\.json$", clean_text(name))
    return match.group(1) if match else ""


def _is_database_corruption_error(error: BaseException) -> bool:
    message = str(error).lower()
    return any(
        marker in message
        for marker in (
            "database disk image is malformed",
            "file is not a database",
            "database corruption",
            "database schema is corrupt",
            "malformed database schema",
        )
    )


def _clear_all_data_caches() -> None:
    global PEOPLE_FOCUS_INDEX_KEY, PEOPLE_FOCUS_INDEX, SUMMARY_CACHE_KEY, SUMMARY_CACHE_VALUE
    with RECORD_CACHE_LOCK:
        RECORD_CACHE.clear()
    with COMMAND_SEARCH_CACHE_LOCK:
        COMMAND_SEARCH_CACHE.clear()
    with PEOPLE_FOCUS_INDEX_LOCK:
        PEOPLE_FOCUS_INDEX_KEY = ""
        PEOPLE_FOCUS_INDEX = []
    with SUMMARY_CACHE_LOCK:
        SUMMARY_CACHE_KEY = None
        SUMMARY_CACHE_VALUE = None
    with AUTO_BACKUP_LOCK:
        AUTO_BACKUP_LAST.clear()
    _clear_delete_restore_tokens()


def _quarantine_corrupt_database(error: BaseException) -> Path:
    """物理破損したSQLite一式を残したまま、JSON控えを復元できる状態へ戻す。"""
    global DB_SCHEMA_READY_PATH
    if not _is_database_corruption_error(error):
        raise error
    stamp = jst_now().strftime("%Y%m%d_%H%M%S_%f")
    quarantine = DATA_ROOT / "corrupt_databases" / stamp
    quarantine.mkdir(parents=True, exist_ok=False)
    sources = [DB_PATH, Path(f"{DB_PATH}-wal"), Path(f"{DB_PATH}-shm"), Path(f"{DB_PATH}-journal")]
    moved: list[tuple[Path, Path]] = []
    try:
        # 本体を最後に動かし、付随ファイルの移動失敗だけで現用DBを消さない。
        for source in [*sources[1:], sources[0]]:
            if not source.exists():
                continue
            destination = quarantine / source.name
            os.replace(source, destination)
            moved.append((source, destination))
        if not any(source == DB_PATH for source, _ in moved):
            raise sqlite3.DatabaseError("破損した保存データ本体を隔離できません。")
        _atomic_write_text(quarantine / "RECOVERY_NOTE.txt", f"検出日時: {iso_now()}\n理由: {error}\n")
    except Exception:
        for source, destination in reversed(moved):
            if destination.exists() and not source.exists():
                try:
                    os.replace(destination, source)
                except OSError:
                    pass
        raise
    DB_SCHEMA_READY_PATH = ""
    _clear_all_data_caches()
    return quarantine


def _latest_valid_json_backup(app: str, key: str = "main") -> tuple[dict[str, Any], str] | None:
    rows: list[tuple[float, Path]] = []
    with BACKUP_FILE_LOCK:
        for path in BACKUP_ROOT.glob(f"{app}_{key}_*.json"):
            if "_draft_" in path.name:
                continue
            try:
                rows.append((path.stat().st_mtime, path))
            except OSError:
                continue
        for _, path in sorted(rows, key=lambda item: item[0], reverse=True):
            try:
                text = path.read_text(encoding="utf-8")
                data = _restore_json_object(text, expected_sha=_backup_content_sha_from_name(path.name))
            except (OSError, UnicodeError, ValueError):
                continue
            return data, path.name
    return None


def backup_restore(app: str, name: str, key: str = "main") -> dict[str, Any]:
    app = valid_store_app(app)
    name = clean_text(name)
    with SAVE_RECORD_LOCK:
        if name.startswith("history:"):
            try:
                history_id = int(name.split(":", 1)[1])
            except Exception as exc:
                raise ValueError("復元対象が見つかりません。") from exc
            with db() as con:
                row = con.execute(
                    "SELECT json_text, sha256 FROM app_history WHERE app=? AND store_key=? AND id=?",
                    (app, key, history_id),
                ).fetchone()
            if not row:
                raise ValueError("復元対象が見つかりません。")
            restore_text = str(row["json_text"] or "")
            data = _restore_json_object(restore_text, expected_sha=clean_text(row["sha256"]))
        else:
            p = (BACKUP_ROOT / name).resolve()
            root = BACKUP_ROOT.resolve()
            with BACKUP_FILE_LOCK:
                if root not in p.parents or not p.is_file() or not p.name.startswith(f"{app}_{key}_"):
                    raise ValueError("復元対象が見つかりません。")
                try:
                    restore_text = p.read_text(encoding="utf-8")
                except (OSError, UnicodeError) as exc:
                    raise ValueError("復元する控えを読み取れません。別の控えを選んでください。") from exc
            expected_sha = _backup_content_sha_from_name(p.name)  # 旧形式の控えはJSON形式だけを検査する。
            data = _restore_json_object(restore_text, expected_sha=expected_sha)
        data = _normalise_record_data(app, data)

        # 対象の検証が終わってから現在値を控える。壊れた控えを選んでも履歴を増やさない。
        database_rebuilt = False
        recovered_other_apps: list[str] = []
        # 復元操作ではキャッシュだけを信頼せず、現用SQLiteを実際に検査する。
        with RECORD_CACHE_LOCK:
            RECORD_CACHE.pop((app, key), None)
        try:
            current = load_record(app, key)
        except DataCorruptionError:
            # 復旧不能な現在値は app_corrupt_store に隔離済み。選択した正常な控えで復旧できる。
            current = None
        except sqlite3.DatabaseError as exc:
            if name.startswith("history:") or not _is_database_corruption_error(exc):
                raise
            _quarantine_corrupt_database(exc)
            database_rebuilt = True
            current = None
            # 選択対象でない側も、未保存の下書きを除く最新の正常JSON控えから戻す。
            for other_app in {"speculum", "continuum"} - {app}:
                latest = _latest_valid_json_backup(other_app, key)
                if latest is None:
                    continue
                save_record(other_app, latest[0], key, force=True, backup_policy="never")
                recovered_other_apps.append(other_app)
        if current is not None:
            current_data = as_dict(current.get("data"))
            if app == "speculum":
                continuum = as_dict(load_record("continuum", key, clone=False).get("data"))
                _assert_speculum_document_reference_integrity(current_data, data, continuum)
            else:
                speculum = as_dict(load_record("speculum", key, clone=False).get("data"))
                _assert_continuum_document_reference_integrity(current_data, data, speculum)
        if current and current.get("hash"):
            write_backup(app, key, current.get("data", {}), f"before_restore_{clean_text(current.get('hash')) or 'data'}")
        restored = save_record(app, data, key, force=True, backup_policy="always")
        # 復元前の画面に残っている削除Undoで、復元後の状態を再変更させない。
        _clear_delete_restore_tokens()
        if database_rebuilt:
            restored["databaseRecovered"] = True
            restored["otherAppsRecovered"] = sorted(recovered_other_apps)
        return restored


def parse_natural(text: str, default_day: str | None = None) -> dict[str, str]:
    raw = clean_text(text)
    title = raw
    day = parse_day(raw, default_day)
    tm = parse_time(raw)
    remove_patterns = [
        r"(?<!\d)\d{4}[-/]\d{1,2}[-/]\d{1,2}(?!\d)", r"(?<!\d)\d{4}年\d{1,2}月\d{1,2}日", r"(?<!\d)\d{1,2}[-/]\d{1,2}(?!\d)", r"\d{1,2}月\d{1,2}日",
        r"今日やる|今やる|今日へ|今日に|今日中|今日|本日|明日|あした|明後日|あさって|今週(?:の)?[月火水木金土日](?:曜(?:日)?)?|来週(?:の)?[月火水木金土日](?:曜(?:日)?)?|(?:次の|今度の)[月火水木金土日]曜(?:日)?|今週末|来週末|今週(?:まで|中)(?:に)?|来週(?:まで|中)(?:に)?|[月火水木金土日]曜(?:日)?(?:の)?",
        r"今月末|来月末|月末|月初",
        r"\d+\s*週間?後|\d+\s*日後",
        r"朝(?=\s*\d{1,2}時)", r"(?:午前|午後|am|pm|AM|PM)?\s*\d{1,2}:\d{2}", r"(?:午前|午後|am|pm|AM|PM)?\s*\d{1,2}時(?!間)(?:半|\d{0,2}分?)", r"正午|昼一|朝一|夕方", r"@[\d:/\-時分]+",
        r"(^|[\s　,、。])\d+(?:\.\d+)?\s*(?:時間|h|H)(?:\s*\d{1,2}\s*(?:分|m|M))?(?=$|[\s　,、。])",
        r"(^|[\s　,、。])\d{1,3}\s*(?:分|m|M)(?=$|[\s　,、。])",
    ]
    for pat in remove_patterns:
        title = re.sub(pat, " ", title)
    # 操作語は「命令として置かれた部分」だけ落とし、
    # 「返却作業」「予定表確認」のようなタイトル中の語は残す。
    title = clean_text(title)
    title = re.sub(r"^(?:の|に|まで|期限で|期日で|日付で)\s*", "", title)
    lead_cmd = re.match(r"^(?:予定|出来事|できごと|期限|事務|作業|タスク)(?:を)?(?:追加|登録)(?:したい|して|する)?\s*(.+)$", title)
    if lead_cmd:
        title = lead_cmd.group(1)
    lead_cmd = re.match(r"^(?:期限で|期日で|日付で|まで)?\s*(?:予定|出来事|できごと|期限|事務|作業|タスク)(?:を)?(?:追加|登録)(?:したい|して|する)?\s*(.+)$", title)
    if lead_cmd and clean_text(lead_cmd.group(1)):
        title = lead_cmd.group(1)
    suffix_cmd = re.match(r"^(.+?)(?:を)?(?:予定|出来事|できごと|期限|事務|作業|タスク)(?:として|に)?(?:追加|登録)(?:したい|して|する)?$", title)
    if suffix_cmd:
        title = suffix_cmd.group(1)
    suffix_cmd = re.match(r"^(.+?)(?:を)?(?:追加|登録)(?:したい|して|する)?$", title)
    if suffix_cmd:
        title = suffix_cmd.group(1)
    suffix_kind = re.match(r"^(.+?)[\s　、,]+(?:予定|出来事|できごと|期限|事務|作業|タスク|やること)$", title)
    if suffix_kind and clean_text(suffix_kind.group(1)):
        title = suffix_kind.group(1)
    if re.match(r"^(?:予定|出来事|できごと|期限|事務|作業|タスク|やること)[:：、,\s]+", title):
        title = re.sub(r"^(?:予定|出来事|できごと|期限|事務|作業|タスク|やること)[:：、,\s]+", "", title)
    title = strip_leading_command_noise(title)
    title = strip_priority_noise(strip_duration_noise(title))
    title = clean_text(title) or strip_duration_noise(raw) or raw or "無題"
    return {"title": title, "date": day, "time": tm}


def parse_day(text: str, default_day: str | None = None) -> str:
    base = today_date()
    s = text or ""
    if "明後日" in s or "あさって" in s:
        return (base + _dt.timedelta(days=2)).isoformat()
    if "明日" in s or "あした" in s:
        return (base + _dt.timedelta(days=1)).isoformat()
    if "今日" in s or "本日" in s:
        return base.isoformat()
    if "来週末" in s or re.search(r"来週(?:まで|中)(?:に)?", s):
        delta = 4 - base.weekday() + 7
        return (base + _dt.timedelta(days=delta)).isoformat()
    if "今週末" in s or re.search(r"今週(?:まで|中)(?:に)?", s):
        delta = max(0, 4 - base.weekday())
        return (base + _dt.timedelta(days=delta)).isoformat()
    if "来月末" in s:
        return end_of_month(add_months(base.replace(day=1), 1)).isoformat()
    if "今月末" in s or "月末" in s:
        return end_of_month(base).isoformat()
    if "月初" in s:
        first = base.replace(day=1)
        if first < base:
            first = add_months(first, 1)
        return first.isoformat()
    m = re.search(r"(\d{4})[-/](\d{1,2})[-/](\d{1,2})", s)
    if not m:
        m = re.search(r"(\d{4})年(\d{1,2})月(\d{1,2})日", s)
    if m:
        try:
            return _dt.date(int(m.group(1)), int(m.group(2)), int(m.group(3))).isoformat()
        except ValueError:
            pass
    m = re.search(r"(\d{1,2})[-/](\d{1,2})", s)
    if not m:
        m = re.search(r"(\d{1,2})月(\d{1,2})日", s)
    if m:
        month = int(m.group(1)); day = int(m.group(2)); year = base.year
        try:
            d = _dt.date(year, month, day)
            if d < base - _dt.timedelta(days=45):
                d = _dt.date(year + 1, month, day)
            return d.isoformat()
        except ValueError:
            pass
    m = re.search(r"(今週|来週)(?:の)?([月火水木金土日])曜(?:日)?", s)
    if not m:
        # 「来週金」のような短い入力も従来どおり扱う。
        m = re.search(r"(今週|来週)([月火水木金土日])", s)
    if m:
        target = WEEKDAYS[m.group(2)]
        delta = target - base.weekday()
        if m.group(1) == "来週":
            delta += 7
        elif delta < 0:
            delta += 7
        return (base + _dt.timedelta(days=delta)).isoformat()
    m = re.search(r"([月火水木金土日])曜(?:日)?", s)
    next_weekday = re.search(r"(?:次の|今度の)([月火水木金土日])曜(?:日)?", s)
    if next_weekday:
        target = WEEKDAYS[next_weekday.group(1)]
        delta = (target - base.weekday()) % 7
        return (base + _dt.timedelta(days=delta or 7)).isoformat()
    if m:
        target = WEEKDAYS[m.group(1)]
        delta = target - base.weekday()
        if delta < 0:
            delta += 7
        return (base + _dt.timedelta(days=delta)).isoformat()
    if re.search(r"来週(?![月火水木金土日])", s):
        return (base + _dt.timedelta(days=7)).isoformat()
    m = re.search(r"(\d+)日後", s)
    if m:
        return (base + _dt.timedelta(days=int(m.group(1)))).isoformat()
    m = re.search(r"(\d+)\s*週間?後", s)
    if m:
        return (base + _dt.timedelta(days=7 * int(m.group(1)))).isoformat()
    return clean_date(default_day) or base.isoformat()


def parse_time(text: str) -> str:
    s = text or ""
    if re.search(r"正午|昼一", s):
        return "12:00"
    if "朝一" in s:
        return "09:00"
    if "夕方" in s:
        return "17:00"
    def apply_ampm(hour: int, marker: str) -> int:
        m = (marker or "").lower()
        if marker == "午後" or m == "pm":
            return hour + 12 if hour < 12 else hour
        if marker == "午前" or m == "am":
            return 0 if hour == 12 else hour
        # 執務用の自然入力では「3時半 会議」は午後の意味になりやすい。
        # ただし「朝7時」のように朝を明示した場合は午前のまま扱う。
        if 1 <= hour <= 7 and not re.search(r"朝|早朝", s):
            return hour + 12
        return hour
    m = re.search(r"(午前|午後|am|pm|AM|PM)?\s*(\d{1,2}):(\d{2})", s)
    if m:
        h = apply_ampm(int(m.group(2)), m.group(1) or "")
        return clean_time(f"{h}:{m.group(3)}")
    m = re.search(r"(午前|午後|am|pm|AM|PM)?\s*(\d{1,2})時(?!間)(?:(半)|(\d{1,2})分?)?", s)
    if m:
        h = apply_ampm(int(m.group(2)), m.group(1) or "")
        minute = "30" if m.group(3) else (m.group(4) or "00")
        return clean_time(f"{h}:{minute}")
    return ""



def strip_leading_command_noise(title: str) -> str:
    t = clean_text(title)
    for _ in range(3):
        before = t
        t = re.sub(r"^(?:の|に|へ|で|まで|期限で|期日で|日付で)\s*", "", t)
        t = re.sub(r"^(?:期限|期日|日付)?(?:予定|出来事|できごと|期限|事務|作業|タスク|やること)(?:を)?(?:追加|登録)(?:したい|して|する)?\s*", "", t)
        t = re.sub(r"^(?:予定|出来事|できごと|期限|事務|作業|タスク|やること)(?:を)?(?:追加|登録)(?:したい|して|する)?\s*", "", t)
        t = clean_text(t)
        if t == before:
            break
    return t




def infer_priority(text: str, payload: dict[str, Any] | None = None) -> str:
    payload = payload or {}
    p = clean_text(payload.get("priority"))
    if p:
        return p
    q = clean_text(text)
    if re.search(r"(^|[\s　,、。])(?:高優先|優先度高|重要|高)(?:$|[\s　,、。])", q):
        return "high"
    if re.search(r"(^|[\s　,、。])(?:低優先|優先度低|低)(?:$|[\s　,、。])", q):
        return "low"
    return "normal"


def strip_priority_noise(title: str) -> str:
    t = clean_text(title)
    for _ in range(2):
        before = t
        t = re.sub(r"(^|[\s　,、。])(?:高優先|優先度高|重要|高)(?:$|[\s　,、。])", " ", t)
        t = re.sub(r"(^|[\s　,、。])(?:低優先|優先度低|低)(?:$|[\s　,、。])", " ", t)
        t = re.sub(r"(^|[\s　,、。])(?:通常優先|優先度通常|通常)(?:$|[\s　,、。])", " ", t)
        t = clean_text(t)
        if t == before:
            break
    return t



def parse_duration_minutes(text: str, payload: dict[str, Any] | None = None) -> int:
    """作業のざっくり見積時間を分で読む。既存データ互換のため、無い場合は0。"""
    payload = payload or {}
    for key in ("estimateMinutes", "durationMinutes", "minutes"):
        raw = payload.get(key)
        try:
            val = int(float(str(raw).replace(",", "")))
            if 0 < val <= 24 * 60:
                return val
        except Exception:
            pass
    s = clean_text(text)
    # 「15時30分」の30分は開始時刻の一部で、所要時間ではない。
    # 時計表現だけを除いてから、独立した「30分」「1時間」を読む。
    duration_source = re.sub(r"(?:午前|午後|am|pm|AM|PM)?\s*\d{1,2}:\d{2}", " ", s)
    duration_source = re.sub(r"(?:午前|午後|am|pm|AM|PM)?\s*\d{1,2}時(?!間)(?:半|\d{1,2}分?)?", " ", duration_source)
    patterns = [
        r"(?<!\d)(\d+(?:\.\d+)?)\s*(?:時間|h|H)(?:\s*(\d{1,2})\s*(?:分|m|M))?",
        r"(?<!\d)(\d{1,3})\s*(?:分|m|M)(?![a-zA-Z])",
    ]
    for pat in patterns:
        m = re.search(pat, duration_source)
        if not m:
            continue
        if "時間" in m.group(0) or re.search(r"\d\s*[hH]", m.group(0)):
            hours = float(m.group(1))
            mins = int(m.group(2) or 0) if len(m.groups()) >= 2 else 0
            val = int(round(hours * 60 + mins))
        else:
            val = int(m.group(1))
        if 0 < val <= 24 * 60:
            return val
    return 0


def strip_duration_noise(text: str) -> str:
    t = clean_text(text)
    # 「30分 資料確認」「資料確認 1時間」「2h 月報」のような見積語だけを落とす。
    duration_patterns = [
        r"(^|[\s　,、。])\d+(?:\.\d+)?\s*(?:時間|h|H)(?:\s*\d{1,2}\s*(?:分|m|M))?(?=$|[\s　,、。])",
        r"(^|[\s　,、。])\d{1,3}\s*(?:分|m|M)(?=$|[\s　,、。])",
    ]
    for pat in duration_patterns:
        t = re.sub(pat, " ", t)
    return clean_text(t)


def format_duration_minutes(value: Any) -> str:
    try:
        minutes = int(float(str(value)))
    except Exception:
        return ""
    if minutes <= 0:
        return ""
    h, m = divmod(minutes, 60)
    if h and m:
        return f"{h}時間{m}分"
    if h:
        return f"{h}時間"
    return f"{m}分"


def infer_task_status_from_text(text: str, payload: dict[str, Any] | None = None) -> str:
    payload = payload or {}
    raw = clean_text(payload.get("status"))
    if raw:
        return normalize_work_status(raw)
    q = clean_text(text)
    if any(w in q for w in ["今日やる", "今日へ", "今日に", "今日中", "今やる"]):
        return "today"
    if any(w in q for w in ["待ち", "保留"]):
        return "waiting"
    return "next"


def is_periodic_command_text(text: str) -> bool:
    """吹き出し入力で周期作業として扱うべきかを判定する。

    「月末 資料確認」「来月末 申告書確認」は日付語として扱い、
    「毎月 月末」「月末ごと」のように繰り返し意図がある時だけ周期にする。
    """
    q = clean_text(text)
    if not q:
        return False
    if any(w in q for w in ["周期", "サイクル", "繰り返し", "毎日", "毎週", "毎月", "毎年", "年次"]):
        return True
    if re.search(r"(?:月初|月始め|月始|月末|月終わり|月終)\s*(?:ごと|毎|周期|サイクル)", q):
        return True
    if re.search(r"(?:ごと|毎|周期|サイクル)\s*(?:月初|月始め|月始|月末|月終わり|月終)", q):
        return True
    if re.search(r"\d+\s*か?ヶ?月(?:ごと|毎)", q) or any(w in q for w in ["隔月", "四半期"]):
        return True
    return False


def has_task_intent_text(text: str) -> bool:
    q = clean_text(text)
    return any(w in q for w in ["今日やる", "今やる", "今日へ", "今日に", "作業", "タスク", "やること", "待ち", "保留"])

def end_of_month(d: _dt.date) -> _dt.date:
    first_next = add_months(d.replace(day=1), 1)
    return first_next - _dt.timedelta(days=1)


def infer_cycle_start(text: str, default_day: Any = None) -> str:
    explicit = clean_date(default_day)
    if explicit:
        return explicit
    s = text or ""
    base = today_date()
    if "月初" in s or "月始" in s or "月始め" in s:
        first = base.replace(day=1)
        if first < base:
            first = add_months(first, 1)
        return first.isoformat()
    if "月末" in s or "月終" in s:
        last = end_of_month(base)
        if last < base:
            last = end_of_month(add_months(base.replace(day=1), 1))
        return last.isoformat()
    m = re.search(r"毎月\s*(\d{1,2})日", s)
    if m:
        day = max(1, min(31, int(m.group(1))))
        first = base.replace(day=1)
        last = end_of_month(first).day
        candidate = first.replace(day=min(day, last))
        if candidate < base:
            first = add_months(first, 1)
            candidate = first.replace(day=min(day, end_of_month(first).day))
        return candidate.isoformat()
    return parse_day(s, None)


def clean_cycle_title(text: str, fallback: str) -> str:
    t = clean_text(fallback or text)
    patterns = [
        r"毎日", r"毎週\s*[月火水木金土日]曜(?:日)?", r"毎週",
        r"毎月\s*\d{1,2}日", r"毎月", r"毎年\s*\d{1,2}月\d{1,2}日", r"毎年",
        r"\d+\s*か?ヶ?月(?:ごと|毎)?", r"隔月", r"四半期",
        r"月初|月始め|月始|月末|月終わり|月終|ごと",
    ]
    for pat in patterns:
        t = re.sub(pat, " ", t)
    t = strip_leading_command_noise(t)
    return clean_text(t) or clean_text(fallback) or clean_text(text) or "無題の周期作業"


def natural_datetime_validation_error(value: Any) -> str:
    """明示された無効日付・時刻が、既定の「今日・時刻なし」に化けるのを防ぐ。"""
    text = clean_text(value)
    if not text:
        return ""

    remaining = text
    full_date_patterns = (
        r"(?<!\d)(\d{4})[-/](\d{1,2})[-/](\d{1,2})(?!\d)",
        r"(?<!\d)(\d{4})年(\d{1,2})月(\d{1,2})日",
    )
    for pattern in full_date_patterns:
        for match in re.finditer(pattern, remaining):
            try:
                _dt.date(int(match.group(1)), int(match.group(2)), int(match.group(3)))
            except ValueError:
                return "日付が正しくありません。実在する年月日を入力してください。"
        remaining = re.sub(pattern, " ", remaining)

    yearless_patterns = (
        r"(?<![\d/-])(\d{1,2})[-/](\d{1,2})(?![\d/-])",
        r"(?<!\d)(\d{1,2})月(\d{1,2})日",
    )
    for pattern in yearless_patterns:
        for match in re.finditer(pattern, remaining):
            try:
                _dt.date(today_date().year, int(match.group(1)), int(match.group(2)))
            except ValueError:
                return "日付が正しくありません。実在する月日を入力してください。"

    colon_time = re.compile(r"(?<!\d)(午前|午後|am|pm|AM|PM)?\s*(\d{1,2}):(\d{2})(?!\d)")
    for match in colon_time.finditer(text):
        marker = clean_text(match.group(1)).lower()
        hour = int(match.group(2)); minute = int(match.group(3))
        valid_hour = 1 <= hour <= 12 if marker else 0 <= hour <= 23
        if not valid_hour or not 0 <= minute <= 59:
            return "時刻が正しくありません。0時から23時59分までで入力してください。"

    japanese_time = re.compile(r"(?<!\d)(午前|午後|am|pm|AM|PM)?\s*(\d{1,2})時(?!間)(?:(半)|(\d{1,2})分?)?")
    for match in japanese_time.finditer(text):
        marker = clean_text(match.group(1)).lower()
        hour = int(match.group(2)); minute = 30 if match.group(3) else int(match.group(4) or 0)
        valid_hour = 1 <= hour <= 12 if marker else 0 <= hour <= 23
        if not valid_hour or not 0 <= minute <= 59:
            return "時刻が正しくありません。0時から23時59分までで入力してください。"
    return ""


def validate_natural_datetime(value: Any) -> None:
    error = natural_datetime_validation_error(value)
    if error:
        raise ValueError(error)


def validate_explicit_date(value: Any, label: str = "日付") -> None:
    text = clean_text(value)
    if text and not clean_date(text):
        raise ValueError(f"{label}が正しくありません。実在する日付を入力してください。")


def validate_explicit_time(value: Any, label: str = "時刻") -> None:
    text = clean_text(value)
    if text and not clean_time(text):
        raise ValueError(f"{label}が正しくありません。0時から23時59分までで入力してください。")


def quick_add_speculum(kind: str, payload: dict[str, Any]) -> dict[str, Any]:
    text = clean_text(payload.get("text") or payload.get("title") or payload.get("name"))
    if not text:
        raise ValueError("登録する内容を入力してください。")
    validate_natural_datetime(text)
    for field, label in (("date", "日付"), ("due", "期限日")):
        if field in payload:
            validate_explicit_date(payload.get(field), label)
    for field, label in (("time", "開始時刻"), ("endTime", "終了時刻")):
        if field in payload:
            validate_explicit_time(payload.get(field), label)
    parsed = parse_natural(text, payload.get("date") or payload.get("due"))
    now = iso_now()
    base_hash_value = payload.get("baseHash") if "baseHash" in payload else payload.get("hash")
    base_hash_supplied = base_hash_value is not None
    base_hash_clean = clean_text(base_hash_value) if base_hash_supplied else ""
    with SAVE_RECORD_LOCK:
        record = load_record("speculum", clone=False)
        # 既存の人物・経歴・予定を全件正規化し直さず、外枠と変更対象の
        # 配列だけを複製する。追加する1件は下で通常どおり正規化する。
        loaded = _copy_speculum_for_write(as_dict(record.get("data")))
        current_hash_clean = clean_text(record.get("hash"))
        if kind in {"deadline", "deadlines"}:
            item = normalise_item("deadlines", {"title": parsed["title"], "due": parsed["date"], "priority": infer_priority(text, payload), "note": payload.get("note") or "", "createdAt": now, "updatedAt": now})
            loaded["deadlines"].append(item)
            saved = save_record("speculum", loaded, already_normalised=True, backup_policy="auto")
            return {"ok": True, "kind": "deadline", "item": item, "hash": saved["hash"], "updatedAt": saved.get("updatedAt"), "merged": bool(base_hash_supplied and base_hash_clean != current_hash_clean)}
        if kind in {"jimu", "office"}:
            item = normalise_item("jimu", {"name": parsed["title"], "due": parsed["date"], "priority": infer_priority(text, payload), "note": payload.get("note") or "", "createdAt": now, "updatedAt": now})
            loaded["jimu"].append(item)
            saved = save_record("speculum", loaded, already_normalised=True, backup_policy="auto")
            return {"ok": True, "kind": "jimu", "item": item, "hash": saved["hash"], "updatedAt": saved.get("updatedAt"), "merged": bool(base_hash_supplied and base_hash_clean != current_hash_clean)}
        event_time = clean_time(payload.get("time")) or parsed["time"]
        event_minutes = parse_duration_minutes(text, payload)
        calendar_kind = clean_text(payload.get("calendarKind") or ("happening" if kind in {"happening", "diary"} else "schedule"))
        item = normalise_item("events", {"title": parsed["title"], "date": parsed["date"], "time": event_time, "endTime": clean_time(payload.get("endTime")) or add_minutes_to_time(event_time, event_minutes), "durationMinutes": event_minutes, "place": payload.get("place") or "", "calendarKind": calendar_kind, "note": payload.get("note") or "", "createdAt": now, "updatedAt": now})
        loaded["events"].append(item)
        saved = save_record("speculum", loaded, already_normalised=True, backup_policy="auto")
        return {"ok": True, "kind": item.get("calendarKind") or "event", "item": item, "hash": saved["hash"], "updatedAt": saved.get("updatedAt"), "merged": bool(base_hash_supplied and base_hash_clean != current_hash_clean)}

def _continuum_kind(kind: str, *, cycle: bool = False) -> str:
    k = clean_text(kind)
    if cycle or k in {"cycle", "cycles", "cycleTasks", "周期作業"}:
        return "cycleTasks"
    return "tasks"


def save_continuum_item(kind: str, item_data: dict[str, Any], base_hash: str | None = None, base_item_updated_at: str | None = None) -> dict[str, Any]:
    """作業管理の1件だけを現在DBへマージして保存する。

    画面全体を送らず、現在保存済みのデータへ1件だけ差し替えるため、
    別画面の追加分を丸ごと上書きしない。
    """
    collection = _continuum_kind(kind)
    prefix = "cy" if collection == "cycleTasks" else "wk"
    raw = dict(as_dict(item_data))
    restore_token = clean_text(raw.pop("_restoreToken", ""))
    with SAVE_RECORD_LOCK:
        record = load_record("continuum", clone=False)
        cont = _copy_continuum_for_write(as_dict(record.get("data")))
        spec = as_dict(load_record("speculum", clone=False).get("data"))
        items = as_list(cont.get(collection))
        cont[collection] = items
        item_id = clean_text(raw.get("id")) or new_id(prefix)
        idx = next((i for i, x in enumerate(items) if isinstance(x, dict) and clean_text(x.get("id")) == item_id), -1)
        existing = dict(items[idx]) if idx >= 0 and isinstance(items[idx], dict) else {}
        base_hash_supplied = base_hash is not None
        base_hash_clean = clean_text(base_hash) if base_hash_supplied else ""
        current_hash_clean = clean_text(record.get("hash"))
        base_item_updated_clean = clean_text(base_item_updated_at)
        stale = bool(base_hash_supplied and base_hash_clean != current_hash_clean)
        restore_snapshot = _delete_restore_item(restore_token, "continuum", collection, item_id) if idx < 0 else None
        if restore_token and (idx >= 0 or restore_snapshot is None):
            raise SaveConflictError("continuum", "main", base_hash_clean, current_hash_clean, clean_text(record.get("updatedAt")))
        if restore_snapshot is not None:
            raw = restore_snapshot
        elif idx < 0 and clean_text(raw.get("id")) and base_item_updated_clean:
            # 別画面の削除や控えの復元後に、開きっぱなしだった編集画面を
            # 「同じIDの新規作成」として復活させない。
            raise SaveConflictError("continuum", "main", base_hash_clean, current_hash_clean, clean_text(record.get("updatedAt")))
        if idx < 0 and not clean_text(raw.get("title")):
            raise ValueError("作業名を入力してください。")
        if idx >= 0 and not base_hash_supplied and not base_item_updated_clean:
            raise ValueError("保存前の作業情報がありません。画面を読み込み直してください。")
        if idx >= 0 and _item_revision_conflicts(existing, base_item_updated_clean, base_required=stale):
            raise SaveConflictError("continuum", "main", base_hash_clean, current_hash_clean, clean_text(record.get("updatedAt")))
        merged = {**existing, **raw, "id": item_id}
        merged["createdAt"] = clean_text(merged.get("createdAt")) or clean_text(existing.get("createdAt")) or iso_now()
        merged["updatedAt"] = iso_now()
        item = normalise_item(collection, merged)
        _assert_added_references_exist(collection, existing, item, spec)
        if collection == "tasks" and normalize_work_status(item.get("status")) != "done":
            item.pop("completedAt", None)
        if idx >= 0:
            items[idx] = item
            mode = "updated"
        else:
            items.append(item)
            mode = "created"
        saved = save_record("continuum", cont, already_normalised=True, backup_policy="auto")
        if restore_snapshot is not None:
            _consume_delete_restore_token(restore_token)
        merged_from_newer = bool(base_hash_supplied and base_hash_clean != current_hash_clean)
        return {"ok": True, "kind": "cycle" if collection == "cycleTasks" else "task", "mode": mode, "item": item, "hash": saved["hash"], "updatedAt": saved.get("updatedAt"), "merged": merged_from_newer}


def delete_continuum_items(kind: str, ids: list[Any], base_hash: str | None = None, base_items: list[Any] | None = None) -> dict[str, Any]:
    collection = _continuum_kind(kind)
    remove = {clean_text(x) for x in as_list(ids) if clean_text(x)}
    if not remove:
        raise ValueError("削除対象の作業が見つかりません。")
    with SAVE_RECORD_LOCK:
        record = load_record("continuum", clone=False)
        cont = _copy_continuum_for_write(as_dict(record.get("data")))
        items = as_list(cont.get(collection))
        base_hash_supplied = base_hash is not None
        base_hash_clean = clean_text(base_hash) if base_hash_supplied else ""
        current_hash_clean = clean_text(record.get("hash"))
        stale = bool(base_hash_supplied and base_hash_clean != current_hash_clean)
        base_updated = {clean_text(x.get("id")): clean_text(x.get("updatedAt")) for x in as_list(base_items) if isinstance(x, dict) and clean_text(x.get("id"))}
        current_ids = {clean_text(x.get("id")) for x in items if isinstance(x, dict) and clean_text(x.get("id"))}
        if any(item_id not in current_ids and base_updated.get(item_id) for item_id in remove):
            raise SaveConflictError("continuum", "main", base_hash_clean, current_hash_clean, clean_text(record.get("updatedAt")))
        for x in items:
            if not isinstance(x, dict):
                continue
            xid = clean_text(x.get("id"))
            if xid in remove and not base_hash_supplied and not base_updated.get(xid):
                raise ValueError("削除前の作業情報がありません。画面を読み込み直してください。")
            if xid in remove and _item_revision_conflicts(x, base_updated.get(xid), base_required=stale):
                raise SaveConflictError("continuum", "main", base_hash_clean, current_hash_clean, clean_text(record.get("updatedAt")))
        kept = [x for x in items if not (isinstance(x, dict) and clean_text(x.get("id")) in remove)]
        changed = len(kept) != len(items)
        removed_items = [x for x in items if isinstance(x, dict) and clean_text(x.get("id")) in remove]
        cont[collection] = kept
        if changed:
            saved = save_record("continuum", cont, already_normalised=True, backup_policy="auto")
            h = saved["hash"]; updated = saved.get("updatedAt")
            restore_tokens = _issue_delete_restore_tokens("continuum", collection, removed_items)
        else:
            h = clean_text(record.get("hash")); updated = clean_text(record.get("updatedAt")); restore_tokens = {}
        merged_from_newer = bool(base_hash_supplied and base_hash_clean != current_hash_clean)
        single_token = next(iter(restore_tokens.values()), "") if len(restore_tokens) == 1 else ""
        return {"ok": True, "changed": changed, "ids": sorted(remove), "hash": h, "updatedAt": updated, "merged": merged_from_newer, "restoreTokens": restore_tokens, "restoreToken": single_token}




def save_continuum_items(kind: str, items_data: list[Any], base_hash: str | None = None, base_items: list[Any] | None = None) -> dict[str, Any]:
    """作業管理の複数件を、最新DBへまとめて安全合流する。"""
    collection = _continuum_kind(kind)
    prefix = "cy" if collection == "cycleTasks" else "wk"
    incoming = [dict(x) for x in as_list(items_data) if isinstance(x, dict)]
    if not incoming:
        raise ValueError("保存対象の作業がありません。")
    with SAVE_RECORD_LOCK:
        record = load_record("continuum", clone=False)
        cont = _copy_continuum_for_write(as_dict(record.get("data")))
        spec = as_dict(load_record("speculum", clone=False).get("data"))
        items = as_list(cont.get(collection))
        cont[collection] = items
        by_id = {clean_text(x.get("id")): i for i, x in enumerate(items) if isinstance(x, dict) and clean_text(x.get("id"))}
        base_hash_supplied = base_hash is not None
        base_hash_clean = clean_text(base_hash) if base_hash_supplied else ""
        current_hash_clean = clean_text(record.get("hash"))
        base_updated = {clean_text(x.get("id")): clean_text(x.get("updatedAt")) for x in as_list(base_items) if isinstance(x, dict) and clean_text(x.get("id"))}
        stale = bool(base_hash_supplied and base_hash_clean != current_hash_clean)
        restore_tokens: dict[str, str] = {}
        for raw in incoming:
            restore_token = clean_text(raw.pop("_restoreToken", ""))
            item_id = clean_text(raw.get("id"))
            idx = by_id.get(item_id, -1) if item_id else -1
            base_u = base_updated.get(item_id) or clean_text(raw.get("_baseUpdatedAt"))
            restore_snapshot = _delete_restore_item(restore_token, "continuum", collection, item_id) if idx < 0 else None
            if restore_token and (idx >= 0 or restore_snapshot is None):
                raise SaveConflictError("continuum", "main", base_hash_clean, current_hash_clean, clean_text(record.get("updatedAt")))
            if restore_snapshot is not None:
                raw.clear(); raw.update(restore_snapshot)
                restore_tokens[item_id] = restore_token
            elif idx < 0 and item_id and base_u:
                raise SaveConflictError("continuum", "main", base_hash_clean, current_hash_clean, clean_text(record.get("updatedAt")))
            if idx < 0 and not clean_text(raw.get("title")):
                raise ValueError("作業名を入力してください。")
            if idx >= 0:
                if not base_hash_supplied and not base_u:
                    raise ValueError("保存前の作業情報がありません。画面を読み込み直してください。")
                if _item_revision_conflicts(items[idx], base_u, base_required=stale):
                    raise SaveConflictError("continuum", "main", base_hash_clean, current_hash_clean, clean_text(record.get("updatedAt")))
        saved_items: list[dict[str, Any]] = []
        for raw in incoming:
            item_id = clean_text(raw.get("id")) or new_id(prefix)
            idx = by_id.get(item_id, -1)
            existing = dict(items[idx]) if idx >= 0 and isinstance(items[idx], dict) else {}
            merged = {**existing, **raw, "id": item_id}
            merged.pop("_baseUpdatedAt", None)
            merged["createdAt"] = clean_text(merged.get("createdAt")) or clean_text(existing.get("createdAt")) or iso_now()
            merged["updatedAt"] = iso_now()
            item = normalise_item(collection, merged)
            _assert_added_references_exist(collection, existing, item, spec)
            if collection == "tasks" and normalize_work_status(item.get("status")) != "done":
                item.pop("completedAt", None)
            if idx >= 0:
                items[idx] = item
            else:
                by_id[item_id] = len(items)
                items.append(item)
            saved_items.append(item)
        saved = save_record("continuum", cont, already_normalised=True, backup_policy="auto")
        for restore_token in restore_tokens.values():
            _consume_delete_restore_token(restore_token)
        return {"ok": True, "kind": "cycle" if collection == "cycleTasks" else "task", "items": saved_items, "hash": saved["hash"], "updatedAt": saved.get("updatedAt"), "merged": bool(base_hash_supplied and base_hash_clean != current_hash_clean)}


def save_speculum_item(kind: str, item_data: dict[str, Any], base_hash: str | None = None, base_item_updated_at: str | None = None) -> dict[str, Any]:
    saved = save_speculum_items(kind, [item_data], base_hash, [{"id": as_dict(item_data).get("id"), "updatedAt": base_item_updated_at or as_dict(item_data).get("_baseUpdatedAt")}])
    item = saved["items"][0]
    return {"ok": True, "kind": _speculum_collection(kind), "mode": saved.get("modes", ["updated"])[0], "item": item, "hash": saved["hash"], "updatedAt": saved.get("updatedAt"), "merged": bool(saved.get("merged"))}


def _work_reference_source(item: Any) -> str:
    row = as_dict(item)
    source_info = as_dict(row.get("sourceInfo"))
    return clean_text(row.get("source") or source_info.get("ref") or source_info.get("legacy"))


def _all_work_reference_items(continuum: dict[str, Any]) -> list[dict[str, Any]]:
    return [
        row
        for collection in ("tasks", "cycleTasks")
        for row in as_list(continuum.get(collection))
        if isinstance(row, dict)
    ]


def _item_person_reference_ids(item: Any) -> set[str]:
    return {clean_text(value) for value in as_list(as_dict(item).get("personIds")) if clean_text(value)}


def _speculum_ids(speculum: dict[str, Any], collection: str) -> set[str]:
    return {
        clean_text(row.get("id"))
        for row in as_list(speculum.get(collection))
        if isinstance(row, dict) and clean_text(row.get("id"))
    }


def _speculum_source_exists(source: str, speculum: dict[str, Any]) -> bool:
    parts = clean_text(source).split(":")
    if len(parts) < 3 or parts[0] != "speculum":
        return True  # 外部・旧形式の出所は、この検査では削除済みと断定しない。
    source_type, source_id = parts[1], parts[2]
    if source_type in {"events", "deadlines", "jimu", "cases"}:
        return source_id in _speculum_ids(speculum, source_type)
    if source_type != "case-target":
        return True
    case = next(
        (row for row in as_list(speculum.get("cases")) if isinstance(row, dict) and clean_text(row.get("id")) == source_id),
        None,
    )
    if not case:
        return False
    target_id = clean_text(parts[3] if len(parts) > 3 else "")
    # 対象者未登録の事案から作業を作る際の、事案全体を示す予約値。
    if target_id == "case":
        return True
    return any(
        isinstance(target, dict) and clean_text(target.get("id")) == target_id
        for target in as_list(case.get("targetPersons") or case.get("targets"))
    )


def _assert_added_references_exist(
    collection: str,
    existing: dict[str, Any],
    updated: dict[str, Any],
    speculum: dict[str, Any],
) -> None:
    """古いフォームから今回追加された参照だけを、最新台帳へ照合する。

    旧データに元から残る孤立IDは、無関係な項目を編集できるよう同じ値のままなら
    許容する。新規項目、または今回追加・変更された人物・事案・連携元だけを拒否する。
    """
    before_people = _item_person_reference_ids(existing)
    after_people = _item_person_reference_ids(updated)
    added_people = after_people - before_people
    missing_people = added_people - _speculum_ids(speculum, "people")
    if missing_people:
        raise ValueError("選択した人物は削除済みです。画面を読み込み直して、関係者を選び直してください。")

    before_case = clean_text(existing.get("caseId"))
    after_case = clean_text(updated.get("caseId"))
    if after_case and after_case != before_case and after_case not in _speculum_ids(speculum, "cases"):
        raise ValueError("選択した事案は削除済みです。画面を読み込み直して、事案を選び直してください。")

    if collection not in {"tasks", "cycleTasks"}:
        return
    before_source = _work_reference_source(existing)
    after_source = _work_reference_source(updated)
    if after_source and after_source != before_source and not _speculum_source_exists(after_source, speculum):
        raise ValueError("連携元の台帳項目は削除済みです。画面を読み込み直して、もう一度操作してください。")


def _reference_summary(rows: list[tuple[str, int]]) -> str:
    return "、".join(f"{label}{count}件" for label, count in rows if count > 0)


def _assert_speculum_deletion_is_unreferenced(
    collection: str,
    remove: set[str],
    speculum: dict[str, Any],
    continuum: dict[str, Any],
) -> None:
    """古い画面からの削除でも、最新保存済みデータの参照を壊さない。

    画面側の事前確認だけでは、別画面が参照を追加した直後の競合を防げない。
    speculum と continuum の両方を SAVE_RECORD_LOCK 内で読み、削除直前に再確認する。
    """
    work_items = _all_work_reference_items(continuum)
    if collection == "people":
        for person_id in remove:
            has_person = lambda row: person_id in {clean_text(value) for value in as_list(as_dict(row).get("personIds")) if clean_text(value)}
            rows = [
                ("予定・出来事", sum(1 for row in as_list(speculum.get("events")) if has_person(row))),
                ("期限", sum(1 for row in as_list(speculum.get("deadlines")) if has_person(row))),
                ("事務", sum(1 for row in as_list(speculum.get("jimu")) if has_person(row))),
                ("事案", sum(1 for row in as_list(speculum.get("cases")) if has_person(row))),
                ("経歴", sum(1 for row in as_list(speculum.get("career")) if has_person(row))),
                ("作業", sum(1 for row in work_items if has_person(row))),
            ]
            if any(count for _, count in rows):
                raise ValueError(
                    f"この人物は{_reference_summary(rows)}で使われているため削除できません。"
                    "先に各項目の関係者から外すか、退職日を登録してください。"
                )
        return

    if collection == "cases":
        for case_id in remove:
            def work_uses_case(row: Any) -> bool:
                item = as_dict(row)
                source = _work_reference_source(item)
                return (
                    clean_text(item.get("caseId")) == case_id
                    or source == f"speculum:cases:{case_id}"
                    or source.startswith(f"speculum:case-target:{case_id}:")
                )

            rows = [
                ("予定・出来事", sum(1 for row in as_list(speculum.get("events")) if clean_text(as_dict(row).get("caseId")) == case_id)),
                ("期限", sum(1 for row in as_list(speculum.get("deadlines")) if clean_text(as_dict(row).get("caseId")) == case_id)),
                ("事務", sum(1 for row in as_list(speculum.get("jimu")) if clean_text(as_dict(row).get("caseId")) == case_id)),
                ("作業", sum(1 for row in work_items if work_uses_case(row))),
            ]
            if any(count for _, count in rows):
                raise ValueError(
                    f"この事案は{_reference_summary(rows)}で使われているため削除できません。"
                    "削除する場合は、先に各項目から事案の紐付けを外してください。"
                    "記録を残す場合は、進行状態を「完了」にして保管できます。"
                )
        return

    if collection in {"events", "deadlines", "jimu"}:
        label = {"events": "予定・出来事", "deadlines": "期限", "jimu": "事務"}[collection]
        for item_id in remove:
            source = f"speculum:{collection}:{item_id}"
            count = sum(1 for row in work_items if _work_reference_source(row) == source)
            if count:
                raise ValueError(
                    f"この{label}は作業{count}件と連携しているため削除できません。"
                    "先に作業管理で台帳との連携を解除するか、連携中の作業を削除してください。"
                )


def _assert_case_targets_are_unreferenced(
    existing: dict[str, Any],
    updated: dict[str, Any],
    continuum: dict[str, Any],
) -> None:
    """事案編集で対象者が消える場合も、連携中の作業を孤立させない。"""
    case_id = clean_text(existing.get("id") or updated.get("id"))
    if not case_id:
        return
    before_ids = {
        clean_text(row.get("id"))
        for row in as_list(existing.get("targetPersons") or existing.get("targets"))
        if isinstance(row, dict) and clean_text(row.get("id"))
    }
    after_ids = {
        clean_text(row.get("id"))
        for row in as_list(updated.get("targetPersons") or updated.get("targets"))
        if isinstance(row, dict) and clean_text(row.get("id"))
    }
    removed_ids = before_ids - after_ids
    if not removed_ids:
        return
    work_items = _all_work_reference_items(continuum)
    for target_id in removed_ids:
        source = f"speculum:case-target:{case_id}:{target_id}"
        count = sum(1 for row in work_items if _work_reference_source(row) == source)
        if count:
            raise ValueError(
                f"この対象者カードは作業{count}件と連携しているため削除できません。"
                "先に作業管理で台帳との連携を解除するか、連携中の作業を削除してください。"
            )


def _assert_full_save_base_is_current(app: str, record: dict[str, Any], base_hash: str | None) -> str:
    base = clean_text(base_hash)
    current = clean_text(record.get("hash"))
    if base_hash is None:
        raise ValueError("保存前の読込情報がありません。画面を読み込み直してください。")
    if base != current:
        raise SaveConflictError(app, "main", base, current, clean_text(record.get("updatedAt")))
    return current


def _assert_speculum_document_reference_integrity(
    current: dict[str, Any],
    incoming: dict[str, Any],
    continuum: dict[str, Any],
) -> None:
    """台帳全体の差替えで、保存後に残る双方向の参照を検査する。"""
    for collection in ("events", "deadlines", "jimu", "cases", "people", "career"):
        current_by_id = {
            clean_text(item.get("id")): item
            for item in as_list(current.get(collection))
            if isinstance(item, dict) and clean_text(item.get("id"))
        }
        incoming_by_id = {
            clean_text(item.get("id")): item
            for item in as_list(incoming.get(collection))
            if isinstance(item, dict) and clean_text(item.get("id"))
        }
        removed = set(current_by_id) - set(incoming_by_id)
        if removed:
            # 同じ全体保存で関係者・事案の紐付けも外した場合は許容し、
            # 保存後にも残る参照と作業管理側の参照だけを拒否する。
            _assert_speculum_deletion_is_unreferenced(collection, removed, incoming, continuum)
        for item_id, item in incoming_by_id.items():
            existing = as_dict(current_by_id.get(item_id))
            _assert_added_references_exist(collection, existing, item, incoming)
            if collection == "cases" and existing:
                _assert_case_targets_are_unreferenced(existing, item, continuum)


def _assert_continuum_document_reference_integrity(
    current: dict[str, Any],
    incoming: dict[str, Any],
    speculum: dict[str, Any],
) -> None:
    """作業管理全体の差替えで、削除済み台帳への参照追加を検査する。"""
    for collection in ("tasks", "cycleTasks"):
        current_by_id = {
            clean_text(item.get("id")): item
            for item in as_list(current.get(collection))
            if isinstance(item, dict) and clean_text(item.get("id"))
        }
        for item in as_list(incoming.get(collection)):
            if not isinstance(item, dict):
                continue
            _assert_added_references_exist(
                collection,
                as_dict(current_by_id.get(clean_text(item.get("id")))),
                item,
                speculum,
            )


def save_speculum_document(data: dict[str, Any], base_hash: str | None) -> dict[str, Any]:
    """HTTP全体保存にも、部分保存と同じ双方向の参照整合性を適用する。"""
    with SAVE_RECORD_LOCK:
        record = load_record("speculum", clone=False)
        current_hash = _assert_full_save_base_is_current("speculum", record, base_hash)
        current = as_dict(record.get("data"))
        continuum = as_dict(load_record("continuum", clone=False).get("data"))
        incoming = normalise_speculum(data)
        _assert_speculum_document_reference_integrity(current, incoming, continuum)

        return save_record(
            "speculum",
            incoming,
            base_hash=current_hash,
            force=False,
            already_normalised=True,
        )


def save_continuum_document(data: dict[str, Any], base_hash: str | None) -> dict[str, Any]:
    """作業管理のHTTP全体保存からも、削除済み台帳への参照追加を防ぐ。"""
    with SAVE_RECORD_LOCK:
        record = load_record("continuum", clone=False)
        current_hash = _assert_full_save_base_is_current("continuum", record, base_hash)
        current = as_dict(record.get("data"))
        speculum = as_dict(load_record("speculum", clone=False).get("data"))
        incoming = normalise_continuum(data)
        _assert_continuum_document_reference_integrity(current, incoming, speculum)
        return save_record(
            "continuum",
            incoming,
            base_hash=current_hash,
            force=False,
            already_normalised=True,
        )


def save_speculum_items(kind: str, items_data: list[Any], base_hash: str | None = None, base_items: list[Any] | None = None) -> dict[str, Any]:
    """今日・日付確認・台帳の複数件を、最新DBへ安全合流する。"""
    collection = _speculum_collection(kind)
    prefix = {"events": "ev", "deadlines": "dl", "jimu": "jm", "cases": "ca", "people": "pe", "career": "cr"}.get(collection, "it")
    incoming = [dict(x) for x in as_list(items_data) if isinstance(x, dict)]
    if not incoming:
        raise ValueError("保存対象がありません。")
    with SAVE_RECORD_LOCK:
        record = load_record("speculum", clone=False)
        spec = _copy_speculum_for_write(as_dict(record.get("data")))
        continuum = as_dict(load_record("continuum", clone=False).get("data")) if collection == "cases" else {}
        items = as_list(spec.get(collection))
        spec[collection] = items
        by_id = {clean_text(x.get("id")): i for i, x in enumerate(items) if isinstance(x, dict) and clean_text(x.get("id"))}
        base_hash_supplied = base_hash is not None
        base_hash_clean = clean_text(base_hash) if base_hash_supplied else ""
        current_hash_clean = clean_text(record.get("hash"))
        base_updated = {clean_text(x.get("id")): clean_text(x.get("updatedAt")) for x in as_list(base_items) if isinstance(x, dict) and clean_text(x.get("id"))}
        stale = bool(base_hash_supplied and base_hash_clean != current_hash_clean)
        restore_tokens: dict[str, str] = {}
        for raw in incoming:
            restore_token = clean_text(raw.pop("_restoreToken", ""))
            item_id = clean_text(raw.get("id"))
            idx = by_id.get(item_id, -1) if item_id else -1
            base_u = base_updated.get(item_id) or clean_text(raw.get("_baseUpdatedAt"))
            restore_snapshot = _delete_restore_item(restore_token, "speculum", collection, item_id) if idx < 0 else None
            if restore_token and (idx >= 0 or restore_snapshot is None):
                raise SaveConflictError("speculum", "main", base_hash_clean, current_hash_clean, clean_text(record.get("updatedAt")))
            if restore_snapshot is not None:
                raw.clear(); raw.update(restore_snapshot)
                restore_tokens[item_id] = restore_token
            elif idx < 0 and item_id and base_u:
                raise SaveConflictError("speculum", "main", base_hash_clean, current_hash_clean, clean_text(record.get("updatedAt")))
            if idx < 0:
                title_fields = ("fiscalYear", "title") if collection == "career" else (("name", "title") if collection in {"jimu", "people"} else ("title", "name"))
                if not any(clean_text(raw.get(field)) for field in title_fields):
                    raise ValueError("登録する名称を入力してください。")
            if idx >= 0:
                if not base_hash_supplied and not base_u:
                    raise ValueError("保存前の登録情報がありません。画面を読み込み直してください。")
                if _item_revision_conflicts(items[idx], base_u, base_required=stale):
                    raise SaveConflictError("speculum", "main", base_hash_clean, current_hash_clean, clean_text(record.get("updatedAt")))
        saved_items: list[dict[str, Any]] = []
        modes: list[str] = []
        for raw in incoming:
            item_id = clean_text(raw.get("id")) or new_id(prefix)
            idx = by_id.get(item_id, -1)
            existing = dict(items[idx]) if idx >= 0 and isinstance(items[idx], dict) else {}
            merged = {**existing, **raw, "id": item_id}
            merged.pop("_baseUpdatedAt", None)
            merged["createdAt"] = clean_text(merged.get("createdAt")) or clean_text(existing.get("createdAt")) or iso_now()
            merged["updatedAt"] = iso_now()
            item = normalise_item(collection, merged)
            _assert_added_references_exist(collection, existing, item, spec)
            if collection == "cases" and existing:
                _assert_case_targets_are_unreferenced(existing, item, continuum)
            if idx >= 0:
                items[idx] = item; modes.append("updated")
            else:
                by_id[item_id] = len(items); items.append(item); modes.append("created")
            saved_items.append(item)
        saved = save_record("speculum", spec, already_normalised=True, backup_policy="auto")
        for restore_token in restore_tokens.values():
            _consume_delete_restore_token(restore_token)
        return {"ok": True, "kind": collection, "modes": modes, "items": saved_items, "hash": saved["hash"], "updatedAt": saved.get("updatedAt"), "merged": bool(base_hash_supplied and base_hash_clean != current_hash_clean)}


def delete_speculum_items(kind: str, ids: list[Any], base_hash: str | None = None, base_items: list[Any] | None = None) -> dict[str, Any]:
    collection = _speculum_collection(kind)
    remove = {clean_text(x) for x in as_list(ids) if clean_text(x)}
    if not remove:
        raise ValueError("削除対象が見つかりません。")
    with SAVE_RECORD_LOCK:
        record = load_record("speculum", clone=False)
        spec = _copy_speculum_for_write(as_dict(record.get("data")))
        continuum = as_dict(load_record("continuum", clone=False).get("data"))
        items = as_list(spec.get(collection))
        base_hash_supplied = base_hash is not None
        base_hash_clean = clean_text(base_hash) if base_hash_supplied else ""
        current_hash_clean = clean_text(record.get("hash"))
        stale = bool(base_hash_supplied and base_hash_clean != current_hash_clean)
        base_updated = {clean_text(x.get("id")): clean_text(x.get("updatedAt")) for x in as_list(base_items) if isinstance(x, dict) and clean_text(x.get("id"))}
        current_ids = {clean_text(x.get("id")) for x in items if isinstance(x, dict) and clean_text(x.get("id"))}
        if any(item_id not in current_ids and base_updated.get(item_id) for item_id in remove):
            raise SaveConflictError("speculum", "main", base_hash_clean, current_hash_clean, clean_text(record.get("updatedAt")))
        for x in items:
            if not isinstance(x, dict):
                continue
            xid = clean_text(x.get("id"))
            if xid in remove and not base_hash_supplied and not base_updated.get(xid):
                raise ValueError("削除前の登録情報がありません。画面を読み込み直してください。")
            if xid in remove and _item_revision_conflicts(x, base_updated.get(xid), base_required=stale):
                raise SaveConflictError("speculum", "main", base_hash_clean, current_hash_clean, clean_text(record.get("updatedAt")))
        _assert_speculum_deletion_is_unreferenced(collection, remove, spec, continuum)
        kept = [x for x in items if not (isinstance(x, dict) and clean_text(x.get("id")) in remove)]
        changed = len(kept) != len(items)
        removed_items = [x for x in items if isinstance(x, dict) and clean_text(x.get("id")) in remove]
        spec[collection] = kept
        if changed:
            saved = save_record("speculum", spec, already_normalised=True, backup_policy="auto")
            h = saved["hash"]; updated = saved.get("updatedAt")
            restore_tokens = _issue_delete_restore_tokens("speculum", collection, removed_items)
        else:
            h = clean_text(record.get("hash")); updated = clean_text(record.get("updatedAt")); restore_tokens = {}
        single_token = next(iter(restore_tokens.values()), "") if len(restore_tokens) == 1 else ""
        return {"ok": True, "changed": changed, "ids": sorted(remove), "hash": h, "updatedAt": updated, "merged": bool(base_hash_supplied and base_hash_clean != current_hash_clean), "restoreTokens": restore_tokens, "restoreToken": single_token}


def patch_speculum(payload: dict[str, Any]) -> dict[str, Any]:
    """メモ・表示設定・祝日などの軽い外枠を最新DBへ合流する。"""
    base_hash_value = payload.get("baseHash") if "baseHash" in payload else payload.get("hash")
    base_hash_supplied = base_hash_value is not None
    base_hash_clean = clean_text(base_hash_value) if base_hash_supplied else ""
    touches_data = any(isinstance(payload.get(name), dict) for name in ("memo", "settings", "holidays"))
    if touches_data and not base_hash_supplied:
        raise ValueError("保存前の読込情報がありません。画面を読み込み直してください。")
    with SAVE_RECORD_LOCK:
        record = load_record("speculum", clone=False)
        current_hash_clean = clean_text(record.get("hash"))
        spec = _copy_speculum_for_write(as_dict(record.get("data")))
        stale = bool(base_hash_supplied and base_hash_clean != current_hash_clean)
        if stale:
            base = record_data_at_hash("speculum", base_hash_clean)
            conflict = base is None and touches_data
            if base is not None:
                conflict = (
                    (isinstance(payload.get("memo"), dict) and touched_mapping_changed(base.get("memo"), spec.get("memo"), payload.get("memo"), {"days"}))
                    or (isinstance(payload.get("settings"), dict) and touched_mapping_changed(base.get("settings"), spec.get("settings"), payload.get("settings")))
                    or (isinstance(payload.get("holidays"), dict) and touched_mapping_changed(base.get("holidays"), spec.get("holidays"), payload.get("holidays"), {"items"}))
                )
            if conflict:
                raise SaveConflictError("speculum", "main", base_hash_clean, current_hash_clean, clean_text(record.get("updatedAt")))
        if isinstance(payload.get("memo"), dict):
            incoming_memo = as_dict(payload.get("memo"))
            merged_memo = {**as_dict(spec.get("memo")), **incoming_memo}
            merged_memo["days"] = {**as_dict(as_dict(spec.get("memo")).get("days")), **as_dict(incoming_memo.get("days"))}
            spec["memo"] = merged_memo
        if isinstance(payload.get("settings"), dict):
            spec["settings"] = {**as_dict(spec.get("settings")), **as_dict(payload.get("settings"))}
        if isinstance(payload.get("holidays"), dict):
            incoming_holidays = as_dict(payload.get("holidays"))
            current_holidays = as_dict(spec.get("holidays"))
            spec["holidays"] = {**current_holidays, **incoming_holidays, "items": {**as_dict(current_holidays.get("items")), **as_dict(incoming_holidays.get("items"))}}
        saved = save_record("speculum", spec, base_hash=current_hash_clean, already_normalised=True, backup_policy="auto")
        return {"ok": True, "hash": saved["hash"], "updatedAt": saved.get("updatedAt"), "merged": stale, "data": saved.get("data")}


def patch_continuum(payload: dict[str, Any]) -> dict[str, Any]:
    """作業管理のメモ・表示設定だけを現在DBへ合流する。

    メモ入力や表示設定変更で全作業を丸ごと正規化し直すと、件数が多い環境で重くなる。
    現在保存済みの作業へ、指定された軽いフィールドだけを重ねる。
    """
    base_hash_value = payload.get("baseHash") if "baseHash" in payload else payload.get("hash")
    base_hash_supplied = base_hash_value is not None
    base_hash_clean = clean_text(base_hash_value) if base_hash_supplied else ""
    touches_data = "memo" in payload or isinstance(payload.get("settings"), dict)
    if touches_data and not base_hash_supplied:
        raise ValueError("保存前の読込情報がありません。画面を読み込み直してください。")
    with SAVE_RECORD_LOCK:
        record = load_record("continuum", clone=False)
        current_hash_clean = clean_text(record.get("hash"))
        cont = _copy_continuum_for_write(as_dict(record.get("data")))
        incoming_settings = _continuum_settings(payload.get("settings")) if isinstance(payload.get("settings"), dict) else None
        stale = bool(base_hash_supplied and base_hash_clean != current_hash_clean)
        if stale:
            base = record_data_at_hash("continuum", base_hash_clean)
            conflict = base is None and touches_data
            if base is not None:
                conflict = (
                    ("memo" in payload and clean_multiline_text(base.get("memo")) != clean_multiline_text(cont.get("memo")))
                    or (incoming_settings is not None and touched_mapping_changed(base.get("settings"), cont.get("settings"), incoming_settings))
                )
            if conflict:
                raise SaveConflictError("continuum", "main", base_hash_clean, current_hash_clean, clean_text(record.get("updatedAt")))
        if "memo" in payload:
            cont["memo"] = clean_multiline_text(payload.get("memo"))
        if incoming_settings is not None:
            cont["settings"] = {**as_dict(cont.get("settings")), **incoming_settings}
        saved = save_record("continuum", cont, base_hash=current_hash_clean, already_normalised=True, backup_policy="auto")
        return {"ok": True, "hash": saved["hash"], "updatedAt": saved.get("updatedAt"), "merged": stale, "data": saved.get("data")}


def quick_add_task(payload: dict[str, Any], cycle: bool = False) -> dict[str, Any]:
    text = clean_text(payload.get("text") or payload.get("title"))
    if not text:
        raise ValueError("登録する作業名を入力してください。")
    validate_natural_datetime(text)
    for field, label in (("due", "期限日"), ("nextRunDate", "次回日")):
        if field in payload:
            validate_explicit_date(payload.get(field), label)
    parsed = parse_natural(text, payload.get("due") or payload.get("nextRunDate"))
    now = iso_now()
    if cycle:
        cycle_title = clean_cycle_title(text, parsed["title"])
        next_run = infer_cycle_start(text, payload.get("nextRunDate") or payload.get("due"))
        item = normalise_item("cycleTasks", {"title": cycle_title, "status": payload.get("status") or "next", "nextRunDate": next_run, "rule": payload.get("rule") or infer_cycle_rule(text), "priority": infer_priority(text, payload), "createdAt": now, "updatedAt": now})
        base_hash_value = payload.get("baseHash") if "baseHash" in payload else payload.get("hash")
        saved = save_continuum_item("cycleTasks", item, base_hash_value)
        return {"ok": True, "kind": "cycle", "item": saved["item"], "hash": saved["hash"], "updatedAt": saved.get("updatedAt"), "merged": bool(saved.get("merged"))}
    estimate = parse_duration_minutes(text, payload)
    item = normalise_item("tasks", {"title": parsed["title"], "due": parsed["date"], "status": infer_task_status_from_text(text, payload), "priority": infer_priority(text, payload), "estimateMinutes": estimate, "nextAction": payload.get("nextAction") or "", "note": payload.get("note") or "", "createdAt": now, "updatedAt": now})
    base_hash_value = payload.get("baseHash") if "baseHash" in payload else payload.get("hash")
    saved = save_continuum_item("tasks", item, base_hash_value)
    return {"ok": True, "kind": "task", "item": saved["item"], "hash": saved["hash"], "updatedAt": saved.get("updatedAt"), "merged": bool(saved.get("merged"))}

def infer_cycle_rule(text: str) -> str:
    s = text or ""
    if "毎日" in s:
        return "毎日"
    m = re.search(r"毎週\s*([月火水木金土日])曜?(?:日)?", s)
    if m:
        return f"毎週{m.group(1)}曜"
    if "毎週" in s:
        return "毎週"
    m = re.search(r"毎年\s*(\d{1,2})月(\d{1,2})日", s)
    if m:
        return f"毎年{int(m.group(1))}月{int(m.group(2))}日"
    if "毎年" in s or "年次" in s:
        return "毎年"
    if "月初" in s or "月始" in s or "月始め" in s:
        return "毎月月初"
    if "月末" in s or "月終" in s:
        return "毎月月末"
    m = re.search(r"毎月\s*(\d{1,2})日", s)
    if m:
        return f"毎月{max(1, min(31, int(m.group(1))))}日"
    if "四半期" in s:
        return "3か月ごと"
    if "隔月" in s:
        return "2か月ごと"
    m = re.search(r"(\d+)\s*か?ヶ?月", s)
    if m:
        return f"{int(m.group(1))}か月ごと"
    return "毎月"


def _cycle_date_after_month_day(base: _dt.date, day: int) -> _dt.date:
    first = base.replace(day=1)
    while True:
        last = end_of_month(first).day
        cand = first.replace(day=min(max(1, day), last))
        if cand > base:
            return cand
        first = add_months(first, 1)


def _cycle_date_after_year_day(base: _dt.date, month: int, day: int) -> _dt.date:
    year = base.year
    while True:
        try:
            cand = _dt.date(year, month, day)
        except ValueError:
            cand = end_of_month(_dt.date(year, month, 1))
        if cand > base:
            return cand
        year += 1


def _cycle_weekday_after(base: _dt.date, weekday_char: str) -> _dt.date:
    target = WEEKDAYS.get(weekday_char, base.weekday())
    delta = (target - base.weekday()) % 7
    if delta == 0:
        delta = 7
    return base + _dt.timedelta(days=delta)


def advance_cycle(item: dict[str, Any], done_day: str | None = None) -> dict[str, Any]:
    done = _dt.date.fromisoformat(clean_date(done_day) or date_s())
    cur_s = clean_date(item.get("nextRunDate")) or done.isoformat()
    try:
        cur = _dt.date.fromisoformat(cur_s)
    except ValueError:
        cur = done
    base = max(cur, done)
    rule = clean_text(item.get("rule"))
    if "毎日" in rule:
        nxt = base + _dt.timedelta(days=1)
    else:
        weekly = re.search(r"毎週\s*([月火水木金土日])曜?", rule)
        yearly = re.search(r"毎年\s*(\d{1,2})月(\d{1,2})日", rule)
        monthly = re.search(r"毎月\s*(\d{1,2})日", rule)
        if weekly:
            nxt = _cycle_weekday_after(base, weekly.group(1))
        elif "毎週" in rule:
            nxt = base + _dt.timedelta(days=7)
        elif yearly:
            nxt = _cycle_date_after_year_day(base, max(1, min(12, int(yearly.group(1)))), max(1, min(31, int(yearly.group(2)))))
        elif "毎年" in rule:
            try:
                nxt = base.replace(year=base.year + 1)
            except ValueError:
                nxt = base.replace(year=base.year + 1, day=28)
        elif "月初" in rule or "月始" in rule:
            nxt = _cycle_date_after_month_day(base, 1)
        elif "月末" in rule or "月終" in rule:
            first = base.replace(day=1)
            while True:
                cand = end_of_month(first)
                if cand > base:
                    nxt = cand
                    break
                first = add_months(first, 1)
        elif monthly:
            nxt = _cycle_date_after_month_day(base, int(monthly.group(1)))
        else:
            m = re.search(r"(\d+)", rule)
            months = int(m.group(1)) if m else 1
            nxt = add_months(base, months)
    item = dict(item)
    item["lastDoneDate"] = done.isoformat()
    item["nextRunDate"] = nxt.isoformat()
    item["status"] = "next"
    item["state"] = "active"
    item["pausedAt"] = ""
    item["endedAt"] = ""
    item["completedAt"] = ""
    if "doneAt" in item:
        item["doneAt"] = ""
    item["updatedAt"] = iso_now()
    return item


def add_months(d: _dt.date, months: int) -> _dt.date:
    y = d.year + (d.month - 1 + months) // 12
    m = (d.month - 1 + months) % 12 + 1
    last = [31, 29 if (y % 4 == 0 and (y % 100 != 0 or y % 400 == 0)) else 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][m - 1]
    return _dt.date(y, m, min(d.day, last))


def import_speculum_actions() -> dict[str, Any]:
    with SAVE_RECORD_LOCK:
        spec = load_record("speculum", clone=False)["data"]
        cont = _copy_continuum_for_write(as_dict(load_record("continuum", clone=False).get("data")))
        existing = {clean_text(t.get("source")) for t in as_list(cont.get("tasks")) if isinstance(t, dict)}
        now = iso_now(); added = []
        for collection, label in (("deadlines", "期限"), ("jimu", "事務")):
            for item in as_list(spec.get(collection)):
                if record_is_done(item):
                    continue
                sid = f"speculum:{collection}:{item.get('id')}"
                if sid in existing:
                    continue
                title = clean_text(item.get("title") or item.get("name"))
                task = normalise_item("tasks", {"title": f"{label}: {title}", "due": item.get("due"), "status": "next", "priority": item.get("priority") or "normal", "source": sid, "nextAction": item.get("nextAction") or "", "caseId": item.get("caseId") or "", "personIds": item.get("personIds") or [], "createdAt": now, "updatedAt": now})
                cont["tasks"].append(task); existing.add(sid); added.append(task)
        for case in as_list(spec.get("cases")):
            targets = parse_case_targets(case.get("targetPersons"), "", case) or [None]
            for target in targets:
                status = normalize_case_status((target or {}).get("status") or case.get("status"))
                if status == "完了":
                    continue
                target_hits = case_target_alerts({**case, "targetPersons": [target]}) if target else []
                # 対象者カードがある場合は、その対象者の状態・着手日だけを見る。
                # まだ着手していない対象者へ事案本体の3か月超過アラートを誤って継承しない。
                hit = target_hits[0] if target_hits else (None if target else case_elapsed_alert(case))
                due = clean_date((hit or {}).get("alertDate")) or clean_date((target or {}).get("nextDate")) or clean_date(case.get("nextDate"))
                if not due:
                    continue
                tid = clean_text((target or {}).get("id"))
                sid = f"speculum:case-target:{case.get('id')}:{tid or 'case'}"
                if sid in existing:
                    continue
                target_name = clean_text((target or {}).get("name"))
                case_title = clean_text(case.get('title') or case.get('name'))
                title = f"事案確認: {target_name} / {case_title}" if target_name else f"事案確認: {case_title}"
                task = normalise_item("tasks", {"title": title, "due": due, "status": "next", "priority": (target or {}).get("priority") or "high", "source": sid, "caseId": case.get("id"), "personIds": [], "nextAction": (target or {}).get("nextAction") or case.get("nextAction") or "次の一手を確認", "note": " / ".join([x for x in [target_name, case.get("note") or ""] if x]), "createdAt": now, "updatedAt": now})
                cont["tasks"].append(task); existing.add(sid); added.append(task)
        saved = save_record("continuum", cont, already_normalised=True, backup_policy="auto")
        return {"ok": True, "added": len(added), "items": added, "hash": saved["hash"], "updatedAt": saved.get("updatedAt")}


def date_diff(ds: str) -> int | None:
    ds = clean_date(ds)
    if not ds:
        return None
    try:
        return (_dt.date.fromisoformat(ds) - today_date()).days
    except ValueError:
        return None


def _holiday_items(spec: dict[str, Any]) -> dict[str, Any]:
    """正規化済みレコードの祝日辞書をそのまま参照する。

    load_record の時点で日付と名称は正規化済みなので、日付判定のたびに全祝日を
    辞書内包表記で作り直す必要はない。未正規化の値も参照時に名称だけ整える。
    """
    return as_dict(as_dict(spec.get("holidays")).get("items"))


def _holiday_name_from_items(items: dict[str, Any], ds: str) -> str:
    imported = clean_text(items.get(ds))
    mmdd = ds[5:]
    closed = mmdd >= "12-29" or mmdd <= "01-03"
    if imported and closed:
        return f"{imported}・閉庁日"
    return imported or ("閉庁日" if closed else "")


class _BusinessDateContext:
    """1回の集計範囲で祝日索引と営業日差を再利用する。"""

    def __init__(self, spec: dict[str, Any], base: _dt.date | None = None) -> None:
        self.items = _holiday_items(spec)
        self.base = base or today_date()
        self._diffs: dict[_dt.date, int] = {self.base: 0}
        self._business: dict[_dt.date, bool] = {}
        self._forward_date = self.base
        self._forward_count = 0
        self._backward_date = self.base
        self._backward_count = 0

    def is_business_day(self, day: _dt.date) -> bool:
        cached = self._business.get(day)
        if cached is not None:
            return cached
        result = day.weekday() < 5 and not _holiday_name_from_items(self.items, day.isoformat())
        self._business[day] = result
        return result

    def diff(self, value: Any) -> int | None:
        ds = clean_date(value)
        if not ds:
            return None
        try:
            target = _dt.date.fromisoformat(ds)
        except ValueError:
            return None
        cached = self._diffs.get(target)
        if cached is not None:
            return cached
        one_day = _dt.timedelta(days=1)
        if target > self.base:
            while self._forward_date < target:
                self._forward_date += one_day
                if self.is_business_day(self._forward_date):
                    self._forward_count += 1
                self._diffs[self._forward_date] = self._forward_count
        else:
            while self._backward_date > target:
                # 従来どおり「対象日の翌日から今日まで」を負数で数える。
                if self.is_business_day(self._backward_date):
                    self._backward_count += 1
                self._backward_date -= one_day
                self._diffs[self._backward_date] = -self._backward_count
        return self._diffs[target]


def business_date_diff(spec: dict[str, Any], ds: str, _context: _BusinessDateContext | None = None) -> int | None:
    return (_context or _BusinessDateContext(spec)).diff(ds)


def due_day_count_mode(*records: dict[str, Any]) -> str:
    for record in records:
        mode = clean_text(as_dict(record.get("settings")).get("dueDayCountMode")).lower()
        if mode in {"business", "calendar"}:
            return mode
    return "business"


def due_date_diff(spec: dict[str, Any], ds: str, mode: str | None = None, _context: _BusinessDateContext | None = None) -> int | None:
    mode = (mode or due_day_count_mode(spec)).lower()
    return date_diff(ds) if mode == "calendar" else business_date_diff(spec, ds, _context)


def holiday_name(spec: dict[str, Any], ds: str) -> str:
    ds = clean_date(ds)
    if not ds:
        return ""
    return _holiday_name_from_items(_holiday_items(spec), ds)


def holiday_status(spec: dict[str, Any]) -> dict[str, Any]:
    items = _holiday_items(spec)
    years = sorted({int(k[:4]) for k in items if k[:4].isdigit()})
    if not years:
        return {"ok": True, "available": False, "message": "祝日データ未取得。土日祝日調整は土日のみで判定されています。", "count": 0}
    return {"ok": True, "available": True, "message": f"祝日データ: {years[0]}年〜{years[-1]}年取得済み", "count": len(items), "minYear": years[0], "maxYear": years[-1]}


def is_business_day(spec: dict[str, Any], d: _dt.date) -> bool:
    return d.weekday() < 5 and not _holiday_name_from_items(_holiday_items(spec), d.isoformat())


def shift_business_date(spec: dict[str, Any], ds: str, mode: str = "none", tie: str = "previous") -> str:
    ds = clean_date(ds)
    if not ds:
        return ""
    mode = clean_text(mode).lower() or "none"
    aliases = {"prev": "previous", "before": "previous", "前": "previous", "next": "next", "after": "next", "後": "next", "closest": "nearest", "近い": "nearest"}
    mode = aliases.get(mode, mode)
    try:
        start = _dt.date.fromisoformat(ds)
    except ValueError:
        return ds
    if mode == "none" or is_business_day(spec, start):
        return ds

    def find(direction: int) -> str:
        cur = start
        for _ in range(366):
            cur += _dt.timedelta(days=direction)
            if is_business_day(spec, cur):
                return cur.isoformat()
        return ds

    if mode == "previous":
        return find(-1)
    if mode == "next":
        return find(1)
    if mode == "nearest":
        tie = "next" if clean_text(tie).lower() in {"next", "after", "後", "後ろ"} else "previous"
        for dist in range(1, 367):
            prev = start - _dt.timedelta(days=dist)
            nxt = start + _dt.timedelta(days=dist)
            prev_ok = is_business_day(spec, prev)
            next_ok = is_business_day(spec, nxt)
            if prev_ok and next_ok:
                return nxt.isoformat() if tie == "next" else prev.isoformat()
            if prev_ok:
                return prev.isoformat()
            if next_ok:
                return nxt.isoformat()
    return ds


def _date_range(start: _dt.date, end: _dt.date):
    cur = start
    while cur <= end:
        yield cur
        cur += _dt.timedelta(days=1)


def _month_diff(a: _dt.date, b: _dt.date) -> int:
    return (b.year - a.year) * 12 + (b.month - a.month)


def _last_day(year: int, month: int) -> _dt.date:
    if month == 12:
        return _dt.date(year, 12, 31)
    return _dt.date(year, month + 1, 1) - _dt.timedelta(days=1)


def _js_weekday(d: _dt.date) -> int:
    return (d.weekday() + 1) % 7


def _nth_weekday(year: int, month: int, js_weekday: int, nth: str) -> _dt.date | None:
    last = _last_day(year, month)
    if nth == "last":
        d = last
        while _js_weekday(d) != js_weekday:
            d -= _dt.timedelta(days=1)
        return d
    try:
        n = max(1, min(5, int(float(nth or 1))))
    except Exception:
        n = 1
    d = _dt.date(year, month, 1)
    while _js_weekday(d) != js_weekday:
        d += _dt.timedelta(days=1)
    d += _dt.timedelta(days=(n - 1) * 7)
    return d if d.month == month else None


def _event_start(event: dict[str, Any]) -> _dt.date | None:
    try:
        return _dt.date.fromisoformat(clean_date(event.get("date")))
    except Exception:
        return None


def _monthly_candidate(spec: dict[str, Any], event: dict[str, Any], year: int, month: int) -> _dt.date | None:
    start = _event_start(event)
    if not start:
        return None
    mode = clean_text(event.get("repeatMonthlyMode") or "dayOfMonth")
    last = _last_day(year, month)
    if mode == "endOfMonth":
        return last
    if mode == "lastBusinessDay":
        return _dt.date.fromisoformat(shift_business_date(spec, last.isoformat(), "previous"))
    if mode == "nthWeekday":
        try:
            weekday = int(float(event.get("repeatWeekday", _js_weekday(start))))
        except Exception:
            weekday = _js_weekday(start)
        return _nth_weekday(year, month, weekday, clean_text(event.get("repeatNth") or "1"))
    try:
        day = int(float(event.get("repeatDayOfMonth") or start.day))
    except Exception:
        day = start.day
    if day <= last.day:
        return _dt.date(year, month, day)
    missing = clean_text(event.get("repeatMissingDatePolicy") or "skip")
    if missing == "lastDay":
        return last
    if missing == "previousBusiness":
        return _dt.date.fromisoformat(shift_business_date(spec, last.isoformat(), "previous"))
    if missing == "nextBusiness":
        nxt = last + _dt.timedelta(days=1)
        return _dt.date.fromisoformat(shift_business_date(spec, nxt.isoformat(), "next"))
    return None


def _base_occurrence_matches(spec: dict[str, Any], event: dict[str, Any], base: _dt.date) -> bool:
    start = _event_start(event)
    if not start or base < start:
        return False
    until_s = clean_date(event.get("repeatUntil"))
    if until_s and base > _dt.date.fromisoformat(until_s):
        return False
    rep = clean_text(event.get("repeat") or "none").lower() or "none"
    try:
        interval = max(1, int(float(event.get("repeatInterval") or 1)))
    except Exception:
        interval = 1
    if rep == "none":
        return base == start
    days = (base - start).days
    if rep == "daily":
        return days % interval == 0
    if rep == "weekly":
        return days >= 0 and days % (7 * interval) == 0
    if rep == "monthly":
        months = _month_diff(start, base)
        if months < 0 or months % interval != 0:
            return False
        return _monthly_candidate(spec, event, base.year, base.month) == base
    if rep == "yearly":
        yd = base.year - start.year
        if yd < 0 or yd % interval != 0:
            return False
        try:
            candidate = _dt.date(base.year, start.month, start.day)
        except ValueError:
            if clean_text(event.get("repeatMissingDatePolicy") or "skip") in {"lastDay", "previousBusiness"}:
                candidate = _dt.date(base.year, start.month, 28)
            else:
                return False
        return candidate == base
    return False


def _event_occurrence_info(spec: dict[str, Any], event: dict[str, Any], ds: str) -> dict[str, Any] | None:
    target_s = clean_date(ds)
    if not target_s:
        return None
    try:
        target = _dt.date.fromisoformat(target_s)
    except ValueError:
        return None
    exceptions = as_dict(event.get("exceptions") or event.get("repeatExceptions"))
    for base in _date_range(target - _dt.timedelta(days=45), target + _dt.timedelta(days=45)):
        if not _base_occurrence_matches(spec, event, base):
            continue
        base_s = base.isoformat()
        ex = as_dict(exceptions.get(base_s))
        if clean_text(ex.get("action")).lower() == "skip":
            continue
        effective = clean_date(ex.get("date")) or shift_business_date(spec, base_s, event.get("repeatBusinessDayShift"), event.get("repeatBusinessDayTie"))
        if effective != target_s:
            continue
        overrides = {k: v for k, v in ex.items() if k not in {"action", "date"} and v not in (None, "")}
        return {"baseDate": base_s, "shifted": base_s != target_s or bool(clean_date(ex.get("date"))), "overrides": overrides}
    return None


def calendar_occurrences(spec: dict[str, Any], start_s: str, end_s: str, mode: str = "both") -> list[dict[str, Any]]:
    start_s = clean_date(start_s) or date_s()
    end_s = clean_date(end_s) or start_s
    start = _dt.date.fromisoformat(start_s)
    end = _dt.date.fromisoformat(end_s)
    if end < start:
        start, end = end, start
    mode = clean_text(mode) or "both"
    out: list[dict[str, Any]] = []
    seen: set[tuple[str, str]] = set()
    for event in as_list(spec.get("events")):
        if not isinstance(event, dict):
            continue
        kind = "happening" if clean_text(event.get("calendarKind")) == "happening" else "schedule"
        if mode in {"schedule", "happening"} and kind != mode:
            continue
        # 従来は「表示日×その前後45日」を毎回探索していた。
        # 表示範囲の前後45日にある基準日を1回だけ走査し、
        # 休日調整・例外移動後の実効日ごとに最初の基準日を採用する。
        # これは _event_occurrence_info() が対象日の45日前から順に
        # 最初の一致を返す従来の優先順位と同じ。
        exceptions = as_dict(event.get("exceptions") or event.get("repeatExceptions"))
        occurrences_by_day: dict[_dt.date, tuple[_dt.date, dict[str, Any]]] = {}
        scan_start = start - _dt.timedelta(days=45)
        scan_end = end + _dt.timedelta(days=45)
        for base in _date_range(scan_start, scan_end):
            if not _base_occurrence_matches(spec, event, base):
                continue
            base_s = base.isoformat()
            ex = as_dict(exceptions.get(base_s))
            if clean_text(ex.get("action")).lower() == "skip":
                continue
            exception_date = clean_date(ex.get("date"))
            effective_s = exception_date or shift_business_date(
                spec,
                base_s,
                event.get("repeatBusinessDayShift"),
                event.get("repeatBusinessDayTie"),
            )
            try:
                effective = _dt.date.fromisoformat(effective_s)
            except (TypeError, ValueError):
                continue
            if effective < start or effective > end:
                continue
            # 旧探索も対象日の前後45日だけを候補にしていた。
            # 大きく移動した例外を新たに表示して挙動を変えないよう維持する。
            if abs((base - effective).days) > 45:
                continue
            if effective in occurrences_by_day:
                continue
            overrides = {k: v for k, v in ex.items() if k not in {"action", "date"} and v not in (None, "")}
            occurrences_by_day[effective] = (
                base,
                {
                    "baseDate": base_s,
                    "shifted": base != effective or bool(exception_date),
                    "overrides": overrides,
                },
            )
        for day in _date_range(start, end):
            hit = occurrences_by_day.get(day)
            if not hit:
                continue
            _base, info = hit
            key = (clean_text(event.get("id")), info["baseDate"])
            if key in seen:
                continue
            seen.add(key)
            item = dict(event)
            item.update(info.get("overrides") or {})
            item["_ds"] = day.isoformat()
            item["_baseDate"] = info["baseDate"]
            item["_shifted"] = bool(info["shifted"])
            out.append(item)
    out.sort(key=lambda x: (x.get("_ds") or x.get("date") or "", 0 if clean_text(x.get("calendarKind")) != "happening" else 1, x.get("time") or "99:99", clean_text(x.get("title"))))
    return out


def memo_text_for_day(memo_value: Any, day: str) -> str:
    """日付別メモを優先し、旧形式の ``today`` は安全に一度だけ扱う。"""
    memo = as_dict(memo_value)
    target_day = clean_date(day)
    days = as_dict(memo.get("days"))
    if target_day and target_day in days:
        return clean_multiline_text(days.get(target_day))
    memo_day = clean_date(memo.get("todayDate") or memo.get("day"))
    if target_day and memo_day == target_day:
        return clean_multiline_text(memo.get("today"))
    # 日付別保存が一件もない旧データだけは、移行時点の当日メモとして表示する。
    if target_day and not memo_day and not days:
        return clean_multiline_text(memo.get("today"))
    return ""


def build_summary(spec_record: dict[str, Any] | None = None, cont_record: dict[str, Any] | None = None) -> dict[str, Any]:
    """今日の集計を、同じ保存ハッシュと日付の間は再計算せず返す。"""
    global SUMMARY_CACHE_KEY, SUMMARY_CACHE_VALUE
    spec_record = spec_record or load_record("speculum", clone=False)
    cont_record = cont_record or load_record("continuum", clone=False)
    spec = as_dict(spec_record.get("data"))
    cont = as_dict(cont_record.get("data"))
    today = date_s()
    mode = due_day_count_mode(spec, cont)
    spec_hash = clean_text(spec_record.get("hash")) or text_hash(stable_json(spec))
    cont_hash = clean_text(cont_record.get("hash")) or text_hash(stable_json(cont))
    cache_key = (spec_hash, cont_hash, today, mode)
    with SUMMARY_CACHE_LOCK:
        if SUMMARY_CACHE_KEY == cache_key and SUMMARY_CACHE_VALUE is not None:
            return SUMMARY_CACHE_VALUE

    base_day = _dt.date.fromisoformat(today)
    business_context = _BusinessDateContext(spec, base_day)
    diff_cache: dict[str, tuple[int | None, int | None]] = {}

    def both_date_diffs(value: Any) -> tuple[int | None, int | None]:
        ds = clean_date(value)
        if not ds:
            return None, None
        cached = diff_cache.get(ds)
        if cached is not None:
            return cached
        try:
            calendar_days: int | None = (_dt.date.fromisoformat(ds) - base_day).days
        except ValueError:
            calendar_days = None
        result = (calendar_days, business_context.diff(ds))
        diff_cache[ds] = result
        return result

    def cached_calendar_diff(value: Any) -> int | None:
        return both_date_diffs(value)[0]

    events_today = calendar_occurrences(spec, today, today, "schedule")
    due = []
    for collection, label in (("deadlines", "期限"), ("jimu", "事務")):
        for x in as_list(spec.get(collection)):
            if record_is_done(x):
                continue
            cal_dd, business_dd = both_date_diffs(x.get("due"))
            dd = cal_dd if mode == "calendar" else business_dd
            if dd is not None and dd <= 7:
                due.append({"kind": label, "id": x.get("id"), "title": clean_text(x.get("title") or x.get("name")), "date": x.get("due"), "days": dd, "calendarDays": cal_dd, "businessDays": business_dd, "dayCountMode": mode})
    for x in as_list(cont.get("tasks")):
        if record_is_done(x):
            continue
        cal_dd, business_dd = both_date_diffs(x.get("due"))
        dd = cal_dd if mode == "calendar" else business_dd
        if dd is not None and dd <= 7:
            due.append({"kind": "作業", "id": x.get("id"), "title": clean_text(x.get("title")), "date": x.get("due"), "days": dd, "calendarDays": cal_dd, "businessDays": business_dd, "dayCountMode": mode})
    due.sort(key=lambda x: (x["days"], x["date"] or ""))
    cycles = []
    for x in as_list(cont.get("cycleTasks")):
        state = clean_text(x.get("state") or x.get("status") or "active")
        if state in {"paused", "ended"} or normalize_work_status(x.get("status")) == "done":
            continue
        nxt = clean_date(x.get("nextRunDate") or x.get("nextDate"))
        cal_dd, business_dd = both_date_diffs(nxt)
        dd = cal_dd if mode == "calendar" else business_dd
        if nxt and dd is not None and dd <= 7:
            cycles.append({"kind": "周期作業", "id": x.get("id"), "title": clean_text(x.get("title")), "date": nxt, "days": dd, "calendarDays": cal_dd, "businessDays": business_dd, "dayCountMode": mode, "state": state})
    cycles.sort(key=lambda x: (x["days"], x["date"] or ""))
    alerts = []
    for c in as_list(spec.get("cases")):
        for hit in case_target_alerts(c, cached_calendar_diff):
            target = clean_text(hit.get("targetName"))
            case_title = clean_text(c.get("title") or c.get("name"))
            alerts.append({"kind": hit.get("alertKind") or "事案アラート", "id": c.get("id"), "targetId": hit.get("targetId"), "title": f"{target} / {case_title}" if target else case_title, "caseTitle": case_title, "targetName": target, "targets": target or case_target_names(c), "date": hit.get("alertDate"), "days": hit.get("diff"), "status": hit.get("targetStatus") or hit.get("status")})
    alerts.sort(key=lambda x: (x["days"], x["date"] or ""))
    summary = {"ok": True, "today": today, "dayCountMode": mode, "eventsToday": events_today, "dueSoon": due[:30], "cycleSoon": cycles[:20], "caseAlerts": alerts[:30], "memo": memo_text_for_day(spec.get("memo"), today)}
    with SUMMARY_CACHE_LOCK:
        SUMMARY_CACHE_KEY = cache_key
        SUMMARY_CACHE_VALUE = summary
    return summary



def import_cabinet_holidays() -> dict[str, Any]:
    """内閣府CSVから2000年以降の祝日・休日を取り込み、未取得日だけ追加する。"""
    req = urllib.request.Request(CABINET_HOLIDAY_CSV_URL, headers={"User-Agent": "BlackCatWorkTool"})
    with urllib.request.urlopen(req, timeout=18) as r:
        raw = r.read()
    text = None
    for enc in ("utf-8-sig", "cp932", "shift_jis"):
        try:
            text = raw.decode(enc)
            break
        except UnicodeDecodeError:
            continue
    if text is None:
        text = raw.decode("utf-8", errors="replace")
    reader = csv.reader(io.StringIO(text))
    source_items: dict[str, str] = {}
    seen_source = 0; min_date = ""; max_date = ""
    for row in reader:
        if len(row) < 2:
            continue
        ds = clean_date(row[0]); name = clean_text(row[1])
        if not ds or not name or not ds[:4].isdigit():
            continue
        if int(ds[:4]) < HOLIDAY_IMPORT_START_YEAR:
            continue
        seen_source += 1
        if not min_date or ds < min_date: min_date = ds
        if not max_date or ds > max_date: max_date = ds
        source_items[ds] = name
    with SAVE_RECORD_LOCK:
        spec = _copy_speculum_for_write(as_dict(load_record("speculum", clone=False).get("data")))
        holidays = as_dict(spec.get("holidays"))
        items = dict(as_dict(holidays.get("items")))
        added = 0; skipped = 0
        for ds, name in source_items.items():
            if ds in items:
                skipped += 1
                continue
            items[ds] = name
            added += 1
        spec["holidays"] = {"items": dict(sorted(items.items())), "source": CABINET_HOLIDAY_CSV_URL, "startYear": HOLIDAY_IMPORT_START_YEAR, "lastImportedAt": iso_now(), "lastSourceMinDate": min_date, "lastSourceMaxDate": max_date}
        saved = save_record("speculum", spec, already_normalised=True, backup_policy="auto")
    return {"ok": True, "added": added, "skipped": skipped, "sourceCount": seen_source, "startYear": HOLIDAY_IMPORT_START_YEAR, "minDate": min_date, "maxDate": max_date, "holidays": saved["data"].get("holidays", {}), "hash": saved.get("hash")}

def list_people_focus(q: str = "") -> list[dict[str, Any]]:
    """人物検索用の索引を保存ハッシュ単位で再利用する。

    従来は人物1人ごとに予定と経歴を全走査していたため、全件表示は
    人物数×関連データ数で増えていた。関連件数を1回の走査で集計し、検索時は
    作成済みの検索文字列だけを見る。
    """
    global PEOPLE_FOCUS_INDEX_KEY, PEOPLE_FOCUS_INDEX
    record = load_record("speculum", clone=False)
    spec = as_dict(record.get("data"))
    index_key = clean_text(record.get("hash")) or f"memory:{id(spec)}"
    with PEOPLE_FOCUS_INDEX_LOCK:
        if PEOPLE_FOCUS_INDEX_KEY == index_key:
            index = PEOPLE_FOCUS_INDEX
        else:
            event_counts: dict[str, int] = {}
            career_counts: dict[str, int] = {}
            for collection, counts in (("events", event_counts), ("career", career_counts)):
                for item in as_list(spec.get(collection)):
                    if not isinstance(item, dict):
                        continue
                    # 同じ項目内の重複IDは、従来どおり関連1件として数える。
                    person_ids = {clean_text(x) for x in as_list(item.get("personIds")) if clean_text(x)}
                    for person_id in person_ids:
                        counts[person_id] = counts.get(person_id, 0) + 1
            built: list[dict[str, Any]] = []
            for person in as_list(spec.get("people")):
                if not isinstance(person, dict):
                    continue
                person_id = clean_text(person.get("id"))
                search_text = " ".join(
                    clean_text(person.get(field))
                    for field in ("name", "kind", "term", "role", "org", "tel", "email", "tags", "note")
                ).lower()
                built.append({
                    **person,
                    "related": {
                        "events": event_counts.get(person_id, 0),
                        "career": career_counts.get(person_id, 0),
                        "tasks": 0,
                    },
                    "_searchText": search_text,
                })
            PEOPLE_FOCUS_INDEX_KEY = index_key
            PEOPLE_FOCUS_INDEX = built
            index = built
    ql = clean_text(q).lower()
    out: list[dict[str, Any]] = []
    for indexed_person in index:
        if ql and ql not in str(indexed_person.get("_searchText") or ""):
            continue
        person = dict(indexed_person)
        person.pop("_searchText", None)
        out.append(person)
    return out


def local_tool_query_tokens(query: str) -> list[str]:
    """検索語から「ローカル」「ツール」「起動」などの操作語を落とし、実名検索に使う語だけ返す。"""
    q = clean_text(query).lower()
    if not q:
        return []
    q = q.replace("＿", "_").replace("－", "-")
    for word in sorted(LOCAL_TOOL_QUERY_WORDS, key=len, reverse=True):
        q = q.replace(word, " ")
    parts = [clean_text(x).lower() for x in re.split(r"[\s　,、。/\\]+", q) if clean_text(x)]
    return parts


def local_tool_match(path: Path, tokens: list[str]) -> bool:
    if not tokens:
        return True
    title = path.stem.replace("_", " ").replace("-", " ")
    hay = f"{path.name} {title}".lower()
    return all(token in hay for token in tokens)


def local_tool_catalog() -> list[dict[str, Any]]:
    ensure_dirs()
    root = LOCAL_TOOLS_ROOT.resolve()
    try:
        entries = sorted(root.iterdir(), key=lambda x: x.name.lower())
        stamp = (root.stat().st_mtime_ns, len(entries))
    except Exception:
        return []
    with LOCAL_TOOL_CATALOG_LOCK:
        if LOCAL_TOOL_CATALOG_CACHE.get("stamp") == stamp:
            return [dict(x) for x in as_list(LOCAL_TOOL_CATALOG_CACHE.get("items")) if isinstance(x, dict)]
    items: list[dict[str, Any]] = []
    for p in entries:
        if not p.is_file() or p.suffix.lower() not in TOOL_EXTENSIONS:
            continue
        rel = p.name
        title = p.stem.replace("_", " ").replace("-", " ").strip() or p.name
        items.append({"id": "local:" + rel, "title": title, "name": p.name, "rel": rel, "ext": p.suffix.lower(), "kind": "ローカルツール", "action": "launch_local", "actionLabel": "起動", "canExecute": True})
    with LOCAL_TOOL_CATALOG_LOCK:
        LOCAL_TOOL_CATALOG_CACHE["stamp"] = stamp
        LOCAL_TOOL_CATALOG_CACHE["items"] = [dict(x) for x in items]
    return items


def scan_local_tools(query: str = "") -> list[dict[str, Any]]:
    """LocalTools 直下の実行用ファイルだけを列挙する。文書ファイルやサブフォルダ内は対象にしない。

    「ローカルツール」「起動」だけの検索では、ツール名が含まれていないため全ツールを候補に出す。
    """
    tokens = local_tool_query_tokens(query)
    items: list[dict[str, Any]] = []
    for tool in local_tool_catalog():
        name = clean_text(tool.get("name"))
        fake_path = Path(name)
        if not local_tool_match(fake_path, tokens):
            continue
        items.append(dict(tool))
    return items[:80]


def safe_child(root: Path, rel: str) -> Path:
    target = (root / rel).resolve()
    if root.resolve() != target and root.resolve() not in target.parents:
        raise ValueError("対象の場所を開けません。")
    return target


def open_path(path: Path) -> None:
    if sys.platform.startswith("win"):
        os.startfile(str(path))  # type: ignore[attr-defined]
    elif sys.platform == "darwin":
        subprocess.Popen(["open", str(path)])
    else:
        subprocess.Popen(["xdg-open", str(path)])


def edge_candidates() -> list[str]:
    names = ["msedge.exe", "microsoft-edge.exe", "msedge", "microsoft-edge", "chromium", "chromium-browser", "google-chrome"]
    found: list[str] = []
    for name in names:
        p = shutil.which(name)
        if p and p not in found:
            found.append(p)
    if sys.platform.startswith("win"):
        roots = [
            os.environ.get("ProgramFiles"),
            os.environ.get("ProgramFiles(x86)"),
            os.environ.get("LOCALAPPDATA"),
        ]
        rels = [
            r"Microsoft\Edge\Application\msedge.exe",
            r"Microsoft\Edge SxS\Application\msedge.exe",
        ]
        for root in roots:
            if not root:
                continue
            for rel in rels:
                p = str(Path(root) / rel)
                if Path(p).exists() and p not in found:
                    found.append(p)
    return found


def normalise_app_target(target: str) -> tuple[str, str]:
    raw = clean_text(target) or "speculum"
    alias = {
        "main": "speculum", "home": "speculum", "schedule": "speculum", "予定": "speculum",
        "work": "continuum", "task": "continuum", "tasks": "continuum", "作業": "continuum",
        "cat": "floating", "bubble": "floating", "resident": "floating", "黒猫": "floating",
        "workspace": "workspace", "ワークスペース": "workspace",
    }
    if raw.startswith(("http://", "https://")):
        parsed = urlparse(raw)
        path = parsed.path or "/speculum"
        fragment = f"#{parsed.fragment}" if parsed.fragment else ""
    else:
        path = raw if raw.startswith("/") else "/" + raw
        fragment = ""
        if "#" in path:
            path, fragment_part = path.split("#", 1)
            fragment = "#" + fragment_part
    parts = [x for x in path.strip("/").split("/") if x]
    first_raw = parts[0] if parts else "speculum"
    first = alias.get(first_raw, first_raw)
    if first not in {"speculum", "continuum", "floating", "workspace"}:
        first = "speculum"
        parts = ["speculum"]
    else:
        parts = [first] + parts[1:]
    path = "/" + "/".join(parts)
    return first, path.rstrip("/") + fragment


def app_url(target: str, port: int = DEFAULT_PORT) -> str:
    _, path = normalise_app_target(target)
    return f"http://{DEFAULT_HOST}:{port}{path}"


def workspace_path_for(target: str) -> str:
    app, path = normalise_app_target(target)
    # 今日・日付確認・作業管理は /workspace の一つの通常ブラウザタブで切り替える。
    # /continuum を要求されても単独画面にせず、ワークスペースの作業タブへ寄せる。
    if app == "continuum":
        fragment = ""
        if "#" in path:
            fragment = clean_text(path.split("#", 1)[1])
        elif "?" in path:
            fragment = clean_text(path.split("?", 1)[1])
        return "/workspace#continuum" + (f"?{fragment.lstrip('?')}" if fragment else "")
    if app == "speculum":
        fragment = "today"
        if "#" in path:
            fragment = path.split("#", 1)[1] or "today"
        if fragment in {"work", "continuum"}:
            return "/workspace#continuum"
        return f"/workspace#speculum:{fragment}"
    if app == "workspace":
        return path or "/workspace"
    return path



def workspace_hash_for_path(path: str) -> str:
    """ワークスペース内で切り替えるハッシュだけを取り出す。"""
    if "#" in path:
        return "#" + path.split("#", 1)[1]
    return "#speculum:today"


def publish_workspace_route(target: str) -> str:
    """既存ワークスペースに切替指示を残す。新しいタブを増やさないための軽いIPC。"""
    route = workspace_path_for(target)
    h = workspace_hash_for_path(route)
    RUNTIME_ROOT.mkdir(parents=True, exist_ok=True)
    with UI_ROUTE_LOCK:
        revision = 1
        try:
            previous = json.loads(UI_ROUTE_PATH.read_text(encoding="utf-8"))
            revision = max(1, int(as_dict(previous).get("revision") or 0) + 1)
        except Exception:
            pass
        _atomic_write_text(UI_ROUTE_PATH, json.dumps({"hash": h, "at": time.time(), "revision": revision}, ensure_ascii=False))
    return h


def current_workspace_route() -> dict[str, Any]:
    try:
        data = json.loads(UI_ROUTE_PATH.read_text(encoding="utf-8"))
        if isinstance(data, dict):
            return {
                "hash": clean_text(data.get("hash")) or "#speculum:today",
                "at": float(data.get("at") or 0),
                "revision": max(0, int(data.get("revision") or 0)),
            }
    except Exception:
        pass
    return {"hash": "#speculum:today", "at": 0.0, "revision": 0}


def current_floating_state() -> dict[str, Any]:
    """常駐猫が最後に配置した吹き出し方向だけをWeb小窓へ渡す。"""
    anchor = ""
    try:
        state_path = DATA_ROOT / "resident_blackcat_state.json"
        if state_path.is_file() and state_path.stat().st_size <= 1024 * 1024:
            raw = json.loads(state_path.read_text(encoding="utf-8"))
            value = clean_text(as_dict(raw).get("bubbleAnchor")).lower()
            if value in {"left", "right"}:
                anchor = value
    except Exception:
        anchor = ""
    return {"ok": True, "anchor": anchor}


def is_workspace_window_title(title: Any) -> bool:
    """ブラウザーの最上位タイトルからワークスペースだけを見分ける。

    吹き出しにも「黒猫ワークツール」が入るため部分一致にすると、吹き出し自身を
    前面化して本体を開いたと誤判定する。現在のワークスペースが使うタイトルだけを
    許可し、吹き出し・埋込み画面・案内画面は明示的に除外する。
    """
    value = str(title or "").strip()
    if not value or any(part in value for part in ("黒猫の吹き出し", "Black Cat Command", "/floating")):
        return False
    known = (
        "黒猫ワークツール｜今日・日付確認",
        "黒猫ワークツール｜作業管理",
        # 直前版を開いたまま更新した場合も、その既存タブへ遷移指示を届ける。
        # 吹き出しは上の明示除外により、この互換名を増やしても対象にならない。
        "今日・日付確認｜黒猫ワークツール",
        "作業管理｜黒猫ワークツール",
        "黒猫ワークスペース",
        "Black Cat Workspace",
    )
    # Edgeは「 - Microsoft Edge」等を末尾へ付ける。既知タイトル直後の
    # ブラウザー接尾辞だけを許し、任意の「黒猫ワークツール」部分一致には戻さない。
    return any(value == base or any(value.startswith(base + sep) for sep in (" - ", " – ", " — ")) for base in known)


def _declare_winapi(library: Any, name: str, argtypes: list[Any], restype: Any) -> Any | None:
    """Win32 API の型を明示し、64bit のウィンドウハンドルを保つ。"""
    function = getattr(library, name, None) if library is not None else None
    if function is None:
        return None
    try:
        function.argtypes = argtypes
        function.restype = restype
    except Exception:
        # 検証用モックなどで型属性を持たない場合も、
        # 呼出し自体は従来どおり試みる。
        pass
    return function


def focus_workspace_window() -> bool:
    """Windows で既存の黒猫ワークスペース窓を最大化して前面へ戻す。

    常駐の吹き出しは ``is_workspace_window_title`` で明示的に除外するため、
    この最大化処理の対象にはならない。
    """
    if not sys.platform.startswith("win"):
        return False
    try:
        import ctypes
        from ctypes import wintypes
        user32 = ctypes.windll.user32
        titles = []
        enum_proc_type = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
        is_visible = _declare_winapi(user32, "IsWindowVisible", [wintypes.HWND], wintypes.BOOL)
        get_text_length = _declare_winapi(user32, "GetWindowTextLengthW", [wintypes.HWND], ctypes.c_int)
        get_text = _declare_winapi(
            user32,
            "GetWindowTextW",
            [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int],
            ctypes.c_int,
        )
        enum_windows = _declare_winapi(user32, "EnumWindows", [enum_proc_type, wintypes.LPARAM], wintypes.BOOL)
        show_window = _declare_winapi(user32, "ShowWindow", [wintypes.HWND, ctypes.c_int], wintypes.BOOL)
        bring_to_top = _declare_winapi(user32, "BringWindowToTop", [wintypes.HWND], wintypes.BOOL)
        set_foreground = _declare_winapi(user32, "SetForegroundWindow", [wintypes.HWND], wintypes.BOOL)
        if not all((is_visible, get_text_length, get_text, enum_windows, show_window, set_foreground)):
            return False

        @enum_proc_type
        def enum_proc(hwnd, _lparam):
            hwnd_w = wintypes.HWND(hwnd)
            if not is_visible(hwnd_w):
                return True
            length = get_text_length(hwnd_w)
            if length <= 0:
                return True
            buf = ctypes.create_unicode_buffer(length + 1)
            get_text(hwnd_w, buf, length + 1)
            title = buf.value or ""
            if is_workspace_window_title(title):
                titles.append(int(hwnd or 0))
                return False
            return True
        enum_windows(enum_proc, wintypes.LPARAM(0))
        if not titles:
            return False
        hwnd = wintypes.HWND(titles[0])
        # SW_MAXIMIZE は最小化中の既存窓にも使え、通常サイズへ一度戻す
        # ちらつきを挟まず、そのまま利用できる大きさで表示できる。
        SW_MAXIMIZE = 3
        show_window(hwnd, SW_MAXIMIZE)
        try:
            if bring_to_top:
                bring_to_top(hwnd)
        except Exception:
            pass
        try:
            set_foreground(hwnd)
        except Exception:
            pass
        # SetForegroundWindow は Windows の前面化制限で拒否されることがある。
        # その成否を重複窓の起動条件にはせず、厳密に識別した既存窓へ
        # SW_MAXIMIZE を送れた時点で同じワークスペースを継続利用する。
        return True
    except Exception:
        return False


def start_workspace_maximize_watch() -> bool:
    """Edge起動後のサイズ復元にも負けない短時間の最大化監視を開始する。

    START_HERE自身を監視専用モードで別プロセス起動するため、HTTP応答や
    常駐メニューを数秒待たせない。監視側は予定・作業の既知タイトルだけを
    対象にするので、コンパクトな吹き出しへ最大化命令は送らない。
    """
    if not sys.platform.startswith("win"):
        return False
    watcher = APP_ROOT / "START_HERE.pyw"
    if not watcher.is_file():
        return False
    try:
        pythonw = Path(sys.executable).with_name("pythonw.exe")
        executable = str(pythonw if pythonw.exists() else Path(sys.executable))
        flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        subprocess.Popen(
            [executable, str(watcher), "--maximize-workspace-watch"],
            cwd=str(APP_ROOT),
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            creationflags=flags,
        )
        return True
    except Exception:
        return False

def hide_floating_windows() -> dict[str, Any]:
    """Windows で残った黒猫吹き出し窓を閉じずに隠す。"""
    if not sys.platform.startswith("win"):
        return {"ok": True, "hidden": 0, "mode": "unsupported"}
    try:
        import ctypes
        from ctypes import wintypes
        user32 = ctypes.windll.user32
        hwnds: list[int] = []
        title_parts = ("黒猫の吹き出し", "Black Cat Command", "/floating", "127.0.0.1:8765/floating", "localhost:8765/floating")

        enum_proc_type = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
        get_text_length = _declare_winapi(user32, "GetWindowTextLengthW", [wintypes.HWND], ctypes.c_int)
        get_text = _declare_winapi(
            user32,
            "GetWindowTextW",
            [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int],
            ctypes.c_int,
        )
        enum_windows = _declare_winapi(user32, "EnumWindows", [enum_proc_type, wintypes.LPARAM], wintypes.BOOL)
        show_window = _declare_winapi(user32, "ShowWindow", [wintypes.HWND, ctypes.c_int], wintypes.BOOL)
        if not all((get_text_length, get_text, enum_windows, show_window)):
            return {"ok": True, "hidden": 0, "mode": "error", "error": "Windows API unavailable"}

        @enum_proc_type
        def enum_proc(hwnd, _lparam):
            hwnd_w = wintypes.HWND(hwnd)
            length = get_text_length(hwnd_w)
            if length <= 0:
                return True
            buf = ctypes.create_unicode_buffer(length + 1)
            get_text(hwnd_w, buf, length + 1)
            title = buf.value or ""
            if any(part in title for part in title_parts):
                hwnds.append(int(hwnd or 0))
            return True

        enum_windows(enum_proc, wintypes.LPARAM(0))
        SW_HIDE = 0
        for hwnd in hwnds:
            show_window(wintypes.HWND(hwnd), SW_HIDE)
        return {"ok": True, "hidden": len(hwnds), "mode": "windows"}
    except Exception as exc:
        return {"ok": True, "hidden": 0, "mode": "error", "error": str(exc)}


def open_edge_app(target: str, port: int = DEFAULT_PORT) -> dict[str, Any]:
    app, _ = normalise_app_target(target)
    # 吹き出しだけは Edge --app の小窓。今日・日付確認・作業管理はワークスペース内の1タブで切替える。
    if app != "floating":
        route = workspace_path_for(target)
        h = publish_workspace_route(target)
        url = f"http://{DEFAULT_HOST}:{port}{route}"
        if focus_workspace_window():
            start_workspace_maximize_watch()
            return {"ok": True, "opened": "existing-window", "mode": "workspace_single", "url": url, "hash": h}
        # 前面化できなかった時に開く新規窓は、背景の旧Workspaceへ即座に
        # handoffせず自分がprimaryを引き継ぐことを明示する。
        takeover_route = route.replace("/workspace", "/workspace?takeover=1", 1) if route.startswith("/workspace") else route
        url = f"http://{DEFAULT_HOST}:{port}{takeover_route}"
        edge = edge_candidates()
        if edge:
            # 本体はブラウザーの通常窓として最大化する。吹き出し用の
            # --app/--window-size 経路にはこの指定を渡さない。
            subprocess.Popen([edge[0], "--new-window", "--start-maximized", url], cwd=str(APP_ROOT))
            start_workspace_maximize_watch()
            return {"ok": True, "opened": "browser-window", "mode": "workspace_single", "url": url, "hash": h}
        if webbrowser.open(url):
            start_workspace_maximize_watch()
            return {"ok": True, "opened": "browser", "mode": "workspace_single", "url": url, "hash": h}
        raise RuntimeError("既定のブラウザーで黒猫ワークツールを開けませんでした。")
    url = app_url(target, port)
    size = "500,720"
    edge = edge_candidates()
    if edge:
        args = [edge[0], "--new-window", f"--app={url}", f"--window-size={size}"]
        args.append("--window-position=1320,90")
        subprocess.Popen(args, cwd=str(APP_ROOT))
        return {"ok": True, "opened": "edge-app", "mode": "edge_app", "url": url}
    if webbrowser.open(url):
        return {"ok": True, "opened": "browser", "mode": "browser", "url": url}
    raise RuntimeError("既定のブラウザーで黒猫の吹き出しを開けませんでした。")



def start_resident_icon() -> dict[str, Any]:
    """常駐黒猫アイコンをネイティブ最前面小窓として起動する。"""
    target = APP_ROOT / "START_BLACKCAT_FLOATING.pyw"
    if not target.exists():
        raise ValueError("常駐黒猫の起動ファイルが見つかりません。")
    flags = getattr(subprocess, "CREATE_NO_WINDOW", 0) if sys.platform.startswith("win") else 0
    exe = sys.executable
    if sys.platform.startswith("win"):
        pyw = Path(sys.executable).with_name("pythonw.exe")
        if pyw.exists():
            exe = str(pyw)
    env = os.environ.copy()
    env["PYTHONUTF8"] = "1"
    env["PYTHONIOENCODING"] = "utf-8"
    subprocess.Popen([exe, str(target)], cwd=str(APP_ROOT), stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, creationflags=flags, env=env)
    return {"ok": True, "mode": "native_topmost", "message": "常駐黒猫を起動しました。"}

def resolve_local_tool_rel(rel: str) -> Path:
    """LocalTools直下の実行用ファイルだけを厳格に解決する。"""
    ensure_dirs()
    raw = clean_text(rel)
    if raw.startswith("local:"):
        raw = raw[6:]
    raw = unquote(raw).replace("\\", "/")
    if not raw or "/" in raw or raw in {".", ".."} or raw.startswith("."):
        raise ValueError("ローカルツールは LocalTools 直下の実行用ファイルだけ起動できます。")
    root = LOCAL_TOOLS_ROOT.resolve()
    p = safe_child(LOCAL_TOOLS_ROOT, raw)
    # 大小文字差、拡張子省略、表示名からの起動に耐える。ただし直下ファイルだけ。
    if not p.exists():
        raw_low = raw.lower()
        for cand in root.iterdir():
            if not cand.is_file() or cand.suffix.lower() not in TOOL_EXTENSIONS:
                continue
            if cand.name.lower() == raw_low or cand.stem.lower() == raw_low:
                p = cand.resolve()
                break
    if p.parent.resolve() != root or not p.exists() or not p.is_file() or p.suffix.lower() not in TOOL_EXTENSIONS:
        allowed = " / ".join(sorted(TOOL_EXTENSIONS))
        raise ValueError(f"起動できるローカルツールが見つかりません。対象はLocalTools直下の実行用ファイルだけです: {allowed}")
    return p


def python_for_local_tool(ext: str) -> str:
    """pywはpythonw、pyはpythonを優先する。"""
    if not sys.platform.startswith("win"):
        return sys.executable
    exe = Path(sys.executable)
    if ext == ".pyw":
        pyw = exe.with_name("pythonw.exe")
        if pyw.exists():
            return str(pyw)
    py = exe.with_name("python.exe")
    if py.exists():
        return str(py)
    return sys.executable


def launch_detached(args: list[str], cwd: Path, *, new_console: bool = False, hidden: bool = False, env: dict[str, str] | None = None) -> int:
    kwargs: dict[str, Any] = {
        "cwd": str(cwd),
        "env": env,
        "stdin": subprocess.DEVNULL,
        "stdout": subprocess.DEVNULL,
        "stderr": subprocess.DEVNULL,
    }
    if sys.platform.startswith("win"):
        flags = getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
        if new_console:
            flags |= getattr(subprocess, "CREATE_NEW_CONSOLE", 0)
        if hidden:
            flags |= getattr(subprocess, "CREATE_NO_WINDOW", 0)
        kwargs["creationflags"] = flags
        kwargs["close_fds"] = False
    else:
        kwargs["start_new_session"] = True
        kwargs["close_fds"] = True
    proc = subprocess.Popen(args, **kwargs)
    return int(getattr(proc, "pid", 0) or 0)


def launch_local_tool(rel: str) -> dict[str, Any]:
    p = resolve_local_tool_rel(rel)
    ext = p.suffix.lower()
    env = os.environ.copy()
    env.setdefault("PYTHONUTF8", "1")
    env.setdefault("PYTHONIOENCODING", "utf-8")
    try:
        if sys.platform.startswith("win"):
            if ext in {".bat", ".cmd"}:
                # os.startfile任せだと環境によって無反応に見えるため、cmd startで明示起動する。
                launch_detached(["cmd.exe", "/c", "start", "", "/D", str(p.parent), str(p)], p.parent, hidden=True, env=env)
                mode = "cmd-start"
            elif ext == ".ps1":
                ps = shutil.which("powershell.exe") or shutil.which("pwsh.exe") or "powershell.exe"
                launch_detached([ps, "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", str(p)], p.parent, new_console=True, env=env)
                mode = "powershell"
            elif ext == ".pyw":
                launch_detached([python_for_local_tool(ext), str(p)], p.parent, env=env)
                mode = "pythonw"
            elif ext == ".py":
                launch_detached([python_for_local_tool(ext), str(p)], p.parent, new_console=True, env=env)
                mode = "python"
            elif ext == ".exe":
                launch_detached([str(p)], p.parent, env=env)
                mode = "exe"
            elif ext in {".lnk", ".url"}:
                os.startfile(str(p))  # type: ignore[attr-defined]
                mode = "shortcut"
            else:
                raise ValueError("この拡張子はローカルツールの起動対象ではありません。")
        else:
            if ext in {".py", ".pyw"}:
                launch_detached([sys.executable, str(p)], p.parent, env=env)
                mode = "python"
            elif ext == ".url":
                url = ""
                for line in p.read_text(encoding="utf-8", errors="ignore").splitlines():
                    if line.lower().startswith("url="):
                        url = line.split("=", 1)[1].strip(); break
                if not url:
                    raise ValueError("URLショートカットのURLを読み取れません。")
                webbrowser.open(url)
                mode = "url"
            elif os.access(p, os.X_OK):
                launch_detached([str(p)], p.parent, env=env)
                mode = "exec"
            else:
                raise ValueError("この環境では .py/.pyw、または実行権限のあるローカルツールだけ起動できます。Windowsでは通常どおり起動できます。")
    except OSError as e:
        raise ValueError(f"ローカルツールを起動できませんでした: {e}") from e
    return {"ok": True, "launched": p.name, "mode": mode}


def open_local_tools_folder() -> dict[str, Any]:
    open_path(LOCAL_TOOLS_ROOT)
    return {"ok": True}


def classify_command(query: str) -> tuple[str, str] | None:
    """検索バーの入力から、明示的な登録命令だけを候補化する。"""
    q = clean_text(query)
    if not q:
        return None
    low = q.lower()
    explicit_add = any(w in q for w in ["追加", "登録", "入れて", "作って"]) or any(w in low for w in ["add", "create"])
    if not explicit_add:
        return None
    if is_periodic_command_text(q):
        return "quick_cycle", "周期作業として追加"
    if "出来事" in q or "できごと" in q:
        return "quick_happening", "出来事として追加"
    if "予定" in q and "作業追加" not in q:
        return "quick_event", "予定として追加"
    if "事務" in q:
        return "quick_jimu", "事務として追加"
    if "作業" in q or "タスク" in q:
        return "quick_task", "作業として追加"
    if "期限" in q or "締切" in q or "期日" in q:
        return "quick_deadline", "期限として追加"
    return None


def command_registration_context(query: str) -> bool:
    """明示的な「追加」がなくても、日付や時刻がある入力は登録候補を控えめに出す。"""
    q = clean_text(query)
    if not q:
        return False
    if natural_datetime_validation_error(q):
        return False
    if any(w in q for w in ["今日を組む", "朝の整理", "今日の整理", "今日を閉じる", "終業", "締め"]):
        return False
    if classify_command(q):
        return False
    if is_periodic_command_text(q):
        return True
    if any(w in q for w in ["今月末", "来月末", "月末", "月初"]):
        return len(strip_command_action_noise(parse_natural(q).get("title", q))) >= 2
    # 「1時間30分」は所要時間であり、開始時刻の「1時」ではない。
    # 「15時30分」のような時計表現だけを登録文脈として扱う。
    if re.search(r"\d{1,2}:\d{2}|\d{1,2}時(?!間)", q) or any(w in q for w in ["朝一", "正午", "昼一", "夕方"]):
        return True
    if re.search(r"\d{4}[-/]\d{1,2}[-/]\d{1,2}|\d{4}年\d{1,2}月\d{1,2}日|\d{1,2}[-/]\d{1,2}|\d{1,2}月\d{1,2}日", q):
        return True
    if re.search(r"\d+\s*(?:日|週間?)後", q):
        return len(strip_command_action_noise(parse_natural(q).get("title", q))) >= 2
    if re.search(r"(?:(?:次の|今度の)?)?[月火水木金土日]曜(?:日)?", q):
        return len(strip_command_action_noise(parse_natural(q).get("title", q))) >= 2
    if any(w in q for w in ["月末", "今月末", "来月末", "月初", "月始", "月始め"]):
        return len(strip_command_action_noise(parse_natural(q).get("title", q))) >= 2
    if any(w in q for w in ["今日", "本日", "明日", "あした", "明後日", "あさって", "今週", "来週"]):
        return len(strip_command_action_noise(parse_natural(q).get("title", q))) >= 2
    return False


def strip_command_action_noise(text: str) -> str:
    """吹き出しの実行候補用に、末尾や先頭の命令語だけを落とす。

    「休止中チェック 再開」のように、タイトル中に操作語が含まれる場合まで
    削ってしまうと検索対象が壊れるため、全文置換はしない。
    """
    t = clean_text(text)
    # 日付・時刻は検索対象名から落とす。parse_natural はこの関数を呼ばないため再帰しない。
    t = clean_text(parse_natural(t).get("title", t))
    action = (
        r"完了(?:する|して|にする)?|済み?|終わった|終わり|done|complete|"
        r"待ち(?:にする|へ|状態)?|保留(?:にする|へ)?|waiting|"
        r"今日やる|今日へ|今日に|今日に移動|次に|戻す|"
        r"スキップ|飛ばす|今回飛ばす|今回だけ飛ばす|休止|一時停止|再開|終了|終わらせる|"
        r"高優先|優先度(?:を)?高|重要|通常優先|優先度(?:を)?通常|低優先|優先度(?:を)?低|"
        r"延期(?:する|して)?|延ばす|先送り|期限(?:を)?(?:変更|設定|にする)?|期日(?:を)?(?:変更|設定)?"
    )
    edge_patterns = [
        # 先頭側の命令語は、直後に区切り・助詞がある時だけ落とす。
        # 「休止中チェック 再開」のような題名中の語まで削らないため。
        rf"^(?:作業|タスク|周期作業)?(?:を|に|へ)?\s*(?:{action})(?:する|して|にする|へ|状態)?(?:[\s　,、。:：]+|を|に|へ|で)+",
        # 末尾側は「資料確認完了」のようにくっついて入力されることが多いため、従来どおり許容する。
        rf"\s*(?:を|に|へ)?(?:{action})(?:する|して|にする|へ|状態)?\s*$",
        r"^(?:作業|タスク|周期作業)[:：、,\s]+",
        r"\s+(?:作業|タスク)$",
        r"^(?:を|に|へ|で)\s*",
        r"\s*(?:を|に|へ|で)$",
    ]
    for _ in range(4):
        before = t
        for pat in edge_patterns:
            t = clean_text(re.sub(pat, " ", t, flags=re.I))
        if t == before:
            break
    return clean_text(t)


def command_has_action_word(query: str, words: list[str]) -> bool:
    q = clean_text(query).lower()
    if not q:
        return False
    for raw in words:
        w = clean_text(raw).lower()
        if not w:
            continue
        if q == w or q.endswith(w):
            return True
        if re.search(rf"(^|[\s　,、。]|を|に|へ){re.escape(w)}($|[\s　,、。]|する|して|にする|へ|状態)", q):
            return True
    return False


def command_action_kind(query: str) -> tuple[str, str, str] | None:
    q = clean_text(query)
    low = q.lower()
    if not q:
        return None
    # 周期作業専用の操作。タイトル中の語ではなく、末尾・先頭・区切りのある命令語を優先する。
    if command_has_action_word(q, ["スキップ", "飛ばす", "今回飛ばす", "今回だけ飛ばす"]):
        return "cycle_skip", "スキップする", "スキップ"
    if command_has_action_word(q, ["再開"]):
        return "cycle_resume", "再開する", "再開"
    if command_has_action_word(q, ["終了", "終わらせる"]):
        return "cycle_end", "終了する", "終了"
    if command_has_action_word(q, ["休止", "一時停止"]):
        return "cycle_pause", "休止する", "休止"
    if command_has_action_word(low, ["done", "complete"]) or command_has_action_word(q, ["完了", "済", "終わった", "終わり"]):
        return "task_complete", "完了にする", "完了"
    if command_has_action_word(q, ["待ち", "保留"]):
        return "task_waiting", "待ちにする", "待ち"
    if command_has_action_word(q, ["今日やる", "今日へ", "今日に移動", "今日にする"]):
        return "task_today", "「今日やる」に移す", "今日"
    if command_has_action_word(q, ["高優先", "優先度高", "優先度を高", "重要"]):
        return "task_priority_high", "高優先にする", "高優先"
    if command_has_action_word(q, ["通常優先", "優先度通常", "優先度を通常"]):
        return "task_priority_normal", "通常優先にする", "通常"
    if command_has_action_word(q, ["低優先", "優先度低", "優先度を低"]):
        return "task_priority_low", "低優先にする", "低優先"
    if command_has_action_word(q, ["延期", "延ばす", "先送り", "期限変更", "期限を変更", "期日変更", "明日に", "明日へ", "来週に", "来週へ"]):
        return "task_due", "期限を変更", "期限変更"
    return None


def command_target_tokens(query: str) -> list[str]:
    parsed_title = parse_natural(query).get("title", query)
    target = strip_command_action_noise(parsed_title)
    return command_split_tokens(target)


def command_split_tokens(text: str) -> list[str]:
    return [clean_text(x).lower() for x in re.split(r"[\s　,、。/\\]+", clean_text(text)) if clean_text(x)]


def command_person_text(person: dict[str, Any]) -> str:
    return " ".join(clean_text(person.get(k)) for k in ["id", "name", "kana", "kind", "term", "org", "role", "section", "title", "tags", "note"] if clean_text(person.get(k)))


def command_case_text(case: dict[str, Any]) -> str:
    targets = []
    for target in as_list(case.get("targetPersons") or case.get("targets")):
        if isinstance(target, dict):
            targets.append(" ".join(clean_text(target.get(k)) for k in ["id", "name", "role", "status", "startedAt", "nextDate", "nextAction", "owner", "note"] if clean_text(target.get(k))))
        else:
            targets.append(clean_text(target))
    return " ".join([
        clean_text(case.get("id")), clean_text(case.get("title") or case.get("name")), clean_text(case.get("client")),
        clean_text(case.get("owner")), clean_text(case.get("nextAction")), clean_text(case.get("status")),
        clean_text(case.get("note")), " ".join(x for x in targets if x),
    ])


def command_lookup_maps(spec: dict[str, Any] | None) -> tuple[dict[str, str], dict[str, str]]:
    spec = as_dict(spec)
    people = {clean_text(p.get("id")): command_person_text(p) for p in as_list(spec.get("people")) if isinstance(p, dict) and clean_text(p.get("id"))}
    cases = {clean_text(c.get("id")): command_case_text(c) for c in as_list(spec.get("cases")) if isinstance(c, dict) and clean_text(c.get("id"))}
    return people, cases


def command_enriched_text(item: dict[str, Any], spec: dict[str, Any] | None = None, collection: str = "", lookup_maps: tuple[dict[str, str], dict[str, str]] | None = None) -> str:
    label_map = {
        "events": "予定 出来事 カレンダー 打合せ 会議 面談",
        "deadlines": "期限 締切 期日 提出日",
        "jimu": "事務 行政 手続",
        "cases": "事案 調査 案件 対象者",
        "people": "人物 職員 関係者 担当",
        "career": "経歴 所属 異動 普通科 専科",
        # 作業は「期限」で探されることが多いため、期限語も検索語として含める。
        "tasks": "作業 タスク 期限 締切 期日 今日やる 待ち",
        "cycleTasks": "周期作業 繰り返し 作業 期限 次回 毎日 毎週 毎月 毎年",
    }
    parts = [stable_json(item), collection, label_map.get(collection, "")]
    people_map, case_map = lookup_maps if lookup_maps is not None else command_lookup_maps(spec)
    for pid in as_list(item.get("personIds")):
        hit = people_map.get(clean_text(pid))
        if hit:
            parts.append(hit)
    if clean_text(item.get("peopleText")):
        parts.append(clean_text(item.get("peopleText")))
    cid = clean_text(item.get("caseId"))
    if cid and case_map.get(cid):
        parts.append(case_map[cid])
    src = clean_text(item.get("source") or as_dict(item.get("sourceInfo")).get("ref") or as_dict(item.get("sourceInfo")).get("legacy"))
    if src:
        parts.append(src)
        bits = src.split(":")
        if len(bits) >= 3:
            src_type, src_id = bits[1], bits[2]
            if src_type in {"cases", "case-target"} and case_map.get(src_id):
                parts.append(case_map[src_id])
            elif spec and src_type in {"events", "deadlines", "jimu"}:
                for x in as_list(spec.get(src_type)):
                    if isinstance(x, dict) and clean_text(x.get("id")) == src_id:
                        parts.append(command_enriched_text(x, spec, src_type, lookup_maps)); break
    return " ".join(x for x in parts if x).lower()


def command_registration_payload(query: str) -> tuple[str, str]:
    parsed = parse_natural(query)
    title = strip_duration_noise(strip_priority_noise(strip_command_action_noise(parsed.get("title") or query))) or clean_text(parsed.get("title") or query)
    # 種類語が単独トークンとして真ん中に置かれた入力だけ落とす。
    # 「返却作業」「予定表確認」のようなタイトル中の語は残す。
    title = clean_text(re.sub(r"(^|[\s　,、。])(?:予定|出来事|できごと|期限|締切|期日|事務|作業|タスク|やること)(?=$|[\s　,、。])", " ", title)) or title
    parts = [parsed.get("date") or "", parsed.get("time") or "", title]
    payload_text = clean_text(" ".join(x for x in parts if x))
    return title, payload_text or query


def command_match_item(item: dict[str, Any], tokens: list[str], spec: dict[str, Any] | None = None, collection: str = "", lookup_maps: tuple[dict[str, str], dict[str, str]] | None = None) -> bool:
    if not tokens:
        return False
    hay = command_enriched_text(item, spec, collection, lookup_maps)
    return all(tok in hay for tok in tokens)


def command_title_text(item: dict[str, Any]) -> str:
    return clean_text(item.get("title") or item.get("name") or item.get("summary"))


def command_rank_due(item: dict[str, Any], collection: str = "") -> int:
    ds = clean_date(item.get("due") or item.get("nextRunDate") or item.get("date") or item.get("nextDate"))
    d = date_diff(ds)
    if d is None:
        return 99999
    if d < 0:
        return -3000 + d
    if d == 0:
        return -2000
    if d <= 7:
        return -1000 + d
    return d


def command_action_rank(item: dict[str, Any], tokens: list[str], action: str, collection: str = "") -> tuple[int, int, str]:
    target = clean_text(" ".join(tokens)).lower()
    title = command_title_text(item).lower()
    compact_target = re.sub(r"\s+", "", target)
    compact_title = re.sub(r"\s+", "", title)
    score = 0
    if compact_target and compact_title == compact_target:
        score -= 200
    elif compact_target and compact_title.startswith(compact_target):
        score -= 120
    elif compact_target and compact_target in compact_title:
        score -= 90
    elif tokens and all(tok in title for tok in tokens):
        score -= 60
    status = normalize_work_status(item.get("status"))
    if status == "today":
        score -= 18
    elif status == "waiting":
        score += 12
    if clean_text(item.get("priority")) == "high":
        score -= 10
    if action == "task_complete" and status == "done":
        score += 500
    if action.startswith("cycle_") and collection == "cycleTasks":
        state = clean_text(item.get("state") or item.get("status") or "active")
        if state == "active":
            score -= 8
        elif state == "paused" and action == "cycle_resume":
            score -= 25
    return (score, command_rank_due(item, collection), title)


def command_candidate_hint(item: dict[str, Any], collection: str = "") -> str:
    bits: list[str] = []
    status = normalize_work_status(item.get("status"))
    if collection == "cycleTasks":
        state = clean_text(item.get("state") or "active")
        if state == "paused": bits.append("休止中")
        elif state == "ended": bits.append("終了済み")
        else: bits.append("継続中")
        ds = clean_date(item.get("nextRunDate"))
        if ds: bits.append(f"次回 {ds}")
    else:
        if status == "today": bits.append("今日やる")
        elif status == "waiting": bits.append("待ち")
        ds = clean_date(item.get("due"))
        if ds: bits.append(f"期限 {ds}")
    if clean_text(item.get("priority")) == "high": bits.append("高優先")
    return " / ".join(bits[:3])


def command_join_hints(*values: str) -> str:
    out: list[str] = []
    for value in values:
        for part in clean_text(value).split(" / "):
            part = clean_text(part)
            if part and part not in out:
                out.append(part)
    return " / ".join(out[:4])


def command_match_hint(item: dict[str, Any], tokens: list[str]) -> str:
    target = clean_text(" ".join(tokens)).lower()
    title = command_title_text(item).lower()
    compact_target = re.sub(r"\s+", "", target)
    compact_title = re.sub(r"\s+", "", title)
    if compact_target and compact_title == compact_target:
        return "完全一致"
    if compact_target and compact_title.startswith(compact_target):
        return "先頭一致"
    if compact_target and compact_target in compact_title:
        return "タイトル一致"
    return ""


def command_search_hint(item: dict[str, Any], collection: str = "") -> str:
    bits: list[str] = []
    if collection == "cycleTasks":
        bits.append(command_candidate_hint(item, "cycleTasks"))
    elif collection == "tasks":
        bits.append(command_candidate_hint(item, "tasks"))
    else:
        ds = clean_date(item.get("date") or item.get("due") or item.get("nextDate") or item.get("startedAt"))
        if ds:
            bits.append(ds)
        if clean_text(item.get("priority")) == "high":
            bits.append("高優先")
        if clean_text(item.get("owner")):
            bits.append(f"担当 {clean_text(item.get('owner'))}")
        if clean_text(item.get("status")):
            bits.append(clean_text(item.get("status")))
    return command_join_hints(*bits)


def command_search_match_tokens(tokens: list[str], hay: str) -> bool:
    if not tokens:
        return False
    h = hay.lower() if isinstance(hay, str) else clean_text(hay).lower()
    return all(tok in h for tok in tokens)


def command_search_match(query: str, hay: str) -> bool:
    return command_search_match_tokens(command_split_tokens(query), hay)


def command_task_action_candidates(query: str, cont: dict[str, Any], spec: dict[str, Any] | None = None) -> list[dict[str, Any]]:
    intent = command_action_kind(query)
    if not intent:
        return []
    action, label, short = intent
    tokens = command_target_tokens(query)
    if not tokens:
        return []
    parsed = parse_natural(query)
    target_due = parsed.get("date") or ""
    if action == "task_due" and target_due == date_s():
        if "来週" in query:
            target_due = (today_date() + _dt.timedelta(days=7)).isoformat()
        elif any(w in query for w in ["明日", "あした", "明日に", "明日へ"]):
            target_due = (today_date() + _dt.timedelta(days=1)).isoformat()
        else:
            target_due = (today_date() + _dt.timedelta(days=1)).isoformat()
    out: list[dict[str, Any]] = []
    lookup_maps = command_lookup_maps(spec)
    if action.startswith("cycle_"):
        allowed_state = {
            "cycle_skip": {"active", "next", "today", ""},
            "cycle_pause": {"active", "next", "today", ""},
            "cycle_resume": {"paused", "waiting"},
            "cycle_end": {"active", "next", "today", "paused", "waiting", ""},
        }.get(action, {"active", "next", "today", ""})
        cycle_matches: list[dict[str, Any]] = []
        for item in as_list(cont.get("cycleTasks")):
            if not isinstance(item, dict) or not command_match_item(item, tokens, spec, "cycleTasks", lookup_maps):
                continue
            state = clean_text(item.get("state") or item.get("status") or "active")
            if state == "ended" or normalize_work_status(item.get("status")) == "done":
                if action != "cycle_resume":
                    continue
            if state not in allowed_state and not (action == "cycle_end" and state != "ended"):
                continue
            cycle_matches.append(item)
        cycle_matches.sort(key=lambda item: command_action_rank(item, tokens, action, "cycleTasks"))
        for item in cycle_matches[:10]:
            title = clean_text(item.get("title")) or "無題の周期作業"
            out.append({"id": f"action:{action}:{item.get('id')}", "title": f"周期作業を{label}: {title}", "kind": "実行候補", "hint": command_join_hints(command_match_hint(item, tokens), command_candidate_hint(item, "cycleTasks")), "action": action, "actionLabel": short, "canExecute": True, "payload": {"cycleId": item.get("id"), "baseItemUpdatedAt": item.get("updatedAt")}})
        return out
    task_matches: list[dict[str, Any]] = []
    for item in as_list(cont.get("tasks")):
        if not isinstance(item, dict) or not command_match_item(item, tokens, spec, "tasks", lookup_maps):
            continue
        if normalize_work_status(item.get("status")) == "done" and action == "task_complete":
            continue
        task_matches.append(item)
    task_matches.sort(key=lambda item: command_action_rank(item, tokens, action, "tasks"))
    for item in task_matches[:8]:
        title = clean_text(item.get("title")) or "無題の作業"
        payload = {"taskId": item.get("id")}
        if action == "task_due":
            payload["due"] = target_due
        meta = f"{title}" + (f" / {target_due}" if action == "task_due" and target_due else "")
        action_title = f"作業の期限を変更: {meta}" if action == "task_due" else f"作業を{label}: {meta}"
        out.append({"id": f"action:{action}:{item.get('id')}", "title": action_title, "kind": "実行候補", "hint": command_join_hints(command_match_hint(item, tokens), command_candidate_hint(item, "tasks")), "action": action, "actionLabel": short, "canExecute": True, "payload": payload})
    if action == "task_complete":
        cycle_matches = []
        for item in as_list(cont.get("cycleTasks")):
            if not isinstance(item, dict) or not command_match_item(item, tokens, spec, "cycleTasks", lookup_maps):
                continue
            state = clean_text(item.get("state") or item.get("status") or "active")
            if state in {"paused", "ended"} or normalize_work_status(item.get("status")) == "done":
                continue
            cycle_matches.append(item)
        cycle_matches.sort(key=lambda item: command_action_rank(item, tokens, "cycle_complete", "cycleTasks"))
        for item in cycle_matches[:max(0, 10 - len(out))]:
            title = clean_text(item.get("title")) or "無題の周期作業"
            out.append({"id": f"action:cycle_complete:{item.get('id')}", "title": f"周期作業を今回完了: {title}", "kind": "実行候補", "hint": command_join_hints(command_match_hint(item, tokens), command_candidate_hint(item, "cycleTasks")), "action": "cycle_complete", "actionLabel": "今回完了", "canExecute": True, "payload": {"cycleId": item.get("id"), "baseItemUpdatedAt": item.get("updatedAt")}})
    return out


def command_update_task(action: str, candidate: dict[str, Any]) -> dict[str, Any]:
    payload = as_dict(candidate.get("payload"))
    task_id = clean_text(payload.get("taskId") or candidate.get("taskId"))
    if not task_id:
        raise ValueError("対象の作業を選び直してください。")
    with SAVE_RECORD_LOCK:
        cont = _copy_continuum_for_write(as_dict(load_record("continuum", clone=False).get("data")))
        found = None
        for i, item in enumerate(cont["tasks"]):
            if item.get("id") == task_id:
                found = dict(item)
                cont["tasks"][i] = found
                break
        if not found:
            raise ValueError("対象の作業が見つかりません。")
        if action == "task_complete":
            found["status"] = "done"; found["completedAt"] = date_s()
        elif action == "task_waiting":
            found["status"] = "waiting"; found.pop("completedAt", None)
        elif action == "task_today":
            found["status"] = "today"; found.pop("completedAt", None)
        elif action == "task_due":
            due = clean_date(payload.get("due"))
            if not due:
                raise ValueError("変更後の期限を読み取れませんでした。")
            found["due"] = due
        elif action == "task_priority_high":
            found["priority"] = "high"
        elif action == "task_priority_normal":
            found["priority"] = "normal"
        elif action == "task_priority_low":
            found["priority"] = "low"
        else:
            raise ValueError("実行対象を選び直してください。")
        found["updatedAt"] = iso_now()
        saved = save_record("continuum", cont, already_normalised=True, backup_policy="auto")
        return {"ok": True, "action": action, "item": found, "hash": saved["hash"], "updatedAt": saved.get("updatedAt")}


def command_cycle_action(action: str, candidate: dict[str, Any]) -> dict[str, Any]:
    payload = as_dict(candidate.get("payload"))
    cycle_id = clean_text(payload.get("cycleId") or candidate.get("cycleId") or payload.get("id") or candidate.get("id"))
    expected_item_updated_at = clean_text(payload.get("baseItemUpdatedAt") or candidate.get("baseItemUpdatedAt"))
    if not cycle_id:
        raise ValueError("対象の周期作業を選び直してください。")
    if not expected_item_updated_at:
        # 完了・見送りは同じ要求を二度処理すると次回日が二回進む。
        # そのため、候補を作った時点の世代は全操作で必須とする。
        raise ValueError("周期作業の更新情報がありません。画面を読み込み直して、もう一度実行してください。")
    action_name = action.replace("cycle_", "")
    with SAVE_RECORD_LOCK:
        record = load_record("continuum", clone=False)
        cont = _copy_continuum_for_write(as_dict(record.get("data")))
        found = None
        for i, item in enumerate(cont["cycleTasks"]):
            if item.get("id") != cycle_id:
                continue
            current_item_updated_at = clean_text(item.get("updatedAt"))
            if current_item_updated_at != expected_item_updated_at:
                raise SaveConflictError("continuum", "main", expected_item_updated_at, current_item_updated_at, clean_text(record.get("updatedAt")))
            if action_name == "complete":
                found = advance_cycle(item, clean_date(payload.get("doneDate")) or date_s())
                found["state"] = "active"
            elif action_name == "skip":
                found = advance_cycle(item, clean_date(payload.get("doneDate")) or item.get("nextRunDate") or date_s())
                found["state"] = "active"
            elif action_name == "pause":
                found = dict(item); found["state"] = "paused"; found["status"] = "waiting"; found["pausedAt"] = date_s(); found["endedAt"] = ""; found["completedAt"] = ""; found["updatedAt"] = iso_now()
            elif action_name == "resume":
                found = dict(item); found["state"] = "active"; found["status"] = "next"; found["pausedAt"] = ""; found["endedAt"] = ""; found["completedAt"] = ""; found["updatedAt"] = iso_now()
            elif action_name == "end":
                found = dict(item); found["state"] = "ended"; found["status"] = "done"; found["endedAt"] = date_s(); found["completedAt"] = date_s(); found["updatedAt"] = iso_now()
            else:
                raise ValueError("周期作業の操作を選び直してください。")
            found["history"] = copy.deepcopy(as_list(found.get("history")))
            found["history"].append({"action": action_name, "date": clean_date(payload.get("doneDate")) or date_s(), "at": iso_now()})
            cont["cycleTasks"][i] = found
            break
        if not found:
            raise ValueError("周期作業が見つかりません。")
        saved = save_record("continuum", cont, already_normalised=True, backup_policy="auto")
        return {"ok": True, "action": action, "item": found, "hash": saved["hash"], "updatedAt": saved.get("updatedAt")}


def command_complete_cycle(candidate: dict[str, Any]) -> dict[str, Any]:
    return command_cycle_action("cycle_complete", candidate)


def command_display_target(query: str, remove_words: list[str] | None = None) -> str:
    parsed = parse_natural(query)
    target = strip_duration_noise(strip_priority_noise(strip_command_action_noise(parsed.get("title") or query)))
    for word in remove_words or []:
        target = re.sub(re.escape(word), " ", target, flags=re.I)
    target = clean_text(target)
    target = clean_text(re.sub(r"(?:と|を|に|へ|で|の)$", "", target)) if len(target) >= 2 else target
    return target or clean_text(parsed.get("title") or query) or clean_text(query)


def command_contextual_candidates(query: str, search_hits: int = 0) -> list[dict[str, Any]]:
    """画面ランチャーに流れる前に、入力の意図に近い検索・関係ビュー候補を補う。

    実行対象や登録候補が作れる場合はそちらが上位になる。ここでは、
    「山田 期限」「A事案 関係」「山田 次回なし」のように、保存せず探したい入力を拾う。
    """
    q = clean_text(query)
    if not q:
        return []
    if any(w in q for w in ["今日を組む", "朝の整理", "今日の整理", "今日を閉じる", "終業", "締め"]):
        return []
    out: list[dict[str, Any]] = []
    low = q.lower()
    def add(id_: str, title: str, href: str, hint: str, label: str = "探す") -> None:
        out.append({"id": id_, "title": title, "kind": "検索結果", "href": href, "hint": hint, "actionLabel": label, "canExecute": True, "action": "open"})

    relation_words = ["関係", "関連", "つながり", "紐づき"]
    if any(w in q for w in relation_words):
        target = command_display_target(q, relation_words + ["を見る", "見たい"])
        if any(w in q for w in ["人物", "人", "職員", "同僚"]):
            add("context:person_relation", f"人物の関係を見る: {target}", "/speculum#people", "人物カードから予定・期限・作業・経歴を確認します", "見る")
        elif any(w in q for w in ["事案", "調査", "案件"]):
            add("context:case_relation", f"事案の関係を見る: {target}", "/speculum#cases", "事案カードから対象者・予定・期限・作業を確認します", "見る")
        else:
            add("context:relation_case", f"関係ビューを探す: {target}", "/speculum#cases", "事案・人物の関係カードを確認します", "見る")
            add("context:relation_person", f"人物側の関係も探す: {target}", "/speculum#people", "人物に紐づく予定・期限・作業・経歴を確認します", "見る")

    intent = command_action_kind(q)
    if intent:
        action, label, short = intent
        target = command_display_target(q, [short, label, "する", "して", "にする", "へ", "を"])
        add("context:action_search", f"実行対象を作業管理で探す: {target}", "/continuum", f"{label}候補が出ない場合は、作業管理で対象を確認します")

    if any(w in q for w in ["次回なし", "次回未定", "次回がない", "次回無し"]):
        target = command_display_target(q, ["次回なし", "次回未定", "次回がない", "次回無し", "事案", "調査"])
        add("context:case_no_next", f"次回予定なしの事案を探す: {target}", "/speculum#cases", "事案台帳の次回予定なし・要確認サマリで確認します")

    if any(w in q for w in ["期限", "締切", "期日", "提出日"]):
        target = command_display_target(q, ["期限", "締切", "期日", "提出日", "を", "探す", "検索"])
        add("context:deadline_search", f"期限・事務を検索: {target}", "/speculum#tasks", "台帳で元情報を確認し、必要なら作業に追加します")

    if any(w in q for w in ["今日やる", "今日へ", "今日に", "作業", "タスク", "待ち"]):
        target = command_display_target(q, ["今日やる", "今日へ", "今日に", "作業", "タスク", "待ち", "を", "探す", "検索"])
        add("context:work_search", f"作業管理で探す: {target}", "/continuum", "今日へ移動・待ち・完了などの処理候補を確認します")

    if re.search(r"\d{1,2}:\d{2}|\d{1,2}時", q) or any(w in q for w in ["朝一", "正午", "昼一", "夕方", "予定", "打合せ", "打ち合わせ", "会議", "面談", "日付", "カレンダー"]):
        target = command_display_target(q, ["予定", "打合せ", "打ち合わせ", "会議", "面談", "日付", "カレンダー", "を", "探す", "検索"])
        add("context:schedule_search", f"日付確認で探す: {target}", "/speculum#schedule", "予定・出来事・期限・作業を日付で確認します")

    if search_hits:
        # 実データ一致がある場合は補助候補を絞り、検索結果そのものを主役にする。
        return out[:2]
    return out[:4]



COMMAND_SEARCH_CACHE: dict[tuple[str, str], list[dict[str, Any]]] = {}
COMMAND_SEARCH_CACHE_LOCK = threading.Lock()
COMMAND_SEARCH_WARMING: set[tuple[str, str]] = set()


def command_search_cache_key(spec_record: dict[str, Any], cont_record: dict[str, Any]) -> tuple[str, str]:
    spec_hash = clean_text(spec_record.get("hash"))
    cont_hash = clean_text(cont_record.get("hash"))
    if not spec_hash:
        spec_hash = text_hash(stable_json(as_dict(spec_record.get("data"))))
    if not cont_hash:
        cont_hash = text_hash(stable_json(as_dict(cont_record.get("data"))))
    return spec_hash, cont_hash



def command_candidate_href(app: str, view: str, title: str, item_id: Any = "") -> str:
    """吹き出し検索結果から該当画面の検索欄とカードへ直行する URL を作る。"""
    q = quote(clean_text(title), safe="")
    focus = quote(clean_text(item_id), safe="")
    params = []
    if q:
        params.append(f"q={q}")
    if focus:
        params.append(f"focus={focus}")
    if app == "continuum":
        return "/continuum" + (("#" + "&".join(params)) if params else "")
    route = clean_text(view) or "today"
    return f"/speculum#{route}" + (("?" + "&".join(params)) if params else "")


def command_build_search_index(spec: dict[str, Any], cont: dict[str, Any]) -> list[dict[str, Any]]:
    """吹き出し候補用の検索文字列を保存データごとに一度だけ作る。"""
    lookup_maps = command_lookup_maps(spec)
    index: list[dict[str, Any]] = []
    for collection, label, view in [("events", "予定", "schedule"), ("deadlines", "期限", "tasks"), ("jimu", "事務", "tasks"), ("cases", "事案", "cases"), ("people", "人物", "people"), ("career", "経歴", "career")]:
        for item in as_list(spec.get(collection)):
            if not isinstance(item, dict):
                continue
            # 完了済みの期限・事務は保存したまま通常検索から外す。検索語に
            # 「完了」を含めても台帳へ再露出させず、必要な履歴確認は日付確認の
            # 「完了済みも表示」という明示操作に限定する。
            if collection in {"deadlines", "jimu"} and record_is_done(item):
                continue
            hay = command_enriched_text(item, spec, collection, lookup_maps)
            item_label = "出来事" if collection == "events" and clean_text(item.get("calendarKind")) == "happening" else label
            title = clean_text(item.get("title") or item.get("name") or case_target_names(item))
            index.append({
                "hay": hay,
                "item": item,
                "collection": collection,
                "scope": "speculum",
                "titleText": title,
                "titleLower": title.lower(),
                "compactTitle": re.sub(r"\s+", "", title.lower()),
                "statusNorm": normalize_work_status(item.get("status")),
                "priority": clean_text(item.get("priority")),
                "state": clean_text(item.get("state") or item.get("status") or ""),
                "dueRank": command_rank_due(item, collection),
                "candidate": {"id": f"speculum:{collection}:{item.get('id')}", "title": f"{item_label}: {title}", "kind": item_label, "hint": command_search_hint(item, collection), "href": command_candidate_href("speculum", view, title, item.get("id")), "actionLabel": "開く", "canExecute": True, "action": "open"},
            })
    for collection, label in [("tasks", "作業"), ("cycleTasks", "周期作業")]:
        for item in as_list(cont.get(collection)):
            if not isinstance(item, dict):
                continue
            hay = command_enriched_text(item, spec, collection, lookup_maps)
            title = clean_text(item.get('title'))
            index.append({
                "hay": hay,
                "item": item,
                "collection": collection,
                "scope": "continuum",
                "titleText": title,
                "titleLower": title.lower(),
                "compactTitle": re.sub(r"\s+", "", title.lower()),
                "statusNorm": normalize_work_status(item.get("status")),
                "priority": clean_text(item.get("priority")),
                "state": clean_text(item.get("state") or item.get("status") or "active"),
                "dueRank": command_rank_due(item, collection),
                "candidate": {"id": f"continuum:{collection}:{item.get('id')}", "title": f"{label}: {title}", "kind": label, "hint": command_search_hint(item, collection), "href": command_candidate_href("continuum", "", title, item.get("id")), "actionLabel": "開く", "canExecute": True, "action": "open"},
            })
    return index


def command_search_index(spec_record: dict[str, Any], cont_record: dict[str, Any]) -> list[dict[str, Any]]:
    key = command_search_cache_key(spec_record, cont_record)
    with COMMAND_SEARCH_CACHE_LOCK:
        cached = COMMAND_SEARCH_CACHE.get(key)
    if cached is not None:
        return cached
    built = command_build_search_index(as_dict(spec_record.get("data")), as_dict(cont_record.get("data")))
    with COMMAND_SEARCH_CACHE_LOCK:
        if len(COMMAND_SEARCH_CACHE) >= 4:
            COMMAND_SEARCH_CACHE.clear()
        COMMAND_SEARCH_CACHE[key] = built
    return built


def command_action_rank_from_index(rec: dict[str, Any], tokens: list[str], action: str, compact_target: str, target: str) -> tuple[int, int, str]:
    title = clean_text(rec.get("titleLower"))
    compact_title = clean_text(rec.get("compactTitle"))
    score = 0
    if compact_target and compact_title == compact_target:
        score -= 200
    elif compact_target and compact_title.startswith(compact_target):
        score -= 120
    elif compact_target and compact_target in compact_title:
        score -= 90
    elif tokens and all(tok in title for tok in tokens):
        score -= 60
    status = clean_text(rec.get("statusNorm"))
    if status == "today":
        score -= 18
    elif status == "waiting":
        score += 12
    if clean_text(rec.get("priority")) == "high":
        score -= 10
    if action == "task_complete" and status == "done":
        score += 500
    if action.startswith("cycle_"):
        state = clean_text(rec.get("state") or "active")
        if state == "active":
            score -= 8
        elif state == "paused" and action == "cycle_resume":
            score -= 25
    try:
        due_rank = int(rec.get("dueRank"))
    except Exception:
        due_rank = 99999
    return (score, due_rank, title)


def command_task_action_candidates_from_index(query: str, index: list[dict[str, Any]]) -> list[dict[str, Any]]:
    intent = command_action_kind(query)
    if not intent:
        return []
    action, label, short = intent
    tokens = command_target_tokens(query)
    if not tokens:
        return []
    target = clean_text(" ".join(tokens)).lower()
    compact_target = re.sub(r"\s+", "", target)
    parsed = parse_natural(query)
    target_due = parsed.get("date") or ""
    if action == "task_due" and target_due == date_s():
        if "来週" in query:
            target_due = (today_date() + _dt.timedelta(days=7)).isoformat()
        elif any(w in query for w in ["明日", "あした", "明日に", "明日へ"]):
            target_due = (today_date() + _dt.timedelta(days=1)).isoformat()
        else:
            target_due = (today_date() + _dt.timedelta(days=1)).isoformat()

    out: list[dict[str, Any]] = []
    if action.startswith("cycle_"):
        allowed_state = {
            "cycle_skip": {"active", "next", "today", ""},
            "cycle_pause": {"active", "next", "today", ""},
            "cycle_resume": {"paused", "waiting"},
            "cycle_end": {"active", "next", "today", "paused", "waiting", ""},
        }.get(action, {"active", "next", "today", ""})
        matches: list[dict[str, Any]] = []
        for rec in index:
            if clean_text(rec.get("collection")) != "cycleTasks" or not command_search_match_tokens(tokens, rec.get("hay", "")):
                continue
            state = clean_text(rec.get("state") or "active")
            status = clean_text(rec.get("statusNorm"))
            if state == "ended" or status == "done":
                if action != "cycle_resume":
                    continue
            if state not in allowed_state and not (action == "cycle_end" and state != "ended"):
                continue
            matches.append(rec)
        matches.sort(key=lambda rec: command_action_rank_from_index(rec, tokens, action, compact_target, target))
        for rec in matches[:10]:
            item = as_dict(rec.get("item"))
            title = clean_text(item.get("title")) or clean_text(rec.get("titleText")) or "無題の周期作業"
            out.append({"id": f"action:{action}:{item.get('id')}", "title": f"周期作業を{label}: {title}", "kind": "実行候補", "hint": command_join_hints(command_match_hint(item, tokens), command_candidate_hint(item, "cycleTasks")), "action": action, "actionLabel": short, "canExecute": True, "payload": {"cycleId": item.get("id"), "baseItemUpdatedAt": item.get("updatedAt")}})
        return out

    matches: list[dict[str, Any]] = []
    for rec in index:
        if clean_text(rec.get("collection")) != "tasks" or not command_search_match_tokens(tokens, rec.get("hay", "")):
            continue
        if clean_text(rec.get("statusNorm")) == "done" and action == "task_complete":
            continue
        matches.append(rec)
    matches.sort(key=lambda rec: command_action_rank_from_index(rec, tokens, action, compact_target, target))
    for rec in matches[:8]:
        item = as_dict(rec.get("item"))
        title = clean_text(item.get("title")) or clean_text(rec.get("titleText")) or "無題の作業"
        payload = {"taskId": item.get("id")}
        if action == "task_due":
            payload["due"] = target_due
        meta = f"{title}" + (f" / {target_due}" if action == "task_due" and target_due else "")
        action_title = f"作業の期限を変更: {meta}" if action == "task_due" else f"作業を{label}: {meta}"
        out.append({"id": f"action:{action}:{item.get('id')}", "title": action_title, "kind": "実行候補", "hint": command_join_hints(command_match_hint(item, tokens), command_candidate_hint(item, "tasks")), "action": action, "actionLabel": short, "canExecute": True, "payload": payload})

    if action == "task_complete":
        cycle_matches: list[dict[str, Any]] = []
        for rec in index:
            if clean_text(rec.get("collection")) != "cycleTasks" or not command_search_match_tokens(tokens, rec.get("hay", "")):
                continue
            state = clean_text(rec.get("state") or "active")
            status = clean_text(rec.get("statusNorm"))
            if state in {"paused", "ended"} or status == "done":
                continue
            cycle_matches.append(rec)
        cycle_matches.sort(key=lambda rec: command_action_rank_from_index(rec, tokens, "cycle_complete", compact_target, target))
        for rec in cycle_matches[:max(0, 10 - len(out))]:
            item = as_dict(rec.get("item"))
            title = clean_text(item.get("title")) or clean_text(rec.get("titleText")) or "無題の周期作業"
            out.append({"id": f"action:cycle_complete:{item.get('id')}", "title": f"周期作業を今回完了: {title}", "kind": "実行候補", "hint": command_join_hints(command_match_hint(item, tokens), command_candidate_hint(item, "cycleTasks")), "action": "cycle_complete", "actionLabel": "今回完了", "canExecute": True, "payload": {"cycleId": item.get("id"), "baseItemUpdatedAt": item.get("updatedAt")}})
    return out


def command_preload_search_index(spec_record: dict[str, Any], cont_record: dict[str, Any]) -> None:
    key = command_search_cache_key(spec_record, cont_record)
    with COMMAND_SEARCH_CACHE_LOCK:
        if key in COMMAND_SEARCH_CACHE or key in COMMAND_SEARCH_WARMING:
            return
        COMMAND_SEARCH_WARMING.add(key)

    def worker() -> None:
        try:
            command_search_index(spec_record, cont_record)
        finally:
            with COMMAND_SEARCH_CACHE_LOCK:
                COMMAND_SEARCH_WARMING.discard(key)

    threading.Thread(target=worker, name="blackcat-command-index", daemon=True).start()


def command_record_action_rank(rec: dict[str, Any], tokens: list[str], action: str, collection: str = "") -> tuple[int, int, str]:
    target = clean_text(" ".join(tokens)).lower()
    compact_target = re.sub(r"\s+", "", target)
    title = clean_text(rec.get("titleLower"))
    compact_title = clean_text(rec.get("compactTitle"))
    score = 0
    if compact_target and compact_title == compact_target:
        score -= 200
    elif compact_target and compact_title.startswith(compact_target):
        score -= 120
    elif compact_target and compact_target in compact_title:
        score -= 90
    elif tokens and all(tok in title for tok in tokens):
        score -= 60
    status = clean_text(rec.get("statusNorm"))
    if status == "today":
        score -= 18
    elif status == "waiting":
        score += 12
    if clean_text(rec.get("priority")) == "high":
        score -= 10
    if action == "task_complete" and status == "done":
        score += 500
    if action.startswith("cycle_") and collection == "cycleTasks":
        state = clean_text(rec.get("state") or "active")
        if state == "active":
            score -= 8
        elif state == "paused" and action == "cycle_resume":
            score -= 25
    return (score, int(rec.get("dueRank") or 99999), title)


def command_task_action_candidates_indexed(query: str, index: list[dict[str, Any]]) -> list[dict[str, Any]]:
    intent = command_action_kind(query)
    if not intent:
        return []
    action, label, short = intent
    tokens = command_target_tokens(query)
    if not tokens:
        return []
    parsed = parse_natural(query)
    target_due = parsed.get("date") or ""
    if action == "task_due" and target_due == date_s():
        if "来週" in query:
            target_due = (today_date() + _dt.timedelta(days=7)).isoformat()
        elif any(w in query for w in ["明日", "あした", "明日に", "明日へ"]):
            target_due = (today_date() + _dt.timedelta(days=1)).isoformat()
        else:
            target_due = (today_date() + _dt.timedelta(days=1)).isoformat()

    def matching_records(collection: str) -> list[dict[str, Any]]:
        out: list[dict[str, Any]] = []
        for rec in index:
            if clean_text(rec.get("collection")) != collection:
                continue
            if command_search_match_tokens(tokens, rec.get("hay", "")):
                out.append(rec)
        return out

    out: list[dict[str, Any]] = []
    if action.startswith("cycle_"):
        allowed_state = {
            "cycle_skip": {"active", "next", "today", ""},
            "cycle_pause": {"active", "next", "today", ""},
            "cycle_resume": {"paused", "waiting"},
            "cycle_end": {"active", "next", "today", "paused", "waiting", ""},
        }.get(action, {"active", "next", "today", ""})
        cycle_matches: list[dict[str, Any]] = []
        for rec in matching_records("cycleTasks"):
            item = as_dict(rec.get("item"))
            state = clean_text(item.get("state") or item.get("status") or "active")
            if state == "ended" or normalize_work_status(item.get("status")) == "done":
                if action != "cycle_resume":
                    continue
            if state not in allowed_state and not (action == "cycle_end" and state != "ended"):
                continue
            cycle_matches.append(rec)
        cycle_matches.sort(key=lambda rec: command_record_action_rank(rec, tokens, action, "cycleTasks"))
        for rec in cycle_matches[:10]:
            item = as_dict(rec.get("item"))
            title = clean_text(item.get("title")) or "無題の周期作業"
            out.append({"id": f"action:{action}:{item.get('id')}", "title": f"周期作業を{label}: {title}", "kind": "実行候補", "hint": command_join_hints(command_match_hint(item, tokens), command_candidate_hint(item, "cycleTasks")), "action": action, "actionLabel": short, "canExecute": True, "payload": {"cycleId": item.get("id"), "baseItemUpdatedAt": item.get("updatedAt")}})
        return out

    task_matches: list[dict[str, Any]] = []
    for rec in matching_records("tasks"):
        item = as_dict(rec.get("item"))
        if normalize_work_status(item.get("status")) == "done" and action == "task_complete":
            continue
        task_matches.append(rec)
    task_matches.sort(key=lambda rec: command_record_action_rank(rec, tokens, action, "tasks"))
    for rec in task_matches[:8]:
        item = as_dict(rec.get("item"))
        title = clean_text(item.get("title")) or "無題の作業"
        payload = {"taskId": item.get("id")}
        if action == "task_due":
            payload["due"] = target_due
        meta = f"{title}" + (f" / {target_due}" if action == "task_due" and target_due else "")
        action_title = f"作業の期限を変更: {meta}" if action == "task_due" else f"作業を{label}: {meta}"
        out.append({"id": f"action:{action}:{item.get('id')}", "title": action_title, "kind": "実行候補", "hint": command_join_hints(command_match_hint(item, tokens), command_candidate_hint(item, "tasks")), "action": action, "actionLabel": short, "canExecute": True, "payload": payload})

    if action == "task_complete":
        cycle_matches: list[dict[str, Any]] = []
        for rec in matching_records("cycleTasks"):
            item = as_dict(rec.get("item"))
            state = clean_text(item.get("state") or item.get("status") or "active")
            if state in {"paused", "ended"} or normalize_work_status(item.get("status")) == "done":
                continue
            cycle_matches.append(rec)
        cycle_matches.sort(key=lambda rec: command_record_action_rank(rec, tokens, "cycle_complete", "cycleTasks"))
        for rec in cycle_matches[:max(0, 10 - len(out))]:
            item = as_dict(rec.get("item"))
            title = clean_text(item.get("title")) or "無題の周期作業"
            out.append({"id": f"action:cycle_complete:{item.get('id')}", "title": f"周期作業を今回完了: {title}", "kind": "実行候補", "hint": command_join_hints(command_match_hint(item, tokens), command_candidate_hint(item, "cycleTasks")), "action": "cycle_complete", "actionLabel": "今回完了", "canExecute": True, "payload": {"cycleId": item.get("id"), "baseItemUpdatedAt": item.get("updatedAt")}})
    return out

def command_result_rank(query: str, item: dict[str, Any], seq: int) -> tuple[int, int]:
    q = clean_text(query)
    kind = clean_text(item.get("kind"))
    id_ = clean_text(item.get("id"))
    if q and id_ == "open:today-ritual":
        return (-20, seq)
    if not q:
        # 空欄ではランチャーとして、今日→日付→作業の順を保つ。
        empty_order = {"open:today": 0, "open:schedule": 1, "open:work": 2, "open:cases": 3, "open:people": 4, "open:career": 5}
        return (empty_order.get(id_, 40), seq)
    kind_order = {
        "実行候補": 0,
        "登録候補": 10,
        "検索結果": 20,
        "作業": 30,
        "周期作業": 31,
        "期限": 32,
        "事務": 33,
        "予定": 34,
        "出来事": 35,
        "事案": 36,
        "人物": 37,
        "経歴": 38,
        "ローカルツール": 45,
        "画面": 60,
    }
    rank = kind_order.get(kind, 50)
    # 氏名・事案名・予定名をそのまま入力した時は、関連する作業より本人の
    # 完全一致カードを先にする。吹き出しからEnter一回で目的へ直行できる。
    display_title = clean_text(item.get("title"))
    if ":" in display_title or "：" in display_title:
        display_title = re.split(r"[:：]", display_title, maxsplit=1)[-1]
    compact_query = re.sub(r"\s+", "", q).lower()
    compact_title = re.sub(r"\s+", "", display_title).lower()
    if compact_query and compact_title == compact_query and kind in {"作業", "周期作業", "期限", "事務", "予定", "出来事", "事案", "人物", "経歴"}:
        rank = 12
    if kind == "画面" and any(w in q for w in ["開く", "ひらく", "画面", "タブ", "司令塔", "作業管理", "日付確認", "カレンダー", "事案台帳", "人物管理", "経歴"]):
        rank = 15
    if kind == "ローカルツール" and any(w in q.lower() for w in ["tool", "ツール", "起動", "ローカル"]):
        rank = 8
    return (rank, seq)


def command_candidates(q: str) -> list[dict[str, Any]]:
    query = clean_text(q)
    low = query.lower()
    registration_error = natural_datetime_validation_error(query)
    candidate_priority = infer_priority(query, {})
    results: list[dict[str, Any]] = []

    def add_nav(id_: str, title: str, href: str, words: list[str], label: str = "開く") -> None:
        if not query or any(w in low for w in words):
            results.append({"id": id_, "title": title, "kind": "画面", "href": href, "actionLabel": label, "canExecute": True, "action": "open"})

    spec_record = load_record("speculum", clone=False)
    cont_record = load_record("continuum", clone=False)
    if not query:
        command_preload_search_index(spec_record, cont_record)
    spec = spec_record["data"]
    cont = cont_record["data"]
    search_index = command_search_index(spec_record, cont_record) if query else []
    action_hits = command_task_action_candidates_indexed(query, search_index) if query else []
    if action_hits:
        results.extend(action_hits)

    search_hits = 0
    if query:
        search_tokens = command_split_tokens(query)
        for entry in search_index:
            if command_search_match_tokens(search_tokens, entry.get("hay", "")):
                results.append(dict(as_dict(entry.get("candidate"))))
                search_hits += 1
                if search_hits >= 40:
                    break

    # 画面遷移だけに落ちる前に、検索・関係ビューの意図を補助候補として出す。
    contextual = command_contextual_candidates(query, search_hits) if query and not action_hits else []
    if contextual:
        results.extend(contextual)

    classified = classify_command(query)
    if classified and not registration_error:
        action, label = classified
        parsed = parse_natural(query)
        detail_date = parsed.get("date") or ""
        detail_time = parsed.get("time") or ""
        detail_when = clean_text(" ".join(x for x in [detail_date, detail_time] if x))
        estimate = parse_duration_minutes(query, {})
        duration = format_duration_minutes(estimate)
        base_detail = f"{parsed.get('title') or query}" + (f" / {detail_when}" if detail_when else "")
        if duration and action in {"quick_task"}:
            detail = base_detail + f" / 見積{duration}"
        elif duration and action in {"quick_event", "quick_happening"}:
            detail = base_detail + f" / 所要{duration}"
        else:
            detail = base_detail
        payload = {"text": query, "priority": candidate_priority}
        if estimate and action == "quick_task":
            payload["estimateMinutes"] = estimate
        if action == "quick_task":
            payload["status"] = infer_task_status_from_text(query, {})
        results.append({"id": "quick:" + action, "title": f"{label}: {detail}", "kind": "登録候補", "hint": "候補を選ぶまで保存しません", "action": action, "actionLabel": "追加", "canExecute": True, "payload": payload})
        if action != "quick_cycle" and any(w in query for w in ["毎日", "毎週", "毎月", "毎年", "周期", "サイクル"]):
            results.append({"id": "quick:cycle", "title": f"周期作業として追加: {detail}", "kind": "登録候補", "hint": "繰り返し作業として扱います", "action": "quick_cycle", "actionLabel": "周期追加", "canExecute": True, "payload": {"text": query, "priority": candidate_priority}})
    elif query and not registration_error and not action_hits and command_registration_context(query):
        parsed = parse_natural(query)
        display_title, payload_text = command_registration_payload(query)
        is_periodic = is_periodic_command_text(query)
        if is_periodic:
            cycle_detail = clean_cycle_title(query, parsed.get('title') or display_title or query)
            results.append({"id": "quick:cycle", "title": f"周期作業として追加: {cycle_detail}", "kind": "登録候補", "hint": "候補を選ぶまで保存しません", "action": "quick_cycle", "actionLabel": "周期追加", "canExecute": True, "payload": {"text": query, "priority": candidate_priority}})
        else:
            detail_date = parsed.get("date") or ""
            detail_time = parsed.get("time") or ""
            detail_when = clean_text(" ".join(x for x in [detail_date, detail_time] if x))
            estimate = parse_duration_minutes(query, {})
            duration = format_duration_minutes(estimate)
            base_detail = f"{display_title or parsed.get('title') or query}" + (f" / {detail_when}" if detail_when else "")
            task_detail = base_detail + (f" / 見積{duration}" if duration else "")
            event_detail = base_detail + (f" / 所要{duration}" if duration else "")
            task_payload = {"text": payload_text, "priority": candidate_priority, "status": infer_task_status_from_text(query, {})}
            if estimate:
                task_payload["estimateMinutes"] = estimate
            deadline_hint = any(w in query for w in ["期限", "締切", "期日", "提出日", "まで"])
            jimu_hint = "事務" in query
            happening_hint = "出来事" in query or "できごと" in query
            task_hint = has_task_intent_text(query)
            if parsed.get("time") or any(w in query for w in ["朝一", "正午", "昼一", "夕方", "予定", "打合せ", "打ち合わせ", "会議", "面談"]):
                action = "quick_happening" if happening_hint else "quick_event"
                label = "出来事として追加" if happening_hint else "予定として追加"
                results.append({"id": "quick:implicit_event", "title": f"{label}: {event_detail}", "kind": "登録候補", "hint": "候補を選ぶまで保存しません", "action": action, "actionLabel": "予定追加" if action == "quick_event" else "出来事追加", "canExecute": True, "payload": task_payload})
            elif jimu_hint:
                results.append({"id": "quick:implicit_jimu", "title": f"事務として追加: {base_detail}", "kind": "登録候補", "hint": "候補を選ぶまで保存しません", "action": "quick_jimu", "actionLabel": "事務追加", "canExecute": True, "payload": task_payload})
                results.append({"id": "quick:implicit_task", "title": f"作業として追加: {task_detail}", "kind": "登録候補", "hint": "必要なら通常作業にします", "action": "quick_task", "actionLabel": "作業追加", "canExecute": True, "payload": task_payload})
            elif deadline_hint and not task_hint:
                results.append({"id": "quick:implicit_deadline", "title": f"期限として追加: {base_detail}", "kind": "登録候補", "hint": "候補を選ぶまで保存しません", "action": "quick_deadline", "actionLabel": "期限追加", "canExecute": True, "payload": task_payload})
                results.append({"id": "quick:implicit_task", "title": f"作業として追加: {task_detail}", "kind": "登録候補", "hint": "期限ではなく作業にする候補", "action": "quick_task", "actionLabel": "作業追加", "canExecute": True, "payload": task_payload})
            else:
                results.append({"id": "quick:implicit_task", "title": f"作業として追加: {task_detail}", "kind": "登録候補", "hint": "候補を選ぶまで保存しません", "action": "quick_task", "actionLabel": "作業追加", "canExecute": True, "payload": task_payload})
                if not has_task_intent_text(query):
                    results.append({"id": "quick:implicit_deadline", "title": f"期限として追加: {base_detail}", "kind": "登録候補", "hint": "期限として管理する候補", "action": "quick_deadline", "actionLabel": "期限追加", "canExecute": True, "payload": task_payload})

    # 画面候補は最後に足し、ランチャーより実行・登録・検索を上にする。
    add_nav("open:today", "今日の画面を開く", "/speculum#today", ["今日", "today", "ホーム", "home", "司令塔", "ダッシュボード"])
    if query and any(w in query for w in ["今日を組む", "朝の整理", "今日の整理", "今日を閉じる", "終業", "締め"]):
        results.append({"id": "open:today-ritual", "title": "今日の画面を開く（今日を組む・閉じる）", "kind": "画面", "href": "/speculum#today", "actionLabel": "開く", "canExecute": True, "action": "open"})
    add_nav("open:schedule", "日付確認カレンダーを開く", "/speculum#schedule", ["日付確認", "予定表", "カレンダー", "日付", "schedule"])
    add_nav("open:work", "作業管理を開く（期限・事務・事案も処理）", "/continuum", ["作業管理", "タスク管理", "処理入口", "todo", "work"])
    add_nav("open:cases", "事案台帳を開く", "/speculum#cases", ["事案台帳", "調査台帳"])
    add_nav("open:people", "人物管理を開く", "/speculum#people", ["人物管理", "職員管理", "同僚管理", "連絡先"])
    add_nav("open:career", "経歴管理を開く", "/speculum#career", ["経歴", "異動", "普通科", "専科"])

    tool_words = ["tool", "ツール", "起動", "ローカル"]
    toolish = (not query) or any(w in low for w in tool_words)
    tool_query = query
    if toolish:
        tool_query = clean_text(re.sub(r"ローカルツール|ローカル|ツール|tool|起動|実行|開く|ひらく|を|する", " ", query, flags=re.I))
    for tool in scan_local_tools(tool_query if toolish else query):
        results.append({"id": tool["id"], "title": "ローカル: " + tool["title"], "kind": "ローカルツール", "rel": tool["rel"], "actionLabel": "起動", "canExecute": True, "action": "launch_local"})
    if toolish:
        results.append({"id": "tools:folder", "title": "ローカルツールフォルダを開く", "kind": "ローカルツール", "action": "open_tools_folder", "actionLabel": "開く", "canExecute": True})

    seen = set(); uniq: list[dict[str, Any]] = []
    for seq, r in enumerate(results):
        rid = clean_text(r.get("id"))
        if not rid or rid in seen:
            continue
        seen.add(rid)
        rr = dict(r)
        rr["_seq"] = seq
        uniq.append(rr)
    uniq.sort(key=lambda r: command_result_rank(query, r, int(r.get("_seq") or 0)))
    for r in uniq:
        r.pop("_seq", None)
    return uniq[:60]


def execute_command_payload(payload: dict[str, Any], server_port: int) -> dict[str, Any]:
    """吹き出しの候補を実行する。HTTP層でrequestIdによる再送防止を適用する。"""
    cand = as_dict(payload.get("candidate"))
    action = clean_text(cand.get("action"))
    cand_payload = as_dict(cand.get("payload"))
    text = clean_text(cand_payload.get("text") or payload.get("text"))
    priority = clean_text(cand_payload.get("priority")) or infer_priority(clean_text(payload.get("text") or text), {})
    if action == "quick_event":
        return quick_add_speculum("event", {"text": text, "calendarKind": "schedule", "priority": priority, "estimateMinutes": cand_payload.get("estimateMinutes")})
    if action == "quick_happening":
        return quick_add_speculum("happening", {"text": text, "calendarKind": "happening", "priority": priority, "estimateMinutes": cand_payload.get("estimateMinutes")})
    if action == "quick_deadline":
        return quick_add_speculum("deadline", {"text": text, "priority": priority})
    if action == "quick_jimu":
        return quick_add_speculum("jimu", {"text": text, "priority": priority})
    if action == "quick_task":
        return quick_add_task({"text": text, "priority": priority, "status": cand_payload.get("status") or "next", "estimateMinutes": cand_payload.get("estimateMinutes")}, False)
    if action == "quick_cycle":
        return quick_add_task({"text": text, "priority": priority}, True)
    if action in {"task_complete", "task_waiting", "task_today", "task_due", "task_priority_high", "task_priority_normal", "task_priority_low"}:
        return command_update_task(action, cand)
    if action in {"cycle_complete", "cycle_skip", "cycle_pause", "cycle_resume", "cycle_end"}:
        return command_cycle_action(action, cand)
    if action == "resident_start":
        return start_resident_icon()
    if action == "open_tools_folder":
        open_path(LOCAL_TOOLS_ROOT)
        return {"ok": True}
    if action == "launch_local":
        return launch_local_tool(clean_text(cand.get("rel") or cand.get("id")))
    if action == "open":
        href = clean_text(cand.get("href") or "/speculum")
        if href.startswith("/"):
            return open_edge_app(href.strip("/"), server_port)
        webbrowser.open(href)
        return {"ok": True}
    raise RequestPayloadError("実行対象を選び直してください。")


class BlackCatHandler(BaseHTTPRequestHandler):
    server_version = "BlackCatWorkTool"
    sys_version = ""

    def log_message(self, fmt: str, *args: Any) -> None:
        return

    def do_GET(self) -> None:
        try:
            if not self.host_ok():
                self.send_json({"ok": False, "error": "この接続先からは黒猫ワークツールを開けません。"}, status=403)
                return
            self.route_get()
        except DataCorruptionError as e:
            self.send_json({"ok": False, "error": str(e), "recoveryRequired": True}, status=503)
        except ValueError as e:
            self.send_json({"ok": False, "error": str(e)}, status=400)
        except Exception as e:
            self.send_json({"ok": False, "error": str(e)}, status=500)

    def do_POST(self) -> None:
        try:
            if not self.host_ok():
                self.send_json({"ok": False, "error": "この接続先からは黒猫ワークツールを操作できません。"}, status=403)
                return
            if not self.origin_ok():
                self.send_json({"ok": False, "error": "別の画面から送られた操作は受け付けません。黒猫ワークツールから実行してください。"}, status=403)
                return
            if not self.check_token():
                self.send_json({"ok": False, "error": "操作用トークンを取得し直してください。"}, status=403)
                return
            self.route_post()
        except SaveConflictError as e:
            self.send_json({"ok": False, "conflict": True, "error": str(e), "app": e.app, "baseHash": e.base_hash, "currentHash": e.current_hash, "updatedAt": e.updated_at}, status=409)
        except RequestPayloadError as e:
            self.send_json({"ok": False, "error": str(e)}, status=e.status)
        except DataCorruptionError as e:
            self.send_json({"ok": False, "error": str(e), "recoveryRequired": True}, status=503)
        except ValueError as e:
            self.send_json({"ok": False, "error": str(e)}, status=400)
        except Exception as e:
            self.send_json({"ok": False, "error": str(e)}, status=500)

    def host_ok(self) -> bool:
        return loopback_host_header_ok(self.headers.get("Host"))

    def origin_ok(self) -> bool:
        """ブラウザー更新は、このサーバー自身のローカルOriginだけを許可する。

        Pythonの起動ファイルなどOriginを送らない正規クライアントは、専用トークンで
        認証する。別ポートのローカルWebアプリからのblind POSTはここで止める。
        """
        raw = clean_text(self.headers.get("Origin"))
        if not raw:
            return True
        try:
            parsed = urlparse(raw)
            if parsed.scheme.lower() != "http" or not loopback_host_header_ok(parsed.netloc):
                return False
            origin_port = parsed.port or 80
            server_port = int(getattr(self.server, "server_port", DEFAULT_PORT))
            return origin_port == server_port
        except (TypeError, ValueError):
            return False

    def check_token(self) -> bool:
        if not self.host_ok():
            return False
        token = self.headers.get("X-Blackcat-Token") or ""
        return secrets.compare_digest(token, TOKEN)

    def read_json(self) -> dict[str, Any]:
        content_type = clean_text(self.headers.get("Content-Type")).split(";", 1)[0].strip().lower()
        if content_type != "application/json":
            raise RequestPayloadError("送信形式が正しくありません。画面を読み込み直して、もう一度実行してください。", status=415)
        raw_length = self.headers.get("Content-Length") or "0"
        try:
            n = int(raw_length)
        except (TypeError, ValueError) as exc:
            raise RequestPayloadError("送信データの長さが正しくありません。") from exc
        if n < 0:
            raise RequestPayloadError("送信データの長さが正しくありません。")
        if n > MAX_JSON_BODY_BYTES:
            self.close_connection = True
            raise RequestPayloadError("送信データが大きすぎます。分割して登録してください。", status=413)
        if n <= 0:
            return {}
        raw = self.rfile.read(n)
        if len(raw) != n:
            raise RequestPayloadError("送信データを最後まで受信できませんでした。もう一度実行してください。")
        try:
            decoded = json.loads(raw.decode("utf-8"))
        except (UnicodeError, TypeError, ValueError, json.JSONDecodeError, RecursionError) as exc:
            raise RequestPayloadError("送信データを読み取れません。入力内容を確認してください。") from exc
        if not isinstance(decoded, dict):
            raise RequestPayloadError("送信データの形式が正しくありません。")
        if not json_value_is_safe(decoded):
            raise RequestPayloadError("送信データに扱えない文字または数値が含まれています。")
        return decoded

    def send_json(self, data: Any, status: int = 200) -> None:
        body = json.dumps(data, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def send_file(self, path: Path) -> None:
        if not path.is_file():
            self.send_error(404)
            return
        ctype = mimetypes.guess_type(str(path))[0] or "application/octet-stream"
        data = path.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Cache-Control", "no-cache" if path.suffix.lower() in {".html", ".js", ".css"} else "public, max-age=86400")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def route_get(self) -> None:
        u = urlparse(self.path)
        path = u.path.rstrip("/") or "/"
        qs = parse_qs(u.query)
        if path in {"/speculum", "/speculum.html"}:
            self.send_file(WEB_ROOT / "speculum.html"); return
        if path in {"/continuum", "/continuum.html"}:
            # 作業管理は単独ウィンドウを増やさず、メイン画面の作業タブで扱う。
            # ただしメイン画面内の iframe から ?embed=1 で呼ばれた場合だけ作業ボード本体を返す。
            if "embed" in qs:
                self.send_file(WEB_ROOT / "continuum.html"); return
            self.send_response(302)
            self.send_header("Location", "/workspace#continuum")
            self.send_header("Cache-Control", "no-store")
            self.end_headers(); return
        if path in {"/", "/main", "/workspace", "/workspace.html"}:
            self.send_file(WEB_ROOT / "workspace.html"); return
        if path in {"/floating", "/floating.html"}:
            self.send_file(WEB_ROOT / "floating.html"); return
        if path.startswith("/web/"):
            rel = unquote(path[len("/web/"):])
            target = (WEB_ROOT / rel).resolve()
            if WEB_ROOT.resolve() in target.parents or WEB_ROOT.resolve() == target:
                self.send_file(target); return
            self.send_error(403); return
        if path == "/api/security/token":
            self.send_response(200)
            body = json.dumps({"ok": True, "token": TOKEN}, ensure_ascii=False).encode("utf-8")
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers(); self.wfile.write(body); return
        if path in {"/api/runtime/ping", "/api/runtime/status", "/api/ui/status", "/api/app/alive"}:
            self.send_json({"ok": True, "schema": "blackcat-worktool-runtime", "now": iso_now(), "app_root": str(APP_ROOT)}); return
        if path == "/api/ui/route":
            self.send_json({"ok": True, **current_workspace_route()}); return
        if path == "/api/floating/state":
            self.send_json(current_floating_state()); return
        if path == "/api/blackcat/load":
            # 同じ応答のためにレコードを複製・再読込せず、集計にも同一スナップショットを渡す。
            spec_record = load_record("speculum", clone=False)
            cont_record = load_record("continuum", clone=False)
            self.send_json({"ok": True, "speculum": spec_record, "continuum": cont_record, "summary": build_summary(spec_record, cont_record)}); return
        if path == "/api/speculum/load":
            self.send_json(load_record("speculum", clone=False)); return
        if path == "/api/continuum/load":
            self.send_json(load_record("continuum", clone=False)); return
        if path == "/api/speculum/summary":
            self.send_json(build_summary()); return
        if path == "/api/holidays/load":
            spec = load_record("speculum", clone=False)["data"]
            self.send_json({"ok": True, "holidays": spec.get("holidays", {}), "status": holiday_status(spec)}); return
        if path == "/api/calendar/occurrences":
            spec = load_record("speculum", clone=False)["data"]
            start = clean_date(qs.get("from", [date_s()])[0]) or date_s()
            end = clean_date(qs.get("to", [start])[0]) or start
            mode = clean_text(qs.get("mode", ["both"])[0]) or "both"
            self.send_json({"ok": True, "items": calendar_occurrences(spec, start, end, mode), "holidayStatus": holiday_status(spec)}); return
        if path == "/api/people/list":
            self.send_json({"ok": True, "items": list_people_focus(qs.get("q", [""])[0])}); return
        if path == "/api/people/focus":
            self.send_json({"ok": True, "items": list_people_focus(qs.get("q", [""])[0])}); return
        if path == "/api/local-tools/list":
            self.send_json({"ok": True, "items": scan_local_tools("")}); return
        if path == "/api/local-tools/search":
            self.send_json({"ok": True, "items": scan_local_tools(qs.get("q", [""])[0])}); return
        if path == "/api/command/resolve" or path == "/api/search/all":
            self.send_json({"ok": True, "candidates": command_candidates(qs.get("q", [""])[0])}); return
        if path in {"/api/backups/list", "/api/speculum/backups"}:
            app = valid_store_app(qs.get("app", ["speculum"])[0])
            self.send_json({"ok": True, "items": backup_list(app)}); return
        if path == "/api/calendar/business-day":
            spec = load_record("speculum", clone=False)["data"]
            start = clean_date(qs.get("date", [date_s()])[0]) or date_s()
            mode = clean_text(qs.get("mode", ["next"])[0]) or "next"
            tie = clean_text(qs.get("tie", ["previous"])[0]) or "previous"
            self.send_json({"ok": True, "date": shift_business_date(spec, start, mode, tie), "holidayStatus": holiday_status(spec)}); return
        self.send_error(404)

    def route_post(self) -> None:
        u = urlparse(self.path)
        path = u.path.rstrip("/") or "/"
        payload = self.read_json()
        if path == "/api/speculum/save":
            if not isinstance(payload.get("data"), dict):
                raise RequestPayloadError("保存する今日・日付確認データがありません。")
            if "baseHash" not in payload and "hash" not in payload:
                raise RequestPayloadError("保存前の読込情報がありません。画面を読み込み直してください。")
            if payload.get("force") or payload.get("overwrite"):
                self.send_json({"ok": False, "conflict": True, "error": "安全のため、通常保存からの強制上書きは停止しました。保存・復元から控えを確認してください。", "app": "speculum"}, status=409); return
            try:
                self.send_json(save_speculum_document(payload["data"], payload.get("baseHash", payload.get("hash"))))
            except SaveConflictError as e:
                self.send_json({"ok": False, "conflict": True, "error": str(e), "app": e.app, "baseHash": e.base_hash, "currentHash": e.current_hash, "updatedAt": e.updated_at}, status=409)
            return
        if path == "/api/holidays/import-cabinet":
            self.send_json(import_cabinet_holidays()); return
        if path == "/api/continuum/save":
            if not isinstance(payload.get("data"), dict):
                raise RequestPayloadError("保存する作業管理データがありません。")
            if "baseHash" not in payload and "hash" not in payload:
                raise RequestPayloadError("保存前の読込情報がありません。画面を読み込み直してください。")
            if payload.get("force") or payload.get("overwrite"):
                self.send_json({"ok": False, "conflict": True, "error": "安全のため、通常保存からの強制上書きは停止しました。保存・復元から控えを確認してください。", "app": "continuum"}, status=409); return
            try:
                self.send_json(save_continuum_document(payload["data"], payload.get("baseHash", payload.get("hash"))))
            except SaveConflictError as e:
                self.send_json({"ok": False, "conflict": True, "error": str(e), "app": e.app, "baseHash": e.base_hash, "currentHash": e.current_hash, "updatedAt": e.updated_at}, status=409)
            return
        if path == "/api/speculum/backup/create":
            data = load_record("speculum", clone=False)["data"]; p = write_backup("speculum", "main", data, f"manual_{text_hash(stable_json(data))}")
            self.send_json({"ok": True, "name": p.name}); return
        if path == "/api/backups/create":
            app = valid_store_app(payload.get("app")); data = load_record(app, clone=False)["data"]; p = write_backup(app, "main", data, f"manual_{text_hash(stable_json(data))}")
            self.send_json({"ok": True, "name": p.name}); return
        if path == "/api/backups/save-draft":
            app = valid_store_app(payload.get("app"))
            p = save_draft_backup(app, payload.get("data", {}), "main")
            self.send_json({"ok": True, "name": p.name}); return
        if path == "/api/backups/restore":
            self.send_json(backup_restore(valid_store_app(payload.get("app")), clean_text(payload.get("name")))); return
        if path in {"/api/speculum/quick-add-event", "/api/speculum/quick-add"}:
            kind = clean_text(payload.get("kind")) or ("event" if path.endswith("event") else "deadline")
            self.send_json(run_idempotent_request(path, payload, lambda: quick_add_speculum(kind, payload))); return
        if path == "/api/continuum/quick-add":
            self.send_json(run_idempotent_request(path, payload, lambda: quick_add_task(payload, False))); return
        if path == "/api/continuum/cycle-add":
            self.send_json(run_idempotent_request(path, payload, lambda: quick_add_task(payload, True))); return
        if path == "/api/speculum/patch":
            self.send_json(patch_speculum(payload)); return
        if path in {"/api/speculum/item-upsert", "/api/speculum/items-upsert"}:
            collection = clean_text(payload.get("collection") or payload.get("kind") or "events")
            if path.endswith("items-upsert"):
                self.send_json(save_speculum_items(collection, payload.get("items") if isinstance(payload.get("items"), list) else [payload.get("item")], payload.get("baseHash", payload.get("hash")), payload.get("baseItems") if isinstance(payload.get("baseItems"), list) else None)); return
            item_payload = as_dict(payload.get("item")) or payload
            self.send_json(save_speculum_item(collection, item_payload, payload.get("baseHash", payload.get("hash")), payload.get("baseItemUpdatedAt") or item_payload.get("_baseUpdatedAt"))); return
        if path == "/api/speculum/items-delete":
            collection = clean_text(payload.get("collection") or payload.get("kind") or "events")
            ids = payload.get("ids") if isinstance(payload.get("ids"), list) else [payload.get("id")]
            self.send_json(delete_speculum_items(collection, ids, payload.get("baseHash", payload.get("hash")), payload.get("baseItems") if isinstance(payload.get("baseItems"), list) else None)); return
        if path == "/api/continuum/patch":
            self.send_json(patch_continuum(payload)); return
        if path == "/api/continuum/items-upsert":
            collection = clean_text(payload.get("collection") or payload.get("kind") or "tasks")
            self.send_json(save_continuum_items(collection, payload.get("items") if isinstance(payload.get("items"), list) else [payload.get("item")], payload.get("baseHash", payload.get("hash")), payload.get("baseItems") if isinstance(payload.get("baseItems"), list) else None)); return
        if path == "/api/continuum/task-upsert":
            item_payload = as_dict(payload.get("item")) or payload
            self.send_json(save_continuum_item("tasks", item_payload, payload.get("baseHash", payload.get("hash")), payload.get("baseItemUpdatedAt") or item_payload.get("_baseUpdatedAt"))); return
        if path == "/api/continuum/cycle-upsert":
            item_payload = as_dict(payload.get("item")) or payload
            self.send_json(save_continuum_item("cycleTasks", item_payload, payload.get("baseHash", payload.get("hash")), payload.get("baseItemUpdatedAt") or item_payload.get("_baseUpdatedAt"))); return
        if path in {"/api/continuum/items-delete", "/api/continuum/task-delete", "/api/continuum/cycle-delete"}:
            if path.endswith("cycle-delete"):
                collection = "cycleTasks"
            elif path.endswith("task-delete"):
                collection = "tasks"
            else:
                collection = clean_text(payload.get("collection") or payload.get("kind") or "tasks")
            ids = payload.get("ids") if isinstance(payload.get("ids"), list) else [payload.get("id")]
            self.send_json(delete_continuum_items(collection, ids, payload.get("baseHash", payload.get("hash")), payload.get("baseItems") if isinstance(payload.get("baseItems"), list) else None)); return
        if path in {"/api/continuum/cycle-complete", "/api/continuum/cycle-skip", "/api/continuum/cycle-pause", "/api/continuum/cycle-resume", "/api/continuum/cycle-end"}:
            action = "cycle_" + path.rsplit("-", 1)[-1]
            self.send_json(command_cycle_action(action, {"payload": {"cycleId": payload.get("id"), "doneDate": payload.get("doneDate"), "baseItemUpdatedAt": payload.get("baseItemUpdatedAt")}})); return
        if path == "/api/continuum/import-speculum-actions":
            self.send_json(import_speculum_actions()); return
        if path == "/api/resident/start":
            self.send_json(start_resident_icon()); return
        if path == "/api/floating/hide":
            self.send_json(hide_floating_windows()); return
        if path == "/api/local-tools/open-folder":
            self.send_json(run_idempotent_request(path, payload, open_local_tools_folder)); return
        if path == "/api/local-tools/launch":
            self.send_json(run_idempotent_request(
                path,
                payload,
                lambda: launch_local_tool(clean_text(payload.get("rel") or payload.get("path"))),
            )); return
        if path == "/api/open-local-path":
            target = clean_text(payload.get("path") or payload.get("url") or payload.get("href"))
            if target.startswith(("http://", "https://")):
                webbrowser.open(target)
            else:
                p = Path(target).expanduser().resolve()
                if not p.exists() or p.suffix.lower() not in OPENABLE_EXTENSIONS and not p.is_dir():
                    raise ValueError("開ける対象が見つかりません。")
                open_path(p)
            self.send_json({"ok": True}); return
        if path in {"/api/app/open", "/api/ui/navigate", "/api/ui/open-target", "/api/ui/open-app"}:
            target = clean_text(payload.get("target") or payload.get("href") or "speculum")
            if target.startswith("/"):
                target = target.strip("/")
            self.send_json(open_edge_app(target, getattr(self.server, "server_port", DEFAULT_PORT))); return
        if path == "/api/command/execute":
            self.send_json(run_idempotent_request(
                path,
                payload,
                lambda: execute_command_payload(payload, getattr(self.server, "server_port", DEFAULT_PORT)),
            )); return
        if path == "/api/shutdown":
            self.send_json({"ok": True})
            threading.Thread(target=lambda: (time.sleep(0.2), self.server.shutdown()), daemon=True).start(); return
        self.send_error(404)




def create_startup_backups_once() -> None:
    """サーバー起動直後の状態を控える。同じハッシュの控えは短時間に量産しない。"""
    try:
        ensure_dirs()
        marker_path = RUNTIME_ROOT / "startup_backup_marker.json"
        marker: dict[str, Any] = {}
        try:
            marker = as_dict(json.loads(marker_path.read_text(encoding="utf-8")))
        except Exception:
            marker = {}
        now_m = time.time()
        changed_marker = False
        with db() as con:
            rows = con.execute("SELECT app, store_key, json_text, sha256 FROM app_store").fetchall()
        for row in rows:
            app = valid_store_app(row["app"])
            key = clean_text(row["store_key"]) or "main"
            sha = clean_text(row["sha256"])
            if not sha:
                continue
            marker_key = f"{app}:{key}:{sha}"
            last = float(marker.get(marker_key) or 0)
            if now_m - last < STARTUP_BACKUP_INTERVAL_SECONDS:
                continue
            write_backup_text(app, key, row["json_text"] or "{}", f"startup_{sha}")
            marker[marker_key] = now_m
            changed_marker = True
        if changed_marker:
            # 古いマーカーを少し間引く。
            fresh = {k: v for k, v in marker.items() if now_m - float(v or 0) < 30 * 24 * 60 * 60}
            _atomic_write_text(marker_path, json.dumps(fresh, ensure_ascii=False, indent=2))
    except Exception as exc:
        try:
            ensure_dirs()
            with (BACKUP_ROOT / "startup_backup_error.log").open("a", encoding="utf-8") as f:
                f.write(f"{iso_now()} {exc}\n")
        except Exception:
            pass


def warm_command_caches() -> None:
    try:
        spec_record = load_record("speculum", clone=False)
        cont_record = load_record("continuum", clone=False)
        command_search_index(spec_record, cont_record)
        local_tool_catalog()
    except Exception:
        pass


def finish_startup_maintenance() -> None:
    """画面受付を止めずに、起動時の控えと検索索引を準備する。"""
    create_startup_backups_once()
    warm_command_caches()


def run(host: str, port: int, open_browser: bool = True) -> None:
    ensure_dirs()
    httpd = ThreadingHTTPServer((host, port), BlackCatHandler)
    httpd.server_port = port  # type: ignore[attr-defined]
    # 大きいJSONの起動控えや検索索引は、HTTP受付開始を待たせず裏で作る。
    # 通常保存時のSQLite履歴・変更前控えは別経路で維持される。
    threading.Thread(target=finish_startup_maintenance, name="blackcat-startup-maintenance", daemon=True).start()
    if open_browser:
        threading.Thread(target=lambda: (time.sleep(0.6), open_edge_app("workspace", port)), daemon=True).start()
    print(f"BlackCat WorkTool: http://{host}:{port}/workspace")
    try:
        httpd.serve_forever()
    finally:
        httpd.server_close()
        flush_pending_backups(5.0)


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--host", default=DEFAULT_HOST)
    p.add_argument("--port", type=int, default=DEFAULT_PORT)
    p.add_argument("--no-browser", action="store_true")
    args = p.parse_args()
    run(args.host, args.port, not args.no_browser)


if __name__ == "__main__":
    main()

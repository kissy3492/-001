# -*- coding: utf-8 -*-
from pathlib import Path
import ctypes
import os
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
TARGET = ROOT / 'START_BLACKCAT_FLOATING.pyw'
ICON = ROOT / 'web' / 'assets' / 'blackcat_icon.ico'


def desktop_folder() -> Path:
    if sys.platform.startswith('win'):
        try:
            buf = ctypes.create_unicode_buffer(32768)
            # CSIDL_DESKTOPDIRECTORY。OneDrive等へ移動したデスクトップも取得する。
            if ctypes.windll.shell32.SHGetFolderPathW(None, 0x10, None, 0, buf) == 0 and buf.value:
                return Path(buf.value)
        except Exception:
            pass
    return Path(os.path.join(os.environ.get('USERPROFILE', str(ROOT)), 'Desktop'))


def pythonw_path() -> Path:
    current = Path(sys.executable)
    sibling = current.with_name('pythonw.exe')
    if sibling.is_file():
        return sibling
    found = shutil.which('pythonw.exe')
    return Path(found) if found else current


def create_windows_link(desktop: Path) -> bool:
    """Windows標準のWScript.Shellで、黒猫アイコン付きショートカットを作る。"""
    if not sys.platform.startswith('win'):
        return False
    powershell = Path(os.environ.get('SystemRoot', r'C:\Windows')) / 'System32' / 'WindowsPowerShell' / 'v1.0' / 'powershell.exe'
    executable = str(powershell) if powershell.is_file() else (shutil.which('powershell.exe') or '')
    if not executable or not ICON.is_file():
        return False
    link = desktop / '常駐黒猫を開く.lnk'
    env = os.environ.copy()
    env.update({
        'BLACKCAT_SHORTCUT_LINK': str(link),
        'BLACKCAT_SHORTCUT_PYTHONW': str(pythonw_path()),
        'BLACKCAT_SHORTCUT_SCRIPT': str(TARGET),
        'BLACKCAT_SHORTCUT_WORKDIR': str(ROOT),
        'BLACKCAT_SHORTCUT_ICON': str(ICON),
    })
    script = (
        "$shell = New-Object -ComObject WScript.Shell; "
        "$link = $shell.CreateShortcut($env:BLACKCAT_SHORTCUT_LINK); "
        "$link.TargetPath = $env:BLACKCAT_SHORTCUT_PYTHONW; "
        "$link.Arguments = '\"' + $env:BLACKCAT_SHORTCUT_SCRIPT + '\"'; "
        "$link.WorkingDirectory = $env:BLACKCAT_SHORTCUT_WORKDIR; "
        "$link.IconLocation = $env:BLACKCAT_SHORTCUT_ICON + ',0'; "
        "$link.Description = '黒猫ワークツールの常駐黒猫を開く'; "
        "$link.Save()"
    )
    try:
        result = subprocess.run(
            [executable, '-NoLogo', '-NoProfile', '-NonInteractive', '-Command', script],
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0),
            env=env,
            timeout=20,
            check=False,
        )
        return result.returncode == 0 and link.is_file()
    except Exception:
        return False


def create_batch_fallback(desktop: Path) -> Path:
    """PowerShellが使えない環境でも、起動手段だけは必ず残す。"""
    shortcut = desktop / '常駐黒猫を開く.bat'
    shortcut.write_text(f'@echo off\r\nchcp 65001 >nul\r\nstart "" "{TARGET}"\r\n', encoding='utf-8-sig')
    return shortcut


def main() -> int:
    desktop = desktop_folder()
    desktop.mkdir(parents=True, exist_ok=True)
    if create_windows_link(desktop):
        try:
            (desktop / '常駐黒猫を開く.bat').unlink()
        except FileNotFoundError:
            pass
    else:
        # 古い場所を向いた同名リンクが残っていると誤起動するため、標準リンクの
        # 作成に失敗した場合は本ツールが作った同名リンクだけを片付ける。
        try:
            (desktop / '常駐黒猫を開く.lnk').unlink()
        except FileNotFoundError:
            pass
        create_batch_fallback(desktop)
    return 0


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except SystemExit:
        raise
    except Exception as e:
        print(e, file=sys.stderr)
        raise SystemExit(1)

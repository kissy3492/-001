(() => {
  'use strict';
  window.addEventListener('unhandledrejection', e => { if (e?.reason?.handled || e?.reason?.cancelled) e.preventDefault(); });
  const $ = (id) => document.getElementById(id);
  const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));
  const today = () => { const d = new Date(); return `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}`; };
  const pad = (n) => String(n).padStart(2, '0');
  const uid = (p) => `${p}_${Date.now().toString(16)}_${Math.random().toString(16).slice(2, 7)}`;
  const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const clean = (v) => String(v ?? '').trim();
  const canonicalValue = (item, key, ...aliases) => {
    if (item && Object.prototype.hasOwnProperty.call(item, key)) return item[key];
    for (const alias of aliases) if (item && Object.prototype.hasOwnProperty.call(item, alias)) return item[alias];
    return '';
  };
  const arr = (v) => Array.isArray(v) ? v : [];
  const boolish = (v) => v === true || ['1','true','yes','on','退職'].includes(clean(v).toLowerCase());
  const searchTokens = (q) => clean(q).toLowerCase().split(/[\s　,、。/\\]+/).filter(Boolean);
  const matchesSearchTokens = (tokens, hay) => { if (!tokens.length) return true; const h = String(hay || '').toLowerCase(); return tokens.every(t => h.includes(t)); };
  const matchesWords = (q, hay) => matchesSearchTokens(searchTokens(q), hay);
  const byDate = (a, b) => String(a || '').localeCompare(String(b || ''));
  const isDone = (x) => !!x.done || ['done','完了'].includes(String(x.status || ''));
  let TOKEN = '';
  let DATA = null;
  let WORK = null;
  let HASH = '';
  let WORK_HASH = '';
  let currentView = location.hash ? location.hash.slice(1) : 'today';
  let calCursor = new Date();
  let calendarMode = 'month';
  let calendarItemMode = 'both';
  let calendarShowDue = false;
  let calendarShowWork = false;
  let calendarShowDone = false;
  let calendarShowRepeat = true;
  let calendarListExpanded = false;
  let dueDayCountMode = 'business';
  let showRetiredPeople = false;
  const PEOPLE_RENDER_BATCH = 120;
  let peopleRenderLimit = PEOPLE_RENDER_BATCH;
  let peopleRenderScopeKey = '';
  const DUE_RENDER_BATCH = 80;
  let dueRenderLimits = {deadlines:DUE_RENDER_BATCH, jimu:DUE_RENDER_BATCH};
  let dueRenderScopeKey = '';
  const CAREER_RENDER_BATCH = 20;
  const PERSON_PICKER_RESULT_LIMIT = 80;
  let careerRenderLimit = CAREER_RENDER_BATCH;
  let careerRenderScopeKey = '';
  let dirtyModal = false;
  let modalSaving = false;
  let modalReturnFocus = null;
  let modalSession = 0;
  let activeConfirmFinish = null;
  let MAIN_CHANNEL = null;
  let DATA_CHANNEL = null;
  let EXTERNAL_SYNC_TIMER = 0;
  let EXTERNAL_SYNC_RUNNING = false;
  let EXTERNAL_SYNC_RETRY_MS = 250;
  let WINDOW_BLURRED_AT = 0;
  const EXTERNAL_SYNC_APPS = new Set();
  const INSTANCE_ID = `${Date.now()}-${Math.random().toString(16).slice(2)}`;
  let OCCURRENCE_CACHE = {key:'', start:'', end:'', mode:'both', items:[]};
  let CALENDAR_RENDER_SEQ = 0;
  let CALENDAR_DRAG = null;
  let CALENDAR_MOVE_BUSY = false;
  let CALENDAR_SUPPRESS_CLICK_UNTIL = 0;
  let SUMMARY_CACHE = {data:null, at:0, promise:null};
  let SUMMARY_CACHE_GENERATION = 0;
  let DATE_DIFF_CACHE_DAY = '';
  const CALENDAR_DAY_DIFF_CACHE = new Map();
  const BUSINESS_DAY_DIFF_CACHE = new Map();
  const todayCommanderExpanded = {critical:false, now:false, near:false, work:false, cases:false};
  let caseBoardOpen = false;
  let caseFocusScope = 'focus';
  let PERSON_BY_ID = new Map();
  let PERSON_BY_NAME = new Map();
  let CASE_BY_ID = new Map();
  let SORTED_PEOPLE_CACHE = null;
  let PERSON_ORDER_BY_ID = null;
  let PERSON_RELATION_COUNTS_CACHE = null;
  let CASE_TARGET_CARDS_CACHE = null;
  let CASE_RELATION_COUNTS_CACHE = null;
  let CASE_RENDER_GENERATION = 0;
  let CASE_RENDER_SIGNATURE = '';
  let CASE_PRELOAD_TASK = 0;
  let PERSON_SEARCH_TEXT_CACHE = new WeakMap();
  let CAREER_SEARCH_TEXT_CACHE = new WeakMap();
  let WORK_TASK_BY_ID = new Map();
  let WORK_TASK_BY_SOURCE = new Map();
  let TODAY_RENDER_SEQ = 0;
  const VIEW_RENDER_SIGNATURES = new Map();
  const UI_ACTION_LOCKS = new Set();
  let MEMO_SAVE_RUNNING = false;
  let MEMO_SAVE_PENDING = false;
  let MEMO_SAVE_NOTICE = '';
  let MEMO_DRAFT_DIRTY = false;
  let ACTIVE_DAY = today();
  let MEMO_DRAFT_DAY = ACTIVE_DAY;
  let DAY_CONTEXT_TIMER = 0;
  let DAY_CONTEXT_REFRESH = null;

  function rebuildSpeculumLookupIndexes() {
    PERSON_BY_ID = new Map();
    PERSON_BY_NAME = new Map();
    arr(DATA?.people).forEach(person => {
      const id = clean(person?.id);
      if (id) PERSON_BY_ID.set(id, person);
      const name = clean(person?.name);
      if (name && !PERSON_BY_NAME.has(name)) PERSON_BY_NAME.set(name, person);
    });
    CASE_BY_ID = new Map(arr(DATA?.cases).map(item => [clean(item?.id), item]).filter(([id]) => !!id));
    SORTED_PEOPLE_CACHE = null;
    PERSON_ORDER_BY_ID = null;
    PERSON_RELATION_COUNTS_CACHE = null;
    CASE_TARGET_CARDS_CACHE = null;
    CASE_RELATION_COUNTS_CACHE = null;
    CASE_RENDER_GENERATION += 1;
    CASE_RENDER_SIGNATURE = '';
    PERSON_SEARCH_TEXT_CACHE = new WeakMap();
    CAREER_SEARCH_TEXT_CACHE = new WeakMap();
  }

  function rebuildWorkLookupIndexes() {
    WORK_TASK_BY_ID = new Map();
    WORK_TASK_BY_SOURCE = new Map();
    arr(WORK?.tasks).forEach(task => {
      const id = clean(task?.id);
      const source = clean(task?.source);
      if (id) WORK_TASK_BY_ID.set(id, task);
      // 旧動作の find() と同じく、重複時は先に登録された作業を採用する。
      if (source && !WORK_TASK_BY_SOURCE.has(source)) WORK_TASK_BY_SOURCE.set(source, task);
    });
    PERSON_RELATION_COUNTS_CACHE = null;
    CASE_RELATION_COUNTS_CACHE = null;
    CASE_RENDER_GENERATION += 1;
    CASE_RENDER_SIGNATURE = '';
  }

  function setupMainSingleton() {
    try {
      MAIN_CHANNEL = new BroadcastChannel('blackcat-main-singleton');
      MAIN_CHANNEL.onmessage = (ev) => {
        const msg = ev.data || {};
        if (!msg || msg.id === INSTANCE_ID) return;
        if (msg.type === 'open-view') {
          MAIN_CHANNEL.postMessage({type:'main-alive', id:INSTANCE_ID, replyTo:msg.id});
          if (msg.view) switchView(msg.view);
        }
        if (msg.type === 'who-main') MAIN_CHANNEL.postMessage({type:'main-alive', id:INSTANCE_ID, replyTo:msg.id});
      };
      // 新しく開かれたタブからも既存タブへ意図だけは伝える。閉じられない場合でも画面は同じ view に揃える。
      MAIN_CHANNEL.postMessage({type:'open-view', id:INSTANCE_ID, view:currentView || 'today'});
    } catch (_) {}
  }

  function setupDataSync() {
    if (DATA_CHANNEL || !('BroadcastChannel' in window)) return;
    try {
      DATA_CHANNEL = new BroadcastChannel('blackcat-data-changed');
      DATA_CHANNEL.onmessage = event => {
        const msg = event.data || {};
        if (!['changed','data-changed'].includes(clean(msg.type)) || (msg.source || msg.sender) === INSTANCE_ID || !['speculum','continuum'].includes(msg.app)) return;
        const localHash = msg.app === 'speculum' ? HASH : WORK_HASH;
        if (msg.hash && localHash && msg.hash === localHash) return;
        queueExternalSync(msg.app);
      };
    } catch (_) { DATA_CHANNEL = null; }
  }

  function notifyDataChanged(app, hash = '', collection = '') {
    invalidateTodaySummary();
    try { DATA_CHANNEL?.postMessage({type:'data-changed', app, hash, collection, source:INSTANCE_ID, sender:INSTANCE_ID, at:Date.now()}); }
    catch (_) {}
  }

  function queueExternalSync(app) {
    if (!['speculum','continuum'].includes(app)) return;
    invalidateTodaySummary();
    EXTERNAL_SYNC_APPS.add(app);
    EXTERNAL_SYNC_RETRY_MS = 250;
    clearTimeout(EXTERNAL_SYNC_TIMER);
    EXTERNAL_SYNC_TIMER = setTimeout(flushExternalSync, 70);
  }

  function externalSyncBlocked() {
    const backdrop = $('modalBackdrop');
    return modalSaving || dirtyModal || !!(backdrop && !backdrop.hidden);
  }

  function schedulePendingExternalSync(delay = 70) {
    if (!EXTERNAL_SYNC_APPS.size || externalSyncBlocked()) return;
    clearTimeout(EXTERNAL_SYNC_TIMER);
    EXTERNAL_SYNC_TIMER = setTimeout(flushExternalSync, delay);
  }

  async function flushExternalSync() {
    if (EXTERNAL_SYNC_RUNNING || !EXTERNAL_SYNC_APPS.size || !TOKEN || externalSyncBlocked()) return;
    EXTERNAL_SYNC_RUNNING = true;
    const apps = [...EXTERNAL_SYNC_APPS];
    EXTERNAL_SYNC_APPS.clear();
    try {
      let speculumRecord = null;
      let continuumRecord = null;
      if (apps.includes('speculum') && apps.includes('continuum')) {
        const j = await api('/api/blackcat/load');
        speculumRecord = j.speculum || {};
        continuumRecord = j.continuum || {};
        rememberSummary(j.summary);
      } else if (apps[0] === 'speculum') speculumRecord = await api('/api/speculum/load');
      else if (apps[0] === 'continuum') continuumRecord = await api('/api/continuum/load');
      // 通信中に編集画面が開かれた場合も、保存基準のハッシュだけを先へ
      // 進めない。旧フォームによる上書きを避け、閉じた後に同じ同期をやり直す。
      if (externalSyncBlocked()) {
        apps.forEach(app => EXTERNAL_SYNC_APPS.add(app));
        return;
      }
      if (speculumRecord) {
        applySpeculum(speculumRecord);
        OCCURRENCE_CACHE = {key:'', start:'', end:'', mode:'both', items:[]};
      }
      if (continuumRecord) applyWork(continuumRecord);
      renderCurrentView();
      EXTERNAL_SYNC_RETRY_MS = 250;
    } catch (_) {
      apps.forEach(app => EXTERNAL_SYNC_APPS.add(app));
      EXTERNAL_SYNC_RETRY_MS = Math.min(5000, EXTERNAL_SYNC_RETRY_MS * 2);
    } finally {
      EXTERNAL_SYNC_RUNNING = false;
      if (EXTERNAL_SYNC_APPS.size) schedulePendingExternalSync(EXTERNAL_SYNC_RETRY_MS);
    }
  }

  const CASE_STATUSES = ['事案交付','事前通知済','着手済','反面済','再臨宅済','重審済','修正勧奨済','加算税賦課済','完了'];
  const CASE_STARTED = new Set(['着手済','反面済','再臨宅済','重審済','修正勧奨済','加算税賦課済']);
  function normalizeCaseStatus(v) { const s = clean(v); return CASE_STATUSES.includes(s) ? s : (s === '調査中' || s === '対応中' ? '着手済' : (s === '確認待ち' ? '事前通知済' : (s === '完了' ? '完了' : '事案交付'))); }
  function openWorkspace(target = 'speculum:today') {
    let hash = 'speculum:today';
    const raw = String(target || '').replace(/^\//, '');
    const routeAfter = (prefix) => {
      if (raw.includes('#')) return raw.split('#').slice(1).join('#');
      if (raw.startsWith(prefix + ':')) return raw.slice(prefix.length + 1);
      if (raw.startsWith(prefix + '?')) return '?' + raw.slice(prefix.length + 1);
      if (raw.includes('?')) return '?' + raw.split('?').slice(1).join('?');
      return '';
    };
    if (raw.startsWith('continuum') || raw === 'work') {
      const detail = clean(routeAfter('continuum')).replace(/^#/, '').replace(/^\?/, '');
      hash = detail ? 'continuum?' + detail : 'continuum';
    }
    else if (raw.startsWith('speculum')) hash = 'speculum:' + (routeAfter('speculum').replace(/^#/, '') || 'today');
    else if (raw.startsWith('main')) hash = 'speculum:' + (routeAfter('main').replace(/^#/, '') || 'today');
    else if (raw.includes('#')) hash = 'speculum:' + (raw.split('#').slice(1).join('#') || 'today');
    else if (raw) hash = raw.includes(':') ? raw : `speculum:${raw}`;
    if (window.parent && window.parent !== window) { try { window.parent.postMessage({blackcatNavigate: hash}, '*'); return; } catch (_) {} }
    const apiTarget = hash.startsWith('continuum') ? ('/continuum' + (hash.includes('?') ? '#' + hash.split('?').slice(1).join('?') : '')) : '/speculum#' + (hash.split(':').slice(1).join(':') || 'today');
    try { api('/api/ui/open-app', {method:'POST', body:JSON.stringify({target:apiTarget})}).catch(() => window.open('/workspace#' + hash, 'blackcat_workspace')); }
    catch (_) { window.open('/workspace#' + hash, 'blackcat_workspace'); }
  }

  function emptySpeculum() {
    return {schema:2,events:[],deadlines:[],jimu:[],cases:[],people:[],career:[],holidays:{items:{},source:'',startYear:2000,lastImportedAt:''},memo:{today:'',todayDate:'',permanent:'',days:{}},settings:{homeRangeDays:7, calendarItemMode:'both', calendarShowDue:'1', calendarShowWork:'1', calendarShowDone:'0', calendarShowRepeat:'1', dueDayCountMode:'business'}};
  }
  function emptyWork() {
    return {schema:2,tasks:[],cycleTasks:[],memo:''};
  }

  async function api(path, options = {}) {
    const headers = {'Content-Type': 'application/json'};
    if (TOKEN) headers['X-Blackcat-Token'] = TOKEN;
    const res = await fetch(path, {...options, headers: {...headers, ...(options.headers || {})}});
    const json = await res.json().catch(() => ({}));
    if (!res.ok || json.ok === false) {
      const err = new Error(json.error || `通信に失敗しました (${res.status})`);
      err.status = res.status; err.data = json; err.path = path;
      throw err;
    }
    return json;
  }
  async function initToken() {
    const j = await fetch('/api/security/token', {cache:'no-store'}).then(r => r.json());
    TOKEN = j.token || '';
  }
  function rememberSummary(data) {
    if (data && typeof data === 'object') SUMMARY_CACHE = {data, at:Date.now(), promise:null};
  }
  function invalidateTodaySummary() {
    SUMMARY_CACHE_GENERATION += 1;
    SUMMARY_CACHE = {data:null, at:0, promise:null};
  }
  async function loadTodaySummary(maxAge = 1200) {
    const cacheAge = Date.now() - SUMMARY_CACHE.at;
    if (SUMMARY_CACHE.data && cacheAge >= 0 && cacheAge <= maxAge) return SUMMARY_CACHE.data;
    if (SUMMARY_CACHE.promise) return SUMMARY_CACHE.promise;
    const generation = SUMMARY_CACHE_GENERATION;
    const promise = api('/api/speculum/summary').then(j => {
      if (generation !== SUMMARY_CACHE_GENERATION) throw Object.assign(new Error(''), {cancelled:true});
      rememberSummary(j);
      return j;
    }).finally(() => { if (generation === SUMMARY_CACHE_GENERATION && SUMMARY_CACHE.promise === promise) SUMMARY_CACHE.promise = null; });
    SUMMARY_CACHE.promise = promise;
    return promise;
  }
  async function loadData() {
    try {
      const j = await api('/api/blackcat/load');
      applySpeculum(j.speculum || {});
      applyWork(j.continuum || {});
      rememberSummary(j.summary);
      return;
    } catch (_) {
      const [s, w] = await Promise.all([api('/api/speculum/load'), api('/api/continuum/load')]);
      applySpeculum(s); applyWork(w);
      invalidateTodaySummary();
    }
  }
  function applySpeculum(j) {
    DATA = Object.assign(emptySpeculum(), j.data || {});
    ['events','deadlines','jimu','cases','people','career'].forEach(k => { DATA[k] = arr(DATA[k]); });
    DATA.people = DATA.people.map(p => {
      const retiredAt = clean(canonicalValue(p, 'retiredAt', 'retirementDate', 'leftAt'));
      return Object.assign({}, p || {}, {retiredAt, retired:boolish(p?.retired) || !!retiredAt});
    });
    DATA.holidays = Object.assign({items:{},source:'',startYear:2000,lastImportedAt:''}, DATA.holidays || {});
    DATA.holidays.items = DATA.holidays.items || {};
    DATA.memo = Object.assign({today:'', todayDate:'', permanent:'', days:{}}, DATA.memo || {});
    DATA.memo.days = (DATA.memo.days && typeof DATA.memo.days === 'object') ? DATA.memo.days : {};
    const currentDay = today();
    const hasCurrentMemo = Object.prototype.hasOwnProperty.call(DATA.memo.days, currentDay);
    const storedMemoDay = clean(DATA.memo.todayDate || DATA.memo.day);
    // 日付情報がない旧形式だけを当日へ移す。過去日の日付別メモがある場合は、
    // ``today`` の別名を翌日へ持ち越さない。
    if (!hasCurrentMemo && clean(DATA.memo.today) && !storedMemoDay && Object.keys(DATA.memo.days).length === 0) DATA.memo.days[currentDay] = DATA.memo.today;
    DATA.memo.today = Object.prototype.hasOwnProperty.call(DATA.memo.days, currentDay)
      ? String(DATA.memo.days[currentDay] || '')
      : (storedMemoDay === currentDay ? String(DATA.memo.today || '') : '');
    DATA.memo.todayDate = currentDay;
    if (!MEMO_DRAFT_DIRTY) MEMO_DRAFT_DAY = currentDay;
    const rawSettings = Object.assign({}, DATA.settings || {});
    DATA.settings = Object.assign({homeRangeDays:7, calendarItemMode:'both', calendarShowDue:'1', calendarShowWork:'1', calendarShowDone:'0', calendarShowRepeat:'1', dueDayCountMode:'business'}, rawSettings);
    if (DATA.settings.designRoleVersion !== '20') {
      DATA.settings.calendarItemMode = 'both';
      DATA.settings.calendarShowDue = '1';
      DATA.settings.calendarShowWork = '1';
      DATA.settings.designRoleVersion = '20';
    }
    calendarItemMode = ['both','schedule','happening'].includes(DATA.settings.calendarItemMode) ? DATA.settings.calendarItemMode : 'both';
    calendarShowDue = DATA.settings.calendarShowDue === true || DATA.settings.calendarShowDue === '1';
    calendarShowWork = DATA.settings.calendarShowWork === true || DATA.settings.calendarShowWork === '1';
    calendarShowDone = DATA.settings.calendarShowDone === true || DATA.settings.calendarShowDone === '1';
    calendarShowRepeat = DATA.settings.calendarShowRepeat !== false && DATA.settings.calendarShowRepeat !== '0';
    dueDayCountMode = DATA.settings.dueDayCountMode === 'calendar' ? 'calendar' : 'business';
    rebuildSpeculumLookupIndexes();
    resetDateDiffCaches();
    HASH = j.hash || '';
  }
  function applyWork(j) {
    WORK = Object.assign(emptyWork(), j.data || {});
    WORK.tasks = arr(WORK.tasks); WORK.cycleTasks = arr(WORK.cycleTasks);
    rebuildWorkLookupIndexes();
    WORK_HASH = j.hash || '';
  }
  function dataSummaryForConflict(app, data) {
    if (app === 'continuum') {
      const tasks = arr(data?.tasks);
      const cycles = arr(data?.cycleTasks);
      const done = tasks.filter(isDone).length;
      const activeCycles = cycles.filter(c => !isDone(c)).length;
      return `通常作業${tasks.length}件（完了${done}件） / 周期作業${cycles.length}件（継続${activeCycles}件） / 更新 ${fmtTimestamp(data?.updatedAt) || '不明'}`;
    }
    return `予定・出来事${arr(data?.events).length}件 / 期限${arr(data?.deadlines).length}件 / 事務${arr(data?.jimu).length}件 / 事案${arr(data?.cases).length}件 / 人物${arr(data?.people).length}人 / 経歴${arr(data?.career).length}件 / 更新 ${fmtTimestamp(data?.updatedAt) || '不明'}`;
  }
  async function conflictDetail(app, localData) {
    try {
      const path = app === 'speculum' ? '/api/speculum/load' : '/api/continuum/load';
      const j = await api(path);
      return `\n\nこの画面: ${dataSummaryForConflict(app, localData)}\n保存済み最新: ${dataSummaryForConflict(app, j.data || {})}`;
    } catch (_) {
      return '';
    }
  }
  async function resolveSaveConflict(app, data, baseHash, message, err) {
    const targetName = app === 'speculum' ? '今日・日付確認' : '作業管理';
    const detail = await conflictDetail(app, data);
    const keep = await askConfirm('別画面で更新されています', `${targetName}は別画面または別操作で更新されています。

上書きは行いません。今の画面内容を控えに残してから、保存済みの最新データを読み込みます。${detail}`, '控えを残して再読み込み', '閉じる');
    if (!keep) throw Object.assign(new Error('保存を中止しました'), {cancelled:true});
    try { await api('/api/backups/save-draft', {method:'POST', body:JSON.stringify({app, data})}); } catch (_) {}
    await loadData(); renderAll();
    toast('この画面の内容を控えに残して、最新データを再読み込みしました');
    throw Object.assign(new Error(''), {cancelled:true, handled:true, conflict:true, reloaded:true, source:err?.data || {}});
  }
  async function saveData(message = '保存しました') {
    DATA.updatedAt = new Date().toISOString();
    try {
      const j = await api('/api/speculum/save', {method:'POST', body:JSON.stringify({data:DATA, baseHash:HASH})});
      HASH = j.hash || HASH;
      OCCURRENCE_CACHE = {key:'', start:'', end:'', mode:'both', items:[]};
      notifyDataChanged('speculum', HASH);
      if (message) toast(message);
      return j;
    } catch (e) {
      if (e.status === 409 || e.data?.conflict) return resolveSaveConflict('speculum', DATA, HASH, message, e);
      throw e;
    }
  }
  async function saveWork(message = '作業管理へ保存しました') {
    WORK.updatedAt = new Date().toISOString();
    try {
      const j = await api('/api/continuum/save', {method:'POST', body:JSON.stringify({data:WORK, baseHash:WORK_HASH})});
      WORK_HASH = j.hash || WORK_HASH;
      notifyDataChanged('continuum', WORK_HASH);
      if (message) toast(message);
      return j;
    } catch (e) {
      if (e.status === 409 || e.data?.conflict) return resolveSaveConflict('continuum', WORK, WORK_HASH, message, e);
      throw e;
    }
  }
  function normalizeWorkStatus(v) {
    const s = clean(v).toLowerCase();
    if (['today','今日','今日やる'].includes(s)) return 'today';
    if (['waiting','wait','待ち','保留'].includes(s)) return 'waiting';
    if (['done','closed','完了'].includes(s)) return 'done';
    return 'next';
  }
  function normalizeWorkTaskClient(t) {
    const x = Object.assign({}, t || {});
    x.status = normalizeWorkStatus(x.status || 'next');
    x.personIds = arr(x.personIds);
    x.estimateMinutes = Math.max(0, Math.min(24 * 60, Math.round(Number(x.estimateMinutes || 0) || 0)));
    if (x.status !== 'done') delete x.completedAt;
    return x;
  }
  function upsertWorkTaskLocal(item, rebuildIndexes = true) {
    if (!item || !item.id) return;
    const obj = normalizeWorkTaskClient(item);
    const i = WORK.tasks.findIndex(x => x.id === obj.id);
    if (i >= 0) WORK.tasks[i] = obj; else WORK.tasks.push(obj);
    PERSON_RELATION_COUNTS_CACHE = null;
    if (rebuildIndexes) rebuildWorkLookupIndexes();
  }
  async function reloadWorkOnly() {
    const j = await api('/api/continuum/load');
    applyWork(j);
    return j;
  }
  async function saveWorkTaskItem(item, baseItemUpdatedAt = '') {
    try {
      const j = await api('/api/continuum/task-upsert', {method:'POST', body:JSON.stringify({item, baseHash:WORK_HASH, baseItemUpdatedAt})});
      WORK_HASH = j.hash || WORK_HASH;
      if (j.merged) await reloadWorkOnly();
      else upsertWorkTaskLocal(j.item || item);
      notifyDataChanged('continuum', WORK_HASH, 'tasks');
      return j;
    } catch (e) {
      if (e.status === 409 || e.data?.conflict) return resolveSaveConflict('continuum', WORK, WORK_HASH, '', e);
      throw e;
    }
  }
  async function deleteWorkTaskItems(ids = []) {
    const set = new Set(arr(ids).filter(Boolean));
    if (!set.size) return {ok:true, changed:false};
    const baseItems = WORK.tasks.filter(x => set.has(x.id)).map(x => ({id:x.id, updatedAt:x.updatedAt || ''}));
    try {
      const j = await api('/api/continuum/items-delete', {method:'POST', body:JSON.stringify({collection:'tasks', ids:[...set], baseHash:WORK_HASH, baseItems})});
      WORK_HASH = j.hash || WORK_HASH;
      if (j.merged) await reloadWorkOnly();
      else { WORK.tasks = WORK.tasks.filter(x => !set.has(x.id)); rebuildWorkLookupIndexes(); }
      notifyDataChanged('continuum', WORK_HASH, 'tasks');
      return j;
    } catch (e) {
      if (e.status === 409 || e.data?.conflict) return resolveSaveConflict('continuum', WORK, WORK_HASH, '', e);
      throw e;
    }
  }

  function baseItemsFromRecords(items = []) { return arr(items).map(x => ({id:x?.id, updatedAt:clean(x?.updatedAt || '')})).filter(x => clean(x.id)); }
  async function saveWorkTaskItems(items = [], baseItems = []) {
    const list = arr(items).filter(Boolean);
    if (!list.length) return {ok:true, items:[]};
    try {
      const j = await api('/api/continuum/items-upsert', {method:'POST', body:JSON.stringify({collection:'tasks', items:list, baseHash:WORK_HASH, baseItems})});
      WORK_HASH = j.hash || WORK_HASH;
      if (j.merged) await reloadWorkOnly();
      else {
        arr(j.items).forEach(item => upsertWorkTaskLocal(item, false));
        rebuildWorkLookupIndexes();
      }
      notifyDataChanged('continuum', WORK_HASH, 'tasks');
      return j;
    } catch (e) {
      if (e.status === 409 || e.data?.conflict) return resolveSaveConflict('continuum', WORK, WORK_HASH, '', e);
      throw e;
    }
  }
  async function reloadSpeculumOnly() {
    const j = await api('/api/speculum/load');
    applySpeculum(j);
    OCCURRENCE_CACHE = {key:'', start:'', end:'', mode:'both', items:[]};
    return j;
  }
  function upsertSpeculumLocal(collection, item, rebuildIndexes = true) {
    if (!item || !item.id) return;
    if (!Array.isArray(DATA[collection])) DATA[collection] = [];
    upsert(collection, item);
    PERSON_RELATION_COUNTS_CACHE = null;
    CASE_RELATION_COUNTS_CACHE = null;
    CASE_RENDER_GENERATION += 1;
    CASE_RENDER_SIGNATURE = '';
    if (collection === 'career' || collection === 'people') CAREER_SEARCH_TEXT_CACHE = new WeakMap();
    if (rebuildIndexes && (collection === 'people' || collection === 'cases')) rebuildSpeculumLookupIndexes();
    OCCURRENCE_CACHE = {key:'', start:'', end:'', mode:'both', items:[]};
  }
  function upsertSpeculumBatchLocal(collection, items = []) {
    const incoming = arr(items).filter(item => item && item.id);
    if (!incoming.length) return;
    if (!Array.isArray(DATA[collection])) DATA[collection] = [];
    const target = DATA[collection];
    const indexById = new Map(target.map((item, index) => [clean(item?.id), index]).filter(([id]) => !!id));
    incoming.forEach(item => {
      const id = clean(item.id);
      const index = indexById.get(id);
      if (index === undefined) { indexById.set(id, target.length); target.push(item); }
      else target[index] = item;
    });
    PERSON_RELATION_COUNTS_CACHE = null;
    CASE_RELATION_COUNTS_CACHE = null;
    CASE_RENDER_GENERATION += 1;
    CASE_RENDER_SIGNATURE = '';
    if (collection === 'career' || collection === 'people') CAREER_SEARCH_TEXT_CACHE = new WeakMap();
    if (collection === 'people' || collection === 'cases') rebuildSpeculumLookupIndexes();
    OCCURRENCE_CACHE = {key:'', start:'', end:'', mode:'both', items:[]};
  }
  function removeSpeculumLocal(collection, ids = []) {
    const set = new Set(arr(ids).filter(Boolean));
    if (!set.size || !Array.isArray(DATA[collection])) return;
    DATA[collection] = DATA[collection].filter(x => !set.has(x.id));
    PERSON_RELATION_COUNTS_CACHE = null;
    CASE_RELATION_COUNTS_CACHE = null;
    CASE_RENDER_GENERATION += 1;
    CASE_RENDER_SIGNATURE = '';
    if (collection === 'career' || collection === 'people') CAREER_SEARCH_TEXT_CACHE = new WeakMap();
    if (collection === 'people' || collection === 'cases') rebuildSpeculumLookupIndexes();
    OCCURRENCE_CACHE = {key:'', start:'', end:'', mode:'both', items:[]};
  }
  async function saveSpeculumPatch(patch = {}, message = '') {
    try {
      const j = await api('/api/speculum/patch', {method:'POST', body:JSON.stringify(Object.assign({baseHash:HASH}, patch || {}))});
      if (j.data) applySpeculum({data:j.data, hash:j.hash || HASH});
      else HASH = j.hash || HASH;
      OCCURRENCE_CACHE = {key:'', start:'', end:'', mode:'both', items:[]};
      notifyDataChanged('speculum', HASH, Object.keys(patch || {}).join(','));
      if (message) toast(message);
      return j;
    } catch (e) {
      if (e.status === 409 || e.data?.conflict) return resolveSaveConflict('speculum', DATA, HASH, message, e);
      throw e;
    }
  }
  async function saveSpeculumItem(collection, item, baseItemUpdatedAt = '') {
    try {
      const j = await api('/api/speculum/item-upsert', {method:'POST', body:JSON.stringify({collection, item, baseHash:HASH, baseItemUpdatedAt})});
      HASH = j.hash || HASH;
      if (j.merged) await reloadSpeculumOnly();
      else upsertSpeculumLocal(collection, j.item || item);
      notifyDataChanged('speculum', HASH, collection);
      return j;
    } catch (e) {
      if (e.status === 409 || e.data?.conflict) return resolveSaveConflict('speculum', DATA, HASH, '', e);
      throw e;
    }
  }
  async function saveSpeculumItems(collection, items = [], baseItems = []) {
    const list = arr(items).filter(Boolean);
    if (!list.length) return {ok:true, items:[]};
    try {
      const j = await api('/api/speculum/items-upsert', {method:'POST', body:JSON.stringify({collection, items:list, baseHash:HASH, baseItems})});
      HASH = j.hash || HASH;
      if (j.merged) await reloadSpeculumOnly();
      else upsertSpeculumBatchLocal(collection, j.items);
      notifyDataChanged('speculum', HASH, collection);
      return j;
    } catch (e) {
      if (e.status === 409 || e.data?.conflict) return resolveSaveConflict('speculum', DATA, HASH, '', e);
      throw e;
    }
  }
  async function deleteSpeculumItems(collection, ids = []) {
    const set = new Set(arr(ids).filter(Boolean));
    if (!set.size) return {ok:true, changed:false};
    const baseItems = arr(DATA[collection]).filter(x => set.has(x.id)).map(x => ({id:x.id, updatedAt:x.updatedAt || ''}));
    try {
      const j = await api('/api/speculum/items-delete', {method:'POST', body:JSON.stringify({collection, ids:[...set], baseHash:HASH, baseItems})});
      HASH = j.hash || HASH;
      if (j.merged) await reloadSpeculumOnly();
      else removeSpeculumLocal(collection, [...set]);
      notifyDataChanged('speculum', HASH, collection);
      return j;
    } catch (e) {
      if (e.status === 409 || e.data?.conflict) return resolveSaveConflict('speculum', DATA, HASH, '', e);
      throw e;
    }
  }
  async function deleteSpeculumItemWithUndo(collection, item, message = '削除しました') {
    if (!item?.id) return;
    const snapshot = cloneRecord(item);
    const deleted = await deleteSpeculumItems(collection, [item.id]);
    const restoreToken = clean(deleted?.restoreTokens?.[item.id] || deleted?.restoreToken);
    renderAll();
    toast(message, {actionLabel:'元に戻す', ms:8000, onAction:()=>restoreDataItemSnapshot(collection, snapshot, '削除した内容を元に戻しました', restoreToken)});
  }
  function toast(msg, opts = {}) {
    const t = $('toast');
    if (!t) return;
    t.innerHTML = '';
    const span = document.createElement('span');
    span.textContent = msg;
    t.appendChild(span);
    if (opts.actionLabel && typeof opts.onAction === 'function') {
      const b = document.createElement('button');
      b.type = 'button';
      b.className = 'toast-action';
      b.textContent = opts.actionLabel;
      b.onclick = async e => { e.preventDefault(); clearTimeout(toast._timer); t.classList.remove('show'); await opts.onAction(); };
      t.appendChild(b);
    }
    t.classList.add('show');
    clearTimeout(toast._timer);
    toast._timer = setTimeout(() => t.classList.remove('show'), opts.ms || 3600);
  }
  async function runUiAction(key, action, failureMessage = '更新できませんでした') {
    const lockKey = clean(key) || 'default';
    if (UI_ACTION_LOCKS.has(lockKey)) { toast('同じ処理を実行中です。完了までお待ちください'); return null; }
    UI_ACTION_LOCKS.add(lockKey);
    try { return await action(); }
    catch (err) {
      if (!err?.handled && !err?.cancelled) toast(err?.message || failureMessage);
      return null;
    } finally {
      UI_ACTION_LOCKS.delete(lockKey);
    }
  }
  function keepKeyboardFocus(event, container) {
    if (event.key !== 'Tab' || !container) return;
    const focusable = $$('button:not([disabled]),input:not([disabled]),textarea:not([disabled]),select:not([disabled]),a[href],[tabindex]:not([tabindex="-1"])', container)
      .filter(element => !element.hidden && element.getClientRects().length > 0);
    if (!focusable.length) { event.preventDefault(); container.focus?.(); return; }
    const first = focusable[0];
    const last = focusable[focusable.length - 1];
    if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
    else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
  }
  function askConfirm(title, message, okLabel = '実行する', cancelLabel = 'やめる') {
    return new Promise(resolve => {
      if (activeConfirmFinish) activeConfirmFinish(false);
      const returnFocus = document.activeElement instanceof HTMLElement ? document.activeElement : null;
      const back = document.createElement('div');
      back.className = 'center-confirm-backdrop';
      const section = document.createElement('section');
      section.className = 'center-confirm';
      section.setAttribute('role', 'dialog');
      section.setAttribute('aria-modal', 'true');
      const h = document.createElement('h2'); h.textContent = title;
      const p = document.createElement('p'); p.textContent = message;
      const actions = document.createElement('div'); actions.className = 'confirm-actions';
      const cancel = document.createElement('button'); cancel.type = 'button'; cancel.className = 'ghost'; cancel.textContent = cancelLabel;
      const ok = document.createElement('button'); ok.type = 'button'; ok.className = 'danger-confirm'; ok.textContent = okLabel;
      let settled = false;
      const done = v => {
        if (settled) return;
        settled = true;
        document.removeEventListener('keydown', onKey);
        if (activeConfirmFinish === done) activeConfirmFinish = null;
        back.remove();
        if (returnFocus?.isConnected) setTimeout(() => returnFocus.focus({preventScroll:true}), 0);
        resolve(v);
      };
      cancel.addEventListener('click', () => done(false));
      ok.addEventListener('click', () => done(true));
      back.addEventListener('click', e => { if (e.target === back) done(false); });
      const onKey = e => {
        if (!document.body.contains(back)) { document.removeEventListener('keydown', onKey); return; }
        if (e.key === 'Escape') { e.preventDefault(); done(false); return; }
        keepKeyboardFocus(e, section);
      };
      document.addEventListener('keydown', onKey);
      activeConfirmFinish = done;
      actions.append(cancel, ok); section.append(h, p, actions); back.append(section); document.body.append(back); cancel.focus();
    });
  }
  function fmtDate(ds) {
    if (!ds) return '';
    const d = new Date(ds + 'T00:00:00');
    if (Number.isNaN(d.getTime())) return ds;
    return `${d.getFullYear()}/${d.getMonth()+1}/${d.getDate()}(${['日','月','火','水','木','金','土'][d.getDay()]})`;
  }
  function fmtTimestamp(value) {
    const raw = clean(value);
    if (!raw) return '';
    const date = new Date(raw);
    if (Number.isNaN(date.getTime())) return raw.replace('T', ' ').replace(/:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:?\d{2})?$/, '').slice(0, 16).replace(/-/g, '/');
    const parts = Object.fromEntries(new Intl.DateTimeFormat('ja-JP', {
      timeZone:'Asia/Tokyo', year:'numeric', month:'2-digit', day:'2-digit', hour:'2-digit', minute:'2-digit', hourCycle:'h23'
    }).formatToParts(date).map(part => [part.type, part.value]));
    return `${parts.year}/${parts.month}/${parts.day} ${parts.hour}:${parts.minute}`;
  }
  function calendarDayDiff(ds) {
    ensureDateDiffCaches();
    const key = clean(ds);
    if (!key) return null;
    if (CALENDAR_DAY_DIFF_CACHE.has(key)) return CALENDAR_DAY_DIFF_CACHE.get(key);
    const a = new Date(today() + 'T00:00:00');
    const b = new Date(key + 'T00:00:00');
    const value = Number.isNaN(b.getTime()) ? null : Math.round((b - a) / 86400000);
    CALENDAR_DAY_DIFF_CACHE.set(key, value);
    return value;
  }
  function businessDayDiff(ds) {
    ensureDateDiffCaches();
    const key = clean(ds);
    if (!key) return null;
    if (BUSINESS_DAY_DIFF_CACHE.has(key)) return BUSINESS_DAY_DIFF_CACHE.get(key);
    const target = dateObj(key);
    const base = dateObj(today());
    if (!target || !base) { BUSINESS_DAY_DIFF_CACHE.set(key, null); return null; }
    const cd = calendarDayDiff(key);
    if (cd === null) { BUSINESS_DAY_DIFF_CACHE.set(key, null); return null; }
    if (cd === 0) { BUSINESS_DAY_DIFF_CACHE.set(key, 0); return 0; }
    let count = 0;
    if (cd > 0) {
      const cur = new Date(base);
      while (true) {
        cur.setDate(cur.getDate() + 1);
        if (cur > target) break;
        if (!isClosedCalendarDay(isoFromDate(cur))) count++;
      }
      BUSINESS_DAY_DIFF_CACHE.set(key, count);
      return count;
    }
    const cur = new Date(target);
    while (true) {
      cur.setDate(cur.getDate() + 1);
      if (cur > base) break;
      if (!isClosedCalendarDay(isoFromDate(cur))) count++;
    }
    BUSINESS_DAY_DIFF_CACHE.set(key, -count);
    return -count;
  }
  function resetDateDiffCaches() {
    DATE_DIFF_CACHE_DAY = today();
    CALENDAR_DAY_DIFF_CACHE.clear();
    BUSINESS_DAY_DIFF_CACHE.clear();
  }
  function ensureDateDiffCaches() {
    if (DATE_DIFF_CACHE_DAY !== today()) resetDateDiffCaches();
  }
  function dayContextCheckDelay() {
    const now = new Date();
    const next = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1, 0, 0, 0, 250);
    const untilBoundary = next.getTime() - now.getTime();
    // 日付変更だけでなく、スリープ復帰・手動の日付変更も遅くとも1分以内に拾う。
    return Math.max(1000, Math.min(60000, Number.isFinite(untilBoundary) ? untilBoundary : 60000));
  }
  function scheduleDayContextCheck() {
    clearTimeout(DAY_CONTEXT_TIMER);
    DAY_CONTEXT_TIMER = setTimeout(() => {
      refreshDayContextIfNeeded().finally(scheduleDayContextCheck);
    }, dayContextCheckDelay());
  }
  async function refreshDayContextIfNeeded() {
    if (DAY_CONTEXT_REFRESH) return DAY_CONTEXT_REFRESH;
    const nextDay = today();
    const dayChanged = ACTIVE_DAY !== nextDay;
    const memoNeedsSwitch = MEMO_DRAFT_DAY !== nextDay;
    if (!dayChanged && !memoNeedsSwitch) return false;
    DAY_CONTEXT_REFRESH = (async () => {
      const previousDay = ACTIVE_DAY;
      ACTIVE_DAY = nextDay;
      if (dayChanged) {
        const previousDate = dateObj(previousDay);
        if (previousDate && calCursor.getFullYear() === previousDate.getFullYear() && calCursor.getMonth() === previousDate.getMonth()) calCursor = new Date();
        resetDateDiffCaches();
        OCCURRENCE_CACHE = {key:'', start:'', end:'', mode:'both', items:[]};
        invalidateTodaySummary();
        invalidateViewRenderCache();
      }

      let memoSwitched = false;
      if (MEMO_DRAFT_DAY !== nextDay && DATA?.memo) {
        // 23時台に入力した内容は、保存タイマーが午前0時を越えても前日へ残す。
        if (MEMO_DRAFT_DIRTY || MEMO_SAVE_RUNNING) await saveMemos('');
        if (!MEMO_DRAFT_DIRTY && !MEMO_SAVE_RUNNING) {
          DATA.memo.today = Object.prototype.hasOwnProperty.call(DATA.memo.days || {}, nextDay) ? String(DATA.memo.days[nextDay] || '') : '';
          DATA.memo.todayDate = nextDay;
          syncMemoInputsFromData(true);
          updateMemoPreview();
          renderMemoHistory();
          memoSwitched = true;
        }
      }
      if (dayChanged || (memoSwitched && currentView === 'today')) renderCurrentView();
      return dayChanged || memoSwitched;
    })().finally(() => { DAY_CONTEXT_REFRESH = null; });
    return DAY_CONTEXT_REFRESH;
  }
  function dayDiff(ds) {
    return dueDayCountMode === 'calendar' ? calendarDayDiff(ds) : businessDayDiff(ds);
  }
  function dueLabel(ds) {
    const cal = calendarDayDiff(ds);
    const diff = dayDiff(ds);
    if (cal === null || diff === null) return '';
    if (dueDayCountMode === 'calendar') {
      if (diff < 0) return `${Math.abs(diff)}日超過`;
      if (diff === 0) return '今日';
      if (diff === 1) return '明日';
      return `あと${diff}日`;
    }
    if (cal === 0) return '今日';
    if (cal < 0) return diff === 0 ? '超過（0営業日）' : `${Math.abs(diff)}営業日超過`;
    return `あと${Math.max(0, diff)}営業日`;
  }
  function estimateMinutes(item) {
    const raw = (item && typeof item === 'object') ? (item.estimateMinutes ?? item.durationMinutes ?? item.minutes ?? 0) : item;
    const n = Number(raw || 0);
    return Number.isFinite(n) && n > 0 ? Math.min(24 * 60, Math.round(n)) : 0;
  }
  function durationLabel(itemOrMinutes) {
    const m = typeof itemOrMinutes === 'number' ? estimateMinutes(itemOrMinutes) : estimateMinutes(itemOrMinutes || 0);
    if (!m) return '';
    const h = Math.floor(m / 60);
    const mm = m % 60;
    if (h && mm) return `${h}時間${mm}分`;
    if (h) return `${h}時間`;
    return `${mm}分`;
  }
  function totalEstimate(items) { return arr(items).reduce((sum, x) => sum + estimateMinutes(x), 0); }
  function estimateMeta(item) { const lab = durationLabel(item); return lab ? `見積 ${lab}` : ''; }
  function eventTimeLabel(e) {
    const start = clean(e?.time);
    const end = clean(e?.endTime);
    if (start && end) return `${start}〜${end}`;
    if (start && estimateMinutes(e)) return `${start} / 所要${durationLabel(e)}`;
    return start || '';
  }
  function holidayDataAvailable() { return Object.keys(DATA?.holidays?.items || {}).length > 0; }
  function dueCountModeText() { return dueDayCountMode === 'calendar' ? '土日祝含む日数' : '平日のみ（土日祝除く）'; }
  function dueCountModeNote() {
    if (dueDayCountMode === 'calendar') return '現在：土日祝日を含めた暦日数で表示しています。';
    return holidayDataAvailable() ? '現在：土日祝日を除いた実稼働日数で表示しています。' : '現在：平日のみで表示しています。祝日データ未取得時は土日のみ除外します。';
  }
  function syncDueCountModeControls() {
    $$('[data-due-count-mode]').forEach(el => { el.value = dueDayCountMode; });
    $$('[data-due-count-mode-note]').forEach(el => { el.textContent = dueCountModeNote(); });
  }
  async function saveDueCountMode() {
    DATA.settings = Object.assign({}, DATA.settings || {}, {dueDayCountMode});
    await saveSpeculumPatch({settings:DATA.settings}, '');
  }
  function setDueDayCountMode(mode) {
    dueDayCountMode = mode === 'calendar' ? 'calendar' : 'business';
    syncDueCountModeControls();
    saveDueCountMode().catch(err => { if (!err?.handled && !err?.cancelled) toast(err?.message || '日数の表示設定を保存できませんでした'); });
    renderAll();
    toast(dueDayCountMode === 'calendar' ? '期限までの日数を土日祝含む日数で表示します' : '期限までの日数を実稼働日数で表示します');
  }
  const CAREER_MONEY_KEYS = new Set(['annualIncome', 'income', 'withholdingIncomeTax']);
  function formatNumberToken(value) {
    const raw = String(value ?? '').replace(/,/g, '');
    if (!/^[+-]?\d+(?:\.\d+)?$/.test(raw)) return String(value ?? '');
    const sign = raw.startsWith('-') || raw.startsWith('+') ? raw.slice(0, 1) : '';
    const body = sign ? raw.slice(1) : raw;
    const [intPart, decPart] = body.split('.');
    const formattedInt = intPart.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    return sign + formattedInt + (decPart !== undefined ? `.${decPart}` : '');
  }
  function formatMoneyText(value) {
    const s = clean(value);
    if (!s) return '';
    return s.replace(/[+-]?\d[\d,]*(?:\.\d+)?/g, (m) => formatNumberToken(m));
  }
  function moneyPlain(value) { return clean(value).replace(/,/g, ''); }
  function personName(id) {
    const p = PERSON_BY_ID.get(clean(id));
    return p ? p.name : '';
  }
  function personById(id) { return PERSON_BY_ID.get(clean(id)) || null; }
  function personMeta(p) { return [p?.kind, p?.term].map(clean).filter(Boolean).join('・'); }
  function personRetirementLabel(p) {
    const ds = clean(canonicalValue(p, 'retiredAt', 'retirementDate', 'leftAt'));
    if (ds) return `退職 ${fmtDate(ds)}`;
    return p?.retired ? '退職者' : '';
  }
  function personDisplay(p) {
    if (!p) return '';
    const meta = personMeta(p);
    return `${p.name || '無名の人物'}${meta ? `（${meta}）` : ''}`;
  }
  function personCandidateDisplay(p) {
    const retired = personRetirementLabel(p);
    return `${personDisplay(p)}${retired ? ` / ${retired}` : ''}`;
  }
  function parseSortNumber(value) {
    const s = clean(value).replace(/[，,]/g, '');
    if (!s) return null;
    const n = Number(s);
    return Number.isFinite(n) ? n : null;
  }
  function personCourse(p) {
    const s = `${p?.kind || ''} ${p?.term || ''}`;
    if (/専科|専門科/.test(s)) return 'senka';
    if (/普通科|普科|普通/.test(s)) return 'futsu';
    return '';
  }
  function personTermNumber(p) {
    const chunks = [p?.term, p?.kind, `${p?.kind || ''} ${p?.term || ''}`].map(clean).filter(Boolean);
    for (const chunk of chunks) {
      let m = chunk.match(/(\d+(?:\.\d+)?)\s*期/);
      if (!m) m = chunk.match(/^(\d+(?:\.\d+)?)$/);
      if (!m) m = chunk.match(/(?:普通科|普科|専科|専門科)?\s*(\d+(?:\.\d+)?)/);
      if (m) {
        const n = Number(m[1]);
        if (Number.isFinite(n)) return n;
      }
    }
    return null;
  }
  function personEquivalentCohort(p) {
    const n = personTermNumber(p);
    if (n === null) return null;
    return personCourse(p) === 'senka' ? n + 29 : n;
  }
  function personManualOrder(p) { return parseSortNumber(p?.displayOrder ?? p?.sortOrder ?? ''); }
  function personSortValue(p, fallbackIndex = 0) {
    const manual = personManualOrder(p);
    if (manual !== null) return manual;
    const cohort = personEquivalentCohort(p);
    if (cohort !== null) return cohort;
    const created = Date.parse(p?.createdAt || p?.updatedAt || '');
    if (Number.isFinite(created)) return 900000 + Math.floor(created / 100000000);
    return 990000 + fallbackIndex;
  }
  function personKindTie(p) {
    const c = personCourse(p);
    if (c === 'futsu') return 1;
    if (c === 'senka') return 2;
    return 9;
  }
  function personCompareWrapped(a, b) {
    const av = personSortValue(a.p, a.i);
    const bv = personSortValue(b.p, b.i);
    return av - bv
      || personKindTie(a.p) - personKindTie(b.p)
      || (personTermNumber(a.p) ?? 999999) - (personTermNumber(b.p) ?? 999999)
      || clean(a.p?.name).localeCompare(clean(b.p?.name), 'ja')
      || a.i - b.i;
  }
  function peopleSorted(items = DATA.people) {
    if (items === DATA.people) {
      if (!SORTED_PEOPLE_CACHE) SORTED_PEOPLE_CACHE = arr(items).map((p, i) => ({p, i})).sort(personCompareWrapped).map(x => x.p);
      return SORTED_PEOPLE_CACHE.slice();
    }
    return arr(items).map((p, i) => ({p, i})).sort(personCompareWrapped).map(x => x.p);
  }
  function sortPersonIds(ids) {
    if (!PERSON_ORDER_BY_ID) PERSON_ORDER_BY_ID = new Map(peopleSorted(DATA.people).map((p, i) => [p.id, i]));
    return arr(ids).slice().sort((a, b) => (PERSON_ORDER_BY_ID.get(a) ?? 999999) - (PERSON_ORDER_BY_ID.get(b) ?? 999999));
  }
  function formatSortNumber(n) { return Number.isInteger(n) ? String(n) : String(n).replace(/\.?0+$/, ''); }
  function personSortMeta(p) {
    const manual = personManualOrder(p);
    if (manual !== null) return `表示順 ${formatSortNumber(manual)}`;
    const cohort = personEquivalentCohort(p);
    if (cohort === null) return '';
    return personCourse(p) === 'senka' ? `同期換算 普通科${formatSortNumber(cohort)}期相当` : `同期換算 ${formatSortNumber(cohort)}期`;
  }
  function findPersonByName(name) {
    const n = clean(name);
    if (!n) return null;
    return PERSON_BY_NAME.get(n) || null;
  }
  function personDisplayFromIdOrName(value) {
    const v = clean(value);
    if (!v) return '';
    const byId = personById(v);
    if (byId) return personDisplay(byId);
    const byName = findPersonByName(v);
    if (byName) return personDisplay(byName);
    return v;
  }
  function uniqueIds(ids) {
    const seen = new Set(); const out = [];
    arr(ids).forEach(id => { const v = clean(id); if (v && personById(v) && !seen.has(v)) { seen.add(v); out.push(v); } });
    return out;
  }
  function splitStaffLines(value) {
    if (Array.isArray(value)) return value.map(clean).filter(Boolean);
    return String(value || '').split(/\r?\n|、|,/).map(clean).filter(Boolean);
  }
  function selectedSingleStaffId(v, idKey, textKey) {
    const stored = clean(v[idKey]);
    if (stored && personById(stored)) return stored;
    const byName = findPersonByName(v[textKey]);
    return byName ? byName.id : '';
  }
  function selectedMultiStaffIds(v, idKey, textKey) {
    const ids = uniqueIds(v[idKey]);
    splitStaffLines(v[textKey]).forEach(name => { const p = findPersonByName(name); if (p) ids.push(p.id); });
    return uniqueIds(ids);
  }
  function manualStaffText(v, textKey, selectedIds) {
    const picked = uniqueIds(selectedIds);
    const selectedNames = new Set(picked.map(id => clean(personName(id))));
    return splitStaffLines(v[textKey]).filter(name => {
      const p = findPersonByName(name);
      if (p && picked.includes(p.id)) return false;
      return !selectedNames.has(clean(name));
    }).join('\n');
  }
  function singleCareerStaffDisplay(c, textKey, idKey) {
    const id = selectedSingleStaffId(c, idKey, textKey);
    if (id) return personDisplay(personById(id));
    return personDisplayFromIdOrName(c[textKey]);
  }
  function multiCareerStaffDisplay(c, textKey, idKey) {
    const ids = sortPersonIds(selectedMultiStaffIds(c, idKey, textKey));
    const seenNames = new Set(ids.map(id => clean(personName(id))));
    const out = ids.map(id => personDisplay(personById(id))).filter(Boolean);
    splitStaffLines(c[textKey]).forEach(name => {
      const p = findPersonByName(name);
      if (p) {
        if (!ids.includes(p.id)) out.push(personDisplay(p));
      } else if (!seenNames.has(clean(name))) {
        out.push(name);
      }
    });
    return out.join('\n');
  }
  function careerDepartments(c = {}) {
    const canonicalPresent = Array.isArray(c.departments);
    let raw = canonicalPresent ? c.departments : [];
    if (!canonicalPresent) {
      raw = [{
        id:`${clean(c.id) || 'career'}_department_1`,
        name:clean(c.division),
        manager:clean(c.manager),
        managerPersonId:clean(c.managerPersonId),
        staff:splitStaffLines(c.departmentStaff),
        staffPersonIds:uniqueIds(c.departmentStaffPersonIds)
      }];
      const related = {
        id:`${clean(c.id) || 'career'}_department_2`,
        name:clean(c.relatedDepartmentName || c.relatedDepartment || c.relatedDivision),
        manager:clean(c.relatedManager),
        managerPersonId:clean(c.relatedManagerPersonId),
        staff:splitStaffLines(c.relatedStaff),
        staffPersonIds:uniqueIds(c.relatedStaffPersonIds)
      };
      if (related.name || related.manager || related.managerPersonId || related.staff.length || related.staffPersonIds.length) raw.push(related);
    }
    if (!raw.length) raw = [{}];
    const recordId = clean(c.id) || 'career';
    return raw.map((value, index) => {
      const d = value && typeof value === 'object' ? value : {};
      const own = (key, aliases = []) => {
        if (Object.prototype.hasOwnProperty.call(d, key)) return d[key];
        for (const alias of aliases) if (Object.prototype.hasOwnProperty.call(d, alias)) return d[alias];
        return '';
      };
      return {
        id:clean(d.id) || `${recordId}_department_${index + 1}`,
        kind:index === 0 ? 'current' : 'additional',
        name:clean(own('name', ['departmentName','division'])),
        manager:clean(own('manager', ['responsiblePerson','leader'])),
        managerPersonId:clean(own('managerPersonId', ['responsiblePersonId','leaderPersonId'])),
        staff:splitStaffLines(own('staff', ['members','departmentStaff'])),
        staffPersonIds:uniqueIds(own('staffPersonIds', ['memberPersonIds','departmentStaffPersonIds']))
      };
    });
  }
  function careerDepartmentManagerDisplay(d) {
    return singleCareerStaffDisplay(d, 'manager', 'managerPersonId');
  }
  function careerDepartmentStaffDisplay(d) {
    return multiCareerStaffDisplay(d, 'staff', 'staffPersonIds');
  }
  function careerDepartmentLabel(d, index) {
    return clean(d.name) || (index === 0 ? '部門名未入力' : `追加部門 ${index}`);
  }
  function careerDepartmentNamesDisplay(c) {
    return careerDepartments(c).map((d,index) => `${index === 0 ? '今の部門' : `追加部門 ${index}`}：${careerDepartmentLabel(d,index)}`).join('\n');
  }
  function careerDepartmentManagersDisplay(c) {
    return careerDepartments(c).map((d,index) => `${careerDepartmentLabel(d,index)}：${careerDepartmentManagerDisplay(d) || '未入力'}`).join('\n');
  }
  function careerDepartmentStaffsDisplay(c) {
    return careerDepartments(c).map((d,index) => {
      const staff = careerDepartmentStaffDisplay(d).replace(/\n/g, '、');
      return `${careerDepartmentLabel(d,index)}：${staff || '未入力'}`;
    }).join('\n');
  }
  function careerPersonIds(c) {
    const departmentIds = careerDepartments(c).flatMap(d => [
      selectedSingleStaffId(d, 'managerPersonId', 'manager'),
      ...selectedMultiStaffIds(d, 'staffPersonIds', 'staff')
    ]);
    return uniqueIds([selectedSingleStaffId(c, 'reviewOfficerPersonId', 'reviewOfficer'), ...departmentIds, ...arr(c.personIds)]);
  }
  function caseName(id) {
    const c = CASE_BY_ID.get(clean(id));
    return c ? (c.title || c.name) : '';
  }
  function peopleLabel(item) {
    const names = sortPersonIds(arr(item.personIds)).map(personName).filter(Boolean);
    return names.length ? names.join('、') : '';
  }
  function personRelationCountIndex() {
    if (PERSON_RELATION_COUNTS_CACHE) return PERSON_RELATION_COUNTS_CACHE;
    const counts = new Map(DATA.people.map(p => [p.id, {events:0, deadlines:0, jimu:0, career:0, tasks:0}]));
    const bump = (ids, key) => {
      const seen = new Set(arr(ids).filter(Boolean));
      seen.forEach(id => { const row = counts.get(id); if (row) row[key] += 1; });
    };
    DATA.events.forEach(x => bump(x.personIds, 'events'));
    DATA.deadlines.forEach(x => bump(x.personIds, 'deadlines'));
    DATA.jimu.forEach(x => bump(x.personIds, 'jimu'));
    DATA.career.forEach(x => bump(careerPersonIds(x), 'career'));
    WORK.tasks.forEach(x => bump(x.personIds, 'tasks'));
    PERSON_RELATION_COUNTS_CACHE = counts;
    return PERSON_RELATION_COUNTS_CACHE;
  }
  function sourceId(collection, id) { return `speculum:${collection}:${id}`; }
  function workTaskForSource(collection, id) {
    const sid = sourceId(collection, id);
    return WORK_TASK_BY_SOURCE.get(sid);
  }
  function itemTitle(item) { return clean(item.title || item.name || item.url) || '無題'; }
  function makeButtonAction(a) {
    const b = document.createElement('button');
    b.type = 'button';
    b.className = a.className || 'mini';
    b.textContent = a.label;
    b.addEventListener('click', a.onClick);
    return b;
  }
  function actionMenuHost(details) {
    return details.closest?.('.card, .item, .case-card, .target-case-card');
  }
  function interactiveCardTarget(target) {
    return !!target?.closest?.('button, select, input, textarea, label, summary, details, a, [role="button"], .card-actions, .card-more, .action-menu');
  }
  function closeActionMenus(except = null) {
    $$('.card-more[open], .action-menu[open]').forEach(menu => { if (menu !== except) menu.open = false; });
  }
  function wireActionMenu(details) {
    if (!details) return details;
    details.addEventListener('toggle', () => {
      actionMenuHost(details)?.classList.toggle('menu-open', details.open);
      if (details.open) closeActionMenus(details);
    });
    details.addEventListener('click', ev => ev.stopPropagation());
    details.querySelector('.more-menu, .action-menu-body')?.addEventListener('click', ev => ev.stopPropagation());
    return details;
  }
  function compactActionMenu(actions, label = '⋯') {
    const details = document.createElement('details');
    details.className = 'card-more action-menu';
    const summary = document.createElement('summary');
    summary.textContent = label;
    summary.setAttribute('aria-label', 'その他の操作');
    details.appendChild(summary);
    const menu = document.createElement('div');
    menu.className = 'more-menu action-menu-body';
    actions.filter(Boolean).forEach(a => {
      const b = makeButtonAction(a);
      b.addEventListener('click', () => { details.open = false; });
      menu.appendChild(b);
    });
    details.appendChild(menu);
    return wireActionMenu(details);
  }
  function metaClass(value) {
    const s = clean(value);
    const cls = ['meta-chip'];
    if (/超過|期限切れ|危険|未取得|見つかりません|エラー|3か月/.test(s)) cls.push('meta-danger');
    if (/^\d{4}\/|^\d{1,2}\/|今日|明日|明後日|次回|着手|完了|終了|前回|あと\d+|営業日|日以内/.test(s)) cls.push('meta-date');
    if (/高優先|低優先|重要|priority|high|low|normal|通常/.test(s)) cls.push('meta-priority');
    if (/担当|関係者|人物|さん$/.test(s)) cls.push('meta-person');
    if (/事案|調査|同事案/.test(s)) cls.push('meta-case');
    if (CASE_STATUSES.includes(s) || /^(active|today|next|waiting|done|継続中|休止中|終了済|待ち状態)$/.test(s)) cls.push('meta-status');
    if (/次:|次の一手|作業済|元データ|リンク|見積|時間|分/.test(s)) cls.push('meta-note');
    return cls.join(' ');
  }
  function metaHtml(parts) {
    return parts.filter(Boolean).map(x => `<span class="${metaClass(x)}">${esc(x)}</span>`).join('');
  }
  function itemNode(item, metaParts, actions = [], status = '') {
    const node = document.createElement('div');
    node.className = `item ${status}`.trim();
    if (item && item.id) {
      node.dataset.recordId = clean(item.id);
      node.dataset.recordTitle = itemTitle(item);
    }
    node.innerHTML = `<div><div class="item-title">${esc(itemTitle(item))}</div><div class="item-meta">${metaHtml(metaParts)}</div></div><div class="item-actions"></div>`;
    const box = node.querySelector('.item-actions');
    const safeActions = actions.filter(Boolean);
    if (safeActions.length <= 2) {
      safeActions.forEach(a => box.appendChild(makeButtonAction(a)));
    } else {
      const direct = [safeActions[0], ...safeActions.slice(1).filter(action => action.expose)];
      const folded = safeActions.slice(1).filter(action => !action.expose);
      direct.forEach(action => box.appendChild(makeButtonAction(action)));
      if (folded.length) box.appendChild(compactActionMenu(folded));
    }
    return node;
  }
  function emptyNode(text) { const d = document.createElement('div'); d.className = 'empty'; d.textContent = text; return d; }
  function setList(id, nodes, emptyText) {
    const box = $(id); if (!box) return;
    const fragment = document.createDocumentFragment();
    if (!nodes.length) fragment.appendChild(emptyNode(emptyText));
    else nodes.forEach(n => fragment.appendChild(n));
    box.replaceChildren(fragment);
  }

  function calendarKind(item) {
    const raw = clean(typeof item === 'string' ? item : (item?.calendarKind ?? item?.eventKind ?? item?.type ?? item?.kind ?? ''));
    const low = raw.toLowerCase();
    return (['happening','occurrence','diary'].includes(low) || ['出来事','できごと','出来ごと','日記'].includes(raw)) ? 'happening' : 'schedule';
  }
  function calendarKindLabel(item) { return calendarKind(item) === 'happening' ? '出来事' : '予定'; }
  function calendarKindClass(item) { return calendarKind(item) === 'happening' ? 'happening' : 'schedule'; }
  function calendarModeMatches(item) {
    if (calendarItemMode === 'both') return true;
    return calendarKind(item) === calendarItemMode;
  }
  function scheduleShiftLabel(e) {
    if (!e || !e._shifted || !e._baseDate) return '';
    return `元の予定日 ${fmtDate(e._baseDate)} から平日調整`;
  }

  function dueItems(includeWork = true) {
    const out = [];
    DATA.deadlines.forEach(x => { if (!isDone(x)) out.push({...x, collection:'deadlines', label:'期限', due:x.due, sourceType:'spec'}); });
    DATA.jimu.forEach(x => { if (!isDone(x)) out.push({...x, collection:'jimu', label:'事務', due:x.due, sourceType:'spec'}); });
    if (includeWork) WORK.tasks.forEach(x => { if (!isDone(x) && x.due) out.push({...x, collection:'work', label:'作業', due:x.due, sourceType:'work'}); });
    return out;
  }
  function caseRelations(caseId) {
    return {
      events: DATA.events.filter(x => x.caseId === caseId),
      deadlines: DATA.deadlines.filter(x => x.caseId === caseId),
      jimu: DATA.jimu.filter(x => x.caseId === caseId),
      tasks: WORK.tasks.filter(x => x.caseId === caseId || clean(x.source) === sourceId('cases', caseId))
    };
  }
  function caseRelationCountIndex() {
    if (CASE_RELATION_COUNTS_CACHE) return CASE_RELATION_COUNTS_CACHE;
    const counts = new Map(DATA.cases.map(item => [item.id, {events:0, deadlines:0, jimu:0, tasks:0}]));
    const bump = (caseId, key) => {
      const row = counts.get(clean(caseId));
      if (row) row[key] += 1;
    };
    DATA.events.forEach(item => bump(item.caseId, 'events'));
    DATA.deadlines.forEach(item => bump(item.caseId, 'deadlines'));
    DATA.jimu.forEach(item => bump(item.caseId, 'jimu'));
    WORK.tasks.forEach(item => {
      let caseId = clean(item.caseId);
      if (!caseId) {
        const match = clean(item.source).match(/^speculum:cases:(.+)$/);
        if (match) caseId = match[1];
      }
      bump(caseId, 'tasks');
    });
    CASE_RELATION_COUNTS_CACHE = counts;
    return CASE_RELATION_COUNTS_CACHE;
  }
  function personRelations(pid) {
    return {
      events: DATA.events.filter(x => arr(x.personIds).includes(pid)),
      deadlines: DATA.deadlines.filter(x => arr(x.personIds).includes(pid)),
      jimu: DATA.jimu.filter(x => arr(x.personIds).includes(pid)),
      career: DATA.career.filter(x => careerPersonIds(x).includes(pid)),
      tasks: WORK.tasks.filter(x => arr(x.personIds).includes(pid))
    };
  }
  function referenceSummary(rows = []) {
    return rows.filter(([,count]) => count > 0).map(([label,count]) => `${label}${count}件`).join('、');
  }
  function personDeletionReferences(personId) {
    const hasPerson = item => arr(item?.personIds).includes(personId);
    const rows = [
      ['予定・出来事', DATA.events.filter(hasPerson).length],
      ['期限', DATA.deadlines.filter(hasPerson).length],
      ['事務', DATA.jimu.filter(hasPerson).length],
      ['事案', DATA.cases.filter(hasPerson).length],
      ['経歴', DATA.career.filter(item => careerPersonIds(item).includes(personId)).length],
      ['作業', [...WORK.tasks, ...WORK.cycleTasks].filter(hasPerson).length]
    ];
    return {rows, total:rows.reduce((sum, [,count]) => sum + count, 0)};
  }
  function workReferencesCase(item, caseId) {
    const source = clean(item?.source);
    return clean(item?.caseId) === caseId
      || source === sourceId('cases', caseId)
      || source.startsWith(`speculum:case-target:${caseId}:`);
  }
  function caseDeletionReferences(caseId) {
    const rows = [
      ['予定・出来事', DATA.events.filter(item => clean(item.caseId) === caseId).length],
      ['期限', DATA.deadlines.filter(item => clean(item.caseId) === caseId).length],
      ['事務', DATA.jimu.filter(item => clean(item.caseId) === caseId).length],
      ['作業', [...WORK.tasks, ...WORK.cycleTasks].filter(item => workReferencesCase(item, caseId)).length]
    ];
    return {rows, total:rows.reduce((sum, [,count]) => sum + count, 0)};
  }
  function preventReferencedPersonDeletion(person) {
    const refs = personDeletionReferences(clean(person?.id));
    if (!refs.total) return false;
    toast(`この人物は${referenceSummary(refs.rows)}で使われているため削除できません。退職者は退職日を登録し、誤った紐付けは先に各項目の関係者から外してください`, {ms:8000});
    return true;
  }
  function preventReferencedCaseDeletion(item) {
    const refs = caseDeletionReferences(clean(item?.id));
    if (!refs.total) return false;
    toast(`この事案は${referenceSummary(refs.rows)}で使われているため削除できません。終了した事案は進行状態を「完了」にし、誤った紐付けは先に各項目から外してください`, {ms:8000});
    return true;
  }
  function preventReferencedCaseTargetDeletion(caseId, targetId) {
    const source = `speculum:case-target:${clean(caseId)}:${clean(targetId)}`;
    const count = [...WORK.tasks, ...WORK.cycleTasks].filter(item => clean(item?.source) === source).length;
    if (!count) return false;
    toast(`この対象者カードは作業${count}件と連携しているため削除できません。作業管理で連携中の作業を削除するか、連携を外してから削除してください`, {ms:8000});
    return true;
  }
  function preventLinkedSourceDeletion(collection, item, label = '項目') {
    const source = sourceId(collection, clean(item?.id));
    const taskCount = WORK.tasks.filter(task => clean(task?.source) === source).length;
    const cycleCount = WORK.cycleTasks.filter(task => clean(task?.source) === source).length;
    if (!taskCount && !cycleCount) return false;
    const linked = referenceSummary([['作業', taskCount], ['周期作業', cycleCount]]);
    toast(`この${label}は${linked}と連携しているため削除できません。作業管理で連携を外すか、連携中の作業を削除してから削除してください`, {ms:8000});
    return true;
  }
  function caseTargets(c) {
    const raw = arr(c.targetPersons || c.targets).filter(x => x && typeof x === 'object');
    const fallback = {status:normalizeCaseStatus(c.status), startedAt:c.startedAt || '', nextDate:c.nextDate || '', owner:c.owner || '', priority:c.priority || 'normal', nextAction:c.nextAction || ''};
    if (raw.length) return raw.map(x => {
      const hasTargetStatus = !!clean(x.status);
      const status = normalizeCaseStatus(x.status || fallback.status);
      let startedAt = clean(canonicalValue(x, 'startedAt', 'startDate') || (hasTargetStatus ? '' : fallback.startedAt));
      if (CASE_STARTED.has(status) && !startedAt) startedAt = today();
      return {
        id:clean(x.id)||uid('tg'),
        name:clean(x.name || x.title || x.client),
        role:clean(x.role),
        status,
        startedAt,
        nextDate:clean(x.nextDate || fallback.nextDate),
        owner:clean(x.owner || fallback.owner),
        priority:clean(x.priority || fallback.priority) || 'normal',
        nextAction:clean(x.nextAction || fallback.nextAction),
        note:clean(x.note)
      };
    }).filter(x => x.name);
    const legacy = arr(c.subjects).map(x => clean(x)).filter(Boolean);
    if (legacy.length) return legacy.map(name => ({id:uid('tg'), name, role:'', status:fallback.status, startedAt:fallback.startedAt, nextDate:fallback.nextDate, owner:fallback.owner, priority:fallback.priority, nextAction:fallback.nextAction, note:''}));
    const client = clean(c.client);
    return client ? [{id:uid('tg'), name:client, role:'', status:fallback.status, startedAt:fallback.startedAt, nextDate:fallback.nextDate, owner:fallback.owner, priority:fallback.priority, nextAction:fallback.nextAction, note:''}] : [];
  }
  function caseTargetNames(c) { return caseTargets(c).map(x => x.name).join('、'); }
  function caseTargetText(c) { return caseTargets(c).map(x => [x.name, x.role, x.status, x.startedAt, x.nextDate, x.nextAction, x.note].map(v => clean(v)).join('、')).join('\n'); }
  function parseCaseTargetText(text, existingOrDefaults = {}, maybeDefaults = null) {
    const existing = Array.isArray(existingOrDefaults) ? existingOrDefaults : [];
    const defaults = maybeDefaults || (Array.isArray(existingOrDefaults) ? {} : existingOrDefaults);
    return String(text || '').split(/\r?\n/).map(line => line.trim()).filter(Boolean).map(line => {
      const cols = line.split(/\t|,|、/).map(clean);
      const name = cols[0] || '';
      const prev = existing.find(x => clean(x.name) === name) || {};
      const status = normalizeCaseStatus(cols[2] || prev.status || defaults.status || '事案交付');
      let startedAt = clean(cols[3] || prev.startedAt || defaults.startedAt || '');
      if (CASE_STARTED.has(status) && !startedAt) startedAt = today();
      return {id:prev.id || uid('tg'), name, role:cols[1] || prev.role || '', status, startedAt, nextDate:clean(cols[4] || prev.nextDate || defaults.nextDate || ''), owner:clean(prev.owner || defaults.owner || ''), priority:clean(prev.priority || defaults.priority || 'normal'), nextAction:clean(cols[5] || prev.nextAction || defaults.nextAction || ''), note:clean(cols.slice(6).join(' ') || prev.note || '')};
    }).filter(x => x.name);
  }
  function caseTargetCards() {
    if (CASE_TARGET_CARDS_CACHE) return CASE_TARGET_CARDS_CACHE;
    const cards = [];
    DATA.cases.forEach(c => {
      const targets = caseTargets(c);
      if (!targets.length) {
        cards.push({case:c, caseId:c.id, id:`${c.id}:`, targetId:'', title:itemTitle(c), targetName:'調査対象者未登録', targetRole:'', targetNote:'', status:normalizeCaseStatus(c.status), startedAt:c.startedAt || '', nextDate:c.nextDate || '', owner:c.owner || '', priority:c.priority || 'normal', nextAction:c.nextAction || '', note:c.note || '', emptyTarget:true});
      } else {
        targets.forEach(t => cards.push({case:c, caseId:c.id, id:`${c.id}:${t.id}`, targetId:t.id, title:itemTitle(c), targetName:t.name, targetRole:t.role, targetNote:t.note, status:normalizeCaseStatus(t.status), startedAt:t.startedAt || '', nextDate:t.nextDate || '', owner:t.owner || '', priority:t.priority || 'normal', nextAction:t.nextAction || '', note:t.note || c.note || '', emptyTarget:false}));
      }
    });
    CASE_TARGET_CARDS_CACHE = cards;
    return CASE_TARGET_CARDS_CACHE;
  }
  function caseTargetSource(card) { return `speculum:case-target:${card.caseId}:${card.targetId || 'case'}`; }
  function workTaskForCaseTarget(card) { return WORK_TASK_BY_SOURCE.get(caseTargetSource(card)); }
  function workTaskForEvent(item) { return WORK_TASK_BY_SOURCE.get(sourceId('events', item?.id)); }
  function addMonthsISO(ds, months) {
    if (!ds) return '';
    const d = new Date(ds + 'T00:00:00');
    if (Number.isNaN(d.getTime())) return '';
    const day = d.getDate();
    d.setMonth(d.getMonth() + months);
    if (d.getDate() !== day) d.setDate(0);
    return `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}`;
  }
  function caseAlertInfo(c) {
    const status = normalizeCaseStatus(c.status);
    if (status === '完了' || !CASE_STARTED.has(status) || !c.startedAt) return null;
    const limit = addMonthsISO(c.startedAt, 3);
    const d = calendarDayDiff(limit);
    if (d !== null && d < 0) return {date:limit, diff:d, label:'長期化'};
    return null;
  }


  const HOLIDAY_CACHE = new Map();
  function isoDate(y, m, d) { return `${y}-${pad(m)}-${pad(d)}`; }
  function nthMonday(y, m, n) {
    const first = new Date(y, m - 1, 1);
    const day = 1 + ((8 - first.getDay()) % 7) + (n - 1) * 7;
    return isoDate(y, m, day);
  }
  function equinoxDay(y, spring = true) {
    if (spring) return Math.floor(20.8431 + 0.242194 * (y - 1980) - Math.floor((y - 1980) / 4));
    return Math.floor(23.2488 + 0.242194 * (y - 1980) - Math.floor((y - 1980) / 4));
  }
  function eachDateOfYear(y, fn) {
    const d = new Date(y, 0, 1);
    while (d.getFullYear() === y) {
      fn(isoDate(d.getFullYear(), d.getMonth() + 1, d.getDate()), d);
      d.setDate(d.getDate() + 1);
    }
  }
  function holidayMap(y) {
    if (HOLIDAY_CACHE.has(y)) return HOLIDAY_CACHE.get(y);
    const m = new Map();
    const add = (ds, name) => { if (ds && !m.has(ds)) m.set(ds, name); };
    add(isoDate(y,1,1),'元日');
    add(nthMonday(y,1,2),'成人の日');
    add(isoDate(y,2,11),'建国記念の日');
    add(isoDate(y,2,23),'天皇誕生日');
    add(isoDate(y,3,equinoxDay(y,true)),'春分の日');
    add(isoDate(y,4,29),'昭和の日');
    add(isoDate(y,5,3),'憲法記念日');
    add(isoDate(y,5,4),'みどりの日');
    add(isoDate(y,5,5),'こどもの日');
    add(nthMonday(y,7,3),'海の日');
    add(isoDate(y,8,11),'山の日');
    add(nthMonday(y,9,3),'敬老の日');
    add(isoDate(y,9,equinoxDay(y,false)),'秋分の日');
    add(nthMonday(y,10,2),'スポーツの日');
    add(isoDate(y,11,3),'文化の日');
    add(isoDate(y,11,23),'勤労感謝の日');
    const baseDates = Array.from(m.keys());
    for (const ds of baseDates) {
      const d = new Date(ds + 'T00:00:00');
      if (d.getDay() !== 0) continue;
      d.setDate(d.getDate() + 1);
      while (m.has(isoDate(d.getFullYear(), d.getMonth()+1, d.getDate()))) d.setDate(d.getDate() + 1);
      if (d.getFullYear() === y) add(isoDate(d.getFullYear(), d.getMonth()+1, d.getDate()), '振替休日');
    }
    eachDateOfYear(y, (ds, d) => {
      if (m.has(ds) || d.getDay() === 0) return;
      const prev = new Date(d); prev.setDate(d.getDate() - 1);
      const next = new Date(d); next.setDate(d.getDate() + 1);
      const ps = isoDate(prev.getFullYear(), prev.getMonth()+1, prev.getDate());
      const ns = isoDate(next.getFullYear(), next.getMonth()+1, next.getDate());
      if (m.has(ps) && m.has(ns)) add(ds, '国民の休日');
    });
    HOLIDAY_CACHE.set(y, m);
    return m;
  }
  function holidayName(ds) {
    if (!ds) return '';
    const d = new Date(ds + 'T00:00:00');
    if (Number.isNaN(d.getTime())) return '';
    const mmdd = ds.slice(5);
    const imported = clean(DATA?.holidays?.items?.[ds] || '');
    const closed = (mmdd >= '12-29' || mmdd <= '01-03');
    if (closed) return imported ? `${imported}・閉庁日` : '閉庁日';
    return imported;
  }
  function dateObj(ds) {
    const d = new Date(ds + 'T00:00:00');
    return Number.isNaN(d.getTime()) ? null : d;
  }
  function addDays(ds, days) {
    const d = dateObj(ds);
    if (!d) return '';
    d.setDate(d.getDate() + Number(days || 0));
    return `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}`;
  }
  function isClosedCalendarDay(ds) {
    const d = dateObj(ds);
    if (!d) return false;
    return d.getDay() === 0 || d.getDay() === 6 || !!holidayName(ds);
  }
  function repeatShiftMode(e) {
    const raw = clean(e?.repeatBusinessDayShift || e?.businessDayShift || e?.holidayShift || 'none').toLowerCase();
    if (['previous','prev','before','前','前へ','前営業日'].includes(raw)) return 'previous';
    if (['next','after','後','後ろ','後営業日'].includes(raw)) return 'next';
    if (['nearest','closest','近い','最寄り'].includes(raw)) return 'nearest';
    return 'none';
  }
  function repeatTieMode(e) {
    const raw = clean(e?.repeatBusinessDayTie || e?.businessDayTie || e?.nearestTie || 'previous').toLowerCase();
    return ['next','after','後','後ろ'].includes(raw) ? 'next' : 'previous';
  }
  function shiftToBusinessDay(ds, mode, tie = 'previous') {
    if (!ds || mode === 'none' || !isClosedCalendarDay(ds)) return ds;
    const find = (dir) => {
      let x = ds;
      for (let i=0; i<31; i++) {
        x = addDays(x, dir);
        if (x && !isClosedCalendarDay(x)) return x;
      }
      return ds;
    };
    if (mode === 'previous') return find(-1);
    if (mode === 'next') return find(1);
    if (mode === 'nearest') {
      for (let dist=1; dist<=31; dist++) {
        const prev = addDays(ds, -dist);
        const next = addDays(ds, dist);
        const prevOk = prev && !isClosedCalendarDay(prev);
        const nextOk = next && !isClosedCalendarDay(next);
        if (prevOk && nextOk) return tie === 'next' ? next : prev;
        if (prevOk) return prev;
        if (nextOk) return next;
      }
    }
    return ds;
  }
  function repeatAdjustLabel(e) {
    const mode = repeatShiftMode(e);
    if (mode === 'none') return '';
    if (mode === 'previous') return '土日祝日は前の平日へ';
    if (mode === 'next') return '土日祝日は後ろの平日へ';
    return `土日祝日は近い平日へ（同距離は${repeatTieMode(e) === 'next' ? '後ろ' : '前'}）`;
  }
  function repeatInterval(e) { const n = Number(e?.repeatInterval || 1); return Number.isFinite(n) && n > 0 ? Math.floor(n) : 1; }
  function monthDiff(a, b) { return (b.getFullYear() - a.getFullYear()) * 12 + (b.getMonth() - a.getMonth()); }
  function endOfMonthDate(y, m0) { return new Date(y, m0 + 1, 0); }
  function isoFromDate(d) { return `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}`; }
  function nthWeekdayDate(y, m0, weekday, nth) {
    const last = endOfMonthDate(y, m0);
    if (String(nth) === 'last') {
      const d = new Date(last);
      while (d.getDay() !== Number(weekday)) d.setDate(d.getDate() - 1);
      return d;
    }
    const n = Math.max(1, Math.min(5, Number(nth) || 1));
    const d = new Date(y, m0, 1);
    while (d.getDay() !== Number(weekday)) d.setDate(d.getDate() + 1);
    d.setDate(d.getDate() + (n - 1) * 7);
    return d.getMonth() === m0 ? d : null;
  }
  function monthlyCandidate(e, y, m0) {
    const start = dateObj(e.date); if (!start) return '';
    const mode = clean(e.repeatMonthlyMode || 'dayOfMonth');
    const last = endOfMonthDate(y, m0);
    if (mode === 'endOfMonth') return isoFromDate(last);
    if (mode === 'lastBusinessDay') return shiftToBusinessDay(isoFromDate(last), 'previous');
    if (mode === 'nthWeekday') {
      const weekday = Number.isFinite(Number(e.repeatWeekday)) ? Number(e.repeatWeekday) : start.getDay();
      const d = nthWeekdayDate(y, m0, weekday, clean(e.repeatNth || '1'));
      return d ? isoFromDate(d) : '';
    }
    const day = Math.max(1, Math.min(31, Number(e.repeatDayOfMonth || start.getDate()) || start.getDate()));
    if (day <= last.getDate()) return `${y}-${pad(m0+1)}-${pad(day)}`;
    const missing = clean(e.repeatMissingDatePolicy || 'skip');
    if (missing === 'lastDay') return isoFromDate(last);
    if (missing === 'previousBusiness') return shiftToBusinessDay(isoFromDate(last), 'previous');
    if (missing === 'nextBusiness') return shiftToBusinessDay(isoFromDate(new Date(y, m0 + 1, 1)), 'next');
    return '';
  }
  function baseOccurrenceMatches(e, baseDs) {
    if (!e || !baseDs || !e.date) return false;
    const rep = clean(e.repeat || 'none');
    if (baseDs < e.date) return false;
    if (e.repeatUntil && baseDs > e.repeatUntil) return false;
    if (!rep || rep === 'none') return baseDs === e.date;
    const start = dateObj(e.date);
    const base = dateObj(baseDs);
    if (!start || !base || base < start) return false;
    const diffDays = Math.round((base - start) / 86400000);
    const interval = repeatInterval(e);
    if (rep === 'daily') return diffDays % interval === 0;
    if (rep === 'weekly') return diffDays % (7 * interval) === 0;
    if (rep === 'monthly') {
      const md = monthDiff(start, base);
      if (md < 0 || md % interval !== 0) return false;
      return monthlyCandidate(e, base.getFullYear(), base.getMonth()) === baseDs;
    }
    if (rep === 'yearly') {
      const yd = base.getFullYear() - start.getFullYear();
      if (yd < 0 || yd % interval !== 0) return false;
      if (start.getMonth() === base.getMonth() && start.getDate() === base.getDate()) return true;
      if (start.getMonth() === 1 && start.getDate() === 29 && base.getMonth() === 1 && base.getDate() === 28 && ['lastDay','previousBusiness'].includes(clean(e.repeatMissingDatePolicy || 'skip'))) return true;
      return false;
    }
    return false;
  }
  function effectiveOccurrenceDate(e, baseDs) {
    const ex = (e.exceptions || {})[baseDs] || {};
    if (clean(ex.action).toLowerCase() === 'skip') return '';
    return clean(ex.date) || shiftToBusinessDay(baseDs, repeatShiftMode(e), repeatTieMode(e));
  }
  function eventOccurrenceInfo(e, ds) {
    if (!e || !ds) return null;
    const exceptions = e.exceptions || {};
    for (const [baseDs, raw] of Object.entries(exceptions)) {
      const ex = raw && typeof raw === 'object' ? raw : {};
      if (clean(ex.action).toLowerCase() === 'skip' || clean(ex.date) !== ds || !baseOccurrenceMatches(e, baseDs)) continue;
      return {baseDate:baseDs, shifted:baseDs !== ds || !!clean(ex.date)};
    }
    for (let offset=-45; offset<=45; offset++) {
      const baseDs = addDays(ds, offset);
      if (!baseDs || !baseOccurrenceMatches(e, baseDs)) continue;
      const effective = effectiveOccurrenceDate(e, baseDs);
      if (effective === ds) return {baseDate:baseDs, shifted:baseDs !== ds || !!clean((e.exceptions || {})[baseDs]?.date)};
    }
    return null;
  }
  async function importCabinetHolidays() {
    const btn = $('importHolidaysBtn');
    if (btn) { btn.disabled = true; btn.textContent = '取得中'; }
    try {
      const j = await api('/api/holidays/import-cabinet', {method:'POST', body:'{}'});
      DATA.holidays = Object.assign({items:{}}, j.holidays || {});
      if (j.hash) HASH = j.hash;
      OCCURRENCE_CACHE = {key:'', start:'', end:'', mode:'both', items:[]};
      notifyDataChanged('speculum', HASH, 'holidays');
      toast(j.added ? `祝日データを${j.added}件追加しました` : '祝日データは取得済みです');
      renderCalendar();
    } catch (e) {
      toast(e.message || '祝日データを取得できませんでした');
    } finally {
      if (btn) { btn.disabled = false; btn.textContent = '祝日取得'; }
    }
  }



  function occurrenceSort(a, b) {
    const kp = (calendarKind(a) === 'schedule' ? 0 : 1) - (calendarKind(b) === 'schedule' ? 0 : 1);
    return kp || String(a.time || '99:99').localeCompare(String(b.time || '99:99')) || itemTitle(a).localeCompare(itemTitle(b));
  }
  function cacheCovers(ds, mode = 'both') {
    return OCCURRENCE_CACHE.start && OCCURRENCE_CACHE.end && OCCURRENCE_CACHE.start <= ds && ds <= OCCURRENCE_CACHE.end && (OCCURRENCE_CACHE.mode === 'both' || OCCURRENCE_CACHE.mode === mode || mode === 'both');
  }
  async function loadOccurrences(startDs, endDs, mode = 'both') {
    const key = `${startDs}:${endDs}:${mode}`;
    if (OCCURRENCE_CACHE.key === key) return OCCURRENCE_CACHE.items;
    const j = await api(`/api/calendar/occurrences?from=${encodeURIComponent(startDs)}&to=${encodeURIComponent(endDs)}&mode=${encodeURIComponent(mode)}`);
    OCCURRENCE_CACHE = {key, start:startDs, end:endDs, mode, items:arr(j.items)};
    return OCCURRENCE_CACHE.items;
  }
  function serverOccurrencesOn(ds, mode = calendarItemMode) {
    if (!cacheCovers(ds, mode)) return null;
    return OCCURRENCE_CACHE.items.filter(e => e._ds === ds && (mode === 'both' || calendarKind(e) === mode)).sort(occurrenceSort);
  }
  function eventOccursOn(e, ds) {
    return !!eventOccurrenceInfo(e, ds);
  }
  function eventsOn(ds, mode = calendarItemMode) {
    const cached = serverOccurrencesOn(ds, mode);
    if (cached) return cached;
    return DATA.events.map(e => {
      const info = eventOccurrenceInfo(e, ds);
      return info ? Object.assign({}, e, {_ds:ds, _baseDate:info.baseDate, _shifted:info.shifted}) : null;
    }).filter(Boolean).filter(e => mode === 'both' || calendarKind(e) === mode).sort(occurrenceSort);
  }
  function nextOccurrenceOnOrAfter(e, from = today()) {
    if (!e) return null;
    for (let i=0; i<=1465; i++) {
      const ds = addDays(from, i);
      const info = eventOccurrenceInfo(e, ds);
      if (info) return Object.assign({}, e, {_ds:ds, _baseDate:info.baseDate, _shifted:info.shifted});
    }
    return null;
  }
  function scheduleHay(item) {
    return [itemTitle(item), calendarKindLabel(item), item.date, item._ds, item.time, item.place, item.due, item.label, peopleLabel(item), caseName(item.caseId), item.note].join(' ').toLowerCase();
  }
  function matchingScheduleItem(item) {
    const q = clean($('scheduleSearch')?.value || '');
    return matchesWords(q, scheduleHay(item));
  }

  function safeReplaceHash(routeText) {
    const hash = `#${routeText || 'today'}`;
    try {
      if (location.hash !== hash) history.replaceState(null, '', hash);
    } catch (_) {
      try { if (location.hash !== hash) location.hash = hash; } catch (_) {}
    }
  }
  function parseViewRoute(raw) {
    const text = clean(String(raw || '').replace(/^#/, '')) || 'today';
    const qAt = text.indexOf('?');
    const view = clean((qAt >= 0 ? text.slice(0, qAt) : text) || 'today');
    const params = new URLSearchParams(qAt >= 0 ? text.slice(qAt + 1) : '');
    return {view, q:clean(params.get('q') || ''), focus:clean(params.get('focus') || '')};
  }
  function routeHashText(view, route = {}) {
    const params = new URLSearchParams();
    if (clean(route.q)) params.set('q', clean(route.q));
    if (clean(route.focus)) params.set('focus', clean(route.focus));
    const qs = params.toString();
    return `${view || 'today'}${qs ? '?' + qs : ''}`;
  }
  function setRouteSearch(id, value) {
    const el = $(id);
    if (!el || !clean(value)) return false;
    const next = clean(value);
    if (el.value !== next) { el.value = next; return true; }
    return false;
  }
  function routedFocus(containerId, id = '', allowFallback = true) {
    setTimeout(() => {
      const box = $(containerId); if (!box) return;
      const wanted = clean(id);
      const selector = '[data-record-id], [data-person-id], [data-case-id], [data-target-id], [data-career-id]';
      let target = null;
      if (wanted) {
        target = Array.from(box.querySelectorAll(selector)).find(el => [el.dataset.recordId, el.dataset.personId, el.dataset.caseId, el.dataset.targetId, el.dataset.careerId].some(v => clean(v) === wanted));
      }
      if (!target && allowFallback) target = box.querySelector('.card, .item, .case-card, .career-year-head, .career-cell, .day-cell');
      if (!target) return;
      target.classList.add('route-focus');
      target.scrollIntoView({block:'center', inline:'nearest'});
      setTimeout(() => target.classList.remove('route-focus'), 1800);
    }, 100);
  }
  function focusTitleFor(view, id) {
    const wanted = clean(id);
    if (!wanted) return '';
    if (view === 'people') return itemTitle(DATA.people.find(x => x.id === wanted) || {});
    if (view === 'cases') { const c = DATA.cases.find(x => x.id === wanted); return clean(c?.title || c?.name); }
    if (view === 'tasks') { const d = [...DATA.deadlines, ...DATA.jimu].find(x => x.id === wanted); return itemTitle(d || {}); }
    if (view === 'career') { const c = DATA.career.find(x => x.id === wanted); return clean(c?.fiscalYear || c?.office || c?.division); }
    if (view === 'schedule') { const e = DATA.events.find(x => x.id === wanted); return itemTitle(e || {}); }
    return '';
  }
  function applyRouteFocus(route) {
    const focus = clean(route?.focus);
    let q = clean(route?.q) || focusTitleFor(currentView, focus);
    if (!q && !focus) return;
    if (currentView === 'people') {
      const p = DATA.people.find(x => x.id === focus);
      if (p?.retired && !showRetiredPeople) {
        showRetiredPeople = true;
        const b = $('toggleRetiredBtn'); if (b) b.textContent = '退職者を隠す';
      }
      setRouteSearch('peopleSearch', q || p?.name || '');
      renderPeople();
      routedFocus('peopleList', focus, !focus);
      return;
    }
    if (currentView === 'cases') {
      if (q) {
        caseFocusScope = 'focus';
        caseBoardOpen = true;
        setRouteSearch('caseSearch', q);
      }
      renderCards();
      routedFocus('caseList', focus, !focus);
      return;
    }
    if (currentView === 'tasks') {
      setRouteSearch('dueSearch', q);
      renderLists();
      if (focus) {
        routedFocus('deadlineList', focus, false);
        routedFocus('jimuList', focus, false);
      } else {
        routedFocus('deadlineList', '', true);
        routedFocus('jimuList', '', true);
      }
      return;
    }
    if (currentView === 'career') {
      setRouteSearch('careerSearch', q);
      renderTimeline();
      routedFocus('careerList', focus, !focus);
      return;
    }
    if (currentView === 'schedule') {
      setRouteSearch('scheduleSearch', q);
      calendarMode = 'list';
      calendarListExpanded = false;
      renderCalendar();
      routedFocus('scheduleListView', focus, !focus);
    }
  }
  function endOfMonthISO(ds = today()) {
    const d = dateObj(ds || today());
    if (!d) return today();
    return isoFromDate(new Date(d.getFullYear(), d.getMonth() + 1, 0));
  }
  function nextWeekFridayISO(ds = today()) {
    const d = dateObj(ds || today());
    if (!d) return addDays(today(), 7);
    const delta = ((5 - d.getDay() + 7) % 7) || 7;
    d.setDate(d.getDate() + delta);
    return isoFromDate(d);
  }
  function datePresets() {
    const next = nextOpenDay(today());
    return [[today(), '今日'], [next, '次の稼働日'], [addDays(today(), 7), '7日後'], [nextWeekFridayISO(), '来週金曜'], [endOfMonthISO(), '月末']];
  }
  function timePresets() { return [['09:00','9時'], ['10:00','10時'], ['13:00','13時'], ['15:00','15時'], ['17:00','17時']]; }
  function durationPresets() { return [['15','15分'], ['30','30分'], ['45','45分'], ['60','1時間'], ['90','1.5時間'], ['120','2時間']]; }
  function statusPresets() { return [['today','今日'], ['next','次'], ['waiting','待ち']]; }
  function priorityPresets() { return [['normal','通常'], ['high','高優先'], ['low','低優先']]; }
  function priorityLabel(value) { return ({high:'高優先', normal:'通常', low:'低優先'})[clean(value).toLowerCase()] || clean(value); }
  function statusLabel(value) {
    const raw = clean(value);
    return ({today:'今日やる', next:'次に進める', waiting:'待ち', done:'完了', open:'未完了', active:'継続中', paused:'休止中', ended:'終了'})[raw.toLowerCase()] || raw;
  }

  function switchView(view) {
    const route = parseViewRoute(view);
    const allowed = ['today','schedule','tasks','cases','people','career'];
    currentView = allowed.includes(route.view) ? route.view : 'today';
    $$('.bc-tabs button').forEach(b => b.classList.toggle('active', b.dataset.view === currentView));
    $$('.view').forEach(v => v.classList.toggle('active', v.id === `view-${currentView}`));
    safeReplaceHash(routeHashText(currentView, route));
    renderCurrentView();
    applyRouteFocus(route);
  }
  function viewRenderSignature(view = currentView) {
    const shared = [HASH, WORK_HASH, today(), dueDayCountMode];
    if (view === 'schedule') return JSON.stringify([...shared, view, calCursor.getFullYear(), calCursor.getMonth(), calendarMode, calendarItemMode, calendarShowDue, calendarShowWork, calendarShowDone, calendarShowRepeat, calendarListExpanded, clean($('scheduleSearch')?.value)]);
    if (view === 'tasks') return JSON.stringify([...shared, view, clean($('dueSearch')?.value), dueRenderScopeKey, dueRenderLimits.deadlines, dueRenderLimits.jimu]);
    if (view === 'cases') return JSON.stringify([...shared, view, clean($('caseSearch')?.value), caseFocusScope, caseBoardOpen, CASE_RENDER_GENERATION]);
    if (view === 'people') return JSON.stringify([...shared, view, clean($('peopleSearch')?.value), showRetiredPeople, peopleRenderScopeKey, peopleRenderLimit]);
    if (view === 'career') return JSON.stringify([...shared, view, clean($('careerSearch')?.value), careerRenderScopeKey, careerRenderLimit]);
    if (view === 'today') return JSON.stringify([...shared, view, todayCommanderExpanded]);
    return JSON.stringify([...shared, view]);
  }
  function invalidateViewRenderCache(view = '') {
    if (view) VIEW_RENDER_SIGNATURES.delete(view);
    else VIEW_RENDER_SIGNATURES.clear();
  }
  function renderCurrentView(force = false) {
    if (!DATA || !WORK) return;
    const before = viewRenderSignature(currentView);
    if (!force && VIEW_RENDER_SIGNATURES.get(currentView) === before) return false;
    syncDueCountModeControls();
    if (currentView === 'today') renderToday();
    else if (currentView === 'schedule') renderCalendar();
    else if (currentView === 'tasks') { renderLists(); renderWorkLinked(); }
    else if (currentView === 'cases') renderCards();
    else if (currentView === 'people') renderPeople();
    else if (currentView === 'career') renderTimeline();
    VIEW_RENDER_SIGNATURES.set(currentView, viewRenderSignature(currentView));
    return true;
  }
  function renderAll() {
    invalidateViewRenderCache(currentView);
    renderCurrentView(true);
  }

  function setTinyText(id, text) {
    const el = $(id);
    if (el) el.textContent = text;
  }
  function itemLimitNote(total, limit = 3) {
    return total > limit ? `ほか${total - limit}件。必要なら下の詳細を展開してください。` : '';
  }
  function actionNoteNode(text, actions = []) {
    const d = document.createElement('div');
    d.className = 'empty action-note';
    const span = document.createElement('span');
    span.textContent = text;
    d.appendChild(span);
    if (actions.length) {
      const box = document.createElement('div');
      box.className = 'action-note-buttons';
      actions.forEach(a => {
        const b = document.createElement('button');
        b.type = 'button';
        b.className = a.className || 'mini';
        b.textContent = a.label;
        b.addEventListener('click', a.onClick);
        box.appendChild(b);
      });
      d.appendChild(box);
    }
    return d;
  }
  function commanderEmptyActions(key) {
    const actions = {
      now:[{label:'予定を追加', className:'mini primary-inline', onClick:()=>openEventModal({date:today(), calendarKind:'schedule'})}],
      work:[{label:'作業管理を開く', onClick:()=>openWorkspace('continuum')}]
    };
    return actions[key] || [];
  }
  function commanderCompactLimit(key, total) {
    if (todayCommanderExpanded[key]) return 10;
    if (total >= 12 && ['work','near','cases'].includes(key)) return 2;
    if (total >= 8 && key !== 'critical') return 2;
    return 3;
  }
  function setCommanderList(id, key, nodes, emptyText) {
    const total = nodes.length;
    const host = $(id);
    const card = host?.closest('.commander-card');
    if (card) {
      card.hidden = total === 0 && ['near','cases'].includes(key);
      card.classList.toggle('is-empty', total === 0);
      card.classList.toggle('has-items', total > 0);
      card.classList.toggle('is-crowded', total >= 8);
    }
    if (!total) {
      setList(id, [actionNoteNode(emptyText, commanderEmptyActions(key))], '');
      const empty = host?.querySelector('.empty');
      if (empty) empty.classList.add('quiet-empty');
      return;
    }
    const limit = commanderCompactLimit(key, total);
    const shown = nodes.slice(0, limit);
    if (total > limit || todayCommanderExpanded[key]) {
      const hidden = Math.max(0, total - limit);
      shown.push(actionNoteNode(
        todayCommanderExpanded[key]
          ? (hidden ? `さらに${hidden}件あります。必要なものだけ開いて処理します。` : '展開表示中です。')
          : `${total}件のうち上位${limit}件だけ表示。ほか${hidden}件。`,
        [{label: todayCommanderExpanded[key] ? '畳む' : 'さらに表示', onClick: () => { todayCommanderExpanded[key] = !todayCommanderExpanded[key]; renderToday(); }}]
      ));
    }
    setList(id, shown, emptyText);
  }
  function renderTodayDensityNotice(ctx = {}) {
    const box = $('todayDensityNotice');
    const dashboard = document.querySelector('.today-dashboard');
    if (!box) return;
    const a = loadAssessment(ctx);
    const buckets = [
      ['今日の流れ', a.flowCount, 'now'],
      ['今日の作業', a.workCount, 'work'],
      ['要対応', a.riskCount, 'critical'],
      ['未追加', a.unlinkedCount, 'unlinked'],
      ['その他', a.confirmCount, 'confirm']
    ];
    const total = buckets.reduce((sum, x) => sum + Number(x[1] || 0), 0);
    const crowded = total >= 24 || a.workCount >= 10 || a.riskCount >= 3 || a.unlinkedCount >= 6 || a.confirmCount >= 12;
    dashboard?.classList.toggle('density-crowded', crowded);
    if (!crowded) { box.hidden = true; box.innerHTML = ''; return; }
    box.hidden = false;
    box.innerHTML = `<div><b>今日は項目が多めです</b><span>すべてを一度に開かず、今やる一件、今日の流れと作業、要対応の順に確認してください。</span></div><div class="density-chips">${buckets.filter(x=>x[1]).map(([label,n,key])=>`<button type="button" data-density-open="${esc(key)}"><b>${esc(n)}</b><span>${esc(label)}</span></button>`).join('')}</div>`;
    $$('[data-density-open]', box).forEach(btn => btn.addEventListener('click', () => openTodayMetric(btn.dataset.densityOpen)));
  }
  function setTodayFocusAction(items) {
    const box = $('todayFocusAction');
    if (!box) return;
    box.innerHTML = '';
    const list = arr(items);
    const first = list[0];
    box.hidden = false;
    const card = document.createElement('div');
    card.className = `focus-action-card ${first ? (first.tone || '') : 'empty-focus'}`.trim();
    const info = document.createElement('div');
    info.className = 'focus-action-copy';
    const ops = document.createElement('div'); ops.className = 'focus-action-buttons';
    if (!first) {
      info.innerHTML = `<span>今やる一件</span><b>まだ決まっていません</b><em>「今日を整理」で候補を選ぶか、作業管理から最初の一件を決めます。</em>`;
      const plan = document.createElement('button'); plan.type='button'; plan.className='primary-inline'; plan.textContent='今日を整理'; plan.onclick=()=>openMorningReview(); ops.appendChild(plan);
      const work = document.createElement('button'); work.type='button'; work.className='mini'; work.textContent='作業管理を開く'; work.onclick=()=>openWorkspace('continuum'); ops.appendChild(work);
      card.append(info, ops); box.appendChild(card);
      return;
    }
    const label = first.tone === 'danger' ? '今やる一件 / 要対応' : (first.tone === 'near' ? '今やる一件 / 近い期限' : '今やる一件');
    const reason = first.tone === 'danger' ? '期限を過ぎた項目から判断します。' : (first.tone === 'near' ? '近い期限を先に確認します。' : 'この一件を終えるか、次の状態へ進めます。');
    info.innerHTML = `<span>${esc(label)}</span><b>${esc(first.title || '無題')}</b><em>${esc(first.meta || '')}</em><div class="focus-action-reason">${esc(reason)}</div>`;
    if (first.primaryLabel && typeof first.primary === 'function') {
      const b = document.createElement('button'); b.type='button'; b.className='primary-inline'; b.textContent=first.primaryLabel; b.onclick=first.primary; ops.appendChild(b);
    }
    if (first.openLabel && typeof first.open === 'function') {
      const b = document.createElement('button'); b.type='button'; b.className='mini'; b.textContent=first.openLabel; b.onclick=first.open; ops.appendChild(b);
    }
    if (list.length > 1) {
      const more = document.createElement('button'); more.type='button'; more.className='mini ghost'; more.textContent=`ほかを選ぶ（${list.length - 1}件）`;
      more.onclick = () => openTodayMetric(first.group || (first.tone === 'danger' ? 'critical' : first.tone === 'today' ? 'work' : 'near'));
      ops.appendChild(more);
    }
    card.append(info, ops); box.appendChild(card);
  }

  function cycleDueItems() {
    return WORK.cycleTasks
      .filter(x => {
        const state = clean(x.state || x.status || 'active');
        return state !== 'paused' && state !== 'ended' && !isDone(x) && clean(x.nextRunDate);
      })
      .map(x => ({...x, label:'周期作業', due:x.nextRunDate, diff:dayDiff(x.nextRunDate), calDiff:calendarDayDiff(x.nextRunDate)}))
      .filter(x => x.diff !== null && x.diff <= 7)
      .sort((a,b) => a.diff - b.diff || byDate(a.nextRunDate,b.nextRunDate) || itemTitle(a).localeCompare(itemTitle(b)));
  }
  async function todayCycleAction(id, action = 'complete') {
    return runUiAction(`cycle:${id}`, async () => {
      const names = {complete:'今回分を完了しました', skip:'今回分をスキップしました', pause:'休止しました', resume:'再開しました', end:'終了しました'};
      const current = WORK.cycleTasks.find(item => item.id === id);
      const j = await api(`/api/continuum/cycle-${action}`, {method:'POST', body:JSON.stringify({id, doneDate:today(), baseItemUpdatedAt:current?.updatedAt || ''})});
      await loadData();
      renderAll();
      const next = j?.item?.nextRunDate ? `。次回は ${fmtDate(j.item.nextRunDate)} です` : '';
      toast((names[action] || '更新しました') + next);
      return j;
    }, '周期作業を更新できませんでした');
  }
  function taskAgeDays(t) {
    const raw = Date.parse(t.updatedAt || t.createdAt || '');
    if (!Number.isFinite(raw)) return null;
    return Math.max(0, Math.floor((Date.now() - raw) / 86400000));
  }

  function updateMemoPreview() {
    const preview = $('memoPreview');
    if (!preview) return;
    const active = document.querySelector('.memo-tabs button.active')?.dataset.memoTab || 'today';
    let text = '';
    if (active === 'permanent') text = $('permanentMemo')?.value || DATA.memo?.permanent || '';
    else if (active === 'history') text = '過去メモは「メモを書く」を開いて履歴タブで確認します。';
    else text = $('todayMemo')?.value || DATA.memo?.today || DATA.memo?.days?.[today()] || '';
    preview.textContent = clean(text) || 'メモはありません。';
  }
  function toggleMemoPanel(force) {
    const panel = $('todayMemoPanel');
    if (!panel) return;
    const expand = typeof force === 'boolean' ? force : panel.classList.contains('memo-collapsed');
    panel.classList.toggle('memo-collapsed', !expand);
    const btn = $('toggleMemoBtn');
    if (btn) btn.textContent = expand ? '畳む' : 'メモを書く';
    updateMemoPreview();
    if (expand) setTimeout(() => $('todayMemo')?.focus(), 30);
  }
  function openTodayMetric(key) {
    const targetMap = {critical:'todayCritical', now:'todayNow', near:'todayNear', work:'todayWorkDashboard', cases:'todayCaseDashboard'};
    if (targetMap[key]) {
      todayCommanderExpanded[key] = true;
      renderToday().then(() => {
        const card = $(targetMap[key])?.closest('.commander-card');
        card?.scrollIntoView({block:'nearest', behavior:'smooth'});
      });
      return;
    }
    if (key === 'confirm' || key === 'unlinked') {
      const id = key === 'unlinked' ? 'actionSuggestions' : 'todayConfirm';
      const detail = $(id)?.closest('details');
      if (detail) detail.open = true;
      detail?.scrollIntoView({block:'nearest', behavior:'smooth'});
    }
  }

  function nextOpenDay(ds = today()) {
    let cur = ds;
    for (let i = 0; i < 14; i++) {
      cur = addDays(cur, 1);
      if (cur && !isClosedCalendarDay(cur)) return cur;
    }
    return addDays(ds, 1);
  }
  function todayRitualStore() {
    DATA.settings = Object.assign({}, DATA.settings || {});
    DATA.settings.todayRitual = Object.assign({days:{}}, DATA.settings.todayRitual || {});
    DATA.settings.todayRitual.days = DATA.settings.todayRitual.days || {};
    const ds = today();
    DATA.settings.todayRitual.days[ds] = Object.assign({}, DATA.settings.todayRitual.days[ds] || {});
    return DATA.settings.todayRitual.days[ds];
  }
  function todayRitualState(ds = today()) {
    const days = DATA?.settings?.todayRitual?.days || {};
    return Object.assign({plannedAt:'', closedAt:''}, days[ds] || {});
  }
  function formatRitualTime(value) {
    const d = new Date(value || '');
    if (Number.isNaN(d.getTime())) return '';
    return `${pad(d.getHours())}:${pad(d.getMinutes())}`;
  }
  function renderTodayRitualState(ctx = null) {
    const box = $('todayRitualState');
    if (!box) return;
    const st = todayRitualState();
    const a = ctx ? loadAssessment(ctx) : null;
    const planned = st.plannedAt ? `朝の整理 ${formatRitualTime(st.plannedAt)}` : '朝の整理: 未';
    const closed = st.closedAt ? `終業時の整理 ${formatRitualTime(st.closedAt)}` : '終業時の整理: 未';
    const hint = a && (a.riskCount || a.unlinkedCount) ? '要対応と未追加の項目を確認' : 'このまま開始できます';
    box.innerHTML = `<span class="${st.plannedAt ? 'done' : ''}">${esc(planned)}</span><span class="${st.closedAt ? 'done' : ''}">${esc(closed)}</span><em>${esc(hint)}</em>`;
  }
  function priorityRank(x) {
    const p = clean(x?.priority || '').toLowerCase();
    return p === 'high' || p === '高' || p === '高い' ? -2 : (p === 'low' || p === '低' || p === '低い' ? 1 : 0);
  }
  function taskUrgencyRank(x) {
    const d = calendarDayDiff(x?.due);
    const dueRank = d === null ? 99 : d;
    const st = clean(x?.status || 'next');
    return (st === 'today' ? -20 : 0) + dueRank * 3 + priorityRank(x);
  }
  async function collectTodayContext() {
    const t = today();
    let todayEvents = eventsOn(t, 'schedule');
    let summary = null;
    try {
      summary = await loadTodaySummary();
      if (arr(summary.eventsToday).length || todayEvents.length) todayEvents = arr(summary.eventsToday);
    } catch (_) {}
    const dueSoon = dueItems(true).map(x => ({...x, diff:dayDiff(x.due), calDiff:calendarDayDiff(x.due)})).filter(x => x.diff !== null && x.diff <= 7).sort((a,b) => a.diff - b.diff || byDate(a.due,b.due));
    const cyclesSoon = cycleDueItems();
    const localAlerts = caseAlerts(7);
    const alerts = summary ? arr(summary.caseAlerts).map(x => ({...x, caseId:x.id || x.caseId, alertKind:x.kind, alertDate:x.date, diff:x.days, targetName:x.targetName || x.targets || '', title:x.caseTitle || x.title || ''})) : localAlerts;
    const unlinked = unlinkedActionItems(localAlerts);
    const criticalDue = dueSoon.filter(x => x.calDiff < 0);
    const criticalCycles = cyclesSoon.filter(x => x.calDiff < 0);
    const criticalAlerts = alerts.filter(x => (calendarDayDiff(x.alertDate) ?? Number(x.diff)) < 0);
    const todayDueItems = dueSoon.filter(x => x.calDiff >= 0 && x.diff === 0);
    const todayCycles = cyclesSoon.filter(x => x.calDiff >= 0 && x.diff === 0);
    const nearDue = dueSoon.filter(x => x.calDiff >= 0 && x.diff > 0 && x.diff <= 7);
    const nearCycles = cyclesSoon.filter(x => x.calDiff >= 0 && x.diff > 0 && x.diff <= 7);
    const nearAlerts = alerts.filter(x => (calendarDayDiff(x.alertDate) ?? Number(x.diff)) >= 0 && Number(x.diff) <= 7);
    const todayWorkTasks = WORK.tasks.filter(x => !isDone(x) && (clean(x.status) === 'today' || calendarDayDiff(x.due) === 0)).sort((a,b) => taskUrgencyRank(a) - taskUrgencyRank(b) || itemTitle(a).localeCompare(itemTitle(b)));
    const waitingLong = WORK.tasks.filter(x => !isDone(x) && clean(x.status) === 'waiting').map(x => ({...x, ageDays:taskAgeDays(x)})).filter(x => x.ageDays === null || x.ageDays >= 7).sort((a,b)=>(b.ageDays||0)-(a.ageDays||0));
    const highNoDue = WORK.tasks.filter(x => !isDone(x) && clean(x.priority) === 'high' && !clean(x.due)).sort((a,b)=>String(b.updatedAt||'').localeCompare(String(a.updatedAt||'')));
    const tomorrow = nextOpenDay(t);
    const tomorrowTasks = WORK.tasks.filter(x => !isDone(x) && calendarDayDiff(x.due) === 1).sort((a,b)=>taskUrgencyRank(a)-taskUrgencyRank(b));
    const todayCloseTasks = WORK.tasks.filter(x => !isDone(x) && (clean(x.status) === 'today' || (calendarDayDiff(x.due) !== null && calendarDayDiff(x.due) <= 0))).sort((a,b)=>taskUrgencyRank(a)-taskUrgencyRank(b) || itemTitle(a).localeCompare(itemTitle(b)));
    const planCandidates = WORK.tasks.filter(x => !isDone(x) && clean(x.status) !== 'today' && clean(x.status) !== 'waiting' && clean(x.status) !== 'done').filter(x => clean(x.priority) === 'high' || (calendarDayDiff(x.due) !== null && calendarDayDiff(x.due) <= 7) || clean(x.nextAction)).sort((a,b)=>taskUrgencyRank(a)-taskUrgencyRank(b) || itemTitle(a).localeCompare(itemTitle(b)));
    return {t, summary, todayEvents, dueSoon, cyclesSoon, alerts, unlinked, criticalDue, criticalCycles, criticalAlerts, todayDueItems, todayCycles, nearDue, nearCycles, nearAlerts, todayWorkTasks, waitingLong, highNoDue, todayCloseTasks, planCandidates, tomorrow, tomorrowTasks};
  }
  function loadAssessment(ctx) {
    const workCount = arr(ctx.todayWorkTasks).length + arr(ctx.todayCycles).length;
    const flowCount = arr(ctx.todayEvents).length + arr(ctx.todayDueItems).filter(x => x.sourceType !== 'work').length;
    const riskCount = arr(ctx.criticalDue).length + arr(ctx.criticalCycles).length + arr(ctx.criticalAlerts).length;
    const unlinkedCount = arr(ctx.unlinked).length;
    const confirmCount = arr(ctx.waitingLong).length + arr(ctx.highNoDue).length;
    const workMinutes = totalEstimate(ctx.todayWorkTasks);
    const estimateCount = arr(ctx.todayWorkTasks).filter(x => estimateMinutes(x)).length;
    const hourPressure = Math.ceil(workMinutes / 75);
    const score = workCount + Math.ceil(flowCount / 2) + riskCount * 2 + Math.ceil(unlinkedCount / 2) + hourPressure;
    let level = 'calm', label = '落ち着いています';
    if (riskCount || score >= 8 || workCount >= 7 || flowCount >= 5 || unlinkedCount >= 3 || workMinutes >= 240) { level = 'busy'; label = '要整理'; }
    if (riskCount >= 3 || score >= 13 || workCount >= 11 || unlinkedCount >= 6 || workMinutes >= 420) { level = 'heavy'; label = '多すぎ注意'; }
    return {level, label, workCount, flowCount, riskCount, unlinkedCount, confirmCount, score, workMinutes, estimateCount};
  }
  function renderTodayLoadStatus(ctx) {
    const box = $('todayLoadStatus');
    if (!box) return;
    const a = loadAssessment(ctx || {});
    const hint = a.level === 'calm' ? 'そのまま開始' : ((a.riskCount || a.unlinkedCount) ? '整理してから開始' : '今日へ絞る');
    box.className = `today-load-status ${a.level}`;
    const workTime = a.workMinutes ? ` / 見積${durationLabel(a.workMinutes)}` : '';
    const estimateNote = a.workCount && !a.estimateCount ? ' / 見積未入力' : '';
    const pressure = Math.max(4, Math.min(100, Math.round(Math.max((a.workMinutes / 420) * 100, (a.workCount / 10) * 100, (a.riskCount / 3) * 100, (a.unlinkedCount / 6) * 100))));
    box.innerHTML = `<div class="today-load-copy"><span>今日の負荷</span><b>${esc(a.label)}</b><em>作業${a.workCount}${esc(workTime)}${estimateNote} / 流れ${a.flowCount} / 要対応${a.riskCount} / 未追加${a.unlinkedCount}</em></div><div class="today-load-meter" aria-hidden="true"><i style="width:${pressure}%"></i></div><strong>${esc(hint)}</strong>`;
  }
  function ritualSummaryHtml(ctx, mode = 'morning') {
    const a = loadAssessment(ctx);
    const yesterday = addDays(today(), -1);
    const yesterdayOpen = WORK.tasks.filter(x => !isDone(x) && calendarDayDiff(x.due) < 0).length;
    const closeCount = arr(ctx.todayCloseTasks).length;
    const estimateText = a.workMinutes ? durationLabel(a.workMinutes) : (a.workCount ? '未入力' : '0');
    const items = mode === 'closing'
      ? [['未完了', closeCount, closeCount ? 'danger' : 'ok'], ['見積', estimateText, a.workMinutes >= 420 ? 'danger' : ''], ['明日の候補', arr(ctx.tomorrowTasks).length, ''], ['要対応', a.riskCount, a.riskCount ? 'danger' : 'ok'], ['未追加', a.unlinkedCount, a.unlinkedCount ? 'danger' : 'ok']]
      : [['昨日以前', yesterdayOpen, yesterdayOpen ? 'danger' : 'ok'], ['今日の流れ', a.flowCount, ''], ['今日の作業', a.workCount, a.workCount >= 11 ? 'danger' : ''], ['見積', estimateText, a.workMinutes >= 420 ? 'danger' : ''], ['要対応', a.riskCount, a.riskCount ? 'danger' : 'ok'], ['未追加', a.unlinkedCount, a.unlinkedCount ? 'danger' : 'ok']];
    return `<div class="ritual-summary">${items.map(([label,num,cls]) => `<div class="ritual-chip ${esc(cls || '')}"><b>${esc(num)}</b><span>${esc(label)}</span></div>`).join('')}</div><p class="modal-note">${mode === 'closing' ? `今日の未完了を、完了・次の稼働日・待ちのいずれかに整理します。次の稼働日: ${fmtDate(ctx.tomorrow)}` : '昨日以前、今日の流れと作業、要対応、未追加の項目の順に整理します。'}</p>`;
  }

  function ritualStepsHtml(mode = 'morning') {
    const steps = mode === 'closing'
      ? ['未完了を確認', '完了・明日・待ちに置く', 'メモを残す', '整理を記録']
      : ['昨日以前を確認', '今日の流れを確認', '要対応と未追加の項目を整理', '今やる一件を決める'];
    return `<div class="ritual-step-flow">${steps.map((x,i)=>`<div class="ritual-step"><b>${i+1}</b><span>${esc(x)}</span></div>`).join('')}</div>`;
  }
  function ritualRowHtml(x, meta = [], actions = [], tone = '') {
    return `<div class="ritual-row-item ${esc(tone || '')}"><div><b>${esc(itemTitle(x))}</b><em>${meta.filter(Boolean).map(m => `<span>${esc(m)}</span>`).join('')}</em></div><div class="ritual-row-actions">${actions.map(a => `<button type="button" class="${esc(a.className || 'mini')}" ${a.attr || ''}>${esc(a.label)}</button>`).join('')}</div></div>`;
  }
  function ritualEmpty(text) { return `<div class="ritual-empty">${esc(text)}</div>`; }
  async function updateWorkTaskFromToday(id, updater, message) {
    const item = WORK.tasks.find(x => x.id === id);
    if (!item) return toast('作業が見つかりません');
    const snapshot = cloneRecord(item);
    updater(item);
    item.updatedAt = new Date().toISOString();
    await saveWorkTaskItem(item, snapshot.updatedAt || ''); renderAll();
    toast(message || '更新しました', {actionLabel:'元に戻す', onAction:()=>restoreWorkTaskSnapshot(snapshot)});
  }
  async function moveTaskToTodayFromPlan(id) {
    await updateWorkTaskFromToday(id, item => { item.status = 'today'; if (!item.due) item.due = today(); delete item.completedAt; }, '「今日やる」に移しました');
  }
  async function moveTaskToWaitingFromPlan(id) {
    await updateWorkTaskFromToday(id, item => { item.status = 'waiting'; delete item.completedAt; }, '「待ち」に移しました');
  }
  async function moveTaskToNextOpenDay(id) {
    const ds = nextOpenDay(today());
    await updateWorkTaskFromToday(id, item => { item.status = 'next'; item.due = ds; delete item.completedAt; }, `次の稼働日 ${fmtDate(ds)} へ送りました`);
  }
  async function quickCompleteWorkTaskAndRefresh(id, reopen = '') {
    await completeWorkTask(id, true);
    if (reopen === 'closing') setTimeout(openClosingReview, 60);
    if (reopen === 'morning') setTimeout(openMorningReview, 60);
  }
  function makeSpecWorkTask(collection, item, opts = {}) {
    const label = collection === 'jimu' ? '事務' : '期限';
    return {id:uid('wk'), title:`${label}: ${itemTitle(item)}`, status:opts.status || 'next', priority:item.priority || 'normal', due:opts.due !== undefined ? opts.due : (item.due || ''), estimateMinutes:Math.max(0, Number(opts.estimateMinutes || item.estimateMinutes || 0) || 0), nextAction:item.nextAction || '', caseId:item.caseId || '', personIds:arr(item.personIds), note:item.note || '', source:sourceId(collection, item.id), createdAt:new Date().toISOString(), updatedAt:new Date().toISOString()};
  }
  function makeCaseWorkTask(card, opts = {}) {
    const alert = caseAlertInfo(card);
    return {id:uid('wk'), title:`事案確認: ${card.title} / ${card.targetName}`, status:opts.status || 'next', priority:'high', due:opts.due !== undefined ? opts.due : ((alert && alert.date) || card.nextDate || ''), estimateMinutes:Math.max(0, Number(opts.estimateMinutes || card.estimateMinutes || 0) || 0), nextAction:card.nextAction || '次の一手を確認', caseId:card.caseId, personIds:[], note:[card.targetRole, card.note || card.case?.note || ''].filter(Boolean).join(' / '), source:caseTargetSource(card), createdAt:new Date().toISOString(), updatedAt:new Date().toISOString()};
  }
  async function sendUnlinkedToWork(status = 'next') {
    const tasks = [];
    for (const collection of ['deadlines','jimu']) {
      for (const item of DATA[collection]) {
        const diff = dayDiff(item.due);
        if (!isDone(item) && diff !== null && diff <= 7 && !workTaskForSource(collection, item.id)) {
          tasks.push(makeSpecWorkTask(collection, item, {status}));
        }
      }
    }
    for (const card of caseAlerts(7)) {
      if (!workTaskForCaseTarget(card)) tasks.push(makeCaseWorkTask(card, {status}));
    }
    if (!tasks.length) return toast('作業に追加する項目はありません');
    const j = await saveWorkTaskItems(tasks, []);
    const addedIds = arr(j.items).length ? arr(j.items).map(x => x.id).filter(Boolean) : tasks.map(x => x.id);
    renderAll();
    const msg = status === 'today' ? `${addedIds.length}件を作業に追加し、「今日やる」に移しました` : `${addedIds.length}件を作業に追加しました`;
    toast(j.merged ? `${msg}（最新データを反映）` : msg, {actionLabel:'元に戻す', onAction:()=>removeWorkTasksByIds(addedIds, 'まとめて作業に追加した内容を元に戻しました')});
  }
  async function markTodayRitual(kind) {
    const before = cloneRecord(todayRitualState());
    const st = todayRitualStore();
    st[`${kind}At`] = new Date().toISOString();
    await saveSpeculumPatch({settings:DATA.settings}, '');
    renderAll();
    const doneMessage = kind === 'planned' ? '今日の整理を記録しました' : '終業時の整理を記録しました';
    toast(doneMessage, {actionLabel:'記録を戻す', onAction:async()=>{
      const restore = todayRitualStore();
      Object.keys(restore).forEach(k => delete restore[k]);
      Object.assign(restore, before);
      await saveSpeculumPatch({settings:DATA.settings}, '記録を戻しました');
      renderAll();
    }});
  }
  function bindRitualModalActions(ctx, mode) {
    const form = $('modalForm'); if (!form) return;
    $$('[data-plan-task-today]', form).forEach(b => b.addEventListener('click', async () => { await moveTaskToTodayFromPlan(b.dataset.planTaskToday); closeModal(true); openMorningReview(); }));
    $$('[data-plan-task-wait]', form).forEach(b => b.addEventListener('click', async () => { await moveTaskToWaitingFromPlan(b.dataset.planTaskWait); closeModal(true); openMorningReview(); }));
    $$('[data-close-complete]', form).forEach(b => b.addEventListener('click', async () => { closeModal(true); await quickCompleteWorkTaskAndRefresh(b.dataset.closeComplete, 'closing'); }));
    $$('[data-close-next]', form).forEach(b => b.addEventListener('click', async () => { await moveTaskToNextOpenDay(b.dataset.closeNext); closeModal(true); openClosingReview(); }));
    $$('[data-close-wait]', form).forEach(b => b.addEventListener('click', async () => { await moveTaskToWaitingFromPlan(b.dataset.closeWait); closeModal(true); openClosingReview(); }));
    $$('[data-edit-work]', form).forEach(b => b.addEventListener('click', () => { const x = WORK.tasks.find(v => v.id === b.dataset.editWork); closeModal(true); if (x) openTaskModal(x); }));
    $$('[data-plan-unlinked]', form).forEach(b => b.addEventListener('click', async () => {
      const i = Number(b.dataset.planUnlinked); const x = arr(ctx.unlinked)[i];
      if (x?.collection && x?.item) await sendSpecToWork(x.collection, x.item, {status:'today'});
      else if (x?.caseCard) await caseToWork(x.caseCard, {status:'today'});
      else if (x && typeof x.send === 'function') await x.send();
      closeModal(true); openMorningReview();
    }));
    $$('[data-open-unlinked]', form).forEach(b => b.addEventListener('click', () => { const i = Number(b.dataset.openUnlinked); const x = arr(ctx.unlinked)[i]; closeModal(true); if (x && typeof x.open === 'function') x.open(); }));
    const allToday = form.querySelector('[data-plan-all-unlinked-today]');
    if (allToday) allToday.addEventListener('click', async () => { await sendUnlinkedToWork('today'); closeModal(true); openMorningReview(); });
    const allNext = form.querySelector('[data-plan-all-unlinked-next]');
    if (allNext) allNext.addEventListener('click', async () => { await sendUnlinkedToWork('next'); closeModal(true); openMorningReview(); });
    const done = form.querySelector('[data-ritual-done]');
    if (done) done.addEventListener('click', async () => { await markTodayRitual(mode === 'closing' ? 'closed' : 'planned'); closeModal(true); });
    const saveMemo = form.querySelector('[data-save-memo]');
    if (saveMemo) saveMemo.addEventListener('click', async () => { await saveMemos('今日メモを保存しました'); });
    const goWork = form.querySelector('[data-go-work]');
    if (goWork) goWork.addEventListener('click', () => { closeModal(true); openWorkspace('continuum'); });
    const goToday = form.querySelector('[data-go-today]');
    if (goToday) goToday.addEventListener('click', () => { closeModal(true); switchView('today'); });
  }
  async function openMorningReview() {
    const ctx = await collectTodayContext();
    const candidateRows = arr(ctx.planCandidates).slice(0, 8).map(x => ritualRowHtml(x, [fmtDate(x.due), x.due ? dueLabel(x.due) : '期限なし', estimateMeta(x), x.priority === 'high' ? '高優先' : '', caseName(x.caseId), peopleLabel(x)].filter(Boolean), [
      {label:'今日へ', className:'primary-inline', attr:`data-plan-task-today="${esc(x.id)}"`},
      {label:'待ち', attr:`data-plan-task-wait="${esc(x.id)}"`},
      {label:'編集', attr:`data-edit-work="${esc(x.id)}"`}
    ], calendarDayDiff(x.due) < 0 ? 'late' : '')).join('') || ritualEmpty('今日の作業に加える候補はありません。');
    const unlinkedRows = arr(ctx.unlinked).slice(0, 8).map((x,i) => ritualRowHtml(x, x.meta || [], [
      {label:'作業に追加して今日へ', className:'primary-inline', attr:`data-plan-unlinked="${i}"`},
      {label:'見る', attr:`data-open-unlinked="${i}"`}
    ], x.status || '')).join('') || ritualEmpty('作業にまだ追加していない期限・事案はありません。');
    const dangerRows = [...arr(ctx.criticalDue), ...arr(ctx.criticalCycles), ...arr(ctx.criticalAlerts)].slice(0, 6).map(x => ritualRowHtml({title:itemTitle(x) || x.title}, [x.label || x.alertKind || '要対応', fmtDate(x.due || x.nextRunDate || x.alertDate), dueLabel(x.due || x.nextRunDate || x.alertDate), statusLabel(x.status), priorityLabel(x.priority)].filter(Boolean), [
      {label:'見る', attr:'data-go-today'}
    ], 'late')).join('') || ritualEmpty('期限を過ぎた要対応項目はありません。');
    const html = `${ritualSummaryHtml(ctx, 'morning')}
      ${ritualStepsHtml('morning')}
      <div class="ritual-section"><h3>要対応 <small>期限を過ぎた項目から判断</small></h3><div class="ritual-list">${dangerRows}</div></div>
      <div class="ritual-section"><h3>今日の作業に加える候補 <small>期限・優先度・次の一手から選択</small></h3><div class="ritual-list">${candidateRows}</div></div>
      <div class="ritual-section"><h3>作業にまだ追加していない項目 <small>処理が必要なものだけ選択</small></h3><div class="ritual-list">${unlinkedRows}</div><div class="ritual-footer"><p class="muted">必要なものだけ作業に追加します。</p><div class="ritual-footer-actions"><button type="button" class="mini primary-inline" data-plan-all-unlinked-today>すべて「今日やる」に追加</button><button type="button" class="mini" data-plan-all-unlinked-next>すべて「次に進める」に追加</button></div></div></div>
      <div class="ritual-footer"><p class="muted">今日の予定と作業量を確認したら、整理完了として記録します。</p><div class="ritual-footer-actions"><button type="button" class="mini" data-go-work>作業管理へ</button><button type="button" class="primary" data-ritual-done>今日の整理完了</button></div></div>`;
    if (!openModal('今日を整理', html, null, null, {noSubmit:true})) return;
    bindRitualModalActions(ctx, 'morning');
  }
  async function openClosingReview() {
    const ctx = await collectTodayContext();
    const closeRows = arr(ctx.todayCloseTasks).slice(0, 18).map(x => ritualRowHtml(x, [clean(x.status) === 'today' ? '今日やる' : '', fmtDate(x.due), x.due ? dueLabel(x.due) : '期限なし', x.priority === 'high' ? '高優先' : '', estimateMeta(x), caseName(x.caseId), peopleLabel(x)].filter(Boolean), [
      {label:'完了', className:'primary-inline', attr:`data-close-complete="${esc(x.id)}"`},
      {label:'次の稼働日へ', attr:`data-close-next="${esc(x.id)}"`},
      {label:'待ち', attr:`data-close-wait="${esc(x.id)}"`},
      {label:'編集', attr:`data-edit-work="${esc(x.id)}"`}
    ], calendarDayDiff(x.due) < 0 ? 'late' : '')).join('') || ritualEmpty('今日から持ち越す作業はありません。');
    const memoText = clean($('todayMemo')?.value || DATA.memo?.today || DATA.memo?.days?.[today()] || '');
    const html = `${ritualSummaryHtml(ctx, 'closing')}
      ${ritualStepsHtml('closing')}
      <div class="ritual-section"><h3>今日の未完了 <small>頭に残さず、必ず置き場所を決める</small></h3><div class="ritual-list">${closeRows}</div></div>
      <div class="ritual-section"><h3>メモと未追加の項目 <small>明日に残す前に確認</small></h3><div class="ritual-list">
        ${ritualRowHtml({title:memoText ? '今日メモがあります' : '今日メモは空です'}, [memoText ? `${memoText.slice(0, 54)}${memoText.length > 54 ? '…' : ''}` : '必要なら今日の判断を残す'], [{label:'メモ保存', attr:'data-save-memo'}, {label:'今日へ戻る', attr:'data-go-today'}])}
        ${ritualRowHtml({title:`未追加 ${arr(ctx.unlinked).length}件`}, ['作業にまだ追加していない期限・事務・事案'], [{label:'今日の画面で確認', attr:'data-go-today'}], arr(ctx.unlinked).length ? 'late' : '')}
      </div></div>
      <div class="ritual-footer"><p class="muted">未完了の置き場所を決めたら、終業時の整理を記録します。</p><div class="ritual-footer-actions"><button type="button" class="mini" data-go-work>作業管理へ</button><button type="button" class="primary" data-ritual-done>整理を完了</button></div></div>`;
    if (!openModal('終業前の整理', html, null, null, {noSubmit:true})) return;
    bindRitualModalActions(ctx, 'closing');
  }


  function renderTodayPlanTimeline(ctx) {
    const box = $('todayPlanTimeline');
    const summary = $('todayPlanSummary');
    if (!box) return;
    const events = arr(ctx.todayEvents).map(e => ({kind: calendarKindLabel(e), time: clean(e.time), title: itemTitle(e), meta: [eventTimeLabel(e), e.place, scheduleShiftLabel(e), peopleLabel(e), caseName(e.caseId)].filter(Boolean), tone: calendarKind(e), actionLabel: '編集', onAction: () => openEventModal(DATA.events.find(x => x.id === e.id) || e)}));
    const dueItemsForPlan = arr(ctx.todayDueItems).filter(x => x.sourceType !== 'work').map(x => ({kind: x.label || '期限', time: '', title: itemTitle(x), meta: [dueLabel(x.due), priorityLabel(x.priority), peopleLabel(x), caseName(x.caseId), workTaskForSource(x.collection, x.id) ? '追加済み' : '未追加'].filter(Boolean), tone: x.calDiff < 0 ? 'danger' : 'due', actionLabel: workTaskForSource(x.collection, x.id) ? '作業管理' : '作業に追加', onAction: () => workTaskForSource(x.collection, x.id) ? openWorkspace('continuum') : sendSpecToWork(x.collection, x)}));
    const workItems = arr(ctx.todayWorkTasks).map(x => ({kind: '作業', time: '', title: itemTitle(x), meta: [clean(x.status) === 'today' ? '今日やる' : '', estimateMeta(x), x.due ? dueLabel(x.due) : '期限なし', x.priority === 'high' ? '高優先' : '', caseName(x.caseId), peopleLabel(x)].filter(Boolean), tone: calendarDayDiff(x.due) < 0 ? 'danger' : 'work', actionLabel: '完了', onAction: () => completeWorkTask(x.id, true), secondaryLabel: '編集', secondary: () => openTaskModal(x)}));
    const cycles = arr(ctx.todayCycles).map(x => ({kind: '周期', time: '', title: itemTitle(x), meta: [dueLabel(x.nextRunDate), x.rule, priorityLabel(x.priority)].filter(Boolean), tone: x.calDiff < 0 ? 'danger' : 'cycle', actionLabel: '今回完了', onAction: () => todayCycleAction(x.id, 'complete')}));
    const rows = [...events, ...dueItemsForPlan, ...workItems, ...cycles].sort((a,b) => {
      const ta = a.time ? a.time.replace(/[^0-9]/g, '').padEnd(4, '0') : '9999';
      const tb = b.time ? b.time.replace(/[^0-9]/g, '').padEnd(4, '0') : '9999';
      if (ta !== tb) return ta.localeCompare(tb);
      const order = {danger:0, schedule:1, happening:2, due:3, work:4, cycle:5};
      return (order[a.tone] ?? 9) - (order[b.tone] ?? 9) || a.title.localeCompare(b.title);
    });
    const fold = box.closest('details');
    if (fold) fold.hidden = rows.length === 0;
    const mins = totalEstimate(ctx.todayWorkTasks);
    const unestimated = arr(ctx.todayWorkTasks).filter(x => !estimateMinutes(x)).length;
    if (summary) summary.textContent = `予定${events.length} / 作業${workItems.length + cycles.length}${mins ? ' / 見積' + durationLabel(mins) : ''}${unestimated ? ' / 未見積' + unestimated : ''}`;
    box.innerHTML = '';
    if (!rows.length) { box.appendChild(emptyNode('今日の時系列に出す予定・期限・作業はありません。')); return; }
    rows.slice(0, 12).forEach(r => {
      const node = document.createElement('div');
      node.className = `plan-line ${esc(r.tone || '')}`;
      node.innerHTML = `<span class="plan-time">${esc(r.time || r.kind)}</span><div class="plan-main"><b>${esc(r.title)}</b><div class="item-meta">${metaHtml(r.meta || [])}</div></div><div class="plan-actions"></div>`;
      const actions = node.querySelector('.plan-actions');
      actions.appendChild(makeButtonAction({label:r.actionLabel || '開く', onClick:r.onAction}));
      if (r.secondary) actions.appendChild(makeButtonAction({label:r.secondaryLabel || '編集', onClick:r.secondary}));
      box.appendChild(node);
    });
    if (rows.length > 12) {
      const more = document.createElement('div');
      more.className = 'plan-more muted';
      more.textContent = `ほか ${rows.length - 12}件は各カードで確認`;
      box.appendChild(more);
    }
  }


  async function renderToday(options = {}) {
    const renderSeq = ++TODAY_RENDER_SEQ;
    const t = today();
    $('todayDate').textContent = fmtDate(t);
    syncMemoInputsFromData(); updateMemoPreview(); renderMemoHistory();
    let todayEvents = eventsOn(t, 'schedule');
    const summaryAge = Date.now() - SUMMARY_CACHE.at;
    const summaryCandidate = options.summary || (SUMMARY_CACHE.data && summaryAge >= 0 && summaryAge <= 1200 ? SUMMARY_CACHE.data : null);
    // 午前0時直後やPC復帰直後に前日の応答が遅れて届いても、当日の表示へ混ぜない。
    const summary = summaryCandidate && (!clean(summaryCandidate.today) || clean(summaryCandidate.today) === t) ? summaryCandidate : null;
    if (!summary && !options.skipSummaryLoad) {
      loadTodaySummary().then(fresh => {
        if (currentView === 'today' && renderSeq === TODAY_RENDER_SEQ) renderToday({summary:fresh, skipSummaryLoad:true});
      }).catch(() => {});
    }
    if (summary && (arr(summary.eventsToday).length || todayEvents.length)) todayEvents = arr(summary.eventsToday);
    const dueSoon = dueItems(true).map(x => ({...x, diff:dayDiff(x.due), calDiff:calendarDayDiff(x.due)})).filter(x => x.diff !== null && x.diff <= 7).sort((a,b) => a.diff - b.diff || byDate(a.due,b.due));
    const cyclesSoon = cycleDueItems();
    const localAlerts = caseAlerts(7);
    const alerts = summary ? arr(summary.caseAlerts).map(x => ({...x, caseId:x.id || x.caseId, alertKind:x.kind, alertDate:x.date, diff:x.days, targetName:x.targetName || x.targets || '', title:x.caseTitle || x.title || ''})) : localAlerts;
    const unlinked = unlinkedActionItems(localAlerts);
    const holidayState = holidayStatusText();
    const waitingLong = WORK.tasks.filter(x => !isDone(x) && clean(x.status) === 'waiting').map(x => ({...x, ageDays:taskAgeDays(x)})).filter(x => x.ageDays === null || x.ageDays >= 7).sort((a,b)=>(b.ageDays||0)-(a.ageDays||0));
    const highNoDue = WORK.tasks.filter(x => !isDone(x) && clean(x.priority) === 'high' && !clean(x.due)).sort((a,b)=>String(b.updatedAt||'').localeCompare(String(a.updatedAt||'')));

    const dueNode = (x) => {
      const linked = x.sourceType !== 'work' && !!workTaskForSource(x.collection, x.id);
      const actions = x.sourceType === 'work'
        ? [{label:'完了', onClick:()=>completeWorkTask(x.id, true)}, {label:'作業管理', onClick:()=>openWorkspace('continuum')}]
        : [{label:'完了', onClick:()=>completeItem(x.collection, x.id)}, {label:linked?'作業管理':'作業に追加', onClick:()=>linked?openWorkspace('continuum'):sendSpecToWork(x.collection, x), className:linked?'mini ok':'mini'}, {label:'編集', onClick:()=>openDueModal(x.collection, x)}];
      return itemNode(x, [`${x.label} ${fmtDate(x.due)}`, dueLabel(x.due), priorityLabel(x.priority), peopleLabel(x), caseName(x.caseId)].filter(Boolean), actions, x.calDiff < 0 ? 'late' : 'soon');
    };
    const eventNode = (e) => {
      const linked = !!workTaskForEvent(e);
      return itemNode(e, [eventTimeLabel(e), e.place, scheduleShiftLabel(e), peopleLabel(e), caseName(e.caseId)].filter(Boolean), [
        {label:'編集', onClick:()=>openEventModal(DATA.events.find(x=>x.id===e.id)||e)}, {label:linked?'作業管理':'作業に追加', onClick:()=>linked?openWorkspace('continuum'):eventToWork(e), className:linked?'mini ok':'mini'}
      ]);
    };
    const cycleNode = (c) => itemNode({title:itemTitle(c)}, ['周期作業', fmtDate(c.nextRunDate), dueLabel(c.nextRunDate), c.rule, priorityLabel(c.priority)].filter(Boolean), [
      {label:'今回完了', onClick:()=>todayCycleAction(c.id, 'complete')}, {label:'スキップ', onClick:()=>todayCycleAction(c.id, 'skip')}, {label:'作業管理', onClick:()=>openWorkspace('continuum')}
    ], c.calDiff < 0 ? 'late' : 'soon');
    const workNode = (x) => itemNode(x, ['作業管理', x.status === 'today' ? '今日やる' : '', fmtDate(x.due), x.due ? dueLabel(x.due) : '期限なし', x.priority === 'high' ? '高優先' : '', caseName(x.caseId), peopleLabel(x)].filter(Boolean), [
      {label:'完了', onClick:()=>completeWorkTask(x.id, true)}, {label:'作業管理', onClick:()=>openWorkspace('continuum')}, {label:'編集', onClick:()=>openTaskModal(x)}
    ], calendarDayDiff(x.due) < 0 ? 'late' : 'soon');
    const alertNode = (c) => {
      const linked = !!workTaskForCaseTarget(c);
      return itemNode({title:`${c.title}${c.targetName && !String(c.title || '').includes(c.targetName) ? ' / ' + c.targetName : ''}`}, [`${c.alertKind} ${fmtDate(c.alertDate)}`, dueLabel(c.alertDate), statusLabel(c.status), c.owner, c.nextAction].filter(Boolean), [
        {label:'編集', onClick:()=>openCaseTargetModal(c)}, {label:linked?'作業管理':'作業に追加', onClick:()=>linked?openWorkspace('continuum'):caseToWork(c), className:linked?'mini ok':'mini'}
      ], c.diff < 0 ? 'late' : 'soon');
    };

    const criticalDue = dueSoon.filter(x => x.calDiff < 0);
    const criticalCycles = cyclesSoon.filter(x => x.calDiff < 0);
    const criticalAlerts = alerts.filter(x => (calendarDayDiff(x.alertDate) ?? Number(x.diff)) < 0);
    const todayDueItems = dueSoon.filter(x => x.calDiff >= 0 && x.diff === 0);
    const todayCycles = cyclesSoon.filter(x => x.calDiff >= 0 && x.diff === 0);
    const nearDue = dueSoon.filter(x => x.calDiff >= 0 && x.diff > 0 && x.diff <= 7);
    const nearCycles = cyclesSoon.filter(x => x.calDiff >= 0 && x.diff > 0 && x.diff <= 7);
    const nearAlerts = alerts.filter(x => (calendarDayDiff(x.alertDate) ?? Number(x.diff)) >= 0 && Number(x.diff) <= 7);
    const todayWorkTasks = WORK.tasks.filter(x => !isDone(x) && (clean(x.status) === 'today' || calendarDayDiff(x.due) === 0)).sort((a,b) => {
      const ad = calendarDayDiff(a.due); const bd = calendarDayDiff(b.due);
      return (ad ?? 9999) - (bd ?? 9999) || (a.priority === 'high' ? -1 : 0) - (b.priority === 'high' ? -1 : 0) || itemTitle(a).localeCompare(itemTitle(b));
    });
    const confirmCount = (holidayState.warning && dueDayCountMode === 'business' ? 1 : 0) + waitingLong.length + highNoDue.length;
    const todayContextForStatus = {todayEvents, todayDueItems, todayWorkTasks, todayCycles, criticalDue, criticalCycles, criticalAlerts, unlinked, alerts, waitingLong, highNoDue};
    renderTodayLoadStatus(todayContextForStatus);
    renderTodayRitualState(todayContextForStatus);
    renderTodayDensityNotice(todayContextForStatus);
    renderTodayPlanTimeline(todayContextForStatus);

    const dueWorkTaskIds = new Set(dueSoon.filter(x => x.sourceType === 'work').map(x => x.id));
    const todayOnlyWorkAction = todayWorkTasks
      .filter(x => !dueWorkTaskIds.has(x.id))
      .map(x => ({title:itemTitle(x), meta:['作業', '今日やる', estimateMeta(x), x.priority === 'high' ? '高優先' : '', caseName(x.caseId), peopleLabel(x)].filter(Boolean).join(' / '), tone:'today', group:'work', primaryLabel:'完了', primary:()=>completeWorkTask(x.id, true), openLabel:'編集', open:()=>openTaskModal(x)}));

    const focusActionCandidates = [
      ...criticalDue.map(x => ({title:itemTitle(x), meta:`${x.label || '期限'} / ${dueLabel(x.due)}`, tone:'danger', group:'critical', primaryLabel:x.sourceType === 'work' ? '完了' : (workTaskForSource(x.collection, x.id) ? '作業管理' : '作業に追加'), primary:()=> x.sourceType === 'work' ? completeWorkTask(x.id, true) : (workTaskForSource(x.collection, x.id) ? openWorkspace('continuum') : sendSpecToWork(x.collection, x)), openLabel:x.sourceType === 'work' ? '作業管理' : '編集', open:()=> x.sourceType === 'work' ? openWorkspace('continuum') : openDueModal(x.collection, x)})),
      ...criticalCycles.map(x => ({title:itemTitle(x), meta:`周期作業 / ${dueLabel(x.nextRunDate)}`, tone:'danger', group:'critical', primaryLabel:'今回完了', primary:()=>todayCycleAction(x.id, 'complete'), openLabel:'作業管理', open:()=>openWorkspace('continuum')})),
      ...criticalAlerts.map(x => ({title:`${itemTitle(x)}${x.targetName ? ' / ' + x.targetName : ''}`, meta:`事案 / ${dueLabel(x.alertDate)}`, tone:'danger', group:'critical', primaryLabel:workTaskForCaseTarget(x)?'作業管理':'作業に追加', primary:()=>workTaskForCaseTarget(x)?openWorkspace('continuum'):caseToWork(x), openLabel:'編集', open:()=>openCaseTargetModal(x)})),
      ...todayOnlyWorkAction,
      ...todayDueItems.map(x => ({title:itemTitle(x), meta:`${x.label || '期限'} / ${dueLabel(x.due)}`, tone:'today', group:'now', primaryLabel:x.sourceType === 'work' ? '完了' : (workTaskForSource(x.collection, x.id) ? '作業管理' : '作業に追加'), primary:()=> x.sourceType === 'work' ? completeWorkTask(x.id, true) : (workTaskForSource(x.collection, x.id) ? openWorkspace('continuum') : sendSpecToWork(x.collection, x)), openLabel:x.sourceType === 'work' ? '作業管理' : '編集', open:()=> x.sourceType === 'work' ? openWorkspace('continuum') : openDueModal(x.collection, x)})),
      ...todayCycles.map(x => ({title:itemTitle(x), meta:`周期作業 / ${dueLabel(x.nextRunDate)}`, tone:'today', group:'now', primaryLabel:'今回完了', primary:()=>todayCycleAction(x.id, 'complete'), openLabel:'作業管理', open:()=>openWorkspace('continuum')})),
      ...todayEvents.map(x => ({title:itemTitle(x), meta:['予定', eventTimeLabel(x), x.place].filter(Boolean).join(' / '), tone:'today', group:'now', primaryLabel:'編集', primary:()=>openEventModal(DATA.events.find(v=>v.id===x.id)||x), openLabel:workTaskForEvent(x)?'作業管理':'作業に追加', open:()=>workTaskForEvent(x)?openWorkspace('continuum'):eventToWork(x)})),
      ...nearDue.map(x => ({title:itemTitle(x), meta:`${x.label || '期限'} / ${dueLabel(x.due)}`, tone:'near', group:'near', primaryLabel:x.sourceType === 'work' ? '完了' : (workTaskForSource(x.collection, x.id) ? '作業管理' : '作業に追加'), primary:()=> x.sourceType === 'work' ? completeWorkTask(x.id, true) : (workTaskForSource(x.collection, x.id) ? openWorkspace('continuum') : sendSpecToWork(x.collection, x)), openLabel:x.sourceType === 'work' ? '作業管理' : '編集', open:()=> x.sourceType === 'work' ? openWorkspace('continuum') : openDueModal(x.collection, x)})),
      ...nearCycles.map(x => ({title:itemTitle(x), meta:`周期作業 / ${dueLabel(x.nextRunDate)}`, tone:'near', group:'near', primaryLabel:'今回完了', primary:()=>todayCycleAction(x.id, 'complete'), openLabel:'作業管理', open:()=>openWorkspace('continuum')})),
      ...nearAlerts.map(x => ({title:`${itemTitle(x)}${x.targetName ? ' / ' + x.targetName : ''}`, meta:`事案 / ${dueLabel(x.alertDate)}`, tone:'near', group:'cases', primaryLabel:workTaskForCaseTarget(x)?'作業管理':'作業に追加', primary:()=>workTaskForCaseTarget(x)?openWorkspace('continuum'):caseToWork(x), openLabel:'編集', open:()=>openCaseTargetModal(x)}))
    ];
    setTodayFocusAction(focusActionCandidates);

    const todayWorkTaskIds = new Set(todayWorkTasks.map(x => x.id));
    const criticalDueForCard = criticalDue.filter(x => x.sourceType !== 'work' || !todayWorkTaskIds.has(x.id));
    const criticalNodes = [
      ...criticalDueForCard.map(dueNode),
      ...criticalCycles.map(cycleNode),
      ...criticalAlerts.map(alertNode)
    ];
    setCommanderList('todayCritical', 'critical', criticalNodes, '今日中に判断する要対応項目はありません。');

    const todayFlowDue = todayDueItems.filter(x => x.sourceType !== 'work');
    const flowNodes = [
      ...todayEvents.map(eventNode),
      ...todayFlowDue.map(dueNode)
    ];
    setCommanderList('todayNow', 'now', flowNodes, '今日の予定・出来事・締切はありません。');

    const workNodes = [
      ...todayWorkTasks.map(workNode),
      ...todayCycles.map(cycleNode)
    ].slice(0, 24);
    setCommanderList('todayWorkDashboard', 'work', workNodes, '今日処理する作業はありません。');

    const nearNodes = [
      ...nearDue.map(dueNode),
      ...nearCycles.map(cycleNode)
    ].slice(0, 24);
    setCommanderList('todayNear', 'near', nearNodes, `7${dueDayCountMode === 'business' ? '営業日' : '日'}以内の期限はありません。`);

    const caseDashboardItems = alerts.filter(x => (calendarDayDiff(x.alertDate) ?? Number(x.diff)) >= 0);
    const caseDashboardNodes = caseDashboardItems.slice(0, 12).map(alertNode);
    setCommanderList('todayCaseDashboard', 'cases', caseDashboardNodes, '今後確認する事案はありません。');

    setTinyText('todayCriticalCount', String(criticalDueForCard.length + criticalCycles.length + criticalAlerts.length));
    setTinyText('todayNowCount', String(flowNodes.length));
    setTinyText('todayWorkCount', String(todayWorkTasks.length + todayCycles.length));
    setTinyText('todayNearCount', String(nearDue.length + nearCycles.length));
    setTinyText('todayCaseDashCount', String(caseDashboardItems.length));
    setTinyText('todayUnlinkedCount', `${unlinked.length}件`);
    setTinyText('todayConfirmCount', `${confirmCount}件`);
    if ($('todayUnlinkedFold')) $('todayUnlinkedFold').hidden = unlinked.length === 0;
    if ($('todayConfirmFold')) $('todayConfirmFold').hidden = confirmCount === 0;
    if ($('todayAllFold')) $('todayAllFold').hidden = todayEvents.length === 0 && dueSoon.length === 0;

    const confirmNodes = [];
    if (holidayState.warning && dueDayCountMode === 'business') {
      confirmNodes.push(itemNode({title:'祝日データ未取得'}, ['実稼働日数は土日のみ除外で表示中', '祝日取得後に判定がより正確になります'], [{label:'祝日取得', onClick:()=>importCabinetHolidays()}], 'soon'));
    }
    waitingLong.slice(0,5).forEach(x => confirmNodes.push(itemNode(x, ['待ち状態', x.ageDays === null ? '更新日不明' : `${x.ageDays}日更新なし`, fmtDate(x.due), estimateMeta(x), caseName(x.caseId), peopleLabel(x)].filter(Boolean), [{label:'作業管理', onClick:()=>openWorkspace('continuum')}], 'soon')));
    highNoDue.slice(0,5).forEach(x => confirmNodes.push(itemNode(x, ['高優先', '期限なし', estimateMeta(x), caseName(x.caseId), peopleLabel(x)].filter(Boolean), [{label:'編集', onClick:()=>openTaskModal(x)}, {label:'作業管理', onClick:()=>openWorkspace('continuum')}], 'soon')));
    setList('todayConfirm', confirmNodes.slice(0,24), '追加で確認する項目はありません。');

    setList('todayEvents', todayEvents.map(eventNode), '今日の予定はありません。');
    setList('todayDue', dueSoon.slice(0, 12).map(dueNode), '迫っている期限・作業はありません。');
    setList('actionSuggestions', unlinked.slice(0,10).map(x => itemNode(x, x.meta, [{label:'作業に追加', onClick:x.send}, {label:'元情報を見る', onClick:x.open}], x.status)), '作業にまだ追加していない項目はありません。');
  }

  function memoDraftData() {
    const next = Object.assign({today:'', todayDate:'', permanent:'', days:{}}, cloneRecord(DATA?.memo));
    next.days = Object.assign({}, next.days || {});
    const currentDay = today();
    const draftDay = MEMO_DRAFT_DAY || currentDay;
    const draftText = $('todayMemo')?.value || '';
    next.permanent = $('permanentMemo')?.value || '';
    next.days[draftDay] = draftText;
    next.today = String(next.days[currentDay] || '');
    next.todayDate = currentDay;
    return next;
  }
  function memoContentSignature(value) {
    const memo = Object.assign({today:'', permanent:'', days:{}}, value || {});
    return JSON.stringify({today:String(memo.today || ''), permanent:String(memo.permanent || ''), days:memo.days || {}});
  }
  function syncMemoInputsFromData(force = false) {
    if (MEMO_DRAFT_DIRTY && !force) return;
    const t = today();
    if ($('todayMemo')) $('todayMemo').value = Object.prototype.hasOwnProperty.call(DATA.memo?.days || {}, t) ? String(DATA.memo.days[t] || '') : (clean(DATA.memo?.todayDate) === t ? String(DATA.memo?.today || '') : '');
    if ($('permanentMemo')) $('permanentMemo').value = DATA.memo?.permanent || '';
    MEMO_DRAFT_DAY = t;
    MEMO_DRAFT_DIRTY = false;
  }
  function renderMemoHistory() {
    const box = $('memoHistory'); if (!box) return;
    box.innerHTML = '';
    const days = Object.entries(DATA.memo?.days || {}).filter(([,v]) => clean(v)).sort((a,b)=>String(b[0]).localeCompare(String(a[0]))).slice(0,20);
    if (!days.length) { box.appendChild(emptyNode('メモ履歴はまだありません。')); return; }
    days.forEach(([ds,text]) => {
      const node = document.createElement('div');
      node.className = 'item';
      node.innerHTML = `<div><div class="item-title">${esc(fmtDate(ds))}</div><div class="item-meta"><span>${esc(String(text).slice(0,80))}${String(text).length>80?'…':''}</span></div></div><div class="item-actions"><button type="button" class="mini">開く</button></div>`;
      node.querySelector('button').onclick = () => {
        DATA.memo.today = DATA.memo.days[ds] || '';
        $('todayMemo').value = DATA.memo.today;
        $('todayMemo').dispatchEvent(new Event('input', {bubbles:true}));
        showMemoPanel('today');
      };
      box.appendChild(node);
    });
  }
  function showMemoPanel(name) {
    $$('.memo-tabs button').forEach(b => b.classList.toggle('active', b.dataset.memoTab === name));
    $$('[data-memo-panel]').forEach(p => { p.hidden = p.dataset.memoPanel !== name; });
    updateMemoPreview();
  }
  async function saveMemos(message='メモを保存しました') {
    if (message) MEMO_SAVE_NOTICE = message;
    if (MEMO_SAVE_RUNNING) { MEMO_SAVE_PENDING = true; return false; }
    MEMO_SAVE_RUNNING = true;
    try {
      do {
        MEMO_SAVE_PENDING = false;
        const previous = cloneRecord(DATA.memo);
        const next = memoDraftData();
        const notice = MEMO_SAVE_NOTICE;
        MEMO_SAVE_NOTICE = '';
        if (memoContentSignature(next) === memoContentSignature(previous)) {
          MEMO_DRAFT_DIRTY = false;
          if (notice) toast('メモは保存済みです');
          continue;
        }
        DATA.memo = next;
        try {
          await saveSpeculumPatch({memo:next}, '');
        } catch (err) {
          MEMO_SAVE_PENDING = false;
          MEMO_SAVE_NOTICE = '';
          if (err?.reloaded) {
            syncMemoInputsFromData(true);
            updateMemoPreview();
          } else {
            DATA.memo = previous;
            MEMO_DRAFT_DIRTY = true;
          }
          if (!err?.handled && !err?.cancelled) toast(err?.message || 'メモを保存できませんでした');
          return false;
        }
        const latestDraft = memoDraftData();
        MEMO_DRAFT_DIRTY = memoContentSignature(latestDraft) !== memoContentSignature(DATA.memo);
        renderMemoHistory();
        if (notice) toast(notice);
      } while (MEMO_SAVE_PENDING || MEMO_DRAFT_DIRTY);
      return true;
    } finally {
      MEMO_SAVE_RUNNING = false;
      if (MEMO_DRAFT_DAY !== today()) queueMicrotask(() => refreshDayContextIfNeeded());
    }
  }
  async function settleMemoBeforeRestore() {
    clearTimeout(bind.memoTimer);
    if (MEMO_SAVE_RUNNING) {
      MEMO_SAVE_PENDING = true;
      const deadline = performance.now() + 15000;
      while (MEMO_SAVE_RUNNING && performance.now() < deadline) await new Promise(resolve => setTimeout(resolve, 25));
      if (MEMO_SAVE_RUNNING) throw new Error('メモの保存が終わっていません。少し待ってから復元してください');
    }
    const draft = memoDraftData();
    if (MEMO_DRAFT_DIRTY || memoContentSignature(draft) !== memoContentSignature(DATA.memo)) {
      const saved = await saveMemos('');
      if (!saved) throw new Error('入力中のメモを保存できないため、復元を中止しました');
    }
  }
  function resetMemoSaveAfterRestore() {
    clearTimeout(bind.memoTimer);
    MEMO_SAVE_PENDING = false;
    MEMO_SAVE_NOTICE = '';
    MEMO_DRAFT_DIRTY = false;
  }

  function caseAlerts(_days = 7) {
    const alerts = [];
    caseTargetCards().forEach(card => {
      const hit = caseAlertInfo(card);
      if (hit) alerts.push({...card, diff:hit.diff, alertKind:hit.label, alertDate:hit.date});
    });
    return alerts.sort((a,b) => a.diff - b.diff || byDate(a.alertDate, b.alertDate));
  }
  function unlinkedActionItems(alertRows = null) {
    const out = [];
    for (const collection of ['deadlines','jimu']) {
      const label = collection === 'jimu' ? '事務' : '期限';
      DATA[collection].forEach(x => {
        const diff = dayDiff(x.due);
        if (!isDone(x) && diff !== null && diff <= 7 && !workTaskForSource(collection, x.id)) {
          out.push({title:itemTitle(x), meta:[label, fmtDate(x.due), dueLabel(x.due), caseName(x.caseId), peopleLabel(x)], status:calendarDayDiff(x.due) < 0 ? 'late' : 'soon', collection, item:x, send:()=>sendSpecToWork(collection, x), open:()=>openDueModal(collection, x)});
        }
      });
    }
    (Array.isArray(alertRows) ? alertRows : caseAlerts(7)).forEach(c => {
      if (!workTaskForCaseTarget(c)) out.push({title:`${c.title} / ${c.targetName}`, meta:['事案', c.alertKind, fmtDate(c.alertDate), dueLabel(c.alertDate), c.status], status:c.diff < 0 ? 'late' : 'soon', caseCard:c, send:()=>caseToWork(c), open:()=>openCaseTargetModal(c)});
    });
    return out;
  }

  function holidayStatusText() {
    const items = Object.keys(DATA?.holidays?.items || {}).filter(Boolean).sort();
    if (!items.length) return {warning:true, text:'祝日データ未取得。土日祝日調整は土日のみで判定されています。'};
    const years = Array.from(new Set(items.map(x => x.slice(0,4)).filter(Boolean))).sort();
    return {warning:false, text:`祝日データ: ${years[0]}年〜${years[years.length-1]}年取得済み（${items.length}件）`};
  }
  function renderHolidayStatus() {
    const box = $('holidayStatus'); if (!box) return;
    const st = holidayStatusText();
    box.textContent = st.text;
    box.classList.toggle('warn', !!st.warning);
  }
  function calendarDueItems() {
    const out = [];
    DATA.deadlines.forEach(x => { if (calendarShowDone || !isDone(x)) out.push({...x, collection:'deadlines', label:'期限', due:x.due, sourceType:'spec'}); });
    DATA.jimu.forEach(x => { if (calendarShowDone || !isDone(x)) out.push({...x, collection:'jimu', label:'事務', due:x.due, sourceType:'spec'}); });
    return out;
  }
  function calendarWorkItems() {
    const out = [];
    WORK.tasks.forEach(x => { if (x.due && (calendarShowDone || !isDone(x))) out.push({...x, collection:'work', label:'作業', due:x.due, sourceType:'work'}); });
    return out;
  }
  function calendarEventItemsOn(ds) {
    return eventsOn(ds).filter(e => calendarShowRepeat || clean(e.repeat || 'none') === 'none' || e._baseDate === e.date);
  }
  async function saveCalendarSettings() {
    DATA.settings = Object.assign({}, DATA.settings || {}, {
      calendarItemMode,
      calendarShowDue: calendarShowDue ? '1' : '0',
      calendarShowWork: calendarShowWork ? '1' : '0',
      calendarShowDone: calendarShowDone ? '1' : '0',
      calendarShowRepeat: calendarShowRepeat ? '1' : '0',
      dueDayCountMode
    });
    await saveSpeculumPatch({settings:DATA.settings}, '');
  }
  function setCalendarItemMode(mode) {
    calendarItemMode = ['both','schedule','happening'].includes(mode) ? mode : 'both';
    saveCalendarSettings().catch(err => { if (!err?.handled && !err?.cancelled) toast(err?.message || 'カレンダーの表示設定を保存できませんでした'); });
    renderCalendar();
  }
  function setCalendarToggle(name, value) {
    if (name === 'due') calendarShowDue = !!value;
    if (name === 'work') calendarShowWork = !!value;
    if (name === 'done') calendarShowDone = !!value;
    if (name === 'repeat') calendarShowRepeat = !!value;
    saveCalendarSettings().catch(err => { if (!err?.handled && !err?.cancelled) toast(err?.message || 'カレンダーの表示設定を保存できませんでした'); });
    renderCalendar();
  }

  function eventBaseRecord(item) {
    const source = item?.id ? (DATA.events.find(x => x.id === item.id) || item) : item;
    const base = cloneRecord(source || {});
    delete base._ds; delete base._baseDate; delete base._shifted; delete base._kind;
    delete base.collection; delete base.label; delete base.sourceType;
    return base;
  }

  function occurrenceCacheWithEvent(cache, event) {
    const current = cache && cache.start && cache.end ? cache : null;
    if (!current || !event?.id) return {key:'', start:'', end:'', mode:'both', items:[]};
    const items = arr(current.items).filter(x => x.id !== event.id);
    let ds = current.start;
    let guard = 0;
    while (ds && ds <= current.end && guard++ < 370) {
      const info = eventOccurrenceInfo(event, ds);
      if (info && (current.mode === 'both' || calendarKind(event) === current.mode)) {
        items.push(Object.assign({}, event, {_ds:ds, _baseDate:info.baseDate, _shifted:info.shifted}));
      }
      ds = addDays(ds, 1);
    }
    items.sort((a,b)=>byDate(a._ds || a.date,b._ds || b.date)||occurrenceSort(a,b));
    return Object.assign({}, current, {items});
  }

  function calendarDragPayload(raw = '') {
    if (CALENDAR_DRAG?.id) return CALENDAR_DRAG;
    try {
      const value = JSON.parse(raw || '{}');
      return value && value.id ? value : null;
    } catch (_) { return null; }
  }

  function bindCalendarEventDrag(chip, event, ds) {
    if (!chip || !event?.id || calendarKind(event) !== 'schedule') return;
    chip.draggable = true;
    chip.addEventListener('dragstart', e => {
      CALENDAR_DRAG = {id:event.id, fromDate:ds, baseDate:clean(event._baseDate || event.date || ds)};
      chip.classList.add('dragging');
      document.body.classList.add('dragging-calendar-item');
      try {
        const text = JSON.stringify(CALENDAR_DRAG);
        e.dataTransfer.setData('application/x-blackcat-calendar-event', text);
        e.dataTransfer.setData('text/plain', text);
        e.dataTransfer.effectAllowed = 'move';
      } catch (_) {}
    });
    chip.addEventListener('dragend', () => {
      chip.classList.remove('dragging');
      document.body.classList.remove('dragging-calendar-item');
      $$('.day-cell.calendar-drop-target').forEach(x => x.classList.remove('calendar-drop-target'));
      CALENDAR_SUPPRESS_CLICK_UNTIL = Date.now() + 260;
      CALENDAR_DRAG = null;
    });
  }

  function bindCalendarDateDrop(cell, ds) {
    if (!cell) return;
    cell.dataset.calendarDate = ds;
    cell.addEventListener('dragover', e => {
      if (!CALENDAR_DRAG?.id) return;
      e.preventDefault();
      try { e.dataTransfer.dropEffect = 'move'; } catch (_) {}
      cell.classList.add('calendar-drop-target');
    });
    cell.addEventListener('dragleave', e => {
      if (!cell.contains(e.relatedTarget)) cell.classList.remove('calendar-drop-target');
    });
    cell.addEventListener('drop', async e => {
      e.preventDefault(); e.stopPropagation();
      cell.classList.remove('calendar-drop-target');
      const raw = (() => { try { return e.dataTransfer.getData('application/x-blackcat-calendar-event') || e.dataTransfer.getData('text/plain'); } catch (_) { return ''; } })();
      const payload = calendarDragPayload(raw);
      CALENDAR_SUPPRESS_CLICK_UNTIL = Date.now() + 300;
      if (!payload || payload.fromDate === ds) return;
      try { await moveCalendarOccurrence(payload, ds); }
      catch (err) { if (!err?.handled && !err?.cancelled) toast(err?.message || '予定を移動できませんでした'); }
    });
  }

  async function moveCalendarOccurrence(payload, targetDate) {
    if (CALENDAR_MOVE_BUSY) { toast('予定を移動しています'); return; }
    const source = DATA.events.find(x => x.id === payload?.id);
    if (!source || calendarKind(source) !== 'schedule') return;
    const baseDate = clean(payload.baseDate || payload.fromDate || source.date);
    const repeat = clean(source.repeat || 'none');
    if (repeat !== 'none') {
      const collision = eventsOn(targetDate, 'schedule').find(x => x.id === source.id && clean(x._baseDate || x.date) !== baseDate);
      if (collision) { toast('同じ繰り返し予定がある日には移動できません'); return; }
    }
    const snapshot = eventBaseRecord(source);
    const moved = eventBaseRecord(source);
    if (repeat === 'none') {
      moved.date = targetDate;
    } else {
      const exceptions = Object.assign({}, moved.exceptions || {});
      const ex = Object.assign({}, exceptions[baseDate] || {});
      if (clean(ex.action).toLowerCase() === 'skip') delete ex.action;
      ex.date = targetDate;
      exceptions[baseDate] = ex;
      moved.exceptions = exceptions;
    }
    moved.updatedAt = new Date().toISOString();
    const cacheBefore = Object.assign({}, OCCURRENCE_CACHE, {items:arr(OCCURRENCE_CACHE.items).slice()});
    CALENDAR_MOVE_BUSY = true;
    try {
      upsertSpeculumLocal('events', moved);
      OCCURRENCE_CACHE = occurrenceCacheWithEvent(cacheBefore, moved);
      renderCalendar({skipLoad:true});
      const j = await saveSpeculumItem('events', moved, snapshot.updatedAt || '');
      const saved = eventBaseRecord(j.item || DATA.events.find(x => x.id === moved.id) || moved);
      if (j.merged) renderCalendar();
      else {
        OCCURRENCE_CACHE = occurrenceCacheWithEvent(cacheBefore, saved);
        renderCalendar({skipLoad:true});
      }
      toast(`${fmtDate(payload.fromDate)} から ${fmtDate(targetDate)} へ移動しました`, {actionLabel:'元に戻す', onAction:()=>restoreDataItemSnapshot('events', snapshot, '予定の移動を元に戻しました')});
    } catch (err) {
      if (!err?.handled && !err?.reloaded) {
        upsertSpeculumLocal('events', snapshot);
        OCCURRENCE_CACHE = occurrenceCacheWithEvent(cacheBefore, snapshot);
        renderCalendar({skipLoad:true});
      }
      throw err;
    } finally {
      CALENDAR_MOVE_BUSY = false;
    }
  }

  async function skipCalendarOccurrence(eventId, occurrenceDate, baseDate = '') {
    return runUiAction(`event-skip:${eventId}:${baseDate || occurrenceDate}`, async () => {
      const current = DATA.events.find(item => item.id === eventId);
      if (!current || clean(current.repeat || 'none') === 'none') return false;
      const snapshot = eventBaseRecord(current);
      const next = eventBaseRecord(current);
      const base = clean(baseDate || occurrenceDate);
      const exceptions = Object.assign({}, next.exceptions || {});
      const exception = Object.assign({}, exceptions[base] || {});
      delete exception.date;
      exception.action = 'skip';
      exceptions[base] = exception;
      next.exceptions = exceptions;
      next.updatedAt = new Date().toISOString();
      await saveSpeculumItem('events', next, snapshot.updatedAt || '');
      renderAll();
      toast(`${fmtDate(occurrenceDate)} の回だけを除外しました`, {actionLabel:'元に戻す', ms:8000, onAction:()=>restoreDataItemSnapshot('events', snapshot, '除外した回を元に戻しました')});
      return true;
    }, 'この回を除外できませんでした');
  }

  async function renderCalendar(options = {}) {
    const seq = ++CALENDAR_RENDER_SEQ;
    const y = calCursor.getFullYear(); const m = calCursor.getMonth();
    $('monthTitle').textContent = `${y}年 ${m+1}月`;
    if ($('jumpDate')) $('jumpDate').value = `${y}-${pad(m+1)}-01`;
    const first = new Date(y, m, 1); const start = new Date(first); start.setDate(1 - first.getDay());
    const rangeStart = `${start.getFullYear()}-${pad(start.getMonth()+1)}-${pad(start.getDate())}`;
    const rangeEndDate = new Date(start); rangeEndDate.setDate(start.getDate() + 41);
    const rangeEnd = `${rangeEndDate.getFullYear()}-${pad(rangeEndDate.getMonth()+1)}-${pad(rangeEndDate.getDate())}`;
    if (!options.skipLoad) { try { await loadOccurrences(rangeStart, rangeEnd, 'both'); } catch (_) {} }
    if (seq !== CALENDAR_RENDER_SEQ) return;
    const grid = $('calendarGrid'); if (grid) grid.innerHTML = '';
    if (grid) ['日','月','火','水','木','金','土'].forEach(d => { const e=document.createElement('div'); e.className='dow'; e.textContent=d; grid.appendChild(e); });
    const groupByDate = (items, keyFn) => {
      const map = new Map();
      arr(items).forEach(item => {
        const key = clean(keyFn(item));
        if (!key) return;
        if (!map.has(key)) map.set(key, []);
        map.get(key).push(item);
      });
      return map;
    };
    const scheduleTokens = searchTokens($('scheduleSearch')?.value || '');
    const matchesSchedule = item => matchesSearchTokens(scheduleTokens, scheduleHay(item));
    const occurrenceRangeReady = cacheCovers(rangeStart, 'both') && cacheCovers(rangeEnd, 'both');
    const eventMap = occurrenceRangeReady ? groupByDate(OCCURRENCE_CACHE.items.filter(e => calendarModeMatches(e) && (calendarShowRepeat || clean(e.repeat || 'none') === 'none' || e._baseDate === e.date) && matchesSchedule(e)), e => e._ds || e.date) : null;
    const dueMap = (calendarItemMode === 'both' && calendarShowDue) ? groupByDate(calendarDueItems().filter(matchesSchedule), x => x.due) : new Map();
    const workMap = (calendarItemMode === 'both' && calendarShowWork) ? groupByDate(calendarWorkItems().filter(matchesSchedule), x => x.due) : new Map();
    const monthItems = [];
    for (let i=0;i<42;i++) {
      const d = new Date(start); d.setDate(start.getDate()+i);
      const ds = `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}`;
      const evs = eventMap ? arr(eventMap.get(ds)) : calendarEventItemsOn(ds).filter(matchesSchedule);
      const dues = arr(dueMap.get(ds));
      const works = arr(workMap.get(ds));
      const scheduleEvents = evs.filter(e => calendarKind(e) === 'schedule');
      const happeningEvents = evs.filter(e => calendarKind(e) === 'happening');
      [
        ...scheduleEvents.map(e=>({...e, _kind:'予定', _ds:ds})),
        ...dues.map(x=>({...x, _kind:x.label, _ds:ds})),
        ...works.map(x=>({...x, _kind:'作業', _ds:ds})),
        ...happeningEvents.map(e=>({...e, _kind:'出来事', _ds:ds}))
      ].forEach(x => { if (d.getMonth() === m) monthItems.push(x); });
      const cell = document.createElement('button');
      const hname = holidayName(ds);
      const week = d.getDay();
      const total = scheduleEvents.length + dues.length + works.length + happeningEvents.length;
      cell.className = `day-cell ${d.getMonth()===m?'':'out'} ${ds===today()?'today':''} ${total?'has-things':''} ${total>=6?'crowded':''} ${hname?'holiday':''} ${week===0?'sun':''} ${week===6?'sat':''}`;
      const eventChip = (e) => {
        const dragData = calendarKind(e) === 'schedule' ? ` data-calendar-event-id="${esc(e.id)}" data-calendar-base-date="${esc(e._baseDate || e.date || ds)}" data-calendar-occurrence-date="${esc(ds)}"` : '';
        return `<span class="day-chip event-${calendarKindClass(e)}"${dragData}>${esc((eventTimeLabel(e)?eventTimeLabel(e)+' ':'') + e.title)}${e.repeat&&e.repeat!=='none'?' ↻':''}${e._shifted?' ⇄':''}</span>`;
      };
      const chipEntries = [
        ...scheduleEvents.map(e => ({rank:10, title:`${eventTimeLabel(e) || ''} ${itemTitle(e)}`, html:eventChip(e)})),
        ...dues.map(x => {
          const rd = calendarDayDiff(x.due);
          return {rank:rd !== null && rd < 0 ? 0 : (rd === 0 ? 5 : 15), title:itemTitle(x), html:`<span class="day-chip due">${esc((x.label || '') + ' ' + itemTitle(x))}</span>`};
        }),
        ...works.map(x => {
          const rd = calendarDayDiff(x.due);
          return {rank:rd !== null && rd < 0 ? 1 : (rd === 0 ? 6 : 20), title:itemTitle(x), html:`<span class="day-chip work">${esc('作業 ' + itemTitle(x))}</span>`};
        }),
        ...happeningEvents.map(e => ({rank:30, title:itemTitle(e), html:eventChip(e)}))
      ].sort((a,b) => a.rank - b.rank || String(a.title).localeCompare(String(b.title)));
      const maxDayChips = 3;
      const chips = chipEntries.slice(0,maxDayChips).map(x => x.html);
      const more = Math.max(0, total - chips.length);
      const sub = hname ? `<span class="day-sub">${esc(hname)}</span>` : '';
      cell.innerHTML = `<span class="day-num"><span>${d.getDate()}</span>${sub}</span><span class="day-chips">${chips.join('')}${more?`<span class="day-chip more">＋${more}件</span>`:''}</span><span class="day-add-cue">${total ? 'この日を開く' : '日を開く'}</span>`;
      cell.querySelectorAll('[data-calendar-event-id]').forEach(chip => {
        const event = scheduleEvents.find(x => x.id === chip.dataset.calendarEventId && clean(x._baseDate || x.date || ds) === clean(chip.dataset.calendarBaseDate));
        if (event) bindCalendarEventDrag(chip, event, ds);
      });
      bindCalendarDateDrop(cell, ds);
      cell.addEventListener('click', () => { if (Date.now() >= CALENDAR_SUPPRESS_CLICK_UNTIL) openDay(ds); });
      if (grid) grid.appendChild(cell);
    }
    renderScheduleList(monthItems);
    if (grid) grid.hidden = calendarMode !== 'month';
    if ($('scheduleListView')) $('scheduleListView').hidden = calendarMode !== 'list';
    $$('#monthViewBtn,#listViewBtn').forEach(b => b.classList.toggle('active', (b.id==='monthViewBtn'&&calendarMode==='month') || (b.id==='listViewBtn'&&calendarMode==='list')));
    $$('#calendarBothBtn,#calendarScheduleBtn,#calendarHappeningBtn').forEach(b => {
      const mode = b.id === 'calendarScheduleBtn' ? 'schedule' : (b.id === 'calendarHappeningBtn' ? 'happening' : 'both');
      b.classList.toggle('active', calendarItemMode === mode);
    });
    [['calendarDueToggle', calendarShowDue], ['calendarWorkToggle', calendarShowWork], ['calendarDoneToggle', calendarShowDone], ['calendarRepeatToggle', calendarShowRepeat]].forEach(([id, val]) => { const el=$(id); if(el) el.checked = !!val; });
    $$('.calendar-extra-toggle').forEach(el => { el.classList.toggle('disabled-mode', calendarItemMode !== 'both' && ['calendarDueToggle','calendarWorkToggle','calendarDoneToggle'].includes(el.querySelector('input')?.id || '')); });
    renderHolidayStatus();
    const cachedUpcoming = OCCURRENCE_CACHE.items.filter(e => calendarKind(e) === 'schedule' && (e._ds || e.date) >= today());
    const upcomingAll = (cachedUpcoming.length ? cachedUpcoming : DATA.events.map(e => calendarKind(e) === 'schedule' ? nextOccurrenceOnOrAfter(e) : null).filter(Boolean)).sort((a,b)=>byDate(a._ds,b._ds)||String(a.time||'99:99').localeCompare(String(b.time||'99:99')));
    renderUpcomingEvents(upcomingAll);
  }

  function renderUpcomingEvents(upcomingAll) {
    const box = $('upcomingEvents'); if (!box) return;
    box.innerHTML = '';
    const list = arr(upcomingAll);
    setTinyText('upcomingEventCount', `${list.length}件`);
    const fold = box.closest('details');
    if (fold) fold.hidden = list.length === 0;
    if (!list.length) { box.appendChild(emptyNode('近い日付の予定はありません。')); return; }
    const limit = 8;
    list.slice(0, limit).forEach(e => {
      const linked = !!workTaskForEvent(e);
      box.appendChild(itemNode(e, [fmtDate(e._ds || e.date), scheduleShiftLabel(e), eventTimeLabel(e), e.repeat&&e.repeat!=='none'?repeatLabel(e.repeat):'', repeatAdjustLabel(e), e.place, peopleLabel(e), caseName(e.caseId)], [{label:'編集', onClick:()=>openEventModal(DATA.events.find(x=>x.id===e.id)||e)}, {label:linked?'作業管理':'作業に追加', onClick:()=>linked?openWorkspace('continuum'):eventToWork(e), className:linked?'mini ok':'mini'}]));
    });
    if (list.length > limit) {
      const note = document.createElement('div');
      note.className = 'density-summary-note schedule-more-note';
      note.innerHTML = `<b>ほか${esc(list.length - limit)}件</b><span>月表示では近い予定だけ表示します。必要な時は一覧表示で日付ごとに確認します。</span>`;
      const btn = document.createElement('button');
      btn.type = 'button'; btn.className = 'mini ghost'; btn.textContent = '一覧表示';
      btn.addEventListener('click', () => { calendarMode = 'list'; switchView('schedule'); renderCalendar(); });
      note.appendChild(btn);
      box.appendChild(note);
    }
  }

  function repeatLabel(v) {
    return ({daily:'毎日',weekly:'毎週',monthly:'毎月',yearly:'毎年',none:''})[v] || '';
  }
  function scheduleListRow(x) {
    const isCalendarEvent = x._kind === '予定' || x._kind === '出来事';
    const linked = isCalendarEvent ? !!workTaskForEvent(x) : (x.collection !== 'work' && !!workTaskForSource(x.collection, x.id));
    const actions = isCalendarEvent
      ? [{label:'編集', onClick:()=>openEventModal(DATA.events.find(e=>e.id===x.id)||x)}, {label:linked?'作業管理':'作業に追加', onClick:()=>linked?openWorkspace('continuum'):eventToWork(x), className:linked?'mini ok':'mini'}]
      : (x.collection === 'work'
        ? [{label:'編集', onClick:()=>openTaskModal(x)}, {label:'作業管理', onClick:()=>openWorkspace('continuum')}]
        : [{label:'編集', onClick:()=>openDueModal(x.collection, x)}, {label:linked?'作業管理':'作業に追加', onClick:()=>linked?openWorkspace('continuum'):sendSpecToWork(x.collection, x), className:linked?'mini ok':'mini'}]);
    const meta = isCalendarEvent
      ? [x._kind, eventTimeLabel(x), repeatLabel(x.repeat), repeatAdjustLabel(x), scheduleShiftLabel(x), peopleLabel(x), caseName(x.caseId)]
      : [x._kind, x.due?dueLabel(x.due):'', peopleLabel(x), caseName(x.caseId)];
    return itemNode({id:x.id, title:itemTitle(x)}, meta, actions, calendarDayDiff(x.due)<0?'late':'');
  }

  function renderScheduleList(items) {
    const box = $('scheduleListView'); if (!box) return;
    box.innerHTML = '';
    const list = items.slice().sort((a,b)=>byDate(a._ds,b._ds)||((a._kind==='出来事'?1:0)-(b._kind==='出来事'?1:0))||String(a.time||'99:99').localeCompare(String(b.time||'99:99'))||itemTitle(a).localeCompare(itemTitle(b)));
    if (!list.length) { box.appendChild(emptyNode('この月の表示対象はありません。')); return; }
    const groups = new Map();
    list.forEach(x => { const key = x._ds || x.due || x.date || ''; if (!groups.has(key)) groups.set(key, []); groups.get(key).push(x); });
    const entries = Array.from(groups.entries());
    const perDayLimit = 8;
    const dayLimit = calendarListExpanded ? entries.length : 14;
    const shownEntries = entries.slice(0, dayLimit);
    const hiddenDayCount = Math.max(0, entries.length - shownEntries.length);
    const renderedItemCount = shownEntries.reduce((sum, [, rows]) => sum + Math.min(rows.length, perDayLimit), 0);
    const hiddenItemCount = Math.max(0, list.length - renderedItemCount);
    const hasCrowdedDay = entries.some(([, rows]) => rows.length > perDayLimit);
    const totals = list.reduce((m, x) => { m[x._kind] = (m[x._kind] || 0) + 1; return m; }, {});
    const summary = document.createElement('div');
    summary.className = 'density-summary-note schedule-list-summary';
    const totalText = ['予定','出来事','期限','事務','作業'].map(k => totals[k] ? `${k}${totals[k]}` : '').filter(Boolean).join(' / ') || '表示中の条件に合うもの';
    summary.innerHTML = `<b>${esc(list.length)}件 / ${esc(entries.length)}日</b><span>${esc(totalText)}。一覧も詰め込みすぎず、日付ごとに要点を表示します。</span>`;
    if (hiddenDayCount) {
      const btn = document.createElement('button');
      btn.type = 'button'; btn.className = 'mini ghost'; btn.textContent = '全日表示';
      btn.addEventListener('click', () => { calendarListExpanded = true; renderScheduleList(items); });
      summary.appendChild(btn);
    }
    box.appendChild(summary);

    shownEntries.forEach(([ds, rows]) => {
      const h = document.createElement('button');
      h.type = 'button';
      h.className = `schedule-list-date ${rows.length > perDayLimit ? 'crowded' : ''}`;
      h.innerHTML = `<span>${esc(fmtDate(ds))}</span><small>${esc(rows.length)}件</small>`;
      h.addEventListener('click', () => openDay(ds));
      box.appendChild(h);
      rows.slice(0, perDayLimit).forEach(x => box.appendChild(scheduleListRow(x)));
      if (rows.length > perDayLimit) {
        const note = document.createElement('button');
        note.type = 'button';
        note.className = 'density-summary-note day-more-note as-button';
        note.innerHTML = `<b>この日ほか${esc(rows.length - perDayLimit)}件</b><span>${esc(fmtDate(ds))} の詳細で、予定・期限・作業を分けて確認します。</span>`;
        note.addEventListener('click', () => openDay(ds));
        box.appendChild(note);
      }
    });
    if (hiddenDayCount) {
      const tail = document.createElement('button');
      tail.type = 'button';
      tail.className = 'density-summary-note schedule-more-button';
      tail.innerHTML = `<b>ほか${esc(hiddenDayCount)}日 / ${esc(hiddenItemCount)}件</b><span>月全体の一覧はここで止めています。必要なら全日表示、または検索で絞り込んでください。</span>`;
      tail.addEventListener('click', () => { calendarListExpanded = true; renderScheduleList(items); });
      box.appendChild(tail);
    } else if (hiddenItemCount || hasCrowdedDay) {
      const tail = document.createElement('div');
      tail.className = 'density-summary-note schedule-list-summary';
      tail.innerHTML = `<b>省略あり</b><span>1日あたりの表示を抑えています。日付見出しまたは「この日ほかN件」から詳細を開いてください。</span>`;
      box.appendChild(tail);
    }
  }

  function openDay(ds) {
    const evs = calendarEventItemsOn(ds).filter(matchingScheduleItem);
    const dues = (calendarItemMode === 'both' && calendarShowDue) ? calendarDueItems().filter(x => x.due === ds).filter(matchingScheduleItem) : [];
    const works = (calendarItemMode === 'both' && calendarShowWork) ? calendarWorkItems().filter(x => x.due === ds).filter(matchingScheduleItem) : [];
    const scheduleEvents = evs.filter(e => calendarKind(e) === 'schedule');
    const happeningEvents = evs.filter(e => calendarKind(e) === 'happening');
    const unlinkedDues = dues.filter(x => !workTaskForSource(x.collection, x.id) && !isDone(x));
    const riskDues = [...dues.filter(x => calendarDayDiff(x.due) < 0 && !isDone(x)), ...unlinkedDues.filter(x => calendarDayDiff(x.due) >= 0)];
    const riskDueKeys = new Set(riskDues.map(x => `${x.collection}:${x.id}`));
    const normalDues = dues.filter(x => !riskDueKeys.has(`${x.collection}:${x.id}`));
    const riskCount = dues.filter(x => calendarDayDiff(x.due) < 0 && !isDone(x)).length + works.filter(x => calendarDayDiff(x.due) < 0 && !isDone(x)).length;
    const daySummary = [
      ['予定', scheduleEvents.length],
      ['出来事', happeningEvents.length],
      ['期限・事務', dues.length],
      ['作業', works.length],
      ['未追加', unlinkedDues.length],
      ['要対応', riskCount]
    ].map(([k,n]) => `<div class="mini-metric ${n && (k === '要対応' || k === '未追加') ? 'warn' : ''}"><b>${esc(n)}</b><span>${esc(k)}</span></div>`).join('');
    const eventRow = e => {
      const linked = !!workTaskForEvent(e);
      const repeating = clean(e.repeat || 'none') !== 'none';
      const skipButton = repeating ? `<button type="button" class="mini" data-skip-event="${esc(e.id)}" data-occurrence-date="${esc(e._ds || ds)}" data-base-date="${esc(e._baseDate || e.date || ds)}">この回を除外</button>` : '';
      return `<div class="item event-${esc(calendarKindClass(e))}"><div><div class="item-title">${esc(e.title)}</div><div class="item-meta">${metaHtml([calendarKindLabel(e),eventTimeLabel(e),repeating?repeatLabel(e.repeat):'',repeatAdjustLabel(e),scheduleShiftLabel(e),e.place,peopleLabel(e),caseName(e.caseId),linked?'追加済み':'未追加'])}</div></div><div class="item-actions"><button type="button" class="mini" data-edit-event="${esc(e.id)}">${repeating?'全体を編集':'編集'}</button>${skipButton}<button type="button" class="mini ${linked?'ok':''}" data-work-event="${esc(e.id)}">${linked?'作業管理':'作業に追加'}</button></div></div>`;
    };
    const dueRow = x => {
      const linked = !!workTaskForSource(x.collection, x.id);
      const tone = calendarDayDiff(x.due) < 0 && !isDone(x) ? 'late' : (linked ? 'linked' : 'soon');
      return `<div class="item ${tone}"><div><div class="item-title">${esc(itemTitle(x))}</div><div class="item-meta">${metaHtml([x.label,dueLabel(x.due),priorityLabel(x.priority),peopleLabel(x),caseName(x.caseId),linked?'追加済み':'未追加'])}</div></div><div class="item-actions"><button type="button" class="mini" data-edit-due="${esc(x.collection)}:${esc(x.id)}">編集</button><button type="button" class="mini ${linked?'ok':''}" data-work-due="${esc(x.collection)}:${esc(x.id)}">${linked?'作業管理':'作業に追加'}</button></div></div>`;
    };
    const workRow = x => `<div class="item ${calendarDayDiff(x.due) < 0 && !isDone(x) ? 'late' : 'linked'}"><div><div class="item-title">${esc(itemTitle(x))}</div><div class="item-meta">${metaHtml(['作業',dueLabel(x.due),statusLabel(x.status),peopleLabel(x),caseName(x.caseId)])}</div></div><div class="item-actions"><button type="button" class="mini" data-edit-work="${esc(x.id)}">編集</button><button type="button" class="mini" data-open-work>作業管理</button></div></div>`;
    const section = (title, items, row, limit = 6) => {
      const list = arr(items);
      if (!list.length) return '';
      const shown = list.slice(0, limit);
      const body = shown.map(row).join('') + (list.length > shown.length ? `<div class="density-summary-note day-more-note"><b>ほか${esc(list.length - shown.length)}件</b><span>一覧表示または検索で絞り込んで確認してください。</span></div>` : '');
      return `<section class="day-detail-section ${list.length >= 8 ? 'is-crowded' : ''}"><h3>${esc(title)} <span>${esc(list.length)}</span></h3><div class="item-list">${body}</div></section>`;
    };
    const totalDayItems = evs.length + dues.length + works.length;
    const crowdedNote = totalDayItems >= 10 ? `<div class="density-summary-note day-density-note"><b>この日は${esc(totalDayItems)}件あります</b><span>予定、未追加の項目、追加済みの作業の順に確認してください。</span></div>` : '';
    const daySections = [
      section('その日の予定', scheduleEvents, eventRow),
      section('作業に追加するか判断する期限・事務', riskDues, dueRow),
      section('追加済みの作業', works, workRow),
      section('その日の出来事', happeningEvents, eventRow),
      section('その他の期限・事務', normalDues, dueRow)
    ].filter(Boolean).join('');
    const detail = daySections
      ? `<div class="day-detail-grid">${daySections}</div>`
      : `<div class="empty">この日の登録はありません。必要なら下のボタンから予定や出来事を追加できます。</div>`;
    const summaryBlock = totalDayItems ? `<div class="relation-summary day-summary">${daySummary}</div>` : '';
    const html = `<p class="modal-note">${esc(fmtDate(ds))} の内容です。予定と出来事を確認し、処理が必要な項目だけ「作業に追加」を選びます。</p>
      ${summaryBlock}${crowdedNote}
      ${detail}
      <div class="modal-actions"><div></div><div><button type="button" class="ghost" data-day-deadline>期限</button><button type="button" class="ghost" data-day-jimu>事務</button><button type="button" class="ghost" data-day-happening>出来事を追加</button><button type="button" class="primary" data-day-event>予定を追加</button></div></div>`;
    if (!openModal(`${fmtDate(ds)} の内容`, html, null, null, {noSubmit:true})) return;
    const form = $('modalForm');
    $$('[data-edit-event]', form).forEach(b => b.addEventListener('click', () => { const e = DATA.events.find(x => x.id === b.dataset.editEvent); closeModal(true); openEventModal(e); }));
    $$('[data-skip-event]', form).forEach(b => b.addEventListener('click', async () => {
      const event = DATA.events.find(item => item.id === b.dataset.skipEvent);
      if (!event) return;
      const occurrenceDate = clean(b.dataset.occurrenceDate || ds);
      const baseDate = clean(b.dataset.baseDate || event.date || occurrenceDate);
      const approved = await askConfirm('この回を除外しますか？', `${fmtDate(occurrenceDate)} の「${itemTitle(event)}」だけを除外します。繰り返し予定の全体と、ほかの日の回は残ります。`, 'この回を除外');
      if (!approved) return;
      const saved = await skipCalendarOccurrence(event.id, occurrenceDate, baseDate);
      if (saved) closeModal(true);
    }));
    $$('[data-work-event]', form).forEach(b => b.addEventListener('click', () => { const e = DATA.events.find(x => x.id === b.dataset.workEvent); if (e) { closeModal(true); if (workTaskForEvent(e)) openWorkspace('continuum'); else eventToWork(Object.assign({}, e, {_ds: ds})); } }));
    $$('[data-edit-due]', form).forEach(b => b.addEventListener('click', () => { const [col,id] = b.dataset.editDue.split(':'); const x = DATA[col].find(v => v.id === id); closeModal(true); openDueModal(col, x); }));
    $$('[data-work-due]', form).forEach(b => b.addEventListener('click', () => { const [col,id] = b.dataset.workDue.split(':'); const x = DATA[col].find(v => v.id === id); if (!x) return; closeModal(true); if (workTaskForSource(col, id)) openWorkspace('continuum'); else sendSpecToWork(col, x); }));
    $$('[data-edit-work]', form).forEach(b => b.addEventListener('click', () => { const x = WORK.tasks.find(v => v.id === b.dataset.editWork); closeModal(true); openTaskModal(x); }));
    $$('[data-open-work]', form).forEach(b => b.addEventListener('click', () => { closeModal(true); openWorkspace('continuum'); }));
    form.querySelector('[data-day-event]')?.addEventListener('click', () => { closeModal(true); openEventModal({date:ds, calendarKind:'schedule'}); });
    form.querySelector('[data-day-happening]')?.addEventListener('click', () => { closeModal(true); openEventModal({date:ds, calendarKind:'happening'}); });
    form.querySelector('[data-day-deadline]')?.addEventListener('click', () => { closeModal(true); openDueModal('deadlines', {due:ds}); });
    form.querySelector('[data-day-jimu]')?.addEventListener('click', () => { closeModal(true); openDueModal('jimu', {due:ds}); });
  }

  function renderLists() {
    const sorter = (a,b) => byDate(a.due,b.due) || String(itemTitle(a)).localeCompare(itemTitle(b));
    const q = clean($('dueSearch')?.value || '');
    const tokens = searchTokens(q);
    if (q !== dueRenderScopeKey) { dueRenderScopeKey = q; dueRenderLimits = {deadlines:DUE_RENDER_BATCH, jimu:DUE_RENDER_BATCH}; }
    const matches = (x, collection='') => matchesSearchTokens(tokens, [itemTitle(x), collection === 'deadlines' ? '期限 締切 期日' : collection === 'jimu' ? '事務' : '', x.label || x.collection, x.due, dueLabel(x.due), x.priority, peopleLabel(x), caseName(x.caseId), x.nextAction, x.note, isDone(x)?'完了':'未完了'].join(' '));
    const make = (collection) => {
      const all = DATA[collection].filter(x => matches(x, collection)).slice().sort(sorter);
      const shown = q ? all : all.slice(0, dueRenderLimits[collection]);
      const nodes = shown.map(x => {
      const diff = dayDiff(x.due);
      const calDiff = calendarDayDiff(x.due);
      const linked = !!workTaskForSource(collection, x.id);
      const status = linked ? 'linked' : (calDiff !== null && calDiff < 0 && !isDone(x) ? 'late' : (diff !== null && diff <= 7 && !isDone(x) ? 'soon' : ''));
      return itemNode(x, [fmtDate(x.due), dueLabel(x.due), priorityLabel(x.priority), peopleLabel(x), caseName(x.caseId), isDone(x)?'完了':'未完了', linked?'追加済み':''], [
        {label:isDone(x)?'未完了へ':'完了', onClick:()=>completeItem(collection, x.id, !isDone(x))},
        {label:linked?'作業管理':'作業に追加', onClick:()=>linked?openWorkspace('continuum'):sendSpecToWork(collection, x), className:linked?'mini ok':'mini', expose:true},
        {label:'編集', onClick:()=>openDueModal(collection, x), expose:true}
      ], status);
      });
      if (!q && shown.length < all.length) {
        const remaining = all.length - shown.length;
        const reveal = (showAll = false) => {
          const firstNewId = all[shown.length]?.id;
          dueRenderLimits[collection] = showAll ? all.length : dueRenderLimits[collection] + DUE_RENDER_BATCH;
          renderLists();
          setTimeout(() => {
            const host = $(collection === 'deadlines' ? 'deadlineList' : 'jimuList');
            const row = firstNewId ? host?.querySelector(`[data-record-id="${CSS.escape(firstNewId)}"]`) : null;
            (row?.querySelector('button') || row)?.focus?.({preventScroll:true}); row?.scrollIntoView({block:'nearest'});
          }, 0);
        };
        nodes.push(actionNoteNode(`${all.length}件中${shown.length}件を表示しています。初期表示を絞って台帳をすばやく開いています。`, [
          {label:`さらに${Math.min(DUE_RENDER_BATCH, remaining)}件`, className:'mini primary-inline', onClick:()=>reveal(false)},
          {label:'全件表示', className:'mini', onClick:()=>reveal(true)}
        ]));
      }
      return nodes;
    };
    setList('deadlineList', make('deadlines'), q ? '検索に合う期限はありません。' : '期限はまだありません。');
    setList('jimuList', make('jimu'), q ? '検索に合う事務はありません。' : '事務はまだありません。');
  }
  function renderWorkLinked() {
    const linked = WORK.tasks.filter(t => clean(t.source).startsWith('speculum:')).slice().sort((a,b)=>byDate(a.due,b.due));
    setList('workLinkedList', linked.slice(0,10).map(t => itemNode(t, [fmtDate(t.due), dueLabel(t.due), statusLabel(t.status), caseName(t.caseId), peopleLabel(t)], [{label:'作業管理', onClick:()=>openWorkspace('continuum')}], isDone(t)?'linked':(calendarDayDiff(t.due)<0?'late':'linked'))), 'まだ台帳から作業に追加した項目はありません。');
  }

  function caseFocusRank(card) {
    const alert = caseAlertInfo(card);
    const diff = card.nextDate ? dayDiff(card.nextDate) : null;
    if (alert && alert.diff < 0) return 0;
    if (alert) return 1;
    if (diff !== null && diff < 0) return 2;
    if (diff !== null && diff <= 7) return 3;
    if (clean(card.priority) === 'high') return 4;
    if (!['完了'].includes(normalizeCaseStatus(card.status))) return 5;
    return 9;
  }
  function renderCaseFocusCards(cards) {
    return cards
      .filter(c => caseFocusRank(c) < 6)
      .sort((a,b) => caseFocusRank(a) - caseFocusRank(b) || byDate(a.nextDate || a.startedAt, b.nextDate || b.startedAt) || a.title.localeCompare(b.title) || a.targetName.localeCompare(b.targetName))
      .slice(0, 12);
  }
  function caseRenderSignature(q = '') {
    return `${CASE_RENDER_GENERATION}\n${today()}\n${dueDayCountMode}\n${clean(q)}\n${caseFocusScope}\n${caseBoardOpen ? 'open' : 'closed'}`;
  }
  function renderCards() {
    const box = $('caseList'); if (!box) return;
    const q = clean($('caseSearch')?.value || '');
    const signature = caseRenderSignature(q);
    if (CASE_RENDER_SIGNATURE === signature && box.firstElementChild) return;
    box.replaceChildren(); box.className = 'case-layout';
    const allCards = caseTargetCards().filter(card => matchesWords(q, [card.title, card.targetName, card.targetRole, card.owner, card.nextAction, card.note, card.case?.note, card.status, card.priority].join(' ')));
    let relationCounts = null;
    const getRelationCounts = () => relationCounts || (relationCounts = caseRelationCountIndex());
    const counts = new Map(CASE_STATUSES.map(s => [s, 0]));
    allCards.forEach(card => counts.set(normalizeCaseStatus(card.status), (counts.get(normalizeCaseStatus(card.status)) || 0) + 1));

    const shell = document.createElement('div'); shell.className = 'case-command-layout';
    const focusCards = renderCaseFocusCards(allCards);
    const activeCards = allCards.filter(card => normalizeCaseStatus(card.status) !== '完了');
    const overdueCards = activeCards.filter(card => { const d = calendarDayDiff(card.nextDate); return d !== null && d < 0; });
    const soonCards = activeCards.filter(card => { const d = dayDiff(card.nextDate); return d !== null && d >= 0 && d <= 7; });
    const oldCards = activeCards.filter(card => { const age = card.startedAt ? -Number(calendarDayDiff(card.startedAt)) : 0; return age >= 90; });
    const noNextCards = activeCards.filter(card => !clean(card.nextDate));
    const scopeDefs = [
      ['focus', '要対応', focusCards, '期限・アラート・高優先'],
      ['overdue', '期限超過', overdueCards, '次回日が過ぎています'],
      ['soon', '7営業日内', soonCards, '近い確認日があります'],
      ['old', '長期化', oldCards, '着手から3か月以上'],
      ['noNext', '次回予定なし', noNextCards, '次の予定を決める候補']
    ];
    if (!scopeDefs.some(([key]) => key === caseFocusScope)) caseFocusScope = 'focus';
    const selectedScope = scopeDefs.find(([key]) => key === caseFocusScope) || scopeDefs[0];
    const selectedCards = selectedScope[2].slice().sort((a,b) => caseFocusRank(a) - caseFocusRank(b) || byDate(a.nextDate || a.startedAt, b.nextDate || b.startedAt) || a.title.localeCompare(b.title) || a.targetName.localeCompare(b.targetName)).slice(0, 12);
    const overview = document.createElement('section');
    overview.className = 'case-overview';
    overview.innerHTML = scopeDefs.map(([key,label,cards,hint]) => `<button type="button" class="case-overview-chip ${key === caseFocusScope ? 'active' : ''}" data-case-focus-scope="${esc(key)}"><b>${esc(cards.length)}</b><span>${esc(label)}</span><em>${esc(hint)}</em></button>`).join('');
    overview.querySelectorAll('[data-case-focus-scope]').forEach(btn => btn.addEventListener('click', () => { caseFocusScope = btn.dataset.caseFocusScope || 'focus'; renderCards(); }));
    shell.appendChild(overview);

    const statusBar = document.createElement('div'); statusBar.className = 'case-status-strip';
    CASE_STATUSES.forEach(status => {
      const b = document.createElement('button');
      b.type = 'button';
      b.className = 'case-status-chip';
      b.innerHTML = `<span>${esc(status)}</span><b>${esc(counts.get(status) || 0)}</b>`;
      b.addEventListener('click', () => { caseBoardOpen = true; renderCards(); setTimeout(() => $$('.case-column-body').find(el => el.dataset.caseStatus === status)?.scrollIntoView({block:'nearest', inline:'center'}), 40); });
      statusBar.appendChild(b);
    });
    // 事案がまだ無い状態では、空の状態チップ列を出さず追加導線だけを残す。
    if (allCards.length) shell.appendChild(statusBar);

    const focus = document.createElement('section'); focus.className = 'case-focus-panel';
    focus.innerHTML = `<div class="case-focus-head"><div><b>${esc(selectedScope[1])}</b><span>${esc(selectedScope[3])}</span></div><span class="work-count">${esc(selectedScope[2].length)}</span></div>`;
    const focusList = document.createElement('div'); focusList.className = 'case-focus-list';
    if (!selectedCards.length) {
      const e = document.createElement('div'); e.className = 'empty'; e.textContent = q ? '検索条件に合う事案はありません。「全件を進行状態別に表示」で全件を確認できます。' : `${selectedScope[1]}の事案はありません。必要なときは、全件を進行状態別に確認できます。`; focusList.appendChild(e);
    } else {
      selectedCards.forEach(card => focusList.appendChild(caseCard(card, {compact:true})));
    }
    focus.appendChild(focusList);
    shell.appendChild(focus);

    const details = document.createElement('details'); details.className = 'fold-section case-board-fold'; details.open = caseBoardOpen;
    details.innerHTML = `<summary><span>全件を進行状態別に表示</span><span class="fold-count">${esc(allCards.length)}件</span></summary>`;
    const ensureCaseBoard = () => {
      if (details.querySelector(':scope > .case-board')) return;
      const board = document.createElement('div'); board.className = 'case-board';
      const cardsByStatus = new Map(CASE_STATUSES.map(status => [status, []]));
      allCards.forEach(card => cardsByStatus.get(normalizeCaseStatus(card.status))?.push(card));
      CASE_STATUSES.forEach(status => {
        const col = document.createElement('article'); col.className = 'case-column';
        const cards = cardsByStatus.get(status) || [];
        col.innerHTML = `<h3>${esc(status)}<span class="work-count">${cards.length}</span></h3><div class="case-column-body" data-case-status="${esc(status)}"></div>`;
        const body = col.querySelector('.case-column-body');
        bindCaseDrop(body, async raw => moveCaseStatus(raw, status));
        if (!cards.length) { const e=document.createElement('div'); e.className='empty'; e.textContent='ここにはまだありません。'; body.appendChild(e); }
        cards.sort((a,b)=>byDate(a.startedAt||a.nextDate,b.startedAt||b.nextDate)||a.title.localeCompare(b.title)||a.targetName.localeCompare(b.targetName)).forEach(card => body.appendChild(caseCard(card, {relationCounts:getRelationCounts()})));
        board.appendChild(col);
      });
      details.appendChild(board);
    };
    details.addEventListener('toggle', () => {
      caseBoardOpen = details.open;
      if (details.open) ensureCaseBoard();
      CASE_RENDER_SIGNATURE = caseRenderSignature(q);
    });
    if (caseBoardOpen) ensureCaseBoard();
    shell.appendChild(details);
    box.appendChild(shell);
    CASE_RENDER_SIGNATURE = caseRenderSignature(q);
  }
  function scheduleCaseViewPreload() {
    if (CASE_PRELOAD_TASK || !DATA || !WORK || currentView === 'cases') return;
    const run = () => {
      CASE_PRELOAD_TASK = 0;
      if (!DATA || !WORK || currentView === 'cases' || externalSyncBlocked()) return;
      renderCards();
    };
    if ('requestIdleCallback' in window) CASE_PRELOAD_TASK = window.requestIdleCallback(run, {timeout:900});
    else CASE_PRELOAD_TASK = window.setTimeout(run, 180);
  }
  function caseCard(card, opts = {}) {
    const compact = !!opts.compact;
    let relationCounts = null;
    if (!compact) {
      const indexed = opts.relationCounts?.get(card.caseId);
      relationCounts = indexed || (() => {
        const rel = caseRelations(card.caseId);
        return {events:rel.events.length, deadlines:rel.deadlines.length, jimu:rel.jimu.length, tasks:rel.tasks.length};
      })();
    }
    const alert = caseAlertInfo(card);
    const node = document.createElement('article'); node.className = `card case-card target-case-card ${alert?'late':''}`.trim(); node.draggable = true;
    node.dataset.recordId = clean(card.caseId || card.targetId || '');
    node.dataset.caseId = clean(card.caseId || '');
    node.dataset.targetId = clean(card.targetId || '');
    let caseDragBlocked = false;
    node.addEventListener('pointerdown', e => { caseDragBlocked = interactiveCardTarget(e.target); }, true);
    node.addEventListener('dragstart', e => {
      if (caseDragBlocked || interactiveCardTarget(e.target)) { caseDragBlocked = false; e.preventDefault(); return; }
      e.dataTransfer.setData('text/plain', `caseTarget:${card.caseId}:${card.targetId || ''}`); e.dataTransfer.effectAllowed='move'; node.classList.add('dragging');
    });
    node.addEventListener('dragend', () => { caseDragBlocked = false; node.classList.remove('dragging'); });
    node.addEventListener('click', e => { if (e.target.closest('button, summary, details, .card-more, .action-menu')) return; openCaseTargetModal(card); });
    const noteHtml = !compact && card.note ? `<p>${esc(card.note)}</p>` : '';
    const metricsHtml = compact ? '' : `<div class="mini-metrics">${[['予定',relationCounts.events],['期限',relationCounts.deadlines+relationCounts.jimu],['作業',relationCounts.tasks],['同事案',caseTargets(card.case).length]].map(([k,n])=>`<div class="mini-metric"><b>${n}</b><span>${k}</span></div>`).join('')}</div>`;
    node.innerHTML = `<div class="case-name-pill">${esc(card.title)}</div><h3>${esc(card.targetName)}</h3><div class="item-meta">${metaHtml([card.status, priorityLabel(card.priority), card.targetRole?`役割 ${card.targetRole}`:'', card.startedAt?`着手 ${fmtDate(card.startedAt)}`:'', card.nextDate?`次回 ${fmtDate(card.nextDate)}`:'', card.owner?`担当 ${card.owner}`:'', alert?`${alert.label} ${fmtDate(alert.date)}`:'', card.nextAction?`次: ${card.nextAction}`:''])}</div>${noteHtml}${metricsHtml}<div class="card-actions"></div>`;
    const a = node.querySelector('.card-actions');
    const idx = CASE_STATUSES.indexOf(normalizeCaseStatus(card.status));
    const primaryActions = [];
    if (idx >= 0 && idx < CASE_STATUSES.length - 1) primaryActions.push([`${CASE_STATUSES[idx+1]}へ`,()=>moveCaseStatus(`caseTarget:${card.caseId}:${card.targetId || ''}`, CASE_STATUSES[idx+1]), 'primary-inline']);
    const linked = !!workTaskForCaseTarget(card);
    primaryActions.push([linked?'作業管理':'作業に追加',()=>linked?openWorkspace('continuum'):caseToWork(card), linked?'ok':'']);
    primaryActions.forEach(([lb,fn,cls])=>{const b=document.createElement('button');b.className='mini ' + (cls || '');b.textContent=lb;b.addEventListener('click',fn);a.appendChild(b);});
    const editButton = document.createElement('button'); editButton.type='button'; editButton.className='mini'; editButton.textContent='編集'; editButton.addEventListener('click',()=>openCaseTargetModal(card)); a.appendChild(editButton);
    const more = document.createElement('details'); more.className = 'card-more case-more';
    more.innerHTML = '<summary>⋯</summary><div class="more-menu"></div>';
    const menu = more.querySelector('.more-menu');
    const moreActions = [];
    if (idx > 0) moreActions.push([`${CASE_STATUSES[idx-1]}へ戻す`,()=>moveCaseStatus(`caseTarget:${card.caseId}:${card.targetId || ''}`, CASE_STATUSES[idx-1])]);
    moreActions.push(['関連情報を見る',()=>openCaseRelation(card)],['予定を作る',()=>openEventModal({date:card.nextDate || today(), caseId:card.caseId})],['期限を作る',()=>openDueModal('deadlines',{due:card.nextDate || today(), caseId:card.caseId})]);
    const ensureMoreActions = () => {
      if (menu.dataset.ready === '1') return;
      menu.dataset.ready = '1';
      moreActions.forEach(([lb,fn])=>{const b=document.createElement('button');b.className='mini';b.textContent=lb;b.addEventListener('click',e=>{e.stopPropagation();more.open=false;fn();});menu.appendChild(b);});
    };
    more.addEventListener('toggle', () => { if (more.open) ensureMoreActions(); });
    a.appendChild(wireActionMenu(more));
    if (compact) node.classList.add('compact-case-card');
    return node;
  }
  function bindCaseDrop(el, handler) {
    if (!el) return;
    el.addEventListener('dragover', e => { e.preventDefault(); e.dataTransfer.dropEffect='move'; el.closest('.case-column')?.classList.add('drop-target'); });
    el.addEventListener('dragleave', () => el.closest('.case-column')?.classList.remove('drop-target'));
    el.addEventListener('drop', async e => { e.preventDefault(); el.closest('.case-column')?.classList.remove('drop-target'); const raw=e.dataTransfer.getData('text/plain')||''; if(raw.startsWith('caseTarget:') || raw.startsWith('case:')) await handler(raw); });
  }
  async function moveCaseStatus(raw, status) {
    const parts = String(raw || '').split(':');
    const caseId = parts[0] === 'caseTarget' ? parts[1] : (parts[0] === 'case' ? parts[1] : raw);
    const targetId = parts[0] === 'caseTarget' ? (parts[2] || '') : '';
    return runUiAction(`case-status:${caseId}:${targetId || 'case'}`, async () => {
      const current = DATA.cases.find(x => x.id === caseId); if (!current) return;
      const snapshot = cloneRecord(current);
      const next = cloneRecord(current);
      const nextStatus = normalizeCaseStatus(status);
      if (targetId) {
        next.targetPersons = caseTargets(next);
        const target = next.targetPersons.find(x => x.id === targetId); if (!target) return;
        target.status = nextStatus;
        if (CASE_STARTED.has(nextStatus) && !target.startedAt) target.startedAt = today();
        const active = next.targetPersons.find(x => normalizeCaseStatus(x.status) !== '完了') || next.targetPersons[0] || target;
        next.status = normalizeCaseStatus(active.status);
        next.startedAt = active.startedAt || '';
        next.nextDate = active.nextDate || '';
        next.owner = active.owner || '';
        next.priority = active.priority || 'normal';
        next.nextAction = active.nextAction || '';
      } else {
        next.status = nextStatus;
        if (CASE_STARTED.has(nextStatus) && !next.startedAt) next.startedAt = today();
      }
      next.updatedAt = new Date().toISOString();
      await saveSpeculumItem('cases', next, snapshot.updatedAt || ''); renderAll();
      toast('対象者カードの状態を移動しました', {actionLabel:'元に戻す', ms:7000, onAction:()=>restoreDataItemSnapshot('cases', snapshot, '対象者カードの状態を元に戻しました')});
    }, '対象者カードの状態を更新できませんでした');
  }
  function renderPeople() {
    const box = $('peopleList'); if (!box) return;
    const q = clean($('peopleSearch')?.value || '');
    const tokens = searchTokens(q);
    const scopeKey = `${q}\n${showRetiredPeople ? 'retired' : 'active'}`;
    if (scopeKey !== peopleRenderScopeKey) { peopleRenderScopeKey = scopeKey; peopleRenderLimit = PEOPLE_RENDER_BATCH; }
    const list = peopleSorted(DATA.people).filter(p => (showRetiredPeople || !p.retired) && matchesSearchTokens(tokens, [p.name,p.kana,p.kind,p.term,p.org,p.role,p.tags,p.note,p.retiredAt,p.retired?'退職 退職者':'',personSortMeta(p)].join(' ')));
    if (!list.length) { box.replaceChildren(emptyNode(q ? '検索に合う人物はいません。' : '人物管理の登録はまだありません。')); return; }
    const visible = q ? list : list.slice(0, peopleRenderLimit);
    const relationCounts = personRelationCountIndex();
    const fragment = document.createDocumentFragment();
    visible.forEach(p => {
      const rel = relationCounts.get(p.id) || {events:0, deadlines:0, jimu:0, career:0, tasks:0};
      const node=document.createElement('article'); node.className='card person-card'; node.draggable=true;
      node.dataset.recordId = clean(p.id);
      node.dataset.personId = clean(p.id);
      node.innerHTML = `<div class="person-card-head"><span class="person-drag-handle" title="ドラッグして表示順を変更">⠿</span><h3>${esc(p.name)}</h3></div><div class="item-meta">${[personRetirementLabel(p),p.kind,p.term,personSortMeta(p),p.org,p.role,p.tel,p.email,p.tags].filter(Boolean).map(x=>`<span>${esc(x)}</span>`).join('')}</div>${p.note?`<p>${esc(p.note)}</p>`:''}<div class="mini-metrics">${[['予定',rel.events],['作業',rel.tasks],['経歴',rel.career],['メモ',p.note?1:0]].map(([k,n])=>`<div class="mini-metric"><b>${n}</b><span>${k}</span></div>`).join('')}</div><div class="card-actions"></div>`;
      node.addEventListener('dragstart', e => { if (interactiveCardTarget(e.target)) { e.preventDefault(); return; } e.dataTransfer.setData('text/plain', `person:${p.id}`); e.dataTransfer.effectAllowed='move'; node.classList.add('dragging'); });
      node.addEventListener('dragend', () => { node.classList.remove('dragging'); $$('.person-card.drop-before,.person-card.drop-after').forEach(card => card.classList.remove('drop-before','drop-after')); });
      node.addEventListener('dragover', e => { const raw=[...e.dataTransfer.types].includes('text/plain'); if(!raw)return; e.preventDefault(); const after=e.clientY > node.getBoundingClientRect().top + node.offsetHeight/2; node.classList.toggle('drop-before',!after); node.classList.toggle('drop-after',after); });
      node.addEventListener('dragleave', () => node.classList.remove('drop-before','drop-after'));
      node.addEventListener('drop', async e => { e.preventDefault(); const raw=e.dataTransfer.getData('text/plain'); node.classList.remove('drop-before','drop-after'); if(!raw.startsWith('person:'))return; const id=raw.slice(7); if(id===p.id)return; const after=e.clientY > node.getBoundingClientRect().top + node.offsetHeight/2; await movePersonTo(id,p.id,after); });
      const a=node.querySelector('.card-actions');
      const relBtn=document.createElement('button'); relBtn.className='mini primary-inline'; relBtn.textContent='関連情報を見る'; relBtn.addEventListener('click',()=>openPersonDetail(p)); a.appendChild(relBtn);
      const taskBtn=document.createElement('button'); taskBtn.className='mini'; taskBtn.textContent='作業を追加'; taskBtn.addEventListener('click',()=>openTaskModal({personIds:[p.id], title:`${p.name} に関する作業`})); a.appendChild(taskBtn);
      const editBtn=document.createElement('button'); editBtn.className='mini'; editBtn.textContent='編集'; editBtn.addEventListener('click',()=>openPersonModal(p)); a.appendChild(editBtn);
      a.appendChild(compactActionMenu([
        {label:'予定を追加', onClick:()=>openEventModal({date:today(), personIds:[p.id]})},
        {label:'上へ', onClick:()=>movePersonOrder(p.id,-1)},
        {label:'下へ', onClick:()=>movePersonOrder(p.id,1)},
        {label:'自動順', onClick:()=>resetPersonOrder(p.id)}
      ]));
      fragment.appendChild(node);
    });
    if (!q && visible.length < list.length) {
      const more = document.createElement('div');
      more.className = 'people-list-more';
      const remaining = list.length - visible.length;
      more.innerHTML = `<div><b>${esc(list.length)}人中 ${esc(visible.length)}人を表示</b><span>初期表示を絞って、人物管理をすばやく開いています。</span></div>`;
      const button = document.createElement('button');
      button.type = 'button'; button.className = 'mini primary-inline'; button.textContent = `さらに${Math.min(PEOPLE_RENDER_BATCH, remaining)}人を表示`;
      button.addEventListener('click', () => {
        const firstNewId = list[visible.length]?.id;
        peopleRenderLimit += PEOPLE_RENDER_BATCH; renderPeople();
        setTimeout(() => { const card = firstNewId ? $(`peopleList`)?.querySelector(`[data-person-id="${CSS.escape(firstNewId)}"]`) : null; (card?.querySelector('button') || card)?.focus?.({preventScroll:true}); card?.scrollIntoView({block:'nearest'}); }, 0);
      });
      const allButton = document.createElement('button');
      allButton.type = 'button'; allButton.className = 'mini'; allButton.textContent = '全員表示';
      allButton.addEventListener('click', () => {
        const firstNewId = list[visible.length]?.id;
        peopleRenderLimit = list.length; renderPeople();
        setTimeout(() => { const card = firstNewId ? $(`peopleList`)?.querySelector(`[data-person-id="${CSS.escape(firstNewId)}"]`) : null; (card?.querySelector('button') || card)?.focus?.({preventScroll:true}); card?.scrollIntoView({block:'nearest'}); }, 0);
      });
      const actions = document.createElement('span'); actions.className = 'people-list-more-actions'; actions.append(button, allButton);
      more.appendChild(actions);
      fragment.appendChild(more);
    }
    box.replaceChildren(fragment);
  }
  async function movePersonOrder(id, dir) {
    const sorted = peopleSorted(DATA.people);
    const idx = sorted.findIndex(p => p.id === id);
    const to = idx + dir;
    if (idx < 0 || to < 0 || to >= sorted.length) return;
    await movePersonTo(id, sorted[to].id, dir > 0);
  }
  async function movePersonTo(id, targetId, after = false) {
    return runUiAction('person-order', async () => {
      const sorted = peopleSorted(DATA.people);
      const from = sorted.findIndex(p => p.id === id); if (from < 0) return;
      const snapshots = new Map(sorted.map(person => [person.id, cloneRecord(person)]));
      const moved = sorted.map(cloneRecord); const [person] = moved.splice(from, 1);
      let target = moved.findIndex(p => p.id === targetId); if (target < 0) return;
      if (after) target += 1;
      moved.splice(target, 0, person);
      const position = moved.findIndex(p => p.id === id);
      const othersAreManual = moved.every(p => p.id === id || personManualOrder(p) !== null);
      let changed;
      if (othersAreManual) {
        const previous = position > 0 ? personManualOrder(moved[position - 1]) : null;
        const next = position < moved.length - 1 ? personManualOrder(moved[position + 1]) : null;
        const order = previous === null ? Number(next) - 10 : next === null ? Number(previous) + 10 : (Number(previous) + Number(next)) / 2;
        person.displayOrder = String(order); person.updatedAt = new Date().toISOString(); changed = [person];
      } else {
        changed = [];
        moved.forEach((p, i) => { const order=String((i + 1) * 10); if(clean(p.displayOrder)===order)return; p.displayOrder=order; p.updatedAt=new Date().toISOString(); changed.push(p); });
      }
      if (!changed.length) return;
      await saveSpeculumItems('people', changed, changed.map(p => ({id:p.id, updatedAt:snapshots.get(p.id)?.updatedAt || ''})));
      renderPeople(); renderTimeline(); toast('人物の表示順を変更しました');
    }, '人物の表示順を変更できませんでした');
  }
  async function resetPersonOrder(id) {
    return runUiAction('person-order', async () => {
      const current = DATA.people.find(x => x.id === id); if (!current) return;
      const snapshot = cloneRecord(current);
      const next = cloneRecord(current);
      next.displayOrder = ''; next.updatedAt = new Date().toISOString();
      await saveSpeculumItem('people', next, snapshot.updatedAt || ''); renderPeople(); renderTimeline();
      toast('自動順に戻しました');
    }, '人物の表示順を自動順へ戻せませんでした');
  }

  const CAREER_ROWS = [
    ['fiscalYear','事務年度'],
    ['experienceYears','経験年数'],
    ['office','所属署'],
    ['departments','部門'],
    ['departmentManagers','各部門の責任者'],
    ['departmentStaffs','各部門の所属職員'],
    ['section','係（担当）'],
    ['position','職名又は職務内容'],
    ['reviewOfficer','審理専門官'],
    ['myEvents','自分の出来事'],
    ['othersEvents','他者の出来事'],
    ['abilityEval','能力評価（10月〜9月）'],
    ['performanceEvalAprSep','業績評価（4月〜9月）'],
    ['performanceEvalOctMar','業績評価（10月〜3月）'],
    ['bonusUpper','勤勉手当（上期）'],
    ['raiseCategory','昇給区分'],
    ['bonusLower','勤勉手当（下期）'],
    ['annualIncome','収入'],
    ['income','所得'],
    ['withholdingIncomeTax','源泉所得税額'],
    ['hrGoal1','人事目標1'],
    ['hrGoal2','人事目標2'],
    ['hrGoal3','人事目標3'],
    ['selfEval1','自己評価1'],
    ['selfEval2','自己評価2'],
    ['selfEval3','自己評価3']
  ];
  function careerFiscalParts(label) {
    const s = clean(label);
    const m = s.match(/^([A-Za-zＡ-Ｚａ-ｚ一-龥]+)\s*(\d+)$/);
    if (!m) return null;
    return {era:m[1], num:Number(m[2])};
  }
  function careerEraRank(era) {
    const e = clean(era).toUpperCase();
    if (['S','昭和'].includes(e)) return 1;
    if (['H','平成'].includes(e)) return 2;
    if (['R','令和'].includes(e)) return 3;
    return 20;
  }
  function careerOrderValue(c, fallbackIndex = 0) {
    const ord = Number(c.order);
    if (Number.isFinite(ord) && ord > 0) return ord;
    const parts = careerFiscalParts(c.fiscalYear);
    if (parts) return careerEraRank(parts.era) * 10000 + parts.num;
    const created = Date.parse(c.createdAt || c.updatedAt || c.date || '');
    if (Number.isFinite(created)) return 900000 + Math.floor(created / 100000000);
    return 800000 + fallbackIndex;
  }
  function careerSorted(direction = 'desc') {
    return DATA.career.map((career,index) => ({career, order:careerOrderValue(career,index)}))
      .sort((a,b) => direction === 'asc' ? (a.order - b.order) : (b.order - a.order))
      .map(row => row.career);
  }
  function careerExperienceMap(itemsAsc = null) {
    const asc = itemsAsc || careerSorted('asc');
    const map = new Map();
    asc.forEach((c, i) => map.set(c.id, i));
    return map;
  }
  function suggestNextFiscalYear() {
    const latest = careerSorted('desc')[0];
    if (!latest) return 'R1';
    const p = careerFiscalParts(latest.fiscalYear);
    if (p) return `${p.era}${p.num + 1}`;
    return clean(latest.fiscalYear) || 'R1';
  }
  function nextCareerOrder() {
    const vals = DATA.career.map((c,i)=>careerOrderValue(c,i)).filter(Number.isFinite);
    return vals.length ? Math.max(...vals) + 1 : 1;
  }
  function careerCellValue(c, key, expMap) {
    if (key === 'experienceYears') return String(expMap.get(c.id) ?? 0);
    if (key === 'departments') return careerDepartmentNamesDisplay(c);
    if (key === 'departmentManagers') return careerDepartmentManagersDisplay(c);
    if (key === 'departmentStaffs') return careerDepartmentStaffsDisplay(c);
    if (key === 'reviewOfficer') return singleCareerStaffDisplay(c, 'reviewOfficer', 'reviewOfficerPersonId');
    const v = c[key];
    if (CAREER_MONEY_KEYS.has(key)) return formatMoneyText(v);
    if (Array.isArray(v)) return v.join('\n');
    return String(v ?? '');
  }
  function careerSearchText(c) {
    if (c && typeof c === 'object' && CAREER_SEARCH_TEXT_CACHE.has(c)) return CAREER_SEARCH_TEXT_CACHE.get(c);
    const text = CAREER_ROWS.map(([key]) => careerCellValue(c, key, new Map())).join(' ') + ' ' + stableCareerText(c);
    if (c && typeof c === 'object') CAREER_SEARCH_TEXT_CACHE.set(c, text);
    return text;
  }
  function careerMatches(c, tokens) {
    return !tokens.length || matchesSearchTokens(tokens, careerSearchText(c));
  }
  function stableCareerText(c) {
    try { return JSON.stringify(c); } catch (_) { return ''; }
  }
  function renderTimeline() {
    const box = $('careerList'); if (!box) return; box.innerHTML = '';
    const q = clean($('careerSearch')?.value || '');
    const tokens = searchTokens(q);
    if (q !== careerRenderScopeKey) { careerRenderScopeKey = q; careerRenderLimit = CAREER_RENDER_BATCH; }
    const ascAll = careerSorted('asc');
    const descAll = ascAll.slice().reverse();
    const expMap = careerExperienceMap(ascAll);
    const matchingCols = descAll.filter(c => careerMatches(c, tokens));
    const cols = q ? matchingCols : matchingCols.slice(0, careerRenderLimit);
    if ($('careerSummary')) {
      const latest = descAll[0];
      const old = ascAll[0];
      $('careerSummary').innerHTML = [
        ['登録年度', DATA.career.length],
        ['最新年度', latest ? clean(latest.fiscalYear) : '-'],
        ['経験年数', latest ? `${expMap.get(latest.id) ?? 0}` : '-'],
        ['最初の年度', old ? clean(old.fiscalYear) : '-']
      ].map(([k,n])=>`<div class="metric"><div class="n career-summary-text">${esc(n)}</div><div class="k">${esc(k)}</div></div>`).join('');
    }
    if (!cols.length) { box.onclick = null; box.appendChild(emptyNode(q ? '検索に合う経歴はありません。' : '事務年度の経歴はまだ登録されていません。')); return; }
    const wrap = document.createElement('div');
    wrap.className = 'career-board-scroll';
    const grid = document.createElement('div');
    grid.className = 'career-board';
    grid.style.setProperty('--career-cols', String(cols.length));
    grid.innerHTML = `<div class="career-corner">項目</div>` + cols.map(c => `<button type="button" class="career-year-head" data-career-id="${esc(c.id)}"><b>${esc(c.fiscalYear || '年度未入力')}</b><span>年度を選んで編集</span></button>`).join('');
    CAREER_ROWS.forEach(([key, label]) => {
      const labelNode = document.createElement('div');
      labelNode.className = 'career-row-label';
      labelNode.textContent = label;
      grid.appendChild(labelNode);
      cols.forEach(c => {
        const cell = document.createElement('button');
        cell.type = 'button';
        cell.className = 'career-cell';
        cell.dataset.careerId = c.id;
        cell.dataset.careerKey = key;
        const value = careerCellValue(c, key, expMap);
        if (!clean(value)) cell.classList.add('empty-cell');
        cell.innerHTML = value ? esc(value).replace(/\n/g, '<br>') : '<span>未入力</span>';
        grid.appendChild(cell);
      });
    });
    wrap.appendChild(grid);
    box.appendChild(wrap);
    if (!q && cols.length < matchingCols.length) {
      const more = document.createElement('div');
      more.className = 'career-list-more';
      const remaining = matchingCols.length - cols.length;
      more.innerHTML = `<div><b>${esc(matchingCols.length)}年度中 ${esc(cols.length)}年度を表示</b><span>最新年度から表示し、古い年度は必要なときだけ追加します。</span></div>`;
      const actions = document.createElement('span'); actions.className = 'career-list-more-actions';
      const next = document.createElement('button'); next.type = 'button'; next.className = 'mini primary-inline'; next.textContent = `さらに${Math.min(CAREER_RENDER_BATCH, remaining)}年度`;
      next.addEventListener('click', () => {
        const firstNewId = matchingCols[cols.length]?.id;
        careerRenderLimit += CAREER_RENDER_BATCH; renderTimeline();
        setTimeout(() => $('careerList')?.querySelector(`[data-career-id="${CSS.escape(firstNewId || '')}"]`)?.focus({preventScroll:false}), 0);
      });
      const all = document.createElement('button'); all.type = 'button'; all.className = 'mini'; all.textContent = '全年度表示';
      all.addEventListener('click', () => {
        const firstNewId = matchingCols[cols.length]?.id;
        careerRenderLimit = matchingCols.length; renderTimeline();
        setTimeout(() => $('careerList')?.querySelector(`[data-career-id="${CSS.escape(firstNewId || '')}"]`)?.focus({preventScroll:false}), 0);
      });
      actions.append(next, all); more.appendChild(actions); box.appendChild(more);
    }
    box.onclick = event => {
      const el = event.target.closest?.('[data-career-id]');
      if (!el || !box.contains(el)) return;
      const c = DATA.career.find(x => x.id === el.dataset.careerId);
      if (c) openCareerModal(c, el.dataset.careerKey || '');
    };
  }
  function relationList(items, formatter, empty, limit = 6) {
    const list = arr(items);
    if (!list.length) return `<div class="empty">${esc(empty)}</div>`;
    const row = x => `<div class="item"><div><div class="item-title">${esc(itemTitle(x))}</div><div class="item-meta">${formatter(x).filter(Boolean).map(v=>`<span>${esc(v)}</span>`).join('')}</div></div></div>`;
    const shown = list.slice(0, limit).map(row).join('');
    const more = list.length > limit ? `<details class="relation-more-details"><summary>ほか${esc(list.length - limit)}件を表示</summary><div class="relation-more-list">${list.slice(limit).map(row).join('')}</div></details>` : '';
    return shown + more;
  }
  function openCaseTargetModal(card = {}) {
    const c = card.case || DATA.cases.find(x => x.id === card.caseId) || {};
    const isNewCase = !c.id;
    const addingTarget = !!card.newTarget && !isNewCase;
    const targets = isNewCase ? [] : caseTargets(c);
    const t = addingTarget ? {} : (targets.find(x => x.id === card.targetId) || targets[0] || {});
    const v = {
      caseId:c.id || uid('ca'),
      targetId:addingTarget ? uid('tg') : (t.id || card.targetId || uid('tg')),
      caseTitle:clean(c.title || c.name || card.title),
      targetName:addingTarget ? '' : clean(t.name || card.targetName),
      role:addingTarget ? '' : clean(t.role || card.targetRole),
      status:normalizeCaseStatus(addingTarget ? '事案交付' : (t.status || card.status || c.status)),
      startedAt:addingTarget ? '' : clean(t.startedAt || card.startedAt || c.startedAt),
      nextDate:clean(addingTarget ? c.nextDate : (t.nextDate || card.nextDate || c.nextDate)),
      owner:clean(addingTarget ? c.owner : (t.owner || card.owner || c.owner)),
      priority:clean(addingTarget ? (c.priority || 'normal') : (t.priority || card.priority || c.priority || 'normal')),
      nextAction:addingTarget ? '' : clean(t.nextAction || card.nextAction || c.nextAction),
      note:addingTarget ? '' : clean(t.note || card.targetNote || card.note || '')
    };
    const fields = [
      {name:'caseTitle', label:'事案名', full:true, value:v.caseTitle},
      {name:'targetName', label:'調査対象者名', full:true, value:v.targetName},
      {name:'role', label:'区分・家族など', value:v.role},
      {name:'status', label:'進行状態', type:'select', options:CASE_STATUSES.map(x=>[x,x]), value:v.status},
      {name:'startedAt', label:'最初の着手日', type:'date', value:v.startedAt},
      {name:'nextDate', label:'次回予定日', type:'date', value:v.nextDate},
      {name:'owner', label:'担当', value:v.owner},
      {name:'priority', label:'優先度', type:'select', options:[['normal','通常'],['high','高優先'],['low','低優先']], value:v.priority},
      {name:'nextAction', label:'次の一手', full:true, value:v.nextAction},
      {name:'note', label:'対象者メモ', type:'textarea', full:true, value:v.note}
    ];
    openModal(isNewCase || addingTarget ? '対象者カードを追加' : '対象者カードを編集', formBase(v, fields, !isNewCase && !addingTarget), async(fd) => {
      const caseTitle = clean(fd.get('caseTitle')) || '無題の事案';
      let targetName = clean(fd.get('targetName')) || '調査対象者未入力';
      let status = normalizeCaseStatus(fd.get('status'));
      let startedAt = fd.get('startedAt') || '';
      if (CASE_STARTED.has(status) && !startedAt) startedAt = today();
      const caseSnapshot = c.id ? cloneRecord(c) : {};
      let obj = c.id ? cloneRecord(c) : {id:v.caseId, title:caseTitle, name:caseTitle, targetPersons:[], createdAt:new Date().toISOString()};
      obj.title = caseTitle; obj.name = caseTitle;
      obj.targetPersons = caseTargets(obj);
      let target = obj.targetPersons.find(x => x.id === v.targetId);
      if (!target) { target = {id:v.targetId, name:targetName}; obj.targetPersons.push(target); }
      Object.assign(target, {name:targetName, role:clean(fd.get('role')), status, startedAt, nextDate:fd.get('nextDate') || '', owner:clean(fd.get('owner')), priority:clean(fd.get('priority')) || 'normal', nextAction:clean(fd.get('nextAction')), note:clean(fd.get('note'))});
      const active = obj.targetPersons.find(x => normalizeCaseStatus(x.status) !== '完了') || obj.targetPersons[0] || target;
      obj.status = active.status || status; obj.startedAt = active.startedAt || startedAt; obj.nextDate = active.nextDate || ''; obj.owner = active.owner || ''; obj.priority = active.priority || 'normal'; obj.nextAction = active.nextAction || '';
      obj.client = obj.targetPersons.map(x=>x.name).filter(Boolean).join('、'); obj.subjects = obj.targetPersons.map(x=>x.name).filter(Boolean); obj.personIds = []; obj.updatedAt = new Date().toISOString();
      await saveSpeculumItem('cases', obj, caseSnapshot.updatedAt || ''); renderAll();
    }, async()=>{
      const current = DATA.cases.find(x => x.id === v.caseId); if (!current) return;
      if (preventReferencedCaseTargetDeletion(current.id, v.targetId)) return false;
      const snapshot = cloneRecord(current);
      const next = cloneRecord(current);
      let restoreToken = '';
      next.targetPersons = caseTargets(next).filter(x => x.id !== v.targetId);
      if (!next.targetPersons.length) {
        if (preventReferencedCaseDeletion(current)) return false;
        const deleted = await deleteSpeculumItems('cases', [next.id]);
        restoreToken = clean(deleted?.restoreTokens?.[next.id] || deleted?.restoreToken);
      }
      else {
        next.client = next.targetPersons.map(x=>x.name).join('、');
        next.subjects = next.targetPersons.map(x=>x.name);
        const active = next.targetPersons.find(x => normalizeCaseStatus(x.status) !== '完了') || next.targetPersons[0];
        next.status = normalizeCaseStatus(active?.status);
        next.startedAt = active?.startedAt || '';
        next.nextDate = active?.nextDate || '';
        next.owner = active?.owner || '';
        next.priority = active?.priority || 'normal';
        next.nextAction = active?.nextAction || '';
        next.updatedAt = new Date().toISOString();
        await saveSpeculumItem('cases', next, snapshot.updatedAt || '');
      }
      renderAll();
      toast('対象者カードを削除しました', {actionLabel:'元に戻す', ms:8000, onAction:()=>restoreDataItemSnapshot('cases', snapshot, '対象者カードを元に戻しました', restoreToken)});
    }, {
      itemLabel: v.targetName || '対象者カード',
      deleteMessage: targets.length <= 1
        ? `「${v.targetName || '対象者カード'}」はこの事案の最後の対象者です。削除すると事案「${v.caseTitle || '無題の事案'}」全体も削除されます。`
        : `事案「${v.caseTitle || '無題の事案'}」から「${v.targetName || '対象者カード'}」を削除します。`
    });
  }
  function relationSpotlightHtml(cards = []) {
    const cleanCards = arr(cards).filter(Boolean);
    if (!cleanCards.length) return '';
    return `<div class="relation-spotlight">${cleanCards.map(c => `<section class="${esc(c.tone || '')}"><b>${esc(c.title || '')}</b><span>${esc(c.value || '')}</span><em>${esc(c.hint || '')}</em></section>`).join('')}</div>`;
  }

  function openCaseRelation(card = {}) {
    const c = card.case || DATA.cases.find(x => x.id === card.caseId || x.id === card.id) || card || {};
    if (!c.id) { openCaseTargetModal(card); return; }
    const targets = caseTargets(c);
    const rel = caseRelations(c.id);
    const relDues = [
      ...rel.deadlines.map(x => Object.assign({}, x, {collection:'deadlines', label:'期限'})),
      ...rel.jimu.map(x => Object.assign({}, x, {collection:'jimu', label:'事務'}))
    ];
    const activeTargets = targets.filter(x => normalizeCaseStatus(x.status) !== '完了');
    const unworkedDues = relDues.filter(x => !isDone(x) && !workTaskForSource(x.collection, x.id));
    const todayRelated = [
      ...rel.events.filter(x => (x._ds || x.date) === today()).map(x => Object.assign({}, x, {title:itemTitle(x), _relType:calendarKindLabel(x), _relDate:eventTimeLabel(x) || fmtDate(x.date)})),
      ...relDues.filter(x => !isDone(x) && calendarDayDiff(x.due) !== null && calendarDayDiff(x.due) <= 0).map(x => Object.assign({}, x, {title:itemTitle(x), _relType:x.label, _relDate:dueLabel(x.due)})),
      ...rel.tasks.filter(x => !isDone(x) && (clean(x.status) === 'today' || (calendarDayDiff(x.due) !== null && calendarDayDiff(x.due) <= 0))).map(x => Object.assign({}, x, {title:itemTitle(x), _relType:'作業', _relDate:[statusLabel(x.status),dueLabel(x.due)].filter(Boolean).join(' / ')}))
    ];
    const openTasks = rel.tasks.filter(x => !isDone(x));
    const activeTaskMinutes = totalEstimate(openTasks);
    const nearRelDues = relDues.filter(x => !isDone(x) && calendarDayDiff(x.due) !== null && calendarDayDiff(x.due) <= 7);
    const nextEvent = rel.events.filter(x => calendarDayDiff(x._ds || x.date) !== null && calendarDayDiff(x._ds || x.date) >= 0).sort((a,b)=>byDate(a._ds || a.date,b._ds || b.date))[0];
    const noEstimate = openTasks.filter(x => !estimateMinutes(x)).length;
    const targetRow = t => `<div class="item"><div><div class="item-title">${esc(t.name || '対象者未入力')}</div><div class="item-meta">${metaHtml([t.status, t.role, t.startedAt?`着手 ${fmtDate(t.startedAt)}`:'', t.nextDate?`次回 ${fmtDate(t.nextDate)}`:'', t.owner?`担当 ${t.owner}`:'', t.nextAction?`次: ${t.nextAction}`:''])}</div></div></div>`;
    const targetRows = targets.length
      ? targets.slice(0,8).map(targetRow).join('') + (targets.length > 8 ? `<details class="relation-more-details"><summary>ほか${targets.length - 8}人を表示</summary><div class="relation-more-list">${targets.slice(8).map(targetRow).join('')}</div></details>` : '')
      : `<div class="empty">対象者はまだありません。</div>`;
    const spotlight = relationSpotlightHtml([
      {title:'次に見る', value: todayRelated[0] ? itemTitle(todayRelated[0]) : (nextEvent ? itemTitle(nextEvent) : (nearRelDues[0] ? itemTitle(nearRelDues[0]) : '落ち着いています')), hint: todayRelated[0] ? todayRelated[0]._relDate : (nextEvent ? `${fmtDate(nextEvent._ds || nextEvent.date)} ${eventTimeLabel(nextEvent)}` : (nearRelDues[0] ? dueLabel(nearRelDues[0].due) : '今日急ぐ関係はありません')), tone: todayRelated.length ? 'hot' : ''},
      {title:'未完了作業', value:`${openTasks.length}件`, hint:activeTaskMinutes ? `見積 ${durationLabel(activeTaskMinutes)}` : (openTasks.length ? '見積未入力' : '作業はありません'), tone:openTasks.length ? 'work' : ''},
      {title:'近い期限', value:`${nearRelDues.length}件`, hint:nearRelDues[0] ? `${fmtDate(nearRelDues[0].due)} ${dueLabel(nearRelDues[0].due)}` : '7日以内はありません', tone:nearRelDues.length ? 'due' : ''},
      {title:'未見積', value:`${noEstimate}件`, hint:noEstimate ? '重いものだけ見積を入れる' : '見積は整っています', tone:noEstimate ? 'soft' : ''}
    ]);
    const html = `<p class="modal-note">「${esc(c.title || c.name || '事案')}」に紐づく予定・期限・作業・対象者をまとめて確認します。今日の関連項目と、作業にまだ追加していない項目を先に表示します。</p>
      <div class="relation-summary">${[['今日の関連項目',todayRelated.length],['対象者',targets.length],['未追加',unworkedDues.length],['未完了作業',openTasks.length],['作業見積',durationLabel(activeTaskMinutes) || '0']].map(([k,n])=>`<div class="mini-metric"><b>${esc(n)}</b><span>${esc(k)}</span></div>`).join('')}</div>
      ${spotlight}
      <div class="relation-grid relation-grid-wide">
        <div class="relation-block relation-block-priority"><h3>今日の関連項目</h3>${relationList(todayRelated, x=>[x._relType,x._relDate,peopleLabel(x),caseName(x.caseId)], '今日すぐ見る関連項目はありません。')}</div>
        <div class="relation-block"><h3>対象者</h3>${targetRows}</div>
        <div class="relation-block"><h3>予定・出来事</h3>${relationList(rel.events, x=>[fmtDate(x._ds || x.date),eventTimeLabel(x),calendarKindLabel(x),peopleLabel(x)], '予定・出来事はありません。')}</div>
        <div class="relation-block"><h3>期限・事務</h3>${relationList(relDues, x=>[x.label,fmtDate(x.due),dueLabel(x.due),priorityLabel(x.priority),peopleLabel(x),workTaskForSource(x.collection, x.id)?'追加済み':'未追加'], '期限・事務はありません。')}</div>
        <div class="relation-block"><h3>作業</h3>${relationList(rel.tasks, x=>[fmtDate(x.due),dueLabel(x.due),estimateMeta(x),statusLabel(x.status),peopleLabel(x)], '作業はありません。')}</div>
      </div>
      <div class="modal-actions"><div></div><div><button type="button" class="ghost" data-case-event>予定</button><button type="button" class="ghost" data-case-deadline>期限</button><button type="button" class="ghost" data-case-task>作業</button><button type="button" class="ghost" data-case-target-add>対象者を追加</button><button type="button" class="primary" data-case-edit>編集</button></div></div>`;
    if (!openModal('関連情報を見る', html, null, null, {noSubmit:true})) return;
    const form = $('modalForm');
    form.querySelector('[data-case-event]').onclick = () => { closeModal(true); openEventModal({date:card.nextDate || c.nextDate || today(), caseId:c.id}); };
    form.querySelector('[data-case-deadline]').onclick = () => { closeModal(true); openDueModal('deadlines', {due:card.nextDate || c.nextDate || today(), caseId:c.id}); };
    form.querySelector('[data-case-task]').onclick = () => { closeModal(true); openTaskModal({title:`${c.title || c.name || '事案'} の次の作業`, caseId:c.id, due:card.nextDate || c.nextDate || '', priority:card.priority || c.priority || 'normal'}); };
    form.querySelector('[data-case-target-add]').onclick = () => { closeModal(true); openCaseTargetModal({caseId:c.id, case:c, newTarget:true}); };
    form.querySelector('[data-case-edit]').onclick = () => { closeModal(true); openCaseTargetModal(card.caseId ? card : {caseId:c.id, case:c}); };
  }

  function openCaseDetail(card) { openCaseRelation(card); }
  function openPersonDetail(p) {
    const rel = personRelations(p.id);
    const relDues = [
      ...rel.deadlines.map(x => Object.assign({}, x, {collection:'deadlines', label:'期限'})),
      ...rel.jimu.map(x => Object.assign({}, x, {collection:'jimu', label:'事務'}))
    ];
    const todayRelated = [
      ...rel.events.filter(x => (x._ds || x.date) === today()).map(x => Object.assign({}, x, {title:itemTitle(x), _relType:calendarKindLabel(x), _relDate:eventTimeLabel(x) || fmtDate(x.date)})),
      ...relDues.filter(x => !isDone(x) && calendarDayDiff(x.due) !== null && calendarDayDiff(x.due) <= 0).map(x => Object.assign({}, x, {title:itemTitle(x), _relType:x.label, _relDate:dueLabel(x.due)})),
      ...rel.tasks.filter(x => !isDone(x) && (clean(x.status) === 'today' || (calendarDayDiff(x.due) !== null && calendarDayDiff(x.due) <= 0))).map(x => Object.assign({}, x, {title:itemTitle(x), _relType:'作業', _relDate:[statusLabel(x.status),dueLabel(x.due)].filter(Boolean).join(' / ')}))
    ];
    const openPersonTasks = rel.tasks.filter(x => !isDone(x));
    const activePersonTaskMinutes = totalEstimate(openPersonTasks);
    const nearPersonDues = relDues.filter(x => !isDone(x) && calendarDayDiff(x.due) !== null && calendarDayDiff(x.due) <= 7);
    const nextPersonEvent = rel.events.filter(x => calendarDayDiff(x._ds || x.date) !== null && calendarDayDiff(x._ds || x.date) >= 0).sort((a,b)=>byDate(a._ds || a.date,b._ds || b.date))[0];
    const personNoEstimate = openPersonTasks.filter(x => !estimateMinutes(x)).length;
    const careerItems = rel.career.slice().map((c,i)=>Object.assign({_personCareerOrder:careerOrderValue(c,i)}, c)).sort((a,b)=>b._personCareerOrder-a._personCareerOrder).map(c => Object.assign({}, c, {title:clean(c.fiscalYear) ? `${clean(c.fiscalYear)}年度` : '経歴'}));
    const spotlight = relationSpotlightHtml([
      {title:'次に見る', value: todayRelated[0] ? itemTitle(todayRelated[0]) : (nextPersonEvent ? itemTitle(nextPersonEvent) : (nearPersonDues[0] ? itemTitle(nearPersonDues[0]) : '落ち着いています')), hint: todayRelated[0] ? todayRelated[0]._relDate : (nextPersonEvent ? `${fmtDate(nextPersonEvent._ds || nextPersonEvent.date)} ${eventTimeLabel(nextPersonEvent)}` : (nearPersonDues[0] ? dueLabel(nearPersonDues[0].due) : '今日急ぐ関係はありません')), tone: todayRelated.length ? 'hot' : ''},
      {title:'未完了作業', value:`${openPersonTasks.length}件`, hint:activePersonTaskMinutes ? `見積 ${durationLabel(activePersonTaskMinutes)}` : (openPersonTasks.length ? '見積未入力' : '作業はありません'), tone:openPersonTasks.length ? 'work' : ''},
      {title:'近い期限', value:`${nearPersonDues.length}件`, hint:nearPersonDues[0] ? `${fmtDate(nearPersonDues[0].due)} ${dueLabel(nearPersonDues[0].due)}` : '7日以内はありません', tone:nearPersonDues.length ? 'due' : ''},
      {title:'経歴', value:`${rel.career.length}件`, hint:careerItems[0] ? itemTitle(careerItems[0]) : '経歴紐づきなし', tone:rel.career.length ? 'soft' : ''}
    ]);
    const html = `<p class="modal-note">「${esc(p.name)}」との予定・作業・出来事を整理します。調査事案の対象者、事務年度ごとの経歴とは別管理です。</p>
    <div class="relation-summary person-relation-summary">${[['今日の関連項目',todayRelated.length],['予定',rel.events.length],['期限・事務',relDues.length],['作業',rel.tasks.length],['作業見積',durationLabel(activePersonTaskMinutes) || '0'],['経歴',rel.career.length]].map(([k,n])=>`<div class="mini-metric"><b>${esc(n)}</b><span>${esc(k)}</span></div>`).join('')}</div>
    ${spotlight}
    <div class="relation-grid relation-grid-wide">
      <div class="relation-block relation-block-priority"><h3>今日の関連項目</h3>${relationList(todayRelated, x=>[x._relType,x._relDate,caseName(x.caseId)], '今日すぐ見る関連項目はありません。')}</div>
      <div class="relation-block"><h3>予定</h3>${relationList(rel.events, x=>[fmtDate(x._ds || x.date),eventTimeLabel(x),calendarKindLabel(x),caseName(x.caseId)], '予定はありません。')}</div>
      <div class="relation-block"><h3>期限・事務</h3>${relationList(relDues, x=>[x.label,fmtDate(x.due),dueLabel(x.due),caseName(x.caseId),workTaskForSource(x.collection, x.id)?'追加済み':'未追加'], '期限・事務はありません。')}</div>
      <div class="relation-block"><h3>作業</h3>${relationList(rel.tasks, x=>[fmtDate(x.due),dueLabel(x.due),estimateMeta(x),statusLabel(x.status),caseName(x.caseId)], '作業はありません。')}</div>
      <div class="relation-block"><h3>経歴</h3>${relationList(careerItems, x=>[careerCellValue(x,'office',new Map()),careerCellValue(x,'departments',new Map()),careerCellValue(x,'section',new Map()),careerCellValue(x,'position',new Map())], '経歴への紐づきはありません。')}</div>
      <div class="relation-block"><h3>出来事・メモ</h3><div class="item"><div><div class="item-title">${esc(p.name)}</div><div class="item-meta">${metaHtml([personRetirementLabel(p),p.kind,p.term,p.org,p.role,p.section,p.title,p.note || 'メモはありません。'])}</div></div></div></div>
    </div><div class="modal-actions"><div></div><div><button type="button" class="ghost" data-person-event>予定</button><button type="button" class="primary" data-person-task>作業</button></div></div>`;
    if (!openModal('関連情報を見る', html, null, null, {noSubmit:true})) return;
    $('modalForm').querySelector('[data-person-event]').onclick = () => { closeModal(true); openEventModal({date:today(), personIds:[p.id]}); };
    $('modalForm').querySelector('[data-person-task]').onclick = () => { closeModal(true); openTaskModal({personIds:[p.id], title:`${p.name} に関する作業`}); };
  }



  async function sendSpecToWork(collection, item, opts = {}) {
    return runUiAction(`work-add:${sourceId(collection, item?.id)}`, async () => {
      if (workTaskForSource(collection, item.id)) { toast('この項目は作業に追加済みです'); return; }
      const task = makeSpecWorkTask(collection, item, opts);
      const j = await saveWorkTaskItem(task);
      renderAll();
      toast(opts.status === 'today' ? '項目を作業に追加し、「今日やる」に移しました' : '項目を作業に追加しました', {actionLabel:'元に戻す', ms:7000, onAction:()=>removeWorkTasksByIds([j.item?.id || task.id])});
      return j;
    }, '項目を作業に追加できませんでした');
  }
  async function caseToWork(card, opts = {}) {
    return runUiAction(`work-add:${caseTargetSource(card)}`, async () => {
      if (workTaskForCaseTarget(card)) { toast('この対象者カードは作業に追加済みです'); return; }
      const task = makeCaseWorkTask(card, opts);
      const j = await saveWorkTaskItem(task);
      renderAll();
      toast(opts.status === 'today' ? '対象者カードを作業に追加し、「今日やる」に移しました' : '対象者カードを作業に追加しました', {actionLabel:'元に戻す', ms:7000, onAction:()=>removeWorkTasksByIds([j.item?.id || task.id])});
      return j;
    }, '対象者カードを作業に追加できませんでした');
  }
  async function eventToWork(e) {
    const sid = sourceId('events', e.id);
    return runUiAction(`work-add:${sid}`, async () => {
      if (WORK.tasks.find(t => clean(t.source) === sid)) { toast(`この${calendarKindLabel(e)}は作業に追加済みです`); return; }
      const task = {id:uid('wk'), title:`${calendarKindLabel(e)}後対応: ${itemTitle(e)}`, status:'next', priority:'normal', due:e._ds || e.date || '', estimateMinutes:Math.max(0, Number(e.estimateMinutes || 0) || 0), nextAction:`${calendarKindLabel(e)}後の対応を確認`, caseId:e.caseId || '', personIds:arr(e.personIds), note:[scheduleShiftLabel(e), e.note || ''].filter(Boolean).join(' / '), source:sid, createdAt:new Date().toISOString(), updatedAt:new Date().toISOString()};
      const j = await saveWorkTaskItem(task);
      renderAll();
      toast(`${calendarKindLabel(e)}を作業に追加しました`, {actionLabel:'元に戻す', ms:7000, onAction:()=>removeWorkTasksByIds([j.item?.id || task.id])});
      return j;
    }, `${calendarKindLabel(e)}を作業に追加できませんでした`);
  }
  async function sendAllToWork() {
    return runUiAction('work-add-all', async () => {
      const tasks = [];
      for (const col of ['deadlines','jimu']) for (const x of DATA[col]) {
        const d = dayDiff(x.due);
        if (!isDone(x) && d !== null && d <= 7 && !workTaskForSource(col, x.id)) tasks.push(makeSpecWorkTask(col, x));
      }
      for (const c of caseAlerts(7)) if (!workTaskForCaseTarget(c)) tasks.push(makeCaseWorkTask(c));
      if (!tasks.length) { toast('作業に追加する項目はありません'); return; }
      const j = await saveWorkTaskItems(tasks, []);
      const addedIds = arr(j.items).length ? arr(j.items).map(x => x.id).filter(Boolean) : tasks.map(x => x.id);
      renderAll();
      const msg = `${addedIds.length}件を作業に追加しました`;
      toast(j.merged ? `${msg}（最新データを反映）` : msg, {actionLabel:'元に戻す', ms:8000, onAction:()=>removeWorkTasksByIds(addedIds, 'まとめて作業に追加した内容を元に戻しました')});
      return j;
    }, 'まとめて作業に追加できませんでした');
  }
  function cloneRecord(x){ return JSON.parse(JSON.stringify(x || {})); }
  async function restoreWorkTaskSnapshot(snapshot, message = '元に戻しました', restoreToken = '') {
    return runUiAction(`work-restore:${snapshot?.id}`, async () => {
      const restored = Object.assign(cloneRecord(snapshot), {updatedAt:new Date().toISOString(), ...(restoreToken ? {_restoreToken:restoreToken} : {})});
      await saveWorkTaskItem(restored, WORK.tasks.find(x => x.id === snapshot.id)?.updatedAt || snapshot.updatedAt || ''); renderAll(); toast(message);
    }, '作業を元に戻せませんでした');
  }
  async function restoreDataItemSnapshot(collection, snapshot, message = '元に戻しました', restoreToken = '') {
    return runUiAction(`speculum-restore:${collection}:${snapshot?.id}`, async () => {
      const list = DATA[collection]; if (!Array.isArray(list)) return;
      const current = list.find(x => x.id === snapshot.id);
      const restored = Object.assign(cloneRecord(snapshot), {updatedAt:new Date().toISOString(), ...(restoreToken ? {_restoreToken:restoreToken} : {})});
      await saveSpeculumItem(collection, restored, current?.updatedAt || snapshot.updatedAt || ''); renderAll(); toast(message);
    }, '元に戻せませんでした');
  }
  async function removeWorkTasksByIds(ids = [], message = '作業に追加した内容を元に戻しました') {
    const set = new Set(arr(ids).filter(Boolean));
    if (!set.size) return;
    return runUiAction(`work-remove:${[...set].sort().join(',')}`, async () => {
      await deleteWorkTaskItems([...set]); renderAll(); toast(message);
    }, '追加した作業を元に戻せませんでした');
  }
  async function completeWorkTask(id, done = true) {
    return runUiAction(`work-complete:${id}`, async () => {
      const current = WORK.tasks.find(x => x.id === id); if (!current) return;
      const snapshot = cloneRecord(current);
      const next = cloneRecord(current);
      next.status = done ? 'done' : 'next';
      if (done && !next.completedAt) next.completedAt = today();
      if (!done) delete next.completedAt;
      next.updatedAt = new Date().toISOString();
      await saveWorkTaskItem(next, snapshot.updatedAt || ''); renderAll();
      toast(done ? '作業を完了にしました' : '作業を戻しました', {actionLabel:'元に戻す', ms:7000, onAction:()=>restoreWorkTaskSnapshot(snapshot)});
    }, '作業の状態を更新できませんでした');
  }
  async function completeItem(collection, id, done = true) {
    return runUiAction(`speculum-complete:${collection}:${id}`, async () => {
      const current = DATA[collection].find(x => x.id === id); if (!current) return;
      const snapshot = cloneRecord(current);
      const next = cloneRecord(current);
      next.done = done; next.status = done ? 'done' : 'open'; next.updatedAt = new Date().toISOString();
      await saveSpeculumItem(collection, next, snapshot.updatedAt || ''); renderAll();
      toast(done ? '完了にしました' : '未完了に戻しました', {actionLabel:'元に戻す', ms:7000, onAction:()=>restoreDataItemSnapshot(collection, snapshot)});
    }, '完了状態を更新できませんでした');
  }

  function openModal(title, html, onSubmit, onDelete, opts = {}) {
    if (modalSaving) { toast('保存が終わるまでお待ちください'); return false; }
    const backdrop = $('modalBackdrop');
    const openingFromClosed = backdrop?.hidden ?? true;
    if (!openingFromClosed && dirtyModal) { toast('編集中の画面を閉じてから、次の操作を行ってください'); return false; }
    if (openingFromClosed && document.activeElement instanceof HTMLElement) modalReturnFocus = document.activeElement;
    const session = ++modalSession;
    $('modalTitle').textContent = title;
    const form = $('modalForm'); form.innerHTML = html; dirtyModal = false;
    bindFieldPresets(form);
    form.querySelectorAll('input,textarea,select').forEach(x => {
      const markDirty = () => { if (!opts.noSubmit && !x.matches('[data-person-candidate-search]')) dirtyModal = true; };
      x.addEventListener('input', markDirty);
      x.addEventListener('change', markDirty);
    });
    bindPersonCandidateSearch(form);
    let saving = false;
    const setSaving = (on) => {
      saving = on;
      modalSaving = on;
      form.classList.toggle('is-saving', on);
      backdrop?.setAttribute('aria-busy', on ? 'true' : 'false');
      const closeButton = $('modalClose'); if (closeButton) closeButton.disabled = on;
      const submit = form.querySelector('button[type="submit"]');
      if (submit) {
        if (!submit.dataset.idleLabel) submit.dataset.idleLabel = submit.textContent || '保存';
        submit.disabled = on;
        submit.textContent = on ? '保存中…' : submit.dataset.idleLabel;
      }
      form.querySelectorAll('input,textarea,select,button').forEach(el => { if (el !== submit) el.disabled = on; });
    };
    if (opts.noSubmit) form.onsubmit = (e) => e.preventDefault();
    else form.onsubmit = async (e) => {
      e.preventDefault();
      if (saving) return;
      const formData = new FormData(form);
      setSaving(true);
      try {
        const result = await onSubmit(formData, form);
        if (result === false || result?.cancelled) { setSaving(false); return; }
        if (session !== modalSession) return;
        setSaving(false); dirtyModal = false; closeModal(true);
      } catch (err) {
        setSaving(false);
        if (err?.handled) { if (err?.reloaded) { dirtyModal=false; closeModal(true); } return; }
        if (err?.cancelled) { toast(err.message || '保存を中止しました'); return; }
        toast(err?.message || '保存に失敗しました');
        return;
      }
    };
    form.addEventListener('keydown', event => {
      if (opts.noSubmit || event.key !== 'Enter' || (!event.ctrlKey && !event.metaKey)) return;
      event.preventDefault();
      if (!saving) form.requestSubmit();
    });
    form.querySelector('[data-cancel]')?.addEventListener('click', () => closeModal(false));
    form.querySelector('[data-delete]')?.addEventListener('click', async () => {
      if (saving || !onDelete) return;
      const enteredName = clean(form.elements?.title?.value || form.elements?.name?.value || form.elements?.targetName?.value || form.elements?.caseTitle?.value || form.elements?.fiscalYear?.value);
      const itemLabel = clean(opts.itemLabel || enteredName || title.replace(/を編集$|を追加$/, '')) || 'この項目';
      const detail = clean(opts.deleteMessage) || `「${itemLabel}」を削除します。削除後しばらくは、画面下の「元に戻す」で復元できます。`;
      if (!await askConfirm(`${itemLabel}を削除しますか？`, detail, '削除する')) return;
      setSaving(true);
      try {
        const result = await onDelete();
        if (result === false || result?.cancelled) { setSaving(false); return; }
        setSaving(false); dirtyModal = false; closeModal(true);
      }
      catch (err) { setSaving(false); if (!err?.handled) toast(err?.message || '削除に失敗しました'); }
    });
    if (backdrop) backdrop.onkeydown = event => keepKeyboardFocus(event, backdrop.querySelector('.modal-card'));
    const modalCard = backdrop?.querySelector('.modal-card');
    if (modalCard) modalCard.scrollTop = 0;
    if (backdrop) backdrop.scrollTop = 0;
    backdrop.hidden = false;
    setTimeout(() => {
      const editorField = form.querySelector('input:not([type="hidden"]):not([disabled]),textarea:not([disabled]),select:not([disabled])');
      (editorField || $('modalClose'))?.focus({preventScroll:true});
      // 閲覧モーダルの下部操作へ初期フォーカスが移り、冒頭が隠れるのを防ぐ。
      if (modalCard) modalCard.scrollTop = 0;
      if (backdrop) backdrop.scrollTop = 0;
    }, 30);
    return true;
  }
  function closeModal(force = false) {
    if (modalSaving) { toast('保存中です。完了するまでお待ちください'); return; }
    if (!force && dirtyModal) { askConfirm('入力中の内容があります', '保存せずに編集画面を閉じますか？', '閉じる').then(ok => { if (ok) closeModal(true); }); return; }
    const backdrop = $('modalBackdrop');
    backdrop.hidden = true; backdrop.removeAttribute('aria-busy'); backdrop.onkeydown = null;
    const closeButton = $('modalClose'); if (closeButton) closeButton.disabled = false;
    $('modalForm').innerHTML = ''; dirtyModal = false; modalSaving = false; modalSession++;
    const returnTo = modalReturnFocus; modalReturnFocus = null;
    setTimeout(() => { if (backdrop.hidden && returnTo?.isConnected) returnTo.focus({preventScroll:true}); }, 0);
    schedulePendingExternalSync();
  }
  function backdropTap(e) {
    if (e.target !== $('modalBackdrop')) return;
    document.querySelector('.modal-card')?.classList.add('shake');
    setTimeout(()=>document.querySelector('.modal-card')?.classList.remove('shake'),260);
    toast('外側クリックでは閉じません。右上の×か閉じるボタンを使ってください。');
  }
  function formBase(v, fields, del = false) {
    return `<div class="form-grid">${fields.map(f => fieldHTML(v, f)).join('')}<div class="modal-actions"><div>${del?'<button type="button" class="ghost" data-delete>削除</button>':''}</div><div><button type="button" class="ghost" data-cancel>閉じる</button><button type="submit" class="primary">保存</button></div></div></div>`;
  }
  function fieldExtras(f) {
    const presets = arr(f.presets).filter(x => arr(x).length >= 2);
    const chips = presets.length ? `<div class="field-presets" aria-label="${esc(f.label)}の候補">${presets.map(([value,label]) => `<button type="button" class="preset-chip" data-set-field="${esc(f.name)}" data-set-value="${esc(value)}">${esc(label)}</button>`).join('')}</div>` : '';
    const hint = f.hint ? `<small class="field-hint">${esc(f.hint)}</small>` : '';
    return chips + hint;
  }
  function bindFieldPresets(root) {
    $$('[data-set-field]', root).forEach(btn => {
      btn.addEventListener('click', () => {
        const name = btn.dataset.setField || '';
        const el = root.elements ? root.elements[name] : null;
        if (!el) return;
        el.value = btn.dataset.setValue || '';
        dirtyModal = true;
        el.dispatchEvent(new Event('input', {bubbles:true}));
        el.dispatchEvent(new Event('change', {bubbles:true}));
        el.focus?.();
      });
    });
  }
  function fieldHTML(v, f) {
    const val = f.value ?? v[f.name] ?? '';
    const full = f.full ? ' full' : '';
    const extras = fieldExtras(f);
    if (f.type === 'textarea') return `<label class="field${full}"><span>${esc(f.label)}</span><textarea name="${esc(f.name)}">${esc(val)}</textarea>${extras}</label>`;
    if (f.type === 'select') return `<label class="field${full}"><span>${esc(f.label)}</span><select name="${esc(f.name)}">${arr(f.options).map(o => `<option value="${esc(o[0])}" ${String(val)===String(o[0])?'selected':''}>${esc(o[1])}</option>`).join('')}</select>${extras}</label>`;
    if (f.type === 'people') return `<div class="field full"><span>${esc(f.label)}</span><div data-people>${peopleOptions(arr(f.value ?? val), f.name)}</div>${extras}</div>`;
    if (f.type === 'personSingle') return singleStaffFieldHTML(v, f);
    if (f.type === 'peopleStaff') return multiStaffFieldHTML(v, f);
    if (f.type === 'checkbox') return `<label class="field check-field${full}"><input name="${esc(f.name)}" type="checkbox" value="1" ${val?'checked':''}><span>${esc(f.label)}</span>${extras}</label>`;
    return `<label class="field${full}"><span>${esc(f.label)}</span><input name="${esc(f.name)}" type="${esc(f.type || 'text')}" value="${esc(val)}">${extras}</label>`;
  }
  function personSearchText(p) {
    if (p && typeof p === 'object' && PERSON_SEARCH_TEXT_CACHE.has(p)) return PERSON_SEARCH_TEXT_CACHE.get(p);
    const text = [p.name, p.kana, p.kind, p.term, p.org, p.role, p.section, p.title, p.tags, p.retiredAt, p.retired?'退職 退職者':'', p.note].map(x => clean(x)).filter(Boolean).join(' ').toLowerCase();
    if (p && typeof p === 'object') PERSON_SEARCH_TEXT_CACHE.set(p, text);
    return text;
  }
  function personCandidateSearchBox(target, opts = {}) {
    const compact = opts.compact ? '1' : '0';
    const lazy = opts.lazy ? '1' : '0';
    const placeholder = opts.placeholder || (opts.compact ? '名前を入力すると候補が出ます' : '名前・種別・期別・所属で候補検索');
    return `<input class="person-candidate-search" type="search" data-person-candidate-search data-person-target="${esc(target)}" data-person-compact="${compact}" data-person-lazy="${lazy}" placeholder="${esc(placeholder)}"><small class="person-search-count" data-person-search-count="${esc(target)}"></small>`;
  }
  function personPickerOption(p, selected = false) {
    if (!p) return '';
    const extra = [p.org, p.role].map(clean).filter(Boolean).join('・');
    return `<option value="${esc(p.id)}" data-person-text="${esc(personSearchText(p))}" ${selected?'selected':''}>${esc(personCandidateDisplay(p))}${extra?` / ${esc(extra)}`:''}</option>`;
  }
  function lazyPersonSelectHTML(target, selectedId = '', opts = {}) {
    const selected = personById(selectedId);
    const departmentAttr = opts.departmentManager ? ' data-department-manager-id' : '';
    return `<select name="${esc(target)}" data-person-select="${esc(target)}" data-lazy-person-select data-selected-person-id="${esc(selected?.id || '')}"${departmentAttr}><option value="">人物管理から選択</option>${personPickerOption(selected, true)}</select>`;
  }
  function lazyPersonCandidatesHTML(target, selectedIds = [], opts = {}) {
    const selected = uniqueIds(selectedIds);
    return `<div data-lazy-person-candidates="${esc(target)}" data-selected-person-ids="${esc(JSON.stringify(selected))}" data-person-input-name="${esc(opts.inputName || target)}" data-department-staff="${opts.departmentStaff ? '1' : '0'}"></div>`;
  }
  function bindLazyPersonCandidateSearch(input, scope, target, compact) {
    if (input.dataset.personLazy !== '1') return false;
    const lazyList = $$('[data-lazy-person-candidates]', scope).find(el => el.dataset.lazyPersonCandidates === target);
    const lazySelect = $$('select[data-lazy-person-select]', scope).find(el => el.dataset.personSelect === target);
    if (!lazyList && !lazySelect) return false;
    const people = peopleSorted(DATA.people);
    const countEls = $$('[data-person-search-count]', scope).filter(el => el.dataset.personSearchCount === target);
    const manualInput = lazySelect ? scope.querySelector('.staff-single input:not([data-person-candidate-search])') : null;
    const readSelected = () => {
      if (!lazyList) return [];
      try { return uniqueIds(JSON.parse(lazyList.dataset.selectedPersonIds || '[]')); }
      catch (_) { return []; }
    };
    const writeSelected = ids => { if (lazyList) lazyList.dataset.selectedPersonIds = JSON.stringify(uniqueIds(ids)); };
    let applyFrame = 0;
    const apply = () => {
      applyFrame = 0;
      const q = clean(input.value).toLowerCase();
      let selectedCount = 0;
      let matchedCount = 0;
      let shownCount = 0;
      if (lazyList) {
        const selectedIds = readSelected();
        const selectedSet = new Set(selectedIds);
        selectedCount = selectedIds.length;
        const matches = q ? people.filter(person => personSearchText(person).includes(q)) : (people.length <= PERSON_PICKER_RESULT_LIMIT ? people : []);
        matchedCount = q || matches.length ? matches.length : selectedCount;
        const visible = [];
        const seen = new Set();
        selectedIds.map(personById).filter(Boolean).forEach(person => { seen.add(person.id); visible.push(person); });
        matches.slice(0, PERSON_PICKER_RESULT_LIMIT).forEach(person => { if (!seen.has(person.id)) { seen.add(person.id); visible.push(person); } });
        const name = lazyList.dataset.personInputName || target;
        const departmentAttr = lazyList.dataset.departmentStaff === '1' ? ' data-department-staff-id' : '';
        lazyList.innerHTML = visible.map(person => {
          const extra = [person.org, person.role].map(clean).filter(Boolean).join('・');
          return `<label class="pill-select staff-person" data-person-candidate="${esc(target)}" data-person-text="${esc(personSearchText(person))}"><input name="${esc(name)}" type="checkbox" value="${esc(person.id)}" ${selectedSet.has(person.id)?'checked':''}${departmentAttr}> ${esc(personCandidateDisplay(person))}${extra?`<small>${esc(extra)}</small>`:''}</label>`;
        }).join('') || (people.length ? '' : '<span class="muted">人物管理の登録はまだありません。</span>');
        shownCount = visible.length;
      }
      if (lazySelect) {
        const selectedId = clean(lazySelect.value || lazySelect.dataset.selectedPersonId);
        const selected = personById(selectedId);
        const matches = q ? people.filter(person => personSearchText(person).includes(q)) : (people.length <= PERSON_PICKER_RESULT_LIMIT ? people : []);
        matchedCount = q || matches.length ? matches.length : (selected ? 1 : 0);
        selectedCount = selected ? 1 : 0;
        const visible = [];
        const seen = new Set();
        if (selected) { visible.push(selected); seen.add(selected.id); }
        matches.slice(0, PERSON_PICKER_RESULT_LIMIT).forEach(person => { if (!seen.has(person.id)) { seen.add(person.id); visible.push(person); } });
        lazySelect.innerHTML = '<option value="">人物管理から選択</option>' + visible.map(person => personPickerOption(person, person.id === selectedId)).join('');
        lazySelect.value = selectedId;
        lazySelect.dataset.selectedPersonId = selectedId;
        shownCount = visible.length;
      }
      countEls.forEach(el => {
        if (!people.length) el.textContent = '候補はまだありません';
        else if (!q && people.length <= PERSON_PICKER_RESULT_LIMIT) el.textContent = `${people.length}人から選択できます${selectedCount ? `（選択中${selectedCount}人）` : ''}`;
        else if (!q) el.textContent = selectedCount ? `選択中${selectedCount}人。名前を入力して変更できます` : '名前を入力すると候補を表示します';
        else if (matchedCount > PERSON_PICKER_RESULT_LIMIT) el.textContent = `一致${matchedCount}人のうち先頭${shownCount}人を表示。さらに名前を入力して絞り込めます`;
        else el.textContent = `一致${matchedCount}人${selectedCount ? `（選択中${selectedCount}人）` : ''}`;
      });
    };
    const scheduleApply = () => { if (!applyFrame) applyFrame = requestAnimationFrame(apply); };
    input.addEventListener('input', scheduleApply);
    scope.addEventListener('change', event => {
      const checkbox = event.target.closest?.('[data-person-candidate] input[type="checkbox"]');
      if (checkbox && lazyList?.contains(checkbox)) {
        const selected = new Set(readSelected());
        if (checkbox.checked) selected.add(checkbox.value); else selected.delete(checkbox.value);
        writeSelected([...selected]);
        dirtyModal = true;
        scheduleApply();
        return;
      }
      if (event.target === lazySelect) {
        lazySelect.dataset.selectedPersonId = clean(lazySelect.value);
        if (clean(lazySelect.value) && manualInput) manualInput.value = '';
        dirtyModal = true;
        scheduleApply();
      }
    });
    manualInput?.addEventListener('input', () => {
      if (!clean(manualInput.value) || !lazySelect) return;
      lazySelect.value = '';
      lazySelect.dataset.selectedPersonId = '';
      scheduleApply();
    });
    apply();
    return true;
  }
  function bindPersonCandidateSearch(root) {
    $$('[data-person-candidate-search]', root).forEach(input => {
      if (input.dataset.personSearchBound === '1') return;
      input.dataset.personSearchBound = '1';
      const target = input.dataset.personTarget || '';
      const compact = input.dataset.personCompact === '1';
      const scope = input.closest('.staff-field,[data-people]') || root;
      if (bindLazyPersonCandidateSearch(input, scope, target, compact)) return;
      const candidateEls = $$('[data-person-candidate]', scope).filter(el => (el.dataset.personCandidate || '') === target);
      const chipBox = $$('[data-selected-person-chips]', scope).find(el => (el.dataset.selectedPersonChips || '') === target);
      const candidateLists = new Set(candidateEls.map(el => el.closest('.person-candidate-list,.staff-checks')).filter(Boolean));
      const selects = $$('select[data-person-select]', scope).filter(sel => (sel.dataset.personSelect || '') === target);
      const countEls = $$('[data-person-search-count]', scope).filter(el => (el.dataset.personSearchCount || '') === target);
      let applyFrame = 0;
      const apply = () => {
        applyFrame = 0;
        const q = clean(input.value).toLowerCase();
        let total = 0, shown = 0, selected = 0;
        if (chipBox) chipBox.innerHTML = '';
        candidateEls.forEach(el => {
          total++;
          const check = el.querySelector('input[type="checkbox"]');
          const checked = !!(check && check.checked);
          if (checked) selected++;
          if (checked && chipBox) {
            const chip = document.createElement('button');
            chip.type = 'button'; chip.className = 'person-chip';
            chip.textContent = `${clean(el.textContent)} ×`;
            chip.onclick = () => { check.checked = false; dirtyModal = true; apply(); };
            chipBox.appendChild(chip);
          }
          const text = el.dataset.personText || '';
          const hit = compact ? (checked || (!!q && text.includes(q))) : (!q || text.includes(q));
          el.hidden = !hit;
          if (hit) shown++;
        });
        candidateLists.forEach(list => list.classList.toggle('empty-candidates', compact && !q && shown === 0));
        selects.forEach(sel => {
          let optsTotal = 0, optsShown = 0;
          Array.from(sel.options).forEach(opt => {
            if (!opt.value) { opt.hidden = false; return; }
            optsTotal++;
            const hit = !q || (opt.dataset.personText || opt.textContent || '').toLowerCase().includes(q);
            opt.hidden = !hit;
            if (hit) optsShown++;
          });
          if (optsTotal) { total = optsTotal; shown = optsShown; }
        });
        countEls.forEach(el => {
          if (!total) el.textContent = '候補はまだありません';
          else if (compact && !q) el.textContent = selected ? `選択中${selected}人。検索で追加できます` : '名前を入力すると候補を表示します';
          else el.textContent = `${shown}/${total}人を表示${compact ? `（選択中${selected}人）` : ''}`;
        });
      };
      const scheduleApply = () => { if (!applyFrame) applyFrame = requestAnimationFrame(apply); };
      input.addEventListener('input', scheduleApply);
      scope.addEventListener('change', event => {
        const candidate = event.target.closest?.('[data-person-candidate]');
        if (!candidate || (candidate.dataset.personCandidate || '') !== target) return;
        dirtyModal = true;
        scheduleApply();
      });
      apply();
    });
  }
  function peopleOptions(values, target = 'personIds') {
    const set = new Set(values);
    const boxes = peopleSorted(DATA.people).map(p => `<label class="pill-select person-chip-option" data-person-candidate="${esc(target)}" data-person-text="${esc(personSearchText(p))}"><input type="checkbox" value="${esc(p.id)}" ${set.has(p.id)?'checked':''}> ${esc(personCandidateDisplay(p))}</label>`).join('') || '<span class="muted">人物管理の登録はまだありません</span>';
    return `<div class="selected-person-chips" data-selected-person-chips="${esc(target)}"></div>${personCandidateSearchBox(target, {compact:true})}<div class="person-candidate-list compact-person-candidates" data-person-candidate-list="${esc(target)}">${boxes}</div>`;
  }
  function singleStaffFieldHTML(v, f) {
    const idName = f.idName || `${f.name}PersonId`;
    const selected = selectedSingleStaffId(v, idName, f.name);
    const manual = selected ? (findPersonByName(v[f.name]) ? '' : clean(v[f.name])) : clean(v[f.name]);
    return `<div class="field staff-field full"><span>${esc(f.label)}</span>${personCandidateSearchBox(idName, {compact:true, lazy:true})}<div class="staff-single">${lazyPersonSelectHTML(idName, selected)}<input name="${esc(f.name)}" value="${esc(manual)}" placeholder="人物管理にない場合だけ直接入力"></div><small>人物管理から選ぶと、経歴表示で種別・期別も併記します。</small></div>`;
  }
  function multiStaffFieldHTML(v, f) {
    const idName = f.idName || `${f.name}PersonIds`;
    const selected = selectedMultiStaffIds(v, idName, f.name);
    const manual = manualStaffText(v, f.name, selected);
    return `<div class="field staff-field full"><span>${esc(f.label)}</span>${personCandidateSearchBox(idName, {compact:true, lazy:true})}<div class="staff-checks">${lazyPersonCandidatesHTML(idName, selected, {inputName:idName})}</div><textarea name="${esc(f.name)}" placeholder="人物管理にない職員だけ1行1人で直接入力">${esc(manual)}</textarea><small>登録済み人物は候補から選べます。表示時は氏名に種別・期別を併記します。</small></div>`;
  }
  function selectedPeople(form) { return $$('[data-people] input:checked', form).map(x => x.value); }

  function foldEventRepeatFields(form, value) {
    const repeat = form?.elements?.repeat;
    const root = repeat?.closest?.('.form-grid');
    const anchor = repeat?.closest?.('.field');
    if (!root || !anchor) return;
    const names = ['repeatInterval','repeatUntil','repeatMonthlyMode','repeatDayOfMonth','repeatMissingDatePolicy','repeatNth','repeatWeekday','repeatBusinessDayShift','repeatBusinessDayTie'];
    const fields = names.map(name => form.elements?.[name]?.closest?.('.field')).filter(Boolean);
    if (!fields.length) return;
    const details = document.createElement('details');
    details.className = 'event-repeat-details';
    details.open = clean(value || repeat.value) !== 'none';
    const summary = document.createElement('summary');
    summary.innerHTML = '<span>繰り返しの詳細設定</span><span class="fold-count">必要なときだけ</span>';
    const grid = document.createElement('div');
    grid.className = 'form-grid event-repeat-grid';
    fields.forEach(field => grid.appendChild(field));
    details.append(summary, grid);
    anchor.after(details);
    repeat.addEventListener('change', () => { if (repeat.value !== 'none') details.open = true; });
  }

  function clockMinutes(value) {
    const match = clean(value).match(/^(\d{1,2}):(\d{2})$/);
    if (!match) return null;
    const minutes = Number(match[1]) * 60 + Number(match[2]);
    return minutes >= 0 && minutes < 24 * 60 ? minutes : null;
  }
  function clockValue(minutes) {
    const value = ((Number(minutes) % (24 * 60)) + (24 * 60)) % (24 * 60);
    return `${String(Math.floor(value / 60)).padStart(2,'0')}:${String(value % 60).padStart(2,'0')}`;
  }
  function eventDuration(start, end, fallback = 0) {
    const startMinutes = clockMinutes(start); const endMinutes = clockMinutes(end);
    if (startMinutes === null || endMinutes === null) return Math.max(0, Math.min(24 * 60, Number(fallback) || 0));
    const delta = (endMinutes - startMinutes + 24 * 60) % (24 * 60);
    return delta === 0 && Number(fallback) >= 24 * 60 ? 24 * 60 : delta;
  }
  function bindEventTimeFields(form) {
    const start = form?.elements?.time; const end = form?.elements?.endTime; const duration = form?.elements?.durationMinutes;
    if (!start || !end || !duration) return;
    const updateEnd = () => {
      const startMinutes = clockMinutes(start.value); const minutes = Math.max(0, Math.min(24 * 60, Math.round(Number(duration.value) || 0)));
      if (startMinutes !== null && minutes > 0) end.value = clockValue(startMinutes + minutes);
    };
    const updateDuration = () => {
      if (clockMinutes(start.value) === null || clockMinutes(end.value) === null) return;
      duration.value = String(eventDuration(start.value, end.value, duration.value));
    };
    start.addEventListener('change', () => { if (end.value) updateDuration(); else updateEnd(); });
    duration.addEventListener('input', updateEnd);
    end.addEventListener('change', updateDuration);
  }

  function openEventModal(item = {}) {
    const isNew = !item.id;
    const v = Object.assign({id:uid('ev'), title:'', calendarKind:'schedule', date:today(), time:'', endTime:'', durationMinutes:0, place:'', repeat:'none', repeatUntil:'', repeatInterval:1, repeatMonthlyMode:'dayOfMonth', repeatDayOfMonth:'', repeatMissingDatePolicy:'skip', repeatNth:'1', repeatWeekday:'', repeatBusinessDayShift:'none', repeatBusinessDayTie:'previous', caseId:'', personIds:[], peopleText:'', note:''}, eventBaseRecord(item || {}));
    if (!v.repeatDayOfMonth && v.date) v.repeatDayOfMonth = Number(v.date.slice(8,10)) || '';
    if (v.repeatWeekday === '' && v.date) { const d = dateObj(v.date); v.repeatWeekday = d ? String(d.getDay()) : ''; }
    ['_ds','_baseDate','_shifted','_kind'].forEach(k => { if (k in v) delete v[k]; });
    v.calendarKind = calendarKind(v);
    const fields = [
      {name:'title', label:'名称', full:true}, {name:'calendarKind', label:'種別', type:'select', options:[['schedule','予定'],['happening','出来事']]},
      {name:'date', label:'日付', type:'date', presets:datePresets()}, {name:'time', label:'開始', type:'time', presets:timePresets()}, {name:'endTime', label:'終了', type:'time', presets:timePresets()}, {name:'durationMinutes', label:'所要（分）', type:'number', presets:durationPresets(), hint:'予定の終了時刻補完と今日の流れに使います。'}, {name:'place', label:'場所'},
      {name:'repeat', label:'繰り返し', type:'select', options:[['none','なし'],['daily','毎日'],['weekly','毎週'],['monthly','毎月'],['yearly','毎年']]}, {name:'repeatInterval', label:'間隔', type:'number'}, {name:'repeatUntil', label:'繰り返し終了', type:'date', presets:datePresets()},
      {name:'repeatMonthlyMode', label:'毎月の扱い', type:'select', options:[['dayOfMonth','指定日'],['endOfMonth','月末'],['lastBusinessDay','最終平日'],['nthWeekday','第N曜日']]},
      {name:'repeatDayOfMonth', label:'指定日', type:'number'}, {name:'repeatMissingDatePolicy', label:'存在しない日付', type:'select', options:[['skip','スキップ'],['lastDay','月末に寄せる'],['previousBusiness','前の平日'],['nextBusiness','後ろの平日']]},
      {name:'repeatNth', label:'第N', type:'select', options:[['1','第1'],['2','第2'],['3','第3'],['4','第4'],['5','第5'],['last','最終']]}, {name:'repeatWeekday', label:'曜日', type:'select', options:[['0','日曜'],['1','月曜'],['2','火曜'],['3','水曜'],['4','木曜'],['5','金曜'],['6','土曜']]},
      {name:'repeatBusinessDayShift', label:'土日祝日の調整', type:'select', options:[['none','調整しない'],['previous','前の平日へ'],['next','後ろの平日へ'],['nearest','一番近い平日へ']]},
      {name:'repeatBusinessDayTie', label:'前後同距離のとき', type:'select', options:[['previous','前にずらす'],['next','後ろにずらす']]},
      {name:'caseId', label:'事案', type:'select', options:[['','なし'], ...DATA.cases.map(c=>[c.id,c.title||c.name])]}, {name:'personIds', label:'関係者', type:'people', value:v.personIds}, {name:'peopleText', label:'直接入力の関係者', full:true}, {name:'note', label:'メモ', type:'textarea', full:true}
    ];
    const opened = openModal(isNew?'予定・出来事を追加':'予定・出来事を編集', formBase(v, fields, !isNew), async(fd, form) => {
      const kind = fd.get('calendarKind') === 'happening' ? 'happening' : 'schedule';
      const eventDate = fd.get('date') || today();
      const repeat = fd.get('repeat') || 'none';
      const repeatUntil = fd.get('repeatUntil') || '';
      if (repeat !== 'none' && repeatUntil && repeatUntil < eventDate) {
        toast('繰り返し終了日は、開始日以降の日付を指定してください');
        form.elements?.repeatUntil?.focus();
        return false;
      }
      const startTime = fd.get('time') || ''; let endTime = fd.get('endTime') || '';
      let durationMinutes = Math.max(0, Math.min(24 * 60, Math.round(Number(fd.get('durationMinutes') || 0) || 0)));
      if (startTime && endTime) durationMinutes = eventDuration(startTime, endTime, durationMinutes);
      else if (startTime && durationMinutes) endTime = clockValue(clockMinutes(startTime) + durationMinutes);
      const obj = {...v, calendarKind:kind, title:clean(fd.get('title')) || (kind === 'happening' ? '無題の出来事' : '無題の予定'), date:eventDate, time:startTime, endTime, durationMinutes, place:clean(fd.get('place')), repeat, repeatInterval:Math.max(1, Number(fd.get('repeatInterval') || 1) || 1), repeatUntil, repeatMonthlyMode:fd.get('repeatMonthlyMode') || 'dayOfMonth', repeatDayOfMonth:Math.max(1, Math.min(31, Number(fd.get('repeatDayOfMonth') || 1) || 1)), repeatMissingDatePolicy:fd.get('repeatMissingDatePolicy') || 'skip', repeatNth:fd.get('repeatNth') || '1', repeatWeekday:fd.get('repeatWeekday') || '0', repeatBusinessDayShift:fd.get('repeatBusinessDayShift') || 'none', repeatBusinessDayTie:fd.get('repeatBusinessDayTie') || 'previous', caseId:fd.get('caseId') || '', personIds:selectedPeople(form), peopleText:clean(fd.get('peopleText')), note:String(fd.get('note') || ''), updatedAt:new Date().toISOString()};
      ['_ds','_baseDate','_shifted','_kind'].forEach(k => { if (k in obj) delete obj[k]; });
      await saveSpeculumItem('events', obj, v.updatedAt || ''); renderAll();
    }, async()=>{
      if (preventLinkedSourceDeletion('events', v, calendarKind(v) === 'happening' ? '出来事' : '予定')) return false;
      await deleteSpeculumItemWithUndo('events', v, '予定・出来事を削除しました');
    });
    if (!opened) return;
    foldEventRepeatFields($('modalForm'), v.repeat);
    bindEventTimeFields($('modalForm'));
  }
  function openDueModal(collection, item = {}) {
    const isNew = !item.id; const label = collection === 'jimu' ? '事務' : '期限';
    const v = Object.assign({id:uid(collection==='jimu'?'jm':'dl'), title:'', name:'', due:today(), priority:'normal', status:'open', caseId:'', personIds:[], nextAction:'', note:''}, item || {});
    const fields = [
      {name:'title', label:`${label}名`, full:true, value:v.title || v.name}, {name:'due', label:'期日', type:'date', presets:datePresets(), hint:'台帳に残し、処理が必要になったものだけ作業に追加します。'}, {name:'priority', label:'優先度', type:'select', options:[['normal','通常'],['high','高優先'],['low','低優先']], presets:priorityPresets()}, {name:'status', label:'状態', type:'select', options:[['open','未完了'],['done','完了']], presets:[['open','未完了'],['done','完了']]},
      {name:'caseId', label:'事案', type:'select', options:[['','なし'], ...DATA.cases.map(c=>[c.id,c.title||c.name])]}, {name:'personIds', label:'関係者', type:'people', value:v.personIds}, {name:'peopleText', label:'直接入力の関係者', full:true}, {name:'nextAction', label:'次の一手', full:true}, {name:'note', label:'メモ', type:'textarea', full:true}
    ];
    openModal(isNew?`${label}を追加`:`${label}を編集`, formBase(v, fields, !isNew), async(fd, form) => {
      const title = clean(fd.get('title')) || `無題の${label}`;
      const obj = {...v, title, name:title, due:fd.get('due') || today(), priority:fd.get('priority') || 'normal', status:fd.get('status') || 'open', done:fd.get('status') === 'done', caseId:fd.get('caseId') || '', personIds:selectedPeople(form), peopleText:clean(fd.get('peopleText')), nextAction:clean(fd.get('nextAction')), note:String(fd.get('note') || ''), updatedAt:new Date().toISOString()};
      await saveSpeculumItem(collection, obj, v.updatedAt || ''); renderAll();
    }, async()=>{
      if (preventLinkedSourceDeletion(collection, v, label)) return false;
      await deleteSpeculumItemWithUndo(collection, v, `${label}を削除しました`);
    });
  }
  function openCaseModal(item = {}) {
    const isNew = !item.id;
    const v = Object.assign({id:uid('ca'), title:'', status:'事案交付', priority:'normal', startedAt:'', nextDate:'', owner:'', nextAction:'', targetPersons:[], note:''}, item || {});
    v.status = normalizeCaseStatus(v.status);
    const fields = [
      {name:'title', label:'事案名', full:true},
      {name:'status', label:'進行状態', type:'select', options:CASE_STATUSES.map(x=>[x,x])},
      {name:'startedAt', label:'最初の着手日', type:'date', presets:datePresets()},
      {name:'nextDate', label:'次回予定日', type:'date', presets:datePresets(), hint:'次回予定なしの見落とし防止に使います。'},
      {name:'owner', label:'担当'},
      {name:'priority', label:'優先度', type:'select', options:[['normal','通常'],['high','高優先'],['low','低優先']], presets:priorityPresets()},
      {name:'nextAction', label:'次の一手', full:true},
      {name:'targetText', label:'調査対象者（1行1人）', type:'textarea', full:true, value:caseTargetText(v), hint:'氏名、区分、進行状態、着手日、次回予定、次の一手、メモの順です。空欄も「、、」で位置を残します。'},
      {name:'note', label:'調査メモ', type:'textarea', full:true}
    ];
    openModal(isNew?'事案を追加':'事案を編集', formBase(v, fields, !isNew), async(fd) => {
      const title = clean(fd.get('title')) || '無題の事案';
      const status = normalizeCaseStatus(fd.get('status'));
      let startedAt = fd.get('startedAt') || '';
      if (CASE_STARTED.has(status) && !startedAt) startedAt = today();
      const targets = parseCaseTargetText(fd.get('targetText'), caseTargets(v), {status, startedAt, nextDate:fd.get('nextDate') || '', owner:clean(fd.get('owner')), priority:clean(fd.get('priority')) || 'normal', nextAction:clean(fd.get('nextAction'))});
      const obj = {...v, title, name:title, status, startedAt, nextDate:fd.get('nextDate') || '', owner:clean(fd.get('owner')), priority:clean(fd.get('priority')) || 'normal', nextAction:clean(fd.get('nextAction')), targetPersons:targets, client:targets.map(x=>x.name).join('、'), personIds:[], note:String(fd.get('note') || ''), updatedAt:new Date().toISOString()};
      await saveSpeculumItem('cases', obj, v.updatedAt || ''); renderAll();
    }, async()=>{
      if (preventReferencedCaseDeletion(v)) return false;
      await deleteSpeculumItemWithUndo('cases', v, '事案を削除しました');
    });
  }
  function openPersonModal(item = {}) {
    const isNew = !item.id; const v = Object.assign({id:uid('pe'), name:'', kind:'', term:'', displayOrder:'', org:'', role:'', tel:'', email:'', tags:'', retired:false, retiredAt:'', note:''}, item || {});
    const fields = [{name:'name',label:'氏名',full:true},{name:'kind',label:'種別'},{name:'term',label:'期別'},{name:'org',label:'所属'},{name:'role',label:'役割'},{name:'retiredAt',label:'退職日',type:'date',hint:'入力すると退職者として管理し、通常の人物一覧から外します。空欄へ戻すと在職者になります。'},{name:'tel',label:'電話'},{name:'email',label:'メール',type:'email'},{name:'tags',label:'タグ',full:true},{name:'note',label:'出来事・メモ',type:'textarea',full:true},{name:'displayOrder',label:'手動の表示順',full:true,hint:'通常は空欄のままで、種別・期別による自動順を使います。'}];
    const manualOrder = personManualOrder(v);
    const automaticOrder = personEquivalentCohort(v);
    const helpText = manualOrder !== null
      ? `現在は手動の表示順「${formatSortNumber(manualOrder)}」を使っています。空欄に戻すと、種別・期別による自動順になります。`
      : automaticOrder !== null
        ? `${personSortMeta(v)}で自動的に並べます。必要な人だけ手動の表示順を指定できます。`
        : '種別・期別を入力すると同期相当の順に自動で並びます。必要な人だけ手動の表示順を指定できます。';
    const help = `<p class="modal-note">${esc(helpText)} 専科は期別に29を加えて普通科相当に換算します。</p>`;
    openModal(isNew?'人物を追加':'人物を編集', help + formBase(v, fields, !isNew), async(fd) => {
      const retiredAt = clean(fd.get('retiredAt'));
      const obj = {...v, name:clean(fd.get('name')) || '無名の人物', kind:clean(fd.get('kind')), term:clean(fd.get('term')), displayOrder:clean(fd.get('displayOrder')), org:clean(fd.get('org')), role:clean(fd.get('role')), tel:clean(fd.get('tel')), email:clean(fd.get('email')), tags:clean(fd.get('tags')), retired:!!retiredAt, retiredAt, note:String(fd.get('note') || ''), updatedAt:new Date().toISOString()};
      await saveSpeculumItem('people', obj, v.updatedAt || ''); renderAll();
    }, async()=>{
      if (preventReferencedPersonDeletion(v)) return false;
      await deleteSpeculumItemWithUndo('people', v, '人物を削除しました');
    });
  }

  function careerDepartmentFieldKey(id) {
    return clean(id).replace(/[^A-Za-z0-9_-]/g, '_') || uid('department');
  }
  function careerDepartmentCardHTML(department, index, open = false) {
    const d = department && typeof department === 'object' ? department : {};
    const id = clean(d.id) || uid('department');
    const key = careerDepartmentFieldKey(id);
    const managerIdName = `careerDepartmentManagerPersonId_${key}`;
    const managerTextName = `careerDepartmentManager_${key}`;
    const staffIdsName = `careerDepartmentStaffPersonIds_${key}`;
    const staffTextName = `careerDepartmentStaff_${key}`;
    const selectedManager = selectedSingleStaffId(d, 'managerPersonId', 'manager');
    const manualManager = selectedManager ? (findPersonByName(d.manager) ? '' : clean(d.manager)) : clean(d.manager);
    const selectedStaff = selectedMultiStaffIds(d, 'staffPersonIds', 'staff');
    const manualStaff = manualStaffText(d, 'staff', selectedStaff);
    const cardLabel = index === 0 ? '今の部門' : `追加部門 ${index}`;
    return `<details class="career-department-card" data-career-department data-department-id="${esc(id)}" data-manager-id-name="${esc(managerIdName)}" data-manager-text-name="${esc(managerTextName)}" data-staff-ids-name="${esc(staffIdsName)}" data-staff-text-name="${esc(staffTextName)}" ${open?'open':''}>
      <summary><span><b data-department-summary-title>${esc(cardLabel)}</b><small data-department-summary-meta>部門名を入力してください</small></span><span class="fold-count">編集</span></summary>
      <div class="career-department-body">
        <input type="hidden" name="careerDepartmentId" value="${esc(id)}">
        <label class="field full"><span>部門名</span><input name="careerDepartmentName_${esc(key)}" data-department-name value="${esc(d.name)}" placeholder="例：資産課税部門"><small class="field-hint">今の部門も追加した部門も、名称を自由に入力・訂正できます。</small></label>
        <div class="field staff-field full"><span>責任者</span>${personCandidateSearchBox(managerIdName, {compact:true, lazy:true})}<div class="staff-single">${lazyPersonSelectHTML(managerIdName, selectedManager, {departmentManager:true})}<input name="${esc(managerTextName)}" data-department-manager-text value="${esc(manualManager)}" placeholder="人物管理にない場合だけ直接入力"></div><small>人物管理から選ぶか、未登録の責任者名を直接入力できます。</small></div>
        <div class="field staff-field full"><span>所属職員（何人でも）</span>${personCandidateSearchBox(staffIdsName, {compact:true, lazy:true})}<div class="staff-checks">${lazyPersonCandidatesHTML(staffIdsName, selectedStaff, {inputName:staffIdsName, departmentStaff:true})}</div><textarea name="${esc(staffTextName)}" data-department-staff-text placeholder="人物管理にない職員だけ1行1人で直接入力">${esc(manualStaff)}</textarea><small>この部門に所属する職員を選択します。追加部門ごとに別々に登録できます。</small></div>
        <div class="career-department-actions"><div>${index === 0 ? '<span class="current-department-note">今の部門は削除できません</span>' : '<button type="button" class="ghost danger-soft" data-remove-career-department>この部門を削除</button>'}</div><div>${index === 0 ? '' : '<button type="button" class="ghost" data-move-career-department="up">上へ</button><button type="button" class="ghost" data-move-career-department="down">下へ</button>'}</div></div>
      </div>
    </details>`;
  }
  function careerDepartmentsEditorHTML(v) {
    const departments = careerDepartments(v);
    return `<div class="career-departments-editor full" data-career-departments><div class="career-departments-head"><div><b>部門</b><small>先頭が今の部門です。必要な数だけ部門を追加できます。</small></div><span class="department-count" data-department-count>${departments.length}部門</span></div><div class="career-departments-list" data-career-departments-list>${departments.map((department,index) => careerDepartmentCardHTML(department,index,index===0)).join('')}</div><button type="button" class="department-add-button" data-add-career-department>＋ 部門を追加</button></div>`;
  }
  function refreshCareerDepartmentCards(root) {
    const cards = $$('[data-career-department]', root);
    cards.forEach((card,index) => {
      card.dataset.departmentIndex = String(index);
      const name = clean(card.querySelector('[data-department-name]')?.value);
      const title = card.querySelector('[data-department-summary-title]');
      const meta = card.querySelector('[data-department-summary-meta]');
      if (title) title.textContent = `${index === 0 ? '今の部門' : `追加部門 ${index}`}：${name || '部門名未入力'}`;
      const managerSelect = card.querySelector('[data-department-manager-id]');
      const managerText = clean(card.querySelector('[data-department-manager-text]')?.value);
      const selectedManager = clean(managerSelect?.value) ? clean(managerSelect?.selectedOptions?.[0]?.textContent?.split(' / ')[0]) : '';
      const manager = selectedManager || managerText;
      const selectedStaff = $$('[data-department-staff-id]:checked', card).length;
      const manualStaff = splitStaffLines(card.querySelector('[data-department-staff-text]')?.value).length;
      if (meta) meta.textContent = `責任者：${manager || '未入力'}・職員${selectedStaff + manualStaff}人`;
      const remove = card.querySelector('[data-remove-career-department]');
      if (remove) remove.hidden = index === 0;
      const up = card.querySelector('[data-move-career-department="up"]');
      const down = card.querySelector('[data-move-career-department="down"]');
      if (up) up.disabled = index <= 1;
      if (down) down.disabled = index >= cards.length - 1;
    });
    const count = root.querySelector('[data-department-count]');
    if (count) count.textContent = `${cards.length}部門`;
    const sectionCount = root.closest('[data-career-section="people"]')?.querySelector(':scope > summary .fold-count');
    if (sectionCount) sectionCount.textContent = `${cards.length}部門`;
  }
  function bindNewCareerDepartmentCard(card) {
    card.querySelectorAll('input,textarea,select').forEach(input => {
      input.addEventListener('input', () => { if (!input.matches('[data-person-candidate-search]')) dirtyModal = true; });
      input.addEventListener('change', () => { if (!input.matches('[data-person-candidate-search]')) dirtyModal = true; });
    });
    bindPersonCandidateSearch(card);
  }
  function bindCareerDepartmentsEditor(form) {
    const root = form.querySelector('[data-career-departments]');
    const list = root?.querySelector('[data-career-departments-list]');
    if (!root || !list) return;
    const refresh = () => refreshCareerDepartmentCards(root);
    root.addEventListener('input', event => {
      const manual = event.target.closest?.('[data-department-manager-text]');
      if (manual && clean(manual.value)) {
        const select = manual.closest('[data-career-department]')?.querySelector('[data-department-manager-id]');
        if (select) { select.value = ''; select.dataset.selectedPersonId = ''; }
      }
      refresh();
    });
    root.addEventListener('change', event => {
      const select = event.target.closest?.('[data-department-manager-id]');
      if (select && clean(select.value)) {
        const manual = select.closest('[data-career-department]')?.querySelector('[data-department-manager-text]');
        if (manual) manual.value = '';
      }
      refresh();
    });
    root.querySelector('[data-add-career-department]')?.addEventListener('click', () => {
      const index = $$('[data-career-department]', list).length;
      list.insertAdjacentHTML('beforeend', careerDepartmentCardHTML({id:uid('department'),kind:'additional',name:'',manager:'',managerPersonId:'',staff:[],staffPersonIds:[]}, index, true));
      const card = list.lastElementChild;
      if (card) { bindNewCareerDepartmentCard(card); refresh(); dirtyModal = true; card.querySelector('[data-department-name]')?.focus(); card.scrollIntoView({block:'center',behavior:'smooth'}); }
    });
    root.addEventListener('click', async event => {
      const remove = event.target.closest?.('[data-remove-career-department]');
      if (remove) {
        const card = remove.closest('[data-career-department]');
        if (!card || Number(card.dataset.departmentIndex) === 0) return;
        const name = clean(card.querySelector('[data-department-name]')?.value) || 'この追加部門';
        const hasPeople = !!(clean(card.querySelector('[data-department-manager-text]')?.value) || clean(card.querySelector('[data-department-manager-id]')?.value) || card.querySelector('[data-department-staff-id]:checked') || splitStaffLines(card.querySelector('[data-department-staff-text]')?.value).length);
        if (hasPeople && !await askConfirm('追加部門を削除しますか？', `「${name}」の責任者と所属職員の登録も削除します。`, '削除する')) return;
        card.remove(); dirtyModal = true; refresh();
        return;
      }
      const move = event.target.closest?.('[data-move-career-department]');
      if (!move || move.disabled) return;
      const card = move.closest('[data-career-department]');
      const direction = move.dataset.moveCareerDepartment;
      const sibling = direction === 'up' ? card?.previousElementSibling : card?.nextElementSibling;
      if (!card || !sibling || (direction === 'up' && Number(card.dataset.departmentIndex) <= 1)) return;
      if (direction === 'up') list.insertBefore(card, sibling); else list.insertBefore(sibling, card);
      dirtyModal = true; refresh(); card.open = true; card.scrollIntoView({block:'nearest'});
    });
    refresh();
  }
  function readCareerDepartments(form) {
    return $$('[data-career-department]', form).map((card,index) => {
      const id = clean(card.querySelector('input[name="careerDepartmentId"]')?.value) || uid('department');
      const name = clean(card.querySelector('[data-department-name]')?.value);
      let managerPersonId = clean(card.querySelector('[data-department-manager-id]')?.value);
      const managerText = clean(card.querySelector('[data-department-manager-text]')?.value);
      if (!managerPersonId) managerPersonId = clean(findPersonByName(managerText)?.id);
      const staff = splitStaffLines(card.querySelector('[data-department-staff-text]')?.value);
      const staffPersonIds = uniqueIds([
        ...$$('[data-department-staff-id]:checked', card).map(input => input.value),
        ...staff.map(nameValue => findPersonByName(nameValue)?.id).filter(Boolean)
      ]);
      return {id,kind:index===0?'current':'additional',name,manager:managerPersonId ? personName(managerPersonId) : managerText,managerPersonId,staff,staffPersonIds};
    });
  }

  const CAREER_FORM_GROUPS = [
    {id:'basic', title:'基本情報', hint:'年度・所属・職務', names:['fiscalYear','office','section','position']},
    {id:'people', title:'部門・職員', hint:'部門名・責任者・所属者', names:['departments','reviewOfficer']},
    {id:'evaluation', title:'出来事・評価・給与', hint:'出来事・評価・手当・収入', names:['myEvents','othersEvents','abilityEval','performanceEvalAprSep','performanceEvalOctMar','bonusUpper','raiseCategory','bonusLower','annualIncome','income','withholdingIncomeTax']},
    {id:'goals', title:'目標・自己評価', hint:'人事目標と自己評価', names:['hrGoal1','hrGoal2','hrGoal3','selfEval1','selfEval2','selfEval3']}
  ];
  function careerFormBase(v, fields, del = false, focusField = '') {
    const byName = new Map(fields.map(field => [field.name, field]));
    const sections = CAREER_FORM_GROUPS.map((group, index) => {
      const groupFields = group.names.map(name => byName.get(name)).filter(Boolean);
      const filled = group.names.filter(name => {
        const value = v?.[name];
        return Array.isArray(value) ? value.length : !!clean(value);
      }).length;
      const open = index === 0 || group.names.includes(focusField);
      const status = group.id === 'people' ? `${careerDepartments(v).length}部門` : (filled ? `${filled}項目入力済み` : '未入力');
      return `<details class="career-editor-section" data-career-section="${esc(group.id)}" ${open?'open':''}><summary><span><b>${esc(group.title)}</b><small>${esc(group.hint)}</small></span><span class="fold-count">${status}</span></summary><div class="form-grid career-section-grid">${groupFields.map(field => field.type === 'careerDepartments' ? careerDepartmentsEditorHTML(v) : fieldHTML(v, field)).join('')}</div></details>`;
    }).join('');
    return `<div class="career-editor-sections">${sections}<div class="modal-actions"><div>${del?'<button type="button" class="ghost" data-delete>この年度を削除</button>':''}</div><div><button type="button" class="ghost" data-cancel>閉じる</button><button type="submit" class="primary">保存</button></div></div></div>`;
  }
  function openCareerModal(item = {}, requestedFocus = '') {
    const isNew = !item.id;
    const v = Object.assign({
      id:uid('cr'), fiscalYear:suggestNextFiscalYear(), order:nextCareerOrder(), office:'', division:'', section:'', position:'', manager:'', reviewOfficer:'',
      departmentStaff:[], relatedStaff:[], myEvents:'', othersEvents:'', abilityEval:'', performanceEvalAprSep:'', performanceEvalOctMar:'',
      bonusUpper:'', raiseCategory:'', bonusLower:'', annualIncome:'', income:'', withholdingIncomeTax:'',
      hrGoal1:'', hrGoal2:'', hrGoal3:'', selfEval1:'', selfEval2:'', selfEval3:''
    }, item || {});
    if (isNew) v.order = nextCareerOrder();
    v.departments = careerDepartments(isNew && !arr(item?.departments).length ? Object.assign({}, v, {departments:[{id:`${v.id}_department_1`,kind:'current',name:'',manager:'',managerPersonId:'',staff:[],staffPersonIds:[]}]}) : v);
    const fields = [
      {name:'fiscalYear', label:'事務年度', full:true, value:v.fiscalYear},
      {name:'office', label:'所属署', value:v.office},
      {name:'section', label:'係（担当）', value:v.section},
      {name:'position', label:'職名又は職務内容', full:true, value:v.position},
      {name:'departments', label:'部門', type:'careerDepartments', full:true, value:v.departments},
      {name:'reviewOfficer', label:'審理専門官', type:'personSingle', idName:'reviewOfficerPersonId', value:v.reviewOfficer},
      {name:'myEvents', label:'自分の出来事', type:'textarea', full:true, value:v.myEvents || v.note || ''},
      {name:'othersEvents', label:'他者の出来事', type:'textarea', full:true, value:v.othersEvents},
      {name:'abilityEval', label:'能力評価（10月〜9月）', value:v.abilityEval},
      {name:'performanceEvalAprSep', label:'業績評価（4月〜9月）', value:v.performanceEvalAprSep},
      {name:'performanceEvalOctMar', label:'業績評価（10月〜3月）', value:v.performanceEvalOctMar},
      {name:'bonusUpper', label:'勤勉手当（上期）', value:v.bonusUpper},
      {name:'raiseCategory', label:'昇給区分', value:v.raiseCategory},
      {name:'bonusLower', label:'勤勉手当（下期）', value:v.bonusLower},
      {name:'annualIncome', label:'収入', value:formatMoneyText(v.annualIncome)},
      {name:'income', label:'所得', value:formatMoneyText(v.income)},
      {name:'withholdingIncomeTax', label:'源泉所得税額', value:formatMoneyText(v.withholdingIncomeTax)},
      {name:'hrGoal1', label:'人事目標1', type:'textarea', full:true, value:v.hrGoal1},
      {name:'hrGoal2', label:'人事目標2', type:'textarea', full:true, value:v.hrGoal2},
      {name:'hrGoal3', label:'人事目標3', type:'textarea', full:true, value:v.hrGoal3},
      {name:'selfEval1', label:'自己評価1', type:'textarea', full:true, value:v.selfEval1},
      {name:'selfEval2', label:'自己評価2', type:'textarea', full:true, value:v.selfEval2},
      {name:'selfEval3', label:'自己評価3', type:'textarea', full:true, value:v.selfEval3}
    ];
    const help = `<p class="modal-note">事務年度ごとに経歴を登録します。今の部門を先頭に置き、他の部門がある場合は「部門を追加」から増やしてください。部門名・責任者・所属職員は部門ごとに登録できます。</p>`;
    const departmentFocusKeys = new Set(['division','manager','departmentStaff','relatedStaff','departments','departmentManagers','departmentStaffs']);
    const mappedFocus = departmentFocusKeys.has(requestedFocus) ? 'departments' : requestedFocus;
    const focusField = fields.some(field => field.name === mappedFocus) ? mappedFocus : (requestedFocus === 'experienceYears' ? 'fiscalYear' : '');
    const opened = openModal(isNew?'事務年度を追加':'事務年度を編集', help + careerFormBase(v, fields, !isNew, focusField), async(fd, form) => {
      const singleId = (name, textName) => {
        const picked = clean(fd.get(name));
        if (picked && personById(picked)) return picked;
        const matched = findPersonByName(fd.get(textName));
        return matched ? matched.id : '';
      };
      const reviewOfficerPersonId = singleId('reviewOfficerPersonId', 'reviewOfficer');
      const departments = readCareerDepartments(form);
      const currentDepartment = departments[0];
      const additionalDepartments = departments.slice(1);
      const linkedPersonIds = uniqueIds([reviewOfficerPersonId, ...departments.flatMap(department => [department.managerPersonId, ...department.staffPersonIds])]);
      const obj = {
        ...v,
        fiscalYear:clean(fd.get('fiscalYear')) || '年度未入力',
        order:Number(v.order) || nextCareerOrder(),
        title:clean(fd.get('fiscalYear')) || '年度未入力',
        office:clean(fd.get('office')),
        departments,
        division:clean(currentDepartment?.name),
        section:clean(fd.get('section')),
        position:clean(fd.get('position')),
        manager:clean(currentDepartment?.manager),
        managerPersonId:clean(currentDepartment?.managerPersonId),
        reviewOfficer:clean(fd.get('reviewOfficer')) || personName(reviewOfficerPersonId),
        reviewOfficerPersonId,
        departmentStaff:arr(currentDepartment?.staff),
        departmentStaffPersonIds:uniqueIds(currentDepartment?.staffPersonIds),
        relatedDepartmentName:clean(additionalDepartments[0]?.name),
        relatedDepartment:clean(additionalDepartments[0]?.name),
        relatedManager:clean(additionalDepartments[0]?.manager),
        relatedManagerPersonId:clean(additionalDepartments[0]?.managerPersonId),
        relatedStaff:additionalDepartments.flatMap(department => arr(department.staff)),
        relatedStaffPersonIds:uniqueIds(additionalDepartments.flatMap(department => arr(department.staffPersonIds))),
        myEvents:String(fd.get('myEvents') || ''),
        othersEvents:String(fd.get('othersEvents') || ''),
        abilityEval:clean(fd.get('abilityEval')),
        performanceEvalAprSep:clean(fd.get('performanceEvalAprSep')),
        performanceEvalOctMar:clean(fd.get('performanceEvalOctMar')),
        bonusUpper:clean(fd.get('bonusUpper')),
        raiseCategory:clean(fd.get('raiseCategory')),
        bonusLower:clean(fd.get('bonusLower')),
        annualIncome:moneyPlain(fd.get('annualIncome')),
        income:moneyPlain(fd.get('income')),
        withholdingIncomeTax:moneyPlain(fd.get('withholdingIncomeTax')),
        hrGoal1:String(fd.get('hrGoal1') || ''),
        hrGoal2:String(fd.get('hrGoal2') || ''),
        hrGoal3:String(fd.get('hrGoal3') || ''),
        selfEval1:String(fd.get('selfEval1') || ''),
        selfEval2:String(fd.get('selfEval2') || ''),
        selfEval3:String(fd.get('selfEval3') || ''),
        note:String(fd.get('myEvents') || ''),
        personIds:linkedPersonIds,
        caseId:'',
        updatedAt:new Date().toISOString()
      };
      await saveSpeculumItem('career', obj, v.updatedAt || ''); renderAll();
    }, async()=>{ await deleteSpeculumItemWithUndo('career', v, '経歴を削除しました'); }, {itemLabel:clean(v.fiscalYear) ? `${clean(v.fiscalYear)}年度の経歴` : 'この年度の経歴'});
    if (!opened) return;
    bindCareerDepartmentsEditor($('modalForm'));
    if (focusField) setTimeout(() => {
      const form = $('modalForm');
      const control = focusField === 'departments' ? form?.querySelector('[data-department-name]') : form?.elements?.[focusField];
      const target = control instanceof RadioNodeList ? control[0] : control;
      target?.closest?.('.career-editor-section')?.setAttribute('open', '');
      target?.closest?.('[data-career-department]')?.setAttribute('open', '');
      target?.focus?.({preventScroll:true});
      target?.scrollIntoView?.({block:'center', behavior:'smooth'});
    }, 70);
  }
  function openTaskModal(item = {}) {
    const isNew = !item.id; const v = Object.assign({id:uid('wk'), title:'', status:'next', priority:'normal', due:'', estimateMinutes:0, nextAction:'', caseId:'', personIds:[], peopleText:'', note:'', source:''}, item || {});
    const fields = [{name:'title',label:'作業名',full:true},{name:'status',label:'表示する列',type:'select',options:[['today','今日やる'],['next','次に進める'],['waiting','待ち'],['done','完了']],presets:statusPresets()},{name:'priority',label:'優先度',type:'select',options:[['normal','通常'],['high','高優先'],['low','低優先']],presets:priorityPresets()},{name:'due',label:'期限',type:'date',presets:datePresets()},{name:'estimateMinutes',label:'見積（分）',type:'number',presets:durationPresets(),hint:'15 / 30 / 60 など。今日の負荷に反映します。'},{name:'caseId',label:'事案',type:'select',options:[['','なし'],...DATA.cases.map(c=>[c.id,c.title||c.name])]}, {name:'personIds',label:'関係者',type:'people',value:v.personIds},{name:'peopleText',label:'直接入力の関係者',full:true},{name:'nextAction',label:'次の一手',full:true},{name:'note',label:'メモ',type:'textarea',full:true}];
    openModal(isNew?'作業を追加':'作業を編集', formBase(v, fields, !isNew), async(fd, form) => {
      const minutes = Math.max(0, Math.min(24 * 60, Math.round(Number(fd.get('estimateMinutes') || 0) || 0)));
      const obj = {...v, title:clean(fd.get('title')) || '無題の作業', status:fd.get('status') || 'next', priority:fd.get('priority') || 'normal', due:fd.get('due') || '', estimateMinutes:minutes, caseId:fd.get('caseId') || '', personIds:selectedPeople(form), peopleText:clean(fd.get('peopleText')), nextAction:clean(fd.get('nextAction')), note:String(fd.get('note') || ''), updatedAt:new Date().toISOString()};
      if (obj.status === 'done' && !obj.completedAt) obj.completedAt = today();
      if (obj.status !== 'done') delete obj.completedAt;
      await saveWorkTaskItem(obj, v.updatedAt || ''); renderAll(); toast('保存しました');
    }, async()=>{
      const snapshot = cloneRecord(v);
      const deleted = await deleteWorkTaskItems([v.id]); renderAll();
      const restoreToken = clean(deleted?.restoreTokens?.[v.id] || deleted?.restoreToken);
      toast('作業を削除しました', {actionLabel:'元に戻す', ms:8000, onAction:()=>restoreWorkTaskSnapshot(snapshot, '削除した作業を元に戻しました', restoreToken)});
    });
  }
  function upsert(collection, obj) { const i = DATA[collection].findIndex(x => x.id === obj.id); if (i >= 0) DATA[collection][i] = obj; else DATA[collection].push(obj); }
  function removeItem(collection, id) { DATA[collection] = DATA[collection].filter(x => x.id !== id); }

  async function openBackupModal() {
    const html = `<p class="modal-note">普段は自動保存します。手動で控えを作る、または過去の控えへ戻す時だけ使います。</p>
      <div class="form-grid">
        <label class="field"><span>対象</span><select id="backupApp"><option value="speculum">今日・日付確認</option><option value="continuum">作業管理</option></select></label>
        <div class="field"><span>操作</span><button type="button" class="primary" id="createBackupBtn">今の控えを作成</button></div>
        <div class="field full"><span>控え一覧</span><div class="backup-list" id="backupList"></div></div>
        <div class="modal-actions"><div></div><div><button type="button" class="ghost" data-cancel>閉じる</button></div></div>
      </div>`;
    if (!openModal('保存・復元', html, null, null, {noSubmit:true})) return;
    const fileSizeLabel = n => { const v=Math.max(0,Number(n)||0); return v>=1048576 ? `${(v/1048576).toFixed(1)} MB` : v>=1024 ? `${Math.round(v/1024)} KB` : `${Math.round(v)} B`; };
    let backupBusy = false;
    let refreshSequence = 0;
    const setBackupBusy = on => {
      backupBusy = !!on;
      const form = $('modalForm');
      form?.querySelectorAll('#backupApp,#createBackupBtn,.backup-row button').forEach(element => { element.disabled = backupBusy; });
      if (form) form.setAttribute('aria-busy', backupBusy ? 'true' : 'false');
    };
    const refresh = async () => {
      const sequence = ++refreshSequence;
      const app = clean($('backupApp')?.value || 'speculum');
      const box = $('backupList');
      if (!box) return false;
      box.setAttribute('aria-busy', 'true');
      if (!box.childElementCount) box.appendChild(emptyNode('控えを読み込んでいます…'));
      try {
        const j = await api(`/api/backups/list?app=${encodeURIComponent(app)}`);
        if (sequence !== refreshSequence || !$('backupList') || clean($('backupApp')?.value) !== app) return false;
        const list = arr(j.items);
        box.innerHTML = '';
        if (!list.length) { box.appendChild(emptyNode('控えはまだありません。')); return true; }
        list.forEach(b => {
          const row = document.createElement('div');
          row.className = 'backup-row';
          row.innerHTML = `<div><b>${esc(b.label || b.name)}</b><span>${esc(fileSizeLabel(b.size))}${b.source === 'sqlite' ? ' / 保存履歴' : ''}</span></div><button type="button" class="mini">復元</button>`;
          row.querySelector('button').onclick = async () => {
            if (backupBusy) return toast('保存・復元の処理中です');
            setBackupBusy(true);
            const confirmed = await askConfirm('控えを復元しますか？', '現在の状態を控えてから、この控えの内容へ戻します。', '復元する');
            if (!confirmed) { setBackupBusy(false); return; }
            let restored = false;
            try {
              if (app === 'speculum') await settleMemoBeforeRestore();
              await api('/api/backups/create', {method:'POST', body:JSON.stringify({app})});
              await api('/api/backups/restore', {method:'POST', body:JSON.stringify({app, name:b.name})});
              restored = true;
              if (app === 'speculum') resetMemoSaveAfterRestore();
              notifyDataChanged(app);
              closeModal(true);
              await loadData(); renderAll(); toast('復元しました');
            } catch (err) {
              toast(restored ? '復元は完了しましたが、画面を更新できませんでした。画面を開き直してください' : (err?.message || '復元できませんでした'));
            } finally {
              if (!$('modalBackdrop')?.hidden) setBackupBusy(false);
            }
          };
          box.appendChild(row);
        });
        setBackupBusy(backupBusy);
        return true;
      } catch (err) {
        if (sequence === refreshSequence && $('backupList')) {
          box.innerHTML = '';
          box.appendChild(emptyNode('控え一覧を読み込めませんでした。対象を切り替えるか、もう一度開いてください。'));
          toast(err?.message || '控え一覧を読み込めませんでした');
        }
        return false;
      } finally {
        if (sequence === refreshSequence && $('backupList')) box.removeAttribute('aria-busy');
      }
    };
    $('backupApp').addEventListener('change', refresh);
    $('createBackupBtn').addEventListener('click', async () => {
      if (backupBusy) return toast('保存・復元の処理中です');
      setBackupBusy(true);
      try {
        await api('/api/backups/create', {method:'POST', body:JSON.stringify({app:$('backupApp')?.value || 'speculum'})});
        toast('控えを作成しました');
        await refresh();
      } catch (err) {
        toast(err?.message || '控えを作成できませんでした');
      } finally {
        setBackupBusy(false);
      }
    });
    await refresh();
  }

  function canonicalPersonName(value) { return clean(value).replace(/[\s　]+/g, '').toLowerCase(); }
  function bulkPersonTermKey(value) {
    const n = personTermNumber({term:clean(value)});
    return n === null ? clean(value).toLowerCase() : `#${n}`;
  }
  function bulkPersonNames(value) {
    const seen = new Set();
    const names = [];
    String(value || '').split(/[\r\n\t,，、;；]+/).map(clean).filter(Boolean).forEach(name => {
      const key = canonicalPersonName(name);
      if (!key || seen.has(key)) return;
      seen.add(key); names.push(name);
    });
    return names;
  }
  function bulkPersonNameIndex() {
    const index = new Map();
    DATA.people.forEach(person => {
      const key = canonicalPersonName(person?.name);
      if (!key) return;
      if (!index.has(key)) index.set(key, []);
      index.get(key).push(person);
    });
    return index;
  }
  function bulkPersonPlan(name, common, nameIndex = null) {
    const nameKey = canonicalPersonName(name);
    const sameNames = nameIndex ? arr(nameIndex.get(nameKey)) : DATA.people.filter(p => canonicalPersonName(p.name) === nameKey);
    const exact = sameNames.find(p => bulkPersonTermKey(p.term) === bulkPersonTermKey(common.term));
    const duplicate = exact || (sameNames.length === 1 && (!clean(sameNames[0].term) || !common.term) ? sameNames[0] : null);
    if (!duplicate) return {name, mode:'create', duplicate:null, changes:[]};
    const changes = ['kind','term','org','role'].filter(key => common[key] && clean(duplicate[key]) !== common[key]);
    return {name, mode:changes.length ? 'update' : 'unchanged', duplicate, changes};
  }

  function openBulkPeopleModal() {
    const html = `<div class="bulk-people-form">
      <p class="modal-note">同じ種別・期別などを一度だけ入力し、氏名をカンマ・読点または改行で並べて登録します。空欄の共通項目で既存の情報を消すことはありません。</p>
      <div class="bulk-common-grid">
        <label class="field"><span>種別</span><input name="bulkKind" placeholder="例：普通科"></label>
        <label class="field"><span>期別</span><input name="bulkTerm" placeholder="例：79期"></label>
        <label class="field"><span>所属</span><input name="bulkOrg" placeholder="共通する場合だけ入力"></label>
        <label class="field"><span>役割</span><input name="bulkRole" placeholder="共通する場合だけ入力"></label>
      </div>
      <label class="field full bulk-name-entry"><span>氏名</span><textarea name="bulkNames" class="bulk-textarea" placeholder="例：田中太郎、山田花子\n佐藤一郎"></textarea><small class="field-hint">「、」「,」または改行で区切れます。同じ氏名が重なっていても1人として扱います。</small></label>
      <div class="bulk-preview" aria-live="polite"><b data-bulk-preview-count>0人</b><div class="bulk-preview-list" data-bulk-preview-list></div></div>
      <div class="modal-actions"><div></div><div><button type="button" class="ghost" data-cancel>閉じる</button><button type="submit" class="primary">まとめて登録</button></div></div>
    </div>`;
    const opened = openModal('人物を一括登録', html, async(fd) => {
      const names = bulkPersonNames(fd.get('bulkNames'));
      if (!names.length) { toast('登録する氏名を入力してください'); return false; }
      const common = {kind:clean(fd.get('bulkKind')), term:clean(fd.get('bulkTerm')), org:clean(fd.get('bulkOrg')), role:clean(fd.get('bulkRole'))};
      const now = new Date().toISOString();
      const nameIndex = bulkPersonNameIndex();
      const changed = [];
      const baseItems = [];
      let created = 0, updated = 0, unchanged = 0;
      for (const name of names) {
        const plan = bulkPersonPlan(name, common, nameIndex);
        const dup = plan.duplicate;
        if (plan.mode === 'create') {
          changed.push({id:uid('pe'), name, kind:common.kind, term:common.term, displayOrder:'', org:common.org, role:common.role, tel:'', email:'', tags:'', retired:false, retiredAt:'', note:'', createdAt:now, updatedAt:now});
          created++;
          continue;
        }
        const obj = cloneRecord(dup);
        if (plan.mode === 'unchanged') { unchanged++; continue; }
        plan.changes.forEach(key => { obj[key] = common[key]; });
        obj.updatedAt = now;
        changed.push(obj);
        baseItems.push({id:dup.id, updatedAt:dup.updatedAt || ''});
        updated++;
      }
      if (!changed.length) { toast(`${unchanged}人は登録済みです`); return false; }
      const j = await saveSpeculumItems('people', changed, baseItems);
      renderAll();
      const parts = [created?`新規${created}人`:'', updated?`更新${updated}人`:'', unchanged?`変更なし${unchanged}人`:''].filter(Boolean).join('・');
      toast(j.merged ? `${parts}を反映しました（最新データを反映）` : `${parts}を反映しました`);
    }, null);
    if (!opened) return;
    const form = $('modalForm');
    const namesInput = form?.elements?.bulkNames;
    const refreshPreview = () => {
      const names = bulkPersonNames(namesInput?.value || '');
      const common = {kind:clean(form?.elements?.bulkKind?.value), term:clean(form?.elements?.bulkTerm?.value), org:clean(form?.elements?.bulkOrg?.value), role:clean(form?.elements?.bulkRole?.value)};
      const nameIndex = bulkPersonNameIndex();
      const plans = names.map(name => bulkPersonPlan(name, common, nameIndex));
      const totals = {create:plans.filter(x=>x.mode==='create').length, update:plans.filter(x=>x.mode==='update').length, unchanged:plans.filter(x=>x.mode==='unchanged').length};
      const count = form?.querySelector('[data-bulk-preview-count]');
      const list = form?.querySelector('[data-bulk-preview-list]');
      if (count) count.textContent = `${names.length}人（新規${totals.create}・更新${totals.update}・変更なし${totals.unchanged}）`;
      if (list) list.innerHTML = plans.slice(0,20).map(plan => {
        const modeLabel = plan.mode === 'create' ? '新規' : plan.mode === 'update' ? '更新' : '変更なし';
        const detail = plan.changes.length ? `：${plan.changes.map(key=>({kind:'種別',term:'期別',org:'所属',role:'役割'})[key]).join('・')}` : '';
        return `<span class="bulk-preview-chip bulk-${esc(plan.mode)}"><b>${modeLabel}</b> ${esc(plan.name)}${esc(detail)}</span>`;
      }).join('') + (plans.length>20?`<span class="bulk-preview-chip">ほか${plans.length-20}人</span>`:'');
    };
    namesInput?.addEventListener('input', refreshPreview);
    ['bulkKind','bulkTerm','bulkOrg','bulkRole'].forEach(name => form?.elements?.[name]?.addEventListener('input', refreshPreview));
    refreshPreview();
  }


  function bindClick(id, fn) { const el = $(id); if (el) el.addEventListener('click', fn); }
  function bindInput(id, fn) { const el = $(id); if (el) el.addEventListener('input', fn); }
  function bindDebouncedInput(id, fn, delay = 110) {
    const el = $(id); if (!el) return;
    let timer = 0;
    el.addEventListener('input', e => { clearTimeout(timer); timer = setTimeout(() => fn(e), delay); });
  }
  function bindKey(id, fn) { const el = $(id); if (el) el.addEventListener('keydown', fn); }

  function bind() {
    if (!document.body.dataset.blackcatCloseActionMenusBound) {
      document.body.dataset.blackcatCloseActionMenusBound = '1';
      document.addEventListener('click', e => { if (!e.target?.closest?.('.card-more, .action-menu')) closeActionMenus(); });
      document.addEventListener('keydown', e => {
        if (e.key !== 'Escape') return;
        closeActionMenus();
        if (document.querySelector('.center-confirm-backdrop')) return;
        const backdrop = $('modalBackdrop');
        if (backdrop && !backdrop.hidden) { e.preventDefault(); closeModal(false); }
      });
    }
    $$('.bc-tabs button').forEach(b => b.addEventListener('click', () => switchView(b.dataset.view)));
    $$('[data-go]').forEach(b => b.addEventListener('click', () => switchView(b.dataset.go)));
    bindClick('openWorkBtn', () => openWorkspace('continuum'));
    bindClick('openWorkFromDueBtn', () => openWorkspace('continuum'));
    bindClick('openBackupBtn', openBackupModal);
    bindClick('todayBackupBtn', openBackupModal);
    bindClick('openBackupTodayBtn', openBackupModal);
    bindClick('quickAddEventBtn', () => openEventModal({date:today()}));
    bindClick('addTodayEventBtn', () => openEventModal({date:today()}));
    bindClick('openMorningReviewBtn', openMorningReview);
    bindClick('openClosingReviewBtn', openClosingReview);

    $$('.memo-tabs button').forEach(b => b.addEventListener('click', () => showMemoPanel(b.dataset.memoTab || 'today')));
    bindClick('saveMemoBtn', () => saveMemos('メモを保存しました'));
    bindClick('toggleMemoBtn', () => toggleMemoPanel());
    const memoAuto = () => {
      MEMO_DRAFT_DIRTY = true;
      if (MEMO_SAVE_RUNNING) MEMO_SAVE_PENDING = true;
      clearTimeout(bind.memoTimer);
      bind.memoTimer = setTimeout(() => saveMemos(''), 900);
    };
    bindInput('todayMemo', e => { updateMemoPreview(); memoAuto(e); });
    bindInput('permanentMemo', e => { updateMemoPreview(); memoAuto(e); });

    bindClick('prevYear', () => { calCursor.setFullYear(calCursor.getFullYear()-1); renderCalendar(); });
    bindClick('nextYear', () => { calCursor.setFullYear(calCursor.getFullYear()+1); renderCalendar(); });
    bindClick('prevMonth', () => { calCursor.setMonth(calCursor.getMonth()-1); renderCalendar(); });
    bindClick('nextMonth', () => { calCursor.setMonth(calCursor.getMonth()+1); renderCalendar(); });
    bindClick('todayJumpBtn', () => { calCursor = new Date(); renderCalendar(); });
    bindClick('importHolidaysBtn', importCabinetHolidays);
    bindClick('jumpDateBtn', () => { const v = $('jumpDate')?.value; if (v) { calCursor = new Date(v + 'T00:00:00'); renderCalendar(); } });
    bindClick('monthViewBtn', () => { calendarMode = 'month'; calendarListExpanded = false; renderCalendar(); });
    bindClick('listViewBtn', () => { calendarMode = 'list'; calendarListExpanded = false; renderCalendar(); });
    bindClick('calendarBothBtn', () => setCalendarItemMode('both'));
    bindClick('calendarScheduleBtn', () => setCalendarItemMode('schedule'));
    bindClick('calendarHappeningBtn', () => setCalendarItemMode('happening'));
    [['calendarDueToggle','due'],['calendarWorkToggle','work'],['calendarDoneToggle','done'],['calendarRepeatToggle','repeat']].forEach(([id,name]) => { const el=$(id); if(el) el.addEventListener('change', e => setCalendarToggle(name, e.target.checked)); });
    $$('[data-due-count-mode]').forEach(el => el.addEventListener('change', e => setDueDayCountMode(e.target.value)));
    bindDebouncedInput('scheduleSearch', renderCalendar);
    bindClick('clearScheduleSearch', () => { if ($('scheduleSearch')) $('scheduleSearch').value=''; renderCalendar(); });
    bindClick('showAllScheduleBtn', () => { calendarMode='list'; calendarListExpanded = false; switchView('schedule'); renderCalendar(); });
    bindClick('addScheduleBtn', () => openEventModal({date:today()}));

    bindClick('addDeadlineBtn', () => openDueModal('deadlines', {due:today()}));
    bindClick('addJimuBtn', () => openDueModal('jimu', {due:today()}));
    bindClick('addCaseBtn', () => openCaseModal());
    bindDebouncedInput('caseSearch', renderCards);
    bindClick('addPersonBtn', () => openPersonModal());
    bindClick('bulkPeopleBtn', openBulkPeopleModal);
    bindClick('toggleRetiredBtn', () => { showRetiredPeople = !showRetiredPeople; const b=$('toggleRetiredBtn'); if(b) b.textContent = showRetiredPeople ? '退職者を隠す' : '退職者も表示'; renderPeople(); });
    bindClick('addCareerBtn', () => openCareerModal());
    bindDebouncedInput('peopleSearch', renderPeople);
    bindDebouncedInput('careerSearch', renderTimeline);
    bindClick('importWorkBtn', sendAllToWork);
    bindDebouncedInput('dueSearch', renderLists);
    bindClick('clearDueSearch', () => { if ($('dueSearch')) $('dueSearch').value=''; renderLists(); });
    bindClick('sendAllWorkBtn', sendAllToWork);
    bindClick('modalClose', () => closeModal(false));
    const backdrop = $('modalBackdrop'); if (backdrop) backdrop.addEventListener('click', backdropTap);
    window.addEventListener('hashchange', () => switchView(location.hash.slice(1) || 'today'));
    window.addEventListener('blur', () => { WINDOW_BLURRED_AT = Date.now(); });
    window.addEventListener('focus', () => {
      const elapsed = WINDOW_BLURRED_AT ? Date.now() - WINDOW_BLURRED_AT : 0;
      WINDOW_BLURRED_AT = 0;
      refreshDayContextIfNeeded().finally(() => {
        if (elapsed < 0 || elapsed > 180) { queueExternalSync('speculum'); queueExternalSync('continuum'); }
      });
    });
    document.addEventListener('visibilitychange', () => {
      if (!document.hidden) refreshDayContextIfNeeded().finally(() => { queueExternalSync('speculum'); queueExternalSync('continuum'); });
    });
    window.addEventListener('message', e => {
      if (e.data && e.data.blackcatOpenBackup) openBackupModal();
      if (e.data && e.data.blackcatNavigateView) switchView(String(e.data.blackcatNavigateView || 'today'));
    });
    scheduleDayContextCheck();
  }

  async function start() {
    try {
      await initToken();
      await loadData();
      setupDataSync();
      bind();
      await refreshDayContextIfNeeded();
      // ワークスペースから内側の画面へ直接入った場合も、要求された表示先を維持する。
      currentView = location.hash ? location.hash.slice(1) : (currentView || 'today');
      switchView(currentView);
      scheduleCaseViewPreload();
    }
    catch (e) { document.body.innerHTML = `<main class="bc-shell"><div class="panel"><h1>起動できませんでした</h1><p>${esc(e.message)}</p></div></main>`; }
  }
  window.addEventListener('message', e => { if ((e.data || {}).blackcatCommand === 'openBackup') openBackupModal(); });
  document.addEventListener('DOMContentLoaded', () => { if (new URLSearchParams(location.search).get('embed') === '1') document.body.classList.add('embedded'); start(); });
})();

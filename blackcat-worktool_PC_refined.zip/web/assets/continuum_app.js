(() => {
  'use strict';
  window.addEventListener('unhandledrejection', e => { if (e?.reason?.handled || e?.reason?.cancelled) e.preventDefault(); });
  const $ = id => document.getElementById(id);
  const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
  const esc = v => String(v ?? '').replace(/[&<>\"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','\"':'&quot;',"'":'&#39;'}[c]));
  const clean = v => String(v ?? '').trim();
  const arr = v => Array.isArray(v) ? v : [];
  const searchTokens = q => clean(q).toLowerCase().split(/[\s　,、。/\\]+/).filter(Boolean);
  const matchesSearchTokens = (tokens, hay) => { if(!tokens.length) return true; const h = String(hay || '').toLowerCase(); return tokens.every(t => h.includes(t)); };
  const uid = p => `${p}_${Date.now().toString(16)}_${Math.random().toString(16).slice(2,7)}`;
  const pad = n => String(n).padStart(2,'0');
  const today = () => { const d = new Date(); return `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}`; };
  const displayDateTime = value => {
    const raw = clean(value); if(!raw) return '';
    const d = new Date(raw); if(Number.isNaN(d.getTime())) return raw.replace('T',' ').replace(/:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:?\d{2})?$/,'');
    try {
      const parts = new Intl.DateTimeFormat('ja-JP', {timeZone:'Asia/Tokyo', year:'numeric', month:'2-digit', day:'2-digit', hour:'2-digit', minute:'2-digit', hourCycle:'h23'}).formatToParts(d);
      const get = type => parts.find(part => part.type === type)?.value || '';
      return `${get('year')}/${get('month')}/${get('day')} ${get('hour')}:${get('minute')}`;
    } catch (_) {
      return `${d.getFullYear()}/${pad(d.getMonth()+1)}/${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
    }
  };
  const addDaysISO = (ds, n) => { const d = new Date((ds || today()) + 'T00:00:00'); if(Number.isNaN(d.getTime())) return today(); d.setDate(d.getDate() + Number(n || 0)); return `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}`; };
  const columns = [['today','今日やる'],['next','次に進める'],['waiting','待ち'],['done','完了']];
  const cycleColumns = [['today','今回対象'],['next','継続中'],['waiting','休止中'],['done','終了済み']];
  const statusLabel = s => (columns.find(x => x[0] === String(s || 'next')) || columns[1])[1];
  const cycleColumnLabel = s => (cycleColumns.find(x => x[0] === String(s || 'next')) || cycleColumns[1])[1];
  const validStatus = s => columns.some(x => x[0] === s) ? s : 'next';
  const defaultSettings = () => ({doneVisibleDays:'0', boardLimit:'20', boardDensity:'compact', workSortMode:'urgency', dueDayCountMode:'business', savedWorkFilters:[]});
  const isDoneStatus = x => validStatus(x?.status || 'next') === 'done';
  let WORK_SCOPE = 'all';
  let TOKEN = '';
  let DATA = {schema:2, tasks:[], cycleTasks:[], memo:'', settings:defaultSettings()};
  let SPEC = {people:[], cases:[], deadlines:[], jimu:[], events:[], holidays:{items:{}}};
  let HASH = '';
  let dirtyModal = false;
  let MODAL_SAVING = false;
  let MODAL_SESSION = 0;
  let MODAL_RETURN_FOCUS = null;
  let ACTIVE_PROMPT_CANCEL = null;
  let QUICK_ADD_BUSY = false;
  let ACTIVE_TASK_DRAG_ID = '';
  let SELECT_MODE = false;
  const SELECTED_TASK_IDS = new Set();
  const PENDING_SOURCE_IMPORTS = new Set();
  let IMPORT_ALL_BUSY = false;
  let MEMO_SAVE_TIMER = 0;
  let MEMO_SAVE_RUNNING = false;
  let MEMO_SAVE_PENDING = false;
  let MEMO_SAVE_NOTICE = false;
  let MEMO_LAST_SAVED = '';
  let SETTINGS_SAVE_CHAIN = Promise.resolve();
  const INSTANCE_ID = `${Date.now()}-${Math.random().toString(16).slice(2)}`;
  let DATA_CHANNEL = null;
  let DATA_SYNC_TIMER = 0;
  const PENDING_DATA_APPS = new Set();
  const PENDING_TASK_IDS = new Set();
  const PENDING_CYCLE_IDS = new Set();
  let PERSON_BY_ID = new Map();
  let PERSON_SEARCH_BY_ID = new Map();
  let CASE_BY_ID = new Map();
  let TASK_BY_ID = new Map();
  let TASK_INDEX_BY_ID = new Map();
  let CYCLE_INDEX_BY_ID = new Map();
  let TASK_SEARCH_BY_ID = new Map();
  let TASK_SOURCE_KEYS = new Set();
  let CALENDAR_DIFF_CACHE = new Map();
  let BUSINESS_DIFF_CACHE = new Map();
  let DATE_CACHE_DAY = '';
  let SOURCE_INDEX = {deadlines:new Map(), jimu:new Map(), events:new Map(), cases:new Map()};
  let SPEC_HASH = '';
  let LAST_REMOTE_CHECK = 0;
  let RESUME_SYNC_TIMER = 0;
  let RESUME_SYNC_RUNNING = false;
  let RENDER_INBOX_DATA = null;
  let ACTIVE_DAY = today();
  let DAY_CONTEXT_TIMER = 0;

  function debounce(fn, wait = 90){
    let timer = 0;
    return (...args) => { clearTimeout(timer); timer = setTimeout(() => fn(...args), wait); };
  }

  function hasPendingWorkMutation(){
    return PENDING_TASK_IDS.size > 0 || PENDING_CYCLE_IDS.size > 0;
  }

  function sourceRef(item){ return clean(item?.source || item?.sourceInfo?.ref || item?.sourceInfo?.legacy); }
  function rebuildContinuumIndexes(rebuildSearch = true){
    TASK_BY_ID = new Map(arr(DATA.tasks).map(x => [x.id, x]));
    TASK_INDEX_BY_ID = new Map(arr(DATA.tasks).map((x, index) => [x.id, index]));
    rebuildCycleIndex();
    TASK_SOURCE_KEYS = new Set(arr(DATA.tasks).map(sourceRef).filter(Boolean));
    [...SELECTED_TASK_IDS].forEach(id => { if(!TASK_BY_ID.has(id)) SELECTED_TASK_IDS.delete(id); });
    if(rebuildSearch) rebuildTaskSearchIndex();
  }

  function rebuildCycleIndex(){
    CYCLE_INDEX_BY_ID = new Map(arr(DATA.cycleTasks).map((x, index) => [x.id, index]));
  }

  function rebuildTaskSearchIndex(){
    TASK_SEARCH_BY_ID = new Map(arr(DATA.tasks).map(x => [x.id, searchableTask(x)]));
  }

  function rebuildSpeculumIndexes(){
    PERSON_BY_ID = new Map(arr(SPEC.people).map(x => [x.id, x]));
    PERSON_SEARCH_BY_ID = new Map(arr(SPEC.people).map(x => [x.id, personSearchText(x)]));
    CASE_BY_ID = new Map(arr(SPEC.cases).map(x => [x.id, x]));
    SOURCE_INDEX = {
      deadlines:new Map(arr(SPEC.deadlines).map(x => [x.id, x])),
      jimu:new Map(arr(SPEC.jimu).map(x => [x.id, x])),
      events:new Map(arr(SPEC.events).map(x => [x.id, x])),
      cases:new Map(arr(SPEC.cases).map(x => [x.id, x]))
    };
    CALENDAR_DIFF_CACHE = new Map();
    BUSINESS_DIFF_CACHE = new Map();
    DATE_CACHE_DAY = today();
    // 人物名・事案名・連携元は台帳側の更新でも変わるため、検索用文字列も更新する。
    rebuildTaskSearchIndex();
  }

  function notifyDataChanged(app){
    try { DATA_CHANNEL?.postMessage({type:'data-changed', app, source:INSTANCE_ID, at:Date.now()}); } catch (_) {}
  }

  function setupDataSync(){
    try {
      DATA_CHANNEL = new BroadcastChannel('blackcat-data-changed');
      DATA_CHANNEL.onmessage = ev => {
        const msg = ev.data || {};
        if (!['data-changed','changed'].includes(msg.type) || (msg.source || msg.sender) === INSTANCE_ID) return;
        const apps = arr(msg.apps).length ? arr(msg.apps) : [msg.app];
        apps.filter(x => x === 'speculum' || x === 'continuum').forEach(x => PENDING_DATA_APPS.add(x));
        clearTimeout(DATA_SYNC_TIMER);
        DATA_SYNC_TIMER = setTimeout(refreshExternalData, 70);
      };
    } catch (_) {}
  }

  function flushPendingDataSync(){
    if(!PENDING_DATA_APPS.size)return;
    clearTimeout(DATA_SYNC_TIMER);
    DATA_SYNC_TIMER=setTimeout(refreshExternalData,70);
  }

  async function refreshExternalData(){
    if(!($('modalBackdrop')?.hidden ?? true) || hasPendingWorkMutation())return;
    const apps = new Set(PENDING_DATA_APPS); PENDING_DATA_APPS.clear();
    if (!apps.size) return;
    try {
      if (apps.has('continuum') && apps.has('speculum')) {
        const j = await api('/api/blackcat/load');
        applyContinuumRecord(j.continuum || {});
        applySpeculumRecord(j.speculum || {});
      } else if (apps.has('continuum')) applyContinuumRecord(await api('/api/continuum/load'));
      else if (apps.has('speculum')) applySpeculumRecord(await api('/api/speculum/load'));
      render();
      LAST_REMOTE_CHECK = Date.now();
    } catch (_) {}
  }

  function remoteRecordChanged(record, hash, updatedAt){
    const nextHash = clean(record?.hash);
    if (nextHash) return nextHash !== clean(hash);
    const nextUpdated = clean(record?.data?.updatedAt);
    return !!nextUpdated && nextUpdated !== clean(updatedAt);
  }

  async function refreshAfterResume(){
    if (document.hidden) return;
    refreshDayContextIfNeeded();
    if (!($('modalBackdrop')?.hidden ?? true) || dirtyModal || hasPendingWorkMutation() || RESUME_SYNC_RUNNING) return;
    const elapsed = Date.now() - LAST_REMOTE_CHECK;
    if (elapsed >= 0 && elapsed < 900) return;
    RESUME_SYNC_RUNNING = true;
    try {
      const j = await api('/api/blackcat/load');
      const continuum = j.continuum || {};
      const speculum = j.speculum || {};
      const continuumChanged = remoteRecordChanged(continuum, HASH, DATA.updatedAt);
      const speculumChanged = remoteRecordChanged(speculum, SPEC_HASH, SPEC.updatedAt);
      if (continuumChanged) applyContinuumRecord(continuum);
      if (speculumChanged) applySpeculumRecord(speculum);
      if (continuumChanged || speculumChanged) render();
      LAST_REMOTE_CHECK = Date.now();
    } catch (_) {
      LAST_REMOTE_CHECK = Date.now();
    } finally {
      RESUME_SYNC_RUNNING = false;
    }
  }

  function scheduleResumeSync(){
    clearTimeout(RESUME_SYNC_TIMER);
    RESUME_SYNC_TIMER = setTimeout(refreshAfterResume, 120);
  }

  function openWorkspace(target='speculum:today') {
    let hash = 'speculum:today';
    const raw = String(target || '').replace(/^\//, '');
    const routeAfter = (prefix) => {
      if (raw.includes('#')) return raw.split('#').slice(1).join('#');
      if (raw.startsWith(prefix + ':')) return raw.slice(prefix.length + 1);
      if (raw.startsWith(prefix + '?')) return '?' + raw.slice(prefix.length + 1);
      if (raw.includes('?')) return '?' + raw.split('?').slice(1).join('?');
      return '';
    };
    if (raw.startsWith('continuum') || raw === 'work') {
      const detail = clean(routeAfter('continuum')).replace(/^#/, '').replace(/^\?/, '');
      hash = detail ? 'continuum?' + detail : 'continuum';
    }
    else if (raw.startsWith('main')) hash = 'speculum:' + (routeAfter('main').replace(/^#/, '') || 'today');
    else if (raw.startsWith('speculum')) hash = 'speculum:' + (routeAfter('speculum').replace(/^#/, '') || 'today');
    else if (raw.includes('#')) hash = 'speculum:' + (raw.split('#').slice(1).join('#') || 'today');
    else if (raw) hash = raw.includes(':') ? raw : `speculum:${raw}`;
    if (window.parent && window.parent !== window) { try { window.parent.postMessage({blackcatNavigate: hash}, '*'); return; } catch (_) {} }
    const apiTarget = hash.startsWith('continuum') ? ('/continuum' + (hash.includes('?') ? '#' + hash.split('?').slice(1).join('?') : '')) : '/speculum#' + (hash.split(':').slice(1).join(':') || 'today');
    try { api('/api/ui/open-app', {method:'POST', body:JSON.stringify({target:apiTarget})}).catch(() => window.open('/workspace#' + hash, 'blackcat_workspace')); }
    catch (_) { window.open('/workspace#' + hash, 'blackcat_workspace'); }
  }

  async function initToken(){ const j = await fetch('/api/security/token', {cache:'no-store'}).then(r=>r.json()); TOKEN = j.token || ''; }
  function routeParamsFromHash(){
    const raw = String(location.hash || '').replace(/^#?\??/, '');
    return new URLSearchParams(raw);
  }
  function routeFocus(){
    const params = routeParamsFromHash();
    const q = clean(params.get('q') || '');
    const focus = clean(params.get('focus') || '');
    if (!q && !focus) return;
    const input = $('workFilter');
    if (input && q && input.value !== q) input.value = q;
    render();
    setTimeout(() => {
      const selector = '[data-record-id], [data-task-id], [data-cycle-id]';
      let target = null;
      if (focus) target = Array.from(document.querySelectorAll(selector)).find(el => [el.dataset.recordId, el.dataset.taskId, el.dataset.cycleId].some(v => clean(v) === focus));
      if (!target) target = document.querySelector('.task-card, .cycle-card');
      if (!target) return;
      target.classList.add('route-focus');
      target.scrollIntoView({block:'center', inline:'nearest'});
      setTimeout(() => target.classList.remove('route-focus'), 1800);
    }, 100);
  }
  async function api(path, options = {}){
    const headers = {'Content-Type':'application/json'};
    if (TOKEN) headers['X-Blackcat-Token'] = TOKEN;
    const r = await fetch(path, {...options, headers:{...headers, ...(options.headers || {})}});
    const j = await r.json().catch(()=>({}));
    if (!r.ok || j.ok === false) { const e = new Error(j.error || '通信に失敗しました'); e.status = r.status; e.data = j; e.path = path; throw e; }
    const method = String(options.method || 'GET').toUpperCase();
    if (method !== 'GET' && path.startsWith('/api/continuum/')) notifyDataChanged('continuum');
    if (method !== 'GET' && path.startsWith('/api/speculum/')) notifyDataChanged('speculum');
    if (method !== 'GET' && path === '/api/backups/restore') {
      let app = '';
      try { app = clean(JSON.parse(options.body || '{}').app); } catch (_) {}
      notifyDataChanged(app === 'continuum' ? 'continuum' : 'speculum');
    }
    return j;
  }
  function applyContinuumRecord(j){
    const memoEl=$('workMemo');
    const memoHadLocalEdits=!!memoEl && String(memoEl.value || '')!==MEMO_LAST_SAVED;
    const rawWorkSettings = Object.assign({}, (j.data || {}).settings || {});
    DATA = Object.assign({schema:2, tasks:[], cycleTasks:[], memo:'', settings:defaultSettings()}, j.data || {});
    DATA.settings = Object.assign(defaultSettings(), DATA.settings || {});
    DATA.tasks = arr(DATA.tasks).map(t => ({...t, status: validStatus(t.status || 'next'), personIds:arr(t.personIds), estimateMinutes:estimateMinutes(t)}));
    DATA.cycleTasks = arr(DATA.cycleTasks).map(normalizeCycleClient);
    HASH = j.hash || '';
    MEMO_LAST_SAVED = String(DATA.memo || '');
    if(memoEl && !memoHadLocalEdits && document.activeElement!==memoEl)memoEl.value=MEMO_LAST_SAVED;
    rebuildContinuumIndexes();
    return rawWorkSettings;
  }
  function applySpeculumRecord(s, rawWorkSettings = null){
    SPEC = Object.assign({people:[], cases:[], deadlines:[], jimu:[], events:[], holidays:{items:{}}}, s.data || {});
    if (rawWorkSettings && !Object.prototype.hasOwnProperty.call(rawWorkSettings, 'dueDayCountMode') && SPEC.settings?.dueDayCountMode) DATA.settings.dueDayCountMode = SPEC.settings.dueDayCountMode === 'calendar' ? 'calendar' : 'business';
    SPEC.people = arr(SPEC.people); SPEC.cases = arr(SPEC.cases); SPEC.deadlines = arr(SPEC.deadlines); SPEC.jimu = arr(SPEC.jimu); SPEC.events = arr(SPEC.events);
    SPEC_HASH = s.hash || SPEC_HASH;
    rebuildSpeculumIndexes();
  }
  async function load(){
    try {
      const j = await api('/api/blackcat/load');
      const raw = applyContinuumRecord(j.continuum || {});
      applySpeculumRecord(j.speculum || {}, raw);
    } catch (_) {
      const [j, s] = await Promise.all([api('/api/continuum/load'), api('/api/speculum/load')]);
      const raw = applyContinuumRecord(j); applySpeculumRecord(s, raw);
    }
    LAST_REMOTE_CHECK = Date.now();
  }
  function dataSummaryForConflict(data){
    const tasks=arr(data?.tasks); const cycles=arr(data?.cycleTasks);
    const done=tasks.filter(isDoneStatus).length;
    const cycleDone=cycles.filter(c=>cycleState(c)==='ended').length;
    return `通常作業${tasks.length}件（完了${done}件） / 周期作業${cycles.length}件（終了${cycleDone}件） / 更新 ${displayDateTime(data?.updatedAt)||'不明'}`;
  }
  async function conflictDetail(localData){
    try{ const j=await api('/api/continuum/load'); return `\n\nこの画面: ${dataSummaryForConflict(localData)}\n保存済み最新: ${dataSummaryForConflict(j.data||{})}`; }
    catch(_){ return ''; }
  }
  async function resolveSaveConflict(data, baseHash, message, err){
    const updated = err?.data?.updatedAt ? `
相手側更新: ${displayDateTime(err.data.updatedAt)}` : '';
    const detail = await conflictDetail(data);
    const keep = await askConfirm('別画面で更新されています', `この画面を開いた後に、別画面または別操作で作業データが更新されています。

上書きは行いません。今の画面内容を控えに残してから、保存済みの最新データを読み込みます。${updated}${detail}`, '控えを残して再読み込み', '閉じる');
    if (!keep) throw Object.assign(new Error('保存を中止しました'), {cancelled:true});
    try { await api('/api/backups/save-draft', {method:'POST', body:JSON.stringify({app:'continuum', data})}); } catch (_) {}
    await load(); render();
    toast('この画面の内容を控えに残して、最新データを読み込みました');
    throw Object.assign(new Error(''), {cancelled:true, handled:true, conflict:true, reloaded:true});
  }
  async function save(msg = '保存しました'){
    DATA.updatedAt = new Date().toISOString();
    try {
      const j = await api('/api/continuum/save', {method:'POST', body:JSON.stringify({data:DATA, baseHash:HASH})});
      HASH = j.hash || HASH;
      if (msg) toast(msg);
      return j;
    } catch(e) {
      if (e.status === 409 || e.data?.conflict) return resolveSaveConflict(DATA, HASH, msg, e);
      throw e;
    }
  }
  function toast(msg, opts = {}){
    const t=$('toast'); if(!t || !msg)return;
    t.innerHTML = '';
    const span = document.createElement('span'); span.textContent = msg; t.appendChild(span);
    if (opts.actionLabel && typeof opts.onAction === 'function') {
      const b = document.createElement('button'); b.type='button'; b.className='toast-action'; b.textContent=opts.actionLabel;
      b.onclick = async e => { e.preventDefault(); clearTimeout(toast.t); t.classList.remove('show'); b.disabled=true; try{await opts.onAction();}catch(err){toast(err?.message || '操作を元に戻せませんでした');} };
      t.appendChild(b);
    }
    t.classList.add('show'); clearTimeout(toast.t); toast.t=setTimeout(()=>t.classList.remove('show'), opts.ms || 3600);
  }
  function askConfirm(title, message, okLabel = '実行', cancelLabel = 'やめる'){
    return new Promise(resolve => {
      ACTIVE_PROMPT_CANCEL?.();
      const returnFocus=document.activeElement;
      const back = document.createElement('div'); back.className = 'center-confirm-backdrop';
      back.innerHTML = `<section class="center-confirm" role="dialog" aria-modal="true" aria-labelledby="centerConfirmTitle" aria-describedby="centerConfirmMessage"><h2 id="centerConfirmTitle">${esc(title)}</h2><p id="centerConfirmMessage">${esc(message)}</p><div class="confirm-actions"><button type="button" class="ghost" data-cancel>${esc(cancelLabel)}</button><button type="button" class="danger-confirm" data-ok>${esc(okLabel)}</button></div></section>`;
      document.body.appendChild(back);
      let settled=false;
      const cancel=()=>done(false);
      const done = v => { if(settled)return;settled=true;if(ACTIVE_PROMPT_CANCEL===cancel)ACTIVE_PROMPT_CANCEL=null;back.remove();if(returnFocus&&document.contains(returnFocus)&&typeof returnFocus.focus==='function')returnFocus.focus();resolve(v); };
      ACTIVE_PROMPT_CANCEL=cancel;
      back.querySelector('[data-cancel]').onclick = () => done(false);
      back.querySelector('[data-ok]').onclick = () => done(true);
      back.addEventListener('click', e => { if (e.target === back) done(false); });
      back.addEventListener('keydown', e => { if(e.key==='Escape'){e.preventDefault();e.stopPropagation();done(false);} });
      setTimeout(() => back.querySelector('[data-cancel]')?.focus(), 20);
    });
  }

  function askText(title, message, defaultValue = '', okLabel = '決定', cancelLabel = 'やめる', inputType = 'date'){
    return new Promise(resolve => {
      ACTIVE_PROMPT_CANCEL?.();
      const returnFocus=document.activeElement;
      const back = document.createElement('div'); back.className = 'center-confirm-backdrop';
      back.innerHTML = `<section class="center-confirm" role="dialog" aria-modal="true" aria-labelledby="centerConfirmTitle" aria-describedby="centerConfirmMessage"><h2 id="centerConfirmTitle">${esc(title)}</h2><p id="centerConfirmMessage">${esc(message)}</p><input class="confirm-input" type="${esc(inputType)}" value="${esc(defaultValue)}" aria-label="${esc(title)}"><div class="confirm-actions"><button type="button" class="ghost" data-cancel>${esc(cancelLabel)}</button><button type="button" class="danger-confirm" data-ok>${esc(okLabel)}</button></div></section>`;
      document.body.appendChild(back);
      const input = back.querySelector('.confirm-input');
      let settled=false;
      const cancel=()=>done(false);
      const done = v => { if(settled)return;settled=true;const value=v?input.value:null;if(ACTIVE_PROMPT_CANCEL===cancel)ACTIVE_PROMPT_CANCEL=null;back.remove();if(returnFocus&&document.contains(returnFocus)&&typeof returnFocus.focus==='function')returnFocus.focus();resolve(value); };
      ACTIVE_PROMPT_CANCEL=cancel;
      back.querySelector('[data-cancel]').onclick = () => done(false);
      back.querySelector('[data-ok]').onclick = () => done(true);
      input.addEventListener('keydown', e => { if(e.key==='Escape'){e.preventDefault();done(false);} if(e.key==='Enter'){e.preventDefault();done(true);} });
      back.addEventListener('click', e => { if(e.target === back) done(false); });
      setTimeout(() => { input.focus(); input.select?.(); }, 20);
    });
  }

  function fmt(ds){ if(!ds) return ''; const d=new Date(ds+'T00:00:00'); if(Number.isNaN(d.getTime())) return ds; return `${d.getFullYear()}/${d.getMonth()+1}/${d.getDate()}(${['日','月','火','水','木','金','土'][d.getDay()]})`; }
  function dateObj(ds){ const d=new Date(clean(ds)+'T00:00:00'); return Number.isNaN(d.getTime()) ? null : d; }
  function isoFromDate(d){ return `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}`; }
  function ensureDateCacheCurrent(){ const day=today(); if(DATE_CACHE_DAY===day)return; DATE_CACHE_DAY=day; CALENDAR_DIFF_CACHE.clear(); BUSINESS_DIFF_CACHE.clear(); }
  function dayContextCheckDelay(){ const now=new Date(); const next=new Date(now.getFullYear(),now.getMonth(),now.getDate()+1,0,0,0,250); const wait=next.getTime()-now.getTime(); return Math.max(1000,Math.min(60000,Number.isFinite(wait)?wait:60000)); }
  function scheduleDayContextCheck(){ clearTimeout(DAY_CONTEXT_TIMER); DAY_CONTEXT_TIMER=setTimeout(()=>{refreshDayContextIfNeeded();scheduleDayContextCheck();},dayContextCheckDelay()); }
  function refreshDayContextIfNeeded(){
    const nextDay=today(); if(ACTIVE_DAY===nextDay)return false;
    ACTIVE_DAY=nextDay; DATE_CACHE_DAY=nextDay; CALENDAR_DIFF_CACHE.clear(); BUSINESS_DIFF_CACHE.clear();
    if(typeof window.blackcatInvalidateWorkRenderCache==='function')window.blackcatInvalidateWorkRenderCache('day-change');
    render();
    return true;
  }
  function calendarDiff(ds){ ensureDateCacheCurrent(); const key=clean(ds); if(!key)return null; if(CALENDAR_DIFF_CACHE.has(key))return CALENDAR_DIFF_CACHE.get(key); const a=dateObj(DATE_CACHE_DAY), b=dateObj(key); const value=(!a||!b)?null:Math.round((b-a)/86400000); CALENDAR_DIFF_CACHE.set(key,value); return value; }
  function holidayName(ds){ const s=clean(ds); if(!/^\d{4}-\d{2}-\d{2}$/.test(s))return''; const imported=clean(SPEC?.holidays?.items?.[s] || ''); const mmdd=s.slice(5); const closed=mmdd>='12-29'||mmdd<='01-03'; if(imported&&closed)return`${imported}・閉庁日`; return imported || (closed?'閉庁日':''); }
  function holidayDataAvailable(){ return Object.keys(SPEC?.holidays?.items || {}).length > 0; }
  function isClosedDay(ds){ const d=dateObj(ds); if(!d)return false; return d.getDay()===0 || d.getDay()===6 || !!holidayName(ds); }
  function businessDiff(ds){ ensureDateCacheCurrent(); const key=clean(ds); if(!key)return null; if(BUSINESS_DIFF_CACHE.has(key))return BUSINESS_DIFF_CACHE.get(key); const target=dateObj(key), base=dateObj(DATE_CACHE_DAY); if(!target||!base){BUSINESS_DIFF_CACHE.set(key,null);return null;} const cd=calendarDiff(key); if(cd===null){BUSINESS_DIFF_CACHE.set(key,null);return null;} if(cd===0){BUSINESS_DIFF_CACHE.set(key,0);return 0;} let count=0; if(cd>0){ const cur=new Date(base); while(true){ cur.setDate(cur.getDate()+1); if(cur>target)break; if(!isClosedDay(isoFromDate(cur)))count++; } BUSINESS_DIFF_CACHE.set(key,count); return count; } const cur=new Date(target); while(true){ cur.setDate(cur.getDate()+1); if(cur>base)break; if(!isClosedDay(isoFromDate(cur)))count++; } BUSINESS_DIFF_CACHE.set(key,-count); return -count; }
  function nextOpenDay(ds=today()){ let cur=ds||today(); for(let i=0;i<14;i++){ cur=addDaysISO(cur,1); if(!isClosedDay(cur)) return cur; } return addDaysISO(ds||today(),1); }
  function endOfMonthISO(ds=today()){ const d=dateObj(ds||today()); if(!d)return today(); return isoFromDate(new Date(d.getFullYear(), d.getMonth()+1, 0)); }
  function nextWeekFridayISO(ds=today()){ const d=dateObj(ds||today()); if(!d)return addDaysISO(today(),7); const delta=((5-d.getDay()+7)%7)||7; d.setDate(d.getDate()+delta); return isoFromDate(d); }
  function datePresets(){ return [[today(),'今日'],[nextOpenDay(),'次の稼働日'],[addDaysISO(today(),7),'7日後'],[nextWeekFridayISO(),'来週金曜'],[endOfMonthISO(),'月末']]; }
  function durationPresets(){ return [['15','15分'],['30','30分'],['45','45分'],['60','1時間'],['90','1.5時間'],['120','2時間']]; }
  function statusPresets(){ return [['today','今日'],['next','次'],['waiting','待ち']]; }
  function priorityPresets(){ return [['normal','通常'],['high','高優先'],['low','低優先']]; }
  function dueCountMode(){ return setting('dueDayCountMode') === 'calendar' ? 'calendar' : 'business'; }
  function diff(ds){ return dueCountMode()==='calendar' ? calendarDiff(ds) : businessDiff(ds); }
  function due(ds){ const cal=calendarDiff(ds), d=diff(ds); if(cal===null||d===null)return''; if(dueCountMode()==='calendar'){ if(d<0)return`${Math.abs(d)}日超過`; if(d===0)return'今日'; if(d===1)return'明日'; return`あと${d}日`; } if(cal===0)return'今日'; if(cal<0)return d===0?'超過（0営業日）':`${Math.abs(d)}営業日超過`; return`あと${Math.max(0,d)}営業日`; }
  function estimateMinutes(item){ const raw=(item&&typeof item==='object')?(item.estimateMinutes??item.durationMinutes??item.minutes??0):item; const n=Number(raw||0); return Number.isFinite(n)&&n>0?Math.min(24*60,Math.round(n)):0; }
  function durationLabel(itemOrMinutes){ const m=typeof itemOrMinutes==='number'?estimateMinutes(itemOrMinutes):estimateMinutes(itemOrMinutes||0); if(!m)return''; const h=Math.floor(m/60), mm=m%60; if(h&&mm)return`${h}時間${mm}分`; if(h)return`${h}時間`; return`${mm}分`; }
  function totalEstimate(items){ return arr(items).reduce((sum,x)=>sum+estimateMinutes(x),0); }
  function estimateMeta(x){ const lab=durationLabel(x); return lab ? `見積 ${lab}` : ''; }
  function personName(id){ const p=PERSON_BY_ID.get(id); return p ? p.name : ''; }
  function caseName(id){ const c=CASE_BY_ID.get(id); return c ? (c.title || c.name) : ''; }
  function peopleLabel(item){ const linked = arr(item.personIds).map(personName).filter(Boolean); const free = clean(item.peopleText); return [...linked, ...(free ? [free] : [])].join('、'); }
  function currentFilter(){ return clean($('workFilter')?.value || ''); }
  function itemDate(x){ return x.due || x.nextRunDate || '9999'; }
  function priorityRank(x){ return x.priority === 'high' ? 0 : (x.priority === 'low' ? 2 : 1); }
  function urgencyRank(x){ const cd = calendarDiff(itemDate(x)); const d = diff(itemDate(x)); if (isDoneStatus(x)) return 9; if (cd !== null && cd < 0) return 0; if (cd === 0) return 1; if (d !== null && d >= 0 && d <= 7) return 2; if (!itemDate(x) || itemDate(x)==='9999') return 5; return 4; }
  function setting(key){
    if(!DATA.settings || typeof DATA.settings!=='object')DATA.settings=defaultSettings();
    if(!Object.prototype.hasOwnProperty.call(DATA.settings,key))DATA.settings[key]=defaultSettings()[key];
    return DATA.settings[key];
  }
  function doneVisibleDays(){ const v = String(setting('doneVisibleDays') || '7'); return v === 'always' ? Infinity : Math.max(0, Number(v) || 0); }
  function baseBoardLimit(){ const v = String(setting('boardLimit') || '20'); return v === 'all' ? Infinity : Math.max(1, Number(v) || 20); }
  function columnLimit(prefix, key){ const v = DATA.settings?.[`limit_${prefix}_${key}`]; if (v === 'all') return Infinity; if (v) return Math.max(1, Number(v) || baseBoardLimit()); return baseBoardLimit(); }
  function boardDensity(){ return setting('boardDensity') === 'comfortable' ? 'comfortable' : 'compact'; }
  function sortMode(){ return setting('workSortMode') || 'urgency'; }
  function dateOnlyFromAny(value){ const s=clean(value); if(!s)return''; const m=s.match(/^(\d{4}-\d{2}-\d{2})/); return m ? m[1] : ''; }
  function daysSince(ds){ const d=dateOnlyFromAny(ds); if(!d)return null; const n=calendarDiff(d); return n===null ? null : -n; }
  function doneDate(x){ return dateOnlyFromAny(x.completedAt || x.doneAt || x.endedAt || x.updatedAt || x.createdAt); }
  function shouldShowDone(x, forceAll = false){ if(!isDoneStatus(x)) return true; if(forceAll) return true; const keep=doneVisibleDays(); if(keep === Infinity) return true; if(keep <= 0) return false; const age=daysSince(doneDate(x)); return age === null ? true : age <= keep; }
  function caseSortKey(x){ return caseName(x.caseId) || ''; }
  function personSortKey(x){ return peopleLabel(x) || ''; }
  function manualSortKey(x){ const n = Number(x.sortOrder); return Number.isFinite(n) ? n : 999999; }
  function sortCards(a,b){
    const mode = sortMode();
    const byTitle = String(a.title||'').localeCompare(String(b.title||''));
    if (mode === 'due') return String(itemDate(a)).localeCompare(String(itemDate(b))) || urgencyRank(a)-urgencyRank(b) || byTitle;
    if (mode === 'priority') return priorityRank(a)-priorityRank(b) || urgencyRank(a)-urgencyRank(b) || byTitle;
    if (mode === 'updated') return String(b.updatedAt||'').localeCompare(String(a.updatedAt||'')) || byTitle;
    if (mode === 'created') return String(b.createdAt||'').localeCompare(String(a.createdAt||'')) || byTitle;
    if (mode === 'case') return caseSortKey(a).localeCompare(caseSortKey(b)) || urgencyRank(a)-urgencyRank(b) || byTitle;
    if (mode === 'person') return personSortKey(a).localeCompare(personSortKey(b)) || urgencyRank(a)-urgencyRank(b) || byTitle;
    if (mode === 'manual') return manualSortKey(a)-manualSortKey(b) || urgencyRank(a)-urgencyRank(b) || byTitle;
    return urgencyRank(a) - urgencyRank(b) || priorityRank(a) - priorityRank(b) || String(itemDate(a)).localeCompare(String(itemDate(b))) || byTitle;
  }
  function dueBucket(x, done=false){
    if (done || isDoneStatus(x)) return '完了';
    if (validStatus(x.status) === 'waiting') return '保留';
    const cd = calendarDiff(itemDate(x));
    const d = diff(itemDate(x));
    if (cd !== null && cd < 0) return '超過';
    if (cd === 0) return '今日';
    if (d !== null && d >= 0 && d <= 7) return soonBucketLabel();
    if (d !== null && d > 7) return laterBucketLabel();
    return '期限なし';
  }
  function soonBucketLabel(){ return dueCountMode()==='calendar' ? '7日以内' : '7営業日以内'; }
  function laterBucketLabel(){ return dueCountMode()==='calendar' ? '8日以降' : '8営業日以降'; }
  function bucketOrder(){ return ['超過','今日',soonBucketLabel(),laterBucketLabel(),'期限なし','保留','完了']; }

  function searchableTask(t){ return [JSON.stringify(t), '作業 タスク', caseName(t.caseId), peopleLabel(t), sourceStatus(t)?.label].join(' ').toLowerCase(); }
  function workScopeMatch(x){
    const st = validStatus(x.status || 'next'); const cd = calendarDiff(itemDate(x)); const d = diff(itemDate(x));
    const review = st !== 'done' && ((st === 'waiting' && (daysSince(x.updatedAt || x.createdAt) ?? 999) >= 7) || (x.priority === 'high' && !clean(x.due || x.nextRunDate)) || !!sourceStatus(x)?.changed);
    if (WORK_SCOPE === 'active') return st !== 'done';
    if (WORK_SCOPE === 'overdue') return st !== 'done' && cd !== null && cd < 0;
    if (WORK_SCOPE === 'urgent') return st !== 'done' && (st === 'today' || (cd !== null && cd <= 0));
    if (WORK_SCOPE === 'today') return st !== 'done' && (st === 'today' || cd === 0);
    if (WORK_SCOPE === 'next') return st === 'next';
    if (WORK_SCOPE === 'week') return st !== 'done' && d !== null && d >= 0 && d <= 7;
    if (WORK_SCOPE === 'high') return st !== 'done' && x.priority === 'high';
    if (WORK_SCOPE === 'quick') return st !== 'done' && estimateMinutes(x) > 0 && estimateMinutes(x) <= 30;
    if (WORK_SCOPE === 'heavy') return st !== 'done' && estimateMinutes(x) >= 60;
    if (WORK_SCOPE === 'noDueHigh') return st !== 'done' && x.priority === 'high' && !clean(x.due || x.nextRunDate);
    if (WORK_SCOPE === 'waiting') return st === 'waiting';
    if (WORK_SCOPE === 'review') return review;
    if (WORK_SCOPE === 'unestimated') return st !== 'done' && !estimateMinutes(x) && (st === 'today' || cd !== null || x.priority === 'high');
    if (WORK_SCOPE === 'done') return st === 'done';
    return true;
  }
  function scopeLabel(scope = WORK_SCOPE){
    const week = dueCountMode()==='calendar' ? '7日以内' : '7営業日以内';
    return ({all:'すべて', active:'未完了', urgent:'今すぐ', overdue:'期限超過', today:'今日', next:'次に進める', week, high:'高優先', quick:'短時間', heavy:'重い作業', noDueHigh:'期限なし高優先', waiting:'待ち', review:'要確認', unestimated:'未見積', done:'完了'})[scope] || 'すべて';
  }
  function renderScopeSummary(){
    const q = currentFilter();
    const clearSearch=$('clearWorkFilter'); if(clearSearch)clearSearch.hidden=!q;
    const el = $('workScopeSummary'); if(!el) return;
    const parts = [];
    if (WORK_SCOPE !== 'all') parts.push(`表示中: ${scopeLabel(WORK_SCOPE)}`);
    if (q) parts.push(`検索: ${q}`);
    if (!parts.length) { el.hidden = true; el.innerHTML = ''; return; }
    el.hidden = false;
    el.innerHTML = `<span>${esc(parts.join(' / '))}</span><button type="button" class="mini" data-clear-work-scope>解除</button>`;
    const btn = el.querySelector('[data-clear-work-scope]');
    if (btn) btn.onclick = () => { WORK_SCOPE = 'all'; if($('workFilter')) $('workFilter').value = ''; render(); };
  }
  function savedFilters(){
    DATA.settings = Object.assign(defaultSettings(), DATA.settings || {});
    DATA.settings.savedWorkFilters = arr(DATA.settings.savedWorkFilters).filter(f => clean(f.label));
    return DATA.settings.savedWorkFilters;
  }
  function builtinWorkViews(){
    return [
      {id:'builtin_week', label:dueCountMode()==='calendar' ? '7日以内' : '7営業日以内', scope:'week', q:'', hint:'近い期限'},
      {id:'builtin_quick', label:'短時間', scope:'quick', q:'', hint:'30分以内'},
      {id:'builtin_heavy', label:'重い', scope:'heavy', q:'', hint:'1時間以上'},
      {id:'builtin_review', label:'要確認', scope:'review', q:'', hint:'長期待ち・期限なし高優先'},
      {id:'builtin_unestimated', label:'未見積', scope:'unestimated', q:'', hint:'重さ未入力'}
    ];
  }
  function workViewIsActive(view){ return (view.scope || 'all') === WORK_SCOPE && clean(view.q) === currentFilter(); }
  function applyWorkView(view){
    WORK_SCOPE = view.scope || 'all';
    const input = $('workFilter'); if (input) input.value = clean(view.q);
    render();
  }
  function renderSavedWorkViews(){
    const box = $('savedWorkViews'); if(!box) return;
    const custom = savedFilters();
    const canSave = WORK_SCOPE !== 'all' || !!currentFilter();
    box.innerHTML = '';
    const label = document.createElement('span'); label.className = 'saved-work-label'; label.textContent = '補助条件'; box.appendChild(label);
    [...builtinWorkViews(), ...custom].forEach(view => {
      const wrap = document.createElement('span'); wrap.className = 'saved-work-chip-wrap';
      const b = document.createElement('button'); b.type='button'; b.className = 'saved-work-chip'; b.textContent = view.label; b.title = view.hint || [scopeLabel(view.scope), view.q ? `検索: ${view.q}` : ''].filter(Boolean).join(' / ');
      const active=workViewIsActive(view); b.classList.toggle('active', active); b.setAttribute('aria-pressed',active?'true':'false'); b.onclick = () => applyWorkView(view); wrap.appendChild(b);
      if(!String(view.id||'').startsWith('builtin_')){
        const del = document.createElement('button'); del.type='button'; del.className='saved-work-delete'; del.textContent='×'; del.title='この条件を削除'; del.setAttribute('aria-label',`「${view.label}」を削除`);
        del.onclick = async e => { e.stopPropagation(); DATA.settings.savedWorkFilters = savedFilters().filter(f => f.id !== view.id); await saveSettings('よく見る条件を削除しました'); render(); };
        wrap.appendChild(del);
      }
      box.appendChild(wrap);
    });
    if (canSave) {
      const saveBtn = document.createElement('button'); saveBtn.type='button'; saveBtn.className='saved-work-save'; saveBtn.textContent='今の条件を保存'; saveBtn.onclick = saveCurrentWorkView; box.appendChild(saveBtn);
    }
  }
  function askPlainText(title, message, defaultValue = '', okLabel = '保存', cancelLabel = 'やめる'){
    return new Promise(resolve => {
      ACTIVE_PROMPT_CANCEL?.();
      const returnFocus=document.activeElement;
      const back = document.createElement('div'); back.className = 'center-confirm-backdrop';
      back.innerHTML = `<section class="center-confirm" role="dialog" aria-modal="true" aria-labelledby="centerConfirmTitle" aria-describedby="centerConfirmMessage"><h2 id="centerConfirmTitle">${esc(title)}</h2><p id="centerConfirmMessage">${esc(message)}</p><input class="confirm-input" type="text" value="${esc(defaultValue)}" aria-label="${esc(title)}"><div class="confirm-actions"><button type="button" class="ghost" data-cancel>${esc(cancelLabel)}</button><button type="button" class="danger-confirm" data-ok>${esc(okLabel)}</button></div></section>`;
      document.body.appendChild(back);
      const input = back.querySelector('.confirm-input');
      let settled=false;
      const cancel=()=>done(false);
      const done = v => { if(settled)return;settled=true;const value=v?clean(input.value):null;if(ACTIVE_PROMPT_CANCEL===cancel)ACTIVE_PROMPT_CANCEL=null;back.remove();if(returnFocus&&document.contains(returnFocus)&&typeof returnFocus.focus==='function')returnFocus.focus();resolve(value); };
      ACTIVE_PROMPT_CANCEL=cancel;
      back.querySelector('[data-cancel]').onclick = () => done(false);
      back.querySelector('[data-ok]').onclick = () => done(true);
      input.addEventListener('keydown', e => { if(e.key==='Escape'){e.preventDefault();done(false);} if(e.key==='Enter'){e.preventDefault();done(true);} });
      back.addEventListener('click', e => { if(e.target === back) done(false); });
      setTimeout(() => { input.focus(); input.select?.(); }, 20);
    });
  }
  async function saveCurrentWorkView(){
    const q = currentFilter();
    const defaultName = q ? `${scopeLabel(WORK_SCOPE)}・${q}` : scopeLabel(WORK_SCOPE);
    const label = await askPlainText('よく見る条件を保存', '現在の表示条件を、作業管理からすぐ呼び出せるようにします。', defaultName, '保存する');
    if(label === null) return;
    if(!label) return toast('名前を入力してください');
    const filters = savedFilters().filter(f => clean(f.label) !== label).slice(0, 10);
    filters.unshift({id:uid('wf'), label, scope:WORK_SCOPE, q});
    DATA.settings.savedWorkFilters = filters.slice(0, 12);
    await saveSettings('よく見る条件を保存しました');
    render();
  }

  const CASE_STATUSES = ['事案交付','事前通知済','着手済','反面済','再臨宅済','重審済','修正勧奨済','加算税賦課済','完了'];
  const CASE_STARTED = new Set(['着手済','反面済','再臨宅済','重審済','修正勧奨済','加算税賦課済']);
  function normalizeCaseStatus(v){ const s=clean(v); return CASE_STATUSES.includes(s) ? s : (s==='調査中'||s==='対応中'?'着手済':(s==='確認待ち'?'事前通知済':(s==='完了'?'完了':'事案交付'))); }
  function isSpecDone(x){ return !!x?.done || ['done','完了'].includes(clean(x?.status)); }
  function caseTargets(c){ return arr(c?.targetPersons || c?.targets || c?.subjects).map((x,i)=> typeof x === 'string' ? {id:`target_${i}`, name:x} : Object.assign({id:`target_${i}`}, x || {})); }
  function caseTitle(c){ return clean(c?.title || c?.name || '無題の事案'); }
  function sourceKey(type, id, subId=''){ return `speculum:${type}:${id}${subId ? ':' + subId : ''}`; }
  function taskLinkedSource(type, id, subId=''){
    return TASK_SOURCE_KEYS.has(sourceKey(type, id, subId));
  }
  function dueInboxItems(){
    const items=[];
    [['deadlines','期限'],['jimu','事務']].forEach(([collection,label])=>{
      arr(SPEC[collection]).forEach(x=>{ if(!isSpecDone(x)) items.push({...x, _inboxKind:'due', _collection:collection, _label:label, _date:x.due || '', _linked:taskLinkedSource(collection, x.id)}); });
    });
    return items.sort((a,b)=>urgencyRank({due:a._date, priority:a.priority})-urgencyRank({due:b._date, priority:b.priority}) || String(a._date||'9999').localeCompare(String(b._date||'9999')) || clean(a.title||a.name).localeCompare(clean(b.title||b.name)));
  }
  function caseInboxItems(){
    const out=[];
    arr(SPEC.cases).forEach(c=>{
      const targets=caseTargets(c);
      const base = targets.length ? targets : [null];
      base.forEach(t=>{
        const status=normalizeCaseStatus((t||{}).status || c.status);
        if(status === '完了') return;
        const tid=clean((t||{}).id) || 'case';
        const targetName=clean((t||{}).name || (t||{}).targetName || c.client || '');
        const dueDate=clean((t||{}).nextDate || c.nextDate || '');
        const started=clean((t||{}).startedAt || c.startedAt || '');
        const dueDiff=dueDate ? diff(dueDate) : null;
        const calDiff=dueDate ? calendarDiff(dueDate) : null;
        const age=started ? daysSince(started) : null;
        let alert='進行中';
        if(calDiff !== null && calDiff < 0) alert='期限超過';
        else if(dueDiff !== null && dueDiff >= 0 && dueDiff <= 7) alert=dueCountMode()==='calendar'?'7日内':'7営業日内';
        else if(age !== null && age >= 90 && CASE_STARTED.has(status)) alert='長期化';
        else if(!dueDate) alert='次回予定なし';
        out.push({_inboxKind:'case', case:c, target:t, id:c.id, targetId:tid, title:targetName ? `${targetName} / ${caseTitle(c)}` : caseTitle(c), _date:dueDate, status, alert, owner:clean((t||{}).owner || c.owner || ''), nextAction:clean((t||{}).nextAction || c.nextAction || ''), _linked:taskLinkedSource('case-target', c.id, tid)});
      });
    });
    return out.sort((a,b)=>urgencyRank({due:a._date, priority:a.alert==='期限超過'?'high':'normal'})-urgencyRank({due:b._date, priority:b.alert==='期限超過'?'high':'normal'}) || String(a._date||'9999').localeCompare(String(b._date||'9999')) || a.title.localeCompare(b.title));
  }
  function workInboxCounts(dueItems, caseItems){
    const dueUnlinked=dueItems.filter(x=>!x._linked).length;
    const caseUnlinked=caseItems.filter(x=>!x._linked).length;
    const dueNear=dueItems.filter(x=>{ const d=diff(x._date); return d!==null && d>=0 && d<=7; }).length;
    const caseRisk=caseItems.filter(x=>['期限超過','長期化','次回予定なし'].includes(x.alert)).length;
    return {dueUnlinked, caseUnlinked, dueNear, caseRisk};
  }
  function prepareRenderInboxData(){
    const dueItems = dueInboxItems();
    const caseItems = caseInboxItems();
    return {dueItems, caseItems, counts:workInboxCounts(dueItems, caseItems)};
  }
  function currentRenderInboxData(){ return RENDER_INBOX_DATA || prepareRenderInboxData(); }
  async function removeTasksByIds(ids = [], message = '作業に追加した内容を元に戻しました'){
    return removeAddedRecords('tasks', ids, message);
  }
  async function removeAddedRecords(collection, ids = [], message = '追加を元に戻しました'){
    const set = new Set(arr(ids).filter(Boolean));
    if(!set.size) return;
    const kind = collection === 'cycles' || collection === 'cycleTasks' ? 'cycleTasks' : 'tasks';
    const localItems = (kind === 'cycleTasks' ? DATA.cycleTasks : DATA.tasks).filter(t => set.has(t.id)).map(t => ({id:t.id, updatedAt:t.updatedAt || ''}));
    const j = await api('/api/continuum/items-delete', {method:'POST', body:JSON.stringify({collection:kind, ids:[...set], baseHash:HASH, baseItems:localItems})});
    HASH = j.hash || HASH;
    if(j.merged){ await load(); }
    else if(kind === 'cycleTasks') { DATA.cycleTasks = DATA.cycleTasks.filter(t => !set.has(t.id)); rebuildCycleIndex(); }
    else { DATA.tasks = DATA.tasks.filter(t => !set.has(t.id)); rebuildContinuumIndexes(); }
    render();
    if(message)toast(j.merged ? `${message}（最新データを反映）` : message);
    return j;
  }
  function addedRecordUndo(collection, ids, message){
    const list = arr(ids).filter(Boolean);
    return list.length ? {actionLabel:'元に戻す', onAction:()=>removeAddedRecords(collection, list, message)} : undefined;
  }
  async function taskFromDueItem(collection, x){
    if(!x?.id) return;
    if(taskLinkedSource(collection, x.id)) return toast('この項目は追加済みです');
    const importKey=`${collection}:${x.id}`;
    if(PENDING_SOURCE_IMPORTS.has(importKey))return toast('この項目を追加しています');
    PENDING_SOURCE_IMPORTS.add(importKey); if(workOverviewIsOpen())renderWorkInbox();
    const label = collection === 'jimu' ? '事務' : '期限';
    const task = {id:uid('wk'), title:`${label}: ${clean(x.title || x.name) || '無題'}`, status:'next', priority:x.priority || 'normal', due:clean(x.due), caseId:clean(x.caseId), personIds:arr(x.personIds), peopleText:clean(x.peopleText), source:sourceKey(collection, x.id), nextAction:clean(x.nextAction), note:clean(x.note), createdAt:new Date().toISOString(), updatedAt:new Date().toISOString()};
    try{
      const j = await api('/api/continuum/task-upsert', {method:'POST', body:JSON.stringify({item:task, baseHash:HASH})});
      const reloaded = await applySavedWorkMutation('tasks', j, task);
      render();
      toast(reloaded ? '作業に追加しました（最新データを反映）' : '作業に追加しました', {actionLabel:'元に戻す', onAction:()=>removeTasksByIds([j.item?.id || task.id])});
    }catch(err){toast(err?.message || '作業に追加できませんでした');}
    finally{PENDING_SOURCE_IMPORTS.delete(importKey);if(workOverviewIsOpen())renderWorkInbox();}
  }
  async function taskFromCaseInbox(item){
    if(!item?.case?.id) return;
    if(taskLinkedSource('case-target', item.case.id, item.targetId)) return toast('この事案は追加済みです');
    const importKey=`case-target:${item.case.id}:${item.targetId}`;
    if(PENDING_SOURCE_IMPORTS.has(importKey))return toast('この事案を追加しています');
    PENDING_SOURCE_IMPORTS.add(importKey); if(workOverviewIsOpen())renderWorkInbox();
    const task = {id:uid('wk'), title:`事案確認: ${item.title}`, status:'next', priority:'high', due:clean(item._date), caseId:item.case.id, personIds:[], peopleText:'', source:sourceKey('case-target', item.case.id, item.targetId), nextAction:item.nextAction || '次の一手を確認', note:[item.alert, item.owner].filter(Boolean).join(' / '), createdAt:new Date().toISOString(), updatedAt:new Date().toISOString()};
    try{
      const j = await api('/api/continuum/task-upsert', {method:'POST', body:JSON.stringify({item:task, baseHash:HASH})});
      const reloaded = await applySavedWorkMutation('tasks', j, task);
      render();
      toast(reloaded ? '事案を作業に追加しました（最新データを反映）' : '事案を作業に追加しました', {actionLabel:'元に戻す', onAction:()=>removeTasksByIds([j.item?.id || task.id])});
    }catch(err){toast(err?.message || '事案を作業に追加できませんでした');}
    finally{PENDING_SOURCE_IMPORTS.delete(importKey);if(workOverviewIsOpen())renderWorkInbox();}
  }
  function inboxRowHTML(x, idx){
    if(x._inboxKind === 'case') { const pending=PENDING_SOURCE_IMPORTS.has(`case-target:${x.case.id}:${x.targetId}`); return `<article class="work-inbox-row ${x._linked?'linked':''}"><div><b>${esc(x.title)}</b><span>${esc(['事案', x.alert, x._date?fmt(x._date):'次回予定なし', x.status, x.owner].filter(Boolean).join(' / '))}</span></div><button type="button" class="mini" data-inbox-case="${idx}" ${pending?'disabled':''}>${pending?'追加中…':(x._linked?'追加済み':'作業に追加')}</button></article>`; }
    const pending=PENDING_SOURCE_IMPORTS.has(`${x._collection}:${x.id}`);
    return `<article class="work-inbox-row ${x._linked?'linked':''}"><div><b>${esc(clean(x.title || x.name) || '無題')}</b><span>${esc([x._label, x._date?fmt(x._date):'期限なし', x._date?due(x._date):'', caseName(x.caseId), peopleLabel(x)].filter(Boolean).join(' / '))}</span></div><button type="button" class="mini" data-inbox-due="${idx}" ${pending?'disabled':''}>${pending?'追加中…':(x._linked?'追加済み':'作業に追加')}</button></article>`;
  }
  function setImportAllBusy(on){
    IMPORT_ALL_BUSY=!!on;
    $$('[data-import-all],#importFromSpeculumBtn').forEach(button=>{
      if(!button.dataset.idleLabel)button.dataset.idleLabel=button.textContent||'まとめて追加';
      button.disabled=IMPORT_ALL_BUSY;
      button.textContent=IMPORT_ALL_BUSY?'追加中…':button.dataset.idleLabel;
    });
  }
  async function importAllFromSpeculum(){
    if(IMPORT_ALL_BUSY)return toast('台帳の項目を追加しています');
    setImportAllBusy(true);
    try{
      const j=await api('/api/continuum/import-speculum-actions',{method:'POST',body:'{}'});
      const ids=arr(j.items).map(x=>x.id).filter(Boolean);
      await load(); render();
      toast(`${j.added||0}件を作業に追加しました`, addedRecordUndo('tasks', ids, '作業にまとめて追加した内容を元に戻しました'));
      return true;
    }catch(err){toast(err?.message || '台帳の項目を追加できませんでした');return false;}
    finally{setImportAllBusy(false);}
  }
  function renderWorkInbox(){
    const box=$('workInbox'); if(!box)return;
    const {dueItems, caseItems, counts}=currentRenderInboxData();
    const queue=[...dueItems.filter(x=>!x._linked).slice(0,6), ...caseItems.filter(x=>!x._linked).slice(0,6)].sort((a,b)=>urgencyRank({due:a._date, priority:a.alert==='期限超過'?'high':a.priority})-urgencyRank({due:b._date, priority:b.alert==='期限超過'?'high':b.priority}) || String(a._date||'9999').localeCompare(String(b._date||'9999')) || String(a.title || a.name || '').localeCompare(String(b.title || b.name || ''))).slice(0,6);

    const emptyInbox = '<div class="empty work-inbox-empty"><b>未追加の項目はありません</b><span>必要なら台帳を開いて確認できます。</span><div class="empty-actions"><button type="button" class="mini" data-open-ledger>期限・事務</button><button type="button" class="mini" data-open-cases>事案</button></div></div>';
    box.className = `work-inbox ${queue.length ? 'needs-action' : 'quiet'}`;
    box.innerHTML = `<div class="work-inbox-head"><div><span class="section-kicker">台帳連携</span><h3>台帳から作業に追加</h3><p>処理する項目だけ作業カードにします。</p></div><div class="work-inbox-actions"><button type="button" class="mini" data-open-calendar>日付</button><button type="button" class="mini" data-open-ledger>台帳</button><button type="button" class="mini primary-inline" data-import-all>未追加をまとめて追加</button></div></div><div class="work-inbox-metrics"><button type="button" data-open-ledger><b>${counts.dueUnlinked}</b><span>未追加の期限・事務</span></button><button type="button" data-open-ledger><b>${counts.dueNear}</b><span>近い期限・事務</span></button><button type="button" data-open-cases><b>${counts.caseUnlinked}</b><span>未追加の事案</span></button><button type="button" data-open-cases><b>${counts.caseRisk}</b><span>要確認の事案</span></button></div><details class="work-inbox-list" ${queue.length ? 'open' : ''}><summary><span>未追加の項目</span><span class="fold-count">${queue.length ? `${queue.length}件` : 'なし'}</span></summary><div class="work-inbox-list-body">${queue.length ? queue.map((x,i)=>inboxRowHTML(x,i)).join('') : emptyInbox}</div></details>`;
    box.querySelector('[data-open-calendar]')?.addEventListener('click',()=>openWorkspace('speculum:schedule'));
    box.querySelectorAll('[data-open-ledger]').forEach(b=>b.addEventListener('click',()=>openWorkspace('speculum:tasks')));
    box.querySelectorAll('[data-open-cases]').forEach(b=>b.addEventListener('click',()=>openWorkspace('speculum:cases')));
    box.querySelector('[data-import-all]')?.addEventListener('click',importAllFromSpeculum);
    setImportAllBusy(IMPORT_ALL_BUSY);
    box.querySelectorAll('[data-inbox-due]').forEach(b=>b.addEventListener('click',()=>{ const item=queue[Number(b.dataset.inboxDue)]; if(item&&!item._linked) taskFromDueItem(item._collection, item); }));
    box.querySelectorAll('[data-inbox-case]').forEach(b=>b.addEventListener('click',()=>{ const item=queue[Number(b.dataset.inboxCase)]; if(item&&!item._linked) taskFromCaseInbox(item); }));
  }

  async function saveContinuumPatch(patch, message=''){
    const j = await api('/api/continuum/patch', {method:'POST', body:JSON.stringify(Object.assign({baseHash:HASH}, patch || {}))});
    HASH = j.hash || HASH;
    if(j.merged){ await load(); }
    else if(j.data?.settings) DATA.settings = Object.assign(defaultSettings(), j.data.settings || DATA.settings || {});
    if(message) toast(j.merged ? `${message}（最新データを反映）` : message);
    return j;
  }
  function memoValue(){ return String($('workMemo')?.value ?? DATA.memo ?? ''); }
  function scheduleMemoSave(delay=900, showNotice=false){
    clearTimeout(MEMO_SAVE_TIMER);
    if(showNotice) MEMO_SAVE_NOTICE = true;
    MEMO_SAVE_TIMER = setTimeout(flushMemoSave, Math.max(0, Number(delay) || 0));
  }
  async function flushMemoSave(){
    clearTimeout(MEMO_SAVE_TIMER);
    if(MEMO_SAVE_RUNNING){ MEMO_SAVE_PENDING = true; return false; }
    const value=memoValue();
    const showNotice=MEMO_SAVE_NOTICE; MEMO_SAVE_NOTICE=false;
    if(value===MEMO_LAST_SAVED){ if(showNotice)toast('メモは保存済みです'); return true; }
    MEMO_SAVE_RUNNING=true; MEMO_SAVE_PENDING=false; DATA.memo=value;
    let saved=false;
    try{
      const result=await saveContinuumPatch({memo:value}, '');
      MEMO_LAST_SAVED=result?.merged ? String(DATA.memo || '') : value;
      DATA.memo=MEMO_LAST_SAVED;
      saved=true;
      if(showNotice)toast(result?.merged?'メモを保存しました（最新データを反映）':'メモを保存しました');
      return true;
    }catch(err){
      MEMO_SAVE_NOTICE=false;
      toast(err?.message ? `メモを保存できませんでした：${err.message}` : 'メモを保存できませんでした');
      return false;
    }finally{
      MEMO_SAVE_RUNNING=false;
      const needsNext=MEMO_SAVE_PENDING || memoValue()!==MEMO_LAST_SAVED;
      MEMO_SAVE_PENDING=false;
      if(saved && needsNext)scheduleMemoSave(0, MEMO_SAVE_NOTICE);
    }
  }
  async function settleMemoBeforeRestore(){
    clearTimeout(MEMO_SAVE_TIMER);
    if(MEMO_SAVE_RUNNING){
      MEMO_SAVE_PENDING=true;
      const deadline=performance.now()+15000;
      while(MEMO_SAVE_RUNNING && performance.now()<deadline)await new Promise(resolve=>setTimeout(resolve,25));
      if(MEMO_SAVE_RUNNING)throw new Error('メモの保存が終わっていません。少し待ってから復元してください');
    }
    if(memoValue()!==MEMO_LAST_SAVED){
      const saved=await flushMemoSave();
      if(!saved)throw new Error('入力中のメモを保存できないため、復元を中止しました');
    }
  }
  function resetMemoSaveAfterRestore(){
    clearTimeout(MEMO_SAVE_TIMER);
    MEMO_SAVE_PENDING=false;
    MEMO_SAVE_NOTICE=false;
  }
  async function saveSettings(message='表示設定を保存しました'){
    DATA.settings = Object.assign(defaultSettings(), DATA.settings || {});
    const snapshot=JSON.parse(JSON.stringify(DATA.settings));
    const run=SETTINGS_SAVE_CHAIN.catch(()=>{}).then(()=>saveContinuumPatch({settings:snapshot}, message));
    SETTINGS_SAVE_CHAIN=run.catch(()=>{});
    try{return await run;}
    catch(err){toast(err?.message ? `表示設定を保存できませんでした：${err.message}` : '表示設定を保存できませんでした');return {ok:false,failed:true};}
  }
  function syncSettingsUI(){
    DATA.settings = Object.assign(defaultSettings(), DATA.settings || {});
    [['doneVisibleDays','doneVisibleDays'],['boardLimit','boardLimit'],['boardDensity','boardDensity'],['workSortMode','workSortMode'],['dueDayCountMode','dueDayCountMode']].forEach(([id,key])=>{ const el=$(id); if(el) el.value=String(DATA.settings[key]); });
    const weekChip = document.querySelector('[data-work-scope="week"]'); if(weekChip) weekChip.textContent = dueCountMode()==='calendar' ? '7日以内' : '7営業日以内';
    const hint=$('dueDayCountHint'); if(hint) hint.textContent = dueCountMode()==='calendar' ? '期限までの日数は土日祝日を含めて数えます。' : (holidayDataAvailable() ? '期限までの日数は土日祝日を除いた平日のみで数えます。' : '期限までの日数は平日のみで数えます。祝日データ未取得時は土日のみ除外します。');
    $$('[data-work-scope]').forEach(b => { const active=(b.dataset.workScope || 'all') === WORK_SCOPE; b.classList.toggle('active',active); b.setAttribute('aria-pressed',active?'true':'false'); });
    renderBulkActions();
  }
  function todayWorkItems(){
    const active = DATA.tasks.filter(t=>!isDoneStatus(t));
    const cycles = DATA.cycleTasks.filter(c=>cycleState(c)==='active').map(c=>({...c, due:c.nextRunDate, status:cycleColumnStatus(c), rule:c.rule || '周期'}));
    return [...active.filter(t=>validStatus(t.status)==='today' || calendarDiff(t.due)===0), ...cycles.filter(t=>validStatus(t.status)==='today' || calendarDiff(t.due)===0)];
  }
  function renderWorkDensityNotice(){
    const box = $('workDensityNotice'); if(!box) return;
    const active = DATA.tasks.filter(t=>!isDoneStatus(t));
    const cycles = DATA.cycleTasks.filter(c=>cycleState(c)==='active');
    const limit = baseBoardLimit();
    const counts = columns.map(([key,label]) => {
      const taskCount = DATA.tasks.filter(t=>validStatus(t.status)===key && shouldShowDone(t, WORK_SCOPE==='done')).filter(workScopeMatch).length;
      const cycleCount = DATA.cycleTasks.filter(c=>cycleColumnStatus(c)===key && shouldShowCycle(c, currentFilter())).filter(cycleScopeMatch).length;
      return {key,label,count:taskCount + cycleCount};
    });
    const crowded = active.length + cycles.length >= 36 || counts.some(x => limit !== Infinity && x.count > limit);
    document.body.classList.toggle('work-density-crowded', crowded);
    if(!crowded){ box.hidden = true; box.innerHTML = ''; return; }
    const top = counts.filter(x=>x.count).sort((a,b)=>b.count-a.count).slice(0,4);
    box.hidden = false;
    box.innerHTML = `<div><b>作業が多めです</b><span>各列は上位だけ表示し、必要な列だけ「さらに表示」で開きます。検索・よく見る条件で絞ると軽く見られます。</span></div><div class="density-chips">${top.map(x=>`<button type="button" data-density-status="${esc(x.key)}"><b>${esc(x.count)}</b><span>${esc(x.label)}</span></button>`).join('')}</div>`;
    $$('[data-density-status]', box).forEach(b=>b.addEventListener('click',()=>{ WORK_SCOPE = b.dataset.densityStatus === 'done' ? 'done' : 'all'; render(); document.querySelector(`.work-column-${b.dataset.densityStatus}`)?.scrollIntoView({behavior:'smooth', block:'start'}); }));
  }

  function renderWorkCapacityStrip(){
    const box = $('workCapacityStrip'); if(!box) return;
    const items = todayWorkItems();
    const normalTasks = items.filter(x=>!x.rule);
    const minutes = totalEstimate(normalTasks);
    const estimated = normalTasks.filter(x=>estimateMinutes(x)).length;
    const cap = 360;
    const pct = Math.min(100, Math.max(items.length ? 5 : 0, Math.round((minutes / cap) * 100)));
    let level='calm', label='余裕あり', advice='今日列は軽めです。必要なら短時間作業から始められます。';
    if(minutes >= 240 || items.length >= 6){ level='busy'; label='要整理'; advice='時間が重くなっています。重い作業を今日から外すか、短時間作業を先に片づけます。'; }
    if(minutes >= 420 || items.length >= 10){ level='heavy'; label='詰まり注意'; advice='今日に詰め込みすぎです。期限・危険以外は次へ戻すのが安全です。'; }
    if(!items.length) { label='落ち着き'; advice='今日やる作業はありません。必要なものだけ追加します。'; }
    const missing = normalTasks.length - estimated;
    box.className = `work-capacity-strip ${level}`;
    box.innerHTML = `<div class="capacity-main"><span class="section-kicker">今日の見通し</span><b>今日の容量</b><em>${esc(label)}</em></div><div class="capacity-meter" aria-hidden="true"><i style="width:${pct}%"></i></div><div class="capacity-copy"><b>${esc(items.length)}件${minutes ? ' / ' + esc(durationLabel(minutes)) : ''}${missing > 0 ? ' / 未見積' + esc(missing) : ''}</b><span>${esc(advice)}</span></div><button type="button" class="mini" data-capacity-today>今日列を見る</button>`;
    box.querySelector('[data-capacity-today]')?.addEventListener('click',()=>{ WORK_SCOPE='today'; render(); $('workBoard')?.scrollIntoView({behavior:'smooth', block:'start'}); });
  }
  function workOverviewIsOpen(){ const details=$('workOverview'); return !details || details.open; }
  function cyclePanelIsOpen(){ const details=$('cyclePanel'); return !details || details.open; }
  function renderOverviewViews(){
    RENDER_INBOX_DATA = prepareRenderInboxData();
    try {
      renderStats();
      renderWorkCapacityStrip();
      renderWorkInbox();
    } finally {
      RENDER_INBOX_DATA = null;
    }
  }
  function renderTaskViews(){
    document.body.classList.toggle('select-mode', SELECT_MODE);
    const sm=$('selectionModeBtn'); if(sm){sm.textContent = SELECT_MODE ? '複数選択を終了' : '複数選択';sm.setAttribute('aria-pressed',SELECT_MODE?'true':'false');}
    syncSettingsUI();
    renderWorkDensityNotice();
    if(workOverviewIsOpen()) renderOverviewViews();
    renderScopeSummary();
    renderSavedWorkViews();
    renderBoard();
    renderBulkActions();
  }
  function renderFilterResults(){
    // 検索入力では、検索に関係しない台帳取込・統計・保存条件を作り直さない。
    document.body.classList.toggle('select-mode', SELECT_MODE);
    renderWorkDensityNotice();
    renderScopeSummary();
    renderBoard();
    if(cyclePanelIsOpen()) renderCycles();
    renderBulkActions();
  }
  function render(){
    renderTaskViews();
    if(cyclePanelIsOpen()) renderCycles();
    const memo=$('workMemo');
    if(memo && document.activeElement !== memo && String(memo.value || '')===MEMO_LAST_SAVED) memo.value = DATA.memo || '';
  }

  function cycleState(c){ const s = clean(c?.state).toLowerCase(); if(['active','paused','ended'].includes(s)) return s; if(validStatus(c?.status)==='done' || clean(c?.endedAt)) return 'ended'; if(clean(c?.pausedAt)) return 'paused'; return 'active'; }
  function normalizedCycleStateStatus(c={}){
    const state=cycleState(c);
    let status=validStatus(c?.status || 'next');
    if(state==='paused')status='waiting';
    else if(state==='ended')status='done';
    else if(!['today','next'].includes(status))status='next';
    return {state,status};
  }
  function cycleColumnStatus(c){ return normalizedCycleStateStatus(c).status; }
  function cycleScopeMatch(c){ return workScopeMatch({...c, status:cycleColumnStatus(c), due:c.nextRunDate}); }
  function shouldShowCycle(c, q){
    const s = cycleState(c);
    if (s === 'paused' && !q && WORK_SCOPE !== 'waiting') return false;
    if (s === 'ended' && !q && WORK_SCOPE !== 'done') return false;
    if (s === 'ended' && !q && WORK_SCOPE === 'all') return shouldShowDone({...c,status:'done'}, false);
    return true;
  }

  function renderStats(){
    const box=$('workStats'); if(!box)return;
    const normalActive=DATA.tasks.filter(t=>!isDoneStatus(t));
    const cycleActive=DATA.cycleTasks.filter(c=>cycleState(c)==='active').map(c=>({...c, due:c.nextRunDate, status:cycleColumnStatus(c)}));
    const allActive=[...normalActive, ...cycleActive];
    const overdue=allActive.filter(t=>calendarDiff(t.due)!==null&&calendarDiff(t.due)<0).length;
    const todayItems=allActive.filter(t=>calendarDiff(t.due)===0||validStatus(t.status)==='today');
    const todayCount=todayItems.length;
    const todayMinutes=totalEstimate(todayItems.filter(t=>!t.rule));
    const unestimatedToday=todayItems.filter(t=>!t.rule && !estimateMinutes(t) && (validStatus(t.status)==='today' || calendarDiff(t.due)!==null || t.priority==='high')).length;
    const soon=allActive.filter(t=>{const d=diff(t.due);return d!==null&&d>=0&&d<=7;}).length;
    const waiting=[...DATA.tasks, ...DATA.cycleTasks.map(c=>({...c,status:cycleColumnStatus(c)}))].filter(t=>validStatus(t.status)==='waiting').length;
    const doneAll=[...DATA.tasks, ...DATA.cycleTasks.map(c=>({...c,status:cycleColumnStatus(c)}))].filter(isDoneStatus);
    const hiddenDone=doneAll.filter(t=>!shouldShowDone(t, false)).length;
    const weekLabel = dueCountMode()==='calendar' ? '7日以内' : '7営業日以内';
    const todayMeta = todayMinutes ? `見積${durationLabel(todayMinutes)}` : (todayCount ? '見積未入力' : '');
    const stats = [
      ['today','今日',todayCount,todayMeta],
      ['unestimated','未見積',unestimatedToday,'重さ未入力'],
      ['week',weekLabel,soon,''],
      ['overdue','超過',overdue,''],
      ['waiting','待ち',waiting,''],
      ['done','完了を表示',doneAll.length-hiddenDone,''],
      ['done','過去の完了',hiddenDone,'']
    ];
    box.innerHTML=stats.map(([scope,k,n,meta])=>`<button type="button" class="work-stat ${(scope===WORK_SCOPE)?'active':''}" data-stat-scope="${esc(scope)}"><b>${esc(n)}</b><span>${esc(k)}</span>${meta ? `<em>${esc(meta)}</em>` : ''}</button>`).join('');
    $$('[data-stat-scope]', box).forEach(b => b.onclick = () => { WORK_SCOPE = b.dataset.statScope || 'all'; render(); });
  }
  function columnMiniStats(tasks){
    const overdue = tasks.filter(t=>!isDoneStatus(t) && calendarDiff(t.due)!==null && calendarDiff(t.due)<0).length;
    const todayN = tasks.filter(t=>!isDoneStatus(t) && (calendarDiff(t.due)===0 || validStatus(t.status)==='today')).length;
    const high = tasks.filter(t=>!isDoneStatus(t) && t.priority==='high').length;
    const minutes = totalEstimate(tasks.filter(t=>!isDoneStatus(t) && !t.rule));
    const parts = []; if (overdue) parts.push(`超過${overdue}`); if (todayN) parts.push(`今日${todayN}`); if (high) parts.push(`高優先${high}`); if (minutes) parts.push(`見積${durationLabel(minutes)}`); return parts.join(' / ');
  }
  function applyColumnLimit(prefix, key, mode){ DATA.settings = Object.assign(defaultSettings(), DATA.settings || {}); const k=`limit_${prefix}_${key}`; if(mode==='more'){ const cur = columnLimit(prefix,key); DATA.settings[k] = String(cur === Infinity ? 'all' : cur + 10); } if(mode==='all') DATA.settings[k]='all'; if(mode==='fold') delete DATA.settings[k]; saveSettings('表示件数を更新しました').then(render); }
  function renderColumnContents(box, items, prefix, key, makeCard, emptyText){
    const limit = columnLimit(prefix, key);
    const visible = items.slice(0, limit);
    if (!visible.length) { const e=document.createElement('div'); e.className='empty'; e.textContent=emptyText; box.appendChild(e); }
    const grouped = new Map();
    const manualOrder=prefix==='task' && sortMode()==='manual';
    if(manualOrder)grouped.set('手動順',visible);
    else visible.forEach(t => { const bucket=dueBucket(t); if(!grouped.has(bucket))grouped.set(bucket,[]); grouped.get(bucket).push(t); });
    (manualOrder?['手動順']:bucketOrder()).filter(bucket=>grouped.has(bucket)).forEach(bucket=>{
      const divider=document.createElement('div'); divider.className='due-divider';
      const name=document.createElement('span'); name.textContent=bucket; divider.appendChild(name);
      const count=document.createElement('small'); count.textContent=String(grouped.get(bucket).length); divider.appendChild(count);
      box.appendChild(divider);
      grouped.get(bucket).forEach(t=>box.appendChild(makeCard(t)));
    });
    if (items.length > visible.length) {
      const wrap = document.createElement('div'); wrap.className = 'column-more-actions';
      wrap.innerHTML = `<button type="button" class="column-more" data-more>さらに10件表示（残り${esc(items.length-visible.length)}件）</button><button type="button" class="column-more" data-all>この列だけ全表示</button><button type="button" class="column-more" data-fold>折りたたむ</button>`;
      wrap.querySelector('[data-more]').onclick = () => applyColumnLimit(prefix, key, 'more');
      wrap.querySelector('[data-all]').onclick = () => applyColumnLimit(prefix, key, 'all');
      wrap.querySelector('[data-fold]').onclick = () => applyColumnLimit(prefix, key, 'fold');
      box.appendChild(wrap);
    }
  }
  function columnGuide(key){
    return ({today:'今ここで取り組む', next:'着手前の候補', waiting:'相手待ち・保留', done:'完了済み'})[key] || '';
  }
  function cycleColumnGuide(key){
    return ({today:'今回処理する周期作業', next:'次回まで継続して監視', waiting:'休止中。再開すると処理対象に戻ります', done:'終了した周期作業'})[key] || '';
  }
  function renderBoard(){
    const q = currentFilter(); const qTokens=searchTokens(q); const board = $('workBoard'); if(!board) return; board.innerHTML = ''; board.classList.toggle('compact-board', boardDensity() === 'compact');
    const byStatus={today:[],next:[],waiting:[],done:[]};
    DATA.tasks.forEach(task=>byStatus[validStatus(task.status)].push(task));
    let visibleDoneCount = 0;
    columns.forEach(([key,label]) => {
      const forceDone = WORK_SCOPE === 'done' || !!q;
      const allInColumn = byStatus[key];
      const hiddenDone = key === 'done' && !q ? allInColumn.filter(t => !shouldShowDone(t, false)).length : 0;
      let tasks = allInColumn;
      if (key === 'done' && !forceDone) tasks = tasks.filter(t => shouldShowDone(t, false));
      if (WORK_SCOPE !== 'all') tasks = tasks.filter(workScopeMatch);
      if (qTokens.length) tasks = tasks.filter(t => matchesSearchTokens(qTokens, TASK_SEARCH_BY_ID.get(t.id) || searchableTask(t)));
      tasks = tasks.slice().sort(sortCards);
      if (key === 'done') visibleDoneCount = tasks.length;
      const col = document.createElement('article'); col.className = `work-column work-column-${key}`;
      const mini = columnMiniStats(tasks); const guide = columnGuide(key);
      col.innerHTML = `<h2><span>${esc(label)}<small>${mini ? esc(mini) : ''}</small><em class="column-guide">${esc(guide)}</em></span><span class="work-count">${tasks.length}</span></h2><div class="tasks" data-status="${esc(key)}"></div>`;
      const box = col.querySelector('.tasks'); bindDrop(box, async payload => { if(payload.type === 'task') await moveTask(payload.id, key); });
      const emptyByColumn = {today:'今日の作業はありません', next:'着手前の作業はありません', waiting:'待ちの作業はありません', done:'表示する完了作業はありません'};
      renderColumnContents(box, tasks, 'task', key, taskCard, q ? '条件に合う作業はありません。' : (emptyByColumn[key] || 'ここにはまだありません。'));
      if (hiddenDone) { const note = document.createElement('button'); note.type='button'; note.className = 'done-hidden-note'; note.textContent = `古い完了作業 ${hiddenDone}件を見る`; note.onclick=()=>{WORK_SCOPE='done';render();}; box.appendChild(note); }
      board.appendChild(col);
    });
    board.classList.toggle('done-column-empty', visibleDoneCount === 0 && WORK_SCOPE !== 'done' && !q);
  }
  function metaClass(value){
    const s=clean(value);
    const cls=['meta-chip'];
    if(/超過|期限切れ|危険|見つかりません|変更されています|エラー/.test(s)) cls.push('meta-danger');
    if(/^\d{4}\/|^\d{1,2}\/|今日|明日|明後日|あと\d+|営業日|日以内|完了|終了|前回/.test(s)) cls.push('meta-date');
    if(/高優先|低優先|重要|通常/.test(s)) cls.push('meta-priority');
    if(/担当|関係者|人物|さん$/.test(s)) cls.push('meta-person');
    if(/事案|調査/.test(s)) cls.push('meta-case');
    if(/^(今日やる|次に進める|待ち|完了|継続中|休止中|終了済み|周期|列:)/.test(s)) cls.push('meta-status');
    if(/次:|元データ|リンク|一致|見積|時間|分/.test(s)) cls.push('meta-note');
    return cls.join(' ');
  }
  function cardMeta(parts){ return parts.filter(Boolean).map(x=>`<span class="${metaClass(x)}">${esc(x)}</span>`).join(''); }
  function cardMetaBlock(primaryParts, relatedParts = []){
    const primary = cardMeta(primaryParts);
    const related = cardMeta(relatedParts);
    return `<div class="item-meta meta-primary">${primary}</div>${related ? `<div class="item-meta meta-related">${related}</div>` : ''}`;
  }

  function sourceParts(src){ const s = clean(src); const p=s.split(':'); return {raw:s, parts:p, app:p[0], type:p[1], id:p[2], subId:p[3]}; }
  function sourceFind(t){
    const src = sourceParts(t.source || t.sourceInfo?.ref || t.sourceInfo?.legacy);
    if (!src.raw || src.app !== 'speculum') return null;
    if (src.type === 'deadlines') { const x=SOURCE_INDEX.deadlines.get(src.id); return x ? {kind:'期限', item:x, due:x.due, title:`期限: ${x.title || x.name || ''}`} : {missing:true, kind:'期限'}; }
    if (src.type === 'jimu') { const x=SOURCE_INDEX.jimu.get(src.id); return x ? {kind:'事務', item:x, due:x.due, title:`事務: ${x.title || x.name || ''}`} : {missing:true, kind:'事務'}; }
    if (src.type === 'events') { const x=SOURCE_INDEX.events.get(src.id); return x ? {kind:'予定', item:x, due:x.date, title:`予定: ${x.title || ''}`} : {missing:true, kind:'予定'}; }
    if (src.type === 'cases') { const x=SOURCE_INDEX.cases.get(src.id); return x ? {kind:'事案', item:x, due:x.nextDate, title:`事案確認: ${x.title || x.name || ''}`} : {missing:true, kind:'事案'}; }
    if (src.type === 'case-target') {
      const c=SOURCE_INDEX.cases.get(src.id); if(!c) return {missing:true, kind:'事案'};
      const target=arr(c.targetPersons).find(x=>x.id===src.subId) || null;
      const targetName = target?.name || '';
      const dueDate = target?.nextDate || c.nextDate || '';
      return {kind:'事案', item:c, due:dueDate, title: targetName ? `事案確認: ${targetName} / ${c.title || c.name || ''}` : `事案確認: ${c.title || c.name || ''}`};
    }
    return null;
  }
  function sourceStatus(t){
    const found = sourceFind(t); if(!found) return null;
    if(found.missing) return {label:'連携元が見つかりません', changed:true, missing:true};
    const dueChanged = clean(found.due) && clean(found.due) !== clean(t.due);
    const titleChanged = clean(found.title) && clean(found.title) !== clean(t.title);
    return {label:(dueChanged || titleChanged) ? '元データが変更されています' : '元データと一致', changed:dueChanged || titleChanged, expected:found};
  }
  async function syncTaskSource(id){ const t=TASK_BY_ID.get(id); if(!t)return; const st=sourceStatus(t); if(!st?.expected)return; const changed=cloneRecord(t); if(clean(st.expected.due)) changed.due=clean(st.expected.due); if(clean(st.expected.title)) changed.title=clean(st.expected.title); await persistTaskOptimistically(changed,t,{message:'元データに合わせました'}); }
  async function unlinkTaskSource(id){ const t=TASK_BY_ID.get(id); if(!t)return; const changed=cloneRecord(t); delete changed.source; delete changed.sourceInfo; await persistTaskOptimistically(changed,t,{message:'台帳との連携を解除しました'}); }


  function relationItemHTML(title, meta = []){
    return `<div class="relation-mini-item"><b>${esc(title || '無題')}</b><span>${esc(meta.filter(Boolean).join(' / '))}</span></div>`;
  }
  function relationBlockHTML(title, items, formatter, emptyText){
    const shown = arr(items).slice(0, 6);
    const body = shown.length ? shown.map(formatter).join('') + (items.length > shown.length ? `<div class="relation-mini-more">ほか${esc(items.length - shown.length)}件</div>` : '') : `<div class="relation-mini-empty">${esc(emptyText)}</div>`;
    return `<section class="relation-mini-block"><h3>${esc(title)} <span>${esc(items.length)}</span></h3>${body}</section>`;
  }
  function idsOverlap(a = [], b = []){ const set = new Set(arr(a).filter(Boolean)); return arr(b).some(x => set.has(x)); }
  function openTaskRelations(id){
    const t = DATA.tasks.find(x=>x.id===id); if(!t) return;
    const pids = arr(t.personIds).filter(Boolean);
    const relatedCase = SPEC.cases.find(c=>c.id===t.caseId) || null;
    const sameCaseTasks = t.caseId ? DATA.tasks.filter(x=>x.id!==t.id && x.caseId===t.caseId) : [];
    const samePeopleTasks = pids.length ? DATA.tasks.filter(x=>x.id!==t.id && idsOverlap(x.personIds, pids)) : [];
    const caseEvents = t.caseId ? SPEC.events.filter(x=>x.caseId===t.caseId) : [];
    const personEvents = pids.length ? SPEC.events.filter(x=>idsOverlap(x.personIds, pids)) : [];
    const caseDue = t.caseId ? [...SPEC.deadlines, ...SPEC.jimu].filter(x=>x.caseId===t.caseId) : [];
    const personDue = pids.length ? [...SPEC.deadlines, ...SPEC.jimu].filter(x=>idsOverlap(x.personIds, pids)) : [];
    const caseTargets = relatedCase ? arr(relatedCase.targetPersons).map(x=>({...x, caseTitle:relatedCase.title || relatedCase.name, status:normalizeCaseStatus(x.status || relatedCase.status)})) : [];
    const people = pids.map(id=>SPEC.people.find(p=>p.id===id)).filter(Boolean);
    const relatedTasks = [...sameCaseTasks, ...samePeopleTasks].filter((x,i,a)=>a.findIndex(y=>y.id===x.id)===i);
    const activeRelated = relatedTasks.filter(x=>!isDoneStatus(x));
    const relatedDueItems = [...caseDue, ...personDue].filter((x,i,a)=>a.findIndex(y=>y.id===x.id)===i);
    const nearDueItems = relatedDueItems.filter(x=>{ const d=diff(x.due); return d!==null && d<=7; }).sort((a,b)=>String(a.due||'9999').localeCompare(String(b.due||'9999')));
    const nearDueCount = nearDueItems.length;
    const noEstimate = activeRelated.filter(x=>!estimateMinutes(x)).length + (!estimateMinutes(t) && !isDoneStatus(t) ? 1 : 0);
    const relatedEvents = [...caseEvents, ...personEvents].filter((x,i,a)=>a.findIndex(y=>y.id===x.id)===i);
    const todayRelated = relatedEvents.filter(x=>calendarDiff(x.date)===0).length + relatedDueItems.filter(x=>calendarDiff(x.due)!==null && calendarDiff(x.due)<=0).length + activeRelated.filter(x=>validStatus(x.status)==='today' || (calendarDiff(x.due)!==null && calendarDiff(x.due)<=0)).length;
    const nextEvent = relatedEvents.filter(x=>calendarDiff(x.date)!==null && calendarDiff(x.date)>=0).sort((a,b)=>String(a.date||'9999').localeCompare(String(b.date||'9999')))[0];
    const relationFocus = `<div class="relation-spotlight"><section class="${calendarDiff(t.due) !== null && calendarDiff(t.due) <= 0 ? 'hot' : 'work'}"><b>この作業</b><span>${esc(t.due ? due(t.due) : statusLabel(validStatus(t.status)))}</span><em>${esc(estimateMeta(t) || '見積なし')}</em></section><section class="${activeRelated.length ? 'work' : ''}"><b>周辺作業</b><span>${esc(activeRelated.length)}件</span><em>${esc(durationLabel(totalEstimate(activeRelated)) || '見積なし')}</em></section><section class="${nearDueCount ? 'due' : ''}"><b>近い期限</b><span>${esc(nearDueCount)}件</span><em>${esc(nearDueItems[0] ? [fmt(nearDueItems[0].due), due(nearDueItems[0].due)].filter(Boolean).join(' / ') : '7日以内はありません')}</em></section><section class="${noEstimate ? 'soft' : ''}"><b>未見積</b><span>${esc(noEstimate)}件</span><em>${esc(noEstimate ? '重いものだけ見積を入れる' : '見積は整っています')}</em></section></div>`;
    const html = `<p class="modal-note">この作業に紐づく事案・人物・期限・予定をまとめて確認します。編集は各カードまたは該当画面で行います。</p>
      <div class="relation-summary-card"><b>${esc(t.title || '無題の作業')}</b><span>${esc([t.due?fmt(t.due):'', t.due?due(t.due):'', estimateMeta(t), statusLabel(validStatus(t.status)), caseName(t.caseId), peopleLabel(t)].filter(Boolean).join(' / '))}</span></div>
      <div class="relation-rollup"><span><b>${activeRelated.length}</b><em>関連未完了</em></span><span><b>${esc(durationLabel(totalEstimate(activeRelated)) || '0')}</b><em>関連見積</em></span><span><b>${todayRelated}</b><em>今日の関連項目</em></span><span><b>${nearDueCount}</b><em>近い期限</em></span><span><b>${noEstimate}</b><em>未見積</em></span><span><b>${people.length}</b><em>関係者</em></span></div>
      ${relationFocus}
      <div class="relation-mini-grid">
        ${relationBlockHTML('事案', relatedCase ? [relatedCase] : [], x=>relationItemHTML(x.title || x.name, [normalizeCaseStatus(x.status), x.owner, x.nextDate?fmt(x.nextDate):'']), '紐づく事案はありません。')}
        ${relationBlockHTML('人物', people, x=>relationItemHTML(x.name, [x.kind, x.term, x.org, x.role]), '紐づく人物はありません。')}
        ${relationBlockHTML('同じ事案の作業', sameCaseTasks, x=>relationItemHTML(x.title, [x.due?fmt(x.due):'', estimateMeta(x), statusLabel(validStatus(x.status)), x.priority==='high'?'高優先':'']), '同じ事案の作業はありません。')}
        ${relationBlockHTML('同じ人物の作業', samePeopleTasks, x=>relationItemHTML(x.title, [x.due?fmt(x.due):'', estimateMeta(x), statusLabel(validStatus(x.status)), caseName(x.caseId)]), '同じ人物の作業はありません。')}
        ${relationBlockHTML('期限・事務', [...caseDue, ...personDue].filter((x,i,a)=>a.findIndex(y=>y.id===x.id)===i), x=>relationItemHTML(x.title || x.name, [x.due?fmt(x.due):'', x.due?due(x.due):'', caseName(x.caseId)]), '関係する期限・事務はありません。')}
        ${relationBlockHTML('予定・出来事', [...caseEvents, ...personEvents].filter((x,i,a)=>a.findIndex(y=>y.id===x.id)===i), x=>relationItemHTML(x.title || x.name, [x.date?fmt(x.date):'', x.time, caseName(x.caseId)]), '関係する予定・出来事はありません。')}
        ${relationBlockHTML('事案対象者', caseTargets, x=>relationItemHTML(x.name || x.targetName, [x.status, x.nextDate?fmt(x.nextDate):'', x.owner]), '対象者カードはありません。')}
      </div>
      <div class="modal-actions"><div><button type="button" class="ghost" data-rel-open-main>日付確認で見る</button></div><div><button type="button" class="ghost" data-cancel>閉じる</button><button type="button" class="primary" data-rel-edit>この作業を編集</button></div></div>`;
    if(!openModal('関連情報を見る', html, async()=>{}, null))return;
    const form = $('modalForm');
    form.querySelector('[data-rel-open-main]')?.addEventListener('click', () => openWorkspace(t.caseId ? 'speculum:cases' : 'speculum:people'));
    form.querySelector('[data-rel-edit]')?.addEventListener('click', () => { closeModal(true); openTaskModal(t); });
  }

  function focusWithoutScroll(element){
    if(!element || typeof element.focus !== 'function')return;
    try{element.focus({preventScroll:true});}catch(_){element.focus();}
  }
  function closeActionMenus(except = null, restoreFocus = false){
    let returnTarget=null;
    $$('.action-menu[open]').forEach(menu => {
      if(menu === except)return;
      if(restoreFocus && menu.contains(document.activeElement))returnTarget=menu.querySelector(':scope > summary');
      menu.open = false;
    });
    if(returnTarget)focusWithoutScroll(returnTarget);
  }
  function actionMenuHost(details){
    return details.closest?.('.task-card');
  }
  function interactiveCardTarget(target){
    return !!target?.closest?.('button, select, input, textarea, label, summary, [role="button"], .action-menu');
  }
  function actionMenu(actions, label = '⋯', accessibleLabel = 'その他の操作'){
    const details = document.createElement('details');
    details.className = 'action-menu';
    details.draggable = false;
    const summary = document.createElement('summary');
    summary.textContent = label;
    summary.setAttribute('aria-label', accessibleLabel);
    summary.setAttribute('role', 'button');
    summary.addEventListener('mousedown', ev => ev.stopPropagation());
    summary.addEventListener('click', ev => ev.stopPropagation());
    details.appendChild(summary);
    const body = document.createElement('div');
    body.className = 'action-menu-body';
    body.addEventListener('mousedown', ev => ev.stopPropagation());
    body.addEventListener('click', ev => ev.stopPropagation());
    actions.filter(Boolean).forEach(a => {
      const b = document.createElement('button');
      b.type = 'button';
      b.draggable = false;
      b.textContent = a.label;
      if (a.className) b.className = a.className;
      b.onclick = ev => {
        ev.preventDefault(); ev.stopPropagation();
        details.open = false;
        // 閉じた details 内のボタンを、次の確認画面や編集画面の戻り先にしない。
        focusWithoutScroll(summary);
        a.onClick?.();
      };
      body.appendChild(b);
    });
    details.addEventListener('toggle', () => {
      actionMenuHost(details)?.classList.toggle('menu-open', details.open);
      if(details.open) closeActionMenus(details);
    });
    details.appendChild(body);
    return details;
  }

  const CARD_FOCUS_SELECTORS = [
    ['bulk','.bulk-task-check'],
    ['title','.card-title-button,.card-title-click'],
    ['due','.quick-due input'],
    ['priority','.quick-priority select'],
    ['status','.quick-status select'],
    ['primary','.ops .primary-inline'],
    ['edit','.ops .card-edit-button'],
    ['more','.action-menu > summary']
  ];
  function captureCardFocus(expectedId=''){
    const active=document.activeElement;
    const host=active?.closest?.('.task-card[data-task-id],.task-card[data-cycle-id]');
    if(!host)return null;
    const taskId=clean(host.dataset.taskId), cycleId=clean(host.dataset.cycleId);
    if(expectedId && expectedId!==taskId && expectedId!==cycleId)return null;
    const entry=CARD_FOCUS_SELECTORS.find(([,selector])=>active.matches?.(selector));
    return entry ? {taskId,cycleId,key:entry[0]} : null;
  }
  function focusIsUnplaced(){
    const active=document.activeElement;
    return !active || active===document.body || active===document.documentElement;
  }
  function restoreCardFocus(snapshot){
    if(!snapshot || !focusIsUnplaced())return false;
    const hosts=$$('.task-card[data-task-id],.task-card[data-cycle-id]');
    const host=hosts.find(node=>(snapshot.taskId&&clean(node.dataset.taskId)===snapshot.taskId)||(snapshot.cycleId&&clean(node.dataset.cycleId)===snapshot.cycleId));
    const selector=CARD_FOCUS_SELECTORS.find(([key])=>key===snapshot.key)?.[1];
    let target=host&&selector ? host.querySelector(selector) : null;
    if(!target || target.disabled || target.getAttribute('aria-disabled')==='true'){
      target=snapshot.cycleId ? $('cyclePanel')?.querySelector(':scope > summary') : (document.querySelector('[data-work-scope].active') || $('addTaskBtn'));
    }
    focusWithoutScroll(target);
    return !!target;
  }

  function appendMetaChips(parent, parts){
    arr(parts).filter(Boolean).forEach(value => {
      const chip=document.createElement('span');
      chip.className=metaClass(value);
      chip.textContent=String(value);
      parent.appendChild(chip);
    });
  }

  function quickSelect(label, className, value, options, onChange, disabled=false, displayLabel=label, ariaLabel=displayLabel){
    const field=document.createElement('label'); field.className=`task-quick-field ${className}`;
    const caption=document.createElement('span'); caption.textContent=displayLabel; field.appendChild(caption);
    const select=document.createElement('select'); select.setAttribute('aria-label', ariaLabel); select.disabled=disabled;
    options.forEach(([optionValue, optionLabel])=>{ const option=document.createElement('option'); option.value=optionValue; option.textContent=optionLabel; option.selected=String(optionValue)===String(value); select.appendChild(option); });
    select.addEventListener('change',()=>onChange(select.value));
    field.appendChild(select);
    return field;
  }

  function clearTaskReorderTargets(){
    $$('.task-card.task-reorder-before,.task-card.task-reorder-after').forEach(card=>card.classList.remove('task-reorder-before','task-reorder-after'));
  }
  async function reorderTasksAtCard(dragId,targetId,placeAfter=false,visibleIds=[]){
    const dragged=TASK_BY_ID.get(dragId); const target=TASK_BY_ID.get(targetId);
    if(!dragged || !target || dragId===targetId || PENDING_TASK_IDS.has(dragId))return false;
    if(validStatus(dragged.status)!==validStatus(target.status))return false;
    const columnIds=DATA.tasks.filter(item=>validStatus(item.status)===validStatus(dragged.status)).slice().sort(sortCards).map(item=>item.id);
    const ids=(columnIds.includes(dragId)&&columnIds.includes(targetId)?columnIds:arr(visibleIds)).filter(id=>TASK_BY_ID.has(id));
    const originalIds=ids.slice();
    const from=ids.indexOf(dragId); const targetIndex=ids.indexOf(targetId);
    if(from<0 || targetIndex<0)return false;
    ids.splice(from,1);
    let insertAt=ids.indexOf(targetId)+(placeAfter?1:0);
    insertAt=Math.max(0,Math.min(ids.length,insertAt)); ids.splice(insertAt,0,dragId);
    if(ids.every((id,index)=>id===originalIds[index]))return false;
    const snapshots=ids.map(id=>cloneRecord(TASK_BY_ID.get(id))).filter(Boolean);
    const movedIndex=ids.indexOf(dragId);
    const allManual=snapshots.every(task=>task.id===dragId || clean(task.sortOrder));
    let changed=[];
    if(allManual){
      const previous=movedIndex>0?Number(TASK_BY_ID.get(ids[movedIndex-1])?.sortOrder):null;
      const next=movedIndex<ids.length-1?Number(TASK_BY_ID.get(ids[movedIndex+1])?.sortOrder):null;
      const hasSpace=(previous===null&&Number.isFinite(next))||(next===null&&Number.isFinite(previous))||(Number.isFinite(previous)&&Number.isFinite(next)&&next-previous>1e-6);
      if(hasSpace){
        const order=previous===null?next-10:next===null?previous+10:(previous+next)/2;
        changed=[Object.assign(cloneRecord(TASK_BY_ID.get(dragId)),{sortOrder:String(order),updatedAt:new Date().toISOString()})];
      }
    }
    if(!changed.length)changed=snapshots.map((task,index)=>Object.assign(cloneRecord(task),{sortOrder:String((index+1)*10),updatedAt:new Date().toISOString()}));
    const previousSortMode=sortMode();
    DATA.settings=Object.assign(defaultSettings(),DATA.settings||{}, {workSortMode:'manual'});
    const snapshotById=new Map(snapshots.map(task=>[task.id,task]));
    const {reloaded,failed}=await saveWorkItems('tasks',changed,baseItemsFrom(changed.map(task=>snapshotById.get(task.id))));
    if(failed){DATA.settings.workSortMode=previousSortMode;render();return false;}
    try{const settingsResult=await saveSettings('');if(settingsResult?.merged)render();}catch(err){toast(err?.message||'並び順の表示設定を保存できませんでした');}
    toast(reloaded?'カードを並べ替えました（最新データを反映）':'カードを並べ替えました',{actionLabel:'元に戻す',onAction:()=>restoreTaskSnapshots(snapshots,'並び替えを元に戻しました')});
    return true;
  }

  function taskCard(t){
    const d = calendarDiff(t.due); const st = validStatus(t.status); const done = st === 'done'; const src = sourceStatus(t);
    const pending=PENDING_TASK_IDS.has(t.id);
    const taskLabel=t.title || '無題の作業';
    const node = document.createElement('div'); node.draggable = !pending;
    node.dataset.recordId = clean(t.id);
    node.dataset.taskId = clean(t.id);
    node.addEventListener('dragstart', e => { if(pending || interactiveCardTarget(e.target)){ e.preventDefault(); return; } ACTIVE_TASK_DRAG_ID=t.id; e.dataTransfer.setData('text/plain', 'task:' + t.id); e.dataTransfer.effectAllowed='move'; node.classList.add('dragging'); document.body.classList.add('dragging-work-card'); });
    node.addEventListener('dragend', () => { ACTIVE_TASK_DRAG_ID=''; clearTaskReorderTargets(); node.classList.remove('dragging'); document.body.classList.remove('dragging-work-card'); });
    node.addEventListener('dragover',e=>{
      const dragged=TASK_BY_ID.get(ACTIVE_TASK_DRAG_ID);
      if(!dragged || dragged.id===t.id || validStatus(dragged.status)!==st)return;
      e.preventDefault();e.stopPropagation();e.dataTransfer.dropEffect='move';
      const after=e.clientY>node.getBoundingClientRect().top+(node.offsetHeight/2);
      clearTaskReorderTargets();node.classList.add(after?'task-reorder-after':'task-reorder-before');
    });
    node.addEventListener('dragleave',e=>{if(!node.contains(e.relatedTarget))node.classList.remove('task-reorder-before','task-reorder-after');});
    node.addEventListener('drop',async e=>{
      const dragged=TASK_BY_ID.get(ACTIVE_TASK_DRAG_ID);
      if(!dragged || dragged.id===t.id || validStatus(dragged.status)!==st)return;
      e.preventDefault();e.stopPropagation();
      const after=node.classList.contains('task-reorder-after');
      const visibleIds=$$('.task-card[data-task-id]',node.closest('.tasks')).map(card=>clean(card.dataset.taskId));
      const dragId=ACTIVE_TASK_DRAG_ID;ACTIVE_TASK_DRAG_ID='';clearTaskReorderTargets();document.body.classList.remove('dragging-work-card');
      await reorderTasksAtCard(dragId,t.id,after,visibleIds);
    });
    node.className = `task-card ${t.priority==='high'?'high':''} ${d!==null&&d<0&&!done?'over':''} ${done?'done-card':''} ${src?.changed?'source-changed':''} ${pending?'saving-card':''}`.trim();
    const doneInfo = done && doneDate(t) ? `完了 ${fmt(doneDate(t))}` : '';
    const dueMeta=t.due&&!done?due(t.due):(doneInfo || (!t.due?'期限なし':''));
    const primaryMeta = [dueMeta, estimateMeta(t)];
    const relatedMeta = [caseName(t.caseId), peopleLabel(t), t.note?'メモあり':'', src?.changed?src.label:''];
    const head=document.createElement('div'); head.className='task-card-head';
    const bulkLabel=document.createElement('label'); bulkLabel.className='bulk-check';
    const bulk=document.createElement('input'); bulk.className='bulk-task-check'; bulk.type='checkbox'; bulk.value=clean(t.id); bulk.checked=SELECTED_TASK_IDS.has(t.id); bulk.disabled=pending; bulk.setAttribute('aria-label',`「${taskLabel}」を複数選択`); bulk.addEventListener('change',()=>{if(bulk.checked)SELECTED_TASK_IDS.add(t.id);else SELECTED_TASK_IDS.delete(t.id);renderBulkActions();}); bulkLabel.appendChild(bulk); head.appendChild(bulkLabel);
    const dragHandle=document.createElement('span'); dragHandle.className='card-drag-handle'; dragHandle.textContent='⠿'; dragHandle.title='カードをドラッグして移動・並べ替え'; dragHandle.setAttribute('aria-hidden','true'); head.appendChild(dragHandle);
    const heading=document.createElement('h3');
    const titleButton=document.createElement('button'); titleButton.type='button'; titleButton.className='card-title-button'; titleButton.disabled=pending; titleButton.textContent=taskLabel; titleButton.setAttribute('aria-label',`${taskLabel}を編集`); titleButton.addEventListener('click',()=>openTaskModal(TASK_BY_ID.get(t.id)||t)); heading.appendChild(titleButton); head.appendChild(heading);
    const badge=document.createElement('span'); badge.className=`status-badge status-${st}`; badge.textContent=pending?'保存中…':statusLabel(st); head.appendChild(badge); node.appendChild(head);

    const primaryMetaBox=document.createElement('div'); primaryMetaBox.className='item-meta meta-primary'; appendMetaChips(primaryMetaBox, primaryMeta); node.appendChild(primaryMetaBox);
    if(t.nextAction){ const next=document.createElement('div'); next.className='task-next-action'; const label=document.createElement('span'); label.textContent='次'; next.appendChild(label); const value=document.createElement('b'); value.textContent=t.nextAction; next.appendChild(value); node.appendChild(next); }
    if(relatedMeta.some(Boolean)){ const relatedMetaBox=document.createElement('div'); relatedMetaBox.className='item-meta meta-related'; appendMetaChips(relatedMetaBox,relatedMeta); node.appendChild(relatedMetaBox); }

    const quick=document.createElement('div'); quick.className='task-quick-fields'; quick.setAttribute('aria-label','カード上で変更');
    const dueField=document.createElement('label'); dueField.className='task-quick-field quick-due'; const dueCaption=document.createElement('span'); dueCaption.textContent='期限'; dueField.appendChild(dueCaption);
    const dueInput=document.createElement('input'); dueInput.type='date'; dueInput.value=clean(t.due); dueInput.disabled=pending; dueInput.setAttribute('aria-label',`「${taskLabel}」の期限を変更`); dueInput.addEventListener('change',()=>quickUpdateTask(t.id,{due:dueInput.value},'期限を変更しました')); dueField.appendChild(dueInput); quick.appendChild(dueField);
    quick.appendChild(quickSelect('優先','quick-priority',t.priority||'normal',[['normal','通常'],['high','高優先'],['low','低優先']],value=>quickUpdateTask(t.id,{priority:value},'優先度を変更しました'),pending,'優先度',`「${taskLabel}」の優先度を変更`));
    quick.appendChild(quickSelect('表示する列','quick-status',st,columns,value=>moveTask(t.id,value),pending,'位置',`「${taskLabel}」の表示する列を変更`));
    node.appendChild(quick);

    const ops = document.createElement('div'); ops.className='ops'; node.appendChild(ops);
    const primaryTarget=st==='today'?'done':(st==='next'?'today':'next');
    const primaryLabel=st==='today'?'完了':(st==='next'?'今日やる':(st==='waiting'?'待ちを解除':'未完了へ'));
    const primary = document.createElement('button'); primary.type='button'; primary.disabled=pending; primary.textContent=primaryLabel; primary.className='primary-inline'; primary.onclick = () => moveTask(t.id,primaryTarget); ops.appendChild(primary);
    const edit=document.createElement('button'); edit.type='button'; edit.className='card-edit-button'; edit.disabled=pending; edit.textContent='詳しく編集'; edit.onclick=()=>openTaskModal(TASK_BY_ID.get(t.id)||t); ops.appendChild(edit);
    const moreActions = [];
    if (src?.changed && !src.missing) moreActions.push({label:'元に合わせる', onClick:()=>syncTaskSource(t.id)});
    if (src) moreActions.push({label:'台帳との連携を解除', onClick:()=>unlinkTaskSource(t.id)});
    if (t.caseId || arr(t.personIds).length) moreActions.push({label:'関連情報を見る', onClick:()=>openTaskRelations(t.id)});
    moreActions.push({label:'削除…', className:'danger-action', onClick:()=>deleteTask(t.id)});
    if(!pending)ops.appendChild(actionMenu(moreActions, '⋯', `「${taskLabel}」のその他の操作`));
    return node;
  }

  function refreshRenderedTaskCards(ids=[]){
    const wanted=new Set(arr(ids).filter(Boolean));
    if(!wanted.size)return;
    $$('.task-card[data-task-id]').forEach(node=>{
      const id=clean(node.dataset.taskId); if(!wanted.has(id))return;
      const item=TASK_BY_ID.get(id); if(item)node.replaceWith(taskCard(item)); else node.remove();
    });
    renderBulkActions();
  }

  function renderCycles(){
    const board=$('cycleBoard'); if(!board) return; board.innerHTML=''; const q=currentFilter(); const qTokens=searchTokens(q); board.classList.toggle('compact-board', boardDensity() === 'compact');
    const byStatus={today:[],next:[],waiting:[],done:[]};
    DATA.cycleTasks.forEach(cycle=>byStatus[cycleColumnStatus(cycle)].push(cycle));
    cycleColumns.forEach(([key,label]) => {
      let list = byStatus[key].filter(c => shouldShowCycle(c, q));
      const hiddenDone = key === 'done' && !q ? DATA.cycleTasks.filter(c => cycleColumnStatus(c)==='done' && !shouldShowDone({...c,status:'done'}, false)).length : 0;
      if (WORK_SCOPE !== 'all') list = list.filter(cycleScopeMatch);
      if(qTokens.length) list = list.filter(c => matchesSearchTokens(qTokens, JSON.stringify(c) + ' 周期作業 作業 繰り返し ' + label));
      list = list.slice().sort((a,b)=>sortCards({...a,due:a.nextRunDate,status:cycleColumnStatus(a)}, {...b,due:b.nextRunDate,status:cycleColumnStatus(b)}));
      const col=document.createElement('article'); col.className=`cycle-column cycle-column-${key}`;
      const mini = columnMiniStats(list.map(c=>({...c, due:c.nextRunDate, status:cycleColumnStatus(c)}))); const guide = cycleColumnGuide(key);
      col.innerHTML=`<h2><span>${esc(label)}<small>${mini ? esc(mini) : ''}</small><em class="column-guide">${esc(guide)}</em></span><span class="work-count">${list.length}</span></h2><div class="cycle-tasks" data-status="${esc(key)}"></div>`;
      const box=col.querySelector('.cycle-tasks'); bindDrop(box, async payload => { if(payload.type === 'cycle') await moveCycle(payload.id, key); });
      const cycleEmpty = {today:'今回対象の周期作業はありません。', next:'継続中の周期作業はありません。', waiting:'休止中の周期作業はありません。', done:'終了済み周期作業はありません。'};
      renderColumnContents(box, list.map(c=>({...c,due:c.nextRunDate,status:cycleColumnStatus(c)})), 'cycle', key, c=>cycleCard(DATA.cycleTasks.find(x=>x.id===c.id)||c), q ? '条件に合う周期作業はありません。' : (cycleEmpty[key] || 'ここにはまだありません。'));
      if (hiddenDone) { const note = document.createElement('button'); note.type='button'; note.className='done-hidden-note'; note.textContent = `終了済み周期作業 ${hiddenDone}件を見る`; note.onclick=()=>{WORK_SCOPE='done';render();}; box.appendChild(note); }
      board.appendChild(col);
    });
  }
  function cycleCard(c){
    const st = cycleColumnStatus(c); const state = cycleState(c); const d = calendarDiff(c.nextRunDate); const done = st === 'done';
    const pending=PENDING_CYCLE_IDS.has(c.id);
    const node=document.createElement('div'); node.draggable=!pending;
    node.dataset.recordId = clean(c.id);
    node.dataset.cycleId = clean(c.id);
    node.addEventListener('dragstart', e=>{ if(pending || interactiveCardTarget(e.target)){ e.preventDefault(); return; } e.dataTransfer.setData('text/plain','cycle:'+c.id); e.dataTransfer.effectAllowed='move'; node.classList.add('dragging'); document.body.classList.add('dragging-work-card');});
    node.addEventListener('dragend',()=>{node.classList.remove('dragging'); document.body.classList.remove('dragging-work-card');});
    node.className=`task-card cycle-card ${c.priority==='high'?'high':''} ${d!==null&&d<0&&!done?'over':''} ${done?'done-card':''} ${pending?'saving-card':''}`.trim();
    const stateLabel = state === 'paused' ? '休止中' : state === 'ended' ? '終了済み' : '継続中';
    const doneInfo = done && doneDate(c) ? `終了 ${fmt(doneDate(c))}` : '';
    const primaryMeta = [stateLabel, c.nextRunDate?fmt(c.nextRunDate):'', c.nextRunDate&&!done?due(c.nextRunDate):'', c.priority==='high'?'高優先':(c.priority==='low'?'低優先':'')];
    const relatedMeta = [c.rule, `列: ${cycleColumnLabel(st)}`, c.lastDoneDate?`前回 ${fmt(c.lastDoneDate)}`:'', doneInfo];
    node.innerHTML=`<div class="task-card-head"><h3>${esc(c.title || '無題の周期作業')}</h3><span class="status-badge status-${esc(st)}">${esc(pending?'保存中…':stateLabel)}</span></div>${cardMetaBlock(primaryMeta, relatedMeta)}${c.note?`<p class="muted">${esc(c.note)}</p>`:''}<div class="ops"></div>`;
    const title=node.querySelector('h3'); title.classList.add('card-title-click'); title.tabIndex=pending?-1:0; title.setAttribute('role','button'); title.setAttribute('aria-label',pending?'保存中です':`${c.title || '無題の周期作業'}を編集`); title.setAttribute('aria-disabled',pending?'true':'false'); if(!pending){title.addEventListener('click',()=>openCycleModal(c)); title.addEventListener('keydown',e=>{ if(e.key==='Enter'||e.key===' '){ e.preventDefault(); openCycleModal(c); } });}
    const ops=node.querySelector('.ops');
    const moreActions = [];
    if (state === 'active') {
      const doneBtn=document.createElement('button'); doneBtn.textContent='今回完了'; doneBtn.className='primary-inline'; doneBtn.disabled=pending; doneBtn.onclick=()=>cycleAction(c.id,'complete'); ops.appendChild(doneBtn);
      moreActions.push({label:'スキップ', onClick:()=>cycleAction(c.id,'skip')});
      moreActions.push({label:'休止', onClick:()=>cycleAction(c.id,'pause')});
      moreActions.push({label:'終了', className:'danger-action', onClick:()=>cycleEnd(c.id)});
    } else if (state === 'paused') {
      const resume=document.createElement('button'); resume.textContent='再開'; resume.className='primary-inline'; resume.disabled=pending; resume.onclick=()=>cycleAction(c.id,'resume'); ops.appendChild(resume);
      moreActions.push({label:'終了', className:'danger-action', onClick:()=>cycleEnd(c.id)});
    } else {
      const resume=document.createElement('button'); resume.textContent='再開'; resume.disabled=pending; resume.onclick=()=>cycleAction(c.id,'resume'); ops.appendChild(resume);
    }
    const edit=document.createElement('button'); edit.type='button'; edit.className='card-edit-button'; edit.textContent='編集'; edit.disabled=pending; edit.onclick=()=>openCycleModal(c); ops.appendChild(edit);
    moreActions.push({label:'削除', className:'danger-action', onClick:()=>deleteCycle(c.id)});
    if(!pending)ops.appendChild(actionMenu(moreActions, '⋯', `「${c.title || '無題の周期作業'}」のその他の操作`));
    return node;
  }

  function parseDrag(e){ const raw = e.dataTransfer.getData('text/plain') || ''; if(raw.startsWith('task:')) return {type:'task', id:raw.slice(5)}; if(raw.startsWith('cycle:')) return {type:'cycle', id:raw.slice(6)}; return raw ? {type:'task', id:raw} : {type:'', id:''}; }
  function bindDrop(el, handler){ if(!el) return; el.addEventListener('dragover', e => { e.preventDefault(); e.dataTransfer.dropEffect='move'; el.closest('.work-column,.cycle-column,.trash-drop-zone')?.classList.add('drop-target'); }); el.addEventListener('dragleave', () => el.closest('.work-column,.cycle-column,.trash-drop-zone')?.classList.remove('drop-target')); el.addEventListener('drop', async e => { e.preventDefault(); el.closest('.work-column,.cycle-column,.trash-drop-zone')?.classList.remove('drop-target'); const payload=parseDrag(e); if(payload.id) await handler(payload); }); }
  function cloneRecord(x){ return JSON.parse(JSON.stringify(x || {})); }
  function removeLocalTask(id){ DATA.tasks=DATA.tasks.filter(x=>x.id!==id); rebuildContinuumIndexes(); }
  function rollbackLocalTask(id, snapshot){ if(snapshot?.id) upsert('tasks',normalizeTaskClient(snapshot)); else removeLocalTask(id); }
  async function persistTaskOptimistically(nextItem, previousItem=null, options={}){
    const snapshot=previousItem?.id ? cloneRecord(previousItem) : null;
    const item=normalizeTaskClient({...nextItem,updatedAt:new Date().toISOString()});
    if(options.restoreToken)item._restoreToken=options.restoreToken;
    if(!item.id) return false;
    if(PENDING_TASK_IDS.has(item.id)){ toast('この作業は保存中です'); return false; }
    const returnFocus=captureCardFocus(item.id);
    const baseHash=HASH;
    PENDING_TASK_IDS.add(item.id);
    upsert('tasks',item);
    const cardOnly = canRefreshTaskCardOnly(snapshot, item);
    if(cardOnly) refreshRenderedTaskCards([item.id]); else renderTaskViews();
    try {
      const j=await api('/api/continuum/task-upsert',{method:'POST',body:JSON.stringify({item,baseHash,baseItemUpdatedAt:itemBaseUpdatedAt(snapshot)})});
      const reloaded=await applySavedWorkMutation('tasks',j,item);
      PENDING_TASK_IDS.delete(item.id);
      flushPendingDataSync();
      if(reloaded) render(); else refreshRenderedTaskCards([item.id]);
      restoreCardFocus(returnFocus);
      const message=clean(options.message || '保存しました');
      const undo=options.undo===false ? {} : (snapshot ? {actionLabel:'元に戻す',onAction:()=>restoreTaskSnapshot(snapshot)} : {actionLabel:'元に戻す',onAction:()=>removeTasksByIds([item.id])});
      if(message) toast(reloaded?`${message}（最新データを反映）`:message,undo);
      return true;
    } catch(err) {
      PENDING_TASK_IDS.delete(item.id);
      flushPendingDataSync();
      rollbackLocalTask(item.id,snapshot);
      if(err?.status===409 || err?.data?.conflict){
        try { await load(); render(); } catch (_) { renderTaskViews(); }
        restoreCardFocus(returnFocus);
        toast('別画面の変更を反映しました。内容を確認して、もう一度変更してください');
        return false;
      }
      renderTaskViews();
      restoreCardFocus(returnFocus);
      toast(err?.message || '保存できなかったため、変更前に戻しました');
      return false;
    }
  }
  function canRefreshTaskCardOnly(previousItem, nextItem){
    if(!previousItem?.id || !nextItem?.id || currentFilter() || WORK_SCOPE !== 'all') return false;
    const allowed = new Set(['updatedAt','note','nextAction']);
    const emptyEquivalent = new Set(['peopleText','sortOrder','caseId','source','completedAt']);
    const keys = new Set([...Object.keys(previousItem), ...Object.keys(nextItem)]);
    for(const key of keys){
      if(allowed.has(key)) continue;
      if(emptyEquivalent.has(key) && !clean(previousItem[key]) && !clean(nextItem[key])) continue;
      if(JSON.stringify(previousItem[key] ?? null) !== JSON.stringify(nextItem[key] ?? null)) return false;
    }
    return true;
  }
  async function quickUpdateTask(id,patch,message){
    const current=TASK_BY_ID.get(id); if(!current)return false;
    const changed={...cloneRecord(current),...(patch||{})};
    if(Object.prototype.hasOwnProperty.call(changed,'status')){
      const previousStatus=validStatus(current.status); changed.status=validStatus(changed.status);
      if(changed.status==='done' && previousStatus!=='done') changed.completedAt=today();
      if(changed.status!=='done') delete changed.completedAt;
    }
    return persistTaskOptimistically(changed,current,{message});
  }
  async function restoreTaskSnapshot(snapshot, message='元に戻しました'){
    const current = TASK_BY_ID.get(snapshot.id); if(!current)return;
    await persistTaskOptimistically(cloneRecord(snapshot),current,{message,undo:false});
  }
  async function restoreTaskSnapshots(snapshots, message='元に戻しました'){
    const byId = new Map(arr(snapshots).map(x=>[x.id, cloneRecord(x)]));
    const current = DATA.tasks.filter(t=>byId.has(t.id));
    const restored = current.map(t=>Object.assign(cloneRecord(byId.get(t.id)), {updatedAt:new Date().toISOString()}));
    if(!restored.length) return;
    const {reloaded,failed} = await saveWorkItems('tasks', restored, baseItemsFrom(current));
    if(failed)return;
    toast(reloaded ? `${message}（最新データを反映）` : message);
  }
  async function runCycleMutation(id,operation,errorMessage='周期作業を更新できませんでした'){
    if(!id)return {ok:false};
    if(PENDING_CYCLE_IDS.has(id)){toast('この周期作業は保存中です');return {ok:false,busy:true};}
    const returnFocus=captureCardFocus(id);
    PENDING_CYCLE_IDS.add(id); renderCycles();
    try{return {ok:true,value:await operation()};}
    catch(err){
      if(err?.status===409 || err?.data?.conflict){try{await load();}catch(_){}toast('別画面の変更を反映しました。内容を確認して、もう一度操作してください');}
      else toast(err?.message || errorMessage);
      return {ok:false,error:err};
    }
    finally{PENDING_CYCLE_IDS.delete(id);render();restoreCardFocus(returnFocus);flushPendingDataSync();}
  }
  async function restoreCycleSnapshot(snapshot, message='元に戻しました', restoreToken=''){
    if(!snapshot?.id)return false;
    const current = DATA.cycleTasks.find(x=>x.id===snapshot.id);
    const restored = normalizeCycleClient(Object.assign(cloneRecord(snapshot), {updatedAt:new Date().toISOString()}));
    if(restoreToken)restored._restoreToken=restoreToken;
    const result=await runCycleMutation(snapshot.id,async()=>{
      const j=await api('/api/continuum/cycle-upsert', {method:'POST', body:JSON.stringify({item:restored, baseHash:HASH, baseItemUpdatedAt:clean(current?.updatedAt)})});
      return {reloaded:await applySavedWorkMutation('cycleTasks', j, restored)};
    },'周期作業を元に戻せませんでした');
    if(!result.ok)return false;
    toast(result.value.reloaded ? `${message}（最新データを反映）` : message);
    return true;
  }
  async function moveTask(id,status){
    const next=validStatus(status);
    return quickUpdateTask(id,{status:next},next==='done'?'完了にしました':'列を移動しました');
  }
  async function moveCycle(id,status){
    const c=DATA.cycleTasks.find(x=>x.id===id); if(!c)return; const snapshot=cloneRecord(c);
    const next=validStatus(status); if(next==='done') { await cycleEnd(id); return; }
    const changed = normalizeCycleClient(Object.assign(cloneRecord(c), {status:next, state:next==='waiting'?'paused':'active', updatedAt:new Date().toISOString()}));
    if(next!=='done') delete changed.completedAt;
    const result=await runCycleMutation(id,async()=>{
      const j=await api('/api/continuum/cycle-upsert', {method:'POST', body:JSON.stringify({item:changed, baseHash:HASH, baseItemUpdatedAt:snapshot.updatedAt || ''})});
      return {reloaded:await applySavedWorkMutation('cycleTasks', j, changed)};
    });
    if(!result.ok)return false;
    toast(result.value.reloaded ? '周期作業を移動しました（最新データを反映）' : (changed.state==='paused'?'周期作業を休止しました':'周期作業を移動しました'), {actionLabel:'元に戻す', onAction:()=>restoreCycleSnapshot(snapshot)});
    return true;
  }
  async function restoreDeletedTask(snapshot, restoreToken=''){
    if(!snapshot?.id)return false;
    return persistTaskOptimistically(cloneRecord(snapshot),null,{message:'削除した作業を元に戻しました',undo:false,restoreToken});
  }
  async function deleteTaskRecord(id){
    const snapshot=TASK_BY_ID.get(id); if(!snapshot)return false;
    if(PENDING_TASK_IDS.has(id)){toast('この作業は保存中です');return false;}
    const returnFocus=captureCardFocus(id);
    PENDING_TASK_IDS.add(id); refreshRenderedTaskCards([id]);
    try{
      const result=await removeAddedRecords('tasks',[id],'');
      const restoreToken=clean(result?.restoreTokens?.[id] || result?.restoreToken);
      toast(result?.merged?'削除しました（最新データを反映）':'削除しました',{actionLabel:'元に戻す',onAction:()=>restoreDeletedTask(snapshot,restoreToken)});
      return true;
    }catch(err){toast(err?.message || '作業を削除できませんでした');return false;}
    finally{PENDING_TASK_IDS.delete(id);refreshRenderedTaskCards([id]);restoreCardFocus(returnFocus);flushPendingDataSync();}
  }
  async function deleteCycleRecord(id){
    const snapshot=DATA.cycleTasks.find(x=>x.id===id); if(!snapshot)return false;
    const result=await runCycleMutation(id,()=>removeAddedRecords('cycleTasks',[id],''),'周期作業を削除できませんでした');
    if(!result.ok)return false;
    const restoreToken=clean(result.value?.restoreTokens?.[id] || result.value?.restoreToken);
    toast('削除しました',{actionLabel:'元に戻す',onAction:()=>restoreCycleSnapshot(snapshot,'元に戻しました',restoreToken)});
    return true;
  }
  async function deleteTask(id){ const t=TASK_BY_ID.get(id); if(!t)return false; if(PENDING_TASK_IDS.has(id)){toast('この作業は保存中です');return false;} const ok = await askConfirm('作業を削除しますか？', `「${t.title || '無題の作業'}」を作業管理から削除します。`, '削除する'); if(!ok)return false; return deleteTaskRecord(id); }
  async function deleteCycle(id){ if(PENDING_CYCLE_IDS.has(id)){toast('この周期作業は保存中です');return false;} const c=DATA.cycleTasks.find(x=>x.id===id); if(!c)return false; const ok = await askConfirm('周期作業を削除しますか？', `「${c.title || '無題の周期作業'}」を周期作業から削除します。`, '削除する'); if(!ok)return false; return deleteCycleRecord(id); }
  async function cycleAction(id, action){
    const current=DATA.cycleTasks.find(x=>x.id===id); if(!current)return false;
    const before=cloneRecord(current);
    const names={complete:'今回分を完了しました',skip:'今回分をスキップしました',pause:'休止しました',resume:'再開しました',end:'終了しました'};
    const result=await runCycleMutation(id,async()=>{
      const j=await api(`/api/continuum/cycle-${action}`,{method:'POST',body:JSON.stringify({id,doneDate:today(),baseItemUpdatedAt:before.updatedAt||''})});
      const reloaded=await applySavedWorkMutation('cycleTasks',j,j.item);
      return {j,reloaded};
    },'周期作業を更新できませんでした');
    if(!result.ok)return false;
    const {j}=result.value;
    const msg = action==='complete'||action==='skip' ? `${names[action]}。次回は ${fmt(j.item.nextRunDate)} です` : names[action];
    toast(msg, before.id ? {actionLabel:'元に戻す', onAction:()=>restoreCycleSnapshot(before)} : {});
    return true;
  }
  async function cycleEnd(id){ if(PENDING_CYCLE_IDS.has(id)){toast('この周期作業は保存中です');return false;} const c=DATA.cycleTasks.find(x=>x.id===id); if(!c)return false; if(!await askConfirm('周期作業を終了しますか？', `「${c.title || '無題の周期作業'}」を通常一覧から外し、終了済みの周期作業として残します。`, '終了する')) return false; return cycleAction(id,'end'); }

  function selectedTaskIds(){ return [...SELECTED_TASK_IDS].filter(id=>TASK_BY_ID.has(id)); }
  function setSelectMode(on){ SELECT_MODE = !!on; document.body.classList.toggle('select-mode', SELECT_MODE); const b=$('selectionModeBtn'); if(b){b.textContent = SELECT_MODE ? '複数選択を終了' : '複数選択';b.setAttribute('aria-pressed',SELECT_MODE?'true':'false');} if(!SELECT_MODE) bulkClearSelection(); else renderBulkActions(); }
  function renderBulkActions(){ const box=$('bulkActions'); if(!box)return; const n=selectedTaskIds().length; box.classList.toggle('active', n>0); const count=box.querySelector('[data-bulk-count]'); if(count) count.textContent = n ? `${n}件選択中` : '複数選択した作業'; }
  async function bulkMoveTasks(status){
    const ids=selectedTaskIds(); if(!ids.length)return toast('作業を選択してください');
    const idSet = new Set(ids); const snapshots=DATA.tasks.filter(t=>idSet.has(t.id)).map(cloneRecord);
    const changed=snapshots.map(t=>{ const prev=validStatus(t.status); const item=Object.assign(cloneRecord(t), {status:validStatus(status), updatedAt:new Date().toISOString()}); if(item.status==='done' && prev!=='done') item.completedAt=today(); if(item.status!=='done') delete item.completedAt; return item; });
    const {reloaded,failed}=await saveWorkItems('tasks', changed, baseItemsFrom(snapshots)); if(failed)return;
    bulkClearSelection();
    const msg=status==='done'?'一括完了しました':status==='today'?'「今日やる」に移しました':'一括変更しました';
    toast(reloaded ? `${msg}（最新データを反映）` : msg, {actionLabel:'元に戻す', onAction:()=>restoreTaskSnapshots(snapshots, '一括操作を元に戻しました')});
  }
  async function bulkSetPriority(priority){
    const ids=selectedTaskIds(); if(!ids.length)return toast('作業を選択してください');
    const idSet = new Set(ids); const snapshots=DATA.tasks.filter(t=>idSet.has(t.id)).map(cloneRecord);
    const changed=snapshots.map(t=>Object.assign(cloneRecord(t), {priority, updatedAt:new Date().toISOString()}));
    const {reloaded,failed}=await saveWorkItems('tasks', changed, baseItemsFrom(snapshots)); if(failed)return;
    bulkClearSelection();
    const msg=priority==='high'?'選択した作業を高優先にしました':'選択した作業の優先度を通常にしました';
    toast(reloaded ? `${msg}（最新データを反映）` : msg, {actionLabel:'元に戻す', onAction:()=>restoreTaskSnapshots(snapshots, '一括操作を元に戻しました')});
  }
  async function bulkShiftDue(days){
    const ids=selectedTaskIds(); if(!ids.length)return toast('作業を選択してください');
    const idSet = new Set(ids); const snapshots=DATA.tasks.filter(t=>idSet.has(t.id)).map(cloneRecord); const target=addDaysISO(today(), days);
    const changed=snapshots.map(t=>Object.assign(cloneRecord(t), {due:target, updatedAt:new Date().toISOString()}));
    const {reloaded,failed}=await saveWorkItems('tasks', changed, baseItemsFrom(snapshots)); if(failed)return;
    bulkClearSelection();
    const msg=days===1?'選択作業を明日に延期しました':'選択作業を7日後へ移しました';
    toast(reloaded ? `${msg}（最新データを反映）` : msg, {actionLabel:'元に戻す', onAction:()=>restoreTaskSnapshots(snapshots, '一括操作を元に戻しました')});
  }
  async function bulkSetDue(){
    const ids=selectedTaskIds(); if(!ids.length)return toast('作業を選択してください');
    const ds=await askText('期限を一括変更', '選択した作業の期限を変更します。', today(), '期限を変更'); if(ds === null)return; if(!/^\d{4}-\d{2}-\d{2}$/.test(clean(ds))) return toast('日付は YYYY-MM-DD で入力してください');
    const idSet = new Set(ids); const snapshots=DATA.tasks.filter(t=>idSet.has(t.id)).map(cloneRecord);
    const changed=snapshots.map(t=>Object.assign(cloneRecord(t), {due:clean(ds), updatedAt:new Date().toISOString()}));
    const {reloaded,failed}=await saveWorkItems('tasks', changed, baseItemsFrom(snapshots)); if(failed)return;
    bulkClearSelection();
    const msg='期限を一括変更しました';
    toast(reloaded ? `${msg}（最新データを反映）` : msg, {actionLabel:'元に戻す', onAction:()=>restoreTaskSnapshots(snapshots, '一括操作を元に戻しました')});
  }
  function bulkClearSelection(){ SELECTED_TASK_IDS.clear(); $$('.bulk-task-check:checked').forEach(x=>x.checked=false); renderBulkActions(); }

  function captureModalReturnFocus(){
    const element=document.activeElement;
    const host=element?.closest?.('[data-task-id],[data-cycle-id],[data-record-id]');
    return {element,taskId:clean(host?.dataset?.taskId),cycleId:clean(host?.dataset?.cycleId),recordId:clean(host?.dataset?.recordId)};
  }
  function restoreModalReturnFocus(snapshot){
    if(!snapshot)return;
    let target=snapshot.element;
    if(!target || !document.contains(target)){
      const hosts=$$('[data-task-id],[data-cycle-id],[data-record-id]');
      const host=hosts.find(el=>(snapshot.taskId&&clean(el.dataset.taskId)===snapshot.taskId)||(snapshot.cycleId&&clean(el.dataset.cycleId)===snapshot.cycleId)||(snapshot.recordId&&clean(el.dataset.recordId)===snapshot.recordId));
      target=host?.querySelector('.card-title-button,.card-title-click,.card-edit-button,button,[role="button"]') || host;
    }
    if(!target || !document.contains(target))target=$('addTaskBtn') || $('workBoard');
    if(target && document.contains(target) && typeof target.focus==='function'){
      try{target.focus({preventScroll:true});}catch(_){target.focus();}
    }
  }
  function trapKeyboardFocus(event, container){
    if(event.key!=='Tab' || !container)return false;
    const focusable=$$('button:not([disabled]),input:not([disabled]),textarea:not([disabled]),select:not([disabled]),a[href],[tabindex]:not([tabindex="-1"])',container).filter(el=>el.getClientRects().length>0);
    if(!focusable.length){event.preventDefault();container.focus?.();return true;}
    const first=focusable[0], last=focusable[focusable.length-1], active=document.activeElement;
    if(event.shiftKey && (active===first || !container.contains(active))){event.preventDefault();last.focus();return true;}
    if(!event.shiftKey && (active===last || !container.contains(active))){event.preventDefault();first.focus();return true;}
    return false;
  }

  function openModal(title,html,onSubmit,onDelete){
    if(MODAL_SAVING){ toast('保存が終わるまでお待ちください'); return false; }
    const backdrop=$('modalBackdrop');
    if(backdrop && !backdrop.hidden){toast('開いている画面を閉じてから操作してください');return false;}
    if(backdrop?.hidden !== false){
      MODAL_RETURN_FOCUS=captureModalReturnFocus();
    }
    const session=++MODAL_SESSION;
    $('modalTitle').textContent=title; const form=$('modalForm');
    if(html && typeof html === 'object' && typeof html.nodeType === 'number') form.replaceChildren(html);
    else form.innerHTML=html;
    backdrop?.classList.toggle('task-editor-open',!!form.querySelector('.task-editor-modal'));
    dirtyModal=false;
    bindFieldPresets(form);
    form.querySelectorAll('input,textarea,select').forEach(x=>x.addEventListener('input',()=>{ if(!x.matches('[data-person-candidate-search]')) dirtyModal=true; }));
    let saving=false;
    const setSaving=on=>{
      if(session !== MODAL_SESSION)return;
      saving=on;
      MODAL_SAVING=on;
      form.classList.toggle('is-saving',on);
      form.setAttribute('aria-busy',on?'true':'false');
      const submit=form.querySelector('button[type="submit"]');
      form.querySelectorAll('input,textarea,select,button').forEach(el=>{
        if(on){el.dataset.modalWasDisabled=el.disabled?'1':'0';el.disabled=true;}
        else{el.disabled=el.dataset.modalWasDisabled==='1';delete el.dataset.modalWasDisabled;}
      });
      if(submit){ if(!submit.dataset.idleLabel)submit.dataset.idleLabel=submit.textContent||'保存'; submit.textContent=on?'保存中…':submit.dataset.idleLabel; }
      const close=$('modalClose'); if(close)close.disabled=on;
    };
    form.onsubmit=async e=>{
      e.preventDefault();
      if(saving)return;
      const formData=new FormData(form);
      setSaving(true);
      try {
        const result = onSubmit ? await onSubmit(formData, form) : null;
        if(session !== MODAL_SESSION)return;
        if(result === false || result?.cancelled){ setSaving(false); return; }
        dirtyModal=false; setSaving(false); closeModal(true,session);
      } catch(err) {
        if(session !== MODAL_SESSION)return;
        setSaving(false);
        if(err?.handled) return;
        if(err?.cancelled){ toast(err.message || '保存を中止しました'); return; }
        toast(err?.message || '保存に失敗しました');
        return false;
      }
    };
    form.querySelector('[data-cancel]')?.addEventListener('click',()=>closeModal(false));
    form.querySelector('[data-delete]')?.addEventListener('click',async()=>{
      if(!onDelete || saving)return;
      if(!await askConfirm('削除しますか？', 'この内容を削除します。', '削除する') || session !== MODAL_SESSION)return;
      setSaving(true);
      try{
        const result=await onDelete();
        if(session !== MODAL_SESSION)return;
        if(result===false || result?.cancelled){setSaving(false);return;}
        dirtyModal=false; setSaving(false); closeModal(true,session);
      }catch(err){
        if(session !== MODAL_SESSION)return;
        setSaving(false); toast(err?.message || '削除に失敗しました');
      }
    });
    if(backdrop)backdrop.hidden=false; setTimeout(()=>form.querySelector('input,textarea,select,button')?.focus(),20);
    return true;
  }
  function closeModal(force=false,session=MODAL_SESSION){
    if(session !== MODAL_SESSION)return false;
    if(MODAL_SAVING){ toast('保存が終わるまでお待ちください'); return false; }
    if(!force&&dirtyModal){ askConfirm('入力中の内容があります', '保存せずに編集画面を閉じますか？', '閉じる').then(ok=>{ if(ok && session===MODAL_SESSION) closeModal(true,session); }); return false; }
    const backdrop=$('modalBackdrop');
    if(backdrop){backdrop.hidden=true;backdrop.classList.remove('task-editor-open');backdrop.removeAttribute('aria-busy');}
    const form=$('modalForm'); if(form){form.innerHTML='';form.classList.remove('is-saving');form.removeAttribute('aria-busy');}
    const close=$('modalClose'); if(close)close.disabled=false;
    dirtyModal=false; MODAL_SAVING=false; MODAL_SESSION++;
    const returnFocus=MODAL_RETURN_FOCUS; MODAL_RETURN_FOCUS=null;
    restoreModalReturnFocus(returnFocus);
    flushPendingDataSync(); scheduleResumeSync();
    return true;
  }
  function selectedPeople(form){ const picker=form.querySelector('[data-people]'); if(picker?._selectedPersonIds instanceof Set)return [...picker._selectedPersonIds]; return $$('[data-people] input:checked', form).map(x=>x.value); }
  function personSearchText(p){ return [p.name,p.kana,p.kind,p.term,p.org,p.role,p.section,p.title,p.tags,p.note].map(clean).filter(Boolean).join(' ').toLowerCase(); }
  function peopleChoices(selected=[], target='personIds'){
    const set=new Set(arr(selected));
    const boxes=SPEC.people.map(p=>`<label class="pill-select person-chip-option" data-person-candidate="${esc(target)}" data-person-text="${esc(personSearchText(p))}"><input type="checkbox" value="${esc(p.id)}" ${set.has(p.id)?'checked':''}> <span>${esc(p.name)}${p.kind||p.term?`<small>${esc([p.kind,p.term].filter(Boolean).join('・'))}</small>`:''}</span></label>`).join('') || '<span class="muted">人物登録なし</span>';
    return `<div class="selected-person-chips" data-selected-person-chips="${esc(target)}"></div><input class="person-candidate-search" type="search" data-person-candidate-search data-person-target="${esc(target)}" placeholder="名前・所属・期別で検索"><small class="person-search-count" data-person-search-count="${esc(target)}"></small><div class="person-candidate-list compact-person-candidates">${boxes}</div>`;
  }
  function bindPeopleSearch(root){
    $$('[data-person-candidate-search]', root).forEach(input=>{
      const target=input.dataset.personTarget || 'personIds';
      const apply=()=>{
        const q=clean(input.value).toLowerCase(); let total=0, shown=0, selected=0;
        const els=$$('[data-person-candidate]', root).filter(el=>(el.dataset.personCandidate||'')===target);
        const chipBox = root.querySelector(`[data-selected-person-chips="${CSS.escape(target)}"]`); if(chipBox) chipBox.innerHTML='';
        els.forEach(el=>{
          total++; const check=el.querySelector('input[type="checkbox"]'); const checked=!!(check&&check.checked); if(checked)selected++;
          const name=clean(el.textContent); if(checked && chipBox){ const b=document.createElement('button'); b.type='button'; b.className='person-chip'; b.textContent=`${name} ×`; b.onclick=()=>{check.checked=false; apply(); dirtyModal=true;}; chipBox.appendChild(b); }
          const hit=checked || (!!q && (el.dataset.personText||'').includes(q)); el.hidden=!hit; if(hit)shown++;
        });
        new Set(els.map(el=>el.closest('.person-candidate-list')).filter(Boolean)).forEach(list=>list.classList.toggle('empty-candidates', !q && shown===0));
        $$('[data-person-search-count]', root).filter(el=>(el.dataset.personSearchCount||'')===target).forEach(el=>{ el.textContent = !total ? '候補はまだありません' : (!q ? (selected ? `選択中${selected}人。検索で追加できます` : '名前を入力すると候補を表示します') : `${Math.min(shown, 10)}/${total}人を表示（選択中${selected}人）`); });
        els.filter(el=>!el.hidden).forEach((el,i)=>{ if(!el.querySelector('input')?.checked && q) el.hidden = i >= 10; });
      };
      input.addEventListener('input', apply);
      $$('[data-person-candidate]', root).filter(el=>(el.dataset.personCandidate||'')===target).forEach(el=>el.querySelector('input[type="checkbox"]')?.addEventListener('change',()=>{ dirtyModal=true; apply(); }));
      apply();
    });
  }
  function fieldExtras(f){ const presets=arr(f.presets).filter(x=>arr(x).length>=2); const chips=presets.length?`<div class="field-presets" aria-label="${esc(f.label)}の候補">${presets.map(([value,label])=>`<button type="button" class="preset-chip" data-set-field="${esc(f.name)}" data-set-value="${esc(value)}">${esc(label)}</button>`).join('')}</div>`:''; const hint=f.hint?`<small class="field-hint">${esc(f.hint)}</small>`:''; return chips+hint; }
  function bindFieldPresets(root){ $$('[data-set-field]', root).forEach(btn=>btn.addEventListener('click',()=>{ const name=btn.dataset.setField||''; const el=root.elements?root.elements[name]:null; if(!el)return; el.value=btn.dataset.setValue||''; dirtyModal=true; el.dispatchEvent(new Event('input',{bubbles:true})); el.dispatchEvent(new Event('change',{bubbles:true})); el.focus?.(); })); }
  function field(v,f){ const val=v[f.name]??f.value??''; const full=f.full?' full':''; const extras=fieldExtras(f); if(f.type==='textarea')return`<label class="field${full}"><span>${esc(f.label)}</span><textarea name="${esc(f.name)}">${esc(val)}</textarea>${extras}</label>`; if(f.type==='select')return`<label class="field${full}"><span>${esc(f.label)}</span><select name="${esc(f.name)}">${f.options.map(o=>`<option value="${esc(o[0])}" ${String(val)===String(o[0])?'selected':''}>${esc(o[1])}</option>`).join('')}</select>${extras}</label>`; if(f.type==='people')return`<div class="field full"><span>${esc(f.label)}</span><div class="multi-box people-picker" data-people>${peopleChoices(val, f.name)}</div>${extras}</div>`; return`<label class="field${full}"><span>${esc(f.label)}</span><input name="${esc(f.name)}" type="${esc(f.type||'text')}" value="${esc(val)}">${extras}</label>`; }
  function form(v,fields,del=false){return`<div class="form-grid">${fields.map(f=>field(v,f)).join('')}<div class="modal-actions"><div>${del?'<button type="button" class="ghost" data-delete>削除</button>':''}</div><div><button type="button" class="ghost" data-cancel>閉じる</button><button type="submit" class="primary">保存</button></div></div></div>`;}

  function makeEditorField(v,config){
    const label=document.createElement('label'); label.className=`field${config.full?' full':''}`;
    const caption=document.createElement('span'); caption.textContent=config.label; label.appendChild(caption);
    let control;
    if(config.type==='select'){
      control=document.createElement('select');
      arr(config.options).forEach(([value,text])=>{ const option=document.createElement('option'); option.value=String(value); option.textContent=String(text); option.selected=String(v[config.name]??'')===String(value); control.appendChild(option); });
    }else if(config.type==='textarea'){
      control=document.createElement('textarea'); control.value=String(v[config.name]??'');
    }else{
      control=document.createElement('input'); control.type=config.type||'text'; control.value=String(v[config.name]??'');
      if(config.type==='number'){ control.min='0'; control.max=String(24*60); control.step='5'; }
    }
    control.name=config.name; label.appendChild(control);
    const presets=arr(config.presets).filter(x=>arr(x).length>=2);
    if(presets.length){
      const presetBox=document.createElement('div'); presetBox.className='field-presets'; presetBox.setAttribute('aria-label',`${config.label}の候補`);
      presets.forEach(([value,text])=>{ const button=document.createElement('button'); button.type='button'; button.className='preset-chip'; button.textContent=text; button.addEventListener('click',()=>{ control.value=String(value); dirtyModal=true; control.dispatchEvent(new Event('input',{bubbles:true})); control.dispatchEvent(new Event('change',{bubbles:true})); control.focus(); }); presetBox.appendChild(button); });
      label.appendChild(presetBox);
    }
    if(config.hint){ const hint=document.createElement('small'); hint.className='field-hint'; hint.textContent=config.hint; label.appendChild(hint); }
    return label;
  }

  function makePersonCandidate(person,selected,onToggle){
    const label=document.createElement('label'); label.className='pill-select person-chip-option';
    const check=document.createElement('input'); check.type='checkbox'; check.value=person.id; check.checked=selected; check.addEventListener('change',()=>onToggle(person.id,check.checked)); label.appendChild(check);
    const text=document.createElement('span'); text.textContent=person.name || '名前未登録';
    const sub=[person.kind,person.term].map(clean).filter(Boolean).join('・');
    if(sub){ const small=document.createElement('small'); small.textContent=sub; text.appendChild(small); }
    label.appendChild(text);
    return label;
  }

  function makePeoplePicker(selected=[]){
    const field=document.createElement('div'); field.className='field full';
    const caption=document.createElement('span'); caption.textContent='関係者'; field.appendChild(caption);
    const picker=document.createElement('div'); picker.className='multi-box people-picker lazy-people-picker'; picker.dataset.people='';
    const selectedIds=new Set(arr(selected).filter(Boolean)); picker._selectedPersonIds=selectedIds;
    const chips=document.createElement('div'); chips.className='selected-person-chips'; picker.appendChild(chips);
    const search=document.createElement('input'); search.type='search'; search.className='person-candidate-search'; search.dataset.personCandidateSearch=''; search.placeholder='名前・所属・期別で検索'; search.setAttribute('aria-label','関係者を検索'); picker.appendChild(search);
    const count=document.createElement('small'); count.className='person-search-count'; picker.appendChild(count);
    const results=document.createElement('div'); results.className='person-candidate-list compact-person-candidates person-picker-results'; picker.appendChild(results);
    const renderPicker=()=>{
      chips.replaceChildren();
      [...selectedIds].forEach(id=>{ const person=PERSON_BY_ID.get(id); const chip=document.createElement('button'); chip.type='button'; chip.className='person-chip'; chip.textContent=`${person?.name || '登録外の人物'} ×`; chip.setAttribute('aria-label',`${person?.name || '登録外の人物'}を選択解除`); chip.addEventListener('click',()=>{ selectedIds.delete(id); dirtyModal=true; renderPicker(); picker.dispatchEvent(new Event('change',{bubbles:true})); }); chips.appendChild(chip); });
      const q=clean(search.value).toLowerCase();
      const selectedPeople=[...selectedIds].map(id=>PERSON_BY_ID.get(id)).filter(Boolean);
      const matched=q ? arr(SPEC.people).filter(person=>!selectedIds.has(person.id) && (PERSON_SEARCH_BY_ID.get(person.id)||'').includes(q)).slice(0,10) : [];
      const candidates=[...selectedPeople,...matched];
      const nodes=candidates.map(person=>makePersonCandidate(person,selectedIds.has(person.id),(id,on)=>{ if(on)selectedIds.add(id); else selectedIds.delete(id); dirtyModal=true; renderPicker(); picker.dispatchEvent(new Event('change',{bubbles:true})); }));
      if(!nodes.length){ const empty=document.createElement('span'); empty.className='muted'; empty.textContent=q?'一致する人物はありません':'名前を入力すると候補を表示します'; nodes.push(empty); }
      results.replaceChildren(...nodes);
      count.textContent=q?`${matched.length}人を表示・選択中${selectedIds.size}人`:`選択中${selectedIds.size}人。検索して追加できます`;
    };
    search.addEventListener('input',debounce(renderPicker,80));
    renderPicker(); field.appendChild(picker); return field;
  }

  function taskAdvancedSummaryParts(v={},formEl=null){
    const fieldValue=name=>clean(formEl?.elements?.[name]?.value ?? v?.[name]);
    const parts=[];
    const caseId=fieldValue('caseId');
    const personIds=formEl ? selectedPeople(formEl) : arr(v?.personIds).filter(Boolean);
    if(caseId)parts.push(`事案: ${caseName(caseId)||'設定済み'}`);
    if(personIds.length)parts.push(`関係者${personIds.length}人`);
    if(fieldValue('peopleText'))parts.push('人物台帳外あり');
    if(fieldValue('note'))parts.push('メモあり');
    if(fieldValue('sortOrder'))parts.push(`手動順 ${fieldValue('sortOrder')}`);
    return parts;
  }

  function refreshTaskAdvancedSummary(formEl,v={}){
    const details=formEl?.querySelector('.advanced-fields');
    const meta=details?.querySelector('[data-advanced-summary-meta]');
    if(!meta)return;
    const parts=taskAdvancedSummaryParts(v,formEl);
    meta.textContent=parts.length ? parts.join('・') : '追加情報なし';
    meta.classList.toggle('has-values',parts.length>0);
  }

  function makeTaskEditor(v,isNew){
    const root=document.createElement('div'); root.className='task-editor-modal';
    const basicHead=document.createElement('div'); basicHead.className='task-editor-section-head';
    const basicTitle=document.createElement('b'); basicTitle.textContent=isNew?'新しい作業':'作業の内容'; basicHead.appendChild(basicTitle);
    const basicHint=document.createElement('span'); basicHint.textContent='よく使う項目から入力'; basicHead.appendChild(basicHint); root.appendChild(basicHead);
    const basic=document.createElement('section'); basic.className='task-basic-fields form-grid';
    [
      {name:'title',label:'作業名',full:true},
      {name:'nextAction',label:'次にすること',full:true},
      {name:'due',label:'期限',type:'date',presets:datePresets()},
      {name:'priority',label:'優先度',type:'select',options:[['normal','通常'],['high','高優先'],['low','低優先']],presets:priorityPresets()},
      {name:'status',label:'表示する列',type:'select',options:columns,presets:statusPresets()},
      {name:'estimateMinutes',label:'見積時間（分）',type:'number',presets:durationPresets(),hint:'必要な作業だけ入力します。'}
    ].forEach(config=>basic.appendChild(makeEditorField(v,config)));
    root.appendChild(basic);

    const advancedParts=taskAdvancedSummaryParts(v);
    const advanced=document.createElement('details'); advanced.className='advanced-fields'; advanced.open=advancedParts.length>0;
    const summary=document.createElement('summary');
    const summaryLabel=document.createElement('span'); summaryLabel.className='advanced-summary-label'; summaryLabel.textContent='関係・メモ・並び順'; summary.appendChild(summaryLabel);
    const summaryMeta=document.createElement('span'); summaryMeta.className=`advanced-summary-meta ${advancedParts.length?'has-values':''}`.trim(); summaryMeta.dataset.advancedSummaryMeta=''; summaryMeta.textContent=advancedParts.length?advancedParts.join('・'):'追加情報なし'; summary.appendChild(summaryMeta); advanced.appendChild(summary);
    const advancedGrid=document.createElement('div'); advancedGrid.className='advanced-fields-grid form-grid';
    advancedGrid.appendChild(makeEditorField(v,{name:'caseId',label:'事案',type:'select',options:[['','なし'],...SPEC.cases.map(c=>[c.id,c.title||c.name||'無題の事案'])]}));
    advancedGrid.appendChild(makePeoplePicker(v.personIds));
    advancedGrid.appendChild(makeEditorField(v,{name:'peopleText',label:'直接入力の関係者',full:true}));
    advancedGrid.appendChild(makeEditorField(v,{name:'sortOrder',label:'手動順'}));
    advancedGrid.appendChild(makeEditorField(v,{name:'note',label:'メモ',type:'textarea',full:true}));
    advanced.appendChild(advancedGrid); root.appendChild(advanced);

    const actions=document.createElement('div'); actions.className='modal-actions';
    const left=document.createElement('div'); if(!isNew){ const del=document.createElement('button'); del.type='button'; del.className='drawer-delete-button'; del.dataset.delete=''; del.textContent='この作業を削除…'; left.appendChild(del); } actions.appendChild(left);
    const right=document.createElement('div'); const cancel=document.createElement('button'); cancel.type='button'; cancel.className='ghost'; cancel.dataset.cancel=''; cancel.textContent='閉じる'; right.appendChild(cancel); const saveButton=document.createElement('button'); saveButton.type='submit'; saveButton.className='primary'; saveButton.textContent='保存して閉じる'; right.appendChild(saveButton); actions.appendChild(right); root.appendChild(actions);
    return root;
  }

  function openTaskModal(item={}){
    const isNew=!item.id; const v=Object.assign({id:uid('wk'),title:'',status:'next',priority:'normal',due:'',estimateMinutes:0,nextAction:'',caseId:'',personIds:[],peopleText:'',note:'',source:''},item);
    const opened=openModal(isNew?'作業を追加':'作業を編集',makeTaskEditor(v,isNew), async (fd, formEl)=>{
      const obj={...v,title:clean(fd.get('title'))||'無題の作業',status:validStatus(fd.get('status')||'next'),priority:fd.get('priority')||'normal',due:fd.get('due')||'',estimateMinutes:Math.max(0,Math.min(24*60,Math.round(Number(fd.get('estimateMinutes')||0)||0))),caseId:clean(fd.get('caseId')),personIds:selectedPeople(formEl),peopleText:clean(fd.get('peopleText')),sortOrder:clean(fd.get('sortOrder')),nextAction:clean(fd.get('nextAction')),note:String(fd.get('note')||''),updatedAt:new Date().toISOString()};
      if(obj.status==='done' && !obj.completedAt) obj.completedAt=today(); if(obj.status!=='done') delete obj.completedAt;
      return persistTaskOptimistically(obj,isNew?null:v,{message:isNew?'作業を追加しました':'作業を保存しました'});
    }, async()=>deleteTaskRecord(v.id));
    if(!opened)return false;
    const formEl=$('modalForm');
    const refreshAdvanced=()=>refreshTaskAdvancedSummary(formEl,v);
    formEl?.addEventListener('input',refreshAdvanced);
    formEl?.addEventListener('change',refreshAdvanced);
    refreshAdvanced();
    return true;
  }
  function cycleRuleOptions(current=''){
    const ruleOptions=[['毎日','毎日'],['毎週','毎週'],['毎月','毎月'],['2か月ごと','2か月ごと'],['3か月ごと','3か月ごと'],['毎年','毎年']];
    const currentRule=clean(current);
    if(currentRule && !ruleOptions.some(([value])=>value===currentRule)) ruleOptions.unshift([currentRule,currentRule]);
    return ruleOptions;
  }
  function openCycleModal(item={}){
    const isNew=!item.id; const v=Object.assign({id:uid('cy'),title:'',status:'next',state:'active',rule:'毎月',nextRunDate:today(),priority:'normal',note:''},item);
    Object.assign(v,normalizedCycleStateStatus(v));
    v.cyclePlacement=v.status;
    const ruleOptions=cycleRuleOptions(v.rule);
    const opened=openModal(isNew?'周期作業を追加':'周期作業を編集',form(v,[
      {name:'title',label:'作業名',full:true}, {name:'cyclePlacement',label:'状態・表示先',type:'select',options:cycleColumns,presets:cycleColumns}, {name:'rule',label:'周期',type:'select',options:ruleOptions}, {name:'nextRunDate',label:'次回日',type:'date',presets:datePresets()}, {name:'priority',label:'優先度',type:'select',options:[['normal','通常'],['high','高優先'],['low','低優先']],presets:priorityPresets()}, {name:'note',label:'メモ',type:'textarea'}
    ],!isNew), async fd=>{
      const status=validStatus(fd.get('cyclePlacement')||v.status||'next');
      const state=status==='waiting'?'paused':status==='done'?'ended':'active';
      const obj={...v,title:clean(fd.get('title'))||'無題の周期作業',state,status,rule:fd.get('rule')||'毎月',nextRunDate:fd.get('nextRunDate')||today(),priority:fd.get('priority')||'normal',note:String(fd.get('note')||''),updatedAt:new Date().toISOString()};
      delete obj.cyclePlacement;
      if(state==='ended'){
        if(!obj.endedAt)obj.endedAt=today();
        if(!obj.completedAt)obj.completedAt=today();
        delete obj.pausedAt;
      }else if(state==='paused'){
        if(!obj.pausedAt)obj.pausedAt=today();
        delete obj.endedAt; delete obj.completedAt;
      }else{
        delete obj.pausedAt; delete obj.endedAt; delete obj.completedAt;
      }
      const result=await runCycleMutation(v.id,async()=>{
        const j=await api('/api/continuum/cycle-upsert', {method:'POST', body:JSON.stringify({item:obj, baseHash:HASH, baseItemUpdatedAt:itemBaseUpdatedAt(v)})});
        return {reloaded:await applySavedWorkMutation('cycleTasks', j, obj)};
      });
      if(!result.ok)return false;
      toast(result.value.reloaded ? '保存しました（最新データを反映）' : '保存しました');
      return true;
    }, async()=>deleteCycleRecord(v.id));
    if(!opened)return false;
    return true;
  }
  function upsert(k,obj){
    const indexMap=k==='tasks'?TASK_INDEX_BY_ID:(k==='cycleTasks'?CYCLE_INDEX_BY_ID:null);
    const storedIndex=indexMap?.get(obj.id);
    const i=Number.isInteger(storedIndex)?storedIndex:-1;
    const previous=i>=0?DATA[k][i]:null;
    if(i>=0)DATA[k][i]=obj;
    else { DATA[k].push(obj); indexMap?.set(obj.id,DATA[k].length-1); }
    if(k==='tasks'){
      TASK_BY_ID.set(obj.id,obj);
      TASK_INDEX_BY_ID.set(obj.id,i>=0?i:DATA.tasks.length-1);
      const previousSource=sourceRef(previous), nextSource=sourceRef(obj);
      if(nextSource)TASK_SOURCE_KEYS.add(nextSource);
      if(previousSource && previousSource!==nextSource && !DATA.tasks.some(item=>sourceRef(item)===previousSource))TASK_SOURCE_KEYS.delete(previousSource);
      TASK_SEARCH_BY_ID.set(obj.id, searchableTask(obj));
    }
  }
  function normalizeTaskClient(t){ const x={...t,status:validStatus(t?.status||'next'),personIds:arr(t?.personIds),estimateMinutes:estimateMinutes(t)}; if(x.status!=='done') delete x.completedAt; return x; }
  function normalizeCycleClient(c){ const normalized=normalizedCycleStateStatus(c); return {...c,...normalized}; }
  function applySavedWorkItem(collection, item, hash){
    if(hash) HASH = hash;
    if(!item || !item.id) return;
    if(collection === 'cycleTasks' || collection === 'cycles') upsert('cycleTasks', normalizeCycleClient(item));
    else upsert('tasks', normalizeTaskClient(item));
  }
  async function applySavedWorkMutation(collection, result, fallback){
    if(result?.hash) HASH = result.hash;
    if(result?.merged){ await load(); return true; }
    applySavedWorkItem(collection, result?.item || fallback, result?.hash);
    return false;
  }
  async function applySavedWorkItemsMutation(collection, result, fallbackItems=[]){
    if(result?.hash) HASH = result.hash;
    if(result?.merged){ await load(); return true; }
    const items = arr(result?.items).length ? arr(result.items) : arr(fallbackItems);
    if(collection === 'cycleTasks' || collection === 'cycles') {
      const normalized=items.map(normalizeCycleClient);
      const byId=new Map(normalized.map(item=>[item.id,item]));
      DATA.cycleTasks=DATA.cycleTasks.map(item=>byId.get(item.id)||item);
      const existing=new Set(DATA.cycleTasks.map(item=>item.id));
      normalized.forEach(item=>{ if(!existing.has(item.id))DATA.cycleTasks.push(item); });
      rebuildCycleIndex();
    } else {
      const normalized=items.map(normalizeTaskClient);
      const byId=new Map(normalized.map(item=>[item.id,item]));
      DATA.tasks=DATA.tasks.map(item=>byId.get(item.id)||item);
      const existing=new Set(DATA.tasks.map(item=>item.id));
      normalized.forEach(item=>{ if(!existing.has(item.id))DATA.tasks.push(item); });
      rebuildContinuumIndexes();
    }
    return false;
  }
  function baseItemsFrom(items){ return arr(items).map(x=>({id:x?.id, updatedAt:clean(x?.updatedAt || '')})).filter(x=>clean(x.id)); }
  async function saveWorkItems(collection, items, baseItems=[]){
    const kind = (collection === 'cycleTasks' || collection === 'cycles') ? 'cycleTasks' : 'tasks';
    const list = arr(items).filter(Boolean);
    if(!list.length) return {j:{ok:true,items:[],hash:HASH}, reloaded:false};
    const optimistic=kind==='tasks';
    const ids=new Set(list.map(x=>x.id).filter(Boolean));
    const previous=optimistic ? new Map(DATA.tasks.filter(x=>ids.has(x.id)).map(x=>[x.id,cloneRecord(x)])) : new Map();
    if(optimistic && [...ids].some(id=>PENDING_TASK_IDS.has(id))){ toast('選択した作業に保存中の項目があります'); return {j:null,reloaded:false,failed:true}; }
    const baseHash=HASH;
    if(optimistic){
      ids.forEach(id=>PENDING_TASK_IDS.add(id));
      const byId=new Map(list.map(item=>[item.id,normalizeTaskClient(item)]));
      DATA.tasks=DATA.tasks.map(item=>byId.get(item.id)||item);
      byId.forEach((item,id)=>{ if(!previous.has(id))DATA.tasks.push(item); });
      rebuildContinuumIndexes(); renderTaskViews();
    }
    try{
      const j = await api('/api/continuum/items-upsert', {method:'POST', body:JSON.stringify({collection:kind, items:list, baseHash, baseItems})});
      const reloaded = await applySavedWorkItemsMutation(kind, j, list);
      ids.forEach(id=>PENDING_TASK_IDS.delete(id));
      flushPendingDataSync();
      if(optimistic){ if(reloaded)render(); else refreshRenderedTaskCards([...ids]); }
      return {j, reloaded, failed:false};
    }catch(err){
      ids.forEach(id=>PENDING_TASK_IDS.delete(id));
      flushPendingDataSync();
      if(optimistic){
        DATA.tasks=DATA.tasks.filter(item=>!ids.has(item.id));
        previous.forEach(item=>DATA.tasks.push(item));
        rebuildContinuumIndexes();
        if(err?.status===409 || err?.data?.conflict){ try{await load();render();}catch(_){renderTaskViews();} toast('別画面の変更を反映しました。内容を確認して、もう一度操作してください'); }
        else { renderTaskViews(); toast(err?.message||'保存できなかったため、変更前に戻しました'); }
        return {j:null,reloaded:false,failed:true};
      }
      throw err;
    }
  }
  function itemBaseUpdatedAt(item){ return clean(item?.updatedAt || ''); }
  function insertQuickText(text){ const input=$('quickTaskText'); if(!input)return; const add=String(text||''); const sep=input.value && !/\s$/.test(input.value) && !/^\s/.test(add) ? ' ' : ''; input.value=`${input.value}${sep}${add}`; input.focus(); input.dispatchEvent(new Event('input',{bubbles:true})); }
  function setQuickAddBusy(on,cycle=false){
    QUICK_ADD_BUSY=on;
    const input=$('quickTaskText');
    const taskButton=$('quickTaskBtn');
    const cycleButton=$('quickCycleBtn');
    const composer=input?.closest('.quick-composer');
    if(composer)composer.setAttribute('aria-busy',on?'true':'false');
    if(input)input.disabled=on;
    composer?.querySelectorAll('button').forEach(button=>{
      if(on){button.dataset.quickWasDisabled=button.disabled?'1':'0';button.disabled=true;}
      else{button.disabled=button.dataset.quickWasDisabled==='1';delete button.dataset.quickWasDisabled;}
    });
    [taskButton,cycleButton].filter(Boolean).forEach(button=>{
      if(!button.dataset.idleLabel)button.dataset.idleLabel=button.textContent||'追加';
      button.textContent=on && ((cycle && button===cycleButton)||(!cycle && button===taskButton)) ? '追加中…' : button.dataset.idleLabel;
    });
  }
  async function quick(cycle=false){
    if(QUICK_ADD_BUSY){toast('追加処理中です');return false;}
    const input=$('quickTaskText');
    const text=clean(input?.value);
    if(!text)return toast('作業内容を入力してください');
    setQuickAddBusy(true,cycle);
    try{
      const j=await api(cycle?'/api/continuum/cycle-add':'/api/continuum/quick-add',{method:'POST',body:JSON.stringify({text,status:'next',baseHash:HASH})});
      if(input)input.value='';
      await applySavedWorkMutation(cycle?'cycleTasks':'tasks', j, j.item);
      render();
      const id=j?.item?.id;
      toast(cycle?'周期作業を追加しました':'作業を追加しました', addedRecordUndo(cycle?'cycles':'tasks', id?[id]:[], cycle?'周期作業の追加を元に戻しました':'作業の追加を元に戻しました'));
      return true;
    }catch(err){
      toast(err?.message || (cycle?'周期作業を追加できませんでした':'作業を追加できませんでした'));
      return false;
    }finally{
      setQuickAddBusy(false,cycle);
      input?.focus();
    }
  }

  async function openBackupModal(){
    if(!openModal('保存・復元', `<p class="modal-note">普段は自動保存します。手動で控えを作る、または過去の控えへ戻す時だけ使います。</p><div class="form-grid"><label class="field"><span>対象</span><select id="backupApp"><option value="continuum">作業管理</option><option value="speculum">今日・日付確認</option></select></label><div class="field"><span>操作</span><button type="button" class="primary" id="createBackupBtn">今の控えを作成</button></div><div class="field full"><span>控え一覧</span><div class="backup-list" id="backupList"></div></div><div class="modal-actions"><div></div><div><button type="button" class="ghost" data-cancel>閉じる</button></div></div></div>`, async()=>{}, null))return false;
    const fileSize = n => { const v=Math.max(0,Number(n)||0); return v>=1048576 ? `${(v/1048576).toFixed(1)} MB` : v>=1024 ? `${Math.round(v/1024)} KB` : `${Math.round(v)} B`; };
    let backupBusy=false, refreshSequence=0;
    const setBackupBusy=on=>{
      backupBusy=!!on;
      const form=$('modalForm');
      form?.querySelectorAll('#backupApp,#createBackupBtn,.backup-row button').forEach(el=>{el.disabled=backupBusy;});
      form?.setAttribute('aria-busy',backupBusy?'true':'false');
    };
    const refresh = async()=>{
      const sequence=++refreshSequence;
      const app=clean($('backupApp')?.value || 'continuum');
      const box=$('backupList'); if(!box)return false;
      box.setAttribute('aria-busy','true');
      try{
        const j=await api(`/api/backups/list?app=${encodeURIComponent(app)}`);
        if(sequence!==refreshSequence || !$('backupList'))return false;
        const items=arr(j.items);
        if(!items.length){box.innerHTML='<div class="empty">控えはまだありません。</div>';return true;}
        box.innerHTML='';
        items.forEach(backup=>{
          const row=document.createElement('div'); row.className='backup-row';
          row.innerHTML=`<div><b>${esc(backup.label || backup.name)}</b><span>${esc(fileSize(backup.size))}${backup.source === 'sqlite' ? ' / 保存履歴' : ''}</span></div><button type="button" class="mini">復元</button>`;
          row.querySelector('button').onclick=async()=>{
            if(backupBusy)return toast('保存・復元の処理中です');
            setBackupBusy(true);
            if(!await askConfirm('控えを復元しますか？','現在の状態を控えてから、この控えの内容へ戻します。','復元する')){setBackupBusy(false);return;}
            try{
              if(app==='continuum')await settleMemoBeforeRestore();
              await api('/api/backups/create',{method:'POST',body:JSON.stringify({app})});
              await api('/api/backups/restore',{method:'POST',body:JSON.stringify({app,name:backup.name})});
              if(app==='continuum')resetMemoSaveAfterRestore();
              toast('復元しました'); closeModal(true); await load(); render();
            }catch(err){toast(err?.message || '復元できませんでした');}
            finally{if(!$('modalBackdrop')?.hidden)setBackupBusy(false);}
          };
          box.appendChild(row);
        });
        setBackupBusy(backupBusy);
        return true;
      }catch(err){if(sequence===refreshSequence){box.innerHTML='<div class="empty">控え一覧を読み込めませんでした。</div>';toast(err?.message || '控え一覧を読み込めませんでした');}return false;}
      finally{if(sequence===refreshSequence)box.removeAttribute('aria-busy');}
    };
    $('backupApp')?.addEventListener('change',refresh);
    $('createBackupBtn')?.addEventListener('click',async()=>{
      if(backupBusy)return toast('保存・復元の処理中です');
      setBackupBusy(true);
      try{await api('/api/backups/create',{method:'POST',body:JSON.stringify({app:$('backupApp')?.value || 'continuum'})});toast('控えを作成しました');await refresh();}
      catch(err){toast(err?.message || '控えを作成できませんでした');}
      finally{setBackupBusy(false);}
    });
    await refresh();
    return true;
  }
  async function openApp(target){ openWorkspace(target); return {ok:true}; }
  function bindTrash(){ const trash=$('workTrash'); if(!trash)return; bindDrop(trash, async payload=>{ if(payload.type==='task') await deleteTask(payload.id); else if(payload.type==='cycle') await deleteCycle(payload.id); }); }
  function bind(){
    if(!document.body.dataset.blackcatCloseActionMenusBound){
      document.body.dataset.blackcatCloseActionMenusBound = '1';
      document.addEventListener('click', e => {
        if(!e.target?.closest?.('.action-menu')) closeActionMenus();
        const activeTool=e.target?.closest?.('.work-more-tools,.quick-options');
        $$('.work-more-tools[open],.quick-options[open]').forEach(details=>{if(details!==activeTool)details.open=false;});
      });
      document.addEventListener('keydown', e => {
        if(e.key==='Tab'){
          const prompt=document.querySelector('.center-confirm-backdrop .center-confirm');
          const modal=(!$('modalBackdrop')?.hidden)?$('modalBackdrop')?.querySelector('.modal-card'):null;
          trapKeyboardFocus(e,prompt||modal);
          return;
        }
        if(e.key !== 'Escape')return;
        const activeDisclosure=document.activeElement?.closest?.('.work-more-tools[open],.quick-options[open]');
        closeActionMenus(null,true);
        $$('.work-more-tools[open],.quick-options[open]').forEach(details=>details.open=false);
        if(activeDisclosure)focusWithoutScroll(activeDisclosure.querySelector(':scope > summary'));
        if(e.defaultPrevented || document.querySelector('.center-confirm-backdrop'))return;
        const modal=$('modalBackdrop');
        if(modal && !modal.hidden){e.preventDefault();closeModal(false);}
      });
    }
    const on=(id,ev,fn)=>{const el=$(id); if(el) el.addEventListener(ev,fn);};
    on('backMainBtn','click',()=>openApp('main'));
    on('openBackupBtn','click',openBackupModal); on('addTaskBtn','click',()=>openTaskModal()); on('addTaskVisibleBtn','click',()=>openTaskModal()); on('addCycleBtn','click',()=>openCycleModal());
    on('quickTaskBtn','click',()=>quick(false)); on('quickCycleBtn','click',()=>quick(true)); on('quickTaskText','keydown',e=>{if(e.key==='Enter'&&!e.isComposing){e.preventDefault();quick(false);}});
    $$('[data-quick-insert]').forEach(b=>b.addEventListener('click',()=>insertQuickText(b.dataset.quickInsert||'')));
    const renderFiltered = debounce(renderFilterResults, 80);
    on('workFilter','input',renderFiltered); on('clearWorkFilter','click',()=>{if($('workFilter'))$('workFilter').value='';renderFilterResults();});
    ['doneVisibleDays','boardLimit','boardDensity','workSortMode','dueDayCountMode'].forEach(id=>on(id,'change',async e=>{ DATA.settings=Object.assign(defaultSettings(), DATA.settings||{}); DATA.settings[id]=e.target.value; await saveSettings('表示設定を保存しました'); render(); }));
    $$('[data-work-scope]').forEach(b=>b.addEventListener('click',()=>{ WORK_SCOPE=b.dataset.workScope||'all'; render(); }));
    on('importFromSpeculumBtn','click',importAllFromSpeculum);
    on('saveWorkMemoBtn','click',()=>scheduleMemoSave(0,true));
    on('workMemo','input',()=>{DATA.memo=memoValue();scheduleMemoSave(900,false);});
    on('selectionModeBtn','click',()=>setSelectMode(!SELECT_MODE));
    on('bulkTodayBtn','click',()=>bulkMoveTasks('today')); on('bulkCompleteBtn','click',()=>bulkMoveTasks('done')); on('bulkWaitingBtn','click',()=>bulkMoveTasks('waiting')); on('bulkHighBtn','click',()=>bulkSetPriority('high')); on('bulkNormalBtn','click',()=>bulkSetPriority('normal')); on('bulkTomorrowBtn','click',()=>bulkShiftDue(1)); on('bulkNextWeekBtn','click',()=>bulkShiftDue(7)); on('bulkDueBtn','click',bulkSetDue); on('bulkClearBtn','click',bulkClearSelection);
    on('modalClose','click',()=>closeModal(false)); const backdrop=$('modalBackdrop'); if(backdrop) backdrop.onclick=e=>{if(e.target===backdrop){const c=document.querySelector('.modal-card'); if(c){c.classList.add('shake');setTimeout(()=>c.classList.remove('shake'),260);} toast('外側クリックでは閉じません。');}};
    window.addEventListener('message', e => {
      if(e.origin && e.origin!==location.origin)return;
      if (e.data && e.data.blackcatOpenBackup) openBackupModal();
      if (e.data && typeof e.data.blackcatWorkRoute === 'string') {
        const route = clean(e.data.blackcatWorkRoute);
        const nextHash = route ? '#' + route.replace(/^#?\??/, '') : '';
        if (location.hash !== nextHash) location.hash = nextHash;
        else routeFocus();
      }
    });
    window.addEventListener('hashchange', routeFocus);
    window.addEventListener('focus',scheduleResumeSync);
    document.addEventListener('visibilitychange',()=>{ if(!document.hidden)scheduleResumeSync(); });
    $('workOverview')?.addEventListener('toggle',()=>{ if(workOverviewIsOpen())renderOverviewViews(); });
    $('cyclePanel')?.addEventListener('toggle',()=>{ if(cyclePanelIsOpen())renderCycles(); });
    bindTrash();
    scheduleDayContextCheck();
  }
  document.addEventListener('DOMContentLoaded',async()=>{try{if(new URLSearchParams(location.search).get('embed')==='1')document.body.classList.add('embedded');await initToken();setupDataSync();await load();bind();render();routeFocus();}catch(e){document.body.innerHTML=`<main class="bc-shell"><div class="panel"><h1>起動できませんでした</h1><p>${esc(e.message)}</p></div></main>`;}});
})();

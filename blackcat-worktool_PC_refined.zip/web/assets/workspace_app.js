(() => {
  'use strict';
  window.name = 'blackcat_workspace';
  const $ = id => document.getElementById(id);
  const spec = $('speculumFrame');
  const work = $('continuumFrame');
  const app = $('workspaceApp');
  const handoff = $('handoffScreen');
  const primaryTabs = [$('tabSpeculum'), $('tabContinuum')].filter(Boolean);
  let workLoaded = false;
  let workPreloadScheduled = false;
  let activePrimary = false;
  let lastRouteAt = 0;
  let lastRouteRevision = 0;
  let routePollRunning = false;
  let backupFocusObserver = null;
  let backupFocusTimer = 0;
  let secondaryConflict = false;
  let activationUnlockTimer = 0;
  let activatingApp = '';
  const frameDirtyState = {
    speculum:{dirty:false,saving:false,modalDirty:false,memoDirty:false},
    continuum:{dirty:false,saving:false,modalDirty:false,memoDirty:false}
  };
  const instanceId = String(Date.now()) + ':' + Math.random().toString(36).slice(2);
  const channel = ('BroadcastChannel' in window) ? new BroadcastChannel('blackcat_workspace_singleton') : null;
  const takeoverRequested = new URLSearchParams(location.search).get('takeover') === '1';
  const takeoverNonce = takeoverRequested ? `${instanceId}:${Math.random().toString(36).slice(2)}` : '';



  function desiredHash(){ return (location.hash || '#speculum:today').replace(/^#?/, '#'); }
  function appFromHash(hash){
    const raw=String(hash || '').replace(/^#/,'');
    return raw==='continuum'||raw==='work'||raw.startsWith('continuum?')||raw.startsWith('continuum:')?'continuum':'speculum';
  }
  function hasWorkspaceDirty(){
    return Object.values(frameDirtyState).some(state=>state.dirty||state.saving);
  }
  function updateDirtyIndicators(){
    [['speculum',$('tabSpeculum')],['continuum',$('tabContinuum')]].forEach(([name,tab])=>{
      if(!tab)return;
      const state=frameDirtyState[name];
      tab.classList.toggle('has-unsaved',!!state.dirty);
      tab.classList.toggle('is-saving',!!state.saving);
      tab.title=state.saving?'入力内容を保存しています':state.dirty?'入力中の内容があります':'';
    });
  }
  function requestFrameDeactivate(appName){
    const frame=appName==='continuum'?work:spec;
    try{frame?.contentWindow?.postMessage({blackcatWorkspaceDeactivate:true},location.origin);}catch(_){ }
  }
  function requestFrameActivate(appName){
    const frame=appName==='continuum'?work:spec;
    try{frame?.contentWindow?.postMessage({blackcatWorkspaceActivate:true},location.origin);}catch(_){ }
  }
  function beginFrameActivation(appName){
    activatingApp=appName;
    app?.classList.add('is-activating');
    if(app){app.inert=true;app.setAttribute('aria-busy','true');}
    clearTimeout(activationUnlockTimer);
    // 遅い通信でも旧データのまま編集を解禁しない。時間がかかる場合は案内を
    // 変えるだけにし、子画面の同期完了通知を受けた時だけ解除する。
    activationUnlockTimer=setTimeout(()=>{if(activatingApp===appName)app?.classList.add('activation-slow');},2400);
  }
  function finishFrameActivation(appName){
    if(activatingApp&&appName&&activatingApp!==appName)return;
    activatingApp='';
    clearTimeout(activationUnlockTimer);
    app?.classList.remove('is-activating');
    app?.classList.remove('activation-slow');
    if(app){app.inert=false;app.removeAttribute('aria-busy');}
  }
  function requestFrameConflictLock(){
    [spec,work].forEach(frame=>{try{frame?.contentWindow?.postMessage({blackcatWorkspaceConflictLock:true},location.origin);}catch(_){ }});
  }
  function lockFrameForConflict(frame){
    let doc=null;
    try{doc=frame?.contentDocument;}catch(_){ }
    if(!doc)return;
    doc.querySelectorAll('button').forEach(control=>{control.disabled=true;});
    doc.querySelectorAll('input,textarea').forEach(control=>{control.readOnly=true;});
    doc.querySelectorAll('select').forEach(control=>{control.disabled=true;});
    doc.querySelectorAll('[contenteditable="true"]').forEach(control=>{control.contentEditable='false';});
    doc.querySelectorAll('[draggable="true"]').forEach(control=>{control.draggable=false;});
  }
  function lockConflictFrames(){[spec,work].forEach(lockFrameForConflict);}
  function parseHash(){
    const raw = (location.hash || '#speculum:today').slice(1);
    if (!raw || raw === 'speculum') return {app:'speculum', view:'today'};
    if (raw === 'continuum' || raw === 'work') return {app:'continuum', view:''};
    if (raw.startsWith('continuum?')) return {app:'continuum', view:raw.slice('continuum?'.length)};
    if (raw.startsWith('continuum:')) return {app:'continuum', view:raw.slice('continuum:'.length).replace(/^\?/, '')};
    if (raw.startsWith('speculum:')) return {app:'speculum', view:raw.slice('speculum:'.length) || 'today'};
    return {app:'speculum', view:raw};
  }
  function navigate(hash){
    if (!hash) hash = '#speculum:today';
    if (!String(hash).startsWith('#')) hash = '#' + hash;
    if (location.hash !== hash) location.hash = hash;
    else route();
  }
  function setSpecView(view){
    const viewName = view || 'today';
    try {
      if (spec.contentWindow && spec.contentWindow.location.pathname === '/speculum') {
        const nextHash = '#' + viewName;
        if (spec.contentWindow.location.hash !== nextHash) spec.contentWindow.location.hash = nextHash;
        try { spec.contentWindow.postMessage({blackcatNavigateView:viewName}, '*'); } catch (_) {}
      } else {
        spec.src = '/speculum?embed=1#' + viewName;
      }
    } catch (_) { spec.src = '/speculum?embed=1#' + viewName; }
  }
  function setWorkView(route){
    const routeText = String(route || '').replace(/^#?\??/, '');
    const nextHash = routeText ? '#' + routeText : '';
    try {
      if (work.contentWindow && work.contentWindow.location.pathname === '/continuum') {
        if (work.contentWindow.location.hash !== nextHash) work.contentWindow.location.hash = nextHash;
        try { work.contentWindow.postMessage({blackcatWorkRoute:routeText}, '*'); } catch (_) {}
      } else {
        work.src = '/continuum?embed=1' + nextHash;
        workLoaded = true;
      }
    } catch (_) {
      work.src = '/continuum?embed=1' + nextHash;
      workLoaded = true;
    }
  }
  function show(appName, view){
    const isWork = appName === 'continuum';
    const becomingVisible = isWork ? work.hidden : spec.hidden;
    if(becomingVisible)requestFrameDeactivate(isWork?'speculum':'continuum');
    const currentTab = isWork ? $('tabContinuum') : $('tabSpeculum');
    primaryTabs.forEach(tab => {
      const active = tab === currentTab;
      tab.classList.toggle('active', active);
      tab.setAttribute('aria-selected', active ? 'true' : 'false');
      tab.tabIndex = active ? 0 : -1;
    });
    const currentTitle = $('workspaceCurrentTitle');
    if (currentTitle) currentTitle.textContent = isWork ? '作業管理' : '今日・日付確認';
    // 最上位窓だけが持つ順序にして、Windows側が吹き出しや埋込み画面を
    // ワークスペースと誤認しないようにする。
    document.title = '黒猫ワークツール｜' + (isWork ? '作業管理' : '今日・日付確認');
    spec.hidden = isWork;
    work.hidden = !isWork;
    spec.setAttribute('aria-hidden', isWork ? 'true' : 'false');
    work.setAttribute('aria-hidden', isWork ? 'false' : 'true');
    if (isWork) {
      setWorkView(view || '');
    } else {
      setSpecView(view || 'today');
    }
    if(becomingVisible){
      const nextApp=isWork?'continuum':'speculum';
      beginFrameActivation(nextApp);
      requestFrameActivate(nextApp);
    }
  }
  function route(){ const r = parseHash(); show(r.app, r.view); }
  function activeFrame(){ const r = parseHash(); return r.app === 'continuum' ? work : spec; }
  function clearBackupFocusWatch(){
    backupFocusObserver?.disconnect();
    backupFocusObserver = null;
    clearTimeout(backupFocusTimer);
    backupFocusTimer = 0;
  }
  function watchBackupDialogClose(frame){
    clearBackupFocusWatch();
    let backdrop=null;
    try { backdrop=frame?.contentDocument?.getElementById('modalBackdrop'); } catch (_) {}
    if(!backdrop)return;
    let sawOpen=!backdrop.hidden;
    backupFocusObserver=new MutationObserver(records=>{
      // hidden 属性が外れた記録は、通知時に既に再度 hidden でも開いたことを示す。
      if(records.some(record=>record.oldValue!==null))sawOpen=true;
      if(!backdrop.hidden){sawOpen=true;return;}
      if(!sawOpen)return;
      clearBackupFocusWatch();
      const button=$('backupActiveBtn');
      try{button?.focus({preventScroll:true});}catch(_){button?.focus();}
    });
    backupFocusObserver.observe(backdrop,{attributes:true,attributeFilter:['hidden'],attributeOldValue:true});
    backupFocusTimer=setTimeout(clearBackupFocusWatch,120000);
  }
  function openBackupOnActive(){
    const f = activeFrame();
    watchBackupDialogClose(f);
    try { f.contentWindow?.postMessage({blackcatOpenBackup:true}, '*'); }
    catch (_) {}
  }

  spec.addEventListener('load', () => {
    // iframe の初期化が遅れた場合も、最後に要求された内側画面へ戻す。
    const r = parseHash();
    if (r.app === 'speculum') setTimeout(() => setSpecView(r.view || 'today'), 40);
    if (r.app === 'speculum') setTimeout(() => requestFrameActivate('speculum'), 45);
  });
  work.addEventListener('load',()=>{ if(parseHash().app==='continuum')setTimeout(()=>requestFrameActivate('continuum'),45); });

  function preloadWorkFrame(){
    if (!activePrimary || workLoaded || !work || work.src !== 'about:blank') return;
    work.src = '/continuum?embed=1';
    workLoaded = true;
  }

  function scheduleWorkPreload(){
    if (workPreloadScheduled || workLoaded) return;
    workPreloadScheduled = true;
    const run = () => { workPreloadScheduled = false; preloadWorkFrame(); };
    if ('requestIdleCallback' in window) window.requestIdleCallback(run, {timeout: 2600});
    else setTimeout(run, 1400);
  }

  async function pollServerRoute(){
    if (!activePrimary || document.hidden || routePollRunning) return;
    routePollRunning = true;
    try {
      const r = await fetch('/api/ui/route?t=' + Date.now(), {cache:'no-store'}).then(x => x.json());
      const revision = Number(r?.revision || 0);
      const at = Number(r?.at || 0);
      const changed = revision > 0 ? revision !== lastRouteRevision : at !== lastRouteAt;
      if (r && r.ok && changed) {
        lastRouteRevision = revision;
        lastRouteAt = at;
        navigate(r.hash || '#speculum:today');
        try { window.focus(); } catch (_) {}
      }
    } catch (_) {}
    finally { routePollRunning = false; }
  }

  function activateAsPrimary(){
    activePrimary = true;
    if (app) app.hidden = false;
    if (handoff) handoff.hidden = true;
    route();
    pollServerRoute();
    scheduleWorkPreload();
  }
  function switchToExisting(){
    activePrimary = false;
    requestFrameConflictLock();
    if (app) app.hidden = true;
    if (handoff) handoff.hidden = false;
    document.title = '黒猫ワークツール｜案内';
    setTimeout(() => { try { window.close(); } catch (_) {} }, 650);
  }
  function showLateDenialConflict(){
    if(secondaryConflict)return;
    secondaryConflict=true;
    activePrimary=false;
    requestFrameConflictLock();
    if(app)app.hidden=true;
    if(!handoff)return;
    handoff.hidden=false;
    handoff.classList.add('workspace-conflict');
    handoff.innerHTML='<img src="/web/assets/blackcat_floating_magic_icon.png" alt="黒猫"><span class="handoff-alert">入力内容の確認が必要です</span><h1>別の画面にも未保存の入力があります</h1><p>この画面の入力と、先に開いていた画面の入力は自動では統合しません。ここでは保存操作を止めています。必要な内容を控えてからこの画面を閉じ、先に開いていた画面で続けてください。</p><div class="handoff-actions"><button type="button" data-review-conflict>この画面の入力を確認</button><button type="button" class="primary" data-close-conflict>この画面を閉じる</button></div>';
    handoff.querySelector('[data-review-conflict]')?.addEventListener('click',()=>{
      handoff.hidden=true;
      if(app)app.hidden=false;
      lockConflictFrames();
      let banner=document.getElementById('workspaceConflictBanner');
      if(!banner){
        banner=document.createElement('div');banner.id='workspaceConflictBanner';banner.className='workspace-conflict-banner';
        banner.innerHTML='<b>確認専用</b><span>別画面にも未保存入力があります。この画面では保存できません。内容を控えてから閉じてください。</span><button type="button">閉じる</button>';
        banner.querySelector('button').addEventListener('click',()=>{try{window.close();}catch(_){ }});
        document.body.appendChild(banner);
      }
    });
    handoff.querySelector('[data-close-conflict]')?.addEventListener('click',()=>{try{window.close();}catch(_){ }});
    document.title='黒猫ワークツール｜入力内容の確認';
  }
  function yieldToIncoming(msg){
    if(hasWorkspaceDirty()){
      try{window.focus();}catch(_){ }
      channel?.postMessage({type:'blackcat-workspace-takeover-denied',id:instanceId,to:msg.id,nonce:msg.nonce||'',reason:'unsaved'});
      return;
    }
    activePrimary = false;
    if (app) app.hidden = true;
    if (handoff) handoff.hidden = false;
    document.title = '黒猫ワークツール｜案内';
    channel?.postMessage({
      type:'blackcat-workspace-takeover',
      id:instanceId,
      to:msg.id,
      nonce:msg.nonce || '',
      hash:msg.hash || '#speculum:today'
    });
  }

  if (channel) {
    channel.onmessage = event => {
      const msg = event.data || {};
      if (msg.type === 'blackcat-workspace-open' && msg.id !== instanceId && activePrimary) {
        // 通常のsingleton要求だけを旧来のACK契約で扱う。明示takeoverは下の
        // 専用メッセージを使い、旧版Workspaceが通常ACKして前面タブを退かせる
        // 更新跨ぎの競合を起こさない。
        navigate(msg.hash || '#speculum:today');
        try { window.focus(); } catch (_) {}
        channel.postMessage({type:'blackcat-workspace-ack', id:instanceId, to:msg.id});
      }
      if (msg.type === 'blackcat-workspace-takeover-request' && msg.id !== instanceId && activePrimary) {
        // Edgeが新しいURLタブを前面へ出した時、背景の旧タブへ戻して閉じると
        // 利用者には何も起きない。現行同士ではnonce付き専用契約で安全に引き継ぐ。
        yieldToIncoming(msg);
      }
      if (msg.type === 'blackcat-workspace-takeover' && msg.to === instanceId && msg.nonce === takeoverNonce && !activePrimary) {
        const requested = msg.hash || desiredHash();
        if (location.hash !== requested) location.hash = requested;
        activateAsPrimary();
      }
      if (msg.type === 'blackcat-workspace-takeover-denied' && msg.to === instanceId && msg.nonce === takeoverNonce && !activePrimary) {
        if(hasWorkspaceDirty())showLateDenialConflict();else switchToExisting();
      }
      if (msg.type === 'blackcat-workspace-takeover-denied' && msg.to === instanceId && msg.nonce === takeoverNonce && activePrimary) {
        if(hasWorkspaceDirty())showLateDenialConflict();else switchToExisting();
      }
      if (msg.type === 'blackcat-workspace-ack' && msg.to === instanceId && !takeoverRequested) {
        if(hasWorkspaceDirty())showLateDenialConflict();else switchToExisting();
      }
    };
    if (takeoverRequested) {
      channel.postMessage({type:'blackcat-workspace-takeover-request', id:instanceId, nonce:takeoverNonce, hash:desiredHash()});
    } else {
      channel.postMessage({type:'blackcat-workspace-open', id:instanceId, hash:desiredHash()});
    }
    setTimeout(() => { if (!activePrimary && !(handoff && !handoff.hidden)) activateAsPrimary(); }, 220);
  } else {
    activateAsPrimary();
  }

  $('tabSpeculum').onclick = () => { navigate('#speculum:today'); };
  $('tabContinuum').onclick = () => { navigate('#continuum'); };
  primaryTabs.forEach((tab, index) => tab.addEventListener('keydown', event => {
    if (!['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(event.key)) return;
    event.preventDefault();
    let next = index;
    if (event.key === 'ArrowLeft') next = (index - 1 + primaryTabs.length) % primaryTabs.length;
    if (event.key === 'ArrowRight') next = (index + 1) % primaryTabs.length;
    if (event.key === 'Home') next = 0;
    if (event.key === 'End') next = primaryTabs.length - 1;
    primaryTabs[next].focus();
    primaryTabs[next].click();
  }));
  const backupBtn = $('backupActiveBtn'); if (backupBtn) backupBtn.onclick = openBackupOnActive;
  window.addEventListener('hashchange', () => { if (activePrimary) route(); });
  setInterval(pollServerRoute, 4000);
  // Windows側から既存窓を前面化した瞬間にサーバーの遷移指示を読む。
  // BroadcastChannelが使えない環境でも4秒の定期確認を待たせない。
  window.addEventListener('focus', pollServerRoute);
  document.addEventListener('visibilitychange', () => { if (!document.hidden) pollServerRoute(); });
  window.addEventListener('beforeunload',event=>{
    if(!hasWorkspaceDirty())return;
    requestFrameDeactivate('speculum');
    requestFrameDeactivate('continuum');
    event.preventDefault();
    event.returnValue='';
  });
  window.addEventListener('message', e => {
    if (e.origin && e.origin !== location.origin) return;
    const data = e.data || {};
    if (data && data.blackcatNavigate) navigate('#' + data.blackcatNavigate);
    const dirty=data.blackcatDirtyState;
    if(dirty&&['speculum','continuum'].includes(dirty.app)){
      frameDirtyState[dirty.app]={dirty:!!dirty.dirty,saving:!!dirty.saving,modalDirty:!!dirty.modalDirty,memoDirty:!!dirty.memoDirty};
      updateDirtyIndicators();
    }
    if(data.blackcatWorkspaceActivated&&['speculum','continuum'].includes(data.blackcatWorkspaceActivated.app))finishFrameActivation(data.blackcatWorkspaceActivated.app);
  });
  [spec,work].forEach(frame=>frame?.addEventListener('load',()=>{if(secondaryConflict)lockFrameForConflict(frame);}));
})();

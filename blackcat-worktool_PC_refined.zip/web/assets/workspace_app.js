(() => {
  'use strict';
  window.name = 'blackcat_workspace';
  const $ = id => document.getElementById(id);
  const spec = $('speculumFrame');
  const work = $('continuumFrame');
  const app = $('workspaceApp');
  const handoff = $('handoffScreen');
  const primaryTabs = [$('tabSpeculum'), $('tabContinuum')].filter(Boolean);
  let workLoaded = false;
  let workPreloadScheduled = false;
  let activePrimary = false;
  let lastRouteAt = 0;
  let routePollRunning = false;
  let backupFocusObserver = null;
  let backupFocusTimer = 0;
  const instanceId = String(Date.now()) + ':' + Math.random().toString(36).slice(2);
  const channel = ('BroadcastChannel' in window) ? new BroadcastChannel('blackcat_workspace_singleton') : null;



  function desiredHash(){ return (location.hash || '#speculum:today').replace(/^#?/, '#'); }
  function parseHash(){
    const raw = (location.hash || '#speculum:today').slice(1);
    if (!raw || raw === 'speculum') return {app:'speculum', view:'today'};
    if (raw === 'continuum' || raw === 'work') return {app:'continuum', view:''};
    if (raw.startsWith('continuum?')) return {app:'continuum', view:raw.slice('continuum?'.length)};
    if (raw.startsWith('continuum:')) return {app:'continuum', view:raw.slice('continuum:'.length).replace(/^\?/, '')};
    if (raw.startsWith('speculum:')) return {app:'speculum', view:raw.slice('speculum:'.length) || 'today'};
    return {app:'speculum', view:raw};
  }
  function navigate(hash){
    if (!hash) hash = '#speculum:today';
    if (!String(hash).startsWith('#')) hash = '#' + hash;
    if (location.hash !== hash) location.hash = hash;
    else route();
  }
  function setSpecView(view){
    const viewName = view || 'today';
    try {
      if (spec.contentWindow && spec.contentWindow.location.pathname === '/speculum') {
        const nextHash = '#' + viewName;
        if (spec.contentWindow.location.hash !== nextHash) spec.contentWindow.location.hash = nextHash;
        try { spec.contentWindow.postMessage({blackcatNavigateView:viewName}, '*'); } catch (_) {}
      } else {
        spec.src = '/speculum?embed=1#' + viewName;
      }
    } catch (_) { spec.src = '/speculum?embed=1#' + viewName; }
  }
  function setWorkView(route){
    const routeText = String(route || '').replace(/^#?\??/, '');
    const nextHash = routeText ? '#' + routeText : '';
    try {
      if (work.contentWindow && work.contentWindow.location.pathname === '/continuum') {
        if (work.contentWindow.location.hash !== nextHash) work.contentWindow.location.hash = nextHash;
        try { work.contentWindow.postMessage({blackcatWorkRoute:routeText}, '*'); } catch (_) {}
      } else {
        work.src = '/continuum?embed=1' + nextHash;
        workLoaded = true;
      }
    } catch (_) {
      work.src = '/continuum?embed=1' + nextHash;
      workLoaded = true;
    }
  }
  function show(appName, view){
    const isWork = appName === 'continuum';
    const currentTab = isWork ? $('tabContinuum') : $('tabSpeculum');
    primaryTabs.forEach(tab => {
      const active = tab === currentTab;
      tab.classList.toggle('active', active);
      tab.setAttribute('aria-selected', active ? 'true' : 'false');
      tab.tabIndex = active ? 0 : -1;
    });
    const currentTitle = $('workspaceCurrentTitle');
    if (currentTitle) currentTitle.textContent = isWork ? '作業管理' : '今日・日付確認';
    document.title = (isWork ? '作業管理' : '今日・日付確認') + '｜黒猫ワークツール';
    spec.hidden = isWork;
    work.hidden = !isWork;
    spec.setAttribute('aria-hidden', isWork ? 'true' : 'false');
    work.setAttribute('aria-hidden', isWork ? 'false' : 'true');
    if (isWork) {
      setWorkView(view || '');
    } else {
      setSpecView(view || 'today');
    }
  }
  function route(){ const r = parseHash(); show(r.app, r.view); }
  function activeFrame(){ const r = parseHash(); return r.app === 'continuum' ? work : spec; }
  function clearBackupFocusWatch(){
    backupFocusObserver?.disconnect();
    backupFocusObserver = null;
    clearTimeout(backupFocusTimer);
    backupFocusTimer = 0;
  }
  function watchBackupDialogClose(frame){
    clearBackupFocusWatch();
    let backdrop=null;
    try { backdrop=frame?.contentDocument?.getElementById('modalBackdrop'); } catch (_) {}
    if(!backdrop)return;
    let sawOpen=!backdrop.hidden;
    backupFocusObserver=new MutationObserver(records=>{
      // hidden 属性が外れた記録は、通知時に既に再度 hidden でも開いたことを示す。
      if(records.some(record=>record.oldValue!==null))sawOpen=true;
      if(!backdrop.hidden){sawOpen=true;return;}
      if(!sawOpen)return;
      clearBackupFocusWatch();
      const button=$('backupActiveBtn');
      try{button?.focus({preventScroll:true});}catch(_){button?.focus();}
    });
    backupFocusObserver.observe(backdrop,{attributes:true,attributeFilter:['hidden'],attributeOldValue:true});
    backupFocusTimer=setTimeout(clearBackupFocusWatch,120000);
  }
  function openBackupOnActive(){
    const f = activeFrame();
    watchBackupDialogClose(f);
    try { f.contentWindow?.postMessage({blackcatOpenBackup:true}, '*'); }
    catch (_) {}
  }

  spec.addEventListener('load', () => {
    // iframe の初期化が遅れた場合も、最後に要求された内側画面へ戻す。
    const r = parseHash();
    if (r.app === 'speculum') setTimeout(() => setSpecView(r.view || 'today'), 40);
  });

  function preloadWorkFrame(){
    if (!activePrimary || workLoaded || !work || work.src !== 'about:blank') return;
    work.src = '/continuum?embed=1';
    workLoaded = true;
  }

  function scheduleWorkPreload(){
    if (workPreloadScheduled || workLoaded) return;
    workPreloadScheduled = true;
    const run = () => { workPreloadScheduled = false; preloadWorkFrame(); };
    if ('requestIdleCallback' in window) window.requestIdleCallback(run, {timeout: 2600});
    else setTimeout(run, 1400);
  }

  async function pollServerRoute(){
    if (!activePrimary || document.hidden || routePollRunning) return;
    routePollRunning = true;
    try {
      const r = await fetch('/api/ui/route?t=' + Date.now(), {cache:'no-store'}).then(x => x.json());
      if (r && r.ok && Number(r.at || 0) > lastRouteAt) {
        lastRouteAt = Number(r.at || 0);
        navigate(r.hash || '#speculum:today');
        try { window.focus(); } catch (_) {}
      }
    } catch (_) {}
    finally { routePollRunning = false; }
  }

  function activateAsPrimary(){
    activePrimary = true;
    if (app) app.hidden = false;
    if (handoff) handoff.hidden = true;
    route();
    pollServerRoute();
    scheduleWorkPreload();
  }
  function switchToExisting(){
    if (app) app.hidden = true;
    if (handoff) handoff.hidden = false;
    setTimeout(() => { try { window.close(); } catch (_) {} }, 650);
  }

  if (channel) {
    channel.onmessage = event => {
      const msg = event.data || {};
      if (msg.type === 'blackcat-workspace-open' && msg.id !== instanceId && activePrimary) {
        navigate(msg.hash || '#speculum:today');
        try { window.focus(); } catch (_) {}
        channel.postMessage({type:'blackcat-workspace-ack', id:instanceId, to:msg.id});
      }
      if (msg.type === 'blackcat-workspace-ack' && msg.to === instanceId && !activePrimary) {
        switchToExisting();
      }
    };
    channel.postMessage({type:'blackcat-workspace-open', id:instanceId, hash:desiredHash()});
    setTimeout(() => { if (!activePrimary && !(handoff && !handoff.hidden)) activateAsPrimary(); }, 220);
  } else {
    activateAsPrimary();
  }

  $('tabSpeculum').onclick = () => { navigate('#speculum:today'); };
  $('tabContinuum').onclick = () => { navigate('#continuum'); };
  primaryTabs.forEach((tab, index) => tab.addEventListener('keydown', event => {
    if (!['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(event.key)) return;
    event.preventDefault();
    let next = index;
    if (event.key === 'ArrowLeft') next = (index - 1 + primaryTabs.length) % primaryTabs.length;
    if (event.key === 'ArrowRight') next = (index + 1) % primaryTabs.length;
    if (event.key === 'Home') next = 0;
    if (event.key === 'End') next = primaryTabs.length - 1;
    primaryTabs[next].focus();
    primaryTabs[next].click();
  }));
  const backupBtn = $('backupActiveBtn'); if (backupBtn) backupBtn.onclick = openBackupOnActive;
  window.addEventListener('hashchange', () => { if (activePrimary) route(); });
  setInterval(pollServerRoute, 4000);
  document.addEventListener('visibilitychange', () => { if (!document.hidden) pollServerRoute(); });
  window.addEventListener('message', e => {
    if (e.origin && e.origin !== location.origin) return;
    const data = e.data || {};
    if (data && data.blackcatNavigate) navigate('#' + data.blackcatNavigate);
  });
})();

(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  const esc = v => String(v ?? '').replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
  const clean = v => String(v ?? '').trim();
  const arr = v => Array.isArray(v) ? v : [];
  let TOKEN = '';
  let LAST = [];
  let SELECTED = 0;
  let RESOLVED_QUERY = null;
  let RESOLVE_SEQ = 0;
  let RESOLVE_TIMER = 0;
  let RESOLVE_ABORT = null;
  let RESOLVE_REQUEST_QUERY = '';
  let IS_COMPOSING = false;
  let SHOW_ALL_CANDIDATES = false;
  let LAST_IS_INSTANT = false;
  let HIDE_TIMER = 0;
  let EXECUTING = false;
  let RESOLVING = false;
  let DATA_CHANNEL = null;
  let WORKSPACE_CHANNEL = null;
  const INSTANCE_ID = `${Date.now()}-${Math.random().toString(16).slice(2)}`;
  const RESOLVE_CACHE = new Map();
  const RESOLVE_CACHE_LIMIT = 30;
  let ACTIVE_DAY = localDay();
  let DAY_CONTEXT_TIMER = 0;
  let SUMMARY_LOAD_SEQ = 0;

  function setupDataSync(){
    try {
      DATA_CHANNEL = new BroadcastChannel('blackcat-data-changed');
      DATA_CHANNEL.onmessage = () => { clearResolveCache(); if(!document.hidden)loadSummary().catch(()=>{}); };
    } catch (_) {}
    try { WORKSPACE_CHANNEL = new BroadcastChannel('blackcat_workspace_singleton'); } catch (_) {}
  }
  function notifyDataChanged(app){
    try { DATA_CHANNEL?.postMessage({type:'data-changed', app, source:INSTANCE_ID, at:Date.now()}); } catch (_) {}
  }

  function applyAnchor(){
    const a = new URLSearchParams(location.search).get('anchor');
    document.body.classList.toggle('anchor-left', a === 'left');
    document.body.classList.toggle('anchor-right', a === 'right');
  }
  async function initToken(){ const j = await fetch('/api/security/token', {cache:'no-store'}).then(r=>r.json()); TOKEN = j.token || ''; }
  async function api(path, options={}){
    const headers = {'Content-Type':'application/json'};
    if (TOKEN) headers['X-Blackcat-Token'] = TOKEN;
    const r = await fetch(path, {...options, headers:{...headers, ...(options.headers||{})}});
    const j = await r.json().catch(()=>({}));
    if (!r.ok || j.ok === false) throw new Error(j.error || '通信に失敗しました');
    return j;
  }
  function cachedResolve(q){
    const hit = RESOLVE_CACHE.get(q);
    const age = hit ? Date.now() - hit.t : -1;
    if (!hit || age < 0 || age > 20000) { RESOLVE_CACHE.delete(q); return null; }
    return hit.items.map(x => ({...x}));
  }
  function rememberResolve(q, items){
    RESOLVE_CACHE.set(q, {t: Date.now(), items: items.map(x => ({...x}))});
    while (RESOLVE_CACHE.size > RESOLVE_CACHE_LIMIT) RESOLVE_CACHE.delete(RESOLVE_CACHE.keys().next().value);
  }
  function clearResolveCache(){ RESOLVE_CACHE.clear(); }
  function localDay(){ const d=new Date(); return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`; }
  function dayContextCheckDelay(){ const now=new Date(); const next=new Date(now.getFullYear(),now.getMonth(),now.getDate()+1,0,0,0,250); const wait=next.getTime()-now.getTime(); return Math.max(1000,Math.min(60000,Number.isFinite(wait)?wait:60000)); }
  function refreshDayContextIfNeeded(){ const nextDay=localDay(); if(ACTIVE_DAY===nextDay)return false; ACTIVE_DAY=nextDay; clearResolveCache(); loadSummary().catch(()=>{}); return true; }
  function scheduleDayContextCheck(){ clearTimeout(DAY_CONTEXT_TIMER); DAY_CONTEXT_TIMER=setTimeout(()=>{refreshDayContextIfNeeded();scheduleDayContextCheck();},dayContextCheckDelay()); }
  function toast(msg){
    const t = $('toast');
    if (!t) return;
    t.textContent = msg;
    t.classList.add('show');
    clearTimeout(toast.t);
    toast.t = setTimeout(() => t.classList.remove('show'), 2300);
  }
  function setResultsStatus(message){
    const status = $('resultsStatus');
    if (status) status.textContent = message;
  }
  function updateCommandState(){
    const input = $('commandText');
    const button = $('commandBtn');
    const hasText = Boolean(clean(input?.value));
    if (button) {
      button.disabled = EXECUTING || RESOLVING || !hasText;
      button.textContent = RESOLVING ? '確認中…' : '候補を見る';
    }
  }
  function setResolving(on){
    RESOLVING = Boolean(on);
    $('results')?.setAttribute('aria-busy', RESOLVING ? 'true' : 'false');
    document.body.classList.toggle('is-resolving', RESOLVING);
    updateCommandState();
  }
  function setExecutionBusy(on){
    EXECUTING = Boolean(on);
    document.body.classList.toggle('is-executing', EXECUTING);
    const input = $('commandText');
    if (input) input.disabled = EXECUTING;
    document.querySelectorAll('.result button, .command-samples button, .nav-row button, .pulse').forEach(button => {
      button.disabled = EXECUTING;
    });
    updateCommandState();
  }
  function routeAfter(prefix, raw){
    if (raw.includes('#')) return raw.split('#').slice(1).join('#');
    if (raw.startsWith(prefix + ':')) return raw.slice(prefix.length + 1);
    if (raw.startsWith(prefix + '?')) return '?' + raw.slice(prefix.length + 1);
    if (raw.includes('?')) return '?' + raw.split('?').slice(1).join('?');
    return '';
  }
  function workspaceHash(target){
    const raw = String(target || '').replace(/^\//, '');
    if (raw.startsWith('continuum') || raw === 'work') {
      const detail = clean(routeAfter('continuum', raw)).replace(/^#/, '').replace(/^\?/, '');
      return detail ? 'continuum?' + detail : 'continuum';
    }
    if (raw.startsWith('speculum')) return 'speculum:' + (routeAfter('speculum', raw).replace(/^#/, '') || 'today');
    if (raw.startsWith('main')) return 'speculum:' + (routeAfter('main', raw).replace(/^#/, '') || 'today');
    if (raw.includes('#')) return 'speculum:' + (raw.split('#').slice(1).join('#') || 'today');
    if (raw) return raw.includes(':') ? raw : `speculum:${raw}`;
    return 'speculum:today';
  }
  function hashToTarget(h){
    if (h.startsWith('continuum')) {
      const detail = h.includes('?') ? h.split('?').slice(1).join('?') : '';
      return '/continuum' + (detail ? '#' + detail : '');
    }
    return '/speculum#' + (h.split(':').slice(1).join(':') || 'today');
  }
  async function openWorkspace(target){
    const h = workspaceHash(target);
    const t = hashToTarget(h);
    try { WORKSPACE_CHANNEL?.postMessage({type:'blackcat-workspace-open', id:`${INSTANCE_ID}-floating`, hash:h}); } catch (_) {}
    try {
      await api('/api/ui/open-app', {method:'POST', body:JSON.stringify({target:t})});
      finishAndHide('開きました', 220);
    } catch (_e) {
      window.open('/workspace#' + h, 'blackcat_workspace');
      finishAndHide('開きました', 220);
    }
  }
  function pulse(label, count, target){ return `<button class="pulse" data-target="${esc(target)}"><b>${esc(count)}</b><span>${esc(label)}</span></button>`; }
  async function loadSummary(){
    const box = $('summaryStrip'); if (!box) return;
    const seq = ++SUMMARY_LOAD_SEQ;
    try {
      const j = await api('/api/speculum/summary');
      if(seq !== SUMMARY_LOAD_SEQ)return;
      const due = arr(j.dueSoon);
      const cycles = arr(j.cycleSoon);
      const alerts = arr(j.caseAlerts);
      const danger = due.filter(x => Number(x.calendarDays ?? x.days) < 0).length + cycles.filter(x => Number(x.calendarDays ?? x.days) < 0).length + alerts.filter(x => Number(x.calendarDays ?? x.days) < 0).length;
      const todayCount = arr(j.eventsToday).length + due.filter(x => Number(x.days) === 0).length + cycles.filter(x => Number(x.days) === 0).length;
      const near = due.filter(x => Number(x.days) > 0 && Number(x.days) <= 7).length + cycles.filter(x => Number(x.days) > 0 && Number(x.days) <= 7).length + alerts.filter(x => Number(x.days) >= 0 && Number(x.days) <= 7).length;
      box.innerHTML = pulse('今日', todayCount, 'speculum:today') + pulse('近い期限', near, 'speculum:today') + pulse('期限超過', danger, 'speculum:today');
    } catch (_e) {
      if(seq !== SUMMARY_LOAD_SEQ)return;
      box.innerHTML = pulse('今日', '-', 'speculum:today') + pulse('予定', '-', 'speculum:schedule') + pulse('作業', '-', 'continuum');
    }
    box.querySelectorAll('[data-target]').forEach(b => b.onclick = () => openWorkspace(b.dataset.target || 'speculum:today'));
  }
  function setSelected(index){
    const input = $('commandText');
    if (!LAST.length) {
      SELECTED = 0;
      input?.removeAttribute('aria-activedescendant');
      input?.setAttribute('aria-expanded', 'false');
      return;
    }
    input?.setAttribute('aria-expanded', 'true');
    SELECTED = Math.max(0, Math.min(index, LAST.length - 1));
    document.querySelectorAll('.result[data-index]').forEach((el, i) => {
      const on = i === SELECTED;
      el.classList.toggle('selected', on);
      el.setAttribute('aria-selected', on ? 'true' : 'false');
      if (on) {
        input?.setAttribute('aria-activedescendant', el.id);
        el.scrollIntoView({block:'nearest'});
      }
    });
  }
  function resultGroupClass(item){
    const g = candidateGroup(item);
    if (g === '実行候補') return 'result-execute';
    if (g === '登録候補') return 'result-register';
    if (g === '検索結果') return 'result-search';
    if (g === '画面') return 'result-open';
    if (g === 'ローカルツール') return 'result-tool';
    return 'result-other';
  }
  function resultNode(item, index){
    const n = document.createElement('div');
    n.className = 'result ' + resultGroupClass(item);
    n.dataset.index = String(index);
    n.id = 'commandResult-' + index;
    n.tabIndex = -1;
    n.setAttribute('role', 'option');
    const rawHint = clean(item.hint);
    const hint = rawHint === '即時候補'
      ? 'すぐに確認できます'
      : (rawHint.startsWith('即時候補。詳細検索') ? '詳しい候補も確認しています' : rawHint);
    const meta = [...new Set([item.kind, hint].filter(Boolean))].join('・');
    const actionLabel=item.actionLabel || '開く';
    n.innerHTML = '<div><div class="title">' + esc(item.title) + '</div><div class="meta">' + esc(meta) + '</div></div><button aria-label="' + esc(actionLabel + ': ' + item.title) + '">' + esc(actionLabel) + '</button>';
    n.addEventListener('mouseenter', () => setSelected(index));
    n.addEventListener('click', () => setSelected(index));
    n.addEventListener('dblclick', () => execute(item));
    n.querySelector('button').onclick = e => { e.stopPropagation(); setSelected(index); execute(item); };
    return n;
  }
  function showEnterHint(){
    const box = $('results'); if (!box) return;
    const input=$('commandText'); input?.removeAttribute('aria-activedescendant'); input?.setAttribute('aria-expanded','false');
    box.innerHTML = '<div class="result hint-result"><div><div class="title">入力すると候補を表示します</div><div class="meta">予定・作業・人物・事案を一つの欄から探せます。</div></div></div>';
    setResultsStatus('入力すると候補を表示します');
  }
  function resetCommandUi(){
    const input = $('commandText');
    if (input) input.value = '';
    LAST = [];
    SELECTED = 0;
    RESOLVED_QUERY = null;
    SHOW_ALL_CANDIDATES = false;
    LAST_IS_INSTANT = false;
    showEnterHint();
    updateCommandState();
  }
  function hideBubbleSoon(delay = 520){
    clearTimeout(HIDE_TIMER);
    document.body.classList.add('action-done');
    HIDE_TIMER = setTimeout(async () => {
      try { await api('/api/floating/hide', {method:'POST', body:'{}'}); } catch (_) {}
      try { window.close(); } catch (_) {}
    }, Math.max(180, Number(delay) || 520));
  }
  function finishAndHide(message, delay = 520){
    resetCommandUi();
    if (message) toast(message);
    hideBubbleSoon(delay);
  }
  function validCalendarDate(year, month, day){
    const y = Number(year);
    const m = Number(month);
    const d = Number(day);
    if (!Number.isInteger(y) || !Number.isInteger(m) || !Number.isInteger(d) || y < 1 || m < 1 || m > 12 || d < 1) return false;
    return d <= new Date(Date.UTC(y, m, 0)).getUTCDate();
  }
  function hasInvalidTemporalExpression(value){
    const text = clean(value);
    if (!text) return false;
    let dateText = text;
    let invalid = false;
    const currentYear = new Date().getFullYear();
    const consumeDates = (pattern, yearIndex, monthIndex, dayIndex) => {
      dateText = dateText.replace(pattern, (...args) => {
        if (!validCalendarDate(args[yearIndex], args[monthIndex], args[dayIndex])) invalid = true;
        return ' ';
      });
    };
    consumeDates(/(\d{4})年\s*(\d{1,2})月\s*(\d{1,2})日/g, 1, 2, 3);
    consumeDates(/(\d{4})[/-](\d{1,2})[/-](\d{1,2})/g, 1, 2, 3);
    dateText = dateText.replace(/(\d{1,2})月\s*(\d{1,2})日/g, (_, month, day) => {
      if (!validCalendarDate(currentYear, month, day)) invalid = true;
      return ' ';
    });
    dateText.replace(/(?:^|[^\d])(\d{1,2})[/-](\d{1,2})(?![/-]\d)/g, (_, month, day) => {
      if (!validCalendarDate(currentYear, month, day)) invalid = true;
      return ' ';
    });

    const validClock = (marker, hour, minute) => {
      const h = Number(hour);
      const m = Number(minute || 0);
      if (!Number.isInteger(h) || !Number.isInteger(m) || m < 0 || m > 59) return false;
      return marker ? h >= 1 && h <= 12 : h >= 0 && h <= 23;
    };
    text.replace(/(?:^|[^\d])(午前|午後|am|pm)?\s*(\d{1,2}):(\d{2})(?!\d)/gi, (_, marker, hour, minute) => {
      if (!validClock(marker, hour, minute)) invalid = true;
      return ' ';
    });
    text.replace(/(?:^|[^\d])(午前|午後|am|pm)?\s*(\d{1,2})時(?!間)(?:(半)|(\d{1,2})分?)?/gi, (_, marker, hour, half, minute) => {
      if (!validClock(marker, hour, half ? 30 : (minute || 0))) invalid = true;
      return ' ';
    });
    return invalid;
  }
  function safeCandidatesForQuery(q, items){
    const candidates = arr(items);
    if (!hasInvalidTemporalExpression(q)) return candidates;
    return candidates.filter(item => candidateGroup(item) !== '登録候補');
  }
  function quickLocalCandidates(q){
    const text = clean(q);
    if (!text) return [];
    const low = text.toLowerCase();
    const out = [];
    const has = words => words.some(w => text.includes(w) || low.includes(String(w).toLowerCase()));
    const addNav = (id, title, href, words) => {
      if (words.some(w => low.includes(String(w).toLowerCase()))) {
        out.push({id, title, kind:'画面', href, actionLabel:'開く', canExecute:true, action:'open', hint:'即時候補'});
      }
    };
    const addReg = (id, title, action, label) => {
      out.push({id:'instant:' + id + ':' + text, title, kind:'登録候補', hint:'即時候補。詳細検索は続けています', action, actionLabel:label, canExecute:true, payload:{text}});
    };

    addNav('instant:today', '今日の画面を開く', '/speculum#today', ['今日','today','ホーム','司令塔','ダッシュボード','朝の整理','今日を組む','終業','締め']);
    addNav('instant:schedule', '日付確認カレンダーを開く', '/speculum#schedule', ['日付確認','予定表','カレンダー','日付','予定','打合せ','打ち合わせ','会議','面談','schedule']);
    addNav('instant:work', '作業管理を開く', '/continuum', ['作業管理','タスク管理','作業','タスク','期限','締切','期日','事務','完了','待ち','todo','work']);
    addNav('instant:cases', '事案台帳を開く', '/speculum#cases', ['事案台帳','調査台帳','事案','調査','案件','対象者']);
    addNav('instant:people', '人物管理を開く', '/speculum#people', ['人物管理','職員管理','同僚管理','連絡先','人物','職員','担当']);
    addNav('instant:career', '経歴管理を開く', '/speculum#career', ['経歴','異動','普通科','専科']);
    if (has(['ローカル','ツール','tool','tools','起動'])) {
      out.push({id:'instant:tools', title:'ローカルツールフォルダを開く', kind:'ローカルツール', action:'open_tools_folder', actionLabel:'開く', canExecute:true, hint:'即時候補'});
    }

    const explicitAdd = has(['追加','登録','入れて','作って','add','create']);
    const periodic = has(['毎日','毎週','毎月','毎年','周期','サイクル']);
    const invalidTemporal = hasInvalidTemporalExpression(text);
    const timeish = /\d{1,2}:\d{2}|\d{1,2}時(?!間)/.test(text) || has(['朝一','正午','昼一','夕方']);
    const dateish = /\d{4}[-/]\d{1,2}[-/]\d{1,2}|\d{4}年\d{1,2}月\d{1,2}日|\d{1,2}[-/]\d{1,2}|\d{1,2}月\d{1,2}日|\d+\s*(?:日|週間?)後|(?:(?:今週|来週|次の|今度の)(?:の)?\s*)?[月火水木金土日]曜(?:日)?/.test(text) || has(['今月末','来月末','月末','月初','月始','今日','本日','明日','あした','明後日','あさって','今週','来週']);
    const ritualOnly = has(['今日を組む','朝の整理','今日の整理','今日を閉じる','終業','締め']);
    if (!invalidTemporal && !ritualOnly && (explicitAdd || periodic || timeish || dateish)) {
      if (periodic) addReg('cycle', '周期作業として追加: ' + text, 'quick_cycle', '周期追加');
      else {
        if (has(['出来事','できごと'])) addReg('happening', '出来事として追加: ' + text, 'quick_happening', '出来事追加');
        else if (timeish || has(['予定','打合せ','打ち合わせ','会議','面談'])) addReg('event', '予定として追加: ' + text, 'quick_event', '予定追加');
        if (has(['事務'])) addReg('jimu', '事務として追加: ' + text, 'quick_jimu', '事務追加');
        if (has(['期限','締切','期日','提出日','まで'])) addReg('deadline', '期限として追加: ' + text, 'quick_deadline', '期限追加');
        if (has(['作業','タスク']) || (!timeish && !out.some(x => candidateGroup(x) === '登録候補'))) addReg('task', '作業として追加: ' + text, 'quick_task', '作業追加');
        if (dateish && !timeish && !out.some(x => x.action === 'quick_deadline') && !out.some(x => x.action === 'quick_task')) {
          addReg('task', '作業として追加: ' + text, 'quick_task', '作業追加');
          addReg('deadline', '期限として追加: ' + text, 'quick_deadline', '期限追加');
        }
      }
    }

    const seen = new Set();
    return out.filter(x => !seen.has(x.id) && seen.add(x.id)).slice(0, 6);
  }
  function renderPendingCandidates(q){
    const items = orderCandidates(quickLocalCandidates(q));
    SELECTED = 0;
    SHOW_ALL_CANDIDATES = false;
    if (items.length) {
      RESOLVED_QUERY = q;
      LAST_IS_INSTANT = true;
      LAST = renderCandidates(items);
      setSelected(0);
      if (hasInvalidTemporalExpression(q)) setResultsStatus('日付または時刻を確認してください');
    } else {
      RESOLVED_QUERY = null;
      LAST_IS_INSTANT = false;
      LAST = [];
      showEnterHint();
    }
  }
  function candidateGroup(item){
    if (item.kind === '実行候補') return '実行候補';
    if (item.kind === '登録候補') return '登録候補';
    if (['予定','出来事','期限','事務','作業','周期作業','人物','事案','経歴'].includes(item.kind)) return '検索結果';
    if (item.kind === '画面') return '画面';
    if (item.kind === 'ローカルツール') return 'ローカルツール';
    return item.kind || 'その他';
  }
  function candidateGroupLabel(group){
    return ({
      '実行候補':'実行する',
      '登録候補':'登録する',
      '検索結果':'見つかった項目',
      '画面':'画面を開く',
      'ローカルツール':'ツールを開く',
      'その他':'その他'
    })[group] || group;
  }
  function orderCandidates(items){
    const order = ['実行候補','登録候補','検索結果','画面','ローカルツール','その他'];
    return items.slice().sort((a,b) => order.indexOf(candidateGroup(a)) - order.indexOf(candidateGroup(b)));
  }
  function groupHeading(text){
    const h = document.createElement('div');
    h.className = 'result-group-heading';
    h.textContent = text;
    return h;
  }
  function renderCandidates(items){
    const box = $('results'); if (!box) return [];
    const fragment = document.createDocumentFragment();
    const shown = SHOW_ALL_CANDIDATES ? items : items.slice(0, 5);
    let lastGroup = '';
    shown.forEach((item, i) => {
      const g = candidateGroup(item);
      if (g !== lastGroup) { fragment.appendChild(groupHeading(candidateGroupLabel(g))); lastGroup = g; }
      fragment.appendChild(resultNode(item, i));
    });
    if (items.length > shown.length) {
      const more = document.createElement('div');
      more.className = 'result more-candidates';
      more.innerHTML = '<div><div class="title">さらに' + esc(items.length - shown.length) + '件あります</div><div class="meta">入力を足すと候補を絞れます。</div></div><button>さらに表示</button>';
      const btn = more.querySelector('button');
      if (btn) btn.onclick = e => {
        e.stopPropagation();
        SHOW_ALL_CANDIDATES = true;
        LAST = renderCandidates(items);
        setSelected(Math.min(shown.length, Math.max(0, LAST.length - 1)));
      };
      fragment.appendChild(more);
    }
    box.replaceChildren(fragment);
    setResultsStatus(items.length + '件の候補');
    return shown;
  }
  function cancelActiveResolve(){
    RESOLVE_SEQ += 1;
    if (RESOLVE_ABORT) RESOLVE_ABORT.abort();
    RESOLVE_ABORT = null;
    RESOLVE_REQUEST_QUERY = '';
    setResolving(false);
  }
  function scheduleResolve(delay = 150){
    clearTimeout(RESOLVE_TIMER);
    RESOLVE_TIMER = setTimeout(resolve, delay);
  }
  async function resolve(){
    const input = $('commandText');
    const q = clean(input ? input.value : '');
    const box = $('results'); if (!box) return;
    if (!q) {
      cancelActiveResolve();
      RESOLVED_QUERY = null;
      LAST = [];
      SELECTED = 0;
      LAST_IS_INSTANT = false;
      setResolving(false);
      showEnterHint();
      return;
    }
    if (!LAST_IS_INSTANT && RESOLVED_QUERY === q && LAST.length) return;
    const cached = safeCandidatesForQuery(q, cachedResolve(q));
    if (cached && cached.length) {
      SHOW_ALL_CANDIDATES = false;
      LAST = []; RESOLVED_QUERY = q; SELECTED = 0; LAST_IS_INSTANT = false;
      LAST = renderCandidates(orderCandidates(cached));
      setSelected(0);
      if (hasInvalidTemporalExpression(q)) setResultsStatus('日付または時刻を確認してください');
      return;
    }
    const seq = ++RESOLVE_SEQ;
    if (RESOLVE_ABORT) RESOLVE_ABORT.abort();
    const controller = new AbortController();
    RESOLVE_ABORT = controller;
    RESOLVE_REQUEST_QUERY = q;
    setResolving(true);
    setResultsStatus('候補を確認しています…');
    const instantFallback = LAST_IS_INSTANT && RESOLVED_QUERY === q ? LAST.slice() : [];
    try {
      const j = await api('/api/command/resolve?q=' + encodeURIComponent(q), {signal: controller.signal});
      if (seq !== RESOLVE_SEQ) return;
      const items = orderCandidates(safeCandidatesForQuery(q, j.candidates));
      if(items.length)rememberResolve(q, items);
      SHOW_ALL_CANDIDATES = false;
      LAST = [];
      RESOLVED_QUERY = q;
      SELECTED = 0;
      LAST_IS_INSTANT = false;
      if (!items.length) {
        if(instantFallback.length){
          LAST=instantFallback; LAST_IS_INSTANT=true;
          setResultsStatus(hasInvalidTemporalExpression(q) ? '日付または時刻を確認してください' : `${LAST.length}件のすぐ使える候補`); setSelected(0);
          return;
        }
        setSelected(0);
        box.innerHTML = '<div class="result"><div><div class="title">候補がありません</div><div class="meta">予定名、作業名、人物名、ツール名を別の言葉で入力してください</div></div></div>';
        setResultsStatus('候補は見つかりませんでした');
        return;
      }
      LAST = renderCandidates(items);
      setSelected(0);
      if (hasInvalidTemporalExpression(q)) setResultsStatus('日付または時刻を確認してください');
    } catch (e) {
      if (e && e.name === 'AbortError') return;
      if (seq !== RESOLVE_SEQ) return;
      RESOLVED_QUERY = q;
      if (!LAST.length) { setSelected(0); box.innerHTML = '<div class="result"><div><div class="title">' + esc(e.message) + '</div></div></div>'; }
      else toast(e.message || '候補更新に失敗しました');
    } finally {
      if (RESOLVE_ABORT === controller) { RESOLVE_ABORT = null; RESOLVE_REQUEST_QUERY = ''; }
      if (seq === RESOLVE_SEQ) setResolving(false);
    }
  }
  async function execute(item){
    if (!item || EXECUTING) return;
    const text = clean($('commandText').value);
    setExecutionBusy(true);
    setResultsStatus('実行しています…');
    try {
      if (item.action === 'open' && item.href) { await openWorkspace(item.href); return; }
      if (item.action === 'launch_local') { await api('/api/local-tools/launch', {method:'POST', body:JSON.stringify({rel:item.rel})}); finishAndHide('起動しました', 360); return; }
      if (item.action === 'open_tools_folder') { await api('/api/local-tools/open-folder', {method:'POST', body:'{}'}); finishAndHide('フォルダを開きました', 360); return; }
      await api('/api/command/execute', {method:'POST', body:JSON.stringify({candidate:item, text})});
      clearResolveCache();
      const speculumActions = new Set(['quick_event','quick_happening','quick_deadline','quick_jimu']);
      const continuumActions = new Set(['quick_task','quick_cycle','task_complete','task_waiting','task_today','task_due','task_priority_high','task_priority_normal','task_priority_low','cycle_complete','cycle_skip','cycle_pause','cycle_resume','cycle_end']);
      if (speculumActions.has(item.action)) notifyDataChanged('speculum');
      if (continuumActions.has(item.action)) notifyDataChanged('continuum');
      const messages = {
        quick_event:'予定を追加しました', quick_happening:'出来事を追加しました', quick_deadline:'期限を追加しました', quick_jimu:'事務を追加しました', quick_task:'作業を追加しました', quick_cycle:'周期作業を追加しました',
        task_complete:'作業を完了しました', task_waiting:'作業を「待ち」に移しました', task_today:'作業を「今日やる」に移しました', task_due:'作業期限を変更しました', task_priority_high:'優先度を「高優先」にしました', task_priority_normal:'優先度を「通常」にしました', task_priority_low:'優先度を「低優先」にしました',
        cycle_complete:'今回分を完了しました', cycle_skip:'今回分をスキップしました', cycle_pause:'周期作業を休止しました', cycle_resume:'周期作業を再開しました', cycle_end:'周期作業を終了しました'
      };
      loadSummary().catch(()=>{});
      finishAndHide(messages[item.action] || (item.kind === '実行候補' ? '実行しました' : '追加しました'), 820);
    } catch (e) {
      toast(e.message || '実行できませんでした');
      setExecutionBusy(false);
      setResultsStatus(LAST.length + '件の候補');
      $('commandText')?.focus();
    }
  }
  function bind(){
    $('commandBtn').onclick = resolve;
    const commandInput = $('commandText');
    const handleCommandInput = (immediate = false) => {
      const q = clean(commandInput.value);
      if (q && RESOLVE_ABORT && RESOLVE_REQUEST_QUERY !== q) cancelActiveResolve();
      updateCommandState();
      if (q) {
        renderPendingCandidates(q);
        scheduleResolve(immediate ? 0 : 150);
      } else {
        cancelActiveResolve();
        RESOLVED_QUERY = null;
        LAST = [];
        SELECTED = 0;
        SHOW_ALL_CANDIDATES = false;
        LAST_IS_INSTANT = false;
        clearResolveCache();
        showEnterHint();
      }
    };
    commandInput.addEventListener('compositionstart', () => {
      IS_COMPOSING = true;
      clearTimeout(RESOLVE_TIMER);
      if (RESOLVE_ABORT) cancelActiveResolve();
    });
    commandInput.addEventListener('compositionend', () => {
      IS_COMPOSING = false;
      handleCommandInput(true);
    });
    commandInput.addEventListener('input', () => {
      if (IS_COMPOSING) return;
      handleCommandInput(false);
    });
    commandInput.addEventListener('keydown', e => {
      if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
        if (LAST.length && RESOLVED_QUERY === clean($('commandText').value)) {
          e.preventDefault();
          setSelected(SELECTED + (e.key === 'ArrowDown' ? 1 : -1));
        }
        return;
      }
      if (e.key === 'Home' && LAST.length) { e.preventDefault(); setSelected(0); return; }
      if (e.key === 'End' && LAST.length) { e.preventDefault(); setSelected(LAST.length - 1); return; }
      if (e.key === 'Escape') {
        e.preventDefault();
        cancelActiveResolve();
        const input = $('commandText'); if (input) input.value = '';
        LAST = []; SELECTED = 0; RESOLVED_QUERY = null; SHOW_ALL_CANDIDATES = false; LAST_IS_INSTANT = false;
        showEnterHint();
        updateCommandState();
        return;
      }
      if (e.key === '?' && !clean($('commandText').value)) {
        e.preventDefault();
        const box = $('results'); if (box) box.innerHTML = '<div class="result hint-result"><div><div class="title">操作ヒント</div><div class="meta">Enterキーで第一候補、上下キーで候補移動、Ctrl＋Enterキーで即実行、Escキーで入力を消去。</div></div></div>';
        return;
      }
      if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
        e.preventDefault();
        const q = clean($('commandText').value);
        if (LAST.length && RESOLVED_QUERY === q) execute(LAST[SELECTED] || LAST[0]);
        else resolve().then(() => execute(LAST[SELECTED] || LAST[0]));
        return;
      }
      if (e.key === 'Enter') {
        e.preventDefault();
        const q = clean($('commandText').value);
        if (LAST.length && RESOLVED_QUERY === q) execute(LAST[SELECTED] || LAST[0]);
        else resolve();
      }
    });
    document.querySelectorAll('[data-sample]').forEach(b => b.addEventListener('click', async () => {
      const input = $('commandText');
      if (input) { input.value = b.dataset.sample || ''; input.focus(); }
      updateCommandState();
      await resolve();
    }));
    $('openMain').onclick = () => openWorkspace('speculum:today');
    $('openWork').onclick = () => openWorkspace('continuum');
    $('openToolsFolder').onclick = async () => {
      try {
        await api('/api/local-tools/open-folder', {method:'POST', body:'{}'});
        finishAndHide('フォルダを開きました', 360);
      } catch (e) {
        toast(e.message || 'フォルダを開けませんでした');
      }
    };
    window.addEventListener('focus',()=>{if(!refreshDayContextIfNeeded())loadSummary().catch(()=>{});});
    document.addEventListener('visibilitychange',()=>{if(!document.hidden&&!refreshDayContextIfNeeded())loadSummary().catch(()=>{});});
    scheduleDayContextCheck();
  }
  document.addEventListener('DOMContentLoaded', async () => {
    try {
      applyAnchor();
      await initToken();
      setupDataSync();
      bind();
      loadSummary();
      showEnterHint();
      updateCommandState();
      setTimeout(() => $('commandText')?.focus(), 40);
    } catch (e) {
      document.body.innerHTML = '<main class="cat-bubble"><h1>起動できませんでした</h1><p>' + esc(e.message) + '</p></main>';
    }
  });
})();

# -*- coding: utf-8 -*-
import json
import urllib.request

PORT = 8765
base = f'http://127.0.0.1:{PORT}'
try:
    with urllib.request.urlopen(base + '/api/runtime/status', timeout=1.5) as r:
        status = json.loads(r.read().decode('utf-8'))
    if status.get('schema') != 'blackcat-worktool-runtime':
        raise RuntimeError('黒猫ワークツール以外のサービスが応答しています。')
    with urllib.request.urlopen(base + '/api/security/token', timeout=1.5) as r:
        token = json.loads(r.read().decode('utf-8')).get('token', '')
    req = urllib.request.Request(base + '/api/shutdown', data=b'{}', method='POST', headers={'Content-Type':'application/json','X-Blackcat-Token': token})
    urllib.request.urlopen(req, timeout=1.5).read()
except Exception:
    pass

Attribute VB_Name = "modConstants"
Option Explicit

Public Const TOOL_PASSWORD As String = "cashop"

Public Const SH_CONFIG As String = "�ݒ�"
Public Const SH_INPUT As String = "����"
Public Const SH_TEKIYO As String = "�E�v���"
Public Const SH_ACCOUNT_TYPE As String = "�Ȗڌ��"
Public Const SH_INPUT_MODE As String = "���̓��[�h"
Public Const SH_YEAR_MODE As String = "�N���͕������"
Public Const SH_DISPLAY_OPTION As String = "�\���ؑ֌��"
Public Const SH_POST_KEEP As String = "�]�L��ێ����"
Public Const SH_POST_CLEAR As String = "�]�L�㏈�����"
Public Const SH_BANK_CAND As String = "��s�����"
Public Const SH_BRANCH_CAND As String = "�x�X�����"
Public Const SH_PERSON_CAND As String = "�l�����"
Public Const SH_WORK_TX As String = "W_���"
Public Const SH_WORK_BAL As String = "W_�c��"
Public Const SH_CHECK As String = "C_�`�F�b�N"
Public Const SH_OUTPUT_TX As String = "��������\"
Public Const SH_OUTPUT_BAL As String = "�c�����ڕ\"
Public Const SH_SHOP_TARGET As String = "�戵�X�ϊ��Ώ�"
Public Const SH_OUTPUT_TX_CONVERTED As String = "��������\_�戵�X�ϊ���"
Public Const SH_SETUP_LOG As String = "W_�Z�b�g�A�b�v���O"
Public Const SH_WORK_PERSON_REF As String = "W_�l���Q��"
Public Const SH_WORK_ACCOUNT As String = "W_����"
Public Const SH_WORK_ID As String = "W_ID�Ǘ�"
Public Const SH_LINK_LOG As String = "W_�A�g���O"
Public Const COMMON_DATA_FILE As String = "00_���ʃf�[�^.xlsx"
Public Const COMMON_SCHEMA_VERSION As String = "finance-link-v1"

Public Const NM_LST_TEKIYO As String = "lstTekiyo"
Public Const NM_LST_ACCOUNT_TYPE As String = "lstAccountType"
Public Const NM_LST_INPUT_MODE As String = "lstInputMode"
Public Const NM_LST_YEAR_MODE As String = "lstYearInputMode"
Public Const NM_LST_DISPLAY_OPTION As String = "lstDisplayOption"
Public Const NM_LST_POST_KEEP As String = "lstPostTransferKeep"
Public Const NM_LST_POST_CLEAR As String = "lstPostTransferClear"
Public Const NM_LST_BANK_CAND As String = "lstBankCandidates"
Public Const NM_LST_BRANCH_CAND As String = "lstBranchCandidates"
Public Const NM_LST_PERSON_CAND As String = "lstPersonCandidates"
Public Const NM_LST_LINKED_PERSON_CAND As String = "lstLinkedPersonCandidates"

Public Const ROW_CFG_INHERITANCE_DATE As Long = 4
Public Const ROW_CFG_BAL_START_YEAR As Long = 5
Public Const ROW_CFG_BAL_END_YEAR As Long = 6
Public Const ROW_CFG_YEAR_ADD As Long = 7
Public Const ROW_CFG_INPUT_MODE As Long = 8
Public Const ROW_CFG_POST_KEEP As Long = 9
Public Const ROW_CFG_POST_TX As Long = 10
Public Const ROW_CFG_POST_BAL As Long = 11
Public Const ROW_CFG_YEAR_MODE As Long = 12
Public Const ROW_CFG_RELATIONSHIP As Long = 13
Public Const ROW_CFG_SHOW_INHERITANCE_ROW As Long = 14
Public Const ROW_CFG_SHOW_OPEN_DATE_ROW As Long = 15
Public Const ROW_CFG_SHOW_CLOSE_DATE_ROW As Long = 16
Public Const ROW_CFG_SHOW_BALANCE_ROWS As Long = 17
Public Const ROW_CFG_LINK_MODE As Long = 18
Public Const ROW_CFG_COMMON_DATA As Long = 19
Public Const ROW_CFG_AUTO_SAVE_COMMON As Long = 20
Public Const COL_CFG_VALUE As Long = 3

'�����}�X�^�i�ݒ�V�[�g���j�B�����J�ݓ��E���������́u1.53.5.6�v�`���Ŏg�p����B
'�V���������������ꍇ�́A�ݒ�V�[�g�̌����}�X�^�ɍs��ǉ�����΂悢�B
Public Const ERA_MASTER_TITLE_ROW As Long = 39
Public Const ERA_MASTER_HEADER_ROW As Long = 40
Public Const ERA_MASTER_FIRST_ROW As Long = 41
Public Const ERA_MASTER_MAX_ROW As Long = 50
Public Const ERA_COL_CODE As Long = 2      'B
Public Const ERA_COL_NAME As Long = 3      'C
Public Const ERA_COL_ABBR As Long = 4      'D
Public Const ERA_COL_START As Long = 5     'E
Public Const ERA_COL_END As Long = 6       'F
Public Const ERA_COL_ENABLED As Long = 7   'G

Public Const CELL_BANK As String = "C5"
Public Const CELL_BRANCH As String = "F5"
Public Const CELL_PERSON As String = "I5"
Public Const CELL_RELATIONSHIP As String = "K5"
Public Const CELL_ACCOUNT_TYPE As String = "C6"
Public Const CELL_ACCOUNT_NO As String = "F6"
Public Const CELL_OPEN_DATE As String = "I6"
Public Const CELL_CLOSE_DATE As String = "K6"
Public Const CELL_STATUS As String = "B12"
Public Const CELL_PERSON_ID As String = "AA5"
Public Const CELL_ACCOUNT_ID As String = "AA6"
Public Const CELL_LINK_STATUS As String = "AA8"

Public Const BAL_LABEL_ROW As Long = 9
Public Const BAL_VALUE_ROW As Long = 10
Public Const BAL_DATE_ROW As Long = 11
Public Const BAL_FIRST_COL As Long = 2       'B
Public Const BAL_MAX_COL As Long = 11        'K
Public Const BAL_MAX_LABELS As Long = 9      '�Ō���Ɂu���̑��v��u�����߁A�c����͍ő�9��

Public Const TX_HEADER_ROW As Long = 14
Public Const TX_FIRST_ROW As Long = 15
Public Const TX_LAST_ROW As Long = 314

Public Const COL_TX_YEAR As Long = 2       'B
Public Const COL_TX_MONTH As Long = 3      'C
Public Const COL_TX_DAY As Long = 4        'D
Public Const COL_TX_TIME As Long = 5       'E
Public Const COL_TX_WITHDRAW As Long = 6   'F
Public Const COL_TX_DEPOSIT As Long = 7    'G
Public Const COL_TX_SHOP As Long = 8       'H
Public Const COL_TX_MACHINE As Long = 9    'I
Public Const COL_TX_TEKIYO As Long = 10    'J
Public Const COL_TX_OTHER As Long = 11     'K

Public Const MODE_NORMAL As String = "�ʏ�"
Public Const MODE_NO_TIME As String = "�����Ȃ�"
Public Const MODE_NO_MACHINE As String = "�@�ԂȂ�"
Public Const MODE_NO_TEKIYO As String = "�E�v�Ȃ�"
Public Const MODE_WITH_OTHER As String = "���̑�����"
Public Const MODE_SIMPLE As String = "�Ȉ�"

Public Const KEEP_NONE As String = "�c���Ȃ�"
Public Const KEEP_PERSON_ONLY As String = "�����̂ݎc��"
Public Const KEEP_BANK_BRANCH As String = "��s���E�x�X���̂ݎc��"
Public Const KEEP_BANK_BRANCH_PERSON_TYPE As String = "��s���E�x�X���E�����E�Ȗڂ��c��"
Public Const KEEP_ALL_ACCOUNT As String = "�����������ׂĎc��"

Public Const POST_CLEAR As String = "�N���A����"
Public Const POST_KEEP As String = "�c��"

Public Const YEAR_MODE_WAREKI As String = "�a��"
Public Const YEAR_MODE_WESTERN2 As String = "����2��"

Public Const DISPLAY_ON As String = "�\������"
Public Const DISPLAY_OFF As String = "�\�����Ȃ�"

Public Const UI_PREFIX As String = "cashop_ui_"

Public Const OUT_COL_BANK As Long = 1
Public Const OUT_COL_BRANCH As Long = 2
Public Const OUT_COL_PERSON As Long = 3
Public Const OUT_COL_ACCOUNT_TYPE As Long = 4
Public Const OUT_COL_ACCOUNT_NO As Long = 5
Public Const OUT_COL_DATE As Long = 6
Public Const OUT_COL_TIME As Long = 7
Public Const OUT_COL_WITHDRAW As Long = 8
Public Const OUT_COL_DEPOSIT As Long = 9
Public Const OUT_COL_SHOP As Long = 10
Public Const OUT_COL_MACHINE As Long = 11
Public Const OUT_COL_TEKIYO As Long = 12
Public Const OUT_COL_OTHER As Long = 13

Public Const WORK_TX_COL_RELATIONSHIP As Long = 14
Public Const WORK_BAL_COL_RELATIONSHIP As Long = 12

Public Const WORK_TX_COL_PERSON_ID As Long = 15
Public Const WORK_TX_COL_ACCOUNT_ID As Long = 16
Public Const WORK_TX_COL_TRANSACTION_ID As Long = 17
Public Const WORK_TX_COL_ROW_KIND As Long = 18
Public Const WORK_TX_COL_TRANSFER_ID As Long = 19
Public Const WORK_TX_COL_SOURCE_ROW As Long = 20
Public Const WORK_TX_COL_INPUT_ORDER As Long = 21
Public Const WORK_TX_COL_SHOP_FINAL As Long = 22
Public Const WORK_TX_COL_DATA_STATUS As Long = 23
Public Const WORK_TX_COL_TRANSFERRED_AT As Long = 24
Public Const WORK_TX_COL_AFTER_BALANCE As Long = 25
Public Const WORK_TX_COL_AFTER_BALANCE_RAW As Long = 26
Public Const WORK_TX_COL_BALANCE_SOURCE As Long = 27
Public Const WORK_TX_COL_SOURCE_FINGERPRINT As Long = 28
Public Const WORK_TX_LAST_COL As Long = 28

Public Const WORK_BAL_COL_PERSON_ID As Long = 13
Public Const WORK_BAL_COL_ACCOUNT_ID As Long = 14
Public Const WORK_BAL_COL_BALANCE_ID As Long = 15
Public Const WORK_BAL_COL_TRANSFER_ID As Long = 16
Public Const WORK_BAL_COL_DATA_STATUS As Long = 17
Public Const WORK_BAL_COL_TRANSFERRED_AT As Long = 18
Public Const WORK_BAL_COL_SOURCE_FINGERPRINT As Long = 19
Public Const WORK_BAL_LAST_COL As Long = 19

Public Const ROW_KIND_TRANSACTION As String = "���"
Public Const ROW_KIND_OPEN As String = "�����J��"
Public Const ROW_KIND_CLOSE As String = "�������"
Public Const ROW_KIND_BALANCE As String = "�c��"
Public Const ROW_KIND_INHERITANCE As String = "�����J�n"
Public Const DATA_STATUS_ACTIVE As String = "�L��"
Public Const DATA_STATUS_CANCELLED As String = "���"

Public Const OUT_COL_PERSON_ID As Long = 14
Public Const OUT_COL_ACCOUNT_ID As Long = 15
Public Const OUT_COL_TRANSACTION_ID As Long = 16
Public Const OUT_COL_ROW_KIND As Long = 17
Public Const OUT_COL_SHOP_FINAL As Long = 18
Public Const OUT_COL_DATA_STATUS As Long = 19
Public Const OUT_LAST_COL As Long = 19

Public Const SHOP_TGT_COL_NO As Long = 1
Public Const SHOP_TGT_COL_BANK As Long = 2
Public Const SHOP_TGT_COL_CODE As Long = 3
Public Const SHOP_TGT_COL_COUNT As Long = 4
Public Const SHOP_TGT_COL_ROWS As Long = 5
Public Const SHOP_TGT_COL_RESULT As Long = 6
Public Const SHOP_TGT_COL_STATUS As Long = 7
Public Const SHOP_TGT_COL_CREATED As Long = 8
Public Const SHOP_TGT_LAST_COL As Long = 8

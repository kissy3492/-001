Attribute VB_Name = "modAppState"
Option Explicit

Private mStateDepth As Long
Private mPrevEvents As Boolean
Private mPrevScreenUpdating As Boolean
Private mPrevDisplayAlerts As Boolean
Private mPrevCalculation As XlCalculation
Private mPrevStatusBar As Variant

Public Sub AppBegin(Optional ByVal statusText As String = "������...")
    '�Z�b�g�A�b�v�E�ꊇ�쐬�E�o�͂ł́A�����ŕʂ̏�����AppBegin/AppEnd���ĂԁB
    '�r����AppEnd�ŉ�ʍX�V��C�x���g��߂��Ȃ��悤�A����q�[�x�ŊǗ�����B
    On Error Resume Next
    If mStateDepth = 0 Then
        mPrevEvents = Application.EnableEvents
        mPrevScreenUpdating = Application.ScreenUpdating
        mPrevDisplayAlerts = Application.DisplayAlerts
        mPrevCalculation = Application.Calculation
        mPrevStatusBar = Application.StatusBar
        Application.EnableEvents = False
        Application.ScreenUpdating = False
        Application.DisplayAlerts = False
        Application.Calculation = xlCalculationManual
    End If
    mStateDepth = mStateDepth + 1
    Application.StatusBar = statusText
    On Error GoTo 0
End Sub

Public Sub AppEnd()
    On Error Resume Next
    If mStateDepth > 0 Then mStateDepth = mStateDepth - 1
    If mStateDepth = 0 Then
        Application.EnableEvents = mPrevEvents
        Application.ScreenUpdating = mPrevScreenUpdating
        Application.DisplayAlerts = mPrevDisplayAlerts
        Application.Calculation = mPrevCalculation
        Application.StatusBar = mPrevStatusBar
    End If
    On Error GoTo 0
End Sub

Public Sub AppForceRestore()
    On Error Resume Next
    DisableInputKeys
    mStateDepth = 0
    Application.EnableEvents = True
    Application.ScreenUpdating = True
    Application.DisplayAlerts = True
    Application.Calculation = xlCalculationAutomatic
    Application.StatusBar = False
    On Error GoTo 0
End Sub

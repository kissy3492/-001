Attribute VB_Name = "modSheetVisibility"
Option Explicit

Public Sub ShowOnlyInput()
    On Error GoTo EH
    AppBegin
    ShowOnlyInputCore True
    ApplyInputUsability
CleanExit:
    AppEnd
    Exit Sub
EH:
    AppEnd
    RuntimeShowError "ShowOnlyInput", "���͉�ʂւ̐ؑ�", "�l�����̓V�[�g�����݂��邩�m�F���Ă��������B"
End Sub

Public Sub ShowSettings()
    On Error GoTo EH
    AppBegin
    ShowOnlyInputCore False
    ThisWorkbook.Worksheets(SH_CONFIG).Visible = xlSheetVisible
    ApplyConfigUsability
    ThisWorkbook.Worksheets(SH_CONFIG).Activate
CleanExit:
    AppEnd
    Exit Sub
EH:
    AppEnd
    RuntimeShowError "ShowSettings", "�ݒ��ʂւ̐ؑ�", "�ݒ�V�[�g�����݂��邩�m�F���Ă��������B"
End Sub

Public Sub ShowOutputSheets()
    On Error GoTo EH
    AppBegin
    ApplyOutputUsability
    ShowOutputSheetsCore True
CleanExit:
    AppEnd
    Exit Sub
EH:
    AppEnd
    RuntimeShowError "ShowOutputSheets", "�o�̓V�[�g�\��", "�o�̓V�[�g�쐬��ɍĎ��s���Ă��������B"
End Sub

Public Sub RunChecksAndShow()
    On Error GoTo EH
    AppBegin
    RunChecks
    ApplyOutputUsability
    ShowOnlyInputCore False
    ThisWorkbook.Worksheets(SH_CHECK).Visible = xlSheetVisible
    ThisWorkbook.Worksheets(SH_CHECK).Activate
CleanExit:
    AppEnd
    Exit Sub
EH:
    AppEnd
    RuntimeShowError "RunChecksAndShow", "�����`�F�b�N", "�l�����ƍ�ƃV�[�g�̏�Ԃ��m�F���Ă��������B"
End Sub

Public Sub ShowOnlyInputCore(Optional ByVal activateInput As Boolean = True)
    Dim ws As Worksheet
    ThisWorkbook.Worksheets(SH_INPUT).Visible = xlSheetVisible
    If activateInput Then ThisWorkbook.Worksheets(SH_INPUT).Activate
    For Each ws In ThisWorkbook.Worksheets
        Select Case ws.Name
            Case SH_INPUT
                ws.Visible = xlSheetVisible
            Case SH_W_PERSON, SH_W_REL, SH_W_ADDR_CAND, SH_W_ADDR_HIST, SH_W_EVENT, SH_W_CAND, SH_W_ID, SH_W_LOG
                ws.Visible = xlSheetVeryHidden
            Case Else
                ws.Visible = xlSheetHidden
        End Select
    Next ws
    If activateInput Then ThisWorkbook.Worksheets(SH_INPUT).Activate
End Sub

Public Sub ShowOutputSheetsCore(Optional ByVal activateDiagram As Boolean = True)
    Dim ws As Worksheet, sh As Variant, outputSheets As Variant
    ThisWorkbook.Worksheets(SH_INPUT).Visible = xlSheetVisible
    ThisWorkbook.Worksheets(SH_INPUT).Activate
    For Each ws In ThisWorkbook.Worksheets
        Select Case ws.Name
            Case SH_INPUT
                ws.Visible = xlSheetVisible
            Case SH_W_PERSON, SH_W_REL, SH_W_ADDR_CAND, SH_W_ADDR_HIST, SH_W_EVENT, SH_W_CAND, SH_W_ID, SH_W_LOG
                ws.Visible = xlSheetVeryHidden
            Case Else
                ws.Visible = xlSheetHidden
        End Select
    Next ws
    outputSheets = Array(SH_DIAGRAM, SH_ADDR_TABLE, SH_COHAB, SH_TIMELINE, SH_PERSON_LIST, SH_CONFIRM, SH_CHECK)
    For Each sh In outputSheets
        If SheetExists(CStr(sh), ThisWorkbook) Then ThisWorkbook.Worksheets(CStr(sh)).Visible = xlSheetVisible
    Next sh
    If activateDiagram And SheetExists(SH_DIAGRAM, ThisWorkbook) Then ThisWorkbook.Worksheets(SH_DIAGRAM).Activate
End Sub

Attribute VB_Name = "modUtilities"
Option Explicit

Public Function SheetExists(ByVal sheetName As String) As Boolean
    Dim ws As Worksheet
    On Error Resume Next
    Set ws = ThisWorkbook.Worksheets(sheetName)
    SheetExists = Not ws Is Nothing
    On Error GoTo 0
End Function

Public Function GetSheet(ByVal sheetName As String) As Worksheet
    Set GetSheet = ThisWorkbook.Worksheets(sheetName)
End Function

Public Function GetOrCreateSheet(ByVal sheetName As String, Optional ByVal clearContents As Boolean = False) As Worksheet
    Dim ws As Worksheet
    On Error Resume Next
    Set ws = ThisWorkbook.Worksheets(sheetName)
    On Error GoTo 0
    If ws Is Nothing Then
        Set ws = ThisWorkbook.Worksheets.Add(After:=ThisWorkbook.Worksheets(ThisWorkbook.Worksheets.Count))
        ws.Name = sheetName
    End If
    If clearContents Then
        On Error Resume Next
        ws.Unprotect Password:=TOOL_PASSWORD
        ws.Cells.Clear
        DeleteAllShapes ws
        On Error GoTo 0
    End If
    Set GetOrCreateSheet = ws
End Function

Public Sub DeleteAllShapes(ByVal ws As Worksheet)
    Dim shp As Shape
    On Error Resume Next
    For Each shp In ws.Shapes
        shp.Delete
    Next shp
    On Error GoTo 0
End Sub

Public Function LastRow(ByVal ws As Worksheet, Optional ByVal col As Long = 1) As Long
    Dim r As Long
    On Error Resume Next
    r = ws.Cells(ws.Rows.Count, col).End(xlUp).Row
    If r < 1 Then r = 1
    LastRow = r
    On Error GoTo 0
End Function

Public Function LastUsedRowInSheet(ByVal ws As Worksheet) As Long
    Dim c As Range
    On Error Resume Next
    Set c = ws.Cells.Find(What:="*", LookIn:=xlFormulas, LookAt:=xlPart, SearchOrder:=xlByRows, SearchDirection:=xlPrevious)
    If c Is Nothing Then
        LastUsedRowInSheet = 1
    Else
        LastUsedRowInSheet = c.Row
    End If
    On Error GoTo 0
End Function

Public Function LastUsedColumn(ByVal ws As Worksheet) As Long
    Dim c As Range
    On Error Resume Next
    Set c = ws.Cells.Find(What:="*", LookIn:=xlFormulas, LookAt:=xlPart, SearchOrder:=xlByColumns, SearchDirection:=xlPrevious)
    If c Is Nothing Then
        LastUsedColumn = 1
    Else
        LastUsedColumn = c.Column
    End If
    On Error GoTo 0
End Function

Public Function CellText(ByVal v As Variant) As String
    If IsError(v) Or IsNull(v) Or IsEmpty(v) Then
        CellText = ""
    Else
        CellText = Trim$(CStr(v))
    End If
End Function

Public Function NzDbl(ByVal v As Variant, Optional ByVal defaultValue As Double = 0) As Double
    On Error GoTo EH
    If IsError(v) Or IsNull(v) Or IsEmpty(v) Or Len(Trim$(CStr(v))) = 0 Then
        NzDbl = defaultValue
    Else
        NzDbl = CDbl(Replace(CStr(v), ",", ""))
    End If
    Exit Function
EH:
    NzDbl = defaultValue
End Function

Public Function NzLong(ByVal v As Variant, Optional ByVal defaultValue As Long = 0) As Long
    On Error GoTo EH
    If IsError(v) Or IsNull(v) Or IsEmpty(v) Or Len(Trim$(CStr(v))) = 0 Then
        NzLong = defaultValue
    Else
        NzLong = CLng(v)
    End If
    Exit Function
EH:
    NzLong = defaultValue
End Function

Public Function ToDateOrEmpty(ByVal v As Variant) As Variant
    If IsDate(v) Then
        ToDateOrEmpty = CDate(v)
    Else
        ToDateOrEmpty = Empty
    End If
End Function

Public Function DateSerialLong(ByVal v As Variant) As Long
    If IsDate(v) Then
        DateSerialLong = CLng(DateValue(CDate(v)))
    Else
        DateSerialLong = 0
    End If
End Function

Public Function DateRangeText(ByVal dMin As Variant, ByVal dMax As Variant) As String
    If Not IsDate(dMin) And Not IsDate(dMax) Then
        DateRangeText = ""
    ElseIf IsDate(dMin) And IsDate(dMax) Then
        If CLng(DateValue(CDate(dMin))) = CLng(DateValue(CDate(dMax))) Then
            DateRangeText = Format$(CDate(dMin), "yyyy/m/d")
        Else
            DateRangeText = Format$(CDate(dMin), "yyyy/m/d") & "�`" & Format$(CDate(dMax), "yyyy/m/d")
        End If
    ElseIf IsDate(dMin) Then
        DateRangeText = Format$(CDate(dMin), "yyyy/m/d")
    Else
        DateRangeText = Format$(CDate(dMax), "yyyy/m/d")
    End If
End Function

Public Function HeaderColumn(ByVal ws As Worksheet, ByVal headerText As String, Optional ByVal headerRow As Long = 1) As Long
    Dim lastC As Long, c As Long
    lastC = LastUsedColumn(ws)
    For c = 1 To lastC
        If CellText(ws.Cells(headerRow, c).Value) = headerText Then
            HeaderColumn = c
            Exit Function
        End If
    Next c
    HeaderColumn = 0
End Function

Public Function FirstHeaderColumn(ByVal ws As Worksheet, ByVal headers As Variant, Optional ByVal headerRow As Long = 1) As Long
    Dim i As Long, c As Long
    For i = LBound(headers) To UBound(headers)
        c = HeaderColumn(ws, CStr(headers(i)), headerRow)
        If c > 0 Then
            FirstHeaderColumn = c
            Exit Function
        End If
    Next i
    FirstHeaderColumn = 0
End Function

Public Sub SetRowValues(ByVal topLeft As Range, ByVal values As Variant)
    Dim i As Long
    For i = LBound(values) To UBound(values)
        topLeft.Offset(0, i - LBound(values)).Value = values(i)
    Next i
End Sub

Public Sub FormatHeader(ByVal rng As Range, Optional ByVal fillColor As Long = 0)
    If fillColor = 0 Then fillColor = ThemeColor("header")
    With rng
        .Interior.Color = fillColor
        .Font.Color = vbWhite
        .Font.Bold = True
        .HorizontalAlignment = xlCenter
        .VerticalAlignment = xlCenter
        .WrapText = True
    End With
    ThemeApplyCompleteBorders rng, "border"
End Sub

Public Sub FormatBody(ByVal rng As Range)
    With rng
        .Font.Name = "Meiryo UI"
        .Font.Size = 9
        .VerticalAlignment = xlCenter
        .WrapText = True
    End With
    ThemeApplyCompleteBorders rng, "border"
End Sub

Public Sub AutoFitSheetSmart(ByVal ws As Worksheet, ByVal rangeText As String, Optional ByVal minWidth As Double = 6, Optional ByVal maxWidth As Double = 34)
    Dim rng As Range, c As Range
    On Error Resume Next
    Set rng = ws.Range(rangeText)
    If rng Is Nothing Then Exit Sub
    rng.EntireColumn.AutoFit
    For Each c In rng.Columns
        If c.ColumnWidth < minWidth Then c.ColumnWidth = minWidth
        If c.ColumnWidth > maxWidth Then c.ColumnWidth = maxWidth
    Next c
    rng.EntireRow.AutoFit
    On Error GoTo 0
End Sub


Public Function ColumnLetter(ByVal colNo As Long) As String
    If colNo <= 0 Then
        ColumnLetter = "A"
    Else
        ColumnLetter = Split(Cells(1, colNo).Address(False, False), "1")(0)
    End If
End Function

Public Function BuildAnalysisStateKey(ByVal patternText As String, ByVal outIds As String, ByVal inIds As String) As String
    BuildAnalysisStateKey = SafeKey(patternText) & "|O:" & SafeKey(outIds) & "|I:" & SafeKey(inIds)
End Function

Public Function CombinePath(ByVal folderPath As String, ByVal fileName As String) As String
    CombinePath = RuntimeCombinePath(folderPath, fileName)
End Function

Public Function CommonDataPath() As String
    Dim fileName As String
    fileName = CellText(GetSheet(SH_MAIN).Cells(ROW_COMMON_FILE, COL_VALUE).Value)
    If Len(fileName) = 0 Then fileName = COMMON_DATA_FILE
    CommonDataPath = CombinePath(ThisWorkbook.Path, fileName)
End Function

Public Function RequireSavedWorkbook() As Boolean
    If Len(ThisWorkbook.Path) = 0 Then
        MsgBox "��ɂ��̕��̓c�[�����Č��t�H���_�֕ۑ����Ă��������B" & vbCrLf & _
               "�����t�H���_���� 00_���ʃf�[�^.xlsx ��ǂݏ������܂��B", vbExclamation
        RequireSavedWorkbook = False
    Else
        RequireSavedWorkbook = True
    End If
End Function

Public Function GetSettingDouble(ByVal rowNo As Long, ByVal defaultValue As Double) As Double
    GetSettingDouble = NzDbl(GetSheet(SH_MAIN).Cells(rowNo, COL_VALUE).Value, defaultValue)
End Function

Public Function GetSettingLong(ByVal rowNo As Long, ByVal defaultValue As Long) As Long
    GetSettingLong = NzLong(GetSheet(SH_MAIN).Cells(rowNo, COL_VALUE).Value, defaultValue)
End Function

Public Function SettingYes(ByVal rowNo As Long, Optional ByVal defaultYes As Boolean = True) As Boolean
    Dim s As String
    s = CellText(GetSheet(SH_MAIN).Cells(rowNo, COL_VALUE).Value)
    If Len(s) = 0 Then
        SettingYes = defaultYes
    Else
        SettingYes = (s = "����" Or s = "�͂�" Or s = "Yes" Or s = "TRUE" Or s = "1")
    End If
End Function

Public Sub AppendLog(ByVal actionText As String, ByVal resultText As String, ByVal detailText As String)
    Dim ws As Worksheet, r As Long
    Set ws = GetOrCreateSheet(SH_LOG, False)
    If Len(CellText(ws.Range("A1").Value)) = 0 Then
        SetRowValues ws.Range("A1"), Array("����", "����", "����", "���e")
        FormatHeader ws.Range("A1:D1")
        ws.Columns("A:A").NumberFormatLocal = "yyyy/m/d h:mm"
    End If
    r = LastRow(ws, 1) + 1
    ws.Cells(r, 1).Value = Now
    ws.Cells(r, 2).Value = actionText
    ws.Cells(r, 3).Value = resultText
    ws.Cells(r, 4).Value = detailText
End Sub

Public Sub ProtectSheetLight(ByVal ws As Worksheet)
    On Error Resume Next
    ThemePrepareSheetForProtection ws
    ws.Protect Password:=TOOL_PASSWORD, UserInterfaceOnly:=True, DrawingObjects:=True, Contents:=True, Scenarios:=True, AllowFiltering:=True, AllowSorting:=True
    ws.EnableSelection = xlUnlockedCells
    On Error GoTo 0
End Sub

Public Sub UnprotectSheetLight(ByVal ws As Worksheet)
    On Error Resume Next
    ws.Unprotect Password:=TOOL_PASSWORD
    ws.EnableSelection = xlNoRestrictions
    On Error GoTo 0
End Sub

Public Function SafeKey(ByVal s As String) As String
    SafeKey = Replace(Replace(s, " ", ""), "�@", "")
End Function

Public Function BuildPairKey(ByVal a As String, ByVal b As String) As String
    If a <= b Then
        BuildPairKey = a & "|" & b
    Else
        BuildPairKey = b & "|" & a
    End If
End Function


Public Function IsExcludeDecision(ByVal decisionText As String) As Boolean
    decisionText = CellText(decisionText)
    IsExcludeDecision = (decisionText = DECISION_EXCLUDE Or decisionText = DECISION_TX_EXCLUDE Or decisionText = DECISION_EXCLUDE_OLD)
End Function

Public Function IsTxExcludeDecision(ByVal decisionText As String) As Boolean
    decisionText = CellText(decisionText)
    IsTxExcludeDecision = (decisionText = DECISION_TX_EXCLUDE)
End Function

Public Function NormalizeDecisionText(ByVal decisionText As String) As String
    decisionText = CellText(decisionText)
    If decisionText = DECISION_EXCLUDE_OLD Then
        NormalizeDecisionText = DECISION_EXCLUDE
    ElseIf decisionText = DECISION_TX_EXCLUDE Then
        NormalizeDecisionText = DECISION_TX_EXCLUDE
    ElseIf decisionText = DECISION_EXCLUDE Then
        NormalizeDecisionText = DECISION_EXCLUDE
    Else
        NormalizeDecisionText = DECISION_USE
    End If
End Function


Public Function JoinNonBlank(ByVal leftText As String, ByVal rightText As String, Optional ByVal sep As String = " / ") As String
    leftText = Trim$(CStr(leftText))
    rightText = Trim$(CStr(rightText))
    If Len(leftText) = 0 Then
        JoinNonBlank = rightText
    ElseIf Len(rightText) = 0 Then
        JoinNonBlank = leftText
    Else
        JoinNonBlank = leftText & sep & rightText
    End If
End Function

Public Function ClipText(ByVal s As String, ByVal maxLen As Long) As String
    s = Trim$(CStr(s))
    If maxLen <= 0 Or Len(s) <= maxLen Then
        ClipText = s
    Else
        ClipText = Left$(s, maxLen - 1) & "�c"
    End If
End Function

Public Function DateDiffAbsDays(ByVal d1 As Variant, ByVal d2 As Variant) As Long
    If IsDate(d1) And IsDate(d2) Then DateDiffAbsDays = Abs(CLng(CDate(d1)) - CLng(CDate(d2)))
End Function

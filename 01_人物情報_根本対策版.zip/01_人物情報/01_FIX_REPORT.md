# 01 人物情報 根本原因修正版 修正レポート

## 対象

- 対象ツール: 01 人物情報
- 変更対象外: 02 資金操作表、03 資金移動分析、04 伝票依頼表

## 実機報告から切り分けた問題

実機では以下が報告された。

- 一括インポートができない
- 手動インポート後も相続関係図の作成に失敗する
- 相続関係図の描画を一部スキップ: row=7 / depth=3 / アプリケーション定義またはオブジェクト定義のエラー
- 相続関係図の作成中に停止: 工程=未接続人物確認 / オブジェクトは、このプロパティまたはメソッドをサポートしていません
- 資料出力で https が見つからない旨のエラー
- 環境: Windows 11 / Office 365

## 根本原因候補

### 1. 手動インポートによる旧モジュール残存

VBEで既存の標準モジュールを削除せずに `.bas` を手動インポートすると、Excelは同名モジュールを上書きせず、`modOutputs1` のような数字付きモジュールとして追加することがある。

この場合、ボタンや既存のマクロ参照は古い `modOutputs` 側を呼び続けるため、修正版を取り込んだつもりでも古い相続関係図コードが実行される。

そのため、今回の一括インポートは「旧非ドキュメントモジュールを先に削除する」処理を強化した。

### 2. 相続関係図の TextFrame2 依存

相続関係図のカード、未接続人物ラベル、その他関係人ボックスで `TextFrame2` 系プロパティを直接扱うと、環境や図形種類により 438 エラーが出る。

今回、相続関係図本体の `modOutputs.bas` から `TextFrame2` 実行時依存を除去した。

さらに横断検索で、ボタン装飾側 `modVisualTheme.bas` にも `TextFrame2` 依存が残っていたため、こちらも旧 `TextFrame` 中心の描画に変更した。

### 3. 深い子孫ブロックの描画継続性不足

`row=7/depth=3` は、孫・曽孫・玄孫などの深い世代の描画中に、幅計算、配偶者取得、子取得、親子線描画、子ブロック描画のどこかで図形座標エラーが出たことを示す。

今回、深い子孫ブロックについて以下を局所復旧化した。

- ブロック幅計算に失敗しても既定カード幅で継続
- 配偶者取得に失敗しても本人カードだけ描画
- 子一覧取得に失敗しても本人ブロックは残す
- 子単位の描画に失敗しても他の兄弟姉妹ブロックは継続
- 失敗内容はチェックシートへ警告として残す

### 4. SharePoint / OneDrive の https パスをローカルパス扱いしていた

Office 365でSharePoint/OneDrive上のブックをURLとして開くと、`ThisWorkbook.Path` が `https://...` になることがある。

これを `Dir` / `MkDir` / `Name` / `SaveAs` のローカルファイル処理に渡すと、「https が見つからない」系のエラーになる。

今回、資料出力と共通データ保存は、`ThisWorkbook.Path` が `http://` / `https://` / `sharepoint:` の場合、ローカル保存先フォルダを選択させる構造に変更した。

## 修正内容

### modOutputs.bas

- 相続関係図の文字描画を旧 `TextFrame` 中心に統一
- `modOutputs.bas` 内の `TextFrame2` 実行時依存を全廃
- `DrawRemainingVisiblePersons` を局所エラー処理化
- 未接続人物ラベル作成失敗で図全体を停止しないよう修正
- 未接続人物カード作成失敗で他カードを巻き込まないよう修正
- 深い子孫ブロックの幅計算、配偶者取得、子取得、子単位描画を局所復旧化
- `SaveCommonData` の出力先をローカル保存先解決経由に変更
- `ExportPersonInfoWorkbook` の出力先をローカル保存先解決経由に変更

### modVisualTheme.bas

- ボタン文字描画も旧 `TextFrame` 中心に統一
- `TextFrame2` 実行時依存を除去

### modUtilities.bas / modRuntimeGuard.bas

- `RuntimeIsWebPath` を追加
- `RuntimePickLocalFolder` を追加
- `EnsureWorkbookLocalBaseFolder` を追加
- `EnsureOutputFolder` をSharePoint/OneDrive URL非依存に変更

### 一括インポート

- `IMPORT_01_MODULES.vbs` を再構成
- 取込前に非ドキュメントVBAコンポーネントを削除
- `ThisWorkbook` とシートモジュールは削除しない
- まず `VBComponents.Import` を試行
- 失敗時は `ADODB.Stream` + `shift_jis` + `CodeModule.InsertLines` へフォールバック
- `Stage` / `ErrNumber` / `Description` / `Source` / `Target` / `Backup` を表示
- `IMPORT_OK` / `IMPORT_PARTIAL` / `IMPORT_FAILED` で結果を明確化

## 静的チェック

以下を確認済み。

- CP932デコードエラーなし
- Option Explicit不足なし
- Sub / Function / Property 開始終了不一致なし
- Public重複なし
- OnAction / AddButton / OnKey 未定義候補なし
- IIf残存なし
- 成功通知MsgBox候補なし
- `modOutputs.bas` の `TextFrame2` 実行時依存なし
- 全モジュールの `TextFrame2` 実行時依存なし
- BAT ASCII
- VBS UTF-16LE BOM
- VBS本文ASCII
- VBS `ADODB.Stream` + `shift_jis` 読込
- VBS `VBComponents.Import` + `CodeModule.InsertLines` フォールバック
- IMPORT_ORDER不足・余剰なし
- ZIP再展開テストOK

## 未実施

この環境では以下は未実施。

- Windows実機での一括インポート実行
- 実機ExcelでのVBEコンパイル
- 実Excel操作
- 印刷プレビュー
- 実データ通し検証

完成扱いにはしない。

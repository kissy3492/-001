# 変更差分 2026-07-07

## 変更ファイル

- `01_person_v8/modOutputs.bas`
- `01_person_v8/modRuntimeGuard.bas`
- `02_cash_v10/modExternalCashOperationImport.bas`
- `02_cash_v10/modFinanceLinkage.bas`
- `02_cash_v10/modRuntimeGuard.bas`
- `03_analysis_v11/modAnalysisOutput.bas`
- `03_analysis_v11/modDataLoad.bas`
- `03_analysis_v11/modRuntimeGuard.bas`
- `03_analysis_v11/modSetup.bas`
- `04_voucher_v5/modCommonData.bas`
- `04_voucher_v5/modExport.bas`
- `04_voucher_v5/modRuntimeGuard.bas`

## 01 人物情報

- 時系列の死亡イベントの表示内容を `没` に変更。
- 相続関係図用に `DiagramBaseRelationLabel` を追加。
  - 末尾注記 `（前配偶者との子）` 等は図ロジックでは基底続柄として扱う。
  - ただし `孫の配偶者の子` のような世代推定に必要な文字列は潰さない。
- `NormalizeDiagramRelationText`、`IsDirectChildRelationText`、`CardFillColor` を修正。
  - 注記付き直系子が孤立ブロックへ落ちるリスクを低減。
  - 直系・孫・ひ孫・玄孫の色分け判定も正規化後の続柄で行う。

## 02 資金操作表

- `NormalizePersonLookupText` を強化。
  - 全角/半角、空白、タブ、中点、敬称、代表的異体字を正規化。
  - 現在姓＋名、旧姓＋名、表示名、外部表の表記揺れに強くした。
- `NormalizeExternalText` を同じ方針で強化。
- `PersonCandidateOptionsText` を追加。
  - 一意に決まらない人物名について、候補人物ID・候補名・続柄・人物区分を一覧化。
- 外部表取込時、人物IDが一意に決まらない場合は誤紐づけせずスキップし、`C_チェック` に候補を出すように変更。
- 既存の自然キー重複スキップ処理は維持。

## 03 資金移動分析

- 共通データ読込エラー時の `C_チェック` 出力を強化。
  - ファイルパス、ファイル存在、シート一覧、必須シート、`T_取引` 必須列、01→02→03 の保存順を明示。
- メイン画面の説明を「通常見るのは `資金操作表_分析済` と `フラグ抽出` の2画面」に合わせて修正。
- `調査論点サマリ` 参照が通常操作の案内に出ないよう、ステータス文言を修正。
- L35のボタンを `2画面表示` / `ShowOutputSheets` に変更。

## 04 伝票依頼表

- 共通データ読込エラー時の `C_チェック` 出力を強化。
  - 03で共通保存が必要か、`T_伝票依頼候補` がないか、必須列がないかを切り分ける文言を追加。
- `UpdateMainStatus` の共通データ有無判定を、`Dir` と `IIf` の組み合わせから順序明示の判定へ変更。
- 出力設定表の `前後日数` を常に `1` と記録。
  - 処理本体は既に前1銀行営業日・翌1銀行営業日に限定されているため、表示側の混乱をなくした。

## 共通ランタイム

- 4ツールの `modRuntimeGuard.bas` を修正。
  - 保存失敗時のロールバックで、VBAの `And` 非短絡評価により不要な `Dir$` が走らないよう、条件をネスト化。

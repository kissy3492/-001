Attribute VB_Name = "modVoucherBuild"

Option Explicit

Public Sub BuildVoucherSheets()

    BuildVoucherSheetsCore True, False

End Sub

Public Sub EnsureVoucherBuildFreshForExport(ByVal actionName As String)

    If Not BuildVoucherSheetsCore(False, True) Then Err.Raise vbObjectError + 8842, "EnsureVoucherBuildFreshForExport", "�˗��\�쐬�Ɏ��s���܂����B"
    WriteLog actionName & "�O�Ɉ˗����E�T�����ׂ��ŐV��"

End Sub

Public Function BuildVoucherSheetsCore(Optional ByVal showMessage As Boolean = True, _
        Optional ByVal raiseOnError As Boolean = False) As Boolean

    Dim errNum As Long, errDesc As String, errSrc As String
    Dim stepText As String

    On Error GoTo EH

    stepText = "�����J�n"
    AppBegin IIf(showMessage, "�`�[�˗��\���쐬��...", "�`�[�˗��\�̑O��f�[�^���쐬��...")

    stepText = "���f�[�^�m�F"
    If LastRow(Ws(SH_W_CAND), 1) <= 1 Then Err.Raise vbObjectError + 401, , "�`�[�˗���₪����܂���B���03�����ړ����͂ŋ��ʃf�[�^�ۑ����A04�ŋ��ʃf�[�^�Ǎ������s���Ă��������B"

    stepText = "�˗���I�𔽉f"
    SyncDestinationTargetsFromList

    stepText = "�˗���}�X�^�č\�z"
    BuildDestinationMaster

    stepText = "�j���E��s�c�Ɠ��m�F"
    If IsSettingYes("�O���s�c�Ɠ����܂߂�", True) Then
        If Not EnsureHolidayCoverageForVoucherDates(False, False) Then
            Err.Raise vbObjectError + 402, , "�j���f�[�^�������擾�ł��܂���ł����B" & vbCrLf & MissingHolidayCoverageMessage()
        End If
    End If

    stepText = "�˗����č\�z"
    BuildRequestDates

    stepText = "�T�����׍č\�z"
    BuildControlDetails

    stepText = "�˗��p�E�T���p�R�ꌟ��"
    AssertVoucherCoverageComplete

    stepText = "03��04�p�C�v���C����������"
    AssertVoucherPipelineIntegrity

    stepText = "�˗���ʃV�[�g�`��"
    RenderDestinationSetSheets

    stepText = "�˗���ꗗ�X�V"
    RefreshDestinationList

    stepText = "�˗��p�v���r���[�X�V"
    RenderRequestPreview

    stepText = "�T���p�v���r���[�X�V"
    RenderControlPreview

    stepText = "�쐬���ʕ\��"
    If showMessage Then ShowAfterBuild

    stepText = "�o�̓V�[�g�ی�"
    ProtectOutputSheets

    stepText = "��ԕ\���X�V"
    UpdateMainStatus

    stepText = "�쐬�����f�f�L�^"
    WriteVoucherBuildSuccessTrace

    Ws(SH_MAIN).Range("C14").Value = Format$(Now, "yyyy/m/d h:mm")
    WriteLog "�˗��\�쐬����"

    AppEnd ""
    BuildVoucherSheetsCore = True
    If showMessage Then NotifyInfo "�˗��\���쐬���܂����B�ŏI�o�͂֐i�߂܂��B"
    Exit Function

EH:
    errNum = Err.Number
    errDesc = Err.Description
    errSrc = Err.Source
    AppEnd ""
    WriteVoucherBuildFailureCheck stepText, errNum, errDesc, errSrc
    If raiseOnError Then
        Err.Raise errNum, "BuildVoucherSheetsCore - " & stepText, errDesc
    Else
        RuntimeShowErrorValues "BuildVoucherSheets", "�˗��\�쐬 - " & stepText, "C_�`�F�b�N�ɒ�~�H���E����ԁE�����������o���܂����B�j���s�����̓g�b�v��ʂ́w�j��CSV�捞�x����蓮�捞�ł��܂��B", "", errNum, errDesc, errSrc
    End If

End Function

Private Sub WriteVoucherBuildFailureCheck(ByVal stepText As String, ByVal errNum As Long, ByVal errDesc As String, ByVal errSrc As String)
    Dim sh As Worksheet, r As Long
    Dim candCountText As String
    On Error Resume Next
    Set sh = Ws(SH_CHECK)
    If sh Is Nothing Then Exit Sub
    sh.Visible = xlSheetVisible
    ClearSheetSafe sh
    sh.Range("A1:D1").Value = Array("�敪", "���e", "�Ώ�", "�Ή�")
    With sh.Range("A1:D1")
        .Interior.Color = C_NAVY
        .Font.Color = vbWhite
        .Font.Bold = True
    End With
    r = 2
    sh.Cells(r, 1).Value = "�G���["
    sh.Cells(r, 2).Value = "�˗��\�쐬�Ɏ��s���܂����B�H��: " & stepText
    sh.Cells(r, 3).Value = "Err " & CStr(errNum) & " / " & errSrc
    sh.Cells(r, 4).Value = errDesc
    sh.Rows(r).Interior.Color = C_LIGHT_RED
    r = r + 1
    If SheetExists(SH_W_CAND) Then
        candCountText = CStr(Application.Max(0, LastRow(Ws(SH_W_CAND), 1) - 1))
    Else
        candCountText = "���V�[�g�Ȃ�"
    End If
    sh.Cells(r, 1).Value = "�m�F"
    sh.Cells(r, 2).Value = "��⌏��"
    sh.Cells(r, 3).Value = candCountText
    sh.Cells(r, 4).Value = "03�����ړ����͂œ`�[�˗�=�v�̌������ʕۑ����A04�ŋ��ʃf�[�^�Ǎ����Ď��s���Ă��������B"
    r = r + 1
    sh.Cells(r, 1).Value = "�m�F"
    sh.Cells(r, 2).Value = "��������"
    sh.Cells(r, 3).Value = "03�����ʕۑ���04�Ǎ����˗��\�쐬"
    sh.Cells(r, 4).Value = "��₪�Ȃ��ꍇ��03�̎�������\_���͍�/�t���O���o�œ`�[�˗������m�F���Ă��������B"
    sh.Range("A1:D" & r).WrapText = True
    sh.Columns("A:D").AutoFit
    CapColumns sh, 1, 4, 55
    sh.Activate
    On Error GoTo 0
End Sub

Public Sub SyncDestinationTargetsFromList()

    If Not SheetExists(SH_DEST_LIST) Then Exit Sub

    Dim list As Worksheet, dest As Worksheet, d As Object, r As Long, lr As Long, key As String

    Set list = Ws(SH_DEST_LIST)

    Set dest = Ws(SH_W_DEST)

    Set d = CreateObject("Scripting.Dictionary")

    lr = LastRow(list, 1)

    For r = 5 To lr

        If Len(Nz(list.Cells(r, 1).Value)) > 0 Then d(Nz(list.Cells(r, 1).Value)) = Nz(list.Cells(r, 6).Value, "�쐬")

    Next r

    lr = LastRow(dest, DS_ID)

    For r = 2 To lr

        key = Nz(dest.Cells(r, DS_ID).Value)

        If d.Exists(key) Then dest.Cells(r, DS_TARGET).Value = d(key)

    Next r

End Sub

Private Sub BuildRequestDates()

    Dim out As Worksheet, cand As Worksheet, dest As Worksheet

    Set out = Ws(SH_W_DATES)

    Set cand = Ws(SH_W_CAND)

    Set dest = Ws(SH_W_DEST)

    ClearRows out

    If IsSettingYes("�O���s�c�Ɠ����܂߂�", True) Then EnsureHolidayCacheLoaded

    Dim destRows As Object, r As Long, lr As Long, key As String

    Set destRows = CreateObject("Scripting.Dictionary")

    For r = 2 To LastRow(dest, DS_ID)

        If Nz(dest.Cells(r, DS_TARGET).Value) = "�쐬" Then destRows(dest.Cells(r, DS_KEY).Value) = r

        dest.Cells(r, DS_REQUEST_DATE_COUNT).Value = 0

    Next r

    Dim dateSet As Object

    Set dateSet = CreateObject("Scripting.Dictionary")

    Dim outR As Long

    outR = 2

    lr = LastRow(cand, VC_ID)

    For r = 2 To lr

        If Nz(cand.Cells(r, VC_TARGET).Value) = "�v" And IsDate(cand.Cells(r, VC_TX_DATE).Value) Then

            key = Nz(cand.Cells(r, VC_DEST_KEY).Value)

            If destRows.Exists(key) Then

                AddRequestDate out, dateSet, outR, dest, destRows(key), cand, r, CDate(cand.Cells(r, VC_TX_DATE).Value), "����"

                If IsSettingYes("�O���s�c�Ɠ����܂߂�", True) Then

                    AddBeforeAfterDates out, dateSet, outR, dest, destRows(key), cand, r, CDate(cand.Cells(r, VC_TX_DATE).Value)

                End If

            End If

        End If

    Next r

    If outR > 2 Then SortRequestDates out

    UpdateRequestDateCounts

End Sub

Private Sub AddBeforeAfterDates(ByVal out As Worksheet, _
        ByVal dateSet As Object, _
        ByRef outR As Long, _
        ByVal dest As Worksheet, _
        ByVal destRow As Long, _
        ByVal cand As Worksheet, _
        ByVal candRow As Long, _
        ByVal txDate As Date)

    Dim mode As String, n As Long, i As Long, prevD As Date, nextD As Date

    mode = "��s�c�Ɠ�" ' v4: �O������܂߂�ꍇ�͏�ɋ�s�c�Ɠ��œW�J����B

    n = RequestBeforeAfterBusinessDayCount()

    prevD = txDate

    nextD = txDate

    For i = 1 To n

        prevD = PreviousBankBusinessDay(prevD)

        nextD = NextBankBusinessDay(nextD)

        AddRequestDate out, dateSet, outR, dest, destRow, cand, candRow, prevD, "�O��"

        AddRequestDate out, dateSet, outR, dest, destRow, cand, candRow, nextD, "����"

    Next i

End Sub

Private Function RequestBeforeAfterBusinessDayCount() As Long

    ' �v���Œ�: �O����͗���O��ł͂Ȃ��A��������̑O1��s�c�Ɠ��E��1��s�c�Ɠ�������ǉ�����B

    If IsSettingYes("�O���s�c�Ɠ����܂߂�", True) Then

        RequestBeforeAfterBusinessDayCount = 1

    Else

        RequestBeforeAfterBusinessDayCount = 0

    End If

End Function

Private Sub AddRequestDate(ByVal out As Worksheet, _
        ByVal dateSet As Object, _
        ByRef outR As Long, _
        ByVal dest As Worksheet, _
        ByVal destRow As Long, _
        ByVal cand As Worksheet, _
        ByVal candRow As Long, _
        ByVal reqDate As Date, _
        ByVal kind As String)

    ' �O���E�����́A�ݒ�Łu�O���s�c�Ɠ����܂߂�=����v�̏ꍇ�����ǉ������B�ǉ�������͕K����s�c�Ɠ��Ɍ��肷��B

    If kind <> "����" Then

        If Not IsBankBusinessDay(reqDate) Then Exit Sub

    End If

    Dim uniq As String

    uniq = dest.Cells(destRow, DS_ID).Value & "|" & CLng(DateValue(reqDate))

    If dateSet.Exists(uniq) Then

        Dim rowIndex As Long

        rowIndex = dateSet(uniq)

        If Not SourceIdAlreadyLinked(out.Cells(rowIndex, RD_SOURCE_IDS).Value, cand.Cells(candRow, VC_ID).Value) Then
            out.Cells(rowIndex, RD_SOURCE_IDS).Value = JoinNonEmpty(out.Cells(rowIndex, RD_SOURCE_IDS).Value, cand.Cells(candRow, VC_ID).Value, ",")
            out.Cells(rowIndex, RD_SOURCE_COUNT).Value = NzDbl(out.Cells(rowIndex, RD_SOURCE_COUNT).Value) + 1
        End If

        Exit Sub

    End If

    dateSet.Add uniq, outR

    out.Cells(outR, RD_ID).Value = "VDT" & Format$(outR - 1, "000000")

    out.Cells(outR, RD_DEST_ID).Value = dest.Cells(destRow, DS_ID).Value

    out.Cells(outR, RD_DEST_KEY).Value = dest.Cells(destRow, DS_KEY).Value

    out.Cells(outR, RD_BANK).Value = dest.Cells(destRow, DS_BANK).Value

    out.Cells(outR, RD_SHOP).Value = dest.Cells(destRow, DS_SHOP).Value

    out.Cells(outR, RD_SOURCE_DATE).Value = cand.Cells(candRow, VC_TX_DATE).Value

    out.Cells(outR, RD_REQUEST_DATE).Value = reqDate

    out.Cells(outR, RD_DATE_KIND).Value = kind

    out.Cells(outR, RD_WEEKDAY).Value = WeekdayNameJP(Weekday(reqDate, vbSunday))

    out.Cells(outR, RD_HOLIDAY).Value = BankHolidayName(reqDate)

    out.Cells(outR, RD_SOURCE_COUNT).Value = 1

    out.Cells(outR, RD_SOURCE_IDS).Value = cand.Cells(candRow, VC_ID).Value

    outR = outR + 1

End Sub

Private Function SourceIdAlreadyLinked(ByVal listText As String, ByVal sourceId As String) As Boolean
    Dim arr As Variant, i As Long
    sourceId = Trim$(CStr(sourceId))
    If Len(sourceId) = 0 Then Exit Function
    arr = Split(CStr(listText), ",")
    For i = LBound(arr) To UBound(arr)
        If Trim$(CStr(arr(i))) = sourceId Then
            SourceIdAlreadyLinked = True
            Exit Function
        End If
    Next i
End Function

Private Sub SortRequestDates(ByVal sh As Worksheet)

    Dim lr As Long

    lr = LastRow(sh, RD_ID)

    With sh.Sort

        .SortFields.Clear

        .SortFields.Add Key:=sh.Range(sh.Cells(2, RD_DEST_ID), sh.Cells(lr, RD_DEST_ID)), SortOn:=xlSortOnValues, Order:=xlAscending

        .SortFields.Add Key:=sh.Range(sh.Cells(2, RD_REQUEST_DATE), sh.Cells(lr, RD_REQUEST_DATE)), SortOn:=xlSortOnValues, Order:=xlAscending

        .SetRange sh.Range(sh.Cells(1, 1), sh.Cells(lr, RD_COLS))

        .Header = xlYes

        .Apply

    End With

End Sub

Private Sub UpdateRequestDateCounts()

    Dim dates As Worksheet, dest As Worksheet, r As Long, lr As Long, d As Object, key As String

    Set dates = Ws(SH_W_DATES)

    Set dest = Ws(SH_W_DEST)

    Set d = CreateObject("Scripting.Dictionary")

    For r = 2 To LastRow(dest, DS_ID)

        d(dest.Cells(r, DS_ID).Value) = r

        dest.Cells(r, DS_REQUEST_DATE_COUNT).Value = 0

    Next r

    lr = LastRow(dates, RD_ID)

    For r = 2 To lr

        key = dates.Cells(r, RD_DEST_ID).Value

        If d.Exists(key) Then dest.Cells(d(key), DS_REQUEST_DATE_COUNT).Value = NzDbl(dest.Cells(d(key), DS_REQUEST_DATE_COUNT).Value) + 1

    Next r

End Sub

Private Sub BuildControlDetails()

    Dim out As Worksheet, cand As Worksheet, dest As Worksheet, d As Object, r As Long, lr As Long, outR As Long, key As String

    Set out = Ws(SH_W_CONTROL)

    Set cand = Ws(SH_W_CAND)

    Set dest = Ws(SH_W_DEST)

    ClearRows out

    Set d = CreateObject("Scripting.Dictionary")

    For r = 2 To LastRow(dest, DS_ID)

        If dest.Cells(r, DS_TARGET).Value = "�쐬" Then d(dest.Cells(r, DS_KEY).Value) = dest.Cells(r, DS_ID).Value

    Next r

    Dim countByDate As Object

    Set countByDate = CreateObject("Scripting.Dictionary")

    lr = LastRow(cand, VC_ID)

    For r = 2 To lr

        If cand.Cells(r, VC_TARGET).Value = "�v" Then

            key = cand.Cells(r, VC_DEST_KEY).Value

            If d.Exists(key) And IsDate(cand.Cells(r, VC_TX_DATE).Value) Then

                countByDate(key & "|" & CLng(CDate(cand.Cells(r, VC_TX_DATE).Value))) = NzDbl(countByDate(key & "|" & CLng(CDate(cand.Cells(r, VC_TX_DATE).Value)))) + 1

            End If

        End If

    Next r

    outR = 2

    For r = 2 To lr

        If cand.Cells(r, VC_TARGET).Value = "�v" Then

            key = cand.Cells(r, VC_DEST_KEY).Value

            If d.Exists(key) Then

                out.Cells(outR, CD_DEST_ID).Value = d(key)

                out.Cells(outR, CD_DEST_KEY).Value = key

                out.Cells(outR, CD_BANK).Value = cand.Cells(r, VC_BANK).Value

                out.Cells(outR, CD_SHOP).Value = cand.Cells(r, VC_SHOP).Value

                out.Cells(outR, CD_TX_DATE).Value = cand.Cells(r, VC_TX_DATE).Value

                If IsDate(cand.Cells(r, VC_TX_DATE).Value) Then out.Cells(outR, CD_DATE_COUNT).Value = countByDate(key & "|" & CLng(CDate(cand.Cells(r, VC_TX_DATE).Value)))

                out.Cells(outR, CD_ANALYSIS_ID).Value = cand.Cells(r, VC_ANALYSIS_ID).Value

                out.Cells(outR, CD_TX_ID).Value = cand.Cells(r, VC_TX_ID).Value

                out.Cells(outR, CD_KIND).Value = cand.Cells(r, VC_KIND).Value

                out.Cells(outR, CD_PERSON).Value = cand.Cells(r, VC_PERSON_NAME).Value

                out.Cells(outR, CD_RELATION).Value = cand.Cells(r, VC_RELATION).Value

                out.Cells(outR, CD_OUT).Value = cand.Cells(r, VC_OUT).Value

                out.Cells(outR, CD_IN).Value = cand.Cells(r, VC_IN).Value

                out.Cells(outR, CD_SUMMARY).Value = cand.Cells(r, VC_SUMMARY).Value

                out.Cells(outR, CD_MEMO).Value = cand.Cells(r, VC_MEMO).Value

                outR = outR + 1

            End If

        End If

    Next r

    If outR > 2 Then SortControlDetails out

End Sub

Private Sub SortControlDetails(ByVal sh As Worksheet)

    Dim lr As Long

    lr = LastRow(sh, CD_DEST_ID)

    With sh.Sort

        .SortFields.Clear

        .SortFields.Add Key:=sh.Range(sh.Cells(2, CD_DEST_ID), sh.Cells(lr, CD_DEST_ID)), Order:=xlAscending

        .SortFields.Add Key:=sh.Range(sh.Cells(2, CD_TX_DATE), sh.Cells(lr, CD_TX_DATE)), Order:=xlAscending

        .SetRange sh.Range(sh.Cells(1, 1), sh.Cells(lr, CD_COLS))

        .Header = xlYes

        .Apply

    End With

End Sub

Private Sub ClearRows(ByVal sh As Worksheet)

    Dim lr As Long

    lr = LastRow(sh, 1)

    If lr >= 2 Then sh.Range(sh.Rows(2), sh.Rows(lr)).ClearContents

End Sub


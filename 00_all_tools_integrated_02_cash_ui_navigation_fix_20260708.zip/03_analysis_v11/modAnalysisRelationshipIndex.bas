Attribute VB_Name = "modAnalysisRelationshipIndex"
Option Explicit

'�l���Ԃ̊֌W�y�A�������A�����modAnalysisEngine���番������B
'W_�֌W����ɓǂ݁AW_���������ɑ���l��ID������ꍇ�����͏�̋ߐڐl���Ƃ��Ĉ����B
Public Function BuildAnalysisRelationPairIndex() As Object
    Dim dict As Object, ws As Worksheet, lastR As Long, r As Long
    Dim colBase As Long, colOther As Long, colStatus As Long
    Dim baseId As String, otherId As String, statusText As String

    Set dict = CreateObject("Scripting.Dictionary")

    If SheetExists(SH_WORK_REL) Then
        Set ws = GetSheet(SH_WORK_REL)
        colBase = FirstHeaderColumn(ws, Array("��l��ID", "�l��ID_A", "�l��A", "�l��ID1"), 1)
        colOther = FirstHeaderColumn(ws, Array("����l��ID", "�l��ID_B", "�l��B", "�l��ID2"), 1)
        colStatus = FirstHeaderColumn(ws, Array("�f�[�^���"), 1)
        If colBase > 0 And colOther > 0 Then
            lastR = LastRow(ws, colBase)
            For r = 2 To lastR
                statusText = AnalysisIndexCell(ws, r, colStatus)
                If statusText <> "���" Then
                    baseId = AnalysisIndexCell(ws, r, colBase)
                    otherId = AnalysisIndexCell(ws, r, colOther)
                    AddAnalysisRelationPair dict, baseId, otherId
                End If
            Next r
        End If
    End If

    AddMarriageHistoryRelationPairs dict
    Set BuildAnalysisRelationPairIndex = dict
End Function

Private Sub AddAnalysisRelationPair(ByVal dict As Object, ByVal personId1 As String, ByVal personId2 As String)
    If dict Is Nothing Then Exit Sub
    personId1 = Trim$(personId1)
    personId2 = Trim$(personId2)
    If Len(personId1) = 0 Or Len(personId2) = 0 Then Exit Sub
    dict(AnalysisRelationPairKey(personId1, personId2)) = True
    dict(AnalysisRelationPairKey(personId2, personId1)) = True
End Sub

Private Function AnalysisRelationPairKey(ByVal personId1 As String, ByVal personId2 As String) As String
    AnalysisRelationPairKey = personId1 & "|" & personId2
End Function

Private Function AnalysisIndexCell(ByVal ws As Worksheet, ByVal r As Long, ByVal c As Long) As String
    If ws Is Nothing Or c <= 0 Then Exit Function
    AnalysisIndexCell = CellText(ws.Cells(r, c).Value)
End Function

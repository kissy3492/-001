Attribute VB_Name = "modAnalysisScoring"
Option Explicit

'���X�R�A�����O�𕪐͖{�̂���؂�o���B
'�V�[�g�E�O���[�o����ԁE��������𒼐ړǂ܂��A�G���W�������W�߂��v�f������_��������B

Public Function CalculateCandidateScore(ByVal amountDiff As Double, _
        ByVal amountTolerance As Double, ByVal effectiveTolerance As Double, _
        ByVal outDateMin As Variant, ByVal inDateMin As Variant, _
        ByVal dateWindowDays As Long, ByVal comboCount As Long, _
        ByVal sameAccount As Boolean, ByVal useContextScore As Boolean, _
        ByVal sameDayGapMinutes As Long, ByVal temporalFlowHint As String, _
        ByVal contextFlags As Object) As Long

    Dim score As Long, daysDiff As Long
    score = 55

    If amountDiff = 0 Then
        score = score + 22
    ElseIf Abs(amountDiff) <= amountTolerance Then
        score = score + 14
    ElseIf effectiveTolerance > 0 Then
        If Abs(amountDiff) <= effectiveTolerance Then score = score + 10
    End If

    If IsDate(outDateMin) And IsDate(inDateMin) Then
        daysDiff = DateOnlySerialForScore(inDateMin) - DateOnlySerialForScore(outDateMin)
        If daysDiff = 0 Then
            score = score + 16
            If sameDayGapMinutes >= 0 Then
                If sameDayGapMinutes <= 30 Then
                    score = score + 8
                ElseIf sameDayGapMinutes <= 120 Then
                    score = score + 6
                Else
                    score = score + 4
                End If
            ElseIf InStr(1, temporalFlowHint, "����������OK", vbTextCompare) > 0 Then
                score = score + 4
            ElseIf InStr(1, temporalFlowHint, "�����ꕔ�s��", vbTextCompare) > 0 Then
                score = score - 3
            End If
        ElseIf daysDiff = 1 Then
            score = score + 12
        ElseIf daysDiff > 1 And daysDiff <= dateWindowDays Then
            score = score + 6
        End If
    End If

    If comboCount > 2 Then score = score - Application.Min(12, (comboCount - 2) * 2)
    If sameAccount Then score = score - 10

    If useContextScore Then
        If FlagOn(contextFlags, "SameName") Then score = score + 4
        If FlagOn(contextFlags, "Cohabitation") Then score = score + 4
        If FlagOn(contextFlags, "SameAddress") Then score = score + 4
        If FlagOn(contextFlags, "InheritanceShift") Then score = score + 6
        If FlagOn(contextFlags, "SameShopOrBank") Then score = score + 3
        If FlagOn(contextFlags, "SummaryKeywordFlow") Then score = score + 2
        If FlagOn(contextFlags, "TimeCluster") Then score = score + 4
        If FlagOn(contextFlags, "YoungHighAmount") Then score = score + 3
        If FlagOn(contextFlags, "MoveAroundHighAmount") Then score = score + 4
        If FlagOn(contextFlags, "LifeEventAroundHighAmount") Then score = score + 3
        If FlagOn(contextFlags, "AccountOperationPattern") Then score = score + 3
        If FlagOn(contextFlags, "CentralizedManagement") Then score = score + 4
        If FlagOn(contextFlags, "GiftAddBack") Then score = score + 5
        If FlagOn(contextFlags, "PreInheritanceWithdrawal") Then score = score + 4
        If FlagOn(contextFlags, "BalanceSignal") Then score = score + 3
    End If

    CalculateCandidateScore = ClampScore(score)
End Function

Public Function CalculateUnknownFlagComboScore(ByVal amountDiff As Double, _
        ByVal amountsClose As Boolean, ByVal sameShopOrBank As Boolean, _
        ByVal hasSameAddress As Boolean, ByVal hasCohabitation As Boolean, _
        ByVal hasRiskSignal As Boolean, ByVal outCount As Long, ByVal inCount As Long) As Long

    Dim score As Long, n As Long
    score = 62
    If Abs(amountDiff) = 0 Then
        score = score + 24
    ElseIf amountsClose Then
        score = score + 16
    End If

    If sameShopOrBank Then score = score + 4
    If hasSameAddress Then score = score + 4
    If hasCohabitation Then score = score + 4
    If hasRiskSignal Then score = score + 5

    n = outCount + inCount
    If n > 4 Then score = score - Application.Min(14, (n - 4) * 2)
    If outCount > 1 And inCount > 1 Then score = score - 3

    CalculateUnknownFlagComboScore = ClampScore(score)
End Function

Private Function FlagOn(ByVal flags As Object, ByVal keyText As String) As Boolean
    If flags Is Nothing Then Exit Function
    If flags.Exists(keyText) Then FlagOn = CBool(flags(keyText))
End Function

Private Function DateOnlySerialForScore(ByVal v As Variant) As Long
    DateOnlySerialForScore = CLng(DateValue(CDate(v)))
End Function

Private Function ClampScore(ByVal score As Long) As Long
    If score > 100 Then score = 100
    If score < 0 Then score = 0
    ClampScore = score
End Function

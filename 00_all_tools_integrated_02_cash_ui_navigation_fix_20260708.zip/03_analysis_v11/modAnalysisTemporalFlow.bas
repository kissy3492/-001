Attribute VB_Name = "modAnalysisTemporalFlow"

Option Explicit

'�o���������̎��n�񐬗����A���������сA��������e�L�X�g���𕪐͖{�̂��番������B

Public Function IsTemporalFlowValid(ByVal outRecords As Collection, ByVal inRecords As Collection) As Boolean

    Dim outLatestDay As Long, inEarliestDay As Long

    Dim outLatestKnown As Double, inEarliestKnown As Double

    Dim hasOutKnown As Boolean, hasInKnown As Boolean

    IsTemporalFlowValid = True

    If outRecords Is Nothing Or inRecords Is Nothing Then Exit Function

    If outRecords.Count = 0 Or inRecords.Count = 0 Then Exit Function



    outLatestDay = LatestDateSerialInRecords(outRecords)

    inEarliestDay = EarliestDateSerialInRecords(inRecords)

    If outLatestDay = 0 Or inEarliestDay = 0 Then Exit Function



    ' �u�o���������v�����B���������o�������O�̌��͍��Ȃ��B

    If outLatestDay > inEarliestDay Then

        IsTemporalFlowValid = False

        Exit Function

    End If



    ' �����őo���Ɏ���������ꍇ�́A�ŐV�o������ <= �ő��������� ��K�{�ɂ���B

    If outLatestDay = inEarliestDay Then

        hasOutKnown = LatestKnownDateTimeOnDay(outRecords, outLatestDay, outLatestKnown)

        hasInKnown = EarliestKnownDateTimeOnDay(inRecords, inEarliestDay, inEarliestKnown)

        If hasOutKnown And hasInKnown Then

            If outLatestKnown > inEarliestKnown + 0.00000001 Then IsTemporalFlowValid = False

        End If

    End If

End Function



Public Function EarliestDateSerialInRecords(ByVal recs As Collection) As Long

    Dim rec As Object, d As Long

    For Each rec In recs

        d = AnalysisTemporalDateOnlySerial(rec("Date"))

        If d > 0 Then

            If EarliestDateSerialInRecords = 0 Or d < EarliestDateSerialInRecords Then EarliestDateSerialInRecords = d

        End If

    Next rec

End Function



Public Function LatestDateSerialInRecords(ByVal recs As Collection) As Long

    Dim rec As Object, d As Long

    For Each rec In recs

        d = AnalysisTemporalDateOnlySerial(rec("Date"))

        If d > 0 Then

            If LatestDateSerialInRecords = 0 Or d > LatestDateSerialInRecords Then LatestDateSerialInRecords = d

        End If

    Next rec

End Function



Public Function EarliestKnownDateTimeOnDay(ByVal recs As Collection, ByVal daySerial As Long, ByRef outValue As Double) As Boolean

    Dim rec As Object, v As Double

    For Each rec In recs

        If AnalysisTemporalDateOnlySerial(rec("Date")) = daySerial And CBool(rec("HasTime")) Then

            v = CDbl(daySerial) + CDbl(rec("TimeFraction"))

            If Not EarliestKnownDateTimeOnDay Or v < outValue Then outValue = v

            EarliestKnownDateTimeOnDay = True

        End If

    Next rec

End Function



Public Function LatestKnownDateTimeOnDay(ByVal recs As Collection, ByVal daySerial As Long, ByRef outValue As Double) As Boolean

    Dim rec As Object, v As Double

    For Each rec In recs

        If AnalysisTemporalDateOnlySerial(rec("Date")) = daySerial And CBool(rec("HasTime")) Then

            v = CDbl(daySerial) + CDbl(rec("TimeFraction"))

            If Not LatestKnownDateTimeOnDay Or v > outValue Then outValue = v

            LatestKnownDateTimeOnDay = True

        End If

    Next rec

End Function



Public Function TemporalFlowHintText(ByVal outRecords As Collection, ByVal inRecords As Collection) As String

    Dim outLatestDay As Long, inEarliestDay As Long

    Dim outKnown As Double, inKnown As Double, gapMinutes As Long

    If outRecords Is Nothing Or inRecords Is Nothing Then Exit Function

    If outRecords.Count = 0 Or inRecords.Count = 0 Then Exit Function

    outLatestDay = LatestDateSerialInRecords(outRecords)

    inEarliestDay = EarliestDateSerialInRecords(inRecords)

    If outLatestDay = 0 Or inEarliestDay = 0 Then Exit Function

    If outLatestDay < inEarliestDay Then

        TemporalFlowHintText = "���t��OK"

    ElseIf outLatestDay = inEarliestDay Then

        If LatestKnownDateTimeOnDay(outRecords, outLatestDay, outKnown) And EarliestKnownDateTimeOnDay(inRecords, inEarliestDay, inKnown) Then

            gapMinutes = CLng(Application.Max(0, Round((inKnown - outKnown) * 1440#, 0)))

            TemporalFlowHintText = "����������OK�i" & CStr(gapMinutes) & "����j"

        ElseIf HasAnyTime(outRecords) Or HasAnyTime(inRecords) Then

            TemporalFlowHintText = "�����E�����ꕔ�s��"

        Else

            TemporalFlowHintText = "�����E�����s��"

        End If

    End If

End Function



Public Function SameDayKnownTimeGapMinutes(ByVal outRecords As Collection, ByVal inRecords As Collection) As Long

    Dim outLatestDay As Long, inEarliestDay As Long

    Dim outKnown As Double, inKnown As Double

    SameDayKnownTimeGapMinutes = -1

    If outRecords Is Nothing Or inRecords Is Nothing Then Exit Function

    If outRecords.Count = 0 Or inRecords.Count = 0 Then Exit Function

    outLatestDay = LatestDateSerialInRecords(outRecords)

    inEarliestDay = EarliestDateSerialInRecords(inRecords)

    If outLatestDay = 0 Or outLatestDay <> inEarliestDay Then Exit Function

    If LatestKnownDateTimeOnDay(outRecords, outLatestDay, outKnown) And EarliestKnownDateTimeOnDay(inRecords, inEarliestDay, inKnown) Then

        If inKnown >= outKnown Then SameDayKnownTimeGapMinutes = CLng(Application.Max(0, Round((inKnown - outKnown) * 1440#, 0)))

    End If

End Function



Public Function HasAnyTime(ByVal recs As Collection) As Boolean

    Dim rec As Object

    For Each rec In recs

        If CBool(rec("HasTime")) Then HasAnyTime = True: Exit Function

    Next rec

End Function



Public Function RecordsDateTimeRangeText(ByVal recs As Collection) As String

    Dim rec As Object, minKey As Double, maxKey As Double, minText As String, maxText As String, k As Double

    If recs Is Nothing Then Exit Function

    If recs.Count = 0 Then Exit Function

    For Each rec In recs

        k = RecordDateTimeSortValue(rec)

        If minKey = 0 Or k < minKey Then

            minKey = k

            minText = RecordDateTimeText(rec)

        End If

        If maxKey = 0 Or k > maxKey Then

            maxKey = k

            maxText = RecordDateTimeText(rec)

        End If

    Next rec

    If minText = maxText Then

        RecordsDateTimeRangeText = minText

    Else

        RecordsDateTimeRangeText = minText & "�`" & maxText

    End If

End Function



Public Function RecordDateTimeSortValue(ByVal rec As Object) As Double

    If rec Is Nothing Then Exit Function

    If KeyExists(rec, "DateTimeSort") Then

        RecordDateTimeSortValue = CDbl(rec("DateTimeSort"))

    ElseIf IsDate(rec("Date")) Then

        RecordDateTimeSortValue = CDbl(AnalysisTemporalDateOnlySerial(rec("Date")))

    End If

End Function



Public Function RecordDateTimeText(ByVal rec As Object) As String

    If rec Is Nothing Then Exit Function

    If IsDate(rec("Date")) Then

        If KeyExists(rec, "HasTime") And CBool(rec("HasTime")) Then

            RecordDateTimeText = Format$(CDate(rec("Date")) + CDbl(rec("TimeFraction")), "yyyy/m/d h:mm")

        Else

            RecordDateTimeText = Format$(CDate(rec("Date")), "yyyy/m/d")

        End If

    End If

End Function



Public Function KeyExists(ByVal dict As Object, ByVal keyText As String) As Boolean

    On Error GoTo EH

    If dict Is Nothing Then Exit Function

    KeyExists = dict.Exists(keyText)

    Exit Function

EH:

    KeyExists = False

End Function





Private Function AnalysisTemporalDateOnlySerial(ByVal v As Variant) As Long
    If IsDate(v) Then AnalysisTemporalDateOnlySerial = CLng(DateValue(CDate(v)))
End Function


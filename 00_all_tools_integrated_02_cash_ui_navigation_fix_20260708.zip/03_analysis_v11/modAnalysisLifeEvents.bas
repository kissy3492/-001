Attribute VB_Name = "modAnalysisLifeEvents"
Option Explicit

'�����E�����C�x���g�̓Ǎ��Ӗ����A�����modAnalysisEngine���番������B
'T_������������f�[�^�A��T_�֌W�̍��������݊��f�[�^�Ƃ��Ĉ����B

Public Function BuildMarriageLifeEventIndex(ByVal personInfo As Object) As Object
    Dim dict As Object
    Set dict = CreateObject("Scripting.Dictionary")
    AddMarriageHistoryToLifeEventIndex dict, personInfo
    AddLegacyRelationMarriageToLifeEventIndex dict, personInfo
    Set BuildMarriageLifeEventIndex = dict
End Function

Public Sub AddMarriageHistoryRelationPairs(ByVal dict As Object)
    Dim ws As Worksheet, lastR As Long, r As Long
    Dim colPerson As Long, colCounterpart As Long, colStatus As Long
    Dim pid As String, cpId As String, statusText As String
    If dict Is Nothing Then Exit Sub
    If Not SheetExists(SH_WORK_MARRIAGE_HIST) Then Exit Sub
    Set ws = GetSheet(SH_WORK_MARRIAGE_HIST)
    colPerson = FirstHeaderColumn(ws, Array("�l��ID"), 1)
    colCounterpart = FirstHeaderColumn(ws, Array("����l��ID"), 1)
    colStatus = FirstHeaderColumn(ws, Array("�f�[�^���"), 1)
    If colPerson = 0 Or colCounterpart = 0 Then Exit Sub
    lastR = LastRow(ws, colPerson)
    For r = 2 To lastR
        statusText = IndexCellTextByCol(ws, r, colStatus)
        If statusText <> "���" Then
            pid = IndexCellTextByCol(ws, r, colPerson)
            cpId = IndexCellTextByCol(ws, r, colCounterpart)
            If Len(pid) > 0 And Len(cpId) > 0 Then
                dict(pid & "|" & cpId) = True
                dict(cpId & "|" & pid) = True
            End If
        End If
    Next r
End Sub

Private Sub AddMarriageHistoryToLifeEventIndex(ByVal dict As Object, ByVal personInfo As Object)
    Dim ws As Worksheet, lastR As Long, r As Long
    Dim colId As Long, colPerson As Long, colCounterpartId As Long, colCounterpartName As Long
    Dim colMarriage As Long, colDivorce As Long, colStatus As Long, colShow As Long
    Dim mhId As String, pid As String, cpId As String, cpName As String, statusText As String, showText As String
    Dim mDate As Variant, dDate As Variant

    If dict Is Nothing Then Exit Sub
    If Not SheetExists(SH_WORK_MARRIAGE_HIST) Then Exit Sub
    Set ws = GetSheet(SH_WORK_MARRIAGE_HIST)
    colId = FirstHeaderColumn(ws, Array("��������ID"), 1)
    colPerson = FirstHeaderColumn(ws, Array("�l��ID"), 1)
    colCounterpartId = FirstHeaderColumn(ws, Array("����l��ID"), 1)
    colCounterpartName = FirstHeaderColumn(ws, Array("���薼", "���莁��"), 1)
    colMarriage = FirstHeaderColumn(ws, Array("������", "�����N����"), 1)
    colDivorce = FirstHeaderColumn(ws, Array("������", "�����N����"), 1)
    colStatus = FirstHeaderColumn(ws, Array("�f�[�^���"), 1)
    colShow = FirstHeaderColumn(ws, Array("�\��"), 1)
    If colPerson = 0 Then Exit Sub

    lastR = LastRow(ws, colPerson)
    For r = 2 To lastR
        statusText = IndexCellTextByCol(ws, r, colStatus)
        showText = IndexCellTextByCol(ws, r, colShow)
        If statusText <> "���" And showText <> "���Ȃ�" Then
            mhId = IndexCellTextByCol(ws, r, colId)
            pid = IndexCellTextByCol(ws, r, colPerson)
            cpId = IndexCellTextByCol(ws, r, colCounterpartId)
            cpName = IndexCellTextByCol(ws, r, colCounterpartName)
            If Len(cpName) = 0 And Len(cpId) > 0 Then cpName = IndexPersonName(personInfo, cpId)
            If colMarriage > 0 Then
                mDate = IndexDateOrEmpty(ws.Cells(r, colMarriage).Value)
            Else
                mDate = Empty
            End If
            If colDivorce > 0 Then
                dDate = IndexDateOrEmpty(ws.Cells(r, colDivorce).Value)
            Else
                dDate = Empty
            End If
            If Len(pid) > 0 Then
                If IsDate(mDate) Then AddLifeEventIndexItem dict, pid, CDate(mDate), "����:" & cpName, "��������", mhId
                If IsDate(dDate) Then AddLifeEventIndexItem dict, pid, CDate(dDate), DivorceIndexText(cpName), "��������", mhId
            End If
            If Len(cpId) > 0 Then
                If IsDate(mDate) Then AddLifeEventIndexItem dict, cpId, CDate(mDate), "����:" & IndexPersonName(personInfo, pid), "��������", mhId
                If IsDate(dDate) Then AddLifeEventIndexItem dict, cpId, CDate(dDate), DivorceIndexText(IndexPersonName(personInfo, pid)), "��������", mhId
            End If
        End If
    Next r
End Sub

Private Sub AddLegacyRelationMarriageToLifeEventIndex(ByVal dict As Object, ByVal personInfo As Object)
    Dim ws As Worksheet, lastR As Long, r As Long
    Dim colBase As Long, colOther As Long, colMarriage As Long, colDivorce As Long, colStatus As Long, colType As Long
    Dim baseId As String, otherId As String, statusText As String, relationType As String
    Dim marriageDate As Variant, divorceDate As Variant
    If dict Is Nothing Then Exit Sub
    If Not SheetExists(SH_WORK_REL) Then Exit Sub
    Set ws = GetSheet(SH_WORK_REL)
    colBase = FirstHeaderColumn(ws, Array("��l��ID", "�l��ID_A", "�l��A", "�l��ID1"), 1)
    colOther = FirstHeaderColumn(ws, Array("����l��ID", "�l��ID_B", "�l��B", "�l��ID2"), 1)
    colMarriage = FirstHeaderColumn(ws, Array("������", "�����N����"), 1)
    colDivorce = FirstHeaderColumn(ws, Array("������", "�����N����"), 1)
    colStatus = FirstHeaderColumn(ws, Array("�f�[�^���"), 1)
    colType = FirstHeaderColumn(ws, Array("�֌W���"), 1)
    If colBase = 0 Or colOther = 0 Then Exit Sub
    If colMarriage = 0 And colDivorce = 0 Then Exit Sub

    lastR = LastRow(ws, colBase)
    For r = 2 To lastR
        statusText = IndexCellTextByCol(ws, r, colStatus)
        relationType = IndexCellTextByCol(ws, r, colType)
        If statusText <> "���" And (Len(relationType) = 0 Or relationType = "�z���") Then
            baseId = IndexCellTextByCol(ws, r, colBase)
            otherId = IndexCellTextByCol(ws, r, colOther)
            If colMarriage > 0 Then marriageDate = IndexDateOrEmpty(ws.Cells(r, colMarriage).Value) Else marriageDate = Empty
            If colDivorce > 0 Then divorceDate = IndexDateOrEmpty(ws.Cells(r, colDivorce).Value) Else divorceDate = Empty
            If IsDate(marriageDate) Then
                If Len(baseId) > 0 Then AddLifeEventIndexItem dict, baseId, CDate(marriageDate), "����:" & IndexPersonName(personInfo, otherId), "�֌W", ""
                If Len(otherId) > 0 Then AddLifeEventIndexItem dict, otherId, CDate(marriageDate), "����:" & IndexPersonName(personInfo, baseId), "�֌W", ""
            End If
            If IsDate(divorceDate) Then
                If Len(baseId) > 0 Then AddLifeEventIndexItem dict, baseId, CDate(divorceDate), DivorceIndexText(IndexPersonName(personInfo, otherId)), "�֌W", ""
                If Len(otherId) > 0 Then AddLifeEventIndexItem dict, otherId, CDate(divorceDate), DivorceIndexText(IndexPersonName(personInfo, baseId)), "�֌W", ""
            End If
        End If
    Next r
End Sub

Private Sub AddLifeEventIndexItem(ByVal dict As Object, ByVal personId As String, ByVal eventDate As Date, ByVal eventText As String, ByVal sourceText As String, ByVal sourceId As String)
    Dim col As Collection, item As Object, k As String
    If dict Is Nothing Or Len(personId) = 0 Then Exit Sub
    k = personId
    If dict.Exists(k) Then
        Set col = dict(k)
    Else
        Set col = New Collection
        dict.Add k, col
    End If
    Set item = CreateObject("Scripting.Dictionary")
    item("Date") = DateValue(eventDate)
    item("Text") = eventText
    item("Source") = sourceText
    item("SourceId") = sourceId
    col.Add item
End Sub

Private Function IndexPersonName(ByVal personInfo As Object, ByVal personId As String) As String
    Dim info As Object
    If Len(personId) = 0 Then Exit Function
    If personInfo Is Nothing Then IndexPersonName = personId: Exit Function
    If Not personInfo.Exists(personId) Then IndexPersonName = personId: Exit Function
    Set info = personInfo(personId)
    If info.Exists("Name") Then IndexPersonName = CStr(info("Name"))
    If Len(IndexPersonName) = 0 Then IndexPersonName = personId
End Function

Private Function DivorceIndexText(ByVal counterpartName As String) As String
    counterpartName = CellText(counterpartName)
    If Len(counterpartName) > 0 Then
        DivorceIndexText = "����:" & counterpartName
    Else
        DivorceIndexText = "����"
    End If
End Function

Private Function IndexDateOrEmpty(ByVal v As Variant) As Variant
    If IsDate(v) Then IndexDateOrEmpty = DateValue(CDate(v)) Else IndexDateOrEmpty = Empty
End Function

Private Function IndexCellTextByCol(ByVal ws As Worksheet, ByVal r As Long, ByVal c As Long) As String
    If c <= 0 Then
        IndexCellTextByCol = ""
    Else
        IndexCellTextByCol = CellText(ws.Cells(r, c).Value)
    End If
End Function

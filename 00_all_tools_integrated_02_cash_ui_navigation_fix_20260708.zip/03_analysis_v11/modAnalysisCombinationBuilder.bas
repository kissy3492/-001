Attribute VB_Name = "modAnalysisCombinationBuilder"
Option Explicit

'�g���������E���z�o�P�b�g�ƍ��͕��͖{�̂̏�ԂɈˑ����Ȃ����������Ƃ��ĕ�������B
'�{�̑��͌�␶���̏����E������B�̕\���Ӗ����������B

Public Function AnalysisSortRecordsByAmountDesc(ByVal records As Collection, ByVal useOut As Boolean) As Collection
    Dim out As New Collection, rec As Object, i As Long, inserted As Boolean
    If records Is Nothing Then Set AnalysisSortRecordsByAmountDesc = out: Exit Function
    For Each rec In records
        inserted = False
        For i = 1 To out.Count
            If AnalysisRecordAmountForSide(rec, useOut) > AnalysisRecordAmountForSide(out(i), useOut) Then
                out.Add rec, , i
                inserted = True
                Exit For
            End If
        Next i
        If Not inserted Then out.Add rec
    Next rec
    Set AnalysisSortRecordsByAmountDesc = out
End Function

Public Function AnalysisRecordAmountForSide(ByVal rec As Object, ByVal useOut As Boolean) As Double
    On Error Resume Next
    If rec Is Nothing Then Exit Function
    If useOut Then
        If rec.Exists("Out") Then AnalysisRecordAmountForSide = CDbl(rec("Out"))
    Else
        If rec.Exists("In") Then AnalysisRecordAmountForSide = CDbl(rec("In"))
    End If
    On Error GoTo 0
End Function

Public Function AnalysisBuildCombos(ByVal records As Collection, ByVal minDepth As Long, ByVal maxDepth As Long, ByVal useOut As Boolean, ByVal maxOutCombos As Long) As Collection
    Dim result As New Collection, tmp As New Collection, target As Long
    If records Is Nothing Then Set AnalysisBuildCombos = result: Exit Function
    If records.Count = 0 Or maxOutCombos <= 0 Then Set AnalysisBuildCombos = result: Exit Function
    For target = minDepth To Application.Min(maxDepth, records.Count)
        AnalysisBuildCombosRec records, 1, target, tmp, result, useOut, maxOutCombos
        If result.Count >= maxOutCombos Then Exit For
    Next target
    Set AnalysisBuildCombos = result
End Function

Public Function AnalysisBuildCombosNearAmount(ByVal records As Collection, ByVal minDepth As Long, ByVal maxDepth As Long, ByVal targetAmount As Double, ByVal useOut As Boolean, ByVal maxOutCombos As Long, ByVal absTolerance As Double, ByVal rateTolerance As Double) As Collection
    Dim result As New Collection, tmp As New Collection, targetDepth As Long, tol As Double
    If records Is Nothing Then Set AnalysisBuildCombosNearAmount = result: Exit Function
    If records.Count = 0 Or targetAmount <= 0 Or maxOutCombos <= 0 Then Set AnalysisBuildCombosNearAmount = result: Exit Function
    tol = AnalysisEffectiveTolerance(targetAmount, targetAmount, absTolerance, rateTolerance)
    For targetDepth = minDepth To Application.Min(maxDepth, records.Count)
        AnalysisBuildCombosNearAmountRec records, 1, targetDepth, tmp, result, useOut, maxOutCombos, targetAmount, tol, absTolerance, rateTolerance, 0#
        If result.Count >= maxOutCombos Then Exit For
    Next targetDepth
    Set AnalysisBuildCombosNearAmount = result
End Function

Private Sub AnalysisBuildCombosNearAmountRec(ByVal records As Collection, ByVal startIdx As Long, ByVal targetDepth As Long, ByVal tmp As Collection, ByVal result As Collection, ByVal useOut As Boolean, ByVal maxOutCombos As Long, ByVal targetAmount As Double, ByVal tol As Double, ByVal absTolerance As Double, ByVal rateTolerance As Double, ByVal currentSum As Double)
    Dim i As Long, amountValue As Double
    If result.Count >= maxOutCombos Then Exit Sub
    If currentSum > targetAmount + tol Then Exit Sub
    If tmp.Count = targetDepth Then
        If Abs(currentSum - targetAmount) <= AnalysisEffectiveTolerance(currentSum, targetAmount, absTolerance, rateTolerance) Then result.Add AnalysisComboObject(tmp, useOut)
        Exit Sub
    End If
    For i = startIdx To records.Count
        amountValue = AnalysisRecordAmountForSide(records(i), useOut)
        If amountValue > 0 Then
            tmp.Add records(i)
            AnalysisBuildCombosNearAmountRec records, i + 1, targetDepth, tmp, result, useOut, maxOutCombos, targetAmount, tol, absTolerance, rateTolerance, currentSum + amountValue
            tmp.Remove tmp.Count
            If result.Count >= maxOutCombos Then Exit For
        End If
    Next i
End Sub

Private Sub AnalysisBuildCombosRec(ByVal records As Collection, ByVal startIdx As Long, ByVal targetDepth As Long, ByVal tmp As Collection, ByVal result As Collection, ByVal useOut As Boolean, ByVal maxOutCombos As Long)
    Dim i As Long
    If result.Count >= maxOutCombos Then Exit Sub
    If tmp.Count = targetDepth Then
        result.Add AnalysisComboObject(tmp, useOut)
        Exit Sub
    End If
    For i = startIdx To records.Count
        tmp.Add records(i)
        AnalysisBuildCombosRec records, i + 1, targetDepth, tmp, result, useOut, maxOutCombos
        tmp.Remove tmp.Count
        If result.Count >= maxOutCombos Then Exit For
    Next i
End Sub

Private Function AnalysisComboObject(ByVal recs As Collection, ByVal useOut As Boolean) As Object
    Dim d As Object, r As Object, sumAmt As Double, copy As New Collection, ids As String
    Set d = CreateObject("Scripting.Dictionary")
    For Each r In recs
        copy.Add r
        sumAmt = sumAmt + AnalysisRecordAmountForSide(r, useOut)
        If Len(ids) > 0 Then ids = ids & ","
        ids = ids & CStr(r("TxId"))
    Next r
    d.Add "Records", copy
    d.Add "Sum", sumAmt
    d.Add "Ids", ids
    Set AnalysisComboObject = d
End Function

Public Function AnalysisAmountClose(ByVal outAmt As Double, ByVal inAmt As Double, ByVal absTolerance As Double, ByVal rateTolerance As Double) As Boolean
    AnalysisAmountClose = (Abs(outAmt - inAmt) <= AnalysisEffectiveTolerance(outAmt, inAmt, absTolerance, rateTolerance))
End Function

Public Function AnalysisEffectiveTolerance(ByVal outAmt As Double, ByVal inAmt As Double, ByVal absTolerance As Double, ByVal rateTolerance As Double) As Double
    AnalysisEffectiveTolerance = absTolerance
    If rateTolerance > 0 Then AnalysisEffectiveTolerance = Application.Max(AnalysisEffectiveTolerance, Application.Max(outAmt, inAmt) * rateTolerance)
End Function

Public Function AnalysisAmountBucketUnit(ByVal absTolerance As Double) As Double
    AnalysisAmountBucketUnit = absTolerance
    If AnalysisAmountBucketUnit < 1 Then AnalysisAmountBucketUnit = 1
End Function

Public Function AnalysisBuildComboAmountIndex(ByVal combos As Collection, ByVal bucketUnit As Double) As Object
    Dim idx As Object, i As Long, c As Object, k As String, col As Collection
    Set idx = CreateObject("Scripting.Dictionary")
    If combos Is Nothing Then Set AnalysisBuildComboAmountIndex = idx: Exit Function
    If bucketUnit < 1 Then bucketUnit = 1
    For i = 1 To combos.Count
        Set c = combos(i)
        k = CStr(CLng(Fix(CDbl(c("Sum")) / bucketUnit)))
        If idx.Exists(k) Then
            Set col = idx(k)
        Else
            Set col = New Collection
            idx.Add k, col
        End If
        col.Add c
    Next i
    Set AnalysisBuildComboAmountIndex = idx
End Function

Public Function AnalysisCandidateCombosByAmountIndexed(ByVal idx As Object, ByVal amountValue As Double, ByVal bucketUnit As Double, ByVal absTolerance As Double, ByVal rateTolerance As Double) As Collection
    Dim out As New Collection, tol As Double, kMin As Long, kMax As Long, k As Long, col As Collection, i As Long, c As Object
    If idx Is Nothing Then Set AnalysisCandidateCombosByAmountIndexed = out: Exit Function
    If bucketUnit < 1 Then bucketUnit = 1
    tol = AnalysisEffectiveTolerance(amountValue, amountValue, absTolerance, rateTolerance)
    kMin = CLng(Fix((amountValue - tol) / bucketUnit)) - 1
    kMax = CLng(Fix((amountValue + tol) / bucketUnit)) + 1
    For k = kMin To kMax
        If idx.Exists(CStr(k)) Then
            Set col = idx(CStr(k))
            For i = 1 To col.Count
                Set c = col(i)
                If AnalysisAmountClose(amountValue, CDbl(c("Sum")), absTolerance, rateTolerance) Then out.Add c
            Next i
        End If
    Next k
    Set AnalysisCandidateCombosByAmountIndexed = out
End Function

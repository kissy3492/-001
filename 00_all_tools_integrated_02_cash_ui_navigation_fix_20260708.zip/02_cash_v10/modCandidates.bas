Attribute VB_Name = "modCandidates"
Option Explicit

Public Sub BuildCandidateSheets(Optional ByVal resetContents As Boolean = False)
    SetupCandidateSheet SH_BANK_CAND, "��s�����", NM_LST_BANK_CAND, resetContents
    SetupCandidateSheet SH_BRANCH_CAND, "�x�X�����", NM_LST_BRANCH_CAND, resetContents
    SetupCandidateSheet SH_PERSON_CAND, "�l�����", NM_LST_PERSON_CAND, resetContents
End Sub

Private Sub SetupCandidateSheet(ByVal sheetName As String, ByVal titleText As String, ByVal listName As String, ByVal resetContents As Boolean)
    Dim ws As Worksheet
    On Error Resume Next
    Set ws = GetOrCreateSheet(sheetName, False)
    If ws Is Nothing Then Exit Sub
    ws.Visible = xlSheetVeryHidden
    ws.Cells.Font.Name = "Meiryo UI"
    ws.Cells.Font.Size = 10
    If resetContents Or Len(CellText(ws.Range("A1").Value)) = 0 Then
        ws.Cells.Clear
        ws.Range("A1").Value = titleText
        ws.Range("A1").Font.Bold = True
        ws.Range("A2").Value = ""
    End If
    ws.Columns("A:A").ColumnWidth = 28
    RefreshSingleCandidateName sheetName, listName
    On Error GoTo 0
End Sub

Public Sub RefreshAccountCandidateNames()
    RefreshSingleCandidateName SH_BANK_CAND, NM_LST_BANK_CAND
    RefreshSingleCandidateName SH_BRANCH_CAND, NM_LST_BRANCH_CAND
    RefreshSingleCandidateName SH_PERSON_CAND, NM_LST_PERSON_CAND
End Sub

Private Sub RefreshSingleCandidateName(ByVal sheetName As String, ByVal listName As String)
    Dim ws As Worksheet
    Dim lastR As Long
    On Error Resume Next
    If Not SheetExists(sheetName) Then Exit Sub
    Set ws = GetSheet(sheetName)
    lastR = LastRow(ws, 1)
    If lastR < 2 Then
        ws.Range("A2").Value = ""
        lastR = 2
    End If
    ResetName listName, ws.Range("A2:A" & CStr(lastR))
    ws.Visible = xlSheetVeryHidden
    On Error GoTo 0
End Sub


Public Sub UpdateTekiyoCandidate(ByVal valueText As String)
    AddCandidateValue SH_TEKIYO, NM_LST_TEKIYO, valueText
End Sub

Public Sub UpdateAccountCandidates(ByVal bankName As String, ByVal branchName As String, ByVal personName As String)
    AddCandidateValue SH_BANK_CAND, NM_LST_BANK_CAND, bankName
    AddCandidateValue SH_BRANCH_CAND, NM_LST_BRANCH_CAND, branchName
    AddCandidateValue SH_PERSON_CAND, NM_LST_PERSON_CAND, personName
End Sub

Public Sub UpdateCandidateFromTarget(ByVal Target As Range)
    If Target Is Nothing Then Exit Sub
    On Error Resume Next
    If Target.Worksheet.Name <> SH_INPUT Then Exit Sub
    Select Case Target.Address(False, False)
        Case CELL_BANK
            AddCandidateValue SH_BANK_CAND, NM_LST_BANK_CAND, CellText(Target.Value)
        Case CELL_BRANCH
            AddCandidateValue SH_BRANCH_CAND, NM_LST_BRANCH_CAND, CellText(Target.Value)
        Case CELL_PERSON
            AddCandidateValue SH_PERSON_CAND, NM_LST_PERSON_CAND, CellText(Target.Value)
    End Select
    On Error GoTo 0
End Sub

Private Sub AddCandidateValue(ByVal sheetName As String, ByVal listName As String, ByVal valueText As String)
    Dim ws As Worksheet
    Dim lastR As Long, r As Long
    Dim s As String
    s = Trim$(valueText)
    If Len(s) = 0 Then Exit Sub
    If Not SheetExists(sheetName) Then BuildCandidateSheets False
    If Not SheetExists(sheetName) Then Exit Sub
    Set ws = GetSheet(sheetName)
    lastR = LastRow(ws, 1)
    If lastR < 2 Then lastR = 1
    For r = 2 To lastR
        If StrComp(CellText(ws.Cells(r, 1).Value), s, vbTextCompare) = 0 Then
            RefreshSingleCandidateName sheetName, listName
            VeryHideSheetIfExists sheetName
            Exit Sub
        End If
    Next r
    ws.Cells(lastR + 1, 1).Value = s
    RefreshSingleCandidateName sheetName, listName
    VeryHideSheetIfExists sheetName
End Sub

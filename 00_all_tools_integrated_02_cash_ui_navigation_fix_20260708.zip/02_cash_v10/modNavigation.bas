Attribute VB_Name = "modNavigation"
Option Explicit

Private mLastHighlightRow As Long
Private mLastEditedRow As Long
Private mLastEditedCol As Long
Private mRedirecting As Boolean

'��������ԍ��x���́A���͍s���ړ����邽�тɍ�ƃV�[�g�S�̂𑖍�����Əd���Ȃ�B
'���݂̌������{��ƃV�[�g�������L�[�ɃL���b�V�����A������Ԃł͍đ������Ȃ��B
Private mDuplicateCacheKey As String
Private mDuplicateCacheMessage As String

Public Sub EnableInputKeys()
    '���̓V�[�g���L���ȊԂ���Tab/Shift+Tab�𐧌䂷��B
    '�u�b�N��A�N�e�B�u���E���̓V�[�g���E���ɂ͕K����������B
    On Error Resume Next
    Application.EnableEvents = True
    Application.OnKey "{TAB}", MacroRef("InputTabNext")
    Application.OnKey "+{TAB}", MacroRef("InputTabPrev")
    On Error GoTo 0
End Sub

Public Sub DisableInputKeys()
    On Error Resume Next
    Application.OnKey "{TAB}"
    Application.OnKey "+{TAB}"
    On Error GoTo 0
End Sub

Public Sub InvalidateDuplicateAccountWarningCache()
    '�]�L�E�������E�蓮�ҏW�Ȃǂō�ƃV�[�g�̓��e���ς�������ɌĂԁB
    '�Â��u�d���Ȃ��v���肪�c��ƌx���������Ƃ����߁A�����I�ɔj������B
    mDuplicateCacheKey = vbNullString
    mDuplicateCacheMessage = vbNullString
End Sub

Public Sub RestoreInputNavigation()
    On Error Resume Next
    AppForceRestore
    Application.EnableEvents = True
    If SheetExists(SH_INPUT) Then
        ThisWorkbook.Worksheets(SH_INPUT).Visible = xlSheetVisible
        ThisWorkbook.Worksheets(SH_INPUT).Activate
        ProtectInputSheet
        EnableInputKeys
        ThisWorkbook.Worksheets(SH_INPUT).Cells(TX_FIRST_ROW, COL_TX_DAY).Select
    End If
    On Error GoTo 0
    NotifyInfo "Tab�ړ��𕜋����܂����B�ʏ탂�[�h�ł́A�E�v�̎��Ɏ��s�̓��ֈړ����܂��B"
End Sub

Public Sub InputTabNext()
    MoveInputCell False
End Sub

Public Sub InputTabPrev()
    MoveInputCell True
End Sub

Public Sub MoveInputCell(ByVal backwards As Boolean)
    Dim ws As Worksheet
    Dim nextCell As Range
    On Error GoTo Fallback
    If ActiveSheet Is Nothing Then GoTo Fallback
    If ActiveSheet.Name <> SH_INPUT Then GoTo Fallback
    Set ws = ActiveSheet
    Set nextCell = GetNextInputCell(ws, ActiveCell, backwards)
    If Not nextCell Is Nothing Then
        Application.Goto nextCell, False
        Exit Sub
    End If
Fallback:
    On Error Resume Next
    If backwards Then ActiveCell.Offset(0, -1).Select Else ActiveCell.Offset(0, 1).Select
    On Error GoTo 0
End Sub

Public Function GetNextInputCell(ByVal ws As Worksheet, ByVal cur As Range, ByVal backwards As Boolean) As Range
    Dim r As Long, c As Long, memoCol As Long
    If ws Is Nothing Or cur Is Nothing Then Exit Function
    r = cur.Row: c = cur.Column
    memoCol = BalanceMemoCol(ws)
    If IsAccountCell(cur) Then
        Set GetNextInputCell = NextAccountCell(ws, cur, backwards)
        Exit Function
    End If
    If r = BAL_VALUE_ROW And c >= BAL_FIRST_COL And c <= memoCol Then
        Set GetNextInputCell = NextBalanceCell(ws, cur, backwards, memoCol)
        Exit Function
    End If
    If r >= TX_FIRST_ROW And r <= TX_LAST_ROW And c >= COL_TX_YEAR And c <= COL_TX_OTHER Then
        Set GetNextInputCell = NextTransactionCell(ws, cur, backwards)
        Exit Function
    End If
    Set GetNextInputCell = ws.Range(CELL_BANK)
End Function

Private Function IsAccountCell(ByVal cur As Range) As Boolean
    Dim a As String
    If cur Is Nothing Then Exit Function
    a = cur.Address(False, False)
    IsAccountCell = (a = CELL_BANK Or a = CELL_BRANCH Or a = CELL_PERSON Or _
                     (UseRelationshipDisplay() And a = CELL_RELATIONSHIP) Or _
                     a = CELL_ACCOUNT_TYPE Or a = CELL_ACCOUNT_NO Or a = CELL_OPEN_DATE Or a = CELL_CLOSE_DATE)
End Function

Private Function NextAccountCell(ByVal ws As Worksheet, ByVal cur As Range, ByVal backwards As Boolean) As Range
    Dim arr As Variant, i As Long
    If UseRelationshipDisplay() Then
        arr = Array(CELL_BANK, CELL_BRANCH, CELL_PERSON, CELL_RELATIONSHIP, CELL_ACCOUNT_TYPE, CELL_ACCOUNT_NO, CELL_OPEN_DATE, CELL_CLOSE_DATE)
    Else
        arr = Array(CELL_BANK, CELL_BRANCH, CELL_PERSON, CELL_ACCOUNT_TYPE, CELL_ACCOUNT_NO, CELL_OPEN_DATE, CELL_CLOSE_DATE)
    End If
    For i = LBound(arr) To UBound(arr)
        If cur.Address(False, False) = CStr(arr(i)) Then
            If backwards Then
                If i = LBound(arr) Then Set NextAccountCell = ws.Range(CELL_BANK) Else Set NextAccountCell = ws.Range(CStr(arr(i - 1)))
            Else
                If i = UBound(arr) Then
                    Set NextAccountCell = FirstAvailableBalanceInputCell(ws)
                Else
                    Set NextAccountCell = ws.Range(CStr(arr(i + 1)))
                End If
            End If
            Exit Function
        End If
    Next i
    Set NextAccountCell = ws.Range(CELL_BANK)
End Function

Private Function NextBalanceCell(ByVal ws As Worksheet, ByVal cur As Range, ByVal backwards As Boolean, ByVal memoCol As Long) As Range
    '�J�ݓ��O�E������Ń��b�N���ꂽ�c�����́ATab�ړ��ł���΂��B
    '���̑����͏�ɓ��͉\�Ȃ̂ŁA�c���������ׂđΏۊO�ł��Ō�ɓ��B�ł���B
    If cur Is Nothing Then Exit Function
    If backwards Then
        Set NextBalanceCell = NextAvailableBalanceInputCell(ws, cur.Column, True)
    Else
        Set NextBalanceCell = NextAvailableBalanceInputCell(ws, cur.Column, False)
    End If
End Function

Private Function NextTransactionCell(ByVal ws As Worksheet, ByVal cur As Range, ByVal backwards As Boolean) As Range
    Dim cols As Variant, idx As Long, i As Long, targetCol As Long
    cols = TransactionRoute(GetInputMode())

    '�y�N�E���̍l�����z
    '2�s�ڈȍ~�̘A�����͂ł́u���v���痬���B����A�N�ւ�肾���͑f����������悤�A
    '���Z���� Shift+Tab �����ꍇ�͌��ł͂Ȃ��N�֒��ږ߂��B���Z���̓N���b�N�E���L�[�ł͕ҏW�\�B
    If cur.Column = COL_TX_YEAR And Not backwards Then Set NextTransactionCell = ws.Cells(cur.Row, COL_TX_MONTH): Exit Function
    If cur.Column = COL_TX_MONTH And Not backwards Then Set NextTransactionCell = ws.Cells(cur.Row, COL_TX_DAY): Exit Function
    If cur.Column = COL_TX_DAY And backwards Then Set NextTransactionCell = ws.Cells(cur.Row, COL_TX_YEAR): Exit Function
    If cur.Column = COL_TX_MONTH And backwards Then Set NextTransactionCell = ws.Cells(cur.Row, COL_TX_YEAR): Exit Function
    If cur.Column = COL_TX_YEAR And backwards Then
        If cur.Row <= TX_FIRST_ROW Then
            Set NextTransactionCell = ws.Cells(cur.Row, COL_TX_YEAR)
        Else
            Set NextTransactionCell = ws.Cells(cur.Row - 1, CLng(cols(UBound(cols))))
        End If
        Exit Function
    End If

    '�ʏ탂�[�h�ł͂��̑����Tab���[�g����O���Ă���B
    '�������N���b�N�E���L�[�œ��������Tab���������ꍇ�́A�����s�̓��ł͂Ȃ����s�̓��֑���B
    If cur.Column = COL_TX_OTHER Then
        If backwards Then
            Set NextTransactionCell = ws.Cells(cur.Row, COL_TX_TEKIYO)
        ElseIf cur.Row < TX_LAST_ROW Then
            Set NextTransactionCell = ws.Cells(cur.Row + 1, COL_TX_DAY)
        Else
            Set NextTransactionCell = ws.Cells(TX_LAST_ROW, COL_TX_OTHER)
        End If
        Exit Function
    End If

    idx = -1
    For i = LBound(cols) To UBound(cols)
        If CLng(cols(i)) = cur.Column Then idx = i: Exit For
    Next i
    If idx = -1 Then Set NextTransactionCell = ws.Cells(cur.Row, COL_TX_DAY): Exit Function
    If backwards Then
        If idx = LBound(cols) Then
            If cur.Row <= TX_FIRST_ROW Then Set NextTransactionCell = ws.Cells(TX_FIRST_ROW, COL_TX_DAY) Else Set NextTransactionCell = ws.Cells(cur.Row - 1, CLng(cols(UBound(cols))))
        Else
            Set NextTransactionCell = ws.Cells(cur.Row, CLng(cols(idx - 1)))
        End If
    Else
        If cur.Column = COL_TX_WITHDRAW And HasText(cur.Value) Then
            targetCol = RouteColumnAfter(cols, COL_TX_DEPOSIT)
            Set NextTransactionCell = ws.Cells(cur.Row, targetCol)
            Exit Function
        End If
        If idx = UBound(cols) Then
            If cur.Row >= TX_LAST_ROW Then Set NextTransactionCell = ws.Cells(TX_LAST_ROW, CLng(cols(idx))) Else Set NextTransactionCell = ws.Cells(cur.Row + 1, COL_TX_DAY)
        Else
            Set NextTransactionCell = ws.Cells(cur.Row, CLng(cols(idx + 1)))
        End If
    End If
End Function

Private Function TransactionRoute(ByVal modeText As String) As Variant
    If modeText = MODE_SIMPLE Then
        TransactionRoute = Array(COL_TX_DAY, COL_TX_WITHDRAW, COL_TX_DEPOSIT, COL_TX_SHOP)
    ElseIf modeText = MODE_NO_TIME Then
        TransactionRoute = Array(COL_TX_DAY, COL_TX_WITHDRAW, COL_TX_DEPOSIT, COL_TX_SHOP, COL_TX_MACHINE, COL_TX_TEKIYO)
    ElseIf modeText = MODE_NO_MACHINE Then
        TransactionRoute = Array(COL_TX_DAY, COL_TX_TIME, COL_TX_WITHDRAW, COL_TX_DEPOSIT, COL_TX_SHOP, COL_TX_TEKIYO)
    ElseIf modeText = MODE_NO_TEKIYO Then
        TransactionRoute = Array(COL_TX_DAY, COL_TX_TIME, COL_TX_WITHDRAW, COL_TX_DEPOSIT, COL_TX_SHOP, COL_TX_MACHINE)
    ElseIf modeText = MODE_WITH_OTHER Then
        TransactionRoute = Array(COL_TX_DAY, COL_TX_TIME, COL_TX_WITHDRAW, COL_TX_DEPOSIT, COL_TX_SHOP, COL_TX_MACHINE, COL_TX_TEKIYO, COL_TX_OTHER)
    Else
        TransactionRoute = Array(COL_TX_DAY, COL_TX_TIME, COL_TX_WITHDRAW, COL_TX_DEPOSIT, COL_TX_SHOP, COL_TX_MACHINE, COL_TX_TEKIYO)
    End If
End Function

Private Function RouteColumnAfter(ByVal cols As Variant, ByVal afterCol As Long) As Long
    Dim i As Long
    For i = LBound(cols) To UBound(cols) - 1
        If CLng(cols(i)) = afterCol Then RouteColumnAfter = CLng(cols(i + 1)): Exit Function
    Next i
    RouteColumnAfter = COL_TX_SHOP
End Function

Public Sub OnInputSelectionChange(ByVal Target As Range)
    Dim t As Range
    On Error Resume Next
    If Target Is Nothing Then Exit Sub
    Set t = Target
    If t.Cells.CountLarge > 1 Then
        If t.MergeCells Then
            Set t = t.MergeArea.Cells(1, 1)
        Else
            Exit Sub
        End If
    End If
    If mRedirecting Then Exit Sub
    '���̑���͒ʏ�Tab���[�g����͊O�����A�N���b�N�E���L�[�œ������ꍇ�͂��̂܂ܕҏW������B
    '�����Ŏ����ޔ�������ƁA���͒��̃����������Ȃ��Ȃ�B
    SmartRedirectAfterDefaultMove t
    UpdateCurrentRowHighlight t
    UpdateComplementStatus t
    On Error GoTo 0
End Sub

Public Sub OnInputChange(ByVal Target As Range)
    Dim nextCol As Long
    Dim t As Range
    If Target Is Nothing Then Exit Sub
    Set t = Target
    If t.Cells.CountLarge > 1 Then
        If t.MergeCells Then
            Set t = t.MergeArea.Cells(1, 1)
        Else
            Exit Sub
        End If
    End If
    If t.Worksheet.Name <> SH_INPUT Then Exit Sub

    '��s���E�x�X���E�l�����́A���͂������̂�����ȍ~�̌��ɂ���B
    '���킹�Č����ԍ��̏d���x�����Ĕ��肷��B��s����l�����𒼂������Ɍx����������悤�ɂ��邽�߁B
    If t.Address(False, False) = CELL_BANK Or t.Address(False, False) = CELL_BRANCH Or t.Address(False, False) = CELL_PERSON Or t.Address(False, False) = CELL_RELATIONSHIP Then
        UpdateCandidateFromTarget t
        If t.Address(False, False) = CELL_PERSON Then SyncSelectedPersonFromInput t.Worksheet
        If Not UpdateDuplicateAccountStatus(t.Worksheet) Then UpdateComplementStatus t
        Exit Sub
    End If

    If t.Address(False, False) = CELL_ACCOUNT_TYPE Or t.Address(False, False) = CELL_ACCOUNT_NO Then
        If Not UpdateDuplicateAccountStatus(t.Worksheet) Then UpdateComplementStatus t
        Exit Sub
    End If

    If t.Address(False, False) = CELL_OPEN_DATE Or t.Address(False, False) = CELL_CLOSE_DATE Then
        '�J�ݓ��E�����́A�a������͂����̏�� yyyy/m/d �\���֐����A�c�����̓��͉ۂ��X�V����B
        On Error Resume Next
        Application.EnableEvents = False
        NormalizeAccountDateEntry t
        Application.EnableEvents = True
        t.Worksheet.Unprotect Password:=TOOL_PASSWORD
        ApplyBalanceAvailability t.Worksheet
        ProtectInputSheet
        If Not UpdateDuplicateAccountStatus(t.Worksheet) Then UpdateComplementStatus t
        On Error GoTo 0
        Exit Sub
    End If

    If t.Row < TX_FIRST_ROW Or t.Row > TX_LAST_ROW Then Exit Sub

    mLastEditedRow = t.Row
    mLastEditedCol = t.Column

    If t.Column = COL_TX_WITHDRAW And HasText(t.Value) Then
        nextCol = RouteColumnAfter(TransactionRoute(GetInputMode()), COL_TX_DEPOSIT)
        SafeGoto t.Worksheet.Cells(t.Row, nextCol)
    ElseIf t.Column = COL_TX_DEPOSIT And HasText(t.Value) Then
        nextCol = RouteColumnAfter(TransactionRoute(GetInputMode()), COL_TX_DEPOSIT)
        SafeGoto t.Worksheet.Cells(t.Row, nextCol)
    ElseIf t.Column = COL_TX_TEKIYO And GetInputMode() <> MODE_WITH_OTHER Then
        If t.Row < TX_LAST_ROW Then SafeGoto t.Worksheet.Cells(t.Row + 1, COL_TX_DAY)
    End If
End Sub

Private Sub SmartRedirectAfterDefaultMove(ByVal Target As Range)
    Dim nextCol As Long
    If Target.Worksheet.Name <> SH_INPUT Then Exit Sub
    If Target.Row < TX_FIRST_ROW Or Target.Row > TX_LAST_ROW Then Exit Sub

    If Target.Column = COL_TX_DEPOSIT Then
        If HasText(Target.Worksheet.Cells(Target.Row, COL_TX_WITHDRAW).Value) Then
            nextCol = RouteColumnAfter(TransactionRoute(GetInputMode()), COL_TX_DEPOSIT)
            SafeGoto Target.Worksheet.Cells(Target.Row, nextCol)
            Exit Sub
        End If
    End If

    '���̑���͒ʏ�Tab�ł͒ʂ�Ȃ����A���L�[�E�N���b�N�ł͓��͉\�ɂ���B
End Sub

Private Sub SafeGoto(ByVal targetCell As Range)
    If targetCell Is Nothing Then Exit Sub
    On Error Resume Next
    mRedirecting = True
    Application.Goto targetCell, False
    mRedirecting = False
    On Error GoTo 0
End Sub

Private Sub UpdateCurrentRowHighlight(ByVal Target As Range)
    Dim ws As Worksheet
    Set ws = Target.Worksheet
    If mLastHighlightRow >= TX_FIRST_ROW And mLastHighlightRow <= TX_LAST_ROW Then
        RestoreTransactionRowStyle ws, mLastHighlightRow
    End If
    If Target.Row >= TX_FIRST_ROW And Target.Row <= TX_LAST_ROW Then
        With ws.Range(ws.Cells(Target.Row, COL_TX_YEAR), ws.Cells(Target.Row, COL_TX_OTHER))
            .Interior.Color = RGB(219, 234, 254)
            .Font.Color = RGB(15, 23, 42)
            .Borders.Color = RGB(37, 99, 235)
        End With
        mLastHighlightRow = Target.Row
    Else
        mLastHighlightRow = 0
    End If
End Sub

Private Sub RestoreTransactionRowStyle(ByVal ws As Worksheet, ByVal rowNo As Long)
    If ws Is Nothing Then Exit Sub
    With ws.Range(ws.Cells(rowNo, COL_TX_YEAR), ws.Cells(rowNo, COL_TX_OTHER))
        If (rowNo - TX_FIRST_ROW) Mod 2 = 0 Then
            .Interior.Color = RGB(255, 255, 255)
        Else
            .Interior.Color = RGB(248, 250, 252)
        End If
        .Font.Color = RGB(15, 23, 42)
        .Borders.Color = RGB(226, 232, 240)
    End With
End Sub
Private Sub UpdateComplementStatus(ByVal Target As Range)
    Dim ws As Worksheet, r As Long, cy As Long, cm As Long, cd As Long
    Dim ok As Boolean, timeOK As Boolean, yAdd As Long, d As Variant, tVal As Variant
    Dim textY As String, textM As String, textD As String, textTime As String
    Set ws = Target.Worksheet

    '���������ԍ������ɓ]�L�ς݂Ȃ�A�⊮�l�����x���J�[�h�Ƃ��Ďg���B
    '���b�Z�[�W�{�b�N�X���o���Ɠ��͂̎肪�~�܂邽�߁A��ʓ��̐F�ƕ��������Œm�点��B
    If UpdateDuplicateAccountStatus(ws) Then Exit Sub

    ApplyStatusStyle ws, False
    If Target.Row < TX_FIRST_ROW Then
        ws.Range(CELL_STATUS).Value = "�⊮�l�@-�N�@-���@-���@--:--"
        Exit Sub
    End If
    yAdd = GetCfgLong(ROW_CFG_YEAR_ADD, 2000)
    textTime = "--:--"
    For r = TX_FIRST_ROW To Target.Row
        If Not IsTransactionRowBlank(ws, r) Then
            d = ResolveInputDate(ws.Cells(r, COL_TX_YEAR).Value, ws.Cells(r, COL_TX_MONTH).Value, ws.Cells(r, COL_TX_DAY).Value, cy, cm, cd, yAdd, ok)
            If HasText(ws.Cells(r, COL_TX_TIME).Value) Then
                tVal = NormalizeTimeInput(ws.Cells(r, COL_TX_TIME).Value, timeOK)
                If timeOK Then
                    If IsDate(tVal) Then textTime = Format$(CDate(tVal), "hh:mm")
                End If
            End If
        End If
    Next r
    If cy = 0 Then textY = "-" Else textY = CStr(cy)
    If cm = 0 Then textM = "-" Else textM = CStr(cm)
    If cd = 0 Then textD = "-" Else textD = CStr(cd)
    ws.Range(CELL_STATUS).Value = "�⊮�l�@" & textY & "�N�@" & textM & "���@" & textD & "���@" & textTime
End Sub



Public Function UpdateDuplicateAccountStatus(ByVal ws As Worksheet) As Boolean
    Dim msg As String
    If ws Is Nothing Then Exit Function
    msg = DuplicateAccountWarningMessage(ws)
    If Len(msg) > 0 Then
        ApplyStatusStyle ws, True
        ws.Range(CELL_STATUS).Value = msg
        UpdateDuplicateAccountStatus = True
    Else
        ApplyStatusStyle ws, False
    End If
End Function

Private Function DuplicateAccountWarningMessage(ByVal ws As Worksheet) As String
    Dim bankName As String, branchName As String, personName As String, accType As String, accNo As String
    Dim hitInfo As String
    Dim cacheKey As String
    If ws Is Nothing Then Exit Function

    accNo = NormalizeAccountHyphen(CellText(ws.Range(CELL_ACCOUNT_NO).Value))
    If Len(accNo) = 0 Then
        InvalidateDuplicateAccountWarningCache
        Exit Function
    End If

    bankName = CellText(ws.Range(CELL_BANK).Value)
    branchName = CellText(ws.Range(CELL_BRANCH).Value)
    personName = CellText(ws.Range(CELL_PERSON).Value)
    accType = CellText(ws.Range(CELL_ACCOUNT_TYPE).Value)

    cacheKey = DuplicateAccountCacheKey(bankName, branchName, personName, accType, accNo)
    If cacheKey = mDuplicateCacheKey Then
        DuplicateAccountWarningMessage = mDuplicateCacheMessage
        Exit Function
    End If

    '���ɓ]�L�ς݂̍�ƃV�[�g����A���������ԍ��̌���T���B
    '��ƃV�[�g���傫���Ȃ��Ă��A�������͏�Ԃł̓L���b�V�����g�����߈ړ����̕��ׂ�}������B
    hitInfo = FindDuplicateAccountInWorkSheets(bankName, branchName, personName, accType, accNo)
    If Len(hitInfo) > 0 Then
        DuplicateAccountWarningMessage = "�m�F�@���������ԍ��̓]�L�ς݌�₪����܂��F" & accNo & "�@" & hitInfo
    End If

    mDuplicateCacheKey = cacheKey
    mDuplicateCacheMessage = DuplicateAccountWarningMessage
End Function

Private Function DuplicateAccountCacheKey(ByVal bankName As String, ByVal branchName As String, ByVal personName As String, ByVal accType As String, ByVal accNo As String) As String
    '������񂾂��łȂ��A��ƃV�[�g�̍ŏI�s���L�[�Ɋ܂߂�B
    '�]�L��ɍs�����������ꍇ�͓��������ԍ��ł��Ĕ��肳���B
    Dim txLast As Long
    Dim balLast As Long

    If SheetExists(SH_WORK_TX) Then txLast = LastRow(GetSheet(SH_WORK_TX), OUT_COL_BANK)
    If SheetExists(SH_WORK_BAL) Then balLast = LastRow(GetSheet(SH_WORK_BAL), 1)

    DuplicateAccountCacheKey = bankName & Chr$(30) & branchName & Chr$(30) & personName & Chr$(30) & _
                               accType & Chr$(30) & accNo & Chr$(30) & CStr(txLast) & Chr$(30) & CStr(balLast)
End Function

Private Function FindDuplicateAccountInWorkSheets(ByVal bankName As String, ByVal branchName As String, ByVal personName As String, ByVal accType As String, ByVal accNo As String) As String
    Dim ws As Worksheet, r As Long, lastR As Long
    Dim hitCount As Long, firstHit As String
    If Len(accNo) = 0 Then Exit Function

    If SheetExists(SH_WORK_TX) Then
        Set ws = GetSheet(SH_WORK_TX)
        lastR = LastRow(ws, OUT_COL_BANK)
        For r = 2 To lastR
            If WorkAccountMatches(ws, r, bankName, branchName, personName, accType, accNo) Then
                hitCount = hitCount + 1
                If Len(firstHit) = 0 Then firstHit = "W_��� " & CStr(r) & "�s"
            End If
        Next r
    End If

    If hitCount = 0 And SheetExists(SH_WORK_BAL) Then
        Set ws = GetSheet(SH_WORK_BAL)
        lastR = LastRow(ws, 1)
        For r = 2 To lastR
            If WorkBalanceAccountMatches(ws, r, bankName, branchName, personName, accType, accNo) Then
                hitCount = hitCount + 1
                If Len(firstHit) = 0 Then firstHit = "W_�c�� " & CStr(r) & "�s"
            End If
        Next r
    End If

    If hitCount = 1 Then
        FindDuplicateAccountInWorkSheets = firstHit
    ElseIf hitCount > 1 Then
        FindDuplicateAccountInWorkSheets = firstHit & " �ق� " & CStr(hitCount - 1) & "��"
    End If
End Function

Private Function WorkAccountMatches(ByVal ws As Worksheet, ByVal r As Long, ByVal bankName As String, ByVal branchName As String, ByVal personName As String, ByVal accType As String, ByVal accNo As String) As Boolean
    If NormalizeAccountHyphen(CellText(ws.Cells(r, OUT_COL_ACCOUNT_NO).Value)) <> accNo Then Exit Function
    If Len(bankName) > 0 And CellText(ws.Cells(r, OUT_COL_BANK).Value) <> bankName Then Exit Function
    If Len(branchName) > 0 And CellText(ws.Cells(r, OUT_COL_BRANCH).Value) <> branchName Then Exit Function
    If Len(personName) > 0 And CellText(ws.Cells(r, OUT_COL_PERSON).Value) <> personName Then Exit Function
    If Len(accType) > 0 And CellText(ws.Cells(r, OUT_COL_ACCOUNT_TYPE).Value) <> accType Then Exit Function
    WorkAccountMatches = True
End Function

Private Function WorkBalanceAccountMatches(ByVal ws As Worksheet, ByVal r As Long, ByVal bankName As String, ByVal branchName As String, ByVal personName As String, ByVal accType As String, ByVal accNo As String) As Boolean
    'W_�c���́A1:���� 2:��s�� 3:�x�X�� 4:�Ȗ� 5:�����ԍ� �̍\���B
    If NormalizeAccountHyphen(CellText(ws.Cells(r, 5).Value)) <> accNo Then Exit Function
    If Len(personName) > 0 And CellText(ws.Cells(r, 1).Value) <> personName Then Exit Function
    If Len(bankName) > 0 And CellText(ws.Cells(r, 2).Value) <> bankName Then Exit Function
    If Len(branchName) > 0 And CellText(ws.Cells(r, 3).Value) <> branchName Then Exit Function
    If Len(accType) > 0 And CellText(ws.Cells(r, 4).Value) <> accType Then Exit Function
    WorkBalanceAccountMatches = True
End Function

Private Sub ApplyStatusStyle(ByVal ws As Worksheet, ByVal warningMode As Boolean)
    Dim rng As Range
    If ws Is Nothing Then Exit Sub
    Set rng = ws.Range(CELL_STATUS & ":K12")
    If warningMode Then
        rng.Interior.Color = RGB(254, 226, 226)
        rng.Font.Color = RGB(153, 27, 27)
        rng.Borders.Color = RGB(248, 113, 113)
    Else
        rng.Interior.Color = RGB(236, 253, 245)
        rng.Font.Color = RGB(15, 118, 110)
        rng.Borders.Color = RGB(94, 234, 212)
    End If
    rng.Font.Bold = True
    rng.HorizontalAlignment = xlCenter
    rng.VerticalAlignment = xlCenter
End Sub

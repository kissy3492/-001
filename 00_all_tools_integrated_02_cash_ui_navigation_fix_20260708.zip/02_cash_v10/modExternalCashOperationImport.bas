Attribute VB_Name = "modExternalCashOperationImport"
Option Explicit

Private Const IMPORT_BALANCE_SOURCE As String = "������׎c������⊮"
Private mImportManualSelection As Object

Public Sub ImportExternalCashOperationTable()
    Dim filePath As Variant
    Dim wbSrc As Workbook, wsSrc As Worksheet
    Dim importedCount As Long, skippedCount As Long, balanceCount As Long
    Dim personResolutionMessage As String
    If Not RequireToolReady() Then Exit Sub
    filePath = Application.GetOpenFilename("Excel/CSV (*.xlsx;*.xlsm;*.xls;*.csv),*.xlsx;*.xlsm;*.xls;*.csv", , "13��ڎc���t����������\��I��")
    If VarType(filePath) = vbBoolean Then Exit Sub

    If IsCommonLinkEnabled() Then LoadPersonMasterFromCommonData False

    On Error GoTo EH
    AppBegin "�O����������\���捞��..."
    Set wbSrc = OpenExternalWorkbookReadOnly(CStr(filePath))
    Set wsSrc = FindExternalCashOperationSheet(wbSrc)
    If wsSrc Is Nothing Then Err.Raise vbObjectError + 4101, "ImportExternalCashOperationTable", "��������\�̃w�b�_�[�s�����o�ł��܂���ł����B"

    importedCount = ImportExternalCashRows(wsSrc, CStr(filePath), skippedCount)
    wbSrc.Close SaveChanges:=False
    Set wbSrc = Nothing

    balanceCount = RebuildBalancesFromTransactionAfterBalance(False)
    FormatWorkTx GetSheet(SH_WORK_TX)
    FormatWorkBal GetSheet(SH_WORK_BAL)
    RefreshAccountCandidateNames
    AppendLinkLog "�O����������\�捞", "����", "���" & CStr(importedCount) & "�� / �d�����X�L�b�v" & CStr(skippedCount) & "�� / �c���⊮" & CStr(balanceCount) & "��"
    If HasPendingImportPersonResolution() Then
        ShowImportPersonResolutionSheet False
    Else
        HideDailySheets False
    End If
    AppEnd
    If HasPendingImportPersonResolution() Then
        personResolutionMessage = "�l���ƍ��҂�������܂��BW_�捞�l���ƍ���O��֌��ID����͂��A�I�𔽉f���Ď捞�����s���Ă��������B"
    Else
        personResolutionMessage = "�l���ƍ��҂��͂���܂���B"
    End If
    NotifyInfo "�O����������\����荞�݂܂����B" & vbCrLf & _
           "���: " & CStr(importedCount) & " ��" & vbCrLf & _
           "�X�L�b�v: " & CStr(skippedCount) & " ��" & vbCrLf & _
           "�N���E�����J�n�����_�c���̕⊮: " & CStr(balanceCount) & " ��" & vbCrLf & _
           personResolutionMessage
    Exit Sub
EH:
    On Error Resume Next
    If Not wbSrc Is Nothing Then wbSrc.Close SaveChanges:=False
    AppendLinkLog "�O����������\�捞", "���s", Err.Description
    AppEnd
    RuntimeShowError "ImportExternalCashOperationTable", "�O����������\�捞", "�I���t�@�C���A�w�b�_�[�s�A��}�b�s���O�A�J���Ă���O���u�b�N���m�F���Ă��������B"
End Sub

Public Sub RebuildBalancesFromTransactionAfterBalanceButton()
    Dim n As Long
    If Not RequireToolReady() Then Exit Sub
    On Error GoTo EH
    AppBegin "������׎c������c���⊮��..."
    n = RebuildBalancesFromTransactionAfterBalance(True)
    FormatWorkTx GetSheet(SH_WORK_TX)
    FormatWorkBal GetSheet(SH_WORK_BAL)
    AppendLinkLog "������׎c�����c���⊮", "����", CStr(n) & "��"
    AppEnd
    NotifyInfo "������ׂ�13��ڎc������A�N���E�����J�n�����_�c����⊮���܂����B" & vbCrLf & CStr(n) & " ��"
    Exit Sub
EH:
    AppEnd
    RuntimeShowError "RebuildBalancesFromTransactionAfterBalanceButton", "�c���⊮", "�����c����E���t�E�����E���͏��̏�Ԃ��m�F���Ă��������B"
End Sub

Private Function FindExternalCashOperationSheet(ByVal wb As Workbook) As Worksheet
    Dim ws As Worksheet
    If wb Is Nothing Then Exit Function
    For Each ws In wb.Worksheets
        If DetectExternalHeaderRow(ws) > 0 Then
            Set FindExternalCashOperationSheet = ws
            Exit Function
        End If
    Next ws
End Function

Private Function DetectExternalHeaderRow(ByVal ws As Worksheet) As Long
    Dim r As Long
    If ws Is Nothing Then Exit Function
    For r = 1 To Application.Min(30, LastUsedRowInSheet(ws))
        If ExternalHeaderCol(ws, r, Array("���t", "�����"), 0) > 0 _
           And ExternalHeaderCol(ws, r, Array("�o��", "���o", "�x��"), 0) > 0 _
           And ExternalHeaderCol(ws, r, Array("����", "�a��", "���"), 0) > 0 Then
            DetectExternalHeaderRow = r
            Exit Function
        End If
    Next r
End Function

Private Function ExternalMapQualityScore(ByVal ws As Worksheet, _
        ByVal hdr As Long, _
        ByVal lastR As Long, _
        ByVal cols As Variant, _
        ByRef messageText As String) As Long
    Dim cBank As Long
    Dim cBranch As Long
    Dim cPerson As Long
    Dim cNo As Long
    Dim cTxDateColumn As Long
    Dim cOutCol As Long
    Dim cInCol As Long
    Dim cOther As Long
    Dim score As Long
    Dim total As Long
    Dim dateOk As Long
    Dim amountOk As Long
    Dim r As Long
    Dim maxR As Long
    Dim outAmt As Variant
    Dim inAmt As Variant
    Dim hasData As Boolean
    Dim warnings As String

    cBank = CLng(cols(0))
    cBranch = CLng(cols(1))
    cPerson = CLng(cols(2))
    cNo = CLng(cols(3))
    cTxDateColumn = CLng(cols(4))
    cOutCol = CLng(cols(5))
    cInCol = CLng(cols(6))
    cOther = CLng(cols(7))

    If HeaderTextMatches(ws, hdr, cTxDateColumn, Array("���t", "�����")) Then
        score = score + 15
    Else
        warnings = JoinImportWarning(warnings, "���t�񂪊���ʒu����")
    End If

    If HeaderTextMatches(ws, hdr, cOutCol, Array("�o��", "���o", "�x��")) Then
        score = score + 15
    Else
        warnings = JoinImportWarning(warnings, "�o���񂪊���ʒu����")
    End If

    If HeaderTextMatches(ws, hdr, cInCol, Array("����", "�a��", "���")) Then
        score = score + 15
    Else
        warnings = JoinImportWarning(warnings, "�����񂪊���ʒu����")
    End If

    If HeaderTextMatches(ws, hdr, cBank, Array("��s��", "���Z�@��", "���Z�@�֖�")) Then score = score + 5
    If HeaderTextMatches(ws, hdr, cBranch, Array("�x�X��", "�X�ܖ�", "�戵�X��")) Then score = score + 5
    If HeaderTextMatches(ws, hdr, cPerson, Array("����", "���`�l", "�������`�l")) Then score = score + 5
    If HeaderTextMatches(ws, hdr, cNo, Array("�����ԍ�", "�ԍ�")) Then score = score + 5
    If HeaderTextMatches(ws, hdr, cOther, Array("���̑�", "�c��", "�����c��", "�����c��")) Then score = score + 5

    maxR = Application.Min(lastR, hdr + 80)
    For r = hdr + 1 To maxR
        hasData = HasExternalImportData(ws, r, cTxDateColumn, cOutCol, cInCol)
        If hasData Then
            total = total + 1
            If IsDate(ImportedDateValue(ws.Cells(r, cTxDateColumn).Value)) Then dateOk = dateOk + 1
            outAmt = LooseAmountOrBlank(ws.Cells(r, cOutCol).Value)
            inAmt = LooseAmountOrBlank(ws.Cells(r, cInCol).Value)
            If ImportedAmountNonZero(outAmt) Or ImportedAmountNonZero(inAmt) Then amountOk = amountOk + 1
        End If
    Next r

    If total > 0 Then
        If dateOk >= total * 0.8 Then
            score = score + 15
        Else
            warnings = JoinImportWarning(warnings, "���t���ߗ����Ⴂ")
        End If

        If amountOk >= total * 0.5 Then
            score = score + 15
        Else
            warnings = JoinImportWarning(warnings, "���z���ߗ����Ⴂ")
        End If
    Else
        warnings = JoinImportWarning(warnings, "�f�[�^�s��������Ȃ�")
    End If

    If score > 100 Then score = 100
    messageText = "���{" & CStr(total) & "�s�� ���tOK" & CStr(dateOk) & " / ���zOK" & CStr(amountOk)
    If Len(warnings) > 0 Then messageText = messageText & " / " & warnings
    ExternalMapQualityScore = score
End Function

Private Function HasExternalImportData(ByVal ws As Worksheet, _
        ByVal rowNo As Long, _
        ByVal cTxDateColumn As Long, _
        ByVal cOutCol As Long, _
        ByVal cInCol As Long) As Boolean
    If Len(CellText(ws.Cells(rowNo, cTxDateColumn).Value)) > 0 Then HasExternalImportData = True: Exit Function
    If Len(CellText(ws.Cells(rowNo, cOutCol).Value)) > 0 Then HasExternalImportData = True: Exit Function
    If Len(CellText(ws.Cells(rowNo, cInCol).Value)) > 0 Then HasExternalImportData = True: Exit Function
End Function

Private Function HeaderTextMatches(ByVal ws As Worksheet, ByVal hdr As Long, ByVal colNo As Long, ByVal names As Variant) As Boolean
    Dim i As Long, head As String
    If ws Is Nothing Or hdr <= 0 Or colNo <= 0 Then Exit Function
    head = NormalizeExternalText(ws.Cells(hdr, colNo).Value)
    For i = LBound(names) To UBound(names)
        If head = NormalizeExternalText(CStr(names(i))) Then HeaderTextMatches = True: Exit Function
    Next i
End Function

Private Function JoinImportWarning(ByVal leftText As String, ByVal rightText As String) As String
    If Len(leftText) = 0 Then
        JoinImportWarning = rightText
    Else
        JoinImportWarning = leftText & "�A" & rightText
    End If
End Function

Private Function ImportedAmountNonZero(ByVal v As Variant) As Boolean
    If Len(CellText(v)) = 0 Then Exit Function
    If Not IsNumeric(v) Then Exit Function
    ImportedAmountNonZero = (Abs(CDbl(v)) > 0.0000001)
End Function

Private Function ImportExternalCashRows(ByVal wsSrc As Worksheet, ByVal sourcePath As String, ByRef skippedCount As Long) As Long
    Dim hdr As Long, lastR As Long, r As Long, outR As Long
    Dim cBank As Long, cBranch As Long, cPerson As Long, cRelation As Long, cType As Long, cNo As Long
    Dim cTxDateCol As Long, cTime As Long, cOut As Long, cIn As Long, cShop As Long, cMachine As Long, cSummary As Long, cOther As Long, cRowKind As Long
    Dim bankName As String, branchName As String, personName As String, relationName As String, accType As String, accNo As String
    Dim lastBank As String, lastBranch As String, lastPerson As String, lastRelation As String, lastType As String, lastNo As String
    Dim personId As String, accountId As String, transferId As String, txId As String, shopFinal As String, summaryText As String
    Dim txDate As Variant, txTime As Variant, timeOK As Boolean, outAmt As Variant, inAmt As Variant, balAfter As Variant
    Dim wsTx As Worksheet, existing As Object, naturalKey As String
    Dim inputOrder As Long
    Dim mapQuality As Long, mapMessage As String
    Dim mapCols As Variant
    Dim candidateText As String, manualPersonId As String
    Dim duplicateCount As Long, unresolvedCount As Long, manualResolvedCount As Long

    Set wsTx = GetSheet(SH_WORK_TX)
    Set existing = BuildExistingTransactionNaturalKeys(wsTx)
    hdr = DetectExternalHeaderRow(wsSrc)
    If hdr = 0 Then Err.Raise vbObjectError + 4102, "ImportExternalCashRows", "�w�b�_�[�s��������܂���B"

    cBank = ExternalHeaderCol(wsSrc, hdr, Array("��s��", "���Z�@��", "���Z�@�֖�"), 1)
    cBranch = ExternalHeaderCol(wsSrc, hdr, Array("�x�X��", "�X�ܖ�", "�戵�X��"), 2)
    cPerson = ExternalHeaderCol(wsSrc, hdr, Array("����", "���`�l", "�������`�l"), 3)
    cType = ExternalHeaderCol(wsSrc, hdr, Array("�Ȗ�", "�a�����"), 4)
    cNo = ExternalHeaderCol(wsSrc, hdr, Array("�����ԍ�", "�ԍ�"), 5)
    cTxDateCol = ExternalHeaderCol(wsSrc, hdr, Array("���t", "�����"), 6)
    cTime = ExternalHeaderCol(wsSrc, hdr, Array("����", "�������", "����"), 0)
    cOut = ExternalHeaderCol(wsSrc, hdr, Array("�o��", "���o", "�x��"), 8)
    cIn = ExternalHeaderCol(wsSrc, hdr, Array("����", "�a��", "���"), 9)
    cShop = ExternalHeaderCol(wsSrc, hdr, Array("�戵�X", "�戵�X����", "�戵�X�m��l"), 10)
    cMachine = ExternalHeaderCol(wsSrc, hdr, Array("�@��", "�@�B�ԍ�", "�[��"), 11)
    cSummary = ExternalHeaderCol(wsSrc, hdr, Array("�E�v��", "�E�v", "���e"), 12)
    cOther = ExternalHeaderCol(wsSrc, hdr, Array("���̑�", "�c��", "�����c��", "�����c��"), 13)
    cRelation = ExternalHeaderCol(wsSrc, hdr, Array("����", "�֌W"), 0)
    cRowKind = ExternalHeaderCol(wsSrc, hdr, Array("�s���", "���s���"), 0)

    lastR = LastUsedRowInSheet(wsSrc)
    mapCols = Array(cBank, cBranch, cPerson, cNo, cTxDateCol, cOut, cIn, cOther)
    mapQuality = ExternalMapQualityScore(wsSrc, hdr, lastR, mapCols, mapMessage)
    If mapQuality < 55 Then
        Err.Raise vbObjectError + 4103, "ImportExternalCashRows", "�O����������\�̗񔻒�̐M���x���Ⴂ���߁A�����捞���~�߂܂����B" & vbCrLf & _
                  "�M���x: " & CStr(mapQuality) & " / " & mapMessage
    ElseIf mapQuality < 75 Then
        AddCheck "�m�F", SourceRowText(sourcePath, wsSrc.Name, hdr), "�O���捞�̗񔻒肪���M���ł��B�m�F�V�[�g�Ō����Ɨ���m�F���Ă��������B�M���x " & CStr(mapQuality) & " / " & mapMessage
    End If
    Set mImportManualSelection = LoadImportPersonManualSelectionMap()
    InitImportPersonResolutionSheet sourcePath, wsSrc.Name
    For r = hdr + 1 To lastR
        If cRowKind > 0 Then
            If Len(CellText(wsSrc.Cells(r, cRowKind).Value)) > 0 And CellText(wsSrc.Cells(r, cRowKind).Value) <> ROW_KIND_TRANSACTION Then
                skippedCount = skippedCount + 1
                GoTo ContinueRow
            End If
        End If

        bankName = CarryForwardText(wsSrc.Cells(r, cBank).Value, lastBank)
        branchName = CarryForwardText(wsSrc.Cells(r, cBranch).Value, lastBranch)
        personName = CarryForwardText(wsSrc.Cells(r, cPerson).Value, lastPerson)
        accType = CarryForwardText(wsSrc.Cells(r, cType).Value, lastType)
        accNo = CarryForwardText(wsSrc.Cells(r, cNo).Value, lastNo)
        If cRelation > 0 Then relationName = CarryForwardText(wsSrc.Cells(r, cRelation).Value, lastRelation) Else relationName = ""

        txDate = ImportedDateValue(wsSrc.Cells(r, cTxDateCol).Value)
        If cTime > 0 Then
            txTime = NormalizeTimeInput(wsSrc.Cells(r, cTime).Value, timeOK)
        Else
            txTime = Empty
            timeOK = False
        End If
        outAmt = LooseAmountOrBlank(wsSrc.Cells(r, cOut).Value)
        inAmt = LooseAmountOrBlank(wsSrc.Cells(r, cIn).Value)
        balAfter = LooseAmountOrBlank(wsSrc.Cells(r, cOther).Value)
        summaryText = CellText(wsSrc.Cells(r, cSummary).Value)

        If Not IsDate(txDate) Then
            If Len(CellText(wsSrc.Cells(r, cTxDateCol).Value)) > 0 Or Len(CellText(outAmt & inAmt)) > 0 Then AddCheck "�m�F", SourceRowText(sourcePath, wsSrc.Name, r), "���t�����߂ł��Ȃ����ߎ捞���X�L�b�v���܂����B"
            skippedCount = skippedCount + 1
            GoTo ContinueRow
        End If
        If Len(CellText(outAmt)) = 0 And Len(CellText(inAmt)) = 0 Then
            skippedCount = skippedCount + 1
            GoTo ContinueRow
        End If
        If Not ImportedAmountNonZero(outAmt) And Not ImportedAmountNonZero(inAmt) Then
            skippedCount = skippedCount + 1
            GoTo ContinueRow
        End If
        If ImportedAmountNonZero(outAmt) And ImportedAmountNonZero(inAmt) Then
            AddCheck "�m�F", SourceRowText(sourcePath, wsSrc.Name, r), "�o���Ɠ����̗����ɋ��z�����邽�߁A�������͂֍������捞���X�L�b�v���܂����B"
            skippedCount = skippedCount + 1
            GoTo ContinueRow
        End If
        If Len(bankName & branchName & personName & accType & accNo) = 0 Then
            AddCheck "�m�F", SourceRowText(sourcePath, wsSrc.Name, r), "������񂪋�̂��ߎ捞���X�L�b�v���܂����B"
            skippedCount = skippedCount + 1
            GoTo ContinueRow
        End If

        manualPersonId = ManualResolvedPersonIdForImport(personName, bankName, branchName, accType, accNo)
        If Len(manualPersonId) > 0 Then
            personId = manualPersonId
            manualResolvedCount = manualResolvedCount + 1
        Else
            personId = ResolveImportedPersonId(personName, bankName, branchName, accType, accNo)
        End If
        If Len(personId) = 0 And IsCommonLinkEnabled() Then
            candidateText = PersonCandidateOptionsText(personName, 8)
            RecordImportPersonResolution sourcePath, wsSrc.Name, r, personName, candidateText, bankName, branchName, accType, accNo, txDate, outAmt, inAmt
            unresolvedCount = unresolvedCount + 1
            If Len(candidateText) > 0 Then
                AddCheck "�m�F", SourceRowText(sourcePath, wsSrc.Name, r), _
                    "�l��ID����ӂɌ��߂��Ȃ����ߖ{�o�^���܂���B��R�Â��h�~�̂��߃X�L�b�v���܂���: " & personName & vbCrLf & _
                    "���:" & vbCrLf & candidateText & vbCrLf & _
                    "W_�捞�l���ƍ��Ō��E�����E���t�E���z���m�F���AO��֐l��ID�����āu�I�𔽉f���Ď捞�v�����s���Ă��������B"
            Else
                AddCheck "�G���[", SourceRowText(sourcePath, wsSrc.Name, r), _
                    "�l��ID�ɕR�Â��ł��Ȃ����ߖ{�o�^���܂���B���ݎ����E���������E�\������S���p�E�󔒁E�h�́E���L��ꍞ�݂Ő��K�����Ă���v���܂���: " & personName & vbCrLf & _
                    "W_�捞�l���ƍ��Ɋm�F�҂��s���쐬���܂����B"
            End If
            skippedCount = skippedCount + 1
            GoTo ContinueRow
        End If
        If Len(relationName) = 0 Then relationName = PersonRelationById(personId)

        accountId = GetOrCreateWorkAccountId(personId, personName, relationName, bankName, branchName, accType, accNo, "", "")
        shopFinal = CellText(wsSrc.Cells(r, cShop).Value)
        If Len(shopFinal) = 0 Then shopFinal = branchName

        naturalKey = ImportedNaturalKey(accountId, txDate, txTime, outAmt, inAmt, CellText(wsSrc.Cells(r, cShop).Value), CellText(wsSrc.Cells(r, cMachine).Value), summaryText, balAfter)
        If existing.Exists(naturalKey) Then
            duplicateCount = duplicateCount + 1
            skippedCount = skippedCount + 1
            GoTo ContinueRow
        End If
        existing.Add naturalKey, True

        transferId = NextTransferId()
        txId = NextTransactionId()
        inputOrder = inputOrder + 1
        outR = LastRow(wsTx, 1) + 1
        If outR < 2 Then outR = 2
        wsTx.Cells(outR, OUT_COL_BANK).Value = bankName
        wsTx.Cells(outR, OUT_COL_BRANCH).Value = branchName
        wsTx.Cells(outR, OUT_COL_PERSON).Value = personName
        wsTx.Cells(outR, OUT_COL_ACCOUNT_TYPE).Value = accType
        wsTx.Cells(outR, OUT_COL_ACCOUNT_NO).Value = accNo
        wsTx.Cells(outR, OUT_COL_DATE).Value = CDate(txDate)
        If IsDate(txTime) Then
            wsTx.Cells(outR, OUT_COL_TIME).Value = CDate(txTime)
        ElseIf cTime > 0 Then
            wsTx.Cells(outR, OUT_COL_TIME).Value = CellText(wsSrc.Cells(r, cTime).Value)
        Else
            wsTx.Cells(outR, OUT_COL_TIME).Value = ""
        End If
        wsTx.Cells(outR, OUT_COL_WITHDRAW).Value = outAmt
        wsTx.Cells(outR, OUT_COL_DEPOSIT).Value = inAmt
        wsTx.Cells(outR, OUT_COL_SHOP).Value = CellText(wsSrc.Cells(r, cShop).Value)
        wsTx.Cells(outR, OUT_COL_MACHINE).Value = CellText(wsSrc.Cells(r, cMachine).Value)
        wsTx.Cells(outR, OUT_COL_TEKIYO).Value = summaryText
        '13��ڎc���́u�����c���v��𐳖{�ɂ���B���̑����֏d�������Ȃ��B
        wsTx.Cells(outR, OUT_COL_OTHER).Value = ""
        wsTx.Cells(outR, WORK_TX_COL_AFTER_BALANCE).Value = balAfter
        wsTx.Cells(outR, WORK_TX_COL_AFTER_BALANCE_RAW).Value = CellText(wsSrc.Cells(r, cOther).Value)
        wsTx.Cells(outR, WORK_TX_COL_BALANCE_SOURCE).Value = "�O����������\13���"
        wsTx.Cells(outR, WORK_TX_COL_RELATIONSHIP).Value = relationName
        RegisterWorkTxMeta wsTx, outR, personId, accountId, txId, ROW_KIND_TRANSACTION, transferId, r, inputOrder, shopFinal
        If Len(summaryText) > 0 Then UpdateTekiyoCandidate summaryText
        UpdateAccountCandidates bankName, branchName, personName
        ImportExternalCashRows = ImportExternalCashRows + 1
ContinueRow:
    Next r
    If duplicateCount > 0 Then AddCheck "���", SourceRowText(sourcePath, wsSrc.Name, hdr), "�����s�ƈ�v�������ߏd���]�L����炸�X�L�b�v: " & CStr(duplicateCount) & " ��"
    If manualResolvedCount > 0 Then AddCheck "���", SourceRowText(sourcePath, wsSrc.Name, hdr), "W_�捞�l���ƍ���O��I��l��ID���g���ĕR�t�����s: " & CStr(manualResolvedCount) & " ��"
    If unresolvedCount > 0 Then
        AddCheck "�m�F", SourceRowText(sourcePath, wsSrc.Name, hdr), "�l��ID����ӂɌ��߂�ꂸ�{�o�^���Ȃ������s: " & CStr(unresolvedCount) & " ���BW_�捞�l���ƍ��Ō����m�F���AO��֐l��ID����͂��čĎ捞�ł��܂��B"
        ShowImportPersonResolutionSheet
    Else
        HideImportPersonResolutionSheet
        EnforceCashSheetVisibility "input"
    End If
End Function

Private Sub InitImportPersonResolutionSheet(ByVal sourcePath As String, ByVal sheetName As String)
    Dim ws As Worksheet, r As Long
    Set ws = GetOrCreateSheet(SH_IMPORT_PERSON_RESOLUTION, False)
    ws.Unprotect Password:=TOOL_PASSWORD
    If Len(CellText(ws.Range("A1").Value)) = 0 Or CellText(ws.Cells(1, 15).Value) <> "�I��l��ID" Then
        ws.Cells.Clear
        SetRowValues ws.Range("A1"), Array("���", "���t�@�C��", "���V�[�g", "���s", "���͎���", "���K���L�[", "���", "��s��", "�x�X��", "�Ȗ�", "�����ԍ�", "���t", "�o��", "����", "�I��l��ID", "�I��l����", "�I������", "�Ή�����")
        ws.Range("A2").Value = "���̕\�͊O���捞�Ől��ID����ӂɌ��߂��Ȃ������s���c���܂��B��◓���_�u���N���b�N�A�܂��͉E���̑���{�^���u���I���v�Ől��ID��I�ׂ܂��BO��֒��ړ��͂��\�ł��B�I�𔽉f���Ď捞�ŁA���������E���������̍s�������̐l���֕R�t���܂��B"
        ws.Range("A2:R2").Merge
        ws.Range("A2:R2").Interior.Color = ThemeColor("warning-soft")
        ws.Range("A2:R2").WrapText = True
        ws.Range("A2:R2").VerticalAlignment = xlVAlignCenter
        FormatHeader ws.Range("A1:R1")
    End If
    For r = LastRow(ws, 1) To 3 Step -1
        If Len(CellText(ws.Cells(r, 15).Value)) = 0 Then
            ws.Rows(r).Delete
        ElseIf ImportedPersonIdExists(CellText(ws.Cells(r, 15).Value)) Then
            ws.Cells(r, 1).Value = "�蓮�I����/�Ď捞�Ŏg�p"
        Else
            ws.Cells(r, 1).Value = "�I��l��ID����/�Ċm�F"
            ws.Cells(r, 18).Value = AppendMemoText(ws.Cells(r, 18).Value, "�I��l��ID�����ʃf�[�^��Ɍ�����܂���B���ID���m�F���Ă��������B")
        End If
    Next r
    AutoFitSheetSmart ws, "A:R", 8, 44
    AddImportPersonResolutionButtons ws
    If SheetExists(SH_INPUT) Then ThisWorkbook.Worksheets(SH_INPUT).Activate
    ws.Visible = xlSheetVeryHidden
End Sub



Public Sub ApplyImportPersonResolutionSelections(Optional ByVal silent As Boolean = False)
    Dim ws As Worksheet, lastR As Long, r As Long
    Dim selectedId As String, validCount As Long, invalidCount As Long, emptyCount As Long
    If Not SheetExists(SH_IMPORT_PERSON_RESOLUTION) Then
        If Not silent Then NotifyInfo "W_�捞�l���ƍ��͂܂�����܂���B"
        Exit Sub
    End If
    If IsCommonLinkEnabled() Then LoadPersonMasterFromCommonData False
    Set ws = GetSheet(SH_IMPORT_PERSON_RESOLUTION)
    ws.Unprotect Password:=TOOL_PASSWORD
    AddImportPersonResolutionButtons ws
    lastR = LastRow(ws, 1)
    For r = 3 To lastR
        If Len(CellText(ws.Cells(r, 5).Value)) > 0 Then
            selectedId = CellText(ws.Cells(r, 15).Value)
            If Len(selectedId) = 0 Then
                emptyCount = emptyCount + 1
            ElseIf ImportedPersonIdExists(selectedId) Then
                ws.Cells(r, 1).Value = "�蓮�I����/�Ď捞��"
                ws.Cells(r, 16).Value = ImportedPersonNameById(selectedId)
                If Len(CellText(ws.Cells(r, 17).Value)) = 0 Then ws.Cells(r, 17).Value = "O��I��"
                PersistImportPersonSelection ws, r, selectedId
                ws.Cells(r, 18).Value = AppendMemoText(ws.Cells(r, 18).Value, "�I��ID�m�F�ρE�L���ۑ�: " & selectedId & " / " & Format$(Now, "yyyy/m/d h:nn"))
                validCount = validCount + 1
            Else
                ws.Cells(r, 1).Value = "�I��l��ID����/�Ċm�F"
                ws.Cells(r, 16).Value = ""
                ws.Cells(r, 18).Value = AppendMemoText(ws.Cells(r, 18).Value, "�I��l��ID�����ʃf�[�^��Ɍ�����܂���: " & selectedId)
                invalidCount = invalidCount + 1
            End If
        End If
    Next r
    Set mImportManualSelection = LoadImportPersonManualSelectionMap()
    AutoFitSheetSmart ws, "A:R", 8, 44
    AddImportPersonResolutionButtons ws
    If Not silent Then
        If invalidCount > 0 Then
            QuietWarn "�l���ƍ��Ŗ����ȑI��l��ID������܂��B�L��: " & CStr(validCount) & "�� / ����: " & CStr(invalidCount) & "�� / ������: " & CStr(emptyCount) & "��", True, "�l���ƍ�"
        Else
            NotifyInfo "�l���ƍ��̑I�����m�F���܂����B" & vbCrLf & _
                       "�L��: " & CStr(validCount) & "�� / ����: " & CStr(invalidCount) & "�� / ������: " & CStr(emptyCount) & "��"
        End If
    End If
End Sub

Public Sub ReimportAfterImportPersonResolutionSelection()
    Dim paths As Object, k As Variant, wbSrc As Workbook, wsSrc As Worksheet
    Dim importedTotal As Long, skippedTotal As Long, skippedCount As Long, balanceCount As Long
    If Not RequireToolReady() Then Exit Sub
    If Not SheetExists(SH_IMPORT_PERSON_RESOLUTION) Then
        NotifyInfo "W_�捞�l���ƍ�������܂���B�܂��O���\�捞�����s���Ă��������B"
        Exit Sub
    End If

    On Error GoTo EH
    AppBegin "�l���ƍ��I���𔽉f���čĎ捞��..."
    ApplyImportPersonResolutionSelections True
    Set paths = SelectedImportSourcePaths()
    If paths.Count = 0 Then
        AppEnd
        ShowImportPersonResolutionSheet False
        QuietWarn "�Ď捞�ł���L���ȑI���s������܂���BO��̐l��ID�ƌ��t�@�C���̑��݂��m�F���Ă��������B", True, "�l���ƍ��Ď捞"
        Exit Sub
    End If

    If IsCommonLinkEnabled() Then LoadPersonMasterFromCommonData False
    For Each k In paths.Keys
        If Len(CStr(k)) > 0 Then
            If Len(Dir$(CStr(k))) > 0 Then
                skippedCount = 0
                Set wbSrc = OpenExternalWorkbookReadOnly(CStr(k))
                Set wsSrc = FindExternalCashOperationSheet(wbSrc)
                If wsSrc Is Nothing Then Err.Raise vbObjectError + 4211, "ReimportAfterImportPersonResolutionSelection", "��������\�̃w�b�_�[�s�����o�ł��܂���ł���: " & CStr(k)
                importedTotal = importedTotal + ImportExternalCashRows(wsSrc, CStr(k), skippedCount)
                skippedTotal = skippedTotal + skippedCount
                wbSrc.Close SaveChanges:=False
                Set wbSrc = Nothing
            End If
        End If
    Next k

    balanceCount = RebuildBalancesFromTransactionAfterBalance(False)
    FormatWorkTx GetSheet(SH_WORK_TX)
    FormatWorkBal GetSheet(SH_WORK_BAL)
    RefreshAccountCandidateNames
    AppendLinkLog "�l���ƍ��Ď捞", "����", "���" & CStr(importedTotal) & "�� / �X�L�b�v" & CStr(skippedTotal) & "�� / �c���⊮" & CStr(balanceCount) & "��"
    If HasPendingImportPersonResolution() Then
        ShowImportPersonResolutionSheet False
    Else
        HideDailySheets False
    End If
    AppEnd
    NotifyInfo "�l���ƍ��I�����g���čĎ捞���܂����B" & vbCrLf & _
           "�V�K���: " & CStr(importedTotal) & "��" & vbCrLf & _
           "�X�L�b�v: " & CStr(skippedTotal) & "��" & vbCrLf & _
           "�c���⊮: " & CStr(balanceCount) & "��"
    Exit Sub
EH:
    On Error Resume Next
    If Not wbSrc Is Nothing Then wbSrc.Close SaveChanges:=False
    AppEnd
    On Error GoTo 0
    RuntimeShowError "ReimportAfterImportPersonResolutionSelection", "�l���ƍ��I���̍Ď捞", "O��̐l��ID�A���t�@�C���̑��݁A�O���\�w�b�_�[���m�F���Ă��������B"
End Sub

Private Function SelectedImportSourcePaths() As Object
    Dim d As Object, ws As Worksheet, lastR As Long, r As Long, selectedId As String, p As String
    Set d = CreateObject("Scripting.Dictionary")
    LoadImportPersonSelectionMemory d
    If SheetExists(SH_IMPORT_PERSON_RESOLUTION) Then
        Set ws = GetSheet(SH_IMPORT_PERSON_RESOLUTION)
        lastR = LastRow(ws, 1)
        For r = 3 To lastR
            selectedId = CellText(ws.Cells(r, 15).Value)
            p = CellText(ws.Cells(r, 2).Value)
            If ImportedPersonIdExists(selectedId) And Len(p) > 0 Then
                If Len(Dir$(p)) > 0 Then
                    If Not d.Exists(p) Then d.Add p, True
                Else
                    ws.Cells(r, 1).Value = "���t�@�C���Ȃ�/�Ċm�F"
                    ws.Cells(r, 18).Value = AppendMemoText(ws.Cells(r, 18).Value, "���t�@�C����������܂���: " & p)
                End If
            End If
        Next r
    End If
    Set SelectedImportSourcePaths = d
End Function

Public Function ImportedPersonNameById(ByVal personId As String) As String
    Dim ws As Worksheet, lastR As Long, r As Long
    personId = CellText(personId)
    If Len(personId) = 0 Then Exit Function
    If SheetExists(SH_WORK_PERSON_REF) Then
        Set ws = GetSheet(SH_WORK_PERSON_REF)
        lastR = LastRow(ws, 1)
        For r = 2 To lastR
            If CellText(ws.Cells(r, 1).Value) = personId Then
                ImportedPersonNameById = CellText(ws.Cells(r, 2).Value)
                Exit Function
            End If
        Next r
    End If
    If SheetExists(SH_PERSON_CAND) Then
        Set ws = GetSheet(SH_PERSON_CAND)
        lastR = LastRow(ws, 1)
        For r = 2 To lastR
            If CellText(ws.Cells(r, 2).Value) = personId Then
                ImportedPersonNameById = CellText(ws.Cells(r, 1).Value)
                Exit Function
            End If
        Next r
    End If
End Function

Public Sub AddImportPersonResolutionButtons(ByVal ws As Worksheet)
    Dim shp As Shape, lastR As Long
    Dim x As Double, y As Double, gap As Double, wSmall As Double, wLarge As Double, h As Double
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    ws.Unprotect Password:=TOOL_PASSWORD
    ws.Cells.Locked = True
    lastR = LastRow(ws, 1)
    If lastR < 200 Then lastR = 200
    ws.Range("O3:R" & CStr(lastR)).Locked = False
    DeleteImportPersonResolutionButtons ws
    ws.Columns("U:AD").ColumnWidth = 13
    ws.Range("U1:AD4").ClearContents
    ws.Range("U1:AD4").Interior.Color = RGB(248, 250, 252)
    ws.Range("U1:AD4").Borders.LineStyle = xlNone
    ws.Range("U1").Value = "����"
    ws.Range("U1").Font.Bold = True
    ws.Range("U1").Font.Color = RGB(30, 64, 175)
    On Error GoTo 0

    x = ws.Range("U2").Left
    y = ws.Range("U2").Top + 1
    gap = 6
    wSmall = 104
    wLarge = 142
    h = 24
    AddUIButton ws, x, y, wSmall, h, "���I��", "ChooseImportPersonResolutionForActiveRow", "accent"
    AddUIButton ws, x + wSmall + gap, y, wSmall, h, "���ꗗ", "ShowImportPersonCandidatePanelForActiveRow", "accent"
    AddUIButton ws, x + (wSmall + gap) * 2, y, wSmall, h, "�I�𔽉f", "ApplyImportPersonResolutionSelections", "accent"
    AddUIButton ws, x, y + h + gap, wLarge, h, "�I�𔽉f���Ď捞", "ReimportAfterImportPersonResolutionSelection", "primary"
    AddUIButton ws, x + wLarge + gap, y + h + gap, 100, h, "���͂�", "ShowInputSheet", "neutral"
    MarkImportPersonResolutionButtons ws
    On Error Resume Next
    ws.Protect Password:=TOOL_PASSWORD, UserInterfaceOnly:=True, AllowFiltering:=True
    On Error GoTo 0
End Sub

Private Sub DeleteImportPersonResolutionButtons(ByVal ws As Worksheet)
    Dim i As Long
    Dim shp As Shape
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    For i = ws.Shapes.Count To 1 Step -1
        Set shp = ws.Shapes(i)
        If IsImportPersonResolutionButton(shp) Then shp.Delete
    Next i
    On Error GoTo 0
End Sub

Private Function IsImportPersonResolutionButton(ByVal shp As Shape) As Boolean
    Dim macroName As String
    If shp Is Nothing Then Exit Function
    On Error Resume Next
    macroName = CellText(shp.AlternativeText)
    If Len(macroName) = 0 Then macroName = CellText(shp.OnAction)
    On Error GoTo 0
    If Left$(shp.Name, 21) = "btn_import_person_res" Then
        IsImportPersonResolutionButton = True
    ElseIf InStr(1, macroName, "ChooseImportPersonResolutionForActiveRow", vbTextCompare) > 0 _
        Or InStr(1, macroName, "ShowImportPersonCandidatePanelForActiveRow", vbTextCompare) > 0 _
        Or InStr(1, macroName, "ApplyImportPersonResolutionSelections", vbTextCompare) > 0 _
        Or InStr(1, macroName, "ReimportAfterImportPersonResolutionSelection", vbTextCompare) > 0 _
        Or InStr(1, macroName, "ShowInputSheet", vbTextCompare) > 0 Then
        IsImportPersonResolutionButton = True
    End If
End Function

Private Sub MarkImportPersonResolutionButtons(ByVal ws As Worksheet)
    Dim shp As Shape
    Dim idx As Long
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    idx = 0
    For Each shp In ws.Shapes
        If IsImportPersonResolutionButton(shp) Then
            idx = idx + 1
            shp.Name = "btn_import_person_res_" & CStr(idx)
            shp.PrintObject = False
            shp.Placement = xlMove
            shp.Locked = True
        End If
    Next shp
    On Error GoTo 0
End Sub

Private Sub RecordImportPersonResolution(ByVal sourcePath As String, _
        ByVal sheetName As String, _
        ByVal srcRow As Long, _
        ByVal personName As String, _
        ByVal candidateText As String, _
        ByVal bankName As String, _
        ByVal branchName As String, _
        ByVal accType As String, _
        ByVal accNo As String, _
        ByVal txDate As Variant, _
        ByVal outAmt As Variant, _
        ByVal inAmt As Variant)
    Dim ws As Worksheet, outR As Long, statusText As String
    Set ws = GetOrCreateSheet(SH_IMPORT_PERSON_RESOLUTION, False)
    If Len(CellText(ws.Range("A1").Value)) = 0 Or CellText(ws.Cells(1, 15).Value) <> "�I��l��ID" Then InitImportPersonResolutionSheet sourcePath, sheetName
    If Len(candidateText) > 0 Then
        statusText = "��╡��/�v�I��"
    Else
        statusText = "���Ȃ�/�l���o�^�v"
    End If
    outR = LastRow(ws, 1) + 1
    If outR < 3 Then outR = 3
    ws.Cells(outR, 1).Value = statusText
    ws.Cells(outR, 2).Value = sourcePath
    ws.Cells(outR, 3).Value = sheetName
    ws.Cells(outR, 4).Value = srcRow
    ws.Cells(outR, 5).Value = personName
    ws.Cells(outR, 6).Value = ImportPersonNameKey(personName)
    ws.Cells(outR, 7).Value = candidateText
    ws.Cells(outR, 8).Value = bankName
    ws.Cells(outR, 9).Value = branchName
    ws.Cells(outR, 10).Value = accType
    ws.Cells(outR, 11).Value = accNo
    If IsDate(txDate) Then ws.Cells(outR, 12).Value = CDate(txDate) Else ws.Cells(outR, 12).Value = txDate
    ws.Cells(outR, 13).Value = outAmt
    ws.Cells(outR, 14).Value = inAmt
    ws.Cells(outR, 15).Value = ""
    ws.Cells(outR, 16).Value = ""
    ws.Cells(outR, 17).Value = ""
    ws.Cells(outR, 18).Value = "���ID��O��֓��͂��A�I�𔽉f���Ď捞�����s�B���Ȃ��̏ꍇ��01�l�����/���ʃf�[�^���̐l���o�^���ɏC���B"
    ws.Range(ws.Cells(outR, 1), ws.Cells(outR, 18)).WrapText = True
    AutoFitSheetSmart ws, "A:R", 8, 44
    If SheetExists(SH_INPUT) Then ThisWorkbook.Worksheets(SH_INPUT).Activate
    ws.Visible = xlSheetVeryHidden
End Sub

Public Sub ChooseImportPersonResolutionForActiveRow()
    '����݊��̃{�^�������B�]���̐擪��⎩�����͂ł͂Ȃ��A��␔�ɉ����đI���ł���UI�ֈϏ�����B
    ChooseImportPersonResolutionForActiveRowUi
End Sub

Public Sub FillSelectedImportPersonCandidateId()
    Dim ws As Worksheet, targetRow As Long, candidateText As String, candidateId As String
    If Not SheetExists(SH_IMPORT_PERSON_RESOLUTION) Then
        NotifyInfo "W_�捞�l���ƍ�������܂���B"
        Exit Sub
    End If
    Set ws = GetSheet(SH_IMPORT_PERSON_RESOLUTION)
    targetRow = ActiveCell.Row
    If targetRow < 3 Then targetRow = 3
    If Len(CellText(ws.Cells(targetRow, 5).Value)) = 0 Then
        QuietWarn "���s��I�����Ă��牟���Ă��������B", False, "�l���ƍ�"
        Exit Sub
    End If
    candidateText = CellText(ws.Cells(targetRow, 7).Value)
    candidateId = FirstCandidatePersonIdFromText(candidateText)
    If Len(candidateId) = 0 Then
        QuietWarn "���ID�𒊏o�ł��܂���ł����B��◓���m�F���AO��֐l��ID����͂��Ă��������B", False, "�l���ƍ�"
        Exit Sub
    End If
    If Not ImportedPersonIdExists(candidateId) Then
        QuietWarn "���o�������ID���l���}�X�^�ɂ���܂���: " & candidateId, True, "�l���ƍ�"
        Exit Sub
    End If
    ws.Unprotect Password:=TOOL_PASSWORD
    ws.Cells(targetRow, 15).Value = candidateId
    ws.Cells(targetRow, 16).Value = ImportedPersonNameById(candidateId)
    ws.Cells(targetRow, 17).Value = "��◓�擪ID"
    ws.Cells(targetRow, 18).Value = AppendMemoText(ws.Cells(targetRow, 18).Value, "��◓����ID����: " & candidateId)
    AddImportPersonResolutionButtons ws
End Sub

Private Function FirstCandidatePersonIdFromText(ByVal candidateText As String) As String
    Dim lines As Variant, i As Long, s As String, p As Long
    candidateText = Replace(candidateText, vbCr, vbLf)
    lines = Split(candidateText, vbLf)
    For i = LBound(lines) To UBound(lines)
        s = Trim$(CStr(lines(i)))
        If Left$(s, 1) = "�E" Then s = Mid$(s, 2)
        p = InStr(1, s, "/", vbTextCompare)
        If p > 1 Then s = Trim$(Left$(s, p - 1))
        If ImportedPersonIdExists(s) Then
            FirstCandidatePersonIdFromText = s
            Exit Function
        End If
    Next i
End Function

Private Sub EnsureImportPersonSelectionMemorySheet()
    Dim ws As Worksheet
    Set ws = GetOrCreateSheet(SH_IMPORT_PERSON_MEMORY, False)
    If CellText(ws.Cells(1, 1).Value) <> "�ƍ��L�[" Or CellText(ws.Cells(1, 3).Value) <> "�l��ID" Then
        ws.Cells.Clear
        SetRowValues ws.Range("A1"), Array("�ƍ��L�[", "�L�[���", "�l��ID", "�l����", "������", "��s��", "�x�X��", "�Ȗ�", "�����ԍ�", "�X�V����", "����")
        FormatHeader ws.Range("A1:K1")
    End If
    ws.Visible = xlSheetVeryHidden
End Sub

Private Sub PersistImportPersonSelection(ByVal wsRes As Worksheet, ByVal rowNo As Long, ByVal selectedId As String)
    Dim keyFull As String, keyName As String
    keyFull = ImportPersonSelectionKey(wsRes.Cells(rowNo, 5).Value, wsRes.Cells(rowNo, 8).Value, wsRes.Cells(rowNo, 9).Value, wsRes.Cells(rowNo, 10).Value, wsRes.Cells(rowNo, 11).Value)
    keyName = ImportPersonNameKey(wsRes.Cells(rowNo, 5).Value)
    If Len(keyFull) > 0 Then UpsertImportPersonSelectionMemory "F|" & keyFull, "����+��������", selectedId, wsRes, rowNo
    If Len(keyName) > 0 Then UpsertImportPersonSelectionMemory "N|" & keyName, "�����̂�", selectedId, wsRes, rowNo
End Sub

Private Sub UpsertImportPersonSelectionMemory(ByVal keyText As String, ByVal keyType As String, ByVal selectedId As String, ByVal wsRes As Worksheet, ByVal rowNo As Long)
    Dim ws As Worksheet, r As Long, lastR As Long
    If Len(keyText) = 0 Or Len(selectedId) = 0 Then Exit Sub
    EnsureImportPersonSelectionMemorySheet
    Set ws = GetSheet(SH_IMPORT_PERSON_MEMORY)
    lastR = LastRow(ws, 1)
    r = 0
    For r = 2 To lastR
        If CellText(ws.Cells(r, 1).Value) = keyText Then Exit For
    Next r
    If r < 2 Or r > lastR Then r = lastR + 1
    If r < 2 Then r = 2
    ws.Cells(r, 1).Value = keyText
    ws.Cells(r, 2).Value = keyType
    ws.Cells(r, 3).Value = selectedId
    ws.Cells(r, 4).Value = ImportedPersonNameById(selectedId)
    ws.Cells(r, 5).Value = wsRes.Cells(rowNo, 5).Value
    ws.Cells(r, 6).Value = wsRes.Cells(rowNo, 8).Value
    ws.Cells(r, 7).Value = wsRes.Cells(rowNo, 9).Value
    ws.Cells(r, 8).Value = wsRes.Cells(rowNo, 10).Value
    ws.Cells(r, 9).Value = wsRes.Cells(rowNo, 11).Value
    ws.Cells(r, 10).Value = Now
    ws.Cells(r, 11).Value = wsRes.Cells(rowNo, 17).Value
    ws.Visible = xlSheetVeryHidden
End Sub

Private Sub LoadImportPersonSelectionMemory(ByVal d As Object)
    Dim ws As Worksheet, lastR As Long, r As Long, keyText As String, pid As String
    If d Is Nothing Then Exit Sub
    If Not SheetExists(SH_IMPORT_PERSON_MEMORY) Then Exit Sub
    Set ws = GetSheet(SH_IMPORT_PERSON_MEMORY)
    lastR = LastRow(ws, 1)
    For r = 2 To lastR
        keyText = CellText(ws.Cells(r, 1).Value)
        pid = CellText(ws.Cells(r, 3).Value)
        If Len(keyText) > 0 And ImportedPersonIdExists(pid) Then d(keyText) = pid
    Next r
    ws.Visible = xlSheetVeryHidden
End Sub

Private Function LoadImportPersonManualSelectionMap() As Object
    Dim d As Object, ws As Worksheet, lastR As Long, r As Long
    Dim selectedId As String, keyFull As String, keyName As String
    Set d = CreateObject("Scripting.Dictionary")
    LoadImportPersonSelectionMemory d
    If SheetExists(SH_IMPORT_PERSON_RESOLUTION) Then
        Set ws = GetSheet(SH_IMPORT_PERSON_RESOLUTION)
        lastR = LastRow(ws, 1)
        For r = 3 To lastR
            selectedId = CellText(ws.Cells(r, 15).Value)
            If Len(selectedId) > 0 Then
                If ImportedPersonIdExists(selectedId) Then
                    keyFull = ImportPersonSelectionKey(ws.Cells(r, 5).Value, ws.Cells(r, 8).Value, ws.Cells(r, 9).Value, ws.Cells(r, 10).Value, ws.Cells(r, 11).Value)
                    keyName = ImportPersonNameKey(ws.Cells(r, 5).Value)
                    If Len(keyFull) > 0 Then d("F|" & keyFull) = selectedId
                    If Len(keyName) > 0 Then
                        If d.Exists("N|" & keyName) Then
                            If d("N|" & keyName) <> selectedId Then d("N|" & keyName) = "#AMBIG#"
                        Else
                            d("N|" & keyName) = selectedId
                        End If
                    End If
                End If
            End If
        Next r
    End If
    Set LoadImportPersonManualSelectionMap = d
End Function

Private Function ManualResolvedPersonIdForImport(ByVal personName As String, _
        ByVal bankName As String, _
        ByVal branchName As String, _
        ByVal accType As String, _
        ByVal accNo As String) As String
    Dim keyFull As String, keyName As String, hit As String
    If mImportManualSelection Is Nothing Then Set mImportManualSelection = LoadImportPersonManualSelectionMap()
    If mImportManualSelection Is Nothing Then Exit Function
    keyFull = ImportPersonSelectionKey(personName, bankName, branchName, accType, accNo)
    If Len(keyFull) > 0 Then
        If mImportManualSelection.Exists("F|" & keyFull) Then
            hit = CellText(mImportManualSelection("F|" & keyFull))
            If ImportedPersonIdExists(hit) Then ManualResolvedPersonIdForImport = hit
            Exit Function
        End If
    End If
    keyName = ImportPersonNameKey(personName)
    If Len(keyName) > 0 Then
        If mImportManualSelection.Exists("N|" & keyName) Then
            hit = CellText(mImportManualSelection("N|" & keyName))
            If hit <> "#AMBIG#" Then
                If ImportedPersonIdExists(hit) Then ManualResolvedPersonIdForImport = hit
            End If
        End If
    End If
End Function

Private Function ImportPersonSelectionKey(ByVal personName As Variant, _
        ByVal bankName As Variant, _
        ByVal branchName As Variant, _
        ByVal accType As Variant, _
        ByVal accNo As Variant) As String
    Dim nameKey As String
    nameKey = ImportPersonNameKey(personName)
    If Len(nameKey) = 0 Then Exit Function
    ImportPersonSelectionKey = nameKey & "|" & NormalizeExternalText(bankName) & "|" & NormalizeExternalText(branchName) & "|" & NormalizeExternalText(accType) & "|" & NormalizeExternalText(accNo)
End Function

Private Function ImportPersonNameKey(ByVal personName As Variant) As String
    ImportPersonNameKey = NormalizeExternalText(BasePersonName(personName))
End Function

Public Function ImportedPersonIdExists(ByVal personId As String) As Boolean
    Dim ws As Worksheet, lastR As Long, r As Long
    personId = CellText(personId)
    If Len(personId) = 0 Then Exit Function
    If SheetExists(SH_WORK_PERSON_REF) Then
        Set ws = GetSheet(SH_WORK_PERSON_REF)
        lastR = LastRow(ws, 1)
        For r = 2 To lastR
            If CellText(ws.Cells(r, 1).Value) = personId Then ImportedPersonIdExists = True: Exit Function
        Next r
    End If
    If SheetExists(SH_PERSON_CAND) Then
        Set ws = GetSheet(SH_PERSON_CAND)
        lastR = LastRow(ws, 1)
        For r = 2 To lastR
            If CellText(ws.Cells(r, 2).Value) = personId Then ImportedPersonIdExists = True: Exit Function
        Next r
    End If
End Function

Private Function AppendMemoText(ByVal oldMemo As Variant, ByVal addMemo As String) As String
    AppendMemoText = CellText(oldMemo)
    If Len(AppendMemoText) > 0 Then AppendMemoText = AppendMemoText & vbCrLf
    AppendMemoText = AppendMemoText & addMemo
End Function

Public Function RebuildBalancesFromTransactionAfterBalance(Optional ByVal clearOldImported As Boolean = False) As Long
    Dim wsTx As Worksheet, wsBal As Worksheet, accounts As Object, labels As Collection, dates As Collection
    Dim accId As Variant, i As Long, srcRow As Long, balValue As Variant, sourceDate As Variant, sourceRow As Long
    If Not SheetExists(SH_WORK_TX) Or Not SheetExists(SH_WORK_BAL) Then Exit Function
    Set wsTx = GetSheet(SH_WORK_TX)
    Set wsBal = GetSheet(SH_WORK_BAL)
    Set accounts = BuildAccountsWithTransactionAfterBalance(wsTx)
    If accounts.Count = 0 Then Exit Function
    BuildBalanceCollections labels, dates
    If clearOldImported Then ClearImportedBalanceRows wsTx, wsBal

    For Each accId In accounts.Keys
        srcRow = CLng(accounts(accId))
        For i = 1 To dates.Count
            If LatestTransactionAfterBalance(wsTx, CStr(accId), CDate(dates(i)), balValue, sourceDate, sourceRow) Then
                UpsertImportedBalanceRows wsTx, wsBal, srcRow, CellText(labels(i)), CDate(dates(i)), balValue, CDate(sourceDate), sourceRow
                RebuildBalancesFromTransactionAfterBalance = RebuildBalancesFromTransactionAfterBalance + 1
            Else
                AddCheck "�m�F", SH_WORK_TX & " / " & CStr(accId), Format$(CDate(dates(i)), "yyyy/m/d") & " �ȑO�̎�����׎c�����Ȃ����߁A�c���⊮�ł��܂���ł����B"
            End If
        Next i
    Next accId
End Function

Private Function BuildAccountsWithTransactionAfterBalance(ByVal wsTx As Worksheet) As Object
    Dim d As Object, lastR As Long, r As Long, accId As String
    Set d = CreateObject("Scripting.Dictionary")
    If wsTx Is Nothing Then Set BuildAccountsWithTransactionAfterBalance = d: Exit Function
    lastR = LastRow(wsTx, 1)
    For r = 2 To lastR
        If CellText(wsTx.Cells(r, WORK_TX_COL_ROW_KIND).Value) = ROW_KIND_TRANSACTION And _
           CellText(wsTx.Cells(r, WORK_TX_COL_DATA_STATUS).Value) <> DATA_STATUS_CANCELLED Then
            accId = CellText(wsTx.Cells(r, WORK_TX_COL_ACCOUNT_ID).Value)
            If Len(accId) > 0 And Len(CellText(TransactionAfterBalanceFromWorkRow(wsTx, r))) > 0 Then
                If Not d.Exists(accId) Then d.Add accId, r
            End If
        End If
    Next r
    Set BuildAccountsWithTransactionAfterBalance = d
End Function

Private Function LatestTransactionAfterBalance(ByVal wsTx As Worksheet, ByVal accountId As String, ByVal targetDate As Date, _
                                               ByRef balValue As Variant, ByRef sourceDate As Variant, ByRef sourceRow As Long) As Boolean
    Dim lastR As Long, r As Long, d As Variant, t As Variant, amountValue As Variant
    Dim bestDate As Date, bestTime As Double, bestOrder As Double, curTime As Double, curOrder As Double
    Dim candidateDate As Date
    Dim bestHasTime As Boolean, curHasTime As Boolean, useCandidate As Boolean
    If wsTx Is Nothing Then Exit Function
    bestDate = DateSerial(1900, 1, 1)
    lastR = LastRow(wsTx, 1)
    For r = 2 To lastR
        If CellText(wsTx.Cells(r, WORK_TX_COL_ROW_KIND).Value) = ROW_KIND_TRANSACTION And _
           CellText(wsTx.Cells(r, WORK_TX_COL_ACCOUNT_ID).Value) = accountId And _
           CellText(wsTx.Cells(r, WORK_TX_COL_DATA_STATUS).Value) <> DATA_STATUS_CANCELLED Then
            d = ImportedDateValue(wsTx.Cells(r, OUT_COL_DATE).Value)
            If IsDate(d) Then
                If DateValue(CDate(d)) <= DateValue(targetDate) Then
                    amountValue = TransactionAfterBalanceFromWorkRow(wsTx, r)
                    If Len(CellText(amountValue)) > 0 Then
                        curHasTime = IsDate(wsTx.Cells(r, OUT_COL_TIME).Value)
                        curTime = 0
                        If curHasTime Then curTime = CDbl(TimeValue(CDate(wsTx.Cells(r, OUT_COL_TIME).Value)))
                        curOrder = r
                        If IsNumeric(wsTx.Cells(r, WORK_TX_COL_INPUT_ORDER).Value) Then curOrder = CDbl(wsTx.Cells(r, WORK_TX_COL_INPUT_ORDER).Value)
                        candidateDate = DateValue(CDate(d))
                        useCandidate = False
                        If Not LatestTransactionAfterBalance Then
                            useCandidate = True
                        ElseIf candidateDate > bestDate Then
                            useCandidate = True
                        ElseIf candidateDate = bestDate Then
                            If IsLaterSameDayTransaction(curHasTime, curTime, curOrder, r, bestHasTime, bestTime, bestOrder, sourceRow) Then useCandidate = True
                        End If
                        If useCandidate Then
                            LatestTransactionAfterBalance = True
                            bestDate = candidateDate
                            bestHasTime = curHasTime
                            bestTime = curTime
                            bestOrder = curOrder
                            balValue = amountValue
                            sourceDate = DateValue(CDate(d))
                            sourceRow = r
                        End If
                    End If
                End If
            End If
        End If
    Next r
End Function

Private Function IsLaterSameDayTransaction(ByVal curHasTime As Boolean, ByVal curTime As Double, ByVal curOrder As Double, ByVal curRow As Long, _
                                           ByVal bestHasTime As Boolean, ByVal bestTime As Double, ByVal bestOrder As Double, ByVal bestRow As Long) As Boolean
    '�o���Ɏ���������ꍇ�����������Ŕ�r����B�Е��ł������Ȃ��Ȃ�A0:00/�����֊񂹂����ד������Ŕ�r����B
    If curHasTime And bestHasTime Then
        If curTime <> bestTime Then
            IsLaterSameDayTransaction = (curTime > bestTime)
            Exit Function
        End If
    End If
    If curOrder <> bestOrder Then
        IsLaterSameDayTransaction = (curOrder > bestOrder)
    Else
        IsLaterSameDayTransaction = (curRow > bestRow)
    End If
End Function

Private Sub UpsertImportedBalanceRows(ByVal wsTx As Worksheet, ByVal wsBal As Worksheet, ByVal srcRow As Long, ByVal labelText As String, _
                                      ByVal balDate As Date, ByVal balValue As Variant, ByVal sourceDate As Date, ByVal sourceRow As Long)
    Dim rTx As Long, rBal As Long, accountId As String, personId As String, transferId As String, balanceId As String, noteText As String
    accountId = CellText(wsTx.Cells(srcRow, WORK_TX_COL_ACCOUNT_ID).Value)
    personId = CellText(wsTx.Cells(srcRow, WORK_TX_COL_PERSON_ID).Value)
    transferId = CellText(wsTx.Cells(srcRow, WORK_TX_COL_TRANSFER_ID).Value)
    noteText = IMPORT_BALANCE_SOURCE & "�i�ŏI�m�F�� " & Format$(sourceDate, "yyyy/m/d") & " / " & SH_WORK_TX & " " & CStr(sourceRow) & "�s�j"

    rTx = FindWorkTxBalanceRow(wsTx, accountId, balDate, labelText)
    If rTx = 0 Then
        rTx = LastRow(wsTx, 1) + 1
        If rTx < 2 Then rTx = 2
    End If
    wsTx.Cells(rTx, OUT_COL_BANK).Value = wsTx.Cells(srcRow, OUT_COL_BANK).Value
    wsTx.Cells(rTx, OUT_COL_BRANCH).Value = wsTx.Cells(srcRow, OUT_COL_BRANCH).Value
    wsTx.Cells(rTx, OUT_COL_PERSON).Value = wsTx.Cells(srcRow, OUT_COL_PERSON).Value
    wsTx.Cells(rTx, OUT_COL_ACCOUNT_TYPE).Value = wsTx.Cells(srcRow, OUT_COL_ACCOUNT_TYPE).Value
    wsTx.Cells(rTx, OUT_COL_ACCOUNT_NO).Value = wsTx.Cells(srcRow, OUT_COL_ACCOUNT_NO).Value
    wsTx.Cells(rTx, OUT_COL_DATE).Value = balDate
    wsTx.Cells(rTx, OUT_COL_TEKIYO).Value = labelText & " �c��"
    wsTx.Cells(rTx, OUT_COL_MACHINE).Value = IMPORT_BALANCE_SOURCE
    wsTx.Cells(rTx, OUT_COL_OTHER).Value = balValue
    wsTx.Cells(rTx, WORK_TX_COL_AFTER_BALANCE).Value = balValue
    wsTx.Cells(rTx, WORK_TX_COL_AFTER_BALANCE_RAW).Value = CellText(balValue)
    wsTx.Cells(rTx, WORK_TX_COL_BALANCE_SOURCE).Value = IMPORT_BALANCE_SOURCE
    wsTx.Cells(rTx, WORK_TX_COL_RELATIONSHIP).Value = wsTx.Cells(srcRow, WORK_TX_COL_RELATIONSHIP).Value
    RegisterWorkTxMeta wsTx, rTx, personId, accountId, "", ROW_KIND_BALANCE, transferId, 0, 0, CellText(wsTx.Cells(srcRow, OUT_COL_BRANCH).Value)

    rBal = FindWorkBalanceRow(wsBal, accountId, balDate, labelText)
    If rBal = 0 Then
        rBal = LastRow(wsBal, 1) + 1
        If rBal < 2 Then rBal = 2
        balanceId = NextBalanceId()
    Else
        balanceId = CellText(wsBal.Cells(rBal, WORK_BAL_COL_BALANCE_ID).Value)
        If Len(balanceId) = 0 Then balanceId = NextBalanceId()
    End If
    wsBal.Cells(rBal, 1).Value = wsTx.Cells(srcRow, OUT_COL_PERSON).Value
    wsBal.Cells(rBal, 2).Value = wsTx.Cells(srcRow, OUT_COL_BANK).Value
    wsBal.Cells(rBal, 3).Value = wsTx.Cells(srcRow, OUT_COL_BRANCH).Value
    wsBal.Cells(rBal, 4).Value = wsTx.Cells(srcRow, OUT_COL_ACCOUNT_TYPE).Value
    wsBal.Cells(rBal, 5).Value = wsTx.Cells(srcRow, OUT_COL_ACCOUNT_NO).Value
    wsBal.Cells(rBal, 8).Value = balDate
    wsBal.Cells(rBal, 9).Value = labelText
    wsBal.Cells(rBal, 10).Value = balValue
    wsBal.Cells(rBal, 11).Value = noteText
    wsBal.Cells(rBal, WORK_BAL_COL_RELATIONSHIP).Value = wsTx.Cells(srcRow, WORK_TX_COL_RELATIONSHIP).Value
    RegisterWorkBalMeta wsBal, rBal, personId, accountId, balanceId, transferId
End Sub

Private Function FindWorkTxBalanceRow(ByVal ws As Worksheet, ByVal accountId As String, ByVal balDate As Date, ByVal labelText As String) As Long
    Dim r As Long, lastR As Long
    If ws Is Nothing Then Exit Function
    lastR = LastRow(ws, 1)
    For r = 2 To lastR
        If CellText(ws.Cells(r, WORK_TX_COL_ACCOUNT_ID).Value) = accountId And _
           CellText(ws.Cells(r, WORK_TX_COL_ROW_KIND).Value) = ROW_KIND_BALANCE And _
           IsDate(ws.Cells(r, OUT_COL_DATE).Value) Then
            If DateValue(CDate(ws.Cells(r, OUT_COL_DATE).Value)) = DateValue(balDate) Then
                If InStr(1, CellText(ws.Cells(r, OUT_COL_MACHINE).Value), IMPORT_BALANCE_SOURCE, vbTextCompare) > 0 Then
                    FindWorkTxBalanceRow = r
                    Exit Function
                End If
            End If
        End If
    Next r
End Function

Private Function FindWorkBalanceRow(ByVal ws As Worksheet, ByVal accountId As String, ByVal balDate As Date, ByVal labelText As String) As Long
    Dim r As Long, lastR As Long
    If ws Is Nothing Then Exit Function
    lastR = LastRow(ws, 1)
    For r = 2 To lastR
        If CellText(ws.Cells(r, WORK_BAL_COL_ACCOUNT_ID).Value) = accountId And IsDate(ws.Cells(r, 8).Value) Then
            If DateValue(CDate(ws.Cells(r, 8).Value)) = DateValue(balDate) Then
                If InStr(1, CellText(ws.Cells(r, 11).Value), IMPORT_BALANCE_SOURCE, vbTextCompare) > 0 Then
                    FindWorkBalanceRow = r
                    Exit Function
                End If
            End If
        End If
    Next r
End Function

Private Sub ClearImportedBalanceRows(ByVal wsTx As Worksheet, ByVal wsBal As Worksheet)
    Dim r As Long
    If Not wsTx Is Nothing Then
        For r = LastRow(wsTx, 1) To 2 Step -1
            If CellText(wsTx.Cells(r, WORK_TX_COL_ROW_KIND).Value) = ROW_KIND_BALANCE And _
               InStr(1, CellText(wsTx.Cells(r, OUT_COL_MACHINE).Value), IMPORT_BALANCE_SOURCE, vbTextCompare) > 0 Then
                wsTx.Rows(r).Delete
            End If
        Next r
    End If
    If Not wsBal Is Nothing Then
        For r = LastRow(wsBal, 1) To 2 Step -1
            If InStr(1, CellText(wsBal.Cells(r, 11).Value), IMPORT_BALANCE_SOURCE, vbTextCompare) > 0 Then wsBal.Rows(r).Delete
        Next r
    End If
End Sub

Private Function BuildExistingTransactionNaturalKeys(ByVal wsTx As Worksheet) As Object
    Dim d As Object, r As Long, lastR As Long, k As String
    Set d = CreateObject("Scripting.Dictionary")
    If wsTx Is Nothing Then Set BuildExistingTransactionNaturalKeys = d: Exit Function
    lastR = LastRow(wsTx, 1)
    For r = 2 To lastR
        If CellText(wsTx.Cells(r, WORK_TX_COL_ROW_KIND).Value) = ROW_KIND_TRANSACTION And _
           CellText(wsTx.Cells(r, WORK_TX_COL_DATA_STATUS).Value) <> DATA_STATUS_CANCELLED Then
            k = ImportedNaturalKey(CellText(wsTx.Cells(r, WORK_TX_COL_ACCOUNT_ID).Value), wsTx.Cells(r, OUT_COL_DATE).Value, wsTx.Cells(r, OUT_COL_TIME).Value, _
                                   wsTx.Cells(r, OUT_COL_WITHDRAW).Value, wsTx.Cells(r, OUT_COL_DEPOSIT).Value, wsTx.Cells(r, OUT_COL_SHOP).Value, _
                                   wsTx.Cells(r, OUT_COL_MACHINE).Value, wsTx.Cells(r, OUT_COL_TEKIYO).Value, TransactionAfterBalanceFromWorkRow(wsTx, r))
            If Not d.Exists(k) Then d.Add k, True
        End If
    Next r
    Set BuildExistingTransactionNaturalKeys = d
End Function

Private Function ImportedNaturalKey(ByVal accountId As String, ByVal txDate As Variant, ByVal txTime As Variant, ByVal outAmt As Variant, ByVal inAmt As Variant, _
                                    ByVal shopText As Variant, ByVal machineText As Variant, ByVal summaryText As Variant, ByVal otherValue As Variant) As String
    Dim dateText As String, timeText As String
    If IsDate(txDate) Then dateText = Format$(DateValue(CDate(txDate)), "yyyymmdd") Else dateText = NormalizeExternalText(txDate)
    If IsDate(txTime) Then timeText = Format$(TimeValue(CDate(txTime)), "hhmmss") Else timeText = NormalizeExternalText(txTime)
    ImportedNaturalKey = CellText(accountId) & "|" & dateText & "|" & timeText & "|" & _
                         NormalizeAmountKey(outAmt) & "|" & NormalizeAmountKey(inAmt) & "|" & _
                         NormalizeExternalText(shopText) & "|" & NormalizeExternalText(machineText) & "|" & NormalizeExternalText(summaryText) & "|" & NormalizeAmountKey(otherValue)
End Function

Private Function ExternalHeaderCol(ByVal ws As Worksheet, ByVal headerRow As Long, ByVal names As Variant, Optional ByVal defaultCol As Long = 0) As Long
    Dim c As Long, maxC As Long, i As Long, head As String, needle As String
    If ws Is Nothing Or headerRow <= 0 Then Exit Function
    maxC = ws.Cells(headerRow, ws.Columns.Count).End(xlToLeft).Column
    For c = 1 To maxC
        head = NormalizeExternalText(ws.Cells(headerRow, c).Value)
        For i = LBound(names) To UBound(names)
            needle = NormalizeExternalText(CStr(names(i)))
            If head = needle Then ExternalHeaderCol = c: Exit Function
        Next i
    Next c
    ExternalHeaderCol = defaultCol
End Function

Private Function ImportedDateValue(ByVal v As Variant) As Variant
    Dim s As String, eraDate As Variant
    If IsDate(v) Then ImportedDateValue = DateValue(CDate(v)): Exit Function
    s = NormalizeExternalDateText(v)
    If Len(s) = 0 Then Exit Function
    eraDate = JapaneseEraDateValue(s)
    If IsDate(eraDate) Then ImportedDateValue = DateValue(CDate(eraDate)): Exit Function
    s = Replace$(s, "�N", "/")
    s = Replace$(s, "��", "/")
    s = Replace$(s, "��", "")
    s = Replace$(s, ".", "/")
    s = Replace$(s, "-", "/")
    If IsDate(s) Then ImportedDateValue = DateValue(CDate(s))
End Function

Private Function NormalizeExternalDateText(ByVal v As Variant) As String
    Dim s As String
    s = CellText(v)
    On Error Resume Next
    s = StrConv(s, vbNarrow)
    On Error GoTo 0
    s = Replace$(s, " ", "")
    s = Replace$(s, "�@", "")
    s = Replace$(s, "�^", "/")
    s = Replace$(s, "�|", "-")
    s = Replace$(s, "�\", "-")
    NormalizeExternalDateText = s
End Function

Private Function JapaneseEraDateValue(ByVal s As String) As Variant
    Dim era As String, body As String, parts() As String
    Dim eraYear As Long, y As Long, m As Long, d As Long, dt As Date
    s = UCase$(s)
    s = Replace$(s, "�ߘa", "R")
    s = Replace$(s, "����", "H")
    s = Replace$(s, "���a", "S")
    If Len(s) < 2 Then Exit Function
    era = Left$(s, 1)
    If era <> "R" And era <> "H" And era <> "S" Then Exit Function
    body = Mid$(s, 2)
    body = Replace$(body, "�N", "/")
    body = Replace$(body, "��", "/")
    body = Replace$(body, "��", "")
    body = Replace$(body, ".", "/")
    body = Replace$(body, "-", "/")
    parts = Split(body, "/")
    If UBound(parts) < 2 Then Exit Function
    If parts(0) = "��" Then
        eraYear = 1
    ElseIf IsNumeric(parts(0)) Then
        eraYear = CLng(parts(0))
    Else
        Exit Function
    End If
    If Not IsNumeric(parts(1)) Or Not IsNumeric(parts(2)) Then Exit Function
    m = CLng(parts(1))
    d = CLng(parts(2))
    Select Case era
        Case "R": y = 2018 + eraYear
        Case "H": y = 1988 + eraYear
        Case "S": y = 1925 + eraYear
    End Select
    If y < 1900 Or m < 1 Or m > 12 Or d < 1 Or d > 31 Then Exit Function
    On Error GoTo InvalidDate
    dt = DateSerial(y, m, d)
    If Year(dt) = y And Month(dt) = m And Day(dt) = d Then JapaneseEraDateValue = dt
    Exit Function
InvalidDate:
    JapaneseEraDateValue = Empty
End Function

Private Function LooseAmountOrBlank(ByVal v As Variant) As Variant
    Dim s As String, negByParen As Boolean
    If IsNumeric(v) Then LooseAmountOrBlank = CDbl(v): Exit Function
    s = CellText(v)
    If Len(s) = 0 Then LooseAmountOrBlank = "": Exit Function
    On Error Resume Next
    s = StrConv(s, vbNarrow)
    On Error GoTo 0
    s = Replace$(s, ",", "")
    s = Replace$(s, "�~", "")
    s = Replace$(s, "��", "")
    s = Replace$(s, "��", "")
    s = Replace$(s, "�c��", "")
    s = Replace$(s, "�����", "")
    s = Replace$(s, "����", "")
    s = Replace$(s, "�F", "")
    s = Replace$(s, ":", "")
    s = Replace$(s, vbTab, "")
    s = Replace$(s, " ", "")
    s = Replace$(s, "�@", "")
    s = Replace$(s, "��", "-")
    s = Replace$(s, "��", "-")
    s = Replace$(s, "�|", "-")
    s = Replace$(s, "�|", "-")
    If Left$(s, 1) = "(" And Right$(s, 1) = ")" Then
        negByParen = True
        s = Mid$(s, 2, Len(s) - 2)
    End If
    If IsNumeric(s) Then
        LooseAmountOrBlank = IIf(negByParen, -CDbl(s), CDbl(s))
    Else
        LooseAmountOrBlank = ""
    End If
End Function

Private Function NormalizeAmountKey(ByVal v As Variant) As String
    Dim a As Variant
    a = LooseAmountOrBlank(v)
    If Len(CellText(a)) = 0 Then
        NormalizeAmountKey = ""
    Else
        NormalizeAmountKey = Format$(CDbl(a), "0.00")
    End If
End Function

Private Function NormalizeExternalText(ByVal v As Variant) As String
    Dim s As String
    s = CellText(v)
    On Error Resume Next
    s = StrConv(s, vbNarrow)
    On Error GoTo 0
    s = Replace$(s, vbCr, "")
    s = Replace$(s, vbLf, "")
    s = Replace$(s, vbTab, "")
    s = Replace$(s, " ", "")
    s = Replace$(s, "�@", "")
    s = Replace$(s, "�E", "")
    s = Replace$(s, "�", "")
    s = Replace$(s, "��", "��")
    s = Replace$(s, "�", "��")
    s = Replace$(s, "�", "��")
    If Right$(s, 1) = "�l" Then s = Left$(s, Len(s) - 1)
    If Right$(s, 1) = "�a" Then s = Left$(s, Len(s) - 1)
    If Right$(s, 1) = "��" Then s = Left$(s, Len(s) - 1)
    If Right$(s, 2) = "����" Then s = Left$(s, Len(s) - 2)
    NormalizeExternalText = s
End Function

Private Function CarryForwardText(ByVal v As Variant, ByRef lastValue As String) As String
    Dim s As String
    s = CellText(v)
    If Len(s) > 0 Then lastValue = s
    CarryForwardText = lastValue
End Function

Private Function ResolveImportedPersonId(ByVal personName As String, _
        Optional ByVal bankName As String = "", _
        Optional ByVal branchName As String = "", _
        Optional ByVal accType As String = "", _
        Optional ByVal accNo As String = "") As String
    Dim ws As Worksheet, lastR As Long, r As Long, baseName As String, cand As String, hit As String
    ResolveImportedPersonId = ManualResolvedPersonIdForImport(personName, bankName, branchName, accType, accNo)
    If Len(ResolveImportedPersonId) > 0 Then Exit Function
    ResolveImportedPersonId = PersonIdByDisplayName(personName)
    If Len(ResolveImportedPersonId) > 0 Then Exit Function
    If Not SheetExists(SH_PERSON_CAND) Then Exit Function
    baseName = NormalizeExternalText(BasePersonName(personName))
    If Len(baseName) = 0 Then Exit Function
    Set ws = GetSheet(SH_PERSON_CAND)
    lastR = LastRow(ws, 1)
    For r = 2 To lastR
        cand = NormalizeExternalText(BasePersonName(ws.Cells(r, 1).Value))
        If cand = baseName Then
            If Len(hit) > 0 And hit <> CellText(ws.Cells(r, 2).Value) Then
                ResolveImportedPersonId = ""
                Exit Function
            End If
            hit = CellText(ws.Cells(r, 2).Value)
        End If
    Next r
    ResolveImportedPersonId = hit
End Function

Private Function BasePersonName(ByVal v As Variant) As String
    Dim s As String, p As Long
    s = CellText(v)
    p = InStr(1, s, "�i", vbTextCompare)
    If p = 0 Then p = InStr(1, s, "(", vbTextCompare)
    If p > 1 Then s = Left$(s, p - 1)
    BasePersonName = s
End Function

Private Function SourceRowText(ByVal sourcePath As String, ByVal sheetName As String, ByVal rowNo As Long) As String
    SourceRowText = Dir$(sourcePath) & "!" & sheetName & "!" & CStr(rowNo) & "�s"
End Function

Private Function OpenExternalWorkbookReadOnly(ByVal filePath As String) As Workbook
    Dim oldAsk As Boolean
    Dim oldSec As Variant
    Dim errNo As Long, errDesc As String
    On Error GoTo EH
    oldAsk = Application.AskToUpdateLinks
    oldSec = Application.AutomationSecurity
    Application.AskToUpdateLinks = False
    Application.AutomationSecurity = 3 'msoAutomationSecurityForceDisable�B�O���u�b�N���}�N���͐�΂ɋN�����Ȃ��B
    Set OpenExternalWorkbookReadOnly = Workbooks.Open(Filename:=filePath, UpdateLinks:=0, ReadOnly:=True, IgnoreReadOnlyRecommended:=True, Notify:=False, AddToMru:=False, Local:=True)
CleanExit:
    On Error Resume Next
    Application.AutomationSecurity = oldSec
    Application.AskToUpdateLinks = oldAsk
    On Error GoTo 0
    If errNo <> 0 Then Err.Raise errNo, "OpenExternalWorkbookReadOnly", errDesc
    Exit Function
EH:
    errNo = Err.Number
    errDesc = Err.Description
    Resume CleanExit
End Function

Private Function TransactionAfterBalanceFromWorkRow(ByVal ws As Worksheet, ByVal rowNo As Long) As Variant
    Dim v As Variant
    If ws Is Nothing Or rowNo <= 0 Then TransactionAfterBalanceFromWorkRow = "": Exit Function
    v = LooseAmountOrBlank(ws.Cells(rowNo, WORK_TX_COL_AFTER_BALANCE).Value)
    If Len(CellText(v)) = 0 Then
        '����݊��p�B�c����񌳂�����s�����A���u���̑��v������⊮����B
        If Len(CellText(ws.Cells(rowNo, WORK_TX_COL_BALANCE_SOURCE).Value)) > 0 Then
            v = LooseAmountOrBlank(ws.Cells(rowNo, OUT_COL_OTHER).Value)
        End If
    End If
    TransactionAfterBalanceFromWorkRow = v
End Function

﻿Attribute VB_Name = "modExternalImport"
Option Explicit

Private Const PREP_BANK As Long = 1
Private Const PREP_BRANCH As Long = 2
Private Const PREP_PERSON As Long = 3
Private Const PREP_RELATIONSHIP As Long = 4
Private Const PREP_TYPE As Long = 5
Private Const PREP_ACCOUNT_NO As Long = 6
Private Const PREP_DATE As Long = 7
Private Const PREP_TIME As Long = 8
Private Const PREP_WITHDRAW As Long = 9
Private Const PREP_DEPOSIT As Long = 10
Private Const PREP_SHOP As Long = 11
Private Const PREP_MACHINE As Long = 12
Private Const PREP_TEKIYO As Long = 13
Private Const PREP_AFTER_BALANCE As Long = 14
Private Const PREP_RECORD_TYPE As Long = 15
Private Const PREP_INPUT_ORDER As Long = 16
Private Const PREP_LAST_COL As Long = 16
Private Const MAX_EXTERNAL_DATA_ROWS As Long = 100000
Private Const MAX_EXTERNAL_COLUMNS As Long = 200
Private Const MAX_SOURCE_SHEETS As Long = 100
Private Const MAX_COMMON_TOTAL_ROWS As Long = 100000
Private Const EXTERNAL_PREPARED_WORK_FACTOR As Double = 13#
Private Const EXTERNAL_INTERNAL_STORE_WORK_FACTOR As Double = 5#
Private Const EXTERNAL_CANDIDATE_STORE_WORK_FACTOR As Double = 8#
Private Const STORE_SNAPSHOT_VALUE2 As Long = 1
Private Const STORE_SNAPSHOT_PREFIX As Long = 2
Private Const STORE_SNAPSHOT_ITEM_COUNT As Long = 2
Private Const SHEET_SNAPSHOT_VALUE2 As Long = 1
Private Const SHEET_SNAPSHOT_FORMULA As Long = 2
Private Const SHEET_SNAPSHOT_HAS_FORMULA As Long = 3
Private Const SHEET_SNAPSHOT_PREFIX As Long = 4
Private Const SHEET_SNAPSHOT_ITEM_COUNT As Long = 4
Private Const SHEET_SNAPSHOT_CHUNK_ROWS As Long = 500
Private Const EXTERNAL_IMPORT_RECOVERY_FATAL_ERROR As Long = vbObjectError + 4499
Private Const EXTERNAL_IMPORT_RECOVERY_FATAL_SOURCE As String = _
    "ExternalImportRecoveryFatal/"

'13列取込の「取引後残高」から年末値を派生するときの公開列契約。
'W_残高へ複製保存せず、帳票作成側がW_取引の正本から都度利用する。
Public Const DERIVED_YEAR_END_COL_ACCOUNT_ID As Long = 1
Public Const DERIVED_YEAR_END_COL_YEAR As Long = 2
Public Const DERIVED_YEAR_END_COL_DATE As Long = 3
Public Const DERIVED_YEAR_END_COL_BALANCE As Long = 4
Public Const DERIVED_YEAR_END_COL_SOURCE_DATE As Long = 5
Public Const DERIVED_YEAR_END_COL_TRANSACTION_ID As Long = 6
Public Const DERIVED_YEAR_END_COL_CARRIED As Long = 7
Public Const DERIVED_YEAR_END_COL_INPUT_ORDER As Long = 8
Public Const DERIVED_YEAR_END_LAST_COL As Long = 8

Private Const DERIVED_YEAR_END_MAX_YEARS As Long = 200
Private Const DERIVED_YEAR_END_MAX_ROWS As Long = 1000000
Private Const DERIVED_CAND_BALANCE As Long = 0
Private Const DERIVED_CAND_DATE As Long = 1
Private Const DERIVED_CAND_TRANSACTION_ID As Long = 2
Private Const DERIVED_CAND_INPUT_ORDER As Long = 3
Private Const DERIVED_CAND_TIME_KNOWN As Long = 4
Private Const DERIVED_CAND_TIME_VALUE As Long = 5
Private Const DERIVED_CAND_SOURCE_ROW As Long = 6
Private Const DERIVED_DAY_ACCOUNT_ID As Long = 0
Private Const DERIVED_DAY_SOURCE_YEAR As Long = 1
Private Const DERIVED_DAY_ALL_TIMES_KNOWN As Long = 2
Private Const DERIVED_DAY_TIME_WINNER As Long = 3
Private Const DERIVED_DAY_INPUT_WINNER As Long = 4


'W_取引の13列目は各取引直後の残高であり、年末残高そのものではない。
'口座・年ごとの最後の確定値を選び、取引後残高がない年は直前の確定値を
'繰り越す。結果は派生値であり、W_残高へは書き込まない。
'
'transactionDataはW_取引の既存1始まり21列schemaをそのまま渡す。
'参照列はOUT_COL_DATE(6)、OUT_COL_TIME(7)、OUT_COL_OTHER(13)、
'WORK_TX_COL_ACCOUNT_ID(15)、WORK_TX_COL_TRANSACTION_ID(17)、
'WORK_TX_COL_RECORD_TYPE(18)、WORK_TX_COL_INPUT_ORDER(19)である。
'resultDataは上のDERIVED_YEAR_END_COL_*で固定した1始まり8列schemaを返す。
'
'同一口座・同一日の全候補に時刻があれば時刻を優先する。1件でも
'時刻がなければ、時刻を推定せず全候補の入力順を使う。同順位なら元配列の後行を採用する。
Public Function DeriveYearEndBalancesFromTransactions( _
        ByRef transactionData As Variant, ByVal firstYear As Long, _
        ByVal lastYear As Long, ByRef resultData As Variant, _
        ByRef problems As String) As Boolean
    Dim firstRow As Long, lastRow As Long, hasRows As Boolean
    Dim sourceRow As Long, targetYear As Long, sourceYear As Long
    Dim yearCount As Long, resultCount As Long, writeRow As Long
    Dim accountID As String, recordType As String, transactionID As String
    Dim keyText As String, dayKeyText As String
    Dim accountKey As Variant, dayKey As Variant
    Dim sourceDate As Date, normalizedTime As Variant, amountValue As Variant
    Dim rawBalance As Variant, rawAccountID As Variant, rawDate As Variant
    Dim rawTime As Variant, rawTransactionID As Variant, rawRecordType As Variant
    Dim sourceDateNumber As Double, sourceTimeNumber As Double
    Dim inputOrder As Double, plannedRows As Double
    Dim timeKnown As Boolean, timeOK As Boolean, amountOK As Boolean
    Dim inputOrderOK As Boolean, hasActive As Boolean, carriedForward As Boolean
    Dim candidate As Variant, activeCandidate As Variant, dailyCandidate As Variant
    Dim dayGroup As Variant, timeWinner As Variant, outputData() As Variant
    Dim winnerByAccountYear As Object, seedByAccount As Object
    Dim knownAccounts As Object, dayGroups As Object
    Dim accountOrder As Collection, dayOrder As Collection

    On Error GoTo Failed
    resultData = Empty
    problems = vbNullString
    If firstYear < 100 Or lastYear > 9999 Or firstYear > lastYear Then
        AppendDerivedYearEndProblem problems, _
            "対象年の範囲が不正です（" & CStr(firstYear) & "～" & CStr(lastYear) & "）。"
        Exit Function
    End If
    yearCount = lastYear - firstYear + 1
    If yearCount > DERIVED_YEAR_END_MAX_YEARS Then
        AppendDerivedYearEndProblem problems, _
            "対象年が上限（" & CStr(DERIVED_YEAR_END_MAX_YEARS) & "年）を超えています。"
        Exit Function
    End If
    If Not TryDerivedYearEndMatrixBounds(transactionData, firstRow, lastRow, _
                                          hasRows, problems) Then Exit Function
    If Not hasRows Then
        DeriveYearEndBalancesFromTransactions = True
        Exit Function
    End If

    Set winnerByAccountYear = NewTextDictionary()
    Set seedByAccount = NewTextDictionary()
    Set knownAccounts = NewTextDictionary()
    Set dayGroups = NewTextDictionary()
    Set accountOrder = New Collection
    Set dayOrder = New Collection

    For sourceRow = firstRow To lastRow
        rawRecordType = transactionData(sourceRow, WORK_TX_COL_RECORD_TYPE)
        If DerivedValueIsErrorOrNull(rawRecordType) Then
            AppendDerivedYearEndProblem problems, _
                "W_取引 " & CStr(sourceRow + 1) & "行: 行種別が不正です。"
            GoTo NextDerivedSourceRow
        End If
        recordType = CellText(rawRecordType)
        If StrComp(recordType, RECORD_TRANSACTION, vbBinaryCompare) <> 0 Then _
            GoTo NextDerivedSourceRow

        rawBalance = transactionData(sourceRow, OUT_COL_OTHER)
        If DerivedValueIsErrorOrNull(rawBalance) Then
            AppendDerivedYearEndProblem problems, _
                "W_取引 " & CStr(sourceRow + 1) & "行: 取引後残高が不正です。"
            GoTo NextDerivedSourceRow
        End If
        If Not HasText(rawBalance) Then GoTo NextDerivedSourceRow
        amountValue = TryParseAmount(rawBalance, amountOK)
        If Not amountOK Then
            AppendDerivedYearEndProblem problems, _
                "W_取引 " & CStr(sourceRow + 1) & "行: 取引後残高を数値として解釈できません。"
            GoTo NextDerivedSourceRow
        End If
        If Not HasText(amountValue) Then
            AppendDerivedYearEndProblem problems, _
                "W_取引 " & CStr(sourceRow + 1) & "行: 取引後残高を数値として解釈できません。"
            GoTo NextDerivedSourceRow
        End If

        rawAccountID = transactionData(sourceRow, WORK_TX_COL_ACCOUNT_ID)
        If DerivedValueIsErrorOrNull(rawAccountID) Then
            AppendDerivedYearEndProblem problems, _
                "W_取引 " & CStr(sourceRow + 1) & "行: 取引後残高の口座IDが不正です。"
            GoTo NextDerivedSourceRow
        End If
        accountID = CellText(rawAccountID)
        If Len(accountID) = 0 Then
            AppendDerivedYearEndProblem problems, _
                "W_取引 " & CStr(sourceRow + 1) & "行: 取引後残高の口座IDがありません。"
            GoTo NextDerivedSourceRow
        End If
        If Not IsInternalIdValue(accountID, "A") Then
            AppendDerivedYearEndProblem problems, _
                "W_取引 " & CStr(sourceRow + 1) & _
                "行: 取引後残高の口座ID形式が不正です（" & accountID & "）。"
            GoTo NextDerivedSourceRow
        End If
        rawDate = transactionData(sourceRow, OUT_COL_DATE)
        If DerivedValueIsErrorOrNull(rawDate) Then
            AppendDerivedYearEndProblem problems, _
                "W_取引 " & CStr(sourceRow + 1) & "行: 取引後残高の根拠日を解釈できません。"
            GoTo NextDerivedSourceRow
        End If
        If Not IsDate(rawDate) Then
            AppendDerivedYearEndProblem problems, _
                "W_取引 " & CStr(sourceRow + 1) & "行: 取引後残高の根拠日を解釈できません。"
            GoTo NextDerivedSourceRow
        End If
        sourceDate = DateValue(CDate(rawDate))
        sourceDateNumber = CDbl(sourceDate)
        sourceYear = Year(sourceDate)
        If sourceYear > lastYear Then GoTo NextDerivedSourceRow

        timeKnown = False
        sourceTimeNumber = 0#
        rawTime = transactionData(sourceRow, OUT_COL_TIME)
        If DerivedValueIsErrorOrNull(rawTime) Then
            AppendDerivedYearEndProblem problems, _
                "W_取引 " & CStr(sourceRow + 1) & "行: 時刻がExcelエラーまたはNullです。"
            GoTo NextDerivedSourceRow
        End If
        If HasText(rawTime) Then
            normalizedTime = NormalizeTimeInput(rawTime, timeOK)
            If Not timeOK Then
                AppendDerivedYearEndProblem problems, _
                    "W_取引 " & CStr(sourceRow + 1) & "行: 時刻を解釈できません。"
                GoTo NextDerivedSourceRow
            End If
            If DerivedValueIsErrorOrNull(normalizedTime) Then
                AppendDerivedYearEndProblem problems, _
                    "W_取引 " & CStr(sourceRow + 1) & "行: 時刻を解釈できません。"
                GoTo NextDerivedSourceRow
            End If
            If Not IsDate(normalizedTime) Then
                AppendDerivedYearEndProblem problems, _
                    "W_取引 " & CStr(sourceRow + 1) & "行: 時刻を解釈できません。"
                GoTo NextDerivedSourceRow
            End If
            timeKnown = True
            sourceTimeNumber = CDbl(VBA.TimeValue(CDate(normalizedTime)))
        End If

        inputOrder = DerivedInputOrderValue( _
                         transactionData(sourceRow, WORK_TX_COL_INPUT_ORDER), _
                         sourceRow, inputOrderOK)
        If Not inputOrderOK Then
            AppendDerivedYearEndProblem problems, _
                "W_取引 " & CStr(sourceRow + 1) & "行: 入力順を解釈できません。"
            GoTo NextDerivedSourceRow
        End If
        rawTransactionID = transactionData(sourceRow, WORK_TX_COL_TRANSACTION_ID)
        If DerivedValueIsErrorOrNull(rawTransactionID) Then
            AppendDerivedYearEndProblem problems, _
                "W_取引 " & CStr(sourceRow + 1) & "行: 取引IDが不正です。"
            GoTo NextDerivedSourceRow
        End If
        transactionID = CellText(rawTransactionID)
        If Len(transactionID) = 0 Then
            AppendDerivedYearEndProblem problems, _
                "W_取引 " & CStr(sourceRow + 1) & "行: 取引IDがありません。"
            GoTo NextDerivedSourceRow
        End If
        If Not IsInternalIdValue(transactionID, "T") Then
            AppendDerivedYearEndProblem problems, _
                "W_取引 " & CStr(sourceRow + 1) & _
                "行: 取引ID形式が不正です（" & transactionID & "）。"
            GoTo NextDerivedSourceRow
        End If
        candidate = Array(CDbl(amountValue), sourceDateNumber, transactionID, _
                          inputOrder, timeKnown, sourceTimeNumber, sourceRow)

        dayKeyText = DerivedYearEndDayKey(accountID, sourceDate)
        If dayGroups.Exists(dayKeyText) Then
            dayGroup = dayGroups(dayKeyText)
            If Not timeKnown Then _
                dayGroup(DERIVED_DAY_ALL_TIMES_KNOWN) = False
            If timeKnown Then
                timeWinner = dayGroup(DERIVED_DAY_TIME_WINNER)
                If Not IsArray(timeWinner) Then
                    dayGroup(DERIVED_DAY_TIME_WINNER) = candidate
                ElseIf DerivedCandidateIsLaterByKnownTime( _
                           timeWinner, candidate) Then
                    dayGroup(DERIVED_DAY_TIME_WINNER) = candidate
                End If
            End If
            If DerivedCandidateIsLaterByInputOrder( _
                   dayGroup(DERIVED_DAY_INPUT_WINNER), candidate) Then _
                dayGroup(DERIVED_DAY_INPUT_WINNER) = candidate
            dayGroups(dayKeyText) = dayGroup
        Else
            If timeKnown Then
                timeWinner = candidate
            Else
                timeWinner = Empty
            End If
            dayGroup = Array(accountID, sourceYear, timeKnown, _
                             timeWinner, candidate)
            dayGroups.Add dayKeyText, dayGroup
            dayOrder.Add dayKeyText
            If Not knownAccounts.Exists(accountID) Then
                knownAccounts.Add accountID, True
                accountOrder.Add accountID
            End If
        End If
NextDerivedSourceRow:
    Next sourceRow
    If Len(problems) > 0 Then Exit Function

    '同一口座・同一日は先に一つの決定候補へ畳み込む。日内の全候補に
    '時刻がある場合だけ時刻順を使い、1件でも欠落すれば全候補を入力順で
    '決める。これにより3件以上の混在でも物理行順に依存しない。
    For Each dayKey In dayOrder
        dayGroup = dayGroups(CStr(dayKey))
        accountID = CStr(dayGroup(DERIVED_DAY_ACCOUNT_ID))
        sourceYear = CLng(dayGroup(DERIVED_DAY_SOURCE_YEAR))
        If CBool(dayGroup(DERIVED_DAY_ALL_TIMES_KNOWN)) Then
            dailyCandidate = dayGroup(DERIVED_DAY_TIME_WINNER)
        Else
            dailyCandidate = dayGroup(DERIVED_DAY_INPUT_WINNER)
        End If
        If sourceYear < firstYear Then
            If seedByAccount.Exists(accountID) Then
                If DerivedYearEndCandidateIsLater( _
                       seedByAccount(accountID), dailyCandidate) Then _
                    seedByAccount(accountID) = dailyCandidate
            Else
                seedByAccount.Add accountID, dailyCandidate
            End If
        Else
            keyText = DerivedYearEndKey(accountID, sourceYear)
            If winnerByAccountYear.Exists(keyText) Then
                If DerivedYearEndCandidateIsLater( _
                       winnerByAccountYear(keyText), dailyCandidate) Then _
                    winnerByAccountYear(keyText) = dailyCandidate
            Else
                winnerByAccountYear.Add keyText, dailyCandidate
            End If
        End If
    Next dayKey

    plannedRows = CDbl(accountOrder.Count) * CDbl(yearCount)
    If plannedRows > CDbl(DERIVED_YEAR_END_MAX_ROWS) Then
        AppendDerivedYearEndProblem problems, _
            "年末残高の派生件数が安全上限（" & _
            Format$(DERIVED_YEAR_END_MAX_ROWS, "#,##0") & "件）を超える可能性があります。"
        Exit Function
    End If

    For Each accountKey In accountOrder
        accountID = CStr(accountKey)
        hasActive = False
        If seedByAccount.Exists(accountID) Then
            activeCandidate = seedByAccount(accountID)
            hasActive = True
        End If
        For targetYear = firstYear To lastYear
            keyText = DerivedYearEndKey(accountID, targetYear)
            If winnerByAccountYear.Exists(keyText) Then
                activeCandidate = winnerByAccountYear(keyText)
                hasActive = True
            End If
            If hasActive Then resultCount = resultCount + 1
        Next targetYear
    Next accountKey

    If resultCount = 0 Then
        DeriveYearEndBalancesFromTransactions = True
        Exit Function
    End If
    ReDim outputData(1 To resultCount, 1 To DERIVED_YEAR_END_LAST_COL)
    For Each accountKey In accountOrder
        accountID = CStr(accountKey)
        hasActive = False
        If seedByAccount.Exists(accountID) Then
            activeCandidate = seedByAccount(accountID)
            hasActive = True
        End If
        For targetYear = firstYear To lastYear
            keyText = DerivedYearEndKey(accountID, targetYear)
            carriedForward = True
            If winnerByAccountYear.Exists(keyText) Then
                activeCandidate = winnerByAccountYear(keyText)
                hasActive = True
                carriedForward = False
            End If
            If hasActive Then
                writeRow = writeRow + 1
                outputData(writeRow, DERIVED_YEAR_END_COL_ACCOUNT_ID) = accountID
                outputData(writeRow, DERIVED_YEAR_END_COL_YEAR) = targetYear
                outputData(writeRow, DERIVED_YEAR_END_COL_DATE) = _
                    DateSerial(targetYear, 12, 31)
                outputData(writeRow, DERIVED_YEAR_END_COL_BALANCE) = _
                    activeCandidate(DERIVED_CAND_BALANCE)
                outputData(writeRow, DERIVED_YEAR_END_COL_SOURCE_DATE) = _
                    CDate(activeCandidate(DERIVED_CAND_DATE))
                outputData(writeRow, DERIVED_YEAR_END_COL_TRANSACTION_ID) = _
                    CStr(activeCandidate(DERIVED_CAND_TRANSACTION_ID))
                outputData(writeRow, DERIVED_YEAR_END_COL_CARRIED) = carriedForward
                outputData(writeRow, DERIVED_YEAR_END_COL_INPUT_ORDER) = _
                    activeCandidate(DERIVED_CAND_INPUT_ORDER)
            End If
        Next targetYear
    Next accountKey
    If writeRow <> resultCount Then
        AppendDerivedYearEndProblem problems, _
            "年末残高の派生件数が計画値と一致しません。"
        Exit Function
    End If
    resultData = outputData
    DeriveYearEndBalancesFromTransactions = True
    Exit Function
Failed:
    resultData = Empty
    problems = vbNullString
    AppendDerivedYearEndProblem problems, _
        "年末残高の派生を完了できません（Err " & CStr(Err.Number) & _
        "）: " & Err.Description
    DeriveYearEndBalancesFromTransactions = False
End Function

Private Function TryDerivedYearEndMatrixBounds( _
        ByRef transactionData As Variant, ByRef firstRow As Long, _
        ByRef lastRow As Long, ByRef hasRows As Boolean, _
        ByRef problems As String) As Boolean
    Dim firstColumn As Long, lastColumn As Long
    hasRows = False
    If IsEmpty(transactionData) Then
        TryDerivedYearEndMatrixBounds = True
        Exit Function
    End If
    On Error GoTo InvalidMatrix
    firstRow = LBound(transactionData, 1)
    lastRow = UBound(transactionData, 1)
    firstColumn = LBound(transactionData, 2)
    lastColumn = UBound(transactionData, 2)
    If firstRow <> 1 Or firstColumn <> 1 Or _
       lastColumn < WORK_TX_COL_PERSON_ID Or lastRow < firstRow Then _
        GoTo InvalidMatrix
    hasRows = True
    TryDerivedYearEndMatrixBounds = True
    Exit Function
InvalidMatrix:
    AppendDerivedYearEndProblem problems, _
        "W_取引配列は1始まり・1行以上・" & _
        CStr(WORK_TX_COL_PERSON_ID) & _
        "列以上の2次元配列で指定してください。"
End Function

Private Function DerivedInputOrderValue( _
        ByVal valueIn As Variant, ByVal sourceRow As Long, _
        ByRef ok As Boolean) As Double
    ok = False
    If DerivedValueIsErrorOrNull(valueIn) Then Exit Function
    If Not HasText(valueIn) Then
        DerivedInputOrderValue = CDbl(sourceRow)
        ok = True
        Exit Function
    End If
    If Not IsNumeric(valueIn) Then Exit Function
    DerivedInputOrderValue = CDbl(valueIn)
    If DerivedInputOrderValue < 0# Or _
       DerivedInputOrderValue <> Fix(DerivedInputOrderValue) Then Exit Function
    ok = True
End Function

Private Function DerivedValueIsErrorOrNull(ByVal valueIn As Variant) As Boolean
    If IsError(valueIn) Then
        DerivedValueIsErrorOrNull = True
    ElseIf IsNull(valueIn) Then
        DerivedValueIsErrorOrNull = True
    End If
End Function

Private Function DerivedYearEndCandidateIsLater( _
        ByVal existingCandidate As Variant, _
        ByVal newCandidate As Variant) As Boolean
    If CDbl(newCandidate(DERIVED_CAND_DATE)) <> _
       CDbl(existingCandidate(DERIVED_CAND_DATE)) Then
        DerivedYearEndCandidateIsLater = _
            (CDbl(newCandidate(DERIVED_CAND_DATE)) > _
             CDbl(existingCandidate(DERIVED_CAND_DATE)))
        Exit Function
    End If
    If CBool(newCandidate(DERIVED_CAND_TIME_KNOWN)) And _
       CBool(existingCandidate(DERIVED_CAND_TIME_KNOWN)) Then
        If CDbl(newCandidate(DERIVED_CAND_TIME_VALUE)) <> _
           CDbl(existingCandidate(DERIVED_CAND_TIME_VALUE)) Then
            DerivedYearEndCandidateIsLater = _
                (CDbl(newCandidate(DERIVED_CAND_TIME_VALUE)) > _
                 CDbl(existingCandidate(DERIVED_CAND_TIME_VALUE)))
            Exit Function
        End If
    End If
    If CDbl(newCandidate(DERIVED_CAND_INPUT_ORDER)) <> _
       CDbl(existingCandidate(DERIVED_CAND_INPUT_ORDER)) Then
        DerivedYearEndCandidateIsLater = _
            (CDbl(newCandidate(DERIVED_CAND_INPUT_ORDER)) > _
             CDbl(existingCandidate(DERIVED_CAND_INPUT_ORDER)))
        Exit Function
    End If
    DerivedYearEndCandidateIsLater = _
        (CLng(newCandidate(DERIVED_CAND_SOURCE_ROW)) > _
         CLng(existingCandidate(DERIVED_CAND_SOURCE_ROW)))
End Function

Private Function DerivedCandidateIsLaterByKnownTime( _
        ByVal existingCandidate As Variant, _
        ByVal newCandidate As Variant) As Boolean
    If Not CBool(existingCandidate(DERIVED_CAND_TIME_KNOWN)) Or _
       Not CBool(newCandidate(DERIVED_CAND_TIME_KNOWN)) Then _
        Err.Raise vbObjectError + 6243, _
                  "DerivedCandidateIsLaterByKnownTime", _
                  "時刻既知候補以外を時刻順で比較できません。"
    If CDbl(newCandidate(DERIVED_CAND_TIME_VALUE)) <> _
       CDbl(existingCandidate(DERIVED_CAND_TIME_VALUE)) Then
        DerivedCandidateIsLaterByKnownTime = _
            (CDbl(newCandidate(DERIVED_CAND_TIME_VALUE)) > _
             CDbl(existingCandidate(DERIVED_CAND_TIME_VALUE)))
        Exit Function
    End If
    DerivedCandidateIsLaterByKnownTime = _
        DerivedCandidateIsLaterByInputOrder(existingCandidate, newCandidate)
End Function

Private Function DerivedCandidateIsLaterByInputOrder( _
        ByVal existingCandidate As Variant, _
        ByVal newCandidate As Variant) As Boolean
    If CDbl(newCandidate(DERIVED_CAND_INPUT_ORDER)) <> _
       CDbl(existingCandidate(DERIVED_CAND_INPUT_ORDER)) Then
        DerivedCandidateIsLaterByInputOrder = _
            (CDbl(newCandidate(DERIVED_CAND_INPUT_ORDER)) > _
             CDbl(existingCandidate(DERIVED_CAND_INPUT_ORDER)))
        Exit Function
    End If
    DerivedCandidateIsLaterByInputOrder = _
        (CLng(newCandidate(DERIVED_CAND_SOURCE_ROW)) > _
         CLng(existingCandidate(DERIVED_CAND_SOURCE_ROW)))
End Function

Private Function DerivedYearEndKey(ByVal accountID As String, _
                                   ByVal targetYear As Long) As String
    DerivedYearEndKey = UCase$(Trim$(accountID)) & Chr$(29) & CStr(targetYear)
End Function

Private Function DerivedYearEndDayKey(ByVal accountID As String, _
                                      ByVal sourceDate As Date) As String
    DerivedYearEndDayKey = UCase$(Trim$(accountID)) & Chr$(28) & _
                           CStr(CLng(DateValue(sourceDate)))
End Function

Private Sub AppendDerivedYearEndProblem(ByRef problems As String, _
                                        ByVal problemText As String)
    Const DETAIL_LIMIT As Long = 30000
    If Len(problems) >= DETAIL_LIMIT Then Exit Sub
    If Len(problems) + Len(problemText) + 3 > DETAIL_LIMIT Then
        problems = Left$(problems, DETAIL_LIMIT - 20) & _
                   "・以降は省略しました。" & vbCrLf
    Else
        problems = problems & "・" & problemText & vbCrLf
    End If
End Sub


Public Sub ImportExternal13ColumnWorkbook()
    Dim filePath As String
    Dim sourceBook As Workbook, alreadyOpenBook As Workbook, sourceSheet As Worksheet
    Dim openBooksBefore As Collection
    Dim wsTx As Worksheet, wsBal As Worksheet, wsAcc As Worksheet
    Dim wsBank As Worksheet, wsBranch As Worksheet, wsPerson As Worksheet
    Dim wsType As Worksheet, wsTekiyo As Worksheet
    Dim previousSecurity As Long
    Dim headerRow As Long, lastRow As Long, lastCol As Long
    Dim values As Variant, prepared() As Variant, mappedColumns As Variant, columnItem As Variant
    Dim bankCol As Long, branchCol As Long, personCol As Long, typeCol As Long, accountCol As Long
    Dim dateCol As Long, timeCol As Long, withdrawCol As Long, depositCol As Long
    Dim shopCol As Long, machineCol As Long, tekiyoCol As Long, balanceCol As Long
    Dim firstDataCol As Long, lastDataCol As Long
    Dim accountSourceCol As Long, shopSourceCol As Long, machineSourceCol As Long
    Dim sourceRow As Long, preparedCount As Long, errorCount As Long
    Dim firstError As String, firstErrorRow As Long
    Dim bankName As String, branchName As String, personName As String, relationshipText As String
    Dim accountType As String, accountNo As String, tekiyoText As String, recordType As String
    Dim shopText As String, machineText As String
    Dim txDate As Variant, txTime As Variant, withdrawValue As Variant, depositValue As Variant, afterBalance As Variant
    Dim ok As Boolean, amountOK As Boolean, securityChanged As Boolean
    Dim sourceBookOwned As Boolean
    Dim dataCommitted As Boolean, postCommitDirtyFailed As Boolean
    Dim postCommitAppRestoreFailed As Boolean, postCommitKeyRestoreFailed As Boolean
    Dim postCommitRecoveryRequired As Boolean
    Dim importedCount As Long, duplicateCount As Long, accountCount As Long
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim postCommitSafetyDetail As String
    Dim appRestoreErrorNumber As Long, appRestoreErrorDescription As String
    Dim cleanupDetail As String
    Dim postCommitWarning As String
    Dim sourceRangeRows As Long, sourceRangeColumns As Long, preparedCapacityRows As Long
    Dim internalStoreRows As Double, candidateStoreRows As Double
    Dim confirmedWorkRows As Double
    Dim entryEvents As Boolean, entryEventsCaptured As Boolean
    Dim applicationLeaseStarted As Boolean, eventsSafeForWorkbookWrites As Boolean
    Dim eventStateDetail As String, finishDetail As String
    Dim recoveryGateDetail As String
    Dim recoveryApplicationDetail As String
    Dim recoveryGateRequired As Boolean, recoveryConfirmed As Boolean
    Dim recoveryApplicationSafe As Boolean
    Dim recoveryEnforcementFailed As Boolean
    Dim recoveryAttempted As Boolean, recoveryTerminalFailure As Boolean

    On Error GoTo EH
    If Not TryGetExternalImportEnableEvents(entryEvents, eventStateDetail) Then
        On Error Resume Next
        MsgBox "外部取込を開始する前にExcelイベント状態を取得できませんでした。" & vbCrLf & _
               "データは変更していません。現在のブックを上書き保存せず、Excelを再起動して確認してください。" & _
               vbCrLf & eventStateDetail, vbCritical, "Excel状態を確認できません"
        On Error GoTo 0
        Exit Sub
    End If
    entryEventsCaptured = True
    If Not TrySetExternalImportEnableEventsExact(False, eventStateDetail) Then _
        Err.Raise vbObjectError + 6242, "ImportExternal13ColumnWorkbook", _
                  "事前確認より前にExcelイベントを停止できませんでした。 " & _
                  eventStateDetail
    eventsSafeForWorkbookWrites = True

    If Not RequireToolReady() Then GoTo PRESTART_EXIT
    If Not RequireWritableWorkbook("外部データの取り込み") Then GoTo PRESTART_EXIT
    '訂正画面は取込開始時点の保存済みデータを複製している。訂正中に外部取込を許すと、
    '後の訂正登録がその古い複製で口座データを再構成し、取込分を消し得るため先に止める。
    If Not RequireNoPendingAccountInput("外部データの取り込み") Then GoTo PRESTART_EXIT
    filePath = PickWorkbookFile("取込元の資金操作表を選択してください", False)
    If Len(filePath) = 0 Then GoTo PRESTART_EXIT
    Set alreadyOpenBook = FindOpenExternalWorkbookByFullName(filePath, openBooksBefore)
    If Not alreadyOpenBook Is Nothing Then
        If alreadyOpenBook Is ThisWorkbook Then
            MsgBox "作業中のツール自身は取込元に指定できません。", vbExclamation
        Else
            MsgBox "指定した取込元ブックはExcelですでに開かれています。" & vbCrLf & _
                   "未保存の編集を保護するため、取込元を閉じてからもう一度実行してください。", _
                   vbExclamation, "開いている取込元"
        End If
        Set alreadyOpenBook = Nothing
        GoTo PRESTART_EXIT
    End If
    AppBegin "外部ブックを安全に読み込んでいます..."
    applicationLeaseStarted = True
    '最初の取込時だけ検証し、以後は取込元データ固有の検査へ直行する。
    previousSecurity = Application.AutomationSecurity
    securityChanged = True
    Application.AutomationSecurity = msoAutomationSecurityForceDisable
    If Application.AutomationSecurity <> msoAutomationSecurityForceDisable Then _
        Err.Raise vbObjectError + 6190, "ImportExternal13ColumnWorkbook", _
                  "取込元を安全に開くためのマクロ無効化を確認できません。データは取り込んでいません。"
    Set sourceBook = Workbooks.Open(Filename:=filePath, UpdateLinks:=0, ReadOnly:=True, _
                                    AddToMru:=False, IgnoreReadOnlyRecommended:=True, Notify:=False)
    If sourceBook Is Nothing Then _
        Err.Raise vbObjectError + 6237, "ImportExternal13ColumnWorkbook", _
                  "取込元ブックを開いた後の参照を取得できません。データは取り込んでいません。"
    If sourceBook Is ThisWorkbook Then
        'EHの共通Close対象から外し、取込拒否のために作業ブック自身を閉じない。
        Set sourceBook = Nothing
        Application.AutomationSecurity = previousSecurity
        If Application.AutomationSecurity <> previousSecurity Then _
            Err.Raise vbObjectError + 6192, "ImportExternal13ColumnWorkbook", _
                      "自己取込を中止した後にExcelのマクロ設定を復元できません。"
        securityChanged = False
        Err.Raise vbObjectError + 6191, "ImportExternal13ColumnWorkbook", _
                  "作業中のツール自身は取込元に指定できません。"
    End If
    'FullNameが同期URL/ローカルパス等の別表記で事前照合をすり抜けても、
    'Open前に保持したオブジェクト参照と同一なら所有ブックにせず、絶対にCloseしない。
    If ExternalWorkbookWasAlreadyOpen(sourceBook, openBooksBefore) Then _
        Err.Raise vbObjectError + 6239, "ImportExternal13ColumnWorkbook", _
                  "取込元はExcelですでに開かれています。" & _
                  "未保存の編集を保護するため、閉じてからもう一度実行してください。"
    sourceBookOwned = True
    If Not sourceBook.ReadOnly Then _
        Err.Raise vbObjectError + 6237, "ImportExternal13ColumnWorkbook", _
                  "取込元を読み取り専用で開いたことを確認できません。データは取り込んでいません。"
    Application.AutomationSecurity = previousSecurity
    If Application.AutomationSecurity <> previousSecurity Then _
        Err.Raise vbObjectError + 6192, "ImportExternal13ColumnWorkbook", _
                  "取込元を開いた後にExcelのマクロ設定を復元できません。"
    securityChanged = False
    If sourceBook.Worksheets.Count > MAX_SOURCE_SHEETS Then
        Err.Raise vbObjectError + 6107, "ImportExternal13ColumnWorkbook", _
                  "取込元のシート数が上限（" & CStr(MAX_SOURCE_SHEETS) & "枚）を超えています。"
    End If
    ValidateImportWorkbookNoExternalDependencies sourceBook, "取込元"
    Set sourceSheet = FindExternalTableSheet(sourceBook, headerRow)
    If sourceSheet Is Nothing Then Err.Raise vbObjectError + 6101, "ImportExternal13ColumnWorkbook", "13列表の見出しを見つけられません。"

    lastCol = ExternalLastUsedColumn(sourceSheet)
    If lastCol > MAX_EXTERNAL_COLUMNS Then
        Err.Raise vbObjectError + 6106, "ImportExternal13ColumnWorkbook", _
                  "使用列が多すぎます。取込表を必要列だけのシートへ整理してください。"
    End If
    If lastCol < 1 Then Err.Raise vbObjectError + 6101, "ImportExternal13ColumnWorkbook", "取込表の列を確認できません。"

    '先に見出し1行だけを読み、実データは認識した列を含む最小範囲に限定する。
    '最大200列×10万行を無条件に配列化せず、通常の13列表でメモリ使用量を大幅に抑える。
    values = sourceSheet.Range(sourceSheet.Cells(headerRow, 1), sourceSheet.Cells(headerRow, lastCol)).Value2

    bankCol = FindHeaderColumn(values, 1)
    branchCol = FindHeaderColumn(values, 2)
    personCol = FindHeaderColumn(values, 3)
    typeCol = FindHeaderColumn(values, 4)
    accountCol = FindHeaderColumn(values, 5)
    dateCol = FindHeaderColumn(values, 6)
    timeCol = FindHeaderColumn(values, 7)       '時刻見出しがなければ0。ほかの列から推測しない。
    withdrawCol = FindHeaderColumn(values, 8)
    depositCol = FindHeaderColumn(values, 9)
    shopCol = FindHeaderColumn(values, 10)
    machineCol = FindHeaderColumn(values, 11)
    tekiyoCol = FindHeaderColumn(values, 12)
    balanceCol = FindHeaderColumn(values, 13)   '第13列は取引後残高。年末残高には転用しない。

    ValidateExternalHeaders bankCol, branchCol, personCol, typeCol, accountCol, dateCol, _
                            withdrawCol, depositCol, shopCol, machineCol, tekiyoCol, balanceCol
    ValidateExternalHeaderUniqueness values

    mappedColumns = Array(bankCol, branchCol, personCol, typeCol, accountCol, dateCol, timeCol, _
                          withdrawCol, depositCol, shopCol, machineCol, tekiyoCol, balanceCol)
    firstDataCol = lastCol
    For Each columnItem In mappedColumns
        If CLng(columnItem) > 0 Then
            If CLng(columnItem) < firstDataCol Then firstDataCol = CLng(columnItem)
            If CLng(columnItem) > lastDataCol Then lastDataCol = CLng(columnItem)
        End If
    Next columnItem
    lastRow = ExternalLastMappedDataRow(sourceSheet, headerRow, mappedColumns)
    If lastRow <= headerRow Then Err.Raise vbObjectError + 6102, "ImportExternal13ColumnWorkbook", "見出しより下に取引データがありません。"
    If lastRow - headerRow > MAX_EXTERNAL_DATA_ROWS Then
        Err.Raise vbObjectError + 6105, "ImportExternal13ColumnWorkbook", _
                  "取込対象は" & Format$(lastRow - headerRow, "#,##0") & _
                  "行で、安全な一括取込上限（" & _
                  Format$(MAX_EXTERNAL_DATA_ROWS, "#,##0") & _
                  "行）を超えています。一部だけを取り込まず中止しました。" & _
                  "外部データを複数ファイルに分割するか、取込元の原本にある不要行・重複行を整理してください。"
    End If

    '大きなRange.Value2、prepared配列、内部整合性検査の配列より先に、同時に必要となる
    '元表セル、取込準備配列、既存8ストアの全規模を16列相当行へ換算して判定する。
    Set wsTx = GetSheet(SH_WORK_TX)
    Set wsBal = GetSheet(SH_WORK_BAL)
    Set wsAcc = GetSheet(SH_WORK_ACCOUNT)
    Set wsBank = GetSheet(SH_BANK_CAND)
    Set wsBranch = GetSheet(SH_BRANCH_CAND)
    Set wsPerson = GetSheet(SH_PERSON_CAND)
    Set wsType = GetSheet(SH_ACCOUNT_TYPE)
    Set wsTekiyo = GetSheet(SH_TEKIYO)
    internalStoreRows = ExternalImportInternalStoreRows( _
                        ExternalDataRows(wsTx, WORK_TX_COL_PERSON_ID), _
                        ExternalDataRows(wsBal, WORK_BAL_COL_PERSON_ID), _
                        ExternalDataRows(wsAcc, ACC_COL_TRANSFER_ID))
    '候補snapshotは見出し行もValue2/Formulaで保持するため、データ行数ではなく
    '実際に退避する行数（最低1行）を事前容量へ含める。
    candidateStoreRows = ExternalImportCandidateStoreRows( _
                         CommonSnapshotRows(wsBank, 4), _
                         CommonSnapshotRows(wsBranch, 4), _
                         CommonSnapshotRows(wsPerson, 4), _
                         CommonSnapshotRows(wsType, 4), _
                         CommonSnapshotRows(wsTekiyo, 4))
    sourceRangeRows = lastRow - headerRow + 1
    sourceRangeColumns = lastDataCol - firstDataCol + 1
    preparedCapacityRows = lastRow - headerRow
    confirmedWorkRows = ExternalImportPreallocationWorkRows( _
                        sourceRangeRows, sourceRangeColumns, preparedCapacityRows, _
                        internalStoreRows, candidateStoreRows)
    If confirmedWorkRows > 2147483647# Then _
        Err.Raise vbObjectError + 6229, "ImportExternal13ColumnWorkbook", _
                  "外部取込の事前安全規模を計算できません。"
    If Not ConfirmLargeArrayOperation(CLng(confirmedWorkRows), _
            "外部データの取り込み（元表・取込配列・既存保管の事前安全検査）") Then
        cleanupDetail = vbNullString
        CloseSourceWorkbookAndRestoreSecurity sourceBook, sourceBookOwned, securityChanged, _
                                                previousSecurity, cleanupDetail
        If Len(cleanupDetail) > 0 Then _
            Err.Raise vbObjectError + 6191, "ImportExternal13ColumnWorkbook", cleanupDetail
        SetInputStatus "外部取込を開始前に中止しました。データは変更していません。"
        FinishExternalImportApplicationLease applicationLeaseStarted, entryEvents, _
            entryEventsCaptured, "外部データ取込", False, finishDetail, _
            recoveryEnforcementFailed, recoveryAttempted, recoveryTerminalFailure
        Exit Sub
    End If
    '追記前は内部保管だけを厳格確認し、画面幅・図形・旧帳票など
    If Not RequireInternalStoresSafeForWrite() Then
        cleanupDetail = vbNullString
        CloseSourceWorkbookAndRestoreSecurity sourceBook, sourceBookOwned, securityChanged, _
                                                previousSecurity, cleanupDetail
        If Len(cleanupDetail) > 0 Then _
            Err.Raise vbObjectError + 6191, "ImportExternal13ColumnWorkbook", cleanupDetail
        FinishExternalImportApplicationLease applicationLeaseStarted, entryEvents, _
            entryEventsCaptured, "外部データ取込", False, finishDetail, _
            recoveryEnforcementFailed, recoveryAttempted, recoveryTerminalFailure
        Exit Sub
    End If
    ValidateExternalMappedColumnsNoFormulas sourceSheet, headerRow, lastRow, mappedColumns

    accountSourceCol = accountCol
    shopSourceCol = shopCol
    machineSourceCol = machineCol
    values = sourceSheet.Range(sourceSheet.Cells(headerRow, firstDataCol), _
                               sourceSheet.Cells(lastRow, lastDataCol)).Value2
    bankCol = bankCol - firstDataCol + 1
    branchCol = branchCol - firstDataCol + 1
    personCol = personCol - firstDataCol + 1
    typeCol = typeCol - firstDataCol + 1
    accountCol = accountCol - firstDataCol + 1
    dateCol = dateCol - firstDataCol + 1
    If timeCol > 0 Then timeCol = timeCol - firstDataCol + 1
    withdrawCol = withdrawCol - firstDataCol + 1
    depositCol = depositCol - firstDataCol + 1
    shopCol = shopCol - firstDataCol + 1
    machineCol = machineCol - firstDataCol + 1
    tekiyoCol = tekiyoCol - firstDataCol + 1
    balanceCol = balanceCol - firstDataCol + 1
    ReDim prepared(1 To UBound(values, 1) - 1, 1 To PREP_LAST_COL)
    For sourceRow = 2 To UBound(values, 1)
        If ExternalArrayRowHasData(values, sourceRow) Then
            AddExternalCellValueError values(sourceRow, bankCol), "銀行名", sourceRow + headerRow - 1, errorCount, firstError, firstErrorRow
            AddExternalCellValueError values(sourceRow, branchCol), "支店名", sourceRow + headerRow - 1, errorCount, firstError, firstErrorRow
            AddExternalCellValueError values(sourceRow, personCol), "氏名", sourceRow + headerRow - 1, errorCount, firstError, firstErrorRow
            AddExternalCellValueError values(sourceRow, typeCol), "科目", sourceRow + headerRow - 1, errorCount, firstError, firstErrorRow
            AddExternalCellValueError values(sourceRow, accountCol), "口座番号", sourceRow + headerRow - 1, errorCount, firstError, firstErrorRow
            AddExternalCellValueError values(sourceRow, dateCol), "日付", sourceRow + headerRow - 1, errorCount, firstError, firstErrorRow
            If timeCol > 0 Then _
                AddExternalCellValueError values(sourceRow, timeCol), "時刻", sourceRow + headerRow - 1, errorCount, firstError, firstErrorRow
            AddExternalCellValueError values(sourceRow, withdrawCol), "出金", sourceRow + headerRow - 1, errorCount, firstError, firstErrorRow
            AddExternalCellValueError values(sourceRow, depositCol), "入金", sourceRow + headerRow - 1, errorCount, firstError, firstErrorRow
            AddExternalCellValueError values(sourceRow, shopCol), "取扱店", sourceRow + headerRow - 1, errorCount, firstError, firstErrorRow
            AddExternalCellValueError values(sourceRow, machineCol), "機番", sourceRow + headerRow - 1, errorCount, firstError, firstErrorRow
            AddExternalCellValueError values(sourceRow, tekiyoCol), "摘要", sourceRow + headerRow - 1, errorCount, firstError, firstErrorRow
            AddExternalCellValueError values(sourceRow, balanceCol), "取引後残高", sourceRow + headerRow - 1, errorCount, firstError, firstErrorRow

            bankName = CellText(values(sourceRow, bankCol))
            branchName = CellText(values(sourceRow, branchCol))
            SplitExternalPerson CellText(values(sourceRow, personCol)), personName, relationshipText
            '取込元に続柄記載がなければ空欄のまま保持する。氏名だけで
            '既存続柄を推定すると、空欄identityを入力済みidentityへ誤統合する。
            accountType = CellText(values(sourceRow, typeCol))
            '表示値は原表の区切りを保持し、一致判定だけをCanonicalAccountKey側で正規化する。
            accountNo = PrepareExternalIdentifier( _
                        values(sourceRow, accountCol), sourceSheet, sourceRow + headerRow - 1, accountSourceCol, _
                        "口座番号", errorCount, firstError, firstErrorRow)
            tekiyoText = CellText(values(sourceRow, tekiyoCol))
            shopText = PrepareExternalIdentifier( _
                       values(sourceRow, shopCol), sourceSheet, sourceRow + headerRow - 1, shopSourceCol, _
                       "取扱店", errorCount, firstError, firstErrorRow)
            machineText = PrepareExternalIdentifier( _
                          values(sourceRow, machineCol), sourceSheet, sourceRow + headerRow - 1, machineSourceCol, _
                          "機番", errorCount, firstError, firstErrorRow)

            '相続開始日の全体行は口座レコードではないため、設定側で再生成する。
            If tekiyoText = "相続開始日" And Len(bankName & accountNo) = 0 Then GoTo NextSourceRow

            If Len(bankName) = 0 Then AddImportError "銀行名が空欄です。", sourceRow + headerRow - 1, errorCount, firstError, firstErrorRow
            If Len(personName) = 0 Then AddImportError "氏名が空欄です。", sourceRow + headerRow - 1, errorCount, firstError, firstErrorRow
            If Len(accountType) = 0 Then AddImportError "科目が空欄です。", sourceRow + headerRow - 1, errorCount, firstError, firstErrorRow
            If Len(accountNo) = 0 Then AddImportError "口座番号が空欄です。", sourceRow + headerRow - 1, errorCount, firstError, firstErrorRow
            AddImportLengthError bankName, 100, "銀行名", sourceRow + headerRow - 1, errorCount, firstError, firstErrorRow
            AddImportLengthError branchName, 100, "支店名", sourceRow + headerRow - 1, errorCount, firstError, firstErrorRow
            AddImportLengthError personName, 100, "氏名", sourceRow + headerRow - 1, errorCount, firstError, firstErrorRow
            AddImportLengthError relationshipText, 50, "続柄", sourceRow + headerRow - 1, errorCount, firstError, firstErrorRow
            AddImportLengthError accountType, 100, "科目", sourceRow + headerRow - 1, errorCount, firstError, firstErrorRow
            AddImportLengthError accountNo, 100, "口座番号", sourceRow + headerRow - 1, errorCount, firstError, firstErrorRow
            AddImportLengthError shopText, 100, "取扱店", sourceRow + headerRow - 1, errorCount, firstError, firstErrorRow
            AddImportLengthError machineText, 100, "機番", sourceRow + headerRow - 1, errorCount, firstError, firstErrorRow
            AddImportLengthError tekiyoText, 500, "摘要", sourceRow + headerRow - 1, errorCount, firstError, firstErrorRow

            txDate = ParseExternalDate(values(sourceRow, dateCol), ok)
            If Not ok Then AddImportError "日付を解釈できません。", sourceRow + headerRow - 1, errorCount, firstError, firstErrorRow
            'VBAのAndは短絡評価されない。時刻列なし（timeCol=0）の時に
            '配列の0列目を参照しないよう、列有無と値有無を段階的に判定する。
            txTime = ""
            If timeCol > 0 Then
                If HasText(values(sourceRow, timeCol)) Then
                    txTime = NormalizeTimeInput(values(sourceRow, timeCol), ok)
                    If Not ok Then AddImportError "時刻を解釈できません。", sourceRow + headerRow - 1, errorCount, firstError, firstErrorRow
                End If
            End If

            withdrawValue = TryParseAmount(values(sourceRow, withdrawCol), amountOK)
            If Not amountOK Then AddImportError "出金額が不正です（有効数字15桁・小数8桁以内）。", sourceRow + headerRow - 1, errorCount, firstError, firstErrorRow
            If amountOK Then
                If HasText(withdrawValue) Then
                    If CDbl(withdrawValue) < 0 Then AddImportError "出金額は0以上で入力してください。", sourceRow + headerRow - 1, errorCount, firstError, firstErrorRow
                End If
            End If
            depositValue = TryParseAmount(values(sourceRow, depositCol), amountOK)
            If Not amountOK Then AddImportError "入金額が不正です（有効数字15桁・小数8桁以内）。", sourceRow + headerRow - 1, errorCount, firstError, firstErrorRow
            If amountOK Then
                If HasText(depositValue) Then
                    If CDbl(depositValue) < 0 Then AddImportError "入金額は0以上で入力してください。", sourceRow + headerRow - 1, errorCount, firstError, firstErrorRow
                End If
            End If
            If HasText(withdrawValue) And HasText(depositValue) Then
                AddImportError "出金と入金の両方に金額があります。", sourceRow + headerRow - 1, errorCount, firstError, firstErrorRow
            End If
            afterBalance = TryParseAmount(values(sourceRow, balanceCol), amountOK)
            If Not amountOK Then AddImportError "取引後残高が不正です（有効数字15桁・小数8桁以内）。", sourceRow + headerRow - 1, errorCount, firstError, firstErrorRow

            Select Case tekiyoText
                Case "口座開設日": recordType = RECORD_OPEN
                Case "口座解約日": recordType = RECORD_CLOSE
                Case Else
                    If IsExternalBalanceRecord(tekiyoText, withdrawValue, depositValue, afterBalance) Then
                        recordType = RECORD_BALANCE
                    Else
                        recordType = RECORD_TRANSACTION
                    End If
            End Select
            If recordType = RECORD_OPEN Or recordType = RECORD_CLOSE Then
                If HasText(withdrawValue) Or HasText(depositValue) Or HasText(afterBalance) Or _
                   Len(shopText) > 0 Or Len(machineText) > 0 Then
                    AddImportError "口座開設日・口座解約日行には入出金、残高、取扱店、機番を入力できません。", _
                                   sourceRow + headerRow - 1, errorCount, firstError, firstErrorRow
                End If
            End If
            If recordType = RECORD_TRANSACTION Then
                If Not HasText(withdrawValue) And Not HasText(depositValue) And Not HasText(afterBalance) And _
                   Len(shopText) = 0 And Len(machineText) = 0 And Len(tekiyoText) = 0 Then
                    AddImportError "日付以外の取引内容がありません。", sourceRow + headerRow - 1, errorCount, firstError, firstErrorRow
                End If
            End If

            preparedCount = preparedCount + 1
            prepared(preparedCount, PREP_BANK) = bankName
            prepared(preparedCount, PREP_BRANCH) = branchName
            prepared(preparedCount, PREP_PERSON) = personName
            prepared(preparedCount, PREP_RELATIONSHIP) = relationshipText
            prepared(preparedCount, PREP_TYPE) = accountType
            prepared(preparedCount, PREP_ACCOUNT_NO) = accountNo
            prepared(preparedCount, PREP_DATE) = txDate
            prepared(preparedCount, PREP_TIME) = txTime
            prepared(preparedCount, PREP_WITHDRAW) = withdrawValue
            prepared(preparedCount, PREP_DEPOSIT) = depositValue
            prepared(preparedCount, PREP_SHOP) = shopText
            prepared(preparedCount, PREP_MACHINE) = machineText
            prepared(preparedCount, PREP_TEKIYO) = tekiyoText
            prepared(preparedCount, PREP_AFTER_BALANCE) = afterBalance
            prepared(preparedCount, PREP_RECORD_TYPE) = recordType
            prepared(preparedCount, PREP_INPUT_ORDER) = sourceRow + headerRow - 1
        End If
NextSourceRow:
    Next sourceRow

    CloseSourceWorkbookAndRestoreSecurity sourceBook, sourceBookOwned, securityChanged, _
                                            previousSecurity, cleanupDetail
    If Len(cleanupDetail) > 0 Then _
        Err.Raise vbObjectError + 6191, "ImportExternal13ColumnWorkbook", cleanupDetail

    If errorCount > 0 Then
        SetInputStatus "外部取込を中止しました（" & errorCount & "件）　" & firstError
        FinishExternalImportApplicationLease applicationLeaseStarted, entryEvents, _
            entryEventsCaptured, "外部データ取込", False, finishDetail, _
            recoveryEnforcementFailed, recoveryAttempted, recoveryTerminalFailure
        MsgBox "外部データには登録できない行があります。データは反映していません。" & vbCrLf & vbCrLf & _
               "最初の問題: " & firstErrorRow & "行　" & firstError & vbCrLf & _
               "問題件数: " & errorCount, vbExclamation, "外部取込の検証結果"
        Exit Sub
    End If
    If preparedCount = 0 Then
        SetInputStatus "取込対象の取引行はありませんでした。"
        FinishExternalImportApplicationLease applicationLeaseStarted, entryEvents, _
            entryEventsCaptured, "外部データ取込", False, finishDetail, _
            recoveryEnforcementFailed, recoveryAttempted, recoveryTerminalFailure
        Exit Sub
    End If

    CommitExternalRows prepared, preparedCount, importedCount, duplicateCount, accountCount, _
                       dataCommitted, postCommitWarning, recoveryGateRequired, _
                       recoveryConfirmed, recoveryEnforcementFailed, _
                       recoveryAttempted, recoveryTerminalFailure, confirmedWorkRows
    eventStateDetail = vbNullString
    If Not TrySetExternalImportEnableEventsExact(False, eventStateDetail) Then _
        Err.Raise vbObjectError + 6241, "ImportExternal13ColumnWorkbook", _
                  "取込後の案内を書き込む前にExcelイベント停止を確認できません: " & _
                  eventStateDetail
    If Len(postCommitWarning) > 0 Then
        If ToolDataHealthIsNormal() Then
            SetInputStatus "外部データは取込済みです。登録済み口座一覧の更新に警告があります。同じ資料を再取込せずC_チェックを確認してください。", True
            If Not FinishExternalImportApplicationLease( _
                       applicationLeaseStarted, entryEvents, entryEventsCaptured, _
                       "外部データ取込", True, finishDetail, _
                       recoveryEnforcementFailed, recoveryAttempted, _
                       recoveryTerminalFailure) Then Exit Sub
            MsgBox "外部データの内部保管への取り込みは完了しました。" & vbCrLf & _
                   "登録済み口座一覧の再構築を安全に完了できなかったため、警告として記録しました。" & vbCrLf & _
                   "同じ資料を再取込せず、C_チェックと登録済み口座を確認してください。" & vbCrLf & vbCrLf & _
                   "新規取込行: " & importedCount & "件" & vbCrLf & _
                   "重複のため除外: " & duplicateCount & "件" & vbCrLf & _
                   "対象口座: " & accountCount & "件", _
                   vbExclamation, "取込済み・後処理警告"
        Else
            SetInputStatus "外部データは取込済みですが、後処理の安全状態を確認できないため通常操作へ戻せません。再取込しないでください。", True
            If Not FinishExternalImportApplicationLease( _
                       applicationLeaseStarted, entryEvents, entryEventsCaptured, _
                       "外部データ取込", True, finishDetail, _
                       recoveryEnforcementFailed, recoveryAttempted, _
                       recoveryTerminalFailure, True, False) Then Exit Sub
            MsgBox "外部データの内部保管への取り込みは完了しましたが、一覧の安全状態を保証できません。" & vbCrLf & _
                   "同じ資料を再取込せず、C_チェックを確認し、現在のブックを上書きしないでください。", _
                   vbCritical, "取込済み・安全状態要確認"
        End If
    Else
        SetInputStatus "外部取込完了　取込行 " & importedCount & "件、口座 " & accountCount & "件。"
        If Not FinishExternalImportApplicationLease( _
                   applicationLeaseStarted, entryEvents, entryEventsCaptured, _
                   "外部データ取込", True, finishDetail, _
                   recoveryEnforcementFailed, recoveryAttempted, _
                   recoveryTerminalFailure) Then Exit Sub
        MsgBox "外部データを取り込みました。" & vbCrLf & _
               "新規取込行: " & importedCount & "件" & vbCrLf & _
               "重複のため除外: " & duplicateCount & "件" & vbCrLf & _
               "対象口座: " & accountCount & "件" & vbCrLf & vbCrLf & _
               "時刻見出しがない資料については、時刻を補完していません。", vbInformation, "外部取込完了"
    End If
    Exit Sub

PRESTART_EXIT:
    If entryEventsCaptured Then _
        FinishExternalImportApplicationLease applicationLeaseStarted, entryEvents, _
            entryEventsCaptured, "外部データ取込", False, finishDetail, _
            recoveryEnforcementFailed, recoveryAttempted, recoveryTerminalFailure
    Exit Sub

EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    If IsExternalImportRecoveryFatal(errorNumber, errorSource) Then _
        RethrowExternalImportRecoveryFatal _
            errorNumber, errorSource, errorDescription
    eventStateDetail = vbNullString
    eventsSafeForWorkbookWrites = _
        TrySetExternalImportEnableEventsExact(False, eventStateDetail)
    If Not eventsSafeForWorkbookWrites Then
        recoveryGateRequired = True
        recoveryConfirmed = False
        AppendExternalDetail postCommitSafetyDetail, _
            "Excelイベント停止を読戻し確認できないため、" & _
            "エラー終了時のブック書込みを見送りました: " & eventStateDetail
    End If

    cleanupDetail = vbNullString
    CloseSourceWorkbookAndRestoreSecurity sourceBook, sourceBookOwned, securityChanged, _
                                            previousSecurity, cleanupDetail
    If Len(cleanupDetail) > 0 Then
        errorDescription = errorDescription & " / 終了処理: " & cleanupDetail
        If eventsSafeForWorkbookWrites And _
           (Not recoveryGateRequired Or recoveryConfirmed) Then
            On Error Resume Next
            AddCheck "エラー", "外部取込の終了処理", cleanupDetail
            On Error GoTo 0
        End If
    End If
    If dataCommitted Then
        'Commit本体が全書込を確認した後の一覧・案内だけが失敗した場合、
        '「反映していない」と誤案内して同じ資料を再取込させない。確定後は
        '旧snapshotへ戻さず、帳票dirtyと必要な復旧状態だけをlease内で確定する。
        If eventsSafeForWorkbookWrites Then
            On Error Resume Next
            Err.Clear
            MarkOutputsDirty
            If Err.Number <> 0 Then
                postCommitDirtyFailed = True
                AppendExternalDetail postCommitSafetyDetail, _
                    "帳票要更新状態の再確認エラー: Err " & _
                    CStr(Err.Number) & " " & Err.Description
            End If
            Err.Clear
            postCommitRecoveryRequired = postCommitDirtyFailed
            If Not postCommitRecoveryRequired Then
                If Not recoveryEnforcementFailed Then _
                    postCommitRecoveryRequired = Not ToolDataHealthIsNormal()
            End If
            Err.Clear
            If postCommitRecoveryRequired Then
                recoveryGateRequired = True
                On Error GoTo 0
                AppendExternalDetail postCommitSafetyDetail, _
                    "確定後の外部取込状態を安全に記録できません。"
            End If
            If eventsSafeForWorkbookWrites And _
               (Not recoveryGateRequired Or recoveryConfirmed) Then
                AddCheck IIf(postCommitRecoveryRequired, "エラー", "警告"), _
                         "外部取込後処理", _
                         "外部データの内部保管への反映は完了しています。Err " & _
                         CStr(errorNumber) & ": " & errorDescription & _
                         IIf(Len(postCommitSafetyDetail) > 0, _
                             " / " & postCommitSafetyDetail, "")
                If postCommitRecoveryRequired Then
                    If recoveryConfirmed Then
                        SetInputStatus "外部データは反映済みで、案件の要復旧状態を確認しました。再取込・上書き保存をせずC_チェックを確認してください。", True
                    Else
                        SetInputStatus "外部データは反映済みですが、案件の復旧状態を一意に確認できません。再取込・上書き保存をせずC_チェックを確認してください。", True
                    End If
                Else
                    SetInputStatus "外部データは反映済みです。後処理だけに失敗したため、同じ資料を再取込せずC_チェックを確認してください。", True
                End If
            End If
            Err.Clear
            On Error GoTo 0
        End If
        If recoveryEnforcementFailed Or recoveryTerminalFailure Then
            eventStateDetail = vbNullString
            eventsSafeForWorkbookWrites = _
                TrySetExternalImportEnableEventsExact(False, eventStateDetail)
            FinishExternalImportApplicationLease applicationLeaseStarted, entryEvents, _
                entryEventsCaptured, "外部データ取込", True, _
                postCommitSafetyDetail, recoveryEnforcementFailed, _
                recoveryAttempted, recoveryTerminalFailure, True, False
            Exit Sub
        End If
        On Error Resume Next
        MsgBox "外部データの内部保管への反映は完了していますが、取込後の画面・一覧更新に失敗しました。" & vbCrLf & _
               "同じ資料をもう一度取り込まず、C_チェックと登録済み口座を確認してください。" & vbCrLf & _
               IIf(Not eventsSafeForWorkbookWrites, _
                   "Excelイベント状態が不明なため、終了記録はブックへ書き込んでいません。" & vbCrLf, _
                   IIf(postCommitRecoveryRequired, _
                       "案件の復旧状態を確認してください。現在のブックを上書きしないでください。" & vbCrLf, _
                       "帳票は要更新状態です。" & vbCrLf)) & _
               "Err " & CStr(errorNumber) & ": " & errorDescription & _
               IIf(Len(postCommitSafetyDetail) > 0, _
                   vbCrLf & "安全停止詳細: " & postCommitSafetyDetail, ""), _
               vbExclamation, "外部取込後の更新エラー"
        On Error GoTo 0
        FinishExternalImportApplicationLease applicationLeaseStarted, entryEvents, _
            entryEventsCaptured, "外部データ取込", True, _
            postCommitSafetyDetail, recoveryEnforcementFailed, _
            recoveryAttempted, recoveryTerminalFailure, _
            recoveryGateRequired Or Not eventsSafeForWorkbookWrites, _
            recoveryConfirmed
        Exit Sub
    End If

    If eventsSafeForWorkbookWrites Then
        On Error Resume Next
        postCommitRecoveryRequired = recoveryGateRequired
        If Not postCommitRecoveryRequired Then
            If Not recoveryEnforcementFailed Then _
                postCommitRecoveryRequired = Not ToolDataHealthIsNormal()
        End If
        Err.Clear
        If postCommitRecoveryRequired Then
            recoveryGateRequired = True
            On Error GoTo 0
            AppendExternalDetail postCommitSafetyDetail, _
                "外部取込の失敗復元を厳密確認できません。"
        ElseIf InStr(1, errorDescription, "ロールバック確認", vbTextCompare) > 0 Then
            SetInputStatus "外部取込に失敗し、復元結果も要確認です。C_チェックを確認してください。"
            AddCheck "エラー", "外部取込ロールバック", errorDescription
        ElseIf InStr(1, errorDescription, "ロールバック処理警告", vbTextCompare) > 0 Then
            SetInputStatus "外部取込に失敗しました。データは取込前と一致しています。"
            AddCheck "警告", "外部取込ロールバック", errorDescription
        Else
            SetInputStatus "外部取込に失敗したため、データは反映していません。"
        End If
        Err.Clear
        On Error GoTo 0
    End If
    If recoveryEnforcementFailed Or recoveryTerminalFailure Then
        eventStateDetail = vbNullString
        eventsSafeForWorkbookWrites = _
            TrySetExternalImportEnableEventsExact(False, eventStateDetail)
        FinishExternalImportApplicationLease applicationLeaseStarted, entryEvents, _
            entryEventsCaptured, "外部データ取込", False, _
            postCommitSafetyDetail, recoveryEnforcementFailed, _
            recoveryAttempted, recoveryTerminalFailure, True, False
        Exit Sub
    End If
    On Error Resume Next
    MsgBox "外部取込中にエラーが発生しました。" & vbCrLf & _
           "Err " & errorNumber & ": " & errorDescription & _
           IIf(Not eventsSafeForWorkbookWrites, _
               vbCrLf & "Excelイベント状態が不明なため、終了記録はブックへ書き込んでいません。", ""), _
           vbCritical
    On Error GoTo 0
    FinishExternalImportApplicationLease applicationLeaseStarted, entryEvents, _
        entryEventsCaptured, "外部データ取込", False, _
        postCommitSafetyDetail, recoveryEnforcementFailed, _
        recoveryAttempted, recoveryTerminalFailure, _
        recoveryGateRequired Or Not eventsSafeForWorkbookWrites, _
        recoveryConfirmed
End Sub

Private Function TryGetExternalImportEnableEvents(ByRef currentValue As Boolean, _
                                                   ByRef detailText As String) As Boolean
    Dim errorNumber As Long, errorDescription As String
    detailText = vbNullString
    On Error GoTo EH
    currentValue = Application.EnableEvents
    TryGetExternalImportEnableEvents = True
    Exit Function
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    detailText = "Err " & CStr(errorNumber) & ": " & errorDescription
    Err.Clear
End Function

Private Function TrySetExternalImportEnableEventsExact( _
        ByVal desiredValue As Boolean, _
        ByRef detailText As String) As Boolean
    Dim errorNumber As Long, errorDescription As String
    detailText = vbNullString
    On Error GoTo EH
    Application.EnableEvents = desiredValue
    If Application.EnableEvents <> desiredValue Then _
        Err.Raise vbObjectError + 6240, _
                  "TrySetExternalImportEnableEventsExact", _
                  "EnableEventsの書込み後読戻しが一致しません。"
    TrySetExternalImportEnableEventsExact = True
    Exit Function
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    detailText = "Err " & CStr(errorNumber) & ": " & errorDescription
    Err.Clear
End Function

Private Function IsExternalImportRecoveryFatal( _
        ByVal errorNumber As Long, ByVal errorSource As String) As Boolean
    Dim sourcePrefix As String
    Select Case errorNumber
        Case vbObjectError + 3599, EXTERNAL_IMPORT_RECOVERY_FATAL_ERROR
            IsExternalImportRecoveryFatal = True
            Exit Function
        Case vbObjectError + 5191
            sourcePrefix = "AnalysisWorkspaceRecoveryFatal/"
        Case vbObjectError + 5192
            sourcePrefix = "SetupConvergeRecoveryFatal/"
        Case vbObjectError + 5194
            sourcePrefix = "CashAnalysisRecoveryFatal/"
        Case vbObjectError + 5195
            sourcePrefix = "TransactionAnalysisRecoveryFatal/"
        Case vbObjectError + 5196
            sourcePrefix = "CashManualSelectionRecoveryFatal/"
        Case vbObjectError + 5197
            sourcePrefix = "ClearRecoveryFatal/"
        Case Else
            Exit Function
    End Select
    IsExternalImportRecoveryFatal = _
        (Len(errorSource) >= Len(sourcePrefix)) And _
        (StrComp(Left$(errorSource, Len(sourcePrefix)), _
                 sourcePrefix, vbBinaryCompare) = 0)
End Function

Private Sub RethrowExternalImportRecoveryFatal( _
        ByVal errorNumber As Long, ByVal errorSource As String, _
        ByVal errorDescription As String)
    Dim eventDetail As String
    Call TrySetExternalImportEnableEventsExact(False, eventDetail)
    Err.Raise errorNumber, errorSource, errorDescription
End Sub

Private Sub RaiseExternalImportRecoveryFatal( _
        ByVal operationName As String, _
        ByVal originalErrorNumber As Long, _
        ByVal originalErrorSource As String, _
        ByVal originalErrorDescription As String, _
        ByVal recoveryDetail As String)
    Dim eventDetail As String, fatalDescription As String
    If Not TrySetExternalImportEnableEventsExact(False, eventDetail) Then _
        AppendExternalDetail recoveryDetail, _
            "Recovery終端のExcelイベントFalse収束に失敗しました: " & _
            eventDetail
    fatalDescription = "元エラー Err " & CStr(originalErrorNumber)
    If Len(originalErrorSource) > 0 Then _
        fatalDescription = fatalDescription & " / " & originalErrorSource
    If Len(originalErrorDescription) > 0 Then _
        fatalDescription = fatalDescription & ": " & originalErrorDescription
    If Len(recoveryDetail) > 0 Then _
        fatalDescription = fatalDescription & " / Recovery: " & recoveryDetail
    Err.Raise EXTERNAL_IMPORT_RECOVERY_FATAL_ERROR, _
              EXTERNAL_IMPORT_RECOVERY_FATAL_SOURCE & operationName, _
              fatalDescription
End Sub

Private Function ExternalImportRecoveryStateConfirmed() As Boolean
    Dim latchIsSet As Boolean, healthValue As String
    On Error GoTo EH
    If Not TryGetRollbackRecoveryLatch(latchIsSet) Then Exit Function
    If Not latchIsSet Then Exit Function
    If Not TryGetExactStateValue(STATE_DATA_HEALTH, healthValue) Then Exit Function
    ExternalImportRecoveryStateConfirmed = _
        (StrComp(healthValue, DATA_HEALTH_NEEDS_RECOVERY, vbBinaryCompare) = 0)
    Exit Function
EH:
    ExternalImportRecoveryStateConfirmed = False
    Err.Clear
End Function

Private Sub EnterExternalImportRecoveryStateTerminal( _
        ByVal operationName As String, _
        ByVal reasonText As String, _
        ByRef recoveryDetail As String, _
        ByRef enforcementFailed As Boolean, _
        ByRef recoveryAttempted As Boolean, _
        ByRef recoveryTerminalFailure As Boolean, _
        ByRef applicationLeaseStarted As Boolean, _
        ByVal originalErrorNumber As Long, _
        ByVal originalErrorSource As String, _
        ByVal originalErrorDescription As String)
    Dim eventDetail As String, confirmationDetail As String
    Dim enforceErrorNumber As Long, enforceErrorDescription As String
    Dim enforceErrorSource As String, applicationDetail As String
    Dim appEndErrorNumber As Long, appEndErrorDescription As String
    Dim eventsStopped As Boolean, applicationSafe As Boolean

    If enforcementFailed Or recoveryTerminalFailure Or recoveryAttempted Then
        recoveryTerminalFailure = True
        If TrySetExternalImportEnableEventsExact(False, eventDetail) Then
            recoveryDetail = _
                "Recovery強制設定はこの操作で既に試行済みのため再試行せず、" & _
                "ExcelイベントをFalseで停止しました。"
        Else
            recoveryDetail = _
                "Recovery再試行を抑止しましたが、ExcelイベントFalse収束に失敗しました: " & _
                eventDetail
        End If
        RaiseExternalImportRecoveryFatal _
            operationName, originalErrorNumber, originalErrorSource, _
            originalErrorDescription, recoveryDetail
    End If
    If Not TrySetExternalImportEnableEventsExact(False, eventDetail) Then
        recoveryTerminalFailure = True
        recoveryDetail = _
            "Recovery書込み前にExcelイベント停止を確認できません: " & _
            eventDetail
        RaiseExternalImportRecoveryFatal _
            operationName, originalErrorNumber, originalErrorSource, _
            originalErrorDescription, recoveryDetail
    End If

    recoveryDetail = reasonText
    recoveryAttempted = True
    On Error Resume Next
    Err.Clear
    EnforceRollbackRecoveryState recoveryDetail
    enforceErrorNumber = Err.Number
    enforceErrorDescription = Err.Description
    enforceErrorSource = Err.Source
    Err.Clear
    eventsStopped = _
        TrySetExternalImportEnableEventsExact(False, eventDetail)
    On Error GoTo 0

    If enforceErrorNumber <> 0 Then
        enforcementFailed = True
        recoveryTerminalFailure = True
        AppendExternalDetail recoveryDetail, _
            "要復旧状態の設定エラー: Err " & _
            CStr(enforceErrorNumber) & " " & enforceErrorDescription
        If Len(enforceErrorSource) > 0 Then _
            AppendExternalDetail recoveryDetail, _
                "要復旧処理エラー発生元: " & enforceErrorSource
        If Not eventsStopped Then _
            AppendExternalDetail recoveryDetail, _
                "要復旧処理エラー後のExcelイベントFalse収束にも失敗しました: " & _
                eventDetail
        RaiseExternalImportRecoveryFatal _
            operationName, originalErrorNumber, originalErrorSource, _
            originalErrorDescription, recoveryDetail
    End If
    If Not eventsStopped Then
        recoveryTerminalFailure = True
        AppendExternalDetail recoveryDetail, _
            "Recovery設定後にExcelイベント停止を再確認できません: " & _
            eventDetail
        RaiseExternalImportRecoveryFatal _
            operationName, originalErrorNumber, originalErrorSource, _
            originalErrorDescription, recoveryDetail
    End If
    If Not ExternalImportRecoveryStateConfirmed() Then
        recoveryTerminalFailure = True
        AppendExternalDetail recoveryDetail, _
            "復旧ラッチと案件要復旧状態を一意に読み返せません。"
        RaiseExternalImportRecoveryFatal _
            operationName, originalErrorNumber, originalErrorSource, _
            originalErrorDescription, recoveryDetail
    End If

    'Recoveryを正常に書き返せた場合に限り、この操作が所有する
    'Application leaseを一度だけ終了する。Enforce自体が失敗した場合は
    'ここに到達させず、Falseのまま外側へterminalを伝播する。
    If applicationLeaseStarted Then
        On Error Resume Next
        Err.Clear
        AppEnd
        appEndErrorNumber = Err.Number
        appEndErrorDescription = Err.Description
        Err.Clear
        On Error GoTo 0
        applicationLeaseStarted = False
    End If

    applicationSafe = _
        ExternalImportApplicationStateConfirmed(applicationDetail)
    If Not TrySetExternalImportEnableEventsExact(False, eventDetail) Then
        recoveryTerminalFailure = True
        AppendExternalDetail recoveryDetail, _
            "Recovery安全確認後の最終ExcelイベントFalseを確認できません: " & _
            eventDetail
        RaiseExternalImportRecoveryFatal _
            operationName, originalErrorNumber, originalErrorSource, _
            originalErrorDescription, recoveryDetail
    End If
    If appEndErrorNumber <> 0 Or Not applicationSafe Then
        recoveryTerminalFailure = True
        If appEndErrorNumber <> 0 Then _
            AppendExternalDetail recoveryDetail, _
                "Recovery確認後のApplication lease終了エラー: Err " & _
                CStr(appEndErrorNumber) & " " & appEndErrorDescription
        If Not applicationSafe Then _
            AppendExternalDetail recoveryDetail, _
                "Application状態を安全に読み返せません: " & _
                applicationDetail
        RaiseExternalImportRecoveryFatal _
            operationName, originalErrorNumber, originalErrorSource, _
            originalErrorDescription, recoveryDetail
    End If
    AppendExternalDetail recoveryDetail, _
        "今回のRecovery二重状態、Application状態、最終イベントFalseを確認しました。"
    RaiseExternalImportRecoveryFatal _
        operationName, originalErrorNumber, originalErrorSource, _
        originalErrorDescription, recoveryDetail
End Sub

Private Function ExternalImportApplicationStateConfirmed( _
        ByRef detailText As String) As Boolean
    Dim errorNumber As Long, errorDescription As String
    detailText = vbNullString
    On Error GoTo EH
    ExternalImportApplicationStateConfirmed = AppStateIsRestored(detailText)
    Exit Function
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    detailText = "Application状態確認エラー: Err " & _
                 CStr(errorNumber) & " " & errorDescription
    Err.Clear
End Function

Private Sub RecordExternalImportApplicationLeaseFailureTerminal( _
        ByVal operationName As String, _
        ByVal dataCommitted As Boolean, _
        ByRef detailText As String, _
        ByRef enforcementFailed As Boolean, _
        ByRef recoveryAttempted As Boolean, _
        ByRef recoveryTerminalFailure As Boolean, _
        ByRef applicationLeaseStarted As Boolean)
    Dim originalDetail As String
    originalDetail = detailText
    EnterExternalImportRecoveryStateTerminal _
        operationName, operationName & "のApplication状態復元失敗", _
        detailText, enforcementFailed, recoveryAttempted, _
        recoveryTerminalFailure, applicationLeaseStarted, _
        0, operationName, originalDetail
End Sub

Private Function TryRestoreExternalImportEnableEvents( _
        ByVal previousValue As Boolean, _
        ByVal operationName As String, _
        ByVal dataCommitted As Boolean, _
        ByVal recoveryRequiredOnEntry As Boolean, _
        ByVal recoveryConfirmedOnEntry As Boolean, _
        ByRef recoveryEnforcementFailed As Boolean, _
        ByRef recoveryAttempted As Boolean, _
        ByRef recoveryTerminalFailure As Boolean, _
        ByRef detailText As String) As Boolean
    Dim firstDetail As String, retryDetail As String, stopDetail As String
    Dim finalDetail As String, convergenceDetail As String
    Dim eventsStopped As Boolean, recoveryConfirmed As Boolean
    Dim stateProblems As String, terminalDetail As String
    Dim noApplicationLeaseStarted As Boolean

    detailText = vbNullString
    If recoveryEnforcementFailed Or recoveryTerminalFailure Or _
       recoveryAttempted Then
        recoveryTerminalFailure = True
        If Not TrySetExternalImportEnableEventsExact(False, stopDetail) Then _
            detailText = _
                "Recovery終端後にExcelイベントをFalseへ収束できません: " & _
                stopDetail
        RaiseExternalImportRecoveryFatal _
            operationName, 0, operationName, _
            "Recovery強制設定後の開始値復元は実行できません。", _
            detailText
    End If
    recoveryConfirmed = recoveryConfirmedOnEntry
    If recoveryRequiredOnEntry Then
        If recoveryConfirmed Then _
            recoveryConfirmed = ExternalImportRecoveryStateConfirmed()
        If Not recoveryConfirmed Then
            If recoveryAttempted Then
                recoveryTerminalFailure = True
                If Not TrySetExternalImportEnableEventsExact(False, stopDetail) Then _
                    detailText = _
                        "Recovery再確認失敗後のExcelイベントFalse収束にも失敗しました: " & _
                        stopDetail
                RaiseExternalImportRecoveryFatal _
                    operationName, 0, operationName, _
                    "Recovery強制設定実行後は開始値を復元できません。", _
                    detailText
            End If
            If Not TrySetExternalImportEnableEventsExact(False, stopDetail) Then
                recoveryTerminalFailure = True
                detailText = _
                    "Recovery書込み前にExcelイベントをFalseへ収束できません: " & _
                    stopDetail
                RaiseExternalImportRecoveryFatal _
                    operationName, 0, operationName, _
                    "Recovery書込み前のイベント停止に失敗しました。", _
                    detailText
            End If
            RecordExternalImportApplicationLeaseFailureTerminal _
                operationName, dataCommitted, detailText, _
                recoveryEnforcementFailed, recoveryAttempted, _
                recoveryTerminalFailure, noApplicationLeaseStarted
        End If
    End If
    If TrySetExternalImportEnableEventsExact(previousValue, firstDetail) Then
        TryRestoreExternalImportEnableEvents = True
        Exit Function
    End If
    If TrySetExternalImportEnableEventsExact(previousValue, retryDetail) Then
        TryRestoreExternalImportEnableEvents = True
        Exit Function
    End If
    detailText = "Excelイベント状態を開始値へ復元できませんでした。初回=" & _
                 firstDetail & " / 再試行=" & retryDetail
    eventsStopped = TrySetExternalImportEnableEventsExact(False, stopDetail)
    If eventsStopped Then
        AppendExternalDetail detailText, _
            "要復旧記録前にExcelイベント停止を読戻し確認しました。"
    Else
        AppendExternalDetail detailText, _
            "Excelイベント停止を確認できず、ブックへの復旧記録を見送りました: " & _
            stopDetail
        RaiseExternalImportRecoveryFatal _
            operationName, 0, operationName, _
            "Excelイベントの開始値復元に失敗しました。", _
            detailText
    End If
    If Not previousValue Then
        '開始値自体がFalseなら三回目のexact停止でleaseは復元済みである。
        TryRestoreExternalImportEnableEvents = True
        Exit Function
    End If
    If Not AppStateIsRestored(stateProblems) Then
        AppendExternalDetail detailText, _
            "Application状態が安全に復元されていないため、Recoveryのブック書込みと" & _
            "開始値Trueへの復元を見送り、ExcelイベントをFalseに維持しました。 " & _
            stateProblems
        recoveryTerminalFailure = True
        RaiseExternalImportRecoveryFatal _
            operationName, 0, operationName, _
            "Application状態が安全でないため開始値を復元できません。", _
            detailText
    End If

    recoveryConfirmed = recoveryConfirmedOnEntry Or recoveryConfirmed
    If recoveryRequiredOnEntry Then
        If recoveryConfirmed Then _
            recoveryConfirmed = ExternalImportRecoveryStateConfirmed()
    End If
    If Not recoveryConfirmed Then
        RecordExternalImportApplicationLeaseFailureTerminal _
            operationName, dataCommitted, detailText, _
            recoveryEnforcementFailed, recoveryAttempted, _
            recoveryTerminalFailure, noApplicationLeaseStarted
    End If
End Function

Private Function FinishExternalImportApplicationLease( _
        ByRef leaseStarted As Boolean, _
        ByVal entryEvents As Boolean, _
        ByVal entryEventsCaptured As Boolean, _
        ByVal operationName As String, _
        ByVal dataCommitted As Boolean, _
        ByRef detailText As String, _
        ByRef recoveryEnforcementFailed As Boolean, _
        ByRef recoveryAttempted As Boolean, _
        ByRef recoveryTerminalFailure As Boolean, _
        Optional ByVal recoveryRequiredOnEntry As Boolean = False, _
        Optional ByVal recoveryConfirmedOnEntry As Boolean = False) As Boolean
    Dim eventsStopped As Boolean, keyRestoreFailed As Boolean
    Dim applicationRestoreFailed As Boolean, finishFailed As Boolean
    Dim applicationStateSafe As Boolean, recoveryGateRequired As Boolean
    Dim recoveryConfirmed As Boolean
    Dim eventDetail As String, keyErrorDescription As String
    Dim appErrorNumber As Long, appErrorDescription As String
    Dim forceErrorNumber As Long, forceErrorDescription As String
    Dim eventRestoreDetail As String, stateProblems As String
    Dim recoveryGateDetail As String

    recoveryGateRequired = recoveryRequiredOnEntry
    recoveryConfirmed = recoveryConfirmedOnEntry
    If recoveryEnforcementFailed Or recoveryTerminalFailure Or _
       recoveryAttempted Then
        recoveryTerminalFailure = True
        If Not TrySetExternalImportEnableEventsExact(False, eventDetail) Then _
            AppendExternalDetail detailText, _
                "Recovery終端後にExcelイベントをFalseへ収束できません: " & _
                eventDetail
        RaiseExternalImportRecoveryFatal _
            operationName, 0, operationName, _
            "Recovery強制設定後の終了処理は再開できません。", _
            detailText
    End If

    If leaseStarted Then
        eventsStopped = TrySetExternalImportEnableEventsExact(False, eventDetail)
        If eventsStopped Then
            On Error Resume Next
            Err.Clear
            EnableInputKeys
            If Err.Number <> 0 Then
                keyRestoreFailed = True
                keyErrorDescription = _
                    "Err " & CStr(Err.Number) & " " & Err.Description
            End If
            Err.Clear
            On Error GoTo 0

            If keyRestoreFailed Then
                recoveryGateRequired = True
                AppendExternalDetail detailText, _
                    "入力キー状態の復元エラー: " & keyErrorDescription
            End If
            If recoveryGateRequired Then
                EnterExternalImportRecoveryStateTerminal _
                    operationName, _
                    "終了処理で案件要復旧状態の確定が必要です。", _
                    detailText, recoveryEnforcementFailed, _
                    recoveryAttempted, recoveryTerminalFailure, _
                    leaseStarted, 0, operationName, detailText
            End If
        Else
            AppendExternalDetail detailText, _
                "入力キー復元前にExcelイベント停止を確認できません: " & eventDetail
            recoveryTerminalFailure = True
            RaiseExternalImportRecoveryFatal _
                operationName, 0, operationName, _
                "終了処理前にExcelイベントを安全停止できません。", _
                detailText
        End If

        If recoveryEnforcementFailed Or recoveryTerminalFailure Or _
           recoveryAttempted Then
            recoveryTerminalFailure = True
            eventDetail = vbNullString
            If Not TrySetExternalImportEnableEventsExact(False, eventDetail) Then _
                AppendExternalDetail detailText, _
                    "Recovery終端後のExcelイベントFalse収束にも失敗しました: " & _
                    eventDetail
            RaiseExternalImportRecoveryFatal _
                operationName, 0, operationName, _
                "Recovery強制設定実行後は終了処理を続行できません。", _
                detailText
        End If

        On Error Resume Next
        Err.Clear
        AppEnd
        appErrorNumber = Err.Number
        appErrorDescription = Err.Description
        Err.Clear
        If appErrorNumber <> 0 Then
            If Not recoveryEnforcementFailed And Not recoveryAttempted Then
                AppForceRestore
                forceErrorNumber = Err.Number
                forceErrorDescription = Err.Description
                Err.Clear
            End If
        End If
        On Error GoTo 0
        leaseStarted = False
        stateProblems = vbNullString
        applicationStateSafe = AppStateIsRestored(stateProblems)
        applicationRestoreFailed = _
            (appErrorNumber <> 0 Or forceErrorNumber <> 0 Or _
             Not applicationStateSafe)
        If applicationRestoreFailed Then
            AppendExternalDetail detailText, _
                "Excel状態の復元エラー: Err " & CStr(appErrorNumber) & _
                " " & appErrorDescription
            If forceErrorNumber <> 0 Then _
                AppendExternalDetail detailText, _
                    "強制復元再試行: Err " & CStr(forceErrorNumber) & _
                    " " & forceErrorDescription
            If Len(stateProblems) > 0 Then _
                AppendExternalDetail detailText, _
                    "Application状態の読戻し不一致: " & stateProblems
            eventDetail = vbNullString
            If Not TrySetExternalImportEnableEventsExact(False, eventDetail) Then
                AppendExternalDetail detailText, _
                    "Recovery前にExcelイベントをFalseへ収束できません: " & _
                    eventDetail
                recoveryTerminalFailure = True
                RaiseExternalImportRecoveryFatal _
                    operationName, appErrorNumber, "AppEnd/AppForceRestore", _
                    appErrorDescription, detailText
            End If
            EnterExternalImportRecoveryStateTerminal _
                operationName, _
                "Application状態の復元失敗を案件要復旧状態に記録します。", _
                detailText, recoveryEnforcementFailed, recoveryAttempted, _
                recoveryTerminalFailure, leaseStarted, appErrorNumber, _
                "AppEnd/AppForceRestore", appErrorDescription
        End If
    Else
        eventDetail = vbNullString
        If Not TrySetExternalImportEnableEventsExact(False, eventDetail) Then
            recoveryTerminalFailure = True
            AppendExternalDetail detailText, _
                "Application状態の確認前にExcelイベントをFalseへ収束できません: " & _
                eventDetail
            RaiseExternalImportRecoveryFatal _
                operationName, 0, operationName, _
                "終了時のExcel状態を確認できません。", _
                detailText
        End If
        stateProblems = vbNullString
        applicationStateSafe = AppStateIsRestored(stateProblems)
        If Not applicationStateSafe Then
            AppendExternalDetail detailText, _
                "開始に失敗したApplication状態を安全に確認できません: " & _
                stateProblems
            EnterExternalImportRecoveryStateTerminal _
                operationName, _
                "Application状態の安全を確認できません。", _
                detailText, recoveryEnforcementFailed, recoveryAttempted, _
                recoveryTerminalFailure, leaseStarted, 0, operationName, _
                stateProblems
        End If
    End If

    If recoveryEnforcementFailed Or recoveryTerminalFailure Or _
       recoveryAttempted Then
        recoveryTerminalFailure = True
        eventDetail = vbNullString
        If Not TrySetExternalImportEnableEventsExact(False, eventDetail) Then _
            AppendExternalDetail detailText, _
                "Recovery終端後のExcelイベントFalse収束にも失敗しました: " & _
                eventDetail
        RaiseExternalImportRecoveryFatal _
            operationName, 0, operationName, _
            "Recovery強制設定実行後は終了処理を続行できません。", _
            detailText
    End If

    '最後のイベント返却前に、FalseとApplication状態を独立に確認する。
    eventDetail = vbNullString
    eventsStopped = TrySetExternalImportEnableEventsExact(False, eventDetail)
    If Not eventsStopped Then
        AppendExternalDetail detailText, _
            "終了時の最終イベント停止を確認できません: " & eventDetail
        recoveryTerminalFailure = True
        RaiseExternalImportRecoveryFatal _
            operationName, 0, operationName, _
            "終了時にExcelイベントをFalseへ収束できません。", _
            detailText
    End If
    stateProblems = vbNullString
    applicationStateSafe = AppStateIsRestored(stateProblems)
    If Not applicationStateSafe Then
        AppendExternalDetail detailText, _
            "終了時にApplication状態の安全を確認できません: " & _
            stateProblems
        EnterExternalImportRecoveryStateTerminal _
            operationName, _
            "終了時のApplication状態が安全であることを確認できません。", _
            detailText, recoveryEnforcementFailed, recoveryAttempted, _
            recoveryTerminalFailure, leaseStarted, 0, operationName, _
            stateProblems
    End If

    'Application leaseの返却後に行う最後の状態操作。以後ブックへ書き込まない。
    If Not entryEventsCaptured Then
        AppendExternalDetail detailText, "Excelイベントの開始状態が未取得です。"
        recoveryTerminalFailure = True
        RaiseExternalImportRecoveryFatal _
            operationName, 0, operationName, _
            "Excelイベントの開始状態が未取得です。", _
            detailText
    End If
    If Not entryEvents Then
        FinishExternalImportApplicationLease = True
        Exit Function
    End If
    If recoveryEnforcementFailed Or recoveryTerminalFailure Or _
       recoveryAttempted Or Not eventsStopped Or Not applicationStateSafe Then
        AppendExternalDetail detailText, _
            "イベント停止・Application状態の安全条件がそろわないため、" & _
            "開始値Trueへの復元を行いませんでした。"
        eventDetail = vbNullString
        eventsStopped = TrySetExternalImportEnableEventsExact(False, eventDetail)
        If Not eventsStopped Then _
            AppendExternalDetail detailText, _
                "ExcelイベントをFalseへ収束できません: " & eventDetail
        RaiseExternalImportRecoveryFatal _
            operationName, 0, operationName, _
            "Excelイベントの開始値を安全に復元できません。", _
            detailText
    End If
    If Not TryRestoreExternalImportEnableEvents(entryEvents, operationName, _
                                                 dataCommitted, recoveryGateRequired, _
                                                 recoveryConfirmed, _
                                                 recoveryEnforcementFailed, _
                                                 recoveryAttempted, _
                                                 recoveryTerminalFailure, _
                                                 eventRestoreDetail) Then
        AppendExternalDetail detailText, eventRestoreDetail
        recoveryTerminalFailure = True
        RaiseExternalImportRecoveryFatal _
            operationName, 0, operationName, _
            "Excelイベントの開始値を安全に復元できません。", _
            detailText
    End If
    FinishExternalImportApplicationLease = True
End Function

Private Function IsExternalBalanceRecord(ByVal tekiyoText As String, ByVal withdrawValue As Variant, _
                                         ByVal depositValue As Variant, ByVal afterBalance As Variant) As Boolean
    '自ツールが出力する残高行だけを保守的に復元する。
    '摘要に「残高」が含まれる通常取引を誤認しないよう、入出金なし・残高数値を必須とする。
    Dim s As String
    If HasText(withdrawValue) Or HasText(depositValue) Then Exit Function
    If Not HasText(afterBalance) Or Not IsNumeric(afterBalance) Then Exit Function
    s = CellText(tekiyoText)
    s = Replace(s, vbCrLf, "")
    s = Replace(s, vbCr, "")
    s = Replace(s, vbLf, "")
    s = Replace(s, " ", "")
    s = Replace(s, "　", "")
    If s = "残高" Or InStr(1, s, "年末残高", vbTextCompare) > 0 Or _
       InStr(1, s, "相続開始日時点残高", vbTextCompare) > 0 Then
        IsExternalBalanceRecord = True
    End If
End Function

Private Function ExternalDataRows(ByVal ws As Worksheet, ByVal lastColumn As Long) As Long
    Dim lastDataRow As Long
    If ws Is Nothing Or lastColumn < 1 Then _
        Err.Raise vbObjectError + 6226, "ExternalDataRows", _
                  "外部取込の既存保管行数を取得できません。"
    lastDataRow = LastDataRowInColumns(ws, 1, lastColumn)
    If lastDataRow > 1 Then ExternalDataRows = lastDataRow - 1
End Function

Private Function ExternalImportExistingStoreRows( _
                 ByVal transactionRows As Long, ByVal balanceRows As Long, _
                 ByVal accountRows As Long, ByVal bankRows As Long, _
                 ByVal branchRows As Long, ByVal personRows As Long, _
                 ByVal typeRows As Long, ByVal tekiyoRows As Long) As Double
    ExternalImportExistingStoreRows = _
        ExternalImportInternalStoreRows( _
            transactionRows, balanceRows, accountRows) + _
        ExternalImportCandidateStoreRows( _
            bankRows, branchRows, personRows, typeRows, tekiyoRows)
End Function

Private Function ExternalImportInternalStoreRows( _
                 ByVal transactionRows As Long, ByVal balanceRows As Long, _
                 ByVal accountRows As Long) As Double
    If transactionRows < 0 Or balanceRows < 0 Or accountRows < 0 Then _
        Err.Raise vbObjectError + 6226, "ExternalImportInternalStoreRows", _
                  "外部取込の内部保管行数が不正です。"
    ExternalImportInternalStoreRows = _
        ExternalEquivalentWorkRows(transactionRows, WORK_TX_COL_PERSON_ID) + _
        ExternalEquivalentWorkRows(balanceRows, WORK_BAL_COL_PERSON_ID) + _
        ExternalEquivalentWorkRows(accountRows, ACC_COL_TRANSFER_ID)
End Function

Private Function ExternalImportCandidateStoreRows( _
                 ByVal bankRows As Long, ByVal branchRows As Long, _
                 ByVal personRows As Long, ByVal typeRows As Long, _
                 ByVal tekiyoRows As Long) As Double
    If bankRows < 0 Or branchRows < 0 Or personRows < 0 Or _
       typeRows < 0 Or tekiyoRows < 0 Then _
        Err.Raise vbObjectError + 6226, "ExternalImportCandidateStoreRows", _
                  "外部取込の候補保管行数が不正です。"
    ExternalImportCandidateStoreRows = _
        ExternalEquivalentWorkRows(bankRows, 4) + _
        ExternalEquivalentWorkRows(branchRows, 4) + _
        ExternalEquivalentWorkRows(personRows, 4) + _
        ExternalEquivalentWorkRows(typeRows, 4) + _
        ExternalEquivalentWorkRows(tekiyoRows, 4)
End Function

Private Function ExternalEquivalentWorkRows(ByVal rowCount As Long, _
                                            ByVal columnCount As Long) As Double
    Dim cellCount As Double
    If rowCount < 0 Or columnCount < 1 Then _
        Err.Raise vbObjectError + 6227, "ExternalEquivalentWorkRows", _
                  "外部取込の配列寸法が不正です。"
    If rowCount = 0 Then Exit Function
    cellCount = CDbl(rowCount) * CDbl(columnCount)
    ExternalEquivalentWorkRows = Int((cellCount + CDbl(PREP_LAST_COL) - 1#) / _
                                     CDbl(PREP_LAST_COL))
End Function

Private Function ExternalImportPreallocationWorkRows( _
                 ByVal sourceRangeRows As Long, ByVal sourceRangeColumns As Long, _
                 ByVal preparedCapacityRows As Long, _
                 ByVal internalStoreRows As Double, _
                 ByVal candidateStoreRows As Double) As Double
    If sourceRangeRows < 1 Or sourceRangeColumns < 1 Or _
       preparedCapacityRows < 1 Or internalStoreRows < 0# Or _
       candidateStoreRows < 0# Then _
        Err.Raise vbObjectError + 6228, "ExternalImportPreallocationWorkRows", _
                  "外部取込の事前安全規模が不正です。"
    '呼出元の元表配列とpreparedを保持したまま、Commitでは出力、書込、期待値、
    'ID・キー・検証用のprepared由来配列を最大約194列分同時保持する。
    '内部3表はsnapshot、復元用constant、照合expected/actual等の最大5組、
    '候補5表はValue2/Formulaのlocal・snapshot・expected・actualの最大8組を
    '表別に計上する。小さい取込で既存表だけが大きい場合も過小評価しない。
    ExternalImportPreallocationWorkRows = _
        ExternalEquivalentWorkRows(sourceRangeRows, sourceRangeColumns) + _
        EXTERNAL_PREPARED_WORK_FACTOR * CDbl(preparedCapacityRows) + _
        EXTERNAL_INTERNAL_STORE_WORK_FACTOR * internalStoreRows + _
        EXTERNAL_CANDIDATE_STORE_WORK_FACTOR * candidateStoreRows
End Function

Private Sub CommitExternalRows(ByRef prepared() As Variant, ByVal preparedCount As Long, _
                               ByRef importedCount As Long, ByRef duplicateCount As Long, _
                               ByRef accountCount As Long, ByRef dataCommitted As Boolean, _
                               ByRef postCommitWarning As String, _
                               ByRef rollbackRecoveryRequired As Boolean, _
                               ByRef rollbackRecoveryConfirmed As Boolean, _
                               ByRef rollbackRecoveryEnforcementFailed As Boolean, _
                               ByRef recoveryAttempted As Boolean, _
                               ByRef recoveryTerminalFailure As Boolean, _
                               ByVal confirmedWorkRows As Double)
    Dim wsTx As Worksheet, wsBal As Worksheet, wsAcc As Worksheet
    Dim accountIDByKey As Object, transferIDByKey As Object, personIDByKey As Object, personIDByName As Object, relationshipByKey As Object
    Dim personLookupKeyByAccountKey As Object, personNameByKey As Object
    Dim personAliasByID As Object
    Dim pendingPersonKeys As Object
    Dim personRelationshipByID As Object
    Dim sourceRelationshipByKey As Object, sourceCanonicalByLocator As Object
    Dim firstIndexByKey As Object, newAccountByKey As Object, accountHasRows As Object
    Dim openDateByKey As Object, closeDateByKey As Object, signatures As Object, incomingSignatures As Object
    Dim createdAccountIDs As Object, sourceBalanceDates As Object, existingBalanceAmounts As Object
    Dim existingMasterByID As Object
    Dim existingSpecialDates As Object, skipSpecialByType As Object, existingAccountIDByKey As Object
    Dim existingAccountIDByLocator As Object, accountRowByID As Object
    Dim outData() As Variant, writeData() As Variant, expectedWriteData() As Variant
    Dim balanceOutData() As Variant, writeBalanceData() As Variant
    Dim expectedBalanceWriteData() As Variant
    Dim outAccountKeys() As String, balanceAccountKeys() As String
    Dim txStoreSnapshot As Variant, balanceStoreSnapshot As Variant, accountStoreSnapshot As Variant
    Dim bankCandidateSnapshot As Variant, branchCandidateSnapshot As Variant
    Dim personCandidateSnapshot As Variant, typeCandidateSnapshot As Variant
    Dim tekiyoCandidateSnapshot As Variant
    Dim idCounterSnapshot As Variant, accountIDs As Variant, personIDs As Variant, transferIDs As Variant
    Dim transactionIDs As Variant, balanceIDs As Variant
    Dim newAccountKeys As Collection, newPersonKeyOrder As Collection, newTransferKeys As Collection
    Dim i As Long, c As Long, outCount As Long, firstR As Long, nextMasterRow As Long
    Dim personReserveIndex As Long
    Dim balanceCount As Long, balanceFirstR As Long, incomingCount As Long, existingCount As Long
    Dim keyText As String, locatorKey As String, accountID As String, transferID As String, personID As String, personNameKey As String, specialKey As String
    Dim existingID As String, signatureText As String, recordType As String, balanceKey As String
    Dim item As Variant, firstIndex As Long, masterRow As Long
    Dim effectiveOpen As Variant, effectiveClose As Variant, masterSnapshot As Variant
    Dim masterSource As String, rollbackDetail As String, postProcessDetail As String
    Dim postProcessErrorNumber As Long, postProcessErrorDescription As String
    Dim postProcessErrorSource As String
    Dim rollbackStepErrorNumber As Long
    Dim rollbackStepErrorDescription As String, rollbackStepErrorSource As String
    Dim recoveryGateDetail As String
    Dim relationshipText As String, sourceRelationshipText As String
    Dim resolvedPersonName As String
    Dim writeStarted As Boolean, committed As Boolean, skipRow As Boolean, idCountersCaptured As Boolean
    Dim rollbackVerified As Boolean, candidateBatchStarted As Boolean, storeSnapshotsCaptured As Boolean
    Dim candidateSnapshotsCaptured As Boolean, candidateWritesStarted As Boolean
    Dim storeRestoreFailed As Boolean, candidateRestoreFailed As Boolean, counterRestoreFailed As Boolean
    Dim txStoreRows As Long, balanceStoreRows As Long, accountStoreRows As Long
    Dim bankCandidateRows As Long, branchCandidateRows As Long, personCandidateRows As Long
    Dim typeCandidateRows As Long, tekiyoCandidateRows As Long
    Dim internalStoreRows As Double, candidateStoreRows As Double
    Dim snapshotWorkRows As Double
    Dim errorNumber As Long, errorDescription As String, errorSource As String

    postCommitWarning = vbNullString
    rollbackRecoveryRequired = False
    rollbackRecoveryConfirmed = False
    On Error GoTo EH
    Set wsTx = GetSheet(SH_WORK_TX)
    Set wsBal = GetSheet(SH_WORK_BAL)
    Set wsAcc = GetSheet(SH_WORK_ACCOUNT)
    '取込開始前に確認した規模が、直前の実数を確実に覆うことを再計算する。
    'ここでは二重の確認ダイアログを出さず、事前確認を超えた場合はfail-closedで止める。
    internalStoreRows = ExternalImportInternalStoreRows( _
                        ExternalDataRows(wsTx, WORK_TX_COL_PERSON_ID), _
                        ExternalDataRows(wsBal, WORK_BAL_COL_PERSON_ID), _
                        ExternalDataRows(wsAcc, ACC_COL_TRANSFER_ID))
    candidateStoreRows = ExternalImportCandidateStoreRows( _
                         CommonSnapshotRows(GetSheet(SH_BANK_CAND), 4), _
                         CommonSnapshotRows(GetSheet(SH_BRANCH_CAND), 4), _
                         CommonSnapshotRows(GetSheet(SH_PERSON_CAND), 4), _
                         CommonSnapshotRows(GetSheet(SH_ACCOUNT_TYPE), 4), _
                         CommonSnapshotRows(GetSheet(SH_TEKIYO), 4))
    snapshotWorkRows = _
        EXTERNAL_PREPARED_WORK_FACTOR * CDbl(preparedCount) + _
        EXTERNAL_INTERNAL_STORE_WORK_FACTOR * internalStoreRows + _
        EXTERNAL_CANDIDATE_STORE_WORK_FACTOR * candidateStoreRows
    If snapshotWorkRows > 2147483647# Then _
        Err.Raise vbObjectError + 6225, "CommitExternalRows", _
                  "外部取込の安全退避規模を計算できません。"
    If confirmedWorkRows <= 0# Or snapshotWorkRows > confirmedWorkRows Then _
        Err.Raise vbObjectError + 6230, "CommitExternalRows", _
                  "外部取込の事前安全確認範囲を実処理が超えました。データは取り込んでいません。"
    '一括追記・圧縮削除の途中失敗では、新規ID列まで書かれていない部分行や、
    '圧縮対象外だった既存口座の行まで損傷し得る。破壊的書込みより前に3ストアを
    '全列・行順・Variant型込みで退避し、失敗時はID条件ではなく全体を戻す。
    SnapshotExternalStore wsTx, WORK_TX_COL_PERSON_ID, txStoreSnapshot, txStoreRows
    SnapshotExternalStore wsBal, WORK_BAL_COL_PERSON_ID, balanceStoreSnapshot, balanceStoreRows
    SnapshotExternalStore wsAcc, ACC_COL_TRANSFER_ID, accountStoreSnapshot, accountStoreRows
    storeSnapshotsCaptured = True
    Set accountIDByKey = NewTextDictionary()
    Set transferIDByKey = NewTextDictionary()
    Set personIDByKey = NewTextDictionary()
    Set personIDByName = NewTextDictionary()
    Set personRelationshipByID = NewTextDictionary()
    Set personAliasByID = NewTextDictionary()
    Set personLookupKeyByAccountKey = NewTextDictionary()
    Set personNameByKey = NewTextDictionary()
    Set pendingPersonKeys = NewTextDictionary()
    Set relationshipByKey = NewTextDictionary()
    Set sourceRelationshipByKey = NewTextDictionary()
    Set sourceCanonicalByLocator = NewTextDictionary()
    Set firstIndexByKey = NewTextDictionary()
    Set newAccountByKey = NewTextDictionary()
    Set accountHasRows = NewTextDictionary()
    Set openDateByKey = NewTextDictionary()
    Set closeDateByKey = NewTextDictionary()
    Set signatures = NewTextDictionary()
    Set incomingSignatures = NewTextDictionary()
    Set sourceBalanceDates = NewTextDictionary()
    Set existingBalanceAmounts = NewTextDictionary()
    Set createdAccountIDs = NewTextDictionary()
    Set existingMasterByID = NewTextDictionary()
    Set existingSpecialDates = NewTextDictionary()
    Set skipSpecialByType = NewTextDictionary()
    Set existingAccountIDByKey = NewTextDictionary()
    Set existingAccountIDByLocator = NewTextDictionary()
    Set accountRowByID = NewTextDictionary()
    Set newAccountKeys = New Collection
    Set newPersonKeyOrder = New Collection
    Set newTransferKeys = New Collection
    LoadExistingTransactionSignatures wsTx, signatures
    LoadExistingBalanceIndex wsBal, existingBalanceAmounts
    LoadExistingSpecialRecordDates wsTx, existingSpecialDates
    LoadExistingAccountIndexes wsAcc, existingAccountIDByKey, existingAccountIDByLocator, accountRowByID
    LoadExistingPersonIndexes personIDByName, personRelationshipByID, personAliasByID
    '同じ人物IDの別名義に続柄空欄があっても、ID側で続柄が一意なら
    '収束後の氏名+続柄を採番前に索引へ投影する。
    ProjectExternalPersonAliasesToIdentityIndex personIDByName, personRelationshipByID, _
                                                personAliasByID
    idCounterSnapshot = CaptureInternalIdCounters()
    idCountersCaptured = True
    nextMasterRow = RequireExternalAppendRow(wsAcc, "W_口座")

    For i = 1 To preparedCount
        keyText = CanonicalAccountKey(CStr(prepared(i, PREP_BANK)), CStr(prepared(i, PREP_BRANCH)), _
                                      CStr(prepared(i, PREP_PERSON)), CStr(prepared(i, PREP_TYPE)), _
                                      CStr(prepared(i, PREP_ACCOUNT_NO)))
        locatorKey = CanonicalAccountLocatorKey(CStr(prepared(i, PREP_BANK)), CStr(prepared(i, PREP_BRANCH)), _
                                                CStr(prepared(i, PREP_TYPE)), CStr(prepared(i, PREP_ACCOUNT_NO)))
        sourceRelationshipText = CStr(prepared(i, PREP_RELATIONSHIP))
        If sourceRelationshipByKey.Exists(keyText) Then
            relationshipText = CStr(sourceRelationshipByKey(keyText))
            If Len(relationshipText) = 0 And Len(sourceRelationshipText) > 0 Then
                sourceRelationshipByKey(keyText) = sourceRelationshipText
            ElseIf Len(relationshipText) > 0 And Len(sourceRelationshipText) > 0 Then
                If NormalizeRelationshipKey(relationshipText) <> NormalizeRelationshipKey(sourceRelationshipText) Then
                    Err.Raise vbObjectError + 6145, "CommitExternalRows", _
                              "同じ口座の続柄が取込資料内で一致しません: " & CStr(prepared(i, PREP_ACCOUNT_NO))
                End If
            End If
        Else
            sourceRelationshipByKey.Add keyText, sourceRelationshipText
        End If
        If sourceCanonicalByLocator.Exists(locatorKey) Then
            If CStr(sourceCanonicalByLocator(locatorKey)) <> keyText Then
                Err.Raise vbObjectError + 6146, "CommitExternalRows", _
                          "同じ銀行・支店・科目・口座番号に異なる名義があります。名義を確認し、必要なら訂正モードを使用してください: " & _
                          CStr(prepared(i, PREP_ACCOUNT_NO))
            End If
        Else
            sourceCanonicalByLocator.Add locatorKey, keyText
        End If
        If existingAccountIDByLocator.Exists(locatorKey) Then
            If Not existingAccountIDByKey.Exists(keyText) Then
                Err.Raise vbObjectError + 6147, "CommitExternalRows", _
                          "登録済み口座と同じ銀行・支店・科目・口座番号ですが、名義が異なります。外部取込では上書きせず、訂正モードで確認してください: " & _
                          CStr(prepared(i, PREP_ACCOUNT_NO))
            ElseIf CStr(existingAccountIDByLocator(locatorKey)) <> CStr(existingAccountIDByKey(keyText)) Then
                Err.Raise vbObjectError + 6148, "CommitExternalRows", _
                          "登録済み口座の識別情報が矛盾しています。先に該当する口座・人物の登録内容を確認してください。"
            End If
        End If
        If Not accountIDByKey.Exists(keyText) Then
            existingID = ""
            If existingAccountIDByKey.Exists(keyText) Then existingID = CStr(existingAccountIDByKey(keyText))
            If Len(existingID) > 0 Then
                accountID = existingID
                newAccountByKey.Add keyText, False
                If Not accountRowByID.Exists(accountID) Then _
                    Err.Raise vbObjectError + 6113, "CommitExternalRows", "既存口座マスタを取得できません: " & accountID
                masterRow = CLng(accountRowByID(accountID))
                If Not existingMasterByID.Exists(accountID) Then
                    masterSnapshot = wsAcc.Range(wsAcc.Cells(masterRow, 1), wsAcc.Cells(masterRow, ACC_COL_TRANSFER_ID)).Value
                    existingMasterByID.Add accountID, masterSnapshot
                End If
            Else
                accountID = ""
                newAccountByKey.Add keyText, True
                newAccountKeys.Add keyText
            End If
            relationshipText = CStr(sourceRelationshipByKey(keyText))
            resolvedPersonName = CStr(prepared(i, PREP_PERSON))
            If Len(existingID) > 0 Then
                If Not accountRowByID.Exists(existingID) Then _
                    Err.Raise vbObjectError + 6113, "CommitExternalRows", "既存口座マスタを取得できません: " & existingID
                masterRow = CLng(accountRowByID(existingID))
                '既存口座の人物属性は口座マスタを正とし、外部表だけで変更しない。
                sourceRelationshipText = relationshipText
                masterSnapshot = existingMasterByID(existingID)
                resolvedPersonName = CellText(masterSnapshot(1, ACC_COL_PERSON))
                relationshipText = CellText(masterSnapshot(1, ACC_COL_RELATIONSHIP))
                If Len(sourceRelationshipText) > 0 And Len(relationshipText) > 0 Then
                    If NormalizeRelationshipKey(sourceRelationshipText) <> NormalizeRelationshipKey(relationshipText) Then
                        Err.Raise vbObjectError + 6149, "CommitExternalRows", _
                                  "登録済み口座と取込資料の続柄が異なります。訂正モードで確認してください: " & accountID
                    End If
                End If
            End If
            accountIDByKey.Add keyText, accountID
            personNameByKey.Add keyText, resolvedPersonName
            relationshipByKey.Add keyText, relationshipText
            firstIndexByKey.Add keyText, i
            accountCount = accountCount + 1
        End If
        recordType = CStr(prepared(i, PREP_RECORD_TYPE))
        If recordType = RECORD_OPEN Then
            If openDateByKey.Exists(keyText) Then
                Err.Raise vbObjectError + 6111, "CommitExternalRows", _
                          "同じ口座に口座開設日行が複数あります: " & CStr(prepared(i, PREP_ACCOUNT_NO))
            End If
            openDateByKey.Add keyText, prepared(i, PREP_DATE)
        ElseIf recordType = RECORD_CLOSE Then
            If closeDateByKey.Exists(keyText) Then
                Err.Raise vbObjectError + 6112, "CommitExternalRows", _
                          "同じ口座に口座解約日行が複数あります: " & CStr(prepared(i, PREP_ACCOUNT_NO))
            End If
            closeDateByKey.Add keyText, prepared(i, PREP_DATE)
        ElseIf recordType = RECORD_BALANCE Then
            balanceKey = keyText & Chr$(29) & DateSignature(prepared(i, PREP_DATE))
            If sourceBalanceDates.Exists(balanceKey) Then
                Err.Raise vbObjectError + 6129, "CommitExternalRows", _
                          "同じ口座・同じ基準日の残高行が複数あります: " & _
                          CStr(prepared(i, PREP_ACCOUNT_NO)) & " / " & Format$(CDate(prepared(i, PREP_DATE)), "yyyy/m/d")
            End If
            sourceBalanceDates.Add balanceKey, True
        End If
    Next i

    '新規口座数が確定してからまとめて採番し、W_状態を口座ごとに更新しない。
    If newAccountKeys.Count > 0 Then
        accountIDs = ReserveInternalIds(STATE_NEXT_ACCOUNT, "A", newAccountKeys.Count)
        For i = 1 To newAccountKeys.Count
            keyText = CStr(newAccountKeys(i))
            accountID = CStr(accountIDs(i))
            accountIDByKey(keyText) = accountID
            createdAccountIDs(accountID) = True
            accountRowByID.Add accountID, nextMasterRow
            nextMasterRow = nextMasterRow + 1
        Next i
    End If

    '人物IDも口座ごとに状態表へ書かず、既存IDとの整合を確認してから新規人物だけを一括採番する。
    For Each item In accountIDByKey.Keys
        keyText = CStr(item)
        accountID = CStr(accountIDByKey(keyText))
        firstIndex = CLng(firstIndexByKey(keyText))
        personNameKey = PersonLookupKey(CStr(personNameByKey(keyText)), _
                                        CStr(relationshipByKey(keyText)))
        personID = ""
        If Not CBool(newAccountByKey(keyText)) Then
            If Not accountRowByID.Exists(accountID) Then _
                Err.Raise vbObjectError + 6113, "CommitExternalRows", "既存口座マスタを取得できません: " & accountID
            masterRow = CLng(accountRowByID(accountID))
            masterSnapshot = existingMasterByID(accountID)
            personID = CellText(masterSnapshot(1, ACC_COL_PERSON_ID))
        End If
        If Len(personID) = 0 Then
            If personIDByName.Exists(personNameKey) Then personID = CStr(personIDByName(personNameKey))
        End If
        If Len(personID) > 0 Then
            relationshipText = ValidatedIndexedRelationshipForPersonID( _
                               personRelationshipByID, personID, _
                               CStr(relationshipByKey(keyText)))
            relationshipByKey(keyText) = relationshipText
            '続柄空欄を既存IDの確定値で補った場合は、補完後の同一性キーで
            '人物IDの競合と後続口座の共有を判定する。
            personNameKey = PersonLookupKey(CStr(personNameByKey(keyText)), _
                                             relationshipText)
            If personIDByName.Exists(personNameKey) Then
                existingID = CStr(personIDByName(personNameKey))
                If Len(existingID) > 0 And StrComp(existingID, personID, vbTextCompare) <> 0 Then
                    Err.Raise vbObjectError + 6126, "CommitExternalRows", _
                              "同じ氏名・続柄に異なる人物IDがあります。先に該当する口座・人物の登録内容を確認してください: " & _
                              CStr(prepared(firstIndex, PREP_PERSON))
                ElseIf Len(existingID) = 0 Then
                    personIDByName(personNameKey) = personID
                    If pendingPersonKeys.Exists(personNameKey) Then pendingPersonKeys.Remove personNameKey
                End If
            Else
                personIDByName.Add personNameKey, personID
            End If
        ElseIf Not personIDByName.Exists(personNameKey) Then
            personIDByName.Add personNameKey, ""
            pendingPersonKeys.Add personNameKey, True
            newPersonKeyOrder.Add personNameKey
        End If
        personLookupKeyByAccountKey.Add keyText, personNameKey
        personIDByKey.Add keyText, personID
    Next item
    If pendingPersonKeys.Count > 0 Then
        personIDs = ReserveInternalIds(STATE_NEXT_PERSON, "P", pendingPersonKeys.Count)
        personReserveIndex = 0
        For i = 1 To newPersonKeyOrder.Count
            personNameKey = CStr(newPersonKeyOrder(i))
            If pendingPersonKeys.Exists(personNameKey) Then
                personReserveIndex = personReserveIndex + 1
                personIDByName(personNameKey) = CStr(personIDs(personReserveIndex))
            End If
        Next i
    End If
    For Each item In accountIDByKey.Keys
        keyText = CStr(item)
        If Len(CStr(personIDByKey(keyText))) = 0 Then
            personNameKey = CStr(personLookupKeyByAccountKey(keyText))
            If Not personIDByName.Exists(personNameKey) Then _
                Err.Raise vbObjectError + 6154, "CommitExternalRows", "人物IDの割当を確認できません。"
            personID = CStr(personIDByName(personNameKey))
            If Len(personID) = 0 Then _
                Err.Raise vbObjectError + 6154, "CommitExternalRows", "人物IDの割当が空欄です。"
            personIDByKey(keyText) = personID
        End If
        personID = CStr(personIDByKey(keyText))
        relationshipText = ValidatedIndexedRelationshipForPersonID( _
                           personRelationshipByID, personID, _
                           CStr(relationshipByKey(keyText)))
        relationshipByKey(keyText) = relationshipText
        AddExternalPersonAliasToIndex personAliasByID, personID, _
                                      CStr(personNameByKey(keyText)), _
                                      "外部取込予定「" & keyText & "」"
    Next item

    '既存ストアと取込予定を一度だけ索引化し、同一人物IDの全名義に
    '確定続柄を適用した将来状態を検査する。口座ごとの全表再走査は行わない。
    ValidateExternalFuturePersonIdentities personIDByName, personRelationshipByID, _
                                           personAliasByID

    '既存口座の日付が空欄なら外部表で補完できるが、異なる登録済み日付は訂正モードを使う。
    '外部取込だけで既存の開設日・解約日を上書きせず、特殊行の二重登録も防ぐ。
    For Each item In accountIDByKey.Keys
        keyText = CStr(item)
        accountID = CStr(accountIDByKey(keyText))
        If CBool(newAccountByKey(keyText)) Then
            effectiveOpen = DictionaryValueOrBlank(openDateByKey, keyText)
            effectiveClose = DictionaryValueOrBlank(closeDateByKey, keyText)
        Else
            If Not accountRowByID.Exists(accountID) Then _
                Err.Raise vbObjectError + 6113, "CommitExternalRows", "既存口座マスタを取得できません: " & accountID
            masterRow = CLng(accountRowByID(accountID))
            masterSnapshot = existingMasterByID(accountID)
            effectiveOpen = masterSnapshot(1, ACC_COL_OPEN_DATE)
            effectiveClose = masterSnapshot(1, ACC_COL_CLOSE_DATE)
            If IsError(effectiveOpen) Then Err.Raise vbObjectError + 6114, "CommitExternalRows", "既存口座の開設日が不正です: " & accountID
            If IsError(effectiveClose) Then Err.Raise vbObjectError + 6115, "CommitExternalRows", "既存口座の解約日が不正です: " & accountID
            If HasText(effectiveOpen) Then
                If Not IsDate(effectiveOpen) Then Err.Raise vbObjectError + 6114, "CommitExternalRows", "既存口座の開設日が不正です: " & accountID
            End If
            If HasText(effectiveClose) Then
                If Not IsDate(effectiveClose) Then Err.Raise vbObjectError + 6115, "CommitExternalRows", "既存口座の解約日が不正です: " & accountID
            End If
            If openDateByKey.Exists(keyText) Then
                If IsDate(effectiveOpen) Then
                    If DateSignature(effectiveOpen) <> DateSignature(openDateByKey(keyText)) Then
                        Err.Raise vbObjectError + 6116, "CommitExternalRows", _
                                  "既存口座の開設日と取込値が異なります。登録済み口座の訂正モードを使用してください: " & accountID
                    End If
                End If
                specialKey = ExistingSpecialRecordKey(accountID, RECORD_OPEN)
                If existingSpecialDates.Exists(specialKey) Then
                    If Not IsDate(effectiveOpen) Or CStr(existingSpecialDates(specialKey)) <> DateSignature(openDateByKey(keyText)) Then
                        Err.Raise vbObjectError + 6117, "CommitExternalRows", "既存の口座開設日行と口座マスタが一致しません: " & accountID
                    End If
                    skipSpecialByType(specialKey) = True
                End If
                effectiveOpen = openDateByKey(keyText)
            End If
            If closeDateByKey.Exists(keyText) Then
                If IsDate(effectiveClose) Then
                    If DateSignature(effectiveClose) <> DateSignature(closeDateByKey(keyText)) Then
                        Err.Raise vbObjectError + 6118, "CommitExternalRows", _
                                  "既存口座の解約日と取込値が異なります。登録済み口座の訂正モードを使用してください: " & accountID
                    End If
                End If
                specialKey = ExistingSpecialRecordKey(accountID, RECORD_CLOSE)
                If existingSpecialDates.Exists(specialKey) Then
                    If Not IsDate(effectiveClose) Or CStr(existingSpecialDates(specialKey)) <> DateSignature(closeDateByKey(keyText)) Then
                        Err.Raise vbObjectError + 6119, "CommitExternalRows", "既存の口座解約日行と口座マスタが一致しません: " & accountID
                    End If
                    skipSpecialByType(specialKey) = True
                End If
                effectiveClose = closeDateByKey(keyText)
            End If
            specialKey = ExistingSpecialRecordKey(accountID, RECORD_OPEN)
            If existingSpecialDates.Exists(specialKey) Then
                If Not IsDate(effectiveOpen) Then
                    Err.Raise vbObjectError + 6137, "CommitExternalRows", "口座開設日行に対応する口座マスタ日付がありません: " & accountID
                ElseIf CStr(existingSpecialDates(specialKey)) <> DateSignature(effectiveOpen) Then
                    Err.Raise vbObjectError + 6138, "CommitExternalRows", "既存の口座開設日行と口座マスタが一致しません: " & accountID
                End If
            ElseIf IsDate(effectiveOpen) And Not openDateByKey.Exists(keyText) Then
                Err.Raise vbObjectError + 6139, "CommitExternalRows", "口座マスタの開設日に対応する取引行がありません。先に該当する口座・人物の登録内容を確認してください: " & accountID
            End If
            specialKey = ExistingSpecialRecordKey(accountID, RECORD_CLOSE)
            If existingSpecialDates.Exists(specialKey) Then
                If Not IsDate(effectiveClose) Then
                    Err.Raise vbObjectError + 6140, "CommitExternalRows", "口座解約日行に対応する口座マスタ日付がありません: " & accountID
                ElseIf CStr(existingSpecialDates(specialKey)) <> DateSignature(effectiveClose) Then
                    Err.Raise vbObjectError + 6141, "CommitExternalRows", "既存の口座解約日行と口座マスタが一致しません: " & accountID
                End If
            ElseIf IsDate(effectiveClose) And Not closeDateByKey.Exists(keyText) Then
                Err.Raise vbObjectError + 6142, "CommitExternalRows", "口座マスタの解約日に対応する取引行がありません。先に該当する口座・人物の登録内容を確認してください: " & accountID
            End If
        End If
        openDateByKey(keyText) = effectiveOpen
        closeDateByKey(keyText) = effectiveClose
        If IsDate(effectiveOpen) And IsDate(effectiveClose) Then
            If CDate(effectiveOpen) > CDate(effectiveClose) Then
                Err.Raise vbObjectError + 6110, "CommitExternalRows", _
                          "口座「" & CStr(prepared(CLng(firstIndexByKey(keyText)), PREP_ACCOUNT_NO)) & "」の開設日が解約日より後です。"
            End If
        End If
    Next item

    '開設前・解約後の取引は、外部取込でも手入力と同じ基準で拒否する。
    For i = 1 To preparedCount
        keyText = CanonicalAccountKey(CStr(prepared(i, PREP_BANK)), CStr(prepared(i, PREP_BRANCH)), _
                                      CStr(prepared(i, PREP_PERSON)), CStr(prepared(i, PREP_TYPE)), _
                                      CStr(prepared(i, PREP_ACCOUNT_NO)))
        effectiveOpen = DictionaryValueOrBlank(openDateByKey, keyText)
        effectiveClose = DictionaryValueOrBlank(closeDateByKey, keyText)
        If IsDate(effectiveOpen) Then
            If CDate(prepared(i, PREP_DATE)) < CDate(effectiveOpen) Then
                Err.Raise vbObjectError + 6130, "CommitExternalRows", _
                          "口座「" & CStr(prepared(i, PREP_ACCOUNT_NO)) & "」に開設日前の行があります（取込元 " & _
                          CStr(prepared(i, PREP_INPUT_ORDER)) & "行）。"
            End If
        End If
        If IsDate(effectiveClose) Then
            If CDate(prepared(i, PREP_DATE)) > CDate(effectiveClose) Then
                Err.Raise vbObjectError + 6131, "CommitExternalRows", _
                          "口座「" & CStr(prepared(i, PREP_ACCOUNT_NO)) & "」に解約日後の行があります（取込元 " & _
                          CStr(prepared(i, PREP_INPUT_ORDER)) & "行）。"
            End If
        End If
    Next i

    ReDim outData(1 To preparedCount, 1 To WORK_TX_COL_PERSON_ID)
    ReDim balanceOutData(1 To preparedCount, 1 To WORK_BAL_COL_PERSON_ID)
    ReDim outAccountKeys(1 To preparedCount)
    ReDim balanceAccountKeys(1 To preparedCount)
    For i = 1 To preparedCount
        keyText = CanonicalAccountKey(CStr(prepared(i, PREP_BANK)), CStr(prepared(i, PREP_BRANCH)), _
                                      CStr(prepared(i, PREP_PERSON)), CStr(prepared(i, PREP_TYPE)), _
                                      CStr(prepared(i, PREP_ACCOUNT_NO)))
        accountID = CStr(accountIDByKey(keyText))
        recordType = CStr(prepared(i, PREP_RECORD_TYPE))
        skipRow = False
        If recordType = RECORD_OPEN Or recordType = RECORD_CLOSE Then
            skipRow = skipSpecialByType.Exists(ExistingSpecialRecordKey(accountID, recordType))
        End If
        signatureText = ExternalRecordSignature(accountID, prepared, i)
        incomingCount = IncrementDictionaryCount(incomingSignatures, signatureText)
        existingCount = DictionaryLongValue(signatures, signatureText)
        If skipRow Then
            duplicateCount = duplicateCount + 1
        ElseIf incomingCount <= existingCount Then
            duplicateCount = duplicateCount + 1
        Else
            If transferIDByKey.Exists(keyText) Then
                transferID = CStr(transferIDByKey(keyText))
            Else
                transferID = ""
                transferIDByKey.Add keyText, transferID
                newTransferKeys.Add keyText
            End If
            personID = CStr(personIDByKey(keyText))
            outCount = outCount + 1
            outAccountKeys(outCount) = keyText
            outData(outCount, OUT_COL_BANK) = prepared(i, PREP_BANK)
            outData(outCount, OUT_COL_BRANCH) = prepared(i, PREP_BRANCH)
            outData(outCount, OUT_COL_PERSON) = personNameByKey(keyText)
            outData(outCount, OUT_COL_ACCOUNT_TYPE) = prepared(i, PREP_TYPE)
            outData(outCount, OUT_COL_ACCOUNT_NO) = prepared(i, PREP_ACCOUNT_NO)
            outData(outCount, OUT_COL_DATE) = prepared(i, PREP_DATE)
            outData(outCount, OUT_COL_TIME) = prepared(i, PREP_TIME)
            outData(outCount, OUT_COL_WITHDRAW) = prepared(i, PREP_WITHDRAW)
            outData(outCount, OUT_COL_DEPOSIT) = prepared(i, PREP_DEPOSIT)
            outData(outCount, OUT_COL_SHOP) = prepared(i, PREP_SHOP)
            outData(outCount, OUT_COL_MACHINE) = prepared(i, PREP_MACHINE)
            outData(outCount, OUT_COL_TEKIYO) = prepared(i, PREP_TEKIYO)
            outData(outCount, OUT_COL_OTHER) = prepared(i, PREP_AFTER_BALANCE)
            outData(outCount, WORK_TX_COL_RELATIONSHIP) = relationshipByKey(keyText)
            outData(outCount, WORK_TX_COL_ACCOUNT_ID) = accountID
            outData(outCount, WORK_TX_COL_TRANSFER_ID) = transferID
            outData(outCount, WORK_TX_COL_RECORD_TYPE) = prepared(i, PREP_RECORD_TYPE)
            outData(outCount, WORK_TX_COL_INPUT_ORDER) = prepared(i, PREP_INPUT_ORDER)
            outData(outCount, WORK_TX_COL_SOURCE) = SOURCE_EXTERNAL
            outData(outCount, WORK_TX_COL_PERSON_ID) = personID
            If recordType = RECORD_BALANCE Then
                balanceKey = BalanceImportKey(accountID, prepared(i, PREP_DATE))
                If existingBalanceAmounts.Exists(balanceKey) Then
                    Err.Raise vbObjectError + 6132, "CommitExternalRows", _
                              "残高保管には同じ口座・基準日の残高が既にありますが、対応する取引行が一致しません: " & _
                              accountID & " / " & Format$(CDate(prepared(i, PREP_DATE)), "yyyy/m/d")
                End If
                balanceCount = balanceCount + 1
                balanceAccountKeys(balanceCount) = keyText
                balanceOutData(balanceCount, 1) = personNameByKey(keyText)
                balanceOutData(balanceCount, 2) = prepared(i, PREP_BANK)
                balanceOutData(balanceCount, 3) = prepared(i, PREP_BRANCH)
                balanceOutData(balanceCount, 4) = prepared(i, PREP_TYPE)
                balanceOutData(balanceCount, 5) = prepared(i, PREP_ACCOUNT_NO)
                balanceOutData(balanceCount, 6) = DictionaryValueOrBlank(openDateByKey, keyText)
                balanceOutData(balanceCount, 7) = DictionaryValueOrBlank(closeDateByKey, keyText)
                balanceOutData(balanceCount, 8) = prepared(i, PREP_DATE)
                balanceOutData(balanceCount, 9) = prepared(i, PREP_TEKIYO)
                balanceOutData(balanceCount, 10) = prepared(i, PREP_AFTER_BALANCE)
                balanceOutData(balanceCount, 11) = ""
                balanceOutData(balanceCount, WORK_BAL_COL_RELATIONSHIP) = relationshipByKey(keyText)
                balanceOutData(balanceCount, WORK_BAL_COL_ACCOUNT_ID) = accountID
                balanceOutData(balanceCount, WORK_BAL_COL_TRANSFER_ID) = transferID
                balanceOutData(balanceCount, WORK_BAL_COL_SOURCE) = SOURCE_EXTERNAL
                balanceOutData(balanceCount, WORK_BAL_COL_PERSON_ID) = personID
            End If
            accountHasRows(keyText) = True
        End If
        If recordType = RECORD_BALANCE And (skipRow Or incomingCount <= existingCount) Then
            balanceKey = BalanceImportKey(accountID, prepared(i, PREP_DATE))
            If Not existingBalanceAmounts.Exists(balanceKey) Then
                Err.Raise vbObjectError + 6133, "CommitExternalRows", _
                          "既存の残高取引行に対応する残高保管がありません。先に該当する口座・人物の登録内容を確認してください: " & accountID
            ElseIf CStr(existingBalanceAmounts(balanceKey)) <> AmountSignature(prepared(i, PREP_AFTER_BALANCE)) Then
                Err.Raise vbObjectError + 6134, "CommitExternalRows", _
                          "既存の残高保管と取込値が一致しません: " & accountID & " / " & _
                          Format$(CDate(prepared(i, PREP_DATE)), "yyyy/m/d")
            End If
        End If
    Next i

    '追加対象の口座単位で転記回IDをまとめて採番する。全件重複の口座には発行しない。
    If newTransferKeys.Count > 0 Then
        transferIDs = ReserveInternalIds(STATE_NEXT_TRANSFER, "R", newTransferKeys.Count)
        For i = 1 To newTransferKeys.Count
            keyText = CStr(newTransferKeys(i))
            transferID = CStr(transferIDs(i))
            transferIDByKey(keyText) = transferID
        Next i
        For i = 1 To outCount
            outData(i, WORK_TX_COL_TRANSFER_ID) = transferIDByKey(outAccountKeys(i))
        Next i
        For i = 1 To balanceCount
            balanceOutData(i, WORK_BAL_COL_TRANSFER_ID) = transferIDByKey(balanceAccountKeys(i))
        Next i
    End If

    '件数確定後に明細IDをまとめて採番し、最大10万行の取込でもW_状態へのCOM書込みを
    '1行ごとに繰り返さない。
    If outCount > 0 Then
        transactionIDs = ReserveInternalIds(STATE_NEXT_TRANSACTION, "T", outCount)
        For i = 1 To outCount
            outData(i, WORK_TX_COL_TRANSACTION_ID) = transactionIDs(i)
        Next i
    End If
    If balanceCount > 0 Then
        balanceIDs = ReserveInternalIds(STATE_NEXT_BALANCE, "B", balanceCount)
        For i = 1 To balanceCount
            balanceOutData(i, WORK_BAL_COL_BALANCE_ID) = balanceIDs(i)
        Next i
    End If

    EnsureInternalAppendCapacity wsTx, outCount, "W_取引"
    EnsureInternalAppendCapacity wsBal, balanceCount, "W_残高"
    EnsureInternalAppendCapacity wsAcc, createdAccountIDs.Count, "W_口座"

    '人物ID列までの内部ストアと人物候補を別トランザクションにしない。
    '候補5表も書込前に退避し、候補追加・収束の例外で内部ストアだけを
    '確定しない。
    If outCount > 0 Then
        SnapshotSheetBlock SH_BANK_CAND, 4, bankCandidateSnapshot, bankCandidateRows
        SnapshotSheetBlock SH_BRANCH_CAND, 4, branchCandidateSnapshot, branchCandidateRows
        SnapshotSheetBlock SH_PERSON_CAND, 4, personCandidateSnapshot, personCandidateRows
        SnapshotSheetBlock SH_ACCOUNT_TYPE, 4, typeCandidateSnapshot, typeCandidateRows
        SnapshotSheetBlock SH_TEKIYO, 4, tekiyoCandidateSnapshot, tekiyoCandidateRows
        candidateSnapshotsCaptured = True
    End If

    If outCount > 0 Then
        ReDim writeData(1 To outCount, 1 To WORK_TX_COL_PERSON_ID)
        ReDim expectedWriteData(1 To outCount, 1 To WORK_TX_COL_PERSON_ID)
        For i = 1 To outCount
            For c = 1 To WORK_TX_COL_PERSON_ID
                expectedWriteData(i, c) = ExternalExpectedStoredValue2(outData(i, c), _
                                                                       "取引", i, c)
                writeData(i, c) = expectedWriteData(i, c)
            Next c
        Next i
        firstR = RequireExternalAppendRow(wsTx, "W_取引")
        If outCount > wsTx.Rows.Count - firstR + 1 Then _
            Err.Raise vbObjectError + 6143, "CommitExternalRows", "取引保管がExcelの行上限を超えます。案件を分割してください。"
        writeStarted = True
        wsTx.Range(wsTx.Cells(firstR, 1), wsTx.Cells(firstR + outCount - 1, OUT_COL_ACCOUNT_NO)).NumberFormatLocal = "@"
        wsTx.Range(wsTx.Cells(firstR, OUT_COL_SHOP), wsTx.Cells(firstR + outCount - 1, OUT_COL_TEKIYO)).NumberFormatLocal = "@"
        wsTx.Range(wsTx.Cells(firstR, WORK_TX_COL_RELATIONSHIP), _
                   wsTx.Cells(firstR + outCount - 1, WORK_TX_COL_PERSON_ID)).NumberFormatLocal = "@"
        wsTx.Range(wsTx.Cells(firstR, 1), _
                   wsTx.Cells(firstR + outCount - 1, WORK_TX_COL_PERSON_ID)).Value2 = writeData
        FormatImportedWorkRows wsTx, firstR, firstR + outCount - 1
        If Not RangeValue2MatchesMatrixStrict( _
            wsTx.Range(wsTx.Cells(firstR, 1), _
                       wsTx.Cells(firstR + outCount - 1, WORK_TX_COL_PERSON_ID)), _
            expectedWriteData, outCount, WORK_TX_COL_PERSON_ID) Then _
            Err.Raise vbObjectError + 6170, "CommitExternalRows", _
                      "外部取引の追記読戻しが全行・全列・型で一致しません。"
    End If
    If balanceCount > 0 Then
        ReDim writeBalanceData(1 To balanceCount, 1 To WORK_BAL_COL_PERSON_ID)
        ReDim expectedBalanceWriteData(1 To balanceCount, 1 To WORK_BAL_COL_PERSON_ID)
        For i = 1 To balanceCount
            For c = 1 To WORK_BAL_COL_PERSON_ID
                expectedBalanceWriteData(i, c) = ExternalExpectedStoredValue2( _
                                                        balanceOutData(i, c), "残高", i, c)
                writeBalanceData(i, c) = expectedBalanceWriteData(i, c)
            Next c
        Next i
        balanceFirstR = RequireExternalAppendRow(wsBal, "W_残高")
        If balanceCount > wsBal.Rows.Count - balanceFirstR + 1 Then _
            Err.Raise vbObjectError + 6144, "CommitExternalRows", "残高保管がExcelの行上限を超えます。案件を分割してください。"
        writeStarted = True
        wsBal.Range(wsBal.Cells(balanceFirstR, 1), wsBal.Cells(balanceFirstR + balanceCount - 1, 5)).NumberFormatLocal = "@"
        wsBal.Range(wsBal.Cells(balanceFirstR, 9), wsBal.Cells(balanceFirstR + balanceCount - 1, 9)).NumberFormatLocal = "@"
        wsBal.Range(wsBal.Cells(balanceFirstR, 11), _
                    wsBal.Cells(balanceFirstR + balanceCount - 1, WORK_BAL_COL_PERSON_ID)).NumberFormatLocal = "@"
        wsBal.Range(wsBal.Cells(balanceFirstR, 1), _
                    wsBal.Cells(balanceFirstR + balanceCount - 1, WORK_BAL_COL_PERSON_ID)).Value2 = writeBalanceData
        FormatImportedBalanceRows wsBal, balanceFirstR, balanceFirstR + balanceCount - 1
        If Not RangeValue2MatchesMatrixStrict( _
            wsBal.Range(wsBal.Cells(balanceFirstR, 1), _
                        wsBal.Cells(balanceFirstR + balanceCount - 1, WORK_BAL_COL_PERSON_ID)), _
            expectedBalanceWriteData, balanceCount, WORK_BAL_COL_PERSON_ID) Then _
            Err.Raise vbObjectError + 6171, "CommitExternalRows", _
                      "外部残高の追記読戻しが全行・全列・型で一致しません。"
    End If

    For Each item In accountIDByKey.Keys
        keyText = CStr(item)
        If accountHasRows.Exists(keyText) Then
            firstIndex = CLng(firstIndexByKey(keyText))
            accountID = CStr(accountIDByKey(keyText))
            transferID = CStr(transferIDByKey(keyText))
            personID = CStr(personIDByKey(keyText))
            masterSource = SOURCE_EXTERNAL
            If Not accountRowByID.Exists(accountID) Then _
                Err.Raise vbObjectError + 6125, "CommitExternalRows", "口座マスタの書込位置を取得できません: " & accountID
            masterRow = CLng(accountRowByID(accountID))
            If Not CBool(newAccountByKey(keyText)) Then
                masterSnapshot = existingMasterByID(accountID)
                If Len(CellText(masterSnapshot(1, ACC_COL_SOURCE))) > 0 Then
                    masterSource = CellText(masterSnapshot(1, ACC_COL_SOURCE))
                End If
            End If
            UpsertAccountMaster accountID, transferID, CStr(prepared(firstIndex, PREP_BANK)), _
                                CStr(prepared(firstIndex, PREP_BRANCH)), CStr(personNameByKey(keyText)), _
                                CStr(relationshipByKey(keyText)), CStr(prepared(firstIndex, PREP_TYPE)), _
                                CStr(prepared(firstIndex, PREP_ACCOUNT_NO)), DictionaryValueOrBlank(openDateByKey, keyText), _
                                DictionaryValueOrBlank(closeDateByKey, keyText), personID, masterSource, masterRow
        End If
    Next item

    '人物ID付き候補をコア書込みと同じトランザクション内で更新する。
    'ここの失敗は警告で握りつぶさず、候補表と内部3ストアを全復元する。
    If outCount > 0 Then
        candidateWritesStarted = True
        BeginCandidateBatchUpdate
        candidateBatchStarted = True
        For Each item In firstIndexByKey.Keys
            keyText = CStr(item)
            If accountHasRows.Exists(keyText) Then
                firstIndex = CLng(firstIndexByKey(keyText))
                AddBankCandidate CStr(prepared(firstIndex, PREP_BANK))
                AddBranchCandidate CStr(prepared(firstIndex, PREP_BRANCH))
                AddAccountTypeCandidate CStr(prepared(firstIndex, PREP_TYPE))
                AddPersonCandidateWithID CStr(personNameByKey(keyText)), _
                                         CStr(personIDByKey(keyText)), _
                                         CStr(relationshipByKey(keyText))
            End If
        Next item
        EndCandidateBatchUpdate
        candidateBatchStarted = False
    End If

    If outCount > 0 Then
        MarkOutputsDirty
        InvalidateDuplicateAccountWarningCache
        '全追記と口座マスタ更新を確認した後、確定フラグを立てる前に主キー・参照・
        '最新転記回・人物ID関係を全体で再検査する。
        If Not RequireInternalStoresSafeForWrite() Then _
            Err.Raise vbObjectError + 6173, "CommitExternalRows", _
                      "外部取込後の内部データ関係検査に失敗しました。"
    End If
    committed = True
    dataCommitted = True
    importedCount = outCount

    On Error Resume Next
    Err.Clear
    BuildRegisteredAccountsSheet False, True
    postProcessErrorNumber = Err.Number
    postProcessErrorDescription = Err.Description
    postProcessErrorSource = Err.Source
    Err.Clear
    On Error GoTo 0
    If IsExternalImportRecoveryFatal( _
           postProcessErrorNumber, postProcessErrorSource) Then _
        RethrowExternalImportRecoveryFatal _
            postProcessErrorNumber, postProcessErrorSource, _
            postProcessErrorDescription
    If postProcessErrorNumber <> 0 Then
        AppendExternalDetail postProcessDetail, _
                             "登録済み口座一覧の再構築失敗: Err " & _
                             postProcessErrorNumber & " " & _
                             postProcessErrorDescription
    End If
    If Len(postProcessDetail) > 0 Then
        postCommitWarning = postProcessDetail
        AddCheck IIf(ToolDataHealthIsNormal(), "警告", "エラー"), _
                 "外部取込後処理", _
                 "内部保管への取込は完了しています。" & postProcessDetail
    End If
    Exit Sub

EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    If IsExternalImportRecoveryFatal(errorNumber, errorSource) Then _
        RethrowExternalImportRecoveryFatal _
            errorNumber, errorSource, errorDescription
    rollbackVerified = True
    If Not committed Then
        On Error Resume Next
        If candidateBatchStarted Then
            Err.Clear
            EndCandidateBatchUpdate
            rollbackStepErrorNumber = Err.Number
            rollbackStepErrorDescription = Err.Description
            rollbackStepErrorSource = Err.Source
            Err.Clear
            On Error GoTo 0
            If IsExternalImportRecoveryFatal( _
                   rollbackStepErrorNumber, rollbackStepErrorSource) Then _
                RethrowExternalImportRecoveryFatal _
                    rollbackStepErrorNumber, rollbackStepErrorSource, _
                    rollbackStepErrorDescription
            On Error Resume Next
            If rollbackStepErrorNumber <> 0 Then _
                AppendExternalDetail rollbackDetail, _
                                     "候補バッチ終了時エラー（全体復元を継続）: " & _
                                     rollbackStepErrorDescription
            candidateBatchStarted = False
        End If
        If candidateWritesStarted Then
            Err.Clear
            If candidateSnapshotsCaptured Then
                RestoreCommonCandidateSnapshots _
                    bankCandidateSnapshot, bankCandidateRows, _
                    branchCandidateSnapshot, branchCandidateRows, _
                    personCandidateSnapshot, personCandidateRows, _
                    typeCandidateSnapshot, typeCandidateRows, _
                    tekiyoCandidateSnapshot, tekiyoCandidateRows
            Else
                Err.Raise vbObjectError + 6223, "CommitExternalRows", _
                          "候補5表の取込前退避を確認できません。"
            End If
            If Err.Number <> 0 Then
                candidateRestoreFailed = True
                AppendExternalDetail rollbackDetail, "候補5表の全体復元エラー: " & Err.Description
            End If
            '定義名と保護範囲も復元後の行数へ再接続する。深さ0での終了呼出しは
            'バッチ索引を使わず、候補名の更新と保護検証だけを行う。
            Err.Clear
            EndCandidateBatchUpdate
            rollbackStepErrorNumber = Err.Number
            rollbackStepErrorDescription = Err.Description
            rollbackStepErrorSource = Err.Source
            Err.Clear
            On Error GoTo 0
            If IsExternalImportRecoveryFatal( _
                   rollbackStepErrorNumber, rollbackStepErrorSource) Then _
                RethrowExternalImportRecoveryFatal _
                    rollbackStepErrorNumber, rollbackStepErrorSource, _
                    rollbackStepErrorDescription
            On Error Resume Next
            If rollbackStepErrorNumber <> 0 Then
                candidateRestoreFailed = True
                AppendExternalDetail rollbackDetail, _
                                     "候補定義名・保護の復元エラー: " & _
                                     rollbackStepErrorDescription
            End If
        End If
        If writeStarted Then
            If storeSnapshotsCaptured Then
                Err.Clear
                RestoreExternalStoreSnapshot wsTx, WORK_TX_COL_PERSON_ID, txStoreSnapshot, txStoreRows, "W_取引"
                If Err.Number <> 0 Then
                    storeRestoreFailed = True
                    AppendExternalDetail rollbackDetail, "取引保管の全体復元エラー: " & Err.Description
                End If
                Err.Clear
                RestoreExternalStoreSnapshot wsBal, WORK_BAL_COL_PERSON_ID, balanceStoreSnapshot, balanceStoreRows, "W_残高"
                If Err.Number <> 0 Then
                    storeRestoreFailed = True
                    AppendExternalDetail rollbackDetail, "残高保管の全体復元エラー: " & Err.Description
                End If
                Err.Clear
                RestoreExternalStoreSnapshot wsAcc, ACC_COL_TRANSFER_ID, accountStoreSnapshot, accountStoreRows, "W_口座"
                If Err.Number <> 0 Then
                    storeRestoreFailed = True
                    AppendExternalDetail rollbackDetail, "口座保管の全体復元エラー: " & Err.Description
                End If
            Else
                storeRestoreFailed = True
                AppendExternalDetail rollbackDetail, "内部3ストアの取込前退避を確認できません。"
            End If
        End If
        '復元処理が一つでも例外を出した場合は、後続の部分的な照合結果にかかわらず
        '成功扱いにしない。各Restore helperは全行・全列・順序・型を読戻している。
        If storeRestoreFailed Or candidateRestoreFailed Then rollbackVerified = False
        Err.Clear
        On Error GoTo 0
    End If
    If idCountersCaptured And Not committed And rollbackVerified Then
        On Error Resume Next
        Err.Clear
        RestoreInternalIdCounters idCounterSnapshot
        If Err.Number <> 0 Then
            AppendExternalDetail rollbackDetail, "ID採番状態の復元エラー: " & Err.Description
            '内部3ストアが一致していても、採番状態を戻せなければ取込前状態とはいえない。
            rollbackVerified = False
            counterRestoreFailed = True
        End If
        Err.Clear
        On Error GoTo 0
    End If
    If (Not committed And (writeStarted Or candidateWritesStarted) And Not rollbackVerified) Or _
       counterRestoreFailed Then
        '下位トランザクションでRecoveryを開始せず、外側UI操作が所有する
        'Application leaseの後始末と一緒に、一度だけ復旧処理を行う。
        rollbackRecoveryRequired = True
        rollbackRecoveryConfirmed = False
        AppendExternalDetail rollbackDetail, _
            "外側操作で案件要復旧状態を確定する必要があります。"
    End If
    If Len(rollbackDetail) > 0 Then
        If rollbackVerified Then
            errorDescription = errorDescription & " / ロールバック処理警告（復元結果は一致）: " & rollbackDetail
        Else
            errorDescription = errorDescription & " / ロールバック確認: " & rollbackDetail
        End If
    End If
    If Len(errorSource) = 0 Then errorSource = "CommitExternalRows"
    Err.Raise errorNumber, errorSource, errorDescription
End Sub

Private Function ExternalExpectedStoredValue2(ByVal valueIn As Variant, _
                                              ByVal storeName As String, _
                                              ByVal rowNo As Long, _
                                              ByVal columnNo As Long) As Variant
    '一括書込み後のRange.Value2型へ正規化し、表示文字列だけの一致にしない。
    If IsError(valueIn) Then _
        Err.Raise vbObjectError + 6172, "ExternalExpectedStoredValue2", _
                  storeName & "追記予定" & CStr(rowNo) & "行" & CStr(columnNo) & _
                  "列にExcelエラー値があります。"
    If IsNull(valueIn) Or IsEmpty(valueIn) Then
        ExternalExpectedStoredValue2 = Empty
    ElseIf VarType(valueIn) = vbString And Len(CStr(valueIn)) = 0 Then
        ExternalExpectedStoredValue2 = Empty
    ElseIf storeName = "取引" And columnNo = WORK_TX_COL_INPUT_ORDER Then
        ExternalExpectedStoredValue2 = CStr(valueIn)
    ElseIf VarType(valueIn) = vbDate Then
        ExternalExpectedStoredValue2 = CDbl(valueIn)
    ElseIf VarType(valueIn) <> vbString And VarType(valueIn) <> vbBoolean And IsNumeric(valueIn) Then
        ExternalExpectedStoredValue2 = CDbl(valueIn)
    Else
        ExternalExpectedStoredValue2 = valueIn
    End If
End Function

Private Sub LoadExistingPersonIdIndex(ByVal personIndex As Object)
    Dim relationshipIndex As Object, personAliasByID As Object
    Set relationshipIndex = NewTextDictionary()
    Set personAliasByID = NewTextDictionary()
    LoadExistingPersonIndexes personIndex, relationshipIndex, personAliasByID
End Sub

Private Sub LoadExistingPersonIndexes(ByVal personIndex As Object, _
                                      ByVal relationshipIndex As Object, _
                                      ByVal personAliasByID As Object)
    '外部取込中に人物候補・口座マスタを口座ごとに再走査しない。
    '同じ正規化氏名+続柄に異なるIDが既にあれば停止するが、
    '改姓等による同一IDの別名義は現行の契約どおり許容する。
    Dim ws As Worksheet, lastR As Long, r As Long
    Dim sourceData As Variant
    Dim personName As String, relationshipText As String, personID As String
    If personIndex Is Nothing Then Exit Sub
    If SheetExists(SH_PERSON_CAND) Then
        Set ws = GetSheet(SH_PERSON_CAND)
        lastR = LastUsedRowInSheet(ws)
        If lastR >= 2 Then
            sourceData = ws.Range(ws.Cells(2, 1), ws.Cells(lastR, 3)).Value2
            For r = 1 To lastR - 1
                personName = CellText(sourceData(r, 1))
                personID = CellText(sourceData(r, 2))
                relationshipText = CellText(sourceData(r, 3))
                AddPersonIdToIndex personIndex, PersonLookupKey(personName, relationshipText), _
                                   personID, "人物候補 " & CStr(r + 1) & "行"
                AddPersonRelationshipToIndex relationshipIndex, personID, relationshipText, _
                                             "人物候補 " & CStr(r + 1) & "行"
                AddExternalPersonAliasToIndex personAliasByID, personID, personName, _
                                              "人物候補 " & CStr(r + 1) & "行"
            Next r
        End If
    End If
    If SheetExists(SH_WORK_ACCOUNT) Then
        Set ws = GetSheet(SH_WORK_ACCOUNT)
        lastR = LastUsedRowInSheet(ws)
        If lastR >= 2 Then
            sourceData = ws.Range(ws.Cells(2, ACC_COL_PERSON), _
                                  ws.Cells(lastR, ACC_COL_PERSON_ID)).Value2
            For r = 1 To lastR - 1
                personName = CellText(sourceData(r, 1))
                relationshipText = CellText(sourceData(r, ACC_COL_RELATIONSHIP - ACC_COL_PERSON + 1))
                personID = CellText(sourceData(r, ACC_COL_PERSON_ID - ACC_COL_PERSON + 1))
                AddPersonIdToIndex personIndex, PersonLookupKey(personName, relationshipText), _
                                   personID, "W_口座 " & CStr(r + 1) & "行"
                AddPersonRelationshipToIndex relationshipIndex, personID, relationshipText, _
                                             "W_口座 " & CStr(r + 1) & "行"
                AddExternalPersonAliasToIndex personAliasByID, personID, personName, _
                                              "W_口座 " & CStr(r + 1) & "行"
            Next r
        End If
    End If
End Sub

Private Sub AddPersonRelationshipToIndex(ByVal relationshipIndex As Object, ByVal personID As String, _
                                         ByVal relationshipText As String, ByVal sourceText As String)
    Dim relationshipKey As String, storedRelationship As String
    personID = CellText(personID)
    If relationshipIndex Is Nothing Or Len(personID) = 0 Then Exit Sub
    If Not IsInternalIdValue(personID, "P") Then _
        Err.Raise vbObjectError + 6157, "LoadExistingPersonIdIndex", _
                  "人物IDの形式が不正です（" & sourceText & "）: " & personID
    relationshipKey = NormalizeRelationshipKey(relationshipText)
    If Len(relationshipKey) = 0 Then Exit Sub
    If relationshipIndex.Exists(personID) Then
        storedRelationship = CStr(relationshipIndex(personID))
        If NormalizeRelationshipKey(storedRelationship) <> relationshipKey Then _
            Err.Raise vbObjectError + 6160, "LoadExistingPersonIdIndex", _
                      "同一人物IDに異なる続柄があります（" & sourceText & "）: " & personID
    Else
        relationshipIndex.Add personID, CellText(relationshipText)
    End If
End Sub

Private Function ValidatedIndexedRelationshipForPersonID(ByVal relationshipIndex As Object, _
                                                          ByVal personID As String, _
                                                          ByVal requestedRelationship As String) As String
    Dim storedRelationship As String
    Dim storedKey As String, requestedKey As String
    personID = CellText(personID)
    requestedRelationship = CellText(requestedRelationship)
    If Len(personID) = 0 Then
        ValidatedIndexedRelationshipForPersonID = requestedRelationship
        Exit Function
    End If
    If Not IsInternalIdValue(personID, "P") Then _
        Err.Raise vbObjectError + 6157, "ValidatedIndexedRelationshipForPersonID", _
                  "人物IDの形式が不正です: " & personID
    If relationshipIndex Is Nothing Then _
        Err.Raise vbObjectError + 6161, "ValidatedIndexedRelationshipForPersonID", _
                  "人物ID別の続柄索引を取得できません。"
    requestedKey = NormalizeRelationshipKey(requestedRelationship)
    If relationshipIndex.Exists(personID) Then
        storedRelationship = CellText(relationshipIndex(personID))
        storedKey = NormalizeRelationshipKey(storedRelationship)
        If Len(requestedKey) > 0 And requestedKey <> storedKey Then _
            Err.Raise vbObjectError + 6162, "ValidatedIndexedRelationshipForPersonID", _
                      "同一人物IDの続柄が既存候補または登録済み口座と一致しません: " & personID
        If Len(requestedKey) = 0 Then
            ValidatedIndexedRelationshipForPersonID = storedRelationship
        Else
            ValidatedIndexedRelationshipForPersonID = requestedRelationship
        End If
    Else
        If Len(requestedKey) > 0 Then _
            relationshipIndex.Add personID, requestedRelationship
        ValidatedIndexedRelationshipForPersonID = requestedRelationship
    End If
End Function

Private Sub AddPersonIdToIndex(ByVal personIndex As Object, ByVal personNameKey As String, _
                               ByVal personID As String, ByVal sourceText As String)
    If personIndex Is Nothing Then Exit Sub
    If Len(personNameKey) = 0 Or Len(personID) = 0 Then Exit Sub
    If Not IsInternalIdValue(personID, "P") Then _
        Err.Raise vbObjectError + 6157, "LoadExistingPersonIdIndex", _
                  "人物IDの形式が不正です（" & sourceText & "）: " & personID
    If personIndex.Exists(personNameKey) Then
        If StrComp(CStr(personIndex(personNameKey)), personID, vbTextCompare) <> 0 Then
            Err.Raise vbObjectError + 6127, "LoadExistingPersonIdIndex", _
                      "同じ氏名・続柄に異なる人物IDがあります（" & sourceText & "）。先に該当する口座・人物の登録内容を確認してください。"
        End If
    Else
        personIndex.Add personNameKey, personID
    End If
End Sub

Private Sub AddExternalPersonAliasToIndex(ByVal personAliasByID As Object, _
                                          ByVal personID As String, _
                                          ByVal personName As String, _
                                          ByVal sourceText As String)
    'IDごとの名義をフラットな複合キーで保持し、Dictionaryの入れ子を
    '口座ごとに作らない。同じ正規化名義は1件に収束する。
    Dim personNameKey As String, aliasKey As String
    personID = CellText(personID)
    personName = CellText(personName)
    If personAliasByID Is Nothing Or Len(personID) = 0 Then Exit Sub
    If Not IsInternalIdValue(personID, "P") Then _
        Err.Raise vbObjectError + 6220, "AddExternalPersonAliasToIndex", _
                  "人物IDの形式が不正です（" & sourceText & "）: " & personID
    personNameKey = NormalizePersonNameKey(personName)
    If Len(personNameKey) = 0 Then Exit Sub
    aliasKey = UCase$(personID) & Chr$(29) & personNameKey
    If Not personAliasByID.Exists(aliasKey) Then _
        personAliasByID.Add aliasKey, Array(personID, personName)
End Sub

Private Sub ProjectExternalPersonAliasesToIdentityIndex( _
        ByVal personIndex As Object, ByVal relationshipIndex As Object, _
        ByVal personAliasByID As Object)
    '人物IDに確定続柄があるとき、同IDの空欄続柄名義も収束後の
    'identityとして採番前索引へ加える。これにより新IDの誤発行を防ぐ。
    Dim item As Variant, aliasData As Variant
    Dim personID As String, personName As String, relationshipText As String
    If personIndex Is Nothing Or relationshipIndex Is Nothing Or _
       personAliasByID Is Nothing Then _
        Err.Raise vbObjectError + 6221, _
                  "ProjectExternalPersonAliasesToIdentityIndex", _
                  "人物同一性の一括索引を取得できません。"
    For Each item In personAliasByID.Keys
        aliasData = personAliasByID(item)
        If Not IsArray(aliasData) Then _
            Err.Raise vbObjectError + 6222, _
                      "ProjectExternalPersonAliasesToIdentityIndex", _
                      "人物名義索引が壊れています。"
        personID = CellText(aliasData(0))
        personName = CellText(aliasData(1))
        relationshipText = vbNullString
        If relationshipIndex.Exists(personID) Then _
            relationshipText = CellText(relationshipIndex(personID))
        AddPersonIdToIndex personIndex, _
                           PersonLookupKey(personName, relationshipText), _
                           personID, "続柄収束予定「" & personName & "」"
    Next item
End Sub

Private Function ExternalFutureIdentityConflictID( _
        ByVal personIndex As Object, ByVal relationshipIndex As Object, _
        ByVal personAliasByID As Object, ByRef conflictingPersonName As String, _
        ByRef allowedPersonID As String) As String
    'identity索引の複製に、各IDの全名義+確定続柄を1回ずつ重ねる。
    '全表の再走査をしないため、既存行+取込口座+名義数に比例する。
    Dim futureIndex As Object
    Dim item As Variant, aliasData As Variant
    Dim personID As String, personName As String, relationshipText As String
    Dim identityKey As String, existingID As String
    conflictingPersonName = vbNullString
    allowedPersonID = vbNullString
    If personIndex Is Nothing Or relationshipIndex Is Nothing Or _
       personAliasByID Is Nothing Then _
        Err.Raise vbObjectError + 6221, "ExternalFutureIdentityConflictID", _
                  "人物同一性の一括索引を取得できません。"
    Set futureIndex = NewTextDictionary()
    For Each item In personIndex.Keys
        identityKey = CStr(item)
        existingID = CellText(personIndex(item))
        If Len(identityKey) > 0 And Len(existingID) > 0 Then _
            futureIndex(identityKey) = existingID
    Next item

    For Each item In personAliasByID.Keys
        aliasData = personAliasByID(item)
        If Not IsArray(aliasData) Then _
            Err.Raise vbObjectError + 6222, "ExternalFutureIdentityConflictID", _
                      "人物名義索引が壊れています。"
        personID = CellText(aliasData(0))
        personName = CellText(aliasData(1))
        relationshipText = vbNullString
        If relationshipIndex.Exists(personID) Then _
            relationshipText = CellText(relationshipIndex(personID))
        identityKey = PersonLookupKey(personName, relationshipText)
        If Len(identityKey) > 0 Then
            If futureIndex.Exists(identityKey) Then
                existingID = CellText(futureIndex(identityKey))
                If Len(existingID) > 0 And _
                   StrComp(existingID, personID, vbTextCompare) <> 0 Then
                    conflictingPersonName = personName
                    allowedPersonID = personID
                    ExternalFutureIdentityConflictID = existingID
                    Exit Function
                End If
            Else
                futureIndex.Add identityKey, personID
            End If
        End If
    Next item
End Function

Private Sub ValidateExternalFuturePersonIdentities( _
        ByVal personIndex As Object, ByVal relationshipIndex As Object, _
        ByVal personAliasByID As Object)
    Dim conflictingPersonName As String, allowedPersonID As String
    Dim conflictingPersonID As String
    conflictingPersonID = ExternalFutureIdentityConflictID( _
                              personIndex, relationshipIndex, personAliasByID, _
                              conflictingPersonName, allowedPersonID)
    If Len(conflictingPersonID) > 0 Then _
        Err.Raise vbObjectError + 6164, "ValidateExternalFuturePersonIdentities", _
                  "続柄補完後に氏名「" & conflictingPersonName & _
                  "」が別の人物ID（" & conflictingPersonID & _
                  "）と重複します（補完対象=" & allowedPersonID & _
                  "）。人物候補を修正してから再取込してください。"
End Sub


Private Function PersonLookupKey(ByVal personName As String, ByVal relationshipText As String) As String
    PersonLookupKey = PersonIdentityKey(personName, relationshipText)
End Function

Private Sub LoadExistingAccountIndexes(ByVal wsAcc As Worksheet, ByVal accountIndex As Object, _
                                       ByVal locatorIndex As Object, ByVal rowByID As Object)
    Dim r As Long, lastR As Long
    Dim accountID As String, keyText As String, locatorKey As String
    Dim accountIDs As Object
    Dim sourceData As Variant
    If wsAcc Is Nothing Or accountIndex Is Nothing Or locatorIndex Is Nothing Or rowByID Is Nothing Then Exit Sub
    Set accountIDs = NewTextDictionary()
    lastR = LastUsedRowInSheet(wsAcc)
    If lastR < 2 Then Exit Sub
    sourceData = wsAcc.Range(wsAcc.Cells(2, ACC_COL_ID), wsAcc.Cells(lastR, ACC_COL_NO)).Value2
    For r = 1 To lastR - 1
        accountID = CellText(sourceData(r, ACC_COL_ID))
        If Len(accountID) = 0 Then
            Err.Raise vbObjectError + 6122, "LoadExistingAccountIndexes", _
                      "既存口座マスタに口座IDのない行があります。先に該当する口座・人物の登録内容を確認してください。"
        End If
        If accountIDs.Exists(accountID) Then
            Err.Raise vbObjectError + 6124, "LoadExistingAccountIndexes", _
                      "既存口座マスタに口座IDの重複があります。先に該当する口座・人物の登録内容を確認してください: " & accountID
        End If
        accountIDs.Add accountID, True
        rowByID.Add accountID, r + 1
        keyText = CanonicalAccountKey(CellText(sourceData(r, ACC_COL_BANK)), _
                                      CellText(sourceData(r, ACC_COL_BRANCH)), _
                                      CellText(sourceData(r, ACC_COL_PERSON)), _
                                      CellText(sourceData(r, ACC_COL_TYPE)), _
                                      CellText(sourceData(r, ACC_COL_NO)))
        If accountIndex.Exists(keyText) Then
            Err.Raise vbObjectError + 6123, "LoadExistingAccountIndexes", _
                      "既存口座マスタに同一口座が重複しています。先に該当する口座・人物の登録内容を確認してください。"
        End If
        accountIndex.Add keyText, accountID
        locatorKey = CanonicalAccountLocatorKey(CellText(sourceData(r, ACC_COL_BANK)), _
                                                CellText(sourceData(r, ACC_COL_BRANCH)), _
                                                CellText(sourceData(r, ACC_COL_TYPE)), _
                                                CellText(sourceData(r, ACC_COL_NO)))
        If locatorIndex.Exists(locatorKey) Then
            Err.Raise vbObjectError + 6150, "LoadExistingAccountIndexes", _
                      "既存口座マスタに同じ銀行・支店・科目・口座番号の重複があります。先に該当する口座・人物の登録内容を確認してください。"
        End If
        locatorIndex.Add locatorKey, accountID
    Next r
End Sub


Private Sub AppendExternalDetail(ByRef detailText As String, ByVal newDetail As String)
    newDetail = Trim$(newDetail)
    If Len(newDetail) = 0 Then Exit Sub
    If Len(detailText) > 0 Then detailText = detailText & " / "
    detailText = detailText & newDetail
End Sub

Private Function RequireExternalAppendRow(ByVal ws As Worksheet, _
                                          ByVal storeLabel As String) As Long
    'Find失敗を空シートと誤認して既存データを2行目から上書きしない。
    Dim lastUsedRow As Long
    If ws Is Nothing Then _
        Err.Raise vbObjectError + 6174, "RequireExternalAppendRow", _
                  storeLabel & "を取得できません。"
    If Not TryGetLastUsedRowInSheet(ws, lastUsedRow) Then _
        Err.Raise vbObjectError + 6175, "RequireExternalAppendRow(" & ws.Name & ")", _
                  storeLabel & "の最終行を安全に確認できないため、外部取込の追記を中止しました。"
    If lastUsedRow < 1 Then lastUsedRow = 1
    If lastUsedRow >= ws.Rows.Count Then _
        Err.Raise vbObjectError + 6176, "RequireExternalAppendRow(" & ws.Name & ")", _
                  storeLabel & "がExcelの行上限に達しています。"
    RequireExternalAppendRow = lastUsedRow + 1
    If RequireExternalAppendRow < 2 Then RequireExternalAppendRow = 2
End Function

Public Sub CaptureInternalStoreSnapshotWithPrefix(ByVal ws As Worksheet, _
                                                  ByVal lastColumn As Long, _
                                                  ByRef snapshot As Variant, _
                                                  ByRef snapshotRows As Long)
    '口座削除など、外部取込以外の原子的変更からも同じ厳格退避を利用する。
    SnapshotExternalStore ws, lastColumn, snapshot, snapshotRows
End Sub

Public Sub RestoreInternalStoreSnapshotWithPrefix(ByVal ws As Worksheet, _
                                                  ByVal lastColumn As Long, _
                                                  ByRef snapshot As Variant, _
                                                  ByVal snapshotRows As Long, _
                                                  ByVal storeLabel As String)
    RestoreExternalStoreSnapshot ws, lastColumn, snapshot, snapshotRows, storeLabel
End Sub

Public Function InternalStoreMatchesSnapshotWithPrefix(ByVal ws As Worksheet, _
                                                        ByVal lastColumn As Long, _
                                                        ByRef snapshot As Variant, _
                                                        ByVal expectedRows As Long) As Boolean
    InternalStoreMatchesSnapshotWithPrefix = _
        ExternalStoreMatchesSnapshot(ws, lastColumn, snapshot, expectedRows)
End Function

Private Sub SnapshotExternalStore(ByVal ws As Worksheet, ByVal lastColumn As Long, _
                                  ByRef snapshot As Variant, ByRef snapshotRows As Long)
    '外部取込の破壊的書込み前に、内部ストアを行順・全列・Variant型・
    'PrefixCharacter込みで固定する。先頭アポストロフィ付きの「=...」を
    'Value2だけで退避すると復元時に数式化し得るため、接頭辞を別に保持する。
    Dim lastR As Long
    Dim dataRange As Range
    Dim snapshotItems As Collection
    Dim valueData As Variant
    Dim formulaCells As Object, prefixCells As Object
    If ws Is Nothing Then _
        Err.Raise vbObjectError + 6160, "SnapshotExternalStore", "内部ストアがありません。"
    If lastColumn < 1 Or lastColumn > ws.Columns.Count Then _
        Err.Raise vbObjectError + 6161, "SnapshotExternalStore", _
                  "内部ストアの最終列が不正です: " & ws.Name

    lastR = LastDataRowInColumns(ws, 1, lastColumn)
    If lastR < 2 Then
        snapshotRows = 0
        Set prefixCells = NewTextDictionary()
        Set snapshotItems = New Collection
        snapshotItems.Add Empty
        snapshotItems.Add prefixCells
        Set snapshot = snapshotItems
    Else
        snapshotRows = lastR - 1
        If snapshotRows > MAX_INTERNAL_STORE_DATA_ROWS Then _
            Err.Raise vbObjectError + 6177, "SnapshotExternalStore", _
                      ws.Name & "は" & Format$(snapshotRows, "#,##0") & _
                      "行あり、内部保管の実用上限（" & _
                      Format$(MAX_INTERNAL_STORE_DATA_ROWS, "#,##0") & _
                      "行）を超えています。データは変更していません。" & _
                      "案件を分割するか、内部保管の不要行・重複行を整理してください。"
        Set dataRange = ws.Range(ws.Cells(2, 1), ws.Cells(lastR, lastColumn))
        CaptureSheetSnapshotMetadata dataRange, formulaCells, prefixCells
        If formulaCells.Count > 0 Then _
            Err.Raise vbObjectError + 6163, "SnapshotExternalStore", _
                      ws.Name & "に数式があります。内部データの安全な変更を中止しました。"
        valueData = dataRange.Value2
        If Not IsArray(valueData) Then _
            Err.Raise vbObjectError + 6164, "SnapshotExternalStore", _
                      ws.Name & "の退避配列を取得できません。"
        Set snapshotItems = New Collection
        snapshotItems.Add valueData
        snapshotItems.Add prefixCells
        Set snapshot = snapshotItems
    End If
    If Not ExternalStoreMatchesSnapshot(ws, lastColumn, snapshot, snapshotRows) Then _
        Err.Raise vbObjectError + 6165, "SnapshotExternalStore", _
                  ws.Name & "の退避直後照合に失敗しました。"
End Sub

Private Sub RestoreExternalStoreSnapshot(ByVal ws As Worksheet, ByVal lastColumn As Long, _
                                         ByRef snapshot As Variant, ByVal snapshotRows As Long, _
                                         ByVal storeLabel As String)
    'ID列を条件にした部分削除では、ID列まで書かれなかった部分行を除去できない。
    '現在のデータ領域を全消去して取込前配列を戻し、余剰行・型・接頭辞も厳密照合する。
    Dim currentLastR As Long, clearLastR As Long, r As Long, c As Long
    Dim targetRange As Range, targetCell As Range
    Dim snapshotItems As Collection
    Dim valueData As Variant, constantData() As Variant
    Dim prefixCells As Object
    Dim keyText As String, prefixText As String
    If ws Is Nothing Then _
        Err.Raise vbObjectError + 6166, "RestoreExternalStoreSnapshot", _
                  storeLabel & "がありません。"
    If lastColumn < 1 Or lastColumn > ws.Columns.Count Or snapshotRows < 0 Then _
        Err.Raise vbObjectError + 6167, "RestoreExternalStoreSnapshot", _
                  storeLabel & "の退避範囲が不正です。"
    If Not IsObject(snapshot) Then _
        Err.Raise vbObjectError + 6168, "RestoreExternalStoreSnapshot", _
                  storeLabel & "の退避情報がありません。"
    Set snapshotItems = snapshot
    If snapshotItems.Count <> STORE_SNAPSHOT_ITEM_COUNT Then _
        Err.Raise vbObjectError + 6168, "RestoreExternalStoreSnapshot", _
                  storeLabel & "の退避情報が不足しています。"
    valueData = snapshotItems(STORE_SNAPSHOT_VALUE2)
    Set prefixCells = snapshotItems(STORE_SNAPSHOT_PREFIX)
    If snapshotRows > 0 Then
        If Not ExternalSnapshotArrayDimensionsMatch(valueData, valueData, _
                                                    snapshotRows, lastColumn) Then _
            Err.Raise vbObjectError + 6168, "RestoreExternalStoreSnapshot", _
                      storeLabel & "の退避配列範囲が一致しません。"
    ElseIf prefixCells.Count <> 0 Then
        Err.Raise vbObjectError + 6168, "RestoreExternalStoreSnapshot", _
                  storeLabel & "の空退避情報に接頭辞が残っています。"
    End If

    currentLastR = LastDataRowInColumns(ws, 1, lastColumn)
    clearLastR = currentLastR
    If snapshotRows + 1 > clearLastR Then clearLastR = snapshotRows + 1
    If clearLastR >= 2 Then _
        ws.Range(ws.Cells(2, 1), ws.Cells(clearLastR, lastColumn)).ClearContents
    If snapshotRows > 0 Then
        Set targetRange = ws.Range(ws.Cells(2, 1), ws.Cells(snapshotRows + 1, lastColumn))
        ReDim constantData(1 To snapshotRows, 1 To lastColumn)
        For r = 1 To snapshotRows
            For c = 1 To lastColumn
                keyText = ExternalSnapshotCellKey(r, c)
                If Not prefixCells.Exists(keyText) And _
                   Not ExternalSnapshotConstantNeedsLiteralRestore(valueData(r, c)) Then
                    constantData(r, c) = valueData(r, c)
                End If
            Next c
        Next r
        targetRange.Value2 = constantData
        For r = 1 To snapshotRows
            For c = 1 To lastColumn
                keyText = ExternalSnapshotCellKey(r, c)
                If prefixCells.Exists(keyText) Then
                    prefixText = CStr(prefixCells(keyText))
                    Set targetCell = ws.Cells(r + 1, c)
                    RestoreExternalSnapshotLiteral targetCell, valueData(r, c), prefixText
                ElseIf ExternalSnapshotConstantNeedsLiteralRestore(valueData(r, c)) Then
                    Set targetCell = ws.Cells(r + 1, c)
                    RestoreExternalSnapshotLiteral targetCell, valueData(r, c), ""
                End If
            Next c
        Next r
    End If

    If Not ExternalStoreMatchesSnapshot(ws, lastColumn, snapshot, snapshotRows) Then _
        Err.Raise vbObjectError + 6169, "RestoreExternalStoreSnapshot", _
                  storeLabel & "が取込前の行順・全列・型・接頭辞と一致しません。"
End Sub

Private Function ExternalStoreMatchesSnapshot(ByVal ws As Worksheet, ByVal lastColumn As Long, _
                                              ByRef snapshot As Variant, _
                                              ByVal expectedRows As Long) As Boolean
    Dim snapshotItems As Collection
    Dim expectedData As Variant, actualData As Variant
    Dim expectedPrefixCells As Object
    Dim actualFormulaCells As Object, actualPrefixCells As Object
    Dim actualLastR As Long, actualRows As Long
    Dim r As Long, c As Long
    Dim dataRange As Range
    Dim keyText As String
    On Error GoTo Failed
    If ws Is Nothing Or lastColumn < 1 Or expectedRows < 0 Then Exit Function
    If Not IsObject(snapshot) Then Exit Function
    Set snapshotItems = snapshot
    If snapshotItems.Count <> STORE_SNAPSHOT_ITEM_COUNT Then Exit Function
    expectedData = snapshotItems(STORE_SNAPSHOT_VALUE2)
    Set expectedPrefixCells = snapshotItems(STORE_SNAPSHOT_PREFIX)
    actualLastR = LastDataRowInColumns(ws, 1, lastColumn)
    If actualLastR >= 2 Then actualRows = actualLastR - 1
    If actualRows <> expectedRows Then Exit Function
    If expectedRows = 0 Then
        If expectedPrefixCells.Count <> 0 Then Exit Function
        ExternalStoreMatchesSnapshot = True
        Exit Function
    End If
    If Not IsArray(expectedData) Then Exit Function
    Set dataRange = ws.Range(ws.Cells(2, 1), ws.Cells(expectedRows + 1, lastColumn))
    CaptureSheetSnapshotMetadata dataRange, actualFormulaCells, actualPrefixCells
    If actualFormulaCells.Count <> 0 Then Exit Function
    If expectedPrefixCells.Count <> actualPrefixCells.Count Then Exit Function
    actualData = dataRange.Value2
    If Not IsArray(actualData) Then Exit Function
    If LBound(expectedData, 1) <> LBound(actualData, 1) Or _
       UBound(expectedData, 1) <> UBound(actualData, 1) Or _
       LBound(expectedData, 2) <> LBound(actualData, 2) Or _
       UBound(expectedData, 2) <> UBound(actualData, 2) Then Exit Function
    For r = LBound(expectedData, 1) To UBound(expectedData, 1)
        For c = LBound(expectedData, 2) To UBound(expectedData, 2)
            keyText = ExternalSnapshotCellKey(r, c)
            If expectedPrefixCells.Exists(keyText) <> actualPrefixCells.Exists(keyText) Then Exit Function
            If expectedPrefixCells.Exists(keyText) Then
                If StrComp(CStr(expectedPrefixCells(keyText)), CStr(actualPrefixCells(keyText)), _
                           vbBinaryCompare) <> 0 Then Exit Function
            End If
            If Not ExternalStoreSnapshotValueMatches(expectedData(r, c), actualData(r, c)) Then Exit Function
        Next c
    Next r
    ExternalStoreMatchesSnapshot = True
    Exit Function
Failed:
    ExternalStoreMatchesSnapshot = False
End Function

Private Function ExternalStoreSnapshotValueMatches(ByVal expectedValue As Variant, _
                                                   ByVal actualValue As Variant) As Boolean
    'CStr比較では数値1と文字列"1"を同一視するため、Variant型を先に一致させる。
    Dim expectedType As VbVarType, actualType As VbVarType
    On Error GoTo Failed
    expectedType = VarType(expectedValue)
    actualType = VarType(actualValue)
    If expectedType <> actualType Then Exit Function
    Select Case expectedType
        Case vbEmpty, vbNull
            ExternalStoreSnapshotValueMatches = True
        Case vbError
            ExternalStoreSnapshotValueMatches = _
                (Application.WorksheetFunction.Error_Type(expectedValue) = _
                 Application.WorksheetFunction.Error_Type(actualValue))
        Case vbString
            ExternalStoreSnapshotValueMatches = _
                (StrComp(CStr(expectedValue), CStr(actualValue), vbBinaryCompare) = 0)
        Case Else
            ExternalStoreSnapshotValueMatches = (expectedValue = actualValue)
    End Select
    Exit Function
Failed:
    ExternalStoreSnapshotValueMatches = False
End Function


Private Sub LoadExistingTransactionSignatures(ByVal ws As Worksheet, ByVal signatures As Object)
    Dim r As Long, lastR As Long, signatureText As String, accountID As String
    Dim coreData As Variant, accountData As Variant, recordTypeData As Variant
    If ws Is Nothing Or signatures Is Nothing Then Exit Sub
    lastR = LastUsedRowInSheet(ws)
    If lastR < 2 Then Exit Sub
    '署名に必要な列だけを一括取得し、1行につき多数回のExcel COM読取を避ける。
    coreData = ws.Range(ws.Cells(2, OUT_COL_DATE), ws.Cells(lastR, OUT_COL_OTHER)).Value2
    accountData = ws.Range(ws.Cells(2, WORK_TX_COL_ACCOUNT_ID), _
                           ws.Cells(lastR, WORK_TX_COL_ACCOUNT_ID)).Value2
    recordTypeData = ws.Range(ws.Cells(2, WORK_TX_COL_RECORD_TYPE), _
                              ws.Cells(lastR, WORK_TX_COL_RECORD_TYPE)).Value2
    For r = 1 To lastR - 1
        accountID = CellText(BulkArrayValue(accountData, r))
        signatureText = ""
        If Len(accountID) > 0 Then
            signatureText = accountID & Chr$(28) & DateSignature(coreData(r, 1)) & Chr$(28) & _
                            TimeSignature(coreData(r, 2)) & Chr$(28) & AmountSignature(coreData(r, 3)) & Chr$(28) & _
                            AmountSignature(coreData(r, 4)) & Chr$(28) & CellText(coreData(r, 5)) & Chr$(28) & _
                            CellText(coreData(r, 6)) & Chr$(28) & CellText(coreData(r, 7)) & Chr$(28) & _
                            AmountSignature(coreData(r, 8)) & Chr$(28) & _
                            CellText(BulkArrayValue(recordTypeData, r))
        End If
        If Len(signatureText) > 0 Then IncrementDictionaryCount signatures, signatureText
    Next r
End Sub

Private Sub LoadExistingBalanceIndex(ByVal ws As Worksheet, ByVal balanceAmounts As Object)
    Dim r As Long, lastR As Long, keyText As String, accountID As String
    Dim accountData As Variant, dateAmountData As Variant, balanceDate As Variant, balanceAmount As Variant
    If ws Is Nothing Or balanceAmounts Is Nothing Then Exit Sub
    lastR = LastUsedRowInSheet(ws)
    If lastR < 2 Then Exit Sub
    accountData = ws.Range(ws.Cells(2, WORK_BAL_COL_ACCOUNT_ID), _
                           ws.Cells(lastR, WORK_BAL_COL_ACCOUNT_ID)).Value2
    dateAmountData = ws.Range(ws.Cells(2, 8), ws.Cells(lastR, 10)).Value2
    For r = 1 To lastR - 1
        accountID = CellText(BulkArrayValue(accountData, r))
        balanceDate = dateAmountData(r, 1)
        balanceAmount = dateAmountData(r, 3)
        If Len(accountID) = 0 Or Not IsDate(balanceDate) Or _
           Not HasText(balanceAmount) Or Not IsNumeric(balanceAmount) Then
            Err.Raise vbObjectError + 6135, "LoadExistingBalanceIndex", _
                      "既存の残高保管が不正です。先に該当する口座・人物の登録内容を確認してください（W_残高 " & CStr(r + 1) & "行）。"
        End If
        keyText = BalanceImportKey(accountID, balanceDate)
        If balanceAmounts.Exists(keyText) Then
            Err.Raise vbObjectError + 6136, "LoadExistingBalanceIndex", _
                      "既存の残高保管に同一口座・同一基準日の重複があります: " & accountID
        End If
        balanceAmounts.Add keyText, AmountSignature(balanceAmount)
    Next r
End Sub

Private Function BalanceImportKey(ByVal accountID As String, ByVal balanceDate As Variant) As String
    BalanceImportKey = CellText(accountID) & Chr$(29) & DateSignature(balanceDate)
End Function

Private Function IncrementDictionaryCount(ByVal dict As Object, ByVal keyText As String) As Long
    If dict.Exists(keyText) Then
        dict(keyText) = CLng(dict(keyText)) + 1
    Else
        dict.Add keyText, 1
    End If
    IncrementDictionaryCount = CLng(dict(keyText))
End Function

Private Function DictionaryLongValue(ByVal dict As Object, ByVal keyText As String) As Long
    If Not dict Is Nothing Then
        If dict.Exists(keyText) Then DictionaryLongValue = CLng(dict(keyText))
    End If
End Function

Private Sub LoadExistingSpecialRecordDates(ByVal ws As Worksheet, ByVal specialDates As Object)
    Dim r As Long, lastR As Long
    Dim accountID As String, recordType As String, keyText As String
    Dim dateData As Variant, accountData As Variant, recordTypeData As Variant, recordDate As Variant
    If ws Is Nothing Or specialDates Is Nothing Then Exit Sub
    lastR = LastUsedRowInSheet(ws)
    If lastR < 2 Then Exit Sub
    dateData = ws.Range(ws.Cells(2, OUT_COL_DATE), ws.Cells(lastR, OUT_COL_DATE)).Value2
    accountData = ws.Range(ws.Cells(2, WORK_TX_COL_ACCOUNT_ID), _
                           ws.Cells(lastR, WORK_TX_COL_ACCOUNT_ID)).Value2
    recordTypeData = ws.Range(ws.Cells(2, WORK_TX_COL_RECORD_TYPE), _
                              ws.Cells(lastR, WORK_TX_COL_RECORD_TYPE)).Value2
    For r = 1 To lastR - 1
        recordType = CellText(BulkArrayValue(recordTypeData, r))
        If recordType = RECORD_OPEN Or recordType = RECORD_CLOSE Then
            accountID = CellText(BulkArrayValue(accountData, r))
            If Len(accountID) = 0 Then
                Err.Raise vbObjectError + 6120, "LoadExistingSpecialRecordDates", _
                          "既存の口座開設日・口座解約日行が不正です。先に該当する口座・人物の登録内容を確認してください。"
            End If
            recordDate = BulkArrayValue(dateData, r)
            If IsError(recordDate) Then
                Err.Raise vbObjectError + 6120, "LoadExistingSpecialRecordDates", _
                          "既存の口座開設日・口座解約日行が不正です。先に該当する口座・人物の登録内容を確認してください。"
            End If
            If Not IsDate(recordDate) Then
                Err.Raise vbObjectError + 6120, "LoadExistingSpecialRecordDates", _
                          "既存の口座開設日・口座解約日行が不正です。先に該当する口座・人物の登録内容を確認してください。"
            End If
            keyText = ExistingSpecialRecordKey(accountID, recordType)
            If specialDates.Exists(keyText) Then
                Err.Raise vbObjectError + 6121, "LoadExistingSpecialRecordDates", _
                          "既存の口座開設日・口座解約日行が重複しています: " & accountID
            End If
            specialDates.Add keyText, DateSignature(recordDate)
        End If
    Next r
End Sub

Private Function ExistingSpecialRecordKey(ByVal accountID As String, ByVal recordType As String) As String
    ExistingSpecialRecordKey = CellText(accountID) & Chr$(29) & CellText(recordType)
End Function

Private Function ExternalRecordSignature(ByVal accountID As String, ByRef prepared() As Variant, ByVal r As Long) As String
    ExternalRecordSignature = accountID & Chr$(28) & DateSignature(prepared(r, PREP_DATE)) & Chr$(28) & _
                              TimeSignature(prepared(r, PREP_TIME)) & Chr$(28) & AmountSignature(prepared(r, PREP_WITHDRAW)) & Chr$(28) & _
                              AmountSignature(prepared(r, PREP_DEPOSIT)) & Chr$(28) & CellText(prepared(r, PREP_SHOP)) & Chr$(28) & _
                              CellText(prepared(r, PREP_MACHINE)) & Chr$(28) & CellText(prepared(r, PREP_TEKIYO)) & Chr$(28) & _
                              AmountSignature(prepared(r, PREP_AFTER_BALANCE)) & Chr$(28) & CellText(prepared(r, PREP_RECORD_TYPE))
End Function

Private Function DateSignature(ByVal v As Variant) As String
    If IsDate(v) Then DateSignature = Format$(CDate(v), "yyyymmdd") Else DateSignature = CellText(v)
End Function

Private Function TimeSignature(ByVal v As Variant) As String
    If IsDate(v) Then TimeSignature = Format$(CDate(v), "hhmm") Else TimeSignature = CellText(v)
End Function

Private Function AmountSignature(ByVal v As Variant) As String
    If IsNumeric(v) And HasText(v) Then AmountSignature = Format$(CDbl(v), "0.################") Else AmountSignature = CellText(v)
End Function


Private Sub FormatImportedWorkRows(ByVal ws As Worksheet, ByVal firstR As Long, ByVal lastR As Long)
    ws.Range(ws.Cells(firstR, 1), ws.Cells(lastR, OUT_COL_ACCOUNT_NO)).NumberFormatLocal = "@"
    ws.Range(ws.Cells(firstR, OUT_COL_SHOP), ws.Cells(lastR, OUT_COL_TEKIYO)).NumberFormatLocal = "@"
    ws.Range(ws.Cells(firstR, WORK_TX_COL_RELATIONSHIP), ws.Cells(lastR, WORK_TX_COL_PERSON_ID)).NumberFormatLocal = "@"
    ws.Range(ws.Cells(firstR, OUT_COL_DATE), ws.Cells(lastR, OUT_COL_DATE)).NumberFormatLocal = "yyyy/m/d"
    ws.Range(ws.Cells(firstR, OUT_COL_TIME), ws.Cells(lastR, OUT_COL_TIME)).NumberFormatLocal = "hh:mm"
    ws.Range(ws.Cells(firstR, OUT_COL_WITHDRAW), ws.Cells(lastR, OUT_COL_DEPOSIT)).NumberFormatLocal = "#,##0.########"
    ws.Range(ws.Cells(firstR, OUT_COL_OTHER), ws.Cells(lastR, OUT_COL_OTHER)).NumberFormatLocal = "#,##0.########"
End Sub

Private Sub FormatImportedBalanceRows(ByVal ws As Worksheet, ByVal firstR As Long, ByVal lastR As Long)
    If ws Is Nothing Or firstR < 2 Or lastR < firstR Then Exit Sub
    ws.Range(ws.Cells(firstR, 1), ws.Cells(lastR, 5)).NumberFormatLocal = "@"
    ws.Range(ws.Cells(firstR, 9), ws.Cells(lastR, 9)).NumberFormatLocal = "@"
    ws.Range(ws.Cells(firstR, 11), ws.Cells(lastR, WORK_BAL_COL_PERSON_ID)).NumberFormatLocal = "@"
    ws.Range(ws.Cells(firstR, 6), ws.Cells(lastR, 8)).NumberFormatLocal = "yyyy/m/d"
    ws.Range(ws.Cells(firstR, 10), ws.Cells(lastR, 10)).NumberFormatLocal = "#,##0.########"
End Sub

Private Function DictionaryValueOrBlank(ByVal dict As Object, ByVal keyText As String) As Variant
    If dict.Exists(keyText) Then DictionaryValueOrBlank = dict(keyText) Else DictionaryValueOrBlank = ""
End Function

Private Function BulkArrayValue(ByRef sourceData As Variant, ByVal rowIndex As Long, _
                                Optional ByVal colIndex As Long = 1) As Variant
    'Excelの1セルRange.Value2だけは2次元配列ではなくスカラーを返すため、一括読込側で吸収する。
    If IsArray(sourceData) Then
        BulkArrayValue = sourceData(rowIndex, colIndex)
    ElseIf rowIndex = 1 And colIndex = 1 Then
        BulkArrayValue = sourceData
    Else
        Err.Raise vbObjectError + 6152, "BulkArrayValue", "一括読込配列の範囲が不正です。"
    End If
End Function

Private Function NewTextDictionary() As Object
    Dim dict As Object
    Set dict = CreateObject("Scripting.Dictionary")
    dict.CompareMode = vbTextCompare
    Set NewTextDictionary = dict
End Function

Private Sub AddImportError(ByVal messageText As String, ByVal sourceRow As Long, ByRef errorCount As Long, _
                           ByRef firstError As String, ByRef firstErrorRow As Long)
    errorCount = errorCount + 1
    If Len(firstError) = 0 Then
        firstError = messageText
        firstErrorRow = sourceRow
    End If
End Sub

Private Sub AddExternalCellValueError(ByVal valueIn As Variant, ByVal labelText As String, _
                                      ByVal sourceRow As Long, ByRef errorCount As Long, _
                                      ByRef firstError As String, ByRef firstErrorRow As Long)
    '任意項目のExcelエラー値を空欄として黙って取り込まない。
    If IsError(valueIn) Then _
        AddImportError labelText & "がExcelエラー値です。取込元の数式または値を修正してください。", _
                       sourceRow, errorCount, firstError, firstErrorRow
End Sub

Private Sub AddImportLengthError(ByVal valueText As String, ByVal maxLength As Long, ByVal labelText As String, _
                                 ByVal sourceRow As Long, ByRef errorCount As Long, _
                                 ByRef firstError As String, ByRef firstErrorRow As Long)
    If Len(valueText) > maxLength Then
        AddImportError labelText & "は" & CStr(maxLength) & "文字以内にしてください。", _
                       sourceRow, errorCount, firstError, firstErrorRow
    End If
End Sub

Private Function ParseExternalDate(ByVal v As Variant, ByRef ok As Boolean) As Variant
    Dim d As Variant
    ok = False
    If IsError(v) Or IsNull(v) Or IsEmpty(v) Then Exit Function
    If IsDate(v) Then
        ParseExternalDate = NormalizeDateOnlyValue(v, ok)
        Exit Function
    End If
    d = ResolveAccountDateInput(v, ok)
    If ok Then
        If IsDate(d) Then
            ParseExternalDate = CDate(d)
        Else
            ok = False
        End If
    End If
End Function

Private Function ExternalIdentifierText(ByVal sourceCell As Range, _
                                        Optional ByVal suppliedValue As Variant) As String
    Dim identifierText As String, issueText As String
    Dim rawValue As Variant
    If sourceCell Is Nothing Then Exit Function
    If IsMissing(suppliedValue) Then rawValue = sourceCell.Value2 Else rawValue = suppliedValue
    If TryExternalIdentifierText(sourceCell, rawValue, identifierText, issueText) Then
        ExternalIdentifierText = identifierText
    Else
        Err.Raise vbObjectError + 6192, "ExternalIdentifierText", _
                  issueText & ": " & sourceCell.Parent.Name & "!" & _
                  sourceCell.Address(False, False)
    End If
End Function

Private Function TryExternalIdentifierText(ByVal sourceCell As Range, ByVal rawValue As Variant, _
                                           ByRef identifierText As String, _
                                           ByRef issueText As String) As Boolean
    'rawValueを勝手に推測変換しない。文字列は原文を採用し、数値は識別子として
    '一意に復元できるGeneralまたは0＋ハイフンだけの書式に限定する。
    Dim shownText As String, numberFormatText As String
    Dim numericValue As Double

    identifierText = vbNullString
    issueText = vbNullString
    If sourceCell Is Nothing Then
        issueText = "識別子の元セルを取得できません"
        Exit Function
    End If
    If IsError(rawValue) Then
        issueText = "識別子がExcelエラー値です"
        Exit Function
    End If
    If IsNull(rawValue) Or IsEmpty(rawValue) Then
        TryExternalIdentifierText = True
        Exit Function
    End If
    If VarType(rawValue) = vbString Then
        identifierText = CellText(rawValue)
        TryExternalIdentifierText = True
        Exit Function
    End If
    If VarType(rawValue) = vbBoolean Or Not IsNumeric(rawValue) Then
        issueText = "識別子は文字列または0以上の整数で保存してください"
        Exit Function
    End If

    On Error GoTo FormatReadFailed
    numericValue = CDbl(rawValue)
    If numericValue < 0 Or numericValue <> Fix(numericValue) Then
        issueText = "数値の識別子は0以上の整数で保存してください"
        Exit Function
    End If
    If numericValue >= 1000000000000000# Then
        issueText = "16桁以上の数値識別子は桁丸めを防ぐため文字列で保存してください"
        Exit Function
    End If
    numberFormatText = CStr(sourceCell.NumberFormat)
    shownText = Trim$(CStr(sourceCell.Text))
    TryExternalIdentifierText = TryResolveNumericIdentifierText( _
                                numericValue, numberFormatText, shownText, _
                                identifierText, issueText)
    Exit Function

FormatReadFailed:
    issueText = "識別子の表示形式を安全に確認できません（Err " & _
                CStr(Err.Number) & ": " & Err.Description & "）"
    Err.Clear
End Function

Private Function TryResolveNumericIdentifierText(ByVal numericValue As Double, _
                                                 ByVal numberFormatText As String, _
                                                 ByVal shownText As String, _
                                                 ByRef identifierText As String, _
                                                 ByRef issueText As String) As Boolean
    'Range非依存。列幅不足の#####を値として採用せず、検証済み書式の再現値だけを返す。
    Dim renderedText As String

    identifierText = vbNullString
    issueText = vbNullString
    If Not TryRenderNumericIdentifierFormat(numericValue, numberFormatText, _
                                            renderedText, issueText) Then Exit Function
    shownText = Trim$(shownText)
    If Len(shownText) = 0 Or InStr(1, shownText, "#", vbBinaryCompare) > 0 Then
        identifierText = renderedText
    ElseIf IsSafeDisplayedIdentifierText(shownText) Then
        If StrComp(NormalizeExternalIdentifierHyphens(shownText), _
                   NormalizeExternalIdentifierHyphens(renderedText), _
                   vbBinaryCompare) <> 0 Then
            issueText = "セル表示と数値・表示形式から再現した識別子が一致しません"
            Exit Function
        End If
        identifierText = shownText
    ElseIf StrComp(Trim$(numberFormatText), "General", vbTextCompare) = 0 Then
        'Generalが列幅により指数表示された場合も、15桁未満の整数値そのものは一意。
        identifierText = renderedText
    Else
        issueText = "表示形式が識別子として一意ではありません。文字列として保存してください"
        Exit Function
    End If
    TryResolveNumericIdentifierText = True
End Function

Private Function TryRenderNumericIdentifierFormat(ByVal numericValue As Double, _
                                                  ByVal numberFormatText As String, _
                                                  ByRef renderedText As String, _
                                                  ByRef issueText As String) As Boolean
    'Range非依存の純粋関数。例: 1234567 + 0000-0000 -> 0123-4567。
    '「#」「?」、日付、桁区切り、通貨、色・条件、空白調整等は推測せず失敗させる。
    Dim sections As Variant, formatSection As String
    Dim tokenPattern As String, placeholderMarker As String
    Dim placeholderCount As Long
    Dim i As Long, closeQuote As Long, digitPosition As Long
    Dim ch As String, literalText As String, digitText As String

    renderedText = vbNullString
    issueText = vbNullString
    placeholderMarker = Chr$(1)
    If numericValue < 0 Or numericValue <> Fix(numericValue) Or _
       numericValue >= 1000000000000000# Then
        issueText = "数値識別子は0以上15桁以内の整数にしてください"
        Exit Function
    End If

    sections = Split(numberFormatText, ";")
    formatSection = CStr(sections(LBound(sections)))
    If numericValue = 0 And UBound(sections) - LBound(sections) >= 2 Then _
        formatSection = CStr(sections(LBound(sections) + 2))
    formatSection = Trim$(formatSection)
    If StrComp(formatSection, "General", vbTextCompare) = 0 Then
        renderedText = Format$(numericValue, "0")
        TryRenderNumericIdentifierFormat = True
        Exit Function
    End If
    If Len(formatSection) = 0 Then
        issueText = "空欄を表示する数値書式は識別子に使用できません"
        Exit Function
    End If

    i = 1
    Do While i <= Len(formatSection)
        ch = Mid$(formatSection, i, 1)
        Select Case ch
            Case "0"
                tokenPattern = tokenPattern & placeholderMarker
                placeholderCount = placeholderCount + 1
                i = i + 1
            Case "\"
                If i = Len(formatSection) Then
                    issueText = "表示形式の末尾に不完全なエスケープがあります"
                    Exit Function
                End If
                literalText = Mid$(formatSection, i + 1, 1)
                If Not IsIdentifierFormatHyphen(literalText) Then
                    issueText = "0とハイフン以外の表示形式は識別子へ安全に変換できません"
                    Exit Function
                End If
                tokenPattern = tokenPattern & literalText
                i = i + 2
            Case """"
                closeQuote = InStr(i + 1, formatSection, """")
                If closeQuote = 0 Then
                    issueText = "表示形式の引用符が閉じられていません"
                    Exit Function
                End If
                literalText = Mid$(formatSection, i + 1, closeQuote - i - 1)
                If Len(literalText) <> 1 Or Not IsIdentifierFormatHyphen(literalText) Then
                    issueText = "0とハイフン以外のリテラルは識別子へ安全に変換できません"
                    Exit Function
                End If
                tokenPattern = tokenPattern & literalText
                i = closeQuote + 1
            Case Else
                If IsIdentifierFormatHyphen(ch) Then
                    tokenPattern = tokenPattern & ch
                    i = i + 1
                Else
                    issueText = "0とハイフン以外の表示形式は識別子へ安全に変換できません"
                    Exit Function
                End If
        End Select
    Loop

    If placeholderCount = 0 Or Len(tokenPattern) = 0 Then
        issueText = "表示形式に数値用の0がありません"
        Exit Function
    End If
    If Left$(tokenPattern, 1) <> placeholderMarker Or _
       Right$(tokenPattern, 1) <> placeholderMarker Then
        issueText = "識別子の表示形式は0で始まり0で終わる必要があります"
        Exit Function
    End If

    digitText = Format$(numericValue, "0")
    digitPosition = Len(digitText)
    renderedText = tokenPattern
    For i = Len(tokenPattern) To 1 Step -1
        If Mid$(tokenPattern, i, 1) = placeholderMarker Then
            If digitPosition > 0 Then
                Mid(renderedText, i, 1) = Mid$(digitText, digitPosition, 1)
                digitPosition = digitPosition - 1
            Else
                Mid(renderedText, i, 1) = "0"
            End If
        End If
    Next i
    If digitPosition > 0 Then _
        renderedText = Left$(digitText, digitPosition) & renderedText
    TryRenderNumericIdentifierFormat = True
End Function


Private Function NormalizeExternalIdentifierHyphens(ByVal valueText As String) As String
    Dim s As String
    s = Trim$(valueText)
    s = Replace(s, "－", "-")
    s = Replace(s, "―", "-")
    s = Replace(s, "ー", "-")
    s = Replace(s, "ｰ", "-")
    NormalizeExternalIdentifierHyphens = s
End Function

Private Function IsIdentifierFormatHyphen(ByVal textValue As String) As Boolean
    If Len(textValue) <> 1 Then Exit Function
    Select Case textValue
        Case "-", "－", "―", "ー", "ｰ"
            IsIdentifierFormatHyphen = True
    End Select
End Function

Private Function IsSafeDisplayedIdentifierText(ByVal shownText As String) As Boolean
    Dim s As String, ch As String, i As Long
    Dim hasDigit As Boolean
    s = NormalizeExternalIdentifierHyphens(shownText)
    If Len(s) = 0 Or InStr(s, "#") > 0 Or InStr(1, s, "E", vbTextCompare) > 0 Then Exit Function
    For i = 1 To Len(s)
        ch = Mid$(s, i, 1)
        If ch >= "0" And ch <= "9" Then
            hasDigit = True
        ElseIf ch <> "-" Then
            Exit Function
        End If
    Next i
    IsSafeDisplayedIdentifierText = hasDigit
End Function

Private Function PrepareExternalIdentifier(ByVal rawValue As Variant, ByVal sourceSheet As Worksheet, _
                                           ByVal sourceRow As Long, ByVal sourceColumn As Long, _
                                           ByVal labelText As String, ByRef errorCount As Long, _
                                           ByRef firstError As String, ByRef firstErrorRow As Long) As String
    'Excel数値は有効数字15桁まで。16桁以上の識別子を数値セルから読むと、既に丸められた値を
    '正しい口座番号・コードとして登録してしまうため、元表側で文字列化してもらう。
    '文字列セルは取込配列だけで処理し、表示書式の確認が必要な数値セルだけRangeへ触れる。
    Dim numericValue As Double
    Dim identifierText As String, identifierIssue As String
    Dim sourceCell As Range
    If IsError(rawValue) Or IsNull(rawValue) Or IsEmpty(rawValue) Then Exit Function
    If VarType(rawValue) = vbString Then
        PrepareExternalIdentifier = CellText(rawValue)
        Exit Function
    End If
    If VarType(rawValue) = vbBoolean Then
        AddImportError labelText & "がTRUE/FALSEです。識別子は文字列または0以上の整数で保存してください。", _
                       sourceRow, errorCount, firstError, firstErrorRow
        Exit Function
    End If
    If Not IsNumeric(rawValue) Then
        AddImportError labelText & "を識別子として解釈できません。文字列または0以上の整数で保存してください。", _
                       sourceRow, errorCount, firstError, firstErrorRow
        Exit Function
    End If
    On Error GoTo UnsafeIdentifier
    numericValue = CDbl(rawValue)
    If numericValue < 0 Then
        AddImportError labelText & "が負の数値セルです。識別子は0以上の整数または文字列で保存してください。", _
                       sourceRow, errorCount, firstError, firstErrorRow
        Exit Function
    ElseIf numericValue <> Fix(numericValue) Then
        AddImportError labelText & "が小数の数値セルです。識別子は整数または文字列で保存してください。", _
                       sourceRow, errorCount, firstError, firstErrorRow
        Exit Function
    ElseIf numericValue >= 1000000000000000# Then
        AddImportError labelText & "が16桁以上の数値セルです。桁丸めを防ぐため、取込元で文字列として保存してください。", _
                       sourceRow, errorCount, firstError, firstErrorRow
        Exit Function
    End If
    Set sourceCell = sourceSheet.Cells(sourceRow, sourceColumn)
    If TryExternalIdentifierText(sourceCell, rawValue, identifierText, identifierIssue) Then
        PrepareExternalIdentifier = identifierText
    Else
        AddImportError labelText & "を安全に読み取れません。" & identifierIssue, _
                       sourceRow, errorCount, firstError, firstErrorRow
    End If
    Exit Function
UnsafeIdentifier:
    AddImportError labelText & "が16桁以上の数値セルです。桁丸めを防ぐため、取込元で文字列として保存してください。", _
                   sourceRow, errorCount, firstError, firstErrorRow
    Err.Clear
End Function

Private Sub SplitExternalPerson(ByVal displayText As String, ByRef personName As String, ByRef relationshipText As String)
    Dim p As Long
    personName = CellText(displayText)
    relationshipText = ""
    If Right$(personName, 1) = "）" Then
        p = InStrRev(personName, "（")
        If p > 1 Then
            relationshipText = Mid$(personName, p + 1, Len(personName) - p - 1)
            personName = Trim$(Left$(personName, p - 1))
            Exit Sub
        End If
    End If
    If Right$(personName, 1) = ")" Then
        p = InStrRev(personName, "(")
        If p > 1 Then
            relationshipText = Mid$(personName, p + 1, Len(personName) - p - 1)
            personName = Trim$(Left$(personName, p - 1))
        End If
    End If
End Sub

Private Sub ValidateExternalHeaders(ByVal bankCol As Long, ByVal branchCol As Long, ByVal personCol As Long, _
                                    ByVal typeCol As Long, ByVal accountCol As Long, ByVal dateCol As Long, _
                                    ByVal withdrawCol As Long, ByVal depositCol As Long, ByVal shopCol As Long, _
                                    ByVal machineCol As Long, ByVal tekiyoCol As Long, ByVal balanceCol As Long)
    Dim missing As String
    If bankCol = 0 Then missing = missing & "銀行名、"
    If branchCol = 0 Then missing = missing & "支店名、"
    If personCol = 0 Then missing = missing & "氏名、"
    If typeCol = 0 Then missing = missing & "科目、"
    If accountCol = 0 Then missing = missing & "口座番号、"
    If dateCol = 0 Then missing = missing & "日付、"
    If withdrawCol = 0 Then missing = missing & "出金、"
    If depositCol = 0 Then missing = missing & "入金、"
    If shopCol = 0 Then missing = missing & "取扱店、"
    If machineCol = 0 Then missing = missing & "機番、"
    If tekiyoCol = 0 Then missing = missing & "摘要、"
    If balanceCol = 0 Then missing = missing & "取引後残高、"
    If Len(missing) > 0 Then
        missing = Left$(missing, Len(missing) - 1)
        Err.Raise vbObjectError + 6103, "ValidateExternalHeaders", "必要な見出しがありません: " & missing
    End If
End Sub

Private Sub ValidateExternalHeaderUniqueness(ByVal values As Variant)
    Dim counts(1 To 13) As Long
    Dim c As Long, kindNo As Long
    For c = LBound(values, 2) To UBound(values, 2)
        kindNo = HeaderKind(values(1, c))
        If kindNo >= 1 And kindNo <= 13 Then counts(kindNo) = counts(kindNo) + 1
    Next c
    For kindNo = 1 To 13
        If counts(kindNo) > 1 Then
            Err.Raise vbObjectError + 6104, "ValidateExternalHeaderUniqueness", _
                      "同じ役割の見出しが複数あります: " & ExternalHeaderName(kindNo)
        End If
    Next kindNo
End Sub

Private Function ExternalHeaderName(ByVal kindNo As Long) As String
    Select Case kindNo
        Case 1: ExternalHeaderName = "銀行名"
        Case 2: ExternalHeaderName = "支店名"
        Case 3: ExternalHeaderName = "氏名"
        Case 4: ExternalHeaderName = "科目"
        Case 5: ExternalHeaderName = "口座番号"
        Case 6: ExternalHeaderName = "日付"
        Case 7: ExternalHeaderName = "時刻"
        Case 8: ExternalHeaderName = "出金"
        Case 9: ExternalHeaderName = "入金"
        Case 10: ExternalHeaderName = "取扱店"
        Case 11: ExternalHeaderName = "機番"
        Case 12: ExternalHeaderName = "摘要"
        Case 13: ExternalHeaderName = "取引後残高"
        Case 14: ExternalHeaderName = "人物ID"
        Case 15: ExternalHeaderName = "続柄"
        Case Else: ExternalHeaderName = CStr(kindNo)
    End Select
End Function

Private Function FindExternalTableSheet(ByVal wb As Workbook, ByRef headerRow As Long) As Worksheet
    Dim ws As Worksheet, r As Long, c As Long, bestRow As Long
    Dim lastR As Long, lastC As Long
    Dim kinds(1 To 13) As Boolean, kindNo As Long, hasMandatory As Boolean
    Dim candidateCount As Long, candidateLocations As String
    For Each ws In wb.Worksheets
        lastR = ExternalLastUsedRow(ws)
        lastC = ExternalLastUsedColumn(ws)
        If lastR > MAX_EXTERNAL_DATA_ROWS + 10 Or lastC > MAX_EXTERNAL_COLUMNS Then
            Err.Raise vbObjectError + 6108, "FindExternalTableSheet", _
                      "取込元「" & ws.Name & "」の使用範囲（" & _
                      Format$(lastR, "#,##0") & "行×" & _
                      Format$(lastC, "#,##0") & _
                      "列）が上限を超えています。一部だけを読み込まず中止しました。" & _
                      "必要な表を別ファイルへ分割するか、取込元の原本にある不要行・不要列を整理してください。"
        End If
        For r = 1 To Application.Min(10, lastR)
            For kindNo = 1 To 13
                kinds(kindNo) = False
            Next kindNo
            For c = 1 To lastC
                kindNo = HeaderKind(ws.Cells(r, c).Value)
                If kindNo >= 1 And kindNo <= 13 Then
                    kinds(kindNo) = True
                End If
            Next c
            hasMandatory = HasMandatoryExternalHeaderKinds(kinds)
            If hasMandatory Then
                candidateCount = candidateCount + 1
                If candidateCount <= 10 Then
                    If Len(candidateLocations) > 0 Then candidateLocations = candidateLocations & "、"
                    candidateLocations = candidateLocations & ws.Name & "!" & CStr(r) & "行"
                End If
                If candidateCount = 1 Then
                    bestRow = r
                    Set FindExternalTableSheet = ws
                End If
            End If
        Next r
    Next ws
    If candidateCount = 0 Then
        Set FindExternalTableSheet = Nothing
        headerRow = 0
    ElseIf candidateCount > 1 Then
        Set FindExternalTableSheet = Nothing
        headerRow = 0
        Err.Raise vbObjectError + 6109, "FindExternalTableSheet", _
                  "取込可能な表が" & CStr(candidateCount) & "か所あります。取込対象だけのブックへ分けてください: " & _
                  candidateLocations
    Else
        headerRow = bestRow
    End If
End Function

Private Function HasMandatoryExternalHeaderKinds(ByRef kinds() As Boolean) As Boolean
    Dim kindNo As Long
    '時刻(7)だけは任意。それ以外の13列定義は誤列推測を避けるため必須とする。
    For kindNo = 1 To 13
        If kindNo <> 7 Then
            If Not kinds(kindNo) Then Exit Function
        End If
    Next kindNo
    HasMandatoryExternalHeaderKinds = True
End Function

Private Function FindHeaderColumn(ByVal values As Variant, ByVal kindNo As Long) As Long
    Dim c As Long
    For c = LBound(values, 2) To UBound(values, 2)
        If HeaderKind(values(1, c)) = kindNo Then FindHeaderColumn = c: Exit Function
    Next c
End Function

Private Function HeaderKind(ByVal headerValue As Variant) As Long
    Dim s As String
    s = NormalizeHeaderText(CellText(headerValue))
    Select Case s
        Case "銀行名", "金融機関名", "銀行名候補": HeaderKind = 1
        Case "支店名", "店名", "支店名候補": HeaderKind = 2
        Case "氏名", "名義人", "口座名義人", "人物", "人物候補", "氏名候補": HeaderKind = 3
        Case "科目", "預金種別", "口座種別", "科目候補": HeaderKind = 4
        Case "口座番号": HeaderKind = 5
        Case "日付", "取引日": HeaderKind = 6
        Case "時刻", "時間", "取引時刻": HeaderKind = 7
        Case "出金", "出金額", "支払金額": HeaderKind = 8
        Case "入金", "入金額", "預り金額": HeaderKind = 9
        Case "取扱店", "店舗", "取扱店番号": HeaderKind = 10
        Case "機番", "機械番号": HeaderKind = 11
        Case "摘要", "摘要欄", "内容", "摘要候補": HeaderKind = 12
        '第13列は数値の取引後残高だけを受け付ける。「その他」は自由文の意味が
        '混在するため、残高列へ推測せず未認識としてfail-closedにする。
        Case "取引後残高", "残高": HeaderKind = 13
        Case "人物ID": HeaderKind = 14
        Case "続柄", "関係": HeaderKind = 15
    End Select
End Function


Private Function NormalizeHeaderText(ByVal valueText As String) As String
    Dim s As String
    s = valueText
    s = Replace(s, " ", "")
    s = Replace(s, "　", "")
    s = Replace(s, vbCr, "")
    s = Replace(s, vbLf, "")
    s = Replace(s, "：", "")
    s = Replace(s, ":", "")
    NormalizeHeaderText = s
End Function

Private Function ExternalArrayRowHasData(ByVal values As Variant, ByVal r As Long) As Boolean
    Dim c As Long
    For c = LBound(values, 2) To UBound(values, 2)
        If IsError(values(r, c)) Or HasText(values(r, c)) Then ExternalArrayRowHasData = True: Exit Function
    Next c
End Function

Private Function ExternalLastMappedDataRow(ByVal ws As Worksheet, ByVal headerRow As Long, _
                                           ByVal mappedColumns As Variant) As Long
    '表の下や右にある説明文を取引行として数えず、認識済み列だけで終端を決める。
    Dim item As Variant, columnNo As Long, rowNo As Long
    ExternalLastMappedDataRow = headerRow
    If ws Is Nothing Then Exit Function
    For Each item In mappedColumns
        columnNo = CLng(item)
        If columnNo > 0 Then
            rowNo = ws.Cells(ws.Rows.Count, columnNo).End(xlUp).Row
            If rowNo > ExternalLastMappedDataRow Then ExternalLastMappedDataRow = rowNo
        End If
    Next item
End Function

Private Sub ValidateExternalMappedColumnsNoFormulas(ByVal ws As Worksheet, ByVal headerRow As Long, _
                                                    ByVal lastRow As Long, ByVal mappedColumns As Variant)
    '取込値が再計算環境や外部リンクで変わらないよう、認識対象列は固定値だけを受け付ける。
    Dim item As Variant, columnNo As Long
    Dim formulaCell As Range
    If ws Is Nothing Or lastRow < headerRow Then Exit Sub
    For Each item In mappedColumns
        columnNo = CLng(item)
        If columnNo > 0 Then
            Set formulaCell = Nothing
            If Not TryFindFirstFormulaCell( _
                       ws.Range(ws.Cells(headerRow, columnNo), _
                                ws.Cells(lastRow, columnNo)), formulaCell) Then _
                Err.Raise vbObjectError + 6178, "ValidateExternalMappedColumnsNoFormulas", _
                          "取込対象列の数式検査に失敗しました。データは取り込んでいません: " & _
                          ws.Name & "!" & ws.Cells(headerRow, columnNo).Address(False, False)
            If Not formulaCell Is Nothing Then
                Err.Raise vbObjectError + 6155, "ValidateExternalMappedColumnsNoFormulas", _
                          "取込対象列に数式があります。値へ置き換えてから再実行してください: " & _
                          ws.Name & "!" & formulaCell.Address(False, False)
            End If
        End If
    Next item
End Sub

Private Function ExternalLastUsedRow(ByVal ws As Worksheet) As Long
    Dim lastUsedRow As Long
    If ws Is Nothing Then _
        Err.Raise vbObjectError + 6179, "ExternalLastUsedRow", _
                  "取込元シートを取得できません。データは取り込んでいません。"
    If Not TryGetLastUsedRowInSheet(ws, lastUsedRow) Then _
        Err.Raise vbObjectError + 6179, "ExternalLastUsedRow(" & ws.Name & ")", _
                  "取込元の最終行を安全に確認できません。データは取り込んでいません。"
    ExternalLastUsedRow = lastUsedRow
End Function

Private Function ExternalLastUsedColumn(ByVal ws As Worksheet) As Long
    Dim lastUsedColumn As Long
    If ws Is Nothing Then _
        Err.Raise vbObjectError + 6180, "ExternalLastUsedColumn", _
                  "取込元シートを取得できません。データは取り込んでいません。"
    If Not TryGetLastUsedColumnInSheet(ws, lastUsedColumn) Then _
        Err.Raise vbObjectError + 6180, "ExternalLastUsedColumn(" & ws.Name & ")", _
                  "取込元の最終列を安全に確認できません。データは取り込んでいません。"
    ExternalLastUsedColumn = lastUsedColumn
End Function

Private Function PickWorkbookFile(ByVal dialogTitle As String, ByVal preferCommonData As Boolean) As String
    Dim fd As FileDialog
    Dim initialPath As String
    Set fd = Application.FileDialog(msoFileDialogFilePicker)
    initialPath = ThisWorkbook.Path
    If IsWebUrlPath(initialPath) Then initialPath = Application.DefaultFilePath
    If Len(initialPath) = 0 Then initialPath = Application.DefaultFilePath
    If preferCommonData And Len(initialPath) > 0 Then _
        initialPath = initialPath & Application.PathSeparator & "00_共通データ.xlsx"
    With fd
        .Title = dialogTitle
        .AllowMultiSelect = False
        .Filters.Clear
        .Filters.Add "Excelブック", "*.xlsx;*.xlsm;*.xlsb;*.xls"
        If Len(initialPath) > 0 Then
            'Office版やポリシーにより初期フォルダーだけが拒否されても、選択自体は続行する。
            On Error Resume Next
            .InitialFileName = initialPath
            Err.Clear
            On Error GoTo 0
        End If
        If .Show = -1 Then PickWorkbookFile = CStr(.SelectedItems(1))
    End With
End Function

Private Function FindOpenExternalWorkbookByFullName( _
                 ByVal filePath As String, _
                 ByRef openBooksBefore As Collection) As Workbook
    'Workbooks.Openの戻り値を無条件に自分が開いたブックと扱うと、
    'すでに開いているブックと同一だった場合に、未保存の編集ごとCloseし得る。
    'Open前にExcelが把握しているFullNameと照合し、所有権が曖昧なブックは開かない。
    Dim candidate As Workbook
    Dim candidateFullName As String
    Dim requestedFullName As String
    Dim errorNumber As Long, errorDescription As String

    requestedFullName = NormalizeExternalWorkbookFullName(filePath)
    If Len(requestedFullName) = 0 Then Exit Function

    On Error GoTo FullNameFailed
    Set openBooksBefore = New Collection
    For Each candidate In Application.Workbooks
        openBooksBefore.Add candidate
        candidateFullName = NormalizeExternalWorkbookFullName(CStr(candidate.FullName))
        If Len(candidateFullName) = 0 Then _
            Err.Raise vbObjectError + 6238, "FindOpenExternalWorkbookByFullName", _
                      "Excelで開いているブックのFullNameが空です。"
        If StrComp(candidateFullName, requestedFullName, vbTextCompare) = 0 Then
            Set FindOpenExternalWorkbookByFullName = candidate
            Exit Function
        End If
    Next candidate
    Exit Function
FullNameFailed:
    errorNumber = Err.Number
    errorDescription = Err.Description
    Err.Raise vbObjectError + 6238, "FindOpenExternalWorkbookByFullName", _
              "Excelで開いているブックの保存先を確認できないため、" & _
              "取込元の所有権を安全に判定できません。" & _
              "Err " & CStr(errorNumber) & ": " & errorDescription
End Function

Private Function ExternalWorkbookWasAlreadyOpen( _
                 ByVal sourceBook As Workbook, _
                 ByVal openBooksBefore As Collection) As Boolean
    Dim candidate As Workbook
    If sourceBook Is Nothing Or openBooksBefore Is Nothing Then _
        Err.Raise vbObjectError + 6238, "ExternalWorkbookWasAlreadyOpen", _
                  "取込元の所有権判定に必要なブック参照を取得できません。"
    For Each candidate In openBooksBefore
        If sourceBook Is candidate Then
            ExternalWorkbookWasAlreadyOpen = True
            Exit Function
        End If
    Next candidate
End Function

Private Function NormalizeExternalWorkbookFullName(ByVal filePath As String) As String
    Dim normalizedPath As String
    normalizedPath = Trim$(filePath)
    If Len(normalizedPath) = 0 Then Exit Function
    If Not IsWebUrlPath(normalizedPath) Then _
        normalizedPath = Replace(normalizedPath, "/", "\")
    NormalizeExternalWorkbookFullName = normalizedPath
End Function

Private Sub CloseSourceWorkbookAndRestoreSecurity(ByRef sourceBook As Workbook, _
                                                   ByRef sourceBookOwned As Boolean, _
                                                   ByRef securityChanged As Boolean, _
                                                   ByVal previousSecurity As Long, _
                                                   ByRef cleanupDetail As String)
    '取込元は読み取り専用でも、Close失敗を黙殺すると開いたブックが残り、次の取込先を
    '取り違える原因になる。AutomationSecurityの復元失敗はExcel全体へ影響するため、
    '設定後の読戻しまで確認し、呼出元が必ず利用者へ通知できる形で返す。
    Dim closeErrorNumber As Long, closeErrorDescription As String
    Dim securityErrorNumber As Long, securityErrorDescription As String
    Dim restoredSecurity As Long

    cleanupDetail = vbNullString
    If Not sourceBook Is Nothing And sourceBookOwned Then
        On Error Resume Next
        Err.Clear
        sourceBook.Close SaveChanges:=False
        closeErrorNumber = Err.Number
        closeErrorDescription = Err.Description
        Err.Clear
        On Error GoTo 0
        If closeErrorNumber = 0 Then
            Set sourceBook = Nothing
            sourceBookOwned = False
        Else
            AppendExternalCleanupDetail cleanupDetail, _
                "取込元ブックを閉じられません（Err " & CStr(closeErrorNumber) & _
                ": " & closeErrorDescription & "）。"
        End If
    ElseIf Not sourceBook Is Nothing Then
        '呼出元または別処理が所有するブックは絶対に閉じない。
        Set sourceBook = Nothing
    End If

    If securityChanged Then
        On Error Resume Next
        Err.Clear
        Application.AutomationSecurity = previousSecurity
        securityErrorNumber = Err.Number
        securityErrorDescription = Err.Description
        Err.Clear
        If securityErrorNumber = 0 Then
            restoredSecurity = Application.AutomationSecurity
            securityErrorNumber = Err.Number
            securityErrorDescription = Err.Description
        End If
        Err.Clear
        On Error GoTo 0
        If securityErrorNumber <> 0 Then
            AppendExternalCleanupDetail cleanupDetail, _
                "Excelのマクロセキュリティを元に戻せません（Err " & _
                CStr(securityErrorNumber) & ": " & securityErrorDescription & _
                "）。Excelを終了して管理者へ連絡してください。"
        ElseIf restoredSecurity <> previousSecurity Then
            AppendExternalCleanupDetail cleanupDetail, _
                "Excelのマクロセキュリティを元の値へ復元できません。" & _
                "Excelを終了して管理者へ連絡してください。"
        Else
            securityChanged = False
        End If
    End If
End Sub

Private Sub AppendExternalCleanupDetail(ByRef detailText As String, ByVal newDetail As String)
    If Len(newDetail) = 0 Then Exit Sub
    If Len(detailText) > 0 Then detailText = detailText & " "
    detailText = detailText & newDetail
End Sub

Private Function CommonSnapshotRows(ByVal ws As Worksheet, _
                                    ByVal lastColumn As Long) As Long
    If ws Is Nothing Or lastColumn < 1 Then _
        Err.Raise vbObjectError + 6226, "CommonSnapshotRows", _
                  "共通データ取込の退避行数を取得できません。"
    CommonSnapshotRows = LastDataRowInColumns(ws, 1, lastColumn)
    If CommonSnapshotRows < 1 Then CommonSnapshotRows = 1
End Function

Private Function CommonImportSnapshotSafetyRows( _
                 ByVal bankRows As Long, ByVal branchRows As Long, _
                 ByVal personRows As Long, ByVal typeRows As Long, _
                 ByVal tekiyoRows As Long, ByVal checkRows As Long) As Double
    Dim totalRows As Double, largestRows As Long
    If bankRows < 1 Or branchRows < 1 Or personRows < 1 Or _
       typeRows < 1 Or tekiyoRows < 1 Or checkRows < 1 Then _
        Err.Raise vbObjectError + 6228, "CommonImportSnapshotSafetyRows", _
                  "共通データ取込の退避規模が不正です。"
    totalRows = CDbl(bankRows) + CDbl(branchRows) + CDbl(personRows) + _
                CDbl(typeRows) + CDbl(tekiyoRows) + CDbl(checkRows)
    largestRows = Application.Max(bankRows, branchRows, personRows, _
                                  typeRows, tekiyoRows, checkRows)
    '各表はValue2とFormulaを保持し、直後照合でも同じ2配列を一時保持する。
    '16列相当への厳密換算より保守的に、全表行＋最大表行を安全規模とする。
    CommonImportSnapshotSafetyRows = totalRows + CDbl(largestRows)
End Function

Private Function CommonImportPreallocationWorkRows( _
                 ByVal maxSourceEquivalentRows As Double, _
                 ByVal snapshotSafetyRows As Double, _
                 ByVal existingStoreRows As Double) As Double
    If maxSourceEquivalentRows < 0# Or snapshotSafetyRows < 1# Or _
       existingStoreRows < 0# Then _
        Err.Raise vbObjectError + 6228, "CommonImportPreallocationWorkRows", _
                  "共通データ取込の事前安全規模が不正です。"
    CommonImportPreallocationWorkRows = maxSourceEquivalentRows + _
                                        snapshotSafetyRows + existingStoreRows
End Function

Public Sub ImportCommonDataWorkbook()
    Dim filePath As String
    Dim sourceBook As Workbook, alreadyOpenBook As Workbook, ws As Worksheet
    Dim openBooksBefore As Collection
    Dim wsTx As Worksheet, wsBal As Worksheet, wsAcc As Worksheet
    Dim wsBank As Worksheet, wsBranch As Worksheet, wsPerson As Worksheet
    Dim wsType As Worksheet, wsTekiyo As Worksheet, wsCheck As Worksheet
    Dim previousSecurity As Long, securityChanged As Boolean
    Dim sourceBookOwned As Boolean
    Dim headerRow As Long, lastR As Long, lastC As Long, r As Long, c As Long, sourceDataRow As Long
    Dim bankCol As Long, branchCol As Long, personCol As Long, personIDCol As Long
    Dim relationshipCol As Long, typeCol As Long, tekiyoCol As Long
    Dim importedCount As Long, errorNumber As Long, errorDescription As String
    Dim errorSource As String
    Dim bankSnapshot As Variant, branchSnapshot As Variant, personSnapshot As Variant
    Dim typeSnapshot As Variant, tekiyoSnapshot As Variant, checkSnapshot As Variant, idCounterSnapshot As Variant
    Dim commonData As Variant
    Dim bankRows As Long, branchRows As Long, personRows As Long, typeRows As Long, tekiyoRows As Long, checkRows As Long
    Dim candidateBatchStarted As Boolean, snapshotsTaken As Boolean, idCountersCaptured As Boolean
    Dim coreRestoreFailed As Boolean, dataCommitted As Boolean
    Dim personValidationIndex As Object
    Dim restoreDetail As String, cleanupDetail As String
    Dim existingStoreRows As Double, maxSourceEquivalentRows As Double
    Dim snapshotSafetyRows As Double, confirmedWorkRows As Double
    Dim entryEvents As Boolean, entryEventsCaptured As Boolean
    Dim applicationLeaseStarted As Boolean, eventsSafeForWorkbookWrites As Boolean
    Dim eventStateDetail As String, finishDetail As String
    Dim recoveryGateDetail As String
    Dim recoveryApplicationDetail As String
    Dim recoveryGateRequired As Boolean, recoveryConfirmed As Boolean
    Dim recoveryApplicationSafe As Boolean
    Dim recoveryEnforcementFailed As Boolean
    Dim recoveryAttempted As Boolean, recoveryTerminalFailure As Boolean
    Dim cleanupStepErrorNumber As Long
    Dim cleanupStepErrorDescription As String, cleanupStepErrorSource As String

    On Error GoTo EH
    If Not TryGetExternalImportEnableEvents(entryEvents, eventStateDetail) Then
        On Error Resume Next
        MsgBox "共通データ取込を開始する前にExcelイベント状態を取得できませんでした。" & vbCrLf & _
               "データは変更していません。現在のブックを上書き保存せず、Excelを再起動して確認してください。" & _
               vbCrLf & eventStateDetail, vbCritical, "Excel状態を確認できません"
        On Error GoTo 0
        Exit Sub
    End If
    entryEventsCaptured = True
    If Not TrySetExternalImportEnableEventsExact(False, eventStateDetail) Then _
        Err.Raise vbObjectError + 6242, "ImportCommonDataWorkbook", _
                  "事前確認より前にExcelイベントを停止できませんでした。 " & _
                  eventStateDetail
    eventsSafeForWorkbookWrites = True

    If Not RequireToolReady() Then GoTo COMMON_PRESTART_EXIT
    If Not RequireWritableWorkbook("共通データの取り込み") Then GoTo COMMON_PRESTART_EXIT
    If Not RequireNoPendingAccountInput("共通データの取り込み") Then GoTo COMMON_PRESTART_EXIT
    filePath = PickWorkbookFile("00_共通データ.xlsx を選択してください", True)
    If Len(filePath) = 0 Then GoTo COMMON_PRESTART_EXIT
    Set alreadyOpenBook = FindOpenExternalWorkbookByFullName(filePath, openBooksBefore)
    If Not alreadyOpenBook Is Nothing Then
        If alreadyOpenBook Is ThisWorkbook Then
            MsgBox "作業中のツール自身は共通データに指定できません。", vbExclamation
        Else
            MsgBox "指定した共通データブックはExcelですでに開かれています。" & vbCrLf & _
                   "未保存の編集を保護するため、取込元を閉じてからもう一度実行してください。", _
                   vbExclamation, "開いている取込元"
        End If
        Set alreadyOpenBook = Nothing
        GoTo COMMON_PRESTART_EXIT
    End If
    AppBegin "共通データを読み込んでいます..."
    applicationLeaseStarted = True
    previousSecurity = Application.AutomationSecurity
    securityChanged = True
    Application.AutomationSecurity = msoAutomationSecurityForceDisable
    If Application.AutomationSecurity <> msoAutomationSecurityForceDisable Then _
        Err.Raise vbObjectError + 6190, "ImportCommonDataWorkbook", _
                  "共通データを安全に開くためのマクロ無効化を確認できません。データは取り込んでいません。"
    Set sourceBook = Workbooks.Open(Filename:=filePath, UpdateLinks:=0, ReadOnly:=True, _
                                    AddToMru:=False, IgnoreReadOnlyRecommended:=True, Notify:=False)
    If sourceBook Is Nothing Then _
        Err.Raise vbObjectError + 6237, "ImportCommonDataWorkbook", _
                  "共通データブックを開いた後の参照を取得できません。データは取り込んでいません。"
    If sourceBook Is ThisWorkbook Then
        'EHの共通Close対象から外し、取込拒否のために作業ブック自身を閉じない。
        Set sourceBook = Nothing
        Application.AutomationSecurity = previousSecurity
        If Application.AutomationSecurity <> previousSecurity Then _
            Err.Raise vbObjectError + 6192, "ImportCommonDataWorkbook", _
                      "自己取込を中止した後にExcelのマクロ設定を復元できません。"
        securityChanged = False
        Err.Raise vbObjectError + 6191, "ImportCommonDataWorkbook", _
                  "作業中のツール自身は共通データに指定できません。"
    End If
    'FullNameが同期URL/ローカルパス等の別表記で事前照合をすり抜けても、
    'Open前に保持したオブジェクト参照と同一なら所有ブックにせず、絶対にCloseしない。
    If ExternalWorkbookWasAlreadyOpen(sourceBook, openBooksBefore) Then _
        Err.Raise vbObjectError + 6239, "ImportCommonDataWorkbook", _
                  "共通データはExcelですでに開かれています。" & _
                  "未保存の編集を保護するため、閉じてからもう一度実行してください。"
    sourceBookOwned = True
    If Not sourceBook.ReadOnly Then _
        Err.Raise vbObjectError + 6237, "ImportCommonDataWorkbook", _
                  "共通データを読み取り専用で開いたことを確認できません。データは取り込んでいません。"
    Application.AutomationSecurity = previousSecurity
    If Application.AutomationSecurity <> previousSecurity Then _
        Err.Raise vbObjectError + 6192, "ImportCommonDataWorkbook", _
                  "共通データを開いた後にExcelのマクロ設定を復元できません。"
    securityChanged = False
    If sourceBook.Worksheets.Count > MAX_SOURCE_SHEETS Then
        Err.Raise vbObjectError + 6201, "ImportCommonDataWorkbook", _
                  "共通データのシート数が上限（" & CStr(MAX_SOURCE_SHEETS) & "枚）を超えています。"
    End If
    ValidateCommonWorkbookSize sourceBook, maxSourceEquivalentRows
    ValidateImportWorkbookNoExternalDependencies sourceBook, "共通データ"

    '内部整合性検査、候補6表の二重snapshot、外部Range.Value2より前に、
    '既存8ストア・最大元表配列・snapshot検証中の一時配列を合算して判定する。
    Set wsTx = GetSheet(SH_WORK_TX)
    Set wsBal = GetSheet(SH_WORK_BAL)
    Set wsAcc = GetSheet(SH_WORK_ACCOUNT)
    Set wsBank = GetSheet(SH_BANK_CAND)
    Set wsBranch = GetSheet(SH_BRANCH_CAND)
    Set wsPerson = GetSheet(SH_PERSON_CAND)
    Set wsType = GetSheet(SH_ACCOUNT_TYPE)
    Set wsTekiyo = GetSheet(SH_TEKIYO)
    Set wsCheck = GetSheet(SH_CHECK)
    existingStoreRows = ExternalImportExistingStoreRows( _
                        ExternalDataRows(wsTx, WORK_TX_COL_PERSON_ID), _
                        ExternalDataRows(wsBal, WORK_BAL_COL_PERSON_ID), _
                        ExternalDataRows(wsAcc, ACC_COL_TRANSFER_ID), _
                        ExternalDataRows(wsBank, 4), _
                        ExternalDataRows(wsBranch, 4), _
                        ExternalDataRows(wsPerson, 4), _
                        ExternalDataRows(wsType, 4), _
                        ExternalDataRows(wsTekiyo, 4))
    bankRows = CommonSnapshotRows(wsBank, 4)
    branchRows = CommonSnapshotRows(wsBranch, 4)
    personRows = CommonSnapshotRows(wsPerson, 4)
    typeRows = CommonSnapshotRows(wsType, 4)
    tekiyoRows = CommonSnapshotRows(wsTekiyo, 4)
    checkRows = CommonSnapshotRows(wsCheck, 4)
    snapshotSafetyRows = CommonImportSnapshotSafetyRows( _
                         bankRows, branchRows, personRows, typeRows, _
                         tekiyoRows, checkRows)
    confirmedWorkRows = CommonImportPreallocationWorkRows( _
                        maxSourceEquivalentRows, snapshotSafetyRows, _
                        existingStoreRows)
    If confirmedWorkRows > 2147483647# Then _
        Err.Raise vbObjectError + 6231, "ImportCommonDataWorkbook", _
                  "共通データ取込の事前安全規模を計算できません。"
    If Not ConfirmLargeArrayOperation(CLng(confirmedWorkRows), _
            "共通データの取り込み（元表・候補退避・既存保管の事前安全検査）") Then
        cleanupDetail = vbNullString
        CloseSourceWorkbookAndRestoreSecurity sourceBook, sourceBookOwned, securityChanged, _
                                                previousSecurity, cleanupDetail
        If Len(cleanupDetail) > 0 Then _
            Err.Raise vbObjectError + 6191, "ImportCommonDataWorkbook", cleanupDetail
        SetInputStatus "共通データ取込を開始前に中止しました。データは変更していません。"
        FinishExternalImportApplicationLease applicationLeaseStarted, entryEvents, _
            entryEventsCaptured, "共通データ取込", False, finishDetail, _
            recoveryEnforcementFailed, recoveryAttempted, recoveryTerminalFailure
        Exit Sub
    End If
    If Not RequireInternalStoresSafeForWrite() Then
        cleanupDetail = vbNullString
        CloseSourceWorkbookAndRestoreSecurity sourceBook, sourceBookOwned, securityChanged, _
                                                previousSecurity, cleanupDetail
        If Len(cleanupDetail) > 0 Then _
            Err.Raise vbObjectError + 6191, "ImportCommonDataWorkbook", cleanupDetail
        FinishExternalImportApplicationLease applicationLeaseStarted, entryEvents, _
            entryEventsCaptured, "共通データ取込", False, finishDetail, _
            recoveryEnforcementFailed, recoveryAttempted, recoveryTerminalFailure
        Exit Sub
    End If
    ValidateCommonWorkbookNoFormulas sourceBook

    SnapshotSheetBlock SH_BANK_CAND, 4, bankSnapshot, bankRows
    SnapshotSheetBlock SH_BRANCH_CAND, 4, branchSnapshot, branchRows
    SnapshotSheetBlock SH_PERSON_CAND, 4, personSnapshot, personRows
    'AddCandidateValueは区分をD列にも記録するため、科目・摘要もA:Dを退避する。
    SnapshotSheetBlock SH_ACCOUNT_TYPE, 4, typeSnapshot, typeRows
    SnapshotSheetBlock SH_TEKIYO, 4, tekiyoSnapshot, tekiyoRows
    SnapshotSheetBlock SH_CHECK, 4, checkSnapshot, checkRows
    snapshotsTaken = True
    idCounterSnapshot = CaptureInternalIdCounters()
    idCountersCaptured = True

    BeginCandidateBatchUpdate
    candidateBatchStarted = True
    For Each ws In sourceBook.Worksheets
        Erase commonData
        lastR = ExternalLastUsedRow(ws)
        lastC = ExternalLastUsedColumn(ws)
        If lastR > MAX_EXTERNAL_DATA_ROWS + 1 Then
            Err.Raise vbObjectError + 6202, "ImportCommonDataWorkbook", _
                      "共通データ「" & ws.Name & "」は" & _
                      Format$(lastR - 1, "#,##0") & _
                      "行あり、安全な一括取込上限を超えています。" & _
                      "一部だけを読み込まず中止しました。ファイルを分割するか、原本の不要行・重複行を整理してください。"
        End If
        If lastC > MAX_EXTERNAL_COLUMNS Then
            Err.Raise vbObjectError + 6203, "ImportCommonDataWorkbook", _
                      "共通データ「" & ws.Name & "」の使用列が上限を超えています。"
        End If
        headerRow = FindCommonHeaderRow(ws, lastR, lastC)
        If headerRow > 0 Then
            ValidateCommonHeaderUniqueness ws, headerRow, lastC
            bankCol = FindWorksheetHeaderColumn(ws, headerRow, 1, lastC)
            branchCol = FindWorksheetHeaderColumn(ws, headerRow, 2, lastC)
            personCol = FindWorksheetHeaderColumn(ws, headerRow, 3, lastC)
            typeCol = FindWorksheetHeaderColumn(ws, headerRow, 4, lastC)
            tekiyoCol = FindWorksheetHeaderColumn(ws, headerRow, 12, lastC)
            personIDCol = FindWorksheetHeaderColumn(ws, headerRow, 14, lastC)
            relationshipCol = FindWorksheetHeaderColumn(ws, headerRow, 15, lastC)
            If lastR > headerRow Then _
                commonData = ws.Range(ws.Cells(headerRow + 1, 1), ws.Cells(lastR, lastC)).Value2
            For sourceDataRow = 1 To lastR - headerRow
                r = headerRow + sourceDataRow
                '列が存在しない時にCells(r, 0)へ触れない。VBAのAndは短絡評価されないため、
                '各列の有無と値有無を別々のIfで確認する。
                EnsureCommonBulkCellNotError commonData, sourceDataRow, bankCol, ws, r, "銀行名"
                EnsureCommonBulkCellNotError commonData, sourceDataRow, branchCol, ws, r, "支店名"
                EnsureCommonBulkCellNotError commonData, sourceDataRow, personCol, ws, r, "氏名"
                EnsureCommonBulkCellNotError commonData, sourceDataRow, personIDCol, ws, r, "人物ID"
                EnsureCommonBulkCellNotError commonData, sourceDataRow, relationshipCol, ws, r, "続柄"
                EnsureCommonBulkCellNotError commonData, sourceDataRow, typeCol, ws, r, "科目"
                EnsureCommonBulkCellNotError commonData, sourceDataRow, tekiyoCol, ws, r, "摘要"
                If bankCol > 0 Then
                    If HasText(BulkArrayValue(commonData, sourceDataRow, bankCol)) Then
                        AddBankCandidate CellText(BulkArrayValue(commonData, sourceDataRow, bankCol)), CAND_SOURCE_COMMON
                        importedCount = importedCount + 1
                    End If
                End If
                If branchCol > 0 Then
                    If HasText(BulkArrayValue(commonData, sourceDataRow, branchCol)) Then
                        AddBranchCandidate CellText(BulkArrayValue(commonData, sourceDataRow, branchCol)), CAND_SOURCE_COMMON
                        importedCount = importedCount + 1
                    End If
                End If
                If typeCol > 0 Then
                    If HasText(BulkArrayValue(commonData, sourceDataRow, typeCol)) Then
                        AddAccountTypeCandidate CellText(BulkArrayValue(commonData, sourceDataRow, typeCol))
                        importedCount = importedCount + 1
                    End If
                End If
                If tekiyoCol > 0 Then
                    If HasText(BulkArrayValue(commonData, sourceDataRow, tekiyoCol)) Then
                        AddTekiyoCandidate CellText(BulkArrayValue(commonData, sourceDataRow, tekiyoCol))
                        importedCount = importedCount + 1
                    End If
                End If
                If personCol > 0 Then
                    If HasText(BulkArrayValue(commonData, sourceDataRow, personCol)) Then
                        AddPersonCandidateWithID CellText(BulkArrayValue(commonData, sourceDataRow, personCol)), _
                                                 CommonBulkIdentifierAtOrBlank(commonData, sourceDataRow, _
                                                                               ws, r, personIDCol, "人物ID"), _
                                                 CommonBulkText(commonData, sourceDataRow, relationshipCol), CAND_SOURCE_COMMON
                        importedCount = importedCount + 1
                    End If
                End If
            Next sourceDataRow
        Else
            ImportCommonSheetByName ws, importedCount
        End If
    Next ws
    Erase commonData
    EndCandidateBatchUpdate
    candidateBatchStarted = False
    ReconcileInternalIdCounters
    Set personValidationIndex = NewTextDictionary()
    LoadExistingPersonIdIndex personValidationIndex
    '共通候補の取込後は、変更した候補・採番状態だけを検証する。未更新の帳票や
    '分析表示まで全走査すると、正しい取込を無関係な表示状態で巻き戻してしまう。
    If Not RequireInternalStoresSafeForWrite() Then _
        Err.Raise vbObjectError + 2206, "ImportCommonDataWorkbook", _
                  "取込後の内部データ確認に失敗しました。"
    ValidateCaseCandidateResetSources
    ValidateInitializationPreservedSettings

    CloseSourceWorkbookAndRestoreSecurity sourceBook, sourceBookOwned, securityChanged, _
                                            previousSecurity, cleanupDetail
    If Len(cleanupDetail) > 0 Then _
        Err.Raise vbObjectError + 6191, "ImportCommonDataWorkbook", cleanupDetail
    '候補・採番の全書込みと整合性検証が完了した時点をcommit境界とする。
    '以後の入力画面再設定や案内が失敗しても、旧snapshotを再書込みしない。
    dataCommitted = True
    eventStateDetail = vbNullString
    If Not TrySetExternalImportEnableEventsExact(False, eventStateDetail) Then _
        Err.Raise vbObjectError + 6241, "ImportCommonDataWorkbook", _
                  "取込後の画面再設定前にExcelイベント停止を確認できません: " & _
                  eventStateDetail
    ApplyInputSettings False, True
    eventStateDetail = vbNullString
    If Not TrySetExternalImportEnableEventsExact(False, eventStateDetail) Then _
        Err.Raise vbObjectError + 6241, "ImportCommonDataWorkbook", _
                  "取込後の案内を書き込む前にExcelイベント停止を確認できません: " & _
                  eventStateDetail
    SetInputStatus "共通データを候補へ取り込みました。"
    If Not FinishExternalImportApplicationLease( _
               applicationLeaseStarted, entryEvents, entryEventsCaptured, _
               "共通データ取込", True, finishDetail, _
               recoveryEnforcementFailed, recoveryAttempted, _
               recoveryTerminalFailure) Then Exit Sub
    MsgBox "共通データから候補を取り込みました。" & vbCrLf & _
           "読込候補項目数（重複を含む）: " & importedCount, vbInformation
    Exit Sub
COMMON_PRESTART_EXIT:
    If entryEventsCaptured Then _
        FinishExternalImportApplicationLease applicationLeaseStarted, entryEvents, _
            entryEventsCaptured, "共通データ取込", False, finishDetail, _
            recoveryEnforcementFailed, recoveryAttempted, recoveryTerminalFailure
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    If IsExternalImportRecoveryFatal(errorNumber, errorSource) Then _
        RethrowExternalImportRecoveryFatal _
            errorNumber, errorSource, errorDescription
    eventStateDetail = vbNullString
    eventsSafeForWorkbookWrites = _
        TrySetExternalImportEnableEventsExact(False, eventStateDetail)
    If Not eventsSafeForWorkbookWrites Then
        coreRestoreFailed = Not dataCommitted
        recoveryGateRequired = True
        recoveryConfirmed = False
        AppendExternalDetail restoreDetail, _
            "Excelイベント停止を読戻し確認できないため、" & _
            "候補・採番・チェック履歴の復元と終了記録を見送りました: " & _
            eventStateDetail
    End If

    If eventsSafeForWorkbookWrites And Not dataCommitted Then
        On Error Resume Next
        If candidateBatchStarted Then
            Err.Clear
            EndCandidateBatchUpdate
            cleanupStepErrorNumber = Err.Number
            cleanupStepErrorDescription = Err.Description
            cleanupStepErrorSource = Err.Source
            Err.Clear
            On Error GoTo 0
            If IsExternalImportRecoveryFatal( _
                   cleanupStepErrorNumber, cleanupStepErrorSource) Then _
                RethrowExternalImportRecoveryFatal _
                    cleanupStepErrorNumber, cleanupStepErrorSource, _
                    cleanupStepErrorDescription
            On Error Resume Next
            If cleanupStepErrorNumber <> 0 Then
                AppendExternalDetail restoreDetail, _
                    "候補一括更新の終了エラー: " & _
                    cleanupStepErrorDescription
                coreRestoreFailed = True
            End If
            Err.Clear
            candidateBatchStarted = False
        End If
        If snapshotsTaken Then
            Err.Clear
            RestoreCommonCandidateSnapshots bankSnapshot, bankRows, branchSnapshot, branchRows, _
                                            personSnapshot, personRows, typeSnapshot, typeRows, _
                                            tekiyoSnapshot, tekiyoRows
            If Err.Number <> 0 Then
                restoreDetail = "候補の復元エラー: " & Err.Description
                coreRestoreFailed = True
            End If
            Err.Clear
            If idCountersCaptured Then
                RestoreInternalIdCounters idCounterSnapshot
                If Err.Number <> 0 Then
                    AppendExternalDetail restoreDetail, _
                        "ID採番状態の復元エラー: " & Err.Description
                    coreRestoreFailed = True
                End If
            End If
            Err.Clear
            RestoreSheetBlock SH_CHECK, 4, checkSnapshot, checkRows
            If Err.Number <> 0 Then
                AppendExternalDetail restoreDetail, _
                    "チェック履歴の復元エラー: " & Err.Description
                coreRestoreFailed = True
            End If
            Err.Clear
            EndCandidateBatchUpdate
            cleanupStepErrorNumber = Err.Number
            cleanupStepErrorDescription = Err.Description
            cleanupStepErrorSource = Err.Source
            Err.Clear
            On Error GoTo 0
            If IsExternalImportRecoveryFatal( _
                   cleanupStepErrorNumber, cleanupStepErrorSource) Then _
                RethrowExternalImportRecoveryFatal _
                    cleanupStepErrorNumber, cleanupStepErrorSource, _
                    cleanupStepErrorDescription
            On Error Resume Next
            If cleanupStepErrorNumber <> 0 Then
                AppendExternalDetail restoreDetail, _
                    "候補一覧名の更新エラー: " & _
                    cleanupStepErrorDescription
                coreRestoreFailed = True
            End If
        End If
        Err.Clear
        On Error GoTo 0
    End If

    If coreRestoreFailed And eventsSafeForWorkbookWrites Then
        recoveryGateRequired = True
        recoveryConfirmed = False
        AppendExternalDetail restoreDetail, _
            "外側操作のApplication lease終了と一緒に、" & _
            "案件要復旧状態を一度だけ確定する必要があります。"
    End If

    If recoveryEnforcementFailed Or recoveryTerminalFailure Then
        eventStateDetail = vbNullString
        eventsSafeForWorkbookWrites = _
            TrySetExternalImportEnableEventsExact(False, eventStateDetail)
        FinishExternalImportApplicationLease applicationLeaseStarted, entryEvents, _
            entryEventsCaptured, "共通データ取込", dataCommitted, _
            restoreDetail, recoveryEnforcementFailed, recoveryAttempted, _
            recoveryTerminalFailure, True, False
        Exit Sub
    End If

    cleanupDetail = vbNullString
    CloseSourceWorkbookAndRestoreSecurity sourceBook, sourceBookOwned, securityChanged, _
                                            previousSecurity, cleanupDetail
    If Len(cleanupDetail) > 0 Then
        AppendExternalDetail restoreDetail, "終了処理: " & cleanupDetail
    End If

    If recoveryAttempted Then
        eventStateDetail = vbNullString
        eventsSafeForWorkbookWrites = _
            TrySetExternalImportEnableEventsExact(False, eventStateDetail)
        If eventsSafeForWorkbookWrites Then _
            recoveryConfirmed = ExternalImportRecoveryStateConfirmed()
        If recoveryConfirmed Then
            recoveryApplicationDetail = vbNullString
            recoveryApplicationSafe = _
                ExternalImportApplicationStateConfirmed( _
                    recoveryApplicationDetail)
            If Not recoveryApplicationSafe Then recoveryConfirmed = False
        End If
        If Not eventsSafeForWorkbookWrites Or Not recoveryConfirmed Then
            recoveryTerminalFailure = True
            FinishExternalImportApplicationLease applicationLeaseStarted, entryEvents, _
                entryEventsCaptured, "共通データ取込", dataCommitted, _
                restoreDetail, recoveryEnforcementFailed, recoveryAttempted, _
                recoveryTerminalFailure, True, False
            Exit Sub
        End If
    End If

    If eventsSafeForWorkbookWrites And _
       (Not recoveryGateRequired Or recoveryConfirmed) Then
        On Error Resume Next
        Err.Clear
        If dataCommitted Then
            AddCheck "警告", "共通データ取込後処理", _
                     "候補・採番への取込は確定済みです。旧snapshotへは戻していません。" & _
                     "Err " & CStr(errorNumber) & ": " & errorDescription & _
                     IIf(Len(restoreDetail) > 0, " / " & restoreDetail, "")
            SetInputStatus "共通データは候補へ取込済みですが、画面の後処理でエラーが発生しました。同じ資料を再取込せずC_チェックを確認してください。", True
        ElseIf coreRestoreFailed Then
            AddCheck "エラー", "共通データ取込ロールバック", restoreDetail
            If recoveryConfirmed Then
                SetInputStatus "共通データ取込に失敗し、案件の要復旧状態を確認しました。上書き保存をせずC_チェックを確認してください。", True
            Else
                SetInputStatus "共通データ取込に失敗し、復元結果と案件の復旧状態を一意に確認できません。上書き保存をせずC_チェックを確認してください。", True
            End If
        Else
            If Len(restoreDetail) > 0 Then _
                AddCheck "警告", "共通データ取込終了処理", restoreDetail
            SetInputStatus "共通データ取込に失敗しました。候補・採番への変更は反映していません。"
        End If
        Err.Clear
        On Error GoTo 0
    End If

    On Error Resume Next
    MsgBox "共通データの取込中にエラーが発生しました。" & vbCrLf & _
           "Err " & errorNumber & ": " & errorDescription & _
           IIf(dataCommitted, _
               vbCrLf & "候補・採番への取込は確定済みです。同じ資料を再取込しないでください。", _
               IIf(Not eventsSafeForWorkbookWrites, _
                   vbCrLf & "Excelイベント状態が不明なため、ブックへのロールバックと終了記録を見送りました。", _
                   IIf(coreRestoreFailed, _
                       vbCrLf & "復元結果を一意に確認できません。", _
                       vbCrLf & "候補・採番への変更は反映していません。"))) & _
           IIf(Len(restoreDetail) > 0, vbCrLf & "復元確認: " & restoreDetail, ""), _
           IIf(dataCommitted Or coreRestoreFailed Or Not eventsSafeForWorkbookWrites, _
               vbCritical, vbExclamation), "共通データ取込エラー"
    On Error GoTo 0
    FinishExternalImportApplicationLease applicationLeaseStarted, entryEvents, _
        entryEventsCaptured, "共通データ取込", dataCommitted, restoreDetail, _
        recoveryEnforcementFailed, recoveryAttempted, recoveryTerminalFailure, _
        recoveryGateRequired Or Not eventsSafeForWorkbookWrites, _
        recoveryConfirmed
End Sub

Private Sub ValidateCommonWorkbookSize(ByVal sourceBook As Workbook, _
                                       ByRef maxSourceEquivalentRows As Double)
    Dim ws As Worksheet, lastR As Long, lastC As Long
    Dim totalRows As Double, sourceEquivalentRows As Double
    maxSourceEquivalentRows = 0#
    If sourceBook Is Nothing Then Exit Sub
    For Each ws In sourceBook.Worksheets
        lastR = ExternalLastUsedRow(ws)
        lastC = ExternalLastUsedColumn(ws)
        If lastR > MAX_EXTERNAL_DATA_ROWS + 1 Then
            Err.Raise vbObjectError + 6202, "ValidateCommonWorkbookSize", _
                      "共通データ「" & ws.Name & "」は" & _
                      Format$(lastR - 1, "#,##0") & _
                      "行あり、安全な一括取込上限を超えています。" & _
                      "一部だけを読み込まず中止しました。ファイルを分割するか、原本の不要行・重複行を整理してください。"
        End If
        If lastC > MAX_EXTERNAL_COLUMNS Then
            Err.Raise vbObjectError + 6203, "ValidateCommonWorkbookSize", _
                      "共通データ「" & ws.Name & "」の使用列が上限を超えています。"
        End If
        If lastR > 1 And lastC > 0 Then
            sourceEquivalentRows = ExternalEquivalentWorkRows(lastR - 1, lastC)
            If sourceEquivalentRows > maxSourceEquivalentRows Then _
                maxSourceEquivalentRows = sourceEquivalentRows
        End If
        If lastR > 1 Then totalRows = totalRows + CDbl(lastR - 1)
        If totalRows > MAX_COMMON_TOTAL_ROWS Then
            Err.Raise vbObjectError + 6204, "ValidateCommonWorkbookSize", _
                      "共通データは合計" & Format$(totalRows, "#,##0") & _
                      "行で、安全な一括取込上限（" & Format$(MAX_COMMON_TOTAL_ROWS, "#,##0") & _
                      "行）を超えています。一部だけを読み込まず中止しました。" & _
                      "ファイルを分割するか、原本の不要行・重複行を整理してください。"
        End If
    Next ws
End Sub

Private Sub ValidateCommonWorkbookNoFormulas(ByVal sourceBook As Workbook)
    Dim ws As Worksheet, lastR As Long, lastC As Long
    Dim formulaCell As Range
    If sourceBook Is Nothing Then _
        Err.Raise vbObjectError + 6234, "ValidateCommonWorkbookNoFormulas", _
                  "共通データブックを取得できません。"
    For Each ws In sourceBook.Worksheets
        lastR = ExternalLastUsedRow(ws)
        lastC = ExternalLastUsedColumn(ws)
        If lastR > 0 And lastC > 0 Then
            Set formulaCell = Nothing
            If Not TryFindFirstFormulaCell( _
                       ws.Range(ws.Cells(1, 1), ws.Cells(lastR, lastC)), _
                       formulaCell) Then _
                Err.Raise vbObjectError + 6234, "ValidateCommonWorkbookNoFormulas", _
                          "共通データの数式検査に失敗しました。データは取り込んでいません: " & _
                          ws.Name
            If Not formulaCell Is Nothing Then
                Err.Raise vbObjectError + 6234, "ValidateCommonWorkbookNoFormulas", _
                          "共通データに数式があります。固定値へ置き換えてから再実行してください: " & _
                          ws.Name & "!" & formulaCell.Address(False, False)
            End If
        End If
    Next ws
End Sub

Private Function OptionalExternalCollectionCount(ByVal owner As Object, _
                                                 ByVal propertyName As String) As Long
    Dim collectionObject As Object
    Dim errorNumber As Long, errorDescription As String
    On Error GoTo EH
    Set collectionObject = CallByName(owner, propertyName, VbGet)
    If Not collectionObject Is Nothing Then _
        OptionalExternalCollectionCount = _
            CLng(CallByName(collectionObject, "Count", VbGet))
    Exit Function
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    On Error GoTo 0
    'Queriesを持たない旧Excelでは、同機能の外部クエリも存在しない。
    If errorNumber = 438 And StrComp(propertyName, "Queries", vbTextCompare) = 0 Then _
        Exit Function
    Err.Raise vbObjectError + 6233, "OptionalExternalCollectionCount", _
              propertyName & "を安全に検査できません（Err " & _
              CStr(errorNumber) & ": " & errorDescription & "）。"
End Function

Private Function ExternalLinkListHasItems(ByVal linkItems As Variant) As Boolean
    If IsArray(linkItems) Then
        ExternalLinkListHasItems = True
    ElseIf Not IsEmpty(linkItems) And Not IsNull(linkItems) Then
        ExternalLinkListHasItems = (Len(CellText(linkItems)) > 0)
    End If
End Function

Private Function NameRefersToExternalSource(ByVal refersToText As String) As Boolean
    Dim s As String, openBracket As Long, closeBracket As Long, bangPosition As Long
    s = LCase$(Trim$(refersToText))
    If Len(s) = 0 Then Exit Function
    If InStr(1, s, "http://", vbBinaryCompare) > 0 Or _
       InStr(1, s, "https://", vbBinaryCompare) > 0 Or _
       InStr(1, s, "file:", vbBinaryCompare) > 0 Or _
       InStr(1, s, "\\", vbBinaryCompare) > 0 Then
        NameRefersToExternalSource = True
        Exit Function
    End If
    openBracket = InStr(1, s, "[", vbBinaryCompare)
    If openBracket > 0 Then closeBracket = InStr(openBracket + 1, s, "]", vbBinaryCompare)
    If closeBracket > openBracket Then
        bangPosition = InStr(closeBracket + 1, s, "!", vbBinaryCompare)
        If bangPosition > closeBracket Then NameRefersToExternalSource = True
    End If
End Function

Private Sub ValidateImportWorkbookNoExternalDependencies( _
            ByVal sourceBook As Workbook, ByVal sourceLabel As String)
    Dim ws As Worksheet, workbookName As Name, sheetName As Name
    Dim listObject As ListObject, hyperlinkItem As Hyperlink
    Dim excelLinks As Variant, oleLinks As Variant
    Dim dependencyDetail As String
    Dim errorNumber As Long, errorDescription As String
    If Len(Trim$(sourceLabel)) = 0 Then sourceLabel = "取込元"
    If sourceBook Is Nothing Then _
        Err.Raise vbObjectError + 6233, _
                  "ValidateImportWorkbookNoExternalDependencies", _
                  sourceLabel & "ブックを取得できません。"
    On Error GoTo InspectionFailed
    excelLinks = sourceBook.LinkSources(Type:=xlExcelLinks)
    If ExternalLinkListHasItems(excelLinks) Then
        dependencyDetail = "Excel外部リンク"
        GoTo DependencyFound
    End If
    oleLinks = sourceBook.LinkSources(Type:=xlOLELinks)
    If ExternalLinkListHasItems(oleLinks) Then
        dependencyDetail = "OLE外部リンク"
        GoTo DependencyFound
    End If
    If OptionalExternalCollectionCount(sourceBook, "Connections") > 0 Then
        dependencyDetail = "データ接続"
        GoTo DependencyFound
    End If
    If OptionalExternalCollectionCount(sourceBook, "Queries") > 0 Then
        dependencyDetail = "Power Query"
        GoTo DependencyFound
    End If
    For Each workbookName In sourceBook.Names
        If NameRefersToExternalSource(CStr(workbookName.RefersTo)) Then
            dependencyDetail = "外部参照を持つ定義名 " & workbookName.Name
            GoTo DependencyFound
        End If
    Next workbookName
    For Each ws In sourceBook.Worksheets
        If ws.QueryTables.Count > 0 Then
            dependencyDetail = "QueryTable " & ws.Name
            GoTo DependencyFound
        End If
        If ws.PivotTables.Count > 0 Then
            dependencyDetail = "PivotTable " & ws.Name
            GoTo DependencyFound
        End If
        If ws.OLEObjects.Count > 0 Then
            dependencyDetail = "OLEObject " & ws.Name
            GoTo DependencyFound
        End If
        For Each listObject In ws.ListObjects
            If listObject.SourceType <> xlSrcRange Then
                dependencyDetail = "外部ソースのテーブル " & ws.Name & "!" & listObject.Name
                GoTo DependencyFound
            End If
        Next listObject
        For Each hyperlinkItem In ws.Hyperlinks
            If Len(Trim$(hyperlinkItem.Address)) > 0 Then
                dependencyDetail = "外部ハイパーリンク " & ws.Name
                GoTo DependencyFound
            End If
        Next hyperlinkItem
        For Each sheetName In ws.Names
            If NameRefersToExternalSource(CStr(sheetName.RefersTo)) Then
                dependencyDetail = "外部参照を持つシート定義名 " & sheetName.Name
                GoTo DependencyFound
            End If
        Next sheetName
    Next ws
    On Error GoTo 0
    Exit Sub

DependencyFound:
    On Error GoTo 0
    Err.Raise vbObjectError + 6232, _
              "ValidateImportWorkbookNoExternalDependencies", _
              sourceLabel & "に外部依存があります（" & dependencyDetail & _
              "）。固定値だけのブックへ変換してから再実行してください。"
InspectionFailed:
    errorNumber = Err.Number
    errorDescription = Err.Description
    On Error GoTo 0
    Err.Raise vbObjectError + 6233, _
              "ValidateImportWorkbookNoExternalDependencies", _
              sourceLabel & "の外部依存検査に失敗しました（Err " & _
              CStr(errorNumber) & ": " & errorDescription & _
              "）。データは取り込んでいません。"
End Sub

Private Sub SnapshotSheetBlock(ByVal sheetName As String, ByVal lastCol As Long, _
                               ByRef snapshot As Variant, ByRef snapshotRows As Long)
    '候補には利用者が入力した数式・数式風の定数文字列・先頭アポストロフがあり得る。
    '.Formulaだけの退避では「'=...」を実数式へ変えても同じ文字列として誤照合するため、
    'Value2 / Formula / HasFormula / PrefixCharacterを独立して保持する。
    Dim ws As Worksheet, targetRange As Range
    Dim snapshotItems As Collection
    Dim valueData As Variant, formulaData As Variant
    Dim formulaCells As Object, prefixCells As Object
    Set ws = GetSheet(sheetName)
    snapshotRows = LastDataRowInColumns(ws, 1, lastCol)
    If snapshotRows < 1 Then snapshotRows = 1
    Set targetRange = ws.Range(ws.Cells(1, 1), ws.Cells(snapshotRows, lastCol))
    valueData = targetRange.Value2
    formulaData = targetRange.Formula
    CaptureSheetSnapshotMetadata targetRange, formulaCells, prefixCells

    Set snapshotItems = New Collection
    snapshotItems.Add valueData
    snapshotItems.Add formulaData
    snapshotItems.Add formulaCells
    snapshotItems.Add prefixCells
    Set snapshot = snapshotItems
    If Not ExternalSnapshotBlockMatches(snapshot, targetRange) Then _
        Err.Raise vbObjectError + 6211, "SnapshotSheetBlock", _
                  sheetName & "の退避直後照合に失敗しました。"
End Sub

Private Sub RestoreSheetBlock(ByVal sheetName As String, ByVal lastCol As Long, _
                              ByRef snapshot As Variant, ByVal snapshotRows As Long)
    Dim ws As Worksheet, clearRows As Long, r As Long, c As Long
    Dim targetRange As Range, targetCell As Range
    Dim snapshotItems As Collection
    Dim valueData As Variant, formulaData As Variant, constantData() As Variant
    Dim formulaCells As Object, prefixCells As Object
    Dim keyText As String, prefixText As String
    Set ws = GetSheet(sheetName)
    If Not IsObject(snapshot) Then _
        Err.Raise vbObjectError + 6212, "RestoreSheetBlock", _
                  sheetName & "の退避情報がありません。"
    Set snapshotItems = snapshot
    If snapshotItems.Count <> SHEET_SNAPSHOT_ITEM_COUNT Then _
        Err.Raise vbObjectError + 6213, "RestoreSheetBlock", _
                  sheetName & "の退避情報が不足しています。"
    valueData = snapshotItems(SHEET_SNAPSHOT_VALUE2)
    formulaData = snapshotItems(SHEET_SNAPSHOT_FORMULA)
    Set formulaCells = snapshotItems(SHEET_SNAPSHOT_HAS_FORMULA)
    Set prefixCells = snapshotItems(SHEET_SNAPSHOT_PREFIX)
    If Not ExternalSnapshotArrayDimensionsMatch(valueData, formulaData, snapshotRows, lastCol) Then _
        Err.Raise vbObjectError + 6214, "RestoreSheetBlock", _
                  sheetName & "の退避配列範囲が一致しません。"

    clearRows = Application.Max(snapshotRows, LastDataRowInColumns(ws, 1, lastCol), 1)
    ws.Range(ws.Cells(1, 1), ws.Cells(clearRows, lastCol)).ClearContents
    Set targetRange = ws.Range(ws.Cells(1, 1), ws.Cells(snapshotRows, lastCol))
    ReDim constantData(1 To snapshotRows, 1 To lastCol)
    For r = 1 To snapshotRows
        For c = 1 To lastCol
            keyText = ExternalSnapshotCellKey(r, c)
            If Not formulaCells.Exists(keyText) And Not prefixCells.Exists(keyText) And _
               Not ExternalSnapshotConstantNeedsLiteralRestore(valueData(r, c)) Then
                constantData(r, c) = valueData(r, c)
            End If
        Next c
    Next r
    '数式セルと数式風の定数を空欄にした配列から先に戻し、外部式を誤評価しない。
    targetRange.Value2 = constantData
    For r = 1 To snapshotRows
        For c = 1 To lastCol
            keyText = ExternalSnapshotCellKey(r, c)
            Set targetCell = ws.Cells(r, c)
            If formulaCells.Exists(keyText) Then
                targetCell.Formula = formulaData(r, c)
            ElseIf prefixCells.Exists(keyText) Then
                prefixText = CStr(prefixCells(keyText))
                RestoreExternalSnapshotLiteral targetCell, valueData(r, c), prefixText
            ElseIf ExternalSnapshotConstantNeedsLiteralRestore(valueData(r, c)) Then
                RestoreExternalSnapshotLiteral targetCell, valueData(r, c), ""
            End If
        Next c
    Next r
    If Not ExternalSnapshotBlockMatches(snapshot, targetRange) Or _
       LastDataRowInColumns(ws, 1, lastCol) <> snapshotRows Then _
        Err.Raise vbObjectError + 6209, "RestoreSheetBlock", _
                  sheetName & "の復元結果を確認できません。"
End Sub

Private Sub CaptureSheetSnapshotMetadata(ByVal targetRange As Range, _
                                         ByRef formulaCells As Object, _
                                         ByRef prefixCells As Object)
    Dim rowOffset As Long, chunkRows As Long, relativeRow As Long, relativeCol As Long
    Dim chunk As Range, cell As Range
    Dim formulaState As Variant, prefixState As Variant
    Dim formulaScanNeeded As Boolean, prefixScanNeeded As Boolean
    Dim scanError As Long, keyText As String, prefixText As String
    Set formulaCells = NewTextDictionary()
    Set prefixCells = NewTextDictionary()
    If targetRange Is Nothing Then _
        Err.Raise vbObjectError + 6215, "CaptureSheetSnapshotMetadata", _
                  "候補退避範囲がありません。"

    For rowOffset = 1 To targetRange.Rows.Count Step SHEET_SNAPSHOT_CHUNK_ROWS
        chunkRows = Application.Min(SHEET_SNAPSHOT_CHUNK_ROWS, _
                                    targetRange.Rows.Count - rowOffset + 1)
        Set chunk = targetRange.Rows(rowOffset).Resize(chunkRows, targetRange.Columns.Count)
        formulaScanNeeded = False
        prefixScanNeeded = False

        On Error Resume Next
        Err.Clear
        formulaState = chunk.HasFormula
        scanError = Err.Number
        Err.Clear
        On Error GoTo 0
        If scanError <> 0 Or IsNull(formulaState) Then
            formulaScanNeeded = True
        ElseIf CBool(formulaState) Then
            formulaScanNeeded = True
        End If

        On Error Resume Next
        Err.Clear
        prefixState = chunk.PrefixCharacter
        scanError = Err.Number
        Err.Clear
        On Error GoTo 0
        If scanError <> 0 Or IsNull(prefixState) Then
            prefixScanNeeded = True
        ElseIf Len(CStr(prefixState)) > 0 Then
            prefixScanNeeded = True
        End If

        If formulaScanNeeded Or prefixScanNeeded Then
            For Each cell In chunk.Cells
                relativeRow = cell.Row - targetRange.Row + 1
                relativeCol = cell.Column - targetRange.Column + 1
                keyText = ExternalSnapshotCellKey(relativeRow, relativeCol)
                If formulaScanNeeded Then
                    If CBool(cell.HasFormula) Then formulaCells(keyText) = True
                End If
                If prefixScanNeeded Then
                    prefixText = CStr(cell.PrefixCharacter)
                    If Len(prefixText) > 0 Then prefixCells(keyText) = prefixText
                End If
            Next cell
        End If
    Next rowOffset
End Sub

Private Function ExternalSnapshotBlockMatches(ByRef snapshot As Variant, _
                                               ByVal actualRange As Range) As Boolean
    Dim snapshotItems As Collection
    Dim expectedValues As Variant, expectedFormulas As Variant
    Dim actualValues As Variant, actualFormulas As Variant
    Dim expectedFormulaCells As Object, expectedPrefixCells As Object
    Dim actualFormulaCells As Object, actualPrefixCells As Object
    Dim r As Long, c As Long
    Dim keyText As String
    On Error GoTo Failed
    If Not IsObject(snapshot) Or actualRange Is Nothing Then Exit Function
    Set snapshotItems = snapshot
    If snapshotItems.Count <> SHEET_SNAPSHOT_ITEM_COUNT Then Exit Function
    expectedValues = snapshotItems(SHEET_SNAPSHOT_VALUE2)
    expectedFormulas = snapshotItems(SHEET_SNAPSHOT_FORMULA)
    Set expectedFormulaCells = snapshotItems(SHEET_SNAPSHOT_HAS_FORMULA)
    Set expectedPrefixCells = snapshotItems(SHEET_SNAPSHOT_PREFIX)
    actualValues = actualRange.Value2
    actualFormulas = actualRange.Formula
    If Not ExternalSnapshotArrayDimensionsMatch(expectedValues, actualValues, _
                                                actualRange.Rows.Count, actualRange.Columns.Count) Then Exit Function
    If Not ExternalSnapshotArrayDimensionsMatch(expectedFormulas, actualFormulas, _
                                                actualRange.Rows.Count, actualRange.Columns.Count) Then Exit Function
    CaptureSheetSnapshotMetadata actualRange, actualFormulaCells, actualPrefixCells
    If expectedFormulaCells.Count <> actualFormulaCells.Count Or _
       expectedPrefixCells.Count <> actualPrefixCells.Count Then Exit Function
    For r = 1 To actualRange.Rows.Count
        For c = 1 To actualRange.Columns.Count
            keyText = ExternalSnapshotCellKey(r, c)
            If expectedFormulaCells.Exists(keyText) <> actualFormulaCells.Exists(keyText) Then Exit Function
            If expectedPrefixCells.Exists(keyText) <> actualPrefixCells.Exists(keyText) Then Exit Function
            If expectedPrefixCells.Exists(keyText) Then
                If StrComp(CStr(expectedPrefixCells(keyText)), CStr(actualPrefixCells(keyText)), _
                           vbBinaryCompare) <> 0 Then Exit Function
            End If
            If Not ExternalSnapshotValueMatches(expectedValues(r, c), actualValues(r, c)) Then Exit Function
            If Not ExternalSnapshotValueMatches(expectedFormulas(r, c), actualFormulas(r, c)) Then Exit Function
        Next c
    Next r
    ExternalSnapshotBlockMatches = True
    Exit Function
Failed:
    ExternalSnapshotBlockMatches = False
End Function

Private Function ExternalSnapshotValueMatches(ByVal expectedValue As Variant, _
                                              ByVal actualValue As Variant) As Boolean
    Dim expectedType As VbVarType, actualType As VbVarType
    On Error GoTo Failed
    expectedType = VarType(expectedValue)
    actualType = VarType(actualValue)
    If expectedType <> actualType Then Exit Function
    If expectedType = vbError Then
        ExternalSnapshotValueMatches = _
            (Application.WorksheetFunction.Error_Type(expectedValue) = _
             Application.WorksheetFunction.Error_Type(actualValue))
    ElseIf expectedType = vbEmpty Or expectedType = vbNull Then
        ExternalSnapshotValueMatches = True
    ElseIf expectedType = vbString Then
        ExternalSnapshotValueMatches = _
            (StrComp(CStr(expectedValue), CStr(actualValue), vbBinaryCompare) = 0)
    Else
        ExternalSnapshotValueMatches = CBool(expectedValue = actualValue)
    End If
    Exit Function
Failed:
    ExternalSnapshotValueMatches = False
End Function

Private Function ExternalSnapshotArrayDimensionsMatch(ByRef firstData As Variant, _
                                                       ByRef secondData As Variant, _
                                                       ByVal expectedRows As Long, _
                                                       ByVal expectedCols As Long) As Boolean
    On Error GoTo Failed
    If Not IsArray(firstData) Or Not IsArray(secondData) Then Exit Function
    If LBound(firstData, 1) <> 1 Or UBound(firstData, 1) <> expectedRows Or _
       LBound(firstData, 2) <> 1 Or UBound(firstData, 2) <> expectedCols Then Exit Function
    If LBound(secondData, 1) <> 1 Or UBound(secondData, 1) <> expectedRows Or _
       LBound(secondData, 2) <> 1 Or UBound(secondData, 2) <> expectedCols Then Exit Function
    ExternalSnapshotArrayDimensionsMatch = True
    Exit Function
Failed:
    ExternalSnapshotArrayDimensionsMatch = False
End Function

Private Function ExternalSnapshotCellKey(ByVal relativeRow As Long, _
                                         ByVal relativeCol As Long) As String
    ExternalSnapshotCellKey = CStr(relativeRow) & Chr$(29) & CStr(relativeCol)
End Function

Private Function ExternalSnapshotConstantNeedsLiteralRestore(ByVal valueIn As Variant) As Boolean
    Dim valueText As String, firstCharacter As String
    If VarType(valueIn) <> vbString Then Exit Function
    valueText = LTrim$(CStr(valueIn))
    If Len(valueText) = 0 Then Exit Function
    firstCharacter = Left$(valueText, 1)
    ExternalSnapshotConstantNeedsLiteralRestore = _
        (firstCharacter = "=" Or firstCharacter = "+" Or _
         firstCharacter = "-" Or firstCharacter = "@")
End Function

Private Sub RestoreExternalSnapshotLiteral(ByVal targetCell As Range, _
                                           ByVal expectedValue As Variant, _
                                           ByVal prefixText As String)
    Dim originalNumberFormat As Variant
    If targetCell Is Nothing Then _
        Err.Raise vbObjectError + 6216, "RestoreExternalSnapshotLiteral", _
                  "候補定数の復元セルがありません。"
    If Len(prefixText) > 0 Then
        If VarType(expectedValue) <> vbString Then _
            Err.Raise vbObjectError + 6217, "RestoreExternalSnapshotLiteral", _
                      "PrefixCharacter付き候補が文字列ではありません。"
        targetCell.Formula = prefixText & CStr(expectedValue)
    Else
        '数式風の定数は一時的に文字列書式で戻し、式として評価させない。
        originalNumberFormat = targetCell.NumberFormat
        targetCell.NumberFormat = "@"
        targetCell.Value2 = expectedValue
        targetCell.NumberFormat = originalNumberFormat
    End If
End Sub

Private Sub RestoreCommonCandidateSnapshots(ByRef bankSnapshot As Variant, ByVal bankRows As Long, _
                                            ByRef branchSnapshot As Variant, ByVal branchRows As Long, _
                                            ByRef personSnapshot As Variant, ByVal personRows As Long, _
                                            ByRef typeSnapshot As Variant, ByVal typeRows As Long, _
                                            ByRef tekiyoSnapshot As Variant, ByVal tekiyoRows As Long)
    Dim restoreProblems As String
    On Error Resume Next
    Err.Clear
    RestoreSheetBlock SH_BANK_CAND, 4, bankSnapshot, bankRows
    If Err.Number <> 0 Then AppendExternalDetail restoreProblems, "銀行候補: " & Err.Description
    Err.Clear
    RestoreSheetBlock SH_BRANCH_CAND, 4, branchSnapshot, branchRows
    If Err.Number <> 0 Then AppendExternalDetail restoreProblems, "支店候補: " & Err.Description
    Err.Clear
    RestoreSheetBlock SH_PERSON_CAND, 4, personSnapshot, personRows
    If Err.Number <> 0 Then AppendExternalDetail restoreProblems, "人物候補: " & Err.Description
    Err.Clear
    RestoreSheetBlock SH_ACCOUNT_TYPE, 4, typeSnapshot, typeRows
    If Err.Number <> 0 Then AppendExternalDetail restoreProblems, "科目候補: " & Err.Description
    Err.Clear
    RestoreSheetBlock SH_TEKIYO, 4, tekiyoSnapshot, tekiyoRows
    If Err.Number <> 0 Then AppendExternalDetail restoreProblems, "摘要候補: " & Err.Description
    Err.Clear
    InvalidateInternalIdCaches
    If Err.Number <> 0 Then AppendExternalDetail restoreProblems, "内部ID索引: " & Err.Description
    On Error GoTo 0
    If Len(restoreProblems) > 0 Then _
        Err.Raise vbObjectError + 6208, "RestoreCommonCandidateSnapshots", restoreProblems
End Sub

Private Function FindCommonHeaderRow(ByVal ws As Worksheet, ByVal lastR As Long, ByVal lastC As Long) As Long
    Dim r As Long, c As Long, score As Long, bestScore As Long
    For r = 1 To Application.Min(10, lastR)
        score = 0
        For c = 1 To lastC
            If HeaderKind(ws.Cells(r, c).Value) > 0 Then score = score + 1
        Next c
        If score > bestScore Then bestScore = score: FindCommonHeaderRow = r
    Next r
    If bestScore = 0 Then FindCommonHeaderRow = 0
End Function

Private Function FindWorksheetHeaderColumn(ByVal ws As Worksheet, ByVal headerRow As Long, ByVal kindNo As Long, ByVal lastC As Long) As Long
    Dim c As Long
    For c = 1 To lastC
        If HeaderKind(ws.Cells(headerRow, c).Value) = kindNo Then FindWorksheetHeaderColumn = c: Exit Function
    Next c
End Function

Private Sub ValidateCommonHeaderUniqueness(ByVal ws As Worksheet, ByVal headerRow As Long, ByVal lastC As Long)
    Dim counts(1 To 15) As Long
    Dim c As Long, kindNo As Long
    If ws Is Nothing Or headerRow < 1 Or lastC < 1 Then Exit Sub
    For c = 1 To lastC
        kindNo = HeaderKind(ws.Cells(headerRow, c).Value)
        Select Case kindNo
            Case 1, 2, 3, 4, 12, 14, 15
                counts(kindNo) = counts(kindNo) + 1
        End Select
    Next c
    For kindNo = 1 To 15
        If counts(kindNo) > 1 Then
            Err.Raise vbObjectError + 6205, "ValidateCommonHeaderUniqueness", _
                      "共通データ「" & ws.Name & "」に同じ役割の見出しが複数あります: " & ExternalHeaderName(kindNo)
        End If
    Next kindNo
End Sub

Private Sub EnsureCommonBulkCellNotError(ByRef sourceData As Variant, ByVal dataRow As Long, _
                                         ByVal colNo As Long, ByVal ws As Worksheet, _
                                         ByVal sourceRow As Long, ByVal labelText As String)
    If colNo <= 0 Then Exit Sub
    If IsError(BulkArrayValue(sourceData, dataRow, colNo)) Then
        Err.Raise vbObjectError + 6206, "EnsureCommonBulkCellNotError", _
                  "共通データの" & labelText & "がExcelエラー値です: " & ws.Name & "!" & _
                  ws.Cells(sourceRow, colNo).Address(False, False)
    End If
End Sub

Private Function CommonBulkText(ByRef sourceData As Variant, ByVal dataRow As Long, _
                                ByVal colNo As Long) As String
    If colNo <= 0 Then Exit Function
    CommonBulkText = CellText(BulkArrayValue(sourceData, dataRow, colNo))
End Function

Private Function CommonBulkIdentifierAtOrBlank(ByRef sourceData As Variant, ByVal dataRow As Long, _
                                                ByVal ws As Worksheet, ByVal sourceRow As Long, _
                                                ByVal colNo As Long, ByVal labelText As String) As String
    '任意列がない場合は配列の0列目を評価しない。文字列IDは一括読込値だけで返す。
    If colNo <= 0 Then Exit Function
    CommonBulkIdentifierAtOrBlank = CommonIdentifierAtOrBlank( _
                                  ws, sourceRow, colNo, labelText, _
                                  BulkArrayValue(sourceData, dataRow, colNo))
End Function

Private Function CommonIdentifierAtOrBlank(ByVal ws As Worksheet, ByVal rowNo As Long, _
                                           ByVal colNo As Long, ByVal labelText As String, _
                                           Optional ByVal suppliedValue As Variant) As String
    Dim numericValue As Double
    Dim rawValue As Variant
    Dim sourceCell As Range
    If ws Is Nothing Or colNo <= 0 Then Exit Function
    If IsMissing(suppliedValue) Then
        Set sourceCell = ws.Cells(rowNo, colNo)
        rawValue = sourceCell.Value2
    Else
        rawValue = suppliedValue
    End If
    If IsNull(rawValue) Or IsEmpty(rawValue) Then Exit Function
    If VarType(rawValue) = vbString Then
        CommonIdentifierAtOrBlank = CellText(rawValue)
        Exit Function
    End If
    If IsError(rawValue) Then
        If sourceCell Is Nothing Then Set sourceCell = ws.Cells(rowNo, colNo)
        Err.Raise vbObjectError + 6206, "CommonIdentifierAtOrBlank", _
                  "共通データの" & labelText & "がExcelエラー値です: " & ws.Name & "!" & _
                  sourceCell.Address(False, False)
    End If
    If VarType(rawValue) = vbBoolean Then
        If sourceCell Is Nothing Then Set sourceCell = ws.Cells(rowNo, colNo)
        Err.Raise vbObjectError + 6210, "CommonIdentifierAtOrBlank", _
                  "共通データの" & labelText & "がTRUE/FALSEです。" & _
                  "識別子は文字列または0以上の整数で保存してください: " & _
                  ws.Name & "!" & sourceCell.Address(False, False)
    End If
    If VarType(rawValue) <> vbString And VarType(rawValue) <> vbBoolean And Not IsEmpty(rawValue) Then
        If IsNumeric(rawValue) Then
            On Error GoTo UnsafeIdentifier
            numericValue = CDbl(rawValue)
            If numericValue < 0 Or numericValue <> Fix(numericValue) Then GoTo InvalidNumericIdentifier
            If numericValue >= 1000000000000000# Then GoTo UnsafeIdentifier
            On Error GoTo 0
            If sourceCell Is Nothing Then Set sourceCell = ws.Cells(rowNo, colNo)
            CommonIdentifierAtOrBlank = ExternalIdentifierText(sourceCell, rawValue)
            Exit Function
        End If
    End If
    CommonIdentifierAtOrBlank = CellText(rawValue)
    Exit Function
UnsafeIdentifier:
    If sourceCell Is Nothing Then Set sourceCell = ws.Cells(rowNo, colNo)
    Err.Raise vbObjectError + 6207, "CommonIdentifierAtOrBlank", _
              "共通データの" & labelText & "が16桁以上の数値セルです。" & _
              "桁丸めを防ぐため、取込元で文字列として保存してください: " & _
              ws.Name & "!" & sourceCell.Address(False, False)
InvalidNumericIdentifier:
    If sourceCell Is Nothing Then Set sourceCell = ws.Cells(rowNo, colNo)
    Err.Raise vbObjectError + 6209, "CommonIdentifierAtOrBlank", _
              "共通データの" & labelText & "が負数または小数の数値セルです。" & _
              "識別子は0以上の整数または文字列で保存してください: " & _
              ws.Name & "!" & sourceCell.Address(False, False)
End Function

Private Sub ImportCommonSheetByName(ByVal ws As Worksheet, ByRef importedCount As Long)
    Dim sheetKey As String, lastR As Long, r As Long, sheetKind As Long, dataRow As Long, dataCols As Long
    Dim sourceData As Variant, candidateText As String
    sheetKey = NormalizeHeaderText(ws.Name)
    If InStr(sheetKey, "銀行") > 0 Then
        sheetKind = 1
    ElseIf InStr(sheetKey, "支店") > 0 Then
        sheetKind = 2
    ElseIf InStr(sheetKey, "人物") > 0 Or InStr(sheetKey, "氏名") > 0 Then
        sheetKind = 3
    ElseIf InStr(sheetKey, "科目") > 0 Or InStr(sheetKey, "種別") > 0 Then
        sheetKind = 4
    ElseIf InStr(sheetKey, "摘要") > 0 Then
        sheetKind = 5
    Else
        Exit Sub
    End If
    lastR = ExternalLastUsedRow(ws)
    If lastR < 2 Then Exit Sub
    If sheetKind = 3 Then dataCols = 3 Else dataCols = 1
    sourceData = ws.Range(ws.Cells(2, 1), ws.Cells(lastR, dataCols)).Value2
    For dataRow = 1 To lastR - 1
        r = dataRow + 1
        EnsureCommonBulkCellNotError sourceData, dataRow, 1, ws, r, "候補値"
        If sheetKind = 3 Then
            EnsureCommonBulkCellNotError sourceData, dataRow, 2, ws, r, "人物ID"
            EnsureCommonBulkCellNotError sourceData, dataRow, 3, ws, r, "続柄"
        End If
        candidateText = CellText(BulkArrayValue(sourceData, dataRow, 1))
        If Len(candidateText) > 0 Then
            Select Case sheetKind
                Case 1
                    AddBankCandidate candidateText, CAND_SOURCE_COMMON
                Case 2
                    AddBranchCandidate candidateText, CAND_SOURCE_COMMON
                Case 3
                    AddPersonCandidateWithID candidateText, _
                                             CommonBulkIdentifierAtOrBlank(sourceData, dataRow, _
                                                                           ws, r, 2, "人物ID"), _
                                             CommonBulkText(sourceData, dataRow, 3), CAND_SOURCE_COMMON
                Case 4
                    AddAccountTypeCandidate candidateText
                Case 5
                    AddTekiyoCandidate candidateText
            End Select
            importedCount = importedCount + 1
        End If
    Next dataRow
End Sub

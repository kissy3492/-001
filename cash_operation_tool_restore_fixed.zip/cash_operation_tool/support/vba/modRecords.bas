﻿Attribute VB_Name = "modRecords"
Option Explicit

Private mInternalIdCaches As Object
Private mRecoveryLatchSession As Boolean
Private mRecoveryLatchPersistenceUncertain As Boolean
Private mRollbackRecoveryAttempted As Boolean
Private Const RECOVERY_LATCH_NAME As String = "_tool_recovery_latch"
Private Const RECOVERY_LATCH_REFERS_TO As String = "=1"
Private Const COUNTER_SNAPSHOT_COUNT As Long = 5
Private Const COUNTER_SNAPSHOT_COL_KEY As Long = 1
Private Const COUNTER_SNAPSHOT_COL_VALUE2 As Long = 2
Private Const COUNTER_SNAPSHOT_COL_VALUE_TYPE As Long = 3
Private Const COUNTER_SNAPSHOT_COL_PREFIX As Long = 4
Private Const COUNTER_SNAPSHOT_LAST_COL As Long = COUNTER_SNAPSHOT_COL_PREFIX
Private Const DELETE_ACCOUNT_CAPACITY_BASE_COLUMNS As Long = 16
Private Const DELETE_ACCOUNT_PERSON_COLUMNS As Long = 4
Private Const DELETE_ACCOUNT_CAPACITY_LONG_MAX As Double = 2147483647#
'vbObjectError + 3599。入れ子呼出しでもEnforce本体errorのhard barrierを伝播する。
Private Const RECORDS_RECOVERY_ENFORCE_ERROR As Long = -2147217905
Private Const RECORDS_RECOVERY_HARD_BARRIER_SOURCE As String = _
    "RecordsRecoveryFatal/"

'口座・取引・残高を、表示文字列ではなく非表示IDで結び付ける。
'利用者はIDを入力せず、登録済み口座画面から対象を選ぶだけで訂正できる。

Public Sub SetupRecordStores(Optional ByVal resetContents As Boolean = False, _
                             Optional ByVal initialDataHealth As String = DATA_HEALTH_NORMAL)
    Dim ws As Worksheet

    If initialDataHealth <> DATA_HEALTH_NORMAL And _
       initialDataHealth <> DATA_HEALTH_INITIALIZING And _
       initialDataHealth <> DATA_HEALTH_NEEDS_RECOVERY Then
        Err.Raise vbObjectError + 3406, "SetupRecordStores", _
                  "案件データ状態の初期値が不正です: " & initialDataHealth
    End If

    If resetContents Then InvalidateInternalIdCaches

    Set ws = GetOrCreateSheet(SH_WORK_ACCOUNT, False)
    If resetContents Then ResetWorksheet ws
    If Len(CellText(ws.Cells(1, 1).Value)) = 0 Then
        SetRowValues ws.Range("A1"), Array("口座ID", "銀行名", "支店名", "氏名", "続柄", "科目", "口座番号", "口座開設日", "口座解約日", "人物ID", "登録元", "更新日時", "最新転記回ID")
        FormatOutputHeader ws.Range("A1:M1")
        ws.Columns("A:M").ColumnWidth = 16
    End If
    ws.Columns("A:G").NumberFormatLocal = "@"
    ws.Columns("H:I").NumberFormatLocal = "yyyy/m/d"
    ws.Columns("J:K").NumberFormatLocal = "@"
    ws.Columns("L:L").NumberFormatLocal = "yyyy/m/d h:mm:ss"
    ws.Columns("M:M").NumberFormatLocal = "@"
    SetSheetVeryHiddenSafe ws

    'シートの作成はSetupWorkbookStructure側で完了していることを必須とする。
    'ここで欠落したW_状態だけを再作成すると、既存正本に初期カウンターを
    '混在させ得るため、セットアップ中でもfail-closedとする。
    If Not SheetExists(SH_WORK_STATE) Then _
        Err.Raise vbObjectError + 3502, "SetupRecordStores", _
                  "状態表がありません。セットアップ構造を先に作成してください。"
    Set ws = GetSheet(SH_WORK_STATE)
    If resetContents Then ResetWorksheet ws
    If Len(CellText(ws.Cells(1, 1).Value)) = 0 Then
        SetRowValues ws.Range("A1"), Array("項目", "値")
        '状態値は文字列契約で保持する。初期値を書いた後で表示形式を変えると、
        '採番値だけ数値型で残り、保存・再開時の厳密読戻しが不安定になる。
        ws.Columns("A:B").NumberFormatLocal = "@"
        FormatOutputHeader ws.Range("A1:B1")
        SetStateValue STATE_NEXT_ACCOUNT, "1"
        SetStateValue STATE_NEXT_TRANSFER, "1"
        SetStateValue STATE_NEXT_TRANSACTION, "1"
        SetStateValue STATE_NEXT_BALANCE, "1"
        SetStateValue STATE_NEXT_PERSON, "1"
        SetStateValue STATE_EDIT_ACCOUNT, ""
        SetStateValue STATE_OUTPUT_DIRTY, STATE_TRUE
        SetStateValue STATE_ANALYSIS_REVIEW_DIRTY, STATE_FALSE
        SetStateValue STATE_LAST_BUILD, ""
        SetStateValue STATE_DATA_HEALTH, initialDataHealth
        SetStateValue STATE_INPUT_DATE_CONFIG_SAFE, STATE_TRUE
    End If
    EnsureStateDefault STATE_NEXT_ACCOUNT, "1"
    EnsureStateDefault STATE_NEXT_TRANSFER, "1"
    EnsureStateDefault STATE_NEXT_TRANSACTION, "1"
    EnsureStateDefault STATE_NEXT_BALANCE, "1"
    EnsureStateDefault STATE_NEXT_PERSON, "1"
    EnsureStateDefault STATE_EDIT_ACCOUNT, ""
    EnsureStateDefault STATE_OUTPUT_DIRTY, STATE_TRUE
    EnsureStateDefault STATE_ANALYSIS_REVIEW_DIRTY, STATE_FALSE
    EnsureStateDefault STATE_LAST_BUILD, ""
    EnsureStateDefault STATE_DATA_HEALTH, initialDataHealth
    EnsureStateDefault STATE_INPUT_DATE_CONFIG_SAFE, STATE_TRUE
    ws.Columns("A:B").NumberFormatLocal = "@"
    SetSheetVeryHiddenSafe ws

    Set ws = GetOrCreateSheet(SH_REGISTERED_ACCOUNTS, False)
    If resetContents Then ResetWorksheet ws
    If Len(CellText(ws.Cells(1, 1).Value)) = 0 Then _
        BuildRegisteredAccountsSheet False, False
    ws.Visible = xlSheetHidden
End Sub

Public Function GetStateValue(ByVal keyText As String, Optional ByVal defaultValue As String = "") As String
    Dim ws As Worksheet
    Dim lastR As Long, r As Long
    On Error GoTo EH
    Set ws = GetSheet(SH_WORK_STATE)
    lastR = LastDataRowInColumns(ws, 1, 2)
    For r = 2 To lastR
        If CellText(ws.Cells(r, 1).Value) = keyText Then
            GetStateValue = CellText(ws.Cells(r, 2).Value)
            Exit Function
        End If
    Next r
EH:
    If Len(GetStateValue) = 0 Then GetStateValue = defaultValue
End Function

Public Function TryGetExactStateValue(ByVal keyText As String, ByRef valueText As String) As Boolean
    '安全判定用。GetStateValueの既定値補完は表示・互換用途には便利だが、
    '案件データ状態のような安全フラグで使うと、欠落や読取失敗を正常値として扱い得る。
    Dim ws As Worksheet
    Dim lastR As Long, r As Long
    Dim found As Boolean, candidateKey As String
    valueText = vbNullString
    If Len(keyText) = 0 Then Exit Function
    If Not SheetExists(SH_WORK_STATE) Then Exit Function
    On Error GoTo EH
    Set ws = GetSheet(SH_WORK_STATE)
    lastR = LastDataRowInColumns(ws, 1, 2)
    For r = 2 To lastR
        '対象外キーの式・エラーは状態表全体監査で扱う。1キーの安全読取まで
        '無関係な行に連動させると、正常な対象値をUNKNOWNへ誤分類する。
        If Not IsError(ws.Cells(r, 1).Value2) Then _
            candidateKey = CellText(ws.Cells(r, 1).Value2) Else candidateKey = vbNullString
        If StrComp(candidateKey, keyText, vbBinaryCompare) = 0 Then
            '安全フラグは重複、数式、Excelエラーのどれも受理しない。
            If found Or ws.Cells(r, 1).HasFormula Or ws.Cells(r, 2).HasFormula Or _
               IsError(ws.Cells(r, 2).Value2) Then GoTo EH
            valueText = CellText(ws.Cells(r, 2).Value2)
            found = True
        End If
    Next r
    TryGetExactStateValue = found
    Exit Function
EH:
    valueText = vbNullString
    TryGetExactStateValue = False
    Err.Clear
End Function

Public Function ToolHasSetupTrace() As Boolean
    'セットアップ途中で中核シートの一部しか作成されなかった場合も検知する。
    '通常の空ブックではFalse、既存・途中生成ツールではどれか一つでTrueとなる。
    ToolHasSetupTrace = _
        SheetExists(SH_INPUT) Or SheetExists(SH_CONFIG) Or _
        SheetExists(SH_WORK_STATE) Or SheetExists(SH_CHECK) Or _
        SheetExists(SH_SETUP_LOG) Or SheetExists(SH_WORK_ACCOUNT) Or _
        SheetExists(SH_WORK_TX) Or SheetExists(SH_WORK_BAL) Or _
        SheetExists(SH_OUTPUT_TX) Or SheetExists(SH_ANALYSIS_RESULT)
End Function

Public Function ToolDataHealthClassification() As Long
    '安全状態を4分類する。読取不能・未知値を明示的な復旧状態と区別し、
    '壊れかけの正常ブックを分析未同期のまま上書きしない。
    Dim dataHealth As String, recoveryLatchSet As Boolean
    'W_STATEそのものを更新できない二重障害でも、独立したブック定義名ラッチが
    '残っている限り正常扱いしない。ラッチの読取り自体が不確実な場合もfail-closed。
    If Not TryGetRollbackRecoveryLatch(recoveryLatchSet) Then
        ToolDataHealthClassification = TOOL_HEALTH_UNKNOWN
        Exit Function
    End If
    If recoveryLatchSet Then
        ToolDataHealthClassification = TOOL_HEALTH_RECOVERY
        Exit Function
    End If
    If Not ToolHasSetupTrace() Then
        ToolDataHealthClassification = TOOL_HEALTH_NOT_INITIALIZED
        Exit Function
    End If
    If Not TryGetExactStateValue(STATE_DATA_HEALTH, dataHealth) Then
        ToolDataHealthClassification = TOOL_HEALTH_UNKNOWN
        Exit Function
    End If
    Select Case dataHealth
        Case DATA_HEALTH_NORMAL
            ToolDataHealthClassification = TOOL_HEALTH_NORMAL
        Case DATA_HEALTH_INITIALIZING, DATA_HEALTH_NEEDS_RECOVERY
            ToolDataHealthClassification = TOOL_HEALTH_RECOVERY
        Case Else
            ToolDataHealthClassification = TOOL_HEALTH_UNKNOWN
    End Select
End Function

Public Function TryGetRollbackRecoveryLatch(ByRef latchIsSet As Boolean) As Boolean
    '非表示のブック定義名をW_STATEから独立した永続ラッチとして使用する。
    'RefersTo、可視性、取得結果のいずれかが不正なら「ラッチなし」へ倒さない。
    Dim recoveryName As Name, candidateName As Name
    Dim refersToText As String, isVisible As Boolean
    Dim candidateText As String, separatorPos As Long
    Dim lookupErrorNumber As Long

    latchIsSet = False
    If mRecoveryLatchPersistenceUncertain Then Exit Function
    If mRecoveryLatchSession Then
        latchIsSet = True
        TryGetRollbackRecoveryLatch = True
        Exit Function
    End If
    On Error GoTo EH
    On Error Resume Next
    Err.Clear
    Set recoveryName = ThisWorkbook.Names(RECOVERY_LATCH_NAME)
    lookupErrorNumber = Err.Number
    Err.Clear
    On Error GoTo EH
    'Names.Itemの不存在は1004。通信・オブジェクト状態など別の失敗を
    '「名前がない」と読み替えず、状態不明として呼出元へ返す。
    If lookupErrorNumber <> 0 And lookupErrorNumber <> 1004 Then GoTo EH
    If recoveryName Is Nothing Then
        '単なるItem未検出とCOM読取異常を区別するため全定義名を走査する。
        '同じ末尾名のローカル定義等があれば、曖昧なため正常扱いしない。
        For Each candidateName In ThisWorkbook.Names
            candidateText = candidateName.Name
            separatorPos = InStrRev(candidateText, "!")
            If separatorPos > 0 Then candidateText = Mid$(candidateText, separatorPos + 1)
            If StrComp(candidateText, RECOVERY_LATCH_NAME, vbBinaryCompare) = 0 Then _
                Exit Function
        Next candidateName
        TryGetRollbackRecoveryLatch = True
        Exit Function
    End If
    refersToText = recoveryName.RefersTo
    isVisible = recoveryName.Visible
    If StrComp(refersToText, RECOVERY_LATCH_REFERS_TO, vbBinaryCompare) <> 0 Or _
       isVisible Then Exit Function
    latchIsSet = True
    TryGetRollbackRecoveryLatch = True
    Exit Function
EH:
    latchIsSet = False
    TryGetRollbackRecoveryLatch = False
    Err.Clear
End Function

Public Sub SetRollbackRecoveryLatch()
    Dim recoveryName As Name
    Dim latchIsSet As Boolean
    Dim errorNumber As Long, errorDescription As String, errorSource As String

    '永続化に失敗しても、少なくとも現セッションの分類を正常へ戻さない。
    mRecoveryLatchSession = True
    mRecoveryLatchPersistenceUncertain = True
    On Error GoTo EH
    On Error Resume Next
    Err.Clear
    Set recoveryName = ThisWorkbook.Names(RECOVERY_LATCH_NAME)
    Err.Clear
    On Error GoTo EH
    If recoveryName Is Nothing Then
        Set recoveryName = ThisWorkbook.Names.Add( _
                               Name:=RECOVERY_LATCH_NAME, _
                               RefersTo:=RECOVERY_LATCH_REFERS_TO, Visible:=False)
    Else
        recoveryName.RefersTo = RECOVERY_LATCH_REFERS_TO
        recoveryName.Visible = False
    End If
    If recoveryName Is Nothing Then _
        Err.Raise vbObjectError + 3494, "SetRollbackRecoveryLatch", _
                  "復旧ラッチを作成できません。"
    mRecoveryLatchPersistenceUncertain = False
    mRecoveryLatchSession = False
    If Not TryGetRollbackRecoveryLatch(latchIsSet) Or Not latchIsSet Then _
        Err.Raise vbObjectError + 3495, "SetRollbackRecoveryLatch", _
                  "復旧ラッチを一意に読み返せません。"
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    mRecoveryLatchSession = True
    mRecoveryLatchPersistenceUncertain = True
    Err.Raise errorNumber, "SetRollbackRecoveryLatch", errorDescription
End Sub

Public Sub ClearRollbackRecoveryLatch()
    '全セットアップ工程と最終検査が成功した時だけ呼ぶ。
    Dim recoveryName As Name
    Dim latchIsSet As Boolean
    Dim errorNumber As Long, errorDescription As String

    On Error GoTo EH
    On Error Resume Next
    Err.Clear
    Set recoveryName = ThisWorkbook.Names(RECOVERY_LATCH_NAME)
    Err.Clear
    On Error GoTo EH
    If Not recoveryName Is Nothing Then recoveryName.Delete
    mRecoveryLatchSession = False
    mRecoveryLatchPersistenceUncertain = False
    If Not TryGetRollbackRecoveryLatch(latchIsSet) Or latchIsSet Then _
        Err.Raise vbObjectError + 3497, "ClearRollbackRecoveryLatch", _
                  "復旧ラッチの解除を一意に確認できません。"
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    '解除工程の失敗は正常化せず、現セッションでも復旧状態を維持する。
    mRecoveryLatchSession = True
    mRecoveryLatchPersistenceUncertain = True
    Err.Raise errorNumber, "ClearRollbackRecoveryLatch", errorDescription
End Sub

Public Function ToolDataHealthIsNormal() As Boolean
    '保存前イベント等からメッセージなしで使うfail-closed判定。
    ToolDataHealthIsNormal = _
        (ToolDataHealthClassification() = TOOL_HEALTH_NORMAL)
End Function

Public Sub SetStateValue(ByVal keyText As String, ByVal valueText As String)
    Dim ws As Worksheet
    Dim lastR As Long, r As Long, targetRow As Long, matchCount As Long
    Dim candidateKey As String
    Dim targetIsNew As Boolean, writeStarted As Boolean
    Dim previousKeyValue As Variant, previousStateValue As Variant
    Dim previousKeyFormat As String, previousStateFormat As String
    Dim errorNumber As Long, errorDescription As String, rollbackDetail As String
    Dim cleanupErrorNumber As Long, cleanupErrorDescription As String
    keyText = Trim$(keyText)
    If Len(keyText) = 0 Or Len(keyText) > 255 Then _
        Err.Raise vbObjectError + 3498, "SetStateValue", _
                  "状態キーが空欄または長すぎます。"
    If Len(valueText) > 32767 Then _
        Err.Raise vbObjectError + 3498, "SetStateValue", _
                  "状態値がExcelセルの上限を超えています: " & keyText
    On Error GoTo EH
    '通常更新primitiveは欠落シートを作らない。作成はSetupRecordStoresだけの責務とし、
    '欠落中に1キーだけのW_状態を新設して正常化する事故を防ぐ。
    If Not SheetExists(SH_WORK_STATE) Then _
        Err.Raise vbObjectError + 3498, "SetStateValue", _
                  "状態表がありません。通常更新では再作成しません。"
    Set ws = GetSheet(SH_WORK_STATE)
    If CellText(ws.Cells(1, 1).Value2) <> "項目" Or _
       CellText(ws.Cells(1, 2).Value2) <> "値" Then _
        Err.Raise vbObjectError + 3498, "SetStateValue", _
                  "状態表の見出しが一致しません。"
    lastR = LastDataRowInColumns(ws, 1, 2)
    For r = 2 To lastR
        If ws.Cells(r, 1).HasFormula Or IsError(ws.Cells(r, 1).Value2) Then _
            Err.Raise vbObjectError + 3498, "SetStateValue", _
                      "状態表のキー列に数式またはExcelエラーがあります: " & CStr(r) & "行"
        candidateKey = CellText(ws.Cells(r, 1).Value2)
        If StrComp(candidateKey, keyText, vbBinaryCompare) = 0 Then
            matchCount = matchCount + 1
            targetRow = r
        End If
    Next r
    If matchCount > 1 Then _
        Err.Raise vbObjectError + 3498, "SetStateValue", _
                  "状態キーが重複しているため更新していません: " & keyText
    If matchCount = 0 Then
        targetRow = lastR + 1
        If targetRow < 2 Then targetRow = 2
        If targetRow > 101 Or targetRow > ws.Rows.Count Then _
            Err.Raise vbObjectError + 3498, "SetStateValue", _
                      "状態表の保存上限を超えるため更新していません。"
        targetIsNew = True
    ElseIf ws.Cells(targetRow, 2).HasFormula Or _
           IsError(ws.Cells(targetRow, 2).Value2) Then
        Err.Raise vbObjectError + 3498, "SetStateValue", _
                  "既存状態値に数式またはExcelエラーがあるため更新していません: " & keyText
    End If

    previousKeyValue = ws.Cells(targetRow, 1).Value2
    previousStateValue = ws.Cells(targetRow, 2).Value2
    previousKeyFormat = ws.Cells(targetRow, 1).NumberFormatLocal
    previousStateFormat = ws.Cells(targetRow, 2).NumberFormatLocal
    writeStarted = True
    ws.Cells(targetRow, 1).NumberFormatLocal = "@"
    ws.Cells(targetRow, 2).NumberFormatLocal = "@"
    ws.Cells(targetRow, 1).Value2 = keyText
    ws.Cells(targetRow, 2).Value2 = valueText
    If ws.Cells(targetRow, 1).HasFormula Or ws.Cells(targetRow, 2).HasFormula Or _
       IsError(ws.Cells(targetRow, 1).Value2) Or IsError(ws.Cells(targetRow, 2).Value2) Or _
       StrComp(CellText(ws.Cells(targetRow, 1).Value2), keyText, vbBinaryCompare) <> 0 Or _
       StrComp(CellText(ws.Cells(targetRow, 2).Value2), valueText, vbBinaryCompare) <> 0 Or _
       Len(CStr(ws.Cells(targetRow, 1).PrefixCharacter)) > 0 Or _
       Len(CStr(ws.Cells(targetRow, 2).PrefixCharacter)) > 0 Then _
        Err.Raise vbObjectError + 3499, "SetStateValue", _
                  "状態値の書込読戻しが一致しません: " & keyText
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    If writeStarted Then _
        TryRestoreStateValue ws, targetRow, targetIsNew, _
                             previousKeyValue, previousStateValue, _
                             previousKeyFormat, previousStateFormat, rollbackDetail
    Err.Raise errorNumber, "SetStateValue(" & keyText & ")", _
              errorDescription & rollbackDetail
End Sub

Private Function TryRestoreStateValue( _
        ByVal ws As Worksheet, ByVal targetRow As Long, ByVal targetIsNew As Boolean, _
        ByVal previousKeyValue As Variant, ByVal previousStateValue As Variant, _
        ByVal previousKeyFormat As String, ByVal previousStateFormat As String, _
        ByRef rollbackDetail As String) As Boolean
    On Error GoTo EH
    If ws Is Nothing Or targetRow < 2 Then _
        Err.Raise vbObjectError + 3503, "TryRestoreStateValue", _
                  "状態値の復元対象を特定できません。"
    If targetIsNew Then
        ws.Range(ws.Cells(targetRow, 1), ws.Cells(targetRow, 2)).ClearContents
        If Len(CellText(ws.Cells(targetRow, 1).Value2)) > 0 Or _
           Len(CellText(ws.Cells(targetRow, 2).Value2)) > 0 Then _
            Err.Raise vbObjectError + 3503, "TryRestoreStateValue", _
                      "追加途中の状態行を消去できません。"
    Else
        ws.Cells(targetRow, 1).NumberFormatLocal = previousKeyFormat
        ws.Cells(targetRow, 2).NumberFormatLocal = previousStateFormat
        ws.Cells(targetRow, 1).Value2 = previousKeyValue
        ws.Cells(targetRow, 2).Value2 = previousStateValue
        If Not StrictVariantValuesMatch(ws.Cells(targetRow, 1).Value2, previousKeyValue) Or _
           Not StrictVariantValuesMatch(ws.Cells(targetRow, 2).Value2, previousStateValue) Or _
           StrComp(ws.Cells(targetRow, 1).NumberFormatLocal, previousKeyFormat, _
                   vbBinaryCompare) <> 0 Or _
           StrComp(ws.Cells(targetRow, 2).NumberFormatLocal, previousStateFormat, _
                   vbBinaryCompare) <> 0 Then _
            Err.Raise vbObjectError + 3503, "TryRestoreStateValue", _
                      "状態値の復元読戻しが一致しません。"
    End If
    TryRestoreStateValue = True
    Exit Function
EH:
    rollbackDetail = " / 元の状態値を復元できません: Err " & _
                     CStr(Err.Number) & " " & Err.Description
    Err.Clear
End Function

Public Function CaptureInternalIdCounters() As Variant
    '既定値補完を使わず、各キーが一意な定数であることとValue2の型まで退避する。
    Dim counterSnapshot() As Variant
    ReDim counterSnapshot(1 To COUNTER_SNAPSHOT_COUNT, 1 To COUNTER_SNAPSHOT_LAST_COL)
    CaptureInternalCounter counterSnapshot, 1, STATE_NEXT_ACCOUNT
    CaptureInternalCounter counterSnapshot, 2, STATE_NEXT_TRANSFER
    CaptureInternalCounter counterSnapshot, 3, STATE_NEXT_TRANSACTION
    CaptureInternalCounter counterSnapshot, 4, STATE_NEXT_BALANCE
    CaptureInternalCounter counterSnapshot, 5, STATE_NEXT_PERSON
    CaptureInternalIdCounters = counterSnapshot
End Function

Public Sub RestoreInternalIdCounters(ByVal counterSnapshot As Variant)
    Dim stateCell As Range
    Dim r As Long, expectedKey As String, prefixText As String
    Dim snapshotValue As Variant, snapshotValueType As Long
    Dim errorNumber As Long, errorDescription As String
    On Error GoTo EH
    If Not InternalCounterSnapshotHasExpectedShape(counterSnapshot) Then
        Err.Raise vbObjectError + 3404, "RestoreInternalIdCounters", "内部IDカウンターの退避値がありません。"
    End If
    For r = 1 To COUNTER_SNAPSHOT_COUNT
        expectedKey = InternalCounterKeyAt(r)
        If StrComp(CStr(counterSnapshot(r, COUNTER_SNAPSHOT_COL_KEY)), _
                   expectedKey, vbBinaryCompare) <> 0 Then _
            Err.Raise vbObjectError + 3405, "RestoreInternalIdCounters", _
                      "内部IDカウンターの退避キーが一致しません: " & expectedKey
        snapshotValue = counterSnapshot(r, COUNTER_SNAPSHOT_COL_VALUE2)
        snapshotValueType = CLng(counterSnapshot(r, COUNTER_SNAPSHOT_COL_VALUE_TYPE))
        prefixText = CStr(counterSnapshot(r, COUNTER_SNAPSHOT_COL_PREFIX))
        If VarType(snapshotValue) <> snapshotValueType Then _
            Err.Raise vbObjectError + 3410, "RestoreInternalIdCounters", _
                      "内部IDカウンターの退避型が一致しません: " & expectedKey
        ValidateInternalCounterValue expectedKey, snapshotValue
        Set stateCell = ExactInternalCounterValueCell(expectedKey)
        If Len(prefixText) > 0 Then
            If snapshotValueType <> vbString Then _
                Err.Raise vbObjectError + 3411, "RestoreInternalIdCounters", _
                          "内部IDカウンターの退避接頭文字が不正です: " & expectedKey
            stateCell.Formula = prefixText & CStr(snapshotValue)
        Else
            stateCell.Value2 = snapshotValue
        End If
    Next r

    '全件を書いた後にもう一度一意性・数式なし・型・値・PrefixCharacterを読戻す。
    For r = 1 To COUNTER_SNAPSHOT_COUNT
        AssertInternalCounterMatchesSnapshot counterSnapshot, r
    Next r
    InvalidateInternalIdCaches
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    On Error Resume Next
    InvalidateInternalIdCaches
    On Error GoTo 0
    Err.Raise errorNumber, "RestoreInternalIdCounters", errorDescription
End Sub

Private Sub CaptureInternalCounter(ByRef counterSnapshot() As Variant, ByVal snapshotRow As Long, _
                                   ByVal stateKey As String)
    Dim stateCell As Range
    Dim rawValue As Variant, prefixText As String
    Set stateCell = ExactInternalCounterValueCell(stateKey)
    rawValue = stateCell.Value2
    ValidateInternalCounterValue stateKey, rawValue
    prefixText = CStr(stateCell.PrefixCharacter)
    counterSnapshot(snapshotRow, COUNTER_SNAPSHOT_COL_KEY) = stateKey
    counterSnapshot(snapshotRow, COUNTER_SNAPSHOT_COL_VALUE2) = rawValue
    counterSnapshot(snapshotRow, COUNTER_SNAPSHOT_COL_VALUE_TYPE) = VarType(rawValue)
    counterSnapshot(snapshotRow, COUNTER_SNAPSHOT_COL_PREFIX) = prefixText
End Sub

Private Function ExactInternalCounterValueCell(ByVal stateKey As String) As Range
    Dim ws As Worksheet, stateCell As Range
    Dim lastR As Long, r As Long, foundCount As Long
    Dim errorNumber As Long, errorDescription As String
    On Error GoTo EH
    If Len(stateKey) = 0 Or Not SheetExists(SH_WORK_STATE) Then _
        Err.Raise vbObjectError + 3412, "ExactInternalCounterValueCell", _
                  "内部IDカウンターの状態表がありません: " & stateKey
    Set ws = GetSheet(SH_WORK_STATE)
    lastR = LastDataRowInColumns(ws, 1, 2)
    For r = 2 To lastR
        If ws.Cells(r, 1).HasFormula Or IsError(ws.Cells(r, 1).Value2) Then _
            Err.Raise vbObjectError + 3413, "ExactInternalCounterValueCell", _
                      "状態キーに数式またはExcelエラーがあります: " & ws.Cells(r, 1).Address(False, False)
        If StrComp(CellText(ws.Cells(r, 1).Value2), stateKey, vbBinaryCompare) = 0 Then
            foundCount = foundCount + 1
            If foundCount > 1 Then _
                Err.Raise vbObjectError + 3414, "ExactInternalCounterValueCell", _
                          "内部IDカウンターが重複しています: " & stateKey
            If ws.Cells(r, 2).HasFormula Or IsError(ws.Cells(r, 2).Value2) Then _
                Err.Raise vbObjectError + 3415, "ExactInternalCounterValueCell", _
                          "内部IDカウンターに数式またはExcelエラーがあります: " & stateKey
            Set stateCell = ws.Cells(r, 2)
        End If
    Next r
    If foundCount <> 1 Or stateCell Is Nothing Then _
        Err.Raise vbObjectError + 3416, "ExactInternalCounterValueCell", _
                  "内部IDカウンターを一意に確認できません: " & stateKey
    Set ExactInternalCounterValueCell = stateCell
    Exit Function
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    Err.Raise errorNumber, "ExactInternalCounterValueCell(" & stateKey & ")", errorDescription
End Function

Private Sub ValidateInternalCounterValue(ByVal stateKey As String, ByVal rawValue As Variant)
    Dim numericValue As Double
    If IsError(rawValue) Then _
        Err.Raise vbObjectError + 3417, "ValidateInternalCounterValue", _
                  "内部IDカウンターがExcelエラー値です: " & stateKey
    If IsNull(rawValue) Or IsEmpty(rawValue) Or VarType(rawValue) = vbBoolean Then _
        Err.Raise vbObjectError + 3417, "ValidateInternalCounterValue", _
                  "内部IDカウンターが数値定数ではありません: " & stateKey
    If Not IsNumeric(rawValue) Then _
        Err.Raise vbObjectError + 3417, "ValidateInternalCounterValue", _
                  "内部IDカウンターが数値定数ではありません: " & stateKey
    numericValue = CDbl(rawValue)
    If numericValue <> Fix(numericValue) Or numericValue < 1 Or numericValue > 2147483647# Then _
        Err.Raise vbObjectError + 3418, "ValidateInternalCounterValue", _
                  "内部IDカウンターが範囲外です: " & stateKey
End Sub

Private Function InternalCounterSnapshotHasExpectedShape(ByVal counterSnapshot As Variant) As Boolean
    On Error GoTo EH
    If Not IsArray(counterSnapshot) Then Exit Function
    If LBound(counterSnapshot, 1) <> 1 Or _
       UBound(counterSnapshot, 1) <> COUNTER_SNAPSHOT_COUNT Then Exit Function
    If LBound(counterSnapshot, 2) <> 1 Or _
       UBound(counterSnapshot, 2) <> COUNTER_SNAPSHOT_LAST_COL Then Exit Function
    InternalCounterSnapshotHasExpectedShape = True
    Exit Function
EH:
    InternalCounterSnapshotHasExpectedShape = False
    Err.Clear
End Function

Private Function InternalCounterKeyAt(ByVal snapshotRow As Long) As String
    Select Case snapshotRow
        Case 1: InternalCounterKeyAt = STATE_NEXT_ACCOUNT
        Case 2: InternalCounterKeyAt = STATE_NEXT_TRANSFER
        Case 3: InternalCounterKeyAt = STATE_NEXT_TRANSACTION
        Case 4: InternalCounterKeyAt = STATE_NEXT_BALANCE
        Case 5: InternalCounterKeyAt = STATE_NEXT_PERSON
    End Select
End Function

Private Sub AssertInternalCounterMatchesSnapshot(ByVal counterSnapshot As Variant, _
                                                 ByVal snapshotRow As Long)
    Dim stateKey As String, prefixText As String
    Dim stateCell As Range, expectedValue As Variant
    stateKey = InternalCounterKeyAt(snapshotRow)
    Set stateCell = ExactInternalCounterValueCell(stateKey)
    expectedValue = counterSnapshot(snapshotRow, COUNTER_SNAPSHOT_COL_VALUE2)
    prefixText = CStr(counterSnapshot(snapshotRow, COUNTER_SNAPSHOT_COL_PREFIX))
    If stateCell.HasFormula Or _
       VarType(stateCell.Value2) <> CLng(counterSnapshot(snapshotRow, COUNTER_SNAPSHOT_COL_VALUE_TYPE)) Or _
       Not StrictVariantValuesMatch(expectedValue, stateCell.Value2) Or _
       StrComp(prefixText, CStr(stateCell.PrefixCharacter), vbBinaryCompare) <> 0 Then _
        Err.Raise vbObjectError + 3419, "AssertInternalCounterMatchesSnapshot", _
                  "内部IDカウンターの復元読戻しが一致しません: " & stateKey
End Sub

Private Sub EnsureStateDefault(ByVal keyText As String, ByVal defaultValue As String)
    Dim ws As Worksheet, lastR As Long, r As Long
    Dim foundAny As Boolean, exactValue As String
    Set ws = GetSheet(SH_WORK_STATE)
    lastR = LastDataRowInColumns(ws, 1, 2)
    For r = 2 To lastR
        If Not IsError(ws.Cells(r, 1).Value2) Then
            If StrComp(CellText(ws.Cells(r, 1).Value2), keyText, _
                       vbBinaryCompare) = 0 Then foundAny = True
        End If
    Next r
    If foundAny Then
        If Not TryGetExactStateValue(keyText, exactValue) Then _
            Err.Raise vbObjectError + 3501, "EnsureStateDefault", _
                      "既存状態キーが重複・数式・エラーのため補完していません: " & keyText
        Exit Sub
    End If
    SetStateValue keyText, defaultValue
End Sub

Public Function NextInternalId(ByVal stateKey As String, ByVal prefixText As String) As String
    Dim reserved As Variant
    reserved = ReserveInternalIds(stateKey, prefixText, 1)
    NextInternalId = CStr(reserved(1))
End Function

Public Function ReserveInternalIds(ByVal stateKey As String, ByVal prefixText As String, _
                                   ByVal reserveCount As Long) As Variant
    '大量明細でもW_状態を1行ずつ更新しない。一括で衝突を避けて採番し、
    '次番号は全件確保できた後に一度だけ進める。
    Dim n As Long, allocated As Long, i As Long
    Dim stateText As String, stateNumber As Double, nextStateNumber As Double
    Dim candidateID As String
    Dim ids As Object
    Dim reserved() As String
    If reserveCount < 1 Then _
        Err.Raise vbObjectError + 3407, "ReserveInternalIds", "内部IDの予約件数が不正です: " & reserveCount
    If Len(prefixText) = 0 Then _
        Err.Raise vbObjectError + 3408, "ReserveInternalIds", "内部IDの接頭辞が空欄です。"

    Set ids = GetInternalIdCache(stateKey)
    '採番カウンターの欠落・重複・数式を既定値1へ読み替えると、既存IDを再発行する。
    '安全読取で一意な定数を確認できた場合だけ予約を進める。
    If Not TryGetExactStateValue(stateKey, stateText) Then _
        Err.Raise vbObjectError + 3401, "ReserveInternalIds", _
                  "内部IDカウンターを一意に読み取れません: " & stateKey
    If Not IsNumeric(stateText) Then _
        Err.Raise vbObjectError + 3401, "ReserveInternalIds", "内部IDカウンターが数値ではありません: " & stateKey
    stateNumber = CDbl(stateText)
    If stateNumber <> Fix(stateNumber) Or stateNumber < 1 Or stateNumber > 2147483647# Then
        Err.Raise vbObjectError + 3402, "ReserveInternalIds", "内部IDカウンターが範囲外です: " & stateKey
    End If
    If stateNumber = 2147483647# Then _
        Err.Raise vbObjectError + 3403, "ReserveInternalIds", "内部IDをこれ以上採番できません: " & stateKey

    n = CLng(stateNumber)
    ReDim reserved(1 To reserveCount)
    Do While allocated < reserveCount
        candidateID = prefixText & Format$(n, "000000")
        If Not ids.Exists(candidateID) Then
            allocated = allocated + 1
            reserved(allocated) = candidateID
        End If
        If n >= 2147483646 Then
            If allocated < reserveCount Then _
                Err.Raise vbObjectError + 3403, "ReserveInternalIds", "内部IDをこれ以上採番できません: " & stateKey
            nextStateNumber = 2147483647#
            Exit Do
        End If
        n = n + 1
    Loop
    If nextStateNumber = 0 Then nextStateNumber = n

    '状態表が進んだ後にだけメモリ索引へ予約IDを反映する。呼出側の失敗時は
    '既存のカウンター退避・復元処理が状態表と索引を同時に戻す。
    SetStateValue stateKey, Format$(nextStateNumber, "0")
    For i = 1 To reserveCount
        ids(reserved(i)) = True
    Next i
    ReserveInternalIds = reserved
End Function

Public Sub InvalidateInternalIdCaches()
    Set mInternalIdCaches = Nothing
End Sub

Public Sub ReconcileInternalIdCounters()
    '共通人物候補を残したまま案件初期化しても、採番が既存IDへ戻らないよう整合させる。
    SetCounterAtLeast STATE_NEXT_ACCOUNT, MaxInternalSuffix(GetSheet(SH_WORK_ACCOUNT), ACC_COL_ID, "A") + 1
    '明細が空でもW_口座の最新転記回IDだけが残る場合がある。口座マスタも採番済み集合へ含め、
    '既存R-IDを次回登録で再発行しない。
    SetCounterAtLeast STATE_NEXT_TRANSFER, Application.Max( _
                          MaxInternalSuffix(GetSheet(SH_WORK_TX), WORK_TX_COL_TRANSFER_ID, "R"), _
                          MaxInternalSuffix(GetSheet(SH_WORK_BAL), WORK_BAL_COL_TRANSFER_ID, "R"), _
                          MaxInternalSuffix(GetSheet(SH_WORK_ACCOUNT), ACC_COL_TRANSFER_ID, "R")) + 1
    SetCounterAtLeast STATE_NEXT_TRANSACTION, MaxInternalSuffix(GetSheet(SH_WORK_TX), WORK_TX_COL_TRANSACTION_ID, "T") + 1
    SetCounterAtLeast STATE_NEXT_BALANCE, MaxInternalSuffix(GetSheet(SH_WORK_BAL), WORK_BAL_COL_BALANCE_ID, "B") + 1
    SetCounterAtLeast STATE_NEXT_PERSON, Application.Max(MaxInternalSuffix(GetSheet(SH_PERSON_CAND), 2, "P"), _
                                                         MaxInternalSuffix(GetSheet(SH_WORK_ACCOUNT), ACC_COL_PERSON_ID, "P")) + 1
    InvalidateInternalIdCaches
End Sub

Private Sub SetCounterAtLeast(ByVal stateKey As String, ByVal minimumValue As Long)
    Dim currentValue As Long
    Dim currentText As String, currentNumber As Double
    If minimumValue < 1 Then minimumValue = 1
    currentText = GetStateValue(stateKey, "1")
    If IsNumeric(currentText) Then
        currentNumber = CDbl(currentText)
        If currentNumber = Fix(currentNumber) And currentNumber >= 1 And currentNumber <= 2147483647# Then currentValue = CLng(currentNumber)
    End If
    If currentValue < minimumValue Then SetStateValue stateKey, CStr(minimumValue)
End Sub

Private Function MaxInternalSuffix(ByVal ws As Worksheet, ByVal colNo As Long, ByVal prefixText As String) As Long
    Dim r As Long, lastR As Long, idText As String, n As Long, rawNumber As Double
    Dim idValues As Variant, valueAtRow As Variant
    If ws Is Nothing Then Exit Function
    lastR = LastRow(ws, colNo)
    If lastR < 2 Then Exit Function
    idValues = ws.Range(ws.Cells(2, colNo), ws.Cells(lastR, colNo)).Value2
    For r = 1 To lastR - 1
        If lastR = 2 Then valueAtRow = idValues Else valueAtRow = idValues(r, 1)
        idText = CellText(valueAtRow)
        If Len(idText) > Len(prefixText) And StrComp(Left$(idText, Len(prefixText)), prefixText, vbTextCompare) = 0 Then
            rawNumber = Val(Mid$(idText, Len(prefixText) + 1))
            If rawNumber > 2147483646# Then n = 2147483646 Else n = CLng(rawNumber)
            If n > MaxInternalSuffix Then MaxInternalSuffix = n
        End If
    Next r
End Function

Private Function GetInternalIdCache(ByVal stateKey As String) As Object
    Dim ids As Object
    If mInternalIdCaches Is Nothing Then
        Set mInternalIdCaches = CreateObject("Scripting.Dictionary")
        mInternalIdCaches.CompareMode = vbTextCompare
    End If
    If mInternalIdCaches.Exists(stateKey) Then
        Set ids = mInternalIdCaches(stateKey)
    Else
        Set ids = CreateObject("Scripting.Dictionary")
        ids.CompareMode = vbTextCompare
        LoadInternalIds stateKey, ids
        mInternalIdCaches.Add stateKey, ids
    End If
    Set GetInternalIdCache = ids
End Function

Private Sub LoadInternalIds(ByVal stateKey As String, ByVal ids As Object)
    Select Case stateKey
        Case STATE_NEXT_ACCOUNT
            AddColumnIds GetSheet(SH_WORK_ACCOUNT), ACC_COL_ID, ids
        Case STATE_NEXT_TRANSFER
            AddColumnIds GetSheet(SH_WORK_TX), WORK_TX_COL_TRANSFER_ID, ids
            AddColumnIds GetSheet(SH_WORK_BAL), WORK_BAL_COL_TRANSFER_ID, ids
            AddColumnIds GetSheet(SH_WORK_ACCOUNT), ACC_COL_TRANSFER_ID, ids
        Case STATE_NEXT_TRANSACTION
            AddColumnIds GetSheet(SH_WORK_TX), WORK_TX_COL_TRANSACTION_ID, ids
        Case STATE_NEXT_BALANCE
            AddColumnIds GetSheet(SH_WORK_BAL), WORK_BAL_COL_BALANCE_ID, ids
        Case STATE_NEXT_PERSON
            AddColumnIds GetSheet(SH_PERSON_CAND), 2, ids
            AddColumnIds GetSheet(SH_WORK_ACCOUNT), ACC_COL_PERSON_ID, ids
    End Select
End Sub

Private Sub AddColumnIds(ByVal ws As Worksheet, ByVal colNo As Long, ByVal ids As Object)
    Dim lastR As Long, r As Long, idText As String
    Dim idValues As Variant, valueAtRow As Variant
    If ws Is Nothing Or ids Is Nothing Then Exit Sub
    lastR = LastRow(ws, colNo)
    If lastR < 2 Then Exit Sub
    idValues = ws.Range(ws.Cells(2, colNo), ws.Cells(lastR, colNo)).Value2
    For r = 1 To lastR - 1
        If lastR = 2 Then valueAtRow = idValues Else valueAtRow = idValues(r, 1)
        idText = CellText(valueAtRow)
        If Len(idText) > 0 Then ids(idText) = True
    Next r
End Sub

Public Function CurrentEditAccountID() As String
    CurrentEditAccountID = GetStateValue(STATE_EDIT_ACCOUNT, "")
End Function

Public Function IsEditMode() As Boolean
    IsEditMode = (Len(CurrentEditAccountID()) > 0)
End Function

Public Sub SetEditAccountID(ByVal accountID As String)
    Dim previousAccountID As String, requestedAccountID As String
    Dim confirmedAccountID As String
    Dim snapshotCaptured As Boolean, writeAttempted As Boolean
    Dim rollbackDetail As String, recoveryDetail As String
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim eventDetail As String
    On Error GoTo EH
    '正本状態の既定値補完をsnapshotに使わない。一意な定数値を読めない時は、
    '後で戻せる値がないため何も書き込まない。
    If Not TryGetExactStateValue(STATE_EDIT_ACCOUNT, previousAccountID) Then _
        Err.Raise vbObjectError + 3493, "SetEditAccountID", _
                  "更新前の訂正IDを一意に退避できません。"
    snapshotCaptured = True
    requestedAccountID = CellText(accountID)

    writeAttempted = True
    SetStateValue STATE_EDIT_ACCOUNT, requestedAccountID
    If Not TryGetExactStateValue(STATE_EDIT_ACCOUNT, confirmedAccountID) Or _
       StrComp(confirmedAccountID, requestedAccountID, vbBinaryCompare) <> 0 Then _
        Err.Raise vbObjectError + 3493, "SetEditAccountID", _
                  "訂正IDの書込読戻しが一致しません。"

    '訂正モードで編集可否が変わる人物候補を、非表示中も直ちに現在状態へ収束させる。
    If SheetExists(SH_PERSON_CAND) Then _
        ProtectCandidateSheet GetSheet(SH_PERSON_CAND), True
    RefreshMainActionCaption
    '派生UIの収束中にイベント等が正本を変えていないことも最後に確認する。
    confirmedAccountID = vbNullString
    If Not TryGetExactStateValue(STATE_EDIT_ACCOUNT, confirmedAccountID) Or _
       StrComp(confirmedAccountID, requestedAccountID, vbBinaryCompare) <> 0 Then _
        Err.Raise vbObjectError + 3493, "SetEditAccountID", _
                  "訂正IDの最終状態が更新値と一致しません。"
    Exit Sub
EH:
    errorNumber = Err.Number
    errorSource = Err.Source
    errorDescription = Err.Description
    If IsRecordsRecoveryHardBarrier(errorNumber, errorSource) Then
        Call TryKeepRecordsEventsDisabledExact(eventDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    If snapshotCaptured And writeAttempted Then
        If Not TryRestoreEditAccountIDSnapshot(previousAccountID, rollbackDetail) Then
            recoveryDetail = "訂正IDの更新前状態を復元できません: " & rollbackDetail
            If Not TryEnforceEditAccountRollbackRecovery(recoveryDetail) Then _
                AppendRecordsDetail recoveryDetail, _
                    "復旧安全停止自体を完了できません。"
            errorDescription = errorDescription & " / " & recoveryDetail
        End If
    End If
    Err.Raise errorNumber, "SetEditAccountID", errorDescription
End Sub

Private Function TryRestoreEditAccountIDSnapshot(ByVal previousAccountID As String, _
                                                 ByRef detailText As String) As Boolean
    Dim restoredAccountID As String
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim eventDetail As String
    detailText = vbNullString
    On Error GoTo EH
    SetStateValue STATE_EDIT_ACCOUNT, previousAccountID
    If Not TryGetExactStateValue(STATE_EDIT_ACCOUNT, restoredAccountID) Or _
       StrComp(restoredAccountID, previousAccountID, vbBinaryCompare) <> 0 Then _
        Err.Raise vbObjectError + 3493, "TryRestoreEditAccountIDSnapshot", _
                  "訂正IDのrollback読戻しが一致しません。"

    '正本を戻した後に、候補シートと操作表示も退避状態から再投影する。
    If SheetExists(SH_PERSON_CAND) Then _
        ProtectCandidateSheet GetSheet(SH_PERSON_CAND), True
    RefreshMainActionCaption
    restoredAccountID = vbNullString
    If Not TryGetExactStateValue(STATE_EDIT_ACCOUNT, restoredAccountID) Or _
       StrComp(restoredAccountID, previousAccountID, vbBinaryCompare) <> 0 Then _
        Err.Raise vbObjectError + 3493, "TryRestoreEditAccountIDSnapshot", _
                  "訂正IDのrollback最終状態が一致しません。"
    TryRestoreEditAccountIDSnapshot = True
    Exit Function
EH:
    errorNumber = Err.Number
    errorSource = Err.Source
    errorDescription = Err.Description
    If IsRecordsRecoveryHardBarrier(errorNumber, errorSource) Then
        Call TryKeepRecordsEventsDisabledExact(eventDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    detailText = "Err " & CStr(errorNumber) & " [" & errorSource & "] " & errorDescription
    Err.Clear
End Function

Private Function TryEnforceEditAccountRollbackRecovery(ByRef detailText As String) As Boolean
    Dim eventsStopped As Boolean, recoveryConfirmed As Boolean
    Dim recoveryAttempted As Boolean, recoveryEnforceFailed As Boolean
    Dim eventDetail As String
    eventsStopped = TryKeepRecordsEventsDisabledExact(eventDetail)
    If Not eventsStopped Then
        AppendRecordsDetail detailText, _
            "復旧安全停止前にExcelイベント停止を確認できません: " & eventDetail
        Exit Function
    End If
    TryEnforceEditAccountRollbackRecovery = _
        TryEnterRecordsRecoveryState( _
            "訂正IDロールバック不成立", eventsStopped, _
            recoveryConfirmed, recoveryAttempted, _
            recoveryEnforceFailed, detailText)
End Function

Private Function RollbackRecoveryStateIsConfirmedExact( _
        ByRef detailText As String, _
        ByRef dateSafeFallbackConfirmed As Boolean) As Boolean
    '呼出元も正常returnだけに依存せず、独立ラッチとhealthの双方を
    '一意に読めた時だけ「要復旧として停止済み」と判定する。
    Dim latchSet As Boolean, latchReadSucceeded As Boolean
    Dim healthValue As String, healthReadSucceeded As Boolean
    Dim dateSafeValue As String, dateSafeReadSucceeded As Boolean
    Dim errorNumber As Long, errorDescription As String

    dateSafeFallbackConfirmed = False
    On Error GoTo EH
    latchReadSucceeded = TryGetRollbackRecoveryLatch(latchSet)
    healthReadSucceeded = _
        TryGetExactStateValue(STATE_DATA_HEALTH, healthValue)
    RollbackRecoveryStateIsConfirmedExact = _
        latchReadSucceeded And latchSet And healthReadSucceeded And _
        (StrComp(healthValue, DATA_HEALTH_NEEDS_RECOVERY, _
                 vbBinaryCompare) = 0)
    If RollbackRecoveryStateIsConfirmedExact Then Exit Function

    If Not latchReadSucceeded Then
        AppendRecordsDetail detailText, _
                            "独立復旧ラッチを一意に読み返せません。"
    ElseIf Not latchSet Then
        AppendRecordsDetail detailText, _
                            "独立復旧ラッチが設定されていません。"
    End If
    If Not healthReadSucceeded Then
        AppendRecordsDetail detailText, _
                            "案件healthを一意に読み返せません。"
    ElseIf StrComp(healthValue, DATA_HEALTH_NEEDS_RECOVERY, _
                   vbBinaryCompare) <> 0 Then
        AppendRecordsDetail detailText, _
                            "案件healthが要復旧ではありません（実値=" & _
                            healthValue & "）。"
    End If

    'DATE_SAFE=Falseは登録だけを止める代替防衛であり、帳票・通常操作まで
    '止める要復旧確定とは区別してdetailへ残す。
    dateSafeReadSucceeded = _
        TryGetExactStateValue(STATE_INPUT_DATE_CONFIG_SAFE, dateSafeValue)
    dateSafeFallbackConfirmed = dateSafeReadSucceeded And _
        (StrComp(dateSafeValue, STATE_FALSE, vbBinaryCompare) = 0)
    If dateSafeFallbackConfirmed Then
        AppendRecordsDetail detailText, _
                            "代替の登録停止（DATE_SAFE=False）のみ確認しました。"
    Else
        AppendRecordsDetail detailText, _
                            "代替の登録停止も一意に確認できません。"
    End If
    Exit Function
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    Err.Clear
    AppendRecordsDetail detailText, _
                        "復旧状態の確認エラー: Err " & _
                        CStr(errorNumber) & " " & errorDescription
End Function

Public Function OutputsAreDirty() As Boolean
    Dim stateValue As String
    '印刷・最終出力の安全ゲート用。欠落・重複・数式・Excelエラー・読取失敗を
    '「更新済み」へ倒さず、一意なFalseを確認できた時だけcleanとみなす。
    OutputsAreDirty = True
    If TryGetExactStateValue(STATE_OUTPUT_DIRTY, stateValue) Then _
        OutputsAreDirty = (StrComp(stateValue, STATE_FALSE, vbBinaryCompare) <> 0)
End Function

Public Function TryBuildCanonicalSaveSummary(ByRef recordSummary As String, _
                                              ByRef totalRecordCount As Double, _
                                              ByRef warningText As String) As Boolean
    '入力シートは編集中の下書き、W_口座・W_取引・W_残高は登録済み正本である。
    '保存監査には正本件数を使い、入力途中のセルを登録済み件数へ混ぜない。
    Dim accountRows As Long, transactionRows As Long, balanceRows As Long
    Dim reviewRows As Long
    Dim errorNumber As Long, errorDescription As String
    recordSummary = vbNullString
    warningText = vbNullString
    totalRecordCount = 0#
    On Error GoTo EH
    If Not SheetExists(SH_WORK_ACCOUNT) Or Not SheetExists(SH_WORK_TX) Or _
       Not SheetExists(SH_WORK_BAL) Then _
        Err.Raise vbObjectError + 3500, "TryBuildCanonicalSaveSummary", _
                  "登録済み正本の内部保管が不足しています。"
    accountRows = LastDataRowInColumns(GetSheet(SH_WORK_ACCOUNT), 1, ACC_COL_TRANSFER_ID) - 1
    transactionRows = LastDataRowInColumns(GetSheet(SH_WORK_TX), 1, WORK_TX_COL_PERSON_ID) - 1
    balanceRows = LastDataRowInColumns(GetSheet(SH_WORK_BAL), 1, WORK_BAL_COL_PERSON_ID) - 1
    If accountRows < 0 Then accountRows = 0
    If transactionRows < 0 Then transactionRows = 0
    If balanceRows < 0 Then balanceRows = 0
    If SheetExists(SH_WORK_ANALYSIS_REVIEW) Then
        reviewRows = LastDataRowInColumns(GetSheet(SH_WORK_ANALYSIS_REVIEW), _
                                          1, ANALYSIS_REVIEW_STORE_LAST_COL) - 1
        If reviewRows < 0 Then reviewRows = 0
    Else
        warningText = "分析判断台帳なし"
    End If
    totalRecordCount = CDbl(accountRows) + CDbl(transactionRows) + _
                       CDbl(balanceRows) + CDbl(reviewRows)
    recordSummary = "正本: 口座=" & Format$(accountRows, "0") & _
                    ", 取引=" & Format$(transactionRows, "0") & _
                    ", 残高=" & Format$(balanceRows, "0") & _
                    ", 分析判断=" & Format$(reviewRows, "0") & _
                    ", 合計=" & Format$(totalRecordCount, "0")
    If OutputsAreDirty() Then warningText = AppendSaveSummaryWarning( _
                                             warningText, "帳票要更新")
    If AnalysisReviewsAreDirty() Then warningText = AppendSaveSummaryWarning( _
                                                    warningText, "分析判断要同期")
    If IsEditMode() Then warningText = AppendSaveSummaryWarning( _
                                     warningText, "口座訂正モード中")
    TryBuildCanonicalSaveSummary = True
    Exit Function
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    warningText = AppendSaveSummaryWarning(warningText, _
                  "正本件数を取得できません: Err " & CStr(errorNumber) & " " & errorDescription)
    Err.Clear
End Function

Private Function AppendSaveSummaryWarning(ByVal warningText As String, _
                                          ByVal newWarning As String) As String
    newWarning = Trim$(newWarning)
    If Len(newWarning) = 0 Then
        AppendSaveSummaryWarning = warningText
    ElseIf Len(warningText) = 0 Then
        AppendSaveSummaryWarning = newWarning
    Else
        AppendSaveSummaryWarning = warningText & " / " & newWarning
    End If
End Function

Public Function AnalysisReviewsAreDirty() As Boolean
    Dim stateValue As String
    '欠落や重複を「未変更」とみなすと、保存前の台帳同期を飛ばし得るためfail-closedにする。
    AnalysisReviewsAreDirty = True
    If TryGetExactStateValue(STATE_ANALYSIS_REVIEW_DIRTY, stateValue) Then _
        AnalysisReviewsAreDirty = (StrComp(stateValue, STATE_FALSE, vbBinaryCompare) <> 0)
End Function

Public Sub MarkAnalysisReviewsDirty()
    Dim stateValue As String
    SetStateValue STATE_ANALYSIS_REVIEW_DIRTY, STATE_TRUE
    If Not TryGetExactStateValue(STATE_ANALYSIS_REVIEW_DIRTY, stateValue) Or _
       stateValue <> STATE_TRUE Then _
        Err.Raise vbObjectError + 3487, "MarkAnalysisReviewsDirty", _
                  "分析確認の要更新状態を一意に確認できません。"
End Sub

Public Sub MarkAnalysisReviewsClean()
    Dim stateValue As String
    SetStateValue STATE_ANALYSIS_REVIEW_DIRTY, STATE_FALSE
    If Not TryGetExactStateValue(STATE_ANALYSIS_REVIEW_DIRTY, stateValue) Or _
       stateValue <> STATE_FALSE Then _
        Err.Raise vbObjectError + 3488, "MarkAnalysisReviewsClean", _
                  "分析確認の更新済み状態を一意に確認できません。"
End Sub

Public Sub MarkOutputsDirty()
    Dim stateValue As String
    SetStateValue STATE_OUTPUT_DIRTY, STATE_TRUE
    If Not TryGetExactStateValue(STATE_OUTPUT_DIRTY, stateValue) Or _
       stateValue <> STATE_TRUE Then _
        Err.Raise vbObjectError + 3489, "MarkOutputsDirty", _
                  "帳票の要更新状態を一意に確認できません。"

    '派生表は同期的に消去しない。最終出力はdirty状態なら必ず同一工程で再生成する。
    '編集イベント中の全消去や、後続処理失敗時に旧成果物まで失う事故を防ぐ。
    On Error Resume Next
    RefreshMainActionCaption
    On Error GoTo 0
End Sub

Public Sub EnforceRollbackRecoveryState(ByRef detailText As String)
    '内部データのrollbackを照合できない場合の共通最終防衛。
    'Application.EnableEventsは呼出元所有のleaseである。開始値を厳密に捕捉し、
    'ブックへのいかなる復旧書込みより前にFalseの書込みと読戻しを完了する。
    '復旧ラッチ=TrueとDATA_HEALTH=NEEDS_RECOVERYの独立読戻しを
    '両方確認できた場合だけ要復旧の確定成功とする。
    Dim stateValue As String
    Dim entryEvents As Boolean, entryEventsCaptured As Boolean
    Dim eventsStopped As Boolean, recoveryConfirmed As Boolean
    Dim outputsConfirmed As Boolean, healthConfirmed As Boolean
    Dim dateStopConfirmed As Boolean, dateSafeFallbackConfirmed As Boolean
    Dim latchIsSet As Boolean, latchReadSucceeded As Boolean
    Dim keysDisabled As Boolean, inspectionPrepared As Boolean
    Dim safeToRestoreEntry As Boolean
    Dim operationErrorNumber As Long, operationErrorDescription As String
    Dim applicationErrorNumber As Long, applicationErrorSource As String
    Dim applicationErrorDescription As String
    Dim applicationStateRestored As Boolean
    Dim eventDetail As String, confirmationDetail As String
    Dim applicationStateDetail As String, convergenceDetail As String

    'Recovery本体はVBAセッション内で一度だけ試行する。最初の試行が
    '正常／異常のどちらで終端しても、二度目はブックや退避状態へ触れない。
    If mRollbackRecoveryAttempted Then
        eventsStopped = TryKeepRecordsEventsDisabledExact(eventDetail)
        If eventsStopped Then
            AppendRecordsDetail detailText, _
                "Recovery強制設定はこのVBAセッションで既に試行済みのため、" & _
                "再試行せずExcelイベントをFalseで停止しました。"
        Else
            AppendRecordsDetail detailText, _
                "Recovery強制設定の再試行を抑止しましたが、" & _
                "ExcelイベントFalse収束にも失敗しました: " & eventDetail
        End If
        Err.Raise vbObjectError + 3599, _
                  "RollbackRecoveryTerminal/EnforceRollbackRecoveryState", _
                  detailText
    End If
    '開始値読取りを含む最初の外部操作より前に所有権を確定する。
    'このフラグはVBA reset／ブック再openまで解除しない。
    mRollbackRecoveryAttempted = True

    entryEventsCaptured = _
        TryGetRecordsEnableEvents(entryEvents, eventDetail)
    If Not entryEventsCaptured Then
        AppendRecordsDetail detailText, _
            "Excelイベント開始値を一意に取得できないため、" & _
            "ブックへの復旧書込みは一切実行しませんでした。 " & eventDetail
        AppendRecordsDetail detailText, _
            "Excelイベント状態と案件の安全状態は不明です。"
        Err.Raise vbObjectError + 3599, _
                  "RollbackRecoveryTerminal/EnforceRollbackRecoveryState", _
                  detailText
    End If

    eventsStopped = TryKeepRecordsEventsDisabledExact(eventDetail)
    If Not eventsStopped Then
        AppendRecordsDetail detailText, _
            "復旧書込み前のExcelイベント停止を一意に確認できないため、" & _
            "ブックへの復旧書込みは一切実行しませんでした。 " & eventDetail
        AppendRecordsDetail detailText, _
            "Excelイベント状態と案件の安全状態は不明です。"
        GoTo FAIL_CLOSED
    End If

    '状態表の書込み可否と独立した定義名ラッチを最初に永続化する。
    If Not TryKeepRecordsEventsDisabledExact(eventDetail) Then
        AppendRecordsDetail detailText, _
            "独立復旧ラッチ記録前のイベント停止を確認できません: " & eventDetail
        GoTo FAIL_CLOSED
    End If
    On Error Resume Next
    Err.Clear
    SetRollbackRecoveryLatch
    operationErrorNumber = Err.Number
    operationErrorDescription = Err.Description
    Err.Clear
    On Error GoTo 0
    latchReadSucceeded = TryGetRollbackRecoveryLatch(latchIsSet)
    If operationErrorNumber <> 0 Then _
        AppendRecordsDetail detailText, _
            "独立復旧ラッチの記録エラー: Err " & _
            CStr(operationErrorNumber) & " " & operationErrorDescription
    If Not latchReadSucceeded Or Not latchIsSet Then _
        AppendRecordsDetail detailText, _
            "独立復旧ラッチ=Trueを一意に読み返せません。"

    If Not TryKeepRecordsEventsDisabledExact(eventDetail) Then
        AppendRecordsDetail detailText, _
            "帳票要更新記録前のイベント停止を確認できません: " & eventDetail
        GoTo FAIL_CLOSED
    End If
    On Error Resume Next
    Err.Clear
    MarkOutputsDirty
    operationErrorNumber = Err.Number
    operationErrorDescription = Err.Description
    Err.Clear
    On Error GoTo 0
    outputsConfirmed = TryGetExactStateValue(STATE_OUTPUT_DIRTY, stateValue)
    outputsConfirmed = outputsConfirmed And _
                       (StrComp(stateValue, STATE_TRUE, vbBinaryCompare) = 0)
    If operationErrorNumber <> 0 Then _
        AppendRecordsDetail detailText, _
            "帳票要更新状態の記録エラー: Err " & _
            CStr(operationErrorNumber) & " " & operationErrorDescription
    If Not outputsConfirmed Then _
        AppendRecordsDetail detailText, _
            "帳票要更新状態=Trueを一意に読み返せません。"

    If Not TryKeepRecordsEventsDisabledExact(eventDetail) Then
        AppendRecordsDetail detailText, _
            "案件要復旧記録前のイベント停止を確認できません: " & eventDetail
        GoTo FAIL_CLOSED
    End If
    On Error Resume Next
    Err.Clear
    SetStateValue STATE_DATA_HEALTH, DATA_HEALTH_NEEDS_RECOVERY
    operationErrorNumber = Err.Number
    operationErrorDescription = Err.Description
    Err.Clear
    On Error GoTo 0
    healthConfirmed = TryGetExactStateValue(STATE_DATA_HEALTH, stateValue)
    healthConfirmed = healthConfirmed And _
                      (StrComp(stateValue, DATA_HEALTH_NEEDS_RECOVERY, _
                               vbBinaryCompare) = 0)
    If operationErrorNumber <> 0 Then _
        AppendRecordsDetail detailText, _
            "案件要復旧状態の記録エラー: Err " & _
            CStr(operationErrorNumber) & " " & operationErrorDescription

    If Not healthConfirmed Then
        AppendRecordsDetail detailText, _
            "案件要復旧状態を一意に読み返せません。"
        If Not TryKeepRecordsEventsDisabledExact(eventDetail) Then
            AppendRecordsDetail detailText, _
                "代替登録停止記録前のイベント停止を確認できません: " & eventDetail
            GoTo FAIL_CLOSED
        End If
        On Error Resume Next
        Err.Clear
        SetStateValue STATE_INPUT_DATE_CONFIG_SAFE, STATE_FALSE
        operationErrorNumber = Err.Number
        operationErrorDescription = Err.Description
        Err.Clear
        On Error GoTo 0
        dateStopConfirmed = _
            TryGetExactStateValue(STATE_INPUT_DATE_CONFIG_SAFE, stateValue)
        dateStopConfirmed = dateStopConfirmed And _
            (StrComp(stateValue, STATE_FALSE, vbBinaryCompare) = 0)
        If operationErrorNumber <> 0 Then _
            AppendRecordsDetail detailText, _
                "代替登録停止状態の記録エラー: Err " & _
                CStr(operationErrorNumber) & " " & operationErrorDescription
        If Not dateStopConfirmed Then _
            AppendRecordsDetail detailText, _
                "代替登録停止状態=Falseを一意に読み返せません。"

        '一時的な書込エラーから回復した可能性を考慮し、healthを再試行する。
        If Not TryKeepRecordsEventsDisabledExact(eventDetail) Then
            AppendRecordsDetail detailText, _
                "案件要復旧の再試行前にイベント停止を確認できません: " & eventDetail
            GoTo FAIL_CLOSED
        End If
        On Error Resume Next
        Err.Clear
        SetStateValue STATE_DATA_HEALTH, DATA_HEALTH_NEEDS_RECOVERY
        operationErrorNumber = Err.Number
        operationErrorDescription = Err.Description
        Err.Clear
        On Error GoTo 0
        If operationErrorNumber <> 0 Then _
            AppendRecordsDetail detailText, _
                "案件要復旧の再試行エラー: Err " & _
                CStr(operationErrorNumber) & " " & operationErrorDescription
        healthConfirmed = TryGetExactStateValue(STATE_DATA_HEALTH, stateValue)
        healthConfirmed = healthConfirmed And _
            (StrComp(stateValue, DATA_HEALTH_NEEDS_RECOVERY, _
                     vbBinaryCompare) = 0)
        If Not healthConfirmed Then _
            AppendRecordsDetail detailText, _
                "案件要復旧状態は再試行後も一意に確認できません。"
    End If

    'ラッチとhealthをここで独立に再読取し、片方だけの成功を認めない。
    confirmationDetail = vbNullString
    recoveryConfirmed = _
        RollbackRecoveryStateIsConfirmedExact( _
            confirmationDetail, dateSafeFallbackConfirmed)
    If Len(confirmationDetail) > 0 Then _
        AppendRecordsDetail detailText, confirmationDetail

    If Not TryKeepRecordsEventsDisabledExact(eventDetail) Then
        AppendRecordsDetail detailText, _
            "診断記録前のイベント停止を確認できません: " & eventDetail
        GoTo FAIL_CLOSED
    End If
    On Error Resume Next
    Err.Clear
    If recoveryConfirmed Then
        AddCheck "エラー", "ロールバック安全停止", _
                 "独立復旧ラッチと案件要復旧状態を確認しました。" & _
                 IIf(Len(detailText) > 0, " / " & detailText, vbNullString)
    Else
        AddCheck "エラー", "ロールバック安全状態不明", _
                 "復元不成立後の独立復旧ラッチと案件要復旧状態を" & _
                 "両方とも一意に確認できません。" & _
                 IIf(Len(detailText) > 0, " / " & detailText, vbNullString)
    End If
    operationErrorNumber = Err.Number
    operationErrorDescription = Err.Description
    Err.Clear
    On Error GoTo 0
    If operationErrorNumber <> 0 Then _
        AppendRecordsDetail detailText, _
            "診断記録エラー: Err " & CStr(operationErrorNumber) & _
            " " & operationErrorDescription

    '状態フラグだけではセル編集を止められないため、
    'キー割当を解除し、診断表示だけの隔離状態へ移行する。
    If Not TryKeepRecordsEventsDisabledExact(eventDetail) Then
        AppendRecordsDetail detailText, _
            "入力キー解除前のイベント停止を確認できません: " & eventDetail
        GoTo FAIL_CLOSED
    End If
    On Error Resume Next
    Err.Clear
    DisableInputKeys
    operationErrorNumber = Err.Number
    operationErrorDescription = Err.Description
    keysDisabled = (operationErrorNumber = 0)
    Err.Clear
    On Error GoTo 0
    If Not keysDisabled Then _
        AppendRecordsDetail detailText, _
            "入力キー解除エラー: Err " & CStr(operationErrorNumber) & _
            " " & operationErrorDescription

    If Not TryKeepRecordsEventsDisabledExact(eventDetail) Then
        AppendRecordsDetail detailText, _
            "診断隔離準備前のイベント停止を確認できません: " & eventDetail
        GoTo FAIL_CLOSED
    End If
    On Error Resume Next
    Err.Clear
    inspectionPrepared = PrepareFailedSetupForInspection()
    operationErrorNumber = Err.Number
    operationErrorDescription = Err.Description
    Err.Clear
    On Error GoTo 0
    If operationErrorNumber <> 0 Then _
        AppendRecordsDetail detailText, _
            "診断隔離準備エラー: Err " & CStr(operationErrorNumber) & _
            " " & operationErrorDescription
    If Not inspectionPrepared Then _
        AppendRecordsDetail detailText, _
            "診断隔離状態を一意に確認できません。"

    'PrepareFailedSetupForInspectionは開始時Falseを保存する契約だが、
    '呼出し後にも独立した読戻しでFalseを再確定する。
    eventsStopped = TryKeepRecordsEventsDisabledExact(eventDetail)
    If Not eventsStopped Then
        AppendRecordsDetail detailText, _
            "診断隔離準備後のイベント停止を確認できません: " & eventDetail
        GoTo FAIL_CLOSED
    End If

    '診断準備後もラッチとhealthの双方を再読取する。
    confirmationDetail = vbNullString
    recoveryConfirmed = _
        RollbackRecoveryStateIsConfirmedExact( _
            confirmationDetail, dateSafeFallbackConfirmed)
    If Len(confirmationDetail) > 0 Then _
        AppendRecordsDetail detailText, confirmationDetail
    outputsConfirmed = TryGetExactStateValue(STATE_OUTPUT_DIRTY, stateValue)
    outputsConfirmed = outputsConfirmed And _
        (StrComp(stateValue, STATE_TRUE, vbBinaryCompare) = 0)
    If Not outputsConfirmed Then _
        AppendRecordsDetail detailText, _
            "診断準備後の帳票要更新状態=Trueを一意に確認できません。"
    safeToRestoreEntry = recoveryConfirmed And outputsConfirmed And _
                         keysDisabled And inspectionPrepared
    If Not safeToRestoreEntry Then
        If recoveryConfirmed Then
            AppendRecordsDetail detailText, _
                "要復旧は確定しましたが、安全隔離の必須工程が未確定です。"
        Else
            AppendRecordsDetail detailText, _
                "独立復旧ラッチ=Trueと案件要復旧状態の双方を確定できません。"
        End If
        GoTo FAIL_CLOSED
    End If

    '今回のRecoveryが確定した後だけ、入れ子を含む捕捉済みApplication
    'leaseを全て閉じる。終端中は開始値=Trueへ一瞬も戻さない専用APIを使う。
    On Error Resume Next
    Err.Clear
    AppForceRestoreForRecoveryTerminal
    applicationErrorNumber = Err.Number
    applicationErrorSource = Err.Source
    applicationErrorDescription = Err.Description
    Err.Clear
    'Application収束の成否を分岐する前に、必ずfresh Falseを再確定する。
    eventsStopped = TryKeepRecordsEventsDisabledExact(eventDetail)
    On Error GoTo 0
    If applicationErrorNumber <> 0 Then
        AppendRecordsDetail detailText, _
            "Recovery確定後のApplication終端収束エラー: Err " & _
            CStr(applicationErrorNumber) & " " & applicationErrorDescription
        If Len(applicationErrorSource) > 0 Then _
            AppendRecordsDetail detailText, _
                "Application終端収束エラー発生元: " & applicationErrorSource
        If Not eventsStopped Then _
            AppendRecordsDetail detailText, _
                "Application終端収束エラー後のイベントFalse収束にも失敗しました: " & _
                eventDetail
        GoTo FAIL_CLOSED
    End If
    If Not eventsStopped Then
        AppendRecordsDetail detailText, _
            "Application終端収束後のイベントFalseを確認できません: " & _
            eventDetail
        GoTo FAIL_CLOSED
    End If

    On Error Resume Next
    Err.Clear
    applicationStateDetail = vbNullString
    applicationStateRestored = AppStateIsRestored(applicationStateDetail)
    operationErrorNumber = Err.Number
    operationErrorDescription = Err.Description
    Err.Clear
    'Application読戻し後も、判定より先にfresh Falseを再確定する。
    eventsStopped = TryKeepRecordsEventsDisabledExact(eventDetail)
    On Error GoTo 0
    If operationErrorNumber <> 0 Then
        AppendRecordsDetail detailText, _
            "Application終端状態の読戻しエラー: Err " & _
            CStr(operationErrorNumber) & " " & operationErrorDescription
        If Not eventsStopped Then _
            AppendRecordsDetail detailText, _
                "Application読戻しエラー後のイベントFalse収束にも失敗しました: " & _
                eventDetail
        GoTo FAIL_CLOSED
    End If
    If Not applicationStateRestored Then
        AppendRecordsDetail detailText, _
            "Application終端状態を一意に確認できません: " & _
            applicationStateDetail
        If Not eventsStopped Then _
            AppendRecordsDetail detailText, _
                "Application状態未確認後のイベントFalse収束にも失敗しました: " & _
                eventDetail
        GoTo FAIL_CLOSED
    End If
    If Not eventsStopped Then
        AppendRecordsDetail detailText, _
            "Application確認後の最終イベントFalseを確認できません: " & _
            eventDetail
        GoTo FAIL_CLOSED
    End If
    AppendRecordsDetail detailText, _
        "Recovery状態、Application終端状態、最終イベントFalseを確認しました。"
    Err.Raise vbObjectError + 3599, _
              "RollbackRecoveryTerminal/EnforceRollbackRecoveryState", _
              detailText

FAIL_CLOSED:
    '要復旧の双方確認または安全隔離が未確定なら、
    '開始値=Trueであっても再有効化せずFalseへ収束させる。
    If Not recoveryConfirmed Then _
        AppendRecordsDetail detailText, _
            "復旧ラッチ=Trueと案件要復旧状態の双方確認は未完了です。"
    If TryKeepRecordsEventsDisabledExact(convergenceDetail) Then
        AppendRecordsDetail detailText, _
            "安全停止のためExcelイベントをFalseへ収束させました。"
    Else
        AppendRecordsDetail detailText, _
            "ExcelイベントのFalse収束にも失敗し、" & _
            "Excelイベント状態と案件の安全状態は不明です: " & _
            convergenceDetail
    End If
    Err.Raise vbObjectError + 3599, _
              "RollbackRecoveryTerminal/EnforceRollbackRecoveryState", _
              detailText
End Sub

Public Sub MarkOutputsClean()
    '最後の1書込みまでOUTPUT_DIRTY=Trueを保ち、中途失敗で旧帳票をcleanにしない。
    Dim stateValue As String, buildStamp As String
    SetStateValue STATE_ANALYSIS_REVIEW_DIRTY, STATE_FALSE
    If Not TryGetExactStateValue(STATE_ANALYSIS_REVIEW_DIRTY, stateValue) Or _
       stateValue <> STATE_FALSE Then _
        Err.Raise vbObjectError + 3490, "MarkOutputsClean", _
                  "分析確認の更新済み状態を一意に確認できません。"
    buildStamp = Format$(Now, "yyyy/m/d h:mm:ss")
    SetStateValue STATE_LAST_BUILD, buildStamp
    If Not TryGetExactStateValue(STATE_LAST_BUILD, stateValue) Or _
       StrComp(stateValue, buildStamp, vbBinaryCompare) <> 0 Then _
        Err.Raise vbObjectError + 3491, "MarkOutputsClean", _
                  "最終帳票更新時刻を一意に確認できません。"
    SetStateValue STATE_OUTPUT_DIRTY, STATE_FALSE
    If Not TryGetExactStateValue(STATE_OUTPUT_DIRTY, stateValue) Or _
       stateValue <> STATE_FALSE Then _
        Err.Raise vbObjectError + 3492, "MarkOutputsClean", _
                  "帳票更新済み状態を一意に確認できません。"
    'キャプション更新は表示補助。完了状態確定後のUI失敗でデータを失敗扱いにしない。
    On Error Resume Next
    RefreshMainActionCaption
    On Error GoTo 0
End Sub

Public Function CanonicalAccountKey(ByVal bankName As String, ByVal branchName As String, _
                                    ByVal personName As String, ByVal accountType As String, _
                                    ByVal accountNo As String) As String
    CanonicalAccountKey = NormalizeIdentityPart(bankName) & Chr$(30) & _
                          NormalizeIdentityPart(branchName) & Chr$(30) & _
                          NormalizeIdentityPart(personName) & Chr$(30) & _
                          NormalizeIdentityPart(accountType) & Chr$(30) & _
                          NormalizeAccountNumberForKey(accountNo)
End Function

Public Function CanonicalAccountLocatorKey(ByVal bankName As String, ByVal branchName As String, _
                                           ByVal accountType As String, ByVal accountNo As String) As String
    '名義の誤記・改姓だけで同じ実口座を別口座として登録しないため、名義を除いた所在地キーも持つ。
    CanonicalAccountLocatorKey = NormalizeIdentityPart(bankName) & Chr$(30) & _
                                 NormalizeIdentityPart(branchName) & Chr$(30) & _
                                 NormalizeIdentityPart(accountType) & Chr$(30) & _
                                 NormalizeAccountNumberForKey(accountNo)
End Function

Private Function NormalizeIdentityPart(ByVal valueText As String) As String
    Dim s As String
    s = Trim$(CellText(valueText))
    s = Replace(s, " ", "")
    s = Replace(s, "　", "")
    NormalizeIdentityPart = UCase$(s)
End Function

Private Function NormalizeAccountNumberForKey(ByVal valueText As String) As String
    Dim s As String
    s = NormalizeAccountHyphen(CellText(valueText))
    On Error Resume Next
    s = StrConv(s, vbNarrow)
    On Error GoTo 0
    s = Replace(s, " ", "")
    s = Replace(s, "　", "")
    NormalizeAccountNumberForKey = UCase$(s)
End Function

Public Function FindAccountRowByID(ByVal accountID As String) As Long
    Dim ws As Worksheet
    Dim lastR As Long, r As Long, rowCount As Long
    Dim idData As Variant
    If Len(CellText(accountID)) = 0 Then Exit Function
    If Not SheetExists(SH_WORK_ACCOUNT) Then Exit Function
    Set ws = GetSheet(SH_WORK_ACCOUNT)
    lastR = LastUsedRowInSheet(ws)
    If lastR < 2 Then Exit Function
    rowCount = lastR - 1
    idData = ws.Range(ws.Cells(2, ACC_COL_ID), ws.Cells(lastR, ACC_COL_ID)).Value2
    For r = 1 To rowCount
        If CellText(RecordsColumnValue(idData, r, rowCount)) = accountID Then
            FindAccountRowByID = r + 1
            Exit Function
        End If
    Next r
End Function

Public Function FindAccountIDByComposite(ByVal bankName As String, ByVal branchName As String, _
                                         ByVal personName As String, ByVal accountType As String, _
                                         ByVal accountNo As String, _
                                         Optional ByVal excludeAccountID As String = "") As String
    Dim ws As Worksheet
    Dim lastR As Long, r As Long
    Dim targetKey As String, rowKey As String, rowID As String
    Dim accountData As Variant
    If Not SheetExists(SH_WORK_ACCOUNT) Then Exit Function
    targetKey = CanonicalAccountKey(bankName, branchName, personName, accountType, accountNo)
    Set ws = GetSheet(SH_WORK_ACCOUNT)
    lastR = LastUsedRowInSheet(ws)
    If lastR < 2 Then Exit Function
    accountData = ws.Range(ws.Cells(2, ACC_COL_ID), ws.Cells(lastR, ACC_COL_NO)).Value2
    For r = 1 To UBound(accountData, 1)
        rowID = CellText(accountData(r, ACC_COL_ID))
        If rowID <> excludeAccountID Then
            rowKey = CanonicalAccountKey(CellText(accountData(r, ACC_COL_BANK)), _
                                         CellText(accountData(r, ACC_COL_BRANCH)), _
                                         CellText(accountData(r, ACC_COL_PERSON)), _
                                         CellText(accountData(r, ACC_COL_TYPE)), _
                                         CellText(accountData(r, ACC_COL_NO)))
            If rowKey = targetKey Then
                FindAccountIDByComposite = rowID
                Exit Function
            End If
        End If
    Next r
End Function

Public Function FindAccountIDByLocator(ByVal bankName As String, ByVal branchName As String, _
                                       ByVal accountType As String, ByVal accountNo As String, _
                                       Optional ByVal excludeAccountID As String = "") As String
    Dim ws As Worksheet
    Dim lastR As Long, r As Long
    Dim targetKey As String, rowKey As String, rowID As String
    Dim accountData As Variant
    If Not SheetExists(SH_WORK_ACCOUNT) Then Exit Function
    targetKey = CanonicalAccountLocatorKey(bankName, branchName, accountType, accountNo)
    Set ws = GetSheet(SH_WORK_ACCOUNT)
    lastR = LastUsedRowInSheet(ws)
    If lastR < 2 Then Exit Function
    accountData = ws.Range(ws.Cells(2, ACC_COL_ID), ws.Cells(lastR, ACC_COL_NO)).Value2
    For r = 1 To UBound(accountData, 1)
        rowID = CellText(accountData(r, ACC_COL_ID))
        If rowID <> excludeAccountID Then
            rowKey = CanonicalAccountLocatorKey(CellText(accountData(r, ACC_COL_BANK)), _
                                                CellText(accountData(r, ACC_COL_BRANCH)), _
                                                CellText(accountData(r, ACC_COL_TYPE)), _
                                                CellText(accountData(r, ACC_COL_NO)))
            If rowKey = targetKey Then
                FindAccountIDByLocator = rowID
                Exit Function
            End If
        End If
    Next r
End Function

Public Sub UpsertAccountMaster(ByVal accountID As String, ByVal transferID As String, _
                               ByVal bankName As String, ByVal branchName As String, _
                               ByVal personName As String, ByVal relationshipText As String, _
                               ByVal accountType As String, ByVal accountNo As String, _
                               ByVal openDate As Variant, ByVal closeDate As Variant, _
                               ByVal personID As String, ByVal sourceText As String, _
                               Optional ByVal knownRow As Long = 0)
    Dim ws As Worksheet
    Dim r As Long
    Dim existingID As String
    Dim updatedAt As Date
    Dim expectedData(1 To 1, 1 To ACC_COL_TRANSFER_ID) As Variant
    Dim writtenRange As Range
    Set ws = GetSheet(SH_WORK_ACCOUNT)
    If knownRow > 0 Then
        If knownRow < 2 Or knownRow > ws.Rows.Count Then _
            Err.Raise vbObjectError + 3426, "UpsertAccountMaster", "口座マスタの書込位置が不正です。"
        existingID = CellText(ws.Cells(knownRow, ACC_COL_ID).Value)
        If Len(existingID) > 0 And StrComp(existingID, accountID, vbTextCompare) <> 0 Then _
            Err.Raise vbObjectError + 3427, "UpsertAccountMaster", "口座マスタの書込位置に別の口座IDがあります。"
        r = knownRow
    Else
        r = FindAccountRowByID(accountID)
    End If
    If r = 0 Then
        r = RequireRecordsAppendRow(ws, "口座マスタ")
    End If
    ws.Range(ws.Cells(r, ACC_COL_ID), ws.Cells(r, ACC_COL_NO)).NumberFormatLocal = "@"
    ws.Range(ws.Cells(r, ACC_COL_PERSON_ID), ws.Cells(r, ACC_COL_SOURCE)).NumberFormatLocal = "@"
    ws.Cells(r, ACC_COL_UPDATED_AT).NumberFormatLocal = "yyyy/m/d h:mm:ss"
    ws.Cells(r, ACC_COL_TRANSFER_ID).NumberFormatLocal = "@"
    updatedAt = Now
    '保存後のValue2型へ先に正規化し、空文字・日付・数値の環境依存変換を排除する。
    '全列を一括書込みした後に同じ配列を読戻し、部分書込みを成功扱いしない。
    expectedData(1, ACC_COL_ID) = AccountMasterExpectedValue2(accountID)
    expectedData(1, ACC_COL_BANK) = AccountMasterExpectedValue2(bankName)
    expectedData(1, ACC_COL_BRANCH) = AccountMasterExpectedValue2(branchName)
    expectedData(1, ACC_COL_PERSON) = AccountMasterExpectedValue2(personName)
    expectedData(1, ACC_COL_RELATIONSHIP) = AccountMasterExpectedValue2(relationshipText)
    expectedData(1, ACC_COL_TYPE) = AccountMasterExpectedValue2(accountType)
    expectedData(1, ACC_COL_NO) = AccountMasterExpectedValue2(accountNo)
    expectedData(1, ACC_COL_OPEN_DATE) = AccountMasterExpectedValue2(openDate)
    expectedData(1, ACC_COL_CLOSE_DATE) = AccountMasterExpectedValue2(closeDate)
    expectedData(1, ACC_COL_PERSON_ID) = AccountMasterExpectedValue2(personID)
    expectedData(1, ACC_COL_SOURCE) = AccountMasterExpectedValue2(sourceText)
    expectedData(1, ACC_COL_UPDATED_AT) = AccountMasterExpectedValue2(updatedAt)
    expectedData(1, ACC_COL_TRANSFER_ID) = AccountMasterExpectedValue2(transferID)
    Set writtenRange = ws.Range(ws.Cells(r, 1), ws.Cells(r, ACC_COL_TRANSFER_ID))
    writtenRange.Value2 = expectedData
    If Not RangeValue2MatchesMatrixStrict(writtenRange, expectedData, 1, ACC_COL_TRANSFER_ID) Then _
        Err.Raise vbObjectError + 3428, "UpsertAccountMaster", _
                  "口座マスタの書込読戻しが全列・型で一致しません: " & accountID
End Sub

Private Function RequireRecordsAppendRow(ByVal ws As Worksheet, _
                                         ByVal storeLabel As String) As Long
    '追記位置の検索失敗を空シートと誤認して2行目を上書きしない。
    Dim lastUsedRow As Long
    If ws Is Nothing Then _
        Err.Raise vbObjectError + 3430, "RequireRecordsAppendRow", _
                  storeLabel & "を取得できません。"
    If Not TryGetLastUsedRowInSheet(ws, lastUsedRow) Then _
        Err.Raise vbObjectError + 3431, "RequireRecordsAppendRow(" & ws.Name & ")", _
                  storeLabel & "の最終行を安全に確認できないため、追記を中止しました。"
    If lastUsedRow < 1 Then lastUsedRow = 1
    If lastUsedRow >= ws.Rows.Count Then _
        Err.Raise vbObjectError + 3421, "RequireRecordsAppendRow(" & ws.Name & ")", _
                  storeLabel & "がExcelの行上限に達しています。"
    RequireRecordsAppendRow = lastUsedRow + 1
    If RequireRecordsAppendRow < 2 Then RequireRecordsAppendRow = 2
End Function

Private Function AccountMasterExpectedValue2(ByVal valueIn As Variant) As Variant
    'Range.Value2で読戻したときの保存型へ正規化する。
    If IsError(valueIn) Or IsNull(valueIn) Then _
        Err.Raise vbObjectError + 3429, "AccountMasterExpectedValue2", _
                  "口座マスタへ保存できない値があります。"
    If IsEmpty(valueIn) Then
        AccountMasterExpectedValue2 = Empty
    ElseIf VarType(valueIn) = vbString And Len(CStr(valueIn)) = 0 Then
        AccountMasterExpectedValue2 = Empty
    ElseIf VarType(valueIn) = vbDate Then
        AccountMasterExpectedValue2 = CDbl(valueIn)
    ElseIf VarType(valueIn) <> vbString And VarType(valueIn) <> vbBoolean And IsNumeric(valueIn) Then
        AccountMasterExpectedValue2 = CDbl(valueIn)
    Else
        AccountMasterExpectedValue2 = valueIn
    End If
End Function

Public Sub DeleteAccountRecords(ByVal accountID As String, Optional ByVal deleteMaster As Boolean = False)
    Dim r As Long
    DeleteRowsForAccount GetSheet(SH_WORK_TX), WORK_TX_COL_ACCOUNT_ID, accountID
    DeleteRowsForAccount GetSheet(SH_WORK_BAL), WORK_BAL_COL_ACCOUNT_ID, accountID
    If deleteMaster Then
        r = FindAccountRowByID(accountID)
        If r > 0 Then GetSheet(SH_WORK_ACCOUNT).Rows(r).Delete
    End If
End Sub

Private Sub DeleteRowsForAccount(ByVal ws As Worksheet, ByVal idCol As Long, ByVal accountID As String)
    If ws Is Nothing Or Len(accountID) = 0 Then Exit Sub
    If ws.Name = SH_WORK_TX Then
        CompactDeleteDataRows ws, WORK_TX_COL_PERSON_ID, idCol, accountID
    ElseIf ws.Name = SH_WORK_BAL Then
        CompactDeleteDataRows ws, WORK_BAL_COL_PERSON_ID, idCol, accountID
    Else
        Err.Raise vbObjectError + 3424, "DeleteRowsForAccount", "対象外の内部シートです: " & ws.Name
    End If
End Sub

Public Function CountAccountRecords(ByVal ws As Worksheet, ByVal idCol As Long, ByVal accountID As String, _
                                    Optional ByVal recordType As String = "") As Long
    Dim lastR As Long, lastCol As Long, r As Long
    Dim sourceData As Variant
    If ws Is Nothing Then Exit Function
    lastR = LastUsedRowInSheet(ws)
    If lastR < 2 Then Exit Function
    lastCol = idCol
    If Len(recordType) > 0 And ws.Name = SH_WORK_TX Then lastCol = Application.Max(lastCol, WORK_TX_COL_RECORD_TYPE)
    sourceData = ws.Range(ws.Cells(2, 1), ws.Cells(lastR, lastCol)).Value2
    For r = 1 To UBound(sourceData, 1)
        If CellText(sourceData(r, idCol)) = accountID Then
            If Len(recordType) = 0 Then
                CountAccountRecords = CountAccountRecords + 1
            ElseIf ws.Name = SH_WORK_TX And CellText(sourceData(r, WORK_TX_COL_RECORD_TYPE)) = recordType Then
                CountAccountRecords = CountAccountRecords + 1
            End If
        End If
    Next r
End Function

Public Sub OpenRegisteredAccounts()
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim entryEvents As Boolean, entryEventsCaptured As Boolean
    Dim eventsStopped As Boolean, recoveryConfirmed As Boolean
    Dim eventDetail As String, cleanupDetail As String
    Dim leaseRestored As Boolean, applicationLeaseStarted As Boolean
    Dim localSafetyConfirmed As Boolean, recoveryAttempted As Boolean
    Dim recoveryEnforceFailed As Boolean
    If Not RequireToolReady() Then Exit Sub
    If Not RequireInternalStoresSafeForWrite(False, False) Then Exit Sub
    On Error GoTo EH
    If Not TryGetRecordsEnableEvents(entryEvents, eventDetail) Then _
        Err.Raise vbObjectError + 3441, "OpenRegisteredAccounts", _
                  "Excelイベントの開始状態を取得できません: " & eventDetail
    entryEventsCaptured = True
    AppBegin "登録済み口座を表示しています..."
    applicationLeaseStarted = True
    If Not TryKeepRecordsEventsDisabledExact(eventDetail) Then _
        Err.Raise vbObjectError + 3441, "OpenRegisteredAccounts", _
                  "一覧表示前にExcelイベントを停止できません: " & eventDetail
    BuildRegisteredAccountsSheet True, True
    If Not TryKeepRecordsEventsDisabledExact(eventDetail) Then _
        Err.Raise vbObjectError + 3441, "OpenRegisteredAccounts", _
                  "一覧表示後にExcelイベント停止を維持できません: " & eventDetail
    DisableInputKeys
    localSafetyConfirmed = True
    leaseRestored = FinalizeRecordsApplicationLease( _
                        "登録済み口座一覧の表示", _
                        applicationLeaseStarted, entryEventsCaptured, entryEvents, _
                        localSafetyConfirmed, True, _
                        recoveryAttempted, recoveryEnforceFailed, _
                        recoveryConfirmed, cleanupDetail)
    If Not leaseRestored Then
        MsgBox "登録済み口座一覧は表示しましたが、Excelの開始状態を安全に復元できませんでした。" & _
               vbCrLf & cleanupDetail, vbCritical, _
               "一覧表示後のExcel状態を確認できません"
    End If
    Exit Sub
EH:
    errorNumber = Err.Number
    errorSource = Err.Source
    errorDescription = Err.Description
    If IsRecordsRecoveryHardBarrier(errorNumber, errorSource) Then
        Call TryKeepRecordsEventsDisabledExact(eventDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    eventsStopped = False
    If entryEventsCaptured Then _
        eventsStopped = TryKeepRecordsEventsDisabledExact(eventDetail)
    If recoveryEnforceFailed Then
        AppendRecordsDetail cleanupDetail, _
            "Recovery設定自体が失敗したため、入力キー・診断・状態へ書き込まず、" & _
            "ExcelイベントをFalseに維持しました。"
    ElseIf eventsStopped Then
        On Error Resume Next
        Err.Clear
        DisableInputKeys
        If Err.Number <> 0 Then _
            AppendRecordsDetail cleanupDetail, _
                "入力キー停止エラー: Err " & CStr(Err.Number) & _
                " " & Err.Description
        Err.Clear
        On Error GoTo 0
    Else
        AppendRecordsDetail cleanupDetail, _
            "失敗復旧前のExcelイベント停止を確認できないため、" & _
            "シート・状態・キー設定へ書き込んでいません。" & _
            IIf(Len(eventDetail) > 0, " " & eventDetail, vbNullString)
    End If
    leaseRestored = FinalizeRecordsApplicationLease( _
                        "登録済み口座一覧の表示失敗復旧", _
                        applicationLeaseStarted, entryEventsCaptured, entryEvents, _
                        False, eventsStopped, _
                        recoveryAttempted, recoveryEnforceFailed, _
                        recoveryConfirmed, cleanupDetail)
    MsgBox "登録済み口座を表示できませんでした。" & vbCrLf & _
           "Err " & errorNumber & ": " & errorDescription & _
           IIf(Len(cleanupDetail) > 0, _
               vbCrLf & "復旧確認: " & cleanupDetail, vbNullString), _
           vbExclamation
End Sub

Public Sub BuildRegisteredAccountsSheet( _
        Optional ByVal activateAfter As Boolean = False, _
        Optional ByVal capacityAlreadyConfirmed As Boolean = False)
    Dim ws As Worksheet, wsAcc As Worksheet, wsTx As Worksheet, wsBal As Worksheet
    Dim lastR As Long, r As Long, outR As Long, lastTx As Long, lastBal As Long, clearLastR As Long
    Dim accountCount As Long
    Dim accountID As String
    Dim txCounts As Object, balCounts As Object
    Dim txData As Variant, balData As Variant, accountData As Variant, outputData() As Variant
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim containmentDetail As String, recoveryDetail As String, containmentSuffix As String
    Dim mutationStarted As Boolean
    Dim containmentEventsStopped As Boolean, containmentRecoveryConfirmed As Boolean
    Dim containmentRecoveryAttempted As Boolean
    Dim containmentEnforceFailed As Boolean
    Dim containmentEventDetail As String
    Dim containmentRecoveryErrorNumber As Long
    Dim containmentRecoveryErrorSource As String
    Dim containmentRecoveryErrorDescription As String

    On Error GoTo EH
    If Not capacityAlreadyConfirmed Then
        If Not RequireCorePersonIntegrityCapacity( _
                   "登録済み口座一覧の生成", False, False) Then _
            Err.Raise 18, "BuildRegisteredAccountsSheet", _
                      "利用者が登録済み口座一覧の容量確認を取り消しました。"
    End If
    Set ws = GetOrCreateSheet(SH_REGISTERED_ACCOUNTS, False)
    Set wsAcc = GetSheet(SH_WORK_ACCOUNT)
    Set wsTx = GetSheet(SH_WORK_TX)
    Set wsBal = GetSheet(SH_WORK_BAL)
    Set txCounts = CreateObject("Scripting.Dictionary")
    Set balCounts = CreateObject("Scripting.Dictionary")
    txCounts.CompareMode = vbTextCompare
    balCounts.CompareMode = vbTextCompare
    lastTx = LastUsedRowInSheet(wsTx)
    If lastTx >= 2 Then
        txData = wsTx.Range(wsTx.Cells(2, WORK_TX_COL_ACCOUNT_ID), _
                            wsTx.Cells(lastTx, WORK_TX_COL_RECORD_TYPE)).Value2
        For r = 1 To UBound(txData, 1)
            If CellText(txData(r, WORK_TX_COL_RECORD_TYPE - WORK_TX_COL_ACCOUNT_ID + 1)) = RECORD_TRANSACTION Then
                accountID = CellText(txData(r, 1))
                If Len(accountID) > 0 Then txCounts(accountID) = CLng(DictionaryLong(txCounts, accountID)) + 1
            End If
        Next r
    End If
    lastBal = LastUsedRowInSheet(wsBal)
    If lastBal >= 2 Then
        balData = wsBal.Range(wsBal.Cells(2, WORK_BAL_COL_ACCOUNT_ID), _
                              wsBal.Cells(lastBal, WORK_BAL_COL_PERSON_ID)).Value2
        For r = 1 To UBound(balData, 1)
            accountID = CellText(balData(r, 1))
            If Len(accountID) > 0 Then balCounts(accountID) = CLng(DictionaryLong(balCounts, accountID)) + 1
        Next r
    End If
    lastR = LastUsedRowInSheet(wsAcc)
    outR = 4
    If lastR >= 2 Then
        accountCount = lastR - 1
        If accountCount > ws.Rows.Count - 3 Then _
            Err.Raise vbObjectError + 3422, "BuildRegisteredAccountsSheet", _
                      "登録済み口座一覧がExcelの行上限を超えます。案件を分割してください。"
        accountData = wsAcc.Range(wsAcc.Cells(2, 1), wsAcc.Cells(lastR, ACC_COL_TRANSFER_ID)).Value2
        ReDim outputData(1 To accountCount, 1 To 13)
        For r = 1 To accountCount
            accountID = CellText(accountData(r, ACC_COL_ID))
            If Len(accountID) = 0 Then _
                Err.Raise vbObjectError + 3423, "BuildRegisteredAccountsSheet", _
                          "口座マスタの口座IDが空欄です（W_口座 " & CStr(r + 1) & "行）。"
            outputData(r, 1) = r
            outputData(r, 2) = accountData(r, ACC_COL_PERSON)
            outputData(r, 3) = accountData(r, ACC_COL_RELATIONSHIP)
            outputData(r, 4) = accountData(r, ACC_COL_BANK)
            outputData(r, 5) = accountData(r, ACC_COL_BRANCH)
            outputData(r, 6) = accountData(r, ACC_COL_TYPE)
            outputData(r, 7) = accountData(r, ACC_COL_NO)
            outputData(r, 8) = accountData(r, ACC_COL_OPEN_DATE)
            outputData(r, 9) = accountData(r, ACC_COL_CLOSE_DATE)
            outputData(r, 10) = DictionaryLong(txCounts, accountID)
            outputData(r, 11) = DictionaryLong(balCounts, accountID)
            outputData(r, 12) = accountData(r, ACC_COL_UPDATED_AT)
            outputData(r, 13) = accountID
        Next r
        outR = 4 + accountCount
    End If

    '内部3表の全読込・件数集計・出力配列検証が終わるまで、旧一覧を変更しない。
    mutationStarted = True
    ws.Visible = xlSheetVisible
    ws.Unprotect Password:=TOOL_PASSWORD
    DeleteToolShapesVerified ws, False
    clearLastR = Application.Max(4, LastUsedRowInSheet(ws))
    ws.Range("A1:Q" & CStr(clearLastR)).UnMerge
    ws.Range("A1:Q" & CStr(clearLastR)).Clear
    If ws.AutoFilterMode Then ws.AutoFilterMode = False

    MergeAndFormat ws.Range("A1:L1"), _
                   "登録済み口座　｜　行をダブルクリックすると訂正画面を開きます"
    ws.Range("A1:L1").Font.Size = 16
    ws.Range("A1:L1").Font.Bold = True
    ws.Range("A1:L1").Font.Color = RGB(30, 64, 175)
    ws.Range("A1:L1").Interior.Color = RGB(239, 246, 255)
    SetRowValues ws.Range("A3"), _
        Array("No", "氏名", "続柄", "銀行名", "支店名", "科目", "口座番号", _
              "開設日", "解約日", "取引件数", "残高件数", "更新日時", "口座ID")
    FormatOutputHeader ws.Range("A3:M3")
    If accountCount > 0 Then
        ws.Range(ws.Cells(4, 1), ws.Cells(3 + accountCount, 13)).Value2 = _
            outputData
        If Not RangeValue2MatchesMatrixStrict( _
                   ws.Range(ws.Cells(4, 1), _
                            ws.Cells(3 + accountCount, 13)), _
                   outputData, accountCount, 13) Then _
            Err.Raise vbObjectError + 3435, "BuildRegisteredAccountsSheet", _
                      "登録済み口座一覧を書込み後に型または値が一致しません。"
    End If

    With ws.Range("A1:M" & CStr(Application.Max(4, outR - 1)))
        .Font.Name = "Yu Gothic UI"
    End With
    ws.Range("A4:M" & CStr(Application.Max(4, outR - 1))).Font.Size = 10

    ws.Columns("A:A").ColumnWidth = 6
    ws.Columns("B:B").ColumnWidth = 15
    ws.Columns("C:C").ColumnWidth = 10
    ws.Columns("D:D").ColumnWidth = 18
    ws.Columns("E:E").ColumnWidth = 15
    ws.Columns("F:F").ColumnWidth = 13
    ws.Columns("G:G").ColumnWidth = 16
    ws.Columns("H:I").ColumnWidth = 11
    ws.Columns("J:K").ColumnWidth = 9
    ws.Columns("L:L").ColumnWidth = 16
    ws.Columns("M:M").Hidden = True
    ws.Rows(1).RowHeight = 30
    ws.Rows(2).RowHeight = 38
    ws.Rows(3).RowHeight = 30
    ws.Range("B4:G" & CStr(Application.Max(4, outR - 1))).NumberFormatLocal = "@"
    ws.Range("M4:M" & CStr(Application.Max(4, outR - 1))).NumberFormatLocal = "@"
    ws.Range("H4:I" & CStr(Application.Max(4, outR - 1))).NumberFormatLocal = "yyyy/m/d"
    ws.Range("L4:L" & CStr(Application.Max(4, outR - 1))).NumberFormatLocal = "yyyy/m/d h:mm"
    If outR > 4 Then
        With ws.Range("A4:L" & CStr(outR - 1))
            .Borders.LineStyle = xlContinuous
            .Borders.Color = RGB(226, 232, 240)
            .VerticalAlignment = xlCenter
            .RowHeight = 23
        End With
        With ws.Range("A4:L" & CStr(outR - 1)).FormatConditions
            .Delete
            .Add Type:=xlExpression, Formula1:="=MOD(ROW(),2)=0"
            .Item(.Count).Interior.Color = RGB(248, 250, 252)
        End With
        ws.Range("A3:M" & CStr(outR - 1)).AutoFilter
    Else
        MergeAndFormat ws.Range("A4:L4"), "登録済み口座はありません。"
        ws.Range("A4:L4").HorizontalAlignment = xlCenter
        ws.Range("A4:L4").Interior.Color = RGB(248, 250, 252)
    End If

    BuildRegisteredAccountsPanel ws
    ws.ScrollArea = "A1:M" & CStr(Application.Max(50, outR + 20))
    ProtectRegisteredAccountsSheet True
    SafeFreezeSheetAt ws, "A4", 90
    If activateAfter Then
        ws.Activate
        If outR > 4 Then ws.Range("A4").Select Else ws.Range("A3").Select
    Else
        ws.Visible = xlSheetHidden
    End If
    Exit Sub

EH:
    errorNumber = Err.Number
    errorSource = Err.Source
    errorDescription = Err.Description
    If IsRecordsRecoveryHardBarrier(errorNumber, errorSource) Then
        containmentEventsStopped = _
            TryKeepRecordsEventsDisabledExact(containmentEventDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    If Not mutationStarted Then _
        Err.Raise errorNumber, "BuildRegisteredAccountsSheet", errorDescription
    On Error Resume Next
    ContainRegisteredAccountsBuildFailure ws, containmentDetail
    If Len(containmentDetail) > 0 Then
        containmentEventsStopped = _
            TryKeepRecordsEventsDisabledExact(containmentEventDetail)
        If containmentEventsStopped Then
            Err.Clear
            Call TryEnterRecordsRecoveryState( _
                     "登録済み口座一覧の隔離失敗", _
                     containmentEventsStopped, containmentRecoveryConfirmed, _
                     containmentRecoveryAttempted, containmentEnforceFailed, _
                     recoveryDetail)
            containmentRecoveryErrorNumber = Err.Number
            containmentRecoveryErrorSource = Err.Source
            containmentRecoveryErrorDescription = Err.Description
            Err.Clear
            If IsRecordsRecoveryHardBarrier( _
                   containmentRecoveryErrorNumber, _
                   containmentRecoveryErrorSource) Then
                containmentEventsStopped = _
                    TryKeepRecordsEventsDisabledExact(containmentEventDetail)
                On Error GoTo 0
                Err.Raise containmentRecoveryErrorNumber, _
                          containmentRecoveryErrorSource, _
                          containmentRecoveryErrorDescription
            End If
        End If
        If Not containmentRecoveryConfirmed Then _
            AppendRecordsDetail containmentDetail, _
                                "一覧隔離失敗後の要復旧状態を一意に確認できません。" & _
                                IIf(Len(containmentEventDetail) > 0, _
                                    " " & containmentEventDetail, vbNullString)
        If Len(recoveryDetail) > 0 Then AppendRecordsDetail containmentDetail, recoveryDetail
        containmentSuffix = " / 一覧の安全な隔離を完了できません: " & containmentDetail
    ElseIf Not ws Is Nothing Then
        containmentSuffix = " / 未完成の一覧は保護して非表示にしました。"
    End If
    On Error GoTo 0
    If containmentRecoveryAttempted Then
        containmentEventsStopped = _
            TryKeepRecordsEventsDisabledExact(containmentEventDetail)
        Err.Raise RECORDS_RECOVERY_ENFORCE_ERROR, _
                  RECORDS_RECOVERY_HARD_BARRIER_SOURCE & _
                      "BuildRegisteredAccountsSheet/ContainmentRecovery", _
                  errorDescription & containmentSuffix
    End If
    Err.Raise errorNumber, "BuildRegisteredAccountsSheet", _
              errorDescription & containmentSuffix
End Sub

Private Sub ContainRegisteredAccountsBuildFailure(ByVal ws As Worksheet, _
                                                  ByRef detailText As String)
    '再構築途中の一覧を利用者へ見せず、図形を含めて必ず保護する。
    Dim fallbackSheet As Worksheet
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    Err.Clear
    If ws Is ActiveSheet Then
        If SheetExists(SH_INPUT) Then
            Set fallbackSheet = GetSheet(SH_INPUT)
            fallbackSheet.Visible = xlSheetVisible
            fallbackSheet.Activate
        End If
        If Err.Number <> 0 Or ws Is ActiveSheet Then
            AppendRecordsDetail detailText, _
                                "未完成一覧から安全な画面へ移動できません: Err " & _
                                CStr(Err.Number) & " " & Err.Description
            Err.Clear
        End If
    End If

    EmergencyProtectToolSheet ws
    If Not ws.ProtectContents Or Not ws.ProtectDrawingObjects Then
        AppendRecordsDetail detailText, "未完成一覧を保護できません。"
    End If
    Err.Clear
    ws.Visible = xlSheetHidden
    If Err.Number <> 0 Or ws.Visible = xlSheetVisible Then
        AppendRecordsDetail detailText, _
                            "未完成一覧を非表示にできません: Err " & _
                            CStr(Err.Number) & " " & Err.Description
        Err.Clear
    End If
    On Error GoTo 0
End Sub

Public Sub ProtectRegisteredAccountsSheet(Optional ByVal raiseOnError As Boolean = False)
    Dim ws As Worksheet
    Dim lastR As Long
    Dim workbookWasSaved As Boolean, emergencyProtected As Boolean
    Dim savedReadback As Boolean, recoveryStateConfirmed As Boolean
    Dim dateSafeFallbackConfirmed As Boolean
    Dim entryEvents As Boolean, entryEventsCaptured As Boolean
    Dim eventsStopped As Boolean, mutationStarted As Boolean
    Dim entryEventsRestored As Boolean, protectionSafetyConfirmed As Boolean
    Dim applicationStateSafe As Boolean, stateProblems As String
    Dim recoveryAttempted As Boolean, recoveryEnforceFailed As Boolean
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim emergencyErrorNumber As Long, emergencyErrorDescription As String
    Dim emergencyReadErrorNumber As Long, emergencyReadErrorDescription As String
    Dim savedErrorNumber As Long, savedErrorDescription As String
    Dim savedReadErrorNumber As Long, savedReadErrorDescription As String
    Dim recoveryDetail As String, eventDetail As String, cleanupDetail As String
    If Not SheetExists(SH_REGISTERED_ACCOUNTS) Then Exit Sub
    Set ws = GetSheet(SH_REGISTERED_ACCOUNTS)
    On Error GoTo EH
    If Not TryGetRecordsEnableEvents(entryEvents, eventDetail) Then _
        Err.Raise vbObjectError + 3438, _
                  "ProtectRegisteredAccountsSheet", _
                  "Excelイベントの開始状態を取得できません: " & eventDetail
    entryEventsCaptured = True
    If Not TryKeepRecordsEventsDisabledExact(eventDetail) Then _
        Err.Raise vbObjectError + 3438, _
                  "ProtectRegisteredAccountsSheet", _
                  "保護開始前にExcelイベントを停止できません: " & eventDetail
    eventsStopped = True
    workbookWasSaved = ThisWorkbook.Saved
    mutationStarted = True
    ws.Unprotect Password:=TOOL_PASSWORD
    RestoreToolSheetScrollArea ws
    lastR = Application.Max(4, LastUsedRowInSheet(ws))
    ws.Range("A1:M" & CStr(lastR)).Locked = True
    LockToolShapes ws, False
    ws.Protect Password:=TOOL_PASSWORD, DrawingObjects:=True, Contents:=True, Scenarios:=False, _
               UserInterfaceOnly:=True, AllowFiltering:=True, AllowSorting:=False, _
               AllowFormattingCells:=False, AllowFormattingColumns:=False, AllowFormattingRows:=False
    ws.EnableSelection = xlNoRestrictions
    If Not ws.ProtectContents Or Not ws.ProtectDrawingObjects Then _
        Err.Raise vbObjectError + 3425, "ProtectRegisteredAccountsSheet", _
                  "登録済み口座一覧を保護できませんでした。"
    VerifyToolShapeSecurity ws, True, False
    If workbookWasSaved Then
        ThisWorkbook.Saved = True
        savedReadback = ThisWorkbook.Saved
        If Not savedReadback Then _
            Err.Raise vbObjectError + 3439, _
                      "ProtectRegisteredAccountsSheet", _
                      "保護後の保存状態を開始値へ復元できません。"
    End If
    entryEventsRestored = TryRestoreRecordsEntryEvents( _
                              entryEvents, "登録済み口座一覧の保護", _
                              True, recoveryStateConfirmed, _
                              recoveryAttempted, recoveryEnforceFailed, _
                              eventDetail)
    If recoveryEnforceFailed Or _
       (recoveryAttempted And Not recoveryStateConfirmed) Then
        eventsStopped = TryKeepRecordsEventsDisabledExact(eventDetail)
        Err.Raise RECORDS_RECOVERY_ENFORCE_ERROR, _
                  RECORDS_RECOVERY_HARD_BARRIER_SOURCE & _
                      "ProtectRegisteredAccountsSheet/RecoveryTerminal", _
                  eventDetail
    End If
    If Not entryEventsRestored Or Len(eventDetail) > 0 Then
        If Len(eventDetail) = 0 Then _
            eventDetail = "Excelイベントの開始状態を復元できません。"
        If raiseOnError Then _
            Err.Raise vbObjectError + 3440, _
                      "ProtectRegisteredAccountsSheet", eventDetail
        MsgBox "登録済み口座一覧は保護しましたが、Excelイベントの状態を安全に戻せませんでした。" & _
               vbCrLf & eventDetail, vbCritical, _
               "登録済み口座一覧の保護後状態を確認できません"
    End If
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    errorSource = Err.Source
    If IsRecordsRecoveryHardBarrier(errorNumber, errorSource) Then
        Call TryKeepRecordsEventsDisabledExact(eventDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    If recoveryEnforceFailed Then
        eventsStopped = TryKeepRecordsEventsDisabledExact(eventDetail)
        If Not eventsStopped Then _
            AppendRecordsDetail cleanupDetail, _
                "Recovery設定エラー後のExcelイベントFalse収束にも失敗しました: " & _
                eventDetail
        Err.Raise RECORDS_RECOVERY_ENFORCE_ERROR, _
                  RECORDS_RECOVERY_HARD_BARRIER_SOURCE & _
                      "ProtectRegisteredAccountsSheet/RecoveryTerminal", _
                  cleanupDetail
    End If
    eventsStopped = False
    If entryEventsCaptured Then _
        eventsStopped = TryKeepRecordsEventsDisabledExact(eventDetail)
    If Not eventsStopped Then
        AppendRecordsDetail cleanupDetail, _
            "失敗復旧前のExcelイベント停止を確認できないため、" & _
            "シート・状態・診断への書込みを実行していません。" & _
            IIf(Len(eventDetail) > 0, " " & eventDetail, vbNullString)
    ElseIf mutationStarted Then
        On Error Resume Next
        Err.Clear
        EmergencyProtectToolSheet ws
        emergencyErrorNumber = Err.Number
        emergencyErrorDescription = Err.Description
        Err.Clear
        emergencyProtected = ws.ProtectContents And _
                             ws.ProtectDrawingObjects
        emergencyReadErrorNumber = Err.Number
        emergencyReadErrorDescription = Err.Description
        Err.Clear
        On Error GoTo 0
        If emergencyErrorNumber <> 0 Then emergencyProtected = False
        If emergencyErrorNumber <> 0 Or emergencyReadErrorNumber <> 0 Or _
           Not emergencyProtected Then
            recoveryDetail = "登録済み口座一覧の緊急再保護を確認できません。"
            If emergencyErrorNumber <> 0 Then _
                AppendRecordsDetail recoveryDetail, _
                    "Err " & CStr(emergencyErrorNumber) & " " & _
                    emergencyErrorDescription
            If emergencyReadErrorNumber <> 0 Then _
                AppendRecordsDetail recoveryDetail, _
                    "保護読戻し Err " & CStr(emergencyReadErrorNumber) & _
                    " " & emergencyReadErrorDescription
            Call TryEnterRecordsRecoveryState( _
                     "登録済み口座一覧の緊急再保護失敗", _
                     eventsStopped, recoveryStateConfirmed, _
                     recoveryAttempted, recoveryEnforceFailed, _
                     recoveryDetail)
            AppendRecordsDetail cleanupDetail, recoveryDetail
            If recoveryEnforceFailed Or _
               (recoveryAttempted And Not recoveryStateConfirmed) Then _
                GoTo PROTECT_OUTER_RESTORE
            If eventsStopped And recoveryStateConfirmed Then
                On Error Resume Next
                AddCheck "エラー", _
                         "登録済み口座一覧の緊急再保護", _
                         recoveryDetail
                If recoveryStateConfirmed Then
                    SetInputStatus _
                        "登録済み口座一覧を再保護できないため、案件を要復旧として停止しました。C_チェックを確認してください。", _
                        True
                Else
                    SetInputStatus _
                        "登録済み口座一覧と案件の安全状態を確認できないため通常操作へ戻せません。現在のブックを上書きしないでください。", _
                        True
                End If
                Err.Clear
                On Error GoTo 0
                eventsStopped = _
                    TryKeepRecordsEventsDisabledExact(eventDetail)
                If Not eventsStopped Then _
                    AppendRecordsDetail cleanupDetail, _
                        "診断記録後のExcelイベント停止を維持できません: " & _
                        eventDetail
            End If
        End If
        '緊急再保護と読戻しが成立した時だけ、保護操作によるSaved変更を戻す。
        If eventsStopped And emergencyProtected And workbookWasSaved Then
            On Error Resume Next
            Err.Clear
            ThisWorkbook.Saved = True
            savedErrorNumber = Err.Number
            savedErrorDescription = Err.Description
            Err.Clear
            savedReadback = ThisWorkbook.Saved
            savedReadErrorNumber = Err.Number
            savedReadErrorDescription = Err.Description
            Err.Clear
            On Error GoTo 0
            If savedErrorNumber <> 0 Or savedReadErrorNumber <> 0 Or _
               Not savedReadback Then
                AppendRecordsDetail cleanupDetail, _
                    "ブック保存状態の復元を確認できません" & _
                    IIf(savedErrorNumber <> 0, _
                        ": Err " & CStr(savedErrorNumber) & " " & _
                        savedErrorDescription, vbNullString) & _
                    IIf(savedReadErrorNumber <> 0, _
                        " / 読戻し Err " & CStr(savedReadErrorNumber) & _
                        " " & savedReadErrorDescription, vbNullString)
                On Error Resume Next
                AddCheck "警告", _
                         "登録済み口座一覧の保存状態", _
                         cleanupDetail
                Err.Clear
                On Error GoTo 0
            End If
        End If
    End If

PROTECT_OUTER_RESTORE:
    If recoveryEnforceFailed Then
        recoveryStateConfirmed = False
        eventsStopped = TryKeepRecordsEventsDisabledExact(eventDetail)
        If Not eventsStopped Then _
            AppendRecordsDetail cleanupDetail, _
                "Recovery設定エラー後のExcelイベントFalse収束にも失敗しました: " & _
                eventDetail
        entryEventsRestored = entryEventsCaptured And _
                              Not entryEvents And eventsStopped
        AppendRecordsDetail cleanupDetail, _
            "Recovery設定自体が失敗したため、診断・保存状態・Application状態を変更せず、" & _
            "開始値TrueへExcelイベントを復元していません。"
        GoTo PROTECT_REPORT_FAILURE
    End If
    If recoveryAttempted And Not recoveryStateConfirmed Then
        eventsStopped = TryKeepRecordsEventsDisabledExact(eventDetail)
        If Not eventsStopped Then _
            AppendRecordsDetail cleanupDetail, _
                "Recovery強制試行後のExcelイベントFalse収束にも失敗しました: " & _
                eventDetail
        entryEventsRestored = entryEventsCaptured And _
                              Not entryEvents And eventsStopped
        AppendRecordsDetail cleanupDetail, _
            "Recovery強制試行後の二重状態を確認できないため、" & _
            "保存状態・Application状態・開始値Trueを変更していません。"
        GoTo PROTECT_REPORT_FAILURE
    End If

    If entryEventsCaptured Then
        protectionSafetyConfirmed = Not mutationStarted Or emergencyProtected
        eventsStopped = TryKeepRecordsEventsDisabledExact(eventDetail)
        If recoveryStateConfirmed Then
            If eventsStopped Then
                dateSafeFallbackConfirmed = False
                recoveryStateConfirmed = _
                    RollbackRecoveryStateIsConfirmedExact( _
                        cleanupDetail, dateSafeFallbackConfirmed)
            Else
                recoveryStateConfirmed = False
            End If
        End If
        stateProblems = vbNullString
        applicationStateSafe = AppStateIsRestored(stateProblems)
        If Not entryEvents Or _
           (eventsStopped And applicationStateSafe And _
            (protectionSafetyConfirmed Or recoveryStateConfirmed)) Then
            entryEventsRestored = TryRestoreRecordsEntryEvents( _
                                      entryEvents, _
                                      "登録済み口座一覧の保護失敗復旧", _
                                      eventsStopped, recoveryStateConfirmed, _
                                      recoveryAttempted, recoveryEnforceFailed, _
                                      eventDetail)
        Else
            AppendRecordsDetail cleanupDetail, _
                "保護安全またはRecovery二重状態とApplication安全を確認できないため、" & _
                "開始値TrueへExcelイベントを復元しません。"
            entryEventsRestored = False
        End If
        If Not entryEventsRestored Or Len(eventDetail) > 0 Then _
            AppendRecordsDetail cleanupDetail, eventDetail
    End If
PROTECT_REPORT_FAILURE:
    AppendRecordsDetail errorDescription, cleanupDetail
    If recoveryEnforceFailed Or _
       (recoveryAttempted And Not recoveryStateConfirmed) Then
        eventsStopped = TryKeepRecordsEventsDisabledExact(eventDetail)
        Err.Raise RECORDS_RECOVERY_ENFORCE_ERROR, _
                  RECORDS_RECOVERY_HARD_BARRIER_SOURCE & _
                      "ProtectRegisteredAccountsSheet/RecoveryTerminal", _
                  errorDescription
    End If
    If raiseOnError Then
        Err.Raise errorNumber, "ProtectRegisteredAccountsSheet", _
                  IIf(Len(errorSource) > 0, _
                      errorSource & " / ", vbNullString) & _
                  errorDescription
    End If
    On Error Resume Next
    MsgBox "登録済み口座一覧を安全に保護できませんでした。" & _
           vbCrLf & "現在のブックを上書きせず、C_チェックを確認してください。" & _
           vbCrLf & "Err " & CStr(errorNumber) & ": " & _
           errorDescription, vbCritical, _
           "登録済み口座一覧の安全状態を確認できません"
    On Error GoTo 0
End Sub

Private Function DictionaryLong(ByVal dict As Object, ByVal keyText As String) As Long
    If Not dict Is Nothing Then
        If dict.Exists(keyText) Then DictionaryLong = CLng(dict(keyText))
    End If
End Function

Public Sub BuildRegisteredAccountsPanel(ByVal ws As Worksheet)
    Dim x As Double, y As Double, w As Double, availableW As Double
    Dim gap As Double, margin As Double, wideW As Double, smallW As Double, leftX As Double
    x = ws.Range("A2").Left
    y = ws.Range("A2").Top + 1
    w = ws.Range("A2:L2").Width
    margin = 10
    gap = 8
    availableW = w - margin * 2 - gap * 3
    wideW = availableW * 0.29
    smallW = (availableW - wideW * 2) / 2
    AddPanelBack ws, x, y, w, 36
    leftX = x + margin
    AddUIButton ws, leftX, y + 4, wideW, 28, "選択口座を訂正", "LoadSelectedAccountForEdit", "primary"
    leftX = leftX + wideW + gap
    AddUIButton ws, leftX, y + 4, wideW, 28, "選択口座を削除", "DeleteSelectedAccount", "danger"
    leftX = leftX + wideW + gap
    AddUIButton ws, leftX, y + 4, smallW, 28, "再表示", "OpenRegisteredAccounts", "tool"
    leftX = leftX + smallW + gap
    AddUIButton ws, leftX, y + 4, smallW, 28, "入力へ戻る", "ShowInputSheet", "soft"
    LockToolShapes ws, False
End Sub

Private Function DeleteAccountPreflightWorkRows( _
        ByVal txStoreRows As Long, ByVal balanceStoreRows As Long, _
        ByVal accountStoreRows As Long, ByVal personCandidateRows As Long) As Double
    Dim cellWork As Double
    If txStoreRows < 0 Or balanceStoreRows < 0 Or _
       accountStoreRows < 0 Or personCandidateRows < 0 Then _
        Err.Raise vbObjectError + 3432, "DeleteAccountPreflightWorkRows", _
                  "口座削除の事前安全検査行数に負数が含まれています。"
    '内部3表の全体snapshotを保持したまま、圧縮削除の元/出力配列を最大2本使う。
    '人物候補は削除対象ではないため、整合性検査用の1本だけを加える。
    cellWork = 3# * (CDbl(txStoreRows) * CDbl(WORK_TX_COL_PERSON_ID) + _
                     CDbl(balanceStoreRows) * CDbl(WORK_BAL_COL_PERSON_ID) + _
                     CDbl(accountStoreRows) * CDbl(ACC_COL_TRANSFER_ID)) + _
               CDbl(personCandidateRows) * CDbl(DELETE_ACCOUNT_PERSON_COLUMNS)
    DeleteAccountPreflightWorkRows = DeleteAccountEquivalentWorkRows(cellWork)
End Function

Private Function DeleteAccountEquivalentWorkRows(ByVal cellWork As Double) As Double
    Dim workRows As Double
    If cellWork < 0# Or _
       cellWork > DELETE_ACCOUNT_CAPACITY_LONG_MAX * _
                  CDbl(DELETE_ACCOUNT_CAPACITY_BASE_COLUMNS) Then _
        Err.Raise vbObjectError + 3434, "DeleteAccountEquivalentWorkRows", _
                  "口座削除の安全退避規模を16列相当行へ換算できません。"
    workRows = Int( _
        (cellWork + CDbl(DELETE_ACCOUNT_CAPACITY_BASE_COLUMNS) - 1#) / _
        CDbl(DELETE_ACCOUNT_CAPACITY_BASE_COLUMNS))
    If workRows < 0# Or workRows > DELETE_ACCOUNT_CAPACITY_LONG_MAX Then _
        Err.Raise vbObjectError + 3434, "DeleteAccountEquivalentWorkRows", _
                  "口座削除の安全退避規模を16列相当行へ換算できません。"
    DeleteAccountEquivalentWorkRows = workRows
End Function

Public Sub DeleteSelectedAccount()
    Dim wsList As Worksheet, wsTx As Worksheet, wsBal As Worksheet, wsAcc As Worksheet
    Dim wsPerson As Worksheet
    Dim selectedRow As Long, masterRow As Long, accountID As String
    Dim bankName As String, branchName As String, personName As String, accountType As String, accountNo As String
    Dim txSnapshot As Variant, balSnapshot As Variant, accountSnapshot As Variant
    Dim txCount As Long, balCount As Long
    Dim txSnapshotRows As Long, balSnapshotRows As Long, accountSnapshotRows As Long
    Dim preflightTxRows As Long, preflightBalanceRows As Long
    Dim preflightAccountRows As Long, preflightPersonRows As Long
    Dim preflightWorkRows As Double
    Dim deleteStarted As Boolean, committed As Boolean, rollbackVerified As Boolean
    Dim snapshotsCaptured As Boolean
    Dim postCommitDirtyFailed As Boolean
    Dim postCommitRecoveryRequired As Boolean
    Dim applicationRestoreFailed As Boolean, inputKeyRestoreFailed As Boolean
    Dim rollbackDirtyFailed As Boolean, rollbackRecoveryRequired As Boolean
    Dim recoveryStateConfirmed As Boolean, dateSafeFallbackConfirmed As Boolean
    Dim recoveryAttempted As Boolean, recoveryEnforceFailed As Boolean
    Dim deletedEditAccount As Boolean
    Dim entryEvents As Boolean, entryEventsCaptured As Boolean
    Dim cleanupEventsStopped As Boolean, leaseRestored As Boolean
    Dim applicationLeaseStarted As Boolean, localSafetyConfirmed As Boolean
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim nestedErrorNumber As Long, nestedErrorDescription As String
    Dim nestedErrorSource As String
    Dim rollbackDetail As String, rollbackVerifyDetail As String, postDeleteDetail As String
    Dim cleanupErrorNumber As Long, cleanupErrorDescription As String
    Dim editDeleteWarning As String, eventDetail As String, finalizeDetail As String

    If Not RequireToolReady() Then Exit Sub
    If ActiveSheet Is Nothing Then Exit Sub
    If ActiveSheet.Name <> SH_REGISTERED_ACCOUNTS Then Exit Sub
    If Not SheetExists(SH_PERSON_CAND) Then
        MsgBox "人物候補の保存領域が見つからないため、口座を削除できません。" & vbCrLf & _
               "診断を実行し、案件ファイルを復旧してください。", _
               vbCritical, "口座削除を開始できません"
        Exit Sub
    End If
    On Error GoTo EH
    Set wsList = ActiveSheet
    selectedRow = ActiveCell.Row
    If selectedRow < 4 Then
        MsgBox "削除する口座の行を選択してください。", vbInformation
        Exit Sub
    End If
    accountID = CellText(wsList.Cells(selectedRow, 13).Value)
    If Len(accountID) = 0 Then
        MsgBox "選択行から口座IDを取得できません。再表示して選び直してください。", vbExclamation
        Exit Sub
    End If
    Set wsTx = GetSheet(SH_WORK_TX)
    Set wsBal = GetSheet(SH_WORK_BAL)
    Set wsAcc = GetSheet(SH_WORK_ACCOUNT)
    Set wsPerson = GetSheet(SH_PERSON_CAND)

    '人物・参照整合性検査、対象件数取得、全体退避はいずれも案件規模の
    'Range.Value2配列を確保する。最初の確保より前に内部3ストアと人物候補を
    '合算し、32bit版ではメモリ不足より先に安全停止する。
    preflightTxRows = CLng(Application.Max(0, _
        LastDataRowInColumns(wsTx, 1, WORK_TX_COL_PERSON_ID) - 1))
    preflightBalanceRows = CLng(Application.Max(0, _
        LastDataRowInColumns(wsBal, 1, WORK_BAL_COL_PERSON_ID) - 1))
    preflightAccountRows = CLng(Application.Max(0, _
        LastDataRowInColumns(wsAcc, 1, ACC_COL_TRANSFER_ID) - 1))
    preflightPersonRows = CLng(Application.Max(0, _
        LastDataRowInColumns(wsPerson, 1, 4) - 1))
    preflightWorkRows = DeleteAccountPreflightWorkRows( _
        preflightTxRows, preflightBalanceRows, _
        preflightAccountRows, preflightPersonRows)
    If preflightWorkRows > 2147483647# Then _
        Err.Raise vbObjectError + 3433, "DeleteSelectedAccount", _
                  "口座削除の安全退避規模を計算できません。"
    If Not ConfirmLargeArrayOperation(CLng(preflightWorkRows), _
            "口座の削除（内部保管の検査・安全退避）") Then
        SetInputStatus "口座削除を開始せず中止しました。内部データは変更していません。"
        Exit Sub
    End If
    If Not RequireInternalStoresSafeForWrite() Then Exit Sub

    masterRow = FindAccountRowByID(accountID)
    If masterRow = 0 Then
        MsgBox "対象口座が既に存在しません。再表示してください。", vbExclamation
        Exit Sub
    End If
    bankName = CellText(wsAcc.Cells(masterRow, ACC_COL_BANK).Value)
    branchName = CellText(wsAcc.Cells(masterRow, ACC_COL_BRANCH).Value)
    personName = CellText(wsAcc.Cells(masterRow, ACC_COL_PERSON).Value)
    accountType = CellText(wsAcc.Cells(masterRow, ACC_COL_TYPE).Value)
    accountNo = CellText(wsAcc.Cells(masterRow, ACC_COL_NO).Value)
    txCount = CountAccountRecords(wsTx, WORK_TX_COL_ACCOUNT_ID, accountID)
    balCount = CountAccountRecords(wsBal, WORK_BAL_COL_ACCOUNT_ID, accountID)
    deletedEditAccount = (CurrentEditAccountID() = accountID)
    If deletedEditAccount Then _
        editDeleteWarning = vbCrLf & "この口座で入力中の未反映の訂正内容も破棄されます。" & vbCrLf

    If MsgBox("次の口座と、その取引・残高を削除します。" & vbCrLf & vbCrLf & _
              bankName & IIf(Len(branchName) > 0, " " & branchName, "") & vbCrLf & _
              personName & " / " & accountType & " / " & accountNo & vbCrLf & _
              "取引等 " & txCount & "行、残高 " & balCount & "行" & editDeleteWarning & vbCrLf & _
              "この操作を実行しますか？", _
              vbYesNo + vbCritical + vbDefaultButton2, "口座削除の最終確認") <> vbYes Then Exit Sub

    If Not TryGetRecordsEnableEvents(entryEvents, eventDetail) Then _
        Err.Raise vbObjectError + 3442, "DeleteSelectedAccount", _
                  "Excelイベントの開始状態を取得できません: " & eventDetail
    entryEventsCaptured = True
    AppBegin "選択口座を削除しています..."
    applicationLeaseStarted = True
    If Not TryKeepRecordsEventsDisabledExact(eventDetail) Then _
        Err.Raise vbObjectError + 3442, "DeleteSelectedAccount", _
                  "削除開始前にExcelイベントを停止できません: " & eventDetail
    '対象行だけを末尾へ戻す方式では、元の物理位置・Variant型・PrefixCharacterを
    '復元できない。削除前の内部3ストアを全行順で固定し、失敗時は全体を戻す。
    CaptureInternalStoreSnapshotWithPrefix wsTx, WORK_TX_COL_PERSON_ID, _
                                           txSnapshot, txSnapshotRows
    CaptureInternalStoreSnapshotWithPrefix wsBal, WORK_BAL_COL_PERSON_ID, _
                                           balSnapshot, balSnapshotRows
    CaptureInternalStoreSnapshotWithPrefix wsAcc, ACC_COL_TRANSFER_ID, _
                                           accountSnapshot, accountSnapshotRows
    snapshotsCaptured = True
    '破壊的処理の前に帳票を要更新へ倒し、途中失敗時にも旧帳票を正常扱いしない。
    MarkOutputsDirty
    deleteStarted = True
    DeleteAccountRecords accountID, True
    If FindAccountRowByID(accountID) > 0 Or _
       CountAccountRecords(wsTx, WORK_TX_COL_ACCOUNT_ID, accountID) > 0 Or _
       CountAccountRecords(wsBal, WORK_BAL_COL_ACCOUNT_ID, accountID) > 0 Then
        Err.Raise vbObjectError + 3420, "DeleteSelectedAccount", "削除後の確認で対象データが残っています。"
    End If
    InvalidateInternalIdCaches
    '削除対象を訂正中なら、入力クリアまでを削除トランザクションの必須工程にする。
    'ClearInputCoreは失敗時に入力と訂正IDを復元するため、ここで失敗した場合は
    '下のEHで内部口座も復元し、古い入力だけが新規登録状態で残る事故を防ぐ。
    If deletedEditAccount Then ClearInputCore KEEP_NONE, True, True, True
    committed = True

    On Error Resume Next
    Err.Clear
    BuildRegisteredAccountsSheet True, True
    If Err.Number <> 0 Then
        nestedErrorNumber = Err.Number
        nestedErrorSource = Err.Source
        nestedErrorDescription = Err.Description
        If IsRecordsRecoveryHardBarrier( _
               nestedErrorNumber, nestedErrorSource) Then
            Err.Clear
            cleanupEventsStopped = _
                TryKeepRecordsEventsDisabledExact(eventDetail)
            On Error GoTo EH
            Err.Raise nestedErrorNumber, nestedErrorSource, _
                      nestedErrorDescription
        End If
        If Len(postDeleteDetail) > 0 Then postDeleteDetail = postDeleteDetail & " / "
        postDeleteDetail = postDeleteDetail & _
                           "登録済み口座一覧の再構築に失敗: Err " & _
                           Err.Number & " " & Err.Description
        Err.Clear
    End If
    On Error GoTo EH
    If recoveryEnforceFailed Then
        cleanupEventsStopped = _
            TryKeepRecordsEventsDisabledExact(eventDetail)
        If Not cleanupEventsStopped Then _
            AppendRecordsDetail postDeleteDetail, _
                "Recovery設定エラー後のExcelイベントFalse収束にも失敗しました: " & _
                eventDetail
        GoTo DELETE_NORMAL_FINALIZE
    End If
    If Not TryKeepRecordsEventsDisabledExact(eventDetail) Then _
        Err.Raise vbObjectError + 3442, "DeleteSelectedAccount", _
                  "削除確定後にExcelイベント停止を維持できません: " & eventDetail
    cleanupEventsStopped = True
    postCommitRecoveryRequired = Not ToolDataHealthIsNormal()
    If postCommitRecoveryRequired Then _
        Call TryEnterRecordsRecoveryState( _
                 "口座削除後の安全状態", cleanupEventsStopped, _
                 recoveryStateConfirmed, recoveryAttempted, _
                 recoveryEnforceFailed, _
                 postDeleteDetail)
    If recoveryEnforceFailed Or _
       (recoveryAttempted And Not recoveryStateConfirmed) Then _
        GoTo DELETE_NORMAL_FINALIZE
    If cleanupEventsStopped And _
       (Not postCommitRecoveryRequired Or recoveryStateConfirmed) Then
        If Len(postDeleteDetail) > 0 Or postCommitRecoveryRequired Then
            AddCheck IIf(postCommitRecoveryRequired, "エラー", "警告"), _
                     "口座削除後処理", _
                     "口座データの削除は完了しています。" & _
                     IIf(Len(postDeleteDetail) > 0, _
                         " / " & postDeleteDetail, vbNullString)
        End If
        If postCommitRecoveryRequired Then
            If recoveryStateConfirmed Then
                SetInputStatus _
                    "削除済み・要復旧: 口座の削除は完了しています。同じ削除を繰り返さず、C_チェックを確認してください。", _
                    True
            Else
                SetInputStatus _
                    "削除済み・安全状態要確認: 口座の削除は完了しています。現在のブックを上書きしないでください。", _
                    True
            End If
        ElseIf Len(postDeleteDetail) > 0 Then
            SetInputStatus _
                "口座を削除しました。登録済み口座一覧は再構築できなかったため、再表示してください。"
        Else
            SetInputStatus "口座を削除しました: " & bankName & " " & accountNo
        End If
    Else
        AppendRecordsDetail postDeleteDetail, _
            "削除確定後のExcelイベント停止が不明なため、診断・状態表示を書き込んでいません。"
    End If
DELETE_NORMAL_FINALIZE:
    localSafetyConfirmed = committed And Not postCommitRecoveryRequired And _
                           Not recoveryEnforceFailed
    leaseRestored = FinalizeRecordsApplicationLease( _
                        "口座削除", applicationLeaseStarted, _
                        entryEventsCaptured, entryEvents, _
                        localSafetyConfirmed, cleanupEventsStopped, _
                        recoveryAttempted, recoveryEnforceFailed, _
                        recoveryStateConfirmed, _
                        finalizeDetail)
    AppendRecordsDetail postDeleteDetail, finalizeDetail
    If Not leaseRestored Then
        MsgBox "口座データの削除は完了しています。同じ削除を繰り返さないでください。" & _
               vbCrLf & "Excelの開始状態を完全に復元できませんでした。" & _
               vbCrLf & postDeleteDetail, vbCritical, _
               "削除済み・Excel状態要確認"
    ElseIf postCommitRecoveryRequired Then
        MsgBox "口座データの削除は完了しています。同じ削除を繰り返さないでください。" & _
               vbCrLf & IIf(recoveryStateConfirmed, _
                   "案件を要復旧として停止しました。C_チェックを確認してください。", _
                   "案件の安全状態を一意に確認できません。現在のブックを上書きしないでください。"), _
               vbCritical, IIf(recoveryStateConfirmed, _
                   "削除済み・要復旧", "削除済み・安全状態要確認")
    ElseIf Len(postDeleteDetail) > 0 Then
        MsgBox "口座データの削除は完了しました。" & vbCrLf & _
               "登録済み口座一覧は再構築できなかったため、同じ削除を繰り返さず再表示してください。" & _
               vbCrLf & "帳票は要更新状態です。", vbExclamation, _
               "削除済み・一覧再構築警告"
    Else
        MsgBox "口座を削除しました。帳票は要更新状態です。", _
               vbInformation
    End If
    Exit Sub

EH:
    errorNumber = Err.Number
    errorSource = Err.Source
    errorDescription = Err.Description
    If IsRecordsClearRecoveryFatal(errorNumber, errorSource) Then
        cleanupEventsStopped = _
            TryKeepRecordsEventsDisabledExact(eventDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    If IsRecordsRecoveryHardBarrier(errorNumber, errorSource) Then
        cleanupEventsStopped = _
            TryKeepRecordsEventsDisabledExact(eventDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    cleanupEventsStopped = False
    eventDetail = vbNullString
    If entryEventsCaptured Then _
        cleanupEventsStopped = _
            TryKeepRecordsEventsDisabledExact(eventDetail)
    If Not cleanupEventsStopped Then
        If committed Then
            AppendRecordsDetail postDeleteDetail, _
                "失敗復旧開始時のExcelイベント停止を確認できないため、" & _
                "確定済みデータへ再書込みせず、診断・状態・キー設定も変更していません。" & _
                IIf(Len(eventDetail) > 0, " " & eventDetail, vbNullString)
            leaseRestored = FinalizeRecordsApplicationLease( _
                                "口座削除の確定後失敗復旧", _
                                applicationLeaseStarted, _
                                entryEventsCaptured, entryEvents, _
                                False, False, _
                                recoveryAttempted, recoveryEnforceFailed, _
                                recoveryStateConfirmed, _
                                finalizeDetail)
            AppendRecordsDetail postDeleteDetail, finalizeDetail
            MsgBox "口座データの削除は完了しています。同じ削除を繰り返さないでください。" & _
                   vbCrLf & "Excelイベントの安全状態を確認できないため、" & _
                   "現在のブックを上書きしないでください。" & _
                   vbCrLf & "Err " & CStr(errorNumber) & ": " & _
                   errorDescription & vbCrLf & postDeleteDetail, _
                   vbCritical, "削除済み・Excel状態不明"
        Else
            AppendRecordsDetail rollbackDetail, _
                "失敗復旧開始時のExcelイベント停止を確認できないため、" & _
                "退避データ・状態・診断・キー設定へ書き込んでいません。" & _
                IIf(Len(eventDetail) > 0, " " & eventDetail, vbNullString)
            leaseRestored = FinalizeRecordsApplicationLease( _
                                "口座削除の失敗復旧", _
                                applicationLeaseStarted, _
                                entryEventsCaptured, entryEvents, _
                                False, False, _
                                recoveryAttempted, recoveryEnforceFailed, _
                                recoveryStateConfirmed, _
                                finalizeDetail)
            AppendRecordsDetail rollbackDetail, finalizeDetail
            MsgBox "口座削除中にエラーが発生し、Excelイベントの安全状態も確認できません。" & _
                   vbCrLf & "現在のブックを上書きせず、Excelを再起動してください。" & _
                   vbCrLf & "Err " & CStr(errorNumber) & ": " & _
                   errorDescription & vbCrLf & rollbackDetail, _
                   vbCritical, "口座削除・状態不明"
        End If
        Exit Sub
    End If
    If committed Then
        '内部口座・取引・残高の削除確認後に、一覧再表示や案内だけが失敗しても
        '削除ロールバック不成立へ誤分類しない。帳票dirtyを先に再確認し、
        'Application leaseと入力キーの復元失敗は削除済みの要復旧として止める。
        On Error Resume Next
        Err.Clear
        MarkOutputsDirty
        cleanupErrorNumber = Err.Number
        cleanupErrorDescription = Err.Description
        Err.Clear
        On Error GoTo 0
        If cleanupErrorNumber <> 0 Then
            postCommitDirtyFailed = True
            AppendRecordsDetail postDeleteDetail, _
                "帳票要更新状態の再確認エラー: Err " & _
                CStr(cleanupErrorNumber) & " " & cleanupErrorDescription
        End If
        If postCommitDirtyFailed Then
            '削除済みデータは巻き戻さないが、古い帳票を正常扱いできないため
            'dirtyを保証できなければ案件全体を診断隔離する。
            Call TryEnterRecordsRecoveryState( _
                     "削除確定後の帳票状態失敗", _
                     cleanupEventsStopped, recoveryStateConfirmed, _
                     recoveryAttempted, recoveryEnforceFailed, _
                     postDeleteDetail)
            If recoveryEnforceFailed Or _
               (recoveryAttempted And Not recoveryStateConfirmed) Or _
               Not cleanupEventsStopped Then _
                GoTo DELETE_COMMITTED_FINALIZE
        End If

        'OnKeyはFalse exact下で先に収束させ、Applicationと開始時イベントを最後に戻す。
        On Error Resume Next
        Err.Clear
        EnableInputKeys
        cleanupErrorNumber = Err.Number
        cleanupErrorDescription = Err.Description
        Err.Clear
        On Error GoTo 0
        If cleanupErrorNumber <> 0 Then
            inputKeyRestoreFailed = True
            AppendRecordsDetail postDeleteDetail, _
                "入力キー復旧エラー: Err " & CStr(cleanupErrorNumber) & _
                " " & cleanupErrorDescription
            Call TryEnterRecordsRecoveryState( _
                     "削除確定後の入力キー復旧失敗", _
                     cleanupEventsStopped, recoveryStateConfirmed, _
                     recoveryAttempted, recoveryEnforceFailed, _
                     postDeleteDetail)
            If recoveryEnforceFailed Or _
               (recoveryAttempted And Not recoveryStateConfirmed) Or _
               Not cleanupEventsStopped Then _
                GoTo DELETE_COMMITTED_FINALIZE
        End If

        postCommitRecoveryRequired = postCommitDirtyFailed Or _
                                     applicationRestoreFailed Or _
                                     inputKeyRestoreFailed
        On Error Resume Next
        Err.Clear
        If Not ToolDataHealthIsNormal() Then postCommitRecoveryRequired = True
        cleanupErrorNumber = Err.Number
        cleanupErrorDescription = Err.Description
        Err.Clear
        On Error GoTo 0
        If cleanupErrorNumber <> 0 Then
            postCommitRecoveryRequired = True
            AppendRecordsDetail postDeleteDetail, _
                "案件安全状態の確認エラー: Err " & CStr(cleanupErrorNumber) & _
                " " & cleanupErrorDescription
            Call TryEnterRecordsRecoveryState( _
                     "削除確定後の安全状態確認失敗", _
                     cleanupEventsStopped, recoveryStateConfirmed, _
                     recoveryAttempted, recoveryEnforceFailed, _
                     postDeleteDetail)
            If recoveryEnforceFailed Or _
               (recoveryAttempted And Not recoveryStateConfirmed) Or _
               Not cleanupEventsStopped Then _
                GoTo DELETE_COMMITTED_FINALIZE
        End If
        If errorNumber = vbObjectError + 3442 Then _
            postCommitRecoveryRequired = True
        AppendRecordsDetail postDeleteDetail, _
                            "削除完了後の処理エラー: Err " & CStr(errorNumber) & _
                            " " & errorDescription
        If postCommitRecoveryRequired And Not recoveryStateConfirmed Then
            Call TryEnterRecordsRecoveryState( _
                     "口座削除の確定後失敗", cleanupEventsStopped, _
                     recoveryStateConfirmed, recoveryAttempted, _
                     recoveryEnforceFailed, _
                     postDeleteDetail)
            If recoveryEnforceFailed Or _
               (recoveryAttempted And Not recoveryStateConfirmed) Or _
               Not cleanupEventsStopped Then _
                GoTo DELETE_COMMITTED_FINALIZE
        End If
        dateSafeFallbackConfirmed = False
        If postCommitRecoveryRequired Then _
            recoveryStateConfirmed = _
                RollbackRecoveryStateIsConfirmedExact( _
                    postDeleteDetail, dateSafeFallbackConfirmed)
        If Not recoveryEnforceFailed And _
           (Not postCommitRecoveryRequired Or recoveryStateConfirmed) Then
            On Error Resume Next
            AddCheck IIf(postCommitRecoveryRequired, "エラー", "警告"), "口座削除後処理", _
                     "口座データの削除は完了しています。" & _
                     IIf(Len(postDeleteDetail) > 0, " / " & postDeleteDetail, "")
            If postCommitRecoveryRequired Then
                SetInputStatus "削除済み・要復旧: 口座の削除は完了しています。" & _
                               "同じ削除を繰り返さず、C_チェックを確認してください。", True
            Else
                SetInputStatus "口座の削除は完了しましたが、一覧または画面の更新に失敗しました。再表示してください。"
            End If
            Err.Clear
            On Error GoTo 0
        End If
DELETE_COMMITTED_FINALIZE:
        localSafetyConfirmed = cleanupEventsStopped And _
                               Not postCommitRecoveryRequired And _
                               Not recoveryEnforceFailed
        leaseRestored = FinalizeRecordsApplicationLease( _
                            "口座削除の確定後失敗復旧", _
                            applicationLeaseStarted, _
                            entryEventsCaptured, entryEvents, _
                            localSafetyConfirmed, cleanupEventsStopped, _
                            recoveryAttempted, recoveryEnforceFailed, _
                            recoveryStateConfirmed, _
                            finalizeDetail)
        AppendRecordsDetail postDeleteDetail, finalizeDetail
        If Not leaseRestored Then postCommitRecoveryRequired = True
        If postCommitRecoveryRequired Then
            If recoveryStateConfirmed Then
                MsgBox "口座データの削除は完了しています。" & vbCrLf & _
                       "同じ削除操作を繰り返さないでください。" & vbCrLf & _
                       "案件を要復旧として停止しました。C_チェックを確認してください。" & vbCrLf & _
                       "Err " & CStr(errorNumber) & ": " & errorDescription & _
                       IIf(Len(postDeleteDetail) > 0, _
                           vbCrLf & "安全停止詳細: " & postDeleteDetail, ""), _
                       vbCritical, "削除済み・要復旧"
            Else
                MsgBox "口座データの削除は完了しています。" & vbCrLf & _
                       "同じ削除操作を繰り返さないでください。" & vbCrLf & _
                       "案件の安全状態を一意に確認できないため通常操作へ戻せません。" & vbCrLf & _
                       "C_チェックを確認し、現在のブックを上書きしないでください。" & vbCrLf & _
                       "Err " & CStr(errorNumber) & ": " & errorDescription & _
                       IIf(Len(postDeleteDetail) > 0, _
                           vbCrLf & "安全停止詳細: " & postDeleteDetail, ""), _
                       vbCritical, "削除済み・安全状態要確認"
            End If
        Else
            MsgBox "口座データの削除は完了しましたが、削除後の画面更新に失敗しました。" & vbCrLf & _
                   "同じ削除操作を繰り返さず、口座一覧とC_チェックを確認してください。" & vbCrLf & _
                   "帳票は要更新状態です。" & vbCrLf & _
                   "Err " & CStr(errorNumber) & ": " & errorDescription, _
                   vbExclamation, "口座削除後の表示更新エラー"
        End If
        Exit Sub
    End If
    If deleteStarted And Not committed Then
        On Error Resume Next
        Err.Clear
        If snapshotsCaptured Then
            RestoreDeletedAccount txSnapshot, txSnapshotRows, _
                                  balSnapshot, balSnapshotRows, _
                                  accountSnapshot, accountSnapshotRows
            If Err.Number <> 0 Then _
                AppendRecordsDetail rollbackDetail, "復元処理エラー: " & Err.Description
            Err.Clear
            rollbackVerifyDetail = VerifyDeletedAccountRestore( _
                                        txSnapshot, txSnapshotRows, _
                                        balSnapshot, balSnapshotRows, _
                                        accountSnapshot, accountSnapshotRows)
            If Err.Number <> 0 Then
                AppendRecordsDetail rollbackDetail, "復元確認エラー: " & Err.Description
            ElseIf Len(rollbackVerifyDetail) > 0 Then
                AppendRecordsDetail rollbackDetail, rollbackVerifyDetail
            Else
                rollbackVerified = True
            End If
        Else
            AppendRecordsDetail rollbackDetail, "削除前の内部3ストア退避を確認できません。"
        End If
        Err.Clear
        If deletedEditAccount And rollbackVerified Then
            SetEditAccountID accountID
            nestedErrorNumber = Err.Number
            nestedErrorSource = Err.Source
            nestedErrorDescription = Err.Description
            If IsRecordsRecoveryHardBarrier( _
                   nestedErrorNumber, nestedErrorSource) Then
                Err.Clear
                Call TryKeepRecordsEventsDisabledExact(eventDetail)
                On Error GoTo 0
                Err.Raise nestedErrorNumber, nestedErrorSource, _
                          nestedErrorDescription
            End If
            If Err.Number <> 0 Then
                AppendRecordsDetail rollbackDetail, "訂正状態の復元エラー: " & Err.Description
                rollbackVerified = False
            End If
        End If
        Err.Clear
        On Error GoTo 0
    End If

    'rollback helper内でRecovery隔離が走ると外側leaseが閉じ得るため、
    'dirty・Recovery・OnKey・診断書込みの前にFalseを再確認する。
    cleanupEventsStopped = _
        TryKeepRecordsEventsDisabledExact(eventDetail)
    If Not cleanupEventsStopped Then
        AppendRecordsDetail rollbackDetail, _
            "ロールバック後のExcelイベント停止を確認できないため、" & _
            "以後の状態・診断・キー設定へ書き込んでいません: " & _
            eventDetail
        GoTo DELETE_PRECOMMIT_FINALIZE
    End If

    'rollbackの読戻し・訂正状態復元後にdirtyを再確認し、Application状態を返す前に
    '内部データ側の復旧要否を確定する。
    If snapshotsCaptured Then
        On Error Resume Next
        Err.Clear
        MarkOutputsDirty
        cleanupErrorNumber = Err.Number
        cleanupErrorDescription = Err.Description
        Err.Clear
        On Error GoTo 0
        If cleanupErrorNumber <> 0 Then
            rollbackDirtyFailed = True
            AppendRecordsDetail rollbackDetail, _
                "帳票要更新状態の再確認エラー: Err " & _
                CStr(cleanupErrorNumber) & " " & cleanupErrorDescription
        End If
    End If

    rollbackRecoveryRequired = (deleteStarted And Not rollbackVerified) Or _
                               rollbackDirtyFailed
    If rollbackRecoveryRequired Then
        '削除復元またはdirty確認が不成立なら、旧帳票の再利用と通常操作を先に止める。
        Call TryEnterRecordsRecoveryState( _
                 "口座削除ロールバック不成立", _
                 cleanupEventsStopped, recoveryStateConfirmed, _
                 recoveryAttempted, recoveryEnforceFailed, _
                 rollbackDetail)
        If recoveryEnforceFailed Or _
           (recoveryAttempted And Not recoveryStateConfirmed) Or _
           Not cleanupEventsStopped Then _
            GoTo DELETE_PRECOMMIT_FINALIZE
    End If

    'OnKeyもFalse exact下で処理し、Applicationと開始時イベントの復元を最後に行う。
    On Error Resume Next
    Err.Clear
    EnableInputKeys
    cleanupErrorNumber = Err.Number
    cleanupErrorDescription = Err.Description
    Err.Clear
    On Error GoTo 0
    If cleanupErrorNumber <> 0 Then
        inputKeyRestoreFailed = True
        rollbackRecoveryRequired = True
        AppendRecordsDetail rollbackDetail, _
            "入力キー復旧エラー: Err " & CStr(cleanupErrorNumber) & _
            " " & cleanupErrorDescription
        Call TryEnterRecordsRecoveryState( _
                 "口座削除失敗後の入力キー復旧失敗", _
                 cleanupEventsStopped, recoveryStateConfirmed, _
                 recoveryAttempted, recoveryEnforceFailed, _
                 rollbackDetail)
        If recoveryEnforceFailed Or _
           (recoveryAttempted And Not recoveryStateConfirmed) Or _
           Not cleanupEventsStopped Then _
            GoTo DELETE_PRECOMMIT_FINALIZE
    End If

    dateSafeFallbackConfirmed = False
    If rollbackRecoveryRequired Then _
        recoveryStateConfirmed = _
            RollbackRecoveryStateIsConfirmedExact( _
                rollbackDetail, dateSafeFallbackConfirmed)
    If Not recoveryEnforceFailed And _
       (Not rollbackRecoveryRequired Or recoveryStateConfirmed) Then
        On Error Resume Next
        If rollbackRecoveryRequired Then
            AddCheck "エラー", "口座削除の復旧", rollbackDetail
            SetInputStatus "口座削除に失敗したため案件を要復旧として停止しました。" & _
                           "C_チェックを確認してください。", True
        Else
            SetInputStatus "口座削除に失敗したため、データは削除していません。"
            If Len(rollbackDetail) > 0 Then _
                AddCheck "警告", "口座削除ロールバック", rollbackDetail
        End If
        Err.Clear
        On Error GoTo 0
    End If
DELETE_PRECOMMIT_FINALIZE:
    localSafetyConfirmed = cleanupEventsStopped And _
                           (Not deleteStarted Or rollbackVerified) And _
                           Not rollbackDirtyFailed And _
                           Not inputKeyRestoreFailed And _
                           Not recoveryEnforceFailed
    leaseRestored = FinalizeRecordsApplicationLease( _
                        "口座削除の失敗復旧", _
                        applicationLeaseStarted, _
                        entryEventsCaptured, entryEvents, _
                        localSafetyConfirmed, cleanupEventsStopped, _
                        recoveryAttempted, recoveryEnforceFailed, _
                        recoveryStateConfirmed, _
                        finalizeDetail)
    AppendRecordsDetail rollbackDetail, finalizeDetail
    If Not leaseRestored Then rollbackRecoveryRequired = True
    MsgBox "口座削除中にエラーが発生しました。" & vbCrLf & _
           "Err " & errorNumber & ": " & errorDescription & _
           IIf(Len(rollbackDetail) > 0, _
               vbCrLf & "復元確認: " & rollbackDetail, "") & _
           IIf(Not leaseRestored, _
               vbCrLf & "Excelの開始状態を完全に復元できません。", _
               vbNullString), vbCritical
End Sub

Private Sub RestoreDeletedAccount(ByRef txSnapshot As Variant, ByVal txSnapshotRows As Long, _
                                  ByRef balSnapshot As Variant, ByVal balSnapshotRows As Long, _
                                  ByRef accountSnapshot As Variant, ByVal accountSnapshotRows As Long)
    Dim wsTx As Worksheet, wsBal As Worksheet, wsAcc As Worksheet
    Dim restoreProblems As String
    Set wsTx = GetSheet(SH_WORK_TX)
    Set wsBal = GetSheet(SH_WORK_BAL)
    Set wsAcc = GetSheet(SH_WORK_ACCOUNT)

    On Error Resume Next
    Err.Clear
    RestoreInternalStoreSnapshotWithPrefix wsTx, WORK_TX_COL_PERSON_ID, _
                                           txSnapshot, txSnapshotRows, "W_取引"
    If Err.Number <> 0 Then _
        AppendRecordsDetail restoreProblems, "取引保管の全体復元: " & Err.Description
    Err.Clear
    RestoreInternalStoreSnapshotWithPrefix wsBal, WORK_BAL_COL_PERSON_ID, _
                                           balSnapshot, balSnapshotRows, "W_残高"
    If Err.Number <> 0 Then _
        AppendRecordsDetail restoreProblems, "残高保管の全体復元: " & Err.Description
    Err.Clear
    RestoreInternalStoreSnapshotWithPrefix wsAcc, ACC_COL_TRANSFER_ID, _
                                           accountSnapshot, accountSnapshotRows, "W_口座"
    If Err.Number <> 0 Then _
        AppendRecordsDetail restoreProblems, "口座保管の全体復元: " & Err.Description
    Err.Clear
    FormatWorkTx
    If Err.Number <> 0 Then AppendRecordsDetail restoreProblems, "取引書式の復元: " & Err.Description
    Err.Clear
    FormatWorkBal
    If Err.Number <> 0 Then AppendRecordsDetail restoreProblems, "残高書式の復元: " & Err.Description
    Err.Clear
    InvalidateInternalIdCaches
    If Err.Number <> 0 Then AppendRecordsDetail restoreProblems, "内部ID索引の更新: " & Err.Description
    On Error GoTo 0
    If Len(restoreProblems) > 0 Then _
        Err.Raise vbObjectError + 3428, "RestoreDeletedAccount", restoreProblems
End Sub

Private Sub AppendRecordsDetail(ByRef detailText As String, ByVal newDetail As String)
    newDetail = Trim$(newDetail)
    If Len(newDetail) = 0 Then Exit Sub
    If Len(detailText) > 0 Then detailText = detailText & " / "
    detailText = detailText & newDetail
End Sub

Private Function TryGetRecordsEnableEvents( _
        ByRef currentValue As Boolean, _
        ByRef detailText As String) As Boolean
    Dim errorNumber As Long, errorDescription As String
    detailText = vbNullString
    On Error GoTo EH
    currentValue = Application.EnableEvents
    TryGetRecordsEnableEvents = True
    Exit Function
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    detailText = "Err " & CStr(errorNumber) & ": " & errorDescription
    Err.Clear
End Function

Private Function TrySetRecordsEnableEventsExact( _
        ByVal desiredValue As Boolean, _
        ByRef detailText As String) As Boolean
    Dim errorNumber As Long, errorDescription As String
    Dim actualValue As Boolean
    detailText = vbNullString
    On Error GoTo EH
    Application.EnableEvents = desiredValue
    actualValue = Application.EnableEvents
    If actualValue <> desiredValue Then _
        Err.Raise vbObjectError + 3436, _
                  "TrySetRecordsEnableEventsExact", _
                  "EnableEventsの書込み後読戻しが一致しません。"
    TrySetRecordsEnableEventsExact = True
    Exit Function
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    detailText = "Err " & CStr(errorNumber) & ": " & errorDescription
    Err.Clear
End Function

Private Function TryKeepRecordsEventsDisabledExact( _
        ByRef detailText As String) As Boolean
    Dim firstDetail As String, retryDetail As String
    detailText = vbNullString
    If TrySetRecordsEnableEventsExact(False, firstDetail) Then
        TryKeepRecordsEventsDisabledExact = True
        Exit Function
    End If
    If TrySetRecordsEnableEventsExact(False, retryDetail) Then
        TryKeepRecordsEventsDisabledExact = True
        Exit Function
    End If
    detailText = "初回=" & firstDetail & " / 再試行=" & retryDetail
End Function

Private Function TryRestoreRecordsApplicationState( _
        ByRef detailText As String, _
        ByRef applicationLeaseClosed As Boolean) As Boolean
    Dim stateProblems As String
    Dim errorNumber As Long, errorDescription As String
    detailText = vbNullString
    applicationLeaseClosed = False
    On Error GoTo EH
    AppForceRestore
    'Force呼出しが正常returnした時点で、このcallerが所有したleaseは閉じている。
    '後続の独立読戻し失敗を理由に同じ所有権を再利用しない。
    applicationLeaseClosed = True
    If Not AppStateIsRestored(stateProblems) Then _
        Err.Raise vbObjectError + 3437, _
                  "TryRestoreRecordsApplicationState", _
                  "開始時のExcel設定へ復元できません: " & stateProblems
    TryRestoreRecordsApplicationState = True
    Exit Function
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    detailText = "Err " & CStr(errorNumber) & ": " & errorDescription
    Err.Clear
End Function

Private Function TryEnterRecordsRecoveryState( _
        ByVal operationName As String, _
        ByRef eventsStopped As Boolean, _
        ByRef recoveryConfirmed As Boolean, _
        ByRef recoveryAttempted As Boolean, _
        ByRef recoveryEnforceFailed As Boolean, _
        ByRef detailText As String) As Boolean
    Dim recoveryDetail As String, stopDetail As String
    Dim dateSafeFallbackConfirmed As Boolean
    Dim enforceErrorNumber As Long
    Dim enforceErrorSource As String, enforceErrorDescription As String
    Dim applicationStateProblems As String, finalStopDetail As String
    Dim recoveryGatePassed As Boolean

    recoveryConfirmed = False
    If recoveryEnforceFailed Or recoveryAttempted Then
        '一度でもEnforce本体を試行した後は、成否にかかわらず
        '古いRecovery状態を成功扱いせず、fresh False exactだけへ収束する。
        eventsStopped = TryKeepRecordsEventsDisabledExact(stopDetail)
        If Not eventsStopped Then _
            AppendRecordsDetail detailText, _
                "Recovery強制試行後のExcelイベントFalse収束にも失敗しました: " & _
                stopDetail
        recoveryEnforceFailed = True
        Err.Raise RECORDS_RECOVERY_ENFORCE_ERROR, _
                  RECORDS_RECOVERY_HARD_BARRIER_SOURCE & _
                      "TryEnterRecordsRecoveryState/RepeatedAttempt", _
                  detailText
    End If
    If Not eventsStopped Then Exit Function
    eventsStopped = TryKeepRecordsEventsDisabledExact(stopDetail)
    If Not eventsStopped Then
        AppendRecordsDetail detailText, _
            "要復旧処理前のExcelイベント停止を確認できません: " & stopDetail
        Exit Function
    End If

    On Error Resume Next
    Err.Clear
    recoveryDetail = operationName
    If Len(detailText) > 0 Then recoveryDetail = recoveryDetail & ": " & detailText
    recoveryAttempted = True
    EnforceRollbackRecoveryState recoveryDetail
    enforceErrorNumber = Err.Number
    enforceErrorSource = Err.Source
    enforceErrorDescription = Err.Description
    Err.Clear
    'EnforceRollbackRecoveryState内の診断隔離は、外側のApplication leaseを
    '閉じることがある。Recoveryの読戻しと後続書込みより前にFalseを再確定する。
    On Error GoTo 0
    eventsStopped = TryKeepRecordsEventsDisabledExact(stopDetail)
    recoveryEnforceFailed = (enforceErrorNumber <> 0)
    If enforceErrorNumber <> 0 Then _
        AppendRecordsDetail detailText, _
            "要復旧状態の設定エラー: Err " & CStr(enforceErrorNumber) & _
            " " & enforceErrorDescription
    If enforceErrorNumber <> 0 Then
        recoveryConfirmed = False
        recoveryEnforceFailed = True
        Err.Raise RECORDS_RECOVERY_ENFORCE_ERROR, _
                  RECORDS_RECOVERY_HARD_BARRIER_SOURCE & _
                      "TryEnterRecordsRecoveryState/EnforceError", _
                  detailText
    End If
    If Not eventsStopped Then
        AppendRecordsDetail detailText, _
            "要復旧処理後のExcelイベント停止を確認できません: " & _
            stopDetail
        recoveryConfirmed = False
        recoveryEnforceFailed = True
        Err.Raise RECORDS_RECOVERY_ENFORCE_ERROR, _
                  RECORDS_RECOVERY_HARD_BARRIER_SOURCE & _
                      "TryEnterRecordsRecoveryState/PostFalseFailed", _
                  detailText
    End If
    recoveryConfirmed = _
        RollbackRecoveryStateIsConfirmedExact( _
            recoveryDetail, dateSafeFallbackConfirmed)
    If Len(recoveryDetail) > 0 Then _
        AppendRecordsDetail detailText, recoveryDetail
    recoveryGatePassed = recoveryConfirmed
    If recoveryGatePassed Then
        applicationStateProblems = vbNullString
        If Not AppStateIsRestored(applicationStateProblems) Then
            recoveryGatePassed = False
            AppendRecordsDetail detailText, _
                "Recovery後にApplication状態の安全を確認できません: " & _
                applicationStateProblems
        End If
    End If
    finalStopDetail = vbNullString
    eventsStopped = TryKeepRecordsEventsDisabledExact(finalStopDetail)
    If Not eventsStopped Then
        recoveryGatePassed = False
        AppendRecordsDetail detailText, _
            "Recovery成功返却直前のExcelイベント停止を確認できません: " & _
            finalStopDetail
    End If
    recoveryConfirmed = False
    recoveryEnforceFailed = True
    If recoveryGatePassed And eventsStopped Then
        Err.Raise RECORDS_RECOVERY_ENFORCE_ERROR, _
                  RECORDS_RECOVERY_HARD_BARRIER_SOURCE & _
                      "TryEnterRecordsRecoveryState/EnforceReturned", _
                  detailText
    End If
    Err.Raise RECORDS_RECOVERY_ENFORCE_ERROR, _
              RECORDS_RECOVERY_HARD_BARRIER_SOURCE & _
                  "TryEnterRecordsRecoveryState/RecoveryGateFailed", _
              detailText
End Function

Private Function TryRestoreRecordsEntryEvents( _
        ByVal entryValue As Boolean, _
        ByVal operationName As String, _
        ByVal recoveryWritesAllowed As Boolean, _
        ByRef recoveryConfirmed As Boolean, _
        ByRef recoveryAttempted As Boolean, _
        ByRef recoveryEnforceFailed As Boolean, _
        ByRef detailText As String) As Boolean
    Dim firstDetail As String, retryDetail As String
    Dim stopDetail As String, finalDetail As String, convergenceDetail As String
    Dim eventsStopped As Boolean
    Dim stateProblems As String, dateSafeFallbackConfirmed As Boolean

    If recoveryEnforceFailed Then
        eventsStopped = TryKeepRecordsEventsDisabledExact(stopDetail)
        If Not eventsStopped Then _
            AppendRecordsDetail detailText, _
                "Recovery設定エラー後のExcelイベントFalse収束にも失敗しました: " & _
                stopDetail
        Err.Raise RECORDS_RECOVERY_ENFORCE_ERROR, _
                  RECORDS_RECOVERY_HARD_BARRIER_SOURCE & _
                      "TryRestoreRecordsEntryEvents/EnforceError", _
                  detailText
    End If
    If recoveryAttempted And Not recoveryConfirmed Then
        eventsStopped = TryKeepRecordsEventsDisabledExact(stopDetail)
        If Not eventsStopped Then _
            AppendRecordsDetail detailText, _
                "Recovery強制試行後のExcelイベントFalse収束にも失敗しました: " & _
                stopDetail
        Err.Raise RECORDS_RECOVERY_ENFORCE_ERROR, _
                  RECORDS_RECOVERY_HARD_BARRIER_SOURCE & _
                      "TryRestoreRecordsEntryEvents/EnforceReturned", _
                  detailText
    End If

    If TrySetRecordsEnableEventsExact(entryValue, firstDetail) Then
        TryRestoreRecordsEntryEvents = True
        Exit Function
    End If
    If TrySetRecordsEnableEventsExact(entryValue, retryDetail) Then
        TryRestoreRecordsEntryEvents = True
        Exit Function
    End If
    AppendRecordsDetail detailText, _
        "Excelイベントを開始値へ復元できません。初回=" & firstDetail & _
        " / 再試行=" & retryDetail

    eventsStopped = TryKeepRecordsEventsDisabledExact(stopDetail)
    If Not eventsStopped Then
        AppendRecordsDetail detailText, _
            "Recovery記録前のExcelイベント停止に失敗しました: " & _
            stopDetail
        Exit Function
    End If
    If Not entryValue Then
        '開始値自体がFalseなら、三回目のexact停止でleaseは復元済みである。
        TryRestoreRecordsEntryEvents = True
        Exit Function
    End If

    If Not recoveryWritesAllowed Then
        AppendRecordsDetail detailText, _
            "失敗復旧開始時のイベント停止が未確認だったため、Recovery書込みを実行しません。"
        Exit Function
    End If
    If Not AppStateIsRestored(stateProblems) Then
        AppendRecordsDetail detailText, _
            "Application状態が安全に復元されていないため、Recovery診断と" & _
            "開始値Trueへの最終再試行を行いません。 " & stateProblems
        Exit Function
    End If

    Call TryEnterRecordsRecoveryState( _
             operationName & "のイベント復元失敗", _
             eventsStopped, recoveryConfirmed, recoveryAttempted, _
             recoveryEnforceFailed, detailText)
    If recoveryEnforceFailed Then
        recoveryConfirmed = False
        AppendRecordsDetail detailText, _
            "Recovery設定自体が失敗したため、開始値Trueへの最終再試行を行いません。"
        Exit Function
    End If
    eventsStopped = TryKeepRecordsEventsDisabledExact(stopDetail)
    If Not eventsStopped Then
        AppendRecordsDetail detailText, _
            "Recovery後のExcelイベント停止を確認できません: " & stopDetail
        Exit Function
    End If
    dateSafeFallbackConfirmed = False
    If recoveryConfirmed Then
        recoveryConfirmed = _
            RollbackRecoveryStateIsConfirmedExact( _
                detailText, dateSafeFallbackConfirmed)
    End If
    If Not recoveryConfirmed Then
        AppendRecordsDetail detailText, _
            "Recovery二重状態を一意に確認できないため、診断書込みと" & _
            "開始値Trueへの最終再試行を行いません。"
        Exit Function
    End If
    stateProblems = vbNullString
    If Not AppStateIsRestored(stateProblems) Then
        AppendRecordsDetail detailText, _
            "Recovery後のApplication状態を安全に確認できないため、" & _
            "開始値Trueへの最終再試行を行いません。 " & stateProblems
        Exit Function
    End If

    On Error Resume Next
    AddCheck "エラー", operationName & "のExcelイベント復元", detailText
    SetInputStatus operationName & _
        "後にExcelイベントを開始状態へ戻せないため、案件を要復旧として停止しました。", _
        True
    Err.Clear
    On Error GoTo 0

    '最後のブック書込み後にもRecovery二重状態・False・Application状態を再確認する。
    eventsStopped = TryKeepRecordsEventsDisabledExact(stopDetail)
    If Not eventsStopped Then
        AppendRecordsDetail detailText, _
            "最終再試行前のExcelイベント停止を維持できません: " & stopDetail
        Exit Function
    End If
    dateSafeFallbackConfirmed = False
    recoveryConfirmed = _
        RollbackRecoveryStateIsConfirmedExact( _
            detailText, dateSafeFallbackConfirmed)
    If Not recoveryConfirmed Then
        AppendRecordsDetail detailText, _
            "最終再試行前にRecovery二重状態を確認できず、イベントをFalseに維持しました。"
        Exit Function
    End If
    stateProblems = vbNullString
    If Not AppStateIsRestored(stateProblems) Then
        AppendRecordsDetail detailText, _
            "最終再試行前にApplication状態を確認できず、イベントをFalseに維持しました。 " & _
            stateProblems
        Exit Function
    End If

    If TrySetRecordsEnableEventsExact(entryValue, finalDetail) Then
        TryRestoreRecordsEntryEvents = True
        Exit Function
    End If
    AppendRecordsDetail detailText, _
        "安全停止後も開始値へ復元できません: " & finalDetail
    If TryKeepRecordsEventsDisabledExact(convergenceDetail) Then
        AppendRecordsDetail detailText, _
            "安全停止のためExcelイベントをFalseへ戻しました。"
    Else
        AppendRecordsDetail detailText, _
            "ExcelイベントのFalse収束にも失敗しました: " & _
            convergenceDetail
    End If
End Function

Private Function FinalizeRecordsApplicationLease( _
        ByVal operationName As String, _
        ByRef applicationLeaseStarted As Boolean, _
        ByVal entryEventsCaptured As Boolean, _
        ByVal entryEvents As Boolean, _
        ByVal localSafetyConfirmed As Boolean, _
        ByVal recoveryWritesAllowed As Boolean, _
        ByRef recoveryAttempted As Boolean, _
        ByRef recoveryEnforceFailed As Boolean, _
        ByRef recoveryConfirmed As Boolean, _
        ByRef detailText As String) As Boolean
    Dim applicationRestored As Boolean, entryEventsRestored As Boolean
    Dim eventsStopped As Boolean, restoreFailed As Boolean
    Dim recoveryGateRequired As Boolean, safetyGatePassed As Boolean
    Dim applicationLeaseClosed As Boolean
    Dim applicationDetail As String, stopDetail As String, stateProblems As String
    Dim dateSafeFallbackConfirmed As Boolean

    If recoveryEnforceFailed Then GoTo ENFORCE_FAILED_CONVERGENCE
    If recoveryAttempted And Not recoveryConfirmed Then _
        GoTo RECOVERY_ATTEMPTED_CONVERGENCE

    If applicationLeaseStarted Then
        applicationRestored = _
            TryRestoreRecordsApplicationState( _
                applicationDetail, applicationLeaseClosed)
        If applicationLeaseClosed Then applicationLeaseStarted = False
    Else
        'AppBeginが正常returnしていない経路では、所有していないleaseへ
        'AppEnd/AppForceRestoreを実行せず、現在状態の読戻しだけを行う。
        applicationRestored = AppStateIsRestored(stateProblems)
        If Not applicationRestored Then _
            applicationDetail = "所有していないApplication leaseは復元できません: " & _
                                stateProblems
    End If
    If Not applicationRestored Then
        restoreFailed = True
        AppendRecordsDetail detailText, _
            "Excel状態の復元エラー: " & applicationDetail
        If recoveryWritesAllowed Then
            eventsStopped = TryKeepRecordsEventsDisabledExact(stopDetail)
            If eventsStopped Then
                Call TryEnterRecordsRecoveryState( _
                         operationName & "のExcel状態復元失敗", _
                         eventsStopped, recoveryConfirmed, _
                         recoveryAttempted, recoveryEnforceFailed, detailText)
                If recoveryEnforceFailed Then GoTo ENFORCE_FAILED_CONVERGENCE
                If recoveryAttempted And Not recoveryConfirmed Then _
                    GoTo RECOVERY_ATTEMPTED_CONVERGENCE
                eventsStopped = _
                    TryKeepRecordsEventsDisabledExact(stopDetail)
                If Not eventsStopped Then _
                    AppendRecordsDetail detailText, _
                        "Recovery後のイベント停止を確認できません: " & stopDetail
            Else
                AppendRecordsDetail detailText, _
                    "Excel状態失敗後のイベント安全停止を確認できません: " & _
                    stopDetail
            End If
        End If
        If eventsStopped And applicationLeaseStarted Then
            applicationDetail = vbNullString
            applicationLeaseClosed = False
            applicationRestored = _
                TryRestoreRecordsApplicationState( _
                    applicationDetail, applicationLeaseClosed)
            If applicationLeaseClosed Then applicationLeaseStarted = False
            If Not applicationRestored Then _
                AppendRecordsDetail detailText, _
                    "Excel状態の最終復元にも失敗しました: " & _
                    applicationDetail
        End If
    End If

    '外側restoreやEnforceが状態を変更した可能性を捨て、最終ゲートを独立に再確認する。
    eventsStopped = TryKeepRecordsEventsDisabledExact(stopDetail)
    If Not eventsStopped Then _
        AppendRecordsDetail detailText, _
            "開始時イベント復元前にFalseを確認できません: " & stopDetail
    If applicationRestored Then
        stateProblems = vbNullString
        applicationRestored = AppStateIsRestored(stateProblems)
    End If
    If Not applicationRestored And Len(stateProblems) > 0 Then _
        AppendRecordsDetail detailText, _
            "開始時イベント復元前のApplication状態が不安全です: " & stateProblems

    recoveryGateRequired = Not localSafetyConfirmed Or restoreFailed
    If recoveryGateRequired And recoveryConfirmed Then
        '呼出元でRecoveryを確認済みでも、Finalize自身のpost-Falseの後で
        '二重状態を読み直し、続けてApplication安全も再確認する。
        If eventsStopped Then
            dateSafeFallbackConfirmed = False
            recoveryConfirmed = _
                RollbackRecoveryStateIsConfirmedExact( _
                    detailText, dateSafeFallbackConfirmed)
        Else
            recoveryConfirmed = False
        End If
        If recoveryAttempted And Not recoveryConfirmed Then _
            GoTo RECOVERY_ATTEMPTED_CONVERGENCE
        If applicationRestored Then
            stateProblems = vbNullString
            applicationRestored = AppStateIsRestored(stateProblems)
        End If
    End If
    If recoveryGateRequired And Not recoveryConfirmed And _
       recoveryWritesAllowed And eventsStopped And applicationRestored Then
        Call TryEnterRecordsRecoveryState( _
                 operationName & "の最終安全ゲート", _
                 eventsStopped, recoveryConfirmed, _
                 recoveryAttempted, recoveryEnforceFailed, detailText)
        If recoveryEnforceFailed Then GoTo ENFORCE_FAILED_CONVERGENCE
        If recoveryAttempted And Not recoveryConfirmed Then _
            GoTo RECOVERY_ATTEMPTED_CONVERGENCE
        eventsStopped = TryKeepRecordsEventsDisabledExact(stopDetail)
        If recoveryConfirmed And eventsStopped Then
            dateSafeFallbackConfirmed = False
            recoveryConfirmed = _
                RollbackRecoveryStateIsConfirmedExact( _
                    detailText, dateSafeFallbackConfirmed)
        Else
            recoveryConfirmed = False
        End If
        If recoveryAttempted And Not recoveryConfirmed Then _
            GoTo RECOVERY_ATTEMPTED_CONVERGENCE
        If applicationRestored Then
            stateProblems = vbNullString
            applicationRestored = AppStateIsRestored(stateProblems)
        End If
    End If
    safetyGatePassed = _
        (localSafetyConfirmed And Not restoreFailed) Or recoveryConfirmed

    If restoreFailed And recoveryConfirmed And eventsStopped And _
       applicationRestored Then
        On Error Resume Next
        AddCheck "エラー", operationName & "のExcel状態復元", detailText
        SetInputStatus operationName & _
            "後のExcel状態復元で異常を検出したため、案件を要復旧として停止しました。", _
            True
        Err.Clear
        On Error GoTo 0
        eventsStopped = TryKeepRecordsEventsDisabledExact(stopDetail)
        If eventsStopped Then
            dateSafeFallbackConfirmed = False
            recoveryConfirmed = _
                RollbackRecoveryStateIsConfirmedExact( _
                    detailText, dateSafeFallbackConfirmed)
            If recoveryAttempted And Not recoveryConfirmed Then _
                GoTo RECOVERY_ATTEMPTED_CONVERGENCE
            If applicationRestored Then
                stateProblems = vbNullString
                applicationRestored = AppStateIsRestored(stateProblems)
            End If
            safetyGatePassed = _
                (localSafetyConfirmed And Not restoreFailed) Or _
                recoveryConfirmed
        End If
    End If

    If Not entryEventsCaptured Then
        AppendRecordsDetail detailText, _
            "Excelイベントの開始状態を取得できていません。"
        Exit Function
    End If
    If Not entryEvents Then
        entryEventsRestored = TryKeepRecordsEventsDisabledExact(stopDetail)
        If Not entryEventsRestored Then _
            AppendRecordsDetail detailText, _
                "開始値FalseへExcelイベントを復元できません: " & stopDetail
        FinalizeRecordsApplicationLease = _
            entryEventsRestored And applicationRestored And _
            safetyGatePassed And Not restoreFailed
        Exit Function
    End If
    If Not eventsStopped Or Not applicationRestored Or Not safetyGatePassed Then
        AppendRecordsDetail detailText, _
            "局所rollback・保護安全、またはRecovery二重確認と" & _
            "Application安全の最終ゲートが成立しないため、" & _
            "開始値Trueへイベントを復元しません。"
        eventsStopped = TryKeepRecordsEventsDisabledExact(stopDetail)
        If Not eventsStopped Then _
            AppendRecordsDetail detailText, _
                "ExcelイベントのFalse収束にも失敗しました: " & stopDetail
        Exit Function
    End If
    entryEventsRestored = TryRestoreRecordsEntryEvents( _
                              entryEvents, operationName, _
                              recoveryWritesAllowed, recoveryConfirmed, _
                              recoveryAttempted, recoveryEnforceFailed, _
                              detailText)
    FinalizeRecordsApplicationLease = _
        entryEventsRestored And applicationRestored And _
        safetyGatePassed And Not restoreFailed
    Exit Function

RECOVERY_ATTEMPTED_CONVERGENCE:
    '一度Enforceが正常returnした後でも、freshな二重読戻しが失敗したら
    '再Enforce・診断・Application読戻し・開始値True復元を禁止する。
    recoveryConfirmed = False
    eventsStopped = TryKeepRecordsEventsDisabledExact(stopDetail)
    If Not eventsStopped Then _
        AppendRecordsDetail detailText, _
            "Recovery強制試行後のExcelイベントFalse収束にも失敗しました: " & _
            stopDetail
    recoveryEnforceFailed = True
    Err.Raise RECORDS_RECOVERY_ENFORCE_ERROR, _
              RECORDS_RECOVERY_HARD_BARRIER_SOURCE & _
                  "FinalizeRecordsApplicationLease/EnforceReturned", _
              detailText

ENFORCE_FAILED_CONVERGENCE:
    'Enforce本体のerror後は、stale Recovery読戻し、診断、Application再復元、
    '開始値Trueへの復元をすべて禁止し、fresh False exactだけへ収束する。
    recoveryConfirmed = False
    eventsStopped = TryKeepRecordsEventsDisabledExact(stopDetail)
    If Not eventsStopped Then
        AppendRecordsDetail detailText, _
            "Recovery設定エラー後のExcelイベントFalse収束にも失敗しました: " & _
            stopDetail
    ElseIf entryEventsCaptured And Not entryEvents Then
        AppendRecordsDetail detailText, _
            "開始値Falseを維持しましたが、Recovery設定エラーのため終了状態を成功扱いしません。"
    Else
        AppendRecordsDetail detailText, _
            "Recovery設定エラーのため開始値Trueへイベントを復元せず、Falseに維持しました。"
    End If
    Err.Raise RECORDS_RECOVERY_ENFORCE_ERROR, _
              RECORDS_RECOVERY_HARD_BARRIER_SOURCE & _
                  "FinalizeRecordsApplicationLease/EnforceError", _
              detailText
End Function

Private Function VerifyDeletedAccountRestore(ByRef txSnapshot As Variant, ByVal txSnapshotRows As Long, _
                                             ByRef balSnapshot As Variant, ByVal balSnapshotRows As Long, _
                                             ByRef accountSnapshot As Variant, _
                                             ByVal accountSnapshotRows As Long) As String
    Dim problems As String
    If Not InternalStoreMatchesSnapshotWithPrefix(GetSheet(SH_WORK_TX), _
            WORK_TX_COL_PERSON_ID, txSnapshot, txSnapshotRows) Then _
        problems = problems & "取引保管の行位置・全列・型・接頭辞が削除前と一致しません。 "
    If Not InternalStoreMatchesSnapshotWithPrefix(GetSheet(SH_WORK_BAL), _
            WORK_BAL_COL_PERSON_ID, balSnapshot, balSnapshotRows) Then _
        problems = problems & "残高保管の行位置・全列・型・接頭辞が削除前と一致しません。 "
    If Not InternalStoreMatchesSnapshotWithPrefix(GetSheet(SH_WORK_ACCOUNT), _
            ACC_COL_TRANSFER_ID, accountSnapshot, accountSnapshotRows) Then _
        problems = problems & "口座保管の行位置・全列・型・接頭辞が削除前と一致しません。 "
    VerifyDeletedAccountRestore = Trim$(problems)
End Function

Public Sub LoadSelectedAccountForEdit()
    Dim ws As Worksheet
    Dim r As Long, accountID As String
    If Not RequireToolReady() Then Exit Sub
    If ActiveSheet Is Nothing Then Exit Sub
    If ActiveSheet.Name <> SH_REGISTERED_ACCOUNTS Then Exit Sub
    Set ws = ActiveSheet
    r = ActiveCell.Row
    If r < 4 Then
        SetInputStatus "訂正する口座の行を選択してください。"
        Exit Sub
    End If
    accountID = CellText(ws.Cells(r, 13).Value)
    If Len(accountID) = 0 Then Exit Sub
    If IsEditMode() Then
        If MsgBox("現在の訂正入力を破棄し、選択した口座を読み込みますか？", _
                  vbYesNo + vbExclamation + vbDefaultButton2, "訂正対象の切替確認") <> vbYes Then Exit Sub
    ElseIf CurrentAccountInputHasData() Then
        If MsgBox("現在の未登録入力を破棄し、選択した口座を訂正画面へ読み込みますか？", _
                  vbYesNo + vbExclamation + vbDefaultButton2, "未登録入力の破棄確認") <> vbYes Then Exit Sub
    End If
    LoadAccountForEdit accountID
End Sub

Public Sub LoadAccountForEdit(ByVal accountID As String)
    Dim wsIn As Worksheet, wsAcc As Worksheet
    Dim accR As Long
    Dim txCount As Long
    Dim editableTransactionRows As Long
    Dim previousEditAccountID As String
    Dim inputSnapshot As Variant
    Dim protectionSnapshot As InputProtectionSnapshot
    Dim loadStarted As Boolean, snapshotCaptured As Boolean, rollbackRestored As Boolean
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim nestedErrorNumber As Long, nestedErrorDescription As String
    Dim nestedErrorSource As String, rollbackDetail As String
    Dim cleanupErrorNumber As Long, cleanupErrorDescription As String
    Dim cleanupErrorSource As String
    Dim restoredEditAccountID As String, stoppedDateConfigSafe As String
    Dim safetyStateFailed As Boolean, recoveryStateConfirmed As Boolean
    Dim recoveryAttempted As Boolean, recoveryEnforceFailed As Boolean
    Dim entryEvents As Boolean, entryEventsCaptured As Boolean
    Dim cleanupEventsStopped As Boolean, leaseRestored As Boolean
    Dim applicationLeaseStarted As Boolean, localSafetyConfirmed As Boolean
    Dim eventDetail As String, finalizeDetail As String

    If Not RequireToolReady() Then Exit Sub
    If Not RequireWritableWorkbook("訂正データの読み込み") Then Exit Sub
    '訂正対象の安全確認は内部保管だけへ限定する。画面幅・図形・未更新帳票など
    If Not RequireInternalStoresSafeForWrite(False, False) Then Exit Sub
    If Not TryGetExactStateValue(STATE_EDIT_ACCOUNT, previousEditAccountID) Then
        SetInputStatus "訂正状態を一意に読み取れないため読み込みを中止しました。C_チェックを確認してください。"
        Exit Sub
    End If
    On Error GoTo EH
    accR = FindAccountRowByID(accountID)
    If accR = 0 Then Exit Sub
    txCount = CountAccountRecords(GetSheet(SH_WORK_TX), WORK_TX_COL_ACCOUNT_ID, accountID, RECORD_TRANSACTION)
    editableTransactionRows = TX_LAST_ROW - TX_FIRST_ROW + 1
    If txCount > editableTransactionRows Then
        SetInputStatus "この口座の取引は" & Format$(txCount, "#,##0") & _
                       "件あり、訂正画面の上限" & Format$(editableTransactionRows, "#,##0") & _
                       "件を超えるため、1件も読み込んでいません。"
        MsgBox "この口座には取引が" & Format$(txCount, "#,##0") & "件あります。" & vbCrLf & _
               "訂正画面で安全に扱える上限は" & _
               Format$(editableTransactionRows, "#,##0") & "件のため、一部だけを表示せず処理を中止しました。" & _
               vbCrLf & vbCrLf & _
               "外部データを期間などで分割して別の案件へ取り込むか、取込元の原本にある不要行・重複行を整理してください。", _
               vbExclamation, "取引件数が訂正画面の上限を超えています"
        Exit Sub
    End If

    CaptureInputProtection GetSheet(SH_INPUT), protectionSnapshot
    inputSnapshot = CaptureInputForEditLoad(GetSheet(SH_INPUT))
    snapshotCaptured = True
    If Not TryGetRecordsEnableEvents(entryEvents, eventDetail) Then _
        Err.Raise vbObjectError + 3443, "LoadAccountForEdit", _
                  "Excelイベントの開始状態を取得できません: " & eventDetail
    entryEventsCaptured = True
    AppBegin "登録済み口座を読み込んでいます..."
    applicationLeaseStarted = True
    If Not TryKeepRecordsEventsDisabledExact(eventDetail) Then _
        Err.Raise vbObjectError + 3443, "LoadAccountForEdit", _
                  "訂正読込前にExcelイベントを停止できません: " & eventDetail
    loadStarted = True
    ClearInputForRecordLoad
    Set wsIn = GetSheet(SH_INPUT)
    Set wsAcc = GetSheet(SH_WORK_ACCOUNT)
    wsIn.Unprotect Password:=TOOL_PASSWORD
    wsIn.Range(CELL_BANK).Value = wsAcc.Cells(accR, ACC_COL_BANK).Value
    wsIn.Range(CELL_BRANCH).Value = wsAcc.Cells(accR, ACC_COL_BRANCH).Value
    wsIn.Range(CELL_PERSON).Value = wsAcc.Cells(accR, ACC_COL_PERSON).Value
    wsIn.Range(CELL_RELATIONSHIP).Value = wsAcc.Cells(accR, ACC_COL_RELATIONSHIP).Value
    wsIn.Range(CELL_ACCOUNT_TYPE).Value = wsAcc.Cells(accR, ACC_COL_TYPE).Value
    wsIn.Range(CELL_ACCOUNT_NO).Value = wsAcc.Cells(accR, ACC_COL_NO).Value
    wsIn.Range(CELL_OPEN_DATE).Value = wsAcc.Cells(accR, ACC_COL_OPEN_DATE).Value
    wsIn.Range(CELL_CLOSE_DATE).Value = wsAcc.Cells(accR, ACC_COL_CLOSE_DATE).Value

    LoadBalancesForEdit wsIn, accountID
    LoadTransactionsForEdit wsIn, accountID
    SetEditAccountID accountID
    ApplyBalanceAvailability wsIn
    ProtectInputSheet True
    wsIn.Visible = xlSheetVisible
    wsIn.Activate
    SafeSelectCell wsIn, CELL_BANK
    If Not TryKeepRecordsEventsDisabledExact(eventDetail) Then _
        Err.Raise vbObjectError + 3443, "LoadAccountForEdit", _
                  "訂正読込後にExcelイベント停止を維持できません: " & eventDetail
    cleanupEventsStopped = True
    EnableInputKeys
    SetInputStatus "訂正中　内容を直して「訂正を反映」を押してください。"
    localSafetyConfirmed = True
    leaseRestored = FinalizeRecordsApplicationLease( _
                        "登録済み口座の訂正読込", _
                        applicationLeaseStarted, _
                        entryEventsCaptured, entryEvents, _
                        localSafetyConfirmed, True, _
                        recoveryAttempted, recoveryEnforceFailed, _
                        recoveryStateConfirmed, _
                        finalizeDetail)
    If Not leaseRestored Then
        MsgBox "訂正データは読み込みましたが、Excelの開始状態を安全に復元できませんでした。" & _
               vbCrLf & finalizeDetail, vbCritical, _
               "訂正読込後のExcel状態を確認できません"
    End If
    Exit Sub
EH:
    errorNumber = Err.Number
    errorSource = Err.Source
    errorDescription = Err.Description
    If IsRecordsClearRecoveryFatal(errorNumber, errorSource) Then
        cleanupEventsStopped = _
            TryKeepRecordsEventsDisabledExact(eventDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    If IsRecordsRecoveryHardBarrier(errorNumber, errorSource) Then
        Call TryKeepRecordsEventsDisabledExact(eventDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    cleanupEventsStopped = False
    eventDetail = vbNullString
    If entryEventsCaptured Then _
        cleanupEventsStopped = _
            TryKeepRecordsEventsDisabledExact(eventDetail)
    If Not cleanupEventsStopped Then
        AppendRecordsDetail rollbackDetail, _
            "失敗復旧開始時のExcelイベント停止を確認できないため、" & _
            "入力・保護・状態・診断・キー設定へ書き込んでいません。" & _
            IIf(Len(eventDetail) > 0, " " & eventDetail, vbNullString)
        leaseRestored = FinalizeRecordsApplicationLease( _
                            "登録済み口座の訂正読込失敗復旧", _
                            applicationLeaseStarted, _
                            entryEventsCaptured, entryEvents, _
                            False, False, _
                            recoveryAttempted, recoveryEnforceFailed, _
                            recoveryStateConfirmed, _
                            finalizeDetail)
        AppendRecordsDetail rollbackDetail, finalizeDetail
        MsgBox "訂正データの読込中にエラーが発生し、Excelイベントの安全状態も確認できません。" & _
               vbCrLf & "現在のブックを上書きせず、Excelを再起動してください。" & _
               vbCrLf & "Err " & CStr(errorNumber) & ": " & _
               errorDescription & vbCrLf & rollbackDetail, _
               vbCritical, "訂正読込・状態不明"
        Exit Sub
    End If
    If loadStarted And snapshotCaptured Then
        On Error Resume Next
        RestoreInputAfterEditLoad GetSheet(SH_INPUT), inputSnapshot, previousEditAccountID, protectionSnapshot
        nestedErrorNumber = Err.Number
        nestedErrorSource = Err.Source
        nestedErrorDescription = Err.Description
        If IsRecordsRecoveryHardBarrier( _
               nestedErrorNumber, nestedErrorSource) Then
            Err.Clear
            Call TryKeepRecordsEventsDisabledExact(eventDetail)
            On Error GoTo 0
            Err.Raise nestedErrorNumber, nestedErrorSource, _
                      nestedErrorDescription
        End If
        If Err.Number <> 0 Then
            rollbackDetail = " / 読込前入力の復元エラー: " & Err.Description
        Else
            rollbackRestored = True
        End If
        On Error GoTo 0
    ElseIf protectionSnapshot.Captured Then
        'スナップショット取得後、AppBeginが失敗しただけならシートは未変更。
        '元のカスタム保護を標準保護で上書きせず、取得済み状態との一致を厳密に確認する。
        On Error Resume Next
        Err.Clear
        AssertInputProtection GetSheet(SH_INPUT), protectionSnapshot
        If Err.Number <> 0 Then
            rollbackDetail = " / 読込開始前の入力シート保護照合エラー: " & Err.Description
        ElseIf Not TryGetExactStateValue(STATE_EDIT_ACCOUNT, restoredEditAccountID) Then
            rollbackDetail = " / 読込開始前の訂正IDを一意に読み返せません。"
        ElseIf StrComp(restoredEditAccountID, previousEditAccountID, vbBinaryCompare) <> 0 Then
            rollbackDetail = " / 読込開始前の訂正IDが変化しています。"
        Else
            rollbackRestored = True
        End If
        On Error GoTo 0
    Else
        '保護退避より前の失敗も、読込書込みはまだ始まっていない。
        '訂正IDが変化していないことだけを確認し、シート保護を上書きしない。
        On Error Resume Next
        Err.Clear
        If Not TryGetExactStateValue(STATE_EDIT_ACCOUNT, restoredEditAccountID) Then
            rollbackDetail = " / 読込準備中の訂正IDを一意に読み返せません。"
        ElseIf StrComp(restoredEditAccountID, previousEditAccountID, vbBinaryCompare) <> 0 Then
            rollbackDetail = " / 読込準備中の訂正IDが変化しています。"
        Else
            rollbackRestored = True
        End If
        On Error GoTo 0
    End If
    cleanupEventsStopped = _
        TryKeepRecordsEventsDisabledExact(eventDetail)
    If Not cleanupEventsStopped Then
        AppendRecordsDetail rollbackDetail, _
            "入力復元後のExcelイベント停止を確認できないため、" & _
            "以後の保護・状態・診断・キー設定へ書き込んでいません: " & _
            eventDetail
        GoTo LOAD_ACCOUNT_FINALIZE
    End If
    On Error Resume Next
    Err.Clear
    If Not rollbackRestored Then ProtectInputSheet True
    cleanupErrorNumber = Err.Number
    cleanupErrorDescription = Err.Description
    cleanupErrorSource = Err.Source
    Err.Clear
    On Error GoTo 0
    If IsRecordsRecoveryHardBarrier( _
           cleanupErrorNumber, cleanupErrorSource) Then
        cleanupEventsStopped = _
            TryKeepRecordsEventsDisabledExact(eventDetail)
        Err.Raise cleanupErrorNumber, cleanupErrorSource, _
                  cleanupErrorDescription
    End If
    If cleanupErrorNumber <> 0 Then
        AppendRecordsDetail rollbackDetail, _
            "入力シート再保護エラー: Err " & _
            CStr(cleanupErrorNumber) & " " & cleanupErrorDescription
        safetyStateFailed = True
    End If
    cleanupEventsStopped = _
        TryKeepRecordsEventsDisabledExact(eventDetail)
    If Not cleanupEventsStopped Then
        AppendRecordsDetail rollbackDetail, _
            "入力シート保護後のExcelイベント停止を確認できないため、" & _
            "以後の状態・診断・キー設定へ書き込んでいません: " & _
            eventDetail
        GoTo LOAD_ACCOUNT_FINALIZE
    End If

    If Not rollbackRestored Then safetyStateFailed = True
    If Len(rollbackDetail) > 0 Then
        On Error Resume Next
        Err.Clear
        SetStateValue STATE_INPUT_DATE_CONFIG_SAFE, STATE_FALSE
        cleanupErrorNumber = Err.Number
        cleanupErrorDescription = Err.Description
        Err.Clear
        If cleanupErrorNumber <> 0 Then
            AppendRecordsDetail rollbackDetail, _
                "登録停止状態の記録エラー: Err " & _
                CStr(cleanupErrorNumber) & " " & cleanupErrorDescription
            safetyStateFailed = True
        ElseIf Not TryGetExactStateValue( _
                         STATE_INPUT_DATE_CONFIG_SAFE, _
                         stoppedDateConfigSafe) Then
            AppendRecordsDetail rollbackDetail, _
                "登録停止状態を一意に読み返せません。"
            safetyStateFailed = True
        ElseIf stoppedDateConfigSafe <> STATE_FALSE Then
            AppendRecordsDetail rollbackDetail, _
                "登録停止状態が反映されていません。"
            safetyStateFailed = True
        End If
        Err.Clear
        On Error GoTo 0
    End If
    If safetyStateFailed Then
        Call TryEnterRecordsRecoveryState( _
                 "訂正読込ロールバック不成立", _
                 cleanupEventsStopped, recoveryStateConfirmed, _
                 recoveryAttempted, recoveryEnforceFailed, _
                 rollbackDetail)
        If recoveryEnforceFailed Or _
           (recoveryAttempted And Not recoveryStateConfirmed) Or _
           Not cleanupEventsStopped Then _
            GoTo LOAD_ACCOUNT_FINALIZE
    End If

    On Error Resume Next
    Err.Clear
    EnableInputKeys
    cleanupErrorNumber = Err.Number
    cleanupErrorDescription = Err.Description
    Err.Clear
    On Error GoTo 0
    If cleanupErrorNumber <> 0 Then
        AppendRecordsDetail rollbackDetail, _
            "入力キー復旧エラー: Err " & CStr(cleanupErrorNumber) & _
            " " & cleanupErrorDescription
        safetyStateFailed = True
        Call TryEnterRecordsRecoveryState( _
                 "訂正読込失敗後の入力キー復旧失敗", _
                 cleanupEventsStopped, recoveryStateConfirmed, _
                 recoveryAttempted, recoveryEnforceFailed, _
                 rollbackDetail)
        If recoveryEnforceFailed Or _
           (recoveryAttempted And Not recoveryStateConfirmed) Or _
           Not cleanupEventsStopped Then _
            GoTo LOAD_ACCOUNT_FINALIZE
    End If

    localSafetyConfirmed = cleanupEventsStopped And _
                           rollbackRestored And Not safetyStateFailed
    If Not recoveryEnforceFailed And _
       (localSafetyConfirmed Or recoveryStateConfirmed) Then
        On Error Resume Next
        If Len(rollbackDetail) = 0 Then
            SetInputStatus _
                "登録済み口座を読み込めませんでした。読込前の入力を復元しました。"
        Else
            AddCheck "エラー", "訂正読込ロールバック", rollbackDetail
            If recoveryStateConfirmed Then
                SetInputStatus _
                    "登録済み口座の読込と入力復元に失敗したため、案件を要復旧として停止しました。", _
                    True
            Else
                SetInputStatus _
                    "登録済み口座を読み込めませんでした。読込前の入力と保護を復元しました。", _
                    True
            End If
        End If
        Err.Clear
        On Error GoTo 0
    End If
LOAD_ACCOUNT_FINALIZE:
    localSafetyConfirmed = cleanupEventsStopped And _
                           rollbackRestored And Not safetyStateFailed And _
                           Not recoveryEnforceFailed
    leaseRestored = FinalizeRecordsApplicationLease( _
                        "登録済み口座の訂正読込失敗復旧", _
                        applicationLeaseStarted, _
                        entryEventsCaptured, entryEvents, _
                        localSafetyConfirmed, cleanupEventsStopped, _
                        recoveryAttempted, recoveryEnforceFailed, _
                        recoveryStateConfirmed, _
                        finalizeDetail)
    AppendRecordsDetail rollbackDetail, finalizeDetail
    MsgBox "訂正データの読込中にエラーが発生しました。" & vbCrLf & _
           "Err " & errorNumber & ": " & errorDescription & _
           IIf(Len(rollbackDetail) > 0, _
               vbCrLf & "復旧確認: " & rollbackDetail, vbNullString) & _
           IIf(Not leaseRestored, _
               vbCrLf & "Excelの開始状態を完全に復元できません。", _
               vbNullString), vbExclamation
End Sub

Private Function CaptureInputForEditLoad(ByVal ws As Worksheet) As Variant
    '訂正対象の読込途中で失敗しても、直前の未登録入力・訂正入力を失わない。
    Dim accountFields As Variant, fieldAddress As Variant
    Dim accountValues() As Variant, accountMergeSignatures() As Variant
    Dim balanceAmountValues As Variant, balanceMemoValues As Variant
    Dim transactionValues As Variant, statusValues As Variant
    Dim balanceAmountMergeSignature As String, balanceMemoMergeSignature As String
    Dim transactionMergeSignature As String, statusMergeSignature As String
    Dim transactionLastRow As Long, memoCol As Long, i As Long
    Dim targetRange As Range, balanceAmountRange As Range, balanceMemoRange As Range
    If ws Is Nothing Then Err.Raise vbObjectError + 3302, "CaptureInputForEditLoad", "入力シートを取得できません。"
    accountFields = Array(CELL_BANK, CELL_BRANCH, CELL_PERSON, CELL_RELATIONSHIP, _
                          CELL_ACCOUNT_TYPE, CELL_ACCOUNT_NO, CELL_OPEN_DATE, CELL_CLOSE_DATE)
    ReDim accountValues(0 To UBound(accountFields))
    ReDim accountMergeSignatures(0 To UBound(accountFields))
    For i = 0 To UBound(accountFields)
        Set targetRange = StrictEffectiveInputRange(ws.Range(CStr(accountFields(i))), _
                                                    "口座入力欄 " & CStr(accountFields(i)))
        accountValues(i) = CaptureInputFormulaSnapshot(targetRange)
        accountMergeSignatures(i) = InputRangeMergeSignature(targetRange)
    Next i
    memoCol = BalanceMemoCol(ws)
    If memoCol <= BAL_FIRST_COL Or memoCol > BAL_MAX_COL Then _
        Err.Raise vbObjectError + 3310, "CaptureInputForEditLoad", "残高メモ列を安全に取得できません。"
    Set balanceAmountRange = StrictEffectiveInputRange( _
                                 ws.Range(ws.Cells(BAL_VALUE_ROW, BAL_FIRST_COL), _
                                          ws.Cells(BAL_VALUE_ROW, memoCol - 1)), _
                                 "残高金額欄")
    Set balanceMemoRange = StrictEffectiveInputRange(BalanceMemoInputRange(ws), "残高メモ欄")
    AssertInputRangeWithinBoundary balanceAmountRange, _
                                   ws.Range(ws.Cells(BAL_VALUE_ROW, BAL_FIRST_COL), _
                                            ws.Cells(BAL_VALUE_ROW, memoCol - 1)), _
                                   "残高金額欄"
    AssertInputRangeWithinBoundary balanceMemoRange, BalanceMemoInputRange(ws), "残高メモ欄"
    balanceAmountValues = CaptureInputFormulaSnapshot(balanceAmountRange)
    balanceAmountMergeSignature = InputRangeMergeSignature(balanceAmountRange)
    balanceMemoValues = CaptureInputFormulaSnapshot(balanceMemoRange)
    balanceMemoMergeSignature = InputRangeMergeSignature(balanceMemoRange)
    transactionLastRow = StrictLastTransactionInputRow(ws)
    If transactionLastRow >= TX_FIRST_ROW Then
        Set targetRange = StrictEffectiveInputRange( _
                              ws.Range(ws.Cells(TX_FIRST_ROW, COL_TX_YEAR), _
                                       ws.Cells(transactionLastRow, COL_TX_BALANCE)), _
                              "取引入力欄")
        AssertInputRangeWithinBoundary targetRange, _
                                       ws.Range(ws.Cells(TX_FIRST_ROW, COL_TX_YEAR), _
                                                ws.Cells(TX_LAST_ROW, COL_TX_BALANCE)), _
                                       "取引入力欄"
        transactionValues = CaptureInputFormulaSnapshot(targetRange)
        transactionMergeSignature = InputRangeMergeSignature(targetRange)
    End If
    Set targetRange = StrictEffectiveInputRange(ws.Range(CELL_STATUS), "入力状態表示")
    statusValues = CaptureInputFormulaSnapshot(targetRange)
    statusMergeSignature = InputRangeMergeSignature(targetRange)
    CaptureInputForEditLoad = Array(accountValues, accountMergeSignatures, _
                                    balanceAmountValues, balanceAmountMergeSignature, _
                                    balanceMemoValues, balanceMemoMergeSignature, _
                                    transactionValues, transactionMergeSignature, transactionLastRow, _
                                    statusValues, statusMergeSignature, _
                                    GetStateValue(STATE_INPUT_DATE_CONFIG_SAFE, STATE_FALSE))
End Function

Private Sub RestoreInputAfterEditLoad(ByVal ws As Worksheet, ByVal snapshot As Variant, _
                                      ByVal previousEditAccountID As String, _
                                      ByRef protectionSnapshot As InputProtectionSnapshot)
    Dim accountFields As Variant, accountValues As Variant, accountMergeSignatures As Variant
    Dim balanceAmountValues As Variant, balanceMemoValues As Variant
    Dim transactionValues As Variant, statusValues As Variant
    Dim balanceAmountMergeSignature As String, balanceMemoMergeSignature As String
    Dim transactionMergeSignature As String, statusMergeSignature As String
    Dim currentLastRow As Long, snapshotLastRow As Long, memoCol As Long, i As Long
    Dim snapshotDateConfigSafe As String, restoredDateConfigSafe As String
    Dim restoredEditAccountID As String
    Dim targetRange As Range, balanceAmountRange As Range, balanceMemoRange As Range
    Dim firstIndex As Long
    If ws Is Nothing Then Err.Raise vbObjectError + 3303, "RestoreInputAfterEditLoad", "入力シートを取得できません。"
    If Not IsArray(snapshot) Then Err.Raise vbObjectError + 3304, "RestoreInputAfterEditLoad", "入力退避値がありません。"
    firstIndex = LBound(snapshot)
    If UBound(snapshot) - firstIndex < 11 Then _
        Err.Raise vbObjectError + 3311, "RestoreInputAfterEditLoad", "入力退避値が不足しています。"
    snapshotDateConfigSafe = CellText(snapshot(firstIndex + 11))
    If snapshotDateConfigSafe <> STATE_TRUE And snapshotDateConfigSafe <> STATE_FALSE Then _
        snapshotDateConfigSafe = STATE_FALSE
    '復元途中の失敗でClearInputForRecordLoad後のTrueを残さない。全復元完了まで必ずfail-closed。
    SetStateValue STATE_INPUT_DATE_CONFIG_SAFE, STATE_FALSE
    accountFields = Array(CELL_BANK, CELL_BRANCH, CELL_PERSON, CELL_RELATIONSHIP, _
                          CELL_ACCOUNT_TYPE, CELL_ACCOUNT_NO, CELL_OPEN_DATE, CELL_CLOSE_DATE)
    accountValues = snapshot(firstIndex)
    accountMergeSignatures = snapshot(firstIndex + 1)
    balanceAmountValues = snapshot(firstIndex + 2)
    balanceAmountMergeSignature = CStr(snapshot(firstIndex + 3))
    balanceMemoValues = snapshot(firstIndex + 4)
    balanceMemoMergeSignature = CStr(snapshot(firstIndex + 5))
    transactionValues = snapshot(firstIndex + 6)
    transactionMergeSignature = CStr(snapshot(firstIndex + 7))
    snapshotLastRow = CLng(snapshot(firstIndex + 8))
    statusValues = snapshot(firstIndex + 9)
    statusMergeSignature = CStr(snapshot(firstIndex + 10))
    ws.Unprotect Password:=TOOL_PASSWORD
    For i = 0 To UBound(accountFields)
        Set targetRange = StrictEffectiveInputRange(ws.Range(CStr(accountFields(i))), _
                                                    "口座入力欄 " & CStr(accountFields(i)))
        RestoreInputFormulaSnapshot targetRange, accountValues(i), _
                                    CStr(accountMergeSignatures(i)), _
                                    "口座入力欄 " & CStr(accountFields(i))
    Next i
    '残高欄の入力可否処理はプレースホルダ等を書き換えるため、退避値を戻す前に実行する。
    ApplyBalanceAvailability ws
    memoCol = BalanceMemoCol(ws)
    If memoCol <= BAL_FIRST_COL Or memoCol > BAL_MAX_COL Then _
        Err.Raise vbObjectError + 3312, "RestoreInputAfterEditLoad", "残高メモ列を安全に取得できません。"
    Set balanceAmountRange = StrictEffectiveInputRange( _
                                 ws.Range(ws.Cells(BAL_VALUE_ROW, BAL_FIRST_COL), _
                                          ws.Cells(BAL_VALUE_ROW, memoCol - 1)), _
                                 "残高金額欄")
    Set balanceMemoRange = StrictEffectiveInputRange(BalanceMemoInputRange(ws), "残高メモ欄")
    AssertInputRangeWithinBoundary balanceAmountRange, _
                                   ws.Range(ws.Cells(BAL_VALUE_ROW, BAL_FIRST_COL), _
                                            ws.Cells(BAL_VALUE_ROW, memoCol - 1)), _
                                   "残高金額欄"
    AssertInputRangeWithinBoundary balanceMemoRange, BalanceMemoInputRange(ws), "残高メモ欄"
    RestoreInputFormulaSnapshot balanceAmountRange, balanceAmountValues, _
                                balanceAmountMergeSignature, "残高金額欄"
    RestoreInputFormulaSnapshot balanceMemoRange, balanceMemoValues, _
                                balanceMemoMergeSignature, "残高メモ欄"
    currentLastRow = StrictLastTransactionInputRow(ws)
    If currentLastRow >= TX_FIRST_ROW Then
        Set targetRange = StrictEffectiveInputRange( _
                              ws.Range(ws.Cells(TX_FIRST_ROW, COL_TX_YEAR), _
                                       ws.Cells(currentLastRow, COL_TX_BALANCE)), _
                              "訂正読込後の取引欄")
        AssertInputRangeWithinBoundary targetRange, _
                                       ws.Range(ws.Cells(TX_FIRST_ROW, COL_TX_YEAR), _
                                                ws.Cells(TX_LAST_ROW, COL_TX_BALANCE)), _
                                       "訂正読込後の取引欄"
        ClearInputRangeStrict targetRange, "訂正読込後の取引欄"
    End If
    If snapshotLastRow >= TX_FIRST_ROW Then
        Set targetRange = StrictEffectiveInputRange( _
                              ws.Range(ws.Cells(TX_FIRST_ROW, COL_TX_YEAR), _
                                       ws.Cells(snapshotLastRow, COL_TX_BALANCE)), _
                              "訂正読込前の取引欄")
        AssertInputRangeWithinBoundary targetRange, _
                                       ws.Range(ws.Cells(TX_FIRST_ROW, COL_TX_YEAR), _
                                                ws.Cells(TX_LAST_ROW, COL_TX_BALANCE)), _
                                       "訂正読込前の取引欄"
        RestoreInputFormulaSnapshot targetRange, transactionValues, _
                                    transactionMergeSignature, "訂正読込前の取引欄"
        RestoreAllTransactionRowStyles ws, snapshotLastRow
    End If
    Set targetRange = StrictEffectiveInputRange(ws.Range(CELL_STATUS), "入力状態表示")
    RestoreInputFormulaSnapshot targetRange, statusValues, statusMergeSignature, "入力状態表示"
    InvalidateDateComplementCache
    SetEditAccountID previousEditAccountID
    RestoreInputProtection ws, protectionSnapshot
    AssertInputProtection ws, protectionSnapshot
    If Not TryGetExactStateValue(STATE_EDIT_ACCOUNT, restoredEditAccountID) Then _
        Err.Raise vbObjectError + 3313, "RestoreInputAfterEditLoad", _
                  "訂正IDの復元結果を一意に読み取れません。"
    If StrComp(restoredEditAccountID, previousEditAccountID, vbBinaryCompare) <> 0 Then _
        Err.Raise vbObjectError + 3314, "RestoreInputAfterEditLoad", "訂正IDの復元結果が一致しません。"
    'セル・訂正ID・保護を全て復元できた後だけ、退避時の安全状態へ確定する。
    SetStateValue STATE_INPUT_DATE_CONFIG_SAFE, snapshotDateConfigSafe
    If Not TryGetExactStateValue(STATE_INPUT_DATE_CONFIG_SAFE, restoredDateConfigSafe) Then _
        Err.Raise vbObjectError + 3315, "RestoreInputAfterEditLoad", _
                  "日付安全状態の復元結果を一意に読み取れません。"
    If restoredDateConfigSafe <> snapshotDateConfigSafe Then _
        Err.Raise vbObjectError + 3316, "RestoreInputAfterEditLoad", _
                  "日付安全状態の復元値が一致しません。"
End Sub

Private Sub LoadBalancesForEdit(ByVal wsIn As Worksheet, ByVal accountID As String)
    Dim wsBal As Worksheet
    Dim lastR As Long, r As Long, c As Long, memoCol As Long
    Dim targetDate As Variant
    Dim seenDates As Object, gridColumnByDate As Object, dateKey As String
    Dim memoText As String, selectedMemo As String
    Dim balanceData As Variant
    Set seenDates = CreateObject("Scripting.Dictionary")
    seenDates.CompareMode = vbTextCompare
    Set gridColumnByDate = CreateObject("Scripting.Dictionary")
    gridColumnByDate.CompareMode = vbTextCompare
    Set wsBal = GetSheet(SH_WORK_BAL)
    lastR = LastUsedRowInSheet(wsBal)
    memoCol = BalanceMemoCol(wsIn)
    For c = BAL_FIRST_COL To memoCol - 1
        If IsDate(wsIn.Cells(BAL_DATE_ROW, c).Value) Then _
            gridColumnByDate(Format$(CDate(wsIn.Cells(BAL_DATE_ROW, c).Value), "yyyymmdd")) = c
    Next c
    If lastR < 2 Then Exit Sub
    balanceData = wsBal.Range(wsBal.Cells(2, 1), wsBal.Cells(lastR, WORK_BAL_COL_PERSON_ID)).Value2
    For r = 1 To UBound(balanceData, 1)
        If CellText(balanceData(r, WORK_BAL_COL_ACCOUNT_ID)) = accountID Then
            targetDate = balanceData(r, 8)
            If Not IsDate(targetDate) Then _
                Err.Raise vbObjectError + 3306, "LoadBalancesForEdit", _
                          "残高基準日が不正です。該当口座の残高を確認してください（" & CStr(r + 1) & "行）。"
            dateKey = Format$(CDate(targetDate), "yyyymmdd")
            If seenDates.Exists(dateKey) Then
                Err.Raise vbObjectError + 3301, "LoadBalancesForEdit", _
                          "同じ基準日の残高が重複しています。該当口座の残高を確認してください: " & Format$(CDate(targetDate), "yyyy/m/d")
            End If
            seenDates.Add dateKey, True
            If gridColumnByDate.Exists(dateKey) Then _
                wsIn.Cells(BAL_VALUE_ROW, CLng(gridColumnByDate(dateKey))).Value = balanceData(r, 10)
            memoText = CellText(balanceData(r, 11))
            If Len(memoText) > 0 Then
                If Len(selectedMemo) > 0 And StrComp(selectedMemo, memoText, vbBinaryCompare) <> 0 Then
                    Err.Raise vbObjectError + 3305, "LoadBalancesForEdit", _
                              "同一口座の残高メモに異なる内容があります。該当口座の残高を確認してください。"
                End If
                selectedMemo = memoText
            End If
        End If
    Next r
    If Len(selectedMemo) > 0 Then wsIn.Cells(BAL_VALUE_ROW, memoCol).Value = selectedMemo
End Sub

Private Sub LoadTransactionsForEdit(ByVal wsIn As Worksheet, ByVal accountID As String)
    Dim wsTx As Worksheet
    Dim lastR As Long, r As Long, outCount As Long, outputColumns As Long, outputIndex As Long
    Dim editableTransactionRows As Long
    Dim txDate As Variant, txTime As Variant
    Dim txData As Variant, inputData() As Variant
    Set wsTx = GetSheet(SH_WORK_TX)
    lastR = LastUsedRowInSheet(wsTx)
    If lastR < 2 Then Exit Sub
    outputColumns = COL_TX_BALANCE - COL_TX_YEAR + 1
    txData = wsTx.Range(wsTx.Cells(2, 1), wsTx.Cells(lastR, WORK_TX_COL_PERSON_ID)).Value2
    For r = 1 To UBound(txData, 1)
        If CellText(txData(r, WORK_TX_COL_ACCOUNT_ID)) = accountID And _
           CellText(txData(r, WORK_TX_COL_RECORD_TYPE)) = RECORD_TRANSACTION Then _
            outCount = outCount + 1
    Next r
    If outCount = 0 Then Exit Sub
    editableTransactionRows = TX_LAST_ROW - TX_FIRST_ROW + 1
    If outCount > editableTransactionRows Then _
        Err.Raise vbObjectError + 3307, "LoadTransactionsForEdit", _
                  "訂正対象は" & Format$(outCount, "#,##0") & _
                  "件で、訂正画面の上限" & Format$(editableTransactionRows, "#,##0") & _
                  "件を超えています。一部だけを読み込まず中止しました。" & _
                  "外部データを分割するか、取込元原本の不要行・重複行を整理してください。"
    ReDim inputData(1 To outCount, 1 To outputColumns)
    For r = 1 To UBound(txData, 1)
        If CellText(txData(r, WORK_TX_COL_ACCOUNT_ID)) = accountID And _
           CellText(txData(r, WORK_TX_COL_RECORD_TYPE)) = RECORD_TRANSACTION Then
            outputIndex = outputIndex + 1
            txDate = txData(r, OUT_COL_DATE)
            If Not IsDate(txDate) Then _
                Err.Raise vbObjectError + 3308, "LoadTransactionsForEdit", _
                          "取引日付が不正です。該当口座の取引を確認してください（" & CStr(r + 1) & "行）。"
            '訂正時は各行を自己完結させ、後続行が前月・前年を誤って引き継がないようにする。
            inputData(outputIndex, COL_TX_YEAR - COL_TX_YEAR + 1) = Year(CDate(txDate))
            inputData(outputIndex, COL_TX_MONTH - COL_TX_YEAR + 1) = Month(CDate(txDate))
            inputData(outputIndex, COL_TX_DAY - COL_TX_YEAR + 1) = Day(CDate(txDate))
            txTime = txData(r, OUT_COL_TIME)
            If HasText(txTime) Then
                If Not IsDate(txTime) Then _
                    Err.Raise vbObjectError + 3309, "LoadTransactionsForEdit", _
                              "取引時刻が不正です。該当口座の取引を確認してください（" & CStr(r + 1) & "行）。"
                inputData(outputIndex, COL_TX_TIME - COL_TX_YEAR + 1) = Format$(CDate(txTime), "hhmm")
            End If
            inputData(outputIndex, COL_TX_WITHDRAW - COL_TX_YEAR + 1) = txData(r, OUT_COL_WITHDRAW)
            inputData(outputIndex, COL_TX_DEPOSIT - COL_TX_YEAR + 1) = txData(r, OUT_COL_DEPOSIT)
            inputData(outputIndex, COL_TX_SHOP - COL_TX_YEAR + 1) = txData(r, OUT_COL_SHOP)
            inputData(outputIndex, COL_TX_MACHINE - COL_TX_YEAR + 1) = txData(r, OUT_COL_MACHINE)
            inputData(outputIndex, COL_TX_TEKIYO - COL_TX_YEAR + 1) = txData(r, OUT_COL_TEKIYO)
            inputData(outputIndex, COL_TX_BALANCE - COL_TX_YEAR + 1) = txData(r, OUT_COL_OTHER)
        End If
    Next r
    wsIn.Range(wsIn.Cells(TX_FIRST_ROW, COL_TX_YEAR), _
               wsIn.Cells(TX_FIRST_ROW + outCount - 1, COL_TX_BALANCE)).Value = inputData
    InvalidateDateComplementCache
End Sub

Public Sub CancelCorrection()
    Dim errorNumber As Long, errorDescription As String, errorSource As String
    Dim cleanupErrorNumber As Long, cleanupErrorDescription As String
    Dim healthErrorNumber As Long, healthErrorDescription As String
    Dim entryEvents As Boolean, entryEventsCaptured As Boolean
    Dim cleanupEventsStopped As Boolean, leaseRestored As Boolean
    Dim recoveryStateConfirmed As Boolean
    Dim recoveryAttempted As Boolean, recoveryEnforceFailed As Boolean
    Dim applicationLeaseStarted As Boolean, localSafetyConfirmed As Boolean
    Dim healthNormal As Boolean
    Dim eventDetail As String, cleanupDetail As String
    If Not RequireToolReady() Then Exit Sub
    If Not RequireWritableWorkbook("訂正の中止") Then Exit Sub
    If Not IsEditMode() Then
        SetInputStatus "現在は口座訂正中ではありません。"
        Exit Sub
    End If
    If MsgBox("入力中の訂正内容を破棄して、訂正を中止しますか？", _
              vbYesNo + vbExclamation + vbDefaultButton2, "訂正の中止確認") <> vbYes Then Exit Sub
    '訂正IDの破棄はClearInputCoreの成功時にだけ行う。失敗時は入力と訂正状態を一緒に復元する。
    On Error GoTo EH
    If Not TryGetRecordsEnableEvents(entryEvents, eventDetail) Then _
        Err.Raise vbObjectError + 3444, "CancelCorrection", _
                  "Excelイベントの開始状態を取得できません: " & eventDetail
    entryEventsCaptured = True
    'ClearInputCoreを入れ子leaseとして呼び、内側処理の終了後も選択・状態表示まで
    '外側のFalse exactを維持する。
    AppBegin "口座訂正を中止しています..."
    applicationLeaseStarted = True
    If Not TryKeepRecordsEventsDisabledExact(eventDetail) Then _
        Err.Raise vbObjectError + 3444, "CancelCorrection", _
                  "訂正中止前にExcelイベントを停止できません: " & eventDetail
    ClearInputCore KEEP_NONE, True, True, True
    If Not TryKeepRecordsEventsDisabledExact(eventDetail) Then _
        Err.Raise vbObjectError + 3444, "CancelCorrection", _
                  "入力クリア後にExcelイベント停止を維持できません: " & _
                  eventDetail
    cleanupEventsStopped = True
    If SheetExists(SH_INPUT) Then SafeSelectCell GetSheet(SH_INPUT), CELL_BANK
    SetInputStatus "訂正を終了しました。"
    localSafetyConfirmed = True
    leaseRestored = FinalizeRecordsApplicationLease( _
                        "口座訂正の中止", applicationLeaseStarted, _
                        entryEventsCaptured, entryEvents, _
                        localSafetyConfirmed, True, recoveryAttempted, _
                        recoveryEnforceFailed, recoveryStateConfirmed, _
                        cleanupDetail)
    If Not leaseRestored Then
        MsgBox "訂正入力は破棄しましたが、Excelの開始状態を安全に復元できませんでした。" & _
               vbCrLf & cleanupDetail, vbCritical, _
               "訂正中止後のExcel状態を確認できません"
    End If
    Exit Sub
EH:
    errorNumber = Err.Number
    errorSource = Err.Source
    errorDescription = Err.Description
    If IsRecordsClearRecoveryFatal(errorNumber, errorSource) Then
        cleanupEventsStopped = _
            TryKeepRecordsEventsDisabledExact(eventDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    If IsRecordsRecoveryHardBarrier(errorNumber, errorSource) Then
        cleanupEventsStopped = _
            TryKeepRecordsEventsDisabledExact(eventDetail)
        Err.Raise errorNumber, errorSource, errorDescription
    End If
    'ClearInputCoreは退避した保護設定を厳密に復元・照合してからエラーを返す。
    'ここで標準保護を再適用すると、復元済みのカスタム保護を上書きするため行わない。
    cleanupEventsStopped = False
    If entryEventsCaptured Then _
        cleanupEventsStopped = _
            TryKeepRecordsEventsDisabledExact(eventDetail)
    If cleanupEventsStopped Then
        On Error Resume Next
        Err.Clear
        EnableInputKeys
        cleanupErrorNumber = Err.Number
        cleanupErrorDescription = Err.Description
        Err.Clear
        On Error GoTo 0
        If cleanupErrorNumber <> 0 Then
            AppendRecordsDetail cleanupDetail, _
                "入力キー復旧エラー: Err " & CStr(cleanupErrorNumber) & _
                " " & cleanupErrorDescription
        End If
        On Error Resume Next
        Err.Clear
        healthNormal = ToolDataHealthIsNormal()
        healthErrorNumber = Err.Number
        healthErrorDescription = Err.Description
        Err.Clear
        On Error GoTo 0
        If healthErrorNumber <> 0 Then _
            AppendRecordsDetail cleanupDetail, _
                "案件安全状態の確認エラー: Err " & _
                CStr(healthErrorNumber) & " " & healthErrorDescription
        localSafetyConfirmed = (cleanupErrorNumber = 0 And _
                                healthErrorNumber = 0 And healthNormal)
        If Not localSafetyConfirmed Then
            Call TryEnterRecordsRecoveryState( _
                     "訂正中止失敗後の安全状態", _
                     cleanupEventsStopped, recoveryStateConfirmed, _
                     recoveryAttempted, recoveryEnforceFailed, _
                     cleanupDetail)
        End If
        If Not recoveryEnforceFailed And cleanupEventsStopped And _
           (localSafetyConfirmed Or recoveryStateConfirmed) Then
            On Error Resume Next
            AddCheck "エラー", "訂正の中止", _
                     "Err " & CStr(errorNumber) & ": " & _
                     errorDescription & _
                     IIf(Len(cleanupDetail) > 0, _
                         " / " & cleanupDetail, vbNullString)
            If recoveryStateConfirmed Then
                SetInputStatus _
                    "訂正を中止できず、案件を要復旧として停止しました。C_チェックを確認してください。", _
                    True
            Else
                SetInputStatus _
                    "訂正を中止できませんでした。入力内容と訂正状態は読込前へ戻しました。", _
                    True
            End If
            Err.Clear
            On Error GoTo 0
        End If
    Else
        AppendRecordsDetail cleanupDetail, _
            "失敗復旧前のExcelイベント停止を確認できないため、" & _
            "状態・診断・キー設定へ書き込んでいません。" & _
            IIf(Len(eventDetail) > 0, " " & eventDetail, vbNullString)
    End If
    leaseRestored = FinalizeRecordsApplicationLease( _
                        "口座訂正の中止失敗復旧", _
                        applicationLeaseStarted, _
                        entryEventsCaptured, entryEvents, _
                        localSafetyConfirmed, cleanupEventsStopped, _
                        recoveryAttempted, recoveryEnforceFailed, _
                        recoveryStateConfirmed, _
                        cleanupDetail)
    MsgBox "訂正の中止処理でエラーが発生しました。" & vbCrLf & _
           "Err " & CStr(errorNumber) & ": " & errorDescription & _
           IIf(Len(cleanupDetail) > 0, _
               vbCrLf & "復旧確認: " & cleanupDetail, vbNullString) & _
           IIf(Not leaseRestored, _
               vbCrLf & "Excelの開始状態を完全に復元できません。", _
               vbNullString), vbExclamation, _
           "訂正を中止できませんでした"
End Sub

Private Function IsRecordsClearRecoveryFatal( _
        ByVal errorNumber As Long, _
        ByVal errorSource As String) As Boolean
    IsRecordsClearRecoveryFatal = _
        (errorNumber = vbObjectError + 5197) And _
        (Left$(errorSource, Len("ClearRecoveryFatal/")) = _
            "ClearRecoveryFatal/")
End Function

Private Function IsRecordsRecoveryHardBarrier( _
        ByVal errorNumber As Long, _
        ByVal errorSource As String) As Boolean
    Dim sourcePrefix As String

    Select Case errorNumber
        Case RECORDS_RECOVERY_ENFORCE_ERROR, vbObjectError + 4499
            IsRecordsRecoveryHardBarrier = True
            Exit Function
        Case vbObjectError + 5191
            sourcePrefix = "AnalysisWorkspaceRecoveryFatal/"
        Case vbObjectError + 5192
            sourcePrefix = "SetupConvergeRecoveryFatal/"
        Case vbObjectError + 5194
            sourcePrefix = "CashAnalysisRecoveryFatal/"
        Case vbObjectError + 5195
            sourcePrefix = "TransactionAnalysisRecoveryFatal/"
        Case vbObjectError + 5196
            sourcePrefix = "CashManualSelectionRecoveryFatal/"
        Case vbObjectError + 5197
            sourcePrefix = "ClearRecoveryFatal/"
        Case Else
            Exit Function
    End Select

    IsRecordsRecoveryHardBarrier = _
        (Len(errorSource) >= Len(sourcePrefix)) And _
        (StrComp(Left$(errorSource, Len(sourcePrefix)), _
                 sourcePrefix, vbBinaryCompare) = 0)
End Function

Public Sub SynchronizePersonRelationship(ByVal personID As String, ByVal relationshipText As String)
    '続柄は口座ではなく人物に属する属性として扱う。訂正時は同一人物IDの全記録を同時にそろえる。
    Dim wsAcc As Worksheet, wsTx As Worksheet, wsBal As Worksheet, wsPerson As Worksheet
    Dim lastAcc As Long, lastTx As Long, lastBal As Long, lastPerson As Long
    Dim snapAcc As Variant, snapTx As Variant, snapBal As Variant, snapPerson As Variant
    Dim sigAcc As String, sigTx As String, sigBal As String, sigPerson As String
    Dim rngAcc As Range, rngTx As Range, rngBal As Range, rngPerson As Range
    Dim errorNumber As Long, errorDescription As String, restoreDescription As String
    If Len(Trim$(CellText(personID))) = 0 Then _
        Err.Raise vbObjectError + 3412, "SynchronizePersonRelationship", "人物IDがありません。"

    On Error GoTo EH
    Set wsAcc = GetSheet(SH_WORK_ACCOUNT)
    Set wsTx = GetSheet(SH_WORK_TX)
    Set wsBal = GetSheet(SH_WORK_BAL)
    lastAcc = LastUsedRowInSheet(wsAcc)
    lastTx = LastUsedRowInSheet(wsTx)
    lastBal = LastUsedRowInSheet(wsBal)
    If SheetExists(SH_PERSON_CAND) Then
        Set wsPerson = GetSheet(SH_PERSON_CAND)
        lastPerson = LastUsedRowInSheet(wsPerson)
    End If

    '数式と「'=...」形式の文字定数を区別して退避する。Formula配列だけの往復では、
    '同期対象外の文字定数を数式化し得るため、値・型・PrefixCharacterまで保持する。
    If lastAcc >= 2 Then
        Set rngAcc = wsAcc.Range(wsAcc.Cells(2, ACC_COL_RELATIONSHIP), _
                                 wsAcc.Cells(lastAcc, ACC_COL_RELATIONSHIP))
        sigAcc = InputRangeMergeSignature(rngAcc)
        snapAcc = CaptureInputFormulaSnapshot(rngAcc)
    End If
    If lastTx >= 2 Then
        Set rngTx = wsTx.Range(wsTx.Cells(2, WORK_TX_COL_RELATIONSHIP), _
                               wsTx.Cells(lastTx, WORK_TX_COL_RELATIONSHIP))
        sigTx = InputRangeMergeSignature(rngTx)
        snapTx = CaptureInputFormulaSnapshot(rngTx)
    End If
    If lastBal >= 2 Then
        Set rngBal = wsBal.Range(wsBal.Cells(2, WORK_BAL_COL_RELATIONSHIP), _
                                 wsBal.Cells(lastBal, WORK_BAL_COL_RELATIONSHIP))
        sigBal = InputRangeMergeSignature(rngBal)
        snapBal = CaptureInputFormulaSnapshot(rngBal)
    End If
    If lastPerson >= 2 Then
        Set rngPerson = wsPerson.Range(wsPerson.Cells(2, 3), wsPerson.Cells(lastPerson, 3))
        sigPerson = InputRangeMergeSignature(rngPerson)
        snapPerson = CaptureInputFormulaSnapshot(rngPerson)
    End If

    SynchronizeRelationshipColumn wsAcc, lastAcc, ACC_COL_PERSON_ID, ACC_COL_RELATIONSHIP, _
                                  personID, relationshipText, 3413, "口座マスタ"
    SynchronizeRelationshipColumn wsTx, lastTx, WORK_TX_COL_PERSON_ID, WORK_TX_COL_RELATIONSHIP, _
                                  personID, relationshipText, 3414, "取引記録"
    SynchronizeRelationshipColumn wsBal, lastBal, WORK_BAL_COL_PERSON_ID, WORK_BAL_COL_RELATIONSHIP, _
                                  personID, relationshipText, 3415, "残高記録"
    If Not wsPerson Is Nothing Then _
        SynchronizeRelationshipColumn wsPerson, lastPerson, 2, 3, personID, relationshipText, 3416, "人物候補"
    Exit Sub

EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    On Error Resume Next
    If Not rngAcc Is Nothing Then
        Err.Clear
        RestoreInputFormulaSnapshot rngAcc, snapAcc, sigAcc, "口座マスタ続柄"
        AssertInputFormulaSnapshot rngAcc, snapAcc, sigAcc, "口座マスタ続柄"
        If Err.Number <> 0 Then AppendRecordsDetail restoreDescription, _
            "口座マスタ続柄の復元エラー: " & Err.Description
    End If
    If Not rngTx Is Nothing Then
        Err.Clear
        RestoreInputFormulaSnapshot rngTx, snapTx, sigTx, "取引続柄"
        AssertInputFormulaSnapshot rngTx, snapTx, sigTx, "取引続柄"
        If Err.Number <> 0 Then AppendRecordsDetail restoreDescription, _
            "取引続柄の復元エラー: " & Err.Description
    End If
    If Not rngBal Is Nothing Then
        Err.Clear
        RestoreInputFormulaSnapshot rngBal, snapBal, sigBal, "残高続柄"
        AssertInputFormulaSnapshot rngBal, snapBal, sigBal, "残高続柄"
        If Err.Number <> 0 Then AppendRecordsDetail restoreDescription, _
            "残高続柄の復元エラー: " & Err.Description
    End If
    If Not rngPerson Is Nothing Then
        Err.Clear
        RestoreInputFormulaSnapshot rngPerson, snapPerson, sigPerson, "人物候補続柄"
        AssertInputFormulaSnapshot rngPerson, snapPerson, sigPerson, "人物候補続柄"
        If Err.Number <> 0 Then AppendRecordsDetail restoreDescription, _
            "人物候補続柄の復元エラー: " & Err.Description
    End If
    On Error GoTo 0
    Err.Raise errorNumber, "SynchronizePersonRelationship", errorDescription & _
              IIf(Len(restoreDescription) > 0, " / " & restoreDescription, "")
End Sub

Private Sub SynchronizeRelationshipColumn(ByVal ws As Worksheet, ByVal lastR As Long, _
                                          ByVal personIDCol As Long, ByVal relationshipCol As Long, _
                                          ByVal personID As String, ByVal relationshipText As String, _
                                          ByVal verifyErrorOffset As Long, ByVal labelText As String)
    Dim rowCount As Long, r As Long
    Dim idData As Variant, verifyData As Variant
    Dim targetCell As Range
    Dim expectedKey As String, changed As Boolean
    If ws Is Nothing Or lastR < 2 Then Exit Sub
    rowCount = lastR - 1
    idData = ws.Range(ws.Cells(2, personIDCol), ws.Cells(lastR, personIDCol)).Value2
    For r = 1 To rowCount
        If StrComp(CellText(RecordsColumnValue(idData, r, rowCount)), personID, vbTextCompare) = 0 Then
            Set targetCell = ws.Cells(r + 1, relationshipCol)
            '対象行だけを書き換え、同じ列の無関係な数式・文字定数には一切触れない。
            targetCell.NumberFormatLocal = "@"
            targetCell.Value2 = relationshipText
            If targetCell.HasFormula Or IsError(targetCell.Value2) Then _
                Err.Raise vbObjectError + verifyErrorOffset, "SynchronizeRelationshipColumn", _
                          labelText & "の続柄を文字列として保存できません。"
            changed = True
        End If
    Next r
    If Not changed Then Exit Sub
    verifyData = ws.Range(ws.Cells(2, relationshipCol), ws.Cells(lastR, relationshipCol)).Value2
    expectedKey = NormalizeRelationshipKey(relationshipText)
    For r = 1 To rowCount
        If StrComp(CellText(RecordsColumnValue(idData, r, rowCount)), personID, vbTextCompare) = 0 Then
            If NormalizeRelationshipKey(CellText(RecordsColumnValue(verifyData, r, rowCount))) <> expectedKey Then _
                Err.Raise vbObjectError + verifyErrorOffset, "SynchronizeRelationshipColumn", _
                          labelText & "の続柄更新を確認できません。"
        End If
    Next r
End Sub

Private Function RecordsColumnValue(ByRef sourceData As Variant, ByVal rowIndex As Long, _
                                    ByVal rowCount As Long) As Variant
    If rowCount = 1 Then
        If rowIndex <> 1 Then Err.Raise vbObjectError + 3417, "RecordsColumnValue", "列配列の行番号が不正です。"
        RecordsColumnValue = sourceData
    Else
        RecordsColumnValue = sourceData(rowIndex, 1)
    End If
End Function


Public Function PersonIDForName(ByVal personName As String, Optional ByVal relationshipText As String = "") As String
    Dim ws As Worksheet
    Dim lastR As Long
    Dim candidateID As String
    Dim candidateRowCount As Long, accountRowCount As Long
    Dim personData As Variant, accountData As Variant

    '候補表を先に参照するが、候補更新に失敗・手修正された場合でも、
    '既存口座の人物IDを正として同一人物へ別IDを発行しない。
    If SheetExists(SH_PERSON_CAND) Then
        Set ws = GetSheet(SH_PERSON_CAND)
        lastR = LastUsedRowInSheet(ws)
        If lastR >= 2 Then
            personData = ws.Range(ws.Cells(2, 1), ws.Cells(lastR, 3)).Value2
            candidateRowCount = lastR - 1
        End If
    End If

    If SheetExists(SH_WORK_ACCOUNT) Then
        Set ws = GetSheet(SH_WORK_ACCOUNT)
        lastR = LastUsedRowInSheet(ws)
        If lastR >= 2 Then
            accountData = ws.Range(ws.Cells(2, ACC_COL_PERSON), _
                                   ws.Cells(lastR, ACC_COL_PERSON_ID)).Value2
            accountRowCount = lastR - 1
        End If
    End If

    candidateID = ResolvePersonIDFromIdentityData( _
                      personName, relationshipText, personData, candidateRowCount, _
                      accountData, accountRowCount)
    If Len(candidateID) > 0 Then
        AssertPersonIDRelationshipCompatible candidateID, _
                                             NormalizeRelationshipKey(relationshipText), _
                                             personName
    End If
    PersonIDForName = candidateID
End Function

Private Function ResolvePersonIDFromIdentityData( _
        ByVal personName As String, ByVal relationshipText As String, _
        ByRef candidateData As Variant, ByVal candidateRowCount As Long, _
        ByRef accountData As Variant, ByVal accountRowCount As Long) As String
    Dim r As Long
    Dim personKey As String, relationshipKey As String
    Dim candidateID As String, storedRelationship As String
    Dim matchingRelationshipIDs As Object
    Dim relationshipByPersonID As Object

    personKey = NormalizePersonNameKey(personName)
    If Len(personKey) = 0 Then Exit Function
    relationshipKey = NormalizeRelationshipKey(relationshipText)
    AssertPersonIDResolverMatrix candidateData, candidateRowCount, 3, "人物候補"
    AssertPersonIDResolverMatrix accountData, accountRowCount, _
                                 ACC_COL_PERSON_ID - ACC_COL_PERSON + 1, "W_口座"
    Set matchingRelationshipIDs = CreateObject("Scripting.Dictionary")
    matchingRelationshipIDs.CompareMode = vbTextCompare
    Set relationshipByPersonID = CreateObject("Scripting.Dictionary")
    relationshipByPersonID.CompareMode = vbTextCompare

    '同じ人物IDの別名義に確定済み続柄があれば、空欄の別名義にもその続柄を
    '投影してから氏名＋続柄を照合する。これにより、空欄候補が先に存在しても
    '同じ人物へ別IDを発行しない。非空欄同士の矛盾は採番前に停止する。
    For r = 1 To candidateRowCount
        IndexResolverPersonIDRelationship relationshipByPersonID, _
            CellText(candidateData(r, 2)), CellText(candidateData(r, 3)), "人物候補"
    Next r
    For r = 1 To accountRowCount
        IndexResolverPersonIDRelationship relationshipByPersonID, _
            CellText(accountData(r, ACC_COL_PERSON_ID - ACC_COL_PERSON + 1)), _
            CellText(accountData(r, ACC_COL_RELATIONSHIP - ACC_COL_PERSON + 1)), _
            "W_口座"
    Next r

    For r = 1 To candidateRowCount
        If NormalizePersonNameKey(CellText(candidateData(r, 1))) = personKey Then
            candidateID = CellText(candidateData(r, 2))
            storedRelationship = CellText(candidateData(r, 3))
            If Len(NormalizeRelationshipKey(storedRelationship)) = 0 And _
               Len(relationshipKey) > 0 And _
               relationshipByPersonID.Exists(candidateID) Then _
                storedRelationship = CellText(relationshipByPersonID(candidateID))
            AddPersonIDMatch matchingRelationshipIDs, candidateID, _
                             storedRelationship, relationshipKey
        End If
    Next r
    For r = 1 To accountRowCount
        If NormalizePersonNameKey(CellText(accountData(r, 1))) = personKey Then
            candidateID = CellText( _
                            accountData(r, ACC_COL_PERSON_ID - ACC_COL_PERSON + 1))
            storedRelationship = CellText( _
                                     accountData( _
                                         r, ACC_COL_RELATIONSHIP - ACC_COL_PERSON + 1))
            If Len(NormalizeRelationshipKey(storedRelationship)) = 0 And _
               Len(relationshipKey) > 0 And _
               relationshipByPersonID.Exists(candidateID) Then _
                storedRelationship = CellText(relationshipByPersonID(candidateID))
            AddPersonIDMatch matchingRelationshipIDs, candidateID, _
                             storedRelationship, relationshipKey
        End If
    Next r

    If matchingRelationshipIDs.Count = 1 Then
        ResolvePersonIDFromIdentityData = OnlyDictionaryKey(matchingRelationshipIDs)
    ElseIf matchingRelationshipIDs.Count > 1 Then
        Err.Raise vbObjectError + 3410, "PersonIDForName", _
                  "同じ氏名・続柄に複数の人物IDがあります。" & _
                  "該当する登録内容を確認してください: " & personName
    End If
End Function

Private Sub IndexResolverPersonIDRelationship(ByVal relationshipByPersonID As Object, _
                                              ByVal personID As String, _
                                              ByVal relationshipText As String, _
                                              ByVal sourceLabel As String)
    Dim relationshipKey As String, storedRelationship As String
    personID = CellText(personID)
    relationshipText = CellText(relationshipText)
    relationshipKey = NormalizeRelationshipKey(relationshipText)
    If Len(personID) = 0 Or Len(relationshipKey) = 0 Then Exit Sub
    If relationshipByPersonID.Exists(personID) Then
        storedRelationship = CellText(relationshipByPersonID(personID))
        If StrComp(NormalizeRelationshipKey(storedRelationship), _
                   relationshipKey, vbBinaryCompare) <> 0 Then _
            Err.Raise vbObjectError + 3428, "PersonIDForName", _
                      "同一人物IDに異なる続柄があります。" & _
                      sourceLabel & "を確認してください: " & personID
    Else
        relationshipByPersonID.Add personID, relationshipText
    End If
End Sub

Private Sub AssertPersonIDResolverMatrix(ByRef sourceData As Variant, _
                                         ByVal rowCount As Long, _
                                         ByVal requiredColumnCount As Long, _
                                         ByVal sourceLabel As String)
    Dim firstRow As Long, lastRow As Long
    Dim firstColumn As Long, lastColumn As Long
    If rowCount < 0 Or requiredColumnCount < 1 Then GoTo InvalidMatrix
    If rowCount = 0 Then Exit Sub
    If Not IsArray(sourceData) Then GoTo InvalidMatrix
    On Error GoTo InvalidMatrix
    firstRow = LBound(sourceData, 1)
    lastRow = UBound(sourceData, 1)
    firstColumn = LBound(sourceData, 2)
    lastColumn = UBound(sourceData, 2)
    On Error GoTo 0
    If firstRow <> 1 Or firstColumn <> 1 Or lastRow <> rowCount Or _
       lastColumn < requiredColumnCount Then GoTo InvalidMatrix
    Exit Sub
InvalidMatrix:
    Err.Raise vbObjectError + 3427, "PersonIDForName", _
              sourceLabel & "の人物ID検索データが不正です。" & _
              "該当する登録内容を確認してください。"
End Sub

Private Sub AssertPersonIDRelationshipCompatible(ByVal personID As String, _
                                                  ByVal requestedRelationshipKey As String, _
                                                  ByVal personName As String)
    '人物候補の続柄だけが手修正されても、既存口座で確定済みの同一人物IDへ
    '異なる続柄を割り当てない。既存側の空欄は「未確定」として許容する。
    Dim ws As Worksheet
    Dim lastR As Long, r As Long
    Dim storedID As String, storedKey As String
    Dim accountData As Variant, candidateData As Variant
    If Len(personID) = 0 Then Exit Sub
    If Not IsInternalIdValue(personID, "P") Then _
        Err.Raise vbObjectError + 3422, "PersonIDForName", _
                  "人物IDの形式が不正です。入力候補の人物情報を確認してください: " & personID
    '空欄は未確定値であり、既知の続柄と矛盾しない。後段の候補収束で既知値へ揃える。
    If Len(requestedRelationshipKey) = 0 Then Exit Sub
    If SheetExists(SH_WORK_ACCOUNT) Then
        Set ws = GetSheet(SH_WORK_ACCOUNT)
        lastR = LastDataRowInColumns(ws, ACC_COL_ID, ACC_COL_TRANSFER_ID)
        If lastR >= 2 Then
            accountData = ws.Range(ws.Cells(2, ACC_COL_RELATIONSHIP), _
                                   ws.Cells(lastR, ACC_COL_PERSON_ID)).Value2
            For r = 1 To UBound(accountData, 1)
                storedID = CellText(accountData(r, ACC_COL_PERSON_ID - ACC_COL_RELATIONSHIP + 1))
                If StrComp(storedID, personID, vbTextCompare) = 0 Then
                    storedKey = NormalizeRelationshipKey(CellText(accountData(r, 1)))
                    If Len(storedKey) > 0 And storedKey <> requestedRelationshipKey Then
                        Err.Raise vbObjectError + 3419, "PersonIDForName", _
                                  "人物候補の続柄が登録済み口座と一致しません。人物候補を戻すか、登録済み口座から訂正してください: " & _
                                  personName & "（人物ID " & personID & "）"
                    End If
                End If
            Next r
        End If
    End If
    '改姓など別名義の人物候補も同じ人物ID契約に含める。候補側の空欄続柄は
    '未確定として許容するが、別名義に既知の異なる続柄があれば再利用しない。
    If SheetExists(SH_PERSON_CAND) Then
        Set ws = GetSheet(SH_PERSON_CAND)
        lastR = LastDataRowInColumns(ws, 1, 4)
        If lastR >= 2 Then
            candidateData = ws.Range(ws.Cells(2, 2), ws.Cells(lastR, 3)).Value2
            For r = 1 To UBound(candidateData, 1)
                storedID = CellText(candidateData(r, 1))
                If StrComp(storedID, personID, vbTextCompare) = 0 Then
                    storedKey = NormalizeRelationshipKey(CellText(candidateData(r, 2)))
                    If Len(storedKey) > 0 And storedKey <> requestedRelationshipKey Then
                        Err.Raise vbObjectError + 3426, "PersonIDForName", _
                                  "同じ人物IDの別名義候補に異なる続柄があります。人物候補または登録済み口座を確認してください: " & _
                                  personName & "（人物ID " & personID & "）"
                    End If
                End If
            Next r
        End If
    End If
End Sub

Public Function ValidatedRelationshipForPersonID(ByVal personID As String, _
                                                  ByVal requestedRelationship As String) As String
    'ID付き人物候補はW_口座の確定済み続柄と同じ契約に揃える。別名義でも同じIDなら、
    '空欄は既知値で補い、非空欄の矛盾は候補へ書き込む前に停止する。
    Dim ws As Worksheet
    Dim lastR As Long, r As Long
    Dim accountData As Variant
    Dim candidateData As Variant
    Dim storedID As String, storedRelationship As String
    Dim storedKey As String, requestedKey As String
    personID = CellText(personID)
    requestedRelationship = CellText(requestedRelationship)
    If Len(personID) = 0 Then
        ValidatedRelationshipForPersonID = requestedRelationship
        Exit Function
    End If
    If Not IsInternalIdValue(personID, "P") Then _
        Err.Raise vbObjectError + 3423, "ValidatedRelationshipForPersonID", _
                  "人物IDの形式が不正です: " & personID
    requestedKey = NormalizeRelationshipKey(requestedRelationship)
    If SheetExists(SH_PERSON_CAND) Then
        Set ws = GetSheet(SH_PERSON_CAND)
        lastR = LastDataRowInColumns(ws, 1, 4)
        If lastR >= 2 Then
            candidateData = ws.Range(ws.Cells(2, 2), ws.Cells(lastR, 3)).Value2
            For r = 1 To UBound(candidateData, 1)
                storedID = CellText(candidateData(r, 1))
                If StrComp(storedID, personID, vbTextCompare) = 0 Then
                    If Len(NormalizeRelationshipKey(CellText(candidateData(r, 2)))) > 0 Then
                        If Len(storedKey) = 0 Then
                            storedRelationship = CellText(candidateData(r, 2))
                            storedKey = NormalizeRelationshipKey(storedRelationship)
                        ElseIf storedKey <> NormalizeRelationshipKey(CellText(candidateData(r, 2))) Then
                            Err.Raise vbObjectError + 3427, "ValidatedRelationshipForPersonID", _
                                      "人物候補で同一人物IDの続柄が一致しません: " & personID
                        End If
                    End If
                End If
            Next r
        End If
    End If
    If SheetExists(SH_WORK_ACCOUNT) Then
        Set ws = GetSheet(SH_WORK_ACCOUNT)
        lastR = LastDataRowInColumns(ws, ACC_COL_ID, ACC_COL_TRANSFER_ID)
        If lastR >= 2 Then
            accountData = ws.Range(ws.Cells(2, ACC_COL_RELATIONSHIP), _
                                   ws.Cells(lastR, ACC_COL_PERSON_ID)).Value2
            For r = 1 To UBound(accountData, 1)
                storedID = CellText(accountData(r, ACC_COL_PERSON_ID - ACC_COL_RELATIONSHIP + 1))
                If StrComp(storedID, personID, vbTextCompare) = 0 Then
                    If Len(NormalizeRelationshipKey(CellText(accountData(r, 1)))) > 0 Then
                        If Len(storedKey) = 0 Then
                            storedRelationship = CellText(accountData(r, 1))
                            storedKey = NormalizeRelationshipKey(storedRelationship)
                        ElseIf storedKey <> NormalizeRelationshipKey(CellText(accountData(r, 1))) Then
                            Err.Raise vbObjectError + 3424, "ValidatedRelationshipForPersonID", _
                                      "登録済み口座で同一人物IDの続柄が一致しません: " & personID
                        End If
                    End If
                End If
            Next r
        End If
    End If
    If Len(requestedKey) > 0 And Len(storedKey) > 0 And requestedKey <> storedKey Then _
        Err.Raise vbObjectError + 3425, "ValidatedRelationshipForPersonID", _
                  "人物候補の続柄が登録済み口座と一致しません: " & personID
    If Len(requestedKey) = 0 And Len(storedKey) > 0 Then
        ValidatedRelationshipForPersonID = storedRelationship
    Else
        ValidatedRelationshipForPersonID = requestedRelationship
    End If
End Function

Public Function FindConflictingPersonIDForIdentity(ByVal personName As String, _
                                                    ByVal relationshipText As String, _
                                                    ByVal allowedPersonID As String, _
                                                    ByRef conflictingPersonID As String) As Boolean
    '訂正後の氏名+続柄が別人物IDへ既に割り当てられていないか、書込み前に確認する。
    '重複が判明する状態や、候補更新が黙って失敗する状態を作らない。
    Dim ws As Worksheet
    Dim lastR As Long, r As Long
    Dim targetKey As String, candidateID As String
    Dim accountData As Variant, candidateData As Variant
    conflictingPersonID = vbNullString
    targetKey = PersonIdentityKey(personName, relationshipText)
    If Len(targetKey) = 0 Then Exit Function

    If SheetExists(SH_WORK_ACCOUNT) Then
        Set ws = GetSheet(SH_WORK_ACCOUNT)
        lastR = LastDataRowInColumns(ws, ACC_COL_ID, ACC_COL_TRANSFER_ID)
        If lastR >= 2 Then
            accountData = ws.Range(ws.Cells(2, ACC_COL_PERSON), _
                                   ws.Cells(lastR, ACC_COL_PERSON_ID)).Value2
            For r = 1 To UBound(accountData, 1)
                If PersonIdentityKey(CellText(accountData(r, 1)), _
                                     CellText(accountData(r, ACC_COL_RELATIONSHIP - ACC_COL_PERSON + 1))) = targetKey Then
                    candidateID = CellText(accountData(r, ACC_COL_PERSON_ID - ACC_COL_PERSON + 1))
                    If Len(candidateID) > 0 And _
                       StrComp(candidateID, CellText(allowedPersonID), vbTextCompare) <> 0 Then
                        conflictingPersonID = candidateID
                        FindConflictingPersonIDForIdentity = True
                        Exit Function
                    End If
                End If
            Next r
        End If
    End If

    If SheetExists(SH_PERSON_CAND) Then
        Set ws = GetSheet(SH_PERSON_CAND)
        lastR = LastDataRowInColumns(ws, 1, 4)
        If lastR >= 2 Then
            candidateData = ws.Range(ws.Cells(2, 1), ws.Cells(lastR, 3)).Value2
            For r = 1 To UBound(candidateData, 1)
                If PersonIdentityKey(CellText(candidateData(r, 1)), _
                                     CellText(candidateData(r, 3))) = targetKey Then
                    candidateID = CellText(candidateData(r, 2))
                    If Len(candidateID) > 0 And _
                       StrComp(candidateID, CellText(allowedPersonID), vbTextCompare) <> 0 Then
                        conflictingPersonID = candidateID
                        FindConflictingPersonIDForIdentity = True
                        Exit Function
                    End If
                End If
            Next r
        End If
    End If
End Function

Public Function FindConflictingPersonIDForRelationshipChange(ByVal allowedPersonID As String, _
                                                              ByVal currentPersonName As String, _
                                                              ByVal relationshipText As String, _
                                                              ByRef conflictingPersonName As String, _
                                                              ByRef conflictingPersonID As String) As Boolean
    '続柄同期は同一人物IDの別名義にも及ぶ。入力中の氏名だけでなく、口座マスタと人物候補に
    '紐づく全氏名について「氏名+新続柄」が別IDと衝突しないことを先に確認する。
    Dim names As Object, personIDsByIdentity As Object, identityIDs As Object
    Dim ws As Worksheet
    Dim lastR As Long, r As Long
    Dim personKey As String, personName As String, candidateID As String
    Dim storedRelationship As String, identityKey As String
    Dim accountData As Variant, candidateData As Variant
    Dim item As Variant, idItem As Variant
    conflictingPersonName = vbNullString
    conflictingPersonID = vbNullString
    allowedPersonID = CellText(allowedPersonID)
    If Len(allowedPersonID) = 0 Then Exit Function

    Set names = CreateObject("Scripting.Dictionary")
    names.CompareMode = vbTextCompare
    Set personIDsByIdentity = CreateObject("Scripting.Dictionary")
    personIDsByIdentity.CompareMode = vbTextCompare
    personName = CellText(currentPersonName)
    personKey = NormalizePersonNameKey(personName)
    If Len(personKey) > 0 Then names(personKey) = personName

    If SheetExists(SH_WORK_ACCOUNT) Then
        Set ws = GetSheet(SH_WORK_ACCOUNT)
        lastR = LastDataRowInColumns(ws, ACC_COL_ID, ACC_COL_TRANSFER_ID)
        If lastR >= 2 Then
            accountData = ws.Range(ws.Cells(2, ACC_COL_PERSON), _
                                   ws.Cells(lastR, ACC_COL_PERSON_ID)).Value2
            For r = 1 To UBound(accountData, 1)
                personName = CellText(accountData(r, 1))
                storedRelationship = CellText( _
                    accountData(r, ACC_COL_RELATIONSHIP - ACC_COL_PERSON + 1))
                candidateID = CellText(accountData(r, ACC_COL_PERSON_ID - ACC_COL_PERSON + 1))
                IndexPersonIdentityIDSet personIDsByIdentity, personName, _
                                         storedRelationship, candidateID
                If StrComp(candidateID, allowedPersonID, vbTextCompare) = 0 Then
                    personKey = NormalizePersonNameKey(personName)
                    If Len(personKey) > 0 Then names(personKey) = personName
                End If
            Next r
        End If
    End If

    If SheetExists(SH_PERSON_CAND) Then
        Set ws = GetSheet(SH_PERSON_CAND)
        lastR = LastDataRowInColumns(ws, 1, 4)
        If lastR >= 2 Then
            candidateData = ws.Range(ws.Cells(2, 1), ws.Cells(lastR, 3)).Value2
            For r = 1 To UBound(candidateData, 1)
                personName = CellText(candidateData(r, 1))
                candidateID = CellText(candidateData(r, 2))
                storedRelationship = CellText(candidateData(r, 3))
                IndexPersonIdentityIDSet personIDsByIdentity, personName, _
                                         storedRelationship, candidateID
                If StrComp(candidateID, allowedPersonID, vbTextCompare) = 0 Then
                    personKey = NormalizePersonNameKey(personName)
                    If Len(personKey) > 0 Then names(personKey) = personName
                End If
            Next r
        End If
    End If

    For Each item In names.Keys
        personName = CStr(names(item))
        identityKey = PersonIdentityKey(personName, relationshipText)
        If personIDsByIdentity.Exists(identityKey) Then
            Set identityIDs = personIDsByIdentity(identityKey)
            For Each idItem In identityIDs.Keys
                candidateID = CStr(idItem)
                If StrComp(candidateID, allowedPersonID, vbTextCompare) <> 0 Then
                    conflictingPersonName = personName
                    conflictingPersonID = candidateID
                    FindConflictingPersonIDForRelationshipChange = True
                    Exit Function
                End If
            Next idItem
        End If
    Next item
End Function

Private Sub IndexPersonIdentityIDSet(ByVal personIDsByIdentity As Object, _
                                     ByVal personName As String, _
                                     ByVal relationshipText As String, _
                                     ByVal personID As String)
    Dim identityKey As String
    Dim identityIDs As Object
    If personIDsByIdentity Is Nothing Then Exit Sub
    personID = CellText(personID)
    If Len(personID) = 0 Then Exit Sub
    identityKey = PersonIdentityKey(personName, relationshipText)
    If Len(identityKey) = 0 Then Exit Sub
    If personIDsByIdentity.Exists(identityKey) Then
        Set identityIDs = personIDsByIdentity(identityKey)
    Else
        Set identityIDs = CreateObject("Scripting.Dictionary")
        identityIDs.CompareMode = vbTextCompare
        personIDsByIdentity.Add identityKey, identityIDs
    End If
    identityIDs(personID) = True
End Sub

Private Function OnlyDictionaryKey(ByVal dict As Object) As String
    Dim keys As Variant
    If dict Is Nothing Then Exit Function
    If dict.Count <> 1 Then Exit Function
    keys = dict.Keys
    OnlyDictionaryKey = CStr(keys(0))
End Function

Private Sub AddPersonIDMatch(ByVal relationshipIDs As Object, _
                             ByVal personID As String, ByVal storedRelationship As String, _
                             ByVal requestedRelationshipKey As String)
    Dim storedKey As String
    If Len(personID) = 0 Then Exit Sub
    storedKey = NormalizeRelationshipKey(storedRelationship)
    If storedKey = requestedRelationshipKey Then relationshipIDs(personID) = True
End Sub


Public Function NormalizeRelationshipKey(ByVal relationshipText As String) As String
    NormalizeRelationshipKey = NormalizePersonIdentityText(relationshipText)
End Function

Public Function PersonIdentityKey(ByVal personName As String, ByVal relationshipText As String) As String
    Dim personKey As String
    personKey = NormalizePersonNameKey(personName)
    If Len(personKey) = 0 Then Exit Function
    PersonIdentityKey = personKey & Chr$(29) & NormalizeRelationshipKey(relationshipText)
End Function

Public Function RelationshipForName(ByVal personName As String) As String
    Dim ws As Worksheet
    Dim lastR As Long, r As Long
    Dim personKey As String, relationshipKey As String, relationshipText As String
    Dim sourceData As Variant
    Dim relationships As Object
    personKey = NormalizePersonNameKey(personName)
    If Len(personKey) = 0 Then Exit Function
    Set relationships = CreateObject("Scripting.Dictionary")
    relationships.CompareMode = vbTextCompare
    If SheetExists(SH_PERSON_CAND) Then
        Set ws = GetSheet(SH_PERSON_CAND)
        lastR = LastUsedRowInSheet(ws)
        If lastR >= 2 Then sourceData = ws.Range(ws.Cells(2, 1), ws.Cells(lastR, 3)).Value2
        For r = 1 To lastR - 1
            If NormalizePersonNameKey(CellText(sourceData(r, 1))) = personKey Then
                relationshipText = CellText(sourceData(r, 3))
                relationshipKey = NormalizeRelationshipKey(relationshipText)
                If Len(relationshipKey) > 0 Then relationships(relationshipKey) = relationshipText
            End If
        Next r
    End If
    If SheetExists(SH_WORK_ACCOUNT) Then
        Set ws = GetSheet(SH_WORK_ACCOUNT)
        lastR = LastUsedRowInSheet(ws)
        If lastR >= 2 Then
            sourceData = ws.Range(ws.Cells(2, ACC_COL_PERSON), _
                                  ws.Cells(lastR, ACC_COL_RELATIONSHIP)).Value2
        End If
        For r = 1 To lastR - 1
            If NormalizePersonNameKey(CellText(sourceData(r, 1))) = personKey Then
                relationshipText = CellText(sourceData(r, ACC_COL_RELATIONSHIP - ACC_COL_PERSON + 1))
                relationshipKey = NormalizeRelationshipKey(relationshipText)
                If Len(relationshipKey) > 0 Then relationships(relationshipKey) = relationshipText
            End If
        Next r
    End If
    '同姓同名で続柄が複数あるときは、誤った人物を自動選択せず利用者の入力を待つ。
    If relationships.Count = 1 Then RelationshipForName = OnlyDictionaryValue(relationships)
End Function

Private Function OnlyDictionaryValue(ByVal dict As Object) As String
    Dim values As Variant
    If dict Is Nothing Then Exit Function
    If dict.Count <> 1 Then Exit Function
    values = dict.Items
    OnlyDictionaryValue = CStr(values(0))
End Function

Public Function NormalizePersonNameKey(ByVal personName As String) As String
    NormalizePersonNameKey = NormalizePersonIdentityText(personName)
End Function

Private Function NormalizePersonIdentityText(ByVal valueText As String) As String
    '人物同一性は見た目に現れない貼付ノイズだけを除去する。
    '異体字・互換漢字等の可視文字は変換せず、利用者の登録名を識別に残す。
    Dim s As String
    s = UCase$(CellText(valueText))
    s = Replace(s, " ", "")
    s = Replace(s, "　", "")
    s = Replace(s, vbTab, vbNullString)
    s = Replace(s, vbCr, vbNullString)
    s = Replace(s, vbLf, vbNullString)
    s = Replace(s, ChrW(11), vbNullString)
    s = Replace(s, ChrW(12), vbNullString)
    s = Replace(s, ChrW(160), vbNullString)
    s = Replace(s, ChrW(&H200B&), vbNullString)
    s = Replace(s, ChrW(&H200C&), vbNullString)
    s = Replace(s, ChrW(&H200D&), vbNullString)
    s = Replace(s, ChrW(&H2060&), vbNullString)
    s = Replace(s, ChrW(&HFEFF&), vbNullString)
    NormalizePersonIdentityText = s
End Function

Public Function VerifyCaseDataCleared(ByRef detailText As String, _
                                      Optional ByVal allowInitializingState As Boolean = False) As Boolean
    Dim problems As String
    Dim dataHealth As String
    Dim startYear As Long, endYear As Long
    Dim yearDetail As String
    Dim ws As Worksheet, memoCol As Long, c As Long
    If LastUsedRowInSheet(GetSheet(SH_WORK_ACCOUNT)) > 1 Then problems = problems & "口座 "
    If LastUsedRowInSheet(GetSheet(SH_WORK_TX)) > 1 Then problems = problems & "取引 "
    If LastUsedRowInSheet(GetSheet(SH_WORK_BAL)) > 1 Then problems = problems & "残高 "
    If LastUsedRowInSheet(GetSheet(SH_CHECK)) > 1 Then problems = problems & "確認事項 "
    If LastUsedRowInSheet(GetSheet(SH_WORK_CASH)) > 1 Then problems = problems & "資金操作表 "
    If LastUsedRowInSheet(GetSheet(SH_OUTPUT_TX_CONVERTED)) > 1 Then problems = problems & "変換済表 "
    If LastUsedRowInSheet(GetSheet(SH_OUTPUT_BAL)) > 1 Then problems = problems & "残高推移表 "
    If LastUsedRowInSheet(GetSheet(SH_ANALYSIS_SHIFT)) > 1 Then problems = problems & "資金シフト候補 "
    If LastUsedRowInSheet(GetSheet(SH_ANALYSIS_FLOW)) > 1 Then problems = problems & "資金フロー追跡 "
    If LastUsedRowInSheet(GetSheet(SH_ANALYSIS_UNKNOWN)) > 1 Then problems = problems & "不明入出金 "
    If LastUsedRowInSheet(GetSheet(SH_ANALYSIS_RESULT)) > 1 Then problems = problems & "分析結果 "
    If LastUsedRowInSheet(GetSheet(SH_WORK_ANALYSIS_GROUP)) > 1 Then problems = problems & "分析グループ "
    If LastUsedRowInSheet(GetSheet(SH_WORK_ANALYSIS_REVIEW)) > 1 Then problems = problems & "分析判断台帳 "
    If LastUsedRowInSheet(GetSheet(SH_WORK_ANALYSIS_HISTORY)) > 1 Then problems = problems & "分析判断履歴 "
    If LastUsedRowInSheet(GetSheet(SH_WORK_MANUAL_FLOW)) > 1 Then problems = problems & "手動資金候補 "
    If LastUsedRowInSheet(GetSheet(SH_BALANCE_RECONCILIATION)) > 1 Then problems = problems & "残高検算 "
    '空一覧の案内文はA4にあるため、実データ識別子のM列で判定する。
    If LastRow(GetSheet(SH_REGISTERED_ACCOUNTS), 13) > 3 Then problems = problems & "登録済み一覧 "
    If LastRow(GetSheet(SH_SHOP_TARGET), SHOP_TGT_COL_CODE) > 1 Then problems = problems & "取扱店変換一覧 "
    If CandidateHasCaseValues(SH_BANK_CAND) Then problems = problems & "銀行候補 "
    If CandidateHasCaseValues(SH_BRANCH_CAND) Then problems = problems & "支店候補 "
    If CandidateHasCaseValues(SH_PERSON_CAND) Then problems = problems & "人物候補 "
    If Len(CurrentEditAccountID()) > 0 Then problems = problems & "訂正状態 "
    If Not TryGetExactStateValue(STATE_DATA_HEALTH, dataHealth) Then
        problems = problems & "案件データ状態 "
    ElseIf dataHealth <> DATA_HEALTH_NORMAL Then
        If Not (allowInitializingState And dataHealth = DATA_HEALTH_INITIALIZING) Then _
            problems = problems & "案件データ状態 "
    End If
    If GetStateValue(STATE_NEXT_ACCOUNT, "") <> "1" Or GetStateValue(STATE_NEXT_TRANSFER, "") <> "1" Or _
       GetStateValue(STATE_NEXT_TRANSACTION, "") <> "1" Or GetStateValue(STATE_NEXT_BALANCE, "") <> "1" Then
        problems = problems & "ID採番状態 "
    End If
    If Not IsNumeric(GetStateValue(STATE_NEXT_PERSON, "")) Or Val(GetStateValue(STATE_NEXT_PERSON, "")) < 1 Then problems = problems & "人物ID採番状態 "
    If GetStateValue(STATE_OUTPUT_DIRTY, "") <> STATE_TRUE Or _
       GetStateValue(STATE_ANALYSIS_REVIEW_DIRTY, "") <> STATE_FALSE Or _
       Len(GetStateValue(STATE_LAST_BUILD, "")) > 0 Then problems = problems & "帳票更新状態 "
    If GetStateValue(STATE_INPUT_DATE_CONFIG_SAFE, "") <> STATE_TRUE Then _
        problems = problems & "入力日付設定状態 "
    If HasText(GetSheet(SH_CONFIG).Cells(ROW_CFG_INHERITANCE_DATE, COL_CFG_VALUE).Value) Then problems = problems & "相続開始日設定 "
    If Not ValidateBalanceYearSettings(startYear, endYear, yearDetail) Then
        problems = problems & "残高表示年設定 "
    ElseIf startYear <> Year(Date) - 4 Or endYear <> Year(Date) Then
        problems = problems & "残高表示年設定 "
    End If

    Set ws = GetSheet(SH_INPUT)
    If HasText(ws.Range(CELL_BANK).Value) Or HasText(ws.Range(CELL_BRANCH).Value) Or _
       HasText(ws.Range(CELL_PERSON).Value) Or HasText(ws.Range(CELL_RELATIONSHIP).Value) Or _
       HasText(ws.Range(CELL_ACCOUNT_TYPE).Value) Or _
       HasText(ws.Range(CELL_ACCOUNT_NO).Value) Or HasText(ws.Range(CELL_OPEN_DATE).Value) Or _
       HasText(ws.Range(CELL_CLOSE_DATE).Value) Then problems = problems & "口座入力欄 "
    If Application.WorksheetFunction.CountA(ws.Range(ws.Cells(TX_FIRST_ROW, COL_TX_YEAR), ws.Cells(TX_LAST_ROW, COL_TX_BALANCE))) > 0 Then problems = problems & "取引入力欄 "
    memoCol = BalanceMemoCol(ws)
    For c = BAL_FIRST_COL To memoCol
        If HasText(ws.Cells(BAL_VALUE_ROW, c).Value) And Not IsBalancePlaceholder(ws.Cells(BAL_VALUE_ROW, c).Value) Then problems = problems & "残高入力欄 ": Exit For
    Next c
    detailText = Trim$(problems)
    VerifyCaseDataCleared = (Len(detailText) = 0)
End Function

Private Function CandidateHasCaseValues(ByVal sheetName As String) As Boolean
    Dim ws As Worksheet, lastR As Long, r As Long
    Set ws = GetSheet(sheetName)
    lastR = LastDataRowInColumns(ws, 1, 4)
    For r = 2 To lastR
        If HasText(ws.Cells(r, 1).Value) And CellText(ws.Cells(r, 4).Value) <> CAND_SOURCE_COMMON Then CandidateHasCaseValues = True: Exit Function
    Next r
End Function

﻿Attribute VB_Name = "modSetupLog"
Option Explicit

Public Sub ResetSetupLog()
    Dim ws As Worksheet
    On Error GoTo EH
    Set ws = GetOrCreateSheet(SH_SETUP_LOG, True)
    If ws Is Nothing Then Err.Raise vbObjectError + 1701, "ResetSetupLog", "セットアップログを作成できません。"
    EnsureSetupLogHeader ws
    Exit Sub
EH:
    Err.Raise Err.Number, "ResetSetupLog", Err.Description
End Sub

Public Sub LogStep(ByVal categoryText As String, ByVal stepText As String, Optional ByVal stateText As String = "", Optional ByVal detailText As String = "")
    Dim ws As Worksheet
    Dim r As Long
    On Error Resume Next
    Set ws = GetOrCreateSheet(SH_SETUP_LOG, False)
    If ws Is Nothing Then Exit Sub
    'ResetSetupLogより前の工程で失敗しても、見出しのない診断ログを残さない。
    EnsureSetupLogHeader ws
    r = ws.Cells(ws.Rows.Count, 1).End(xlUp).Row + 1
    If r < 2 Then r = 2
    ws.Cells(r, 1).Value = Now
    ws.Cells(r, 2).Value = categoryText
    ws.Cells(r, 3).Value = stepText
    ws.Cells(r, 4).Value = stateText
    ws.Cells(r, 5).Value = detailText
    ws.Rows(r).VerticalAlignment = xlTop
    ws.Cells(r, 5).WrapText = True
    On Error GoTo 0
End Sub

Public Sub RecordSaveTrace(ByVal phaseText As String, ByVal stateText As String, _
                           ByVal sourcePath As String, ByVal destinationPath As String, _
                           ByVal recordSummary As String, Optional ByVal warningText As String = "")
    '通常のLogStepはセットアップ失敗中にも呼べるbest-effortログである。
    '保存監査は成功条件の一部なので、見出し・書込・読戻しを厳密に確認し、
    '記録できない場合は呼出側へ例外を返して保存成功として扱わせない。
    Dim ws As Worksheet, target As Range, formulaCell As Range
    Dim rowNo As Long, expectedData As Variant
    Dim writeStarted As Boolean
    Dim errorNumber As Long, errorDescription As String, rollbackDetail As String
    phaseText = Trim$(phaseText)
    stateText = Trim$(stateText)
    If Len(phaseText) = 0 Then _
        Err.Raise vbObjectError + 1702, "RecordSaveTrace", _
                  "保存監査の工程名が空欄です。"
    On Error GoTo EH
    If Not SheetExists(SH_SETUP_LOG) Then _
        Err.Raise vbObjectError + 1702, "RecordSaveTrace", _
                  "保存監査の記録先がありません。"
    Set ws = GetSheet(SH_SETUP_LOG)
    If CellText(ws.Cells(1, 1).Value2) <> "時刻" Or _
       CellText(ws.Cells(1, 2).Value2) <> "区分" Or _
       CellText(ws.Cells(1, 3).Value2) <> "工程" Or _
       CellText(ws.Cells(1, 4).Value2) <> "状態" Or _
       CellText(ws.Cells(1, 5).Value2) <> "詳細" Then _
        Err.Raise vbObjectError + 1703, "RecordSaveTrace", _
                  "保存監査の見出しが一致しません。"
    rowNo = LastDataRowInColumns(ws, 1, 5) + 1
    If rowNo < 2 Then rowNo = 2
    If rowNo > ws.Rows.Count Or rowNo - 1 > MAX_INTERNAL_STORE_DATA_ROWS Then _
        Err.Raise vbObjectError + 1704, "RecordSaveTrace", _
                  "保存監査ログの空き行がありません。"
    ReDim expectedData(1 To 1, 1 To 5)
    expectedData(1, 1) = CDbl(Now)
    expectedData(1, 2) = "保存"
    expectedData(1, 3) = phaseText
    expectedData(1, 4) = stateText
    expectedData(1, 5) = Left$( _
        "元=" & sourcePath & " / 先=" & destinationPath & _
        " / " & recordSummary & _
        IIf(Len(warningText) > 0, " / 警告=" & warningText, " / 警告=なし"), 30000)
    Set target = ws.Range(ws.Cells(rowNo, 1), ws.Cells(rowNo, 5))
    target.ClearContents
    target.Columns(2).Resize(, 4).NumberFormatLocal = "@"
    writeStarted = True
    target.Value2 = expectedData
    If Not RangeValue2MatchesMatrixStrict(target, expectedData, 1, 5) Then _
        Err.Raise vbObjectError + 1705, "RecordSaveTrace", _
                  "保存監査ログの書込読戻しが全列・型で一致しません。"
    If Not TryFindFirstFormulaCell(target, formulaCell) Then _
        Err.Raise vbObjectError + 1705, "RecordSaveTrace", _
                  "保存監査ログの数式検査を実行できません。"
    If Not formulaCell Is Nothing Then _
        Err.Raise vbObjectError + 1705, "RecordSaveTrace", _
                  "保存監査ログへ数式が混入しました。"
    ws.Rows(rowNo).VerticalAlignment = xlTop
    ws.Cells(rowNo, 5).WrapText = True
    Exit Sub
EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    If writeStarted Then
        On Error Resume Next
        target.ClearContents
        If Err.Number <> 0 Then rollbackDetail = _
            " / 不完全な保存監査行を消去できません: Err " & _
            CStr(Err.Number) & " " & Err.Description
        Err.Clear
        On Error GoTo 0
    End If
    Err.Raise errorNumber, "RecordSaveTrace", errorDescription & rollbackDetail
End Sub

Private Sub EnsureSetupLogHeader(ByVal ws As Worksheet)
    If ws Is Nothing Then Exit Sub
    With ws
        If CellText(.Cells(1, 1).Value2) <> "時刻" Or _
           CellText(.Cells(1, 2).Value2) <> "区分" Or _
           CellText(.Cells(1, 3).Value2) <> "工程" Or _
           CellText(.Cells(1, 4).Value2) <> "状態" Or _
           CellText(.Cells(1, 5).Value2) <> "詳細" Then _
            SetRowValues .Range("A1"), Array("時刻", "区分", "工程", "状態", "詳細")
        .Range("A1:E1").Font.Bold = True
        .Range("A1:E1").Interior.Color = RGB(68, 114, 196)
        .Range("A1:E1").Font.Color = vbWhite
        .Columns("A:A").ColumnWidth = 20
        .Columns("B:B").ColumnWidth = 12
        .Columns("C:C").ColumnWidth = 26
        .Columns("D:D").ColumnWidth = 16
        .Columns("E:E").ColumnWidth = 80
        .Columns("B:E").NumberFormatLocal = "@"
        .Columns("A:A").NumberFormatLocal = "yyyy/m/d h:mm:ss"
        .Columns("E:E").WrapText = True
        .Rows(1).RowHeight = 24
    End With
End Sub

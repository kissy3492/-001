Attribute VB_Name = "modRelationshipDiagramAudit"
Option Explicit

'�����֌W�}�̕`��O�č��B
'�}�`�̌����ڂ����Œ��[���̂��B���Ȃ����߁A�e�q�����E�O�z��҂Ƃ̎q�E�Ǘ��q����C_�`�F�b�N�֏o���B

Public Sub AuditRelationshipDiagramBeforeBuild(ByVal decedentId As String)
    Dim wp As Worksheet, wr As Worksheet, wc As Worksheet
    Dim outR As Long, issueCount As Long
    Dim childParents As Object, relRowsByChild As Object
    Dim r As Long, parentId As String, childId As String, reasonText As String
    Dim currentSpouseId As String

    On Error GoTo SafeExit
    If Len(decedentId) = 0 Then Exit Sub
    If Not SheetExists(SH_W_PERSON, ThisWorkbook) Then Exit Sub
    If Not SheetExists(SH_W_REL, ThisWorkbook) Then Exit Sub
    If Not SheetExists(SH_CHECK, ThisWorkbook) Then Exit Sub

    Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)
    Set wr = ThisWorkbook.Worksheets(SH_W_REL)
    Set wc = ThisWorkbook.Worksheets(SH_CHECK)

    On Error Resume Next
    wc.Unprotect Password:=TOOL_PASSWORD
    On Error GoTo SafeExit
    ClearPriorRelationshipDiagramAudit wc
    outR = LastRow(wc, 1) + 1
    If outR < 4 Then outR = 4

    Set childParents = CreateObject("Scripting.Dictionary")
    Set relRowsByChild = CreateObject("Scripting.Dictionary")
    currentSpouseId = DiagramAuditCurrentSpouseId(decedentId)

    For r = 2 To LastRow(wr, 1)
        If CStr(wr.Cells(r, R_STATUS).Value) <> STATUS_CANCEL And CStr(wr.Cells(r, R_TYPE).Value) = "�e�q" Then
            parentId = "": childId = "": reasonText = ""
            If DiagramAuditResolveParentChild(wr, r, parentId, childId, reasonText) Then
                DiagramAuditAddParent childParents, childId, parentId
                DiagramAuditAddParent relRowsByChild, childId, CStr(r)
                If parentId = childId Then
                    DiagramAuditAddCheck wc, outR, "�G���[", "�e�q�֌W�œ���l�����e�q�o���ɓ����Ă��܂��B", childId, DiagramAuditPersonName(childId), "�����֌W�}�č�", "W_�֌W�̐e�q�s���C��", issueCount
                End If
            Else
                If Len(reasonText) > 0 Then
                    DiagramAuditAddCheck wc, outR, "�x��", "�e�q�֌W�̐e�q�������m��ł��܂���B " & reasonText, _
                        CStr(wr.Cells(r, R_BASE_ID).Value), CStr(wr.Cells(r, R_OTHER_ID).Value), "�����֌W�}�č�", "�����Ɛe�q�֌W���m�F", issueCount
                Else
                    DiagramAuditAddCheck wc, outR, "�x��", "�e�q�֌W�̐e�q�������m��ł��܂���B", _
                        CStr(wr.Cells(r, R_BASE_ID).Value), CStr(wr.Cells(r, R_OTHER_ID).Value), "�����֌W�}�č�", "�����Ɛe�q�֌W���m�F", issueCount
                End If
            End If
        End If
    Next r

    AuditDiagramVisibleDescendants wp, wc, outR, issueCount, decedentId, currentSpouseId, childParents, relRowsByChild

    If issueCount = 0 Then
        DiagramAuditAddPlain wc, outR, "OK", "�����֌W�}�̐e�q�����E�O�z��ҍ����E�Ǘ��q���̎��O�č��ŏd��x���͂���܂���B", "�����֌W�}�č�", "�}�`�z�u��̌��؂�E���d�Ȃ�͕ʓr�x�����m�F"
    End If

    wc.Columns("A:G").AutoFit
    On Error Resume Next
    wc.Protect Password:=TOOL_PASSWORD, UserInterfaceOnly:=True
SafeExit:
End Sub

Private Sub AuditDiagramVisibleDescendants(ByVal wp As Worksheet, ByVal wc As Worksheet, ByRef outR As Long, ByRef issueCount As Long, _
        ByVal decedentId As String, ByVal currentSpouseId As String, ByVal childParents As Object, ByVal relRowsByChild As Object)
    Dim r As Long, pid As String, relText As String, levelValue As Long, parentList As String
    Dim hasDecParent As Boolean, hasCurrentSpouseParent As Boolean, hasAnyParent As Boolean
    Dim oldSpouseNote As Boolean

    For r = 2 To LastRow(wp, 1)
        If CStr(wp.Cells(r, P_STATUS).Value) <> STATUS_CANCEL And CStr(wp.Cells(r, P_SHOW).Value) <> SHOW_NO Then
            pid = CStr(wp.Cells(r, P_ID).Value)
            If Len(pid) > 0 And pid <> decedentId Then
                relText = CStr(wp.Cells(r, P_REL_DEC).Value)
                levelValue = DiagramAuditDescendantLevel(relText)
                If levelValue > 0 Then
                    parentList = DiagramAuditDictText(childParents, pid)
                    hasAnyParent = (Len(parentList) > 0)
                    hasDecParent = DiagramAuditListContains(parentList, decedentId)
                    hasCurrentSpouseParent = (Len(currentSpouseId) > 0 And DiagramAuditListContains(parentList, currentSpouseId))
                    oldSpouseNote = DiagramAuditLooksOldSpouseChild(relText)

                    If levelValue = 1 Then
                        If Not hasDecParent Then
                            DiagramAuditAddCheck wc, outR, "�x��", "�푊���l���猩���q�ł����A�푊���l��e�Ƃ���e�q�֌W���m�F�ł��܂���B", _
                                pid, CStr(wp.Cells(r, P_DISPLAY).Value), "�����֌W�}�č�", "�푊���l���q�̐e�q�֌W��o�^", issueCount
                        End If
                        If oldSpouseNote And hasCurrentSpouseParent Then
                            DiagramAuditAddCheck wc, outR, "�G���[", "�O�z��҂Ƃ̎q�̒��L������܂����A���ݔz��҂��e�Ƃ��ĕR�Â��Ă��܂��B���ݕv�w�����牺����}���̌����ɂȂ�܂��B", _
                                pid, CStr(wp.Cells(r, P_DISPLAY).Value), "�����֌W�}�č�", "�e�q�֌W�Ƒ������L���C��", issueCount
                        ElseIf Len(currentSpouseId) > 0 And hasDecParent And Not hasCurrentSpouseParent Then
                            DiagramAuditAddPlain wc, outR, "�m�F", "���ݔz��҂̐e�q�֌W���Ȃ��q�́A�v�w�����ł͂Ȃ��푊���l�J�[�h������������낵�܂��B", _
                                CStr(wp.Cells(r, P_DISPLAY).Value), "�O�z��҂Ƃ̎q�E�A��q���̒��L���m�F"
                        End If
                    ElseIf levelValue > 1 Then
                        If Not hasAnyParent Then
                            DiagramAuditAddCheck wc, outR, "�G���[", "���ȉ��̐l���ł����A���㐢��̐e�q�֌W���m�F�ł��܂���B�����Ǘ��\����ʐl�����̌����ɂȂ�܂��B", _
                                pid, CStr(wp.Cells(r, P_DISPLAY).Value), "�����֌W�}�č�", "�e�l������q�Ƃ��ēo�^������", issueCount
                        End If
                    End If

                    If DiagramAuditParentCount(parentList) > 2 Then
                        DiagramAuditAddCheck wc, outR, "�x��", "�e�Ƃ��ĕR�Â��l����3���ȏ゠��܂��B���e�E�{�e�E�L�ڌ�����ʂ��Ă��������B", _
                            pid, CStr(wp.Cells(r, P_DISPLAY).Value), "�����֌W�}�č�", "�e�q�֌W�𐮗����A�K�v�Ȃ�{�q���L������", issueCount
                    End If
                End If
            End If
        End If
    Next r
End Sub

Private Function DiagramAuditResolveParentChild(ByVal wr As Worksheet, ByVal relRow As Long, ByRef parentId As String, ByRef childId As String, ByRef reasonText As String) As Boolean
    Dim baseId As String, otherId As String, baseRow As Long, otherRow As Long
    Dim baseLevel As Long, otherLevel As Long, baseRel As String, otherRel As String
    baseId = CStr(wr.Cells(relRow, R_BASE_ID).Value)
    otherId = CStr(wr.Cells(relRow, R_OTHER_ID).Value)
    If Len(baseId) = 0 Or Len(otherId) = 0 Then reasonText = "�l��ID����ł��B": Exit Function
    If baseId = otherId Then reasonText = "����l��ID�ł��B": Exit Function
    baseRow = FindPersonRow(baseId)
    otherRow = FindPersonRow(otherId)
    If baseRow = 0 Or otherRow = 0 Then reasonText = "�l���\�ɑ��݂��Ȃ��l��ID�ł��B": Exit Function
    baseRel = GetPersonValue(baseId, P_REL_DEC)
    otherRel = GetPersonValue(otherId, P_REL_DEC)
    baseLevel = DiagramAuditParentLevel(baseRel)
    otherLevel = DiagramAuditDescendantLevel(otherRel)
    If DiagramAuditIsExpected(baseRel, otherRel) Then
        parentId = baseId: childId = otherId: DiagramAuditResolveParentChild = True: Exit Function
    End If
    If DiagramAuditIsExpected(otherRel, baseRel) Then
        parentId = otherId: childId = baseId: DiagramAuditResolveParentChild = True: Exit Function
    End If
    reasonText = "����=" & baseRel & " / " & otherRel
End Function

Private Function DiagramAuditCurrentSpouseId(ByVal decedentId As String) As String
    Dim wr As Worksheet, r As Long, b As String, o As String, otherId As String, relText As String
    If Len(decedentId) = 0 Or Not SheetExists(SH_W_REL, ThisWorkbook) Then Exit Function
    Set wr = ThisWorkbook.Worksheets(SH_W_REL)
    For r = 2 To LastRow(wr, 1)
        If CStr(wr.Cells(r, R_STATUS).Value) <> STATUS_CANCEL And CStr(wr.Cells(r, R_TYPE).Value) = "�z���" Then
            b = CStr(wr.Cells(r, R_BASE_ID).Value): o = CStr(wr.Cells(r, R_OTHER_ID).Value)
            otherId = ""
            If b = decedentId Then otherId = o
            If o = decedentId Then otherId = b
            If Len(otherId) > 0 Then
                relText = GetPersonValue(otherId, P_REL_DEC) & " " & CStr(wr.Cells(r, R_DISPLAY).Value) & " " & CStr(wr.Cells(r, R_NOTE).Value)
                If InStr(relText, "�O�z���") = 0 And InStr(relText, "�O��") = 0 And InStr(relText, "�O�v") = 0 Then
                    DiagramAuditCurrentSpouseId = otherId
                    Exit Function
                End If
            End If
        End If
    Next r
End Function

Private Function DiagramAuditIsExpected(ByVal parentRel As String, ByVal childRel As String) As Boolean
    Dim pLevel As Long, cLevel As Long
    pLevel = DiagramAuditParentLevel(parentRel)
    cLevel = DiagramAuditDescendantLevel(childRel)
    If pLevel = 0 Then
        DiagramAuditIsExpected = (cLevel = 1)
    ElseIf pLevel > 0 Then
        DiagramAuditIsExpected = (cLevel = pLevel + 1)
    End If
End Function

Private Function DiagramAuditParentLevel(ByVal relText As String) As Long
    Dim rawText As String
    rawText = CleanText(relText)
    If Len(rawText) = 0 Then Exit Function
    If InStr(rawText, "�푊���l") > 0 Or InStr(rawText, "�z���") > 0 Or InStr(rawText, "�O�z���") > 0 Then
        DiagramAuditParentLevel = 0
    Else
        DiagramAuditParentLevel = DiagramAuditDescendantLevel(rawText)
    End If
End Function

Private Function DiagramAuditDescendantLevel(ByVal relText As String) As Long
    relText = DiagramAuditBaseRelation(CleanText(relText))
    If DiagramAuditContainsGreatGrandchild(relText) And InStr(relText, "�z���") > 0 And InStr(relText, "�q") > 0 Then
        DiagramAuditDescendantLevel = 4
    ElseIf InStr(relText, "��") > 0 And Not DiagramAuditContainsGreatGrandchild(relText) And InStr(relText, "�z���") > 0 And InStr(relText, "�q") > 0 Then
        DiagramAuditDescendantLevel = 3
    ElseIf InStr(relText, "�z���") > 0 Then
        Exit Function
    ElseIf DiagramAuditDirectChild(relText) Then
        DiagramAuditDescendantLevel = 1
    ElseIf Left$(relText, 2) = "��" Then
        DiagramAuditDescendantLevel = 2
    ElseIf DiagramAuditIsGreatGrandchild(relText) Then
        DiagramAuditDescendantLevel = 3
    ElseIf Left$(relText, 2) = "����" Then
        DiagramAuditDescendantLevel = 4
    End If
End Function


Private Function DiagramAuditContainsGreatGrandchild(ByVal relText As String) As Boolean
    relText = DiagramAuditBaseRelation(CleanText(relText))
    If InStr(relText, "�]��") > 0 Then
        DiagramAuditContainsGreatGrandchild = True
    ElseIf InStr(relText, "�\��") > 0 Then
        DiagramAuditContainsGreatGrandchild = True
    ElseIf InStr(relText, "�Б�") > 0 Then
        DiagramAuditContainsGreatGrandchild = True
    End If
End Function

Private Function DiagramAuditIsGreatGrandchild(ByVal relText As String) As Boolean
    relText = DiagramAuditBaseRelation(CleanText(relText))
    If relText = "�]��" Or Left$(relText, 2) = "�]��" Then
        DiagramAuditIsGreatGrandchild = True
    ElseIf relText = "�\��" Or Left$(relText, 2) = "�\��" Then
        DiagramAuditIsGreatGrandchild = True
    ElseIf relText = "�Б�" Or Left$(relText, 3) = "�Б�" Then
        DiagramAuditIsGreatGrandchild = True
    End If
End Function

Private Function DiagramAuditBaseRelation(ByVal relText As String) As String
    Dim p As Long, q As Long
    p = InStr(1, relText, "�i", vbTextCompare)
    If p > 1 Then q = InStr(p + 1, relText, "�j", vbTextCompare)
    If p = 0 Then
        p = InStr(1, relText, "(", vbTextCompare)
        If p > 1 Then q = InStr(p + 1, relText, ")", vbTextCompare)
    End If
    If p > 1 And q = Len(relText) Then relText = Left$(relText, p - 1)
    DiagramAuditBaseRelation = relText
End Function

Private Function DiagramAuditDirectChild(ByVal relText As String) As Boolean
    Select Case relText
        Case "�q", "�{�q"
            DiagramAuditDirectChild = True
            Exit Function
    End Select
    Select Case True
        Case InStr(relText, "���j") > 0, InStr(relText, "��j") > 0, InStr(relText, "�O�j") > 0, _
             InStr(relText, "�l�j") > 0, InStr(relText, "�ܒj") > 0, InStr(relText, "�Z�j") > 0, _
             InStr(relText, "����") > 0, InStr(relText, "��") > 0, InStr(relText, "�O��") > 0, _
             InStr(relText, "�l��") > 0, InStr(relText, "�܏�") > 0, InStr(relText, "�Z��") > 0
            DiagramAuditDirectChild = True
            Exit Function
    End Select
    If InStr(relText, "�q") > 0 Then
        If InStr(relText, "��") = 0 Then
            If InStr(relText, "�z���") = 0 Then DiagramAuditDirectChild = True
        End If
    End If
End Function

Private Function DiagramAuditLooksOldSpouseChild(ByVal relText As String) As Boolean
    relText = CleanText(relText)
    DiagramAuditLooksOldSpouseChild = (InStr(relText, "�O�z���") > 0 Or InStr(relText, "�O��") > 0 Or InStr(relText, "�O�v") > 0)
End Function

Private Sub DiagramAuditAddParent(ByVal dict As Object, ByVal childId As String, ByVal parentId As String)
    If Len(childId) = 0 Or Len(parentId) = 0 Then Exit Sub
    If dict.Exists(childId) Then
        If Not DiagramAuditListContains(CStr(dict(childId)), parentId) Then dict(childId) = CStr(dict(childId)) & "," & parentId
    Else
        dict.Add childId, parentId
    End If
End Sub

Private Function DiagramAuditDictText(ByVal dict As Object, ByVal keyText As String) As String
    If dict Is Nothing Then Exit Function
    If dict.Exists(keyText) Then DiagramAuditDictText = CStr(dict(keyText))
End Function

Private Function DiagramAuditListContains(ByVal listText As String, ByVal valueText As String) As Boolean
    Dim arr As Variant, i As Long
    If Len(valueText) = 0 Or Len(listText) = 0 Then Exit Function
    arr = Split(listText, ",")
    For i = LBound(arr) To UBound(arr)
        If Trim$(CStr(arr(i))) = valueText Then DiagramAuditListContains = True: Exit Function
    Next i
End Function

Private Function DiagramAuditParentCount(ByVal listText As String) As Long
    If Len(listText) = 0 Then Exit Function
    DiagramAuditParentCount = UBound(Split(listText, ",")) + 1
End Function

Private Function DiagramAuditPersonName(ByVal personId As String) As String
    If Len(personId) > 0 Then DiagramAuditPersonName = GetPersonValue(personId, P_DISPLAY)
End Function

Private Sub ClearPriorRelationshipDiagramAudit(ByVal ws As Worksheet)
    Dim r As Long
    For r = LastRow(ws, 1) To 2 Step -1
        If CStr(ws.Cells(r, 5).Value) = "�����֌W�}�č�" Then ws.Rows(r).Delete
    Next r
End Sub

Private Sub DiagramAuditAddCheck(ByVal ws As Worksheet, ByRef outR As Long, ByVal levelText As String, ByVal msgText As String, _
        ByVal pid As String, ByVal nameText As String, ByVal targetText As String, ByVal actionText As String, ByRef issueCount As Long)
    ws.Cells(outR, 1).Value = levelText
    ws.Cells(outR, 2).Value = msgText
    ws.Cells(outR, 3).Value = pid
    ws.Cells(outR, 4).Value = nameText
    ws.Cells(outR, 5).Value = targetText
    ws.Cells(outR, 6).Value = actionText
    ws.Cells(outR, 7).Value = Now
    If levelText = "�G���[" Or levelText = "�x��" Then issueCount = issueCount + 1
    outR = outR + 1
End Sub

Private Sub DiagramAuditAddPlain(ByVal ws As Worksheet, ByRef outR As Long, ByVal levelText As String, ByVal msgText As String, ByVal targetText As String, ByVal actionText As String)
    ws.Cells(outR, 1).Value = levelText
    ws.Cells(outR, 2).Value = msgText
    ws.Cells(outR, 5).Value = targetText
    ws.Cells(outR, 6).Value = actionText
    ws.Cells(outR, 7).Value = Now
    outR = outR + 1
End Sub

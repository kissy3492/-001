IMPORT_01_MODULES.bat imports all 01 modules into an existing macro-enabled workbook.

Recommended use:
1. Extract the ZIP first. Do not run from inside the ZIP preview.
2. Save or sync the target workbook as a local .xlsm file. Do not pass an http/https URL.
3. Drag the target 01 .xlsm file onto IMPORT_01_MODULES.bat.
4. If a security message appears, enable Trust access to the VBA project object model.
5. After import, open VBE and run Compile VBAProject.

Important:
The importer owns only the standard modules listed in modules\IMPORT_ORDER.txt. It replaces those modules by exact name and preserves unrelated standard modules, class modules, sheet modules, and ThisWorkbook (except for the intentional ThisWorkbook code replacement).
Manual import without removing the old owned modules is unsafe. Excel can create modOutputs1, modSetup1, etc., while the old modOutputs remains callable. This can make old drawing code run even after new files were imported.

This import script:
- creates a backup next to the target workbook before changes
- removes only the old owned standard modules before import
- verifies that the owned standard modules were actually removed
- preserves unrelated standard modules, class modules, ThisWorkbook, and sheet modules
- reads .bas files through ADODB.Stream as shift_jis
- creates standard modules explicitly and inserts code through CodeModule.InsertLines
- does not use VBComponents.Import for .bas files
- rewrites ThisWorkbook code without deleting sheet modules
- verifies that every ordered standard module exists after import
- runs non-destructive SetupWorkbook after import and checks its success flag
- does not save a partially imported workbook when SetupWorkbook reports failure
- reports IMPORT_OK or IMPORT_FAILED with the failed stage

Return codes:
0 = imported and SetupWorkbook ran
1 = import failed before save
2 = modules were imported but SetupWorkbook did not complete; the target workbook was not saved

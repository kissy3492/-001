Attribute VB_Name = "modFamilyModel"
Option Explicit

'V2 �Ƒ��������f��
'���́E�ۑ��E���[�œ����l��ID�֌W���Q�Ƃ���B����������͕\���ɂ����g���A
'�ʏ폈���ł͕����񂩂�e�q�����Đ��肵�Ȃ��B

Private mBuilt As Boolean
Private mDecedentId As String
Private mPersonRows As Object
Private mParentsByChild As Object
Private mPrimaryParentByChild As Object
Private mChildrenByParent As Object
Private mSpousesByPerson As Object
Private mPreferredSpouseByPerson As Object
Private mCoupleMarriage As Object
Private mCoupleDivorce As Object
Private mGenerationByPerson As Object
Private mDisplayRelationByPerson As Object
Private mPureSpouse As Object
Private mUnresolved As Object
Private mChildKindByChild As Object
Private mChildConfidenceByChild As Object
Private mChildEvidenceByChild As Object
Private mChildFamilyKeyByChild As Object
Private mWarnings As Object

Public Sub FamilyModelInvalidate()
    mBuilt = False
    mDecedentId = vbNullString
    Set mPersonRows = Nothing
    Set mParentsByChild = Nothing
    Set mPrimaryParentByChild = Nothing
    Set mChildrenByParent = Nothing
    Set mSpousesByPerson = Nothing
    Set mPreferredSpouseByPerson = Nothing
    Set mCoupleMarriage = Nothing
    Set mCoupleDivorce = Nothing
    Set mGenerationByPerson = Nothing
    Set mDisplayRelationByPerson = Nothing
    Set mPureSpouse = Nothing
    Set mUnresolved = Nothing
    Set mChildKindByChild = Nothing
    Set mChildConfidenceByChild = Nothing
    Set mChildEvidenceByChild = Nothing
    Set mChildFamilyKeyByChild = Nothing
    Set mWarnings = Nothing
End Sub

Public Function FamilyModelIsBuilt() As Boolean
    FamilyModelIsBuilt = mBuilt
End Function

Public Function FamilyModelEnsureBuilt(ByVal decedentId As String) As Boolean
    decedentId = CleanText(decedentId)
    If Len(decedentId) = 0 Then Exit Function
    If mBuilt Then
        If mDecedentId = decedentId Then
            FamilyModelEnsureBuilt = True
            Exit Function
        End If
    End If
    FamilyModelBuild decedentId
    FamilyModelEnsureBuilt = mBuilt
End Function

Public Function FamilyModelRebuild(ByVal decedentId As String, Optional ByVal raiseOnError As Boolean = False) As Boolean
    On Error GoTo EH
    FamilyModelInvalidate
    FamilyModelBuild decedentId
    FamilyModelRebuild = mBuilt
    Exit Function
EH:
    FamilyModelInvalidate
    If raiseOnError Then Err.Raise Err.Number, Err.Source, Err.Description
End Function

Private Sub FamilyModelBuild(ByVal decedentId As String)
    On Error GoTo EH
    FamilyModelInvalidate
    mDecedentId = CleanText(decedentId)
    If Len(mDecedentId) = 0 Then Err.Raise vbObjectError + 9401, "FamilyModelBuild", "�푊���l�l��ID����ł��B"
    FamilyInitDictionaries
    FamilyLoadPersons
    If Not mPersonRows.Exists(mDecedentId) Then Err.Raise vbObjectError + 9402, "FamilyModelBuild", "�푊���l���L���Ȑl���\�ɑ��݂��܂���B"
    FamilyLoadRelations
    FamilyLoadMarriageHistory
    FamilyChoosePreferredSpouses
    FamilyBuildLineage
    FamilyBuildDisplayRelations
    FamilyValidateFacts
    mBuilt = True
    Exit Sub
EH:
    FamilyAddWarning "���f���\�z", Err.Description
    mBuilt = False
    Err.Raise Err.Number, Err.Source, Err.Description
End Sub

Private Sub FamilyInitDictionaries()
    Set mPersonRows = CreateObject("Scripting.Dictionary")
    Set mParentsByChild = CreateObject("Scripting.Dictionary")
    Set mPrimaryParentByChild = CreateObject("Scripting.Dictionary")
    Set mChildrenByParent = CreateObject("Scripting.Dictionary")
    Set mSpousesByPerson = CreateObject("Scripting.Dictionary")
    Set mPreferredSpouseByPerson = CreateObject("Scripting.Dictionary")
    Set mCoupleMarriage = CreateObject("Scripting.Dictionary")
    Set mCoupleDivorce = CreateObject("Scripting.Dictionary")
    Set mGenerationByPerson = CreateObject("Scripting.Dictionary")
    Set mDisplayRelationByPerson = CreateObject("Scripting.Dictionary")
    Set mPureSpouse = CreateObject("Scripting.Dictionary")
    Set mUnresolved = CreateObject("Scripting.Dictionary")
    Set mChildKindByChild = CreateObject("Scripting.Dictionary")
    Set mChildConfidenceByChild = CreateObject("Scripting.Dictionary")
    Set mChildEvidenceByChild = CreateObject("Scripting.Dictionary")
    Set mChildFamilyKeyByChild = CreateObject("Scripting.Dictionary")
    Set mWarnings = CreateObject("Scripting.Dictionary")
End Sub

Private Sub FamilyLoadPersons()
    Dim ws As Worksheet, lastR As Long, data As Variant, r As Long
    Dim pid As String, statusText As String, showText As String
    If Not SheetExists(SH_W_PERSON, ThisWorkbook) Then Exit Sub
    Set ws = ThisWorkbook.Worksheets(SH_W_PERSON)
    lastR = LastRow(ws, P_ID)
    If lastR < 2 Then Exit Sub
    data = ws.Range(ws.Cells(1, 1), ws.Cells(lastR, P_DIVORCE)).Value2
    For r = 2 To UBound(data, 1)
        pid = CleanText(data(r, P_ID))
        statusText = CleanText(data(r, P_STATUS))
        showText = CleanText(data(r, P_SHOW))
        If Len(pid) > 0 And statusText <> STATUS_CANCEL Then
            If showText <> SHOW_NO Or pid = mDecedentId Then
                If Not mPersonRows.Exists(pid) Then mPersonRows.Add pid, r
            End If
        End If
    Next r
End Sub

Private Sub FamilyLoadRelations()
    Dim ws As Worksheet, lastR As Long, data As Variant, r As Long
    Dim leftId As String, rightId As String, relType As String
    Dim childKind As String, confidenceText As String, evidenceText As String, familyKey As String
    If Not SheetExists(SH_W_REL, ThisWorkbook) Then Exit Sub
    Set ws = ThisWorkbook.Worksheets(SH_W_REL)
    lastR = LastRow(ws, R_ID)
    If lastR < 2 Then Exit Sub
    data = ws.Range(ws.Cells(1, 1), ws.Cells(lastR, R_FACT_VERSION)).Value2

    '��ɕv�w������ǂށB�e�q�̕v�w����������œ����������g���B
    For r = 2 To UBound(data, 1)
        If CleanText(data(r, R_STATUS)) <> STATUS_CANCEL Then
            relType = CleanText(data(r, R_TYPE))
            If FamilyModelIsSpouseRelationType(relType) Then
                leftId = CleanText(data(r, R_BASE_ID))
                rightId = CleanText(data(r, R_OTHER_ID))
                FamilyAddSpouse leftId, rightId, data(r, R_MARRIAGE), data(r, R_DIVORCE)
            End If
        End If
    Next r

    'V2�ł͐e�q�s�̌����͏�� R_BASE_ID=�e / R_OTHER_ID=�q�B
    For r = 2 To UBound(data, 1)
        If CleanText(data(r, R_STATUS)) <> STATUS_CANCEL Then
            relType = CleanText(data(r, R_TYPE))
            If FamilyModelIsParentChildType(relType) Then
                leftId = CleanText(data(r, R_BASE_ID))
                rightId = CleanText(data(r, R_OTHER_ID))
                childKind = CleanText(data(r, R_CHILD_KIND))
                confidenceText = CleanText(data(r, R_CONFIDENCE))
                evidenceText = CleanText(data(r, R_EVIDENCE))
                familyKey = CleanText(data(r, R_FAMILY_KEY))
                FamilyAddParentChild leftId, rightId, childKind, confidenceText, evidenceText, familyKey
            End If
        End If
    Next r
End Sub

Private Sub FamilyLoadMarriageHistory()
    Dim ws As Worksheet, lastR As Long, data As Variant, r As Long
    Dim leftId As String, rightId As String
    If Not SheetExists(SH_W_MARRIAGE_HIST, ThisWorkbook) Then Exit Sub
    Set ws = ThisWorkbook.Worksheets(SH_W_MARRIAGE_HIST)
    lastR = LastRow(ws, MH_ID)
    If lastR < 2 Then Exit Sub
    data = ws.Range(ws.Cells(1, 1), ws.Cells(lastR, MH_SOURCE_ID)).Value2
    For r = 2 To UBound(data, 1)
        If CleanText(data(r, MH_STATUS)) <> STATUS_CANCEL And CleanText(data(r, MH_SHOW)) <> SHOW_NO Then
            leftId = CleanText(data(r, MH_PERSON_ID))
            rightId = CleanText(data(r, MH_COUNTERPART_ID))
            If Len(leftId) > 0 And Len(rightId) > 0 Then
                FamilyAddSpouse leftId, rightId, data(r, MH_MARRIAGE), data(r, MH_DIVORCE)
            End If
        End If
    Next r
End Sub

Private Sub FamilyAddSpouse(ByVal leftId As String, ByVal rightId As String, ByVal marriageDate As Variant, ByVal divorceDate As Variant)
    Dim pairKey As String
    leftId = CleanText(leftId)
    rightId = CleanText(rightId)
    If Len(leftId) = 0 Or Len(rightId) = 0 Or leftId = rightId Then Exit Sub
    If Not mPersonRows.Exists(leftId) Or Not mPersonRows.Exists(rightId) Then Exit Sub
    FamilyCollectionAddUnique mSpousesByPerson, leftId, rightId
    FamilyCollectionAddUnique mSpousesByPerson, rightId, leftId
    pairKey = FamilyModelPairKey(leftId, rightId)
    If Not mCoupleMarriage.Exists(pairKey) Then
        mCoupleMarriage.Add pairKey, SameDateOrBlank(marriageDate)
        mCoupleDivorce.Add pairKey, SameDateOrBlank(divorceDate)
    Else
        If Not HasInputDate(mCoupleMarriage(pairKey)) And HasInputDate(marriageDate) Then mCoupleMarriage(pairKey) = SameDateOrBlank(marriageDate)
        If Not HasInputDate(mCoupleDivorce(pairKey)) And HasInputDate(divorceDate) Then mCoupleDivorce(pairKey) = SameDateOrBlank(divorceDate)
    End If
End Sub

Private Sub FamilyAddParentChild(ByVal parentId As String, ByVal childId As String, _
        ByVal childKind As String, ByVal confidenceText As String, _
        ByVal evidenceText As String, ByVal familyKey As String)
    parentId = CleanText(parentId)
    childId = CleanText(childId)
    If Len(parentId) = 0 Or Len(childId) = 0 Or parentId = childId Then Exit Sub
    If Not mPersonRows.Exists(parentId) Or Not mPersonRows.Exists(childId) Then Exit Sub
    FamilyCollectionAddUnique mParentsByChild, childId, parentId
    FamilyCollectionAddUnique mChildrenByParent, parentId, childId

    If Len(childKind) = 0 Then childKind = CHILD_KIND_UNKNOWN
    If Len(confidenceText) = 0 Then confidenceText = FACT_REVIEW
    If Not mChildKindByChild.Exists(childId) Then
        mChildKindByChild.Add childId, childKind
        mChildConfidenceByChild.Add childId, confidenceText
        mChildEvidenceByChild.Add childId, evidenceText
    Else
        If childKind = CHILD_KIND_COUPLE Then mChildKindByChild(childId) = childKind
        If confidenceText = FACT_REVIEW Then mChildConfidenceByChild(childId) = confidenceText
        If Len(CleanText(mChildEvidenceByChild(childId))) = 0 And Len(evidenceText) > 0 Then mChildEvidenceByChild(childId) = evidenceText
    End If
    If Len(familyKey) > 0 Then
        If mChildFamilyKeyByChild.Exists(childId) Then
            mChildFamilyKeyByChild(childId) = familyKey
        Else
            mChildFamilyKeyByChild.Add childId, familyKey
        End If
    End If
End Sub

Private Sub FamilyCollectionAddUnique(ByVal dict As Object, ByVal keyText As String, ByVal valueText As String)
    Dim col As Collection, i As Long
    keyText = CleanText(keyText)
    valueText = CleanText(valueText)
    If Len(keyText) = 0 Or Len(valueText) = 0 Then Exit Sub
    If dict.Exists(keyText) Then
        Set col = dict(keyText)
    Else
        Set col = New Collection
        dict.Add keyText, col
    End If
    For i = 1 To col.Count
        If CleanText(CStr(col(i))) = valueText Then Exit Sub
    Next i
    col.Add valueText
End Sub

Private Sub FamilyChoosePreferredSpouses()
    Dim pid As Variant, spouses As Collection, i As Long, sid As String
    Dim bestId As String, bestScore As Double, scoreValue As Double
    If mSpousesByPerson Is Nothing Then Exit Sub
    For Each pid In mSpousesByPerson.Keys
        Set spouses = mSpousesByPerson(CStr(pid))
        bestScore = -1
        For i = 1 To spouses.Count
            sid = CleanText(CStr(spouses(i)))
            scoreValue = FamilySpouseScore(CStr(pid), sid, GetInheritanceDate())
            If scoreValue > bestScore Then
                bestScore = scoreValue
                bestId = sid
            End If
        Next i
        If Len(bestId) > 0 Then mPreferredSpouseByPerson(CStr(pid)) = bestId
    Next pid
End Sub

Private Function FamilySpouseScore(ByVal personId As String, ByVal spouseId As String, ByVal targetDate As Variant) As Double
    Dim pairKey As String, m As Variant, d As Variant, scoreValue As Double
    pairKey = FamilyModelPairKey(personId, spouseId)
    If mCoupleMarriage.Exists(pairKey) Then m = mCoupleMarriage(pairKey)
    If mCoupleDivorce.Exists(pairKey) Then d = mCoupleDivorce(pairKey)
    If HasInputDate(targetDate) And FamilyDateWithinPeriod(targetDate, m, d) Then scoreValue = scoreValue + 100000
    If Not HasInputDate(d) Then scoreValue = scoreValue + 50000
    If HasInputDate(m) Then scoreValue = scoreValue + CDbl(CDate(SameDateOrBlank(m)))
    FamilySpouseScore = scoreValue
End Function

Private Sub FamilyBuildLineage()
    Dim changed As Boolean, passNo As Long, maxPass As Long
    Dim childId As Variant, parents As Collection, i As Long, parentId As String
    Dim parentGen As Long, childGen As Long, currentGen As Long
    Dim pid As Variant, rawRel As String
    mGenerationByPerson(mDecedentId) = 0
    maxPass = mPersonRows.Count + 2

    For passNo = 1 To maxPass
        changed = False
        For Each childId In mParentsByChild.Keys
            Set parents = mParentsByChild(CStr(childId))
            For i = 1 To parents.Count
                parentId = CleanText(CStr(parents(i)))
                If mGenerationByPerson.Exists(parentId) Then
                    parentGen = CLng(mGenerationByPerson(parentId))
                    childGen = parentGen + 1
                    If Not mGenerationByPerson.Exists(CStr(childId)) Then
                        mGenerationByPerson.Add CStr(childId), childGen
                        mPrimaryParentByChild(CStr(childId)) = parentId
                        changed = True
                    Else
                        currentGen = CLng(mGenerationByPerson(CStr(childId)))
                        If childGen < currentGen Then
                            mGenerationByPerson(CStr(childId)) = childGen
                            mPrimaryParentByChild(CStr(childId)) = parentId
                            changed = True
                        End If
                    End If
                End If
            Next i
        Next childId
        If Not changed Then Exit For
    Next passNo

    '��n���̐e�����ݒ�ł��A�����e����l�Ȃ炻�̐l������̋N�_�ɂ���B
    For Each childId In mParentsByChild.Keys
        If Not mPrimaryParentByChild.Exists(CStr(childId)) Then
            Set parents = mParentsByChild(CStr(childId))
            If parents.Count > 0 Then mPrimaryParentByChild(CStr(childId)) = CleanText(CStr(parents(1)))
        End If
    Next childId

    For Each pid In mPersonRows.Keys
        If CStr(pid) <> mDecedentId Then
            If Not mGenerationByPerson.Exists(CStr(pid)) Then
                If Not FamilyIsParentOfDecedent(CStr(pid)) And mSpousesByPerson.Exists(CStr(pid)) Then
                    If FamilyHasLineageSpouse(CStr(pid)) Then mPureSpouse(CStr(pid)) = True
                End If
                rawRel = FamilyRawRelation(CStr(pid))
                If RelationshipDescendantLevel(rawRel) > 0 And Not mPureSpouse.Exists(CStr(pid)) Then
                    If FamilyModelChildKind(CStr(pid)) <> CHILD_KIND_STEP Then mUnresolved(CStr(pid)) = True
                End If
            End If
        End If
    Next pid
End Sub

Private Function FamilyHasLineageSpouse(ByVal personId As String) As Boolean
    Dim col As Collection, i As Long, sid As String
    If Not mSpousesByPerson.Exists(personId) Then Exit Function
    Set col = mSpousesByPerson(personId)
    For i = 1 To col.Count
        sid = CleanText(CStr(col(i)))
        If mGenerationByPerson.Exists(sid) Then
            FamilyHasLineageSpouse = True
            Exit Function
        End If
        If FamilyIsParentOfDecedent(sid) Then
            FamilyHasLineageSpouse = True
            Exit Function
        End If
    Next i
End Function

Private Sub FamilyBuildDisplayRelations()
    Dim pid As Variant, generationNo As Long, rawRel As String, labelText As String
    Dim anchorId As String, anchorLabel As String, genderText As String
    For Each pid In mPersonRows.Keys
        labelText = vbNullString
        rawRel = FamilyRawRelation(CStr(pid))
        If CStr(pid) = mDecedentId Then
            labelText = MODE_DECEDENT
        ElseIf mGenerationByPerson.Exists(CStr(pid)) Then
            generationNo = CLng(mGenerationByPerson(CStr(pid)))
            If generationNo = 1 Then
                labelText = RelationshipCanonicalStoredLabel(rawRel)
                If RelationshipDescendantLevel(labelText) <> 1 Then labelText = "�q"
            ElseIf generationNo > 1 Then
                labelText = RelationshipDescendantLabel(generationNo)
            End If
        ElseIf FamilyIsParentOfDecedent(CStr(pid)) Then
            genderText = FamilyPersonValue(CStr(pid), P_GENDER)
            If genderText = "�j" Then
                labelText = "��"
            ElseIf genderText = "��" Then
                labelText = "��"
            Else
                labelText = RelationshipCanonicalStoredLabel(rawRel)
            End If
        ElseIf Not mPureSpouse.Exists(CStr(pid)) Then
            labelText = RelationshipCanonicalStoredLabel(rawRel)
        End If
        If Len(labelText) = 0 Then labelText = CleanText(rawRel)
        mDisplayRelationByPerson(CStr(pid)) = labelText
    Next pid

    '�z��ҕ\���͎�n�����̑�������ɍŌ�ɍ��B
    For Each pid In mPureSpouse.Keys
        anchorId = FamilyLineageSpouseId(CStr(pid))
        anchorLabel = vbNullString
        If Len(anchorId) > 0 Then
            If mDisplayRelationByPerson.Exists(anchorId) Then anchorLabel = CleanText(mDisplayRelationByPerson(anchorId))
        End If
        Select Case anchorLabel
            Case MODE_DECEDENT
                If FamilyPairIsDivorced(CStr(pid), anchorId) Then
                    labelText = "�O�z���"
                Else
                    labelText = "�z���"
                End If
            Case "��": labelText = "��"
            Case "��": labelText = "��"
            Case "": labelText = "�z���"
            Case Else: labelText = anchorLabel & "�̔z���"
        End Select
        mDisplayRelationByPerson(CStr(pid)) = labelText
    Next pid
End Sub

Private Function FamilyLineageSpouseId(ByVal personId As String) As String
    Dim col As Collection, i As Long, sid As String, bestId As String
    If Not mSpousesByPerson.Exists(personId) Then Exit Function
    Set col = mSpousesByPerson(personId)
    For i = 1 To col.Count
        sid = CleanText(CStr(col(i)))
        If mGenerationByPerson.Exists(sid) Or FamilyIsParentOfDecedent(sid) Then
            If Len(bestId) = 0 Then bestId = sid
            If mPreferredSpouseByPerson.Exists(personId) Then
                If CleanText(mPreferredSpouseByPerson(personId)) = sid Then
                    FamilyLineageSpouseId = sid
                    Exit Function
                End If
            End If
        End If
    Next i
    FamilyLineageSpouseId = bestId
End Function

Private Function FamilyIsParentOfDecedent(ByVal personId As String) As Boolean
    Dim col As Collection, i As Long
    personId = CleanText(personId)
    If Len(personId) = 0 Then Exit Function
    If Not mParentsByChild.Exists(mDecedentId) Then Exit Function
    Set col = mParentsByChild(mDecedentId)
    For i = 1 To col.Count
        If CleanText(CStr(col(i))) = personId Then
            FamilyIsParentOfDecedent = True
            Exit Function
        End If
    Next i
End Function

Private Function FamilyPairIsDivorced(ByVal leftId As String, ByVal rightId As String) As Boolean
    Dim pairKey As String
    pairKey = FamilyModelPairKey(leftId, rightId)
    If mCoupleDivorce.Exists(pairKey) Then FamilyPairIsDivorced = HasInputDate(mCoupleDivorce(pairKey))
End Function

Private Sub FamilyValidateFacts()
    Dim childId As Variant, confidenceText As String, kindText As String, pid As Variant
    Dim parents As Collection, familyKey As String
    For Each childId In mParentsByChild.Keys
        Set parents = mParentsByChild(CStr(childId))
        kindText = FamilyModelChildKind(CStr(childId))
        confidenceText = FamilyModelChildConfidence(CStr(childId))
        familyKey = FamilyModelChildFamilyKey(CStr(childId))
        If kindText = CHILD_KIND_COUPLE Then
            If parents.Count < 2 Or Len(familyKey) = 0 Then
                FamilyAddWarning "�v�w�q�s��:" & CStr(childId), FamilyPersonName(CStr(childId)) & " �͕v�w�̎q�ł����A���eID�܂��͉Ƒ��L�[���s�����Ă��܂��B"
                mChildConfidenceByChild(CStr(childId)) = FACT_REVIEW
            End If
        End If
        If confidenceText = FACT_REVIEW Then
            FamilyAddWarning "�e�q�v�m�F:" & CStr(childId), FamilyPersonName(CStr(childId)) & " �̐e�q�敪�͗v�m�F�ł��B"
        End If
    Next childId
    For Each pid In mSpousesByPerson.Keys
        If FamilyModelSpouseCount(CStr(pid)) > 1 Then
            FamilyAddWarning "�����z���:" & CStr(pid), FamilyPersonName(CStr(pid)) & " �ɕ����̔z��Ҏ���������܂��B��\�z��҂͍������Ԃ���I�сA���̑��͗����Ƃ��ĕێ����܂��B"
        End If
    Next pid
End Sub

Public Function FamilyModelPersonRow(ByVal personId As String) As Long
    personId = CleanText(personId)
    If Not mPersonRows Is Nothing Then
        If mPersonRows.Exists(personId) Then FamilyModelPersonRow = CLng(mPersonRows(personId))
    End If
End Function

Public Function FamilyModelParentId(ByVal childId As String) As String
    childId = CleanText(childId)
    If Not mPrimaryParentByChild Is Nothing Then
        If mPrimaryParentByChild.Exists(childId) Then FamilyModelParentId = CleanText(mPrimaryParentByChild(childId))
    End If
End Function

Public Function FamilyModelParentIds(ByVal childId As String) As Collection
    Dim result As New Collection, src As Collection, i As Long
    childId = CleanText(childId)
    If Not mParentsByChild Is Nothing Then
        If mParentsByChild.Exists(childId) Then
            Set src = mParentsByChild(childId)
            For i = 1 To src.Count
                result.Add CStr(src(i))
            Next i
        End If
    End If
    Set FamilyModelParentIds = result
End Function

Public Function FamilyModelChildIds(ByVal parentId As String) As Collection
    Dim result As New Collection, src As Collection, i As Long
    parentId = CleanText(parentId)
    If Not mChildrenByParent Is Nothing Then
        If mChildrenByParent.Exists(parentId) Then
            Set src = mChildrenByParent(parentId)
            For i = 1 To src.Count
                result.Add CStr(src(i))
            Next i
        End If
    End If
    Set FamilyModelChildIds = result
End Function

Public Function FamilyModelSpouseIds(ByVal personId As String) As Collection
    Dim result As New Collection, src As Collection, i As Long
    personId = CleanText(personId)
    If Not mSpousesByPerson Is Nothing Then
        If mSpousesByPerson.Exists(personId) Then
            Set src = mSpousesByPerson(personId)
            For i = 1 To src.Count
                result.Add CStr(src(i))
            Next i
        End If
    End If
    Set FamilyModelSpouseIds = result
End Function

Public Function FamilyModelPreferredSpouseId(ByVal personId As String) As String
    personId = CleanText(personId)
    If Not mPreferredSpouseByPerson Is Nothing Then
        If mPreferredSpouseByPerson.Exists(personId) Then FamilyModelPreferredSpouseId = CleanText(mPreferredSpouseByPerson(personId))
    End If
End Function

Public Function FamilyModelSpouseCount(ByVal personId As String) As Long
    Dim col As Collection
    Set col = FamilyModelSpouseIds(personId)
    FamilyModelSpouseCount = col.Count
End Function

Public Function FamilyModelDisplayRelation(ByVal personId As String, Optional ByVal fallbackText As String = "") As String
    personId = CleanText(personId)
    If Not mDisplayRelationByPerson Is Nothing Then
        If mDisplayRelationByPerson.Exists(personId) Then
            FamilyModelDisplayRelation = CleanText(mDisplayRelationByPerson(personId))
            Exit Function
        End If
    End If
    FamilyModelDisplayRelation = RelationshipCanonicalStoredLabel(fallbackText)
End Function

Public Function FamilyModelIsPureSpouse(ByVal personId As String) As Boolean
    personId = CleanText(personId)
    If Not mPureSpouse Is Nothing Then FamilyModelIsPureSpouse = mPureSpouse.Exists(personId)
End Function

Public Function FamilyModelIsUnresolved(ByVal personId As String) As Boolean
    personId = CleanText(personId)
    If Not mUnresolved Is Nothing Then FamilyModelIsUnresolved = mUnresolved.Exists(personId)
End Function

Public Function FamilyModelChildKind(ByVal childId As String) As String
    childId = CleanText(childId)
    If Not mChildKindByChild Is Nothing Then
        If mChildKindByChild.Exists(childId) Then FamilyModelChildKind = CleanText(mChildKindByChild(childId))
    End If
End Function

Public Function FamilyModelChildConfidence(ByVal childId As String) As String
    childId = CleanText(childId)
    If Not mChildConfidenceByChild Is Nothing Then
        If mChildConfidenceByChild.Exists(childId) Then FamilyModelChildConfidence = CleanText(mChildConfidenceByChild(childId))
    End If
End Function

Public Function FamilyModelChildEvidence(ByVal childId As String) As String
    childId = CleanText(childId)
    If Not mChildEvidenceByChild Is Nothing Then
        If mChildEvidenceByChild.Exists(childId) Then FamilyModelChildEvidence = CleanText(mChildEvidenceByChild(childId))
    End If
End Function

Public Function FamilyModelChildFamilyKey(ByVal childId As String) As String
    childId = CleanText(childId)
    If Not mChildFamilyKeyByChild Is Nothing Then
        If mChildFamilyKeyByChild.Exists(childId) Then FamilyModelChildFamilyKey = CleanText(mChildFamilyKeyByChild(childId))
    End If
End Function

Public Function FamilyModelChildUsesCouple(ByVal childId As String, ByVal parentId As String, ByVal spouseId As String) As Boolean
    Dim storedKey As String
    storedKey = FamilyModelChildFamilyKey(childId)
    If Len(storedKey) = 0 Then Exit Function
    If FamilyModelChildKind(childId) <> CHILD_KIND_COUPLE Then Exit Function
    FamilyModelChildUsesCouple = (storedKey = FamilyModelPairKey(parentId, spouseId))
End Function

Public Function FamilyModelChildNeedsReview(ByVal childId As String) As Boolean
    FamilyModelChildNeedsReview = (FamilyModelChildConfidence(childId) = FACT_REVIEW Or FamilyModelChildKind(childId) = CHILD_KIND_UNKNOWN)
End Function

Public Function FamilyModelChildReviewReason(ByVal childId As String) As String
    If FamilyModelChildNeedsReview(childId) Then FamilyModelChildReviewReason = FamilyModelChildEvidence(childId)
End Function

Public Function FamilyModelFatherRow(ByVal decedentId As String) As Long
    FamilyModelFatherRow = FamilyParentRowByGender(decedentId, "�j", "��")
End Function

Public Function FamilyModelMotherRow(ByVal decedentId As String) As Long
    FamilyModelMotherRow = FamilyParentRowByGender(decedentId, "��", "��")
End Function

Private Function FamilyParentRowByGender(ByVal decedentId As String, ByVal genderText As String, ByVal relationText As String) As Long
    Dim parents As Collection, i As Long, pid As String
    Set parents = FamilyModelParentIds(decedentId)
    For i = 1 To parents.Count
        pid = CleanText(CStr(parents(i)))
        If FamilyPersonValue(pid, P_GENDER) = genderText Then
            FamilyParentRowByGender = FamilyModelPersonRow(pid)
            Exit Function
        End If
    Next i
    For i = 1 To parents.Count
        pid = CleanText(CStr(parents(i)))
        If FamilyModelDisplayRelation(pid, FamilyRawRelation(pid)) = relationText Then
            FamilyParentRowByGender = FamilyModelPersonRow(pid)
            Exit Function
        End If
    Next i
End Function

Public Function FamilyModelIsSpouseRelationType(ByVal relationType As String) As Boolean
    relationType = CleanText(relationType)
    Select Case relationType
        Case "�z���", "�O�z���", "�v�w", "�v", "��"
            FamilyModelIsSpouseRelationType = True
        Case Else
            FamilyModelIsSpouseRelationType = (InStr(1, relationType, "�z���", vbTextCompare) > 0)
    End Select
End Function

Public Function FamilyModelIsParentChildType(ByVal relationType As String) As Boolean
    relationType = CleanText(relationType)
    If FamilyModelIsSpouseRelationType(relationType) Then Exit Function
    Select Case relationType
        Case "�e�q", "�e�q�֌W", "���e�q", "�{�e�q", "����", "�e", "�q", "��", "��", "�{�q"
            FamilyModelIsParentChildType = True
    End Select
End Function

Public Function FamilyModelIsParentChildRow(ByVal ws As Worksheet, ByVal rowNo As Long) As Boolean
    If ws Is Nothing Or rowNo <= 0 Then Exit Function
    FamilyModelIsParentChildRow = FamilyModelIsParentChildType(CleanText(ws.Cells(rowNo, R_TYPE).Value))
End Function

Public Function FamilyModelPairKey(ByVal leftId As String, ByVal rightId As String) As String
    leftId = CleanText(leftId)
    rightId = CleanText(rightId)
    If Len(leftId) = 0 Or Len(rightId) = 0 Or leftId = rightId Then Exit Function
    If StrComp(leftId, rightId, vbTextCompare) <= 0 Then
        FamilyModelPairKey = "F|" & leftId & "|" & rightId
    Else
        FamilyModelPairKey = "F|" & rightId & "|" & leftId
    End If
End Function

Public Function FamilyModelResolveChildFactForInput(ByVal baseId As String, _
        ByVal birthDate As Variant, ByVal inputChoice As String, _
        ByRef firstParentId As String, ByRef secondParentId As String, _
        ByRef childKind As String, ByRef confidenceText As String, _
        ByRef evidenceText As String, ByRef familyKey As String) As Boolean
    Dim spouseId As String, spouseState As String
    baseId = CleanText(baseId)
    inputChoice = CleanText(inputChoice)
    firstParentId = baseId
    secondParentId = vbNullString
    familyKey = vbNullString
    If Len(baseId) = 0 Then Exit Function
    If Len(inputChoice) = 0 Then inputChoice = CHILD_INPUT_AUTO
    If Not FamilyModelEnsureBuilt(GetDecedentId()) Then Exit Function

    If inputChoice = CHILD_KIND_STEP Then
        spouseId = FamilyModelPreferredSpouseId(baseId)
        If Len(spouseId) > 0 Then spouseState = "��\�z���" Else spouseState = "�z��Җ��o�^"
    ElseIf inputChoice = CHILD_KIND_PREVIOUS Then
        spouseId = FamilyResolvePreviousSpouseForChild(baseId, birthDate, spouseState)
    Else
        spouseId = FamilyResolveSpouseForChild(baseId, birthDate, spouseState)
    End If
    Select Case inputChoice
        Case CHILD_KIND_BASE_ONLY
            childKind = CHILD_KIND_BASE_ONLY
            confidenceText = FACT_CONFIRMED
            evidenceText = "���͎҂���l���݂̂̎q���w��"
        Case CHILD_KIND_PREVIOUS
            childKind = CHILD_KIND_PREVIOUS
            confidenceText = FACT_CONFIRMED
            If Len(spouseId) > 0 Then
                secondParentId = spouseId
                familyKey = FamilyModelPairKey(baseId, spouseId)
                evidenceText = "���͎҂��O�z��҂Ƃ̎q���w��B�������Ԃ��瑊��l����R�t��"
            Else
                evidenceText = "���͎҂��O�z��҂Ƃ̎q���w��B�O�z��Ґl��ID�͖��m��"
            End If
        Case CHILD_KIND_STEP
            If Len(spouseId) > 0 Then
                firstParentId = spouseId
                childKind = CHILD_KIND_STEP
                confidenceText = FACT_CONFIRMED
                evidenceText = "���͎҂��z��҂̘A��q���w��"
            Else
                childKind = CHILD_KIND_UNKNOWN
                confidenceText = FACT_REVIEW
                evidenceText = "�A��q�̐e�ƂȂ�z��҂���l�ɓ���ł��܂���: " & spouseState
            End If
        Case CHILD_KIND_COUPLE
            If Len(spouseId) > 0 Then
                secondParentId = spouseId
                childKind = CHILD_KIND_COUPLE
                confidenceText = FACT_CONFIRMED
                familyKey = FamilyModelPairKey(baseId, spouseId)
                evidenceText = "���͎҂��v�w�̎q���w��"
            Else
                childKind = CHILD_KIND_UNKNOWN
                confidenceText = FACT_REVIEW
                evidenceText = "�v�w�̑������l�ɓ���ł��܂���: " & spouseState
            End If
        Case Else
            If Len(spouseId) > 0 And spouseState <> "�������ԊO" Then
                secondParentId = spouseId
                If FamilyPairHasDivorce(baseId, spouseId) _
                        And FamilyModelPreferredSpouseId(baseId) <> spouseId Then
                    childKind = CHILD_KIND_PREVIOUS
                Else
                    childKind = CHILD_KIND_COUPLE
                End If
                confidenceText = FACT_INFERRED
                familyKey = FamilyModelPairKey(baseId, spouseId)
                If spouseState = "�������ԓ�" Then
                    If childKind = CHILD_KIND_PREVIOUS Then
                        evidenceText = "���N�������O�z��҂Ƃ̍������ԓ��̂��߁A�O�z��҂Ƃ̎q�Ɛ���"
                    Else
                        evidenceText = "���N�������������ԓ��̂��ߕv�w�̎q�Ɛ���"
                    End If
                Else
                    evidenceText = "�z��҂���l�Ŕ��Ύw�肪�Ȃ����ߕv�w�̎q�Ɛ���i" & spouseState & "�j"
                End If
            Else
                childKind = CHILD_KIND_UNKNOWN
                confidenceText = FACT_REVIEW
                If Len(spouseState) = 0 Then spouseState = "�z��Җ��o�^"
                evidenceText = "�v�w�̎q�������m��ł��܂���: " & spouseState
            End If
    End Select
    FamilyModelResolveChildFactForInput = True
End Function

Private Function FamilyResolvePreviousSpouseForChild(ByVal baseId As String, ByVal birthDate As Variant, ByRef stateText As String) As String
    Dim spouses As Collection, i As Long, sid As String, candidateId As String
    Dim candidateCount As Long, periodState As String, divorcedCount As Long, soleDivorcedId As String
    Set spouses = FamilyModelSpouseIds(baseId)
    For i = 1 To spouses.Count
        sid = CleanText(CStr(spouses(i)))
        If FamilyPairHasDivorce(baseId, sid) Then
            divorcedCount = divorcedCount + 1
            soleDivorcedId = sid
            periodState = FamilyPairDateState(baseId, sid, birthDate)
            If periodState = "�������ԓ�" Then
                candidateCount = candidateCount + 1
                candidateId = sid
            End If
        End If
    Next i
    If candidateCount = 1 Then
        stateText = "�O�z��҂̍������ԓ�"
        FamilyResolvePreviousSpouseForChild = candidateId
    ElseIf candidateCount > 1 Then
        stateText = "�Y������O�z��҂�����"
    ElseIf divorcedCount = 1 Then
        stateText = "�O�z��҂���l"
        FamilyResolvePreviousSpouseForChild = soleDivorcedId
    ElseIf divorcedCount = 0 Then
        stateText = "�O�z��Җ��o�^"
    Else
        stateText = "�O�z��҂���l�ɓ���ł��Ȃ�"
    End If
End Function

Private Function FamilyPairHasDivorce(ByVal leftId As String, ByVal rightId As String) As Boolean
    Dim mh As Worksheet, r As Long, pid As String, cpId As String, pairKey As String
    If SheetExists(SH_W_MARRIAGE_HIST, ThisWorkbook) Then
        Set mh = ThisWorkbook.Worksheets(SH_W_MARRIAGE_HIST)
        For r = 2 To LastRow(mh, MH_ID)
            If CleanText(mh.Cells(r, MH_STATUS).Value) <> STATUS_CANCEL Then
                pid = CleanText(mh.Cells(r, MH_PERSON_ID).Value)
                cpId = CleanText(mh.Cells(r, MH_COUNTERPART_ID).Value)
                If (pid = leftId And cpId = rightId) Or (pid = rightId And cpId = leftId) Then
                    If HasInputDate(mh.Cells(r, MH_DIVORCE).Value) Then FamilyPairHasDivorce = True: Exit Function
                End If
            End If
        Next r
    End If
    pairKey = FamilyModelPairKey(leftId, rightId)
    If mCoupleDivorce.Exists(pairKey) Then FamilyPairHasDivorce = HasInputDate(mCoupleDivorce(pairKey))
End Function

Private Function FamilyResolveSpouseForChild(ByVal baseId As String, ByVal birthDate As Variant, ByRef stateText As String) As String
    Dim spouses As Collection, i As Long, sid As String, periodState As String
    Dim withinCount As Long, unknownCount As Long
    Dim withinId As String, unknownId As String, knownOutsideCount As Long
    Set spouses = FamilyModelSpouseIds(baseId)
    If spouses.Count = 0 Then
        stateText = "�z��Җ��o�^"
        Exit Function
    End If
    For i = 1 To spouses.Count
        sid = CleanText(CStr(spouses(i)))
        periodState = FamilyPairDateState(baseId, sid, birthDate)
        Select Case periodState
            Case "�������ԓ�"
                withinCount = withinCount + 1
                withinId = sid
            Case "�������ԊO"
                knownOutsideCount = knownOutsideCount + 1
            Case Else
                unknownCount = unknownCount + 1
                unknownId = sid
        End Select
    Next i
    If withinCount = 1 Then
        stateText = "�������ԓ�"
        FamilyResolveSpouseForChild = withinId
    ElseIf withinCount > 1 Then
        stateText = "�������Ԃ��d�Ȃ�z��҂�����"
    ElseIf unknownCount = 1 And knownOutsideCount = 0 Then
        stateText = "���N�����܂��͍������Ԗ�����"
        FamilyResolveSpouseForChild = unknownId
    ElseIf spouses.Count = 1 And knownOutsideCount = 1 Then
        stateText = "�������ԊO"
        FamilyResolveSpouseForChild = CleanText(CStr(spouses(1)))
    ElseIf unknownCount = 1 And knownOutsideCount > 0 Then
        stateText = "���ԕs���̔z��҂���l"
        FamilyResolveSpouseForChild = unknownId
    Else
        stateText = "�z��҂���l�ɓ���ł��Ȃ�"
    End If
End Function

Private Function FamilyPairDateState(ByVal leftId As String, ByVal rightId As String, ByVal targetDate As Variant) As String
    Dim mh As Worksheet, r As Long, pid As String, cpId As String
    Dim m As Variant, d As Variant, hasRecord As Boolean, hasUnknown As Boolean, hasOutside As Boolean
    Dim pairKey As String
    If Not HasInputDate(targetDate) Then
        FamilyPairDateState = "���N����������"
        Exit Function
    End If
    If SheetExists(SH_W_MARRIAGE_HIST, ThisWorkbook) Then
        Set mh = ThisWorkbook.Worksheets(SH_W_MARRIAGE_HIST)
        For r = 2 To LastRow(mh, MH_ID)
            If CleanText(mh.Cells(r, MH_STATUS).Value) <> STATUS_CANCEL _
                    And CleanText(mh.Cells(r, MH_SHOW).Value) <> SHOW_NO Then
                pid = CleanText(mh.Cells(r, MH_PERSON_ID).Value)
                cpId = CleanText(mh.Cells(r, MH_COUNTERPART_ID).Value)
                If (pid = leftId And cpId = rightId) Or (pid = rightId And cpId = leftId) Then
                    hasRecord = True
                    m = mh.Cells(r, MH_MARRIAGE).Value
                    d = mh.Cells(r, MH_DIVORCE).Value
                    If HasInputDate(m) Then
                        If FamilyDateWithinPeriod(targetDate, m, d) Then
                            FamilyPairDateState = "�������ԓ�"
                            Exit Function
                        Else
                            hasOutside = True
                        End If
                    Else
                        hasUnknown = True
                    End If
                End If
            End If
        Next r
    End If
    If hasRecord Then
        If hasUnknown Then
            FamilyPairDateState = "�������Ԗ�����"
        ElseIf hasOutside Then
            FamilyPairDateState = "�������ԊO"
        End If
        Exit Function
    End If

    pairKey = FamilyModelPairKey(leftId, rightId)
    m = Empty: d = Empty
    If mCoupleMarriage.Exists(pairKey) Then m = mCoupleMarriage(pairKey)
    If mCoupleDivorce.Exists(pairKey) Then d = mCoupleDivorce(pairKey)
    If HasInputDate(m) Then
        If FamilyDateWithinPeriod(targetDate, m, d) Then
            FamilyPairDateState = "�������ԓ�"
        Else
            FamilyPairDateState = "�������ԊO"
        End If
    Else
        FamilyPairDateState = "�������Ԗ�����"
    End If
End Function

Private Function FamilyDateWithinPeriod(ByVal targetDate As Variant, ByVal startDate As Variant, ByVal endDate As Variant) As Boolean
    Dim t As Date
    If Not HasInputDate(targetDate) Then Exit Function
    t = CDate(SameDateOrBlank(targetDate))
    If HasInputDate(startDate) Then
        If t < CDate(SameDateOrBlank(startDate)) Then Exit Function
    End If
    If HasInputDate(endDate) Then
        If t > CDate(SameDateOrBlank(endDate)) Then Exit Function
    End If
    FamilyDateWithinPeriod = True
End Function

Public Sub MigrateLegacyFamilyFacts()
    '���f�[�^��������x�AV2�̐e���q�E�v�w�q�敪�ֈڂ��B�ʏ�̒��[�쐬�ł͎��s���Ȃ��B
    On Error GoTo EH
    Dim ws As Worksheet, r As Long, lastR As Long, relType As String
    Dim leftId As String, rightId As String, parentId As String, childId As String
    Dim certainty As String, legacyChildren As Object, childKey As Variant
    Dim rowsForChild As Collection, firstRow As Long, firstParent As String, secondParent As String
    Dim kindText As String, confText As String, evidenceText As String, familyKey As String
    Dim birthValue As Variant, personRow As Long
    If Not SheetExists(SH_W_REL, ThisWorkbook) Then Exit Sub
    Set ws = ThisWorkbook.Worksheets(SH_W_REL)
    Set legacyChildren = CreateObject("Scripting.Dictionary")
    lastR = LastRow(ws, R_ID)

    For r = 2 To lastR
        If CleanText(ws.Cells(r, R_STATUS).Value) <> STATUS_CANCEL Then
            relType = CleanText(ws.Cells(r, R_TYPE).Value)
            If FamilyModelIsSpouseRelationType(relType) Then
                If Len(CleanText(ws.Cells(r, R_FACT_VERSION).Value)) = 0 Then ws.Cells(r, R_FACT_VERSION).Value = "V2-MIGRATED"
            ElseIf FamilyModelIsParentChildType(relType) Then
                leftId = CleanText(ws.Cells(r, R_BASE_ID).Value)
                rightId = CleanText(ws.Cells(r, R_OTHER_ID).Value)
                certainty = FACT_INFERRED
                FamilyResolveLegacyDirection leftId, rightId, parentId, childId, certainty
                If Len(parentId) > 0 And Len(childId) > 0 Then
                    ws.Cells(r, R_BASE_ID).Value = parentId
                    ws.Cells(r, R_OTHER_ID).Value = childId
                    ws.Cells(r, R_TYPE).Value = "�e�q"
                    If Len(CleanText(ws.Cells(r, R_CHILD_KIND).Value)) = 0 Then ws.Cells(r, R_CHILD_KIND).Value = CHILD_KIND_BASE_ONLY
                    If Len(CleanText(ws.Cells(r, R_CONFIDENCE).Value)) = 0 Then ws.Cells(r, R_CONFIDENCE).Value = certainty
                    If Len(CleanText(ws.Cells(r, R_EVIDENCE).Value)) = 0 Then ws.Cells(r, R_EVIDENCE).Value = "���f�[�^�֌W�s��e���q�ֈڍs"
                    If Len(CleanText(ws.Cells(r, R_FACT_VERSION).Value)) = 0 Then
                        ws.Cells(r, R_FACT_VERSION).Value = "V2-MIGRATED"
                        legacyChildren(childId) = True
                    End If
                    ws.Cells(r, R_UPDATED).Value = Now
                End If
            ElseIf Len(CleanText(ws.Cells(r, R_FACT_VERSION).Value)) = 0 Then
                ws.Cells(r, R_FACT_VERSION).Value = "V2-MIGRATED"
            End If
        End If
    Next r

    Call FamilyModelRebuild(GetDecedentId(), False)
    For Each childKey In legacyChildren.Keys
        Set rowsForChild = FamilyRelationRowsForChild(ws, CStr(childKey))
        If rowsForChild.Count = 1 Then
            firstRow = CLng(rowsForChild(1))
            If Not FamilyLegacySeparateParentText(CleanText(ws.Cells(firstRow, R_DISPLAY).Value) & " " & CleanText(ws.Cells(firstRow, R_NOTE).Value)) Then
                firstParent = CleanText(ws.Cells(firstRow, R_BASE_ID).Value)
                personRow = FindPersonRow(CStr(childKey))
                birthValue = Empty
                If personRow > 0 Then birthValue = ThisWorkbook.Worksheets(SH_W_PERSON).Cells(personRow, P_BIRTH).Value
                If FamilyModelResolveChildFactForInput(firstParent, birthValue, CHILD_INPUT_AUTO, parentId, secondParent, kindText, confText, evidenceText, familyKey) Then
                    If (kindText = CHILD_KIND_COUPLE Or kindText = CHILD_KIND_PREVIOUS) And Len(secondParent) > 0 Then
                        FamilyWriteParentFactMetadata ws, firstRow, kindText, FACT_INFERRED, "���f�[�^: " & evidenceText, familyKey, "V2-MIGRATED"
                        FamilyUpsertMigratedParentFact ws, secondParent, CStr(childKey), CleanText(ws.Cells(firstRow, R_DISPLAY).Value), kindText, familyKey, evidenceText
                    ElseIf confText = FACT_REVIEW Then
                        FamilyWriteParentFactMetadata ws, firstRow, CHILD_KIND_UNKNOWN, FACT_REVIEW, evidenceText, vbNullString, "V2-MIGRATED"
                    End If
                End If
            End If
        ElseIf rowsForChild.Count >= 2 Then
            FamilyMarkExistingCoupleParents ws, CStr(childKey), rowsForChild
        End If
    Next childKey
    FamilyModelInvalidate
    Exit Sub
EH:
    RuntimeAppendLog "WARN", "MigrateLegacyFamilyFacts", "�Ƒ�����V2�ڍs", "���f�[�^�͕ύX�ł����s�܂ŕێ����܂����B", Err.Number, Err.Description, Err.Source
    FamilyModelInvalidate
End Sub

Private Sub FamilyResolveLegacyDirection(ByVal leftId As String, ByVal rightId As String, _
        ByRef parentId As String, ByRef childId As String, ByRef certainty As String)
    Dim leftRel As String, rightRel As String, leftLevel As Long, rightLevel As Long
    Dim leftSource As String, rightSource As String
    parentId = leftId
    childId = rightId
    certainty = FACT_INFERRED
    If Len(leftId) = 0 Or Len(rightId) = 0 Then parentId = vbNullString: childId = vbNullString: Exit Sub
    leftSource = FamilyPersonValue(leftId, P_SUR_SRC)
    rightSource = FamilyPersonValue(rightId, P_SUR_SRC)
    If rightSource = leftId Then Exit Sub
    If leftSource = rightId Then parentId = rightId: childId = leftId: Exit Sub
    leftRel = RelationshipCanonicalStoredLabel(FamilyRawRelation(leftId))
    rightRel = RelationshipCanonicalStoredLabel(FamilyRawRelation(rightId))
    If (leftRel = "��" Or leftRel = "��") And rightId = GetDecedentId() Then Exit Sub
    If (rightRel = "��" Or rightRel = "��") And leftId = GetDecedentId() Then parentId = rightId: childId = leftId: Exit Sub
    If leftId = GetDecedentId() And RelationshipDescendantLevel(rightRel) = 1 Then Exit Sub
    If rightId = GetDecedentId() And RelationshipDescendantLevel(leftRel) = 1 Then parentId = rightId: childId = leftId: Exit Sub
    leftLevel = RelationshipDescendantLevel(leftRel)
    rightLevel = RelationshipDescendantLevel(rightRel)
    If rightLevel = leftLevel + 1 And rightLevel > 0 Then Exit Sub
    If leftLevel = rightLevel + 1 And leftLevel > 0 Then parentId = rightId: childId = leftId: Exit Sub
    certainty = FACT_REVIEW
End Sub

Private Function FamilyRelationRowsForChild(ByVal ws As Worksheet, ByVal childId As String) As Collection
    Dim result As New Collection, r As Long
    For r = 2 To LastRow(ws, R_ID)
        If CleanText(ws.Cells(r, R_STATUS).Value) <> STATUS_CANCEL _
                And FamilyModelIsParentChildType(CleanText(ws.Cells(r, R_TYPE).Value)) _
                And CleanText(ws.Cells(r, R_OTHER_ID).Value) = childId Then result.Add r
    Next r
    Set FamilyRelationRowsForChild = result
End Function

Private Sub FamilyMarkExistingCoupleParents(ByVal ws As Worksheet, ByVal childId As String, ByVal rowsForChild As Collection)
    Dim i As Long, j As Long, leftParent As String, rightParent As String, pairKey As String
    For i = 1 To rowsForChild.Count - 1
        leftParent = CleanText(ws.Cells(CLng(rowsForChild(i)), R_BASE_ID).Value)
        For j = i + 1 To rowsForChild.Count
            rightParent = CleanText(ws.Cells(CLng(rowsForChild(j)), R_BASE_ID).Value)
            If FamilyPersonsAreSpouses(leftParent, rightParent) Then
                pairKey = FamilyModelPairKey(leftParent, rightParent)
                FamilyWriteParentFactMetadata ws, CLng(rowsForChild(i)), CHILD_KIND_COUPLE, FACT_INFERRED, "���f�[�^: ���eID�Ɣz��Ҋ֌W����v�w�̎q�ֈڍs", pairKey, "V2-MIGRATED"
                FamilyWriteParentFactMetadata ws, CLng(rowsForChild(j)), CHILD_KIND_COUPLE, FACT_INFERRED, "���f�[�^: ���eID�Ɣz��Ҋ֌W����v�w�̎q�ֈڍs", pairKey, "V2-MIGRATED"
                Exit Sub
            End If
        Next j
    Next i
End Sub

Private Function FamilyPersonsAreSpouses(ByVal leftId As String, ByVal rightId As String) As Boolean
    Dim spouses As Collection, i As Long
    Set spouses = FamilyModelSpouseIds(leftId)
    For i = 1 To spouses.Count
        If CleanText(CStr(spouses(i))) = CleanText(rightId) Then FamilyPersonsAreSpouses = True: Exit Function
    Next i
End Function

Private Sub FamilyUpsertMigratedParentFact(ByVal ws As Worksheet, ByVal parentId As String, ByVal childId As String, _
        ByVal displayText As String, ByVal childKind As String, ByVal familyKey As String, ByVal evidenceText As String)
    Dim r As Long
    r = FamilyFindParentFactRow(ws, parentId, childId)
    If r = 0 Then
        r = NextBlankRow(ws, R_ID)
        ws.Cells(r, R_ID).Value = NextId("�֌W")
        ws.Cells(r, R_CREATED).Value = Now
    End If
    ws.Cells(r, R_BASE_ID).Value = parentId
    ws.Cells(r, R_OTHER_ID).Value = childId
    ws.Cells(r, R_TYPE).Value = "�e�q"
    ws.Cells(r, R_DISPLAY).Value = displayText
    ws.Cells(r, R_AUTO).Value = "�ڍs"
    ws.Cells(r, R_STATUS).Value = STATUS_ACTIVE
    ws.Cells(r, R_UPDATED).Value = Now
    FamilyWriteParentFactMetadata ws, r, childKind, FACT_INFERRED, "���f�[�^: " & evidenceText, familyKey, "V2-MIGRATED"
End Sub

Private Function FamilyFindParentFactRow(ByVal ws As Worksheet, ByVal parentId As String, ByVal childId As String) As Long
    Dim r As Long
    For r = 2 To LastRow(ws, R_ID)
        If CleanText(ws.Cells(r, R_STATUS).Value) <> STATUS_CANCEL _
                And CleanText(ws.Cells(r, R_TYPE).Value) = "�e�q" _
                And CleanText(ws.Cells(r, R_BASE_ID).Value) = parentId _
                And CleanText(ws.Cells(r, R_OTHER_ID).Value) = childId Then
            FamilyFindParentFactRow = r
            Exit Function
        End If
    Next r
End Function

Private Sub FamilyWriteParentFactMetadata(ByVal ws As Worksheet, ByVal rowNo As Long, _
        ByVal kindText As String, ByVal confidenceText As String, ByVal evidenceText As String, _
        ByVal familyKey As String, ByVal versionText As String)
    ws.Cells(rowNo, R_CHILD_KIND).Value = kindText
    ws.Cells(rowNo, R_CONFIDENCE).Value = confidenceText
    ws.Cells(rowNo, R_EVIDENCE).Value = evidenceText
    ws.Cells(rowNo, R_FAMILY_KEY).Value = familyKey
    ws.Cells(rowNo, R_FACT_VERSION).Value = versionText
    ws.Cells(rowNo, R_UPDATED).Value = Now
End Sub

Private Function FamilyLegacySeparateParentText(ByVal textValue As String) As Boolean
    textValue = CleanText(textValue)
    FamilyLegacySeparateParentText = (InStr(textValue, "�A��q") > 0 _
        Or InStr(textValue, "�O�z���") > 0 Or InStr(textValue, "�O��") > 0 _
        Or InStr(textValue, "�O�v") > 0 Or InStr(textValue, "�ʕ�") > 0 Or InStr(textValue, "�ʕ�") > 0)
End Function

Private Function FamilyRawRelation(ByVal personId As String) As String
    Dim rowNo As Long, ws As Worksheet
    rowNo = 0
    If Not mPersonRows Is Nothing Then
        If mPersonRows.Exists(personId) Then rowNo = CLng(mPersonRows(personId))
    End If
    If rowNo = 0 Then rowNo = FindPersonRow(personId)
    If rowNo <= 0 Then Exit Function
    Set ws = ThisWorkbook.Worksheets(SH_W_PERSON)
    FamilyRawRelation = CleanText(ws.Cells(rowNo, P_REL_DEC).Value)
    If Len(FamilyRawRelation) = 0 Then FamilyRawRelation = CleanText(ws.Cells(rowNo, P_REL_DISP).Value)
End Function

Private Function FamilyPersonValue(ByVal personId As String, ByVal columnNo As Long) As String
    Dim rowNo As Long
    rowNo = FindPersonRow(personId)
    If rowNo > 0 Then FamilyPersonValue = CleanText(ThisWorkbook.Worksheets(SH_W_PERSON).Cells(rowNo, columnNo).Value)
End Function

Private Function FamilyPersonName(ByVal personId As String) As String
    FamilyPersonName = FamilyPersonValue(personId, P_DISPLAY)
    If Len(FamilyPersonName) = 0 Then FamilyPersonName = personId
End Function

Private Sub FamilyAddWarning(ByVal warningKey As String, ByVal warningText As String)
    warningKey = CleanText(warningKey)
    If Len(warningKey) = 0 Then warningKey = CStr(mWarnings.Count + 1)
    If mWarnings Is Nothing Then Set mWarnings = CreateObject("Scripting.Dictionary")
    If mWarnings.Exists(warningKey) Then
        mWarnings(warningKey) = warningText
    Else
        mWarnings.Add warningKey, warningText
    End If
End Sub

Public Function FamilyModelWarningItems() As Object
    Set FamilyModelWarningItems = mWarnings
End Function

Attribute VB_Name = "modMarriageHistory"
Option Explicit

Private mLegacyFactsBackfilled As Boolean

'�����E�����͐l���\/�֌W�\�̕������ł͂Ȃ��A�����𐳂Ƃ���B
'���Ō݊��̂��ߐl���\�E�֌W�\�̓��t�͓ǂݎ���p�̈ڍs���Ƃ��Ĉ����A
'�Z�b�g�A�b�v��o�͎��ɔ�j��� W_�������� �֋z���グ��B

Public Sub EnsureMarriageHistoryWorkSheet(Optional ByVal resetData As Boolean = False)
    Dim ws As Worksheet, headers As Variant, i As Long
    Set ws = EnsureSheet(SH_W_MARRIAGE_HIST, xlSheetVeryHidden)
    If resetData Then
        ws.Cells.Clear
        mLegacyFactsBackfilled = False
    End If
    headers = Array("��������ID", "�l��ID", "����l��ID", "���薼", "������", "������", _
        "�������", "����", "���l", "�����쐬�敪", "�\��", "�f�[�^���", _
        "�쐬����", "�X�V����", "���f�[�^ID")
    For i = LBound(headers) To UBound(headers)
        ws.Cells(1, i + 1).Value = headers(i)
    Next i
    ws.Rows(1).Font.Bold = True
    SetSheetVisibilitySafe ws, xlSheetVeryHidden
End Sub

Public Sub UpsertMarriageHistory(ByVal personId As String, _
        ByVal counterpartId As String, _
        ByVal counterpartName As String, _
        ByVal marriageDate As Variant, _
        ByVal divorceDate As Variant, _
        ByVal sourceText As String, _
        Optional ByVal sourceId As String = "", _
        Optional ByVal noteText As String = "")

    Dim ws As Worksheet, r As Long, stateText As String, isMigration As Boolean, useStableSourceId As Boolean
    Dim parsedMarriage As Variant, parsedDivorce As Variant
    personId = CleanText(personId)
    counterpartId = CleanText(counterpartId)
    counterpartName = CleanText(counterpartName)
    sourceId = CleanText(sourceId)
    parsedMarriage = SameDateOrBlank(marriageDate)
    parsedDivorce = SameDateOrBlank(divorceDate)
    If Len(personId) = 0 Then Exit Sub
    isMigration = (InStr(1, sourceText, "�ڍs", vbTextCompare) > 0)
    '�l���o�^�E�z��ғo�^�E���f�[�^�ڍs�́A���t�����������������s���X�V����B
    '����������͂����͓�������Ƃ̍č��𕡐��s�Ŏ��Ă邽�߁A��ID�Œ�ɂ��Ȃ��B
    useStableSourceId = (Len(sourceId) > 0 And sourceText <> "�����������")
    If Not HasInputDate(parsedMarriage) And Not HasInputDate(parsedDivorce) Then
        '�����o�^�s�̓��t�𗼕������čēo�^�����ꍇ�A�����t�𗚗𑤂��畜�������Ȃ��B
        '�蓮�ǉ������͂��̓����ŏ������A���������m�F���疾���I�Ɏ������B
        If useStableSourceId And SheetExists(SH_W_MARRIAGE_HIST, ThisWorkbook) Then
            Set ws = ThisWorkbook.Worksheets(SH_W_MARRIAGE_HIST)
            r = FindMarriageHistoryRowBySourceId(sourceId, personId)
            If r > 0 Then
                ws.Cells(r, MH_STATUS).Value = STATUS_CANCEL
                ws.Cells(r, MH_SHOW).Value = SHOW_NO
                ws.Cells(r, MH_UPDATED).Value = Now
                On Error Resume Next
                DiagramGraphReset
                On Error GoTo 0
            End If
        End If
        Exit Sub
    End If

    If Len(counterpartName) = 0 And Len(counterpartId) > 0 Then counterpartName = GetPersonValue(counterpartId, P_DISPLAY)

    EnsureMarriageHistoryWorkSheet
    Set ws = ThisWorkbook.Worksheets(SH_W_MARRIAGE_HIST)

    '�ڍs��ID������s�́A���t���ォ���������Ă����������s���X�V����B
    '�������t��v�����ŒT���ƁA����̒����̂��тɌÂ��s���c��A���n�񂪏d������B
    If useStableSourceId Then r = FindMarriageHistoryRowBySourceId(sourceId, personId)
    If r = 0 Then r = FindMarriageHistoryRow(personId, counterpartId, counterpartName, parsedMarriage, parsedDivorce, isMigration, Len(counterpartId) > 0)
    If r = 0 Then
        r = NextBlankRow(ws, 1)
        ws.Cells(r, MH_ID).Value = NextId("��������")
        ws.Cells(r, MH_CREATED).Value = Now
    End If

    If HasInputDate(parsedDivorce) Then
        stateText = "����"
    ElseIf HasInputDate(parsedMarriage) Then
        stateText = "����"
    Else
        stateText = "���t�v�m�F"
    End If

    ws.Cells(r, MH_PERSON_ID).Value = personId
    '���`���̐l���P�Ɠ��t����荞�ލہA�����̑���l���t��������
    '����s���ŏ㏑�����Ȃ��B�����������ƍ������肪�����A�v�w���̋N�_��������B
    If Len(counterpartId) = 0 And Len(counterpartName) = 0 Then
        If Len(CleanText(ws.Cells(r, MH_COUNTERPART_ID).Value)) > 0 Then
            counterpartId = CleanText(ws.Cells(r, MH_COUNTERPART_ID).Value)
            counterpartName = CleanText(ws.Cells(r, MH_COUNTERPART_NAME).Value)
        End If
    End If
    ws.Cells(r, MH_COUNTERPART_ID).Value = counterpartId
    ws.Cells(r, MH_COUNTERPART_NAME).Value = counterpartName
    ws.Cells(r, MH_MARRIAGE).Value = parsedMarriage
    ws.Cells(r, MH_DIVORCE).Value = parsedDivorce
    ws.Cells(r, MH_STATE).Value = stateText
    ws.Cells(r, MH_SOURCE).Value = sourceText
    ws.Cells(r, MH_NOTE).Value = noteText
    If sourceText = "�����������" Then
        ws.Cells(r, MH_AUTO).Value = "�����"
    ElseIf InStr(1, sourceText, "�ڍs", vbTextCompare) > 0 Then
        ws.Cells(r, MH_AUTO).Value = "�ڍs"
    Else
        ws.Cells(r, MH_AUTO).Value = "����"
    End If
    ws.Cells(r, MH_SHOW).Value = SHOW_YES
    ws.Cells(r, MH_STATUS).Value = STATUS_ACTIVE
    ws.Cells(r, MH_UPDATED).Value = Now
    ws.Cells(r, MH_SOURCE_ID).Value = sourceId
    SetSheetVisibilitySafe ws, xlSheetVeryHidden
    On Error Resume Next
    DiagramGraphReset
    On Error GoTo 0
End Sub

Public Sub BackfillMarriageHistoryFromLegacyFacts()
    '���Ńf�[�^�� P_MARRIAGE/P_DIVORCE �� R_MARRIAGE/R_DIVORCE ���A���������֔�j��ňڍs����B
    '����͏����Ȃ��B���n��E03���́E���ʕۑ��� W_��������/T_�������� ��D�悷��B
    If mLegacyFactsBackfilled Then Exit Sub
    Dim wp As Worksheet, wr As Worksheet
    Dim r As Long, lastR As Long
    Dim pid As String, otherId As String, relType As String, srcId As String, cpName As String

    If Not SheetExists(SH_W_PERSON, ThisWorkbook) Then Exit Sub
    EnsureMarriageHistoryWorkSheet

    Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)
    lastR = LastRow(wp, 1)
    For r = 2 To lastR
        If CStr(wp.Cells(r, P_STATUS).Value) <> STATUS_CANCEL Then
            pid = CleanText(wp.Cells(r, P_ID).Value)
            If Len(pid) > 0 Then
                If (HasInputDate(wp.Cells(r, P_MARRIAGE).Value) Or HasInputDate(wp.Cells(r, P_DIVORCE).Value)) _
                        And Not MarriageHistoryPersonPeriodAlreadyPresent(pid, wp.Cells(r, P_MARRIAGE).Value, wp.Cells(r, P_DIVORCE).Value) Then
                    srcId = "P|" & pid & "|" & CStr(r)
                    UpsertMarriageHistory pid, "", "", wp.Cells(r, P_MARRIAGE).Value, wp.Cells(r, P_DIVORCE).Value, "�l���\�������t�ڍs", srcId, "���`���̖{�l������/�{�l����������ڍs"
                End If
            End If
        End If
    Next r

    If Not SheetExists(SH_W_REL, ThisWorkbook) Then Exit Sub
    Set wr = ThisWorkbook.Worksheets(SH_W_REL)
    lastR = LastRow(wr, 1)
    For r = 2 To lastR
        If CStr(wr.Cells(r, R_STATUS).Value) <> STATUS_CANCEL Then
            relType = CleanText(wr.Cells(r, R_TYPE).Value)
            If DiagramGraphIsSpouseRelationType(relType) Then
                pid = CleanText(wr.Cells(r, R_BASE_ID).Value)
                otherId = CleanText(wr.Cells(r, R_OTHER_ID).Value)
                If Len(pid) > 0 Then
                    If (HasInputDate(wr.Cells(r, R_MARRIAGE).Value) Or HasInputDate(wr.Cells(r, R_DIVORCE).Value)) _
                            And Not MarriageHistoryPairPeriodAlreadyPresent(pid, otherId, wr.Cells(r, R_MARRIAGE).Value, wr.Cells(r, R_DIVORCE).Value) Then
                        cpName = ""
                        If Len(otherId) > 0 Then cpName = GetPersonValue(otherId, P_DISPLAY)
                        srcId = "R|" & CleanText(wr.Cells(r, R_ID).Value)
                        UpsertMarriageHistory pid, otherId, cpName, wr.Cells(r, R_MARRIAGE).Value, wr.Cells(r, R_DIVORCE).Value, "�֌W�\�������t�ڍs", srcId, "���`���̔z��Ҋ֌W���t����ڍs"
                    End If
                End If
            End If
        End If
    Next r

    '�z��Ґl�����ォ��o�^���ꂽ�ꍇ�A��ɓ��͂��ꂽ�u���薢�w��v�̗�����
    '��ӂɊm��ł���z��Ҋ֌W�֌��ђ����B
    ReconcileMarriageHistoryCounterpartsFromRelations
    SyncLegacyMarriageFactsFromHistory
    ThisWorkbook.Worksheets(SH_W_MARRIAGE_HIST).Visible = xlSheetVeryHidden
    mLegacyFactsBackfilled = True
End Sub

Public Sub ReconcileMarriageHistoryCounterpartsFromRelations()
    'W_�֌W�̔z��ҍs��l�������N�̐��{�Ƃ��āA���������̋󑊎��⊮����B
    '��₪��������ꍇ�͐��������A���薼�ƈ�v����1�l�������̗p����B
    Dim mh As Worksheet, r As Long, pid As String, cpId As String, cpName As String
    Dim resolvedId As String, resolvedName As String
    If Not SheetExists(SH_W_MARRIAGE_HIST, ThisWorkbook) Then Exit Sub
    If Not SheetExists(SH_W_REL, ThisWorkbook) Then Exit Sub
    Set mh = ThisWorkbook.Worksheets(SH_W_MARRIAGE_HIST)

    For r = 2 To LastRow(mh, MH_ID)
        If CleanText(mh.Cells(r, MH_STATUS).Value) <> STATUS_CANCEL Then
            pid = CleanText(mh.Cells(r, MH_PERSON_ID).Value)
            cpId = CleanText(mh.Cells(r, MH_COUNTERPART_ID).Value)
            cpName = CleanText(mh.Cells(r, MH_COUNTERPART_NAME).Value)
            If Len(pid) > 0 And Left$(pid, 14) <> "__PENDING_MH__" Then
                If Len(cpId) > 0 Then
                    resolvedName = GetPersonValue(cpId, P_DISPLAY)
                    If Len(cpName) = 0 And Len(resolvedName) > 0 Then
                        mh.Cells(r, MH_COUNTERPART_NAME).Value = resolvedName
                        mh.Cells(r, MH_UPDATED).Value = Now
                    End If
                Else
                    resolvedId = MarriageHistoryUniqueSpouseId(pid, cpName, _
                        mh.Cells(r, MH_MARRIAGE).Value, mh.Cells(r, MH_DIVORCE).Value)
                    If Len(resolvedId) > 0 Then
                        resolvedName = GetPersonValue(resolvedId, P_DISPLAY)
                        mh.Cells(r, MH_COUNTERPART_ID).Value = resolvedId
                        If Len(resolvedName) > 0 Then mh.Cells(r, MH_COUNTERPART_NAME).Value = resolvedName
                        mh.Cells(r, MH_UPDATED).Value = Now
                    End If
                End If
            End If
        End If
    Next r
End Sub

Private Function MarriageHistoryUniqueSpouseId(ByVal personId As String, ByVal counterpartName As String, _
        ByVal marriageDate As Variant, ByVal divorceDate As Variant) As String
    Dim wr As Worksheet, r As Long, a As String, b As String, candidateId As String
    Dim candidates As Object, candidateName As String, k As Variant
    personId = CleanText(personId)
    counterpartName = CleanText(counterpartName)
    If Len(personId) = 0 Or Not SheetExists(SH_W_REL, ThisWorkbook) Then Exit Function
    Set candidates = CreateObject("Scripting.Dictionary")
    Set wr = ThisWorkbook.Worksheets(SH_W_REL)

    For r = 2 To LastRow(wr, R_ID)
        If CleanText(wr.Cells(r, R_STATUS).Value) <> STATUS_CANCEL _
                And DiagramGraphIsSpouseRelationType(CleanText(wr.Cells(r, R_TYPE).Value)) Then
            a = CleanText(wr.Cells(r, R_BASE_ID).Value)
            b = CleanText(wr.Cells(r, R_OTHER_ID).Value)
            candidateId = vbNullString
            If a = personId Then
                candidateId = b
            ElseIf b = personId Then
                candidateId = a
            End If
            If Len(candidateId) > 0 And candidateId <> personId And FindPersonRow(candidateId) > 0 Then
                candidateName = GetPersonValue(candidateId, P_DISPLAY)
                If Len(counterpartName) > 0 Then
                    If StrComp(counterpartName, candidateName, vbTextCompare) = 0 Then
                        If Not candidates.Exists(candidateId) Then candidates.Add candidateId, True
                    End If
                ElseIf MarriageHistoryRelationPeriodMatches(personId, candidateId, marriageDate, divorceDate) _
                        Or MarriageHistoryActivePeriodCount(personId) = 1 Then
                    If Not candidates.Exists(candidateId) Then candidates.Add candidateId, True
                End If
            End If
        End If
    Next r

    If candidates.Count = 1 Then
        For Each k In candidates.Keys
            MarriageHistoryUniqueSpouseId = CStr(k)
            Exit Function
        Next k
    End If
End Function

Private Function MarriageHistoryActivePeriodCount(ByVal personId As String) As Long
    Dim ws As Worksheet, r As Long, ownerId As String, cpId As String
    personId = CleanText(personId)
    If Len(personId) = 0 Or Not SheetExists(SH_W_MARRIAGE_HIST, ThisWorkbook) Then Exit Function
    Set ws = ThisWorkbook.Worksheets(SH_W_MARRIAGE_HIST)
    For r = 2 To LastRow(ws, MH_ID)
        If CleanText(ws.Cells(r, MH_STATUS).Value) <> STATUS_CANCEL _
                And CleanText(ws.Cells(r, MH_SHOW).Value) <> SHOW_NO Then
            ownerId = CleanText(ws.Cells(r, MH_PERSON_ID).Value)
            cpId = CleanText(ws.Cells(r, MH_COUNTERPART_ID).Value)
            If ownerId = personId Or cpId = personId Then
                If HasInputDate(ws.Cells(r, MH_MARRIAGE).Value) Or HasInputDate(ws.Cells(r, MH_DIVORCE).Value) Then
                    MarriageHistoryActivePeriodCount = MarriageHistoryActivePeriodCount + 1
                End If
            End If
        End If
    Next r
End Function

Private Function MarriageHistoryRelationPeriodMatches(ByVal leftId As String, ByVal rightId As String, _
        ByVal marriageDate As Variant, ByVal divorceDate As Variant) As Boolean
    Dim wr As Worksheet, r As Long, a As String, b As String
    leftId = CleanText(leftId)
    rightId = CleanText(rightId)
    If Len(leftId) = 0 Or Len(rightId) = 0 Or Not SheetExists(SH_W_REL, ThisWorkbook) Then Exit Function
    Set wr = ThisWorkbook.Worksheets(SH_W_REL)
    For r = 2 To LastRow(wr, R_ID)
        If CleanText(wr.Cells(r, R_STATUS).Value) <> STATUS_CANCEL _
                And DiagramGraphIsSpouseRelationType(CleanText(wr.Cells(r, R_TYPE).Value)) Then
            a = CleanText(wr.Cells(r, R_BASE_ID).Value)
            b = CleanText(wr.Cells(r, R_OTHER_ID).Value)
            If (a = leftId And b = rightId) Or (a = rightId And b = leftId) Then
                If MarriageSameDateValueOrBlank(wr.Cells(r, R_MARRIAGE).Value, marriageDate) _
                        And MarriageSameDateValueOrBlank(wr.Cells(r, R_DIVORCE).Value, divorceDate) Then
                    MarriageHistoryRelationPeriodMatches = True
                    Exit Function
                End If
            End If
        End If
    Next r
End Function

Private Function FindMarriageHistoryRow(ByVal personId As String, _
        ByVal counterpartId As String, _
        ByVal counterpartName As String, _
        ByVal marriageDate As Variant, _
        ByVal divorceDate As Variant, _
        Optional ByVal allowLegacyMerge As Boolean = False, _
        Optional ByVal allowBlankCounterpartMerge As Boolean = False) As Long

    Dim ws As Worksheet, r As Long, lastR As Long, candidateRow As Long, candidateCount As Long
    Dim existingCpId As String, existingCpName As String
    personId = CleanText(personId)
    counterpartId = CleanText(counterpartId)
    counterpartName = CleanText(counterpartName)
    If Len(personId) = 0 Then Exit Function
    EnsureMarriageHistoryWorkSheet
    Set ws = ThisWorkbook.Worksheets(SH_W_MARRIAGE_HIST)
    lastR = LastRow(ws, 1)
    For r = 2 To lastR
        If CStr(ws.Cells(r, MH_STATUS).Value) <> STATUS_CANCEL Then
            If CleanText(ws.Cells(r, MH_PERSON_ID).Value) = personId Then
                If MarriageSameDateValueOrBlank(ws.Cells(r, MH_MARRIAGE).Value, marriageDate) Then
                    If MarriageSameDateValueOrBlank(ws.Cells(r, MH_DIVORCE).Value, divorceDate) Then
                        existingCpId = CleanText(ws.Cells(r, MH_COUNTERPART_ID).Value)
                        existingCpName = CleanText(ws.Cells(r, MH_COUNTERPART_NAME).Value)
                        If Len(counterpartId) > 0 Then
                            If existingCpId = counterpartId Then FindMarriageHistoryRow = r: Exit Function
                            If allowBlankCounterpartMerge And Len(existingCpId) = 0 Then
                                If Len(counterpartName) = 0 Or Len(existingCpName) = 0 Or StrComp(existingCpName, counterpartName, vbTextCompare) = 0 Then
                                    candidateCount = candidateCount + 1
                                    candidateRow = r
                                End If
                            End If
                        ElseIf Len(existingCpId) = 0 Then
                            If Len(counterpartName) = 0 Or Len(existingCpName) = 0 Or StrComp(existingCpName, counterpartName, vbTextCompare) = 0 Then
                                FindMarriageHistoryRow = r
                                Exit Function
                            End If
                        ElseIf allowLegacyMerge Then
                            '�{�l�P�Ƃ̓��t�ڍs�͑�������������A���������֊񂹂�B
                            candidateCount = candidateCount + 1
                            candidateRow = r
                        End If
                    End If
                End If
            End If
        End If
    Next r
    If (allowLegacyMerge Or allowBlankCounterpartMerge) And candidateCount = 1 Then FindMarriageHistoryRow = candidateRow
End Function

Private Function FindMarriageHistoryRowBySourceId(ByVal sourceId As String, ByVal personId As String) As Long
    Dim ws As Worksheet, r As Long, lastR As Long
    sourceId = CleanText(sourceId)
    personId = CleanText(personId)
    If Len(sourceId) = 0 Or Len(personId) = 0 Then Exit Function
    If Not SheetExists(SH_W_MARRIAGE_HIST, ThisWorkbook) Then Exit Function
    Set ws = ThisWorkbook.Worksheets(SH_W_MARRIAGE_HIST)
    lastR = LastRow(ws, MH_ID)
    For r = 2 To lastR
        If CleanText(ws.Cells(r, MH_STATUS).Value) <> STATUS_CANCEL Then
            If CleanText(ws.Cells(r, MH_SOURCE_ID).Value) = sourceId _
                    And CleanText(ws.Cells(r, MH_PERSON_ID).Value) = personId Then
                FindMarriageHistoryRowBySourceId = r
                Exit Function
            End If
        End If
    Next r
End Function

Public Function MarriageHistoryTryGetPairPeriod(ByVal leftId As String, _
        ByVal rightId As String, _
        ByVal targetDate As Variant, _
        ByRef marriageDate As Variant, _
        ByRef divorceDate As Variant) As Boolean
    '����������v�w���Ԃ̗B��̐��K�����Ƃ��Č��J����B
    '�o�^�E�֌W�}�E���n�񂪐l���\�̒P�ƍ�������ʁX�ɓǂނƁA���������Ŕ��肪���򂷂�B
    Dim ws As Worksheet, r As Long, pid As String, cpId As String
    Dim m As Variant, d As Variant, target As Variant
    Dim rank As Long, bestRank As Long, mSerial As Double, bestSerial As Double
    Dim hasTarget As Boolean

    marriageDate = Empty
    divorceDate = Empty
    leftId = CleanText(leftId)
    rightId = CleanText(rightId)
    If Len(leftId) = 0 Or Len(rightId) = 0 Or leftId = rightId Then Exit Function
    If Not SheetExists(SH_W_MARRIAGE_HIST, ThisWorkbook) Then Exit Function

    target = SameDateOrBlank(targetDate)
    hasTarget = HasInputDate(target)
    Set ws = ThisWorkbook.Worksheets(SH_W_MARRIAGE_HIST)
    For r = 2 To LastRow(ws, MH_ID)
        If CleanText(ws.Cells(r, MH_STATUS).Value) <> STATUS_CANCEL _
                And CleanText(ws.Cells(r, MH_SHOW).Value) <> SHOW_NO Then
            pid = CleanText(ws.Cells(r, MH_PERSON_ID).Value)
            cpId = CleanText(ws.Cells(r, MH_COUNTERPART_ID).Value)
            If (pid = leftId And cpId = rightId) Or (pid = rightId And cpId = leftId) Then
                m = SameDateOrBlank(ws.Cells(r, MH_MARRIAGE).Value)
                d = SameDateOrBlank(ws.Cells(r, MH_DIVORCE).Value)
                If HasInputDate(m) Or HasInputDate(d) Then
                    rank = 1
                    If hasTarget Then
                        If HasInputDate(m) And CDate(target) >= CDate(m) _
                                And (Not HasInputDate(d) Or CDate(target) <= CDate(d)) Then
                            rank = 3
                        ElseIf HasInputDate(m) And CDate(m) <= CDate(target) Then
                            rank = 2
                        End If
                    ElseIf Not HasInputDate(d) Then
                        rank = 3
                    ElseIf HasInputDate(m) Then
                        rank = 2
                    Else
                        rank = 1
                    End If
                    If HasInputDate(m) Then
                        mSerial = CDbl(CDate(m))
                    ElseIf HasInputDate(d) Then
                        mSerial = CDbl(CDate(d))
                    Else
                        mSerial = 0
                    End If
                    If rank > bestRank Or (rank = bestRank And mSerial > bestSerial) Then
                        bestRank = rank
                        bestSerial = mSerial
                        marriageDate = m
                        divorceDate = d
                    End If
                End If
            End If
        End If
    Next r
    MarriageHistoryTryGetPairPeriod = (bestRank > 0)
End Function

Public Function MarriageHistoryPairHasRecord(ByVal leftId As String, ByVal rightId As String, _
        Optional ByVal includeInactive As Boolean = False) As Boolean
    Dim ws As Worksheet, r As Long, pid As String, cpId As String
    leftId = CleanText(leftId)
    rightId = CleanText(rightId)
    If Len(leftId) = 0 Or Len(rightId) = 0 Or leftId = rightId Then Exit Function
    If Not SheetExists(SH_W_MARRIAGE_HIST, ThisWorkbook) Then Exit Function
    Set ws = ThisWorkbook.Worksheets(SH_W_MARRIAGE_HIST)
    For r = 2 To LastRow(ws, MH_ID)
        If includeInactive Or (CleanText(ws.Cells(r, MH_STATUS).Value) <> STATUS_CANCEL _
                And CleanText(ws.Cells(r, MH_SHOW).Value) <> SHOW_NO) Then
            pid = CleanText(ws.Cells(r, MH_PERSON_ID).Value)
            cpId = CleanText(ws.Cells(r, MH_COUNTERPART_ID).Value)
            If (pid = leftId And cpId = rightId) Or (pid = rightId And cpId = leftId) Then
                MarriageHistoryPairHasRecord = True
                Exit Function
            End If
        End If
    Next r
End Function

Public Sub SyncLegacyMarriageFactsFromHistory()
    'W_���������𐳂Ƃ��āA����͌݊��\���E���f�[�^�捞�p�ɓ�������B
    '�Ȍ�̐e�������PairPeriod���g�����߁A�����z��҂ł��P�Ɠ��t�̏Փ˂��N�����Ȃ��B
    Dim wp As Worksheet, wr As Worksheet, r As Long, pid As String
    Dim m As Variant, d As Variant, a As String, b As String
    On Error GoTo EH
    If Not SheetExists(SH_W_PERSON, ThisWorkbook) Then Exit Sub
    EnsureMarriageHistoryWorkSheet
    Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)
    For r = 2 To LastRow(wp, P_ID)
        If CleanText(wp.Cells(r, P_STATUS).Value) <> STATUS_CANCEL Then
            pid = CleanText(wp.Cells(r, P_ID).Value)
            If Len(pid) > 0 Then
                m = Empty: d = Empty
                If MarriageHistoryTryGetPrimaryPeriod(pid, m, d) Then
                    If HasInputDate(m) Then wp.Cells(r, P_MARRIAGE).Value = m Else wp.Cells(r, P_MARRIAGE).ClearContents
                    If HasInputDate(d) Then wp.Cells(r, P_DIVORCE).Value = d Else wp.Cells(r, P_DIVORCE).ClearContents
                ElseIf MarriageHistoryPersonHasRecord(pid, True) Then
                    '�����𖾎������������������������B���𖢍쐬�̐l�����͒l�͏���ɏ����Ȃ��B
                    wp.Cells(r, P_MARRIAGE).ClearContents
                    wp.Cells(r, P_DIVORCE).ClearContents
                End If
            End If
        End If
    Next r

    If SheetExists(SH_W_REL, ThisWorkbook) Then
        Set wr = ThisWorkbook.Worksheets(SH_W_REL)
        For r = 2 To LastRow(wr, R_ID)
            If CleanText(wr.Cells(r, R_STATUS).Value) <> STATUS_CANCEL _
                    And DiagramGraphIsSpouseRelationType(CleanText(wr.Cells(r, R_TYPE).Value)) Then
                a = CleanText(wr.Cells(r, R_BASE_ID).Value)
                b = CleanText(wr.Cells(r, R_OTHER_ID).Value)
                If MarriageHistoryPairHasRecord(a, b, False) Then
                    m = Empty: d = Empty
                    MarriageHistoryTryGetPairPeriod a, b, Empty, m, d
                    If HasInputDate(m) Then wr.Cells(r, R_MARRIAGE).Value = m Else wr.Cells(r, R_MARRIAGE).ClearContents
                    If HasInputDate(d) Then wr.Cells(r, R_DIVORCE).Value = d Else wr.Cells(r, R_DIVORCE).ClearContents
                ElseIf MarriageHistoryPairHasRecord(a, b, True) Then
                    wr.Cells(r, R_MARRIAGE).ClearContents
                    wr.Cells(r, R_DIVORCE).ClearContents
                End If
            End If
        Next r
    End If
    On Error Resume Next
    DiagramGraphReset
    On Error GoTo 0
    Exit Sub
EH:
    RuntimeAppendLog "WARN", "SyncLegacyMarriageFactsFromHistory", "�������𓯊�", "���񓯊����ꕔ�ȗ����܂����B", Err.Number, Err.Description, Err.Source
End Sub

Private Function MarriageHistoryPersonHasRecord(ByVal personId As String, Optional ByVal includeInactive As Boolean = False) As Boolean
    Dim ws As Worksheet, r As Long, ownerId As String, cpId As String
    personId = CleanText(personId)
    If Len(personId) = 0 Or Not SheetExists(SH_W_MARRIAGE_HIST, ThisWorkbook) Then Exit Function
    Set ws = ThisWorkbook.Worksheets(SH_W_MARRIAGE_HIST)
    For r = 2 To LastRow(ws, MH_ID)
        If includeInactive Or (CleanText(ws.Cells(r, MH_STATUS).Value) <> STATUS_CANCEL _
                And CleanText(ws.Cells(r, MH_SHOW).Value) <> SHOW_NO) Then
            ownerId = CleanText(ws.Cells(r, MH_PERSON_ID).Value)
            cpId = CleanText(ws.Cells(r, MH_COUNTERPART_ID).Value)
            If ownerId = personId Or cpId = personId Then
                MarriageHistoryPersonHasRecord = True
                Exit Function
            End If
        End If
    Next r
End Function

Public Function MarriageHistoryTryGetPrimaryPeriod(ByVal personId As String, _
        ByRef marriageDate As Variant, _
        ByRef divorceDate As Variant) As Boolean
    '����֌݊��������邽�߂̑�\���ԁB�������Ɨ�������ʁX�ɍő剻���Ȃ��B
    '�������i�������Ȃ��j��D�悵�A���ɍ������܂��͗��������V�����������̗p����B
    Dim ws As Worksheet, r As Long, m As Variant, d As Variant, ownerId As String, cpId As String
    Dim rank As Long, bestRank As Long, periodSerial As Double, bestSerial As Double
    personId = CleanText(personId)
    marriageDate = Empty
    divorceDate = Empty
    If Len(personId) = 0 Or Not SheetExists(SH_W_MARRIAGE_HIST, ThisWorkbook) Then Exit Function
    Set ws = ThisWorkbook.Worksheets(SH_W_MARRIAGE_HIST)
    For r = 2 To LastRow(ws, MH_ID)
        If CleanText(ws.Cells(r, MH_STATUS).Value) <> STATUS_CANCEL _
                And CleanText(ws.Cells(r, MH_SHOW).Value) <> SHOW_NO Then
            ownerId = CleanText(ws.Cells(r, MH_PERSON_ID).Value)
            cpId = CleanText(ws.Cells(r, MH_COUNTERPART_ID).Value)
            If ownerId = personId Or cpId = personId Then
            m = SameDateOrBlank(ws.Cells(r, MH_MARRIAGE).Value)
            d = SameDateOrBlank(ws.Cells(r, MH_DIVORCE).Value)
            If HasInputDate(m) Or HasInputDate(d) Then
                If Not HasInputDate(d) Then
                    rank = 3
                ElseIf HasInputDate(m) Then
                    rank = 2
                Else
                    rank = 1
                End If
                If HasInputDate(m) Then
                    periodSerial = CDbl(CDate(m))
                Else
                    periodSerial = CDbl(CDate(d))
                End If
                If rank > bestRank Or (rank = bestRank And periodSerial > bestSerial) Then
                    bestRank = rank
                    bestSerial = periodSerial
                    marriageDate = m
                    divorceDate = d
                End If
            End If
            End If
        End If
    Next r
    MarriageHistoryTryGetPrimaryPeriod = (bestRank > 0)
End Function

Private Function MarriageHistoryLegacyFactAlreadyPresent(ByVal sourceId As String, _
        ByVal marriageDate As Variant, ByVal divorceDate As Variant) As Boolean
    Dim ws As Worksheet, r As Long
    If Len(CleanText(sourceId)) = 0 Or Not SheetExists(SH_W_MARRIAGE_HIST, ThisWorkbook) Then Exit Function
    Set ws = ThisWorkbook.Worksheets(SH_W_MARRIAGE_HIST)
    For r = 2 To LastRow(ws, MH_ID)
        If CleanText(ws.Cells(r, MH_SOURCE_ID).Value) = CleanText(sourceId) Then
            If SameInputDateOrBothBlank(ws.Cells(r, MH_MARRIAGE).Value, marriageDate) _
                    And SameInputDateOrBothBlank(ws.Cells(r, MH_DIVORCE).Value, divorceDate) Then
                MarriageHistoryLegacyFactAlreadyPresent = True
                Exit Function
            End If
        End If
    Next r
End Function

Private Function MarriageHistoryPersonPeriodAlreadyPresent(ByVal personId As String, _
        ByVal marriageDate As Variant, ByVal divorceDate As Variant) As Boolean
    Dim ws As Worksheet, r As Long, ownerId As String, cpId As String
    personId = CleanText(personId)
    If Len(personId) = 0 Or Not SheetExists(SH_W_MARRIAGE_HIST, ThisWorkbook) Then Exit Function
    Set ws = ThisWorkbook.Worksheets(SH_W_MARRIAGE_HIST)
    For r = 2 To LastRow(ws, MH_ID)
        If CleanText(ws.Cells(r, MH_STATUS).Value) <> STATUS_CANCEL Then
            ownerId = CleanText(ws.Cells(r, MH_PERSON_ID).Value)
            cpId = CleanText(ws.Cells(r, MH_COUNTERPART_ID).Value)
            If ownerId = personId Or cpId = personId Then
                If MarriageSameDateValueOrBlank(ws.Cells(r, MH_MARRIAGE).Value, marriageDate) _
                        And MarriageSameDateValueOrBlank(ws.Cells(r, MH_DIVORCE).Value, divorceDate) Then
                    MarriageHistoryPersonPeriodAlreadyPresent = True
                    Exit Function
                End If
            End If
        End If
    Next r
End Function

Private Function MarriageHistoryPairPeriodAlreadyPresent(ByVal leftId As String, ByVal rightId As String, _
        ByVal marriageDate As Variant, ByVal divorceDate As Variant) As Boolean
    Dim ws As Worksheet, r As Long, ownerId As String, cpId As String
    leftId = CleanText(leftId)
    rightId = CleanText(rightId)
    If Len(leftId) = 0 Or Len(rightId) = 0 Then Exit Function
    If Not SheetExists(SH_W_MARRIAGE_HIST, ThisWorkbook) Then Exit Function
    Set ws = ThisWorkbook.Worksheets(SH_W_MARRIAGE_HIST)
    For r = 2 To LastRow(ws, MH_ID)
        If CleanText(ws.Cells(r, MH_STATUS).Value) <> STATUS_CANCEL Then
            ownerId = CleanText(ws.Cells(r, MH_PERSON_ID).Value)
            cpId = CleanText(ws.Cells(r, MH_COUNTERPART_ID).Value)
            If (ownerId = leftId And cpId = rightId) Or (ownerId = rightId And cpId = leftId) Then
                If MarriageSameDateValueOrBlank(ws.Cells(r, MH_MARRIAGE).Value, marriageDate) _
                        And MarriageSameDateValueOrBlank(ws.Cells(r, MH_DIVORCE).Value, divorceDate) Then
                    MarriageHistoryPairPeriodAlreadyPresent = True
                    Exit Function
                End If
            End If
        End If
    Next r
End Function

Private Function MarriageSameDateValueOrBlank(ByVal a As Variant, ByVal b As Variant) As Boolean
    MarriageSameDateValueOrBlank = SameInputDateOrBothBlank(a, b)
End Function


Public Sub ShowMarriageHistoryEditor()
    '����݊��̓����B�����\ W_�������� �͒��ڌ������A�m�F�p�̔�����ʂ֗U������B
    ShowMarriageHistoryReviewSheet
End Sub

Public Sub ApplyMarriageHistoryEditorChanges()
    ApplyMarriageHistoryReviewEdits
End Sub
